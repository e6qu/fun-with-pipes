
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14718>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	90000045 	adrp	x5, 9000 <__divti3+0x2c0>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	911ac0a5 	add	x5, x5, #0x6b0
    1720:	90000044 	adrp	x4, 9000 <__divti3+0x2c0>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	911ae084 	add	x4, x4, #0x6b8
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x14718>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9004a61 	str	x1, [x19, #144]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    17a4:	91264000 	add	x0, x0, #0x990
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000022 	adrp	x2, 8000 <f0+0x1ee0>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	911e4042 	add	x2, x2, #0x790
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91024273 	add	x19, x19, #0x90
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942e260 	ldr	w0, [x19, #736]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    18ec:	91268000 	add	x0, x0, #0x9a0
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    18fc:	91290000 	add	x0, x0, #0xa40
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    1914:	91286000 	add	x0, x0, #0xa18
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    1920:	9127a000 	add	x0, x0, #0x9e8
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    192c:	91270000 	add	x0, x0, #0x9c0
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9101e000 	add	x0, x0, #0x78
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9101e021 	add	x1, x1, #0x78
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9101e000 	add	x0, x0, #0x78
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9101e021 	add	x1, x1, #0x78
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14718>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	39420260 	ldrb	w0, [x19, #128]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	39020260 	strb	w0, [x19, #128]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	90000041 	adrp	x1, 9000 <__divti3+0x2c0>
    1af4:	912cc021 	add	x1, x1, #0xb30
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9404800 	ldr	x0, [x0, #144]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91024043 	add	x3, x2, #0x90
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91024042 	add	x2, x2, #0x90
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	90000041 	adrp	x1, 9000 <__divti3+0x2c0>
    1cb8:	912c4021 	add	x1, x1, #0xb10
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14718>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    1cf0:	9111a000 	add	x0, x0, #0x468
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xc70>
    1d24:	9115c2a1 	add	x1, x21, #0x570
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1d38:	912580a5 	add	x5, x5, #0x960
    1d3c:	9115c2a1 	add	x1, x21, #0x570
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	9115c2b7 	add	x23, x21, #0x570
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	9115c2b5 	add	x21, x21, #0x570
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	9115c2b5 	add	x21, x21, #0x570
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1ec8:	912560a5 	add	x5, x5, #0x958
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14718>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	90000042 	adrp	x2, 9000 <__divti3+0x2c0>
    1efc:	91120042 	add	x2, x2, #0x480
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14718>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	90000042 	adrp	x2, 9000 <__divti3+0x2c0>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	9112c042 	add	x2, x2, #0x4b0
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	90000056 	adrp	x22, 9000 <__divti3+0x2c0>
    1f3c:	911442d6 	add	x22, x22, #0x510
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x14718>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	90000057 	adrp	x23, 9000 <__divti3+0x2c0>
    1f5c:	9112a2f7 	add	x23, x23, #0x4a8
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9405824 	ldr	x4, [x1, #176]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	90000043 	adrp	x3, 9000 <__divti3+0x2c0>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	91128063 	add	x3, x3, #0x4a0
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	90000040 	adrp	x0, 9000 <__divti3+0x2c0>
    1fe4:	91154000 	add	x0, x0, #0x550
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	9115a000 	add	x0, x0, #0x568
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14718>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    20ec:	9111a000 	add	x0, x0, #0x468
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91024022 	add	x2, x1, #0x90
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91024021 	add	x1, x1, #0x90
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	f0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    2230:	aa1303e0 	mov	x0, x19
    2234:	9115c021 	add	x1, x1, #0x570
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	f0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    2244:	aa1303e0 	mov	x0, x19
    2248:	9115e021 	add	x1, x1, #0x578
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	f0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    2260:	91160021 	add	x1, x1, #0x580
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14718>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	f0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    22a4:	91162042 	add	x2, x2, #0x588
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14718>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2348:	91166000 	add	x0, x0, #0x598
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2358:	9116e000 	add	x0, x0, #0x5b8
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	f0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14718>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	91178084 	add	x4, x4, #0x5e0
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	f0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	9117e084 	add	x4, x4, #0x5f8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	f0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	9117a084 	add	x4, x4, #0x5e8
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    276c:	9115c042 	add	x2, x2, #0x570
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14718>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	f0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	91180021 	add	x1, x1, #0x600
    27c8:	91182000 	add	x0, x0, #0x608
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	f0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	9118a042 	add	x2, x2, #0x628
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xa90>
    28d8:	9111c061 	add	x1, x3, #0x470
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    28e8:	9115c262 	add	x2, x19, #0x570
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	f0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xa90>
    291c:	9112c021 	add	x1, x1, #0x4b0
    2920:	3dc2d043 	ldr	q3, [x2, #2880]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xa90>
    294c:	9111c063 	add	x3, x3, #0x470
    2950:	91144084 	add	x4, x4, #0x510
    2954:	9115c266 	add	x6, x19, #0x570
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	9115c275 	add	x21, x19, #0x570
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2a38:	911b6000 	add	x0, x0, #0x6d8
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	9115c273 	add	x19, x19, #0x570
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91024122 	add	x2, x9, #0x90
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91024120 	add	x0, x9, #0x90
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91024129 	add	x9, x9, #0x90
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91024281 	add	x1, x20, #0x90
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91024280 	add	x0, x20, #0x90
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91024288 	add	x8, x20, #0x90
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91024281 	add	x1, x20, #0x90
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14718>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2d6c:	911ba000 	add	x0, x0, #0x6e8
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    2db4:	9115c262 	add	x2, x19, #0x570
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	9115c273 	add	x19, x19, #0x570
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2e14:	911c6000 	add	x0, x0, #0x718
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xc70>
    2e30:	9115c2c2 	add	x2, x22, #0x570
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	9115c2c2 	add	x2, x22, #0x570
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	9115c2d6 	add	x22, x22, #0x570
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    2f50:	9115c2b5 	add	x21, x21, #0x570
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3014:	9115c2a1 	add	x1, x21, #0x570
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	9115c2b5 	add	x21, x21, #0x570
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	9115c2a1 	add	x1, x21, #0x570
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	9115c2a0 	add	x0, x21, #0x570
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	9115c2b5 	add	x21, x21, #0x570
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xc70>
    3218:	9115c359 	add	x25, x26, #0x570
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	9115c353 	add	x19, x26, #0x570
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9115c35a 	add	x26, x26, #0x570
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    3330:	9115c262 	add	x2, x19, #0x570
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	9115c262 	add	x2, x19, #0x570
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	9115c260 	add	x0, x19, #0x570
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	9115c273 	add	x19, x19, #0x570
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	9115c260 	add	x0, x19, #0x570
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_fresh>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    3488:	9115c063 	add	x3, x3, #0x570
    348c:	910003fd 	mov	x29, sp
    3490:	a90153f3 	stp	x19, x20, [sp, #16]
    3494:	aa0003f3 	mov	x19, x0
    3498:	f949d861 	ldr	x1, [x3, #5040]
    349c:	f949ec60 	ldr	x0, [x3, #5080]
    34a0:	cb010261 	sub	x1, x19, x1
    34a4:	eb00403f 	cmp	x1, x0, lsl #16
    34a8:	54000322 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34ac:	d350fc22 	lsr	x2, x1, #16
    34b0:	f949fc63 	ldr	x3, [x3, #5112]
    34b4:	8b020842 	add	x2, x2, x2, lsl #2
    34b8:	d37df042 	lsl	x2, x2, #3
    34bc:	8b020060 	add	x0, x3, x2
    34c0:	f9401014 	ldr	x20, [x0, #32]
    34c4:	b4000254 	cbz	x20, 350c <fwp_rc_fresh+0x8c>
    34c8:	38626862 	ldrb	w2, [x3, x2]
    34cc:	7100085f 	cmp	w2, #0x2
    34d0:	54000260 	b.eq	351c <fwp_rc_fresh+0x9c>  // b.none
    34d4:	7100045f 	cmp	w2, #0x1
    34d8:	540001a1 	b.ne	350c <fwp_rc_fresh+0x8c>  // b.any
    34dc:	29430002 	ldp	w2, w0, [x0, #24]
    34e0:	92403c21 	and	x1, x1, #0xffff
    34e4:	9b027c21 	mul	x1, x1, x2
    34e8:	d360fc21 	lsr	x1, x1, #32
    34ec:	eb00003f 	cmp	x1, x0
    34f0:	540000e2 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34f4:	8b010294 	add	x20, x20, x1
    34f8:	39400280 	ldrb	w0, [x20]
    34fc:	7103fc1f 	cmp	w0, #0xff
    3500:	540001a0 	b.eq	3534 <fwp_rc_fresh+0xb4>  // b.none
    3504:	52800020 	mov	w0, #0x1                   	// #1
    3508:	39000280 	strb	w0, [x20]
    350c:	aa1303e0 	mov	x0, x19
    3510:	a94153f3 	ldp	x19, x20, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	72003c3f 	tst	w1, #0xffff
    3520:	54fffec0 	b.eq	34f8 <fwp_rc_fresh+0x78>  // b.none
    3524:	aa1303e0 	mov	x0, x19
    3528:	a94153f3 	ldp	x19, x20, [sp, #16]
    352c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3530:	d65f03c0 	ret
    3534:	aa1403e0 	mov	x0, x20
    3538:	97fffe13 	bl	2d84 <fwp_rc_forget_slot>
    353c:	17fffff2 	b	3504 <fwp_rc_fresh+0x84>

0000000000003540 <fwp_rc_free_arr>:
    3540:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    3544:	9115c063 	add	x3, x3, #0x570
    3548:	f949d861 	ldr	x1, [x3, #5040]
    354c:	f949ec62 	ldr	x2, [x3, #5080]
    3550:	cb010001 	sub	x1, x0, x1
    3554:	eb02403f 	cmp	x1, x2, lsl #16
    3558:	54000342 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    355c:	d350fc22 	lsr	x2, x1, #16
    3560:	f949fc65 	ldr	x5, [x3, #5112]
    3564:	8b020842 	add	x2, x2, x2, lsl #2
    3568:	d37df042 	lsl	x2, x2, #3
    356c:	8b0200a4 	add	x4, x5, x2
    3570:	f9401083 	ldr	x3, [x4, #32]
    3574:	b4000263 	cbz	x3, 35c0 <fwp_rc_free_arr+0x80>
    3578:	386268a2 	ldrb	w2, [x5, x2]
    357c:	7100085f 	cmp	w2, #0x2
    3580:	540001c0 	b.eq	35b8 <fwp_rc_free_arr+0x78>  // b.none
    3584:	7100045f 	cmp	w2, #0x1
    3588:	540001c1 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    358c:	29430885 	ldp	w5, w2, [x4, #24]
    3590:	92403c21 	and	x1, x1, #0xffff
    3594:	9b057c21 	mul	x1, x1, x5
    3598:	d360fc21 	lsr	x1, x1, #32
    359c:	eb02003f 	cmp	x1, x2
    35a0:	54000102 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    35a4:	8b010063 	add	x3, x3, x1
    35a8:	39400061 	ldrb	w1, [x3]
    35ac:	7100043f 	cmp	w1, #0x1
    35b0:	54000081 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    35b4:	17fffe93 	b	3000 <fwp_mem_free>
    35b8:	72003c3f 	tst	w1, #0xffff
    35bc:	54ffff60 	b.eq	35a8 <fwp_rc_free_arr+0x68>  // b.none
    35c0:	d65f03c0 	ret

00000000000035c4 <fwp_heap_alloc>:
    35c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    35c8:	910003fd 	mov	x29, sp
    35cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    35d0:	b00000f6 	adrp	x22, 20000 <__data_start>
    35d4:	910242c2 	add	x2, x22, #0x90
    35d8:	a90363f7 	stp	x23, x24, [sp, #48]
    35dc:	b9404058 	ldr	w24, [x2, #64]
    35e0:	a90153f3 	stp	x19, x20, [sp, #16]
    35e4:	7100031f 	cmp	w24, #0x0
    35e8:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    35ec:	54000861 	b.ne	36f8 <fwp_heap_alloc+0x134>  // b.any
    35f0:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xc70>
    35f4:	9115c2f3 	add	x19, x23, #0x570
    35f8:	f140101f 	cmp	x0, #0x4, lsl #12
    35fc:	b953a662 	ldr	w2, [x19, #5028]
    3600:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3604:	54000740 	b.eq	36ec <fwp_heap_alloc+0x128>  // b.none
    3608:	91003c03 	add	x3, x0, #0xf
    360c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3610:	cb21c042 	sub	x2, x2, w1, sxtw
    3614:	8b431263 	add	x3, x19, x3, lsr #4
    3618:	d37ae442 	lsl	x2, x2, #6
    361c:	397e8063 	ldrb	w3, [x3, #4000]
    3620:	910f0064 	add	x4, x3, #0x3c0
    3624:	8b030463 	add	x3, x3, x3, lsl #1
    3628:	8b030c43 	add	x3, x2, x3, lsl #3
    362c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3630:	2a1503f4 	mov	w20, w21
    3634:	f8636a64 	ldr	x4, [x19, x3]
    3638:	b40004c4 	cbz	x4, 36d0 <fwp_heap_alloc+0x10c>
    363c:	f9400085 	ldr	x5, [x4]
    3640:	7100043f 	cmp	w1, #0x1
    3644:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3648:	aa0403e0 	mov	x0, x4
    364c:	aa2503e5 	mvn	x5, x5
    3650:	52800001 	mov	w1, #0x0                   	// #0
    3654:	f8236a65 	str	x5, [x19, x3]
    3658:	97fff79e 	bl	14d0 <memset@plt>
    365c:	aa0003e4 	mov	x4, x0
    3660:	f94a1260 	ldr	x0, [x19, #5152]
    3664:	ab140000 	adds	x0, x0, x20
    3668:	540006e2 	b.cs	3744 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    366c:	f94a1661 	ldr	x1, [x19, #5160]
    3670:	f90a1260 	str	x0, [x19, #5152]
    3674:	eb01001f 	cmp	x0, x1
    3678:	54000049 	b.ls	3680 <fwp_heap_alloc+0xbc>  // b.plast
    367c:	f90a1660 	str	x0, [x19, #5160]
    3680:	9115c2e0 	add	x0, x23, #0x570
    3684:	1e6302a1 	ucvtf	d1, w21
    3688:	fd4a1c00 	ldr	d0, [x0, #5176]
    368c:	1e612800 	fadd	d0, d0, d1
    3690:	fd0a1c00 	str	d0, [x0, #5176]
    3694:	34000138 	cbz	w24, 36b8 <fwp_heap_alloc+0xf4>
    3698:	9115c2e1 	add	x1, x23, #0x570
    369c:	910242c0 	add	x0, x22, #0x90
    36a0:	fd4a1020 	ldr	d0, [x1, #5152]
    36a4:	6d458402 	ldp	d2, d1, [x0, #88]
    36a8:	7e61d800 	ucvtf	d0, d0
    36ac:	1e623800 	fsub	d0, d0, d2
    36b0:	1e612010 	fcmpe	d0, d1
    36b4:	540002cc 	b.gt	370c <fwp_heap_alloc+0x148>
    36b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36bc:	aa0403e0 	mov	x0, x4
    36c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    36c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    36cc:	d65f03c0 	ret
    36d0:	8b030263 	add	x3, x19, x3
    36d4:	f9400464 	ldr	x4, [x3, #8]
    36d8:	b40000a4 	cbz	x4, 36ec <fwp_heap_alloc+0x128>
    36dc:	f9400862 	ldr	x2, [x3, #16]
    36e0:	cb040042 	sub	x2, x2, x4
    36e4:	eb02029f 	cmp	x20, x2
    36e8:	54000209 	b.ls	3728 <fwp_heap_alloc+0x164>  // b.plast
    36ec:	97ffff0d 	bl	3320 <fwp_heap_alloc_slow>
    36f0:	aa0003e4 	mov	x4, x0
    36f4:	17ffffe8 	b	3694 <fwp_heap_alloc+0xd0>
    36f8:	a9448c44 	ldp	x4, x3, [x2, #72]
    36fc:	91000484 	add	x4, x4, #0x1
    3700:	8b000063 	add	x3, x3, x0
    3704:	a9048c44 	stp	x4, x3, [x2, #72]
    3708:	17ffffba 	b	35f0 <fwp_heap_alloc+0x2c>
    370c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3710:	fd003000 	str	d0, [x0, #96]
    3714:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3718:	aa0403e0 	mov	x0, x4
    371c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3720:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3724:	d65f03c0 	ret
    3728:	7100043f 	cmp	w1, #0x1
    372c:	8b140085 	add	x5, x4, x20
    3730:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3734:	52800001 	mov	w1, #0x0                   	// #0
    3738:	aa0403e0 	mov	x0, x4
    373c:	f9000465 	str	x5, [x3, #8]
    3740:	17ffffc6 	b	3658 <fwp_heap_alloc+0x94>
    3744:	97fff963 	bl	1cd0 <fwp_heap_oom>
    3748:	d503201f 	nop
    374c:	d503201f 	nop

0000000000003750 <fwp_data.part.0.constprop.0>:
    3750:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3754:	910003fd 	mov	x29, sp
    3758:	a9025bf5 	stp	x21, x22, [sp, #32]
    375c:	b00000f6 	adrp	x22, 20000 <__data_start>
    3760:	910242c2 	add	x2, x22, #0x90
    3764:	a9046bf9 	stp	x25, x26, [sp, #64]
    3768:	b9404059 	ldr	w25, [x2, #64]
    376c:	a90153f3 	stp	x19, x20, [sp, #16]
    3770:	aa0103f4 	mov	x20, x1
    3774:	a90363f7 	stp	x23, x24, [sp, #48]
    3778:	2a0003f7 	mov	w23, w0
    377c:	340000b9 	cbz	w25, 3790 <fwp_data.part.0.constprop.0+0x40>
    3780:	a9448041 	ldp	x1, x0, [x2, #72]
    3784:	91000421 	add	x1, x1, #0x1
    3788:	91006000 	add	x0, x0, #0x18
    378c:	a9048041 	stp	x1, x0, [x2, #72]
    3790:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3794:	9115c2a3 	add	x3, x21, #0x570
    3798:	b953a460 	ldr	w0, [x3, #5028]
    379c:	34000840 	cbz	w0, 38a4 <fwp_data.part.0.constprop.0+0x154>
    37a0:	397e8862 	ldrb	w2, [x3, #4002]
    37a4:	910f0040 	add	x0, x2, #0x3c0
    37a8:	8b020442 	add	x2, x2, x2, lsl #1
    37ac:	d37df042 	lsl	x2, x2, #3
    37b0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    37b4:	2a1a03f8 	mov	w24, w26
    37b8:	f8626873 	ldr	x19, [x3, x2]
    37bc:	b4000613 	cbz	x19, 387c <fwp_data.part.0.constprop.0+0x12c>
    37c0:	f9400260 	ldr	x0, [x19]
    37c4:	aa2003e0 	mvn	x0, x0
    37c8:	f8226860 	str	x0, [x3, x2]
    37cc:	f100631f 	cmp	x24, #0x18
    37d0:	540000e9 	b.ls	37ec <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    37d4:	d1006702 	sub	x2, x24, #0x19
    37d8:	91006260 	add	x0, x19, #0x18
    37dc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    37e0:	52800001 	mov	w1, #0x0                   	// #0
    37e4:	91002042 	add	x2, x2, #0x8
    37e8:	97fff73a 	bl	14d0 <memset@plt>
    37ec:	9115c2a0 	add	x0, x21, #0x570
    37f0:	f94a1001 	ldr	x1, [x0, #5152]
    37f4:	ab180021 	adds	x1, x1, x24
    37f8:	54000642 	b.cs	38c0 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    37fc:	f94a1402 	ldr	x2, [x0, #5160]
    3800:	f90a1001 	str	x1, [x0, #5152]
    3804:	eb02003f 	cmp	x1, x2
    3808:	54000049 	b.ls	3810 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    380c:	f90a1401 	str	x1, [x0, #5160]
    3810:	9115c2a0 	add	x0, x21, #0x570
    3814:	1e630341 	ucvtf	d1, w26
    3818:	fd4a1c00 	ldr	d0, [x0, #5176]
    381c:	1e612800 	fadd	d0, d0, d1
    3820:	fd0a1c00 	str	d0, [x0, #5176]
    3824:	34000139 	cbz	w25, 3848 <fwp_data.part.0.constprop.0+0xf8>
    3828:	9115c2b5 	add	x21, x21, #0x570
    382c:	910242d6 	add	x22, x22, #0x90
    3830:	fd4a12a0 	ldr	d0, [x21, #5152]
    3834:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3838:	7e61d800 	ucvtf	d0, d0
    383c:	1e623800 	fsub	d0, d0, d2
    3840:	1e612010 	fcmpe	d0, d1
    3844:	540003ac 	b.gt	38b8 <fwp_data.part.0.constprop.0+0x168>
    3848:	52800040 	mov	w0, #0x2                   	// #2
    384c:	29000277 	stp	w23, w0, [x19]
    3850:	aa1303e0 	mov	x0, x19
    3854:	f9400281 	ldr	x1, [x20]
    3858:	f9000661 	str	x1, [x19, #8]
    385c:	f9400681 	ldr	x1, [x20, #8]
    3860:	f9000a61 	str	x1, [x19, #16]
    3864:	a94153f3 	ldp	x19, x20, [sp, #16]
    3868:	a9425bf5 	ldp	x21, x22, [sp, #32]
    386c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3870:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3874:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3878:	d65f03c0 	ret
    387c:	8b020063 	add	x3, x3, x2
    3880:	f9400473 	ldr	x19, [x3, #8]
    3884:	b4000113 	cbz	x19, 38a4 <fwp_data.part.0.constprop.0+0x154>
    3888:	f9400860 	ldr	x0, [x3, #16]
    388c:	cb130000 	sub	x0, x0, x19
    3890:	eb00031f 	cmp	x24, x0
    3894:	54000088 	b.hi	38a4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    3898:	8b180260 	add	x0, x19, x24
    389c:	f9000460 	str	x0, [x3, #8]
    38a0:	17ffffcb 	b	37cc <fwp_data.part.0.constprop.0+0x7c>
    38a4:	52800001 	mov	w1, #0x0                   	// #0
    38a8:	d2800300 	mov	x0, #0x18                  	// #24
    38ac:	97ffff46 	bl	35c4 <fwp_heap_alloc>
    38b0:	aa0003f3 	mov	x19, x0
    38b4:	17ffffdc 	b	3824 <fwp_data.part.0.constprop.0+0xd4>
    38b8:	fd0032c0 	str	d0, [x22, #96]
    38bc:	17ffffe3 	b	3848 <fwp_data.part.0.constprop.0+0xf8>
    38c0:	97fff904 	bl	1cd0 <fwp_heap_oom>

00000000000038c4 <fwp_array_new_packed.constprop.0>:
    38c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38c8:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    38cc:	910003fd 	mov	x29, sp
    38d0:	f9000bf3 	str	x19, [sp, #16]
    38d4:	eb01001f 	cmp	x0, x1
    38d8:	54000148 	b.hi	3900 <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    38dc:	aa0003f3 	mov	x19, x0
    38e0:	91000400 	add	x0, x0, #0x1
    38e4:	52800021 	mov	w1, #0x1                   	// #1
    38e8:	d37df000 	lsl	x0, x0, #3
    38ec:	97ffff36 	bl	35c4 <fwp_heap_alloc>
    38f0:	f9000013 	str	x19, [x0]
    38f4:	f9400bf3 	ldr	x19, [sp, #16]
    38f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    38fc:	d65f03c0 	ret
    3900:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3904:	911d0000 	add	x0, x0, #0x740
    3908:	97fffa5e 	bl	2280 <fwp_trap>
    390c:	d503201f 	nop

0000000000003910 <fwp_drop1>:
    3910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3914:	910003fd 	mov	x29, sp
    3918:	a90153f3 	stp	x19, x20, [sp, #16]
    391c:	f90013f5 	str	x21, [sp, #32]
    3920:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3924:	9115c2b4 	add	x20, x21, #0x570
    3928:	f949da81 	ldr	x1, [x20, #5040]
    392c:	f949ee82 	ldr	x2, [x20, #5080]
    3930:	cb010001 	sub	x1, x0, x1
    3934:	eb02403f 	cmp	x1, x2, lsl #16
    3938:	54000382 	b.cs	39a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    393c:	d350fc22 	lsr	x2, x1, #16
    3940:	f949fe84 	ldr	x4, [x20, #5112]
    3944:	8b020842 	add	x2, x2, x2, lsl #2
    3948:	d37df042 	lsl	x2, x2, #3
    394c:	8b020083 	add	x3, x4, x2
    3950:	f9401073 	ldr	x19, [x3, #32]
    3954:	b40002b3 	cbz	x19, 39a8 <fwp_drop1+0x98>
    3958:	38626882 	ldrb	w2, [x4, x2]
    395c:	7100085f 	cmp	w2, #0x2
    3960:	540002c0 	b.eq	39b8 <fwp_drop1+0xa8>  // b.none
    3964:	7100045f 	cmp	w2, #0x1
    3968:	54000201 	b.ne	39a8 <fwp_drop1+0x98>  // b.any
    396c:	29430864 	ldp	w4, w2, [x3, #24]
    3970:	92403c21 	and	x1, x1, #0xffff
    3974:	9b047c21 	mul	x1, x1, x4
    3978:	d360fc21 	lsr	x1, x1, #32
    397c:	eb02003f 	cmp	x1, x2
    3980:	54000142 	b.cs	39a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    3984:	8b010273 	add	x19, x19, x1
    3988:	39400261 	ldrb	w1, [x19]
    398c:	340000e1 	cbz	w1, 39a8 <fwp_drop1+0x98>
    3990:	7100043f 	cmp	w1, #0x1
    3994:	540001e0 	b.eq	39d0 <fwp_drop1+0xc0>  // b.none
    3998:	7103fc3f 	cmp	w1, #0xff
    399c:	540002e0 	b.eq	39f8 <fwp_drop1+0xe8>  // b.none
    39a0:	51000421 	sub	w1, w1, #0x1
    39a4:	39000261 	strb	w1, [x19]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	f94013f5 	ldr	x21, [sp, #32]
    39b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39b4:	d65f03c0 	ret
    39b8:	72003c3f 	tst	w1, #0xffff
    39bc:	54fffe60 	b.eq	3988 <fwp_drop1+0x78>  // b.none
    39c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    39c4:	f94013f5 	ldr	x21, [sp, #32]
    39c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39cc:	d65f03c0 	ret
    39d0:	f9400813 	ldr	x19, [x0, #16]
    39d4:	97fffedb 	bl	3540 <fwp_rc_free_arr>
    39d8:	9115c2a0 	add	x0, x21, #0x570
    39dc:	f949d801 	ldr	x1, [x0, #5040]
    39e0:	f949ec00 	ldr	x0, [x0, #5080]
    39e4:	cb010261 	sub	x1, x19, x1
    39e8:	eb00403f 	cmp	x1, x0, lsl #16
    39ec:	54fffde2 	b.cs	39a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    39f0:	aa1303e0 	mov	x0, x19
    39f4:	17ffffd2 	b	393c <fwp_drop1+0x2c>
    39f8:	ca534660 	eor	x0, x19, x19, lsr #17
    39fc:	9115c2b5 	add	x21, x21, #0x570
    3a00:	ca402400 	eor	x0, x0, x0, lsr #9
    3a04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3a08:	f94a2400 	ldr	x0, [x0, #5192]
    3a0c:	b5000080 	cbnz	x0, 3a1c <fwp_drop1+0x10c>
    3a10:	14000010 	b	3a50 <fwp_drop1+0x140>
    3a14:	f9400800 	ldr	x0, [x0, #16]
    3a18:	b40001c0 	cbz	x0, 3a50 <fwp_drop1+0x140>
    3a1c:	f9400001 	ldr	x1, [x0]
    3a20:	eb13003f 	cmp	x1, x19
    3a24:	54ffff81 	b.ne	3a14 <fwp_drop1+0x104>  // b.any
    3a28:	f9400401 	ldr	x1, [x0, #8]
    3a2c:	d1000421 	sub	x1, x1, #0x1
    3a30:	f9000401 	str	x1, [x0, #8]
    3a34:	f103f83f 	cmp	x1, #0xfe
    3a38:	54fffb81 	b.ne	39a8 <fwp_drop1+0x98>  // b.any
    3a3c:	aa1303e0 	mov	x0, x19
    3a40:	97fffcd1 	bl	2d84 <fwp_rc_forget_slot>
    3a44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3a48:	39000260 	strb	w0, [x19]
    3a4c:	17ffffd7 	b	39a8 <fwp_drop1+0x98>
    3a50:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3a54:	911c6000 	add	x0, x0, #0x718
    3a58:	97fffa0a 	bl	2280 <fwp_trap>
    3a5c:	d503201f 	nop

0000000000003a60 <fwp_drop0>:
    3a60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a64:	910003fd 	mov	x29, sp
    3a68:	a90153f3 	stp	x19, x20, [sp, #16]
    3a6c:	f90013f5 	str	x21, [sp, #32]
    3a70:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3a74:	9115c2b4 	add	x20, x21, #0x570
    3a78:	f949da81 	ldr	x1, [x20, #5040]
    3a7c:	f949ee82 	ldr	x2, [x20, #5080]
    3a80:	cb010001 	sub	x1, x0, x1
    3a84:	eb02403f 	cmp	x1, x2, lsl #16
    3a88:	54000382 	b.cs	3af8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a8c:	d350fc22 	lsr	x2, x1, #16
    3a90:	f949fe84 	ldr	x4, [x20, #5112]
    3a94:	8b020842 	add	x2, x2, x2, lsl #2
    3a98:	d37df042 	lsl	x2, x2, #3
    3a9c:	8b020083 	add	x3, x4, x2
    3aa0:	f9401073 	ldr	x19, [x3, #32]
    3aa4:	b40002b3 	cbz	x19, 3af8 <fwp_drop0+0x98>
    3aa8:	38626882 	ldrb	w2, [x4, x2]
    3aac:	7100085f 	cmp	w2, #0x2
    3ab0:	540002c0 	b.eq	3b08 <fwp_drop0+0xa8>  // b.none
    3ab4:	7100045f 	cmp	w2, #0x1
    3ab8:	54000201 	b.ne	3af8 <fwp_drop0+0x98>  // b.any
    3abc:	29430864 	ldp	w4, w2, [x3, #24]
    3ac0:	92403c21 	and	x1, x1, #0xffff
    3ac4:	9b047c21 	mul	x1, x1, x4
    3ac8:	d360fc21 	lsr	x1, x1, #32
    3acc:	eb02003f 	cmp	x1, x2
    3ad0:	54000142 	b.cs	3af8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3ad4:	8b010273 	add	x19, x19, x1
    3ad8:	39400261 	ldrb	w1, [x19]
    3adc:	340000e1 	cbz	w1, 3af8 <fwp_drop0+0x98>
    3ae0:	7100043f 	cmp	w1, #0x1
    3ae4:	540001e0 	b.eq	3b20 <fwp_drop0+0xc0>  // b.none
    3ae8:	7103fc3f 	cmp	w1, #0xff
    3aec:	540002e0 	b.eq	3b48 <fwp_drop0+0xe8>  // b.none
    3af0:	51000421 	sub	w1, w1, #0x1
    3af4:	39000261 	strb	w1, [x19]
    3af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3afc:	f94013f5 	ldr	x21, [sp, #32]
    3b00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b04:	d65f03c0 	ret
    3b08:	72003c3f 	tst	w1, #0xffff
    3b0c:	54fffe60 	b.eq	3ad8 <fwp_drop0+0x78>  // b.none
    3b10:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b14:	f94013f5 	ldr	x21, [sp, #32]
    3b18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b1c:	d65f03c0 	ret
    3b20:	f9400813 	ldr	x19, [x0, #16]
    3b24:	97fffe87 	bl	3540 <fwp_rc_free_arr>
    3b28:	9115c2a0 	add	x0, x21, #0x570
    3b2c:	f949d801 	ldr	x1, [x0, #5040]
    3b30:	f949ec00 	ldr	x0, [x0, #5080]
    3b34:	cb010261 	sub	x1, x19, x1
    3b38:	eb00403f 	cmp	x1, x0, lsl #16
    3b3c:	54fffde2 	b.cs	3af8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3b40:	aa1303e0 	mov	x0, x19
    3b44:	17ffffd2 	b	3a8c <fwp_drop0+0x2c>
    3b48:	ca534660 	eor	x0, x19, x19, lsr #17
    3b4c:	9115c2b5 	add	x21, x21, #0x570
    3b50:	ca402400 	eor	x0, x0, x0, lsr #9
    3b54:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3b58:	f94a2400 	ldr	x0, [x0, #5192]
    3b5c:	b5000080 	cbnz	x0, 3b6c <fwp_drop0+0x10c>
    3b60:	14000010 	b	3ba0 <fwp_drop0+0x140>
    3b64:	f9400800 	ldr	x0, [x0, #16]
    3b68:	b40001c0 	cbz	x0, 3ba0 <fwp_drop0+0x140>
    3b6c:	f9400001 	ldr	x1, [x0]
    3b70:	eb13003f 	cmp	x1, x19
    3b74:	54ffff81 	b.ne	3b64 <fwp_drop0+0x104>  // b.any
    3b78:	f9400401 	ldr	x1, [x0, #8]
    3b7c:	d1000421 	sub	x1, x1, #0x1
    3b80:	f9000401 	str	x1, [x0, #8]
    3b84:	f103f83f 	cmp	x1, #0xfe
    3b88:	54fffb81 	b.ne	3af8 <fwp_drop0+0x98>  // b.any
    3b8c:	aa1303e0 	mov	x0, x19
    3b90:	97fffc7d 	bl	2d84 <fwp_rc_forget_slot>
    3b94:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3b98:	39000260 	strb	w0, [x19]
    3b9c:	17ffffd7 	b	3af8 <fwp_drop0+0x98>
    3ba0:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3ba4:	911c6000 	add	x0, x0, #0x718
    3ba8:	97fff9b6 	bl	2280 <fwp_trap>
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_task_dispose>:
    3bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bb4:	910003fd 	mov	x29, sp
    3bb8:	f9000bf3 	str	x19, [sp, #16]
    3bbc:	aa0003f3 	mov	x19, x0
    3bc0:	39414000 	ldrb	w0, [x0, #80]
    3bc4:	36000720 	tbz	w0, #0, 3ca8 <fwp_task_dispose+0xf8>
    3bc8:	f9400a60 	ldr	x0, [x19, #16]
    3bcc:	b50006e0 	cbnz	x0, 3ca8 <fwp_task_dispose+0xf8>
    3bd0:	a9478660 	ldp	x0, x1, [x19, #120]
    3bd4:	39014e7f 	strb	wzr, [x19, #83]
    3bd8:	f9003e7f 	str	xzr, [x19, #120]
    3bdc:	f100003f 	cmp	x1, #0x0
    3be0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3be4:	54000040 	b.eq	3bec <fwp_task_dispose+0x3c>  // b.none
    3be8:	d63f0020 	blr	x1
    3bec:	f9405660 	ldr	x0, [x19, #168]
    3bf0:	97fffd04 	bl	3000 <fwp_mem_free>
    3bf4:	f900567f 	str	xzr, [x19, #168]
    3bf8:	b9405e60 	ldr	w0, [x19, #92]
    3bfc:	7100041f 	cmp	w0, #0x1
    3c00:	54000420 	b.eq	3c84 <fwp_task_dispose+0xd4>  // b.none
    3c04:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    3c08:	9115c042 	add	x2, x2, #0x570
    3c0c:	f949d840 	ldr	x0, [x2, #5040]
    3c10:	f949ec41 	ldr	x1, [x2, #5080]
    3c14:	cb000260 	sub	x0, x19, x0
    3c18:	eb01401f 	cmp	x0, x1, lsl #16
    3c1c:	540002e2 	b.cs	3c78 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c20:	d350fc01 	lsr	x1, x0, #16
    3c24:	f949fc44 	ldr	x4, [x2, #5112]
    3c28:	8b010821 	add	x1, x1, x1, lsl #2
    3c2c:	d37df021 	lsl	x1, x1, #3
    3c30:	8b010083 	add	x3, x4, x1
    3c34:	f9401062 	ldr	x2, [x3, #32]
    3c38:	b4000202 	cbz	x2, 3c78 <fwp_task_dispose+0xc8>
    3c3c:	38616881 	ldrb	w1, [x4, x1]
    3c40:	7100083f 	cmp	w1, #0x2
    3c44:	54000280 	b.eq	3c94 <fwp_task_dispose+0xe4>  // b.none
    3c48:	7100043f 	cmp	w1, #0x1
    3c4c:	54000161 	b.ne	3c78 <fwp_task_dispose+0xc8>  // b.any
    3c50:	29430464 	ldp	w4, w1, [x3, #24]
    3c54:	92403c00 	and	x0, x0, #0xffff
    3c58:	9b047c00 	mul	x0, x0, x4
    3c5c:	d360fc00 	lsr	x0, x0, #32
    3c60:	eb01001f 	cmp	x0, x1
    3c64:	540000a2 	b.cs	3c78 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c68:	8b000042 	add	x2, x2, x0
    3c6c:	39400040 	ldrb	w0, [x2]
    3c70:	7100041f 	cmp	w0, #0x1
    3c74:	54000080 	b.eq	3c84 <fwp_task_dispose+0xd4>  // b.none
    3c78:	f9400bf3 	ldr	x19, [sp, #16]
    3c7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c80:	d65f03c0 	ret
    3c84:	aa1303e0 	mov	x0, x19
    3c88:	f9400bf3 	ldr	x19, [sp, #16]
    3c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c90:	17fffcdc 	b	3000 <fwp_mem_free>
    3c94:	72003c1f 	tst	w0, #0xffff
    3c98:	54fffea0 	b.eq	3c6c <fwp_task_dispose+0xbc>  // b.none
    3c9c:	f9400bf3 	ldr	x19, [sp, #16]
    3ca0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ca4:	d65f03c0 	ret
    3ca8:	97fff62a 	bl	1550 <abort@plt>
    3cac:	d503201f 	nop

0000000000003cb0 <fwp_free_zombie>:
    3cb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3cb4:	910003fd 	mov	x29, sp
    3cb8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cbc:	b00000f4 	adrp	x20, 20000 <__data_start>
    3cc0:	91024281 	add	x1, x20, #0x90
    3cc4:	f9403433 	ldr	x19, [x1, #104]
    3cc8:	b4000333 	cbz	x19, 3d2c <fwp_free_zombie+0x7c>
    3ccc:	f9400420 	ldr	x0, [x1, #8]
    3cd0:	eb00027f 	cmp	x19, x0
    3cd4:	540002c0 	b.eq	3d2c <fwp_free_zombie+0x7c>  // b.none
    3cd8:	b9407022 	ldr	w2, [x1, #112]
    3cdc:	f9400a60 	ldr	x0, [x19, #16]
    3ce0:	7100fc5f 	cmp	w2, #0x3f
    3ce4:	5400078c 	b.gt	3dd4 <fwp_free_zombie+0x124>
    3ce8:	91020023 	add	x3, x1, #0x80
    3cec:	11000444 	add	w4, w2, #0x1
    3cf0:	b9007024 	str	w4, [x1, #112]
    3cf4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3cf8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3cfc:	a9530261 	ldp	x1, x0, [x19, #304]
    3d00:	b4000741 	cbz	x1, 3de8 <fwp_free_zombie+0x138>
    3d04:	f9009c20 	str	x0, [x1, #312]
    3d08:	b4000040 	cbz	x0, 3d10 <fwp_free_zombie+0x60>
    3d0c:	f9009801 	str	x1, [x0, #304]
    3d10:	91024294 	add	x20, x20, #0x90
    3d14:	b9405e60 	ldr	w0, [x19, #92]
    3d18:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3d1c:	f900369f 	str	xzr, [x20, #104]
    3d20:	34000140 	cbz	w0, 3d48 <fwp_free_zombie+0x98>
    3d24:	7100041f 	cmp	w0, #0x1
    3d28:	54000080 	b.eq	3d38 <fwp_free_zombie+0x88>  // b.none
    3d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d34:	d65f03c0 	ret
    3d38:	aa1303e0 	mov	x0, x19
    3d3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d44:	17ffff9b 	b	3bb0 <fwp_task_dispose>
    3d48:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xc70>
    3d4c:	9115c082 	add	x2, x4, #0x570
    3d50:	f949d841 	ldr	x1, [x2, #5040]
    3d54:	f949ec40 	ldr	x0, [x2, #5080]
    3d58:	cb010261 	sub	x1, x19, x1
    3d5c:	eb00403f 	cmp	x1, x0, lsl #16
    3d60:	54fffe62 	b.cs	3d2c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3d64:	d350fc20 	lsr	x0, x1, #16
    3d68:	f949fc43 	ldr	x3, [x2, #5112]
    3d6c:	8b000800 	add	x0, x0, x0, lsl #2
    3d70:	d37df000 	lsl	x0, x0, #3
    3d74:	8b000062 	add	x2, x3, x0
    3d78:	f9401054 	ldr	x20, [x2, #32]
    3d7c:	b4fffd94 	cbz	x20, 3d2c <fwp_free_zombie+0x7c>
    3d80:	38606860 	ldrb	w0, [x3, x0]
    3d84:	7100081f 	cmp	w0, #0x2
    3d88:	54000360 	b.eq	3df4 <fwp_free_zombie+0x144>  // b.none
    3d8c:	7100041f 	cmp	w0, #0x1
    3d90:	54fffce1 	b.ne	3d2c <fwp_free_zombie+0x7c>  // b.any
    3d94:	29430043 	ldp	w3, w0, [x2, #24]
    3d98:	92403c21 	and	x1, x1, #0xffff
    3d9c:	9b037c21 	mul	x1, x1, x3
    3da0:	d360fc21 	lsr	x1, x1, #32
    3da4:	eb00003f 	cmp	x1, x0
    3da8:	54fffc22 	b.cs	3d2c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3dac:	8b010294 	add	x20, x20, x1
    3db0:	39400280 	ldrb	w0, [x20]
    3db4:	34fffbc0 	cbz	w0, 3d2c <fwp_free_zombie+0x7c>
    3db8:	7100041f 	cmp	w0, #0x1
    3dbc:	54fffbe0 	b.eq	3d38 <fwp_free_zombie+0x88>  // b.none
    3dc0:	7103fc1f 	cmp	w0, #0xff
    3dc4:	540001e0 	b.eq	3e00 <fwp_free_zombie+0x150>  // b.none
    3dc8:	51000400 	sub	w0, w0, #0x1
    3dcc:	39000280 	strb	w0, [x20]
    3dd0:	17ffffd7 	b	3d2c <fwp_free_zombie+0x7c>
    3dd4:	f9400e61 	ldr	x1, [x19, #24]
    3dd8:	97fff612 	bl	1620 <munmap@plt>
    3ddc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3de0:	a9530261 	ldp	x1, x0, [x19, #304]
    3de4:	b5fff901 	cbnz	x1, 3d04 <fwp_free_zombie+0x54>
    3de8:	91024282 	add	x2, x20, #0x90
    3dec:	f9014040 	str	x0, [x2, #640]
    3df0:	17ffffc6 	b	3d08 <fwp_free_zombie+0x58>
    3df4:	72003c3f 	tst	w1, #0xffff
    3df8:	54fff9a1 	b.ne	3d2c <fwp_free_zombie+0x7c>  // b.any
    3dfc:	17ffffed 	b	3db0 <fwp_free_zombie+0x100>
    3e00:	ca544680 	eor	x0, x20, x20, lsr #17
    3e04:	9115c084 	add	x4, x4, #0x570
    3e08:	ca402400 	eor	x0, x0, x0, lsr #9
    3e0c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3e10:	f94a2400 	ldr	x0, [x0, #5192]
    3e14:	b5000080 	cbnz	x0, 3e24 <fwp_free_zombie+0x174>
    3e18:	14000010 	b	3e58 <fwp_free_zombie+0x1a8>
    3e1c:	f9400800 	ldr	x0, [x0, #16]
    3e20:	b40001c0 	cbz	x0, 3e58 <fwp_free_zombie+0x1a8>
    3e24:	f9400001 	ldr	x1, [x0]
    3e28:	eb14003f 	cmp	x1, x20
    3e2c:	54ffff81 	b.ne	3e1c <fwp_free_zombie+0x16c>  // b.any
    3e30:	f9400401 	ldr	x1, [x0, #8]
    3e34:	d1000421 	sub	x1, x1, #0x1
    3e38:	f9000401 	str	x1, [x0, #8]
    3e3c:	f103f83f 	cmp	x1, #0xfe
    3e40:	54fff761 	b.ne	3d2c <fwp_free_zombie+0x7c>  // b.any
    3e44:	aa1403e0 	mov	x0, x20
    3e48:	97fffbcf 	bl	2d84 <fwp_rc_forget_slot>
    3e4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3e50:	39000280 	strb	w0, [x20]
    3e54:	17ffffb6 	b	3d2c <fwp_free_zombie+0x7c>
    3e58:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3e5c:	911c6000 	add	x0, x0, #0x718
    3e60:	97fff908 	bl	2280 <fwp_trap>

0000000000003e64 <fwp_block>:
    3e64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e68:	910003fd 	mov	x29, sp
    3e6c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e70:	b00000f3 	adrp	x19, 20000 <__data_start>
    3e74:	91024274 	add	x20, x19, #0x90
    3e78:	f9401a82 	ldr	x2, [x20, #48]
    3e7c:	b4000622 	cbz	x2, 3f40 <fwp_block+0xdc>
    3e80:	91024261 	add	x1, x19, #0x90
    3e84:	f9408040 	ldr	x0, [x2, #256]
    3e88:	f9001820 	str	x0, [x1, #48]
    3e8c:	b4000680 	cbz	x0, 3f5c <fwp_block+0xf8>
    3e90:	91024263 	add	x3, x19, #0x90
    3e94:	3901505f 	strb	wzr, [x2, #84]
    3e98:	f9400464 	ldr	x4, [x3, #8]
    3e9c:	eb02009f 	cmp	x4, x2
    3ea0:	54000440 	b.eq	3f28 <fwp_block+0xc4>  // b.none
    3ea4:	f9414465 	ldr	x5, [x3, #648]
    3ea8:	f9000462 	str	x2, [x3, #8]
    3eac:	f9400441 	ldr	x1, [x2, #8]
    3eb0:	f9004885 	str	x5, [x4, #144]
    3eb4:	f9414865 	ldr	x5, [x3, #656]
    3eb8:	f9004c85 	str	x5, [x4, #152]
    3ebc:	f9414c65 	ldr	x5, [x3, #664]
    3ec0:	f9005085 	str	x5, [x4, #160]
    3ec4:	f9415065 	ldr	x5, [x3, #672]
    3ec8:	f9005485 	str	x5, [x4, #168]
    3ecc:	f9415465 	ldr	x5, [x3, #680]
    3ed0:	f9005885 	str	x5, [x4, #176]
    3ed4:	f9415865 	ldr	x5, [x3, #688]
    3ed8:	f9005c85 	str	x5, [x4, #184]
    3edc:	f9415c65 	ldr	x5, [x3, #696]
    3ee0:	f9006085 	str	x5, [x4, #192]
    3ee4:	f9400480 	ldr	x0, [x4, #8]
    3ee8:	f9404844 	ldr	x4, [x2, #144]
    3eec:	f9014464 	str	x4, [x3, #648]
    3ef0:	f9404c44 	ldr	x4, [x2, #152]
    3ef4:	f9014864 	str	x4, [x3, #656]
    3ef8:	f9405044 	ldr	x4, [x2, #160]
    3efc:	f9014c64 	str	x4, [x3, #664]
    3f00:	f9405444 	ldr	x4, [x2, #168]
    3f04:	f9015064 	str	x4, [x3, #672]
    3f08:	f9405844 	ldr	x4, [x2, #176]
    3f0c:	f9015464 	str	x4, [x3, #680]
    3f10:	a94b8844 	ldp	x4, x2, [x2, #184]
    3f14:	f9015864 	str	x4, [x3, #688]
    3f18:	f9015c62 	str	x2, [x3, #696]
    3f1c:	97fff591 	bl	1560 <swapcontext@plt>
    3f20:	97ffff64 	bl	3cb0 <fwp_free_zombie>
    3f24:	d503201f 	nop
    3f28:	91024260 	add	x0, x19, #0x90
    3f2c:	b942c000 	ldr	w0, [x0, #704]
    3f30:	340001a0 	cbz	w0, 3f64 <fwp_block+0x100>
    3f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f38:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f3c:	d65f03c0 	ret
    3f40:	97fffb04 	bl	2b50 <fwp_poll_events>
    3f44:	f9401a82 	ldr	x2, [x20, #48]
    3f48:	b4ffffc2 	cbz	x2, 3f40 <fwp_block+0xdc>
    3f4c:	91024261 	add	x1, x19, #0x90
    3f50:	f9408040 	ldr	x0, [x2, #256]
    3f54:	f9001820 	str	x0, [x1, #48]
    3f58:	b5fff9c0 	cbnz	x0, 3e90 <fwp_block+0x2c>
    3f5c:	f900143f 	str	xzr, [x1, #40]
    3f60:	17ffffcc 	b	3e90 <fwp_block+0x2c>
    3f64:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3f68:	911d4000 	add	x0, x0, #0x750
    3f6c:	97fff5c9 	bl	1690 <getenv@plt>
    3f70:	5284e202 	mov	w2, #0x2710                	// #10000
    3f74:	b4000060 	cbz	x0, 3f80 <fwp_block+0x11c>
    3f78:	39400001 	ldrb	w1, [x0]
    3f7c:	350000c1 	cbnz	w1, 3f94 <fwp_block+0x130>
    3f80:	91024273 	add	x19, x19, #0x90
    3f84:	b902c262 	str	w2, [x19, #704]
    3f88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f90:	d65f03c0 	ret
    3f94:	52800142 	mov	w2, #0xa                   	// #10
    3f98:	d2800001 	mov	x1, #0x0                   	// #0
    3f9c:	97fff50d 	bl	13d0 <strtoll@plt>
    3fa0:	d1000403 	sub	x3, x0, #0x1
    3fa4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3fa8:	eb02007f 	cmp	x3, x2
    3fac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3fb0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3fb4:	17fffff3 	b	3f80 <fwp_block+0x11c>
    3fb8:	d503201f 	nop
    3fbc:	d503201f 	nop

0000000000003fc0 <fwp_write.constprop.0>:
    3fc0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3fc4:	910003fd 	mov	x29, sp
    3fc8:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14718>
    3fcc:	f947f463 	ldr	x3, [x3, #4072]
    3fd0:	a90153f3 	stp	x19, x20, [sp, #16]
    3fd4:	d10943ff 	sub	sp, sp, #0x250
    3fd8:	aa0003f4 	mov	x20, x0
    3fdc:	b9400040 	ldr	w0, [x2]
    3fe0:	aa0103f3 	mov	x19, x1
    3fe4:	f9400061 	ldr	x1, [x3]
    3fe8:	f90127e1 	str	x1, [sp, #584]
    3fec:	d2800001 	mov	x1, #0x0                   	// #0
    3ff0:	7100641f 	cmp	w0, #0x19
    3ff4:	540003e8 	b.hi	4070 <fwp_write.constprop.0+0xb0>  // b.pmore
    3ff8:	d0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    3ffc:	912b4021 	add	x1, x1, #0xad0
    4000:	f9013bf5 	str	x21, [sp, #624]
    4004:	f9013ff6 	str	x22, [sp, #632]
    4008:	f90153fb 	str	x27, [sp, #672]
    400c:	f90157fc 	str	x28, [sp, #680]
    4010:	aa0203fc 	mov	x28, x2
    4014:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    4018:	10000062 	adr	x2, 4024 <fwp_write.constprop.0+0x64>
    401c:	8b21a841 	add	x1, x2, w1, sxth #2
    4020:	d61f0020 	br	x1
    4024:	910123e0 	add	x0, sp, #0x48
    4028:	aa1303e5 	mov	x5, x19
    402c:	b0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    4030:	aa0003f3 	mov	x19, x0
    4034:	911e6084 	add	x4, x4, #0x798
    4038:	d2804003 	mov	x3, #0x200                 	// #512
    403c:	aa0303e1 	mov	x1, x3
    4040:	52800042 	mov	w2, #0x2                   	// #2
    4044:	97fff50b 	bl	1470 <__snprintf_chk@plt>
    4048:	aa1303e0 	mov	x0, x19
    404c:	97fff4d1 	bl	1390 <strlen@plt>
    4050:	aa1303e1 	mov	x1, x19
    4054:	aa0003e2 	mov	x2, x0
    4058:	aa1403e0 	mov	x0, x20
    405c:	97fff82d 	bl	2110 <buf_put>
    4060:	f9413bf5 	ldr	x21, [sp, #624]
    4064:	f9413ff6 	ldr	x22, [sp, #632]
    4068:	f94153fb 	ldr	x27, [sp, #672]
    406c:	f94157fc 	ldr	x28, [sp, #680]
    4070:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    4074:	f947f400 	ldr	x0, [x0, #4072]
    4078:	f94127e2 	ldr	x2, [sp, #584]
    407c:	f9400001 	ldr	x1, [x0]
    4080:	eb010042 	subs	x2, x2, x1
    4084:	d2800001 	mov	x1, #0x0                   	// #0
    4088:	540074a1 	b.ne	4f1c <fwp_write.constprop.0+0xf5c>  // b.any
    408c:	910943ff 	add	sp, sp, #0x250
    4090:	a94153f3 	ldp	x19, x20, [sp, #16]
    4094:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4098:	d65f03c0 	ret
    409c:	910123e0 	add	x0, sp, #0x48
    40a0:	aa1303e5 	mov	x5, x19
    40a4:	b0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    40a8:	aa0003f3 	mov	x19, x0
    40ac:	911e4084 	add	x4, x4, #0x790
    40b0:	d2804003 	mov	x3, #0x200                 	// #512
    40b4:	17ffffe2 	b	403c <fwp_write.constprop.0+0x7c>
    40b8:	71004c1f 	cmp	w0, #0x13
    40bc:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    40c0:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    40c4:	911e2021 	add	x1, x1, #0x788
    40c8:	911e0000 	add	x0, x0, #0x780
    40cc:	d2800082 	mov	x2, #0x4                   	// #4
    40d0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    40d4:	aa1403e0 	mov	x0, x20
    40d8:	f90143f7 	str	x23, [sp, #640]
    40dc:	d2800016 	mov	x22, #0x0                   	// #0
    40e0:	f90147f8 	str	x24, [sp, #648]
    40e4:	97fff80b 	bl	2110 <buf_put>
    40e8:	f9400260 	ldr	x0, [x19]
    40ec:	b0000037 	adrp	x23, 9000 <__divti3+0x2c0>
    40f0:	d2800015 	mov	x21, #0x0                   	// #0
    40f4:	912022f7 	add	x23, x23, #0x808
    40f8:	b4004e40 	cbz	x0, 4ac0 <fwp_write.constprop.0+0xb00>
    40fc:	b9400381 	ldr	w1, [x28]
    4100:	aa1403e0 	mov	x0, x20
    4104:	f9401f82 	ldr	x2, [x28, #56]
    4108:	71004c3f 	cmp	w1, #0x13
    410c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4110:	8b010e61 	add	x1, x19, x1, lsl #3
    4114:	f9400421 	ldr	x1, [x1, #8]
    4118:	97ffffaa 	bl	3fc0 <fwp_write.constprop.0>
    411c:	b9400380 	ldr	w0, [x28]
    4120:	7100481f 	cmp	w0, #0x12
    4124:	540050c0 	b.eq	4b3c <fwp_write.constprop.0+0xb7c>  // b.none
    4128:	f9400260 	ldr	x0, [x19]
    412c:	910006b5 	add	x21, x21, #0x1
    4130:	91000ad6 	add	x22, x22, #0x2
    4134:	eb0002bf 	cmp	x21, x0
    4138:	54004c42 	b.cs	4ac0 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    413c:	aa1703e1 	mov	x1, x23
    4140:	aa1403e0 	mov	x0, x20
    4144:	d2800042 	mov	x2, #0x2                   	// #2
    4148:	97fff7f2 	bl	2110 <buf_put>
    414c:	17ffffec 	b	40fc <fwp_write.constprop.0+0x13c>
    4150:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4154:	911f0021 	add	x1, x1, #0x7c0
    4158:	d28000c2 	mov	x2, #0x6                   	// #6
    415c:	aa1403e0 	mov	x0, x20
    4160:	91004273 	add	x19, x19, #0x10
    4164:	97fff7eb 	bl	2110 <buf_put>
    4168:	aa1303e0 	mov	x0, x19
    416c:	97fff489 	bl	1390 <strlen@plt>
    4170:	aa1303e1 	mov	x1, x19
    4174:	aa0003e2 	mov	x2, x0
    4178:	aa1403e0 	mov	x0, x20
    417c:	97fff7e5 	bl	2110 <buf_put>
    4180:	528007c3 	mov	w3, #0x3e                  	// #62
    4184:	aa1403e0 	mov	x0, x20
    4188:	91001fe1 	add	x1, sp, #0x7
    418c:	d2800022 	mov	x2, #0x1                   	// #1
    4190:	39001fe3 	strb	w3, [sp, #7]
    4194:	17ffffb2 	b	405c <fwp_write.constprop.0+0x9c>
    4198:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    419c:	f947f400 	ldr	x0, [x0, #4072]
    41a0:	f94127e2 	ldr	x2, [sp, #584]
    41a4:	f9400001 	ldr	x1, [x0]
    41a8:	eb010042 	subs	x2, x2, x1
    41ac:	d2800001 	mov	x1, #0x0                   	// #0
    41b0:	54006cc1 	b.ne	4f48 <fwp_write.constprop.0+0xf88>  // b.any
    41b4:	f9413bf5 	ldr	x21, [sp, #624]
    41b8:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    41bc:	f9413ff6 	ldr	x22, [sp, #632]
    41c0:	aa1403e0 	mov	x0, x20
    41c4:	911e8021 	add	x1, x1, #0x7a0
    41c8:	d2800142 	mov	x2, #0xa                   	// #10
    41cc:	f94153fb 	ldr	x27, [sp, #672]
    41d0:	f94157fc 	ldr	x28, [sp, #680]
    41d4:	910943ff 	add	sp, sp, #0x250
    41d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41dc:	a8c77bfd 	ldp	x29, x30, [sp], #112
    41e0:	17fff7cc 	b	2110 <buf_put>
    41e4:	f9400796 	ldr	x22, [x28, #8]
    41e8:	f90143f7 	str	x23, [sp, #640]
    41ec:	f90147f8 	str	x24, [sp, #648]
    41f0:	b4005816 	cbz	x22, 4cf0 <fwp_write.constprop.0+0xd30>
    41f4:	aa1603e0 	mov	x0, x22
    41f8:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    41fc:	91208021 	add	x1, x1, #0x820
    4200:	97fff4e0 	bl	1580 <strcmp@plt>
    4204:	2a0003f5 	mov	w21, w0
    4208:	34005ce0 	cbz	w0, 4da4 <fwp_write.constprop.0+0xde4>
    420c:	aa1603e0 	mov	x0, x22
    4210:	97fff460 	bl	1390 <strlen@plt>
    4214:	aa1603e1 	mov	x1, x22
    4218:	aa0003e2 	mov	x2, x0
    421c:	aa1403e0 	mov	x0, x20
    4220:	97fff7bc 	bl	2110 <buf_put>
    4224:	52800403 	mov	w3, #0x20                  	// #32
    4228:	91001ff5 	add	x21, sp, #0x7
    422c:	aa1503e1 	mov	x1, x21
    4230:	aa1403e0 	mov	x0, x20
    4234:	d2800022 	mov	x2, #0x1                   	// #1
    4238:	39001fe3 	strb	w3, [sp, #7]
    423c:	97fff7b5 	bl	2110 <buf_put>
    4240:	52800f63 	mov	w3, #0x7b                  	// #123
    4244:	aa1403e0 	mov	x0, x20
    4248:	aa1503e1 	mov	x1, x21
    424c:	d2800022 	mov	x2, #0x1                   	// #1
    4250:	39001fe3 	strb	w3, [sp, #7]
    4254:	97fff7af 	bl	2110 <buf_put>
    4258:	b9401380 	ldr	w0, [x28, #16]
    425c:	52800018 	mov	w24, #0x0                   	// #0
    4260:	7100001f 	cmp	w0, #0x0
    4264:	54003d8d 	b.le	4a14 <fwp_write.constprop.0+0xa54>
    4268:	f9014bf9 	str	x25, [sp, #656]
    426c:	b0000039 	adrp	x25, 9000 <__divti3+0x2c0>
    4270:	91212339 	add	x25, x25, #0x848
    4274:	f9014ffa 	str	x26, [sp, #664]
    4278:	b000003a 	adrp	x26, 9000 <__divti3+0x2c0>
    427c:	9120235a 	add	x26, x26, #0x808
    4280:	91002276 	add	x22, x19, #0x8
    4284:	d2800013 	mov	x19, #0x0                   	// #0
    4288:	b5004413 	cbnz	x19, 4b08 <fwp_write.constprop.0+0xb48>
    428c:	d37df277 	lsl	x23, x19, #3
    4290:	34004238 	cbz	w24, 4ad4 <fwp_write.constprop.0+0xb14>
    4294:	f9401382 	ldr	x2, [x28, #32]
    4298:	aa1403e0 	mov	x0, x20
    429c:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    42a0:	91000673 	add	x19, x19, #0x1
    42a4:	f8776842 	ldr	x2, [x2, x23]
    42a8:	97ffff46 	bl	3fc0 <fwp_write.constprop.0>
    42ac:	b9401380 	ldr	w0, [x28, #16]
    42b0:	6b13001f 	cmp	w0, w19
    42b4:	54fffeac 	b.gt	4288 <fwp_write.constprop.0+0x2c8>
    42b8:	f9414bf9 	ldr	x25, [sp, #656]
    42bc:	f9414ffa 	ldr	x26, [sp, #664]
    42c0:	34003ab8 	cbz	w24, 4a14 <fwp_write.constprop.0+0xa54>
    42c4:	52800523 	mov	w3, #0x29                  	// #41
    42c8:	aa1503e1 	mov	x1, x21
    42cc:	aa1403e0 	mov	x0, x20
    42d0:	d2800022 	mov	x2, #0x1                   	// #1
    42d4:	39001fe3 	strb	w3, [sp, #7]
    42d8:	97fff78e 	bl	2110 <buf_put>
    42dc:	f9413bf5 	ldr	x21, [sp, #624]
    42e0:	f9413ff6 	ldr	x22, [sp, #632]
    42e4:	f94143f7 	ldr	x23, [sp, #640]
    42e8:	f94147f8 	ldr	x24, [sp, #648]
    42ec:	f94153fb 	ldr	x27, [sp, #672]
    42f0:	f94157fc 	ldr	x28, [sp, #680]
    42f4:	17ffff5f 	b	4070 <fwp_write.constprop.0+0xb0>
    42f8:	b9404b95 	ldr	w21, [x28, #72]
    42fc:	aa1403e0 	mov	x0, x20
    4300:	93407eb6 	sxtw	x22, w21
    4304:	91000ac1 	add	x1, x22, #0x2
    4308:	97fff74e 	bl	2040 <buf_grow>
    430c:	a9400281 	ldp	x1, x0, [x20]
    4310:	528e8603 	mov	w3, #0x7430                	// #29744
    4314:	78206823 	strh	w3, [x1, x0]
    4318:	8b000022 	add	x2, x1, x0
    431c:	710002bf 	cmp	w21, #0x0
    4320:	54003bcd 	b.le	4a98 <fwp_write.constprop.0+0xad8>
    4324:	110006a3 	add	w3, w21, #0x1
    4328:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    432c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4330:	91000449 	add	x9, x2, #0x1
    4334:	8b23c043 	add	x3, x2, w3, sxtw
    4338:	f28aaac6 	movk	x6, #0x5556
    433c:	f2955568 	movk	x8, #0xaaab
    4340:	1400000d 	b	4374 <fwp_write.constprop.0+0x3b4>
    4344:	d2800021 	mov	x1, #0x1                   	// #1
    4348:	528005a5 	mov	w5, #0x2d                  	// #45
    434c:	f100001f 	cmp	x0, #0x0
    4350:	9b467e60 	smulh	x0, x19, x6
    4354:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    4358:	381ff465 	strb	w5, [x3], #-1
    435c:	cb040000 	sub	x0, x0, x4
    4360:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4364:	cb020000 	sub	x0, x0, x2
    4368:	8b010013 	add	x19, x0, x1
    436c:	eb03013f 	cmp	x9, x3
    4370:	54003940 	b.eq	4a98 <fwp_write.constprop.0+0xad8>  // b.none
    4374:	9b467e60 	smulh	x0, x19, x6
    4378:	937ffe64 	asr	x4, x19, #63
    437c:	52800605 	mov	w5, #0x30                  	// #48
    4380:	cb040000 	sub	x0, x0, x4
    4384:	8b000400 	add	x0, x0, x0, lsl #1
    4388:	cb000260 	sub	x0, x19, x0
    438c:	91000c01 	add	x1, x0, #0x3
    4390:	9bc87c22 	umulh	x2, x1, x8
    4394:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    4398:	8b4204e2 	add	x2, x7, x2, lsr #1
    439c:	eb020021 	subs	x1, x1, x2
    43a0:	54fffd60 	b.eq	434c <fwp_write.constprop.0+0x38c>  // b.none
    43a4:	f100043f 	cmp	x1, #0x1
    43a8:	54fffce1 	b.ne	4344 <fwp_write.constprop.0+0x384>  // b.any
    43ac:	d2800001 	mov	x1, #0x0                   	// #0
    43b0:	52800565 	mov	w5, #0x2b                  	// #43
    43b4:	17ffffe6 	b	434c <fwp_write.constprop.0+0x38c>
    43b8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    43bc:	f947f400 	ldr	x0, [x0, #4072]
    43c0:	f94127e2 	ldr	x2, [sp, #584]
    43c4:	f9400001 	ldr	x1, [x0]
    43c8:	eb010042 	subs	x2, x2, x1
    43cc:	d2800001 	mov	x1, #0x0                   	// #0
    43d0:	54005bc1 	b.ne	4f48 <fwp_write.constprop.0+0xf88>  // b.any
    43d4:	f9413bf5 	ldr	x21, [sp, #624]
    43d8:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    43dc:	f9413ff6 	ldr	x22, [sp, #632]
    43e0:	aa1403e0 	mov	x0, x20
    43e4:	911ec021 	add	x1, x1, #0x7b0
    43e8:	d2800102 	mov	x2, #0x8                   	// #8
    43ec:	17ffff78 	b	41cc <fwp_write.constprop.0+0x20c>
    43f0:	aa1403e0 	mov	x0, x20
    43f4:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    43f8:	d28000c2 	mov	x2, #0x6                   	// #6
    43fc:	91204021 	add	x1, x1, #0x810
    4400:	97fff744 	bl	2110 <buf_put>
    4404:	d2800015 	mov	x21, #0x0                   	// #0
    4408:	f9400263 	ldr	x3, [x19]
    440c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4410:	540026a0 	b.eq	48e4 <fwp_write.constprop.0+0x924>  // b.none
    4414:	f9401f82 	ldr	x2, [x28, #56]
    4418:	f90143f7 	str	x23, [sp, #640]
    441c:	f90147f8 	str	x24, [sp, #648]
    4420:	d2800857 	mov	x23, #0x42                  	// #66
    4424:	f9014bf9 	str	x25, [sp, #656]
    4428:	b0000036 	adrp	x22, 9000 <__divti3+0x2c0>
    442c:	f9014ffa 	str	x26, [sp, #664]
    4430:	912022d6 	add	x22, x22, #0x808
    4434:	d2800038 	mov	x24, #0x1                   	// #1
    4438:	f2a18017 	movk	x23, #0xc00, lsl #16
    443c:	d2809099 	mov	x25, #0x484                 	// #1156
    4440:	b4000482 	cbz	x2, 44d0 <fwp_write.constprop.0+0x510>
    4444:	b9400040 	ldr	w0, [x2]
    4448:	7100701f 	cmp	w0, #0x1c
    444c:	540042e0 	b.eq	4ca8 <fwp_write.constprop.0+0xce8>  // b.none
    4450:	71006c1f 	cmp	w0, #0x1b
    4454:	540003e8 	b.hi	44d0 <fwp_write.constprop.0+0x510>  // b.pmore
    4458:	9ac02301 	lsl	x1, x24, x0
    445c:	ea17003f 	tst	x1, x23
    4460:	54003f21 	b.ne	4c44 <fwp_write.constprop.0+0xc84>  // b.any
    4464:	ea19003f 	tst	x1, x25
    4468:	54003da1 	b.ne	4c1c <fwp_write.constprop.0+0xc5c>  // b.any
    446c:	d2800425 	mov	x5, #0x21                  	// #33
    4470:	ea05003f 	tst	x1, x5
    4474:	540002e0 	b.eq	44d0 <fwp_write.constprop.0+0x510>  // b.none
    4478:	b7f84743 	tbnz	x3, #63, 4d60 <fwp_write.constprop.0+0xda0>
    447c:	91002261 	add	x1, x19, #0x8
    4480:	8b150021 	add	x1, x1, x21
    4484:	39400021 	ldrb	w1, [x1]
    4488:	7100001f 	cmp	w0, #0x0
    448c:	93401c23 	sxtb	x3, w1
    4490:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4494:	d503201f 	nop
    4498:	aa1403e0 	mov	x0, x20
    449c:	97fffec9 	bl	3fc0 <fwp_write.constprop.0>
    44a0:	f9400260 	ldr	x0, [x19]
    44a4:	910006b5 	add	x21, x21, #0x1
    44a8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    44ac:	eb0002bf 	cmp	x21, x0
    44b0:	54002122 	b.cs	48d4 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    44b4:	d2800042 	mov	x2, #0x2                   	// #2
    44b8:	aa1603e1 	mov	x1, x22
    44bc:	aa1403e0 	mov	x0, x20
    44c0:	97fff714 	bl	2110 <buf_put>
    44c4:	f9401f82 	ldr	x2, [x28, #56]
    44c8:	f9400263 	ldr	x3, [x19]
    44cc:	b5fffbc2 	cbnz	x2, 4444 <fwp_write.constprop.0+0x484>
    44d0:	d37df2a0 	lsl	x0, x21, #3
    44d4:	b7f83f43 	tbnz	x3, #63, 4cbc <fwp_write.constprop.0+0xcfc>
    44d8:	91002261 	add	x1, x19, #0x8
    44dc:	8b000020 	add	x0, x1, x0
    44e0:	f9400001 	ldr	x1, [x0]
    44e4:	17ffffed 	b	4498 <fwp_write.constprop.0+0x4d8>
    44e8:	a9400e62 	ldp	x2, x3, [x19]
    44ec:	b7f83ce3 	tbnz	x3, #63, 4c88 <fwp_write.constprop.0+0xcc8>
    44f0:	910123f5 	add	x21, sp, #0x48
    44f4:	aa1503e0 	mov	x0, x21
    44f8:	97fff55a 	bl	1a60 <fwp_fmt_u128>
    44fc:	aa1503e0 	mov	x0, x21
    4500:	97fff3a4 	bl	1390 <strlen@plt>
    4504:	aa1503e1 	mov	x1, x21
    4508:	aa0003e2 	mov	x2, x0
    450c:	17fffed3 	b	4058 <fwp_write.constprop.0+0x98>
    4510:	fd015be8 	str	d8, [sp, #688]
    4514:	1e270268 	fmov	s8, w19
    4518:	fd015fe9 	str	d9, [sp, #696]
    451c:	1e282100 	fcmp	s8, s8
    4520:	54004a66 	b.vs	4e6c <fwp_write.constprop.0+0xeac>
    4524:	1e20c101 	fabs	s1, s8
    4528:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    452c:	1e270000 	fmov	s0, w0
    4530:	1e202020 	fcmp	s1, s0
    4534:	540034ad 	b.le	4bc8 <fwp_write.constprop.0+0xc08>
    4538:	1e202118 	fcmpe	s8, #0.0
    453c:	b0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    4540:	9115c042 	add	x2, x2, #0x570
    4544:	910123f5 	add	x21, sp, #0x48
    4548:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    454c:	911d8021 	add	x1, x1, #0x760
    4550:	aa1503e0 	mov	x0, x21
    4554:	9a81c041 	csel	x1, x2, x1, gt
    4558:	97fff43a 	bl	1640 <strcpy@plt>
    455c:	d503201f 	nop
    4560:	aa1503e0 	mov	x0, x21
    4564:	97fff38b 	bl	1390 <strlen@plt>
    4568:	aa1503e1 	mov	x1, x21
    456c:	aa0003e2 	mov	x2, x0
    4570:	aa1403e0 	mov	x0, x20
    4574:	97fff6e7 	bl	2110 <buf_put>
    4578:	f9413bf5 	ldr	x21, [sp, #624]
    457c:	f9413ff6 	ldr	x22, [sp, #632]
    4580:	f94153fb 	ldr	x27, [sp, #672]
    4584:	f94157fc 	ldr	x28, [sp, #680]
    4588:	fd415be8 	ldr	d8, [sp, #688]
    458c:	fd415fe9 	ldr	d9, [sp, #696]
    4590:	17fffeb8 	b	4070 <fwp_write.constprop.0+0xb0>
    4594:	f90143f7 	str	x23, [sp, #640]
    4598:	52800443 	mov	w3, #0x22                  	// #34
    459c:	f90147f8 	str	x24, [sp, #648]
    45a0:	91001ff5 	add	x21, sp, #0x7
    45a4:	aa1503e1 	mov	x1, x21
    45a8:	aa1403e0 	mov	x0, x20
    45ac:	f8408677 	ldr	x23, [x19], #8
    45b0:	d2800022 	mov	x2, #0x1                   	// #1
    45b4:	39001fe3 	strb	w3, [sp, #7]
    45b8:	97fff6d6 	bl	2110 <buf_put>
    45bc:	8b1302f6 	add	x22, x23, x19
    45c0:	b4002657 	cbz	x23, 4a88 <fwp_write.constprop.0+0xac8>
    45c4:	b0000038 	adrp	x24, 9000 <__divti3+0x2c0>
    45c8:	911f2318 	add	x24, x24, #0x7c8
    45cc:	f9014bf9 	str	x25, [sp, #656]
    45d0:	b0000039 	adrp	x25, 9000 <__divti3+0x2c0>
    45d4:	911fa339 	add	x25, x25, #0x7e8
    45d8:	f9014ffa 	str	x26, [sp, #664]
    45dc:	1400000e 	b	4614 <fwp_write.constprop.0+0x654>
    45e0:	710024bf 	cmp	w5, #0x9
    45e4:	54002380 	b.eq	4a54 <fwp_write.constprop.0+0xa94>  // b.none
    45e8:	710028bf 	cmp	w5, #0xa
    45ec:	54002be1 	b.ne	4b68 <fwp_write.constprop.0+0xba8>  // b.any
    45f0:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    45f4:	aa1403e0 	mov	x0, x20
    45f8:	911f6021 	add	x1, x1, #0x7d8
    45fc:	d2800042 	mov	x2, #0x2                   	// #2
    4600:	97fff6c4 	bl	2110 <buf_put>
    4604:	d503201f 	nop
    4608:	91000673 	add	x19, x19, #0x1
    460c:	eb16027f 	cmp	x19, x22
    4610:	54002380 	b.eq	4a80 <fwp_write.constprop.0+0xac0>  // b.none
    4614:	39400265 	ldrb	w5, [x19]
    4618:	710034bf 	cmp	w5, #0xd
    461c:	54002120 	b.eq	4a40 <fwp_write.constprop.0+0xa80>  // b.none
    4620:	54fffe09 	b.ls	45e0 <fwp_write.constprop.0+0x620>  // b.plast
    4624:	710088bf 	cmp	w5, #0x22
    4628:	54002220 	b.eq	4a6c <fwp_write.constprop.0+0xaac>  // b.none
    462c:	710170bf 	cmp	w5, #0x5c
    4630:	54002ba1 	b.ne	4ba4 <fwp_write.constprop.0+0xbe4>  // b.any
    4634:	aa1403e0 	mov	x0, x20
    4638:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    463c:	d2800042 	mov	x2, #0x2                   	// #2
    4640:	911f4021 	add	x1, x1, #0x7d0
    4644:	97fff6b3 	bl	2110 <buf_put>
    4648:	17fffff0 	b	4608 <fwp_write.constprop.0+0x648>
    464c:	fd015be8 	str	d8, [sp, #688]
    4650:	9e670268 	fmov	d8, x19
    4654:	fd015fe9 	str	d9, [sp, #696]
    4658:	1e682100 	fcmp	d8, d8
    465c:	54004086 	b.vs	4e6c <fwp_write.constprop.0+0xeac>
    4660:	1e60c101 	fabs	d1, d8
    4664:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    4668:	9e670000 	fmov	d0, x0
    466c:	910123f5 	add	x21, sp, #0x48
    4670:	52800033 	mov	w19, #0x1                   	// #1
    4674:	1e602020 	fcmp	d1, d0
    4678:	540001ad 	b.le	46ac <fwp_write.constprop.0+0x6ec>
    467c:	1e602118 	fcmpe	d8, #0.0
    4680:	b0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    4684:	9115c042 	add	x2, x2, #0x570
    4688:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    468c:	911d8021 	add	x1, x1, #0x760
    4690:	aa1503e0 	mov	x0, x21
    4694:	9a81c041 	csel	x1, x2, x1, gt
    4698:	97fff3ea 	bl	1640 <strcpy@plt>
    469c:	17ffffb1 	b	4560 <fwp_write.constprop.0+0x5a0>
    46a0:	11000673 	add	w19, w19, #0x1
    46a4:	71004a7f 	cmp	w19, #0x12
    46a8:	540031a0 	b.eq	4cdc <fwp_write.constprop.0+0xd1c>  // b.none
    46ac:	1e604100 	fmov	d0, d8
    46b0:	2a1303e1 	mov	w1, w19
    46b4:	aa1503e0 	mov	x0, x21
    46b8:	97fff72a 	bl	2360 <fwp_format_g.constprop.0>
    46bc:	aa1503e0 	mov	x0, x21
    46c0:	d2800001 	mov	x1, #0x0                   	// #0
    46c4:	97fff347 	bl	13e0 <strtod@plt>
    46c8:	1e602100 	fcmp	d8, d0
    46cc:	54fffea1 	b.ne	46a0 <fwp_write.constprop.0+0x6e0>  // b.any
    46d0:	aa1503e0 	mov	x0, x21
    46d4:	97fff6c8 	bl	21f4 <fwp_finish_float>
    46d8:	17ffffa2 	b	4560 <fwp_write.constprop.0+0x5a0>
    46dc:	a9400e62 	ldp	x2, x3, [x19]
    46e0:	910123f3 	add	x19, sp, #0x48
    46e4:	aa1303e0 	mov	x0, x19
    46e8:	97fff4de 	bl	1a60 <fwp_fmt_u128>
    46ec:	17fffe57 	b	4048 <fwp_write.constprop.0+0x88>
    46f0:	f90143f7 	str	x23, [sp, #640]
    46f4:	f90147f8 	str	x24, [sp, #648]
    46f8:	2a1303f8 	mov	w24, w19
    46fc:	f9014bf9 	str	x25, [sp, #656]
    4700:	f9014ffa 	str	x26, [sp, #664]
    4704:	f13ffe7f 	cmp	x19, #0xfff
    4708:	54000049 	b.ls	4710 <fwp_write.constprop.0+0x750>  // b.plast
    470c:	b9400278 	ldr	w24, [x19]
    4710:	f9400f80 	ldr	x0, [x28, #24]
    4714:	2a1803f5 	mov	w21, w24
    4718:	d37d7f18 	ubfiz	x24, x24, #3, #32
    471c:	d37ef6b9 	lsl	x25, x21, #2
    4720:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4724:	aa1603e0 	mov	x0, x22
    4728:	97fff31a 	bl	1390 <strlen@plt>
    472c:	aa1603e1 	mov	x1, x22
    4730:	aa0003e2 	mov	x2, x0
    4734:	aa1403e0 	mov	x0, x20
    4738:	97fff676 	bl	2110 <buf_put>
    473c:	f9401780 	ldr	x0, [x28, #40]
    4740:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4744:	7100001f 	cmp	w0, #0x0
    4748:	5400064d 	b.le	4810 <fwp_write.constprop.0+0x850>
    474c:	91002276 	add	x22, x19, #0x8
    4750:	91001ff5 	add	x21, sp, #0x7
    4754:	d280001b 	mov	x27, #0x0                   	// #0
    4758:	5280041a 	mov	w26, #0x20                  	// #32
    475c:	f9401b80 	ldr	x0, [x28, #48]
    4760:	aa1503e1 	mov	x1, x21
    4764:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    4768:	d2800022 	mov	x2, #0x1                   	// #1
    476c:	f8786805 	ldr	x5, [x0, x24]
    4770:	aa1403e0 	mov	x0, x20
    4774:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    4778:	39001ffa 	strb	w26, [sp, #7]
    477c:	97fff665 	bl	2110 <buf_put>
    4780:	f13ffeff 	cmp	x23, #0xfff
    4784:	b9400261 	ldr	w1, [x19]
    4788:	1a9f97e0 	cset	w0, hi	// hi = pmore
    478c:	7100383f 	cmp	w1, #0xe
    4790:	54000140 	b.eq	47b8 <fwp_write.constprop.0+0x7f8>  // b.none
    4794:	7100403f 	cmp	w1, #0x10
    4798:	54001c20 	b.eq	4b1c <fwp_write.constprop.0+0xb5c>  // b.none
    479c:	7100283f 	cmp	w1, #0xa
    47a0:	540026e0 	b.eq	4c7c <fwp_write.constprop.0+0xcbc>  // b.none
    47a4:	540013cc 	b.gt	4a1c <fwp_write.constprop.0+0xa5c>
    47a8:	71000c3f 	cmp	w1, #0x3
    47ac:	540025ec 	b.gt	4c68 <fwp_write.constprop.0+0xca8>
    47b0:	d37ffee0 	lsr	x0, x23, #63
    47b4:	37f813c1 	tbnz	w1, #31, 4a2c <fwp_write.constprop.0+0xa6c>
    47b8:	340013a0 	cbz	w0, 4a2c <fwp_write.constprop.0+0xa6c>
    47bc:	52800503 	mov	w3, #0x28                  	// #40
    47c0:	aa1503e1 	mov	x1, x21
    47c4:	aa1403e0 	mov	x0, x20
    47c8:	d2800022 	mov	x2, #0x1                   	// #1
    47cc:	39001fe3 	strb	w3, [sp, #7]
    47d0:	97fff650 	bl	2110 <buf_put>
    47d4:	aa1303e2 	mov	x2, x19
    47d8:	aa1703e1 	mov	x1, x23
    47dc:	aa1403e0 	mov	x0, x20
    47e0:	97fffdf8 	bl	3fc0 <fwp_write.constprop.0>
    47e4:	52800523 	mov	w3, #0x29                  	// #41
    47e8:	aa1503e1 	mov	x1, x21
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	d2800022 	mov	x2, #0x1                   	// #1
    47f4:	39001fe3 	strb	w3, [sp, #7]
    47f8:	97fff646 	bl	2110 <buf_put>
    47fc:	f9401780 	ldr	x0, [x28, #40]
    4800:	9100077b 	add	x27, x27, #0x1
    4804:	b8796800 	ldr	w0, [x0, x25]
    4808:	6b1b001f 	cmp	w0, w27
    480c:	54fffa8c 	b.gt	475c <fwp_write.constprop.0+0x79c>
    4810:	f9413bf5 	ldr	x21, [sp, #624]
    4814:	f9413ff6 	ldr	x22, [sp, #632]
    4818:	f94143f7 	ldr	x23, [sp, #640]
    481c:	f94147f8 	ldr	x24, [sp, #648]
    4820:	f9414bf9 	ldr	x25, [sp, #656]
    4824:	f9414ffa 	ldr	x26, [sp, #664]
    4828:	f94153fb 	ldr	x27, [sp, #672]
    482c:	f94157fc 	ldr	x28, [sp, #680]
    4830:	17fffe10 	b	4070 <fwp_write.constprop.0+0xb0>
    4834:	aa1403e0 	mov	x0, x20
    4838:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    483c:	d28000c2 	mov	x2, #0x6                   	// #6
    4840:	911fe021 	add	x1, x1, #0x7f8
    4844:	97fff633 	bl	2110 <buf_put>
    4848:	f9400260 	ldr	x0, [x19]
    484c:	b40004c0 	cbz	x0, 48e4 <fwp_write.constprop.0+0x924>
    4850:	910123f5 	add	x21, sp, #0x48
    4854:	91002276 	add	x22, x19, #0x8
    4858:	f90143f7 	str	x23, [sp, #640]
    485c:	d2800017 	mov	x23, #0x0                   	// #0
    4860:	f90147f8 	str	x24, [sp, #648]
    4864:	b0000038 	adrp	x24, 9000 <__divti3+0x2c0>
    4868:	91200318 	add	x24, x24, #0x800
    486c:	f9014bf9 	str	x25, [sp, #656]
    4870:	b0000039 	adrp	x25, 9000 <__divti3+0x2c0>
    4874:	91202339 	add	x25, x25, #0x808
    4878:	f9014ffa 	str	x26, [sp, #664]
    487c:	14000005 	b	4890 <fwp_write.constprop.0+0x8d0>
    4880:	aa1903e1 	mov	x1, x25
    4884:	aa1403e0 	mov	x0, x20
    4888:	d2800042 	mov	x2, #0x2                   	// #2
    488c:	97fff621 	bl	2110 <buf_put>
    4890:	38776ac5 	ldrb	w5, [x22, x23]
    4894:	d2804003 	mov	x3, #0x200                 	// #512
    4898:	aa1803e4 	mov	x4, x24
    489c:	aa0303e1 	mov	x1, x3
    48a0:	52800042 	mov	w2, #0x2                   	// #2
    48a4:	aa1503e0 	mov	x0, x21
    48a8:	910006f7 	add	x23, x23, #0x1
    48ac:	97fff2f1 	bl	1470 <__snprintf_chk@plt>
    48b0:	aa1503e0 	mov	x0, x21
    48b4:	97fff2b7 	bl	1390 <strlen@plt>
    48b8:	aa1503e1 	mov	x1, x21
    48bc:	aa0003e2 	mov	x2, x0
    48c0:	aa1403e0 	mov	x0, x20
    48c4:	97fff613 	bl	2110 <buf_put>
    48c8:	f9400260 	ldr	x0, [x19]
    48cc:	eb0002ff 	cmp	x23, x0
    48d0:	54fffd83 	b.cc	4880 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    48d4:	f94143f7 	ldr	x23, [sp, #640]
    48d8:	f94147f8 	ldr	x24, [sp, #648]
    48dc:	f9414bf9 	ldr	x25, [sp, #656]
    48e0:	f9414ffa 	ldr	x26, [sp, #664]
    48e4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48e8:	aa1403e0 	mov	x0, x20
    48ec:	91001fe1 	add	x1, sp, #0x7
    48f0:	d2800022 	mov	x2, #0x1                   	// #1
    48f4:	39001fe3 	strb	w3, [sp, #7]
    48f8:	17fffdd9 	b	405c <fwp_write.constprop.0+0x9c>
    48fc:	52800b63 	mov	w3, #0x5b                  	// #91
    4900:	91001ff5 	add	x21, sp, #0x7
    4904:	aa1503e1 	mov	x1, x21
    4908:	aa1403e0 	mov	x0, x20
    490c:	d2800022 	mov	x2, #0x1                   	// #1
    4910:	b0000036 	adrp	x22, 9000 <__divti3+0x2c0>
    4914:	912022d6 	add	x22, x22, #0x808
    4918:	39001fe3 	strb	w3, [sp, #7]
    491c:	97fff5fd 	bl	2110 <buf_put>
    4920:	b4000233 	cbz	x19, 4964 <fwp_write.constprop.0+0x9a4>
    4924:	f9400661 	ldr	x1, [x19, #8]
    4928:	aa1403e0 	mov	x0, x20
    492c:	f9401f82 	ldr	x2, [x28, #56]
    4930:	97fffda4 	bl	3fc0 <fwp_write.constprop.0>
    4934:	f9400a73 	ldr	x19, [x19, #16]
    4938:	b4000173 	cbz	x19, 4964 <fwp_write.constprop.0+0x9a4>
    493c:	aa1603e1 	mov	x1, x22
    4940:	aa1403e0 	mov	x0, x20
    4944:	d2800042 	mov	x2, #0x2                   	// #2
    4948:	97fff5f2 	bl	2110 <buf_put>
    494c:	f9400661 	ldr	x1, [x19, #8]
    4950:	aa1403e0 	mov	x0, x20
    4954:	f9401f82 	ldr	x2, [x28, #56]
    4958:	97fffd9a 	bl	3fc0 <fwp_write.constprop.0>
    495c:	f9400a73 	ldr	x19, [x19, #16]
    4960:	b5fffef3 	cbnz	x19, 493c <fwp_write.constprop.0+0x97c>
    4964:	52800ba3 	mov	w3, #0x5d                  	// #93
    4968:	aa1503e1 	mov	x1, x21
    496c:	aa1403e0 	mov	x0, x20
    4970:	d2800022 	mov	x2, #0x1                   	// #1
    4974:	39001fe3 	strb	w3, [sp, #7]
    4978:	17fffdb9 	b	405c <fwp_write.constprop.0+0x9c>
    497c:	52800783 	mov	w3, #0x3c                  	// #60
    4980:	91001ff3 	add	x19, sp, #0x7
    4984:	aa1303e1 	mov	x1, x19
    4988:	d2800022 	mov	x2, #0x1                   	// #1
    498c:	aa1403e0 	mov	x0, x20
    4990:	39001fe3 	strb	w3, [sp, #7]
    4994:	97fff5df 	bl	2110 <buf_put>
    4998:	f9400795 	ldr	x21, [x28, #8]
    499c:	aa1503e0 	mov	x0, x21
    49a0:	97fff27c 	bl	1390 <strlen@plt>
    49a4:	aa1503e1 	mov	x1, x21
    49a8:	aa0003e2 	mov	x2, x0
    49ac:	aa1403e0 	mov	x0, x20
    49b0:	97fff5d8 	bl	2110 <buf_put>
    49b4:	528007c3 	mov	w3, #0x3e                  	// #62
    49b8:	aa1303e1 	mov	x1, x19
    49bc:	aa1403e0 	mov	x0, x20
    49c0:	d2800022 	mov	x2, #0x1                   	// #1
    49c4:	39001fe3 	strb	w3, [sp, #7]
    49c8:	17fffda5 	b	405c <fwp_write.constprop.0+0x9c>
    49cc:	f100067f 	cmp	x19, #0x1
    49d0:	540017e0 	b.eq	4ccc <fwp_write.constprop.0+0xd0c>  // b.none
    49d4:	b100067f 	cmn	x19, #0x1
    49d8:	54001b00 	b.eq	4d38 <fwp_write.constprop.0+0xd78>  // b.none
    49dc:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    49e0:	911de021 	add	x1, x1, #0x778
    49e4:	d2800022 	mov	x2, #0x1                   	// #1
    49e8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    49ec:	f947f400 	ldr	x0, [x0, #4072]
    49f0:	f94127e4 	ldr	x4, [sp, #584]
    49f4:	f9400003 	ldr	x3, [x0]
    49f8:	eb030084 	subs	x4, x4, x3
    49fc:	d2800003 	mov	x3, #0x0                   	// #0
    4a00:	54002a41 	b.ne	4f48 <fwp_write.constprop.0+0xf88>  // b.any
    4a04:	f9413bf5 	ldr	x21, [sp, #624]
    4a08:	aa1403e0 	mov	x0, x20
    4a0c:	f9413ff6 	ldr	x22, [sp, #632]
    4a10:	17fffdef 	b	41cc <fwp_write.constprop.0+0x20c>
    4a14:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a18:	17fffe2c 	b	42c8 <fwp_write.constprop.0+0x308>
    4a1c:	f10002ff 	cmp	x23, #0x0
    4a20:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4a24:	71002c3f 	cmp	w1, #0xb
    4a28:	54ffec80 	b.eq	47b8 <fwp_write.constprop.0+0x7f8>  // b.none
    4a2c:	aa1303e2 	mov	x2, x19
    4a30:	aa1703e1 	mov	x1, x23
    4a34:	aa1403e0 	mov	x0, x20
    4a38:	97fffd62 	bl	3fc0 <fwp_write.constprop.0>
    4a3c:	17ffff70 	b	47fc <fwp_write.constprop.0+0x83c>
    4a40:	aa1903e1 	mov	x1, x25
    4a44:	aa1403e0 	mov	x0, x20
    4a48:	d2800042 	mov	x2, #0x2                   	// #2
    4a4c:	97fff5b1 	bl	2110 <buf_put>
    4a50:	17fffeee 	b	4608 <fwp_write.constprop.0+0x648>
    4a54:	aa1403e0 	mov	x0, x20
    4a58:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4a5c:	d2800042 	mov	x2, #0x2                   	// #2
    4a60:	911f8021 	add	x1, x1, #0x7e0
    4a64:	97fff5ab 	bl	2110 <buf_put>
    4a68:	17fffee8 	b	4608 <fwp_write.constprop.0+0x648>
    4a6c:	aa1803e1 	mov	x1, x24
    4a70:	aa1403e0 	mov	x0, x20
    4a74:	d2800042 	mov	x2, #0x2                   	// #2
    4a78:	97fff5a6 	bl	2110 <buf_put>
    4a7c:	17fffee3 	b	4608 <fwp_write.constprop.0+0x648>
    4a80:	f9414bf9 	ldr	x25, [sp, #656]
    4a84:	f9414ffa 	ldr	x26, [sp, #664]
    4a88:	aa1503e1 	mov	x1, x21
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	52800443 	mov	w3, #0x22                  	// #34
    4a94:	17fffe0f 	b	42d0 <fwp_write.constprop.0+0x310>
    4a98:	a9400281 	ldp	x1, x0, [x20]
    4a9c:	91000800 	add	x0, x0, #0x2
    4aa0:	8b160000 	add	x0, x0, x22
    4aa4:	f9000680 	str	x0, [x20, #8]
    4aa8:	3820683f 	strb	wzr, [x1, x0]
    4aac:	f9413bf5 	ldr	x21, [sp, #624]
    4ab0:	f9413ff6 	ldr	x22, [sp, #632]
    4ab4:	f94153fb 	ldr	x27, [sp, #672]
    4ab8:	f94157fc 	ldr	x28, [sp, #680]
    4abc:	17fffd6d 	b	4070 <fwp_write.constprop.0+0xb0>
    4ac0:	aa1403e0 	mov	x0, x20
    4ac4:	91001fe1 	add	x1, sp, #0x7
    4ac8:	52800fa3 	mov	w3, #0x7d                  	// #125
    4acc:	d2800022 	mov	x2, #0x1                   	// #1
    4ad0:	17fffe01 	b	42d4 <fwp_write.constprop.0+0x314>
    4ad4:	f9400f80 	ldr	x0, [x28, #24]
    4ad8:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4adc:	aa1b03e0 	mov	x0, x27
    4ae0:	97fff22c 	bl	1390 <strlen@plt>
    4ae4:	aa1b03e1 	mov	x1, x27
    4ae8:	aa0003e2 	mov	x2, x0
    4aec:	aa1403e0 	mov	x0, x20
    4af0:	97fff588 	bl	2110 <buf_put>
    4af4:	aa1903e1 	mov	x1, x25
    4af8:	aa1403e0 	mov	x0, x20
    4afc:	d2800062 	mov	x2, #0x3                   	// #3
    4b00:	97fff584 	bl	2110 <buf_put>
    4b04:	17fffde4 	b	4294 <fwp_write.constprop.0+0x2d4>
    4b08:	aa1a03e1 	mov	x1, x26
    4b0c:	aa1403e0 	mov	x0, x20
    4b10:	d2800042 	mov	x2, #0x2                   	// #2
    4b14:	97fff57f 	bl	2110 <buf_put>
    4b18:	17fffddd 	b	428c <fwp_write.constprop.0+0x2cc>
    4b1c:	f9400660 	ldr	x0, [x19, #8]
    4b20:	b4fff860 	cbz	x0, 4a2c <fwp_write.constprop.0+0xa6c>
    4b24:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4b28:	91208021 	add	x1, x1, #0x820
    4b2c:	97fff295 	bl	1580 <strcmp@plt>
    4b30:	7100001f 	cmp	w0, #0x0
    4b34:	1a9f07e0 	cset	w0, ne	// ne = any
    4b38:	17ffff20 	b	47b8 <fwp_write.constprop.0+0x7f8>
    4b3c:	aa1403e0 	mov	x0, x20
    4b40:	d2800042 	mov	x2, #0x2                   	// #2
    4b44:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4b48:	91206021 	add	x1, x1, #0x818
    4b4c:	97fff571 	bl	2110 <buf_put>
    4b50:	91004261 	add	x1, x19, #0x10
    4b54:	aa1403e0 	mov	x0, x20
    4b58:	f9402382 	ldr	x2, [x28, #64]
    4b5c:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4b60:	97fffd18 	bl	3fc0 <fwp_write.constprop.0>
    4b64:	17fffd71 	b	4128 <fwp_write.constprop.0+0x168>
    4b68:	d2800203 	mov	x3, #0x10                  	// #16
    4b6c:	b0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    4b70:	aa0303e1 	mov	x1, x3
    4b74:	911fc084 	add	x4, x4, #0x7f0
    4b78:	910123f7 	add	x23, sp, #0x48
    4b7c:	52800042 	mov	w2, #0x2                   	// #2
    4b80:	aa1703e0 	mov	x0, x23
    4b84:	97fff23b 	bl	1470 <__snprintf_chk@plt>
    4b88:	aa1703e0 	mov	x0, x23
    4b8c:	97fff201 	bl	1390 <strlen@plt>
    4b90:	aa1703e1 	mov	x1, x23
    4b94:	aa0003e2 	mov	x2, x0
    4b98:	aa1403e0 	mov	x0, x20
    4b9c:	97fff55d 	bl	2110 <buf_put>
    4ba0:	17fffe9a 	b	4608 <fwp_write.constprop.0+0x648>
    4ba4:	7101fcbf 	cmp	w5, #0x7f
    4ba8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4bac:	54fffde9 	b.ls	4b68 <fwp_write.constprop.0+0xba8>  // b.plast
    4bb0:	aa1503e1 	mov	x1, x21
    4bb4:	aa1403e0 	mov	x0, x20
    4bb8:	d2800022 	mov	x2, #0x1                   	// #1
    4bbc:	39001fe5 	strb	w5, [sp, #7]
    4bc0:	97fff554 	bl	2110 <buf_put>
    4bc4:	17fffe91 	b	4608 <fwp_write.constprop.0+0x648>
    4bc8:	1e22c109 	fcvt	d9, s8
    4bcc:	910123f5 	add	x21, sp, #0x48
    4bd0:	52800033 	mov	w19, #0x1                   	// #1
    4bd4:	d503201f 	nop
    4bd8:	1e604120 	fmov	d0, d9
    4bdc:	2a1303e1 	mov	w1, w19
    4be0:	aa1503e0 	mov	x0, x21
    4be4:	97fff5df 	bl	2360 <fwp_format_g.constprop.0>
    4be8:	aa1503e0 	mov	x0, x21
    4bec:	d2800001 	mov	x1, #0x0                   	// #0
    4bf0:	97fff270 	bl	15b0 <strtof@plt>
    4bf4:	1e202100 	fcmp	s8, s0
    4bf8:	54ffd6c0 	b.eq	46d0 <fwp_write.constprop.0+0x710>  // b.none
    4bfc:	11000673 	add	w19, w19, #0x1
    4c00:	71002a7f 	cmp	w19, #0xa
    4c04:	54fffea1 	b.ne	4bd8 <fwp_write.constprop.0+0xc18>  // b.any
    4c08:	1e604120 	fmov	d0, d9
    4c0c:	aa1503e0 	mov	x0, x21
    4c10:	52800121 	mov	w1, #0x9                   	// #9
    4c14:	97fff5d3 	bl	2360 <fwp_format_g.constprop.0>
    4c18:	17fffeae 	b	46d0 <fwp_write.constprop.0+0x710>
    4c1c:	d37ef6a1 	lsl	x1, x21, #2
    4c20:	b7f809a3 	tbnz	x3, #63, 4d54 <fwp_write.constprop.0+0xd94>
    4c24:	91002263 	add	x3, x19, #0x8
    4c28:	8b010061 	add	x1, x3, x1
    4c2c:	b9400023 	ldr	w3, [x1]
    4c30:	7100081f 	cmp	w0, #0x2
    4c34:	2a0303e1 	mov	w1, w3
    4c38:	93407c63 	sxtw	x3, w3
    4c3c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c40:	17fffe16 	b	4498 <fwp_write.constprop.0+0x4d8>
    4c44:	d37ffaa1 	lsl	x1, x21, #1
    4c48:	b7f80803 	tbnz	x3, #63, 4d48 <fwp_write.constprop.0+0xd88>
    4c4c:	91002263 	add	x3, x19, #0x8
    4c50:	8b010061 	add	x1, x3, x1
    4c54:	79400021 	ldrh	w1, [x1]
    4c58:	7100041f 	cmp	w0, #0x1
    4c5c:	93403c23 	sxth	x3, w1
    4c60:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c64:	17fffe0d 	b	4498 <fwp_write.constprop.0+0x4d8>
    4c68:	7100103f 	cmp	w1, #0x4
    4c6c:	54ffee01 	b.ne	4a2c <fwp_write.constprop.0+0xa6c>  // b.any
    4c70:	f94006e0 	ldr	x0, [x23, #8]
    4c74:	d37ffc00 	lsr	x0, x0, #63
    4c78:	17fffed0 	b	47b8 <fwp_write.constprop.0+0x7f8>
    4c7c:	710002ff 	cmp	w23, #0x0
    4c80:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4c84:	17fffecd 	b	47b8 <fwp_write.constprop.0+0x7f8>
    4c88:	528005a1 	mov	w1, #0x2d                  	// #45
    4c8c:	eb0203e2 	negs	x2, x2
    4c90:	da0303e3 	ngc	x3, x3
    4c94:	910127e0 	add	x0, sp, #0x49
    4c98:	910123f5 	add	x21, sp, #0x48
    4c9c:	390123e1 	strb	w1, [sp, #72]
    4ca0:	97fff370 	bl	1a60 <fwp_fmt_u128>
    4ca4:	17fffe16 	b	44fc <fwp_write.constprop.0+0x53c>
    4ca8:	d37ceea1 	lsl	x1, x21, #4
    4cac:	b7f80da3 	tbnz	x3, #63, 4e60 <fwp_write.constprop.0+0xea0>
    4cb0:	91002260 	add	x0, x19, #0x8
    4cb4:	8b010001 	add	x1, x0, x1
    4cb8:	17fffdf8 	b	4498 <fwp_write.constprop.0+0x4d8>
    4cbc:	f9400a61 	ldr	x1, [x19, #16]
    4cc0:	8b010000 	add	x0, x0, x1
    4cc4:	f9400001 	ldr	x1, [x0]
    4cc8:	17fffdf4 	b	4498 <fwp_write.constprop.0+0x4d8>
    4ccc:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4cd0:	d2800042 	mov	x2, #0x2                   	// #2
    4cd4:	911da021 	add	x1, x1, #0x768
    4cd8:	17ffff44 	b	49e8 <fwp_write.constprop.0+0xa28>
    4cdc:	1e604100 	fmov	d0, d8
    4ce0:	aa1503e0 	mov	x0, x21
    4ce4:	52800221 	mov	w1, #0x11                  	// #17
    4ce8:	97fff59e 	bl	2360 <fwp_format_g.constprop.0>
    4cec:	17fffe79 	b	46d0 <fwp_write.constprop.0+0x710>
    4cf0:	b9401380 	ldr	w0, [x28, #16]
    4cf4:	350003c0 	cbnz	w0, 4d6c <fwp_write.constprop.0+0xdac>
    4cf8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    4cfc:	f947f400 	ldr	x0, [x0, #4072]
    4d00:	f94127e2 	ldr	x2, [sp, #584]
    4d04:	f9400001 	ldr	x1, [x0]
    4d08:	eb010042 	subs	x2, x2, x1
    4d0c:	d2800001 	mov	x1, #0x0                   	// #0
    4d10:	54001201 	b.ne	4f50 <fwp_write.constprop.0+0xf90>  // b.any
    4d14:	f9413bf5 	ldr	x21, [sp, #624]
    4d18:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4d1c:	f9413ff6 	ldr	x22, [sp, #632]
    4d20:	aa1403e0 	mov	x0, x20
    4d24:	f94143f7 	ldr	x23, [sp, #640]
    4d28:	91210021 	add	x1, x1, #0x840
    4d2c:	f94147f8 	ldr	x24, [sp, #648]
    4d30:	d2800042 	mov	x2, #0x2                   	// #2
    4d34:	17fffd26 	b	41cc <fwp_write.constprop.0+0x20c>
    4d38:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4d3c:	d2800042 	mov	x2, #0x2                   	// #2
    4d40:	911dc021 	add	x1, x1, #0x770
    4d44:	17ffff29 	b	49e8 <fwp_write.constprop.0+0xa28>
    4d48:	f9400a63 	ldr	x3, [x19, #16]
    4d4c:	8b030021 	add	x1, x1, x3
    4d50:	17ffffc1 	b	4c54 <fwp_write.constprop.0+0xc94>
    4d54:	f9400a63 	ldr	x3, [x19, #16]
    4d58:	8b030021 	add	x1, x1, x3
    4d5c:	17ffffb4 	b	4c2c <fwp_write.constprop.0+0xc6c>
    4d60:	f9400a61 	ldr	x1, [x19, #16]
    4d64:	8b0102a1 	add	x1, x21, x1
    4d68:	17fffdc7 	b	4484 <fwp_write.constprop.0+0x4c4>
    4d6c:	b9404b80 	ldr	w0, [x28, #72]
    4d70:	91001ff5 	add	x21, sp, #0x7
    4d74:	34ffa660 	cbz	w0, 4240 <fwp_write.constprop.0+0x280>
    4d78:	52800503 	mov	w3, #0x28                  	// #40
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	aa1503e1 	mov	x1, x21
    4d84:	d2800022 	mov	x2, #0x1                   	// #1
    4d88:	39001fe3 	strb	w3, [sp, #7]
    4d8c:	97fff4e1 	bl	2110 <buf_put>
    4d90:	b9401380 	ldr	w0, [x28, #16]
    4d94:	52800038 	mov	w24, #0x1                   	// #1
    4d98:	7100001f 	cmp	w0, #0x0
    4d9c:	54ffa66c 	b.gt	4268 <fwp_write.constprop.0+0x2a8>
    4da0:	17fffd49 	b	42c4 <fwp_write.constprop.0+0x304>
    4da4:	f9014bf9 	str	x25, [sp, #656]
    4da8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x14718>
    4dac:	f9014ffa 	str	x26, [sp, #664]
    4db0:	f9400676 	ldr	x22, [x19, #8]
    4db4:	912ca333 	add	x19, x25, #0xb28
    4db8:	91002273 	add	x19, x19, #0x8
    4dbc:	937ffed8 	asr	x24, x22, #63
    4dc0:	aa1802c0 	orr	x0, x22, x24
    4dc4:	b5000320 	cbnz	x0, 4e28 <fwp_write.constprop.0+0xe68>
    4dc8:	110006b5 	add	w21, w21, #0x1
    4dcc:	710016bf 	cmp	w21, #0x5
    4dd0:	54ffffc1 	b.ne	4dc8 <fwp_write.constprop.0+0xe08>  // b.any
    4dd4:	b7f80578 	tbnz	x24, #63, 4e80 <fwp_write.constprop.0+0xec0>
    4dd8:	910023f3 	add	x19, sp, #0x8
    4ddc:	aa1603e2 	mov	x2, x22
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	d2800003 	mov	x3, #0x0                   	// #0
    4de8:	97fff31e 	bl	1a60 <fwp_fmt_u128>
    4dec:	910123f5 	add	x21, sp, #0x48
    4df0:	b0000023 	adrp	x3, 9000 <__divti3+0x2c0>
    4df4:	aa1303e4 	mov	x4, x19
    4df8:	aa1503e0 	mov	x0, x21
    4dfc:	9120e063 	add	x3, x3, #0x838
    4e00:	d2804002 	mov	x2, #0x200                 	// #512
    4e04:	52800041 	mov	w1, #0x2                   	// #2
    4e08:	97fff166 	bl	13a0 <__sprintf_chk@plt>
    4e0c:	aa1503e0 	mov	x0, x21
    4e10:	97fff160 	bl	1390 <strlen@plt>
    4e14:	aa1503e1 	mov	x1, x21
    4e18:	aa0003e2 	mov	x2, x0
    4e1c:	aa1403e0 	mov	x0, x20
    4e20:	97fff4bc 	bl	2110 <buf_put>
    4e24:	17fffe7b 	b	4810 <fwp_write.constprop.0+0x850>
    4e28:	f9400277 	ldr	x23, [x19]
    4e2c:	aa1603e0 	mov	x0, x22
    4e30:	aa1803e1 	mov	x1, x24
    4e34:	aa1703e2 	mov	x2, x23
    4e38:	937ffefa 	asr	x26, x23, #63
    4e3c:	aa1a03e3 	mov	x3, x26
    4e40:	940010a0 	bl	90c0 <__modti3>
    4e44:	aa010000 	orr	x0, x0, x1
    4e48:	b40002c0 	cbz	x0, 4ea0 <fwp_write.constprop.0+0xee0>
    4e4c:	110006b5 	add	w21, w21, #0x1
    4e50:	91004273 	add	x19, x19, #0x10
    4e54:	710016bf 	cmp	w21, #0x5
    4e58:	54fffe81 	b.ne	4e28 <fwp_write.constprop.0+0xe68>  // b.any
    4e5c:	17ffffde 	b	4dd4 <fwp_write.constprop.0+0xe14>
    4e60:	f9400a60 	ldr	x0, [x19, #16]
    4e64:	8b000021 	add	x1, x1, x0
    4e68:	17fffd8c 	b	4498 <fwp_write.constprop.0+0x4d8>
    4e6c:	528c29c0 	mov	w0, #0x614e                	// #24910
    4e70:	910123f5 	add	x21, sp, #0x48
    4e74:	72a009c0 	movk	w0, #0x4e, lsl #16
    4e78:	b9004be0 	str	w0, [sp, #72]
    4e7c:	17fffdb9 	b	4560 <fwp_write.constprop.0+0x5a0>
    4e80:	528005a1 	mov	w1, #0x2d                  	// #45
    4e84:	eb1603e2 	negs	x2, x22
    4e88:	da1803e3 	ngc	x3, x24
    4e8c:	910027e0 	add	x0, sp, #0x9
    4e90:	910023f3 	add	x19, sp, #0x8
    4e94:	390023e1 	strb	w1, [sp, #8]
    4e98:	97fff2f2 	bl	1a60 <fwp_fmt_u128>
    4e9c:	17ffffd4 	b	4dec <fwp_write.constprop.0+0xe2c>
    4ea0:	aa1703e2 	mov	x2, x23
    4ea4:	aa1a03e3 	mov	x3, x26
    4ea8:	aa1603e0 	mov	x0, x22
    4eac:	aa1803e1 	mov	x1, x24
    4eb0:	94000fa4 	bl	8d40 <__divti3>
    4eb4:	aa0003e2 	mov	x2, x0
    4eb8:	aa0103e3 	mov	x3, x1
    4ebc:	b7f80201 	tbnz	x1, #63, 4efc <fwp_write.constprop.0+0xf3c>
    4ec0:	910023f3 	add	x19, sp, #0x8
    4ec4:	aa1303e0 	mov	x0, x19
    4ec8:	97fff2e6 	bl	1a60 <fwp_fmt_u128>
    4ecc:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4ed0:	912ca339 	add	x25, x25, #0xb28
    4ed4:	910123f5 	add	x21, sp, #0x48
    4ed8:	aa1303e4 	mov	x4, x19
    4edc:	aa1503e0 	mov	x0, x21
    4ee0:	b0000023 	adrp	x3, 9000 <__divti3+0x2c0>
    4ee4:	f8616b25 	ldr	x5, [x25, x1]
    4ee8:	9120c063 	add	x3, x3, #0x830
    4eec:	d2804002 	mov	x2, #0x200                 	// #512
    4ef0:	52800041 	mov	w1, #0x2                   	// #2
    4ef4:	97fff12b 	bl	13a0 <__sprintf_chk@plt>
    4ef8:	17ffffc5 	b	4e0c <fwp_write.constprop.0+0xe4c>
    4efc:	528005a4 	mov	w4, #0x2d                  	// #45
    4f00:	eb0003e2 	negs	x2, x0
    4f04:	da0103e3 	ngc	x3, x1
    4f08:	910027e0 	add	x0, sp, #0x9
    4f0c:	910023f3 	add	x19, sp, #0x8
    4f10:	390023e4 	strb	w4, [sp, #8]
    4f14:	97fff2d3 	bl	1a60 <fwp_fmt_u128>
    4f18:	17ffffed 	b	4ecc <fwp_write.constprop.0+0xf0c>
    4f1c:	f9013bf5 	str	x21, [sp, #624]
    4f20:	f9013ff6 	str	x22, [sp, #632]
    4f24:	f90143f7 	str	x23, [sp, #640]
    4f28:	f90147f8 	str	x24, [sp, #648]
    4f2c:	f9014bf9 	str	x25, [sp, #656]
    4f30:	f9014ffa 	str	x26, [sp, #664]
    4f34:	f90153fb 	str	x27, [sp, #672]
    4f38:	f90157fc 	str	x28, [sp, #680]
    4f3c:	fd015be8 	str	d8, [sp, #688]
    4f40:	fd015fe9 	str	d9, [sp, #696]
    4f44:	97fff16f 	bl	1500 <__stack_chk_fail@plt>
    4f48:	f90143f7 	str	x23, [sp, #640]
    4f4c:	f90147f8 	str	x24, [sp, #648]
    4f50:	f9014bf9 	str	x25, [sp, #656]
    4f54:	f9014ffa 	str	x26, [sp, #664]
    4f58:	fd015be8 	str	d8, [sp, #688]
    4f5c:	fd015fe9 	str	d9, [sp, #696]
    4f60:	97fff168 	bl	1500 <__stack_chk_fail@plt>

0000000000004f64 <fwp_hof0.constprop.0>:
    4f64:	d10443ff 	sub	sp, sp, #0x110
    4f68:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x14718>
    4f6c:	f947f442 	ldr	x2, [x2, #4072]
    4f70:	a9077bfd 	stp	x29, x30, [sp, #112]
    4f74:	9101c3fd 	add	x29, sp, #0x70
    4f78:	f90007e0 	str	x0, [sp, #8]
    4f7c:	f9400040 	ldr	x0, [x2]
    4f80:	f90037e0 	str	x0, [sp, #104]
    4f84:	d2800000 	mov	x0, #0x0                   	// #0
    4f88:	f9000fe1 	str	x1, [sp, #24]
    4f8c:	b4005ec1 	cbz	x1, 5b64 <fwp_hof0.constprop.0+0xc00>
    4f90:	b0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    4f94:	6d0e2fea 	stp	d10, d11, [sp, #224]
    4f98:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    4f9c:	fd45b02a 	ldr	d10, [x1, #2912]
    4fa0:	a90853f3 	stp	x19, x20, [sp, #128]
    4fa4:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4fa8:	a9095bf5 	stp	x21, x22, [sp, #144]
    4fac:	a90a63f7 	stp	x23, x24, [sp, #160]
    4fb0:	a90b6bf9 	stp	x25, x26, [sp, #176]
    4fb4:	a90c73fb 	stp	x27, x28, [sp, #192]
    4fb8:	6d0d27e8 	stp	d8, d9, [sp, #208]
    4fbc:	9e670009 	fmov	d9, x0
    4fc0:	6d0f37ec 	stp	d12, d13, [sp, #240]
    4fc4:	6d103fee 	stp	d14, d15, [sp, #256]
    4fc8:	9115c262 	add	x2, x19, #0x570
    4fcc:	f94007e3 	ldr	x3, [sp, #8]
    4fd0:	f949d840 	ldr	x0, [x2, #5040]
    4fd4:	f949ec41 	ldr	x1, [x2, #5080]
    4fd8:	cb000060 	sub	x0, x3, x0
    4fdc:	eb01401f 	cmp	x0, x1, lsl #16
    4fe0:	54000422 	b.cs	5064 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    4fe4:	d350fc01 	lsr	x1, x0, #16
    4fe8:	f949fc43 	ldr	x3, [x2, #5112]
    4fec:	8b010821 	add	x1, x1, x1, lsl #2
    4ff0:	d37df021 	lsl	x1, x1, #3
    4ff4:	8b010062 	add	x2, x3, x1
    4ff8:	f9401054 	ldr	x20, [x2, #32]
    4ffc:	b4000354 	cbz	x20, 5064 <fwp_hof0.constprop.0+0x100>
    5000:	38616861 	ldrb	w1, [x3, x1]
    5004:	7100083f 	cmp	w1, #0x2
    5008:	54006fc0 	b.eq	5e00 <fwp_hof0.constprop.0+0xe9c>  // b.none
    500c:	7100043f 	cmp	w1, #0x1
    5010:	540002a1 	b.ne	5064 <fwp_hof0.constprop.0+0x100>  // b.any
    5014:	29430443 	ldp	w3, w1, [x2, #24]
    5018:	92403c00 	and	x0, x0, #0xffff
    501c:	9b037c00 	mul	x0, x0, x3
    5020:	d360fc00 	lsr	x0, x0, #32
    5024:	eb01001f 	cmp	x0, x1
    5028:	540001e2 	b.cs	5064 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    502c:	8b000294 	add	x20, x20, x0
    5030:	39400280 	ldrb	w0, [x20]
    5034:	34000180 	cbz	w0, 5064 <fwp_hof0.constprop.0+0x100>
    5038:	f00000c1 	adrp	x1, 20000 <__data_start>
    503c:	91024021 	add	x1, x1, #0x90
    5040:	b9404022 	ldr	w2, [x1, #64]
    5044:	34000082 	cbz	w2, 5054 <fwp_hof0.constprop.0+0xf0>
    5048:	f9416422 	ldr	x2, [x1, #712]
    504c:	91000442 	add	x2, x2, #0x1
    5050:	f9016422 	str	x2, [x1, #712]
    5054:	7103f41f 	cmp	w0, #0xfd
    5058:	54007a08 	b.hi	5f98 <fwp_hof0.constprop.0+0x1034>  // b.pmore
    505c:	11000400 	add	w0, w0, #0x1
    5060:	39000280 	strb	w0, [x20]
    5064:	f94007e0 	ldr	x0, [sp, #8]
    5068:	b4006d40 	cbz	x0, 5e10 <fwp_hof0.constprop.0+0xeac>
    506c:	aa0003e1 	mov	x1, x0
    5070:	d2800000 	mov	x0, #0x0                   	// #0
    5074:	d503201f 	nop
    5078:	f9400821 	ldr	x1, [x1, #16]
    507c:	91000400 	add	x0, x0, #0x1
    5080:	b5ffffc1 	cbnz	x1, 5078 <fwp_hof0.constprop.0+0x114>
    5084:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5088:	eb01001f 	cmp	x0, x1
    508c:	540081c8 	b.hi	60c4 <fwp_hof0.constprop.0+0x1160>  // b.pmore
    5090:	97fffa0d 	bl	38c4 <fwp_array_new_packed.constprop.0>
    5094:	aa0003f4 	mov	x20, x0
    5098:	9115c261 	add	x1, x19, #0x570
    509c:	aa0103e0 	mov	x0, x1
    50a0:	f949d821 	ldr	x1, [x1, #5040]
    50a4:	f949ec00 	ldr	x0, [x0, #5080]
    50a8:	cb010281 	sub	x1, x20, x1
    50ac:	eb00403f 	cmp	x1, x0, lsl #16
    50b0:	54000382 	b.cs	5120 <fwp_hof0.constprop.0+0x1bc>  // b.hs, b.nlast
    50b4:	9115c262 	add	x2, x19, #0x570
    50b8:	d350fc20 	lsr	x0, x1, #16
    50bc:	8b000800 	add	x0, x0, x0, lsl #2
    50c0:	f949fc43 	ldr	x3, [x2, #5112]
    50c4:	d37df002 	lsl	x2, x0, #3
    50c8:	8b020060 	add	x0, x3, x2
    50cc:	f9401015 	ldr	x21, [x0, #32]
    50d0:	b4000255 	cbz	x21, 5118 <fwp_hof0.constprop.0+0x1b4>
    50d4:	38626862 	ldrb	w2, [x3, x2]
    50d8:	7100085f 	cmp	w2, #0x2
    50dc:	54006b20 	b.eq	5e40 <fwp_hof0.constprop.0+0xedc>  // b.none
    50e0:	7100045f 	cmp	w2, #0x1
    50e4:	540001a1 	b.ne	5118 <fwp_hof0.constprop.0+0x1b4>  // b.any
    50e8:	29430002 	ldp	w2, w0, [x0, #24]
    50ec:	92403c21 	and	x1, x1, #0xffff
    50f0:	9b027c21 	mul	x1, x1, x2
    50f4:	d360fc21 	lsr	x1, x1, #32
    50f8:	eb00003f 	cmp	x1, x0
    50fc:	540000e2 	b.cs	5118 <fwp_hof0.constprop.0+0x1b4>  // b.hs, b.nlast
    5100:	8b0102b5 	add	x21, x21, x1
    5104:	394002a0 	ldrb	w0, [x21]
    5108:	7103fc1f 	cmp	w0, #0xff
    510c:	54006a40 	b.eq	5e54 <fwp_hof0.constprop.0+0xef0>  // b.none
    5110:	52800020 	mov	w0, #0x1                   	// #1
    5114:	390002a0 	strb	w0, [x21]
    5118:	f94007e0 	ldr	x0, [sp, #8]
    511c:	b40068e0 	cbz	x0, 5e38 <fwp_hof0.constprop.0+0xed4>
    5120:	f94007f5 	ldr	x21, [sp, #8]
    5124:	91002296 	add	x22, x20, #0x8
    5128:	9115c277 	add	x23, x19, #0x570
    512c:	52800038 	mov	w24, #0x1                   	// #1
    5130:	aa1503e0 	mov	x0, x21
    5134:	14000013 	b	5180 <fwp_hof0.constprop.0+0x21c>
    5138:	7100045f 	cmp	w2, #0x1
    513c:	54000161 	b.ne	5168 <fwp_hof0.constprop.0+0x204>  // b.any
    5140:	294308e8 	ldp	w8, w2, [x7, #24]
    5144:	92403c21 	and	x1, x1, #0xffff
    5148:	9b087c21 	mul	x1, x1, x8
    514c:	d360fc21 	lsr	x1, x1, #32
    5150:	eb02003f 	cmp	x1, x2
    5154:	540000a2 	b.cs	5168 <fwp_hof0.constprop.0+0x204>  // b.hs, b.nlast
    5158:	8b0100c6 	add	x6, x6, x1
    515c:	394000c1 	ldrb	w1, [x6]
    5160:	7100043f 	cmp	w1, #0x1
    5164:	540003e0 	b.eq	51e0 <fwp_hof0.constprop.0+0x27c>  // b.none
    5168:	f9400281 	ldr	x1, [x20]
    516c:	b7f87761 	tbnz	x1, #63, 6058 <fwp_hof0.constprop.0+0x10f4>
    5170:	f90002c4 	str	x4, [x22]
    5174:	52800018 	mov	w24, #0x0                   	// #0
    5178:	910022d6 	add	x22, x22, #0x8
    517c:	b4000775 	cbz	x21, 5268 <fwp_hof0.constprop.0+0x304>
    5180:	aa1503e5 	mov	x5, x21
    5184:	aa1503e3 	mov	x3, x21
    5188:	a940d6a4 	ldp	x4, x21, [x21, #8]
    518c:	34fffef8 	cbz	w24, 5168 <fwp_hof0.constprop.0+0x204>
    5190:	f949dae1 	ldr	x1, [x23, #5040]
    5194:	f949eee2 	ldr	x2, [x23, #5080]
    5198:	cb0100a1 	sub	x1, x5, x1
    519c:	eb02403f 	cmp	x1, x2, lsl #16
    51a0:	54fffe42 	b.cs	5168 <fwp_hof0.constprop.0+0x204>  // b.hs, b.nlast
    51a4:	d350fc22 	lsr	x2, x1, #16
    51a8:	f949fee8 	ldr	x8, [x23, #5112]
    51ac:	8b020842 	add	x2, x2, x2, lsl #2
    51b0:	d37df042 	lsl	x2, x2, #3
    51b4:	8b020107 	add	x7, x8, x2
    51b8:	f94010e6 	ldr	x6, [x7, #32]
    51bc:	b4fffd66 	cbz	x6, 5168 <fwp_hof0.constprop.0+0x204>
    51c0:	38626902 	ldrb	w2, [x8, x2]
    51c4:	7100085f 	cmp	w2, #0x2
    51c8:	54fffb81 	b.ne	5138 <fwp_hof0.constprop.0+0x1d4>  // b.any
    51cc:	72003c3f 	tst	w1, #0xffff
    51d0:	54fffcc1 	b.ne	5168 <fwp_hof0.constprop.0+0x204>  // b.any
    51d4:	394000c1 	ldrb	w1, [x6]
    51d8:	7100043f 	cmp	w1, #0x1
    51dc:	54fffc61 	b.ne	5168 <fwp_hof0.constprop.0+0x204>  // b.any
    51e0:	f9400280 	ldr	x0, [x20]
    51e4:	b7f873a0 	tbnz	x0, #63, 6058 <fwp_hof0.constprop.0+0x10f4>
    51e8:	f90002c4 	str	x4, [x22]
    51ec:	f949dae1 	ldr	x1, [x23, #5040]
    51f0:	f949eee0 	ldr	x0, [x23, #5080]
    51f4:	cb010063 	sub	x3, x3, x1
    51f8:	eb00407f 	cmp	x3, x0, lsl #16
    51fc:	540002e2 	b.cs	5258 <fwp_hof0.constprop.0+0x2f4>  // b.hs, b.nlast
    5200:	d350fc60 	lsr	x0, x3, #16
    5204:	f949fee1 	ldr	x1, [x23, #5112]
    5208:	8b000800 	add	x0, x0, x0, lsl #2
    520c:	d37df000 	lsl	x0, x0, #3
    5210:	8b000024 	add	x4, x1, x0
    5214:	f9401082 	ldr	x2, [x4, #32]
    5218:	b4000202 	cbz	x2, 5258 <fwp_hof0.constprop.0+0x2f4>
    521c:	38606820 	ldrb	w0, [x1, x0]
    5220:	7100081f 	cmp	w0, #0x2
    5224:	54005ca0 	b.eq	5db8 <fwp_hof0.constprop.0+0xe54>  // b.none
    5228:	7100041f 	cmp	w0, #0x1
    522c:	54000161 	b.ne	5258 <fwp_hof0.constprop.0+0x2f4>  // b.any
    5230:	29430086 	ldp	w6, w0, [x4, #24]
    5234:	92403c61 	and	x1, x3, #0xffff
    5238:	9b067c21 	mul	x1, x1, x6
    523c:	d360fc21 	lsr	x1, x1, #32
    5240:	eb00003f 	cmp	x1, x0
    5244:	540000a2 	b.cs	5258 <fwp_hof0.constprop.0+0x2f4>  // b.hs, b.nlast
    5248:	8b010042 	add	x2, x2, x1
    524c:	39400040 	ldrb	w0, [x2]
    5250:	7100041f 	cmp	w0, #0x1
    5254:	540021a0 	b.eq	5688 <fwp_hof0.constprop.0+0x724>  // b.none
    5258:	aa1503e0 	mov	x0, x21
    525c:	910022d6 	add	x22, x22, #0x8
    5260:	b5fff915 	cbnz	x21, 5180 <fwp_hof0.constprop.0+0x21c>
    5264:	d503201f 	nop
    5268:	d28018d7 	mov	x23, #0xc6                  	// #198
    526c:	b27feffa 	mov	x26, #0x1ffffffffffffffe    	// #2305843009213693950
    5270:	97fff9fc 	bl	3a60 <fwp_drop0>
    5274:	d503201f 	nop
    5278:	f9400296 	ldr	x22, [x20]
    527c:	9240fad6 	and	x22, x22, #0x7fffffffffffffff
    5280:	eb1a02df 	cmp	x22, x26
    5284:	54007208 	b.hi	60c4 <fwp_hof0.constprop.0+0x1160>  // b.pmore
    5288:	aa1603e0 	mov	x0, x22
    528c:	97fff98e 	bl	38c4 <fwp_array_new_packed.constprop.0>
    5290:	9115c262 	add	x2, x19, #0x570
    5294:	aa0003f5 	mov	x21, x0
    5298:	f949d841 	ldr	x1, [x2, #5040]
    529c:	f949ec40 	ldr	x0, [x2, #5080]
    52a0:	cb0102a1 	sub	x1, x21, x1
    52a4:	eb00403f 	cmp	x1, x0, lsl #16
    52a8:	54000322 	b.cs	530c <fwp_hof0.constprop.0+0x3a8>  // b.hs, b.nlast
    52ac:	d350fc20 	lsr	x0, x1, #16
    52b0:	f949fc43 	ldr	x3, [x2, #5112]
    52b4:	8b000800 	add	x0, x0, x0, lsl #2
    52b8:	d37df002 	lsl	x2, x0, #3
    52bc:	8b020060 	add	x0, x3, x2
    52c0:	f9401018 	ldr	x24, [x0, #32]
    52c4:	b4000258 	cbz	x24, 530c <fwp_hof0.constprop.0+0x3a8>
    52c8:	38626862 	ldrb	w2, [x3, x2]
    52cc:	7100085f 	cmp	w2, #0x2
    52d0:	54004bc0 	b.eq	5c48 <fwp_hof0.constprop.0+0xce4>  // b.none
    52d4:	7100045f 	cmp	w2, #0x1
    52d8:	540001a1 	b.ne	530c <fwp_hof0.constprop.0+0x3a8>  // b.any
    52dc:	29430002 	ldp	w2, w0, [x0, #24]
    52e0:	92403c21 	and	x1, x1, #0xffff
    52e4:	9b027c21 	mul	x1, x1, x2
    52e8:	d360fc21 	lsr	x1, x1, #32
    52ec:	eb00003f 	cmp	x1, x0
    52f0:	540000e2 	b.cs	530c <fwp_hof0.constprop.0+0x3a8>  // b.hs, b.nlast
    52f4:	8b010318 	add	x24, x24, x1
    52f8:	39400300 	ldrb	w0, [x24]
    52fc:	7103fc1f 	cmp	w0, #0xff
    5300:	54004ae0 	b.eq	5c5c <fwp_hof0.constprop.0+0xcf8>  // b.none
    5304:	52800020 	mov	w0, #0x1                   	// #1
    5308:	39000300 	strb	w0, [x24]
    530c:	d280011b 	mov	x27, #0x8                   	// #8
    5310:	2f00e408 	movi	d8, #0x0
    5314:	8b1b0298 	add	x24, x20, x27
    5318:	d280001c 	mov	x28, #0x0                   	// #0
    531c:	b5001a76 	cbnz	x22, 5668 <fwp_hof0.constprop.0+0x704>
    5320:	14000108 	b	5740 <fwp_hof0.constprop.0+0x7dc>
    5324:	aa1803e0 	mov	x0, x24
    5328:	b7f84342 	tbnz	x2, #63, 5b90 <fwp_hof0.constprop.0+0xc2c>
    532c:	fc7c780b 	ldr	d11, [x0, x28, lsl #3]
    5330:	9e6703ec 	fmov	d12, xzr
    5334:	b400027c 	cbz	x28, 5380 <fwp_hof0.constprop.0+0x41c>
    5338:	8b1b0000 	add	x0, x0, x27
    533c:	1e6e100c 	fmov	d12, #1.000000000000000000e+00
    5340:	fc5f0000 	ldur	d0, [x0, #-16]
    5344:	1e680802 	fmul	d2, d0, d8
    5348:	1e600801 	fmul	d1, d0, d0
    534c:	1e603980 	fsub	d0, d12, d0
    5350:	1e622842 	fadd	d2, d2, d2
    5354:	1e613961 	fsub	d1, d11, d1
    5358:	1e680800 	fmul	d0, d0, d8
    535c:	1e62398c 	fsub	d12, d12, d2
    5360:	1e610822 	fmul	d2, d1, d1
    5364:	1e602800 	fadd	d0, d0, d0
    5368:	1e61098c 	fmul	d12, d12, d1
    536c:	1e680841 	fmul	d1, d2, d8
    5370:	1e6c298c 	fadd	d12, d12, d12
    5374:	1e69098c 	fmul	d12, d12, d9
    5378:	1e61298c 	fadd	d12, d12, d1
    537c:	1e60298c 	fadd	d12, d12, d0
    5380:	9100079c 	add	x28, x28, #0x1
    5384:	eb1c003f 	cmp	x1, x28
    5388:	54001880 	b.eq	5698 <fwp_hof0.constprop.0+0x734>  // b.none
    538c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    5390:	910163e1 	add	x1, sp, #0x58
    5394:	52800000 	mov	w0, #0x0                   	// #0
    5398:	f9002fe2 	str	x2, [sp, #88]
    539c:	fd0033eb 	str	d11, [sp, #96]
    53a0:	97fff8ec 	bl	3750 <fwp_data.part.0.constprop.0>
    53a4:	9115c263 	add	x3, x19, #0x570
    53a8:	aa0003f9 	mov	x25, x0
    53ac:	f949d861 	ldr	x1, [x3, #5040]
    53b0:	f949ec60 	ldr	x0, [x3, #5080]
    53b4:	cb010321 	sub	x1, x25, x1
    53b8:	eb00403f 	cmp	x1, x0, lsl #16
    53bc:	54000322 	b.cs	5420 <fwp_hof0.constprop.0+0x4bc>  // b.hs, b.nlast
    53c0:	d350fc22 	lsr	x2, x1, #16
    53c4:	f949fc66 	ldr	x6, [x3, #5112]
    53c8:	8b020842 	add	x2, x2, x2, lsl #2
    53cc:	d37df042 	lsl	x2, x2, #3
    53d0:	8b0200c3 	add	x3, x6, x2
    53d4:	f9401060 	ldr	x0, [x3, #32]
    53d8:	b4000240 	cbz	x0, 5420 <fwp_hof0.constprop.0+0x4bc>
    53dc:	386268c2 	ldrb	w2, [x6, x2]
    53e0:	7100085f 	cmp	w2, #0x2
    53e4:	540017a0 	b.eq	56d8 <fwp_hof0.constprop.0+0x774>  // b.none
    53e8:	7100045f 	cmp	w2, #0x1
    53ec:	540001a1 	b.ne	5420 <fwp_hof0.constprop.0+0x4bc>  // b.any
    53f0:	29430866 	ldp	w6, w2, [x3, #24]
    53f4:	92403c21 	and	x1, x1, #0xffff
    53f8:	9b067c21 	mul	x1, x1, x6
    53fc:	d360fc21 	lsr	x1, x1, #32
    5400:	eb02003f 	cmp	x1, x2
    5404:	540000e2 	b.cs	5420 <fwp_hof0.constprop.0+0x4bc>  // b.hs, b.nlast
    5408:	8b010000 	add	x0, x0, x1
    540c:	39400001 	ldrb	w1, [x0]
    5410:	7103fc3f 	cmp	w1, #0xff
    5414:	540016e0 	b.eq	56f0 <fwp_hof0.constprop.0+0x78c>  // b.none
    5418:	52800021 	mov	w1, #0x1                   	// #1
    541c:	39000001 	strb	w1, [x0]
    5420:	f9400280 	ldr	x0, [x20]
    5424:	9240f801 	and	x1, x0, #0x7fffffffffffffff
    5428:	eb1c003f 	cmp	x1, x28
    542c:	54001269 	b.ls	5678 <fwp_hof0.constprop.0+0x714>  // b.plast
    5430:	aa1803e2 	mov	x2, x24
    5434:	b7f83b20 	tbnz	x0, #63, 5b98 <fwp_hof0.constprop.0+0xc34>
    5438:	f87b6842 	ldr	x2, [x2, x27]
    543c:	910123e1 	add	x1, sp, #0x48
    5440:	52800000 	mov	w0, #0x0                   	// #0
    5444:	a9048bff 	stp	xzr, x2, [sp, #72]
    5448:	97fff8c2 	bl	3750 <fwp_data.part.0.constprop.0>
    544c:	aa0003e8 	mov	x8, x0
    5450:	9115c267 	add	x7, x19, #0x570
    5454:	f949ece6 	ldr	x6, [x7, #5080]
    5458:	f949d8e2 	ldr	x2, [x7, #5040]
    545c:	d370bcc6 	lsl	x6, x6, #16
    5460:	cb020001 	sub	x1, x0, x2
    5464:	eb06003f 	cmp	x1, x6
    5468:	540003c2 	b.cs	54e0 <fwp_hof0.constprop.0+0x57c>  // b.hs, b.nlast
    546c:	d350fc23 	lsr	x3, x1, #16
    5470:	f949fcea 	ldr	x10, [x7, #5112]
    5474:	8b030867 	add	x7, x3, x3, lsl #2
    5478:	d37df0e7 	lsl	x7, x7, #3
    547c:	8b070149 	add	x9, x10, x7
    5480:	f9401120 	ldr	x0, [x9, #32]
    5484:	b4001420 	cbz	x0, 5708 <fwp_hof0.constprop.0+0x7a4>
    5488:	38676947 	ldrb	w7, [x10, x7]
    548c:	710008ff 	cmp	w7, #0x2
    5490:	54001380 	b.eq	5700 <fwp_hof0.constprop.0+0x79c>  // b.none
    5494:	710004ff 	cmp	w7, #0x1
    5498:	54001381 	b.ne	5708 <fwp_hof0.constprop.0+0x7a4>  // b.any
    549c:	2943252a 	ldp	w10, w9, [x9, #24]
    54a0:	92403c27 	and	x7, x1, #0xffff
    54a4:	9b0a7ce7 	mul	x7, x7, x10
    54a8:	d360fce7 	lsr	x7, x7, #32
    54ac:	eb0900ff 	cmp	x7, x9
    54b0:	540012c2 	b.cs	5708 <fwp_hof0.constprop.0+0x7a4>  // b.hs, b.nlast
    54b4:	8b070000 	add	x0, x0, x7
    54b8:	39400001 	ldrb	w1, [x0]
    54bc:	7103fc3f 	cmp	w1, #0xff
    54c0:	54003700 	b.eq	5ba0 <fwp_hof0.constprop.0+0xc3c>  // b.none
    54c4:	9115c261 	add	x1, x19, #0x570
    54c8:	52800022 	mov	w2, #0x1                   	// #1
    54cc:	39000002 	strb	w2, [x0]
    54d0:	f949ec26 	ldr	x6, [x1, #5080]
    54d4:	f949d822 	ldr	x2, [x1, #5040]
    54d8:	d370bcc6 	lsl	x6, x6, #16
    54dc:	cb020101 	sub	x1, x8, x2
    54e0:	fd400b24 	ldr	d4, [x25, #16]
    54e4:	fd400722 	ldr	d2, [x25, #8]
    54e8:	6d40b900 	ldp	d0, d14, [x8, #8]
    54ec:	1e64088f 	fmul	d15, d4, d4
    54f0:	1e640843 	fmul	d3, d2, d4
    54f4:	1e632863 	fadd	d3, d3, d3
    54f8:	1e63380d 	fsub	d13, d0, d3
    54fc:	eb06003f 	cmp	x1, x6
    5500:	54000482 	b.cs	5590 <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    5504:	d350fc23 	lsr	x3, x1, #16
    5508:	9115c260 	add	x0, x19, #0x570
    550c:	8b030863 	add	x3, x3, x3, lsl #2
    5510:	d37df063 	lsl	x3, x3, #3
    5514:	f949fc09 	ldr	x9, [x0, #5112]
    5518:	8b030127 	add	x7, x9, x3
    551c:	f94010e0 	ldr	x0, [x7, #32]
    5520:	b4000380 	cbz	x0, 5590 <fwp_hof0.constprop.0+0x62c>
    5524:	38636923 	ldrb	w3, [x9, x3]
    5528:	7100087f 	cmp	w3, #0x2
    552c:	54000fe0 	b.eq	5728 <fwp_hof0.constprop.0+0x7c4>  // b.none
    5530:	7100047f 	cmp	w3, #0x1
    5534:	540002e1 	b.ne	5590 <fwp_hof0.constprop.0+0x62c>  // b.any
    5538:	29430ce9 	ldp	w9, w3, [x7, #24]
    553c:	92403c21 	and	x1, x1, #0xffff
    5540:	9b097c21 	mul	x1, x1, x9
    5544:	d360fc21 	lsr	x1, x1, #32
    5548:	eb03003f 	cmp	x1, x3
    554c:	54000222 	b.cs	5590 <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    5550:	8b010000 	add	x0, x0, x1
    5554:	39400001 	ldrb	w1, [x0]
    5558:	340001c1 	cbz	w1, 5590 <fwp_hof0.constprop.0+0x62c>
    555c:	7100043f 	cmp	w1, #0x1
    5560:	54000a00 	b.eq	56a0 <fwp_hof0.constprop.0+0x73c>  // b.none
    5564:	7103fc3f 	cmp	w1, #0xff
    5568:	54003c60 	b.eq	5cf4 <fwp_hof0.constprop.0+0xd90>  // b.none
    556c:	9115c262 	add	x2, x19, #0x570
    5570:	51000421 	sub	w1, w1, #0x1
    5574:	39000001 	strb	w1, [x0]
    5578:	f949ec46 	ldr	x6, [x2, #5080]
    557c:	fd400b24 	ldr	d4, [x25, #16]
    5580:	f949d842 	ldr	x2, [x2, #5040]
    5584:	d370bcc6 	lsl	x6, x6, #16
    5588:	fd400722 	ldr	d2, [x25, #8]
    558c:	d503201f 	nop
    5590:	cb020322 	sub	x2, x25, x2
    5594:	1e6f39ce 	fsub	d14, d14, d15
    5598:	1e62390f 	fsub	d15, d8, d2
    559c:	eb0200df 	cmp	x6, x2
    55a0:	540003c9 	b.ls	5618 <fwp_hof0.constprop.0+0x6b4>  // b.plast
    55a4:	9115c261 	add	x1, x19, #0x570
    55a8:	d350fc40 	lsr	x0, x2, #16
    55ac:	8b000800 	add	x0, x0, x0, lsl #2
    55b0:	f949fc26 	ldr	x6, [x1, #5112]
    55b4:	d37df000 	lsl	x0, x0, #3
    55b8:	8b0000c3 	add	x3, x6, x0
    55bc:	f9401061 	ldr	x1, [x3, #32]
    55c0:	b40002c1 	cbz	x1, 5618 <fwp_hof0.constprop.0+0x6b4>
    55c4:	386068c0 	ldrb	w0, [x6, x0]
    55c8:	7100081f 	cmp	w0, #0x2
    55cc:	54000b40 	b.eq	5734 <fwp_hof0.constprop.0+0x7d0>  // b.none
    55d0:	7100041f 	cmp	w0, #0x1
    55d4:	54000221 	b.ne	5618 <fwp_hof0.constprop.0+0x6b4>  // b.any
    55d8:	29430066 	ldp	w6, w0, [x3, #24]
    55dc:	92403c42 	and	x2, x2, #0xffff
    55e0:	9b067c42 	mul	x2, x2, x6
    55e4:	d360fc42 	lsr	x2, x2, #32
    55e8:	eb00005f 	cmp	x2, x0
    55ec:	54000162 	b.cs	5618 <fwp_hof0.constprop.0+0x6b4>  // b.hs, b.nlast
    55f0:	8b020021 	add	x1, x1, x2
    55f4:	39400020 	ldrb	w0, [x1]
    55f8:	34000100 	cbz	w0, 5618 <fwp_hof0.constprop.0+0x6b4>
    55fc:	7100041f 	cmp	w0, #0x1
    5600:	54000620 	b.eq	56c4 <fwp_hof0.constprop.0+0x760>  // b.none
    5604:	7103fc1f 	cmp	w0, #0xff
    5608:	540039e0 	b.eq	5d44 <fwp_hof0.constprop.0+0xde0>  // b.none
    560c:	51000400 	sub	w0, w0, #0x1
    5610:	39000020 	strb	w0, [x1]
    5614:	d503201f 	nop
    5618:	1e6e09a0 	fmul	d0, d13, d14
    561c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5620:	1e6e09ce 	fmul	d14, d14, d14
    5624:	1e643821 	fsub	d1, d1, d4
    5628:	1e602800 	fadd	d0, d0, d0
    562c:	1e6809ce 	fmul	d14, d14, d8
    5630:	1e6f0821 	fmul	d1, d1, d15
    5634:	1e690800 	fmul	d0, d0, d9
    5638:	1e612821 	fadd	d1, d1, d1
    563c:	1e6e2800 	fadd	d0, d0, d14
    5640:	1e612800 	fadd	d0, d0, d1
    5644:	1e6c2800 	fadd	d0, d0, d12
    5648:	f94002a0 	ldr	x0, [x21]
    564c:	1e6a0800 	fmul	d0, d0, d10
    5650:	1e603960 	fsub	d0, d11, d0
    5654:	b7f85020 	tbnz	x0, #63, 6058 <fwp_hof0.constprop.0+0x10f4>
    5658:	fc3b6aa0 	str	d0, [x21, x27]
    565c:	9100237b 	add	x27, x27, #0x8
    5660:	eb1c02df 	cmp	x22, x28
    5664:	540006e0 	b.eq	5740 <fwp_hof0.constprop.0+0x7dc>  // b.none
    5668:	f9400282 	ldr	x2, [x20]
    566c:	9240f841 	and	x1, x2, #0x7fffffffffffffff
    5670:	eb01039f 	cmp	x28, x1
    5674:	54ffe583 	b.cc	5324 <fwp_hof0.constprop.0+0x3c0>  // b.lo, b.ul, b.last
    5678:	f00000c0 	adrp	x0, 20000 <__data_start>
    567c:	91004000 	add	x0, x0, #0x10
    5680:	9100a000 	add	x0, x0, #0x28
    5684:	97fff2ff 	bl	2280 <fwp_trap>
    5688:	aa0503e0 	mov	x0, x5
    568c:	97fff65d 	bl	3000 <fwp_mem_free>
    5690:	aa1503e0 	mov	x0, x21
    5694:	17fffef2 	b	525c <fwp_hof0.constprop.0+0x2f8>
    5698:	2f00e400 	movi	d0, #0x0
    569c:	17ffffea 	b	5644 <fwp_hof0.constprop.0+0x6e0>
    56a0:	aa0803e0 	mov	x0, x8
    56a4:	97fff7a7 	bl	3540 <fwp_rc_free_arr>
    56a8:	9115c260 	add	x0, x19, #0x570
    56ac:	fd400722 	ldr	d2, [x25, #8]
    56b0:	fd400b24 	ldr	d4, [x25, #16]
    56b4:	f949ec06 	ldr	x6, [x0, #5080]
    56b8:	f949d802 	ldr	x2, [x0, #5040]
    56bc:	d370bcc6 	lsl	x6, x6, #16
    56c0:	17ffffb4 	b	5590 <fwp_hof0.constprop.0+0x62c>
    56c4:	aa1903e0 	mov	x0, x25
    56c8:	fd0003e4 	str	d4, [sp]
    56cc:	97fff79d 	bl	3540 <fwp_rc_free_arr>
    56d0:	fd4003e4 	ldr	d4, [sp]
    56d4:	17ffffd1 	b	5618 <fwp_hof0.constprop.0+0x6b4>
    56d8:	72003c3f 	tst	w1, #0xffff
    56dc:	54ffea21 	b.ne	5420 <fwp_hof0.constprop.0+0x4bc>  // b.any
    56e0:	39400001 	ldrb	w1, [x0]
    56e4:	7103fc3f 	cmp	w1, #0xff
    56e8:	54ffe981 	b.ne	5418 <fwp_hof0.constprop.0+0x4b4>  // b.any
    56ec:	d503201f 	nop
    56f0:	f90003e0 	str	x0, [sp]
    56f4:	97fff5a4 	bl	2d84 <fwp_rc_forget_slot>
    56f8:	f94003e0 	ldr	x0, [sp]
    56fc:	17ffff47 	b	5418 <fwp_hof0.constprop.0+0x4b4>
    5700:	72003c3f 	tst	w1, #0xffff
    5704:	54ffeda0 	b.eq	54b8 <fwp_hof0.constprop.0+0x554>  // b.none
    5708:	fd400b24 	ldr	d4, [x25, #16]
    570c:	fd400722 	ldr	d2, [x25, #8]
    5710:	6d40b900 	ldp	d0, d14, [x8, #8]
    5714:	1e64088f 	fmul	d15, d4, d4
    5718:	1e620883 	fmul	d3, d4, d2
    571c:	1e632863 	fadd	d3, d3, d3
    5720:	1e63380d 	fsub	d13, d0, d3
    5724:	17ffff79 	b	5508 <fwp_hof0.constprop.0+0x5a4>
    5728:	72003c3f 	tst	w1, #0xffff
    572c:	54fff321 	b.ne	5590 <fwp_hof0.constprop.0+0x62c>  // b.any
    5730:	17ffff89 	b	5554 <fwp_hof0.constprop.0+0x5f0>
    5734:	72003c5f 	tst	w2, #0xffff
    5738:	54fff701 	b.ne	5618 <fwp_hof0.constprop.0+0x6b4>  // b.any
    573c:	17ffffae 	b	55f4 <fwp_hof0.constprop.0+0x690>
    5740:	9115c276 	add	x22, x19, #0x570
    5744:	f949dac1 	ldr	x1, [x22, #5040]
    5748:	f949eec0 	ldr	x0, [x22, #5080]
    574c:	cb010281 	sub	x1, x20, x1
    5750:	eb00403f 	cmp	x1, x0, lsl #16
    5754:	540003a2 	b.cs	57c8 <fwp_hof0.constprop.0+0x864>  // b.hs, b.nlast
    5758:	d350fc20 	lsr	x0, x1, #16
    575c:	f949fec4 	ldr	x4, [x22, #5112]
    5760:	8b000800 	add	x0, x0, x0, lsl #2
    5764:	d37df000 	lsl	x0, x0, #3
    5768:	8b000082 	add	x2, x4, x0
    576c:	f9401058 	ldr	x24, [x2, #32]
    5770:	b40002d8 	cbz	x24, 57c8 <fwp_hof0.constprop.0+0x864>
    5774:	38606880 	ldrb	w0, [x4, x0]
    5778:	7100081f 	cmp	w0, #0x2
    577c:	540021e0 	b.eq	5bb8 <fwp_hof0.constprop.0+0xc54>  // b.none
    5780:	7100041f 	cmp	w0, #0x1
    5784:	54000221 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    5788:	29430043 	ldp	w3, w0, [x2, #24]
    578c:	92403c21 	and	x1, x1, #0xffff
    5790:	9b037c21 	mul	x1, x1, x3
    5794:	d360fc21 	lsr	x1, x1, #32
    5798:	eb00003f 	cmp	x1, x0
    579c:	54000162 	b.cs	57c8 <fwp_hof0.constprop.0+0x864>  // b.hs, b.nlast
    57a0:	8b010318 	add	x24, x24, x1
    57a4:	39400300 	ldrb	w0, [x24]
    57a8:	34000100 	cbz	w0, 57c8 <fwp_hof0.constprop.0+0x864>
    57ac:	7100041f 	cmp	w0, #0x1
    57b0:	54000160 	b.eq	57dc <fwp_hof0.constprop.0+0x878>  // b.none
    57b4:	7103fc1f 	cmp	w0, #0xff
    57b8:	54003540 	b.eq	5e60 <fwp_hof0.constprop.0+0xefc>  // b.none
    57bc:	51000400 	sub	w0, w0, #0x1
    57c0:	39000300 	strb	w0, [x24]
    57c4:	d503201f 	nop
    57c8:	b40004d7 	cbz	x23, 5860 <fwp_hof0.constprop.0+0x8fc>
    57cc:	f10006f7 	subs	x23, x23, #0x1
    57d0:	54004a66 	b.vs	611c <fwp_hof0.constprop.0+0x11b8>
    57d4:	aa1503f4 	mov	x20, x21
    57d8:	17fffea8 	b	5278 <fwp_hof0.constprop.0+0x314>
    57dc:	f9400285 	ldr	x5, [x20]
    57e0:	aa1403e0 	mov	x0, x20
    57e4:	f949eec3 	ldr	x3, [x22, #5080]
    57e8:	f949dac1 	ldr	x1, [x22, #5040]
    57ec:	d370bc63 	lsl	x3, x3, #16
    57f0:	cb010282 	sub	x2, x20, x1
    57f4:	b7f81e85 	tbnz	x5, #63, 5bc4 <fwp_hof0.constprop.0+0xc60>
    57f8:	eb03005f 	cmp	x2, x3
    57fc:	54fffe62 	b.cs	57c8 <fwp_hof0.constprop.0+0x864>  // b.hs, b.nlast
    5800:	d350fc40 	lsr	x0, x2, #16
    5804:	8b000800 	add	x0, x0, x0, lsl #2
    5808:	d37df000 	lsl	x0, x0, #3
    580c:	8b000083 	add	x3, x4, x0
    5810:	f9401061 	ldr	x1, [x3, #32]
    5814:	b4fffda1 	cbz	x1, 57c8 <fwp_hof0.constprop.0+0x864>
    5818:	38606880 	ldrb	w0, [x4, x0]
    581c:	7100081f 	cmp	w0, #0x2
    5820:	54002240 	b.eq	5c68 <fwp_hof0.constprop.0+0xd04>  // b.none
    5824:	7100041f 	cmp	w0, #0x1
    5828:	54fffd01 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    582c:	92403c40 	and	x0, x2, #0xffff
    5830:	29430864 	ldp	w4, w2, [x3, #24]
    5834:	9b047c00 	mul	x0, x0, x4
    5838:	d360fc00 	lsr	x0, x0, #32
    583c:	eb02001f 	cmp	x0, x2
    5840:	54fffc42 	b.cs	57c8 <fwp_hof0.constprop.0+0x864>  // b.hs, b.nlast
    5844:	8b000021 	add	x1, x1, x0
    5848:	39400020 	ldrb	w0, [x1]
    584c:	7100041f 	cmp	w0, #0x1
    5850:	54fffbc1 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    5854:	aa1403e0 	mov	x0, x20
    5858:	97fff5ea 	bl	3000 <fwp_mem_free>
    585c:	b5fffb97 	cbnz	x23, 57cc <fwp_hof0.constprop.0+0x868>
    5860:	52800b63 	mov	w3, #0x5b                  	// #91
    5864:	9100bffc 	add	x28, sp, #0x2f
    5868:	9100c3f4 	add	x20, sp, #0x30
    586c:	aa1c03e1 	mov	x1, x28
    5870:	aa1403e0 	mov	x0, x20
    5874:	d2800022 	mov	x2, #0x1                   	// #1
    5878:	3900bfe3 	strb	w3, [sp, #47]
    587c:	d280001b 	mov	x27, #0x0                   	// #0
    5880:	a9037fff 	stp	xzr, xzr, [sp, #48]
    5884:	d00000d6 	adrp	x22, 1f000 <__FRAME_END__+0x14718>
    5888:	f90023ff 	str	xzr, [sp, #64]
    588c:	97fff221 	bl	2110 <buf_put>
    5890:	f94002a0 	ldr	x0, [x21]
    5894:	f240f818 	ands	x24, x0, #0x7fffffffffffffff
    5898:	540003c0 	b.eq	5910 <fwp_hof0.constprop.0+0x9ac>  // b.none
    589c:	912ca2d6 	add	x22, x22, #0xb28
    58a0:	90000037 	adrp	x23, 9000 <__divti3+0x2c0>
    58a4:	910142d6 	add	x22, x22, #0x50
    58a8:	912022f7 	add	x23, x23, #0x808
    58ac:	910022ba 	add	x26, x21, #0x8
    58b0:	1400000d 	b	58e4 <fwp_hof0.constprop.0+0x980>
    58b4:	f87b7821 	ldr	x1, [x1, x27, lsl #3]
    58b8:	aa1603e2 	mov	x2, x22
    58bc:	aa1403e0 	mov	x0, x20
    58c0:	9100077b 	add	x27, x27, #0x1
    58c4:	97fff9bf 	bl	3fc0 <fwp_write.constprop.0>
    58c8:	eb1b031f 	cmp	x24, x27
    58cc:	54000220 	b.eq	5910 <fwp_hof0.constprop.0+0x9ac>  // b.none
    58d0:	aa1403e0 	mov	x0, x20
    58d4:	aa1703e1 	mov	x1, x23
    58d8:	d2800042 	mov	x2, #0x2                   	// #2
    58dc:	97fff20d 	bl	2110 <buf_put>
    58e0:	f94002a0 	ldr	x0, [x21]
    58e4:	aa1a03e1 	mov	x1, x26
    58e8:	b6fffe60 	tbz	x0, #63, 58b4 <fwp_hof0.constprop.0+0x950>
    58ec:	f9400aa1 	ldr	x1, [x21, #16]
    58f0:	aa1603e2 	mov	x2, x22
    58f4:	aa1403e0 	mov	x0, x20
    58f8:	f87b7821 	ldr	x1, [x1, x27, lsl #3]
    58fc:	9100077b 	add	x27, x27, #0x1
    5900:	97fff9b0 	bl	3fc0 <fwp_write.constprop.0>
    5904:	eb1b031f 	cmp	x24, x27
    5908:	54fffe41 	b.ne	58d0 <fwp_hof0.constprop.0+0x96c>  // b.any
    590c:	d503201f 	nop
    5910:	52800ba3 	mov	w3, #0x5d                  	// #93
    5914:	aa1403e0 	mov	x0, x20
    5918:	aa1c03e1 	mov	x1, x28
    591c:	d2800022 	mov	x2, #0x1                   	// #1
    5920:	3900bfe3 	strb	w3, [sp, #47]
    5924:	97fff1fb 	bl	2110 <buf_put>
    5928:	a9435bf7 	ldp	x23, x22, [sp, #48]
    592c:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5930:	91128000 	add	x0, x0, #0x4a0
    5934:	f10002ff 	cmp	x23, #0x0
    5938:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    593c:	b1002adf 	cmn	x22, #0xa
    5940:	54003e88 	b.hi	6110 <fwp_hof0.constprop.0+0x11ac>  // b.pmore
    5944:	910026c0 	add	x0, x22, #0x9
    5948:	52800021 	mov	w1, #0x1                   	// #1
    594c:	97fff71e 	bl	35c4 <fwp_heap_alloc>
    5950:	aa0003f4 	mov	x20, x0
    5954:	aa1703e1 	mov	x1, x23
    5958:	aa0003f7 	mov	x23, x0
    595c:	aa1603e2 	mov	x2, x22
    5960:	f80086f6 	str	x22, [x23], #8
    5964:	8b160296 	add	x22, x20, x22
    5968:	aa1703e0 	mov	x0, x23
    596c:	97ffee7d 	bl	1360 <memcpy@plt>
    5970:	f9401be0 	ldr	x0, [sp, #48]
    5974:	390022df 	strb	wzr, [x22, #8]
    5978:	97ffef12 	bl	15c0 <free@plt>
    597c:	9115c262 	add	x2, x19, #0x570
    5980:	f949ec43 	ldr	x3, [x2, #5080]
    5984:	f949d841 	ldr	x1, [x2, #5040]
    5988:	d370bc63 	lsl	x3, x3, #16
    598c:	cb010284 	sub	x4, x20, x1
    5990:	eb03009f 	cmp	x4, x3
    5994:	540003a2 	b.cs	5a08 <fwp_hof0.constprop.0+0xaa4>  // b.hs, b.nlast
    5998:	d350fc80 	lsr	x0, x4, #16
    599c:	f949fc45 	ldr	x5, [x2, #5112]
    59a0:	8b000800 	add	x0, x0, x0, lsl #2
    59a4:	d37df002 	lsl	x2, x0, #3
    59a8:	8b0200a0 	add	x0, x5, x2
    59ac:	f9401016 	ldr	x22, [x0, #32]
    59b0:	b40002d6 	cbz	x22, 5a08 <fwp_hof0.constprop.0+0xaa4>
    59b4:	386268a2 	ldrb	w2, [x5, x2]
    59b8:	7100085f 	cmp	w2, #0x2
    59bc:	540027e0 	b.eq	5eb8 <fwp_hof0.constprop.0+0xf54>  // b.none
    59c0:	7100045f 	cmp	w2, #0x1
    59c4:	54000221 	b.ne	5a08 <fwp_hof0.constprop.0+0xaa4>  // b.any
    59c8:	29430005 	ldp	w5, w0, [x0, #24]
    59cc:	92403c82 	and	x2, x4, #0xffff
    59d0:	9b057c42 	mul	x2, x2, x5
    59d4:	d360fc42 	lsr	x2, x2, #32
    59d8:	eb00005f 	cmp	x2, x0
    59dc:	54000162 	b.cs	5a08 <fwp_hof0.constprop.0+0xaa4>  // b.hs, b.nlast
    59e0:	8b0202d6 	add	x22, x22, x2
    59e4:	394002c0 	ldrb	w0, [x22]
    59e8:	7103fc1f 	cmp	w0, #0xff
    59ec:	54002700 	b.eq	5ecc <fwp_hof0.constprop.0+0xf68>  // b.none
    59f0:	9115c260 	add	x0, x19, #0x570
    59f4:	52800021 	mov	w1, #0x1                   	// #1
    59f8:	390002c1 	strb	w1, [x22]
    59fc:	f949ec03 	ldr	x3, [x0, #5080]
    5a00:	f949d801 	ldr	x1, [x0, #5040]
    5a04:	d370bc63 	lsl	x3, x3, #16
    5a08:	cb0102a1 	sub	x1, x21, x1
    5a0c:	9115c278 	add	x24, x19, #0x570
    5a10:	eb03003f 	cmp	x1, x3
    5a14:	540003a2 	b.cs	5a88 <fwp_hof0.constprop.0+0xb24>  // b.hs, b.nlast
    5a18:	d350fc20 	lsr	x0, x1, #16
    5a1c:	f949ff03 	ldr	x3, [x24, #5112]
    5a20:	8b000800 	add	x0, x0, x0, lsl #2
    5a24:	d37df002 	lsl	x2, x0, #3
    5a28:	8b020060 	add	x0, x3, x2
    5a2c:	f9401016 	ldr	x22, [x0, #32]
    5a30:	b40002d6 	cbz	x22, 5a88 <fwp_hof0.constprop.0+0xb24>
    5a34:	38626862 	ldrb	w2, [x3, x2]
    5a38:	7100085f 	cmp	w2, #0x2
    5a3c:	54001c60 	b.eq	5dc8 <fwp_hof0.constprop.0+0xe64>  // b.none
    5a40:	7100045f 	cmp	w2, #0x1
    5a44:	54000221 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5a48:	29430002 	ldp	w2, w0, [x0, #24]
    5a4c:	92403c21 	and	x1, x1, #0xffff
    5a50:	9b027c21 	mul	x1, x1, x2
    5a54:	d360fc21 	lsr	x1, x1, #32
    5a58:	eb00003f 	cmp	x1, x0
    5a5c:	54000162 	b.cs	5a88 <fwp_hof0.constprop.0+0xb24>  // b.hs, b.nlast
    5a60:	8b0102d6 	add	x22, x22, x1
    5a64:	394002c0 	ldrb	w0, [x22]
    5a68:	34000100 	cbz	w0, 5a88 <fwp_hof0.constprop.0+0xb24>
    5a6c:	7100041f 	cmp	w0, #0x1
    5a70:	54001020 	b.eq	5c74 <fwp_hof0.constprop.0+0xd10>  // b.none
    5a74:	7103fc1f 	cmp	w0, #0xff
    5a78:	54002600 	b.eq	5f38 <fwp_hof0.constprop.0+0xfd4>  // b.none
    5a7c:	51000400 	sub	w0, w0, #0x1
    5a80:	390002c0 	strb	w0, [x22]
    5a84:	d503201f 	nop
    5a88:	f00000d5 	adrp	x21, 20000 <__data_start>
    5a8c:	d2800021 	mov	x1, #0x1                   	// #1
    5a90:	f9400282 	ldr	x2, [x20]
    5a94:	aa1703e0 	mov	x0, x23
    5a98:	f9404aa3 	ldr	x3, [x21, #144]
    5a9c:	97ffeed9 	bl	1600 <fwrite@plt>
    5aa0:	f9404aa1 	ldr	x1, [x21, #144]
    5aa4:	52800140 	mov	w0, #0xa                   	// #10
    5aa8:	97ffee5e 	bl	1420 <fputc@plt>
    5aac:	9115c262 	add	x2, x19, #0x570
    5ab0:	f949d841 	ldr	x1, [x2, #5040]
    5ab4:	f949ec40 	ldr	x0, [x2, #5080]
    5ab8:	cb010281 	sub	x1, x20, x1
    5abc:	eb00403f 	cmp	x1, x0, lsl #16
    5ac0:	54000382 	b.cs	5b30 <fwp_hof0.constprop.0+0xbcc>  // b.hs, b.nlast
    5ac4:	d350fc20 	lsr	x0, x1, #16
    5ac8:	f949fc43 	ldr	x3, [x2, #5112]
    5acc:	8b000800 	add	x0, x0, x0, lsl #2
    5ad0:	d37df002 	lsl	x2, x0, #3
    5ad4:	8b020060 	add	x0, x3, x2
    5ad8:	f9401015 	ldr	x21, [x0, #32]
    5adc:	b40002b5 	cbz	x21, 5b30 <fwp_hof0.constprop.0+0xbcc>
    5ae0:	38626862 	ldrb	w2, [x3, x2]
    5ae4:	7100085f 	cmp	w2, #0x2
    5ae8:	54001f80 	b.eq	5ed8 <fwp_hof0.constprop.0+0xf74>  // b.none
    5aec:	7100045f 	cmp	w2, #0x1
    5af0:	54000201 	b.ne	5b30 <fwp_hof0.constprop.0+0xbcc>  // b.any
    5af4:	29430002 	ldp	w2, w0, [x0, #24]
    5af8:	92403c21 	and	x1, x1, #0xffff
    5afc:	9b027c21 	mul	x1, x1, x2
    5b00:	d360fc21 	lsr	x1, x1, #32
    5b04:	eb00003f 	cmp	x1, x0
    5b08:	54000142 	b.cs	5b30 <fwp_hof0.constprop.0+0xbcc>  // b.hs, b.nlast
    5b0c:	8b0102b5 	add	x21, x21, x1
    5b10:	394002a0 	ldrb	w0, [x21]
    5b14:	340000e0 	cbz	w0, 5b30 <fwp_hof0.constprop.0+0xbcc>
    5b18:	7100041f 	cmp	w0, #0x1
    5b1c:	54001ea0 	b.eq	5ef0 <fwp_hof0.constprop.0+0xf8c>  // b.none
    5b20:	7103fc1f 	cmp	w0, #0xff
    5b24:	540026e0 	b.eq	6000 <fwp_hof0.constprop.0+0x109c>  // b.none
    5b28:	51000400 	sub	w0, w0, #0x1
    5b2c:	390002a0 	strb	w0, [x21]
    5b30:	f9400fe0 	ldr	x0, [sp, #24]
    5b34:	f9400800 	ldr	x0, [x0, #16]
    5b38:	f9000fe0 	str	x0, [sp, #24]
    5b3c:	b5ffa460 	cbnz	x0, 4fc8 <fwp_hof0.constprop.0+0x64>
    5b40:	a94853f3 	ldp	x19, x20, [sp, #128]
    5b44:	a9495bf5 	ldp	x21, x22, [sp, #144]
    5b48:	a94a63f7 	ldp	x23, x24, [sp, #160]
    5b4c:	a94b6bf9 	ldp	x25, x26, [sp, #176]
    5b50:	a94c73fb 	ldp	x27, x28, [sp, #192]
    5b54:	6d4d27e8 	ldp	d8, d9, [sp, #208]
    5b58:	6d4e2fea 	ldp	d10, d11, [sp, #224]
    5b5c:	6d4f37ec 	ldp	d12, d13, [sp, #240]
    5b60:	6d503fee 	ldp	d14, d15, [sp, #256]
    5b64:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    5b68:	f947f400 	ldr	x0, [x0, #4072]
    5b6c:	f94037e2 	ldr	x2, [sp, #104]
    5b70:	f9400001 	ldr	x1, [x0]
    5b74:	eb010042 	subs	x2, x2, x1
    5b78:	d2800001 	mov	x1, #0x0                   	// #0
    5b7c:	54002b61 	b.ne	60e8 <fwp_hof0.constprop.0+0x1184>  // b.any
    5b80:	a9477bfd 	ldp	x29, x30, [sp, #112]
    5b84:	d2800000 	mov	x0, #0x0                   	// #0
    5b88:	910443ff 	add	sp, sp, #0x110
    5b8c:	d65f03c0 	ret
    5b90:	f9400a80 	ldr	x0, [x20, #16]
    5b94:	17fffde6 	b	532c <fwp_hof0.constprop.0+0x3c8>
    5b98:	f9400a82 	ldr	x2, [x20, #16]
    5b9c:	17fffe27 	b	5438 <fwp_hof0.constprop.0+0x4d4>
    5ba0:	f90003e0 	str	x0, [sp]
    5ba4:	f9000be8 	str	x8, [sp, #16]
    5ba8:	97fff477 	bl	2d84 <fwp_rc_forget_slot>
    5bac:	f94003e0 	ldr	x0, [sp]
    5bb0:	f9400be8 	ldr	x8, [sp, #16]
    5bb4:	17fffe44 	b	54c4 <fwp_hof0.constprop.0+0x560>
    5bb8:	72003c3f 	tst	w1, #0xffff
    5bbc:	54ffe061 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    5bc0:	17fffef9 	b	57a4 <fwp_hof0.constprop.0+0x840>
    5bc4:	f9400694 	ldr	x20, [x20, #8]
    5bc8:	eb03005f 	cmp	x2, x3
    5bcc:	54000362 	b.cs	5c38 <fwp_hof0.constprop.0+0xcd4>  // b.hs, b.nlast
    5bd0:	d350fc45 	lsr	x5, x2, #16
    5bd4:	8b0508a5 	add	x5, x5, x5, lsl #2
    5bd8:	d37df0a5 	lsl	x5, x5, #3
    5bdc:	8b050087 	add	x7, x4, x5
    5be0:	f94010e6 	ldr	x6, [x7, #32]
    5be4:	b40002a6 	cbz	x6, 5c38 <fwp_hof0.constprop.0+0xcd4>
    5be8:	38656884 	ldrb	w4, [x4, x5]
    5bec:	7100089f 	cmp	w4, #0x2
    5bf0:	54000de0 	b.eq	5dac <fwp_hof0.constprop.0+0xe48>  // b.none
    5bf4:	7100049f 	cmp	w4, #0x1
    5bf8:	54000201 	b.ne	5c38 <fwp_hof0.constprop.0+0xcd4>  // b.any
    5bfc:	294310e5 	ldp	w5, w4, [x7, #24]
    5c00:	92403c42 	and	x2, x2, #0xffff
    5c04:	9b057c42 	mul	x2, x2, x5
    5c08:	d360fc42 	lsr	x2, x2, #32
    5c0c:	eb04005f 	cmp	x2, x4
    5c10:	54000142 	b.cs	5c38 <fwp_hof0.constprop.0+0xcd4>  // b.hs, b.nlast
    5c14:	8b0200c6 	add	x6, x6, x2
    5c18:	394000c2 	ldrb	w2, [x6]
    5c1c:	7100045f 	cmp	w2, #0x1
    5c20:	540000c1 	b.ne	5c38 <fwp_hof0.constprop.0+0xcd4>  // b.any
    5c24:	97fff4f7 	bl	3000 <fwp_mem_free>
    5c28:	9115c260 	add	x0, x19, #0x570
    5c2c:	f949ec03 	ldr	x3, [x0, #5080]
    5c30:	f949d801 	ldr	x1, [x0, #5040]
    5c34:	d370bc63 	lsl	x3, x3, #16
    5c38:	cb010281 	sub	x1, x20, x1
    5c3c:	eb01007f 	cmp	x3, x1
    5c40:	54ffd8c8 	b.hi	5758 <fwp_hof0.constprop.0+0x7f4>  // b.pmore
    5c44:	17fffee1 	b	57c8 <fwp_hof0.constprop.0+0x864>
    5c48:	72003c3f 	tst	w1, #0xffff
    5c4c:	54ffb601 	b.ne	530c <fwp_hof0.constprop.0+0x3a8>  // b.any
    5c50:	39400300 	ldrb	w0, [x24]
    5c54:	7103fc1f 	cmp	w0, #0xff
    5c58:	54ffb561 	b.ne	5304 <fwp_hof0.constprop.0+0x3a0>  // b.any
    5c5c:	aa1803e0 	mov	x0, x24
    5c60:	97fff449 	bl	2d84 <fwp_rc_forget_slot>
    5c64:	17fffda8 	b	5304 <fwp_hof0.constprop.0+0x3a0>
    5c68:	72003c5f 	tst	w2, #0xffff
    5c6c:	54ffdae1 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    5c70:	17fffef6 	b	5848 <fwp_hof0.constprop.0+0x8e4>
    5c74:	f94002a0 	ldr	x0, [x21]
    5c78:	b7f80ae0 	tbnz	x0, #63, 5dd4 <fwp_hof0.constprop.0+0xe70>
    5c7c:	9115c261 	add	x1, x19, #0x570
    5c80:	f949d820 	ldr	x0, [x1, #5040]
    5c84:	f949ec21 	ldr	x1, [x1, #5080]
    5c88:	cb0002a0 	sub	x0, x21, x0
    5c8c:	eb01401f 	cmp	x0, x1, lsl #16
    5c90:	54ffefc2 	b.cs	5a88 <fwp_hof0.constprop.0+0xb24>  // b.hs, b.nlast
    5c94:	d350fc01 	lsr	x1, x0, #16
    5c98:	8b010821 	add	x1, x1, x1, lsl #2
    5c9c:	d37df021 	lsl	x1, x1, #3
    5ca0:	8b010064 	add	x4, x3, x1
    5ca4:	f9401082 	ldr	x2, [x4, #32]
    5ca8:	b4ffef02 	cbz	x2, 5a88 <fwp_hof0.constprop.0+0xb24>
    5cac:	38616861 	ldrb	w1, [x3, x1]
    5cb0:	7100083f 	cmp	w1, #0x2
    5cb4:	54001240 	b.eq	5efc <fwp_hof0.constprop.0+0xf98>  // b.none
    5cb8:	7100043f 	cmp	w1, #0x1
    5cbc:	54ffee61 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5cc0:	29430483 	ldp	w3, w1, [x4, #24]
    5cc4:	92403c00 	and	x0, x0, #0xffff
    5cc8:	9b037c00 	mul	x0, x0, x3
    5ccc:	d360fc00 	lsr	x0, x0, #32
    5cd0:	eb01001f 	cmp	x0, x1
    5cd4:	54ffeda2 	b.cs	5a88 <fwp_hof0.constprop.0+0xb24>  // b.hs, b.nlast
    5cd8:	8b000042 	add	x2, x2, x0
    5cdc:	39400040 	ldrb	w0, [x2]
    5ce0:	7100041f 	cmp	w0, #0x1
    5ce4:	54ffed21 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5ce8:	aa1503e0 	mov	x0, x21
    5cec:	97fff4c5 	bl	3000 <fwp_mem_free>
    5cf0:	17ffff66 	b	5a88 <fwp_hof0.constprop.0+0xb24>
    5cf4:	ca404401 	eor	x1, x0, x0, lsr #17
    5cf8:	9115c263 	add	x3, x19, #0x570
    5cfc:	ca412421 	eor	x1, x1, x1, lsr #9
    5d00:	8b210c61 	add	x1, x3, w1, uxtb #3
    5d04:	f94a2421 	ldr	x1, [x1, #5192]
    5d08:	b5000081 	cbnz	x1, 5d18 <fwp_hof0.constprop.0+0xdb4>
    5d0c:	140000d9 	b	6070 <fwp_hof0.constprop.0+0x110c>
    5d10:	f9400821 	ldr	x1, [x1, #16]
    5d14:	b4001ae1 	cbz	x1, 6070 <fwp_hof0.constprop.0+0x110c>
    5d18:	f9400023 	ldr	x3, [x1]
    5d1c:	eb00007f 	cmp	x3, x0
    5d20:	54ffff81 	b.ne	5d10 <fwp_hof0.constprop.0+0xdac>  // b.any
    5d24:	f9400423 	ldr	x3, [x1, #8]
    5d28:	d1000463 	sub	x3, x3, #0x1
    5d2c:	f9000423 	str	x3, [x1, #8]
    5d30:	f103f87f 	cmp	x3, #0xfe
    5d34:	54000ea0 	b.eq	5f08 <fwp_hof0.constprop.0+0xfa4>  // b.none
    5d38:	fd400722 	ldr	d2, [x25, #8]
    5d3c:	fd400b24 	ldr	d4, [x25, #16]
    5d40:	17fffe14 	b	5590 <fwp_hof0.constprop.0+0x62c>
    5d44:	ca414420 	eor	x0, x1, x1, lsr #17
    5d48:	9115c262 	add	x2, x19, #0x570
    5d4c:	ca402400 	eor	x0, x0, x0, lsr #9
    5d50:	8b200c40 	add	x0, x2, w0, uxtb #3
    5d54:	f94a2400 	ldr	x0, [x0, #5192]
    5d58:	b5000080 	cbnz	x0, 5d68 <fwp_hof0.constprop.0+0xe04>
    5d5c:	140000c5 	b	6070 <fwp_hof0.constprop.0+0x110c>
    5d60:	f9400800 	ldr	x0, [x0, #16]
    5d64:	b4001860 	cbz	x0, 6070 <fwp_hof0.constprop.0+0x110c>
    5d68:	f9400002 	ldr	x2, [x0]
    5d6c:	eb01005f 	cmp	x2, x1
    5d70:	54ffff81 	b.ne	5d60 <fwp_hof0.constprop.0+0xdfc>  // b.any
    5d74:	f9400402 	ldr	x2, [x0, #8]
    5d78:	d1000442 	sub	x2, x2, #0x1
    5d7c:	f9000402 	str	x2, [x0, #8]
    5d80:	f103f85f 	cmp	x2, #0xfe
    5d84:	54ffc4a1 	b.ne	5618 <fwp_hof0.constprop.0+0x6b4>  // b.any
    5d88:	aa0103e0 	mov	x0, x1
    5d8c:	f90003e1 	str	x1, [sp]
    5d90:	fd000be4 	str	d4, [sp, #16]
    5d94:	97fff3fc 	bl	2d84 <fwp_rc_forget_slot>
    5d98:	f94003e1 	ldr	x1, [sp]
    5d9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5da0:	fd400be4 	ldr	d4, [sp, #16]
    5da4:	39000020 	strb	w0, [x1]
    5da8:	17fffe1c 	b	5618 <fwp_hof0.constprop.0+0x6b4>
    5dac:	72003c5f 	tst	w2, #0xffff
    5db0:	54fff441 	b.ne	5c38 <fwp_hof0.constprop.0+0xcd4>  // b.any
    5db4:	17ffff99 	b	5c18 <fwp_hof0.constprop.0+0xcb4>
    5db8:	72003c7f 	tst	w3, #0xffff
    5dbc:	54ffa480 	b.eq	524c <fwp_hof0.constprop.0+0x2e8>  // b.none
    5dc0:	aa1503e0 	mov	x0, x21
    5dc4:	17fffd26 	b	525c <fwp_hof0.constprop.0+0x2f8>
    5dc8:	72003c3f 	tst	w1, #0xffff
    5dcc:	54ffe5e1 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5dd0:	17ffff25 	b	5a64 <fwp_hof0.constprop.0+0xb00>
    5dd4:	f94006b6 	ldr	x22, [x21, #8]
    5dd8:	aa1503e0 	mov	x0, x21
    5ddc:	97fff5d9 	bl	3540 <fwp_rc_free_arr>
    5de0:	9115c260 	add	x0, x19, #0x570
    5de4:	f949d801 	ldr	x1, [x0, #5040]
    5de8:	f949ec00 	ldr	x0, [x0, #5080]
    5dec:	cb0102c1 	sub	x1, x22, x1
    5df0:	eb00403f 	cmp	x1, x0, lsl #16
    5df4:	54ffe4a2 	b.cs	5a88 <fwp_hof0.constprop.0+0xb24>  // b.hs, b.nlast
    5df8:	aa1603f5 	mov	x21, x22
    5dfc:	17ffff07 	b	5a18 <fwp_hof0.constprop.0+0xab4>
    5e00:	72003c1f 	tst	w0, #0xffff
    5e04:	54ff9160 	b.eq	5030 <fwp_hof0.constprop.0+0xcc>  // b.none
    5e08:	f94007e0 	ldr	x0, [sp, #8]
    5e0c:	b5ff9300 	cbnz	x0, 506c <fwp_hof0.constprop.0+0x108>
    5e10:	d2800000 	mov	x0, #0x0                   	// #0
    5e14:	97fff6ac 	bl	38c4 <fwp_array_new_packed.constprop.0>
    5e18:	9115c261 	add	x1, x19, #0x570
    5e1c:	aa0003f4 	mov	x20, x0
    5e20:	aa0103e0 	mov	x0, x1
    5e24:	f949d821 	ldr	x1, [x1, #5040]
    5e28:	f949ec00 	ldr	x0, [x0, #5080]
    5e2c:	cb010281 	sub	x1, x20, x1
    5e30:	eb00403f 	cmp	x1, x0, lsl #16
    5e34:	54ff9403 	b.cc	50b4 <fwp_hof0.constprop.0+0x150>  // b.lo, b.ul, b.last
    5e38:	d2800000 	mov	x0, #0x0                   	// #0
    5e3c:	17fffd0b 	b	5268 <fwp_hof0.constprop.0+0x304>
    5e40:	72003c3f 	tst	w1, #0xffff
    5e44:	54ff96a1 	b.ne	5118 <fwp_hof0.constprop.0+0x1b4>  // b.any
    5e48:	394002a0 	ldrb	w0, [x21]
    5e4c:	7103fc1f 	cmp	w0, #0xff
    5e50:	54ff9601 	b.ne	5110 <fwp_hof0.constprop.0+0x1ac>  // b.any
    5e54:	aa1503e0 	mov	x0, x21
    5e58:	97fff3cb 	bl	2d84 <fwp_rc_forget_slot>
    5e5c:	17fffcad 	b	5110 <fwp_hof0.constprop.0+0x1ac>
    5e60:	ca584700 	eor	x0, x24, x24, lsr #17
    5e64:	9115c261 	add	x1, x19, #0x570
    5e68:	ca402400 	eor	x0, x0, x0, lsr #9
    5e6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5e70:	f94a2400 	ldr	x0, [x0, #5192]
    5e74:	b5000080 	cbnz	x0, 5e84 <fwp_hof0.constprop.0+0xf20>
    5e78:	1400007e 	b	6070 <fwp_hof0.constprop.0+0x110c>
    5e7c:	f9400800 	ldr	x0, [x0, #16]
    5e80:	b4000f80 	cbz	x0, 6070 <fwp_hof0.constprop.0+0x110c>
    5e84:	f9400001 	ldr	x1, [x0]
    5e88:	eb01031f 	cmp	x24, x1
    5e8c:	54ffff81 	b.ne	5e7c <fwp_hof0.constprop.0+0xf18>  // b.any
    5e90:	f9400401 	ldr	x1, [x0, #8]
    5e94:	d1000421 	sub	x1, x1, #0x1
    5e98:	f9000401 	str	x1, [x0, #8]
    5e9c:	f103f83f 	cmp	x1, #0xfe
    5ea0:	54ffc941 	b.ne	57c8 <fwp_hof0.constprop.0+0x864>  // b.any
    5ea4:	aa1803e0 	mov	x0, x24
    5ea8:	97fff3b7 	bl	2d84 <fwp_rc_forget_slot>
    5eac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5eb0:	39000300 	strb	w0, [x24]
    5eb4:	17fffe45 	b	57c8 <fwp_hof0.constprop.0+0x864>
    5eb8:	72003c9f 	tst	w4, #0xffff
    5ebc:	54ffda61 	b.ne	5a08 <fwp_hof0.constprop.0+0xaa4>  // b.any
    5ec0:	394002c0 	ldrb	w0, [x22]
    5ec4:	7103fc1f 	cmp	w0, #0xff
    5ec8:	54ffd941 	b.ne	59f0 <fwp_hof0.constprop.0+0xa8c>  // b.any
    5ecc:	aa1603e0 	mov	x0, x22
    5ed0:	97fff3ad 	bl	2d84 <fwp_rc_forget_slot>
    5ed4:	17fffec7 	b	59f0 <fwp_hof0.constprop.0+0xa8c>
    5ed8:	72003c3f 	tst	w1, #0xffff
    5edc:	54ffe2a1 	b.ne	5b30 <fwp_hof0.constprop.0+0xbcc>  // b.any
    5ee0:	394002a0 	ldrb	w0, [x21]
    5ee4:	34ffe260 	cbz	w0, 5b30 <fwp_hof0.constprop.0+0xbcc>
    5ee8:	7100041f 	cmp	w0, #0x1
    5eec:	54ffe1a1 	b.ne	5b20 <fwp_hof0.constprop.0+0xbbc>  // b.any
    5ef0:	aa1403e0 	mov	x0, x20
    5ef4:	97fff443 	bl	3000 <fwp_mem_free>
    5ef8:	17ffff0e 	b	5b30 <fwp_hof0.constprop.0+0xbcc>
    5efc:	72003c1f 	tst	w0, #0xffff
    5f00:	54ffdc41 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5f04:	17ffff76 	b	5cdc <fwp_hof0.constprop.0+0xd78>
    5f08:	f90003e0 	str	x0, [sp]
    5f0c:	97fff39e 	bl	2d84 <fwp_rc_forget_slot>
    5f10:	f94003e0 	ldr	x0, [sp]
    5f14:	9115c261 	add	x1, x19, #0x570
    5f18:	12800022 	mov	w2, #0xfffffffe            	// #-2
    5f1c:	39000002 	strb	w2, [x0]
    5f20:	f949ec26 	ldr	x6, [x1, #5080]
    5f24:	fd400722 	ldr	d2, [x25, #8]
    5f28:	fd400b24 	ldr	d4, [x25, #16]
    5f2c:	d370bcc6 	lsl	x6, x6, #16
    5f30:	f949d822 	ldr	x2, [x1, #5040]
    5f34:	17fffd97 	b	5590 <fwp_hof0.constprop.0+0x62c>
    5f38:	ca5646c0 	eor	x0, x22, x22, lsr #17
    5f3c:	9115c261 	add	x1, x19, #0x570
    5f40:	ca402400 	eor	x0, x0, x0, lsr #9
    5f44:	8b200c20 	add	x0, x1, w0, uxtb #3
    5f48:	f94a2400 	ldr	x0, [x0, #5192]
    5f4c:	b4000920 	cbz	x0, 6070 <fwp_hof0.constprop.0+0x110c>
    5f50:	f9400001 	ldr	x1, [x0]
    5f54:	eb16003f 	cmp	x1, x22
    5f58:	540000c0 	b.eq	5f70 <fwp_hof0.constprop.0+0x100c>  // b.none
    5f5c:	f9400800 	ldr	x0, [x0, #16]
    5f60:	b4000880 	cbz	x0, 6070 <fwp_hof0.constprop.0+0x110c>
    5f64:	f9400001 	ldr	x1, [x0]
    5f68:	eb16003f 	cmp	x1, x22
    5f6c:	54ffff81 	b.ne	5f5c <fwp_hof0.constprop.0+0xff8>  // b.any
    5f70:	f9400401 	ldr	x1, [x0, #8]
    5f74:	d1000421 	sub	x1, x1, #0x1
    5f78:	f9000401 	str	x1, [x0, #8]
    5f7c:	f103f83f 	cmp	x1, #0xfe
    5f80:	54ffd841 	b.ne	5a88 <fwp_hof0.constprop.0+0xb24>  // b.any
    5f84:	aa1603e0 	mov	x0, x22
    5f88:	97fff37f 	bl	2d84 <fwp_rc_forget_slot>
    5f8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f90:	390002c0 	strb	w0, [x22]
    5f94:	17fffebd 	b	5a88 <fwp_hof0.constprop.0+0xb24>
    5f98:	ca544681 	eor	x1, x20, x20, lsr #17
    5f9c:	9115c262 	add	x2, x19, #0x570
    5fa0:	ca412421 	eor	x1, x1, x1, lsr #9
    5fa4:	92401c21 	and	x1, x1, #0xff
    5fa8:	910a2423 	add	x3, x1, #0x289
    5fac:	8b010c41 	add	x1, x2, x1, lsl #3
    5fb0:	8b030c55 	add	x21, x2, x3, lsl #3
    5fb4:	f94a2421 	ldr	x1, [x1, #5192]
    5fb8:	b50000a1 	cbnz	x1, 5fcc <fwp_hof0.constprop.0+0x1068>
    5fbc:	14000048 	b	60dc <fwp_hof0.constprop.0+0x1178>
    5fc0:	91004035 	add	x21, x1, #0x10
    5fc4:	f9400821 	ldr	x1, [x1, #16]
    5fc8:	b40004e1 	cbz	x1, 6064 <fwp_hof0.constprop.0+0x1100>
    5fcc:	f9400022 	ldr	x2, [x1]
    5fd0:	eb14005f 	cmp	x2, x20
    5fd4:	54ffff61 	b.ne	5fc0 <fwp_hof0.constprop.0+0x105c>  // b.any
    5fd8:	f94002a1 	ldr	x1, [x21]
    5fdc:	7103f81f 	cmp	w0, #0xfe
    5fe0:	540006a0 	b.eq	60b4 <fwp_hof0.constprop.0+0x1150>  // b.none
    5fe4:	b4000461 	cbz	x1, 6070 <fwp_hof0.constprop.0+0x110c>
    5fe8:	f9400420 	ldr	x0, [x1, #8]
    5fec:	b100041f 	cmn	x0, #0x1
    5ff0:	54000700 	b.eq	60d0 <fwp_hof0.constprop.0+0x116c>  // b.none
    5ff4:	91000400 	add	x0, x0, #0x1
    5ff8:	f9000420 	str	x0, [x1, #8]
    5ffc:	17fffc1a 	b	5064 <fwp_hof0.constprop.0+0x100>
    6000:	ca5546a0 	eor	x0, x21, x21, lsr #17
    6004:	9115c261 	add	x1, x19, #0x570
    6008:	ca402400 	eor	x0, x0, x0, lsr #9
    600c:	8b200c20 	add	x0, x1, w0, uxtb #3
    6010:	f94a2400 	ldr	x0, [x0, #5192]
    6014:	b5000080 	cbnz	x0, 6024 <fwp_hof0.constprop.0+0x10c0>
    6018:	14000016 	b	6070 <fwp_hof0.constprop.0+0x110c>
    601c:	f9400800 	ldr	x0, [x0, #16]
    6020:	b4000280 	cbz	x0, 6070 <fwp_hof0.constprop.0+0x110c>
    6024:	f9400001 	ldr	x1, [x0]
    6028:	eb15003f 	cmp	x1, x21
    602c:	54ffff81 	b.ne	601c <fwp_hof0.constprop.0+0x10b8>  // b.any
    6030:	f9400401 	ldr	x1, [x0, #8]
    6034:	d1000421 	sub	x1, x1, #0x1
    6038:	f9000401 	str	x1, [x0, #8]
    603c:	f103f83f 	cmp	x1, #0xfe
    6040:	54ffd781 	b.ne	5b30 <fwp_hof0.constprop.0+0xbcc>  // b.any
    6044:	aa1503e0 	mov	x0, x21
    6048:	97fff34f 	bl	2d84 <fwp_rc_forget_slot>
    604c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6050:	390002a0 	strb	w0, [x21]
    6054:	17fffeb7 	b	5b30 <fwp_hof0.constprop.0+0xbcc>
    6058:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    605c:	91226000 	add	x0, x0, #0x898
    6060:	97fff088 	bl	2280 <fwp_trap>
    6064:	7103f81f 	cmp	w0, #0xfe
    6068:	540000a0 	b.eq	607c <fwp_hof0.constprop.0+0x1118>  // b.none
    606c:	d503201f 	nop
    6070:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6074:	911c6000 	add	x0, x0, #0x718
    6078:	97fff082 	bl	2280 <fwp_trap>
    607c:	d2800300 	mov	x0, #0x18                  	// #24
    6080:	97ffed08 	bl	14a0 <malloc@plt>
    6084:	b4000300 	cbz	x0, 60e4 <fwp_hof0.constprop.0+0x1180>
    6088:	d2801fe1 	mov	x1, #0xff                  	// #255
    608c:	a9000414 	stp	x20, x1, [x0]
    6090:	9115c261 	add	x1, x19, #0x570
    6094:	f900081f 	str	xzr, [x0, #16]
    6098:	12800002 	mov	w2, #0xffffffff            	// #-1
    609c:	f90002a0 	str	x0, [x21]
    60a0:	39000282 	strb	w2, [x20]
    60a4:	f94e2420 	ldr	x0, [x1, #7240]
    60a8:	91000400 	add	x0, x0, #0x1
    60ac:	f90e2420 	str	x0, [x1, #7240]
    60b0:	17fffbed 	b	5064 <fwp_hof0.constprop.0+0x100>
    60b4:	b4fffe41 	cbz	x1, 607c <fwp_hof0.constprop.0+0x1118>
    60b8:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    60bc:	91214000 	add	x0, x0, #0x850
    60c0:	97fff070 	bl	2280 <fwp_trap>
    60c4:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    60c8:	911d0000 	add	x0, x0, #0x740
    60cc:	97fff06d 	bl	2280 <fwp_trap>
    60d0:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    60d4:	9121e000 	add	x0, x0, #0x878
    60d8:	97fff06a 	bl	2280 <fwp_trap>
    60dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    60e0:	17ffffbf 	b	5fdc <fwp_hof0.constprop.0+0x1078>
    60e4:	97ffeefb 	bl	1cd0 <fwp_heap_oom>
    60e8:	a90853f3 	stp	x19, x20, [sp, #128]
    60ec:	a9095bf5 	stp	x21, x22, [sp, #144]
    60f0:	a90a63f7 	stp	x23, x24, [sp, #160]
    60f4:	a90b6bf9 	stp	x25, x26, [sp, #176]
    60f8:	a90c73fb 	stp	x27, x28, [sp, #192]
    60fc:	6d0d27e8 	stp	d8, d9, [sp, #208]
    6100:	6d0e2fea 	stp	d10, d11, [sp, #224]
    6104:	6d0f37ec 	stp	d12, d13, [sp, #240]
    6108:	6d103fee 	stp	d14, d15, [sp, #256]
    610c:	97ffecfd 	bl	1500 <__stack_chk_fail@plt>
    6110:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6114:	91230000 	add	x0, x0, #0x8c0
    6118:	97fff05a 	bl	2280 <fwp_trap>
    611c:	97ffed79 	bl	1700 <fwp_trap_overflow.constprop.0>

0000000000006120 <f0>:
    6120:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    6124:	910003fd 	mov	x29, sp
    6128:	a90153f3 	stp	x19, x20, [sp, #16]
    612c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6130:	a90363f7 	stp	x23, x24, [sp, #48]
    6134:	a9046bf9 	stp	x25, x26, [sp, #64]
    6138:	a90573fb 	stp	x27, x28, [sp, #80]
    613c:	d12183ff 	sub	sp, sp, #0x860
    6140:	f90203ff 	str	xzr, [sp, #1024]
    6144:	d00000c0 	adrp	x0, 20000 <__data_start>
    6148:	91024005 	add	x5, x0, #0x90
    614c:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    6150:	f947f400 	ldr	x0, [x0, #4072]
    6154:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc70>
    6158:	f94148a6 	ldr	x6, [x5, #656]
    615c:	f9400001 	ldr	x1, [x0]
    6160:	f9042fe1 	str	x1, [sp, #2136]
    6164:	d2800001 	mov	x1, #0x0                   	// #0
    6168:	9115c298 	add	x24, x20, #0x570
    616c:	912123f6 	add	x22, sp, #0x848
    6170:	910023e0 	add	x0, sp, #0x8
    6174:	910083e2 	add	x2, sp, #0x20
    6178:	b0ffffe1 	adrp	x1, 3000 <fwp_mem_free>
    617c:	f0ffffc4 	adrp	x4, 1000 <__abi_tag+0xd88>
    6180:	91244021 	add	x1, x1, #0x910
    6184:	912e4084 	add	x4, x4, #0xb90
    6188:	d2800013 	mov	x19, #0x0                   	// #0
    618c:	d2800119 	mov	x25, #0x8                   	// #8
    6190:	d2800015 	mov	x21, #0x0                   	// #0
    6194:	52800037 	mov	w23, #0x1                   	// #1
    6198:	a90093e6 	stp	x6, x4, [sp, #8]
    619c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    61a0:	a90307ff 	stp	xzr, x1, [sp, #48]
    61a4:	f90148a0 	str	x0, [x5, #656]
    61a8:	f100073a 	subs	x26, x25, #0x1
    61ac:	aa1603e1 	mov	x1, x22
    61b0:	da1f02bc 	sbc	x28, x21, xzr
    61b4:	52800020 	mov	w0, #0x1                   	// #1
    61b8:	f90017fa 	str	x26, [sp, #40]
    61bc:	aa1a03f9 	mov	x25, x26
    61c0:	f90427fa 	str	x26, [sp, #2120]
    61c4:	aa1c03f5 	mov	x21, x28
    61c8:	f9042bf3 	str	x19, [sp, #2128]
    61cc:	97fff561 	bl	3750 <fwp_data.part.0.constprop.0>
    61d0:	f949db02 	ldr	x2, [x24, #5040]
    61d4:	aa0003f3 	mov	x19, x0
    61d8:	f949ef00 	ldr	x0, [x24, #5080]
    61dc:	cb020262 	sub	x2, x19, x2
    61e0:	eb00405f 	cmp	x2, x0, lsl #16
    61e4:	54000302 	b.cs	6244 <f0+0x124>  // b.hs, b.nlast
    61e8:	d350fc40 	lsr	x0, x2, #16
    61ec:	f949ff04 	ldr	x4, [x24, #5112]
    61f0:	8b000800 	add	x0, x0, x0, lsl #2
    61f4:	d37df001 	lsl	x1, x0, #3
    61f8:	8b010080 	add	x0, x4, x1
    61fc:	f940101b 	ldr	x27, [x0, #32]
    6200:	b400023b 	cbz	x27, 6244 <f0+0x124>
    6204:	38616881 	ldrb	w1, [x4, x1]
    6208:	7100083f 	cmp	w1, #0x2
    620c:	54010e60 	b.eq	83d8 <f0+0x22b8>  // b.none
    6210:	7100043f 	cmp	w1, #0x1
    6214:	54000181 	b.ne	6244 <f0+0x124>  // b.any
    6218:	29430001 	ldp	w1, w0, [x0, #24]
    621c:	92403c42 	and	x2, x2, #0xffff
    6220:	9b017c42 	mul	x2, x2, x1
    6224:	d360fc42 	lsr	x2, x2, #32
    6228:	eb00005f 	cmp	x2, x0
    622c:	540000c2 	b.cs	6244 <f0+0x124>  // b.hs, b.nlast
    6230:	8b02037b 	add	x27, x27, x2
    6234:	39400360 	ldrb	w0, [x27]
    6238:	7103fc1f 	cmp	w0, #0xff
    623c:	54010c80 	b.eq	83cc <f0+0x22ac>  // b.none
    6240:	39000377 	strb	w23, [x27]
    6244:	f90013f3 	str	x19, [sp, #32]
    6248:	aa1c035a 	orr	x26, x26, x28
    624c:	b5fffafa 	cbnz	x26, 61a8 <f0+0x88>
    6250:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6254:	910103e1 	add	x1, sp, #0x40
    6258:	f94007e2 	ldr	x2, [sp, #8]
    625c:	3dc2d400 	ldr	q0, [x0, #2896]
    6260:	d00000c0 	adrp	x0, 20000 <__data_start>
    6264:	91024018 	add	x24, x0, #0x90
    6268:	52800020 	mov	w0, #0x1                   	// #1
    626c:	3d8013e0 	str	q0, [sp, #64]
    6270:	f9014b02 	str	x2, [x24, #656]
    6274:	97fff537 	bl	3750 <fwp_data.part.0.constprop.0>
    6278:	97fff482 	bl	3480 <fwp_rc_fresh>
    627c:	aa0003e2 	mov	x2, x0
    6280:	910163e1 	add	x1, sp, #0x58
    6284:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6288:	52800020 	mov	w0, #0x1                   	// #1
    628c:	a9058be3 	stp	x3, x2, [sp, #88]
    6290:	97fff530 	bl	3750 <fwp_data.part.0.constprop.0>
    6294:	97fff47b 	bl	3480 <fwp_rc_fresh>
    6298:	aa0003e2 	mov	x2, x0
    629c:	f0000003 	adrp	x3, 9000 <__divti3+0x2c0>
    62a0:	9101a3e1 	add	x1, sp, #0x68
    62a4:	52800020 	mov	w0, #0x1                   	// #1
    62a8:	f9003be2 	str	x2, [sp, #112]
    62ac:	3dc2d460 	ldr	q0, [x3, #2896]
    62b0:	fd0037e0 	str	d0, [sp, #104]
    62b4:	97fff527 	bl	3750 <fwp_data.part.0.constprop.0>
    62b8:	9115c283 	add	x3, x20, #0x570
    62bc:	aa0003f5 	mov	x21, x0
    62c0:	f949d861 	ldr	x1, [x3, #5040]
    62c4:	f949ec60 	ldr	x0, [x3, #5080]
    62c8:	cb0102a1 	sub	x1, x21, x1
    62cc:	eb00403f 	cmp	x1, x0, lsl #16
    62d0:	54000322 	b.cs	6334 <f0+0x214>  // b.hs, b.nlast
    62d4:	d350fc22 	lsr	x2, x1, #16
    62d8:	f949fc63 	ldr	x3, [x3, #5112]
    62dc:	8b020842 	add	x2, x2, x2, lsl #2
    62e0:	d37df042 	lsl	x2, x2, #3
    62e4:	8b020060 	add	x0, x3, x2
    62e8:	f9401017 	ldr	x23, [x0, #32]
    62ec:	b4000257 	cbz	x23, 6334 <f0+0x214>
    62f0:	38626862 	ldrb	w2, [x3, x2]
    62f4:	7100085f 	cmp	w2, #0x2
    62f8:	54010b20 	b.eq	845c <f0+0x233c>  // b.none
    62fc:	7100045f 	cmp	w2, #0x1
    6300:	540001a1 	b.ne	6334 <f0+0x214>  // b.any
    6304:	29430002 	ldp	w2, w0, [x0, #24]
    6308:	92403c21 	and	x1, x1, #0xffff
    630c:	9b027c21 	mul	x1, x1, x2
    6310:	d360fc21 	lsr	x1, x1, #32
    6314:	eb00003f 	cmp	x1, x0
    6318:	540000e2 	b.cs	6334 <f0+0x214>  // b.hs, b.nlast
    631c:	8b0102f7 	add	x23, x23, x1
    6320:	394002e0 	ldrb	w0, [x23]
    6324:	7103fc1f 	cmp	w0, #0xff
    6328:	540114e0 	b.eq	85c4 <f0+0x24a4>  // b.none
    632c:	52800020 	mov	w0, #0x1                   	// #1
    6330:	390002e0 	strb	w0, [x23]
    6334:	9101e3e1 	add	x1, sp, #0x78
    6338:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    633c:	52800020 	mov	w0, #0x1                   	// #1
    6340:	a907d7f7 	stp	x23, x21, [sp, #120]
    6344:	97fff503 	bl	3750 <fwp_data.part.0.constprop.0>
    6348:	97fff44e 	bl	3480 <fwp_rc_fresh>
    634c:	aa0003e2 	mov	x2, x0
    6350:	910223e1 	add	x1, sp, #0x88
    6354:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6358:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    635c:	52800020 	mov	w0, #0x1                   	// #1
    6360:	a9088bf5 	stp	x21, x2, [sp, #136]
    6364:	97fff4fb 	bl	3750 <fwp_data.part.0.constprop.0>
    6368:	97fff446 	bl	3480 <fwp_rc_fresh>
    636c:	aa0003e2 	mov	x2, x0
    6370:	910263e1 	add	x1, sp, #0x98
    6374:	52800020 	mov	w0, #0x1                   	// #1
    6378:	a9098bf7 	stp	x23, x2, [sp, #152]
    637c:	97fff4f5 	bl	3750 <fwp_data.part.0.constprop.0>
    6380:	97fff440 	bl	3480 <fwp_rc_fresh>
    6384:	aa0003e2 	mov	x2, x0
    6388:	9102a3e1 	add	x1, sp, #0xa8
    638c:	52800020 	mov	w0, #0x1                   	// #1
    6390:	a90a8bf5 	stp	x21, x2, [sp, #168]
    6394:	97fff4ef 	bl	3750 <fwp_data.part.0.constprop.0>
    6398:	97fff43a 	bl	3480 <fwp_rc_fresh>
    639c:	aa0003e2 	mov	x2, x0
    63a0:	9102e3e1 	add	x1, sp, #0xb8
    63a4:	52800020 	mov	w0, #0x1                   	// #1
    63a8:	a90b8bf7 	stp	x23, x2, [sp, #184]
    63ac:	97fff4e9 	bl	3750 <fwp_data.part.0.constprop.0>
    63b0:	97fff434 	bl	3480 <fwp_rc_fresh>
    63b4:	aa0003e2 	mov	x2, x0
    63b8:	910323e1 	add	x1, sp, #0xc8
    63bc:	52800020 	mov	w0, #0x1                   	// #1
    63c0:	a90c8bf5 	stp	x21, x2, [sp, #200]
    63c4:	97fff4e3 	bl	3750 <fwp_data.part.0.constprop.0>
    63c8:	97fff42e 	bl	3480 <fwp_rc_fresh>
    63cc:	aa0003e2 	mov	x2, x0
    63d0:	910363e1 	add	x1, sp, #0xd8
    63d4:	52800020 	mov	w0, #0x1                   	// #1
    63d8:	a90d8bf7 	stp	x23, x2, [sp, #216]
    63dc:	97fff4dd 	bl	3750 <fwp_data.part.0.constprop.0>
    63e0:	97fff428 	bl	3480 <fwp_rc_fresh>
    63e4:	aa0003e2 	mov	x2, x0
    63e8:	9103a3e1 	add	x1, sp, #0xe8
    63ec:	52800020 	mov	w0, #0x1                   	// #1
    63f0:	a90e8bf5 	stp	x21, x2, [sp, #232]
    63f4:	97fff4d7 	bl	3750 <fwp_data.part.0.constprop.0>
    63f8:	9115c283 	add	x3, x20, #0x570
    63fc:	aa0003f5 	mov	x21, x0
    6400:	f949d861 	ldr	x1, [x3, #5040]
    6404:	f949ec60 	ldr	x0, [x3, #5080]
    6408:	cb0102a1 	sub	x1, x21, x1
    640c:	eb00403f 	cmp	x1, x0, lsl #16
    6410:	54000322 	b.cs	6474 <f0+0x354>  // b.hs, b.nlast
    6414:	d350fc22 	lsr	x2, x1, #16
    6418:	f949fc63 	ldr	x3, [x3, #5112]
    641c:	8b020842 	add	x2, x2, x2, lsl #2
    6420:	d37df042 	lsl	x2, x2, #3
    6424:	8b020060 	add	x0, x3, x2
    6428:	f9401017 	ldr	x23, [x0, #32]
    642c:	b4000257 	cbz	x23, 6474 <f0+0x354>
    6430:	38626862 	ldrb	w2, [x3, x2]
    6434:	7100085f 	cmp	w2, #0x2
    6438:	540100c0 	b.eq	8450 <f0+0x2330>  // b.none
    643c:	7100045f 	cmp	w2, #0x1
    6440:	540001a1 	b.ne	6474 <f0+0x354>  // b.any
    6444:	29430002 	ldp	w2, w0, [x0, #24]
    6448:	92403c21 	and	x1, x1, #0xffff
    644c:	9b027c21 	mul	x1, x1, x2
    6450:	d360fc21 	lsr	x1, x1, #32
    6454:	eb00003f 	cmp	x1, x0
    6458:	540000e2 	b.cs	6474 <f0+0x354>  // b.hs, b.nlast
    645c:	8b0102f7 	add	x23, x23, x1
    6460:	394002e0 	ldrb	w0, [x23]
    6464:	7103fc1f 	cmp	w0, #0xff
    6468:	54010b40 	b.eq	85d0 <f0+0x24b0>  // b.none
    646c:	52800020 	mov	w0, #0x1                   	// #1
    6470:	390002e0 	strb	w0, [x23]
    6474:	9103e3e1 	add	x1, sp, #0xf8
    6478:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    647c:	52800020 	mov	w0, #0x1                   	// #1
    6480:	a90fd7f7 	stp	x23, x21, [sp, #248]
    6484:	97fff4b3 	bl	3750 <fwp_data.part.0.constprop.0>
    6488:	97fff3fe 	bl	3480 <fwp_rc_fresh>
    648c:	aa0003e2 	mov	x2, x0
    6490:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6494:	910423e1 	add	x1, sp, #0x108
    6498:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    649c:	52800020 	mov	w0, #0x1                   	// #1
    64a0:	a9108be3 	stp	x3, x2, [sp, #264]
    64a4:	97fff4ab 	bl	3750 <fwp_data.part.0.constprop.0>
    64a8:	97fff3f6 	bl	3480 <fwp_rc_fresh>
    64ac:	aa0003e2 	mov	x2, x0
    64b0:	910463e1 	add	x1, sp, #0x118
    64b4:	52800020 	mov	w0, #0x1                   	// #1
    64b8:	a9118bf7 	stp	x23, x2, [sp, #280]
    64bc:	97fff4a5 	bl	3750 <fwp_data.part.0.constprop.0>
    64c0:	9115c283 	add	x3, x20, #0x570
    64c4:	aa0003f5 	mov	x21, x0
    64c8:	f949d861 	ldr	x1, [x3, #5040]
    64cc:	f949ec60 	ldr	x0, [x3, #5080]
    64d0:	cb0102a1 	sub	x1, x21, x1
    64d4:	eb00403f 	cmp	x1, x0, lsl #16
    64d8:	54000322 	b.cs	653c <f0+0x41c>  // b.hs, b.nlast
    64dc:	d350fc22 	lsr	x2, x1, #16
    64e0:	f949fc63 	ldr	x3, [x3, #5112]
    64e4:	8b020842 	add	x2, x2, x2, lsl #2
    64e8:	d37df042 	lsl	x2, x2, #3
    64ec:	8b020060 	add	x0, x3, x2
    64f0:	f9401017 	ldr	x23, [x0, #32]
    64f4:	b4000257 	cbz	x23, 653c <f0+0x41c>
    64f8:	38626862 	ldrb	w2, [x3, x2]
    64fc:	7100085f 	cmp	w2, #0x2
    6500:	5400fa20 	b.eq	8444 <f0+0x2324>  // b.none
    6504:	7100045f 	cmp	w2, #0x1
    6508:	540001a1 	b.ne	653c <f0+0x41c>  // b.any
    650c:	29430002 	ldp	w2, w0, [x0, #24]
    6510:	92403c21 	and	x1, x1, #0xffff
    6514:	9b027c21 	mul	x1, x1, x2
    6518:	d360fc21 	lsr	x1, x1, #32
    651c:	eb00003f 	cmp	x1, x0
    6520:	540000e2 	b.cs	653c <f0+0x41c>  // b.hs, b.nlast
    6524:	8b0102f7 	add	x23, x23, x1
    6528:	394002e0 	ldrb	w0, [x23]
    652c:	7103fc1f 	cmp	w0, #0xff
    6530:	54010560 	b.eq	85dc <f0+0x24bc>  // b.none
    6534:	52800020 	mov	w0, #0x1                   	// #1
    6538:	390002e0 	strb	w0, [x23]
    653c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6540:	9104a3e1 	add	x1, sp, #0x128
    6544:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6548:	52800020 	mov	w0, #0x1                   	// #1
    654c:	a912d7e2 	stp	x2, x21, [sp, #296]
    6550:	97fff480 	bl	3750 <fwp_data.part.0.constprop.0>
    6554:	9115c283 	add	x3, x20, #0x570
    6558:	aa0003f5 	mov	x21, x0
    655c:	f949d861 	ldr	x1, [x3, #5040]
    6560:	f949ec60 	ldr	x0, [x3, #5080]
    6564:	cb0102a1 	sub	x1, x21, x1
    6568:	eb00403f 	cmp	x1, x0, lsl #16
    656c:	54000322 	b.cs	65d0 <f0+0x4b0>  // b.hs, b.nlast
    6570:	d350fc22 	lsr	x2, x1, #16
    6574:	f949fc63 	ldr	x3, [x3, #5112]
    6578:	8b020842 	add	x2, x2, x2, lsl #2
    657c:	d37df042 	lsl	x2, x2, #3
    6580:	8b020060 	add	x0, x3, x2
    6584:	f9401017 	ldr	x23, [x0, #32]
    6588:	b4000257 	cbz	x23, 65d0 <f0+0x4b0>
    658c:	38626862 	ldrb	w2, [x3, x2]
    6590:	7100085f 	cmp	w2, #0x2
    6594:	5400f7c0 	b.eq	848c <f0+0x236c>  // b.none
    6598:	7100045f 	cmp	w2, #0x1
    659c:	540001a1 	b.ne	65d0 <f0+0x4b0>  // b.any
    65a0:	29430002 	ldp	w2, w0, [x0, #24]
    65a4:	92403c21 	and	x1, x1, #0xffff
    65a8:	9b027c21 	mul	x1, x1, x2
    65ac:	d360fc21 	lsr	x1, x1, #32
    65b0:	eb00003f 	cmp	x1, x0
    65b4:	540000e2 	b.cs	65d0 <f0+0x4b0>  // b.hs, b.nlast
    65b8:	8b0102f7 	add	x23, x23, x1
    65bc:	394002e0 	ldrb	w0, [x23]
    65c0:	7103fc1f 	cmp	w0, #0xff
    65c4:	54010120 	b.eq	85e8 <f0+0x24c8>  // b.none
    65c8:	52800020 	mov	w0, #0x1                   	// #1
    65cc:	390002e0 	strb	w0, [x23]
    65d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    65d4:	9104e3e1 	add	x1, sp, #0x138
    65d8:	52800020 	mov	w0, #0x1                   	// #1
    65dc:	a913d7e2 	stp	x2, x21, [sp, #312]
    65e0:	97fff45c 	bl	3750 <fwp_data.part.0.constprop.0>
    65e4:	9115c283 	add	x3, x20, #0x570
    65e8:	aa0003f5 	mov	x21, x0
    65ec:	f949d861 	ldr	x1, [x3, #5040]
    65f0:	f949ec60 	ldr	x0, [x3, #5080]
    65f4:	cb0102a1 	sub	x1, x21, x1
    65f8:	eb00403f 	cmp	x1, x0, lsl #16
    65fc:	54000322 	b.cs	6660 <f0+0x540>  // b.hs, b.nlast
    6600:	d350fc22 	lsr	x2, x1, #16
    6604:	f949fc63 	ldr	x3, [x3, #5112]
    6608:	8b020842 	add	x2, x2, x2, lsl #2
    660c:	d37df042 	lsl	x2, x2, #3
    6610:	8b020060 	add	x0, x3, x2
    6614:	f9401017 	ldr	x23, [x0, #32]
    6618:	b4000257 	cbz	x23, 6660 <f0+0x540>
    661c:	38626862 	ldrb	w2, [x3, x2]
    6620:	7100085f 	cmp	w2, #0x2
    6624:	5400f2e0 	b.eq	8480 <f0+0x2360>  // b.none
    6628:	7100045f 	cmp	w2, #0x1
    662c:	540001a1 	b.ne	6660 <f0+0x540>  // b.any
    6630:	29430002 	ldp	w2, w0, [x0, #24]
    6634:	92403c21 	and	x1, x1, #0xffff
    6638:	9b027c21 	mul	x1, x1, x2
    663c:	d360fc21 	lsr	x1, x1, #32
    6640:	eb00003f 	cmp	x1, x0
    6644:	540000e2 	b.cs	6660 <f0+0x540>  // b.hs, b.nlast
    6648:	8b0102f7 	add	x23, x23, x1
    664c:	394002e0 	ldrb	w0, [x23]
    6650:	7103fc1f 	cmp	w0, #0xff
    6654:	5400fd00 	b.eq	85f4 <f0+0x24d4>  // b.none
    6658:	52800020 	mov	w0, #0x1                   	// #1
    665c:	390002e0 	strb	w0, [x23]
    6660:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6664:	910523e1 	add	x1, sp, #0x148
    6668:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    666c:	52800020 	mov	w0, #0x1                   	// #1
    6670:	a914d7e2 	stp	x2, x21, [sp, #328]
    6674:	97fff437 	bl	3750 <fwp_data.part.0.constprop.0>
    6678:	9115c283 	add	x3, x20, #0x570
    667c:	aa0003f7 	mov	x23, x0
    6680:	f949d861 	ldr	x1, [x3, #5040]
    6684:	f949ec60 	ldr	x0, [x3, #5080]
    6688:	cb0102e1 	sub	x1, x23, x1
    668c:	eb00403f 	cmp	x1, x0, lsl #16
    6690:	54000322 	b.cs	66f4 <f0+0x5d4>  // b.hs, b.nlast
    6694:	d350fc22 	lsr	x2, x1, #16
    6698:	f949fc63 	ldr	x3, [x3, #5112]
    669c:	8b020842 	add	x2, x2, x2, lsl #2
    66a0:	d37df042 	lsl	x2, x2, #3
    66a4:	8b020060 	add	x0, x3, x2
    66a8:	f9401015 	ldr	x21, [x0, #32]
    66ac:	b4000255 	cbz	x21, 66f4 <f0+0x5d4>
    66b0:	38626862 	ldrb	w2, [x3, x2]
    66b4:	7100085f 	cmp	w2, #0x2
    66b8:	5400ede0 	b.eq	8474 <f0+0x2354>  // b.none
    66bc:	7100045f 	cmp	w2, #0x1
    66c0:	540001a1 	b.ne	66f4 <f0+0x5d4>  // b.any
    66c4:	29430002 	ldp	w2, w0, [x0, #24]
    66c8:	92403c21 	and	x1, x1, #0xffff
    66cc:	9b027c21 	mul	x1, x1, x2
    66d0:	d360fc21 	lsr	x1, x1, #32
    66d4:	eb00003f 	cmp	x1, x0
    66d8:	540000e2 	b.cs	66f4 <f0+0x5d4>  // b.hs, b.nlast
    66dc:	8b0102b5 	add	x21, x21, x1
    66e0:	394002a0 	ldrb	w0, [x21]
    66e4:	7103fc1f 	cmp	w0, #0xff
    66e8:	5400f8c0 	b.eq	8600 <f0+0x24e0>  // b.none
    66ec:	52800020 	mov	w0, #0x1                   	// #1
    66f0:	390002a0 	strb	w0, [x21]
    66f4:	910563e1 	add	x1, sp, #0x158
    66f8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    66fc:	52800020 	mov	w0, #0x1                   	// #1
    6700:	a915dff5 	stp	x21, x23, [sp, #344]
    6704:	97fff413 	bl	3750 <fwp_data.part.0.constprop.0>
    6708:	97fff35e 	bl	3480 <fwp_rc_fresh>
    670c:	aa0003e2 	mov	x2, x0
    6710:	9105a3e1 	add	x1, sp, #0x168
    6714:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6718:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    671c:	52800020 	mov	w0, #0x1                   	// #1
    6720:	a9168bf7 	stp	x23, x2, [sp, #360]
    6724:	97fff40b 	bl	3750 <fwp_data.part.0.constprop.0>
    6728:	97fff356 	bl	3480 <fwp_rc_fresh>
    672c:	aa0003e2 	mov	x2, x0
    6730:	9105e3e1 	add	x1, sp, #0x178
    6734:	52800020 	mov	w0, #0x1                   	// #1
    6738:	a9178bf5 	stp	x21, x2, [sp, #376]
    673c:	97fff405 	bl	3750 <fwp_data.part.0.constprop.0>
    6740:	97fff350 	bl	3480 <fwp_rc_fresh>
    6744:	aa0003e2 	mov	x2, x0
    6748:	910623e1 	add	x1, sp, #0x188
    674c:	52800020 	mov	w0, #0x1                   	// #1
    6750:	a9188bf7 	stp	x23, x2, [sp, #392]
    6754:	97fff3ff 	bl	3750 <fwp_data.part.0.constprop.0>
    6758:	97fff34a 	bl	3480 <fwp_rc_fresh>
    675c:	aa0003e2 	mov	x2, x0
    6760:	910663e1 	add	x1, sp, #0x198
    6764:	52800020 	mov	w0, #0x1                   	// #1
    6768:	a9198bf5 	stp	x21, x2, [sp, #408]
    676c:	97fff3f9 	bl	3750 <fwp_data.part.0.constprop.0>
    6770:	97fff344 	bl	3480 <fwp_rc_fresh>
    6774:	aa0003e2 	mov	x2, x0
    6778:	9106a3e1 	add	x1, sp, #0x1a8
    677c:	52800020 	mov	w0, #0x1                   	// #1
    6780:	a91a8bf7 	stp	x23, x2, [sp, #424]
    6784:	97fff3f3 	bl	3750 <fwp_data.part.0.constprop.0>
    6788:	97fff33e 	bl	3480 <fwp_rc_fresh>
    678c:	aa0003e2 	mov	x2, x0
    6790:	9106e3e1 	add	x1, sp, #0x1b8
    6794:	52800020 	mov	w0, #0x1                   	// #1
    6798:	a91b8bf5 	stp	x21, x2, [sp, #440]
    679c:	97fff3ed 	bl	3750 <fwp_data.part.0.constprop.0>
    67a0:	97fff338 	bl	3480 <fwp_rc_fresh>
    67a4:	aa0003e2 	mov	x2, x0
    67a8:	910723e1 	add	x1, sp, #0x1c8
    67ac:	52800020 	mov	w0, #0x1                   	// #1
    67b0:	a91c8bf7 	stp	x23, x2, [sp, #456]
    67b4:	97fff3e7 	bl	3750 <fwp_data.part.0.constprop.0>
    67b8:	97fff332 	bl	3480 <fwp_rc_fresh>
    67bc:	aa0003e2 	mov	x2, x0
    67c0:	910763e1 	add	x1, sp, #0x1d8
    67c4:	52800020 	mov	w0, #0x1                   	// #1
    67c8:	a91d8bf5 	stp	x21, x2, [sp, #472]
    67cc:	97fff3e1 	bl	3750 <fwp_data.part.0.constprop.0>
    67d0:	97fff32c 	bl	3480 <fwp_rc_fresh>
    67d4:	aa0003e2 	mov	x2, x0
    67d8:	9107a3e1 	add	x1, sp, #0x1e8
    67dc:	52800020 	mov	w0, #0x1                   	// #1
    67e0:	a91e8bf7 	stp	x23, x2, [sp, #488]
    67e4:	97fff3db 	bl	3750 <fwp_data.part.0.constprop.0>
    67e8:	97fff326 	bl	3480 <fwp_rc_fresh>
    67ec:	aa0003e2 	mov	x2, x0
    67f0:	9107e3e1 	add	x1, sp, #0x1f8
    67f4:	52800020 	mov	w0, #0x1                   	// #1
    67f8:	a91f8bf5 	stp	x21, x2, [sp, #504]
    67fc:	97fff3d5 	bl	3750 <fwp_data.part.0.constprop.0>
    6800:	97fff320 	bl	3480 <fwp_rc_fresh>
    6804:	aa0003e2 	mov	x2, x0
    6808:	910823e1 	add	x1, sp, #0x208
    680c:	52800020 	mov	w0, #0x1                   	// #1
    6810:	f90107f7 	str	x23, [sp, #520]
    6814:	f9010be2 	str	x2, [sp, #528]
    6818:	97fff3ce 	bl	3750 <fwp_data.part.0.constprop.0>
    681c:	97fff319 	bl	3480 <fwp_rc_fresh>
    6820:	aa0003e2 	mov	x2, x0
    6824:	910863e1 	add	x1, sp, #0x218
    6828:	52800020 	mov	w0, #0x1                   	// #1
    682c:	f9010ff5 	str	x21, [sp, #536]
    6830:	f90113e2 	str	x2, [sp, #544]
    6834:	97fff3c7 	bl	3750 <fwp_data.part.0.constprop.0>
    6838:	97fff312 	bl	3480 <fwp_rc_fresh>
    683c:	aa0003e2 	mov	x2, x0
    6840:	9108a3e1 	add	x1, sp, #0x228
    6844:	52800020 	mov	w0, #0x1                   	// #1
    6848:	f90117f7 	str	x23, [sp, #552]
    684c:	f9011be2 	str	x2, [sp, #560]
    6850:	97fff3c0 	bl	3750 <fwp_data.part.0.constprop.0>
    6854:	97fff30b 	bl	3480 <fwp_rc_fresh>
    6858:	aa0003e2 	mov	x2, x0
    685c:	9108e3e1 	add	x1, sp, #0x238
    6860:	52800020 	mov	w0, #0x1                   	// #1
    6864:	f9011ff5 	str	x21, [sp, #568]
    6868:	f90123e2 	str	x2, [sp, #576]
    686c:	97fff3b9 	bl	3750 <fwp_data.part.0.constprop.0>
    6870:	97fff304 	bl	3480 <fwp_rc_fresh>
    6874:	aa0003e2 	mov	x2, x0
    6878:	910923e1 	add	x1, sp, #0x248
    687c:	52800020 	mov	w0, #0x1                   	// #1
    6880:	f90127f7 	str	x23, [sp, #584]
    6884:	f9012be2 	str	x2, [sp, #592]
    6888:	97fff3b2 	bl	3750 <fwp_data.part.0.constprop.0>
    688c:	97fff2fd 	bl	3480 <fwp_rc_fresh>
    6890:	aa0003e2 	mov	x2, x0
    6894:	910963e1 	add	x1, sp, #0x258
    6898:	52800020 	mov	w0, #0x1                   	// #1
    689c:	f9012ff5 	str	x21, [sp, #600]
    68a0:	f90133e2 	str	x2, [sp, #608]
    68a4:	97fff3ab 	bl	3750 <fwp_data.part.0.constprop.0>
    68a8:	9115c283 	add	x3, x20, #0x570
    68ac:	aa0003f5 	mov	x21, x0
    68b0:	f949d861 	ldr	x1, [x3, #5040]
    68b4:	f949ec60 	ldr	x0, [x3, #5080]
    68b8:	cb0102a1 	sub	x1, x21, x1
    68bc:	eb00403f 	cmp	x1, x0, lsl #16
    68c0:	54000322 	b.cs	6924 <f0+0x804>  // b.hs, b.nlast
    68c4:	d350fc22 	lsr	x2, x1, #16
    68c8:	f949fc63 	ldr	x3, [x3, #5112]
    68cc:	8b020842 	add	x2, x2, x2, lsl #2
    68d0:	d37df042 	lsl	x2, x2, #3
    68d4:	8b020060 	add	x0, x3, x2
    68d8:	f9401017 	ldr	x23, [x0, #32]
    68dc:	b4000257 	cbz	x23, 6924 <f0+0x804>
    68e0:	38626862 	ldrb	w2, [x3, x2]
    68e4:	7100085f 	cmp	w2, #0x2
    68e8:	5400dc00 	b.eq	8468 <f0+0x2348>  // b.none
    68ec:	7100045f 	cmp	w2, #0x1
    68f0:	540001a1 	b.ne	6924 <f0+0x804>  // b.any
    68f4:	29430002 	ldp	w2, w0, [x0, #24]
    68f8:	92403c21 	and	x1, x1, #0xffff
    68fc:	9b027c21 	mul	x1, x1, x2
    6900:	d360fc21 	lsr	x1, x1, #32
    6904:	eb00003f 	cmp	x1, x0
    6908:	540000e2 	b.cs	6924 <f0+0x804>  // b.hs, b.nlast
    690c:	8b0102f7 	add	x23, x23, x1
    6910:	394002e0 	ldrb	w0, [x23]
    6914:	7103fc1f 	cmp	w0, #0xff
    6918:	5400e7a0 	b.eq	860c <f0+0x24ec>  // b.none
    691c:	52800020 	mov	w0, #0x1                   	// #1
    6920:	390002e0 	strb	w0, [x23]
    6924:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6928:	9109a3e1 	add	x1, sp, #0x268
    692c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6930:	52800020 	mov	w0, #0x1                   	// #1
    6934:	f90137e2 	str	x2, [sp, #616]
    6938:	f9013bf5 	str	x21, [sp, #624]
    693c:	97fff385 	bl	3750 <fwp_data.part.0.constprop.0>
    6940:	97fff2d0 	bl	3480 <fwp_rc_fresh>
    6944:	aa0003e2 	mov	x2, x0
    6948:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    694c:	9109e3e1 	add	x1, sp, #0x278
    6950:	52800020 	mov	w0, #0x1                   	// #1
    6954:	f9013fe3 	str	x3, [sp, #632]
    6958:	f90143e2 	str	x2, [sp, #640]
    695c:	97fff37d 	bl	3750 <fwp_data.part.0.constprop.0>
    6960:	9115c283 	add	x3, x20, #0x570
    6964:	aa0003f7 	mov	x23, x0
    6968:	f949d861 	ldr	x1, [x3, #5040]
    696c:	f949ec60 	ldr	x0, [x3, #5080]
    6970:	cb0102e1 	sub	x1, x23, x1
    6974:	eb00403f 	cmp	x1, x0, lsl #16
    6978:	54000322 	b.cs	69dc <f0+0x8bc>  // b.hs, b.nlast
    697c:	d350fc22 	lsr	x2, x1, #16
    6980:	f949fc63 	ldr	x3, [x3, #5112]
    6984:	8b020842 	add	x2, x2, x2, lsl #2
    6988:	d37df042 	lsl	x2, x2, #3
    698c:	8b020060 	add	x0, x3, x2
    6990:	f9401015 	ldr	x21, [x0, #32]
    6994:	b4000255 	cbz	x21, 69dc <f0+0x8bc>
    6998:	38626862 	ldrb	w2, [x3, x2]
    699c:	7100085f 	cmp	w2, #0x2
    69a0:	5400da60 	b.eq	84ec <f0+0x23cc>  // b.none
    69a4:	7100045f 	cmp	w2, #0x1
    69a8:	540001a1 	b.ne	69dc <f0+0x8bc>  // b.any
    69ac:	29430002 	ldp	w2, w0, [x0, #24]
    69b0:	92403c21 	and	x1, x1, #0xffff
    69b4:	9b027c21 	mul	x1, x1, x2
    69b8:	d360fc21 	lsr	x1, x1, #32
    69bc:	eb00003f 	cmp	x1, x0
    69c0:	540000e2 	b.cs	69dc <f0+0x8bc>  // b.hs, b.nlast
    69c4:	8b0102b5 	add	x21, x21, x1
    69c8:	394002a0 	ldrb	w0, [x21]
    69cc:	7103fc1f 	cmp	w0, #0xff
    69d0:	5400e240 	b.eq	8618 <f0+0x24f8>  // b.none
    69d4:	52800020 	mov	w0, #0x1                   	// #1
    69d8:	390002a0 	strb	w0, [x21]
    69dc:	910a23e1 	add	x1, sp, #0x288
    69e0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    69e4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    69e8:	52800020 	mov	w0, #0x1                   	// #1
    69ec:	f90147f5 	str	x21, [sp, #648]
    69f0:	f9014bf7 	str	x23, [sp, #656]
    69f4:	97fff357 	bl	3750 <fwp_data.part.0.constprop.0>
    69f8:	97fff2a2 	bl	3480 <fwp_rc_fresh>
    69fc:	aa0003e2 	mov	x2, x0
    6a00:	910a63e1 	add	x1, sp, #0x298
    6a04:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6a08:	52800020 	mov	w0, #0x1                   	// #1
    6a0c:	f9014ff7 	str	x23, [sp, #664]
    6a10:	f90153e2 	str	x2, [sp, #672]
    6a14:	97fff34f 	bl	3750 <fwp_data.part.0.constprop.0>
    6a18:	97fff29a 	bl	3480 <fwp_rc_fresh>
    6a1c:	aa0003e2 	mov	x2, x0
    6a20:	910aa3e1 	add	x1, sp, #0x2a8
    6a24:	52800020 	mov	w0, #0x1                   	// #1
    6a28:	f90157f5 	str	x21, [sp, #680]
    6a2c:	f9015be2 	str	x2, [sp, #688]
    6a30:	97fff348 	bl	3750 <fwp_data.part.0.constprop.0>
    6a34:	97fff293 	bl	3480 <fwp_rc_fresh>
    6a38:	aa0003e2 	mov	x2, x0
    6a3c:	910ae3e1 	add	x1, sp, #0x2b8
    6a40:	52800020 	mov	w0, #0x1                   	// #1
    6a44:	f9015ff7 	str	x23, [sp, #696]
    6a48:	f90163e2 	str	x2, [sp, #704]
    6a4c:	97fff341 	bl	3750 <fwp_data.part.0.constprop.0>
    6a50:	97fff28c 	bl	3480 <fwp_rc_fresh>
    6a54:	aa0003e2 	mov	x2, x0
    6a58:	910b23e1 	add	x1, sp, #0x2c8
    6a5c:	52800020 	mov	w0, #0x1                   	// #1
    6a60:	f90167f5 	str	x21, [sp, #712]
    6a64:	f9016be2 	str	x2, [sp, #720]
    6a68:	97fff33a 	bl	3750 <fwp_data.part.0.constprop.0>
    6a6c:	97fff285 	bl	3480 <fwp_rc_fresh>
    6a70:	aa0003e2 	mov	x2, x0
    6a74:	910b63e1 	add	x1, sp, #0x2d8
    6a78:	52800020 	mov	w0, #0x1                   	// #1
    6a7c:	f9016ff7 	str	x23, [sp, #728]
    6a80:	f90173e2 	str	x2, [sp, #736]
    6a84:	97fff333 	bl	3750 <fwp_data.part.0.constprop.0>
    6a88:	97fff27e 	bl	3480 <fwp_rc_fresh>
    6a8c:	aa0003e2 	mov	x2, x0
    6a90:	910ba3e1 	add	x1, sp, #0x2e8
    6a94:	52800020 	mov	w0, #0x1                   	// #1
    6a98:	f90177f5 	str	x21, [sp, #744]
    6a9c:	f9017be2 	str	x2, [sp, #752]
    6aa0:	97fff32c 	bl	3750 <fwp_data.part.0.constprop.0>
    6aa4:	97fff277 	bl	3480 <fwp_rc_fresh>
    6aa8:	aa0003e2 	mov	x2, x0
    6aac:	910be3e1 	add	x1, sp, #0x2f8
    6ab0:	52800020 	mov	w0, #0x1                   	// #1
    6ab4:	f9017ff7 	str	x23, [sp, #760]
    6ab8:	f90183e2 	str	x2, [sp, #768]
    6abc:	97fff325 	bl	3750 <fwp_data.part.0.constprop.0>
    6ac0:	97fff270 	bl	3480 <fwp_rc_fresh>
    6ac4:	aa0003e2 	mov	x2, x0
    6ac8:	910c23e1 	add	x1, sp, #0x308
    6acc:	52800020 	mov	w0, #0x1                   	// #1
    6ad0:	f90187f5 	str	x21, [sp, #776]
    6ad4:	f9018be2 	str	x2, [sp, #784]
    6ad8:	97fff31e 	bl	3750 <fwp_data.part.0.constprop.0>
    6adc:	97fff269 	bl	3480 <fwp_rc_fresh>
    6ae0:	aa0003e2 	mov	x2, x0
    6ae4:	910c63e1 	add	x1, sp, #0x318
    6ae8:	52800020 	mov	w0, #0x1                   	// #1
    6aec:	f9018ff7 	str	x23, [sp, #792]
    6af0:	f90193e2 	str	x2, [sp, #800]
    6af4:	97fff317 	bl	3750 <fwp_data.part.0.constprop.0>
    6af8:	97fff262 	bl	3480 <fwp_rc_fresh>
    6afc:	aa0003e2 	mov	x2, x0
    6b00:	910ca3e1 	add	x1, sp, #0x328
    6b04:	52800020 	mov	w0, #0x1                   	// #1
    6b08:	f90197f5 	str	x21, [sp, #808]
    6b0c:	f9019be2 	str	x2, [sp, #816]
    6b10:	97fff310 	bl	3750 <fwp_data.part.0.constprop.0>
    6b14:	97fff25b 	bl	3480 <fwp_rc_fresh>
    6b18:	aa0003e2 	mov	x2, x0
    6b1c:	910ce3e1 	add	x1, sp, #0x338
    6b20:	52800020 	mov	w0, #0x1                   	// #1
    6b24:	f9019ff7 	str	x23, [sp, #824]
    6b28:	f901a3e2 	str	x2, [sp, #832]
    6b2c:	97fff309 	bl	3750 <fwp_data.part.0.constprop.0>
    6b30:	97fff254 	bl	3480 <fwp_rc_fresh>
    6b34:	aa0003e2 	mov	x2, x0
    6b38:	910d23e1 	add	x1, sp, #0x348
    6b3c:	52800020 	mov	w0, #0x1                   	// #1
    6b40:	f901a7f5 	str	x21, [sp, #840]
    6b44:	f901abe2 	str	x2, [sp, #848]
    6b48:	97fff302 	bl	3750 <fwp_data.part.0.constprop.0>
    6b4c:	9115c283 	add	x3, x20, #0x570
    6b50:	aa0003f5 	mov	x21, x0
    6b54:	f949d861 	ldr	x1, [x3, #5040]
    6b58:	f949ec60 	ldr	x0, [x3, #5080]
    6b5c:	cb0102a1 	sub	x1, x21, x1
    6b60:	eb00403f 	cmp	x1, x0, lsl #16
    6b64:	54000322 	b.cs	6bc8 <f0+0xaa8>  // b.hs, b.nlast
    6b68:	d350fc22 	lsr	x2, x1, #16
    6b6c:	f949fc63 	ldr	x3, [x3, #5112]
    6b70:	8b020842 	add	x2, x2, x2, lsl #2
    6b74:	d37df042 	lsl	x2, x2, #3
    6b78:	8b020060 	add	x0, x3, x2
    6b7c:	f9401017 	ldr	x23, [x0, #32]
    6b80:	b4000257 	cbz	x23, 6bc8 <f0+0xaa8>
    6b84:	38626862 	ldrb	w2, [x3, x2]
    6b88:	7100085f 	cmp	w2, #0x2
    6b8c:	5400caa0 	b.eq	84e0 <f0+0x23c0>  // b.none
    6b90:	7100045f 	cmp	w2, #0x1
    6b94:	540001a1 	b.ne	6bc8 <f0+0xaa8>  // b.any
    6b98:	29430002 	ldp	w2, w0, [x0, #24]
    6b9c:	92403c21 	and	x1, x1, #0xffff
    6ba0:	9b027c21 	mul	x1, x1, x2
    6ba4:	d360fc21 	lsr	x1, x1, #32
    6ba8:	eb00003f 	cmp	x1, x0
    6bac:	540000e2 	b.cs	6bc8 <f0+0xaa8>  // b.hs, b.nlast
    6bb0:	8b0102f7 	add	x23, x23, x1
    6bb4:	394002e0 	ldrb	w0, [x23]
    6bb8:	7103fc1f 	cmp	w0, #0xff
    6bbc:	5400d340 	b.eq	8624 <f0+0x2504>  // b.none
    6bc0:	52800020 	mov	w0, #0x1                   	// #1
    6bc4:	390002e0 	strb	w0, [x23]
    6bc8:	910d63e1 	add	x1, sp, #0x358
    6bcc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6bd0:	52800020 	mov	w0, #0x1                   	// #1
    6bd4:	f901afe2 	str	x2, [sp, #856]
    6bd8:	f901b3f5 	str	x21, [sp, #864]
    6bdc:	97fff2dd 	bl	3750 <fwp_data.part.0.constprop.0>
    6be0:	97fff228 	bl	3480 <fwp_rc_fresh>
    6be4:	aa0003e2 	mov	x2, x0
    6be8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6bec:	910da3e1 	add	x1, sp, #0x368
    6bf0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    6bf4:	52800020 	mov	w0, #0x1                   	// #1
    6bf8:	f901b7e3 	str	x3, [sp, #872]
    6bfc:	f901bbe2 	str	x2, [sp, #880]
    6c00:	97fff2d4 	bl	3750 <fwp_data.part.0.constprop.0>
    6c04:	9115c283 	add	x3, x20, #0x570
    6c08:	aa0003f5 	mov	x21, x0
    6c0c:	f949d861 	ldr	x1, [x3, #5040]
    6c10:	f949ec60 	ldr	x0, [x3, #5080]
    6c14:	cb0102a1 	sub	x1, x21, x1
    6c18:	eb00403f 	cmp	x1, x0, lsl #16
    6c1c:	54000322 	b.cs	6c80 <f0+0xb60>  // b.hs, b.nlast
    6c20:	d350fc22 	lsr	x2, x1, #16
    6c24:	f949fc63 	ldr	x3, [x3, #5112]
    6c28:	8b020842 	add	x2, x2, x2, lsl #2
    6c2c:	d37df042 	lsl	x2, x2, #3
    6c30:	8b020060 	add	x0, x3, x2
    6c34:	f9401017 	ldr	x23, [x0, #32]
    6c38:	b4000257 	cbz	x23, 6c80 <f0+0xb60>
    6c3c:	38626862 	ldrb	w2, [x3, x2]
    6c40:	7100085f 	cmp	w2, #0x2
    6c44:	5400c480 	b.eq	84d4 <f0+0x23b4>  // b.none
    6c48:	7100045f 	cmp	w2, #0x1
    6c4c:	540001a1 	b.ne	6c80 <f0+0xb60>  // b.any
    6c50:	29430002 	ldp	w2, w0, [x0, #24]
    6c54:	92403c21 	and	x1, x1, #0xffff
    6c58:	9b027c21 	mul	x1, x1, x2
    6c5c:	d360fc21 	lsr	x1, x1, #32
    6c60:	eb00003f 	cmp	x1, x0
    6c64:	540000e2 	b.cs	6c80 <f0+0xb60>  // b.hs, b.nlast
    6c68:	8b0102f7 	add	x23, x23, x1
    6c6c:	394002e0 	ldrb	w0, [x23]
    6c70:	7103fc1f 	cmp	w0, #0xff
    6c74:	5400cde0 	b.eq	8630 <f0+0x2510>  // b.none
    6c78:	52800020 	mov	w0, #0x1                   	// #1
    6c7c:	390002e0 	strb	w0, [x23]
    6c80:	910de3e1 	add	x1, sp, #0x378
    6c84:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6c88:	52800020 	mov	w0, #0x1                   	// #1
    6c8c:	f901bff7 	str	x23, [sp, #888]
    6c90:	f901c3f5 	str	x21, [sp, #896]
    6c94:	97fff2af 	bl	3750 <fwp_data.part.0.constprop.0>
    6c98:	97fff1fa 	bl	3480 <fwp_rc_fresh>
    6c9c:	aa0003e2 	mov	x2, x0
    6ca0:	910e23e1 	add	x1, sp, #0x388
    6ca4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6ca8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6cac:	52800020 	mov	w0, #0x1                   	// #1
    6cb0:	f901c7f5 	str	x21, [sp, #904]
    6cb4:	f901cbe2 	str	x2, [sp, #912]
    6cb8:	97fff2a6 	bl	3750 <fwp_data.part.0.constprop.0>
    6cbc:	97fff1f1 	bl	3480 <fwp_rc_fresh>
    6cc0:	aa0003e2 	mov	x2, x0
    6cc4:	910e63e1 	add	x1, sp, #0x398
    6cc8:	52800020 	mov	w0, #0x1                   	// #1
    6ccc:	f901cff7 	str	x23, [sp, #920]
    6cd0:	f901d3e2 	str	x2, [sp, #928]
    6cd4:	97fff29f 	bl	3750 <fwp_data.part.0.constprop.0>
    6cd8:	97fff1ea 	bl	3480 <fwp_rc_fresh>
    6cdc:	aa0003e2 	mov	x2, x0
    6ce0:	910ea3e1 	add	x1, sp, #0x3a8
    6ce4:	52800020 	mov	w0, #0x1                   	// #1
    6ce8:	f901d7f5 	str	x21, [sp, #936]
    6cec:	f901dbe2 	str	x2, [sp, #944]
    6cf0:	97fff298 	bl	3750 <fwp_data.part.0.constprop.0>
    6cf4:	9115c283 	add	x3, x20, #0x570
    6cf8:	aa0003f5 	mov	x21, x0
    6cfc:	f949d861 	ldr	x1, [x3, #5040]
    6d00:	f949ec60 	ldr	x0, [x3, #5080]
    6d04:	cb0102a1 	sub	x1, x21, x1
    6d08:	eb00403f 	cmp	x1, x0, lsl #16
    6d0c:	54000322 	b.cs	6d70 <f0+0xc50>  // b.hs, b.nlast
    6d10:	d350fc22 	lsr	x2, x1, #16
    6d14:	f949fc63 	ldr	x3, [x3, #5112]
    6d18:	8b020842 	add	x2, x2, x2, lsl #2
    6d1c:	d37df042 	lsl	x2, x2, #3
    6d20:	8b020060 	add	x0, x3, x2
    6d24:	f9401017 	ldr	x23, [x0, #32]
    6d28:	b4000257 	cbz	x23, 6d70 <f0+0xc50>
    6d2c:	38626862 	ldrb	w2, [x3, x2]
    6d30:	7100085f 	cmp	w2, #0x2
    6d34:	5400bca0 	b.eq	84c8 <f0+0x23a8>  // b.none
    6d38:	7100045f 	cmp	w2, #0x1
    6d3c:	540001a1 	b.ne	6d70 <f0+0xc50>  // b.any
    6d40:	29430002 	ldp	w2, w0, [x0, #24]
    6d44:	92403c21 	and	x1, x1, #0xffff
    6d48:	9b027c21 	mul	x1, x1, x2
    6d4c:	d360fc21 	lsr	x1, x1, #32
    6d50:	eb00003f 	cmp	x1, x0
    6d54:	540000e2 	b.cs	6d70 <f0+0xc50>  // b.hs, b.nlast
    6d58:	8b0102f7 	add	x23, x23, x1
    6d5c:	394002e0 	ldrb	w0, [x23]
    6d60:	7103fc1f 	cmp	w0, #0xff
    6d64:	5400c6c0 	b.eq	863c <f0+0x251c>  // b.none
    6d68:	52800020 	mov	w0, #0x1                   	// #1
    6d6c:	390002e0 	strb	w0, [x23]
    6d70:	910ee3e1 	add	x1, sp, #0x3b8
    6d74:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6d78:	52800020 	mov	w0, #0x1                   	// #1
    6d7c:	f901dff7 	str	x23, [sp, #952]
    6d80:	f901e3f5 	str	x21, [sp, #960]
    6d84:	97fff273 	bl	3750 <fwp_data.part.0.constprop.0>
    6d88:	97fff1be 	bl	3480 <fwp_rc_fresh>
    6d8c:	aa0003e2 	mov	x2, x0
    6d90:	910f23e1 	add	x1, sp, #0x3c8
    6d94:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6d98:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6d9c:	52800020 	mov	w0, #0x1                   	// #1
    6da0:	f901e7f5 	str	x21, [sp, #968]
    6da4:	f901ebe2 	str	x2, [sp, #976]
    6da8:	97fff26a 	bl	3750 <fwp_data.part.0.constprop.0>
    6dac:	97fff1b5 	bl	3480 <fwp_rc_fresh>
    6db0:	aa0003e2 	mov	x2, x0
    6db4:	910f63e1 	add	x1, sp, #0x3d8
    6db8:	52800020 	mov	w0, #0x1                   	// #1
    6dbc:	f901eff7 	str	x23, [sp, #984]
    6dc0:	f901f3e2 	str	x2, [sp, #992]
    6dc4:	97fff263 	bl	3750 <fwp_data.part.0.constprop.0>
    6dc8:	97fff1ae 	bl	3480 <fwp_rc_fresh>
    6dcc:	aa0003e2 	mov	x2, x0
    6dd0:	910fa3e1 	add	x1, sp, #0x3e8
    6dd4:	52800020 	mov	w0, #0x1                   	// #1
    6dd8:	f901f7f5 	str	x21, [sp, #1000]
    6ddc:	f901fbe2 	str	x2, [sp, #1008]
    6de0:	97fff25c 	bl	3750 <fwp_data.part.0.constprop.0>
    6de4:	9115c283 	add	x3, x20, #0x570
    6de8:	aa0003f5 	mov	x21, x0
    6dec:	f949d861 	ldr	x1, [x3, #5040]
    6df0:	f949ec60 	ldr	x0, [x3, #5080]
    6df4:	cb0102a1 	sub	x1, x21, x1
    6df8:	eb00403f 	cmp	x1, x0, lsl #16
    6dfc:	54000322 	b.cs	6e60 <f0+0xd40>  // b.hs, b.nlast
    6e00:	d350fc22 	lsr	x2, x1, #16
    6e04:	f949fc63 	ldr	x3, [x3, #5112]
    6e08:	8b020842 	add	x2, x2, x2, lsl #2
    6e0c:	d37df042 	lsl	x2, x2, #3
    6e10:	8b020060 	add	x0, x3, x2
    6e14:	f9401017 	ldr	x23, [x0, #32]
    6e18:	b4000257 	cbz	x23, 6e60 <f0+0xd40>
    6e1c:	38626862 	ldrb	w2, [x3, x2]
    6e20:	7100085f 	cmp	w2, #0x2
    6e24:	5400b4c0 	b.eq	84bc <f0+0x239c>  // b.none
    6e28:	7100045f 	cmp	w2, #0x1
    6e2c:	540001a1 	b.ne	6e60 <f0+0xd40>  // b.any
    6e30:	29430002 	ldp	w2, w0, [x0, #24]
    6e34:	92403c21 	and	x1, x1, #0xffff
    6e38:	9b027c21 	mul	x1, x1, x2
    6e3c:	d360fc21 	lsr	x1, x1, #32
    6e40:	eb00003f 	cmp	x1, x0
    6e44:	540000e2 	b.cs	6e60 <f0+0xd40>  // b.hs, b.nlast
    6e48:	8b0102f7 	add	x23, x23, x1
    6e4c:	394002e0 	ldrb	w0, [x23]
    6e50:	7103fc1f 	cmp	w0, #0xff
    6e54:	5400bfa0 	b.eq	8648 <f0+0x2528>  // b.none
    6e58:	52800020 	mov	w0, #0x1                   	// #1
    6e5c:	390002e0 	strb	w0, [x23]
    6e60:	910fe3e1 	add	x1, sp, #0x3f8
    6e64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6e68:	52800020 	mov	w0, #0x1                   	// #1
    6e6c:	f901ffe2 	str	x2, [sp, #1016]
    6e70:	f90203f5 	str	x21, [sp, #1024]
    6e74:	97fff237 	bl	3750 <fwp_data.part.0.constprop.0>
    6e78:	97fff182 	bl	3480 <fwp_rc_fresh>
    6e7c:	aa0003e2 	mov	x2, x0
    6e80:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6e84:	911023e1 	add	x1, sp, #0x408
    6e88:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    6e8c:	52800020 	mov	w0, #0x1                   	// #1
    6e90:	f90207e3 	str	x3, [sp, #1032]
    6e94:	f9020be2 	str	x2, [sp, #1040]
    6e98:	97fff22e 	bl	3750 <fwp_data.part.0.constprop.0>
    6e9c:	9115c283 	add	x3, x20, #0x570
    6ea0:	aa0003f5 	mov	x21, x0
    6ea4:	f949d861 	ldr	x1, [x3, #5040]
    6ea8:	f949ec60 	ldr	x0, [x3, #5080]
    6eac:	cb0102a1 	sub	x1, x21, x1
    6eb0:	eb00403f 	cmp	x1, x0, lsl #16
    6eb4:	54000322 	b.cs	6f18 <f0+0xdf8>  // b.hs, b.nlast
    6eb8:	d350fc22 	lsr	x2, x1, #16
    6ebc:	f949fc63 	ldr	x3, [x3, #5112]
    6ec0:	8b020842 	add	x2, x2, x2, lsl #2
    6ec4:	d37df042 	lsl	x2, x2, #3
    6ec8:	8b020060 	add	x0, x3, x2
    6ecc:	f9401017 	ldr	x23, [x0, #32]
    6ed0:	b4000257 	cbz	x23, 6f18 <f0+0xdf8>
    6ed4:	38626862 	ldrb	w2, [x3, x2]
    6ed8:	7100085f 	cmp	w2, #0x2
    6edc:	5400aea0 	b.eq	84b0 <f0+0x2390>  // b.none
    6ee0:	7100045f 	cmp	w2, #0x1
    6ee4:	540001a1 	b.ne	6f18 <f0+0xdf8>  // b.any
    6ee8:	29430002 	ldp	w2, w0, [x0, #24]
    6eec:	92403c21 	and	x1, x1, #0xffff
    6ef0:	9b027c21 	mul	x1, x1, x2
    6ef4:	d360fc21 	lsr	x1, x1, #32
    6ef8:	eb00003f 	cmp	x1, x0
    6efc:	540000e2 	b.cs	6f18 <f0+0xdf8>  // b.hs, b.nlast
    6f00:	8b0102f7 	add	x23, x23, x1
    6f04:	394002e0 	ldrb	w0, [x23]
    6f08:	7103fc1f 	cmp	w0, #0xff
    6f0c:	5400ba40 	b.eq	8654 <f0+0x2534>  // b.none
    6f10:	52800020 	mov	w0, #0x1                   	// #1
    6f14:	390002e0 	strb	w0, [x23]
    6f18:	911063e1 	add	x1, sp, #0x418
    6f1c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6f20:	52800020 	mov	w0, #0x1                   	// #1
    6f24:	f9020fe2 	str	x2, [sp, #1048]
    6f28:	f90213f5 	str	x21, [sp, #1056]
    6f2c:	97fff209 	bl	3750 <fwp_data.part.0.constprop.0>
    6f30:	97fff154 	bl	3480 <fwp_rc_fresh>
    6f34:	aa0003e2 	mov	x2, x0
    6f38:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6f3c:	9110a3e1 	add	x1, sp, #0x428
    6f40:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    6f44:	52800020 	mov	w0, #0x1                   	// #1
    6f48:	f90217e3 	str	x3, [sp, #1064]
    6f4c:	f9021be2 	str	x2, [sp, #1072]
    6f50:	97fff200 	bl	3750 <fwp_data.part.0.constprop.0>
    6f54:	9115c283 	add	x3, x20, #0x570
    6f58:	aa0003f5 	mov	x21, x0
    6f5c:	f949d861 	ldr	x1, [x3, #5040]
    6f60:	f949ec60 	ldr	x0, [x3, #5080]
    6f64:	cb0102a1 	sub	x1, x21, x1
    6f68:	eb00403f 	cmp	x1, x0, lsl #16
    6f6c:	54000322 	b.cs	6fd0 <f0+0xeb0>  // b.hs, b.nlast
    6f70:	d350fc22 	lsr	x2, x1, #16
    6f74:	f949fc63 	ldr	x3, [x3, #5112]
    6f78:	8b020842 	add	x2, x2, x2, lsl #2
    6f7c:	d37df042 	lsl	x2, x2, #3
    6f80:	8b020060 	add	x0, x3, x2
    6f84:	f9401017 	ldr	x23, [x0, #32]
    6f88:	b4000257 	cbz	x23, 6fd0 <f0+0xeb0>
    6f8c:	38626862 	ldrb	w2, [x3, x2]
    6f90:	7100085f 	cmp	w2, #0x2
    6f94:	5400a880 	b.eq	84a4 <f0+0x2384>  // b.none
    6f98:	7100045f 	cmp	w2, #0x1
    6f9c:	540001a1 	b.ne	6fd0 <f0+0xeb0>  // b.any
    6fa0:	29430002 	ldp	w2, w0, [x0, #24]
    6fa4:	92403c21 	and	x1, x1, #0xffff
    6fa8:	9b027c21 	mul	x1, x1, x2
    6fac:	d360fc21 	lsr	x1, x1, #32
    6fb0:	eb00003f 	cmp	x1, x0
    6fb4:	540000e2 	b.cs	6fd0 <f0+0xeb0>  // b.hs, b.nlast
    6fb8:	8b0102f7 	add	x23, x23, x1
    6fbc:	394002e0 	ldrb	w0, [x23]
    6fc0:	7103fc1f 	cmp	w0, #0xff
    6fc4:	5400b4e0 	b.eq	8660 <f0+0x2540>  // b.none
    6fc8:	52800020 	mov	w0, #0x1                   	// #1
    6fcc:	390002e0 	strb	w0, [x23]
    6fd0:	9110e3e1 	add	x1, sp, #0x438
    6fd4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6fd8:	52800020 	mov	w0, #0x1                   	// #1
    6fdc:	f9021fe2 	str	x2, [sp, #1080]
    6fe0:	f90223f5 	str	x21, [sp, #1088]
    6fe4:	97fff1db 	bl	3750 <fwp_data.part.0.constprop.0>
    6fe8:	97fff126 	bl	3480 <fwp_rc_fresh>
    6fec:	aa0003e2 	mov	x2, x0
    6ff0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6ff4:	911123e1 	add	x1, sp, #0x448
    6ff8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    6ffc:	52800020 	mov	w0, #0x1                   	// #1
    7000:	f90227e3 	str	x3, [sp, #1096]
    7004:	f9022be2 	str	x2, [sp, #1104]
    7008:	97fff1d2 	bl	3750 <fwp_data.part.0.constprop.0>
    700c:	9115c283 	add	x3, x20, #0x570
    7010:	aa0003f5 	mov	x21, x0
    7014:	f949d861 	ldr	x1, [x3, #5040]
    7018:	f949ec60 	ldr	x0, [x3, #5080]
    701c:	cb0102a1 	sub	x1, x21, x1
    7020:	eb00403f 	cmp	x1, x0, lsl #16
    7024:	54000322 	b.cs	7088 <f0+0xf68>  // b.hs, b.nlast
    7028:	d350fc22 	lsr	x2, x1, #16
    702c:	f949fc63 	ldr	x3, [x3, #5112]
    7030:	8b020842 	add	x2, x2, x2, lsl #2
    7034:	d37df042 	lsl	x2, x2, #3
    7038:	8b020060 	add	x0, x3, x2
    703c:	f9401017 	ldr	x23, [x0, #32]
    7040:	b4000257 	cbz	x23, 7088 <f0+0xf68>
    7044:	38626862 	ldrb	w2, [x3, x2]
    7048:	7100085f 	cmp	w2, #0x2
    704c:	5400a260 	b.eq	8498 <f0+0x2378>  // b.none
    7050:	7100045f 	cmp	w2, #0x1
    7054:	540001a1 	b.ne	7088 <f0+0xf68>  // b.any
    7058:	29430002 	ldp	w2, w0, [x0, #24]
    705c:	92403c21 	and	x1, x1, #0xffff
    7060:	9b027c21 	mul	x1, x1, x2
    7064:	d360fc21 	lsr	x1, x1, #32
    7068:	eb00003f 	cmp	x1, x0
    706c:	540000e2 	b.cs	7088 <f0+0xf68>  // b.hs, b.nlast
    7070:	8b0102f7 	add	x23, x23, x1
    7074:	394002e0 	ldrb	w0, [x23]
    7078:	7103fc1f 	cmp	w0, #0xff
    707c:	5400af80 	b.eq	866c <f0+0x254c>  // b.none
    7080:	52800020 	mov	w0, #0x1                   	// #1
    7084:	390002e0 	strb	w0, [x23]
    7088:	911163e1 	add	x1, sp, #0x458
    708c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7090:	52800020 	mov	w0, #0x1                   	// #1
    7094:	f9022fe2 	str	x2, [sp, #1112]
    7098:	f90233f5 	str	x21, [sp, #1120]
    709c:	97fff1ad 	bl	3750 <fwp_data.part.0.constprop.0>
    70a0:	97fff0f8 	bl	3480 <fwp_rc_fresh>
    70a4:	aa0003e2 	mov	x2, x0
    70a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    70ac:	9111a3e1 	add	x1, sp, #0x468
    70b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    70b4:	52800020 	mov	w0, #0x1                   	// #1
    70b8:	f90237e3 	str	x3, [sp, #1128]
    70bc:	f9023be2 	str	x2, [sp, #1136]
    70c0:	97fff1a4 	bl	3750 <fwp_data.part.0.constprop.0>
    70c4:	9115c283 	add	x3, x20, #0x570
    70c8:	aa0003f5 	mov	x21, x0
    70cc:	f949d861 	ldr	x1, [x3, #5040]
    70d0:	f949ec60 	ldr	x0, [x3, #5080]
    70d4:	cb0102a1 	sub	x1, x21, x1
    70d8:	eb00403f 	cmp	x1, x0, lsl #16
    70dc:	54000322 	b.cs	7140 <f0+0x1020>  // b.hs, b.nlast
    70e0:	d350fc22 	lsr	x2, x1, #16
    70e4:	f949fc63 	ldr	x3, [x3, #5112]
    70e8:	8b020842 	add	x2, x2, x2, lsl #2
    70ec:	d37df042 	lsl	x2, x2, #3
    70f0:	8b020060 	add	x0, x3, x2
    70f4:	f9401017 	ldr	x23, [x0, #32]
    70f8:	b4000257 	cbz	x23, 7140 <f0+0x1020>
    70fc:	38626862 	ldrb	w2, [x3, x2]
    7100:	7100085f 	cmp	w2, #0x2
    7104:	540099a0 	b.eq	8438 <f0+0x2318>  // b.none
    7108:	7100045f 	cmp	w2, #0x1
    710c:	540001a1 	b.ne	7140 <f0+0x1020>  // b.any
    7110:	29430002 	ldp	w2, w0, [x0, #24]
    7114:	92403c21 	and	x1, x1, #0xffff
    7118:	9b027c21 	mul	x1, x1, x2
    711c:	d360fc21 	lsr	x1, x1, #32
    7120:	eb00003f 	cmp	x1, x0
    7124:	540000e2 	b.cs	7140 <f0+0x1020>  // b.hs, b.nlast
    7128:	8b0102f7 	add	x23, x23, x1
    712c:	394002e0 	ldrb	w0, [x23]
    7130:	7103fc1f 	cmp	w0, #0xff
    7134:	5400aa20 	b.eq	8678 <f0+0x2558>  // b.none
    7138:	52800020 	mov	w0, #0x1                   	// #1
    713c:	390002e0 	strb	w0, [x23]
    7140:	9111e3e1 	add	x1, sp, #0x478
    7144:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7148:	52800020 	mov	w0, #0x1                   	// #1
    714c:	f9023ff7 	str	x23, [sp, #1144]
    7150:	f90243f5 	str	x21, [sp, #1152]
    7154:	97fff17f 	bl	3750 <fwp_data.part.0.constprop.0>
    7158:	97fff0ca 	bl	3480 <fwp_rc_fresh>
    715c:	aa0003e2 	mov	x2, x0
    7160:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7164:	911223e1 	add	x1, sp, #0x488
    7168:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    716c:	52800020 	mov	w0, #0x1                   	// #1
    7170:	f90247e3 	str	x3, [sp, #1160]
    7174:	f9024be2 	str	x2, [sp, #1168]
    7178:	97fff176 	bl	3750 <fwp_data.part.0.constprop.0>
    717c:	97fff0c1 	bl	3480 <fwp_rc_fresh>
    7180:	aa0003e2 	mov	x2, x0
    7184:	911263e1 	add	x1, sp, #0x498
    7188:	52800020 	mov	w0, #0x1                   	// #1
    718c:	f9024ff7 	str	x23, [sp, #1176]
    7190:	f90253e2 	str	x2, [sp, #1184]
    7194:	97fff16f 	bl	3750 <fwp_data.part.0.constprop.0>
    7198:	9115c283 	add	x3, x20, #0x570
    719c:	aa0003f5 	mov	x21, x0
    71a0:	f949d861 	ldr	x1, [x3, #5040]
    71a4:	f949ec60 	ldr	x0, [x3, #5080]
    71a8:	cb0102a1 	sub	x1, x21, x1
    71ac:	eb00403f 	cmp	x1, x0, lsl #16
    71b0:	54000322 	b.cs	7214 <f0+0x10f4>  // b.hs, b.nlast
    71b4:	d350fc22 	lsr	x2, x1, #16
    71b8:	f949fc63 	ldr	x3, [x3, #5112]
    71bc:	8b020842 	add	x2, x2, x2, lsl #2
    71c0:	d37df042 	lsl	x2, x2, #3
    71c4:	8b020060 	add	x0, x3, x2
    71c8:	f9401017 	ldr	x23, [x0, #32]
    71cc:	b4000257 	cbz	x23, 7214 <f0+0x10f4>
    71d0:	38626862 	ldrb	w2, [x3, x2]
    71d4:	7100085f 	cmp	w2, #0x2
    71d8:	540092a0 	b.eq	842c <f0+0x230c>  // b.none
    71dc:	7100045f 	cmp	w2, #0x1
    71e0:	540001a1 	b.ne	7214 <f0+0x10f4>  // b.any
    71e4:	29430002 	ldp	w2, w0, [x0, #24]
    71e8:	92403c21 	and	x1, x1, #0xffff
    71ec:	9b027c21 	mul	x1, x1, x2
    71f0:	d360fc21 	lsr	x1, x1, #32
    71f4:	eb00003f 	cmp	x1, x0
    71f8:	540000e2 	b.cs	7214 <f0+0x10f4>  // b.hs, b.nlast
    71fc:	8b0102f7 	add	x23, x23, x1
    7200:	394002e0 	ldrb	w0, [x23]
    7204:	7103fc1f 	cmp	w0, #0xff
    7208:	5400a3e0 	b.eq	8684 <f0+0x2564>  // b.none
    720c:	52800020 	mov	w0, #0x1                   	// #1
    7210:	390002e0 	strb	w0, [x23]
    7214:	9112a3e1 	add	x1, sp, #0x4a8
    7218:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    721c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7220:	52800020 	mov	w0, #0x1                   	// #1
    7224:	f90257f7 	str	x23, [sp, #1192]
    7228:	f9025bf5 	str	x21, [sp, #1200]
    722c:	97fff149 	bl	3750 <fwp_data.part.0.constprop.0>
    7230:	97fff094 	bl	3480 <fwp_rc_fresh>
    7234:	aa0003e2 	mov	x2, x0
    7238:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    723c:	9112e3e1 	add	x1, sp, #0x4b8
    7240:	52800020 	mov	w0, #0x1                   	// #1
    7244:	f9025fe3 	str	x3, [sp, #1208]
    7248:	f90263e2 	str	x2, [sp, #1216]
    724c:	97fff141 	bl	3750 <fwp_data.part.0.constprop.0>
    7250:	97fff08c 	bl	3480 <fwp_rc_fresh>
    7254:	aa0003e2 	mov	x2, x0
    7258:	911323e1 	add	x1, sp, #0x4c8
    725c:	52800020 	mov	w0, #0x1                   	// #1
    7260:	f90267f7 	str	x23, [sp, #1224]
    7264:	f9026be2 	str	x2, [sp, #1232]
    7268:	97fff13a 	bl	3750 <fwp_data.part.0.constprop.0>
    726c:	9115c283 	add	x3, x20, #0x570
    7270:	aa0003f5 	mov	x21, x0
    7274:	f949d861 	ldr	x1, [x3, #5040]
    7278:	f949ec60 	ldr	x0, [x3, #5080]
    727c:	cb0102a1 	sub	x1, x21, x1
    7280:	eb00403f 	cmp	x1, x0, lsl #16
    7284:	54000322 	b.cs	72e8 <f0+0x11c8>  // b.hs, b.nlast
    7288:	d350fc22 	lsr	x2, x1, #16
    728c:	f949fc63 	ldr	x3, [x3, #5112]
    7290:	8b020842 	add	x2, x2, x2, lsl #2
    7294:	d37df042 	lsl	x2, x2, #3
    7298:	8b020060 	add	x0, x3, x2
    729c:	f9401017 	ldr	x23, [x0, #32]
    72a0:	b4000257 	cbz	x23, 72e8 <f0+0x11c8>
    72a4:	38626862 	ldrb	w2, [x3, x2]
    72a8:	7100085f 	cmp	w2, #0x2
    72ac:	54008ba0 	b.eq	8420 <f0+0x2300>  // b.none
    72b0:	7100045f 	cmp	w2, #0x1
    72b4:	540001a1 	b.ne	72e8 <f0+0x11c8>  // b.any
    72b8:	29430002 	ldp	w2, w0, [x0, #24]
    72bc:	92403c21 	and	x1, x1, #0xffff
    72c0:	9b027c21 	mul	x1, x1, x2
    72c4:	d360fc21 	lsr	x1, x1, #32
    72c8:	eb00003f 	cmp	x1, x0
    72cc:	540000e2 	b.cs	72e8 <f0+0x11c8>  // b.hs, b.nlast
    72d0:	8b0102f7 	add	x23, x23, x1
    72d4:	394002e0 	ldrb	w0, [x23]
    72d8:	7103fc1f 	cmp	w0, #0xff
    72dc:	54009da0 	b.eq	8690 <f0+0x2570>  // b.none
    72e0:	52800020 	mov	w0, #0x1                   	// #1
    72e4:	390002e0 	strb	w0, [x23]
    72e8:	911363e1 	add	x1, sp, #0x4d8
    72ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    72f0:	52800020 	mov	w0, #0x1                   	// #1
    72f4:	f9026fe2 	str	x2, [sp, #1240]
    72f8:	f90273f5 	str	x21, [sp, #1248]
    72fc:	97fff115 	bl	3750 <fwp_data.part.0.constprop.0>
    7300:	97fff060 	bl	3480 <fwp_rc_fresh>
    7304:	aa0003e2 	mov	x2, x0
    7308:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    730c:	9113a3e1 	add	x1, sp, #0x4e8
    7310:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7314:	52800020 	mov	w0, #0x1                   	// #1
    7318:	f90277e3 	str	x3, [sp, #1256]
    731c:	f9027be2 	str	x2, [sp, #1264]
    7320:	97fff10c 	bl	3750 <fwp_data.part.0.constprop.0>
    7324:	9115c283 	add	x3, x20, #0x570
    7328:	aa0003f5 	mov	x21, x0
    732c:	f949d861 	ldr	x1, [x3, #5040]
    7330:	f949ec60 	ldr	x0, [x3, #5080]
    7334:	cb0102a1 	sub	x1, x21, x1
    7338:	eb00403f 	cmp	x1, x0, lsl #16
    733c:	54000322 	b.cs	73a0 <f0+0x1280>  // b.hs, b.nlast
    7340:	d350fc22 	lsr	x2, x1, #16
    7344:	f949fc63 	ldr	x3, [x3, #5112]
    7348:	8b020842 	add	x2, x2, x2, lsl #2
    734c:	d37df042 	lsl	x2, x2, #3
    7350:	8b020060 	add	x0, x3, x2
    7354:	f9401017 	ldr	x23, [x0, #32]
    7358:	b4000257 	cbz	x23, 73a0 <f0+0x1280>
    735c:	38626862 	ldrb	w2, [x3, x2]
    7360:	7100085f 	cmp	w2, #0x2
    7364:	54008580 	b.eq	8414 <f0+0x22f4>  // b.none
    7368:	7100045f 	cmp	w2, #0x1
    736c:	540001a1 	b.ne	73a0 <f0+0x1280>  // b.any
    7370:	29430002 	ldp	w2, w0, [x0, #24]
    7374:	92403c21 	and	x1, x1, #0xffff
    7378:	9b027c21 	mul	x1, x1, x2
    737c:	d360fc21 	lsr	x1, x1, #32
    7380:	eb00003f 	cmp	x1, x0
    7384:	540000e2 	b.cs	73a0 <f0+0x1280>  // b.hs, b.nlast
    7388:	8b0102f7 	add	x23, x23, x1
    738c:	394002e0 	ldrb	w0, [x23]
    7390:	7103fc1f 	cmp	w0, #0xff
    7394:	54009840 	b.eq	869c <f0+0x257c>  // b.none
    7398:	52800020 	mov	w0, #0x1                   	// #1
    739c:	390002e0 	strb	w0, [x23]
    73a0:	9113e3e1 	add	x1, sp, #0x4f8
    73a4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    73a8:	52800020 	mov	w0, #0x1                   	// #1
    73ac:	f9027ff7 	str	x23, [sp, #1272]
    73b0:	f90283f5 	str	x21, [sp, #1280]
    73b4:	97fff0e7 	bl	3750 <fwp_data.part.0.constprop.0>
    73b8:	97fff032 	bl	3480 <fwp_rc_fresh>
    73bc:	aa0003e2 	mov	x2, x0
    73c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    73c4:	911423e1 	add	x1, sp, #0x508
    73c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    73cc:	52800020 	mov	w0, #0x1                   	// #1
    73d0:	f90287e3 	str	x3, [sp, #1288]
    73d4:	f9028be2 	str	x2, [sp, #1296]
    73d8:	97fff0de 	bl	3750 <fwp_data.part.0.constprop.0>
    73dc:	97fff029 	bl	3480 <fwp_rc_fresh>
    73e0:	aa0003e2 	mov	x2, x0
    73e4:	911463e1 	add	x1, sp, #0x518
    73e8:	52800020 	mov	w0, #0x1                   	// #1
    73ec:	f9028ff7 	str	x23, [sp, #1304]
    73f0:	f90293e2 	str	x2, [sp, #1312]
    73f4:	97fff0d7 	bl	3750 <fwp_data.part.0.constprop.0>
    73f8:	9115c283 	add	x3, x20, #0x570
    73fc:	aa0003f5 	mov	x21, x0
    7400:	f949d861 	ldr	x1, [x3, #5040]
    7404:	f949ec60 	ldr	x0, [x3, #5080]
    7408:	cb0102a1 	sub	x1, x21, x1
    740c:	eb00403f 	cmp	x1, x0, lsl #16
    7410:	54000322 	b.cs	7474 <f0+0x1354>  // b.hs, b.nlast
    7414:	d350fc22 	lsr	x2, x1, #16
    7418:	f949fc63 	ldr	x3, [x3, #5112]
    741c:	8b020842 	add	x2, x2, x2, lsl #2
    7420:	d37df042 	lsl	x2, x2, #3
    7424:	8b020060 	add	x0, x3, x2
    7428:	f9401017 	ldr	x23, [x0, #32]
    742c:	b4000257 	cbz	x23, 7474 <f0+0x1354>
    7430:	38626862 	ldrb	w2, [x3, x2]
    7434:	7100085f 	cmp	w2, #0x2
    7438:	54007e80 	b.eq	8408 <f0+0x22e8>  // b.none
    743c:	7100045f 	cmp	w2, #0x1
    7440:	540001a1 	b.ne	7474 <f0+0x1354>  // b.any
    7444:	29430002 	ldp	w2, w0, [x0, #24]
    7448:	92403c21 	and	x1, x1, #0xffff
    744c:	9b027c21 	mul	x1, x1, x2
    7450:	d360fc21 	lsr	x1, x1, #32
    7454:	eb00003f 	cmp	x1, x0
    7458:	540000e2 	b.cs	7474 <f0+0x1354>  // b.hs, b.nlast
    745c:	8b0102f7 	add	x23, x23, x1
    7460:	394002e0 	ldrb	w0, [x23]
    7464:	7103fc1f 	cmp	w0, #0xff
    7468:	54009200 	b.eq	86a8 <f0+0x2588>  // b.none
    746c:	52800020 	mov	w0, #0x1                   	// #1
    7470:	390002e0 	strb	w0, [x23]
    7474:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7478:	9114a3e1 	add	x1, sp, #0x528
    747c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7480:	52800020 	mov	w0, #0x1                   	// #1
    7484:	f90297e2 	str	x2, [sp, #1320]
    7488:	f9029bf5 	str	x21, [sp, #1328]
    748c:	97fff0b1 	bl	3750 <fwp_data.part.0.constprop.0>
    7490:	9115c283 	add	x3, x20, #0x570
    7494:	aa0003f5 	mov	x21, x0
    7498:	f949d861 	ldr	x1, [x3, #5040]
    749c:	f949ec60 	ldr	x0, [x3, #5080]
    74a0:	cb0102a1 	sub	x1, x21, x1
    74a4:	eb00403f 	cmp	x1, x0, lsl #16
    74a8:	54000322 	b.cs	750c <f0+0x13ec>  // b.hs, b.nlast
    74ac:	d350fc22 	lsr	x2, x1, #16
    74b0:	f949fc63 	ldr	x3, [x3, #5112]
    74b4:	8b020842 	add	x2, x2, x2, lsl #2
    74b8:	d37df042 	lsl	x2, x2, #3
    74bc:	8b020060 	add	x0, x3, x2
    74c0:	f9401017 	ldr	x23, [x0, #32]
    74c4:	b4000257 	cbz	x23, 750c <f0+0x13ec>
    74c8:	38626862 	ldrb	w2, [x3, x2]
    74cc:	7100085f 	cmp	w2, #0x2
    74d0:	54007960 	b.eq	83fc <f0+0x22dc>  // b.none
    74d4:	7100045f 	cmp	w2, #0x1
    74d8:	540001a1 	b.ne	750c <f0+0x13ec>  // b.any
    74dc:	29430002 	ldp	w2, w0, [x0, #24]
    74e0:	92403c21 	and	x1, x1, #0xffff
    74e4:	9b027c21 	mul	x1, x1, x2
    74e8:	d360fc21 	lsr	x1, x1, #32
    74ec:	eb00003f 	cmp	x1, x0
    74f0:	540000e2 	b.cs	750c <f0+0x13ec>  // b.hs, b.nlast
    74f4:	8b0102f7 	add	x23, x23, x1
    74f8:	394002e0 	ldrb	w0, [x23]
    74fc:	7103fc1f 	cmp	w0, #0xff
    7500:	54008da0 	b.eq	86b4 <f0+0x2594>  // b.none
    7504:	52800020 	mov	w0, #0x1                   	// #1
    7508:	390002e0 	strb	w0, [x23]
    750c:	9114e3e1 	add	x1, sp, #0x538
    7510:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7514:	52800020 	mov	w0, #0x1                   	// #1
    7518:	f9029fe2 	str	x2, [sp, #1336]
    751c:	f902a3f5 	str	x21, [sp, #1344]
    7520:	97fff08c 	bl	3750 <fwp_data.part.0.constprop.0>
    7524:	97ffefd7 	bl	3480 <fwp_rc_fresh>
    7528:	aa0003e2 	mov	x2, x0
    752c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7530:	911523e1 	add	x1, sp, #0x548
    7534:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7538:	52800020 	mov	w0, #0x1                   	// #1
    753c:	f902a7e3 	str	x3, [sp, #1352]
    7540:	f902abe2 	str	x2, [sp, #1360]
    7544:	97fff083 	bl	3750 <fwp_data.part.0.constprop.0>
    7548:	9115c283 	add	x3, x20, #0x570
    754c:	aa0003f5 	mov	x21, x0
    7550:	f949d861 	ldr	x1, [x3, #5040]
    7554:	f949ec60 	ldr	x0, [x3, #5080]
    7558:	cb0102a1 	sub	x1, x21, x1
    755c:	eb00403f 	cmp	x1, x0, lsl #16
    7560:	54000322 	b.cs	75c4 <f0+0x14a4>  // b.hs, b.nlast
    7564:	d350fc22 	lsr	x2, x1, #16
    7568:	f949fc63 	ldr	x3, [x3, #5112]
    756c:	8b020842 	add	x2, x2, x2, lsl #2
    7570:	d37df042 	lsl	x2, x2, #3
    7574:	8b020060 	add	x0, x3, x2
    7578:	f9401017 	ldr	x23, [x0, #32]
    757c:	b4000257 	cbz	x23, 75c4 <f0+0x14a4>
    7580:	38626862 	ldrb	w2, [x3, x2]
    7584:	7100085f 	cmp	w2, #0x2
    7588:	54007340 	b.eq	83f0 <f0+0x22d0>  // b.none
    758c:	7100045f 	cmp	w2, #0x1
    7590:	540001a1 	b.ne	75c4 <f0+0x14a4>  // b.any
    7594:	29430002 	ldp	w2, w0, [x0, #24]
    7598:	92403c21 	and	x1, x1, #0xffff
    759c:	9b027c21 	mul	x1, x1, x2
    75a0:	d360fc21 	lsr	x1, x1, #32
    75a4:	eb00003f 	cmp	x1, x0
    75a8:	540000e2 	b.cs	75c4 <f0+0x14a4>  // b.hs, b.nlast
    75ac:	8b0102f7 	add	x23, x23, x1
    75b0:	394002e0 	ldrb	w0, [x23]
    75b4:	7103fc1f 	cmp	w0, #0xff
    75b8:	54008840 	b.eq	86c0 <f0+0x25a0>  // b.none
    75bc:	52800020 	mov	w0, #0x1                   	// #1
    75c0:	390002e0 	strb	w0, [x23]
    75c4:	911563e1 	add	x1, sp, #0x558
    75c8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    75cc:	52800020 	mov	w0, #0x1                   	// #1
    75d0:	f902afe2 	str	x2, [sp, #1368]
    75d4:	f902b3f5 	str	x21, [sp, #1376]
    75d8:	97fff05e 	bl	3750 <fwp_data.part.0.constprop.0>
    75dc:	97ffefa9 	bl	3480 <fwp_rc_fresh>
    75e0:	aa0003e2 	mov	x2, x0
    75e4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    75e8:	9115a3e1 	add	x1, sp, #0x568
    75ec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    75f0:	52800020 	mov	w0, #0x1                   	// #1
    75f4:	f902b7e3 	str	x3, [sp, #1384]
    75f8:	f902bbe2 	str	x2, [sp, #1392]
    75fc:	97fff055 	bl	3750 <fwp_data.part.0.constprop.0>
    7600:	9115c283 	add	x3, x20, #0x570
    7604:	aa0003f5 	mov	x21, x0
    7608:	f949d861 	ldr	x1, [x3, #5040]
    760c:	f949ec60 	ldr	x0, [x3, #5080]
    7610:	cb0102a1 	sub	x1, x21, x1
    7614:	eb00403f 	cmp	x1, x0, lsl #16
    7618:	54000322 	b.cs	767c <f0+0x155c>  // b.hs, b.nlast
    761c:	d350fc22 	lsr	x2, x1, #16
    7620:	f949fc63 	ldr	x3, [x3, #5112]
    7624:	8b020842 	add	x2, x2, x2, lsl #2
    7628:	d37df042 	lsl	x2, x2, #3
    762c:	8b020060 	add	x0, x3, x2
    7630:	f9401017 	ldr	x23, [x0, #32]
    7634:	b4000257 	cbz	x23, 767c <f0+0x155c>
    7638:	38626862 	ldrb	w2, [x3, x2]
    763c:	7100085f 	cmp	w2, #0x2
    7640:	54006d20 	b.eq	83e4 <f0+0x22c4>  // b.none
    7644:	7100045f 	cmp	w2, #0x1
    7648:	540001a1 	b.ne	767c <f0+0x155c>  // b.any
    764c:	29430002 	ldp	w2, w0, [x0, #24]
    7650:	92403c21 	and	x1, x1, #0xffff
    7654:	9b027c21 	mul	x1, x1, x2
    7658:	d360fc21 	lsr	x1, x1, #32
    765c:	eb00003f 	cmp	x1, x0
    7660:	540000e2 	b.cs	767c <f0+0x155c>  // b.hs, b.nlast
    7664:	8b0102f7 	add	x23, x23, x1
    7668:	394002e0 	ldrb	w0, [x23]
    766c:	7103fc1f 	cmp	w0, #0xff
    7670:	540082e0 	b.eq	86cc <f0+0x25ac>  // b.none
    7674:	52800020 	mov	w0, #0x1                   	// #1
    7678:	390002e0 	strb	w0, [x23]
    767c:	9115e3e1 	add	x1, sp, #0x578
    7680:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7684:	52800020 	mov	w0, #0x1                   	// #1
    7688:	f902bff7 	str	x23, [sp, #1400]
    768c:	f902c3f5 	str	x21, [sp, #1408]
    7690:	97fff030 	bl	3750 <fwp_data.part.0.constprop.0>
    7694:	97ffef7b 	bl	3480 <fwp_rc_fresh>
    7698:	aa0003e2 	mov	x2, x0
    769c:	911623e1 	add	x1, sp, #0x588
    76a0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    76a4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    76a8:	52800020 	mov	w0, #0x1                   	// #1
    76ac:	f902c7f5 	str	x21, [sp, #1416]
    76b0:	f902cbe2 	str	x2, [sp, #1424]
    76b4:	97fff027 	bl	3750 <fwp_data.part.0.constprop.0>
    76b8:	97ffef72 	bl	3480 <fwp_rc_fresh>
    76bc:	aa0003e2 	mov	x2, x0
    76c0:	911663e1 	add	x1, sp, #0x598
    76c4:	52800020 	mov	w0, #0x1                   	// #1
    76c8:	f902cff7 	str	x23, [sp, #1432]
    76cc:	f902d3e2 	str	x2, [sp, #1440]
    76d0:	97fff020 	bl	3750 <fwp_data.part.0.constprop.0>
    76d4:	97ffef6b 	bl	3480 <fwp_rc_fresh>
    76d8:	aa0003e2 	mov	x2, x0
    76dc:	9116a3e1 	add	x1, sp, #0x5a8
    76e0:	52800020 	mov	w0, #0x1                   	// #1
    76e4:	f902d7f5 	str	x21, [sp, #1448]
    76e8:	f902dbe2 	str	x2, [sp, #1456]
    76ec:	97fff019 	bl	3750 <fwp_data.part.0.constprop.0>
    76f0:	9115c283 	add	x3, x20, #0x570
    76f4:	aa0003f5 	mov	x21, x0
    76f8:	f949d861 	ldr	x1, [x3, #5040]
    76fc:	f949ec60 	ldr	x0, [x3, #5080]
    7700:	cb0102a1 	sub	x1, x21, x1
    7704:	eb00403f 	cmp	x1, x0, lsl #16
    7708:	54000322 	b.cs	776c <f0+0x164c>  // b.hs, b.nlast
    770c:	d350fc22 	lsr	x2, x1, #16
    7710:	f949fc63 	ldr	x3, [x3, #5112]
    7714:	8b020842 	add	x2, x2, x2, lsl #2
    7718:	d37df042 	lsl	x2, x2, #3
    771c:	8b020060 	add	x0, x3, x2
    7720:	f9401017 	ldr	x23, [x0, #32]
    7724:	b4000257 	cbz	x23, 776c <f0+0x164c>
    7728:	38626862 	ldrb	w2, [x3, x2]
    772c:	7100085f 	cmp	w2, #0x2
    7730:	540073e0 	b.eq	85ac <f0+0x248c>  // b.none
    7734:	7100045f 	cmp	w2, #0x1
    7738:	540001a1 	b.ne	776c <f0+0x164c>  // b.any
    773c:	29430002 	ldp	w2, w0, [x0, #24]
    7740:	92403c21 	and	x1, x1, #0xffff
    7744:	9b027c21 	mul	x1, x1, x2
    7748:	d360fc21 	lsr	x1, x1, #32
    774c:	eb00003f 	cmp	x1, x0
    7750:	540000e2 	b.cs	776c <f0+0x164c>  // b.hs, b.nlast
    7754:	8b0102f7 	add	x23, x23, x1
    7758:	394002e0 	ldrb	w0, [x23]
    775c:	7103fc1f 	cmp	w0, #0xff
    7760:	54007bc0 	b.eq	86d8 <f0+0x25b8>  // b.none
    7764:	52800020 	mov	w0, #0x1                   	// #1
    7768:	390002e0 	strb	w0, [x23]
    776c:	9116e3e1 	add	x1, sp, #0x5b8
    7770:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7774:	52800020 	mov	w0, #0x1                   	// #1
    7778:	f902dfe2 	str	x2, [sp, #1464]
    777c:	f902e3f5 	str	x21, [sp, #1472]
    7780:	97ffeff4 	bl	3750 <fwp_data.part.0.constprop.0>
    7784:	97ffef3f 	bl	3480 <fwp_rc_fresh>
    7788:	aa0003e2 	mov	x2, x0
    778c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7790:	911723e1 	add	x1, sp, #0x5c8
    7794:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7798:	52800020 	mov	w0, #0x1                   	// #1
    779c:	f902e7e3 	str	x3, [sp, #1480]
    77a0:	f902ebe2 	str	x2, [sp, #1488]
    77a4:	97ffefeb 	bl	3750 <fwp_data.part.0.constprop.0>
    77a8:	9115c283 	add	x3, x20, #0x570
    77ac:	aa0003f5 	mov	x21, x0
    77b0:	f949d861 	ldr	x1, [x3, #5040]
    77b4:	f949ec60 	ldr	x0, [x3, #5080]
    77b8:	cb0102a1 	sub	x1, x21, x1
    77bc:	eb00403f 	cmp	x1, x0, lsl #16
    77c0:	54000322 	b.cs	7824 <f0+0x1704>  // b.hs, b.nlast
    77c4:	d350fc22 	lsr	x2, x1, #16
    77c8:	f949fc63 	ldr	x3, [x3, #5112]
    77cc:	8b020842 	add	x2, x2, x2, lsl #2
    77d0:	d37df042 	lsl	x2, x2, #3
    77d4:	8b020060 	add	x0, x3, x2
    77d8:	f9401017 	ldr	x23, [x0, #32]
    77dc:	b4000257 	cbz	x23, 7824 <f0+0x1704>
    77e0:	38626862 	ldrb	w2, [x3, x2]
    77e4:	7100085f 	cmp	w2, #0x2
    77e8:	54006dc0 	b.eq	85a0 <f0+0x2480>  // b.none
    77ec:	7100045f 	cmp	w2, #0x1
    77f0:	540001a1 	b.ne	7824 <f0+0x1704>  // b.any
    77f4:	29430002 	ldp	w2, w0, [x0, #24]
    77f8:	92403c21 	and	x1, x1, #0xffff
    77fc:	9b027c21 	mul	x1, x1, x2
    7800:	d360fc21 	lsr	x1, x1, #32
    7804:	eb00003f 	cmp	x1, x0
    7808:	540000e2 	b.cs	7824 <f0+0x1704>  // b.hs, b.nlast
    780c:	8b0102f7 	add	x23, x23, x1
    7810:	394002e0 	ldrb	w0, [x23]
    7814:	7103fc1f 	cmp	w0, #0xff
    7818:	54007660 	b.eq	86e4 <f0+0x25c4>  // b.none
    781c:	52800020 	mov	w0, #0x1                   	// #1
    7820:	390002e0 	strb	w0, [x23]
    7824:	911763e1 	add	x1, sp, #0x5d8
    7828:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    782c:	52800020 	mov	w0, #0x1                   	// #1
    7830:	f902efe2 	str	x2, [sp, #1496]
    7834:	f902f3f5 	str	x21, [sp, #1504]
    7838:	97ffefc6 	bl	3750 <fwp_data.part.0.constprop.0>
    783c:	97ffef11 	bl	3480 <fwp_rc_fresh>
    7840:	aa0003e2 	mov	x2, x0
    7844:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7848:	9117a3e1 	add	x1, sp, #0x5e8
    784c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7850:	52800020 	mov	w0, #0x1                   	// #1
    7854:	f902f7e3 	str	x3, [sp, #1512]
    7858:	f902fbe2 	str	x2, [sp, #1520]
    785c:	97ffefbd 	bl	3750 <fwp_data.part.0.constprop.0>
    7860:	9115c283 	add	x3, x20, #0x570
    7864:	aa0003f5 	mov	x21, x0
    7868:	f949d861 	ldr	x1, [x3, #5040]
    786c:	f949ec60 	ldr	x0, [x3, #5080]
    7870:	cb0102a1 	sub	x1, x21, x1
    7874:	eb00403f 	cmp	x1, x0, lsl #16
    7878:	54000322 	b.cs	78dc <f0+0x17bc>  // b.hs, b.nlast
    787c:	d350fc22 	lsr	x2, x1, #16
    7880:	f949fc63 	ldr	x3, [x3, #5112]
    7884:	8b020842 	add	x2, x2, x2, lsl #2
    7888:	d37df042 	lsl	x2, x2, #3
    788c:	8b020060 	add	x0, x3, x2
    7890:	f9401017 	ldr	x23, [x0, #32]
    7894:	b4000257 	cbz	x23, 78dc <f0+0x17bc>
    7898:	38626862 	ldrb	w2, [x3, x2]
    789c:	7100085f 	cmp	w2, #0x2
    78a0:	540067a0 	b.eq	8594 <f0+0x2474>  // b.none
    78a4:	7100045f 	cmp	w2, #0x1
    78a8:	540001a1 	b.ne	78dc <f0+0x17bc>  // b.any
    78ac:	29430002 	ldp	w2, w0, [x0, #24]
    78b0:	92403c21 	and	x1, x1, #0xffff
    78b4:	9b027c21 	mul	x1, x1, x2
    78b8:	d360fc21 	lsr	x1, x1, #32
    78bc:	eb00003f 	cmp	x1, x0
    78c0:	540000e2 	b.cs	78dc <f0+0x17bc>  // b.hs, b.nlast
    78c4:	8b0102f7 	add	x23, x23, x1
    78c8:	394002e0 	ldrb	w0, [x23]
    78cc:	7103fc1f 	cmp	w0, #0xff
    78d0:	54007100 	b.eq	86f0 <f0+0x25d0>  // b.none
    78d4:	52800020 	mov	w0, #0x1                   	// #1
    78d8:	390002e0 	strb	w0, [x23]
    78dc:	9117e3e1 	add	x1, sp, #0x5f8
    78e0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    78e4:	52800020 	mov	w0, #0x1                   	// #1
    78e8:	f902fff7 	str	x23, [sp, #1528]
    78ec:	f90303f5 	str	x21, [sp, #1536]
    78f0:	97ffef98 	bl	3750 <fwp_data.part.0.constprop.0>
    78f4:	97ffeee3 	bl	3480 <fwp_rc_fresh>
    78f8:	aa0003e2 	mov	x2, x0
    78fc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7900:	911823e1 	add	x1, sp, #0x608
    7904:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7908:	52800020 	mov	w0, #0x1                   	// #1
    790c:	f90307e3 	str	x3, [sp, #1544]
    7910:	f9030be2 	str	x2, [sp, #1552]
    7914:	97ffef8f 	bl	3750 <fwp_data.part.0.constprop.0>
    7918:	97ffeeda 	bl	3480 <fwp_rc_fresh>
    791c:	aa0003e2 	mov	x2, x0
    7920:	911863e1 	add	x1, sp, #0x618
    7924:	52800020 	mov	w0, #0x1                   	// #1
    7928:	f9030ff7 	str	x23, [sp, #1560]
    792c:	f90313e2 	str	x2, [sp, #1568]
    7930:	97ffef88 	bl	3750 <fwp_data.part.0.constprop.0>
    7934:	9115c283 	add	x3, x20, #0x570
    7938:	aa0003f5 	mov	x21, x0
    793c:	f949d861 	ldr	x1, [x3, #5040]
    7940:	f949ec60 	ldr	x0, [x3, #5080]
    7944:	cb0102a1 	sub	x1, x21, x1
    7948:	eb00403f 	cmp	x1, x0, lsl #16
    794c:	54000322 	b.cs	79b0 <f0+0x1890>  // b.hs, b.nlast
    7950:	d350fc22 	lsr	x2, x1, #16
    7954:	f949fc63 	ldr	x3, [x3, #5112]
    7958:	8b020842 	add	x2, x2, x2, lsl #2
    795c:	d37df042 	lsl	x2, x2, #3
    7960:	8b020060 	add	x0, x3, x2
    7964:	f9401017 	ldr	x23, [x0, #32]
    7968:	b4000257 	cbz	x23, 79b0 <f0+0x1890>
    796c:	38626862 	ldrb	w2, [x3, x2]
    7970:	7100085f 	cmp	w2, #0x2
    7974:	540060a0 	b.eq	8588 <f0+0x2468>  // b.none
    7978:	7100045f 	cmp	w2, #0x1
    797c:	540001a1 	b.ne	79b0 <f0+0x1890>  // b.any
    7980:	29430002 	ldp	w2, w0, [x0, #24]
    7984:	92403c21 	and	x1, x1, #0xffff
    7988:	9b027c21 	mul	x1, x1, x2
    798c:	d360fc21 	lsr	x1, x1, #32
    7990:	eb00003f 	cmp	x1, x0
    7994:	540000e2 	b.cs	79b0 <f0+0x1890>  // b.hs, b.nlast
    7998:	8b0102f7 	add	x23, x23, x1
    799c:	394002e0 	ldrb	w0, [x23]
    79a0:	7103fc1f 	cmp	w0, #0xff
    79a4:	54006ac0 	b.eq	86fc <f0+0x25dc>  // b.none
    79a8:	52800020 	mov	w0, #0x1                   	// #1
    79ac:	390002e0 	strb	w0, [x23]
    79b0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    79b4:	9118a3e1 	add	x1, sp, #0x628
    79b8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    79bc:	52800020 	mov	w0, #0x1                   	// #1
    79c0:	f90317e2 	str	x2, [sp, #1576]
    79c4:	f9031bf5 	str	x21, [sp, #1584]
    79c8:	97ffef62 	bl	3750 <fwp_data.part.0.constprop.0>
    79cc:	9115c283 	add	x3, x20, #0x570
    79d0:	aa0003f7 	mov	x23, x0
    79d4:	f949d861 	ldr	x1, [x3, #5040]
    79d8:	f949ec60 	ldr	x0, [x3, #5080]
    79dc:	cb0102e1 	sub	x1, x23, x1
    79e0:	eb00403f 	cmp	x1, x0, lsl #16
    79e4:	54000322 	b.cs	7a48 <f0+0x1928>  // b.hs, b.nlast
    79e8:	d350fc22 	lsr	x2, x1, #16
    79ec:	f949fc63 	ldr	x3, [x3, #5112]
    79f0:	8b020842 	add	x2, x2, x2, lsl #2
    79f4:	d37df042 	lsl	x2, x2, #3
    79f8:	8b020060 	add	x0, x3, x2
    79fc:	f9401015 	ldr	x21, [x0, #32]
    7a00:	b4000255 	cbz	x21, 7a48 <f0+0x1928>
    7a04:	38626862 	ldrb	w2, [x3, x2]
    7a08:	7100085f 	cmp	w2, #0x2
    7a0c:	54005b80 	b.eq	857c <f0+0x245c>  // b.none
    7a10:	7100045f 	cmp	w2, #0x1
    7a14:	540001a1 	b.ne	7a48 <f0+0x1928>  // b.any
    7a18:	29430002 	ldp	w2, w0, [x0, #24]
    7a1c:	92403c21 	and	x1, x1, #0xffff
    7a20:	9b027c21 	mul	x1, x1, x2
    7a24:	d360fc21 	lsr	x1, x1, #32
    7a28:	eb00003f 	cmp	x1, x0
    7a2c:	540000e2 	b.cs	7a48 <f0+0x1928>  // b.hs, b.nlast
    7a30:	8b0102b5 	add	x21, x21, x1
    7a34:	394002a0 	ldrb	w0, [x21]
    7a38:	7103fc1f 	cmp	w0, #0xff
    7a3c:	54006660 	b.eq	8708 <f0+0x25e8>  // b.none
    7a40:	52800020 	mov	w0, #0x1                   	// #1
    7a44:	390002a0 	strb	w0, [x21]
    7a48:	9118e3e1 	add	x1, sp, #0x638
    7a4c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7a50:	52800020 	mov	w0, #0x1                   	// #1
    7a54:	f9031ff5 	str	x21, [sp, #1592]
    7a58:	f90323f7 	str	x23, [sp, #1600]
    7a5c:	97ffef3d 	bl	3750 <fwp_data.part.0.constprop.0>
    7a60:	97ffee88 	bl	3480 <fwp_rc_fresh>
    7a64:	aa0003e2 	mov	x2, x0
    7a68:	911923e1 	add	x1, sp, #0x648
    7a6c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7a70:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7a74:	52800020 	mov	w0, #0x1                   	// #1
    7a78:	f90327f7 	str	x23, [sp, #1608]
    7a7c:	f9032be2 	str	x2, [sp, #1616]
    7a80:	97ffef34 	bl	3750 <fwp_data.part.0.constprop.0>
    7a84:	97ffee7f 	bl	3480 <fwp_rc_fresh>
    7a88:	aa0003e2 	mov	x2, x0
    7a8c:	911963e1 	add	x1, sp, #0x658
    7a90:	52800020 	mov	w0, #0x1                   	// #1
    7a94:	f9032ff5 	str	x21, [sp, #1624]
    7a98:	f90333e2 	str	x2, [sp, #1632]
    7a9c:	97ffef2d 	bl	3750 <fwp_data.part.0.constprop.0>
    7aa0:	97ffee78 	bl	3480 <fwp_rc_fresh>
    7aa4:	aa0003e2 	mov	x2, x0
    7aa8:	9119a3e1 	add	x1, sp, #0x668
    7aac:	52800020 	mov	w0, #0x1                   	// #1
    7ab0:	f90337f7 	str	x23, [sp, #1640]
    7ab4:	f9033be2 	str	x2, [sp, #1648]
    7ab8:	97ffef26 	bl	3750 <fwp_data.part.0.constprop.0>
    7abc:	97ffee71 	bl	3480 <fwp_rc_fresh>
    7ac0:	aa0003e2 	mov	x2, x0
    7ac4:	9119e3e1 	add	x1, sp, #0x678
    7ac8:	52800020 	mov	w0, #0x1                   	// #1
    7acc:	f9033ff5 	str	x21, [sp, #1656]
    7ad0:	f90343e2 	str	x2, [sp, #1664]
    7ad4:	97ffef1f 	bl	3750 <fwp_data.part.0.constprop.0>
    7ad8:	97ffee6a 	bl	3480 <fwp_rc_fresh>
    7adc:	aa0003e2 	mov	x2, x0
    7ae0:	911a23e1 	add	x1, sp, #0x688
    7ae4:	52800020 	mov	w0, #0x1                   	// #1
    7ae8:	f90347f7 	str	x23, [sp, #1672]
    7aec:	f9034be2 	str	x2, [sp, #1680]
    7af0:	97ffef18 	bl	3750 <fwp_data.part.0.constprop.0>
    7af4:	97ffee63 	bl	3480 <fwp_rc_fresh>
    7af8:	aa0003e2 	mov	x2, x0
    7afc:	911a63e1 	add	x1, sp, #0x698
    7b00:	52800020 	mov	w0, #0x1                   	// #1
    7b04:	f9034ff5 	str	x21, [sp, #1688]
    7b08:	f90353e2 	str	x2, [sp, #1696]
    7b0c:	97ffef11 	bl	3750 <fwp_data.part.0.constprop.0>
    7b10:	9115c283 	add	x3, x20, #0x570
    7b14:	aa0003f5 	mov	x21, x0
    7b18:	f949d861 	ldr	x1, [x3, #5040]
    7b1c:	f949ec60 	ldr	x0, [x3, #5080]
    7b20:	cb0102a1 	sub	x1, x21, x1
    7b24:	eb00403f 	cmp	x1, x0, lsl #16
    7b28:	54000322 	b.cs	7b8c <f0+0x1a6c>  // b.hs, b.nlast
    7b2c:	d350fc22 	lsr	x2, x1, #16
    7b30:	f949fc63 	ldr	x3, [x3, #5112]
    7b34:	8b020842 	add	x2, x2, x2, lsl #2
    7b38:	d37df042 	lsl	x2, x2, #3
    7b3c:	8b020060 	add	x0, x3, x2
    7b40:	f9401017 	ldr	x23, [x0, #32]
    7b44:	b4000257 	cbz	x23, 7b8c <f0+0x1a6c>
    7b48:	38626862 	ldrb	w2, [x3, x2]
    7b4c:	7100085f 	cmp	w2, #0x2
    7b50:	54005100 	b.eq	8570 <f0+0x2450>  // b.none
    7b54:	7100045f 	cmp	w2, #0x1
    7b58:	540001a1 	b.ne	7b8c <f0+0x1a6c>  // b.any
    7b5c:	29430002 	ldp	w2, w0, [x0, #24]
    7b60:	92403c21 	and	x1, x1, #0xffff
    7b64:	9b027c21 	mul	x1, x1, x2
    7b68:	d360fc21 	lsr	x1, x1, #32
    7b6c:	eb00003f 	cmp	x1, x0
    7b70:	540000e2 	b.cs	7b8c <f0+0x1a6c>  // b.hs, b.nlast
    7b74:	8b0102f7 	add	x23, x23, x1
    7b78:	394002e0 	ldrb	w0, [x23]
    7b7c:	7103fc1f 	cmp	w0, #0xff
    7b80:	54005ca0 	b.eq	8714 <f0+0x25f4>  // b.none
    7b84:	52800020 	mov	w0, #0x1                   	// #1
    7b88:	390002e0 	strb	w0, [x23]
    7b8c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7b90:	911aa3e1 	add	x1, sp, #0x6a8
    7b94:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7b98:	52800020 	mov	w0, #0x1                   	// #1
    7b9c:	f90357e2 	str	x2, [sp, #1704]
    7ba0:	f9035bf5 	str	x21, [sp, #1712]
    7ba4:	97ffeeeb 	bl	3750 <fwp_data.part.0.constprop.0>
    7ba8:	9115c283 	add	x3, x20, #0x570
    7bac:	aa0003f5 	mov	x21, x0
    7bb0:	f949d861 	ldr	x1, [x3, #5040]
    7bb4:	f949ec60 	ldr	x0, [x3, #5080]
    7bb8:	cb0102a1 	sub	x1, x21, x1
    7bbc:	eb00403f 	cmp	x1, x0, lsl #16
    7bc0:	54000322 	b.cs	7c24 <f0+0x1b04>  // b.hs, b.nlast
    7bc4:	d350fc22 	lsr	x2, x1, #16
    7bc8:	f949fc63 	ldr	x3, [x3, #5112]
    7bcc:	8b020842 	add	x2, x2, x2, lsl #2
    7bd0:	d37df042 	lsl	x2, x2, #3
    7bd4:	8b020060 	add	x0, x3, x2
    7bd8:	f9401017 	ldr	x23, [x0, #32]
    7bdc:	b4000257 	cbz	x23, 7c24 <f0+0x1b04>
    7be0:	38626862 	ldrb	w2, [x3, x2]
    7be4:	7100085f 	cmp	w2, #0x2
    7be8:	54004be0 	b.eq	8564 <f0+0x2444>  // b.none
    7bec:	7100045f 	cmp	w2, #0x1
    7bf0:	540001a1 	b.ne	7c24 <f0+0x1b04>  // b.any
    7bf4:	29430002 	ldp	w2, w0, [x0, #24]
    7bf8:	92403c21 	and	x1, x1, #0xffff
    7bfc:	9b027c21 	mul	x1, x1, x2
    7c00:	d360fc21 	lsr	x1, x1, #32
    7c04:	eb00003f 	cmp	x1, x0
    7c08:	540000e2 	b.cs	7c24 <f0+0x1b04>  // b.hs, b.nlast
    7c0c:	8b0102f7 	add	x23, x23, x1
    7c10:	394002e0 	ldrb	w0, [x23]
    7c14:	7103fc1f 	cmp	w0, #0xff
    7c18:	54005840 	b.eq	8720 <f0+0x2600>  // b.none
    7c1c:	52800020 	mov	w0, #0x1                   	// #1
    7c20:	390002e0 	strb	w0, [x23]
    7c24:	911ae3e1 	add	x1, sp, #0x6b8
    7c28:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7c2c:	52800020 	mov	w0, #0x1                   	// #1
    7c30:	f9035ff7 	str	x23, [sp, #1720]
    7c34:	f90363f5 	str	x21, [sp, #1728]
    7c38:	97ffeec6 	bl	3750 <fwp_data.part.0.constprop.0>
    7c3c:	97ffee11 	bl	3480 <fwp_rc_fresh>
    7c40:	aa0003e2 	mov	x2, x0
    7c44:	911b23e1 	add	x1, sp, #0x6c8
    7c48:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7c4c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7c50:	52800020 	mov	w0, #0x1                   	// #1
    7c54:	f90367f5 	str	x21, [sp, #1736]
    7c58:	f9036be2 	str	x2, [sp, #1744]
    7c5c:	97ffeebd 	bl	3750 <fwp_data.part.0.constprop.0>
    7c60:	97ffee08 	bl	3480 <fwp_rc_fresh>
    7c64:	aa0003e2 	mov	x2, x0
    7c68:	911b63e1 	add	x1, sp, #0x6d8
    7c6c:	52800020 	mov	w0, #0x1                   	// #1
    7c70:	f9036ff7 	str	x23, [sp, #1752]
    7c74:	f90373e2 	str	x2, [sp, #1760]
    7c78:	97ffeeb6 	bl	3750 <fwp_data.part.0.constprop.0>
    7c7c:	97ffee01 	bl	3480 <fwp_rc_fresh>
    7c80:	aa0003e2 	mov	x2, x0
    7c84:	911ba3e1 	add	x1, sp, #0x6e8
    7c88:	52800020 	mov	w0, #0x1                   	// #1
    7c8c:	f90377f5 	str	x21, [sp, #1768]
    7c90:	f9037be2 	str	x2, [sp, #1776]
    7c94:	97ffeeaf 	bl	3750 <fwp_data.part.0.constprop.0>
    7c98:	9115c283 	add	x3, x20, #0x570
    7c9c:	aa0003f5 	mov	x21, x0
    7ca0:	f949d861 	ldr	x1, [x3, #5040]
    7ca4:	f949ec60 	ldr	x0, [x3, #5080]
    7ca8:	cb0102a1 	sub	x1, x21, x1
    7cac:	eb00403f 	cmp	x1, x0, lsl #16
    7cb0:	54000322 	b.cs	7d14 <f0+0x1bf4>  // b.hs, b.nlast
    7cb4:	d350fc22 	lsr	x2, x1, #16
    7cb8:	f949fc63 	ldr	x3, [x3, #5112]
    7cbc:	8b020842 	add	x2, x2, x2, lsl #2
    7cc0:	d37df042 	lsl	x2, x2, #3
    7cc4:	8b020060 	add	x0, x3, x2
    7cc8:	f9401017 	ldr	x23, [x0, #32]
    7ccc:	b4000257 	cbz	x23, 7d14 <f0+0x1bf4>
    7cd0:	38626862 	ldrb	w2, [x3, x2]
    7cd4:	7100085f 	cmp	w2, #0x2
    7cd8:	54004400 	b.eq	8558 <f0+0x2438>  // b.none
    7cdc:	7100045f 	cmp	w2, #0x1
    7ce0:	540001a1 	b.ne	7d14 <f0+0x1bf4>  // b.any
    7ce4:	29430002 	ldp	w2, w0, [x0, #24]
    7ce8:	92403c21 	and	x1, x1, #0xffff
    7cec:	9b027c21 	mul	x1, x1, x2
    7cf0:	d360fc21 	lsr	x1, x1, #32
    7cf4:	eb00003f 	cmp	x1, x0
    7cf8:	540000e2 	b.cs	7d14 <f0+0x1bf4>  // b.hs, b.nlast
    7cfc:	8b0102f7 	add	x23, x23, x1
    7d00:	394002e0 	ldrb	w0, [x23]
    7d04:	7103fc1f 	cmp	w0, #0xff
    7d08:	54005120 	b.eq	872c <f0+0x260c>  // b.none
    7d0c:	52800020 	mov	w0, #0x1                   	// #1
    7d10:	390002e0 	strb	w0, [x23]
    7d14:	911be3e1 	add	x1, sp, #0x6f8
    7d18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7d1c:	52800020 	mov	w0, #0x1                   	// #1
    7d20:	f9037fe2 	str	x2, [sp, #1784]
    7d24:	f90383f5 	str	x21, [sp, #1792]
    7d28:	97ffee8a 	bl	3750 <fwp_data.part.0.constprop.0>
    7d2c:	97ffedd5 	bl	3480 <fwp_rc_fresh>
    7d30:	aa0003e2 	mov	x2, x0
    7d34:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7d38:	911c23e1 	add	x1, sp, #0x708
    7d3c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7d40:	52800020 	mov	w0, #0x1                   	// #1
    7d44:	f90387e3 	str	x3, [sp, #1800]
    7d48:	f9038be2 	str	x2, [sp, #1808]
    7d4c:	97ffee81 	bl	3750 <fwp_data.part.0.constprop.0>
    7d50:	9115c283 	add	x3, x20, #0x570
    7d54:	aa0003f5 	mov	x21, x0
    7d58:	f949d861 	ldr	x1, [x3, #5040]
    7d5c:	f949ec60 	ldr	x0, [x3, #5080]
    7d60:	cb0102a1 	sub	x1, x21, x1
    7d64:	eb00403f 	cmp	x1, x0, lsl #16
    7d68:	54000322 	b.cs	7dcc <f0+0x1cac>  // b.hs, b.nlast
    7d6c:	d350fc22 	lsr	x2, x1, #16
    7d70:	f949fc63 	ldr	x3, [x3, #5112]
    7d74:	8b020842 	add	x2, x2, x2, lsl #2
    7d78:	d37df042 	lsl	x2, x2, #3
    7d7c:	8b020060 	add	x0, x3, x2
    7d80:	f9401017 	ldr	x23, [x0, #32]
    7d84:	b4000257 	cbz	x23, 7dcc <f0+0x1cac>
    7d88:	38626862 	ldrb	w2, [x3, x2]
    7d8c:	7100085f 	cmp	w2, #0x2
    7d90:	54003de0 	b.eq	854c <f0+0x242c>  // b.none
    7d94:	7100045f 	cmp	w2, #0x1
    7d98:	540001a1 	b.ne	7dcc <f0+0x1cac>  // b.any
    7d9c:	29430002 	ldp	w2, w0, [x0, #24]
    7da0:	92403c21 	and	x1, x1, #0xffff
    7da4:	9b027c21 	mul	x1, x1, x2
    7da8:	d360fc21 	lsr	x1, x1, #32
    7dac:	eb00003f 	cmp	x1, x0
    7db0:	540000e2 	b.cs	7dcc <f0+0x1cac>  // b.hs, b.nlast
    7db4:	8b0102f7 	add	x23, x23, x1
    7db8:	394002e0 	ldrb	w0, [x23]
    7dbc:	7103fc1f 	cmp	w0, #0xff
    7dc0:	54004bc0 	b.eq	8738 <f0+0x2618>  // b.none
    7dc4:	52800020 	mov	w0, #0x1                   	// #1
    7dc8:	390002e0 	strb	w0, [x23]
    7dcc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7dd0:	911c63e1 	add	x1, sp, #0x718
    7dd4:	52800020 	mov	w0, #0x1                   	// #1
    7dd8:	f9038fe2 	str	x2, [sp, #1816]
    7ddc:	f90393f5 	str	x21, [sp, #1824]
    7de0:	97ffee5c 	bl	3750 <fwp_data.part.0.constprop.0>
    7de4:	9115c283 	add	x3, x20, #0x570
    7de8:	aa0003f5 	mov	x21, x0
    7dec:	f949d861 	ldr	x1, [x3, #5040]
    7df0:	f949ec60 	ldr	x0, [x3, #5080]
    7df4:	cb0102a1 	sub	x1, x21, x1
    7df8:	eb00403f 	cmp	x1, x0, lsl #16
    7dfc:	54000322 	b.cs	7e60 <f0+0x1d40>  // b.hs, b.nlast
    7e00:	d350fc22 	lsr	x2, x1, #16
    7e04:	f949fc63 	ldr	x3, [x3, #5112]
    7e08:	8b020842 	add	x2, x2, x2, lsl #2
    7e0c:	d37df042 	lsl	x2, x2, #3
    7e10:	8b020060 	add	x0, x3, x2
    7e14:	f9401017 	ldr	x23, [x0, #32]
    7e18:	b4000257 	cbz	x23, 7e60 <f0+0x1d40>
    7e1c:	38626862 	ldrb	w2, [x3, x2]
    7e20:	7100085f 	cmp	w2, #0x2
    7e24:	540038e0 	b.eq	8540 <f0+0x2420>  // b.none
    7e28:	7100045f 	cmp	w2, #0x1
    7e2c:	540001a1 	b.ne	7e60 <f0+0x1d40>  // b.any
    7e30:	29430002 	ldp	w2, w0, [x0, #24]
    7e34:	92403c21 	and	x1, x1, #0xffff
    7e38:	9b027c21 	mul	x1, x1, x2
    7e3c:	d360fc21 	lsr	x1, x1, #32
    7e40:	eb00003f 	cmp	x1, x0
    7e44:	540000e2 	b.cs	7e60 <f0+0x1d40>  // b.hs, b.nlast
    7e48:	8b0102f7 	add	x23, x23, x1
    7e4c:	394002e0 	ldrb	w0, [x23]
    7e50:	7103fc1f 	cmp	w0, #0xff
    7e54:	54004780 	b.eq	8744 <f0+0x2624>  // b.none
    7e58:	52800020 	mov	w0, #0x1                   	// #1
    7e5c:	390002e0 	strb	w0, [x23]
    7e60:	911ca3e1 	add	x1, sp, #0x728
    7e64:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7e68:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7e6c:	52800020 	mov	w0, #0x1                   	// #1
    7e70:	f90397f7 	str	x23, [sp, #1832]
    7e74:	f9039bf5 	str	x21, [sp, #1840]
    7e78:	97ffee36 	bl	3750 <fwp_data.part.0.constprop.0>
    7e7c:	97ffed81 	bl	3480 <fwp_rc_fresh>
    7e80:	aa0003e2 	mov	x2, x0
    7e84:	911ce3e1 	add	x1, sp, #0x738
    7e88:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7e8c:	52800020 	mov	w0, #0x1                   	// #1
    7e90:	f9039ff5 	str	x21, [sp, #1848]
    7e94:	f903a3e2 	str	x2, [sp, #1856]
    7e98:	97ffee2e 	bl	3750 <fwp_data.part.0.constprop.0>
    7e9c:	97ffed79 	bl	3480 <fwp_rc_fresh>
    7ea0:	aa0003e2 	mov	x2, x0
    7ea4:	911d23e1 	add	x1, sp, #0x748
    7ea8:	52800020 	mov	w0, #0x1                   	// #1
    7eac:	f903a7f7 	str	x23, [sp, #1864]
    7eb0:	f903abe2 	str	x2, [sp, #1872]
    7eb4:	97ffee27 	bl	3750 <fwp_data.part.0.constprop.0>
    7eb8:	97ffed72 	bl	3480 <fwp_rc_fresh>
    7ebc:	aa0003e2 	mov	x2, x0
    7ec0:	911d63e1 	add	x1, sp, #0x758
    7ec4:	52800020 	mov	w0, #0x1                   	// #1
    7ec8:	f903aff5 	str	x21, [sp, #1880]
    7ecc:	f903b3e2 	str	x2, [sp, #1888]
    7ed0:	97ffee20 	bl	3750 <fwp_data.part.0.constprop.0>
    7ed4:	97ffed6b 	bl	3480 <fwp_rc_fresh>
    7ed8:	aa0003e2 	mov	x2, x0
    7edc:	911da3e1 	add	x1, sp, #0x768
    7ee0:	52800020 	mov	w0, #0x1                   	// #1
    7ee4:	f903b7f7 	str	x23, [sp, #1896]
    7ee8:	f903bbe2 	str	x2, [sp, #1904]
    7eec:	97ffee19 	bl	3750 <fwp_data.part.0.constprop.0>
    7ef0:	97ffed64 	bl	3480 <fwp_rc_fresh>
    7ef4:	aa0003e2 	mov	x2, x0
    7ef8:	911de3e1 	add	x1, sp, #0x778
    7efc:	52800020 	mov	w0, #0x1                   	// #1
    7f00:	f903bff5 	str	x21, [sp, #1912]
    7f04:	f903c3e2 	str	x2, [sp, #1920]
    7f08:	97ffee12 	bl	3750 <fwp_data.part.0.constprop.0>
    7f0c:	97ffed5d 	bl	3480 <fwp_rc_fresh>
    7f10:	aa0003e2 	mov	x2, x0
    7f14:	911e23e1 	add	x1, sp, #0x788
    7f18:	52800020 	mov	w0, #0x1                   	// #1
    7f1c:	f903c7f7 	str	x23, [sp, #1928]
    7f20:	f903cbe2 	str	x2, [sp, #1936]
    7f24:	97ffee0b 	bl	3750 <fwp_data.part.0.constprop.0>
    7f28:	97ffed56 	bl	3480 <fwp_rc_fresh>
    7f2c:	aa0003e2 	mov	x2, x0
    7f30:	911e63e1 	add	x1, sp, #0x798
    7f34:	52800020 	mov	w0, #0x1                   	// #1
    7f38:	f903cff5 	str	x21, [sp, #1944]
    7f3c:	f903d3e2 	str	x2, [sp, #1952]
    7f40:	97ffee04 	bl	3750 <fwp_data.part.0.constprop.0>
    7f44:	9115c283 	add	x3, x20, #0x570
    7f48:	aa0003f5 	mov	x21, x0
    7f4c:	f949d861 	ldr	x1, [x3, #5040]
    7f50:	f949ec60 	ldr	x0, [x3, #5080]
    7f54:	cb0102a1 	sub	x1, x21, x1
    7f58:	eb00403f 	cmp	x1, x0, lsl #16
    7f5c:	54000322 	b.cs	7fc0 <f0+0x1ea0>  // b.hs, b.nlast
    7f60:	d350fc22 	lsr	x2, x1, #16
    7f64:	f949fc63 	ldr	x3, [x3, #5112]
    7f68:	8b020842 	add	x2, x2, x2, lsl #2
    7f6c:	d37df042 	lsl	x2, x2, #3
    7f70:	8b020060 	add	x0, x3, x2
    7f74:	f9401017 	ldr	x23, [x0, #32]
    7f78:	b4000257 	cbz	x23, 7fc0 <f0+0x1ea0>
    7f7c:	38626862 	ldrb	w2, [x3, x2]
    7f80:	7100085f 	cmp	w2, #0x2
    7f84:	54002d80 	b.eq	8534 <f0+0x2414>  // b.none
    7f88:	7100045f 	cmp	w2, #0x1
    7f8c:	540001a1 	b.ne	7fc0 <f0+0x1ea0>  // b.any
    7f90:	29430002 	ldp	w2, w0, [x0, #24]
    7f94:	92403c21 	and	x1, x1, #0xffff
    7f98:	9b027c21 	mul	x1, x1, x2
    7f9c:	d360fc21 	lsr	x1, x1, #32
    7fa0:	eb00003f 	cmp	x1, x0
    7fa4:	540000e2 	b.cs	7fc0 <f0+0x1ea0>  // b.hs, b.nlast
    7fa8:	8b0102f7 	add	x23, x23, x1
    7fac:	394002e0 	ldrb	w0, [x23]
    7fb0:	7103fc1f 	cmp	w0, #0xff
    7fb4:	54003ce0 	b.eq	8750 <f0+0x2630>  // b.none
    7fb8:	52800020 	mov	w0, #0x1                   	// #1
    7fbc:	390002e0 	strb	w0, [x23]
    7fc0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7fc4:	911ea3e1 	add	x1, sp, #0x7a8
    7fc8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7fcc:	52800020 	mov	w0, #0x1                   	// #1
    7fd0:	f903d7e2 	str	x2, [sp, #1960]
    7fd4:	f903dbf5 	str	x21, [sp, #1968]
    7fd8:	97ffedde 	bl	3750 <fwp_data.part.0.constprop.0>
    7fdc:	9115c283 	add	x3, x20, #0x570
    7fe0:	aa0003f5 	mov	x21, x0
    7fe4:	f949d861 	ldr	x1, [x3, #5040]
    7fe8:	f949ec60 	ldr	x0, [x3, #5080]
    7fec:	cb0102a1 	sub	x1, x21, x1
    7ff0:	eb00403f 	cmp	x1, x0, lsl #16
    7ff4:	54000322 	b.cs	8058 <f0+0x1f38>  // b.hs, b.nlast
    7ff8:	d350fc22 	lsr	x2, x1, #16
    7ffc:	f949fc63 	ldr	x3, [x3, #5112]
    8000:	8b020842 	add	x2, x2, x2, lsl #2
    8004:	d37df042 	lsl	x2, x2, #3
    8008:	8b020060 	add	x0, x3, x2
    800c:	f9401017 	ldr	x23, [x0, #32]
    8010:	b4000257 	cbz	x23, 8058 <f0+0x1f38>
    8014:	38626862 	ldrb	w2, [x3, x2]
    8018:	7100085f 	cmp	w2, #0x2
    801c:	54002860 	b.eq	8528 <f0+0x2408>  // b.none
    8020:	7100045f 	cmp	w2, #0x1
    8024:	540001a1 	b.ne	8058 <f0+0x1f38>  // b.any
    8028:	29430002 	ldp	w2, w0, [x0, #24]
    802c:	92403c21 	and	x1, x1, #0xffff
    8030:	9b027c21 	mul	x1, x1, x2
    8034:	d360fc21 	lsr	x1, x1, #32
    8038:	eb00003f 	cmp	x1, x0
    803c:	540000e2 	b.cs	8058 <f0+0x1f38>  // b.hs, b.nlast
    8040:	8b0102f7 	add	x23, x23, x1
    8044:	394002e0 	ldrb	w0, [x23]
    8048:	7103fc1f 	cmp	w0, #0xff
    804c:	54003880 	b.eq	875c <f0+0x263c>  // b.none
    8050:	52800020 	mov	w0, #0x1                   	// #1
    8054:	390002e0 	strb	w0, [x23]
    8058:	911ee3e1 	add	x1, sp, #0x7b8
    805c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    8060:	52800020 	mov	w0, #0x1                   	// #1
    8064:	f903dff7 	str	x23, [sp, #1976]
    8068:	f903e3f5 	str	x21, [sp, #1984]
    806c:	97ffedb9 	bl	3750 <fwp_data.part.0.constprop.0>
    8070:	97ffed04 	bl	3480 <fwp_rc_fresh>
    8074:	aa0003e2 	mov	x2, x0
    8078:	911f23e1 	add	x1, sp, #0x7c8
    807c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    8080:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    8084:	52800020 	mov	w0, #0x1                   	// #1
    8088:	f903e7f5 	str	x21, [sp, #1992]
    808c:	f903ebe2 	str	x2, [sp, #2000]
    8090:	97ffedb0 	bl	3750 <fwp_data.part.0.constprop.0>
    8094:	97ffecfb 	bl	3480 <fwp_rc_fresh>
    8098:	aa0003e2 	mov	x2, x0
    809c:	911f63e1 	add	x1, sp, #0x7d8
    80a0:	52800020 	mov	w0, #0x1                   	// #1
    80a4:	f903eff7 	str	x23, [sp, #2008]
    80a8:	f903f3e2 	str	x2, [sp, #2016]
    80ac:	97ffeda9 	bl	3750 <fwp_data.part.0.constprop.0>
    80b0:	97ffecf4 	bl	3480 <fwp_rc_fresh>
    80b4:	aa0003e2 	mov	x2, x0
    80b8:	911fa3e1 	add	x1, sp, #0x7e8
    80bc:	52800020 	mov	w0, #0x1                   	// #1
    80c0:	f903f7f5 	str	x21, [sp, #2024]
    80c4:	f903fbe2 	str	x2, [sp, #2032]
    80c8:	97ffeda2 	bl	3750 <fwp_data.part.0.constprop.0>
    80cc:	9115c283 	add	x3, x20, #0x570
    80d0:	aa0003f5 	mov	x21, x0
    80d4:	f949d861 	ldr	x1, [x3, #5040]
    80d8:	f949ec60 	ldr	x0, [x3, #5080]
    80dc:	cb0102a1 	sub	x1, x21, x1
    80e0:	eb00403f 	cmp	x1, x0, lsl #16
    80e4:	54000322 	b.cs	8148 <f0+0x2028>  // b.hs, b.nlast
    80e8:	d350fc22 	lsr	x2, x1, #16
    80ec:	f949fc63 	ldr	x3, [x3, #5112]
    80f0:	8b020842 	add	x2, x2, x2, lsl #2
    80f4:	d37df042 	lsl	x2, x2, #3
    80f8:	8b020060 	add	x0, x3, x2
    80fc:	f9401017 	ldr	x23, [x0, #32]
    8100:	b4000257 	cbz	x23, 8148 <f0+0x2028>
    8104:	38626862 	ldrb	w2, [x3, x2]
    8108:	7100085f 	cmp	w2, #0x2
    810c:	54002080 	b.eq	851c <f0+0x23fc>  // b.none
    8110:	7100045f 	cmp	w2, #0x1
    8114:	540001a1 	b.ne	8148 <f0+0x2028>  // b.any
    8118:	29430002 	ldp	w2, w0, [x0, #24]
    811c:	92403c21 	and	x1, x1, #0xffff
    8120:	9b027c21 	mul	x1, x1, x2
    8124:	d360fc21 	lsr	x1, x1, #32
    8128:	eb00003f 	cmp	x1, x0
    812c:	540000e2 	b.cs	8148 <f0+0x2028>  // b.hs, b.nlast
    8130:	8b0102f7 	add	x23, x23, x1
    8134:	394002e0 	ldrb	w0, [x23]
    8138:	7103fc1f 	cmp	w0, #0xff
    813c:	54003160 	b.eq	8768 <f0+0x2648>  // b.none
    8140:	52800020 	mov	w0, #0x1                   	// #1
    8144:	390002e0 	strb	w0, [x23]
    8148:	911fe3e1 	add	x1, sp, #0x7f8
    814c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8150:	52800020 	mov	w0, #0x1                   	// #1
    8154:	f903ffe2 	str	x2, [sp, #2040]
    8158:	f90403f5 	str	x21, [sp, #2048]
    815c:	97ffed7d 	bl	3750 <fwp_data.part.0.constprop.0>
    8160:	97ffecc8 	bl	3480 <fwp_rc_fresh>
    8164:	aa0003e2 	mov	x2, x0
    8168:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    816c:	912023e1 	add	x1, sp, #0x808
    8170:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8174:	52800020 	mov	w0, #0x1                   	// #1
    8178:	f90407e3 	str	x3, [sp, #2056]
    817c:	f9040be2 	str	x2, [sp, #2064]
    8180:	97ffed74 	bl	3750 <fwp_data.part.0.constprop.0>
    8184:	9115c283 	add	x3, x20, #0x570
    8188:	aa0003f5 	mov	x21, x0
    818c:	f949d861 	ldr	x1, [x3, #5040]
    8190:	f949ec60 	ldr	x0, [x3, #5080]
    8194:	cb0102a1 	sub	x1, x21, x1
    8198:	eb00403f 	cmp	x1, x0, lsl #16
    819c:	54000322 	b.cs	8200 <f0+0x20e0>  // b.hs, b.nlast
    81a0:	d350fc22 	lsr	x2, x1, #16
    81a4:	f949fc63 	ldr	x3, [x3, #5112]
    81a8:	8b020842 	add	x2, x2, x2, lsl #2
    81ac:	d37df042 	lsl	x2, x2, #3
    81b0:	8b020060 	add	x0, x3, x2
    81b4:	f9401017 	ldr	x23, [x0, #32]
    81b8:	b4000257 	cbz	x23, 8200 <f0+0x20e0>
    81bc:	38626862 	ldrb	w2, [x3, x2]
    81c0:	7100085f 	cmp	w2, #0x2
    81c4:	54001a60 	b.eq	8510 <f0+0x23f0>  // b.none
    81c8:	7100045f 	cmp	w2, #0x1
    81cc:	540001a1 	b.ne	8200 <f0+0x20e0>  // b.any
    81d0:	29430002 	ldp	w2, w0, [x0, #24]
    81d4:	92403c21 	and	x1, x1, #0xffff
    81d8:	9b027c21 	mul	x1, x1, x2
    81dc:	d360fc21 	lsr	x1, x1, #32
    81e0:	eb00003f 	cmp	x1, x0
    81e4:	540000e2 	b.cs	8200 <f0+0x20e0>  // b.hs, b.nlast
    81e8:	8b0102f7 	add	x23, x23, x1
    81ec:	394002e0 	ldrb	w0, [x23]
    81f0:	7103fc1f 	cmp	w0, #0xff
    81f4:	54002c00 	b.eq	8774 <f0+0x2654>  // b.none
    81f8:	52800020 	mov	w0, #0x1                   	// #1
    81fc:	390002e0 	strb	w0, [x23]
    8200:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8204:	912063e1 	add	x1, sp, #0x818
    8208:	52800020 	mov	w0, #0x1                   	// #1
    820c:	f9040fe2 	str	x2, [sp, #2072]
    8210:	f90413f5 	str	x21, [sp, #2080]
    8214:	97ffed4f 	bl	3750 <fwp_data.part.0.constprop.0>
    8218:	9115c283 	add	x3, x20, #0x570
    821c:	aa0003f5 	mov	x21, x0
    8220:	f949d861 	ldr	x1, [x3, #5040]
    8224:	f949ec60 	ldr	x0, [x3, #5080]
    8228:	cb0102a1 	sub	x1, x21, x1
    822c:	eb00403f 	cmp	x1, x0, lsl #16
    8230:	54000322 	b.cs	8294 <f0+0x2174>  // b.hs, b.nlast
    8234:	d350fc22 	lsr	x2, x1, #16
    8238:	f949fc63 	ldr	x3, [x3, #5112]
    823c:	8b020842 	add	x2, x2, x2, lsl #2
    8240:	d37df042 	lsl	x2, x2, #3
    8244:	8b020060 	add	x0, x3, x2
    8248:	f9401017 	ldr	x23, [x0, #32]
    824c:	b4000257 	cbz	x23, 8294 <f0+0x2174>
    8250:	38626862 	ldrb	w2, [x3, x2]
    8254:	7100085f 	cmp	w2, #0x2
    8258:	54001560 	b.eq	8504 <f0+0x23e4>  // b.none
    825c:	7100045f 	cmp	w2, #0x1
    8260:	540001a1 	b.ne	8294 <f0+0x2174>  // b.any
    8264:	29430002 	ldp	w2, w0, [x0, #24]
    8268:	92403c21 	and	x1, x1, #0xffff
    826c:	9b027c21 	mul	x1, x1, x2
    8270:	d360fc21 	lsr	x1, x1, #32
    8274:	eb00003f 	cmp	x1, x0
    8278:	540000e2 	b.cs	8294 <f0+0x2174>  // b.hs, b.nlast
    827c:	8b0102f7 	add	x23, x23, x1
    8280:	394002e0 	ldrb	w0, [x23]
    8284:	7103fc1f 	cmp	w0, #0xff
    8288:	540027c0 	b.eq	8780 <f0+0x2660>  // b.none
    828c:	52800020 	mov	w0, #0x1                   	// #1
    8290:	390002e0 	strb	w0, [x23]
    8294:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8298:	9115c294 	add	x20, x20, #0x570
    829c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    82a0:	9120a3e1 	add	x1, sp, #0x828
    82a4:	52800020 	mov	w0, #0x1                   	// #1
    82a8:	f90417e2 	str	x2, [sp, #2088]
    82ac:	f9041bf5 	str	x21, [sp, #2096]
    82b0:	97ffed28 	bl	3750 <fwp_data.part.0.constprop.0>
    82b4:	f949da81 	ldr	x1, [x20, #5040]
    82b8:	aa0003f5 	mov	x21, x0
    82bc:	f949ee80 	ldr	x0, [x20, #5080]
    82c0:	cb0102a1 	sub	x1, x21, x1
    82c4:	eb00403f 	cmp	x1, x0, lsl #16
    82c8:	54000322 	b.cs	832c <f0+0x220c>  // b.hs, b.nlast
    82cc:	d350fc22 	lsr	x2, x1, #16
    82d0:	f949fe83 	ldr	x3, [x20, #5112]
    82d4:	8b020842 	add	x2, x2, x2, lsl #2
    82d8:	d37df042 	lsl	x2, x2, #3
    82dc:	8b020060 	add	x0, x3, x2
    82e0:	f9401014 	ldr	x20, [x0, #32]
    82e4:	b4000254 	cbz	x20, 832c <f0+0x220c>
    82e8:	38626862 	ldrb	w2, [x3, x2]
    82ec:	7100085f 	cmp	w2, #0x2
    82f0:	54001040 	b.eq	84f8 <f0+0x23d8>  // b.none
    82f4:	7100045f 	cmp	w2, #0x1
    82f8:	540001a1 	b.ne	832c <f0+0x220c>  // b.any
    82fc:	29430002 	ldp	w2, w0, [x0, #24]
    8300:	92403c21 	and	x1, x1, #0xffff
    8304:	9b027c21 	mul	x1, x1, x2
    8308:	d360fc21 	lsr	x1, x1, #32
    830c:	eb00003f 	cmp	x1, x0
    8310:	540000e2 	b.cs	832c <f0+0x220c>  // b.hs, b.nlast
    8314:	8b010294 	add	x20, x20, x1
    8318:	39400280 	ldrb	w0, [x20]
    831c:	7103fc1f 	cmp	w0, #0xff
    8320:	540014c0 	b.eq	85b8 <f0+0x2498>  // b.none
    8324:	52800020 	mov	w0, #0x1                   	// #1
    8328:	39000280 	strb	w0, [x20]
    832c:	9120e3e1 	add	x1, sp, #0x838
    8330:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8334:	52800020 	mov	w0, #0x1                   	// #1
    8338:	f9041fe2 	str	x2, [sp, #2104]
    833c:	f90423f5 	str	x21, [sp, #2112]
    8340:	97ffed04 	bl	3750 <fwp_data.part.0.constprop.0>
    8344:	97ffec4f 	bl	3480 <fwp_rc_fresh>
    8348:	aa0003e2 	mov	x2, x0
    834c:	aa1603e1 	mov	x1, x22
    8350:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8354:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8358:	52800020 	mov	w0, #0x1                   	// #1
    835c:	f90427e3 	str	x3, [sp, #2120]
    8360:	f9042be2 	str	x2, [sp, #2128]
    8364:	97ffecfb 	bl	3750 <fwp_data.part.0.constprop.0>
    8368:	97ffec46 	bl	3480 <fwp_rc_fresh>
    836c:	aa0003f5 	mov	x21, x0
    8370:	aa1303e1 	mov	x1, x19
    8374:	97fff2fc 	bl	4f64 <fwp_hof0.constprop.0>
    8378:	aa0003f4 	mov	x20, x0
    837c:	aa1503e0 	mov	x0, x21
    8380:	97ffedb8 	bl	3a60 <fwp_drop0>
    8384:	aa1303e0 	mov	x0, x19
    8388:	97ffedb6 	bl	3a60 <fwp_drop0>
    838c:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    8390:	f947f400 	ldr	x0, [x0, #4072]
    8394:	f9442fe2 	ldr	x2, [sp, #2136]
    8398:	f9400001 	ldr	x1, [x0]
    839c:	eb010042 	subs	x2, x2, x1
    83a0:	d2800001 	mov	x1, #0x0                   	// #0
    83a4:	54001f41 	b.ne	878c <f0+0x266c>  // b.any
    83a8:	912183ff 	add	sp, sp, #0x860
    83ac:	aa1403e0 	mov	x0, x20
    83b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    83b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    83b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    83bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    83c0:	a94573fb 	ldp	x27, x28, [sp, #80]
    83c4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    83c8:	d65f03c0 	ret
    83cc:	aa1b03e0 	mov	x0, x27
    83d0:	97ffea6d 	bl	2d84 <fwp_rc_forget_slot>
    83d4:	17fff79b 	b	6240 <f0+0x120>
    83d8:	72003c5f 	tst	w2, #0xffff
    83dc:	54fef341 	b.ne	6244 <f0+0x124>  // b.any
    83e0:	17fff795 	b	6234 <f0+0x114>
    83e4:	72003c3f 	tst	w1, #0xffff
    83e8:	54ff94a1 	b.ne	767c <f0+0x155c>  // b.any
    83ec:	17fffc9f 	b	7668 <f0+0x1548>
    83f0:	72003c3f 	tst	w1, #0xffff
    83f4:	54ff8e81 	b.ne	75c4 <f0+0x14a4>  // b.any
    83f8:	17fffc6e 	b	75b0 <f0+0x1490>
    83fc:	72003c3f 	tst	w1, #0xffff
    8400:	54ff8861 	b.ne	750c <f0+0x13ec>  // b.any
    8404:	17fffc3d 	b	74f8 <f0+0x13d8>
    8408:	72003c3f 	tst	w1, #0xffff
    840c:	54ff8341 	b.ne	7474 <f0+0x1354>  // b.any
    8410:	17fffc14 	b	7460 <f0+0x1340>
    8414:	72003c3f 	tst	w1, #0xffff
    8418:	54ff7c41 	b.ne	73a0 <f0+0x1280>  // b.any
    841c:	17fffbdc 	b	738c <f0+0x126c>
    8420:	72003c3f 	tst	w1, #0xffff
    8424:	54ff7621 	b.ne	72e8 <f0+0x11c8>  // b.any
    8428:	17fffbab 	b	72d4 <f0+0x11b4>
    842c:	72003c3f 	tst	w1, #0xffff
    8430:	54ff6f21 	b.ne	7214 <f0+0x10f4>  // b.any
    8434:	17fffb73 	b	7200 <f0+0x10e0>
    8438:	72003c3f 	tst	w1, #0xffff
    843c:	54ff6821 	b.ne	7140 <f0+0x1020>  // b.any
    8440:	17fffb3b 	b	712c <f0+0x100c>
    8444:	72003c3f 	tst	w1, #0xffff
    8448:	54ff07a1 	b.ne	653c <f0+0x41c>  // b.any
    844c:	17fff837 	b	6528 <f0+0x408>
    8450:	72003c3f 	tst	w1, #0xffff
    8454:	54ff0101 	b.ne	6474 <f0+0x354>  // b.any
    8458:	17fff802 	b	6460 <f0+0x340>
    845c:	72003c3f 	tst	w1, #0xffff
    8460:	54fef6a1 	b.ne	6334 <f0+0x214>  // b.any
    8464:	17fff7af 	b	6320 <f0+0x200>
    8468:	72003c3f 	tst	w1, #0xffff
    846c:	54ff25c1 	b.ne	6924 <f0+0x804>  // b.any
    8470:	17fff928 	b	6910 <f0+0x7f0>
    8474:	72003c3f 	tst	w1, #0xffff
    8478:	54ff13e1 	b.ne	66f4 <f0+0x5d4>  // b.any
    847c:	17fff899 	b	66e0 <f0+0x5c0>
    8480:	72003c3f 	tst	w1, #0xffff
    8484:	54ff0ee1 	b.ne	6660 <f0+0x540>  // b.any
    8488:	17fff871 	b	664c <f0+0x52c>
    848c:	72003c3f 	tst	w1, #0xffff
    8490:	54ff0a01 	b.ne	65d0 <f0+0x4b0>  // b.any
    8494:	17fff84a 	b	65bc <f0+0x49c>
    8498:	72003c3f 	tst	w1, #0xffff
    849c:	54ff5f61 	b.ne	7088 <f0+0xf68>  // b.any
    84a0:	17fffaf5 	b	7074 <f0+0xf54>
    84a4:	72003c3f 	tst	w1, #0xffff
    84a8:	54ff5941 	b.ne	6fd0 <f0+0xeb0>  // b.any
    84ac:	17fffac4 	b	6fbc <f0+0xe9c>
    84b0:	72003c3f 	tst	w1, #0xffff
    84b4:	54ff5321 	b.ne	6f18 <f0+0xdf8>  // b.any
    84b8:	17fffa93 	b	6f04 <f0+0xde4>
    84bc:	72003c3f 	tst	w1, #0xffff
    84c0:	54ff4d01 	b.ne	6e60 <f0+0xd40>  // b.any
    84c4:	17fffa62 	b	6e4c <f0+0xd2c>
    84c8:	72003c3f 	tst	w1, #0xffff
    84cc:	54ff4521 	b.ne	6d70 <f0+0xc50>  // b.any
    84d0:	17fffa23 	b	6d5c <f0+0xc3c>
    84d4:	72003c3f 	tst	w1, #0xffff
    84d8:	54ff3d41 	b.ne	6c80 <f0+0xb60>  // b.any
    84dc:	17fff9e4 	b	6c6c <f0+0xb4c>
    84e0:	72003c3f 	tst	w1, #0xffff
    84e4:	54ff3721 	b.ne	6bc8 <f0+0xaa8>  // b.any
    84e8:	17fff9b3 	b	6bb4 <f0+0xa94>
    84ec:	72003c3f 	tst	w1, #0xffff
    84f0:	54ff2761 	b.ne	69dc <f0+0x8bc>  // b.any
    84f4:	17fff935 	b	69c8 <f0+0x8a8>
    84f8:	72003c3f 	tst	w1, #0xffff
    84fc:	54fff181 	b.ne	832c <f0+0x220c>  // b.any
    8500:	17ffff86 	b	8318 <f0+0x21f8>
    8504:	72003c3f 	tst	w1, #0xffff
    8508:	54ffec61 	b.ne	8294 <f0+0x2174>  // b.any
    850c:	17ffff5d 	b	8280 <f0+0x2160>
    8510:	72003c3f 	tst	w1, #0xffff
    8514:	54ffe761 	b.ne	8200 <f0+0x20e0>  // b.any
    8518:	17ffff35 	b	81ec <f0+0x20cc>
    851c:	72003c3f 	tst	w1, #0xffff
    8520:	54ffe141 	b.ne	8148 <f0+0x2028>  // b.any
    8524:	17ffff04 	b	8134 <f0+0x2014>
    8528:	72003c3f 	tst	w1, #0xffff
    852c:	54ffd961 	b.ne	8058 <f0+0x1f38>  // b.any
    8530:	17fffec5 	b	8044 <f0+0x1f24>
    8534:	72003c3f 	tst	w1, #0xffff
    8538:	54ffd441 	b.ne	7fc0 <f0+0x1ea0>  // b.any
    853c:	17fffe9c 	b	7fac <f0+0x1e8c>
    8540:	72003c3f 	tst	w1, #0xffff
    8544:	54ffc8e1 	b.ne	7e60 <f0+0x1d40>  // b.any
    8548:	17fffe41 	b	7e4c <f0+0x1d2c>
    854c:	72003c3f 	tst	w1, #0xffff
    8550:	54ffc3e1 	b.ne	7dcc <f0+0x1cac>  // b.any
    8554:	17fffe19 	b	7db8 <f0+0x1c98>
    8558:	72003c3f 	tst	w1, #0xffff
    855c:	54ffbdc1 	b.ne	7d14 <f0+0x1bf4>  // b.any
    8560:	17fffde8 	b	7d00 <f0+0x1be0>
    8564:	72003c3f 	tst	w1, #0xffff
    8568:	54ffb5e1 	b.ne	7c24 <f0+0x1b04>  // b.any
    856c:	17fffda9 	b	7c10 <f0+0x1af0>
    8570:	72003c3f 	tst	w1, #0xffff
    8574:	54ffb0c1 	b.ne	7b8c <f0+0x1a6c>  // b.any
    8578:	17fffd80 	b	7b78 <f0+0x1a58>
    857c:	72003c3f 	tst	w1, #0xffff
    8580:	54ffa641 	b.ne	7a48 <f0+0x1928>  // b.any
    8584:	17fffd2c 	b	7a34 <f0+0x1914>
    8588:	72003c3f 	tst	w1, #0xffff
    858c:	54ffa121 	b.ne	79b0 <f0+0x1890>  // b.any
    8590:	17fffd03 	b	799c <f0+0x187c>
    8594:	72003c3f 	tst	w1, #0xffff
    8598:	54ff9a21 	b.ne	78dc <f0+0x17bc>  // b.any
    859c:	17fffccb 	b	78c8 <f0+0x17a8>
    85a0:	72003c3f 	tst	w1, #0xffff
    85a4:	54ff9401 	b.ne	7824 <f0+0x1704>  // b.any
    85a8:	17fffc9a 	b	7810 <f0+0x16f0>
    85ac:	72003c3f 	tst	w1, #0xffff
    85b0:	54ff8de1 	b.ne	776c <f0+0x164c>  // b.any
    85b4:	17fffc69 	b	7758 <f0+0x1638>
    85b8:	aa1403e0 	mov	x0, x20
    85bc:	97ffe9f2 	bl	2d84 <fwp_rc_forget_slot>
    85c0:	17ffff59 	b	8324 <f0+0x2204>
    85c4:	aa1703e0 	mov	x0, x23
    85c8:	97ffe9ef 	bl	2d84 <fwp_rc_forget_slot>
    85cc:	17fff758 	b	632c <f0+0x20c>
    85d0:	aa1703e0 	mov	x0, x23
    85d4:	97ffe9ec 	bl	2d84 <fwp_rc_forget_slot>
    85d8:	17fff7a5 	b	646c <f0+0x34c>
    85dc:	aa1703e0 	mov	x0, x23
    85e0:	97ffe9e9 	bl	2d84 <fwp_rc_forget_slot>
    85e4:	17fff7d4 	b	6534 <f0+0x414>
    85e8:	aa1703e0 	mov	x0, x23
    85ec:	97ffe9e6 	bl	2d84 <fwp_rc_forget_slot>
    85f0:	17fff7f6 	b	65c8 <f0+0x4a8>
    85f4:	aa1703e0 	mov	x0, x23
    85f8:	97ffe9e3 	bl	2d84 <fwp_rc_forget_slot>
    85fc:	17fff817 	b	6658 <f0+0x538>
    8600:	aa1503e0 	mov	x0, x21
    8604:	97ffe9e0 	bl	2d84 <fwp_rc_forget_slot>
    8608:	17fff839 	b	66ec <f0+0x5cc>
    860c:	aa1703e0 	mov	x0, x23
    8610:	97ffe9dd 	bl	2d84 <fwp_rc_forget_slot>
    8614:	17fff8c2 	b	691c <f0+0x7fc>
    8618:	aa1503e0 	mov	x0, x21
    861c:	97ffe9da 	bl	2d84 <fwp_rc_forget_slot>
    8620:	17fff8ed 	b	69d4 <f0+0x8b4>
    8624:	aa1703e0 	mov	x0, x23
    8628:	97ffe9d7 	bl	2d84 <fwp_rc_forget_slot>
    862c:	17fff965 	b	6bc0 <f0+0xaa0>
    8630:	aa1703e0 	mov	x0, x23
    8634:	97ffe9d4 	bl	2d84 <fwp_rc_forget_slot>
    8638:	17fff990 	b	6c78 <f0+0xb58>
    863c:	aa1703e0 	mov	x0, x23
    8640:	97ffe9d1 	bl	2d84 <fwp_rc_forget_slot>
    8644:	17fff9c9 	b	6d68 <f0+0xc48>
    8648:	aa1703e0 	mov	x0, x23
    864c:	97ffe9ce 	bl	2d84 <fwp_rc_forget_slot>
    8650:	17fffa02 	b	6e58 <f0+0xd38>
    8654:	aa1703e0 	mov	x0, x23
    8658:	97ffe9cb 	bl	2d84 <fwp_rc_forget_slot>
    865c:	17fffa2d 	b	6f10 <f0+0xdf0>
    8660:	aa1703e0 	mov	x0, x23
    8664:	97ffe9c8 	bl	2d84 <fwp_rc_forget_slot>
    8668:	17fffa58 	b	6fc8 <f0+0xea8>
    866c:	aa1703e0 	mov	x0, x23
    8670:	97ffe9c5 	bl	2d84 <fwp_rc_forget_slot>
    8674:	17fffa83 	b	7080 <f0+0xf60>
    8678:	aa1703e0 	mov	x0, x23
    867c:	97ffe9c2 	bl	2d84 <fwp_rc_forget_slot>
    8680:	17fffaae 	b	7138 <f0+0x1018>
    8684:	aa1703e0 	mov	x0, x23
    8688:	97ffe9bf 	bl	2d84 <fwp_rc_forget_slot>
    868c:	17fffae0 	b	720c <f0+0x10ec>
    8690:	aa1703e0 	mov	x0, x23
    8694:	97ffe9bc 	bl	2d84 <fwp_rc_forget_slot>
    8698:	17fffb12 	b	72e0 <f0+0x11c0>
    869c:	aa1703e0 	mov	x0, x23
    86a0:	97ffe9b9 	bl	2d84 <fwp_rc_forget_slot>
    86a4:	17fffb3d 	b	7398 <f0+0x1278>
    86a8:	aa1703e0 	mov	x0, x23
    86ac:	97ffe9b6 	bl	2d84 <fwp_rc_forget_slot>
    86b0:	17fffb6f 	b	746c <f0+0x134c>
    86b4:	aa1703e0 	mov	x0, x23
    86b8:	97ffe9b3 	bl	2d84 <fwp_rc_forget_slot>
    86bc:	17fffb92 	b	7504 <f0+0x13e4>
    86c0:	aa1703e0 	mov	x0, x23
    86c4:	97ffe9b0 	bl	2d84 <fwp_rc_forget_slot>
    86c8:	17fffbbd 	b	75bc <f0+0x149c>
    86cc:	aa1703e0 	mov	x0, x23
    86d0:	97ffe9ad 	bl	2d84 <fwp_rc_forget_slot>
    86d4:	17fffbe8 	b	7674 <f0+0x1554>
    86d8:	aa1703e0 	mov	x0, x23
    86dc:	97ffe9aa 	bl	2d84 <fwp_rc_forget_slot>
    86e0:	17fffc21 	b	7764 <f0+0x1644>
    86e4:	aa1703e0 	mov	x0, x23
    86e8:	97ffe9a7 	bl	2d84 <fwp_rc_forget_slot>
    86ec:	17fffc4c 	b	781c <f0+0x16fc>
    86f0:	aa1703e0 	mov	x0, x23
    86f4:	97ffe9a4 	bl	2d84 <fwp_rc_forget_slot>
    86f8:	17fffc77 	b	78d4 <f0+0x17b4>
    86fc:	aa1703e0 	mov	x0, x23
    8700:	97ffe9a1 	bl	2d84 <fwp_rc_forget_slot>
    8704:	17fffca9 	b	79a8 <f0+0x1888>
    8708:	aa1503e0 	mov	x0, x21
    870c:	97ffe99e 	bl	2d84 <fwp_rc_forget_slot>
    8710:	17fffccc 	b	7a40 <f0+0x1920>
    8714:	aa1703e0 	mov	x0, x23
    8718:	97ffe99b 	bl	2d84 <fwp_rc_forget_slot>
    871c:	17fffd1a 	b	7b84 <f0+0x1a64>
    8720:	aa1703e0 	mov	x0, x23
    8724:	97ffe998 	bl	2d84 <fwp_rc_forget_slot>
    8728:	17fffd3d 	b	7c1c <f0+0x1afc>
    872c:	aa1703e0 	mov	x0, x23
    8730:	97ffe995 	bl	2d84 <fwp_rc_forget_slot>
    8734:	17fffd76 	b	7d0c <f0+0x1bec>
    8738:	aa1703e0 	mov	x0, x23
    873c:	97ffe992 	bl	2d84 <fwp_rc_forget_slot>
    8740:	17fffda1 	b	7dc4 <f0+0x1ca4>
    8744:	aa1703e0 	mov	x0, x23
    8748:	97ffe98f 	bl	2d84 <fwp_rc_forget_slot>
    874c:	17fffdc3 	b	7e58 <f0+0x1d38>
    8750:	aa1703e0 	mov	x0, x23
    8754:	97ffe98c 	bl	2d84 <fwp_rc_forget_slot>
    8758:	17fffe18 	b	7fb8 <f0+0x1e98>
    875c:	aa1703e0 	mov	x0, x23
    8760:	97ffe989 	bl	2d84 <fwp_rc_forget_slot>
    8764:	17fffe3b 	b	8050 <f0+0x1f30>
    8768:	aa1703e0 	mov	x0, x23
    876c:	97ffe986 	bl	2d84 <fwp_rc_forget_slot>
    8770:	17fffe74 	b	8140 <f0+0x2020>
    8774:	aa1703e0 	mov	x0, x23
    8778:	97ffe983 	bl	2d84 <fwp_rc_forget_slot>
    877c:	17fffe9f 	b	81f8 <f0+0x20d8>
    8780:	aa1703e0 	mov	x0, x23
    8784:	97ffe980 	bl	2d84 <fwp_rc_forget_slot>
    8788:	17fffec1 	b	828c <f0+0x216c>
    878c:	97ffe35d 	bl	1500 <__stack_chk_fail@plt>

0000000000008790 <fwp_main_thread>:
    8790:	d10443ff 	sub	sp, sp, #0x110
    8794:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    8798:	f947f400 	ldr	x0, [x0, #4072]
    879c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    87a0:	910303fd 	add	x29, sp, #0xc0
    87a4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    87a8:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc70>
    87ac:	9115c2c1 	add	x1, x22, #0x570
    87b0:	a90d53f3 	stp	x19, x20, [sp, #208]
    87b4:	a90f63f7 	stp	x23, x24, [sp, #240]
    87b8:	b953a421 	ldr	w1, [x1, #5028]
    87bc:	a9106bf9 	stp	x25, x26, [sp, #256]
    87c0:	f9400002 	ldr	x2, [x0]
    87c4:	f9005fe2 	str	x2, [sp, #184]
    87c8:	d2800002 	mov	x2, #0x0                   	// #0
    87cc:	340028e1 	cbz	w1, 8ce8 <fwp_main_thread+0x558>
    87d0:	9115c2c0 	add	x0, x22, #0x570
    87d4:	b953a800 	ldr	w0, [x0, #5032]
    87d8:	35002800 	cbnz	w0, 8cd8 <fwp_main_thread+0x548>
    87dc:	91001fe2 	add	x2, sp, #0x7
    87e0:	900000d5 	adrp	x21, 20000 <__data_start>
    87e4:	900000c3 	adrp	x3, 20000 <__data_start>
    87e8:	910242b3 	add	x19, x21, #0x90
    87ec:	910e4063 	add	x3, x3, #0x390
    87f0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    87f4:	d2a00025 	mov	x5, #0x10000               	// #65536
    87f8:	910023e0 	add	x0, sp, #0x8
    87fc:	d2800001 	mov	x1, #0x0                   	// #0
    8800:	f90007e3 	str	x3, [sp, #8]
    8804:	a9011262 	stp	x2, x4, [x19, #16]
    8808:	b90013ff 	str	wzr, [sp, #16]
    880c:	f9000fe5 	str	x5, [sp, #24]
    8810:	97ffe2d8 	bl	1370 <sigaltstack@plt>
    8814:	35002820 	cbnz	w0, 8d18 <fwp_main_thread+0x588>
    8818:	4f000400 	movi	v0.4s, #0x0
    881c:	9100a3e0 	add	x0, sp, #0x28
    8820:	b0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    8824:	52800082 	mov	w2, #0x4                   	// #4
    8828:	91304021 	add	x1, x1, #0xc10
    882c:	72a10002 	movk	w2, #0x800, lsl #16
    8830:	910083f4 	add	x20, sp, #0x20
    8834:	f90013e1 	str	x1, [sp, #32]
    8838:	3d802000 	str	q0, [x0, #128]
    883c:	b900abe2 	str	w2, [sp, #168]
    8840:	ad000000 	stp	q0, q0, [x0]
    8844:	ad010000 	stp	q0, q0, [x0, #32]
    8848:	ad020000 	stp	q0, q0, [x0, #64]
    884c:	ad030000 	stp	q0, q0, [x0, #96]
    8850:	97ffe31c 	bl	14c0 <sigemptyset@plt>
    8854:	35002620 	cbnz	w0, 8d18 <fwp_main_thread+0x588>
    8858:	aa1403e1 	mov	x1, x20
    885c:	d2800002 	mov	x2, #0x0                   	// #0
    8860:	52800160 	mov	w0, #0xb                   	// #11
    8864:	97ffe32f 	bl	1520 <sigaction@plt>
    8868:	35002580 	cbnz	w0, 8d18 <fwp_main_thread+0x588>
    886c:	aa1403e1 	mov	x1, x20
    8870:	d2800002 	mov	x2, #0x0                   	// #0
    8874:	528000e0 	mov	w0, #0x7                   	// #7
    8878:	97ffe32a 	bl	1520 <sigaction@plt>
    887c:	350024e0 	cbnz	w0, 8d18 <fwp_main_thread+0x588>
    8880:	9115c2c1 	add	x1, x22, #0x570
    8884:	52800034 	mov	w20, #0x1                   	// #1
    8888:	b0ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    888c:	913c4000 	add	x0, x0, #0xf10
    8890:	b9004274 	str	w20, [x19, #64]
    8894:	fd4a1020 	ldr	d0, [x1, #5152]
    8898:	7e61d800 	ucvtf	d0, d0
    889c:	fd002e60 	str	d0, [x19, #88]
    88a0:	940002e4 	bl	9430 <atexit>
    88a4:	35002400 	cbnz	w0, 8d24 <fwp_main_thread+0x594>
    88a8:	b942d260 	ldr	w0, [x19, #720]
    88ac:	34002220 	cbz	w0, 8cf0 <fwp_main_thread+0x560>
    88b0:	910242ba 	add	x26, x21, #0x90
    88b4:	f9400754 	ldr	x20, [x26, #8]
    88b8:	b40010b4 	cbz	x20, 8acc <fwp_main_thread+0x33c>
    88bc:	aa1403f3 	mov	x19, x20
    88c0:	91010297 	add	x23, x20, #0x40
    88c4:	39414a99 	ldrb	w25, [x20, #82]
    88c8:	52800038 	mov	w24, #0x1                   	// #1
    88cc:	39014a98 	strb	w24, [x20, #82]
    88d0:	f9401680 	ldr	x0, [x20, #40]
    88d4:	b4000620 	cbz	x0, 8998 <fwp_main_thread+0x208>
    88d8:	f9403281 	ldr	x1, [x20, #96]
    88dc:	39414680 	ldrb	w0, [x20, #81]
    88e0:	b4000b41 	cbz	x1, 8a48 <fwp_main_thread+0x2b8>
    88e4:	36000a80 	tbz	w0, #0, 8a34 <fwp_main_thread+0x2a4>
    88e8:	39414a62 	ldrb	w2, [x19, #82]
    88ec:	f9402280 	ldr	x0, [x20, #64]
    88f0:	37000d62 	tbnz	w2, #0, 8a9c <fwp_main_thread+0x30c>
    88f4:	f9403261 	ldr	x1, [x19, #96]
    88f8:	a911fe77 	stp	x23, xzr, [x19, #280]
    88fc:	f9009660 	str	x0, [x19, #296]
    8900:	b4000040 	cbz	x0, 8908 <fwp_main_thread+0x178>
    8904:	f9009013 	str	x19, [x0, #288]
    8908:	f9002293 	str	x19, [x20, #64]
    890c:	b4000101 	cbz	x1, 892c <fwp_main_thread+0x19c>
    8910:	f9401f40 	ldr	x0, [x26, #56]
    8914:	39015678 	strb	w24, [x19, #85]
    8918:	f9003661 	str	x1, [x19, #104]
    891c:	a910827f 	stp	xzr, x0, [x19, #264]
    8920:	b4000040 	cbz	x0, 8928 <fwp_main_thread+0x198>
    8924:	f9008413 	str	x19, [x0, #264]
    8928:	f9001f53 	str	x19, [x26, #56]
    892c:	39015a7f 	strb	wzr, [x19, #86]
    8930:	97ffed4d 	bl	3e64 <fwp_block>
    8934:	f9408e62 	ldr	x2, [x19, #280]
    8938:	b4000142 	cbz	x2, 8960 <fwp_main_thread+0x1d0>
    893c:	a9520261 	ldp	x1, x0, [x19, #288]
    8940:	b4000ba1 	cbz	x1, 8ab4 <fwp_main_thread+0x324>
    8944:	f9009420 	str	x0, [x1, #296]
    8948:	f9409660 	ldr	x0, [x19, #296]
    894c:	b4000040 	cbz	x0, 8954 <fwp_main_thread+0x1c4>
    8950:	f9009001 	str	x1, [x0, #288]
    8954:	91080260 	add	x0, x19, #0x200
    8958:	f900967f 	str	xzr, [x19, #296]
    895c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8960:	39415660 	ldrb	w0, [x19, #85]
    8964:	f9400742 	ldr	x2, [x26, #8]
    8968:	36000960 	tbz	w0, #0, 8a94 <fwp_main_thread+0x304>
    896c:	a9508261 	ldp	x1, x0, [x19, #264]
    8970:	b4000a61 	cbz	x1, 8abc <fwp_main_thread+0x32c>
    8974:	f9008820 	str	x0, [x1, #272]
    8978:	b4000040 	cbz	x0, 8980 <fwp_main_thread+0x1f0>
    897c:	f9008401 	str	x1, [x0, #264]
    8980:	91080260 	add	x0, x19, #0x200
    8984:	3901567f 	strb	wzr, [x19, #85]
    8988:	aa0203f3 	mov	x19, x2
    898c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8990:	f9401680 	ldr	x0, [x20, #40]
    8994:	b5fffa20 	cbnz	x0, 88d8 <fwp_main_thread+0x148>
    8998:	910242a0 	add	x0, x21, #0x90
    899c:	39014a99 	strb	w25, [x20, #82]
    89a0:	f9415400 	ldr	x0, [x0, #680]
    89a4:	b40017c0 	cbz	x0, 8c9c <fwp_main_thread+0x50c>
    89a8:	910242a0 	add	x0, x21, #0x90
    89ac:	f9417401 	ldr	x1, [x0, #744]
    89b0:	b902e01f 	str	wzr, [x0, #736]
    89b4:	eb13003f 	cmp	x1, x19
    89b8:	540018e1 	b.ne	8cd4 <fwp_main_thread+0x544>  // b.any
    89bc:	b4000933 	cbz	x19, 8ae0 <fwp_main_thread+0x350>
    89c0:	910242a0 	add	x0, x21, #0x90
    89c4:	52800021 	mov	w1, #0x1                   	// #1
    89c8:	39014a61 	strb	w1, [x19, #82]
    89cc:	f9414005 	ldr	x5, [x0, #640]
    89d0:	b4000885 	cbz	x5, 8ae0 <fwp_main_thread+0x350>
    89d4:	d503201f 	nop
    89d8:	394140a0 	ldrb	w0, [x5, #80]
    89dc:	37000060 	tbnz	w0, #0, 89e8 <fwp_main_thread+0x258>
    89e0:	aa0503e0 	mov	x0, x5
    89e4:	97ffe5e3 	bl	2170 <fwp_cancel_tree.part.0>
    89e8:	f9409ca5 	ldr	x5, [x5, #312]
    89ec:	b5ffff65 	cbnz	x5, 89d8 <fwp_main_thread+0x248>
    89f0:	910242b4 	add	x20, x21, #0x90
    89f4:	52800037 	mov	w23, #0x1                   	// #1
    89f8:	f9402a60 	ldr	x0, [x19, #80]
    89fc:	f2001c1f 	tst	x0, #0xff000000ff
    8a00:	540000e1 	b.ne	8a1c <fwp_main_thread+0x28c>  // b.any
    8a04:	f9401680 	ldr	x0, [x20, #40]
    8a08:	39015277 	strb	w23, [x19, #84]
    8a0c:	f900827f 	str	xzr, [x19, #256]
    8a10:	b40005a0 	cbz	x0, 8ac4 <fwp_main_thread+0x334>
    8a14:	f9008013 	str	x19, [x0, #256]
    8a18:	f9001693 	str	x19, [x20, #40]
    8a1c:	97ffed12 	bl	3e64 <fwp_block>
    8a20:	97ffeca4 	bl	3cb0 <fwp_free_zombie>
    8a24:	f9414280 	ldr	x0, [x20, #640]
    8a28:	b40005c0 	cbz	x0, 8ae0 <fwp_main_thread+0x350>
    8a2c:	f9417693 	ldr	x19, [x20, #744]
    8a30:	17fffff2 	b	89f8 <fwp_main_thread+0x268>
    8a34:	97ffe623 	bl	22c0 <fwp_now_ns>
    8a38:	f9403281 	ldr	x1, [x20, #96]
    8a3c:	eb01001f 	cmp	x0, x1
    8a40:	5400120a 	b.ge	8c80 <fwp_main_thread+0x4f0>  // b.tcont
    8a44:	39414680 	ldrb	w0, [x20, #81]
    8a48:	39414a62 	ldrb	w2, [x19, #82]
    8a4c:	3707f500 	tbnz	w0, #0, 88ec <fwp_main_thread+0x15c>
    8a50:	f9403281 	ldr	x1, [x20, #96]
    8a54:	370001c2 	tbnz	w2, #0, 8a8c <fwp_main_thread+0x2fc>
    8a58:	f9403260 	ldr	x0, [x19, #96]
    8a5c:	b4000180 	cbz	x0, 8a8c <fwp_main_thread+0x2fc>
    8a60:	b4000061 	cbz	x1, 8a6c <fwp_main_thread+0x2dc>
    8a64:	eb01001f 	cmp	x0, x1
    8a68:	9a81d000 	csel	x0, x0, x1, le
    8a6c:	f9402281 	ldr	x1, [x20, #64]
    8a70:	a911fe77 	stp	x23, xzr, [x19, #280]
    8a74:	f9009661 	str	x1, [x19, #296]
    8a78:	b4001441 	cbz	x1, 8d00 <fwp_main_thread+0x570>
    8a7c:	f9009033 	str	x19, [x1, #288]
    8a80:	aa0003e1 	mov	x1, x0
    8a84:	f9002293 	str	x19, [x20, #64]
    8a88:	17ffffa2 	b	8910 <fwp_main_thread+0x180>
    8a8c:	f9402280 	ldr	x0, [x20, #64]
    8a90:	17ffff9a 	b	88f8 <fwp_main_thread+0x168>
    8a94:	aa0203f3 	mov	x19, x2
    8a98:	17ffff8e 	b	88d0 <fwp_main_thread+0x140>
    8a9c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8aa0:	f9009660 	str	x0, [x19, #296]
    8aa4:	b4000040 	cbz	x0, 8aac <fwp_main_thread+0x31c>
    8aa8:	f9009013 	str	x19, [x0, #288]
    8aac:	f9002293 	str	x19, [x20, #64]
    8ab0:	17ffff9f 	b	892c <fwp_main_thread+0x19c>
    8ab4:	f9000040 	str	x0, [x2]
    8ab8:	17ffffa5 	b	894c <fwp_main_thread+0x1bc>
    8abc:	f9001f40 	str	x0, [x26, #56]
    8ac0:	17ffffae 	b	8978 <fwp_main_thread+0x1e8>
    8ac4:	f9001a93 	str	x19, [x20, #48]
    8ac8:	17ffffd4 	b	8a18 <fwp_main_thread+0x288>
    8acc:	f9415740 	ldr	x0, [x26, #680]
    8ad0:	b4000e40 	cbz	x0, 8c98 <fwp_main_thread+0x508>
    8ad4:	f9417740 	ldr	x0, [x26, #744]
    8ad8:	b902e35f 	str	wzr, [x26, #736]
    8adc:	b5000fc0 	cbnz	x0, 8cd4 <fwp_main_thread+0x544>
    8ae0:	910242b4 	add	x20, x21, #0x90
    8ae4:	97ffec73 	bl	3cb0 <fwp_free_zombie>
    8ae8:	f9401a80 	ldr	x0, [x20, #48]
    8aec:	b5000f40 	cbnz	x0, 8cd4 <fwp_main_thread+0x544>
    8af0:	f9401e80 	ldr	x0, [x20, #56]
    8af4:	b5000f00 	cbnz	x0, 8cd4 <fwp_main_thread+0x544>
    8af8:	b9407293 	ldr	w19, [x20, #112]
    8afc:	340001d3 	cbz	w19, 8b34 <fwp_main_thread+0x3a4>
    8b00:	93407e77 	sxtw	x23, w19
    8b04:	51000673 	sub	w19, w19, #0x1
    8b08:	d1000af7 	sub	x23, x23, #0x2
    8b0c:	91020298 	add	x24, x20, #0x80
    8b10:	cb3342f7 	sub	x23, x23, w19, uxtw
    8b14:	93407e73 	sxtw	x19, w19
    8b18:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    8b1c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8b20:	b9007293 	str	w19, [x20, #112]
    8b24:	d1000673 	sub	x19, x19, #0x1
    8b28:	97ffe2be 	bl	1620 <munmap@plt>
    8b2c:	eb1302ff 	cmp	x23, x19
    8b30:	54ffff41 	b.ne	8b18 <fwp_main_thread+0x388>  // b.any
    8b34:	900000d3 	adrp	x19, 20000 <__data_start>
    8b38:	91004260 	add	x0, x19, #0x10
    8b3c:	b9406000 	ldr	w0, [x0, #96]
    8b40:	37f80040 	tbnz	w0, #31, 8b48 <fwp_main_thread+0x3b8>
    8b44:	97ffe273 	bl	1510 <close@plt>
    8b48:	910242a0 	add	x0, x21, #0x90
    8b4c:	91004261 	add	x1, x19, #0x10
    8b50:	12800002 	mov	w2, #0xffffffff            	// #-1
    8b54:	d2800013 	mov	x19, #0x0                   	// #0
    8b58:	f9417817 	ldr	x23, [x0, #752]
    8b5c:	b9006022 	str	w2, [x1, #96]
    8b60:	f9417c14 	ldr	x20, [x0, #760]
    8b64:	b4000177 	cbz	x23, 8b90 <fwp_main_thread+0x400>
    8b68:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8b6c:	b40000c0 	cbz	x0, 8b84 <fwp_main_thread+0x3f4>
    8b70:	f9400001 	ldr	x1, [x0]
    8b74:	b5000b01 	cbnz	x1, 8cd4 <fwp_main_thread+0x544>
    8b78:	f9400401 	ldr	x1, [x0, #8]
    8b7c:	b5000ac1 	cbnz	x1, 8cd4 <fwp_main_thread+0x544>
    8b80:	97ffe920 	bl	3000 <fwp_mem_free>
    8b84:	91000673 	add	x19, x19, #0x1
    8b88:	eb1302ff 	cmp	x23, x19
    8b8c:	54fffee1 	b.ne	8b68 <fwp_main_thread+0x3d8>  // b.any
    8b90:	aa1403e0 	mov	x0, x20
    8b94:	97ffe91b 	bl	3000 <fwp_mem_free>
    8b98:	910242a0 	add	x0, x21, #0x90
    8b9c:	f9417413 	ldr	x19, [x0, #744]
    8ba0:	f901781f 	str	xzr, [x0, #752]
    8ba4:	f9017c1f 	str	xzr, [x0, #760]
    8ba8:	b40001f3 	cbz	x19, 8be4 <fwp_main_thread+0x454>
    8bac:	f9401661 	ldr	x1, [x19, #40]
    8bb0:	b5000921 	cbnz	x1, 8cd4 <fwp_main_thread+0x544>
    8bb4:	f9405661 	ldr	x1, [x19, #168]
    8bb8:	b50008e1 	cbnz	x1, 8cd4 <fwp_main_thread+0x544>
    8bbc:	f9415401 	ldr	x1, [x0, #680]
    8bc0:	b50008a1 	cbnz	x1, 8cd4 <fwp_main_thread+0x544>
    8bc4:	f9415c00 	ldr	x0, [x0, #696]
    8bc8:	b5000860 	cbnz	x0, 8cd4 <fwp_main_thread+0x544>
    8bcc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8bd0:	90000140 	adrp	x0, 30000 <alt.4+0xfc70>
    8bd4:	910e4000 	add	x0, x0, #0x390
    8bd8:	97ffe23e 	bl	14d0 <memset@plt>
    8bdc:	aa1303e0 	mov	x0, x19
    8be0:	97ffe908 	bl	3000 <fwp_mem_free>
    8be4:	9115c2d6 	add	x22, x22, #0x570
    8be8:	910242b5 	add	x21, x21, #0x90
    8bec:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    8bf0:	f947e800 	ldr	x0, [x0, #4048]
    8bf4:	52800041 	mov	w1, #0x2                   	// #2
    8bf8:	fd4a12c0 	ldr	d0, [x22, #5152]
    8bfc:	b0000002 	adrp	x2, 9000 <__divti3+0x2c0>
    8c00:	fd402ea1 	ldr	d1, [x21, #88]
    8c04:	91248042 	add	x2, x2, #0x920
    8c08:	a94492a3 	ldp	x3, x4, [x21, #72]
    8c0c:	7e61d800 	ucvtf	d0, d0
    8c10:	f9400000 	ldr	x0, [x0]
    8c14:	f90006bf 	str	xzr, [x21, #8]
    8c18:	f94166a5 	ldr	x5, [x21, #712]
    8c1c:	1e613801 	fsub	d1, d0, d1
    8c20:	fd4032a0 	ldr	d0, [x21, #96]
    8c24:	f90012bf 	str	xzr, [x21, #32]
    8c28:	b90042bf 	str	wzr, [x21, #64]
    8c2c:	f90176bf 	str	xzr, [x21, #744]
    8c30:	97ffe250 	bl	1570 <__fprintf_chk@plt>
    8c34:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    8c38:	f947ec00 	ldr	x0, [x0, #4056]
    8c3c:	f9400000 	ldr	x0, [x0]
    8c40:	97ffe27c 	bl	1630 <fflush@plt>
    8c44:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14718>
    8c48:	f947f400 	ldr	x0, [x0, #4072]
    8c4c:	f9405fe2 	ldr	x2, [sp, #184]
    8c50:	f9400001 	ldr	x1, [x0]
    8c54:	eb010042 	subs	x2, x2, x1
    8c58:	d2800001 	mov	x1, #0x0                   	// #0
    8c5c:	540006a1 	b.ne	8d30 <fwp_main_thread+0x5a0>  // b.any
    8c60:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8c64:	d2800000 	mov	x0, #0x0                   	// #0
    8c68:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8c6c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8c70:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8c74:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8c78:	910443ff 	add	sp, sp, #0x110
    8c7c:	d65f03c0 	ret
    8c80:	39414280 	ldrb	w0, [x20, #80]
    8c84:	3707ee00 	tbnz	w0, #0, 8a44 <fwp_main_thread+0x2b4>
    8c88:	aa1403e0 	mov	x0, x20
    8c8c:	97ffe539 	bl	2170 <fwp_cancel_tree.part.0>
    8c90:	39414680 	ldrb	w0, [x20, #81]
    8c94:	17ffff6d 	b	8a48 <fwp_main_thread+0x2b8>
    8c98:	d2800013 	mov	x19, #0x0                   	// #0
    8c9c:	910242b4 	add	x20, x21, #0x90
    8ca0:	f9415e80 	ldr	x0, [x20, #696]
    8ca4:	b5ffe820 	cbnz	x0, 89a8 <fwp_main_thread+0x218>
    8ca8:	f9415280 	ldr	x0, [x20, #672]
    8cac:	97ffe8d5 	bl	3000 <fwp_mem_free>
    8cb0:	f901529f 	str	xzr, [x20, #672]
    8cb4:	f9015a9f 	str	xzr, [x20, #688]
    8cb8:	f9417680 	ldr	x0, [x20, #744]
    8cbc:	b4000293 	cbz	x19, 8d0c <fwp_main_thread+0x57c>
    8cc0:	f900567f 	str	xzr, [x19, #168]
    8cc4:	f9005e7f 	str	xzr, [x19, #184]
    8cc8:	b902e29f 	str	wzr, [x20, #736]
    8ccc:	eb13001f 	cmp	x0, x19
    8cd0:	54ffe780 	b.eq	89c0 <fwp_main_thread+0x230>  // b.none
    8cd4:	97ffe21f 	bl	1550 <abort@plt>
    8cd8:	d0ffffc0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    8cdc:	911d9000 	add	x0, x0, #0x764
    8ce0:	940001d4 	bl	9430 <atexit>
    8ce4:	17fffebe 	b	87dc <fwp_main_thread+0x4c>
    8ce8:	97ffe6fa 	bl	28d0 <fwp_heap_init>
    8cec:	17fffeb9 	b	87d0 <fwp_main_thread+0x40>
    8cf0:	97fff50c 	bl	6120 <f0>
    8cf4:	b902d274 	str	w20, [x19, #720]
    8cf8:	f9016e60 	str	x0, [x19, #728]
    8cfc:	17fffeed 	b	88b0 <fwp_main_thread+0x120>
    8d00:	aa0003e1 	mov	x1, x0
    8d04:	f9002293 	str	x19, [x20, #64]
    8d08:	17ffff02 	b	8910 <fwp_main_thread+0x180>
    8d0c:	b902e29f 	str	wzr, [x20, #736]
    8d10:	b4ffee80 	cbz	x0, 8ae0 <fwp_main_thread+0x350>
    8d14:	97ffe20f 	bl	1550 <abort@plt>
    8d18:	b0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    8d1c:	91236000 	add	x0, x0, #0x8d8
    8d20:	97ffe558 	bl	2280 <fwp_trap>
    8d24:	b0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    8d28:	91240000 	add	x0, x0, #0x900
    8d2c:	97ffe46d 	bl	1ee0 <ad_raw_fail>
    8d30:	97ffe1f4 	bl	1500 <__stack_chk_fail@plt>
    8d34:	d503201f 	nop
    8d38:	d503201f 	nop
    8d3c:	d503201f 	nop

0000000000008d40 <__divti3>:
    8d40:	d503245f 	bti	c
    8d44:	d2800004 	mov	x4, #0x0                   	// #0
    8d48:	b7f80721 	tbnz	x1, #63, 8e2c <__divti3+0xec>
    8d4c:	b6f80083 	tbz	x3, #63, 8d5c <__divti3+0x1c>
    8d50:	eb0203e2 	negs	x2, x2
    8d54:	aa2403e4 	mvn	x4, x4
    8d58:	da0303e3 	ngc	x3, x3
    8d5c:	aa0203e6 	mov	x6, x2
    8d60:	aa0003e7 	mov	x7, x0
    8d64:	aa0103e5 	mov	x5, x1
    8d68:	b5000583 	cbnz	x3, 8e18 <__divti3+0xd8>
    8d6c:	eb01005f 	cmp	x2, x1
    8d70:	54000e69 	b.ls	8f3c <__divti3+0x1fc>  // b.plast
    8d74:	dac01040 	clz	x0, x2
    8d78:	b40000e0 	cbz	x0, 8d94 <__divti3+0x54>
    8d7c:	4b0003e1 	neg	w1, w0
    8d80:	9ac020a5 	lsl	x5, x5, x0
    8d84:	9ac02046 	lsl	x6, x2, x0
    8d88:	9ac124e1 	lsr	x1, x7, x1
    8d8c:	aa050025 	orr	x5, x1, x5
    8d90:	9ac020e7 	lsl	x7, x7, x0
    8d94:	d360fcc8 	lsr	x8, x6, #32
    8d98:	92407cc2 	and	x2, x6, #0xffffffff
    8d9c:	9ac808a3 	udiv	x3, x5, x8
    8da0:	9b089465 	msub	x5, x3, x8, x5
    8da4:	aa0303e0 	mov	x0, x3
    8da8:	9b037c41 	mul	x1, x2, x3
    8dac:	93c780a5 	extr	x5, x5, x7, #32
    8db0:	eb05003f 	cmp	x1, x5
    8db4:	540000a9 	b.ls	8dc8 <__divti3+0x88>  // b.plast
    8db8:	ab0500c5 	adds	x5, x6, x5
    8dbc:	d1000460 	sub	x0, x3, #0x1
    8dc0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8dc4:	540015a8 	b.hi	9078 <__divti3+0x338>  // b.pmore
    8dc8:	cb0100a5 	sub	x5, x5, x1
    8dcc:	9ac808a3 	udiv	x3, x5, x8
    8dd0:	9b089465 	msub	x5, x3, x8, x5
    8dd4:	aa0303e1 	mov	x1, x3
    8dd8:	9b037c42 	mul	x2, x2, x3
    8ddc:	aa0703e3 	mov	x3, x7
    8de0:	b3607ca3 	bfi	x3, x5, #32, #32
    8de4:	eb03005f 	cmp	x2, x3
    8de8:	540000c9 	b.ls	8e00 <__divti3+0xc0>  // b.plast
    8dec:	ab0300c3 	adds	x3, x6, x3
    8df0:	d1000425 	sub	x5, x1, #0x1
    8df4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8df8:	d1000821 	sub	x1, x1, #0x2
    8dfc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8e00:	aa008020 	orr	x0, x1, x0, lsl #32
    8e04:	d2800001 	mov	x1, #0x0                   	// #0
    8e08:	b4000064 	cbz	x4, 8e14 <__divti3+0xd4>
    8e0c:	eb0003e0 	negs	x0, x0
    8e10:	da0103e1 	ngc	x1, x1
    8e14:	d65f03c0 	ret
    8e18:	eb01007f 	cmp	x3, x1
    8e1c:	54000109 	b.ls	8e3c <__divti3+0xfc>  // b.plast
    8e20:	d2800001 	mov	x1, #0x0                   	// #0
    8e24:	d2800000 	mov	x0, #0x0                   	// #0
    8e28:	17fffff8 	b	8e08 <__divti3+0xc8>
    8e2c:	eb0003e0 	negs	x0, x0
    8e30:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8e34:	da0103e1 	ngc	x1, x1
    8e38:	17ffffc5 	b	8d4c <__divti3+0xc>
    8e3c:	dac01067 	clz	x7, x3
    8e40:	b40010e7 	cbz	x7, 905c <__divti3+0x31c>
    8e44:	d2800805 	mov	x5, #0x40                  	// #64
    8e48:	cb0700a5 	sub	x5, x5, x7
    8e4c:	9ac72063 	lsl	x3, x3, x7
    8e50:	9ac52448 	lsr	x8, x2, x5
    8e54:	aa030108 	orr	x8, x8, x3
    8e58:	9ac52426 	lsr	x6, x1, x5
    8e5c:	92407d0a 	and	x10, x8, #0xffffffff
    8e60:	d360fd09 	lsr	x9, x8, #32
    8e64:	9ac52403 	lsr	x3, x0, x5
    8e68:	9ac72021 	lsl	x1, x1, x7
    8e6c:	aa010063 	orr	x3, x3, x1
    8e70:	9ac72042 	lsl	x2, x2, x7
    8e74:	9ac908cb 	udiv	x11, x6, x9
    8e78:	9b099965 	msub	x5, x11, x9, x6
    8e7c:	aa0b03e1 	mov	x1, x11
    8e80:	9b0b7d46 	mul	x6, x10, x11
    8e84:	93c380a5 	extr	x5, x5, x3, #32
    8e88:	eb0500df 	cmp	x6, x5
    8e8c:	540000a9 	b.ls	8ea0 <__divti3+0x160>  // b.plast
    8e90:	ab050105 	adds	x5, x8, x5
    8e94:	d1000561 	sub	x1, x11, #0x1
    8e98:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8e9c:	54000f48 	b.hi	9084 <__divti3+0x344>  // b.pmore
    8ea0:	cb0600a6 	sub	x6, x5, x6
    8ea4:	9ac908cb 	udiv	x11, x6, x9
    8ea8:	9b099969 	msub	x9, x11, x9, x6
    8eac:	aa0b03e5 	mov	x5, x11
    8eb0:	9b0b7d4a 	mul	x10, x10, x11
    8eb4:	b3607d23 	bfi	x3, x9, #32, #32
    8eb8:	eb03015f 	cmp	x10, x3
    8ebc:	540000a9 	b.ls	8ed0 <__divti3+0x190>  // b.plast
    8ec0:	ab030103 	adds	x3, x8, x3
    8ec4:	d1000565 	sub	x5, x11, #0x1
    8ec8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8ecc:	54000e28 	b.hi	9090 <__divti3+0x350>  // b.pmore
    8ed0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8ed4:	92407c48 	and	x8, x2, #0xffffffff
    8ed8:	2a0503e5 	mov	w5, w5
    8edc:	d360fc42 	lsr	x2, x2, #32
    8ee0:	d360fc26 	lsr	x6, x1, #32
    8ee4:	cb0a0063 	sub	x3, x3, x10
    8ee8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8eec:	9b087caa 	mul	x10, x5, x8
    8ef0:	9b087cc8 	mul	x8, x6, x8
    8ef4:	9b0220a5 	madd	x5, x5, x2, x8
    8ef8:	9b027cc6 	mul	x6, x6, x2
    8efc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8f00:	8b0900c5 	add	x5, x6, x9
    8f04:	eb02011f 	cmp	x8, x2
    8f08:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8f0c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8f10:	eb06007f 	cmp	x3, x6
    8f14:	540000e3 	b.cc	8f30 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8f18:	92407d4a 	and	x10, x10, #0xffffffff
    8f1c:	9ac72000 	lsl	x0, x0, x7
    8f20:	8b028142 	add	x2, x10, x2, lsl #32
    8f24:	eb02001f 	cmp	x0, x2
    8f28:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8f2c:	54000a01 	b.ne	906c <__divti3+0x32c>  // b.any
    8f30:	d1000420 	sub	x0, x1, #0x1
    8f34:	d2800001 	mov	x1, #0x0                   	// #0
    8f38:	17ffffb4 	b	8e08 <__divti3+0xc8>
    8f3c:	b5000062 	cbnz	x2, 8f48 <__divti3+0x208>
    8f40:	d2800022 	mov	x2, #0x1                   	// #1
    8f44:	9ac30846 	udiv	x6, x2, x3
    8f48:	dac010c8 	clz	x8, x6
    8f4c:	b5000408 	cbnz	x8, 8fcc <__divti3+0x28c>
    8f50:	d360fcc9 	lsr	x9, x6, #32
    8f54:	92407cc5 	and	x5, x6, #0xffffffff
    8f58:	cb060023 	sub	x3, x1, x6
    8f5c:	d2800021 	mov	x1, #0x1                   	// #1
    8f60:	9ac90868 	udiv	x8, x3, x9
    8f64:	9b098d03 	msub	x3, x8, x9, x3
    8f68:	aa0803e0 	mov	x0, x8
    8f6c:	9b057d02 	mul	x2, x8, x5
    8f70:	93c78063 	extr	x3, x3, x7, #32
    8f74:	eb03005f 	cmp	x2, x3
    8f78:	540000a9 	b.ls	8f8c <__divti3+0x24c>  // b.plast
    8f7c:	ab0300c3 	adds	x3, x6, x3
    8f80:	d1000500 	sub	x0, x8, #0x1
    8f84:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8f88:	54000968 	b.hi	90b4 <__divti3+0x374>  // b.pmore
    8f8c:	cb020063 	sub	x3, x3, x2
    8f90:	9ac90862 	udiv	x2, x3, x9
    8f94:	aa0203e8 	mov	x8, x2
    8f98:	9b098c42 	msub	x2, x2, x9, x3
    8f9c:	aa0703e3 	mov	x3, x7
    8fa0:	9b057d05 	mul	x5, x8, x5
    8fa4:	b3607c43 	bfi	x3, x2, #32, #32
    8fa8:	eb0300bf 	cmp	x5, x3
    8fac:	540000c9 	b.ls	8fc4 <__divti3+0x284>  // b.plast
    8fb0:	ab0300c2 	adds	x2, x6, x3
    8fb4:	d1000503 	sub	x3, x8, #0x1
    8fb8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8fbc:	d1000908 	sub	x8, x8, #0x2
    8fc0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8fc4:	aa008100 	orr	x0, x8, x0, lsl #32
    8fc8:	17ffff90 	b	8e08 <__divti3+0xc8>
    8fcc:	9ac820c6 	lsl	x6, x6, x8
    8fd0:	d2800803 	mov	x3, #0x40                  	// #64
    8fd4:	cb080063 	sub	x3, x3, x8
    8fd8:	d360fcc9 	lsr	x9, x6, #32
    8fdc:	9ac82027 	lsl	x7, x1, x8
    8fe0:	92407cc5 	and	x5, x6, #0xffffffff
    8fe4:	9ac32422 	lsr	x2, x1, x3
    8fe8:	9ac32403 	lsr	x3, x0, x3
    8fec:	aa070063 	orr	x3, x3, x7
    8ff0:	9ac9084a 	udiv	x10, x2, x9
    8ff4:	9ac82007 	lsl	x7, x0, x8
    8ff8:	9b098940 	msub	x0, x10, x9, x2
    8ffc:	aa0a03e1 	mov	x1, x10
    9000:	9b0a7ca2 	mul	x2, x5, x10
    9004:	93c38000 	extr	x0, x0, x3, #32
    9008:	eb00005f 	cmp	x2, x0
    900c:	540000a9 	b.ls	9020 <__divti3+0x2e0>  // b.plast
    9010:	ab0000c0 	adds	x0, x6, x0
    9014:	d1000541 	sub	x1, x10, #0x1
    9018:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    901c:	54000468 	b.hi	90a8 <__divti3+0x368>  // b.pmore
    9020:	cb020000 	sub	x0, x0, x2
    9024:	9ac9080a 	udiv	x10, x0, x9
    9028:	9b098140 	msub	x0, x10, x9, x0
    902c:	aa0a03e2 	mov	x2, x10
    9030:	9b0a7ca8 	mul	x8, x5, x10
    9034:	b3607c03 	bfi	x3, x0, #32, #32
    9038:	eb03011f 	cmp	x8, x3
    903c:	540000a9 	b.ls	9050 <__divti3+0x310>  // b.plast
    9040:	ab0300c3 	adds	x3, x6, x3
    9044:	d1000542 	sub	x2, x10, #0x1
    9048:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    904c:	54000288 	b.hi	909c <__divti3+0x35c>  // b.pmore
    9050:	cb080063 	sub	x3, x3, x8
    9054:	aa018041 	orr	x1, x2, x1, lsl #32
    9058:	17ffffc2 	b	8f60 <__divti3+0x220>
    905c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9060:	d2800001 	mov	x1, #0x0                   	// #0
    9064:	9a9f87e0 	cset	x0, ls	// ls = plast
    9068:	17ffff68 	b	8e08 <__divti3+0xc8>
    906c:	aa0103e0 	mov	x0, x1
    9070:	d2800001 	mov	x1, #0x0                   	// #0
    9074:	17ffff65 	b	8e08 <__divti3+0xc8>
    9078:	d1000860 	sub	x0, x3, #0x2
    907c:	8b0600a5 	add	x5, x5, x6
    9080:	17ffff52 	b	8dc8 <__divti3+0x88>
    9084:	d1000961 	sub	x1, x11, #0x2
    9088:	8b0800a5 	add	x5, x5, x8
    908c:	17ffff85 	b	8ea0 <__divti3+0x160>
    9090:	d1000965 	sub	x5, x11, #0x2
    9094:	8b080063 	add	x3, x3, x8
    9098:	17ffff8e 	b	8ed0 <__divti3+0x190>
    909c:	d1000942 	sub	x2, x10, #0x2
    90a0:	8b060063 	add	x3, x3, x6
    90a4:	17ffffeb 	b	9050 <__divti3+0x310>
    90a8:	d1000941 	sub	x1, x10, #0x2
    90ac:	8b060000 	add	x0, x0, x6
    90b0:	17ffffdc 	b	9020 <__divti3+0x2e0>
    90b4:	d1000900 	sub	x0, x8, #0x2
    90b8:	8b060063 	add	x3, x3, x6
    90bc:	17ffffb4 	b	8f8c <__divti3+0x24c>

00000000000090c0 <__modti3>:
    90c0:	d503245f 	bti	c
    90c4:	d2800004 	mov	x4, #0x0                   	// #0
    90c8:	b6f80081 	tbz	x1, #63, 90d8 <__modti3+0x18>
    90cc:	eb0003e0 	negs	x0, x0
    90d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    90d4:	da0103e1 	ngc	x1, x1
    90d8:	f100007f 	cmp	x3, #0x0
    90dc:	5400128b 	b.lt	932c <__modti3+0x26c>  // b.tstop
    90e0:	aa0003e7 	mov	x7, x0
    90e4:	aa0103e6 	mov	x6, x1
    90e8:	540004e1 	b.ne	9184 <__modti3+0xc4>  // b.any
    90ec:	eb02003f 	cmp	x1, x2
    90f0:	54000dc2 	b.cs	92a8 <__modti3+0x1e8>  // b.hs, b.nlast
    90f4:	dac01043 	clz	x3, x2
    90f8:	aa0303e5 	mov	x5, x3
    90fc:	b40000e3 	cbz	x3, 9118 <__modti3+0x58>
    9100:	4b0303e6 	neg	w6, w3
    9104:	9ac32021 	lsl	x1, x1, x3
    9108:	9ac32042 	lsl	x2, x2, x3
    910c:	9ac62406 	lsr	x6, x0, x6
    9110:	aa0100c6 	orr	x6, x6, x1
    9114:	9ac32007 	lsl	x7, x0, x3
    9118:	d360fc40 	lsr	x0, x2, #32
    911c:	92407c43 	and	x3, x2, #0xffffffff
    9120:	9ac008c1 	udiv	x1, x6, x0
    9124:	9b009826 	msub	x6, x1, x0, x6
    9128:	9b017c61 	mul	x1, x3, x1
    912c:	93c780c6 	extr	x6, x6, x7, #32
    9130:	eb06003f 	cmp	x1, x6
    9134:	540000a9 	b.ls	9148 <__modti3+0x88>  // b.plast
    9138:	ab060046 	adds	x6, x2, x6
    913c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9140:	8b0200c8 	add	x8, x6, x2
    9144:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9148:	cb0100c6 	sub	x6, x6, x1
    914c:	9ac008c8 	udiv	x8, x6, x0
    9150:	9b009901 	msub	x1, x8, x0, x6
    9154:	aa0703e0 	mov	x0, x7
    9158:	9b087c63 	mul	x3, x3, x8
    915c:	b3607c20 	bfi	x0, x1, #32, #32
    9160:	eb00007f 	cmp	x3, x0
    9164:	54001088 	b.hi	9374 <__modti3+0x2b4>  // b.pmore
    9168:	cb030000 	sub	x0, x0, x3
    916c:	9ac52400 	lsr	x0, x0, x5
    9170:	d2800001 	mov	x1, #0x0                   	// #0
    9174:	b4000064 	cbz	x4, 9180 <__modti3+0xc0>
    9178:	eb0003e0 	negs	x0, x0
    917c:	da0103e1 	ngc	x1, x1
    9180:	d65f03c0 	ret
    9184:	dac01066 	clz	x6, x3
    9188:	eb03003f 	cmp	x1, x3
    918c:	54ffff43 	b.cc	9174 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9190:	93407cc5 	sxtw	x5, w6
    9194:	d2800808 	mov	x8, #0x40                  	// #64
    9198:	cb050108 	sub	x8, x8, x5
    919c:	9ac62063 	lsl	x3, x3, x6
    91a0:	9ac62025 	lsl	x5, x1, x6
    91a4:	9ac82447 	lsr	x7, x2, x8
    91a8:	aa0300e7 	orr	x7, x7, x3
    91ac:	9ac82423 	lsr	x3, x1, x8
    91b0:	92407cec 	and	x12, x7, #0xffffffff
    91b4:	d360fcea 	lsr	x10, x7, #32
    91b8:	9ac82401 	lsr	x1, x0, x8
    91bc:	aa050021 	orr	x1, x1, x5
    91c0:	9ac62042 	lsl	x2, x2, x6
    91c4:	9ac62000 	lsl	x0, x0, x6
    91c8:	9aca086b 	udiv	x11, x3, x10
    91cc:	9b0a8d63 	msub	x3, x11, x10, x3
    91d0:	aa0b03e5 	mov	x5, x11
    91d4:	9b0b7d89 	mul	x9, x12, x11
    91d8:	93c18063 	extr	x3, x3, x1, #32
    91dc:	eb03013f 	cmp	x9, x3
    91e0:	540000a9 	b.ls	91f4 <__modti3+0x134>  // b.plast
    91e4:	ab0300e3 	adds	x3, x7, x3
    91e8:	d1000565 	sub	x5, x11, #0x1
    91ec:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    91f0:	54001168 	b.hi	941c <__modti3+0x35c>  // b.pmore
    91f4:	cb090063 	sub	x3, x3, x9
    91f8:	9aca086b 	udiv	x11, x3, x10
    91fc:	9b0a8d6a 	msub	x10, x11, x10, x3
    9200:	aa0b03e9 	mov	x9, x11
    9204:	9b0b7d8c 	mul	x12, x12, x11
    9208:	b3607d41 	bfi	x1, x10, #32, #32
    920c:	eb01019f 	cmp	x12, x1
    9210:	540000a9 	b.ls	9224 <__modti3+0x164>  // b.plast
    9214:	ab0100e1 	adds	x1, x7, x1
    9218:	d1000569 	sub	x9, x11, #0x1
    921c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9220:	54000f88 	b.hi	9410 <__modti3+0x350>  // b.pmore
    9224:	aa058123 	orr	x3, x9, x5, lsl #32
    9228:	92407c4b 	and	x11, x2, #0xffffffff
    922c:	2a0903e9 	mov	w9, w9
    9230:	d360fc4a 	lsr	x10, x2, #32
    9234:	d360fc63 	lsr	x3, x3, #32
    9238:	cb0c0021 	sub	x1, x1, x12
    923c:	aa0a03ec 	mov	x12, x10
    9240:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9244:	9b0b7d25 	mul	x5, x9, x11
    9248:	9b0b7c6b 	mul	x11, x3, x11
    924c:	9b0a2d29 	madd	x9, x9, x10, x11
    9250:	92407caa 	and	x10, x5, #0xffffffff
    9254:	9b0c7c63 	mul	x3, x3, x12
    9258:	8b458125 	add	x5, x9, x5, lsr #32
    925c:	8b0d0069 	add	x9, x3, x13
    9260:	eb05017f 	cmp	x11, x5
    9264:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9268:	8b058149 	add	x9, x10, x5, lsl #32
    926c:	8b458063 	add	x3, x3, x5, lsr #32
    9270:	eb03003f 	cmp	x1, x3
    9274:	54000063 	b.cc	9280 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9278:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    927c:	54000082 	b.cs	928c <__modti3+0x1cc>  // b.hs, b.nlast
    9280:	eb020129 	subs	x9, x9, x2
    9284:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9288:	cb070063 	sub	x3, x3, x7
    928c:	eb090000 	subs	x0, x0, x9
    9290:	da030021 	sbc	x1, x1, x3
    9294:	9ac62400 	lsr	x0, x0, x6
    9298:	9ac82028 	lsl	x8, x1, x8
    929c:	aa000100 	orr	x0, x8, x0
    92a0:	9ac62421 	lsr	x1, x1, x6
    92a4:	17ffffb4 	b	9174 <__modti3+0xb4>
    92a8:	b5000062 	cbnz	x2, 92b4 <__modti3+0x1f4>
    92ac:	d2800023 	mov	x3, #0x1                   	// #1
    92b0:	9ac20862 	udiv	x2, x3, x2
    92b4:	dac01048 	clz	x8, x2
    92b8:	aa0803e5 	mov	x5, x8
    92bc:	b5000668 	cbnz	x8, 9388 <__modti3+0x2c8>
    92c0:	cb020020 	sub	x0, x1, x2
    92c4:	d360fc49 	lsr	x9, x2, #32
    92c8:	92407c4a 	and	x10, x2, #0xffffffff
    92cc:	9ac90801 	udiv	x1, x0, x9
    92d0:	9b098020 	msub	x0, x1, x9, x0
    92d4:	9b0a7c21 	mul	x1, x1, x10
    92d8:	93c78000 	extr	x0, x0, x7, #32
    92dc:	eb00003f 	cmp	x1, x0
    92e0:	540000a9 	b.ls	92f4 <__modti3+0x234>  // b.plast
    92e4:	ab000040 	adds	x0, x2, x0
    92e8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    92ec:	8b020003 	add	x3, x0, x2
    92f0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    92f4:	cb010001 	sub	x1, x0, x1
    92f8:	9ac90820 	udiv	x0, x1, x9
    92fc:	9b098403 	msub	x3, x0, x9, x1
    9300:	aa0703e1 	mov	x1, x7
    9304:	9b0a7c00 	mul	x0, x0, x10
    9308:	b3607c61 	bfi	x1, x3, #32, #32
    930c:	eb01001f 	cmp	x0, x1
    9310:	540000a9 	b.ls	9324 <__modti3+0x264>  // b.plast
    9314:	ab010041 	adds	x1, x2, x1
    9318:	8b020022 	add	x2, x1, x2
    931c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9320:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9324:	cb000020 	sub	x0, x1, x0
    9328:	17ffff91 	b	916c <__modti3+0xac>
    932c:	eb0203e5 	negs	x5, x2
    9330:	aa0003e7 	mov	x7, x0
    9334:	da0303e8 	ngc	x8, x3
    9338:	aa0503e2 	mov	x2, x5
    933c:	aa0803e3 	mov	x3, x8
    9340:	aa0103e6 	mov	x6, x1
    9344:	b4ffed48 	cbz	x8, 90ec <__modti3+0x2c>
    9348:	eb01011f 	cmp	x8, x1
    934c:	54fff148 	b.hi	9174 <__modti3+0xb4>  // b.pmore
    9350:	dac01109 	clz	x9, x8
    9354:	2a0903e6 	mov	w6, w9
    9358:	b5fff1c9 	cbnz	x9, 9190 <__modti3+0xd0>
    935c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9360:	54000068 	b.hi	936c <__modti3+0x2ac>  // b.pmore
    9364:	eb050007 	subs	x7, x0, x5
    9368:	da080021 	sbc	x1, x1, x8
    936c:	aa0703e0 	mov	x0, x7
    9370:	17ffff81 	b	9174 <__modti3+0xb4>
    9374:	ab000040 	adds	x0, x2, x0
    9378:	8b020002 	add	x2, x0, x2
    937c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9380:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9384:	17ffff79 	b	9168 <__modti3+0xa8>
    9388:	9ac82042 	lsl	x2, x2, x8
    938c:	d2800803 	mov	x3, #0x40                  	// #64
    9390:	cb080063 	sub	x3, x3, x8
    9394:	d360fc49 	lsr	x9, x2, #32
    9398:	9ac82027 	lsl	x7, x1, x8
    939c:	92407c4a 	and	x10, x2, #0xffffffff
    93a0:	9ac32426 	lsr	x6, x1, x3
    93a4:	9ac32403 	lsr	x3, x0, x3
    93a8:	aa070063 	orr	x3, x3, x7
    93ac:	9ac908c1 	udiv	x1, x6, x9
    93b0:	9ac82007 	lsl	x7, x0, x8
    93b4:	9b099820 	msub	x0, x1, x9, x6
    93b8:	9b017d41 	mul	x1, x10, x1
    93bc:	93c38000 	extr	x0, x0, x3, #32
    93c0:	eb00003f 	cmp	x1, x0
    93c4:	540000a9 	b.ls	93d8 <__modti3+0x318>  // b.plast
    93c8:	ab000040 	adds	x0, x2, x0
    93cc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    93d0:	8b020006 	add	x6, x0, x2
    93d4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    93d8:	cb010000 	sub	x0, x0, x1
    93dc:	9ac90801 	udiv	x1, x0, x9
    93e0:	9b098026 	msub	x6, x1, x9, x0
    93e4:	aa0303e0 	mov	x0, x3
    93e8:	9b017d41 	mul	x1, x10, x1
    93ec:	b3607cc0 	bfi	x0, x6, #32, #32
    93f0:	eb00003f 	cmp	x1, x0
    93f4:	540000a9 	b.ls	9408 <__modti3+0x348>  // b.plast
    93f8:	ab000040 	adds	x0, x2, x0
    93fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9400:	8b020003 	add	x3, x0, x2
    9404:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9408:	cb010000 	sub	x0, x0, x1
    940c:	17ffffb0 	b	92cc <__modti3+0x20c>
    9410:	d1000969 	sub	x9, x11, #0x2
    9414:	8b070021 	add	x1, x1, x7
    9418:	17ffff83 	b	9224 <__modti3+0x164>
    941c:	d1000965 	sub	x5, x11, #0x2
    9420:	8b070063 	add	x3, x3, x7
    9424:	17ffff74 	b	91f4 <__modti3+0x134>
    9428:	d503201f 	nop
    942c:	d503201f 	nop

0000000000009430 <atexit>:
    9430:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9434:	f00000a2 	adrp	x2, 20000 <__data_start>
    9438:	d2800001 	mov	x1, #0x0                   	// #0
    943c:	910003fd 	mov	x29, sp
    9440:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9444:	f9400442 	ldr	x2, [x2, #8]
    9448:	17ffdfee 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000944c <_fini>:
    944c:	d503201f 	nop
    9450:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9454:	910003fd 	mov	x29, sp
    9458:	a8c17bfd 	ldp	x29, x30, [sp], #16
    945c:	d65f03c0 	ret
