
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000012c8 <_init>:
    12c8:	d503201f 	nop
    12cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    12d0:	910003fd 	mov	x29, sp
    12d4:	94000188 	bl	18f4 <call_weak_fn>
    12d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    12dc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000012e0 <.plt>:
    12e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    12e4:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    12e8:	f946fe11 	ldr	x17, [x16, #3576]
    12ec:	9137e210 	add	x16, x16, #0xdf8
    12f0:	d61f0220 	br	x17
    12f4:	d503201f 	nop
    12f8:	d503201f 	nop
    12fc:	d503201f 	nop

0000000000001300 <memcpy@plt>:
    1300:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1304:	f9470211 	ldr	x17, [x16, #3584]
    1308:	91380210 	add	x16, x16, #0xe00
    130c:	d61f0220 	br	x17

0000000000001310 <sigaltstack@plt>:
    1310:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1314:	f9470611 	ldr	x17, [x16, #3592]
    1318:	91382210 	add	x16, x16, #0xe08
    131c:	d61f0220 	br	x17

0000000000001320 <_exit@plt>:
    1320:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1324:	f9470a11 	ldr	x17, [x16, #3600]
    1328:	91384210 	add	x16, x16, #0xe10
    132c:	d61f0220 	br	x17

0000000000001330 <strlen@plt>:
    1330:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1334:	f9470e11 	ldr	x17, [x16, #3608]
    1338:	91386210 	add	x16, x16, #0xe18
    133c:	d61f0220 	br	x17

0000000000001340 <__sprintf_chk@plt>:
    1340:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1344:	f9471211 	ldr	x17, [x16, #3616]
    1348:	91388210 	add	x16, x16, #0xe20
    134c:	d61f0220 	br	x17

0000000000001350 <exit@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1354:	f9471611 	ldr	x17, [x16, #3624]
    1358:	9138a210 	add	x16, x16, #0xe28
    135c:	d61f0220 	br	x17

0000000000001360 <__libc_start_main@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1364:	f9471a11 	ldr	x17, [x16, #3632]
    1368:	9138c210 	add	x16, x16, #0xe30
    136c:	d61f0220 	br	x17

0000000000001370 <strtoll@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1374:	f9471e11 	ldr	x17, [x16, #3640]
    1378:	9138e210 	add	x16, x16, #0xe38
    137c:	d61f0220 	br	x17

0000000000001380 <strtod@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1384:	f9472211 	ldr	x17, [x16, #3648]
    1388:	91390210 	add	x16, x16, #0xe40
    138c:	d61f0220 	br	x17

0000000000001390 <__cxa_finalize@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1394:	f9472611 	ldr	x17, [x16, #3656]
    1398:	91392210 	add	x16, x16, #0xe48
    139c:	d61f0220 	br	x17

00000000000013a0 <__cxa_atexit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13a4:	f9472a11 	ldr	x17, [x16, #3664]
    13a8:	91394210 	add	x16, x16, #0xe50
    13ac:	d61f0220 	br	x17

00000000000013b0 <pthread_attr_init@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13b4:	f9472e11 	ldr	x17, [x16, #3672]
    13b8:	91396210 	add	x16, x16, #0xe58
    13bc:	d61f0220 	br	x17

00000000000013c0 <fputc@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13c4:	f9473211 	ldr	x17, [x16, #3680]
    13c8:	91398210 	add	x16, x16, #0xe60
    13cc:	d61f0220 	br	x17

00000000000013d0 <clock_gettime@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13d4:	f9473611 	ldr	x17, [x16, #3688]
    13d8:	9139a210 	add	x16, x16, #0xe68
    13dc:	d61f0220 	br	x17

00000000000013e0 <setvbuf@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13e4:	f9473a11 	ldr	x17, [x16, #3696]
    13e8:	9139c210 	add	x16, x16, #0xe70
    13ec:	d61f0220 	br	x17

00000000000013f0 <__memcpy_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    13f4:	f9473e11 	ldr	x17, [x16, #3704]
    13f8:	9139e210 	add	x16, x16, #0xe78
    13fc:	d61f0220 	br	x17

0000000000001400 <signal@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1404:	f9474211 	ldr	x17, [x16, #3712]
    1408:	913a0210 	add	x16, x16, #0xe80
    140c:	d61f0220 	br	x17

0000000000001410 <__snprintf_chk@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1414:	f9474611 	ldr	x17, [x16, #3720]
    1418:	913a2210 	add	x16, x16, #0xe88
    141c:	d61f0220 	br	x17

0000000000001420 <fclose@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1424:	f9474a11 	ldr	x17, [x16, #3728]
    1428:	913a4210 	add	x16, x16, #0xe90
    142c:	d61f0220 	br	x17

0000000000001430 <fopen@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1434:	f9474e11 	ldr	x17, [x16, #3736]
    1438:	913a6210 	add	x16, x16, #0xe98
    143c:	d61f0220 	br	x17

0000000000001440 <malloc@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1444:	f9475211 	ldr	x17, [x16, #3744]
    1448:	913a8210 	add	x16, x16, #0xea0
    144c:	d61f0220 	br	x17

0000000000001450 <pthread_attr_destroy@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1454:	f9475611 	ldr	x17, [x16, #3752]
    1458:	913aa210 	add	x16, x16, #0xea8
    145c:	d61f0220 	br	x17

0000000000001460 <sigemptyset@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1464:	f9475a11 	ldr	x17, [x16, #3760]
    1468:	913ac210 	add	x16, x16, #0xeb0
    146c:	d61f0220 	br	x17

0000000000001470 <memset@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1474:	f9475e11 	ldr	x17, [x16, #3768]
    1478:	913ae210 	add	x16, x16, #0xeb8
    147c:	d61f0220 	br	x17

0000000000001480 <calloc@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1484:	f9476211 	ldr	x17, [x16, #3776]
    1488:	913b0210 	add	x16, x16, #0xec0
    148c:	d61f0220 	br	x17

0000000000001490 <realloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1494:	f9476611 	ldr	x17, [x16, #3784]
    1498:	913b2210 	add	x16, x16, #0xec8
    149c:	d61f0220 	br	x17

00000000000014a0 <__stack_chk_fail@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14a4:	f9476a11 	ldr	x17, [x16, #3792]
    14a8:	913b4210 	add	x16, x16, #0xed0
    14ac:	d61f0220 	br	x17

00000000000014b0 <close@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14b4:	f9476e11 	ldr	x17, [x16, #3800]
    14b8:	913b6210 	add	x16, x16, #0xed8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigaction@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14c4:	f9477211 	ldr	x17, [x16, #3808]
    14c8:	913b8210 	add	x16, x16, #0xee0
    14cc:	d61f0220 	br	x17

00000000000014d0 <__gmon_start__@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14d4:	f9477611 	ldr	x17, [x16, #3816]
    14d8:	913ba210 	add	x16, x16, #0xee8
    14dc:	d61f0220 	br	x17

00000000000014e0 <write@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14e4:	f9477a11 	ldr	x17, [x16, #3824]
    14e8:	913bc210 	add	x16, x16, #0xef0
    14ec:	d61f0220 	br	x17

00000000000014f0 <abort@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    14f4:	f9477e11 	ldr	x17, [x16, #3832]
    14f8:	913be210 	add	x16, x16, #0xef8
    14fc:	d61f0220 	br	x17

0000000000001500 <swapcontext@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1504:	f9478211 	ldr	x17, [x16, #3840]
    1508:	913c0210 	add	x16, x16, #0xf00
    150c:	d61f0220 	br	x17

0000000000001510 <__fprintf_chk@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1514:	f9478611 	ldr	x17, [x16, #3848]
    1518:	913c2210 	add	x16, x16, #0xf08
    151c:	d61f0220 	br	x17

0000000000001520 <strcmp@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1524:	f9478a11 	ldr	x17, [x16, #3856]
    1528:	913c4210 	add	x16, x16, #0xf10
    152c:	d61f0220 	br	x17

0000000000001530 <mmap@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1534:	f9478e11 	ldr	x17, [x16, #3864]
    1538:	913c6210 	add	x16, x16, #0xf18
    153c:	d61f0220 	br	x17

0000000000001540 <strtol@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1544:	f9479211 	ldr	x17, [x16, #3872]
    1548:	913c8210 	add	x16, x16, #0xf20
    154c:	d61f0220 	br	x17

0000000000001550 <strtof@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1554:	f9479611 	ldr	x17, [x16, #3880]
    1558:	913ca210 	add	x16, x16, #0xf28
    155c:	d61f0220 	br	x17

0000000000001560 <free@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1564:	f9479a11 	ldr	x17, [x16, #3888]
    1568:	913cc210 	add	x16, x16, #0xf30
    156c:	d61f0220 	br	x17

0000000000001570 <nanosleep@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1574:	f9479e11 	ldr	x17, [x16, #3896]
    1578:	913ce210 	add	x16, x16, #0xf38
    157c:	d61f0220 	br	x17

0000000000001580 <strchr@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1584:	f947a211 	ldr	x17, [x16, #3904]
    1588:	913d0210 	add	x16, x16, #0xf40
    158c:	d61f0220 	br	x17

0000000000001590 <strtoull@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1594:	f947a611 	ldr	x17, [x16, #3912]
    1598:	913d2210 	add	x16, x16, #0xf48
    159c:	d61f0220 	br	x17

00000000000015a0 <fwrite@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15a4:	f947aa11 	ldr	x17, [x16, #3920]
    15a8:	913d4210 	add	x16, x16, #0xf50
    15ac:	d61f0220 	br	x17

00000000000015b0 <pthread_create@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15b4:	f947ae11 	ldr	x17, [x16, #3928]
    15b8:	913d6210 	add	x16, x16, #0xf58
    15bc:	d61f0220 	br	x17

00000000000015c0 <munmap@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15c4:	f947b211 	ldr	x17, [x16, #3936]
    15c8:	913d8210 	add	x16, x16, #0xf60
    15cc:	d61f0220 	br	x17

00000000000015d0 <fflush@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15d4:	f947b611 	ldr	x17, [x16, #3944]
    15d8:	913da210 	add	x16, x16, #0xf68
    15dc:	d61f0220 	br	x17

00000000000015e0 <strcpy@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15e4:	f947ba11 	ldr	x17, [x16, #3952]
    15e8:	913dc210 	add	x16, x16, #0xf70
    15ec:	d61f0220 	br	x17

00000000000015f0 <sysconf@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    15f4:	f947be11 	ldr	x17, [x16, #3960]
    15f8:	913de210 	add	x16, x16, #0xf78
    15fc:	d61f0220 	br	x17

0000000000001600 <strstr@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1604:	f947c211 	ldr	x17, [x16, #3968]
    1608:	913e0210 	add	x16, x16, #0xf80
    160c:	d61f0220 	br	x17

0000000000001610 <_Exit@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1614:	f947c611 	ldr	x17, [x16, #3976]
    1618:	913e2210 	add	x16, x16, #0xf88
    161c:	d61f0220 	br	x17

0000000000001620 <pthread_join@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1624:	f947ca11 	ldr	x17, [x16, #3984]
    1628:	913e4210 	add	x16, x16, #0xf90
    162c:	d61f0220 	br	x17

0000000000001630 <getenv@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1634:	f947ce11 	ldr	x17, [x16, #3992]
    1638:	913e6210 	add	x16, x16, #0xf98
    163c:	d61f0220 	br	x17

0000000000001640 <mprotect@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1644:	f947d211 	ldr	x17, [x16, #4000]
    1648:	913e8210 	add	x16, x16, #0xfa0
    164c:	d61f0220 	br	x17

0000000000001650 <fgets@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1654:	f947d611 	ldr	x17, [x16, #4008]
    1658:	913ea210 	add	x16, x16, #0xfa8
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_attr_setstacksize@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14c18>
    1664:	f947da11 	ldr	x17, [x16, #4016]
    1668:	913ec210 	add	x16, x16, #0xfb0
    166c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001680 <fwp_trap_overflow.constprop.0>:
    1680:	d10243ff 	sub	sp, sp, #0x90
    1684:	d2800c03 	mov	x3, #0x60                  	// #96
    1688:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    168c:	f947f421 	ldr	x1, [x1, #4072]
    1690:	90000045 	adrp	x5, 9000 <__modti3+0x260>
    1694:	a9077bfd 	stp	x29, x30, [sp, #112]
    1698:	9101c3fd 	add	x29, sp, #0x70
    169c:	910a80a5 	add	x5, x5, #0x2a0
    16a0:	90000044 	adrp	x4, 9000 <__modti3+0x260>
    16a4:	f90043f3 	str	x19, [sp, #128]
    16a8:	910aa084 	add	x4, x4, #0x2a8
    16ac:	910023f3 	add	x19, sp, #0x8
    16b0:	f9400022 	ldr	x2, [x1]
    16b4:	f90037e2 	str	x2, [sp, #104]
    16b8:	d2800002 	mov	x2, #0x0                   	// #0
    16bc:	aa0303e1 	mov	x1, x3
    16c0:	52800042 	mov	w2, #0x2                   	// #2
    16c4:	aa1303e0 	mov	x0, x19
    16c8:	97ffff52 	bl	1410 <__snprintf_chk@plt>
    16cc:	aa1303e0 	mov	x0, x19
    16d0:	94000274 	bl	20a0 <fwp_trap>
    16d4:	d503201f 	nop
    16d8:	d503201f 	nop
    16dc:	d503201f 	nop

00000000000016e0 <main>:
    16e0:	d10243ff 	sub	sp, sp, #0x90
    16e4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    16e8:	f947f400 	ldr	x0, [x0, #4072]
    16ec:	a9067bfd 	stp	x29, x30, [sp, #96]
    16f0:	910183fd 	add	x29, sp, #0x60
    16f4:	a90753f3 	stp	x19, x20, [sp, #112]
    16f8:	f00000f3 	adrp	x19, 20000 <__data_start>
    16fc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x14c18>
    1700:	f947ee94 	ldr	x20, [x20, #4056]
    1704:	f9400281 	ldr	x1, [x20]
    1708:	f90043f5 	str	x21, [sp, #128]
    170c:	f9400002 	ldr	x2, [x0]
    1710:	f9002fe2 	str	x2, [sp, #88]
    1714:	d2800002 	mov	x2, #0x0                   	// #0
    1718:	f9003a61 	str	x1, [x19, #112]
    171c:	94000271 	bl	20e0 <fwp_now_ns>
    1720:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    1724:	9113c000 	add	x0, x0, #0x4f0
    1728:	97ffffc2 	bl	1630 <getenv@plt>
    172c:	b4000080 	cbz	x0, 173c <main+0x5c>
    1730:	39400001 	ldrb	w1, [x0]
    1734:	aa0003f5 	mov	x21, x0
    1738:	35000801 	cbnz	w1, 1838 <main+0x158>
    173c:	910023e1 	add	x1, sp, #0x8
    1740:	52800000 	mov	w0, #0x0                   	// #0
    1744:	97ffff23 	bl	13d0 <clock_gettime@plt>
    1748:	35000900 	cbnz	w0, 1868 <main+0x188>
    174c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1750:	d2994003 	mov	x3, #0xca00                	// #51712
    1754:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1758:	9b037c01 	mul	x1, x0, x3
    175c:	9b437c00 	smulh	x0, x0, x3
    1760:	ab020021 	adds	x1, x1, x2
    1764:	937ffc42 	asr	x2, x2, #63
    1768:	9a020000 	adc	x0, x0, x2
    176c:	f100003f 	cmp	x1, #0x0
    1770:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1774:	b50009a0 	cbnz	x0, 18a8 <main+0x1c8>
    1778:	f9400280 	ldr	x0, [x20]
    177c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1780:	52800002 	mov	w2, #0x0                   	// #0
    1784:	d2800001 	mov	x1, #0x0                   	// #0
    1788:	910063f5 	add	x21, sp, #0x18
    178c:	97ffff15 	bl	13e0 <setvbuf@plt>
    1790:	d2800021 	mov	x1, #0x1                   	// #1
    1794:	528001a0 	mov	w0, #0xd                   	// #13
    1798:	97ffff1a 	bl	1400 <signal@plt>
    179c:	aa1503e0 	mov	x0, x21
    17a0:	97ffff04 	bl	13b0 <pthread_attr_init@plt>
    17a4:	350007c0 	cbnz	w0, 189c <main+0x1bc>
    17a8:	aa1503e0 	mov	x0, x21
    17ac:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17b0:	97ffffac 	bl	1660 <pthread_attr_setstacksize@plt>
    17b4:	35000680 	cbnz	w0, 1884 <main+0x1a4>
    17b8:	aa1503e1 	mov	x1, x21
    17bc:	910023e0 	add	x0, sp, #0x8
    17c0:	f0000022 	adrp	x2, 8000 <f0+0x21a0>
    17c4:	d2800003 	mov	x3, #0x0                   	// #0
    17c8:	91138042 	add	x2, x2, #0x4e0
    17cc:	97ffff79 	bl	15b0 <pthread_create@plt>
    17d0:	2a0003e1 	mov	w1, w0
    17d4:	aa1503e0 	mov	x0, x21
    17d8:	2a0103f5 	mov	w21, w1
    17dc:	97ffff1d 	bl	1450 <pthread_attr_destroy@plt>
    17e0:	350006a0 	cbnz	w0, 18b4 <main+0x1d4>
    17e4:	350004b5 	cbnz	w21, 1878 <main+0x198>
    17e8:	f94007e0 	ldr	x0, [sp, #8]
    17ec:	d2800001 	mov	x1, #0x0                   	// #0
    17f0:	97ffff8c 	bl	1620 <pthread_join@plt>
    17f4:	35000600 	cbnz	w0, 18b4 <main+0x1d4>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	9101c273 	add	x19, x19, #0x70
    1800:	97ffff74 	bl	15d0 <fflush@plt>
    1804:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    1808:	f947f421 	ldr	x1, [x1, #4072]
    180c:	b942a260 	ldr	w0, [x19, #672]
    1810:	f9402fe3 	ldr	x3, [sp, #88]
    1814:	f9400022 	ldr	x2, [x1]
    1818:	eb020063 	subs	x3, x3, x2
    181c:	d2800002 	mov	x2, #0x0                   	// #0
    1820:	540002a1 	b.ne	1874 <main+0x194>  // b.any
    1824:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1828:	a94753f3 	ldp	x19, x20, [sp, #112]
    182c:	f94043f5 	ldr	x21, [sp, #128]
    1830:	910243ff 	add	sp, sp, #0x90
    1834:	d65f03c0 	ret
    1838:	910003e1 	mov	x1, sp
    183c:	52800142 	mov	w2, #0xa                   	// #10
    1840:	97ffff54 	bl	1590 <strtoull@plt>
    1844:	f94003e0 	ldr	x0, [sp]
    1848:	39400000 	ldrb	w0, [x0]
    184c:	35fff780 	cbnz	w0, 173c <main+0x5c>
    1850:	394002a0 	ldrb	w0, [x21]
    1854:	52801fa1 	mov	w1, #0xfd                  	// #253
    1858:	5100ac00 	sub	w0, w0, #0x2b
    185c:	6a01001f 	tst	w0, w1
    1860:	54fff6e0 	b.eq	173c <main+0x5c>  // b.none
    1864:	17ffffc5 	b	1778 <main+0x98>
    1868:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    186c:	91140000 	add	x0, x0, #0x500
    1870:	9400020c 	bl	20a0 <fwp_trap>
    1874:	97ffff0b 	bl	14a0 <__stack_chk_fail@plt>
    1878:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    187c:	91168000 	add	x0, x0, #0x5a0
    1880:	94000208 	bl	20a0 <fwp_trap>
    1884:	aa1503e0 	mov	x0, x21
    1888:	97fffef2 	bl	1450 <pthread_attr_destroy@plt>
    188c:	35000140 	cbnz	w0, 18b4 <main+0x1d4>
    1890:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    1894:	9115e000 	add	x0, x0, #0x578
    1898:	94000202 	bl	20a0 <fwp_trap>
    189c:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    18a0:	91152000 	add	x0, x0, #0x548
    18a4:	940001ff 	bl	20a0 <fwp_trap>
    18a8:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    18ac:	91148000 	add	x0, x0, #0x520
    18b0:	940001fc 	bl	20a0 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <abort@plt>
    18b8:	d503201f 	nop
    18bc:	d503201f 	nop

00000000000018c0 <_start>:
    18c0:	d503201f 	nop
    18c4:	d280001d 	mov	x29, #0x0                   	// #0
    18c8:	d280001e 	mov	x30, #0x0                   	// #0
    18cc:	aa0003e5 	mov	x5, x0
    18d0:	f94003e1 	ldr	x1, [sp]
    18d4:	910023e2 	add	x2, sp, #0x8
    18d8:	910003e6 	mov	x6, sp
    18dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    18e0:	f947f800 	ldr	x0, [x0, #4080]
    18e4:	d2800003 	mov	x3, #0x0                   	// #0
    18e8:	d2800004 	mov	x4, #0x0                   	// #0
    18ec:	97fffe9d 	bl	1360 <__libc_start_main@plt>
    18f0:	97ffff00 	bl	14f0 <abort@plt>

00000000000018f4 <call_weak_fn>:
    18f4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    18f8:	f947f000 	ldr	x0, [x0, #4064]
    18fc:	b4000040 	cbz	x0, 1904 <call_weak_fn+0x10>
    1900:	17fffef4 	b	14d0 <__gmon_start__@plt>
    1904:	d65f03c0 	ret
    1908:	d503201f 	nop
    190c:	d503201f 	nop

0000000000001910 <deregister_tm_clones>:
    1910:	f00000e0 	adrp	x0, 20000 <__data_start>
    1914:	91016000 	add	x0, x0, #0x58
    1918:	f00000e1 	adrp	x1, 20000 <__data_start>
    191c:	91016021 	add	x1, x1, #0x58
    1920:	eb00003f 	cmp	x1, x0
    1924:	540000c0 	b.eq	193c <deregister_tm_clones+0x2c>  // b.none
    1928:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    192c:	f947e021 	ldr	x1, [x1, #4032]
    1930:	b4000061 	cbz	x1, 193c <deregister_tm_clones+0x2c>
    1934:	aa0103f0 	mov	x16, x1
    1938:	d61f0200 	br	x16
    193c:	d65f03c0 	ret

0000000000001940 <register_tm_clones>:
    1940:	f00000e0 	adrp	x0, 20000 <__data_start>
    1944:	91016000 	add	x0, x0, #0x58
    1948:	f00000e1 	adrp	x1, 20000 <__data_start>
    194c:	91016021 	add	x1, x1, #0x58
    1950:	cb000021 	sub	x1, x1, x0
    1954:	d37ffc22 	lsr	x2, x1, #63
    1958:	8b810c41 	add	x1, x2, x1, asr #3
    195c:	9341fc21 	asr	x1, x1, #1
    1960:	b40000c1 	cbz	x1, 1978 <register_tm_clones+0x38>
    1964:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14c18>
    1968:	f947fc42 	ldr	x2, [x2, #4088]
    196c:	b4000062 	cbz	x2, 1978 <register_tm_clones+0x38>
    1970:	aa0203f0 	mov	x16, x2
    1974:	d61f0200 	br	x16
    1978:	d65f03c0 	ret
    197c:	d503201f 	nop

0000000000001980 <__do_global_dtors_aux>:
    1980:	d503233f 	paciasp
    1984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1988:	910003fd 	mov	x29, sp
    198c:	f9000bf3 	str	x19, [sp, #16]
    1990:	f00000f3 	adrp	x19, 20000 <__data_start>
    1994:	39418260 	ldrb	w0, [x19, #96]
    1998:	37000140 	tbnz	w0, #0, 19c0 <__do_global_dtors_aux+0x40>
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    19a0:	f947e400 	ldr	x0, [x0, #4040]
    19a4:	b4000080 	cbz	x0, 19b4 <__do_global_dtors_aux+0x34>
    19a8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ac:	f9400400 	ldr	x0, [x0, #8]
    19b0:	97fffe78 	bl	1390 <__cxa_finalize@plt>
    19b4:	97ffffd7 	bl	1910 <deregister_tm_clones>
    19b8:	52800020 	mov	w0, #0x1                   	// #1
    19bc:	39018260 	strb	w0, [x19, #96]
    19c0:	f9400bf3 	ldr	x19, [sp, #16]
    19c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19c8:	d50323bf 	autiasp
    19cc:	d65f03c0 	ret

00000000000019d0 <frame_dummy>:
    19d0:	d503245f 	bti	c
    19d4:	17ffffdb 	b	1940 <register_tm_clones>
    19d8:	d503201f 	nop
    19dc:	d503201f 	nop

00000000000019e0 <fwp_fmt_u128>:
    19e0:	d10183ff 	sub	sp, sp, #0x60
    19e4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    19e8:	f947f421 	ldr	x1, [x1, #4072]
    19ec:	a9057bfd 	stp	x29, x30, [sp, #80]
    19f0:	910143fd 	add	x29, sp, #0x50
    19f4:	f9400024 	ldr	x4, [x1]
    19f8:	f90027e4 	str	x4, [sp, #72]
    19fc:	d2800004 	mov	x4, #0x0                   	// #0
    1a00:	aa030041 	orr	x1, x2, x3
    1a04:	b5000361 	cbnz	x1, 1a70 <fwp_fmt_u128+0x90>
    1a08:	910023e9 	add	x9, sp, #0x8
    1a0c:	52800601 	mov	w1, #0x30                  	// #48
    1a10:	5280002d 	mov	w13, #0x1                   	// #1
    1a14:	390023e1 	strb	w1, [sp, #8]
    1a18:	93407dad 	sxtw	x13, w13
    1a1c:	aa0d03e1 	mov	x1, x13
    1a20:	8b0d0004 	add	x4, x0, x13
    1a24:	d503201f 	nop
    1a28:	8b010123 	add	x3, x9, x1
    1a2c:	cb0103e2 	neg	x2, x1
    1a30:	d1000421 	sub	x1, x1, #0x1
    1a34:	385ff063 	ldurb	w3, [x3, #-1]
    1a38:	38226883 	strb	w3, [x4, x2]
    1a3c:	35ffff61 	cbnz	w1, 1a28 <fwp_fmt_u128+0x48>
    1a40:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    1a44:	f947f421 	ldr	x1, [x1, #4072]
    1a48:	382d681f 	strb	wzr, [x0, x13]
    1a4c:	aa0103e0 	mov	x0, x1
    1a50:	f94027e2 	ldr	x2, [sp, #72]
    1a54:	f9400001 	ldr	x1, [x0]
    1a58:	eb010042 	subs	x2, x2, x1
    1a5c:	d2800001 	mov	x1, #0x0                   	// #0
    1a60:	54000561 	b.ne	1b0c <fwp_fmt_u128+0x12c>  // b.any
    1a64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1a68:	910183ff 	add	sp, sp, #0x60
    1a6c:	d65f03c0 	ret
    1a70:	90000041 	adrp	x1, 9000 <__modti3+0x260>
    1a74:	91194021 	add	x1, x1, #0x650
    1a78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1a7c:	910023e9 	add	x9, sp, #0x8
    1a80:	d2800027 	mov	x7, #0x1                   	// #1
    1a84:	f29999af 	movk	x15, #0xcccd
    1a88:	a9402826 	ldp	x6, x10, [x1]
    1a8c:	d503201f 	nop
    1a90:	ab030041 	adds	x1, x2, x3
    1a94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1a98:	aa0303eb 	mov	x11, x3
    1a9c:	8b070128 	add	x8, x9, x7
    1aa0:	aa0203ee 	mov	x14, x2
    1aa4:	aa0703ed 	mov	x13, x7
    1aa8:	910004e7 	add	x7, x7, #0x1
    1aac:	9bcf7c24 	umulh	x4, x1, x15
    1ab0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1ab4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1ab8:	cb040021 	sub	x1, x1, x4
    1abc:	eb010041 	subs	x1, x2, x1
    1ac0:	da1f0063 	sbc	x3, x3, xzr
    1ac4:	9bc67c24 	umulh	x4, x1, x6
    1ac8:	9b061064 	madd	x4, x3, x6, x4
    1acc:	9b067c2c 	mul	x12, x1, x6
    1ad0:	9b0a1024 	madd	x4, x1, x10, x4
    1ad4:	9bc67c25 	umulh	x5, x1, x6
    1ad8:	9b061465 	madd	x5, x3, x6, x5
    1adc:	9b0a1425 	madd	x5, x1, x10, x5
    1ae0:	93cc0484 	extr	x4, x4, x12, #1
    1ae4:	8b040884 	add	x4, x4, x4, lsl #2
    1ae8:	d341fca3 	lsr	x3, x5, #1
    1aec:	cb040444 	sub	x4, x2, x4, lsl #1
    1af0:	93cc04a2 	extr	x2, x5, x12, #1
    1af4:	1100c084 	add	w4, w4, #0x30
    1af8:	381ff104 	sturb	w4, [x8, #-1]
    1afc:	b5fffcab 	cbnz	x11, 1a90 <fwp_fmt_u128+0xb0>
    1b00:	f10025df 	cmp	x14, #0x9
    1b04:	54fffc68 	b.hi	1a90 <fwp_fmt_u128+0xb0>  // b.pmore
    1b08:	17ffffc4 	b	1a18 <fwp_fmt_u128+0x38>
    1b0c:	97fffe65 	bl	14a0 <__stack_chk_fail@plt>

0000000000001b10 <fwp_range_release>:
    1b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b14:	910003fd 	mov	x29, sp
    1b18:	f9400801 	ldr	x1, [x0, #16]
    1b1c:	f9000bf3 	str	x19, [sp, #16]
    1b20:	aa0003f3 	mov	x19, x0
    1b24:	b4000061 	cbz	x1, 1b30 <fwp_range_release+0x20>
    1b28:	f9400400 	ldr	x0, [x0, #8]
    1b2c:	d63f0020 	blr	x1
    1b30:	f9400260 	ldr	x0, [x19]
    1b34:	f9400e61 	ldr	x1, [x19, #24]
    1b38:	f9400bf3 	ldr	x19, [sp, #16]
    1b3c:	aa0103f0 	mov	x16, x1
    1b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b44:	d61f0200 	br	x16
    1b48:	d503201f 	nop
    1b4c:	d503201f 	nop

0000000000001b50 <fwp_flush>:
    1b50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1b54:	f9403800 	ldr	x0, [x0, #112]
    1b58:	b4000120 	cbz	x0, 1b7c <fwp_flush+0x2c>
    1b5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b60:	910003fd 	mov	x29, sp
    1b64:	97fffe9b 	bl	15d0 <fflush@plt>
    1b68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    1b6c:	f947ec00 	ldr	x0, [x0, #4056]
    1b70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1b74:	f9400000 	ldr	x0, [x0]
    1b78:	17fffe96 	b	15d0 <fflush@plt>
    1b7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    1b80:	f947ec00 	ldr	x0, [x0, #4056]
    1b84:	f9400000 	ldr	x0, [x0]
    1b88:	17fffe92 	b	15d0 <fflush@plt>
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_heap_oom>:
    1b90:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14c18>
    1b94:	f947e863 	ldr	x3, [x3, #4048]
    1b98:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b9c:	d2800262 	mov	x2, #0x13                  	// #19
    1ba0:	910003fd 	mov	x29, sp
    1ba4:	f9400063 	ldr	x3, [x3]
    1ba8:	d2800021 	mov	x1, #0x1                   	// #1
    1bac:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    1bb0:	91052000 	add	x0, x0, #0x148
    1bb4:	97fffe7b 	bl	15a0 <fwrite@plt>
    1bb8:	d2800000 	mov	x0, #0x0                   	// #0
    1bbc:	97fffe85 	bl	15d0 <fflush@plt>
    1bc0:	52800cc0 	mov	w0, #0x66                  	// #102
    1bc4:	97fffe93 	bl	1610 <_Exit@plt>
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_segv>:
    1bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1bd4:	f00000e2 	adrp	x2, 20000 <__data_start>
    1bd8:	9101c043 	add	x3, x2, #0x70
    1bdc:	910003fd 	mov	x29, sp
    1be0:	a90153f3 	stp	x19, x20, [sp, #16]
    1be4:	2a0003f3 	mov	w19, w0
    1be8:	f9400460 	ldr	x0, [x3, #8]
    1bec:	f90013f5 	str	x21, [sp, #32]
    1bf0:	f9400835 	ldr	x21, [x1, #16]
    1bf4:	b4000280 	cbz	x0, 1c44 <fwp_segv+0x74>
    1bf8:	f9400814 	ldr	x20, [x0, #16]
    1bfc:	b4000254 	cbz	x20, 1c44 <fwp_segv+0x74>
    1c00:	528003c0 	mov	w0, #0x1e                  	// #30
    1c04:	97fffe7b 	bl	15f0 <sysconf@plt>
    1c08:	f144029f 	cmp	x20, #0x100, lsl #12
    1c0c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c10:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c14:	8b000294 	add	x20, x20, x0
    1c18:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c1c:	eb0102bf 	cmp	x21, x1
    1c20:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c24:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c28:	35000240 	cbnz	w0, 1c70 <fwp_segv+0xa0>
    1c2c:	f94013f5 	ldr	x21, [sp, #32]
    1c30:	2a1303e0 	mov	w0, w19
    1c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c38:	d2800001 	mov	x1, #0x0                   	// #0
    1c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c40:	17fffdf0 	b	1400 <signal@plt>
    1c44:	9101c042 	add	x2, x2, #0x70
    1c48:	f9400840 	ldr	x0, [x2, #16]
    1c4c:	b4ffff00 	cbz	x0, 1c2c <fwp_segv+0x5c>
    1c50:	f9400c41 	ldr	x1, [x2, #24]
    1c54:	cb010000 	sub	x0, x0, x1
    1c58:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c5c:	91440000 	add	x0, x0, #0x100, lsl #12
    1c60:	eb15003f 	cmp	x1, x21
    1c64:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1c68:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c6c:	34fffe00 	cbz	w0, 1c2c <fwp_segv+0x5c>
    1c70:	97ffffb8 	bl	1b50 <fwp_flush>
    1c74:	90000041 	adrp	x1, 9000 <__modti3+0x260>
    1c78:	9118c021 	add	x1, x1, #0x630
    1c7c:	d2800342 	mov	x2, #0x1a                  	// #26
    1c80:	52800040 	mov	w0, #0x2                   	// #2
    1c84:	97fffe17 	bl	14e0 <write@plt>
    1c88:	52800ca0 	mov	w0, #0x65                  	// #101
    1c8c:	97fffda5 	bl	1320 <_exit@plt>

0000000000001c90 <fwp_heap_chunks>:
    1c90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c94:	910003fd 	mov	x29, sp
    1c98:	a90153f3 	stp	x19, x20, [sp, #16]
    1c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ca0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    1ca4:	911442a1 	add	x1, x21, #0x510
    1ca8:	f100041f 	cmp	x0, #0x1
    1cac:	54000ca0 	b.eq	1e40 <fwp_heap_chunks+0x1b0>  // b.none
    1cb0:	f949f822 	ldr	x2, [x1, #5104]
    1cb4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1cb8:	912400a5 	add	x5, x5, #0x900
    1cbc:	911442a1 	add	x1, x21, #0x510
    1cc0:	f949ec34 	ldr	x20, [x1, #5080]
    1cc4:	eb14005f 	cmp	x2, x20
    1cc8:	54000c42 	b.cs	1e50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1ccc:	f949fc23 	ldr	x3, [x1, #5112]
    1cd0:	8b020841 	add	x1, x2, x2, lsl #2
    1cd4:	d2800004 	mov	x4, #0x0                   	// #0
    1cd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1cdc:	14000009 	b	1d00 <fwp_heap_chunks+0x70>
    1ce0:	91000483 	add	x3, x4, #0x1
    1ce4:	eb03001f 	cmp	x0, x3
    1ce8:	54000940 	b.eq	1e10 <fwp_heap_chunks+0x180>  // b.none
    1cec:	91000442 	add	x2, x2, #0x1
    1cf0:	aa0303e4 	mov	x4, x3
    1cf4:	9100a021 	add	x1, x1, #0x28
    1cf8:	eb02029f 	cmp	x20, x2
    1cfc:	54000100 	b.eq	1d1c <fwp_heap_chunks+0x8c>  // b.none
    1d00:	39400023 	ldrb	w3, [x1]
    1d04:	34fffee3 	cbz	w3, 1ce0 <fwp_heap_chunks+0x50>
    1d08:	91000442 	add	x2, x2, #0x1
    1d0c:	9100a021 	add	x1, x1, #0x28
    1d10:	d2800004 	mov	x4, #0x0                   	// #0
    1d14:	eb02029f 	cmp	x20, x2
    1d18:	54ffff41 	b.ne	1d00 <fwp_heap_chunks+0x70>  // b.any
    1d1c:	cb040294 	sub	x20, x20, x4
    1d20:	f9001bf7 	str	x23, [sp, #48]
    1d24:	911442b7 	add	x23, x21, #0x510
    1d28:	8b140013 	add	x19, x0, x20
    1d2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1d30:	f949f2e0 	ldr	x0, [x23, #5088]
    1d34:	cb040021 	sub	x1, x1, x4
    1d38:	f90a1ae1 	str	x1, [x23, #5168]
    1d3c:	eb00027f 	cmp	x19, x0
    1d40:	54000429 	b.ls	1dc4 <fwp_heap_chunks+0x134>  // b.plast
    1d44:	f949eae1 	ldr	x1, [x23, #5072]
    1d48:	eb01027f 	cmp	x19, x1
    1d4c:	54000888 	b.hi	1e5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1d50:	91010276 	add	x22, x19, #0x40
    1d54:	52800062 	mov	w2, #0x3                   	// #3
    1d58:	f949dae3 	ldr	x3, [x23, #5040]
    1d5c:	eb0102df 	cmp	x22, x1
    1d60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1d64:	cb0002c1 	sub	x1, x22, x0
    1d68:	8b004060 	add	x0, x3, x0, lsl #16
    1d6c:	d370bc21 	lsl	x1, x1, #16
    1d70:	97fffe34 	bl	1640 <mprotect@plt>
    1d74:	35000740 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1d78:	528003c0 	mov	w0, #0x1e                  	// #30
    1d7c:	97fffe1d 	bl	15f0 <sysconf@plt>
    1d80:	f949f2e2 	ldr	x2, [x23, #5088]
    1d84:	cb0003e5 	neg	x5, x0
    1d88:	aa0003e4 	mov	x4, x0
    1d8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1d90:	f949fee0 	ldr	x0, [x23, #5112]
    1d94:	8b020843 	add	x3, x2, x2, lsl #2
    1d98:	52800062 	mov	w2, #0x3                   	// #3
    1d9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1da0:	8b030c03 	add	x3, x0, x3, lsl #3
    1da4:	d1000421 	sub	x1, x1, #0x1
    1da8:	8a050060 	and	x0, x3, x5
    1dac:	8b040021 	add	x1, x1, x4
    1db0:	8a050021 	and	x1, x1, x5
    1db4:	cb000021 	sub	x1, x1, x0
    1db8:	97fffe22 	bl	1640 <mprotect@plt>
    1dbc:	35000500 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1dc0:	f909f2f6 	str	x22, [x23, #5088]
    1dc4:	911442b5 	add	x21, x21, #0x510
    1dc8:	d370be60 	lsl	x0, x19, #16
    1dcc:	f949e6a1 	ldr	x1, [x21, #5064]
    1dd0:	f909eeb3 	str	x19, [x21, #5080]
    1dd4:	eb01001f 	cmp	x0, x1
    1dd8:	540000e8 	b.hi	1df4 <fwp_heap_chunks+0x164>  // b.pmore
    1ddc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1de0:	aa1403e0 	mov	x0, x20
    1de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1de8:	f9401bf7 	ldr	x23, [sp, #48]
    1dec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1df0:	d65f03c0 	ret
    1df4:	f9401bf7 	ldr	x23, [sp, #48]
    1df8:	f909e6a0 	str	x0, [x21, #5064]
    1dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e00:	aa1403e0 	mov	x0, x20
    1e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e0c:	d65f03c0 	ret
    1e10:	911442b5 	add	x21, x21, #0x510
    1e14:	91000441 	add	x1, x2, #0x1
    1e18:	f90000a1 	str	x1, [x5]
    1e1c:	cb040054 	sub	x20, x2, x4
    1e20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1e24:	cb000020 	sub	x0, x1, x0
    1e28:	f90a1aa0 	str	x0, [x21, #5168]
    1e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e30:	aa1403e0 	mov	x0, x20
    1e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e3c:	d65f03c0 	ret
    1e40:	f949f422 	ldr	x2, [x1, #5096]
    1e44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1e48:	9123e0a5 	add	x5, x5, #0x8f8
    1e4c:	17ffff9c 	b	1cbc <fwp_heap_chunks+0x2c>
    1e50:	d2800004 	mov	x4, #0x0                   	// #0
    1e54:	f9001bf7 	str	x23, [sp, #48]
    1e58:	17ffffb3 	b	1d24 <fwp_heap_chunks+0x94>
    1e5c:	97ffff4d 	bl	1b90 <fwp_heap_oom>

0000000000001e60 <buf_grow>:
    1e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1e64:	910003fd 	mov	x29, sp
    1e68:	a90153f3 	stp	x19, x20, [sp, #16]
    1e6c:	aa0003f4 	mov	x20, x0
    1e70:	f9400400 	ldr	x0, [x0, #8]
    1e74:	b100041f 	cmn	x0, #0x1
    1e78:	54000400 	b.eq	1ef8 <buf_grow+0x98>  // b.none
    1e7c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1e80:	cb000042 	sub	x2, x2, x0
    1e84:	eb01005f 	cmp	x2, x1
    1e88:	54000383 	b.cc	1ef8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1e8c:	f9400a82 	ldr	x2, [x20, #16]
    1e90:	91000421 	add	x1, x1, #0x1
    1e94:	8b000033 	add	x19, x1, x0
    1e98:	eb13005f 	cmp	x2, x19
    1e9c:	54000242 	b.cs	1ee4 <buf_grow+0x84>  // b.hs, b.nlast
    1ea0:	f100005f 	cmp	x2, #0x0
    1ea4:	b5000262 	cbnz	x2, 1ef0 <buf_grow+0x90>
    1ea8:	d2800802 	mov	x2, #0x40                  	// #64
    1eac:	eb02027f 	cmp	x19, x2
    1eb0:	54000068 	b.hi	1ebc <buf_grow+0x5c>  // b.pmore
    1eb4:	14000005 	b	1ec8 <buf_grow+0x68>
    1eb8:	b7f800a2 	tbnz	x2, #63, 1ecc <buf_grow+0x6c>
    1ebc:	d37ff842 	lsl	x2, x2, #1
    1ec0:	eb02027f 	cmp	x19, x2
    1ec4:	54ffffa8 	b.hi	1eb8 <buf_grow+0x58>  // b.pmore
    1ec8:	aa0203f3 	mov	x19, x2
    1ecc:	f9400280 	ldr	x0, [x20]
    1ed0:	aa1303e1 	mov	x1, x19
    1ed4:	97fffd6f 	bl	1490 <realloc@plt>
    1ed8:	b4000100 	cbz	x0, 1ef8 <buf_grow+0x98>
    1edc:	f9000280 	str	x0, [x20]
    1ee0:	f9000a93 	str	x19, [x20, #16]
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1eec:	d65f03c0 	ret
    1ef0:	54fffe6a 	b.ge	1ebc <buf_grow+0x5c>  // b.tcont
    1ef4:	17fffff6 	b	1ecc <buf_grow+0x6c>
    1ef8:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14c18>
    1efc:	f947e863 	ldr	x3, [x3, #4048]
    1f00:	d2800262 	mov	x2, #0x13                  	// #19
    1f04:	d2800021 	mov	x1, #0x1                   	// #1
    1f08:	90000040 	adrp	x0, 9000 <__modti3+0x260>
    1f0c:	91052000 	add	x0, x0, #0x148
    1f10:	f9400063 	ldr	x3, [x3]
    1f14:	97fffda3 	bl	15a0 <fwrite@plt>
    1f18:	d2800000 	mov	x0, #0x0                   	// #0
    1f1c:	97fffdad 	bl	15d0 <fflush@plt>
    1f20:	52800cc0 	mov	w0, #0x66                  	// #102
    1f24:	97fffdbb 	bl	1610 <_Exit@plt>
    1f28:	d503201f 	nop
    1f2c:	d503201f 	nop

0000000000001f30 <buf_put>:
    1f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1f34:	910003fd 	mov	x29, sp
    1f38:	a90153f3 	stp	x19, x20, [sp, #16]
    1f3c:	aa0003f4 	mov	x20, x0
    1f40:	aa0203f3 	mov	x19, x2
    1f44:	f90013f5 	str	x21, [sp, #32]
    1f48:	aa0103f5 	mov	x21, x1
    1f4c:	aa0203e1 	mov	x1, x2
    1f50:	97ffffc4 	bl	1e60 <buf_grow>
    1f54:	a9400283 	ldp	x3, x0, [x20]
    1f58:	aa1503e1 	mov	x1, x21
    1f5c:	aa1303e2 	mov	x2, x19
    1f60:	8b000060 	add	x0, x3, x0
    1f64:	97fffce7 	bl	1300 <memcpy@plt>
    1f68:	a9400680 	ldp	x0, x1, [x20]
    1f6c:	8b010273 	add	x19, x19, x1
    1f70:	f9000693 	str	x19, [x20, #8]
    1f74:	3833681f 	strb	wzr, [x0, x19]
    1f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f7c:	f94013f5 	ldr	x21, [sp, #32]
    1f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1f84:	d65f03c0 	ret
    1f88:	d503201f 	nop
    1f8c:	d503201f 	nop

0000000000001f90 <fwp_cancel_tree.part.0>:
    1f90:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f94:	9101c022 	add	x2, x1, #0x70
    1f98:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1f9c:	52800023 	mov	w3, #0x1                   	// #1
    1fa0:	910003fd 	mov	x29, sp
    1fa4:	f9400444 	ldr	x4, [x2, #8]
    1fa8:	f9000bf3 	str	x19, [sp, #16]
    1fac:	39014403 	strb	w3, [x0, #81]
    1fb0:	eb04001f 	cmp	x0, x4
    1fb4:	54000160 	b.eq	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.none
    1fb8:	f9402804 	ldr	x4, [x0, #80]
    1fbc:	f2001c9f 	tst	x4, #0xff000000ff
    1fc0:	54000101 	b.ne	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.any
    1fc4:	f9401044 	ldr	x4, [x2, #32]
    1fc8:	39015003 	strb	w3, [x0, #84]
    1fcc:	f900801f 	str	xzr, [x0, #256]
    1fd0:	b40001e4 	cbz	x4, 200c <fwp_cancel_tree.part.0+0x7c>
    1fd4:	f9008080 	str	x0, [x4, #256]
    1fd8:	9101c021 	add	x1, x1, #0x70
    1fdc:	f9001020 	str	x0, [x1, #32]
    1fe0:	f9401413 	ldr	x19, [x0, #40]
    1fe4:	b40000f3 	cbz	x19, 2000 <fwp_cancel_tree.part.0+0x70>
    1fe8:	39414261 	ldrb	w1, [x19, #80]
    1fec:	aa1303e0 	mov	x0, x19
    1ff0:	37000041 	tbnz	w1, #0, 1ff8 <fwp_cancel_tree.part.0+0x68>
    1ff4:	97ffffe7 	bl	1f90 <fwp_cancel_tree.part.0>
    1ff8:	f9401a73 	ldr	x19, [x19, #48]
    1ffc:	b5ffff73 	cbnz	x19, 1fe8 <fwp_cancel_tree.part.0+0x58>
    2000:	f9400bf3 	ldr	x19, [sp, #16]
    2004:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2008:	d65f03c0 	ret
    200c:	f9001440 	str	x0, [x2, #40]
    2010:	17fffff2 	b	1fd8 <fwp_cancel_tree.part.0+0x48>

0000000000002014 <fwp_finish_float>:
    2014:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2018:	528005c1 	mov	w1, #0x2e                  	// #46
    201c:	910003fd 	mov	x29, sp
    2020:	f9000bf3 	str	x19, [sp, #16]
    2024:	aa0003f3 	mov	x19, x0
    2028:	97fffd56 	bl	1580 <strchr@plt>
    202c:	b4000080 	cbz	x0, 203c <fwp_finish_float+0x28>
    2030:	f9400bf3 	ldr	x19, [sp, #16]
    2034:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2038:	d65f03c0 	ret
    203c:	aa1303e0 	mov	x0, x19
    2040:	52800ca1 	mov	w1, #0x65                  	// #101
    2044:	97fffd4f 	bl	1580 <strchr@plt>
    2048:	b5ffff40 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    204c:	f0000021 	adrp	x1, 9000 <__modti3+0x260>
    2050:	aa1303e0 	mov	x0, x19
    2054:	91058021 	add	x1, x1, #0x160
    2058:	97fffd6a 	bl	1600 <strstr@plt>
    205c:	b5fffea0 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2060:	f0000021 	adrp	x1, 9000 <__modti3+0x260>
    2064:	aa1303e0 	mov	x0, x19
    2068:	9105a021 	add	x1, x1, #0x168
    206c:	97fffd65 	bl	1600 <strstr@plt>
    2070:	b5fffe00 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2074:	aa1303e0 	mov	x0, x19
    2078:	97fffcae 	bl	1330 <strlen@plt>
    207c:	f0000021 	adrp	x1, 9000 <__modti3+0x260>
    2080:	9105c021 	add	x1, x1, #0x170
    2084:	8b000262 	add	x2, x19, x0
    2088:	79400023 	ldrh	w3, [x1]
    208c:	39400821 	ldrb	w1, [x1, #2]
    2090:	78206a63 	strh	w3, [x19, x0]
    2094:	39000841 	strb	w1, [x2, #2]
    2098:	17ffffe6 	b	2030 <fwp_finish_float+0x1c>
    209c:	d503201f 	nop

00000000000020a0 <fwp_trap>:
    20a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20a4:	910003fd 	mov	x29, sp
    20a8:	f9000bf3 	str	x19, [sp, #16]
    20ac:	aa0003f3 	mov	x19, x0
    20b0:	97fffea8 	bl	1b50 <fwp_flush>
    20b4:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14c18>
    20b8:	f947e884 	ldr	x4, [x4, #4048]
    20bc:	aa1303e3 	mov	x3, x19
    20c0:	f0000022 	adrp	x2, 9000 <__modti3+0x260>
    20c4:	9105e042 	add	x2, x2, #0x178
    20c8:	52800041 	mov	w1, #0x2                   	// #2
    20cc:	f9400080 	ldr	x0, [x4]
    20d0:	97fffd10 	bl	1510 <__fprintf_chk@plt>
    20d4:	52800ca0 	mov	w0, #0x65                  	// #101
    20d8:	97fffc9e 	bl	1350 <exit@plt>
    20dc:	d503201f 	nop

00000000000020e0 <fwp_now_ns>:
    20e0:	d100c3ff 	sub	sp, sp, #0x30
    20e4:	52800020 	mov	w0, #0x1                   	// #1
    20e8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14c18>
    20ec:	f947f442 	ldr	x2, [x2, #4072]
    20f0:	910023e1 	add	x1, sp, #0x8
    20f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    20f8:	910083fd 	add	x29, sp, #0x20
    20fc:	f9400043 	ldr	x3, [x2]
    2100:	f9000fe3 	str	x3, [sp, #24]
    2104:	d2800003 	mov	x3, #0x0                   	// #0
    2108:	97fffcb2 	bl	13d0 <clock_gettime@plt>
    210c:	350002c0 	cbnz	w0, 2164 <fwp_now_ns+0x84>
    2110:	a9408be1 	ldp	x1, x2, [sp, #8]
    2114:	d2994003 	mov	x3, #0xca00                	// #51712
    2118:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    211c:	9b037c20 	mul	x0, x1, x3
    2120:	9b437c21 	smulh	x1, x1, x3
    2124:	ab020000 	adds	x0, x0, x2
    2128:	937ffc42 	asr	x2, x2, #63
    212c:	9a020021 	adc	x1, x1, x2
    2130:	f100001f 	cmp	x0, #0x0
    2134:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2138:	b50001e1 	cbnz	x1, 2174 <fwp_now_ns+0x94>
    213c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    2140:	f947f421 	ldr	x1, [x1, #4072]
    2144:	f9400fe3 	ldr	x3, [sp, #24]
    2148:	f9400022 	ldr	x2, [x1]
    214c:	eb020063 	subs	x3, x3, x2
    2150:	d2800002 	mov	x2, #0x0                   	// #0
    2154:	540000e1 	b.ne	2170 <fwp_now_ns+0x90>  // b.any
    2158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    215c:	9100c3ff 	add	sp, sp, #0x30
    2160:	d65f03c0 	ret
    2164:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    2168:	91062000 	add	x0, x0, #0x188
    216c:	97ffffcd 	bl	20a0 <fwp_trap>
    2170:	97fffccc 	bl	14a0 <__stack_chk_fail@plt>
    2174:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    2178:	9106a000 	add	x0, x0, #0x1a8
    217c:	97ffffc9 	bl	20a0 <fwp_trap>

0000000000002180 <fwp_format_g.constprop.0>:
    2180:	d10483ff 	sub	sp, sp, #0x120
    2184:	f0000024 	adrp	x4, 9000 <__modti3+0x260>
    2188:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14c18>
    218c:	f947f442 	ldr	x2, [x2, #4072]
    2190:	91074084 	add	x4, x4, #0x1d0
    2194:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2198:	9102c3fd 	add	x29, sp, #0xb0
    219c:	d2800803 	mov	x3, #0x40                  	// #64
    21a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    21a4:	93407c38 	sxtw	x24, w1
    21a8:	aa0303e1 	mov	x1, x3
    21ac:	fd008be8 	str	d8, [sp, #272]
    21b0:	1e604008 	fmov	d8, d0
    21b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    21b8:	910083f4 	add	x20, sp, #0x20
    21bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    21c0:	aa0003f5 	mov	x21, x0
    21c4:	a91073fb 	stp	x27, x28, [sp, #256]
    21c8:	5100071c 	sub	w28, w24, #0x1
    21cc:	2a1c03e5 	mov	w5, w28
    21d0:	f9400040 	ldr	x0, [x2]
    21d4:	f90057e0 	str	x0, [sp, #168]
    21d8:	d2800000 	mov	x0, #0x0                   	// #0
    21dc:	52800042 	mov	w2, #0x2                   	// #2
    21e0:	aa1403e0 	mov	x0, x20
    21e4:	97fffc8b 	bl	1410 <__snprintf_chk@plt>
    21e8:	52800ca1 	mov	w1, #0x65                  	// #101
    21ec:	aa1403e0 	mov	x0, x20
    21f0:	97fffce4 	bl	1580 <strchr@plt>
    21f4:	aa0003f3 	mov	x19, x0
    21f8:	52800142 	mov	w2, #0xa                   	// #10
    21fc:	91000400 	add	x0, x0, #0x1
    2200:	d2800001 	mov	x1, #0x0                   	// #0
    2204:	97fffccf 	bl	1540 <strtol@plt>
    2208:	aa0003f7 	mov	x23, x0
    220c:	11001400 	add	w0, w0, #0x5
    2210:	7100541f 	cmp	w0, #0x15
    2214:	54000d68 	b.hi	23c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    2218:	4b170385 	sub	w5, w28, w23
    221c:	710000bf 	cmp	w5, #0x0
    2220:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2224:	54000b80 	b.eq	2394 <fwp_format_g.constprop.0+0x214>  // b.none
    2228:	394083e0 	ldrb	w0, [sp, #32]
    222c:	cb180273 	sub	x19, x19, x24
    2230:	91000673 	add	x19, x19, #0x1
    2234:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2238:	7100b41f 	cmp	w0, #0x2d
    223c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2240:	1a9f17e4 	cset	w4, eq	// eq = none
    2244:	cb010266 	sub	x6, x19, x1
    2248:	d10004da 	sub	x26, x6, #0x1
    224c:	540018a0 	b.eq	2560 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2250:	910183f9 	add	x25, sp, #0x60
    2254:	d280091b 	mov	x27, #0x48                  	// #72
    2258:	aa1903e7 	mov	x7, x25
    225c:	91000423 	add	x3, x1, #0x1
    2260:	91011cc6 	add	x6, x6, #0x47
    2264:	910004f6 	add	x22, x7, #0x1
    2268:	37f80ff7 	tbnz	w23, #31, 2464 <fwp_format_g.constprop.0+0x2e4>
    226c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2270:	93407ef7 	sxtw	x23, w23
    2274:	390000e4 	strb	w4, [x7]
    2278:	aa1303e1 	mov	x1, x19
    227c:	aa1703e2 	mov	x2, x23
    2280:	aa1603e0 	mov	x0, x22
    2284:	b9000be5 	str	w5, [sp, #8]
    2288:	cb170374 	sub	x20, x27, x23
    228c:	a9011be3 	stp	x3, x6, [sp, #16]
    2290:	97fffc1c 	bl	1300 <memcpy@plt>
    2294:	d1000694 	sub	x20, x20, #0x1
    2298:	f9400be3 	ldr	x3, [sp, #16]
    229c:	8b1702d6 	add	x22, x22, x23
    22a0:	aa1603e0 	mov	x0, x22
    22a4:	aa1a03e2 	mov	x2, x26
    22a8:	aa0303e1 	mov	x1, x3
    22ac:	aa1403e3 	mov	x3, x20
    22b0:	97fffc50 	bl	13f0 <__memcpy_chk@plt>
    22b4:	8b1a02d6 	add	x22, x22, x26
    22b8:	f9400fe6 	ldr	x6, [sp, #24]
    22bc:	d2800900 	mov	x0, #0x48                  	// #72
    22c0:	b9400be5 	ldr	w5, [sp, #8]
    22c4:	8b170261 	add	x1, x19, x23
    22c8:	cb1400c3 	sub	x3, x6, x20
    22cc:	cb060294 	sub	x20, x20, x6
    22d0:	f101207f 	cmp	x3, #0x48
    22d4:	93407cb8 	sxtw	x24, w5
    22d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    22dc:	aa1803e2 	mov	x2, x24
    22e0:	8b1802d3 	add	x19, x22, x24
    22e4:	8b140063 	add	x3, x3, x20
    22e8:	aa1603e0 	mov	x0, x22
    22ec:	97fffc41 	bl	13f0 <__memcpy_chk@plt>
    22f0:	cb190273 	sub	x19, x19, x25
    22f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    22f8:	eb00027f 	cmp	x19, x0
    22fc:	aa1903e1 	mov	x1, x25
    2300:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2304:	aa1503e0 	mov	x0, x21
    2308:	aa1303e2 	mov	x2, x19
    230c:	97fffbfd 	bl	1300 <memcpy@plt>
    2310:	38336abf 	strb	wzr, [x21, x19]
    2314:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2318:	aa1503e0 	mov	x0, x21
    231c:	97fffc05 	bl	1330 <strlen@plt>
    2320:	aa0003f3 	mov	x19, x0
    2324:	528005c1 	mov	w1, #0x2e                  	// #46
    2328:	aa1503e0 	mov	x0, x21
    232c:	97fffc95 	bl	1580 <strchr@plt>
    2330:	b4000140 	cbz	x0, 2358 <fwp_format_g.constprop.0+0x1d8>
    2334:	b4000133 	cbz	x19, 2358 <fwp_format_g.constprop.0+0x1d8>
    2338:	aa1303e1 	mov	x1, x19
    233c:	d1000673 	sub	x19, x19, #0x1
    2340:	38736aa0 	ldrb	w0, [x21, x19]
    2344:	7100c01f 	cmp	w0, #0x30
    2348:	54001001 	b.ne	2548 <fwp_format_g.constprop.0+0x3c8>  // b.any
    234c:	38336abf 	strb	wzr, [x21, x19]
    2350:	b5ffff53 	cbnz	x19, 2338 <fwp_format_g.constprop.0+0x1b8>
    2354:	d503201f 	nop
    2358:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    235c:	f947f400 	ldr	x0, [x0, #4072]
    2360:	f94057e2 	ldr	x2, [sp, #168]
    2364:	f9400001 	ldr	x1, [x0]
    2368:	eb010042 	subs	x2, x2, x1
    236c:	d2800001 	mov	x1, #0x0                   	// #0
    2370:	54001061 	b.ne	257c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2374:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2378:	a94c53f3 	ldp	x19, x20, [sp, #192]
    237c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2380:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2384:	a95073fb 	ldp	x27, x28, [sp, #256]
    2388:	fd408be8 	ldr	d8, [sp, #272]
    238c:	910483ff 	add	sp, sp, #0x120
    2390:	d65f03c0 	ret
    2394:	1e604100 	fmov	d0, d8
    2398:	710000bf 	cmp	w5, #0x0
    239c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    23a0:	aa1503e0 	mov	x0, x21
    23a4:	f0000024 	adrp	x4, 9000 <__modti3+0x260>
    23a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    23ac:	9107a084 	add	x4, x4, #0x1e8
    23b0:	52800042 	mov	w2, #0x2                   	// #2
    23b4:	d2803201 	mov	x1, #0x190                 	// #400
    23b8:	97fffc16 	bl	1410 <__snprintf_chk@plt>
    23bc:	17ffffd7 	b	2318 <fwp_format_g.constprop.0+0x198>
    23c0:	cb140273 	sub	x19, x19, x20
    23c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    23c8:	910183f9 	add	x25, sp, #0x60
    23cc:	aa1303e2 	mov	x2, x19
    23d0:	aa1403e1 	mov	x1, x20
    23d4:	aa1903e0 	mov	x0, x25
    23d8:	d2800803 	mov	x3, #0x40                  	// #64
    23dc:	97fffc05 	bl	13f0 <__memcpy_chk@plt>
    23e0:	38336b3f 	strb	wzr, [x25, x19]
    23e4:	aa1903e0 	mov	x0, x25
    23e8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ec:	97fffc65 	bl	1580 <strchr@plt>
    23f0:	b40001c0 	cbz	x0, 2428 <fwp_format_g.constprop.0+0x2a8>
    23f4:	b50000b3 	cbnz	x19, 2408 <fwp_format_g.constprop.0+0x288>
    23f8:	1400000c 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    23fc:	381ff01f 	sturb	wzr, [x0, #-1]
    2400:	f1000673 	subs	x19, x19, #0x1
    2404:	54000120 	b.eq	2428 <fwp_format_g.constprop.0+0x2a8>  // b.none
    2408:	8b130320 	add	x0, x25, x19
    240c:	385ff001 	ldurb	w1, [x0, #-1]
    2410:	7100c03f 	cmp	w1, #0x30
    2414:	54ffff40 	b.eq	23fc <fwp_format_g.constprop.0+0x27c>  // b.none
    2418:	d1000673 	sub	x19, x19, #0x1
    241c:	38736b20 	ldrb	w0, [x25, x19]
    2420:	7100b81f 	cmp	w0, #0x2e
    2424:	54000a80 	b.eq	2574 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2428:	710002ff 	cmp	w23, #0x0
    242c:	528005a1 	mov	w1, #0x2d                  	// #45
    2430:	aa1903e5 	mov	x5, x25
    2434:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2438:	aa1503e0 	mov	x0, x21
    243c:	52800566 	mov	w6, #0x2b                  	// #43
    2440:	f0000024 	adrp	x4, 9000 <__modti3+0x260>
    2444:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2448:	91076084 	add	x4, x4, #0x1d8
    244c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2450:	52800042 	mov	w2, #0x2                   	// #2
    2454:	d2803201 	mov	x1, #0x190                 	// #400
    2458:	97fffbee 	bl	1410 <__snprintf_chk@plt>
    245c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2460:	17ffffbe 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2464:	52800605 	mov	w5, #0x30                  	// #48
    2468:	390000e5 	strb	w5, [x7]
    246c:	d100077b 	sub	x27, x27, #0x1
    2470:	aa0303e1 	mov	x1, x3
    2474:	aa1603e0 	mov	x0, x22
    2478:	aa1b03e3 	mov	x3, x27
    247c:	aa1a03e2 	mov	x2, x26
    2480:	f90007e6 	str	x6, [sp, #8]
    2484:	b90013e4 	str	w4, [sp, #16]
    2488:	8b1a02d6 	add	x22, x22, x26
    248c:	b9001be5 	str	w5, [sp, #24]
    2490:	97fffbd8 	bl	13f0 <__memcpy_chk@plt>
    2494:	f94007e6 	ldr	x6, [sp, #8]
    2498:	2a3703e7 	mvn	w7, w23
    249c:	b94013e4 	ldr	w4, [sp, #16]
    24a0:	cb1b00c1 	sub	x1, x6, x27
    24a4:	cb06037b 	sub	x27, x27, x6
    24a8:	f101203f 	cmp	x1, #0x48
    24ac:	d2800906 	mov	x6, #0x48                  	// #72
    24b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    24b4:	8b1b0023 	add	x3, x1, x27
    24b8:	310006ff 	cmn	w23, #0x1
    24bc:	54000220 	b.eq	2500 <fwp_format_g.constprop.0+0x380>  // b.none
    24c0:	b9401be5 	ldr	w5, [sp, #24]
    24c4:	d2800001 	mov	x1, #0x0                   	// #0
    24c8:	f101207f 	cmp	x3, #0x48
    24cc:	d1000462 	sub	x2, x3, #0x1
    24d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    24d4:	38216ac5 	strb	w5, [x22, x1]
    24d8:	cb030003 	sub	x3, x0, x3
    24dc:	91000421 	add	x1, x1, #0x1
    24e0:	91000463 	add	x3, x3, #0x1
    24e4:	eb00007f 	cmp	x3, x0
    24e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24ec:	cb000063 	sub	x3, x3, x0
    24f0:	8b020063 	add	x3, x3, x2
    24f4:	6b0100ff 	cmp	w7, w1
    24f8:	54fffe8c 	b.gt	24c8 <fwp_format_g.constprop.0+0x348>
    24fc:	8b2742d6 	add	x22, x22, w7, uxtw
    2500:	f101207f 	cmp	x3, #0x48
    2504:	d2800905 	mov	x5, #0x48                  	// #72
    2508:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    250c:	aa1603e0 	mov	x0, x22
    2510:	cb0300a1 	sub	x1, x5, x3
    2514:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2518:	91000421 	add	x1, x1, #0x1
    251c:	d1000463 	sub	x3, x3, #0x1
    2520:	eb05003f 	cmp	x1, x5
    2524:	38001402 	strb	w2, [x0], #1
    2528:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    252c:	93407f82 	sxtw	x2, w28
    2530:	cb050025 	sub	x5, x1, x5
    2534:	aa1303e1 	mov	x1, x19
    2538:	8b0300a3 	add	x3, x5, x3
    253c:	8b1802d3 	add	x19, x22, x24
    2540:	97fffbac 	bl	13f0 <__memcpy_chk@plt>
    2544:	17ffff6b 	b	22f0 <fwp_format_g.constprop.0+0x170>
    2548:	d1000421 	sub	x1, x1, #0x1
    254c:	38616aa0 	ldrb	w0, [x21, x1]
    2550:	7100b81f 	cmp	w0, #0x2e
    2554:	54fff021 	b.ne	2358 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2558:	38216abf 	strb	wzr, [x21, x1]
    255c:	17ffff7f 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2560:	910187e7 	add	x7, sp, #0x61
    2564:	910183f9 	add	x25, sp, #0x60
    2568:	d28008fb 	mov	x27, #0x47                  	// #71
    256c:	390183e0 	strb	w0, [sp, #96]
    2570:	17ffff3b 	b	225c <fwp_format_g.constprop.0+0xdc>
    2574:	38336b3f 	strb	wzr, [x25, x19]
    2578:	17ffffac 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    257c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2580:	97fffbc8 	bl	14a0 <__stack_chk_fail@plt>

0000000000002584 <fwp_heap_report>:
    2584:	d105c3ff 	sub	sp, sp, #0x170
    2588:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    258c:	91144042 	add	x2, x2, #0x510
    2590:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14c18>
    2594:	f947e821 	ldr	x1, [x1, #4048]
    2598:	a9117bfd 	stp	x29, x30, [sp, #272]
    259c:	910443fd 	add	x29, sp, #0x110
    25a0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    25a4:	f947f400 	ldr	x0, [x0, #4072]
    25a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    25ac:	a91463f7 	stp	x23, x24, [sp, #320]
    25b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    25b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    25b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    25bc:	fd4a2049 	ldr	d9, [x2, #5184]
    25c0:	f9400036 	ldr	x22, [x1]
    25c4:	f9400001 	ldr	x1, [x0]
    25c8:	f90087e1 	str	x1, [sp, #264]
    25cc:	d2800001 	mov	x1, #0x0                   	// #0
    25d0:	f949e459 	ldr	x25, [x2, #5064]
    25d4:	f0000021 	adrp	x1, 9000 <__modti3+0x260>
    25d8:	f94a1057 	ldr	x23, [x2, #5152]
    25dc:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    25e0:	f94a1458 	ldr	x24, [x2, #5160]
    25e4:	9107c021 	add	x1, x1, #0x1f0
    25e8:	9107e000 	add	x0, x0, #0x1f8
    25ec:	97fffb91 	bl	1430 <fopen@plt>
    25f0:	b4000760 	cbz	x0, 26dc <fwp_heap_report+0x158>
    25f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    25f8:	a91253f3 	stp	x19, x20, [sp, #288]
    25fc:	aa0003f4 	mov	x20, x0
    2600:	910023f3 	add	x19, sp, #0x8
    2604:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2608:	72aae915 	movk	w21, #0x5748, lsl #16
    260c:	d503201f 	nop
    2610:	aa1403e2 	mov	x2, x20
    2614:	aa1303e0 	mov	x0, x19
    2618:	52802001 	mov	w1, #0x100                 	// #256
    261c:	97fffc0d 	bl	1650 <fgets@plt>
    2620:	b4000280 	cbz	x0, 2670 <fwp_heap_report+0xec>
    2624:	b9400261 	ldr	w1, [x19]
    2628:	6b15003f 	cmp	w1, w21
    262c:	54ffff21 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2630:	39401260 	ldrb	w0, [x19, #4]
    2634:	7101341f 	cmp	w0, #0x4d
    2638:	54fffec1 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    263c:	394037e0 	ldrb	w0, [sp, #13]
    2640:	7100e81f 	cmp	w0, #0x3a
    2644:	54fffe61 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2648:	52800142 	mov	w2, #0xa                   	// #10
    264c:	d2800001 	mov	x1, #0x0                   	// #0
    2650:	91003be0 	add	x0, sp, #0xe
    2654:	97fffbbb 	bl	1540 <strtol@plt>
    2658:	aa1403e2 	mov	x2, x20
    265c:	aa0003fa 	mov	x26, x0
    2660:	52802001 	mov	w1, #0x100                 	// #256
    2664:	aa1303e0 	mov	x0, x19
    2668:	97fffbfa 	bl	1650 <fgets@plt>
    266c:	b5fffdc0 	cbnz	x0, 2624 <fwp_heap_report+0xa0>
    2670:	aa1403e0 	mov	x0, x20
    2674:	97fffb6b 	bl	1420 <fclose@plt>
    2678:	a95253f3 	ldp	x19, x20, [sp, #288]
    267c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    2680:	f947f400 	ldr	x0, [x0, #4072]
    2684:	f94087e2 	ldr	x2, [sp, #264]
    2688:	f9400001 	ldr	x1, [x0]
    268c:	eb010042 	subs	x2, x2, x1
    2690:	d2800001 	mov	x1, #0x0                   	// #0
    2694:	54000281 	b.ne	26e4 <fwp_heap_report+0x160>  // b.any
    2698:	a9517bfd 	ldp	x29, x30, [sp, #272]
    269c:	aa1a03e6 	mov	x6, x26
    26a0:	aa1903e5 	mov	x5, x25
    26a4:	aa1803e4 	mov	x4, x24
    26a8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    26ac:	aa1703e3 	mov	x3, x23
    26b0:	a95463f7 	ldp	x23, x24, [sp, #320]
    26b4:	aa1603e0 	mov	x0, x22
    26b8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    26bc:	1e604121 	fmov	d1, d9
    26c0:	1e604100 	fmov	d0, d8
    26c4:	f0000022 	adrp	x2, 9000 <__modti3+0x260>
    26c8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    26cc:	91086042 	add	x2, x2, #0x218
    26d0:	9105c3ff 	add	sp, sp, #0x170
    26d4:	52800041 	mov	w1, #0x2                   	// #2
    26d8:	17fffb8e 	b	1510 <__fprintf_chk@plt>
    26dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    26e0:	17ffffe7 	b	267c <fwp_heap_report+0xf8>
    26e4:	a91253f3 	stp	x19, x20, [sp, #288]
    26e8:	97fffb6e 	bl	14a0 <__stack_chk_fail@plt>
    26ec:	d503201f 	nop

00000000000026f0 <fwp_heap_init>:
    26f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    26f4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaf0>
    26f8:	91104061 	add	x1, x3, #0x410
    26fc:	910003fd 	mov	x29, sp
    2700:	a90153f3 	stp	x19, x20, [sp, #16]
    2704:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2708:	91144262 	add	x2, x19, #0x510
    270c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2710:	52800024 	mov	w4, #0x1                   	// #1
    2714:	52800200 	mov	w0, #0x10                  	// #16
    2718:	b913a444 	str	w4, [x2, #5028]
    271c:	d503201f 	nop
    2720:	b8004420 	str	w0, [x1], #4
    2724:	11004000 	add	w0, w0, #0x10
    2728:	7104401f 	cmp	w0, #0x110
    272c:	54ffffa1 	b.ne	2720 <fwp_heap_init+0x30>  // b.any
    2730:	f0000022 	adrp	x2, 9000 <__modti3+0x260>
    2734:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2738:	90000181 	adrp	x1, 32000 <fwp_heap+0xaf0>
    273c:	91114021 	add	x1, x1, #0x450
    2740:	3dc19843 	ldr	q3, [x2, #1632]
    2744:	d2800000 	mov	x0, #0x0                   	// #0
    2748:	4e040401 	dup	v1.4s, v0.s[0]
    274c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2750:	0f215400 	shl	v0.2s, v0.2s, #1
    2754:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2758:	3ca06821 	str	q1, [x1, x0]
    275c:	91004000 	add	x0, x0, #0x10
    2760:	f101801f 	cmp	x0, #0x60
    2764:	54ffff21 	b.ne	2748 <fwp_heap_init+0x58>  // b.any
    2768:	90000184 	adrp	x4, 32000 <fwp_heap+0xaf0>
    276c:	91104063 	add	x3, x3, #0x410
    2770:	9112c084 	add	x4, x4, #0x4b0
    2774:	91144266 	add	x6, x19, #0x510
    2778:	d2800002 	mov	x2, #0x0                   	// #0
    277c:	d2800000 	mov	x0, #0x0                   	// #0
    2780:	d2880205 	mov	x5, #0x4010                	// #16400
    2784:	d503201f 	nop
    2788:	910f0001 	add	x1, x0, #0x3c0
    278c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2790:	eb02003f 	cmp	x1, x2
    2794:	540000a2 	b.cs	27a8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2798:	91000400 	add	x0, x0, #0x1
    279c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    27a0:	eb02003f 	cmp	x1, x2
    27a4:	54ffffa3 	b.cc	2798 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    27a8:	91004042 	add	x2, x2, #0x10
    27ac:	38001480 	strb	w0, [x4], #1
    27b0:	eb05005f 	cmp	x2, x5
    27b4:	54fffea1 	b.ne	2788 <fwp_heap_init+0x98>  // b.any
    27b8:	528000b5 	mov	w21, #0x5                   	// #5
    27bc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    27c0:	14000004 	b	27d0 <fwp_heap_init+0xe0>
    27c4:	d342fe94 	lsr	x20, x20, #2
    27c8:	710006b5 	subs	w21, w21, #0x1
    27cc:	54000720 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    27d0:	91404296 	add	x22, x20, #0x10, lsl #12
    27d4:	d2800005 	mov	x5, #0x0                   	// #0
    27d8:	aa1603e1 	mov	x1, x22
    27dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    27e0:	52880443 	mov	w3, #0x4022                	// #16418
    27e4:	52800002 	mov	w2, #0x0                   	// #0
    27e8:	d2800000 	mov	x0, #0x0                   	// #0
    27ec:	97fffb51 	bl	1530 <mmap@plt>
    27f0:	aa0003e6 	mov	x6, x0
    27f4:	b100041f 	cmn	x0, #0x1
    27f8:	54fffe60 	b.eq	27c4 <fwp_heap_init+0xd4>  // b.none
    27fc:	b40005a0 	cbz	x0, 28b0 <fwp_heap_init+0x1c0>
    2800:	d350fe94 	lsr	x20, x20, #16
    2804:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2808:	8b0000c7 	add	x7, x6, x0
    280c:	91144275 	add	x21, x19, #0x510
    2810:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2814:	8b140a81 	add	x1, x20, x20, lsl #2
    2818:	d2800005 	mov	x5, #0x0                   	// #0
    281c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2820:	d37df021 	lsl	x1, x1, #3
    2824:	52880443 	mov	w3, #0x4022                	// #16418
    2828:	52800002 	mov	w2, #0x0                   	// #0
    282c:	d2800000 	mov	x0, #0x0                   	// #0
    2830:	f909daa7 	str	x7, [x21, #5040]
    2834:	f909dea6 	str	x6, [x21, #5048]
    2838:	f909e2b6 	str	x22, [x21, #5056]
    283c:	f909eab4 	str	x20, [x21, #5072]
    2840:	f90a02a1 	str	x1, [x21, #5120]
    2844:	97fffb3b 	bl	1530 <mmap@plt>
    2848:	aa0003e1 	mov	x1, x0
    284c:	b100041f 	cmn	x0, #0x1
    2850:	54000300 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    2854:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    2858:	910b2000 	add	x0, x0, #0x2c8
    285c:	f909fea1 	str	x1, [x21, #5112]
    2860:	97fffb74 	bl	1630 <getenv@plt>
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	aa0003e1 	mov	x1, x0
    286c:	b40000e0 	cbz	x0, 2888 <fwp_heap_init+0x198>
    2870:	39400000 	ldrb	w0, [x0]
    2874:	340000a0 	cbz	w0, 2888 <fwp_heap_init+0x198>
    2878:	7100c000 	subs	w0, w0, #0x30
    287c:	54000120 	b.eq	28a0 <fwp_heap_init+0x1b0>  // b.none
    2880:	7100001f 	cmp	w0, #0x0
    2884:	1a9f07e2 	cset	w2, ne	// ne = any
    2888:	91144273 	add	x19, x19, #0x510
    288c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2890:	b913aa62 	str	w2, [x19, #5032]
    2894:	a94153f3 	ldp	x19, x20, [sp, #16]
    2898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    289c:	d65f03c0 	ret
    28a0:	39400420 	ldrb	w0, [x1, #1]
    28a4:	7100001f 	cmp	w0, #0x0
    28a8:	1a9f07e2 	cset	w2, ne	// ne = any
    28ac:	17fffff7 	b	2888 <fwp_heap_init+0x198>
    28b0:	97fffcb8 	bl	1b90 <fwp_heap_oom>

00000000000028b4 <fwp_wake_io>:
    28b4:	d00000e9 	adrp	x9, 20000 <__data_start>
    28b8:	9101c122 	add	x2, x9, #0x70
    28bc:	f9400001 	ldr	x1, [x0]
    28c0:	5280000a 	mov	w10, #0x0                   	// #0
    28c4:	f9401046 	ldr	x6, [x2, #32]
    28c8:	52800008 	mov	w8, #0x0                   	// #0
    28cc:	4f000400 	movi	v0.4s, #0x0
    28d0:	52800027 	mov	w7, #0x1                   	// #1
    28d4:	aa0103e2 	mov	x2, x1
    28d8:	b4000321 	cbz	x1, 293c <fwp_wake_io+0x88>
    28dc:	f9408c25 	ldr	x5, [x1, #280]
    28e0:	39015c27 	strb	w7, [x1, #87]
    28e4:	b4000165 	cbz	x5, 2910 <fwp_wake_io+0x5c>
    28e8:	a9520c24 	ldp	x4, x3, [x1, #288]
    28ec:	b4000364 	cbz	x4, 2958 <fwp_wake_io+0xa4>
    28f0:	f9009483 	str	x3, [x4, #296]
    28f4:	f9409423 	ldr	x3, [x1, #296]
    28f8:	b4000043 	cbz	x3, 2900 <fwp_wake_io+0x4c>
    28fc:	f9009064 	str	x4, [x3, #288]
    2900:	91080023 	add	x3, x1, #0x200
    2904:	f900943f 	str	xzr, [x1, #296]
    2908:	3c918060 	stur	q0, [x3, #-232]
    290c:	f9400001 	ldr	x1, [x0]
    2910:	f9402843 	ldr	x3, [x2, #80]
    2914:	f2001c7f 	tst	x3, #0xff000000ff
    2918:	54fffde1 	b.ne	28d4 <fwp_wake_io+0x20>  // b.any
    291c:	39015047 	strb	w7, [x2, #84]
    2920:	f900805f 	str	xzr, [x2, #256]
    2924:	b40001e6 	cbz	x6, 2960 <fwp_wake_io+0xac>
    2928:	f90080c2 	str	x2, [x6, #256]
    292c:	aa0203e6 	mov	x6, x2
    2930:	52800028 	mov	w8, #0x1                   	// #1
    2934:	aa0103e2 	mov	x2, x1
    2938:	b5fffd21 	cbnz	x1, 28dc <fwp_wake_io+0x28>
    293c:	3400006a 	cbz	w10, 2948 <fwp_wake_io+0x94>
    2940:	9101c120 	add	x0, x9, #0x70
    2944:	f900140b 	str	x11, [x0, #40]
    2948:	34000068 	cbz	w8, 2954 <fwp_wake_io+0xa0>
    294c:	9101c129 	add	x9, x9, #0x70
    2950:	f9001126 	str	x6, [x9, #32]
    2954:	d65f03c0 	ret
    2958:	f90000a3 	str	x3, [x5]
    295c:	17ffffe7 	b	28f8 <fwp_wake_io+0x44>
    2960:	aa0203eb 	mov	x11, x2
    2964:	5280002a 	mov	w10, #0x1                   	// #1
    2968:	17fffff1 	b	292c <fwp_wake_io+0x78>
    296c:	d503201f 	nop

0000000000002970 <fwp_poll_events>:
    2970:	d10103ff 	sub	sp, sp, #0x40
    2974:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    2978:	f947f400 	ldr	x0, [x0, #4072]
    297c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2980:	910083fd 	add	x29, sp, #0x20
    2984:	a90353f3 	stp	x19, x20, [sp, #48]
    2988:	d00000f4 	adrp	x20, 20000 <__data_start>
    298c:	f9400001 	ldr	x1, [x0]
    2990:	f9000fe1 	str	x1, [sp, #24]
    2994:	d2800001 	mov	x1, #0x0                   	// #0
    2998:	97fffdd2 	bl	20e0 <fwp_now_ns>
    299c:	9101c281 	add	x1, x20, #0x70
    29a0:	f9401833 	ldr	x19, [x1, #48]
    29a4:	b4000e93 	cbz	x19, 2b74 <fwp_poll_events+0x204>
    29a8:	aa1303e1 	mov	x1, x19
    29ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    29b0:	14000005 	b	29c4 <fwp_poll_events+0x54>
    29b4:	f9408821 	ldr	x1, [x1, #272]
    29b8:	eb03005f 	cmp	x2, x3
    29bc:	9a83d042 	csel	x2, x2, x3, le
    29c0:	b40000c1 	cbz	x1, 29d8 <fwp_poll_events+0x68>
    29c4:	f9403423 	ldr	x3, [x1, #104]
    29c8:	b6ffff62 	tbz	x2, #63, 29b4 <fwp_poll_events+0x44>
    29cc:	f9408821 	ldr	x1, [x1, #272]
    29d0:	aa0303e2 	mov	x2, x3
    29d4:	b5ffff81 	cbnz	x1, 29c4 <fwp_poll_events+0x54>
    29d8:	b7f80ce2 	tbnz	x2, #63, 2b74 <fwp_poll_events+0x204>
    29dc:	cb000042 	sub	x2, x2, x0
    29e0:	f100005f 	cmp	x2, #0x0
    29e4:	540005cd 	b.le	2a9c <fwp_poll_events+0x12c>
    29e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    29ec:	d2884801 	mov	x1, #0x4240                	// #16960
    29f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    29f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    29f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    29fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a00:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a04:	9b407c40 	smulh	x0, x2, x0
    2a08:	9352fc00 	asr	x0, x0, #18
    2a0c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2a10:	9b018802 	msub	x2, x0, x1, x2
    2a14:	f100005f 	cmp	x2, #0x0
    2a18:	9a800400 	cinc	x0, x0, ne	// ne = any
    2a1c:	eb03001f 	cmp	x0, x3
    2a20:	54000a0c 	b.gt	2b60 <fwp_poll_events+0x1f0>
    2a24:	340003c0 	cbz	w0, 2a9c <fwp_poll_events+0x12c>
    2a28:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2a2c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2a30:	72a20c42 	movk	w2, #0x1062, lsl #16
    2a34:	9ba27c02 	umull	x2, w0, w2
    2a38:	d366fc43 	lsr	x3, x2, #38
    2a3c:	aa0303e2 	mov	x2, x3
    2a40:	1b048063 	msub	w3, w3, w4, w0
    2a44:	9b217c63 	smull	x3, w3, w1
    2a48:	d2800001 	mov	x1, #0x0                   	// #0
    2a4c:	910023e0 	add	x0, sp, #0x8
    2a50:	a9008fe2 	stp	x2, x3, [sp, #8]
    2a54:	97fffac7 	bl	1570 <nanosleep@plt>
    2a58:	9101c280 	add	x0, x20, #0x70
    2a5c:	f9401813 	ldr	x19, [x0, #48]
    2a60:	97fffda0 	bl	20e0 <fwp_now_ns>
    2a64:	aa0003e6 	mov	x6, x0
    2a68:	b50001f3 	cbnz	x19, 2aa4 <fwp_poll_events+0x134>
    2a6c:	d503201f 	nop
    2a70:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    2a74:	f947f400 	ldr	x0, [x0, #4072]
    2a78:	f9400fe2 	ldr	x2, [sp, #24]
    2a7c:	f9400001 	ldr	x1, [x0]
    2a80:	eb010042 	subs	x2, x2, x1
    2a84:	d2800001 	mov	x1, #0x0                   	// #0
    2a88:	540008c1 	b.ne	2ba0 <fwp_poll_events+0x230>  // b.any
    2a8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2a90:	a94353f3 	ldp	x19, x20, [sp, #48]
    2a94:	910103ff 	add	sp, sp, #0x40
    2a98:	d65f03c0 	ret
    2a9c:	97fffd91 	bl	20e0 <fwp_now_ns>
    2aa0:	aa0003e6 	mov	x6, x0
    2aa4:	4f000400 	movi	v0.4s, #0x0
    2aa8:	9101c288 	add	x8, x20, #0x70
    2aac:	52800027 	mov	w7, #0x1                   	// #1
    2ab0:	f9403661 	ldr	x1, [x19, #104]
    2ab4:	aa1303e5 	mov	x5, x19
    2ab8:	f9408a73 	ldr	x19, [x19, #272]
    2abc:	eb06003f 	cmp	x1, x6
    2ac0:	5400032c 	b.gt	2b24 <fwp_poll_events+0x1b4>
    2ac4:	394154a0 	ldrb	w0, [x5, #85]
    2ac8:	36000120 	tbz	w0, #0, 2aec <fwp_poll_events+0x17c>
    2acc:	f94084a0 	ldr	x0, [x5, #264]
    2ad0:	b40003c0 	cbz	x0, 2b48 <fwp_poll_events+0x1d8>
    2ad4:	f9008813 	str	x19, [x0, #272]
    2ad8:	b4000053 	cbz	x19, 2ae0 <fwp_poll_events+0x170>
    2adc:	f9008660 	str	x0, [x19, #264]
    2ae0:	910800a0 	add	x0, x5, #0x200
    2ae4:	390154bf 	strb	wzr, [x5, #85]
    2ae8:	3c908000 	stur	q0, [x0, #-248]
    2aec:	f94030a0 	ldr	x0, [x5, #96]
    2af0:	390158a7 	strb	w7, [x5, #86]
    2af4:	f100001f 	cmp	x0, #0x0
    2af8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2afc:	5400018d 	b.le	2b2c <fwp_poll_events+0x1bc>
    2b00:	f94028a0 	ldr	x0, [x5, #80]
    2b04:	f2001c1f 	tst	x0, #0xff000000ff
    2b08:	540000e1 	b.ne	2b24 <fwp_poll_events+0x1b4>  // b.any
    2b0c:	f9401100 	ldr	x0, [x8, #32]
    2b10:	390150a7 	strb	w7, [x5, #84]
    2b14:	f90080bf 	str	xzr, [x5, #256]
    2b18:	b40001e0 	cbz	x0, 2b54 <fwp_poll_events+0x1e4>
    2b1c:	f9001105 	str	x5, [x8, #32]
    2b20:	f9008005 	str	x5, [x0, #256]
    2b24:	b5fffc73 	cbnz	x19, 2ab0 <fwp_poll_events+0x140>
    2b28:	17ffffd2 	b	2a70 <fwp_poll_events+0x100>
    2b2c:	394144a0 	ldrb	w0, [x5, #81]
    2b30:	3707fe80 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b34:	394140a0 	ldrb	w0, [x5, #80]
    2b38:	3707fe40 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b3c:	aa0503e0 	mov	x0, x5
    2b40:	97fffd14 	bl	1f90 <fwp_cancel_tree.part.0>
    2b44:	17ffffef 	b	2b00 <fwp_poll_events+0x190>
    2b48:	9101c281 	add	x1, x20, #0x70
    2b4c:	f9001833 	str	x19, [x1, #48]
    2b50:	17ffffe2 	b	2ad8 <fwp_poll_events+0x168>
    2b54:	f9001105 	str	x5, [x8, #32]
    2b58:	f9001505 	str	x5, [x8, #40]
    2b5c:	17fffff2 	b	2b24 <fwp_poll_events+0x1b4>
    2b60:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2b64:	d2989362 	mov	x2, #0xc49b                	// #50331
    2b68:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2b6c:	f2a00402 	movk	x2, #0x20, lsl #16
    2b70:	17ffffb6 	b	2a48 <fwp_poll_events+0xd8>
    2b74:	97fffbf7 	bl	1b50 <fwp_flush>
    2b78:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14c18>
    2b7c:	f947e863 	ldr	x3, [x3, #4048]
    2b80:	d2800562 	mov	x2, #0x2b                  	// #43
    2b84:	d2800021 	mov	x1, #0x1                   	// #1
    2b88:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    2b8c:	910b6000 	add	x0, x0, #0x2d8
    2b90:	f9400063 	ldr	x3, [x3]
    2b94:	97fffa83 	bl	15a0 <fwrite@plt>
    2b98:	52800ca0 	mov	w0, #0x65                  	// #101
    2b9c:	97fff9ed 	bl	1350 <exit@plt>
    2ba0:	97fffa40 	bl	14a0 <__stack_chk_fail@plt>

0000000000002ba4 <fwp_rc_forget_slot>:
    2ba4:	aa0003e1 	mov	x1, x0
    2ba8:	39400000 	ldrb	w0, [x0]
    2bac:	7103fc1f 	cmp	w0, #0xff
    2bb0:	54000040 	b.eq	2bb8 <fwp_rc_forget_slot+0x14>  // b.none
    2bb4:	d65f03c0 	ret
    2bb8:	ca414420 	eor	x0, x1, x1, lsr #17
    2bbc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    2bc4:	910003fd 	mov	x29, sp
    2bc8:	92401c00 	and	x0, x0, #0xff
    2bcc:	f9000bf3 	str	x19, [sp, #16]
    2bd0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2bd4:	91144262 	add	x2, x19, #0x510
    2bd8:	910a2403 	add	x3, x0, #0x289
    2bdc:	8b000c40 	add	x0, x2, x0, lsl #3
    2be0:	8b030c43 	add	x3, x2, x3, lsl #3
    2be4:	f94a2400 	ldr	x0, [x0, #5192]
    2be8:	b50000a0 	cbnz	x0, 2bfc <fwp_rc_forget_slot+0x58>
    2bec:	14000011 	b	2c30 <fwp_rc_forget_slot+0x8c>
    2bf0:	91004003 	add	x3, x0, #0x10
    2bf4:	f9400800 	ldr	x0, [x0, #16]
    2bf8:	b40001c0 	cbz	x0, 2c30 <fwp_rc_forget_slot+0x8c>
    2bfc:	f9400002 	ldr	x2, [x0]
    2c00:	eb02003f 	cmp	x1, x2
    2c04:	54ffff61 	b.ne	2bf0 <fwp_rc_forget_slot+0x4c>  // b.any
    2c08:	f9400801 	ldr	x1, [x0, #16]
    2c0c:	91144273 	add	x19, x19, #0x510
    2c10:	f9000061 	str	x1, [x3]
    2c14:	97fffa53 	bl	1560 <free@plt>
    2c18:	f94e2660 	ldr	x0, [x19, #7240]
    2c1c:	d1000400 	sub	x0, x0, #0x1
    2c20:	f90e2660 	str	x0, [x19, #7240]
    2c24:	f9400bf3 	ldr	x19, [sp, #16]
    2c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2c2c:	d65f03c0 	ret
    2c30:	f0000020 	adrp	x0, 9000 <__modti3+0x260>
    2c34:	910c2000 	add	x0, x0, #0x308
    2c38:	97fffd1a 	bl	20a0 <fwp_trap>
    2c3c:	d503201f 	nop

0000000000002c40 <fwp_rc_prepare_chunk>:
    2c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c44:	910003fd 	mov	x29, sp
    2c48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c4c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcd0>
    2c50:	911442c2 	add	x2, x22, #0x510
    2c54:	b9401c03 	ldr	w3, [x0, #28]
    2c58:	aa0103f5 	mov	x21, x1
    2c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c60:	aa0003f4 	mov	x20, x0
    2c64:	f94e2440 	ldr	x0, [x2, #7240]
    2c68:	b4000440 	cbz	x0, 2cf0 <fwp_rc_prepare_chunk+0xb0>
    2c6c:	d2800013 	mov	x19, #0x0                   	// #0
    2c70:	35000203 	cbnz	w3, 2cb0 <fwp_rc_prepare_chunk+0x70>
    2c74:	b4000361 	cbz	x1, 2ce0 <fwp_rc_prepare_chunk+0xa0>
    2c78:	f9401280 	ldr	x0, [x20, #32]
    2c7c:	97fffa39 	bl	1560 <free@plt>
    2c80:	aa1503e0 	mov	x0, x21
    2c84:	d2800021 	mov	x1, #0x1                   	// #1
    2c88:	97fff9fe 	bl	1480 <calloc@plt>
    2c8c:	f9001280 	str	x0, [x20, #32]
    2c90:	b5000460 	cbnz	x0, 2d1c <fwp_rc_prepare_chunk+0xdc>
    2c94:	97fffbbf 	bl	1b90 <fwp_heap_oom>
    2c98:	97ffffc3 	bl	2ba4 <fwp_rc_forget_slot>
    2c9c:	91000673 	add	x19, x19, #0x1
    2ca0:	b9401e83 	ldr	w3, [x20, #28]
    2ca4:	eb13007f 	cmp	x3, x19
    2ca8:	54000169 	b.ls	2cd4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2cac:	d503201f 	nop
    2cb0:	f9401283 	ldr	x3, [x20, #32]
    2cb4:	8b130060 	add	x0, x3, x19
    2cb8:	38736863 	ldrb	w3, [x3, x19]
    2cbc:	7103fc7f 	cmp	w3, #0xff
    2cc0:	54fffec0 	b.eq	2c98 <fwp_rc_prepare_chunk+0x58>  // b.none
    2cc4:	b9401e83 	ldr	w3, [x20, #28]
    2cc8:	91000673 	add	x19, x19, #0x1
    2ccc:	eb13007f 	cmp	x3, x19
    2cd0:	54ffff08 	b.hi	2cb0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2cd4:	eb0302bf 	cmp	x21, x3
    2cd8:	54000121 	b.ne	2cfc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2cdc:	b5000335 	cbnz	x21, 2d40 <fwp_rc_prepare_chunk+0x100>
    2ce0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ce4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ce8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cec:	d65f03c0 	ret
    2cf0:	2a0303e3 	mov	w3, w3
    2cf4:	eb0302bf 	cmp	x21, x3
    2cf8:	54ffff20 	b.eq	2cdc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2cfc:	911442c2 	add	x2, x22, #0x510
    2d00:	f9401280 	ldr	x0, [x20, #32]
    2d04:	f94e2841 	ldr	x1, [x2, #7248]
    2d08:	cb030021 	sub	x1, x1, x3
    2d0c:	f90e2841 	str	x1, [x2, #7248]
    2d10:	97fffa14 	bl	1560 <free@plt>
    2d14:	b5fffb75 	cbnz	x21, 2c80 <fwp_rc_prepare_chunk+0x40>
    2d18:	f900129f 	str	xzr, [x20, #32]
    2d1c:	911442d6 	add	x22, x22, #0x510
    2d20:	f94e2ac0 	ldr	x0, [x22, #7248]
    2d24:	b9001e95 	str	w21, [x20, #28]
    2d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d2c:	8b150000 	add	x0, x0, x21
    2d30:	f90e2ac0 	str	x0, [x22, #7248]
    2d34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d3c:	d65f03c0 	ret
    2d40:	f9401280 	ldr	x0, [x20, #32]
    2d44:	aa1503e2 	mov	x2, x21
    2d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d4c:	52800001 	mov	w1, #0x0                   	// #0
    2d50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d58:	17fff9c6 	b	1470 <memset@plt>
    2d5c:	d503201f 	nop

0000000000002d60 <fwp_heap_refill>:
    2d60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d64:	910003fd 	mov	x29, sp
    2d68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d6c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2d70:	911442b5 	add	x21, x21, #0x510
    2d74:	aa0003f6 	mov	x22, x0
    2d78:	d2800020 	mov	x0, #0x1                   	// #1
    2d7c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d80:	a90363f7 	stp	x23, x24, [sp, #48]
    2d84:	2a0103f7 	mov	w23, w1
    2d88:	2a0203f8 	mov	w24, w2
    2d8c:	97fffbc1 	bl	1c90 <fwp_heap_chunks>
    2d90:	aa0003f3 	mov	x19, x0
    2d94:	f949fea2 	ldr	x2, [x21, #5112]
    2d98:	8b000800 	add	x0, x0, x0, lsl #2
    2d9c:	2a1703e1 	mov	w1, w23
    2da0:	52800025 	mov	w5, #0x1                   	// #1
    2da4:	d37df000 	lsl	x0, x0, #3
    2da8:	910f0021 	add	x1, x1, #0x3c0
    2dac:	8b000054 	add	x20, x2, x0
    2db0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2db4:	52a00024 	mov	w4, #0x10000               	// #65536
    2db8:	38206845 	strb	w5, [x2, x0]
    2dbc:	aa1403e0 	mov	x0, x20
    2dc0:	39000698 	strb	w24, [x20, #1]
    2dc4:	39000a97 	strb	w23, [x20, #2]
    2dc8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2dcc:	b9000681 	str	w1, [x20, #4]
    2dd0:	2a0103e5 	mov	w5, w1
    2dd4:	8b0300a2 	add	x2, x5, x3
    2dd8:	1ac10881 	udiv	w1, w4, w1
    2ddc:	9ac50842 	udiv	x2, x2, x5
    2de0:	b9000a81 	str	w1, [x20, #8]
    2de4:	92404021 	and	x1, x1, #0x1ffff
    2de8:	b9001a82 	str	w2, [x20, #24]
    2dec:	97ffff95 	bl	2c40 <fwp_rc_prepare_chunk>
    2df0:	f949daa0 	ldr	x0, [x21, #5040]
    2df4:	29408a81 	ldp	w1, w2, [x20, #4]
    2df8:	8b134000 	add	x0, x0, x19, lsl #16
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	8b214003 	add	x3, x0, w1, uxtw
    2e04:	9ba20021 	umaddl	x1, w1, w2, x0
    2e08:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e0c:	a90086c3 	stp	x3, x1, [x22, #8]
    2e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e14:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e18:	d65f03c0 	ret
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_mem_free>:
    2e20:	b40003c0 	cbz	x0, 2e98 <fwp_mem_free+0x78>
    2e24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2e28:	910003fd 	mov	x29, sp
    2e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e30:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2e34:	911442a1 	add	x1, x21, #0x510
    2e38:	a90153f3 	stp	x19, x20, [sp, #16]
    2e3c:	aa0003f3 	mov	x19, x0
    2e40:	f949d823 	ldr	x3, [x1, #5040]
    2e44:	f949ec22 	ldr	x2, [x1, #5080]
    2e48:	cb030000 	sub	x0, x0, x3
    2e4c:	eb02401f 	cmp	x0, x2, lsl #16
    2e50:	540001c2 	b.cs	2e88 <fwp_mem_free+0x68>  // b.hs, b.nlast
    2e54:	d350fc16 	lsr	x22, x0, #16
    2e58:	a90363f7 	stp	x23, x24, [sp, #48]
    2e5c:	f949fc22 	ldr	x2, [x1, #5112]
    2e60:	8b160ad4 	add	x20, x22, x22, lsl #2
    2e64:	d37df294 	lsl	x20, x20, #3
    2e68:	ab140057 	adds	x23, x2, x20
    2e6c:	540000c0 	b.eq	2e84 <fwp_mem_free+0x64>  // b.none
    2e70:	38746842 	ldrb	w2, [x2, x20]
    2e74:	7100045f 	cmp	w2, #0x1
    2e78:	54000120 	b.eq	2e9c <fwp_mem_free+0x7c>  // b.none
    2e7c:	7100085f 	cmp	w2, #0x2
    2e80:	540005e0 	b.eq	2f3c <fwp_mem_free+0x11c>  // b.none
    2e84:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e90:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2e94:	d65f03c0 	ret
    2e98:	d65f03c0 	ret
    2e9c:	f94012f8 	ldr	x24, [x23, #32]
    2ea0:	b94006e1 	ldr	w1, [x23, #4]
    2ea4:	f90023f9 	str	x25, [sp, #64]
    2ea8:	2a0103e2 	mov	w2, w1
    2eac:	394006f9 	ldrb	w25, [x23, #1]
    2eb0:	39400af4 	ldrb	w20, [x23, #2]
    2eb4:	b4000158 	cbz	x24, 2edc <fwp_mem_free+0xbc>
    2eb8:	92403e76 	and	x22, x19, #0xffff
    2ebc:	9ac20ad6 	udiv	x22, x22, x2
    2ec0:	38766b01 	ldrb	w1, [x24, x22]
    2ec4:	8b160300 	add	x0, x24, x22
    2ec8:	7103fc3f 	cmp	w1, #0xff
    2ecc:	54000980 	b.eq	2ffc <fwp_mem_free+0x1dc>  // b.none
    2ed0:	38366b1f 	strb	wzr, [x24, x22]
    2ed4:	b94006e1 	ldr	w1, [x23, #4]
    2ed8:	2a0103e2 	mov	w2, w1
    2edc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    2ee0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    2ee4:	cb390000 	sub	x0, x0, w25, uxtb
    2ee8:	8b340074 	add	x20, x3, w20, uxtb
    2eec:	911442b5 	add	x21, x21, #0x510
    2ef0:	1e630021 	ucvtf	d1, w1
    2ef4:	d37ae400 	lsl	x0, x0, #6
    2ef8:	8b140c14 	add	x20, x0, x20, lsl #3
    2efc:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f00:	f8746aa0 	ldr	x0, [x21, x20]
    2f04:	f94023f9 	ldr	x25, [sp, #64]
    2f08:	aa2003e0 	mvn	x0, x0
    2f0c:	fd4a22a0 	ldr	d0, [x21, #5184]
    2f10:	f9000260 	str	x0, [x19]
    2f14:	f8346ab3 	str	x19, [x21, x20]
    2f18:	f94a12a0 	ldr	x0, [x21, #5152]
    2f1c:	1e612800 	fadd	d0, d0, d1
    2f20:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f24:	cb020000 	sub	x0, x0, x2
    2f28:	f90a12a0 	str	x0, [x21, #5152]
    2f2c:	fd0a22a0 	str	d0, [x21, #5184]
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2f38:	d65f03c0 	ret
    2f3c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    2f40:	8b000063 	add	x3, x3, x0
    2f44:	eb03027f 	cmp	x19, x3
    2f48:	54fff9e1 	b.ne	2e84 <fwp_mem_free+0x64>  // b.any
    2f4c:	fd400ae1 	ldr	d1, [x23, #16]
    2f50:	fd4a2020 	ldr	d0, [x1, #5184]
    2f54:	f9400ae0 	ldr	x0, [x23, #16]
    2f58:	7e61d821 	ucvtf	d1, d1
    2f5c:	f94a1022 	ldr	x2, [x1, #5152]
    2f60:	f94012f3 	ldr	x19, [x23, #32]
    2f64:	1e612800 	fadd	d0, d0, d1
    2f68:	cb000042 	sub	x2, x2, x0
    2f6c:	f90a1022 	str	x2, [x1, #5152]
    2f70:	fd0a2020 	str	d0, [x1, #5184]
    2f74:	b40000b3 	cbz	x19, 2f88 <fwp_mem_free+0x168>
    2f78:	39400260 	ldrb	w0, [x19]
    2f7c:	7103fc1f 	cmp	w0, #0xff
    2f80:	54000380 	b.eq	2ff0 <fwp_mem_free+0x1d0>  // b.none
    2f84:	3900027f 	strb	wzr, [x19]
    2f88:	b9400ee2 	ldr	w2, [x23, #12]
    2f8c:	b4000142 	cbz	x2, 2fb4 <fwp_mem_free+0x194>
    2f90:	911442a1 	add	x1, x21, #0x510
    2f94:	8b160040 	add	x0, x2, x22
    2f98:	8b000800 	add	x0, x0, x0, lsl #2
    2f9c:	f949fc21 	ldr	x1, [x1, #5112]
    2fa0:	8b140034 	add	x20, x1, x20
    2fa4:	8b000c20 	add	x0, x1, x0, lsl #3
    2fa8:	3802869f 	strb	wzr, [x20], #40
    2fac:	eb00029f 	cmp	x20, x0
    2fb0:	54ffffc1 	b.ne	2fa8 <fwp_mem_free+0x188>  // b.any
    2fb4:	911442a0 	add	x0, x21, #0x510
    2fb8:	f94a1801 	ldr	x1, [x0, #5168]
    2fbc:	f949f803 	ldr	x3, [x0, #5104]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f90a1801 	str	x1, [x0, #5168]
    2fc8:	eb16007f 	cmp	x3, x22
    2fcc:	54000049 	b.ls	2fd4 <fwp_mem_free+0x1b4>  // b.plast
    2fd0:	f909f816 	str	x22, [x0, #5104]
    2fd4:	911442b5 	add	x21, x21, #0x510
    2fd8:	f949f6a0 	ldr	x0, [x21, #5096]
    2fdc:	eb16001f 	cmp	x0, x22
    2fe0:	54fff529 	b.ls	2e84 <fwp_mem_free+0x64>  // b.plast
    2fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fe8:	f909f6b6 	str	x22, [x21, #5096]
    2fec:	17ffffa7 	b	2e88 <fwp_mem_free+0x68>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	97fffeec 	bl	2ba4 <fwp_rc_forget_slot>
    2ff8:	17ffffe3 	b	2f84 <fwp_mem_free+0x164>
    2ffc:	97fffeea 	bl	2ba4 <fwp_rc_forget_slot>
    3000:	17ffffb4 	b	2ed0 <fwp_mem_free+0xb0>

0000000000003004 <fwp_heap_alloc_big>:
    3004:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3008:	910003fd 	mov	x29, sp
    300c:	a90153f3 	stp	x19, x20, [sp, #16]
    3010:	a9025bf5 	stp	x21, x22, [sp, #32]
    3014:	a90363f7 	stp	x23, x24, [sp, #48]
    3018:	aa0003f7 	mov	x23, x0
    301c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3020:	a9046bf9 	stp	x25, x26, [sp, #64]
    3024:	eb0002ff 	cmp	x23, x0
    3028:	54000888 	b.hi	3138 <fwp_heap_alloc_big+0x134>  // b.pmore
    302c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3030:	8b0002f4 	add	x20, x23, x0
    3034:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcd0>
    3038:	91144359 	add	x25, x26, #0x510
    303c:	d350fe94 	lsr	x20, x20, #16
    3040:	2a0103f5 	mov	w21, w1
    3044:	aa1403e0 	mov	x0, x20
    3048:	97fffb12 	bl	1c90 <fwp_heap_chunks>
    304c:	f949ff22 	ldr	x2, [x25, #5112]
    3050:	8b000813 	add	x19, x0, x0, lsl #2
    3054:	aa0003f8 	mov	x24, x0
    3058:	52800043 	mov	w3, #0x2                   	// #2
    305c:	d37df273 	lsl	x19, x19, #3
    3060:	d2800021 	mov	x1, #0x1                   	// #1
    3064:	8b130040 	add	x0, x2, x19
    3068:	38336843 	strb	w3, [x2, x19]
    306c:	39000415 	strb	w21, [x0, #1]
    3070:	b9000c14 	str	w20, [x0, #12]
    3074:	f9000817 	str	x23, [x0, #16]
    3078:	97fffef2 	bl	2c40 <fwp_rc_prepare_chunk>
    307c:	f100069f 	cmp	x20, #0x1
    3080:	54000269 	b.ls	30cc <fwp_heap_alloc_big+0xc8>  // b.plast
    3084:	8b180294 	add	x20, x20, x24
    3088:	9100a273 	add	x19, x19, #0x28
    308c:	a90573fb 	stp	x27, x28, [sp, #80]
    3090:	5280007b 	mov	w27, #0x3                   	// #3
    3094:	8b140a94 	add	x20, x20, x20, lsl #2
    3098:	2a1803fc 	mov	w28, w24
    309c:	9adb2296 	lsl	x22, x20, x27
    30a0:	f949ff35 	ldr	x21, [x25, #5112]
    30a4:	d2800001 	mov	x1, #0x0                   	// #0
    30a8:	8b1302b4 	add	x20, x21, x19
    30ac:	aa1403e0 	mov	x0, x20
    30b0:	97fffee4 	bl	2c40 <fwp_rc_prepare_chunk>
    30b4:	38336abb 	strb	w27, [x21, x19]
    30b8:	9100a273 	add	x19, x19, #0x28
    30bc:	b9000e9c 	str	w28, [x20, #12]
    30c0:	eb1302df 	cmp	x22, x19
    30c4:	54fffee1 	b.ne	30a0 <fwp_heap_alloc_big+0x9c>  // b.any
    30c8:	a94573fb 	ldp	x27, x28, [sp, #80]
    30cc:	91144353 	add	x19, x26, #0x510
    30d0:	aa1703e2 	mov	x2, x23
    30d4:	52800001 	mov	w1, #0x0                   	// #0
    30d8:	f949da60 	ldr	x0, [x19, #5040]
    30dc:	8b184018 	add	x24, x0, x24, lsl #16
    30e0:	aa1803e0 	mov	x0, x24
    30e4:	97fff8e3 	bl	1470 <memset@plt>
    30e8:	f94a1260 	ldr	x0, [x19, #5152]
    30ec:	ab170000 	adds	x0, x0, x23
    30f0:	54000242 	b.cs	3138 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    30f4:	f94a1661 	ldr	x1, [x19, #5160]
    30f8:	f90a1260 	str	x0, [x19, #5152]
    30fc:	eb01001f 	cmp	x0, x1
    3100:	54000049 	b.ls	3108 <fwp_heap_alloc_big+0x104>  // b.plast
    3104:	f90a1660 	str	x0, [x19, #5160]
    3108:	9114435a 	add	x26, x26, #0x510
    310c:	9e6202e0 	scvtf	d0, x23
    3110:	a94153f3 	ldp	x19, x20, [sp, #16]
    3114:	aa1803e0 	mov	x0, x24
    3118:	fd4a1f41 	ldr	d1, [x26, #5176]
    311c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3120:	1e602820 	fadd	d0, d1, d0
    3124:	a94363f7 	ldp	x23, x24, [sp, #48]
    3128:	fd0a1f40 	str	d0, [x26, #5176]
    312c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3130:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3134:	d65f03c0 	ret
    3138:	a90573fb 	stp	x27, x28, [sp, #80]
    313c:	97fffa95 	bl	1b90 <fwp_heap_oom>

0000000000003140 <fwp_heap_alloc_slow>:
    3140:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3144:	910003fd 	mov	x29, sp
    3148:	a90153f3 	stp	x19, x20, [sp, #16]
    314c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    3150:	91144262 	add	x2, x19, #0x510
    3154:	a9025bf5 	stp	x21, x22, [sp, #32]
    3158:	aa0003f5 	mov	x21, x0
    315c:	2a0103f4 	mov	w20, w1
    3160:	b953a440 	ldr	w0, [x2, #5028]
    3164:	34000600 	cbz	w0, 3224 <fwp_heap_alloc_slow+0xe4>
    3168:	f14012bf 	cmp	x21, #0x4, lsl #12
    316c:	54000628 	b.hi	3230 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3170:	91003ea0 	add	x0, x21, #0xf
    3174:	91144262 	add	x2, x19, #0x510
    3178:	f9001bf7 	str	x23, [sp, #48]
    317c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3180:	8b401040 	add	x0, x2, x0, lsr #4
    3184:	cb34c084 	sub	x4, x4, w20, sxtw
    3188:	d37ae484 	lsl	x4, x4, #6
    318c:	397e8003 	ldrb	w3, [x0, #4000]
    3190:	910f0060 	add	x0, x3, #0x3c0
    3194:	aa0303e1 	mov	x1, x3
    3198:	8b030463 	add	x3, x3, x3, lsl #1
    319c:	8b030c83 	add	x3, x4, x3, lsl #3
    31a0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    31a4:	2a1703f6 	mov	w22, w23
    31a8:	f8636844 	ldr	x4, [x2, x3]
    31ac:	b40004e4 	cbz	x4, 3248 <fwp_heap_alloc_slow+0x108>
    31b0:	f9400080 	ldr	x0, [x4]
    31b4:	aa2003e0 	mvn	x0, x0
    31b8:	f8236840 	str	x0, [x2, x3]
    31bc:	7100069f 	cmp	w20, #0x1
    31c0:	aa0403e0 	mov	x0, x4
    31c4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    31c8:	52800001 	mov	w1, #0x0                   	// #0
    31cc:	97fff8a9 	bl	1470 <memset@plt>
    31d0:	aa0003e4 	mov	x4, x0
    31d4:	91144260 	add	x0, x19, #0x510
    31d8:	f94a1001 	ldr	x1, [x0, #5152]
    31dc:	ab160021 	adds	x1, x1, x22
    31e0:	540005c2 	b.cs	3298 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    31e4:	f94a1402 	ldr	x2, [x0, #5160]
    31e8:	f90a1001 	str	x1, [x0, #5152]
    31ec:	eb02003f 	cmp	x1, x2
    31f0:	54000049 	b.ls	31f8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    31f4:	f90a1401 	str	x1, [x0, #5160]
    31f8:	91144273 	add	x19, x19, #0x510
    31fc:	1e6302e1 	ucvtf	d1, w23
    3200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3204:	aa0403e0 	mov	x0, x4
    3208:	fd4a1e60 	ldr	d0, [x19, #5176]
    320c:	f9401bf7 	ldr	x23, [sp, #48]
    3210:	1e612800 	fadd	d0, d0, d1
    3214:	fd0a1e60 	str	d0, [x19, #5176]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3220:	d65f03c0 	ret
    3224:	97fffd33 	bl	26f0 <fwp_heap_init>
    3228:	f14012bf 	cmp	x21, #0x4, lsl #12
    322c:	54fffa29 	b.ls	3170 <fwp_heap_alloc_slow+0x30>  // b.plast
    3230:	2a1403e1 	mov	w1, w20
    3234:	aa1503e0 	mov	x0, x21
    3238:	a94153f3 	ldp	x19, x20, [sp, #16]
    323c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3240:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3244:	17ffff70 	b	3004 <fwp_heap_alloc_big>
    3248:	8b030042 	add	x2, x2, x3
    324c:	f9400444 	ldr	x4, [x2, #8]
    3250:	b4000104 	cbz	x4, 3270 <fwp_heap_alloc_slow+0x130>
    3254:	f9400840 	ldr	x0, [x2, #16]
    3258:	cb040000 	sub	x0, x0, x4
    325c:	eb16001f 	cmp	x0, x22
    3260:	54000083 	b.cc	3270 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3264:	8b160080 	add	x0, x4, x22
    3268:	f9000440 	str	x0, [x2, #8]
    326c:	17ffffd4 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3270:	52800302 	mov	w2, #0x18                  	// #24
    3274:	52807804 	mov	w4, #0x3c0                 	// #960
    3278:	91144260 	add	x0, x19, #0x510
    327c:	9ba27c23 	umull	x3, w1, w2
    3280:	2a1403e2 	mov	w2, w20
    3284:	9b240e84 	smaddl	x4, w20, w4, x3
    3288:	8b040000 	add	x0, x0, x4
    328c:	97fffeb5 	bl	2d60 <fwp_heap_refill>
    3290:	aa0003e4 	mov	x4, x0
    3294:	17ffffca 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3298:	97fffa3e 	bl	1b90 <fwp_heap_oom>
    329c:	d503201f 	nop

00000000000032a0 <fwp_rc_fresh>:
    32a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32a4:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    32a8:	91144063 	add	x3, x3, #0x510
    32ac:	910003fd 	mov	x29, sp
    32b0:	a90153f3 	stp	x19, x20, [sp, #16]
    32b4:	aa0003f3 	mov	x19, x0
    32b8:	f949d861 	ldr	x1, [x3, #5040]
    32bc:	f949ec60 	ldr	x0, [x3, #5080]
    32c0:	cb010261 	sub	x1, x19, x1
    32c4:	eb00403f 	cmp	x1, x0, lsl #16
    32c8:	54000322 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    32cc:	d350fc22 	lsr	x2, x1, #16
    32d0:	f949fc63 	ldr	x3, [x3, #5112]
    32d4:	8b020842 	add	x2, x2, x2, lsl #2
    32d8:	d37df042 	lsl	x2, x2, #3
    32dc:	8b020060 	add	x0, x3, x2
    32e0:	f9401014 	ldr	x20, [x0, #32]
    32e4:	b4000254 	cbz	x20, 332c <fwp_rc_fresh+0x8c>
    32e8:	38626862 	ldrb	w2, [x3, x2]
    32ec:	7100085f 	cmp	w2, #0x2
    32f0:	54000260 	b.eq	333c <fwp_rc_fresh+0x9c>  // b.none
    32f4:	7100045f 	cmp	w2, #0x1
    32f8:	540001a1 	b.ne	332c <fwp_rc_fresh+0x8c>  // b.any
    32fc:	29430002 	ldp	w2, w0, [x0, #24]
    3300:	92403c21 	and	x1, x1, #0xffff
    3304:	9b027c21 	mul	x1, x1, x2
    3308:	d360fc21 	lsr	x1, x1, #32
    330c:	eb00003f 	cmp	x1, x0
    3310:	540000e2 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    3314:	8b010294 	add	x20, x20, x1
    3318:	39400280 	ldrb	w0, [x20]
    331c:	7103fc1f 	cmp	w0, #0xff
    3320:	540001a0 	b.eq	3354 <fwp_rc_fresh+0xb4>  // b.none
    3324:	52800020 	mov	w0, #0x1                   	// #1
    3328:	39000280 	strb	w0, [x20]
    332c:	aa1303e0 	mov	x0, x19
    3330:	a94153f3 	ldp	x19, x20, [sp, #16]
    3334:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3338:	d65f03c0 	ret
    333c:	72003c3f 	tst	w1, #0xffff
    3340:	54fffec0 	b.eq	3318 <fwp_rc_fresh+0x78>  // b.none
    3344:	aa1303e0 	mov	x0, x19
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	aa1403e0 	mov	x0, x20
    3358:	97fffe13 	bl	2ba4 <fwp_rc_forget_slot>
    335c:	17fffff2 	b	3324 <fwp_rc_fresh+0x84>

0000000000003360 <fwp_rc_free_arr>:
    3360:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    3364:	91144063 	add	x3, x3, #0x510
    3368:	f949d861 	ldr	x1, [x3, #5040]
    336c:	f949ec62 	ldr	x2, [x3, #5080]
    3370:	cb010001 	sub	x1, x0, x1
    3374:	eb02403f 	cmp	x1, x2, lsl #16
    3378:	54000342 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    337c:	d350fc22 	lsr	x2, x1, #16
    3380:	f949fc65 	ldr	x5, [x3, #5112]
    3384:	8b020842 	add	x2, x2, x2, lsl #2
    3388:	d37df042 	lsl	x2, x2, #3
    338c:	8b0200a4 	add	x4, x5, x2
    3390:	f9401083 	ldr	x3, [x4, #32]
    3394:	b4000263 	cbz	x3, 33e0 <fwp_rc_free_arr+0x80>
    3398:	386268a2 	ldrb	w2, [x5, x2]
    339c:	7100085f 	cmp	w2, #0x2
    33a0:	540001c0 	b.eq	33d8 <fwp_rc_free_arr+0x78>  // b.none
    33a4:	7100045f 	cmp	w2, #0x1
    33a8:	540001c1 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33ac:	29430885 	ldp	w5, w2, [x4, #24]
    33b0:	92403c21 	and	x1, x1, #0xffff
    33b4:	9b057c21 	mul	x1, x1, x5
    33b8:	d360fc21 	lsr	x1, x1, #32
    33bc:	eb02003f 	cmp	x1, x2
    33c0:	54000102 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    33c4:	8b010063 	add	x3, x3, x1
    33c8:	39400061 	ldrb	w1, [x3]
    33cc:	7100043f 	cmp	w1, #0x1
    33d0:	54000081 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33d4:	17fffe93 	b	2e20 <fwp_mem_free>
    33d8:	72003c3f 	tst	w1, #0xffff
    33dc:	54ffff60 	b.eq	33c8 <fwp_rc_free_arr+0x68>  // b.none
    33e0:	d65f03c0 	ret

00000000000033e4 <fwp_heap_alloc>:
    33e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    33e8:	f140101f 	cmp	x0, #0x4, lsl #12
    33ec:	910003fd 	mov	x29, sp
    33f0:	a90153f3 	stp	x19, x20, [sp, #16]
    33f4:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    33f8:	91144293 	add	x19, x20, #0x510
    33fc:	b953a662 	ldr	w2, [x19, #5028]
    3400:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3404:	54000640 	b.eq	34cc <fwp_heap_alloc+0xe8>  // b.none
    3408:	91003c03 	add	x3, x0, #0xf
    340c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3410:	937c7c22 	sbfiz	x2, x1, #4, #32
    3414:	8b431263 	add	x3, x19, x3, lsr #4
    3418:	cb21c042 	sub	x2, x2, w1, sxtw
    341c:	d37ae442 	lsl	x2, x2, #6
    3420:	397e8063 	ldrb	w3, [x3, #4000]
    3424:	910f0064 	add	x4, x3, #0x3c0
    3428:	8b030463 	add	x3, x3, x3, lsl #1
    342c:	8b030c43 	add	x3, x2, x3, lsl #3
    3430:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3434:	2a1603f5 	mov	w21, w22
    3438:	f8636a64 	ldr	x4, [x19, x3]
    343c:	b4000384 	cbz	x4, 34ac <fwp_heap_alloc+0xc8>
    3440:	f9400085 	ldr	x5, [x4]
    3444:	7100043f 	cmp	w1, #0x1
    3448:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    344c:	aa0403e0 	mov	x0, x4
    3450:	aa2503e5 	mvn	x5, x5
    3454:	52800001 	mov	w1, #0x0                   	// #0
    3458:	f8236a65 	str	x5, [x19, x3]
    345c:	97fff805 	bl	1470 <memset@plt>
    3460:	aa0003e4 	mov	x4, x0
    3464:	f94a1260 	ldr	x0, [x19, #5152]
    3468:	ab150000 	adds	x0, x0, x21
    346c:	54000442 	b.cs	34f4 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    3470:	f94a1661 	ldr	x1, [x19, #5160]
    3474:	f90a1260 	str	x0, [x19, #5152]
    3478:	eb01001f 	cmp	x0, x1
    347c:	54000049 	b.ls	3484 <fwp_heap_alloc+0xa0>  // b.plast
    3480:	f90a1660 	str	x0, [x19, #5160]
    3484:	91144294 	add	x20, x20, #0x510
    3488:	1e6302c1 	ucvtf	d1, w22
    348c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3490:	aa0403e0 	mov	x0, x4
    3494:	fd4a1e80 	ldr	d0, [x20, #5176]
    3498:	1e612800 	fadd	d0, d0, d1
    349c:	fd0a1e80 	str	d0, [x20, #5176]
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34a8:	d65f03c0 	ret
    34ac:	8b030263 	add	x3, x19, x3
    34b0:	f9400464 	ldr	x4, [x3, #8]
    34b4:	b40000a4 	cbz	x4, 34c8 <fwp_heap_alloc+0xe4>
    34b8:	f9400862 	ldr	x2, [x3, #16]
    34bc:	cb040042 	sub	x2, x2, x4
    34c0:	eb15005f 	cmp	x2, x21
    34c4:	540000a2 	b.cs	34d8 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    34c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34d4:	17ffff1b 	b	3140 <fwp_heap_alloc_slow>
    34d8:	7100043f 	cmp	w1, #0x1
    34dc:	8b150085 	add	x5, x4, x21
    34e0:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    34e4:	52800001 	mov	w1, #0x0                   	// #0
    34e8:	aa0403e0 	mov	x0, x4
    34ec:	f9000465 	str	x5, [x3, #8]
    34f0:	17ffffdb 	b	345c <fwp_heap_alloc+0x78>
    34f4:	97fff9a7 	bl	1b90 <fwp_heap_oom>
    34f8:	d503201f 	nop
    34fc:	d503201f 	nop

0000000000003500 <fwp_data.part.0.constprop.0>:
    3500:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3504:	910003fd 	mov	x29, sp
    3508:	a90153f3 	stp	x19, x20, [sp, #16]
    350c:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3510:	91144283 	add	x3, x20, #0x510
    3514:	a9025bf5 	stp	x21, x22, [sp, #32]
    3518:	aa0103f5 	mov	x21, x1
    351c:	b953a461 	ldr	w1, [x3, #5028]
    3520:	a90363f7 	stp	x23, x24, [sp, #48]
    3524:	2a0003f8 	mov	w24, w0
    3528:	34000701 	cbz	w1, 3608 <fwp_data.part.0.constprop.0+0x108>
    352c:	397e8862 	ldrb	w2, [x3, #4002]
    3530:	910f0040 	add	x0, x2, #0x3c0
    3534:	8b020442 	add	x2, x2, x2, lsl #1
    3538:	d37df042 	lsl	x2, x2, #3
    353c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    3540:	2a1703f6 	mov	w22, w23
    3544:	f8626873 	ldr	x19, [x3, x2]
    3548:	b40004d3 	cbz	x19, 35e0 <fwp_data.part.0.constprop.0+0xe0>
    354c:	f9400260 	ldr	x0, [x19]
    3550:	aa2003e0 	mvn	x0, x0
    3554:	f8226860 	str	x0, [x3, x2]
    3558:	f10062df 	cmp	x22, #0x18
    355c:	540000e9 	b.ls	3578 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    3560:	d10066c2 	sub	x2, x22, #0x19
    3564:	91006260 	add	x0, x19, #0x18
    3568:	927df042 	and	x2, x2, #0xfffffffffffffff8
    356c:	52800001 	mov	w1, #0x0                   	// #0
    3570:	91002042 	add	x2, x2, #0x8
    3574:	97fff7bf 	bl	1470 <memset@plt>
    3578:	91144282 	add	x2, x20, #0x510
    357c:	f94a1041 	ldr	x1, [x2, #5152]
    3580:	ab160021 	adds	x1, x1, x22
    3584:	540004c2 	b.cs	361c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    3588:	f94a1440 	ldr	x0, [x2, #5160]
    358c:	f90a1041 	str	x1, [x2, #5152]
    3590:	eb00003f 	cmp	x1, x0
    3594:	54000049 	b.ls	359c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    3598:	f90a1441 	str	x1, [x2, #5160]
    359c:	91144294 	add	x20, x20, #0x510
    35a0:	1e6302e1 	ucvtf	d1, w23
    35a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    35a8:	1e612800 	fadd	d0, d0, d1
    35ac:	fd0a1e80 	str	d0, [x20, #5176]
    35b0:	52800041 	mov	w1, #0x2                   	// #2
    35b4:	29000678 	stp	w24, w1, [x19]
    35b8:	aa1303e0 	mov	x0, x19
    35bc:	f94002a1 	ldr	x1, [x21]
    35c0:	f9000661 	str	x1, [x19, #8]
    35c4:	f94006a1 	ldr	x1, [x21, #8]
    35c8:	f9000a61 	str	x1, [x19, #16]
    35cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    35d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    35d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35dc:	d65f03c0 	ret
    35e0:	8b020063 	add	x3, x3, x2
    35e4:	f9400473 	ldr	x19, [x3, #8]
    35e8:	b4000113 	cbz	x19, 3608 <fwp_data.part.0.constprop.0+0x108>
    35ec:	f9400860 	ldr	x0, [x3, #16]
    35f0:	cb130000 	sub	x0, x0, x19
    35f4:	eb0002df 	cmp	x22, x0
    35f8:	54000088 	b.hi	3608 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    35fc:	8b160260 	add	x0, x19, x22
    3600:	f9000460 	str	x0, [x3, #8]
    3604:	17ffffd5 	b	3558 <fwp_data.part.0.constprop.0+0x58>
    3608:	52800001 	mov	w1, #0x0                   	// #0
    360c:	d2800300 	mov	x0, #0x18                  	// #24
    3610:	97ffff75 	bl	33e4 <fwp_heap_alloc>
    3614:	aa0003f3 	mov	x19, x0
    3618:	17ffffe6 	b	35b0 <fwp_data.part.0.constprop.0+0xb0>
    361c:	97fff95d 	bl	1b90 <fwp_heap_oom>

0000000000003620 <fwp_array_new_packed.constprop.0>:
    3620:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3624:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3628:	910003fd 	mov	x29, sp
    362c:	f9000bf3 	str	x19, [sp, #16]
    3630:	eb01001f 	cmp	x0, x1
    3634:	54000148 	b.hi	365c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    3638:	aa0003f3 	mov	x19, x0
    363c:	91000400 	add	x0, x0, #0x1
    3640:	52800021 	mov	w1, #0x1                   	// #1
    3644:	d37df000 	lsl	x0, x0, #3
    3648:	97ffff67 	bl	33e4 <fwp_heap_alloc>
    364c:	f9000013 	str	x19, [x0]
    3650:	f9400bf3 	ldr	x19, [sp, #16]
    3654:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3658:	d65f03c0 	ret
    365c:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    3660:	910cc000 	add	x0, x0, #0x330
    3664:	97fffa8f 	bl	20a0 <fwp_trap>
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_drop0>:
    3670:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3674:	910003fd 	mov	x29, sp
    3678:	a90153f3 	stp	x19, x20, [sp, #16]
    367c:	f90013f5 	str	x21, [sp, #32]
    3680:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    3684:	911442b4 	add	x20, x21, #0x510
    3688:	f949da81 	ldr	x1, [x20, #5040]
    368c:	f949ee82 	ldr	x2, [x20, #5080]
    3690:	cb010001 	sub	x1, x0, x1
    3694:	eb02403f 	cmp	x1, x2, lsl #16
    3698:	54000382 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    369c:	d350fc22 	lsr	x2, x1, #16
    36a0:	f949fe84 	ldr	x4, [x20, #5112]
    36a4:	8b020842 	add	x2, x2, x2, lsl #2
    36a8:	d37df042 	lsl	x2, x2, #3
    36ac:	8b020083 	add	x3, x4, x2
    36b0:	f9401073 	ldr	x19, [x3, #32]
    36b4:	b40002b3 	cbz	x19, 3708 <fwp_drop0+0x98>
    36b8:	38626882 	ldrb	w2, [x4, x2]
    36bc:	7100085f 	cmp	w2, #0x2
    36c0:	540002c0 	b.eq	3718 <fwp_drop0+0xa8>  // b.none
    36c4:	7100045f 	cmp	w2, #0x1
    36c8:	54000201 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    36cc:	29430864 	ldp	w4, w2, [x3, #24]
    36d0:	92403c21 	and	x1, x1, #0xffff
    36d4:	9b047c21 	mul	x1, x1, x4
    36d8:	d360fc21 	lsr	x1, x1, #32
    36dc:	eb02003f 	cmp	x1, x2
    36e0:	54000142 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    36e4:	8b010273 	add	x19, x19, x1
    36e8:	39400261 	ldrb	w1, [x19]
    36ec:	340000e1 	cbz	w1, 3708 <fwp_drop0+0x98>
    36f0:	7100043f 	cmp	w1, #0x1
    36f4:	540001e0 	b.eq	3730 <fwp_drop0+0xc0>  // b.none
    36f8:	7103fc3f 	cmp	w1, #0xff
    36fc:	540002e0 	b.eq	3758 <fwp_drop0+0xe8>  // b.none
    3700:	51000421 	sub	w1, w1, #0x1
    3704:	39000261 	strb	w1, [x19]
    3708:	a94153f3 	ldp	x19, x20, [sp, #16]
    370c:	f94013f5 	ldr	x21, [sp, #32]
    3710:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3714:	d65f03c0 	ret
    3718:	72003c3f 	tst	w1, #0xffff
    371c:	54fffe60 	b.eq	36e8 <fwp_drop0+0x78>  // b.none
    3720:	a94153f3 	ldp	x19, x20, [sp, #16]
    3724:	f94013f5 	ldr	x21, [sp, #32]
    3728:	a8c37bfd 	ldp	x29, x30, [sp], #48
    372c:	d65f03c0 	ret
    3730:	f9400813 	ldr	x19, [x0, #16]
    3734:	97ffff0b 	bl	3360 <fwp_rc_free_arr>
    3738:	911442a0 	add	x0, x21, #0x510
    373c:	f949d801 	ldr	x1, [x0, #5040]
    3740:	f949ec00 	ldr	x0, [x0, #5080]
    3744:	cb010261 	sub	x1, x19, x1
    3748:	eb00403f 	cmp	x1, x0, lsl #16
    374c:	54fffde2 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    3750:	aa1303e0 	mov	x0, x19
    3754:	17ffffd2 	b	369c <fwp_drop0+0x2c>
    3758:	ca534660 	eor	x0, x19, x19, lsr #17
    375c:	911442b5 	add	x21, x21, #0x510
    3760:	ca402400 	eor	x0, x0, x0, lsr #9
    3764:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3768:	f94a2400 	ldr	x0, [x0, #5192]
    376c:	b5000080 	cbnz	x0, 377c <fwp_drop0+0x10c>
    3770:	14000010 	b	37b0 <fwp_drop0+0x140>
    3774:	f9400800 	ldr	x0, [x0, #16]
    3778:	b40001c0 	cbz	x0, 37b0 <fwp_drop0+0x140>
    377c:	f9400001 	ldr	x1, [x0]
    3780:	eb13003f 	cmp	x1, x19
    3784:	54ffff81 	b.ne	3774 <fwp_drop0+0x104>  // b.any
    3788:	f9400401 	ldr	x1, [x0, #8]
    378c:	d1000421 	sub	x1, x1, #0x1
    3790:	f9000401 	str	x1, [x0, #8]
    3794:	f103f83f 	cmp	x1, #0xfe
    3798:	54fffb81 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    379c:	aa1303e0 	mov	x0, x19
    37a0:	97fffd01 	bl	2ba4 <fwp_rc_forget_slot>
    37a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    37a8:	39000260 	strb	w0, [x19]
    37ac:	17ffffd7 	b	3708 <fwp_drop0+0x98>
    37b0:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    37b4:	910c2000 	add	x0, x0, #0x308
    37b8:	97fffa3a 	bl	20a0 <fwp_trap>
    37bc:	d503201f 	nop

00000000000037c0 <fwp_drop1>:
    37c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37c4:	910003fd 	mov	x29, sp
    37c8:	a90153f3 	stp	x19, x20, [sp, #16]
    37cc:	f90013f5 	str	x21, [sp, #32]
    37d0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    37d4:	911442b4 	add	x20, x21, #0x510
    37d8:	f949da81 	ldr	x1, [x20, #5040]
    37dc:	f949ee82 	ldr	x2, [x20, #5080]
    37e0:	cb010001 	sub	x1, x0, x1
    37e4:	eb02403f 	cmp	x1, x2, lsl #16
    37e8:	54000382 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    37ec:	d350fc22 	lsr	x2, x1, #16
    37f0:	f949fe84 	ldr	x4, [x20, #5112]
    37f4:	8b020842 	add	x2, x2, x2, lsl #2
    37f8:	d37df042 	lsl	x2, x2, #3
    37fc:	8b020083 	add	x3, x4, x2
    3800:	f9401073 	ldr	x19, [x3, #32]
    3804:	b40002b3 	cbz	x19, 3858 <fwp_drop1+0x98>
    3808:	38626882 	ldrb	w2, [x4, x2]
    380c:	7100085f 	cmp	w2, #0x2
    3810:	540002c0 	b.eq	3868 <fwp_drop1+0xa8>  // b.none
    3814:	7100045f 	cmp	w2, #0x1
    3818:	54000201 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    381c:	29430864 	ldp	w4, w2, [x3, #24]
    3820:	92403c21 	and	x1, x1, #0xffff
    3824:	9b047c21 	mul	x1, x1, x4
    3828:	d360fc21 	lsr	x1, x1, #32
    382c:	eb02003f 	cmp	x1, x2
    3830:	54000142 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    3834:	8b010273 	add	x19, x19, x1
    3838:	39400261 	ldrb	w1, [x19]
    383c:	340000e1 	cbz	w1, 3858 <fwp_drop1+0x98>
    3840:	7100043f 	cmp	w1, #0x1
    3844:	540001e0 	b.eq	3880 <fwp_drop1+0xc0>  // b.none
    3848:	7103fc3f 	cmp	w1, #0xff
    384c:	540002e0 	b.eq	38a8 <fwp_drop1+0xe8>  // b.none
    3850:	51000421 	sub	w1, w1, #0x1
    3854:	39000261 	strb	w1, [x19]
    3858:	a94153f3 	ldp	x19, x20, [sp, #16]
    385c:	f94013f5 	ldr	x21, [sp, #32]
    3860:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3864:	d65f03c0 	ret
    3868:	72003c3f 	tst	w1, #0xffff
    386c:	54fffe60 	b.eq	3838 <fwp_drop1+0x78>  // b.none
    3870:	a94153f3 	ldp	x19, x20, [sp, #16]
    3874:	f94013f5 	ldr	x21, [sp, #32]
    3878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    387c:	d65f03c0 	ret
    3880:	f9400813 	ldr	x19, [x0, #16]
    3884:	97fffeb7 	bl	3360 <fwp_rc_free_arr>
    3888:	911442a0 	add	x0, x21, #0x510
    388c:	f949d801 	ldr	x1, [x0, #5040]
    3890:	f949ec00 	ldr	x0, [x0, #5080]
    3894:	cb010261 	sub	x1, x19, x1
    3898:	eb00403f 	cmp	x1, x0, lsl #16
    389c:	54fffde2 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    38a0:	aa1303e0 	mov	x0, x19
    38a4:	17ffffd2 	b	37ec <fwp_drop1+0x2c>
    38a8:	ca534660 	eor	x0, x19, x19, lsr #17
    38ac:	911442b5 	add	x21, x21, #0x510
    38b0:	ca402400 	eor	x0, x0, x0, lsr #9
    38b4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    38b8:	f94a2400 	ldr	x0, [x0, #5192]
    38bc:	b5000080 	cbnz	x0, 38cc <fwp_drop1+0x10c>
    38c0:	14000010 	b	3900 <fwp_drop1+0x140>
    38c4:	f9400800 	ldr	x0, [x0, #16]
    38c8:	b40001c0 	cbz	x0, 3900 <fwp_drop1+0x140>
    38cc:	f9400001 	ldr	x1, [x0]
    38d0:	eb13003f 	cmp	x1, x19
    38d4:	54ffff81 	b.ne	38c4 <fwp_drop1+0x104>  // b.any
    38d8:	f9400401 	ldr	x1, [x0, #8]
    38dc:	d1000421 	sub	x1, x1, #0x1
    38e0:	f9000401 	str	x1, [x0, #8]
    38e4:	f103f83f 	cmp	x1, #0xfe
    38e8:	54fffb81 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    38ec:	aa1303e0 	mov	x0, x19
    38f0:	97fffcad 	bl	2ba4 <fwp_rc_forget_slot>
    38f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    38f8:	39000260 	strb	w0, [x19]
    38fc:	17ffffd7 	b	3858 <fwp_drop1+0x98>
    3900:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    3904:	910c2000 	add	x0, x0, #0x308
    3908:	97fff9e6 	bl	20a0 <fwp_trap>
    390c:	d503201f 	nop

0000000000003910 <fwp_task_dispose>:
    3910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3914:	910003fd 	mov	x29, sp
    3918:	f9000bf3 	str	x19, [sp, #16]
    391c:	aa0003f3 	mov	x19, x0
    3920:	39414000 	ldrb	w0, [x0, #80]
    3924:	36000720 	tbz	w0, #0, 3a08 <fwp_task_dispose+0xf8>
    3928:	f9400a60 	ldr	x0, [x19, #16]
    392c:	b50006e0 	cbnz	x0, 3a08 <fwp_task_dispose+0xf8>
    3930:	a9478660 	ldp	x0, x1, [x19, #120]
    3934:	39014e7f 	strb	wzr, [x19, #83]
    3938:	f9003e7f 	str	xzr, [x19, #120]
    393c:	f100003f 	cmp	x1, #0x0
    3940:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3944:	54000040 	b.eq	394c <fwp_task_dispose+0x3c>  // b.none
    3948:	d63f0020 	blr	x1
    394c:	f9405660 	ldr	x0, [x19, #168]
    3950:	97fffd34 	bl	2e20 <fwp_mem_free>
    3954:	f900567f 	str	xzr, [x19, #168]
    3958:	b9405e60 	ldr	w0, [x19, #92]
    395c:	7100041f 	cmp	w0, #0x1
    3960:	54000420 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    3964:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    3968:	91144042 	add	x2, x2, #0x510
    396c:	f949d840 	ldr	x0, [x2, #5040]
    3970:	f949ec41 	ldr	x1, [x2, #5080]
    3974:	cb000260 	sub	x0, x19, x0
    3978:	eb01401f 	cmp	x0, x1, lsl #16
    397c:	540002e2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3980:	d350fc01 	lsr	x1, x0, #16
    3984:	f949fc44 	ldr	x4, [x2, #5112]
    3988:	8b010821 	add	x1, x1, x1, lsl #2
    398c:	d37df021 	lsl	x1, x1, #3
    3990:	8b010083 	add	x3, x4, x1
    3994:	f9401062 	ldr	x2, [x3, #32]
    3998:	b4000202 	cbz	x2, 39d8 <fwp_task_dispose+0xc8>
    399c:	38616881 	ldrb	w1, [x4, x1]
    39a0:	7100083f 	cmp	w1, #0x2
    39a4:	54000280 	b.eq	39f4 <fwp_task_dispose+0xe4>  // b.none
    39a8:	7100043f 	cmp	w1, #0x1
    39ac:	54000161 	b.ne	39d8 <fwp_task_dispose+0xc8>  // b.any
    39b0:	29430464 	ldp	w4, w1, [x3, #24]
    39b4:	92403c00 	and	x0, x0, #0xffff
    39b8:	9b047c00 	mul	x0, x0, x4
    39bc:	d360fc00 	lsr	x0, x0, #32
    39c0:	eb01001f 	cmp	x0, x1
    39c4:	540000a2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    39c8:	8b000042 	add	x2, x2, x0
    39cc:	39400040 	ldrb	w0, [x2]
    39d0:	7100041f 	cmp	w0, #0x1
    39d4:	54000080 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    39d8:	f9400bf3 	ldr	x19, [sp, #16]
    39dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39e0:	d65f03c0 	ret
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	f9400bf3 	ldr	x19, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	17fffd0c 	b	2e20 <fwp_mem_free>
    39f4:	72003c1f 	tst	w0, #0xffff
    39f8:	54fffea0 	b.eq	39cc <fwp_task_dispose+0xbc>  // b.none
    39fc:	f9400bf3 	ldr	x19, [sp, #16]
    3a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a04:	d65f03c0 	ret
    3a08:	97fff6ba 	bl	14f0 <abort@plt>
    3a0c:	d503201f 	nop

0000000000003a10 <fwp_free_zombie>:
    3a10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3a14:	910003fd 	mov	x29, sp
    3a18:	a90153f3 	stp	x19, x20, [sp, #16]
    3a1c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3a20:	9101c281 	add	x1, x20, #0x70
    3a24:	f9401c33 	ldr	x19, [x1, #56]
    3a28:	b4000333 	cbz	x19, 3a8c <fwp_free_zombie+0x7c>
    3a2c:	f9400420 	ldr	x0, [x1, #8]
    3a30:	eb00027f 	cmp	x19, x0
    3a34:	540002c0 	b.eq	3a8c <fwp_free_zombie+0x7c>  // b.none
    3a38:	b9404022 	ldr	w2, [x1, #64]
    3a3c:	f9400a60 	ldr	x0, [x19, #16]
    3a40:	7100fc5f 	cmp	w2, #0x3f
    3a44:	5400078c 	b.gt	3b34 <fwp_free_zombie+0x124>
    3a48:	91014023 	add	x3, x1, #0x50
    3a4c:	11000444 	add	w4, w2, #0x1
    3a50:	b9004024 	str	w4, [x1, #64]
    3a54:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a58:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3a5c:	a9530261 	ldp	x1, x0, [x19, #304]
    3a60:	b4000741 	cbz	x1, 3b48 <fwp_free_zombie+0x138>
    3a64:	f9009c20 	str	x0, [x1, #312]
    3a68:	b4000040 	cbz	x0, 3a70 <fwp_free_zombie+0x60>
    3a6c:	f9009801 	str	x1, [x0, #304]
    3a70:	9101c294 	add	x20, x20, #0x70
    3a74:	b9405e60 	ldr	w0, [x19, #92]
    3a78:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3a7c:	f9001e9f 	str	xzr, [x20, #56]
    3a80:	34000140 	cbz	w0, 3aa8 <fwp_free_zombie+0x98>
    3a84:	7100041f 	cmp	w0, #0x1
    3a88:	54000080 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3a8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a94:	d65f03c0 	ret
    3a98:	aa1303e0 	mov	x0, x19
    3a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3aa4:	17ffff9b 	b	3910 <fwp_task_dispose>
    3aa8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcd0>
    3aac:	91144082 	add	x2, x4, #0x510
    3ab0:	f949d841 	ldr	x1, [x2, #5040]
    3ab4:	f949ec40 	ldr	x0, [x2, #5080]
    3ab8:	cb010261 	sub	x1, x19, x1
    3abc:	eb00403f 	cmp	x1, x0, lsl #16
    3ac0:	54fffe62 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3ac4:	d350fc20 	lsr	x0, x1, #16
    3ac8:	f949fc43 	ldr	x3, [x2, #5112]
    3acc:	8b000800 	add	x0, x0, x0, lsl #2
    3ad0:	d37df000 	lsl	x0, x0, #3
    3ad4:	8b000062 	add	x2, x3, x0
    3ad8:	f9401054 	ldr	x20, [x2, #32]
    3adc:	b4fffd94 	cbz	x20, 3a8c <fwp_free_zombie+0x7c>
    3ae0:	38606860 	ldrb	w0, [x3, x0]
    3ae4:	7100081f 	cmp	w0, #0x2
    3ae8:	54000360 	b.eq	3b54 <fwp_free_zombie+0x144>  // b.none
    3aec:	7100041f 	cmp	w0, #0x1
    3af0:	54fffce1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3af4:	29430043 	ldp	w3, w0, [x2, #24]
    3af8:	92403c21 	and	x1, x1, #0xffff
    3afc:	9b037c21 	mul	x1, x1, x3
    3b00:	d360fc21 	lsr	x1, x1, #32
    3b04:	eb00003f 	cmp	x1, x0
    3b08:	54fffc22 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3b0c:	8b010294 	add	x20, x20, x1
    3b10:	39400280 	ldrb	w0, [x20]
    3b14:	34fffbc0 	cbz	w0, 3a8c <fwp_free_zombie+0x7c>
    3b18:	7100041f 	cmp	w0, #0x1
    3b1c:	54fffbe0 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3b20:	7103fc1f 	cmp	w0, #0xff
    3b24:	540001e0 	b.eq	3b60 <fwp_free_zombie+0x150>  // b.none
    3b28:	51000400 	sub	w0, w0, #0x1
    3b2c:	39000280 	strb	w0, [x20]
    3b30:	17ffffd7 	b	3a8c <fwp_free_zombie+0x7c>
    3b34:	f9400e61 	ldr	x1, [x19, #24]
    3b38:	97fff6a2 	bl	15c0 <munmap@plt>
    3b3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3b40:	a9530261 	ldp	x1, x0, [x19, #304]
    3b44:	b5fff901 	cbnz	x1, 3a64 <fwp_free_zombie+0x54>
    3b48:	9101c282 	add	x2, x20, #0x70
    3b4c:	f9012840 	str	x0, [x2, #592]
    3b50:	17ffffc6 	b	3a68 <fwp_free_zombie+0x58>
    3b54:	72003c3f 	tst	w1, #0xffff
    3b58:	54fff9a1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3b5c:	17ffffed 	b	3b10 <fwp_free_zombie+0x100>
    3b60:	ca544680 	eor	x0, x20, x20, lsr #17
    3b64:	91144084 	add	x4, x4, #0x510
    3b68:	ca402400 	eor	x0, x0, x0, lsr #9
    3b6c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3b70:	f94a2400 	ldr	x0, [x0, #5192]
    3b74:	b5000080 	cbnz	x0, 3b84 <fwp_free_zombie+0x174>
    3b78:	14000010 	b	3bb8 <fwp_free_zombie+0x1a8>
    3b7c:	f9400800 	ldr	x0, [x0, #16]
    3b80:	b40001c0 	cbz	x0, 3bb8 <fwp_free_zombie+0x1a8>
    3b84:	f9400001 	ldr	x1, [x0]
    3b88:	eb14003f 	cmp	x1, x20
    3b8c:	54ffff81 	b.ne	3b7c <fwp_free_zombie+0x16c>  // b.any
    3b90:	f9400401 	ldr	x1, [x0, #8]
    3b94:	d1000421 	sub	x1, x1, #0x1
    3b98:	f9000401 	str	x1, [x0, #8]
    3b9c:	f103f83f 	cmp	x1, #0xfe
    3ba0:	54fff761 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3ba4:	aa1403e0 	mov	x0, x20
    3ba8:	97fffbff 	bl	2ba4 <fwp_rc_forget_slot>
    3bac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3bb0:	39000280 	strb	w0, [x20]
    3bb4:	17ffffb6 	b	3a8c <fwp_free_zombie+0x7c>
    3bb8:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    3bbc:	910c2000 	add	x0, x0, #0x308
    3bc0:	97fff938 	bl	20a0 <fwp_trap>

0000000000003bc4 <fwp_block>:
    3bc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bc8:	910003fd 	mov	x29, sp
    3bcc:	a90153f3 	stp	x19, x20, [sp, #16]
    3bd0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3bd4:	9101c274 	add	x20, x19, #0x70
    3bd8:	f9401682 	ldr	x2, [x20, #40]
    3bdc:	b4000622 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3be0:	9101c261 	add	x1, x19, #0x70
    3be4:	f9408040 	ldr	x0, [x2, #256]
    3be8:	f9001420 	str	x0, [x1, #40]
    3bec:	b4000680 	cbz	x0, 3cbc <fwp_block+0xf8>
    3bf0:	9101c263 	add	x3, x19, #0x70
    3bf4:	3901505f 	strb	wzr, [x2, #84]
    3bf8:	f9400464 	ldr	x4, [x3, #8]
    3bfc:	eb02009f 	cmp	x4, x2
    3c00:	54000440 	b.eq	3c88 <fwp_block+0xc4>  // b.none
    3c04:	f9412c65 	ldr	x5, [x3, #600]
    3c08:	f9000462 	str	x2, [x3, #8]
    3c0c:	f9400441 	ldr	x1, [x2, #8]
    3c10:	f9004885 	str	x5, [x4, #144]
    3c14:	f9413065 	ldr	x5, [x3, #608]
    3c18:	f9004c85 	str	x5, [x4, #152]
    3c1c:	f9413465 	ldr	x5, [x3, #616]
    3c20:	f9005085 	str	x5, [x4, #160]
    3c24:	f9413865 	ldr	x5, [x3, #624]
    3c28:	f9005485 	str	x5, [x4, #168]
    3c2c:	f9413c65 	ldr	x5, [x3, #632]
    3c30:	f9005885 	str	x5, [x4, #176]
    3c34:	f9414065 	ldr	x5, [x3, #640]
    3c38:	f9005c85 	str	x5, [x4, #184]
    3c3c:	f9414465 	ldr	x5, [x3, #648]
    3c40:	f9006085 	str	x5, [x4, #192]
    3c44:	f9400480 	ldr	x0, [x4, #8]
    3c48:	f9404844 	ldr	x4, [x2, #144]
    3c4c:	f9012c64 	str	x4, [x3, #600]
    3c50:	f9404c44 	ldr	x4, [x2, #152]
    3c54:	f9013064 	str	x4, [x3, #608]
    3c58:	f9405044 	ldr	x4, [x2, #160]
    3c5c:	f9013464 	str	x4, [x3, #616]
    3c60:	f9405444 	ldr	x4, [x2, #168]
    3c64:	f9013864 	str	x4, [x3, #624]
    3c68:	f9405844 	ldr	x4, [x2, #176]
    3c6c:	f9013c64 	str	x4, [x3, #632]
    3c70:	a94b8844 	ldp	x4, x2, [x2, #184]
    3c74:	f9014064 	str	x4, [x3, #640]
    3c78:	f9014462 	str	x2, [x3, #648]
    3c7c:	97fff621 	bl	1500 <swapcontext@plt>
    3c80:	97ffff64 	bl	3a10 <fwp_free_zombie>
    3c84:	d503201f 	nop
    3c88:	9101c260 	add	x0, x19, #0x70
    3c8c:	b9429000 	ldr	w0, [x0, #656]
    3c90:	340001a0 	cbz	w0, 3cc4 <fwp_block+0x100>
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c9c:	d65f03c0 	ret
    3ca0:	97fffb34 	bl	2970 <fwp_poll_events>
    3ca4:	f9401682 	ldr	x2, [x20, #40]
    3ca8:	b4ffffc2 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3cac:	9101c261 	add	x1, x19, #0x70
    3cb0:	f9408040 	ldr	x0, [x2, #256]
    3cb4:	f9001420 	str	x0, [x1, #40]
    3cb8:	b5fff9c0 	cbnz	x0, 3bf0 <fwp_block+0x2c>
    3cbc:	f900103f 	str	xzr, [x1, #32]
    3cc0:	17ffffcc 	b	3bf0 <fwp_block+0x2c>
    3cc4:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    3cc8:	910d0000 	add	x0, x0, #0x340
    3ccc:	97fff659 	bl	1630 <getenv@plt>
    3cd0:	5284e202 	mov	w2, #0x2710                	// #10000
    3cd4:	b4000060 	cbz	x0, 3ce0 <fwp_block+0x11c>
    3cd8:	39400001 	ldrb	w1, [x0]
    3cdc:	350000c1 	cbnz	w1, 3cf4 <fwp_block+0x130>
    3ce0:	9101c273 	add	x19, x19, #0x70
    3ce4:	b9029262 	str	w2, [x19, #656]
    3ce8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cf0:	d65f03c0 	ret
    3cf4:	52800142 	mov	w2, #0xa                   	// #10
    3cf8:	d2800001 	mov	x1, #0x0                   	// #0
    3cfc:	97fff59d 	bl	1370 <strtoll@plt>
    3d00:	d1000403 	sub	x3, x0, #0x1
    3d04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3d08:	eb02007f 	cmp	x3, x2
    3d0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3d10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3d14:	17fffff3 	b	3ce0 <fwp_block+0x11c>
    3d18:	d503201f 	nop
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_write.constprop.0>:
    3d20:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3d24:	910003fd 	mov	x29, sp
    3d28:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14c18>
    3d2c:	f947f463 	ldr	x3, [x3, #4072]
    3d30:	a90153f3 	stp	x19, x20, [sp, #16]
    3d34:	d10943ff 	sub	sp, sp, #0x250
    3d38:	aa0003f4 	mov	x20, x0
    3d3c:	b9400040 	ldr	w0, [x2]
    3d40:	aa0103f3 	mov	x19, x1
    3d44:	f9400061 	ldr	x1, [x3]
    3d48:	f90127e1 	str	x1, [sp, #584]
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	7100641f 	cmp	w0, #0x19
    3d54:	540003e8 	b.hi	3dd0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3d58:	d0000021 	adrp	x1, 9000 <__modti3+0x260>
    3d5c:	9117c021 	add	x1, x1, #0x5f0
    3d60:	f9013bf5 	str	x21, [sp, #624]
    3d64:	f9013ff6 	str	x22, [sp, #632]
    3d68:	f90153fb 	str	x27, [sp, #672]
    3d6c:	f90157fc 	str	x28, [sp, #680]
    3d70:	aa0203fc 	mov	x28, x2
    3d74:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3d78:	10000062 	adr	x2, 3d84 <fwp_write.constprop.0+0x64>
    3d7c:	8b21a841 	add	x1, x2, w1, sxth #2
    3d80:	d61f0020 	br	x1
    3d84:	910123e0 	add	x0, sp, #0x48
    3d88:	aa1303e5 	mov	x5, x19
    3d8c:	d0000024 	adrp	x4, 9000 <__modti3+0x260>
    3d90:	aa0003f3 	mov	x19, x0
    3d94:	910e2084 	add	x4, x4, #0x388
    3d98:	d2804003 	mov	x3, #0x200                 	// #512
    3d9c:	aa0303e1 	mov	x1, x3
    3da0:	52800042 	mov	w2, #0x2                   	// #2
    3da4:	97fff59b 	bl	1410 <__snprintf_chk@plt>
    3da8:	aa1303e0 	mov	x0, x19
    3dac:	97fff561 	bl	1330 <strlen@plt>
    3db0:	aa1303e1 	mov	x1, x19
    3db4:	aa0003e2 	mov	x2, x0
    3db8:	aa1403e0 	mov	x0, x20
    3dbc:	97fff85d 	bl	1f30 <buf_put>
    3dc0:	f9413bf5 	ldr	x21, [sp, #624]
    3dc4:	f9413ff6 	ldr	x22, [sp, #632]
    3dc8:	f94153fb 	ldr	x27, [sp, #672]
    3dcc:	f94157fc 	ldr	x28, [sp, #680]
    3dd0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    3dd4:	f947f400 	ldr	x0, [x0, #4072]
    3dd8:	f94127e2 	ldr	x2, [sp, #584]
    3ddc:	f9400001 	ldr	x1, [x0]
    3de0:	eb010042 	subs	x2, x2, x1
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	540074a1 	b.ne	4c7c <fwp_write.constprop.0+0xf5c>  // b.any
    3dec:	910943ff 	add	sp, sp, #0x250
    3df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3df4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3df8:	d65f03c0 	ret
    3dfc:	910123e0 	add	x0, sp, #0x48
    3e00:	aa1303e5 	mov	x5, x19
    3e04:	d0000024 	adrp	x4, 9000 <__modti3+0x260>
    3e08:	aa0003f3 	mov	x19, x0
    3e0c:	910e0084 	add	x4, x4, #0x380
    3e10:	d2804003 	mov	x3, #0x200                 	// #512
    3e14:	17ffffe2 	b	3d9c <fwp_write.constprop.0+0x7c>
    3e18:	71004c1f 	cmp	w0, #0x13
    3e1c:	d0000021 	adrp	x1, 9000 <__modti3+0x260>
    3e20:	d0000020 	adrp	x0, 9000 <__modti3+0x260>
    3e24:	910de021 	add	x1, x1, #0x378
    3e28:	910dc000 	add	x0, x0, #0x370
    3e2c:	d2800082 	mov	x2, #0x4                   	// #4
    3e30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    3e34:	aa1403e0 	mov	x0, x20
    3e38:	f90143f7 	str	x23, [sp, #640]
    3e3c:	d2800016 	mov	x22, #0x0                   	// #0
    3e40:	f90147f8 	str	x24, [sp, #648]
    3e44:	97fff83b 	bl	1f30 <buf_put>
    3e48:	f9400260 	ldr	x0, [x19]
    3e4c:	d0000037 	adrp	x23, 9000 <__modti3+0x260>
    3e50:	d2800015 	mov	x21, #0x0                   	// #0
    3e54:	910fe2f7 	add	x23, x23, #0x3f8
    3e58:	b4004e40 	cbz	x0, 4820 <fwp_write.constprop.0+0xb00>
    3e5c:	b9400381 	ldr	w1, [x28]
    3e60:	aa1403e0 	mov	x0, x20
    3e64:	f9401f82 	ldr	x2, [x28, #56]
    3e68:	71004c3f 	cmp	w1, #0x13
    3e6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    3e70:	8b010e61 	add	x1, x19, x1, lsl #3
    3e74:	f9400421 	ldr	x1, [x1, #8]
    3e78:	97ffffaa 	bl	3d20 <fwp_write.constprop.0>
    3e7c:	b9400380 	ldr	w0, [x28]
    3e80:	7100481f 	cmp	w0, #0x12
    3e84:	540050c0 	b.eq	489c <fwp_write.constprop.0+0xb7c>  // b.none
    3e88:	f9400260 	ldr	x0, [x19]
    3e8c:	910006b5 	add	x21, x21, #0x1
    3e90:	91000ad6 	add	x22, x22, #0x2
    3e94:	eb0002bf 	cmp	x21, x0
    3e98:	54004c42 	b.cs	4820 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    3e9c:	aa1703e1 	mov	x1, x23
    3ea0:	aa1403e0 	mov	x0, x20
    3ea4:	d2800042 	mov	x2, #0x2                   	// #2
    3ea8:	97fff822 	bl	1f30 <buf_put>
    3eac:	17ffffec 	b	3e5c <fwp_write.constprop.0+0x13c>
    3eb0:	d0000021 	adrp	x1, 9000 <__modti3+0x260>
    3eb4:	910ec021 	add	x1, x1, #0x3b0
    3eb8:	d28000c2 	mov	x2, #0x6                   	// #6
    3ebc:	aa1403e0 	mov	x0, x20
    3ec0:	91004273 	add	x19, x19, #0x10
    3ec4:	97fff81b 	bl	1f30 <buf_put>
    3ec8:	aa1303e0 	mov	x0, x19
    3ecc:	97fff519 	bl	1330 <strlen@plt>
    3ed0:	aa1303e1 	mov	x1, x19
    3ed4:	aa0003e2 	mov	x2, x0
    3ed8:	aa1403e0 	mov	x0, x20
    3edc:	97fff815 	bl	1f30 <buf_put>
    3ee0:	528007c3 	mov	w3, #0x3e                  	// #62
    3ee4:	aa1403e0 	mov	x0, x20
    3ee8:	91001fe1 	add	x1, sp, #0x7
    3eec:	d2800022 	mov	x2, #0x1                   	// #1
    3ef0:	39001fe3 	strb	w3, [sp, #7]
    3ef4:	17ffffb2 	b	3dbc <fwp_write.constprop.0+0x9c>
    3ef8:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    3efc:	f947f400 	ldr	x0, [x0, #4072]
    3f00:	f94127e2 	ldr	x2, [sp, #584]
    3f04:	f9400001 	ldr	x1, [x0]
    3f08:	eb010042 	subs	x2, x2, x1
    3f0c:	d2800001 	mov	x1, #0x0                   	// #0
    3f10:	54006cc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    3f14:	f9413bf5 	ldr	x21, [sp, #624]
    3f18:	d0000021 	adrp	x1, 9000 <__modti3+0x260>
    3f1c:	f9413ff6 	ldr	x22, [sp, #632]
    3f20:	aa1403e0 	mov	x0, x20
    3f24:	910e4021 	add	x1, x1, #0x390
    3f28:	d2800142 	mov	x2, #0xa                   	// #10
    3f2c:	f94153fb 	ldr	x27, [sp, #672]
    3f30:	f94157fc 	ldr	x28, [sp, #680]
    3f34:	910943ff 	add	sp, sp, #0x250
    3f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f3c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3f40:	17fff7fc 	b	1f30 <buf_put>
    3f44:	f9400796 	ldr	x22, [x28, #8]
    3f48:	f90143f7 	str	x23, [sp, #640]
    3f4c:	f90147f8 	str	x24, [sp, #648]
    3f50:	b4005816 	cbz	x22, 4a50 <fwp_write.constprop.0+0xd30>
    3f54:	aa1603e0 	mov	x0, x22
    3f58:	d0000021 	adrp	x1, 9000 <__modti3+0x260>
    3f5c:	91104021 	add	x1, x1, #0x410
    3f60:	97fff570 	bl	1520 <strcmp@plt>
    3f64:	2a0003f5 	mov	w21, w0
    3f68:	34005ce0 	cbz	w0, 4b04 <fwp_write.constprop.0+0xde4>
    3f6c:	aa1603e0 	mov	x0, x22
    3f70:	97fff4f0 	bl	1330 <strlen@plt>
    3f74:	aa1603e1 	mov	x1, x22
    3f78:	aa0003e2 	mov	x2, x0
    3f7c:	aa1403e0 	mov	x0, x20
    3f80:	97fff7ec 	bl	1f30 <buf_put>
    3f84:	52800403 	mov	w3, #0x20                  	// #32
    3f88:	91001ff5 	add	x21, sp, #0x7
    3f8c:	aa1503e1 	mov	x1, x21
    3f90:	aa1403e0 	mov	x0, x20
    3f94:	d2800022 	mov	x2, #0x1                   	// #1
    3f98:	39001fe3 	strb	w3, [sp, #7]
    3f9c:	97fff7e5 	bl	1f30 <buf_put>
    3fa0:	52800f63 	mov	w3, #0x7b                  	// #123
    3fa4:	aa1403e0 	mov	x0, x20
    3fa8:	aa1503e1 	mov	x1, x21
    3fac:	d2800022 	mov	x2, #0x1                   	// #1
    3fb0:	39001fe3 	strb	w3, [sp, #7]
    3fb4:	97fff7df 	bl	1f30 <buf_put>
    3fb8:	b9401380 	ldr	w0, [x28, #16]
    3fbc:	52800018 	mov	w24, #0x0                   	// #0
    3fc0:	7100001f 	cmp	w0, #0x0
    3fc4:	54003d8d 	b.le	4774 <fwp_write.constprop.0+0xa54>
    3fc8:	f9014bf9 	str	x25, [sp, #656]
    3fcc:	d0000039 	adrp	x25, 9000 <__modti3+0x260>
    3fd0:	9110e339 	add	x25, x25, #0x438
    3fd4:	f9014ffa 	str	x26, [sp, #664]
    3fd8:	d000003a 	adrp	x26, 9000 <__modti3+0x260>
    3fdc:	910fe35a 	add	x26, x26, #0x3f8
    3fe0:	91002276 	add	x22, x19, #0x8
    3fe4:	d2800013 	mov	x19, #0x0                   	// #0
    3fe8:	b5004413 	cbnz	x19, 4868 <fwp_write.constprop.0+0xb48>
    3fec:	d37df277 	lsl	x23, x19, #3
    3ff0:	34004238 	cbz	w24, 4834 <fwp_write.constprop.0+0xb14>
    3ff4:	f9401382 	ldr	x2, [x28, #32]
    3ff8:	aa1403e0 	mov	x0, x20
    3ffc:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    4000:	91000673 	add	x19, x19, #0x1
    4004:	f8776842 	ldr	x2, [x2, x23]
    4008:	97ffff46 	bl	3d20 <fwp_write.constprop.0>
    400c:	b9401380 	ldr	w0, [x28, #16]
    4010:	6b13001f 	cmp	w0, w19
    4014:	54fffeac 	b.gt	3fe8 <fwp_write.constprop.0+0x2c8>
    4018:	f9414bf9 	ldr	x25, [sp, #656]
    401c:	f9414ffa 	ldr	x26, [sp, #664]
    4020:	34003ab8 	cbz	w24, 4774 <fwp_write.constprop.0+0xa54>
    4024:	52800523 	mov	w3, #0x29                  	// #41
    4028:	aa1503e1 	mov	x1, x21
    402c:	aa1403e0 	mov	x0, x20
    4030:	d2800022 	mov	x2, #0x1                   	// #1
    4034:	39001fe3 	strb	w3, [sp, #7]
    4038:	97fff7be 	bl	1f30 <buf_put>
    403c:	f9413bf5 	ldr	x21, [sp, #624]
    4040:	f9413ff6 	ldr	x22, [sp, #632]
    4044:	f94143f7 	ldr	x23, [sp, #640]
    4048:	f94147f8 	ldr	x24, [sp, #648]
    404c:	f94153fb 	ldr	x27, [sp, #672]
    4050:	f94157fc 	ldr	x28, [sp, #680]
    4054:	17ffff5f 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4058:	b9404b95 	ldr	w21, [x28, #72]
    405c:	aa1403e0 	mov	x0, x20
    4060:	93407eb6 	sxtw	x22, w21
    4064:	91000ac1 	add	x1, x22, #0x2
    4068:	97fff77e 	bl	1e60 <buf_grow>
    406c:	a9400281 	ldp	x1, x0, [x20]
    4070:	528e8603 	mov	w3, #0x7430                	// #29744
    4074:	78206823 	strh	w3, [x1, x0]
    4078:	8b000022 	add	x2, x1, x0
    407c:	710002bf 	cmp	w21, #0x0
    4080:	54003bcd 	b.le	47f8 <fwp_write.constprop.0+0xad8>
    4084:	110006a3 	add	w3, w21, #0x1
    4088:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    408c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4090:	91000449 	add	x9, x2, #0x1
    4094:	8b23c043 	add	x3, x2, w3, sxtw
    4098:	f28aaac6 	movk	x6, #0x5556
    409c:	f2955568 	movk	x8, #0xaaab
    40a0:	1400000d 	b	40d4 <fwp_write.constprop.0+0x3b4>
    40a4:	d2800021 	mov	x1, #0x1                   	// #1
    40a8:	528005a5 	mov	w5, #0x2d                  	// #45
    40ac:	f100001f 	cmp	x0, #0x0
    40b0:	9b467e60 	smulh	x0, x19, x6
    40b4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    40b8:	381ff465 	strb	w5, [x3], #-1
    40bc:	cb040000 	sub	x0, x0, x4
    40c0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    40c4:	cb020000 	sub	x0, x0, x2
    40c8:	8b010013 	add	x19, x0, x1
    40cc:	eb03013f 	cmp	x9, x3
    40d0:	54003940 	b.eq	47f8 <fwp_write.constprop.0+0xad8>  // b.none
    40d4:	9b467e60 	smulh	x0, x19, x6
    40d8:	937ffe64 	asr	x4, x19, #63
    40dc:	52800605 	mov	w5, #0x30                  	// #48
    40e0:	cb040000 	sub	x0, x0, x4
    40e4:	8b000400 	add	x0, x0, x0, lsl #1
    40e8:	cb000260 	sub	x0, x19, x0
    40ec:	91000c01 	add	x1, x0, #0x3
    40f0:	9bc87c22 	umulh	x2, x1, x8
    40f4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    40f8:	8b4204e2 	add	x2, x7, x2, lsr #1
    40fc:	eb020021 	subs	x1, x1, x2
    4100:	54fffd60 	b.eq	40ac <fwp_write.constprop.0+0x38c>  // b.none
    4104:	f100043f 	cmp	x1, #0x1
    4108:	54fffce1 	b.ne	40a4 <fwp_write.constprop.0+0x384>  // b.any
    410c:	d2800001 	mov	x1, #0x0                   	// #0
    4110:	52800565 	mov	w5, #0x2b                  	// #43
    4114:	17ffffe6 	b	40ac <fwp_write.constprop.0+0x38c>
    4118:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    411c:	f947f400 	ldr	x0, [x0, #4072]
    4120:	f94127e2 	ldr	x2, [sp, #584]
    4124:	f9400001 	ldr	x1, [x0]
    4128:	eb010042 	subs	x2, x2, x1
    412c:	d2800001 	mov	x1, #0x0                   	// #0
    4130:	54005bc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4134:	f9413bf5 	ldr	x21, [sp, #624]
    4138:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    413c:	f9413ff6 	ldr	x22, [sp, #632]
    4140:	aa1403e0 	mov	x0, x20
    4144:	910e8021 	add	x1, x1, #0x3a0
    4148:	d2800102 	mov	x2, #0x8                   	// #8
    414c:	17ffff78 	b	3f2c <fwp_write.constprop.0+0x20c>
    4150:	aa1403e0 	mov	x0, x20
    4154:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4158:	d28000c2 	mov	x2, #0x6                   	// #6
    415c:	91100021 	add	x1, x1, #0x400
    4160:	97fff774 	bl	1f30 <buf_put>
    4164:	d2800015 	mov	x21, #0x0                   	// #0
    4168:	f9400263 	ldr	x3, [x19]
    416c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4170:	540026a0 	b.eq	4644 <fwp_write.constprop.0+0x924>  // b.none
    4174:	f9401f82 	ldr	x2, [x28, #56]
    4178:	f90143f7 	str	x23, [sp, #640]
    417c:	f90147f8 	str	x24, [sp, #648]
    4180:	d2800857 	mov	x23, #0x42                  	// #66
    4184:	f9014bf9 	str	x25, [sp, #656]
    4188:	b0000036 	adrp	x22, 9000 <__modti3+0x260>
    418c:	f9014ffa 	str	x26, [sp, #664]
    4190:	910fe2d6 	add	x22, x22, #0x3f8
    4194:	d2800038 	mov	x24, #0x1                   	// #1
    4198:	f2a18017 	movk	x23, #0xc00, lsl #16
    419c:	d2809099 	mov	x25, #0x484                 	// #1156
    41a0:	b4000482 	cbz	x2, 4230 <fwp_write.constprop.0+0x510>
    41a4:	b9400040 	ldr	w0, [x2]
    41a8:	7100701f 	cmp	w0, #0x1c
    41ac:	540042e0 	b.eq	4a08 <fwp_write.constprop.0+0xce8>  // b.none
    41b0:	71006c1f 	cmp	w0, #0x1b
    41b4:	540003e8 	b.hi	4230 <fwp_write.constprop.0+0x510>  // b.pmore
    41b8:	9ac02301 	lsl	x1, x24, x0
    41bc:	ea17003f 	tst	x1, x23
    41c0:	54003f21 	b.ne	49a4 <fwp_write.constprop.0+0xc84>  // b.any
    41c4:	ea19003f 	tst	x1, x25
    41c8:	54003da1 	b.ne	497c <fwp_write.constprop.0+0xc5c>  // b.any
    41cc:	d2800425 	mov	x5, #0x21                  	// #33
    41d0:	ea05003f 	tst	x1, x5
    41d4:	540002e0 	b.eq	4230 <fwp_write.constprop.0+0x510>  // b.none
    41d8:	b7f84743 	tbnz	x3, #63, 4ac0 <fwp_write.constprop.0+0xda0>
    41dc:	91002261 	add	x1, x19, #0x8
    41e0:	8b150021 	add	x1, x1, x21
    41e4:	39400021 	ldrb	w1, [x1]
    41e8:	7100001f 	cmp	w0, #0x0
    41ec:	93401c23 	sxtb	x3, w1
    41f0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    41f4:	d503201f 	nop
    41f8:	aa1403e0 	mov	x0, x20
    41fc:	97fffec9 	bl	3d20 <fwp_write.constprop.0>
    4200:	f9400260 	ldr	x0, [x19]
    4204:	910006b5 	add	x21, x21, #0x1
    4208:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    420c:	eb0002bf 	cmp	x21, x0
    4210:	54002122 	b.cs	4634 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4214:	d2800042 	mov	x2, #0x2                   	// #2
    4218:	aa1603e1 	mov	x1, x22
    421c:	aa1403e0 	mov	x0, x20
    4220:	97fff744 	bl	1f30 <buf_put>
    4224:	f9401f82 	ldr	x2, [x28, #56]
    4228:	f9400263 	ldr	x3, [x19]
    422c:	b5fffbc2 	cbnz	x2, 41a4 <fwp_write.constprop.0+0x484>
    4230:	d37df2a0 	lsl	x0, x21, #3
    4234:	b7f83f43 	tbnz	x3, #63, 4a1c <fwp_write.constprop.0+0xcfc>
    4238:	91002261 	add	x1, x19, #0x8
    423c:	8b000020 	add	x0, x1, x0
    4240:	f9400001 	ldr	x1, [x0]
    4244:	17ffffed 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4248:	a9400e62 	ldp	x2, x3, [x19]
    424c:	b7f83ce3 	tbnz	x3, #63, 49e8 <fwp_write.constprop.0+0xcc8>
    4250:	910123f5 	add	x21, sp, #0x48
    4254:	aa1503e0 	mov	x0, x21
    4258:	97fff5e2 	bl	19e0 <fwp_fmt_u128>
    425c:	aa1503e0 	mov	x0, x21
    4260:	97fff434 	bl	1330 <strlen@plt>
    4264:	aa1503e1 	mov	x1, x21
    4268:	aa0003e2 	mov	x2, x0
    426c:	17fffed3 	b	3db8 <fwp_write.constprop.0+0x98>
    4270:	fd015be8 	str	d8, [sp, #688]
    4274:	1e270268 	fmov	s8, w19
    4278:	fd015fe9 	str	d9, [sp, #696]
    427c:	1e282100 	fcmp	s8, s8
    4280:	54004a66 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    4284:	1e20c101 	fabs	s1, s8
    4288:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    428c:	1e270000 	fmov	s0, w0
    4290:	1e202020 	fcmp	s1, s0
    4294:	540034ad 	b.le	4928 <fwp_write.constprop.0+0xc08>
    4298:	1e202118 	fcmpe	s8, #0.0
    429c:	b0000022 	adrp	x2, 9000 <__modti3+0x260>
    42a0:	91058042 	add	x2, x2, #0x160
    42a4:	910123f5 	add	x21, sp, #0x48
    42a8:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    42ac:	910d4021 	add	x1, x1, #0x350
    42b0:	aa1503e0 	mov	x0, x21
    42b4:	9a81c041 	csel	x1, x2, x1, gt
    42b8:	97fff4ca 	bl	15e0 <strcpy@plt>
    42bc:	d503201f 	nop
    42c0:	aa1503e0 	mov	x0, x21
    42c4:	97fff41b 	bl	1330 <strlen@plt>
    42c8:	aa1503e1 	mov	x1, x21
    42cc:	aa0003e2 	mov	x2, x0
    42d0:	aa1403e0 	mov	x0, x20
    42d4:	97fff717 	bl	1f30 <buf_put>
    42d8:	f9413bf5 	ldr	x21, [sp, #624]
    42dc:	f9413ff6 	ldr	x22, [sp, #632]
    42e0:	f94153fb 	ldr	x27, [sp, #672]
    42e4:	f94157fc 	ldr	x28, [sp, #680]
    42e8:	fd415be8 	ldr	d8, [sp, #688]
    42ec:	fd415fe9 	ldr	d9, [sp, #696]
    42f0:	17fffeb8 	b	3dd0 <fwp_write.constprop.0+0xb0>
    42f4:	f90143f7 	str	x23, [sp, #640]
    42f8:	52800443 	mov	w3, #0x22                  	// #34
    42fc:	f90147f8 	str	x24, [sp, #648]
    4300:	91001ff5 	add	x21, sp, #0x7
    4304:	aa1503e1 	mov	x1, x21
    4308:	aa1403e0 	mov	x0, x20
    430c:	f8408677 	ldr	x23, [x19], #8
    4310:	d2800022 	mov	x2, #0x1                   	// #1
    4314:	39001fe3 	strb	w3, [sp, #7]
    4318:	97fff706 	bl	1f30 <buf_put>
    431c:	8b1302f6 	add	x22, x23, x19
    4320:	b4002657 	cbz	x23, 47e8 <fwp_write.constprop.0+0xac8>
    4324:	b0000038 	adrp	x24, 9000 <__modti3+0x260>
    4328:	910ee318 	add	x24, x24, #0x3b8
    432c:	f9014bf9 	str	x25, [sp, #656]
    4330:	b0000039 	adrp	x25, 9000 <__modti3+0x260>
    4334:	910f6339 	add	x25, x25, #0x3d8
    4338:	f9014ffa 	str	x26, [sp, #664]
    433c:	1400000e 	b	4374 <fwp_write.constprop.0+0x654>
    4340:	710024bf 	cmp	w5, #0x9
    4344:	54002380 	b.eq	47b4 <fwp_write.constprop.0+0xa94>  // b.none
    4348:	710028bf 	cmp	w5, #0xa
    434c:	54002be1 	b.ne	48c8 <fwp_write.constprop.0+0xba8>  // b.any
    4350:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4354:	aa1403e0 	mov	x0, x20
    4358:	910f2021 	add	x1, x1, #0x3c8
    435c:	d2800042 	mov	x2, #0x2                   	// #2
    4360:	97fff6f4 	bl	1f30 <buf_put>
    4364:	d503201f 	nop
    4368:	91000673 	add	x19, x19, #0x1
    436c:	eb16027f 	cmp	x19, x22
    4370:	54002380 	b.eq	47e0 <fwp_write.constprop.0+0xac0>  // b.none
    4374:	39400265 	ldrb	w5, [x19]
    4378:	710034bf 	cmp	w5, #0xd
    437c:	54002120 	b.eq	47a0 <fwp_write.constprop.0+0xa80>  // b.none
    4380:	54fffe09 	b.ls	4340 <fwp_write.constprop.0+0x620>  // b.plast
    4384:	710088bf 	cmp	w5, #0x22
    4388:	54002220 	b.eq	47cc <fwp_write.constprop.0+0xaac>  // b.none
    438c:	710170bf 	cmp	w5, #0x5c
    4390:	54002ba1 	b.ne	4904 <fwp_write.constprop.0+0xbe4>  // b.any
    4394:	aa1403e0 	mov	x0, x20
    4398:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    439c:	d2800042 	mov	x2, #0x2                   	// #2
    43a0:	910f0021 	add	x1, x1, #0x3c0
    43a4:	97fff6e3 	bl	1f30 <buf_put>
    43a8:	17fffff0 	b	4368 <fwp_write.constprop.0+0x648>
    43ac:	fd015be8 	str	d8, [sp, #688]
    43b0:	9e670268 	fmov	d8, x19
    43b4:	fd015fe9 	str	d9, [sp, #696]
    43b8:	1e682100 	fcmp	d8, d8
    43bc:	54004086 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    43c0:	1e60c101 	fabs	d1, d8
    43c4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    43c8:	9e670000 	fmov	d0, x0
    43cc:	910123f5 	add	x21, sp, #0x48
    43d0:	52800033 	mov	w19, #0x1                   	// #1
    43d4:	1e602020 	fcmp	d1, d0
    43d8:	540001ad 	b.le	440c <fwp_write.constprop.0+0x6ec>
    43dc:	1e602118 	fcmpe	d8, #0.0
    43e0:	b0000022 	adrp	x2, 9000 <__modti3+0x260>
    43e4:	91058042 	add	x2, x2, #0x160
    43e8:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    43ec:	910d4021 	add	x1, x1, #0x350
    43f0:	aa1503e0 	mov	x0, x21
    43f4:	9a81c041 	csel	x1, x2, x1, gt
    43f8:	97fff47a 	bl	15e0 <strcpy@plt>
    43fc:	17ffffb1 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4400:	11000673 	add	w19, w19, #0x1
    4404:	71004a7f 	cmp	w19, #0x12
    4408:	540031a0 	b.eq	4a3c <fwp_write.constprop.0+0xd1c>  // b.none
    440c:	1e604100 	fmov	d0, d8
    4410:	2a1303e1 	mov	w1, w19
    4414:	aa1503e0 	mov	x0, x21
    4418:	97fff75a 	bl	2180 <fwp_format_g.constprop.0>
    441c:	aa1503e0 	mov	x0, x21
    4420:	d2800001 	mov	x1, #0x0                   	// #0
    4424:	97fff3d7 	bl	1380 <strtod@plt>
    4428:	1e602100 	fcmp	d8, d0
    442c:	54fffea1 	b.ne	4400 <fwp_write.constprop.0+0x6e0>  // b.any
    4430:	aa1503e0 	mov	x0, x21
    4434:	97fff6f8 	bl	2014 <fwp_finish_float>
    4438:	17ffffa2 	b	42c0 <fwp_write.constprop.0+0x5a0>
    443c:	a9400e62 	ldp	x2, x3, [x19]
    4440:	910123f3 	add	x19, sp, #0x48
    4444:	aa1303e0 	mov	x0, x19
    4448:	97fff566 	bl	19e0 <fwp_fmt_u128>
    444c:	17fffe57 	b	3da8 <fwp_write.constprop.0+0x88>
    4450:	f90143f7 	str	x23, [sp, #640]
    4454:	f90147f8 	str	x24, [sp, #648]
    4458:	2a1303f8 	mov	w24, w19
    445c:	f9014bf9 	str	x25, [sp, #656]
    4460:	f9014ffa 	str	x26, [sp, #664]
    4464:	f13ffe7f 	cmp	x19, #0xfff
    4468:	54000049 	b.ls	4470 <fwp_write.constprop.0+0x750>  // b.plast
    446c:	b9400278 	ldr	w24, [x19]
    4470:	f9400f80 	ldr	x0, [x28, #24]
    4474:	2a1803f5 	mov	w21, w24
    4478:	d37d7f18 	ubfiz	x24, x24, #3, #32
    447c:	d37ef6b9 	lsl	x25, x21, #2
    4480:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4484:	aa1603e0 	mov	x0, x22
    4488:	97fff3aa 	bl	1330 <strlen@plt>
    448c:	aa1603e1 	mov	x1, x22
    4490:	aa0003e2 	mov	x2, x0
    4494:	aa1403e0 	mov	x0, x20
    4498:	97fff6a6 	bl	1f30 <buf_put>
    449c:	f9401780 	ldr	x0, [x28, #40]
    44a0:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    44a4:	7100001f 	cmp	w0, #0x0
    44a8:	5400064d 	b.le	4570 <fwp_write.constprop.0+0x850>
    44ac:	91002276 	add	x22, x19, #0x8
    44b0:	91001ff5 	add	x21, sp, #0x7
    44b4:	d280001b 	mov	x27, #0x0                   	// #0
    44b8:	5280041a 	mov	w26, #0x20                  	// #32
    44bc:	f9401b80 	ldr	x0, [x28, #48]
    44c0:	aa1503e1 	mov	x1, x21
    44c4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    44c8:	d2800022 	mov	x2, #0x1                   	// #1
    44cc:	f8786805 	ldr	x5, [x0, x24]
    44d0:	aa1403e0 	mov	x0, x20
    44d4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    44d8:	39001ffa 	strb	w26, [sp, #7]
    44dc:	97fff695 	bl	1f30 <buf_put>
    44e0:	f13ffeff 	cmp	x23, #0xfff
    44e4:	b9400261 	ldr	w1, [x19]
    44e8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    44ec:	7100383f 	cmp	w1, #0xe
    44f0:	54000140 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    44f4:	7100403f 	cmp	w1, #0x10
    44f8:	54001c20 	b.eq	487c <fwp_write.constprop.0+0xb5c>  // b.none
    44fc:	7100283f 	cmp	w1, #0xa
    4500:	540026e0 	b.eq	49dc <fwp_write.constprop.0+0xcbc>  // b.none
    4504:	540013cc 	b.gt	477c <fwp_write.constprop.0+0xa5c>
    4508:	71000c3f 	cmp	w1, #0x3
    450c:	540025ec 	b.gt	49c8 <fwp_write.constprop.0+0xca8>
    4510:	d37ffee0 	lsr	x0, x23, #63
    4514:	37f813c1 	tbnz	w1, #31, 478c <fwp_write.constprop.0+0xa6c>
    4518:	340013a0 	cbz	w0, 478c <fwp_write.constprop.0+0xa6c>
    451c:	52800503 	mov	w3, #0x28                  	// #40
    4520:	aa1503e1 	mov	x1, x21
    4524:	aa1403e0 	mov	x0, x20
    4528:	d2800022 	mov	x2, #0x1                   	// #1
    452c:	39001fe3 	strb	w3, [sp, #7]
    4530:	97fff680 	bl	1f30 <buf_put>
    4534:	aa1303e2 	mov	x2, x19
    4538:	aa1703e1 	mov	x1, x23
    453c:	aa1403e0 	mov	x0, x20
    4540:	97fffdf8 	bl	3d20 <fwp_write.constprop.0>
    4544:	52800523 	mov	w3, #0x29                  	// #41
    4548:	aa1503e1 	mov	x1, x21
    454c:	aa1403e0 	mov	x0, x20
    4550:	d2800022 	mov	x2, #0x1                   	// #1
    4554:	39001fe3 	strb	w3, [sp, #7]
    4558:	97fff676 	bl	1f30 <buf_put>
    455c:	f9401780 	ldr	x0, [x28, #40]
    4560:	9100077b 	add	x27, x27, #0x1
    4564:	b8796800 	ldr	w0, [x0, x25]
    4568:	6b1b001f 	cmp	w0, w27
    456c:	54fffa8c 	b.gt	44bc <fwp_write.constprop.0+0x79c>
    4570:	f9413bf5 	ldr	x21, [sp, #624]
    4574:	f9413ff6 	ldr	x22, [sp, #632]
    4578:	f94143f7 	ldr	x23, [sp, #640]
    457c:	f94147f8 	ldr	x24, [sp, #648]
    4580:	f9414bf9 	ldr	x25, [sp, #656]
    4584:	f9414ffa 	ldr	x26, [sp, #664]
    4588:	f94153fb 	ldr	x27, [sp, #672]
    458c:	f94157fc 	ldr	x28, [sp, #680]
    4590:	17fffe10 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4594:	aa1403e0 	mov	x0, x20
    4598:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    459c:	d28000c2 	mov	x2, #0x6                   	// #6
    45a0:	910fa021 	add	x1, x1, #0x3e8
    45a4:	97fff663 	bl	1f30 <buf_put>
    45a8:	f9400260 	ldr	x0, [x19]
    45ac:	b40004c0 	cbz	x0, 4644 <fwp_write.constprop.0+0x924>
    45b0:	910123f5 	add	x21, sp, #0x48
    45b4:	91002276 	add	x22, x19, #0x8
    45b8:	f90143f7 	str	x23, [sp, #640]
    45bc:	d2800017 	mov	x23, #0x0                   	// #0
    45c0:	f90147f8 	str	x24, [sp, #648]
    45c4:	b0000038 	adrp	x24, 9000 <__modti3+0x260>
    45c8:	910fc318 	add	x24, x24, #0x3f0
    45cc:	f9014bf9 	str	x25, [sp, #656]
    45d0:	b0000039 	adrp	x25, 9000 <__modti3+0x260>
    45d4:	910fe339 	add	x25, x25, #0x3f8
    45d8:	f9014ffa 	str	x26, [sp, #664]
    45dc:	14000005 	b	45f0 <fwp_write.constprop.0+0x8d0>
    45e0:	aa1903e1 	mov	x1, x25
    45e4:	aa1403e0 	mov	x0, x20
    45e8:	d2800042 	mov	x2, #0x2                   	// #2
    45ec:	97fff651 	bl	1f30 <buf_put>
    45f0:	38776ac5 	ldrb	w5, [x22, x23]
    45f4:	d2804003 	mov	x3, #0x200                 	// #512
    45f8:	aa1803e4 	mov	x4, x24
    45fc:	aa0303e1 	mov	x1, x3
    4600:	52800042 	mov	w2, #0x2                   	// #2
    4604:	aa1503e0 	mov	x0, x21
    4608:	910006f7 	add	x23, x23, #0x1
    460c:	97fff381 	bl	1410 <__snprintf_chk@plt>
    4610:	aa1503e0 	mov	x0, x21
    4614:	97fff347 	bl	1330 <strlen@plt>
    4618:	aa1503e1 	mov	x1, x21
    461c:	aa0003e2 	mov	x2, x0
    4620:	aa1403e0 	mov	x0, x20
    4624:	97fff643 	bl	1f30 <buf_put>
    4628:	f9400260 	ldr	x0, [x19]
    462c:	eb0002ff 	cmp	x23, x0
    4630:	54fffd83 	b.cc	45e0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4634:	f94143f7 	ldr	x23, [sp, #640]
    4638:	f94147f8 	ldr	x24, [sp, #648]
    463c:	f9414bf9 	ldr	x25, [sp, #656]
    4640:	f9414ffa 	ldr	x26, [sp, #664]
    4644:	52800ba3 	mov	w3, #0x5d                  	// #93
    4648:	aa1403e0 	mov	x0, x20
    464c:	91001fe1 	add	x1, sp, #0x7
    4650:	d2800022 	mov	x2, #0x1                   	// #1
    4654:	39001fe3 	strb	w3, [sp, #7]
    4658:	17fffdd9 	b	3dbc <fwp_write.constprop.0+0x9c>
    465c:	52800b63 	mov	w3, #0x5b                  	// #91
    4660:	91001ff5 	add	x21, sp, #0x7
    4664:	aa1503e1 	mov	x1, x21
    4668:	aa1403e0 	mov	x0, x20
    466c:	d2800022 	mov	x2, #0x1                   	// #1
    4670:	b0000036 	adrp	x22, 9000 <__modti3+0x260>
    4674:	910fe2d6 	add	x22, x22, #0x3f8
    4678:	39001fe3 	strb	w3, [sp, #7]
    467c:	97fff62d 	bl	1f30 <buf_put>
    4680:	b4000233 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    4684:	f9400661 	ldr	x1, [x19, #8]
    4688:	aa1403e0 	mov	x0, x20
    468c:	f9401f82 	ldr	x2, [x28, #56]
    4690:	97fffda4 	bl	3d20 <fwp_write.constprop.0>
    4694:	f9400a73 	ldr	x19, [x19, #16]
    4698:	b4000173 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    469c:	aa1603e1 	mov	x1, x22
    46a0:	aa1403e0 	mov	x0, x20
    46a4:	d2800042 	mov	x2, #0x2                   	// #2
    46a8:	97fff622 	bl	1f30 <buf_put>
    46ac:	f9400661 	ldr	x1, [x19, #8]
    46b0:	aa1403e0 	mov	x0, x20
    46b4:	f9401f82 	ldr	x2, [x28, #56]
    46b8:	97fffd9a 	bl	3d20 <fwp_write.constprop.0>
    46bc:	f9400a73 	ldr	x19, [x19, #16]
    46c0:	b5fffef3 	cbnz	x19, 469c <fwp_write.constprop.0+0x97c>
    46c4:	52800ba3 	mov	w3, #0x5d                  	// #93
    46c8:	aa1503e1 	mov	x1, x21
    46cc:	aa1403e0 	mov	x0, x20
    46d0:	d2800022 	mov	x2, #0x1                   	// #1
    46d4:	39001fe3 	strb	w3, [sp, #7]
    46d8:	17fffdb9 	b	3dbc <fwp_write.constprop.0+0x9c>
    46dc:	52800783 	mov	w3, #0x3c                  	// #60
    46e0:	91001ff3 	add	x19, sp, #0x7
    46e4:	aa1303e1 	mov	x1, x19
    46e8:	d2800022 	mov	x2, #0x1                   	// #1
    46ec:	aa1403e0 	mov	x0, x20
    46f0:	39001fe3 	strb	w3, [sp, #7]
    46f4:	97fff60f 	bl	1f30 <buf_put>
    46f8:	f9400795 	ldr	x21, [x28, #8]
    46fc:	aa1503e0 	mov	x0, x21
    4700:	97fff30c 	bl	1330 <strlen@plt>
    4704:	aa1503e1 	mov	x1, x21
    4708:	aa0003e2 	mov	x2, x0
    470c:	aa1403e0 	mov	x0, x20
    4710:	97fff608 	bl	1f30 <buf_put>
    4714:	528007c3 	mov	w3, #0x3e                  	// #62
    4718:	aa1303e1 	mov	x1, x19
    471c:	aa1403e0 	mov	x0, x20
    4720:	d2800022 	mov	x2, #0x1                   	// #1
    4724:	39001fe3 	strb	w3, [sp, #7]
    4728:	17fffda5 	b	3dbc <fwp_write.constprop.0+0x9c>
    472c:	f100067f 	cmp	x19, #0x1
    4730:	540017e0 	b.eq	4a2c <fwp_write.constprop.0+0xd0c>  // b.none
    4734:	b100067f 	cmn	x19, #0x1
    4738:	54001b00 	b.eq	4a98 <fwp_write.constprop.0+0xd78>  // b.none
    473c:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4740:	910da021 	add	x1, x1, #0x368
    4744:	d2800022 	mov	x2, #0x1                   	// #1
    4748:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    474c:	f947f400 	ldr	x0, [x0, #4072]
    4750:	f94127e4 	ldr	x4, [sp, #584]
    4754:	f9400003 	ldr	x3, [x0]
    4758:	eb030084 	subs	x4, x4, x3
    475c:	d2800003 	mov	x3, #0x0                   	// #0
    4760:	54002a41 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4764:	f9413bf5 	ldr	x21, [sp, #624]
    4768:	aa1403e0 	mov	x0, x20
    476c:	f9413ff6 	ldr	x22, [sp, #632]
    4770:	17fffdef 	b	3f2c <fwp_write.constprop.0+0x20c>
    4774:	52800fa3 	mov	w3, #0x7d                  	// #125
    4778:	17fffe2c 	b	4028 <fwp_write.constprop.0+0x308>
    477c:	f10002ff 	cmp	x23, #0x0
    4780:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4784:	71002c3f 	cmp	w1, #0xb
    4788:	54ffec80 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    478c:	aa1303e2 	mov	x2, x19
    4790:	aa1703e1 	mov	x1, x23
    4794:	aa1403e0 	mov	x0, x20
    4798:	97fffd62 	bl	3d20 <fwp_write.constprop.0>
    479c:	17ffff70 	b	455c <fwp_write.constprop.0+0x83c>
    47a0:	aa1903e1 	mov	x1, x25
    47a4:	aa1403e0 	mov	x0, x20
    47a8:	d2800042 	mov	x2, #0x2                   	// #2
    47ac:	97fff5e1 	bl	1f30 <buf_put>
    47b0:	17fffeee 	b	4368 <fwp_write.constprop.0+0x648>
    47b4:	aa1403e0 	mov	x0, x20
    47b8:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    47bc:	d2800042 	mov	x2, #0x2                   	// #2
    47c0:	910f4021 	add	x1, x1, #0x3d0
    47c4:	97fff5db 	bl	1f30 <buf_put>
    47c8:	17fffee8 	b	4368 <fwp_write.constprop.0+0x648>
    47cc:	aa1803e1 	mov	x1, x24
    47d0:	aa1403e0 	mov	x0, x20
    47d4:	d2800042 	mov	x2, #0x2                   	// #2
    47d8:	97fff5d6 	bl	1f30 <buf_put>
    47dc:	17fffee3 	b	4368 <fwp_write.constprop.0+0x648>
    47e0:	f9414bf9 	ldr	x25, [sp, #656]
    47e4:	f9414ffa 	ldr	x26, [sp, #664]
    47e8:	aa1503e1 	mov	x1, x21
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	52800443 	mov	w3, #0x22                  	// #34
    47f4:	17fffe0f 	b	4030 <fwp_write.constprop.0+0x310>
    47f8:	a9400281 	ldp	x1, x0, [x20]
    47fc:	91000800 	add	x0, x0, #0x2
    4800:	8b160000 	add	x0, x0, x22
    4804:	f9000680 	str	x0, [x20, #8]
    4808:	3820683f 	strb	wzr, [x1, x0]
    480c:	f9413bf5 	ldr	x21, [sp, #624]
    4810:	f9413ff6 	ldr	x22, [sp, #632]
    4814:	f94153fb 	ldr	x27, [sp, #672]
    4818:	f94157fc 	ldr	x28, [sp, #680]
    481c:	17fffd6d 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4820:	aa1403e0 	mov	x0, x20
    4824:	91001fe1 	add	x1, sp, #0x7
    4828:	52800fa3 	mov	w3, #0x7d                  	// #125
    482c:	d2800022 	mov	x2, #0x1                   	// #1
    4830:	17fffe01 	b	4034 <fwp_write.constprop.0+0x314>
    4834:	f9400f80 	ldr	x0, [x28, #24]
    4838:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    483c:	aa1b03e0 	mov	x0, x27
    4840:	97fff2bc 	bl	1330 <strlen@plt>
    4844:	aa1b03e1 	mov	x1, x27
    4848:	aa0003e2 	mov	x2, x0
    484c:	aa1403e0 	mov	x0, x20
    4850:	97fff5b8 	bl	1f30 <buf_put>
    4854:	aa1903e1 	mov	x1, x25
    4858:	aa1403e0 	mov	x0, x20
    485c:	d2800062 	mov	x2, #0x3                   	// #3
    4860:	97fff5b4 	bl	1f30 <buf_put>
    4864:	17fffde4 	b	3ff4 <fwp_write.constprop.0+0x2d4>
    4868:	aa1a03e1 	mov	x1, x26
    486c:	aa1403e0 	mov	x0, x20
    4870:	d2800042 	mov	x2, #0x2                   	// #2
    4874:	97fff5af 	bl	1f30 <buf_put>
    4878:	17fffddd 	b	3fec <fwp_write.constprop.0+0x2cc>
    487c:	f9400660 	ldr	x0, [x19, #8]
    4880:	b4fff860 	cbz	x0, 478c <fwp_write.constprop.0+0xa6c>
    4884:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4888:	91104021 	add	x1, x1, #0x410
    488c:	97fff325 	bl	1520 <strcmp@plt>
    4890:	7100001f 	cmp	w0, #0x0
    4894:	1a9f07e0 	cset	w0, ne	// ne = any
    4898:	17ffff20 	b	4518 <fwp_write.constprop.0+0x7f8>
    489c:	aa1403e0 	mov	x0, x20
    48a0:	d2800042 	mov	x2, #0x2                   	// #2
    48a4:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    48a8:	91102021 	add	x1, x1, #0x408
    48ac:	97fff5a1 	bl	1f30 <buf_put>
    48b0:	91004261 	add	x1, x19, #0x10
    48b4:	aa1403e0 	mov	x0, x20
    48b8:	f9402382 	ldr	x2, [x28, #64]
    48bc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    48c0:	97fffd18 	bl	3d20 <fwp_write.constprop.0>
    48c4:	17fffd71 	b	3e88 <fwp_write.constprop.0+0x168>
    48c8:	d2800203 	mov	x3, #0x10                  	// #16
    48cc:	b0000024 	adrp	x4, 9000 <__modti3+0x260>
    48d0:	aa0303e1 	mov	x1, x3
    48d4:	910f8084 	add	x4, x4, #0x3e0
    48d8:	910123f7 	add	x23, sp, #0x48
    48dc:	52800042 	mov	w2, #0x2                   	// #2
    48e0:	aa1703e0 	mov	x0, x23
    48e4:	97fff2cb 	bl	1410 <__snprintf_chk@plt>
    48e8:	aa1703e0 	mov	x0, x23
    48ec:	97fff291 	bl	1330 <strlen@plt>
    48f0:	aa1703e1 	mov	x1, x23
    48f4:	aa0003e2 	mov	x2, x0
    48f8:	aa1403e0 	mov	x0, x20
    48fc:	97fff58d 	bl	1f30 <buf_put>
    4900:	17fffe9a 	b	4368 <fwp_write.constprop.0+0x648>
    4904:	7101fcbf 	cmp	w5, #0x7f
    4908:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    490c:	54fffde9 	b.ls	48c8 <fwp_write.constprop.0+0xba8>  // b.plast
    4910:	aa1503e1 	mov	x1, x21
    4914:	aa1403e0 	mov	x0, x20
    4918:	d2800022 	mov	x2, #0x1                   	// #1
    491c:	39001fe5 	strb	w5, [sp, #7]
    4920:	97fff584 	bl	1f30 <buf_put>
    4924:	17fffe91 	b	4368 <fwp_write.constprop.0+0x648>
    4928:	1e22c109 	fcvt	d9, s8
    492c:	910123f5 	add	x21, sp, #0x48
    4930:	52800033 	mov	w19, #0x1                   	// #1
    4934:	d503201f 	nop
    4938:	1e604120 	fmov	d0, d9
    493c:	2a1303e1 	mov	w1, w19
    4940:	aa1503e0 	mov	x0, x21
    4944:	97fff60f 	bl	2180 <fwp_format_g.constprop.0>
    4948:	aa1503e0 	mov	x0, x21
    494c:	d2800001 	mov	x1, #0x0                   	// #0
    4950:	97fff300 	bl	1550 <strtof@plt>
    4954:	1e202100 	fcmp	s8, s0
    4958:	54ffd6c0 	b.eq	4430 <fwp_write.constprop.0+0x710>  // b.none
    495c:	11000673 	add	w19, w19, #0x1
    4960:	71002a7f 	cmp	w19, #0xa
    4964:	54fffea1 	b.ne	4938 <fwp_write.constprop.0+0xc18>  // b.any
    4968:	1e604120 	fmov	d0, d9
    496c:	aa1503e0 	mov	x0, x21
    4970:	52800121 	mov	w1, #0x9                   	// #9
    4974:	97fff603 	bl	2180 <fwp_format_g.constprop.0>
    4978:	17fffeae 	b	4430 <fwp_write.constprop.0+0x710>
    497c:	d37ef6a1 	lsl	x1, x21, #2
    4980:	b7f809a3 	tbnz	x3, #63, 4ab4 <fwp_write.constprop.0+0xd94>
    4984:	91002263 	add	x3, x19, #0x8
    4988:	8b010061 	add	x1, x3, x1
    498c:	b9400023 	ldr	w3, [x1]
    4990:	7100081f 	cmp	w0, #0x2
    4994:	2a0303e1 	mov	w1, w3
    4998:	93407c63 	sxtw	x3, w3
    499c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49a0:	17fffe16 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49a4:	d37ffaa1 	lsl	x1, x21, #1
    49a8:	b7f80803 	tbnz	x3, #63, 4aa8 <fwp_write.constprop.0+0xd88>
    49ac:	91002263 	add	x3, x19, #0x8
    49b0:	8b010061 	add	x1, x3, x1
    49b4:	79400021 	ldrh	w1, [x1]
    49b8:	7100041f 	cmp	w0, #0x1
    49bc:	93403c23 	sxth	x3, w1
    49c0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49c4:	17fffe0d 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49c8:	7100103f 	cmp	w1, #0x4
    49cc:	54ffee01 	b.ne	478c <fwp_write.constprop.0+0xa6c>  // b.any
    49d0:	f94006e0 	ldr	x0, [x23, #8]
    49d4:	d37ffc00 	lsr	x0, x0, #63
    49d8:	17fffed0 	b	4518 <fwp_write.constprop.0+0x7f8>
    49dc:	710002ff 	cmp	w23, #0x0
    49e0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    49e4:	17fffecd 	b	4518 <fwp_write.constprop.0+0x7f8>
    49e8:	528005a1 	mov	w1, #0x2d                  	// #45
    49ec:	eb0203e2 	negs	x2, x2
    49f0:	da0303e3 	ngc	x3, x3
    49f4:	910127e0 	add	x0, sp, #0x49
    49f8:	910123f5 	add	x21, sp, #0x48
    49fc:	390123e1 	strb	w1, [sp, #72]
    4a00:	97fff3f8 	bl	19e0 <fwp_fmt_u128>
    4a04:	17fffe16 	b	425c <fwp_write.constprop.0+0x53c>
    4a08:	d37ceea1 	lsl	x1, x21, #4
    4a0c:	b7f80da3 	tbnz	x3, #63, 4bc0 <fwp_write.constprop.0+0xea0>
    4a10:	91002260 	add	x0, x19, #0x8
    4a14:	8b010001 	add	x1, x0, x1
    4a18:	17fffdf8 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a1c:	f9400a61 	ldr	x1, [x19, #16]
    4a20:	8b010000 	add	x0, x0, x1
    4a24:	f9400001 	ldr	x1, [x0]
    4a28:	17fffdf4 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a2c:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4a30:	d2800042 	mov	x2, #0x2                   	// #2
    4a34:	910d6021 	add	x1, x1, #0x358
    4a38:	17ffff44 	b	4748 <fwp_write.constprop.0+0xa28>
    4a3c:	1e604100 	fmov	d0, d8
    4a40:	aa1503e0 	mov	x0, x21
    4a44:	52800221 	mov	w1, #0x11                  	// #17
    4a48:	97fff5ce 	bl	2180 <fwp_format_g.constprop.0>
    4a4c:	17fffe79 	b	4430 <fwp_write.constprop.0+0x710>
    4a50:	b9401380 	ldr	w0, [x28, #16]
    4a54:	350003c0 	cbnz	w0, 4acc <fwp_write.constprop.0+0xdac>
    4a58:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    4a5c:	f947f400 	ldr	x0, [x0, #4072]
    4a60:	f94127e2 	ldr	x2, [sp, #584]
    4a64:	f9400001 	ldr	x1, [x0]
    4a68:	eb010042 	subs	x2, x2, x1
    4a6c:	d2800001 	mov	x1, #0x0                   	// #0
    4a70:	54001201 	b.ne	4cb0 <fwp_write.constprop.0+0xf90>  // b.any
    4a74:	f9413bf5 	ldr	x21, [sp, #624]
    4a78:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4a7c:	f9413ff6 	ldr	x22, [sp, #632]
    4a80:	aa1403e0 	mov	x0, x20
    4a84:	f94143f7 	ldr	x23, [sp, #640]
    4a88:	9110c021 	add	x1, x1, #0x430
    4a8c:	f94147f8 	ldr	x24, [sp, #648]
    4a90:	d2800042 	mov	x2, #0x2                   	// #2
    4a94:	17fffd26 	b	3f2c <fwp_write.constprop.0+0x20c>
    4a98:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4a9c:	d2800042 	mov	x2, #0x2                   	// #2
    4aa0:	910d8021 	add	x1, x1, #0x360
    4aa4:	17ffff29 	b	4748 <fwp_write.constprop.0+0xa28>
    4aa8:	f9400a63 	ldr	x3, [x19, #16]
    4aac:	8b030021 	add	x1, x1, x3
    4ab0:	17ffffc1 	b	49b4 <fwp_write.constprop.0+0xc94>
    4ab4:	f9400a63 	ldr	x3, [x19, #16]
    4ab8:	8b030021 	add	x1, x1, x3
    4abc:	17ffffb4 	b	498c <fwp_write.constprop.0+0xc6c>
    4ac0:	f9400a61 	ldr	x1, [x19, #16]
    4ac4:	8b0102a1 	add	x1, x21, x1
    4ac8:	17fffdc7 	b	41e4 <fwp_write.constprop.0+0x4c4>
    4acc:	b9404b80 	ldr	w0, [x28, #72]
    4ad0:	91001ff5 	add	x21, sp, #0x7
    4ad4:	34ffa660 	cbz	w0, 3fa0 <fwp_write.constprop.0+0x280>
    4ad8:	52800503 	mov	w3, #0x28                  	// #40
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	aa1503e1 	mov	x1, x21
    4ae4:	d2800022 	mov	x2, #0x1                   	// #1
    4ae8:	39001fe3 	strb	w3, [sp, #7]
    4aec:	97fff511 	bl	1f30 <buf_put>
    4af0:	b9401380 	ldr	w0, [x28, #16]
    4af4:	52800038 	mov	w24, #0x1                   	// #1
    4af8:	7100001f 	cmp	w0, #0x0
    4afc:	54ffa66c 	b.gt	3fc8 <fwp_write.constprop.0+0x2a8>
    4b00:	17fffd49 	b	4024 <fwp_write.constprop.0+0x304>
    4b04:	f9014bf9 	str	x25, [sp, #656]
    4b08:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x14c18>
    4b0c:	f9014ffa 	str	x26, [sp, #664]
    4b10:	f9400676 	ldr	x22, [x19, #8]
    4b14:	912ca333 	add	x19, x25, #0xb28
    4b18:	91002273 	add	x19, x19, #0x8
    4b1c:	937ffed8 	asr	x24, x22, #63
    4b20:	aa1802c0 	orr	x0, x22, x24
    4b24:	b5000320 	cbnz	x0, 4b88 <fwp_write.constprop.0+0xe68>
    4b28:	110006b5 	add	w21, w21, #0x1
    4b2c:	710016bf 	cmp	w21, #0x5
    4b30:	54ffffc1 	b.ne	4b28 <fwp_write.constprop.0+0xe08>  // b.any
    4b34:	b7f80578 	tbnz	x24, #63, 4be0 <fwp_write.constprop.0+0xec0>
    4b38:	910023f3 	add	x19, sp, #0x8
    4b3c:	aa1603e2 	mov	x2, x22
    4b40:	aa1303e0 	mov	x0, x19
    4b44:	d2800003 	mov	x3, #0x0                   	// #0
    4b48:	97fff3a6 	bl	19e0 <fwp_fmt_u128>
    4b4c:	910123f5 	add	x21, sp, #0x48
    4b50:	b0000023 	adrp	x3, 9000 <__modti3+0x260>
    4b54:	aa1303e4 	mov	x4, x19
    4b58:	aa1503e0 	mov	x0, x21
    4b5c:	9110a063 	add	x3, x3, #0x428
    4b60:	d2804002 	mov	x2, #0x200                 	// #512
    4b64:	52800041 	mov	w1, #0x2                   	// #2
    4b68:	97fff1f6 	bl	1340 <__sprintf_chk@plt>
    4b6c:	aa1503e0 	mov	x0, x21
    4b70:	97fff1f0 	bl	1330 <strlen@plt>
    4b74:	aa1503e1 	mov	x1, x21
    4b78:	aa0003e2 	mov	x2, x0
    4b7c:	aa1403e0 	mov	x0, x20
    4b80:	97fff4ec 	bl	1f30 <buf_put>
    4b84:	17fffe7b 	b	4570 <fwp_write.constprop.0+0x850>
    4b88:	f9400277 	ldr	x23, [x19]
    4b8c:	aa1603e0 	mov	x0, x22
    4b90:	aa1803e1 	mov	x1, x24
    4b94:	aa1703e2 	mov	x2, x23
    4b98:	937ffefa 	asr	x26, x23, #63
    4b9c:	aa1a03e3 	mov	x3, x26
    4ba0:	94001080 	bl	8da0 <__modti3>
    4ba4:	aa010000 	orr	x0, x0, x1
    4ba8:	b40002c0 	cbz	x0, 4c00 <fwp_write.constprop.0+0xee0>
    4bac:	110006b5 	add	w21, w21, #0x1
    4bb0:	91004273 	add	x19, x19, #0x10
    4bb4:	710016bf 	cmp	w21, #0x5
    4bb8:	54fffe81 	b.ne	4b88 <fwp_write.constprop.0+0xe68>  // b.any
    4bbc:	17ffffde 	b	4b34 <fwp_write.constprop.0+0xe14>
    4bc0:	f9400a60 	ldr	x0, [x19, #16]
    4bc4:	8b000021 	add	x1, x1, x0
    4bc8:	17fffd8c 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4bcc:	528c29c0 	mov	w0, #0x614e                	// #24910
    4bd0:	910123f5 	add	x21, sp, #0x48
    4bd4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4bd8:	b9004be0 	str	w0, [sp, #72]
    4bdc:	17fffdb9 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4be0:	528005a1 	mov	w1, #0x2d                  	// #45
    4be4:	eb1603e2 	negs	x2, x22
    4be8:	da1803e3 	ngc	x3, x24
    4bec:	910027e0 	add	x0, sp, #0x9
    4bf0:	910023f3 	add	x19, sp, #0x8
    4bf4:	390023e1 	strb	w1, [sp, #8]
    4bf8:	97fff37a 	bl	19e0 <fwp_fmt_u128>
    4bfc:	17ffffd4 	b	4b4c <fwp_write.constprop.0+0xe2c>
    4c00:	aa1703e2 	mov	x2, x23
    4c04:	aa1a03e3 	mov	x3, x26
    4c08:	aa1603e0 	mov	x0, x22
    4c0c:	aa1803e1 	mov	x1, x24
    4c10:	94000f84 	bl	8a20 <__divti3>
    4c14:	aa0003e2 	mov	x2, x0
    4c18:	aa0103e3 	mov	x3, x1
    4c1c:	b7f80201 	tbnz	x1, #63, 4c5c <fwp_write.constprop.0+0xf3c>
    4c20:	910023f3 	add	x19, sp, #0x8
    4c24:	aa1303e0 	mov	x0, x19
    4c28:	97fff36e 	bl	19e0 <fwp_fmt_u128>
    4c2c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4c30:	912ca339 	add	x25, x25, #0xb28
    4c34:	910123f5 	add	x21, sp, #0x48
    4c38:	aa1303e4 	mov	x4, x19
    4c3c:	aa1503e0 	mov	x0, x21
    4c40:	b0000023 	adrp	x3, 9000 <__modti3+0x260>
    4c44:	f8616b25 	ldr	x5, [x25, x1]
    4c48:	91108063 	add	x3, x3, #0x420
    4c4c:	d2804002 	mov	x2, #0x200                 	// #512
    4c50:	52800041 	mov	w1, #0x2                   	// #2
    4c54:	97fff1bb 	bl	1340 <__sprintf_chk@plt>
    4c58:	17ffffc5 	b	4b6c <fwp_write.constprop.0+0xe4c>
    4c5c:	528005a4 	mov	w4, #0x2d                  	// #45
    4c60:	eb0003e2 	negs	x2, x0
    4c64:	da0103e3 	ngc	x3, x1
    4c68:	910027e0 	add	x0, sp, #0x9
    4c6c:	910023f3 	add	x19, sp, #0x8
    4c70:	390023e4 	strb	w4, [sp, #8]
    4c74:	97fff35b 	bl	19e0 <fwp_fmt_u128>
    4c78:	17ffffed 	b	4c2c <fwp_write.constprop.0+0xf0c>
    4c7c:	f9013bf5 	str	x21, [sp, #624]
    4c80:	f9013ff6 	str	x22, [sp, #632]
    4c84:	f90143f7 	str	x23, [sp, #640]
    4c88:	f90147f8 	str	x24, [sp, #648]
    4c8c:	f9014bf9 	str	x25, [sp, #656]
    4c90:	f9014ffa 	str	x26, [sp, #664]
    4c94:	f90153fb 	str	x27, [sp, #672]
    4c98:	f90157fc 	str	x28, [sp, #680]
    4c9c:	fd015be8 	str	d8, [sp, #688]
    4ca0:	fd015fe9 	str	d9, [sp, #696]
    4ca4:	97fff1ff 	bl	14a0 <__stack_chk_fail@plt>
    4ca8:	f90143f7 	str	x23, [sp, #640]
    4cac:	f90147f8 	str	x24, [sp, #648]
    4cb0:	f9014bf9 	str	x25, [sp, #656]
    4cb4:	f9014ffa 	str	x26, [sp, #664]
    4cb8:	fd015be8 	str	d8, [sp, #688]
    4cbc:	fd015fe9 	str	d9, [sp, #696]
    4cc0:	97fff1f8 	bl	14a0 <__stack_chk_fail@plt>

0000000000004cc4 <fwp_hof0.constprop.0>:
    4cc4:	d10443ff 	sub	sp, sp, #0x110
    4cc8:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x14c18>
    4ccc:	f947f442 	ldr	x2, [x2, #4072]
    4cd0:	a9077bfd 	stp	x29, x30, [sp, #112]
    4cd4:	9101c3fd 	add	x29, sp, #0x70
    4cd8:	f90007e0 	str	x0, [sp, #8]
    4cdc:	f9400040 	ldr	x0, [x2]
    4ce0:	f90037e0 	str	x0, [sp, #104]
    4ce4:	d2800000 	mov	x0, #0x0                   	// #0
    4ce8:	f9000fe1 	str	x1, [sp, #24]
    4cec:	b4005dc1 	cbz	x1, 58a4 <fwp_hof0.constprop.0+0xbe0>
    4cf0:	b0000021 	adrp	x1, 9000 <__modti3+0x260>
    4cf4:	6d0e2fea 	stp	d10, d11, [sp, #224]
    4cf8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    4cfc:	fd43402a 	ldr	d10, [x1, #1664]
    4d00:	a90853f3 	stp	x19, x20, [sp, #128]
    4d04:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    4d08:	a9095bf5 	stp	x21, x22, [sp, #144]
    4d0c:	a90a63f7 	stp	x23, x24, [sp, #160]
    4d10:	a90b6bf9 	stp	x25, x26, [sp, #176]
    4d14:	a90c73fb 	stp	x27, x28, [sp, #192]
    4d18:	6d0d27e8 	stp	d8, d9, [sp, #208]
    4d1c:	9e670009 	fmov	d9, x0
    4d20:	6d0f37ec 	stp	d12, d13, [sp, #240]
    4d24:	6d103fee 	stp	d14, d15, [sp, #256]
    4d28:	91144262 	add	x2, x19, #0x510
    4d2c:	f94007e3 	ldr	x3, [sp, #8]
    4d30:	f949d840 	ldr	x0, [x2, #5040]
    4d34:	f949ec41 	ldr	x1, [x2, #5080]
    4d38:	cb000060 	sub	x0, x3, x0
    4d3c:	eb01401f 	cmp	x0, x1, lsl #16
    4d40:	54000342 	b.cs	4da8 <fwp_hof0.constprop.0+0xe4>  // b.hs, b.nlast
    4d44:	d350fc01 	lsr	x1, x0, #16
    4d48:	f949fc43 	ldr	x3, [x2, #5112]
    4d4c:	8b010821 	add	x1, x1, x1, lsl #2
    4d50:	d37df021 	lsl	x1, x1, #3
    4d54:	8b010062 	add	x2, x3, x1
    4d58:	f9401054 	ldr	x20, [x2, #32]
    4d5c:	b4000274 	cbz	x20, 4da8 <fwp_hof0.constprop.0+0xe4>
    4d60:	38616861 	ldrb	w1, [x3, x1]
    4d64:	7100083f 	cmp	w1, #0x2
    4d68:	54006ec0 	b.eq	5b40 <fwp_hof0.constprop.0+0xe7c>  // b.none
    4d6c:	7100043f 	cmp	w1, #0x1
    4d70:	540001c1 	b.ne	4da8 <fwp_hof0.constprop.0+0xe4>  // b.any
    4d74:	29430443 	ldp	w3, w1, [x2, #24]
    4d78:	92403c00 	and	x0, x0, #0xffff
    4d7c:	9b037c00 	mul	x0, x0, x3
    4d80:	d360fc00 	lsr	x0, x0, #32
    4d84:	eb01001f 	cmp	x0, x1
    4d88:	54000102 	b.cs	4da8 <fwp_hof0.constprop.0+0xe4>  // b.hs, b.nlast
    4d8c:	8b000294 	add	x20, x20, x0
    4d90:	39400280 	ldrb	w0, [x20]
    4d94:	340000a0 	cbz	w0, 4da8 <fwp_hof0.constprop.0+0xe4>
    4d98:	7103f41f 	cmp	w0, #0xfd
    4d9c:	540079e8 	b.hi	5cd8 <fwp_hof0.constprop.0+0x1014>  // b.pmore
    4da0:	11000400 	add	w0, w0, #0x1
    4da4:	39000280 	strb	w0, [x20]
    4da8:	f94007e0 	ldr	x0, [sp, #8]
    4dac:	b4006d20 	cbz	x0, 5b50 <fwp_hof0.constprop.0+0xe8c>
    4db0:	aa0003e1 	mov	x1, x0
    4db4:	d2800000 	mov	x0, #0x0                   	// #0
    4db8:	f9400821 	ldr	x1, [x1, #16]
    4dbc:	91000400 	add	x0, x0, #0x1
    4dc0:	b5ffffc1 	cbnz	x1, 4db8 <fwp_hof0.constprop.0+0xf4>
    4dc4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    4dc8:	eb01001f 	cmp	x0, x1
    4dcc:	540081c8 	b.hi	5e04 <fwp_hof0.constprop.0+0x1140>  // b.pmore
    4dd0:	97fffa14 	bl	3620 <fwp_array_new_packed.constprop.0>
    4dd4:	aa0003f4 	mov	x20, x0
    4dd8:	91144261 	add	x1, x19, #0x510
    4ddc:	aa0103e0 	mov	x0, x1
    4de0:	f949d821 	ldr	x1, [x1, #5040]
    4de4:	f949ec00 	ldr	x0, [x0, #5080]
    4de8:	cb010281 	sub	x1, x20, x1
    4dec:	eb00403f 	cmp	x1, x0, lsl #16
    4df0:	54000382 	b.cs	4e60 <fwp_hof0.constprop.0+0x19c>  // b.hs, b.nlast
    4df4:	91144262 	add	x2, x19, #0x510
    4df8:	d350fc20 	lsr	x0, x1, #16
    4dfc:	8b000800 	add	x0, x0, x0, lsl #2
    4e00:	f949fc43 	ldr	x3, [x2, #5112]
    4e04:	d37df002 	lsl	x2, x0, #3
    4e08:	8b020060 	add	x0, x3, x2
    4e0c:	f9401015 	ldr	x21, [x0, #32]
    4e10:	b4000255 	cbz	x21, 4e58 <fwp_hof0.constprop.0+0x194>
    4e14:	38626862 	ldrb	w2, [x3, x2]
    4e18:	7100085f 	cmp	w2, #0x2
    4e1c:	54006b20 	b.eq	5b80 <fwp_hof0.constprop.0+0xebc>  // b.none
    4e20:	7100045f 	cmp	w2, #0x1
    4e24:	540001a1 	b.ne	4e58 <fwp_hof0.constprop.0+0x194>  // b.any
    4e28:	29430002 	ldp	w2, w0, [x0, #24]
    4e2c:	92403c21 	and	x1, x1, #0xffff
    4e30:	9b027c21 	mul	x1, x1, x2
    4e34:	d360fc21 	lsr	x1, x1, #32
    4e38:	eb00003f 	cmp	x1, x0
    4e3c:	540000e2 	b.cs	4e58 <fwp_hof0.constprop.0+0x194>  // b.hs, b.nlast
    4e40:	8b0102b5 	add	x21, x21, x1
    4e44:	394002a0 	ldrb	w0, [x21]
    4e48:	7103fc1f 	cmp	w0, #0xff
    4e4c:	54006a40 	b.eq	5b94 <fwp_hof0.constprop.0+0xed0>  // b.none
    4e50:	52800020 	mov	w0, #0x1                   	// #1
    4e54:	390002a0 	strb	w0, [x21]
    4e58:	f94007e0 	ldr	x0, [sp, #8]
    4e5c:	b40068e0 	cbz	x0, 5b78 <fwp_hof0.constprop.0+0xeb4>
    4e60:	f94007f5 	ldr	x21, [sp, #8]
    4e64:	91002296 	add	x22, x20, #0x8
    4e68:	91144277 	add	x23, x19, #0x510
    4e6c:	52800038 	mov	w24, #0x1                   	// #1
    4e70:	aa1503e0 	mov	x0, x21
    4e74:	14000013 	b	4ec0 <fwp_hof0.constprop.0+0x1fc>
    4e78:	7100045f 	cmp	w2, #0x1
    4e7c:	54000161 	b.ne	4ea8 <fwp_hof0.constprop.0+0x1e4>  // b.any
    4e80:	294308e8 	ldp	w8, w2, [x7, #24]
    4e84:	92403c21 	and	x1, x1, #0xffff
    4e88:	9b087c21 	mul	x1, x1, x8
    4e8c:	d360fc21 	lsr	x1, x1, #32
    4e90:	eb02003f 	cmp	x1, x2
    4e94:	540000a2 	b.cs	4ea8 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    4e98:	8b0100c6 	add	x6, x6, x1
    4e9c:	394000c1 	ldrb	w1, [x6]
    4ea0:	7100043f 	cmp	w1, #0x1
    4ea4:	540003e0 	b.eq	4f20 <fwp_hof0.constprop.0+0x25c>  // b.none
    4ea8:	f9400281 	ldr	x1, [x20]
    4eac:	b7f87761 	tbnz	x1, #63, 5d98 <fwp_hof0.constprop.0+0x10d4>
    4eb0:	f90002c4 	str	x4, [x22]
    4eb4:	52800018 	mov	w24, #0x0                   	// #0
    4eb8:	910022d6 	add	x22, x22, #0x8
    4ebc:	b4000775 	cbz	x21, 4fa8 <fwp_hof0.constprop.0+0x2e4>
    4ec0:	aa1503e5 	mov	x5, x21
    4ec4:	aa1503e3 	mov	x3, x21
    4ec8:	a940d6a4 	ldp	x4, x21, [x21, #8]
    4ecc:	34fffef8 	cbz	w24, 4ea8 <fwp_hof0.constprop.0+0x1e4>
    4ed0:	f949dae1 	ldr	x1, [x23, #5040]
    4ed4:	f949eee2 	ldr	x2, [x23, #5080]
    4ed8:	cb0100a1 	sub	x1, x5, x1
    4edc:	eb02403f 	cmp	x1, x2, lsl #16
    4ee0:	54fffe42 	b.cs	4ea8 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    4ee4:	d350fc22 	lsr	x2, x1, #16
    4ee8:	f949fee8 	ldr	x8, [x23, #5112]
    4eec:	8b020842 	add	x2, x2, x2, lsl #2
    4ef0:	d37df042 	lsl	x2, x2, #3
    4ef4:	8b020107 	add	x7, x8, x2
    4ef8:	f94010e6 	ldr	x6, [x7, #32]
    4efc:	b4fffd66 	cbz	x6, 4ea8 <fwp_hof0.constprop.0+0x1e4>
    4f00:	38626902 	ldrb	w2, [x8, x2]
    4f04:	7100085f 	cmp	w2, #0x2
    4f08:	54fffb81 	b.ne	4e78 <fwp_hof0.constprop.0+0x1b4>  // b.any
    4f0c:	72003c3f 	tst	w1, #0xffff
    4f10:	54fffcc1 	b.ne	4ea8 <fwp_hof0.constprop.0+0x1e4>  // b.any
    4f14:	394000c1 	ldrb	w1, [x6]
    4f18:	7100043f 	cmp	w1, #0x1
    4f1c:	54fffc61 	b.ne	4ea8 <fwp_hof0.constprop.0+0x1e4>  // b.any
    4f20:	f9400280 	ldr	x0, [x20]
    4f24:	b7f873a0 	tbnz	x0, #63, 5d98 <fwp_hof0.constprop.0+0x10d4>
    4f28:	f90002c4 	str	x4, [x22]
    4f2c:	f949dae1 	ldr	x1, [x23, #5040]
    4f30:	f949eee0 	ldr	x0, [x23, #5080]
    4f34:	cb010063 	sub	x3, x3, x1
    4f38:	eb00407f 	cmp	x3, x0, lsl #16
    4f3c:	540002e2 	b.cs	4f98 <fwp_hof0.constprop.0+0x2d4>  // b.hs, b.nlast
    4f40:	d350fc60 	lsr	x0, x3, #16
    4f44:	f949fee1 	ldr	x1, [x23, #5112]
    4f48:	8b000800 	add	x0, x0, x0, lsl #2
    4f4c:	d37df000 	lsl	x0, x0, #3
    4f50:	8b000024 	add	x4, x1, x0
    4f54:	f9401082 	ldr	x2, [x4, #32]
    4f58:	b4000202 	cbz	x2, 4f98 <fwp_hof0.constprop.0+0x2d4>
    4f5c:	38606820 	ldrb	w0, [x1, x0]
    4f60:	7100081f 	cmp	w0, #0x2
    4f64:	54005ca0 	b.eq	5af8 <fwp_hof0.constprop.0+0xe34>  // b.none
    4f68:	7100041f 	cmp	w0, #0x1
    4f6c:	54000161 	b.ne	4f98 <fwp_hof0.constprop.0+0x2d4>  // b.any
    4f70:	29430086 	ldp	w6, w0, [x4, #24]
    4f74:	92403c61 	and	x1, x3, #0xffff
    4f78:	9b067c21 	mul	x1, x1, x6
    4f7c:	d360fc21 	lsr	x1, x1, #32
    4f80:	eb00003f 	cmp	x1, x0
    4f84:	540000a2 	b.cs	4f98 <fwp_hof0.constprop.0+0x2d4>  // b.hs, b.nlast
    4f88:	8b010042 	add	x2, x2, x1
    4f8c:	39400040 	ldrb	w0, [x2]
    4f90:	7100041f 	cmp	w0, #0x1
    4f94:	540021a0 	b.eq	53c8 <fwp_hof0.constprop.0+0x704>  // b.none
    4f98:	aa1503e0 	mov	x0, x21
    4f9c:	910022d6 	add	x22, x22, #0x8
    4fa0:	b5fff915 	cbnz	x21, 4ec0 <fwp_hof0.constprop.0+0x1fc>
    4fa4:	d503201f 	nop
    4fa8:	d28018d7 	mov	x23, #0xc6                  	// #198
    4fac:	b27feffa 	mov	x26, #0x1ffffffffffffffe    	// #2305843009213693950
    4fb0:	97fff9b0 	bl	3670 <fwp_drop0>
    4fb4:	d503201f 	nop
    4fb8:	f9400296 	ldr	x22, [x20]
    4fbc:	9240fad6 	and	x22, x22, #0x7fffffffffffffff
    4fc0:	eb1a02df 	cmp	x22, x26
    4fc4:	54007208 	b.hi	5e04 <fwp_hof0.constprop.0+0x1140>  // b.pmore
    4fc8:	aa1603e0 	mov	x0, x22
    4fcc:	97fff995 	bl	3620 <fwp_array_new_packed.constprop.0>
    4fd0:	91144262 	add	x2, x19, #0x510
    4fd4:	aa0003f5 	mov	x21, x0
    4fd8:	f949d841 	ldr	x1, [x2, #5040]
    4fdc:	f949ec40 	ldr	x0, [x2, #5080]
    4fe0:	cb0102a1 	sub	x1, x21, x1
    4fe4:	eb00403f 	cmp	x1, x0, lsl #16
    4fe8:	54000322 	b.cs	504c <fwp_hof0.constprop.0+0x388>  // b.hs, b.nlast
    4fec:	d350fc20 	lsr	x0, x1, #16
    4ff0:	f949fc43 	ldr	x3, [x2, #5112]
    4ff4:	8b000800 	add	x0, x0, x0, lsl #2
    4ff8:	d37df002 	lsl	x2, x0, #3
    4ffc:	8b020060 	add	x0, x3, x2
    5000:	f9401018 	ldr	x24, [x0, #32]
    5004:	b4000258 	cbz	x24, 504c <fwp_hof0.constprop.0+0x388>
    5008:	38626862 	ldrb	w2, [x3, x2]
    500c:	7100085f 	cmp	w2, #0x2
    5010:	54004bc0 	b.eq	5988 <fwp_hof0.constprop.0+0xcc4>  // b.none
    5014:	7100045f 	cmp	w2, #0x1
    5018:	540001a1 	b.ne	504c <fwp_hof0.constprop.0+0x388>  // b.any
    501c:	29430002 	ldp	w2, w0, [x0, #24]
    5020:	92403c21 	and	x1, x1, #0xffff
    5024:	9b027c21 	mul	x1, x1, x2
    5028:	d360fc21 	lsr	x1, x1, #32
    502c:	eb00003f 	cmp	x1, x0
    5030:	540000e2 	b.cs	504c <fwp_hof0.constprop.0+0x388>  // b.hs, b.nlast
    5034:	8b010318 	add	x24, x24, x1
    5038:	39400300 	ldrb	w0, [x24]
    503c:	7103fc1f 	cmp	w0, #0xff
    5040:	54004ae0 	b.eq	599c <fwp_hof0.constprop.0+0xcd8>  // b.none
    5044:	52800020 	mov	w0, #0x1                   	// #1
    5048:	39000300 	strb	w0, [x24]
    504c:	d280011b 	mov	x27, #0x8                   	// #8
    5050:	2f00e408 	movi	d8, #0x0
    5054:	8b1b0298 	add	x24, x20, x27
    5058:	d280001c 	mov	x28, #0x0                   	// #0
    505c:	b5001a76 	cbnz	x22, 53a8 <fwp_hof0.constprop.0+0x6e4>
    5060:	14000108 	b	5480 <fwp_hof0.constprop.0+0x7bc>
    5064:	aa1803e0 	mov	x0, x24
    5068:	b7f84342 	tbnz	x2, #63, 58d0 <fwp_hof0.constprop.0+0xc0c>
    506c:	fc7c780b 	ldr	d11, [x0, x28, lsl #3]
    5070:	9e6703ec 	fmov	d12, xzr
    5074:	b400027c 	cbz	x28, 50c0 <fwp_hof0.constprop.0+0x3fc>
    5078:	8b1b0000 	add	x0, x0, x27
    507c:	1e6e100c 	fmov	d12, #1.000000000000000000e+00
    5080:	fc5f0000 	ldur	d0, [x0, #-16]
    5084:	1e680802 	fmul	d2, d0, d8
    5088:	1e600801 	fmul	d1, d0, d0
    508c:	1e603980 	fsub	d0, d12, d0
    5090:	1e622842 	fadd	d2, d2, d2
    5094:	1e613961 	fsub	d1, d11, d1
    5098:	1e680800 	fmul	d0, d0, d8
    509c:	1e62398c 	fsub	d12, d12, d2
    50a0:	1e610822 	fmul	d2, d1, d1
    50a4:	1e602800 	fadd	d0, d0, d0
    50a8:	1e61098c 	fmul	d12, d12, d1
    50ac:	1e680841 	fmul	d1, d2, d8
    50b0:	1e6c298c 	fadd	d12, d12, d12
    50b4:	1e69098c 	fmul	d12, d12, d9
    50b8:	1e61298c 	fadd	d12, d12, d1
    50bc:	1e60298c 	fadd	d12, d12, d0
    50c0:	9100079c 	add	x28, x28, #0x1
    50c4:	eb1c003f 	cmp	x1, x28
    50c8:	54001880 	b.eq	53d8 <fwp_hof0.constprop.0+0x714>  // b.none
    50cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    50d0:	910163e1 	add	x1, sp, #0x58
    50d4:	52800000 	mov	w0, #0x0                   	// #0
    50d8:	f9002fe2 	str	x2, [sp, #88]
    50dc:	fd0033eb 	str	d11, [sp, #96]
    50e0:	97fff908 	bl	3500 <fwp_data.part.0.constprop.0>
    50e4:	91144263 	add	x3, x19, #0x510
    50e8:	aa0003f9 	mov	x25, x0
    50ec:	f949d861 	ldr	x1, [x3, #5040]
    50f0:	f949ec60 	ldr	x0, [x3, #5080]
    50f4:	cb010321 	sub	x1, x25, x1
    50f8:	eb00403f 	cmp	x1, x0, lsl #16
    50fc:	54000322 	b.cs	5160 <fwp_hof0.constprop.0+0x49c>  // b.hs, b.nlast
    5100:	d350fc22 	lsr	x2, x1, #16
    5104:	f949fc66 	ldr	x6, [x3, #5112]
    5108:	8b020842 	add	x2, x2, x2, lsl #2
    510c:	d37df042 	lsl	x2, x2, #3
    5110:	8b0200c3 	add	x3, x6, x2
    5114:	f9401060 	ldr	x0, [x3, #32]
    5118:	b4000240 	cbz	x0, 5160 <fwp_hof0.constprop.0+0x49c>
    511c:	386268c2 	ldrb	w2, [x6, x2]
    5120:	7100085f 	cmp	w2, #0x2
    5124:	540017a0 	b.eq	5418 <fwp_hof0.constprop.0+0x754>  // b.none
    5128:	7100045f 	cmp	w2, #0x1
    512c:	540001a1 	b.ne	5160 <fwp_hof0.constprop.0+0x49c>  // b.any
    5130:	29430866 	ldp	w6, w2, [x3, #24]
    5134:	92403c21 	and	x1, x1, #0xffff
    5138:	9b067c21 	mul	x1, x1, x6
    513c:	d360fc21 	lsr	x1, x1, #32
    5140:	eb02003f 	cmp	x1, x2
    5144:	540000e2 	b.cs	5160 <fwp_hof0.constprop.0+0x49c>  // b.hs, b.nlast
    5148:	8b010000 	add	x0, x0, x1
    514c:	39400001 	ldrb	w1, [x0]
    5150:	7103fc3f 	cmp	w1, #0xff
    5154:	540016e0 	b.eq	5430 <fwp_hof0.constprop.0+0x76c>  // b.none
    5158:	52800021 	mov	w1, #0x1                   	// #1
    515c:	39000001 	strb	w1, [x0]
    5160:	f9400280 	ldr	x0, [x20]
    5164:	9240f801 	and	x1, x0, #0x7fffffffffffffff
    5168:	eb1c003f 	cmp	x1, x28
    516c:	54001269 	b.ls	53b8 <fwp_hof0.constprop.0+0x6f4>  // b.plast
    5170:	aa1803e2 	mov	x2, x24
    5174:	b7f83b20 	tbnz	x0, #63, 58d8 <fwp_hof0.constprop.0+0xc14>
    5178:	f87b6842 	ldr	x2, [x2, x27]
    517c:	910123e1 	add	x1, sp, #0x48
    5180:	52800000 	mov	w0, #0x0                   	// #0
    5184:	a9048bff 	stp	xzr, x2, [sp, #72]
    5188:	97fff8de 	bl	3500 <fwp_data.part.0.constprop.0>
    518c:	aa0003e8 	mov	x8, x0
    5190:	91144267 	add	x7, x19, #0x510
    5194:	f949ece6 	ldr	x6, [x7, #5080]
    5198:	f949d8e2 	ldr	x2, [x7, #5040]
    519c:	d370bcc6 	lsl	x6, x6, #16
    51a0:	cb020001 	sub	x1, x0, x2
    51a4:	eb06003f 	cmp	x1, x6
    51a8:	540003c2 	b.cs	5220 <fwp_hof0.constprop.0+0x55c>  // b.hs, b.nlast
    51ac:	d350fc23 	lsr	x3, x1, #16
    51b0:	f949fcea 	ldr	x10, [x7, #5112]
    51b4:	8b030867 	add	x7, x3, x3, lsl #2
    51b8:	d37df0e7 	lsl	x7, x7, #3
    51bc:	8b070149 	add	x9, x10, x7
    51c0:	f9401120 	ldr	x0, [x9, #32]
    51c4:	b4001420 	cbz	x0, 5448 <fwp_hof0.constprop.0+0x784>
    51c8:	38676947 	ldrb	w7, [x10, x7]
    51cc:	710008ff 	cmp	w7, #0x2
    51d0:	54001380 	b.eq	5440 <fwp_hof0.constprop.0+0x77c>  // b.none
    51d4:	710004ff 	cmp	w7, #0x1
    51d8:	54001381 	b.ne	5448 <fwp_hof0.constprop.0+0x784>  // b.any
    51dc:	2943252a 	ldp	w10, w9, [x9, #24]
    51e0:	92403c27 	and	x7, x1, #0xffff
    51e4:	9b0a7ce7 	mul	x7, x7, x10
    51e8:	d360fce7 	lsr	x7, x7, #32
    51ec:	eb0900ff 	cmp	x7, x9
    51f0:	540012c2 	b.cs	5448 <fwp_hof0.constprop.0+0x784>  // b.hs, b.nlast
    51f4:	8b070000 	add	x0, x0, x7
    51f8:	39400001 	ldrb	w1, [x0]
    51fc:	7103fc3f 	cmp	w1, #0xff
    5200:	54003700 	b.eq	58e0 <fwp_hof0.constprop.0+0xc1c>  // b.none
    5204:	91144261 	add	x1, x19, #0x510
    5208:	52800022 	mov	w2, #0x1                   	// #1
    520c:	39000002 	strb	w2, [x0]
    5210:	f949ec26 	ldr	x6, [x1, #5080]
    5214:	f949d822 	ldr	x2, [x1, #5040]
    5218:	d370bcc6 	lsl	x6, x6, #16
    521c:	cb020101 	sub	x1, x8, x2
    5220:	fd400b24 	ldr	d4, [x25, #16]
    5224:	fd400722 	ldr	d2, [x25, #8]
    5228:	6d40b900 	ldp	d0, d14, [x8, #8]
    522c:	1e64088f 	fmul	d15, d4, d4
    5230:	1e640843 	fmul	d3, d2, d4
    5234:	1e632863 	fadd	d3, d3, d3
    5238:	1e63380d 	fsub	d13, d0, d3
    523c:	eb06003f 	cmp	x1, x6
    5240:	54000482 	b.cs	52d0 <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    5244:	d350fc23 	lsr	x3, x1, #16
    5248:	91144260 	add	x0, x19, #0x510
    524c:	8b030863 	add	x3, x3, x3, lsl #2
    5250:	d37df063 	lsl	x3, x3, #3
    5254:	f949fc09 	ldr	x9, [x0, #5112]
    5258:	8b030127 	add	x7, x9, x3
    525c:	f94010e0 	ldr	x0, [x7, #32]
    5260:	b4000380 	cbz	x0, 52d0 <fwp_hof0.constprop.0+0x60c>
    5264:	38636923 	ldrb	w3, [x9, x3]
    5268:	7100087f 	cmp	w3, #0x2
    526c:	54000fe0 	b.eq	5468 <fwp_hof0.constprop.0+0x7a4>  // b.none
    5270:	7100047f 	cmp	w3, #0x1
    5274:	540002e1 	b.ne	52d0 <fwp_hof0.constprop.0+0x60c>  // b.any
    5278:	29430ce9 	ldp	w9, w3, [x7, #24]
    527c:	92403c21 	and	x1, x1, #0xffff
    5280:	9b097c21 	mul	x1, x1, x9
    5284:	d360fc21 	lsr	x1, x1, #32
    5288:	eb03003f 	cmp	x1, x3
    528c:	54000222 	b.cs	52d0 <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    5290:	8b010000 	add	x0, x0, x1
    5294:	39400001 	ldrb	w1, [x0]
    5298:	340001c1 	cbz	w1, 52d0 <fwp_hof0.constprop.0+0x60c>
    529c:	7100043f 	cmp	w1, #0x1
    52a0:	54000a00 	b.eq	53e0 <fwp_hof0.constprop.0+0x71c>  // b.none
    52a4:	7103fc3f 	cmp	w1, #0xff
    52a8:	54003c60 	b.eq	5a34 <fwp_hof0.constprop.0+0xd70>  // b.none
    52ac:	91144262 	add	x2, x19, #0x510
    52b0:	51000421 	sub	w1, w1, #0x1
    52b4:	39000001 	strb	w1, [x0]
    52b8:	f949ec46 	ldr	x6, [x2, #5080]
    52bc:	fd400b24 	ldr	d4, [x25, #16]
    52c0:	f949d842 	ldr	x2, [x2, #5040]
    52c4:	d370bcc6 	lsl	x6, x6, #16
    52c8:	fd400722 	ldr	d2, [x25, #8]
    52cc:	d503201f 	nop
    52d0:	cb020322 	sub	x2, x25, x2
    52d4:	1e6f39ce 	fsub	d14, d14, d15
    52d8:	1e62390f 	fsub	d15, d8, d2
    52dc:	eb0200df 	cmp	x6, x2
    52e0:	540003c9 	b.ls	5358 <fwp_hof0.constprop.0+0x694>  // b.plast
    52e4:	91144261 	add	x1, x19, #0x510
    52e8:	d350fc40 	lsr	x0, x2, #16
    52ec:	8b000800 	add	x0, x0, x0, lsl #2
    52f0:	f949fc26 	ldr	x6, [x1, #5112]
    52f4:	d37df000 	lsl	x0, x0, #3
    52f8:	8b0000c3 	add	x3, x6, x0
    52fc:	f9401061 	ldr	x1, [x3, #32]
    5300:	b40002c1 	cbz	x1, 5358 <fwp_hof0.constprop.0+0x694>
    5304:	386068c0 	ldrb	w0, [x6, x0]
    5308:	7100081f 	cmp	w0, #0x2
    530c:	54000b40 	b.eq	5474 <fwp_hof0.constprop.0+0x7b0>  // b.none
    5310:	7100041f 	cmp	w0, #0x1
    5314:	54000221 	b.ne	5358 <fwp_hof0.constprop.0+0x694>  // b.any
    5318:	29430066 	ldp	w6, w0, [x3, #24]
    531c:	92403c42 	and	x2, x2, #0xffff
    5320:	9b067c42 	mul	x2, x2, x6
    5324:	d360fc42 	lsr	x2, x2, #32
    5328:	eb00005f 	cmp	x2, x0
    532c:	54000162 	b.cs	5358 <fwp_hof0.constprop.0+0x694>  // b.hs, b.nlast
    5330:	8b020021 	add	x1, x1, x2
    5334:	39400020 	ldrb	w0, [x1]
    5338:	34000100 	cbz	w0, 5358 <fwp_hof0.constprop.0+0x694>
    533c:	7100041f 	cmp	w0, #0x1
    5340:	54000620 	b.eq	5404 <fwp_hof0.constprop.0+0x740>  // b.none
    5344:	7103fc1f 	cmp	w0, #0xff
    5348:	540039e0 	b.eq	5a84 <fwp_hof0.constprop.0+0xdc0>  // b.none
    534c:	51000400 	sub	w0, w0, #0x1
    5350:	39000020 	strb	w0, [x1]
    5354:	d503201f 	nop
    5358:	1e6e09a0 	fmul	d0, d13, d14
    535c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5360:	1e6e09ce 	fmul	d14, d14, d14
    5364:	1e643821 	fsub	d1, d1, d4
    5368:	1e602800 	fadd	d0, d0, d0
    536c:	1e6809ce 	fmul	d14, d14, d8
    5370:	1e6f0821 	fmul	d1, d1, d15
    5374:	1e690800 	fmul	d0, d0, d9
    5378:	1e612821 	fadd	d1, d1, d1
    537c:	1e6e2800 	fadd	d0, d0, d14
    5380:	1e612800 	fadd	d0, d0, d1
    5384:	1e6c2800 	fadd	d0, d0, d12
    5388:	f94002a0 	ldr	x0, [x21]
    538c:	1e6a0800 	fmul	d0, d0, d10
    5390:	1e603960 	fsub	d0, d11, d0
    5394:	b7f85020 	tbnz	x0, #63, 5d98 <fwp_hof0.constprop.0+0x10d4>
    5398:	fc3b6aa0 	str	d0, [x21, x27]
    539c:	9100237b 	add	x27, x27, #0x8
    53a0:	eb1c02df 	cmp	x22, x28
    53a4:	540006e0 	b.eq	5480 <fwp_hof0.constprop.0+0x7bc>  // b.none
    53a8:	f9400282 	ldr	x2, [x20]
    53ac:	9240f841 	and	x1, x2, #0x7fffffffffffffff
    53b0:	eb01039f 	cmp	x28, x1
    53b4:	54ffe583 	b.cc	5064 <fwp_hof0.constprop.0+0x3a0>  // b.lo, b.ul, b.last
    53b8:	f00000c0 	adrp	x0, 20000 <__data_start>
    53bc:	91004000 	add	x0, x0, #0x10
    53c0:	91002000 	add	x0, x0, #0x8
    53c4:	97fff337 	bl	20a0 <fwp_trap>
    53c8:	aa0503e0 	mov	x0, x5
    53cc:	97fff695 	bl	2e20 <fwp_mem_free>
    53d0:	aa1503e0 	mov	x0, x21
    53d4:	17fffef2 	b	4f9c <fwp_hof0.constprop.0+0x2d8>
    53d8:	2f00e400 	movi	d0, #0x0
    53dc:	17ffffea 	b	5384 <fwp_hof0.constprop.0+0x6c0>
    53e0:	aa0803e0 	mov	x0, x8
    53e4:	97fff7df 	bl	3360 <fwp_rc_free_arr>
    53e8:	91144260 	add	x0, x19, #0x510
    53ec:	fd400722 	ldr	d2, [x25, #8]
    53f0:	fd400b24 	ldr	d4, [x25, #16]
    53f4:	f949ec06 	ldr	x6, [x0, #5080]
    53f8:	f949d802 	ldr	x2, [x0, #5040]
    53fc:	d370bcc6 	lsl	x6, x6, #16
    5400:	17ffffb4 	b	52d0 <fwp_hof0.constprop.0+0x60c>
    5404:	aa1903e0 	mov	x0, x25
    5408:	fd0003e4 	str	d4, [sp]
    540c:	97fff7d5 	bl	3360 <fwp_rc_free_arr>
    5410:	fd4003e4 	ldr	d4, [sp]
    5414:	17ffffd1 	b	5358 <fwp_hof0.constprop.0+0x694>
    5418:	72003c3f 	tst	w1, #0xffff
    541c:	54ffea21 	b.ne	5160 <fwp_hof0.constprop.0+0x49c>  // b.any
    5420:	39400001 	ldrb	w1, [x0]
    5424:	7103fc3f 	cmp	w1, #0xff
    5428:	54ffe981 	b.ne	5158 <fwp_hof0.constprop.0+0x494>  // b.any
    542c:	d503201f 	nop
    5430:	f90003e0 	str	x0, [sp]
    5434:	97fff5dc 	bl	2ba4 <fwp_rc_forget_slot>
    5438:	f94003e0 	ldr	x0, [sp]
    543c:	17ffff47 	b	5158 <fwp_hof0.constprop.0+0x494>
    5440:	72003c3f 	tst	w1, #0xffff
    5444:	54ffeda0 	b.eq	51f8 <fwp_hof0.constprop.0+0x534>  // b.none
    5448:	fd400b24 	ldr	d4, [x25, #16]
    544c:	fd400722 	ldr	d2, [x25, #8]
    5450:	6d40b900 	ldp	d0, d14, [x8, #8]
    5454:	1e64088f 	fmul	d15, d4, d4
    5458:	1e620883 	fmul	d3, d4, d2
    545c:	1e632863 	fadd	d3, d3, d3
    5460:	1e63380d 	fsub	d13, d0, d3
    5464:	17ffff79 	b	5248 <fwp_hof0.constprop.0+0x584>
    5468:	72003c3f 	tst	w1, #0xffff
    546c:	54fff321 	b.ne	52d0 <fwp_hof0.constprop.0+0x60c>  // b.any
    5470:	17ffff89 	b	5294 <fwp_hof0.constprop.0+0x5d0>
    5474:	72003c5f 	tst	w2, #0xffff
    5478:	54fff701 	b.ne	5358 <fwp_hof0.constprop.0+0x694>  // b.any
    547c:	17ffffae 	b	5334 <fwp_hof0.constprop.0+0x670>
    5480:	91144276 	add	x22, x19, #0x510
    5484:	f949dac1 	ldr	x1, [x22, #5040]
    5488:	f949eec0 	ldr	x0, [x22, #5080]
    548c:	cb010281 	sub	x1, x20, x1
    5490:	eb00403f 	cmp	x1, x0, lsl #16
    5494:	540003a2 	b.cs	5508 <fwp_hof0.constprop.0+0x844>  // b.hs, b.nlast
    5498:	d350fc20 	lsr	x0, x1, #16
    549c:	f949fec4 	ldr	x4, [x22, #5112]
    54a0:	8b000800 	add	x0, x0, x0, lsl #2
    54a4:	d37df000 	lsl	x0, x0, #3
    54a8:	8b000082 	add	x2, x4, x0
    54ac:	f9401058 	ldr	x24, [x2, #32]
    54b0:	b40002d8 	cbz	x24, 5508 <fwp_hof0.constprop.0+0x844>
    54b4:	38606880 	ldrb	w0, [x4, x0]
    54b8:	7100081f 	cmp	w0, #0x2
    54bc:	540021e0 	b.eq	58f8 <fwp_hof0.constprop.0+0xc34>  // b.none
    54c0:	7100041f 	cmp	w0, #0x1
    54c4:	54000221 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    54c8:	29430043 	ldp	w3, w0, [x2, #24]
    54cc:	92403c21 	and	x1, x1, #0xffff
    54d0:	9b037c21 	mul	x1, x1, x3
    54d4:	d360fc21 	lsr	x1, x1, #32
    54d8:	eb00003f 	cmp	x1, x0
    54dc:	54000162 	b.cs	5508 <fwp_hof0.constprop.0+0x844>  // b.hs, b.nlast
    54e0:	8b010318 	add	x24, x24, x1
    54e4:	39400300 	ldrb	w0, [x24]
    54e8:	34000100 	cbz	w0, 5508 <fwp_hof0.constprop.0+0x844>
    54ec:	7100041f 	cmp	w0, #0x1
    54f0:	54000160 	b.eq	551c <fwp_hof0.constprop.0+0x858>  // b.none
    54f4:	7103fc1f 	cmp	w0, #0xff
    54f8:	54003540 	b.eq	5ba0 <fwp_hof0.constprop.0+0xedc>  // b.none
    54fc:	51000400 	sub	w0, w0, #0x1
    5500:	39000300 	strb	w0, [x24]
    5504:	d503201f 	nop
    5508:	b40004d7 	cbz	x23, 55a0 <fwp_hof0.constprop.0+0x8dc>
    550c:	f10006f7 	subs	x23, x23, #0x1
    5510:	54004a66 	b.vs	5e5c <fwp_hof0.constprop.0+0x1198>
    5514:	aa1503f4 	mov	x20, x21
    5518:	17fffea8 	b	4fb8 <fwp_hof0.constprop.0+0x2f4>
    551c:	f9400285 	ldr	x5, [x20]
    5520:	aa1403e0 	mov	x0, x20
    5524:	f949eec3 	ldr	x3, [x22, #5080]
    5528:	f949dac1 	ldr	x1, [x22, #5040]
    552c:	d370bc63 	lsl	x3, x3, #16
    5530:	cb010282 	sub	x2, x20, x1
    5534:	b7f81e85 	tbnz	x5, #63, 5904 <fwp_hof0.constprop.0+0xc40>
    5538:	eb03005f 	cmp	x2, x3
    553c:	54fffe62 	b.cs	5508 <fwp_hof0.constprop.0+0x844>  // b.hs, b.nlast
    5540:	d350fc40 	lsr	x0, x2, #16
    5544:	8b000800 	add	x0, x0, x0, lsl #2
    5548:	d37df000 	lsl	x0, x0, #3
    554c:	8b000083 	add	x3, x4, x0
    5550:	f9401061 	ldr	x1, [x3, #32]
    5554:	b4fffda1 	cbz	x1, 5508 <fwp_hof0.constprop.0+0x844>
    5558:	38606880 	ldrb	w0, [x4, x0]
    555c:	7100081f 	cmp	w0, #0x2
    5560:	54002240 	b.eq	59a8 <fwp_hof0.constprop.0+0xce4>  // b.none
    5564:	7100041f 	cmp	w0, #0x1
    5568:	54fffd01 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    556c:	92403c40 	and	x0, x2, #0xffff
    5570:	29430864 	ldp	w4, w2, [x3, #24]
    5574:	9b047c00 	mul	x0, x0, x4
    5578:	d360fc00 	lsr	x0, x0, #32
    557c:	eb02001f 	cmp	x0, x2
    5580:	54fffc42 	b.cs	5508 <fwp_hof0.constprop.0+0x844>  // b.hs, b.nlast
    5584:	8b000021 	add	x1, x1, x0
    5588:	39400020 	ldrb	w0, [x1]
    558c:	7100041f 	cmp	w0, #0x1
    5590:	54fffbc1 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    5594:	aa1403e0 	mov	x0, x20
    5598:	97fff622 	bl	2e20 <fwp_mem_free>
    559c:	b5fffb97 	cbnz	x23, 550c <fwp_hof0.constprop.0+0x848>
    55a0:	52800b63 	mov	w3, #0x5b                  	// #91
    55a4:	9100bffc 	add	x28, sp, #0x2f
    55a8:	9100c3f4 	add	x20, sp, #0x30
    55ac:	aa1c03e1 	mov	x1, x28
    55b0:	aa1403e0 	mov	x0, x20
    55b4:	d2800022 	mov	x2, #0x1                   	// #1
    55b8:	3900bfe3 	strb	w3, [sp, #47]
    55bc:	d280001b 	mov	x27, #0x0                   	// #0
    55c0:	a9037fff 	stp	xzr, xzr, [sp, #48]
    55c4:	d00000d6 	adrp	x22, 1f000 <__FRAME_END__+0x14c18>
    55c8:	f90023ff 	str	xzr, [sp, #64]
    55cc:	97fff259 	bl	1f30 <buf_put>
    55d0:	f94002a0 	ldr	x0, [x21]
    55d4:	f240f818 	ands	x24, x0, #0x7fffffffffffffff
    55d8:	540003c0 	b.eq	5650 <fwp_hof0.constprop.0+0x98c>  // b.none
    55dc:	912ca2d6 	add	x22, x22, #0xb28
    55e0:	90000037 	adrp	x23, 9000 <__modti3+0x260>
    55e4:	910142d6 	add	x22, x22, #0x50
    55e8:	910fe2f7 	add	x23, x23, #0x3f8
    55ec:	910022ba 	add	x26, x21, #0x8
    55f0:	1400000d 	b	5624 <fwp_hof0.constprop.0+0x960>
    55f4:	f87b7821 	ldr	x1, [x1, x27, lsl #3]
    55f8:	aa1603e2 	mov	x2, x22
    55fc:	aa1403e0 	mov	x0, x20
    5600:	9100077b 	add	x27, x27, #0x1
    5604:	97fff9c7 	bl	3d20 <fwp_write.constprop.0>
    5608:	eb1b031f 	cmp	x24, x27
    560c:	54000220 	b.eq	5650 <fwp_hof0.constprop.0+0x98c>  // b.none
    5610:	aa1403e0 	mov	x0, x20
    5614:	aa1703e1 	mov	x1, x23
    5618:	d2800042 	mov	x2, #0x2                   	// #2
    561c:	97fff245 	bl	1f30 <buf_put>
    5620:	f94002a0 	ldr	x0, [x21]
    5624:	aa1a03e1 	mov	x1, x26
    5628:	b6fffe60 	tbz	x0, #63, 55f4 <fwp_hof0.constprop.0+0x930>
    562c:	f9400aa1 	ldr	x1, [x21, #16]
    5630:	aa1603e2 	mov	x2, x22
    5634:	aa1403e0 	mov	x0, x20
    5638:	f87b7821 	ldr	x1, [x1, x27, lsl #3]
    563c:	9100077b 	add	x27, x27, #0x1
    5640:	97fff9b8 	bl	3d20 <fwp_write.constprop.0>
    5644:	eb1b031f 	cmp	x24, x27
    5648:	54fffe41 	b.ne	5610 <fwp_hof0.constprop.0+0x94c>  // b.any
    564c:	d503201f 	nop
    5650:	52800ba3 	mov	w3, #0x5d                  	// #93
    5654:	aa1403e0 	mov	x0, x20
    5658:	aa1c03e1 	mov	x1, x28
    565c:	d2800022 	mov	x2, #0x1                   	// #1
    5660:	3900bfe3 	strb	w3, [sp, #47]
    5664:	97fff233 	bl	1f30 <buf_put>
    5668:	a9435bf7 	ldp	x23, x22, [sp, #48]
    566c:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5670:	910ea000 	add	x0, x0, #0x3a8
    5674:	f10002ff 	cmp	x23, #0x0
    5678:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    567c:	b1002adf 	cmn	x22, #0xa
    5680:	54003e88 	b.hi	5e50 <fwp_hof0.constprop.0+0x118c>  // b.pmore
    5684:	910026c0 	add	x0, x22, #0x9
    5688:	52800021 	mov	w1, #0x1                   	// #1
    568c:	97fff756 	bl	33e4 <fwp_heap_alloc>
    5690:	aa0003f4 	mov	x20, x0
    5694:	aa1703e1 	mov	x1, x23
    5698:	aa0003f7 	mov	x23, x0
    569c:	aa1603e2 	mov	x2, x22
    56a0:	f80086f6 	str	x22, [x23], #8
    56a4:	8b160296 	add	x22, x20, x22
    56a8:	aa1703e0 	mov	x0, x23
    56ac:	97ffef15 	bl	1300 <memcpy@plt>
    56b0:	f9401be0 	ldr	x0, [sp, #48]
    56b4:	390022df 	strb	wzr, [x22, #8]
    56b8:	97ffefaa 	bl	1560 <free@plt>
    56bc:	91144262 	add	x2, x19, #0x510
    56c0:	f949ec43 	ldr	x3, [x2, #5080]
    56c4:	f949d841 	ldr	x1, [x2, #5040]
    56c8:	d370bc63 	lsl	x3, x3, #16
    56cc:	cb010284 	sub	x4, x20, x1
    56d0:	eb03009f 	cmp	x4, x3
    56d4:	540003a2 	b.cs	5748 <fwp_hof0.constprop.0+0xa84>  // b.hs, b.nlast
    56d8:	d350fc80 	lsr	x0, x4, #16
    56dc:	f949fc45 	ldr	x5, [x2, #5112]
    56e0:	8b000800 	add	x0, x0, x0, lsl #2
    56e4:	d37df002 	lsl	x2, x0, #3
    56e8:	8b0200a0 	add	x0, x5, x2
    56ec:	f9401016 	ldr	x22, [x0, #32]
    56f0:	b40002d6 	cbz	x22, 5748 <fwp_hof0.constprop.0+0xa84>
    56f4:	386268a2 	ldrb	w2, [x5, x2]
    56f8:	7100085f 	cmp	w2, #0x2
    56fc:	540027e0 	b.eq	5bf8 <fwp_hof0.constprop.0+0xf34>  // b.none
    5700:	7100045f 	cmp	w2, #0x1
    5704:	54000221 	b.ne	5748 <fwp_hof0.constprop.0+0xa84>  // b.any
    5708:	29430005 	ldp	w5, w0, [x0, #24]
    570c:	92403c82 	and	x2, x4, #0xffff
    5710:	9b057c42 	mul	x2, x2, x5
    5714:	d360fc42 	lsr	x2, x2, #32
    5718:	eb00005f 	cmp	x2, x0
    571c:	54000162 	b.cs	5748 <fwp_hof0.constprop.0+0xa84>  // b.hs, b.nlast
    5720:	8b0202d6 	add	x22, x22, x2
    5724:	394002c0 	ldrb	w0, [x22]
    5728:	7103fc1f 	cmp	w0, #0xff
    572c:	54002700 	b.eq	5c0c <fwp_hof0.constprop.0+0xf48>  // b.none
    5730:	91144260 	add	x0, x19, #0x510
    5734:	52800021 	mov	w1, #0x1                   	// #1
    5738:	390002c1 	strb	w1, [x22]
    573c:	f949ec03 	ldr	x3, [x0, #5080]
    5740:	f949d801 	ldr	x1, [x0, #5040]
    5744:	d370bc63 	lsl	x3, x3, #16
    5748:	cb0102a1 	sub	x1, x21, x1
    574c:	91144278 	add	x24, x19, #0x510
    5750:	eb03003f 	cmp	x1, x3
    5754:	540003a2 	b.cs	57c8 <fwp_hof0.constprop.0+0xb04>  // b.hs, b.nlast
    5758:	d350fc20 	lsr	x0, x1, #16
    575c:	f949ff03 	ldr	x3, [x24, #5112]
    5760:	8b000800 	add	x0, x0, x0, lsl #2
    5764:	d37df002 	lsl	x2, x0, #3
    5768:	8b020060 	add	x0, x3, x2
    576c:	f9401016 	ldr	x22, [x0, #32]
    5770:	b40002d6 	cbz	x22, 57c8 <fwp_hof0.constprop.0+0xb04>
    5774:	38626862 	ldrb	w2, [x3, x2]
    5778:	7100085f 	cmp	w2, #0x2
    577c:	54001c60 	b.eq	5b08 <fwp_hof0.constprop.0+0xe44>  // b.none
    5780:	7100045f 	cmp	w2, #0x1
    5784:	54000221 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5788:	29430002 	ldp	w2, w0, [x0, #24]
    578c:	92403c21 	and	x1, x1, #0xffff
    5790:	9b027c21 	mul	x1, x1, x2
    5794:	d360fc21 	lsr	x1, x1, #32
    5798:	eb00003f 	cmp	x1, x0
    579c:	54000162 	b.cs	57c8 <fwp_hof0.constprop.0+0xb04>  // b.hs, b.nlast
    57a0:	8b0102d6 	add	x22, x22, x1
    57a4:	394002c0 	ldrb	w0, [x22]
    57a8:	34000100 	cbz	w0, 57c8 <fwp_hof0.constprop.0+0xb04>
    57ac:	7100041f 	cmp	w0, #0x1
    57b0:	54001020 	b.eq	59b4 <fwp_hof0.constprop.0+0xcf0>  // b.none
    57b4:	7103fc1f 	cmp	w0, #0xff
    57b8:	54002600 	b.eq	5c78 <fwp_hof0.constprop.0+0xfb4>  // b.none
    57bc:	51000400 	sub	w0, w0, #0x1
    57c0:	390002c0 	strb	w0, [x22]
    57c4:	d503201f 	nop
    57c8:	f00000d5 	adrp	x21, 20000 <__data_start>
    57cc:	d2800021 	mov	x1, #0x1                   	// #1
    57d0:	f9400282 	ldr	x2, [x20]
    57d4:	aa1703e0 	mov	x0, x23
    57d8:	f9403aa3 	ldr	x3, [x21, #112]
    57dc:	97ffef71 	bl	15a0 <fwrite@plt>
    57e0:	f9403aa1 	ldr	x1, [x21, #112]
    57e4:	52800140 	mov	w0, #0xa                   	// #10
    57e8:	97ffeef6 	bl	13c0 <fputc@plt>
    57ec:	91144262 	add	x2, x19, #0x510
    57f0:	f949d841 	ldr	x1, [x2, #5040]
    57f4:	f949ec40 	ldr	x0, [x2, #5080]
    57f8:	cb010281 	sub	x1, x20, x1
    57fc:	eb00403f 	cmp	x1, x0, lsl #16
    5800:	54000382 	b.cs	5870 <fwp_hof0.constprop.0+0xbac>  // b.hs, b.nlast
    5804:	d350fc20 	lsr	x0, x1, #16
    5808:	f949fc43 	ldr	x3, [x2, #5112]
    580c:	8b000800 	add	x0, x0, x0, lsl #2
    5810:	d37df002 	lsl	x2, x0, #3
    5814:	8b020060 	add	x0, x3, x2
    5818:	f9401015 	ldr	x21, [x0, #32]
    581c:	b40002b5 	cbz	x21, 5870 <fwp_hof0.constprop.0+0xbac>
    5820:	38626862 	ldrb	w2, [x3, x2]
    5824:	7100085f 	cmp	w2, #0x2
    5828:	54001f80 	b.eq	5c18 <fwp_hof0.constprop.0+0xf54>  // b.none
    582c:	7100045f 	cmp	w2, #0x1
    5830:	54000201 	b.ne	5870 <fwp_hof0.constprop.0+0xbac>  // b.any
    5834:	29430002 	ldp	w2, w0, [x0, #24]
    5838:	92403c21 	and	x1, x1, #0xffff
    583c:	9b027c21 	mul	x1, x1, x2
    5840:	d360fc21 	lsr	x1, x1, #32
    5844:	eb00003f 	cmp	x1, x0
    5848:	54000142 	b.cs	5870 <fwp_hof0.constprop.0+0xbac>  // b.hs, b.nlast
    584c:	8b0102b5 	add	x21, x21, x1
    5850:	394002a0 	ldrb	w0, [x21]
    5854:	340000e0 	cbz	w0, 5870 <fwp_hof0.constprop.0+0xbac>
    5858:	7100041f 	cmp	w0, #0x1
    585c:	54001ea0 	b.eq	5c30 <fwp_hof0.constprop.0+0xf6c>  // b.none
    5860:	7103fc1f 	cmp	w0, #0xff
    5864:	540026e0 	b.eq	5d40 <fwp_hof0.constprop.0+0x107c>  // b.none
    5868:	51000400 	sub	w0, w0, #0x1
    586c:	390002a0 	strb	w0, [x21]
    5870:	f9400fe0 	ldr	x0, [sp, #24]
    5874:	f9400800 	ldr	x0, [x0, #16]
    5878:	f9000fe0 	str	x0, [sp, #24]
    587c:	b5ffa560 	cbnz	x0, 4d28 <fwp_hof0.constprop.0+0x64>
    5880:	a94853f3 	ldp	x19, x20, [sp, #128]
    5884:	a9495bf5 	ldp	x21, x22, [sp, #144]
    5888:	a94a63f7 	ldp	x23, x24, [sp, #160]
    588c:	a94b6bf9 	ldp	x25, x26, [sp, #176]
    5890:	a94c73fb 	ldp	x27, x28, [sp, #192]
    5894:	6d4d27e8 	ldp	d8, d9, [sp, #208]
    5898:	6d4e2fea 	ldp	d10, d11, [sp, #224]
    589c:	6d4f37ec 	ldp	d12, d13, [sp, #240]
    58a0:	6d503fee 	ldp	d14, d15, [sp, #256]
    58a4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    58a8:	f947f400 	ldr	x0, [x0, #4072]
    58ac:	f94037e2 	ldr	x2, [sp, #104]
    58b0:	f9400001 	ldr	x1, [x0]
    58b4:	eb010042 	subs	x2, x2, x1
    58b8:	d2800001 	mov	x1, #0x0                   	// #0
    58bc:	54002b61 	b.ne	5e28 <fwp_hof0.constprop.0+0x1164>  // b.any
    58c0:	a9477bfd 	ldp	x29, x30, [sp, #112]
    58c4:	d2800000 	mov	x0, #0x0                   	// #0
    58c8:	910443ff 	add	sp, sp, #0x110
    58cc:	d65f03c0 	ret
    58d0:	f9400a80 	ldr	x0, [x20, #16]
    58d4:	17fffde6 	b	506c <fwp_hof0.constprop.0+0x3a8>
    58d8:	f9400a82 	ldr	x2, [x20, #16]
    58dc:	17fffe27 	b	5178 <fwp_hof0.constprop.0+0x4b4>
    58e0:	f90003e0 	str	x0, [sp]
    58e4:	f9000be8 	str	x8, [sp, #16]
    58e8:	97fff4af 	bl	2ba4 <fwp_rc_forget_slot>
    58ec:	f94003e0 	ldr	x0, [sp]
    58f0:	f9400be8 	ldr	x8, [sp, #16]
    58f4:	17fffe44 	b	5204 <fwp_hof0.constprop.0+0x540>
    58f8:	72003c3f 	tst	w1, #0xffff
    58fc:	54ffe061 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    5900:	17fffef9 	b	54e4 <fwp_hof0.constprop.0+0x820>
    5904:	f9400694 	ldr	x20, [x20, #8]
    5908:	eb03005f 	cmp	x2, x3
    590c:	54000362 	b.cs	5978 <fwp_hof0.constprop.0+0xcb4>  // b.hs, b.nlast
    5910:	d350fc45 	lsr	x5, x2, #16
    5914:	8b0508a5 	add	x5, x5, x5, lsl #2
    5918:	d37df0a5 	lsl	x5, x5, #3
    591c:	8b050087 	add	x7, x4, x5
    5920:	f94010e6 	ldr	x6, [x7, #32]
    5924:	b40002a6 	cbz	x6, 5978 <fwp_hof0.constprop.0+0xcb4>
    5928:	38656884 	ldrb	w4, [x4, x5]
    592c:	7100089f 	cmp	w4, #0x2
    5930:	54000de0 	b.eq	5aec <fwp_hof0.constprop.0+0xe28>  // b.none
    5934:	7100049f 	cmp	w4, #0x1
    5938:	54000201 	b.ne	5978 <fwp_hof0.constprop.0+0xcb4>  // b.any
    593c:	294310e5 	ldp	w5, w4, [x7, #24]
    5940:	92403c42 	and	x2, x2, #0xffff
    5944:	9b057c42 	mul	x2, x2, x5
    5948:	d360fc42 	lsr	x2, x2, #32
    594c:	eb04005f 	cmp	x2, x4
    5950:	54000142 	b.cs	5978 <fwp_hof0.constprop.0+0xcb4>  // b.hs, b.nlast
    5954:	8b0200c6 	add	x6, x6, x2
    5958:	394000c2 	ldrb	w2, [x6]
    595c:	7100045f 	cmp	w2, #0x1
    5960:	540000c1 	b.ne	5978 <fwp_hof0.constprop.0+0xcb4>  // b.any
    5964:	97fff52f 	bl	2e20 <fwp_mem_free>
    5968:	91144260 	add	x0, x19, #0x510
    596c:	f949ec03 	ldr	x3, [x0, #5080]
    5970:	f949d801 	ldr	x1, [x0, #5040]
    5974:	d370bc63 	lsl	x3, x3, #16
    5978:	cb010281 	sub	x1, x20, x1
    597c:	eb01007f 	cmp	x3, x1
    5980:	54ffd8c8 	b.hi	5498 <fwp_hof0.constprop.0+0x7d4>  // b.pmore
    5984:	17fffee1 	b	5508 <fwp_hof0.constprop.0+0x844>
    5988:	72003c3f 	tst	w1, #0xffff
    598c:	54ffb601 	b.ne	504c <fwp_hof0.constprop.0+0x388>  // b.any
    5990:	39400300 	ldrb	w0, [x24]
    5994:	7103fc1f 	cmp	w0, #0xff
    5998:	54ffb561 	b.ne	5044 <fwp_hof0.constprop.0+0x380>  // b.any
    599c:	aa1803e0 	mov	x0, x24
    59a0:	97fff481 	bl	2ba4 <fwp_rc_forget_slot>
    59a4:	17fffda8 	b	5044 <fwp_hof0.constprop.0+0x380>
    59a8:	72003c5f 	tst	w2, #0xffff
    59ac:	54ffdae1 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    59b0:	17fffef6 	b	5588 <fwp_hof0.constprop.0+0x8c4>
    59b4:	f94002a0 	ldr	x0, [x21]
    59b8:	b7f80ae0 	tbnz	x0, #63, 5b14 <fwp_hof0.constprop.0+0xe50>
    59bc:	91144261 	add	x1, x19, #0x510
    59c0:	f949d820 	ldr	x0, [x1, #5040]
    59c4:	f949ec21 	ldr	x1, [x1, #5080]
    59c8:	cb0002a0 	sub	x0, x21, x0
    59cc:	eb01401f 	cmp	x0, x1, lsl #16
    59d0:	54ffefc2 	b.cs	57c8 <fwp_hof0.constprop.0+0xb04>  // b.hs, b.nlast
    59d4:	d350fc01 	lsr	x1, x0, #16
    59d8:	8b010821 	add	x1, x1, x1, lsl #2
    59dc:	d37df021 	lsl	x1, x1, #3
    59e0:	8b010064 	add	x4, x3, x1
    59e4:	f9401082 	ldr	x2, [x4, #32]
    59e8:	b4ffef02 	cbz	x2, 57c8 <fwp_hof0.constprop.0+0xb04>
    59ec:	38616861 	ldrb	w1, [x3, x1]
    59f0:	7100083f 	cmp	w1, #0x2
    59f4:	54001240 	b.eq	5c3c <fwp_hof0.constprop.0+0xf78>  // b.none
    59f8:	7100043f 	cmp	w1, #0x1
    59fc:	54ffee61 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5a00:	29430483 	ldp	w3, w1, [x4, #24]
    5a04:	92403c00 	and	x0, x0, #0xffff
    5a08:	9b037c00 	mul	x0, x0, x3
    5a0c:	d360fc00 	lsr	x0, x0, #32
    5a10:	eb01001f 	cmp	x0, x1
    5a14:	54ffeda2 	b.cs	57c8 <fwp_hof0.constprop.0+0xb04>  // b.hs, b.nlast
    5a18:	8b000042 	add	x2, x2, x0
    5a1c:	39400040 	ldrb	w0, [x2]
    5a20:	7100041f 	cmp	w0, #0x1
    5a24:	54ffed21 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5a28:	aa1503e0 	mov	x0, x21
    5a2c:	97fff4fd 	bl	2e20 <fwp_mem_free>
    5a30:	17ffff66 	b	57c8 <fwp_hof0.constprop.0+0xb04>
    5a34:	ca404401 	eor	x1, x0, x0, lsr #17
    5a38:	91144263 	add	x3, x19, #0x510
    5a3c:	ca412421 	eor	x1, x1, x1, lsr #9
    5a40:	8b210c61 	add	x1, x3, w1, uxtb #3
    5a44:	f94a2421 	ldr	x1, [x1, #5192]
    5a48:	b5000081 	cbnz	x1, 5a58 <fwp_hof0.constprop.0+0xd94>
    5a4c:	140000d9 	b	5db0 <fwp_hof0.constprop.0+0x10ec>
    5a50:	f9400821 	ldr	x1, [x1, #16]
    5a54:	b4001ae1 	cbz	x1, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5a58:	f9400023 	ldr	x3, [x1]
    5a5c:	eb00007f 	cmp	x3, x0
    5a60:	54ffff81 	b.ne	5a50 <fwp_hof0.constprop.0+0xd8c>  // b.any
    5a64:	f9400423 	ldr	x3, [x1, #8]
    5a68:	d1000463 	sub	x3, x3, #0x1
    5a6c:	f9000423 	str	x3, [x1, #8]
    5a70:	f103f87f 	cmp	x3, #0xfe
    5a74:	54000ea0 	b.eq	5c48 <fwp_hof0.constprop.0+0xf84>  // b.none
    5a78:	fd400722 	ldr	d2, [x25, #8]
    5a7c:	fd400b24 	ldr	d4, [x25, #16]
    5a80:	17fffe14 	b	52d0 <fwp_hof0.constprop.0+0x60c>
    5a84:	ca414420 	eor	x0, x1, x1, lsr #17
    5a88:	91144262 	add	x2, x19, #0x510
    5a8c:	ca402400 	eor	x0, x0, x0, lsr #9
    5a90:	8b200c40 	add	x0, x2, w0, uxtb #3
    5a94:	f94a2400 	ldr	x0, [x0, #5192]
    5a98:	b5000080 	cbnz	x0, 5aa8 <fwp_hof0.constprop.0+0xde4>
    5a9c:	140000c5 	b	5db0 <fwp_hof0.constprop.0+0x10ec>
    5aa0:	f9400800 	ldr	x0, [x0, #16]
    5aa4:	b4001860 	cbz	x0, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5aa8:	f9400002 	ldr	x2, [x0]
    5aac:	eb01005f 	cmp	x2, x1
    5ab0:	54ffff81 	b.ne	5aa0 <fwp_hof0.constprop.0+0xddc>  // b.any
    5ab4:	f9400402 	ldr	x2, [x0, #8]
    5ab8:	d1000442 	sub	x2, x2, #0x1
    5abc:	f9000402 	str	x2, [x0, #8]
    5ac0:	f103f85f 	cmp	x2, #0xfe
    5ac4:	54ffc4a1 	b.ne	5358 <fwp_hof0.constprop.0+0x694>  // b.any
    5ac8:	aa0103e0 	mov	x0, x1
    5acc:	f90003e1 	str	x1, [sp]
    5ad0:	fd000be4 	str	d4, [sp, #16]
    5ad4:	97fff434 	bl	2ba4 <fwp_rc_forget_slot>
    5ad8:	f94003e1 	ldr	x1, [sp]
    5adc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ae0:	fd400be4 	ldr	d4, [sp, #16]
    5ae4:	39000020 	strb	w0, [x1]
    5ae8:	17fffe1c 	b	5358 <fwp_hof0.constprop.0+0x694>
    5aec:	72003c5f 	tst	w2, #0xffff
    5af0:	54fff441 	b.ne	5978 <fwp_hof0.constprop.0+0xcb4>  // b.any
    5af4:	17ffff99 	b	5958 <fwp_hof0.constprop.0+0xc94>
    5af8:	72003c7f 	tst	w3, #0xffff
    5afc:	54ffa480 	b.eq	4f8c <fwp_hof0.constprop.0+0x2c8>  // b.none
    5b00:	aa1503e0 	mov	x0, x21
    5b04:	17fffd26 	b	4f9c <fwp_hof0.constprop.0+0x2d8>
    5b08:	72003c3f 	tst	w1, #0xffff
    5b0c:	54ffe5e1 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5b10:	17ffff25 	b	57a4 <fwp_hof0.constprop.0+0xae0>
    5b14:	f94006b6 	ldr	x22, [x21, #8]
    5b18:	aa1503e0 	mov	x0, x21
    5b1c:	97fff611 	bl	3360 <fwp_rc_free_arr>
    5b20:	91144260 	add	x0, x19, #0x510
    5b24:	f949d801 	ldr	x1, [x0, #5040]
    5b28:	f949ec00 	ldr	x0, [x0, #5080]
    5b2c:	cb0102c1 	sub	x1, x22, x1
    5b30:	eb00403f 	cmp	x1, x0, lsl #16
    5b34:	54ffe4a2 	b.cs	57c8 <fwp_hof0.constprop.0+0xb04>  // b.hs, b.nlast
    5b38:	aa1603f5 	mov	x21, x22
    5b3c:	17ffff07 	b	5758 <fwp_hof0.constprop.0+0xa94>
    5b40:	72003c1f 	tst	w0, #0xffff
    5b44:	54ff9260 	b.eq	4d90 <fwp_hof0.constprop.0+0xcc>  // b.none
    5b48:	f94007e0 	ldr	x0, [sp, #8]
    5b4c:	b5ff9320 	cbnz	x0, 4db0 <fwp_hof0.constprop.0+0xec>
    5b50:	d2800000 	mov	x0, #0x0                   	// #0
    5b54:	97fff6b3 	bl	3620 <fwp_array_new_packed.constprop.0>
    5b58:	91144261 	add	x1, x19, #0x510
    5b5c:	aa0003f4 	mov	x20, x0
    5b60:	aa0103e0 	mov	x0, x1
    5b64:	f949d821 	ldr	x1, [x1, #5040]
    5b68:	f949ec00 	ldr	x0, [x0, #5080]
    5b6c:	cb010281 	sub	x1, x20, x1
    5b70:	eb00403f 	cmp	x1, x0, lsl #16
    5b74:	54ff9403 	b.cc	4df4 <fwp_hof0.constprop.0+0x130>  // b.lo, b.ul, b.last
    5b78:	d2800000 	mov	x0, #0x0                   	// #0
    5b7c:	17fffd0b 	b	4fa8 <fwp_hof0.constprop.0+0x2e4>
    5b80:	72003c3f 	tst	w1, #0xffff
    5b84:	54ff96a1 	b.ne	4e58 <fwp_hof0.constprop.0+0x194>  // b.any
    5b88:	394002a0 	ldrb	w0, [x21]
    5b8c:	7103fc1f 	cmp	w0, #0xff
    5b90:	54ff9601 	b.ne	4e50 <fwp_hof0.constprop.0+0x18c>  // b.any
    5b94:	aa1503e0 	mov	x0, x21
    5b98:	97fff403 	bl	2ba4 <fwp_rc_forget_slot>
    5b9c:	17fffcad 	b	4e50 <fwp_hof0.constprop.0+0x18c>
    5ba0:	ca584700 	eor	x0, x24, x24, lsr #17
    5ba4:	91144261 	add	x1, x19, #0x510
    5ba8:	ca402400 	eor	x0, x0, x0, lsr #9
    5bac:	8b200c20 	add	x0, x1, w0, uxtb #3
    5bb0:	f94a2400 	ldr	x0, [x0, #5192]
    5bb4:	b5000080 	cbnz	x0, 5bc4 <fwp_hof0.constprop.0+0xf00>
    5bb8:	1400007e 	b	5db0 <fwp_hof0.constprop.0+0x10ec>
    5bbc:	f9400800 	ldr	x0, [x0, #16]
    5bc0:	b4000f80 	cbz	x0, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5bc4:	f9400001 	ldr	x1, [x0]
    5bc8:	eb01031f 	cmp	x24, x1
    5bcc:	54ffff81 	b.ne	5bbc <fwp_hof0.constprop.0+0xef8>  // b.any
    5bd0:	f9400401 	ldr	x1, [x0, #8]
    5bd4:	d1000421 	sub	x1, x1, #0x1
    5bd8:	f9000401 	str	x1, [x0, #8]
    5bdc:	f103f83f 	cmp	x1, #0xfe
    5be0:	54ffc941 	b.ne	5508 <fwp_hof0.constprop.0+0x844>  // b.any
    5be4:	aa1803e0 	mov	x0, x24
    5be8:	97fff3ef 	bl	2ba4 <fwp_rc_forget_slot>
    5bec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bf0:	39000300 	strb	w0, [x24]
    5bf4:	17fffe45 	b	5508 <fwp_hof0.constprop.0+0x844>
    5bf8:	72003c9f 	tst	w4, #0xffff
    5bfc:	54ffda61 	b.ne	5748 <fwp_hof0.constprop.0+0xa84>  // b.any
    5c00:	394002c0 	ldrb	w0, [x22]
    5c04:	7103fc1f 	cmp	w0, #0xff
    5c08:	54ffd941 	b.ne	5730 <fwp_hof0.constprop.0+0xa6c>  // b.any
    5c0c:	aa1603e0 	mov	x0, x22
    5c10:	97fff3e5 	bl	2ba4 <fwp_rc_forget_slot>
    5c14:	17fffec7 	b	5730 <fwp_hof0.constprop.0+0xa6c>
    5c18:	72003c3f 	tst	w1, #0xffff
    5c1c:	54ffe2a1 	b.ne	5870 <fwp_hof0.constprop.0+0xbac>  // b.any
    5c20:	394002a0 	ldrb	w0, [x21]
    5c24:	34ffe260 	cbz	w0, 5870 <fwp_hof0.constprop.0+0xbac>
    5c28:	7100041f 	cmp	w0, #0x1
    5c2c:	54ffe1a1 	b.ne	5860 <fwp_hof0.constprop.0+0xb9c>  // b.any
    5c30:	aa1403e0 	mov	x0, x20
    5c34:	97fff47b 	bl	2e20 <fwp_mem_free>
    5c38:	17ffff0e 	b	5870 <fwp_hof0.constprop.0+0xbac>
    5c3c:	72003c1f 	tst	w0, #0xffff
    5c40:	54ffdc41 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5c44:	17ffff76 	b	5a1c <fwp_hof0.constprop.0+0xd58>
    5c48:	f90003e0 	str	x0, [sp]
    5c4c:	97fff3d6 	bl	2ba4 <fwp_rc_forget_slot>
    5c50:	f94003e0 	ldr	x0, [sp]
    5c54:	91144261 	add	x1, x19, #0x510
    5c58:	12800022 	mov	w2, #0xfffffffe            	// #-2
    5c5c:	39000002 	strb	w2, [x0]
    5c60:	f949ec26 	ldr	x6, [x1, #5080]
    5c64:	fd400722 	ldr	d2, [x25, #8]
    5c68:	fd400b24 	ldr	d4, [x25, #16]
    5c6c:	d370bcc6 	lsl	x6, x6, #16
    5c70:	f949d822 	ldr	x2, [x1, #5040]
    5c74:	17fffd97 	b	52d0 <fwp_hof0.constprop.0+0x60c>
    5c78:	ca5646c0 	eor	x0, x22, x22, lsr #17
    5c7c:	91144261 	add	x1, x19, #0x510
    5c80:	ca402400 	eor	x0, x0, x0, lsr #9
    5c84:	8b200c20 	add	x0, x1, w0, uxtb #3
    5c88:	f94a2400 	ldr	x0, [x0, #5192]
    5c8c:	b4000920 	cbz	x0, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5c90:	f9400001 	ldr	x1, [x0]
    5c94:	eb16003f 	cmp	x1, x22
    5c98:	540000c0 	b.eq	5cb0 <fwp_hof0.constprop.0+0xfec>  // b.none
    5c9c:	f9400800 	ldr	x0, [x0, #16]
    5ca0:	b4000880 	cbz	x0, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5ca4:	f9400001 	ldr	x1, [x0]
    5ca8:	eb16003f 	cmp	x1, x22
    5cac:	54ffff81 	b.ne	5c9c <fwp_hof0.constprop.0+0xfd8>  // b.any
    5cb0:	f9400401 	ldr	x1, [x0, #8]
    5cb4:	d1000421 	sub	x1, x1, #0x1
    5cb8:	f9000401 	str	x1, [x0, #8]
    5cbc:	f103f83f 	cmp	x1, #0xfe
    5cc0:	54ffd841 	b.ne	57c8 <fwp_hof0.constprop.0+0xb04>  // b.any
    5cc4:	aa1603e0 	mov	x0, x22
    5cc8:	97fff3b7 	bl	2ba4 <fwp_rc_forget_slot>
    5ccc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5cd0:	390002c0 	strb	w0, [x22]
    5cd4:	17fffebd 	b	57c8 <fwp_hof0.constprop.0+0xb04>
    5cd8:	ca544681 	eor	x1, x20, x20, lsr #17
    5cdc:	91144262 	add	x2, x19, #0x510
    5ce0:	ca412421 	eor	x1, x1, x1, lsr #9
    5ce4:	92401c21 	and	x1, x1, #0xff
    5ce8:	910a2423 	add	x3, x1, #0x289
    5cec:	8b010c41 	add	x1, x2, x1, lsl #3
    5cf0:	8b030c55 	add	x21, x2, x3, lsl #3
    5cf4:	f94a2421 	ldr	x1, [x1, #5192]
    5cf8:	b50000a1 	cbnz	x1, 5d0c <fwp_hof0.constprop.0+0x1048>
    5cfc:	14000048 	b	5e1c <fwp_hof0.constprop.0+0x1158>
    5d00:	91004035 	add	x21, x1, #0x10
    5d04:	f9400821 	ldr	x1, [x1, #16]
    5d08:	b40004e1 	cbz	x1, 5da4 <fwp_hof0.constprop.0+0x10e0>
    5d0c:	f9400022 	ldr	x2, [x1]
    5d10:	eb14005f 	cmp	x2, x20
    5d14:	54ffff61 	b.ne	5d00 <fwp_hof0.constprop.0+0x103c>  // b.any
    5d18:	f94002a1 	ldr	x1, [x21]
    5d1c:	7103f81f 	cmp	w0, #0xfe
    5d20:	540006a0 	b.eq	5df4 <fwp_hof0.constprop.0+0x1130>  // b.none
    5d24:	b4000461 	cbz	x1, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5d28:	f9400420 	ldr	x0, [x1, #8]
    5d2c:	b100041f 	cmn	x0, #0x1
    5d30:	54000700 	b.eq	5e10 <fwp_hof0.constprop.0+0x114c>  // b.none
    5d34:	91000400 	add	x0, x0, #0x1
    5d38:	f9000420 	str	x0, [x1, #8]
    5d3c:	17fffc1b 	b	4da8 <fwp_hof0.constprop.0+0xe4>
    5d40:	ca5546a0 	eor	x0, x21, x21, lsr #17
    5d44:	91144261 	add	x1, x19, #0x510
    5d48:	ca402400 	eor	x0, x0, x0, lsr #9
    5d4c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5d50:	f94a2400 	ldr	x0, [x0, #5192]
    5d54:	b5000080 	cbnz	x0, 5d64 <fwp_hof0.constprop.0+0x10a0>
    5d58:	14000016 	b	5db0 <fwp_hof0.constprop.0+0x10ec>
    5d5c:	f9400800 	ldr	x0, [x0, #16]
    5d60:	b4000280 	cbz	x0, 5db0 <fwp_hof0.constprop.0+0x10ec>
    5d64:	f9400001 	ldr	x1, [x0]
    5d68:	eb15003f 	cmp	x1, x21
    5d6c:	54ffff81 	b.ne	5d5c <fwp_hof0.constprop.0+0x1098>  // b.any
    5d70:	f9400401 	ldr	x1, [x0, #8]
    5d74:	d1000421 	sub	x1, x1, #0x1
    5d78:	f9000401 	str	x1, [x0, #8]
    5d7c:	f103f83f 	cmp	x1, #0xfe
    5d80:	54ffd781 	b.ne	5870 <fwp_hof0.constprop.0+0xbac>  // b.any
    5d84:	aa1503e0 	mov	x0, x21
    5d88:	97fff387 	bl	2ba4 <fwp_rc_forget_slot>
    5d8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d90:	390002a0 	strb	w0, [x21]
    5d94:	17fffeb7 	b	5870 <fwp_hof0.constprop.0+0xbac>
    5d98:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5d9c:	91122000 	add	x0, x0, #0x488
    5da0:	97fff0c0 	bl	20a0 <fwp_trap>
    5da4:	7103f81f 	cmp	w0, #0xfe
    5da8:	540000a0 	b.eq	5dbc <fwp_hof0.constprop.0+0x10f8>  // b.none
    5dac:	d503201f 	nop
    5db0:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5db4:	910c2000 	add	x0, x0, #0x308
    5db8:	97fff0ba 	bl	20a0 <fwp_trap>
    5dbc:	d2800300 	mov	x0, #0x18                  	// #24
    5dc0:	97ffeda0 	bl	1440 <malloc@plt>
    5dc4:	b4000300 	cbz	x0, 5e24 <fwp_hof0.constprop.0+0x1160>
    5dc8:	d2801fe1 	mov	x1, #0xff                  	// #255
    5dcc:	a9000414 	stp	x20, x1, [x0]
    5dd0:	91144261 	add	x1, x19, #0x510
    5dd4:	f900081f 	str	xzr, [x0, #16]
    5dd8:	12800002 	mov	w2, #0xffffffff            	// #-1
    5ddc:	f90002a0 	str	x0, [x21]
    5de0:	39000282 	strb	w2, [x20]
    5de4:	f94e2420 	ldr	x0, [x1, #7240]
    5de8:	91000400 	add	x0, x0, #0x1
    5dec:	f90e2420 	str	x0, [x1, #7240]
    5df0:	17fffbee 	b	4da8 <fwp_hof0.constprop.0+0xe4>
    5df4:	b4fffe41 	cbz	x1, 5dbc <fwp_hof0.constprop.0+0x10f8>
    5df8:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5dfc:	91110000 	add	x0, x0, #0x440
    5e00:	97fff0a8 	bl	20a0 <fwp_trap>
    5e04:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5e08:	910cc000 	add	x0, x0, #0x330
    5e0c:	97fff0a5 	bl	20a0 <fwp_trap>
    5e10:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5e14:	9111a000 	add	x0, x0, #0x468
    5e18:	97fff0a2 	bl	20a0 <fwp_trap>
    5e1c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    5e20:	17ffffbf 	b	5d1c <fwp_hof0.constprop.0+0x1058>
    5e24:	97ffef5b 	bl	1b90 <fwp_heap_oom>
    5e28:	a90853f3 	stp	x19, x20, [sp, #128]
    5e2c:	a9095bf5 	stp	x21, x22, [sp, #144]
    5e30:	a90a63f7 	stp	x23, x24, [sp, #160]
    5e34:	a90b6bf9 	stp	x25, x26, [sp, #176]
    5e38:	a90c73fb 	stp	x27, x28, [sp, #192]
    5e3c:	6d0d27e8 	stp	d8, d9, [sp, #208]
    5e40:	6d0e2fea 	stp	d10, d11, [sp, #224]
    5e44:	6d0f37ec 	stp	d12, d13, [sp, #240]
    5e48:	6d103fee 	stp	d14, d15, [sp, #256]
    5e4c:	97ffed95 	bl	14a0 <__stack_chk_fail@plt>
    5e50:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5e54:	9112c000 	add	x0, x0, #0x4b0
    5e58:	97fff092 	bl	20a0 <fwp_trap>
    5e5c:	97ffee09 	bl	1680 <fwp_trap_overflow.constprop.0>

0000000000005e60 <f0>:
    5e60:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5e64:	910003fd 	mov	x29, sp
    5e68:	a90153f3 	stp	x19, x20, [sp, #16]
    5e6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5e70:	a90363f7 	stp	x23, x24, [sp, #48]
    5e74:	a9046bf9 	stp	x25, x26, [sp, #64]
    5e78:	a90573fb 	stp	x27, x28, [sp, #80]
    5e7c:	d12183ff 	sub	sp, sp, #0x860
    5e80:	f90203ff 	str	xzr, [sp, #1024]
    5e84:	f00000c0 	adrp	x0, 20000 <__data_start>
    5e88:	9101c005 	add	x5, x0, #0x70
    5e8c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    5e90:	f947f400 	ldr	x0, [x0, #4072]
    5e94:	90000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    5e98:	f94130a6 	ldr	x6, [x5, #608]
    5e9c:	f9400001 	ldr	x1, [x0]
    5ea0:	f9042fe1 	str	x1, [sp, #2136]
    5ea4:	d2800001 	mov	x1, #0x0                   	// #0
    5ea8:	91144298 	add	x24, x20, #0x510
    5eac:	912123f6 	add	x22, sp, #0x848
    5eb0:	910023e0 	add	x0, sp, #0x8
    5eb4:	910083e2 	add	x2, sp, #0x20
    5eb8:	d0ffffe1 	adrp	x1, 3000 <fwp_mem_free+0x1e0>
    5ebc:	90ffffe4 	adrp	x4, 1000 <__abi_tag+0xd88>
    5ec0:	911f0021 	add	x1, x1, #0x7c0
    5ec4:	912c4084 	add	x4, x4, #0xb10
    5ec8:	d2800013 	mov	x19, #0x0                   	// #0
    5ecc:	d2800119 	mov	x25, #0x8                   	// #8
    5ed0:	d2800015 	mov	x21, #0x0                   	// #0
    5ed4:	52800037 	mov	w23, #0x1                   	// #1
    5ed8:	a90093e6 	stp	x6, x4, [sp, #8]
    5edc:	a901ffe2 	stp	x2, xzr, [sp, #24]
    5ee0:	a90307ff 	stp	xzr, x1, [sp, #48]
    5ee4:	f90130a0 	str	x0, [x5, #608]
    5ee8:	f100073a 	subs	x26, x25, #0x1
    5eec:	aa1603e1 	mov	x1, x22
    5ef0:	da1f02bc 	sbc	x28, x21, xzr
    5ef4:	52800020 	mov	w0, #0x1                   	// #1
    5ef8:	f90017fa 	str	x26, [sp, #40]
    5efc:	aa1a03f9 	mov	x25, x26
    5f00:	f90427fa 	str	x26, [sp, #2120]
    5f04:	aa1c03f5 	mov	x21, x28
    5f08:	f9042bf3 	str	x19, [sp, #2128]
    5f0c:	97fff57d 	bl	3500 <fwp_data.part.0.constprop.0>
    5f10:	f949db02 	ldr	x2, [x24, #5040]
    5f14:	aa0003f3 	mov	x19, x0
    5f18:	f949ef00 	ldr	x0, [x24, #5080]
    5f1c:	cb020262 	sub	x2, x19, x2
    5f20:	eb00405f 	cmp	x2, x0, lsl #16
    5f24:	54000302 	b.cs	5f84 <f0+0x124>  // b.hs, b.nlast
    5f28:	d350fc40 	lsr	x0, x2, #16
    5f2c:	f949ff04 	ldr	x4, [x24, #5112]
    5f30:	8b000800 	add	x0, x0, x0, lsl #2
    5f34:	d37df001 	lsl	x1, x0, #3
    5f38:	8b010080 	add	x0, x4, x1
    5f3c:	f940101b 	ldr	x27, [x0, #32]
    5f40:	b400023b 	cbz	x27, 5f84 <f0+0x124>
    5f44:	38616881 	ldrb	w1, [x4, x1]
    5f48:	7100083f 	cmp	w1, #0x2
    5f4c:	54010ea0 	b.eq	8120 <f0+0x22c0>  // b.none
    5f50:	7100043f 	cmp	w1, #0x1
    5f54:	54000181 	b.ne	5f84 <f0+0x124>  // b.any
    5f58:	29430001 	ldp	w1, w0, [x0, #24]
    5f5c:	92403c42 	and	x2, x2, #0xffff
    5f60:	9b017c42 	mul	x2, x2, x1
    5f64:	d360fc42 	lsr	x2, x2, #32
    5f68:	eb00005f 	cmp	x2, x0
    5f6c:	540000c2 	b.cs	5f84 <f0+0x124>  // b.hs, b.nlast
    5f70:	8b02037b 	add	x27, x27, x2
    5f74:	39400360 	ldrb	w0, [x27]
    5f78:	7103fc1f 	cmp	w0, #0xff
    5f7c:	54010cc0 	b.eq	8114 <f0+0x22b4>  // b.none
    5f80:	39000377 	strb	w23, [x27]
    5f84:	f90013f3 	str	x19, [sp, #32]
    5f88:	aa1c035a 	orr	x26, x26, x28
    5f8c:	b5fffafa 	cbnz	x26, 5ee8 <f0+0x88>
    5f90:	90000020 	adrp	x0, 9000 <__modti3+0x260>
    5f94:	910103e1 	add	x1, sp, #0x40
    5f98:	f94007e2 	ldr	x2, [sp, #8]
    5f9c:	3dc19c00 	ldr	q0, [x0, #1648]
    5fa0:	f00000c0 	adrp	x0, 20000 <__data_start>
    5fa4:	9101c018 	add	x24, x0, #0x70
    5fa8:	52800020 	mov	w0, #0x1                   	// #1
    5fac:	3d8013e0 	str	q0, [sp, #64]
    5fb0:	f9013302 	str	x2, [x24, #608]
    5fb4:	97fff553 	bl	3500 <fwp_data.part.0.constprop.0>
    5fb8:	97fff4ba 	bl	32a0 <fwp_rc_fresh>
    5fbc:	aa0003e2 	mov	x2, x0
    5fc0:	910163e1 	add	x1, sp, #0x58
    5fc4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5fc8:	52800020 	mov	w0, #0x1                   	// #1
    5fcc:	a9058be3 	stp	x3, x2, [sp, #88]
    5fd0:	97fff54c 	bl	3500 <fwp_data.part.0.constprop.0>
    5fd4:	97fff4b3 	bl	32a0 <fwp_rc_fresh>
    5fd8:	aa0003e2 	mov	x2, x0
    5fdc:	90000023 	adrp	x3, 9000 <__modti3+0x260>
    5fe0:	9101a3e1 	add	x1, sp, #0x68
    5fe4:	52800020 	mov	w0, #0x1                   	// #1
    5fe8:	f9003be2 	str	x2, [sp, #112]
    5fec:	3dc19c60 	ldr	q0, [x3, #1648]
    5ff0:	fd0037e0 	str	d0, [sp, #104]
    5ff4:	97fff543 	bl	3500 <fwp_data.part.0.constprop.0>
    5ff8:	91144283 	add	x3, x20, #0x510
    5ffc:	aa0003f7 	mov	x23, x0
    6000:	f949d861 	ldr	x1, [x3, #5040]
    6004:	f949ec60 	ldr	x0, [x3, #5080]
    6008:	cb0102e1 	sub	x1, x23, x1
    600c:	eb00403f 	cmp	x1, x0, lsl #16
    6010:	54000322 	b.cs	6074 <f0+0x214>  // b.hs, b.nlast
    6014:	d350fc22 	lsr	x2, x1, #16
    6018:	f949fc63 	ldr	x3, [x3, #5112]
    601c:	8b020842 	add	x2, x2, x2, lsl #2
    6020:	d37df042 	lsl	x2, x2, #3
    6024:	8b020060 	add	x0, x3, x2
    6028:	f9401015 	ldr	x21, [x0, #32]
    602c:	b4000255 	cbz	x21, 6074 <f0+0x214>
    6030:	38626862 	ldrb	w2, [x3, x2]
    6034:	7100085f 	cmp	w2, #0x2
    6038:	54010b60 	b.eq	81a4 <f0+0x2344>  // b.none
    603c:	7100045f 	cmp	w2, #0x1
    6040:	540001a1 	b.ne	6074 <f0+0x214>  // b.any
    6044:	29430002 	ldp	w2, w0, [x0, #24]
    6048:	92403c21 	and	x1, x1, #0xffff
    604c:	9b027c21 	mul	x1, x1, x2
    6050:	d360fc21 	lsr	x1, x1, #32
    6054:	eb00003f 	cmp	x1, x0
    6058:	540000e2 	b.cs	6074 <f0+0x214>  // b.hs, b.nlast
    605c:	8b0102b5 	add	x21, x21, x1
    6060:	394002a0 	ldrb	w0, [x21]
    6064:	7103fc1f 	cmp	w0, #0xff
    6068:	54011520 	b.eq	830c <f0+0x24ac>  // b.none
    606c:	52800020 	mov	w0, #0x1                   	// #1
    6070:	390002a0 	strb	w0, [x21]
    6074:	9101e3e1 	add	x1, sp, #0x78
    6078:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    607c:	52800020 	mov	w0, #0x1                   	// #1
    6080:	a907dff5 	stp	x21, x23, [sp, #120]
    6084:	97fff51f 	bl	3500 <fwp_data.part.0.constprop.0>
    6088:	97fff486 	bl	32a0 <fwp_rc_fresh>
    608c:	aa0003e2 	mov	x2, x0
    6090:	910223e1 	add	x1, sp, #0x88
    6094:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6098:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    609c:	52800020 	mov	w0, #0x1                   	// #1
    60a0:	a9088bf7 	stp	x23, x2, [sp, #136]
    60a4:	97fff517 	bl	3500 <fwp_data.part.0.constprop.0>
    60a8:	97fff47e 	bl	32a0 <fwp_rc_fresh>
    60ac:	aa0003e2 	mov	x2, x0
    60b0:	910263e1 	add	x1, sp, #0x98
    60b4:	52800020 	mov	w0, #0x1                   	// #1
    60b8:	a9098bf5 	stp	x21, x2, [sp, #152]
    60bc:	97fff511 	bl	3500 <fwp_data.part.0.constprop.0>
    60c0:	97fff478 	bl	32a0 <fwp_rc_fresh>
    60c4:	aa0003e2 	mov	x2, x0
    60c8:	9102a3e1 	add	x1, sp, #0xa8
    60cc:	52800020 	mov	w0, #0x1                   	// #1
    60d0:	a90a8bf7 	stp	x23, x2, [sp, #168]
    60d4:	97fff50b 	bl	3500 <fwp_data.part.0.constprop.0>
    60d8:	97fff472 	bl	32a0 <fwp_rc_fresh>
    60dc:	aa0003e2 	mov	x2, x0
    60e0:	9102e3e1 	add	x1, sp, #0xb8
    60e4:	52800020 	mov	w0, #0x1                   	// #1
    60e8:	a90b8bf5 	stp	x21, x2, [sp, #184]
    60ec:	97fff505 	bl	3500 <fwp_data.part.0.constprop.0>
    60f0:	97fff46c 	bl	32a0 <fwp_rc_fresh>
    60f4:	aa0003e2 	mov	x2, x0
    60f8:	910323e1 	add	x1, sp, #0xc8
    60fc:	52800020 	mov	w0, #0x1                   	// #1
    6100:	a90c8bf7 	stp	x23, x2, [sp, #200]
    6104:	97fff4ff 	bl	3500 <fwp_data.part.0.constprop.0>
    6108:	97fff466 	bl	32a0 <fwp_rc_fresh>
    610c:	aa0003e2 	mov	x2, x0
    6110:	910363e1 	add	x1, sp, #0xd8
    6114:	52800020 	mov	w0, #0x1                   	// #1
    6118:	a90d8bf5 	stp	x21, x2, [sp, #216]
    611c:	97fff4f9 	bl	3500 <fwp_data.part.0.constprop.0>
    6120:	97fff460 	bl	32a0 <fwp_rc_fresh>
    6124:	aa0003e2 	mov	x2, x0
    6128:	9103a3e1 	add	x1, sp, #0xe8
    612c:	52800020 	mov	w0, #0x1                   	// #1
    6130:	a90e8bf7 	stp	x23, x2, [sp, #232]
    6134:	97fff4f3 	bl	3500 <fwp_data.part.0.constprop.0>
    6138:	97fff45a 	bl	32a0 <fwp_rc_fresh>
    613c:	aa0003e2 	mov	x2, x0
    6140:	9103e3e1 	add	x1, sp, #0xf8
    6144:	52800020 	mov	w0, #0x1                   	// #1
    6148:	a90f8bf5 	stp	x21, x2, [sp, #248]
    614c:	97fff4ed 	bl	3500 <fwp_data.part.0.constprop.0>
    6150:	97fff454 	bl	32a0 <fwp_rc_fresh>
    6154:	aa0003e2 	mov	x2, x0
    6158:	910423e1 	add	x1, sp, #0x108
    615c:	52800020 	mov	w0, #0x1                   	// #1
    6160:	a9108bf7 	stp	x23, x2, [sp, #264]
    6164:	97fff4e7 	bl	3500 <fwp_data.part.0.constprop.0>
    6168:	97fff44e 	bl	32a0 <fwp_rc_fresh>
    616c:	aa0003e2 	mov	x2, x0
    6170:	910463e1 	add	x1, sp, #0x118
    6174:	52800020 	mov	w0, #0x1                   	// #1
    6178:	a9118bf5 	stp	x21, x2, [sp, #280]
    617c:	97fff4e1 	bl	3500 <fwp_data.part.0.constprop.0>
    6180:	97fff448 	bl	32a0 <fwp_rc_fresh>
    6184:	aa0003e2 	mov	x2, x0
    6188:	9104a3e1 	add	x1, sp, #0x128
    618c:	52800020 	mov	w0, #0x1                   	// #1
    6190:	a9128bf7 	stp	x23, x2, [sp, #296]
    6194:	97fff4db 	bl	3500 <fwp_data.part.0.constprop.0>
    6198:	97fff442 	bl	32a0 <fwp_rc_fresh>
    619c:	aa0003e2 	mov	x2, x0
    61a0:	9104e3e1 	add	x1, sp, #0x138
    61a4:	52800020 	mov	w0, #0x1                   	// #1
    61a8:	a9138bf5 	stp	x21, x2, [sp, #312]
    61ac:	97fff4d5 	bl	3500 <fwp_data.part.0.constprop.0>
    61b0:	91144283 	add	x3, x20, #0x510
    61b4:	aa0003f5 	mov	x21, x0
    61b8:	f949d861 	ldr	x1, [x3, #5040]
    61bc:	f949ec60 	ldr	x0, [x3, #5080]
    61c0:	cb0102a1 	sub	x1, x21, x1
    61c4:	eb00403f 	cmp	x1, x0, lsl #16
    61c8:	54000322 	b.cs	622c <f0+0x3cc>  // b.hs, b.nlast
    61cc:	d350fc22 	lsr	x2, x1, #16
    61d0:	f949fc63 	ldr	x3, [x3, #5112]
    61d4:	8b020842 	add	x2, x2, x2, lsl #2
    61d8:	d37df042 	lsl	x2, x2, #3
    61dc:	8b020060 	add	x0, x3, x2
    61e0:	f9401017 	ldr	x23, [x0, #32]
    61e4:	b4000257 	cbz	x23, 622c <f0+0x3cc>
    61e8:	38626862 	ldrb	w2, [x3, x2]
    61ec:	7100085f 	cmp	w2, #0x2
    61f0:	5400fd40 	b.eq	8198 <f0+0x2338>  // b.none
    61f4:	7100045f 	cmp	w2, #0x1
    61f8:	540001a1 	b.ne	622c <f0+0x3cc>  // b.any
    61fc:	29430002 	ldp	w2, w0, [x0, #24]
    6200:	92403c21 	and	x1, x1, #0xffff
    6204:	9b027c21 	mul	x1, x1, x2
    6208:	d360fc21 	lsr	x1, x1, #32
    620c:	eb00003f 	cmp	x1, x0
    6210:	540000e2 	b.cs	622c <f0+0x3cc>  // b.hs, b.nlast
    6214:	8b0102f7 	add	x23, x23, x1
    6218:	394002e0 	ldrb	w0, [x23]
    621c:	7103fc1f 	cmp	w0, #0xff
    6220:	540107c0 	b.eq	8318 <f0+0x24b8>  // b.none
    6224:	52800020 	mov	w0, #0x1                   	// #1
    6228:	390002e0 	strb	w0, [x23]
    622c:	910523e1 	add	x1, sp, #0x148
    6230:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6234:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6238:	52800020 	mov	w0, #0x1                   	// #1
    623c:	a914d7f7 	stp	x23, x21, [sp, #328]
    6240:	97fff4b0 	bl	3500 <fwp_data.part.0.constprop.0>
    6244:	97fff417 	bl	32a0 <fwp_rc_fresh>
    6248:	aa0003e2 	mov	x2, x0
    624c:	910563e1 	add	x1, sp, #0x158
    6250:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6254:	52800020 	mov	w0, #0x1                   	// #1
    6258:	a9158bf5 	stp	x21, x2, [sp, #344]
    625c:	97fff4a9 	bl	3500 <fwp_data.part.0.constprop.0>
    6260:	97fff410 	bl	32a0 <fwp_rc_fresh>
    6264:	aa0003e2 	mov	x2, x0
    6268:	9105a3e1 	add	x1, sp, #0x168
    626c:	52800020 	mov	w0, #0x1                   	// #1
    6270:	a9168bf7 	stp	x23, x2, [sp, #360]
    6274:	97fff4a3 	bl	3500 <fwp_data.part.0.constprop.0>
    6278:	97fff40a 	bl	32a0 <fwp_rc_fresh>
    627c:	aa0003e2 	mov	x2, x0
    6280:	9105e3e1 	add	x1, sp, #0x178
    6284:	52800020 	mov	w0, #0x1                   	// #1
    6288:	a9178bf5 	stp	x21, x2, [sp, #376]
    628c:	97fff49d 	bl	3500 <fwp_data.part.0.constprop.0>
    6290:	91144283 	add	x3, x20, #0x510
    6294:	aa0003f5 	mov	x21, x0
    6298:	f949d861 	ldr	x1, [x3, #5040]
    629c:	f949ec60 	ldr	x0, [x3, #5080]
    62a0:	cb0102a1 	sub	x1, x21, x1
    62a4:	eb00403f 	cmp	x1, x0, lsl #16
    62a8:	54000322 	b.cs	630c <f0+0x4ac>  // b.hs, b.nlast
    62ac:	d350fc22 	lsr	x2, x1, #16
    62b0:	f949fc63 	ldr	x3, [x3, #5112]
    62b4:	8b020842 	add	x2, x2, x2, lsl #2
    62b8:	d37df042 	lsl	x2, x2, #3
    62bc:	8b020060 	add	x0, x3, x2
    62c0:	f9401017 	ldr	x23, [x0, #32]
    62c4:	b4000257 	cbz	x23, 630c <f0+0x4ac>
    62c8:	38626862 	ldrb	w2, [x3, x2]
    62cc:	7100085f 	cmp	w2, #0x2
    62d0:	5400f5e0 	b.eq	818c <f0+0x232c>  // b.none
    62d4:	7100045f 	cmp	w2, #0x1
    62d8:	540001a1 	b.ne	630c <f0+0x4ac>  // b.any
    62dc:	29430002 	ldp	w2, w0, [x0, #24]
    62e0:	92403c21 	and	x1, x1, #0xffff
    62e4:	9b027c21 	mul	x1, x1, x2
    62e8:	d360fc21 	lsr	x1, x1, #32
    62ec:	eb00003f 	cmp	x1, x0
    62f0:	540000e2 	b.cs	630c <f0+0x4ac>  // b.hs, b.nlast
    62f4:	8b0102f7 	add	x23, x23, x1
    62f8:	394002e0 	ldrb	w0, [x23]
    62fc:	7103fc1f 	cmp	w0, #0xff
    6300:	54010120 	b.eq	8324 <f0+0x24c4>  // b.none
    6304:	52800020 	mov	w0, #0x1                   	// #1
    6308:	390002e0 	strb	w0, [x23]
    630c:	910623e1 	add	x1, sp, #0x188
    6310:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6314:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6318:	52800020 	mov	w0, #0x1                   	// #1
    631c:	a918d7f7 	stp	x23, x21, [sp, #392]
    6320:	97fff478 	bl	3500 <fwp_data.part.0.constprop.0>
    6324:	97fff3df 	bl	32a0 <fwp_rc_fresh>
    6328:	aa0003e2 	mov	x2, x0
    632c:	910663e1 	add	x1, sp, #0x198
    6330:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6334:	52800020 	mov	w0, #0x1                   	// #1
    6338:	a9198bf5 	stp	x21, x2, [sp, #408]
    633c:	97fff471 	bl	3500 <fwp_data.part.0.constprop.0>
    6340:	97fff3d8 	bl	32a0 <fwp_rc_fresh>
    6344:	aa0003e2 	mov	x2, x0
    6348:	9106a3e1 	add	x1, sp, #0x1a8
    634c:	52800020 	mov	w0, #0x1                   	// #1
    6350:	a91a8bf7 	stp	x23, x2, [sp, #424]
    6354:	97fff46b 	bl	3500 <fwp_data.part.0.constprop.0>
    6358:	97fff3d2 	bl	32a0 <fwp_rc_fresh>
    635c:	aa0003e2 	mov	x2, x0
    6360:	9106e3e1 	add	x1, sp, #0x1b8
    6364:	52800020 	mov	w0, #0x1                   	// #1
    6368:	a91b8bf5 	stp	x21, x2, [sp, #440]
    636c:	97fff465 	bl	3500 <fwp_data.part.0.constprop.0>
    6370:	97fff3cc 	bl	32a0 <fwp_rc_fresh>
    6374:	aa0003e2 	mov	x2, x0
    6378:	910723e1 	add	x1, sp, #0x1c8
    637c:	52800020 	mov	w0, #0x1                   	// #1
    6380:	a91c8bf7 	stp	x23, x2, [sp, #456]
    6384:	97fff45f 	bl	3500 <fwp_data.part.0.constprop.0>
    6388:	97fff3c6 	bl	32a0 <fwp_rc_fresh>
    638c:	aa0003e2 	mov	x2, x0
    6390:	910763e1 	add	x1, sp, #0x1d8
    6394:	52800020 	mov	w0, #0x1                   	// #1
    6398:	a91d8bf5 	stp	x21, x2, [sp, #472]
    639c:	97fff459 	bl	3500 <fwp_data.part.0.constprop.0>
    63a0:	91144283 	add	x3, x20, #0x510
    63a4:	aa0003f5 	mov	x21, x0
    63a8:	f949d861 	ldr	x1, [x3, #5040]
    63ac:	f949ec60 	ldr	x0, [x3, #5080]
    63b0:	cb0102a1 	sub	x1, x21, x1
    63b4:	eb00403f 	cmp	x1, x0, lsl #16
    63b8:	54000322 	b.cs	641c <f0+0x5bc>  // b.hs, b.nlast
    63bc:	d350fc22 	lsr	x2, x1, #16
    63c0:	f949fc63 	ldr	x3, [x3, #5112]
    63c4:	8b020842 	add	x2, x2, x2, lsl #2
    63c8:	d37df042 	lsl	x2, x2, #3
    63cc:	8b020060 	add	x0, x3, x2
    63d0:	f9401017 	ldr	x23, [x0, #32]
    63d4:	b4000257 	cbz	x23, 641c <f0+0x5bc>
    63d8:	38626862 	ldrb	w2, [x3, x2]
    63dc:	7100085f 	cmp	w2, #0x2
    63e0:	5400efa0 	b.eq	81d4 <f0+0x2374>  // b.none
    63e4:	7100045f 	cmp	w2, #0x1
    63e8:	540001a1 	b.ne	641c <f0+0x5bc>  // b.any
    63ec:	29430002 	ldp	w2, w0, [x0, #24]
    63f0:	92403c21 	and	x1, x1, #0xffff
    63f4:	9b027c21 	mul	x1, x1, x2
    63f8:	d360fc21 	lsr	x1, x1, #32
    63fc:	eb00003f 	cmp	x1, x0
    6400:	540000e2 	b.cs	641c <f0+0x5bc>  // b.hs, b.nlast
    6404:	8b0102f7 	add	x23, x23, x1
    6408:	394002e0 	ldrb	w0, [x23]
    640c:	7103fc1f 	cmp	w0, #0xff
    6410:	5400f900 	b.eq	8330 <f0+0x24d0>  // b.none
    6414:	52800020 	mov	w0, #0x1                   	// #1
    6418:	390002e0 	strb	w0, [x23]
    641c:	9107a3e1 	add	x1, sp, #0x1e8
    6420:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6424:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6428:	52800020 	mov	w0, #0x1                   	// #1
    642c:	a91ed7f7 	stp	x23, x21, [sp, #488]
    6430:	97fff434 	bl	3500 <fwp_data.part.0.constprop.0>
    6434:	97fff39b 	bl	32a0 <fwp_rc_fresh>
    6438:	aa0003e2 	mov	x2, x0
    643c:	9107e3e1 	add	x1, sp, #0x1f8
    6440:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6444:	52800020 	mov	w0, #0x1                   	// #1
    6448:	a91f8bf5 	stp	x21, x2, [sp, #504]
    644c:	97fff42d 	bl	3500 <fwp_data.part.0.constprop.0>
    6450:	97fff394 	bl	32a0 <fwp_rc_fresh>
    6454:	aa0003e2 	mov	x2, x0
    6458:	910823e1 	add	x1, sp, #0x208
    645c:	52800020 	mov	w0, #0x1                   	// #1
    6460:	f90107f7 	str	x23, [sp, #520]
    6464:	f9010be2 	str	x2, [sp, #528]
    6468:	97fff426 	bl	3500 <fwp_data.part.0.constprop.0>
    646c:	97fff38d 	bl	32a0 <fwp_rc_fresh>
    6470:	aa0003e2 	mov	x2, x0
    6474:	910863e1 	add	x1, sp, #0x218
    6478:	52800020 	mov	w0, #0x1                   	// #1
    647c:	f9010ff5 	str	x21, [sp, #536]
    6480:	f90113e2 	str	x2, [sp, #544]
    6484:	97fff41f 	bl	3500 <fwp_data.part.0.constprop.0>
    6488:	97fff386 	bl	32a0 <fwp_rc_fresh>
    648c:	aa0003e2 	mov	x2, x0
    6490:	9108a3e1 	add	x1, sp, #0x228
    6494:	52800020 	mov	w0, #0x1                   	// #1
    6498:	f90117f7 	str	x23, [sp, #552]
    649c:	f9011be2 	str	x2, [sp, #560]
    64a0:	97fff418 	bl	3500 <fwp_data.part.0.constprop.0>
    64a4:	97fff37f 	bl	32a0 <fwp_rc_fresh>
    64a8:	aa0003e2 	mov	x2, x0
    64ac:	9108e3e1 	add	x1, sp, #0x238
    64b0:	52800020 	mov	w0, #0x1                   	// #1
    64b4:	f9011ff5 	str	x21, [sp, #568]
    64b8:	f90123e2 	str	x2, [sp, #576]
    64bc:	97fff411 	bl	3500 <fwp_data.part.0.constprop.0>
    64c0:	91144283 	add	x3, x20, #0x510
    64c4:	aa0003f5 	mov	x21, x0
    64c8:	f949d861 	ldr	x1, [x3, #5040]
    64cc:	f949ec60 	ldr	x0, [x3, #5080]
    64d0:	cb0102a1 	sub	x1, x21, x1
    64d4:	eb00403f 	cmp	x1, x0, lsl #16
    64d8:	54000322 	b.cs	653c <f0+0x6dc>  // b.hs, b.nlast
    64dc:	d350fc22 	lsr	x2, x1, #16
    64e0:	f949fc63 	ldr	x3, [x3, #5112]
    64e4:	8b020842 	add	x2, x2, x2, lsl #2
    64e8:	d37df042 	lsl	x2, x2, #3
    64ec:	8b020060 	add	x0, x3, x2
    64f0:	f9401017 	ldr	x23, [x0, #32]
    64f4:	b4000257 	cbz	x23, 653c <f0+0x6dc>
    64f8:	38626862 	ldrb	w2, [x3, x2]
    64fc:	7100085f 	cmp	w2, #0x2
    6500:	5400e640 	b.eq	81c8 <f0+0x2368>  // b.none
    6504:	7100045f 	cmp	w2, #0x1
    6508:	540001a1 	b.ne	653c <f0+0x6dc>  // b.any
    650c:	29430002 	ldp	w2, w0, [x0, #24]
    6510:	92403c21 	and	x1, x1, #0xffff
    6514:	9b027c21 	mul	x1, x1, x2
    6518:	d360fc21 	lsr	x1, x1, #32
    651c:	eb00003f 	cmp	x1, x0
    6520:	540000e2 	b.cs	653c <f0+0x6dc>  // b.hs, b.nlast
    6524:	8b0102f7 	add	x23, x23, x1
    6528:	394002e0 	ldrb	w0, [x23]
    652c:	7103fc1f 	cmp	w0, #0xff
    6530:	5400f060 	b.eq	833c <f0+0x24dc>  // b.none
    6534:	52800020 	mov	w0, #0x1                   	// #1
    6538:	390002e0 	strb	w0, [x23]
    653c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6540:	910923e1 	add	x1, sp, #0x248
    6544:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6548:	52800020 	mov	w0, #0x1                   	// #1
    654c:	f90127e2 	str	x2, [sp, #584]
    6550:	f9012bf5 	str	x21, [sp, #592]
    6554:	97fff3eb 	bl	3500 <fwp_data.part.0.constprop.0>
    6558:	97fff352 	bl	32a0 <fwp_rc_fresh>
    655c:	aa0003e2 	mov	x2, x0
    6560:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6564:	910963e1 	add	x1, sp, #0x258
    6568:	52800020 	mov	w0, #0x1                   	// #1
    656c:	f9012fe3 	str	x3, [sp, #600]
    6570:	f90133e2 	str	x2, [sp, #608]
    6574:	97fff3e3 	bl	3500 <fwp_data.part.0.constprop.0>
    6578:	91144283 	add	x3, x20, #0x510
    657c:	aa0003f5 	mov	x21, x0
    6580:	f949d861 	ldr	x1, [x3, #5040]
    6584:	f949ec60 	ldr	x0, [x3, #5080]
    6588:	cb0102a1 	sub	x1, x21, x1
    658c:	eb00403f 	cmp	x1, x0, lsl #16
    6590:	54000322 	b.cs	65f4 <f0+0x794>  // b.hs, b.nlast
    6594:	d350fc22 	lsr	x2, x1, #16
    6598:	f949fc63 	ldr	x3, [x3, #5112]
    659c:	8b020842 	add	x2, x2, x2, lsl #2
    65a0:	d37df042 	lsl	x2, x2, #3
    65a4:	8b020060 	add	x0, x3, x2
    65a8:	f9401017 	ldr	x23, [x0, #32]
    65ac:	b4000257 	cbz	x23, 65f4 <f0+0x794>
    65b0:	38626862 	ldrb	w2, [x3, x2]
    65b4:	7100085f 	cmp	w2, #0x2
    65b8:	5400e020 	b.eq	81bc <f0+0x235c>  // b.none
    65bc:	7100045f 	cmp	w2, #0x1
    65c0:	540001a1 	b.ne	65f4 <f0+0x794>  // b.any
    65c4:	29430002 	ldp	w2, w0, [x0, #24]
    65c8:	92403c21 	and	x1, x1, #0xffff
    65cc:	9b027c21 	mul	x1, x1, x2
    65d0:	d360fc21 	lsr	x1, x1, #32
    65d4:	eb00003f 	cmp	x1, x0
    65d8:	540000e2 	b.cs	65f4 <f0+0x794>  // b.hs, b.nlast
    65dc:	8b0102f7 	add	x23, x23, x1
    65e0:	394002e0 	ldrb	w0, [x23]
    65e4:	7103fc1f 	cmp	w0, #0xff
    65e8:	5400eb00 	b.eq	8348 <f0+0x24e8>  // b.none
    65ec:	52800020 	mov	w0, #0x1                   	// #1
    65f0:	390002e0 	strb	w0, [x23]
    65f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    65f8:	9109a3e1 	add	x1, sp, #0x268
    65fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6600:	52800020 	mov	w0, #0x1                   	// #1
    6604:	f90137e2 	str	x2, [sp, #616]
    6608:	f9013bf5 	str	x21, [sp, #624]
    660c:	97fff3bd 	bl	3500 <fwp_data.part.0.constprop.0>
    6610:	97fff324 	bl	32a0 <fwp_rc_fresh>
    6614:	aa0003e2 	mov	x2, x0
    6618:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    661c:	9109e3e1 	add	x1, sp, #0x278
    6620:	52800020 	mov	w0, #0x1                   	// #1
    6624:	f9013fe3 	str	x3, [sp, #632]
    6628:	f90143e2 	str	x2, [sp, #640]
    662c:	97fff3b5 	bl	3500 <fwp_data.part.0.constprop.0>
    6630:	91144283 	add	x3, x20, #0x510
    6634:	aa0003f5 	mov	x21, x0
    6638:	f949d861 	ldr	x1, [x3, #5040]
    663c:	f949ec60 	ldr	x0, [x3, #5080]
    6640:	cb0102a1 	sub	x1, x21, x1
    6644:	eb00403f 	cmp	x1, x0, lsl #16
    6648:	54000322 	b.cs	66ac <f0+0x84c>  // b.hs, b.nlast
    664c:	d350fc22 	lsr	x2, x1, #16
    6650:	f949fc63 	ldr	x3, [x3, #5112]
    6654:	8b020842 	add	x2, x2, x2, lsl #2
    6658:	d37df042 	lsl	x2, x2, #3
    665c:	8b020060 	add	x0, x3, x2
    6660:	f9401017 	ldr	x23, [x0, #32]
    6664:	b4000257 	cbz	x23, 66ac <f0+0x84c>
    6668:	38626862 	ldrb	w2, [x3, x2]
    666c:	7100085f 	cmp	w2, #0x2
    6670:	5400da00 	b.eq	81b0 <f0+0x2350>  // b.none
    6674:	7100045f 	cmp	w2, #0x1
    6678:	540001a1 	b.ne	66ac <f0+0x84c>  // b.any
    667c:	29430002 	ldp	w2, w0, [x0, #24]
    6680:	92403c21 	and	x1, x1, #0xffff
    6684:	9b027c21 	mul	x1, x1, x2
    6688:	d360fc21 	lsr	x1, x1, #32
    668c:	eb00003f 	cmp	x1, x0
    6690:	540000e2 	b.cs	66ac <f0+0x84c>  // b.hs, b.nlast
    6694:	8b0102f7 	add	x23, x23, x1
    6698:	394002e0 	ldrb	w0, [x23]
    669c:	7103fc1f 	cmp	w0, #0xff
    66a0:	5400e5a0 	b.eq	8354 <f0+0x24f4>  // b.none
    66a4:	52800020 	mov	w0, #0x1                   	// #1
    66a8:	390002e0 	strb	w0, [x23]
    66ac:	910a23e1 	add	x1, sp, #0x288
    66b0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    66b4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    66b8:	52800020 	mov	w0, #0x1                   	// #1
    66bc:	f90147f7 	str	x23, [sp, #648]
    66c0:	f9014bf5 	str	x21, [sp, #656]
    66c4:	97fff38f 	bl	3500 <fwp_data.part.0.constprop.0>
    66c8:	97fff2f6 	bl	32a0 <fwp_rc_fresh>
    66cc:	aa0003e2 	mov	x2, x0
    66d0:	910a63e1 	add	x1, sp, #0x298
    66d4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    66d8:	52800020 	mov	w0, #0x1                   	// #1
    66dc:	f9014ff5 	str	x21, [sp, #664]
    66e0:	f90153e2 	str	x2, [sp, #672]
    66e4:	97fff387 	bl	3500 <fwp_data.part.0.constprop.0>
    66e8:	97fff2ee 	bl	32a0 <fwp_rc_fresh>
    66ec:	aa0003e2 	mov	x2, x0
    66f0:	910aa3e1 	add	x1, sp, #0x2a8
    66f4:	52800020 	mov	w0, #0x1                   	// #1
    66f8:	f90157f7 	str	x23, [sp, #680]
    66fc:	f9015be2 	str	x2, [sp, #688]
    6700:	97fff380 	bl	3500 <fwp_data.part.0.constprop.0>
    6704:	97fff2e7 	bl	32a0 <fwp_rc_fresh>
    6708:	aa0003e2 	mov	x2, x0
    670c:	910ae3e1 	add	x1, sp, #0x2b8
    6710:	52800020 	mov	w0, #0x1                   	// #1
    6714:	f9015ff5 	str	x21, [sp, #696]
    6718:	f90163e2 	str	x2, [sp, #704]
    671c:	97fff379 	bl	3500 <fwp_data.part.0.constprop.0>
    6720:	97fff2e0 	bl	32a0 <fwp_rc_fresh>
    6724:	aa0003e2 	mov	x2, x0
    6728:	910b23e1 	add	x1, sp, #0x2c8
    672c:	52800020 	mov	w0, #0x1                   	// #1
    6730:	f90167f7 	str	x23, [sp, #712]
    6734:	f9016be2 	str	x2, [sp, #720]
    6738:	97fff372 	bl	3500 <fwp_data.part.0.constprop.0>
    673c:	91144283 	add	x3, x20, #0x510
    6740:	aa0003f5 	mov	x21, x0
    6744:	f949d861 	ldr	x1, [x3, #5040]
    6748:	f949ec60 	ldr	x0, [x3, #5080]
    674c:	cb0102a1 	sub	x1, x21, x1
    6750:	eb00403f 	cmp	x1, x0, lsl #16
    6754:	54000322 	b.cs	67b8 <f0+0x958>  // b.hs, b.nlast
    6758:	d350fc22 	lsr	x2, x1, #16
    675c:	f949fc63 	ldr	x3, [x3, #5112]
    6760:	8b020842 	add	x2, x2, x2, lsl #2
    6764:	d37df042 	lsl	x2, x2, #3
    6768:	8b020060 	add	x0, x3, x2
    676c:	f9401017 	ldr	x23, [x0, #32]
    6770:	b4000257 	cbz	x23, 67b8 <f0+0x958>
    6774:	38626862 	ldrb	w2, [x3, x2]
    6778:	7100085f 	cmp	w2, #0x2
    677c:	5400d5c0 	b.eq	8234 <f0+0x23d4>  // b.none
    6780:	7100045f 	cmp	w2, #0x1
    6784:	540001a1 	b.ne	67b8 <f0+0x958>  // b.any
    6788:	29430002 	ldp	w2, w0, [x0, #24]
    678c:	92403c21 	and	x1, x1, #0xffff
    6790:	9b027c21 	mul	x1, x1, x2
    6794:	d360fc21 	lsr	x1, x1, #32
    6798:	eb00003f 	cmp	x1, x0
    679c:	540000e2 	b.cs	67b8 <f0+0x958>  // b.hs, b.nlast
    67a0:	8b0102f7 	add	x23, x23, x1
    67a4:	394002e0 	ldrb	w0, [x23]
    67a8:	7103fc1f 	cmp	w0, #0xff
    67ac:	5400dda0 	b.eq	8360 <f0+0x2500>  // b.none
    67b0:	52800020 	mov	w0, #0x1                   	// #1
    67b4:	390002e0 	strb	w0, [x23]
    67b8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    67bc:	910b63e1 	add	x1, sp, #0x2d8
    67c0:	52800020 	mov	w0, #0x1                   	// #1
    67c4:	f9016fe2 	str	x2, [sp, #728]
    67c8:	f90173f5 	str	x21, [sp, #736]
    67cc:	97fff34d 	bl	3500 <fwp_data.part.0.constprop.0>
    67d0:	91144283 	add	x3, x20, #0x510
    67d4:	aa0003f5 	mov	x21, x0
    67d8:	f949d861 	ldr	x1, [x3, #5040]
    67dc:	f949ec60 	ldr	x0, [x3, #5080]
    67e0:	cb0102a1 	sub	x1, x21, x1
    67e4:	eb00403f 	cmp	x1, x0, lsl #16
    67e8:	54000322 	b.cs	684c <f0+0x9ec>  // b.hs, b.nlast
    67ec:	d350fc22 	lsr	x2, x1, #16
    67f0:	f949fc63 	ldr	x3, [x3, #5112]
    67f4:	8b020842 	add	x2, x2, x2, lsl #2
    67f8:	d37df042 	lsl	x2, x2, #3
    67fc:	8b020060 	add	x0, x3, x2
    6800:	f9401017 	ldr	x23, [x0, #32]
    6804:	b4000257 	cbz	x23, 684c <f0+0x9ec>
    6808:	38626862 	ldrb	w2, [x3, x2]
    680c:	7100085f 	cmp	w2, #0x2
    6810:	5400d0c0 	b.eq	8228 <f0+0x23c8>  // b.none
    6814:	7100045f 	cmp	w2, #0x1
    6818:	540001a1 	b.ne	684c <f0+0x9ec>  // b.any
    681c:	29430002 	ldp	w2, w0, [x0, #24]
    6820:	92403c21 	and	x1, x1, #0xffff
    6824:	9b027c21 	mul	x1, x1, x2
    6828:	d360fc21 	lsr	x1, x1, #32
    682c:	eb00003f 	cmp	x1, x0
    6830:	540000e2 	b.cs	684c <f0+0x9ec>  // b.hs, b.nlast
    6834:	8b0102f7 	add	x23, x23, x1
    6838:	394002e0 	ldrb	w0, [x23]
    683c:	7103fc1f 	cmp	w0, #0xff
    6840:	5400d960 	b.eq	836c <f0+0x250c>  // b.none
    6844:	52800020 	mov	w0, #0x1                   	// #1
    6848:	390002e0 	strb	w0, [x23]
    684c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6850:	910ba3e1 	add	x1, sp, #0x2e8
    6854:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6858:	52800020 	mov	w0, #0x1                   	// #1
    685c:	f90177e2 	str	x2, [sp, #744]
    6860:	f9017bf5 	str	x21, [sp, #752]
    6864:	97fff327 	bl	3500 <fwp_data.part.0.constprop.0>
    6868:	91144283 	add	x3, x20, #0x510
    686c:	aa0003f5 	mov	x21, x0
    6870:	f949d861 	ldr	x1, [x3, #5040]
    6874:	f949ec60 	ldr	x0, [x3, #5080]
    6878:	cb0102a1 	sub	x1, x21, x1
    687c:	eb00403f 	cmp	x1, x0, lsl #16
    6880:	54000322 	b.cs	68e4 <f0+0xa84>  // b.hs, b.nlast
    6884:	d350fc22 	lsr	x2, x1, #16
    6888:	f949fc63 	ldr	x3, [x3, #5112]
    688c:	8b020842 	add	x2, x2, x2, lsl #2
    6890:	d37df042 	lsl	x2, x2, #3
    6894:	8b020060 	add	x0, x3, x2
    6898:	f9401017 	ldr	x23, [x0, #32]
    689c:	b4000257 	cbz	x23, 68e4 <f0+0xa84>
    68a0:	38626862 	ldrb	w2, [x3, x2]
    68a4:	7100085f 	cmp	w2, #0x2
    68a8:	5400cba0 	b.eq	821c <f0+0x23bc>  // b.none
    68ac:	7100045f 	cmp	w2, #0x1
    68b0:	540001a1 	b.ne	68e4 <f0+0xa84>  // b.any
    68b4:	29430002 	ldp	w2, w0, [x0, #24]
    68b8:	92403c21 	and	x1, x1, #0xffff
    68bc:	9b027c21 	mul	x1, x1, x2
    68c0:	d360fc21 	lsr	x1, x1, #32
    68c4:	eb00003f 	cmp	x1, x0
    68c8:	540000e2 	b.cs	68e4 <f0+0xa84>  // b.hs, b.nlast
    68cc:	8b0102f7 	add	x23, x23, x1
    68d0:	394002e0 	ldrb	w0, [x23]
    68d4:	7103fc1f 	cmp	w0, #0xff
    68d8:	5400d500 	b.eq	8378 <f0+0x2518>  // b.none
    68dc:	52800020 	mov	w0, #0x1                   	// #1
    68e0:	390002e0 	strb	w0, [x23]
    68e4:	910be3e1 	add	x1, sp, #0x2f8
    68e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    68ec:	52800020 	mov	w0, #0x1                   	// #1
    68f0:	f9017ff7 	str	x23, [sp, #760]
    68f4:	f90183f5 	str	x21, [sp, #768]
    68f8:	97fff302 	bl	3500 <fwp_data.part.0.constprop.0>
    68fc:	97fff269 	bl	32a0 <fwp_rc_fresh>
    6900:	aa0003e2 	mov	x2, x0
    6904:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    6908:	910c23e1 	add	x1, sp, #0x308
    690c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    6910:	52800020 	mov	w0, #0x1                   	// #1
    6914:	f90187e3 	str	x3, [sp, #776]
    6918:	f9018be2 	str	x2, [sp, #784]
    691c:	97fff2f9 	bl	3500 <fwp_data.part.0.constprop.0>
    6920:	97fff260 	bl	32a0 <fwp_rc_fresh>
    6924:	aa0003e2 	mov	x2, x0
    6928:	910c63e1 	add	x1, sp, #0x318
    692c:	52800020 	mov	w0, #0x1                   	// #1
    6930:	f9018ff7 	str	x23, [sp, #792]
    6934:	f90193e2 	str	x2, [sp, #800]
    6938:	97fff2f2 	bl	3500 <fwp_data.part.0.constprop.0>
    693c:	91144283 	add	x3, x20, #0x510
    6940:	aa0003f5 	mov	x21, x0
    6944:	f949d861 	ldr	x1, [x3, #5040]
    6948:	f949ec60 	ldr	x0, [x3, #5080]
    694c:	cb0102a1 	sub	x1, x21, x1
    6950:	eb00403f 	cmp	x1, x0, lsl #16
    6954:	54000322 	b.cs	69b8 <f0+0xb58>  // b.hs, b.nlast
    6958:	d350fc22 	lsr	x2, x1, #16
    695c:	f949fc63 	ldr	x3, [x3, #5112]
    6960:	8b020842 	add	x2, x2, x2, lsl #2
    6964:	d37df042 	lsl	x2, x2, #3
    6968:	8b020060 	add	x0, x3, x2
    696c:	f9401017 	ldr	x23, [x0, #32]
    6970:	b4000257 	cbz	x23, 69b8 <f0+0xb58>
    6974:	38626862 	ldrb	w2, [x3, x2]
    6978:	7100085f 	cmp	w2, #0x2
    697c:	5400c4a0 	b.eq	8210 <f0+0x23b0>  // b.none
    6980:	7100045f 	cmp	w2, #0x1
    6984:	540001a1 	b.ne	69b8 <f0+0xb58>  // b.any
    6988:	29430002 	ldp	w2, w0, [x0, #24]
    698c:	92403c21 	and	x1, x1, #0xffff
    6990:	9b027c21 	mul	x1, x1, x2
    6994:	d360fc21 	lsr	x1, x1, #32
    6998:	eb00003f 	cmp	x1, x0
    699c:	540000e2 	b.cs	69b8 <f0+0xb58>  // b.hs, b.nlast
    69a0:	8b0102f7 	add	x23, x23, x1
    69a4:	394002e0 	ldrb	w0, [x23]
    69a8:	7103fc1f 	cmp	w0, #0xff
    69ac:	5400cec0 	b.eq	8384 <f0+0x2524>  // b.none
    69b0:	52800020 	mov	w0, #0x1                   	// #1
    69b4:	390002e0 	strb	w0, [x23]
    69b8:	910ca3e1 	add	x1, sp, #0x328
    69bc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    69c0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    69c4:	52800020 	mov	w0, #0x1                   	// #1
    69c8:	f90197f7 	str	x23, [sp, #808]
    69cc:	f9019bf5 	str	x21, [sp, #816]
    69d0:	97fff2cc 	bl	3500 <fwp_data.part.0.constprop.0>
    69d4:	97fff233 	bl	32a0 <fwp_rc_fresh>
    69d8:	aa0003e2 	mov	x2, x0
    69dc:	910ce3e1 	add	x1, sp, #0x338
    69e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    69e4:	52800020 	mov	w0, #0x1                   	// #1
    69e8:	f9019ff5 	str	x21, [sp, #824]
    69ec:	f901a3e2 	str	x2, [sp, #832]
    69f0:	97fff2c4 	bl	3500 <fwp_data.part.0.constprop.0>
    69f4:	97fff22b 	bl	32a0 <fwp_rc_fresh>
    69f8:	aa0003e2 	mov	x2, x0
    69fc:	910d23e1 	add	x1, sp, #0x348
    6a00:	52800020 	mov	w0, #0x1                   	// #1
    6a04:	f901a7f7 	str	x23, [sp, #840]
    6a08:	f901abe2 	str	x2, [sp, #848]
    6a0c:	97fff2bd 	bl	3500 <fwp_data.part.0.constprop.0>
    6a10:	97fff224 	bl	32a0 <fwp_rc_fresh>
    6a14:	aa0003e2 	mov	x2, x0
    6a18:	910d63e1 	add	x1, sp, #0x358
    6a1c:	52800020 	mov	w0, #0x1                   	// #1
    6a20:	f901aff5 	str	x21, [sp, #856]
    6a24:	f901b3e2 	str	x2, [sp, #864]
    6a28:	97fff2b6 	bl	3500 <fwp_data.part.0.constprop.0>
    6a2c:	91144283 	add	x3, x20, #0x510
    6a30:	aa0003f5 	mov	x21, x0
    6a34:	f949d861 	ldr	x1, [x3, #5040]
    6a38:	f949ec60 	ldr	x0, [x3, #5080]
    6a3c:	cb0102a1 	sub	x1, x21, x1
    6a40:	eb00403f 	cmp	x1, x0, lsl #16
    6a44:	54000322 	b.cs	6aa8 <f0+0xc48>  // b.hs, b.nlast
    6a48:	d350fc22 	lsr	x2, x1, #16
    6a4c:	f949fc63 	ldr	x3, [x3, #5112]
    6a50:	8b020842 	add	x2, x2, x2, lsl #2
    6a54:	d37df042 	lsl	x2, x2, #3
    6a58:	8b020060 	add	x0, x3, x2
    6a5c:	f9401017 	ldr	x23, [x0, #32]
    6a60:	b4000257 	cbz	x23, 6aa8 <f0+0xc48>
    6a64:	38626862 	ldrb	w2, [x3, x2]
    6a68:	7100085f 	cmp	w2, #0x2
    6a6c:	5400bcc0 	b.eq	8204 <f0+0x23a4>  // b.none
    6a70:	7100045f 	cmp	w2, #0x1
    6a74:	540001a1 	b.ne	6aa8 <f0+0xc48>  // b.any
    6a78:	29430002 	ldp	w2, w0, [x0, #24]
    6a7c:	92403c21 	and	x1, x1, #0xffff
    6a80:	9b027c21 	mul	x1, x1, x2
    6a84:	d360fc21 	lsr	x1, x1, #32
    6a88:	eb00003f 	cmp	x1, x0
    6a8c:	540000e2 	b.cs	6aa8 <f0+0xc48>  // b.hs, b.nlast
    6a90:	8b0102f7 	add	x23, x23, x1
    6a94:	394002e0 	ldrb	w0, [x23]
    6a98:	7103fc1f 	cmp	w0, #0xff
    6a9c:	5400c7a0 	b.eq	8390 <f0+0x2530>  // b.none
    6aa0:	52800020 	mov	w0, #0x1                   	// #1
    6aa4:	390002e0 	strb	w0, [x23]
    6aa8:	910da3e1 	add	x1, sp, #0x368
    6aac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6ab0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6ab4:	52800020 	mov	w0, #0x1                   	// #1
    6ab8:	f901b7f7 	str	x23, [sp, #872]
    6abc:	f901bbf5 	str	x21, [sp, #880]
    6ac0:	97fff290 	bl	3500 <fwp_data.part.0.constprop.0>
    6ac4:	97fff1f7 	bl	32a0 <fwp_rc_fresh>
    6ac8:	aa0003e2 	mov	x2, x0
    6acc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6ad0:	910de3e1 	add	x1, sp, #0x378
    6ad4:	52800020 	mov	w0, #0x1                   	// #1
    6ad8:	f901bfe3 	str	x3, [sp, #888]
    6adc:	f901c3e2 	str	x2, [sp, #896]
    6ae0:	97fff288 	bl	3500 <fwp_data.part.0.constprop.0>
    6ae4:	97fff1ef 	bl	32a0 <fwp_rc_fresh>
    6ae8:	aa0003e2 	mov	x2, x0
    6aec:	910e23e1 	add	x1, sp, #0x388
    6af0:	52800020 	mov	w0, #0x1                   	// #1
    6af4:	f901c7f7 	str	x23, [sp, #904]
    6af8:	f901cbe2 	str	x2, [sp, #912]
    6afc:	97fff281 	bl	3500 <fwp_data.part.0.constprop.0>
    6b00:	91144283 	add	x3, x20, #0x510
    6b04:	aa0003f5 	mov	x21, x0
    6b08:	f949d861 	ldr	x1, [x3, #5040]
    6b0c:	f949ec60 	ldr	x0, [x3, #5080]
    6b10:	cb0102a1 	sub	x1, x21, x1
    6b14:	eb00403f 	cmp	x1, x0, lsl #16
    6b18:	54000322 	b.cs	6b7c <f0+0xd1c>  // b.hs, b.nlast
    6b1c:	d350fc22 	lsr	x2, x1, #16
    6b20:	f949fc63 	ldr	x3, [x3, #5112]
    6b24:	8b020842 	add	x2, x2, x2, lsl #2
    6b28:	d37df042 	lsl	x2, x2, #3
    6b2c:	8b020060 	add	x0, x3, x2
    6b30:	f9401017 	ldr	x23, [x0, #32]
    6b34:	b4000257 	cbz	x23, 6b7c <f0+0xd1c>
    6b38:	38626862 	ldrb	w2, [x3, x2]
    6b3c:	7100085f 	cmp	w2, #0x2
    6b40:	5400b5c0 	b.eq	81f8 <f0+0x2398>  // b.none
    6b44:	7100045f 	cmp	w2, #0x1
    6b48:	540001a1 	b.ne	6b7c <f0+0xd1c>  // b.any
    6b4c:	29430002 	ldp	w2, w0, [x0, #24]
    6b50:	92403c21 	and	x1, x1, #0xffff
    6b54:	9b027c21 	mul	x1, x1, x2
    6b58:	d360fc21 	lsr	x1, x1, #32
    6b5c:	eb00003f 	cmp	x1, x0
    6b60:	540000e2 	b.cs	6b7c <f0+0xd1c>  // b.hs, b.nlast
    6b64:	8b0102f7 	add	x23, x23, x1
    6b68:	394002e0 	ldrb	w0, [x23]
    6b6c:	7103fc1f 	cmp	w0, #0xff
    6b70:	5400c160 	b.eq	839c <f0+0x253c>  // b.none
    6b74:	52800020 	mov	w0, #0x1                   	// #1
    6b78:	390002e0 	strb	w0, [x23]
    6b7c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6b80:	910e63e1 	add	x1, sp, #0x398
    6b84:	52800020 	mov	w0, #0x1                   	// #1
    6b88:	f901cfe2 	str	x2, [sp, #920]
    6b8c:	f901d3f5 	str	x21, [sp, #928]
    6b90:	97fff25c 	bl	3500 <fwp_data.part.0.constprop.0>
    6b94:	91144283 	add	x3, x20, #0x510
    6b98:	aa0003f5 	mov	x21, x0
    6b9c:	f949d861 	ldr	x1, [x3, #5040]
    6ba0:	f949ec60 	ldr	x0, [x3, #5080]
    6ba4:	cb0102a1 	sub	x1, x21, x1
    6ba8:	eb00403f 	cmp	x1, x0, lsl #16
    6bac:	54000322 	b.cs	6c10 <f0+0xdb0>  // b.hs, b.nlast
    6bb0:	d350fc22 	lsr	x2, x1, #16
    6bb4:	f949fc63 	ldr	x3, [x3, #5112]
    6bb8:	8b020842 	add	x2, x2, x2, lsl #2
    6bbc:	d37df042 	lsl	x2, x2, #3
    6bc0:	8b020060 	add	x0, x3, x2
    6bc4:	f9401017 	ldr	x23, [x0, #32]
    6bc8:	b4000257 	cbz	x23, 6c10 <f0+0xdb0>
    6bcc:	38626862 	ldrb	w2, [x3, x2]
    6bd0:	7100085f 	cmp	w2, #0x2
    6bd4:	5400b0c0 	b.eq	81ec <f0+0x238c>  // b.none
    6bd8:	7100045f 	cmp	w2, #0x1
    6bdc:	540001a1 	b.ne	6c10 <f0+0xdb0>  // b.any
    6be0:	29430002 	ldp	w2, w0, [x0, #24]
    6be4:	92403c21 	and	x1, x1, #0xffff
    6be8:	9b027c21 	mul	x1, x1, x2
    6bec:	d360fc21 	lsr	x1, x1, #32
    6bf0:	eb00003f 	cmp	x1, x0
    6bf4:	540000e2 	b.cs	6c10 <f0+0xdb0>  // b.hs, b.nlast
    6bf8:	8b0102f7 	add	x23, x23, x1
    6bfc:	394002e0 	ldrb	w0, [x23]
    6c00:	7103fc1f 	cmp	w0, #0xff
    6c04:	5400bd20 	b.eq	83a8 <f0+0x2548>  // b.none
    6c08:	52800020 	mov	w0, #0x1                   	// #1
    6c0c:	390002e0 	strb	w0, [x23]
    6c10:	910ea3e1 	add	x1, sp, #0x3a8
    6c14:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6c18:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6c1c:	52800020 	mov	w0, #0x1                   	// #1
    6c20:	f901d7f7 	str	x23, [sp, #936]
    6c24:	f901dbf5 	str	x21, [sp, #944]
    6c28:	97fff236 	bl	3500 <fwp_data.part.0.constprop.0>
    6c2c:	97fff19d 	bl	32a0 <fwp_rc_fresh>
    6c30:	aa0003e2 	mov	x2, x0
    6c34:	910ee3e1 	add	x1, sp, #0x3b8
    6c38:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6c3c:	52800020 	mov	w0, #0x1                   	// #1
    6c40:	f901dff5 	str	x21, [sp, #952]
    6c44:	f901e3e2 	str	x2, [sp, #960]
    6c48:	97fff22e 	bl	3500 <fwp_data.part.0.constprop.0>
    6c4c:	97fff195 	bl	32a0 <fwp_rc_fresh>
    6c50:	aa0003e2 	mov	x2, x0
    6c54:	910f23e1 	add	x1, sp, #0x3c8
    6c58:	52800020 	mov	w0, #0x1                   	// #1
    6c5c:	f901e7f7 	str	x23, [sp, #968]
    6c60:	f901ebe2 	str	x2, [sp, #976]
    6c64:	97fff227 	bl	3500 <fwp_data.part.0.constprop.0>
    6c68:	97fff18e 	bl	32a0 <fwp_rc_fresh>
    6c6c:	aa0003e2 	mov	x2, x0
    6c70:	910f63e1 	add	x1, sp, #0x3d8
    6c74:	52800020 	mov	w0, #0x1                   	// #1
    6c78:	f901eff5 	str	x21, [sp, #984]
    6c7c:	f901f3e2 	str	x2, [sp, #992]
    6c80:	97fff220 	bl	3500 <fwp_data.part.0.constprop.0>
    6c84:	91144283 	add	x3, x20, #0x510
    6c88:	aa0003f5 	mov	x21, x0
    6c8c:	f949d861 	ldr	x1, [x3, #5040]
    6c90:	f949ec60 	ldr	x0, [x3, #5080]
    6c94:	cb0102a1 	sub	x1, x21, x1
    6c98:	eb00403f 	cmp	x1, x0, lsl #16
    6c9c:	54000322 	b.cs	6d00 <f0+0xea0>  // b.hs, b.nlast
    6ca0:	d350fc22 	lsr	x2, x1, #16
    6ca4:	f949fc63 	ldr	x3, [x3, #5112]
    6ca8:	8b020842 	add	x2, x2, x2, lsl #2
    6cac:	d37df042 	lsl	x2, x2, #3
    6cb0:	8b020060 	add	x0, x3, x2
    6cb4:	f9401017 	ldr	x23, [x0, #32]
    6cb8:	b4000257 	cbz	x23, 6d00 <f0+0xea0>
    6cbc:	38626862 	ldrb	w2, [x3, x2]
    6cc0:	7100085f 	cmp	w2, #0x2
    6cc4:	5400a8e0 	b.eq	81e0 <f0+0x2380>  // b.none
    6cc8:	7100045f 	cmp	w2, #0x1
    6ccc:	540001a1 	b.ne	6d00 <f0+0xea0>  // b.any
    6cd0:	29430002 	ldp	w2, w0, [x0, #24]
    6cd4:	92403c21 	and	x1, x1, #0xffff
    6cd8:	9b027c21 	mul	x1, x1, x2
    6cdc:	d360fc21 	lsr	x1, x1, #32
    6ce0:	eb00003f 	cmp	x1, x0
    6ce4:	540000e2 	b.cs	6d00 <f0+0xea0>  // b.hs, b.nlast
    6ce8:	8b0102f7 	add	x23, x23, x1
    6cec:	394002e0 	ldrb	w0, [x23]
    6cf0:	7103fc1f 	cmp	w0, #0xff
    6cf4:	5400b600 	b.eq	83b4 <f0+0x2554>  // b.none
    6cf8:	52800020 	mov	w0, #0x1                   	// #1
    6cfc:	390002e0 	strb	w0, [x23]
    6d00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6d04:	910fa3e1 	add	x1, sp, #0x3e8
    6d08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6d0c:	52800020 	mov	w0, #0x1                   	// #1
    6d10:	f901f7e2 	str	x2, [sp, #1000]
    6d14:	f901fbf5 	str	x21, [sp, #1008]
    6d18:	97fff1fa 	bl	3500 <fwp_data.part.0.constprop.0>
    6d1c:	97fff161 	bl	32a0 <fwp_rc_fresh>
    6d20:	aa0003e2 	mov	x2, x0
    6d24:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6d28:	910fe3e1 	add	x1, sp, #0x3f8
    6d2c:	52800020 	mov	w0, #0x1                   	// #1
    6d30:	f901ffe3 	str	x3, [sp, #1016]
    6d34:	f90203e2 	str	x2, [sp, #1024]
    6d38:	97fff1f2 	bl	3500 <fwp_data.part.0.constprop.0>
    6d3c:	91144283 	add	x3, x20, #0x510
    6d40:	aa0003f5 	mov	x21, x0
    6d44:	f949d861 	ldr	x1, [x3, #5040]
    6d48:	f949ec60 	ldr	x0, [x3, #5080]
    6d4c:	cb0102a1 	sub	x1, x21, x1
    6d50:	eb00403f 	cmp	x1, x0, lsl #16
    6d54:	54000322 	b.cs	6db8 <f0+0xf58>  // b.hs, b.nlast
    6d58:	d350fc22 	lsr	x2, x1, #16
    6d5c:	f949fc63 	ldr	x3, [x3, #5112]
    6d60:	8b020842 	add	x2, x2, x2, lsl #2
    6d64:	d37df042 	lsl	x2, x2, #3
    6d68:	8b020060 	add	x0, x3, x2
    6d6c:	f9401017 	ldr	x23, [x0, #32]
    6d70:	b4000257 	cbz	x23, 6db8 <f0+0xf58>
    6d74:	38626862 	ldrb	w2, [x3, x2]
    6d78:	7100085f 	cmp	w2, #0x2
    6d7c:	5400a020 	b.eq	8180 <f0+0x2320>  // b.none
    6d80:	7100045f 	cmp	w2, #0x1
    6d84:	540001a1 	b.ne	6db8 <f0+0xf58>  // b.any
    6d88:	29430002 	ldp	w2, w0, [x0, #24]
    6d8c:	92403c21 	and	x1, x1, #0xffff
    6d90:	9b027c21 	mul	x1, x1, x2
    6d94:	d360fc21 	lsr	x1, x1, #32
    6d98:	eb00003f 	cmp	x1, x0
    6d9c:	540000e2 	b.cs	6db8 <f0+0xf58>  // b.hs, b.nlast
    6da0:	8b0102f7 	add	x23, x23, x1
    6da4:	394002e0 	ldrb	w0, [x23]
    6da8:	7103fc1f 	cmp	w0, #0xff
    6dac:	5400b0a0 	b.eq	83c0 <f0+0x2560>  // b.none
    6db0:	52800020 	mov	w0, #0x1                   	// #1
    6db4:	390002e0 	strb	w0, [x23]
    6db8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6dbc:	911023e1 	add	x1, sp, #0x408
    6dc0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6dc4:	52800020 	mov	w0, #0x1                   	// #1
    6dc8:	f90207e2 	str	x2, [sp, #1032]
    6dcc:	f9020bf5 	str	x21, [sp, #1040]
    6dd0:	97fff1cc 	bl	3500 <fwp_data.part.0.constprop.0>
    6dd4:	97fff133 	bl	32a0 <fwp_rc_fresh>
    6dd8:	aa0003e2 	mov	x2, x0
    6ddc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6de0:	911063e1 	add	x1, sp, #0x418
    6de4:	52800020 	mov	w0, #0x1                   	// #1
    6de8:	f9020fe3 	str	x3, [sp, #1048]
    6dec:	f90213e2 	str	x2, [sp, #1056]
    6df0:	97fff1c4 	bl	3500 <fwp_data.part.0.constprop.0>
    6df4:	91144283 	add	x3, x20, #0x510
    6df8:	aa0003f5 	mov	x21, x0
    6dfc:	f949d861 	ldr	x1, [x3, #5040]
    6e00:	f949ec60 	ldr	x0, [x3, #5080]
    6e04:	cb0102a1 	sub	x1, x21, x1
    6e08:	eb00403f 	cmp	x1, x0, lsl #16
    6e0c:	54000322 	b.cs	6e70 <f0+0x1010>  // b.hs, b.nlast
    6e10:	d350fc22 	lsr	x2, x1, #16
    6e14:	f949fc63 	ldr	x3, [x3, #5112]
    6e18:	8b020842 	add	x2, x2, x2, lsl #2
    6e1c:	d37df042 	lsl	x2, x2, #3
    6e20:	8b020060 	add	x0, x3, x2
    6e24:	f9401017 	ldr	x23, [x0, #32]
    6e28:	b4000257 	cbz	x23, 6e70 <f0+0x1010>
    6e2c:	38626862 	ldrb	w2, [x3, x2]
    6e30:	7100085f 	cmp	w2, #0x2
    6e34:	54009a00 	b.eq	8174 <f0+0x2314>  // b.none
    6e38:	7100045f 	cmp	w2, #0x1
    6e3c:	540001a1 	b.ne	6e70 <f0+0x1010>  // b.any
    6e40:	29430002 	ldp	w2, w0, [x0, #24]
    6e44:	92403c21 	and	x1, x1, #0xffff
    6e48:	9b027c21 	mul	x1, x1, x2
    6e4c:	d360fc21 	lsr	x1, x1, #32
    6e50:	eb00003f 	cmp	x1, x0
    6e54:	540000e2 	b.cs	6e70 <f0+0x1010>  // b.hs, b.nlast
    6e58:	8b0102f7 	add	x23, x23, x1
    6e5c:	394002e0 	ldrb	w0, [x23]
    6e60:	7103fc1f 	cmp	w0, #0xff
    6e64:	5400ab40 	b.eq	83cc <f0+0x256c>  // b.none
    6e68:	52800020 	mov	w0, #0x1                   	// #1
    6e6c:	390002e0 	strb	w0, [x23]
    6e70:	9110a3e1 	add	x1, sp, #0x428
    6e74:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6e78:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6e7c:	52800020 	mov	w0, #0x1                   	// #1
    6e80:	f90217f7 	str	x23, [sp, #1064]
    6e84:	f9021bf5 	str	x21, [sp, #1072]
    6e88:	97fff19e 	bl	3500 <fwp_data.part.0.constprop.0>
    6e8c:	97fff105 	bl	32a0 <fwp_rc_fresh>
    6e90:	aa0003e2 	mov	x2, x0
    6e94:	9110e3e1 	add	x1, sp, #0x438
    6e98:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6e9c:	52800020 	mov	w0, #0x1                   	// #1
    6ea0:	f9021ff5 	str	x21, [sp, #1080]
    6ea4:	f90223e2 	str	x2, [sp, #1088]
    6ea8:	97fff196 	bl	3500 <fwp_data.part.0.constprop.0>
    6eac:	97fff0fd 	bl	32a0 <fwp_rc_fresh>
    6eb0:	aa0003e2 	mov	x2, x0
    6eb4:	911123e1 	add	x1, sp, #0x448
    6eb8:	52800020 	mov	w0, #0x1                   	// #1
    6ebc:	f90227f7 	str	x23, [sp, #1096]
    6ec0:	f9022be2 	str	x2, [sp, #1104]
    6ec4:	97fff18f 	bl	3500 <fwp_data.part.0.constprop.0>
    6ec8:	97fff0f6 	bl	32a0 <fwp_rc_fresh>
    6ecc:	aa0003e2 	mov	x2, x0
    6ed0:	911163e1 	add	x1, sp, #0x458
    6ed4:	52800020 	mov	w0, #0x1                   	// #1
    6ed8:	f9022ff5 	str	x21, [sp, #1112]
    6edc:	f90233e2 	str	x2, [sp, #1120]
    6ee0:	97fff188 	bl	3500 <fwp_data.part.0.constprop.0>
    6ee4:	91144283 	add	x3, x20, #0x510
    6ee8:	aa0003f5 	mov	x21, x0
    6eec:	f949d861 	ldr	x1, [x3, #5040]
    6ef0:	f949ec60 	ldr	x0, [x3, #5080]
    6ef4:	cb0102a1 	sub	x1, x21, x1
    6ef8:	eb00403f 	cmp	x1, x0, lsl #16
    6efc:	54000322 	b.cs	6f60 <f0+0x1100>  // b.hs, b.nlast
    6f00:	d350fc22 	lsr	x2, x1, #16
    6f04:	f949fc63 	ldr	x3, [x3, #5112]
    6f08:	8b020842 	add	x2, x2, x2, lsl #2
    6f0c:	d37df042 	lsl	x2, x2, #3
    6f10:	8b020060 	add	x0, x3, x2
    6f14:	f9401017 	ldr	x23, [x0, #32]
    6f18:	b4000257 	cbz	x23, 6f60 <f0+0x1100>
    6f1c:	38626862 	ldrb	w2, [x3, x2]
    6f20:	7100085f 	cmp	w2, #0x2
    6f24:	54009220 	b.eq	8168 <f0+0x2308>  // b.none
    6f28:	7100045f 	cmp	w2, #0x1
    6f2c:	540001a1 	b.ne	6f60 <f0+0x1100>  // b.any
    6f30:	29430002 	ldp	w2, w0, [x0, #24]
    6f34:	92403c21 	and	x1, x1, #0xffff
    6f38:	9b027c21 	mul	x1, x1, x2
    6f3c:	d360fc21 	lsr	x1, x1, #32
    6f40:	eb00003f 	cmp	x1, x0
    6f44:	540000e2 	b.cs	6f60 <f0+0x1100>  // b.hs, b.nlast
    6f48:	8b0102f7 	add	x23, x23, x1
    6f4c:	394002e0 	ldrb	w0, [x23]
    6f50:	7103fc1f 	cmp	w0, #0xff
    6f54:	5400a420 	b.eq	83d8 <f0+0x2578>  // b.none
    6f58:	52800020 	mov	w0, #0x1                   	// #1
    6f5c:	390002e0 	strb	w0, [x23]
    6f60:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6f64:	9111a3e1 	add	x1, sp, #0x468
    6f68:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6f6c:	52800020 	mov	w0, #0x1                   	// #1
    6f70:	f90237e2 	str	x2, [sp, #1128]
    6f74:	f9023bf5 	str	x21, [sp, #1136]
    6f78:	97fff162 	bl	3500 <fwp_data.part.0.constprop.0>
    6f7c:	91144283 	add	x3, x20, #0x510
    6f80:	aa0003f5 	mov	x21, x0
    6f84:	f949d861 	ldr	x1, [x3, #5040]
    6f88:	f949ec60 	ldr	x0, [x3, #5080]
    6f8c:	cb0102a1 	sub	x1, x21, x1
    6f90:	eb00403f 	cmp	x1, x0, lsl #16
    6f94:	54000322 	b.cs	6ff8 <f0+0x1198>  // b.hs, b.nlast
    6f98:	d350fc22 	lsr	x2, x1, #16
    6f9c:	f949fc63 	ldr	x3, [x3, #5112]
    6fa0:	8b020842 	add	x2, x2, x2, lsl #2
    6fa4:	d37df042 	lsl	x2, x2, #3
    6fa8:	8b020060 	add	x0, x3, x2
    6fac:	f9401017 	ldr	x23, [x0, #32]
    6fb0:	b4000257 	cbz	x23, 6ff8 <f0+0x1198>
    6fb4:	38626862 	ldrb	w2, [x3, x2]
    6fb8:	7100085f 	cmp	w2, #0x2
    6fbc:	54008d00 	b.eq	815c <f0+0x22fc>  // b.none
    6fc0:	7100045f 	cmp	w2, #0x1
    6fc4:	540001a1 	b.ne	6ff8 <f0+0x1198>  // b.any
    6fc8:	29430002 	ldp	w2, w0, [x0, #24]
    6fcc:	92403c21 	and	x1, x1, #0xffff
    6fd0:	9b027c21 	mul	x1, x1, x2
    6fd4:	d360fc21 	lsr	x1, x1, #32
    6fd8:	eb00003f 	cmp	x1, x0
    6fdc:	540000e2 	b.cs	6ff8 <f0+0x1198>  // b.hs, b.nlast
    6fe0:	8b0102f7 	add	x23, x23, x1
    6fe4:	394002e0 	ldrb	w0, [x23]
    6fe8:	7103fc1f 	cmp	w0, #0xff
    6fec:	54009fc0 	b.eq	83e4 <f0+0x2584>  // b.none
    6ff0:	52800020 	mov	w0, #0x1                   	// #1
    6ff4:	390002e0 	strb	w0, [x23]
    6ff8:	9111e3e1 	add	x1, sp, #0x478
    6ffc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7000:	52800020 	mov	w0, #0x1                   	// #1
    7004:	f9023fe2 	str	x2, [sp, #1144]
    7008:	f90243f5 	str	x21, [sp, #1152]
    700c:	97fff13d 	bl	3500 <fwp_data.part.0.constprop.0>
    7010:	97fff0a4 	bl	32a0 <fwp_rc_fresh>
    7014:	aa0003e2 	mov	x2, x0
    7018:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    701c:	911223e1 	add	x1, sp, #0x488
    7020:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7024:	52800020 	mov	w0, #0x1                   	// #1
    7028:	f90247e3 	str	x3, [sp, #1160]
    702c:	f9024be2 	str	x2, [sp, #1168]
    7030:	97fff134 	bl	3500 <fwp_data.part.0.constprop.0>
    7034:	91144283 	add	x3, x20, #0x510
    7038:	aa0003f5 	mov	x21, x0
    703c:	f949d861 	ldr	x1, [x3, #5040]
    7040:	f949ec60 	ldr	x0, [x3, #5080]
    7044:	cb0102a1 	sub	x1, x21, x1
    7048:	eb00403f 	cmp	x1, x0, lsl #16
    704c:	54000322 	b.cs	70b0 <f0+0x1250>  // b.hs, b.nlast
    7050:	d350fc22 	lsr	x2, x1, #16
    7054:	f949fc63 	ldr	x3, [x3, #5112]
    7058:	8b020842 	add	x2, x2, x2, lsl #2
    705c:	d37df042 	lsl	x2, x2, #3
    7060:	8b020060 	add	x0, x3, x2
    7064:	f9401017 	ldr	x23, [x0, #32]
    7068:	b4000257 	cbz	x23, 70b0 <f0+0x1250>
    706c:	38626862 	ldrb	w2, [x3, x2]
    7070:	7100085f 	cmp	w2, #0x2
    7074:	540086e0 	b.eq	8150 <f0+0x22f0>  // b.none
    7078:	7100045f 	cmp	w2, #0x1
    707c:	540001a1 	b.ne	70b0 <f0+0x1250>  // b.any
    7080:	29430002 	ldp	w2, w0, [x0, #24]
    7084:	92403c21 	and	x1, x1, #0xffff
    7088:	9b027c21 	mul	x1, x1, x2
    708c:	d360fc21 	lsr	x1, x1, #32
    7090:	eb00003f 	cmp	x1, x0
    7094:	540000e2 	b.cs	70b0 <f0+0x1250>  // b.hs, b.nlast
    7098:	8b0102f7 	add	x23, x23, x1
    709c:	394002e0 	ldrb	w0, [x23]
    70a0:	7103fc1f 	cmp	w0, #0xff
    70a4:	54009a60 	b.eq	83f0 <f0+0x2590>  // b.none
    70a8:	52800020 	mov	w0, #0x1                   	// #1
    70ac:	390002e0 	strb	w0, [x23]
    70b0:	911263e1 	add	x1, sp, #0x498
    70b4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    70b8:	52800020 	mov	w0, #0x1                   	// #1
    70bc:	f9024ff7 	str	x23, [sp, #1176]
    70c0:	f90253f5 	str	x21, [sp, #1184]
    70c4:	97fff10f 	bl	3500 <fwp_data.part.0.constprop.0>
    70c8:	97fff076 	bl	32a0 <fwp_rc_fresh>
    70cc:	aa0003e2 	mov	x2, x0
    70d0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    70d4:	9112a3e1 	add	x1, sp, #0x4a8
    70d8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    70dc:	52800020 	mov	w0, #0x1                   	// #1
    70e0:	f90257e3 	str	x3, [sp, #1192]
    70e4:	f9025be2 	str	x2, [sp, #1200]
    70e8:	97fff106 	bl	3500 <fwp_data.part.0.constprop.0>
    70ec:	97fff06d 	bl	32a0 <fwp_rc_fresh>
    70f0:	aa0003e2 	mov	x2, x0
    70f4:	9112e3e1 	add	x1, sp, #0x4b8
    70f8:	52800020 	mov	w0, #0x1                   	// #1
    70fc:	f9025ff7 	str	x23, [sp, #1208]
    7100:	f90263e2 	str	x2, [sp, #1216]
    7104:	97fff0ff 	bl	3500 <fwp_data.part.0.constprop.0>
    7108:	91144283 	add	x3, x20, #0x510
    710c:	aa0003f5 	mov	x21, x0
    7110:	f949d861 	ldr	x1, [x3, #5040]
    7114:	f949ec60 	ldr	x0, [x3, #5080]
    7118:	cb0102a1 	sub	x1, x21, x1
    711c:	eb00403f 	cmp	x1, x0, lsl #16
    7120:	54000322 	b.cs	7184 <f0+0x1324>  // b.hs, b.nlast
    7124:	d350fc22 	lsr	x2, x1, #16
    7128:	f949fc63 	ldr	x3, [x3, #5112]
    712c:	8b020842 	add	x2, x2, x2, lsl #2
    7130:	d37df042 	lsl	x2, x2, #3
    7134:	8b020060 	add	x0, x3, x2
    7138:	f9401017 	ldr	x23, [x0, #32]
    713c:	b4000257 	cbz	x23, 7184 <f0+0x1324>
    7140:	38626862 	ldrb	w2, [x3, x2]
    7144:	7100085f 	cmp	w2, #0x2
    7148:	54007fe0 	b.eq	8144 <f0+0x22e4>  // b.none
    714c:	7100045f 	cmp	w2, #0x1
    7150:	540001a1 	b.ne	7184 <f0+0x1324>  // b.any
    7154:	29430002 	ldp	w2, w0, [x0, #24]
    7158:	92403c21 	and	x1, x1, #0xffff
    715c:	9b027c21 	mul	x1, x1, x2
    7160:	d360fc21 	lsr	x1, x1, #32
    7164:	eb00003f 	cmp	x1, x0
    7168:	540000e2 	b.cs	7184 <f0+0x1324>  // b.hs, b.nlast
    716c:	8b0102f7 	add	x23, x23, x1
    7170:	394002e0 	ldrb	w0, [x23]
    7174:	7103fc1f 	cmp	w0, #0xff
    7178:	54009420 	b.eq	83fc <f0+0x259c>  // b.none
    717c:	52800020 	mov	w0, #0x1                   	// #1
    7180:	390002e0 	strb	w0, [x23]
    7184:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7188:	911323e1 	add	x1, sp, #0x4c8
    718c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7190:	52800020 	mov	w0, #0x1                   	// #1
    7194:	f90267e2 	str	x2, [sp, #1224]
    7198:	f9026bf5 	str	x21, [sp, #1232]
    719c:	97fff0d9 	bl	3500 <fwp_data.part.0.constprop.0>
    71a0:	97fff040 	bl	32a0 <fwp_rc_fresh>
    71a4:	aa0003e2 	mov	x2, x0
    71a8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    71ac:	911363e1 	add	x1, sp, #0x4d8
    71b0:	52800020 	mov	w0, #0x1                   	// #1
    71b4:	f9026fe3 	str	x3, [sp, #1240]
    71b8:	f90273e2 	str	x2, [sp, #1248]
    71bc:	97fff0d1 	bl	3500 <fwp_data.part.0.constprop.0>
    71c0:	91144283 	add	x3, x20, #0x510
    71c4:	aa0003f5 	mov	x21, x0
    71c8:	f949d861 	ldr	x1, [x3, #5040]
    71cc:	f949ec60 	ldr	x0, [x3, #5080]
    71d0:	cb0102a1 	sub	x1, x21, x1
    71d4:	eb00403f 	cmp	x1, x0, lsl #16
    71d8:	54000322 	b.cs	723c <f0+0x13dc>  // b.hs, b.nlast
    71dc:	d350fc22 	lsr	x2, x1, #16
    71e0:	f949fc63 	ldr	x3, [x3, #5112]
    71e4:	8b020842 	add	x2, x2, x2, lsl #2
    71e8:	d37df042 	lsl	x2, x2, #3
    71ec:	8b020060 	add	x0, x3, x2
    71f0:	f9401017 	ldr	x23, [x0, #32]
    71f4:	b4000257 	cbz	x23, 723c <f0+0x13dc>
    71f8:	38626862 	ldrb	w2, [x3, x2]
    71fc:	7100085f 	cmp	w2, #0x2
    7200:	540079c0 	b.eq	8138 <f0+0x22d8>  // b.none
    7204:	7100045f 	cmp	w2, #0x1
    7208:	540001a1 	b.ne	723c <f0+0x13dc>  // b.any
    720c:	29430002 	ldp	w2, w0, [x0, #24]
    7210:	92403c21 	and	x1, x1, #0xffff
    7214:	9b027c21 	mul	x1, x1, x2
    7218:	d360fc21 	lsr	x1, x1, #32
    721c:	eb00003f 	cmp	x1, x0
    7220:	540000e2 	b.cs	723c <f0+0x13dc>  // b.hs, b.nlast
    7224:	8b0102f7 	add	x23, x23, x1
    7228:	394002e0 	ldrb	w0, [x23]
    722c:	7103fc1f 	cmp	w0, #0xff
    7230:	54008ec0 	b.eq	8408 <f0+0x25a8>  // b.none
    7234:	52800020 	mov	w0, #0x1                   	// #1
    7238:	390002e0 	strb	w0, [x23]
    723c:	9113a3e1 	add	x1, sp, #0x4e8
    7240:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7244:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7248:	52800020 	mov	w0, #0x1                   	// #1
    724c:	f90277f7 	str	x23, [sp, #1256]
    7250:	f9027bf5 	str	x21, [sp, #1264]
    7254:	97fff0ab 	bl	3500 <fwp_data.part.0.constprop.0>
    7258:	97fff012 	bl	32a0 <fwp_rc_fresh>
    725c:	aa0003e2 	mov	x2, x0
    7260:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7264:	9113e3e1 	add	x1, sp, #0x4f8
    7268:	52800020 	mov	w0, #0x1                   	// #1
    726c:	f9027fe3 	str	x3, [sp, #1272]
    7270:	f90283e2 	str	x2, [sp, #1280]
    7274:	97fff0a3 	bl	3500 <fwp_data.part.0.constprop.0>
    7278:	97fff00a 	bl	32a0 <fwp_rc_fresh>
    727c:	aa0003e2 	mov	x2, x0
    7280:	911423e1 	add	x1, sp, #0x508
    7284:	52800020 	mov	w0, #0x1                   	// #1
    7288:	f90287f7 	str	x23, [sp, #1288]
    728c:	f9028be2 	str	x2, [sp, #1296]
    7290:	97fff09c 	bl	3500 <fwp_data.part.0.constprop.0>
    7294:	91144283 	add	x3, x20, #0x510
    7298:	aa0003f5 	mov	x21, x0
    729c:	f949d861 	ldr	x1, [x3, #5040]
    72a0:	f949ec60 	ldr	x0, [x3, #5080]
    72a4:	cb0102a1 	sub	x1, x21, x1
    72a8:	eb00403f 	cmp	x1, x0, lsl #16
    72ac:	54000322 	b.cs	7310 <f0+0x14b0>  // b.hs, b.nlast
    72b0:	d350fc22 	lsr	x2, x1, #16
    72b4:	f949fc63 	ldr	x3, [x3, #5112]
    72b8:	8b020842 	add	x2, x2, x2, lsl #2
    72bc:	d37df042 	lsl	x2, x2, #3
    72c0:	8b020060 	add	x0, x3, x2
    72c4:	f9401017 	ldr	x23, [x0, #32]
    72c8:	b4000257 	cbz	x23, 7310 <f0+0x14b0>
    72cc:	38626862 	ldrb	w2, [x3, x2]
    72d0:	7100085f 	cmp	w2, #0x2
    72d4:	540072c0 	b.eq	812c <f0+0x22cc>  // b.none
    72d8:	7100045f 	cmp	w2, #0x1
    72dc:	540001a1 	b.ne	7310 <f0+0x14b0>  // b.any
    72e0:	29430002 	ldp	w2, w0, [x0, #24]
    72e4:	92403c21 	and	x1, x1, #0xffff
    72e8:	9b027c21 	mul	x1, x1, x2
    72ec:	d360fc21 	lsr	x1, x1, #32
    72f0:	eb00003f 	cmp	x1, x0
    72f4:	540000e2 	b.cs	7310 <f0+0x14b0>  // b.hs, b.nlast
    72f8:	8b0102f7 	add	x23, x23, x1
    72fc:	394002e0 	ldrb	w0, [x23]
    7300:	7103fc1f 	cmp	w0, #0xff
    7304:	54008880 	b.eq	8414 <f0+0x25b4>  // b.none
    7308:	52800020 	mov	w0, #0x1                   	// #1
    730c:	390002e0 	strb	w0, [x23]
    7310:	911463e1 	add	x1, sp, #0x518
    7314:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7318:	52800020 	mov	w0, #0x1                   	// #1
    731c:	f9028ff7 	str	x23, [sp, #1304]
    7320:	f90293f5 	str	x21, [sp, #1312]
    7324:	97fff077 	bl	3500 <fwp_data.part.0.constprop.0>
    7328:	97ffefde 	bl	32a0 <fwp_rc_fresh>
    732c:	aa0003e2 	mov	x2, x0
    7330:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7334:	9114a3e1 	add	x1, sp, #0x528
    7338:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    733c:	52800020 	mov	w0, #0x1                   	// #1
    7340:	f90297e3 	str	x3, [sp, #1320]
    7344:	f9029be2 	str	x2, [sp, #1328]
    7348:	97fff06e 	bl	3500 <fwp_data.part.0.constprop.0>
    734c:	97ffefd5 	bl	32a0 <fwp_rc_fresh>
    7350:	aa0003e2 	mov	x2, x0
    7354:	9114e3e1 	add	x1, sp, #0x538
    7358:	52800020 	mov	w0, #0x1                   	// #1
    735c:	f9029ff7 	str	x23, [sp, #1336]
    7360:	f902a3e2 	str	x2, [sp, #1344]
    7364:	97fff067 	bl	3500 <fwp_data.part.0.constprop.0>
    7368:	91144283 	add	x3, x20, #0x510
    736c:	aa0003f5 	mov	x21, x0
    7370:	f949d861 	ldr	x1, [x3, #5040]
    7374:	f949ec60 	ldr	x0, [x3, #5080]
    7378:	cb0102a1 	sub	x1, x21, x1
    737c:	eb00403f 	cmp	x1, x0, lsl #16
    7380:	54000322 	b.cs	73e4 <f0+0x1584>  // b.hs, b.nlast
    7384:	d350fc22 	lsr	x2, x1, #16
    7388:	f949fc63 	ldr	x3, [x3, #5112]
    738c:	8b020842 	add	x2, x2, x2, lsl #2
    7390:	d37df042 	lsl	x2, x2, #3
    7394:	8b020060 	add	x0, x3, x2
    7398:	f9401017 	ldr	x23, [x0, #32]
    739c:	b4000257 	cbz	x23, 73e4 <f0+0x1584>
    73a0:	38626862 	ldrb	w2, [x3, x2]
    73a4:	7100085f 	cmp	w2, #0x2
    73a8:	54007a60 	b.eq	82f4 <f0+0x2494>  // b.none
    73ac:	7100045f 	cmp	w2, #0x1
    73b0:	540001a1 	b.ne	73e4 <f0+0x1584>  // b.any
    73b4:	29430002 	ldp	w2, w0, [x0, #24]
    73b8:	92403c21 	and	x1, x1, #0xffff
    73bc:	9b027c21 	mul	x1, x1, x2
    73c0:	d360fc21 	lsr	x1, x1, #32
    73c4:	eb00003f 	cmp	x1, x0
    73c8:	540000e2 	b.cs	73e4 <f0+0x1584>  // b.hs, b.nlast
    73cc:	8b0102f7 	add	x23, x23, x1
    73d0:	394002e0 	ldrb	w0, [x23]
    73d4:	7103fc1f 	cmp	w0, #0xff
    73d8:	54008240 	b.eq	8420 <f0+0x25c0>  // b.none
    73dc:	52800020 	mov	w0, #0x1                   	// #1
    73e0:	390002e0 	strb	w0, [x23]
    73e4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    73e8:	911523e1 	add	x1, sp, #0x548
    73ec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    73f0:	52800020 	mov	w0, #0x1                   	// #1
    73f4:	f902a7e2 	str	x2, [sp, #1352]
    73f8:	f902abf5 	str	x21, [sp, #1360]
    73fc:	97fff041 	bl	3500 <fwp_data.part.0.constprop.0>
    7400:	97ffefa8 	bl	32a0 <fwp_rc_fresh>
    7404:	aa0003e2 	mov	x2, x0
    7408:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    740c:	911563e1 	add	x1, sp, #0x558
    7410:	52800020 	mov	w0, #0x1                   	// #1
    7414:	f902afe3 	str	x3, [sp, #1368]
    7418:	f902b3e2 	str	x2, [sp, #1376]
    741c:	97fff039 	bl	3500 <fwp_data.part.0.constprop.0>
    7420:	91144283 	add	x3, x20, #0x510
    7424:	aa0003f5 	mov	x21, x0
    7428:	f949d861 	ldr	x1, [x3, #5040]
    742c:	f949ec60 	ldr	x0, [x3, #5080]
    7430:	cb0102a1 	sub	x1, x21, x1
    7434:	eb00403f 	cmp	x1, x0, lsl #16
    7438:	54000322 	b.cs	749c <f0+0x163c>  // b.hs, b.nlast
    743c:	d350fc22 	lsr	x2, x1, #16
    7440:	f949fc63 	ldr	x3, [x3, #5112]
    7444:	8b020842 	add	x2, x2, x2, lsl #2
    7448:	d37df042 	lsl	x2, x2, #3
    744c:	8b020060 	add	x0, x3, x2
    7450:	f9401017 	ldr	x23, [x0, #32]
    7454:	b4000257 	cbz	x23, 749c <f0+0x163c>
    7458:	38626862 	ldrb	w2, [x3, x2]
    745c:	7100085f 	cmp	w2, #0x2
    7460:	54007440 	b.eq	82e8 <f0+0x2488>  // b.none
    7464:	7100045f 	cmp	w2, #0x1
    7468:	540001a1 	b.ne	749c <f0+0x163c>  // b.any
    746c:	29430002 	ldp	w2, w0, [x0, #24]
    7470:	92403c21 	and	x1, x1, #0xffff
    7474:	9b027c21 	mul	x1, x1, x2
    7478:	d360fc21 	lsr	x1, x1, #32
    747c:	eb00003f 	cmp	x1, x0
    7480:	540000e2 	b.cs	749c <f0+0x163c>  // b.hs, b.nlast
    7484:	8b0102f7 	add	x23, x23, x1
    7488:	394002e0 	ldrb	w0, [x23]
    748c:	7103fc1f 	cmp	w0, #0xff
    7490:	54007ce0 	b.eq	842c <f0+0x25cc>  // b.none
    7494:	52800020 	mov	w0, #0x1                   	// #1
    7498:	390002e0 	strb	w0, [x23]
    749c:	9115a3e1 	add	x1, sp, #0x568
    74a0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    74a4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    74a8:	52800020 	mov	w0, #0x1                   	// #1
    74ac:	f902b7f7 	str	x23, [sp, #1384]
    74b0:	f902bbf5 	str	x21, [sp, #1392]
    74b4:	97fff013 	bl	3500 <fwp_data.part.0.constprop.0>
    74b8:	97ffef7a 	bl	32a0 <fwp_rc_fresh>
    74bc:	aa0003e2 	mov	x2, x0
    74c0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    74c4:	9115e3e1 	add	x1, sp, #0x578
    74c8:	52800020 	mov	w0, #0x1                   	// #1
    74cc:	f902bfe3 	str	x3, [sp, #1400]
    74d0:	f902c3e2 	str	x2, [sp, #1408]
    74d4:	97fff00b 	bl	3500 <fwp_data.part.0.constprop.0>
    74d8:	97ffef72 	bl	32a0 <fwp_rc_fresh>
    74dc:	aa0003e2 	mov	x2, x0
    74e0:	911623e1 	add	x1, sp, #0x588
    74e4:	52800020 	mov	w0, #0x1                   	// #1
    74e8:	f902c7f7 	str	x23, [sp, #1416]
    74ec:	f902cbe2 	str	x2, [sp, #1424]
    74f0:	97fff004 	bl	3500 <fwp_data.part.0.constprop.0>
    74f4:	91144283 	add	x3, x20, #0x510
    74f8:	aa0003f5 	mov	x21, x0
    74fc:	f949d861 	ldr	x1, [x3, #5040]
    7500:	f949ec60 	ldr	x0, [x3, #5080]
    7504:	cb0102a1 	sub	x1, x21, x1
    7508:	eb00403f 	cmp	x1, x0, lsl #16
    750c:	54000322 	b.cs	7570 <f0+0x1710>  // b.hs, b.nlast
    7510:	d350fc22 	lsr	x2, x1, #16
    7514:	f949fc63 	ldr	x3, [x3, #5112]
    7518:	8b020842 	add	x2, x2, x2, lsl #2
    751c:	d37df042 	lsl	x2, x2, #3
    7520:	8b020060 	add	x0, x3, x2
    7524:	f9401017 	ldr	x23, [x0, #32]
    7528:	b4000257 	cbz	x23, 7570 <f0+0x1710>
    752c:	38626862 	ldrb	w2, [x3, x2]
    7530:	7100085f 	cmp	w2, #0x2
    7534:	54006d40 	b.eq	82dc <f0+0x247c>  // b.none
    7538:	7100045f 	cmp	w2, #0x1
    753c:	540001a1 	b.ne	7570 <f0+0x1710>  // b.any
    7540:	29430002 	ldp	w2, w0, [x0, #24]
    7544:	92403c21 	and	x1, x1, #0xffff
    7548:	9b027c21 	mul	x1, x1, x2
    754c:	d360fc21 	lsr	x1, x1, #32
    7550:	eb00003f 	cmp	x1, x0
    7554:	540000e2 	b.cs	7570 <f0+0x1710>  // b.hs, b.nlast
    7558:	8b0102f7 	add	x23, x23, x1
    755c:	394002e0 	ldrb	w0, [x23]
    7560:	7103fc1f 	cmp	w0, #0xff
    7564:	540076a0 	b.eq	8438 <f0+0x25d8>  // b.none
    7568:	52800020 	mov	w0, #0x1                   	// #1
    756c:	390002e0 	strb	w0, [x23]
    7570:	911663e1 	add	x1, sp, #0x598
    7574:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7578:	52800020 	mov	w0, #0x1                   	// #1
    757c:	f902cff7 	str	x23, [sp, #1432]
    7580:	f902d3f5 	str	x21, [sp, #1440]
    7584:	97ffefdf 	bl	3500 <fwp_data.part.0.constprop.0>
    7588:	97ffef46 	bl	32a0 <fwp_rc_fresh>
    758c:	aa0003e2 	mov	x2, x0
    7590:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7594:	9116a3e1 	add	x1, sp, #0x5a8
    7598:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    759c:	52800020 	mov	w0, #0x1                   	// #1
    75a0:	f902d7e3 	str	x3, [sp, #1448]
    75a4:	f902dbe2 	str	x2, [sp, #1456]
    75a8:	97ffefd6 	bl	3500 <fwp_data.part.0.constprop.0>
    75ac:	97ffef3d 	bl	32a0 <fwp_rc_fresh>
    75b0:	aa0003e2 	mov	x2, x0
    75b4:	9116e3e1 	add	x1, sp, #0x5b8
    75b8:	52800020 	mov	w0, #0x1                   	// #1
    75bc:	f902dff7 	str	x23, [sp, #1464]
    75c0:	f902e3e2 	str	x2, [sp, #1472]
    75c4:	97ffefcf 	bl	3500 <fwp_data.part.0.constprop.0>
    75c8:	91144283 	add	x3, x20, #0x510
    75cc:	aa0003f5 	mov	x21, x0
    75d0:	f949d861 	ldr	x1, [x3, #5040]
    75d4:	f949ec60 	ldr	x0, [x3, #5080]
    75d8:	cb0102a1 	sub	x1, x21, x1
    75dc:	eb00403f 	cmp	x1, x0, lsl #16
    75e0:	54000322 	b.cs	7644 <f0+0x17e4>  // b.hs, b.nlast
    75e4:	d350fc22 	lsr	x2, x1, #16
    75e8:	f949fc63 	ldr	x3, [x3, #5112]
    75ec:	8b020842 	add	x2, x2, x2, lsl #2
    75f0:	d37df042 	lsl	x2, x2, #3
    75f4:	8b020060 	add	x0, x3, x2
    75f8:	f9401017 	ldr	x23, [x0, #32]
    75fc:	b4000257 	cbz	x23, 7644 <f0+0x17e4>
    7600:	38626862 	ldrb	w2, [x3, x2]
    7604:	7100085f 	cmp	w2, #0x2
    7608:	54006640 	b.eq	82d0 <f0+0x2470>  // b.none
    760c:	7100045f 	cmp	w2, #0x1
    7610:	540001a1 	b.ne	7644 <f0+0x17e4>  // b.any
    7614:	29430002 	ldp	w2, w0, [x0, #24]
    7618:	92403c21 	and	x1, x1, #0xffff
    761c:	9b027c21 	mul	x1, x1, x2
    7620:	d360fc21 	lsr	x1, x1, #32
    7624:	eb00003f 	cmp	x1, x0
    7628:	540000e2 	b.cs	7644 <f0+0x17e4>  // b.hs, b.nlast
    762c:	8b0102f7 	add	x23, x23, x1
    7630:	394002e0 	ldrb	w0, [x23]
    7634:	7103fc1f 	cmp	w0, #0xff
    7638:	54007060 	b.eq	8444 <f0+0x25e4>  // b.none
    763c:	52800020 	mov	w0, #0x1                   	// #1
    7640:	390002e0 	strb	w0, [x23]
    7644:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7648:	911723e1 	add	x1, sp, #0x5c8
    764c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7650:	52800020 	mov	w0, #0x1                   	// #1
    7654:	f902e7e2 	str	x2, [sp, #1480]
    7658:	f902ebf5 	str	x21, [sp, #1488]
    765c:	97ffefa9 	bl	3500 <fwp_data.part.0.constprop.0>
    7660:	97ffef10 	bl	32a0 <fwp_rc_fresh>
    7664:	aa0003e2 	mov	x2, x0
    7668:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    766c:	911763e1 	add	x1, sp, #0x5d8
    7670:	52800020 	mov	w0, #0x1                   	// #1
    7674:	f902efe3 	str	x3, [sp, #1496]
    7678:	f902f3e2 	str	x2, [sp, #1504]
    767c:	97ffefa1 	bl	3500 <fwp_data.part.0.constprop.0>
    7680:	91144283 	add	x3, x20, #0x510
    7684:	aa0003f5 	mov	x21, x0
    7688:	f949d861 	ldr	x1, [x3, #5040]
    768c:	f949ec60 	ldr	x0, [x3, #5080]
    7690:	cb0102a1 	sub	x1, x21, x1
    7694:	eb00403f 	cmp	x1, x0, lsl #16
    7698:	54000322 	b.cs	76fc <f0+0x189c>  // b.hs, b.nlast
    769c:	d350fc22 	lsr	x2, x1, #16
    76a0:	f949fc63 	ldr	x3, [x3, #5112]
    76a4:	8b020842 	add	x2, x2, x2, lsl #2
    76a8:	d37df042 	lsl	x2, x2, #3
    76ac:	8b020060 	add	x0, x3, x2
    76b0:	f9401017 	ldr	x23, [x0, #32]
    76b4:	b4000257 	cbz	x23, 76fc <f0+0x189c>
    76b8:	38626862 	ldrb	w2, [x3, x2]
    76bc:	7100085f 	cmp	w2, #0x2
    76c0:	54006020 	b.eq	82c4 <f0+0x2464>  // b.none
    76c4:	7100045f 	cmp	w2, #0x1
    76c8:	540001a1 	b.ne	76fc <f0+0x189c>  // b.any
    76cc:	29430002 	ldp	w2, w0, [x0, #24]
    76d0:	92403c21 	and	x1, x1, #0xffff
    76d4:	9b027c21 	mul	x1, x1, x2
    76d8:	d360fc21 	lsr	x1, x1, #32
    76dc:	eb00003f 	cmp	x1, x0
    76e0:	540000e2 	b.cs	76fc <f0+0x189c>  // b.hs, b.nlast
    76e4:	8b0102f7 	add	x23, x23, x1
    76e8:	394002e0 	ldrb	w0, [x23]
    76ec:	7103fc1f 	cmp	w0, #0xff
    76f0:	54006b00 	b.eq	8450 <f0+0x25f0>  // b.none
    76f4:	52800020 	mov	w0, #0x1                   	// #1
    76f8:	390002e0 	strb	w0, [x23]
    76fc:	9117a3e1 	add	x1, sp, #0x5e8
    7700:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7704:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7708:	52800020 	mov	w0, #0x1                   	// #1
    770c:	f902f7f7 	str	x23, [sp, #1512]
    7710:	f902fbf5 	str	x21, [sp, #1520]
    7714:	97ffef7b 	bl	3500 <fwp_data.part.0.constprop.0>
    7718:	97ffeee2 	bl	32a0 <fwp_rc_fresh>
    771c:	aa0003e2 	mov	x2, x0
    7720:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7724:	9117e3e1 	add	x1, sp, #0x5f8
    7728:	52800020 	mov	w0, #0x1                   	// #1
    772c:	f902ffe3 	str	x3, [sp, #1528]
    7730:	f90303e2 	str	x2, [sp, #1536]
    7734:	97ffef73 	bl	3500 <fwp_data.part.0.constprop.0>
    7738:	97ffeeda 	bl	32a0 <fwp_rc_fresh>
    773c:	aa0003e2 	mov	x2, x0
    7740:	911823e1 	add	x1, sp, #0x608
    7744:	52800020 	mov	w0, #0x1                   	// #1
    7748:	f90307f7 	str	x23, [sp, #1544]
    774c:	f9030be2 	str	x2, [sp, #1552]
    7750:	97ffef6c 	bl	3500 <fwp_data.part.0.constprop.0>
    7754:	91144283 	add	x3, x20, #0x510
    7758:	aa0003f5 	mov	x21, x0
    775c:	f949d861 	ldr	x1, [x3, #5040]
    7760:	f949ec60 	ldr	x0, [x3, #5080]
    7764:	cb0102a1 	sub	x1, x21, x1
    7768:	eb00403f 	cmp	x1, x0, lsl #16
    776c:	54000322 	b.cs	77d0 <f0+0x1970>  // b.hs, b.nlast
    7770:	d350fc22 	lsr	x2, x1, #16
    7774:	f949fc63 	ldr	x3, [x3, #5112]
    7778:	8b020842 	add	x2, x2, x2, lsl #2
    777c:	d37df042 	lsl	x2, x2, #3
    7780:	8b020060 	add	x0, x3, x2
    7784:	f9401017 	ldr	x23, [x0, #32]
    7788:	b4000257 	cbz	x23, 77d0 <f0+0x1970>
    778c:	38626862 	ldrb	w2, [x3, x2]
    7790:	7100085f 	cmp	w2, #0x2
    7794:	54005920 	b.eq	82b8 <f0+0x2458>  // b.none
    7798:	7100045f 	cmp	w2, #0x1
    779c:	540001a1 	b.ne	77d0 <f0+0x1970>  // b.any
    77a0:	29430002 	ldp	w2, w0, [x0, #24]
    77a4:	92403c21 	and	x1, x1, #0xffff
    77a8:	9b027c21 	mul	x1, x1, x2
    77ac:	d360fc21 	lsr	x1, x1, #32
    77b0:	eb00003f 	cmp	x1, x0
    77b4:	540000e2 	b.cs	77d0 <f0+0x1970>  // b.hs, b.nlast
    77b8:	8b0102f7 	add	x23, x23, x1
    77bc:	394002e0 	ldrb	w0, [x23]
    77c0:	7103fc1f 	cmp	w0, #0xff
    77c4:	540064c0 	b.eq	845c <f0+0x25fc>  // b.none
    77c8:	52800020 	mov	w0, #0x1                   	// #1
    77cc:	390002e0 	strb	w0, [x23]
    77d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    77d4:	911863e1 	add	x1, sp, #0x618
    77d8:	52800020 	mov	w0, #0x1                   	// #1
    77dc:	f9030fe2 	str	x2, [sp, #1560]
    77e0:	f90313f5 	str	x21, [sp, #1568]
    77e4:	97ffef47 	bl	3500 <fwp_data.part.0.constprop.0>
    77e8:	91144283 	add	x3, x20, #0x510
    77ec:	aa0003f5 	mov	x21, x0
    77f0:	f949d861 	ldr	x1, [x3, #5040]
    77f4:	f949ec60 	ldr	x0, [x3, #5080]
    77f8:	cb0102a1 	sub	x1, x21, x1
    77fc:	eb00403f 	cmp	x1, x0, lsl #16
    7800:	54000322 	b.cs	7864 <f0+0x1a04>  // b.hs, b.nlast
    7804:	d350fc22 	lsr	x2, x1, #16
    7808:	f949fc63 	ldr	x3, [x3, #5112]
    780c:	8b020842 	add	x2, x2, x2, lsl #2
    7810:	d37df042 	lsl	x2, x2, #3
    7814:	8b020060 	add	x0, x3, x2
    7818:	f9401017 	ldr	x23, [x0, #32]
    781c:	b4000257 	cbz	x23, 7864 <f0+0x1a04>
    7820:	38626862 	ldrb	w2, [x3, x2]
    7824:	7100085f 	cmp	w2, #0x2
    7828:	54005420 	b.eq	82ac <f0+0x244c>  // b.none
    782c:	7100045f 	cmp	w2, #0x1
    7830:	540001a1 	b.ne	7864 <f0+0x1a04>  // b.any
    7834:	29430002 	ldp	w2, w0, [x0, #24]
    7838:	92403c21 	and	x1, x1, #0xffff
    783c:	9b027c21 	mul	x1, x1, x2
    7840:	d360fc21 	lsr	x1, x1, #32
    7844:	eb00003f 	cmp	x1, x0
    7848:	540000e2 	b.cs	7864 <f0+0x1a04>  // b.hs, b.nlast
    784c:	8b0102f7 	add	x23, x23, x1
    7850:	394002e0 	ldrb	w0, [x23]
    7854:	7103fc1f 	cmp	w0, #0xff
    7858:	54006080 	b.eq	8468 <f0+0x2608>  // b.none
    785c:	52800020 	mov	w0, #0x1                   	// #1
    7860:	390002e0 	strb	w0, [x23]
    7864:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7868:	9118a3e1 	add	x1, sp, #0x628
    786c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7870:	52800020 	mov	w0, #0x1                   	// #1
    7874:	f90317e2 	str	x2, [sp, #1576]
    7878:	f9031bf5 	str	x21, [sp, #1584]
    787c:	97ffef21 	bl	3500 <fwp_data.part.0.constprop.0>
    7880:	97ffee88 	bl	32a0 <fwp_rc_fresh>
    7884:	aa0003e2 	mov	x2, x0
    7888:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    788c:	9118e3e1 	add	x1, sp, #0x638
    7890:	52800020 	mov	w0, #0x1                   	// #1
    7894:	f9031fe3 	str	x3, [sp, #1592]
    7898:	f90323e2 	str	x2, [sp, #1600]
    789c:	97ffef19 	bl	3500 <fwp_data.part.0.constprop.0>
    78a0:	91144283 	add	x3, x20, #0x510
    78a4:	aa0003f5 	mov	x21, x0
    78a8:	f949d861 	ldr	x1, [x3, #5040]
    78ac:	f949ec60 	ldr	x0, [x3, #5080]
    78b0:	cb0102a1 	sub	x1, x21, x1
    78b4:	eb00403f 	cmp	x1, x0, lsl #16
    78b8:	54000322 	b.cs	791c <f0+0x1abc>  // b.hs, b.nlast
    78bc:	d350fc22 	lsr	x2, x1, #16
    78c0:	f949fc63 	ldr	x3, [x3, #5112]
    78c4:	8b020842 	add	x2, x2, x2, lsl #2
    78c8:	d37df042 	lsl	x2, x2, #3
    78cc:	8b020060 	add	x0, x3, x2
    78d0:	f9401017 	ldr	x23, [x0, #32]
    78d4:	b4000257 	cbz	x23, 791c <f0+0x1abc>
    78d8:	38626862 	ldrb	w2, [x3, x2]
    78dc:	7100085f 	cmp	w2, #0x2
    78e0:	54004e00 	b.eq	82a0 <f0+0x2440>  // b.none
    78e4:	7100045f 	cmp	w2, #0x1
    78e8:	540001a1 	b.ne	791c <f0+0x1abc>  // b.any
    78ec:	29430002 	ldp	w2, w0, [x0, #24]
    78f0:	92403c21 	and	x1, x1, #0xffff
    78f4:	9b027c21 	mul	x1, x1, x2
    78f8:	d360fc21 	lsr	x1, x1, #32
    78fc:	eb00003f 	cmp	x1, x0
    7900:	540000e2 	b.cs	791c <f0+0x1abc>  // b.hs, b.nlast
    7904:	8b0102f7 	add	x23, x23, x1
    7908:	394002e0 	ldrb	w0, [x23]
    790c:	7103fc1f 	cmp	w0, #0xff
    7910:	54005b20 	b.eq	8474 <f0+0x2614>  // b.none
    7914:	52800020 	mov	w0, #0x1                   	// #1
    7918:	390002e0 	strb	w0, [x23]
    791c:	911923e1 	add	x1, sp, #0x648
    7920:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7924:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7928:	52800020 	mov	w0, #0x1                   	// #1
    792c:	f90327f7 	str	x23, [sp, #1608]
    7930:	f9032bf5 	str	x21, [sp, #1616]
    7934:	97ffeef3 	bl	3500 <fwp_data.part.0.constprop.0>
    7938:	97ffee5a 	bl	32a0 <fwp_rc_fresh>
    793c:	aa0003e2 	mov	x2, x0
    7940:	911963e1 	add	x1, sp, #0x658
    7944:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7948:	52800020 	mov	w0, #0x1                   	// #1
    794c:	f9032ff5 	str	x21, [sp, #1624]
    7950:	f90333e2 	str	x2, [sp, #1632]
    7954:	97ffeeeb 	bl	3500 <fwp_data.part.0.constprop.0>
    7958:	97ffee52 	bl	32a0 <fwp_rc_fresh>
    795c:	aa0003e2 	mov	x2, x0
    7960:	9119a3e1 	add	x1, sp, #0x668
    7964:	52800020 	mov	w0, #0x1                   	// #1
    7968:	f90337f7 	str	x23, [sp, #1640]
    796c:	f9033be2 	str	x2, [sp, #1648]
    7970:	97ffeee4 	bl	3500 <fwp_data.part.0.constprop.0>
    7974:	97ffee4b 	bl	32a0 <fwp_rc_fresh>
    7978:	aa0003e2 	mov	x2, x0
    797c:	9119e3e1 	add	x1, sp, #0x678
    7980:	52800020 	mov	w0, #0x1                   	// #1
    7984:	f9033ff5 	str	x21, [sp, #1656]
    7988:	f90343e2 	str	x2, [sp, #1664]
    798c:	97ffeedd 	bl	3500 <fwp_data.part.0.constprop.0>
    7990:	97ffee44 	bl	32a0 <fwp_rc_fresh>
    7994:	aa0003e2 	mov	x2, x0
    7998:	911a23e1 	add	x1, sp, #0x688
    799c:	52800020 	mov	w0, #0x1                   	// #1
    79a0:	f90347f7 	str	x23, [sp, #1672]
    79a4:	f9034be2 	str	x2, [sp, #1680]
    79a8:	97ffeed6 	bl	3500 <fwp_data.part.0.constprop.0>
    79ac:	91144283 	add	x3, x20, #0x510
    79b0:	aa0003f5 	mov	x21, x0
    79b4:	f949d861 	ldr	x1, [x3, #5040]
    79b8:	f949ec60 	ldr	x0, [x3, #5080]
    79bc:	cb0102a1 	sub	x1, x21, x1
    79c0:	eb00403f 	cmp	x1, x0, lsl #16
    79c4:	54000322 	b.cs	7a28 <f0+0x1bc8>  // b.hs, b.nlast
    79c8:	d350fc22 	lsr	x2, x1, #16
    79cc:	f949fc63 	ldr	x3, [x3, #5112]
    79d0:	8b020842 	add	x2, x2, x2, lsl #2
    79d4:	d37df042 	lsl	x2, x2, #3
    79d8:	8b020060 	add	x0, x3, x2
    79dc:	f9401017 	ldr	x23, [x0, #32]
    79e0:	b4000257 	cbz	x23, 7a28 <f0+0x1bc8>
    79e4:	38626862 	ldrb	w2, [x3, x2]
    79e8:	7100085f 	cmp	w2, #0x2
    79ec:	54004540 	b.eq	8294 <f0+0x2434>  // b.none
    79f0:	7100045f 	cmp	w2, #0x1
    79f4:	540001a1 	b.ne	7a28 <f0+0x1bc8>  // b.any
    79f8:	29430002 	ldp	w2, w0, [x0, #24]
    79fc:	92403c21 	and	x1, x1, #0xffff
    7a00:	9b027c21 	mul	x1, x1, x2
    7a04:	d360fc21 	lsr	x1, x1, #32
    7a08:	eb00003f 	cmp	x1, x0
    7a0c:	540000e2 	b.cs	7a28 <f0+0x1bc8>  // b.hs, b.nlast
    7a10:	8b0102f7 	add	x23, x23, x1
    7a14:	394002e0 	ldrb	w0, [x23]
    7a18:	7103fc1f 	cmp	w0, #0xff
    7a1c:	54005320 	b.eq	8480 <f0+0x2620>  // b.none
    7a20:	52800020 	mov	w0, #0x1                   	// #1
    7a24:	390002e0 	strb	w0, [x23]
    7a28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7a2c:	911a63e1 	add	x1, sp, #0x698
    7a30:	52800020 	mov	w0, #0x1                   	// #1
    7a34:	f9034fe2 	str	x2, [sp, #1688]
    7a38:	f90353f5 	str	x21, [sp, #1696]
    7a3c:	97ffeeb1 	bl	3500 <fwp_data.part.0.constprop.0>
    7a40:	91144283 	add	x3, x20, #0x510
    7a44:	aa0003f5 	mov	x21, x0
    7a48:	f949d861 	ldr	x1, [x3, #5040]
    7a4c:	f949ec60 	ldr	x0, [x3, #5080]
    7a50:	cb0102a1 	sub	x1, x21, x1
    7a54:	eb00403f 	cmp	x1, x0, lsl #16
    7a58:	54000322 	b.cs	7abc <f0+0x1c5c>  // b.hs, b.nlast
    7a5c:	d350fc22 	lsr	x2, x1, #16
    7a60:	f949fc63 	ldr	x3, [x3, #5112]
    7a64:	8b020842 	add	x2, x2, x2, lsl #2
    7a68:	d37df042 	lsl	x2, x2, #3
    7a6c:	8b020060 	add	x0, x3, x2
    7a70:	f9401017 	ldr	x23, [x0, #32]
    7a74:	b4000257 	cbz	x23, 7abc <f0+0x1c5c>
    7a78:	38626862 	ldrb	w2, [x3, x2]
    7a7c:	7100085f 	cmp	w2, #0x2
    7a80:	54004040 	b.eq	8288 <f0+0x2428>  // b.none
    7a84:	7100045f 	cmp	w2, #0x1
    7a88:	540001a1 	b.ne	7abc <f0+0x1c5c>  // b.any
    7a8c:	29430002 	ldp	w2, w0, [x0, #24]
    7a90:	92403c21 	and	x1, x1, #0xffff
    7a94:	9b027c21 	mul	x1, x1, x2
    7a98:	d360fc21 	lsr	x1, x1, #32
    7a9c:	eb00003f 	cmp	x1, x0
    7aa0:	540000e2 	b.cs	7abc <f0+0x1c5c>  // b.hs, b.nlast
    7aa4:	8b0102f7 	add	x23, x23, x1
    7aa8:	394002e0 	ldrb	w0, [x23]
    7aac:	7103fc1f 	cmp	w0, #0xff
    7ab0:	54004ee0 	b.eq	848c <f0+0x262c>  // b.none
    7ab4:	52800020 	mov	w0, #0x1                   	// #1
    7ab8:	390002e0 	strb	w0, [x23]
    7abc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7ac0:	911aa3e1 	add	x1, sp, #0x6a8
    7ac4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7ac8:	52800020 	mov	w0, #0x1                   	// #1
    7acc:	f90357e2 	str	x2, [sp, #1704]
    7ad0:	f9035bf5 	str	x21, [sp, #1712]
    7ad4:	97ffee8b 	bl	3500 <fwp_data.part.0.constprop.0>
    7ad8:	97ffedf2 	bl	32a0 <fwp_rc_fresh>
    7adc:	aa0003e2 	mov	x2, x0
    7ae0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7ae4:	911ae3e1 	add	x1, sp, #0x6b8
    7ae8:	52800020 	mov	w0, #0x1                   	// #1
    7aec:	f9035fe3 	str	x3, [sp, #1720]
    7af0:	f90363e2 	str	x2, [sp, #1728]
    7af4:	97ffee83 	bl	3500 <fwp_data.part.0.constprop.0>
    7af8:	91144283 	add	x3, x20, #0x510
    7afc:	aa0003f5 	mov	x21, x0
    7b00:	f949d861 	ldr	x1, [x3, #5040]
    7b04:	f949ec60 	ldr	x0, [x3, #5080]
    7b08:	cb0102a1 	sub	x1, x21, x1
    7b0c:	eb00403f 	cmp	x1, x0, lsl #16
    7b10:	54000322 	b.cs	7b74 <f0+0x1d14>  // b.hs, b.nlast
    7b14:	d350fc22 	lsr	x2, x1, #16
    7b18:	f949fc63 	ldr	x3, [x3, #5112]
    7b1c:	8b020842 	add	x2, x2, x2, lsl #2
    7b20:	d37df042 	lsl	x2, x2, #3
    7b24:	8b020060 	add	x0, x3, x2
    7b28:	f9401017 	ldr	x23, [x0, #32]
    7b2c:	b4000257 	cbz	x23, 7b74 <f0+0x1d14>
    7b30:	38626862 	ldrb	w2, [x3, x2]
    7b34:	7100085f 	cmp	w2, #0x2
    7b38:	54003a20 	b.eq	827c <f0+0x241c>  // b.none
    7b3c:	7100045f 	cmp	w2, #0x1
    7b40:	540001a1 	b.ne	7b74 <f0+0x1d14>  // b.any
    7b44:	29430002 	ldp	w2, w0, [x0, #24]
    7b48:	92403c21 	and	x1, x1, #0xffff
    7b4c:	9b027c21 	mul	x1, x1, x2
    7b50:	d360fc21 	lsr	x1, x1, #32
    7b54:	eb00003f 	cmp	x1, x0
    7b58:	540000e2 	b.cs	7b74 <f0+0x1d14>  // b.hs, b.nlast
    7b5c:	8b0102f7 	add	x23, x23, x1
    7b60:	394002e0 	ldrb	w0, [x23]
    7b64:	7103fc1f 	cmp	w0, #0xff
    7b68:	54004980 	b.eq	8498 <f0+0x2638>  // b.none
    7b6c:	52800020 	mov	w0, #0x1                   	// #1
    7b70:	390002e0 	strb	w0, [x23]
    7b74:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7b78:	911b23e1 	add	x1, sp, #0x6c8
    7b7c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7b80:	52800020 	mov	w0, #0x1                   	// #1
    7b84:	f90367e2 	str	x2, [sp, #1736]
    7b88:	f9036bf5 	str	x21, [sp, #1744]
    7b8c:	97ffee5d 	bl	3500 <fwp_data.part.0.constprop.0>
    7b90:	97ffedc4 	bl	32a0 <fwp_rc_fresh>
    7b94:	aa0003e2 	mov	x2, x0
    7b98:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7b9c:	911b63e1 	add	x1, sp, #0x6d8
    7ba0:	52800020 	mov	w0, #0x1                   	// #1
    7ba4:	f9036fe3 	str	x3, [sp, #1752]
    7ba8:	f90373e2 	str	x2, [sp, #1760]
    7bac:	97ffee55 	bl	3500 <fwp_data.part.0.constprop.0>
    7bb0:	91144283 	add	x3, x20, #0x510
    7bb4:	aa0003f5 	mov	x21, x0
    7bb8:	f949d861 	ldr	x1, [x3, #5040]
    7bbc:	f949ec60 	ldr	x0, [x3, #5080]
    7bc0:	cb0102a1 	sub	x1, x21, x1
    7bc4:	eb00403f 	cmp	x1, x0, lsl #16
    7bc8:	54000322 	b.cs	7c2c <f0+0x1dcc>  // b.hs, b.nlast
    7bcc:	d350fc22 	lsr	x2, x1, #16
    7bd0:	f949fc63 	ldr	x3, [x3, #5112]
    7bd4:	8b020842 	add	x2, x2, x2, lsl #2
    7bd8:	d37df042 	lsl	x2, x2, #3
    7bdc:	8b020060 	add	x0, x3, x2
    7be0:	f9401017 	ldr	x23, [x0, #32]
    7be4:	b4000257 	cbz	x23, 7c2c <f0+0x1dcc>
    7be8:	38626862 	ldrb	w2, [x3, x2]
    7bec:	7100085f 	cmp	w2, #0x2
    7bf0:	54003400 	b.eq	8270 <f0+0x2410>  // b.none
    7bf4:	7100045f 	cmp	w2, #0x1
    7bf8:	540001a1 	b.ne	7c2c <f0+0x1dcc>  // b.any
    7bfc:	29430002 	ldp	w2, w0, [x0, #24]
    7c00:	92403c21 	and	x1, x1, #0xffff
    7c04:	9b027c21 	mul	x1, x1, x2
    7c08:	d360fc21 	lsr	x1, x1, #32
    7c0c:	eb00003f 	cmp	x1, x0
    7c10:	540000e2 	b.cs	7c2c <f0+0x1dcc>  // b.hs, b.nlast
    7c14:	8b0102f7 	add	x23, x23, x1
    7c18:	394002e0 	ldrb	w0, [x23]
    7c1c:	7103fc1f 	cmp	w0, #0xff
    7c20:	54004420 	b.eq	84a4 <f0+0x2644>  // b.none
    7c24:	52800020 	mov	w0, #0x1                   	// #1
    7c28:	390002e0 	strb	w0, [x23]
    7c2c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7c30:	911ba3e1 	add	x1, sp, #0x6e8
    7c34:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7c38:	52800020 	mov	w0, #0x1                   	// #1
    7c3c:	f90377e2 	str	x2, [sp, #1768]
    7c40:	f9037bf5 	str	x21, [sp, #1776]
    7c44:	97ffee2f 	bl	3500 <fwp_data.part.0.constprop.0>
    7c48:	97ffed96 	bl	32a0 <fwp_rc_fresh>
    7c4c:	aa0003e2 	mov	x2, x0
    7c50:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7c54:	911be3e1 	add	x1, sp, #0x6f8
    7c58:	52800020 	mov	w0, #0x1                   	// #1
    7c5c:	f9037fe3 	str	x3, [sp, #1784]
    7c60:	f90383e2 	str	x2, [sp, #1792]
    7c64:	97ffee27 	bl	3500 <fwp_data.part.0.constprop.0>
    7c68:	91144283 	add	x3, x20, #0x510
    7c6c:	aa0003f5 	mov	x21, x0
    7c70:	f949d861 	ldr	x1, [x3, #5040]
    7c74:	f949ec60 	ldr	x0, [x3, #5080]
    7c78:	cb0102a1 	sub	x1, x21, x1
    7c7c:	eb00403f 	cmp	x1, x0, lsl #16
    7c80:	54000322 	b.cs	7ce4 <f0+0x1e84>  // b.hs, b.nlast
    7c84:	d350fc22 	lsr	x2, x1, #16
    7c88:	f949fc63 	ldr	x3, [x3, #5112]
    7c8c:	8b020842 	add	x2, x2, x2, lsl #2
    7c90:	d37df042 	lsl	x2, x2, #3
    7c94:	8b020060 	add	x0, x3, x2
    7c98:	f9401017 	ldr	x23, [x0, #32]
    7c9c:	b4000257 	cbz	x23, 7ce4 <f0+0x1e84>
    7ca0:	38626862 	ldrb	w2, [x3, x2]
    7ca4:	7100085f 	cmp	w2, #0x2
    7ca8:	54002de0 	b.eq	8264 <f0+0x2404>  // b.none
    7cac:	7100045f 	cmp	w2, #0x1
    7cb0:	540001a1 	b.ne	7ce4 <f0+0x1e84>  // b.any
    7cb4:	29430002 	ldp	w2, w0, [x0, #24]
    7cb8:	92403c21 	and	x1, x1, #0xffff
    7cbc:	9b027c21 	mul	x1, x1, x2
    7cc0:	d360fc21 	lsr	x1, x1, #32
    7cc4:	eb00003f 	cmp	x1, x0
    7cc8:	540000e2 	b.cs	7ce4 <f0+0x1e84>  // b.hs, b.nlast
    7ccc:	8b0102f7 	add	x23, x23, x1
    7cd0:	394002e0 	ldrb	w0, [x23]
    7cd4:	7103fc1f 	cmp	w0, #0xff
    7cd8:	54003ec0 	b.eq	84b0 <f0+0x2650>  // b.none
    7cdc:	52800020 	mov	w0, #0x1                   	// #1
    7ce0:	390002e0 	strb	w0, [x23]
    7ce4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7ce8:	911c23e1 	add	x1, sp, #0x708
    7cec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7cf0:	52800020 	mov	w0, #0x1                   	// #1
    7cf4:	f90387e2 	str	x2, [sp, #1800]
    7cf8:	f9038bf5 	str	x21, [sp, #1808]
    7cfc:	97ffee01 	bl	3500 <fwp_data.part.0.constprop.0>
    7d00:	91144283 	add	x3, x20, #0x510
    7d04:	aa0003f5 	mov	x21, x0
    7d08:	f949d861 	ldr	x1, [x3, #5040]
    7d0c:	f949ec60 	ldr	x0, [x3, #5080]
    7d10:	cb0102a1 	sub	x1, x21, x1
    7d14:	eb00403f 	cmp	x1, x0, lsl #16
    7d18:	54000322 	b.cs	7d7c <f0+0x1f1c>  // b.hs, b.nlast
    7d1c:	d350fc22 	lsr	x2, x1, #16
    7d20:	f949fc63 	ldr	x3, [x3, #5112]
    7d24:	8b020842 	add	x2, x2, x2, lsl #2
    7d28:	d37df042 	lsl	x2, x2, #3
    7d2c:	8b020060 	add	x0, x3, x2
    7d30:	f9401017 	ldr	x23, [x0, #32]
    7d34:	b4000257 	cbz	x23, 7d7c <f0+0x1f1c>
    7d38:	38626862 	ldrb	w2, [x3, x2]
    7d3c:	7100085f 	cmp	w2, #0x2
    7d40:	540028c0 	b.eq	8258 <f0+0x23f8>  // b.none
    7d44:	7100045f 	cmp	w2, #0x1
    7d48:	540001a1 	b.ne	7d7c <f0+0x1f1c>  // b.any
    7d4c:	29430002 	ldp	w2, w0, [x0, #24]
    7d50:	92403c21 	and	x1, x1, #0xffff
    7d54:	9b027c21 	mul	x1, x1, x2
    7d58:	d360fc21 	lsr	x1, x1, #32
    7d5c:	eb00003f 	cmp	x1, x0
    7d60:	540000e2 	b.cs	7d7c <f0+0x1f1c>  // b.hs, b.nlast
    7d64:	8b0102f7 	add	x23, x23, x1
    7d68:	394002e0 	ldrb	w0, [x23]
    7d6c:	7103fc1f 	cmp	w0, #0xff
    7d70:	54003a60 	b.eq	84bc <f0+0x265c>  // b.none
    7d74:	52800020 	mov	w0, #0x1                   	// #1
    7d78:	390002e0 	strb	w0, [x23]
    7d7c:	911c63e1 	add	x1, sp, #0x718
    7d80:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7d84:	52800020 	mov	w0, #0x1                   	// #1
    7d88:	f9038fe2 	str	x2, [sp, #1816]
    7d8c:	f90393f5 	str	x21, [sp, #1824]
    7d90:	97ffeddc 	bl	3500 <fwp_data.part.0.constprop.0>
    7d94:	97ffed43 	bl	32a0 <fwp_rc_fresh>
    7d98:	aa0003e2 	mov	x2, x0
    7d9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7da0:	911ca3e1 	add	x1, sp, #0x728
    7da4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7da8:	52800020 	mov	w0, #0x1                   	// #1
    7dac:	f90397e3 	str	x3, [sp, #1832]
    7db0:	f9039be2 	str	x2, [sp, #1840]
    7db4:	97ffedd3 	bl	3500 <fwp_data.part.0.constprop.0>
    7db8:	91144283 	add	x3, x20, #0x510
    7dbc:	aa0003f5 	mov	x21, x0
    7dc0:	f949d861 	ldr	x1, [x3, #5040]
    7dc4:	f949ec60 	ldr	x0, [x3, #5080]
    7dc8:	cb0102a1 	sub	x1, x21, x1
    7dcc:	eb00403f 	cmp	x1, x0, lsl #16
    7dd0:	54000322 	b.cs	7e34 <f0+0x1fd4>  // b.hs, b.nlast
    7dd4:	d350fc22 	lsr	x2, x1, #16
    7dd8:	f949fc63 	ldr	x3, [x3, #5112]
    7ddc:	8b020842 	add	x2, x2, x2, lsl #2
    7de0:	d37df042 	lsl	x2, x2, #3
    7de4:	8b020060 	add	x0, x3, x2
    7de8:	f9401017 	ldr	x23, [x0, #32]
    7dec:	b4000257 	cbz	x23, 7e34 <f0+0x1fd4>
    7df0:	38626862 	ldrb	w2, [x3, x2]
    7df4:	7100085f 	cmp	w2, #0x2
    7df8:	540022a0 	b.eq	824c <f0+0x23ec>  // b.none
    7dfc:	7100045f 	cmp	w2, #0x1
    7e00:	540001a1 	b.ne	7e34 <f0+0x1fd4>  // b.any
    7e04:	29430002 	ldp	w2, w0, [x0, #24]
    7e08:	92403c21 	and	x1, x1, #0xffff
    7e0c:	9b027c21 	mul	x1, x1, x2
    7e10:	d360fc21 	lsr	x1, x1, #32
    7e14:	eb00003f 	cmp	x1, x0
    7e18:	540000e2 	b.cs	7e34 <f0+0x1fd4>  // b.hs, b.nlast
    7e1c:	8b0102f7 	add	x23, x23, x1
    7e20:	394002e0 	ldrb	w0, [x23]
    7e24:	7103fc1f 	cmp	w0, #0xff
    7e28:	54003500 	b.eq	84c8 <f0+0x2668>  // b.none
    7e2c:	52800020 	mov	w0, #0x1                   	// #1
    7e30:	390002e0 	strb	w0, [x23]
    7e34:	911ce3e1 	add	x1, sp, #0x738
    7e38:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7e3c:	52800020 	mov	w0, #0x1                   	// #1
    7e40:	f9039ff7 	str	x23, [sp, #1848]
    7e44:	f903a3f5 	str	x21, [sp, #1856]
    7e48:	97ffedae 	bl	3500 <fwp_data.part.0.constprop.0>
    7e4c:	97ffed15 	bl	32a0 <fwp_rc_fresh>
    7e50:	aa0003e2 	mov	x2, x0
    7e54:	911d23e1 	add	x1, sp, #0x748
    7e58:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7e5c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7e60:	52800020 	mov	w0, #0x1                   	// #1
    7e64:	f903a7f5 	str	x21, [sp, #1864]
    7e68:	91144294 	add	x20, x20, #0x510
    7e6c:	f903abe2 	str	x2, [sp, #1872]
    7e70:	97ffeda4 	bl	3500 <fwp_data.part.0.constprop.0>
    7e74:	97ffed0b 	bl	32a0 <fwp_rc_fresh>
    7e78:	aa0003e2 	mov	x2, x0
    7e7c:	911d63e1 	add	x1, sp, #0x758
    7e80:	52800020 	mov	w0, #0x1                   	// #1
    7e84:	f903aff7 	str	x23, [sp, #1880]
    7e88:	f903b3e2 	str	x2, [sp, #1888]
    7e8c:	97ffed9d 	bl	3500 <fwp_data.part.0.constprop.0>
    7e90:	97ffed04 	bl	32a0 <fwp_rc_fresh>
    7e94:	aa0003e2 	mov	x2, x0
    7e98:	911da3e1 	add	x1, sp, #0x768
    7e9c:	52800020 	mov	w0, #0x1                   	// #1
    7ea0:	f903b7f5 	str	x21, [sp, #1896]
    7ea4:	f903bbe2 	str	x2, [sp, #1904]
    7ea8:	97ffed96 	bl	3500 <fwp_data.part.0.constprop.0>
    7eac:	f949da81 	ldr	x1, [x20, #5040]
    7eb0:	aa0003f7 	mov	x23, x0
    7eb4:	f949ee80 	ldr	x0, [x20, #5080]
    7eb8:	cb0102e1 	sub	x1, x23, x1
    7ebc:	eb00403f 	cmp	x1, x0, lsl #16
    7ec0:	54000322 	b.cs	7f24 <f0+0x20c4>  // b.hs, b.nlast
    7ec4:	d350fc22 	lsr	x2, x1, #16
    7ec8:	f949fe83 	ldr	x3, [x20, #5112]
    7ecc:	8b020842 	add	x2, x2, x2, lsl #2
    7ed0:	d37df042 	lsl	x2, x2, #3
    7ed4:	8b020060 	add	x0, x3, x2
    7ed8:	f9401014 	ldr	x20, [x0, #32]
    7edc:	b4000254 	cbz	x20, 7f24 <f0+0x20c4>
    7ee0:	38626862 	ldrb	w2, [x3, x2]
    7ee4:	7100085f 	cmp	w2, #0x2
    7ee8:	54001ac0 	b.eq	8240 <f0+0x23e0>  // b.none
    7eec:	7100045f 	cmp	w2, #0x1
    7ef0:	540001a1 	b.ne	7f24 <f0+0x20c4>  // b.any
    7ef4:	29430002 	ldp	w2, w0, [x0, #24]
    7ef8:	92403c21 	and	x1, x1, #0xffff
    7efc:	9b027c21 	mul	x1, x1, x2
    7f00:	d360fc21 	lsr	x1, x1, #32
    7f04:	eb00003f 	cmp	x1, x0
    7f08:	540000e2 	b.cs	7f24 <f0+0x20c4>  // b.hs, b.nlast
    7f0c:	8b010294 	add	x20, x20, x1
    7f10:	39400280 	ldrb	w0, [x20]
    7f14:	7103fc1f 	cmp	w0, #0xff
    7f18:	54001f40 	b.eq	8300 <f0+0x24a0>  // b.none
    7f1c:	52800020 	mov	w0, #0x1                   	// #1
    7f20:	39000280 	strb	w0, [x20]
    7f24:	911de3e1 	add	x1, sp, #0x778
    7f28:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7f2c:	52800020 	mov	w0, #0x1                   	// #1
    7f30:	f903bff5 	str	x21, [sp, #1912]
    7f34:	f903c3f7 	str	x23, [sp, #1920]
    7f38:	97ffed72 	bl	3500 <fwp_data.part.0.constprop.0>
    7f3c:	97ffecd9 	bl	32a0 <fwp_rc_fresh>
    7f40:	aa0003e2 	mov	x2, x0
    7f44:	911e23e1 	add	x1, sp, #0x788
    7f48:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    7f4c:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    7f50:	52800020 	mov	w0, #0x1                   	// #1
    7f54:	f903c7f4 	str	x20, [sp, #1928]
    7f58:	f903cbe2 	str	x2, [sp, #1936]
    7f5c:	97ffed69 	bl	3500 <fwp_data.part.0.constprop.0>
    7f60:	97ffecd0 	bl	32a0 <fwp_rc_fresh>
    7f64:	aa0003e2 	mov	x2, x0
    7f68:	911e63e1 	add	x1, sp, #0x798
    7f6c:	52800020 	mov	w0, #0x1                   	// #1
    7f70:	f903cff5 	str	x21, [sp, #1944]
    7f74:	f903d3e2 	str	x2, [sp, #1952]
    7f78:	97ffed62 	bl	3500 <fwp_data.part.0.constprop.0>
    7f7c:	97ffecc9 	bl	32a0 <fwp_rc_fresh>
    7f80:	aa0003e2 	mov	x2, x0
    7f84:	911ea3e1 	add	x1, sp, #0x7a8
    7f88:	52800020 	mov	w0, #0x1                   	// #1
    7f8c:	f903d7f4 	str	x20, [sp, #1960]
    7f90:	f903dbe2 	str	x2, [sp, #1968]
    7f94:	97ffed5b 	bl	3500 <fwp_data.part.0.constprop.0>
    7f98:	97ffecc2 	bl	32a0 <fwp_rc_fresh>
    7f9c:	aa0003e2 	mov	x2, x0
    7fa0:	911ee3e1 	add	x1, sp, #0x7b8
    7fa4:	52800020 	mov	w0, #0x1                   	// #1
    7fa8:	f903dff5 	str	x21, [sp, #1976]
    7fac:	f903e3e2 	str	x2, [sp, #1984]
    7fb0:	97ffed54 	bl	3500 <fwp_data.part.0.constprop.0>
    7fb4:	97ffecbb 	bl	32a0 <fwp_rc_fresh>
    7fb8:	aa0003e2 	mov	x2, x0
    7fbc:	911f23e1 	add	x1, sp, #0x7c8
    7fc0:	52800020 	mov	w0, #0x1                   	// #1
    7fc4:	f903e7f4 	str	x20, [sp, #1992]
    7fc8:	f903ebe2 	str	x2, [sp, #2000]
    7fcc:	97ffed4d 	bl	3500 <fwp_data.part.0.constprop.0>
    7fd0:	97ffecb4 	bl	32a0 <fwp_rc_fresh>
    7fd4:	aa0003e2 	mov	x2, x0
    7fd8:	911f63e1 	add	x1, sp, #0x7d8
    7fdc:	52800020 	mov	w0, #0x1                   	// #1
    7fe0:	f903eff5 	str	x21, [sp, #2008]
    7fe4:	f903f3e2 	str	x2, [sp, #2016]
    7fe8:	97ffed46 	bl	3500 <fwp_data.part.0.constprop.0>
    7fec:	97ffecad 	bl	32a0 <fwp_rc_fresh>
    7ff0:	aa0003e2 	mov	x2, x0
    7ff4:	911fa3e1 	add	x1, sp, #0x7e8
    7ff8:	52800020 	mov	w0, #0x1                   	// #1
    7ffc:	f903f7f4 	str	x20, [sp, #2024]
    8000:	f903fbe2 	str	x2, [sp, #2032]
    8004:	97ffed3f 	bl	3500 <fwp_data.part.0.constprop.0>
    8008:	97ffeca6 	bl	32a0 <fwp_rc_fresh>
    800c:	aa0003e2 	mov	x2, x0
    8010:	911fe3e1 	add	x1, sp, #0x7f8
    8014:	52800020 	mov	w0, #0x1                   	// #1
    8018:	f903fff5 	str	x21, [sp, #2040]
    801c:	f90403e2 	str	x2, [sp, #2048]
    8020:	97ffed38 	bl	3500 <fwp_data.part.0.constprop.0>
    8024:	97ffec9f 	bl	32a0 <fwp_rc_fresh>
    8028:	aa0003e2 	mov	x2, x0
    802c:	912023e1 	add	x1, sp, #0x808
    8030:	52800020 	mov	w0, #0x1                   	// #1
    8034:	f90407f4 	str	x20, [sp, #2056]
    8038:	f9040be2 	str	x2, [sp, #2064]
    803c:	97ffed31 	bl	3500 <fwp_data.part.0.constprop.0>
    8040:	97ffec98 	bl	32a0 <fwp_rc_fresh>
    8044:	aa0003e2 	mov	x2, x0
    8048:	912063e1 	add	x1, sp, #0x818
    804c:	52800020 	mov	w0, #0x1                   	// #1
    8050:	f9040ff5 	str	x21, [sp, #2072]
    8054:	f90413e2 	str	x2, [sp, #2080]
    8058:	97ffed2a 	bl	3500 <fwp_data.part.0.constprop.0>
    805c:	97ffec91 	bl	32a0 <fwp_rc_fresh>
    8060:	aa0003e2 	mov	x2, x0
    8064:	9120a3e1 	add	x1, sp, #0x828
    8068:	52800020 	mov	w0, #0x1                   	// #1
    806c:	f90417f4 	str	x20, [sp, #2088]
    8070:	f9041be2 	str	x2, [sp, #2096]
    8074:	97ffed23 	bl	3500 <fwp_data.part.0.constprop.0>
    8078:	97ffec8a 	bl	32a0 <fwp_rc_fresh>
    807c:	aa0003e2 	mov	x2, x0
    8080:	9120e3e1 	add	x1, sp, #0x838
    8084:	52800020 	mov	w0, #0x1                   	// #1
    8088:	f9041ff5 	str	x21, [sp, #2104]
    808c:	f90423e2 	str	x2, [sp, #2112]
    8090:	97ffed1c 	bl	3500 <fwp_data.part.0.constprop.0>
    8094:	97ffec83 	bl	32a0 <fwp_rc_fresh>
    8098:	aa0003e2 	mov	x2, x0
    809c:	aa1603e1 	mov	x1, x22
    80a0:	52800020 	mov	w0, #0x1                   	// #1
    80a4:	f90427f4 	str	x20, [sp, #2120]
    80a8:	f9042be2 	str	x2, [sp, #2128]
    80ac:	97ffed15 	bl	3500 <fwp_data.part.0.constprop.0>
    80b0:	97ffec7c 	bl	32a0 <fwp_rc_fresh>
    80b4:	aa0003f5 	mov	x21, x0
    80b8:	aa1303e1 	mov	x1, x19
    80bc:	97fff302 	bl	4cc4 <fwp_hof0.constprop.0>
    80c0:	aa0003f4 	mov	x20, x0
    80c4:	aa1503e0 	mov	x0, x21
    80c8:	97ffed6a 	bl	3670 <fwp_drop0>
    80cc:	aa1303e0 	mov	x0, x19
    80d0:	97ffed68 	bl	3670 <fwp_drop0>
    80d4:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    80d8:	f947f400 	ldr	x0, [x0, #4072]
    80dc:	f9442fe2 	ldr	x2, [sp, #2136]
    80e0:	f9400001 	ldr	x1, [x0]
    80e4:	eb010042 	subs	x2, x2, x1
    80e8:	d2800001 	mov	x1, #0x0                   	// #0
    80ec:	54001f41 	b.ne	84d4 <f0+0x2674>  // b.any
    80f0:	912183ff 	add	sp, sp, #0x860
    80f4:	aa1403e0 	mov	x0, x20
    80f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    80fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8100:	a94363f7 	ldp	x23, x24, [sp, #48]
    8104:	a9446bf9 	ldp	x25, x26, [sp, #64]
    8108:	a94573fb 	ldp	x27, x28, [sp, #80]
    810c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8110:	d65f03c0 	ret
    8114:	aa1b03e0 	mov	x0, x27
    8118:	97ffeaa3 	bl	2ba4 <fwp_rc_forget_slot>
    811c:	17fff799 	b	5f80 <f0+0x120>
    8120:	72003c5f 	tst	w2, #0xffff
    8124:	54fef301 	b.ne	5f84 <f0+0x124>  // b.any
    8128:	17fff793 	b	5f74 <f0+0x114>
    812c:	72003c3f 	tst	w1, #0xffff
    8130:	54ff8f01 	b.ne	7310 <f0+0x14b0>  // b.any
    8134:	17fffc72 	b	72fc <f0+0x149c>
    8138:	72003c3f 	tst	w1, #0xffff
    813c:	54ff8801 	b.ne	723c <f0+0x13dc>  // b.any
    8140:	17fffc3a 	b	7228 <f0+0x13c8>
    8144:	72003c3f 	tst	w1, #0xffff
    8148:	54ff81e1 	b.ne	7184 <f0+0x1324>  // b.any
    814c:	17fffc09 	b	7170 <f0+0x1310>
    8150:	72003c3f 	tst	w1, #0xffff
    8154:	54ff7ae1 	b.ne	70b0 <f0+0x1250>  // b.any
    8158:	17fffbd1 	b	709c <f0+0x123c>
    815c:	72003c3f 	tst	w1, #0xffff
    8160:	54ff74c1 	b.ne	6ff8 <f0+0x1198>  // b.any
    8164:	17fffba0 	b	6fe4 <f0+0x1184>
    8168:	72003c3f 	tst	w1, #0xffff
    816c:	54ff6fa1 	b.ne	6f60 <f0+0x1100>  // b.any
    8170:	17fffb77 	b	6f4c <f0+0x10ec>
    8174:	72003c3f 	tst	w1, #0xffff
    8178:	54ff67c1 	b.ne	6e70 <f0+0x1010>  // b.any
    817c:	17fffb38 	b	6e5c <f0+0xffc>
    8180:	72003c3f 	tst	w1, #0xffff
    8184:	54ff61a1 	b.ne	6db8 <f0+0xf58>  // b.any
    8188:	17fffb07 	b	6da4 <f0+0xf44>
    818c:	72003c3f 	tst	w1, #0xffff
    8190:	54ff0be1 	b.ne	630c <f0+0x4ac>  // b.any
    8194:	17fff859 	b	62f8 <f0+0x498>
    8198:	72003c3f 	tst	w1, #0xffff
    819c:	54ff0481 	b.ne	622c <f0+0x3cc>  // b.any
    81a0:	17fff81e 	b	6218 <f0+0x3b8>
    81a4:	72003c3f 	tst	w1, #0xffff
    81a8:	54fef661 	b.ne	6074 <f0+0x214>  // b.any
    81ac:	17fff7ad 	b	6060 <f0+0x200>
    81b0:	72003c3f 	tst	w1, #0xffff
    81b4:	54ff27c1 	b.ne	66ac <f0+0x84c>  // b.any
    81b8:	17fff938 	b	6698 <f0+0x838>
    81bc:	72003c3f 	tst	w1, #0xffff
    81c0:	54ff21a1 	b.ne	65f4 <f0+0x794>  // b.any
    81c4:	17fff907 	b	65e0 <f0+0x780>
    81c8:	72003c3f 	tst	w1, #0xffff
    81cc:	54ff1b81 	b.ne	653c <f0+0x6dc>  // b.any
    81d0:	17fff8d6 	b	6528 <f0+0x6c8>
    81d4:	72003c3f 	tst	w1, #0xffff
    81d8:	54ff1221 	b.ne	641c <f0+0x5bc>  // b.any
    81dc:	17fff88b 	b	6408 <f0+0x5a8>
    81e0:	72003c3f 	tst	w1, #0xffff
    81e4:	54ff58e1 	b.ne	6d00 <f0+0xea0>  // b.any
    81e8:	17fffac1 	b	6cec <f0+0xe8c>
    81ec:	72003c3f 	tst	w1, #0xffff
    81f0:	54ff5101 	b.ne	6c10 <f0+0xdb0>  // b.any
    81f4:	17fffa82 	b	6bfc <f0+0xd9c>
    81f8:	72003c3f 	tst	w1, #0xffff
    81fc:	54ff4c01 	b.ne	6b7c <f0+0xd1c>  // b.any
    8200:	17fffa5a 	b	6b68 <f0+0xd08>
    8204:	72003c3f 	tst	w1, #0xffff
    8208:	54ff4501 	b.ne	6aa8 <f0+0xc48>  // b.any
    820c:	17fffa22 	b	6a94 <f0+0xc34>
    8210:	72003c3f 	tst	w1, #0xffff
    8214:	54ff3d21 	b.ne	69b8 <f0+0xb58>  // b.any
    8218:	17fff9e3 	b	69a4 <f0+0xb44>
    821c:	72003c3f 	tst	w1, #0xffff
    8220:	54ff3621 	b.ne	68e4 <f0+0xa84>  // b.any
    8224:	17fff9ab 	b	68d0 <f0+0xa70>
    8228:	72003c3f 	tst	w1, #0xffff
    822c:	54ff3101 	b.ne	684c <f0+0x9ec>  // b.any
    8230:	17fff982 	b	6838 <f0+0x9d8>
    8234:	72003c3f 	tst	w1, #0xffff
    8238:	54ff2c01 	b.ne	67b8 <f0+0x958>  // b.any
    823c:	17fff95a 	b	67a4 <f0+0x944>
    8240:	72003c3f 	tst	w1, #0xffff
    8244:	54ffe701 	b.ne	7f24 <f0+0x20c4>  // b.any
    8248:	17ffff32 	b	7f10 <f0+0x20b0>
    824c:	72003c3f 	tst	w1, #0xffff
    8250:	54ffdf21 	b.ne	7e34 <f0+0x1fd4>  // b.any
    8254:	17fffef3 	b	7e20 <f0+0x1fc0>
    8258:	72003c3f 	tst	w1, #0xffff
    825c:	54ffd901 	b.ne	7d7c <f0+0x1f1c>  // b.any
    8260:	17fffec2 	b	7d68 <f0+0x1f08>
    8264:	72003c3f 	tst	w1, #0xffff
    8268:	54ffd3e1 	b.ne	7ce4 <f0+0x1e84>  // b.any
    826c:	17fffe99 	b	7cd0 <f0+0x1e70>
    8270:	72003c3f 	tst	w1, #0xffff
    8274:	54ffcdc1 	b.ne	7c2c <f0+0x1dcc>  // b.any
    8278:	17fffe68 	b	7c18 <f0+0x1db8>
    827c:	72003c3f 	tst	w1, #0xffff
    8280:	54ffc7a1 	b.ne	7b74 <f0+0x1d14>  // b.any
    8284:	17fffe37 	b	7b60 <f0+0x1d00>
    8288:	72003c3f 	tst	w1, #0xffff
    828c:	54ffc181 	b.ne	7abc <f0+0x1c5c>  // b.any
    8290:	17fffe06 	b	7aa8 <f0+0x1c48>
    8294:	72003c3f 	tst	w1, #0xffff
    8298:	54ffbc81 	b.ne	7a28 <f0+0x1bc8>  // b.any
    829c:	17fffdde 	b	7a14 <f0+0x1bb4>
    82a0:	72003c3f 	tst	w1, #0xffff
    82a4:	54ffb3c1 	b.ne	791c <f0+0x1abc>  // b.any
    82a8:	17fffd98 	b	7908 <f0+0x1aa8>
    82ac:	72003c3f 	tst	w1, #0xffff
    82b0:	54ffada1 	b.ne	7864 <f0+0x1a04>  // b.any
    82b4:	17fffd67 	b	7850 <f0+0x19f0>
    82b8:	72003c3f 	tst	w1, #0xffff
    82bc:	54ffa8a1 	b.ne	77d0 <f0+0x1970>  // b.any
    82c0:	17fffd3f 	b	77bc <f0+0x195c>
    82c4:	72003c3f 	tst	w1, #0xffff
    82c8:	54ffa1a1 	b.ne	76fc <f0+0x189c>  // b.any
    82cc:	17fffd07 	b	76e8 <f0+0x1888>
    82d0:	72003c3f 	tst	w1, #0xffff
    82d4:	54ff9b81 	b.ne	7644 <f0+0x17e4>  // b.any
    82d8:	17fffcd6 	b	7630 <f0+0x17d0>
    82dc:	72003c3f 	tst	w1, #0xffff
    82e0:	54ff9481 	b.ne	7570 <f0+0x1710>  // b.any
    82e4:	17fffc9e 	b	755c <f0+0x16fc>
    82e8:	72003c3f 	tst	w1, #0xffff
    82ec:	54ff8d81 	b.ne	749c <f0+0x163c>  // b.any
    82f0:	17fffc66 	b	7488 <f0+0x1628>
    82f4:	72003c3f 	tst	w1, #0xffff
    82f8:	54ff8761 	b.ne	73e4 <f0+0x1584>  // b.any
    82fc:	17fffc35 	b	73d0 <f0+0x1570>
    8300:	aa1403e0 	mov	x0, x20
    8304:	97ffea28 	bl	2ba4 <fwp_rc_forget_slot>
    8308:	17ffff05 	b	7f1c <f0+0x20bc>
    830c:	aa1503e0 	mov	x0, x21
    8310:	97ffea25 	bl	2ba4 <fwp_rc_forget_slot>
    8314:	17fff756 	b	606c <f0+0x20c>
    8318:	aa1703e0 	mov	x0, x23
    831c:	97ffea22 	bl	2ba4 <fwp_rc_forget_slot>
    8320:	17fff7c1 	b	6224 <f0+0x3c4>
    8324:	aa1703e0 	mov	x0, x23
    8328:	97ffea1f 	bl	2ba4 <fwp_rc_forget_slot>
    832c:	17fff7f6 	b	6304 <f0+0x4a4>
    8330:	aa1703e0 	mov	x0, x23
    8334:	97ffea1c 	bl	2ba4 <fwp_rc_forget_slot>
    8338:	17fff837 	b	6414 <f0+0x5b4>
    833c:	aa1703e0 	mov	x0, x23
    8340:	97ffea19 	bl	2ba4 <fwp_rc_forget_slot>
    8344:	17fff87c 	b	6534 <f0+0x6d4>
    8348:	aa1703e0 	mov	x0, x23
    834c:	97ffea16 	bl	2ba4 <fwp_rc_forget_slot>
    8350:	17fff8a7 	b	65ec <f0+0x78c>
    8354:	aa1703e0 	mov	x0, x23
    8358:	97ffea13 	bl	2ba4 <fwp_rc_forget_slot>
    835c:	17fff8d2 	b	66a4 <f0+0x844>
    8360:	aa1703e0 	mov	x0, x23
    8364:	97ffea10 	bl	2ba4 <fwp_rc_forget_slot>
    8368:	17fff912 	b	67b0 <f0+0x950>
    836c:	aa1703e0 	mov	x0, x23
    8370:	97ffea0d 	bl	2ba4 <fwp_rc_forget_slot>
    8374:	17fff934 	b	6844 <f0+0x9e4>
    8378:	aa1703e0 	mov	x0, x23
    837c:	97ffea0a 	bl	2ba4 <fwp_rc_forget_slot>
    8380:	17fff957 	b	68dc <f0+0xa7c>
    8384:	aa1703e0 	mov	x0, x23
    8388:	97ffea07 	bl	2ba4 <fwp_rc_forget_slot>
    838c:	17fff989 	b	69b0 <f0+0xb50>
    8390:	aa1703e0 	mov	x0, x23
    8394:	97ffea04 	bl	2ba4 <fwp_rc_forget_slot>
    8398:	17fff9c2 	b	6aa0 <f0+0xc40>
    839c:	aa1703e0 	mov	x0, x23
    83a0:	97ffea01 	bl	2ba4 <fwp_rc_forget_slot>
    83a4:	17fff9f4 	b	6b74 <f0+0xd14>
    83a8:	aa1703e0 	mov	x0, x23
    83ac:	97ffe9fe 	bl	2ba4 <fwp_rc_forget_slot>
    83b0:	17fffa16 	b	6c08 <f0+0xda8>
    83b4:	aa1703e0 	mov	x0, x23
    83b8:	97ffe9fb 	bl	2ba4 <fwp_rc_forget_slot>
    83bc:	17fffa4f 	b	6cf8 <f0+0xe98>
    83c0:	aa1703e0 	mov	x0, x23
    83c4:	97ffe9f8 	bl	2ba4 <fwp_rc_forget_slot>
    83c8:	17fffa7a 	b	6db0 <f0+0xf50>
    83cc:	aa1703e0 	mov	x0, x23
    83d0:	97ffe9f5 	bl	2ba4 <fwp_rc_forget_slot>
    83d4:	17fffaa5 	b	6e68 <f0+0x1008>
    83d8:	aa1703e0 	mov	x0, x23
    83dc:	97ffe9f2 	bl	2ba4 <fwp_rc_forget_slot>
    83e0:	17fffade 	b	6f58 <f0+0x10f8>
    83e4:	aa1703e0 	mov	x0, x23
    83e8:	97ffe9ef 	bl	2ba4 <fwp_rc_forget_slot>
    83ec:	17fffb01 	b	6ff0 <f0+0x1190>
    83f0:	aa1703e0 	mov	x0, x23
    83f4:	97ffe9ec 	bl	2ba4 <fwp_rc_forget_slot>
    83f8:	17fffb2c 	b	70a8 <f0+0x1248>
    83fc:	aa1703e0 	mov	x0, x23
    8400:	97ffe9e9 	bl	2ba4 <fwp_rc_forget_slot>
    8404:	17fffb5e 	b	717c <f0+0x131c>
    8408:	aa1703e0 	mov	x0, x23
    840c:	97ffe9e6 	bl	2ba4 <fwp_rc_forget_slot>
    8410:	17fffb89 	b	7234 <f0+0x13d4>
    8414:	aa1703e0 	mov	x0, x23
    8418:	97ffe9e3 	bl	2ba4 <fwp_rc_forget_slot>
    841c:	17fffbbb 	b	7308 <f0+0x14a8>
    8420:	aa1703e0 	mov	x0, x23
    8424:	97ffe9e0 	bl	2ba4 <fwp_rc_forget_slot>
    8428:	17fffbed 	b	73dc <f0+0x157c>
    842c:	aa1703e0 	mov	x0, x23
    8430:	97ffe9dd 	bl	2ba4 <fwp_rc_forget_slot>
    8434:	17fffc18 	b	7494 <f0+0x1634>
    8438:	aa1703e0 	mov	x0, x23
    843c:	97ffe9da 	bl	2ba4 <fwp_rc_forget_slot>
    8440:	17fffc4a 	b	7568 <f0+0x1708>
    8444:	aa1703e0 	mov	x0, x23
    8448:	97ffe9d7 	bl	2ba4 <fwp_rc_forget_slot>
    844c:	17fffc7c 	b	763c <f0+0x17dc>
    8450:	aa1703e0 	mov	x0, x23
    8454:	97ffe9d4 	bl	2ba4 <fwp_rc_forget_slot>
    8458:	17fffca7 	b	76f4 <f0+0x1894>
    845c:	aa1703e0 	mov	x0, x23
    8460:	97ffe9d1 	bl	2ba4 <fwp_rc_forget_slot>
    8464:	17fffcd9 	b	77c8 <f0+0x1968>
    8468:	aa1703e0 	mov	x0, x23
    846c:	97ffe9ce 	bl	2ba4 <fwp_rc_forget_slot>
    8470:	17fffcfb 	b	785c <f0+0x19fc>
    8474:	aa1703e0 	mov	x0, x23
    8478:	97ffe9cb 	bl	2ba4 <fwp_rc_forget_slot>
    847c:	17fffd26 	b	7914 <f0+0x1ab4>
    8480:	aa1703e0 	mov	x0, x23
    8484:	97ffe9c8 	bl	2ba4 <fwp_rc_forget_slot>
    8488:	17fffd66 	b	7a20 <f0+0x1bc0>
    848c:	aa1703e0 	mov	x0, x23
    8490:	97ffe9c5 	bl	2ba4 <fwp_rc_forget_slot>
    8494:	17fffd88 	b	7ab4 <f0+0x1c54>
    8498:	aa1703e0 	mov	x0, x23
    849c:	97ffe9c2 	bl	2ba4 <fwp_rc_forget_slot>
    84a0:	17fffdb3 	b	7b6c <f0+0x1d0c>
    84a4:	aa1703e0 	mov	x0, x23
    84a8:	97ffe9bf 	bl	2ba4 <fwp_rc_forget_slot>
    84ac:	17fffdde 	b	7c24 <f0+0x1dc4>
    84b0:	aa1703e0 	mov	x0, x23
    84b4:	97ffe9bc 	bl	2ba4 <fwp_rc_forget_slot>
    84b8:	17fffe09 	b	7cdc <f0+0x1e7c>
    84bc:	aa1703e0 	mov	x0, x23
    84c0:	97ffe9b9 	bl	2ba4 <fwp_rc_forget_slot>
    84c4:	17fffe2c 	b	7d74 <f0+0x1f14>
    84c8:	aa1703e0 	mov	x0, x23
    84cc:	97ffe9b6 	bl	2ba4 <fwp_rc_forget_slot>
    84d0:	17fffe57 	b	7e2c <f0+0x1fcc>
    84d4:	97ffe3f3 	bl	14a0 <__stack_chk_fail@plt>
    84d8:	d503201f 	nop
    84dc:	d503201f 	nop

00000000000084e0 <fwp_main_thread>:
    84e0:	d10443ff 	sub	sp, sp, #0x110
    84e4:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    84e8:	f947f400 	ldr	x0, [x0, #4072]
    84ec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    84f0:	910303fd 	add	x29, sp, #0xc0
    84f4:	a90d53f3 	stp	x19, x20, [sp, #208]
    84f8:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    84fc:	91144261 	add	x1, x19, #0x510
    8500:	a90e5bf5 	stp	x21, x22, [sp, #224]
    8504:	b953a421 	ldr	w1, [x1, #5028]
    8508:	f9400002 	ldr	x2, [x0]
    850c:	f9005fe2 	str	x2, [sp, #184]
    8510:	d2800002 	mov	x2, #0x0                   	// #0
    8514:	340025c1 	cbz	w1, 89cc <fwp_main_thread+0x4ec>
    8518:	91144273 	add	x19, x19, #0x510
    851c:	b953aa60 	ldr	w0, [x19, #5032]
    8520:	350024e0 	cbnz	w0, 89bc <fwp_main_thread+0x4dc>
    8524:	91001fe2 	add	x2, sp, #0x7
    8528:	900000d5 	adrp	x21, 20000 <__data_start>
    852c:	900000c3 	adrp	x3, 20000 <__data_start>
    8530:	9101c2b3 	add	x19, x21, #0x70
    8534:	910cc063 	add	x3, x3, #0x330
    8538:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    853c:	d2a00025 	mov	x5, #0x10000               	// #65536
    8540:	910023e0 	add	x0, sp, #0x8
    8544:	d2800001 	mov	x1, #0x0                   	// #0
    8548:	f90007e3 	str	x3, [sp, #8]
    854c:	a9011262 	stp	x2, x4, [x19, #16]
    8550:	b90013ff 	str	wzr, [sp, #16]
    8554:	f9000fe5 	str	x5, [sp, #24]
    8558:	97ffe36e 	bl	1310 <sigaltstack@plt>
    855c:	35002520 	cbnz	w0, 8a00 <fwp_main_thread+0x520>
    8560:	4f000400 	movi	v0.4s, #0x0
    8564:	9100a3e0 	add	x0, sp, #0x28
    8568:	b0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    856c:	52800082 	mov	w2, #0x4                   	// #4
    8570:	912f4021 	add	x1, x1, #0xbd0
    8574:	72a10002 	movk	w2, #0x800, lsl #16
    8578:	910083f4 	add	x20, sp, #0x20
    857c:	f90013e1 	str	x1, [sp, #32]
    8580:	3d802000 	str	q0, [x0, #128]
    8584:	b900abe2 	str	w2, [sp, #168]
    8588:	ad000000 	stp	q0, q0, [x0]
    858c:	ad010000 	stp	q0, q0, [x0, #32]
    8590:	ad020000 	stp	q0, q0, [x0, #64]
    8594:	ad030000 	stp	q0, q0, [x0, #96]
    8598:	97ffe3b2 	bl	1460 <sigemptyset@plt>
    859c:	35002320 	cbnz	w0, 8a00 <fwp_main_thread+0x520>
    85a0:	aa1403e1 	mov	x1, x20
    85a4:	d2800002 	mov	x2, #0x0                   	// #0
    85a8:	52800160 	mov	w0, #0xb                   	// #11
    85ac:	97ffe3c5 	bl	14c0 <sigaction@plt>
    85b0:	35002280 	cbnz	w0, 8a00 <fwp_main_thread+0x520>
    85b4:	aa1403e1 	mov	x1, x20
    85b8:	d2800002 	mov	x2, #0x0                   	// #0
    85bc:	528000e0 	mov	w0, #0x7                   	// #7
    85c0:	97ffe3c0 	bl	14c0 <sigaction@plt>
    85c4:	350021e0 	cbnz	w0, 8a00 <fwp_main_thread+0x520>
    85c8:	b9429660 	ldr	w0, [x19, #660]
    85cc:	a90f63f7 	stp	x23, x24, [sp, #240]
    85d0:	34002020 	cbz	w0, 89d4 <fwp_main_thread+0x4f4>
    85d4:	9101c2b6 	add	x22, x21, #0x70
    85d8:	f94006d4 	ldr	x20, [x22, #8]
    85dc:	b40010d4 	cbz	x20, 87f4 <fwp_main_thread+0x314>
    85e0:	aa1403f3 	mov	x19, x20
    85e4:	91010297 	add	x23, x20, #0x40
    85e8:	f90083f9 	str	x25, [sp, #256]
    85ec:	52800038 	mov	w24, #0x1                   	// #1
    85f0:	39414a99 	ldrb	w25, [x20, #82]
    85f4:	39014a98 	strb	w24, [x20, #82]
    85f8:	f9401680 	ldr	x0, [x20, #40]
    85fc:	b4000620 	cbz	x0, 86c0 <fwp_main_thread+0x1e0>
    8600:	f9403281 	ldr	x1, [x20, #96]
    8604:	39414680 	ldrb	w0, [x20, #81]
    8608:	b4000b41 	cbz	x1, 8770 <fwp_main_thread+0x290>
    860c:	36000a80 	tbz	w0, #0, 875c <fwp_main_thread+0x27c>
    8610:	39414a62 	ldrb	w2, [x19, #82]
    8614:	f9402280 	ldr	x0, [x20, #64]
    8618:	37000d62 	tbnz	w2, #0, 87c4 <fwp_main_thread+0x2e4>
    861c:	f9403261 	ldr	x1, [x19, #96]
    8620:	a911fe77 	stp	x23, xzr, [x19, #280]
    8624:	f9009660 	str	x0, [x19, #296]
    8628:	b4000040 	cbz	x0, 8630 <fwp_main_thread+0x150>
    862c:	f9009013 	str	x19, [x0, #288]
    8630:	f9002293 	str	x19, [x20, #64]
    8634:	b4000101 	cbz	x1, 8654 <fwp_main_thread+0x174>
    8638:	f9401ac0 	ldr	x0, [x22, #48]
    863c:	39015678 	strb	w24, [x19, #85]
    8640:	f9003661 	str	x1, [x19, #104]
    8644:	a910827f 	stp	xzr, x0, [x19, #264]
    8648:	b4000040 	cbz	x0, 8650 <fwp_main_thread+0x170>
    864c:	f9008413 	str	x19, [x0, #264]
    8650:	f9001ad3 	str	x19, [x22, #48]
    8654:	39015a7f 	strb	wzr, [x19, #86]
    8658:	97ffed5b 	bl	3bc4 <fwp_block>
    865c:	f9408e62 	ldr	x2, [x19, #280]
    8660:	b4000142 	cbz	x2, 8688 <fwp_main_thread+0x1a8>
    8664:	a9520261 	ldp	x1, x0, [x19, #288]
    8668:	b4000ba1 	cbz	x1, 87dc <fwp_main_thread+0x2fc>
    866c:	f9009420 	str	x0, [x1, #296]
    8670:	f9409660 	ldr	x0, [x19, #296]
    8674:	b4000040 	cbz	x0, 867c <fwp_main_thread+0x19c>
    8678:	f9009001 	str	x1, [x0, #288]
    867c:	91080260 	add	x0, x19, #0x200
    8680:	f900967f 	str	xzr, [x19, #296]
    8684:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8688:	39415660 	ldrb	w0, [x19, #85]
    868c:	f94006c2 	ldr	x2, [x22, #8]
    8690:	36000960 	tbz	w0, #0, 87bc <fwp_main_thread+0x2dc>
    8694:	a9508261 	ldp	x1, x0, [x19, #264]
    8698:	b4000a61 	cbz	x1, 87e4 <fwp_main_thread+0x304>
    869c:	f9008820 	str	x0, [x1, #272]
    86a0:	b4000040 	cbz	x0, 86a8 <fwp_main_thread+0x1c8>
    86a4:	f9008401 	str	x1, [x0, #264]
    86a8:	91080260 	add	x0, x19, #0x200
    86ac:	3901567f 	strb	wzr, [x19, #85]
    86b0:	aa0203f3 	mov	x19, x2
    86b4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    86b8:	f9401680 	ldr	x0, [x20, #40]
    86bc:	b5fffa20 	cbnz	x0, 8600 <fwp_main_thread+0x120>
    86c0:	9101c2a0 	add	x0, x21, #0x70
    86c4:	39014a99 	strb	w25, [x20, #82]
    86c8:	f94083f9 	ldr	x25, [sp, #256]
    86cc:	f9413c00 	ldr	x0, [x0, #632]
    86d0:	b4001560 	cbz	x0, 897c <fwp_main_thread+0x49c>
    86d4:	9101c2a0 	add	x0, x21, #0x70
    86d8:	f9415401 	ldr	x1, [x0, #680]
    86dc:	b902a01f 	str	wzr, [x0, #672]
    86e0:	eb13003f 	cmp	x1, x19
    86e4:	54001681 	b.ne	89b4 <fwp_main_thread+0x4d4>  // b.any
    86e8:	b4000913 	cbz	x19, 8808 <fwp_main_thread+0x328>
    86ec:	9101c2a0 	add	x0, x21, #0x70
    86f0:	52800021 	mov	w1, #0x1                   	// #1
    86f4:	39014a61 	strb	w1, [x19, #82]
    86f8:	f9412805 	ldr	x5, [x0, #592]
    86fc:	b4000865 	cbz	x5, 8808 <fwp_main_thread+0x328>
    8700:	394140a0 	ldrb	w0, [x5, #80]
    8704:	37000060 	tbnz	w0, #0, 8710 <fwp_main_thread+0x230>
    8708:	aa0503e0 	mov	x0, x5
    870c:	97ffe621 	bl	1f90 <fwp_cancel_tree.part.0>
    8710:	f9409ca5 	ldr	x5, [x5, #312]
    8714:	b5ffff65 	cbnz	x5, 8700 <fwp_main_thread+0x220>
    8718:	9101c2b4 	add	x20, x21, #0x70
    871c:	52800036 	mov	w22, #0x1                   	// #1
    8720:	f9402a60 	ldr	x0, [x19, #80]
    8724:	f2001c1f 	tst	x0, #0xff000000ff
    8728:	540000e1 	b.ne	8744 <fwp_main_thread+0x264>  // b.any
    872c:	f9401280 	ldr	x0, [x20, #32]
    8730:	39015276 	strb	w22, [x19, #84]
    8734:	f900827f 	str	xzr, [x19, #256]
    8738:	b40005a0 	cbz	x0, 87ec <fwp_main_thread+0x30c>
    873c:	f9008013 	str	x19, [x0, #256]
    8740:	f9001293 	str	x19, [x20, #32]
    8744:	97ffed20 	bl	3bc4 <fwp_block>
    8748:	97ffecb2 	bl	3a10 <fwp_free_zombie>
    874c:	f9412a80 	ldr	x0, [x20, #592]
    8750:	b40005c0 	cbz	x0, 8808 <fwp_main_thread+0x328>
    8754:	f9415693 	ldr	x19, [x20, #680]
    8758:	17fffff2 	b	8720 <fwp_main_thread+0x240>
    875c:	97ffe661 	bl	20e0 <fwp_now_ns>
    8760:	f9403281 	ldr	x1, [x20, #96]
    8764:	eb01001f 	cmp	x0, x1
    8768:	54000fca 	b.ge	8960 <fwp_main_thread+0x480>  // b.tcont
    876c:	39414680 	ldrb	w0, [x20, #81]
    8770:	39414a62 	ldrb	w2, [x19, #82]
    8774:	3707f500 	tbnz	w0, #0, 8614 <fwp_main_thread+0x134>
    8778:	f9403281 	ldr	x1, [x20, #96]
    877c:	370001c2 	tbnz	w2, #0, 87b4 <fwp_main_thread+0x2d4>
    8780:	f9403260 	ldr	x0, [x19, #96]
    8784:	b4000180 	cbz	x0, 87b4 <fwp_main_thread+0x2d4>
    8788:	b4000061 	cbz	x1, 8794 <fwp_main_thread+0x2b4>
    878c:	eb01001f 	cmp	x0, x1
    8790:	9a81d000 	csel	x0, x0, x1, le
    8794:	f9402281 	ldr	x1, [x20, #64]
    8798:	a911fe77 	stp	x23, xzr, [x19, #280]
    879c:	f9009661 	str	x1, [x19, #296]
    87a0:	b4001241 	cbz	x1, 89e8 <fwp_main_thread+0x508>
    87a4:	f9009033 	str	x19, [x1, #288]
    87a8:	aa0003e1 	mov	x1, x0
    87ac:	f9002293 	str	x19, [x20, #64]
    87b0:	17ffffa2 	b	8638 <fwp_main_thread+0x158>
    87b4:	f9402280 	ldr	x0, [x20, #64]
    87b8:	17ffff9a 	b	8620 <fwp_main_thread+0x140>
    87bc:	aa0203f3 	mov	x19, x2
    87c0:	17ffff8e 	b	85f8 <fwp_main_thread+0x118>
    87c4:	a911fe77 	stp	x23, xzr, [x19, #280]
    87c8:	f9009660 	str	x0, [x19, #296]
    87cc:	b4000040 	cbz	x0, 87d4 <fwp_main_thread+0x2f4>
    87d0:	f9009013 	str	x19, [x0, #288]
    87d4:	f9002293 	str	x19, [x20, #64]
    87d8:	17ffff9f 	b	8654 <fwp_main_thread+0x174>
    87dc:	f9000040 	str	x0, [x2]
    87e0:	17ffffa5 	b	8674 <fwp_main_thread+0x194>
    87e4:	f9001ac0 	str	x0, [x22, #48]
    87e8:	17ffffae 	b	86a0 <fwp_main_thread+0x1c0>
    87ec:	f9001693 	str	x19, [x20, #40]
    87f0:	17ffffd4 	b	8740 <fwp_main_thread+0x260>
    87f4:	f9413ec0 	ldr	x0, [x22, #632]
    87f8:	b4000c00 	cbz	x0, 8978 <fwp_main_thread+0x498>
    87fc:	f94156c0 	ldr	x0, [x22, #680]
    8800:	b902a2df 	str	wzr, [x22, #672]
    8804:	b5000d80 	cbnz	x0, 89b4 <fwp_main_thread+0x4d4>
    8808:	9101c2b4 	add	x20, x21, #0x70
    880c:	97ffec81 	bl	3a10 <fwp_free_zombie>
    8810:	f9401680 	ldr	x0, [x20, #40]
    8814:	b5000d00 	cbnz	x0, 89b4 <fwp_main_thread+0x4d4>
    8818:	f9401a80 	ldr	x0, [x20, #48]
    881c:	b5000cc0 	cbnz	x0, 89b4 <fwp_main_thread+0x4d4>
    8820:	b9404293 	ldr	w19, [x20, #64]
    8824:	340001d3 	cbz	w19, 885c <fwp_main_thread+0x37c>
    8828:	93407e76 	sxtw	x22, w19
    882c:	51000673 	sub	w19, w19, #0x1
    8830:	d1000ad6 	sub	x22, x22, #0x2
    8834:	91014297 	add	x23, x20, #0x50
    8838:	cb3342d6 	sub	x22, x22, w19, uxtw
    883c:	93407e73 	sxtw	x19, w19
    8840:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8844:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8848:	b9004293 	str	w19, [x20, #64]
    884c:	d1000673 	sub	x19, x19, #0x1
    8850:	97ffe35c 	bl	15c0 <munmap@plt>
    8854:	eb16027f 	cmp	x19, x22
    8858:	54ffff41 	b.ne	8840 <fwp_main_thread+0x360>  // b.any
    885c:	900000d3 	adrp	x19, 20000 <__data_start>
    8860:	91004260 	add	x0, x19, #0x10
    8864:	b9404000 	ldr	w0, [x0, #64]
    8868:	37f80040 	tbnz	w0, #31, 8870 <fwp_main_thread+0x390>
    886c:	97ffe311 	bl	14b0 <close@plt>
    8870:	9101c2a0 	add	x0, x21, #0x70
    8874:	91004261 	add	x1, x19, #0x10
    8878:	12800002 	mov	w2, #0xffffffff            	// #-1
    887c:	d2800013 	mov	x19, #0x0                   	// #0
    8880:	f9415816 	ldr	x22, [x0, #688]
    8884:	b9004022 	str	w2, [x1, #64]
    8888:	f9415c14 	ldr	x20, [x0, #696]
    888c:	b4000176 	cbz	x22, 88b8 <fwp_main_thread+0x3d8>
    8890:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8894:	b40000c0 	cbz	x0, 88ac <fwp_main_thread+0x3cc>
    8898:	f9400001 	ldr	x1, [x0]
    889c:	b50008c1 	cbnz	x1, 89b4 <fwp_main_thread+0x4d4>
    88a0:	f9400401 	ldr	x1, [x0, #8]
    88a4:	b5000881 	cbnz	x1, 89b4 <fwp_main_thread+0x4d4>
    88a8:	97ffe95e 	bl	2e20 <fwp_mem_free>
    88ac:	91000673 	add	x19, x19, #0x1
    88b0:	eb16027f 	cmp	x19, x22
    88b4:	54fffee1 	b.ne	8890 <fwp_main_thread+0x3b0>  // b.any
    88b8:	aa1403e0 	mov	x0, x20
    88bc:	97ffe959 	bl	2e20 <fwp_mem_free>
    88c0:	9101c2a0 	add	x0, x21, #0x70
    88c4:	f9415413 	ldr	x19, [x0, #680]
    88c8:	f901581f 	str	xzr, [x0, #688]
    88cc:	f9015c1f 	str	xzr, [x0, #696]
    88d0:	b40001f3 	cbz	x19, 890c <fwp_main_thread+0x42c>
    88d4:	f9401661 	ldr	x1, [x19, #40]
    88d8:	b50006e1 	cbnz	x1, 89b4 <fwp_main_thread+0x4d4>
    88dc:	f9405661 	ldr	x1, [x19, #168]
    88e0:	b50006a1 	cbnz	x1, 89b4 <fwp_main_thread+0x4d4>
    88e4:	f9413c01 	ldr	x1, [x0, #632]
    88e8:	b5000661 	cbnz	x1, 89b4 <fwp_main_thread+0x4d4>
    88ec:	f9414400 	ldr	x0, [x0, #648]
    88f0:	b5000620 	cbnz	x0, 89b4 <fwp_main_thread+0x4d4>
    88f4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    88f8:	90000140 	adrp	x0, 30000 <alt.4+0xfcd0>
    88fc:	910cc000 	add	x0, x0, #0x330
    8900:	97ffe2dc 	bl	1470 <memset@plt>
    8904:	aa1303e0 	mov	x0, x19
    8908:	97ffe946 	bl	2e20 <fwp_mem_free>
    890c:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    8910:	f947ec00 	ldr	x0, [x0, #4056]
    8914:	9101c2b5 	add	x21, x21, #0x70
    8918:	f9400000 	ldr	x0, [x0]
    891c:	f90006bf 	str	xzr, [x21, #8]
    8920:	f90156bf 	str	xzr, [x21, #680]
    8924:	97ffe32b 	bl	15d0 <fflush@plt>
    8928:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14c18>
    892c:	f947f400 	ldr	x0, [x0, #4072]
    8930:	f9405fe2 	ldr	x2, [sp, #184]
    8934:	f9400001 	ldr	x1, [x0]
    8938:	eb010042 	subs	x2, x2, x1
    893c:	d2800001 	mov	x1, #0x0                   	// #0
    8940:	540006a1 	b.ne	8a14 <fwp_main_thread+0x534>  // b.any
    8944:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8948:	d2800000 	mov	x0, #0x0                   	// #0
    894c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8950:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8954:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8958:	910443ff 	add	sp, sp, #0x110
    895c:	d65f03c0 	ret
    8960:	39414280 	ldrb	w0, [x20, #80]
    8964:	3707f040 	tbnz	w0, #0, 876c <fwp_main_thread+0x28c>
    8968:	aa1403e0 	mov	x0, x20
    896c:	97ffe589 	bl	1f90 <fwp_cancel_tree.part.0>
    8970:	39414680 	ldrb	w0, [x20, #81]
    8974:	17ffff7f 	b	8770 <fwp_main_thread+0x290>
    8978:	d2800013 	mov	x19, #0x0                   	// #0
    897c:	9101c2b4 	add	x20, x21, #0x70
    8980:	f9414680 	ldr	x0, [x20, #648]
    8984:	b5ffea80 	cbnz	x0, 86d4 <fwp_main_thread+0x1f4>
    8988:	f9413a80 	ldr	x0, [x20, #624]
    898c:	97ffe925 	bl	2e20 <fwp_mem_free>
    8990:	f9013a9f 	str	xzr, [x20, #624]
    8994:	f901429f 	str	xzr, [x20, #640]
    8998:	f9415680 	ldr	x0, [x20, #680]
    899c:	b40002d3 	cbz	x19, 89f4 <fwp_main_thread+0x514>
    89a0:	f900567f 	str	xzr, [x19, #168]
    89a4:	f9005e7f 	str	xzr, [x19, #184]
    89a8:	b902a29f 	str	wzr, [x20, #672]
    89ac:	eb00027f 	cmp	x19, x0
    89b0:	54ffe9e0 	b.eq	86ec <fwp_main_thread+0x20c>  // b.none
    89b4:	f90083f9 	str	x25, [sp, #256]
    89b8:	97ffe2ce 	bl	14f0 <abort@plt>
    89bc:	d0ffffc0 	adrp	x0, 2000 <fwp_cancel_tree.part.0+0x70>
    89c0:	91161000 	add	x0, x0, #0x584
    89c4:	940001d3 	bl	9110 <atexit>
    89c8:	17fffed7 	b	8524 <fwp_main_thread+0x44>
    89cc:	97ffe749 	bl	26f0 <fwp_heap_init>
    89d0:	17fffed2 	b	8518 <fwp_main_thread+0x38>
    89d4:	97fff523 	bl	5e60 <f0>
    89d8:	f9014e60 	str	x0, [x19, #664]
    89dc:	52800021 	mov	w1, #0x1                   	// #1
    89e0:	b9029661 	str	w1, [x19, #660]
    89e4:	17fffefc 	b	85d4 <fwp_main_thread+0xf4>
    89e8:	aa0003e1 	mov	x1, x0
    89ec:	f9002293 	str	x19, [x20, #64]
    89f0:	17ffff12 	b	8638 <fwp_main_thread+0x158>
    89f4:	b902a29f 	str	wzr, [x20, #672]
    89f8:	b4fff080 	cbz	x0, 8808 <fwp_main_thread+0x328>
    89fc:	17ffffee 	b	89b4 <fwp_main_thread+0x4d4>
    8a00:	b0000000 	adrp	x0, 9000 <__modti3+0x260>
    8a04:	91132000 	add	x0, x0, #0x4c8
    8a08:	a90f63f7 	stp	x23, x24, [sp, #240]
    8a0c:	f90083f9 	str	x25, [sp, #256]
    8a10:	97ffe5a4 	bl	20a0 <fwp_trap>
    8a14:	f90083f9 	str	x25, [sp, #256]
    8a18:	97ffe2a2 	bl	14a0 <__stack_chk_fail@plt>
    8a1c:	d503201f 	nop

0000000000008a20 <__divti3>:
    8a20:	d503245f 	bti	c
    8a24:	d2800004 	mov	x4, #0x0                   	// #0
    8a28:	b7f80721 	tbnz	x1, #63, 8b0c <__divti3+0xec>
    8a2c:	b6f80083 	tbz	x3, #63, 8a3c <__divti3+0x1c>
    8a30:	eb0203e2 	negs	x2, x2
    8a34:	aa2403e4 	mvn	x4, x4
    8a38:	da0303e3 	ngc	x3, x3
    8a3c:	aa0203e6 	mov	x6, x2
    8a40:	aa0003e7 	mov	x7, x0
    8a44:	aa0103e5 	mov	x5, x1
    8a48:	b5000583 	cbnz	x3, 8af8 <__divti3+0xd8>
    8a4c:	eb01005f 	cmp	x2, x1
    8a50:	54000e69 	b.ls	8c1c <__divti3+0x1fc>  // b.plast
    8a54:	dac01040 	clz	x0, x2
    8a58:	b40000e0 	cbz	x0, 8a74 <__divti3+0x54>
    8a5c:	4b0003e1 	neg	w1, w0
    8a60:	9ac020a5 	lsl	x5, x5, x0
    8a64:	9ac02046 	lsl	x6, x2, x0
    8a68:	9ac124e1 	lsr	x1, x7, x1
    8a6c:	aa050025 	orr	x5, x1, x5
    8a70:	9ac020e7 	lsl	x7, x7, x0
    8a74:	d360fcc8 	lsr	x8, x6, #32
    8a78:	92407cc2 	and	x2, x6, #0xffffffff
    8a7c:	9ac808a3 	udiv	x3, x5, x8
    8a80:	9b089465 	msub	x5, x3, x8, x5
    8a84:	aa0303e0 	mov	x0, x3
    8a88:	9b037c41 	mul	x1, x2, x3
    8a8c:	93c780a5 	extr	x5, x5, x7, #32
    8a90:	eb05003f 	cmp	x1, x5
    8a94:	540000a9 	b.ls	8aa8 <__divti3+0x88>  // b.plast
    8a98:	ab0500c5 	adds	x5, x6, x5
    8a9c:	d1000460 	sub	x0, x3, #0x1
    8aa0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8aa4:	540015a8 	b.hi	8d58 <__divti3+0x338>  // b.pmore
    8aa8:	cb0100a5 	sub	x5, x5, x1
    8aac:	9ac808a3 	udiv	x3, x5, x8
    8ab0:	9b089465 	msub	x5, x3, x8, x5
    8ab4:	aa0303e1 	mov	x1, x3
    8ab8:	9b037c42 	mul	x2, x2, x3
    8abc:	aa0703e3 	mov	x3, x7
    8ac0:	b3607ca3 	bfi	x3, x5, #32, #32
    8ac4:	eb03005f 	cmp	x2, x3
    8ac8:	540000c9 	b.ls	8ae0 <__divti3+0xc0>  // b.plast
    8acc:	ab0300c3 	adds	x3, x6, x3
    8ad0:	d1000425 	sub	x5, x1, #0x1
    8ad4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8ad8:	d1000821 	sub	x1, x1, #0x2
    8adc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8ae0:	aa008020 	orr	x0, x1, x0, lsl #32
    8ae4:	d2800001 	mov	x1, #0x0                   	// #0
    8ae8:	b4000064 	cbz	x4, 8af4 <__divti3+0xd4>
    8aec:	eb0003e0 	negs	x0, x0
    8af0:	da0103e1 	ngc	x1, x1
    8af4:	d65f03c0 	ret
    8af8:	eb01007f 	cmp	x3, x1
    8afc:	54000109 	b.ls	8b1c <__divti3+0xfc>  // b.plast
    8b00:	d2800001 	mov	x1, #0x0                   	// #0
    8b04:	d2800000 	mov	x0, #0x0                   	// #0
    8b08:	17fffff8 	b	8ae8 <__divti3+0xc8>
    8b0c:	eb0003e0 	negs	x0, x0
    8b10:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8b14:	da0103e1 	ngc	x1, x1
    8b18:	17ffffc5 	b	8a2c <__divti3+0xc>
    8b1c:	dac01067 	clz	x7, x3
    8b20:	b40010e7 	cbz	x7, 8d3c <__divti3+0x31c>
    8b24:	d2800805 	mov	x5, #0x40                  	// #64
    8b28:	cb0700a5 	sub	x5, x5, x7
    8b2c:	9ac72063 	lsl	x3, x3, x7
    8b30:	9ac52448 	lsr	x8, x2, x5
    8b34:	aa030108 	orr	x8, x8, x3
    8b38:	9ac52426 	lsr	x6, x1, x5
    8b3c:	92407d0a 	and	x10, x8, #0xffffffff
    8b40:	d360fd09 	lsr	x9, x8, #32
    8b44:	9ac52403 	lsr	x3, x0, x5
    8b48:	9ac72021 	lsl	x1, x1, x7
    8b4c:	aa010063 	orr	x3, x3, x1
    8b50:	9ac72042 	lsl	x2, x2, x7
    8b54:	9ac908cb 	udiv	x11, x6, x9
    8b58:	9b099965 	msub	x5, x11, x9, x6
    8b5c:	aa0b03e1 	mov	x1, x11
    8b60:	9b0b7d46 	mul	x6, x10, x11
    8b64:	93c380a5 	extr	x5, x5, x3, #32
    8b68:	eb0500df 	cmp	x6, x5
    8b6c:	540000a9 	b.ls	8b80 <__divti3+0x160>  // b.plast
    8b70:	ab050105 	adds	x5, x8, x5
    8b74:	d1000561 	sub	x1, x11, #0x1
    8b78:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8b7c:	54000f48 	b.hi	8d64 <__divti3+0x344>  // b.pmore
    8b80:	cb0600a6 	sub	x6, x5, x6
    8b84:	9ac908cb 	udiv	x11, x6, x9
    8b88:	9b099969 	msub	x9, x11, x9, x6
    8b8c:	aa0b03e5 	mov	x5, x11
    8b90:	9b0b7d4a 	mul	x10, x10, x11
    8b94:	b3607d23 	bfi	x3, x9, #32, #32
    8b98:	eb03015f 	cmp	x10, x3
    8b9c:	540000a9 	b.ls	8bb0 <__divti3+0x190>  // b.plast
    8ba0:	ab030103 	adds	x3, x8, x3
    8ba4:	d1000565 	sub	x5, x11, #0x1
    8ba8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8bac:	54000e28 	b.hi	8d70 <__divti3+0x350>  // b.pmore
    8bb0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8bb4:	92407c48 	and	x8, x2, #0xffffffff
    8bb8:	2a0503e5 	mov	w5, w5
    8bbc:	d360fc42 	lsr	x2, x2, #32
    8bc0:	d360fc26 	lsr	x6, x1, #32
    8bc4:	cb0a0063 	sub	x3, x3, x10
    8bc8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8bcc:	9b087caa 	mul	x10, x5, x8
    8bd0:	9b087cc8 	mul	x8, x6, x8
    8bd4:	9b0220a5 	madd	x5, x5, x2, x8
    8bd8:	9b027cc6 	mul	x6, x6, x2
    8bdc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8be0:	8b0900c5 	add	x5, x6, x9
    8be4:	eb02011f 	cmp	x8, x2
    8be8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8bec:	8b4280c6 	add	x6, x6, x2, lsr #32
    8bf0:	eb06007f 	cmp	x3, x6
    8bf4:	540000e3 	b.cc	8c10 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8bf8:	92407d4a 	and	x10, x10, #0xffffffff
    8bfc:	9ac72000 	lsl	x0, x0, x7
    8c00:	8b028142 	add	x2, x10, x2, lsl #32
    8c04:	eb02001f 	cmp	x0, x2
    8c08:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8c0c:	54000a01 	b.ne	8d4c <__divti3+0x32c>  // b.any
    8c10:	d1000420 	sub	x0, x1, #0x1
    8c14:	d2800001 	mov	x1, #0x0                   	// #0
    8c18:	17ffffb4 	b	8ae8 <__divti3+0xc8>
    8c1c:	b5000062 	cbnz	x2, 8c28 <__divti3+0x208>
    8c20:	d2800022 	mov	x2, #0x1                   	// #1
    8c24:	9ac30846 	udiv	x6, x2, x3
    8c28:	dac010c8 	clz	x8, x6
    8c2c:	b5000408 	cbnz	x8, 8cac <__divti3+0x28c>
    8c30:	d360fcc9 	lsr	x9, x6, #32
    8c34:	92407cc5 	and	x5, x6, #0xffffffff
    8c38:	cb060023 	sub	x3, x1, x6
    8c3c:	d2800021 	mov	x1, #0x1                   	// #1
    8c40:	9ac90868 	udiv	x8, x3, x9
    8c44:	9b098d03 	msub	x3, x8, x9, x3
    8c48:	aa0803e0 	mov	x0, x8
    8c4c:	9b057d02 	mul	x2, x8, x5
    8c50:	93c78063 	extr	x3, x3, x7, #32
    8c54:	eb03005f 	cmp	x2, x3
    8c58:	540000a9 	b.ls	8c6c <__divti3+0x24c>  // b.plast
    8c5c:	ab0300c3 	adds	x3, x6, x3
    8c60:	d1000500 	sub	x0, x8, #0x1
    8c64:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8c68:	54000968 	b.hi	8d94 <__divti3+0x374>  // b.pmore
    8c6c:	cb020063 	sub	x3, x3, x2
    8c70:	9ac90862 	udiv	x2, x3, x9
    8c74:	aa0203e8 	mov	x8, x2
    8c78:	9b098c42 	msub	x2, x2, x9, x3
    8c7c:	aa0703e3 	mov	x3, x7
    8c80:	9b057d05 	mul	x5, x8, x5
    8c84:	b3607c43 	bfi	x3, x2, #32, #32
    8c88:	eb0300bf 	cmp	x5, x3
    8c8c:	540000c9 	b.ls	8ca4 <__divti3+0x284>  // b.plast
    8c90:	ab0300c2 	adds	x2, x6, x3
    8c94:	d1000503 	sub	x3, x8, #0x1
    8c98:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8c9c:	d1000908 	sub	x8, x8, #0x2
    8ca0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8ca4:	aa008100 	orr	x0, x8, x0, lsl #32
    8ca8:	17ffff90 	b	8ae8 <__divti3+0xc8>
    8cac:	9ac820c6 	lsl	x6, x6, x8
    8cb0:	d2800803 	mov	x3, #0x40                  	// #64
    8cb4:	cb080063 	sub	x3, x3, x8
    8cb8:	d360fcc9 	lsr	x9, x6, #32
    8cbc:	9ac82027 	lsl	x7, x1, x8
    8cc0:	92407cc5 	and	x5, x6, #0xffffffff
    8cc4:	9ac32422 	lsr	x2, x1, x3
    8cc8:	9ac32403 	lsr	x3, x0, x3
    8ccc:	aa070063 	orr	x3, x3, x7
    8cd0:	9ac9084a 	udiv	x10, x2, x9
    8cd4:	9ac82007 	lsl	x7, x0, x8
    8cd8:	9b098940 	msub	x0, x10, x9, x2
    8cdc:	aa0a03e1 	mov	x1, x10
    8ce0:	9b0a7ca2 	mul	x2, x5, x10
    8ce4:	93c38000 	extr	x0, x0, x3, #32
    8ce8:	eb00005f 	cmp	x2, x0
    8cec:	540000a9 	b.ls	8d00 <__divti3+0x2e0>  // b.plast
    8cf0:	ab0000c0 	adds	x0, x6, x0
    8cf4:	d1000541 	sub	x1, x10, #0x1
    8cf8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    8cfc:	54000468 	b.hi	8d88 <__divti3+0x368>  // b.pmore
    8d00:	cb020000 	sub	x0, x0, x2
    8d04:	9ac9080a 	udiv	x10, x0, x9
    8d08:	9b098140 	msub	x0, x10, x9, x0
    8d0c:	aa0a03e2 	mov	x2, x10
    8d10:	9b0a7ca8 	mul	x8, x5, x10
    8d14:	b3607c03 	bfi	x3, x0, #32, #32
    8d18:	eb03011f 	cmp	x8, x3
    8d1c:	540000a9 	b.ls	8d30 <__divti3+0x310>  // b.plast
    8d20:	ab0300c3 	adds	x3, x6, x3
    8d24:	d1000542 	sub	x2, x10, #0x1
    8d28:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8d2c:	54000288 	b.hi	8d7c <__divti3+0x35c>  // b.pmore
    8d30:	cb080063 	sub	x3, x3, x8
    8d34:	aa018041 	orr	x1, x2, x1, lsl #32
    8d38:	17ffffc2 	b	8c40 <__divti3+0x220>
    8d3c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8d40:	d2800001 	mov	x1, #0x0                   	// #0
    8d44:	9a9f87e0 	cset	x0, ls	// ls = plast
    8d48:	17ffff68 	b	8ae8 <__divti3+0xc8>
    8d4c:	aa0103e0 	mov	x0, x1
    8d50:	d2800001 	mov	x1, #0x0                   	// #0
    8d54:	17ffff65 	b	8ae8 <__divti3+0xc8>
    8d58:	d1000860 	sub	x0, x3, #0x2
    8d5c:	8b0600a5 	add	x5, x5, x6
    8d60:	17ffff52 	b	8aa8 <__divti3+0x88>
    8d64:	d1000961 	sub	x1, x11, #0x2
    8d68:	8b0800a5 	add	x5, x5, x8
    8d6c:	17ffff85 	b	8b80 <__divti3+0x160>
    8d70:	d1000965 	sub	x5, x11, #0x2
    8d74:	8b080063 	add	x3, x3, x8
    8d78:	17ffff8e 	b	8bb0 <__divti3+0x190>
    8d7c:	d1000942 	sub	x2, x10, #0x2
    8d80:	8b060063 	add	x3, x3, x6
    8d84:	17ffffeb 	b	8d30 <__divti3+0x310>
    8d88:	d1000941 	sub	x1, x10, #0x2
    8d8c:	8b060000 	add	x0, x0, x6
    8d90:	17ffffdc 	b	8d00 <__divti3+0x2e0>
    8d94:	d1000900 	sub	x0, x8, #0x2
    8d98:	8b060063 	add	x3, x3, x6
    8d9c:	17ffffb4 	b	8c6c <__divti3+0x24c>

0000000000008da0 <__modti3>:
    8da0:	d503245f 	bti	c
    8da4:	d2800004 	mov	x4, #0x0                   	// #0
    8da8:	b6f80081 	tbz	x1, #63, 8db8 <__modti3+0x18>
    8dac:	eb0003e0 	negs	x0, x0
    8db0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8db4:	da0103e1 	ngc	x1, x1
    8db8:	f100007f 	cmp	x3, #0x0
    8dbc:	5400128b 	b.lt	900c <__modti3+0x26c>  // b.tstop
    8dc0:	aa0003e7 	mov	x7, x0
    8dc4:	aa0103e6 	mov	x6, x1
    8dc8:	540004e1 	b.ne	8e64 <__modti3+0xc4>  // b.any
    8dcc:	eb02003f 	cmp	x1, x2
    8dd0:	54000dc2 	b.cs	8f88 <__modti3+0x1e8>  // b.hs, b.nlast
    8dd4:	dac01043 	clz	x3, x2
    8dd8:	aa0303e5 	mov	x5, x3
    8ddc:	b40000e3 	cbz	x3, 8df8 <__modti3+0x58>
    8de0:	4b0303e6 	neg	w6, w3
    8de4:	9ac32021 	lsl	x1, x1, x3
    8de8:	9ac32042 	lsl	x2, x2, x3
    8dec:	9ac62406 	lsr	x6, x0, x6
    8df0:	aa0100c6 	orr	x6, x6, x1
    8df4:	9ac32007 	lsl	x7, x0, x3
    8df8:	d360fc40 	lsr	x0, x2, #32
    8dfc:	92407c43 	and	x3, x2, #0xffffffff
    8e00:	9ac008c1 	udiv	x1, x6, x0
    8e04:	9b009826 	msub	x6, x1, x0, x6
    8e08:	9b017c61 	mul	x1, x3, x1
    8e0c:	93c780c6 	extr	x6, x6, x7, #32
    8e10:	eb06003f 	cmp	x1, x6
    8e14:	540000a9 	b.ls	8e28 <__modti3+0x88>  // b.plast
    8e18:	ab060046 	adds	x6, x2, x6
    8e1c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8e20:	8b0200c8 	add	x8, x6, x2
    8e24:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8e28:	cb0100c6 	sub	x6, x6, x1
    8e2c:	9ac008c8 	udiv	x8, x6, x0
    8e30:	9b009901 	msub	x1, x8, x0, x6
    8e34:	aa0703e0 	mov	x0, x7
    8e38:	9b087c63 	mul	x3, x3, x8
    8e3c:	b3607c20 	bfi	x0, x1, #32, #32
    8e40:	eb00007f 	cmp	x3, x0
    8e44:	54001088 	b.hi	9054 <__modti3+0x2b4>  // b.pmore
    8e48:	cb030000 	sub	x0, x0, x3
    8e4c:	9ac52400 	lsr	x0, x0, x5
    8e50:	d2800001 	mov	x1, #0x0                   	// #0
    8e54:	b4000064 	cbz	x4, 8e60 <__modti3+0xc0>
    8e58:	eb0003e0 	negs	x0, x0
    8e5c:	da0103e1 	ngc	x1, x1
    8e60:	d65f03c0 	ret
    8e64:	dac01066 	clz	x6, x3
    8e68:	eb03003f 	cmp	x1, x3
    8e6c:	54ffff43 	b.cc	8e54 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8e70:	93407cc5 	sxtw	x5, w6
    8e74:	d2800808 	mov	x8, #0x40                  	// #64
    8e78:	cb050108 	sub	x8, x8, x5
    8e7c:	9ac62063 	lsl	x3, x3, x6
    8e80:	9ac62025 	lsl	x5, x1, x6
    8e84:	9ac82447 	lsr	x7, x2, x8
    8e88:	aa0300e7 	orr	x7, x7, x3
    8e8c:	9ac82423 	lsr	x3, x1, x8
    8e90:	92407cec 	and	x12, x7, #0xffffffff
    8e94:	d360fcea 	lsr	x10, x7, #32
    8e98:	9ac82401 	lsr	x1, x0, x8
    8e9c:	aa050021 	orr	x1, x1, x5
    8ea0:	9ac62042 	lsl	x2, x2, x6
    8ea4:	9ac62000 	lsl	x0, x0, x6
    8ea8:	9aca086b 	udiv	x11, x3, x10
    8eac:	9b0a8d63 	msub	x3, x11, x10, x3
    8eb0:	aa0b03e5 	mov	x5, x11
    8eb4:	9b0b7d89 	mul	x9, x12, x11
    8eb8:	93c18063 	extr	x3, x3, x1, #32
    8ebc:	eb03013f 	cmp	x9, x3
    8ec0:	540000a9 	b.ls	8ed4 <__modti3+0x134>  // b.plast
    8ec4:	ab0300e3 	adds	x3, x7, x3
    8ec8:	d1000565 	sub	x5, x11, #0x1
    8ecc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8ed0:	54001168 	b.hi	90fc <__modti3+0x35c>  // b.pmore
    8ed4:	cb090063 	sub	x3, x3, x9
    8ed8:	9aca086b 	udiv	x11, x3, x10
    8edc:	9b0a8d6a 	msub	x10, x11, x10, x3
    8ee0:	aa0b03e9 	mov	x9, x11
    8ee4:	9b0b7d8c 	mul	x12, x12, x11
    8ee8:	b3607d41 	bfi	x1, x10, #32, #32
    8eec:	eb01019f 	cmp	x12, x1
    8ef0:	540000a9 	b.ls	8f04 <__modti3+0x164>  // b.plast
    8ef4:	ab0100e1 	adds	x1, x7, x1
    8ef8:	d1000569 	sub	x9, x11, #0x1
    8efc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8f00:	54000f88 	b.hi	90f0 <__modti3+0x350>  // b.pmore
    8f04:	aa058123 	orr	x3, x9, x5, lsl #32
    8f08:	92407c4b 	and	x11, x2, #0xffffffff
    8f0c:	2a0903e9 	mov	w9, w9
    8f10:	d360fc4a 	lsr	x10, x2, #32
    8f14:	d360fc63 	lsr	x3, x3, #32
    8f18:	cb0c0021 	sub	x1, x1, x12
    8f1c:	aa0a03ec 	mov	x12, x10
    8f20:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    8f24:	9b0b7d25 	mul	x5, x9, x11
    8f28:	9b0b7c6b 	mul	x11, x3, x11
    8f2c:	9b0a2d29 	madd	x9, x9, x10, x11
    8f30:	92407caa 	and	x10, x5, #0xffffffff
    8f34:	9b0c7c63 	mul	x3, x3, x12
    8f38:	8b458125 	add	x5, x9, x5, lsr #32
    8f3c:	8b0d0069 	add	x9, x3, x13
    8f40:	eb05017f 	cmp	x11, x5
    8f44:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    8f48:	8b058149 	add	x9, x10, x5, lsl #32
    8f4c:	8b458063 	add	x3, x3, x5, lsr #32
    8f50:	eb03003f 	cmp	x1, x3
    8f54:	54000063 	b.cc	8f60 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8f58:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    8f5c:	54000082 	b.cs	8f6c <__modti3+0x1cc>  // b.hs, b.nlast
    8f60:	eb020129 	subs	x9, x9, x2
    8f64:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8f68:	cb070063 	sub	x3, x3, x7
    8f6c:	eb090000 	subs	x0, x0, x9
    8f70:	da030021 	sbc	x1, x1, x3
    8f74:	9ac62400 	lsr	x0, x0, x6
    8f78:	9ac82028 	lsl	x8, x1, x8
    8f7c:	aa000100 	orr	x0, x8, x0
    8f80:	9ac62421 	lsr	x1, x1, x6
    8f84:	17ffffb4 	b	8e54 <__modti3+0xb4>
    8f88:	b5000062 	cbnz	x2, 8f94 <__modti3+0x1f4>
    8f8c:	d2800023 	mov	x3, #0x1                   	// #1
    8f90:	9ac20862 	udiv	x2, x3, x2
    8f94:	dac01048 	clz	x8, x2
    8f98:	aa0803e5 	mov	x5, x8
    8f9c:	b5000668 	cbnz	x8, 9068 <__modti3+0x2c8>
    8fa0:	cb020020 	sub	x0, x1, x2
    8fa4:	d360fc49 	lsr	x9, x2, #32
    8fa8:	92407c4a 	and	x10, x2, #0xffffffff
    8fac:	9ac90801 	udiv	x1, x0, x9
    8fb0:	9b098020 	msub	x0, x1, x9, x0
    8fb4:	9b0a7c21 	mul	x1, x1, x10
    8fb8:	93c78000 	extr	x0, x0, x7, #32
    8fbc:	eb00003f 	cmp	x1, x0
    8fc0:	540000a9 	b.ls	8fd4 <__modti3+0x234>  // b.plast
    8fc4:	ab000040 	adds	x0, x2, x0
    8fc8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8fcc:	8b020003 	add	x3, x0, x2
    8fd0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8fd4:	cb010001 	sub	x1, x0, x1
    8fd8:	9ac90820 	udiv	x0, x1, x9
    8fdc:	9b098403 	msub	x3, x0, x9, x1
    8fe0:	aa0703e1 	mov	x1, x7
    8fe4:	9b0a7c00 	mul	x0, x0, x10
    8fe8:	b3607c61 	bfi	x1, x3, #32, #32
    8fec:	eb01001f 	cmp	x0, x1
    8ff0:	540000a9 	b.ls	9004 <__modti3+0x264>  // b.plast
    8ff4:	ab010041 	adds	x1, x2, x1
    8ff8:	8b020022 	add	x2, x1, x2
    8ffc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9000:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9004:	cb000020 	sub	x0, x1, x0
    9008:	17ffff91 	b	8e4c <__modti3+0xac>
    900c:	eb0203e5 	negs	x5, x2
    9010:	aa0003e7 	mov	x7, x0
    9014:	da0303e8 	ngc	x8, x3
    9018:	aa0503e2 	mov	x2, x5
    901c:	aa0803e3 	mov	x3, x8
    9020:	aa0103e6 	mov	x6, x1
    9024:	b4ffed48 	cbz	x8, 8dcc <__modti3+0x2c>
    9028:	eb01011f 	cmp	x8, x1
    902c:	54fff148 	b.hi	8e54 <__modti3+0xb4>  // b.pmore
    9030:	dac01109 	clz	x9, x8
    9034:	2a0903e6 	mov	w6, w9
    9038:	b5fff1c9 	cbnz	x9, 8e70 <__modti3+0xd0>
    903c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9040:	54000068 	b.hi	904c <__modti3+0x2ac>  // b.pmore
    9044:	eb050007 	subs	x7, x0, x5
    9048:	da080021 	sbc	x1, x1, x8
    904c:	aa0703e0 	mov	x0, x7
    9050:	17ffff81 	b	8e54 <__modti3+0xb4>
    9054:	ab000040 	adds	x0, x2, x0
    9058:	8b020002 	add	x2, x0, x2
    905c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9060:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9064:	17ffff79 	b	8e48 <__modti3+0xa8>
    9068:	9ac82042 	lsl	x2, x2, x8
    906c:	d2800803 	mov	x3, #0x40                  	// #64
    9070:	cb080063 	sub	x3, x3, x8
    9074:	d360fc49 	lsr	x9, x2, #32
    9078:	9ac82027 	lsl	x7, x1, x8
    907c:	92407c4a 	and	x10, x2, #0xffffffff
    9080:	9ac32426 	lsr	x6, x1, x3
    9084:	9ac32403 	lsr	x3, x0, x3
    9088:	aa070063 	orr	x3, x3, x7
    908c:	9ac908c1 	udiv	x1, x6, x9
    9090:	9ac82007 	lsl	x7, x0, x8
    9094:	9b099820 	msub	x0, x1, x9, x6
    9098:	9b017d41 	mul	x1, x10, x1
    909c:	93c38000 	extr	x0, x0, x3, #32
    90a0:	eb00003f 	cmp	x1, x0
    90a4:	540000a9 	b.ls	90b8 <__modti3+0x318>  // b.plast
    90a8:	ab000040 	adds	x0, x2, x0
    90ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    90b0:	8b020006 	add	x6, x0, x2
    90b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    90b8:	cb010000 	sub	x0, x0, x1
    90bc:	9ac90801 	udiv	x1, x0, x9
    90c0:	9b098026 	msub	x6, x1, x9, x0
    90c4:	aa0303e0 	mov	x0, x3
    90c8:	9b017d41 	mul	x1, x10, x1
    90cc:	b3607cc0 	bfi	x0, x6, #32, #32
    90d0:	eb00003f 	cmp	x1, x0
    90d4:	540000a9 	b.ls	90e8 <__modti3+0x348>  // b.plast
    90d8:	ab000040 	adds	x0, x2, x0
    90dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    90e0:	8b020003 	add	x3, x0, x2
    90e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    90e8:	cb010000 	sub	x0, x0, x1
    90ec:	17ffffb0 	b	8fac <__modti3+0x20c>
    90f0:	d1000969 	sub	x9, x11, #0x2
    90f4:	8b070021 	add	x1, x1, x7
    90f8:	17ffff83 	b	8f04 <__modti3+0x164>
    90fc:	d1000965 	sub	x5, x11, #0x2
    9100:	8b070063 	add	x3, x3, x7
    9104:	17ffff74 	b	8ed4 <__modti3+0x134>
    9108:	d503201f 	nop
    910c:	d503201f 	nop

0000000000009110 <atexit>:
    9110:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9114:	f00000a2 	adrp	x2, 20000 <__data_start>
    9118:	d2800001 	mov	x1, #0x0                   	// #0
    911c:	910003fd 	mov	x29, sp
    9120:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9124:	f9400442 	ldr	x2, [x2, #8]
    9128:	17ffe09e 	b	13a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000912c <_fini>:
    912c:	d503201f 	nop
    9130:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9134:	910003fd 	mov	x29, sp
    9138:	a8c17bfd 	ldp	x29, x30, [sp], #16
    913c:	d65f03c0 	ret
