
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-199/fwp-local:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000012c8 <_init>:
    12c8:	d503201f 	nop
    12cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    12d0:	910003fd 	mov	x29, sp
    12d4:	94000188 	bl	18f4 <call_weak_fn>
    12d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    12dc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000012e0 <.plt>:
    12e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    12e4:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    12e8:	f946fe11 	ldr	x17, [x16, #3576]
    12ec:	9137e210 	add	x16, x16, #0xdf8
    12f0:	d61f0220 	br	x17
    12f4:	d503201f 	nop
    12f8:	d503201f 	nop
    12fc:	d503201f 	nop

0000000000001300 <memcpy@plt>:
    1300:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1304:	f9470211 	ldr	x17, [x16, #3584]
    1308:	91380210 	add	x16, x16, #0xe00
    130c:	d61f0220 	br	x17

0000000000001310 <sigaltstack@plt>:
    1310:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1314:	f9470611 	ldr	x17, [x16, #3592]
    1318:	91382210 	add	x16, x16, #0xe08
    131c:	d61f0220 	br	x17

0000000000001320 <_exit@plt>:
    1320:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1324:	f9470a11 	ldr	x17, [x16, #3600]
    1328:	91384210 	add	x16, x16, #0xe10
    132c:	d61f0220 	br	x17

0000000000001330 <strlen@plt>:
    1330:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1334:	f9470e11 	ldr	x17, [x16, #3608]
    1338:	91386210 	add	x16, x16, #0xe18
    133c:	d61f0220 	br	x17

0000000000001340 <__sprintf_chk@plt>:
    1340:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1344:	f9471211 	ldr	x17, [x16, #3616]
    1348:	91388210 	add	x16, x16, #0xe20
    134c:	d61f0220 	br	x17

0000000000001350 <exit@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1354:	f9471611 	ldr	x17, [x16, #3624]
    1358:	9138a210 	add	x16, x16, #0xe28
    135c:	d61f0220 	br	x17

0000000000001360 <__libc_start_main@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1364:	f9471a11 	ldr	x17, [x16, #3632]
    1368:	9138c210 	add	x16, x16, #0xe30
    136c:	d61f0220 	br	x17

0000000000001370 <strtoll@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1374:	f9471e11 	ldr	x17, [x16, #3640]
    1378:	9138e210 	add	x16, x16, #0xe38
    137c:	d61f0220 	br	x17

0000000000001380 <strtod@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1384:	f9472211 	ldr	x17, [x16, #3648]
    1388:	91390210 	add	x16, x16, #0xe40
    138c:	d61f0220 	br	x17

0000000000001390 <__cxa_finalize@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1394:	f9472611 	ldr	x17, [x16, #3656]
    1398:	91392210 	add	x16, x16, #0xe48
    139c:	d61f0220 	br	x17

00000000000013a0 <__cxa_atexit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13a4:	f9472a11 	ldr	x17, [x16, #3664]
    13a8:	91394210 	add	x16, x16, #0xe50
    13ac:	d61f0220 	br	x17

00000000000013b0 <pthread_attr_init@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13b4:	f9472e11 	ldr	x17, [x16, #3672]
    13b8:	91396210 	add	x16, x16, #0xe58
    13bc:	d61f0220 	br	x17

00000000000013c0 <fputc@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13c4:	f9473211 	ldr	x17, [x16, #3680]
    13c8:	91398210 	add	x16, x16, #0xe60
    13cc:	d61f0220 	br	x17

00000000000013d0 <clock_gettime@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13d4:	f9473611 	ldr	x17, [x16, #3688]
    13d8:	9139a210 	add	x16, x16, #0xe68
    13dc:	d61f0220 	br	x17

00000000000013e0 <setvbuf@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13e4:	f9473a11 	ldr	x17, [x16, #3696]
    13e8:	9139c210 	add	x16, x16, #0xe70
    13ec:	d61f0220 	br	x17

00000000000013f0 <__memcpy_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    13f4:	f9473e11 	ldr	x17, [x16, #3704]
    13f8:	9139e210 	add	x16, x16, #0xe78
    13fc:	d61f0220 	br	x17

0000000000001400 <signal@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1404:	f9474211 	ldr	x17, [x16, #3712]
    1408:	913a0210 	add	x16, x16, #0xe80
    140c:	d61f0220 	br	x17

0000000000001410 <__snprintf_chk@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1414:	f9474611 	ldr	x17, [x16, #3720]
    1418:	913a2210 	add	x16, x16, #0xe88
    141c:	d61f0220 	br	x17

0000000000001420 <fclose@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1424:	f9474a11 	ldr	x17, [x16, #3728]
    1428:	913a4210 	add	x16, x16, #0xe90
    142c:	d61f0220 	br	x17

0000000000001430 <fopen@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1434:	f9474e11 	ldr	x17, [x16, #3736]
    1438:	913a6210 	add	x16, x16, #0xe98
    143c:	d61f0220 	br	x17

0000000000001440 <malloc@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1444:	f9475211 	ldr	x17, [x16, #3744]
    1448:	913a8210 	add	x16, x16, #0xea0
    144c:	d61f0220 	br	x17

0000000000001450 <pthread_attr_destroy@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1454:	f9475611 	ldr	x17, [x16, #3752]
    1458:	913aa210 	add	x16, x16, #0xea8
    145c:	d61f0220 	br	x17

0000000000001460 <sigemptyset@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1464:	f9475a11 	ldr	x17, [x16, #3760]
    1468:	913ac210 	add	x16, x16, #0xeb0
    146c:	d61f0220 	br	x17

0000000000001470 <memset@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1474:	f9475e11 	ldr	x17, [x16, #3768]
    1478:	913ae210 	add	x16, x16, #0xeb8
    147c:	d61f0220 	br	x17

0000000000001480 <calloc@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1484:	f9476211 	ldr	x17, [x16, #3776]
    1488:	913b0210 	add	x16, x16, #0xec0
    148c:	d61f0220 	br	x17

0000000000001490 <realloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1494:	f9476611 	ldr	x17, [x16, #3784]
    1498:	913b2210 	add	x16, x16, #0xec8
    149c:	d61f0220 	br	x17

00000000000014a0 <__stack_chk_fail@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14a4:	f9476a11 	ldr	x17, [x16, #3792]
    14a8:	913b4210 	add	x16, x16, #0xed0
    14ac:	d61f0220 	br	x17

00000000000014b0 <close@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14b4:	f9476e11 	ldr	x17, [x16, #3800]
    14b8:	913b6210 	add	x16, x16, #0xed8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigaction@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14c4:	f9477211 	ldr	x17, [x16, #3808]
    14c8:	913b8210 	add	x16, x16, #0xee0
    14cc:	d61f0220 	br	x17

00000000000014d0 <__gmon_start__@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14d4:	f9477611 	ldr	x17, [x16, #3816]
    14d8:	913ba210 	add	x16, x16, #0xee8
    14dc:	d61f0220 	br	x17

00000000000014e0 <write@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14e4:	f9477a11 	ldr	x17, [x16, #3824]
    14e8:	913bc210 	add	x16, x16, #0xef0
    14ec:	d61f0220 	br	x17

00000000000014f0 <abort@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    14f4:	f9477e11 	ldr	x17, [x16, #3832]
    14f8:	913be210 	add	x16, x16, #0xef8
    14fc:	d61f0220 	br	x17

0000000000001500 <swapcontext@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1504:	f9478211 	ldr	x17, [x16, #3840]
    1508:	913c0210 	add	x16, x16, #0xf00
    150c:	d61f0220 	br	x17

0000000000001510 <__fprintf_chk@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1514:	f9478611 	ldr	x17, [x16, #3848]
    1518:	913c2210 	add	x16, x16, #0xf08
    151c:	d61f0220 	br	x17

0000000000001520 <strcmp@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1524:	f9478a11 	ldr	x17, [x16, #3856]
    1528:	913c4210 	add	x16, x16, #0xf10
    152c:	d61f0220 	br	x17

0000000000001530 <mmap@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1534:	f9478e11 	ldr	x17, [x16, #3864]
    1538:	913c6210 	add	x16, x16, #0xf18
    153c:	d61f0220 	br	x17

0000000000001540 <strtol@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1544:	f9479211 	ldr	x17, [x16, #3872]
    1548:	913c8210 	add	x16, x16, #0xf20
    154c:	d61f0220 	br	x17

0000000000001550 <strtof@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1554:	f9479611 	ldr	x17, [x16, #3880]
    1558:	913ca210 	add	x16, x16, #0xf28
    155c:	d61f0220 	br	x17

0000000000001560 <free@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1564:	f9479a11 	ldr	x17, [x16, #3888]
    1568:	913cc210 	add	x16, x16, #0xf30
    156c:	d61f0220 	br	x17

0000000000001570 <nanosleep@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1574:	f9479e11 	ldr	x17, [x16, #3896]
    1578:	913ce210 	add	x16, x16, #0xf38
    157c:	d61f0220 	br	x17

0000000000001580 <strchr@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1584:	f947a211 	ldr	x17, [x16, #3904]
    1588:	913d0210 	add	x16, x16, #0xf40
    158c:	d61f0220 	br	x17

0000000000001590 <strtoull@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1594:	f947a611 	ldr	x17, [x16, #3912]
    1598:	913d2210 	add	x16, x16, #0xf48
    159c:	d61f0220 	br	x17

00000000000015a0 <fwrite@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15a4:	f947aa11 	ldr	x17, [x16, #3920]
    15a8:	913d4210 	add	x16, x16, #0xf50
    15ac:	d61f0220 	br	x17

00000000000015b0 <pthread_create@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15b4:	f947ae11 	ldr	x17, [x16, #3928]
    15b8:	913d6210 	add	x16, x16, #0xf58
    15bc:	d61f0220 	br	x17

00000000000015c0 <munmap@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15c4:	f947b211 	ldr	x17, [x16, #3936]
    15c8:	913d8210 	add	x16, x16, #0xf60
    15cc:	d61f0220 	br	x17

00000000000015d0 <fflush@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15d4:	f947b611 	ldr	x17, [x16, #3944]
    15d8:	913da210 	add	x16, x16, #0xf68
    15dc:	d61f0220 	br	x17

00000000000015e0 <strcpy@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15e4:	f947ba11 	ldr	x17, [x16, #3952]
    15e8:	913dc210 	add	x16, x16, #0xf70
    15ec:	d61f0220 	br	x17

00000000000015f0 <sysconf@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    15f4:	f947be11 	ldr	x17, [x16, #3960]
    15f8:	913de210 	add	x16, x16, #0xf78
    15fc:	d61f0220 	br	x17

0000000000001600 <strstr@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1604:	f947c211 	ldr	x17, [x16, #3968]
    1608:	913e0210 	add	x16, x16, #0xf80
    160c:	d61f0220 	br	x17

0000000000001610 <_Exit@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1614:	f947c611 	ldr	x17, [x16, #3976]
    1618:	913e2210 	add	x16, x16, #0xf88
    161c:	d61f0220 	br	x17

0000000000001620 <pthread_join@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1624:	f947ca11 	ldr	x17, [x16, #3984]
    1628:	913e4210 	add	x16, x16, #0xf90
    162c:	d61f0220 	br	x17

0000000000001630 <getenv@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1634:	f947ce11 	ldr	x17, [x16, #3992]
    1638:	913e6210 	add	x16, x16, #0xf98
    163c:	d61f0220 	br	x17

0000000000001640 <mprotect@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1644:	f947d211 	ldr	x17, [x16, #4000]
    1648:	913e8210 	add	x16, x16, #0xfa0
    164c:	d61f0220 	br	x17

0000000000001650 <fgets@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1654:	f947d611 	ldr	x17, [x16, #4008]
    1658:	913ea210 	add	x16, x16, #0xfa8
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_attr_setstacksize@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x160a0>
    1664:	f947da11 	ldr	x17, [x16, #4016]
    1668:	913ec210 	add	x16, x16, #0xfb0
    166c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001680 <fwp_trap_overflow.constprop.0>:
    1680:	d10243ff 	sub	sp, sp, #0x90
    1684:	d2800c03 	mov	x3, #0x60                  	// #96
    1688:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    168c:	f947f421 	ldr	x1, [x1, #4072]
    1690:	d0000025 	adrp	x5, 7000 <fwp_main_thread+0x23fc>
    1694:	a9077bfd 	stp	x29, x30, [sp, #112]
    1698:	9101c3fd 	add	x29, sp, #0x70
    169c:	913980a5 	add	x5, x5, #0xe60
    16a0:	d0000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    16a4:	f90043f3 	str	x19, [sp, #128]
    16a8:	9139a084 	add	x4, x4, #0xe68
    16ac:	910023f3 	add	x19, sp, #0x8
    16b0:	f9400022 	ldr	x2, [x1]
    16b4:	f90037e2 	str	x2, [sp, #104]
    16b8:	d2800002 	mov	x2, #0x0                   	// #0
    16bc:	aa0303e1 	mov	x1, x3
    16c0:	52800042 	mov	w2, #0x2                   	// #2
    16c4:	aa1303e0 	mov	x0, x19
    16c8:	97ffff52 	bl	1410 <__snprintf_chk@plt>
    16cc:	aa1303e0 	mov	x0, x19
    16d0:	94000274 	bl	20a0 <fwp_trap>
    16d4:	d503201f 	nop
    16d8:	d503201f 	nop
    16dc:	d503201f 	nop

00000000000016e0 <main>:
    16e0:	d10243ff 	sub	sp, sp, #0x90
    16e4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    16e8:	f947f400 	ldr	x0, [x0, #4072]
    16ec:	a9067bfd 	stp	x29, x30, [sp, #96]
    16f0:	910183fd 	add	x29, sp, #0x60
    16f4:	a90753f3 	stp	x19, x20, [sp, #112]
    16f8:	f00000f3 	adrp	x19, 20000 <__data_start>
    16fc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x160a0>
    1700:	f947ee94 	ldr	x20, [x20, #4056]
    1704:	f9400281 	ldr	x1, [x20]
    1708:	f90043f5 	str	x21, [sp, #128]
    170c:	f9400002 	ldr	x2, [x0]
    1710:	f9002fe2 	str	x2, [sp, #88]
    1714:	d2800002 	mov	x2, #0x0                   	// #0
    1718:	f9003a61 	str	x1, [x19, #112]
    171c:	94000271 	bl	20e0 <fwp_now_ns>
    1720:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    1724:	9102c000 	add	x0, x0, #0xb0
    1728:	97ffffc2 	bl	1630 <getenv@plt>
    172c:	b4000080 	cbz	x0, 173c <main+0x5c>
    1730:	39400001 	ldrb	w1, [x0]
    1734:	aa0003f5 	mov	x21, x0
    1738:	35000801 	cbnz	w1, 1838 <main+0x158>
    173c:	910023e1 	add	x1, sp, #0x8
    1740:	52800000 	mov	w0, #0x0                   	// #0
    1744:	97ffff23 	bl	13d0 <clock_gettime@plt>
    1748:	35000900 	cbnz	w0, 1868 <main+0x188>
    174c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1750:	d2994003 	mov	x3, #0xca00                	// #51712
    1754:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1758:	9b037c01 	mul	x1, x0, x3
    175c:	9b437c00 	smulh	x0, x0, x3
    1760:	ab020021 	adds	x1, x1, x2
    1764:	937ffc42 	asr	x2, x2, #63
    1768:	9a020000 	adc	x0, x0, x2
    176c:	f100003f 	cmp	x1, #0x0
    1770:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1774:	b50009a0 	cbnz	x0, 18a8 <main+0x1c8>
    1778:	f9400280 	ldr	x0, [x20]
    177c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1780:	52800002 	mov	w2, #0x0                   	// #0
    1784:	d2800001 	mov	x1, #0x0                   	// #0
    1788:	910063f5 	add	x21, sp, #0x18
    178c:	97ffff15 	bl	13e0 <setvbuf@plt>
    1790:	d2800021 	mov	x1, #0x1                   	// #1
    1794:	528001a0 	mov	w0, #0xd                   	// #13
    1798:	97ffff1a 	bl	1400 <signal@plt>
    179c:	aa1503e0 	mov	x0, x21
    17a0:	97ffff04 	bl	13b0 <pthread_attr_init@plt>
    17a4:	350007c0 	cbnz	w0, 189c <main+0x1bc>
    17a8:	aa1503e0 	mov	x0, x21
    17ac:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17b0:	97ffffac 	bl	1660 <pthread_attr_setstacksize@plt>
    17b4:	35000680 	cbnz	w0, 1884 <main+0x1a4>
    17b8:	aa1503e1 	mov	x1, x21
    17bc:	910023e0 	add	x0, sp, #0x8
    17c0:	f0000002 	adrp	x2, 4000 <fwp_write.constprop.0+0x3a0>
    17c4:	d2800003 	mov	x3, #0x0                   	// #0
    17c8:	91301042 	add	x2, x2, #0xc04
    17cc:	97ffff79 	bl	15b0 <pthread_create@plt>
    17d0:	2a0003e1 	mov	w1, w0
    17d4:	aa1503e0 	mov	x0, x21
    17d8:	2a0103f5 	mov	w21, w1
    17dc:	97ffff1d 	bl	1450 <pthread_attr_destroy@plt>
    17e0:	350006a0 	cbnz	w0, 18b4 <main+0x1d4>
    17e4:	350004b5 	cbnz	w21, 1878 <main+0x198>
    17e8:	f94007e0 	ldr	x0, [sp, #8]
    17ec:	d2800001 	mov	x1, #0x0                   	// #0
    17f0:	97ffff8c 	bl	1620 <pthread_join@plt>
    17f4:	35000600 	cbnz	w0, 18b4 <main+0x1d4>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	9101c273 	add	x19, x19, #0x70
    1800:	97ffff74 	bl	15d0 <fflush@plt>
    1804:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    1808:	f947f421 	ldr	x1, [x1, #4072]
    180c:	b942a260 	ldr	w0, [x19, #672]
    1810:	f9402fe3 	ldr	x3, [sp, #88]
    1814:	f9400022 	ldr	x2, [x1]
    1818:	eb020063 	subs	x3, x3, x2
    181c:	d2800002 	mov	x2, #0x0                   	// #0
    1820:	540002a1 	b.ne	1874 <main+0x194>  // b.any
    1824:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1828:	a94753f3 	ldp	x19, x20, [sp, #112]
    182c:	f94043f5 	ldr	x21, [sp, #128]
    1830:	910243ff 	add	sp, sp, #0x90
    1834:	d65f03c0 	ret
    1838:	910003e1 	mov	x1, sp
    183c:	52800142 	mov	w2, #0xa                   	// #10
    1840:	97ffff54 	bl	1590 <strtoull@plt>
    1844:	f94003e0 	ldr	x0, [sp]
    1848:	39400000 	ldrb	w0, [x0]
    184c:	35fff780 	cbnz	w0, 173c <main+0x5c>
    1850:	394002a0 	ldrb	w0, [x21]
    1854:	52801fa1 	mov	w1, #0xfd                  	// #253
    1858:	5100ac00 	sub	w0, w0, #0x2b
    185c:	6a01001f 	tst	w0, w1
    1860:	54fff6e0 	b.eq	173c <main+0x5c>  // b.none
    1864:	17ffffc5 	b	1778 <main+0x98>
    1868:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    186c:	91030000 	add	x0, x0, #0xc0
    1870:	9400020c 	bl	20a0 <fwp_trap>
    1874:	97ffff0b 	bl	14a0 <__stack_chk_fail@plt>
    1878:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    187c:	91058000 	add	x0, x0, #0x160
    1880:	94000208 	bl	20a0 <fwp_trap>
    1884:	aa1503e0 	mov	x0, x21
    1888:	97fffef2 	bl	1450 <pthread_attr_destroy@plt>
    188c:	35000140 	cbnz	w0, 18b4 <main+0x1d4>
    1890:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    1894:	9104e000 	add	x0, x0, #0x138
    1898:	94000202 	bl	20a0 <fwp_trap>
    189c:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    18a0:	91042000 	add	x0, x0, #0x108
    18a4:	940001ff 	bl	20a0 <fwp_trap>
    18a8:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    18ac:	91038000 	add	x0, x0, #0xe0
    18b0:	940001fc 	bl	20a0 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <abort@plt>
    18b8:	d503201f 	nop
    18bc:	d503201f 	nop

00000000000018c0 <_start>:
    18c0:	d503201f 	nop
    18c4:	d280001d 	mov	x29, #0x0                   	// #0
    18c8:	d280001e 	mov	x30, #0x0                   	// #0
    18cc:	aa0003e5 	mov	x5, x0
    18d0:	f94003e1 	ldr	x1, [sp]
    18d4:	910023e2 	add	x2, sp, #0x8
    18d8:	910003e6 	mov	x6, sp
    18dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    18e0:	f947f800 	ldr	x0, [x0, #4080]
    18e4:	d2800003 	mov	x3, #0x0                   	// #0
    18e8:	d2800004 	mov	x4, #0x0                   	// #0
    18ec:	97fffe9d 	bl	1360 <__libc_start_main@plt>
    18f0:	97ffff00 	bl	14f0 <abort@plt>

00000000000018f4 <call_weak_fn>:
    18f4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    18f8:	f947f000 	ldr	x0, [x0, #4064]
    18fc:	b4000040 	cbz	x0, 1904 <call_weak_fn+0x10>
    1900:	17fffef4 	b	14d0 <__gmon_start__@plt>
    1904:	d65f03c0 	ret
    1908:	d503201f 	nop
    190c:	d503201f 	nop

0000000000001910 <deregister_tm_clones>:
    1910:	f00000e0 	adrp	x0, 20000 <__data_start>
    1914:	91016000 	add	x0, x0, #0x58
    1918:	f00000e1 	adrp	x1, 20000 <__data_start>
    191c:	91016021 	add	x1, x1, #0x58
    1920:	eb00003f 	cmp	x1, x0
    1924:	540000c0 	b.eq	193c <deregister_tm_clones+0x2c>  // b.none
    1928:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    192c:	f947e021 	ldr	x1, [x1, #4032]
    1930:	b4000061 	cbz	x1, 193c <deregister_tm_clones+0x2c>
    1934:	aa0103f0 	mov	x16, x1
    1938:	d61f0200 	br	x16
    193c:	d65f03c0 	ret

0000000000001940 <register_tm_clones>:
    1940:	f00000e0 	adrp	x0, 20000 <__data_start>
    1944:	91016000 	add	x0, x0, #0x58
    1948:	f00000e1 	adrp	x1, 20000 <__data_start>
    194c:	91016021 	add	x1, x1, #0x58
    1950:	cb000021 	sub	x1, x1, x0
    1954:	d37ffc22 	lsr	x2, x1, #63
    1958:	8b810c41 	add	x1, x2, x1, asr #3
    195c:	9341fc21 	asr	x1, x1, #1
    1960:	b40000c1 	cbz	x1, 1978 <register_tm_clones+0x38>
    1964:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x160a0>
    1968:	f947fc42 	ldr	x2, [x2, #4088]
    196c:	b4000062 	cbz	x2, 1978 <register_tm_clones+0x38>
    1970:	aa0203f0 	mov	x16, x2
    1974:	d61f0200 	br	x16
    1978:	d65f03c0 	ret
    197c:	d503201f 	nop

0000000000001980 <__do_global_dtors_aux>:
    1980:	d503233f 	paciasp
    1984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1988:	910003fd 	mov	x29, sp
    198c:	f9000bf3 	str	x19, [sp, #16]
    1990:	f00000f3 	adrp	x19, 20000 <__data_start>
    1994:	39418260 	ldrb	w0, [x19, #96]
    1998:	37000140 	tbnz	w0, #0, 19c0 <__do_global_dtors_aux+0x40>
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    19a0:	f947e400 	ldr	x0, [x0, #4040]
    19a4:	b4000080 	cbz	x0, 19b4 <__do_global_dtors_aux+0x34>
    19a8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ac:	f9400400 	ldr	x0, [x0, #8]
    19b0:	97fffe78 	bl	1390 <__cxa_finalize@plt>
    19b4:	97ffffd7 	bl	1910 <deregister_tm_clones>
    19b8:	52800020 	mov	w0, #0x1                   	// #1
    19bc:	39018260 	strb	w0, [x19, #96]
    19c0:	f9400bf3 	ldr	x19, [sp, #16]
    19c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19c8:	d50323bf 	autiasp
    19cc:	d65f03c0 	ret

00000000000019d0 <frame_dummy>:
    19d0:	d503245f 	bti	c
    19d4:	17ffffdb 	b	1940 <register_tm_clones>
    19d8:	d503201f 	nop
    19dc:	d503201f 	nop

00000000000019e0 <fwp_fmt_u128>:
    19e0:	d10183ff 	sub	sp, sp, #0x60
    19e4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    19e8:	f947f421 	ldr	x1, [x1, #4072]
    19ec:	a9057bfd 	stp	x29, x30, [sp, #80]
    19f0:	910143fd 	add	x29, sp, #0x50
    19f4:	f9400024 	ldr	x4, [x1]
    19f8:	f90027e4 	str	x4, [sp, #72]
    19fc:	d2800004 	mov	x4, #0x0                   	// #0
    1a00:	aa030041 	orr	x1, x2, x3
    1a04:	b5000361 	cbnz	x1, 1a70 <fwp_fmt_u128+0x90>
    1a08:	910023e9 	add	x9, sp, #0x8
    1a0c:	52800601 	mov	w1, #0x30                  	// #48
    1a10:	5280002d 	mov	w13, #0x1                   	// #1
    1a14:	390023e1 	strb	w1, [sp, #8]
    1a18:	93407dad 	sxtw	x13, w13
    1a1c:	aa0d03e1 	mov	x1, x13
    1a20:	8b0d0004 	add	x4, x0, x13
    1a24:	d503201f 	nop
    1a28:	8b010123 	add	x3, x9, x1
    1a2c:	cb0103e2 	neg	x2, x1
    1a30:	d1000421 	sub	x1, x1, #0x1
    1a34:	385ff063 	ldurb	w3, [x3, #-1]
    1a38:	38226883 	strb	w3, [x4, x2]
    1a3c:	35ffff61 	cbnz	w1, 1a28 <fwp_fmt_u128+0x48>
    1a40:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    1a44:	f947f421 	ldr	x1, [x1, #4072]
    1a48:	382d681f 	strb	wzr, [x0, x13]
    1a4c:	aa0103e0 	mov	x0, x1
    1a50:	f94027e2 	ldr	x2, [sp, #72]
    1a54:	f9400001 	ldr	x1, [x0]
    1a58:	eb010042 	subs	x2, x2, x1
    1a5c:	d2800001 	mov	x1, #0x0                   	// #0
    1a60:	54000561 	b.ne	1b0c <fwp_fmt_u128+0x12c>  // b.any
    1a64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1a68:	910183ff 	add	sp, sp, #0x60
    1a6c:	d65f03c0 	ret
    1a70:	f0000021 	adrp	x1, 8000 <_IO_stdin_used+0x300>
    1a74:	91084021 	add	x1, x1, #0x210
    1a78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1a7c:	910023e9 	add	x9, sp, #0x8
    1a80:	d2800027 	mov	x7, #0x1                   	// #1
    1a84:	f29999af 	movk	x15, #0xcccd
    1a88:	a9402826 	ldp	x6, x10, [x1]
    1a8c:	d503201f 	nop
    1a90:	ab030041 	adds	x1, x2, x3
    1a94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1a98:	aa0303eb 	mov	x11, x3
    1a9c:	8b070128 	add	x8, x9, x7
    1aa0:	aa0203ee 	mov	x14, x2
    1aa4:	aa0703ed 	mov	x13, x7
    1aa8:	910004e7 	add	x7, x7, #0x1
    1aac:	9bcf7c24 	umulh	x4, x1, x15
    1ab0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1ab4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1ab8:	cb040021 	sub	x1, x1, x4
    1abc:	eb010041 	subs	x1, x2, x1
    1ac0:	da1f0063 	sbc	x3, x3, xzr
    1ac4:	9bc67c24 	umulh	x4, x1, x6
    1ac8:	9b061064 	madd	x4, x3, x6, x4
    1acc:	9b067c2c 	mul	x12, x1, x6
    1ad0:	9b0a1024 	madd	x4, x1, x10, x4
    1ad4:	9bc67c25 	umulh	x5, x1, x6
    1ad8:	9b061465 	madd	x5, x3, x6, x5
    1adc:	9b0a1425 	madd	x5, x1, x10, x5
    1ae0:	93cc0484 	extr	x4, x4, x12, #1
    1ae4:	8b040884 	add	x4, x4, x4, lsl #2
    1ae8:	d341fca3 	lsr	x3, x5, #1
    1aec:	cb040444 	sub	x4, x2, x4, lsl #1
    1af0:	93cc04a2 	extr	x2, x5, x12, #1
    1af4:	1100c084 	add	w4, w4, #0x30
    1af8:	381ff104 	sturb	w4, [x8, #-1]
    1afc:	b5fffcab 	cbnz	x11, 1a90 <fwp_fmt_u128+0xb0>
    1b00:	f10025df 	cmp	x14, #0x9
    1b04:	54fffc68 	b.hi	1a90 <fwp_fmt_u128+0xb0>  // b.pmore
    1b08:	17ffffc4 	b	1a18 <fwp_fmt_u128+0x38>
    1b0c:	97fffe65 	bl	14a0 <__stack_chk_fail@plt>

0000000000001b10 <fwp_range_release>:
    1b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b14:	910003fd 	mov	x29, sp
    1b18:	f9400801 	ldr	x1, [x0, #16]
    1b1c:	f9000bf3 	str	x19, [sp, #16]
    1b20:	aa0003f3 	mov	x19, x0
    1b24:	b4000061 	cbz	x1, 1b30 <fwp_range_release+0x20>
    1b28:	f9400400 	ldr	x0, [x0, #8]
    1b2c:	d63f0020 	blr	x1
    1b30:	f9400260 	ldr	x0, [x19]
    1b34:	f9400e61 	ldr	x1, [x19, #24]
    1b38:	f9400bf3 	ldr	x19, [sp, #16]
    1b3c:	aa0103f0 	mov	x16, x1
    1b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b44:	d61f0200 	br	x16
    1b48:	d503201f 	nop
    1b4c:	d503201f 	nop

0000000000001b50 <fwp_flush>:
    1b50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1b54:	f9403800 	ldr	x0, [x0, #112]
    1b58:	b4000120 	cbz	x0, 1b7c <fwp_flush+0x2c>
    1b5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b60:	910003fd 	mov	x29, sp
    1b64:	97fffe9b 	bl	15d0 <fflush@plt>
    1b68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    1b6c:	f947ec00 	ldr	x0, [x0, #4056]
    1b70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1b74:	f9400000 	ldr	x0, [x0]
    1b78:	17fffe96 	b	15d0 <fflush@plt>
    1b7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    1b80:	f947ec00 	ldr	x0, [x0, #4056]
    1b84:	f9400000 	ldr	x0, [x0]
    1b88:	17fffe92 	b	15d0 <fflush@plt>
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_heap_oom>:
    1b90:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x160a0>
    1b94:	f947e863 	ldr	x3, [x3, #4048]
    1b98:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b9c:	d2800262 	mov	x2, #0x13                  	// #19
    1ba0:	910003fd 	mov	x29, sp
    1ba4:	f9400063 	ldr	x3, [x3]
    1ba8:	d2800021 	mov	x1, #0x1                   	// #1
    1bac:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    1bb0:	91342000 	add	x0, x0, #0xd08
    1bb4:	97fffe7b 	bl	15a0 <fwrite@plt>
    1bb8:	d2800000 	mov	x0, #0x0                   	// #0
    1bbc:	97fffe85 	bl	15d0 <fflush@plt>
    1bc0:	52800cc0 	mov	w0, #0x66                  	// #102
    1bc4:	97fffe93 	bl	1610 <_Exit@plt>
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_segv>:
    1bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1bd4:	f00000e2 	adrp	x2, 20000 <__data_start>
    1bd8:	9101c043 	add	x3, x2, #0x70
    1bdc:	910003fd 	mov	x29, sp
    1be0:	a90153f3 	stp	x19, x20, [sp, #16]
    1be4:	2a0003f3 	mov	w19, w0
    1be8:	f9400460 	ldr	x0, [x3, #8]
    1bec:	f90013f5 	str	x21, [sp, #32]
    1bf0:	f9400835 	ldr	x21, [x1, #16]
    1bf4:	b4000280 	cbz	x0, 1c44 <fwp_segv+0x74>
    1bf8:	f9400814 	ldr	x20, [x0, #16]
    1bfc:	b4000254 	cbz	x20, 1c44 <fwp_segv+0x74>
    1c00:	528003c0 	mov	w0, #0x1e                  	// #30
    1c04:	97fffe7b 	bl	15f0 <sysconf@plt>
    1c08:	f144029f 	cmp	x20, #0x100, lsl #12
    1c0c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c10:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c14:	8b000294 	add	x20, x20, x0
    1c18:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c1c:	eb0102bf 	cmp	x21, x1
    1c20:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c24:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c28:	35000240 	cbnz	w0, 1c70 <fwp_segv+0xa0>
    1c2c:	f94013f5 	ldr	x21, [sp, #32]
    1c30:	2a1303e0 	mov	w0, w19
    1c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c38:	d2800001 	mov	x1, #0x0                   	// #0
    1c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c40:	17fffdf0 	b	1400 <signal@plt>
    1c44:	9101c042 	add	x2, x2, #0x70
    1c48:	f9400840 	ldr	x0, [x2, #16]
    1c4c:	b4ffff00 	cbz	x0, 1c2c <fwp_segv+0x5c>
    1c50:	f9400c41 	ldr	x1, [x2, #24]
    1c54:	cb010000 	sub	x0, x0, x1
    1c58:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c5c:	91440000 	add	x0, x0, #0x100, lsl #12
    1c60:	eb15003f 	cmp	x1, x21
    1c64:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1c68:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c6c:	34fffe00 	cbz	w0, 1c2c <fwp_segv+0x5c>
    1c70:	97ffffb8 	bl	1b50 <fwp_flush>
    1c74:	f0000021 	adrp	x1, 8000 <_IO_stdin_used+0x300>
    1c78:	9107c021 	add	x1, x1, #0x1f0
    1c7c:	d2800342 	mov	x2, #0x1a                  	// #26
    1c80:	52800040 	mov	w0, #0x2                   	// #2
    1c84:	97fffe17 	bl	14e0 <write@plt>
    1c88:	52800ca0 	mov	w0, #0x65                  	// #101
    1c8c:	97fffda5 	bl	1320 <_exit@plt>

0000000000001c90 <fwp_heap_chunks>:
    1c90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c94:	910003fd 	mov	x29, sp
    1c98:	a90153f3 	stp	x19, x20, [sp, #16]
    1c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ca0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    1ca4:	911442a1 	add	x1, x21, #0x510
    1ca8:	f100041f 	cmp	x0, #0x1
    1cac:	54000ca0 	b.eq	1e40 <fwp_heap_chunks+0x1b0>  // b.none
    1cb0:	f949f822 	ldr	x2, [x1, #5104]
    1cb4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1cb8:	912400a5 	add	x5, x5, #0x900
    1cbc:	911442a1 	add	x1, x21, #0x510
    1cc0:	f949ec34 	ldr	x20, [x1, #5080]
    1cc4:	eb14005f 	cmp	x2, x20
    1cc8:	54000c42 	b.cs	1e50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1ccc:	f949fc23 	ldr	x3, [x1, #5112]
    1cd0:	8b020841 	add	x1, x2, x2, lsl #2
    1cd4:	d2800004 	mov	x4, #0x0                   	// #0
    1cd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1cdc:	14000009 	b	1d00 <fwp_heap_chunks+0x70>
    1ce0:	91000483 	add	x3, x4, #0x1
    1ce4:	eb03001f 	cmp	x0, x3
    1ce8:	54000940 	b.eq	1e10 <fwp_heap_chunks+0x180>  // b.none
    1cec:	91000442 	add	x2, x2, #0x1
    1cf0:	aa0303e4 	mov	x4, x3
    1cf4:	9100a021 	add	x1, x1, #0x28
    1cf8:	eb02029f 	cmp	x20, x2
    1cfc:	54000100 	b.eq	1d1c <fwp_heap_chunks+0x8c>  // b.none
    1d00:	39400023 	ldrb	w3, [x1]
    1d04:	34fffee3 	cbz	w3, 1ce0 <fwp_heap_chunks+0x50>
    1d08:	91000442 	add	x2, x2, #0x1
    1d0c:	9100a021 	add	x1, x1, #0x28
    1d10:	d2800004 	mov	x4, #0x0                   	// #0
    1d14:	eb02029f 	cmp	x20, x2
    1d18:	54ffff41 	b.ne	1d00 <fwp_heap_chunks+0x70>  // b.any
    1d1c:	cb040294 	sub	x20, x20, x4
    1d20:	f9001bf7 	str	x23, [sp, #48]
    1d24:	911442b7 	add	x23, x21, #0x510
    1d28:	8b140013 	add	x19, x0, x20
    1d2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1d30:	f949f2e0 	ldr	x0, [x23, #5088]
    1d34:	cb040021 	sub	x1, x1, x4
    1d38:	f90a1ae1 	str	x1, [x23, #5168]
    1d3c:	eb00027f 	cmp	x19, x0
    1d40:	54000429 	b.ls	1dc4 <fwp_heap_chunks+0x134>  // b.plast
    1d44:	f949eae1 	ldr	x1, [x23, #5072]
    1d48:	eb01027f 	cmp	x19, x1
    1d4c:	54000888 	b.hi	1e5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1d50:	91010276 	add	x22, x19, #0x40
    1d54:	52800062 	mov	w2, #0x3                   	// #3
    1d58:	f949dae3 	ldr	x3, [x23, #5040]
    1d5c:	eb0102df 	cmp	x22, x1
    1d60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1d64:	cb0002c1 	sub	x1, x22, x0
    1d68:	8b004060 	add	x0, x3, x0, lsl #16
    1d6c:	d370bc21 	lsl	x1, x1, #16
    1d70:	97fffe34 	bl	1640 <mprotect@plt>
    1d74:	35000740 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1d78:	528003c0 	mov	w0, #0x1e                  	// #30
    1d7c:	97fffe1d 	bl	15f0 <sysconf@plt>
    1d80:	f949f2e2 	ldr	x2, [x23, #5088]
    1d84:	cb0003e5 	neg	x5, x0
    1d88:	aa0003e4 	mov	x4, x0
    1d8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1d90:	f949fee0 	ldr	x0, [x23, #5112]
    1d94:	8b020843 	add	x3, x2, x2, lsl #2
    1d98:	52800062 	mov	w2, #0x3                   	// #3
    1d9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1da0:	8b030c03 	add	x3, x0, x3, lsl #3
    1da4:	d1000421 	sub	x1, x1, #0x1
    1da8:	8a050060 	and	x0, x3, x5
    1dac:	8b040021 	add	x1, x1, x4
    1db0:	8a050021 	and	x1, x1, x5
    1db4:	cb000021 	sub	x1, x1, x0
    1db8:	97fffe22 	bl	1640 <mprotect@plt>
    1dbc:	35000500 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1dc0:	f909f2f6 	str	x22, [x23, #5088]
    1dc4:	911442b5 	add	x21, x21, #0x510
    1dc8:	d370be60 	lsl	x0, x19, #16
    1dcc:	f949e6a1 	ldr	x1, [x21, #5064]
    1dd0:	f909eeb3 	str	x19, [x21, #5080]
    1dd4:	eb01001f 	cmp	x0, x1
    1dd8:	540000e8 	b.hi	1df4 <fwp_heap_chunks+0x164>  // b.pmore
    1ddc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1de0:	aa1403e0 	mov	x0, x20
    1de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1de8:	f9401bf7 	ldr	x23, [sp, #48]
    1dec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1df0:	d65f03c0 	ret
    1df4:	f9401bf7 	ldr	x23, [sp, #48]
    1df8:	f909e6a0 	str	x0, [x21, #5064]
    1dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e00:	aa1403e0 	mov	x0, x20
    1e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e0c:	d65f03c0 	ret
    1e10:	911442b5 	add	x21, x21, #0x510
    1e14:	91000441 	add	x1, x2, #0x1
    1e18:	f90000a1 	str	x1, [x5]
    1e1c:	cb040054 	sub	x20, x2, x4
    1e20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1e24:	cb000020 	sub	x0, x1, x0
    1e28:	f90a1aa0 	str	x0, [x21, #5168]
    1e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e30:	aa1403e0 	mov	x0, x20
    1e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e3c:	d65f03c0 	ret
    1e40:	f949f422 	ldr	x2, [x1, #5096]
    1e44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1e48:	9123e0a5 	add	x5, x5, #0x8f8
    1e4c:	17ffff9c 	b	1cbc <fwp_heap_chunks+0x2c>
    1e50:	d2800004 	mov	x4, #0x0                   	// #0
    1e54:	f9001bf7 	str	x23, [sp, #48]
    1e58:	17ffffb3 	b	1d24 <fwp_heap_chunks+0x94>
    1e5c:	97ffff4d 	bl	1b90 <fwp_heap_oom>

0000000000001e60 <buf_grow>:
    1e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1e64:	910003fd 	mov	x29, sp
    1e68:	a90153f3 	stp	x19, x20, [sp, #16]
    1e6c:	aa0003f4 	mov	x20, x0
    1e70:	f9400400 	ldr	x0, [x0, #8]
    1e74:	b100041f 	cmn	x0, #0x1
    1e78:	54000400 	b.eq	1ef8 <buf_grow+0x98>  // b.none
    1e7c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1e80:	cb000042 	sub	x2, x2, x0
    1e84:	eb01005f 	cmp	x2, x1
    1e88:	54000383 	b.cc	1ef8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1e8c:	f9400a82 	ldr	x2, [x20, #16]
    1e90:	91000421 	add	x1, x1, #0x1
    1e94:	8b000033 	add	x19, x1, x0
    1e98:	eb13005f 	cmp	x2, x19
    1e9c:	54000242 	b.cs	1ee4 <buf_grow+0x84>  // b.hs, b.nlast
    1ea0:	f100005f 	cmp	x2, #0x0
    1ea4:	b5000262 	cbnz	x2, 1ef0 <buf_grow+0x90>
    1ea8:	d2800802 	mov	x2, #0x40                  	// #64
    1eac:	eb02027f 	cmp	x19, x2
    1eb0:	54000068 	b.hi	1ebc <buf_grow+0x5c>  // b.pmore
    1eb4:	14000005 	b	1ec8 <buf_grow+0x68>
    1eb8:	b7f800a2 	tbnz	x2, #63, 1ecc <buf_grow+0x6c>
    1ebc:	d37ff842 	lsl	x2, x2, #1
    1ec0:	eb02027f 	cmp	x19, x2
    1ec4:	54ffffa8 	b.hi	1eb8 <buf_grow+0x58>  // b.pmore
    1ec8:	aa0203f3 	mov	x19, x2
    1ecc:	f9400280 	ldr	x0, [x20]
    1ed0:	aa1303e1 	mov	x1, x19
    1ed4:	97fffd6f 	bl	1490 <realloc@plt>
    1ed8:	b4000100 	cbz	x0, 1ef8 <buf_grow+0x98>
    1edc:	f9000280 	str	x0, [x20]
    1ee0:	f9000a93 	str	x19, [x20, #16]
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1eec:	d65f03c0 	ret
    1ef0:	54fffe6a 	b.ge	1ebc <buf_grow+0x5c>  // b.tcont
    1ef4:	17fffff6 	b	1ecc <buf_grow+0x6c>
    1ef8:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x160a0>
    1efc:	f947e863 	ldr	x3, [x3, #4048]
    1f00:	d2800262 	mov	x2, #0x13                  	// #19
    1f04:	d2800021 	mov	x1, #0x1                   	// #1
    1f08:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    1f0c:	91342000 	add	x0, x0, #0xd08
    1f10:	f9400063 	ldr	x3, [x3]
    1f14:	97fffda3 	bl	15a0 <fwrite@plt>
    1f18:	d2800000 	mov	x0, #0x0                   	// #0
    1f1c:	97fffdad 	bl	15d0 <fflush@plt>
    1f20:	52800cc0 	mov	w0, #0x66                  	// #102
    1f24:	97fffdbb 	bl	1610 <_Exit@plt>
    1f28:	d503201f 	nop
    1f2c:	d503201f 	nop

0000000000001f30 <buf_put>:
    1f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1f34:	910003fd 	mov	x29, sp
    1f38:	a90153f3 	stp	x19, x20, [sp, #16]
    1f3c:	aa0003f4 	mov	x20, x0
    1f40:	aa0203f3 	mov	x19, x2
    1f44:	f90013f5 	str	x21, [sp, #32]
    1f48:	aa0103f5 	mov	x21, x1
    1f4c:	aa0203e1 	mov	x1, x2
    1f50:	97ffffc4 	bl	1e60 <buf_grow>
    1f54:	a9400283 	ldp	x3, x0, [x20]
    1f58:	aa1503e1 	mov	x1, x21
    1f5c:	aa1303e2 	mov	x2, x19
    1f60:	8b000060 	add	x0, x3, x0
    1f64:	97fffce7 	bl	1300 <memcpy@plt>
    1f68:	a9400680 	ldp	x0, x1, [x20]
    1f6c:	8b010273 	add	x19, x19, x1
    1f70:	f9000693 	str	x19, [x20, #8]
    1f74:	3833681f 	strb	wzr, [x0, x19]
    1f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f7c:	f94013f5 	ldr	x21, [sp, #32]
    1f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1f84:	d65f03c0 	ret
    1f88:	d503201f 	nop
    1f8c:	d503201f 	nop

0000000000001f90 <fwp_cancel_tree.part.0>:
    1f90:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f94:	9101c022 	add	x2, x1, #0x70
    1f98:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1f9c:	52800023 	mov	w3, #0x1                   	// #1
    1fa0:	910003fd 	mov	x29, sp
    1fa4:	f9400444 	ldr	x4, [x2, #8]
    1fa8:	f9000bf3 	str	x19, [sp, #16]
    1fac:	39014403 	strb	w3, [x0, #81]
    1fb0:	eb04001f 	cmp	x0, x4
    1fb4:	54000160 	b.eq	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.none
    1fb8:	f9402804 	ldr	x4, [x0, #80]
    1fbc:	f2001c9f 	tst	x4, #0xff000000ff
    1fc0:	54000101 	b.ne	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.any
    1fc4:	f9401044 	ldr	x4, [x2, #32]
    1fc8:	39015003 	strb	w3, [x0, #84]
    1fcc:	f900801f 	str	xzr, [x0, #256]
    1fd0:	b40001e4 	cbz	x4, 200c <fwp_cancel_tree.part.0+0x7c>
    1fd4:	f9008080 	str	x0, [x4, #256]
    1fd8:	9101c021 	add	x1, x1, #0x70
    1fdc:	f9001020 	str	x0, [x1, #32]
    1fe0:	f9401413 	ldr	x19, [x0, #40]
    1fe4:	b40000f3 	cbz	x19, 2000 <fwp_cancel_tree.part.0+0x70>
    1fe8:	39414261 	ldrb	w1, [x19, #80]
    1fec:	aa1303e0 	mov	x0, x19
    1ff0:	37000041 	tbnz	w1, #0, 1ff8 <fwp_cancel_tree.part.0+0x68>
    1ff4:	97ffffe7 	bl	1f90 <fwp_cancel_tree.part.0>
    1ff8:	f9401a73 	ldr	x19, [x19, #48]
    1ffc:	b5ffff73 	cbnz	x19, 1fe8 <fwp_cancel_tree.part.0+0x58>
    2000:	f9400bf3 	ldr	x19, [sp, #16]
    2004:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2008:	d65f03c0 	ret
    200c:	f9001440 	str	x0, [x2, #40]
    2010:	17fffff2 	b	1fd8 <fwp_cancel_tree.part.0+0x48>

0000000000002014 <fwp_finish_float>:
    2014:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2018:	528005c1 	mov	w1, #0x2e                  	// #46
    201c:	910003fd 	mov	x29, sp
    2020:	f9000bf3 	str	x19, [sp, #16]
    2024:	aa0003f3 	mov	x19, x0
    2028:	97fffd56 	bl	1580 <strchr@plt>
    202c:	b4000080 	cbz	x0, 203c <fwp_finish_float+0x28>
    2030:	f9400bf3 	ldr	x19, [sp, #16]
    2034:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2038:	d65f03c0 	ret
    203c:	aa1303e0 	mov	x0, x19
    2040:	52800ca1 	mov	w1, #0x65                  	// #101
    2044:	97fffd4f 	bl	1580 <strchr@plt>
    2048:	b5ffff40 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    204c:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    2050:	aa1303e0 	mov	x0, x19
    2054:	91348021 	add	x1, x1, #0xd20
    2058:	97fffd6a 	bl	1600 <strstr@plt>
    205c:	b5fffea0 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2060:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    2064:	aa1303e0 	mov	x0, x19
    2068:	9134a021 	add	x1, x1, #0xd28
    206c:	97fffd65 	bl	1600 <strstr@plt>
    2070:	b5fffe00 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2074:	aa1303e0 	mov	x0, x19
    2078:	97fffcae 	bl	1330 <strlen@plt>
    207c:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    2080:	9134c021 	add	x1, x1, #0xd30
    2084:	8b000262 	add	x2, x19, x0
    2088:	79400023 	ldrh	w3, [x1]
    208c:	39400821 	ldrb	w1, [x1, #2]
    2090:	78206a63 	strh	w3, [x19, x0]
    2094:	39000841 	strb	w1, [x2, #2]
    2098:	17ffffe6 	b	2030 <fwp_finish_float+0x1c>
    209c:	d503201f 	nop

00000000000020a0 <fwp_trap>:
    20a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20a4:	910003fd 	mov	x29, sp
    20a8:	f9000bf3 	str	x19, [sp, #16]
    20ac:	aa0003f3 	mov	x19, x0
    20b0:	97fffea8 	bl	1b50 <fwp_flush>
    20b4:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x160a0>
    20b8:	f947e884 	ldr	x4, [x4, #4048]
    20bc:	aa1303e3 	mov	x3, x19
    20c0:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x23fc>
    20c4:	9134e042 	add	x2, x2, #0xd38
    20c8:	52800041 	mov	w1, #0x2                   	// #2
    20cc:	f9400080 	ldr	x0, [x4]
    20d0:	97fffd10 	bl	1510 <__fprintf_chk@plt>
    20d4:	52800ca0 	mov	w0, #0x65                  	// #101
    20d8:	97fffc9e 	bl	1350 <exit@plt>
    20dc:	d503201f 	nop

00000000000020e0 <fwp_now_ns>:
    20e0:	d100c3ff 	sub	sp, sp, #0x30
    20e4:	52800020 	mov	w0, #0x1                   	// #1
    20e8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x160a0>
    20ec:	f947f442 	ldr	x2, [x2, #4072]
    20f0:	910023e1 	add	x1, sp, #0x8
    20f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    20f8:	910083fd 	add	x29, sp, #0x20
    20fc:	f9400043 	ldr	x3, [x2]
    2100:	f9000fe3 	str	x3, [sp, #24]
    2104:	d2800003 	mov	x3, #0x0                   	// #0
    2108:	97fffcb2 	bl	13d0 <clock_gettime@plt>
    210c:	350002c0 	cbnz	w0, 2164 <fwp_now_ns+0x84>
    2110:	a9408be1 	ldp	x1, x2, [sp, #8]
    2114:	d2994003 	mov	x3, #0xca00                	// #51712
    2118:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    211c:	9b037c20 	mul	x0, x1, x3
    2120:	9b437c21 	smulh	x1, x1, x3
    2124:	ab020000 	adds	x0, x0, x2
    2128:	937ffc42 	asr	x2, x2, #63
    212c:	9a020021 	adc	x1, x1, x2
    2130:	f100001f 	cmp	x0, #0x0
    2134:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2138:	b50001e1 	cbnz	x1, 2174 <fwp_now_ns+0x94>
    213c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    2140:	f947f421 	ldr	x1, [x1, #4072]
    2144:	f9400fe3 	ldr	x3, [sp, #24]
    2148:	f9400022 	ldr	x2, [x1]
    214c:	eb020063 	subs	x3, x3, x2
    2150:	d2800002 	mov	x2, #0x0                   	// #0
    2154:	540000e1 	b.ne	2170 <fwp_now_ns+0x90>  // b.any
    2158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    215c:	9100c3ff 	add	sp, sp, #0x30
    2160:	d65f03c0 	ret
    2164:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    2168:	91352000 	add	x0, x0, #0xd48
    216c:	97ffffcd 	bl	20a0 <fwp_trap>
    2170:	97fffccc 	bl	14a0 <__stack_chk_fail@plt>
    2174:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    2178:	9135a000 	add	x0, x0, #0xd68
    217c:	97ffffc9 	bl	20a0 <fwp_trap>

0000000000002180 <fwp_format_g.constprop.0>:
    2180:	d10483ff 	sub	sp, sp, #0x120
    2184:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    2188:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x160a0>
    218c:	f947f442 	ldr	x2, [x2, #4072]
    2190:	91364084 	add	x4, x4, #0xd90
    2194:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2198:	9102c3fd 	add	x29, sp, #0xb0
    219c:	d2800803 	mov	x3, #0x40                  	// #64
    21a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    21a4:	93407c38 	sxtw	x24, w1
    21a8:	aa0303e1 	mov	x1, x3
    21ac:	fd008be8 	str	d8, [sp, #272]
    21b0:	1e604008 	fmov	d8, d0
    21b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    21b8:	910083f4 	add	x20, sp, #0x20
    21bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    21c0:	aa0003f5 	mov	x21, x0
    21c4:	a91073fb 	stp	x27, x28, [sp, #256]
    21c8:	5100071c 	sub	w28, w24, #0x1
    21cc:	2a1c03e5 	mov	w5, w28
    21d0:	f9400040 	ldr	x0, [x2]
    21d4:	f90057e0 	str	x0, [sp, #168]
    21d8:	d2800000 	mov	x0, #0x0                   	// #0
    21dc:	52800042 	mov	w2, #0x2                   	// #2
    21e0:	aa1403e0 	mov	x0, x20
    21e4:	97fffc8b 	bl	1410 <__snprintf_chk@plt>
    21e8:	52800ca1 	mov	w1, #0x65                  	// #101
    21ec:	aa1403e0 	mov	x0, x20
    21f0:	97fffce4 	bl	1580 <strchr@plt>
    21f4:	aa0003f3 	mov	x19, x0
    21f8:	52800142 	mov	w2, #0xa                   	// #10
    21fc:	91000400 	add	x0, x0, #0x1
    2200:	d2800001 	mov	x1, #0x0                   	// #0
    2204:	97fffccf 	bl	1540 <strtol@plt>
    2208:	aa0003f7 	mov	x23, x0
    220c:	11001400 	add	w0, w0, #0x5
    2210:	7100541f 	cmp	w0, #0x15
    2214:	54000d68 	b.hi	23c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    2218:	4b170385 	sub	w5, w28, w23
    221c:	710000bf 	cmp	w5, #0x0
    2220:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2224:	54000b80 	b.eq	2394 <fwp_format_g.constprop.0+0x214>  // b.none
    2228:	394083e0 	ldrb	w0, [sp, #32]
    222c:	cb180273 	sub	x19, x19, x24
    2230:	91000673 	add	x19, x19, #0x1
    2234:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2238:	7100b41f 	cmp	w0, #0x2d
    223c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2240:	1a9f17e4 	cset	w4, eq	// eq = none
    2244:	cb010266 	sub	x6, x19, x1
    2248:	d10004da 	sub	x26, x6, #0x1
    224c:	540018a0 	b.eq	2560 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2250:	910183f9 	add	x25, sp, #0x60
    2254:	d280091b 	mov	x27, #0x48                  	// #72
    2258:	aa1903e7 	mov	x7, x25
    225c:	91000423 	add	x3, x1, #0x1
    2260:	91011cc6 	add	x6, x6, #0x47
    2264:	910004f6 	add	x22, x7, #0x1
    2268:	37f80ff7 	tbnz	w23, #31, 2464 <fwp_format_g.constprop.0+0x2e4>
    226c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2270:	93407ef7 	sxtw	x23, w23
    2274:	390000e4 	strb	w4, [x7]
    2278:	aa1303e1 	mov	x1, x19
    227c:	aa1703e2 	mov	x2, x23
    2280:	aa1603e0 	mov	x0, x22
    2284:	b9000be5 	str	w5, [sp, #8]
    2288:	cb170374 	sub	x20, x27, x23
    228c:	a9011be3 	stp	x3, x6, [sp, #16]
    2290:	97fffc1c 	bl	1300 <memcpy@plt>
    2294:	d1000694 	sub	x20, x20, #0x1
    2298:	f9400be3 	ldr	x3, [sp, #16]
    229c:	8b1702d6 	add	x22, x22, x23
    22a0:	aa1603e0 	mov	x0, x22
    22a4:	aa1a03e2 	mov	x2, x26
    22a8:	aa0303e1 	mov	x1, x3
    22ac:	aa1403e3 	mov	x3, x20
    22b0:	97fffc50 	bl	13f0 <__memcpy_chk@plt>
    22b4:	8b1a02d6 	add	x22, x22, x26
    22b8:	f9400fe6 	ldr	x6, [sp, #24]
    22bc:	d2800900 	mov	x0, #0x48                  	// #72
    22c0:	b9400be5 	ldr	w5, [sp, #8]
    22c4:	8b170261 	add	x1, x19, x23
    22c8:	cb1400c3 	sub	x3, x6, x20
    22cc:	cb060294 	sub	x20, x20, x6
    22d0:	f101207f 	cmp	x3, #0x48
    22d4:	93407cb8 	sxtw	x24, w5
    22d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    22dc:	aa1803e2 	mov	x2, x24
    22e0:	8b1802d3 	add	x19, x22, x24
    22e4:	8b140063 	add	x3, x3, x20
    22e8:	aa1603e0 	mov	x0, x22
    22ec:	97fffc41 	bl	13f0 <__memcpy_chk@plt>
    22f0:	cb190273 	sub	x19, x19, x25
    22f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    22f8:	eb00027f 	cmp	x19, x0
    22fc:	aa1903e1 	mov	x1, x25
    2300:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2304:	aa1503e0 	mov	x0, x21
    2308:	aa1303e2 	mov	x2, x19
    230c:	97fffbfd 	bl	1300 <memcpy@plt>
    2310:	38336abf 	strb	wzr, [x21, x19]
    2314:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2318:	aa1503e0 	mov	x0, x21
    231c:	97fffc05 	bl	1330 <strlen@plt>
    2320:	aa0003f3 	mov	x19, x0
    2324:	528005c1 	mov	w1, #0x2e                  	// #46
    2328:	aa1503e0 	mov	x0, x21
    232c:	97fffc95 	bl	1580 <strchr@plt>
    2330:	b4000140 	cbz	x0, 2358 <fwp_format_g.constprop.0+0x1d8>
    2334:	b4000133 	cbz	x19, 2358 <fwp_format_g.constprop.0+0x1d8>
    2338:	aa1303e1 	mov	x1, x19
    233c:	d1000673 	sub	x19, x19, #0x1
    2340:	38736aa0 	ldrb	w0, [x21, x19]
    2344:	7100c01f 	cmp	w0, #0x30
    2348:	54001001 	b.ne	2548 <fwp_format_g.constprop.0+0x3c8>  // b.any
    234c:	38336abf 	strb	wzr, [x21, x19]
    2350:	b5ffff53 	cbnz	x19, 2338 <fwp_format_g.constprop.0+0x1b8>
    2354:	d503201f 	nop
    2358:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    235c:	f947f400 	ldr	x0, [x0, #4072]
    2360:	f94057e2 	ldr	x2, [sp, #168]
    2364:	f9400001 	ldr	x1, [x0]
    2368:	eb010042 	subs	x2, x2, x1
    236c:	d2800001 	mov	x1, #0x0                   	// #0
    2370:	54001061 	b.ne	257c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2374:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2378:	a94c53f3 	ldp	x19, x20, [sp, #192]
    237c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2380:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2384:	a95073fb 	ldp	x27, x28, [sp, #256]
    2388:	fd408be8 	ldr	d8, [sp, #272]
    238c:	910483ff 	add	sp, sp, #0x120
    2390:	d65f03c0 	ret
    2394:	1e604100 	fmov	d0, d8
    2398:	710000bf 	cmp	w5, #0x0
    239c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    23a0:	aa1503e0 	mov	x0, x21
    23a4:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    23a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    23ac:	9136a084 	add	x4, x4, #0xda8
    23b0:	52800042 	mov	w2, #0x2                   	// #2
    23b4:	d2803201 	mov	x1, #0x190                 	// #400
    23b8:	97fffc16 	bl	1410 <__snprintf_chk@plt>
    23bc:	17ffffd7 	b	2318 <fwp_format_g.constprop.0+0x198>
    23c0:	cb140273 	sub	x19, x19, x20
    23c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    23c8:	910183f9 	add	x25, sp, #0x60
    23cc:	aa1303e2 	mov	x2, x19
    23d0:	aa1403e1 	mov	x1, x20
    23d4:	aa1903e0 	mov	x0, x25
    23d8:	d2800803 	mov	x3, #0x40                  	// #64
    23dc:	97fffc05 	bl	13f0 <__memcpy_chk@plt>
    23e0:	38336b3f 	strb	wzr, [x25, x19]
    23e4:	aa1903e0 	mov	x0, x25
    23e8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ec:	97fffc65 	bl	1580 <strchr@plt>
    23f0:	b40001c0 	cbz	x0, 2428 <fwp_format_g.constprop.0+0x2a8>
    23f4:	b50000b3 	cbnz	x19, 2408 <fwp_format_g.constprop.0+0x288>
    23f8:	1400000c 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    23fc:	381ff01f 	sturb	wzr, [x0, #-1]
    2400:	f1000673 	subs	x19, x19, #0x1
    2404:	54000120 	b.eq	2428 <fwp_format_g.constprop.0+0x2a8>  // b.none
    2408:	8b130320 	add	x0, x25, x19
    240c:	385ff001 	ldurb	w1, [x0, #-1]
    2410:	7100c03f 	cmp	w1, #0x30
    2414:	54ffff40 	b.eq	23fc <fwp_format_g.constprop.0+0x27c>  // b.none
    2418:	d1000673 	sub	x19, x19, #0x1
    241c:	38736b20 	ldrb	w0, [x25, x19]
    2420:	7100b81f 	cmp	w0, #0x2e
    2424:	54000a80 	b.eq	2574 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2428:	710002ff 	cmp	w23, #0x0
    242c:	528005a1 	mov	w1, #0x2d                  	// #45
    2430:	aa1903e5 	mov	x5, x25
    2434:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2438:	aa1503e0 	mov	x0, x21
    243c:	52800566 	mov	w6, #0x2b                  	// #43
    2440:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    2444:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2448:	91366084 	add	x4, x4, #0xd98
    244c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2450:	52800042 	mov	w2, #0x2                   	// #2
    2454:	d2803201 	mov	x1, #0x190                 	// #400
    2458:	97fffbee 	bl	1410 <__snprintf_chk@plt>
    245c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2460:	17ffffbe 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2464:	52800605 	mov	w5, #0x30                  	// #48
    2468:	390000e5 	strb	w5, [x7]
    246c:	d100077b 	sub	x27, x27, #0x1
    2470:	aa0303e1 	mov	x1, x3
    2474:	aa1603e0 	mov	x0, x22
    2478:	aa1b03e3 	mov	x3, x27
    247c:	aa1a03e2 	mov	x2, x26
    2480:	f90007e6 	str	x6, [sp, #8]
    2484:	b90013e4 	str	w4, [sp, #16]
    2488:	8b1a02d6 	add	x22, x22, x26
    248c:	b9001be5 	str	w5, [sp, #24]
    2490:	97fffbd8 	bl	13f0 <__memcpy_chk@plt>
    2494:	f94007e6 	ldr	x6, [sp, #8]
    2498:	2a3703e7 	mvn	w7, w23
    249c:	b94013e4 	ldr	w4, [sp, #16]
    24a0:	cb1b00c1 	sub	x1, x6, x27
    24a4:	cb06037b 	sub	x27, x27, x6
    24a8:	f101203f 	cmp	x1, #0x48
    24ac:	d2800906 	mov	x6, #0x48                  	// #72
    24b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    24b4:	8b1b0023 	add	x3, x1, x27
    24b8:	310006ff 	cmn	w23, #0x1
    24bc:	54000220 	b.eq	2500 <fwp_format_g.constprop.0+0x380>  // b.none
    24c0:	b9401be5 	ldr	w5, [sp, #24]
    24c4:	d2800001 	mov	x1, #0x0                   	// #0
    24c8:	f101207f 	cmp	x3, #0x48
    24cc:	d1000462 	sub	x2, x3, #0x1
    24d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    24d4:	38216ac5 	strb	w5, [x22, x1]
    24d8:	cb030003 	sub	x3, x0, x3
    24dc:	91000421 	add	x1, x1, #0x1
    24e0:	91000463 	add	x3, x3, #0x1
    24e4:	eb00007f 	cmp	x3, x0
    24e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24ec:	cb000063 	sub	x3, x3, x0
    24f0:	8b020063 	add	x3, x3, x2
    24f4:	6b0100ff 	cmp	w7, w1
    24f8:	54fffe8c 	b.gt	24c8 <fwp_format_g.constprop.0+0x348>
    24fc:	8b2742d6 	add	x22, x22, w7, uxtw
    2500:	f101207f 	cmp	x3, #0x48
    2504:	d2800905 	mov	x5, #0x48                  	// #72
    2508:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    250c:	aa1603e0 	mov	x0, x22
    2510:	cb0300a1 	sub	x1, x5, x3
    2514:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2518:	91000421 	add	x1, x1, #0x1
    251c:	d1000463 	sub	x3, x3, #0x1
    2520:	eb05003f 	cmp	x1, x5
    2524:	38001402 	strb	w2, [x0], #1
    2528:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    252c:	93407f82 	sxtw	x2, w28
    2530:	cb050025 	sub	x5, x1, x5
    2534:	aa1303e1 	mov	x1, x19
    2538:	8b0300a3 	add	x3, x5, x3
    253c:	8b1802d3 	add	x19, x22, x24
    2540:	97fffbac 	bl	13f0 <__memcpy_chk@plt>
    2544:	17ffff6b 	b	22f0 <fwp_format_g.constprop.0+0x170>
    2548:	d1000421 	sub	x1, x1, #0x1
    254c:	38616aa0 	ldrb	w0, [x21, x1]
    2550:	7100b81f 	cmp	w0, #0x2e
    2554:	54fff021 	b.ne	2358 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2558:	38216abf 	strb	wzr, [x21, x1]
    255c:	17ffff7f 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2560:	910187e7 	add	x7, sp, #0x61
    2564:	910183f9 	add	x25, sp, #0x60
    2568:	d28008fb 	mov	x27, #0x47                  	// #71
    256c:	390183e0 	strb	w0, [sp, #96]
    2570:	17ffff3b 	b	225c <fwp_format_g.constprop.0+0xdc>
    2574:	38336b3f 	strb	wzr, [x25, x19]
    2578:	17ffffac 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    257c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2580:	97fffbc8 	bl	14a0 <__stack_chk_fail@plt>

0000000000002584 <fwp_heap_report>:
    2584:	d105c3ff 	sub	sp, sp, #0x170
    2588:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    258c:	91144042 	add	x2, x2, #0x510
    2590:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x160a0>
    2594:	f947e821 	ldr	x1, [x1, #4048]
    2598:	a9117bfd 	stp	x29, x30, [sp, #272]
    259c:	910443fd 	add	x29, sp, #0x110
    25a0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    25a4:	f947f400 	ldr	x0, [x0, #4072]
    25a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    25ac:	a91463f7 	stp	x23, x24, [sp, #320]
    25b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    25b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    25b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    25bc:	fd4a2049 	ldr	d9, [x2, #5184]
    25c0:	f9400036 	ldr	x22, [x1]
    25c4:	f9400001 	ldr	x1, [x0]
    25c8:	f90087e1 	str	x1, [sp, #264]
    25cc:	d2800001 	mov	x1, #0x0                   	// #0
    25d0:	f949e459 	ldr	x25, [x2, #5064]
    25d4:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    25d8:	f94a1057 	ldr	x23, [x2, #5152]
    25dc:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    25e0:	f94a1458 	ldr	x24, [x2, #5160]
    25e4:	9136c021 	add	x1, x1, #0xdb0
    25e8:	9136e000 	add	x0, x0, #0xdb8
    25ec:	97fffb91 	bl	1430 <fopen@plt>
    25f0:	b4000760 	cbz	x0, 26dc <fwp_heap_report+0x158>
    25f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    25f8:	a91253f3 	stp	x19, x20, [sp, #288]
    25fc:	aa0003f4 	mov	x20, x0
    2600:	910023f3 	add	x19, sp, #0x8
    2604:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2608:	72aae915 	movk	w21, #0x5748, lsl #16
    260c:	d503201f 	nop
    2610:	aa1403e2 	mov	x2, x20
    2614:	aa1303e0 	mov	x0, x19
    2618:	52802001 	mov	w1, #0x100                 	// #256
    261c:	97fffc0d 	bl	1650 <fgets@plt>
    2620:	b4000280 	cbz	x0, 2670 <fwp_heap_report+0xec>
    2624:	b9400261 	ldr	w1, [x19]
    2628:	6b15003f 	cmp	w1, w21
    262c:	54ffff21 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2630:	39401260 	ldrb	w0, [x19, #4]
    2634:	7101341f 	cmp	w0, #0x4d
    2638:	54fffec1 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    263c:	394037e0 	ldrb	w0, [sp, #13]
    2640:	7100e81f 	cmp	w0, #0x3a
    2644:	54fffe61 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2648:	52800142 	mov	w2, #0xa                   	// #10
    264c:	d2800001 	mov	x1, #0x0                   	// #0
    2650:	91003be0 	add	x0, sp, #0xe
    2654:	97fffbbb 	bl	1540 <strtol@plt>
    2658:	aa1403e2 	mov	x2, x20
    265c:	aa0003fa 	mov	x26, x0
    2660:	52802001 	mov	w1, #0x100                 	// #256
    2664:	aa1303e0 	mov	x0, x19
    2668:	97fffbfa 	bl	1650 <fgets@plt>
    266c:	b5fffdc0 	cbnz	x0, 2624 <fwp_heap_report+0xa0>
    2670:	aa1403e0 	mov	x0, x20
    2674:	97fffb6b 	bl	1420 <fclose@plt>
    2678:	a95253f3 	ldp	x19, x20, [sp, #288]
    267c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    2680:	f947f400 	ldr	x0, [x0, #4072]
    2684:	f94087e2 	ldr	x2, [sp, #264]
    2688:	f9400001 	ldr	x1, [x0]
    268c:	eb010042 	subs	x2, x2, x1
    2690:	d2800001 	mov	x1, #0x0                   	// #0
    2694:	54000281 	b.ne	26e4 <fwp_heap_report+0x160>  // b.any
    2698:	a9517bfd 	ldp	x29, x30, [sp, #272]
    269c:	aa1a03e6 	mov	x6, x26
    26a0:	aa1903e5 	mov	x5, x25
    26a4:	aa1803e4 	mov	x4, x24
    26a8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    26ac:	aa1703e3 	mov	x3, x23
    26b0:	a95463f7 	ldp	x23, x24, [sp, #320]
    26b4:	aa1603e0 	mov	x0, x22
    26b8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    26bc:	1e604121 	fmov	d1, d9
    26c0:	1e604100 	fmov	d0, d8
    26c4:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x23fc>
    26c8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    26cc:	91376042 	add	x2, x2, #0xdd8
    26d0:	9105c3ff 	add	sp, sp, #0x170
    26d4:	52800041 	mov	w1, #0x2                   	// #2
    26d8:	17fffb8e 	b	1510 <__fprintf_chk@plt>
    26dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    26e0:	17ffffe7 	b	267c <fwp_heap_report+0xf8>
    26e4:	a91253f3 	stp	x19, x20, [sp, #288]
    26e8:	97fffb6e 	bl	14a0 <__stack_chk_fail@plt>
    26ec:	d503201f 	nop

00000000000026f0 <fwp_heap_init>:
    26f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    26f4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaf0>
    26f8:	91104061 	add	x1, x3, #0x410
    26fc:	910003fd 	mov	x29, sp
    2700:	a90153f3 	stp	x19, x20, [sp, #16]
    2704:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2708:	91144262 	add	x2, x19, #0x510
    270c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2710:	52800024 	mov	w4, #0x1                   	// #1
    2714:	52800200 	mov	w0, #0x10                  	// #16
    2718:	b913a444 	str	w4, [x2, #5028]
    271c:	d503201f 	nop
    2720:	b8004420 	str	w0, [x1], #4
    2724:	11004000 	add	w0, w0, #0x10
    2728:	7104401f 	cmp	w0, #0x110
    272c:	54ffffa1 	b.ne	2720 <fwp_heap_init+0x30>  // b.any
    2730:	d0000022 	adrp	x2, 8000 <_IO_stdin_used+0x300>
    2734:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2738:	90000181 	adrp	x1, 32000 <fwp_heap+0xaf0>
    273c:	91114021 	add	x1, x1, #0x450
    2740:	3dc08843 	ldr	q3, [x2, #544]
    2744:	d2800000 	mov	x0, #0x0                   	// #0
    2748:	4e040401 	dup	v1.4s, v0.s[0]
    274c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2750:	0f215400 	shl	v0.2s, v0.2s, #1
    2754:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2758:	3ca06821 	str	q1, [x1, x0]
    275c:	91004000 	add	x0, x0, #0x10
    2760:	f101801f 	cmp	x0, #0x60
    2764:	54ffff21 	b.ne	2748 <fwp_heap_init+0x58>  // b.any
    2768:	90000184 	adrp	x4, 32000 <fwp_heap+0xaf0>
    276c:	91104063 	add	x3, x3, #0x410
    2770:	9112c084 	add	x4, x4, #0x4b0
    2774:	91144266 	add	x6, x19, #0x510
    2778:	d2800002 	mov	x2, #0x0                   	// #0
    277c:	d2800000 	mov	x0, #0x0                   	// #0
    2780:	d2880205 	mov	x5, #0x4010                	// #16400
    2784:	d503201f 	nop
    2788:	910f0001 	add	x1, x0, #0x3c0
    278c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2790:	eb02003f 	cmp	x1, x2
    2794:	540000a2 	b.cs	27a8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2798:	91000400 	add	x0, x0, #0x1
    279c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    27a0:	eb02003f 	cmp	x1, x2
    27a4:	54ffffa3 	b.cc	2798 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    27a8:	91004042 	add	x2, x2, #0x10
    27ac:	38001480 	strb	w0, [x4], #1
    27b0:	eb05005f 	cmp	x2, x5
    27b4:	54fffea1 	b.ne	2788 <fwp_heap_init+0x98>  // b.any
    27b8:	528000b5 	mov	w21, #0x5                   	// #5
    27bc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    27c0:	14000004 	b	27d0 <fwp_heap_init+0xe0>
    27c4:	d342fe94 	lsr	x20, x20, #2
    27c8:	710006b5 	subs	w21, w21, #0x1
    27cc:	54000720 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    27d0:	91404296 	add	x22, x20, #0x10, lsl #12
    27d4:	d2800005 	mov	x5, #0x0                   	// #0
    27d8:	aa1603e1 	mov	x1, x22
    27dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    27e0:	52880443 	mov	w3, #0x4022                	// #16418
    27e4:	52800002 	mov	w2, #0x0                   	// #0
    27e8:	d2800000 	mov	x0, #0x0                   	// #0
    27ec:	97fffb51 	bl	1530 <mmap@plt>
    27f0:	aa0003e6 	mov	x6, x0
    27f4:	b100041f 	cmn	x0, #0x1
    27f8:	54fffe60 	b.eq	27c4 <fwp_heap_init+0xd4>  // b.none
    27fc:	b40005a0 	cbz	x0, 28b0 <fwp_heap_init+0x1c0>
    2800:	d350fe94 	lsr	x20, x20, #16
    2804:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2808:	8b0000c7 	add	x7, x6, x0
    280c:	91144275 	add	x21, x19, #0x510
    2810:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2814:	8b140a81 	add	x1, x20, x20, lsl #2
    2818:	d2800005 	mov	x5, #0x0                   	// #0
    281c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2820:	d37df021 	lsl	x1, x1, #3
    2824:	52880443 	mov	w3, #0x4022                	// #16418
    2828:	52800002 	mov	w2, #0x0                   	// #0
    282c:	d2800000 	mov	x0, #0x0                   	// #0
    2830:	f909daa7 	str	x7, [x21, #5040]
    2834:	f909dea6 	str	x6, [x21, #5048]
    2838:	f909e2b6 	str	x22, [x21, #5056]
    283c:	f909eab4 	str	x20, [x21, #5072]
    2840:	f90a02a1 	str	x1, [x21, #5120]
    2844:	97fffb3b 	bl	1530 <mmap@plt>
    2848:	aa0003e1 	mov	x1, x0
    284c:	b100041f 	cmn	x0, #0x1
    2850:	54000300 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    2854:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    2858:	913a2000 	add	x0, x0, #0xe88
    285c:	f909fea1 	str	x1, [x21, #5112]
    2860:	97fffb74 	bl	1630 <getenv@plt>
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	aa0003e1 	mov	x1, x0
    286c:	b40000e0 	cbz	x0, 2888 <fwp_heap_init+0x198>
    2870:	39400000 	ldrb	w0, [x0]
    2874:	340000a0 	cbz	w0, 2888 <fwp_heap_init+0x198>
    2878:	7100c000 	subs	w0, w0, #0x30
    287c:	54000120 	b.eq	28a0 <fwp_heap_init+0x1b0>  // b.none
    2880:	7100001f 	cmp	w0, #0x0
    2884:	1a9f07e2 	cset	w2, ne	// ne = any
    2888:	91144273 	add	x19, x19, #0x510
    288c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2890:	b913aa62 	str	w2, [x19, #5032]
    2894:	a94153f3 	ldp	x19, x20, [sp, #16]
    2898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    289c:	d65f03c0 	ret
    28a0:	39400420 	ldrb	w0, [x1, #1]
    28a4:	7100001f 	cmp	w0, #0x0
    28a8:	1a9f07e2 	cset	w2, ne	// ne = any
    28ac:	17fffff7 	b	2888 <fwp_heap_init+0x198>
    28b0:	97fffcb8 	bl	1b90 <fwp_heap_oom>

00000000000028b4 <fwp_wake_io>:
    28b4:	d00000e9 	adrp	x9, 20000 <__data_start>
    28b8:	9101c122 	add	x2, x9, #0x70
    28bc:	f9400001 	ldr	x1, [x0]
    28c0:	5280000a 	mov	w10, #0x0                   	// #0
    28c4:	f9401046 	ldr	x6, [x2, #32]
    28c8:	52800008 	mov	w8, #0x0                   	// #0
    28cc:	4f000400 	movi	v0.4s, #0x0
    28d0:	52800027 	mov	w7, #0x1                   	// #1
    28d4:	aa0103e2 	mov	x2, x1
    28d8:	b4000321 	cbz	x1, 293c <fwp_wake_io+0x88>
    28dc:	f9408c25 	ldr	x5, [x1, #280]
    28e0:	39015c27 	strb	w7, [x1, #87]
    28e4:	b4000165 	cbz	x5, 2910 <fwp_wake_io+0x5c>
    28e8:	a9520c24 	ldp	x4, x3, [x1, #288]
    28ec:	b4000364 	cbz	x4, 2958 <fwp_wake_io+0xa4>
    28f0:	f9009483 	str	x3, [x4, #296]
    28f4:	f9409423 	ldr	x3, [x1, #296]
    28f8:	b4000043 	cbz	x3, 2900 <fwp_wake_io+0x4c>
    28fc:	f9009064 	str	x4, [x3, #288]
    2900:	91080023 	add	x3, x1, #0x200
    2904:	f900943f 	str	xzr, [x1, #296]
    2908:	3c918060 	stur	q0, [x3, #-232]
    290c:	f9400001 	ldr	x1, [x0]
    2910:	f9402843 	ldr	x3, [x2, #80]
    2914:	f2001c7f 	tst	x3, #0xff000000ff
    2918:	54fffde1 	b.ne	28d4 <fwp_wake_io+0x20>  // b.any
    291c:	39015047 	strb	w7, [x2, #84]
    2920:	f900805f 	str	xzr, [x2, #256]
    2924:	b40001e6 	cbz	x6, 2960 <fwp_wake_io+0xac>
    2928:	f90080c2 	str	x2, [x6, #256]
    292c:	aa0203e6 	mov	x6, x2
    2930:	52800028 	mov	w8, #0x1                   	// #1
    2934:	aa0103e2 	mov	x2, x1
    2938:	b5fffd21 	cbnz	x1, 28dc <fwp_wake_io+0x28>
    293c:	3400006a 	cbz	w10, 2948 <fwp_wake_io+0x94>
    2940:	9101c120 	add	x0, x9, #0x70
    2944:	f900140b 	str	x11, [x0, #40]
    2948:	34000068 	cbz	w8, 2954 <fwp_wake_io+0xa0>
    294c:	9101c129 	add	x9, x9, #0x70
    2950:	f9001126 	str	x6, [x9, #32]
    2954:	d65f03c0 	ret
    2958:	f90000a3 	str	x3, [x5]
    295c:	17ffffe7 	b	28f8 <fwp_wake_io+0x44>
    2960:	aa0203eb 	mov	x11, x2
    2964:	5280002a 	mov	w10, #0x1                   	// #1
    2968:	17fffff1 	b	292c <fwp_wake_io+0x78>
    296c:	d503201f 	nop

0000000000002970 <fwp_poll_events>:
    2970:	d10103ff 	sub	sp, sp, #0x40
    2974:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    2978:	f947f400 	ldr	x0, [x0, #4072]
    297c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2980:	910083fd 	add	x29, sp, #0x20
    2984:	a90353f3 	stp	x19, x20, [sp, #48]
    2988:	d00000f4 	adrp	x20, 20000 <__data_start>
    298c:	f9400001 	ldr	x1, [x0]
    2990:	f9000fe1 	str	x1, [sp, #24]
    2994:	d2800001 	mov	x1, #0x0                   	// #0
    2998:	97fffdd2 	bl	20e0 <fwp_now_ns>
    299c:	9101c281 	add	x1, x20, #0x70
    29a0:	f9401833 	ldr	x19, [x1, #48]
    29a4:	b4000e93 	cbz	x19, 2b74 <fwp_poll_events+0x204>
    29a8:	aa1303e1 	mov	x1, x19
    29ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    29b0:	14000005 	b	29c4 <fwp_poll_events+0x54>
    29b4:	f9408821 	ldr	x1, [x1, #272]
    29b8:	eb03005f 	cmp	x2, x3
    29bc:	9a83d042 	csel	x2, x2, x3, le
    29c0:	b40000c1 	cbz	x1, 29d8 <fwp_poll_events+0x68>
    29c4:	f9403423 	ldr	x3, [x1, #104]
    29c8:	b6ffff62 	tbz	x2, #63, 29b4 <fwp_poll_events+0x44>
    29cc:	f9408821 	ldr	x1, [x1, #272]
    29d0:	aa0303e2 	mov	x2, x3
    29d4:	b5ffff81 	cbnz	x1, 29c4 <fwp_poll_events+0x54>
    29d8:	b7f80ce2 	tbnz	x2, #63, 2b74 <fwp_poll_events+0x204>
    29dc:	cb000042 	sub	x2, x2, x0
    29e0:	f100005f 	cmp	x2, #0x0
    29e4:	540005cd 	b.le	2a9c <fwp_poll_events+0x12c>
    29e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    29ec:	d2884801 	mov	x1, #0x4240                	// #16960
    29f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    29f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    29f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    29fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a00:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a04:	9b407c40 	smulh	x0, x2, x0
    2a08:	9352fc00 	asr	x0, x0, #18
    2a0c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2a10:	9b018802 	msub	x2, x0, x1, x2
    2a14:	f100005f 	cmp	x2, #0x0
    2a18:	9a800400 	cinc	x0, x0, ne	// ne = any
    2a1c:	eb03001f 	cmp	x0, x3
    2a20:	54000a0c 	b.gt	2b60 <fwp_poll_events+0x1f0>
    2a24:	340003c0 	cbz	w0, 2a9c <fwp_poll_events+0x12c>
    2a28:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2a2c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2a30:	72a20c42 	movk	w2, #0x1062, lsl #16
    2a34:	9ba27c02 	umull	x2, w0, w2
    2a38:	d366fc43 	lsr	x3, x2, #38
    2a3c:	aa0303e2 	mov	x2, x3
    2a40:	1b048063 	msub	w3, w3, w4, w0
    2a44:	9b217c63 	smull	x3, w3, w1
    2a48:	d2800001 	mov	x1, #0x0                   	// #0
    2a4c:	910023e0 	add	x0, sp, #0x8
    2a50:	a9008fe2 	stp	x2, x3, [sp, #8]
    2a54:	97fffac7 	bl	1570 <nanosleep@plt>
    2a58:	9101c280 	add	x0, x20, #0x70
    2a5c:	f9401813 	ldr	x19, [x0, #48]
    2a60:	97fffda0 	bl	20e0 <fwp_now_ns>
    2a64:	aa0003e6 	mov	x6, x0
    2a68:	b50001f3 	cbnz	x19, 2aa4 <fwp_poll_events+0x134>
    2a6c:	d503201f 	nop
    2a70:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    2a74:	f947f400 	ldr	x0, [x0, #4072]
    2a78:	f9400fe2 	ldr	x2, [sp, #24]
    2a7c:	f9400001 	ldr	x1, [x0]
    2a80:	eb010042 	subs	x2, x2, x1
    2a84:	d2800001 	mov	x1, #0x0                   	// #0
    2a88:	540008c1 	b.ne	2ba0 <fwp_poll_events+0x230>  // b.any
    2a8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2a90:	a94353f3 	ldp	x19, x20, [sp, #48]
    2a94:	910103ff 	add	sp, sp, #0x40
    2a98:	d65f03c0 	ret
    2a9c:	97fffd91 	bl	20e0 <fwp_now_ns>
    2aa0:	aa0003e6 	mov	x6, x0
    2aa4:	4f000400 	movi	v0.4s, #0x0
    2aa8:	9101c288 	add	x8, x20, #0x70
    2aac:	52800027 	mov	w7, #0x1                   	// #1
    2ab0:	f9403661 	ldr	x1, [x19, #104]
    2ab4:	aa1303e5 	mov	x5, x19
    2ab8:	f9408a73 	ldr	x19, [x19, #272]
    2abc:	eb06003f 	cmp	x1, x6
    2ac0:	5400032c 	b.gt	2b24 <fwp_poll_events+0x1b4>
    2ac4:	394154a0 	ldrb	w0, [x5, #85]
    2ac8:	36000120 	tbz	w0, #0, 2aec <fwp_poll_events+0x17c>
    2acc:	f94084a0 	ldr	x0, [x5, #264]
    2ad0:	b40003c0 	cbz	x0, 2b48 <fwp_poll_events+0x1d8>
    2ad4:	f9008813 	str	x19, [x0, #272]
    2ad8:	b4000053 	cbz	x19, 2ae0 <fwp_poll_events+0x170>
    2adc:	f9008660 	str	x0, [x19, #264]
    2ae0:	910800a0 	add	x0, x5, #0x200
    2ae4:	390154bf 	strb	wzr, [x5, #85]
    2ae8:	3c908000 	stur	q0, [x0, #-248]
    2aec:	f94030a0 	ldr	x0, [x5, #96]
    2af0:	390158a7 	strb	w7, [x5, #86]
    2af4:	f100001f 	cmp	x0, #0x0
    2af8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2afc:	5400018d 	b.le	2b2c <fwp_poll_events+0x1bc>
    2b00:	f94028a0 	ldr	x0, [x5, #80]
    2b04:	f2001c1f 	tst	x0, #0xff000000ff
    2b08:	540000e1 	b.ne	2b24 <fwp_poll_events+0x1b4>  // b.any
    2b0c:	f9401100 	ldr	x0, [x8, #32]
    2b10:	390150a7 	strb	w7, [x5, #84]
    2b14:	f90080bf 	str	xzr, [x5, #256]
    2b18:	b40001e0 	cbz	x0, 2b54 <fwp_poll_events+0x1e4>
    2b1c:	f9001105 	str	x5, [x8, #32]
    2b20:	f9008005 	str	x5, [x0, #256]
    2b24:	b5fffc73 	cbnz	x19, 2ab0 <fwp_poll_events+0x140>
    2b28:	17ffffd2 	b	2a70 <fwp_poll_events+0x100>
    2b2c:	394144a0 	ldrb	w0, [x5, #81]
    2b30:	3707fe80 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b34:	394140a0 	ldrb	w0, [x5, #80]
    2b38:	3707fe40 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b3c:	aa0503e0 	mov	x0, x5
    2b40:	97fffd14 	bl	1f90 <fwp_cancel_tree.part.0>
    2b44:	17ffffef 	b	2b00 <fwp_poll_events+0x190>
    2b48:	9101c281 	add	x1, x20, #0x70
    2b4c:	f9001833 	str	x19, [x1, #48]
    2b50:	17ffffe2 	b	2ad8 <fwp_poll_events+0x168>
    2b54:	f9001105 	str	x5, [x8, #32]
    2b58:	f9001505 	str	x5, [x8, #40]
    2b5c:	17fffff2 	b	2b24 <fwp_poll_events+0x1b4>
    2b60:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2b64:	d2989362 	mov	x2, #0xc49b                	// #50331
    2b68:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2b6c:	f2a00402 	movk	x2, #0x20, lsl #16
    2b70:	17ffffb6 	b	2a48 <fwp_poll_events+0xd8>
    2b74:	97fffbf7 	bl	1b50 <fwp_flush>
    2b78:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x160a0>
    2b7c:	f947e863 	ldr	x3, [x3, #4048]
    2b80:	d2800562 	mov	x2, #0x2b                  	// #43
    2b84:	d2800021 	mov	x1, #0x1                   	// #1
    2b88:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    2b8c:	913a6000 	add	x0, x0, #0xe98
    2b90:	f9400063 	ldr	x3, [x3]
    2b94:	97fffa83 	bl	15a0 <fwrite@plt>
    2b98:	52800ca0 	mov	w0, #0x65                  	// #101
    2b9c:	97fff9ed 	bl	1350 <exit@plt>
    2ba0:	97fffa40 	bl	14a0 <__stack_chk_fail@plt>

0000000000002ba4 <fwp_rc_forget_slot>:
    2ba4:	aa0003e1 	mov	x1, x0
    2ba8:	39400000 	ldrb	w0, [x0]
    2bac:	7103fc1f 	cmp	w0, #0xff
    2bb0:	54000040 	b.eq	2bb8 <fwp_rc_forget_slot+0x14>  // b.none
    2bb4:	d65f03c0 	ret
    2bb8:	ca414420 	eor	x0, x1, x1, lsr #17
    2bbc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    2bc4:	910003fd 	mov	x29, sp
    2bc8:	92401c00 	and	x0, x0, #0xff
    2bcc:	f9000bf3 	str	x19, [sp, #16]
    2bd0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2bd4:	91144262 	add	x2, x19, #0x510
    2bd8:	910a2403 	add	x3, x0, #0x289
    2bdc:	8b000c40 	add	x0, x2, x0, lsl #3
    2be0:	8b030c43 	add	x3, x2, x3, lsl #3
    2be4:	f94a2400 	ldr	x0, [x0, #5192]
    2be8:	b50000a0 	cbnz	x0, 2bfc <fwp_rc_forget_slot+0x58>
    2bec:	14000011 	b	2c30 <fwp_rc_forget_slot+0x8c>
    2bf0:	91004003 	add	x3, x0, #0x10
    2bf4:	f9400800 	ldr	x0, [x0, #16]
    2bf8:	b40001c0 	cbz	x0, 2c30 <fwp_rc_forget_slot+0x8c>
    2bfc:	f9400002 	ldr	x2, [x0]
    2c00:	eb02003f 	cmp	x1, x2
    2c04:	54ffff61 	b.ne	2bf0 <fwp_rc_forget_slot+0x4c>  // b.any
    2c08:	f9400801 	ldr	x1, [x0, #16]
    2c0c:	91144273 	add	x19, x19, #0x510
    2c10:	f9000061 	str	x1, [x3]
    2c14:	97fffa53 	bl	1560 <free@plt>
    2c18:	f94e2660 	ldr	x0, [x19, #7240]
    2c1c:	d1000400 	sub	x0, x0, #0x1
    2c20:	f90e2660 	str	x0, [x19, #7240]
    2c24:	f9400bf3 	ldr	x19, [sp, #16]
    2c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2c2c:	d65f03c0 	ret
    2c30:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    2c34:	913b2000 	add	x0, x0, #0xec8
    2c38:	97fffd1a 	bl	20a0 <fwp_trap>
    2c3c:	d503201f 	nop

0000000000002c40 <fwp_rc_prepare_chunk>:
    2c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c44:	910003fd 	mov	x29, sp
    2c48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c4c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcd0>
    2c50:	911442c2 	add	x2, x22, #0x510
    2c54:	b9401c03 	ldr	w3, [x0, #28]
    2c58:	aa0103f5 	mov	x21, x1
    2c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c60:	aa0003f4 	mov	x20, x0
    2c64:	f94e2440 	ldr	x0, [x2, #7240]
    2c68:	b4000440 	cbz	x0, 2cf0 <fwp_rc_prepare_chunk+0xb0>
    2c6c:	d2800013 	mov	x19, #0x0                   	// #0
    2c70:	35000203 	cbnz	w3, 2cb0 <fwp_rc_prepare_chunk+0x70>
    2c74:	b4000361 	cbz	x1, 2ce0 <fwp_rc_prepare_chunk+0xa0>
    2c78:	f9401280 	ldr	x0, [x20, #32]
    2c7c:	97fffa39 	bl	1560 <free@plt>
    2c80:	aa1503e0 	mov	x0, x21
    2c84:	d2800021 	mov	x1, #0x1                   	// #1
    2c88:	97fff9fe 	bl	1480 <calloc@plt>
    2c8c:	f9001280 	str	x0, [x20, #32]
    2c90:	b5000460 	cbnz	x0, 2d1c <fwp_rc_prepare_chunk+0xdc>
    2c94:	97fffbbf 	bl	1b90 <fwp_heap_oom>
    2c98:	97ffffc3 	bl	2ba4 <fwp_rc_forget_slot>
    2c9c:	91000673 	add	x19, x19, #0x1
    2ca0:	b9401e83 	ldr	w3, [x20, #28]
    2ca4:	eb13007f 	cmp	x3, x19
    2ca8:	54000169 	b.ls	2cd4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2cac:	d503201f 	nop
    2cb0:	f9401283 	ldr	x3, [x20, #32]
    2cb4:	8b130060 	add	x0, x3, x19
    2cb8:	38736863 	ldrb	w3, [x3, x19]
    2cbc:	7103fc7f 	cmp	w3, #0xff
    2cc0:	54fffec0 	b.eq	2c98 <fwp_rc_prepare_chunk+0x58>  // b.none
    2cc4:	b9401e83 	ldr	w3, [x20, #28]
    2cc8:	91000673 	add	x19, x19, #0x1
    2ccc:	eb13007f 	cmp	x3, x19
    2cd0:	54ffff08 	b.hi	2cb0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2cd4:	eb0302bf 	cmp	x21, x3
    2cd8:	54000121 	b.ne	2cfc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2cdc:	b5000335 	cbnz	x21, 2d40 <fwp_rc_prepare_chunk+0x100>
    2ce0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ce4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ce8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cec:	d65f03c0 	ret
    2cf0:	2a0303e3 	mov	w3, w3
    2cf4:	eb0302bf 	cmp	x21, x3
    2cf8:	54ffff20 	b.eq	2cdc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2cfc:	911442c2 	add	x2, x22, #0x510
    2d00:	f9401280 	ldr	x0, [x20, #32]
    2d04:	f94e2841 	ldr	x1, [x2, #7248]
    2d08:	cb030021 	sub	x1, x1, x3
    2d0c:	f90e2841 	str	x1, [x2, #7248]
    2d10:	97fffa14 	bl	1560 <free@plt>
    2d14:	b5fffb75 	cbnz	x21, 2c80 <fwp_rc_prepare_chunk+0x40>
    2d18:	f900129f 	str	xzr, [x20, #32]
    2d1c:	911442d6 	add	x22, x22, #0x510
    2d20:	f94e2ac0 	ldr	x0, [x22, #7248]
    2d24:	b9001e95 	str	w21, [x20, #28]
    2d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d2c:	8b150000 	add	x0, x0, x21
    2d30:	f90e2ac0 	str	x0, [x22, #7248]
    2d34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d3c:	d65f03c0 	ret
    2d40:	f9401280 	ldr	x0, [x20, #32]
    2d44:	aa1503e2 	mov	x2, x21
    2d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d4c:	52800001 	mov	w1, #0x0                   	// #0
    2d50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d58:	17fff9c6 	b	1470 <memset@plt>
    2d5c:	d503201f 	nop

0000000000002d60 <fwp_heap_refill>:
    2d60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d64:	910003fd 	mov	x29, sp
    2d68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d6c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2d70:	911442b5 	add	x21, x21, #0x510
    2d74:	aa0003f6 	mov	x22, x0
    2d78:	d2800020 	mov	x0, #0x1                   	// #1
    2d7c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d80:	a90363f7 	stp	x23, x24, [sp, #48]
    2d84:	2a0103f7 	mov	w23, w1
    2d88:	2a0203f8 	mov	w24, w2
    2d8c:	97fffbc1 	bl	1c90 <fwp_heap_chunks>
    2d90:	aa0003f3 	mov	x19, x0
    2d94:	f949fea2 	ldr	x2, [x21, #5112]
    2d98:	8b000800 	add	x0, x0, x0, lsl #2
    2d9c:	2a1703e1 	mov	w1, w23
    2da0:	52800025 	mov	w5, #0x1                   	// #1
    2da4:	d37df000 	lsl	x0, x0, #3
    2da8:	910f0021 	add	x1, x1, #0x3c0
    2dac:	8b000054 	add	x20, x2, x0
    2db0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2db4:	52a00024 	mov	w4, #0x10000               	// #65536
    2db8:	38206845 	strb	w5, [x2, x0]
    2dbc:	aa1403e0 	mov	x0, x20
    2dc0:	39000698 	strb	w24, [x20, #1]
    2dc4:	39000a97 	strb	w23, [x20, #2]
    2dc8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2dcc:	b9000681 	str	w1, [x20, #4]
    2dd0:	2a0103e5 	mov	w5, w1
    2dd4:	8b0300a2 	add	x2, x5, x3
    2dd8:	1ac10881 	udiv	w1, w4, w1
    2ddc:	9ac50842 	udiv	x2, x2, x5
    2de0:	b9000a81 	str	w1, [x20, #8]
    2de4:	92404021 	and	x1, x1, #0x1ffff
    2de8:	b9001a82 	str	w2, [x20, #24]
    2dec:	97ffff95 	bl	2c40 <fwp_rc_prepare_chunk>
    2df0:	f949daa0 	ldr	x0, [x21, #5040]
    2df4:	29408a81 	ldp	w1, w2, [x20, #4]
    2df8:	8b134000 	add	x0, x0, x19, lsl #16
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	8b214003 	add	x3, x0, w1, uxtw
    2e04:	9ba20021 	umaddl	x1, w1, w2, x0
    2e08:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e0c:	a90086c3 	stp	x3, x1, [x22, #8]
    2e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e14:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e18:	d65f03c0 	ret
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_mem_free>:
    2e20:	b40003c0 	cbz	x0, 2e98 <fwp_mem_free+0x78>
    2e24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2e28:	910003fd 	mov	x29, sp
    2e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e30:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2e34:	911442a1 	add	x1, x21, #0x510
    2e38:	a90153f3 	stp	x19, x20, [sp, #16]
    2e3c:	aa0003f3 	mov	x19, x0
    2e40:	f949d823 	ldr	x3, [x1, #5040]
    2e44:	f949ec22 	ldr	x2, [x1, #5080]
    2e48:	cb030000 	sub	x0, x0, x3
    2e4c:	eb02401f 	cmp	x0, x2, lsl #16
    2e50:	540001c2 	b.cs	2e88 <fwp_mem_free+0x68>  // b.hs, b.nlast
    2e54:	d350fc16 	lsr	x22, x0, #16
    2e58:	a90363f7 	stp	x23, x24, [sp, #48]
    2e5c:	f949fc22 	ldr	x2, [x1, #5112]
    2e60:	8b160ad4 	add	x20, x22, x22, lsl #2
    2e64:	d37df294 	lsl	x20, x20, #3
    2e68:	ab140057 	adds	x23, x2, x20
    2e6c:	540000c0 	b.eq	2e84 <fwp_mem_free+0x64>  // b.none
    2e70:	38746842 	ldrb	w2, [x2, x20]
    2e74:	7100045f 	cmp	w2, #0x1
    2e78:	54000120 	b.eq	2e9c <fwp_mem_free+0x7c>  // b.none
    2e7c:	7100085f 	cmp	w2, #0x2
    2e80:	540005e0 	b.eq	2f3c <fwp_mem_free+0x11c>  // b.none
    2e84:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e90:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2e94:	d65f03c0 	ret
    2e98:	d65f03c0 	ret
    2e9c:	f94012f8 	ldr	x24, [x23, #32]
    2ea0:	b94006e1 	ldr	w1, [x23, #4]
    2ea4:	f90023f9 	str	x25, [sp, #64]
    2ea8:	2a0103e2 	mov	w2, w1
    2eac:	394006f9 	ldrb	w25, [x23, #1]
    2eb0:	39400af4 	ldrb	w20, [x23, #2]
    2eb4:	b4000158 	cbz	x24, 2edc <fwp_mem_free+0xbc>
    2eb8:	92403e76 	and	x22, x19, #0xffff
    2ebc:	9ac20ad6 	udiv	x22, x22, x2
    2ec0:	38766b01 	ldrb	w1, [x24, x22]
    2ec4:	8b160300 	add	x0, x24, x22
    2ec8:	7103fc3f 	cmp	w1, #0xff
    2ecc:	54000980 	b.eq	2ffc <fwp_mem_free+0x1dc>  // b.none
    2ed0:	38366b1f 	strb	wzr, [x24, x22]
    2ed4:	b94006e1 	ldr	w1, [x23, #4]
    2ed8:	2a0103e2 	mov	w2, w1
    2edc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    2ee0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    2ee4:	cb390000 	sub	x0, x0, w25, uxtb
    2ee8:	8b340074 	add	x20, x3, w20, uxtb
    2eec:	911442b5 	add	x21, x21, #0x510
    2ef0:	1e630021 	ucvtf	d1, w1
    2ef4:	d37ae400 	lsl	x0, x0, #6
    2ef8:	8b140c14 	add	x20, x0, x20, lsl #3
    2efc:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f00:	f8746aa0 	ldr	x0, [x21, x20]
    2f04:	f94023f9 	ldr	x25, [sp, #64]
    2f08:	aa2003e0 	mvn	x0, x0
    2f0c:	fd4a22a0 	ldr	d0, [x21, #5184]
    2f10:	f9000260 	str	x0, [x19]
    2f14:	f8346ab3 	str	x19, [x21, x20]
    2f18:	f94a12a0 	ldr	x0, [x21, #5152]
    2f1c:	1e612800 	fadd	d0, d0, d1
    2f20:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f24:	cb020000 	sub	x0, x0, x2
    2f28:	f90a12a0 	str	x0, [x21, #5152]
    2f2c:	fd0a22a0 	str	d0, [x21, #5184]
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2f38:	d65f03c0 	ret
    2f3c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    2f40:	8b000063 	add	x3, x3, x0
    2f44:	eb03027f 	cmp	x19, x3
    2f48:	54fff9e1 	b.ne	2e84 <fwp_mem_free+0x64>  // b.any
    2f4c:	fd400ae1 	ldr	d1, [x23, #16]
    2f50:	fd4a2020 	ldr	d0, [x1, #5184]
    2f54:	f9400ae0 	ldr	x0, [x23, #16]
    2f58:	7e61d821 	ucvtf	d1, d1
    2f5c:	f94a1022 	ldr	x2, [x1, #5152]
    2f60:	f94012f3 	ldr	x19, [x23, #32]
    2f64:	1e612800 	fadd	d0, d0, d1
    2f68:	cb000042 	sub	x2, x2, x0
    2f6c:	f90a1022 	str	x2, [x1, #5152]
    2f70:	fd0a2020 	str	d0, [x1, #5184]
    2f74:	b40000b3 	cbz	x19, 2f88 <fwp_mem_free+0x168>
    2f78:	39400260 	ldrb	w0, [x19]
    2f7c:	7103fc1f 	cmp	w0, #0xff
    2f80:	54000380 	b.eq	2ff0 <fwp_mem_free+0x1d0>  // b.none
    2f84:	3900027f 	strb	wzr, [x19]
    2f88:	b9400ee2 	ldr	w2, [x23, #12]
    2f8c:	b4000142 	cbz	x2, 2fb4 <fwp_mem_free+0x194>
    2f90:	911442a1 	add	x1, x21, #0x510
    2f94:	8b160040 	add	x0, x2, x22
    2f98:	8b000800 	add	x0, x0, x0, lsl #2
    2f9c:	f949fc21 	ldr	x1, [x1, #5112]
    2fa0:	8b140034 	add	x20, x1, x20
    2fa4:	8b000c20 	add	x0, x1, x0, lsl #3
    2fa8:	3802869f 	strb	wzr, [x20], #40
    2fac:	eb00029f 	cmp	x20, x0
    2fb0:	54ffffc1 	b.ne	2fa8 <fwp_mem_free+0x188>  // b.any
    2fb4:	911442a0 	add	x0, x21, #0x510
    2fb8:	f94a1801 	ldr	x1, [x0, #5168]
    2fbc:	f949f803 	ldr	x3, [x0, #5104]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f90a1801 	str	x1, [x0, #5168]
    2fc8:	eb16007f 	cmp	x3, x22
    2fcc:	54000049 	b.ls	2fd4 <fwp_mem_free+0x1b4>  // b.plast
    2fd0:	f909f816 	str	x22, [x0, #5104]
    2fd4:	911442b5 	add	x21, x21, #0x510
    2fd8:	f949f6a0 	ldr	x0, [x21, #5096]
    2fdc:	eb16001f 	cmp	x0, x22
    2fe0:	54fff529 	b.ls	2e84 <fwp_mem_free+0x64>  // b.plast
    2fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fe8:	f909f6b6 	str	x22, [x21, #5096]
    2fec:	17ffffa7 	b	2e88 <fwp_mem_free+0x68>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	97fffeec 	bl	2ba4 <fwp_rc_forget_slot>
    2ff8:	17ffffe3 	b	2f84 <fwp_mem_free+0x164>
    2ffc:	97fffeea 	bl	2ba4 <fwp_rc_forget_slot>
    3000:	17ffffb4 	b	2ed0 <fwp_mem_free+0xb0>

0000000000003004 <fwp_heap_alloc_big>:
    3004:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3008:	910003fd 	mov	x29, sp
    300c:	a90153f3 	stp	x19, x20, [sp, #16]
    3010:	a9025bf5 	stp	x21, x22, [sp, #32]
    3014:	a90363f7 	stp	x23, x24, [sp, #48]
    3018:	aa0003f7 	mov	x23, x0
    301c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3020:	a9046bf9 	stp	x25, x26, [sp, #64]
    3024:	eb0002ff 	cmp	x23, x0
    3028:	54000888 	b.hi	3138 <fwp_heap_alloc_big+0x134>  // b.pmore
    302c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3030:	8b0002f4 	add	x20, x23, x0
    3034:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcd0>
    3038:	91144359 	add	x25, x26, #0x510
    303c:	d350fe94 	lsr	x20, x20, #16
    3040:	2a0103f5 	mov	w21, w1
    3044:	aa1403e0 	mov	x0, x20
    3048:	97fffb12 	bl	1c90 <fwp_heap_chunks>
    304c:	f949ff22 	ldr	x2, [x25, #5112]
    3050:	8b000813 	add	x19, x0, x0, lsl #2
    3054:	aa0003f8 	mov	x24, x0
    3058:	52800043 	mov	w3, #0x2                   	// #2
    305c:	d37df273 	lsl	x19, x19, #3
    3060:	d2800021 	mov	x1, #0x1                   	// #1
    3064:	8b130040 	add	x0, x2, x19
    3068:	38336843 	strb	w3, [x2, x19]
    306c:	39000415 	strb	w21, [x0, #1]
    3070:	b9000c14 	str	w20, [x0, #12]
    3074:	f9000817 	str	x23, [x0, #16]
    3078:	97fffef2 	bl	2c40 <fwp_rc_prepare_chunk>
    307c:	f100069f 	cmp	x20, #0x1
    3080:	54000269 	b.ls	30cc <fwp_heap_alloc_big+0xc8>  // b.plast
    3084:	8b180294 	add	x20, x20, x24
    3088:	9100a273 	add	x19, x19, #0x28
    308c:	a90573fb 	stp	x27, x28, [sp, #80]
    3090:	5280007b 	mov	w27, #0x3                   	// #3
    3094:	8b140a94 	add	x20, x20, x20, lsl #2
    3098:	2a1803fc 	mov	w28, w24
    309c:	9adb2296 	lsl	x22, x20, x27
    30a0:	f949ff35 	ldr	x21, [x25, #5112]
    30a4:	d2800001 	mov	x1, #0x0                   	// #0
    30a8:	8b1302b4 	add	x20, x21, x19
    30ac:	aa1403e0 	mov	x0, x20
    30b0:	97fffee4 	bl	2c40 <fwp_rc_prepare_chunk>
    30b4:	38336abb 	strb	w27, [x21, x19]
    30b8:	9100a273 	add	x19, x19, #0x28
    30bc:	b9000e9c 	str	w28, [x20, #12]
    30c0:	eb1302df 	cmp	x22, x19
    30c4:	54fffee1 	b.ne	30a0 <fwp_heap_alloc_big+0x9c>  // b.any
    30c8:	a94573fb 	ldp	x27, x28, [sp, #80]
    30cc:	91144353 	add	x19, x26, #0x510
    30d0:	aa1703e2 	mov	x2, x23
    30d4:	52800001 	mov	w1, #0x0                   	// #0
    30d8:	f949da60 	ldr	x0, [x19, #5040]
    30dc:	8b184018 	add	x24, x0, x24, lsl #16
    30e0:	aa1803e0 	mov	x0, x24
    30e4:	97fff8e3 	bl	1470 <memset@plt>
    30e8:	f94a1260 	ldr	x0, [x19, #5152]
    30ec:	ab170000 	adds	x0, x0, x23
    30f0:	54000242 	b.cs	3138 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    30f4:	f94a1661 	ldr	x1, [x19, #5160]
    30f8:	f90a1260 	str	x0, [x19, #5152]
    30fc:	eb01001f 	cmp	x0, x1
    3100:	54000049 	b.ls	3108 <fwp_heap_alloc_big+0x104>  // b.plast
    3104:	f90a1660 	str	x0, [x19, #5160]
    3108:	9114435a 	add	x26, x26, #0x510
    310c:	9e6202e0 	scvtf	d0, x23
    3110:	a94153f3 	ldp	x19, x20, [sp, #16]
    3114:	aa1803e0 	mov	x0, x24
    3118:	fd4a1f41 	ldr	d1, [x26, #5176]
    311c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3120:	1e602820 	fadd	d0, d1, d0
    3124:	a94363f7 	ldp	x23, x24, [sp, #48]
    3128:	fd0a1f40 	str	d0, [x26, #5176]
    312c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3130:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3134:	d65f03c0 	ret
    3138:	a90573fb 	stp	x27, x28, [sp, #80]
    313c:	97fffa95 	bl	1b90 <fwp_heap_oom>

0000000000003140 <fwp_heap_alloc_slow>:
    3140:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3144:	910003fd 	mov	x29, sp
    3148:	a90153f3 	stp	x19, x20, [sp, #16]
    314c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    3150:	91144262 	add	x2, x19, #0x510
    3154:	a9025bf5 	stp	x21, x22, [sp, #32]
    3158:	aa0003f5 	mov	x21, x0
    315c:	2a0103f4 	mov	w20, w1
    3160:	b953a440 	ldr	w0, [x2, #5028]
    3164:	34000600 	cbz	w0, 3224 <fwp_heap_alloc_slow+0xe4>
    3168:	f14012bf 	cmp	x21, #0x4, lsl #12
    316c:	54000628 	b.hi	3230 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3170:	91003ea0 	add	x0, x21, #0xf
    3174:	91144262 	add	x2, x19, #0x510
    3178:	f9001bf7 	str	x23, [sp, #48]
    317c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3180:	8b401040 	add	x0, x2, x0, lsr #4
    3184:	cb34c084 	sub	x4, x4, w20, sxtw
    3188:	d37ae484 	lsl	x4, x4, #6
    318c:	397e8003 	ldrb	w3, [x0, #4000]
    3190:	910f0060 	add	x0, x3, #0x3c0
    3194:	aa0303e1 	mov	x1, x3
    3198:	8b030463 	add	x3, x3, x3, lsl #1
    319c:	8b030c83 	add	x3, x4, x3, lsl #3
    31a0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    31a4:	2a1703f6 	mov	w22, w23
    31a8:	f8636844 	ldr	x4, [x2, x3]
    31ac:	b40004e4 	cbz	x4, 3248 <fwp_heap_alloc_slow+0x108>
    31b0:	f9400080 	ldr	x0, [x4]
    31b4:	aa2003e0 	mvn	x0, x0
    31b8:	f8236840 	str	x0, [x2, x3]
    31bc:	7100069f 	cmp	w20, #0x1
    31c0:	aa0403e0 	mov	x0, x4
    31c4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    31c8:	52800001 	mov	w1, #0x0                   	// #0
    31cc:	97fff8a9 	bl	1470 <memset@plt>
    31d0:	aa0003e4 	mov	x4, x0
    31d4:	91144260 	add	x0, x19, #0x510
    31d8:	f94a1001 	ldr	x1, [x0, #5152]
    31dc:	ab160021 	adds	x1, x1, x22
    31e0:	540005c2 	b.cs	3298 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    31e4:	f94a1402 	ldr	x2, [x0, #5160]
    31e8:	f90a1001 	str	x1, [x0, #5152]
    31ec:	eb02003f 	cmp	x1, x2
    31f0:	54000049 	b.ls	31f8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    31f4:	f90a1401 	str	x1, [x0, #5160]
    31f8:	91144273 	add	x19, x19, #0x510
    31fc:	1e6302e1 	ucvtf	d1, w23
    3200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3204:	aa0403e0 	mov	x0, x4
    3208:	fd4a1e60 	ldr	d0, [x19, #5176]
    320c:	f9401bf7 	ldr	x23, [sp, #48]
    3210:	1e612800 	fadd	d0, d0, d1
    3214:	fd0a1e60 	str	d0, [x19, #5176]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3220:	d65f03c0 	ret
    3224:	97fffd33 	bl	26f0 <fwp_heap_init>
    3228:	f14012bf 	cmp	x21, #0x4, lsl #12
    322c:	54fffa29 	b.ls	3170 <fwp_heap_alloc_slow+0x30>  // b.plast
    3230:	2a1403e1 	mov	w1, w20
    3234:	aa1503e0 	mov	x0, x21
    3238:	a94153f3 	ldp	x19, x20, [sp, #16]
    323c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3240:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3244:	17ffff70 	b	3004 <fwp_heap_alloc_big>
    3248:	8b030042 	add	x2, x2, x3
    324c:	f9400444 	ldr	x4, [x2, #8]
    3250:	b4000104 	cbz	x4, 3270 <fwp_heap_alloc_slow+0x130>
    3254:	f9400840 	ldr	x0, [x2, #16]
    3258:	cb040000 	sub	x0, x0, x4
    325c:	eb16001f 	cmp	x0, x22
    3260:	54000083 	b.cc	3270 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3264:	8b160080 	add	x0, x4, x22
    3268:	f9000440 	str	x0, [x2, #8]
    326c:	17ffffd4 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3270:	52800302 	mov	w2, #0x18                  	// #24
    3274:	52807804 	mov	w4, #0x3c0                 	// #960
    3278:	91144260 	add	x0, x19, #0x510
    327c:	9ba27c23 	umull	x3, w1, w2
    3280:	2a1403e2 	mov	w2, w20
    3284:	9b240e84 	smaddl	x4, w20, w4, x3
    3288:	8b040000 	add	x0, x0, x4
    328c:	97fffeb5 	bl	2d60 <fwp_heap_refill>
    3290:	aa0003e4 	mov	x4, x0
    3294:	17ffffca 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3298:	97fffa3e 	bl	1b90 <fwp_heap_oom>
    329c:	d503201f 	nop

00000000000032a0 <fwp_rc_free_arr>:
    32a0:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    32a4:	91144063 	add	x3, x3, #0x510
    32a8:	f949d861 	ldr	x1, [x3, #5040]
    32ac:	f949ec62 	ldr	x2, [x3, #5080]
    32b0:	cb010001 	sub	x1, x0, x1
    32b4:	eb02403f 	cmp	x1, x2, lsl #16
    32b8:	54000342 	b.cs	3320 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    32bc:	d350fc22 	lsr	x2, x1, #16
    32c0:	f949fc65 	ldr	x5, [x3, #5112]
    32c4:	8b020842 	add	x2, x2, x2, lsl #2
    32c8:	d37df042 	lsl	x2, x2, #3
    32cc:	8b0200a4 	add	x4, x5, x2
    32d0:	f9401083 	ldr	x3, [x4, #32]
    32d4:	b4000263 	cbz	x3, 3320 <fwp_rc_free_arr+0x80>
    32d8:	386268a2 	ldrb	w2, [x5, x2]
    32dc:	7100085f 	cmp	w2, #0x2
    32e0:	540001c0 	b.eq	3318 <fwp_rc_free_arr+0x78>  // b.none
    32e4:	7100045f 	cmp	w2, #0x1
    32e8:	540001c1 	b.ne	3320 <fwp_rc_free_arr+0x80>  // b.any
    32ec:	29430885 	ldp	w5, w2, [x4, #24]
    32f0:	92403c21 	and	x1, x1, #0xffff
    32f4:	9b057c21 	mul	x1, x1, x5
    32f8:	d360fc21 	lsr	x1, x1, #32
    32fc:	eb02003f 	cmp	x1, x2
    3300:	54000102 	b.cs	3320 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    3304:	8b010063 	add	x3, x3, x1
    3308:	39400061 	ldrb	w1, [x3]
    330c:	7100043f 	cmp	w1, #0x1
    3310:	54000081 	b.ne	3320 <fwp_rc_free_arr+0x80>  // b.any
    3314:	17fffec3 	b	2e20 <fwp_mem_free>
    3318:	72003c3f 	tst	w1, #0xffff
    331c:	54ffff60 	b.eq	3308 <fwp_rc_free_arr+0x68>  // b.none
    3320:	d65f03c0 	ret

0000000000003324 <fwp_heap_alloc>:
    3324:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3328:	f140101f 	cmp	x0, #0x4, lsl #12
    332c:	910003fd 	mov	x29, sp
    3330:	a90153f3 	stp	x19, x20, [sp, #16]
    3334:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3338:	91144293 	add	x19, x20, #0x510
    333c:	b953a662 	ldr	w2, [x19, #5028]
    3340:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3344:	54000640 	b.eq	340c <fwp_heap_alloc+0xe8>  // b.none
    3348:	91003c03 	add	x3, x0, #0xf
    334c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3350:	937c7c22 	sbfiz	x2, x1, #4, #32
    3354:	8b431263 	add	x3, x19, x3, lsr #4
    3358:	cb21c042 	sub	x2, x2, w1, sxtw
    335c:	d37ae442 	lsl	x2, x2, #6
    3360:	397e8063 	ldrb	w3, [x3, #4000]
    3364:	910f0064 	add	x4, x3, #0x3c0
    3368:	8b030463 	add	x3, x3, x3, lsl #1
    336c:	8b030c43 	add	x3, x2, x3, lsl #3
    3370:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3374:	2a1603f5 	mov	w21, w22
    3378:	f8636a64 	ldr	x4, [x19, x3]
    337c:	b4000384 	cbz	x4, 33ec <fwp_heap_alloc+0xc8>
    3380:	f9400085 	ldr	x5, [x4]
    3384:	7100043f 	cmp	w1, #0x1
    3388:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    338c:	aa0403e0 	mov	x0, x4
    3390:	aa2503e5 	mvn	x5, x5
    3394:	52800001 	mov	w1, #0x0                   	// #0
    3398:	f8236a65 	str	x5, [x19, x3]
    339c:	97fff835 	bl	1470 <memset@plt>
    33a0:	aa0003e4 	mov	x4, x0
    33a4:	f94a1260 	ldr	x0, [x19, #5152]
    33a8:	ab150000 	adds	x0, x0, x21
    33ac:	54000442 	b.cs	3434 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    33b0:	f94a1661 	ldr	x1, [x19, #5160]
    33b4:	f90a1260 	str	x0, [x19, #5152]
    33b8:	eb01001f 	cmp	x0, x1
    33bc:	54000049 	b.ls	33c4 <fwp_heap_alloc+0xa0>  // b.plast
    33c0:	f90a1660 	str	x0, [x19, #5160]
    33c4:	91144294 	add	x20, x20, #0x510
    33c8:	1e6302c1 	ucvtf	d1, w22
    33cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33d0:	aa0403e0 	mov	x0, x4
    33d4:	fd4a1e80 	ldr	d0, [x20, #5176]
    33d8:	1e612800 	fadd	d0, d0, d1
    33dc:	fd0a1e80 	str	d0, [x20, #5176]
    33e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    33e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e8:	d65f03c0 	ret
    33ec:	8b030263 	add	x3, x19, x3
    33f0:	f9400464 	ldr	x4, [x3, #8]
    33f4:	b40000a4 	cbz	x4, 3408 <fwp_heap_alloc+0xe4>
    33f8:	f9400862 	ldr	x2, [x3, #16]
    33fc:	cb040042 	sub	x2, x2, x4
    3400:	eb15005f 	cmp	x2, x21
    3404:	540000a2 	b.cs	3418 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    3408:	a9425bf5 	ldp	x21, x22, [sp, #32]
    340c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3410:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3414:	17ffff4b 	b	3140 <fwp_heap_alloc_slow>
    3418:	7100043f 	cmp	w1, #0x1
    341c:	8b150085 	add	x5, x4, x21
    3420:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    3424:	52800001 	mov	w1, #0x0                   	// #0
    3428:	aa0403e0 	mov	x0, x4
    342c:	f9000465 	str	x5, [x3, #8]
    3430:	17ffffdb 	b	339c <fwp_heap_alloc+0x78>
    3434:	97fff9d7 	bl	1b90 <fwp_heap_oom>
    3438:	d503201f 	nop
    343c:	d503201f 	nop

0000000000003440 <fwp_data.part.0.constprop.0>:
    3440:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3444:	910003fd 	mov	x29, sp
    3448:	a90153f3 	stp	x19, x20, [sp, #16]
    344c:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3450:	91144283 	add	x3, x20, #0x510
    3454:	a9025bf5 	stp	x21, x22, [sp, #32]
    3458:	aa0103f5 	mov	x21, x1
    345c:	b953a461 	ldr	w1, [x3, #5028]
    3460:	a90363f7 	stp	x23, x24, [sp, #48]
    3464:	2a0003f8 	mov	w24, w0
    3468:	34000701 	cbz	w1, 3548 <fwp_data.part.0.constprop.0+0x108>
    346c:	397e8862 	ldrb	w2, [x3, #4002]
    3470:	910f0040 	add	x0, x2, #0x3c0
    3474:	8b020442 	add	x2, x2, x2, lsl #1
    3478:	d37df042 	lsl	x2, x2, #3
    347c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    3480:	2a1703f6 	mov	w22, w23
    3484:	f8626873 	ldr	x19, [x3, x2]
    3488:	b40004d3 	cbz	x19, 3520 <fwp_data.part.0.constprop.0+0xe0>
    348c:	f9400260 	ldr	x0, [x19]
    3490:	aa2003e0 	mvn	x0, x0
    3494:	f8226860 	str	x0, [x3, x2]
    3498:	f10062df 	cmp	x22, #0x18
    349c:	540000e9 	b.ls	34b8 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    34a0:	d10066c2 	sub	x2, x22, #0x19
    34a4:	91006260 	add	x0, x19, #0x18
    34a8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    34ac:	52800001 	mov	w1, #0x0                   	// #0
    34b0:	91002042 	add	x2, x2, #0x8
    34b4:	97fff7ef 	bl	1470 <memset@plt>
    34b8:	91144282 	add	x2, x20, #0x510
    34bc:	f94a1041 	ldr	x1, [x2, #5152]
    34c0:	ab160021 	adds	x1, x1, x22
    34c4:	540004c2 	b.cs	355c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    34c8:	f94a1440 	ldr	x0, [x2, #5160]
    34cc:	f90a1041 	str	x1, [x2, #5152]
    34d0:	eb00003f 	cmp	x1, x0
    34d4:	54000049 	b.ls	34dc <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    34d8:	f90a1441 	str	x1, [x2, #5160]
    34dc:	91144294 	add	x20, x20, #0x510
    34e0:	1e6302e1 	ucvtf	d1, w23
    34e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    34e8:	1e612800 	fadd	d0, d0, d1
    34ec:	fd0a1e80 	str	d0, [x20, #5176]
    34f0:	52800041 	mov	w1, #0x2                   	// #2
    34f4:	29000678 	stp	w24, w1, [x19]
    34f8:	aa1303e0 	mov	x0, x19
    34fc:	f94002a1 	ldr	x1, [x21]
    3500:	f9000661 	str	x1, [x19, #8]
    3504:	f94006a1 	ldr	x1, [x21, #8]
    3508:	f9000a61 	str	x1, [x19, #16]
    350c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3514:	a94363f7 	ldp	x23, x24, [sp, #48]
    3518:	a8c47bfd 	ldp	x29, x30, [sp], #64
    351c:	d65f03c0 	ret
    3520:	8b020063 	add	x3, x3, x2
    3524:	f9400473 	ldr	x19, [x3, #8]
    3528:	b4000113 	cbz	x19, 3548 <fwp_data.part.0.constprop.0+0x108>
    352c:	f9400860 	ldr	x0, [x3, #16]
    3530:	cb130000 	sub	x0, x0, x19
    3534:	eb0002df 	cmp	x22, x0
    3538:	54000088 	b.hi	3548 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    353c:	8b160260 	add	x0, x19, x22
    3540:	f9000460 	str	x0, [x3, #8]
    3544:	17ffffd5 	b	3498 <fwp_data.part.0.constprop.0+0x58>
    3548:	52800001 	mov	w1, #0x0                   	// #0
    354c:	d2800300 	mov	x0, #0x18                  	// #24
    3550:	97ffff75 	bl	3324 <fwp_heap_alloc>
    3554:	aa0003f3 	mov	x19, x0
    3558:	17ffffe6 	b	34f0 <fwp_data.part.0.constprop.0+0xb0>
    355c:	97fff98d 	bl	1b90 <fwp_heap_oom>

0000000000003560 <fwp_array_new_packed.constprop.0>:
    3560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3564:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3568:	910003fd 	mov	x29, sp
    356c:	f9000bf3 	str	x19, [sp, #16]
    3570:	eb01001f 	cmp	x0, x1
    3574:	54000148 	b.hi	359c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    3578:	aa0003f3 	mov	x19, x0
    357c:	91000400 	add	x0, x0, #0x1
    3580:	52800021 	mov	w1, #0x1                   	// #1
    3584:	d37df000 	lsl	x0, x0, #3
    3588:	97ffff67 	bl	3324 <fwp_heap_alloc>
    358c:	f9000013 	str	x19, [x0]
    3590:	f9400bf3 	ldr	x19, [sp, #16]
    3594:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3598:	d65f03c0 	ret
    359c:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    35a0:	913bc000 	add	x0, x0, #0xef0
    35a4:	97fffabf 	bl	20a0 <fwp_trap>
    35a8:	d503201f 	nop
    35ac:	d503201f 	nop

00000000000035b0 <fwp_drop1>:
    35b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    35b4:	910003fd 	mov	x29, sp
    35b8:	a90153f3 	stp	x19, x20, [sp, #16]
    35bc:	f90013f5 	str	x21, [sp, #32]
    35c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    35c4:	911442b4 	add	x20, x21, #0x510
    35c8:	f949da81 	ldr	x1, [x20, #5040]
    35cc:	f949ee82 	ldr	x2, [x20, #5080]
    35d0:	cb010001 	sub	x1, x0, x1
    35d4:	eb02403f 	cmp	x1, x2, lsl #16
    35d8:	54000382 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    35dc:	d350fc22 	lsr	x2, x1, #16
    35e0:	f949fe84 	ldr	x4, [x20, #5112]
    35e4:	8b020842 	add	x2, x2, x2, lsl #2
    35e8:	d37df042 	lsl	x2, x2, #3
    35ec:	8b020083 	add	x3, x4, x2
    35f0:	f9401073 	ldr	x19, [x3, #32]
    35f4:	b40002b3 	cbz	x19, 3648 <fwp_drop1+0x98>
    35f8:	38626882 	ldrb	w2, [x4, x2]
    35fc:	7100085f 	cmp	w2, #0x2
    3600:	540002c0 	b.eq	3658 <fwp_drop1+0xa8>  // b.none
    3604:	7100045f 	cmp	w2, #0x1
    3608:	54000201 	b.ne	3648 <fwp_drop1+0x98>  // b.any
    360c:	29430864 	ldp	w4, w2, [x3, #24]
    3610:	92403c21 	and	x1, x1, #0xffff
    3614:	9b047c21 	mul	x1, x1, x4
    3618:	d360fc21 	lsr	x1, x1, #32
    361c:	eb02003f 	cmp	x1, x2
    3620:	54000142 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    3624:	8b010273 	add	x19, x19, x1
    3628:	39400261 	ldrb	w1, [x19]
    362c:	340000e1 	cbz	w1, 3648 <fwp_drop1+0x98>
    3630:	7100043f 	cmp	w1, #0x1
    3634:	540001e0 	b.eq	3670 <fwp_drop1+0xc0>  // b.none
    3638:	7103fc3f 	cmp	w1, #0xff
    363c:	540002e0 	b.eq	3698 <fwp_drop1+0xe8>  // b.none
    3640:	51000421 	sub	w1, w1, #0x1
    3644:	39000261 	strb	w1, [x19]
    3648:	a94153f3 	ldp	x19, x20, [sp, #16]
    364c:	f94013f5 	ldr	x21, [sp, #32]
    3650:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3654:	d65f03c0 	ret
    3658:	72003c3f 	tst	w1, #0xffff
    365c:	54fffe60 	b.eq	3628 <fwp_drop1+0x78>  // b.none
    3660:	a94153f3 	ldp	x19, x20, [sp, #16]
    3664:	f94013f5 	ldr	x21, [sp, #32]
    3668:	a8c37bfd 	ldp	x29, x30, [sp], #48
    366c:	d65f03c0 	ret
    3670:	f9400813 	ldr	x19, [x0, #16]
    3674:	97ffff0b 	bl	32a0 <fwp_rc_free_arr>
    3678:	911442a0 	add	x0, x21, #0x510
    367c:	f949d801 	ldr	x1, [x0, #5040]
    3680:	f949ec00 	ldr	x0, [x0, #5080]
    3684:	cb010261 	sub	x1, x19, x1
    3688:	eb00403f 	cmp	x1, x0, lsl #16
    368c:	54fffde2 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    3690:	aa1303e0 	mov	x0, x19
    3694:	17ffffd2 	b	35dc <fwp_drop1+0x2c>
    3698:	ca534660 	eor	x0, x19, x19, lsr #17
    369c:	911442b5 	add	x21, x21, #0x510
    36a0:	ca402400 	eor	x0, x0, x0, lsr #9
    36a4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    36a8:	f94a2400 	ldr	x0, [x0, #5192]
    36ac:	b5000080 	cbnz	x0, 36bc <fwp_drop1+0x10c>
    36b0:	14000010 	b	36f0 <fwp_drop1+0x140>
    36b4:	f9400800 	ldr	x0, [x0, #16]
    36b8:	b40001c0 	cbz	x0, 36f0 <fwp_drop1+0x140>
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb13003f 	cmp	x1, x19
    36c4:	54ffff81 	b.ne	36b4 <fwp_drop1+0x104>  // b.any
    36c8:	f9400401 	ldr	x1, [x0, #8]
    36cc:	d1000421 	sub	x1, x1, #0x1
    36d0:	f9000401 	str	x1, [x0, #8]
    36d4:	f103f83f 	cmp	x1, #0xfe
    36d8:	54fffb81 	b.ne	3648 <fwp_drop1+0x98>  // b.any
    36dc:	aa1303e0 	mov	x0, x19
    36e0:	97fffd31 	bl	2ba4 <fwp_rc_forget_slot>
    36e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    36e8:	39000260 	strb	w0, [x19]
    36ec:	17ffffd7 	b	3648 <fwp_drop1+0x98>
    36f0:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    36f4:	913b2000 	add	x0, x0, #0xec8
    36f8:	97fffa6a 	bl	20a0 <fwp_trap>
    36fc:	d503201f 	nop

0000000000003700 <fwp_drop0>:
    3700:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3704:	910003fd 	mov	x29, sp
    3708:	a90153f3 	stp	x19, x20, [sp, #16]
    370c:	f90013f5 	str	x21, [sp, #32]
    3710:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    3714:	911442b4 	add	x20, x21, #0x510
    3718:	f949da81 	ldr	x1, [x20, #5040]
    371c:	f949ee82 	ldr	x2, [x20, #5080]
    3720:	cb010001 	sub	x1, x0, x1
    3724:	eb02403f 	cmp	x1, x2, lsl #16
    3728:	54000382 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    372c:	d350fc22 	lsr	x2, x1, #16
    3730:	f949fe84 	ldr	x4, [x20, #5112]
    3734:	8b020842 	add	x2, x2, x2, lsl #2
    3738:	d37df042 	lsl	x2, x2, #3
    373c:	8b020083 	add	x3, x4, x2
    3740:	f9401073 	ldr	x19, [x3, #32]
    3744:	b40002b3 	cbz	x19, 3798 <fwp_drop0+0x98>
    3748:	38626882 	ldrb	w2, [x4, x2]
    374c:	7100085f 	cmp	w2, #0x2
    3750:	540002c0 	b.eq	37a8 <fwp_drop0+0xa8>  // b.none
    3754:	7100045f 	cmp	w2, #0x1
    3758:	54000201 	b.ne	3798 <fwp_drop0+0x98>  // b.any
    375c:	29430864 	ldp	w4, w2, [x3, #24]
    3760:	92403c21 	and	x1, x1, #0xffff
    3764:	9b047c21 	mul	x1, x1, x4
    3768:	d360fc21 	lsr	x1, x1, #32
    376c:	eb02003f 	cmp	x1, x2
    3770:	54000142 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    3774:	8b010273 	add	x19, x19, x1
    3778:	39400261 	ldrb	w1, [x19]
    377c:	340000e1 	cbz	w1, 3798 <fwp_drop0+0x98>
    3780:	7100043f 	cmp	w1, #0x1
    3784:	540001e0 	b.eq	37c0 <fwp_drop0+0xc0>  // b.none
    3788:	7103fc3f 	cmp	w1, #0xff
    378c:	540002e0 	b.eq	37e8 <fwp_drop0+0xe8>  // b.none
    3790:	51000421 	sub	w1, w1, #0x1
    3794:	39000261 	strb	w1, [x19]
    3798:	a94153f3 	ldp	x19, x20, [sp, #16]
    379c:	f94013f5 	ldr	x21, [sp, #32]
    37a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    37a4:	d65f03c0 	ret
    37a8:	72003c3f 	tst	w1, #0xffff
    37ac:	54fffe60 	b.eq	3778 <fwp_drop0+0x78>  // b.none
    37b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    37b4:	f94013f5 	ldr	x21, [sp, #32]
    37b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    37bc:	d65f03c0 	ret
    37c0:	f9400813 	ldr	x19, [x0, #16]
    37c4:	97fffeb7 	bl	32a0 <fwp_rc_free_arr>
    37c8:	911442a0 	add	x0, x21, #0x510
    37cc:	f949d801 	ldr	x1, [x0, #5040]
    37d0:	f949ec00 	ldr	x0, [x0, #5080]
    37d4:	cb010261 	sub	x1, x19, x1
    37d8:	eb00403f 	cmp	x1, x0, lsl #16
    37dc:	54fffde2 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    37e0:	aa1303e0 	mov	x0, x19
    37e4:	17ffffd2 	b	372c <fwp_drop0+0x2c>
    37e8:	ca534660 	eor	x0, x19, x19, lsr #17
    37ec:	911442b5 	add	x21, x21, #0x510
    37f0:	ca402400 	eor	x0, x0, x0, lsr #9
    37f4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    37f8:	f94a2400 	ldr	x0, [x0, #5192]
    37fc:	b5000080 	cbnz	x0, 380c <fwp_drop0+0x10c>
    3800:	14000010 	b	3840 <fwp_drop0+0x140>
    3804:	f9400800 	ldr	x0, [x0, #16]
    3808:	b40001c0 	cbz	x0, 3840 <fwp_drop0+0x140>
    380c:	f9400001 	ldr	x1, [x0]
    3810:	eb13003f 	cmp	x1, x19
    3814:	54ffff81 	b.ne	3804 <fwp_drop0+0x104>  // b.any
    3818:	f9400401 	ldr	x1, [x0, #8]
    381c:	d1000421 	sub	x1, x1, #0x1
    3820:	f9000401 	str	x1, [x0, #8]
    3824:	f103f83f 	cmp	x1, #0xfe
    3828:	54fffb81 	b.ne	3798 <fwp_drop0+0x98>  // b.any
    382c:	aa1303e0 	mov	x0, x19
    3830:	97fffcdd 	bl	2ba4 <fwp_rc_forget_slot>
    3834:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3838:	39000260 	strb	w0, [x19]
    383c:	17ffffd7 	b	3798 <fwp_drop0+0x98>
    3840:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    3844:	913b2000 	add	x0, x0, #0xec8
    3848:	97fffa16 	bl	20a0 <fwp_trap>
    384c:	d503201f 	nop

0000000000003850 <fwp_task_dispose>:
    3850:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3854:	910003fd 	mov	x29, sp
    3858:	f9000bf3 	str	x19, [sp, #16]
    385c:	aa0003f3 	mov	x19, x0
    3860:	39414000 	ldrb	w0, [x0, #80]
    3864:	36000720 	tbz	w0, #0, 3948 <fwp_task_dispose+0xf8>
    3868:	f9400a60 	ldr	x0, [x19, #16]
    386c:	b50006e0 	cbnz	x0, 3948 <fwp_task_dispose+0xf8>
    3870:	a9478660 	ldp	x0, x1, [x19, #120]
    3874:	39014e7f 	strb	wzr, [x19, #83]
    3878:	f9003e7f 	str	xzr, [x19, #120]
    387c:	f100003f 	cmp	x1, #0x0
    3880:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3884:	54000040 	b.eq	388c <fwp_task_dispose+0x3c>  // b.none
    3888:	d63f0020 	blr	x1
    388c:	f9405660 	ldr	x0, [x19, #168]
    3890:	97fffd64 	bl	2e20 <fwp_mem_free>
    3894:	f900567f 	str	xzr, [x19, #168]
    3898:	b9405e60 	ldr	w0, [x19, #92]
    389c:	7100041f 	cmp	w0, #0x1
    38a0:	54000420 	b.eq	3924 <fwp_task_dispose+0xd4>  // b.none
    38a4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    38a8:	91144042 	add	x2, x2, #0x510
    38ac:	f949d840 	ldr	x0, [x2, #5040]
    38b0:	f949ec41 	ldr	x1, [x2, #5080]
    38b4:	cb000260 	sub	x0, x19, x0
    38b8:	eb01401f 	cmp	x0, x1, lsl #16
    38bc:	540002e2 	b.cs	3918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    38c0:	d350fc01 	lsr	x1, x0, #16
    38c4:	f949fc44 	ldr	x4, [x2, #5112]
    38c8:	8b010821 	add	x1, x1, x1, lsl #2
    38cc:	d37df021 	lsl	x1, x1, #3
    38d0:	8b010083 	add	x3, x4, x1
    38d4:	f9401062 	ldr	x2, [x3, #32]
    38d8:	b4000202 	cbz	x2, 3918 <fwp_task_dispose+0xc8>
    38dc:	38616881 	ldrb	w1, [x4, x1]
    38e0:	7100083f 	cmp	w1, #0x2
    38e4:	54000280 	b.eq	3934 <fwp_task_dispose+0xe4>  // b.none
    38e8:	7100043f 	cmp	w1, #0x1
    38ec:	54000161 	b.ne	3918 <fwp_task_dispose+0xc8>  // b.any
    38f0:	29430464 	ldp	w4, w1, [x3, #24]
    38f4:	92403c00 	and	x0, x0, #0xffff
    38f8:	9b047c00 	mul	x0, x0, x4
    38fc:	d360fc00 	lsr	x0, x0, #32
    3900:	eb01001f 	cmp	x0, x1
    3904:	540000a2 	b.cs	3918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3908:	8b000042 	add	x2, x2, x0
    390c:	39400040 	ldrb	w0, [x2]
    3910:	7100041f 	cmp	w0, #0x1
    3914:	54000080 	b.eq	3924 <fwp_task_dispose+0xd4>  // b.none
    3918:	f9400bf3 	ldr	x19, [sp, #16]
    391c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3920:	d65f03c0 	ret
    3924:	aa1303e0 	mov	x0, x19
    3928:	f9400bf3 	ldr	x19, [sp, #16]
    392c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3930:	17fffd3c 	b	2e20 <fwp_mem_free>
    3934:	72003c1f 	tst	w0, #0xffff
    3938:	54fffea0 	b.eq	390c <fwp_task_dispose+0xbc>  // b.none
    393c:	f9400bf3 	ldr	x19, [sp, #16]
    3940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3944:	d65f03c0 	ret
    3948:	97fff6ea 	bl	14f0 <abort@plt>
    394c:	d503201f 	nop

0000000000003950 <fwp_free_zombie>:
    3950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3954:	910003fd 	mov	x29, sp
    3958:	a90153f3 	stp	x19, x20, [sp, #16]
    395c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3960:	9101c281 	add	x1, x20, #0x70
    3964:	f9401c33 	ldr	x19, [x1, #56]
    3968:	b4000333 	cbz	x19, 39cc <fwp_free_zombie+0x7c>
    396c:	f9400420 	ldr	x0, [x1, #8]
    3970:	eb00027f 	cmp	x19, x0
    3974:	540002c0 	b.eq	39cc <fwp_free_zombie+0x7c>  // b.none
    3978:	b9404022 	ldr	w2, [x1, #64]
    397c:	f9400a60 	ldr	x0, [x19, #16]
    3980:	7100fc5f 	cmp	w2, #0x3f
    3984:	5400078c 	b.gt	3a74 <fwp_free_zombie+0x124>
    3988:	91014023 	add	x3, x1, #0x50
    398c:	11000444 	add	w4, w2, #0x1
    3990:	b9004024 	str	w4, [x1, #64]
    3994:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3998:	f822d860 	str	x0, [x3, w2, sxtw #3]
    399c:	a9530261 	ldp	x1, x0, [x19, #304]
    39a0:	b4000741 	cbz	x1, 3a88 <fwp_free_zombie+0x138>
    39a4:	f9009c20 	str	x0, [x1, #312]
    39a8:	b4000040 	cbz	x0, 39b0 <fwp_free_zombie+0x60>
    39ac:	f9009801 	str	x1, [x0, #304]
    39b0:	9101c294 	add	x20, x20, #0x70
    39b4:	b9405e60 	ldr	w0, [x19, #92]
    39b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    39bc:	f9001e9f 	str	xzr, [x20, #56]
    39c0:	34000140 	cbz	w0, 39e8 <fwp_free_zombie+0x98>
    39c4:	7100041f 	cmp	w0, #0x1
    39c8:	54000080 	b.eq	39d8 <fwp_free_zombie+0x88>  // b.none
    39cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    39d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39d4:	d65f03c0 	ret
    39d8:	aa1303e0 	mov	x0, x19
    39dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    39e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39e4:	17ffff9b 	b	3850 <fwp_task_dispose>
    39e8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcd0>
    39ec:	91144082 	add	x2, x4, #0x510
    39f0:	f949d841 	ldr	x1, [x2, #5040]
    39f4:	f949ec40 	ldr	x0, [x2, #5080]
    39f8:	cb010261 	sub	x1, x19, x1
    39fc:	eb00403f 	cmp	x1, x0, lsl #16
    3a00:	54fffe62 	b.cs	39cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a04:	d350fc20 	lsr	x0, x1, #16
    3a08:	f949fc43 	ldr	x3, [x2, #5112]
    3a0c:	8b000800 	add	x0, x0, x0, lsl #2
    3a10:	d37df000 	lsl	x0, x0, #3
    3a14:	8b000062 	add	x2, x3, x0
    3a18:	f9401054 	ldr	x20, [x2, #32]
    3a1c:	b4fffd94 	cbz	x20, 39cc <fwp_free_zombie+0x7c>
    3a20:	38606860 	ldrb	w0, [x3, x0]
    3a24:	7100081f 	cmp	w0, #0x2
    3a28:	54000360 	b.eq	3a94 <fwp_free_zombie+0x144>  // b.none
    3a2c:	7100041f 	cmp	w0, #0x1
    3a30:	54fffce1 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3a34:	29430043 	ldp	w3, w0, [x2, #24]
    3a38:	92403c21 	and	x1, x1, #0xffff
    3a3c:	9b037c21 	mul	x1, x1, x3
    3a40:	d360fc21 	lsr	x1, x1, #32
    3a44:	eb00003f 	cmp	x1, x0
    3a48:	54fffc22 	b.cs	39cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a4c:	8b010294 	add	x20, x20, x1
    3a50:	39400280 	ldrb	w0, [x20]
    3a54:	34fffbc0 	cbz	w0, 39cc <fwp_free_zombie+0x7c>
    3a58:	7100041f 	cmp	w0, #0x1
    3a5c:	54fffbe0 	b.eq	39d8 <fwp_free_zombie+0x88>  // b.none
    3a60:	7103fc1f 	cmp	w0, #0xff
    3a64:	540001e0 	b.eq	3aa0 <fwp_free_zombie+0x150>  // b.none
    3a68:	51000400 	sub	w0, w0, #0x1
    3a6c:	39000280 	strb	w0, [x20]
    3a70:	17ffffd7 	b	39cc <fwp_free_zombie+0x7c>
    3a74:	f9400e61 	ldr	x1, [x19, #24]
    3a78:	97fff6d2 	bl	15c0 <munmap@plt>
    3a7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a80:	a9530261 	ldp	x1, x0, [x19, #304]
    3a84:	b5fff901 	cbnz	x1, 39a4 <fwp_free_zombie+0x54>
    3a88:	9101c282 	add	x2, x20, #0x70
    3a8c:	f9012840 	str	x0, [x2, #592]
    3a90:	17ffffc6 	b	39a8 <fwp_free_zombie+0x58>
    3a94:	72003c3f 	tst	w1, #0xffff
    3a98:	54fff9a1 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3a9c:	17ffffed 	b	3a50 <fwp_free_zombie+0x100>
    3aa0:	ca544680 	eor	x0, x20, x20, lsr #17
    3aa4:	91144084 	add	x4, x4, #0x510
    3aa8:	ca402400 	eor	x0, x0, x0, lsr #9
    3aac:	8b200c80 	add	x0, x4, w0, uxtb #3
    3ab0:	f94a2400 	ldr	x0, [x0, #5192]
    3ab4:	b5000080 	cbnz	x0, 3ac4 <fwp_free_zombie+0x174>
    3ab8:	14000010 	b	3af8 <fwp_free_zombie+0x1a8>
    3abc:	f9400800 	ldr	x0, [x0, #16]
    3ac0:	b40001c0 	cbz	x0, 3af8 <fwp_free_zombie+0x1a8>
    3ac4:	f9400001 	ldr	x1, [x0]
    3ac8:	eb14003f 	cmp	x1, x20
    3acc:	54ffff81 	b.ne	3abc <fwp_free_zombie+0x16c>  // b.any
    3ad0:	f9400401 	ldr	x1, [x0, #8]
    3ad4:	d1000421 	sub	x1, x1, #0x1
    3ad8:	f9000401 	str	x1, [x0, #8]
    3adc:	f103f83f 	cmp	x1, #0xfe
    3ae0:	54fff761 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3ae4:	aa1403e0 	mov	x0, x20
    3ae8:	97fffc2f 	bl	2ba4 <fwp_rc_forget_slot>
    3aec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3af0:	39000280 	strb	w0, [x20]
    3af4:	17ffffb6 	b	39cc <fwp_free_zombie+0x7c>
    3af8:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    3afc:	913b2000 	add	x0, x0, #0xec8
    3b00:	97fff968 	bl	20a0 <fwp_trap>

0000000000003b04 <fwp_block>:
    3b04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3b08:	910003fd 	mov	x29, sp
    3b0c:	a90153f3 	stp	x19, x20, [sp, #16]
    3b10:	b00000f3 	adrp	x19, 20000 <__data_start>
    3b14:	9101c274 	add	x20, x19, #0x70
    3b18:	f9401682 	ldr	x2, [x20, #40]
    3b1c:	b4000622 	cbz	x2, 3be0 <fwp_block+0xdc>
    3b20:	9101c261 	add	x1, x19, #0x70
    3b24:	f9408040 	ldr	x0, [x2, #256]
    3b28:	f9001420 	str	x0, [x1, #40]
    3b2c:	b4000680 	cbz	x0, 3bfc <fwp_block+0xf8>
    3b30:	9101c263 	add	x3, x19, #0x70
    3b34:	3901505f 	strb	wzr, [x2, #84]
    3b38:	f9400464 	ldr	x4, [x3, #8]
    3b3c:	eb02009f 	cmp	x4, x2
    3b40:	54000440 	b.eq	3bc8 <fwp_block+0xc4>  // b.none
    3b44:	f9412c65 	ldr	x5, [x3, #600]
    3b48:	f9000462 	str	x2, [x3, #8]
    3b4c:	f9400441 	ldr	x1, [x2, #8]
    3b50:	f9004885 	str	x5, [x4, #144]
    3b54:	f9413065 	ldr	x5, [x3, #608]
    3b58:	f9004c85 	str	x5, [x4, #152]
    3b5c:	f9413465 	ldr	x5, [x3, #616]
    3b60:	f9005085 	str	x5, [x4, #160]
    3b64:	f9413865 	ldr	x5, [x3, #624]
    3b68:	f9005485 	str	x5, [x4, #168]
    3b6c:	f9413c65 	ldr	x5, [x3, #632]
    3b70:	f9005885 	str	x5, [x4, #176]
    3b74:	f9414065 	ldr	x5, [x3, #640]
    3b78:	f9005c85 	str	x5, [x4, #184]
    3b7c:	f9414465 	ldr	x5, [x3, #648]
    3b80:	f9006085 	str	x5, [x4, #192]
    3b84:	f9400480 	ldr	x0, [x4, #8]
    3b88:	f9404844 	ldr	x4, [x2, #144]
    3b8c:	f9012c64 	str	x4, [x3, #600]
    3b90:	f9404c44 	ldr	x4, [x2, #152]
    3b94:	f9013064 	str	x4, [x3, #608]
    3b98:	f9405044 	ldr	x4, [x2, #160]
    3b9c:	f9013464 	str	x4, [x3, #616]
    3ba0:	f9405444 	ldr	x4, [x2, #168]
    3ba4:	f9013864 	str	x4, [x3, #624]
    3ba8:	f9405844 	ldr	x4, [x2, #176]
    3bac:	f9013c64 	str	x4, [x3, #632]
    3bb0:	a94b8844 	ldp	x4, x2, [x2, #184]
    3bb4:	f9014064 	str	x4, [x3, #640]
    3bb8:	f9014462 	str	x2, [x3, #648]
    3bbc:	97fff651 	bl	1500 <swapcontext@plt>
    3bc0:	97ffff64 	bl	3950 <fwp_free_zombie>
    3bc4:	d503201f 	nop
    3bc8:	9101c260 	add	x0, x19, #0x70
    3bcc:	b9429000 	ldr	w0, [x0, #656]
    3bd0:	340001a0 	cbz	w0, 3c04 <fwp_block+0x100>
    3bd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3bd8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bdc:	d65f03c0 	ret
    3be0:	97fffb64 	bl	2970 <fwp_poll_events>
    3be4:	f9401682 	ldr	x2, [x20, #40]
    3be8:	b4ffffc2 	cbz	x2, 3be0 <fwp_block+0xdc>
    3bec:	9101c261 	add	x1, x19, #0x70
    3bf0:	f9408040 	ldr	x0, [x2, #256]
    3bf4:	f9001420 	str	x0, [x1, #40]
    3bf8:	b5fff9c0 	cbnz	x0, 3b30 <fwp_block+0x2c>
    3bfc:	f900103f 	str	xzr, [x1, #32]
    3c00:	17ffffcc 	b	3b30 <fwp_block+0x2c>
    3c04:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    3c08:	913c0000 	add	x0, x0, #0xf00
    3c0c:	97fff689 	bl	1630 <getenv@plt>
    3c10:	5284e202 	mov	w2, #0x2710                	// #10000
    3c14:	b4000060 	cbz	x0, 3c20 <fwp_block+0x11c>
    3c18:	39400001 	ldrb	w1, [x0]
    3c1c:	350000c1 	cbnz	w1, 3c34 <fwp_block+0x130>
    3c20:	9101c273 	add	x19, x19, #0x70
    3c24:	b9029262 	str	w2, [x19, #656]
    3c28:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c30:	d65f03c0 	ret
    3c34:	52800142 	mov	w2, #0xa                   	// #10
    3c38:	d2800001 	mov	x1, #0x0                   	// #0
    3c3c:	97fff5cd 	bl	1370 <strtoll@plt>
    3c40:	d1000403 	sub	x3, x0, #0x1
    3c44:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3c48:	eb02007f 	cmp	x3, x2
    3c4c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3c50:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3c54:	17fffff3 	b	3c20 <fwp_block+0x11c>
    3c58:	d503201f 	nop
    3c5c:	d503201f 	nop

0000000000003c60 <fwp_write.constprop.0>:
    3c60:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3c64:	910003fd 	mov	x29, sp
    3c68:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x160a0>
    3c6c:	f947f463 	ldr	x3, [x3, #4072]
    3c70:	a90153f3 	stp	x19, x20, [sp, #16]
    3c74:	d10943ff 	sub	sp, sp, #0x250
    3c78:	aa0003f4 	mov	x20, x0
    3c7c:	b9400040 	ldr	w0, [x2]
    3c80:	aa0103f3 	mov	x19, x1
    3c84:	f9400061 	ldr	x1, [x3]
    3c88:	f90127e1 	str	x1, [sp, #584]
    3c8c:	d2800001 	mov	x1, #0x0                   	// #0
    3c90:	7100641f 	cmp	w0, #0x19
    3c94:	540003e8 	b.hi	3d10 <fwp_write.constprop.0+0xb0>  // b.pmore
    3c98:	b0000021 	adrp	x1, 8000 <_IO_stdin_used+0x300>
    3c9c:	9106c021 	add	x1, x1, #0x1b0
    3ca0:	f9013bf5 	str	x21, [sp, #624]
    3ca4:	f9013ff6 	str	x22, [sp, #632]
    3ca8:	f90153fb 	str	x27, [sp, #672]
    3cac:	f90157fc 	str	x28, [sp, #680]
    3cb0:	aa0203fc 	mov	x28, x2
    3cb4:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3cb8:	10000062 	adr	x2, 3cc4 <fwp_write.constprop.0+0x64>
    3cbc:	8b21a841 	add	x1, x2, w1, sxth #2
    3cc0:	d61f0020 	br	x1
    3cc4:	910123e0 	add	x0, sp, #0x48
    3cc8:	aa1303e5 	mov	x5, x19
    3ccc:	90000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    3cd0:	aa0003f3 	mov	x19, x0
    3cd4:	913d2084 	add	x4, x4, #0xf48
    3cd8:	d2804003 	mov	x3, #0x200                 	// #512
    3cdc:	aa0303e1 	mov	x1, x3
    3ce0:	52800042 	mov	w2, #0x2                   	// #2
    3ce4:	97fff5cb 	bl	1410 <__snprintf_chk@plt>
    3ce8:	aa1303e0 	mov	x0, x19
    3cec:	97fff591 	bl	1330 <strlen@plt>
    3cf0:	aa1303e1 	mov	x1, x19
    3cf4:	aa0003e2 	mov	x2, x0
    3cf8:	aa1403e0 	mov	x0, x20
    3cfc:	97fff88d 	bl	1f30 <buf_put>
    3d00:	f9413bf5 	ldr	x21, [sp, #624]
    3d04:	f9413ff6 	ldr	x22, [sp, #632]
    3d08:	f94153fb 	ldr	x27, [sp, #672]
    3d0c:	f94157fc 	ldr	x28, [sp, #680]
    3d10:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    3d14:	f947f400 	ldr	x0, [x0, #4072]
    3d18:	f94127e2 	ldr	x2, [sp, #584]
    3d1c:	f9400001 	ldr	x1, [x0]
    3d20:	eb010042 	subs	x2, x2, x1
    3d24:	d2800001 	mov	x1, #0x0                   	// #0
    3d28:	540074a1 	b.ne	4bbc <fwp_write.constprop.0+0xf5c>  // b.any
    3d2c:	910943ff 	add	sp, sp, #0x250
    3d30:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d34:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3d38:	d65f03c0 	ret
    3d3c:	910123e0 	add	x0, sp, #0x48
    3d40:	aa1303e5 	mov	x5, x19
    3d44:	90000024 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    3d48:	aa0003f3 	mov	x19, x0
    3d4c:	913d0084 	add	x4, x4, #0xf40
    3d50:	d2804003 	mov	x3, #0x200                 	// #512
    3d54:	17ffffe2 	b	3cdc <fwp_write.constprop.0+0x7c>
    3d58:	71004c1f 	cmp	w0, #0x13
    3d5c:	90000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    3d60:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    3d64:	913ce021 	add	x1, x1, #0xf38
    3d68:	913cc000 	add	x0, x0, #0xf30
    3d6c:	d2800082 	mov	x2, #0x4                   	// #4
    3d70:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    3d74:	aa1403e0 	mov	x0, x20
    3d78:	f90143f7 	str	x23, [sp, #640]
    3d7c:	d2800016 	mov	x22, #0x0                   	// #0
    3d80:	f90147f8 	str	x24, [sp, #648]
    3d84:	97fff86b 	bl	1f30 <buf_put>
    3d88:	f9400260 	ldr	x0, [x19]
    3d8c:	90000037 	adrp	x23, 7000 <fwp_main_thread+0x23fc>
    3d90:	d2800015 	mov	x21, #0x0                   	// #0
    3d94:	913ee2f7 	add	x23, x23, #0xfb8
    3d98:	b4004e40 	cbz	x0, 4760 <fwp_write.constprop.0+0xb00>
    3d9c:	b9400381 	ldr	w1, [x28]
    3da0:	aa1403e0 	mov	x0, x20
    3da4:	f9401f82 	ldr	x2, [x28, #56]
    3da8:	71004c3f 	cmp	w1, #0x13
    3dac:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    3db0:	8b010e61 	add	x1, x19, x1, lsl #3
    3db4:	f9400421 	ldr	x1, [x1, #8]
    3db8:	97ffffaa 	bl	3c60 <fwp_write.constprop.0>
    3dbc:	b9400380 	ldr	w0, [x28]
    3dc0:	7100481f 	cmp	w0, #0x12
    3dc4:	540050c0 	b.eq	47dc <fwp_write.constprop.0+0xb7c>  // b.none
    3dc8:	f9400260 	ldr	x0, [x19]
    3dcc:	910006b5 	add	x21, x21, #0x1
    3dd0:	91000ad6 	add	x22, x22, #0x2
    3dd4:	eb0002bf 	cmp	x21, x0
    3dd8:	54004c42 	b.cs	4760 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    3ddc:	aa1703e1 	mov	x1, x23
    3de0:	aa1403e0 	mov	x0, x20
    3de4:	d2800042 	mov	x2, #0x2                   	// #2
    3de8:	97fff852 	bl	1f30 <buf_put>
    3dec:	17ffffec 	b	3d9c <fwp_write.constprop.0+0x13c>
    3df0:	90000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    3df4:	913dc021 	add	x1, x1, #0xf70
    3df8:	d28000c2 	mov	x2, #0x6                   	// #6
    3dfc:	aa1403e0 	mov	x0, x20
    3e00:	91004273 	add	x19, x19, #0x10
    3e04:	97fff84b 	bl	1f30 <buf_put>
    3e08:	aa1303e0 	mov	x0, x19
    3e0c:	97fff549 	bl	1330 <strlen@plt>
    3e10:	aa1303e1 	mov	x1, x19
    3e14:	aa0003e2 	mov	x2, x0
    3e18:	aa1403e0 	mov	x0, x20
    3e1c:	97fff845 	bl	1f30 <buf_put>
    3e20:	528007c3 	mov	w3, #0x3e                  	// #62
    3e24:	aa1403e0 	mov	x0, x20
    3e28:	91001fe1 	add	x1, sp, #0x7
    3e2c:	d2800022 	mov	x2, #0x1                   	// #1
    3e30:	39001fe3 	strb	w3, [sp, #7]
    3e34:	17ffffb2 	b	3cfc <fwp_write.constprop.0+0x9c>
    3e38:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    3e3c:	f947f400 	ldr	x0, [x0, #4072]
    3e40:	f94127e2 	ldr	x2, [sp, #584]
    3e44:	f9400001 	ldr	x1, [x0]
    3e48:	eb010042 	subs	x2, x2, x1
    3e4c:	d2800001 	mov	x1, #0x0                   	// #0
    3e50:	54006cc1 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    3e54:	f9413bf5 	ldr	x21, [sp, #624]
    3e58:	90000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    3e5c:	f9413ff6 	ldr	x22, [sp, #632]
    3e60:	aa1403e0 	mov	x0, x20
    3e64:	913d4021 	add	x1, x1, #0xf50
    3e68:	d2800142 	mov	x2, #0xa                   	// #10
    3e6c:	f94153fb 	ldr	x27, [sp, #672]
    3e70:	f94157fc 	ldr	x28, [sp, #680]
    3e74:	910943ff 	add	sp, sp, #0x250
    3e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e7c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3e80:	17fff82c 	b	1f30 <buf_put>
    3e84:	f9400796 	ldr	x22, [x28, #8]
    3e88:	f90143f7 	str	x23, [sp, #640]
    3e8c:	f90147f8 	str	x24, [sp, #648]
    3e90:	b4005816 	cbz	x22, 4990 <fwp_write.constprop.0+0xd30>
    3e94:	aa1603e0 	mov	x0, x22
    3e98:	90000021 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    3e9c:	913f4021 	add	x1, x1, #0xfd0
    3ea0:	97fff5a0 	bl	1520 <strcmp@plt>
    3ea4:	2a0003f5 	mov	w21, w0
    3ea8:	34005ce0 	cbz	w0, 4a44 <fwp_write.constprop.0+0xde4>
    3eac:	aa1603e0 	mov	x0, x22
    3eb0:	97fff520 	bl	1330 <strlen@plt>
    3eb4:	aa1603e1 	mov	x1, x22
    3eb8:	aa0003e2 	mov	x2, x0
    3ebc:	aa1403e0 	mov	x0, x20
    3ec0:	97fff81c 	bl	1f30 <buf_put>
    3ec4:	52800403 	mov	w3, #0x20                  	// #32
    3ec8:	91001ff5 	add	x21, sp, #0x7
    3ecc:	aa1503e1 	mov	x1, x21
    3ed0:	aa1403e0 	mov	x0, x20
    3ed4:	d2800022 	mov	x2, #0x1                   	// #1
    3ed8:	39001fe3 	strb	w3, [sp, #7]
    3edc:	97fff815 	bl	1f30 <buf_put>
    3ee0:	52800f63 	mov	w3, #0x7b                  	// #123
    3ee4:	aa1403e0 	mov	x0, x20
    3ee8:	aa1503e1 	mov	x1, x21
    3eec:	d2800022 	mov	x2, #0x1                   	// #1
    3ef0:	39001fe3 	strb	w3, [sp, #7]
    3ef4:	97fff80f 	bl	1f30 <buf_put>
    3ef8:	b9401380 	ldr	w0, [x28, #16]
    3efc:	52800018 	mov	w24, #0x0                   	// #0
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	54003d8d 	b.le	46b4 <fwp_write.constprop.0+0xa54>
    3f08:	f9014bf9 	str	x25, [sp, #656]
    3f0c:	90000039 	adrp	x25, 7000 <fwp_main_thread+0x23fc>
    3f10:	913fe339 	add	x25, x25, #0xff8
    3f14:	f9014ffa 	str	x26, [sp, #664]
    3f18:	9000003a 	adrp	x26, 7000 <fwp_main_thread+0x23fc>
    3f1c:	913ee35a 	add	x26, x26, #0xfb8
    3f20:	91002276 	add	x22, x19, #0x8
    3f24:	d2800013 	mov	x19, #0x0                   	// #0
    3f28:	b5004413 	cbnz	x19, 47a8 <fwp_write.constprop.0+0xb48>
    3f2c:	d37df277 	lsl	x23, x19, #3
    3f30:	34004238 	cbz	w24, 4774 <fwp_write.constprop.0+0xb14>
    3f34:	f9401382 	ldr	x2, [x28, #32]
    3f38:	aa1403e0 	mov	x0, x20
    3f3c:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    3f40:	91000673 	add	x19, x19, #0x1
    3f44:	f8776842 	ldr	x2, [x2, x23]
    3f48:	97ffff46 	bl	3c60 <fwp_write.constprop.0>
    3f4c:	b9401380 	ldr	w0, [x28, #16]
    3f50:	6b13001f 	cmp	w0, w19
    3f54:	54fffeac 	b.gt	3f28 <fwp_write.constprop.0+0x2c8>
    3f58:	f9414bf9 	ldr	x25, [sp, #656]
    3f5c:	f9414ffa 	ldr	x26, [sp, #664]
    3f60:	34003ab8 	cbz	w24, 46b4 <fwp_write.constprop.0+0xa54>
    3f64:	52800523 	mov	w3, #0x29                  	// #41
    3f68:	aa1503e1 	mov	x1, x21
    3f6c:	aa1403e0 	mov	x0, x20
    3f70:	d2800022 	mov	x2, #0x1                   	// #1
    3f74:	39001fe3 	strb	w3, [sp, #7]
    3f78:	97fff7ee 	bl	1f30 <buf_put>
    3f7c:	f9413bf5 	ldr	x21, [sp, #624]
    3f80:	f9413ff6 	ldr	x22, [sp, #632]
    3f84:	f94143f7 	ldr	x23, [sp, #640]
    3f88:	f94147f8 	ldr	x24, [sp, #648]
    3f8c:	f94153fb 	ldr	x27, [sp, #672]
    3f90:	f94157fc 	ldr	x28, [sp, #680]
    3f94:	17ffff5f 	b	3d10 <fwp_write.constprop.0+0xb0>
    3f98:	b9404b95 	ldr	w21, [x28, #72]
    3f9c:	aa1403e0 	mov	x0, x20
    3fa0:	93407eb6 	sxtw	x22, w21
    3fa4:	91000ac1 	add	x1, x22, #0x2
    3fa8:	97fff7ae 	bl	1e60 <buf_grow>
    3fac:	a9400281 	ldp	x1, x0, [x20]
    3fb0:	528e8603 	mov	w3, #0x7430                	// #29744
    3fb4:	78206823 	strh	w3, [x1, x0]
    3fb8:	8b000022 	add	x2, x1, x0
    3fbc:	710002bf 	cmp	w21, #0x0
    3fc0:	54003bcd 	b.le	4738 <fwp_write.constprop.0+0xad8>
    3fc4:	110006a3 	add	w3, w21, #0x1
    3fc8:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    3fcc:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    3fd0:	91000449 	add	x9, x2, #0x1
    3fd4:	8b23c043 	add	x3, x2, w3, sxtw
    3fd8:	f28aaac6 	movk	x6, #0x5556
    3fdc:	f2955568 	movk	x8, #0xaaab
    3fe0:	1400000d 	b	4014 <fwp_write.constprop.0+0x3b4>
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	528005a5 	mov	w5, #0x2d                  	// #45
    3fec:	f100001f 	cmp	x0, #0x0
    3ff0:	9b467e60 	smulh	x0, x19, x6
    3ff4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    3ff8:	381ff465 	strb	w5, [x3], #-1
    3ffc:	cb040000 	sub	x0, x0, x4
    4000:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4004:	cb020000 	sub	x0, x0, x2
    4008:	8b010013 	add	x19, x0, x1
    400c:	eb03013f 	cmp	x9, x3
    4010:	54003940 	b.eq	4738 <fwp_write.constprop.0+0xad8>  // b.none
    4014:	9b467e60 	smulh	x0, x19, x6
    4018:	937ffe64 	asr	x4, x19, #63
    401c:	52800605 	mov	w5, #0x30                  	// #48
    4020:	cb040000 	sub	x0, x0, x4
    4024:	8b000400 	add	x0, x0, x0, lsl #1
    4028:	cb000260 	sub	x0, x19, x0
    402c:	91000c01 	add	x1, x0, #0x3
    4030:	9bc87c22 	umulh	x2, x1, x8
    4034:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    4038:	8b4204e2 	add	x2, x7, x2, lsr #1
    403c:	eb020021 	subs	x1, x1, x2
    4040:	54fffd60 	b.eq	3fec <fwp_write.constprop.0+0x38c>  // b.none
    4044:	f100043f 	cmp	x1, #0x1
    4048:	54fffce1 	b.ne	3fe4 <fwp_write.constprop.0+0x384>  // b.any
    404c:	d2800001 	mov	x1, #0x0                   	// #0
    4050:	52800565 	mov	w5, #0x2b                  	// #43
    4054:	17ffffe6 	b	3fec <fwp_write.constprop.0+0x38c>
    4058:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    405c:	f947f400 	ldr	x0, [x0, #4072]
    4060:	f94127e2 	ldr	x2, [sp, #584]
    4064:	f9400001 	ldr	x1, [x0]
    4068:	eb010042 	subs	x2, x2, x1
    406c:	d2800001 	mov	x1, #0x0                   	// #0
    4070:	54005bc1 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    4074:	f9413bf5 	ldr	x21, [sp, #624]
    4078:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    407c:	f9413ff6 	ldr	x22, [sp, #632]
    4080:	aa1403e0 	mov	x0, x20
    4084:	913d8021 	add	x1, x1, #0xf60
    4088:	d2800102 	mov	x2, #0x8                   	// #8
    408c:	17ffff78 	b	3e6c <fwp_write.constprop.0+0x20c>
    4090:	aa1403e0 	mov	x0, x20
    4094:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    4098:	d28000c2 	mov	x2, #0x6                   	// #6
    409c:	913f0021 	add	x1, x1, #0xfc0
    40a0:	97fff7a4 	bl	1f30 <buf_put>
    40a4:	d2800015 	mov	x21, #0x0                   	// #0
    40a8:	f9400263 	ldr	x3, [x19]
    40ac:	f240f87f 	tst	x3, #0x7fffffffffffffff
    40b0:	540026a0 	b.eq	4584 <fwp_write.constprop.0+0x924>  // b.none
    40b4:	f9401f82 	ldr	x2, [x28, #56]
    40b8:	f90143f7 	str	x23, [sp, #640]
    40bc:	f90147f8 	str	x24, [sp, #648]
    40c0:	d2800857 	mov	x23, #0x42                  	// #66
    40c4:	f9014bf9 	str	x25, [sp, #656]
    40c8:	f0000016 	adrp	x22, 7000 <fwp_main_thread+0x23fc>
    40cc:	f9014ffa 	str	x26, [sp, #664]
    40d0:	913ee2d6 	add	x22, x22, #0xfb8
    40d4:	d2800038 	mov	x24, #0x1                   	// #1
    40d8:	f2a18017 	movk	x23, #0xc00, lsl #16
    40dc:	d2809099 	mov	x25, #0x484                 	// #1156
    40e0:	b4000482 	cbz	x2, 4170 <fwp_write.constprop.0+0x510>
    40e4:	b9400040 	ldr	w0, [x2]
    40e8:	7100701f 	cmp	w0, #0x1c
    40ec:	540042e0 	b.eq	4948 <fwp_write.constprop.0+0xce8>  // b.none
    40f0:	71006c1f 	cmp	w0, #0x1b
    40f4:	540003e8 	b.hi	4170 <fwp_write.constprop.0+0x510>  // b.pmore
    40f8:	9ac02301 	lsl	x1, x24, x0
    40fc:	ea17003f 	tst	x1, x23
    4100:	54003f21 	b.ne	48e4 <fwp_write.constprop.0+0xc84>  // b.any
    4104:	ea19003f 	tst	x1, x25
    4108:	54003da1 	b.ne	48bc <fwp_write.constprop.0+0xc5c>  // b.any
    410c:	d2800425 	mov	x5, #0x21                  	// #33
    4110:	ea05003f 	tst	x1, x5
    4114:	540002e0 	b.eq	4170 <fwp_write.constprop.0+0x510>  // b.none
    4118:	b7f84743 	tbnz	x3, #63, 4a00 <fwp_write.constprop.0+0xda0>
    411c:	91002261 	add	x1, x19, #0x8
    4120:	8b150021 	add	x1, x1, x21
    4124:	39400021 	ldrb	w1, [x1]
    4128:	7100001f 	cmp	w0, #0x0
    412c:	93401c23 	sxtb	x3, w1
    4130:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4134:	d503201f 	nop
    4138:	aa1403e0 	mov	x0, x20
    413c:	97fffec9 	bl	3c60 <fwp_write.constprop.0>
    4140:	f9400260 	ldr	x0, [x19]
    4144:	910006b5 	add	x21, x21, #0x1
    4148:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    414c:	eb0002bf 	cmp	x21, x0
    4150:	54002122 	b.cs	4574 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4154:	d2800042 	mov	x2, #0x2                   	// #2
    4158:	aa1603e1 	mov	x1, x22
    415c:	aa1403e0 	mov	x0, x20
    4160:	97fff774 	bl	1f30 <buf_put>
    4164:	f9401f82 	ldr	x2, [x28, #56]
    4168:	f9400263 	ldr	x3, [x19]
    416c:	b5fffbc2 	cbnz	x2, 40e4 <fwp_write.constprop.0+0x484>
    4170:	d37df2a0 	lsl	x0, x21, #3
    4174:	b7f83f43 	tbnz	x3, #63, 495c <fwp_write.constprop.0+0xcfc>
    4178:	91002261 	add	x1, x19, #0x8
    417c:	8b000020 	add	x0, x1, x0
    4180:	f9400001 	ldr	x1, [x0]
    4184:	17ffffed 	b	4138 <fwp_write.constprop.0+0x4d8>
    4188:	a9400e62 	ldp	x2, x3, [x19]
    418c:	b7f83ce3 	tbnz	x3, #63, 4928 <fwp_write.constprop.0+0xcc8>
    4190:	910123f5 	add	x21, sp, #0x48
    4194:	aa1503e0 	mov	x0, x21
    4198:	97fff612 	bl	19e0 <fwp_fmt_u128>
    419c:	aa1503e0 	mov	x0, x21
    41a0:	97fff464 	bl	1330 <strlen@plt>
    41a4:	aa1503e1 	mov	x1, x21
    41a8:	aa0003e2 	mov	x2, x0
    41ac:	17fffed3 	b	3cf8 <fwp_write.constprop.0+0x98>
    41b0:	fd015be8 	str	d8, [sp, #688]
    41b4:	1e270268 	fmov	s8, w19
    41b8:	fd015fe9 	str	d9, [sp, #696]
    41bc:	1e282100 	fcmp	s8, s8
    41c0:	54004a66 	b.vs	4b0c <fwp_write.constprop.0+0xeac>
    41c4:	1e20c101 	fabs	s1, s8
    41c8:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    41cc:	1e270000 	fmov	s0, w0
    41d0:	1e202020 	fcmp	s1, s0
    41d4:	540034ad 	b.le	4868 <fwp_write.constprop.0+0xc08>
    41d8:	1e202118 	fcmpe	s8, #0.0
    41dc:	f0000002 	adrp	x2, 7000 <fwp_main_thread+0x23fc>
    41e0:	91348042 	add	x2, x2, #0xd20
    41e4:	910123f5 	add	x21, sp, #0x48
    41e8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    41ec:	913c4021 	add	x1, x1, #0xf10
    41f0:	aa1503e0 	mov	x0, x21
    41f4:	9a81c041 	csel	x1, x2, x1, gt
    41f8:	97fff4fa 	bl	15e0 <strcpy@plt>
    41fc:	d503201f 	nop
    4200:	aa1503e0 	mov	x0, x21
    4204:	97fff44b 	bl	1330 <strlen@plt>
    4208:	aa1503e1 	mov	x1, x21
    420c:	aa0003e2 	mov	x2, x0
    4210:	aa1403e0 	mov	x0, x20
    4214:	97fff747 	bl	1f30 <buf_put>
    4218:	f9413bf5 	ldr	x21, [sp, #624]
    421c:	f9413ff6 	ldr	x22, [sp, #632]
    4220:	f94153fb 	ldr	x27, [sp, #672]
    4224:	f94157fc 	ldr	x28, [sp, #680]
    4228:	fd415be8 	ldr	d8, [sp, #688]
    422c:	fd415fe9 	ldr	d9, [sp, #696]
    4230:	17fffeb8 	b	3d10 <fwp_write.constprop.0+0xb0>
    4234:	f90143f7 	str	x23, [sp, #640]
    4238:	52800443 	mov	w3, #0x22                  	// #34
    423c:	f90147f8 	str	x24, [sp, #648]
    4240:	91001ff5 	add	x21, sp, #0x7
    4244:	aa1503e1 	mov	x1, x21
    4248:	aa1403e0 	mov	x0, x20
    424c:	f8408677 	ldr	x23, [x19], #8
    4250:	d2800022 	mov	x2, #0x1                   	// #1
    4254:	39001fe3 	strb	w3, [sp, #7]
    4258:	97fff736 	bl	1f30 <buf_put>
    425c:	8b1302f6 	add	x22, x23, x19
    4260:	b4002657 	cbz	x23, 4728 <fwp_write.constprop.0+0xac8>
    4264:	f0000018 	adrp	x24, 7000 <fwp_main_thread+0x23fc>
    4268:	913de318 	add	x24, x24, #0xf78
    426c:	f9014bf9 	str	x25, [sp, #656]
    4270:	f0000019 	adrp	x25, 7000 <fwp_main_thread+0x23fc>
    4274:	913e6339 	add	x25, x25, #0xf98
    4278:	f9014ffa 	str	x26, [sp, #664]
    427c:	1400000e 	b	42b4 <fwp_write.constprop.0+0x654>
    4280:	710024bf 	cmp	w5, #0x9
    4284:	54002380 	b.eq	46f4 <fwp_write.constprop.0+0xa94>  // b.none
    4288:	710028bf 	cmp	w5, #0xa
    428c:	54002be1 	b.ne	4808 <fwp_write.constprop.0+0xba8>  // b.any
    4290:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    4294:	aa1403e0 	mov	x0, x20
    4298:	913e2021 	add	x1, x1, #0xf88
    429c:	d2800042 	mov	x2, #0x2                   	// #2
    42a0:	97fff724 	bl	1f30 <buf_put>
    42a4:	d503201f 	nop
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb16027f 	cmp	x19, x22
    42b0:	54002380 	b.eq	4720 <fwp_write.constprop.0+0xac0>  // b.none
    42b4:	39400265 	ldrb	w5, [x19]
    42b8:	710034bf 	cmp	w5, #0xd
    42bc:	54002120 	b.eq	46e0 <fwp_write.constprop.0+0xa80>  // b.none
    42c0:	54fffe09 	b.ls	4280 <fwp_write.constprop.0+0x620>  // b.plast
    42c4:	710088bf 	cmp	w5, #0x22
    42c8:	54002220 	b.eq	470c <fwp_write.constprop.0+0xaac>  // b.none
    42cc:	710170bf 	cmp	w5, #0x5c
    42d0:	54002ba1 	b.ne	4844 <fwp_write.constprop.0+0xbe4>  // b.any
    42d4:	aa1403e0 	mov	x0, x20
    42d8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    42dc:	d2800042 	mov	x2, #0x2                   	// #2
    42e0:	913e0021 	add	x1, x1, #0xf80
    42e4:	97fff713 	bl	1f30 <buf_put>
    42e8:	17fffff0 	b	42a8 <fwp_write.constprop.0+0x648>
    42ec:	fd015be8 	str	d8, [sp, #688]
    42f0:	9e670268 	fmov	d8, x19
    42f4:	fd015fe9 	str	d9, [sp, #696]
    42f8:	1e682100 	fcmp	d8, d8
    42fc:	54004086 	b.vs	4b0c <fwp_write.constprop.0+0xeac>
    4300:	1e60c101 	fabs	d1, d8
    4304:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    4308:	9e670000 	fmov	d0, x0
    430c:	910123f5 	add	x21, sp, #0x48
    4310:	52800033 	mov	w19, #0x1                   	// #1
    4314:	1e602020 	fcmp	d1, d0
    4318:	540001ad 	b.le	434c <fwp_write.constprop.0+0x6ec>
    431c:	1e602118 	fcmpe	d8, #0.0
    4320:	f0000002 	adrp	x2, 7000 <fwp_main_thread+0x23fc>
    4324:	91348042 	add	x2, x2, #0xd20
    4328:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    432c:	913c4021 	add	x1, x1, #0xf10
    4330:	aa1503e0 	mov	x0, x21
    4334:	9a81c041 	csel	x1, x2, x1, gt
    4338:	97fff4aa 	bl	15e0 <strcpy@plt>
    433c:	17ffffb1 	b	4200 <fwp_write.constprop.0+0x5a0>
    4340:	11000673 	add	w19, w19, #0x1
    4344:	71004a7f 	cmp	w19, #0x12
    4348:	540031a0 	b.eq	497c <fwp_write.constprop.0+0xd1c>  // b.none
    434c:	1e604100 	fmov	d0, d8
    4350:	2a1303e1 	mov	w1, w19
    4354:	aa1503e0 	mov	x0, x21
    4358:	97fff78a 	bl	2180 <fwp_format_g.constprop.0>
    435c:	aa1503e0 	mov	x0, x21
    4360:	d2800001 	mov	x1, #0x0                   	// #0
    4364:	97fff407 	bl	1380 <strtod@plt>
    4368:	1e602100 	fcmp	d8, d0
    436c:	54fffea1 	b.ne	4340 <fwp_write.constprop.0+0x6e0>  // b.any
    4370:	aa1503e0 	mov	x0, x21
    4374:	97fff728 	bl	2014 <fwp_finish_float>
    4378:	17ffffa2 	b	4200 <fwp_write.constprop.0+0x5a0>
    437c:	a9400e62 	ldp	x2, x3, [x19]
    4380:	910123f3 	add	x19, sp, #0x48
    4384:	aa1303e0 	mov	x0, x19
    4388:	97fff596 	bl	19e0 <fwp_fmt_u128>
    438c:	17fffe57 	b	3ce8 <fwp_write.constprop.0+0x88>
    4390:	f90143f7 	str	x23, [sp, #640]
    4394:	f90147f8 	str	x24, [sp, #648]
    4398:	2a1303f8 	mov	w24, w19
    439c:	f9014bf9 	str	x25, [sp, #656]
    43a0:	f9014ffa 	str	x26, [sp, #664]
    43a4:	f13ffe7f 	cmp	x19, #0xfff
    43a8:	54000049 	b.ls	43b0 <fwp_write.constprop.0+0x750>  // b.plast
    43ac:	b9400278 	ldr	w24, [x19]
    43b0:	f9400f80 	ldr	x0, [x28, #24]
    43b4:	2a1803f5 	mov	w21, w24
    43b8:	d37d7f18 	ubfiz	x24, x24, #3, #32
    43bc:	d37ef6b9 	lsl	x25, x21, #2
    43c0:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    43c4:	aa1603e0 	mov	x0, x22
    43c8:	97fff3da 	bl	1330 <strlen@plt>
    43cc:	aa1603e1 	mov	x1, x22
    43d0:	aa0003e2 	mov	x2, x0
    43d4:	aa1403e0 	mov	x0, x20
    43d8:	97fff6d6 	bl	1f30 <buf_put>
    43dc:	f9401780 	ldr	x0, [x28, #40]
    43e0:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    43e4:	7100001f 	cmp	w0, #0x0
    43e8:	5400064d 	b.le	44b0 <fwp_write.constprop.0+0x850>
    43ec:	91002276 	add	x22, x19, #0x8
    43f0:	91001ff5 	add	x21, sp, #0x7
    43f4:	d280001b 	mov	x27, #0x0                   	// #0
    43f8:	5280041a 	mov	w26, #0x20                  	// #32
    43fc:	f9401b80 	ldr	x0, [x28, #48]
    4400:	aa1503e1 	mov	x1, x21
    4404:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    4408:	d2800022 	mov	x2, #0x1                   	// #1
    440c:	f8786805 	ldr	x5, [x0, x24]
    4410:	aa1403e0 	mov	x0, x20
    4414:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    4418:	39001ffa 	strb	w26, [sp, #7]
    441c:	97fff6c5 	bl	1f30 <buf_put>
    4420:	f13ffeff 	cmp	x23, #0xfff
    4424:	b9400261 	ldr	w1, [x19]
    4428:	1a9f97e0 	cset	w0, hi	// hi = pmore
    442c:	7100383f 	cmp	w1, #0xe
    4430:	54000140 	b.eq	4458 <fwp_write.constprop.0+0x7f8>  // b.none
    4434:	7100403f 	cmp	w1, #0x10
    4438:	54001c20 	b.eq	47bc <fwp_write.constprop.0+0xb5c>  // b.none
    443c:	7100283f 	cmp	w1, #0xa
    4440:	540026e0 	b.eq	491c <fwp_write.constprop.0+0xcbc>  // b.none
    4444:	540013cc 	b.gt	46bc <fwp_write.constprop.0+0xa5c>
    4448:	71000c3f 	cmp	w1, #0x3
    444c:	540025ec 	b.gt	4908 <fwp_write.constprop.0+0xca8>
    4450:	d37ffee0 	lsr	x0, x23, #63
    4454:	37f813c1 	tbnz	w1, #31, 46cc <fwp_write.constprop.0+0xa6c>
    4458:	340013a0 	cbz	w0, 46cc <fwp_write.constprop.0+0xa6c>
    445c:	52800503 	mov	w3, #0x28                  	// #40
    4460:	aa1503e1 	mov	x1, x21
    4464:	aa1403e0 	mov	x0, x20
    4468:	d2800022 	mov	x2, #0x1                   	// #1
    446c:	39001fe3 	strb	w3, [sp, #7]
    4470:	97fff6b0 	bl	1f30 <buf_put>
    4474:	aa1303e2 	mov	x2, x19
    4478:	aa1703e1 	mov	x1, x23
    447c:	aa1403e0 	mov	x0, x20
    4480:	97fffdf8 	bl	3c60 <fwp_write.constprop.0>
    4484:	52800523 	mov	w3, #0x29                  	// #41
    4488:	aa1503e1 	mov	x1, x21
    448c:	aa1403e0 	mov	x0, x20
    4490:	d2800022 	mov	x2, #0x1                   	// #1
    4494:	39001fe3 	strb	w3, [sp, #7]
    4498:	97fff6a6 	bl	1f30 <buf_put>
    449c:	f9401780 	ldr	x0, [x28, #40]
    44a0:	9100077b 	add	x27, x27, #0x1
    44a4:	b8796800 	ldr	w0, [x0, x25]
    44a8:	6b1b001f 	cmp	w0, w27
    44ac:	54fffa8c 	b.gt	43fc <fwp_write.constprop.0+0x79c>
    44b0:	f9413bf5 	ldr	x21, [sp, #624]
    44b4:	f9413ff6 	ldr	x22, [sp, #632]
    44b8:	f94143f7 	ldr	x23, [sp, #640]
    44bc:	f94147f8 	ldr	x24, [sp, #648]
    44c0:	f9414bf9 	ldr	x25, [sp, #656]
    44c4:	f9414ffa 	ldr	x26, [sp, #664]
    44c8:	f94153fb 	ldr	x27, [sp, #672]
    44cc:	f94157fc 	ldr	x28, [sp, #680]
    44d0:	17fffe10 	b	3d10 <fwp_write.constprop.0+0xb0>
    44d4:	aa1403e0 	mov	x0, x20
    44d8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    44dc:	d28000c2 	mov	x2, #0x6                   	// #6
    44e0:	913ea021 	add	x1, x1, #0xfa8
    44e4:	97fff693 	bl	1f30 <buf_put>
    44e8:	f9400260 	ldr	x0, [x19]
    44ec:	b40004c0 	cbz	x0, 4584 <fwp_write.constprop.0+0x924>
    44f0:	910123f5 	add	x21, sp, #0x48
    44f4:	91002276 	add	x22, x19, #0x8
    44f8:	f90143f7 	str	x23, [sp, #640]
    44fc:	d2800017 	mov	x23, #0x0                   	// #0
    4500:	f90147f8 	str	x24, [sp, #648]
    4504:	f0000018 	adrp	x24, 7000 <fwp_main_thread+0x23fc>
    4508:	913ec318 	add	x24, x24, #0xfb0
    450c:	f9014bf9 	str	x25, [sp, #656]
    4510:	f0000019 	adrp	x25, 7000 <fwp_main_thread+0x23fc>
    4514:	913ee339 	add	x25, x25, #0xfb8
    4518:	f9014ffa 	str	x26, [sp, #664]
    451c:	14000005 	b	4530 <fwp_write.constprop.0+0x8d0>
    4520:	aa1903e1 	mov	x1, x25
    4524:	aa1403e0 	mov	x0, x20
    4528:	d2800042 	mov	x2, #0x2                   	// #2
    452c:	97fff681 	bl	1f30 <buf_put>
    4530:	38776ac5 	ldrb	w5, [x22, x23]
    4534:	d2804003 	mov	x3, #0x200                 	// #512
    4538:	aa1803e4 	mov	x4, x24
    453c:	aa0303e1 	mov	x1, x3
    4540:	52800042 	mov	w2, #0x2                   	// #2
    4544:	aa1503e0 	mov	x0, x21
    4548:	910006f7 	add	x23, x23, #0x1
    454c:	97fff3b1 	bl	1410 <__snprintf_chk@plt>
    4550:	aa1503e0 	mov	x0, x21
    4554:	97fff377 	bl	1330 <strlen@plt>
    4558:	aa1503e1 	mov	x1, x21
    455c:	aa0003e2 	mov	x2, x0
    4560:	aa1403e0 	mov	x0, x20
    4564:	97fff673 	bl	1f30 <buf_put>
    4568:	f9400260 	ldr	x0, [x19]
    456c:	eb0002ff 	cmp	x23, x0
    4570:	54fffd83 	b.cc	4520 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4574:	f94143f7 	ldr	x23, [sp, #640]
    4578:	f94147f8 	ldr	x24, [sp, #648]
    457c:	f9414bf9 	ldr	x25, [sp, #656]
    4580:	f9414ffa 	ldr	x26, [sp, #664]
    4584:	52800ba3 	mov	w3, #0x5d                  	// #93
    4588:	aa1403e0 	mov	x0, x20
    458c:	91001fe1 	add	x1, sp, #0x7
    4590:	d2800022 	mov	x2, #0x1                   	// #1
    4594:	39001fe3 	strb	w3, [sp, #7]
    4598:	17fffdd9 	b	3cfc <fwp_write.constprop.0+0x9c>
    459c:	52800b63 	mov	w3, #0x5b                  	// #91
    45a0:	91001ff5 	add	x21, sp, #0x7
    45a4:	aa1503e1 	mov	x1, x21
    45a8:	aa1403e0 	mov	x0, x20
    45ac:	d2800022 	mov	x2, #0x1                   	// #1
    45b0:	f0000016 	adrp	x22, 7000 <fwp_main_thread+0x23fc>
    45b4:	913ee2d6 	add	x22, x22, #0xfb8
    45b8:	39001fe3 	strb	w3, [sp, #7]
    45bc:	97fff65d 	bl	1f30 <buf_put>
    45c0:	b4000233 	cbz	x19, 4604 <fwp_write.constprop.0+0x9a4>
    45c4:	f9400661 	ldr	x1, [x19, #8]
    45c8:	aa1403e0 	mov	x0, x20
    45cc:	f9401f82 	ldr	x2, [x28, #56]
    45d0:	97fffda4 	bl	3c60 <fwp_write.constprop.0>
    45d4:	f9400a73 	ldr	x19, [x19, #16]
    45d8:	b4000173 	cbz	x19, 4604 <fwp_write.constprop.0+0x9a4>
    45dc:	aa1603e1 	mov	x1, x22
    45e0:	aa1403e0 	mov	x0, x20
    45e4:	d2800042 	mov	x2, #0x2                   	// #2
    45e8:	97fff652 	bl	1f30 <buf_put>
    45ec:	f9400661 	ldr	x1, [x19, #8]
    45f0:	aa1403e0 	mov	x0, x20
    45f4:	f9401f82 	ldr	x2, [x28, #56]
    45f8:	97fffd9a 	bl	3c60 <fwp_write.constprop.0>
    45fc:	f9400a73 	ldr	x19, [x19, #16]
    4600:	b5fffef3 	cbnz	x19, 45dc <fwp_write.constprop.0+0x97c>
    4604:	52800ba3 	mov	w3, #0x5d                  	// #93
    4608:	aa1503e1 	mov	x1, x21
    460c:	aa1403e0 	mov	x0, x20
    4610:	d2800022 	mov	x2, #0x1                   	// #1
    4614:	39001fe3 	strb	w3, [sp, #7]
    4618:	17fffdb9 	b	3cfc <fwp_write.constprop.0+0x9c>
    461c:	52800783 	mov	w3, #0x3c                  	// #60
    4620:	91001ff3 	add	x19, sp, #0x7
    4624:	aa1303e1 	mov	x1, x19
    4628:	d2800022 	mov	x2, #0x1                   	// #1
    462c:	aa1403e0 	mov	x0, x20
    4630:	39001fe3 	strb	w3, [sp, #7]
    4634:	97fff63f 	bl	1f30 <buf_put>
    4638:	f9400795 	ldr	x21, [x28, #8]
    463c:	aa1503e0 	mov	x0, x21
    4640:	97fff33c 	bl	1330 <strlen@plt>
    4644:	aa1503e1 	mov	x1, x21
    4648:	aa0003e2 	mov	x2, x0
    464c:	aa1403e0 	mov	x0, x20
    4650:	97fff638 	bl	1f30 <buf_put>
    4654:	528007c3 	mov	w3, #0x3e                  	// #62
    4658:	aa1303e1 	mov	x1, x19
    465c:	aa1403e0 	mov	x0, x20
    4660:	d2800022 	mov	x2, #0x1                   	// #1
    4664:	39001fe3 	strb	w3, [sp, #7]
    4668:	17fffda5 	b	3cfc <fwp_write.constprop.0+0x9c>
    466c:	f100067f 	cmp	x19, #0x1
    4670:	540017e0 	b.eq	496c <fwp_write.constprop.0+0xd0c>  // b.none
    4674:	b100067f 	cmn	x19, #0x1
    4678:	54001b00 	b.eq	49d8 <fwp_write.constprop.0+0xd78>  // b.none
    467c:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    4680:	913ca021 	add	x1, x1, #0xf28
    4684:	d2800022 	mov	x2, #0x1                   	// #1
    4688:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    468c:	f947f400 	ldr	x0, [x0, #4072]
    4690:	f94127e4 	ldr	x4, [sp, #584]
    4694:	f9400003 	ldr	x3, [x0]
    4698:	eb030084 	subs	x4, x4, x3
    469c:	d2800003 	mov	x3, #0x0                   	// #0
    46a0:	54002a41 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    46a4:	f9413bf5 	ldr	x21, [sp, #624]
    46a8:	aa1403e0 	mov	x0, x20
    46ac:	f9413ff6 	ldr	x22, [sp, #632]
    46b0:	17fffdef 	b	3e6c <fwp_write.constprop.0+0x20c>
    46b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    46b8:	17fffe2c 	b	3f68 <fwp_write.constprop.0+0x308>
    46bc:	f10002ff 	cmp	x23, #0x0
    46c0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    46c4:	71002c3f 	cmp	w1, #0xb
    46c8:	54ffec80 	b.eq	4458 <fwp_write.constprop.0+0x7f8>  // b.none
    46cc:	aa1303e2 	mov	x2, x19
    46d0:	aa1703e1 	mov	x1, x23
    46d4:	aa1403e0 	mov	x0, x20
    46d8:	97fffd62 	bl	3c60 <fwp_write.constprop.0>
    46dc:	17ffff70 	b	449c <fwp_write.constprop.0+0x83c>
    46e0:	aa1903e1 	mov	x1, x25
    46e4:	aa1403e0 	mov	x0, x20
    46e8:	d2800042 	mov	x2, #0x2                   	// #2
    46ec:	97fff611 	bl	1f30 <buf_put>
    46f0:	17fffeee 	b	42a8 <fwp_write.constprop.0+0x648>
    46f4:	aa1403e0 	mov	x0, x20
    46f8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    46fc:	d2800042 	mov	x2, #0x2                   	// #2
    4700:	913e4021 	add	x1, x1, #0xf90
    4704:	97fff60b 	bl	1f30 <buf_put>
    4708:	17fffee8 	b	42a8 <fwp_write.constprop.0+0x648>
    470c:	aa1803e1 	mov	x1, x24
    4710:	aa1403e0 	mov	x0, x20
    4714:	d2800042 	mov	x2, #0x2                   	// #2
    4718:	97fff606 	bl	1f30 <buf_put>
    471c:	17fffee3 	b	42a8 <fwp_write.constprop.0+0x648>
    4720:	f9414bf9 	ldr	x25, [sp, #656]
    4724:	f9414ffa 	ldr	x26, [sp, #664]
    4728:	aa1503e1 	mov	x1, x21
    472c:	aa1403e0 	mov	x0, x20
    4730:	52800443 	mov	w3, #0x22                  	// #34
    4734:	17fffe0f 	b	3f70 <fwp_write.constprop.0+0x310>
    4738:	a9400281 	ldp	x1, x0, [x20]
    473c:	91000800 	add	x0, x0, #0x2
    4740:	8b160000 	add	x0, x0, x22
    4744:	f9000680 	str	x0, [x20, #8]
    4748:	3820683f 	strb	wzr, [x1, x0]
    474c:	f9413bf5 	ldr	x21, [sp, #624]
    4750:	f9413ff6 	ldr	x22, [sp, #632]
    4754:	f94153fb 	ldr	x27, [sp, #672]
    4758:	f94157fc 	ldr	x28, [sp, #680]
    475c:	17fffd6d 	b	3d10 <fwp_write.constprop.0+0xb0>
    4760:	aa1403e0 	mov	x0, x20
    4764:	91001fe1 	add	x1, sp, #0x7
    4768:	52800fa3 	mov	w3, #0x7d                  	// #125
    476c:	d2800022 	mov	x2, #0x1                   	// #1
    4770:	17fffe01 	b	3f74 <fwp_write.constprop.0+0x314>
    4774:	f9400f80 	ldr	x0, [x28, #24]
    4778:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    477c:	aa1b03e0 	mov	x0, x27
    4780:	97fff2ec 	bl	1330 <strlen@plt>
    4784:	aa1b03e1 	mov	x1, x27
    4788:	aa0003e2 	mov	x2, x0
    478c:	aa1403e0 	mov	x0, x20
    4790:	97fff5e8 	bl	1f30 <buf_put>
    4794:	aa1903e1 	mov	x1, x25
    4798:	aa1403e0 	mov	x0, x20
    479c:	d2800062 	mov	x2, #0x3                   	// #3
    47a0:	97fff5e4 	bl	1f30 <buf_put>
    47a4:	17fffde4 	b	3f34 <fwp_write.constprop.0+0x2d4>
    47a8:	aa1a03e1 	mov	x1, x26
    47ac:	aa1403e0 	mov	x0, x20
    47b0:	d2800042 	mov	x2, #0x2                   	// #2
    47b4:	97fff5df 	bl	1f30 <buf_put>
    47b8:	17fffddd 	b	3f2c <fwp_write.constprop.0+0x2cc>
    47bc:	f9400660 	ldr	x0, [x19, #8]
    47c0:	b4fff860 	cbz	x0, 46cc <fwp_write.constprop.0+0xa6c>
    47c4:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    47c8:	913f4021 	add	x1, x1, #0xfd0
    47cc:	97fff355 	bl	1520 <strcmp@plt>
    47d0:	7100001f 	cmp	w0, #0x0
    47d4:	1a9f07e0 	cset	w0, ne	// ne = any
    47d8:	17ffff20 	b	4458 <fwp_write.constprop.0+0x7f8>
    47dc:	aa1403e0 	mov	x0, x20
    47e0:	d2800042 	mov	x2, #0x2                   	// #2
    47e4:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    47e8:	913f2021 	add	x1, x1, #0xfc8
    47ec:	97fff5d1 	bl	1f30 <buf_put>
    47f0:	91004261 	add	x1, x19, #0x10
    47f4:	aa1403e0 	mov	x0, x20
    47f8:	f9402382 	ldr	x2, [x28, #64]
    47fc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4800:	97fffd18 	bl	3c60 <fwp_write.constprop.0>
    4804:	17fffd71 	b	3dc8 <fwp_write.constprop.0+0x168>
    4808:	d2800203 	mov	x3, #0x10                  	// #16
    480c:	f0000004 	adrp	x4, 7000 <fwp_main_thread+0x23fc>
    4810:	aa0303e1 	mov	x1, x3
    4814:	913e8084 	add	x4, x4, #0xfa0
    4818:	910123f7 	add	x23, sp, #0x48
    481c:	52800042 	mov	w2, #0x2                   	// #2
    4820:	aa1703e0 	mov	x0, x23
    4824:	97fff2fb 	bl	1410 <__snprintf_chk@plt>
    4828:	aa1703e0 	mov	x0, x23
    482c:	97fff2c1 	bl	1330 <strlen@plt>
    4830:	aa1703e1 	mov	x1, x23
    4834:	aa0003e2 	mov	x2, x0
    4838:	aa1403e0 	mov	x0, x20
    483c:	97fff5bd 	bl	1f30 <buf_put>
    4840:	17fffe9a 	b	42a8 <fwp_write.constprop.0+0x648>
    4844:	7101fcbf 	cmp	w5, #0x7f
    4848:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    484c:	54fffde9 	b.ls	4808 <fwp_write.constprop.0+0xba8>  // b.plast
    4850:	aa1503e1 	mov	x1, x21
    4854:	aa1403e0 	mov	x0, x20
    4858:	d2800022 	mov	x2, #0x1                   	// #1
    485c:	39001fe5 	strb	w5, [sp, #7]
    4860:	97fff5b4 	bl	1f30 <buf_put>
    4864:	17fffe91 	b	42a8 <fwp_write.constprop.0+0x648>
    4868:	1e22c109 	fcvt	d9, s8
    486c:	910123f5 	add	x21, sp, #0x48
    4870:	52800033 	mov	w19, #0x1                   	// #1
    4874:	d503201f 	nop
    4878:	1e604120 	fmov	d0, d9
    487c:	2a1303e1 	mov	w1, w19
    4880:	aa1503e0 	mov	x0, x21
    4884:	97fff63f 	bl	2180 <fwp_format_g.constprop.0>
    4888:	aa1503e0 	mov	x0, x21
    488c:	d2800001 	mov	x1, #0x0                   	// #0
    4890:	97fff330 	bl	1550 <strtof@plt>
    4894:	1e202100 	fcmp	s8, s0
    4898:	54ffd6c0 	b.eq	4370 <fwp_write.constprop.0+0x710>  // b.none
    489c:	11000673 	add	w19, w19, #0x1
    48a0:	71002a7f 	cmp	w19, #0xa
    48a4:	54fffea1 	b.ne	4878 <fwp_write.constprop.0+0xc18>  // b.any
    48a8:	1e604120 	fmov	d0, d9
    48ac:	aa1503e0 	mov	x0, x21
    48b0:	52800121 	mov	w1, #0x9                   	// #9
    48b4:	97fff633 	bl	2180 <fwp_format_g.constprop.0>
    48b8:	17fffeae 	b	4370 <fwp_write.constprop.0+0x710>
    48bc:	d37ef6a1 	lsl	x1, x21, #2
    48c0:	b7f809a3 	tbnz	x3, #63, 49f4 <fwp_write.constprop.0+0xd94>
    48c4:	91002263 	add	x3, x19, #0x8
    48c8:	8b010061 	add	x1, x3, x1
    48cc:	b9400023 	ldr	w3, [x1]
    48d0:	7100081f 	cmp	w0, #0x2
    48d4:	2a0303e1 	mov	w1, w3
    48d8:	93407c63 	sxtw	x3, w3
    48dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    48e0:	17fffe16 	b	4138 <fwp_write.constprop.0+0x4d8>
    48e4:	d37ffaa1 	lsl	x1, x21, #1
    48e8:	b7f80803 	tbnz	x3, #63, 49e8 <fwp_write.constprop.0+0xd88>
    48ec:	91002263 	add	x3, x19, #0x8
    48f0:	8b010061 	add	x1, x3, x1
    48f4:	79400021 	ldrh	w1, [x1]
    48f8:	7100041f 	cmp	w0, #0x1
    48fc:	93403c23 	sxth	x3, w1
    4900:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4904:	17fffe0d 	b	4138 <fwp_write.constprop.0+0x4d8>
    4908:	7100103f 	cmp	w1, #0x4
    490c:	54ffee01 	b.ne	46cc <fwp_write.constprop.0+0xa6c>  // b.any
    4910:	f94006e0 	ldr	x0, [x23, #8]
    4914:	d37ffc00 	lsr	x0, x0, #63
    4918:	17fffed0 	b	4458 <fwp_write.constprop.0+0x7f8>
    491c:	710002ff 	cmp	w23, #0x0
    4920:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4924:	17fffecd 	b	4458 <fwp_write.constprop.0+0x7f8>
    4928:	528005a1 	mov	w1, #0x2d                  	// #45
    492c:	eb0203e2 	negs	x2, x2
    4930:	da0303e3 	ngc	x3, x3
    4934:	910127e0 	add	x0, sp, #0x49
    4938:	910123f5 	add	x21, sp, #0x48
    493c:	390123e1 	strb	w1, [sp, #72]
    4940:	97fff428 	bl	19e0 <fwp_fmt_u128>
    4944:	17fffe16 	b	419c <fwp_write.constprop.0+0x53c>
    4948:	d37ceea1 	lsl	x1, x21, #4
    494c:	b7f80da3 	tbnz	x3, #63, 4b00 <fwp_write.constprop.0+0xea0>
    4950:	91002260 	add	x0, x19, #0x8
    4954:	8b010001 	add	x1, x0, x1
    4958:	17fffdf8 	b	4138 <fwp_write.constprop.0+0x4d8>
    495c:	f9400a61 	ldr	x1, [x19, #16]
    4960:	8b010000 	add	x0, x0, x1
    4964:	f9400001 	ldr	x1, [x0]
    4968:	17fffdf4 	b	4138 <fwp_write.constprop.0+0x4d8>
    496c:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    4970:	d2800042 	mov	x2, #0x2                   	// #2
    4974:	913c6021 	add	x1, x1, #0xf18
    4978:	17ffff44 	b	4688 <fwp_write.constprop.0+0xa28>
    497c:	1e604100 	fmov	d0, d8
    4980:	aa1503e0 	mov	x0, x21
    4984:	52800221 	mov	w1, #0x11                  	// #17
    4988:	97fff5fe 	bl	2180 <fwp_format_g.constprop.0>
    498c:	17fffe79 	b	4370 <fwp_write.constprop.0+0x710>
    4990:	b9401380 	ldr	w0, [x28, #16]
    4994:	350003c0 	cbnz	w0, 4a0c <fwp_write.constprop.0+0xdac>
    4998:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    499c:	f947f400 	ldr	x0, [x0, #4072]
    49a0:	f94127e2 	ldr	x2, [sp, #584]
    49a4:	f9400001 	ldr	x1, [x0]
    49a8:	eb010042 	subs	x2, x2, x1
    49ac:	d2800001 	mov	x1, #0x0                   	// #0
    49b0:	54001201 	b.ne	4bf0 <fwp_write.constprop.0+0xf90>  // b.any
    49b4:	f9413bf5 	ldr	x21, [sp, #624]
    49b8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    49bc:	f9413ff6 	ldr	x22, [sp, #632]
    49c0:	aa1403e0 	mov	x0, x20
    49c4:	f94143f7 	ldr	x23, [sp, #640]
    49c8:	913fc021 	add	x1, x1, #0xff0
    49cc:	f94147f8 	ldr	x24, [sp, #648]
    49d0:	d2800042 	mov	x2, #0x2                   	// #2
    49d4:	17fffd26 	b	3e6c <fwp_write.constprop.0+0x20c>
    49d8:	f0000001 	adrp	x1, 7000 <fwp_main_thread+0x23fc>
    49dc:	d2800042 	mov	x2, #0x2                   	// #2
    49e0:	913c8021 	add	x1, x1, #0xf20
    49e4:	17ffff29 	b	4688 <fwp_write.constprop.0+0xa28>
    49e8:	f9400a63 	ldr	x3, [x19, #16]
    49ec:	8b030021 	add	x1, x1, x3
    49f0:	17ffffc1 	b	48f4 <fwp_write.constprop.0+0xc94>
    49f4:	f9400a63 	ldr	x3, [x19, #16]
    49f8:	8b030021 	add	x1, x1, x3
    49fc:	17ffffb4 	b	48cc <fwp_write.constprop.0+0xc6c>
    4a00:	f9400a61 	ldr	x1, [x19, #16]
    4a04:	8b0102a1 	add	x1, x21, x1
    4a08:	17fffdc7 	b	4124 <fwp_write.constprop.0+0x4c4>
    4a0c:	b9404b80 	ldr	w0, [x28, #72]
    4a10:	91001ff5 	add	x21, sp, #0x7
    4a14:	34ffa660 	cbz	w0, 3ee0 <fwp_write.constprop.0+0x280>
    4a18:	52800503 	mov	w3, #0x28                  	// #40
    4a1c:	aa1403e0 	mov	x0, x20
    4a20:	aa1503e1 	mov	x1, x21
    4a24:	d2800022 	mov	x2, #0x1                   	// #1
    4a28:	39001fe3 	strb	w3, [sp, #7]
    4a2c:	97fff541 	bl	1f30 <buf_put>
    4a30:	b9401380 	ldr	w0, [x28, #16]
    4a34:	52800038 	mov	w24, #0x1                   	// #1
    4a38:	7100001f 	cmp	w0, #0x0
    4a3c:	54ffa66c 	b.gt	3f08 <fwp_write.constprop.0+0x2a8>
    4a40:	17fffd49 	b	3f64 <fwp_write.constprop.0+0x304>
    4a44:	f9014bf9 	str	x25, [sp, #656]
    4a48:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x160a0>
    4a4c:	f9014ffa 	str	x26, [sp, #664]
    4a50:	f9400676 	ldr	x22, [x19, #8]
    4a54:	912ca333 	add	x19, x25, #0xb28
    4a58:	91002273 	add	x19, x19, #0x8
    4a5c:	937ffed8 	asr	x24, x22, #63
    4a60:	aa1802c0 	orr	x0, x22, x24
    4a64:	b5000320 	cbnz	x0, 4ac8 <fwp_write.constprop.0+0xe68>
    4a68:	110006b5 	add	w21, w21, #0x1
    4a6c:	710016bf 	cmp	w21, #0x5
    4a70:	54ffffc1 	b.ne	4a68 <fwp_write.constprop.0+0xe08>  // b.any
    4a74:	b7f80578 	tbnz	x24, #63, 4b20 <fwp_write.constprop.0+0xec0>
    4a78:	910023f3 	add	x19, sp, #0x8
    4a7c:	aa1603e2 	mov	x2, x22
    4a80:	aa1303e0 	mov	x0, x19
    4a84:	d2800003 	mov	x3, #0x0                   	// #0
    4a88:	97fff3d6 	bl	19e0 <fwp_fmt_u128>
    4a8c:	910123f5 	add	x21, sp, #0x48
    4a90:	f0000003 	adrp	x3, 7000 <fwp_main_thread+0x23fc>
    4a94:	aa1303e4 	mov	x4, x19
    4a98:	aa1503e0 	mov	x0, x21
    4a9c:	913fa063 	add	x3, x3, #0xfe8
    4aa0:	d2804002 	mov	x2, #0x200                 	// #512
    4aa4:	52800041 	mov	w1, #0x2                   	// #2
    4aa8:	97fff226 	bl	1340 <__sprintf_chk@plt>
    4aac:	aa1503e0 	mov	x0, x21
    4ab0:	97fff220 	bl	1330 <strlen@plt>
    4ab4:	aa1503e1 	mov	x1, x21
    4ab8:	aa0003e2 	mov	x2, x0
    4abc:	aa1403e0 	mov	x0, x20
    4ac0:	97fff51c 	bl	1f30 <buf_put>
    4ac4:	17fffe7b 	b	44b0 <fwp_write.constprop.0+0x850>
    4ac8:	f9400277 	ldr	x23, [x19]
    4acc:	aa1603e0 	mov	x0, x22
    4ad0:	aa1803e1 	mov	x1, x24
    4ad4:	aa1703e2 	mov	x2, x23
    4ad8:	937ffefa 	asr	x26, x23, #63
    4adc:	aa1a03e3 	mov	x3, x26
    4ae0:	94000ba0 	bl	7960 <__modti3>
    4ae4:	aa010000 	orr	x0, x0, x1
    4ae8:	b40002c0 	cbz	x0, 4b40 <fwp_write.constprop.0+0xee0>
    4aec:	110006b5 	add	w21, w21, #0x1
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	710016bf 	cmp	w21, #0x5
    4af8:	54fffe81 	b.ne	4ac8 <fwp_write.constprop.0+0xe68>  // b.any
    4afc:	17ffffde 	b	4a74 <fwp_write.constprop.0+0xe14>
    4b00:	f9400a60 	ldr	x0, [x19, #16]
    4b04:	8b000021 	add	x1, x1, x0
    4b08:	17fffd8c 	b	4138 <fwp_write.constprop.0+0x4d8>
    4b0c:	528c29c0 	mov	w0, #0x614e                	// #24910
    4b10:	910123f5 	add	x21, sp, #0x48
    4b14:	72a009c0 	movk	w0, #0x4e, lsl #16
    4b18:	b9004be0 	str	w0, [sp, #72]
    4b1c:	17fffdb9 	b	4200 <fwp_write.constprop.0+0x5a0>
    4b20:	528005a1 	mov	w1, #0x2d                  	// #45
    4b24:	eb1603e2 	negs	x2, x22
    4b28:	da1803e3 	ngc	x3, x24
    4b2c:	910027e0 	add	x0, sp, #0x9
    4b30:	910023f3 	add	x19, sp, #0x8
    4b34:	390023e1 	strb	w1, [sp, #8]
    4b38:	97fff3aa 	bl	19e0 <fwp_fmt_u128>
    4b3c:	17ffffd4 	b	4a8c <fwp_write.constprop.0+0xe2c>
    4b40:	aa1703e2 	mov	x2, x23
    4b44:	aa1a03e3 	mov	x3, x26
    4b48:	aa1603e0 	mov	x0, x22
    4b4c:	aa1803e1 	mov	x1, x24
    4b50:	94000aa4 	bl	75e0 <__divti3>
    4b54:	aa0003e2 	mov	x2, x0
    4b58:	aa0103e3 	mov	x3, x1
    4b5c:	b7f80201 	tbnz	x1, #63, 4b9c <fwp_write.constprop.0+0xf3c>
    4b60:	910023f3 	add	x19, sp, #0x8
    4b64:	aa1303e0 	mov	x0, x19
    4b68:	97fff39e 	bl	19e0 <fwp_fmt_u128>
    4b6c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4b70:	912ca339 	add	x25, x25, #0xb28
    4b74:	910123f5 	add	x21, sp, #0x48
    4b78:	aa1303e4 	mov	x4, x19
    4b7c:	aa1503e0 	mov	x0, x21
    4b80:	f0000003 	adrp	x3, 7000 <fwp_main_thread+0x23fc>
    4b84:	f8616b25 	ldr	x5, [x25, x1]
    4b88:	913f8063 	add	x3, x3, #0xfe0
    4b8c:	d2804002 	mov	x2, #0x200                 	// #512
    4b90:	52800041 	mov	w1, #0x2                   	// #2
    4b94:	97fff1eb 	bl	1340 <__sprintf_chk@plt>
    4b98:	17ffffc5 	b	4aac <fwp_write.constprop.0+0xe4c>
    4b9c:	528005a4 	mov	w4, #0x2d                  	// #45
    4ba0:	eb0003e2 	negs	x2, x0
    4ba4:	da0103e3 	ngc	x3, x1
    4ba8:	910027e0 	add	x0, sp, #0x9
    4bac:	910023f3 	add	x19, sp, #0x8
    4bb0:	390023e4 	strb	w4, [sp, #8]
    4bb4:	97fff38b 	bl	19e0 <fwp_fmt_u128>
    4bb8:	17ffffed 	b	4b6c <fwp_write.constprop.0+0xf0c>
    4bbc:	f9013bf5 	str	x21, [sp, #624]
    4bc0:	f9013ff6 	str	x22, [sp, #632]
    4bc4:	f90143f7 	str	x23, [sp, #640]
    4bc8:	f90147f8 	str	x24, [sp, #648]
    4bcc:	f9014bf9 	str	x25, [sp, #656]
    4bd0:	f9014ffa 	str	x26, [sp, #664]
    4bd4:	f90153fb 	str	x27, [sp, #672]
    4bd8:	f90157fc 	str	x28, [sp, #680]
    4bdc:	fd015be8 	str	d8, [sp, #688]
    4be0:	fd015fe9 	str	d9, [sp, #696]
    4be4:	97fff22f 	bl	14a0 <__stack_chk_fail@plt>
    4be8:	f90143f7 	str	x23, [sp, #640]
    4bec:	f90147f8 	str	x24, [sp, #648]
    4bf0:	f9014bf9 	str	x25, [sp, #656]
    4bf4:	f9014ffa 	str	x26, [sp, #664]
    4bf8:	fd015be8 	str	d8, [sp, #688]
    4bfc:	fd015fe9 	str	d9, [sp, #696]
    4c00:	97fff228 	bl	14a0 <__stack_chk_fail@plt>

0000000000004c04 <fwp_main_thread>:
    4c04:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
    4c08:	910003fd 	mov	x29, sp
    4c0c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c10:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    4c14:	91144261 	add	x1, x19, #0x510
    4c18:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    4c1c:	f947f400 	ldr	x0, [x0, #4072]
    4c20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c24:	d10583ff 	sub	sp, sp, #0x160
    4c28:	b953a421 	ldr	w1, [x1, #5028]
    4c2c:	f9400002 	ldr	x2, [x0]
    4c30:	f900afe2 	str	x2, [sp, #344]
    4c34:	d2800002 	mov	x2, #0x0                   	// #0
    4c38:	34007341 	cbz	w1, 5aa0 <fwp_main_thread+0xe9c>
    4c3c:	91144260 	add	x0, x19, #0x510
    4c40:	b953a800 	ldr	w0, [x0, #5032]
    4c44:	35007360 	cbnz	w0, 5ab0 <fwp_main_thread+0xeac>
    4c48:	910123e5 	add	x5, sp, #0x48
    4c4c:	900000e0 	adrp	x0, 20000 <__data_start>
    4c50:	900000e2 	adrp	x2, 20000 <__data_start>
    4c54:	9101c015 	add	x21, x0, #0x70
    4c58:	910cc042 	add	x2, x2, #0x330
    4c5c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    4c60:	d2a00024 	mov	x4, #0x10000               	// #65536
    4c64:	910183e0 	add	x0, sp, #0x60
    4c68:	d2800001 	mov	x1, #0x0                   	// #0
    4c6c:	a9010ea5 	stp	x5, x3, [x21, #16]
    4c70:	f9000be0 	str	x0, [sp, #16]
    4c74:	f90013e5 	str	x5, [sp, #32]
    4c78:	f90033e2 	str	x2, [sp, #96]
    4c7c:	b9006bff 	str	wzr, [sp, #104]
    4c80:	f9003be4 	str	x4, [sp, #112]
    4c84:	97fff1a3 	bl	1310 <sigaltstack@plt>
    4c88:	a91963f7 	stp	x23, x24, [sp, #400]
    4c8c:	3500c7a0 	cbnz	w0, 6580 <fwp_main_thread+0x197c>
    4c90:	4f000400 	movi	v0.4s, #0x0
    4c94:	910323e0 	add	x0, sp, #0xc8
    4c98:	b0ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    4c9c:	912f4021 	add	x1, x1, #0xbd0
    4ca0:	f90063e1 	str	x1, [sp, #192]
    4ca4:	52800082 	mov	w2, #0x4                   	// #4
    4ca8:	72a10002 	movk	w2, #0x800, lsl #16
    4cac:	910303f8 	add	x24, sp, #0xc0
    4cb0:	3d802000 	str	q0, [x0, #128]
    4cb4:	b9014be2 	str	w2, [sp, #328]
    4cb8:	ad000000 	stp	q0, q0, [x0]
    4cbc:	ad010000 	stp	q0, q0, [x0, #32]
    4cc0:	ad020000 	stp	q0, q0, [x0, #64]
    4cc4:	ad030000 	stp	q0, q0, [x0, #96]
    4cc8:	97fff1e6 	bl	1460 <sigemptyset@plt>
    4ccc:	3500c5a0 	cbnz	w0, 6580 <fwp_main_thread+0x197c>
    4cd0:	aa1803e1 	mov	x1, x24
    4cd4:	d2800002 	mov	x2, #0x0                   	// #0
    4cd8:	52800160 	mov	w0, #0xb                   	// #11
    4cdc:	97fff1f9 	bl	14c0 <sigaction@plt>
    4ce0:	3500c500 	cbnz	w0, 6580 <fwp_main_thread+0x197c>
    4ce4:	aa1803e1 	mov	x1, x24
    4ce8:	d2800002 	mov	x2, #0x0                   	// #0
    4cec:	528000e0 	mov	w0, #0x7                   	// #7
    4cf0:	97fff1f4 	bl	14c0 <sigaction@plt>
    4cf4:	3500c460 	cbnz	w0, 6580 <fwp_main_thread+0x197c>
    4cf8:	b94296a0 	ldr	w0, [x21, #660]
    4cfc:	a91b73fb 	stp	x27, x28, [sp, #432]
    4d00:	34001ee0 	cbz	w0, 50dc <fwp_main_thread+0x4d8>
    4d04:	900000e0 	adrp	x0, 20000 <__data_start>
    4d08:	9101c015 	add	x21, x0, #0x70
    4d0c:	f94006b4 	ldr	x20, [x21, #8]
    4d10:	b4000cf4 	cbz	x20, 4eac <fwp_main_thread+0x2a8>
    4d14:	aa1403f3 	mov	x19, x20
    4d18:	91010296 	add	x22, x20, #0x40
    4d1c:	39414a98 	ldrb	w24, [x20, #82]
    4d20:	52800037 	mov	w23, #0x1                   	// #1
    4d24:	39014a97 	strb	w23, [x20, #82]
    4d28:	f9401680 	ldr	x0, [x20, #40]
    4d2c:	b4000620 	cbz	x0, 4df0 <fwp_main_thread+0x1ec>
    4d30:	f9403281 	ldr	x1, [x20, #96]
    4d34:	39414680 	ldrb	w0, [x20, #81]
    4d38:	b4001901 	cbz	x1, 5058 <fwp_main_thread+0x454>
    4d3c:	360017c0 	tbz	w0, #0, 5034 <fwp_main_thread+0x430>
    4d40:	39414a62 	ldrb	w2, [x19, #82]
    4d44:	f9402280 	ldr	x0, [x20, #64]
    4d48:	37001b22 	tbnz	w2, #0, 50ac <fwp_main_thread+0x4a8>
    4d4c:	f9403261 	ldr	x1, [x19, #96]
    4d50:	a911fe76 	stp	x22, xzr, [x19, #280]
    4d54:	f9009660 	str	x0, [x19, #296]
    4d58:	b4000040 	cbz	x0, 4d60 <fwp_main_thread+0x15c>
    4d5c:	f9009013 	str	x19, [x0, #288]
    4d60:	f9002293 	str	x19, [x20, #64]
    4d64:	b4000101 	cbz	x1, 4d84 <fwp_main_thread+0x180>
    4d68:	f9401aa0 	ldr	x0, [x21, #48]
    4d6c:	39015677 	strb	w23, [x19, #85]
    4d70:	f9003661 	str	x1, [x19, #104]
    4d74:	a910827f 	stp	xzr, x0, [x19, #264]
    4d78:	b4000040 	cbz	x0, 4d80 <fwp_main_thread+0x17c>
    4d7c:	f9008413 	str	x19, [x0, #264]
    4d80:	f9001ab3 	str	x19, [x21, #48]
    4d84:	39015a7f 	strb	wzr, [x19, #86]
    4d88:	97fffb5f 	bl	3b04 <fwp_block>
    4d8c:	f9408e62 	ldr	x2, [x19, #280]
    4d90:	b4000142 	cbz	x2, 4db8 <fwp_main_thread+0x1b4>
    4d94:	a9520261 	ldp	x1, x0, [x19, #288]
    4d98:	b4001961 	cbz	x1, 50c4 <fwp_main_thread+0x4c0>
    4d9c:	f9009420 	str	x0, [x1, #296]
    4da0:	f9409660 	ldr	x0, [x19, #296]
    4da4:	b4000040 	cbz	x0, 4dac <fwp_main_thread+0x1a8>
    4da8:	f9009001 	str	x1, [x0, #288]
    4dac:	91080260 	add	x0, x19, #0x200
    4db0:	f900967f 	str	xzr, [x19, #296]
    4db4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    4db8:	39415660 	ldrb	w0, [x19, #85]
    4dbc:	f94006a2 	ldr	x2, [x21, #8]
    4dc0:	36001720 	tbz	w0, #0, 50a4 <fwp_main_thread+0x4a0>
    4dc4:	a9508261 	ldp	x1, x0, [x19, #264]
    4dc8:	b4001821 	cbz	x1, 50cc <fwp_main_thread+0x4c8>
    4dcc:	f9008820 	str	x0, [x1, #272]
    4dd0:	b4000040 	cbz	x0, 4dd8 <fwp_main_thread+0x1d4>
    4dd4:	f9008401 	str	x1, [x0, #264]
    4dd8:	91080260 	add	x0, x19, #0x200
    4ddc:	3901567f 	strb	wzr, [x19, #85]
    4de0:	aa0203f3 	mov	x19, x2
    4de4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    4de8:	f9401680 	ldr	x0, [x20, #40]
    4dec:	b5fffa20 	cbnz	x0, 4d30 <fwp_main_thread+0x12c>
    4df0:	900000e0 	adrp	x0, 20000 <__data_start>
    4df4:	9101c000 	add	x0, x0, #0x70
    4df8:	39014a98 	strb	w24, [x20, #82]
    4dfc:	f9413c00 	ldr	x0, [x0, #632]
    4e00:	b50000a0 	cbnz	x0, 4e14 <fwp_main_thread+0x210>
    4e04:	900000e0 	adrp	x0, 20000 <__data_start>
    4e08:	9101c014 	add	x20, x0, #0x70
    4e0c:	f9414680 	ldr	x0, [x20, #648]
    4e10:	b400ab40 	cbz	x0, 6378 <fwp_main_thread+0x1774>
    4e14:	900000e0 	adrp	x0, 20000 <__data_start>
    4e18:	9101c000 	add	x0, x0, #0x70
    4e1c:	f9415401 	ldr	x1, [x0, #680]
    4e20:	b902a01f 	str	wzr, [x0, #672]
    4e24:	eb13003f 	cmp	x1, x19
    4e28:	5400abe1 	b.ne	63a4 <fwp_main_thread+0x17a0>  // b.any
    4e2c:	b40004b3 	cbz	x19, 4ec0 <fwp_main_thread+0x2bc>
    4e30:	900000e0 	adrp	x0, 20000 <__data_start>
    4e34:	9101c000 	add	x0, x0, #0x70
    4e38:	52800021 	mov	w1, #0x1                   	// #1
    4e3c:	39014a61 	strb	w1, [x19, #82]
    4e40:	f9412805 	ldr	x5, [x0, #592]
    4e44:	b40003e5 	cbz	x5, 4ec0 <fwp_main_thread+0x2bc>
    4e48:	394140a0 	ldrb	w0, [x5, #80]
    4e4c:	37000060 	tbnz	w0, #0, 4e58 <fwp_main_thread+0x254>
    4e50:	aa0503e0 	mov	x0, x5
    4e54:	97fff44f 	bl	1f90 <fwp_cancel_tree.part.0>
    4e58:	f9409ca5 	ldr	x5, [x5, #312]
    4e5c:	b5ffff65 	cbnz	x5, 4e48 <fwp_main_thread+0x244>
    4e60:	900000e0 	adrp	x0, 20000 <__data_start>
    4e64:	9101c014 	add	x20, x0, #0x70
    4e68:	52800035 	mov	w21, #0x1                   	// #1
    4e6c:	d503201f 	nop
    4e70:	f9402a60 	ldr	x0, [x19, #80]
    4e74:	f2001c1f 	tst	x0, #0xff000000ff
    4e78:	540000e1 	b.ne	4e94 <fwp_main_thread+0x290>  // b.any
    4e7c:	f9401280 	ldr	x0, [x20, #32]
    4e80:	39015275 	strb	w21, [x19, #84]
    4e84:	f900827f 	str	xzr, [x19, #256]
    4e88:	b4001260 	cbz	x0, 50d4 <fwp_main_thread+0x4d0>
    4e8c:	f9008013 	str	x19, [x0, #256]
    4e90:	f9001293 	str	x19, [x20, #32]
    4e94:	97fffb1c 	bl	3b04 <fwp_block>
    4e98:	97fffaae 	bl	3950 <fwp_free_zombie>
    4e9c:	f9412a80 	ldr	x0, [x20, #592]
    4ea0:	b4000100 	cbz	x0, 4ec0 <fwp_main_thread+0x2bc>
    4ea4:	f9415693 	ldr	x19, [x20, #680]
    4ea8:	17fffff2 	b	4e70 <fwp_main_thread+0x26c>
    4eac:	f9413ea0 	ldr	x0, [x21, #632]
    4eb0:	b400a480 	cbz	x0, 6340 <fwp_main_thread+0x173c>
    4eb4:	f94156a0 	ldr	x0, [x21, #680]
    4eb8:	b902a2bf 	str	wzr, [x21, #672]
    4ebc:	b500a740 	cbnz	x0, 63a4 <fwp_main_thread+0x17a0>
    4ec0:	97fffaa4 	bl	3950 <fwp_free_zombie>
    4ec4:	900000e0 	adrp	x0, 20000 <__data_start>
    4ec8:	9101c014 	add	x20, x0, #0x70
    4ecc:	f9401680 	ldr	x0, [x20, #40]
    4ed0:	b500a6a0 	cbnz	x0, 63a4 <fwp_main_thread+0x17a0>
    4ed4:	f9401a80 	ldr	x0, [x20, #48]
    4ed8:	b500a660 	cbnz	x0, 63a4 <fwp_main_thread+0x17a0>
    4edc:	b9404280 	ldr	w0, [x20, #64]
    4ee0:	340001e0 	cbz	w0, 4f1c <fwp_main_thread+0x318>
    4ee4:	93407c15 	sxtw	x21, w0
    4ee8:	51000400 	sub	w0, w0, #0x1
    4eec:	d1000ab5 	sub	x21, x21, #0x2
    4ef0:	91014296 	add	x22, x20, #0x50
    4ef4:	cb2042b5 	sub	x21, x21, w0, uxtw
    4ef8:	93407c13 	sxtw	x19, w0
    4efc:	d503201f 	nop
    4f00:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    4f04:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    4f08:	b9004293 	str	w19, [x20, #64]
    4f0c:	d1000673 	sub	x19, x19, #0x1
    4f10:	97fff1ac 	bl	15c0 <munmap@plt>
    4f14:	eb15027f 	cmp	x19, x21
    4f18:	54ffff41 	b.ne	4f00 <fwp_main_thread+0x2fc>  // b.any
    4f1c:	900000f3 	adrp	x19, 20000 <__data_start>
    4f20:	91004260 	add	x0, x19, #0x10
    4f24:	b9404000 	ldr	w0, [x0, #64]
    4f28:	37f80040 	tbnz	w0, #31, 4f30 <fwp_main_thread+0x32c>
    4f2c:	97fff161 	bl	14b0 <close@plt>
    4f30:	900000e0 	adrp	x0, 20000 <__data_start>
    4f34:	9101c000 	add	x0, x0, #0x70
    4f38:	91004261 	add	x1, x19, #0x10
    4f3c:	12800002 	mov	w2, #0xffffffff            	// #-1
    4f40:	d2800013 	mov	x19, #0x0                   	// #0
    4f44:	f9415815 	ldr	x21, [x0, #688]
    4f48:	b9004022 	str	w2, [x1, #64]
    4f4c:	f9415c14 	ldr	x20, [x0, #696]
    4f50:	b4000195 	cbz	x21, 4f80 <fwp_main_thread+0x37c>
    4f54:	d503201f 	nop
    4f58:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    4f5c:	b40000c0 	cbz	x0, 4f74 <fwp_main_thread+0x370>
    4f60:	f9400001 	ldr	x1, [x0]
    4f64:	b500a201 	cbnz	x1, 63a4 <fwp_main_thread+0x17a0>
    4f68:	f9400401 	ldr	x1, [x0, #8]
    4f6c:	b500a1c1 	cbnz	x1, 63a4 <fwp_main_thread+0x17a0>
    4f70:	97fff7ac 	bl	2e20 <fwp_mem_free>
    4f74:	91000673 	add	x19, x19, #0x1
    4f78:	eb15027f 	cmp	x19, x21
    4f7c:	54fffee1 	b.ne	4f58 <fwp_main_thread+0x354>  // b.any
    4f80:	aa1403e0 	mov	x0, x20
    4f84:	97fff7a7 	bl	2e20 <fwp_mem_free>
    4f88:	900000e0 	adrp	x0, 20000 <__data_start>
    4f8c:	9101c000 	add	x0, x0, #0x70
    4f90:	f9415413 	ldr	x19, [x0, #680]
    4f94:	f901581f 	str	xzr, [x0, #688]
    4f98:	f9015c1f 	str	xzr, [x0, #696]
    4f9c:	b40001f3 	cbz	x19, 4fd8 <fwp_main_thread+0x3d4>
    4fa0:	f9401661 	ldr	x1, [x19, #40]
    4fa4:	b500a001 	cbnz	x1, 63a4 <fwp_main_thread+0x17a0>
    4fa8:	f9405661 	ldr	x1, [x19, #168]
    4fac:	b5009fc1 	cbnz	x1, 63a4 <fwp_main_thread+0x17a0>
    4fb0:	f9413c01 	ldr	x1, [x0, #632]
    4fb4:	b5009f81 	cbnz	x1, 63a4 <fwp_main_thread+0x17a0>
    4fb8:	f9414400 	ldr	x0, [x0, #648]
    4fbc:	b5009f40 	cbnz	x0, 63a4 <fwp_main_thread+0x17a0>
    4fc0:	d2823a02 	mov	x2, #0x11d0                	// #4560
    4fc4:	90000160 	adrp	x0, 30000 <alt.4+0xfcd0>
    4fc8:	910cc000 	add	x0, x0, #0x330
    4fcc:	97fff129 	bl	1470 <memset@plt>
    4fd0:	aa1303e0 	mov	x0, x19
    4fd4:	97fff793 	bl	2e20 <fwp_mem_free>
    4fd8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x160a0>
    4fdc:	f947ec00 	ldr	x0, [x0, #4056]
    4fe0:	900000e1 	adrp	x1, 20000 <__data_start>
    4fe4:	9101c03c 	add	x28, x1, #0x70
    4fe8:	f9400000 	ldr	x0, [x0]
    4fec:	f900079f 	str	xzr, [x28, #8]
    4ff0:	f901579f 	str	xzr, [x28, #680]
    4ff4:	97fff177 	bl	15d0 <fflush@plt>
    4ff8:	100d0040 	adr	x0, 1f000 <__FRAME_END__+0x160a0>
    4ffc:	f947f400 	ldr	x0, [x0, #4072]
    5000:	f940afe2 	ldr	x2, [sp, #344]
    5004:	f9400001 	ldr	x1, [x0]
    5008:	eb010042 	subs	x2, x2, x1
    500c:	d2800001 	mov	x1, #0x0                   	// #0
    5010:	5400aca1 	b.ne	65a4 <fwp_main_thread+0x19a0>  // b.any
    5014:	a95963f7 	ldp	x23, x24, [sp, #400]
    5018:	d2800000 	mov	x0, #0x0                   	// #0
    501c:	a95b73fb 	ldp	x27, x28, [sp, #432]
    5020:	910583ff 	add	sp, sp, #0x160
    5024:	a94153f3 	ldp	x19, x20, [sp, #16]
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	a8ca7bfd 	ldp	x29, x30, [sp], #160
    5030:	d65f03c0 	ret
    5034:	97fff42b 	bl	20e0 <fwp_now_ns>
    5038:	f9403281 	ldr	x1, [x20, #96]
    503c:	eb01001f 	cmp	x0, x1
    5040:	540000ab 	b.lt	5054 <fwp_main_thread+0x450>  // b.tstop
    5044:	39414280 	ldrb	w0, [x20, #80]
    5048:	37000060 	tbnz	w0, #0, 5054 <fwp_main_thread+0x450>
    504c:	aa1403e0 	mov	x0, x20
    5050:	97fff3d0 	bl	1f90 <fwp_cancel_tree.part.0>
    5054:	39414680 	ldrb	w0, [x20, #81]
    5058:	39414a62 	ldrb	w2, [x19, #82]
    505c:	3707e740 	tbnz	w0, #0, 4d44 <fwp_main_thread+0x140>
    5060:	f9403281 	ldr	x1, [x20, #96]
    5064:	370001c2 	tbnz	w2, #0, 509c <fwp_main_thread+0x498>
    5068:	f9403260 	ldr	x0, [x19, #96]
    506c:	b4000180 	cbz	x0, 509c <fwp_main_thread+0x498>
    5070:	b4000061 	cbz	x1, 507c <fwp_main_thread+0x478>
    5074:	eb01001f 	cmp	x0, x1
    5078:	9a81d000 	csel	x0, x0, x1, le
    507c:	f9402281 	ldr	x1, [x20, #64]
    5080:	a911fe76 	stp	x22, xzr, [x19, #280]
    5084:	f9009661 	str	x1, [x19, #296]
    5088:	b4009721 	cbz	x1, 636c <fwp_main_thread+0x1768>
    508c:	f9009033 	str	x19, [x1, #288]
    5090:	aa0003e1 	mov	x1, x0
    5094:	f9002293 	str	x19, [x20, #64]
    5098:	17ffff34 	b	4d68 <fwp_main_thread+0x164>
    509c:	f9402280 	ldr	x0, [x20, #64]
    50a0:	17ffff2c 	b	4d50 <fwp_main_thread+0x14c>
    50a4:	aa0203f3 	mov	x19, x2
    50a8:	17ffff20 	b	4d28 <fwp_main_thread+0x124>
    50ac:	a911fe76 	stp	x22, xzr, [x19, #280]
    50b0:	f9009660 	str	x0, [x19, #296]
    50b4:	b4000040 	cbz	x0, 50bc <fwp_main_thread+0x4b8>
    50b8:	f9009013 	str	x19, [x0, #288]
    50bc:	f9002293 	str	x19, [x20, #64]
    50c0:	17ffff31 	b	4d84 <fwp_main_thread+0x180>
    50c4:	f9000040 	str	x0, [x2]
    50c8:	17ffff37 	b	4da4 <fwp_main_thread+0x1a0>
    50cc:	f9001aa0 	str	x0, [x21, #48]
    50d0:	17ffff40 	b	4dd0 <fwp_main_thread+0x1cc>
    50d4:	f9001693 	str	x19, [x20, #40]
    50d8:	17ffff6e 	b	4e90 <fwp_main_thread+0x28c>
    50dc:	f94132a2 	ldr	x2, [x21, #608]
    50e0:	d0ffffe0 	adrp	x0, 3000 <fwp_mem_free+0x1e0>
    50e4:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    50e8:	9116c000 	add	x0, x0, #0x5b0
    50ec:	912c4021 	add	x1, x1, #0xb10
    50f0:	91144263 	add	x3, x19, #0x510
    50f4:	a90487e2 	stp	x2, x1, [sp, #72]
    50f8:	d2800416 	mov	x22, #0x20                  	// #32
    50fc:	d2800014 	mov	x20, #0x0                   	// #0
    5100:	f9400be1 	ldr	x1, [sp, #16]
    5104:	a90703ff 	stp	xzr, x0, [sp, #112]
    5108:	f94013e0 	ldr	x0, [sp, #32]
    510c:	a91a6bf9 	stp	x25, x26, [sp, #416]
    5110:	5280003a 	mov	w26, #0x1                   	// #1
    5114:	6d1c27e8 	stp	d8, d9, [sp, #448]
    5118:	6d1d2fea 	stp	d10, d11, [sp, #464]
    511c:	6d1e37ec 	stp	d12, d13, [sp, #480]
    5120:	6d1f3fee 	stp	d14, d15, [sp, #496]
    5124:	f9000fff 	str	xzr, [sp, #24]
    5128:	f9002fe1 	str	x1, [sp, #88]
    512c:	f90033ff 	str	xzr, [sp, #96]
    5130:	f90132a0 	str	x0, [x21, #608]
    5134:	d503201f 	nop
    5138:	f9400fe2 	ldr	x2, [sp, #24]
    513c:	f10006d7 	subs	x23, x22, #0x1
    5140:	aa1803e1 	mov	x1, x24
    5144:	da1f0299 	sbc	x25, x20, xzr
    5148:	52800020 	mov	w0, #0x1                   	// #1
    514c:	f90007e3 	str	x3, [sp, #8]
    5150:	f90037f7 	str	x23, [sp, #104]
    5154:	aa1703f6 	mov	x22, x23
    5158:	a90c0bf7 	stp	x23, x2, [sp, #192]
    515c:	97fff8b9 	bl	3440 <fwp_data.part.0.constprop.0>
    5160:	aa0003e2 	mov	x2, x0
    5164:	f94007e3 	ldr	x3, [sp, #8]
    5168:	f9000fe2 	str	x2, [sp, #24]
    516c:	aa1903f4 	mov	x20, x25
    5170:	f949d861 	ldr	x1, [x3, #5040]
    5174:	f949ec60 	ldr	x0, [x3, #5080]
    5178:	cb010041 	sub	x1, x2, x1
    517c:	eb00403f 	cmp	x1, x0, lsl #16
    5180:	54000302 	b.cs	51e0 <fwp_main_thread+0x5dc>  // b.hs, b.nlast
    5184:	d350fc20 	lsr	x0, x1, #16
    5188:	f949fc65 	ldr	x5, [x3, #5112]
    518c:	8b000800 	add	x0, x0, x0, lsl #2
    5190:	d37df002 	lsl	x2, x0, #3
    5194:	8b0200a0 	add	x0, x5, x2
    5198:	f9401015 	ldr	x21, [x0, #32]
    519c:	b4000235 	cbz	x21, 51e0 <fwp_main_thread+0x5dc>
    51a0:	386268a2 	ldrb	w2, [x5, x2]
    51a4:	7100085f 	cmp	w2, #0x2
    51a8:	54004680 	b.eq	5a78 <fwp_main_thread+0xe74>  // b.none
    51ac:	7100045f 	cmp	w2, #0x1
    51b0:	54000181 	b.ne	51e0 <fwp_main_thread+0x5dc>  // b.any
    51b4:	29430002 	ldp	w2, w0, [x0, #24]
    51b8:	92403c21 	and	x1, x1, #0xffff
    51bc:	9b027c21 	mul	x1, x1, x2
    51c0:	d360fc21 	lsr	x1, x1, #32
    51c4:	eb00003f 	cmp	x1, x0
    51c8:	540000c2 	b.cs	51e0 <fwp_main_thread+0x5dc>  // b.hs, b.nlast
    51cc:	8b0102b5 	add	x21, x21, x1
    51d0:	394002a0 	ldrb	w0, [x21]
    51d4:	7103fc1f 	cmp	w0, #0xff
    51d8:	540045a0 	b.eq	5a8c <fwp_main_thread+0xe88>  // b.none
    51dc:	390002ba 	strb	w26, [x21]
    51e0:	f9400fe0 	ldr	x0, [sp, #24]
    51e4:	f90033e0 	str	x0, [sp, #96]
    51e8:	aa1902e0 	orr	x0, x23, x25
    51ec:	b5fffa60 	cbnz	x0, 5138 <fwp_main_thread+0x534>
    51f0:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    51f4:	910203e1 	add	x1, sp, #0x80
    51f8:	f94027e3 	ldr	x3, [sp, #72]
    51fc:	3dc08c00 	ldr	q0, [x0, #560]
    5200:	f00000c0 	adrp	x0, 20000 <__data_start>
    5204:	9101c002 	add	x2, x0, #0x70
    5208:	52800020 	mov	w0, #0x1                   	// #1
    520c:	3d8023e0 	str	q0, [sp, #128]
    5210:	f9013043 	str	x3, [x2, #608]
    5214:	97fff88b 	bl	3440 <fwp_data.part.0.constprop.0>
    5218:	91144263 	add	x3, x19, #0x510
    521c:	aa0003f4 	mov	x20, x0
    5220:	f949d861 	ldr	x1, [x3, #5040]
    5224:	f949ec60 	ldr	x0, [x3, #5080]
    5228:	cb010281 	sub	x1, x20, x1
    522c:	eb00403f 	cmp	x1, x0, lsl #16
    5230:	54000322 	b.cs	5294 <fwp_main_thread+0x690>  // b.hs, b.nlast
    5234:	d350fc22 	lsr	x2, x1, #16
    5238:	f949fc63 	ldr	x3, [x3, #5112]
    523c:	8b020842 	add	x2, x2, x2, lsl #2
    5240:	d37df042 	lsl	x2, x2, #3
    5244:	8b020060 	add	x0, x3, x2
    5248:	f9401015 	ldr	x21, [x0, #32]
    524c:	b4000255 	cbz	x21, 5294 <fwp_main_thread+0x690>
    5250:	38626862 	ldrb	w2, [x3, x2]
    5254:	7100085f 	cmp	w2, #0x2
    5258:	54008840 	b.eq	6360 <fwp_main_thread+0x175c>  // b.none
    525c:	7100045f 	cmp	w2, #0x1
    5260:	540001a1 	b.ne	5294 <fwp_main_thread+0x690>  // b.any
    5264:	29430002 	ldp	w2, w0, [x0, #24]
    5268:	92403c21 	and	x1, x1, #0xffff
    526c:	9b027c21 	mul	x1, x1, x2
    5270:	d360fc21 	lsr	x1, x1, #32
    5274:	eb00003f 	cmp	x1, x0
    5278:	540000e2 	b.cs	5294 <fwp_main_thread+0x690>  // b.hs, b.nlast
    527c:	8b0102b5 	add	x21, x21, x1
    5280:	394002a0 	ldrb	w0, [x21]
    5284:	7103fc1f 	cmp	w0, #0xff
    5288:	540093c0 	b.eq	6500 <fwp_main_thread+0x18fc>  // b.none
    528c:	52800020 	mov	w0, #0x1                   	// #1
    5290:	390002a0 	strb	w0, [x21]
    5294:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    5298:	910283e1 	add	x1, sp, #0xa0
    529c:	52800020 	mov	w0, #0x1                   	// #1
    52a0:	a90a53e2 	stp	x2, x20, [sp, #160]
    52a4:	97fff867 	bl	3440 <fwp_data.part.0.constprop.0>
    52a8:	91144263 	add	x3, x19, #0x510
    52ac:	aa0003f4 	mov	x20, x0
    52b0:	f949d861 	ldr	x1, [x3, #5040]
    52b4:	f949ec60 	ldr	x0, [x3, #5080]
    52b8:	cb010281 	sub	x1, x20, x1
    52bc:	eb00403f 	cmp	x1, x0, lsl #16
    52c0:	54000322 	b.cs	5324 <fwp_main_thread+0x720>  // b.hs, b.nlast
    52c4:	d350fc22 	lsr	x2, x1, #16
    52c8:	f949fc63 	ldr	x3, [x3, #5112]
    52cc:	8b020842 	add	x2, x2, x2, lsl #2
    52d0:	d37df042 	lsl	x2, x2, #3
    52d4:	8b020060 	add	x0, x3, x2
    52d8:	f9401015 	ldr	x21, [x0, #32]
    52dc:	b4000255 	cbz	x21, 5324 <fwp_main_thread+0x720>
    52e0:	38626862 	ldrb	w2, [x3, x2]
    52e4:	7100085f 	cmp	w2, #0x2
    52e8:	54008360 	b.eq	6354 <fwp_main_thread+0x1750>  // b.none
    52ec:	7100045f 	cmp	w2, #0x1
    52f0:	540001a1 	b.ne	5324 <fwp_main_thread+0x720>  // b.any
    52f4:	29430002 	ldp	w2, w0, [x0, #24]
    52f8:	92403c21 	and	x1, x1, #0xffff
    52fc:	9b027c21 	mul	x1, x1, x2
    5300:	d360fc21 	lsr	x1, x1, #32
    5304:	eb00003f 	cmp	x1, x0
    5308:	540000e2 	b.cs	5324 <fwp_main_thread+0x720>  // b.hs, b.nlast
    530c:	8b0102b5 	add	x21, x21, x1
    5310:	394002a0 	ldrb	w0, [x21]
    5314:	7103fc1f 	cmp	w0, #0xff
    5318:	54009000 	b.eq	6518 <fwp_main_thread+0x1914>  // b.none
    531c:	52800020 	mov	w0, #0x1                   	// #1
    5320:	390002a0 	strb	w0, [x21]
    5324:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5328:	910243e1 	add	x1, sp, #0x90
    532c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5330:	52800020 	mov	w0, #0x1                   	// #1
    5334:	a90953e2 	stp	x2, x20, [sp, #144]
    5338:	97fff842 	bl	3440 <fwp_data.part.0.constprop.0>
    533c:	91144262 	add	x2, x19, #0x510
    5340:	aa0003e3 	mov	x3, x0
    5344:	f90017e3 	str	x3, [sp, #40]
    5348:	f949d841 	ldr	x1, [x2, #5040]
    534c:	f949ec40 	ldr	x0, [x2, #5080]
    5350:	cb010061 	sub	x1, x3, x1
    5354:	eb00403f 	cmp	x1, x0, lsl #16
    5358:	54000322 	b.cs	53bc <fwp_main_thread+0x7b8>  // b.hs, b.nlast
    535c:	d350fc20 	lsr	x0, x1, #16
    5360:	f949fc43 	ldr	x3, [x2, #5112]
    5364:	8b000800 	add	x0, x0, x0, lsl #2
    5368:	d37df002 	lsl	x2, x0, #3
    536c:	8b020060 	add	x0, x3, x2
    5370:	f9401014 	ldr	x20, [x0, #32]
    5374:	b4000254 	cbz	x20, 53bc <fwp_main_thread+0x7b8>
    5378:	38626862 	ldrb	w2, [x3, x2]
    537c:	7100085f 	cmp	w2, #0x2
    5380:	54007e40 	b.eq	6348 <fwp_main_thread+0x1744>  // b.none
    5384:	7100045f 	cmp	w2, #0x1
    5388:	540001a1 	b.ne	53bc <fwp_main_thread+0x7b8>  // b.any
    538c:	29430002 	ldp	w2, w0, [x0, #24]
    5390:	92403c21 	and	x1, x1, #0xffff
    5394:	9b027c21 	mul	x1, x1, x2
    5398:	d360fc21 	lsr	x1, x1, #32
    539c:	eb00003f 	cmp	x1, x0
    53a0:	540000e2 	b.cs	53bc <fwp_main_thread+0x7b8>  // b.hs, b.nlast
    53a4:	8b010294 	add	x20, x20, x1
    53a8:	39400280 	ldrb	w0, [x20]
    53ac:	7103fc1f 	cmp	w0, #0xff
    53b0:	54008a20 	b.eq	64f4 <fwp_main_thread+0x18f0>  // b.none
    53b4:	52800020 	mov	w0, #0x1                   	// #1
    53b8:	39000280 	strb	w0, [x20]
    53bc:	f9400fe0 	ldr	x0, [sp, #24]
    53c0:	f9001fe0 	str	x0, [sp, #56]
    53c4:	b4005de0 	cbz	x0, 5f80 <fwp_main_thread+0x137c>
    53c8:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x300>
    53cc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    53d0:	9e670009 	fmov	d9, x0
    53d4:	fd41202a 	ldr	d10, [x1, #576]
    53d8:	91144262 	add	x2, x19, #0x510
    53dc:	f94017e3 	ldr	x3, [sp, #40]
    53e0:	f949d840 	ldr	x0, [x2, #5040]
    53e4:	f949ec41 	ldr	x1, [x2, #5080]
    53e8:	cb000060 	sub	x0, x3, x0
    53ec:	eb01401f 	cmp	x0, x1, lsl #16
    53f0:	54000342 	b.cs	5458 <fwp_main_thread+0x854>  // b.hs, b.nlast
    53f4:	d350fc01 	lsr	x1, x0, #16
    53f8:	f949fc43 	ldr	x3, [x2, #5112]
    53fc:	8b010821 	add	x1, x1, x1, lsl #2
    5400:	d37df021 	lsl	x1, x1, #3
    5404:	8b010062 	add	x2, x3, x1
    5408:	f9401054 	ldr	x20, [x2, #32]
    540c:	b4000274 	cbz	x20, 5458 <fwp_main_thread+0x854>
    5410:	38616861 	ldrb	w1, [x3, x1]
    5414:	7100083f 	cmp	w1, #0x2
    5418:	54007100 	b.eq	6238 <fwp_main_thread+0x1634>  // b.none
    541c:	7100043f 	cmp	w1, #0x1
    5420:	540001c1 	b.ne	5458 <fwp_main_thread+0x854>  // b.any
    5424:	29430443 	ldp	w3, w1, [x2, #24]
    5428:	92403c00 	and	x0, x0, #0xffff
    542c:	9b037c00 	mul	x0, x0, x3
    5430:	d360fc00 	lsr	x0, x0, #32
    5434:	eb01001f 	cmp	x0, x1
    5438:	54000102 	b.cs	5458 <fwp_main_thread+0x854>  // b.hs, b.nlast
    543c:	8b000294 	add	x20, x20, x0
    5440:	39400280 	ldrb	w0, [x20]
    5444:	340000a0 	cbz	w0, 5458 <fwp_main_thread+0x854>
    5448:	7103f41f 	cmp	w0, #0xfd
    544c:	54007e48 	b.hi	6414 <fwp_main_thread+0x1810>  // b.pmore
    5450:	11000400 	add	w0, w0, #0x1
    5454:	39000280 	strb	w0, [x20]
    5458:	f94017e0 	ldr	x0, [sp, #40]
    545c:	b4006f60 	cbz	x0, 6248 <fwp_main_thread+0x1644>
    5460:	aa0003e1 	mov	x1, x0
    5464:	d2800000 	mov	x0, #0x0                   	// #0
    5468:	f9400821 	ldr	x1, [x1, #16]
    546c:	91000400 	add	x0, x0, #0x1
    5470:	b5ffffc1 	cbnz	x1, 5468 <fwp_main_thread+0x864>
    5474:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5478:	eb01001f 	cmp	x0, x1
    547c:	54008788 	b.hi	656c <fwp_main_thread+0x1968>  // b.pmore
    5480:	97fff838 	bl	3560 <fwp_array_new_packed.constprop.0>
    5484:	aa0003f4 	mov	x20, x0
    5488:	91144261 	add	x1, x19, #0x510
    548c:	aa0103e0 	mov	x0, x1
    5490:	f949d821 	ldr	x1, [x1, #5040]
    5494:	f949ec00 	ldr	x0, [x0, #5080]
    5498:	cb010281 	sub	x1, x20, x1
    549c:	eb00403f 	cmp	x1, x0, lsl #16
    54a0:	54000382 	b.cs	5510 <fwp_main_thread+0x90c>  // b.hs, b.nlast
    54a4:	91144262 	add	x2, x19, #0x510
    54a8:	d350fc20 	lsr	x0, x1, #16
    54ac:	8b000800 	add	x0, x0, x0, lsl #2
    54b0:	f949fc43 	ldr	x3, [x2, #5112]
    54b4:	d37df002 	lsl	x2, x0, #3
    54b8:	8b020060 	add	x0, x3, x2
    54bc:	f9401015 	ldr	x21, [x0, #32]
    54c0:	b4000255 	cbz	x21, 5508 <fwp_main_thread+0x904>
    54c4:	38626862 	ldrb	w2, [x3, x2]
    54c8:	7100085f 	cmp	w2, #0x2
    54cc:	54006d60 	b.eq	6278 <fwp_main_thread+0x1674>  // b.none
    54d0:	7100045f 	cmp	w2, #0x1
    54d4:	540001a1 	b.ne	5508 <fwp_main_thread+0x904>  // b.any
    54d8:	29430002 	ldp	w2, w0, [x0, #24]
    54dc:	92403c21 	and	x1, x1, #0xffff
    54e0:	9b027c21 	mul	x1, x1, x2
    54e4:	d360fc21 	lsr	x1, x1, #32
    54e8:	eb00003f 	cmp	x1, x0
    54ec:	540000e2 	b.cs	5508 <fwp_main_thread+0x904>  // b.hs, b.nlast
    54f0:	8b0102b5 	add	x21, x21, x1
    54f4:	394002a0 	ldrb	w0, [x21]
    54f8:	7103fc1f 	cmp	w0, #0xff
    54fc:	54006c80 	b.eq	628c <fwp_main_thread+0x1688>  // b.none
    5500:	52800020 	mov	w0, #0x1                   	// #1
    5504:	390002a0 	strb	w0, [x21]
    5508:	f94017e0 	ldr	x0, [sp, #40]
    550c:	b4006b20 	cbz	x0, 6270 <fwp_main_thread+0x166c>
    5510:	f94017f5 	ldr	x21, [sp, #40]
    5514:	91002296 	add	x22, x20, #0x8
    5518:	91144277 	add	x23, x19, #0x510
    551c:	52800039 	mov	w25, #0x1                   	// #1
    5520:	aa1503e0 	mov	x0, x21
    5524:	14000013 	b	5570 <fwp_main_thread+0x96c>
    5528:	7100045f 	cmp	w2, #0x1
    552c:	54000161 	b.ne	5558 <fwp_main_thread+0x954>  // b.any
    5530:	294308e8 	ldp	w8, w2, [x7, #24]
    5534:	92403c21 	and	x1, x1, #0xffff
    5538:	9b087c21 	mul	x1, x1, x8
    553c:	d360fc21 	lsr	x1, x1, #32
    5540:	eb02003f 	cmp	x1, x2
    5544:	540000a2 	b.cs	5558 <fwp_main_thread+0x954>  // b.hs, b.nlast
    5548:	8b0100c6 	add	x6, x6, x1
    554c:	394000c1 	ldrb	w1, [x6]
    5550:	7100043f 	cmp	w1, #0x1
    5554:	540003e0 	b.eq	55d0 <fwp_main_thread+0x9cc>  // b.none
    5558:	f9400281 	ldr	x1, [x20]
    555c:	b7f87bc1 	tbnz	x1, #63, 64d4 <fwp_main_thread+0x18d0>
    5560:	f90002c4 	str	x4, [x22]
    5564:	52800019 	mov	w25, #0x0                   	// #0
    5568:	910022d6 	add	x22, x22, #0x8
    556c:	b4000775 	cbz	x21, 5658 <fwp_main_thread+0xa54>
    5570:	aa1503e5 	mov	x5, x21
    5574:	aa1503e3 	mov	x3, x21
    5578:	a940d6a4 	ldp	x4, x21, [x21, #8]
    557c:	34fffef9 	cbz	w25, 5558 <fwp_main_thread+0x954>
    5580:	f949dae1 	ldr	x1, [x23, #5040]
    5584:	f949eee2 	ldr	x2, [x23, #5080]
    5588:	cb0100a1 	sub	x1, x5, x1
    558c:	eb02403f 	cmp	x1, x2, lsl #16
    5590:	54fffe42 	b.cs	5558 <fwp_main_thread+0x954>  // b.hs, b.nlast
    5594:	d350fc22 	lsr	x2, x1, #16
    5598:	f949fee8 	ldr	x8, [x23, #5112]
    559c:	8b020842 	add	x2, x2, x2, lsl #2
    55a0:	d37df042 	lsl	x2, x2, #3
    55a4:	8b020107 	add	x7, x8, x2
    55a8:	f94010e6 	ldr	x6, [x7, #32]
    55ac:	b4fffd66 	cbz	x6, 5558 <fwp_main_thread+0x954>
    55b0:	38626902 	ldrb	w2, [x8, x2]
    55b4:	7100085f 	cmp	w2, #0x2
    55b8:	54fffb81 	b.ne	5528 <fwp_main_thread+0x924>  // b.any
    55bc:	72003c3f 	tst	w1, #0xffff
    55c0:	54fffcc1 	b.ne	5558 <fwp_main_thread+0x954>  // b.any
    55c4:	394000c1 	ldrb	w1, [x6]
    55c8:	7100043f 	cmp	w1, #0x1
    55cc:	54fffc61 	b.ne	5558 <fwp_main_thread+0x954>  // b.any
    55d0:	f9400280 	ldr	x0, [x20]
    55d4:	b7f87800 	tbnz	x0, #63, 64d4 <fwp_main_thread+0x18d0>
    55d8:	f90002c4 	str	x4, [x22]
    55dc:	f949dae1 	ldr	x1, [x23, #5040]
    55e0:	f949eee0 	ldr	x0, [x23, #5080]
    55e4:	cb010063 	sub	x3, x3, x1
    55e8:	eb00407f 	cmp	x3, x0, lsl #16
    55ec:	540002e2 	b.cs	5648 <fwp_main_thread+0xa44>  // b.hs, b.nlast
    55f0:	d350fc60 	lsr	x0, x3, #16
    55f4:	f949fee1 	ldr	x1, [x23, #5112]
    55f8:	8b000800 	add	x0, x0, x0, lsl #2
    55fc:	d37df000 	lsl	x0, x0, #3
    5600:	8b000024 	add	x4, x1, x0
    5604:	f9401082 	ldr	x2, [x4, #32]
    5608:	b4000202 	cbz	x2, 5648 <fwp_main_thread+0xa44>
    560c:	38606820 	ldrb	w0, [x1, x0]
    5610:	7100081f 	cmp	w0, #0x2
    5614:	54005ee0 	b.eq	61f0 <fwp_main_thread+0x15ec>  // b.none
    5618:	7100041f 	cmp	w0, #0x1
    561c:	54000161 	b.ne	5648 <fwp_main_thread+0xa44>  // b.any
    5620:	29430086 	ldp	w6, w0, [x4, #24]
    5624:	92403c61 	and	x1, x3, #0xffff
    5628:	9b067c21 	mul	x1, x1, x6
    562c:	d360fc21 	lsr	x1, x1, #32
    5630:	eb00003f 	cmp	x1, x0
    5634:	540000a2 	b.cs	5648 <fwp_main_thread+0xa44>  // b.hs, b.nlast
    5638:	8b010042 	add	x2, x2, x1
    563c:	39400040 	ldrb	w0, [x2]
    5640:	7100041f 	cmp	w0, #0x1
    5644:	540023e0 	b.eq	5ac0 <fwp_main_thread+0xebc>  // b.none
    5648:	aa1503e0 	mov	x0, x21
    564c:	d503201f 	nop
    5650:	910022d6 	add	x22, x22, #0x8
    5654:	b5fff8f5 	cbnz	x21, 5570 <fwp_main_thread+0x96c>
    5658:	d28018d7 	mov	x23, #0xc6                  	// #198
    565c:	97fff829 	bl	3700 <fwp_drop0>
    5660:	f9400296 	ldr	x22, [x20]
    5664:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    5668:	9240fad6 	and	x22, x22, #0x7fffffffffffffff
    566c:	eb0002df 	cmp	x22, x0
    5670:	540077e8 	b.hi	656c <fwp_main_thread+0x1968>  // b.pmore
    5674:	aa1603e0 	mov	x0, x22
    5678:	97fff7ba 	bl	3560 <fwp_array_new_packed.constprop.0>
    567c:	91144262 	add	x2, x19, #0x510
    5680:	aa0003f5 	mov	x21, x0
    5684:	f949d841 	ldr	x1, [x2, #5040]
    5688:	f949ec40 	ldr	x0, [x2, #5080]
    568c:	cb0102a1 	sub	x1, x21, x1
    5690:	eb00403f 	cmp	x1, x0, lsl #16
    5694:	54000322 	b.cs	56f8 <fwp_main_thread+0xaf4>  // b.hs, b.nlast
    5698:	d350fc20 	lsr	x0, x1, #16
    569c:	f949fc43 	ldr	x3, [x2, #5112]
    56a0:	8b000800 	add	x0, x0, x0, lsl #2
    56a4:	d37df002 	lsl	x2, x0, #3
    56a8:	8b020060 	add	x0, x3, x2
    56ac:	f9401019 	ldr	x25, [x0, #32]
    56b0:	b4000259 	cbz	x25, 56f8 <fwp_main_thread+0xaf4>
    56b4:	38626862 	ldrb	w2, [x3, x2]
    56b8:	7100085f 	cmp	w2, #0x2
    56bc:	54004dc0 	b.eq	6074 <fwp_main_thread+0x1470>  // b.none
    56c0:	7100045f 	cmp	w2, #0x1
    56c4:	540001a1 	b.ne	56f8 <fwp_main_thread+0xaf4>  // b.any
    56c8:	29430002 	ldp	w2, w0, [x0, #24]
    56cc:	92403c21 	and	x1, x1, #0xffff
    56d0:	9b027c21 	mul	x1, x1, x2
    56d4:	d360fc21 	lsr	x1, x1, #32
    56d8:	eb00003f 	cmp	x1, x0
    56dc:	540000e2 	b.cs	56f8 <fwp_main_thread+0xaf4>  // b.hs, b.nlast
    56e0:	8b010339 	add	x25, x25, x1
    56e4:	39400320 	ldrb	w0, [x25]
    56e8:	7103fc1f 	cmp	w0, #0xff
    56ec:	54004ce0 	b.eq	6088 <fwp_main_thread+0x1484>  // b.none
    56f0:	52800020 	mov	w0, #0x1                   	// #1
    56f4:	39000320 	strb	w0, [x25]
    56f8:	d280011b 	mov	x27, #0x8                   	// #8
    56fc:	2f00e408 	movi	d8, #0x0
    5700:	8b1b0299 	add	x25, x20, x27
    5704:	d280001c 	mov	x28, #0x0                   	// #0
    5708:	b5001a96 	cbnz	x22, 5a58 <fwp_main_thread+0xe54>
    570c:	1400011b 	b	5b78 <fwp_main_thread+0xf74>
    5710:	aa1903e0 	mov	x0, x25
    5714:	b7f84542 	tbnz	x2, #63, 5fbc <fwp_main_thread+0x13b8>
    5718:	fc7c780b 	ldr	d11, [x0, x28, lsl #3]
    571c:	9e6703ec 	fmov	d12, xzr
    5720:	b400027c 	cbz	x28, 576c <fwp_main_thread+0xb68>
    5724:	8b1b0000 	add	x0, x0, x27
    5728:	1e6e100c 	fmov	d12, #1.000000000000000000e+00
    572c:	fc5f0000 	ldur	d0, [x0, #-16]
    5730:	1e680802 	fmul	d2, d0, d8
    5734:	1e600801 	fmul	d1, d0, d0
    5738:	1e603980 	fsub	d0, d12, d0
    573c:	1e622842 	fadd	d2, d2, d2
    5740:	1e613961 	fsub	d1, d11, d1
    5744:	1e680800 	fmul	d0, d0, d8
    5748:	1e62398c 	fsub	d12, d12, d2
    574c:	1e610822 	fmul	d2, d1, d1
    5750:	1e602800 	fadd	d0, d0, d0
    5754:	1e61098c 	fmul	d12, d12, d1
    5758:	1e680841 	fmul	d1, d2, d8
    575c:	1e6c298c 	fadd	d12, d12, d12
    5760:	1e69098c 	fmul	d12, d12, d9
    5764:	1e61298c 	fadd	d12, d12, d1
    5768:	1e60298c 	fadd	d12, d12, d0
    576c:	9100079c 	add	x28, x28, #0x1
    5770:	eb1c003f 	cmp	x1, x28
    5774:	54001ae0 	b.eq	5ad0 <fwp_main_thread+0xecc>  // b.none
    5778:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    577c:	aa1803e1 	mov	x1, x24
    5780:	52800000 	mov	w0, #0x0                   	// #0
    5784:	f90063e2 	str	x2, [sp, #192]
    5788:	fd0067eb 	str	d11, [sp, #200]
    578c:	97fff72d 	bl	3440 <fwp_data.part.0.constprop.0>
    5790:	91144266 	add	x6, x19, #0x510
    5794:	aa0003fa 	mov	x26, x0
    5798:	f949d8c1 	ldr	x1, [x6, #5040]
    579c:	f949ecc0 	ldr	x0, [x6, #5080]
    57a0:	cb010341 	sub	x1, x26, x1
    57a4:	eb00403f 	cmp	x1, x0, lsl #16
    57a8:	54000322 	b.cs	580c <fwp_main_thread+0xc08>  // b.hs, b.nlast
    57ac:	d350fc22 	lsr	x2, x1, #16
    57b0:	f949fcc7 	ldr	x7, [x6, #5112]
    57b4:	8b020842 	add	x2, x2, x2, lsl #2
    57b8:	d37df042 	lsl	x2, x2, #3
    57bc:	8b0200e6 	add	x6, x7, x2
    57c0:	f94010c0 	ldr	x0, [x6, #32]
    57c4:	b4000240 	cbz	x0, 580c <fwp_main_thread+0xc08>
    57c8:	386268e2 	ldrb	w2, [x7, x2]
    57cc:	7100085f 	cmp	w2, #0x2
    57d0:	54001a00 	b.eq	5b10 <fwp_main_thread+0xf0c>  // b.none
    57d4:	7100045f 	cmp	w2, #0x1
    57d8:	540001a1 	b.ne	580c <fwp_main_thread+0xc08>  // b.any
    57dc:	294308c7 	ldp	w7, w2, [x6, #24]
    57e0:	92403c21 	and	x1, x1, #0xffff
    57e4:	9b077c21 	mul	x1, x1, x7
    57e8:	d360fc21 	lsr	x1, x1, #32
    57ec:	eb02003f 	cmp	x1, x2
    57f0:	540000e2 	b.cs	580c <fwp_main_thread+0xc08>  // b.hs, b.nlast
    57f4:	8b010000 	add	x0, x0, x1
    57f8:	39400001 	ldrb	w1, [x0]
    57fc:	7103fc3f 	cmp	w1, #0xff
    5800:	54001940 	b.eq	5b28 <fwp_main_thread+0xf24>  // b.none
    5804:	52800021 	mov	w1, #0x1                   	// #1
    5808:	39000001 	strb	w1, [x0]
    580c:	f9400280 	ldr	x0, [x20]
    5810:	9240f801 	and	x1, x0, #0x7fffffffffffffff
    5814:	eb1c003f 	cmp	x1, x28
    5818:	54001289 	b.ls	5a68 <fwp_main_thread+0xe64>  // b.plast
    581c:	aa1903e2 	mov	x2, x25
    5820:	b7f83d20 	tbnz	x0, #63, 5fc4 <fwp_main_thread+0x13c0>
    5824:	f87b6842 	ldr	x2, [x2, x27]
    5828:	9102c3e1 	add	x1, sp, #0xb0
    582c:	52800000 	mov	w0, #0x0                   	// #0
    5830:	a90b0bff 	stp	xzr, x2, [sp, #176]
    5834:	97fff703 	bl	3440 <fwp_data.part.0.constprop.0>
    5838:	aa0003e9 	mov	x9, x0
    583c:	91144268 	add	x8, x19, #0x510
    5840:	f949ed06 	ldr	x6, [x8, #5080]
    5844:	f949d901 	ldr	x1, [x8, #5040]
    5848:	d370bcc6 	lsl	x6, x6, #16
    584c:	cb010007 	sub	x7, x0, x1
    5850:	eb0600ff 	cmp	x7, x6
    5854:	540003e2 	b.cs	58d0 <fwp_main_thread+0xccc>  // b.hs, b.nlast
    5858:	d350fce2 	lsr	x2, x7, #16
    585c:	f949fd0b 	ldr	x11, [x8, #5112]
    5860:	8b020848 	add	x8, x2, x2, lsl #2
    5864:	d37df108 	lsl	x8, x8, #3
    5868:	8b08016a 	add	x10, x11, x8
    586c:	f9401140 	ldr	x0, [x10, #32]
    5870:	b40016e0 	cbz	x0, 5b4c <fwp_main_thread+0xf48>
    5874:	38686968 	ldrb	w8, [x11, x8]
    5878:	7100091f 	cmp	w8, #0x2
    587c:	54001640 	b.eq	5b44 <fwp_main_thread+0xf40>  // b.none
    5880:	7100051f 	cmp	w8, #0x1
    5884:	54001641 	b.ne	5b4c <fwp_main_thread+0xf48>  // b.any
    5888:	2943294b 	ldp	w11, w10, [x10, #24]
    588c:	92403ce8 	and	x8, x7, #0xffff
    5890:	9b0b7d08 	mul	x8, x8, x11
    5894:	d360fd08 	lsr	x8, x8, #32
    5898:	eb0a011f 	cmp	x8, x10
    589c:	54001582 	b.cs	5b4c <fwp_main_thread+0xf48>  // b.hs, b.nlast
    58a0:	8b080000 	add	x0, x0, x8
    58a4:	39400001 	ldrb	w1, [x0]
    58a8:	7103fc3f 	cmp	w1, #0xff
    58ac:	54003900 	b.eq	5fcc <fwp_main_thread+0x13c8>  // b.none
    58b0:	91144261 	add	x1, x19, #0x510
    58b4:	52800022 	mov	w2, #0x1                   	// #1
    58b8:	39000002 	strb	w2, [x0]
    58bc:	aa0103e0 	mov	x0, x1
    58c0:	f949d821 	ldr	x1, [x1, #5040]
    58c4:	f949ec06 	ldr	x6, [x0, #5080]
    58c8:	cb010127 	sub	x7, x9, x1
    58cc:	d370bcc6 	lsl	x6, x6, #16
    58d0:	fd400b44 	ldr	d4, [x26, #16]
    58d4:	d350fce2 	lsr	x2, x7, #16
    58d8:	fd400742 	ldr	d2, [x26, #8]
    58dc:	6d40b920 	ldp	d0, d14, [x9, #8]
    58e0:	1e64088f 	fmul	d15, d4, d4
    58e4:	1e640843 	fmul	d3, d2, d4
    58e8:	1e632863 	fadd	d3, d3, d3
    58ec:	1e63380d 	fsub	d13, d0, d3
    58f0:	eb0600ff 	cmp	x7, x6
    58f4:	54000462 	b.cs	5980 <fwp_main_thread+0xd7c>  // b.hs, b.nlast
    58f8:	91144260 	add	x0, x19, #0x510
    58fc:	8b020842 	add	x2, x2, x2, lsl #2
    5900:	d37df042 	lsl	x2, x2, #3
    5904:	f949fc0a 	ldr	x10, [x0, #5112]
    5908:	8b020148 	add	x8, x10, x2
    590c:	f9401100 	ldr	x0, [x8, #32]
    5910:	b4000380 	cbz	x0, 5980 <fwp_main_thread+0xd7c>
    5914:	38626942 	ldrb	w2, [x10, x2]
    5918:	7100085f 	cmp	w2, #0x2
    591c:	54001280 	b.eq	5b6c <fwp_main_thread+0xf68>  // b.none
    5920:	7100045f 	cmp	w2, #0x1
    5924:	540002e1 	b.ne	5980 <fwp_main_thread+0xd7c>  // b.any
    5928:	2943090a 	ldp	w10, w2, [x8, #24]
    592c:	92403ce7 	and	x7, x7, #0xffff
    5930:	9b0a7ce7 	mul	x7, x7, x10
    5934:	d360fce7 	lsr	x7, x7, #32
    5938:	eb0200ff 	cmp	x7, x2
    593c:	54000222 	b.cs	5980 <fwp_main_thread+0xd7c>  // b.hs, b.nlast
    5940:	8b070000 	add	x0, x0, x7
    5944:	39400002 	ldrb	w2, [x0]
    5948:	340001c2 	cbz	w2, 5980 <fwp_main_thread+0xd7c>
    594c:	7100045f 	cmp	w2, #0x1
    5950:	54000c40 	b.eq	5ad8 <fwp_main_thread+0xed4>  // b.none
    5954:	7103fc5f 	cmp	w2, #0xff
    5958:	54004180 	b.eq	6188 <fwp_main_thread+0x1584>  // b.none
    595c:	91144261 	add	x1, x19, #0x510
    5960:	51000442 	sub	w2, w2, #0x1
    5964:	39000002 	strb	w2, [x0]
    5968:	f949ec26 	ldr	x6, [x1, #5080]
    596c:	fd400b44 	ldr	d4, [x26, #16]
    5970:	f949d821 	ldr	x1, [x1, #5040]
    5974:	d370bcc6 	lsl	x6, x6, #16
    5978:	fd400742 	ldr	d2, [x26, #8]
    597c:	d503201f 	nop
    5980:	cb010341 	sub	x1, x26, x1
    5984:	1e6f39ce 	fsub	d14, d14, d15
    5988:	1e62390f 	fsub	d15, d8, d2
    598c:	eb06003f 	cmp	x1, x6
    5990:	540003c2 	b.cs	5a08 <fwp_main_thread+0xe04>  // b.hs, b.nlast
    5994:	91144262 	add	x2, x19, #0x510
    5998:	d350fc20 	lsr	x0, x1, #16
    599c:	8b000800 	add	x0, x0, x0, lsl #2
    59a0:	f949fc47 	ldr	x7, [x2, #5112]
    59a4:	d37df000 	lsl	x0, x0, #3
    59a8:	8b0000e6 	add	x6, x7, x0
    59ac:	f94010c2 	ldr	x2, [x6, #32]
    59b0:	b40002c2 	cbz	x2, 5a08 <fwp_main_thread+0xe04>
    59b4:	386068e0 	ldrb	w0, [x7, x0]
    59b8:	7100081f 	cmp	w0, #0x2
    59bc:	54000be0 	b.eq	5b38 <fwp_main_thread+0xf34>  // b.none
    59c0:	7100041f 	cmp	w0, #0x1
    59c4:	54000221 	b.ne	5a08 <fwp_main_thread+0xe04>  // b.any
    59c8:	294300c7 	ldp	w7, w0, [x6, #24]
    59cc:	92403c21 	and	x1, x1, #0xffff
    59d0:	9b077c21 	mul	x1, x1, x7
    59d4:	d360fc21 	lsr	x1, x1, #32
    59d8:	eb00003f 	cmp	x1, x0
    59dc:	54000162 	b.cs	5a08 <fwp_main_thread+0xe04>  // b.hs, b.nlast
    59e0:	8b010042 	add	x2, x2, x1
    59e4:	39400040 	ldrb	w0, [x2]
    59e8:	34000100 	cbz	w0, 5a08 <fwp_main_thread+0xe04>
    59ec:	7100041f 	cmp	w0, #0x1
    59f0:	54000860 	b.eq	5afc <fwp_main_thread+0xef8>  // b.none
    59f4:	7103fc1f 	cmp	w0, #0xff
    59f8:	54003940 	b.eq	6120 <fwp_main_thread+0x151c>  // b.none
    59fc:	51000400 	sub	w0, w0, #0x1
    5a00:	39000040 	strb	w0, [x2]
    5a04:	d503201f 	nop
    5a08:	1e6d09c0 	fmul	d0, d14, d13
    5a0c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5a10:	1e6e09ce 	fmul	d14, d14, d14
    5a14:	1e643821 	fsub	d1, d1, d4
    5a18:	1e602800 	fadd	d0, d0, d0
    5a1c:	1e6809ce 	fmul	d14, d14, d8
    5a20:	1e6f0821 	fmul	d1, d1, d15
    5a24:	1e690800 	fmul	d0, d0, d9
    5a28:	1e612821 	fadd	d1, d1, d1
    5a2c:	1e6e2800 	fadd	d0, d0, d14
    5a30:	1e612800 	fadd	d0, d0, d1
    5a34:	1e6c2800 	fadd	d0, d0, d12
    5a38:	f94002a0 	ldr	x0, [x21]
    5a3c:	1e6a0800 	fmul	d0, d0, d10
    5a40:	1e603960 	fsub	d0, d11, d0
    5a44:	b7f85480 	tbnz	x0, #63, 64d4 <fwp_main_thread+0x18d0>
    5a48:	fc3b6aa0 	str	d0, [x21, x27]
    5a4c:	9100237b 	add	x27, x27, #0x8
    5a50:	eb1c02df 	cmp	x22, x28
    5a54:	54000920 	b.eq	5b78 <fwp_main_thread+0xf74>  // b.none
    5a58:	f9400282 	ldr	x2, [x20]
    5a5c:	9240f841 	and	x1, x2, #0x7fffffffffffffff
    5a60:	eb1c003f 	cmp	x1, x28
    5a64:	54ffe568 	b.hi	5710 <fwp_main_thread+0xb0c>  // b.pmore
    5a68:	f00000c0 	adrp	x0, 20000 <__data_start>
    5a6c:	91004000 	add	x0, x0, #0x10
    5a70:	91002000 	add	x0, x0, #0x8
    5a74:	97fff18b 	bl	20a0 <fwp_trap>
    5a78:	72003c3f 	tst	w1, #0xffff
    5a7c:	54ffbb21 	b.ne	51e0 <fwp_main_thread+0x5dc>  // b.any
    5a80:	394002a0 	ldrb	w0, [x21]
    5a84:	7103fc1f 	cmp	w0, #0xff
    5a88:	54ffbaa1 	b.ne	51dc <fwp_main_thread+0x5d8>  // b.any
    5a8c:	aa1503e0 	mov	x0, x21
    5a90:	f90007e3 	str	x3, [sp, #8]
    5a94:	97fff444 	bl	2ba4 <fwp_rc_forget_slot>
    5a98:	f94007e3 	ldr	x3, [sp, #8]
    5a9c:	17fffdd0 	b	51dc <fwp_main_thread+0x5d8>
    5aa0:	97fff314 	bl	26f0 <fwp_heap_init>
    5aa4:	91144260 	add	x0, x19, #0x510
    5aa8:	b953a800 	ldr	w0, [x0, #5032]
    5aac:	34ff8ce0 	cbz	w0, 4c48 <fwp_main_thread+0x44>
    5ab0:	b0ffffe0 	adrp	x0, 2000 <fwp_cancel_tree.part.0+0x70>
    5ab4:	91161000 	add	x0, x0, #0x584
    5ab8:	94000886 	bl	7cd0 <atexit>
    5abc:	17fffc63 	b	4c48 <fwp_main_thread+0x44>
    5ac0:	aa0503e0 	mov	x0, x5
    5ac4:	97fff4d7 	bl	2e20 <fwp_mem_free>
    5ac8:	aa1503e0 	mov	x0, x21
    5acc:	17fffee1 	b	5650 <fwp_main_thread+0xa4c>
    5ad0:	2f00e400 	movi	d0, #0x0
    5ad4:	17ffffd8 	b	5a34 <fwp_main_thread+0xe30>
    5ad8:	aa0903e0 	mov	x0, x9
    5adc:	97fff5f1 	bl	32a0 <fwp_rc_free_arr>
    5ae0:	91144260 	add	x0, x19, #0x510
    5ae4:	fd400742 	ldr	d2, [x26, #8]
    5ae8:	fd400b44 	ldr	d4, [x26, #16]
    5aec:	f949ec06 	ldr	x6, [x0, #5080]
    5af0:	f949d801 	ldr	x1, [x0, #5040]
    5af4:	d370bcc6 	lsl	x6, x6, #16
    5af8:	17ffffa2 	b	5980 <fwp_main_thread+0xd7c>
    5afc:	aa1a03e0 	mov	x0, x26
    5b00:	fd0007e4 	str	d4, [sp, #8]
    5b04:	97fff5e7 	bl	32a0 <fwp_rc_free_arr>
    5b08:	fd4007e4 	ldr	d4, [sp, #8]
    5b0c:	17ffffbf 	b	5a08 <fwp_main_thread+0xe04>
    5b10:	72003c3f 	tst	w1, #0xffff
    5b14:	54ffe7c1 	b.ne	580c <fwp_main_thread+0xc08>  // b.any
    5b18:	39400001 	ldrb	w1, [x0]
    5b1c:	7103fc3f 	cmp	w1, #0xff
    5b20:	54ffe721 	b.ne	5804 <fwp_main_thread+0xc00>  // b.any
    5b24:	d503201f 	nop
    5b28:	f90007e0 	str	x0, [sp, #8]
    5b2c:	97fff41e 	bl	2ba4 <fwp_rc_forget_slot>
    5b30:	f94007e0 	ldr	x0, [sp, #8]
    5b34:	17ffff34 	b	5804 <fwp_main_thread+0xc00>
    5b38:	72003c3f 	tst	w1, #0xffff
    5b3c:	54fff661 	b.ne	5a08 <fwp_main_thread+0xe04>  // b.any
    5b40:	17ffffa9 	b	59e4 <fwp_main_thread+0xde0>
    5b44:	72003cff 	tst	w7, #0xffff
    5b48:	54ffeae0 	b.eq	58a4 <fwp_main_thread+0xca0>  // b.none
    5b4c:	fd400b44 	ldr	d4, [x26, #16]
    5b50:	fd400742 	ldr	d2, [x26, #8]
    5b54:	6d40b920 	ldp	d0, d14, [x9, #8]
    5b58:	1e64088f 	fmul	d15, d4, d4
    5b5c:	1e620883 	fmul	d3, d4, d2
    5b60:	1e632863 	fadd	d3, d3, d3
    5b64:	1e63380d 	fsub	d13, d0, d3
    5b68:	17ffff64 	b	58f8 <fwp_main_thread+0xcf4>
    5b6c:	72003cff 	tst	w7, #0xffff
    5b70:	54fff081 	b.ne	5980 <fwp_main_thread+0xd7c>  // b.any
    5b74:	17ffff74 	b	5944 <fwp_main_thread+0xd40>
    5b78:	91144276 	add	x22, x19, #0x510
    5b7c:	f949dac1 	ldr	x1, [x22, #5040]
    5b80:	f949eec0 	ldr	x0, [x22, #5080]
    5b84:	cb010281 	sub	x1, x20, x1
    5b88:	eb00403f 	cmp	x1, x0, lsl #16
    5b8c:	540003a2 	b.cs	5c00 <fwp_main_thread+0xffc>  // b.hs, b.nlast
    5b90:	d350fc20 	lsr	x0, x1, #16
    5b94:	f949fec4 	ldr	x4, [x22, #5112]
    5b98:	8b000800 	add	x0, x0, x0, lsl #2
    5b9c:	d37df000 	lsl	x0, x0, #3
    5ba0:	8b000082 	add	x2, x4, x0
    5ba4:	f9401059 	ldr	x25, [x2, #32]
    5ba8:	b40002d9 	cbz	x25, 5c00 <fwp_main_thread+0xffc>
    5bac:	38606883 	ldrb	w3, [x4, x0]
    5bb0:	7100087f 	cmp	w3, #0x2
    5bb4:	54002180 	b.eq	5fe4 <fwp_main_thread+0x13e0>  // b.none
    5bb8:	7100047f 	cmp	w3, #0x1
    5bbc:	54000221 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    5bc0:	29430843 	ldp	w3, w2, [x2, #24]
    5bc4:	92403c21 	and	x1, x1, #0xffff
    5bc8:	9b037c21 	mul	x1, x1, x3
    5bcc:	d360fc21 	lsr	x1, x1, #32
    5bd0:	eb02003f 	cmp	x1, x2
    5bd4:	54000162 	b.cs	5c00 <fwp_main_thread+0xffc>  // b.hs, b.nlast
    5bd8:	8b010339 	add	x25, x25, x1
    5bdc:	39400321 	ldrb	w1, [x25]
    5be0:	34000101 	cbz	w1, 5c00 <fwp_main_thread+0xffc>
    5be4:	7100043f 	cmp	w1, #0x1
    5be8:	54000160 	b.eq	5c14 <fwp_main_thread+0x1010>  // b.none
    5bec:	7103fc3f 	cmp	w1, #0xff
    5bf0:	54003540 	b.eq	6298 <fwp_main_thread+0x1694>  // b.none
    5bf4:	51000421 	sub	w1, w1, #0x1
    5bf8:	39000321 	strb	w1, [x25]
    5bfc:	d503201f 	nop
    5c00:	b40004d7 	cbz	x23, 5c98 <fwp_main_thread+0x1094>
    5c04:	f10006f7 	subs	x23, x23, #0x1
    5c08:	54004e86 	b.vs	65d8 <fwp_main_thread+0x19d4>
    5c0c:	aa1503f4 	mov	x20, x21
    5c10:	17fffe94 	b	5660 <fwp_main_thread+0xa5c>
    5c14:	f9400285 	ldr	x5, [x20]
    5c18:	aa1403e0 	mov	x0, x20
    5c1c:	f949eec3 	ldr	x3, [x22, #5080]
    5c20:	f949dac1 	ldr	x1, [x22, #5040]
    5c24:	d370bc63 	lsl	x3, x3, #16
    5c28:	cb010282 	sub	x2, x20, x1
    5c2c:	b7f81e25 	tbnz	x5, #63, 5ff0 <fwp_main_thread+0x13ec>
    5c30:	eb03005f 	cmp	x2, x3
    5c34:	54fffe62 	b.cs	5c00 <fwp_main_thread+0xffc>  // b.hs, b.nlast
    5c38:	d350fc40 	lsr	x0, x2, #16
    5c3c:	8b000800 	add	x0, x0, x0, lsl #2
    5c40:	d37df000 	lsl	x0, x0, #3
    5c44:	8b000083 	add	x3, x4, x0
    5c48:	f9401061 	ldr	x1, [x3, #32]
    5c4c:	b4fffda1 	cbz	x1, 5c00 <fwp_main_thread+0xffc>
    5c50:	38606880 	ldrb	w0, [x4, x0]
    5c54:	7100081f 	cmp	w0, #0x2
    5c58:	540021e0 	b.eq	6094 <fwp_main_thread+0x1490>  // b.none
    5c5c:	7100041f 	cmp	w0, #0x1
    5c60:	54fffd01 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    5c64:	92403c40 	and	x0, x2, #0xffff
    5c68:	29430864 	ldp	w4, w2, [x3, #24]
    5c6c:	9b047c00 	mul	x0, x0, x4
    5c70:	d360fc00 	lsr	x0, x0, #32
    5c74:	eb02001f 	cmp	x0, x2
    5c78:	54fffc42 	b.cs	5c00 <fwp_main_thread+0xffc>  // b.hs, b.nlast
    5c7c:	8b000021 	add	x1, x1, x0
    5c80:	39400020 	ldrb	w0, [x1]
    5c84:	7100041f 	cmp	w0, #0x1
    5c88:	54fffbc1 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    5c8c:	aa1403e0 	mov	x0, x20
    5c90:	97fff464 	bl	2e20 <fwp_mem_free>
    5c94:	b5fffb97 	cbnz	x23, 5c04 <fwp_main_thread+0x1000>
    5c98:	f9400be0 	ldr	x0, [sp, #16]
    5c9c:	52800b63 	mov	w3, #0x5b                  	// #91
    5ca0:	f94013e1 	ldr	x1, [sp, #32]
    5ca4:	d2800022 	mov	x2, #0x1                   	// #1
    5ca8:	390123e3 	strb	w3, [sp, #72]
    5cac:	d280001c 	mov	x28, #0x0                   	// #0
    5cb0:	a9067fff 	stp	xzr, xzr, [sp, #96]
    5cb4:	d00000d4 	adrp	x20, 1f000 <__FRAME_END__+0x160a0>
    5cb8:	f9003bff 	str	xzr, [sp, #112]
    5cbc:	97fff09d 	bl	1f30 <buf_put>
    5cc0:	f94002a0 	ldr	x0, [x21]
    5cc4:	f240f817 	ands	x23, x0, #0x7fffffffffffffff
    5cc8:	54000400 	b.eq	5d48 <fwp_main_thread+0x1144>  // b.none
    5ccc:	912ca294 	add	x20, x20, #0xb28
    5cd0:	d0000016 	adrp	x22, 7000 <fwp_main_thread+0x23fc>
    5cd4:	91014294 	add	x20, x20, #0x50
    5cd8:	913ee2d6 	add	x22, x22, #0xfb8
    5cdc:	910022b9 	add	x25, x21, #0x8
    5ce0:	1400000e 	b	5d18 <fwp_main_thread+0x1114>
    5ce4:	f87c7821 	ldr	x1, [x1, x28, lsl #3]
    5ce8:	aa1403e2 	mov	x2, x20
    5cec:	f9400bfa 	ldr	x26, [sp, #16]
    5cf0:	9100079c 	add	x28, x28, #0x1
    5cf4:	aa1a03e0 	mov	x0, x26
    5cf8:	97fff7da 	bl	3c60 <fwp_write.constprop.0>
    5cfc:	eb1c02ff 	cmp	x23, x28
    5d00:	54000240 	b.eq	5d48 <fwp_main_thread+0x1144>  // b.none
    5d04:	aa1a03e0 	mov	x0, x26
    5d08:	aa1603e1 	mov	x1, x22
    5d0c:	d2800042 	mov	x2, #0x2                   	// #2
    5d10:	97fff088 	bl	1f30 <buf_put>
    5d14:	f94002a0 	ldr	x0, [x21]
    5d18:	aa1903e1 	mov	x1, x25
    5d1c:	b6fffe40 	tbz	x0, #63, 5ce4 <fwp_main_thread+0x10e0>
    5d20:	f9400aa1 	ldr	x1, [x21, #16]
    5d24:	aa1403e2 	mov	x2, x20
    5d28:	f9400bfa 	ldr	x26, [sp, #16]
    5d2c:	f87c7821 	ldr	x1, [x1, x28, lsl #3]
    5d30:	aa1a03e0 	mov	x0, x26
    5d34:	9100079c 	add	x28, x28, #0x1
    5d38:	97fff7ca 	bl	3c60 <fwp_write.constprop.0>
    5d3c:	eb1c02ff 	cmp	x23, x28
    5d40:	54fffe21 	b.ne	5d04 <fwp_main_thread+0x1100>  // b.any
    5d44:	d503201f 	nop
    5d48:	f9400be0 	ldr	x0, [sp, #16]
    5d4c:	52800ba3 	mov	w3, #0x5d                  	// #93
    5d50:	f94013e1 	ldr	x1, [sp, #32]
    5d54:	d2800022 	mov	x2, #0x1                   	// #1
    5d58:	390123e3 	strb	w3, [sp, #72]
    5d5c:	97fff075 	bl	1f30 <buf_put>
    5d60:	a9465bf7 	ldp	x23, x22, [sp, #96]
    5d64:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    5d68:	913da000 	add	x0, x0, #0xf68
    5d6c:	f10002ff 	cmp	x23, #0x0
    5d70:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    5d74:	b1002adf 	cmn	x22, #0xa
    5d78:	54004228 	b.hi	65bc <fwp_main_thread+0x19b8>  // b.pmore
    5d7c:	910026c0 	add	x0, x22, #0x9
    5d80:	52800021 	mov	w1, #0x1                   	// #1
    5d84:	97fff568 	bl	3324 <fwp_heap_alloc>
    5d88:	aa0003f4 	mov	x20, x0
    5d8c:	aa1703e1 	mov	x1, x23
    5d90:	aa0003f7 	mov	x23, x0
    5d94:	aa1603e2 	mov	x2, x22
    5d98:	f80086f6 	str	x22, [x23], #8
    5d9c:	8b160296 	add	x22, x20, x22
    5da0:	aa1703e0 	mov	x0, x23
    5da4:	97ffed57 	bl	1300 <memcpy@plt>
    5da8:	390022df 	strb	wzr, [x22, #8]
    5dac:	f94033e0 	ldr	x0, [sp, #96]
    5db0:	97ffedec 	bl	1560 <free@plt>
    5db4:	91144262 	add	x2, x19, #0x510
    5db8:	f949ec43 	ldr	x3, [x2, #5080]
    5dbc:	f949d841 	ldr	x1, [x2, #5040]
    5dc0:	d370bc63 	lsl	x3, x3, #16
    5dc4:	cb010284 	sub	x4, x20, x1
    5dc8:	eb03009f 	cmp	x4, x3
    5dcc:	540003a2 	b.cs	5e40 <fwp_main_thread+0x123c>  // b.hs, b.nlast
    5dd0:	d350fc80 	lsr	x0, x4, #16
    5dd4:	f949fc45 	ldr	x5, [x2, #5112]
    5dd8:	8b000800 	add	x0, x0, x0, lsl #2
    5ddc:	d37df002 	lsl	x2, x0, #3
    5de0:	8b0200a0 	add	x0, x5, x2
    5de4:	f9401016 	ldr	x22, [x0, #32]
    5de8:	b40002d6 	cbz	x22, 5e40 <fwp_main_thread+0x123c>
    5dec:	386268a2 	ldrb	w2, [x5, x2]
    5df0:	7100085f 	cmp	w2, #0x2
    5df4:	540027e0 	b.eq	62f0 <fwp_main_thread+0x16ec>  // b.none
    5df8:	7100045f 	cmp	w2, #0x1
    5dfc:	54000221 	b.ne	5e40 <fwp_main_thread+0x123c>  // b.any
    5e00:	29430005 	ldp	w5, w0, [x0, #24]
    5e04:	92403c82 	and	x2, x4, #0xffff
    5e08:	9b057c42 	mul	x2, x2, x5
    5e0c:	d360fc42 	lsr	x2, x2, #32
    5e10:	eb00005f 	cmp	x2, x0
    5e14:	54000162 	b.cs	5e40 <fwp_main_thread+0x123c>  // b.hs, b.nlast
    5e18:	8b0202d6 	add	x22, x22, x2
    5e1c:	394002c0 	ldrb	w0, [x22]
    5e20:	7103fc1f 	cmp	w0, #0xff
    5e24:	54002700 	b.eq	6304 <fwp_main_thread+0x1700>  // b.none
    5e28:	91144260 	add	x0, x19, #0x510
    5e2c:	52800021 	mov	w1, #0x1                   	// #1
    5e30:	390002c1 	strb	w1, [x22]
    5e34:	f949ec03 	ldr	x3, [x0, #5080]
    5e38:	f949d801 	ldr	x1, [x0, #5040]
    5e3c:	d370bc63 	lsl	x3, x3, #16
    5e40:	cb0102a1 	sub	x1, x21, x1
    5e44:	91144279 	add	x25, x19, #0x510
    5e48:	eb03003f 	cmp	x1, x3
    5e4c:	540003a2 	b.cs	5ec0 <fwp_main_thread+0x12bc>  // b.hs, b.nlast
    5e50:	d350fc20 	lsr	x0, x1, #16
    5e54:	f949ff23 	ldr	x3, [x25, #5112]
    5e58:	8b000800 	add	x0, x0, x0, lsl #2
    5e5c:	d37df002 	lsl	x2, x0, #3
    5e60:	8b020060 	add	x0, x3, x2
    5e64:	f9401016 	ldr	x22, [x0, #32]
    5e68:	b40002d6 	cbz	x22, 5ec0 <fwp_main_thread+0x12bc>
    5e6c:	38626862 	ldrb	w2, [x3, x2]
    5e70:	7100085f 	cmp	w2, #0x2
    5e74:	54001c60 	b.eq	6200 <fwp_main_thread+0x15fc>  // b.none
    5e78:	7100045f 	cmp	w2, #0x1
    5e7c:	54000221 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    5e80:	29430002 	ldp	w2, w0, [x0, #24]
    5e84:	92403c21 	and	x1, x1, #0xffff
    5e88:	9b027c21 	mul	x1, x1, x2
    5e8c:	d360fc21 	lsr	x1, x1, #32
    5e90:	eb00003f 	cmp	x1, x0
    5e94:	54000162 	b.cs	5ec0 <fwp_main_thread+0x12bc>  // b.hs, b.nlast
    5e98:	8b0102d6 	add	x22, x22, x1
    5e9c:	394002c0 	ldrb	w0, [x22]
    5ea0:	34000100 	cbz	w0, 5ec0 <fwp_main_thread+0x12bc>
    5ea4:	7100041f 	cmp	w0, #0x1
    5ea8:	54000fc0 	b.eq	60a0 <fwp_main_thread+0x149c>  // b.none
    5eac:	7103fc1f 	cmp	w0, #0xff
    5eb0:	54002860 	b.eq	63bc <fwp_main_thread+0x17b8>  // b.none
    5eb4:	51000400 	sub	w0, w0, #0x1
    5eb8:	390002c0 	strb	w0, [x22]
    5ebc:	d503201f 	nop
    5ec0:	f00000c1 	adrp	x1, 20000 <__data_start>
    5ec4:	aa1703e0 	mov	x0, x23
    5ec8:	f9400282 	ldr	x2, [x20]
    5ecc:	f9403823 	ldr	x3, [x1, #112]
    5ed0:	d2800021 	mov	x1, #0x1                   	// #1
    5ed4:	97ffedb3 	bl	15a0 <fwrite@plt>
    5ed8:	f00000c0 	adrp	x0, 20000 <__data_start>
    5edc:	f9403801 	ldr	x1, [x0, #112]
    5ee0:	52800140 	mov	w0, #0xa                   	// #10
    5ee4:	97ffed37 	bl	13c0 <fputc@plt>
    5ee8:	91144262 	add	x2, x19, #0x510
    5eec:	f949d841 	ldr	x1, [x2, #5040]
    5ef0:	f949ec40 	ldr	x0, [x2, #5080]
    5ef4:	cb010281 	sub	x1, x20, x1
    5ef8:	eb00403f 	cmp	x1, x0, lsl #16
    5efc:	540003a2 	b.cs	5f70 <fwp_main_thread+0x136c>  // b.hs, b.nlast
    5f00:	d350fc20 	lsr	x0, x1, #16
    5f04:	f949fc43 	ldr	x3, [x2, #5112]
    5f08:	8b000800 	add	x0, x0, x0, lsl #2
    5f0c:	d37df002 	lsl	x2, x0, #3
    5f10:	8b020060 	add	x0, x3, x2
    5f14:	f9401015 	ldr	x21, [x0, #32]
    5f18:	b40002d5 	cbz	x21, 5f70 <fwp_main_thread+0x136c>
    5f1c:	38626862 	ldrb	w2, [x3, x2]
    5f20:	7100085f 	cmp	w2, #0x2
    5f24:	54001f60 	b.eq	6310 <fwp_main_thread+0x170c>  // b.none
    5f28:	7100045f 	cmp	w2, #0x1
    5f2c:	54000221 	b.ne	5f70 <fwp_main_thread+0x136c>  // b.any
    5f30:	29430002 	ldp	w2, w0, [x0, #24]
    5f34:	92403c21 	and	x1, x1, #0xffff
    5f38:	9b027c21 	mul	x1, x1, x2
    5f3c:	d360fc21 	lsr	x1, x1, #32
    5f40:	eb00003f 	cmp	x1, x0
    5f44:	54000162 	b.cs	5f70 <fwp_main_thread+0x136c>  // b.hs, b.nlast
    5f48:	8b0102b5 	add	x21, x21, x1
    5f4c:	394002a0 	ldrb	w0, [x21]
    5f50:	34000100 	cbz	w0, 5f70 <fwp_main_thread+0x136c>
    5f54:	7100041f 	cmp	w0, #0x1
    5f58:	54001460 	b.eq	61e4 <fwp_main_thread+0x15e0>  // b.none
    5f5c:	7103fc1f 	cmp	w0, #0xff
    5f60:	540028e0 	b.eq	647c <fwp_main_thread+0x1878>  // b.none
    5f64:	51000400 	sub	w0, w0, #0x1
    5f68:	390002a0 	strb	w0, [x21]
    5f6c:	d503201f 	nop
    5f70:	f9401fe0 	ldr	x0, [sp, #56]
    5f74:	f9400800 	ldr	x0, [x0, #16]
    5f78:	f9001fe0 	str	x0, [sp, #56]
    5f7c:	b5ffa2e0 	cbnz	x0, 53d8 <fwp_main_thread+0x7d4>
    5f80:	f94017e0 	ldr	x0, [sp, #40]
    5f84:	97fff5df 	bl	3700 <fwp_drop0>
    5f88:	f9400fe0 	ldr	x0, [sp, #24]
    5f8c:	97fff5dd 	bl	3700 <fwp_drop0>
    5f90:	f00000c0 	adrp	x0, 20000 <__data_start>
    5f94:	9101c000 	add	x0, x0, #0x70
    5f98:	a95a6bf9 	ldp	x25, x26, [sp, #416]
    5f9c:	52800021 	mov	w1, #0x1                   	// #1
    5fa0:	6d5c27e8 	ldp	d8, d9, [sp, #448]
    5fa4:	6d5d2fea 	ldp	d10, d11, [sp, #464]
    5fa8:	6d5e37ec 	ldp	d12, d13, [sp, #480]
    5fac:	6d5f3fee 	ldp	d14, d15, [sp, #496]
    5fb0:	b9029401 	str	w1, [x0, #660]
    5fb4:	f9014c1f 	str	xzr, [x0, #664]
    5fb8:	17fffb53 	b	4d04 <fwp_main_thread+0x100>
    5fbc:	f9400a80 	ldr	x0, [x20, #16]
    5fc0:	17fffdd6 	b	5718 <fwp_main_thread+0xb14>
    5fc4:	f9400a82 	ldr	x2, [x20, #16]
    5fc8:	17fffe17 	b	5824 <fwp_main_thread+0xc20>
    5fcc:	f90007e0 	str	x0, [sp, #8]
    5fd0:	f9001be9 	str	x9, [sp, #48]
    5fd4:	97fff2f4 	bl	2ba4 <fwp_rc_forget_slot>
    5fd8:	f94007e0 	ldr	x0, [sp, #8]
    5fdc:	f9401be9 	ldr	x9, [sp, #48]
    5fe0:	17fffe34 	b	58b0 <fwp_main_thread+0xcac>
    5fe4:	72003c3f 	tst	w1, #0xffff
    5fe8:	54ffe0c1 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    5fec:	17fffefc 	b	5bdc <fwp_main_thread+0xfd8>
    5ff0:	f9400694 	ldr	x20, [x20, #8]
    5ff4:	eb03005f 	cmp	x2, x3
    5ff8:	54000362 	b.cs	6064 <fwp_main_thread+0x1460>  // b.hs, b.nlast
    5ffc:	d350fc45 	lsr	x5, x2, #16
    6000:	8b0508a5 	add	x5, x5, x5, lsl #2
    6004:	d37df0a5 	lsl	x5, x5, #3
    6008:	8b050087 	add	x7, x4, x5
    600c:	f94010e6 	ldr	x6, [x7, #32]
    6010:	b40002a6 	cbz	x6, 6064 <fwp_main_thread+0x1460>
    6014:	38656884 	ldrb	w4, [x4, x5]
    6018:	7100089f 	cmp	w4, #0x2
    601c:	54000de0 	b.eq	61d8 <fwp_main_thread+0x15d4>  // b.none
    6020:	7100049f 	cmp	w4, #0x1
    6024:	54000201 	b.ne	6064 <fwp_main_thread+0x1460>  // b.any
    6028:	294310e5 	ldp	w5, w4, [x7, #24]
    602c:	92403c42 	and	x2, x2, #0xffff
    6030:	9b057c42 	mul	x2, x2, x5
    6034:	d360fc42 	lsr	x2, x2, #32
    6038:	eb04005f 	cmp	x2, x4
    603c:	54000142 	b.cs	6064 <fwp_main_thread+0x1460>  // b.hs, b.nlast
    6040:	8b0200c6 	add	x6, x6, x2
    6044:	394000c2 	ldrb	w2, [x6]
    6048:	7100045f 	cmp	w2, #0x1
    604c:	540000c1 	b.ne	6064 <fwp_main_thread+0x1460>  // b.any
    6050:	97fff374 	bl	2e20 <fwp_mem_free>
    6054:	91144260 	add	x0, x19, #0x510
    6058:	f949ec03 	ldr	x3, [x0, #5080]
    605c:	f949d801 	ldr	x1, [x0, #5040]
    6060:	d370bc63 	lsl	x3, x3, #16
    6064:	cb010281 	sub	x1, x20, x1
    6068:	eb01007f 	cmp	x3, x1
    606c:	54ffd928 	b.hi	5b90 <fwp_main_thread+0xf8c>  // b.pmore
    6070:	17fffee4 	b	5c00 <fwp_main_thread+0xffc>
    6074:	72003c3f 	tst	w1, #0xffff
    6078:	54ffb401 	b.ne	56f8 <fwp_main_thread+0xaf4>  // b.any
    607c:	39400320 	ldrb	w0, [x25]
    6080:	7103fc1f 	cmp	w0, #0xff
    6084:	54ffb361 	b.ne	56f0 <fwp_main_thread+0xaec>  // b.any
    6088:	aa1903e0 	mov	x0, x25
    608c:	97fff2c6 	bl	2ba4 <fwp_rc_forget_slot>
    6090:	17fffd98 	b	56f0 <fwp_main_thread+0xaec>
    6094:	72003c5f 	tst	w2, #0xffff
    6098:	54ffdb41 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    609c:	17fffef9 	b	5c80 <fwp_main_thread+0x107c>
    60a0:	f94002a0 	ldr	x0, [x21]
    60a4:	b7f80b40 	tbnz	x0, #63, 620c <fwp_main_thread+0x1608>
    60a8:	91144261 	add	x1, x19, #0x510
    60ac:	f949d820 	ldr	x0, [x1, #5040]
    60b0:	f949ec21 	ldr	x1, [x1, #5080]
    60b4:	cb0002a0 	sub	x0, x21, x0
    60b8:	eb01401f 	cmp	x0, x1, lsl #16
    60bc:	54fff022 	b.cs	5ec0 <fwp_main_thread+0x12bc>  // b.hs, b.nlast
    60c0:	d350fc01 	lsr	x1, x0, #16
    60c4:	8b010821 	add	x1, x1, x1, lsl #2
    60c8:	d37df021 	lsl	x1, x1, #3
    60cc:	8b010064 	add	x4, x3, x1
    60d0:	f9401082 	ldr	x2, [x4, #32]
    60d4:	b4ffef62 	cbz	x2, 5ec0 <fwp_main_thread+0x12bc>
    60d8:	38616861 	ldrb	w1, [x3, x1]
    60dc:	7100083f 	cmp	w1, #0x2
    60e0:	540011e0 	b.eq	631c <fwp_main_thread+0x1718>  // b.none
    60e4:	7100043f 	cmp	w1, #0x1
    60e8:	54ffeec1 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    60ec:	29430483 	ldp	w3, w1, [x4, #24]
    60f0:	92403c00 	and	x0, x0, #0xffff
    60f4:	9b037c00 	mul	x0, x0, x3
    60f8:	d360fc00 	lsr	x0, x0, #32
    60fc:	eb01001f 	cmp	x0, x1
    6100:	54ffee02 	b.cs	5ec0 <fwp_main_thread+0x12bc>  // b.hs, b.nlast
    6104:	8b000042 	add	x2, x2, x0
    6108:	39400040 	ldrb	w0, [x2]
    610c:	7100041f 	cmp	w0, #0x1
    6110:	54ffed81 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    6114:	aa1503e0 	mov	x0, x21
    6118:	97fff342 	bl	2e20 <fwp_mem_free>
    611c:	17ffff69 	b	5ec0 <fwp_main_thread+0x12bc>
    6120:	ca424440 	eor	x0, x2, x2, lsr #17
    6124:	91144261 	add	x1, x19, #0x510
    6128:	ca402400 	eor	x0, x0, x0, lsr #9
    612c:	8b200c20 	add	x0, x1, w0, uxtb #3
    6130:	f94a2400 	ldr	x0, [x0, #5192]
    6134:	b5000080 	cbnz	x0, 6144 <fwp_main_thread+0x1540>
    6138:	140000ec 	b	64e8 <fwp_main_thread+0x18e4>
    613c:	f9400800 	ldr	x0, [x0, #16]
    6140:	b4001d40 	cbz	x0, 64e8 <fwp_main_thread+0x18e4>
    6144:	f9400001 	ldr	x1, [x0]
    6148:	eb01005f 	cmp	x2, x1
    614c:	54ffff81 	b.ne	613c <fwp_main_thread+0x1538>  // b.any
    6150:	f9400401 	ldr	x1, [x0, #8]
    6154:	d1000421 	sub	x1, x1, #0x1
    6158:	f9000401 	str	x1, [x0, #8]
    615c:	f103f83f 	cmp	x1, #0xfe
    6160:	54ffc541 	b.ne	5a08 <fwp_main_thread+0xe04>  // b.any
    6164:	aa0203e0 	mov	x0, x2
    6168:	f90007e2 	str	x2, [sp, #8]
    616c:	fd001be4 	str	d4, [sp, #48]
    6170:	97fff28d 	bl	2ba4 <fwp_rc_forget_slot>
    6174:	f94007e2 	ldr	x2, [sp, #8]
    6178:	12800020 	mov	w0, #0xfffffffe            	// #-2
    617c:	fd401be4 	ldr	d4, [sp, #48]
    6180:	39000040 	strb	w0, [x2]
    6184:	17fffe21 	b	5a08 <fwp_main_thread+0xe04>
    6188:	ca404402 	eor	x2, x0, x0, lsr #17
    618c:	91144267 	add	x7, x19, #0x510
    6190:	ca422442 	eor	x2, x2, x2, lsr #9
    6194:	8b220ce2 	add	x2, x7, w2, uxtb #3
    6198:	f94a2442 	ldr	x2, [x2, #5192]
    619c:	b5000082 	cbnz	x2, 61ac <fwp_main_thread+0x15a8>
    61a0:	140000d2 	b	64e8 <fwp_main_thread+0x18e4>
    61a4:	f9400842 	ldr	x2, [x2, #16]
    61a8:	b4001a02 	cbz	x2, 64e8 <fwp_main_thread+0x18e4>
    61ac:	f9400047 	ldr	x7, [x2]
    61b0:	eb0000ff 	cmp	x7, x0
    61b4:	54ffff81 	b.ne	61a4 <fwp_main_thread+0x15a0>  // b.any
    61b8:	f9400447 	ldr	x7, [x2, #8]
    61bc:	d10004e7 	sub	x7, x7, #0x1
    61c0:	f9000447 	str	x7, [x2, #8]
    61c4:	f103f8ff 	cmp	x7, #0xfe
    61c8:	54000b00 	b.eq	6328 <fwp_main_thread+0x1724>  // b.none
    61cc:	fd400742 	ldr	d2, [x26, #8]
    61d0:	fd400b44 	ldr	d4, [x26, #16]
    61d4:	17fffdeb 	b	5980 <fwp_main_thread+0xd7c>
    61d8:	72003c5f 	tst	w2, #0xffff
    61dc:	54fff441 	b.ne	6064 <fwp_main_thread+0x1460>  // b.any
    61e0:	17ffff99 	b	6044 <fwp_main_thread+0x1440>
    61e4:	aa1403e0 	mov	x0, x20
    61e8:	97fff42e 	bl	32a0 <fwp_rc_free_arr>
    61ec:	17ffff61 	b	5f70 <fwp_main_thread+0x136c>
    61f0:	72003c7f 	tst	w3, #0xffff
    61f4:	54ffa240 	b.eq	563c <fwp_main_thread+0xa38>  // b.none
    61f8:	aa1503e0 	mov	x0, x21
    61fc:	17fffd15 	b	5650 <fwp_main_thread+0xa4c>
    6200:	72003c3f 	tst	w1, #0xffff
    6204:	54ffe5e1 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    6208:	17ffff25 	b	5e9c <fwp_main_thread+0x1298>
    620c:	f94006b6 	ldr	x22, [x21, #8]
    6210:	aa1503e0 	mov	x0, x21
    6214:	97fff423 	bl	32a0 <fwp_rc_free_arr>
    6218:	91144260 	add	x0, x19, #0x510
    621c:	f949d801 	ldr	x1, [x0, #5040]
    6220:	f949ec00 	ldr	x0, [x0, #5080]
    6224:	cb0102c1 	sub	x1, x22, x1
    6228:	eb00403f 	cmp	x1, x0, lsl #16
    622c:	54ffe4a2 	b.cs	5ec0 <fwp_main_thread+0x12bc>  // b.hs, b.nlast
    6230:	aa1603f5 	mov	x21, x22
    6234:	17ffff07 	b	5e50 <fwp_main_thread+0x124c>
    6238:	72003c1f 	tst	w0, #0xffff
    623c:	54ff9020 	b.eq	5440 <fwp_main_thread+0x83c>  // b.none
    6240:	f94017e0 	ldr	x0, [sp, #40]
    6244:	b5ff90e0 	cbnz	x0, 5460 <fwp_main_thread+0x85c>
    6248:	d2800000 	mov	x0, #0x0                   	// #0
    624c:	97fff4c5 	bl	3560 <fwp_array_new_packed.constprop.0>
    6250:	91144261 	add	x1, x19, #0x510
    6254:	aa0003f4 	mov	x20, x0
    6258:	aa0103e0 	mov	x0, x1
    625c:	f949d821 	ldr	x1, [x1, #5040]
    6260:	f949ec00 	ldr	x0, [x0, #5080]
    6264:	cb010281 	sub	x1, x20, x1
    6268:	eb00403f 	cmp	x1, x0, lsl #16
    626c:	54ff91c3 	b.cc	54a4 <fwp_main_thread+0x8a0>  // b.lo, b.ul, b.last
    6270:	d2800000 	mov	x0, #0x0                   	// #0
    6274:	17fffcf9 	b	5658 <fwp_main_thread+0xa54>
    6278:	72003c3f 	tst	w1, #0xffff
    627c:	54ff9461 	b.ne	5508 <fwp_main_thread+0x904>  // b.any
    6280:	394002a0 	ldrb	w0, [x21]
    6284:	7103fc1f 	cmp	w0, #0xff
    6288:	54ff93c1 	b.ne	5500 <fwp_main_thread+0x8fc>  // b.any
    628c:	aa1503e0 	mov	x0, x21
    6290:	97fff245 	bl	2ba4 <fwp_rc_forget_slot>
    6294:	17fffc9b 	b	5500 <fwp_main_thread+0x8fc>
    6298:	ca594720 	eor	x0, x25, x25, lsr #17
    629c:	91144261 	add	x1, x19, #0x510
    62a0:	ca402400 	eor	x0, x0, x0, lsr #9
    62a4:	8b200c20 	add	x0, x1, w0, uxtb #3
    62a8:	f94a2401 	ldr	x1, [x0, #5192]
    62ac:	b5000081 	cbnz	x1, 62bc <fwp_main_thread+0x16b8>
    62b0:	1400008e 	b	64e8 <fwp_main_thread+0x18e4>
    62b4:	f9400821 	ldr	x1, [x1, #16]
    62b8:	b4001181 	cbz	x1, 64e8 <fwp_main_thread+0x18e4>
    62bc:	f9400020 	ldr	x0, [x1]
    62c0:	eb19001f 	cmp	x0, x25
    62c4:	54ffff81 	b.ne	62b4 <fwp_main_thread+0x16b0>  // b.any
    62c8:	f9400420 	ldr	x0, [x1, #8]
    62cc:	d1000400 	sub	x0, x0, #0x1
    62d0:	f9000420 	str	x0, [x1, #8]
    62d4:	f103f81f 	cmp	x0, #0xfe
    62d8:	54ffc941 	b.ne	5c00 <fwp_main_thread+0xffc>  // b.any
    62dc:	aa1903e0 	mov	x0, x25
    62e0:	97fff231 	bl	2ba4 <fwp_rc_forget_slot>
    62e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62e8:	39000320 	strb	w0, [x25]
    62ec:	17fffe45 	b	5c00 <fwp_main_thread+0xffc>
    62f0:	72003c9f 	tst	w4, #0xffff
    62f4:	54ffda61 	b.ne	5e40 <fwp_main_thread+0x123c>  // b.any
    62f8:	394002c0 	ldrb	w0, [x22]
    62fc:	7103fc1f 	cmp	w0, #0xff
    6300:	54ffd941 	b.ne	5e28 <fwp_main_thread+0x1224>  // b.any
    6304:	aa1603e0 	mov	x0, x22
    6308:	97fff227 	bl	2ba4 <fwp_rc_forget_slot>
    630c:	17fffec7 	b	5e28 <fwp_main_thread+0x1224>
    6310:	72003c3f 	tst	w1, #0xffff
    6314:	54ffe2e1 	b.ne	5f70 <fwp_main_thread+0x136c>  // b.any
    6318:	17ffff0d 	b	5f4c <fwp_main_thread+0x1348>
    631c:	72003c1f 	tst	w0, #0xffff
    6320:	54ffdd01 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    6324:	17ffff79 	b	6108 <fwp_main_thread+0x1504>
    6328:	f90007e0 	str	x0, [sp, #8]
    632c:	97fff21e 	bl	2ba4 <fwp_rc_forget_slot>
    6330:	f94007e0 	ldr	x0, [sp, #8]
    6334:	91144261 	add	x1, x19, #0x510
    6338:	12800022 	mov	w2, #0xfffffffe            	// #-2
    633c:	17fffd8a 	b	5964 <fwp_main_thread+0xd60>
    6340:	d2800013 	mov	x19, #0x0                   	// #0
    6344:	17fffab0 	b	4e04 <fwp_main_thread+0x200>
    6348:	72003c3f 	tst	w1, #0xffff
    634c:	54ff8381 	b.ne	53bc <fwp_main_thread+0x7b8>  // b.any
    6350:	17fffc16 	b	53a8 <fwp_main_thread+0x7a4>
    6354:	72003c3f 	tst	w1, #0xffff
    6358:	54ff7e61 	b.ne	5324 <fwp_main_thread+0x720>  // b.any
    635c:	17fffbed 	b	5310 <fwp_main_thread+0x70c>
    6360:	72003c3f 	tst	w1, #0xffff
    6364:	54ff7981 	b.ne	5294 <fwp_main_thread+0x690>  // b.any
    6368:	17fffbc6 	b	5280 <fwp_main_thread+0x67c>
    636c:	aa0003e1 	mov	x1, x0
    6370:	f9002293 	str	x19, [x20, #64]
    6374:	17fffa7d 	b	4d68 <fwp_main_thread+0x164>
    6378:	f9413a80 	ldr	x0, [x20, #624]
    637c:	97fff2a9 	bl	2e20 <fwp_mem_free>
    6380:	f9013a9f 	str	xzr, [x20, #624]
    6384:	f901429f 	str	xzr, [x20, #640]
    6388:	f9415680 	ldr	x0, [x20, #680]
    638c:	b4000c13 	cbz	x19, 650c <fwp_main_thread+0x1908>
    6390:	f900567f 	str	xzr, [x19, #168]
    6394:	f9005e7f 	str	xzr, [x19, #184]
    6398:	b902a29f 	str	wzr, [x20, #672]
    639c:	eb00027f 	cmp	x19, x0
    63a0:	54ff5480 	b.eq	4e30 <fwp_main_thread+0x22c>  // b.none
    63a4:	a91a6bf9 	stp	x25, x26, [sp, #416]
    63a8:	6d1c27e8 	stp	d8, d9, [sp, #448]
    63ac:	6d1d2fea 	stp	d10, d11, [sp, #464]
    63b0:	6d1e37ec 	stp	d12, d13, [sp, #480]
    63b4:	6d1f3fee 	stp	d14, d15, [sp, #496]
    63b8:	97ffec4e 	bl	14f0 <abort@plt>
    63bc:	ca5646c0 	eor	x0, x22, x22, lsr #17
    63c0:	91144261 	add	x1, x19, #0x510
    63c4:	ca402400 	eor	x0, x0, x0, lsr #9
    63c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    63cc:	f94a2400 	ldr	x0, [x0, #5192]
    63d0:	b5000080 	cbnz	x0, 63e0 <fwp_main_thread+0x17dc>
    63d4:	14000045 	b	64e8 <fwp_main_thread+0x18e4>
    63d8:	f9400800 	ldr	x0, [x0, #16]
    63dc:	b4000860 	cbz	x0, 64e8 <fwp_main_thread+0x18e4>
    63e0:	f9400001 	ldr	x1, [x0]
    63e4:	eb16003f 	cmp	x1, x22
    63e8:	54ffff81 	b.ne	63d8 <fwp_main_thread+0x17d4>  // b.any
    63ec:	f9400401 	ldr	x1, [x0, #8]
    63f0:	d1000421 	sub	x1, x1, #0x1
    63f4:	f9000401 	str	x1, [x0, #8]
    63f8:	f103f83f 	cmp	x1, #0xfe
    63fc:	54ffd621 	b.ne	5ec0 <fwp_main_thread+0x12bc>  // b.any
    6400:	aa1603e0 	mov	x0, x22
    6404:	97fff1e8 	bl	2ba4 <fwp_rc_forget_slot>
    6408:	12800020 	mov	w0, #0xfffffffe            	// #-2
    640c:	390002c0 	strb	w0, [x22]
    6410:	17fffeac 	b	5ec0 <fwp_main_thread+0x12bc>
    6414:	ca544681 	eor	x1, x20, x20, lsr #17
    6418:	91144262 	add	x2, x19, #0x510
    641c:	ca412421 	eor	x1, x1, x1, lsr #9
    6420:	92401c21 	and	x1, x1, #0xff
    6424:	910a2423 	add	x3, x1, #0x289
    6428:	8b010c41 	add	x1, x2, x1, lsl #3
    642c:	8b030c55 	add	x21, x2, x3, lsl #3
    6430:	f94a2421 	ldr	x1, [x1, #5192]
    6434:	b50000a1 	cbnz	x1, 6448 <fwp_main_thread+0x1844>
    6438:	14000050 	b	6578 <fwp_main_thread+0x1974>
    643c:	91004035 	add	x21, x1, #0x10
    6440:	f9400821 	ldr	x1, [x1, #16]
    6444:	b40004e1 	cbz	x1, 64e0 <fwp_main_thread+0x18dc>
    6448:	f9400022 	ldr	x2, [x1]
    644c:	eb02029f 	cmp	x20, x2
    6450:	54ffff61 	b.ne	643c <fwp_main_thread+0x1838>  // b.any
    6454:	f94002a1 	ldr	x1, [x21]
    6458:	7103f81f 	cmp	w0, #0xfe
    645c:	54000800 	b.eq	655c <fwp_main_thread+0x1958>  // b.none
    6460:	b4000441 	cbz	x1, 64e8 <fwp_main_thread+0x18e4>
    6464:	f9400420 	ldr	x0, [x1, #8]
    6468:	b100041f 	cmn	x0, #0x1
    646c:	54000ae0 	b.eq	65c8 <fwp_main_thread+0x19c4>  // b.none
    6470:	91000400 	add	x0, x0, #0x1
    6474:	f9000420 	str	x0, [x1, #8]
    6478:	17fffbf8 	b	5458 <fwp_main_thread+0x854>
    647c:	ca5546a0 	eor	x0, x21, x21, lsr #17
    6480:	91144261 	add	x1, x19, #0x510
    6484:	ca402400 	eor	x0, x0, x0, lsr #9
    6488:	8b200c20 	add	x0, x1, w0, uxtb #3
    648c:	f94a2400 	ldr	x0, [x0, #5192]
    6490:	b5000080 	cbnz	x0, 64a0 <fwp_main_thread+0x189c>
    6494:	14000015 	b	64e8 <fwp_main_thread+0x18e4>
    6498:	f9400800 	ldr	x0, [x0, #16]
    649c:	b4000260 	cbz	x0, 64e8 <fwp_main_thread+0x18e4>
    64a0:	f9400001 	ldr	x1, [x0]
    64a4:	eb15003f 	cmp	x1, x21
    64a8:	54ffff81 	b.ne	6498 <fwp_main_thread+0x1894>  // b.any
    64ac:	f9400401 	ldr	x1, [x0, #8]
    64b0:	d1000421 	sub	x1, x1, #0x1
    64b4:	f9000401 	str	x1, [x0, #8]
    64b8:	f103f83f 	cmp	x1, #0xfe
    64bc:	54ffd5a1 	b.ne	5f70 <fwp_main_thread+0x136c>  // b.any
    64c0:	aa1503e0 	mov	x0, x21
    64c4:	97fff1b8 	bl	2ba4 <fwp_rc_forget_slot>
    64c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64cc:	390002a0 	strb	w0, [x21]
    64d0:	17fffea8 	b	5f70 <fwp_main_thread+0x136c>
    64d4:	d0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    64d8:	9101c000 	add	x0, x0, #0x70
    64dc:	97ffeef1 	bl	20a0 <fwp_trap>
    64e0:	7103f81f 	cmp	w0, #0xfe
    64e4:	54000200 	b.eq	6524 <fwp_main_thread+0x1920>  // b.none
    64e8:	b0000000 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    64ec:	913b2000 	add	x0, x0, #0xec8
    64f0:	97ffeeec 	bl	20a0 <fwp_trap>
    64f4:	aa1403e0 	mov	x0, x20
    64f8:	97fff1ab 	bl	2ba4 <fwp_rc_forget_slot>
    64fc:	17fffbae 	b	53b4 <fwp_main_thread+0x7b0>
    6500:	aa1503e0 	mov	x0, x21
    6504:	97fff1a8 	bl	2ba4 <fwp_rc_forget_slot>
    6508:	17fffb61 	b	528c <fwp_main_thread+0x688>
    650c:	b902a29f 	str	wzr, [x20, #672]
    6510:	b4ff4d80 	cbz	x0, 4ec0 <fwp_main_thread+0x2bc>
    6514:	17ffffa4 	b	63a4 <fwp_main_thread+0x17a0>
    6518:	aa1503e0 	mov	x0, x21
    651c:	97fff1a2 	bl	2ba4 <fwp_rc_forget_slot>
    6520:	17fffb7f 	b	531c <fwp_main_thread+0x718>
    6524:	d2800300 	mov	x0, #0x18                  	// #24
    6528:	97ffebc6 	bl	1440 <malloc@plt>
    652c:	b4000540 	cbz	x0, 65d4 <fwp_main_thread+0x19d0>
    6530:	d2801fe1 	mov	x1, #0xff                  	// #255
    6534:	a9000414 	stp	x20, x1, [x0]
    6538:	91144261 	add	x1, x19, #0x510
    653c:	f900081f 	str	xzr, [x0, #16]
    6540:	12800002 	mov	w2, #0xffffffff            	// #-1
    6544:	f90002a0 	str	x0, [x21]
    6548:	39000282 	strb	w2, [x20]
    654c:	f94e2420 	ldr	x0, [x1, #7240]
    6550:	91000400 	add	x0, x0, #0x1
    6554:	f90e2420 	str	x0, [x1, #7240]
    6558:	17fffbc0 	b	5458 <fwp_main_thread+0x854>
    655c:	b4fffe41 	cbz	x1, 6524 <fwp_main_thread+0x1920>
    6560:	d0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    6564:	9100a000 	add	x0, x0, #0x28
    6568:	97ffeece 	bl	20a0 <fwp_trap>
    656c:	b0000000 	adrp	x0, 7000 <fwp_main_thread+0x23fc>
    6570:	913bc000 	add	x0, x0, #0xef0
    6574:	97ffeecb 	bl	20a0 <fwp_trap>
    6578:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    657c:	17ffffb7 	b	6458 <fwp_main_thread+0x1854>
    6580:	d0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    6584:	91000000 	add	x0, x0, #0x0
    6588:	a91a6bf9 	stp	x25, x26, [sp, #416]
    658c:	a91b73fb 	stp	x27, x28, [sp, #432]
    6590:	6d1c27e8 	stp	d8, d9, [sp, #448]
    6594:	6d1d2fea 	stp	d10, d11, [sp, #464]
    6598:	6d1e37ec 	stp	d12, d13, [sp, #480]
    659c:	6d1f3fee 	stp	d14, d15, [sp, #496]
    65a0:	97ffeec0 	bl	20a0 <fwp_trap>
    65a4:	a91a6bf9 	stp	x25, x26, [sp, #416]
    65a8:	6d1c27e8 	stp	d8, d9, [sp, #448]
    65ac:	6d1d2fea 	stp	d10, d11, [sp, #464]
    65b0:	6d1e37ec 	stp	d12, d13, [sp, #480]
    65b4:	6d1f3fee 	stp	d14, d15, [sp, #496]
    65b8:	97ffebba 	bl	14a0 <__stack_chk_fail@plt>
    65bc:	d0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    65c0:	91026000 	add	x0, x0, #0x98
    65c4:	97ffeeb7 	bl	20a0 <fwp_trap>
    65c8:	d0000000 	adrp	x0, 8000 <_IO_stdin_used+0x300>
    65cc:	91014000 	add	x0, x0, #0x50
    65d0:	97ffeeb4 	bl	20a0 <fwp_trap>
    65d4:	97ffed6f 	bl	1b90 <fwp_heap_oom>
    65d8:	97ffec2a 	bl	1680 <fwp_trap_overflow.constprop.0>
    65dc:	d503201f 	nop
    65e0:	14000400 	b	75e0 <__divti3>
    65e4:	d503201f 	nop
    65e8:	f9400001 	ldr	x1, [x0]
    65ec:	17fffa87 	b	5008 <fwp_main_thread+0x404>
	...

00000000000075e0 <__divti3>:
    75e0:	d503245f 	bti	c
    75e4:	d2800004 	mov	x4, #0x0                   	// #0
    75e8:	b7f80721 	tbnz	x1, #63, 76cc <__divti3+0xec>
    75ec:	b6f80083 	tbz	x3, #63, 75fc <__divti3+0x1c>
    75f0:	eb0203e2 	negs	x2, x2
    75f4:	aa2403e4 	mvn	x4, x4
    75f8:	da0303e3 	ngc	x3, x3
    75fc:	aa0203e6 	mov	x6, x2
    7600:	aa0003e7 	mov	x7, x0
    7604:	aa0103e5 	mov	x5, x1
    7608:	b5000583 	cbnz	x3, 76b8 <__divti3+0xd8>
    760c:	eb01005f 	cmp	x2, x1
    7610:	54000e69 	b.ls	77dc <__divti3+0x1fc>  // b.plast
    7614:	dac01040 	clz	x0, x2
    7618:	b40000e0 	cbz	x0, 7634 <__divti3+0x54>
    761c:	4b0003e1 	neg	w1, w0
    7620:	9ac020a5 	lsl	x5, x5, x0
    7624:	9ac02046 	lsl	x6, x2, x0
    7628:	9ac124e1 	lsr	x1, x7, x1
    762c:	aa050025 	orr	x5, x1, x5
    7630:	9ac020e7 	lsl	x7, x7, x0
    7634:	d360fcc8 	lsr	x8, x6, #32
    7638:	92407cc2 	and	x2, x6, #0xffffffff
    763c:	9ac808a3 	udiv	x3, x5, x8
    7640:	9b089465 	msub	x5, x3, x8, x5
    7644:	aa0303e0 	mov	x0, x3
    7648:	9b037c41 	mul	x1, x2, x3
    764c:	93c780a5 	extr	x5, x5, x7, #32
    7650:	eb05003f 	cmp	x1, x5
    7654:	540000a9 	b.ls	7668 <__divti3+0x88>  // b.plast
    7658:	ab0500c5 	adds	x5, x6, x5
    765c:	d1000460 	sub	x0, x3, #0x1
    7660:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    7664:	540015a8 	b.hi	7918 <__divti3+0x338>  // b.pmore
    7668:	cb0100a5 	sub	x5, x5, x1
    766c:	9ac808a3 	udiv	x3, x5, x8
    7670:	9b089465 	msub	x5, x3, x8, x5
    7674:	aa0303e1 	mov	x1, x3
    7678:	9b037c42 	mul	x2, x2, x3
    767c:	aa0703e3 	mov	x3, x7
    7680:	b3607ca3 	bfi	x3, x5, #32, #32
    7684:	eb03005f 	cmp	x2, x3
    7688:	540000c9 	b.ls	76a0 <__divti3+0xc0>  // b.plast
    768c:	ab0300c3 	adds	x3, x6, x3
    7690:	d1000425 	sub	x5, x1, #0x1
    7694:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    7698:	d1000821 	sub	x1, x1, #0x2
    769c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    76a0:	aa008020 	orr	x0, x1, x0, lsl #32
    76a4:	d2800001 	mov	x1, #0x0                   	// #0
    76a8:	b4000064 	cbz	x4, 76b4 <__divti3+0xd4>
    76ac:	eb0003e0 	negs	x0, x0
    76b0:	da0103e1 	ngc	x1, x1
    76b4:	d65f03c0 	ret
    76b8:	eb01007f 	cmp	x3, x1
    76bc:	54000109 	b.ls	76dc <__divti3+0xfc>  // b.plast
    76c0:	d2800001 	mov	x1, #0x0                   	// #0
    76c4:	d2800000 	mov	x0, #0x0                   	// #0
    76c8:	17fffff8 	b	76a8 <__divti3+0xc8>
    76cc:	eb0003e0 	negs	x0, x0
    76d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    76d4:	da0103e1 	ngc	x1, x1
    76d8:	17ffffc5 	b	75ec <__divti3+0xc>
    76dc:	dac01067 	clz	x7, x3
    76e0:	b40010e7 	cbz	x7, 78fc <__divti3+0x31c>
    76e4:	d2800805 	mov	x5, #0x40                  	// #64
    76e8:	cb0700a5 	sub	x5, x5, x7
    76ec:	9ac72063 	lsl	x3, x3, x7
    76f0:	9ac52448 	lsr	x8, x2, x5
    76f4:	aa030108 	orr	x8, x8, x3
    76f8:	9ac52426 	lsr	x6, x1, x5
    76fc:	92407d0a 	and	x10, x8, #0xffffffff
    7700:	d360fd09 	lsr	x9, x8, #32
    7704:	9ac52403 	lsr	x3, x0, x5
    7708:	9ac72021 	lsl	x1, x1, x7
    770c:	aa010063 	orr	x3, x3, x1
    7710:	9ac72042 	lsl	x2, x2, x7
    7714:	9ac908cb 	udiv	x11, x6, x9
    7718:	9b099965 	msub	x5, x11, x9, x6
    771c:	aa0b03e1 	mov	x1, x11
    7720:	9b0b7d46 	mul	x6, x10, x11
    7724:	93c380a5 	extr	x5, x5, x3, #32
    7728:	eb0500df 	cmp	x6, x5
    772c:	540000a9 	b.ls	7740 <__divti3+0x160>  // b.plast
    7730:	ab050105 	adds	x5, x8, x5
    7734:	d1000561 	sub	x1, x11, #0x1
    7738:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    773c:	54000f48 	b.hi	7924 <__divti3+0x344>  // b.pmore
    7740:	cb0600a6 	sub	x6, x5, x6
    7744:	9ac908cb 	udiv	x11, x6, x9
    7748:	9b099969 	msub	x9, x11, x9, x6
    774c:	aa0b03e5 	mov	x5, x11
    7750:	9b0b7d4a 	mul	x10, x10, x11
    7754:	b3607d23 	bfi	x3, x9, #32, #32
    7758:	eb03015f 	cmp	x10, x3
    775c:	540000a9 	b.ls	7770 <__divti3+0x190>  // b.plast
    7760:	ab030103 	adds	x3, x8, x3
    7764:	d1000565 	sub	x5, x11, #0x1
    7768:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    776c:	54000e28 	b.hi	7930 <__divti3+0x350>  // b.pmore
    7770:	aa0180a1 	orr	x1, x5, x1, lsl #32
    7774:	92407c48 	and	x8, x2, #0xffffffff
    7778:	2a0503e5 	mov	w5, w5
    777c:	d360fc42 	lsr	x2, x2, #32
    7780:	d360fc26 	lsr	x6, x1, #32
    7784:	cb0a0063 	sub	x3, x3, x10
    7788:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    778c:	9b087caa 	mul	x10, x5, x8
    7790:	9b087cc8 	mul	x8, x6, x8
    7794:	9b0220a5 	madd	x5, x5, x2, x8
    7798:	9b027cc6 	mul	x6, x6, x2
    779c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    77a0:	8b0900c5 	add	x5, x6, x9
    77a4:	eb02011f 	cmp	x8, x2
    77a8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    77ac:	8b4280c6 	add	x6, x6, x2, lsr #32
    77b0:	eb06007f 	cmp	x3, x6
    77b4:	540000e3 	b.cc	77d0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    77b8:	92407d4a 	and	x10, x10, #0xffffffff
    77bc:	9ac72000 	lsl	x0, x0, x7
    77c0:	8b028142 	add	x2, x10, x2, lsl #32
    77c4:	eb02001f 	cmp	x0, x2
    77c8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    77cc:	54000a01 	b.ne	790c <__divti3+0x32c>  // b.any
    77d0:	d1000420 	sub	x0, x1, #0x1
    77d4:	d2800001 	mov	x1, #0x0                   	// #0
    77d8:	17ffffb4 	b	76a8 <__divti3+0xc8>
    77dc:	b5000062 	cbnz	x2, 77e8 <__divti3+0x208>
    77e0:	d2800022 	mov	x2, #0x1                   	// #1
    77e4:	9ac30846 	udiv	x6, x2, x3
    77e8:	dac010c8 	clz	x8, x6
    77ec:	b5000408 	cbnz	x8, 786c <__divti3+0x28c>
    77f0:	d360fcc9 	lsr	x9, x6, #32
    77f4:	92407cc5 	and	x5, x6, #0xffffffff
    77f8:	cb060023 	sub	x3, x1, x6
    77fc:	d2800021 	mov	x1, #0x1                   	// #1
    7800:	9ac90868 	udiv	x8, x3, x9
    7804:	9b098d03 	msub	x3, x8, x9, x3
    7808:	aa0803e0 	mov	x0, x8
    780c:	9b057d02 	mul	x2, x8, x5
    7810:	93c78063 	extr	x3, x3, x7, #32
    7814:	eb03005f 	cmp	x2, x3
    7818:	540000a9 	b.ls	782c <__divti3+0x24c>  // b.plast
    781c:	ab0300c3 	adds	x3, x6, x3
    7820:	d1000500 	sub	x0, x8, #0x1
    7824:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    7828:	54000968 	b.hi	7954 <__divti3+0x374>  // b.pmore
    782c:	cb020063 	sub	x3, x3, x2
    7830:	9ac90862 	udiv	x2, x3, x9
    7834:	aa0203e8 	mov	x8, x2
    7838:	9b098c42 	msub	x2, x2, x9, x3
    783c:	aa0703e3 	mov	x3, x7
    7840:	9b057d05 	mul	x5, x8, x5
    7844:	b3607c43 	bfi	x3, x2, #32, #32
    7848:	eb0300bf 	cmp	x5, x3
    784c:	540000c9 	b.ls	7864 <__divti3+0x284>  // b.plast
    7850:	ab0300c2 	adds	x2, x6, x3
    7854:	d1000503 	sub	x3, x8, #0x1
    7858:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    785c:	d1000908 	sub	x8, x8, #0x2
    7860:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    7864:	aa008100 	orr	x0, x8, x0, lsl #32
    7868:	17ffff90 	b	76a8 <__divti3+0xc8>
    786c:	9ac820c6 	lsl	x6, x6, x8
    7870:	d2800803 	mov	x3, #0x40                  	// #64
    7874:	cb080063 	sub	x3, x3, x8
    7878:	d360fcc9 	lsr	x9, x6, #32
    787c:	9ac82027 	lsl	x7, x1, x8
    7880:	92407cc5 	and	x5, x6, #0xffffffff
    7884:	9ac32422 	lsr	x2, x1, x3
    7888:	9ac32403 	lsr	x3, x0, x3
    788c:	aa070063 	orr	x3, x3, x7
    7890:	9ac9084a 	udiv	x10, x2, x9
    7894:	9ac82007 	lsl	x7, x0, x8
    7898:	9b098940 	msub	x0, x10, x9, x2
    789c:	aa0a03e1 	mov	x1, x10
    78a0:	9b0a7ca2 	mul	x2, x5, x10
    78a4:	93c38000 	extr	x0, x0, x3, #32
    78a8:	eb00005f 	cmp	x2, x0
    78ac:	540000a9 	b.ls	78c0 <__divti3+0x2e0>  // b.plast
    78b0:	ab0000c0 	adds	x0, x6, x0
    78b4:	d1000541 	sub	x1, x10, #0x1
    78b8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    78bc:	54000468 	b.hi	7948 <__divti3+0x368>  // b.pmore
    78c0:	cb020000 	sub	x0, x0, x2
    78c4:	9ac9080a 	udiv	x10, x0, x9
    78c8:	9b098140 	msub	x0, x10, x9, x0
    78cc:	aa0a03e2 	mov	x2, x10
    78d0:	9b0a7ca8 	mul	x8, x5, x10
    78d4:	b3607c03 	bfi	x3, x0, #32, #32
    78d8:	eb03011f 	cmp	x8, x3
    78dc:	540000a9 	b.ls	78f0 <__divti3+0x310>  // b.plast
    78e0:	ab0300c3 	adds	x3, x6, x3
    78e4:	d1000542 	sub	x2, x10, #0x1
    78e8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    78ec:	54000288 	b.hi	793c <__divti3+0x35c>  // b.pmore
    78f0:	cb080063 	sub	x3, x3, x8
    78f4:	aa018041 	orr	x1, x2, x1, lsl #32
    78f8:	17ffffc2 	b	7800 <__divti3+0x220>
    78fc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    7900:	d2800001 	mov	x1, #0x0                   	// #0
    7904:	9a9f87e0 	cset	x0, ls	// ls = plast
    7908:	17ffff68 	b	76a8 <__divti3+0xc8>
    790c:	aa0103e0 	mov	x0, x1
    7910:	d2800001 	mov	x1, #0x0                   	// #0
    7914:	17ffff65 	b	76a8 <__divti3+0xc8>
    7918:	d1000860 	sub	x0, x3, #0x2
    791c:	8b0600a5 	add	x5, x5, x6
    7920:	17ffff52 	b	7668 <__divti3+0x88>
    7924:	d1000961 	sub	x1, x11, #0x2
    7928:	8b0800a5 	add	x5, x5, x8
    792c:	17ffff85 	b	7740 <__divti3+0x160>
    7930:	d1000965 	sub	x5, x11, #0x2
    7934:	8b080063 	add	x3, x3, x8
    7938:	17ffff8e 	b	7770 <__divti3+0x190>
    793c:	d1000942 	sub	x2, x10, #0x2
    7940:	8b060063 	add	x3, x3, x6
    7944:	17ffffeb 	b	78f0 <__divti3+0x310>
    7948:	d1000941 	sub	x1, x10, #0x2
    794c:	8b060000 	add	x0, x0, x6
    7950:	17ffffdc 	b	78c0 <__divti3+0x2e0>
    7954:	d1000900 	sub	x0, x8, #0x2
    7958:	8b060063 	add	x3, x3, x6
    795c:	17ffffb4 	b	782c <__divti3+0x24c>

0000000000007960 <__modti3>:
    7960:	d503245f 	bti	c
    7964:	d2800004 	mov	x4, #0x0                   	// #0
    7968:	b6f80081 	tbz	x1, #63, 7978 <__modti3+0x18>
    796c:	eb0003e0 	negs	x0, x0
    7970:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7974:	da0103e1 	ngc	x1, x1
    7978:	f100007f 	cmp	x3, #0x0
    797c:	5400128b 	b.lt	7bcc <__modti3+0x26c>  // b.tstop
    7980:	aa0003e7 	mov	x7, x0
    7984:	aa0103e6 	mov	x6, x1
    7988:	540004e1 	b.ne	7a24 <__modti3+0xc4>  // b.any
    798c:	eb02003f 	cmp	x1, x2
    7990:	54000dc2 	b.cs	7b48 <__modti3+0x1e8>  // b.hs, b.nlast
    7994:	dac01043 	clz	x3, x2
    7998:	aa0303e5 	mov	x5, x3
    799c:	b40000e3 	cbz	x3, 79b8 <__modti3+0x58>
    79a0:	4b0303e6 	neg	w6, w3
    79a4:	9ac32021 	lsl	x1, x1, x3
    79a8:	9ac32042 	lsl	x2, x2, x3
    79ac:	9ac62406 	lsr	x6, x0, x6
    79b0:	aa0100c6 	orr	x6, x6, x1
    79b4:	9ac32007 	lsl	x7, x0, x3
    79b8:	d360fc40 	lsr	x0, x2, #32
    79bc:	92407c43 	and	x3, x2, #0xffffffff
    79c0:	9ac008c1 	udiv	x1, x6, x0
    79c4:	9b009826 	msub	x6, x1, x0, x6
    79c8:	9b017c61 	mul	x1, x3, x1
    79cc:	93c780c6 	extr	x6, x6, x7, #32
    79d0:	eb06003f 	cmp	x1, x6
    79d4:	540000a9 	b.ls	79e8 <__modti3+0x88>  // b.plast
    79d8:	ab060046 	adds	x6, x2, x6
    79dc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    79e0:	8b0200c8 	add	x8, x6, x2
    79e4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    79e8:	cb0100c6 	sub	x6, x6, x1
    79ec:	9ac008c8 	udiv	x8, x6, x0
    79f0:	9b009901 	msub	x1, x8, x0, x6
    79f4:	aa0703e0 	mov	x0, x7
    79f8:	9b087c63 	mul	x3, x3, x8
    79fc:	b3607c20 	bfi	x0, x1, #32, #32
    7a00:	eb00007f 	cmp	x3, x0
    7a04:	54001088 	b.hi	7c14 <__modti3+0x2b4>  // b.pmore
    7a08:	cb030000 	sub	x0, x0, x3
    7a0c:	9ac52400 	lsr	x0, x0, x5
    7a10:	d2800001 	mov	x1, #0x0                   	// #0
    7a14:	b4000064 	cbz	x4, 7a20 <__modti3+0xc0>
    7a18:	eb0003e0 	negs	x0, x0
    7a1c:	da0103e1 	ngc	x1, x1
    7a20:	d65f03c0 	ret
    7a24:	dac01066 	clz	x6, x3
    7a28:	eb03003f 	cmp	x1, x3
    7a2c:	54ffff43 	b.cc	7a14 <__modti3+0xb4>  // b.lo, b.ul, b.last
    7a30:	93407cc5 	sxtw	x5, w6
    7a34:	d2800808 	mov	x8, #0x40                  	// #64
    7a38:	cb050108 	sub	x8, x8, x5
    7a3c:	9ac62063 	lsl	x3, x3, x6
    7a40:	9ac62025 	lsl	x5, x1, x6
    7a44:	9ac82447 	lsr	x7, x2, x8
    7a48:	aa0300e7 	orr	x7, x7, x3
    7a4c:	9ac82423 	lsr	x3, x1, x8
    7a50:	92407cec 	and	x12, x7, #0xffffffff
    7a54:	d360fcea 	lsr	x10, x7, #32
    7a58:	9ac82401 	lsr	x1, x0, x8
    7a5c:	aa050021 	orr	x1, x1, x5
    7a60:	9ac62042 	lsl	x2, x2, x6
    7a64:	9ac62000 	lsl	x0, x0, x6
    7a68:	9aca086b 	udiv	x11, x3, x10
    7a6c:	9b0a8d63 	msub	x3, x11, x10, x3
    7a70:	aa0b03e5 	mov	x5, x11
    7a74:	9b0b7d89 	mul	x9, x12, x11
    7a78:	93c18063 	extr	x3, x3, x1, #32
    7a7c:	eb03013f 	cmp	x9, x3
    7a80:	540000a9 	b.ls	7a94 <__modti3+0x134>  // b.plast
    7a84:	ab0300e3 	adds	x3, x7, x3
    7a88:	d1000565 	sub	x5, x11, #0x1
    7a8c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    7a90:	54001168 	b.hi	7cbc <__modti3+0x35c>  // b.pmore
    7a94:	cb090063 	sub	x3, x3, x9
    7a98:	9aca086b 	udiv	x11, x3, x10
    7a9c:	9b0a8d6a 	msub	x10, x11, x10, x3
    7aa0:	aa0b03e9 	mov	x9, x11
    7aa4:	9b0b7d8c 	mul	x12, x12, x11
    7aa8:	b3607d41 	bfi	x1, x10, #32, #32
    7aac:	eb01019f 	cmp	x12, x1
    7ab0:	540000a9 	b.ls	7ac4 <__modti3+0x164>  // b.plast
    7ab4:	ab0100e1 	adds	x1, x7, x1
    7ab8:	d1000569 	sub	x9, x11, #0x1
    7abc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    7ac0:	54000f88 	b.hi	7cb0 <__modti3+0x350>  // b.pmore
    7ac4:	aa058123 	orr	x3, x9, x5, lsl #32
    7ac8:	92407c4b 	and	x11, x2, #0xffffffff
    7acc:	2a0903e9 	mov	w9, w9
    7ad0:	d360fc4a 	lsr	x10, x2, #32
    7ad4:	d360fc63 	lsr	x3, x3, #32
    7ad8:	cb0c0021 	sub	x1, x1, x12
    7adc:	aa0a03ec 	mov	x12, x10
    7ae0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    7ae4:	9b0b7d25 	mul	x5, x9, x11
    7ae8:	9b0b7c6b 	mul	x11, x3, x11
    7aec:	9b0a2d29 	madd	x9, x9, x10, x11
    7af0:	92407caa 	and	x10, x5, #0xffffffff
    7af4:	9b0c7c63 	mul	x3, x3, x12
    7af8:	8b458125 	add	x5, x9, x5, lsr #32
    7afc:	8b0d0069 	add	x9, x3, x13
    7b00:	eb05017f 	cmp	x11, x5
    7b04:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    7b08:	8b058149 	add	x9, x10, x5, lsl #32
    7b0c:	8b458063 	add	x3, x3, x5, lsr #32
    7b10:	eb03003f 	cmp	x1, x3
    7b14:	54000063 	b.cc	7b20 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    7b18:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    7b1c:	54000082 	b.cs	7b2c <__modti3+0x1cc>  // b.hs, b.nlast
    7b20:	eb020129 	subs	x9, x9, x2
    7b24:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    7b28:	cb070063 	sub	x3, x3, x7
    7b2c:	eb090000 	subs	x0, x0, x9
    7b30:	da030021 	sbc	x1, x1, x3
    7b34:	9ac62400 	lsr	x0, x0, x6
    7b38:	9ac82028 	lsl	x8, x1, x8
    7b3c:	aa000100 	orr	x0, x8, x0
    7b40:	9ac62421 	lsr	x1, x1, x6
    7b44:	17ffffb4 	b	7a14 <__modti3+0xb4>
    7b48:	b5000062 	cbnz	x2, 7b54 <__modti3+0x1f4>
    7b4c:	d2800023 	mov	x3, #0x1                   	// #1
    7b50:	9ac20862 	udiv	x2, x3, x2
    7b54:	dac01048 	clz	x8, x2
    7b58:	aa0803e5 	mov	x5, x8
    7b5c:	b5000668 	cbnz	x8, 7c28 <__modti3+0x2c8>
    7b60:	cb020020 	sub	x0, x1, x2
    7b64:	d360fc49 	lsr	x9, x2, #32
    7b68:	92407c4a 	and	x10, x2, #0xffffffff
    7b6c:	9ac90801 	udiv	x1, x0, x9
    7b70:	9b098020 	msub	x0, x1, x9, x0
    7b74:	9b0a7c21 	mul	x1, x1, x10
    7b78:	93c78000 	extr	x0, x0, x7, #32
    7b7c:	eb00003f 	cmp	x1, x0
    7b80:	540000a9 	b.ls	7b94 <__modti3+0x234>  // b.plast
    7b84:	ab000040 	adds	x0, x2, x0
    7b88:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7b8c:	8b020003 	add	x3, x0, x2
    7b90:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7b94:	cb010001 	sub	x1, x0, x1
    7b98:	9ac90820 	udiv	x0, x1, x9
    7b9c:	9b098403 	msub	x3, x0, x9, x1
    7ba0:	aa0703e1 	mov	x1, x7
    7ba4:	9b0a7c00 	mul	x0, x0, x10
    7ba8:	b3607c61 	bfi	x1, x3, #32, #32
    7bac:	eb01001f 	cmp	x0, x1
    7bb0:	540000a9 	b.ls	7bc4 <__modti3+0x264>  // b.plast
    7bb4:	ab010041 	adds	x1, x2, x1
    7bb8:	8b020022 	add	x2, x1, x2
    7bbc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    7bc0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    7bc4:	cb000020 	sub	x0, x1, x0
    7bc8:	17ffff91 	b	7a0c <__modti3+0xac>
    7bcc:	eb0203e5 	negs	x5, x2
    7bd0:	aa0003e7 	mov	x7, x0
    7bd4:	da0303e8 	ngc	x8, x3
    7bd8:	aa0503e2 	mov	x2, x5
    7bdc:	aa0803e3 	mov	x3, x8
    7be0:	aa0103e6 	mov	x6, x1
    7be4:	b4ffed48 	cbz	x8, 798c <__modti3+0x2c>
    7be8:	eb01011f 	cmp	x8, x1
    7bec:	54fff148 	b.hi	7a14 <__modti3+0xb4>  // b.pmore
    7bf0:	dac01109 	clz	x9, x8
    7bf4:	2a0903e6 	mov	w6, w9
    7bf8:	b5fff1c9 	cbnz	x9, 7a30 <__modti3+0xd0>
    7bfc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    7c00:	54000068 	b.hi	7c0c <__modti3+0x2ac>  // b.pmore
    7c04:	eb050007 	subs	x7, x0, x5
    7c08:	da080021 	sbc	x1, x1, x8
    7c0c:	aa0703e0 	mov	x0, x7
    7c10:	17ffff81 	b	7a14 <__modti3+0xb4>
    7c14:	ab000040 	adds	x0, x2, x0
    7c18:	8b020002 	add	x2, x0, x2
    7c1c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    7c20:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    7c24:	17ffff79 	b	7a08 <__modti3+0xa8>
    7c28:	9ac82042 	lsl	x2, x2, x8
    7c2c:	d2800803 	mov	x3, #0x40                  	// #64
    7c30:	cb080063 	sub	x3, x3, x8
    7c34:	d360fc49 	lsr	x9, x2, #32
    7c38:	9ac82027 	lsl	x7, x1, x8
    7c3c:	92407c4a 	and	x10, x2, #0xffffffff
    7c40:	9ac32426 	lsr	x6, x1, x3
    7c44:	9ac32403 	lsr	x3, x0, x3
    7c48:	aa070063 	orr	x3, x3, x7
    7c4c:	9ac908c1 	udiv	x1, x6, x9
    7c50:	9ac82007 	lsl	x7, x0, x8
    7c54:	9b099820 	msub	x0, x1, x9, x6
    7c58:	9b017d41 	mul	x1, x10, x1
    7c5c:	93c38000 	extr	x0, x0, x3, #32
    7c60:	eb00003f 	cmp	x1, x0
    7c64:	540000a9 	b.ls	7c78 <__modti3+0x318>  // b.plast
    7c68:	ab000040 	adds	x0, x2, x0
    7c6c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7c70:	8b020006 	add	x6, x0, x2
    7c74:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    7c78:	cb010000 	sub	x0, x0, x1
    7c7c:	9ac90801 	udiv	x1, x0, x9
    7c80:	9b098026 	msub	x6, x1, x9, x0
    7c84:	aa0303e0 	mov	x0, x3
    7c88:	9b017d41 	mul	x1, x10, x1
    7c8c:	b3607cc0 	bfi	x0, x6, #32, #32
    7c90:	eb00003f 	cmp	x1, x0
    7c94:	540000a9 	b.ls	7ca8 <__modti3+0x348>  // b.plast
    7c98:	ab000040 	adds	x0, x2, x0
    7c9c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7ca0:	8b020003 	add	x3, x0, x2
    7ca4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7ca8:	cb010000 	sub	x0, x0, x1
    7cac:	17ffffb0 	b	7b6c <__modti3+0x20c>
    7cb0:	d1000969 	sub	x9, x11, #0x2
    7cb4:	8b070021 	add	x1, x1, x7
    7cb8:	17ffff83 	b	7ac4 <__modti3+0x164>
    7cbc:	d1000965 	sub	x5, x11, #0x2
    7cc0:	8b070063 	add	x3, x3, x7
    7cc4:	17ffff74 	b	7a94 <__modti3+0x134>
    7cc8:	d503201f 	nop
    7ccc:	d503201f 	nop

0000000000007cd0 <atexit>:
    7cd0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7cd4:	b00000c2 	adrp	x2, 20000 <__data_start>
    7cd8:	d2800001 	mov	x1, #0x0                   	// #0
    7cdc:	910003fd 	mov	x29, sp
    7ce0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7ce4:	f9400442 	ldr	x2, [x2, #8]
    7ce8:	17ffe5ae 	b	13a0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000007cec <_fini>:
    7cec:	d503201f 	nop
    7cf0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7cf4:	910003fd 	mov	x29, sp
    7cf8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7cfc:	d65f03c0 	ret
