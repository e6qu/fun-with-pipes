
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1999/fwp-local-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b78>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	d0000025 	adrp	x5, 7000 <atexit>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	910a00a5 	add	x5, x5, #0x280
    1720:	d0000024 	adrp	x4, 7000 <atexit>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	910a2084 	add	x4, x4, #0x288
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x16b78>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9004a61 	str	x1, [x19, #144]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	d0000020 	adrp	x0, 7000 <atexit>
    17a4:	91158000 	add	x0, x0, #0x560
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000002 	adrp	x2, 4000 <fwp_write.constprop.0+0x100>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	913a9042 	add	x2, x2, #0xea4
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91024273 	add	x19, x19, #0x90
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942da60 	ldr	w0, [x19, #728]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	d0000020 	adrp	x0, 7000 <atexit>
    18ec:	9115c000 	add	x0, x0, #0x570
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	d0000020 	adrp	x0, 7000 <atexit>
    18fc:	91184000 	add	x0, x0, #0x610
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	d0000020 	adrp	x0, 7000 <atexit>
    1914:	9117a000 	add	x0, x0, #0x5e8
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	d0000020 	adrp	x0, 7000 <atexit>
    1920:	9116e000 	add	x0, x0, #0x5b8
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	d0000020 	adrp	x0, 7000 <atexit>
    192c:	91164000 	add	x0, x0, #0x590
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9101e000 	add	x0, x0, #0x78
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9101e021 	add	x1, x1, #0x78
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9101e000 	add	x0, x0, #0x78
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9101e021 	add	x1, x1, #0x78
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b78>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	39420260 	ldrb	w0, [x19, #128]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	39020260 	strb	w0, [x19, #128]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	d0000021 	adrp	x1, 7000 <atexit>
    1af4:	911c0021 	add	x1, x1, #0x700
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9404800 	ldr	x0, [x0, #144]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91024043 	add	x3, x2, #0x90
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91024042 	add	x2, x2, #0x90
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	d0000021 	adrp	x1, 7000 <atexit>
    1cb8:	911b8021 	add	x1, x1, #0x6e0
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b78>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	d0000020 	adrp	x0, 7000 <atexit>
    1cf0:	9100e000 	add	x0, x0, #0x38
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xc70>
    1d24:	9115c2a1 	add	x1, x21, #0x570
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1d38:	912580a5 	add	x5, x5, #0x960
    1d3c:	9115c2a1 	add	x1, x21, #0x570
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	9115c2b7 	add	x23, x21, #0x570
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	9115c2b5 	add	x21, x21, #0x570
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	9115c2b5 	add	x21, x21, #0x570
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1ec8:	912560a5 	add	x5, x5, #0x958
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x16b78>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	d0000022 	adrp	x2, 7000 <atexit>
    1efc:	91014042 	add	x2, x2, #0x50
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b78>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	d0000022 	adrp	x2, 7000 <atexit>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	91020042 	add	x2, x2, #0x80
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	d0000036 	adrp	x22, 7000 <atexit>
    1f3c:	910382d6 	add	x22, x22, #0xe0
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x16b78>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	d0000037 	adrp	x23, 7000 <atexit>
    1f5c:	9101e2f7 	add	x23, x23, #0x78
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9405824 	ldr	x4, [x1, #176]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	d0000023 	adrp	x3, 7000 <atexit>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	9101c063 	add	x3, x3, #0x70
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	d0000020 	adrp	x0, 7000 <atexit>
    1fe4:	91048000 	add	x0, x0, #0x120
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	b0000020 	adrp	x0, 7000 <atexit>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	9104e000 	add	x0, x0, #0x138
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b78>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	b0000020 	adrp	x0, 7000 <atexit>
    20ec:	9100e000 	add	x0, x0, #0x38
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91024022 	add	x2, x1, #0x90
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91024021 	add	x1, x1, #0x90
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	b0000021 	adrp	x1, 7000 <atexit>
    2230:	aa1303e0 	mov	x0, x19
    2234:	91050021 	add	x1, x1, #0x140
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	b0000021 	adrp	x1, 7000 <atexit>
    2244:	aa1303e0 	mov	x0, x19
    2248:	91052021 	add	x1, x1, #0x148
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	b0000021 	adrp	x1, 7000 <atexit>
    2260:	91054021 	add	x1, x1, #0x150
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x16b78>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	b0000022 	adrp	x2, 7000 <atexit>
    22a4:	91056042 	add	x2, x2, #0x158
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b78>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	b0000020 	adrp	x0, 7000 <atexit>
    2348:	9105a000 	add	x0, x0, #0x168
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	b0000020 	adrp	x0, 7000 <atexit>
    2358:	91062000 	add	x0, x0, #0x188
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	b0000024 	adrp	x4, 7000 <atexit>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b78>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	9106c084 	add	x4, x4, #0x1b0
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	b0000024 	adrp	x4, 7000 <atexit>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	91072084 	add	x4, x4, #0x1c8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	b0000024 	adrp	x4, 7000 <atexit>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	9106e084 	add	x4, x4, #0x1b8
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    276c:	9115c042 	add	x2, x2, #0x570
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b78>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	b0000021 	adrp	x1, 7000 <atexit>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	b0000020 	adrp	x0, 7000 <atexit>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	91074021 	add	x1, x1, #0x1d0
    27c8:	91076000 	add	x0, x0, #0x1d8
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	b0000022 	adrp	x2, 7000 <atexit>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	9107e042 	add	x2, x2, #0x1f8
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xa90>
    28d8:	9111c061 	add	x1, x3, #0x470
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    28e8:	9115c262 	add	x2, x19, #0x570
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	b0000022 	adrp	x2, 7000 <atexit>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xa90>
    291c:	9112c021 	add	x1, x1, #0x4b0
    2920:	3dc1c443 	ldr	q3, [x2, #1808]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xa90>
    294c:	9111c063 	add	x3, x3, #0x470
    2950:	91144084 	add	x4, x4, #0x510
    2954:	9115c266 	add	x6, x19, #0x570
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	9115c275 	add	x21, x19, #0x570
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	b0000020 	adrp	x0, 7000 <atexit>
    2a38:	910aa000 	add	x0, x0, #0x2a8
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	9115c273 	add	x19, x19, #0x570
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91024122 	add	x2, x9, #0x90
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91024120 	add	x0, x9, #0x90
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91024129 	add	x9, x9, #0x90
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91024281 	add	x1, x20, #0x90
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91024280 	add	x0, x20, #0x90
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91024288 	add	x8, x20, #0x90
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91024281 	add	x1, x20, #0x90
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b78>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	b0000020 	adrp	x0, 7000 <atexit>
    2d6c:	910ae000 	add	x0, x0, #0x2b8
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    2db4:	9115c262 	add	x2, x19, #0x570
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	9115c273 	add	x19, x19, #0x570
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	b0000020 	adrp	x0, 7000 <atexit>
    2e14:	910ba000 	add	x0, x0, #0x2e8
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xc70>
    2e30:	9115c2c2 	add	x2, x22, #0x570
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	9115c2c2 	add	x2, x22, #0x570
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	9115c2d6 	add	x22, x22, #0x570
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    2f50:	9115c2b5 	add	x21, x21, #0x570
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3014:	9115c2a1 	add	x1, x21, #0x570
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	9115c2b5 	add	x21, x21, #0x570
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	9115c2a1 	add	x1, x21, #0x570
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	9115c2a0 	add	x0, x21, #0x570
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	9115c2b5 	add	x21, x21, #0x570
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xc70>
    3218:	9115c359 	add	x25, x26, #0x570
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	9115c353 	add	x19, x26, #0x570
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9115c35a 	add	x26, x26, #0x570
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    3330:	9115c262 	add	x2, x19, #0x570
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	9115c262 	add	x2, x19, #0x570
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	9115c260 	add	x0, x19, #0x570
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	9115c273 	add	x19, x19, #0x570
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	9115c260 	add	x0, x19, #0x570
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_free_arr>:
    3480:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    3484:	9115c063 	add	x3, x3, #0x570
    3488:	f949d861 	ldr	x1, [x3, #5040]
    348c:	f949ec62 	ldr	x2, [x3, #5080]
    3490:	cb010001 	sub	x1, x0, x1
    3494:	eb02403f 	cmp	x1, x2, lsl #16
    3498:	54000342 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    349c:	d350fc22 	lsr	x2, x1, #16
    34a0:	f949fc65 	ldr	x5, [x3, #5112]
    34a4:	8b020842 	add	x2, x2, x2, lsl #2
    34a8:	d37df042 	lsl	x2, x2, #3
    34ac:	8b0200a4 	add	x4, x5, x2
    34b0:	f9401083 	ldr	x3, [x4, #32]
    34b4:	b4000263 	cbz	x3, 3500 <fwp_rc_free_arr+0x80>
    34b8:	386268a2 	ldrb	w2, [x5, x2]
    34bc:	7100085f 	cmp	w2, #0x2
    34c0:	540001c0 	b.eq	34f8 <fwp_rc_free_arr+0x78>  // b.none
    34c4:	7100045f 	cmp	w2, #0x1
    34c8:	540001c1 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34cc:	29430885 	ldp	w5, w2, [x4, #24]
    34d0:	92403c21 	and	x1, x1, #0xffff
    34d4:	9b057c21 	mul	x1, x1, x5
    34d8:	d360fc21 	lsr	x1, x1, #32
    34dc:	eb02003f 	cmp	x1, x2
    34e0:	54000102 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    34e4:	8b010063 	add	x3, x3, x1
    34e8:	39400061 	ldrb	w1, [x3]
    34ec:	7100043f 	cmp	w1, #0x1
    34f0:	54000081 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34f4:	17fffec3 	b	3000 <fwp_mem_free>
    34f8:	72003c3f 	tst	w1, #0xffff
    34fc:	54ffff60 	b.eq	34e8 <fwp_rc_free_arr+0x68>  // b.none
    3500:	d65f03c0 	ret

0000000000003504 <fwp_heap_alloc>:
    3504:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3508:	910003fd 	mov	x29, sp
    350c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3510:	b00000f6 	adrp	x22, 20000 <__data_start>
    3514:	910242c2 	add	x2, x22, #0x90
    3518:	a90363f7 	stp	x23, x24, [sp, #48]
    351c:	b9404058 	ldr	w24, [x2, #64]
    3520:	a90153f3 	stp	x19, x20, [sp, #16]
    3524:	7100031f 	cmp	w24, #0x0
    3528:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    352c:	54000861 	b.ne	3638 <fwp_heap_alloc+0x134>  // b.any
    3530:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xc70>
    3534:	9115c2f3 	add	x19, x23, #0x570
    3538:	f140101f 	cmp	x0, #0x4, lsl #12
    353c:	b953a662 	ldr	w2, [x19, #5028]
    3540:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3544:	54000740 	b.eq	362c <fwp_heap_alloc+0x128>  // b.none
    3548:	91003c03 	add	x3, x0, #0xf
    354c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3550:	cb21c042 	sub	x2, x2, w1, sxtw
    3554:	8b431263 	add	x3, x19, x3, lsr #4
    3558:	d37ae442 	lsl	x2, x2, #6
    355c:	397e8063 	ldrb	w3, [x3, #4000]
    3560:	910f0064 	add	x4, x3, #0x3c0
    3564:	8b030463 	add	x3, x3, x3, lsl #1
    3568:	8b030c43 	add	x3, x2, x3, lsl #3
    356c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3570:	2a1503f4 	mov	w20, w21
    3574:	f8636a64 	ldr	x4, [x19, x3]
    3578:	b40004c4 	cbz	x4, 3610 <fwp_heap_alloc+0x10c>
    357c:	f9400085 	ldr	x5, [x4]
    3580:	7100043f 	cmp	w1, #0x1
    3584:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3588:	aa0403e0 	mov	x0, x4
    358c:	aa2503e5 	mvn	x5, x5
    3590:	52800001 	mov	w1, #0x0                   	// #0
    3594:	f8236a65 	str	x5, [x19, x3]
    3598:	97fff7ce 	bl	14d0 <memset@plt>
    359c:	aa0003e4 	mov	x4, x0
    35a0:	f94a1260 	ldr	x0, [x19, #5152]
    35a4:	ab140000 	adds	x0, x0, x20
    35a8:	540006e2 	b.cs	3684 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    35ac:	f94a1661 	ldr	x1, [x19, #5160]
    35b0:	f90a1260 	str	x0, [x19, #5152]
    35b4:	eb01001f 	cmp	x0, x1
    35b8:	54000049 	b.ls	35c0 <fwp_heap_alloc+0xbc>  // b.plast
    35bc:	f90a1660 	str	x0, [x19, #5160]
    35c0:	9115c2e0 	add	x0, x23, #0x570
    35c4:	1e6302a1 	ucvtf	d1, w21
    35c8:	fd4a1c00 	ldr	d0, [x0, #5176]
    35cc:	1e612800 	fadd	d0, d0, d1
    35d0:	fd0a1c00 	str	d0, [x0, #5176]
    35d4:	34000138 	cbz	w24, 35f8 <fwp_heap_alloc+0xf4>
    35d8:	9115c2e1 	add	x1, x23, #0x570
    35dc:	910242c0 	add	x0, x22, #0x90
    35e0:	fd4a1020 	ldr	d0, [x1, #5152]
    35e4:	6d458402 	ldp	d2, d1, [x0, #88]
    35e8:	7e61d800 	ucvtf	d0, d0
    35ec:	1e623800 	fsub	d0, d0, d2
    35f0:	1e612010 	fcmpe	d0, d1
    35f4:	540002cc 	b.gt	364c <fwp_heap_alloc+0x148>
    35f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35fc:	aa0403e0 	mov	x0, x4
    3600:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3604:	a94363f7 	ldp	x23, x24, [sp, #48]
    3608:	a8c47bfd 	ldp	x29, x30, [sp], #64
    360c:	d65f03c0 	ret
    3610:	8b030263 	add	x3, x19, x3
    3614:	f9400464 	ldr	x4, [x3, #8]
    3618:	b40000a4 	cbz	x4, 362c <fwp_heap_alloc+0x128>
    361c:	f9400862 	ldr	x2, [x3, #16]
    3620:	cb040042 	sub	x2, x2, x4
    3624:	eb02029f 	cmp	x20, x2
    3628:	54000209 	b.ls	3668 <fwp_heap_alloc+0x164>  // b.plast
    362c:	97ffff3d 	bl	3320 <fwp_heap_alloc_slow>
    3630:	aa0003e4 	mov	x4, x0
    3634:	17ffffe8 	b	35d4 <fwp_heap_alloc+0xd0>
    3638:	a9448c44 	ldp	x4, x3, [x2, #72]
    363c:	91000484 	add	x4, x4, #0x1
    3640:	8b000063 	add	x3, x3, x0
    3644:	a9048c44 	stp	x4, x3, [x2, #72]
    3648:	17ffffba 	b	3530 <fwp_heap_alloc+0x2c>
    364c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3650:	fd003000 	str	d0, [x0, #96]
    3654:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3658:	aa0403e0 	mov	x0, x4
    365c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3660:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3664:	d65f03c0 	ret
    3668:	7100043f 	cmp	w1, #0x1
    366c:	8b140085 	add	x5, x4, x20
    3670:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3674:	52800001 	mov	w1, #0x0                   	// #0
    3678:	aa0403e0 	mov	x0, x4
    367c:	f9000465 	str	x5, [x3, #8]
    3680:	17ffffc6 	b	3598 <fwp_heap_alloc+0x94>
    3684:	97fff993 	bl	1cd0 <fwp_heap_oom>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <fwp_data.part.0.constprop.0>:
    3690:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3694:	910003fd 	mov	x29, sp
    3698:	a9025bf5 	stp	x21, x22, [sp, #32]
    369c:	b00000f6 	adrp	x22, 20000 <__data_start>
    36a0:	910242c2 	add	x2, x22, #0x90
    36a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    36a8:	b9404059 	ldr	w25, [x2, #64]
    36ac:	a90153f3 	stp	x19, x20, [sp, #16]
    36b0:	aa0103f4 	mov	x20, x1
    36b4:	a90363f7 	stp	x23, x24, [sp, #48]
    36b8:	2a0003f7 	mov	w23, w0
    36bc:	340000b9 	cbz	w25, 36d0 <fwp_data.part.0.constprop.0+0x40>
    36c0:	a9448041 	ldp	x1, x0, [x2, #72]
    36c4:	91000421 	add	x1, x1, #0x1
    36c8:	91006000 	add	x0, x0, #0x18
    36cc:	a9048041 	stp	x1, x0, [x2, #72]
    36d0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    36d4:	9115c2a3 	add	x3, x21, #0x570
    36d8:	b953a460 	ldr	w0, [x3, #5028]
    36dc:	34000840 	cbz	w0, 37e4 <fwp_data.part.0.constprop.0+0x154>
    36e0:	397e8862 	ldrb	w2, [x3, #4002]
    36e4:	910f0040 	add	x0, x2, #0x3c0
    36e8:	8b020442 	add	x2, x2, x2, lsl #1
    36ec:	d37df042 	lsl	x2, x2, #3
    36f0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    36f4:	2a1a03f8 	mov	w24, w26
    36f8:	f8626873 	ldr	x19, [x3, x2]
    36fc:	b4000613 	cbz	x19, 37bc <fwp_data.part.0.constprop.0+0x12c>
    3700:	f9400260 	ldr	x0, [x19]
    3704:	aa2003e0 	mvn	x0, x0
    3708:	f8226860 	str	x0, [x3, x2]
    370c:	f100631f 	cmp	x24, #0x18
    3710:	540000e9 	b.ls	372c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    3714:	d1006702 	sub	x2, x24, #0x19
    3718:	91006260 	add	x0, x19, #0x18
    371c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3720:	52800001 	mov	w1, #0x0                   	// #0
    3724:	91002042 	add	x2, x2, #0x8
    3728:	97fff76a 	bl	14d0 <memset@plt>
    372c:	9115c2a0 	add	x0, x21, #0x570
    3730:	f94a1001 	ldr	x1, [x0, #5152]
    3734:	ab180021 	adds	x1, x1, x24
    3738:	54000642 	b.cs	3800 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    373c:	f94a1402 	ldr	x2, [x0, #5160]
    3740:	f90a1001 	str	x1, [x0, #5152]
    3744:	eb02003f 	cmp	x1, x2
    3748:	54000049 	b.ls	3750 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    374c:	f90a1401 	str	x1, [x0, #5160]
    3750:	9115c2a0 	add	x0, x21, #0x570
    3754:	1e630341 	ucvtf	d1, w26
    3758:	fd4a1c00 	ldr	d0, [x0, #5176]
    375c:	1e612800 	fadd	d0, d0, d1
    3760:	fd0a1c00 	str	d0, [x0, #5176]
    3764:	34000139 	cbz	w25, 3788 <fwp_data.part.0.constprop.0+0xf8>
    3768:	9115c2b5 	add	x21, x21, #0x570
    376c:	910242d6 	add	x22, x22, #0x90
    3770:	fd4a12a0 	ldr	d0, [x21, #5152]
    3774:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3778:	7e61d800 	ucvtf	d0, d0
    377c:	1e623800 	fsub	d0, d0, d2
    3780:	1e612010 	fcmpe	d0, d1
    3784:	540003ac 	b.gt	37f8 <fwp_data.part.0.constprop.0+0x168>
    3788:	52800040 	mov	w0, #0x2                   	// #2
    378c:	29000277 	stp	w23, w0, [x19]
    3790:	aa1303e0 	mov	x0, x19
    3794:	f9400281 	ldr	x1, [x20]
    3798:	f9000661 	str	x1, [x19, #8]
    379c:	f9400681 	ldr	x1, [x20, #8]
    37a0:	f9000a61 	str	x1, [x19, #16]
    37a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    37a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    37ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    37b0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    37b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    37b8:	d65f03c0 	ret
    37bc:	8b020063 	add	x3, x3, x2
    37c0:	f9400473 	ldr	x19, [x3, #8]
    37c4:	b4000113 	cbz	x19, 37e4 <fwp_data.part.0.constprop.0+0x154>
    37c8:	f9400860 	ldr	x0, [x3, #16]
    37cc:	cb130000 	sub	x0, x0, x19
    37d0:	eb00031f 	cmp	x24, x0
    37d4:	54000088 	b.hi	37e4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    37d8:	8b180260 	add	x0, x19, x24
    37dc:	f9000460 	str	x0, [x3, #8]
    37e0:	17ffffcb 	b	370c <fwp_data.part.0.constprop.0+0x7c>
    37e4:	52800001 	mov	w1, #0x0                   	// #0
    37e8:	d2800300 	mov	x0, #0x18                  	// #24
    37ec:	97ffff46 	bl	3504 <fwp_heap_alloc>
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	17ffffdc 	b	3764 <fwp_data.part.0.constprop.0+0xd4>
    37f8:	fd0032c0 	str	d0, [x22, #96]
    37fc:	17ffffe3 	b	3788 <fwp_data.part.0.constprop.0+0xf8>
    3800:	97fff934 	bl	1cd0 <fwp_heap_oom>

0000000000003804 <fwp_array_new_packed.constprop.0>:
    3804:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3808:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    380c:	910003fd 	mov	x29, sp
    3810:	f9000bf3 	str	x19, [sp, #16]
    3814:	eb01001f 	cmp	x0, x1
    3818:	54000148 	b.hi	3840 <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    381c:	aa0003f3 	mov	x19, x0
    3820:	91000400 	add	x0, x0, #0x1
    3824:	52800021 	mov	w1, #0x1                   	// #1
    3828:	d37df000 	lsl	x0, x0, #3
    382c:	97ffff36 	bl	3504 <fwp_heap_alloc>
    3830:	f9000013 	str	x19, [x0]
    3834:	f9400bf3 	ldr	x19, [sp, #16]
    3838:	a8c27bfd 	ldp	x29, x30, [sp], #32
    383c:	d65f03c0 	ret
    3840:	90000020 	adrp	x0, 7000 <atexit>
    3844:	910c4000 	add	x0, x0, #0x310
    3848:	97fffa8e 	bl	2280 <fwp_trap>
    384c:	d503201f 	nop

0000000000003850 <fwp_drop0>:
    3850:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3854:	910003fd 	mov	x29, sp
    3858:	a90153f3 	stp	x19, x20, [sp, #16]
    385c:	f90013f5 	str	x21, [sp, #32]
    3860:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3864:	9115c2b4 	add	x20, x21, #0x570
    3868:	f949da81 	ldr	x1, [x20, #5040]
    386c:	f949ee82 	ldr	x2, [x20, #5080]
    3870:	cb010001 	sub	x1, x0, x1
    3874:	eb02403f 	cmp	x1, x2, lsl #16
    3878:	54000382 	b.cs	38e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    387c:	d350fc22 	lsr	x2, x1, #16
    3880:	f949fe84 	ldr	x4, [x20, #5112]
    3884:	8b020842 	add	x2, x2, x2, lsl #2
    3888:	d37df042 	lsl	x2, x2, #3
    388c:	8b020083 	add	x3, x4, x2
    3890:	f9401073 	ldr	x19, [x3, #32]
    3894:	b40002b3 	cbz	x19, 38e8 <fwp_drop0+0x98>
    3898:	38626882 	ldrb	w2, [x4, x2]
    389c:	7100085f 	cmp	w2, #0x2
    38a0:	540002c0 	b.eq	38f8 <fwp_drop0+0xa8>  // b.none
    38a4:	7100045f 	cmp	w2, #0x1
    38a8:	54000201 	b.ne	38e8 <fwp_drop0+0x98>  // b.any
    38ac:	29430864 	ldp	w4, w2, [x3, #24]
    38b0:	92403c21 	and	x1, x1, #0xffff
    38b4:	9b047c21 	mul	x1, x1, x4
    38b8:	d360fc21 	lsr	x1, x1, #32
    38bc:	eb02003f 	cmp	x1, x2
    38c0:	54000142 	b.cs	38e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    38c4:	8b010273 	add	x19, x19, x1
    38c8:	39400261 	ldrb	w1, [x19]
    38cc:	340000e1 	cbz	w1, 38e8 <fwp_drop0+0x98>
    38d0:	7100043f 	cmp	w1, #0x1
    38d4:	540001e0 	b.eq	3910 <fwp_drop0+0xc0>  // b.none
    38d8:	7103fc3f 	cmp	w1, #0xff
    38dc:	540002e0 	b.eq	3938 <fwp_drop0+0xe8>  // b.none
    38e0:	51000421 	sub	w1, w1, #0x1
    38e4:	39000261 	strb	w1, [x19]
    38e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ec:	f94013f5 	ldr	x21, [sp, #32]
    38f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    38f4:	d65f03c0 	ret
    38f8:	72003c3f 	tst	w1, #0xffff
    38fc:	54fffe60 	b.eq	38c8 <fwp_drop0+0x78>  // b.none
    3900:	a94153f3 	ldp	x19, x20, [sp, #16]
    3904:	f94013f5 	ldr	x21, [sp, #32]
    3908:	a8c37bfd 	ldp	x29, x30, [sp], #48
    390c:	d65f03c0 	ret
    3910:	f9400813 	ldr	x19, [x0, #16]
    3914:	97fffedb 	bl	3480 <fwp_rc_free_arr>
    3918:	9115c2a0 	add	x0, x21, #0x570
    391c:	f949d801 	ldr	x1, [x0, #5040]
    3920:	f949ec00 	ldr	x0, [x0, #5080]
    3924:	cb010261 	sub	x1, x19, x1
    3928:	eb00403f 	cmp	x1, x0, lsl #16
    392c:	54fffde2 	b.cs	38e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3930:	aa1303e0 	mov	x0, x19
    3934:	17ffffd2 	b	387c <fwp_drop0+0x2c>
    3938:	ca534660 	eor	x0, x19, x19, lsr #17
    393c:	9115c2b5 	add	x21, x21, #0x570
    3940:	ca402400 	eor	x0, x0, x0, lsr #9
    3944:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3948:	f94a2400 	ldr	x0, [x0, #5192]
    394c:	b5000080 	cbnz	x0, 395c <fwp_drop0+0x10c>
    3950:	14000010 	b	3990 <fwp_drop0+0x140>
    3954:	f9400800 	ldr	x0, [x0, #16]
    3958:	b40001c0 	cbz	x0, 3990 <fwp_drop0+0x140>
    395c:	f9400001 	ldr	x1, [x0]
    3960:	eb13003f 	cmp	x1, x19
    3964:	54ffff81 	b.ne	3954 <fwp_drop0+0x104>  // b.any
    3968:	f9400401 	ldr	x1, [x0, #8]
    396c:	d1000421 	sub	x1, x1, #0x1
    3970:	f9000401 	str	x1, [x0, #8]
    3974:	f103f83f 	cmp	x1, #0xfe
    3978:	54fffb81 	b.ne	38e8 <fwp_drop0+0x98>  // b.any
    397c:	aa1303e0 	mov	x0, x19
    3980:	97fffd01 	bl	2d84 <fwp_rc_forget_slot>
    3984:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3988:	39000260 	strb	w0, [x19]
    398c:	17ffffd7 	b	38e8 <fwp_drop0+0x98>
    3990:	90000020 	adrp	x0, 7000 <atexit>
    3994:	910ba000 	add	x0, x0, #0x2e8
    3998:	97fffa3a 	bl	2280 <fwp_trap>
    399c:	d503201f 	nop

00000000000039a0 <fwp_drop1>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	910003fd 	mov	x29, sp
    39a8:	a90153f3 	stp	x19, x20, [sp, #16]
    39ac:	f90013f5 	str	x21, [sp, #32]
    39b0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    39b4:	9115c2b4 	add	x20, x21, #0x570
    39b8:	f949da81 	ldr	x1, [x20, #5040]
    39bc:	f949ee82 	ldr	x2, [x20, #5080]
    39c0:	cb010001 	sub	x1, x0, x1
    39c4:	eb02403f 	cmp	x1, x2, lsl #16
    39c8:	54000382 	b.cs	3a38 <fwp_drop1+0x98>  // b.hs, b.nlast
    39cc:	d350fc22 	lsr	x2, x1, #16
    39d0:	f949fe84 	ldr	x4, [x20, #5112]
    39d4:	8b020842 	add	x2, x2, x2, lsl #2
    39d8:	d37df042 	lsl	x2, x2, #3
    39dc:	8b020083 	add	x3, x4, x2
    39e0:	f9401073 	ldr	x19, [x3, #32]
    39e4:	b40002b3 	cbz	x19, 3a38 <fwp_drop1+0x98>
    39e8:	38626882 	ldrb	w2, [x4, x2]
    39ec:	7100085f 	cmp	w2, #0x2
    39f0:	540002c0 	b.eq	3a48 <fwp_drop1+0xa8>  // b.none
    39f4:	7100045f 	cmp	w2, #0x1
    39f8:	54000201 	b.ne	3a38 <fwp_drop1+0x98>  // b.any
    39fc:	29430864 	ldp	w4, w2, [x3, #24]
    3a00:	92403c21 	and	x1, x1, #0xffff
    3a04:	9b047c21 	mul	x1, x1, x4
    3a08:	d360fc21 	lsr	x1, x1, #32
    3a0c:	eb02003f 	cmp	x1, x2
    3a10:	54000142 	b.cs	3a38 <fwp_drop1+0x98>  // b.hs, b.nlast
    3a14:	8b010273 	add	x19, x19, x1
    3a18:	39400261 	ldrb	w1, [x19]
    3a1c:	340000e1 	cbz	w1, 3a38 <fwp_drop1+0x98>
    3a20:	7100043f 	cmp	w1, #0x1
    3a24:	540001e0 	b.eq	3a60 <fwp_drop1+0xc0>  // b.none
    3a28:	7103fc3f 	cmp	w1, #0xff
    3a2c:	540002e0 	b.eq	3a88 <fwp_drop1+0xe8>  // b.none
    3a30:	51000421 	sub	w1, w1, #0x1
    3a34:	39000261 	strb	w1, [x19]
    3a38:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a3c:	f94013f5 	ldr	x21, [sp, #32]
    3a40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a44:	d65f03c0 	ret
    3a48:	72003c3f 	tst	w1, #0xffff
    3a4c:	54fffe60 	b.eq	3a18 <fwp_drop1+0x78>  // b.none
    3a50:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a54:	f94013f5 	ldr	x21, [sp, #32]
    3a58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a5c:	d65f03c0 	ret
    3a60:	f9400813 	ldr	x19, [x0, #16]
    3a64:	97fffe87 	bl	3480 <fwp_rc_free_arr>
    3a68:	9115c2a0 	add	x0, x21, #0x570
    3a6c:	f949d801 	ldr	x1, [x0, #5040]
    3a70:	f949ec00 	ldr	x0, [x0, #5080]
    3a74:	cb010261 	sub	x1, x19, x1
    3a78:	eb00403f 	cmp	x1, x0, lsl #16
    3a7c:	54fffde2 	b.cs	3a38 <fwp_drop1+0x98>  // b.hs, b.nlast
    3a80:	aa1303e0 	mov	x0, x19
    3a84:	17ffffd2 	b	39cc <fwp_drop1+0x2c>
    3a88:	ca534660 	eor	x0, x19, x19, lsr #17
    3a8c:	9115c2b5 	add	x21, x21, #0x570
    3a90:	ca402400 	eor	x0, x0, x0, lsr #9
    3a94:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3a98:	f94a2400 	ldr	x0, [x0, #5192]
    3a9c:	b5000080 	cbnz	x0, 3aac <fwp_drop1+0x10c>
    3aa0:	14000010 	b	3ae0 <fwp_drop1+0x140>
    3aa4:	f9400800 	ldr	x0, [x0, #16]
    3aa8:	b40001c0 	cbz	x0, 3ae0 <fwp_drop1+0x140>
    3aac:	f9400001 	ldr	x1, [x0]
    3ab0:	eb13003f 	cmp	x1, x19
    3ab4:	54ffff81 	b.ne	3aa4 <fwp_drop1+0x104>  // b.any
    3ab8:	f9400401 	ldr	x1, [x0, #8]
    3abc:	d1000421 	sub	x1, x1, #0x1
    3ac0:	f9000401 	str	x1, [x0, #8]
    3ac4:	f103f83f 	cmp	x1, #0xfe
    3ac8:	54fffb81 	b.ne	3a38 <fwp_drop1+0x98>  // b.any
    3acc:	aa1303e0 	mov	x0, x19
    3ad0:	97fffcad 	bl	2d84 <fwp_rc_forget_slot>
    3ad4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ad8:	39000260 	strb	w0, [x19]
    3adc:	17ffffd7 	b	3a38 <fwp_drop1+0x98>
    3ae0:	90000020 	adrp	x0, 7000 <atexit>
    3ae4:	910ba000 	add	x0, x0, #0x2e8
    3ae8:	97fff9e6 	bl	2280 <fwp_trap>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_task_dispose>:
    3af0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3af4:	910003fd 	mov	x29, sp
    3af8:	f9000bf3 	str	x19, [sp, #16]
    3afc:	aa0003f3 	mov	x19, x0
    3b00:	39414000 	ldrb	w0, [x0, #80]
    3b04:	36000720 	tbz	w0, #0, 3be8 <fwp_task_dispose+0xf8>
    3b08:	f9400a60 	ldr	x0, [x19, #16]
    3b0c:	b50006e0 	cbnz	x0, 3be8 <fwp_task_dispose+0xf8>
    3b10:	a9478660 	ldp	x0, x1, [x19, #120]
    3b14:	39014e7f 	strb	wzr, [x19, #83]
    3b18:	f9003e7f 	str	xzr, [x19, #120]
    3b1c:	f100003f 	cmp	x1, #0x0
    3b20:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3b24:	54000040 	b.eq	3b2c <fwp_task_dispose+0x3c>  // b.none
    3b28:	d63f0020 	blr	x1
    3b2c:	f9405660 	ldr	x0, [x19, #168]
    3b30:	97fffd34 	bl	3000 <fwp_mem_free>
    3b34:	f900567f 	str	xzr, [x19, #168]
    3b38:	b9405e60 	ldr	w0, [x19, #92]
    3b3c:	7100041f 	cmp	w0, #0x1
    3b40:	54000420 	b.eq	3bc4 <fwp_task_dispose+0xd4>  // b.none
    3b44:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    3b48:	9115c042 	add	x2, x2, #0x570
    3b4c:	f949d840 	ldr	x0, [x2, #5040]
    3b50:	f949ec41 	ldr	x1, [x2, #5080]
    3b54:	cb000260 	sub	x0, x19, x0
    3b58:	eb01401f 	cmp	x0, x1, lsl #16
    3b5c:	540002e2 	b.cs	3bb8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3b60:	d350fc01 	lsr	x1, x0, #16
    3b64:	f949fc44 	ldr	x4, [x2, #5112]
    3b68:	8b010821 	add	x1, x1, x1, lsl #2
    3b6c:	d37df021 	lsl	x1, x1, #3
    3b70:	8b010083 	add	x3, x4, x1
    3b74:	f9401062 	ldr	x2, [x3, #32]
    3b78:	b4000202 	cbz	x2, 3bb8 <fwp_task_dispose+0xc8>
    3b7c:	38616881 	ldrb	w1, [x4, x1]
    3b80:	7100083f 	cmp	w1, #0x2
    3b84:	54000280 	b.eq	3bd4 <fwp_task_dispose+0xe4>  // b.none
    3b88:	7100043f 	cmp	w1, #0x1
    3b8c:	54000161 	b.ne	3bb8 <fwp_task_dispose+0xc8>  // b.any
    3b90:	29430464 	ldp	w4, w1, [x3, #24]
    3b94:	92403c00 	and	x0, x0, #0xffff
    3b98:	9b047c00 	mul	x0, x0, x4
    3b9c:	d360fc00 	lsr	x0, x0, #32
    3ba0:	eb01001f 	cmp	x0, x1
    3ba4:	540000a2 	b.cs	3bb8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3ba8:	8b000042 	add	x2, x2, x0
    3bac:	39400040 	ldrb	w0, [x2]
    3bb0:	7100041f 	cmp	w0, #0x1
    3bb4:	54000080 	b.eq	3bc4 <fwp_task_dispose+0xd4>  // b.none
    3bb8:	f9400bf3 	ldr	x19, [sp, #16]
    3bbc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bc0:	d65f03c0 	ret
    3bc4:	aa1303e0 	mov	x0, x19
    3bc8:	f9400bf3 	ldr	x19, [sp, #16]
    3bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bd0:	17fffd0c 	b	3000 <fwp_mem_free>
    3bd4:	72003c1f 	tst	w0, #0xffff
    3bd8:	54fffea0 	b.eq	3bac <fwp_task_dispose+0xbc>  // b.none
    3bdc:	f9400bf3 	ldr	x19, [sp, #16]
    3be0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3be4:	d65f03c0 	ret
    3be8:	97fff65a 	bl	1550 <abort@plt>
    3bec:	d503201f 	nop

0000000000003bf0 <fwp_free_zombie>:
    3bf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bf4:	910003fd 	mov	x29, sp
    3bf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3bfc:	b00000f4 	adrp	x20, 20000 <__data_start>
    3c00:	91024281 	add	x1, x20, #0x90
    3c04:	f9403433 	ldr	x19, [x1, #104]
    3c08:	b4000333 	cbz	x19, 3c6c <fwp_free_zombie+0x7c>
    3c0c:	f9400420 	ldr	x0, [x1, #8]
    3c10:	eb00027f 	cmp	x19, x0
    3c14:	540002c0 	b.eq	3c6c <fwp_free_zombie+0x7c>  // b.none
    3c18:	b9407022 	ldr	w2, [x1, #112]
    3c1c:	f9400a60 	ldr	x0, [x19, #16]
    3c20:	7100fc5f 	cmp	w2, #0x3f
    3c24:	5400078c 	b.gt	3d14 <fwp_free_zombie+0x124>
    3c28:	91020023 	add	x3, x1, #0x80
    3c2c:	11000444 	add	w4, w2, #0x1
    3c30:	b9007024 	str	w4, [x1, #112]
    3c34:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3c38:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3c3c:	a9530261 	ldp	x1, x0, [x19, #304]
    3c40:	b4000741 	cbz	x1, 3d28 <fwp_free_zombie+0x138>
    3c44:	f9009c20 	str	x0, [x1, #312]
    3c48:	b4000040 	cbz	x0, 3c50 <fwp_free_zombie+0x60>
    3c4c:	f9009801 	str	x1, [x0, #304]
    3c50:	91024294 	add	x20, x20, #0x90
    3c54:	b9405e60 	ldr	w0, [x19, #92]
    3c58:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3c5c:	f900369f 	str	xzr, [x20, #104]
    3c60:	34000140 	cbz	w0, 3c88 <fwp_free_zombie+0x98>
    3c64:	7100041f 	cmp	w0, #0x1
    3c68:	54000080 	b.eq	3c78 <fwp_free_zombie+0x88>  // b.none
    3c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c74:	d65f03c0 	ret
    3c78:	aa1303e0 	mov	x0, x19
    3c7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c84:	17ffff9b 	b	3af0 <fwp_task_dispose>
    3c88:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xc70>
    3c8c:	9115c082 	add	x2, x4, #0x570
    3c90:	f949d841 	ldr	x1, [x2, #5040]
    3c94:	f949ec40 	ldr	x0, [x2, #5080]
    3c98:	cb010261 	sub	x1, x19, x1
    3c9c:	eb00403f 	cmp	x1, x0, lsl #16
    3ca0:	54fffe62 	b.cs	3c6c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3ca4:	d350fc20 	lsr	x0, x1, #16
    3ca8:	f949fc43 	ldr	x3, [x2, #5112]
    3cac:	8b000800 	add	x0, x0, x0, lsl #2
    3cb0:	d37df000 	lsl	x0, x0, #3
    3cb4:	8b000062 	add	x2, x3, x0
    3cb8:	f9401054 	ldr	x20, [x2, #32]
    3cbc:	b4fffd94 	cbz	x20, 3c6c <fwp_free_zombie+0x7c>
    3cc0:	38606860 	ldrb	w0, [x3, x0]
    3cc4:	7100081f 	cmp	w0, #0x2
    3cc8:	54000360 	b.eq	3d34 <fwp_free_zombie+0x144>  // b.none
    3ccc:	7100041f 	cmp	w0, #0x1
    3cd0:	54fffce1 	b.ne	3c6c <fwp_free_zombie+0x7c>  // b.any
    3cd4:	29430043 	ldp	w3, w0, [x2, #24]
    3cd8:	92403c21 	and	x1, x1, #0xffff
    3cdc:	9b037c21 	mul	x1, x1, x3
    3ce0:	d360fc21 	lsr	x1, x1, #32
    3ce4:	eb00003f 	cmp	x1, x0
    3ce8:	54fffc22 	b.cs	3c6c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3cec:	8b010294 	add	x20, x20, x1
    3cf0:	39400280 	ldrb	w0, [x20]
    3cf4:	34fffbc0 	cbz	w0, 3c6c <fwp_free_zombie+0x7c>
    3cf8:	7100041f 	cmp	w0, #0x1
    3cfc:	54fffbe0 	b.eq	3c78 <fwp_free_zombie+0x88>  // b.none
    3d00:	7103fc1f 	cmp	w0, #0xff
    3d04:	540001e0 	b.eq	3d40 <fwp_free_zombie+0x150>  // b.none
    3d08:	51000400 	sub	w0, w0, #0x1
    3d0c:	39000280 	strb	w0, [x20]
    3d10:	17ffffd7 	b	3c6c <fwp_free_zombie+0x7c>
    3d14:	f9400e61 	ldr	x1, [x19, #24]
    3d18:	97fff642 	bl	1620 <munmap@plt>
    3d1c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3d20:	a9530261 	ldp	x1, x0, [x19, #304]
    3d24:	b5fff901 	cbnz	x1, 3c44 <fwp_free_zombie+0x54>
    3d28:	91024282 	add	x2, x20, #0x90
    3d2c:	f9014040 	str	x0, [x2, #640]
    3d30:	17ffffc6 	b	3c48 <fwp_free_zombie+0x58>
    3d34:	72003c3f 	tst	w1, #0xffff
    3d38:	54fff9a1 	b.ne	3c6c <fwp_free_zombie+0x7c>  // b.any
    3d3c:	17ffffed 	b	3cf0 <fwp_free_zombie+0x100>
    3d40:	ca544680 	eor	x0, x20, x20, lsr #17
    3d44:	9115c084 	add	x4, x4, #0x570
    3d48:	ca402400 	eor	x0, x0, x0, lsr #9
    3d4c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3d50:	f94a2400 	ldr	x0, [x0, #5192]
    3d54:	b5000080 	cbnz	x0, 3d64 <fwp_free_zombie+0x174>
    3d58:	14000010 	b	3d98 <fwp_free_zombie+0x1a8>
    3d5c:	f9400800 	ldr	x0, [x0, #16]
    3d60:	b40001c0 	cbz	x0, 3d98 <fwp_free_zombie+0x1a8>
    3d64:	f9400001 	ldr	x1, [x0]
    3d68:	eb14003f 	cmp	x1, x20
    3d6c:	54ffff81 	b.ne	3d5c <fwp_free_zombie+0x16c>  // b.any
    3d70:	f9400401 	ldr	x1, [x0, #8]
    3d74:	d1000421 	sub	x1, x1, #0x1
    3d78:	f9000401 	str	x1, [x0, #8]
    3d7c:	f103f83f 	cmp	x1, #0xfe
    3d80:	54fff761 	b.ne	3c6c <fwp_free_zombie+0x7c>  // b.any
    3d84:	aa1403e0 	mov	x0, x20
    3d88:	97fffbff 	bl	2d84 <fwp_rc_forget_slot>
    3d8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3d90:	39000280 	strb	w0, [x20]
    3d94:	17ffffb6 	b	3c6c <fwp_free_zombie+0x7c>
    3d98:	90000020 	adrp	x0, 7000 <atexit>
    3d9c:	910ba000 	add	x0, x0, #0x2e8
    3da0:	97fff938 	bl	2280 <fwp_trap>

0000000000003da4 <fwp_block>:
    3da4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3da8:	910003fd 	mov	x29, sp
    3dac:	a90153f3 	stp	x19, x20, [sp, #16]
    3db0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3db4:	91024274 	add	x20, x19, #0x90
    3db8:	f9401a82 	ldr	x2, [x20, #48]
    3dbc:	b4000622 	cbz	x2, 3e80 <fwp_block+0xdc>
    3dc0:	91024261 	add	x1, x19, #0x90
    3dc4:	f9408040 	ldr	x0, [x2, #256]
    3dc8:	f9001820 	str	x0, [x1, #48]
    3dcc:	b4000680 	cbz	x0, 3e9c <fwp_block+0xf8>
    3dd0:	91024263 	add	x3, x19, #0x90
    3dd4:	3901505f 	strb	wzr, [x2, #84]
    3dd8:	f9400464 	ldr	x4, [x3, #8]
    3ddc:	eb02009f 	cmp	x4, x2
    3de0:	54000440 	b.eq	3e68 <fwp_block+0xc4>  // b.none
    3de4:	f9414465 	ldr	x5, [x3, #648]
    3de8:	f9000462 	str	x2, [x3, #8]
    3dec:	f9400441 	ldr	x1, [x2, #8]
    3df0:	f9004885 	str	x5, [x4, #144]
    3df4:	f9414865 	ldr	x5, [x3, #656]
    3df8:	f9004c85 	str	x5, [x4, #152]
    3dfc:	f9414c65 	ldr	x5, [x3, #664]
    3e00:	f9005085 	str	x5, [x4, #160]
    3e04:	f9415065 	ldr	x5, [x3, #672]
    3e08:	f9005485 	str	x5, [x4, #168]
    3e0c:	f9415465 	ldr	x5, [x3, #680]
    3e10:	f9005885 	str	x5, [x4, #176]
    3e14:	f9415865 	ldr	x5, [x3, #688]
    3e18:	f9005c85 	str	x5, [x4, #184]
    3e1c:	f9415c65 	ldr	x5, [x3, #696]
    3e20:	f9006085 	str	x5, [x4, #192]
    3e24:	f9400480 	ldr	x0, [x4, #8]
    3e28:	f9404844 	ldr	x4, [x2, #144]
    3e2c:	f9014464 	str	x4, [x3, #648]
    3e30:	f9404c44 	ldr	x4, [x2, #152]
    3e34:	f9014864 	str	x4, [x3, #656]
    3e38:	f9405044 	ldr	x4, [x2, #160]
    3e3c:	f9014c64 	str	x4, [x3, #664]
    3e40:	f9405444 	ldr	x4, [x2, #168]
    3e44:	f9015064 	str	x4, [x3, #672]
    3e48:	f9405844 	ldr	x4, [x2, #176]
    3e4c:	f9015464 	str	x4, [x3, #680]
    3e50:	a94b8844 	ldp	x4, x2, [x2, #184]
    3e54:	f9015864 	str	x4, [x3, #688]
    3e58:	f9015c62 	str	x2, [x3, #696]
    3e5c:	97fff5c1 	bl	1560 <swapcontext@plt>
    3e60:	97ffff64 	bl	3bf0 <fwp_free_zombie>
    3e64:	d503201f 	nop
    3e68:	91024260 	add	x0, x19, #0x90
    3e6c:	b942c000 	ldr	w0, [x0, #704]
    3e70:	340001a0 	cbz	w0, 3ea4 <fwp_block+0x100>
    3e74:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3e7c:	d65f03c0 	ret
    3e80:	97fffb34 	bl	2b50 <fwp_poll_events>
    3e84:	f9401a82 	ldr	x2, [x20, #48]
    3e88:	b4ffffc2 	cbz	x2, 3e80 <fwp_block+0xdc>
    3e8c:	91024261 	add	x1, x19, #0x90
    3e90:	f9408040 	ldr	x0, [x2, #256]
    3e94:	f9001820 	str	x0, [x1, #48]
    3e98:	b5fff9c0 	cbnz	x0, 3dd0 <fwp_block+0x2c>
    3e9c:	f900143f 	str	xzr, [x1, #40]
    3ea0:	17ffffcc 	b	3dd0 <fwp_block+0x2c>
    3ea4:	90000020 	adrp	x0, 7000 <atexit>
    3ea8:	910c8000 	add	x0, x0, #0x320
    3eac:	97fff5f9 	bl	1690 <getenv@plt>
    3eb0:	5284e202 	mov	w2, #0x2710                	// #10000
    3eb4:	b4000060 	cbz	x0, 3ec0 <fwp_block+0x11c>
    3eb8:	39400001 	ldrb	w1, [x0]
    3ebc:	350000c1 	cbnz	w1, 3ed4 <fwp_block+0x130>
    3ec0:	91024273 	add	x19, x19, #0x90
    3ec4:	b902c262 	str	w2, [x19, #704]
    3ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ed0:	d65f03c0 	ret
    3ed4:	52800142 	mov	w2, #0xa                   	// #10
    3ed8:	d2800001 	mov	x1, #0x0                   	// #0
    3edc:	97fff53d 	bl	13d0 <strtoll@plt>
    3ee0:	d1000403 	sub	x3, x0, #0x1
    3ee4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3ee8:	eb02007f 	cmp	x3, x2
    3eec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3ef0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3ef4:	17fffff3 	b	3ec0 <fwp_block+0x11c>
    3ef8:	d503201f 	nop
    3efc:	d503201f 	nop

0000000000003f00 <fwp_write.constprop.0>:
    3f00:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3f04:	910003fd 	mov	x29, sp
    3f08:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b78>
    3f0c:	f947f463 	ldr	x3, [x3, #4072]
    3f10:	a90153f3 	stp	x19, x20, [sp, #16]
    3f14:	d10943ff 	sub	sp, sp, #0x250
    3f18:	aa0003f4 	mov	x20, x0
    3f1c:	b9400040 	ldr	w0, [x2]
    3f20:	aa0103f3 	mov	x19, x1
    3f24:	f9400061 	ldr	x1, [x3]
    3f28:	f90127e1 	str	x1, [sp, #584]
    3f2c:	d2800001 	mov	x1, #0x0                   	// #0
    3f30:	7100641f 	cmp	w0, #0x19
    3f34:	540003e8 	b.hi	3fb0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3f38:	90000021 	adrp	x1, 7000 <atexit>
    3f3c:	911a8021 	add	x1, x1, #0x6a0
    3f40:	f9013bf5 	str	x21, [sp, #624]
    3f44:	f9013ff6 	str	x22, [sp, #632]
    3f48:	f90153fb 	str	x27, [sp, #672]
    3f4c:	f90157fc 	str	x28, [sp, #680]
    3f50:	aa0203fc 	mov	x28, x2
    3f54:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3f58:	10000062 	adr	x2, 3f64 <fwp_write.constprop.0+0x64>
    3f5c:	8b21a841 	add	x1, x2, w1, sxth #2
    3f60:	d61f0020 	br	x1
    3f64:	910123e0 	add	x0, sp, #0x48
    3f68:	aa1303e5 	mov	x5, x19
    3f6c:	90000024 	adrp	x4, 7000 <atexit>
    3f70:	aa0003f3 	mov	x19, x0
    3f74:	910da084 	add	x4, x4, #0x368
    3f78:	d2804003 	mov	x3, #0x200                 	// #512
    3f7c:	aa0303e1 	mov	x1, x3
    3f80:	52800042 	mov	w2, #0x2                   	// #2
    3f84:	97fff53b 	bl	1470 <__snprintf_chk@plt>
    3f88:	aa1303e0 	mov	x0, x19
    3f8c:	97fff501 	bl	1390 <strlen@plt>
    3f90:	aa1303e1 	mov	x1, x19
    3f94:	aa0003e2 	mov	x2, x0
    3f98:	aa1403e0 	mov	x0, x20
    3f9c:	97fff85d 	bl	2110 <buf_put>
    3fa0:	f9413bf5 	ldr	x21, [sp, #624]
    3fa4:	f9413ff6 	ldr	x22, [sp, #632]
    3fa8:	f94153fb 	ldr	x27, [sp, #672]
    3fac:	f94157fc 	ldr	x28, [sp, #680]
    3fb0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    3fb4:	f947f400 	ldr	x0, [x0, #4072]
    3fb8:	f94127e2 	ldr	x2, [sp, #584]
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	eb010042 	subs	x2, x2, x1
    3fc4:	d2800001 	mov	x1, #0x0                   	// #0
    3fc8:	540074a1 	b.ne	4e5c <fwp_write.constprop.0+0xf5c>  // b.any
    3fcc:	910943ff 	add	sp, sp, #0x250
    3fd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fd4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3fd8:	d65f03c0 	ret
    3fdc:	910123e0 	add	x0, sp, #0x48
    3fe0:	aa1303e5 	mov	x5, x19
    3fe4:	90000024 	adrp	x4, 7000 <atexit>
    3fe8:	aa0003f3 	mov	x19, x0
    3fec:	910d8084 	add	x4, x4, #0x360
    3ff0:	d2804003 	mov	x3, #0x200                 	// #512
    3ff4:	17ffffe2 	b	3f7c <fwp_write.constprop.0+0x7c>
    3ff8:	71004c1f 	cmp	w0, #0x13
    3ffc:	90000021 	adrp	x1, 7000 <atexit>
    4000:	f0000000 	adrp	x0, 7000 <atexit>
    4004:	910d6021 	add	x1, x1, #0x358
    4008:	910d4000 	add	x0, x0, #0x350
    400c:	d2800082 	mov	x2, #0x4                   	// #4
    4010:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    4014:	aa1403e0 	mov	x0, x20
    4018:	f90143f7 	str	x23, [sp, #640]
    401c:	d2800016 	mov	x22, #0x0                   	// #0
    4020:	f90147f8 	str	x24, [sp, #648]
    4024:	97fff83b 	bl	2110 <buf_put>
    4028:	f9400260 	ldr	x0, [x19]
    402c:	f0000017 	adrp	x23, 7000 <atexit>
    4030:	d2800015 	mov	x21, #0x0                   	// #0
    4034:	910f62f7 	add	x23, x23, #0x3d8
    4038:	b4004e40 	cbz	x0, 4a00 <fwp_write.constprop.0+0xb00>
    403c:	b9400381 	ldr	w1, [x28]
    4040:	aa1403e0 	mov	x0, x20
    4044:	f9401f82 	ldr	x2, [x28, #56]
    4048:	71004c3f 	cmp	w1, #0x13
    404c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4050:	8b010e61 	add	x1, x19, x1, lsl #3
    4054:	f9400421 	ldr	x1, [x1, #8]
    4058:	97ffffaa 	bl	3f00 <fwp_write.constprop.0>
    405c:	b9400380 	ldr	w0, [x28]
    4060:	7100481f 	cmp	w0, #0x12
    4064:	540050c0 	b.eq	4a7c <fwp_write.constprop.0+0xb7c>  // b.none
    4068:	f9400260 	ldr	x0, [x19]
    406c:	910006b5 	add	x21, x21, #0x1
    4070:	91000ad6 	add	x22, x22, #0x2
    4074:	eb0002bf 	cmp	x21, x0
    4078:	54004c42 	b.cs	4a00 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    407c:	aa1703e1 	mov	x1, x23
    4080:	aa1403e0 	mov	x0, x20
    4084:	d2800042 	mov	x2, #0x2                   	// #2
    4088:	97fff822 	bl	2110 <buf_put>
    408c:	17ffffec 	b	403c <fwp_write.constprop.0+0x13c>
    4090:	f0000001 	adrp	x1, 7000 <atexit>
    4094:	910e4021 	add	x1, x1, #0x390
    4098:	d28000c2 	mov	x2, #0x6                   	// #6
    409c:	aa1403e0 	mov	x0, x20
    40a0:	91004273 	add	x19, x19, #0x10
    40a4:	97fff81b 	bl	2110 <buf_put>
    40a8:	aa1303e0 	mov	x0, x19
    40ac:	97fff4b9 	bl	1390 <strlen@plt>
    40b0:	aa1303e1 	mov	x1, x19
    40b4:	aa0003e2 	mov	x2, x0
    40b8:	aa1403e0 	mov	x0, x20
    40bc:	97fff815 	bl	2110 <buf_put>
    40c0:	528007c3 	mov	w3, #0x3e                  	// #62
    40c4:	aa1403e0 	mov	x0, x20
    40c8:	91001fe1 	add	x1, sp, #0x7
    40cc:	d2800022 	mov	x2, #0x1                   	// #1
    40d0:	39001fe3 	strb	w3, [sp, #7]
    40d4:	17ffffb2 	b	3f9c <fwp_write.constprop.0+0x9c>
    40d8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    40dc:	f947f400 	ldr	x0, [x0, #4072]
    40e0:	f94127e2 	ldr	x2, [sp, #584]
    40e4:	f9400001 	ldr	x1, [x0]
    40e8:	eb010042 	subs	x2, x2, x1
    40ec:	d2800001 	mov	x1, #0x0                   	// #0
    40f0:	54006cc1 	b.ne	4e88 <fwp_write.constprop.0+0xf88>  // b.any
    40f4:	f9413bf5 	ldr	x21, [sp, #624]
    40f8:	f0000001 	adrp	x1, 7000 <atexit>
    40fc:	f9413ff6 	ldr	x22, [sp, #632]
    4100:	aa1403e0 	mov	x0, x20
    4104:	910dc021 	add	x1, x1, #0x370
    4108:	d2800142 	mov	x2, #0xa                   	// #10
    410c:	f94153fb 	ldr	x27, [sp, #672]
    4110:	f94157fc 	ldr	x28, [sp, #680]
    4114:	910943ff 	add	sp, sp, #0x250
    4118:	a94153f3 	ldp	x19, x20, [sp, #16]
    411c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4120:	17fff7fc 	b	2110 <buf_put>
    4124:	f9400796 	ldr	x22, [x28, #8]
    4128:	f90143f7 	str	x23, [sp, #640]
    412c:	f90147f8 	str	x24, [sp, #648]
    4130:	b4005816 	cbz	x22, 4c30 <fwp_write.constprop.0+0xd30>
    4134:	aa1603e0 	mov	x0, x22
    4138:	f0000001 	adrp	x1, 7000 <atexit>
    413c:	910fc021 	add	x1, x1, #0x3f0
    4140:	97fff510 	bl	1580 <strcmp@plt>
    4144:	2a0003f5 	mov	w21, w0
    4148:	34005ce0 	cbz	w0, 4ce4 <fwp_write.constprop.0+0xde4>
    414c:	aa1603e0 	mov	x0, x22
    4150:	97fff490 	bl	1390 <strlen@plt>
    4154:	aa1603e1 	mov	x1, x22
    4158:	aa0003e2 	mov	x2, x0
    415c:	aa1403e0 	mov	x0, x20
    4160:	97fff7ec 	bl	2110 <buf_put>
    4164:	52800403 	mov	w3, #0x20                  	// #32
    4168:	91001ff5 	add	x21, sp, #0x7
    416c:	aa1503e1 	mov	x1, x21
    4170:	aa1403e0 	mov	x0, x20
    4174:	d2800022 	mov	x2, #0x1                   	// #1
    4178:	39001fe3 	strb	w3, [sp, #7]
    417c:	97fff7e5 	bl	2110 <buf_put>
    4180:	52800f63 	mov	w3, #0x7b                  	// #123
    4184:	aa1403e0 	mov	x0, x20
    4188:	aa1503e1 	mov	x1, x21
    418c:	d2800022 	mov	x2, #0x1                   	// #1
    4190:	39001fe3 	strb	w3, [sp, #7]
    4194:	97fff7df 	bl	2110 <buf_put>
    4198:	b9401380 	ldr	w0, [x28, #16]
    419c:	52800018 	mov	w24, #0x0                   	// #0
    41a0:	7100001f 	cmp	w0, #0x0
    41a4:	54003d8d 	b.le	4954 <fwp_write.constprop.0+0xa54>
    41a8:	f9014bf9 	str	x25, [sp, #656]
    41ac:	f0000019 	adrp	x25, 7000 <atexit>
    41b0:	91106339 	add	x25, x25, #0x418
    41b4:	f9014ffa 	str	x26, [sp, #664]
    41b8:	f000001a 	adrp	x26, 7000 <atexit>
    41bc:	910f635a 	add	x26, x26, #0x3d8
    41c0:	91002276 	add	x22, x19, #0x8
    41c4:	d2800013 	mov	x19, #0x0                   	// #0
    41c8:	b5004413 	cbnz	x19, 4a48 <fwp_write.constprop.0+0xb48>
    41cc:	d37df277 	lsl	x23, x19, #3
    41d0:	34004238 	cbz	w24, 4a14 <fwp_write.constprop.0+0xb14>
    41d4:	f9401382 	ldr	x2, [x28, #32]
    41d8:	aa1403e0 	mov	x0, x20
    41dc:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    41e0:	91000673 	add	x19, x19, #0x1
    41e4:	f8776842 	ldr	x2, [x2, x23]
    41e8:	97ffff46 	bl	3f00 <fwp_write.constprop.0>
    41ec:	b9401380 	ldr	w0, [x28, #16]
    41f0:	6b13001f 	cmp	w0, w19
    41f4:	54fffeac 	b.gt	41c8 <fwp_write.constprop.0+0x2c8>
    41f8:	f9414bf9 	ldr	x25, [sp, #656]
    41fc:	f9414ffa 	ldr	x26, [sp, #664]
    4200:	34003ab8 	cbz	w24, 4954 <fwp_write.constprop.0+0xa54>
    4204:	52800523 	mov	w3, #0x29                  	// #41
    4208:	aa1503e1 	mov	x1, x21
    420c:	aa1403e0 	mov	x0, x20
    4210:	d2800022 	mov	x2, #0x1                   	// #1
    4214:	39001fe3 	strb	w3, [sp, #7]
    4218:	97fff7be 	bl	2110 <buf_put>
    421c:	f9413bf5 	ldr	x21, [sp, #624]
    4220:	f9413ff6 	ldr	x22, [sp, #632]
    4224:	f94143f7 	ldr	x23, [sp, #640]
    4228:	f94147f8 	ldr	x24, [sp, #648]
    422c:	f94153fb 	ldr	x27, [sp, #672]
    4230:	f94157fc 	ldr	x28, [sp, #680]
    4234:	17ffff5f 	b	3fb0 <fwp_write.constprop.0+0xb0>
    4238:	b9404b95 	ldr	w21, [x28, #72]
    423c:	aa1403e0 	mov	x0, x20
    4240:	93407eb6 	sxtw	x22, w21
    4244:	91000ac1 	add	x1, x22, #0x2
    4248:	97fff77e 	bl	2040 <buf_grow>
    424c:	a9400281 	ldp	x1, x0, [x20]
    4250:	528e8603 	mov	w3, #0x7430                	// #29744
    4254:	78206823 	strh	w3, [x1, x0]
    4258:	8b000022 	add	x2, x1, x0
    425c:	710002bf 	cmp	w21, #0x0
    4260:	54003bcd 	b.le	49d8 <fwp_write.constprop.0+0xad8>
    4264:	110006a3 	add	w3, w21, #0x1
    4268:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    426c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4270:	91000449 	add	x9, x2, #0x1
    4274:	8b23c043 	add	x3, x2, w3, sxtw
    4278:	f28aaac6 	movk	x6, #0x5556
    427c:	f2955568 	movk	x8, #0xaaab
    4280:	1400000d 	b	42b4 <fwp_write.constprop.0+0x3b4>
    4284:	d2800021 	mov	x1, #0x1                   	// #1
    4288:	528005a5 	mov	w5, #0x2d                  	// #45
    428c:	f100001f 	cmp	x0, #0x0
    4290:	9b467e60 	smulh	x0, x19, x6
    4294:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    4298:	381ff465 	strb	w5, [x3], #-1
    429c:	cb040000 	sub	x0, x0, x4
    42a0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    42a4:	cb020000 	sub	x0, x0, x2
    42a8:	8b010013 	add	x19, x0, x1
    42ac:	eb03013f 	cmp	x9, x3
    42b0:	54003940 	b.eq	49d8 <fwp_write.constprop.0+0xad8>  // b.none
    42b4:	9b467e60 	smulh	x0, x19, x6
    42b8:	937ffe64 	asr	x4, x19, #63
    42bc:	52800605 	mov	w5, #0x30                  	// #48
    42c0:	cb040000 	sub	x0, x0, x4
    42c4:	8b000400 	add	x0, x0, x0, lsl #1
    42c8:	cb000260 	sub	x0, x19, x0
    42cc:	91000c01 	add	x1, x0, #0x3
    42d0:	9bc87c22 	umulh	x2, x1, x8
    42d4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    42d8:	8b4204e2 	add	x2, x7, x2, lsr #1
    42dc:	eb020021 	subs	x1, x1, x2
    42e0:	54fffd60 	b.eq	428c <fwp_write.constprop.0+0x38c>  // b.none
    42e4:	f100043f 	cmp	x1, #0x1
    42e8:	54fffce1 	b.ne	4284 <fwp_write.constprop.0+0x384>  // b.any
    42ec:	d2800001 	mov	x1, #0x0                   	// #0
    42f0:	52800565 	mov	w5, #0x2b                  	// #43
    42f4:	17ffffe6 	b	428c <fwp_write.constprop.0+0x38c>
    42f8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    42fc:	f947f400 	ldr	x0, [x0, #4072]
    4300:	f94127e2 	ldr	x2, [sp, #584]
    4304:	f9400001 	ldr	x1, [x0]
    4308:	eb010042 	subs	x2, x2, x1
    430c:	d2800001 	mov	x1, #0x0                   	// #0
    4310:	54005bc1 	b.ne	4e88 <fwp_write.constprop.0+0xf88>  // b.any
    4314:	f9413bf5 	ldr	x21, [sp, #624]
    4318:	f0000001 	adrp	x1, 7000 <atexit>
    431c:	f9413ff6 	ldr	x22, [sp, #632]
    4320:	aa1403e0 	mov	x0, x20
    4324:	910e0021 	add	x1, x1, #0x380
    4328:	d2800102 	mov	x2, #0x8                   	// #8
    432c:	17ffff78 	b	410c <fwp_write.constprop.0+0x20c>
    4330:	aa1403e0 	mov	x0, x20
    4334:	f0000001 	adrp	x1, 7000 <atexit>
    4338:	d28000c2 	mov	x2, #0x6                   	// #6
    433c:	910f8021 	add	x1, x1, #0x3e0
    4340:	97fff774 	bl	2110 <buf_put>
    4344:	d2800015 	mov	x21, #0x0                   	// #0
    4348:	f9400263 	ldr	x3, [x19]
    434c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4350:	540026a0 	b.eq	4824 <fwp_write.constprop.0+0x924>  // b.none
    4354:	f9401f82 	ldr	x2, [x28, #56]
    4358:	f90143f7 	str	x23, [sp, #640]
    435c:	f90147f8 	str	x24, [sp, #648]
    4360:	d2800857 	mov	x23, #0x42                  	// #66
    4364:	f9014bf9 	str	x25, [sp, #656]
    4368:	f0000016 	adrp	x22, 7000 <atexit>
    436c:	f9014ffa 	str	x26, [sp, #664]
    4370:	910f62d6 	add	x22, x22, #0x3d8
    4374:	d2800038 	mov	x24, #0x1                   	// #1
    4378:	f2a18017 	movk	x23, #0xc00, lsl #16
    437c:	d2809099 	mov	x25, #0x484                 	// #1156
    4380:	b4000482 	cbz	x2, 4410 <fwp_write.constprop.0+0x510>
    4384:	b9400040 	ldr	w0, [x2]
    4388:	7100701f 	cmp	w0, #0x1c
    438c:	540042e0 	b.eq	4be8 <fwp_write.constprop.0+0xce8>  // b.none
    4390:	71006c1f 	cmp	w0, #0x1b
    4394:	540003e8 	b.hi	4410 <fwp_write.constprop.0+0x510>  // b.pmore
    4398:	9ac02301 	lsl	x1, x24, x0
    439c:	ea17003f 	tst	x1, x23
    43a0:	54003f21 	b.ne	4b84 <fwp_write.constprop.0+0xc84>  // b.any
    43a4:	ea19003f 	tst	x1, x25
    43a8:	54003da1 	b.ne	4b5c <fwp_write.constprop.0+0xc5c>  // b.any
    43ac:	d2800425 	mov	x5, #0x21                  	// #33
    43b0:	ea05003f 	tst	x1, x5
    43b4:	540002e0 	b.eq	4410 <fwp_write.constprop.0+0x510>  // b.none
    43b8:	b7f84743 	tbnz	x3, #63, 4ca0 <fwp_write.constprop.0+0xda0>
    43bc:	91002261 	add	x1, x19, #0x8
    43c0:	8b150021 	add	x1, x1, x21
    43c4:	39400021 	ldrb	w1, [x1]
    43c8:	7100001f 	cmp	w0, #0x0
    43cc:	93401c23 	sxtb	x3, w1
    43d0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    43d4:	d503201f 	nop
    43d8:	aa1403e0 	mov	x0, x20
    43dc:	97fffec9 	bl	3f00 <fwp_write.constprop.0>
    43e0:	f9400260 	ldr	x0, [x19]
    43e4:	910006b5 	add	x21, x21, #0x1
    43e8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    43ec:	eb0002bf 	cmp	x21, x0
    43f0:	54002122 	b.cs	4814 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    43f4:	d2800042 	mov	x2, #0x2                   	// #2
    43f8:	aa1603e1 	mov	x1, x22
    43fc:	aa1403e0 	mov	x0, x20
    4400:	97fff744 	bl	2110 <buf_put>
    4404:	f9401f82 	ldr	x2, [x28, #56]
    4408:	f9400263 	ldr	x3, [x19]
    440c:	b5fffbc2 	cbnz	x2, 4384 <fwp_write.constprop.0+0x484>
    4410:	d37df2a0 	lsl	x0, x21, #3
    4414:	b7f83f43 	tbnz	x3, #63, 4bfc <fwp_write.constprop.0+0xcfc>
    4418:	91002261 	add	x1, x19, #0x8
    441c:	8b000020 	add	x0, x1, x0
    4420:	f9400001 	ldr	x1, [x0]
    4424:	17ffffed 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4428:	a9400e62 	ldp	x2, x3, [x19]
    442c:	b7f83ce3 	tbnz	x3, #63, 4bc8 <fwp_write.constprop.0+0xcc8>
    4430:	910123f5 	add	x21, sp, #0x48
    4434:	aa1503e0 	mov	x0, x21
    4438:	97fff58a 	bl	1a60 <fwp_fmt_u128>
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fff3d4 	bl	1390 <strlen@plt>
    4444:	aa1503e1 	mov	x1, x21
    4448:	aa0003e2 	mov	x2, x0
    444c:	17fffed3 	b	3f98 <fwp_write.constprop.0+0x98>
    4450:	fd015be8 	str	d8, [sp, #688]
    4454:	1e270268 	fmov	s8, w19
    4458:	fd015fe9 	str	d9, [sp, #696]
    445c:	1e282100 	fcmp	s8, s8
    4460:	54004a66 	b.vs	4dac <fwp_write.constprop.0+0xeac>
    4464:	1e20c101 	fabs	s1, s8
    4468:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    446c:	1e270000 	fmov	s0, w0
    4470:	1e202020 	fcmp	s1, s0
    4474:	540034ad 	b.le	4b08 <fwp_write.constprop.0+0xc08>
    4478:	1e202118 	fcmpe	s8, #0.0
    447c:	f0000002 	adrp	x2, 7000 <atexit>
    4480:	91050042 	add	x2, x2, #0x140
    4484:	910123f5 	add	x21, sp, #0x48
    4488:	f0000001 	adrp	x1, 7000 <atexit>
    448c:	910cc021 	add	x1, x1, #0x330
    4490:	aa1503e0 	mov	x0, x21
    4494:	9a81c041 	csel	x1, x2, x1, gt
    4498:	97fff46a 	bl	1640 <strcpy@plt>
    449c:	d503201f 	nop
    44a0:	aa1503e0 	mov	x0, x21
    44a4:	97fff3bb 	bl	1390 <strlen@plt>
    44a8:	aa1503e1 	mov	x1, x21
    44ac:	aa0003e2 	mov	x2, x0
    44b0:	aa1403e0 	mov	x0, x20
    44b4:	97fff717 	bl	2110 <buf_put>
    44b8:	f9413bf5 	ldr	x21, [sp, #624]
    44bc:	f9413ff6 	ldr	x22, [sp, #632]
    44c0:	f94153fb 	ldr	x27, [sp, #672]
    44c4:	f94157fc 	ldr	x28, [sp, #680]
    44c8:	fd415be8 	ldr	d8, [sp, #688]
    44cc:	fd415fe9 	ldr	d9, [sp, #696]
    44d0:	17fffeb8 	b	3fb0 <fwp_write.constprop.0+0xb0>
    44d4:	f90143f7 	str	x23, [sp, #640]
    44d8:	52800443 	mov	w3, #0x22                  	// #34
    44dc:	f90147f8 	str	x24, [sp, #648]
    44e0:	91001ff5 	add	x21, sp, #0x7
    44e4:	aa1503e1 	mov	x1, x21
    44e8:	aa1403e0 	mov	x0, x20
    44ec:	f8408677 	ldr	x23, [x19], #8
    44f0:	d2800022 	mov	x2, #0x1                   	// #1
    44f4:	39001fe3 	strb	w3, [sp, #7]
    44f8:	97fff706 	bl	2110 <buf_put>
    44fc:	8b1302f6 	add	x22, x23, x19
    4500:	b4002657 	cbz	x23, 49c8 <fwp_write.constprop.0+0xac8>
    4504:	f0000018 	adrp	x24, 7000 <atexit>
    4508:	910e6318 	add	x24, x24, #0x398
    450c:	f9014bf9 	str	x25, [sp, #656]
    4510:	f0000019 	adrp	x25, 7000 <atexit>
    4514:	910ee339 	add	x25, x25, #0x3b8
    4518:	f9014ffa 	str	x26, [sp, #664]
    451c:	1400000e 	b	4554 <fwp_write.constprop.0+0x654>
    4520:	710024bf 	cmp	w5, #0x9
    4524:	54002380 	b.eq	4994 <fwp_write.constprop.0+0xa94>  // b.none
    4528:	710028bf 	cmp	w5, #0xa
    452c:	54002be1 	b.ne	4aa8 <fwp_write.constprop.0+0xba8>  // b.any
    4530:	f0000001 	adrp	x1, 7000 <atexit>
    4534:	aa1403e0 	mov	x0, x20
    4538:	910ea021 	add	x1, x1, #0x3a8
    453c:	d2800042 	mov	x2, #0x2                   	// #2
    4540:	97fff6f4 	bl	2110 <buf_put>
    4544:	d503201f 	nop
    4548:	91000673 	add	x19, x19, #0x1
    454c:	eb16027f 	cmp	x19, x22
    4550:	54002380 	b.eq	49c0 <fwp_write.constprop.0+0xac0>  // b.none
    4554:	39400265 	ldrb	w5, [x19]
    4558:	710034bf 	cmp	w5, #0xd
    455c:	54002120 	b.eq	4980 <fwp_write.constprop.0+0xa80>  // b.none
    4560:	54fffe09 	b.ls	4520 <fwp_write.constprop.0+0x620>  // b.plast
    4564:	710088bf 	cmp	w5, #0x22
    4568:	54002220 	b.eq	49ac <fwp_write.constprop.0+0xaac>  // b.none
    456c:	710170bf 	cmp	w5, #0x5c
    4570:	54002ba1 	b.ne	4ae4 <fwp_write.constprop.0+0xbe4>  // b.any
    4574:	aa1403e0 	mov	x0, x20
    4578:	f0000001 	adrp	x1, 7000 <atexit>
    457c:	d2800042 	mov	x2, #0x2                   	// #2
    4580:	910e8021 	add	x1, x1, #0x3a0
    4584:	97fff6e3 	bl	2110 <buf_put>
    4588:	17fffff0 	b	4548 <fwp_write.constprop.0+0x648>
    458c:	fd015be8 	str	d8, [sp, #688]
    4590:	9e670268 	fmov	d8, x19
    4594:	fd015fe9 	str	d9, [sp, #696]
    4598:	1e682100 	fcmp	d8, d8
    459c:	54004086 	b.vs	4dac <fwp_write.constprop.0+0xeac>
    45a0:	1e60c101 	fabs	d1, d8
    45a4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    45a8:	9e670000 	fmov	d0, x0
    45ac:	910123f5 	add	x21, sp, #0x48
    45b0:	52800033 	mov	w19, #0x1                   	// #1
    45b4:	1e602020 	fcmp	d1, d0
    45b8:	540001ad 	b.le	45ec <fwp_write.constprop.0+0x6ec>
    45bc:	1e602118 	fcmpe	d8, #0.0
    45c0:	f0000002 	adrp	x2, 7000 <atexit>
    45c4:	91050042 	add	x2, x2, #0x140
    45c8:	f0000001 	adrp	x1, 7000 <atexit>
    45cc:	910cc021 	add	x1, x1, #0x330
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	9a81c041 	csel	x1, x2, x1, gt
    45d8:	97fff41a 	bl	1640 <strcpy@plt>
    45dc:	17ffffb1 	b	44a0 <fwp_write.constprop.0+0x5a0>
    45e0:	11000673 	add	w19, w19, #0x1
    45e4:	71004a7f 	cmp	w19, #0x12
    45e8:	540031a0 	b.eq	4c1c <fwp_write.constprop.0+0xd1c>  // b.none
    45ec:	1e604100 	fmov	d0, d8
    45f0:	2a1303e1 	mov	w1, w19
    45f4:	aa1503e0 	mov	x0, x21
    45f8:	97fff75a 	bl	2360 <fwp_format_g.constprop.0>
    45fc:	aa1503e0 	mov	x0, x21
    4600:	d2800001 	mov	x1, #0x0                   	// #0
    4604:	97fff377 	bl	13e0 <strtod@plt>
    4608:	1e602100 	fcmp	d8, d0
    460c:	54fffea1 	b.ne	45e0 <fwp_write.constprop.0+0x6e0>  // b.any
    4610:	aa1503e0 	mov	x0, x21
    4614:	97fff6f8 	bl	21f4 <fwp_finish_float>
    4618:	17ffffa2 	b	44a0 <fwp_write.constprop.0+0x5a0>
    461c:	a9400e62 	ldp	x2, x3, [x19]
    4620:	910123f3 	add	x19, sp, #0x48
    4624:	aa1303e0 	mov	x0, x19
    4628:	97fff50e 	bl	1a60 <fwp_fmt_u128>
    462c:	17fffe57 	b	3f88 <fwp_write.constprop.0+0x88>
    4630:	f90143f7 	str	x23, [sp, #640]
    4634:	f90147f8 	str	x24, [sp, #648]
    4638:	2a1303f8 	mov	w24, w19
    463c:	f9014bf9 	str	x25, [sp, #656]
    4640:	f9014ffa 	str	x26, [sp, #664]
    4644:	f13ffe7f 	cmp	x19, #0xfff
    4648:	54000049 	b.ls	4650 <fwp_write.constprop.0+0x750>  // b.plast
    464c:	b9400278 	ldr	w24, [x19]
    4650:	f9400f80 	ldr	x0, [x28, #24]
    4654:	2a1803f5 	mov	w21, w24
    4658:	d37d7f18 	ubfiz	x24, x24, #3, #32
    465c:	d37ef6b9 	lsl	x25, x21, #2
    4660:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4664:	aa1603e0 	mov	x0, x22
    4668:	97fff34a 	bl	1390 <strlen@plt>
    466c:	aa1603e1 	mov	x1, x22
    4670:	aa0003e2 	mov	x2, x0
    4674:	aa1403e0 	mov	x0, x20
    4678:	97fff6a6 	bl	2110 <buf_put>
    467c:	f9401780 	ldr	x0, [x28, #40]
    4680:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4684:	7100001f 	cmp	w0, #0x0
    4688:	5400064d 	b.le	4750 <fwp_write.constprop.0+0x850>
    468c:	91002276 	add	x22, x19, #0x8
    4690:	91001ff5 	add	x21, sp, #0x7
    4694:	d280001b 	mov	x27, #0x0                   	// #0
    4698:	5280041a 	mov	w26, #0x20                  	// #32
    469c:	f9401b80 	ldr	x0, [x28, #48]
    46a0:	aa1503e1 	mov	x1, x21
    46a4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    46a8:	d2800022 	mov	x2, #0x1                   	// #1
    46ac:	f8786805 	ldr	x5, [x0, x24]
    46b0:	aa1403e0 	mov	x0, x20
    46b4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    46b8:	39001ffa 	strb	w26, [sp, #7]
    46bc:	97fff695 	bl	2110 <buf_put>
    46c0:	f13ffeff 	cmp	x23, #0xfff
    46c4:	b9400261 	ldr	w1, [x19]
    46c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    46cc:	7100383f 	cmp	w1, #0xe
    46d0:	54000140 	b.eq	46f8 <fwp_write.constprop.0+0x7f8>  // b.none
    46d4:	7100403f 	cmp	w1, #0x10
    46d8:	54001c20 	b.eq	4a5c <fwp_write.constprop.0+0xb5c>  // b.none
    46dc:	7100283f 	cmp	w1, #0xa
    46e0:	540026e0 	b.eq	4bbc <fwp_write.constprop.0+0xcbc>  // b.none
    46e4:	540013cc 	b.gt	495c <fwp_write.constprop.0+0xa5c>
    46e8:	71000c3f 	cmp	w1, #0x3
    46ec:	540025ec 	b.gt	4ba8 <fwp_write.constprop.0+0xca8>
    46f0:	d37ffee0 	lsr	x0, x23, #63
    46f4:	37f813c1 	tbnz	w1, #31, 496c <fwp_write.constprop.0+0xa6c>
    46f8:	340013a0 	cbz	w0, 496c <fwp_write.constprop.0+0xa6c>
    46fc:	52800503 	mov	w3, #0x28                  	// #40
    4700:	aa1503e1 	mov	x1, x21
    4704:	aa1403e0 	mov	x0, x20
    4708:	d2800022 	mov	x2, #0x1                   	// #1
    470c:	39001fe3 	strb	w3, [sp, #7]
    4710:	97fff680 	bl	2110 <buf_put>
    4714:	aa1303e2 	mov	x2, x19
    4718:	aa1703e1 	mov	x1, x23
    471c:	aa1403e0 	mov	x0, x20
    4720:	97fffdf8 	bl	3f00 <fwp_write.constprop.0>
    4724:	52800523 	mov	w3, #0x29                  	// #41
    4728:	aa1503e1 	mov	x1, x21
    472c:	aa1403e0 	mov	x0, x20
    4730:	d2800022 	mov	x2, #0x1                   	// #1
    4734:	39001fe3 	strb	w3, [sp, #7]
    4738:	97fff676 	bl	2110 <buf_put>
    473c:	f9401780 	ldr	x0, [x28, #40]
    4740:	9100077b 	add	x27, x27, #0x1
    4744:	b8796800 	ldr	w0, [x0, x25]
    4748:	6b1b001f 	cmp	w0, w27
    474c:	54fffa8c 	b.gt	469c <fwp_write.constprop.0+0x79c>
    4750:	f9413bf5 	ldr	x21, [sp, #624]
    4754:	f9413ff6 	ldr	x22, [sp, #632]
    4758:	f94143f7 	ldr	x23, [sp, #640]
    475c:	f94147f8 	ldr	x24, [sp, #648]
    4760:	f9414bf9 	ldr	x25, [sp, #656]
    4764:	f9414ffa 	ldr	x26, [sp, #664]
    4768:	f94153fb 	ldr	x27, [sp, #672]
    476c:	f94157fc 	ldr	x28, [sp, #680]
    4770:	17fffe10 	b	3fb0 <fwp_write.constprop.0+0xb0>
    4774:	aa1403e0 	mov	x0, x20
    4778:	f0000001 	adrp	x1, 7000 <atexit>
    477c:	d28000c2 	mov	x2, #0x6                   	// #6
    4780:	910f2021 	add	x1, x1, #0x3c8
    4784:	97fff663 	bl	2110 <buf_put>
    4788:	f9400260 	ldr	x0, [x19]
    478c:	b40004c0 	cbz	x0, 4824 <fwp_write.constprop.0+0x924>
    4790:	910123f5 	add	x21, sp, #0x48
    4794:	91002276 	add	x22, x19, #0x8
    4798:	f90143f7 	str	x23, [sp, #640]
    479c:	d2800017 	mov	x23, #0x0                   	// #0
    47a0:	f90147f8 	str	x24, [sp, #648]
    47a4:	f0000018 	adrp	x24, 7000 <atexit>
    47a8:	910f4318 	add	x24, x24, #0x3d0
    47ac:	f9014bf9 	str	x25, [sp, #656]
    47b0:	f0000019 	adrp	x25, 7000 <atexit>
    47b4:	910f6339 	add	x25, x25, #0x3d8
    47b8:	f9014ffa 	str	x26, [sp, #664]
    47bc:	14000005 	b	47d0 <fwp_write.constprop.0+0x8d0>
    47c0:	aa1903e1 	mov	x1, x25
    47c4:	aa1403e0 	mov	x0, x20
    47c8:	d2800042 	mov	x2, #0x2                   	// #2
    47cc:	97fff651 	bl	2110 <buf_put>
    47d0:	38776ac5 	ldrb	w5, [x22, x23]
    47d4:	d2804003 	mov	x3, #0x200                 	// #512
    47d8:	aa1803e4 	mov	x4, x24
    47dc:	aa0303e1 	mov	x1, x3
    47e0:	52800042 	mov	w2, #0x2                   	// #2
    47e4:	aa1503e0 	mov	x0, x21
    47e8:	910006f7 	add	x23, x23, #0x1
    47ec:	97fff321 	bl	1470 <__snprintf_chk@plt>
    47f0:	aa1503e0 	mov	x0, x21
    47f4:	97fff2e7 	bl	1390 <strlen@plt>
    47f8:	aa1503e1 	mov	x1, x21
    47fc:	aa0003e2 	mov	x2, x0
    4800:	aa1403e0 	mov	x0, x20
    4804:	97fff643 	bl	2110 <buf_put>
    4808:	f9400260 	ldr	x0, [x19]
    480c:	eb0002ff 	cmp	x23, x0
    4810:	54fffd83 	b.cc	47c0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4814:	f94143f7 	ldr	x23, [sp, #640]
    4818:	f94147f8 	ldr	x24, [sp, #648]
    481c:	f9414bf9 	ldr	x25, [sp, #656]
    4820:	f9414ffa 	ldr	x26, [sp, #664]
    4824:	52800ba3 	mov	w3, #0x5d                  	// #93
    4828:	aa1403e0 	mov	x0, x20
    482c:	91001fe1 	add	x1, sp, #0x7
    4830:	d2800022 	mov	x2, #0x1                   	// #1
    4834:	39001fe3 	strb	w3, [sp, #7]
    4838:	17fffdd9 	b	3f9c <fwp_write.constprop.0+0x9c>
    483c:	52800b63 	mov	w3, #0x5b                  	// #91
    4840:	91001ff5 	add	x21, sp, #0x7
    4844:	aa1503e1 	mov	x1, x21
    4848:	aa1403e0 	mov	x0, x20
    484c:	d2800022 	mov	x2, #0x1                   	// #1
    4850:	f0000016 	adrp	x22, 7000 <atexit>
    4854:	910f62d6 	add	x22, x22, #0x3d8
    4858:	39001fe3 	strb	w3, [sp, #7]
    485c:	97fff62d 	bl	2110 <buf_put>
    4860:	b4000233 	cbz	x19, 48a4 <fwp_write.constprop.0+0x9a4>
    4864:	f9400661 	ldr	x1, [x19, #8]
    4868:	aa1403e0 	mov	x0, x20
    486c:	f9401f82 	ldr	x2, [x28, #56]
    4870:	97fffda4 	bl	3f00 <fwp_write.constprop.0>
    4874:	f9400a73 	ldr	x19, [x19, #16]
    4878:	b4000173 	cbz	x19, 48a4 <fwp_write.constprop.0+0x9a4>
    487c:	aa1603e1 	mov	x1, x22
    4880:	aa1403e0 	mov	x0, x20
    4884:	d2800042 	mov	x2, #0x2                   	// #2
    4888:	97fff622 	bl	2110 <buf_put>
    488c:	f9400661 	ldr	x1, [x19, #8]
    4890:	aa1403e0 	mov	x0, x20
    4894:	f9401f82 	ldr	x2, [x28, #56]
    4898:	97fffd9a 	bl	3f00 <fwp_write.constprop.0>
    489c:	f9400a73 	ldr	x19, [x19, #16]
    48a0:	b5fffef3 	cbnz	x19, 487c <fwp_write.constprop.0+0x97c>
    48a4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48a8:	aa1503e1 	mov	x1, x21
    48ac:	aa1403e0 	mov	x0, x20
    48b0:	d2800022 	mov	x2, #0x1                   	// #1
    48b4:	39001fe3 	strb	w3, [sp, #7]
    48b8:	17fffdb9 	b	3f9c <fwp_write.constprop.0+0x9c>
    48bc:	52800783 	mov	w3, #0x3c                  	// #60
    48c0:	91001ff3 	add	x19, sp, #0x7
    48c4:	aa1303e1 	mov	x1, x19
    48c8:	d2800022 	mov	x2, #0x1                   	// #1
    48cc:	aa1403e0 	mov	x0, x20
    48d0:	39001fe3 	strb	w3, [sp, #7]
    48d4:	97fff60f 	bl	2110 <buf_put>
    48d8:	f9400795 	ldr	x21, [x28, #8]
    48dc:	aa1503e0 	mov	x0, x21
    48e0:	97fff2ac 	bl	1390 <strlen@plt>
    48e4:	aa1503e1 	mov	x1, x21
    48e8:	aa0003e2 	mov	x2, x0
    48ec:	aa1403e0 	mov	x0, x20
    48f0:	97fff608 	bl	2110 <buf_put>
    48f4:	528007c3 	mov	w3, #0x3e                  	// #62
    48f8:	aa1303e1 	mov	x1, x19
    48fc:	aa1403e0 	mov	x0, x20
    4900:	d2800022 	mov	x2, #0x1                   	// #1
    4904:	39001fe3 	strb	w3, [sp, #7]
    4908:	17fffda5 	b	3f9c <fwp_write.constprop.0+0x9c>
    490c:	f100067f 	cmp	x19, #0x1
    4910:	540017e0 	b.eq	4c0c <fwp_write.constprop.0+0xd0c>  // b.none
    4914:	b100067f 	cmn	x19, #0x1
    4918:	54001b00 	b.eq	4c78 <fwp_write.constprop.0+0xd78>  // b.none
    491c:	f0000001 	adrp	x1, 7000 <atexit>
    4920:	910d2021 	add	x1, x1, #0x348
    4924:	d2800022 	mov	x2, #0x1                   	// #1
    4928:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    492c:	f947f400 	ldr	x0, [x0, #4072]
    4930:	f94127e4 	ldr	x4, [sp, #584]
    4934:	f9400003 	ldr	x3, [x0]
    4938:	eb030084 	subs	x4, x4, x3
    493c:	d2800003 	mov	x3, #0x0                   	// #0
    4940:	54002a41 	b.ne	4e88 <fwp_write.constprop.0+0xf88>  // b.any
    4944:	f9413bf5 	ldr	x21, [sp, #624]
    4948:	aa1403e0 	mov	x0, x20
    494c:	f9413ff6 	ldr	x22, [sp, #632]
    4950:	17fffdef 	b	410c <fwp_write.constprop.0+0x20c>
    4954:	52800fa3 	mov	w3, #0x7d                  	// #125
    4958:	17fffe2c 	b	4208 <fwp_write.constprop.0+0x308>
    495c:	f10002ff 	cmp	x23, #0x0
    4960:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4964:	71002c3f 	cmp	w1, #0xb
    4968:	54ffec80 	b.eq	46f8 <fwp_write.constprop.0+0x7f8>  // b.none
    496c:	aa1303e2 	mov	x2, x19
    4970:	aa1703e1 	mov	x1, x23
    4974:	aa1403e0 	mov	x0, x20
    4978:	97fffd62 	bl	3f00 <fwp_write.constprop.0>
    497c:	17ffff70 	b	473c <fwp_write.constprop.0+0x83c>
    4980:	aa1903e1 	mov	x1, x25
    4984:	aa1403e0 	mov	x0, x20
    4988:	d2800042 	mov	x2, #0x2                   	// #2
    498c:	97fff5e1 	bl	2110 <buf_put>
    4990:	17fffeee 	b	4548 <fwp_write.constprop.0+0x648>
    4994:	aa1403e0 	mov	x0, x20
    4998:	f0000001 	adrp	x1, 7000 <atexit>
    499c:	d2800042 	mov	x2, #0x2                   	// #2
    49a0:	910ec021 	add	x1, x1, #0x3b0
    49a4:	97fff5db 	bl	2110 <buf_put>
    49a8:	17fffee8 	b	4548 <fwp_write.constprop.0+0x648>
    49ac:	aa1803e1 	mov	x1, x24
    49b0:	aa1403e0 	mov	x0, x20
    49b4:	d2800042 	mov	x2, #0x2                   	// #2
    49b8:	97fff5d6 	bl	2110 <buf_put>
    49bc:	17fffee3 	b	4548 <fwp_write.constprop.0+0x648>
    49c0:	f9414bf9 	ldr	x25, [sp, #656]
    49c4:	f9414ffa 	ldr	x26, [sp, #664]
    49c8:	aa1503e1 	mov	x1, x21
    49cc:	aa1403e0 	mov	x0, x20
    49d0:	52800443 	mov	w3, #0x22                  	// #34
    49d4:	17fffe0f 	b	4210 <fwp_write.constprop.0+0x310>
    49d8:	a9400281 	ldp	x1, x0, [x20]
    49dc:	91000800 	add	x0, x0, #0x2
    49e0:	8b160000 	add	x0, x0, x22
    49e4:	f9000680 	str	x0, [x20, #8]
    49e8:	3820683f 	strb	wzr, [x1, x0]
    49ec:	f9413bf5 	ldr	x21, [sp, #624]
    49f0:	f9413ff6 	ldr	x22, [sp, #632]
    49f4:	f94153fb 	ldr	x27, [sp, #672]
    49f8:	f94157fc 	ldr	x28, [sp, #680]
    49fc:	17fffd6d 	b	3fb0 <fwp_write.constprop.0+0xb0>
    4a00:	aa1403e0 	mov	x0, x20
    4a04:	91001fe1 	add	x1, sp, #0x7
    4a08:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a0c:	d2800022 	mov	x2, #0x1                   	// #1
    4a10:	17fffe01 	b	4214 <fwp_write.constprop.0+0x314>
    4a14:	f9400f80 	ldr	x0, [x28, #24]
    4a18:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4a1c:	aa1b03e0 	mov	x0, x27
    4a20:	97fff25c 	bl	1390 <strlen@plt>
    4a24:	aa1b03e1 	mov	x1, x27
    4a28:	aa0003e2 	mov	x2, x0
    4a2c:	aa1403e0 	mov	x0, x20
    4a30:	97fff5b8 	bl	2110 <buf_put>
    4a34:	aa1903e1 	mov	x1, x25
    4a38:	aa1403e0 	mov	x0, x20
    4a3c:	d2800062 	mov	x2, #0x3                   	// #3
    4a40:	97fff5b4 	bl	2110 <buf_put>
    4a44:	17fffde4 	b	41d4 <fwp_write.constprop.0+0x2d4>
    4a48:	aa1a03e1 	mov	x1, x26
    4a4c:	aa1403e0 	mov	x0, x20
    4a50:	d2800042 	mov	x2, #0x2                   	// #2
    4a54:	97fff5af 	bl	2110 <buf_put>
    4a58:	17fffddd 	b	41cc <fwp_write.constprop.0+0x2cc>
    4a5c:	f9400660 	ldr	x0, [x19, #8]
    4a60:	b4fff860 	cbz	x0, 496c <fwp_write.constprop.0+0xa6c>
    4a64:	f0000001 	adrp	x1, 7000 <atexit>
    4a68:	910fc021 	add	x1, x1, #0x3f0
    4a6c:	97fff2c5 	bl	1580 <strcmp@plt>
    4a70:	7100001f 	cmp	w0, #0x0
    4a74:	1a9f07e0 	cset	w0, ne	// ne = any
    4a78:	17ffff20 	b	46f8 <fwp_write.constprop.0+0x7f8>
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	d2800042 	mov	x2, #0x2                   	// #2
    4a84:	f0000001 	adrp	x1, 7000 <atexit>
    4a88:	910fa021 	add	x1, x1, #0x3e8
    4a8c:	97fff5a1 	bl	2110 <buf_put>
    4a90:	91004261 	add	x1, x19, #0x10
    4a94:	aa1403e0 	mov	x0, x20
    4a98:	f9402382 	ldr	x2, [x28, #64]
    4a9c:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4aa0:	97fffd18 	bl	3f00 <fwp_write.constprop.0>
    4aa4:	17fffd71 	b	4068 <fwp_write.constprop.0+0x168>
    4aa8:	d2800203 	mov	x3, #0x10                  	// #16
    4aac:	f0000004 	adrp	x4, 7000 <atexit>
    4ab0:	aa0303e1 	mov	x1, x3
    4ab4:	910f0084 	add	x4, x4, #0x3c0
    4ab8:	910123f7 	add	x23, sp, #0x48
    4abc:	52800042 	mov	w2, #0x2                   	// #2
    4ac0:	aa1703e0 	mov	x0, x23
    4ac4:	97fff26b 	bl	1470 <__snprintf_chk@plt>
    4ac8:	aa1703e0 	mov	x0, x23
    4acc:	97fff231 	bl	1390 <strlen@plt>
    4ad0:	aa1703e1 	mov	x1, x23
    4ad4:	aa0003e2 	mov	x2, x0
    4ad8:	aa1403e0 	mov	x0, x20
    4adc:	97fff58d 	bl	2110 <buf_put>
    4ae0:	17fffe9a 	b	4548 <fwp_write.constprop.0+0x648>
    4ae4:	7101fcbf 	cmp	w5, #0x7f
    4ae8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4aec:	54fffde9 	b.ls	4aa8 <fwp_write.constprop.0+0xba8>  // b.plast
    4af0:	aa1503e1 	mov	x1, x21
    4af4:	aa1403e0 	mov	x0, x20
    4af8:	d2800022 	mov	x2, #0x1                   	// #1
    4afc:	39001fe5 	strb	w5, [sp, #7]
    4b00:	97fff584 	bl	2110 <buf_put>
    4b04:	17fffe91 	b	4548 <fwp_write.constprop.0+0x648>
    4b08:	1e22c109 	fcvt	d9, s8
    4b0c:	910123f5 	add	x21, sp, #0x48
    4b10:	52800033 	mov	w19, #0x1                   	// #1
    4b14:	d503201f 	nop
    4b18:	1e604120 	fmov	d0, d9
    4b1c:	2a1303e1 	mov	w1, w19
    4b20:	aa1503e0 	mov	x0, x21
    4b24:	97fff60f 	bl	2360 <fwp_format_g.constprop.0>
    4b28:	aa1503e0 	mov	x0, x21
    4b2c:	d2800001 	mov	x1, #0x0                   	// #0
    4b30:	97fff2a0 	bl	15b0 <strtof@plt>
    4b34:	1e202100 	fcmp	s8, s0
    4b38:	54ffd6c0 	b.eq	4610 <fwp_write.constprop.0+0x710>  // b.none
    4b3c:	11000673 	add	w19, w19, #0x1
    4b40:	71002a7f 	cmp	w19, #0xa
    4b44:	54fffea1 	b.ne	4b18 <fwp_write.constprop.0+0xc18>  // b.any
    4b48:	1e604120 	fmov	d0, d9
    4b4c:	aa1503e0 	mov	x0, x21
    4b50:	52800121 	mov	w1, #0x9                   	// #9
    4b54:	97fff603 	bl	2360 <fwp_format_g.constprop.0>
    4b58:	17fffeae 	b	4610 <fwp_write.constprop.0+0x710>
    4b5c:	d37ef6a1 	lsl	x1, x21, #2
    4b60:	b7f809a3 	tbnz	x3, #63, 4c94 <fwp_write.constprop.0+0xd94>
    4b64:	91002263 	add	x3, x19, #0x8
    4b68:	8b010061 	add	x1, x3, x1
    4b6c:	b9400023 	ldr	w3, [x1]
    4b70:	7100081f 	cmp	w0, #0x2
    4b74:	2a0303e1 	mov	w1, w3
    4b78:	93407c63 	sxtw	x3, w3
    4b7c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4b80:	17fffe16 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4b84:	d37ffaa1 	lsl	x1, x21, #1
    4b88:	b7f80803 	tbnz	x3, #63, 4c88 <fwp_write.constprop.0+0xd88>
    4b8c:	91002263 	add	x3, x19, #0x8
    4b90:	8b010061 	add	x1, x3, x1
    4b94:	79400021 	ldrh	w1, [x1]
    4b98:	7100041f 	cmp	w0, #0x1
    4b9c:	93403c23 	sxth	x3, w1
    4ba0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4ba4:	17fffe0d 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4ba8:	7100103f 	cmp	w1, #0x4
    4bac:	54ffee01 	b.ne	496c <fwp_write.constprop.0+0xa6c>  // b.any
    4bb0:	f94006e0 	ldr	x0, [x23, #8]
    4bb4:	d37ffc00 	lsr	x0, x0, #63
    4bb8:	17fffed0 	b	46f8 <fwp_write.constprop.0+0x7f8>
    4bbc:	710002ff 	cmp	w23, #0x0
    4bc0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4bc4:	17fffecd 	b	46f8 <fwp_write.constprop.0+0x7f8>
    4bc8:	528005a1 	mov	w1, #0x2d                  	// #45
    4bcc:	eb0203e2 	negs	x2, x2
    4bd0:	da0303e3 	ngc	x3, x3
    4bd4:	910127e0 	add	x0, sp, #0x49
    4bd8:	910123f5 	add	x21, sp, #0x48
    4bdc:	390123e1 	strb	w1, [sp, #72]
    4be0:	97fff3a0 	bl	1a60 <fwp_fmt_u128>
    4be4:	17fffe16 	b	443c <fwp_write.constprop.0+0x53c>
    4be8:	d37ceea1 	lsl	x1, x21, #4
    4bec:	b7f80da3 	tbnz	x3, #63, 4da0 <fwp_write.constprop.0+0xea0>
    4bf0:	91002260 	add	x0, x19, #0x8
    4bf4:	8b010001 	add	x1, x0, x1
    4bf8:	17fffdf8 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4bfc:	f9400a61 	ldr	x1, [x19, #16]
    4c00:	8b010000 	add	x0, x0, x1
    4c04:	f9400001 	ldr	x1, [x0]
    4c08:	17fffdf4 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4c0c:	f0000001 	adrp	x1, 7000 <atexit>
    4c10:	d2800042 	mov	x2, #0x2                   	// #2
    4c14:	910ce021 	add	x1, x1, #0x338
    4c18:	17ffff44 	b	4928 <fwp_write.constprop.0+0xa28>
    4c1c:	1e604100 	fmov	d0, d8
    4c20:	aa1503e0 	mov	x0, x21
    4c24:	52800221 	mov	w1, #0x11                  	// #17
    4c28:	97fff5ce 	bl	2360 <fwp_format_g.constprop.0>
    4c2c:	17fffe79 	b	4610 <fwp_write.constprop.0+0x710>
    4c30:	b9401380 	ldr	w0, [x28, #16]
    4c34:	350003c0 	cbnz	w0, 4cac <fwp_write.constprop.0+0xdac>
    4c38:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    4c3c:	f947f400 	ldr	x0, [x0, #4072]
    4c40:	f94127e2 	ldr	x2, [sp, #584]
    4c44:	f9400001 	ldr	x1, [x0]
    4c48:	eb010042 	subs	x2, x2, x1
    4c4c:	d2800001 	mov	x1, #0x0                   	// #0
    4c50:	54001201 	b.ne	4e90 <fwp_write.constprop.0+0xf90>  // b.any
    4c54:	f9413bf5 	ldr	x21, [sp, #624]
    4c58:	f0000001 	adrp	x1, 7000 <atexit>
    4c5c:	f9413ff6 	ldr	x22, [sp, #632]
    4c60:	aa1403e0 	mov	x0, x20
    4c64:	f94143f7 	ldr	x23, [sp, #640]
    4c68:	91104021 	add	x1, x1, #0x410
    4c6c:	f94147f8 	ldr	x24, [sp, #648]
    4c70:	d2800042 	mov	x2, #0x2                   	// #2
    4c74:	17fffd26 	b	410c <fwp_write.constprop.0+0x20c>
    4c78:	f0000001 	adrp	x1, 7000 <atexit>
    4c7c:	d2800042 	mov	x2, #0x2                   	// #2
    4c80:	910d0021 	add	x1, x1, #0x340
    4c84:	17ffff29 	b	4928 <fwp_write.constprop.0+0xa28>
    4c88:	f9400a63 	ldr	x3, [x19, #16]
    4c8c:	8b030021 	add	x1, x1, x3
    4c90:	17ffffc1 	b	4b94 <fwp_write.constprop.0+0xc94>
    4c94:	f9400a63 	ldr	x3, [x19, #16]
    4c98:	8b030021 	add	x1, x1, x3
    4c9c:	17ffffb4 	b	4b6c <fwp_write.constprop.0+0xc6c>
    4ca0:	f9400a61 	ldr	x1, [x19, #16]
    4ca4:	8b0102a1 	add	x1, x21, x1
    4ca8:	17fffdc7 	b	43c4 <fwp_write.constprop.0+0x4c4>
    4cac:	b9404b80 	ldr	w0, [x28, #72]
    4cb0:	91001ff5 	add	x21, sp, #0x7
    4cb4:	34ffa660 	cbz	w0, 4180 <fwp_write.constprop.0+0x280>
    4cb8:	52800503 	mov	w3, #0x28                  	// #40
    4cbc:	aa1403e0 	mov	x0, x20
    4cc0:	aa1503e1 	mov	x1, x21
    4cc4:	d2800022 	mov	x2, #0x1                   	// #1
    4cc8:	39001fe3 	strb	w3, [sp, #7]
    4ccc:	97fff511 	bl	2110 <buf_put>
    4cd0:	b9401380 	ldr	w0, [x28, #16]
    4cd4:	52800038 	mov	w24, #0x1                   	// #1
    4cd8:	7100001f 	cmp	w0, #0x0
    4cdc:	54ffa66c 	b.gt	41a8 <fwp_write.constprop.0+0x2a8>
    4ce0:	17fffd49 	b	4204 <fwp_write.constprop.0+0x304>
    4ce4:	f9014bf9 	str	x25, [sp, #656]
    4ce8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x16b78>
    4cec:	f9014ffa 	str	x26, [sp, #664]
    4cf0:	f9400676 	ldr	x22, [x19, #8]
    4cf4:	912ca333 	add	x19, x25, #0xb28
    4cf8:	91002273 	add	x19, x19, #0x8
    4cfc:	937ffed8 	asr	x24, x22, #63
    4d00:	aa1802c0 	orr	x0, x22, x24
    4d04:	b5000320 	cbnz	x0, 4d68 <fwp_write.constprop.0+0xe68>
    4d08:	110006b5 	add	w21, w21, #0x1
    4d0c:	710016bf 	cmp	w21, #0x5
    4d10:	54ffffc1 	b.ne	4d08 <fwp_write.constprop.0+0xe08>  // b.any
    4d14:	b7f80578 	tbnz	x24, #63, 4dc0 <fwp_write.constprop.0+0xec0>
    4d18:	910023f3 	add	x19, sp, #0x8
    4d1c:	aa1603e2 	mov	x2, x22
    4d20:	aa1303e0 	mov	x0, x19
    4d24:	d2800003 	mov	x3, #0x0                   	// #0
    4d28:	97fff34e 	bl	1a60 <fwp_fmt_u128>
    4d2c:	910123f5 	add	x21, sp, #0x48
    4d30:	f0000003 	adrp	x3, 7000 <atexit>
    4d34:	aa1303e4 	mov	x4, x19
    4d38:	aa1503e0 	mov	x0, x21
    4d3c:	91102063 	add	x3, x3, #0x408
    4d40:	d2804002 	mov	x2, #0x200                 	// #512
    4d44:	52800041 	mov	w1, #0x2                   	// #2
    4d48:	97fff196 	bl	13a0 <__sprintf_chk@plt>
    4d4c:	aa1503e0 	mov	x0, x21
    4d50:	97fff190 	bl	1390 <strlen@plt>
    4d54:	aa1503e1 	mov	x1, x21
    4d58:	aa0003e2 	mov	x2, x0
    4d5c:	aa1403e0 	mov	x0, x20
    4d60:	97fff4ec 	bl	2110 <buf_put>
    4d64:	17fffe7b 	b	4750 <fwp_write.constprop.0+0x850>
    4d68:	f9400277 	ldr	x23, [x19]
    4d6c:	aa1603e0 	mov	x0, x22
    4d70:	aa1803e1 	mov	x1, x24
    4d74:	aa1703e2 	mov	x2, x23
    4d78:	937ffefa 	asr	x26, x23, #63
    4d7c:	aa1a03e3 	mov	x3, x26
    4d80:	940007c4 	bl	6c90 <__modti3>
    4d84:	aa010000 	orr	x0, x0, x1
    4d88:	b40002c0 	cbz	x0, 4de0 <fwp_write.constprop.0+0xee0>
    4d8c:	110006b5 	add	w21, w21, #0x1
    4d90:	91004273 	add	x19, x19, #0x10
    4d94:	710016bf 	cmp	w21, #0x5
    4d98:	54fffe81 	b.ne	4d68 <fwp_write.constprop.0+0xe68>  // b.any
    4d9c:	17ffffde 	b	4d14 <fwp_write.constprop.0+0xe14>
    4da0:	f9400a60 	ldr	x0, [x19, #16]
    4da4:	8b000021 	add	x1, x1, x0
    4da8:	17fffd8c 	b	43d8 <fwp_write.constprop.0+0x4d8>
    4dac:	528c29c0 	mov	w0, #0x614e                	// #24910
    4db0:	910123f5 	add	x21, sp, #0x48
    4db4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4db8:	b9004be0 	str	w0, [sp, #72]
    4dbc:	17fffdb9 	b	44a0 <fwp_write.constprop.0+0x5a0>
    4dc0:	528005a1 	mov	w1, #0x2d                  	// #45
    4dc4:	eb1603e2 	negs	x2, x22
    4dc8:	da1803e3 	ngc	x3, x24
    4dcc:	910027e0 	add	x0, sp, #0x9
    4dd0:	910023f3 	add	x19, sp, #0x8
    4dd4:	390023e1 	strb	w1, [sp, #8]
    4dd8:	97fff322 	bl	1a60 <fwp_fmt_u128>
    4ddc:	17ffffd4 	b	4d2c <fwp_write.constprop.0+0xe2c>
    4de0:	aa1703e2 	mov	x2, x23
    4de4:	aa1a03e3 	mov	x3, x26
    4de8:	aa1603e0 	mov	x0, x22
    4dec:	aa1803e1 	mov	x1, x24
    4df0:	940006c8 	bl	6910 <__divti3>
    4df4:	aa0003e2 	mov	x2, x0
    4df8:	aa0103e3 	mov	x3, x1
    4dfc:	b7f80201 	tbnz	x1, #63, 4e3c <fwp_write.constprop.0+0xf3c>
    4e00:	910023f3 	add	x19, sp, #0x8
    4e04:	aa1303e0 	mov	x0, x19
    4e08:	97fff316 	bl	1a60 <fwp_fmt_u128>
    4e0c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4e10:	912ca339 	add	x25, x25, #0xb28
    4e14:	910123f5 	add	x21, sp, #0x48
    4e18:	aa1303e4 	mov	x4, x19
    4e1c:	aa1503e0 	mov	x0, x21
    4e20:	f0000003 	adrp	x3, 7000 <atexit>
    4e24:	f8616b25 	ldr	x5, [x25, x1]
    4e28:	91100063 	add	x3, x3, #0x400
    4e2c:	d2804002 	mov	x2, #0x200                 	// #512
    4e30:	52800041 	mov	w1, #0x2                   	// #2
    4e34:	97fff15b 	bl	13a0 <__sprintf_chk@plt>
    4e38:	17ffffc5 	b	4d4c <fwp_write.constprop.0+0xe4c>
    4e3c:	528005a4 	mov	w4, #0x2d                  	// #45
    4e40:	eb0003e2 	negs	x2, x0
    4e44:	da0103e3 	ngc	x3, x1
    4e48:	910027e0 	add	x0, sp, #0x9
    4e4c:	910023f3 	add	x19, sp, #0x8
    4e50:	390023e4 	strb	w4, [sp, #8]
    4e54:	97fff303 	bl	1a60 <fwp_fmt_u128>
    4e58:	17ffffed 	b	4e0c <fwp_write.constprop.0+0xf0c>
    4e5c:	f9013bf5 	str	x21, [sp, #624]
    4e60:	f9013ff6 	str	x22, [sp, #632]
    4e64:	f90143f7 	str	x23, [sp, #640]
    4e68:	f90147f8 	str	x24, [sp, #648]
    4e6c:	f9014bf9 	str	x25, [sp, #656]
    4e70:	f9014ffa 	str	x26, [sp, #664]
    4e74:	f90153fb 	str	x27, [sp, #672]
    4e78:	f90157fc 	str	x28, [sp, #680]
    4e7c:	fd015be8 	str	d8, [sp, #688]
    4e80:	fd015fe9 	str	d9, [sp, #696]
    4e84:	97fff19f 	bl	1500 <__stack_chk_fail@plt>
    4e88:	f90143f7 	str	x23, [sp, #640]
    4e8c:	f90147f8 	str	x24, [sp, #648]
    4e90:	f9014bf9 	str	x25, [sp, #656]
    4e94:	f9014ffa 	str	x26, [sp, #664]
    4e98:	fd015be8 	str	d8, [sp, #688]
    4e9c:	fd015fe9 	str	d9, [sp, #696]
    4ea0:	97fff198 	bl	1500 <__stack_chk_fail@plt>

0000000000004ea4 <fwp_main_thread>:
    4ea4:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
    4ea8:	910003fd 	mov	x29, sp
    4eac:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb0:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4eb4:	9115c261 	add	x1, x19, #0x570
    4eb8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    4ebc:	f947f400 	ldr	x0, [x0, #4072]
    4ec0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec4:	d10583ff 	sub	sp, sp, #0x160
    4ec8:	b953a421 	ldr	w1, [x1, #5028]
    4ecc:	f9400002 	ldr	x2, [x0]
    4ed0:	f900afe2 	str	x2, [sp, #344]
    4ed4:	d2800002 	mov	x2, #0x0                   	// #0
    4ed8:	34002961 	cbz	w1, 5404 <fwp_main_thread+0x560>
    4edc:	9115c260 	add	x0, x19, #0x570
    4ee0:	b953a800 	ldr	w0, [x0, #5032]
    4ee4:	35002880 	cbnz	w0, 53f4 <fwp_main_thread+0x550>
    4ee8:	910123e5 	add	x5, sp, #0x48
    4eec:	900000e0 	adrp	x0, 20000 <__data_start>
    4ef0:	900000e2 	adrp	x2, 20000 <__data_start>
    4ef4:	91024015 	add	x21, x0, #0x90
    4ef8:	910e4042 	add	x2, x2, #0x390
    4efc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    4f00:	d2a00024 	mov	x4, #0x10000               	// #65536
    4f04:	910183e0 	add	x0, sp, #0x60
    4f08:	d2800001 	mov	x1, #0x0                   	// #0
    4f0c:	a9010ea5 	stp	x5, x3, [x21, #16]
    4f10:	f9000be0 	str	x0, [sp, #16]
    4f14:	f90013e5 	str	x5, [sp, #32]
    4f18:	f90033e2 	str	x2, [sp, #96]
    4f1c:	b9006bff 	str	wzr, [sp, #104]
    4f20:	f9003be4 	str	x4, [sp, #112]
    4f24:	97fff113 	bl	1370 <sigaltstack@plt>
    4f28:	a91963f7 	stp	x23, x24, [sp, #400]
    4f2c:	3500cc00 	cbnz	w0, 68ac <fwp_main_thread+0x1a08>
    4f30:	4f000400 	movi	v0.4s, #0x0
    4f34:	910323e0 	add	x0, sp, #0xc8
    4f38:	b0ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    4f3c:	91304021 	add	x1, x1, #0xc10
    4f40:	f90063e1 	str	x1, [sp, #192]
    4f44:	52800082 	mov	w2, #0x4                   	// #4
    4f48:	72a10002 	movk	w2, #0x800, lsl #16
    4f4c:	910303f8 	add	x24, sp, #0xc0
    4f50:	3d802000 	str	q0, [x0, #128]
    4f54:	b9014be2 	str	w2, [sp, #328]
    4f58:	ad000000 	stp	q0, q0, [x0]
    4f5c:	ad010000 	stp	q0, q0, [x0, #32]
    4f60:	ad020000 	stp	q0, q0, [x0, #64]
    4f64:	ad030000 	stp	q0, q0, [x0, #96]
    4f68:	97fff156 	bl	14c0 <sigemptyset@plt>
    4f6c:	3500ca00 	cbnz	w0, 68ac <fwp_main_thread+0x1a08>
    4f70:	aa1803e1 	mov	x1, x24
    4f74:	d2800002 	mov	x2, #0x0                   	// #0
    4f78:	52800160 	mov	w0, #0xb                   	// #11
    4f7c:	97fff169 	bl	1520 <sigaction@plt>
    4f80:	3500c960 	cbnz	w0, 68ac <fwp_main_thread+0x1a08>
    4f84:	aa1803e1 	mov	x1, x24
    4f88:	d2800002 	mov	x2, #0x0                   	// #0
    4f8c:	528000e0 	mov	w0, #0x7                   	// #7
    4f90:	97fff164 	bl	1520 <sigaction@plt>
    4f94:	3500c8c0 	cbnz	w0, 68ac <fwp_main_thread+0x1a08>
    4f98:	a91a6bf9 	stp	x25, x26, [sp, #416]
    4f9c:	9115c279 	add	x25, x19, #0x570
    4fa0:	52800034 	mov	w20, #0x1                   	// #1
    4fa4:	b0ffffe0 	adrp	x0, 1000 <__abi_tag+0xd88>
    4fa8:	913c4000 	add	x0, x0, #0xf10
    4fac:	fd4a1320 	ldr	d0, [x25, #5152]
    4fb0:	b90042b4 	str	w20, [x21, #64]
    4fb4:	7e61d800 	ucvtf	d0, d0
    4fb8:	fd002ea0 	str	d0, [x21, #88]
    4fbc:	94000811 	bl	7000 <atexit>
    4fc0:	a91b73fb 	stp	x27, x28, [sp, #432]
    4fc4:	3500c900 	cbnz	w0, 68e4 <fwp_main_thread+0x1a40>
    4fc8:	b942c6a0 	ldr	w0, [x21, #708]
    4fcc:	34002200 	cbz	w0, 540c <fwp_main_thread+0x568>
    4fd0:	900000e0 	adrp	x0, 20000 <__data_start>
    4fd4:	91024019 	add	x25, x0, #0x90
    4fd8:	f9400735 	ldr	x21, [x25, #8]
    4fdc:	b4000d15 	cbz	x21, 517c <fwp_main_thread+0x2d8>
    4fe0:	aa1503f4 	mov	x20, x21
    4fe4:	910102b6 	add	x22, x21, #0x40
    4fe8:	39414ab8 	ldrb	w24, [x21, #82]
    4fec:	52800037 	mov	w23, #0x1                   	// #1
    4ff0:	39014ab7 	strb	w23, [x21, #82]
    4ff4:	f94016a0 	ldr	x0, [x21, #40]
    4ff8:	b4000620 	cbz	x0, 50bc <fwp_main_thread+0x218>
    4ffc:	f94032a1 	ldr	x1, [x21, #96]
    5000:	394146a0 	ldrb	w0, [x21, #81]
    5004:	b4001b61 	cbz	x1, 5370 <fwp_main_thread+0x4cc>
    5008:	36001a20 	tbz	w0, #0, 534c <fwp_main_thread+0x4a8>
    500c:	39414a82 	ldrb	w2, [x20, #82]
    5010:	f94022a0 	ldr	x0, [x21, #64]
    5014:	37001d82 	tbnz	w2, #0, 53c4 <fwp_main_thread+0x520>
    5018:	f9403281 	ldr	x1, [x20, #96]
    501c:	a911fe96 	stp	x22, xzr, [x20, #280]
    5020:	f9009680 	str	x0, [x20, #296]
    5024:	b4000040 	cbz	x0, 502c <fwp_main_thread+0x188>
    5028:	f9009014 	str	x20, [x0, #288]
    502c:	f90022b4 	str	x20, [x21, #64]
    5030:	b4000101 	cbz	x1, 5050 <fwp_main_thread+0x1ac>
    5034:	f9401f20 	ldr	x0, [x25, #56]
    5038:	39015697 	strb	w23, [x20, #85]
    503c:	f9003681 	str	x1, [x20, #104]
    5040:	a910829f 	stp	xzr, x0, [x20, #264]
    5044:	b4000040 	cbz	x0, 504c <fwp_main_thread+0x1a8>
    5048:	f9008414 	str	x20, [x0, #264]
    504c:	f9001f34 	str	x20, [x25, #56]
    5050:	39015a9f 	strb	wzr, [x20, #86]
    5054:	97fffb54 	bl	3da4 <fwp_block>
    5058:	f9408e82 	ldr	x2, [x20, #280]
    505c:	b4000142 	cbz	x2, 5084 <fwp_main_thread+0x1e0>
    5060:	a9520281 	ldp	x1, x0, [x20, #288]
    5064:	b4001bc1 	cbz	x1, 53dc <fwp_main_thread+0x538>
    5068:	f9009420 	str	x0, [x1, #296]
    506c:	f9409680 	ldr	x0, [x20, #296]
    5070:	b4000040 	cbz	x0, 5078 <fwp_main_thread+0x1d4>
    5074:	f9009001 	str	x1, [x0, #288]
    5078:	91080280 	add	x0, x20, #0x200
    507c:	f900969f 	str	xzr, [x20, #296]
    5080:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    5084:	39415680 	ldrb	w0, [x20, #85]
    5088:	f9400722 	ldr	x2, [x25, #8]
    508c:	36001980 	tbz	w0, #0, 53bc <fwp_main_thread+0x518>
    5090:	a9508281 	ldp	x1, x0, [x20, #264]
    5094:	b4001a81 	cbz	x1, 53e4 <fwp_main_thread+0x540>
    5098:	f9008820 	str	x0, [x1, #272]
    509c:	b4000040 	cbz	x0, 50a4 <fwp_main_thread+0x200>
    50a0:	f9008401 	str	x1, [x0, #264]
    50a4:	91080280 	add	x0, x20, #0x200
    50a8:	3901569f 	strb	wzr, [x20, #85]
    50ac:	aa0203f4 	mov	x20, x2
    50b0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    50b4:	f94016a0 	ldr	x0, [x21, #40]
    50b8:	b5fffa20 	cbnz	x0, 4ffc <fwp_main_thread+0x158>
    50bc:	f00000c0 	adrp	x0, 20000 <__data_start>
    50c0:	91024000 	add	x0, x0, #0x90
    50c4:	39014ab8 	strb	w24, [x21, #82]
    50c8:	f9415400 	ldr	x0, [x0, #680]
    50cc:	b50000a0 	cbnz	x0, 50e0 <fwp_main_thread+0x23c>
    50d0:	f00000c0 	adrp	x0, 20000 <__data_start>
    50d4:	91024015 	add	x21, x0, #0x90
    50d8:	f9415ea0 	ldr	x0, [x21, #696]
    50dc:	b400ad80 	cbz	x0, 668c <fwp_main_thread+0x17e8>
    50e0:	f00000c0 	adrp	x0, 20000 <__data_start>
    50e4:	91024000 	add	x0, x0, #0x90
    50e8:	f9417001 	ldr	x1, [x0, #736]
    50ec:	b902d81f 	str	wzr, [x0, #728]
    50f0:	eb14003f 	cmp	x1, x20
    50f4:	5400ae21 	b.ne	66b8 <fwp_main_thread+0x1814>  // b.any
    50f8:	b40004d4 	cbz	x20, 5190 <fwp_main_thread+0x2ec>
    50fc:	f00000c0 	adrp	x0, 20000 <__data_start>
    5100:	91024000 	add	x0, x0, #0x90
    5104:	52800021 	mov	w1, #0x1                   	// #1
    5108:	39014a81 	strb	w1, [x20, #82]
    510c:	f9414005 	ldr	x5, [x0, #640]
    5110:	b4000405 	cbz	x5, 5190 <fwp_main_thread+0x2ec>
    5114:	d503201f 	nop
    5118:	394140a0 	ldrb	w0, [x5, #80]
    511c:	37000060 	tbnz	w0, #0, 5128 <fwp_main_thread+0x284>
    5120:	aa0503e0 	mov	x0, x5
    5124:	97fff413 	bl	2170 <fwp_cancel_tree.part.0>
    5128:	f9409ca5 	ldr	x5, [x5, #312]
    512c:	b5ffff65 	cbnz	x5, 5118 <fwp_main_thread+0x274>
    5130:	f00000c0 	adrp	x0, 20000 <__data_start>
    5134:	91024015 	add	x21, x0, #0x90
    5138:	52800036 	mov	w22, #0x1                   	// #1
    513c:	d503201f 	nop
    5140:	f9402a80 	ldr	x0, [x20, #80]
    5144:	f2001c1f 	tst	x0, #0xff000000ff
    5148:	540000e1 	b.ne	5164 <fwp_main_thread+0x2c0>  // b.any
    514c:	f94016a0 	ldr	x0, [x21, #40]
    5150:	39015296 	strb	w22, [x20, #84]
    5154:	f900829f 	str	xzr, [x20, #256]
    5158:	b40014a0 	cbz	x0, 53ec <fwp_main_thread+0x548>
    515c:	f9008014 	str	x20, [x0, #256]
    5160:	f90016b4 	str	x20, [x21, #40]
    5164:	97fffb10 	bl	3da4 <fwp_block>
    5168:	97fffaa2 	bl	3bf0 <fwp_free_zombie>
    516c:	f94142a0 	ldr	x0, [x21, #640]
    5170:	b4000100 	cbz	x0, 5190 <fwp_main_thread+0x2ec>
    5174:	f94172b4 	ldr	x20, [x21, #736]
    5178:	17fffff2 	b	5140 <fwp_main_thread+0x29c>
    517c:	f9415720 	ldr	x0, [x25, #680]
    5180:	b400a6a0 	cbz	x0, 6654 <fwp_main_thread+0x17b0>
    5184:	f9417320 	ldr	x0, [x25, #736]
    5188:	b902db3f 	str	wzr, [x25, #728]
    518c:	b500a960 	cbnz	x0, 66b8 <fwp_main_thread+0x1814>
    5190:	97fffa98 	bl	3bf0 <fwp_free_zombie>
    5194:	f00000c0 	adrp	x0, 20000 <__data_start>
    5198:	91024015 	add	x21, x0, #0x90
    519c:	f9401aa0 	ldr	x0, [x21, #48]
    51a0:	b500a8c0 	cbnz	x0, 66b8 <fwp_main_thread+0x1814>
    51a4:	f9401ea0 	ldr	x0, [x21, #56]
    51a8:	b500a880 	cbnz	x0, 66b8 <fwp_main_thread+0x1814>
    51ac:	b94072a0 	ldr	w0, [x21, #112]
    51b0:	340001e0 	cbz	w0, 51ec <fwp_main_thread+0x348>
    51b4:	93407c16 	sxtw	x22, w0
    51b8:	51000400 	sub	w0, w0, #0x1
    51bc:	d1000ad6 	sub	x22, x22, #0x2
    51c0:	910202b7 	add	x23, x21, #0x80
    51c4:	cb2042d6 	sub	x22, x22, w0, uxtw
    51c8:	93407c14 	sxtw	x20, w0
    51cc:	d503201f 	nop
    51d0:	f8747ae0 	ldr	x0, [x23, x20, lsl #3]
    51d4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    51d8:	b90072b4 	str	w20, [x21, #112]
    51dc:	d1000694 	sub	x20, x20, #0x1
    51e0:	97fff110 	bl	1620 <munmap@plt>
    51e4:	eb16029f 	cmp	x20, x22
    51e8:	54ffff41 	b.ne	51d0 <fwp_main_thread+0x32c>  // b.any
    51ec:	f00000d4 	adrp	x20, 20000 <__data_start>
    51f0:	91004280 	add	x0, x20, #0x10
    51f4:	b9406000 	ldr	w0, [x0, #96]
    51f8:	37f80040 	tbnz	w0, #31, 5200 <fwp_main_thread+0x35c>
    51fc:	97fff0c5 	bl	1510 <close@plt>
    5200:	f00000c0 	adrp	x0, 20000 <__data_start>
    5204:	91024000 	add	x0, x0, #0x90
    5208:	91004281 	add	x1, x20, #0x10
    520c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5210:	d2800014 	mov	x20, #0x0                   	// #0
    5214:	f9417416 	ldr	x22, [x0, #744]
    5218:	b9006022 	str	w2, [x1, #96]
    521c:	f9417815 	ldr	x21, [x0, #752]
    5220:	b4000196 	cbz	x22, 5250 <fwp_main_thread+0x3ac>
    5224:	d503201f 	nop
    5228:	f8747aa0 	ldr	x0, [x21, x20, lsl #3]
    522c:	b40000c0 	cbz	x0, 5244 <fwp_main_thread+0x3a0>
    5230:	f9400001 	ldr	x1, [x0]
    5234:	b500a421 	cbnz	x1, 66b8 <fwp_main_thread+0x1814>
    5238:	f9400401 	ldr	x1, [x0, #8]
    523c:	b500a3e1 	cbnz	x1, 66b8 <fwp_main_thread+0x1814>
    5240:	97fff770 	bl	3000 <fwp_mem_free>
    5244:	91000694 	add	x20, x20, #0x1
    5248:	eb16029f 	cmp	x20, x22
    524c:	54fffee1 	b.ne	5228 <fwp_main_thread+0x384>  // b.any
    5250:	aa1503e0 	mov	x0, x21
    5254:	97fff76b 	bl	3000 <fwp_mem_free>
    5258:	f00000c0 	adrp	x0, 20000 <__data_start>
    525c:	91024000 	add	x0, x0, #0x90
    5260:	f9417014 	ldr	x20, [x0, #736]
    5264:	f901741f 	str	xzr, [x0, #744]
    5268:	f901781f 	str	xzr, [x0, #752]
    526c:	b40001f4 	cbz	x20, 52a8 <fwp_main_thread+0x404>
    5270:	f9401681 	ldr	x1, [x20, #40]
    5274:	b500a221 	cbnz	x1, 66b8 <fwp_main_thread+0x1814>
    5278:	f9405681 	ldr	x1, [x20, #168]
    527c:	b500a1e1 	cbnz	x1, 66b8 <fwp_main_thread+0x1814>
    5280:	f9415401 	ldr	x1, [x0, #680]
    5284:	b500a1a1 	cbnz	x1, 66b8 <fwp_main_thread+0x1814>
    5288:	f9415c00 	ldr	x0, [x0, #696]
    528c:	b500a160 	cbnz	x0, 66b8 <fwp_main_thread+0x1814>
    5290:	d2823a02 	mov	x2, #0x11d0                	// #4560
    5294:	f0000140 	adrp	x0, 30000 <alt.4+0xfc70>
    5298:	910e4000 	add	x0, x0, #0x390
    529c:	97fff08d 	bl	14d0 <memset@plt>
    52a0:	aa1403e0 	mov	x0, x20
    52a4:	97fff757 	bl	3000 <fwp_mem_free>
    52a8:	9115c273 	add	x19, x19, #0x570
    52ac:	f00000c0 	adrp	x0, 20000 <__data_start>
    52b0:	9102401b 	add	x27, x0, #0x90
    52b4:	52800041 	mov	w1, #0x2                   	// #2
    52b8:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    52bc:	f947e800 	ldr	x0, [x0, #4048]
    52c0:	d0000002 	adrp	x2, 7000 <atexit>
    52c4:	fd4a1260 	ldr	d0, [x19, #5152]
    52c8:	9113c042 	add	x2, x2, #0x4f0
    52cc:	fd402f61 	ldr	d1, [x27, #88]
    52d0:	a9449363 	ldp	x3, x4, [x27, #72]
    52d4:	7e61d800 	ucvtf	d0, d0
    52d8:	f9400000 	ldr	x0, [x0]
    52dc:	f900077f 	str	xzr, [x27, #8]
    52e0:	f9416765 	ldr	x5, [x27, #712]
    52e4:	1e613801 	fsub	d1, d0, d1
    52e8:	fd403360 	ldr	d0, [x27, #96]
    52ec:	f900137f 	str	xzr, [x27, #32]
    52f0:	b900437f 	str	wzr, [x27, #64]
    52f4:	f901737f 	str	xzr, [x27, #736]
    52f8:	97fff09e 	bl	1570 <__fprintf_chk@plt>
    52fc:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    5300:	f947ec00 	ldr	x0, [x0, #4056]
    5304:	f9400000 	ldr	x0, [x0]
    5308:	97fff0ca 	bl	1630 <fflush@plt>
    530c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b78>
    5310:	f947f400 	ldr	x0, [x0, #4072]
    5314:	f940afe2 	ldr	x2, [sp, #344]
    5318:	f9400001 	ldr	x1, [x0]
    531c:	eb010042 	subs	x2, x2, x1
    5320:	d2800001 	mov	x1, #0x0                   	// #0
    5324:	5400ad61 	b.ne	68d0 <fwp_main_thread+0x1a2c>  // b.any
    5328:	a95963f7 	ldp	x23, x24, [sp, #400]
    532c:	d2800000 	mov	x0, #0x0                   	// #0
    5330:	a95a6bf9 	ldp	x25, x26, [sp, #416]
    5334:	a95b73fb 	ldp	x27, x28, [sp, #432]
    5338:	910583ff 	add	sp, sp, #0x160
    533c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5340:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5344:	a8ca7bfd 	ldp	x29, x30, [sp], #160
    5348:	d65f03c0 	ret
    534c:	97fff3dd 	bl	22c0 <fwp_now_ns>
    5350:	f94032a1 	ldr	x1, [x21, #96]
    5354:	eb01001f 	cmp	x0, x1
    5358:	540000ab 	b.lt	536c <fwp_main_thread+0x4c8>  // b.tstop
    535c:	394142a0 	ldrb	w0, [x21, #80]
    5360:	37000060 	tbnz	w0, #0, 536c <fwp_main_thread+0x4c8>
    5364:	aa1503e0 	mov	x0, x21
    5368:	97fff382 	bl	2170 <fwp_cancel_tree.part.0>
    536c:	394146a0 	ldrb	w0, [x21, #81]
    5370:	39414a82 	ldrb	w2, [x20, #82]
    5374:	3707e4e0 	tbnz	w0, #0, 5010 <fwp_main_thread+0x16c>
    5378:	f94032a1 	ldr	x1, [x21, #96]
    537c:	370001c2 	tbnz	w2, #0, 53b4 <fwp_main_thread+0x510>
    5380:	f9403280 	ldr	x0, [x20, #96]
    5384:	b4000180 	cbz	x0, 53b4 <fwp_main_thread+0x510>
    5388:	b4000061 	cbz	x1, 5394 <fwp_main_thread+0x4f0>
    538c:	eb01001f 	cmp	x0, x1
    5390:	9a81d000 	csel	x0, x0, x1, le
    5394:	f94022a1 	ldr	x1, [x21, #64]
    5398:	a911fe96 	stp	x22, xzr, [x20, #280]
    539c:	f9009681 	str	x1, [x20, #296]
    53a0:	b4009701 	cbz	x1, 6680 <fwp_main_thread+0x17dc>
    53a4:	f9009034 	str	x20, [x1, #288]
    53a8:	aa0003e1 	mov	x1, x0
    53ac:	f90022b4 	str	x20, [x21, #64]
    53b0:	17ffff21 	b	5034 <fwp_main_thread+0x190>
    53b4:	f94022a0 	ldr	x0, [x21, #64]
    53b8:	17ffff19 	b	501c <fwp_main_thread+0x178>
    53bc:	aa0203f4 	mov	x20, x2
    53c0:	17ffff0d 	b	4ff4 <fwp_main_thread+0x150>
    53c4:	a911fe96 	stp	x22, xzr, [x20, #280]
    53c8:	f9009680 	str	x0, [x20, #296]
    53cc:	b4000040 	cbz	x0, 53d4 <fwp_main_thread+0x530>
    53d0:	f9009014 	str	x20, [x0, #288]
    53d4:	f90022b4 	str	x20, [x21, #64]
    53d8:	17ffff1e 	b	5050 <fwp_main_thread+0x1ac>
    53dc:	f9000040 	str	x0, [x2]
    53e0:	17ffff24 	b	5070 <fwp_main_thread+0x1cc>
    53e4:	f9001f20 	str	x0, [x25, #56]
    53e8:	17ffff2d 	b	509c <fwp_main_thread+0x1f8>
    53ec:	f9001ab4 	str	x20, [x21, #48]
    53f0:	17ffff5c 	b	5160 <fwp_main_thread+0x2bc>
    53f4:	b0ffffe0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    53f8:	911d9000 	add	x0, x0, #0x764
    53fc:	94000701 	bl	7000 <atexit>
    5400:	17fffeba 	b	4ee8 <fwp_main_thread+0x44>
    5404:	97fff533 	bl	28d0 <fwp_heap_init>
    5408:	17fffeb5 	b	4edc <fwp_main_thread+0x38>
    540c:	f9414aa2 	ldr	x2, [x21, #656]
    5410:	d0ffffe0 	adrp	x0, 3000 <fwp_mem_free>
    5414:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    5418:	91268000 	add	x0, x0, #0x9a0
    541c:	912e4021 	add	x1, x1, #0xb90
    5420:	a90487e2 	stp	x2, x1, [sp, #72]
    5424:	2a1403fb 	mov	w27, w20
    5428:	f9400be1 	ldr	x1, [sp, #16]
    542c:	a90703ff 	stp	xzr, x0, [sp, #112]
    5430:	d2800096 	mov	x22, #0x4                   	// #4
    5434:	f94013e0 	ldr	x0, [sp, #32]
    5438:	6d1c27e8 	stp	d8, d9, [sp, #448]
    543c:	d2800014 	mov	x20, #0x0                   	// #0
    5440:	6d1d2fea 	stp	d10, d11, [sp, #464]
    5444:	6d1e37ec 	stp	d12, d13, [sp, #480]
    5448:	6d1f3fee 	stp	d14, d15, [sp, #496]
    544c:	f9000fff 	str	xzr, [sp, #24]
    5450:	f9002fe1 	str	x1, [sp, #88]
    5454:	f90033ff 	str	xzr, [sp, #96]
    5458:	f9014aa0 	str	x0, [x21, #656]
    545c:	d503201f 	nop
    5460:	f9400fe2 	ldr	x2, [sp, #24]
    5464:	f10006d7 	subs	x23, x22, #0x1
    5468:	aa1803e1 	mov	x1, x24
    546c:	da1f029a 	sbc	x26, x20, xzr
    5470:	52800020 	mov	w0, #0x1                   	// #1
    5474:	f90037f7 	str	x23, [sp, #104]
    5478:	a90c0bf7 	stp	x23, x2, [sp, #192]
    547c:	97fff885 	bl	3690 <fwp_data.part.0.constprop.0>
    5480:	aa0003e2 	mov	x2, x0
    5484:	f949db21 	ldr	x1, [x25, #5040]
    5488:	f9000fe2 	str	x2, [sp, #24]
    548c:	f949ef20 	ldr	x0, [x25, #5080]
    5490:	cb010041 	sub	x1, x2, x1
    5494:	aa1703f6 	mov	x22, x23
    5498:	aa1a03f4 	mov	x20, x26
    549c:	eb00403f 	cmp	x1, x0, lsl #16
    54a0:	54000302 	b.cs	5500 <fwp_main_thread+0x65c>  // b.hs, b.nlast
    54a4:	d350fc20 	lsr	x0, x1, #16
    54a8:	f949ff25 	ldr	x5, [x25, #5112]
    54ac:	8b000800 	add	x0, x0, x0, lsl #2
    54b0:	d37df002 	lsl	x2, x0, #3
    54b4:	8b0200a0 	add	x0, x5, x2
    54b8:	f9401015 	ldr	x21, [x0, #32]
    54bc:	b4000235 	cbz	x21, 5500 <fwp_main_thread+0x65c>
    54c0:	386268a2 	ldrb	w2, [x5, x2]
    54c4:	7100085f 	cmp	w2, #0x2
    54c8:	54004780 	b.eq	5db8 <fwp_main_thread+0xf14>  // b.none
    54cc:	7100045f 	cmp	w2, #0x1
    54d0:	54000181 	b.ne	5500 <fwp_main_thread+0x65c>  // b.any
    54d4:	29430002 	ldp	w2, w0, [x0, #24]
    54d8:	92403c21 	and	x1, x1, #0xffff
    54dc:	9b027c21 	mul	x1, x1, x2
    54e0:	d360fc21 	lsr	x1, x1, #32
    54e4:	eb00003f 	cmp	x1, x0
    54e8:	540000c2 	b.cs	5500 <fwp_main_thread+0x65c>  // b.hs, b.nlast
    54ec:	8b0102b5 	add	x21, x21, x1
    54f0:	394002a0 	ldrb	w0, [x21]
    54f4:	7103fc1f 	cmp	w0, #0xff
    54f8:	540046a0 	b.eq	5dcc <fwp_main_thread+0xf28>  // b.none
    54fc:	390002bb 	strb	w27, [x21]
    5500:	f9400fe0 	ldr	x0, [sp, #24]
    5504:	f90033e0 	str	x0, [sp, #96]
    5508:	aa1a02e0 	orr	x0, x23, x26
    550c:	b5fffaa0 	cbnz	x0, 5460 <fwp_main_thread+0x5bc>
    5510:	d0000000 	adrp	x0, 7000 <atexit>
    5514:	910203e1 	add	x1, sp, #0x80
    5518:	f94027e3 	ldr	x3, [sp, #72]
    551c:	3dc1c800 	ldr	q0, [x0, #1824]
    5520:	f00000c0 	adrp	x0, 20000 <__data_start>
    5524:	91024002 	add	x2, x0, #0x90
    5528:	52800020 	mov	w0, #0x1                   	// #1
    552c:	3d8023e0 	str	q0, [sp, #128]
    5530:	f9014843 	str	x3, [x2, #656]
    5534:	97fff857 	bl	3690 <fwp_data.part.0.constprop.0>
    5538:	9115c263 	add	x3, x19, #0x570
    553c:	aa0003f4 	mov	x20, x0
    5540:	f949d861 	ldr	x1, [x3, #5040]
    5544:	f949ec60 	ldr	x0, [x3, #5080]
    5548:	cb010281 	sub	x1, x20, x1
    554c:	eb00403f 	cmp	x1, x0, lsl #16
    5550:	54000322 	b.cs	55b4 <fwp_main_thread+0x710>  // b.hs, b.nlast
    5554:	d350fc22 	lsr	x2, x1, #16
    5558:	f949fc63 	ldr	x3, [x3, #5112]
    555c:	8b020842 	add	x2, x2, x2, lsl #2
    5560:	d37df042 	lsl	x2, x2, #3
    5564:	8b020060 	add	x0, x3, x2
    5568:	f9401015 	ldr	x21, [x0, #32]
    556c:	b4000255 	cbz	x21, 55b4 <fwp_main_thread+0x710>
    5570:	38626862 	ldrb	w2, [x3, x2]
    5574:	7100085f 	cmp	w2, #0x2
    5578:	54008780 	b.eq	6668 <fwp_main_thread+0x17c4>  // b.none
    557c:	7100045f 	cmp	w2, #0x1
    5580:	540001a1 	b.ne	55b4 <fwp_main_thread+0x710>  // b.any
    5584:	29430002 	ldp	w2, w0, [x0, #24]
    5588:	92403c21 	and	x1, x1, #0xffff
    558c:	9b027c21 	mul	x1, x1, x2
    5590:	d360fc21 	lsr	x1, x1, #32
    5594:	eb00003f 	cmp	x1, x0
    5598:	540000e2 	b.cs	55b4 <fwp_main_thread+0x710>  // b.hs, b.nlast
    559c:	8b0102b5 	add	x21, x21, x1
    55a0:	394002a0 	ldrb	w0, [x21]
    55a4:	7103fc1f 	cmp	w0, #0xff
    55a8:	54009340 	b.eq	6810 <fwp_main_thread+0x196c>  // b.none
    55ac:	52800020 	mov	w0, #0x1                   	// #1
    55b0:	390002a0 	strb	w0, [x21]
    55b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    55b8:	910283e1 	add	x1, sp, #0xa0
    55bc:	52800020 	mov	w0, #0x1                   	// #1
    55c0:	a90a53e2 	stp	x2, x20, [sp, #160]
    55c4:	97fff833 	bl	3690 <fwp_data.part.0.constprop.0>
    55c8:	9115c263 	add	x3, x19, #0x570
    55cc:	aa0003f4 	mov	x20, x0
    55d0:	f949d861 	ldr	x1, [x3, #5040]
    55d4:	f949ec60 	ldr	x0, [x3, #5080]
    55d8:	cb010281 	sub	x1, x20, x1
    55dc:	eb00403f 	cmp	x1, x0, lsl #16
    55e0:	54000322 	b.cs	5644 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    55e4:	d350fc22 	lsr	x2, x1, #16
    55e8:	f949fc63 	ldr	x3, [x3, #5112]
    55ec:	8b020842 	add	x2, x2, x2, lsl #2
    55f0:	d37df042 	lsl	x2, x2, #3
    55f4:	8b020060 	add	x0, x3, x2
    55f8:	f9401015 	ldr	x21, [x0, #32]
    55fc:	b4000255 	cbz	x21, 5644 <fwp_main_thread+0x7a0>
    5600:	38626862 	ldrb	w2, [x3, x2]
    5604:	7100085f 	cmp	w2, #0x2
    5608:	540082a0 	b.eq	665c <fwp_main_thread+0x17b8>  // b.none
    560c:	7100045f 	cmp	w2, #0x1
    5610:	540001a1 	b.ne	5644 <fwp_main_thread+0x7a0>  // b.any
    5614:	29430002 	ldp	w2, w0, [x0, #24]
    5618:	92403c21 	and	x1, x1, #0xffff
    561c:	9b027c21 	mul	x1, x1, x2
    5620:	d360fc21 	lsr	x1, x1, #32
    5624:	eb00003f 	cmp	x1, x0
    5628:	540000e2 	b.cs	5644 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    562c:	8b0102b5 	add	x21, x21, x1
    5630:	394002a0 	ldrb	w0, [x21]
    5634:	7103fc1f 	cmp	w0, #0xff
    5638:	54008f20 	b.eq	681c <fwp_main_thread+0x1978>  // b.none
    563c:	52800020 	mov	w0, #0x1                   	// #1
    5640:	390002a0 	strb	w0, [x21]
    5644:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5648:	910243e1 	add	x1, sp, #0x90
    564c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5650:	52800020 	mov	w0, #0x1                   	// #1
    5654:	a90953e2 	stp	x2, x20, [sp, #144]
    5658:	97fff80e 	bl	3690 <fwp_data.part.0.constprop.0>
    565c:	9115c262 	add	x2, x19, #0x570
    5660:	aa0003e3 	mov	x3, x0
    5664:	f90017e3 	str	x3, [sp, #40]
    5668:	f949d841 	ldr	x1, [x2, #5040]
    566c:	f949ec40 	ldr	x0, [x2, #5080]
    5670:	cb010061 	sub	x1, x3, x1
    5674:	eb00403f 	cmp	x1, x0, lsl #16
    5678:	54000322 	b.cs	56dc <fwp_main_thread+0x838>  // b.hs, b.nlast
    567c:	d350fc20 	lsr	x0, x1, #16
    5680:	f949fc43 	ldr	x3, [x2, #5112]
    5684:	8b000800 	add	x0, x0, x0, lsl #2
    5688:	d37df002 	lsl	x2, x0, #3
    568c:	8b020060 	add	x0, x3, x2
    5690:	f9401014 	ldr	x20, [x0, #32]
    5694:	b4000254 	cbz	x20, 56dc <fwp_main_thread+0x838>
    5698:	38626862 	ldrb	w2, [x3, x2]
    569c:	7100085f 	cmp	w2, #0x2
    56a0:	54007ea0 	b.eq	6674 <fwp_main_thread+0x17d0>  // b.none
    56a4:	7100045f 	cmp	w2, #0x1
    56a8:	540001a1 	b.ne	56dc <fwp_main_thread+0x838>  // b.any
    56ac:	29430002 	ldp	w2, w0, [x0, #24]
    56b0:	92403c21 	and	x1, x1, #0xffff
    56b4:	9b027c21 	mul	x1, x1, x2
    56b8:	d360fc21 	lsr	x1, x1, #32
    56bc:	eb00003f 	cmp	x1, x0
    56c0:	540000e2 	b.cs	56dc <fwp_main_thread+0x838>  // b.hs, b.nlast
    56c4:	8b010294 	add	x20, x20, x1
    56c8:	39400280 	ldrb	w0, [x20]
    56cc:	7103fc1f 	cmp	w0, #0xff
    56d0:	54008ac0 	b.eq	6828 <fwp_main_thread+0x1984>  // b.none
    56d4:	52800020 	mov	w0, #0x1                   	// #1
    56d8:	39000280 	strb	w0, [x20]
    56dc:	f9400fe0 	ldr	x0, [sp, #24]
    56e0:	f9001fe0 	str	x0, [sp, #56]
    56e4:	b4005da0 	cbz	x0, 6298 <fwp_main_thread+0x13f4>
    56e8:	d0000001 	adrp	x1, 7000 <atexit>
    56ec:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    56f0:	9e670009 	fmov	d9, x0
    56f4:	fd43982a 	ldr	d10, [x1, #1840]
    56f8:	9115c262 	add	x2, x19, #0x570
    56fc:	f94017e3 	ldr	x3, [sp, #40]
    5700:	f949d840 	ldr	x0, [x2, #5040]
    5704:	f949ec41 	ldr	x1, [x2, #5080]
    5708:	cb000060 	sub	x0, x3, x0
    570c:	eb01401f 	cmp	x0, x1, lsl #16
    5710:	54000422 	b.cs	5794 <fwp_main_thread+0x8f0>  // b.hs, b.nlast
    5714:	d350fc01 	lsr	x1, x0, #16
    5718:	f949fc43 	ldr	x3, [x2, #5112]
    571c:	8b010821 	add	x1, x1, x1, lsl #2
    5720:	d37df021 	lsl	x1, x1, #3
    5724:	8b010062 	add	x2, x3, x1
    5728:	f9401054 	ldr	x20, [x2, #32]
    572c:	b4000354 	cbz	x20, 5794 <fwp_main_thread+0x8f0>
    5730:	38616861 	ldrb	w1, [x3, x1]
    5734:	7100083f 	cmp	w1, #0x2
    5738:	540070a0 	b.eq	654c <fwp_main_thread+0x16a8>  // b.none
    573c:	7100043f 	cmp	w1, #0x1
    5740:	540002a1 	b.ne	5794 <fwp_main_thread+0x8f0>  // b.any
    5744:	29430443 	ldp	w3, w1, [x2, #24]
    5748:	92403c00 	and	x0, x0, #0xffff
    574c:	9b037c00 	mul	x0, x0, x3
    5750:	d360fc00 	lsr	x0, x0, #32
    5754:	eb01001f 	cmp	x0, x1
    5758:	540001e2 	b.cs	5794 <fwp_main_thread+0x8f0>  // b.hs, b.nlast
    575c:	8b000294 	add	x20, x20, x0
    5760:	39400280 	ldrb	w0, [x20]
    5764:	34000180 	cbz	w0, 5794 <fwp_main_thread+0x8f0>
    5768:	f00000c1 	adrp	x1, 20000 <__data_start>
    576c:	91024021 	add	x1, x1, #0x90
    5770:	b9404022 	ldr	w2, [x1, #64]
    5774:	34000082 	cbz	w2, 5784 <fwp_main_thread+0x8e0>
    5778:	f9416422 	ldr	x2, [x1, #712]
    577c:	91000442 	add	x2, x2, #0x1
    5780:	f9016422 	str	x2, [x1, #712]
    5784:	7103f41f 	cmp	w0, #0xfd
    5788:	54007ce8 	b.hi	6724 <fwp_main_thread+0x1880>  // b.pmore
    578c:	11000400 	add	w0, w0, #0x1
    5790:	39000280 	strb	w0, [x20]
    5794:	f94017e0 	ldr	x0, [sp, #40]
    5798:	b4006e20 	cbz	x0, 655c <fwp_main_thread+0x16b8>
    579c:	aa0003e1 	mov	x1, x0
    57a0:	d2800000 	mov	x0, #0x0                   	// #0
    57a4:	d503201f 	nop
    57a8:	f9400821 	ldr	x1, [x1, #16]
    57ac:	91000400 	add	x0, x0, #0x1
    57b0:	b5ffffc1 	cbnz	x1, 57a8 <fwp_main_thread+0x904>
    57b4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    57b8:	eb01001f 	cmp	x0, x1
    57bc:	54008608 	b.hi	687c <fwp_main_thread+0x19d8>  // b.pmore
    57c0:	97fff811 	bl	3804 <fwp_array_new_packed.constprop.0>
    57c4:	aa0003f4 	mov	x20, x0
    57c8:	9115c261 	add	x1, x19, #0x570
    57cc:	aa0103e0 	mov	x0, x1
    57d0:	f949d821 	ldr	x1, [x1, #5040]
    57d4:	f949ec00 	ldr	x0, [x0, #5080]
    57d8:	cb010281 	sub	x1, x20, x1
    57dc:	eb00403f 	cmp	x1, x0, lsl #16
    57e0:	54000382 	b.cs	5850 <fwp_main_thread+0x9ac>  // b.hs, b.nlast
    57e4:	9115c262 	add	x2, x19, #0x570
    57e8:	d350fc20 	lsr	x0, x1, #16
    57ec:	8b000800 	add	x0, x0, x0, lsl #2
    57f0:	f949fc43 	ldr	x3, [x2, #5112]
    57f4:	d37df002 	lsl	x2, x0, #3
    57f8:	8b020060 	add	x0, x3, x2
    57fc:	f9401015 	ldr	x21, [x0, #32]
    5800:	b4000255 	cbz	x21, 5848 <fwp_main_thread+0x9a4>
    5804:	38626862 	ldrb	w2, [x3, x2]
    5808:	7100085f 	cmp	w2, #0x2
    580c:	54006c00 	b.eq	658c <fwp_main_thread+0x16e8>  // b.none
    5810:	7100045f 	cmp	w2, #0x1
    5814:	540001a1 	b.ne	5848 <fwp_main_thread+0x9a4>  // b.any
    5818:	29430002 	ldp	w2, w0, [x0, #24]
    581c:	92403c21 	and	x1, x1, #0xffff
    5820:	9b027c21 	mul	x1, x1, x2
    5824:	d360fc21 	lsr	x1, x1, #32
    5828:	eb00003f 	cmp	x1, x0
    582c:	540000e2 	b.cs	5848 <fwp_main_thread+0x9a4>  // b.hs, b.nlast
    5830:	8b0102b5 	add	x21, x21, x1
    5834:	394002a0 	ldrb	w0, [x21]
    5838:	7103fc1f 	cmp	w0, #0xff
    583c:	54006b20 	b.eq	65a0 <fwp_main_thread+0x16fc>  // b.none
    5840:	52800020 	mov	w0, #0x1                   	// #1
    5844:	390002a0 	strb	w0, [x21]
    5848:	f94017e0 	ldr	x0, [sp, #40]
    584c:	b40069c0 	cbz	x0, 6584 <fwp_main_thread+0x16e0>
    5850:	f94017f5 	ldr	x21, [sp, #40]
    5854:	91002296 	add	x22, x20, #0x8
    5858:	9115c277 	add	x23, x19, #0x570
    585c:	52800039 	mov	w25, #0x1                   	// #1
    5860:	aa1503e0 	mov	x0, x21
    5864:	14000013 	b	58b0 <fwp_main_thread+0xa0c>
    5868:	7100045f 	cmp	w2, #0x1
    586c:	54000161 	b.ne	5898 <fwp_main_thread+0x9f4>  // b.any
    5870:	294308e8 	ldp	w8, w2, [x7, #24]
    5874:	92403c21 	and	x1, x1, #0xffff
    5878:	9b087c21 	mul	x1, x1, x8
    587c:	d360fc21 	lsr	x1, x1, #32
    5880:	eb02003f 	cmp	x1, x2
    5884:	540000a2 	b.cs	5898 <fwp_main_thread+0x9f4>  // b.hs, b.nlast
    5888:	8b0100c6 	add	x6, x6, x1
    588c:	394000c1 	ldrb	w1, [x6]
    5890:	7100043f 	cmp	w1, #0x1
    5894:	540003e0 	b.eq	5910 <fwp_main_thread+0xa6c>  // b.none
    5898:	f9400281 	ldr	x1, [x20]
    589c:	b7f87a41 	tbnz	x1, #63, 67e4 <fwp_main_thread+0x1940>
    58a0:	f90002c4 	str	x4, [x22]
    58a4:	52800019 	mov	w25, #0x0                   	// #0
    58a8:	910022d6 	add	x22, x22, #0x8
    58ac:	b4000775 	cbz	x21, 5998 <fwp_main_thread+0xaf4>
    58b0:	aa1503e5 	mov	x5, x21
    58b4:	aa1503e3 	mov	x3, x21
    58b8:	a940d6a4 	ldp	x4, x21, [x21, #8]
    58bc:	34fffef9 	cbz	w25, 5898 <fwp_main_thread+0x9f4>
    58c0:	f949dae1 	ldr	x1, [x23, #5040]
    58c4:	f949eee2 	ldr	x2, [x23, #5080]
    58c8:	cb0100a1 	sub	x1, x5, x1
    58cc:	eb02403f 	cmp	x1, x2, lsl #16
    58d0:	54fffe42 	b.cs	5898 <fwp_main_thread+0x9f4>  // b.hs, b.nlast
    58d4:	d350fc22 	lsr	x2, x1, #16
    58d8:	f949fee8 	ldr	x8, [x23, #5112]
    58dc:	8b020842 	add	x2, x2, x2, lsl #2
    58e0:	d37df042 	lsl	x2, x2, #3
    58e4:	8b020107 	add	x7, x8, x2
    58e8:	f94010e6 	ldr	x6, [x7, #32]
    58ec:	b4fffd66 	cbz	x6, 5898 <fwp_main_thread+0x9f4>
    58f0:	38626902 	ldrb	w2, [x8, x2]
    58f4:	7100085f 	cmp	w2, #0x2
    58f8:	54fffb81 	b.ne	5868 <fwp_main_thread+0x9c4>  // b.any
    58fc:	72003c3f 	tst	w1, #0xffff
    5900:	54fffcc1 	b.ne	5898 <fwp_main_thread+0x9f4>  // b.any
    5904:	394000c1 	ldrb	w1, [x6]
    5908:	7100043f 	cmp	w1, #0x1
    590c:	54fffc61 	b.ne	5898 <fwp_main_thread+0x9f4>  // b.any
    5910:	f9400280 	ldr	x0, [x20]
    5914:	b7f87680 	tbnz	x0, #63, 67e4 <fwp_main_thread+0x1940>
    5918:	f90002c4 	str	x4, [x22]
    591c:	f949dae1 	ldr	x1, [x23, #5040]
    5920:	f949eee0 	ldr	x0, [x23, #5080]
    5924:	cb010063 	sub	x3, x3, x1
    5928:	eb00407f 	cmp	x3, x0, lsl #16
    592c:	540002e2 	b.cs	5988 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    5930:	d350fc60 	lsr	x0, x3, #16
    5934:	f949fee1 	ldr	x1, [x23, #5112]
    5938:	8b000800 	add	x0, x0, x0, lsl #2
    593c:	d37df000 	lsl	x0, x0, #3
    5940:	8b000024 	add	x4, x1, x0
    5944:	f9401082 	ldr	x2, [x4, #32]
    5948:	b4000202 	cbz	x2, 5988 <fwp_main_thread+0xae4>
    594c:	38606820 	ldrb	w0, [x1, x0]
    5950:	7100081f 	cmp	w0, #0x2
    5954:	54005d80 	b.eq	6504 <fwp_main_thread+0x1660>  // b.none
    5958:	7100041f 	cmp	w0, #0x1
    595c:	54000161 	b.ne	5988 <fwp_main_thread+0xae4>  // b.any
    5960:	29430086 	ldp	w6, w0, [x4, #24]
    5964:	92403c61 	and	x1, x3, #0xffff
    5968:	9b067c21 	mul	x1, x1, x6
    596c:	d360fc21 	lsr	x1, x1, #32
    5970:	eb00003f 	cmp	x1, x0
    5974:	540000a2 	b.cs	5988 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    5978:	8b010042 	add	x2, x2, x1
    597c:	39400040 	ldrb	w0, [x2]
    5980:	7100041f 	cmp	w0, #0x1
    5984:	540022a0 	b.eq	5dd8 <fwp_main_thread+0xf34>  // b.none
    5988:	aa1503e0 	mov	x0, x21
    598c:	d503201f 	nop
    5990:	910022d6 	add	x22, x22, #0x8
    5994:	b5fff8f5 	cbnz	x21, 58b0 <fwp_main_thread+0xa0c>
    5998:	d280f9d7 	mov	x23, #0x7ce                 	// #1998
    599c:	97fff7ad 	bl	3850 <fwp_drop0>
    59a0:	f9400296 	ldr	x22, [x20]
    59a4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    59a8:	9240fad6 	and	x22, x22, #0x7fffffffffffffff
    59ac:	eb0002df 	cmp	x22, x0
    59b0:	54007668 	b.hi	687c <fwp_main_thread+0x19d8>  // b.pmore
    59b4:	aa1603e0 	mov	x0, x22
    59b8:	97fff793 	bl	3804 <fwp_array_new_packed.constprop.0>
    59bc:	9115c262 	add	x2, x19, #0x570
    59c0:	aa0003f5 	mov	x21, x0
    59c4:	f949d841 	ldr	x1, [x2, #5040]
    59c8:	f949ec40 	ldr	x0, [x2, #5080]
    59cc:	cb0102a1 	sub	x1, x21, x1
    59d0:	eb00403f 	cmp	x1, x0, lsl #16
    59d4:	54000322 	b.cs	5a38 <fwp_main_thread+0xb94>  // b.hs, b.nlast
    59d8:	d350fc20 	lsr	x0, x1, #16
    59dc:	f949fc43 	ldr	x3, [x2, #5112]
    59e0:	8b000800 	add	x0, x0, x0, lsl #2
    59e4:	d37df002 	lsl	x2, x0, #3
    59e8:	8b020060 	add	x0, x3, x2
    59ec:	f9401019 	ldr	x25, [x0, #32]
    59f0:	b4000259 	cbz	x25, 5a38 <fwp_main_thread+0xb94>
    59f4:	38626862 	ldrb	w2, [x3, x2]
    59f8:	7100085f 	cmp	w2, #0x2
    59fc:	54004c60 	b.eq	6388 <fwp_main_thread+0x14e4>  // b.none
    5a00:	7100045f 	cmp	w2, #0x1
    5a04:	540001a1 	b.ne	5a38 <fwp_main_thread+0xb94>  // b.any
    5a08:	29430002 	ldp	w2, w0, [x0, #24]
    5a0c:	92403c21 	and	x1, x1, #0xffff
    5a10:	9b027c21 	mul	x1, x1, x2
    5a14:	d360fc21 	lsr	x1, x1, #32
    5a18:	eb00003f 	cmp	x1, x0
    5a1c:	540000e2 	b.cs	5a38 <fwp_main_thread+0xb94>  // b.hs, b.nlast
    5a20:	8b010339 	add	x25, x25, x1
    5a24:	39400320 	ldrb	w0, [x25]
    5a28:	7103fc1f 	cmp	w0, #0xff
    5a2c:	54004b80 	b.eq	639c <fwp_main_thread+0x14f8>  // b.none
    5a30:	52800020 	mov	w0, #0x1                   	// #1
    5a34:	39000320 	strb	w0, [x25]
    5a38:	d280011b 	mov	x27, #0x8                   	// #8
    5a3c:	2f00e408 	movi	d8, #0x0
    5a40:	8b1b0299 	add	x25, x20, x27
    5a44:	d280001c 	mov	x28, #0x0                   	// #0
    5a48:	b5001a96 	cbnz	x22, 5d98 <fwp_main_thread+0xef4>
    5a4c:	14000111 	b	5e90 <fwp_main_thread+0xfec>
    5a50:	aa1903e0 	mov	x0, x25
    5a54:	b7f843e2 	tbnz	x2, #63, 62d0 <fwp_main_thread+0x142c>
    5a58:	fc7c780b 	ldr	d11, [x0, x28, lsl #3]
    5a5c:	9e6703ec 	fmov	d12, xzr
    5a60:	b400027c 	cbz	x28, 5aac <fwp_main_thread+0xc08>
    5a64:	8b1b0000 	add	x0, x0, x27
    5a68:	1e6e100c 	fmov	d12, #1.000000000000000000e+00
    5a6c:	fc5f0000 	ldur	d0, [x0, #-16]
    5a70:	1e680802 	fmul	d2, d0, d8
    5a74:	1e600801 	fmul	d1, d0, d0
    5a78:	1e603980 	fsub	d0, d12, d0
    5a7c:	1e622842 	fadd	d2, d2, d2
    5a80:	1e613961 	fsub	d1, d11, d1
    5a84:	1e680800 	fmul	d0, d0, d8
    5a88:	1e62398c 	fsub	d12, d12, d2
    5a8c:	1e610822 	fmul	d2, d1, d1
    5a90:	1e602800 	fadd	d0, d0, d0
    5a94:	1e61098c 	fmul	d12, d12, d1
    5a98:	1e680841 	fmul	d1, d2, d8
    5a9c:	1e6c298c 	fadd	d12, d12, d12
    5aa0:	1e69098c 	fmul	d12, d12, d9
    5aa4:	1e61298c 	fadd	d12, d12, d1
    5aa8:	1e60298c 	fadd	d12, d12, d0
    5aac:	9100079c 	add	x28, x28, #0x1
    5ab0:	eb1c003f 	cmp	x1, x28
    5ab4:	540019a0 	b.eq	5de8 <fwp_main_thread+0xf44>  // b.none
    5ab8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    5abc:	aa1803e1 	mov	x1, x24
    5ac0:	52800000 	mov	w0, #0x0                   	// #0
    5ac4:	f90063e2 	str	x2, [sp, #192]
    5ac8:	fd0067eb 	str	d11, [sp, #200]
    5acc:	97fff6f1 	bl	3690 <fwp_data.part.0.constprop.0>
    5ad0:	9115c266 	add	x6, x19, #0x570
    5ad4:	aa0003fa 	mov	x26, x0
    5ad8:	f949d8c1 	ldr	x1, [x6, #5040]
    5adc:	f949ecc0 	ldr	x0, [x6, #5080]
    5ae0:	cb010341 	sub	x1, x26, x1
    5ae4:	eb00403f 	cmp	x1, x0, lsl #16
    5ae8:	54000322 	b.cs	5b4c <fwp_main_thread+0xca8>  // b.hs, b.nlast
    5aec:	d350fc22 	lsr	x2, x1, #16
    5af0:	f949fcc7 	ldr	x7, [x6, #5112]
    5af4:	8b020842 	add	x2, x2, x2, lsl #2
    5af8:	d37df042 	lsl	x2, x2, #3
    5afc:	8b0200e6 	add	x6, x7, x2
    5b00:	f94010c0 	ldr	x0, [x6, #32]
    5b04:	b4000240 	cbz	x0, 5b4c <fwp_main_thread+0xca8>
    5b08:	386268e2 	ldrb	w2, [x7, x2]
    5b0c:	7100085f 	cmp	w2, #0x2
    5b10:	540018c0 	b.eq	5e28 <fwp_main_thread+0xf84>  // b.none
    5b14:	7100045f 	cmp	w2, #0x1
    5b18:	540001a1 	b.ne	5b4c <fwp_main_thread+0xca8>  // b.any
    5b1c:	294308c7 	ldp	w7, w2, [x6, #24]
    5b20:	92403c21 	and	x1, x1, #0xffff
    5b24:	9b077c21 	mul	x1, x1, x7
    5b28:	d360fc21 	lsr	x1, x1, #32
    5b2c:	eb02003f 	cmp	x1, x2
    5b30:	540000e2 	b.cs	5b4c <fwp_main_thread+0xca8>  // b.hs, b.nlast
    5b34:	8b010000 	add	x0, x0, x1
    5b38:	39400001 	ldrb	w1, [x0]
    5b3c:	7103fc3f 	cmp	w1, #0xff
    5b40:	54001800 	b.eq	5e40 <fwp_main_thread+0xf9c>  // b.none
    5b44:	52800021 	mov	w1, #0x1                   	// #1
    5b48:	39000001 	strb	w1, [x0]
    5b4c:	f9400280 	ldr	x0, [x20]
    5b50:	9240f801 	and	x1, x0, #0x7fffffffffffffff
    5b54:	eb1c003f 	cmp	x1, x28
    5b58:	54001289 	b.ls	5da8 <fwp_main_thread+0xf04>  // b.plast
    5b5c:	aa1903e2 	mov	x2, x25
    5b60:	b7f83bc0 	tbnz	x0, #63, 62d8 <fwp_main_thread+0x1434>
    5b64:	f87b6842 	ldr	x2, [x2, x27]
    5b68:	9102c3e1 	add	x1, sp, #0xb0
    5b6c:	52800000 	mov	w0, #0x0                   	// #0
    5b70:	a90b0bff 	stp	xzr, x2, [sp, #176]
    5b74:	97fff6c7 	bl	3690 <fwp_data.part.0.constprop.0>
    5b78:	aa0003e9 	mov	x9, x0
    5b7c:	9115c268 	add	x8, x19, #0x570
    5b80:	f949ed06 	ldr	x6, [x8, #5080]
    5b84:	f949d901 	ldr	x1, [x8, #5040]
    5b88:	d370bcc6 	lsl	x6, x6, #16
    5b8c:	cb010007 	sub	x7, x0, x1
    5b90:	eb0600ff 	cmp	x7, x6
    5b94:	540003e2 	b.cs	5c10 <fwp_main_thread+0xd6c>  // b.hs, b.nlast
    5b98:	d350fce2 	lsr	x2, x7, #16
    5b9c:	f949fd0b 	ldr	x11, [x8, #5112]
    5ba0:	8b020848 	add	x8, x2, x2, lsl #2
    5ba4:	d37df108 	lsl	x8, x8, #3
    5ba8:	8b08016a 	add	x10, x11, x8
    5bac:	f9401140 	ldr	x0, [x10, #32]
    5bb0:	b4001600 	cbz	x0, 5e70 <fwp_main_thread+0xfcc>
    5bb4:	38686968 	ldrb	w8, [x11, x8]
    5bb8:	7100091f 	cmp	w8, #0x2
    5bbc:	54001560 	b.eq	5e68 <fwp_main_thread+0xfc4>  // b.none
    5bc0:	7100051f 	cmp	w8, #0x1
    5bc4:	54001561 	b.ne	5e70 <fwp_main_thread+0xfcc>  // b.any
    5bc8:	2943294b 	ldp	w11, w10, [x10, #24]
    5bcc:	92403ce8 	and	x8, x7, #0xffff
    5bd0:	9b0b7d08 	mul	x8, x8, x11
    5bd4:	d360fd08 	lsr	x8, x8, #32
    5bd8:	eb0a011f 	cmp	x8, x10
    5bdc:	540014a2 	b.cs	5e70 <fwp_main_thread+0xfcc>  // b.hs, b.nlast
    5be0:	8b080000 	add	x0, x0, x8
    5be4:	39400001 	ldrb	w1, [x0]
    5be8:	7103fc3f 	cmp	w1, #0xff
    5bec:	540037a0 	b.eq	62e0 <fwp_main_thread+0x143c>  // b.none
    5bf0:	9115c261 	add	x1, x19, #0x570
    5bf4:	52800022 	mov	w2, #0x1                   	// #1
    5bf8:	39000002 	strb	w2, [x0]
    5bfc:	aa0103e0 	mov	x0, x1
    5c00:	f949d821 	ldr	x1, [x1, #5040]
    5c04:	f949ec06 	ldr	x6, [x0, #5080]
    5c08:	cb010127 	sub	x7, x9, x1
    5c0c:	d370bcc6 	lsl	x6, x6, #16
    5c10:	fd400b44 	ldr	d4, [x26, #16]
    5c14:	d350fce2 	lsr	x2, x7, #16
    5c18:	fd400742 	ldr	d2, [x26, #8]
    5c1c:	6d40b920 	ldp	d0, d14, [x9, #8]
    5c20:	1e64088f 	fmul	d15, d4, d4
    5c24:	1e640843 	fmul	d3, d2, d4
    5c28:	1e632863 	fadd	d3, d3, d3
    5c2c:	1e63380d 	fsub	d13, d0, d3
    5c30:	eb0700df 	cmp	x6, x7
    5c34:	54000469 	b.ls	5cc0 <fwp_main_thread+0xe1c>  // b.plast
    5c38:	9115c260 	add	x0, x19, #0x570
    5c3c:	8b020842 	add	x2, x2, x2, lsl #2
    5c40:	d37df042 	lsl	x2, x2, #3
    5c44:	f949fc0a 	ldr	x10, [x0, #5112]
    5c48:	8b020148 	add	x8, x10, x2
    5c4c:	f9401100 	ldr	x0, [x8, #32]
    5c50:	b4000380 	cbz	x0, 5cc0 <fwp_main_thread+0xe1c>
    5c54:	38626942 	ldrb	w2, [x10, x2]
    5c58:	7100085f 	cmp	w2, #0x2
    5c5c:	54000fa0 	b.eq	5e50 <fwp_main_thread+0xfac>  // b.none
    5c60:	7100045f 	cmp	w2, #0x1
    5c64:	540002e1 	b.ne	5cc0 <fwp_main_thread+0xe1c>  // b.any
    5c68:	2943090a 	ldp	w10, w2, [x8, #24]
    5c6c:	92403ce7 	and	x7, x7, #0xffff
    5c70:	9b0a7ce7 	mul	x7, x7, x10
    5c74:	d360fce7 	lsr	x7, x7, #32
    5c78:	eb0200ff 	cmp	x7, x2
    5c7c:	54000222 	b.cs	5cc0 <fwp_main_thread+0xe1c>  // b.hs, b.nlast
    5c80:	8b070000 	add	x0, x0, x7
    5c84:	39400002 	ldrb	w2, [x0]
    5c88:	340001c2 	cbz	w2, 5cc0 <fwp_main_thread+0xe1c>
    5c8c:	7100045f 	cmp	w2, #0x1
    5c90:	54000b00 	b.eq	5df0 <fwp_main_thread+0xf4c>  // b.none
    5c94:	7103fc5f 	cmp	w2, #0xff
    5c98:	54003ce0 	b.eq	6434 <fwp_main_thread+0x1590>  // b.none
    5c9c:	9115c261 	add	x1, x19, #0x570
    5ca0:	51000442 	sub	w2, w2, #0x1
    5ca4:	39000002 	strb	w2, [x0]
    5ca8:	f949ec26 	ldr	x6, [x1, #5080]
    5cac:	fd400b44 	ldr	d4, [x26, #16]
    5cb0:	f949d821 	ldr	x1, [x1, #5040]
    5cb4:	d370bcc6 	lsl	x6, x6, #16
    5cb8:	fd400742 	ldr	d2, [x26, #8]
    5cbc:	d503201f 	nop
    5cc0:	cb010341 	sub	x1, x26, x1
    5cc4:	1e6f39ce 	fsub	d14, d14, d15
    5cc8:	1e62390f 	fsub	d15, d8, d2
    5ccc:	eb0100df 	cmp	x6, x1
    5cd0:	540003c9 	b.ls	5d48 <fwp_main_thread+0xea4>  // b.plast
    5cd4:	9115c262 	add	x2, x19, #0x570
    5cd8:	d350fc20 	lsr	x0, x1, #16
    5cdc:	8b000800 	add	x0, x0, x0, lsl #2
    5ce0:	f949fc47 	ldr	x7, [x2, #5112]
    5ce4:	d37df000 	lsl	x0, x0, #3
    5ce8:	8b0000e6 	add	x6, x7, x0
    5cec:	f94010c2 	ldr	x2, [x6, #32]
    5cf0:	b40002c2 	cbz	x2, 5d48 <fwp_main_thread+0xea4>
    5cf4:	386068e0 	ldrb	w0, [x7, x0]
    5cf8:	7100081f 	cmp	w0, #0x2
    5cfc:	54000b00 	b.eq	5e5c <fwp_main_thread+0xfb8>  // b.none
    5d00:	7100041f 	cmp	w0, #0x1
    5d04:	54000221 	b.ne	5d48 <fwp_main_thread+0xea4>  // b.any
    5d08:	294300c7 	ldp	w7, w0, [x6, #24]
    5d0c:	92403c21 	and	x1, x1, #0xffff
    5d10:	9b077c21 	mul	x1, x1, x7
    5d14:	d360fc21 	lsr	x1, x1, #32
    5d18:	eb00003f 	cmp	x1, x0
    5d1c:	54000162 	b.cs	5d48 <fwp_main_thread+0xea4>  // b.hs, b.nlast
    5d20:	8b010042 	add	x2, x2, x1
    5d24:	39400040 	ldrb	w0, [x2]
    5d28:	34000100 	cbz	w0, 5d48 <fwp_main_thread+0xea4>
    5d2c:	7100041f 	cmp	w0, #0x1
    5d30:	54000720 	b.eq	5e14 <fwp_main_thread+0xf70>  // b.none
    5d34:	7103fc1f 	cmp	w0, #0xff
    5d38:	54003a60 	b.eq	6484 <fwp_main_thread+0x15e0>  // b.none
    5d3c:	51000400 	sub	w0, w0, #0x1
    5d40:	39000040 	strb	w0, [x2]
    5d44:	d503201f 	nop
    5d48:	1e6e09a0 	fmul	d0, d13, d14
    5d4c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5d50:	1e6e09ce 	fmul	d14, d14, d14
    5d54:	1e643821 	fsub	d1, d1, d4
    5d58:	1e602800 	fadd	d0, d0, d0
    5d5c:	1e6809ce 	fmul	d14, d14, d8
    5d60:	1e6f0821 	fmul	d1, d1, d15
    5d64:	1e690800 	fmul	d0, d0, d9
    5d68:	1e612821 	fadd	d1, d1, d1
    5d6c:	1e6e2800 	fadd	d0, d0, d14
    5d70:	1e612800 	fadd	d0, d0, d1
    5d74:	1e6c2800 	fadd	d0, d0, d12
    5d78:	f94002a0 	ldr	x0, [x21]
    5d7c:	1e6a0800 	fmul	d0, d0, d10
    5d80:	1e603960 	fsub	d0, d11, d0
    5d84:	b7f85300 	tbnz	x0, #63, 67e4 <fwp_main_thread+0x1940>
    5d88:	fc3b6aa0 	str	d0, [x21, x27]
    5d8c:	9100237b 	add	x27, x27, #0x8
    5d90:	eb1c02df 	cmp	x22, x28
    5d94:	540007e0 	b.eq	5e90 <fwp_main_thread+0xfec>  // b.none
    5d98:	f9400282 	ldr	x2, [x20]
    5d9c:	9240f841 	and	x1, x2, #0x7fffffffffffffff
    5da0:	eb01039f 	cmp	x28, x1
    5da4:	54ffe563 	b.cc	5a50 <fwp_main_thread+0xbac>  // b.lo, b.ul, b.last
    5da8:	f00000c0 	adrp	x0, 20000 <__data_start>
    5dac:	91004000 	add	x0, x0, #0x10
    5db0:	9100a000 	add	x0, x0, #0x28
    5db4:	97fff133 	bl	2280 <fwp_trap>
    5db8:	72003c3f 	tst	w1, #0xffff
    5dbc:	54ffba21 	b.ne	5500 <fwp_main_thread+0x65c>  // b.any
    5dc0:	394002a0 	ldrb	w0, [x21]
    5dc4:	7103fc1f 	cmp	w0, #0xff
    5dc8:	54ffb9a1 	b.ne	54fc <fwp_main_thread+0x658>  // b.any
    5dcc:	aa1503e0 	mov	x0, x21
    5dd0:	97fff3ed 	bl	2d84 <fwp_rc_forget_slot>
    5dd4:	17fffdca 	b	54fc <fwp_main_thread+0x658>
    5dd8:	aa0503e0 	mov	x0, x5
    5ddc:	97fff489 	bl	3000 <fwp_mem_free>
    5de0:	aa1503e0 	mov	x0, x21
    5de4:	17fffeeb 	b	5990 <fwp_main_thread+0xaec>
    5de8:	2f00e400 	movi	d0, #0x0
    5dec:	17ffffe2 	b	5d74 <fwp_main_thread+0xed0>
    5df0:	aa0903e0 	mov	x0, x9
    5df4:	97fff5a3 	bl	3480 <fwp_rc_free_arr>
    5df8:	9115c260 	add	x0, x19, #0x570
    5dfc:	fd400742 	ldr	d2, [x26, #8]
    5e00:	fd400b44 	ldr	d4, [x26, #16]
    5e04:	f949ec06 	ldr	x6, [x0, #5080]
    5e08:	f949d801 	ldr	x1, [x0, #5040]
    5e0c:	d370bcc6 	lsl	x6, x6, #16
    5e10:	17ffffac 	b	5cc0 <fwp_main_thread+0xe1c>
    5e14:	aa1a03e0 	mov	x0, x26
    5e18:	fd0007e4 	str	d4, [sp, #8]
    5e1c:	97fff599 	bl	3480 <fwp_rc_free_arr>
    5e20:	fd4007e4 	ldr	d4, [sp, #8]
    5e24:	17ffffc9 	b	5d48 <fwp_main_thread+0xea4>
    5e28:	72003c3f 	tst	w1, #0xffff
    5e2c:	54ffe901 	b.ne	5b4c <fwp_main_thread+0xca8>  // b.any
    5e30:	39400001 	ldrb	w1, [x0]
    5e34:	7103fc3f 	cmp	w1, #0xff
    5e38:	54ffe861 	b.ne	5b44 <fwp_main_thread+0xca0>  // b.any
    5e3c:	d503201f 	nop
    5e40:	f90007e0 	str	x0, [sp, #8]
    5e44:	97fff3d0 	bl	2d84 <fwp_rc_forget_slot>
    5e48:	f94007e0 	ldr	x0, [sp, #8]
    5e4c:	17ffff3e 	b	5b44 <fwp_main_thread+0xca0>
    5e50:	72003cff 	tst	w7, #0xffff
    5e54:	54fff361 	b.ne	5cc0 <fwp_main_thread+0xe1c>  // b.any
    5e58:	17ffff8b 	b	5c84 <fwp_main_thread+0xde0>
    5e5c:	72003c3f 	tst	w1, #0xffff
    5e60:	54fff741 	b.ne	5d48 <fwp_main_thread+0xea4>  // b.any
    5e64:	17ffffb0 	b	5d24 <fwp_main_thread+0xe80>
    5e68:	72003cff 	tst	w7, #0xffff
    5e6c:	54ffebc0 	b.eq	5be4 <fwp_main_thread+0xd40>  // b.none
    5e70:	fd400b44 	ldr	d4, [x26, #16]
    5e74:	fd400742 	ldr	d2, [x26, #8]
    5e78:	6d40b920 	ldp	d0, d14, [x9, #8]
    5e7c:	1e64088f 	fmul	d15, d4, d4
    5e80:	1e620883 	fmul	d3, d4, d2
    5e84:	1e632863 	fadd	d3, d3, d3
    5e88:	1e63380d 	fsub	d13, d0, d3
    5e8c:	17ffff6b 	b	5c38 <fwp_main_thread+0xd94>
    5e90:	9115c276 	add	x22, x19, #0x570
    5e94:	f949dac1 	ldr	x1, [x22, #5040]
    5e98:	f949eec0 	ldr	x0, [x22, #5080]
    5e9c:	cb010281 	sub	x1, x20, x1
    5ea0:	eb00403f 	cmp	x1, x0, lsl #16
    5ea4:	540003a2 	b.cs	5f18 <fwp_main_thread+0x1074>  // b.hs, b.nlast
    5ea8:	d350fc20 	lsr	x0, x1, #16
    5eac:	f949fec4 	ldr	x4, [x22, #5112]
    5eb0:	8b000800 	add	x0, x0, x0, lsl #2
    5eb4:	d37df000 	lsl	x0, x0, #3
    5eb8:	8b000082 	add	x2, x4, x0
    5ebc:	f9401059 	ldr	x25, [x2, #32]
    5ec0:	b40002d9 	cbz	x25, 5f18 <fwp_main_thread+0x1074>
    5ec4:	38606883 	ldrb	w3, [x4, x0]
    5ec8:	7100087f 	cmp	w3, #0x2
    5ecc:	54002160 	b.eq	62f8 <fwp_main_thread+0x1454>  // b.none
    5ed0:	7100047f 	cmp	w3, #0x1
    5ed4:	54000221 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    5ed8:	29430843 	ldp	w3, w2, [x2, #24]
    5edc:	92403c21 	and	x1, x1, #0xffff
    5ee0:	9b037c21 	mul	x1, x1, x3
    5ee4:	d360fc21 	lsr	x1, x1, #32
    5ee8:	eb02003f 	cmp	x1, x2
    5eec:	54000162 	b.cs	5f18 <fwp_main_thread+0x1074>  // b.hs, b.nlast
    5ef0:	8b010339 	add	x25, x25, x1
    5ef4:	39400321 	ldrb	w1, [x25]
    5ef8:	34000101 	cbz	w1, 5f18 <fwp_main_thread+0x1074>
    5efc:	7100043f 	cmp	w1, #0x1
    5f00:	54000160 	b.eq	5f2c <fwp_main_thread+0x1088>  // b.none
    5f04:	7103fc3f 	cmp	w1, #0xff
    5f08:	54003520 	b.eq	65ac <fwp_main_thread+0x1708>  // b.none
    5f0c:	51000421 	sub	w1, w1, #0x1
    5f10:	39000321 	strb	w1, [x25]
    5f14:	d503201f 	nop
    5f18:	b40004d7 	cbz	x23, 5fb0 <fwp_main_thread+0x110c>
    5f1c:	f10006f7 	subs	x23, x23, #0x1
    5f20:	54004f06 	b.vs	6900 <fwp_main_thread+0x1a5c>
    5f24:	aa1503f4 	mov	x20, x21
    5f28:	17fffe9e 	b	59a0 <fwp_main_thread+0xafc>
    5f2c:	f9400285 	ldr	x5, [x20]
    5f30:	aa1403e0 	mov	x0, x20
    5f34:	f949eec3 	ldr	x3, [x22, #5080]
    5f38:	f949dac1 	ldr	x1, [x22, #5040]
    5f3c:	d370bc63 	lsl	x3, x3, #16
    5f40:	cb010282 	sub	x2, x20, x1
    5f44:	b7f81e05 	tbnz	x5, #63, 6304 <fwp_main_thread+0x1460>
    5f48:	eb02007f 	cmp	x3, x2
    5f4c:	54fffe69 	b.ls	5f18 <fwp_main_thread+0x1074>  // b.plast
    5f50:	d350fc40 	lsr	x0, x2, #16
    5f54:	8b000800 	add	x0, x0, x0, lsl #2
    5f58:	d37df000 	lsl	x0, x0, #3
    5f5c:	8b000083 	add	x3, x4, x0
    5f60:	f9401061 	ldr	x1, [x3, #32]
    5f64:	b4fffda1 	cbz	x1, 5f18 <fwp_main_thread+0x1074>
    5f68:	38606880 	ldrb	w0, [x4, x0]
    5f6c:	7100081f 	cmp	w0, #0x2
    5f70:	540021c0 	b.eq	63a8 <fwp_main_thread+0x1504>  // b.none
    5f74:	7100041f 	cmp	w0, #0x1
    5f78:	54fffd01 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    5f7c:	92403c40 	and	x0, x2, #0xffff
    5f80:	29430864 	ldp	w4, w2, [x3, #24]
    5f84:	9b047c00 	mul	x0, x0, x4
    5f88:	d360fc00 	lsr	x0, x0, #32
    5f8c:	eb02001f 	cmp	x0, x2
    5f90:	54fffc42 	b.cs	5f18 <fwp_main_thread+0x1074>  // b.hs, b.nlast
    5f94:	8b000021 	add	x1, x1, x0
    5f98:	39400020 	ldrb	w0, [x1]
    5f9c:	7100041f 	cmp	w0, #0x1
    5fa0:	54fffbc1 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    5fa4:	aa1403e0 	mov	x0, x20
    5fa8:	97fff416 	bl	3000 <fwp_mem_free>
    5fac:	b5fffb97 	cbnz	x23, 5f1c <fwp_main_thread+0x1078>
    5fb0:	f9400be0 	ldr	x0, [sp, #16]
    5fb4:	52800b63 	mov	w3, #0x5b                  	// #91
    5fb8:	f94013e1 	ldr	x1, [sp, #32]
    5fbc:	d2800022 	mov	x2, #0x1                   	// #1
    5fc0:	390123e3 	strb	w3, [sp, #72]
    5fc4:	d280001c 	mov	x28, #0x0                   	// #0
    5fc8:	a9067fff 	stp	xzr, xzr, [sp, #96]
    5fcc:	d00000d4 	adrp	x20, 1f000 <__FRAME_END__+0x16b78>
    5fd0:	f9003bff 	str	xzr, [sp, #112]
    5fd4:	97fff04f 	bl	2110 <buf_put>
    5fd8:	f94002a0 	ldr	x0, [x21]
    5fdc:	f240f817 	ands	x23, x0, #0x7fffffffffffffff
    5fe0:	54000400 	b.eq	6060 <fwp_main_thread+0x11bc>  // b.none
    5fe4:	912ca294 	add	x20, x20, #0xb28
    5fe8:	d0000016 	adrp	x22, 7000 <atexit>
    5fec:	91014294 	add	x20, x20, #0x50
    5ff0:	910f62d6 	add	x22, x22, #0x3d8
    5ff4:	910022b9 	add	x25, x21, #0x8
    5ff8:	1400000e 	b	6030 <fwp_main_thread+0x118c>
    5ffc:	f87c7821 	ldr	x1, [x1, x28, lsl #3]
    6000:	aa1403e2 	mov	x2, x20
    6004:	f9400bfa 	ldr	x26, [sp, #16]
    6008:	9100079c 	add	x28, x28, #0x1
    600c:	aa1a03e0 	mov	x0, x26
    6010:	97fff7bc 	bl	3f00 <fwp_write.constprop.0>
    6014:	eb1c02ff 	cmp	x23, x28
    6018:	54000240 	b.eq	6060 <fwp_main_thread+0x11bc>  // b.none
    601c:	aa1a03e0 	mov	x0, x26
    6020:	aa1603e1 	mov	x1, x22
    6024:	d2800042 	mov	x2, #0x2                   	// #2
    6028:	97fff03a 	bl	2110 <buf_put>
    602c:	f94002a0 	ldr	x0, [x21]
    6030:	aa1903e1 	mov	x1, x25
    6034:	b6fffe40 	tbz	x0, #63, 5ffc <fwp_main_thread+0x1158>
    6038:	f9400aa1 	ldr	x1, [x21, #16]
    603c:	aa1403e2 	mov	x2, x20
    6040:	f9400bfa 	ldr	x26, [sp, #16]
    6044:	f87c7821 	ldr	x1, [x1, x28, lsl #3]
    6048:	aa1a03e0 	mov	x0, x26
    604c:	9100079c 	add	x28, x28, #0x1
    6050:	97fff7ac 	bl	3f00 <fwp_write.constprop.0>
    6054:	eb1c02ff 	cmp	x23, x28
    6058:	54fffe21 	b.ne	601c <fwp_main_thread+0x1178>  // b.any
    605c:	d503201f 	nop
    6060:	f9400be0 	ldr	x0, [sp, #16]
    6064:	52800ba3 	mov	w3, #0x5d                  	// #93
    6068:	f94013e1 	ldr	x1, [sp, #32]
    606c:	d2800022 	mov	x2, #0x1                   	// #1
    6070:	390123e3 	strb	w3, [sp, #72]
    6074:	97fff027 	bl	2110 <buf_put>
    6078:	a9465bf7 	ldp	x23, x22, [sp, #96]
    607c:	b0000000 	adrp	x0, 7000 <atexit>
    6080:	9101c000 	add	x0, x0, #0x70
    6084:	f10002ff 	cmp	x23, #0x0
    6088:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    608c:	b1002adf 	cmn	x22, #0xa
    6090:	54003fc8 	b.hi	6888 <fwp_main_thread+0x19e4>  // b.pmore
    6094:	910026c0 	add	x0, x22, #0x9
    6098:	52800021 	mov	w1, #0x1                   	// #1
    609c:	97fff51a 	bl	3504 <fwp_heap_alloc>
    60a0:	aa0003f4 	mov	x20, x0
    60a4:	aa1703e1 	mov	x1, x23
    60a8:	aa0003f7 	mov	x23, x0
    60ac:	aa1603e2 	mov	x2, x22
    60b0:	f80086f6 	str	x22, [x23], #8
    60b4:	8b160296 	add	x22, x20, x22
    60b8:	aa1703e0 	mov	x0, x23
    60bc:	97ffeca9 	bl	1360 <memcpy@plt>
    60c0:	390022df 	strb	wzr, [x22, #8]
    60c4:	f94033e0 	ldr	x0, [sp, #96]
    60c8:	97ffed3e 	bl	15c0 <free@plt>
    60cc:	9115c262 	add	x2, x19, #0x570
    60d0:	f949ec43 	ldr	x3, [x2, #5080]
    60d4:	f949d841 	ldr	x1, [x2, #5040]
    60d8:	d370bc63 	lsl	x3, x3, #16
    60dc:	cb010284 	sub	x4, x20, x1
    60e0:	eb03009f 	cmp	x4, x3
    60e4:	540003a2 	b.cs	6158 <fwp_main_thread+0x12b4>  // b.hs, b.nlast
    60e8:	d350fc80 	lsr	x0, x4, #16
    60ec:	f949fc45 	ldr	x5, [x2, #5112]
    60f0:	8b000800 	add	x0, x0, x0, lsl #2
    60f4:	d37df002 	lsl	x2, x0, #3
    60f8:	8b0200a0 	add	x0, x5, x2
    60fc:	f9401016 	ldr	x22, [x0, #32]
    6100:	b40002d6 	cbz	x22, 6158 <fwp_main_thread+0x12b4>
    6104:	386268a2 	ldrb	w2, [x5, x2]
    6108:	7100085f 	cmp	w2, #0x2
    610c:	540027c0 	b.eq	6604 <fwp_main_thread+0x1760>  // b.none
    6110:	7100045f 	cmp	w2, #0x1
    6114:	54000221 	b.ne	6158 <fwp_main_thread+0x12b4>  // b.any
    6118:	29430005 	ldp	w5, w0, [x0, #24]
    611c:	92403c82 	and	x2, x4, #0xffff
    6120:	9b057c42 	mul	x2, x2, x5
    6124:	d360fc42 	lsr	x2, x2, #32
    6128:	eb00005f 	cmp	x2, x0
    612c:	54000162 	b.cs	6158 <fwp_main_thread+0x12b4>  // b.hs, b.nlast
    6130:	8b0202d6 	add	x22, x22, x2
    6134:	394002c0 	ldrb	w0, [x22]
    6138:	7103fc1f 	cmp	w0, #0xff
    613c:	540026e0 	b.eq	6618 <fwp_main_thread+0x1774>  // b.none
    6140:	9115c260 	add	x0, x19, #0x570
    6144:	52800021 	mov	w1, #0x1                   	// #1
    6148:	390002c1 	strb	w1, [x22]
    614c:	f949ec03 	ldr	x3, [x0, #5080]
    6150:	f949d801 	ldr	x1, [x0, #5040]
    6154:	d370bc63 	lsl	x3, x3, #16
    6158:	cb0102a1 	sub	x1, x21, x1
    615c:	9115c279 	add	x25, x19, #0x570
    6160:	eb03003f 	cmp	x1, x3
    6164:	540003a2 	b.cs	61d8 <fwp_main_thread+0x1334>  // b.hs, b.nlast
    6168:	d350fc20 	lsr	x0, x1, #16
    616c:	f949ff23 	ldr	x3, [x25, #5112]
    6170:	8b000800 	add	x0, x0, x0, lsl #2
    6174:	d37df002 	lsl	x2, x0, #3
    6178:	8b020060 	add	x0, x3, x2
    617c:	f9401016 	ldr	x22, [x0, #32]
    6180:	b40002d6 	cbz	x22, 61d8 <fwp_main_thread+0x1334>
    6184:	38626862 	ldrb	w2, [x3, x2]
    6188:	7100085f 	cmp	w2, #0x2
    618c:	54001c40 	b.eq	6514 <fwp_main_thread+0x1670>  // b.none
    6190:	7100045f 	cmp	w2, #0x1
    6194:	54000221 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    6198:	29430002 	ldp	w2, w0, [x0, #24]
    619c:	92403c21 	and	x1, x1, #0xffff
    61a0:	9b027c21 	mul	x1, x1, x2
    61a4:	d360fc21 	lsr	x1, x1, #32
    61a8:	eb00003f 	cmp	x1, x0
    61ac:	54000162 	b.cs	61d8 <fwp_main_thread+0x1334>  // b.hs, b.nlast
    61b0:	8b0102d6 	add	x22, x22, x1
    61b4:	394002c0 	ldrb	w0, [x22]
    61b8:	34000100 	cbz	w0, 61d8 <fwp_main_thread+0x1334>
    61bc:	7100041f 	cmp	w0, #0x1
    61c0:	54000fa0 	b.eq	63b4 <fwp_main_thread+0x1510>  // b.none
    61c4:	7103fc1f 	cmp	w0, #0xff
    61c8:	54002820 	b.eq	66cc <fwp_main_thread+0x1828>  // b.none
    61cc:	51000400 	sub	w0, w0, #0x1
    61d0:	390002c0 	strb	w0, [x22]
    61d4:	d503201f 	nop
    61d8:	d00000c1 	adrp	x1, 20000 <__data_start>
    61dc:	aa1703e0 	mov	x0, x23
    61e0:	f9400282 	ldr	x2, [x20]
    61e4:	f9404823 	ldr	x3, [x1, #144]
    61e8:	d2800021 	mov	x1, #0x1                   	// #1
    61ec:	97ffed05 	bl	1600 <fwrite@plt>
    61f0:	d00000c0 	adrp	x0, 20000 <__data_start>
    61f4:	f9404801 	ldr	x1, [x0, #144]
    61f8:	52800140 	mov	w0, #0xa                   	// #10
    61fc:	97ffec89 	bl	1420 <fputc@plt>
    6200:	9115c262 	add	x2, x19, #0x570
    6204:	f949d841 	ldr	x1, [x2, #5040]
    6208:	f949ec40 	ldr	x0, [x2, #5080]
    620c:	cb010281 	sub	x1, x20, x1
    6210:	eb00403f 	cmp	x1, x0, lsl #16
    6214:	540003a2 	b.cs	6288 <fwp_main_thread+0x13e4>  // b.hs, b.nlast
    6218:	d350fc20 	lsr	x0, x1, #16
    621c:	f949fc43 	ldr	x3, [x2, #5112]
    6220:	8b000800 	add	x0, x0, x0, lsl #2
    6224:	d37df002 	lsl	x2, x0, #3
    6228:	8b020060 	add	x0, x3, x2
    622c:	f9401015 	ldr	x21, [x0, #32]
    6230:	b40002d5 	cbz	x21, 6288 <fwp_main_thread+0x13e4>
    6234:	38626862 	ldrb	w2, [x3, x2]
    6238:	7100085f 	cmp	w2, #0x2
    623c:	54001f40 	b.eq	6624 <fwp_main_thread+0x1780>  // b.none
    6240:	7100045f 	cmp	w2, #0x1
    6244:	54000221 	b.ne	6288 <fwp_main_thread+0x13e4>  // b.any
    6248:	29430002 	ldp	w2, w0, [x0, #24]
    624c:	92403c21 	and	x1, x1, #0xffff
    6250:	9b027c21 	mul	x1, x1, x2
    6254:	d360fc21 	lsr	x1, x1, #32
    6258:	eb00003f 	cmp	x1, x0
    625c:	54000162 	b.cs	6288 <fwp_main_thread+0x13e4>  // b.hs, b.nlast
    6260:	8b0102b5 	add	x21, x21, x1
    6264:	394002a0 	ldrb	w0, [x21]
    6268:	34000100 	cbz	w0, 6288 <fwp_main_thread+0x13e4>
    626c:	7100041f 	cmp	w0, #0x1
    6270:	540013e0 	b.eq	64ec <fwp_main_thread+0x1648>  // b.none
    6274:	7103fc1f 	cmp	w0, #0xff
    6278:	540028a0 	b.eq	678c <fwp_main_thread+0x18e8>  // b.none
    627c:	51000400 	sub	w0, w0, #0x1
    6280:	390002a0 	strb	w0, [x21]
    6284:	d503201f 	nop
    6288:	f9401fe0 	ldr	x0, [sp, #56]
    628c:	f9400800 	ldr	x0, [x0, #16]
    6290:	f9001fe0 	str	x0, [sp, #56]
    6294:	b5ffa320 	cbnz	x0, 56f8 <fwp_main_thread+0x854>
    6298:	f94017e0 	ldr	x0, [sp, #40]
    629c:	97fff56d 	bl	3850 <fwp_drop0>
    62a0:	f9400fe0 	ldr	x0, [sp, #24]
    62a4:	97fff56b 	bl	3850 <fwp_drop0>
    62a8:	d00000c0 	adrp	x0, 20000 <__data_start>
    62ac:	91024000 	add	x0, x0, #0x90
    62b0:	6d5c27e8 	ldp	d8, d9, [sp, #448]
    62b4:	52800021 	mov	w1, #0x1                   	// #1
    62b8:	6d5d2fea 	ldp	d10, d11, [sp, #464]
    62bc:	6d5e37ec 	ldp	d12, d13, [sp, #480]
    62c0:	6d5f3fee 	ldp	d14, d15, [sp, #496]
    62c4:	b902c401 	str	w1, [x0, #708]
    62c8:	f901681f 	str	xzr, [x0, #720]
    62cc:	17fffb41 	b	4fd0 <fwp_main_thread+0x12c>
    62d0:	f9400a80 	ldr	x0, [x20, #16]
    62d4:	17fffde1 	b	5a58 <fwp_main_thread+0xbb4>
    62d8:	f9400a82 	ldr	x2, [x20, #16]
    62dc:	17fffe22 	b	5b64 <fwp_main_thread+0xcc0>
    62e0:	f90007e0 	str	x0, [sp, #8]
    62e4:	f9001be9 	str	x9, [sp, #48]
    62e8:	97fff2a7 	bl	2d84 <fwp_rc_forget_slot>
    62ec:	f94007e0 	ldr	x0, [sp, #8]
    62f0:	f9401be9 	ldr	x9, [sp, #48]
    62f4:	17fffe3f 	b	5bf0 <fwp_main_thread+0xd4c>
    62f8:	72003c3f 	tst	w1, #0xffff
    62fc:	54ffe0e1 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    6300:	17fffefd 	b	5ef4 <fwp_main_thread+0x1050>
    6304:	f9400694 	ldr	x20, [x20, #8]
    6308:	eb02007f 	cmp	x3, x2
    630c:	54000369 	b.ls	6378 <fwp_main_thread+0x14d4>  // b.plast
    6310:	d350fc45 	lsr	x5, x2, #16
    6314:	8b0508a5 	add	x5, x5, x5, lsl #2
    6318:	d37df0a5 	lsl	x5, x5, #3
    631c:	8b050087 	add	x7, x4, x5
    6320:	f94010e6 	ldr	x6, [x7, #32]
    6324:	b40002a6 	cbz	x6, 6378 <fwp_main_thread+0x14d4>
    6328:	38656884 	ldrb	w4, [x4, x5]
    632c:	7100089f 	cmp	w4, #0x2
    6330:	54000e40 	b.eq	64f8 <fwp_main_thread+0x1654>  // b.none
    6334:	7100049f 	cmp	w4, #0x1
    6338:	54000201 	b.ne	6378 <fwp_main_thread+0x14d4>  // b.any
    633c:	294310e5 	ldp	w5, w4, [x7, #24]
    6340:	92403c42 	and	x2, x2, #0xffff
    6344:	9b057c42 	mul	x2, x2, x5
    6348:	d360fc42 	lsr	x2, x2, #32
    634c:	eb04005f 	cmp	x2, x4
    6350:	54000142 	b.cs	6378 <fwp_main_thread+0x14d4>  // b.hs, b.nlast
    6354:	8b0200c6 	add	x6, x6, x2
    6358:	394000c2 	ldrb	w2, [x6]
    635c:	7100045f 	cmp	w2, #0x1
    6360:	540000c1 	b.ne	6378 <fwp_main_thread+0x14d4>  // b.any
    6364:	97fff327 	bl	3000 <fwp_mem_free>
    6368:	9115c260 	add	x0, x19, #0x570
    636c:	f949ec03 	ldr	x3, [x0, #5080]
    6370:	f949d801 	ldr	x1, [x0, #5040]
    6374:	d370bc63 	lsl	x3, x3, #16
    6378:	cb010281 	sub	x1, x20, x1
    637c:	eb01007f 	cmp	x3, x1
    6380:	54ffd948 	b.hi	5ea8 <fwp_main_thread+0x1004>  // b.pmore
    6384:	17fffee5 	b	5f18 <fwp_main_thread+0x1074>
    6388:	72003c3f 	tst	w1, #0xffff
    638c:	54ffb561 	b.ne	5a38 <fwp_main_thread+0xb94>  // b.any
    6390:	39400320 	ldrb	w0, [x25]
    6394:	7103fc1f 	cmp	w0, #0xff
    6398:	54ffb4c1 	b.ne	5a30 <fwp_main_thread+0xb8c>  // b.any
    639c:	aa1903e0 	mov	x0, x25
    63a0:	97fff279 	bl	2d84 <fwp_rc_forget_slot>
    63a4:	17fffda3 	b	5a30 <fwp_main_thread+0xb8c>
    63a8:	72003c5f 	tst	w2, #0xffff
    63ac:	54ffdb61 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    63b0:	17fffefa 	b	5f98 <fwp_main_thread+0x10f4>
    63b4:	f94002a0 	ldr	x0, [x21]
    63b8:	b7f80b40 	tbnz	x0, #63, 6520 <fwp_main_thread+0x167c>
    63bc:	9115c261 	add	x1, x19, #0x570
    63c0:	f949d820 	ldr	x0, [x1, #5040]
    63c4:	f949ec21 	ldr	x1, [x1, #5080]
    63c8:	cb0002a0 	sub	x0, x21, x0
    63cc:	eb01401f 	cmp	x0, x1, lsl #16
    63d0:	54fff042 	b.cs	61d8 <fwp_main_thread+0x1334>  // b.hs, b.nlast
    63d4:	d350fc01 	lsr	x1, x0, #16
    63d8:	8b010821 	add	x1, x1, x1, lsl #2
    63dc:	d37df021 	lsl	x1, x1, #3
    63e0:	8b010064 	add	x4, x3, x1
    63e4:	f9401082 	ldr	x2, [x4, #32]
    63e8:	b4ffef82 	cbz	x2, 61d8 <fwp_main_thread+0x1334>
    63ec:	38616861 	ldrb	w1, [x3, x1]
    63f0:	7100083f 	cmp	w1, #0x2
    63f4:	540011e0 	b.eq	6630 <fwp_main_thread+0x178c>  // b.none
    63f8:	7100043f 	cmp	w1, #0x1
    63fc:	54ffeee1 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    6400:	29430483 	ldp	w3, w1, [x4, #24]
    6404:	92403c00 	and	x0, x0, #0xffff
    6408:	9b037c00 	mul	x0, x0, x3
    640c:	d360fc00 	lsr	x0, x0, #32
    6410:	eb01001f 	cmp	x0, x1
    6414:	54ffee22 	b.cs	61d8 <fwp_main_thread+0x1334>  // b.hs, b.nlast
    6418:	8b000042 	add	x2, x2, x0
    641c:	39400040 	ldrb	w0, [x2]
    6420:	7100041f 	cmp	w0, #0x1
    6424:	54ffeda1 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    6428:	aa1503e0 	mov	x0, x21
    642c:	97fff2f5 	bl	3000 <fwp_mem_free>
    6430:	17ffff6a 	b	61d8 <fwp_main_thread+0x1334>
    6434:	ca404402 	eor	x2, x0, x0, lsr #17
    6438:	9115c267 	add	x7, x19, #0x570
    643c:	ca422442 	eor	x2, x2, x2, lsr #9
    6440:	8b220ce2 	add	x2, x7, w2, uxtb #3
    6444:	f94a2442 	ldr	x2, [x2, #5192]
    6448:	b5000082 	cbnz	x2, 6458 <fwp_main_thread+0x15b4>
    644c:	140000eb 	b	67f8 <fwp_main_thread+0x1954>
    6450:	f9400842 	ldr	x2, [x2, #16]
    6454:	b4001d22 	cbz	x2, 67f8 <fwp_main_thread+0x1954>
    6458:	f9400047 	ldr	x7, [x2]
    645c:	eb0000ff 	cmp	x7, x0
    6460:	54ffff81 	b.ne	6450 <fwp_main_thread+0x15ac>  // b.any
    6464:	f9400447 	ldr	x7, [x2, #8]
    6468:	d10004e7 	sub	x7, x7, #0x1
    646c:	f9000447 	str	x7, [x2, #8]
    6470:	f103f8ff 	cmp	x7, #0xfe
    6474:	54000e40 	b.eq	663c <fwp_main_thread+0x1798>  // b.none
    6478:	fd400742 	ldr	d2, [x26, #8]
    647c:	fd400b44 	ldr	d4, [x26, #16]
    6480:	17fffe10 	b	5cc0 <fwp_main_thread+0xe1c>
    6484:	ca424440 	eor	x0, x2, x2, lsr #17
    6488:	9115c261 	add	x1, x19, #0x570
    648c:	ca402400 	eor	x0, x0, x0, lsr #9
    6490:	8b200c20 	add	x0, x1, w0, uxtb #3
    6494:	f94a2400 	ldr	x0, [x0, #5192]
    6498:	b5000080 	cbnz	x0, 64a8 <fwp_main_thread+0x1604>
    649c:	140000d7 	b	67f8 <fwp_main_thread+0x1954>
    64a0:	f9400800 	ldr	x0, [x0, #16]
    64a4:	b4001aa0 	cbz	x0, 67f8 <fwp_main_thread+0x1954>
    64a8:	f9400001 	ldr	x1, [x0]
    64ac:	eb01005f 	cmp	x2, x1
    64b0:	54ffff81 	b.ne	64a0 <fwp_main_thread+0x15fc>  // b.any
    64b4:	f9400401 	ldr	x1, [x0, #8]
    64b8:	d1000421 	sub	x1, x1, #0x1
    64bc:	f9000401 	str	x1, [x0, #8]
    64c0:	f103f83f 	cmp	x1, #0xfe
    64c4:	54ffc421 	b.ne	5d48 <fwp_main_thread+0xea4>  // b.any
    64c8:	aa0203e0 	mov	x0, x2
    64cc:	f90007e2 	str	x2, [sp, #8]
    64d0:	fd001be4 	str	d4, [sp, #48]
    64d4:	97fff22c 	bl	2d84 <fwp_rc_forget_slot>
    64d8:	f94007e2 	ldr	x2, [sp, #8]
    64dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64e0:	fd401be4 	ldr	d4, [sp, #48]
    64e4:	39000040 	strb	w0, [x2]
    64e8:	17fffe18 	b	5d48 <fwp_main_thread+0xea4>
    64ec:	aa1403e0 	mov	x0, x20
    64f0:	97fff3e4 	bl	3480 <fwp_rc_free_arr>
    64f4:	17ffff65 	b	6288 <fwp_main_thread+0x13e4>
    64f8:	72003c5f 	tst	w2, #0xffff
    64fc:	54fff3e1 	b.ne	6378 <fwp_main_thread+0x14d4>  // b.any
    6500:	17ffff96 	b	6358 <fwp_main_thread+0x14b4>
    6504:	72003c7f 	tst	w3, #0xffff
    6508:	54ffa3a0 	b.eq	597c <fwp_main_thread+0xad8>  // b.none
    650c:	aa1503e0 	mov	x0, x21
    6510:	17fffd20 	b	5990 <fwp_main_thread+0xaec>
    6514:	72003c3f 	tst	w1, #0xffff
    6518:	54ffe601 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    651c:	17ffff26 	b	61b4 <fwp_main_thread+0x1310>
    6520:	f94006b6 	ldr	x22, [x21, #8]
    6524:	aa1503e0 	mov	x0, x21
    6528:	97fff3d6 	bl	3480 <fwp_rc_free_arr>
    652c:	9115c260 	add	x0, x19, #0x570
    6530:	f949d801 	ldr	x1, [x0, #5040]
    6534:	f949ec00 	ldr	x0, [x0, #5080]
    6538:	cb0102c1 	sub	x1, x22, x1
    653c:	eb00403f 	cmp	x1, x0, lsl #16
    6540:	54ffe4c2 	b.cs	61d8 <fwp_main_thread+0x1334>  // b.hs, b.nlast
    6544:	aa1603f5 	mov	x21, x22
    6548:	17ffff08 	b	6168 <fwp_main_thread+0x12c4>
    654c:	72003c1f 	tst	w0, #0xffff
    6550:	54ff9080 	b.eq	5760 <fwp_main_thread+0x8bc>  // b.none
    6554:	f94017e0 	ldr	x0, [sp, #40]
    6558:	b5ff9220 	cbnz	x0, 579c <fwp_main_thread+0x8f8>
    655c:	d2800000 	mov	x0, #0x0                   	// #0
    6560:	97fff4a9 	bl	3804 <fwp_array_new_packed.constprop.0>
    6564:	9115c261 	add	x1, x19, #0x570
    6568:	aa0003f4 	mov	x20, x0
    656c:	aa0103e0 	mov	x0, x1
    6570:	f949d821 	ldr	x1, [x1, #5040]
    6574:	f949ec00 	ldr	x0, [x0, #5080]
    6578:	cb010281 	sub	x1, x20, x1
    657c:	eb00403f 	cmp	x1, x0, lsl #16
    6580:	54ff9323 	b.cc	57e4 <fwp_main_thread+0x940>  // b.lo, b.ul, b.last
    6584:	d2800000 	mov	x0, #0x0                   	// #0
    6588:	17fffd04 	b	5998 <fwp_main_thread+0xaf4>
    658c:	72003c3f 	tst	w1, #0xffff
    6590:	54ff95c1 	b.ne	5848 <fwp_main_thread+0x9a4>  // b.any
    6594:	394002a0 	ldrb	w0, [x21]
    6598:	7103fc1f 	cmp	w0, #0xff
    659c:	54ff9521 	b.ne	5840 <fwp_main_thread+0x99c>  // b.any
    65a0:	aa1503e0 	mov	x0, x21
    65a4:	97fff1f8 	bl	2d84 <fwp_rc_forget_slot>
    65a8:	17fffca6 	b	5840 <fwp_main_thread+0x99c>
    65ac:	ca594720 	eor	x0, x25, x25, lsr #17
    65b0:	9115c261 	add	x1, x19, #0x570
    65b4:	ca402400 	eor	x0, x0, x0, lsr #9
    65b8:	8b200c20 	add	x0, x1, w0, uxtb #3
    65bc:	f94a2401 	ldr	x1, [x0, #5192]
    65c0:	b5000081 	cbnz	x1, 65d0 <fwp_main_thread+0x172c>
    65c4:	1400008d 	b	67f8 <fwp_main_thread+0x1954>
    65c8:	f9400821 	ldr	x1, [x1, #16]
    65cc:	b4001161 	cbz	x1, 67f8 <fwp_main_thread+0x1954>
    65d0:	f9400020 	ldr	x0, [x1]
    65d4:	eb19001f 	cmp	x0, x25
    65d8:	54ffff81 	b.ne	65c8 <fwp_main_thread+0x1724>  // b.any
    65dc:	f9400420 	ldr	x0, [x1, #8]
    65e0:	d1000400 	sub	x0, x0, #0x1
    65e4:	f9000420 	str	x0, [x1, #8]
    65e8:	f103f81f 	cmp	x0, #0xfe
    65ec:	54ffc961 	b.ne	5f18 <fwp_main_thread+0x1074>  // b.any
    65f0:	aa1903e0 	mov	x0, x25
    65f4:	97fff1e4 	bl	2d84 <fwp_rc_forget_slot>
    65f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65fc:	39000320 	strb	w0, [x25]
    6600:	17fffe46 	b	5f18 <fwp_main_thread+0x1074>
    6604:	72003c9f 	tst	w4, #0xffff
    6608:	54ffda81 	b.ne	6158 <fwp_main_thread+0x12b4>  // b.any
    660c:	394002c0 	ldrb	w0, [x22]
    6610:	7103fc1f 	cmp	w0, #0xff
    6614:	54ffd961 	b.ne	6140 <fwp_main_thread+0x129c>  // b.any
    6618:	aa1603e0 	mov	x0, x22
    661c:	97fff1da 	bl	2d84 <fwp_rc_forget_slot>
    6620:	17fffec8 	b	6140 <fwp_main_thread+0x129c>
    6624:	72003c3f 	tst	w1, #0xffff
    6628:	54ffe301 	b.ne	6288 <fwp_main_thread+0x13e4>  // b.any
    662c:	17ffff0e 	b	6264 <fwp_main_thread+0x13c0>
    6630:	72003c1f 	tst	w0, #0xffff
    6634:	54ffdd21 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    6638:	17ffff79 	b	641c <fwp_main_thread+0x1578>
    663c:	f90007e0 	str	x0, [sp, #8]
    6640:	97fff1d1 	bl	2d84 <fwp_rc_forget_slot>
    6644:	f94007e0 	ldr	x0, [sp, #8]
    6648:	9115c261 	add	x1, x19, #0x570
    664c:	12800022 	mov	w2, #0xfffffffe            	// #-2
    6650:	17fffd95 	b	5ca4 <fwp_main_thread+0xe00>
    6654:	d2800014 	mov	x20, #0x0                   	// #0
    6658:	17fffa9e 	b	50d0 <fwp_main_thread+0x22c>
    665c:	72003c3f 	tst	w1, #0xffff
    6660:	54ff7f21 	b.ne	5644 <fwp_main_thread+0x7a0>  // b.any
    6664:	17fffbf3 	b	5630 <fwp_main_thread+0x78c>
    6668:	72003c3f 	tst	w1, #0xffff
    666c:	54ff7a41 	b.ne	55b4 <fwp_main_thread+0x710>  // b.any
    6670:	17fffbcc 	b	55a0 <fwp_main_thread+0x6fc>
    6674:	72003c3f 	tst	w1, #0xffff
    6678:	54ff8321 	b.ne	56dc <fwp_main_thread+0x838>  // b.any
    667c:	17fffc13 	b	56c8 <fwp_main_thread+0x824>
    6680:	aa0003e1 	mov	x1, x0
    6684:	f90022b4 	str	x20, [x21, #64]
    6688:	17fffa6b 	b	5034 <fwp_main_thread+0x190>
    668c:	f94152a0 	ldr	x0, [x21, #672]
    6690:	97fff25c 	bl	3000 <fwp_mem_free>
    6694:	f90152bf 	str	xzr, [x21, #672]
    6698:	f9015abf 	str	xzr, [x21, #688]
    669c:	f94172a0 	ldr	x0, [x21, #736]
    66a0:	b4000b34 	cbz	x20, 6804 <fwp_main_thread+0x1960>
    66a4:	f900569f 	str	xzr, [x20, #168]
    66a8:	f9005e9f 	str	xzr, [x20, #184]
    66ac:	b902dabf 	str	wzr, [x21, #728]
    66b0:	eb00029f 	cmp	x20, x0
    66b4:	54ff5240 	b.eq	50fc <fwp_main_thread+0x258>  // b.none
    66b8:	6d1c27e8 	stp	d8, d9, [sp, #448]
    66bc:	6d1d2fea 	stp	d10, d11, [sp, #464]
    66c0:	6d1e37ec 	stp	d12, d13, [sp, #480]
    66c4:	6d1f3fee 	stp	d14, d15, [sp, #496]
    66c8:	97ffeba2 	bl	1550 <abort@plt>
    66cc:	ca5646c0 	eor	x0, x22, x22, lsr #17
    66d0:	9115c261 	add	x1, x19, #0x570
    66d4:	ca402400 	eor	x0, x0, x0, lsr #9
    66d8:	8b200c20 	add	x0, x1, w0, uxtb #3
    66dc:	f94a2400 	ldr	x0, [x0, #5192]
    66e0:	b5000080 	cbnz	x0, 66f0 <fwp_main_thread+0x184c>
    66e4:	14000045 	b	67f8 <fwp_main_thread+0x1954>
    66e8:	f9400800 	ldr	x0, [x0, #16]
    66ec:	b4000860 	cbz	x0, 67f8 <fwp_main_thread+0x1954>
    66f0:	f9400001 	ldr	x1, [x0]
    66f4:	eb16003f 	cmp	x1, x22
    66f8:	54ffff81 	b.ne	66e8 <fwp_main_thread+0x1844>  // b.any
    66fc:	f9400401 	ldr	x1, [x0, #8]
    6700:	d1000421 	sub	x1, x1, #0x1
    6704:	f9000401 	str	x1, [x0, #8]
    6708:	f103f83f 	cmp	x1, #0xfe
    670c:	54ffd661 	b.ne	61d8 <fwp_main_thread+0x1334>  // b.any
    6710:	aa1603e0 	mov	x0, x22
    6714:	97fff19c 	bl	2d84 <fwp_rc_forget_slot>
    6718:	12800020 	mov	w0, #0xfffffffe            	// #-2
    671c:	390002c0 	strb	w0, [x22]
    6720:	17fffeae 	b	61d8 <fwp_main_thread+0x1334>
    6724:	ca544681 	eor	x1, x20, x20, lsr #17
    6728:	9115c262 	add	x2, x19, #0x570
    672c:	ca412421 	eor	x1, x1, x1, lsr #9
    6730:	92401c21 	and	x1, x1, #0xff
    6734:	910a2423 	add	x3, x1, #0x289
    6738:	8b010c41 	add	x1, x2, x1, lsl #3
    673c:	8b030c55 	add	x21, x2, x3, lsl #3
    6740:	f94a2421 	ldr	x1, [x1, #5192]
    6744:	b50000a1 	cbnz	x1, 6758 <fwp_main_thread+0x18b4>
    6748:	14000057 	b	68a4 <fwp_main_thread+0x1a00>
    674c:	91004035 	add	x21, x1, #0x10
    6750:	f9400821 	ldr	x1, [x1, #16]
    6754:	b40004e1 	cbz	x1, 67f0 <fwp_main_thread+0x194c>
    6758:	f9400022 	ldr	x2, [x1]
    675c:	eb02029f 	cmp	x20, x2
    6760:	54ffff61 	b.ne	674c <fwp_main_thread+0x18a8>  // b.any
    6764:	f94002a1 	ldr	x1, [x21]
    6768:	7103f81f 	cmp	w0, #0xfe
    676c:	54000800 	b.eq	686c <fwp_main_thread+0x19c8>  // b.none
    6770:	b4000441 	cbz	x1, 67f8 <fwp_main_thread+0x1954>
    6774:	f9400420 	ldr	x0, [x1, #8]
    6778:	b100041f 	cmn	x0, #0x1
    677c:	540008c0 	b.eq	6894 <fwp_main_thread+0x19f0>  // b.none
    6780:	91000400 	add	x0, x0, #0x1
    6784:	f9000420 	str	x0, [x1, #8]
    6788:	17fffc03 	b	5794 <fwp_main_thread+0x8f0>
    678c:	ca5546a0 	eor	x0, x21, x21, lsr #17
    6790:	9115c261 	add	x1, x19, #0x570
    6794:	ca402400 	eor	x0, x0, x0, lsr #9
    6798:	8b200c20 	add	x0, x1, w0, uxtb #3
    679c:	f94a2400 	ldr	x0, [x0, #5192]
    67a0:	b5000080 	cbnz	x0, 67b0 <fwp_main_thread+0x190c>
    67a4:	14000015 	b	67f8 <fwp_main_thread+0x1954>
    67a8:	f9400800 	ldr	x0, [x0, #16]
    67ac:	b4000260 	cbz	x0, 67f8 <fwp_main_thread+0x1954>
    67b0:	f9400001 	ldr	x1, [x0]
    67b4:	eb15003f 	cmp	x1, x21
    67b8:	54ffff81 	b.ne	67a8 <fwp_main_thread+0x1904>  // b.any
    67bc:	f9400401 	ldr	x1, [x0, #8]
    67c0:	d1000421 	sub	x1, x1, #0x1
    67c4:	f9000401 	str	x1, [x0, #8]
    67c8:	f103f83f 	cmp	x1, #0xfe
    67cc:	54ffd5e1 	b.ne	6288 <fwp_main_thread+0x13e4>  // b.any
    67d0:	aa1503e0 	mov	x0, x21
    67d4:	97fff16c 	bl	2d84 <fwp_rc_forget_slot>
    67d8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67dc:	390002a0 	strb	w0, [x21]
    67e0:	17fffeaa 	b	6288 <fwp_main_thread+0x13e4>
    67e4:	b0000000 	adrp	x0, 7000 <atexit>
    67e8:	9112c000 	add	x0, x0, #0x4b0
    67ec:	97ffeea5 	bl	2280 <fwp_trap>
    67f0:	7103f81f 	cmp	w0, #0xfe
    67f4:	54000200 	b.eq	6834 <fwp_main_thread+0x1990>  // b.none
    67f8:	b0000000 	adrp	x0, 7000 <atexit>
    67fc:	910ba000 	add	x0, x0, #0x2e8
    6800:	97ffeea0 	bl	2280 <fwp_trap>
    6804:	b902dabf 	str	wzr, [x21, #728]
    6808:	b4ff4c40 	cbz	x0, 5190 <fwp_main_thread+0x2ec>
    680c:	17ffffab 	b	66b8 <fwp_main_thread+0x1814>
    6810:	aa1503e0 	mov	x0, x21
    6814:	97fff15c 	bl	2d84 <fwp_rc_forget_slot>
    6818:	17fffb65 	b	55ac <fwp_main_thread+0x708>
    681c:	aa1503e0 	mov	x0, x21
    6820:	97fff159 	bl	2d84 <fwp_rc_forget_slot>
    6824:	17fffb86 	b	563c <fwp_main_thread+0x798>
    6828:	aa1403e0 	mov	x0, x20
    682c:	97fff156 	bl	2d84 <fwp_rc_forget_slot>
    6830:	17fffba9 	b	56d4 <fwp_main_thread+0x830>
    6834:	d2800300 	mov	x0, #0x18                  	// #24
    6838:	97ffeb1a 	bl	14a0 <malloc@plt>
    683c:	b4000320 	cbz	x0, 68a0 <fwp_main_thread+0x19fc>
    6840:	d2801fe1 	mov	x1, #0xff                  	// #255
    6844:	a9000414 	stp	x20, x1, [x0]
    6848:	9115c261 	add	x1, x19, #0x570
    684c:	f900081f 	str	xzr, [x0, #16]
    6850:	12800002 	mov	w2, #0xffffffff            	// #-1
    6854:	f90002a0 	str	x0, [x21]
    6858:	39000282 	strb	w2, [x20]
    685c:	f94e2420 	ldr	x0, [x1, #7240]
    6860:	91000400 	add	x0, x0, #0x1
    6864:	f90e2420 	str	x0, [x1, #7240]
    6868:	17fffbcb 	b	5794 <fwp_main_thread+0x8f0>
    686c:	b4fffe41 	cbz	x1, 6834 <fwp_main_thread+0x1990>
    6870:	b0000000 	adrp	x0, 7000 <atexit>
    6874:	9111a000 	add	x0, x0, #0x468
    6878:	97ffee82 	bl	2280 <fwp_trap>
    687c:	b0000000 	adrp	x0, 7000 <atexit>
    6880:	910c4000 	add	x0, x0, #0x310
    6884:	97ffee7f 	bl	2280 <fwp_trap>
    6888:	b0000000 	adrp	x0, 7000 <atexit>
    688c:	91136000 	add	x0, x0, #0x4d8
    6890:	97ffee7c 	bl	2280 <fwp_trap>
    6894:	b0000000 	adrp	x0, 7000 <atexit>
    6898:	91124000 	add	x0, x0, #0x490
    689c:	97ffee79 	bl	2280 <fwp_trap>
    68a0:	97ffed0c 	bl	1cd0 <fwp_heap_oom>
    68a4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    68a8:	17ffffb0 	b	6768 <fwp_main_thread+0x18c4>
    68ac:	b0000000 	adrp	x0, 7000 <atexit>
    68b0:	91108000 	add	x0, x0, #0x420
    68b4:	a91a6bf9 	stp	x25, x26, [sp, #416]
    68b8:	a91b73fb 	stp	x27, x28, [sp, #432]
    68bc:	6d1c27e8 	stp	d8, d9, [sp, #448]
    68c0:	6d1d2fea 	stp	d10, d11, [sp, #464]
    68c4:	6d1e37ec 	stp	d12, d13, [sp, #480]
    68c8:	6d1f3fee 	stp	d14, d15, [sp, #496]
    68cc:	97ffee6d 	bl	2280 <fwp_trap>
    68d0:	6d1c27e8 	stp	d8, d9, [sp, #448]
    68d4:	6d1d2fea 	stp	d10, d11, [sp, #464]
    68d8:	6d1e37ec 	stp	d12, d13, [sp, #480]
    68dc:	6d1f3fee 	stp	d14, d15, [sp, #496]
    68e0:	97ffeb08 	bl	1500 <__stack_chk_fail@plt>
    68e4:	b0000000 	adrp	x0, 7000 <atexit>
    68e8:	91112000 	add	x0, x0, #0x448
    68ec:	6d1c27e8 	stp	d8, d9, [sp, #448]
    68f0:	6d1d2fea 	stp	d10, d11, [sp, #464]
    68f4:	6d1e37ec 	stp	d12, d13, [sp, #480]
    68f8:	6d1f3fee 	stp	d14, d15, [sp, #496]
    68fc:	97ffed79 	bl	1ee0 <ad_raw_fail>
    6900:	97ffeb80 	bl	1700 <fwp_trap_overflow.constprop.0>
    6904:	d503201f 	nop
    6908:	d503201f 	nop
    690c:	d503201f 	nop

0000000000006910 <__divti3>:
    6910:	d503245f 	bti	c
    6914:	d2800004 	mov	x4, #0x0                   	// #0
    6918:	b7f80721 	tbnz	x1, #63, 69fc <__divti3+0xec>
    691c:	b6f80083 	tbz	x3, #63, 692c <__divti3+0x1c>
    6920:	eb0203e2 	negs	x2, x2
    6924:	aa2403e4 	mvn	x4, x4
    6928:	da0303e3 	ngc	x3, x3
    692c:	aa0203e6 	mov	x6, x2
    6930:	aa0003e7 	mov	x7, x0
    6934:	aa0103e5 	mov	x5, x1
    6938:	b5000583 	cbnz	x3, 69e8 <__divti3+0xd8>
    693c:	eb01005f 	cmp	x2, x1
    6940:	54000e69 	b.ls	6b0c <__divti3+0x1fc>  // b.plast
    6944:	dac01040 	clz	x0, x2
    6948:	b40000e0 	cbz	x0, 6964 <__divti3+0x54>
    694c:	4b0003e1 	neg	w1, w0
    6950:	9ac020a5 	lsl	x5, x5, x0
    6954:	9ac02046 	lsl	x6, x2, x0
    6958:	9ac124e1 	lsr	x1, x7, x1
    695c:	aa050025 	orr	x5, x1, x5
    6960:	9ac020e7 	lsl	x7, x7, x0
    6964:	d360fcc8 	lsr	x8, x6, #32
    6968:	92407cc2 	and	x2, x6, #0xffffffff
    696c:	9ac808a3 	udiv	x3, x5, x8
    6970:	9b089465 	msub	x5, x3, x8, x5
    6974:	aa0303e0 	mov	x0, x3
    6978:	9b037c41 	mul	x1, x2, x3
    697c:	93c780a5 	extr	x5, x5, x7, #32
    6980:	eb05003f 	cmp	x1, x5
    6984:	540000a9 	b.ls	6998 <__divti3+0x88>  // b.plast
    6988:	ab0500c5 	adds	x5, x6, x5
    698c:	d1000460 	sub	x0, x3, #0x1
    6990:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    6994:	540015a8 	b.hi	6c48 <__divti3+0x338>  // b.pmore
    6998:	cb0100a5 	sub	x5, x5, x1
    699c:	9ac808a3 	udiv	x3, x5, x8
    69a0:	9b089465 	msub	x5, x3, x8, x5
    69a4:	aa0303e1 	mov	x1, x3
    69a8:	9b037c42 	mul	x2, x2, x3
    69ac:	aa0703e3 	mov	x3, x7
    69b0:	b3607ca3 	bfi	x3, x5, #32, #32
    69b4:	eb03005f 	cmp	x2, x3
    69b8:	540000c9 	b.ls	69d0 <__divti3+0xc0>  // b.plast
    69bc:	ab0300c3 	adds	x3, x6, x3
    69c0:	d1000425 	sub	x5, x1, #0x1
    69c4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    69c8:	d1000821 	sub	x1, x1, #0x2
    69cc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    69d0:	aa008020 	orr	x0, x1, x0, lsl #32
    69d4:	d2800001 	mov	x1, #0x0                   	// #0
    69d8:	b4000064 	cbz	x4, 69e4 <__divti3+0xd4>
    69dc:	eb0003e0 	negs	x0, x0
    69e0:	da0103e1 	ngc	x1, x1
    69e4:	d65f03c0 	ret
    69e8:	eb01007f 	cmp	x3, x1
    69ec:	54000109 	b.ls	6a0c <__divti3+0xfc>  // b.plast
    69f0:	d2800001 	mov	x1, #0x0                   	// #0
    69f4:	d2800000 	mov	x0, #0x0                   	// #0
    69f8:	17fffff8 	b	69d8 <__divti3+0xc8>
    69fc:	eb0003e0 	negs	x0, x0
    6a00:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6a04:	da0103e1 	ngc	x1, x1
    6a08:	17ffffc5 	b	691c <__divti3+0xc>
    6a0c:	dac01067 	clz	x7, x3
    6a10:	b40010e7 	cbz	x7, 6c2c <__divti3+0x31c>
    6a14:	d2800805 	mov	x5, #0x40                  	// #64
    6a18:	cb0700a5 	sub	x5, x5, x7
    6a1c:	9ac72063 	lsl	x3, x3, x7
    6a20:	9ac52448 	lsr	x8, x2, x5
    6a24:	aa030108 	orr	x8, x8, x3
    6a28:	9ac52426 	lsr	x6, x1, x5
    6a2c:	92407d0a 	and	x10, x8, #0xffffffff
    6a30:	d360fd09 	lsr	x9, x8, #32
    6a34:	9ac52403 	lsr	x3, x0, x5
    6a38:	9ac72021 	lsl	x1, x1, x7
    6a3c:	aa010063 	orr	x3, x3, x1
    6a40:	9ac72042 	lsl	x2, x2, x7
    6a44:	9ac908cb 	udiv	x11, x6, x9
    6a48:	9b099965 	msub	x5, x11, x9, x6
    6a4c:	aa0b03e1 	mov	x1, x11
    6a50:	9b0b7d46 	mul	x6, x10, x11
    6a54:	93c380a5 	extr	x5, x5, x3, #32
    6a58:	eb0500df 	cmp	x6, x5
    6a5c:	540000a9 	b.ls	6a70 <__divti3+0x160>  // b.plast
    6a60:	ab050105 	adds	x5, x8, x5
    6a64:	d1000561 	sub	x1, x11, #0x1
    6a68:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    6a6c:	54000f48 	b.hi	6c54 <__divti3+0x344>  // b.pmore
    6a70:	cb0600a6 	sub	x6, x5, x6
    6a74:	9ac908cb 	udiv	x11, x6, x9
    6a78:	9b099969 	msub	x9, x11, x9, x6
    6a7c:	aa0b03e5 	mov	x5, x11
    6a80:	9b0b7d4a 	mul	x10, x10, x11
    6a84:	b3607d23 	bfi	x3, x9, #32, #32
    6a88:	eb03015f 	cmp	x10, x3
    6a8c:	540000a9 	b.ls	6aa0 <__divti3+0x190>  // b.plast
    6a90:	ab030103 	adds	x3, x8, x3
    6a94:	d1000565 	sub	x5, x11, #0x1
    6a98:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    6a9c:	54000e28 	b.hi	6c60 <__divti3+0x350>  // b.pmore
    6aa0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    6aa4:	92407c48 	and	x8, x2, #0xffffffff
    6aa8:	2a0503e5 	mov	w5, w5
    6aac:	d360fc42 	lsr	x2, x2, #32
    6ab0:	d360fc26 	lsr	x6, x1, #32
    6ab4:	cb0a0063 	sub	x3, x3, x10
    6ab8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    6abc:	9b087caa 	mul	x10, x5, x8
    6ac0:	9b087cc8 	mul	x8, x6, x8
    6ac4:	9b0220a5 	madd	x5, x5, x2, x8
    6ac8:	9b027cc6 	mul	x6, x6, x2
    6acc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    6ad0:	8b0900c5 	add	x5, x6, x9
    6ad4:	eb02011f 	cmp	x8, x2
    6ad8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    6adc:	8b4280c6 	add	x6, x6, x2, lsr #32
    6ae0:	eb06007f 	cmp	x3, x6
    6ae4:	540000e3 	b.cc	6b00 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    6ae8:	92407d4a 	and	x10, x10, #0xffffffff
    6aec:	9ac72000 	lsl	x0, x0, x7
    6af0:	8b028142 	add	x2, x10, x2, lsl #32
    6af4:	eb02001f 	cmp	x0, x2
    6af8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    6afc:	54000a01 	b.ne	6c3c <__divti3+0x32c>  // b.any
    6b00:	d1000420 	sub	x0, x1, #0x1
    6b04:	d2800001 	mov	x1, #0x0                   	// #0
    6b08:	17ffffb4 	b	69d8 <__divti3+0xc8>
    6b0c:	b5000062 	cbnz	x2, 6b18 <__divti3+0x208>
    6b10:	d2800022 	mov	x2, #0x1                   	// #1
    6b14:	9ac30846 	udiv	x6, x2, x3
    6b18:	dac010c8 	clz	x8, x6
    6b1c:	b5000408 	cbnz	x8, 6b9c <__divti3+0x28c>
    6b20:	d360fcc9 	lsr	x9, x6, #32
    6b24:	92407cc5 	and	x5, x6, #0xffffffff
    6b28:	cb060023 	sub	x3, x1, x6
    6b2c:	d2800021 	mov	x1, #0x1                   	// #1
    6b30:	9ac90868 	udiv	x8, x3, x9
    6b34:	9b098d03 	msub	x3, x8, x9, x3
    6b38:	aa0803e0 	mov	x0, x8
    6b3c:	9b057d02 	mul	x2, x8, x5
    6b40:	93c78063 	extr	x3, x3, x7, #32
    6b44:	eb03005f 	cmp	x2, x3
    6b48:	540000a9 	b.ls	6b5c <__divti3+0x24c>  // b.plast
    6b4c:	ab0300c3 	adds	x3, x6, x3
    6b50:	d1000500 	sub	x0, x8, #0x1
    6b54:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6b58:	54000968 	b.hi	6c84 <__divti3+0x374>  // b.pmore
    6b5c:	cb020063 	sub	x3, x3, x2
    6b60:	9ac90862 	udiv	x2, x3, x9
    6b64:	aa0203e8 	mov	x8, x2
    6b68:	9b098c42 	msub	x2, x2, x9, x3
    6b6c:	aa0703e3 	mov	x3, x7
    6b70:	9b057d05 	mul	x5, x8, x5
    6b74:	b3607c43 	bfi	x3, x2, #32, #32
    6b78:	eb0300bf 	cmp	x5, x3
    6b7c:	540000c9 	b.ls	6b94 <__divti3+0x284>  // b.plast
    6b80:	ab0300c2 	adds	x2, x6, x3
    6b84:	d1000503 	sub	x3, x8, #0x1
    6b88:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    6b8c:	d1000908 	sub	x8, x8, #0x2
    6b90:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    6b94:	aa008100 	orr	x0, x8, x0, lsl #32
    6b98:	17ffff90 	b	69d8 <__divti3+0xc8>
    6b9c:	9ac820c6 	lsl	x6, x6, x8
    6ba0:	d2800803 	mov	x3, #0x40                  	// #64
    6ba4:	cb080063 	sub	x3, x3, x8
    6ba8:	d360fcc9 	lsr	x9, x6, #32
    6bac:	9ac82027 	lsl	x7, x1, x8
    6bb0:	92407cc5 	and	x5, x6, #0xffffffff
    6bb4:	9ac32422 	lsr	x2, x1, x3
    6bb8:	9ac32403 	lsr	x3, x0, x3
    6bbc:	aa070063 	orr	x3, x3, x7
    6bc0:	9ac9084a 	udiv	x10, x2, x9
    6bc4:	9ac82007 	lsl	x7, x0, x8
    6bc8:	9b098940 	msub	x0, x10, x9, x2
    6bcc:	aa0a03e1 	mov	x1, x10
    6bd0:	9b0a7ca2 	mul	x2, x5, x10
    6bd4:	93c38000 	extr	x0, x0, x3, #32
    6bd8:	eb00005f 	cmp	x2, x0
    6bdc:	540000a9 	b.ls	6bf0 <__divti3+0x2e0>  // b.plast
    6be0:	ab0000c0 	adds	x0, x6, x0
    6be4:	d1000541 	sub	x1, x10, #0x1
    6be8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    6bec:	54000468 	b.hi	6c78 <__divti3+0x368>  // b.pmore
    6bf0:	cb020000 	sub	x0, x0, x2
    6bf4:	9ac9080a 	udiv	x10, x0, x9
    6bf8:	9b098140 	msub	x0, x10, x9, x0
    6bfc:	aa0a03e2 	mov	x2, x10
    6c00:	9b0a7ca8 	mul	x8, x5, x10
    6c04:	b3607c03 	bfi	x3, x0, #32, #32
    6c08:	eb03011f 	cmp	x8, x3
    6c0c:	540000a9 	b.ls	6c20 <__divti3+0x310>  // b.plast
    6c10:	ab0300c3 	adds	x3, x6, x3
    6c14:	d1000542 	sub	x2, x10, #0x1
    6c18:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    6c1c:	54000288 	b.hi	6c6c <__divti3+0x35c>  // b.pmore
    6c20:	cb080063 	sub	x3, x3, x8
    6c24:	aa018041 	orr	x1, x2, x1, lsl #32
    6c28:	17ffffc2 	b	6b30 <__divti3+0x220>
    6c2c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6c30:	d2800001 	mov	x1, #0x0                   	// #0
    6c34:	9a9f87e0 	cset	x0, ls	// ls = plast
    6c38:	17ffff68 	b	69d8 <__divti3+0xc8>
    6c3c:	aa0103e0 	mov	x0, x1
    6c40:	d2800001 	mov	x1, #0x0                   	// #0
    6c44:	17ffff65 	b	69d8 <__divti3+0xc8>
    6c48:	d1000860 	sub	x0, x3, #0x2
    6c4c:	8b0600a5 	add	x5, x5, x6
    6c50:	17ffff52 	b	6998 <__divti3+0x88>
    6c54:	d1000961 	sub	x1, x11, #0x2
    6c58:	8b0800a5 	add	x5, x5, x8
    6c5c:	17ffff85 	b	6a70 <__divti3+0x160>
    6c60:	d1000965 	sub	x5, x11, #0x2
    6c64:	8b080063 	add	x3, x3, x8
    6c68:	17ffff8e 	b	6aa0 <__divti3+0x190>
    6c6c:	d1000942 	sub	x2, x10, #0x2
    6c70:	8b060063 	add	x3, x3, x6
    6c74:	17ffffeb 	b	6c20 <__divti3+0x310>
    6c78:	d1000941 	sub	x1, x10, #0x2
    6c7c:	8b060000 	add	x0, x0, x6
    6c80:	17ffffdc 	b	6bf0 <__divti3+0x2e0>
    6c84:	d1000900 	sub	x0, x8, #0x2
    6c88:	8b060063 	add	x3, x3, x6
    6c8c:	17ffffb4 	b	6b5c <__divti3+0x24c>

0000000000006c90 <__modti3>:
    6c90:	d503245f 	bti	c
    6c94:	d2800004 	mov	x4, #0x0                   	// #0
    6c98:	b6f80081 	tbz	x1, #63, 6ca8 <__modti3+0x18>
    6c9c:	eb0003e0 	negs	x0, x0
    6ca0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6ca4:	da0103e1 	ngc	x1, x1
    6ca8:	f100007f 	cmp	x3, #0x0
    6cac:	5400128b 	b.lt	6efc <__modti3+0x26c>  // b.tstop
    6cb0:	aa0003e7 	mov	x7, x0
    6cb4:	aa0103e6 	mov	x6, x1
    6cb8:	540004e1 	b.ne	6d54 <__modti3+0xc4>  // b.any
    6cbc:	eb02003f 	cmp	x1, x2
    6cc0:	54000dc2 	b.cs	6e78 <__modti3+0x1e8>  // b.hs, b.nlast
    6cc4:	dac01043 	clz	x3, x2
    6cc8:	aa0303e5 	mov	x5, x3
    6ccc:	b40000e3 	cbz	x3, 6ce8 <__modti3+0x58>
    6cd0:	4b0303e6 	neg	w6, w3
    6cd4:	9ac32021 	lsl	x1, x1, x3
    6cd8:	9ac32042 	lsl	x2, x2, x3
    6cdc:	9ac62406 	lsr	x6, x0, x6
    6ce0:	aa0100c6 	orr	x6, x6, x1
    6ce4:	9ac32007 	lsl	x7, x0, x3
    6ce8:	d360fc40 	lsr	x0, x2, #32
    6cec:	92407c43 	and	x3, x2, #0xffffffff
    6cf0:	9ac008c1 	udiv	x1, x6, x0
    6cf4:	9b009826 	msub	x6, x1, x0, x6
    6cf8:	9b017c61 	mul	x1, x3, x1
    6cfc:	93c780c6 	extr	x6, x6, x7, #32
    6d00:	eb06003f 	cmp	x1, x6
    6d04:	540000a9 	b.ls	6d18 <__modti3+0x88>  // b.plast
    6d08:	ab060046 	adds	x6, x2, x6
    6d0c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    6d10:	8b0200c8 	add	x8, x6, x2
    6d14:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    6d18:	cb0100c6 	sub	x6, x6, x1
    6d1c:	9ac008c8 	udiv	x8, x6, x0
    6d20:	9b009901 	msub	x1, x8, x0, x6
    6d24:	aa0703e0 	mov	x0, x7
    6d28:	9b087c63 	mul	x3, x3, x8
    6d2c:	b3607c20 	bfi	x0, x1, #32, #32
    6d30:	eb00007f 	cmp	x3, x0
    6d34:	54001088 	b.hi	6f44 <__modti3+0x2b4>  // b.pmore
    6d38:	cb030000 	sub	x0, x0, x3
    6d3c:	9ac52400 	lsr	x0, x0, x5
    6d40:	d2800001 	mov	x1, #0x0                   	// #0
    6d44:	b4000064 	cbz	x4, 6d50 <__modti3+0xc0>
    6d48:	eb0003e0 	negs	x0, x0
    6d4c:	da0103e1 	ngc	x1, x1
    6d50:	d65f03c0 	ret
    6d54:	dac01066 	clz	x6, x3
    6d58:	eb03003f 	cmp	x1, x3
    6d5c:	54ffff43 	b.cc	6d44 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6d60:	93407cc5 	sxtw	x5, w6
    6d64:	d2800808 	mov	x8, #0x40                  	// #64
    6d68:	cb050108 	sub	x8, x8, x5
    6d6c:	9ac62063 	lsl	x3, x3, x6
    6d70:	9ac62025 	lsl	x5, x1, x6
    6d74:	9ac82447 	lsr	x7, x2, x8
    6d78:	aa0300e7 	orr	x7, x7, x3
    6d7c:	9ac82423 	lsr	x3, x1, x8
    6d80:	92407cec 	and	x12, x7, #0xffffffff
    6d84:	d360fcea 	lsr	x10, x7, #32
    6d88:	9ac82401 	lsr	x1, x0, x8
    6d8c:	aa050021 	orr	x1, x1, x5
    6d90:	9ac62042 	lsl	x2, x2, x6
    6d94:	9ac62000 	lsl	x0, x0, x6
    6d98:	9aca086b 	udiv	x11, x3, x10
    6d9c:	9b0a8d63 	msub	x3, x11, x10, x3
    6da0:	aa0b03e5 	mov	x5, x11
    6da4:	9b0b7d89 	mul	x9, x12, x11
    6da8:	93c18063 	extr	x3, x3, x1, #32
    6dac:	eb03013f 	cmp	x9, x3
    6db0:	540000a9 	b.ls	6dc4 <__modti3+0x134>  // b.plast
    6db4:	ab0300e3 	adds	x3, x7, x3
    6db8:	d1000565 	sub	x5, x11, #0x1
    6dbc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    6dc0:	54001168 	b.hi	6fec <__modti3+0x35c>  // b.pmore
    6dc4:	cb090063 	sub	x3, x3, x9
    6dc8:	9aca086b 	udiv	x11, x3, x10
    6dcc:	9b0a8d6a 	msub	x10, x11, x10, x3
    6dd0:	aa0b03e9 	mov	x9, x11
    6dd4:	9b0b7d8c 	mul	x12, x12, x11
    6dd8:	b3607d41 	bfi	x1, x10, #32, #32
    6ddc:	eb01019f 	cmp	x12, x1
    6de0:	540000a9 	b.ls	6df4 <__modti3+0x164>  // b.plast
    6de4:	ab0100e1 	adds	x1, x7, x1
    6de8:	d1000569 	sub	x9, x11, #0x1
    6dec:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    6df0:	54000f88 	b.hi	6fe0 <__modti3+0x350>  // b.pmore
    6df4:	aa058123 	orr	x3, x9, x5, lsl #32
    6df8:	92407c4b 	and	x11, x2, #0xffffffff
    6dfc:	2a0903e9 	mov	w9, w9
    6e00:	d360fc4a 	lsr	x10, x2, #32
    6e04:	d360fc63 	lsr	x3, x3, #32
    6e08:	cb0c0021 	sub	x1, x1, x12
    6e0c:	aa0a03ec 	mov	x12, x10
    6e10:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    6e14:	9b0b7d25 	mul	x5, x9, x11
    6e18:	9b0b7c6b 	mul	x11, x3, x11
    6e1c:	9b0a2d29 	madd	x9, x9, x10, x11
    6e20:	92407caa 	and	x10, x5, #0xffffffff
    6e24:	9b0c7c63 	mul	x3, x3, x12
    6e28:	8b458125 	add	x5, x9, x5, lsr #32
    6e2c:	8b0d0069 	add	x9, x3, x13
    6e30:	eb05017f 	cmp	x11, x5
    6e34:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    6e38:	8b058149 	add	x9, x10, x5, lsl #32
    6e3c:	8b458063 	add	x3, x3, x5, lsr #32
    6e40:	eb03003f 	cmp	x1, x3
    6e44:	54000063 	b.cc	6e50 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    6e48:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    6e4c:	54000082 	b.cs	6e5c <__modti3+0x1cc>  // b.hs, b.nlast
    6e50:	eb020129 	subs	x9, x9, x2
    6e54:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    6e58:	cb070063 	sub	x3, x3, x7
    6e5c:	eb090000 	subs	x0, x0, x9
    6e60:	da030021 	sbc	x1, x1, x3
    6e64:	9ac62400 	lsr	x0, x0, x6
    6e68:	9ac82028 	lsl	x8, x1, x8
    6e6c:	aa000100 	orr	x0, x8, x0
    6e70:	9ac62421 	lsr	x1, x1, x6
    6e74:	17ffffb4 	b	6d44 <__modti3+0xb4>
    6e78:	b5000062 	cbnz	x2, 6e84 <__modti3+0x1f4>
    6e7c:	d2800023 	mov	x3, #0x1                   	// #1
    6e80:	9ac20862 	udiv	x2, x3, x2
    6e84:	dac01048 	clz	x8, x2
    6e88:	aa0803e5 	mov	x5, x8
    6e8c:	b5000668 	cbnz	x8, 6f58 <__modti3+0x2c8>
    6e90:	cb020020 	sub	x0, x1, x2
    6e94:	d360fc49 	lsr	x9, x2, #32
    6e98:	92407c4a 	and	x10, x2, #0xffffffff
    6e9c:	9ac90801 	udiv	x1, x0, x9
    6ea0:	9b098020 	msub	x0, x1, x9, x0
    6ea4:	9b0a7c21 	mul	x1, x1, x10
    6ea8:	93c78000 	extr	x0, x0, x7, #32
    6eac:	eb00003f 	cmp	x1, x0
    6eb0:	540000a9 	b.ls	6ec4 <__modti3+0x234>  // b.plast
    6eb4:	ab000040 	adds	x0, x2, x0
    6eb8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6ebc:	8b020003 	add	x3, x0, x2
    6ec0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    6ec4:	cb010001 	sub	x1, x0, x1
    6ec8:	9ac90820 	udiv	x0, x1, x9
    6ecc:	9b098403 	msub	x3, x0, x9, x1
    6ed0:	aa0703e1 	mov	x1, x7
    6ed4:	9b0a7c00 	mul	x0, x0, x10
    6ed8:	b3607c61 	bfi	x1, x3, #32, #32
    6edc:	eb01001f 	cmp	x0, x1
    6ee0:	540000a9 	b.ls	6ef4 <__modti3+0x264>  // b.plast
    6ee4:	ab010041 	adds	x1, x2, x1
    6ee8:	8b020022 	add	x2, x1, x2
    6eec:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    6ef0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    6ef4:	cb000020 	sub	x0, x1, x0
    6ef8:	17ffff91 	b	6d3c <__modti3+0xac>
    6efc:	eb0203e5 	negs	x5, x2
    6f00:	aa0003e7 	mov	x7, x0
    6f04:	da0303e8 	ngc	x8, x3
    6f08:	aa0503e2 	mov	x2, x5
    6f0c:	aa0803e3 	mov	x3, x8
    6f10:	aa0103e6 	mov	x6, x1
    6f14:	b4ffed48 	cbz	x8, 6cbc <__modti3+0x2c>
    6f18:	eb01011f 	cmp	x8, x1
    6f1c:	54fff148 	b.hi	6d44 <__modti3+0xb4>  // b.pmore
    6f20:	dac01109 	clz	x9, x8
    6f24:	2a0903e6 	mov	w6, w9
    6f28:	b5fff1c9 	cbnz	x9, 6d60 <__modti3+0xd0>
    6f2c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    6f30:	54000068 	b.hi	6f3c <__modti3+0x2ac>  // b.pmore
    6f34:	eb050007 	subs	x7, x0, x5
    6f38:	da080021 	sbc	x1, x1, x8
    6f3c:	aa0703e0 	mov	x0, x7
    6f40:	17ffff81 	b	6d44 <__modti3+0xb4>
    6f44:	ab000040 	adds	x0, x2, x0
    6f48:	8b020002 	add	x2, x0, x2
    6f4c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    6f50:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    6f54:	17ffff79 	b	6d38 <__modti3+0xa8>
    6f58:	9ac82042 	lsl	x2, x2, x8
    6f5c:	d2800803 	mov	x3, #0x40                  	// #64
    6f60:	cb080063 	sub	x3, x3, x8
    6f64:	d360fc49 	lsr	x9, x2, #32
    6f68:	9ac82027 	lsl	x7, x1, x8
    6f6c:	92407c4a 	and	x10, x2, #0xffffffff
    6f70:	9ac32426 	lsr	x6, x1, x3
    6f74:	9ac32403 	lsr	x3, x0, x3
    6f78:	aa070063 	orr	x3, x3, x7
    6f7c:	9ac908c1 	udiv	x1, x6, x9
    6f80:	9ac82007 	lsl	x7, x0, x8
    6f84:	9b099820 	msub	x0, x1, x9, x6
    6f88:	9b017d41 	mul	x1, x10, x1
    6f8c:	93c38000 	extr	x0, x0, x3, #32
    6f90:	eb00003f 	cmp	x1, x0
    6f94:	540000a9 	b.ls	6fa8 <__modti3+0x318>  // b.plast
    6f98:	ab000040 	adds	x0, x2, x0
    6f9c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6fa0:	8b020006 	add	x6, x0, x2
    6fa4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    6fa8:	cb010000 	sub	x0, x0, x1
    6fac:	9ac90801 	udiv	x1, x0, x9
    6fb0:	9b098026 	msub	x6, x1, x9, x0
    6fb4:	aa0303e0 	mov	x0, x3
    6fb8:	9b017d41 	mul	x1, x10, x1
    6fbc:	b3607cc0 	bfi	x0, x6, #32, #32
    6fc0:	eb00003f 	cmp	x1, x0
    6fc4:	540000a9 	b.ls	6fd8 <__modti3+0x348>  // b.plast
    6fc8:	ab000040 	adds	x0, x2, x0
    6fcc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6fd0:	8b020003 	add	x3, x0, x2
    6fd4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    6fd8:	cb010000 	sub	x0, x0, x1
    6fdc:	17ffffb0 	b	6e9c <__modti3+0x20c>
    6fe0:	d1000969 	sub	x9, x11, #0x2
    6fe4:	8b070021 	add	x1, x1, x7
    6fe8:	17ffff83 	b	6df4 <__modti3+0x164>
    6fec:	d1000965 	sub	x5, x11, #0x2
    6ff0:	8b070063 	add	x3, x3, x7
    6ff4:	17ffff74 	b	6dc4 <__modti3+0x134>
    6ff8:	d503201f 	nop
    6ffc:	d503201f 	nop

0000000000007000 <atexit>:
    7000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7004:	b00000c2 	adrp	x2, 20000 <__data_start>
    7008:	d2800001 	mov	x1, #0x0                   	// #0
    700c:	910003fd 	mov	x29, sp
    7010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7014:	f9400442 	ldr	x2, [x2, #8]
    7018:	17ffe8fa 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000701c <_fini>:
    701c:	d503201f 	nop
    7020:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7024:	910003fd 	mov	x29, sp
    7028:	a8c17bfd 	ldp	x29, x30, [sp], #16
    702c:	d65f03c0 	ret
