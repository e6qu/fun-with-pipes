
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-local:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 8f 00 00 	mov    0x8fd9(%rip),%rax        # afe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 8e 00 00    	push   0x8e02(%rip)        # ae28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 8e 00 00    	jmp    *0x8e04(%rip)        # ae30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e 8c 00 00    	jmp    *0x8c7e(%rip)        # aff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae 8a 00 00    	jmp    *0x8aae(%rip)        # ae38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 8a 00 00    	jmp    *0x8aa6(%rip)        # ae40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e 8a 00 00    	jmp    *0x8a9e(%rip)        # ae48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 8a 00 00    	jmp    *0x8a96(%rip)        # ae50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e 8a 00 00    	jmp    *0x8a8e(%rip)        # ae58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 8a 00 00    	jmp    *0x8a86(%rip)        # ae60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e 8a 00 00    	jmp    *0x8a7e(%rip)        # ae68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 8a 00 00    	jmp    *0x8a76(%rip)        # ae70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e 8a 00 00    	jmp    *0x8a6e(%rip)        # ae78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 8a 00 00    	jmp    *0x8a66(%rip)        # ae80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e 8a 00 00    	jmp    *0x8a5e(%rip)        # ae88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 8a 00 00    	jmp    *0x8a56(%rip)        # ae90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e 8a 00 00    	jmp    *0x8a4e(%rip)        # ae98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 8a 00 00    	jmp    *0x8a46(%rip)        # aea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e 8a 00 00    	jmp    *0x8a3e(%rip)        # aea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 8a 00 00    	jmp    *0x8a36(%rip)        # aeb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e 8a 00 00    	jmp    *0x8a2e(%rip)        # aeb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 8a 00 00    	jmp    *0x8a26(%rip)        # aec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e 8a 00 00    	jmp    *0x8a1e(%rip)        # aec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 8a 00 00    	jmp    *0x8a16(%rip)        # aed0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e 8a 00 00    	jmp    *0x8a0e(%rip)        # aed8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 8a 00 00    	jmp    *0x8a06(%rip)        # aee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe 89 00 00    	jmp    *0x89fe(%rip)        # aee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 89 00 00    	jmp    *0x89f6(%rip)        # aef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee 89 00 00    	jmp    *0x89ee(%rip)        # aef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 89 00 00    	jmp    *0x89e6(%rip)        # af00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de 89 00 00    	jmp    *0x89de(%rip)        # af08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 89 00 00    	jmp    *0x89d6(%rip)        # af10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce 89 00 00    	jmp    *0x89ce(%rip)        # af18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 89 00 00    	jmp    *0x89c6(%rip)        # af20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be 89 00 00    	jmp    *0x89be(%rip)        # af28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 89 00 00    	jmp    *0x89b6(%rip)        # af30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae 89 00 00    	jmp    *0x89ae(%rip)        # af38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 89 00 00    	jmp    *0x89a6(%rip)        # af40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e 89 00 00    	jmp    *0x899e(%rip)        # af48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 89 00 00    	jmp    *0x8996(%rip)        # af50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e 89 00 00    	jmp    *0x898e(%rip)        # af58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 89 00 00    	jmp    *0x8986(%rip)        # af60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e 89 00 00    	jmp    *0x897e(%rip)        # af68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 89 00 00    	jmp    *0x8976(%rip)        # af70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e 89 00 00    	jmp    *0x896e(%rip)        # af78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 89 00 00    	jmp    *0x8966(%rip)        # af80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e 89 00 00    	jmp    *0x895e(%rip)        # af88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 89 00 00    	jmp    *0x8956(%rip)        # af90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e 89 00 00    	jmp    *0x894e(%rip)        # af98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 89 00 00    	jmp    *0x8946(%rip)        # afa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e 89 00 00    	jmp    *0x893e(%rip)        # afa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 89 00 00    	jmp    *0x8936(%rip)        # afb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e 89 00 00    	jmp    *0x892e(%rip)        # afb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 89 00 00    	jmp    *0x8926(%rip)        # afc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e 89 00 00    	jmp    *0x891e(%rip)        # afc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 89 00 00    	jmp    *0x8916(%rip)        # afd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 69 00 00 	lea    0x69a0(%rip),%r9        # 9077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 69 00 00 	lea    0x699d(%rip),%r8        # 907b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 41 89 00 00 	mov    0x8941(%rip),%rax        # b080 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 52 ac 01 00 	mov    %rax,0x1ac52(%rip)        # 1d398 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 6a 00 00 	lea    0x6a1c(%rip),%rdi        # 916e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d c6 88 00 00 	mov    0x88c6(%rip),%rdi        # b080 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 3d 37 00 00 	lea    0x373d(%rip),%rdx        # 5f50 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d 31 88 00 00 	mov    0x8831(%rip),%rdi        # b080 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 86 88 01 00    	mov    0x18886(%rip),%eax        # 1b0e0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 68 00 00 	lea    0x68cc(%rip),%rdi        # 9177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 6a 00 00 	lea    0x6aec(%rip),%rdi        # 93a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d a6 6a 00 00 	lea    0x6aa6(%rip),%rdi        # 9380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 6a 00 00 	lea    0x6a6a(%rip),%rdi        # 9350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 6a 00 00 	lea    0x6a36(%rip),%rdi        # 9328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 86 00 00    	call   *0x86b3(%rip)        # afd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 31 87 00 00 	lea    0x8731(%rip),%rdi        # b068 <__TMC_END__>
    2937:	48 8d 05 2a 87 00 00 	lea    0x872a(%rip),%rax        # b068 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 86 00 00 	mov    0x8696(%rip),%rax        # afe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d 01 87 00 00 	lea    0x8701(%rip),%rdi        # b068 <__TMC_END__>
    2967:	48 8d 35 fa 86 00 00 	lea    0x86fa(%rip),%rsi        # b068 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 86 00 00 	mov    0x8665(%rip),%rax        # aff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d fd 86 00 00 00 	cmpb   $0x0,0x86fd(%rip)        # b0a8 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 86 00 00 	cmpq   $0x0,0x8642(%rip)        # aff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 86 00 00 	mov    0x8646(%rip),%rdi        # b008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 d5 86 00 00 01 	movb   $0x1,0x86d5(%rip)        # b0a8 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d d1 a7 01 00 	mov    0x1a7d1(%rip),%rdi        # 1d398 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d a4 84 00 00 	mov    0x84a4(%rip),%rdi        # b080 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 91 84 00 00 	mov    0x8491(%rip),%rdi        # b080 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 63 00 00 	lea    0x63f5(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 82 84 00 00 	mov    0x8482(%rip),%rcx        # b0a0 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 d1 8a 01 00 	mov    0x18ad1(%rip),%rax        # 1b720 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 21 84 01 00 	mov    0x18421(%rip),%rax        # 1b0f0 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 0d 84 01 00 	sub    0x1840d(%rip),%rax        # 1b0e8 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 67 00 00 	lea    0x672d(%rip),%rsi        # 9440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 eb 9d 01 00 	mov    0x19deb(%rip),%rax        # 1cb30 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 e4 9d 01 00 	lea    0x19de4(%rip),%r8        # 1cb30 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d c5 9d 01 00 	mov    0x19dc5(%rip),%rbx        # 1cb18 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d d5 9d 01 00 	mov    0x19dd5(%rip),%rcx        # 1cb38 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 71 9d 01 00 	mov    0x19d71(%rip),%rdi        # 1cb20 <fwp_heap+0x13e0>
    2daf:	48 29 35 ba 9d 01 00 	sub    %rsi,0x19dba(%rip)        # 1cb70 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 4a 9d 01 00 	mov    0x19d4a(%rip),%rax        # 1cb10 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 00 9d 01 00 	add    0x19d00(%rip),%rdi        # 1caf0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 0e 9d 01 00 	mov    0x19d0e(%rip),%rsi        # 1cb20 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 1c 9d 01 00 	mov    0x19d1c(%rip),%rax        # 1cb38 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 cb 9c 01 00 	mov    %r12,0x19ccb(%rip)        # 1cb20 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d b9 9c 01 00 	mov    %rbp,0x19cb9(%rip)        # 1cb18 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 9e 9c 01 00 	cmp    %rdi,0x19c9e(%rip)        # 1cb08 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 95 9c 01 00 	mov    %rdi,0x19c95(%rip)        # 1cb08 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d d9 9c 01 00 	sub    %rdi,0x19cd9(%rip)        # 1cb70 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 81 9c 01 00 	mov    0x19c81(%rip),%rax        # 1cb28 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 7a 9c 01 00 	lea    0x19c7a(%rip),%r8        # 1cb28 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d 4d 81 00 00 	mov    0x814d(%rip),%rcx        # b0a0 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 60 00 00 	lea    0x60a4(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d 59 87 01 00 	cmp    0x18759(%rip),%rdi        # 1b720 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 1f 87 01 00 	mov    0x1871f(%rip),%rax        # 1b700 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d fd 86 01 00 	mov    %rdi,0x186fd(%rip)        # 1b700 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d d9 86 01 00 	mov    %rdi,0x186d9(%rip)        # 1b708 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 60 00 00 	lea    0x6051(%rip),%rsi        # 90c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 5f 00 00 	lea    0x5f97(%rip),%rsi        # 901c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d d6 7f 00 00 	mov    0x7fd6(%rip),%rdi        # b0a0 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 5f 00 00 	lea    0x5f4f(%rip),%rdx        # 9020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 5e 00 00 	lea    0x5ed0(%rip),%rdi        # 902f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 60 00 00 	lea    0x6030(%rip),%rdi        # 91a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 5e 00 00 	lea    0x5eb8(%rip),%r8        # 904b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 5d 00 00 	lea    0x5d0d(%rip),%r8        # 905a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 5b 00 00 	lea    0x5b9a(%rip),%r8        # 9050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 59 00 00 	lea    0x5972(%rip),%rdi        # 905f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 59 00 00 	lea    0x59fc(%rip),%rsi        # 910a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 85 93 01 00 	mov    0x19385(%rip),%r9        # 1cb08 <fwp_heap+0x13c8>
    3783:	4c 8b 05 de 93 01 00 	mov    0x193de(%rip),%r8        # 1cb68 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 5a 00 00 	lea    0x5a3f(%rip),%rdx        # 91d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d c6 93 01 00 	mov    0x193c6(%rip),%rcx        # 1cb60 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d d4 93 01 	movsd  0x193d4(%rip),%xmm1        # 1cb80 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 c4 93 01 	movsd  0x193c4(%rip),%xmm0        # 1cb78 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d e5 78 00 00 	mov    0x78e5(%rip),%rdi        # b0a0 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 5c 00 	movdqa 0x5c68(%rip),%xmm0        # 9460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 7f 8e 01 00 	lea    0x18e7f(%rip),%rax        # 1c680 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 5c 00 	movdqa 0x5c91(%rip),%xmm2        # 94a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 25 8e 01 00 	movaps %xmm0,0x18e25(%rip)        # 1c640 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 5c 00 	movdqa 0x5c4d(%rip),%xmm0        # 9470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 b3 92 01 00 01 	movl   $0x1,0x192b3(%rip)        # 1cae4 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 13 8e 01 00 	movaps %xmm0,0x18e13(%rip)        # 1c650 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 5c 00 	movdqa 0x5c3b(%rip),%xmm0        # 9480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 14 8e 01 00 	movaps %xmm0,0x18e14(%rip)        # 1c660 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 5c 00 	movdqa 0x5c3c(%rip),%xmm0        # 9490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 15 8e 01 00 	movaps %xmm0,0x18e15(%rip)        # 1c670 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 95 7e 01 00 	lea    0x17e95(%rip),%r8        # 1b740 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 b0 91 01 00 	mov    %rax,0x191b0(%rip)        # 1caf8 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 8e 91 01 00 	mov    %r12,0x1918e(%rip)        # 1cb00 <fwp_heap+0x13c0>
    3972:	48 89 05 77 91 01 00 	mov    %rax,0x19177(%rip)        # 1caf0 <fwp_heap+0x13b0>
    3979:	48 89 1d 90 91 01 00 	mov    %rbx,0x19190(%rip)        # 1cb10 <fwp_heap+0x13d0>
    3980:	48 89 35 b9 91 01 00 	mov    %rsi,0x191b9(%rip)        # 1cb40 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 56 00 00 	lea    0x56fc(%rip),%rdi        # 9095 <_IO_stdin_used+0x95>
    3999:	48 89 05 98 91 01 00 	mov    %rax,0x19198(%rip)        # 1cb38 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 1c 91 01 00    	mov    %eax,0x1911c(%rip)        # 1cae8 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 0c 7d 01 00 	mov    0x17d0c(%rip),%r8        # 1b700 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d 3c 7c 01 00 	mov    %rbx,0x17c3c(%rip)        # 1b708 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 28 7c 01 00 	mov    %r8,0x17c28(%rip)        # 1b700 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d e7 7b 01 00 	mov    0x17be7(%rip),%rbx        # 1b6f8 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 8a 74 00 00 	mov    0x748a(%rip),%rcx        # b0a0 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 56 00 00 	lea    0x563b(%rip),%rdi        # 9258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 ad 7a 01 00 	mov    0x17aad(%rip),%rax        # 1b700 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 87 7a 01 00 	mov    %rdx,0x17a87(%rip)        # 1b700 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d d4 79 01 00 	mov    0x179d4(%rip),%rbx        # 1b6f8 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 91 79 01 00 	mov    %rbx,0x17991(%rip)        # 1b6f8 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 91 79 01 00 	mov    %rdx,0x17991(%rip)        # 1b708 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 7e 79 01 00 	lea    0x1797e(%rip),%rcx        # 1b740 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 7f 95 01 00 	subq   $0x1,0x1957f(%rip)        # 1d388 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 54 00 00 	lea    0x5473(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 60 95 01 00 	cmpq   $0x0,0x19560(%rip)        # 1d388 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 b5 94 01 00 	sub    %rax,0x194b5(%rip)        # 1d390 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 93 94 01 00 	add    %r12,0x19493(%rip)        # 1d390 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 ef 8b 01 00 	mov    0x18bef(%rip),%rax        # 1cb38 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 ec 77 01 00 	lea    0x177ec(%rip),%rax        # 1b740 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 43 8b 01 00 	add    0x18b43(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 10 8b 01 00 	mov    0x18b10(%rip),%rsi        # 1caf0 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 31 8b 01 00 	mov    0x18b31(%rip),%rax        # 1cb18 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 25 8b 01 00 	add    0x18b25(%rip),%r8        # 1cb38 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 ed 8a 01 	addsd  0x18aed(%rip),%xmm0        # 1cb80 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 a2 76 01 00 	lea    0x176a2(%rip),%rax        # 1b740 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d ac 8a 01 00 	sub    %rdi,0x18aac(%rip)        # 1cb60 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 c4 8a 01 	movsd  %xmm0,0x18ac4(%rip)        # 1cb80 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 7e 8a 01 00 	sub    %rdx,0x18a7e(%rip)        # 1cb60 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 84 8a 01 	addsd  0x18a84(%rip),%xmm0        # 1cb80 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 78 8a 01 	movsd  %xmm0,0x18a78(%rip)        # 1cb80 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 0f 8a 01 00 	mov    0x18a0f(%rip),%rdx        # 1cb38 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d 09 8a 01 00 	add    %rcx,0x18a09(%rip)        # 1cb70 <fwp_heap+0x1430>
    4167:	4c 3b 0d c2 89 01 00 	cmp    0x189c2(%rip),%r9        # 1cb30 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d b9 89 01 00 	mov    %r9,0x189b9(%rip)        # 1cb30 <fwp_heap+0x13f0>
    4177:	4c 3b 0d aa 89 01 00 	cmp    0x189aa(%rip),%r9        # 1cb28 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 9d 89 01 00 	mov    %r9,0x1899d(%rip)        # 1cb28 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d b3 88 01 00 	add    0x188b3(%rip),%rdi        # 1cb38 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 90 74 01 00 	lea    0x17490(%rip),%r15        # 1b740 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 00 88 01 00 	add    0x18800(%rip),%r12        # 1caf0 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 59 88 01 00 	add    0x18859(%rip),%rax        # 1cb60 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 58 88 01 00 	cmp    %rax,0x18858(%rip)        # 1cb68 <fwp_heap+0x1428>
    4310:	48 89 05 49 88 01 00 	mov    %rax,0x18849(%rip)        # 1cb60 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 48 88 01 00 	mov    %rax,0x18848(%rip)        # 1cb68 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 44 88 01 	addsd  0x18844(%rip),%xmm0        # 1cb78 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 3c 88 01 	movsd  %xmm0,0x1883c(%rip)        # 1cb78 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 83 87 01 00    	mov    0x18783(%rip),%eax        # 1cae4 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d bf 73 01 00 	lea    0x173bf(%rip),%rdi        # 1b740 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 78 87 01 00 	add    0x18778(%rip),%rax        # 1cb60 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 73 87 01 00 	cmp    %rax,0x18773(%rip)        # 1cb68 <fwp_heap+0x1428>
    43f5:	48 89 05 64 87 01 00 	mov    %rax,0x18764(%rip)        # 1cb60 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 63 87 01 00 	mov    %rax,0x18763(%rip)        # 1cb68 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 5f 87 01 	addsd  0x1875f(%rip),%xmm0        # 1cb78 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 57 87 01 	movsd  %xmm0,0x18757(%rip)        # 1cb78 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_free_arr>:
    44d0:	48 8b 15 41 86 01 00 	mov    0x18641(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 2b 05 0f 86 01 00 	sub    0x1860f(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    44e1:	48 c1 e2 10          	shl    $0x10,%rdx
    44e5:	48 39 d0             	cmp    %rdx,%rax
    44e8:	73 5b                	jae    4545 <fwp_rc_free_arr+0x75>
    44ea:	48 89 c2             	mov    %rax,%rdx
    44ed:	48 c1 ea 10          	shr    $0x10,%rdx
    44f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f5:	48 8b 15 3c 86 01 00 	mov    0x1863c(%rip),%rdx        # 1cb38 <fwp_heap+0x13f8>
    44fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4500:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4504:	48 85 c9             	test   %rcx,%rcx
    4507:	74 3c                	je     4545 <fwp_rc_free_arr+0x75>
    4509:	0f b6 32             	movzbl (%rdx),%esi
    450c:	40 80 fe 02          	cmp    $0x2,%sil
    4510:	74 2e                	je     4540 <fwp_rc_free_arr+0x70>
    4512:	40 80 fe 01          	cmp    $0x1,%sil
    4516:	75 2d                	jne    4545 <fwp_rc_free_arr+0x75>
    4518:	8b 72 18             	mov    0x18(%rdx),%esi
    451b:	0f b7 c0             	movzwl %ax,%eax
    451e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4521:	48 0f af c6          	imul   %rsi,%rax
    4525:	48 c1 e8 20          	shr    $0x20,%rax
    4529:	48 39 d0             	cmp    %rdx,%rax
    452c:	73 17                	jae    4545 <fwp_rc_free_arr+0x75>
    452e:	48 01 c1             	add    %rax,%rcx
    4531:	80 39 01             	cmpb   $0x1,(%rcx)
    4534:	75 0f                	jne    4545 <fwp_rc_free_arr+0x75>
    4536:	e9 95 fa ff ff       	jmp    3fd0 <fwp_mem_free>
    453b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ec                	je     4531 <fwp_rc_free_arr+0x61>
    4545:	c3                   	ret
    4546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    454d:	00 00 00 

0000000000004550 <fwp_heap_alloc>:
    4550:	8b 05 8e 85 01 00    	mov    0x1858e(%rip),%eax        # 1cae4 <fwp_heap+0x13a4>
    4556:	48 89 fa             	mov    %rdi,%rdx
    4559:	89 f7                	mov    %esi,%edi
    455b:	85 c0                	test   %eax,%eax
    455d:	0f 84 f5 00 00 00    	je     4658 <fwp_heap_alloc+0x108>
    4563:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    456a:	0f 87 e8 00 00 00    	ja     4658 <fwp_heap_alloc+0x108>
    4570:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4574:	48 8d 05 c5 71 01 00 	lea    0x171c5(%rip),%rax        # 1b740 <fwp_heap>
    457b:	48 83 ec 18          	sub    $0x18,%rsp
    457f:	41 89 f0             	mov    %esi,%r8d
    4582:	48 c1 e9 04          	shr    $0x4,%rcx
    4586:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    458d:	00 
    458e:	48 63 cf             	movslq %edi,%rcx
    4591:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4598:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    459f:	00 
    45a0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    45a4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    45a8:	48 01 c8             	add    %rcx,%rax
    45ab:	48 8b 08             	mov    (%rax),%rcx
    45ae:	48 85 c9             	test   %rcx,%rcx
    45b1:	74 6d                	je     4620 <fwp_heap_alloc+0xd0>
    45b3:	48 8b 31             	mov    (%rcx),%rsi
    45b6:	48 f7 d6             	not    %rsi
    45b9:	48 89 30             	mov    %rsi,(%rax)
    45bc:	41 83 f8 01          	cmp    $0x1,%r8d
    45c0:	48 89 cf             	mov    %rcx,%rdi
    45c3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45c8:	49 0f 45 d1          	cmovne %r9,%rdx
    45cc:	31 f6                	xor    %esi,%esi
    45ce:	e8 cd de ff ff       	call   24a0 <memset@plt>
    45d3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    45d8:	48 89 c1             	mov    %rax,%rcx
    45db:	4c 89 c8             	mov    %r9,%rax
    45de:	48 03 05 7b 85 01 00 	add    0x1857b(%rip),%rax        # 1cb60 <fwp_heap+0x1420>
    45e5:	72 7b                	jb     4662 <fwp_heap_alloc+0x112>
    45e7:	48 39 05 7a 85 01 00 	cmp    %rax,0x1857a(%rip)        # 1cb68 <fwp_heap+0x1428>
    45ee:	48 89 05 6b 85 01 00 	mov    %rax,0x1856b(%rip)        # 1cb60 <fwp_heap+0x1420>
    45f5:	73 07                	jae    45fe <fwp_heap_alloc+0xae>
    45f7:	48 89 05 6a 85 01 00 	mov    %rax,0x1856a(%rip)        # 1cb68 <fwp_heap+0x1428>
    45fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4602:	48 89 c8             	mov    %rcx,%rax
    4605:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    460a:	f2 0f 58 05 66 85 01 	addsd  0x18566(%rip),%xmm0        # 1cb78 <fwp_heap+0x1438>
    4611:	00 
    4612:	f2 0f 11 05 5e 85 01 	movsd  %xmm0,0x1855e(%rip)        # 1cb78 <fwp_heap+0x1438>
    4619:	00 
    461a:	48 83 c4 18          	add    $0x18,%rsp
    461e:	c3                   	ret
    461f:	90                   	nop
    4620:	48 8b 48 08          	mov    0x8(%rax),%rcx
    4624:	48 85 c9             	test   %rcx,%rcx
    4627:	74 0c                	je     4635 <fwp_heap_alloc+0xe5>
    4629:	48 8b 70 10          	mov    0x10(%rax),%rsi
    462d:	48 29 ce             	sub    %rcx,%rsi
    4630:	4c 39 ce             	cmp    %r9,%rsi
    4633:	73 13                	jae    4648 <fwp_heap_alloc+0xf8>
    4635:	89 fe                	mov    %edi,%esi
    4637:	48 83 c4 18          	add    $0x18,%rsp
    463b:	48 89 d7             	mov    %rdx,%rdi
    463e:	e9 0d fd ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4643:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4648:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    464c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4650:	e9 67 ff ff ff       	jmp    45bc <fwp_heap_alloc+0x6c>
    4655:	0f 1f 00             	nopl   (%rax)
    4658:	89 fe                	mov    %edi,%esi
    465a:	48 89 d7             	mov    %rdx,%rdi
    465d:	e9 ee fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4662:	e8 99 e5 ff ff       	call   2c00 <fwp_heap_oom>
    4667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    466e:	00 00 

0000000000004670 <fwp_data.part.0.constprop.0>:
    4670:	41 56                	push   %r14
    4672:	41 89 fe             	mov    %edi,%r14d
    4675:	41 54                	push   %r12
    4677:	49 89 f4             	mov    %rsi,%r12
    467a:	55                   	push   %rbp
    467b:	53                   	push   %rbx
    467c:	48 83 ec 08          	sub    $0x8,%rsp
    4680:	8b 05 5e 84 01 00    	mov    0x1845e(%rip),%eax        # 1cae4 <fwp_heap+0x13a4>
    4686:	85 c0                	test   %eax,%eax
    4688:	0f 84 fa 00 00 00    	je     4788 <fwp_data.part.0.constprop.0+0x118>
    468e:	0f b6 05 4d 80 01 00 	movzbl 0x1804d(%rip),%eax        # 1c6e2 <fwp_heap+0xfa2>
    4695:	48 8d 15 a4 70 01 00 	lea    0x170a4(%rip),%rdx        # 1b740 <fwp_heap>
    469c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    46a3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    46a7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    46ab:	48 8b 18             	mov    (%rax),%rbx
    46ae:	48 85 db             	test   %rbx,%rbx
    46b1:	0f 84 a9 00 00 00    	je     4760 <fwp_data.part.0.constprop.0+0xf0>
    46b7:	48 8b 13             	mov    (%rbx),%rdx
    46ba:	48 f7 d2             	not    %rdx
    46bd:	48 89 10             	mov    %rdx,(%rax)
    46c0:	48 83 fd 18          	cmp    $0x18,%rbp
    46c4:	76 1b                	jbe    46e1 <fwp_data.part.0.constprop.0+0x71>
    46c6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    46ca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    46ce:	31 f6                	xor    %esi,%esi
    46d0:	48 c1 e8 03          	shr    $0x3,%rax
    46d4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    46db:	00 
    46dc:	e8 bf dd ff ff       	call   24a0 <memset@plt>
    46e1:	48 89 e8             	mov    %rbp,%rax
    46e4:	48 03 05 75 84 01 00 	add    0x18475(%rip),%rax        # 1cb60 <fwp_heap+0x1420>
    46eb:	0f 82 a8 00 00 00    	jb     4799 <fwp_data.part.0.constprop.0+0x129>
    46f1:	48 39 05 70 84 01 00 	cmp    %rax,0x18470(%rip)        # 1cb68 <fwp_heap+0x1428>
    46f8:	48 89 05 61 84 01 00 	mov    %rax,0x18461(%rip)        # 1cb60 <fwp_heap+0x1420>
    46ff:	73 07                	jae    4708 <fwp_data.part.0.constprop.0+0x98>
    4701:	48 89 05 60 84 01 00 	mov    %rax,0x18460(%rip)        # 1cb68 <fwp_heap+0x1428>
    4708:	66 0f ef c0          	pxor   %xmm0,%xmm0
    470c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    4711:	f2 0f 58 05 5f 84 01 	addsd  0x1845f(%rip),%xmm0        # 1cb78 <fwp_heap+0x1438>
    4718:	00 
    4719:	f2 0f 11 05 57 84 01 	movsd  %xmm0,0x18457(%rip)        # 1cb78 <fwp_heap+0x1438>
    4720:	00 
    4721:	b8 02 00 00 00       	mov    $0x2,%eax
    4726:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    472b:	66 0f 6e c8          	movd   %eax,%xmm1
    472f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    4733:	66 0f d6 03          	movq   %xmm0,(%rbx)
    4737:	49 8b 04 24          	mov    (%r12),%rax
    473b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    473f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    4744:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4748:	48 83 c4 08          	add    $0x8,%rsp
    474c:	48 89 d8             	mov    %rbx,%rax
    474f:	5b                   	pop    %rbx
    4750:	5d                   	pop    %rbp
    4751:	41 5c                	pop    %r12
    4753:	41 5e                	pop    %r14
    4755:	c3                   	ret
    4756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    475d:	00 00 00 
    4760:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4764:	48 85 db             	test   %rbx,%rbx
    4767:	74 1f                	je     4788 <fwp_data.part.0.constprop.0+0x118>
    4769:	48 8b 50 10          	mov    0x10(%rax),%rdx
    476d:	48 29 da             	sub    %rbx,%rdx
    4770:	48 39 ea             	cmp    %rbp,%rdx
    4773:	72 13                	jb     4788 <fwp_data.part.0.constprop.0+0x118>
    4775:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4779:	48 89 50 08          	mov    %rdx,0x8(%rax)
    477d:	e9 3e ff ff ff       	jmp    46c0 <fwp_data.part.0.constprop.0+0x50>
    4782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4788:	31 f6                	xor    %esi,%esi
    478a:	bf 18 00 00 00       	mov    $0x18,%edi
    478f:	e8 bc fd ff ff       	call   4550 <fwp_heap_alloc>
    4794:	48 89 c3             	mov    %rax,%rbx
    4797:	eb 88                	jmp    4721 <fwp_data.part.0.constprop.0+0xb1>
    4799:	e8 62 e4 ff ff       	call   2c00 <fwp_heap_oom>
    479e:	66 90                	xchg   %ax,%ax

00000000000047a0 <fwp_array_new_packed.constprop.0>:
    47a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    47a7:	ff ff 1f 
    47aa:	53                   	push   %rbx
    47ab:	48 39 f8             	cmp    %rdi,%rax
    47ae:	72 1a                	jb     47ca <fwp_array_new_packed.constprop.0+0x2a>
    47b0:	48 89 fb             	mov    %rdi,%rbx
    47b3:	be 01 00 00 00       	mov    $0x1,%esi
    47b8:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    47bf:	00 
    47c0:	e8 8b fd ff ff       	call   4550 <fwp_heap_alloc>
    47c5:	48 89 18             	mov    %rbx,(%rax)
    47c8:	5b                   	pop    %rbx
    47c9:	c3                   	ret
    47ca:	48 8d 3d d4 48 00 00 	lea    0x48d4(%rip),%rdi        # 90a5 <_IO_stdin_used+0xa5>
    47d1:	e8 da e8 ff ff       	call   30b0 <fwp_trap>
    47d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    47dd:	00 00 00 

00000000000047e0 <fwp_task_dispose>:
    47e0:	53                   	push   %rbx
    47e1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    47e5:	0f 84 1b df ff ff    	je     2706 <fwp_task_dispose.cold>
    47eb:	48 89 fb             	mov    %rdi,%rbx
    47ee:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    47f3:	0f 85 0d df ff ff    	jne    2706 <fwp_task_dispose.cold>
    47f9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    47fd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4804:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    480b:	00 
    480c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4810:	48 85 ff             	test   %rdi,%rdi
    4813:	74 07                	je     481c <fwp_task_dispose+0x3c>
    4815:	48 85 c0             	test   %rax,%rax
    4818:	74 02                	je     481c <fwp_task_dispose+0x3c>
    481a:	ff d0                	call   *%rax
    481c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4823:	e8 a8 f7 ff ff       	call   3fd0 <fwp_mem_free>
    4828:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    482f:	00 00 00 00 
    4833:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4837:	74 6f                	je     48a8 <fwp_task_dispose+0xc8>
    4839:	48 8b 15 d8 82 01 00 	mov    0x182d8(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    4840:	48 89 d8             	mov    %rbx,%rax
    4843:	48 2b 05 a6 82 01 00 	sub    0x182a6(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    484a:	48 c1 e2 10          	shl    $0x10,%rdx
    484e:	48 39 d0             	cmp    %rdx,%rax
    4851:	73 4c                	jae    489f <fwp_task_dispose+0xbf>
    4853:	48 89 c2             	mov    %rax,%rdx
    4856:	48 c1 ea 10          	shr    $0x10,%rdx
    485a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    485e:	48 8b 15 d3 82 01 00 	mov    0x182d3(%rip),%rdx        # 1cb38 <fwp_heap+0x13f8>
    4865:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4869:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    486d:	48 85 c9             	test   %rcx,%rcx
    4870:	74 2d                	je     489f <fwp_task_dispose+0xbf>
    4872:	0f b6 32             	movzbl (%rdx),%esi
    4875:	40 80 fe 02          	cmp    $0x2,%sil
    4879:	74 3d                	je     48b8 <fwp_task_dispose+0xd8>
    487b:	40 80 fe 01          	cmp    $0x1,%sil
    487f:	75 1e                	jne    489f <fwp_task_dispose+0xbf>
    4881:	8b 72 18             	mov    0x18(%rdx),%esi
    4884:	0f b7 c0             	movzwl %ax,%eax
    4887:	8b 52 1c             	mov    0x1c(%rdx),%edx
    488a:	48 0f af c6          	imul   %rsi,%rax
    488e:	48 c1 e8 20          	shr    $0x20,%rax
    4892:	48 39 d0             	cmp    %rdx,%rax
    4895:	73 08                	jae    489f <fwp_task_dispose+0xbf>
    4897:	48 01 c1             	add    %rax,%rcx
    489a:	80 39 01             	cmpb   $0x1,(%rcx)
    489d:	74 09                	je     48a8 <fwp_task_dispose+0xc8>
    489f:	5b                   	pop    %rbx
    48a0:	c3                   	ret
    48a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48a8:	48 89 df             	mov    %rbx,%rdi
    48ab:	5b                   	pop    %rbx
    48ac:	e9 1f f7 ff ff       	jmp    3fd0 <fwp_mem_free>
    48b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48b8:	66 85 c0             	test   %ax,%ax
    48bb:	74 dd                	je     489a <fwp_task_dispose+0xba>
    48bd:	5b                   	pop    %rbx
    48be:	c3                   	ret
    48bf:	90                   	nop

00000000000048c0 <fwp_free_zombie>:
    48c0:	48 8b 15 49 6e 01 00 	mov    0x16e49(%rip),%rdx        # 1b710 <fwp_zombie>
    48c7:	48 85 d2             	test   %rdx,%rdx
    48ca:	0f 84 98 00 00 00    	je     4968 <fwp_free_zombie+0xa8>
    48d0:	48 3b 15 49 6e 01 00 	cmp    0x16e49(%rip),%rdx        # 1b720 <fwp_cur>
    48d7:	0f 84 8b 00 00 00    	je     4968 <fwp_free_zombie+0xa8>
    48dd:	48 83 ec 18          	sub    $0x18,%rsp
    48e1:	48 63 05 14 68 01 00 	movslq 0x16814(%rip),%rax        # 1b0fc <fwp_stack_pool_n>
    48e8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    48ec:	83 f8 3f             	cmp    $0x3f,%eax
    48ef:	7f 7f                	jg     4970 <fwp_free_zombie+0xb0>
    48f1:	8d 48 01             	lea    0x1(%rax),%ecx
    48f4:	89 0d 02 68 01 00    	mov    %ecx,0x16802(%rip)        # 1b0fc <fwp_stack_pool_n>
    48fa:	48 8d 0d ff 67 01 00 	lea    0x167ff(%rip),%rcx        # 1b100 <fwp_stack_pool>
    4901:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4905:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    490c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4910:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4917:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    491b:	48 85 c9             	test   %rcx,%rcx
    491e:	0f 84 fc 00 00 00    	je     4a20 <fwp_free_zombie+0x160>
    4924:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    492b:	48 85 c0             	test   %rax,%rax
    492e:	74 07                	je     4937 <fwp_free_zombie+0x77>
    4930:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4937:	8b 42 5c             	mov    0x5c(%rdx),%eax
    493a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    493e:	48 c7 05 c7 6d 01 00 	movq   $0x0,0x16dc7(%rip)        # 1b710 <fwp_zombie>
    4945:	00 00 00 00 
    4949:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4950:	85 c0                	test   %eax,%eax
    4952:	74 34                	je     4988 <fwp_free_zombie+0xc8>
    4954:	83 f8 01             	cmp    $0x1,%eax
    4957:	0f 84 b3 00 00 00    	je     4a10 <fwp_free_zombie+0x150>
    495d:	48 83 c4 18          	add    $0x18,%rsp
    4961:	c3                   	ret
    4962:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4968:	c3                   	ret
    4969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4970:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4974:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4979:	e8 32 dc ff ff       	call   25b0 <munmap@plt>
    497e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4983:	eb 80                	jmp    4905 <fwp_free_zombie+0x45>
    4985:	0f 1f 00             	nopl   (%rax)
    4988:	48 8b 0d 89 81 01 00 	mov    0x18189(%rip),%rcx        # 1cb18 <fwp_heap+0x13d8>
    498f:	48 89 d0             	mov    %rdx,%rax
    4992:	48 2b 05 57 81 01 00 	sub    0x18157(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    4999:	48 c1 e1 10          	shl    $0x10,%rcx
    499d:	48 39 c8             	cmp    %rcx,%rax
    49a0:	73 bb                	jae    495d <fwp_free_zombie+0x9d>
    49a2:	48 89 c1             	mov    %rax,%rcx
    49a5:	48 c1 e9 10          	shr    $0x10,%rcx
    49a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    49ad:	48 8b 0d 84 81 01 00 	mov    0x18184(%rip),%rcx        # 1cb38 <fwp_heap+0x13f8>
    49b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    49b8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    49bc:	48 85 c9             	test   %rcx,%rcx
    49bf:	74 9c                	je     495d <fwp_free_zombie+0x9d>
    49c1:	0f b6 3e             	movzbl (%rsi),%edi
    49c4:	40 80 ff 02          	cmp    $0x2,%dil
    49c8:	74 66                	je     4a30 <fwp_free_zombie+0x170>
    49ca:	40 80 ff 01          	cmp    $0x1,%dil
    49ce:	75 8d                	jne    495d <fwp_free_zombie+0x9d>
    49d0:	8b 7e 18             	mov    0x18(%rsi),%edi
    49d3:	0f b7 c0             	movzwl %ax,%eax
    49d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    49d9:	48 0f af c7          	imul   %rdi,%rax
    49dd:	48 c1 e8 20          	shr    $0x20,%rax
    49e1:	48 39 f0             	cmp    %rsi,%rax
    49e4:	0f 83 73 ff ff ff    	jae    495d <fwp_free_zombie+0x9d>
    49ea:	48 01 c1             	add    %rax,%rcx
    49ed:	0f b6 01             	movzbl (%rcx),%eax
    49f0:	84 c0                	test   %al,%al
    49f2:	0f 84 65 ff ff ff    	je     495d <fwp_free_zombie+0x9d>
    49f8:	3c 01                	cmp    $0x1,%al
    49fa:	74 14                	je     4a10 <fwp_free_zombie+0x150>
    49fc:	3c ff                	cmp    $0xff,%al
    49fe:	74 3b                	je     4a3b <fwp_free_zombie+0x17b>
    4a00:	83 e8 01             	sub    $0x1,%eax
    4a03:	88 01                	mov    %al,(%rcx)
    4a05:	e9 53 ff ff ff       	jmp    495d <fwp_free_zombie+0x9d>
    4a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a10:	48 89 d7             	mov    %rdx,%rdi
    4a13:	48 83 c4 18          	add    $0x18,%rsp
    4a17:	e9 c4 fd ff ff       	jmp    47e0 <fwp_task_dispose>
    4a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a20:	48 89 05 c1 6c 01 00 	mov    %rax,0x16cc1(%rip)        # 1b6e8 <fwp_tasks_active>
    4a27:	e9 ff fe ff ff       	jmp    492b <fwp_free_zombie+0x6b>
    4a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a30:	66 85 c0             	test   %ax,%ax
    4a33:	0f 85 24 ff ff ff    	jne    495d <fwp_free_zombie+0x9d>
    4a39:	eb b2                	jmp    49ed <fwp_free_zombie+0x12d>
    4a3b:	48 89 ca             	mov    %rcx,%rdx
    4a3e:	48 8d 35 fb 6c 01 00 	lea    0x16cfb(%rip),%rsi        # 1b740 <fwp_heap>
    4a45:	48 c1 ea 11          	shr    $0x11,%rdx
    4a49:	48 31 ca             	xor    %rcx,%rdx
    4a4c:	48 89 d0             	mov    %rdx,%rax
    4a4f:	48 c1 e8 09          	shr    $0x9,%rax
    4a53:	48 31 c2             	xor    %rax,%rdx
    4a56:	0f b6 d2             	movzbl %dl,%edx
    4a59:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4a60:	00 
    4a61:	48 85 c0             	test   %rax,%rax
    4a64:	75 23                	jne    4a89 <fwp_free_zombie+0x1c9>
    4a66:	eb 5c                	jmp    4ac4 <fwp_free_zombie+0x204>
    4a68:	66 90                	xchg   %ax,%ax
    4a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a71:	00 00 00 00 
    4a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a7c:	00 00 00 00 
    4a80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4a84:	48 85 c0             	test   %rax,%rax
    4a87:	74 3b                	je     4ac4 <fwp_free_zombie+0x204>
    4a89:	48 89 c2             	mov    %rax,%rdx
    4a8c:	48 39 08             	cmp    %rcx,(%rax)
    4a8f:	75 ef                	jne    4a80 <fwp_free_zombie+0x1c0>
    4a91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4a95:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4a99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4a9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4aa4:	0f 85 b3 fe ff ff    	jne    495d <fwp_free_zombie+0x9d>
    4aaa:	48 89 cf             	mov    %rcx,%rdi
    4aad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4ab2:	e8 d9 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4ab7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4abc:	c6 01 fe             	movb   $0xfe,(%rcx)
    4abf:	e9 99 fe ff ff       	jmp    495d <fwp_free_zombie+0x9d>
    4ac4:	48 8d 3d bd 47 00 00 	lea    0x47bd(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    4acb:	e8 e0 e5 ff ff       	call   30b0 <fwp_trap>

0000000000004ad0 <fwp_block>:
    4ad0:	48 83 ec 08          	sub    $0x8,%rsp
    4ad4:	48 8b 05 2d 6c 01 00 	mov    0x16c2d(%rip),%rax        # 1b708 <fwp_ready_head>
    4adb:	48 85 c0             	test   %rax,%rax
    4ade:	0f 84 1c 01 00 00    	je     4c00 <fwp_block+0x130>
    4ae4:	90                   	nop
    4ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4aec:	00 00 00 00 
    4af0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4af7:	48 89 15 0a 6c 01 00 	mov    %rdx,0x16c0a(%rip)        # 1b708 <fwp_ready_head>
    4afe:	48 85 d2             	test   %rdx,%rdx
    4b01:	0f 84 19 01 00 00    	je     4c20 <fwp_block+0x150>
    4b07:	48 8b 15 12 6c 01 00 	mov    0x16c12(%rip),%rdx        # 1b720 <fwp_cur>
    4b0e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b12:	48 39 c2             	cmp    %rax,%rdx
    4b15:	0f 84 d5 00 00 00    	je     4bf0 <fwp_block+0x120>
    4b1b:	48 8b 0d 7e 88 01 00 	mov    0x1887e(%rip),%rcx        # 1d3a0 <fwp_state_owners>
    4b22:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4b26:	48 89 05 f3 6b 01 00 	mov    %rax,0x16bf3(%rip)        # 1b720 <fwp_cur>
    4b2d:	f3 0f 7e 05 93 88 01 	movq   0x18893(%rip),%xmm0        # 1d3c8 <fwp_foreign_callbacks>
    4b34:	00 
    4b35:	0f 16 05 7c 88 01 00 	movhps 0x1887c(%rip),%xmm0        # 1d3b8 <fwp_state>
    4b3c:	f3 0f 7e 0d 7c 88 01 	movq   0x1887c(%rip),%xmm1        # 1d3c0 <fwp_handlers>
    4b43:	00 
    4b44:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4b4b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4b52:	0f 16 0d 77 88 01 00 	movhps 0x18877(%rip),%xmm1        # 1d3d0 <fwp_cleanups>
    4b59:	f3 0f 7e 05 4f 88 01 	movq   0x1884f(%rip),%xmm0        # 1d3b0 <fwp_state_len>
    4b60:	00 
    4b61:	0f 16 05 40 88 01 00 	movhps 0x18840(%rip),%xmm0        # 1d3a8 <fwp_state_cap>
    4b68:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4b6f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4b76:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b7a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4b81:	48 89 0d 38 88 01 00 	mov    %rcx,0x18838(%rip)        # 1d3c0 <fwp_handlers>
    4b88:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4b8f:	48 89 0d 3a 88 01 00 	mov    %rcx,0x1883a(%rip)        # 1d3d0 <fwp_cleanups>
    4b96:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4b9d:	48 89 0d 24 88 01 00 	mov    %rcx,0x18824(%rip)        # 1d3c8 <fwp_foreign_callbacks>
    4ba4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4bab:	48 89 0d 06 88 01 00 	mov    %rcx,0x18806(%rip)        # 1d3b8 <fwp_state>
    4bb2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4bb9:	48 89 0d f0 87 01 00 	mov    %rcx,0x187f0(%rip)        # 1d3b0 <fwp_state_len>
    4bc0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4bc7:	48 89 0d da 87 01 00 	mov    %rcx,0x187da(%rip)        # 1d3a8 <fwp_state_cap>
    4bce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4bd5:	48 89 0d c4 87 01 00 	mov    %rcx,0x187c4(%rip)        # 1d3a0 <fwp_state_owners>
    4bdc:	e8 8f d8 ff ff       	call   2470 <swapcontext@plt>
    4be1:	f3 0f 1e fa          	endbr64
    4be5:	e8 d6 fc ff ff       	call   48c0 <fwp_free_zombie>
    4bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4bf0:	8b 05 02 65 01 00    	mov    0x16502(%rip),%eax        # 1b0f8 <fwp_slice>
    4bf6:	85 c0                	test   %eax,%eax
    4bf8:	74 36                	je     4c30 <fwp_block+0x160>
    4bfa:	48 83 c4 08          	add    $0x8,%rsp
    4bfe:	c3                   	ret
    4bff:	90                   	nop
    4c00:	e8 eb ee ff ff       	call   3af0 <fwp_poll_events>
    4c05:	48 8b 05 fc 6a 01 00 	mov    0x16afc(%rip),%rax        # 1b708 <fwp_ready_head>
    4c0c:	48 85 c0             	test   %rax,%rax
    4c0f:	0f 85 db fe ff ff    	jne    4af0 <fwp_block+0x20>
    4c15:	eb e9                	jmp    4c00 <fwp_block+0x130>
    4c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c1e:	00 00 
    4c20:	48 c7 05 d5 6a 01 00 	movq   $0x0,0x16ad5(%rip)        # 1b700 <fwp_ready_tail>
    4c27:	00 00 00 00 
    4c2b:	e9 d7 fe ff ff       	jmp    4b07 <fwp_block+0x37>
    4c30:	48 8d 3d 7e 44 00 00 	lea    0x447e(%rip),%rdi        # 90b5 <_IO_stdin_used+0xb5>
    4c37:	e8 44 d7 ff ff       	call   2380 <getenv@plt>
    4c3c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4c41:	48 85 c0             	test   %rax,%rax
    4c44:	74 05                	je     4c4b <fwp_block+0x17b>
    4c46:	80 38 00             	cmpb   $0x0,(%rax)
    4c49:	75 0b                	jne    4c56 <fwp_block+0x186>
    4c4b:	89 15 a7 64 01 00    	mov    %edx,0x164a7(%rip)        # 1b0f8 <fwp_slice>
    4c51:	48 83 c4 08          	add    $0x8,%rsp
    4c55:	c3                   	ret
    4c56:	ba 0a 00 00 00       	mov    $0xa,%edx
    4c5b:	31 f6                	xor    %esi,%esi
    4c5d:	48 89 c7             	mov    %rax,%rdi
    4c60:	e8 cb d8 ff ff       	call   2530 <strtoll@plt>
    4c65:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4c69:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4c70:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4c75:	0f 46 d0             	cmovbe %eax,%edx
    4c78:	eb d1                	jmp    4c4b <fwp_block+0x17b>
    4c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004c80 <fwp_drop0>:
    4c80:	48 8b 15 91 7e 01 00 	mov    0x17e91(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    4c87:	48 89 f8             	mov    %rdi,%rax
    4c8a:	48 2b 05 5f 7e 01 00 	sub    0x17e5f(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    4c91:	48 c1 e2 10          	shl    $0x10,%rdx
    4c95:	48 39 d0             	cmp    %rdx,%rax
    4c98:	0f 83 c2 00 00 00    	jae    4d60 <fwp_drop0+0xe0>
    4c9e:	48 83 ec 18          	sub    $0x18,%rsp
    4ca2:	4c 8d 05 97 6a 01 00 	lea    0x16a97(%rip),%r8        # 1b740 <fwp_heap>
    4ca9:	48 89 c2             	mov    %rax,%rdx
    4cac:	48 c1 ea 10          	shr    $0x10,%rdx
    4cb0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4cb4:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4cbb:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4cbf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4cc3:	48 85 d2             	test   %rdx,%rdx
    4cc6:	74 3c                	je     4d04 <fwp_drop0+0x84>
    4cc8:	0f b6 31             	movzbl (%rcx),%esi
    4ccb:	40 80 fe 02          	cmp    $0x2,%sil
    4ccf:	74 3f                	je     4d10 <fwp_drop0+0x90>
    4cd1:	40 80 fe 01          	cmp    $0x1,%sil
    4cd5:	75 2d                	jne    4d04 <fwp_drop0+0x84>
    4cd7:	8b 71 18             	mov    0x18(%rcx),%esi
    4cda:	0f b7 c0             	movzwl %ax,%eax
    4cdd:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4ce0:	48 0f af c6          	imul   %rsi,%rax
    4ce4:	48 c1 e8 20          	shr    $0x20,%rax
    4ce8:	48 39 c8             	cmp    %rcx,%rax
    4ceb:	73 17                	jae    4d04 <fwp_drop0+0x84>
    4ced:	48 01 c2             	add    %rax,%rdx
    4cf0:	0f b6 02             	movzbl (%rdx),%eax
    4cf3:	84 c0                	test   %al,%al
    4cf5:	74 0d                	je     4d04 <fwp_drop0+0x84>
    4cf7:	3c 01                	cmp    $0x1,%al
    4cf9:	74 25                	je     4d20 <fwp_drop0+0xa0>
    4cfb:	3c ff                	cmp    $0xff,%al
    4cfd:	74 69                	je     4d68 <fwp_drop0+0xe8>
    4cff:	83 e8 01             	sub    $0x1,%eax
    4d02:	88 02                	mov    %al,(%rdx)
    4d04:	48 83 c4 18          	add    $0x18,%rsp
    4d08:	c3                   	ret
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	66 85 c0             	test   %ax,%ax
    4d13:	74 db                	je     4cf0 <fwp_drop0+0x70>
    4d15:	48 83 c4 18          	add    $0x18,%rsp
    4d19:	c3                   	ret
    4d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d20:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4d24:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4d29:	e8 a2 f7 ff ff       	call   44d0 <fwp_rc_free_arr>
    4d2e:	4c 8d 05 0b 6a 01 00 	lea    0x16a0b(%rip),%r8        # 1b740 <fwp_heap>
    4d35:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4d3a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4d41:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4d48:	48 c1 e2 10          	shl    $0x10,%rdx
    4d4c:	48 39 d0             	cmp    %rdx,%rax
    4d4f:	73 b3                	jae    4d04 <fwp_drop0+0x84>
    4d51:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4d56:	e9 4e ff ff ff       	jmp    4ca9 <fwp_drop0+0x29>
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	c3                   	ret
    4d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d68:	48 89 d0             	mov    %rdx,%rax
    4d6b:	48 c1 e8 11          	shr    $0x11,%rax
    4d6f:	48 31 d0             	xor    %rdx,%rax
    4d72:	48 89 c1             	mov    %rax,%rcx
    4d75:	48 c1 e9 09          	shr    $0x9,%rcx
    4d79:	48 31 c8             	xor    %rcx,%rax
    4d7c:	0f b6 c8             	movzbl %al,%ecx
    4d7f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4d86:	00 
    4d87:	48 85 c0             	test   %rax,%rax
    4d8a:	75 1d                	jne    4da9 <fwp_drop0+0x129>
    4d8c:	eb 56                	jmp    4de4 <fwp_drop0+0x164>
    4d8e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4d9c:	00 00 00 00 
    4da0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4da4:	48 85 c0             	test   %rax,%rax
    4da7:	74 3b                	je     4de4 <fwp_drop0+0x164>
    4da9:	48 89 c1             	mov    %rax,%rcx
    4dac:	48 39 10             	cmp    %rdx,(%rax)
    4daf:	75 ef                	jne    4da0 <fwp_drop0+0x120>
    4db1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4db5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4db9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4dbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4dc4:	0f 85 3a ff ff ff    	jne    4d04 <fwp_drop0+0x84>
    4dca:	48 89 d7             	mov    %rdx,%rdi
    4dcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4dd2:	e8 b9 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4dd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4ddc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4ddf:	e9 20 ff ff ff       	jmp    4d04 <fwp_drop0+0x84>
    4de4:	48 8d 3d 9d 44 00 00 	lea    0x449d(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    4deb:	e8 c0 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004df0 <fwp_drop1>:
    4df0:	f3 0f 1e fa          	endbr64
    4df4:	48 8b 15 1d 7d 01 00 	mov    0x17d1d(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    4dfb:	48 89 f8             	mov    %rdi,%rax
    4dfe:	48 2b 05 eb 7c 01 00 	sub    0x17ceb(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    4e05:	48 c1 e2 10          	shl    $0x10,%rdx
    4e09:	48 39 d0             	cmp    %rdx,%rax
    4e0c:	0f 83 be 00 00 00    	jae    4ed0 <fwp_drop1+0xe0>
    4e12:	48 83 ec 18          	sub    $0x18,%rsp
    4e16:	4c 8d 05 23 69 01 00 	lea    0x16923(%rip),%r8        # 1b740 <fwp_heap>
    4e1d:	48 89 c2             	mov    %rax,%rdx
    4e20:	48 c1 ea 10          	shr    $0x10,%rdx
    4e24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4e2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4e33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4e37:	48 85 d2             	test   %rdx,%rdx
    4e3a:	74 3c                	je     4e78 <fwp_drop1+0x88>
    4e3c:	0f b6 31             	movzbl (%rcx),%esi
    4e3f:	40 80 fe 02          	cmp    $0x2,%sil
    4e43:	74 3b                	je     4e80 <fwp_drop1+0x90>
    4e45:	40 80 fe 01          	cmp    $0x1,%sil
    4e49:	75 2d                	jne    4e78 <fwp_drop1+0x88>
    4e4b:	8b 71 18             	mov    0x18(%rcx),%esi
    4e4e:	0f b7 c0             	movzwl %ax,%eax
    4e51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4e54:	48 0f af c6          	imul   %rsi,%rax
    4e58:	48 c1 e8 20          	shr    $0x20,%rax
    4e5c:	48 39 c8             	cmp    %rcx,%rax
    4e5f:	73 17                	jae    4e78 <fwp_drop1+0x88>
    4e61:	48 01 c2             	add    %rax,%rdx
    4e64:	0f b6 02             	movzbl (%rdx),%eax
    4e67:	84 c0                	test   %al,%al
    4e69:	74 0d                	je     4e78 <fwp_drop1+0x88>
    4e6b:	3c 01                	cmp    $0x1,%al
    4e6d:	74 21                	je     4e90 <fwp_drop1+0xa0>
    4e6f:	3c ff                	cmp    $0xff,%al
    4e71:	74 65                	je     4ed8 <fwp_drop1+0xe8>
    4e73:	83 e8 01             	sub    $0x1,%eax
    4e76:	88 02                	mov    %al,(%rdx)
    4e78:	48 83 c4 18          	add    $0x18,%rsp
    4e7c:	c3                   	ret
    4e7d:	0f 1f 00             	nopl   (%rax)
    4e80:	66 85 c0             	test   %ax,%ax
    4e83:	74 df                	je     4e64 <fwp_drop1+0x74>
    4e85:	48 83 c4 18          	add    $0x18,%rsp
    4e89:	c3                   	ret
    4e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4e94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e99:	e8 32 f6 ff ff       	call   44d0 <fwp_rc_free_arr>
    4e9e:	4c 8d 05 9b 68 01 00 	lea    0x1689b(%rip),%r8        # 1b740 <fwp_heap>
    4ea5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4eaa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4eb1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4eb8:	48 c1 e2 10          	shl    $0x10,%rdx
    4ebc:	48 39 d0             	cmp    %rdx,%rax
    4ebf:	73 b7                	jae    4e78 <fwp_drop1+0x88>
    4ec1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4ec6:	e9 52 ff ff ff       	jmp    4e1d <fwp_drop1+0x2d>
    4ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed0:	c3                   	ret
    4ed1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ed8:	48 89 d0             	mov    %rdx,%rax
    4edb:	48 c1 e8 11          	shr    $0x11,%rax
    4edf:	48 31 d0             	xor    %rdx,%rax
    4ee2:	48 89 c1             	mov    %rax,%rcx
    4ee5:	48 c1 e9 09          	shr    $0x9,%rcx
    4ee9:	48 31 c8             	xor    %rcx,%rax
    4eec:	0f b6 c8             	movzbl %al,%ecx
    4eef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4ef6:	00 
    4ef7:	48 85 c0             	test   %rax,%rax
    4efa:	75 0d                	jne    4f09 <fwp_drop1+0x119>
    4efc:	eb 46                	jmp    4f44 <fwp_drop1+0x154>
    4efe:	66 90                	xchg   %ax,%ax
    4f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4f04:	48 85 c0             	test   %rax,%rax
    4f07:	74 3b                	je     4f44 <fwp_drop1+0x154>
    4f09:	48 89 c1             	mov    %rax,%rcx
    4f0c:	48 39 10             	cmp    %rdx,(%rax)
    4f0f:	75 ef                	jne    4f00 <fwp_drop1+0x110>
    4f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4f24:	0f 85 4e ff ff ff    	jne    4e78 <fwp_drop1+0x88>
    4f2a:	48 89 d7             	mov    %rdx,%rdi
    4f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4f32:	e8 59 ee ff ff       	call   3d90 <fwp_rc_forget_slot>
    4f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4f3f:	e9 34 ff ff ff       	jmp    4e78 <fwp_drop1+0x88>
    4f44:	48 8d 3d 3d 43 00 00 	lea    0x433d(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    4f4b:	e8 60 e1 ff ff       	call   30b0 <fwp_trap>

0000000000004f50 <fwp_write.constprop.0>:
    4f50:	41 57                	push   %r15
    4f52:	41 56                	push   %r14
    4f54:	41 55                	push   %r13
    4f56:	41 54                	push   %r12
    4f58:	55                   	push   %rbp
    4f59:	53                   	push   %rbx
    4f5a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    4f61:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    4f68:	00 00 
    4f6a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    4f71:	00 
    4f72:	49 89 d4             	mov    %rdx,%r12
    4f75:	8b 12                	mov    (%rdx),%edx
    4f77:	83 fa 19             	cmp    $0x19,%edx
    4f7a:	77 64                	ja     4fe0 <fwp_write.constprop.0+0x90>
    4f7c:	48 8d 0d 4d 44 00 00 	lea    0x444d(%rip),%rcx        # 93d0 <_IO_stdin_used+0x3d0>
    4f83:	89 d0                	mov    %edx,%eax
    4f85:	48 89 fb             	mov    %rdi,%rbx
    4f88:	48 89 f5             	mov    %rsi,%rbp
    4f8b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    4f8f:	48 01 c8             	add    %rcx,%rax
    4f92:	3e ff e0             	notrack jmp *%rax
    4f95:	0f 1f 00             	nopl   (%rax)
    4f98:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    4f9c:	48 8b 06             	mov    (%rsi),%rax
    4f9f:	48 89 ca             	mov    %rcx,%rdx
    4fa2:	48 85 c9             	test   %rcx,%rcx
    4fa5:	0f 88 b5 0c 00 00    	js     5c60 <fwp_write.constprop.0+0xd10>
    4fab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    4fb2:	00 
    4fb3:	48 89 c6             	mov    %rax,%rsi
    4fb6:	4c 89 e7             	mov    %r12,%rdi
    4fb9:	e8 42 da ff ff       	call   2a00 <fwp_fmt_u128>
    4fbe:	66 90                	xchg   %ax,%ax
    4fc0:	4c 89 e7             	mov    %r12,%rdi
    4fc3:	e8 68 d4 ff ff       	call   2430 <strlen@plt>
    4fc8:	4c 89 e6             	mov    %r12,%rsi
    4fcb:	48 89 df             	mov    %rbx,%rdi
    4fce:	48 89 c2             	mov    %rax,%rdx
    4fd1:	e8 aa df ff ff       	call   2f80 <buf_put>
    4fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fdd:	00 00 00 
    4fe0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    4fe7:	00 
    4fe8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4fef:	00 00 
    4ff1:	0f 85 9e 04 00 00    	jne    5495 <fwp_write.constprop.0+0x545>
    4ff7:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    4ffe:	5b                   	pop    %rbx
    4fff:	5d                   	pop    %rbp
    5000:	41 5c                	pop    %r12
    5002:	41 5d                	pop    %r13
    5004:	41 5e                	pop    %r14
    5006:	41 5f                	pop    %r15
    5008:	c3                   	ret
    5009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5010:	49 89 f1             	mov    %rsi,%r9
    5013:	4c 8d 05 c3 40 00 00 	lea    0x40c3(%rip),%r8        # 90dd <_IO_stdin_used+0xdd>
    501a:	b9 00 02 00 00       	mov    $0x200,%ecx
    501f:	ba 02 00 00 00       	mov    $0x2,%edx
    5024:	be 00 02 00 00       	mov    $0x200,%esi
    5029:	31 c0                	xor    %eax,%eax
    502b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5032:	00 
    5033:	e8 58 d3 ff ff       	call   2390 <__snprintf_chk@plt>
    5038:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    503f:	00 
    5040:	e8 eb d3 ff ff       	call   2430 <strlen@plt>
    5045:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    504c:	00 
    504d:	48 89 df             	mov    %rbx,%rdi
    5050:	48 89 c2             	mov    %rax,%rdx
    5053:	e8 28 df ff ff       	call   2f80 <buf_put>
    5058:	eb 86                	jmp    4fe0 <fwp_write.constprop.0+0x90>
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	49 89 f1             	mov    %rsi,%r9
    5063:	4c 8d 05 6e 40 00 00 	lea    0x406e(%rip),%r8        # 90d8 <_IO_stdin_used+0xd8>
    506a:	eb ae                	jmp    501a <fwp_write.constprop.0+0xca>
    506c:	0f 1f 40 00          	nopl   0x0(%rax)
    5070:	83 fa 13             	cmp    $0x13,%edx
    5073:	48 8d 05 54 40 00 00 	lea    0x4054(%rip),%rax        # 90ce <_IO_stdin_used+0xce>
    507a:	48 8d 35 52 40 00 00 	lea    0x4052(%rip),%rsi        # 90d3 <_IO_stdin_used+0xd3>
    5081:	ba 04 00 00 00       	mov    $0x4,%edx
    5086:	48 0f 44 f0          	cmove  %rax,%rsi
    508a:	45 31 ed             	xor    %r13d,%r13d
    508d:	e8 ee de ff ff       	call   2f80 <buf_put>
    5092:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5097:	0f 84 b3 09 00 00    	je     5a50 <fwp_write.constprop.0+0xb00>
    509d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    50a2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    50a7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    50ac:	48 89 df             	mov    %rbx,%rdi
    50af:	49 0f 44 c5          	cmove  %r13,%rax
    50b3:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    50b8:	e8 93 fe ff ff       	call   4f50 <fwp_write.constprop.0>
    50bd:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    50c2:	0f 84 80 0a 00 00    	je     5b48 <fwp_write.constprop.0+0xbf8>
    50c8:	49 83 c5 01          	add    $0x1,%r13
    50cc:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    50d0:	0f 83 7a 09 00 00    	jae    5a50 <fwp_write.constprop.0+0xb00>
    50d6:	ba 02 00 00 00       	mov    $0x2,%edx
    50db:	48 8d 35 3b 40 00 00 	lea    0x403b(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    50e2:	48 89 df             	mov    %rbx,%rdi
    50e5:	e8 96 de ff ff       	call   2f80 <buf_put>
    50ea:	eb b1                	jmp    509d <fwp_write.constprop.0+0x14d>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	ba 06 00 00 00       	mov    $0x6,%edx
    50f5:	48 8d 35 fa 3f 00 00 	lea    0x3ffa(%rip),%rsi        # 90f6 <_IO_stdin_used+0xf6>
    50fc:	48 83 c5 10          	add    $0x10,%rbp
    5100:	e8 7b de ff ff       	call   2f80 <buf_put>
    5105:	48 89 ef             	mov    %rbp,%rdi
    5108:	e8 23 d3 ff ff       	call   2430 <strlen@plt>
    510d:	48 89 ee             	mov    %rbp,%rsi
    5110:	48 89 df             	mov    %rbx,%rdi
    5113:	48 89 c2             	mov    %rax,%rdx
    5116:	e8 65 de ff ff       	call   2f80 <buf_put>
    511b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5120:	ba 01 00 00 00       	mov    $0x1,%edx
    5125:	48 89 df             	mov    %rbx,%rdi
    5128:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    512d:	e8 4e de ff ff       	call   2f80 <buf_put>
    5132:	e9 a9 fe ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    513e:	00 00 
    5140:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5147:	00 
    5148:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    514f:	00 00 
    5151:	0f 85 3e 03 00 00    	jne    5495 <fwp_write.constprop.0+0x545>
    5157:	ba 0a 00 00 00       	mov    $0xa,%edx
    515c:	48 8d 35 7f 3f 00 00 	lea    0x3f7f(%rip),%rsi        # 90e2 <_IO_stdin_used+0xe2>
    5163:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    516a:	48 89 df             	mov    %rbx,%rdi
    516d:	5b                   	pop    %rbx
    516e:	5d                   	pop    %rbp
    516f:	41 5c                	pop    %r12
    5171:	41 5d                	pop    %r13
    5173:	41 5e                	pop    %r14
    5175:	41 5f                	pop    %r15
    5177:	e9 04 de ff ff       	jmp    2f80 <buf_put>
    517c:	0f 1f 40 00          	nopl   0x0(%rax)
    5180:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5185:	4d 85 ed             	test   %r13,%r13
    5188:	0f 84 c2 0b 00 00    	je     5d50 <fwp_write.constprop.0+0xe00>
    518e:	48 8d 35 95 3f 00 00 	lea    0x3f95(%rip),%rsi        # 912a <_IO_stdin_used+0x12a>
    5195:	4c 89 ef             	mov    %r13,%rdi
    5198:	e8 73 d3 ff ff       	call   2510 <strcmp@plt>
    519d:	41 89 c1             	mov    %eax,%r9d
    51a0:	85 c0                	test   %eax,%eax
    51a2:	0f 84 2c 0c 00 00    	je     5dd4 <fwp_write.constprop.0+0xe84>
    51a8:	4c 89 ef             	mov    %r13,%rdi
    51ab:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    51b0:	e8 7b d2 ff ff       	call   2430 <strlen@plt>
    51b5:	4c 89 ee             	mov    %r13,%rsi
    51b8:	48 89 df             	mov    %rbx,%rdi
    51bb:	48 89 c2             	mov    %rax,%rdx
    51be:	e8 bd dd ff ff       	call   2f80 <buf_put>
    51c3:	ba 01 00 00 00       	mov    $0x1,%edx
    51c8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51cd:	48 89 df             	mov    %rbx,%rdi
    51d0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    51d5:	e8 a6 dd ff ff       	call   2f80 <buf_put>
    51da:	ba 01 00 00 00       	mov    $0x1,%edx
    51df:	4c 89 fe             	mov    %r15,%rsi
    51e2:	48 89 df             	mov    %rbx,%rdi
    51e5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    51ea:	e8 91 dd ff ff       	call   2f80 <buf_put>
    51ef:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    51f4:	45 31 f6             	xor    %r14d,%r14d
    51f7:	85 c0                	test   %eax,%eax
    51f9:	0f 8e 91 0a 00 00    	jle    5c90 <fwp_write.constprop.0+0xd40>
    51ff:	45 31 ed             	xor    %r13d,%r13d
    5202:	4d 85 ed             	test   %r13,%r13
    5205:	0f 85 d5 08 00 00    	jne    5ae0 <fwp_write.constprop.0+0xb90>
    520b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5212:	00 
    5213:	45 85 f6             	test   %r14d,%r14d
    5216:	0f 84 74 08 00 00    	je     5a90 <fwp_write.constprop.0+0xb40>
    521c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    5221:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    5226:	48 89 df             	mov    %rbx,%rdi
    5229:	49 83 c5 01          	add    $0x1,%r13
    522d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    5231:	e8 1a fd ff ff       	call   4f50 <fwp_write.constprop.0>
    5236:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    523b:	7f c5                	jg     5202 <fwp_write.constprop.0+0x2b2>
    523d:	45 85 f6             	test   %r14d,%r14d
    5240:	0f 84 4a 0a 00 00    	je     5c90 <fwp_write.constprop.0+0xd40>
    5246:	b8 29 00 00 00       	mov    $0x29,%eax
    524b:	ba 01 00 00 00       	mov    $0x1,%edx
    5250:	4c 89 fe             	mov    %r15,%rsi
    5253:	48 89 df             	mov    %rbx,%rdi
    5256:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    525a:	e8 21 dd ff ff       	call   2f80 <buf_put>
    525f:	e9 7c fd ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5264:	0f 1f 40 00          	nopl   0x0(%rax)
    5268:	ba 01 00 00 00       	mov    $0x1,%edx
    526d:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5272:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    5277:	e8 04 dd ff ff       	call   2f80 <buf_put>
    527c:	48 85 ed             	test   %rbp,%rbp
    527f:	0f 84 8b 07 00 00    	je     5a10 <fwp_write.constprop.0+0xac0>
    5285:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5289:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    528e:	48 89 df             	mov    %rbx,%rdi
    5291:	e8 ba fc ff ff       	call   4f50 <fwp_write.constprop.0>
    5296:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    529a:	48 85 ed             	test   %rbp,%rbp
    529d:	0f 84 6d 07 00 00    	je     5a10 <fwp_write.constprop.0+0xac0>
    52a3:	ba 02 00 00 00       	mov    $0x2,%edx
    52a8:	48 8d 35 6e 3e 00 00 	lea    0x3e6e(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    52af:	48 89 df             	mov    %rbx,%rdi
    52b2:	e8 c9 dc ff ff       	call   2f80 <buf_put>
    52b7:	eb cc                	jmp    5285 <fwp_write.constprop.0+0x335>
    52b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52c0:	4c 8b 2e             	mov    (%rsi),%r13
    52c3:	ba 01 00 00 00       	mov    $0x1,%edx
    52c8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    52cd:	48 83 c5 08          	add    $0x8,%rbp
    52d1:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    52d6:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    52db:	e8 a0 dc ff ff       	call   2f80 <buf_put>
    52e0:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    52e5:	4d 85 ed             	test   %r13,%r13
    52e8:	75 43                	jne    532d <fwp_write.constprop.0+0x3dd>
    52ea:	e9 81 07 00 00       	jmp    5a70 <fwp_write.constprop.0+0xb20>
    52ef:	90                   	nop
    52f0:	41 80 f9 09          	cmp    $0x9,%r9b
    52f4:	0f 84 f6 06 00 00    	je     59f0 <fwp_write.constprop.0+0xaa0>
    52fa:	41 80 f9 0a          	cmp    $0xa,%r9b
    52fe:	0f 85 bc 06 00 00    	jne    59c0 <fwp_write.constprop.0+0xa70>
    5304:	ba 02 00 00 00       	mov    $0x2,%edx
    5309:	48 8d 35 f3 3d 00 00 	lea    0x3df3(%rip),%rsi        # 9103 <_IO_stdin_used+0x103>
    5310:	48 89 df             	mov    %rbx,%rdi
    5313:	e8 68 dc ff ff       	call   2f80 <buf_put>
    5318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    531f:	00 
    5320:	48 83 c5 01          	add    $0x1,%rbp
    5324:	49 39 ec             	cmp    %rbp,%r12
    5327:	0f 84 43 07 00 00    	je     5a70 <fwp_write.constprop.0+0xb20>
    532d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    5332:	41 80 f9 0d          	cmp    $0xd,%r9b
    5336:	0f 84 64 06 00 00    	je     59a0 <fwp_write.constprop.0+0xa50>
    533c:	7e b2                	jle    52f0 <fwp_write.constprop.0+0x3a0>
    533e:	41 80 f9 22          	cmp    $0x22,%r9b
    5342:	0f 84 38 06 00 00    	je     5980 <fwp_write.constprop.0+0xa30>
    5348:	41 80 f9 5c          	cmp    $0x5c,%r9b
    534c:	0f 85 6e 06 00 00    	jne    59c0 <fwp_write.constprop.0+0xa70>
    5352:	ba 02 00 00 00       	mov    $0x2,%edx
    5357:	48 8d 35 a2 3d 00 00 	lea    0x3da2(%rip),%rsi        # 9100 <_IO_stdin_used+0x100>
    535e:	48 89 df             	mov    %rbx,%rdi
    5361:	e8 1a dc ff ff       	call   2f80 <buf_put>
    5366:	eb b8                	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    536f:	00 
    5370:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    5375:	ba 01 00 00 00       	mov    $0x1,%edx
    537a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    537f:	48 89 ee             	mov    %rbp,%rsi
    5382:	e8 f9 db ff ff       	call   2f80 <buf_put>
    5387:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    538c:	4c 89 e7             	mov    %r12,%rdi
    538f:	e8 9c d0 ff ff       	call   2430 <strlen@plt>
    5394:	4c 89 e6             	mov    %r12,%rsi
    5397:	48 89 df             	mov    %rbx,%rdi
    539a:	48 89 c2             	mov    %rax,%rdx
    539d:	e8 de db ff ff       	call   2f80 <buf_put>
    53a2:	ba 01 00 00 00       	mov    $0x1,%edx
    53a7:	48 89 ee             	mov    %rbp,%rsi
    53aa:	48 89 df             	mov    %rbx,%rdi
    53ad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    53b2:	e8 c9 db ff ff       	call   2f80 <buf_put>
    53b7:	e9 24 fc ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    53bc:	0f 1f 40 00          	nopl   0x0(%rax)
    53c0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    53c5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    53c9:	0f 8a de 0a 00 00    	jp     5ead <fwp_write.constprop.0+0xf5d>
    53cf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    53d3:	66 0f 54 05 e5 40 00 	andpd  0x40e5(%rip),%xmm0        # 94c0 <msg.3+0x80>
    53da:	00 
    53db:	bd 01 00 00 00       	mov    $0x1,%ebp
    53e0:	66 0f 2e 05 f8 40 00 	ucomisd 0x40f8(%rip),%xmm0        # 94e0 <msg.3+0xa0>
    53e7:	00 
    53e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    53ef:	00 
    53f0:	0f 87 02 09 00 00    	ja     5cf8 <fwp_write.constprop.0+0xda8>
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5404:	89 ee                	mov    %ebp,%esi
    5406:	4c 89 e7             	mov    %r12,%rdi
    5409:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    540e:	e8 6d dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    5413:	31 f6                	xor    %esi,%esi
    5415:	4c 89 e7             	mov    %r12,%rdi
    5418:	e8 d3 cf ff ff       	call   23f0 <strtod@plt>
    541d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    5422:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    5426:	7a 06                	jp     542e <fwp_write.constprop.0+0x4de>
    5428:	0f 84 09 03 00 00    	je     5737 <fwp_write.constprop.0+0x7e7>
    542e:	83 c5 01             	add    $0x1,%ebp
    5431:	83 fd 12             	cmp    $0x12,%ebp
    5434:	75 ca                	jne    5400 <fwp_write.constprop.0+0x4b0>
    5436:	be 11 00 00 00       	mov    $0x11,%esi
    543b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    543f:	4c 89 e7             	mov    %r12,%rdi
    5442:	e8 39 dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    5447:	e9 eb 02 00 00       	jmp    5737 <fwp_write.constprop.0+0x7e7>
    544c:	0f 1f 40 00          	nopl   0x0(%rax)
    5450:	48 83 fe 01          	cmp    $0x1,%rsi
    5454:	0f 84 86 08 00 00    	je     5ce0 <fwp_write.constprop.0+0xd90>
    545a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    545e:	b8 02 00 00 00       	mov    $0x2,%eax
    5463:	ba 01 00 00 00       	mov    $0x1,%edx
    5468:	48 0f 44 d0          	cmove  %rax,%rdx
    546c:	48 8d 35 59 3c 00 00 	lea    0x3c59(%rip),%rsi        # 90cc <_IO_stdin_used+0xcc>
    5473:	48 8d 05 4f 3c 00 00 	lea    0x3c4f(%rip),%rax        # 90c9 <_IO_stdin_used+0xc9>
    547a:	48 0f 44 f0          	cmove  %rax,%rsi
    547e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5485:	00 
    5486:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    548d:	00 00 
    548f:	0f 84 ce fc ff ff    	je     5163 <fwp_write.constprop.0+0x213>
    5495:	e8 a6 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    54a0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    54a5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    54aa:	e8 11 da ff ff       	call   2ec0 <buf_grow>
    54af:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    54b3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    54b9:	4c 03 0b             	add    (%rbx),%r9
    54bc:	66 45 89 11          	mov    %r10w,(%r9)
    54c0:	49 83 c1 01          	add    $0x1,%r9
    54c4:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    54cb:	55 55 55 
    54ce:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    54d5:	aa aa aa 
    54d8:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    54dc:	45 85 e4             	test   %r12d,%r12d
    54df:	7f 4c                	jg     552d <fwp_write.constprop.0+0x5dd>
    54e1:	e9 4a 05 00 00       	jmp    5a30 <fwp_write.constprop.0+0xae0>
    54e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    54ed:	00 00 00 
    54f0:	be 01 00 00 00       	mov    $0x1,%esi
    54f5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    54fa:	88 07                	mov    %al,(%rdi)
    54fc:	48 89 e8             	mov    %rbp,%rax
    54ff:	49 f7 e8             	imul   %r8
    5502:	48 89 e8             	mov    %rbp,%rax
    5505:	48 c1 f8 3f          	sar    $0x3f,%rax
    5509:	48 29 c2             	sub    %rax,%rdx
    550c:	48 85 c9             	test   %rcx,%rcx
    550f:	0f 95 c0             	setne  %al
    5512:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5516:	48 83 ef 01          	sub    $0x1,%rdi
    551a:	48 21 c5             	and    %rax,%rbp
    551d:	48 29 ea             	sub    %rbp,%rdx
    5520:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    5524:	49 39 f9             	cmp    %rdi,%r9
    5527:	0f 84 03 05 00 00    	je     5a30 <fwp_write.constprop.0+0xae0>
    552d:	48 89 e8             	mov    %rbp,%rax
    5530:	49 f7 e8             	imul   %r8
    5533:	48 89 e8             	mov    %rbp,%rax
    5536:	48 c1 f8 3f          	sar    $0x3f,%rax
    553a:	48 89 d1             	mov    %rdx,%rcx
    553d:	48 29 c1             	sub    %rax,%rcx
    5540:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    5544:	48 89 e9             	mov    %rbp,%rcx
    5547:	48 29 c1             	sub    %rax,%rcx
    554a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    554e:	49 f7 e2             	mul    %r10
    5551:	b8 30 00 00 00       	mov    $0x30,%eax
    5556:	48 89 d6             	mov    %rdx,%rsi
    5559:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    555d:	48 d1 ee             	shr    $1,%rsi
    5560:	48 01 f2             	add    %rsi,%rdx
    5563:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    5567:	48 29 d6             	sub    %rdx,%rsi
    556a:	74 8e                	je     54fa <fwp_write.constprop.0+0x5aa>
    556c:	48 83 fe 01          	cmp    $0x1,%rsi
    5570:	0f 85 7a ff ff ff    	jne    54f0 <fwp_write.constprop.0+0x5a0>
    5576:	31 f6                	xor    %esi,%esi
    5578:	b8 2b 00 00 00       	mov    $0x2b,%eax
    557d:	e9 78 ff ff ff       	jmp    54fa <fwp_write.constprop.0+0x5aa>
    5582:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5588:	ba 06 00 00 00       	mov    $0x6,%edx
    558d:	48 8d 35 8c 3b 00 00 	lea    0x3b8c(%rip),%rsi        # 9120 <_IO_stdin_used+0x120>
    5594:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    559a:	e8 e1 d9 ff ff       	call   2f80 <buf_put>
    559f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    55a6:	ff ff 7f 
    55a9:	48 23 55 00          	and    0x0(%rbp),%rdx
    55ad:	0f 84 4e 03 00 00    	je     5901 <fwp_write.constprop.0+0x9b1>
    55b3:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    55b8:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    55bc:	48 85 d2             	test   %rdx,%rdx
    55bf:	0f 84 a4 00 00 00    	je     5669 <fwp_write.constprop.0+0x719>
    55c5:	8b 0a                	mov    (%rdx),%ecx
    55c7:	83 f9 1c             	cmp    $0x1c,%ecx
    55ca:	0f 84 d0 06 00 00    	je     5ca0 <fwp_write.constprop.0+0xd50>
    55d0:	83 f9 1b             	cmp    $0x1b,%ecx
    55d3:	0f 87 90 00 00 00    	ja     5669 <fwp_write.constprop.0+0x719>
    55d9:	be 01 00 00 00       	mov    $0x1,%esi
    55de:	48 d3 e6             	shl    %cl,%rsi
    55e1:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    55e7:	0f 85 13 06 00 00    	jne    5c00 <fwp_write.constprop.0+0xcb0>
    55ed:	f7 c6 84 04 00 00    	test   $0x484,%esi
    55f3:	0f 85 d7 05 00 00    	jne    5bd0 <fwp_write.constprop.0+0xc80>
    55f9:	83 e6 21             	and    $0x21,%esi
    55fc:	74 6b                	je     5669 <fwp_write.constprop.0+0x719>
    55fe:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5603:	48 85 ff             	test   %rdi,%rdi
    5606:	79 07                	jns    560f <fwp_write.constprop.0+0x6bf>
    5608:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    560c:	4c 01 ee             	add    %r13,%rsi
    560f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5613:	85 c9                	test   %ecx,%ecx
    5615:	40 0f b6 f7          	movzbl %dil,%esi
    5619:	48 0f 44 f7          	cmove  %rdi,%rsi
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	48 89 df             	mov    %rbx,%rdi
    5623:	49 83 c5 01          	add    $0x1,%r13
    5627:	e8 24 f9 ff ff       	call   4f50 <fwp_write.constprop.0>
    562c:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5633:	ff ff 7f 
    5636:	48 23 55 00          	and    0x0(%rbp),%rdx
    563a:	49 39 d5             	cmp    %rdx,%r13
    563d:	0f 83 be 02 00 00    	jae    5901 <fwp_write.constprop.0+0x9b1>
    5643:	ba 02 00 00 00       	mov    $0x2,%edx
    5648:	48 89 df             	mov    %rbx,%rdi
    564b:	48 8d 35 cb 3a 00 00 	lea    0x3acb(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    5652:	e8 29 d9 ff ff       	call   2f80 <buf_put>
    5657:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    565c:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    5660:	48 85 d2             	test   %rdx,%rdx
    5663:	0f 85 5c ff ff ff    	jne    55c5 <fwp_write.constprop.0+0x675>
    5669:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    566e:	48 85 ff             	test   %rdi,%rdi
    5671:	0f 88 51 06 00 00    	js     5cc8 <fwp_write.constprop.0+0xd78>
    5677:	48 8b 31             	mov    (%rcx),%rsi
    567a:	eb a4                	jmp    5620 <fwp_write.constprop.0+0x6d0>
    567c:	0f 1f 40 00          	nopl   0x0(%rax)
    5680:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5687:	00 
    5688:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    568f:	00 00 
    5691:	0f 85 fe fd ff ff    	jne    5495 <fwp_write.constprop.0+0x545>
    5697:	ba 08 00 00 00       	mov    $0x8,%edx
    569c:	48 8d 35 4a 3a 00 00 	lea    0x3a4a(%rip),%rsi        # 90ed <_IO_stdin_used+0xed>
    56a3:	e9 bb fa ff ff       	jmp    5163 <fwp_write.constprop.0+0x213>
    56a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56af:	00 
    56b0:	66 0f 6e ce          	movd   %esi,%xmm1
    56b4:	0f 2e c9             	ucomiss %xmm1,%xmm1
    56b7:	0f 8a f0 07 00 00    	jp     5ead <fwp_write.constprop.0+0xf5d>
    56bd:	0f 28 c1             	movaps %xmm1,%xmm0
    56c0:	0f 54 05 e9 3d 00 00 	andps  0x3de9(%rip),%xmm0        # 94b0 <msg.3+0x70>
    56c7:	0f 2e 05 36 39 00 00 	ucomiss 0x3936(%rip),%xmm0        # 9004 <_IO_stdin_used+0x4>
    56ce:	0f 87 4c 06 00 00    	ja     5d20 <fwp_write.constprop.0+0xdd0>
    56d4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    56d8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    56de:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    56e5:	00 
    56e6:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    56ea:	66 49 0f 7e d7       	movq   %xmm2,%r15
    56ef:	90                   	nop
    56f0:	44 89 ee             	mov    %r13d,%esi
    56f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    56f8:	4c 89 e7             	mov    %r12,%rdi
    56fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5700:	e8 7b da ff ff       	call   3180 <fwp_format_g.constprop.0>
    5705:	31 f6                	xor    %esi,%esi
    5707:	4c 89 e7             	mov    %r12,%rdi
    570a:	e8 81 cd ff ff       	call   2490 <strtof@plt>
    570f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5714:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5717:	7a 02                	jp     571b <fwp_write.constprop.0+0x7cb>
    5719:	74 1c                	je     5737 <fwp_write.constprop.0+0x7e7>
    571b:	41 83 c5 01          	add    $0x1,%r13d
    571f:	41 83 fd 0a          	cmp    $0xa,%r13d
    5723:	75 cb                	jne    56f0 <fwp_write.constprop.0+0x7a0>
    5725:	be 09 00 00 00       	mov    $0x9,%esi
    572a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    572f:	4c 89 e7             	mov    %r12,%rdi
    5732:	e8 49 da ff ff       	call   3180 <fwp_format_g.constprop.0>
    5737:	4c 89 e7             	mov    %r12,%rdi
    573a:	e8 01 d9 ff ff       	call   3040 <fwp_finish_float>
    573f:	e9 7c f8 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5744:	0f 1f 40 00          	nopl   0x0(%rax)
    5748:	89 f0                	mov    %esi,%eax
    574a:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5751:	76 02                	jbe    5755 <fwp_write.constprop.0+0x805>
    5753:	8b 06                	mov    (%rsi),%eax
    5755:	41 89 c6             	mov    %eax,%r14d
    5758:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    575d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5762:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5766:	4c 89 ef             	mov    %r13,%rdi
    5769:	e8 c2 cc ff ff       	call   2430 <strlen@plt>
    576e:	4c 89 ee             	mov    %r13,%rsi
    5771:	48 89 df             	mov    %rbx,%rdi
    5774:	48 89 c2             	mov    %rax,%rdx
    5777:	e8 04 d8 ff ff       	call   2f80 <buf_put>
    577c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5781:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5785:	85 f6                	test   %esi,%esi
    5787:	0f 8e 53 f8 ff ff    	jle    4fe0 <fwp_write.constprop.0+0x90>
    578d:	45 31 ed             	xor    %r13d,%r13d
    5790:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5795:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    579a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    579f:	4c 89 fe             	mov    %r15,%rsi
    57a2:	48 89 df             	mov    %rbx,%rdi
    57a5:	ba 01 00 00 00       	mov    $0x1,%edx
    57aa:	48 89 04 24          	mov    %rax,(%rsp)
    57ae:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    57b3:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    57b7:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    57bb:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    57c0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    57c5:	e8 b6 d7 ff ff       	call   2f80 <buf_put>
    57ca:	41 8b 06             	mov    (%r14),%eax
    57cd:	83 f8 0e             	cmp    $0xe,%eax
    57d0:	0f 84 5a 03 00 00    	je     5b30 <fwp_write.constprop.0+0xbe0>
    57d6:	83 f8 10             	cmp    $0x10,%eax
    57d9:	0f 84 21 03 00 00    	je     5b00 <fwp_write.constprop.0+0xbb0>
    57df:	83 f8 0a             	cmp    $0xa,%eax
    57e2:	0f 84 68 04 00 00    	je     5c50 <fwp_write.constprop.0+0xd00>
    57e8:	0f 8f 32 01 00 00    	jg     5920 <fwp_write.constprop.0+0x9d0>
    57ee:	83 f8 03             	cmp    $0x3,%eax
    57f1:	0f 8f 39 04 00 00    	jg     5c30 <fwp_write.constprop.0+0xce0>
    57f7:	85 c0                	test   %eax,%eax
    57f9:	78 10                	js     580b <fwp_write.constprop.0+0x8bb>
    57fb:	48 8b 04 24          	mov    (%rsp),%rax
    57ff:	48 c1 e8 3f          	shr    $0x3f,%rax
    5803:	85 c0                	test   %eax,%eax
    5805:	0f 85 32 01 00 00    	jne    593d <fwp_write.constprop.0+0x9ed>
    580b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5810:	48 8b 34 24          	mov    (%rsp),%rsi
    5814:	48 89 df             	mov    %rbx,%rdi
    5817:	e8 34 f7 ff ff       	call   4f50 <fwp_write.constprop.0>
    581c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5821:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5826:	49 83 c5 01          	add    $0x1,%r13
    582a:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    582e:	0f 8f 61 ff ff ff    	jg     5795 <fwp_write.constprop.0+0x845>
    5834:	e9 a7 f7 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5844:	48 8b 36             	mov    (%rsi),%rsi
    5847:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    584e:	00 
    584f:	48 89 ef             	mov    %rbp,%rdi
    5852:	e8 a9 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    5857:	48 89 ef             	mov    %rbp,%rdi
    585a:	e8 d1 cb ff ff       	call   2430 <strlen@plt>
    585f:	48 89 ee             	mov    %rbp,%rsi
    5862:	48 89 df             	mov    %rbx,%rdi
    5865:	48 89 c2             	mov    %rax,%rdx
    5868:	e8 13 d7 ff ff       	call   2f80 <buf_put>
    586d:	e9 6e f7 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5878:	ba 06 00 00 00       	mov    $0x6,%edx
    587d:	48 8d 35 8f 38 00 00 	lea    0x388f(%rip),%rsi        # 9113 <_IO_stdin_used+0x113>
    5884:	45 31 ed             	xor    %r13d,%r13d
    5887:	e8 f4 d6 ff ff       	call   2f80 <buf_put>
    588c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5891:	75 19                	jne    58ac <fwp_write.constprop.0+0x95c>
    5893:	eb 6c                	jmp    5901 <fwp_write.constprop.0+0x9b1>
    5895:	0f 1f 00             	nopl   (%rax)
    5898:	ba 02 00 00 00       	mov    $0x2,%edx
    589d:	48 8d 35 79 38 00 00 	lea    0x3879(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    58a4:	48 89 df             	mov    %rbx,%rdi
    58a7:	e8 d4 d6 ff ff       	call   2f80 <buf_put>
    58ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    58b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    58b7:	31 c0                	xor    %eax,%eax
    58b9:	49 83 c5 01          	add    $0x1,%r13
    58bd:	4c 8d 05 56 38 00 00 	lea    0x3856(%rip),%r8        # 911a <_IO_stdin_used+0x11a>
    58c4:	ba 02 00 00 00       	mov    $0x2,%edx
    58c9:	be 00 02 00 00       	mov    $0x200,%esi
    58ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58d5:	00 
    58d6:	e8 b5 ca ff ff       	call   2390 <__snprintf_chk@plt>
    58db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58e2:	00 
    58e3:	e8 48 cb ff ff       	call   2430 <strlen@plt>
    58e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    58ef:	00 
    58f0:	48 89 df             	mov    %rbx,%rdi
    58f3:	48 89 c2             	mov    %rax,%rdx
    58f6:	e8 85 d6 ff ff       	call   2f80 <buf_put>
    58fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    58ff:	72 97                	jb     5898 <fwp_write.constprop.0+0x948>
    5901:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5906:	ba 01 00 00 00       	mov    $0x1,%edx
    590b:	48 89 df             	mov    %rbx,%rdi
    590e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5913:	e8 68 d6 ff ff       	call   2f80 <buf_put>
    5918:	e9 c3 f6 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    591d:	0f 1f 00             	nopl   (%rax)
    5920:	83 f8 0b             	cmp    $0xb,%eax
    5923:	0f 85 e2 fe ff ff    	jne    580b <fwp_write.constprop.0+0x8bb>
    5929:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    592e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5932:	83 e0 01             	and    $0x1,%eax
    5935:	85 c0                	test   %eax,%eax
    5937:	0f 84 ce fe ff ff    	je     580b <fwp_write.constprop.0+0x8bb>
    593d:	4c 89 fe             	mov    %r15,%rsi
    5940:	48 89 df             	mov    %rbx,%rdi
    5943:	ba 01 00 00 00       	mov    $0x1,%edx
    5948:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    594d:	e8 2e d6 ff ff       	call   2f80 <buf_put>
    5952:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5957:	48 8b 34 24          	mov    (%rsp),%rsi
    595b:	48 89 df             	mov    %rbx,%rdi
    595e:	e8 ed f5 ff ff       	call   4f50 <fwp_write.constprop.0>
    5963:	ba 01 00 00 00       	mov    $0x1,%edx
    5968:	4c 89 fe             	mov    %r15,%rsi
    596b:	48 89 df             	mov    %rbx,%rdi
    596e:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5973:	e8 08 d6 ff ff       	call   2f80 <buf_put>
    5978:	e9 9f fe ff ff       	jmp    581c <fwp_write.constprop.0+0x8cc>
    597d:	0f 1f 00             	nopl   (%rax)
    5980:	ba 02 00 00 00       	mov    $0x2,%edx
    5985:	48 8d 35 71 37 00 00 	lea    0x3771(%rip),%rsi        # 90fd <_IO_stdin_used+0xfd>
    598c:	48 89 df             	mov    %rbx,%rdi
    598f:	e8 ec d5 ff ff       	call   2f80 <buf_put>
    5994:	e9 87 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a0:	ba 02 00 00 00       	mov    $0x2,%edx
    59a5:	48 8d 35 5d 37 00 00 	lea    0x375d(%rip),%rsi        # 9109 <_IO_stdin_used+0x109>
    59ac:	48 89 df             	mov    %rbx,%rdi
    59af:	e8 cc d5 ff ff       	call   2f80 <buf_put>
    59b4:	e9 67 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    59b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    59c4:	0f 86 b6 01 00 00    	jbe    5b80 <fwp_write.constprop.0+0xc30>
    59ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    59ce:	0f 84 ac 01 00 00    	je     5b80 <fwp_write.constprop.0+0xc30>
    59d4:	ba 01 00 00 00       	mov    $0x1,%edx
    59d9:	4c 89 fe             	mov    %r15,%rsi
    59dc:	48 89 df             	mov    %rbx,%rdi
    59df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    59e4:	e8 97 d5 ff ff       	call   2f80 <buf_put>
    59e9:	e9 32 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    59ee:	66 90                	xchg   %ax,%ax
    59f0:	ba 02 00 00 00       	mov    $0x2,%edx
    59f5:	48 8d 35 0a 37 00 00 	lea    0x370a(%rip),%rsi        # 9106 <_IO_stdin_used+0x106>
    59fc:	48 89 df             	mov    %rbx,%rdi
    59ff:	e8 7c d5 ff ff       	call   2f80 <buf_put>
    5a04:	e9 17 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a10:	ba 01 00 00 00       	mov    $0x1,%edx
    5a15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a1a:	48 89 df             	mov    %rbx,%rdi
    5a1d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5a22:	e8 59 d5 ff ff       	call   2f80 <buf_put>
    5a27:	e9 b4 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5a34:	48 8b 13             	mov    (%rbx),%rdx
    5a37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5a3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5a40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5a44:	e9 97 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a50:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a55:	ba 01 00 00 00       	mov    $0x1,%edx
    5a5a:	48 89 df             	mov    %rbx,%rdi
    5a5d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5a62:	e8 19 d5 ff ff       	call   2f80 <buf_put>
    5a67:	e9 74 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a70:	ba 01 00 00 00       	mov    $0x1,%edx
    5a75:	4c 89 fe             	mov    %r15,%rsi
    5a78:	48 89 df             	mov    %rbx,%rdi
    5a7b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5a80:	e8 fb d4 ff ff       	call   2f80 <buf_put>
    5a85:	e9 56 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a90:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5a95:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a9a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5a9e:	48 89 f7             	mov    %rsi,%rdi
    5aa1:	48 89 34 24          	mov    %rsi,(%rsp)
    5aa5:	e8 86 c9 ff ff       	call   2430 <strlen@plt>
    5aaa:	48 8b 34 24          	mov    (%rsp),%rsi
    5aae:	48 89 df             	mov    %rbx,%rdi
    5ab1:	48 89 c2             	mov    %rax,%rdx
    5ab4:	e8 c7 d4 ff ff       	call   2f80 <buf_put>
    5ab9:	ba 03 00 00 00       	mov    $0x3,%edx
    5abe:	48 8d 35 7b 36 00 00 	lea    0x367b(%rip),%rsi        # 9140 <_IO_stdin_used+0x140>
    5ac5:	48 89 df             	mov    %rbx,%rdi
    5ac8:	e8 b3 d4 ff ff       	call   2f80 <buf_put>
    5acd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5ad2:	e9 45 f7 ff ff       	jmp    521c <fwp_write.constprop.0+0x2cc>
    5ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ade:	00 00 
    5ae0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ae5:	48 8d 35 31 36 00 00 	lea    0x3631(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    5aec:	48 89 df             	mov    %rbx,%rdi
    5aef:	e8 8c d4 ff ff       	call   2f80 <buf_put>
    5af4:	e9 12 f7 ff ff       	jmp    520b <fwp_write.constprop.0+0x2bb>
    5af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b00:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5b05:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5b09:	48 85 ff             	test   %rdi,%rdi
    5b0c:	0f 84 f9 fc ff ff    	je     580b <fwp_write.constprop.0+0x8bb>
    5b12:	48 8d 35 11 36 00 00 	lea    0x3611(%rip),%rsi        # 912a <_IO_stdin_used+0x12a>
    5b19:	e8 f2 c9 ff ff       	call   2510 <strcmp@plt>
    5b1e:	85 c0                	test   %eax,%eax
    5b20:	0f 95 c0             	setne  %al
    5b23:	0f b6 c0             	movzbl %al,%eax
    5b26:	e9 d8 fc ff ff       	jmp    5803 <fwp_write.constprop.0+0x8b3>
    5b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b30:	31 c0                	xor    %eax,%eax
    5b32:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5b39:	00 
    5b3a:	0f 97 c0             	seta   %al
    5b3d:	e9 c1 fc ff ff       	jmp    5803 <fwp_write.constprop.0+0x8b3>
    5b42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b48:	48 89 df             	mov    %rbx,%rdi
    5b4b:	ba 02 00 00 00       	mov    $0x2,%edx
    5b50:	48 8d 35 d0 35 00 00 	lea    0x35d0(%rip),%rsi        # 9127 <_IO_stdin_used+0x127>
    5b57:	e8 24 d4 ff ff       	call   2f80 <buf_put>
    5b5c:	4c 89 e8             	mov    %r13,%rax
    5b5f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5b64:	48 89 df             	mov    %rbx,%rdi
    5b67:	48 c1 e0 04          	shl    $0x4,%rax
    5b6b:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5b70:	e8 db f3 ff ff       	call   4f50 <fwp_write.constprop.0>
    5b75:	e9 4e f5 ff ff       	jmp    50c8 <fwp_write.constprop.0+0x178>
    5b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b80:	4c 8d 05 85 35 00 00 	lea    0x3585(%rip),%r8        # 910c <_IO_stdin_used+0x10c>
    5b87:	b9 10 00 00 00       	mov    $0x10,%ecx
    5b8c:	31 c0                	xor    %eax,%eax
    5b8e:	ba 02 00 00 00       	mov    $0x2,%edx
    5b93:	be 10 00 00 00       	mov    $0x10,%esi
    5b98:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5b9f:	00 
    5ba0:	e8 eb c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5ba5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5bac:	00 
    5bad:	e8 7e c8 ff ff       	call   2430 <strlen@plt>
    5bb2:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5bb9:	00 
    5bba:	48 89 df             	mov    %rbx,%rdi
    5bbd:	48 89 c2             	mov    %rax,%rdx
    5bc0:	e8 bb d3 ff ff       	call   2f80 <buf_put>
    5bc5:	e9 56 f7 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bd0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5bd5:	48 85 ff             	test   %rdi,%rdi
    5bd8:	79 0c                	jns    5be6 <fwp_write.constprop.0+0xc96>
    5bda:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5be1:	00 
    5be2:	48 03 75 10          	add    0x10(%rbp),%rsi
    5be6:	48 63 3e             	movslq (%rsi),%rdi
    5be9:	83 f9 02             	cmp    $0x2,%ecx
    5bec:	89 fe                	mov    %edi,%esi
    5bee:	48 0f 44 f7          	cmove  %rdi,%rsi
    5bf2:	e9 29 fa ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bfe:	00 00 
    5c00:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5c05:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5c0a:	48 85 ff             	test   %rdi,%rdi
    5c0d:	0f 88 6f 01 00 00    	js     5d82 <fwp_write.constprop.0+0xe32>
    5c13:	49 0f bf 38          	movswq (%r8),%rdi
    5c17:	83 f9 01             	cmp    $0x1,%ecx
    5c1a:	0f b7 f7             	movzwl %di,%esi
    5c1d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c21:	e9 fa f9 ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c2d:	00 00 00 
    5c30:	83 f8 04             	cmp    $0x4,%eax
    5c33:	0f 85 d2 fb ff ff    	jne    580b <fwp_write.constprop.0+0x8bb>
    5c39:	48 8b 04 24          	mov    (%rsp),%rax
    5c3d:	48 8b 40 08          	mov    0x8(%rax),%rax
    5c41:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5c46:	48 c1 e8 3f          	shr    $0x3f,%rax
    5c4a:	e9 e6 fc ff ff       	jmp    5935 <fwp_write.constprop.0+0x9e5>
    5c4f:	90                   	nop
    5c50:	8b 0c 24             	mov    (%rsp),%ecx
    5c53:	31 c0                	xor    %eax,%eax
    5c55:	85 c9                	test   %ecx,%ecx
    5c57:	0f 98 c0             	sets   %al
    5c5a:	e9 d6 fc ff ff       	jmp    5935 <fwp_write.constprop.0+0x9e5>
    5c5f:	90                   	nop
    5c60:	48 f7 d8             	neg    %rax
    5c63:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5c6a:	00 
    5c6b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5c72:	2d 
    5c73:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5c7a:	00 
    5c7b:	48 83 d2 00          	adc    $0x0,%rdx
    5c7f:	48 89 c6             	mov    %rax,%rsi
    5c82:	48 f7 da             	neg    %rdx
    5c85:	e8 76 cd ff ff       	call   2a00 <fwp_fmt_u128>
    5c8a:	e9 31 f3 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5c8f:	90                   	nop
    5c90:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5c95:	e9 b1 f5 ff ff       	jmp    524b <fwp_write.constprop.0+0x2fb>
    5c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ca0:	4c 89 e9             	mov    %r13,%rcx
    5ca3:	48 c1 e1 04          	shl    $0x4,%rcx
    5ca7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5cac:	48 85 ff             	test   %rdi,%rdi
    5caf:	0f 89 6b f9 ff ff    	jns    5620 <fwp_write.constprop.0+0x6d0>
    5cb5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5cb9:	48 89 ce             	mov    %rcx,%rsi
    5cbc:	e9 5f f9 ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cc8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5ccf:	00 
    5cd0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5cd4:	e9 9e f9 ff ff       	jmp    5677 <fwp_write.constprop.0+0x727>
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ce5:	48 8d 35 da 33 00 00 	lea    0x33da(%rip),%rsi        # 90c6 <_IO_stdin_used+0xc6>
    5cec:	e9 8d f7 ff ff       	jmp    547e <fwp_write.constprop.0+0x52e>
    5cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cf8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5cfc:	48 8d 35 bf 33 00 00 	lea    0x33bf(%rip),%rsi        # 90c2 <_IO_stdin_used+0xc2>
    5d03:	48 8d 05 b7 33 00 00 	lea    0x33b7(%rip),%rax        # 90c1 <_IO_stdin_used+0xc1>
    5d0a:	4c 89 e7             	mov    %r12,%rdi
    5d0d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5d11:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d15:	e8 b6 c6 ff ff       	call   23d0 <strcpy@plt>
    5d1a:	e9 a1 f2 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5d1f:	90                   	nop
    5d20:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d24:	48 8d 35 97 33 00 00 	lea    0x3397(%rip),%rsi        # 90c2 <_IO_stdin_used+0xc2>
    5d2b:	48 8d 05 8f 33 00 00 	lea    0x338f(%rip),%rax        # 90c1 <_IO_stdin_used+0xc1>
    5d32:	0f 2f c8             	comiss %xmm0,%xmm1
    5d35:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5d3c:	00 
    5d3d:	4c 89 e7             	mov    %r12,%rdi
    5d40:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d44:	e8 87 c6 ff ff       	call   23d0 <strcpy@plt>
    5d49:	e9 72 f2 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5d4e:	66 90                	xchg   %ax,%ax
    5d50:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5d55:	45 85 c0             	test   %r8d,%r8d
    5d58:	75 34                	jne    5d8e <fwp_write.constprop.0+0xe3e>
    5d5a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5d61:	00 
    5d62:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d69:	00 00 
    5d6b:	0f 85 24 f7 ff ff    	jne    5495 <fwp_write.constprop.0+0x545>
    5d71:	ba 02 00 00 00       	mov    $0x2,%edx
    5d76:	48 8d 35 c0 33 00 00 	lea    0x33c0(%rip),%rsi        # 913d <_IO_stdin_used+0x13d>
    5d7d:	e9 e1 f3 ff ff       	jmp    5163 <fwp_write.constprop.0+0x213>
    5d82:	48 03 75 10          	add    0x10(%rbp),%rsi
    5d86:	49 89 f0             	mov    %rsi,%r8
    5d89:	e9 85 fe ff ff       	jmp    5c13 <fwp_write.constprop.0+0xcc3>
    5d8e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5d93:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5d98:	85 ff                	test   %edi,%edi
    5d9a:	0f 84 3a f4 ff ff    	je     51da <fwp_write.constprop.0+0x28a>
    5da0:	ba 01 00 00 00       	mov    $0x1,%edx
    5da5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5daa:	48 89 df             	mov    %rbx,%rdi
    5dad:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5db2:	e8 c9 d1 ff ff       	call   2f80 <buf_put>
    5db7:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5dbc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5dc1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5dc7:	85 d2                	test   %edx,%edx
    5dc9:	0f 8f 30 f4 ff ff    	jg     51ff <fwp_write.constprop.0+0x2af>
    5dcf:	e9 72 f4 ff ff       	jmp    5246 <fwp_write.constprop.0+0x2f6>
    5dd4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5dd8:	49 89 c5             	mov    %rax,%r13
    5ddb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5de0:	49 89 c4             	mov    %rax,%r12
    5de3:	49 c1 fd 3f          	sar    $0x3f,%r13
    5de7:	4c 09 e8             	or     %r13,%rax
    5dea:	0f 84 a7 00 00 00    	je     5e97 <fwp_write.constprop.0+0xf47>
    5df0:	48 8d 2d 69 4d 00 00 	lea    0x4d69(%rip),%rbp        # ab60 <units.0>
    5df7:	4d 89 e7             	mov    %r12,%r15
    5dfa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5dfe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5e03:	4c 89 ff             	mov    %r15,%rdi
    5e06:	4c 89 ee             	mov    %r13,%rsi
    5e09:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e0d:	48 99                	cqto
    5e0f:	48 89 d1             	mov    %rdx,%rcx
    5e12:	48 89 c2             	mov    %rax,%rdx
    5e15:	e8 76 20 00 00       	call   7e90 <__divmodti4>
    5e1a:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e1e:	48 89 c1             	mov    %rax,%rcx
    5e21:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5e26:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5e2b:	0f 84 94 00 00 00    	je     5ec5 <fwp_write.constprop.0+0xf75>
    5e31:	41 83 c1 01          	add    $0x1,%r9d
    5e35:	48 83 c5 10          	add    $0x10,%rbp
    5e39:	41 83 f9 05          	cmp    $0x5,%r9d
    5e3d:	75 bb                	jne    5dfa <fwp_write.constprop.0+0xeaa>
    5e3f:	4d 85 ed             	test   %r13,%r13
    5e42:	79 53                	jns    5e97 <fwp_write.constprop.0+0xf47>
    5e44:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5e49:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5e4e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5e53:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e58:	48 99                	cqto
    5e5a:	48 f7 d8             	neg    %rax
    5e5d:	48 83 d2 00          	adc    $0x0,%rdx
    5e61:	48 89 c6             	mov    %rax,%rsi
    5e64:	48 f7 da             	neg    %rdx
    5e67:	e8 94 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5e6c:	49 89 e8             	mov    %rbp,%r8
    5e6f:	ba 00 02 00 00       	mov    $0x200,%edx
    5e74:	be 02 00 00 00       	mov    $0x2,%esi
    5e79:	31 c0                	xor    %eax,%eax
    5e7b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5e82:	00 
    5e83:	48 8d 0d ae 32 00 00 	lea    0x32ae(%rip),%rcx        # 9138 <_IO_stdin_used+0x138>
    5e8a:	4c 89 e7             	mov    %r12,%rdi
    5e8d:	e8 0e c8 ff ff       	call   26a0 <__sprintf_chk@plt>
    5e92:	e9 29 f1 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5e97:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e9c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5ea1:	31 d2                	xor    %edx,%edx
    5ea3:	48 89 ef             	mov    %rbp,%rdi
    5ea6:	e8 55 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5eab:	eb bf                	jmp    5e6c <fwp_write.constprop.0+0xf1c>
    5ead:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5eb4:	4e 61 4e 00 
    5eb8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ebf:	00 
    5ec0:	e9 fb f0 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5ec5:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec9:	48 89 c8             	mov    %rcx,%rax
    5ecc:	48 85 d2             	test   %rdx,%rdx
    5ecf:	78 51                	js     5f22 <fwp_write.constprop.0+0xfd2>
    5ed1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5ed6:	48 89 c6             	mov    %rax,%rsi
    5ed9:	48 89 ef             	mov    %rbp,%rdi
    5edc:	e8 1f cb ff ff       	call   2a00 <fwp_fmt_u128>
    5ee1:	44 8b 0c 24          	mov    (%rsp),%r9d
    5ee5:	49 63 c1             	movslq %r9d,%rax
    5ee8:	49 89 e8             	mov    %rbp,%r8
    5eeb:	ba 00 02 00 00       	mov    $0x200,%edx
    5ef0:	be 02 00 00 00       	mov    $0x2,%esi
    5ef5:	48 c1 e0 04          	shl    $0x4,%rax
    5ef9:	48 8d 0d 60 4c 00 00 	lea    0x4c60(%rip),%rcx        # ab60 <units.0>
    5f00:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f07:	00 
    5f08:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5f0c:	4c 89 e7             	mov    %r12,%rdi
    5f0f:	48 8d 0d 1d 32 00 00 	lea    0x321d(%rip),%rcx        # 9133 <_IO_stdin_used+0x133>
    5f16:	31 c0                	xor    %eax,%eax
    5f18:	e8 83 c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f1d:	e9 9e f0 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5f22:	48 f7 d8             	neg    %rax
    5f25:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5f2a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5f2f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f34:	48 83 d2 00          	adc    $0x0,%rdx
    5f38:	48 89 c6             	mov    %rax,%rsi
    5f3b:	48 f7 da             	neg    %rdx
    5f3e:	e8 bd ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f43:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f47:	eb 9c                	jmp    5ee5 <fwp_write.constprop.0+0xf95>
    5f49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005f50 <fwp_main_thread>:
    5f50:	f3 0f 1e fa          	endbr64
    5f54:	41 57                	push   %r15
    5f56:	41 56                	push   %r14
    5f58:	41 55                	push   %r13
    5f5a:	41 54                	push   %r12
    5f5c:	55                   	push   %rbp
    5f5d:	53                   	push   %rbx
    5f5e:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
    5f65:	8b 3d 79 6b 01 00    	mov    0x16b79(%rip),%edi        # 1cae4 <fwp_heap+0x13a4>
    5f6b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5f72:	00 00 
    5f74:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    5f7b:	00 
    5f7c:	31 c0                	xor    %eax,%eax
    5f7e:	85 ff                	test   %edi,%edi
    5f80:	0f 84 f2 0f 00 00    	je     6f78 <fwp_main_thread+0x1028>
    5f86:	8b 35 5c 6b 01 00    	mov    0x16b5c(%rip),%esi        # 1cae8 <fwp_heap+0x13a8>
    5f8c:	85 f6                	test   %esi,%esi
    5f8e:	0f 85 dc 05 00 00    	jne    6570 <fwp_main_thread+0x620>
    5f94:	48 8d ac 24 a0 00 00 	lea    0xa0(%rsp),%rbp
    5f9b:	00 
    5f9c:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5fa3:	00 
    5fa4:	31 f6                	xor    %esi,%esi
    5fa6:	48 c7 05 37 51 01 00 	movq   $0x40000000,0x15137(%rip)        # 1b0e8 <fwp_main_stack_size>
    5fad:	00 00 00 40 
    5fb1:	48 8d 05 28 51 00 00 	lea    0x5128(%rip),%rax        # b0e0 <alt.4>
    5fb8:	48 89 ef             	mov    %rbp,%rdi
    5fbb:	4c 89 25 2e 51 01 00 	mov    %r12,0x1512e(%rip)        # 1b0f0 <fwp_main_stack_top>
    5fc2:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    5fc9:	00 
    5fca:	48 c7 84 24 b0 00 00 	movq   $0x10000,0xb0(%rsp)
    5fd1:	00 00 00 01 00 
    5fd6:	c7 84 24 a8 00 00 00 	movl   $0x0,0xa8(%rsp)
    5fdd:	00 00 00 00 
    5fe1:	e8 9a c6 ff ff       	call   2680 <sigaltstack@plt>
    5fe6:	85 c0                	test   %eax,%eax
    5fe8:	0f 85 52 1e 00 00    	jne    7e40 <fwp_main_thread+0x1ef0>
    5fee:	31 db                	xor    %ebx,%ebx
    5ff0:	b9 12 00 00 00       	mov    $0x12,%ecx
    5ff5:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
    5ffc:	00 
    5ffd:	48 89 d8             	mov    %rbx,%rax
    6000:	4c 8d bc 24 00 01 00 	lea    0x100(%rsp),%r15
    6007:	00 
    6008:	f3 48 ab             	rep stos %rax,(%rdi)
    600b:	48 8d 05 2e cc ff ff 	lea    -0x33d2(%rip),%rax        # 2c40 <fwp_segv>
    6012:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
    6019:	00 
    601a:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
    601f:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
    6026:	00 
    6027:	c7 84 24 88 01 00 00 	movl   $0x8000004,0x188(%rsp)
    602e:	04 00 00 08 
    6032:	e8 19 c5 ff ff       	call   2550 <sigemptyset@plt>
    6037:	85 c0                	test   %eax,%eax
    6039:	0f 85 01 1e 00 00    	jne    7e40 <fwp_main_thread+0x1ef0>
    603f:	31 d2                	xor    %edx,%edx
    6041:	4c 89 fe             	mov    %r15,%rsi
    6044:	bf 0b 00 00 00       	mov    $0xb,%edi
    6049:	e8 92 c3 ff ff       	call   23e0 <sigaction@plt>
    604e:	85 c0                	test   %eax,%eax
    6050:	0f 85 ea 1d 00 00    	jne    7e40 <fwp_main_thread+0x1ef0>
    6056:	31 d2                	xor    %edx,%edx
    6058:	4c 89 fe             	mov    %r15,%rsi
    605b:	bf 07 00 00 00       	mov    $0x7,%edi
    6060:	e8 7b c3 ff ff       	call   23e0 <sigaction@plt>
    6065:	85 c0                	test   %eax,%eax
    6067:	0f 85 d3 1d 00 00    	jne    7e40 <fwp_main_thread+0x1ef0>
    606d:	8b 0d 55 50 00 00    	mov    0x5055(%rip),%ecx        # b0c8 <st.2>
    6073:	85 c9                	test   %ecx,%ecx
    6075:	0f 84 0d 05 00 00    	je     6588 <fwp_main_thread+0x638>
    607b:	48 8b 2d 9e 56 01 00 	mov    0x1569e(%rip),%rbp        # 1b720 <fwp_cur>
    6082:	48 85 ed             	test   %rbp,%rbp
    6085:	0f 84 c5 01 00 00    	je     6250 <fwp_main_thread+0x300>
    608b:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    6090:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    6094:	48 89 eb             	mov    %rbp,%rbx
    6097:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    609c:	0f 84 41 01 00 00    	je     61e3 <fwp_main_thread+0x293>
    60a2:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    60a7:	0f 84 e3 03 00 00    	je     6490 <fwp_main_thread+0x540>
    60ad:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    60b1:	0f 84 b1 03 00 00    	je     6468 <fwp_main_thread+0x518>
    60b7:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    60bb:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    60bf:	0f 85 4b 04 00 00    	jne    6510 <fwp_main_thread+0x5c0>
    60c5:	48 8b 43 60          	mov    0x60(%rbx),%rax
    60c9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    60d0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    60d4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    60db:	00 00 00 00 
    60df:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    60e6:	48 85 d2             	test   %rdx,%rdx
    60e9:	74 07                	je     60f2 <fwp_main_thread+0x1a2>
    60eb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    60f2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    60f6:	48 85 c0             	test   %rax,%rax
    60f9:	74 34                	je     612f <fwp_main_thread+0x1df>
    60fb:	48 89 43 68          	mov    %rax,0x68(%rbx)
    60ff:	48 8b 05 f2 55 01 00 	mov    0x155f2(%rip),%rax        # 1b6f8 <fwp_timers>
    6106:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    610a:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    6111:	00 00 00 00 
    6115:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    611c:	48 85 c0             	test   %rax,%rax
    611f:	74 07                	je     6128 <fwp_main_thread+0x1d8>
    6121:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    6128:	48 89 1d c9 55 01 00 	mov    %rbx,0x155c9(%rip)        # 1b6f8 <fwp_timers>
    612f:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    6133:	e8 98 e9 ff ff       	call   4ad0 <fwp_block>
    6138:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    613f:	48 85 c9             	test   %rcx,%rcx
    6142:	74 47                	je     618b <fwp_main_thread+0x23b>
    6144:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    614b:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    6152:	48 85 d2             	test   %rdx,%rdx
    6155:	0f 84 f5 03 00 00    	je     6550 <fwp_main_thread+0x600>
    615b:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    6162:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    6169:	48 85 c0             	test   %rax,%rax
    616c:	74 07                	je     6175 <fwp_main_thread+0x225>
    616e:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    6175:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    617c:	00 00 00 00 
    6180:	66 0f ef ff          	pxor   %xmm7,%xmm7
    6184:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    618b:	48 8b 0d 8e 55 01 00 	mov    0x1558e(%rip),%rcx        # 1b720 <fwp_cur>
    6192:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    6196:	0f 84 64 03 00 00    	je     6500 <fwp_main_thread+0x5b0>
    619c:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    61a3:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    61aa:	48 85 d2             	test   %rdx,%rdx
    61ad:	0f 84 ad 03 00 00    	je     6560 <fwp_main_thread+0x610>
    61b3:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    61ba:	48 85 c0             	test   %rax,%rax
    61bd:	74 07                	je     61c6 <fwp_main_thread+0x276>
    61bf:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    61c6:	66 0f ef ff          	pxor   %xmm7,%xmm7
    61ca:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    61ce:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    61d5:	48 89 cb             	mov    %rcx,%rbx
    61d8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    61dd:	0f 85 bf fe ff ff    	jne    60a2 <fwp_main_thread+0x152>
    61e3:	48 83 3d c5 71 01 00 	cmpq   $0x0,0x171c5(%rip)        # 1d3b0 <fwp_state_len>
    61ea:	00 
    61eb:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    61ef:	75 0e                	jne    61ff <fwp_main_thread+0x2af>
    61f1:	48 83 3d a7 71 01 00 	cmpq   $0x0,0x171a7(%rip)        # 1d3a0 <fwp_state_owners>
    61f8:	00 
    61f9:	0f 84 20 1a 00 00    	je     7c1f <fwp_main_thread+0x1ccf>
    61ff:	48 39 1d 12 55 01 00 	cmp    %rbx,0x15512(%rip)        # 1b718 <fwp_root>
    6206:	c7 05 d0 4e 01 00 00 	movl   $0x0,0x14ed0(%rip)        # 1b0e0 <fwp_exit_code>
    620d:	00 00 00 
    6210:	0f 85 70 1c 00 00    	jne    7e86 <fwp_main_thread+0x1f36>
    6216:	48 85 db             	test   %rbx,%rbx
    6219:	74 5b                	je     6276 <fwp_main_thread+0x326>
    621b:	48 8b 15 c6 54 01 00 	mov    0x154c6(%rip),%rdx        # 1b6e8 <fwp_tasks_active>
    6222:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    6226:	48 85 d2             	test   %rdx,%rdx
    6229:	74 4b                	je     6276 <fwp_main_thread+0x326>
    622b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6230:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    6234:	75 08                	jne    623e <fwp_main_thread+0x2ee>
    6236:	48 89 d7             	mov    %rdx,%rdi
    6239:	e8 82 cd ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    623e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    6245:	48 85 d2             	test   %rdx,%rdx
    6248:	75 e6                	jne    6230 <fwp_main_thread+0x2e0>
    624a:	e9 e6 01 00 00       	jmp    6435 <fwp_main_thread+0x4e5>
    624f:	90                   	nop
    6250:	48 83 3d 58 71 01 00 	cmpq   $0x0,0x17158(%rip)        # 1d3b0 <fwp_state_len>
    6257:	00 
    6258:	0f 84 2a 18 00 00    	je     7a88 <fwp_main_thread+0x1b38>
    625e:	48 83 3d b2 54 01 00 	cmpq   $0x0,0x154b2(%rip)        # 1b718 <fwp_root>
    6265:	00 
    6266:	c7 05 70 4e 01 00 00 	movl   $0x0,0x14e70(%rip)        # 1b0e0 <fwp_exit_code>
    626d:	00 00 00 
    6270:	0f 85 15 1c 00 00    	jne    7e8b <fwp_main_thread+0x1f3b>
    6276:	e8 45 e6 ff ff       	call   48c0 <fwp_free_zombie>
    627b:	48 83 3d 85 54 01 00 	cmpq   $0x0,0x15485(%rip)        # 1b708 <fwp_ready_head>
    6282:	00 
    6283:	0f 85 82 c4 ff ff    	jne    270b <fwp_main_thread.cold>
    6289:	48 83 3d 67 54 01 00 	cmpq   $0x0,0x15467(%rip)        # 1b6f8 <fwp_timers>
    6290:	00 
    6291:	0f 85 74 c4 ff ff    	jne    270b <fwp_main_thread.cold>
    6297:	8b 05 5f 4e 01 00    	mov    0x14e5f(%rip),%eax        # 1b0fc <fwp_stack_pool_n>
    629d:	85 c0                	test   %eax,%eax
    629f:	74 3c                	je     62dd <fwp_main_thread+0x38d>
    62a1:	83 e8 01             	sub    $0x1,%eax
    62a4:	4c 8d 25 55 4e 01 00 	lea    0x14e55(%rip),%r12        # 1b100 <fwp_stack_pool>
    62ab:	48 63 d8             	movslq %eax,%rbx
    62ae:	89 c0                	mov    %eax,%eax
    62b0:	48 89 da             	mov    %rbx,%rdx
    62b3:	48 29 c2             	sub    %rax,%rdx
    62b6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    62ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62c0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    62c4:	89 1d 32 4e 01 00    	mov    %ebx,0x14e32(%rip)        # 1b0fc <fwp_stack_pool_n>
    62ca:	be 00 00 00 10       	mov    $0x10000000,%esi
    62cf:	48 83 eb 01          	sub    $0x1,%rbx
    62d3:	e8 d8 c2 ff ff       	call   25b0 <munmap@plt>
    62d8:	48 39 dd             	cmp    %rbx,%rbp
    62db:	75 e3                	jne    62c0 <fwp_main_thread+0x370>
    62dd:	8b 3d 7d 4d 00 00    	mov    0x4d7d(%rip),%edi        # b060 <fwp_epfd>
    62e3:	85 ff                	test   %edi,%edi
    62e5:	78 05                	js     62ec <fwp_main_thread+0x39c>
    62e7:	e8 c4 c1 ff ff       	call   24b0 <close@plt>
    62ec:	4c 8b 25 0d 50 01 00 	mov    0x1500d(%rip),%r12        # 1b300 <fwp_nfdws>
    62f3:	48 8b 2d 0e 50 01 00 	mov    0x1500e(%rip),%rbp        # 1b308 <fwp_fdws>
    62fa:	31 db                	xor    %ebx,%ebx
    62fc:	c7 05 5a 4d 00 00 ff 	movl   $0xffffffff,0x4d5a(%rip)        # b060 <fwp_epfd>
    6303:	ff ff ff 
    6306:	4d 85 e4             	test   %r12,%r12
    6309:	74 32                	je     633d <fwp_main_thread+0x3ed>
    630b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6310:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    6315:	48 85 ff             	test   %rdi,%rdi
    6318:	74 1a                	je     6334 <fwp_main_thread+0x3e4>
    631a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    631e:	0f 85 e7 c3 ff ff    	jne    270b <fwp_main_thread.cold>
    6324:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    6329:	0f 85 dc c3 ff ff    	jne    270b <fwp_main_thread.cold>
    632f:	e8 9c dc ff ff       	call   3fd0 <fwp_mem_free>
    6334:	48 83 c3 01          	add    $0x1,%rbx
    6338:	4c 39 e3             	cmp    %r12,%rbx
    633b:	75 d3                	jne    6310 <fwp_main_thread+0x3c0>
    633d:	48 89 ef             	mov    %rbp,%rdi
    6340:	e8 8b dc ff ff       	call   3fd0 <fwp_mem_free>
    6345:	48 8b 15 cc 53 01 00 	mov    0x153cc(%rip),%rdx        # 1b718 <fwp_root>
    634c:	48 c7 05 b1 4f 01 00 	movq   $0x0,0x14fb1(%rip)        # 1b308 <fwp_fdws>
    6353:	00 00 00 00 
    6357:	48 c7 05 9e 4f 01 00 	movq   $0x0,0x14f9e(%rip)        # 1b300 <fwp_nfdws>
    635e:	00 00 00 00 
    6362:	48 85 d2             	test   %rdx,%rdx
    6365:	74 4e                	je     63b5 <fwp_main_thread+0x465>
    6367:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    636c:	0f 85 99 c3 ff ff    	jne    270b <fwp_main_thread.cold>
    6372:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    6379:	00 
    637a:	0f 85 8b c3 ff ff    	jne    270b <fwp_main_thread.cold>
    6380:	48 83 3d 28 70 01 00 	cmpq   $0x0,0x17028(%rip)        # 1d3b0 <fwp_state_len>
    6387:	00 
    6388:	0f 85 7d c3 ff ff    	jne    270b <fwp_main_thread.cold>
    638e:	48 83 3d 0a 70 01 00 	cmpq   $0x0,0x1700a(%rip)        # 1d3a0 <fwp_state_owners>
    6395:	00 
    6396:	0f 85 6f c3 ff ff    	jne    270b <fwp_main_thread.cold>
    639c:	b9 79 00 00 00       	mov    $0x79,%ecx
    63a1:	31 c0                	xor    %eax,%eax
    63a3:	48 8d 3d 76 4f 01 00 	lea    0x14f76(%rip),%rdi        # 1b320 <fwp_root_context>
    63aa:	f3 48 ab             	rep stos %rax,(%rdi)
    63ad:	48 89 d7             	mov    %rdx,%rdi
    63b0:	e8 1b dc ff ff       	call   3fd0 <fwp_mem_free>
    63b5:	48 8b 3d c4 4c 00 00 	mov    0x4cc4(%rip),%rdi        # b080 <stdout@GLIBC_2.2.5>
    63bc:	48 c7 05 59 53 01 00 	movq   $0x0,0x15359(%rip)        # 1b720 <fwp_cur>
    63c3:	00 00 00 00 
    63c7:	48 c7 05 46 53 01 00 	movq   $0x0,0x15346(%rip)        # 1b718 <fwp_root>
    63ce:	00 00 00 00 
    63d2:	e8 b9 c1 ff ff       	call   2590 <fflush@plt>
    63d7:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
    63de:	00 
    63df:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    63e6:	00 00 
    63e8:	0f 85 87 1a 00 00    	jne    7e75 <fwp_main_thread+0x1f25>
    63ee:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
    63f5:	31 c0                	xor    %eax,%eax
    63f7:	5b                   	pop    %rbx
    63f8:	5d                   	pop    %rbp
    63f9:	41 5c                	pop    %r12
    63fb:	41 5d                	pop    %r13
    63fd:	41 5e                	pop    %r14
    63ff:	41 5f                	pop    %r15
    6401:	c3                   	ret
    6402:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6408:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    640f:	48 89 1d ea 52 01 00 	mov    %rbx,0x152ea(%rip)        # 1b700 <fwp_ready_tail>
    6416:	e8 b5 e6 ff ff       	call   4ad0 <fwp_block>
    641b:	e8 a0 e4 ff ff       	call   48c0 <fwp_free_zombie>
    6420:	48 83 3d c0 52 01 00 	cmpq   $0x0,0x152c0(%rip)        # 1b6e8 <fwp_tasks_active>
    6427:	00 
    6428:	0f 84 48 fe ff ff    	je     6276 <fwp_main_thread+0x326>
    642e:	48 8b 1d e3 52 01 00 	mov    0x152e3(%rip),%rbx        # 1b718 <fwp_root>
    6435:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    6439:	75 db                	jne    6416 <fwp_main_thread+0x4c6>
    643b:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    643f:	75 d5                	jne    6416 <fwp_main_thread+0x4c6>
    6441:	48 8b 05 b8 52 01 00 	mov    0x152b8(%rip),%rax        # 1b700 <fwp_ready_tail>
    6448:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    644c:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    6453:	00 00 00 00 
    6457:	48 85 c0             	test   %rax,%rax
    645a:	75 ac                	jne    6408 <fwp_main_thread+0x4b8>
    645c:	48 89 1d a5 52 01 00 	mov    %rbx,0x152a5(%rip)        # 1b708 <fwp_ready_head>
    6463:	eb aa                	jmp    640f <fwp_main_thread+0x4bf>
    6465:	0f 1f 00             	nopl   (%rax)
    6468:	e8 73 cc ff ff       	call   30e0 <fwp_now_ns>
    646d:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    6471:	7c 1d                	jl     6490 <fwp_main_thread+0x540>
    6473:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    6477:	75 17                	jne    6490 <fwp_main_thread+0x540>
    6479:	48 89 ef             	mov    %rbp,%rdi
    647c:	e8 3f cb ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    6481:	0f 1f 40 00          	nopl   0x0(%rax)
    6485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    648c:	00 00 00 00 
    6490:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    6494:	0f 85 1d fc ff ff    	jne    60b7 <fwp_main_thread+0x167>
    649a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    649e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    64a2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    64a6:	0f 85 1d fc ff ff    	jne    60c9 <fwp_main_thread+0x179>
    64ac:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    64b0:	48 85 c9             	test   %rcx,%rcx
    64b3:	0f 84 10 fc ff ff    	je     60c9 <fwp_main_thread+0x179>
    64b9:	48 39 c8             	cmp    %rcx,%rax
    64bc:	48 89 ce             	mov    %rcx,%rsi
    64bf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    64c6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    64ca:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    64d1:	00 00 00 00 
    64d5:	48 0f 4e f0          	cmovle %rax,%rsi
    64d9:	48 85 c0             	test   %rax,%rax
    64dc:	48 89 c8             	mov    %rcx,%rax
    64df:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    64e6:	48 0f 45 c6          	cmovne %rsi,%rax
    64ea:	48 85 d2             	test   %rdx,%rdx
    64ed:	74 07                	je     64f6 <fwp_main_thread+0x5a6>
    64ef:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    64f6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    64fa:	e9 fc fb ff ff       	jmp    60fb <fwp_main_thread+0x1ab>
    64ff:	90                   	nop
    6500:	48 89 cb             	mov    %rcx,%rbx
    6503:	e9 8f fb ff ff       	jmp    6097 <fwp_main_thread+0x147>
    6508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    650f:	00 
    6510:	48 8b 45 40          	mov    0x40(%rbp),%rax
    6514:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    651b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    6522:	00 00 00 00 
    6526:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    652d:	48 85 c0             	test   %rax,%rax
    6530:	0f 84 18 15 00 00    	je     7a4e <fwp_main_thread+0x1afe>
    6536:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    653d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    6541:	e9 e9 fb ff ff       	jmp    612f <fwp_main_thread+0x1df>
    6546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    654d:	00 00 00 
    6550:	48 89 01             	mov    %rax,(%rcx)
    6553:	e9 11 fc ff ff       	jmp    6169 <fwp_main_thread+0x219>
    6558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    655f:	00 
    6560:	48 89 05 91 51 01 00 	mov    %rax,0x15191(%rip)        # 1b6f8 <fwp_timers>
    6567:	e9 4e fc ff ff       	jmp    61ba <fwp_main_thread+0x26a>
    656c:	0f 1f 40 00          	nopl   0x0(%rax)
    6570:	48 8d 3d 69 d1 ff ff 	lea    -0x2e97(%rip),%rdi        # 36e0 <fwp_heap_report>
    6577:	e8 24 1b 00 00       	call   80a0 <atexit>
    657c:	e9 13 fa ff ff       	jmp    5f94 <fwp_main_thread+0x44>
    6581:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6588:	48 8d 05 61 e8 ff ff 	lea    -0x179f(%rip),%rax        # 4df0 <fwp_drop1>
    658f:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6594:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
    659b:	00 00 00 00 00 
    65a0:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    65a5:	66 48 0f 6e f8       	movq   %rax,%xmm7
    65aa:	48 8b 05 1f 6e 01 00 	mov    0x16e1f(%rip),%rax        # 1d3d0 <fwp_cleanups>
    65b1:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
    65b8:	00 
    65b9:	45 31 f6             	xor    %r14d,%r14d
    65bc:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    65c0:	4c 89 25 09 6e 01 00 	mov    %r12,0x16e09(%rip)        # 1d3d0 <fwp_cleanups>
    65c7:	4c 8d 2d 72 51 01 00 	lea    0x15172(%rip),%r13        # 1b740 <fwp_heap>
    65ce:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
    65d3:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    65da:	00 
    65db:	48 8d 05 ae c5 ff ff 	lea    -0x3a52(%rip),%rax        # 2b90 <fwp_range_release>
    65e2:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    65e9:	00 
    65ea:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    65f1:	00 
    65f2:	eb 42                	jmp    6636 <fwp_main_thread+0x6e6>
    65f4:	0f 1f 40 00          	nopl   0x0(%rax)
    65f8:	80 f9 01             	cmp    $0x1,%cl
    65fb:	75 27                	jne    6624 <fwp_main_thread+0x6d4>
    65fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6600:	0f b7 c0             	movzwl %ax,%eax
    6603:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6606:	48 0f af c1          	imul   %rcx,%rax
    660a:	48 c1 e8 20          	shr    $0x20,%rax
    660e:	48 39 d0             	cmp    %rdx,%rax
    6611:	73 11                	jae    6624 <fwp_main_thread+0x6d4>
    6613:	49 01 c7             	add    %rax,%r15
    6616:	41 80 3f ff          	cmpb   $0xff,(%r15)
    661a:	0f 84 99 14 00 00    	je     7ab9 <fwp_main_thread+0x1b69>
    6620:	41 c6 07 01          	movb   $0x1,(%r15)
    6624:	4c 89 b4 24 a0 00 00 	mov    %r14,0xa0(%rsp)
    662b:	00 
    662c:	48 83 eb 01          	sub    $0x1,%rbx
    6630:	0f 82 8a 00 00 00    	jb     66c0 <fwp_main_thread+0x770>
    6636:	4c 89 e6             	mov    %r12,%rsi
    6639:	bf 01 00 00 00       	mov    $0x1,%edi
    663e:	4c 89 b4 24 08 01 00 	mov    %r14,0x108(%rsp)
    6645:	00 
    6646:	48 89 9c 24 a8 00 00 	mov    %rbx,0xa8(%rsp)
    664d:	00 
    664e:	48 89 9c 24 00 01 00 	mov    %rbx,0x100(%rsp)
    6655:	00 
    6656:	e8 15 e0 ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    665b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6662:	49 89 c6             	mov    %rax,%r14
    6665:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    666c:	48 c1 e2 10          	shl    $0x10,%rdx
    6670:	48 39 d0             	cmp    %rdx,%rax
    6673:	73 af                	jae    6624 <fwp_main_thread+0x6d4>
    6675:	48 89 c2             	mov    %rax,%rdx
    6678:	48 c1 ea 10          	shr    $0x10,%rdx
    667c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6680:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6687:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    668b:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    668f:	4d 85 ff             	test   %r15,%r15
    6692:	74 90                	je     6624 <fwp_main_thread+0x6d4>
    6694:	0f b6 0a             	movzbl (%rdx),%ecx
    6697:	80 f9 02             	cmp    $0x2,%cl
    669a:	0f 85 58 ff ff ff    	jne    65f8 <fwp_main_thread+0x6a8>
    66a0:	66 85 c0             	test   %ax,%ax
    66a3:	0f 84 6d ff ff ff    	je     6616 <fwp_main_thread+0x6c6>
    66a9:	4c 89 b4 24 a0 00 00 	mov    %r14,0xa0(%rsp)
    66b0:	00 
    66b1:	48 83 eb 01          	sub    $0x1,%rbx
    66b5:	0f 83 7b ff ff ff    	jae    6636 <fwp_main_thread+0x6e6>
    66bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    66c0:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    66c7:	00 
    66c8:	66 0f 6f 05 00 2e 00 	movdqa 0x2e00(%rip),%xmm0        # 94d0 <msg.3+0x90>
    66cf:	00 
    66d0:	bf 01 00 00 00       	mov    $0x1,%edi
    66d5:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    66dc:	00 
    66dd:	48 89 05 ec 6c 01 00 	mov    %rax,0x16cec(%rip)        # 1d3d0 <fwp_cleanups>
    66e4:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    66eb:	00 
    66ec:	e8 7f df ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    66f1:	48 8b 15 20 64 01 00 	mov    0x16420(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    66f8:	49 89 c4             	mov    %rax,%r12
    66fb:	48 2b 05 ee 63 01 00 	sub    0x163ee(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    6702:	48 c1 e2 10          	shl    $0x10,%rdx
    6706:	48 39 d0             	cmp    %rdx,%rax
    6709:	73 55                	jae    6760 <fwp_main_thread+0x810>
    670b:	48 89 c2             	mov    %rax,%rdx
    670e:	48 c1 ea 10          	shr    $0x10,%rdx
    6712:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6716:	48 8b 15 1b 64 01 00 	mov    0x1641b(%rip),%rdx        # 1cb38 <fwp_heap+0x13f8>
    671d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6721:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6725:	48 85 db             	test   %rbx,%rbx
    6728:	74 36                	je     6760 <fwp_main_thread+0x810>
    672a:	0f b6 0a             	movzbl (%rdx),%ecx
    672d:	80 f9 02             	cmp    $0x2,%cl
    6730:	0f 84 59 13 00 00    	je     7a8f <fwp_main_thread+0x1b3f>
    6736:	80 f9 01             	cmp    $0x1,%cl
    6739:	75 25                	jne    6760 <fwp_main_thread+0x810>
    673b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    673e:	0f b7 c0             	movzwl %ax,%eax
    6741:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6744:	48 0f af c1          	imul   %rcx,%rax
    6748:	48 c1 e8 20          	shr    $0x20,%rax
    674c:	48 39 d0             	cmp    %rdx,%rax
    674f:	73 0f                	jae    6760 <fwp_main_thread+0x810>
    6751:	48 01 c3             	add    %rax,%rbx
    6754:	80 3b ff             	cmpb   $0xff,(%rbx)
    6757:	0f 84 90 16 00 00    	je     7ded <fwp_main_thread+0x1e9d>
    675d:	c6 03 01             	movb   $0x1,(%rbx)
    6760:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    6767:	00 f0 3f 
    676a:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    6771:	00 
    6772:	bf 01 00 00 00       	mov    $0x1,%edi
    6777:	4c 89 a4 24 d8 00 00 	mov    %r12,0xd8(%rsp)
    677e:	00 
    677f:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    6786:	00 
    6787:	e8 e4 de ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    678c:	48 8b 15 85 63 01 00 	mov    0x16385(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    6793:	49 89 c4             	mov    %rax,%r12
    6796:	48 2b 05 53 63 01 00 	sub    0x16353(%rip),%rax        # 1caf0 <fwp_heap+0x13b0>
    679d:	48 c1 e2 10          	shl    $0x10,%rdx
    67a1:	48 39 d0             	cmp    %rdx,%rax
    67a4:	73 55                	jae    67fb <fwp_main_thread+0x8ab>
    67a6:	48 89 c2             	mov    %rax,%rdx
    67a9:	48 c1 ea 10          	shr    $0x10,%rdx
    67ad:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67b1:	48 8b 15 80 63 01 00 	mov    0x16380(%rip),%rdx        # 1cb38 <fwp_heap+0x13f8>
    67b8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    67bc:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    67c0:	48 85 db             	test   %rbx,%rbx
    67c3:	74 36                	je     67fb <fwp_main_thread+0x8ab>
    67c5:	0f b6 0a             	movzbl (%rdx),%ecx
    67c8:	80 f9 02             	cmp    $0x2,%cl
    67cb:	0f 84 da 12 00 00    	je     7aab <fwp_main_thread+0x1b5b>
    67d1:	80 f9 01             	cmp    $0x1,%cl
    67d4:	75 25                	jne    67fb <fwp_main_thread+0x8ab>
    67d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    67d9:	0f b7 c0             	movzwl %ax,%eax
    67dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67df:	48 0f af c1          	imul   %rcx,%rax
    67e3:	48 c1 e8 20          	shr    $0x20,%rax
    67e7:	48 39 d0             	cmp    %rdx,%rax
    67ea:	73 0f                	jae    67fb <fwp_main_thread+0x8ab>
    67ec:	48 01 c3             	add    %rax,%rbx
    67ef:	80 3b ff             	cmpb   $0xff,(%rbx)
    67f2:	0f 84 02 16 00 00    	je     7dfa <fwp_main_thread+0x1eaa>
    67f8:	c6 03 01             	movb   $0x1,(%rbx)
    67fb:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    6802:	33 f3 bf 
    6805:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    680c:	00 
    680d:	bf 01 00 00 00       	mov    $0x1,%edi
    6812:	4c 89 a4 24 c8 00 00 	mov    %r12,0xc8(%rsp)
    6819:	00 
    681a:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    6821:	00 
    6822:	e8 49 de ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6827:	48 8b 15 ea 62 01 00 	mov    0x162ea(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    682e:	48 8b 0d bb 62 01 00 	mov    0x162bb(%rip),%rcx        # 1caf0 <fwp_heap+0x13b0>
    6835:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    683a:	48 89 d6             	mov    %rdx,%rsi
    683d:	48 29 c8             	sub    %rcx,%rax
    6840:	48 c1 e6 10          	shl    $0x10,%rsi
    6844:	48 39 f0             	cmp    %rsi,%rax
    6847:	73 65                	jae    68ae <fwp_main_thread+0x95e>
    6849:	48 89 c6             	mov    %rax,%rsi
    684c:	48 c1 ee 10          	shr    $0x10,%rsi
    6850:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6854:	48 8b 35 dd 62 01 00 	mov    0x162dd(%rip),%rsi        # 1cb38 <fwp_heap+0x13f8>
    685b:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    685f:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    6863:	48 85 db             	test   %rbx,%rbx
    6866:	74 46                	je     68ae <fwp_main_thread+0x95e>
    6868:	0f b6 3e             	movzbl (%rsi),%edi
    686b:	40 80 ff 02          	cmp    $0x2,%dil
    686f:	0f 84 28 12 00 00    	je     7a9d <fwp_main_thread+0x1b4d>
    6875:	40 80 ff 01          	cmp    $0x1,%dil
    6879:	75 33                	jne    68ae <fwp_main_thread+0x95e>
    687b:	8b 7e 18             	mov    0x18(%rsi),%edi
    687e:	0f b7 c0             	movzwl %ax,%eax
    6881:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6884:	48 0f af c7          	imul   %rdi,%rax
    6888:	48 c1 e8 20          	shr    $0x20,%rax
    688c:	48 39 f0             	cmp    %rsi,%rax
    688f:	73 1d                	jae    68ae <fwp_main_thread+0x95e>
    6891:	48 01 c3             	add    %rax,%rbx
    6894:	80 3b ff             	cmpb   $0xff,(%rbx)
    6897:	0f 84 43 15 00 00    	je     7de0 <fwp_main_thread+0x1e90>
    689d:	c6 03 01             	movb   $0x1,(%rbx)
    68a0:	48 8b 0d 49 62 01 00 	mov    0x16249(%rip),%rcx        # 1caf0 <fwp_heap+0x13b0>
    68a7:	48 8b 15 6a 62 01 00 	mov    0x1626a(%rip),%rdx        # 1cb18 <fwp_heap+0x13d8>
    68ae:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    68b3:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    68b8:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    68bd:	0f 1f 00             	nopl   (%rax)
    68c0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    68c5:	48 c1 e2 10          	shl    $0x10,%rdx
    68c9:	48 29 c8             	sub    %rcx,%rax
    68cc:	48 39 d0             	cmp    %rdx,%rax
    68cf:	73 5d                	jae    692e <fwp_main_thread+0x9de>
    68d1:	48 89 c2             	mov    %rax,%rdx
    68d4:	48 c1 ea 10          	shr    $0x10,%rdx
    68d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68dc:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    68e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    68e7:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    68eb:	48 85 db             	test   %rbx,%rbx
    68ee:	74 3e                	je     692e <fwp_main_thread+0x9de>
    68f0:	0f b6 0a             	movzbl (%rdx),%ecx
    68f3:	80 f9 02             	cmp    $0x2,%cl
    68f6:	0f 84 d4 10 00 00    	je     79d0 <fwp_main_thread+0x1a80>
    68fc:	80 f9 01             	cmp    $0x1,%cl
    68ff:	75 2d                	jne    692e <fwp_main_thread+0x9de>
    6901:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6904:	0f b7 c0             	movzwl %ax,%eax
    6907:	8b 52 1c             	mov    0x1c(%rdx),%edx
    690a:	48 0f af c1          	imul   %rcx,%rax
    690e:	48 c1 e8 20          	shr    $0x20,%rax
    6912:	48 39 d0             	cmp    %rdx,%rax
    6915:	73 17                	jae    692e <fwp_main_thread+0x9de>
    6917:	48 01 c3             	add    %rax,%rbx
    691a:	0f b6 03             	movzbl (%rbx),%eax
    691d:	84 c0                	test   %al,%al
    691f:	74 0d                	je     692e <fwp_main_thread+0x9de>
    6921:	3c fd                	cmp    $0xfd,%al
    6923:	0f 87 d5 13 00 00    	ja     7cfe <fwp_main_thread+0x1dae>
    6929:	83 c0 01             	add    $0x1,%eax
    692c:	88 03                	mov    %al,(%rbx)
    692e:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
    6933:	31 ff                	xor    %edi,%edi
    6935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    693c:	00 00 00 00 
    6940:	4d 8b 76 10          	mov    0x10(%r14),%r14
    6944:	48 83 c7 01          	add    $0x1,%rdi
    6948:	4d 85 f6             	test   %r14,%r14
    694b:	75 f3                	jne    6940 <fwp_main_thread+0x9f0>
    694d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    6954:	ff ff 1f 
    6957:	48 39 f8             	cmp    %rdi,%rax
    695a:	0f 82 b3 14 00 00    	jb     7e13 <fwp_main_thread+0x1ec3>
    6960:	e8 3b de ff ff       	call   47a0 <fwp_array_new_packed.constprop.0>
    6965:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    696c:	48 89 c5             	mov    %rax,%rbp
    696f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6976:	48 c1 e2 10          	shl    $0x10,%rdx
    697a:	48 39 d0             	cmp    %rdx,%rax
    697d:	73 55                	jae    69d4 <fwp_main_thread+0xa84>
    697f:	48 89 c2             	mov    %rax,%rdx
    6982:	48 c1 ea 10          	shr    $0x10,%rdx
    6986:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    698a:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6991:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6995:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6999:	48 85 db             	test   %rbx,%rbx
    699c:	74 36                	je     69d4 <fwp_main_thread+0xa84>
    699e:	0f b6 0a             	movzbl (%rdx),%ecx
    69a1:	80 f9 02             	cmp    $0x2,%cl
    69a4:	0f 84 36 10 00 00    	je     79e0 <fwp_main_thread+0x1a90>
    69aa:	80 f9 01             	cmp    $0x1,%cl
    69ad:	75 25                	jne    69d4 <fwp_main_thread+0xa84>
    69af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69b2:	0f b7 c0             	movzwl %ax,%eax
    69b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69b8:	48 0f af c1          	imul   %rcx,%rax
    69bc:	48 c1 e8 20          	shr    $0x20,%rax
    69c0:	48 39 d0             	cmp    %rdx,%rax
    69c3:	73 0f                	jae    69d4 <fwp_main_thread+0xa84>
    69c5:	48 01 c3             	add    %rax,%rbx
    69c8:	80 3b ff             	cmpb   $0xff,(%rbx)
    69cb:	0f 84 21 10 00 00    	je     79f2 <fwp_main_thread+0x1aa2>
    69d1:	c6 03 01             	movb   $0x1,(%rbx)
    69d4:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    69d9:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    69df:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    69e3:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    69e7:	49 89 d2             	mov    %rdx,%r10
    69ea:	49 89 d1             	mov    %rdx,%r9
    69ed:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    69f4:	48 89 d0             	mov    %rdx,%rax
    69f7:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    69fe:	48 c1 e6 10          	shl    $0x10,%rsi
    6a02:	48 39 f0             	cmp    %rsi,%rax
    6a05:	73 65                	jae    6a6c <fwp_main_thread+0xb1c>
    6a07:	48 89 c6             	mov    %rax,%rsi
    6a0a:	48 c1 ee 10          	shr    $0x10,%rsi
    6a0e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6a12:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    6a19:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6a1d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    6a21:	48 85 ff             	test   %rdi,%rdi
    6a24:	74 46                	je     6a6c <fwp_main_thread+0xb1c>
    6a26:	44 0f b6 06          	movzbl (%rsi),%r8d
    6a2a:	41 80 f8 02          	cmp    $0x2,%r8b
    6a2e:	0f 84 dc 0c 00 00    	je     7710 <fwp_main_thread+0x17c0>
    6a34:	41 80 f8 01          	cmp    $0x1,%r8b
    6a38:	75 32                	jne    6a6c <fwp_main_thread+0xb1c>
    6a3a:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    6a3e:	0f b7 c0             	movzwl %ax,%eax
    6a41:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6a44:	49 0f af c0          	imul   %r8,%rax
    6a48:	48 c1 e8 20          	shr    $0x20,%rax
    6a4c:	48 39 f0             	cmp    %rsi,%rax
    6a4f:	73 1b                	jae    6a6c <fwp_main_thread+0xb1c>
    6a51:	48 01 c7             	add    %rax,%rdi
    6a54:	80 3f 01             	cmpb   $0x1,(%rdi)
    6a57:	75 13                	jne    6a6c <fwp_main_thread+0xb1c>
    6a59:	e9 62 0b 00 00       	jmp    75c0 <fwp_main_thread+0x1670>
    6a5e:	66 90                	xchg   %ax,%ax
    6a60:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    6a64:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    6a68:	49 83 c4 01          	add    $0x1,%r12
    6a6c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6a71:	0f 88 90 13 00 00    	js     7e07 <fwp_main_thread+0x1eb7>
    6a77:	4a 89 4c e5 00       	mov    %rcx,0x0(%rbp,%r12,8)
    6a7c:	48 85 db             	test   %rbx,%rbx
    6a7f:	75 df                	jne    6a60 <fwp_main_thread+0xb10>
    6a81:	4c 89 cf             	mov    %r9,%rdi
    6a84:	e8 f7 e1 ff ff       	call   4c80 <fwp_drop0>
    6a89:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    6a90:	ff ff 7f 
    6a93:	48 23 45 00          	and    0x0(%rbp),%rax
    6a97:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6a9c:	48 89 c3             	mov    %rax,%rbx
    6a9f:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    6aa6:	ff ff 1f 
    6aa9:	48 39 d8             	cmp    %rbx,%rax
    6aac:	0f 82 61 13 00 00    	jb     7e13 <fwp_main_thread+0x1ec3>
    6ab2:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    6ab7:	e8 e4 dc ff ff       	call   47a0 <fwp_array_new_packed.constprop.0>
    6abc:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6ac3:	49 89 c4             	mov    %rax,%r12
    6ac6:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6acd:	48 c1 e2 10          	shl    $0x10,%rdx
    6ad1:	48 39 d0             	cmp    %rdx,%rax
    6ad4:	73 55                	jae    6b2b <fwp_main_thread+0xbdb>
    6ad6:	48 89 c2             	mov    %rax,%rdx
    6ad9:	48 c1 ea 10          	shr    $0x10,%rdx
    6add:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ae1:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6ae8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6aec:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6af0:	48 85 db             	test   %rbx,%rbx
    6af3:	74 36                	je     6b2b <fwp_main_thread+0xbdb>
    6af5:	0f b6 0a             	movzbl (%rdx),%ecx
    6af8:	80 f9 02             	cmp    $0x2,%cl
    6afb:	0f 84 ef 0c 00 00    	je     77f0 <fwp_main_thread+0x18a0>
    6b01:	80 f9 01             	cmp    $0x1,%cl
    6b04:	75 25                	jne    6b2b <fwp_main_thread+0xbdb>
    6b06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b09:	0f b7 c0             	movzwl %ax,%eax
    6b0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b0f:	48 0f af c1          	imul   %rcx,%rax
    6b13:	48 c1 e8 20          	shr    $0x20,%rax
    6b17:	48 39 d0             	cmp    %rdx,%rax
    6b1a:	73 0f                	jae    6b2b <fwp_main_thread+0xbdb>
    6b1c:	48 01 c3             	add    %rax,%rbx
    6b1f:	80 3b ff             	cmpb   $0xff,(%rbx)
    6b22:	0f 84 da 0c 00 00    	je     7802 <fwp_main_thread+0x18b2>
    6b28:	c6 03 01             	movb   $0x1,(%rbx)
    6b2b:	31 db                	xor    %ebx,%ebx
    6b2d:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    6b33:	0f 84 dc 05 00 00    	je     7115 <fwp_main_thread+0x11c5>
    6b39:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    6b3e:	41 be 08 00 00 00    	mov    $0x8,%r14d
    6b44:	e9 0b 04 00 00       	jmp    6f54 <fwp_main_thread+0x1004>
    6b49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b50:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
    6b54:	48 85 d2             	test   %rdx,%rdx
    6b57:	0f 88 a3 0b 00 00    	js     7700 <fwp_main_thread+0x17b0>
    6b5d:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6b64:	00 00 
    6b66:	48 8b 3c d9          	mov    (%rcx,%rbx,8),%rdi
    6b6a:	48 89 3c 24          	mov    %rdi,(%rsp)
    6b6e:	48 85 db             	test   %rbx,%rbx
    6b71:	74 72                	je     6be5 <fwp_main_thread+0xc95>
    6b73:	f2 42 0f 10 54 31 f0 	movsd  -0x10(%rcx,%r14,1),%xmm2
    6b7a:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6b7f:	66 0f ef e4          	pxor   %xmm4,%xmm4
    6b83:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6b87:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6b8b:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6b8f:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6b93:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
    6b97:	66 0f 28 d8          	movapd %xmm0,%xmm3
    6b9b:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
    6b9f:	f2 0f 10 05 41 29 00 	movsd  0x2941(%rip),%xmm0        # 94e8 <msg.3+0xa8>
    6ba6:	00 
    6ba7:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    6bab:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6baf:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6bb3:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6bb7:	f2 0f 59 05 31 29 00 	mulsd  0x2931(%rip),%xmm0        # 94f0 <msg.3+0xb0>
    6bbe:	00 
    6bbf:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6bc3:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6bc7:	f2 0f 10 0d 19 29 00 	movsd  0x2919(%rip),%xmm1        # 94e8 <msg.3+0xa8>
    6bce:	00 
    6bcf:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    6bd3:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6bd7:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6bdb:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6bdf:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6be5:	48 83 c3 01          	add    $0x1,%rbx
    6be9:	48 39 d8             	cmp    %rbx,%rax
    6bec:	0f 84 be 03 00 00    	je     6fb0 <fwp_main_thread+0x1060>
    6bf2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    6bf9:	00 f0 3f 
    6bfc:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    6c01:	31 ff                	xor    %edi,%edi
    6c03:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
    6c0a:	00 
    6c0b:	48 8b 04 24          	mov    (%rsp),%rax
    6c0f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    6c16:	00 
    6c17:	e8 54 da ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6c1c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6c23:	49 89 c7             	mov    %rax,%r15
    6c26:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6c2d:	48 c1 e2 10          	shl    $0x10,%rdx
    6c31:	48 39 d0             	cmp    %rdx,%rax
    6c34:	73 57                	jae    6c8d <fwp_main_thread+0xd3d>
    6c36:	48 89 c2             	mov    %rax,%rdx
    6c39:	48 c1 ea 10          	shr    $0x10,%rdx
    6c3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c41:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6c48:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c4c:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c50:	48 85 d2             	test   %rdx,%rdx
    6c53:	74 38                	je     6c8d <fwp_main_thread+0xd3d>
    6c55:	0f b6 31             	movzbl (%rcx),%esi
    6c58:	40 80 fe 02          	cmp    $0x2,%sil
    6c5c:	0f 84 3e 04 00 00    	je     70a0 <fwp_main_thread+0x1150>
    6c62:	40 80 fe 01          	cmp    $0x1,%sil
    6c66:	75 25                	jne    6c8d <fwp_main_thread+0xd3d>
    6c68:	8b 71 18             	mov    0x18(%rcx),%esi
    6c6b:	0f b7 c0             	movzwl %ax,%eax
    6c6e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c71:	48 0f af c6          	imul   %rsi,%rax
    6c75:	48 c1 e8 20          	shr    $0x20,%rax
    6c79:	48 39 c8             	cmp    %rcx,%rax
    6c7c:	73 0f                	jae    6c8d <fwp_main_thread+0xd3d>
    6c7e:	48 01 c2             	add    %rax,%rdx
    6c81:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c84:	0f 84 36 04 00 00    	je     70c0 <fwp_main_thread+0x1170>
    6c8a:	c6 02 01             	movb   $0x1,(%rdx)
    6c8d:	48 8b 45 00          	mov    0x0(%rbp),%rax
    6c91:	48 89 c2             	mov    %rax,%rdx
    6c94:	48 0f ba f2 3f       	btr    $0x3f,%rdx
    6c99:	48 39 d3             	cmp    %rdx,%rbx
    6c9c:	0f 83 c7 02 00 00    	jae    6f69 <fwp_main_thread+0x1019>
    6ca2:	48 8d 55 08          	lea    0x8(%rbp),%rdx
    6ca6:	48 85 c0             	test   %rax,%rax
    6ca9:	0f 88 71 0a 00 00    	js     7720 <fwp_main_thread+0x17d0>
    6caf:	4a 8b 04 32          	mov    (%rdx,%r14,1),%rax
    6cb3:	31 ff                	xor    %edi,%edi
    6cb5:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    6cbc:	00 
    6cbd:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
    6cc4:	00 00 00 00 00 
    6cc9:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    6cd0:	00 
    6cd1:	e8 9a d9 ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6cd6:	49 8b bd b0 13 00 00 	mov    0x13b0(%r13),%rdi
    6cdd:	48 89 c2             	mov    %rax,%rdx
    6ce0:	48 89 c6             	mov    %rax,%rsi
    6ce3:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    6cea:	48 29 fa             	sub    %rdi,%rdx
    6ced:	48 c1 e0 10          	shl    $0x10,%rax
    6cf1:	48 39 c2             	cmp    %rax,%rdx
    6cf4:	0f 83 8e 02 00 00    	jae    6f88 <fwp_main_thread+0x1038>
    6cfa:	48 89 d1             	mov    %rdx,%rcx
    6cfd:	48 c1 e9 10          	shr    $0x10,%rcx
    6d01:	4c 8d 0c 89          	lea    (%rcx,%rcx,4),%r9
    6d05:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    6d0c:	4e 8d 14 c9          	lea    (%rcx,%r9,8),%r10
    6d10:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    6d14:	4d 85 c9             	test   %r9,%r9
    6d17:	0f 84 64 03 00 00    	je     7081 <fwp_main_thread+0x1131>
    6d1d:	41 0f b6 0a          	movzbl (%r10),%ecx
    6d21:	80 f9 02             	cmp    $0x2,%cl
    6d24:	0f 84 4e 03 00 00    	je     7078 <fwp_main_thread+0x1128>
    6d2a:	80 f9 01             	cmp    $0x1,%cl
    6d2d:	0f 85 4e 03 00 00    	jne    7081 <fwp_main_thread+0x1131>
    6d33:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    6d37:	0f b7 ca             	movzwl %dx,%ecx
    6d3a:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    6d3e:	49 0f af cb          	imul   %r11,%rcx
    6d42:	48 c1 e9 20          	shr    $0x20,%rcx
    6d46:	4c 39 d1             	cmp    %r10,%rcx
    6d49:	0f 83 32 03 00 00    	jae    7081 <fwp_main_thread+0x1131>
    6d4f:	49 01 c9             	add    %rcx,%r9
    6d52:	41 80 39 ff          	cmpb   $0xff,(%r9)
    6d56:	0f 84 d4 09 00 00    	je     7730 <fwp_main_thread+0x17e0>
    6d5c:	41 c6 01 01          	movb   $0x1,(%r9)
    6d60:	49 8b bd b0 13 00 00 	mov    0x13b0(%r13),%rdi
    6d67:	48 89 f2             	mov    %rsi,%rdx
    6d6a:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    6d71:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    6d75:	48 29 fa             	sub    %rdi,%rdx
    6d78:	f2 41 0f 10 6f 08    	movsd  0x8(%r15),%xmm5
    6d7e:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    6d83:	48 c1 e0 10          	shl    $0x10,%rax
    6d87:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6d8c:	48 39 c2             	cmp    %rax,%rdx
    6d8f:	0f 83 07 02 00 00    	jae    6f9c <fwp_main_thread+0x104c>
    6d95:	49 89 d1             	mov    %rdx,%r9
    6d98:	49 c1 e9 10          	shr    $0x10,%r9
    6d9c:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
    6da0:	4d 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%r9
    6da7:	4f 8d 14 d1          	lea    (%r9,%r10,8),%r10
    6dab:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    6daf:	4d 85 c9             	test   %r9,%r9
    6db2:	0f 84 e4 01 00 00    	je     6f9c <fwp_main_thread+0x104c>
    6db8:	45 0f b6 1a          	movzbl (%r10),%r11d
    6dbc:	41 80 fb 02          	cmp    $0x2,%r11b
    6dc0:	0f 84 1a 03 00 00    	je     70e0 <fwp_main_thread+0x1190>
    6dc6:	41 80 fb 01          	cmp    $0x1,%r11b
    6dca:	0f 85 cc 01 00 00    	jne    6f9c <fwp_main_thread+0x104c>
    6dd0:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    6dd4:	0f b7 d2             	movzwl %dx,%edx
    6dd7:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    6ddb:	49 0f af d3          	imul   %r11,%rdx
    6ddf:	48 c1 ea 20          	shr    $0x20,%rdx
    6de3:	4c 39 d2             	cmp    %r10,%rdx
    6de6:	0f 83 b0 01 00 00    	jae    6f9c <fwp_main_thread+0x104c>
    6dec:	49 01 d1             	add    %rdx,%r9
    6def:	41 0f b6 11          	movzbl (%r9),%edx
    6df3:	84 d2                	test   %dl,%dl
    6df5:	0f 84 a1 01 00 00    	je     6f9c <fwp_main_thread+0x104c>
    6dfb:	80 fa 01             	cmp    $0x1,%dl
    6dfe:	0f 84 bc 01 00 00    	je     6fc0 <fwp_main_thread+0x1070>
    6e04:	80 fa ff             	cmp    $0xff,%dl
    6e07:	0f 84 23 0a 00 00    	je     7830 <fwp_main_thread+0x18e0>
    6e0d:	83 ea 01             	sub    $0x1,%edx
    6e10:	41 88 11             	mov    %dl,(%r9)
    6e13:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    6e1a:	f2 41 0f 10 67 08    	movsd  0x8(%r15),%xmm4
    6e20:	f3 41 0f 7e 5f 10    	movq   0x10(%r15),%xmm3
    6e26:	49 8b bd b0 13 00 00 	mov    0x13b0(%r13),%rdi
    6e2d:	48 c1 e0 10          	shl    $0x10,%rax
    6e31:	0f 1f 40 00          	nopl   0x0(%rax)
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	4c 89 fa             	mov    %r15,%rdx
    6e43:	48 29 fa             	sub    %rdi,%rdx
    6e46:	48 39 c2             	cmp    %rax,%rdx
    6e49:	73 75                	jae    6ec0 <fwp_main_thread+0xf70>
    6e4b:	48 89 d0             	mov    %rdx,%rax
    6e4e:	48 c1 e8 10          	shr    $0x10,%rax
    6e52:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    6e56:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    6e5d:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    6e61:	48 8b 46 20          	mov    0x20(%rsi),%rax
    6e65:	48 85 c0             	test   %rax,%rax
    6e68:	74 56                	je     6ec0 <fwp_main_thread+0xf70>
    6e6a:	0f b6 3e             	movzbl (%rsi),%edi
    6e6d:	40 80 ff 02          	cmp    $0x2,%dil
    6e71:	0f 84 89 02 00 00    	je     7100 <fwp_main_thread+0x11b0>
    6e77:	40 80 ff 01          	cmp    $0x1,%dil
    6e7b:	75 43                	jne    6ec0 <fwp_main_thread+0xf70>
    6e7d:	8b 7e 18             	mov    0x18(%rsi),%edi
    6e80:	0f b7 d2             	movzwl %dx,%edx
    6e83:	48 0f af fa          	imul   %rdx,%rdi
    6e87:	8b 56 1c             	mov    0x1c(%rsi),%edx
    6e8a:	48 c1 ef 20          	shr    $0x20,%rdi
    6e8e:	48 39 d7             	cmp    %rdx,%rdi
    6e91:	73 2d                	jae    6ec0 <fwp_main_thread+0xf70>
    6e93:	48 01 f8             	add    %rdi,%rax
    6e96:	0f b6 10             	movzbl (%rax),%edx
    6e99:	84 d2                	test   %dl,%dl
    6e9b:	74 23                	je     6ec0 <fwp_main_thread+0xf70>
    6e9d:	80 fa 01             	cmp    $0x1,%dl
    6ea0:	0f 84 7a 01 00 00    	je     7020 <fwp_main_thread+0x10d0>
    6ea6:	80 fa ff             	cmp    $0xff,%dl
    6ea9:	0f 84 f1 09 00 00    	je     78a0 <fwp_main_thread+0x1950>
    6eaf:	83 ea 01             	sub    $0x1,%edx
    6eb2:	88 10                	mov    %dl,(%rax)
    6eb4:	90                   	nop
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 
    6ec0:	66 48 0f 6e d1       	movq   %rcx,%xmm2
    6ec5:	66 0f 28 f2          	movapd %xmm2,%xmm6
    6ec9:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
    6ecd:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
    6ed1:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
    6ed5:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6ed9:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    6edd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6ee1:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6ee5:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6ee9:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6eed:	f2 0f 59 05 fb 25 00 	mulsd  0x25fb(%rip),%xmm0        # 94f0 <msg.3+0xb0>
    6ef4:	00 
    6ef5:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    6ef9:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
    6efd:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6f01:	66 0f 28 ca          	movapd %xmm2,%xmm1
    6f05:	f2 0f 10 15 db 25 00 	movsd  0x25db(%rip),%xmm2        # 94e8 <msg.3+0xa8>
    6f0c:	00 
    6f0d:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    6f11:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    6f15:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6f19:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6f1d:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    6f22:	0f 88 df 0e 00 00    	js     7e07 <fwp_main_thread+0x1eb7>
    6f28:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6f2e:	f2 0f 59 05 c2 25 00 	mulsd  0x25c2(%rip),%xmm0        # 94f8 <msg.3+0xb8>
    6f35:	00 
    6f36:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6f3b:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6f3f:	f2 43 0f 11 0c 34    	movsd  %xmm1,(%r12,%r14,1)
    6f45:	49 83 c6 08          	add    $0x8,%r14
    6f49:	48 39 5c 24 10       	cmp    %rbx,0x10(%rsp)
    6f4e:	0f 84 bc 01 00 00    	je     7110 <fwp_main_thread+0x11c0>
    6f54:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    6f58:	48 89 d0             	mov    %rdx,%rax
    6f5b:	48 0f ba f0 3f       	btr    $0x3f,%rax
    6f60:	48 39 c3             	cmp    %rax,%rbx
    6f63:	0f 82 e7 fb ff ff    	jb     6b50 <fwp_main_thread+0xc00>
    6f69:	48 8d 3d b8 40 00 00 	lea    0x40b8(%rip),%rdi        # b028 <s0+0x8>
    6f70:	e8 3b c1 ff ff       	call   30b0 <fwp_trap>
    6f75:	0f 1f 00             	nopl   (%rax)
    6f78:	e8 73 c8 ff ff       	call   37f0 <fwp_heap_init>
    6f7d:	e9 04 f0 ff ff       	jmp    5f86 <fwp_main_thread+0x36>
    6f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f88:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    6f8c:	f2 41 0f 10 6f 08    	movsd  0x8(%r15),%xmm5
    6f92:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    6f97:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6f9c:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    6fa1:	66 0f 28 e5          	movapd %xmm5,%xmm4
    6fa5:	e9 96 fe ff ff       	jmp    6e40 <fwp_main_thread+0xef0>
    6faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6fb4:	e9 64 ff ff ff       	jmp    6f1d <fwp_main_thread+0xfcd>
    6fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fc0:	48 89 f7             	mov    %rsi,%rdi
    6fc3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6fc8:	66 0f d6 4c 24 40    	movq   %xmm1,0x40(%rsp)
    6fce:	66 0f d6 44 24 38    	movq   %xmm0,0x38(%rsp)
    6fd4:	f2 0f 11 6c 24 30    	movsd  %xmm5,0x30(%rsp)
    6fda:	e8 f1 d4 ff ff       	call   44d0 <fwp_rc_free_arr>
    6fdf:	f2 41 0f 10 67 08    	movsd  0x8(%r15),%xmm4
    6fe5:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    6fec:	f3 41 0f 7e 5f 10    	movq   0x10(%r15),%xmm3
    6ff2:	49 8b bd b0 13 00 00 	mov    0x13b0(%r13),%rdi
    6ff9:	f3 0f 7e 4c 24 40    	movq   0x40(%rsp),%xmm1
    6fff:	f3 0f 7e 44 24 38    	movq   0x38(%rsp),%xmm0
    7005:	48 c1 e0 10          	shl    $0x10,%rax
    7009:	f2 0f 10 6c 24 30    	movsd  0x30(%rsp),%xmm5
    700f:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    7014:	e9 27 fe ff ff       	jmp    6e40 <fwp_main_thread+0xef0>
    7019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7020:	4c 89 ff             	mov    %r15,%rdi
    7023:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    7028:	66 0f d6 4c 24 50    	movq   %xmm1,0x50(%rsp)
    702e:	66 0f d6 44 24 48    	movq   %xmm0,0x48(%rsp)
    7034:	f2 0f 11 6c 24 40    	movsd  %xmm5,0x40(%rsp)
    703a:	f2 0f 11 64 24 38    	movsd  %xmm4,0x38(%rsp)
    7040:	66 0f d6 5c 24 30    	movq   %xmm3,0x30(%rsp)
    7046:	e8 85 d4 ff ff       	call   44d0 <fwp_rc_free_arr>
    704b:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
    7051:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    7056:	f3 0f 7e 4c 24 50    	movq   0x50(%rsp),%xmm1
    705c:	f3 0f 7e 44 24 48    	movq   0x48(%rsp),%xmm0
    7062:	f2 0f 10 64 24 38    	movsd  0x38(%rsp),%xmm4
    7068:	f3 0f 7e 5c 24 30    	movq   0x30(%rsp),%xmm3
    706e:	e9 4d fe ff ff       	jmp    6ec0 <fwp_main_thread+0xf70>
    7073:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7078:	66 85 d2             	test   %dx,%dx
    707b:	0f 84 d1 fc ff ff    	je     6d52 <fwp_main_thread+0xe02>
    7081:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    7085:	f2 41 0f 10 6f 08    	movsd  0x8(%r15),%xmm5
    708b:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    7090:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    7095:	e9 fb fc ff ff       	jmp    6d95 <fwp_main_thread+0xe45>
    709a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70a0:	66 85 c0             	test   %ax,%ax
    70a3:	0f 85 e4 fb ff ff    	jne    6c8d <fwp_main_thread+0xd3d>
    70a9:	80 3a ff             	cmpb   $0xff,(%rdx)
    70ac:	0f 85 d8 fb ff ff    	jne    6c8a <fwp_main_thread+0xd3a>
    70b2:	0f 1f 00             	nopl   (%rax)
    70b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70bc:	00 00 00 00 
    70c0:	48 89 d7             	mov    %rdx,%rdi
    70c3:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    70c8:	e8 c3 cc ff ff       	call   3d90 <fwp_rc_forget_slot>
    70cd:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    70d2:	e9 b3 fb ff ff       	jmp    6c8a <fwp_main_thread+0xd3a>
    70d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70de:	00 00 
    70e0:	66 85 d2             	test   %dx,%dx
    70e3:	0f 84 06 fd ff ff    	je     6def <fwp_main_thread+0xe9f>
    70e9:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    70ee:	66 0f 28 e5          	movapd %xmm5,%xmm4
    70f2:	e9 49 fd ff ff       	jmp    6e40 <fwp_main_thread+0xef0>
    70f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70fe:	00 00 
    7100:	66 85 d2             	test   %dx,%dx
    7103:	0f 85 b7 fd ff ff    	jne    6ec0 <fwp_main_thread+0xf70>
    7109:	e9 88 fd ff ff       	jmp    6e96 <fwp_main_thread+0xf46>
    710e:	66 90                	xchg   %ax,%ax
    7110:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
    7115:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    711c:	48 89 e8             	mov    %rbp,%rax
    711f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    7126:	48 c1 e2 10          	shl    $0x10,%rdx
    712a:	48 39 d0             	cmp    %rdx,%rax
    712d:	73 71                	jae    71a0 <fwp_main_thread+0x1250>
    712f:	48 89 c2             	mov    %rax,%rdx
    7132:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    7139:	48 c1 ea 10          	shr    $0x10,%rdx
    713d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7141:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    7145:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7149:	48 85 db             	test   %rbx,%rbx
    714c:	74 52                	je     71a0 <fwp_main_thread+0x1250>
    714e:	0f b6 32             	movzbl (%rdx),%esi
    7151:	40 80 fe 02          	cmp    $0x2,%sil
    7155:	0f 84 fd 05 00 00    	je     7758 <fwp_main_thread+0x1808>
    715b:	40 80 fe 01          	cmp    $0x1,%sil
    715f:	75 3f                	jne    71a0 <fwp_main_thread+0x1250>
    7161:	8b 72 18             	mov    0x18(%rdx),%esi
    7164:	0f b7 c0             	movzwl %ax,%eax
    7167:	8b 52 1c             	mov    0x1c(%rdx),%edx
    716a:	48 0f af c6          	imul   %rsi,%rax
    716e:	48 c1 e8 20          	shr    $0x20,%rax
    7172:	48 39 d0             	cmp    %rdx,%rax
    7175:	73 29                	jae    71a0 <fwp_main_thread+0x1250>
    7177:	48 01 c3             	add    %rax,%rbx
    717a:	0f b6 03             	movzbl (%rbx),%eax
    717d:	84 c0                	test   %al,%al
    717f:	74 1f                	je     71a0 <fwp_main_thread+0x1250>
    7181:	3c 01                	cmp    $0x1,%al
    7183:	0f 84 17 01 00 00    	je     72a0 <fwp_main_thread+0x1350>
    7189:	3c ff                	cmp    $0xff,%al
    718b:	0f 84 35 09 00 00    	je     7ac6 <fwp_main_thread+0x1b76>
    7191:	83 e8 01             	sub    $0x1,%eax
    7194:	88 03                	mov    %al,(%rbx)
    7196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    719d:	00 00 00 
    71a0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    71a5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71a9:	be 01 00 00 00       	mov    $0x1,%esi
    71ae:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    71b5:	00 00 00 00 00 
    71ba:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    71c1:	00 
    71c2:	49 8d 6c 24 08       	lea    0x8(%r12),%rbp
    71c7:	e8 f4 bc ff ff       	call   2ec0 <buf_grow>
    71cc:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    71d3:	00 
    71d4:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    71d9:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    71e0:	00 
    71e1:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    71e5:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    71ec:	00 
    71ed:	48 8d 50 01          	lea    0x1(%rax),%rdx
    71f1:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    71f8:	00 
    71f9:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    7200:	00 
    7201:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    7206:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    720d:	ff ff 7f 
    7210:	49 23 04 24          	and    (%r12),%rax
    7214:	48 89 c3             	mov    %rax,%rbx
    7217:	75 6d                	jne    7286 <fwp_main_thread+0x1336>
    7219:	e9 1a 01 00 00       	jmp    7338 <fwp_main_thread+0x13e8>
    721e:	66 90                	xchg   %ax,%ax
    7220:	4a 8b 34 f0          	mov    (%rax,%r14,8),%rsi
    7224:	48 8d 15 95 39 00 00 	lea    0x3995(%rip),%rdx        # abc0 <d0>
    722b:	4c 89 ff             	mov    %r15,%rdi
    722e:	49 83 c6 01          	add    $0x1,%r14
    7232:	e8 19 dd ff ff       	call   4f50 <fwp_write.constprop.0>
    7237:	4c 39 f3             	cmp    %r14,%rbx
    723a:	0f 84 f8 00 00 00    	je     7338 <fwp_main_thread+0x13e8>
    7240:	be 02 00 00 00       	mov    $0x2,%esi
    7245:	4c 89 ff             	mov    %r15,%rdi
    7248:	e8 73 bc ff ff       	call   2ec0 <buf_grow>
    724d:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    7254:	00 
    7255:	ba 2c 20 00 00       	mov    $0x202c,%edx
    725a:	48 03 84 24 a0 00 00 	add    0xa0(%rsp),%rax
    7261:	00 
    7262:	66 89 10             	mov    %dx,(%rax)
    7265:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    726c:	00 
    726d:	48 8d 50 02          	lea    0x2(%rax),%rdx
    7271:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    7278:	00 
    7279:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    7280:	00 
    7281:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    7286:	48 89 e8             	mov    %rbp,%rax
    7289:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    728e:	79 90                	jns    7220 <fwp_main_thread+0x12d0>
    7290:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    7295:	eb 89                	jmp    7220 <fwp_main_thread+0x12d0>
    7297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    729e:	00 00 
    72a0:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    72a7:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    72ae:	48 89 e8             	mov    %rbp,%rax
    72b1:	48 89 ef             	mov    %rbp,%rdi
    72b4:	48 29 f0             	sub    %rsi,%rax
    72b7:	48 c1 e2 10          	shl    $0x10,%rdx
    72bb:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    72c0:	0f 88 aa 04 00 00    	js     7770 <fwp_main_thread+0x1820>
    72c6:	48 39 d0             	cmp    %rdx,%rax
    72c9:	0f 83 d1 fe ff ff    	jae    71a0 <fwp_main_thread+0x1250>
    72cf:	48 89 c2             	mov    %rax,%rdx
    72d2:	48 c1 ea 10          	shr    $0x10,%rdx
    72d6:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    72da:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    72de:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    72e2:	48 85 c9             	test   %rcx,%rcx
    72e5:	0f 84 b5 fe ff ff    	je     71a0 <fwp_main_thread+0x1250>
    72eb:	0f b6 3a             	movzbl (%rdx),%edi
    72ee:	40 80 ff 02          	cmp    $0x2,%dil
    72f2:	0f 84 28 05 00 00    	je     7820 <fwp_main_thread+0x18d0>
    72f8:	40 80 ff 01          	cmp    $0x1,%dil
    72fc:	0f 85 9e fe ff ff    	jne    71a0 <fwp_main_thread+0x1250>
    7302:	8b 7a 18             	mov    0x18(%rdx),%edi
    7305:	0f b7 c0             	movzwl %ax,%eax
    7308:	8b 52 1c             	mov    0x1c(%rdx),%edx
    730b:	48 0f af c7          	imul   %rdi,%rax
    730f:	48 c1 e8 20          	shr    $0x20,%rax
    7313:	48 39 d0             	cmp    %rdx,%rax
    7316:	0f 83 84 fe ff ff    	jae    71a0 <fwp_main_thread+0x1250>
    731c:	48 01 c1             	add    %rax,%rcx
    731f:	80 39 01             	cmpb   $0x1,(%rcx)
    7322:	0f 85 78 fe ff ff    	jne    71a0 <fwp_main_thread+0x1250>
    7328:	48 89 ef             	mov    %rbp,%rdi
    732b:	e8 a0 cc ff ff       	call   3fd0 <fwp_mem_free>
    7330:	e9 6b fe ff ff       	jmp    71a0 <fwp_main_thread+0x1250>
    7335:	0f 1f 00             	nopl   (%rax)
    7338:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    733d:	be 01 00 00 00       	mov    $0x1,%esi
    7342:	e8 79 bb ff ff       	call   2ec0 <buf_grow>
    7347:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    734e:	00 
    734f:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    7356:	00 
    7357:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    735b:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    7362:	00 
    7363:	48 8d 50 01          	lea    0x1(%rax),%rdx
    7367:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    736e:	00 
    736f:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    7376:	00 
    7377:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    737c:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
    7383:	00 
    7384:	48 8d 05 a3 1c 00 00 	lea    0x1ca3(%rip),%rax        # 902e <_IO_stdin_used+0x2e>
    738b:	4c 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%r14
    7392:	00 
    7393:	4d 85 ff             	test   %r15,%r15
    7396:	4c 0f 44 f8          	cmove  %rax,%r15
    739a:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    739e:	0f 87 d6 0a 00 00    	ja     7e7a <fwp_main_thread+0x1f2a>
    73a4:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    73a8:	be 01 00 00 00       	mov    $0x1,%esi
    73ad:	e8 9e d1 ff ff       	call   4550 <fwp_heap_alloc>
    73b2:	4c 89 f2             	mov    %r14,%rdx
    73b5:	4c 89 fe             	mov    %r15,%rsi
    73b8:	4c 89 30             	mov    %r14,(%rax)
    73bb:	48 8d 58 08          	lea    0x8(%rax),%rbx
    73bf:	48 89 c5             	mov    %rax,%rbp
    73c2:	48 89 df             	mov    %rbx,%rdi
    73c5:	e8 a6 b1 ff ff       	call   2570 <memcpy@plt>
    73ca:	42 c6 44 35 08 00    	movb   $0x0,0x8(%rbp,%r14,1)
    73d0:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    73d7:	00 
    73d8:	e8 c3 af ff ff       	call   23a0 <free@plt>
    73dd:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    73e4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    73eb:	48 89 e8             	mov    %rbp,%rax
    73ee:	48 29 c8             	sub    %rcx,%rax
    73f1:	48 c1 e2 10          	shl    $0x10,%rdx
    73f5:	48 39 d0             	cmp    %rdx,%rax
    73f8:	73 6b                	jae    7465 <fwp_main_thread+0x1515>
    73fa:	48 89 c6             	mov    %rax,%rsi
    73fd:	48 c1 ee 10          	shr    $0x10,%rsi
    7401:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    7405:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    740c:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    7410:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    7414:	4d 85 f6             	test   %r14,%r14
    7417:	74 4c                	je     7465 <fwp_main_thread+0x1515>
    7419:	0f b6 3e             	movzbl (%rsi),%edi
    741c:	40 80 ff 02          	cmp    $0x2,%dil
    7420:	0f 84 da 05 00 00    	je     7a00 <fwp_main_thread+0x1ab0>
    7426:	40 80 ff 01          	cmp    $0x1,%dil
    742a:	75 39                	jne    7465 <fwp_main_thread+0x1515>
    742c:	8b 7e 18             	mov    0x18(%rsi),%edi
    742f:	0f b7 c0             	movzwl %ax,%eax
    7432:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7435:	48 0f af c7          	imul   %rdi,%rax
    7439:	48 c1 e8 20          	shr    $0x20,%rax
    743d:	48 39 f0             	cmp    %rsi,%rax
    7440:	73 23                	jae    7465 <fwp_main_thread+0x1515>
    7442:	49 01 c6             	add    %rax,%r14
    7445:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7449:	0f 84 c4 05 00 00    	je     7a13 <fwp_main_thread+0x1ac3>
    744f:	41 c6 06 01          	movb   $0x1,(%r14)
    7453:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    745a:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    7461:	48 c1 e2 10          	shl    $0x10,%rdx
    7465:	4c 89 e0             	mov    %r12,%rax
    7468:	48 29 c8             	sub    %rcx,%rax
    746b:	48 39 d0             	cmp    %rdx,%rax
    746e:	73 70                	jae    74e0 <fwp_main_thread+0x1590>
    7470:	4c 89 e7             	mov    %r12,%rdi
    7473:	48 89 c2             	mov    %rax,%rdx
    7476:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    747d:	48 c1 ea 10          	shr    $0x10,%rdx
    7481:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7485:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    7489:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    748d:	4d 85 f6             	test   %r14,%r14
    7490:	74 4e                	je     74e0 <fwp_main_thread+0x1590>
    7492:	0f b6 32             	movzbl (%rdx),%esi
    7495:	40 80 fe 02          	cmp    $0x2,%sil
    7499:	0f 84 f1 04 00 00    	je     7990 <fwp_main_thread+0x1a40>
    749f:	40 80 fe 01          	cmp    $0x1,%sil
    74a3:	75 3b                	jne    74e0 <fwp_main_thread+0x1590>
    74a5:	8b 72 18             	mov    0x18(%rdx),%esi
    74a8:	0f b7 c0             	movzwl %ax,%eax
    74ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ae:	48 0f af c6          	imul   %rsi,%rax
    74b2:	48 c1 e8 20          	shr    $0x20,%rax
    74b6:	48 39 d0             	cmp    %rdx,%rax
    74b9:	73 25                	jae    74e0 <fwp_main_thread+0x1590>
    74bb:	49 01 c6             	add    %rax,%r14
    74be:	41 0f b6 06          	movzbl (%r14),%eax
    74c2:	84 c0                	test   %al,%al
    74c4:	74 1a                	je     74e0 <fwp_main_thread+0x1590>
    74c6:	3c 01                	cmp    $0x1,%al
    74c8:	0f 84 9a 01 00 00    	je     7668 <fwp_main_thread+0x1718>
    74ce:	3c ff                	cmp    $0xff,%al
    74d0:	0f 84 cf 06 00 00    	je     7ba5 <fwp_main_thread+0x1c55>
    74d6:	83 e8 01             	sub    $0x1,%eax
    74d9:	41 88 06             	mov    %al,(%r14)
    74dc:	0f 1f 40 00          	nopl   0x0(%rax)
    74e0:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    74e4:	48 8b 0d ad 5e 01 00 	mov    0x15ead(%rip),%rcx        # 1d398 <fwp_prog_out>
    74eb:	be 01 00 00 00       	mov    $0x1,%esi
    74f0:	48 89 df             	mov    %rbx,%rdi
    74f3:	e8 48 b1 ff ff       	call   2640 <fwrite@plt>
    74f8:	48 8b 35 99 5e 01 00 	mov    0x15e99(%rip),%rsi        # 1d398 <fwp_prog_out>
    74ff:	bf 0a 00 00 00       	mov    $0xa,%edi
    7504:	e8 b7 af ff ff       	call   24c0 <fputc@plt>
    7509:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    7510:	48 89 e8             	mov    %rbp,%rax
    7513:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    751a:	48 c1 e2 10          	shl    $0x10,%rdx
    751e:	48 39 d0             	cmp    %rdx,%rax
    7521:	73 6d                	jae    7590 <fwp_main_thread+0x1640>
    7523:	48 89 c2             	mov    %rax,%rdx
    7526:	48 c1 ea 10          	shr    $0x10,%rdx
    752a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    752e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    7535:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7539:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    753d:	48 85 db             	test   %rbx,%rbx
    7540:	74 4e                	je     7590 <fwp_main_thread+0x1640>
    7542:	0f b6 0a             	movzbl (%rdx),%ecx
    7545:	80 f9 02             	cmp    $0x2,%cl
    7548:	0f 84 d2 04 00 00    	je     7a20 <fwp_main_thread+0x1ad0>
    754e:	80 f9 01             	cmp    $0x1,%cl
    7551:	75 3d                	jne    7590 <fwp_main_thread+0x1640>
    7553:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7556:	0f b7 c0             	movzwl %ax,%eax
    7559:	8b 52 1c             	mov    0x1c(%rdx),%edx
    755c:	48 0f af c1          	imul   %rcx,%rax
    7560:	48 c1 e8 20          	shr    $0x20,%rax
    7564:	48 39 d0             	cmp    %rdx,%rax
    7567:	73 27                	jae    7590 <fwp_main_thread+0x1640>
    7569:	48 01 c3             	add    %rax,%rbx
    756c:	0f b6 03             	movzbl (%rbx),%eax
    756f:	84 c0                	test   %al,%al
    7571:	74 1d                	je     7590 <fwp_main_thread+0x1640>
    7573:	3c 01                	cmp    $0x1,%al
    7575:	0f 84 95 02 00 00    	je     7810 <fwp_main_thread+0x18c0>
    757b:	3c ff                	cmp    $0xff,%al
    757d:	0f 84 fd 06 00 00    	je     7c80 <fwp_main_thread+0x1d30>
    7583:	83 e8 01             	sub    $0x1,%eax
    7586:	88 03                	mov    %al,(%rbx)
    7588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    758f:	00 
    7590:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    7595:	48 8b 40 10          	mov    0x10(%rax),%rax
    7599:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    759e:	48 85 c0             	test   %rax,%rax
    75a1:	0f 84 b0 04 00 00    	je     7a57 <fwp_main_thread+0x1b07>
    75a7:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    75ae:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    75b5:	e9 06 f3 ff ff       	jmp    68c0 <fwp_main_thread+0x970>
    75ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75c0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    75c5:	0f 88 3c 08 00 00    	js     7e07 <fwp_main_thread+0x1eb7>
    75cb:	4a 89 4c e5 00       	mov    %rcx,0x0(%rbp,%r12,8)
    75d0:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    75d7:	49 2b 95 b0 13 00 00 	sub    0x13b0(%r13),%rdx
    75de:	48 c1 e0 10          	shl    $0x10,%rax
    75e2:	48 39 c2             	cmp    %rax,%rdx
    75e5:	73 58                	jae    763f <fwp_main_thread+0x16ef>
    75e7:	48 89 d0             	mov    %rdx,%rax
    75ea:	48 c1 e8 10          	shr    $0x10,%rax
    75ee:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    75f2:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    75f9:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    75fd:	48 8b 48 20          	mov    0x20(%rax),%rcx
    7601:	48 85 c9             	test   %rcx,%rcx
    7604:	74 39                	je     763f <fwp_main_thread+0x16ef>
    7606:	0f b6 30             	movzbl (%rax),%esi
    7609:	40 80 fe 02          	cmp    $0x2,%sil
    760d:	0f 84 5d 03 00 00    	je     7970 <fwp_main_thread+0x1a20>
    7613:	40 80 fe 01          	cmp    $0x1,%sil
    7617:	75 26                	jne    763f <fwp_main_thread+0x16ef>
    7619:	8b 70 18             	mov    0x18(%rax),%esi
    761c:	0f b7 d2             	movzwl %dx,%edx
    761f:	8b 40 1c             	mov    0x1c(%rax),%eax
    7622:	48 0f af d6          	imul   %rsi,%rdx
    7626:	48 c1 ea 20          	shr    $0x20,%rdx
    762a:	48 39 c2             	cmp    %rax,%rdx
    762d:	73 10                	jae    763f <fwp_main_thread+0x16ef>
    762f:	48 01 d1             	add    %rdx,%rcx
    7632:	80 39 01             	cmpb   $0x1,(%rcx)
    7635:	75 08                	jne    763f <fwp_main_thread+0x16ef>
    7637:	4c 89 d7             	mov    %r10,%rdi
    763a:	e8 91 c9 ff ff       	call   3fd0 <fwp_mem_free>
    763f:	48 85 db             	test   %rbx,%rbx
    7642:	0f 84 3a 03 00 00    	je     7982 <fwp_main_thread+0x1a32>
    7648:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    764c:	49 89 da             	mov    %rbx,%r10
    764f:	49 89 d9             	mov    %rbx,%r9
    7652:	48 89 da             	mov    %rbx,%rdx
    7655:	49 83 c4 01          	add    $0x1,%r12
    7659:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    765d:	e9 8b f3 ff ff       	jmp    69ed <fwp_main_thread+0xa9d>
    7662:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7668:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    766c:	0f 88 2e 03 00 00    	js     79a0 <fwp_main_thread+0x1a50>
    7672:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    7679:	48 89 f8             	mov    %rdi,%rax
    767c:	49 89 fc             	mov    %rdi,%r12
    767f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    7686:	48 c1 e2 10          	shl    $0x10,%rdx
    768a:	48 39 d0             	cmp    %rdx,%rax
    768d:	0f 83 4d fe ff ff    	jae    74e0 <fwp_main_thread+0x1590>
    7693:	48 89 c2             	mov    %rax,%rdx
    7696:	48 c1 ea 10          	shr    $0x10,%rdx
    769a:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    769e:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    76a2:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    76a6:	48 85 c9             	test   %rcx,%rcx
    76a9:	0f 84 31 fe ff ff    	je     74e0 <fwp_main_thread+0x1590>
    76af:	0f b6 32             	movzbl (%rdx),%esi
    76b2:	40 80 fe 02          	cmp    $0x2,%sil
    76b6:	0f 84 74 03 00 00    	je     7a30 <fwp_main_thread+0x1ae0>
    76bc:	40 80 fe 01          	cmp    $0x1,%sil
    76c0:	0f 85 1a fe ff ff    	jne    74e0 <fwp_main_thread+0x1590>
    76c6:	8b 72 18             	mov    0x18(%rdx),%esi
    76c9:	0f b7 c0             	movzwl %ax,%eax
    76cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76cf:	48 0f af c6          	imul   %rsi,%rax
    76d3:	48 c1 e8 20          	shr    $0x20,%rax
    76d7:	48 39 d0             	cmp    %rdx,%rax
    76da:	0f 83 00 fe ff ff    	jae    74e0 <fwp_main_thread+0x1590>
    76e0:	48 01 c1             	add    %rax,%rcx
    76e3:	80 39 01             	cmpb   $0x1,(%rcx)
    76e6:	0f 85 f4 fd ff ff    	jne    74e0 <fwp_main_thread+0x1590>
    76ec:	4c 89 e7             	mov    %r12,%rdi
    76ef:	e8 dc c8 ff ff       	call   3fd0 <fwp_mem_free>
    76f4:	e9 e7 fd ff ff       	jmp    74e0 <fwp_main_thread+0x1590>
    76f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7700:	48 8b 4d 10          	mov    0x10(%rbp),%rcx
    7704:	e9 54 f4 ff ff       	jmp    6b5d <fwp_main_thread+0xc0d>
    7709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7710:	66 85 c0             	test   %ax,%ax
    7713:	0f 85 53 f3 ff ff    	jne    6a6c <fwp_main_thread+0xb1c>
    7719:	e9 36 f3 ff ff       	jmp    6a54 <fwp_main_thread+0xb04>
    771e:	66 90                	xchg   %ax,%ax
    7720:	48 8b 55 10          	mov    0x10(%rbp),%rdx
    7724:	e9 86 f5 ff ff       	jmp    6caf <fwp_main_thread+0xd5f>
    7729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7730:	4c 89 cf             	mov    %r9,%rdi
    7733:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
    7738:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    773d:	e8 4e c6 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7742:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    7747:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    774c:	e9 0b f6 ff ff       	jmp    6d5c <fwp_main_thread+0xe0c>
    7751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7758:	66 85 c0             	test   %ax,%ax
    775b:	0f 85 3f fa ff ff    	jne    71a0 <fwp_main_thread+0x1250>
    7761:	e9 14 fa ff ff       	jmp    717a <fwp_main_thread+0x122a>
    7766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    776d:	00 00 00 
    7770:	48 8b 6d 08          	mov    0x8(%rbp),%rbp
    7774:	48 39 d0             	cmp    %rdx,%rax
    7777:	73 63                	jae    77dc <fwp_main_thread+0x188c>
    7779:	49 89 c0             	mov    %rax,%r8
    777c:	49 c1 e8 10          	shr    $0x10,%r8
    7780:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    7784:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
    7788:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    778c:	4d 85 c0             	test   %r8,%r8
    778f:	74 4b                	je     77dc <fwp_main_thread+0x188c>
    7791:	44 0f b6 09          	movzbl (%rcx),%r9d
    7795:	41 80 f9 02          	cmp    $0x2,%r9b
    7799:	0f 84 a1 02 00 00    	je     7a40 <fwp_main_thread+0x1af0>
    779f:	41 80 f9 01          	cmp    $0x1,%r9b
    77a3:	75 37                	jne    77dc <fwp_main_thread+0x188c>
    77a5:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    77a9:	0f b7 c0             	movzwl %ax,%eax
    77ac:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77af:	49 0f af c1          	imul   %r9,%rax
    77b3:	48 c1 e8 20          	shr    $0x20,%rax
    77b7:	48 39 c8             	cmp    %rcx,%rax
    77ba:	73 20                	jae    77dc <fwp_main_thread+0x188c>
    77bc:	49 01 c0             	add    %rax,%r8
    77bf:	41 80 38 01          	cmpb   $0x1,(%r8)
    77c3:	75 17                	jne    77dc <fwp_main_thread+0x188c>
    77c5:	e8 06 c8 ff ff       	call   3fd0 <fwp_mem_free>
    77ca:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    77d1:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    77d8:	48 c1 e2 10          	shl    $0x10,%rdx
    77dc:	48 89 e8             	mov    %rbp,%rax
    77df:	48 29 f0             	sub    %rsi,%rax
    77e2:	48 39 d0             	cmp    %rdx,%rax
    77e5:	0f 82 44 f9 ff ff    	jb     712f <fwp_main_thread+0x11df>
    77eb:	e9 b0 f9 ff ff       	jmp    71a0 <fwp_main_thread+0x1250>
    77f0:	66 85 c0             	test   %ax,%ax
    77f3:	0f 85 32 f3 ff ff    	jne    6b2b <fwp_main_thread+0xbdb>
    77f9:	80 3b ff             	cmpb   $0xff,(%rbx)
    77fc:	0f 85 26 f3 ff ff    	jne    6b28 <fwp_main_thread+0xbd8>
    7802:	48 89 df             	mov    %rbx,%rdi
    7805:	e8 86 c5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    780a:	e9 19 f3 ff ff       	jmp    6b28 <fwp_main_thread+0xbd8>
    780f:	90                   	nop
    7810:	48 89 ef             	mov    %rbp,%rdi
    7813:	e8 b8 cc ff ff       	call   44d0 <fwp_rc_free_arr>
    7818:	e9 73 fd ff ff       	jmp    7590 <fwp_main_thread+0x1640>
    781d:	0f 1f 00             	nopl   (%rax)
    7820:	66 85 c0             	test   %ax,%ax
    7823:	0f 85 77 f9 ff ff    	jne    71a0 <fwp_main_thread+0x1250>
    7829:	e9 f1 fa ff ff       	jmp    731f <fwp_main_thread+0x13cf>
    782e:	66 90                	xchg   %ax,%ax
    7830:	4c 89 ca             	mov    %r9,%rdx
    7833:	48 c1 ea 11          	shr    $0x11,%rdx
    7837:	4c 31 ca             	xor    %r9,%rdx
    783a:	48 89 d6             	mov    %rdx,%rsi
    783d:	48 c1 ee 09          	shr    $0x9,%rsi
    7841:	48 31 d6             	xor    %rdx,%rsi
    7844:	40 0f b6 f6          	movzbl %sil,%esi
    7848:	49 8b 94 f5 48 14 00 	mov    0x1448(%r13,%rsi,8),%rdx
    784f:	00 
    7850:	48 85 d2             	test   %rdx,%rdx
    7853:	75 18                	jne    786d <fwp_main_thread+0x191d>
    7855:	e9 0f 06 00 00       	jmp    7e69 <fwp_main_thread+0x1f19>
    785a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7860:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7864:	48 85 d2             	test   %rdx,%rdx
    7867:	0f 84 fc 05 00 00    	je     7e69 <fwp_main_thread+0x1f19>
    786d:	48 89 d6             	mov    %rdx,%rsi
    7870:	4c 3b 0a             	cmp    (%rdx),%r9
    7873:	75 eb                	jne    7860 <fwp_main_thread+0x1910>
    7875:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    7879:	48 83 ee 01          	sub    $0x1,%rsi
    787d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7881:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7888:	0f 84 b0 02 00 00    	je     7b3e <fwp_main_thread+0x1bee>
    788e:	f2 41 0f 10 67 08    	movsd  0x8(%r15),%xmm4
    7894:	f3 41 0f 7e 5f 10    	movq   0x10(%r15),%xmm3
    789a:	e9 a1 f5 ff ff       	jmp    6e40 <fwp_main_thread+0xef0>
    789f:	90                   	nop
    78a0:	48 89 c2             	mov    %rax,%rdx
    78a3:	48 c1 ea 11          	shr    $0x11,%rdx
    78a7:	48 31 c2             	xor    %rax,%rdx
    78aa:	48 89 d6             	mov    %rdx,%rsi
    78ad:	48 c1 ee 09          	shr    $0x9,%rsi
    78b1:	48 31 f2             	xor    %rsi,%rdx
    78b4:	0f b6 f2             	movzbl %dl,%esi
    78b7:	49 8b 94 f5 48 14 00 	mov    0x1448(%r13,%rsi,8),%rdx
    78be:	00 
    78bf:	48 85 d2             	test   %rdx,%rdx
    78c2:	75 29                	jne    78ed <fwp_main_thread+0x199d>
    78c4:	e9 a0 05 00 00       	jmp    7e69 <fwp_main_thread+0x1f19>
    78c9:	90                   	nop
    78ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78d1:	00 00 00 00 
    78d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78dc:	00 00 00 00 
    78e0:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    78e4:	48 85 d2             	test   %rdx,%rdx
    78e7:	0f 84 7c 05 00 00    	je     7e69 <fwp_main_thread+0x1f19>
    78ed:	48 89 d6             	mov    %rdx,%rsi
    78f0:	48 39 02             	cmp    %rax,(%rdx)
    78f3:	75 eb                	jne    78e0 <fwp_main_thread+0x1990>
    78f5:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    78f9:	48 8d 77 ff          	lea    -0x1(%rdi),%rsi
    78fd:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7901:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7908:	0f 85 b2 f5 ff ff    	jne    6ec0 <fwp_main_thread+0xf70>
    790e:	48 89 c7             	mov    %rax,%rdi
    7911:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    7916:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    791b:	66 0f d6 4c 24 78    	movq   %xmm1,0x78(%rsp)
    7921:	66 0f d6 44 24 50    	movq   %xmm0,0x50(%rsp)
    7927:	f2 0f 11 6c 24 48    	movsd  %xmm5,0x48(%rsp)
    792d:	f2 0f 11 64 24 40    	movsd  %xmm4,0x40(%rsp)
    7933:	66 0f d6 5c 24 38    	movq   %xmm3,0x38(%rsp)
    7939:	e8 52 c4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    793e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7943:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    7948:	f3 0f 7e 5c 24 38    	movq   0x38(%rsp),%xmm3
    794e:	f2 0f 10 64 24 40    	movsd  0x40(%rsp),%xmm4
    7954:	f2 0f 10 6c 24 48    	movsd  0x48(%rsp),%xmm5
    795a:	c6 00 fe             	movb   $0xfe,(%rax)
    795d:	f3 0f 7e 44 24 50    	movq   0x50(%rsp),%xmm0
    7963:	f3 0f 7e 4c 24 78    	movq   0x78(%rsp),%xmm1
    7969:	e9 52 f5 ff ff       	jmp    6ec0 <fwp_main_thread+0xf70>
    796e:	66 90                	xchg   %ax,%ax
    7970:	66 85 d2             	test   %dx,%dx
    7973:	0f 84 b9 fc ff ff    	je     7632 <fwp_main_thread+0x16e2>
    7979:	48 85 db             	test   %rbx,%rbx
    797c:	0f 85 c6 fc ff ff    	jne    7648 <fwp_main_thread+0x16f8>
    7982:	45 31 c9             	xor    %r9d,%r9d
    7985:	e9 f7 f0 ff ff       	jmp    6a81 <fwp_main_thread+0xb31>
    798a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7990:	66 85 c0             	test   %ax,%ax
    7993:	0f 85 47 fb ff ff    	jne    74e0 <fwp_main_thread+0x1590>
    7999:	e9 20 fb ff ff       	jmp    74be <fwp_main_thread+0x156e>
    799e:	66 90                	xchg   %ax,%ax
    79a0:	4c 8b 77 08          	mov    0x8(%rdi),%r14
    79a4:	e8 27 cb ff ff       	call   44d0 <fwp_rc_free_arr>
    79a9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    79b0:	4c 89 f0             	mov    %r14,%rax
    79b3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    79ba:	48 c1 e2 10          	shl    $0x10,%rdx
    79be:	48 39 d0             	cmp    %rdx,%rax
    79c1:	0f 83 19 fb ff ff    	jae    74e0 <fwp_main_thread+0x1590>
    79c7:	4c 89 f7             	mov    %r14,%rdi
    79ca:	e9 a4 fa ff ff       	jmp    7473 <fwp_main_thread+0x1523>
    79cf:	90                   	nop
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	0f 85 55 ef ff ff    	jne    692e <fwp_main_thread+0x9de>
    79d9:	e9 3c ef ff ff       	jmp    691a <fwp_main_thread+0x9ca>
    79de:	66 90                	xchg   %ax,%ax
    79e0:	66 85 c0             	test   %ax,%ax
    79e3:	0f 85 eb ef ff ff    	jne    69d4 <fwp_main_thread+0xa84>
    79e9:	80 3b ff             	cmpb   $0xff,(%rbx)
    79ec:	0f 85 df ef ff ff    	jne    69d1 <fwp_main_thread+0xa81>
    79f2:	48 89 df             	mov    %rbx,%rdi
    79f5:	e8 96 c3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    79fa:	e9 d2 ef ff ff       	jmp    69d1 <fwp_main_thread+0xa81>
    79ff:	90                   	nop
    7a00:	66 85 c0             	test   %ax,%ax
    7a03:	0f 85 5c fa ff ff    	jne    7465 <fwp_main_thread+0x1515>
    7a09:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7a0d:	0f 85 3c fa ff ff    	jne    744f <fwp_main_thread+0x14ff>
    7a13:	4c 89 f7             	mov    %r14,%rdi
    7a16:	e8 75 c3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7a1b:	e9 2f fa ff ff       	jmp    744f <fwp_main_thread+0x14ff>
    7a20:	66 85 c0             	test   %ax,%ax
    7a23:	0f 85 67 fb ff ff    	jne    7590 <fwp_main_thread+0x1640>
    7a29:	e9 3e fb ff ff       	jmp    756c <fwp_main_thread+0x161c>
    7a2e:	66 90                	xchg   %ax,%ax
    7a30:	66 85 c0             	test   %ax,%ax
    7a33:	0f 85 a7 fa ff ff    	jne    74e0 <fwp_main_thread+0x1590>
    7a39:	e9 a5 fc ff ff       	jmp    76e3 <fwp_main_thread+0x1793>
    7a3e:	66 90                	xchg   %ax,%ax
    7a40:	66 85 c0             	test   %ax,%ax
    7a43:	0f 85 93 fd ff ff    	jne    77dc <fwp_main_thread+0x188c>
    7a49:	e9 71 fd ff ff       	jmp    77bf <fwp_main_thread+0x186f>
    7a4e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7a52:	e9 d8 e6 ff ff       	jmp    612f <fwp_main_thread+0x1df>
    7a57:	4c 8b 74 24 70       	mov    0x70(%rsp),%r14
    7a5c:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
    7a61:	e8 1a d2 ff ff       	call   4c80 <fwp_drop0>
    7a66:	4c 89 f7             	mov    %r14,%rdi
    7a69:	e8 12 d2 ff ff       	call   4c80 <fwp_drop0>
    7a6e:	48 c7 05 47 36 00 00 	movq   $0x0,0x3647(%rip)        # b0c0 <v.1>
    7a75:	00 00 00 00 
    7a79:	c7 05 45 36 00 00 01 	movl   $0x1,0x3645(%rip)        # b0c8 <st.2>
    7a80:	00 00 00 
    7a83:	e9 f3 e5 ff ff       	jmp    607b <fwp_main_thread+0x12b>
    7a88:	31 db                	xor    %ebx,%ebx
    7a8a:	e9 62 e7 ff ff       	jmp    61f1 <fwp_main_thread+0x2a1>
    7a8f:	66 85 c0             	test   %ax,%ax
    7a92:	0f 85 c8 ec ff ff    	jne    6760 <fwp_main_thread+0x810>
    7a98:	e9 b7 ec ff ff       	jmp    6754 <fwp_main_thread+0x804>
    7a9d:	66 85 c0             	test   %ax,%ax
    7aa0:	0f 85 08 ee ff ff    	jne    68ae <fwp_main_thread+0x95e>
    7aa6:	e9 e9 ed ff ff       	jmp    6894 <fwp_main_thread+0x944>
    7aab:	66 85 c0             	test   %ax,%ax
    7aae:	0f 85 47 ed ff ff    	jne    67fb <fwp_main_thread+0x8ab>
    7ab4:	e9 36 ed ff ff       	jmp    67ef <fwp_main_thread+0x89f>
    7ab9:	4c 89 ff             	mov    %r15,%rdi
    7abc:	e8 cf c2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7ac1:	e9 5a eb ff ff       	jmp    6620 <fwp_main_thread+0x6d0>
    7ac6:	48 89 da             	mov    %rbx,%rdx
    7ac9:	48 c1 ea 11          	shr    $0x11,%rdx
    7acd:	48 31 da             	xor    %rbx,%rdx
    7ad0:	48 89 d0             	mov    %rdx,%rax
    7ad3:	48 c1 e8 09          	shr    $0x9,%rax
    7ad7:	48 31 c2             	xor    %rax,%rdx
    7ada:	0f b6 d2             	movzbl %dl,%edx
    7add:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    7ae4:	00 
    7ae5:	48 85 c0             	test   %rax,%rax
    7ae8:	75 23                	jne    7b0d <fwp_main_thread+0x1bbd>
    7aea:	e9 7a 03 00 00       	jmp    7e69 <fwp_main_thread+0x1f19>
    7aef:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7af5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7afc:	00 00 00 00 
    7b00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7b04:	48 85 c0             	test   %rax,%rax
    7b07:	0f 84 5c 03 00 00    	je     7e69 <fwp_main_thread+0x1f19>
    7b0d:	48 89 c2             	mov    %rax,%rdx
    7b10:	48 3b 18             	cmp    (%rax),%rbx
    7b13:	75 eb                	jne    7b00 <fwp_main_thread+0x1bb0>
    7b15:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7b19:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    7b1d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7b21:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7b28:	0f 85 72 f6 ff ff    	jne    71a0 <fwp_main_thread+0x1250>
    7b2e:	48 89 df             	mov    %rbx,%rdi
    7b31:	e8 5a c2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7b36:	c6 03 fe             	movb   $0xfe,(%rbx)
    7b39:	e9 62 f6 ff ff       	jmp    71a0 <fwp_main_thread+0x1250>
    7b3e:	4c 89 cf             	mov    %r9,%rdi
    7b41:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    7b46:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    7b4b:	66 0f d6 4c 24 48    	movq   %xmm1,0x48(%rsp)
    7b51:	66 0f d6 44 24 40    	movq   %xmm0,0x40(%rsp)
    7b57:	f2 0f 11 6c 24 38    	movsd  %xmm5,0x38(%rsp)
    7b5d:	e8 2e c2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7b62:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    7b67:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    7b6c:	f2 0f 10 6c 24 38    	movsd  0x38(%rsp),%xmm5
    7b72:	f3 0f 7e 44 24 40    	movq   0x40(%rsp),%xmm0
    7b78:	41 c6 01 fe          	movb   $0xfe,(%r9)
    7b7c:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    7b83:	f2 41 0f 10 67 08    	movsd  0x8(%r15),%xmm4
    7b89:	f3 41 0f 7e 5f 10    	movq   0x10(%r15),%xmm3
    7b8f:	49 8b bd b0 13 00 00 	mov    0x13b0(%r13),%rdi
    7b96:	f3 0f 7e 4c 24 48    	movq   0x48(%rsp),%xmm1
    7b9c:	48 c1 e0 10          	shl    $0x10,%rax
    7ba0:	e9 9b f2 ff ff       	jmp    6e40 <fwp_main_thread+0xef0>
    7ba5:	4c 89 f0             	mov    %r14,%rax
    7ba8:	48 c1 e8 11          	shr    $0x11,%rax
    7bac:	4c 31 f0             	xor    %r14,%rax
    7baf:	48 89 c2             	mov    %rax,%rdx
    7bb2:	48 c1 ea 09          	shr    $0x9,%rdx
    7bb6:	48 31 d0             	xor    %rdx,%rax
    7bb9:	0f b6 d0             	movzbl %al,%edx
    7bbc:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    7bc3:	00 
    7bc4:	48 85 c0             	test   %rax,%rax
    7bc7:	75 24                	jne    7bed <fwp_main_thread+0x1c9d>
    7bc9:	e9 9b 02 00 00       	jmp    7e69 <fwp_main_thread+0x1f19>
    7bce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bdc:	00 00 00 00 
    7be0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	0f 84 7c 02 00 00    	je     7e69 <fwp_main_thread+0x1f19>
    7bed:	48 89 c2             	mov    %rax,%rdx
    7bf0:	4c 3b 30             	cmp    (%rax),%r14
    7bf3:	75 eb                	jne    7be0 <fwp_main_thread+0x1c90>
    7bf5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7bf9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    7bfd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c01:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c08:	0f 85 d2 f8 ff ff    	jne    74e0 <fwp_main_thread+0x1590>
    7c0e:	4c 89 f7             	mov    %r14,%rdi
    7c11:	e8 7a c1 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7c16:	41 c6 06 fe          	movb   $0xfe,(%r14)
    7c1a:	e9 c1 f8 ff ff       	jmp    74e0 <fwp_main_thread+0x1590>
    7c1f:	48 8b 3d 92 57 01 00 	mov    0x15792(%rip),%rdi        # 1d3b8 <fwp_state>
    7c26:	e8 a5 c3 ff ff       	call   3fd0 <fwp_mem_free>
    7c2b:	48 c7 05 82 57 01 00 	movq   $0x0,0x15782(%rip)        # 1d3b8 <fwp_state>
    7c32:	00 00 00 00 
    7c36:	48 c7 05 67 57 01 00 	movq   $0x0,0x15767(%rip)        # 1d3a8 <fwp_state_cap>
    7c3d:	00 00 00 00 
    7c41:	48 85 db             	test   %rbx,%rbx
    7c44:	0f 84 70 01 00 00    	je     7dba <fwp_main_thread+0x1e6a>
    7c4a:	48 39 1d c7 3a 01 00 	cmp    %rbx,0x13ac7(%rip)        # 1b718 <fwp_root>
    7c51:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    7c58:	00 00 00 00 
    7c5c:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    7c63:	00 00 00 00 
    7c67:	c7 05 6f 34 01 00 00 	movl   $0x0,0x1346f(%rip)        # 1b0e0 <fwp_exit_code>
    7c6e:	00 00 00 
    7c71:	0f 84 a4 e5 ff ff    	je     621b <fwp_main_thread+0x2cb>
    7c77:	e9 8f aa ff ff       	jmp    270b <fwp_main_thread.cold>
    7c7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c80:	48 89 da             	mov    %rbx,%rdx
    7c83:	48 c1 ea 11          	shr    $0x11,%rdx
    7c87:	48 31 da             	xor    %rbx,%rdx
    7c8a:	48 89 d0             	mov    %rdx,%rax
    7c8d:	48 c1 e8 09          	shr    $0x9,%rax
    7c91:	48 31 c2             	xor    %rax,%rdx
    7c94:	0f b6 d2             	movzbl %dl,%edx
    7c97:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    7c9e:	00 
    7c9f:	48 85 c0             	test   %rax,%rax
    7ca2:	75 29                	jne    7ccd <fwp_main_thread+0x1d7d>
    7ca4:	e9 c0 01 00 00       	jmp    7e69 <fwp_main_thread+0x1f19>
    7ca9:	90                   	nop
    7caa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cb1:	00 00 00 00 
    7cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cbc:	00 00 00 00 
    7cc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7cc4:	48 85 c0             	test   %rax,%rax
    7cc7:	0f 84 9c 01 00 00    	je     7e69 <fwp_main_thread+0x1f19>
    7ccd:	48 89 c2             	mov    %rax,%rdx
    7cd0:	48 3b 18             	cmp    (%rax),%rbx
    7cd3:	75 eb                	jne    7cc0 <fwp_main_thread+0x1d70>
    7cd5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7cd9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    7cdd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7ce1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ce8:	0f 85 a2 f8 ff ff    	jne    7590 <fwp_main_thread+0x1640>
    7cee:	48 89 df             	mov    %rbx,%rdi
    7cf1:	e8 9a c0 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7cf6:	c6 03 fe             	movb   $0xfe,(%rbx)
    7cf9:	e9 92 f8 ff ff       	jmp    7590 <fwp_main_thread+0x1640>
    7cfe:	48 89 d9             	mov    %rbx,%rcx
    7d01:	48 c1 e9 11          	shr    $0x11,%rcx
    7d05:	48 31 d9             	xor    %rbx,%rcx
    7d08:	48 89 ca             	mov    %rcx,%rdx
    7d0b:	48 c1 ea 09          	shr    $0x9,%rdx
    7d0f:	48 31 d1             	xor    %rdx,%rcx
    7d12:	0f b6 c9             	movzbl %cl,%ecx
    7d15:	49 8d ac cd 48 14 00 	lea    0x1448(%r13,%rcx,8),%rbp
    7d1c:	00 
    7d1d:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    7d21:	49 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%r13,%rcx,8)
    7d28:	00 00 
    7d2a:	75 20                	jne    7d4c <fwp_main_thread+0x1dfc>
    7d2c:	e9 ee 00 00 00       	jmp    7e1f <fwp_main_thread+0x1ecf>
    7d31:	0f 1f 40 00          	nopl   0x0(%rax)
    7d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d3c:	00 00 00 00 
    7d40:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7d44:	48 85 c9             	test   %rcx,%rcx
    7d47:	74 2b                	je     7d74 <fwp_main_thread+0x1e24>
    7d49:	48 89 ca             	mov    %rcx,%rdx
    7d4c:	48 39 1a             	cmp    %rbx,(%rdx)
    7d4f:	75 ef                	jne    7d40 <fwp_main_thread+0x1df0>
    7d51:	3c fe                	cmp    $0xfe,%al
    7d53:	0f 84 d3 00 00 00    	je     7e2c <fwp_main_thread+0x1edc>
    7d59:	48 8b 42 08          	mov    0x8(%rdx),%rax
    7d5d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    7d61:	0f 84 e5 00 00 00    	je     7e4c <fwp_main_thread+0x1efc>
    7d67:	48 83 c0 01          	add    $0x1,%rax
    7d6b:	48 89 42 08          	mov    %rax,0x8(%rdx)
    7d6f:	e9 ba eb ff ff       	jmp    692e <fwp_main_thread+0x9de>
    7d74:	3c fe                	cmp    $0xfe,%al
    7d76:	0f 85 ed 00 00 00    	jne    7e69 <fwp_main_thread+0x1f19>
    7d7c:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    7d80:	bf 18 00 00 00       	mov    $0x18,%edi
    7d85:	e8 f6 a7 ff ff       	call   2580 <malloc@plt>
    7d8a:	48 85 c0             	test   %rax,%rax
    7d8d:	0f 84 c5 00 00 00    	je     7e58 <fwp_main_thread+0x1f08>
    7d93:	48 89 18             	mov    %rbx,(%rax)
    7d96:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    7d9d:	00 
    7d9e:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    7da5:	00 
    7da6:	48 89 45 00          	mov    %rax,0x0(%rbp)
    7daa:	c6 03 ff             	movb   $0xff,(%rbx)
    7dad:	49 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%r13)
    7db4:	01 
    7db5:	e9 74 eb ff ff       	jmp    692e <fwp_main_thread+0x9de>
    7dba:	48 83 3d 56 39 01 00 	cmpq   $0x0,0x13956(%rip)        # 1b718 <fwp_root>
    7dc1:	00 
    7dc2:	c7 05 14 33 01 00 00 	movl   $0x0,0x13314(%rip)        # 1b0e0 <fwp_exit_code>
    7dc9:	00 00 00 
    7dcc:	0f 84 a4 e4 ff ff    	je     6276 <fwp_main_thread+0x326>
    7dd2:	e9 34 a9 ff ff       	jmp    270b <fwp_main_thread.cold>
    7dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dde:	00 00 
    7de0:	48 89 df             	mov    %rbx,%rdi
    7de3:	e8 a8 bf ff ff       	call   3d90 <fwp_rc_forget_slot>
    7de8:	e9 b0 ea ff ff       	jmp    689d <fwp_main_thread+0x94d>
    7ded:	48 89 df             	mov    %rbx,%rdi
    7df0:	e8 9b bf ff ff       	call   3d90 <fwp_rc_forget_slot>
    7df5:	e9 63 e9 ff ff       	jmp    675d <fwp_main_thread+0x80d>
    7dfa:	48 89 df             	mov    %rbx,%rdi
    7dfd:	e8 8e bf ff ff       	call   3d90 <fwp_rc_forget_slot>
    7e02:	e9 f1 e9 ff ff       	jmp    67f8 <fwp_main_thread+0x8a8>
    7e07:	48 8d 3d f2 14 00 00 	lea    0x14f2(%rip),%rdi        # 9300 <_IO_stdin_used+0x300>
    7e0e:	e8 9d b2 ff ff       	call   30b0 <fwp_trap>
    7e13:	48 8d 3d 8b 12 00 00 	lea    0x128b(%rip),%rdi        # 90a5 <_IO_stdin_used+0xa5>
    7e1a:	e8 91 b2 ff ff       	call   30b0 <fwp_trap>
    7e1f:	3c fe                	cmp    $0xfe,%al
    7e21:	75 3d                	jne    7e60 <fwp_main_thread+0x1f10>
    7e23:	48 85 d2             	test   %rdx,%rdx
    7e26:	0f 84 54 ff ff ff    	je     7d80 <fwp_main_thread+0x1e30>
    7e2c:	48 8d 3d a5 14 00 00 	lea    0x14a5(%rip),%rdi        # 92d8 <_IO_stdin_used+0x2d8>
    7e33:	e8 78 b2 ff ff       	call   30b0 <fwp_trap>
    7e38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e3f:	00 
    7e40:	48 8d 3d 69 14 00 00 	lea    0x1469(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    7e47:	e8 64 b2 ff ff       	call   30b0 <fwp_trap>
    7e4c:	48 8d 3d f1 12 00 00 	lea    0x12f1(%rip),%rdi        # 9144 <_IO_stdin_used+0x144>
    7e53:	e8 58 b2 ff ff       	call   30b0 <fwp_trap>
    7e58:	e8 a3 ad ff ff       	call   2c00 <fwp_heap_oom>
    7e5d:	0f 1f 00             	nopl   (%rax)
    7e60:	48 85 d2             	test   %rdx,%rdx
    7e63:	0f 85 f0 fe ff ff    	jne    7d59 <fwp_main_thread+0x1e09>
    7e69:	48 8d 3d 18 14 00 00 	lea    0x1418(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    7e70:	e8 3b b2 ff ff       	call   30b0 <fwp_trap>
    7e75:	e8 c6 a5 ff ff       	call   2440 <__stack_chk_fail@plt>
    7e7a:	48 8d 3d dc 12 00 00 	lea    0x12dc(%rip),%rdi        # 915d <_IO_stdin_used+0x15d>
    7e81:	e8 2a b2 ff ff       	call   30b0 <fwp_trap>
    7e86:	e9 80 a8 ff ff       	jmp    270b <fwp_main_thread.cold>
    7e8b:	e9 7b a8 ff ff       	jmp    270b <fwp_main_thread.cold>

0000000000007e90 <__divmodti4>:
    7e90:	f3 0f 1e fa          	endbr64
    7e94:	55                   	push   %rbp
    7e95:	49 89 f1             	mov    %rsi,%r9
    7e98:	49 89 d2             	mov    %rdx,%r10
    7e9b:	48 89 fe             	mov    %rdi,%rsi
    7e9e:	49 89 cb             	mov    %rcx,%r11
    7ea1:	48 89 e5             	mov    %rsp,%rbp
    7ea4:	41 57                	push   %r15
    7ea6:	41 56                	push   %r14
    7ea8:	41 55                	push   %r13
    7eaa:	41 54                	push   %r12
    7eac:	53                   	push   %rbx
    7ead:	4c 89 c3             	mov    %r8,%rbx
    7eb0:	45 31 c0             	xor    %r8d,%r8d
    7eb3:	4d 85 c9             	test   %r9,%r9
    7eb6:	79 12                	jns    7eca <__divmodti4+0x3a>
    7eb8:	31 ff                	xor    %edi,%edi
    7eba:	48 f7 de             	neg    %rsi
    7ebd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    7ec4:	4c 19 cf             	sbb    %r9,%rdi
    7ec7:	49 89 f9             	mov    %rdi,%r9
    7eca:	4c 89 d8             	mov    %r11,%rax
    7ecd:	4d 85 db             	test   %r11,%r11
    7ed0:	0f 88 1a 01 00 00    	js     7ff0 <__divmodti4+0x160>
    7ed6:	4c 89 d9             	mov    %r11,%rcx
    7ed9:	49 89 f3             	mov    %rsi,%r11
    7edc:	75 62                	jne    7f40 <__divmodti4+0xb0>
    7ede:	4d 89 c4             	mov    %r8,%r12
    7ee1:	4d 39 d1             	cmp    %r10,%r9
    7ee4:	0f 83 46 01 00 00    	jae    8030 <__divmodti4+0x1a0>
    7eea:	4c 89 d8             	mov    %r11,%rax
    7eed:	4c 89 ca             	mov    %r9,%rdx
    7ef0:	49 f7 f2             	div    %r10
    7ef3:	49 89 c3             	mov    %rax,%r11
    7ef6:	31 c0                	xor    %eax,%eax
    7ef8:	48 89 d6             	mov    %rdx,%rsi
    7efb:	31 ff                	xor    %edi,%edi
    7efd:	4c 89 d9             	mov    %r11,%rcx
    7f00:	48 89 c2             	mov    %rax,%rdx
    7f03:	48 89 c8             	mov    %rcx,%rax
    7f06:	4d 85 e4             	test   %r12,%r12
    7f09:	74 0a                	je     7f15 <__divmodti4+0x85>
    7f0b:	48 f7 d8             	neg    %rax
    7f0e:	48 83 d2 00          	adc    $0x0,%rdx
    7f12:	48 f7 da             	neg    %rdx
    7f15:	4d 85 c0             	test   %r8,%r8
    7f18:	74 0a                	je     7f24 <__divmodti4+0x94>
    7f1a:	48 f7 de             	neg    %rsi
    7f1d:	48 83 d7 00          	adc    $0x0,%rdi
    7f21:	48 f7 df             	neg    %rdi
    7f24:	48 89 33             	mov    %rsi,(%rbx)
    7f27:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    7f2b:	5b                   	pop    %rbx
    7f2c:	41 5c                	pop    %r12
    7f2e:	41 5d                	pop    %r13
    7f30:	41 5e                	pop    %r14
    7f32:	41 5f                	pop    %r15
    7f34:	5d                   	pop    %rbp
    7f35:	c3                   	ret
    7f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f3d:	00 00 00 
    7f40:	4d 89 c4             	mov    %r8,%r12
    7f43:	49 39 c1             	cmp    %rax,%r9
    7f46:	0f 82 ce 00 00 00    	jb     801a <__divmodti4+0x18a>
    7f4c:	31 ff                	xor    %edi,%edi
    7f4e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    7f53:	48 63 c7             	movslq %edi,%rax
    7f56:	be 40 00 00 00       	mov    $0x40,%esi
    7f5b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    7f60:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    7f65:	48 29 c6             	sub    %rax,%rsi
    7f68:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    7f6d:	48 09 c8             	or     %rcx,%rax
    7f70:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    7f75:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    7f7a:	49 89 c6             	mov    %rax,%r14
    7f7d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    7f81:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    7f86:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    7f8b:	49 09 c1             	or     %rax,%r9
    7f8e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    7f92:	4c 89 c8             	mov    %r9,%rax
    7f95:	49 f7 f6             	div    %r14
    7f98:	48 89 d1             	mov    %rdx,%rcx
    7f9b:	49 89 c3             	mov    %rax,%r11
    7f9e:	49 89 c1             	mov    %rax,%r9
    7fa1:	49 f7 e2             	mul    %r10
    7fa4:	49 89 c6             	mov    %rax,%r14
    7fa7:	49 89 d2             	mov    %rdx,%r10
    7faa:	48 39 d1             	cmp    %rdx,%rcx
    7fad:	72 07                	jb     7fb6 <__divmodti4+0x126>
    7faf:	75 17                	jne    7fc8 <__divmodti4+0x138>
    7fb1:	49 39 c7             	cmp    %rax,%r15
    7fb4:	73 12                	jae    7fc8 <__divmodti4+0x138>
    7fb6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    7fba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    7fbe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    7fc2:	49 89 d2             	mov    %rdx,%r10
    7fc5:	49 89 c6             	mov    %rax,%r14
    7fc8:	4c 89 f8             	mov    %r15,%rax
    7fcb:	4c 29 f0             	sub    %r14,%rax
    7fce:	4c 19 d1             	sbb    %r10,%rcx
    7fd1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    7fd6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    7fdb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    7fe0:	48 09 c6             	or     %rax,%rsi
    7fe3:	48 89 cf             	mov    %rcx,%rdi
    7fe6:	31 c0                	xor    %eax,%eax
    7fe8:	4c 89 c9             	mov    %r9,%rcx
    7feb:	e9 10 ff ff ff       	jmp    7f00 <__divmodti4+0x70>
    7ff0:	4c 89 d0             	mov    %r10,%rax
    7ff3:	4c 89 da             	mov    %r11,%rdx
    7ff6:	4d 89 c4             	mov    %r8,%r12
    7ff9:	49 89 f3             	mov    %rsi,%r11
    7ffc:	48 f7 d8             	neg    %rax
    7fff:	49 f7 d4             	not    %r12
    8002:	48 83 d2 00          	adc    $0x0,%rdx
    8006:	49 89 c2             	mov    %rax,%r10
    8009:	48 f7 da             	neg    %rdx
    800c:	48 89 d1             	mov    %rdx,%rcx
    800f:	0f 84 cc fe ff ff    	je     7ee1 <__divmodti4+0x51>
    8015:	49 39 d1             	cmp    %rdx,%r9
    8018:	73 46                	jae    8060 <__divmodti4+0x1d0>
    801a:	4c 89 cf             	mov    %r9,%rdi
    801d:	31 c0                	xor    %eax,%eax
    801f:	31 c9                	xor    %ecx,%ecx
    8021:	e9 da fe ff ff       	jmp    7f00 <__divmodti4+0x70>
    8026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    802d:	00 00 00 
    8030:	4d 85 d2             	test   %r10,%r10
    8033:	75 0d                	jne    8042 <__divmodti4+0x1b2>
    8035:	b8 01 00 00 00       	mov    $0x1,%eax
    803a:	31 d2                	xor    %edx,%edx
    803c:	49 f7 f2             	div    %r10
    803f:	49 89 c2             	mov    %rax,%r10
    8042:	4c 89 c8             	mov    %r9,%rax
    8045:	31 d2                	xor    %edx,%edx
    8047:	49 f7 f2             	div    %r10
    804a:	49 89 c1             	mov    %rax,%r9
    804d:	4c 89 d8             	mov    %r11,%rax
    8050:	49 f7 f2             	div    %r10
    8053:	49 89 c3             	mov    %rax,%r11
    8056:	4c 89 c8             	mov    %r9,%rax
    8059:	e9 9a fe ff ff       	jmp    7ef8 <__divmodti4+0x68>
    805e:	66 90                	xchg   %ax,%ax
    8060:	45 31 f6             	xor    %r14d,%r14d
    8063:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    8068:	44 89 f7             	mov    %r14d,%edi
    806b:	45 85 f6             	test   %r14d,%r14d
    806e:	0f 85 df fe ff ff    	jne    7f53 <__divmodti4+0xc3>
    8074:	4c 39 ca             	cmp    %r9,%rdx
    8077:	72 17                	jb     8090 <__divmodti4+0x200>
    8079:	31 c9                	xor    %ecx,%ecx
    807b:	48 39 c6             	cmp    %rax,%rsi
    807e:	73 10                	jae    8090 <__divmodti4+0x200>
    8080:	4c 89 cf             	mov    %r9,%rdi
    8083:	31 c0                	xor    %eax,%eax
    8085:	e9 76 fe ff ff       	jmp    7f00 <__divmodti4+0x70>
    808a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8090:	4c 89 de             	mov    %r11,%rsi
    8093:	b9 01 00 00 00       	mov    $0x1,%ecx
    8098:	48 29 c6             	sub    %rax,%rsi
    809b:	49 19 d1             	sbb    %rdx,%r9
    809e:	eb e0                	jmp    8080 <__divmodti4+0x1f0>

00000000000080a0 <atexit>:
    80a0:	f3 0f 1e fa          	endbr64
    80a4:	48 8b 15 5d 2f 00 00 	mov    0x2f5d(%rip),%rdx        # b008 <__dso_handle>
    80ab:	31 f6                	xor    %esi,%esi
    80ad:	e9 6e a5 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000080b4 <_fini>:
    80b4:	f3 0f 1e fa          	endbr64
    80b8:	48 83 ec 08          	sub    $0x8,%rsp
    80bc:	48 83 c4 08          	add    $0x8,%rsp
    80c0:	c3                   	ret
