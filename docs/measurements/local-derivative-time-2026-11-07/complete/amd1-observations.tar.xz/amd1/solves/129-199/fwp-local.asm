
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 af 00 00 	mov    0xafd9(%rip),%rax        # cfe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 ae 00 00    	push   0xae02(%rip)        # ce28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 ae 00 00    	jmp    *0xae04(%rip)        # ce30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e ac 00 00    	jmp    *0xac7e(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae aa 00 00    	jmp    *0xaaae(%rip)        # ce38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 aa 00 00    	jmp    *0xaaa6(%rip)        # ce40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e aa 00 00    	jmp    *0xaa9e(%rip)        # ce48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 aa 00 00    	jmp    *0xaa96(%rip)        # ce50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e aa 00 00    	jmp    *0xaa8e(%rip)        # ce58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 aa 00 00    	jmp    *0xaa86(%rip)        # ce60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e aa 00 00    	jmp    *0xaa7e(%rip)        # ce68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 aa 00 00    	jmp    *0xaa76(%rip)        # ce70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e aa 00 00    	jmp    *0xaa6e(%rip)        # ce78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 aa 00 00    	jmp    *0xaa66(%rip)        # ce80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e aa 00 00    	jmp    *0xaa5e(%rip)        # ce88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 aa 00 00    	jmp    *0xaa56(%rip)        # ce90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e aa 00 00    	jmp    *0xaa4e(%rip)        # ce98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 aa 00 00    	jmp    *0xaa46(%rip)        # cea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e aa 00 00    	jmp    *0xaa3e(%rip)        # cea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 aa 00 00    	jmp    *0xaa36(%rip)        # ceb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e aa 00 00    	jmp    *0xaa2e(%rip)        # ceb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 aa 00 00    	jmp    *0xaa26(%rip)        # cec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e aa 00 00    	jmp    *0xaa1e(%rip)        # cec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 aa 00 00    	jmp    *0xaa16(%rip)        # ced0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e aa 00 00    	jmp    *0xaa0e(%rip)        # ced8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 aa 00 00    	jmp    *0xaa06(%rip)        # cee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe a9 00 00    	jmp    *0xa9fe(%rip)        # cee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 a9 00 00    	jmp    *0xa9f6(%rip)        # cef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee a9 00 00    	jmp    *0xa9ee(%rip)        # cef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 a9 00 00    	jmp    *0xa9e6(%rip)        # cf00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de a9 00 00    	jmp    *0xa9de(%rip)        # cf08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 a9 00 00    	jmp    *0xa9d6(%rip)        # cf10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce a9 00 00    	jmp    *0xa9ce(%rip)        # cf18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 a9 00 00    	jmp    *0xa9c6(%rip)        # cf20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be a9 00 00    	jmp    *0xa9be(%rip)        # cf28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 a9 00 00    	jmp    *0xa9b6(%rip)        # cf30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae a9 00 00    	jmp    *0xa9ae(%rip)        # cf38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 a9 00 00    	jmp    *0xa9a6(%rip)        # cf40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e a9 00 00    	jmp    *0xa99e(%rip)        # cf48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 a9 00 00    	jmp    *0xa996(%rip)        # cf50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e a9 00 00    	jmp    *0xa98e(%rip)        # cf58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 a9 00 00    	jmp    *0xa986(%rip)        # cf60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e a9 00 00    	jmp    *0xa97e(%rip)        # cf68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 a9 00 00    	jmp    *0xa976(%rip)        # cf70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e a9 00 00    	jmp    *0xa96e(%rip)        # cf78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 a9 00 00    	jmp    *0xa966(%rip)        # cf80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e a9 00 00    	jmp    *0xa95e(%rip)        # cf88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 a9 00 00    	jmp    *0xa956(%rip)        # cf90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e a9 00 00    	jmp    *0xa94e(%rip)        # cf98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 a9 00 00    	jmp    *0xa946(%rip)        # cfa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e a9 00 00    	jmp    *0xa93e(%rip)        # cfa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 a9 00 00    	jmp    *0xa936(%rip)        # cfb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e a9 00 00    	jmp    *0xa92e(%rip)        # cfb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 a9 00 00    	jmp    *0xa926(%rip)        # cfc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e a9 00 00    	jmp    *0xa91e(%rip)        # cfc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 a9 00 00    	jmp    *0xa916(%rip)        # cfd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 89 00 00 	lea    0x89a0(%rip),%r9        # b077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 89 00 00 	lea    0x899d(%rip),%r8        # b07b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 41 a9 00 00 	mov    0xa941(%rip),%rax        # d080 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 52 cc 01 00 	mov    %rax,0x1cc52(%rip)        # 1f398 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 8a 00 00 	lea    0x8a1c(%rip),%rdi        # b16e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d c6 a8 00 00 	mov    0xa8c6(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 bd 7a 00 00 	lea    0x7abd(%rip),%rdx        # a2d0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 31 a8 00 00 	mov    0xa831(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 86 a8 01 00    	mov    0x1a886(%rip),%eax        # 1d0e0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 88 00 00 	lea    0x88cc(%rip),%rdi        # b177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 8a 00 00 	lea    0x8aec(%rip),%rdi        # b3a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d a6 8a 00 00 	lea    0x8aa6(%rip),%rdi        # b380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 8a 00 00 	lea    0x8a6a(%rip),%rdi        # b350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 8a 00 00 	lea    0x8a36(%rip),%rdi        # b328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 a6 00 00    	call   *0xa6b3(%rip)        # cfd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 31 a7 00 00 	lea    0xa731(%rip),%rdi        # d068 <__TMC_END__>
    2937:	48 8d 05 2a a7 00 00 	lea    0xa72a(%rip),%rax        # d068 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 a6 00 00 	mov    0xa696(%rip),%rax        # cfe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d 01 a7 00 00 	lea    0xa701(%rip),%rdi        # d068 <__TMC_END__>
    2967:	48 8d 35 fa a6 00 00 	lea    0xa6fa(%rip),%rsi        # d068 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 a6 00 00 	mov    0xa665(%rip),%rax        # cff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d fd a6 00 00 00 	cmpb   $0x0,0xa6fd(%rip)        # d0a8 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 a6 00 00 	cmpq   $0x0,0xa642(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 a6 00 00 	mov    0xa646(%rip),%rdi        # d008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 d5 a6 00 00 01 	movb   $0x1,0xa6d5(%rip)        # d0a8 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d d1 c7 01 00 	mov    0x1c7d1(%rip),%rdi        # 1f398 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d a4 a4 00 00 	mov    0xa4a4(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 91 a4 00 00 	mov    0xa491(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 83 00 00 	lea    0x83f5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 82 a4 00 00 	mov    0xa482(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 d1 aa 01 00 	mov    0x1aad1(%rip),%rax        # 1d720 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 21 a4 01 00 	mov    0x1a421(%rip),%rax        # 1d0f0 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 0d a4 01 00 	sub    0x1a40d(%rip),%rax        # 1d0e8 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 87 00 00 	lea    0x872d(%rip),%rsi        # b440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 eb bd 01 00 	mov    0x1bdeb(%rip),%rax        # 1eb30 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 e4 bd 01 00 	lea    0x1bde4(%rip),%r8        # 1eb30 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d c5 bd 01 00 	mov    0x1bdc5(%rip),%rbx        # 1eb18 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d d5 bd 01 00 	mov    0x1bdd5(%rip),%rcx        # 1eb38 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 71 bd 01 00 	mov    0x1bd71(%rip),%rdi        # 1eb20 <fwp_heap+0x13e0>
    2daf:	48 29 35 ba bd 01 00 	sub    %rsi,0x1bdba(%rip)        # 1eb70 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 4a bd 01 00 	mov    0x1bd4a(%rip),%rax        # 1eb10 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 00 bd 01 00 	add    0x1bd00(%rip),%rdi        # 1eaf0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 0e bd 01 00 	mov    0x1bd0e(%rip),%rsi        # 1eb20 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 1c bd 01 00 	mov    0x1bd1c(%rip),%rax        # 1eb38 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 cb bc 01 00 	mov    %r12,0x1bccb(%rip)        # 1eb20 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d b9 bc 01 00 	mov    %rbp,0x1bcb9(%rip)        # 1eb18 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 9e bc 01 00 	cmp    %rdi,0x1bc9e(%rip)        # 1eb08 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 95 bc 01 00 	mov    %rdi,0x1bc95(%rip)        # 1eb08 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d d9 bc 01 00 	sub    %rdi,0x1bcd9(%rip)        # 1eb70 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 81 bc 01 00 	mov    0x1bc81(%rip),%rax        # 1eb28 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 7a bc 01 00 	lea    0x1bc7a(%rip),%r8        # 1eb28 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d 4d a1 00 00 	mov    0xa14d(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 80 00 00 	lea    0x80a4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d 59 a7 01 00 	cmp    0x1a759(%rip),%rdi        # 1d720 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 1f a7 01 00 	mov    0x1a71f(%rip),%rax        # 1d700 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d fd a6 01 00 	mov    %rdi,0x1a6fd(%rip)        # 1d700 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d d9 a6 01 00 	mov    %rdi,0x1a6d9(%rip)        # 1d708 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 80 00 00 	lea    0x8051(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 7f 00 00 	lea    0x7f97(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d d6 9f 00 00 	mov    0x9fd6(%rip),%rdi        # d0a0 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 7f 00 00 	lea    0x7f4f(%rip),%rdx        # b020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 7e 00 00 	lea    0x7ed0(%rip),%rdi        # b02f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 80 00 00 	lea    0x8030(%rip),%rdi        # b1a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 7e 00 00 	lea    0x7eb8(%rip),%r8        # b04b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 7d 00 00 	lea    0x7d0d(%rip),%r8        # b05a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 7b 00 00 	lea    0x7b9a(%rip),%r8        # b050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 79 00 00 	lea    0x7972(%rip),%rdi        # b05f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 79 00 00 	lea    0x79fc(%rip),%rsi        # b10a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 85 b3 01 00 	mov    0x1b385(%rip),%r9        # 1eb08 <fwp_heap+0x13c8>
    3783:	4c 8b 05 de b3 01 00 	mov    0x1b3de(%rip),%r8        # 1eb68 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 7a 00 00 	lea    0x7a3f(%rip),%rdx        # b1d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d c6 b3 01 00 	mov    0x1b3c6(%rip),%rcx        # 1eb60 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d d4 b3 01 	movsd  0x1b3d4(%rip),%xmm1        # 1eb80 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 c4 b3 01 	movsd  0x1b3c4(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d e5 98 00 00 	mov    0x98e5(%rip),%rdi        # d0a0 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 7c 00 	movdqa 0x7c68(%rip),%xmm0        # b460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 7f ae 01 00 	lea    0x1ae7f(%rip),%rax        # 1e680 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 7c 00 	movdqa 0x7c91(%rip),%xmm2        # b4a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 25 ae 01 00 	movaps %xmm0,0x1ae25(%rip)        # 1e640 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 7c 00 	movdqa 0x7c4d(%rip),%xmm0        # b470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 b3 b2 01 00 01 	movl   $0x1,0x1b2b3(%rip)        # 1eae4 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 13 ae 01 00 	movaps %xmm0,0x1ae13(%rip)        # 1e650 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 7c 00 	movdqa 0x7c3b(%rip),%xmm0        # b480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 14 ae 01 00 	movaps %xmm0,0x1ae14(%rip)        # 1e660 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 7c 00 	movdqa 0x7c3c(%rip),%xmm0        # b490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 15 ae 01 00 	movaps %xmm0,0x1ae15(%rip)        # 1e670 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 95 9e 01 00 	lea    0x19e95(%rip),%r8        # 1d740 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 b0 b1 01 00 	mov    %rax,0x1b1b0(%rip)        # 1eaf8 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 8e b1 01 00 	mov    %r12,0x1b18e(%rip)        # 1eb00 <fwp_heap+0x13c0>
    3972:	48 89 05 77 b1 01 00 	mov    %rax,0x1b177(%rip)        # 1eaf0 <fwp_heap+0x13b0>
    3979:	48 89 1d 90 b1 01 00 	mov    %rbx,0x1b190(%rip)        # 1eb10 <fwp_heap+0x13d0>
    3980:	48 89 35 b9 b1 01 00 	mov    %rsi,0x1b1b9(%rip)        # 1eb40 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 76 00 00 	lea    0x76fc(%rip),%rdi        # b095 <_IO_stdin_used+0x95>
    3999:	48 89 05 98 b1 01 00 	mov    %rax,0x1b198(%rip)        # 1eb38 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 1c b1 01 00    	mov    %eax,0x1b11c(%rip)        # 1eae8 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 0c 9d 01 00 	mov    0x19d0c(%rip),%r8        # 1d700 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d 3c 9c 01 00 	mov    %rbx,0x19c3c(%rip)        # 1d708 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 28 9c 01 00 	mov    %r8,0x19c28(%rip)        # 1d700 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d e7 9b 01 00 	mov    0x19be7(%rip),%rbx        # 1d6f8 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 8a 94 00 00 	mov    0x948a(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 76 00 00 	lea    0x763b(%rip),%rdi        # b258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 ad 9a 01 00 	mov    0x19aad(%rip),%rax        # 1d700 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 87 9a 01 00 	mov    %rdx,0x19a87(%rip)        # 1d700 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d d4 99 01 00 	mov    0x199d4(%rip),%rbx        # 1d6f8 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 91 99 01 00 	mov    %rbx,0x19991(%rip)        # 1d6f8 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 91 99 01 00 	mov    %rdx,0x19991(%rip)        # 1d708 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 7e 99 01 00 	lea    0x1997e(%rip),%rcx        # 1d740 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 7f b5 01 00 	subq   $0x1,0x1b57f(%rip)        # 1f388 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 74 00 00 	lea    0x7473(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 60 b5 01 00 	cmpq   $0x0,0x1b560(%rip)        # 1f388 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 b5 b4 01 00 	sub    %rax,0x1b4b5(%rip)        # 1f390 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 93 b4 01 00 	add    %r12,0x1b493(%rip)        # 1f390 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 ef ab 01 00 	mov    0x1abef(%rip),%rax        # 1eb38 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 ec 97 01 00 	lea    0x197ec(%rip),%rax        # 1d740 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 43 ab 01 00 	add    0x1ab43(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 10 ab 01 00 	mov    0x1ab10(%rip),%rsi        # 1eaf0 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 31 ab 01 00 	mov    0x1ab31(%rip),%rax        # 1eb18 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 25 ab 01 00 	add    0x1ab25(%rip),%r8        # 1eb38 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 ed aa 01 	addsd  0x1aaed(%rip),%xmm0        # 1eb80 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 a2 96 01 00 	lea    0x196a2(%rip),%rax        # 1d740 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d ac aa 01 00 	sub    %rdi,0x1aaac(%rip)        # 1eb60 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 c4 aa 01 	movsd  %xmm0,0x1aac4(%rip)        # 1eb80 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 7e aa 01 00 	sub    %rdx,0x1aa7e(%rip)        # 1eb60 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 84 aa 01 	addsd  0x1aa84(%rip),%xmm0        # 1eb80 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 78 aa 01 	movsd  %xmm0,0x1aa78(%rip)        # 1eb80 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 0f aa 01 00 	mov    0x1aa0f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d 09 aa 01 00 	add    %rcx,0x1aa09(%rip)        # 1eb70 <fwp_heap+0x1430>
    4167:	4c 3b 0d c2 a9 01 00 	cmp    0x1a9c2(%rip),%r9        # 1eb30 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d b9 a9 01 00 	mov    %r9,0x1a9b9(%rip)        # 1eb30 <fwp_heap+0x13f0>
    4177:	4c 3b 0d aa a9 01 00 	cmp    0x1a9aa(%rip),%r9        # 1eb28 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 9d a9 01 00 	mov    %r9,0x1a99d(%rip)        # 1eb28 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d b3 a8 01 00 	add    0x1a8b3(%rip),%rdi        # 1eb38 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 90 94 01 00 	lea    0x19490(%rip),%r15        # 1d740 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 00 a8 01 00 	add    0x1a800(%rip),%r12        # 1eaf0 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 59 a8 01 00 	add    0x1a859(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 58 a8 01 00 	cmp    %rax,0x1a858(%rip)        # 1eb68 <fwp_heap+0x1428>
    4310:	48 89 05 49 a8 01 00 	mov    %rax,0x1a849(%rip)        # 1eb60 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 48 a8 01 00 	mov    %rax,0x1a848(%rip)        # 1eb68 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 44 a8 01 	addsd  0x1a844(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 3c a8 01 	movsd  %xmm0,0x1a83c(%rip)        # 1eb78 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 83 a7 01 00    	mov    0x1a783(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d bf 93 01 00 	lea    0x193bf(%rip),%rdi        # 1d740 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 78 a7 01 00 	add    0x1a778(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 73 a7 01 00 	cmp    %rax,0x1a773(%rip)        # 1eb68 <fwp_heap+0x1428>
    43f5:	48 89 05 64 a7 01 00 	mov    %rax,0x1a764(%rip)        # 1eb60 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 63 a7 01 00 	mov    %rax,0x1a763(%rip)        # 1eb68 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 5f a7 01 	addsd  0x1a75f(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 57 a7 01 	movsd  %xmm0,0x1a757(%rip)        # 1eb78 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_fresh>:
    44d0:	48 8b 15 41 a6 01 00 	mov    0x1a641(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 89 fe             	mov    %rdi,%rsi
    44dd:	48 2b 05 0c a6 01 00 	sub    0x1a60c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    44e4:	48 c1 e2 10          	shl    $0x10,%rdx
    44e8:	48 39 d0             	cmp    %rdx,%rax
    44eb:	73 4f                	jae    453c <fwp_rc_fresh+0x6c>
    44ed:	48 89 c2             	mov    %rax,%rdx
    44f0:	48 c1 ea 10          	shr    $0x10,%rdx
    44f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f8:	48 8b 15 39 a6 01 00 	mov    0x1a639(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    44ff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4507:	48 85 d2             	test   %rdx,%rdx
    450a:	74 30                	je     453c <fwp_rc_fresh+0x6c>
    450c:	0f b6 39             	movzbl (%rcx),%edi
    450f:	40 80 ff 02          	cmp    $0x2,%dil
    4513:	74 2b                	je     4540 <fwp_rc_fresh+0x70>
    4515:	40 80 ff 01          	cmp    $0x1,%dil
    4519:	75 21                	jne    453c <fwp_rc_fresh+0x6c>
    451b:	8b 79 18             	mov    0x18(%rcx),%edi
    451e:	0f b7 c0             	movzwl %ax,%eax
    4521:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4524:	48 0f af c7          	imul   %rdi,%rax
    4528:	48 c1 e8 20          	shr    $0x20,%rax
    452c:	48 39 c8             	cmp    %rcx,%rax
    452f:	73 0b                	jae    453c <fwp_rc_fresh+0x6c>
    4531:	48 01 c2             	add    %rax,%rdx
    4534:	80 3a ff             	cmpb   $0xff,(%rdx)
    4537:	74 17                	je     4550 <fwp_rc_fresh+0x80>
    4539:	c6 02 01             	movb   $0x1,(%rdx)
    453c:	48 89 f0             	mov    %rsi,%rax
    453f:	c3                   	ret
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ef                	je     4534 <fwp_rc_fresh+0x64>
    4545:	48 89 f0             	mov    %rsi,%rax
    4548:	c3                   	ret
    4549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4550:	48 83 ec 18          	sub    $0x18,%rsp
    4554:	48 89 d7             	mov    %rdx,%rdi
    4557:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    455c:	48 89 14 24          	mov    %rdx,(%rsp)
    4560:	e8 2b f8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4565:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    456a:	48 8b 14 24          	mov    (%rsp),%rdx
    456e:	48 89 f0             	mov    %rsi,%rax
    4571:	c6 02 01             	movb   $0x1,(%rdx)
    4574:	48 83 c4 18          	add    $0x18,%rsp
    4578:	c3                   	ret
    4579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004580 <fwp_rc_free_arr>:
    4580:	48 8b 15 91 a5 01 00 	mov    0x1a591(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4587:	48 89 f8             	mov    %rdi,%rax
    458a:	48 2b 05 5f a5 01 00 	sub    0x1a55f(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4591:	48 c1 e2 10          	shl    $0x10,%rdx
    4595:	48 39 d0             	cmp    %rdx,%rax
    4598:	73 5b                	jae    45f5 <fwp_rc_free_arr+0x75>
    459a:	48 89 c2             	mov    %rax,%rdx
    459d:	48 c1 ea 10          	shr    $0x10,%rdx
    45a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    45a5:	48 8b 15 8c a5 01 00 	mov    0x1a58c(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    45ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    45b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    45b4:	48 85 c9             	test   %rcx,%rcx
    45b7:	74 3c                	je     45f5 <fwp_rc_free_arr+0x75>
    45b9:	0f b6 32             	movzbl (%rdx),%esi
    45bc:	40 80 fe 02          	cmp    $0x2,%sil
    45c0:	74 2e                	je     45f0 <fwp_rc_free_arr+0x70>
    45c2:	40 80 fe 01          	cmp    $0x1,%sil
    45c6:	75 2d                	jne    45f5 <fwp_rc_free_arr+0x75>
    45c8:	8b 72 18             	mov    0x18(%rdx),%esi
    45cb:	0f b7 c0             	movzwl %ax,%eax
    45ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    45d1:	48 0f af c6          	imul   %rsi,%rax
    45d5:	48 c1 e8 20          	shr    $0x20,%rax
    45d9:	48 39 d0             	cmp    %rdx,%rax
    45dc:	73 17                	jae    45f5 <fwp_rc_free_arr+0x75>
    45de:	48 01 c1             	add    %rax,%rcx
    45e1:	80 39 01             	cmpb   $0x1,(%rcx)
    45e4:	75 0f                	jne    45f5 <fwp_rc_free_arr+0x75>
    45e6:	e9 e5 f9 ff ff       	jmp    3fd0 <fwp_mem_free>
    45eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45f0:	66 85 c0             	test   %ax,%ax
    45f3:	74 ec                	je     45e1 <fwp_rc_free_arr+0x61>
    45f5:	c3                   	ret
    45f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    45fd:	00 00 00 

0000000000004600 <fwp_heap_alloc>:
    4600:	8b 05 de a4 01 00    	mov    0x1a4de(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4606:	48 89 fa             	mov    %rdi,%rdx
    4609:	89 f7                	mov    %esi,%edi
    460b:	85 c0                	test   %eax,%eax
    460d:	0f 84 f5 00 00 00    	je     4708 <fwp_heap_alloc+0x108>
    4613:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    461a:	0f 87 e8 00 00 00    	ja     4708 <fwp_heap_alloc+0x108>
    4620:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4624:	48 8d 05 15 91 01 00 	lea    0x19115(%rip),%rax        # 1d740 <fwp_heap>
    462b:	48 83 ec 18          	sub    $0x18,%rsp
    462f:	41 89 f0             	mov    %esi,%r8d
    4632:	48 c1 e9 04          	shr    $0x4,%rcx
    4636:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    463d:	00 
    463e:	48 63 cf             	movslq %edi,%rcx
    4641:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4648:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    464f:	00 
    4650:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    4654:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    4658:	48 01 c8             	add    %rcx,%rax
    465b:	48 8b 08             	mov    (%rax),%rcx
    465e:	48 85 c9             	test   %rcx,%rcx
    4661:	74 6d                	je     46d0 <fwp_heap_alloc+0xd0>
    4663:	48 8b 31             	mov    (%rcx),%rsi
    4666:	48 f7 d6             	not    %rsi
    4669:	48 89 30             	mov    %rsi,(%rax)
    466c:	41 83 f8 01          	cmp    $0x1,%r8d
    4670:	48 89 cf             	mov    %rcx,%rdi
    4673:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4678:	49 0f 45 d1          	cmovne %r9,%rdx
    467c:	31 f6                	xor    %esi,%esi
    467e:	e8 1d de ff ff       	call   24a0 <memset@plt>
    4683:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4688:	48 89 c1             	mov    %rax,%rcx
    468b:	4c 89 c8             	mov    %r9,%rax
    468e:	48 03 05 cb a4 01 00 	add    0x1a4cb(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    4695:	72 7b                	jb     4712 <fwp_heap_alloc+0x112>
    4697:	48 39 05 ca a4 01 00 	cmp    %rax,0x1a4ca(%rip)        # 1eb68 <fwp_heap+0x1428>
    469e:	48 89 05 bb a4 01 00 	mov    %rax,0x1a4bb(%rip)        # 1eb60 <fwp_heap+0x1420>
    46a5:	73 07                	jae    46ae <fwp_heap_alloc+0xae>
    46a7:	48 89 05 ba a4 01 00 	mov    %rax,0x1a4ba(%rip)        # 1eb68 <fwp_heap+0x1428>
    46ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    46b2:	48 89 c8             	mov    %rcx,%rax
    46b5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    46ba:	f2 0f 58 05 b6 a4 01 	addsd  0x1a4b6(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    46c1:	00 
    46c2:	f2 0f 11 05 ae a4 01 	movsd  %xmm0,0x1a4ae(%rip)        # 1eb78 <fwp_heap+0x1438>
    46c9:	00 
    46ca:	48 83 c4 18          	add    $0x18,%rsp
    46ce:	c3                   	ret
    46cf:	90                   	nop
    46d0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    46d4:	48 85 c9             	test   %rcx,%rcx
    46d7:	74 0c                	je     46e5 <fwp_heap_alloc+0xe5>
    46d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    46dd:	48 29 ce             	sub    %rcx,%rsi
    46e0:	4c 39 ce             	cmp    %r9,%rsi
    46e3:	73 13                	jae    46f8 <fwp_heap_alloc+0xf8>
    46e5:	89 fe                	mov    %edi,%esi
    46e7:	48 83 c4 18          	add    $0x18,%rsp
    46eb:	48 89 d7             	mov    %rdx,%rdi
    46ee:	e9 5d fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    46f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46f8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    46fc:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4700:	e9 67 ff ff ff       	jmp    466c <fwp_heap_alloc+0x6c>
    4705:	0f 1f 00             	nopl   (%rax)
    4708:	89 fe                	mov    %edi,%esi
    470a:	48 89 d7             	mov    %rdx,%rdi
    470d:	e9 3e fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4712:	e8 e9 e4 ff ff       	call   2c00 <fwp_heap_oom>
    4717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    471e:	00 00 

0000000000004720 <fwp_data.part.0.constprop.0>:
    4720:	41 56                	push   %r14
    4722:	41 89 fe             	mov    %edi,%r14d
    4725:	41 54                	push   %r12
    4727:	49 89 f4             	mov    %rsi,%r12
    472a:	55                   	push   %rbp
    472b:	53                   	push   %rbx
    472c:	48 83 ec 08          	sub    $0x8,%rsp
    4730:	8b 05 ae a3 01 00    	mov    0x1a3ae(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4736:	85 c0                	test   %eax,%eax
    4738:	0f 84 fa 00 00 00    	je     4838 <fwp_data.part.0.constprop.0+0x118>
    473e:	0f b6 05 9d 9f 01 00 	movzbl 0x19f9d(%rip),%eax        # 1e6e2 <fwp_heap+0xfa2>
    4745:	48 8d 15 f4 8f 01 00 	lea    0x18ff4(%rip),%rdx        # 1d740 <fwp_heap>
    474c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    4753:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4757:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    475b:	48 8b 18             	mov    (%rax),%rbx
    475e:	48 85 db             	test   %rbx,%rbx
    4761:	0f 84 a9 00 00 00    	je     4810 <fwp_data.part.0.constprop.0+0xf0>
    4767:	48 8b 13             	mov    (%rbx),%rdx
    476a:	48 f7 d2             	not    %rdx
    476d:	48 89 10             	mov    %rdx,(%rax)
    4770:	48 83 fd 18          	cmp    $0x18,%rbp
    4774:	76 1b                	jbe    4791 <fwp_data.part.0.constprop.0+0x71>
    4776:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    477a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    477e:	31 f6                	xor    %esi,%esi
    4780:	48 c1 e8 03          	shr    $0x3,%rax
    4784:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    478b:	00 
    478c:	e8 0f dd ff ff       	call   24a0 <memset@plt>
    4791:	48 89 e8             	mov    %rbp,%rax
    4794:	48 03 05 c5 a3 01 00 	add    0x1a3c5(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    479b:	0f 82 a8 00 00 00    	jb     4849 <fwp_data.part.0.constprop.0+0x129>
    47a1:	48 39 05 c0 a3 01 00 	cmp    %rax,0x1a3c0(%rip)        # 1eb68 <fwp_heap+0x1428>
    47a8:	48 89 05 b1 a3 01 00 	mov    %rax,0x1a3b1(%rip)        # 1eb60 <fwp_heap+0x1420>
    47af:	73 07                	jae    47b8 <fwp_data.part.0.constprop.0+0x98>
    47b1:	48 89 05 b0 a3 01 00 	mov    %rax,0x1a3b0(%rip)        # 1eb68 <fwp_heap+0x1428>
    47b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    47bc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    47c1:	f2 0f 58 05 af a3 01 	addsd  0x1a3af(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    47c8:	00 
    47c9:	f2 0f 11 05 a7 a3 01 	movsd  %xmm0,0x1a3a7(%rip)        # 1eb78 <fwp_heap+0x1438>
    47d0:	00 
    47d1:	b8 02 00 00 00       	mov    $0x2,%eax
    47d6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    47db:	66 0f 6e c8          	movd   %eax,%xmm1
    47df:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    47e3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    47e7:	49 8b 04 24          	mov    (%r12),%rax
    47eb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    47ef:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    47f4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    47f8:	48 83 c4 08          	add    $0x8,%rsp
    47fc:	48 89 d8             	mov    %rbx,%rax
    47ff:	5b                   	pop    %rbx
    4800:	5d                   	pop    %rbp
    4801:	41 5c                	pop    %r12
    4803:	41 5e                	pop    %r14
    4805:	c3                   	ret
    4806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    480d:	00 00 00 
    4810:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4814:	48 85 db             	test   %rbx,%rbx
    4817:	74 1f                	je     4838 <fwp_data.part.0.constprop.0+0x118>
    4819:	48 8b 50 10          	mov    0x10(%rax),%rdx
    481d:	48 29 da             	sub    %rbx,%rdx
    4820:	48 39 ea             	cmp    %rbp,%rdx
    4823:	72 13                	jb     4838 <fwp_data.part.0.constprop.0+0x118>
    4825:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4829:	48 89 50 08          	mov    %rdx,0x8(%rax)
    482d:	e9 3e ff ff ff       	jmp    4770 <fwp_data.part.0.constprop.0+0x50>
    4832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4838:	31 f6                	xor    %esi,%esi
    483a:	bf 18 00 00 00       	mov    $0x18,%edi
    483f:	e8 bc fd ff ff       	call   4600 <fwp_heap_alloc>
    4844:	48 89 c3             	mov    %rax,%rbx
    4847:	eb 88                	jmp    47d1 <fwp_data.part.0.constprop.0+0xb1>
    4849:	e8 b2 e3 ff ff       	call   2c00 <fwp_heap_oom>
    484e:	66 90                	xchg   %ax,%ax

0000000000004850 <fwp_array_new_packed.constprop.0>:
    4850:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4857:	ff ff 1f 
    485a:	53                   	push   %rbx
    485b:	48 39 f8             	cmp    %rdi,%rax
    485e:	72 1a                	jb     487a <fwp_array_new_packed.constprop.0+0x2a>
    4860:	48 89 fb             	mov    %rdi,%rbx
    4863:	be 01 00 00 00       	mov    $0x1,%esi
    4868:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    486f:	00 
    4870:	e8 8b fd ff ff       	call   4600 <fwp_heap_alloc>
    4875:	48 89 18             	mov    %rbx,(%rax)
    4878:	5b                   	pop    %rbx
    4879:	c3                   	ret
    487a:	48 8d 3d 24 68 00 00 	lea    0x6824(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    4881:	e8 2a e8 ff ff       	call   30b0 <fwp_trap>
    4886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    488d:	00 00 00 

0000000000004890 <fwp_task_dispose>:
    4890:	53                   	push   %rbx
    4891:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4895:	0f 84 6b de ff ff    	je     2706 <fwp_task_dispose.cold>
    489b:	48 89 fb             	mov    %rdi,%rbx
    489e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    48a3:	0f 85 5d de ff ff    	jne    2706 <fwp_task_dispose.cold>
    48a9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    48ad:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    48b4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    48bb:	00 
    48bc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    48c0:	48 85 ff             	test   %rdi,%rdi
    48c3:	74 07                	je     48cc <fwp_task_dispose+0x3c>
    48c5:	48 85 c0             	test   %rax,%rax
    48c8:	74 02                	je     48cc <fwp_task_dispose+0x3c>
    48ca:	ff d0                	call   *%rax
    48cc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    48d3:	e8 f8 f6 ff ff       	call   3fd0 <fwp_mem_free>
    48d8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    48df:	00 00 00 00 
    48e3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    48e7:	74 6f                	je     4958 <fwp_task_dispose+0xc8>
    48e9:	48 8b 15 28 a2 01 00 	mov    0x1a228(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    48f0:	48 89 d8             	mov    %rbx,%rax
    48f3:	48 2b 05 f6 a1 01 00 	sub    0x1a1f6(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    48fa:	48 c1 e2 10          	shl    $0x10,%rdx
    48fe:	48 39 d0             	cmp    %rdx,%rax
    4901:	73 4c                	jae    494f <fwp_task_dispose+0xbf>
    4903:	48 89 c2             	mov    %rax,%rdx
    4906:	48 c1 ea 10          	shr    $0x10,%rdx
    490a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    490e:	48 8b 15 23 a2 01 00 	mov    0x1a223(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    4915:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4919:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    491d:	48 85 c9             	test   %rcx,%rcx
    4920:	74 2d                	je     494f <fwp_task_dispose+0xbf>
    4922:	0f b6 32             	movzbl (%rdx),%esi
    4925:	40 80 fe 02          	cmp    $0x2,%sil
    4929:	74 3d                	je     4968 <fwp_task_dispose+0xd8>
    492b:	40 80 fe 01          	cmp    $0x1,%sil
    492f:	75 1e                	jne    494f <fwp_task_dispose+0xbf>
    4931:	8b 72 18             	mov    0x18(%rdx),%esi
    4934:	0f b7 c0             	movzwl %ax,%eax
    4937:	8b 52 1c             	mov    0x1c(%rdx),%edx
    493a:	48 0f af c6          	imul   %rsi,%rax
    493e:	48 c1 e8 20          	shr    $0x20,%rax
    4942:	48 39 d0             	cmp    %rdx,%rax
    4945:	73 08                	jae    494f <fwp_task_dispose+0xbf>
    4947:	48 01 c1             	add    %rax,%rcx
    494a:	80 39 01             	cmpb   $0x1,(%rcx)
    494d:	74 09                	je     4958 <fwp_task_dispose+0xc8>
    494f:	5b                   	pop    %rbx
    4950:	c3                   	ret
    4951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4958:	48 89 df             	mov    %rbx,%rdi
    495b:	5b                   	pop    %rbx
    495c:	e9 6f f6 ff ff       	jmp    3fd0 <fwp_mem_free>
    4961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4968:	66 85 c0             	test   %ax,%ax
    496b:	74 dd                	je     494a <fwp_task_dispose+0xba>
    496d:	5b                   	pop    %rbx
    496e:	c3                   	ret
    496f:	90                   	nop

0000000000004970 <fwp_free_zombie>:
    4970:	48 8b 15 99 8d 01 00 	mov    0x18d99(%rip),%rdx        # 1d710 <fwp_zombie>
    4977:	48 85 d2             	test   %rdx,%rdx
    497a:	0f 84 98 00 00 00    	je     4a18 <fwp_free_zombie+0xa8>
    4980:	48 3b 15 99 8d 01 00 	cmp    0x18d99(%rip),%rdx        # 1d720 <fwp_cur>
    4987:	0f 84 8b 00 00 00    	je     4a18 <fwp_free_zombie+0xa8>
    498d:	48 83 ec 18          	sub    $0x18,%rsp
    4991:	48 63 05 64 87 01 00 	movslq 0x18764(%rip),%rax        # 1d0fc <fwp_stack_pool_n>
    4998:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    499c:	83 f8 3f             	cmp    $0x3f,%eax
    499f:	7f 7f                	jg     4a20 <fwp_free_zombie+0xb0>
    49a1:	8d 48 01             	lea    0x1(%rax),%ecx
    49a4:	89 0d 52 87 01 00    	mov    %ecx,0x18752(%rip)        # 1d0fc <fwp_stack_pool_n>
    49aa:	48 8d 0d 4f 87 01 00 	lea    0x1874f(%rip),%rcx        # 1d100 <fwp_stack_pool>
    49b1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    49b5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    49bc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49c0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    49c7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    49cb:	48 85 c9             	test   %rcx,%rcx
    49ce:	0f 84 fc 00 00 00    	je     4ad0 <fwp_free_zombie+0x160>
    49d4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    49db:	48 85 c0             	test   %rax,%rax
    49de:	74 07                	je     49e7 <fwp_free_zombie+0x77>
    49e0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    49e7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    49ea:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49ee:	48 c7 05 17 8d 01 00 	movq   $0x0,0x18d17(%rip)        # 1d710 <fwp_zombie>
    49f5:	00 00 00 00 
    49f9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4a00:	85 c0                	test   %eax,%eax
    4a02:	74 34                	je     4a38 <fwp_free_zombie+0xc8>
    4a04:	83 f8 01             	cmp    $0x1,%eax
    4a07:	0f 84 b3 00 00 00    	je     4ac0 <fwp_free_zombie+0x150>
    4a0d:	48 83 c4 18          	add    $0x18,%rsp
    4a11:	c3                   	ret
    4a12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a18:	c3                   	ret
    4a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a20:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4a24:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4a29:	e8 82 db ff ff       	call   25b0 <munmap@plt>
    4a2e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4a33:	eb 80                	jmp    49b5 <fwp_free_zombie+0x45>
    4a35:	0f 1f 00             	nopl   (%rax)
    4a38:	48 8b 0d d9 a0 01 00 	mov    0x1a0d9(%rip),%rcx        # 1eb18 <fwp_heap+0x13d8>
    4a3f:	48 89 d0             	mov    %rdx,%rax
    4a42:	48 2b 05 a7 a0 01 00 	sub    0x1a0a7(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4a49:	48 c1 e1 10          	shl    $0x10,%rcx
    4a4d:	48 39 c8             	cmp    %rcx,%rax
    4a50:	73 bb                	jae    4a0d <fwp_free_zombie+0x9d>
    4a52:	48 89 c1             	mov    %rax,%rcx
    4a55:	48 c1 e9 10          	shr    $0x10,%rcx
    4a59:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4a5d:	48 8b 0d d4 a0 01 00 	mov    0x1a0d4(%rip),%rcx        # 1eb38 <fwp_heap+0x13f8>
    4a64:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4a68:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4a6c:	48 85 c9             	test   %rcx,%rcx
    4a6f:	74 9c                	je     4a0d <fwp_free_zombie+0x9d>
    4a71:	0f b6 3e             	movzbl (%rsi),%edi
    4a74:	40 80 ff 02          	cmp    $0x2,%dil
    4a78:	74 66                	je     4ae0 <fwp_free_zombie+0x170>
    4a7a:	40 80 ff 01          	cmp    $0x1,%dil
    4a7e:	75 8d                	jne    4a0d <fwp_free_zombie+0x9d>
    4a80:	8b 7e 18             	mov    0x18(%rsi),%edi
    4a83:	0f b7 c0             	movzwl %ax,%eax
    4a86:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4a89:	48 0f af c7          	imul   %rdi,%rax
    4a8d:	48 c1 e8 20          	shr    $0x20,%rax
    4a91:	48 39 f0             	cmp    %rsi,%rax
    4a94:	0f 83 73 ff ff ff    	jae    4a0d <fwp_free_zombie+0x9d>
    4a9a:	48 01 c1             	add    %rax,%rcx
    4a9d:	0f b6 01             	movzbl (%rcx),%eax
    4aa0:	84 c0                	test   %al,%al
    4aa2:	0f 84 65 ff ff ff    	je     4a0d <fwp_free_zombie+0x9d>
    4aa8:	3c 01                	cmp    $0x1,%al
    4aaa:	74 14                	je     4ac0 <fwp_free_zombie+0x150>
    4aac:	3c ff                	cmp    $0xff,%al
    4aae:	74 3b                	je     4aeb <fwp_free_zombie+0x17b>
    4ab0:	83 e8 01             	sub    $0x1,%eax
    4ab3:	88 01                	mov    %al,(%rcx)
    4ab5:	e9 53 ff ff ff       	jmp    4a0d <fwp_free_zombie+0x9d>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 89 d7             	mov    %rdx,%rdi
    4ac3:	48 83 c4 18          	add    $0x18,%rsp
    4ac7:	e9 c4 fd ff ff       	jmp    4890 <fwp_task_dispose>
    4acc:	0f 1f 40 00          	nopl   0x0(%rax)
    4ad0:	48 89 05 11 8c 01 00 	mov    %rax,0x18c11(%rip)        # 1d6e8 <fwp_tasks_active>
    4ad7:	e9 ff fe ff ff       	jmp    49db <fwp_free_zombie+0x6b>
    4adc:	0f 1f 40 00          	nopl   0x0(%rax)
    4ae0:	66 85 c0             	test   %ax,%ax
    4ae3:	0f 85 24 ff ff ff    	jne    4a0d <fwp_free_zombie+0x9d>
    4ae9:	eb b2                	jmp    4a9d <fwp_free_zombie+0x12d>
    4aeb:	48 89 ca             	mov    %rcx,%rdx
    4aee:	48 8d 35 4b 8c 01 00 	lea    0x18c4b(%rip),%rsi        # 1d740 <fwp_heap>
    4af5:	48 c1 ea 11          	shr    $0x11,%rdx
    4af9:	48 31 ca             	xor    %rcx,%rdx
    4afc:	48 89 d0             	mov    %rdx,%rax
    4aff:	48 c1 e8 09          	shr    $0x9,%rax
    4b03:	48 31 c2             	xor    %rax,%rdx
    4b06:	0f b6 d2             	movzbl %dl,%edx
    4b09:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4b10:	00 
    4b11:	48 85 c0             	test   %rax,%rax
    4b14:	75 13                	jne    4b29 <fwp_free_zombie+0x1b9>
    4b16:	eb 4c                	jmp    4b64 <fwp_free_zombie+0x1f4>
    4b18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b1f:	00 
    4b20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4b24:	48 85 c0             	test   %rax,%rax
    4b27:	74 3b                	je     4b64 <fwp_free_zombie+0x1f4>
    4b29:	48 89 c2             	mov    %rax,%rdx
    4b2c:	48 39 08             	cmp    %rcx,(%rax)
    4b2f:	75 ef                	jne    4b20 <fwp_free_zombie+0x1b0>
    4b31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b35:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4b39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4b3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4b44:	0f 85 c3 fe ff ff    	jne    4a0d <fwp_free_zombie+0x9d>
    4b4a:	48 89 cf             	mov    %rcx,%rdi
    4b4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4b52:	e8 39 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4b57:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4b5c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4b5f:	e9 a9 fe ff ff       	jmp    4a0d <fwp_free_zombie+0x9d>
    4b64:	48 8d 3d 1d 67 00 00 	lea    0x671d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4b6b:	e8 40 e5 ff ff       	call   30b0 <fwp_trap>

0000000000004b70 <fwp_block>:
    4b70:	48 83 ec 08          	sub    $0x8,%rsp
    4b74:	48 8b 05 8d 8b 01 00 	mov    0x18b8d(%rip),%rax        # 1d708 <fwp_ready_head>
    4b7b:	48 85 c0             	test   %rax,%rax
    4b7e:	0f 84 1c 01 00 00    	je     4ca0 <fwp_block+0x130>
    4b84:	90                   	nop
    4b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b8c:	00 00 00 00 
    4b90:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4b97:	48 89 15 6a 8b 01 00 	mov    %rdx,0x18b6a(%rip)        # 1d708 <fwp_ready_head>
    4b9e:	48 85 d2             	test   %rdx,%rdx
    4ba1:	0f 84 19 01 00 00    	je     4cc0 <fwp_block+0x150>
    4ba7:	48 8b 15 72 8b 01 00 	mov    0x18b72(%rip),%rdx        # 1d720 <fwp_cur>
    4bae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4bb2:	48 39 c2             	cmp    %rax,%rdx
    4bb5:	0f 84 d5 00 00 00    	je     4c90 <fwp_block+0x120>
    4bbb:	48 8b 0d de a7 01 00 	mov    0x1a7de(%rip),%rcx        # 1f3a0 <fwp_state_owners>
    4bc2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4bc6:	48 89 05 53 8b 01 00 	mov    %rax,0x18b53(%rip)        # 1d720 <fwp_cur>
    4bcd:	f3 0f 7e 05 f3 a7 01 	movq   0x1a7f3(%rip),%xmm0        # 1f3c8 <fwp_foreign_callbacks>
    4bd4:	00 
    4bd5:	0f 16 05 dc a7 01 00 	movhps 0x1a7dc(%rip),%xmm0        # 1f3b8 <fwp_state>
    4bdc:	f3 0f 7e 0d dc a7 01 	movq   0x1a7dc(%rip),%xmm1        # 1f3c0 <fwp_handlers>
    4be3:	00 
    4be4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4beb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4bf2:	0f 16 0d d7 a7 01 00 	movhps 0x1a7d7(%rip),%xmm1        # 1f3d0 <fwp_cleanups>
    4bf9:	f3 0f 7e 05 af a7 01 	movq   0x1a7af(%rip),%xmm0        # 1f3b0 <fwp_state_len>
    4c00:	00 
    4c01:	0f 16 05 a0 a7 01 00 	movhps 0x1a7a0(%rip),%xmm0        # 1f3a8 <fwp_state_cap>
    4c08:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4c0f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4c16:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4c1a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4c21:	48 89 0d 98 a7 01 00 	mov    %rcx,0x1a798(%rip)        # 1f3c0 <fwp_handlers>
    4c28:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4c2f:	48 89 0d 9a a7 01 00 	mov    %rcx,0x1a79a(%rip)        # 1f3d0 <fwp_cleanups>
    4c36:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4c3d:	48 89 0d 84 a7 01 00 	mov    %rcx,0x1a784(%rip)        # 1f3c8 <fwp_foreign_callbacks>
    4c44:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4c4b:	48 89 0d 66 a7 01 00 	mov    %rcx,0x1a766(%rip)        # 1f3b8 <fwp_state>
    4c52:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4c59:	48 89 0d 50 a7 01 00 	mov    %rcx,0x1a750(%rip)        # 1f3b0 <fwp_state_len>
    4c60:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4c67:	48 89 0d 3a a7 01 00 	mov    %rcx,0x1a73a(%rip)        # 1f3a8 <fwp_state_cap>
    4c6e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4c75:	48 89 0d 24 a7 01 00 	mov    %rcx,0x1a724(%rip)        # 1f3a0 <fwp_state_owners>
    4c7c:	e8 ef d7 ff ff       	call   2470 <swapcontext@plt>
    4c81:	f3 0f 1e fa          	endbr64
    4c85:	e8 e6 fc ff ff       	call   4970 <fwp_free_zombie>
    4c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c90:	8b 05 62 84 01 00    	mov    0x18462(%rip),%eax        # 1d0f8 <fwp_slice>
    4c96:	85 c0                	test   %eax,%eax
    4c98:	74 36                	je     4cd0 <fwp_block+0x160>
    4c9a:	48 83 c4 08          	add    $0x8,%rsp
    4c9e:	c3                   	ret
    4c9f:	90                   	nop
    4ca0:	e8 4b ee ff ff       	call   3af0 <fwp_poll_events>
    4ca5:	48 8b 05 5c 8a 01 00 	mov    0x18a5c(%rip),%rax        # 1d708 <fwp_ready_head>
    4cac:	48 85 c0             	test   %rax,%rax
    4caf:	0f 85 db fe ff ff    	jne    4b90 <fwp_block+0x20>
    4cb5:	eb e9                	jmp    4ca0 <fwp_block+0x130>
    4cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4cbe:	00 00 
    4cc0:	48 c7 05 35 8a 01 00 	movq   $0x0,0x18a35(%rip)        # 1d700 <fwp_ready_tail>
    4cc7:	00 00 00 00 
    4ccb:	e9 d7 fe ff ff       	jmp    4ba7 <fwp_block+0x37>
    4cd0:	48 8d 3d de 63 00 00 	lea    0x63de(%rip),%rdi        # b0b5 <_IO_stdin_used+0xb5>
    4cd7:	e8 a4 d6 ff ff       	call   2380 <getenv@plt>
    4cdc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4ce1:	48 85 c0             	test   %rax,%rax
    4ce4:	74 05                	je     4ceb <fwp_block+0x17b>
    4ce6:	80 38 00             	cmpb   $0x0,(%rax)
    4ce9:	75 0b                	jne    4cf6 <fwp_block+0x186>
    4ceb:	89 15 07 84 01 00    	mov    %edx,0x18407(%rip)        # 1d0f8 <fwp_slice>
    4cf1:	48 83 c4 08          	add    $0x8,%rsp
    4cf5:	c3                   	ret
    4cf6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4cfb:	31 f6                	xor    %esi,%esi
    4cfd:	48 89 c7             	mov    %rax,%rdi
    4d00:	e8 2b d8 ff ff       	call   2530 <strtoll@plt>
    4d05:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4d09:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4d10:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4d15:	0f 46 d0             	cmovbe %eax,%edx
    4d18:	eb d1                	jmp    4ceb <fwp_block+0x17b>
    4d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004d20 <fwp_drop0>:
    4d20:	48 8b 15 f1 9d 01 00 	mov    0x19df1(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4d27:	48 89 f8             	mov    %rdi,%rax
    4d2a:	48 2b 05 bf 9d 01 00 	sub    0x19dbf(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4d31:	48 c1 e2 10          	shl    $0x10,%rdx
    4d35:	48 39 d0             	cmp    %rdx,%rax
    4d38:	0f 83 c2 00 00 00    	jae    4e00 <fwp_drop0+0xe0>
    4d3e:	48 83 ec 18          	sub    $0x18,%rsp
    4d42:	4c 8d 05 f7 89 01 00 	lea    0x189f7(%rip),%r8        # 1d740 <fwp_heap>
    4d49:	48 89 c2             	mov    %rax,%rdx
    4d4c:	48 c1 ea 10          	shr    $0x10,%rdx
    4d50:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4d54:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4d5b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4d5f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4d63:	48 85 d2             	test   %rdx,%rdx
    4d66:	74 3c                	je     4da4 <fwp_drop0+0x84>
    4d68:	0f b6 31             	movzbl (%rcx),%esi
    4d6b:	40 80 fe 02          	cmp    $0x2,%sil
    4d6f:	74 3f                	je     4db0 <fwp_drop0+0x90>
    4d71:	40 80 fe 01          	cmp    $0x1,%sil
    4d75:	75 2d                	jne    4da4 <fwp_drop0+0x84>
    4d77:	8b 71 18             	mov    0x18(%rcx),%esi
    4d7a:	0f b7 c0             	movzwl %ax,%eax
    4d7d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4d80:	48 0f af c6          	imul   %rsi,%rax
    4d84:	48 c1 e8 20          	shr    $0x20,%rax
    4d88:	48 39 c8             	cmp    %rcx,%rax
    4d8b:	73 17                	jae    4da4 <fwp_drop0+0x84>
    4d8d:	48 01 c2             	add    %rax,%rdx
    4d90:	0f b6 02             	movzbl (%rdx),%eax
    4d93:	84 c0                	test   %al,%al
    4d95:	74 0d                	je     4da4 <fwp_drop0+0x84>
    4d97:	3c 01                	cmp    $0x1,%al
    4d99:	74 25                	je     4dc0 <fwp_drop0+0xa0>
    4d9b:	3c ff                	cmp    $0xff,%al
    4d9d:	74 69                	je     4e08 <fwp_drop0+0xe8>
    4d9f:	83 e8 01             	sub    $0x1,%eax
    4da2:	88 02                	mov    %al,(%rdx)
    4da4:	48 83 c4 18          	add    $0x18,%rsp
    4da8:	c3                   	ret
    4da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4db0:	66 85 c0             	test   %ax,%ax
    4db3:	74 db                	je     4d90 <fwp_drop0+0x70>
    4db5:	48 83 c4 18          	add    $0x18,%rsp
    4db9:	c3                   	ret
    4dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4dc0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4dc4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4dc9:	e8 b2 f7 ff ff       	call   4580 <fwp_rc_free_arr>
    4dce:	4c 8d 05 6b 89 01 00 	lea    0x1896b(%rip),%r8        # 1d740 <fwp_heap>
    4dd5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4dda:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4de1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4de8:	48 c1 e2 10          	shl    $0x10,%rdx
    4dec:	48 39 d0             	cmp    %rdx,%rax
    4def:	73 b3                	jae    4da4 <fwp_drop0+0x84>
    4df1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4df6:	e9 4e ff ff ff       	jmp    4d49 <fwp_drop0+0x29>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	c3                   	ret
    4e01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e08:	48 89 d0             	mov    %rdx,%rax
    4e0b:	48 c1 e8 11          	shr    $0x11,%rax
    4e0f:	48 31 d0             	xor    %rdx,%rax
    4e12:	48 89 c1             	mov    %rax,%rcx
    4e15:	48 c1 e9 09          	shr    $0x9,%rcx
    4e19:	48 31 c8             	xor    %rcx,%rax
    4e1c:	0f b6 c8             	movzbl %al,%ecx
    4e1f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4e26:	00 
    4e27:	48 85 c0             	test   %rax,%rax
    4e2a:	75 1d                	jne    4e49 <fwp_drop0+0x129>
    4e2c:	eb 56                	jmp    4e84 <fwp_drop0+0x164>
    4e2e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e3c:	00 00 00 00 
    4e40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4e44:	48 85 c0             	test   %rax,%rax
    4e47:	74 3b                	je     4e84 <fwp_drop0+0x164>
    4e49:	48 89 c1             	mov    %rax,%rcx
    4e4c:	48 39 10             	cmp    %rdx,(%rax)
    4e4f:	75 ef                	jne    4e40 <fwp_drop0+0x120>
    4e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4e55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4e59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4e5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4e64:	0f 85 3a ff ff ff    	jne    4da4 <fwp_drop0+0x84>
    4e6a:	48 89 d7             	mov    %rdx,%rdi
    4e6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4e72:	e8 19 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4e77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4e7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4e7f:	e9 20 ff ff ff       	jmp    4da4 <fwp_drop0+0x84>
    4e84:	48 8d 3d fd 63 00 00 	lea    0x63fd(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4e8b:	e8 20 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004e90 <fwp_drop1>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	48 8b 15 7d 9c 01 00 	mov    0x19c7d(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4e9b:	48 89 f8             	mov    %rdi,%rax
    4e9e:	48 2b 05 4b 9c 01 00 	sub    0x19c4b(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4ea5:	48 c1 e2 10          	shl    $0x10,%rdx
    4ea9:	48 39 d0             	cmp    %rdx,%rax
    4eac:	0f 83 be 00 00 00    	jae    4f70 <fwp_drop1+0xe0>
    4eb2:	48 83 ec 18          	sub    $0x18,%rsp
    4eb6:	4c 8d 05 83 88 01 00 	lea    0x18883(%rip),%r8        # 1d740 <fwp_heap>
    4ebd:	48 89 c2             	mov    %rax,%rdx
    4ec0:	48 c1 ea 10          	shr    $0x10,%rdx
    4ec4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4ec8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4ecf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4ed3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4ed7:	48 85 d2             	test   %rdx,%rdx
    4eda:	74 3c                	je     4f18 <fwp_drop1+0x88>
    4edc:	0f b6 31             	movzbl (%rcx),%esi
    4edf:	40 80 fe 02          	cmp    $0x2,%sil
    4ee3:	74 3b                	je     4f20 <fwp_drop1+0x90>
    4ee5:	40 80 fe 01          	cmp    $0x1,%sil
    4ee9:	75 2d                	jne    4f18 <fwp_drop1+0x88>
    4eeb:	8b 71 18             	mov    0x18(%rcx),%esi
    4eee:	0f b7 c0             	movzwl %ax,%eax
    4ef1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4ef4:	48 0f af c6          	imul   %rsi,%rax
    4ef8:	48 c1 e8 20          	shr    $0x20,%rax
    4efc:	48 39 c8             	cmp    %rcx,%rax
    4eff:	73 17                	jae    4f18 <fwp_drop1+0x88>
    4f01:	48 01 c2             	add    %rax,%rdx
    4f04:	0f b6 02             	movzbl (%rdx),%eax
    4f07:	84 c0                	test   %al,%al
    4f09:	74 0d                	je     4f18 <fwp_drop1+0x88>
    4f0b:	3c 01                	cmp    $0x1,%al
    4f0d:	74 21                	je     4f30 <fwp_drop1+0xa0>
    4f0f:	3c ff                	cmp    $0xff,%al
    4f11:	74 65                	je     4f78 <fwp_drop1+0xe8>
    4f13:	83 e8 01             	sub    $0x1,%eax
    4f16:	88 02                	mov    %al,(%rdx)
    4f18:	48 83 c4 18          	add    $0x18,%rsp
    4f1c:	c3                   	ret
    4f1d:	0f 1f 00             	nopl   (%rax)
    4f20:	66 85 c0             	test   %ax,%ax
    4f23:	74 df                	je     4f04 <fwp_drop1+0x74>
    4f25:	48 83 c4 18          	add    $0x18,%rsp
    4f29:	c3                   	ret
    4f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f30:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4f34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4f39:	e8 42 f6 ff ff       	call   4580 <fwp_rc_free_arr>
    4f3e:	4c 8d 05 fb 87 01 00 	lea    0x187fb(%rip),%r8        # 1d740 <fwp_heap>
    4f45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4f4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4f51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4f58:	48 c1 e2 10          	shl    $0x10,%rdx
    4f5c:	48 39 d0             	cmp    %rdx,%rax
    4f5f:	73 b7                	jae    4f18 <fwp_drop1+0x88>
    4f61:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4f66:	e9 52 ff ff ff       	jmp    4ebd <fwp_drop1+0x2d>
    4f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f70:	c3                   	ret
    4f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f78:	48 89 d0             	mov    %rdx,%rax
    4f7b:	48 c1 e8 11          	shr    $0x11,%rax
    4f7f:	48 31 d0             	xor    %rdx,%rax
    4f82:	48 89 c1             	mov    %rax,%rcx
    4f85:	48 c1 e9 09          	shr    $0x9,%rcx
    4f89:	48 31 c8             	xor    %rcx,%rax
    4f8c:	0f b6 c8             	movzbl %al,%ecx
    4f8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4f96:	00 
    4f97:	48 85 c0             	test   %rax,%rax
    4f9a:	75 0d                	jne    4fa9 <fwp_drop1+0x119>
    4f9c:	eb 46                	jmp    4fe4 <fwp_drop1+0x154>
    4f9e:	66 90                	xchg   %ax,%ax
    4fa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4fa4:	48 85 c0             	test   %rax,%rax
    4fa7:	74 3b                	je     4fe4 <fwp_drop1+0x154>
    4fa9:	48 89 c1             	mov    %rax,%rcx
    4fac:	48 39 10             	cmp    %rdx,(%rax)
    4faf:	75 ef                	jne    4fa0 <fwp_drop1+0x110>
    4fb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4fb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4fb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4fbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4fc4:	0f 85 4e ff ff ff    	jne    4f18 <fwp_drop1+0x88>
    4fca:	48 89 d7             	mov    %rdx,%rdi
    4fcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4fd2:	e8 b9 ed ff ff       	call   3d90 <fwp_rc_forget_slot>
    4fd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4fdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4fdf:	e9 34 ff ff ff       	jmp    4f18 <fwp_drop1+0x88>
    4fe4:	48 8d 3d 9d 62 00 00 	lea    0x629d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4feb:	e8 c0 e0 ff ff       	call   30b0 <fwp_trap>

0000000000004ff0 <fwp_write.constprop.0>:
    4ff0:	41 57                	push   %r15
    4ff2:	41 56                	push   %r14
    4ff4:	41 55                	push   %r13
    4ff6:	41 54                	push   %r12
    4ff8:	55                   	push   %rbp
    4ff9:	53                   	push   %rbx
    4ffa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    5001:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5008:	00 00 
    500a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    5011:	00 
    5012:	49 89 d4             	mov    %rdx,%r12
    5015:	8b 12                	mov    (%rdx),%edx
    5017:	83 fa 19             	cmp    $0x19,%edx
    501a:	77 64                	ja     5080 <fwp_write.constprop.0+0x90>
    501c:	48 8d 0d ad 63 00 00 	lea    0x63ad(%rip),%rcx        # b3d0 <_IO_stdin_used+0x3d0>
    5023:	89 d0                	mov    %edx,%eax
    5025:	48 89 fb             	mov    %rdi,%rbx
    5028:	48 89 f5             	mov    %rsi,%rbp
    502b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    502f:	48 01 c8             	add    %rcx,%rax
    5032:	3e ff e0             	notrack jmp *%rax
    5035:	0f 1f 00             	nopl   (%rax)
    5038:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    503c:	48 8b 06             	mov    (%rsi),%rax
    503f:	48 89 ca             	mov    %rcx,%rdx
    5042:	48 85 c9             	test   %rcx,%rcx
    5045:	0f 88 b5 0c 00 00    	js     5d00 <fwp_write.constprop.0+0xd10>
    504b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5052:	00 
    5053:	48 89 c6             	mov    %rax,%rsi
    5056:	4c 89 e7             	mov    %r12,%rdi
    5059:	e8 a2 d9 ff ff       	call   2a00 <fwp_fmt_u128>
    505e:	66 90                	xchg   %ax,%ax
    5060:	4c 89 e7             	mov    %r12,%rdi
    5063:	e8 c8 d3 ff ff       	call   2430 <strlen@plt>
    5068:	4c 89 e6             	mov    %r12,%rsi
    506b:	48 89 df             	mov    %rbx,%rdi
    506e:	48 89 c2             	mov    %rax,%rdx
    5071:	e8 0a df ff ff       	call   2f80 <buf_put>
    5076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    507d:	00 00 00 
    5080:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5087:	00 
    5088:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    508f:	00 00 
    5091:	0f 85 9e 04 00 00    	jne    5535 <fwp_write.constprop.0+0x545>
    5097:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    509e:	5b                   	pop    %rbx
    509f:	5d                   	pop    %rbp
    50a0:	41 5c                	pop    %r12
    50a2:	41 5d                	pop    %r13
    50a4:	41 5e                	pop    %r14
    50a6:	41 5f                	pop    %r15
    50a8:	c3                   	ret
    50a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50b0:	49 89 f1             	mov    %rsi,%r9
    50b3:	4c 8d 05 23 60 00 00 	lea    0x6023(%rip),%r8        # b0dd <_IO_stdin_used+0xdd>
    50ba:	b9 00 02 00 00       	mov    $0x200,%ecx
    50bf:	ba 02 00 00 00       	mov    $0x2,%edx
    50c4:	be 00 02 00 00       	mov    $0x200,%esi
    50c9:	31 c0                	xor    %eax,%eax
    50cb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50d2:	00 
    50d3:	e8 b8 d2 ff ff       	call   2390 <__snprintf_chk@plt>
    50d8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50df:	00 
    50e0:	e8 4b d3 ff ff       	call   2430 <strlen@plt>
    50e5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    50ec:	00 
    50ed:	48 89 df             	mov    %rbx,%rdi
    50f0:	48 89 c2             	mov    %rax,%rdx
    50f3:	e8 88 de ff ff       	call   2f80 <buf_put>
    50f8:	eb 86                	jmp    5080 <fwp_write.constprop.0+0x90>
    50fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5100:	49 89 f1             	mov    %rsi,%r9
    5103:	4c 8d 05 ce 5f 00 00 	lea    0x5fce(%rip),%r8        # b0d8 <_IO_stdin_used+0xd8>
    510a:	eb ae                	jmp    50ba <fwp_write.constprop.0+0xca>
    510c:	0f 1f 40 00          	nopl   0x0(%rax)
    5110:	83 fa 13             	cmp    $0x13,%edx
    5113:	48 8d 05 b4 5f 00 00 	lea    0x5fb4(%rip),%rax        # b0ce <_IO_stdin_used+0xce>
    511a:	48 8d 35 b2 5f 00 00 	lea    0x5fb2(%rip),%rsi        # b0d3 <_IO_stdin_used+0xd3>
    5121:	ba 04 00 00 00       	mov    $0x4,%edx
    5126:	48 0f 44 f0          	cmove  %rax,%rsi
    512a:	45 31 ed             	xor    %r13d,%r13d
    512d:	e8 4e de ff ff       	call   2f80 <buf_put>
    5132:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5137:	0f 84 b3 09 00 00    	je     5af0 <fwp_write.constprop.0+0xb00>
    513d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5142:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5147:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    514c:	48 89 df             	mov    %rbx,%rdi
    514f:	49 0f 44 c5          	cmove  %r13,%rax
    5153:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5158:	e8 93 fe ff ff       	call   4ff0 <fwp_write.constprop.0>
    515d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5162:	0f 84 80 0a 00 00    	je     5be8 <fwp_write.constprop.0+0xbf8>
    5168:	49 83 c5 01          	add    $0x1,%r13
    516c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5170:	0f 83 7a 09 00 00    	jae    5af0 <fwp_write.constprop.0+0xb00>
    5176:	ba 02 00 00 00       	mov    $0x2,%edx
    517b:	48 8d 35 9b 5f 00 00 	lea    0x5f9b(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5182:	48 89 df             	mov    %rbx,%rdi
    5185:	e8 f6 dd ff ff       	call   2f80 <buf_put>
    518a:	eb b1                	jmp    513d <fwp_write.constprop.0+0x14d>
    518c:	0f 1f 40 00          	nopl   0x0(%rax)
    5190:	ba 06 00 00 00       	mov    $0x6,%edx
    5195:	48 8d 35 5a 5f 00 00 	lea    0x5f5a(%rip),%rsi        # b0f6 <_IO_stdin_used+0xf6>
    519c:	48 83 c5 10          	add    $0x10,%rbp
    51a0:	e8 db dd ff ff       	call   2f80 <buf_put>
    51a5:	48 89 ef             	mov    %rbp,%rdi
    51a8:	e8 83 d2 ff ff       	call   2430 <strlen@plt>
    51ad:	48 89 ee             	mov    %rbp,%rsi
    51b0:	48 89 df             	mov    %rbx,%rdi
    51b3:	48 89 c2             	mov    %rax,%rdx
    51b6:	e8 c5 dd ff ff       	call   2f80 <buf_put>
    51bb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51c0:	ba 01 00 00 00       	mov    $0x1,%edx
    51c5:	48 89 df             	mov    %rbx,%rdi
    51c8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    51cd:	e8 ae dd ff ff       	call   2f80 <buf_put>
    51d2:	e9 a9 fe ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    51d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51de:	00 00 
    51e0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    51e7:	00 
    51e8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ef:	00 00 
    51f1:	0f 85 3e 03 00 00    	jne    5535 <fwp_write.constprop.0+0x545>
    51f7:	ba 0a 00 00 00       	mov    $0xa,%edx
    51fc:	48 8d 35 df 5e 00 00 	lea    0x5edf(%rip),%rsi        # b0e2 <_IO_stdin_used+0xe2>
    5203:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    520a:	48 89 df             	mov    %rbx,%rdi
    520d:	5b                   	pop    %rbx
    520e:	5d                   	pop    %rbp
    520f:	41 5c                	pop    %r12
    5211:	41 5d                	pop    %r13
    5213:	41 5e                	pop    %r14
    5215:	41 5f                	pop    %r15
    5217:	e9 64 dd ff ff       	jmp    2f80 <buf_put>
    521c:	0f 1f 40 00          	nopl   0x0(%rax)
    5220:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5225:	4d 85 ed             	test   %r13,%r13
    5228:	0f 84 c2 0b 00 00    	je     5df0 <fwp_write.constprop.0+0xe00>
    522e:	48 8d 35 f5 5e 00 00 	lea    0x5ef5(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5235:	4c 89 ef             	mov    %r13,%rdi
    5238:	e8 d3 d2 ff ff       	call   2510 <strcmp@plt>
    523d:	41 89 c1             	mov    %eax,%r9d
    5240:	85 c0                	test   %eax,%eax
    5242:	0f 84 2c 0c 00 00    	je     5e74 <fwp_write.constprop.0+0xe84>
    5248:	4c 89 ef             	mov    %r13,%rdi
    524b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5250:	e8 db d1 ff ff       	call   2430 <strlen@plt>
    5255:	4c 89 ee             	mov    %r13,%rsi
    5258:	48 89 df             	mov    %rbx,%rdi
    525b:	48 89 c2             	mov    %rax,%rdx
    525e:	e8 1d dd ff ff       	call   2f80 <buf_put>
    5263:	ba 01 00 00 00       	mov    $0x1,%edx
    5268:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    526d:	48 89 df             	mov    %rbx,%rdi
    5270:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5275:	e8 06 dd ff ff       	call   2f80 <buf_put>
    527a:	ba 01 00 00 00       	mov    $0x1,%edx
    527f:	4c 89 fe             	mov    %r15,%rsi
    5282:	48 89 df             	mov    %rbx,%rdi
    5285:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    528a:	e8 f1 dc ff ff       	call   2f80 <buf_put>
    528f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5294:	45 31 f6             	xor    %r14d,%r14d
    5297:	85 c0                	test   %eax,%eax
    5299:	0f 8e 91 0a 00 00    	jle    5d30 <fwp_write.constprop.0+0xd40>
    529f:	45 31 ed             	xor    %r13d,%r13d
    52a2:	4d 85 ed             	test   %r13,%r13
    52a5:	0f 85 d5 08 00 00    	jne    5b80 <fwp_write.constprop.0+0xb90>
    52ab:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    52b2:	00 
    52b3:	45 85 f6             	test   %r14d,%r14d
    52b6:	0f 84 74 08 00 00    	je     5b30 <fwp_write.constprop.0+0xb40>
    52bc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    52c1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    52c6:	48 89 df             	mov    %rbx,%rdi
    52c9:	49 83 c5 01          	add    $0x1,%r13
    52cd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    52d1:	e8 1a fd ff ff       	call   4ff0 <fwp_write.constprop.0>
    52d6:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    52db:	7f c5                	jg     52a2 <fwp_write.constprop.0+0x2b2>
    52dd:	45 85 f6             	test   %r14d,%r14d
    52e0:	0f 84 4a 0a 00 00    	je     5d30 <fwp_write.constprop.0+0xd40>
    52e6:	b8 29 00 00 00       	mov    $0x29,%eax
    52eb:	ba 01 00 00 00       	mov    $0x1,%edx
    52f0:	4c 89 fe             	mov    %r15,%rsi
    52f3:	48 89 df             	mov    %rbx,%rdi
    52f6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    52fa:	e8 81 dc ff ff       	call   2f80 <buf_put>
    52ff:	e9 7c fd ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5304:	0f 1f 40 00          	nopl   0x0(%rax)
    5308:	ba 01 00 00 00       	mov    $0x1,%edx
    530d:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5312:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    5317:	e8 64 dc ff ff       	call   2f80 <buf_put>
    531c:	48 85 ed             	test   %rbp,%rbp
    531f:	0f 84 8b 07 00 00    	je     5ab0 <fwp_write.constprop.0+0xac0>
    5325:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5329:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    532e:	48 89 df             	mov    %rbx,%rdi
    5331:	e8 ba fc ff ff       	call   4ff0 <fwp_write.constprop.0>
    5336:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    533a:	48 85 ed             	test   %rbp,%rbp
    533d:	0f 84 6d 07 00 00    	je     5ab0 <fwp_write.constprop.0+0xac0>
    5343:	ba 02 00 00 00       	mov    $0x2,%edx
    5348:	48 8d 35 ce 5d 00 00 	lea    0x5dce(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    534f:	48 89 df             	mov    %rbx,%rdi
    5352:	e8 29 dc ff ff       	call   2f80 <buf_put>
    5357:	eb cc                	jmp    5325 <fwp_write.constprop.0+0x335>
    5359:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5360:	4c 8b 2e             	mov    (%rsi),%r13
    5363:	ba 01 00 00 00       	mov    $0x1,%edx
    5368:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    536d:	48 83 c5 08          	add    $0x8,%rbp
    5371:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5376:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    537b:	e8 00 dc ff ff       	call   2f80 <buf_put>
    5380:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5385:	4d 85 ed             	test   %r13,%r13
    5388:	75 43                	jne    53cd <fwp_write.constprop.0+0x3dd>
    538a:	e9 81 07 00 00       	jmp    5b10 <fwp_write.constprop.0+0xb20>
    538f:	90                   	nop
    5390:	41 80 f9 09          	cmp    $0x9,%r9b
    5394:	0f 84 f6 06 00 00    	je     5a90 <fwp_write.constprop.0+0xaa0>
    539a:	41 80 f9 0a          	cmp    $0xa,%r9b
    539e:	0f 85 bc 06 00 00    	jne    5a60 <fwp_write.constprop.0+0xa70>
    53a4:	ba 02 00 00 00       	mov    $0x2,%edx
    53a9:	48 8d 35 53 5d 00 00 	lea    0x5d53(%rip),%rsi        # b103 <_IO_stdin_used+0x103>
    53b0:	48 89 df             	mov    %rbx,%rdi
    53b3:	e8 c8 db ff ff       	call   2f80 <buf_put>
    53b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    53bf:	00 
    53c0:	48 83 c5 01          	add    $0x1,%rbp
    53c4:	49 39 ec             	cmp    %rbp,%r12
    53c7:	0f 84 43 07 00 00    	je     5b10 <fwp_write.constprop.0+0xb20>
    53cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    53d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    53d6:	0f 84 64 06 00 00    	je     5a40 <fwp_write.constprop.0+0xa50>
    53dc:	7e b2                	jle    5390 <fwp_write.constprop.0+0x3a0>
    53de:	41 80 f9 22          	cmp    $0x22,%r9b
    53e2:	0f 84 38 06 00 00    	je     5a20 <fwp_write.constprop.0+0xa30>
    53e8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    53ec:	0f 85 6e 06 00 00    	jne    5a60 <fwp_write.constprop.0+0xa70>
    53f2:	ba 02 00 00 00       	mov    $0x2,%edx
    53f7:	48 8d 35 02 5d 00 00 	lea    0x5d02(%rip),%rsi        # b100 <_IO_stdin_used+0x100>
    53fe:	48 89 df             	mov    %rbx,%rdi
    5401:	e8 7a db ff ff       	call   2f80 <buf_put>
    5406:	eb b8                	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5408:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    540f:	00 
    5410:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    5415:	ba 01 00 00 00       	mov    $0x1,%edx
    541a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    541f:	48 89 ee             	mov    %rbp,%rsi
    5422:	e8 59 db ff ff       	call   2f80 <buf_put>
    5427:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    542c:	4c 89 e7             	mov    %r12,%rdi
    542f:	e8 fc cf ff ff       	call   2430 <strlen@plt>
    5434:	4c 89 e6             	mov    %r12,%rsi
    5437:	48 89 df             	mov    %rbx,%rdi
    543a:	48 89 c2             	mov    %rax,%rdx
    543d:	e8 3e db ff ff       	call   2f80 <buf_put>
    5442:	ba 01 00 00 00       	mov    $0x1,%edx
    5447:	48 89 ee             	mov    %rbp,%rsi
    544a:	48 89 df             	mov    %rbx,%rdi
    544d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5452:	e8 29 db ff ff       	call   2f80 <buf_put>
    5457:	e9 24 fc ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    545c:	0f 1f 40 00          	nopl   0x0(%rax)
    5460:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5465:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5469:	0f 8a de 0a 00 00    	jp     5f4d <fwp_write.constprop.0+0xf5d>
    546f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5473:	66 0f 54 05 45 60 00 	andpd  0x6045(%rip),%xmm0        # b4c0 <msg.3+0x80>
    547a:	00 
    547b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5480:	66 0f 2e 05 58 60 00 	ucomisd 0x6058(%rip),%xmm0        # b4e0 <msg.3+0xa0>
    5487:	00 
    5488:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    548f:	00 
    5490:	0f 87 02 09 00 00    	ja     5d98 <fwp_write.constprop.0+0xda8>
    5496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    549d:	00 00 00 
    54a0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    54a4:	89 ee                	mov    %ebp,%esi
    54a6:	4c 89 e7             	mov    %r12,%rdi
    54a9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    54ae:	e8 cd dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    54b3:	31 f6                	xor    %esi,%esi
    54b5:	4c 89 e7             	mov    %r12,%rdi
    54b8:	e8 33 cf ff ff       	call   23f0 <strtod@plt>
    54bd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    54c2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    54c6:	7a 06                	jp     54ce <fwp_write.constprop.0+0x4de>
    54c8:	0f 84 09 03 00 00    	je     57d7 <fwp_write.constprop.0+0x7e7>
    54ce:	83 c5 01             	add    $0x1,%ebp
    54d1:	83 fd 12             	cmp    $0x12,%ebp
    54d4:	75 ca                	jne    54a0 <fwp_write.constprop.0+0x4b0>
    54d6:	be 11 00 00 00       	mov    $0x11,%esi
    54db:	66 0f 28 c1          	movapd %xmm1,%xmm0
    54df:	4c 89 e7             	mov    %r12,%rdi
    54e2:	e8 99 dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    54e7:	e9 eb 02 00 00       	jmp    57d7 <fwp_write.constprop.0+0x7e7>
    54ec:	0f 1f 40 00          	nopl   0x0(%rax)
    54f0:	48 83 fe 01          	cmp    $0x1,%rsi
    54f4:	0f 84 86 08 00 00    	je     5d80 <fwp_write.constprop.0+0xd90>
    54fa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    54fe:	b8 02 00 00 00       	mov    $0x2,%eax
    5503:	ba 01 00 00 00       	mov    $0x1,%edx
    5508:	48 0f 44 d0          	cmove  %rax,%rdx
    550c:	48 8d 35 b9 5b 00 00 	lea    0x5bb9(%rip),%rsi        # b0cc <_IO_stdin_used+0xcc>
    5513:	48 8d 05 af 5b 00 00 	lea    0x5baf(%rip),%rax        # b0c9 <_IO_stdin_used+0xc9>
    551a:	48 0f 44 f0          	cmove  %rax,%rsi
    551e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5525:	00 
    5526:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    552d:	00 00 
    552f:	0f 84 ce fc ff ff    	je     5203 <fwp_write.constprop.0+0x213>
    5535:	e8 06 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    553a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5540:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5545:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    554a:	e8 71 d9 ff ff       	call   2ec0 <buf_grow>
    554f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5553:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5559:	4c 03 0b             	add    (%rbx),%r9
    555c:	66 45 89 11          	mov    %r10w,(%r9)
    5560:	49 83 c1 01          	add    $0x1,%r9
    5564:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    556b:	55 55 55 
    556e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5575:	aa aa aa 
    5578:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    557c:	45 85 e4             	test   %r12d,%r12d
    557f:	7f 4c                	jg     55cd <fwp_write.constprop.0+0x5dd>
    5581:	e9 4a 05 00 00       	jmp    5ad0 <fwp_write.constprop.0+0xae0>
    5586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    558d:	00 00 00 
    5590:	be 01 00 00 00       	mov    $0x1,%esi
    5595:	b8 2d 00 00 00       	mov    $0x2d,%eax
    559a:	88 07                	mov    %al,(%rdi)
    559c:	48 89 e8             	mov    %rbp,%rax
    559f:	49 f7 e8             	imul   %r8
    55a2:	48 89 e8             	mov    %rbp,%rax
    55a5:	48 c1 f8 3f          	sar    $0x3f,%rax
    55a9:	48 29 c2             	sub    %rax,%rdx
    55ac:	48 85 c9             	test   %rcx,%rcx
    55af:	0f 95 c0             	setne  %al
    55b2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    55b6:	48 83 ef 01          	sub    $0x1,%rdi
    55ba:	48 21 c5             	and    %rax,%rbp
    55bd:	48 29 ea             	sub    %rbp,%rdx
    55c0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    55c4:	49 39 f9             	cmp    %rdi,%r9
    55c7:	0f 84 03 05 00 00    	je     5ad0 <fwp_write.constprop.0+0xae0>
    55cd:	48 89 e8             	mov    %rbp,%rax
    55d0:	49 f7 e8             	imul   %r8
    55d3:	48 89 e8             	mov    %rbp,%rax
    55d6:	48 c1 f8 3f          	sar    $0x3f,%rax
    55da:	48 89 d1             	mov    %rdx,%rcx
    55dd:	48 29 c1             	sub    %rax,%rcx
    55e0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    55e4:	48 89 e9             	mov    %rbp,%rcx
    55e7:	48 29 c1             	sub    %rax,%rcx
    55ea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    55ee:	49 f7 e2             	mul    %r10
    55f1:	b8 30 00 00 00       	mov    $0x30,%eax
    55f6:	48 89 d6             	mov    %rdx,%rsi
    55f9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    55fd:	48 d1 ee             	shr    $1,%rsi
    5600:	48 01 f2             	add    %rsi,%rdx
    5603:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    5607:	48 29 d6             	sub    %rdx,%rsi
    560a:	74 8e                	je     559a <fwp_write.constprop.0+0x5aa>
    560c:	48 83 fe 01          	cmp    $0x1,%rsi
    5610:	0f 85 7a ff ff ff    	jne    5590 <fwp_write.constprop.0+0x5a0>
    5616:	31 f6                	xor    %esi,%esi
    5618:	b8 2b 00 00 00       	mov    $0x2b,%eax
    561d:	e9 78 ff ff ff       	jmp    559a <fwp_write.constprop.0+0x5aa>
    5622:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5628:	ba 06 00 00 00       	mov    $0x6,%edx
    562d:	48 8d 35 ec 5a 00 00 	lea    0x5aec(%rip),%rsi        # b120 <_IO_stdin_used+0x120>
    5634:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    563a:	e8 41 d9 ff ff       	call   2f80 <buf_put>
    563f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5646:	ff ff 7f 
    5649:	48 23 55 00          	and    0x0(%rbp),%rdx
    564d:	0f 84 4e 03 00 00    	je     59a1 <fwp_write.constprop.0+0x9b1>
    5653:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5658:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    565c:	48 85 d2             	test   %rdx,%rdx
    565f:	0f 84 a4 00 00 00    	je     5709 <fwp_write.constprop.0+0x719>
    5665:	8b 0a                	mov    (%rdx),%ecx
    5667:	83 f9 1c             	cmp    $0x1c,%ecx
    566a:	0f 84 d0 06 00 00    	je     5d40 <fwp_write.constprop.0+0xd50>
    5670:	83 f9 1b             	cmp    $0x1b,%ecx
    5673:	0f 87 90 00 00 00    	ja     5709 <fwp_write.constprop.0+0x719>
    5679:	be 01 00 00 00       	mov    $0x1,%esi
    567e:	48 d3 e6             	shl    %cl,%rsi
    5681:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5687:	0f 85 13 06 00 00    	jne    5ca0 <fwp_write.constprop.0+0xcb0>
    568d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5693:	0f 85 d7 05 00 00    	jne    5c70 <fwp_write.constprop.0+0xc80>
    5699:	83 e6 21             	and    $0x21,%esi
    569c:	74 6b                	je     5709 <fwp_write.constprop.0+0x719>
    569e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    56a3:	48 85 ff             	test   %rdi,%rdi
    56a6:	79 07                	jns    56af <fwp_write.constprop.0+0x6bf>
    56a8:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    56ac:	4c 01 ee             	add    %r13,%rsi
    56af:	48 0f be 3e          	movsbq (%rsi),%rdi
    56b3:	85 c9                	test   %ecx,%ecx
    56b5:	40 0f b6 f7          	movzbl %dil,%esi
    56b9:	48 0f 44 f7          	cmove  %rdi,%rsi
    56bd:	0f 1f 00             	nopl   (%rax)
    56c0:	48 89 df             	mov    %rbx,%rdi
    56c3:	49 83 c5 01          	add    $0x1,%r13
    56c7:	e8 24 f9 ff ff       	call   4ff0 <fwp_write.constprop.0>
    56cc:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    56d3:	ff ff 7f 
    56d6:	48 23 55 00          	and    0x0(%rbp),%rdx
    56da:	49 39 d5             	cmp    %rdx,%r13
    56dd:	0f 83 be 02 00 00    	jae    59a1 <fwp_write.constprop.0+0x9b1>
    56e3:	ba 02 00 00 00       	mov    $0x2,%edx
    56e8:	48 89 df             	mov    %rbx,%rdi
    56eb:	48 8d 35 2b 5a 00 00 	lea    0x5a2b(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    56f2:	e8 89 d8 ff ff       	call   2f80 <buf_put>
    56f7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    56fc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    5700:	48 85 d2             	test   %rdx,%rdx
    5703:	0f 85 5c ff ff ff    	jne    5665 <fwp_write.constprop.0+0x675>
    5709:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    570e:	48 85 ff             	test   %rdi,%rdi
    5711:	0f 88 51 06 00 00    	js     5d68 <fwp_write.constprop.0+0xd78>
    5717:	48 8b 31             	mov    (%rcx),%rsi
    571a:	eb a4                	jmp    56c0 <fwp_write.constprop.0+0x6d0>
    571c:	0f 1f 40 00          	nopl   0x0(%rax)
    5720:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5727:	00 
    5728:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    572f:	00 00 
    5731:	0f 85 fe fd ff ff    	jne    5535 <fwp_write.constprop.0+0x545>
    5737:	ba 08 00 00 00       	mov    $0x8,%edx
    573c:	48 8d 35 aa 59 00 00 	lea    0x59aa(%rip),%rsi        # b0ed <_IO_stdin_used+0xed>
    5743:	e9 bb fa ff ff       	jmp    5203 <fwp_write.constprop.0+0x213>
    5748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    574f:	00 
    5750:	66 0f 6e ce          	movd   %esi,%xmm1
    5754:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5757:	0f 8a f0 07 00 00    	jp     5f4d <fwp_write.constprop.0+0xf5d>
    575d:	0f 28 c1             	movaps %xmm1,%xmm0
    5760:	0f 54 05 49 5d 00 00 	andps  0x5d49(%rip),%xmm0        # b4b0 <msg.3+0x70>
    5767:	0f 2e 05 96 58 00 00 	ucomiss 0x5896(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    576e:	0f 87 4c 06 00 00    	ja     5dc0 <fwp_write.constprop.0+0xdd0>
    5774:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5778:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    577e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5785:	00 
    5786:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    578a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    578f:	90                   	nop
    5790:	44 89 ee             	mov    %r13d,%esi
    5793:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5798:	4c 89 e7             	mov    %r12,%rdi
    579b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    57a0:	e8 db d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    57a5:	31 f6                	xor    %esi,%esi
    57a7:	4c 89 e7             	mov    %r12,%rdi
    57aa:	e8 e1 cc ff ff       	call   2490 <strtof@plt>
    57af:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    57b4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    57b7:	7a 02                	jp     57bb <fwp_write.constprop.0+0x7cb>
    57b9:	74 1c                	je     57d7 <fwp_write.constprop.0+0x7e7>
    57bb:	41 83 c5 01          	add    $0x1,%r13d
    57bf:	41 83 fd 0a          	cmp    $0xa,%r13d
    57c3:	75 cb                	jne    5790 <fwp_write.constprop.0+0x7a0>
    57c5:	be 09 00 00 00       	mov    $0x9,%esi
    57ca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    57cf:	4c 89 e7             	mov    %r12,%rdi
    57d2:	e8 a9 d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    57d7:	4c 89 e7             	mov    %r12,%rdi
    57da:	e8 61 d8 ff ff       	call   3040 <fwp_finish_float>
    57df:	e9 7c f8 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    57e4:	0f 1f 40 00          	nopl   0x0(%rax)
    57e8:	89 f0                	mov    %esi,%eax
    57ea:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    57f1:	76 02                	jbe    57f5 <fwp_write.constprop.0+0x805>
    57f3:	8b 06                	mov    (%rsi),%eax
    57f5:	41 89 c6             	mov    %eax,%r14d
    57f8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    57fd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5802:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5806:	4c 89 ef             	mov    %r13,%rdi
    5809:	e8 22 cc ff ff       	call   2430 <strlen@plt>
    580e:	4c 89 ee             	mov    %r13,%rsi
    5811:	48 89 df             	mov    %rbx,%rdi
    5814:	48 89 c2             	mov    %rax,%rdx
    5817:	e8 64 d7 ff ff       	call   2f80 <buf_put>
    581c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5821:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5825:	85 f6                	test   %esi,%esi
    5827:	0f 8e 53 f8 ff ff    	jle    5080 <fwp_write.constprop.0+0x90>
    582d:	45 31 ed             	xor    %r13d,%r13d
    5830:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5835:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    583a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    583f:	4c 89 fe             	mov    %r15,%rsi
    5842:	48 89 df             	mov    %rbx,%rdi
    5845:	ba 01 00 00 00       	mov    $0x1,%edx
    584a:	48 89 04 24          	mov    %rax,(%rsp)
    584e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5853:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5857:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    585b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5860:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5865:	e8 16 d7 ff ff       	call   2f80 <buf_put>
    586a:	41 8b 06             	mov    (%r14),%eax
    586d:	83 f8 0e             	cmp    $0xe,%eax
    5870:	0f 84 5a 03 00 00    	je     5bd0 <fwp_write.constprop.0+0xbe0>
    5876:	83 f8 10             	cmp    $0x10,%eax
    5879:	0f 84 21 03 00 00    	je     5ba0 <fwp_write.constprop.0+0xbb0>
    587f:	83 f8 0a             	cmp    $0xa,%eax
    5882:	0f 84 68 04 00 00    	je     5cf0 <fwp_write.constprop.0+0xd00>
    5888:	0f 8f 32 01 00 00    	jg     59c0 <fwp_write.constprop.0+0x9d0>
    588e:	83 f8 03             	cmp    $0x3,%eax
    5891:	0f 8f 39 04 00 00    	jg     5cd0 <fwp_write.constprop.0+0xce0>
    5897:	85 c0                	test   %eax,%eax
    5899:	78 10                	js     58ab <fwp_write.constprop.0+0x8bb>
    589b:	48 8b 04 24          	mov    (%rsp),%rax
    589f:	48 c1 e8 3f          	shr    $0x3f,%rax
    58a3:	85 c0                	test   %eax,%eax
    58a5:	0f 85 32 01 00 00    	jne    59dd <fwp_write.constprop.0+0x9ed>
    58ab:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    58b0:	48 8b 34 24          	mov    (%rsp),%rsi
    58b4:	48 89 df             	mov    %rbx,%rdi
    58b7:	e8 34 f7 ff ff       	call   4ff0 <fwp_write.constprop.0>
    58bc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    58c1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    58c6:	49 83 c5 01          	add    $0x1,%r13
    58ca:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    58ce:	0f 8f 61 ff ff ff    	jg     5835 <fwp_write.constprop.0+0x845>
    58d4:	e9 a7 f7 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    58d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    58e4:	48 8b 36             	mov    (%rsi),%rsi
    58e7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    58ee:	00 
    58ef:	48 89 ef             	mov    %rbp,%rdi
    58f2:	e8 09 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    58f7:	48 89 ef             	mov    %rbp,%rdi
    58fa:	e8 31 cb ff ff       	call   2430 <strlen@plt>
    58ff:	48 89 ee             	mov    %rbp,%rsi
    5902:	48 89 df             	mov    %rbx,%rdi
    5905:	48 89 c2             	mov    %rax,%rdx
    5908:	e8 73 d6 ff ff       	call   2f80 <buf_put>
    590d:	e9 6e f7 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5912:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5918:	ba 06 00 00 00       	mov    $0x6,%edx
    591d:	48 8d 35 ef 57 00 00 	lea    0x57ef(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    5924:	45 31 ed             	xor    %r13d,%r13d
    5927:	e8 54 d6 ff ff       	call   2f80 <buf_put>
    592c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5931:	75 19                	jne    594c <fwp_write.constprop.0+0x95c>
    5933:	eb 6c                	jmp    59a1 <fwp_write.constprop.0+0x9b1>
    5935:	0f 1f 00             	nopl   (%rax)
    5938:	ba 02 00 00 00       	mov    $0x2,%edx
    593d:	48 8d 35 d9 57 00 00 	lea    0x57d9(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5944:	48 89 df             	mov    %rbx,%rdi
    5947:	e8 34 d6 ff ff       	call   2f80 <buf_put>
    594c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5952:	b9 00 02 00 00       	mov    $0x200,%ecx
    5957:	31 c0                	xor    %eax,%eax
    5959:	49 83 c5 01          	add    $0x1,%r13
    595d:	4c 8d 05 b6 57 00 00 	lea    0x57b6(%rip),%r8        # b11a <_IO_stdin_used+0x11a>
    5964:	ba 02 00 00 00       	mov    $0x2,%edx
    5969:	be 00 02 00 00       	mov    $0x200,%esi
    596e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5975:	00 
    5976:	e8 15 ca ff ff       	call   2390 <__snprintf_chk@plt>
    597b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5982:	00 
    5983:	e8 a8 ca ff ff       	call   2430 <strlen@plt>
    5988:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    598f:	00 
    5990:	48 89 df             	mov    %rbx,%rdi
    5993:	48 89 c2             	mov    %rax,%rdx
    5996:	e8 e5 d5 ff ff       	call   2f80 <buf_put>
    599b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    599f:	72 97                	jb     5938 <fwp_write.constprop.0+0x948>
    59a1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    59a6:	ba 01 00 00 00       	mov    $0x1,%edx
    59ab:	48 89 df             	mov    %rbx,%rdi
    59ae:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    59b3:	e8 c8 d5 ff ff       	call   2f80 <buf_put>
    59b8:	e9 c3 f6 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    59bd:	0f 1f 00             	nopl   (%rax)
    59c0:	83 f8 0b             	cmp    $0xb,%eax
    59c3:	0f 85 e2 fe ff ff    	jne    58ab <fwp_write.constprop.0+0x8bb>
    59c9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    59ce:	66 0f 50 c3          	movmskpd %xmm3,%eax
    59d2:	83 e0 01             	and    $0x1,%eax
    59d5:	85 c0                	test   %eax,%eax
    59d7:	0f 84 ce fe ff ff    	je     58ab <fwp_write.constprop.0+0x8bb>
    59dd:	4c 89 fe             	mov    %r15,%rsi
    59e0:	48 89 df             	mov    %rbx,%rdi
    59e3:	ba 01 00 00 00       	mov    $0x1,%edx
    59e8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    59ed:	e8 8e d5 ff ff       	call   2f80 <buf_put>
    59f2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    59f7:	48 8b 34 24          	mov    (%rsp),%rsi
    59fb:	48 89 df             	mov    %rbx,%rdi
    59fe:	e8 ed f5 ff ff       	call   4ff0 <fwp_write.constprop.0>
    5a03:	ba 01 00 00 00       	mov    $0x1,%edx
    5a08:	4c 89 fe             	mov    %r15,%rsi
    5a0b:	48 89 df             	mov    %rbx,%rdi
    5a0e:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5a13:	e8 68 d5 ff ff       	call   2f80 <buf_put>
    5a18:	e9 9f fe ff ff       	jmp    58bc <fwp_write.constprop.0+0x8cc>
    5a1d:	0f 1f 00             	nopl   (%rax)
    5a20:	ba 02 00 00 00       	mov    $0x2,%edx
    5a25:	48 8d 35 d1 56 00 00 	lea    0x56d1(%rip),%rsi        # b0fd <_IO_stdin_used+0xfd>
    5a2c:	48 89 df             	mov    %rbx,%rdi
    5a2f:	e8 4c d5 ff ff       	call   2f80 <buf_put>
    5a34:	e9 87 f9 ff ff       	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a40:	ba 02 00 00 00       	mov    $0x2,%edx
    5a45:	48 8d 35 bd 56 00 00 	lea    0x56bd(%rip),%rsi        # b109 <_IO_stdin_used+0x109>
    5a4c:	48 89 df             	mov    %rbx,%rdi
    5a4f:	e8 2c d5 ff ff       	call   2f80 <buf_put>
    5a54:	e9 67 f9 ff ff       	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a60:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5a64:	0f 86 b6 01 00 00    	jbe    5c20 <fwp_write.constprop.0+0xc30>
    5a6a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5a6e:	0f 84 ac 01 00 00    	je     5c20 <fwp_write.constprop.0+0xc30>
    5a74:	ba 01 00 00 00       	mov    $0x1,%edx
    5a79:	4c 89 fe             	mov    %r15,%rsi
    5a7c:	48 89 df             	mov    %rbx,%rdi
    5a7f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5a84:	e8 f7 d4 ff ff       	call   2f80 <buf_put>
    5a89:	e9 32 f9 ff ff       	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5a8e:	66 90                	xchg   %ax,%ax
    5a90:	ba 02 00 00 00       	mov    $0x2,%edx
    5a95:	48 8d 35 6a 56 00 00 	lea    0x566a(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    5a9c:	48 89 df             	mov    %rbx,%rdi
    5a9f:	e8 dc d4 ff ff       	call   2f80 <buf_put>
    5aa4:	e9 17 f9 ff ff       	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5aa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ab0:	ba 01 00 00 00       	mov    $0x1,%edx
    5ab5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5aba:	48 89 df             	mov    %rbx,%rdi
    5abd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5ac2:	e8 b9 d4 ff ff       	call   2f80 <buf_put>
    5ac7:	e9 b4 f5 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5acc:	0f 1f 40 00          	nopl   0x0(%rax)
    5ad0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5ad4:	48 8b 13             	mov    (%rbx),%rdx
    5ad7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5adc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5ae0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5ae4:	e9 97 f5 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5af0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5af5:	ba 01 00 00 00       	mov    $0x1,%edx
    5afa:	48 89 df             	mov    %rbx,%rdi
    5afd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5b02:	e8 79 d4 ff ff       	call   2f80 <buf_put>
    5b07:	e9 74 f5 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    5b10:	ba 01 00 00 00       	mov    $0x1,%edx
    5b15:	4c 89 fe             	mov    %r15,%rsi
    5b18:	48 89 df             	mov    %rbx,%rdi
    5b1b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5b20:	e8 5b d4 ff ff       	call   2f80 <buf_put>
    5b25:	e9 56 f5 ff ff       	jmp    5080 <fwp_write.constprop.0+0x90>
    5b2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b30:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5b35:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5b3a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5b3e:	48 89 f7             	mov    %rsi,%rdi
    5b41:	48 89 34 24          	mov    %rsi,(%rsp)
    5b45:	e8 e6 c8 ff ff       	call   2430 <strlen@plt>
    5b4a:	48 8b 34 24          	mov    (%rsp),%rsi
    5b4e:	48 89 df             	mov    %rbx,%rdi
    5b51:	48 89 c2             	mov    %rax,%rdx
    5b54:	e8 27 d4 ff ff       	call   2f80 <buf_put>
    5b59:	ba 03 00 00 00       	mov    $0x3,%edx
    5b5e:	48 8d 35 db 55 00 00 	lea    0x55db(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    5b65:	48 89 df             	mov    %rbx,%rdi
    5b68:	e8 13 d4 ff ff       	call   2f80 <buf_put>
    5b6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b72:	e9 45 f7 ff ff       	jmp    52bc <fwp_write.constprop.0+0x2cc>
    5b77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b7e:	00 00 
    5b80:	ba 02 00 00 00       	mov    $0x2,%edx
    5b85:	48 8d 35 91 55 00 00 	lea    0x5591(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5b8c:	48 89 df             	mov    %rbx,%rdi
    5b8f:	e8 ec d3 ff ff       	call   2f80 <buf_put>
    5b94:	e9 12 f7 ff ff       	jmp    52ab <fwp_write.constprop.0+0x2bb>
    5b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ba0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5ba5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5ba9:	48 85 ff             	test   %rdi,%rdi
    5bac:	0f 84 f9 fc ff ff    	je     58ab <fwp_write.constprop.0+0x8bb>
    5bb2:	48 8d 35 71 55 00 00 	lea    0x5571(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5bb9:	e8 52 c9 ff ff       	call   2510 <strcmp@plt>
    5bbe:	85 c0                	test   %eax,%eax
    5bc0:	0f 95 c0             	setne  %al
    5bc3:	0f b6 c0             	movzbl %al,%eax
    5bc6:	e9 d8 fc ff ff       	jmp    58a3 <fwp_write.constprop.0+0x8b3>
    5bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5bd0:	31 c0                	xor    %eax,%eax
    5bd2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5bd9:	00 
    5bda:	0f 97 c0             	seta   %al
    5bdd:	e9 c1 fc ff ff       	jmp    58a3 <fwp_write.constprop.0+0x8b3>
    5be2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5be8:	48 89 df             	mov    %rbx,%rdi
    5beb:	ba 02 00 00 00       	mov    $0x2,%edx
    5bf0:	48 8d 35 30 55 00 00 	lea    0x5530(%rip),%rsi        # b127 <_IO_stdin_used+0x127>
    5bf7:	e8 84 d3 ff ff       	call   2f80 <buf_put>
    5bfc:	4c 89 e8             	mov    %r13,%rax
    5bff:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5c04:	48 89 df             	mov    %rbx,%rdi
    5c07:	48 c1 e0 04          	shl    $0x4,%rax
    5c0b:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5c10:	e8 db f3 ff ff       	call   4ff0 <fwp_write.constprop.0>
    5c15:	e9 4e f5 ff ff       	jmp    5168 <fwp_write.constprop.0+0x178>
    5c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c20:	4c 8d 05 e5 54 00 00 	lea    0x54e5(%rip),%r8        # b10c <_IO_stdin_used+0x10c>
    5c27:	b9 10 00 00 00       	mov    $0x10,%ecx
    5c2c:	31 c0                	xor    %eax,%eax
    5c2e:	ba 02 00 00 00       	mov    $0x2,%edx
    5c33:	be 10 00 00 00       	mov    $0x10,%esi
    5c38:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c3f:	00 
    5c40:	e8 4b c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c45:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c4c:	00 
    5c4d:	e8 de c7 ff ff       	call   2430 <strlen@plt>
    5c52:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c59:	00 
    5c5a:	48 89 df             	mov    %rbx,%rdi
    5c5d:	48 89 c2             	mov    %rax,%rdx
    5c60:	e8 1b d3 ff ff       	call   2f80 <buf_put>
    5c65:	e9 56 f7 ff ff       	jmp    53c0 <fwp_write.constprop.0+0x3d0>
    5c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c70:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5c75:	48 85 ff             	test   %rdi,%rdi
    5c78:	79 0c                	jns    5c86 <fwp_write.constprop.0+0xc96>
    5c7a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5c81:	00 
    5c82:	48 03 75 10          	add    0x10(%rbp),%rsi
    5c86:	48 63 3e             	movslq (%rsi),%rdi
    5c89:	83 f9 02             	cmp    $0x2,%ecx
    5c8c:	89 fe                	mov    %edi,%esi
    5c8e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c92:	e9 29 fa ff ff       	jmp    56c0 <fwp_write.constprop.0+0x6d0>
    5c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c9e:	00 00 
    5ca0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5ca5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5caa:	48 85 ff             	test   %rdi,%rdi
    5cad:	0f 88 6f 01 00 00    	js     5e22 <fwp_write.constprop.0+0xe32>
    5cb3:	49 0f bf 38          	movswq (%r8),%rdi
    5cb7:	83 f9 01             	cmp    $0x1,%ecx
    5cba:	0f b7 f7             	movzwl %di,%esi
    5cbd:	48 0f 44 f7          	cmove  %rdi,%rsi
    5cc1:	e9 fa f9 ff ff       	jmp    56c0 <fwp_write.constprop.0+0x6d0>
    5cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ccd:	00 00 00 
    5cd0:	83 f8 04             	cmp    $0x4,%eax
    5cd3:	0f 85 d2 fb ff ff    	jne    58ab <fwp_write.constprop.0+0x8bb>
    5cd9:	48 8b 04 24          	mov    (%rsp),%rax
    5cdd:	48 8b 40 08          	mov    0x8(%rax),%rax
    5ce1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5ce6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5cea:	e9 e6 fc ff ff       	jmp    59d5 <fwp_write.constprop.0+0x9e5>
    5cef:	90                   	nop
    5cf0:	8b 0c 24             	mov    (%rsp),%ecx
    5cf3:	31 c0                	xor    %eax,%eax
    5cf5:	85 c9                	test   %ecx,%ecx
    5cf7:	0f 98 c0             	sets   %al
    5cfa:	e9 d6 fc ff ff       	jmp    59d5 <fwp_write.constprop.0+0x9e5>
    5cff:	90                   	nop
    5d00:	48 f7 d8             	neg    %rax
    5d03:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5d0a:	00 
    5d0b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5d12:	2d 
    5d13:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5d1a:	00 
    5d1b:	48 83 d2 00          	adc    $0x0,%rdx
    5d1f:	48 89 c6             	mov    %rax,%rsi
    5d22:	48 f7 da             	neg    %rdx
    5d25:	e8 d6 cc ff ff       	call   2a00 <fwp_fmt_u128>
    5d2a:	e9 31 f3 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5d2f:	90                   	nop
    5d30:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5d35:	e9 b1 f5 ff ff       	jmp    52eb <fwp_write.constprop.0+0x2fb>
    5d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d40:	4c 89 e9             	mov    %r13,%rcx
    5d43:	48 c1 e1 04          	shl    $0x4,%rcx
    5d47:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5d4c:	48 85 ff             	test   %rdi,%rdi
    5d4f:	0f 89 6b f9 ff ff    	jns    56c0 <fwp_write.constprop.0+0x6d0>
    5d55:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d59:	48 89 ce             	mov    %rcx,%rsi
    5d5c:	e9 5f f9 ff ff       	jmp    56c0 <fwp_write.constprop.0+0x6d0>
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5d6f:	00 
    5d70:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d74:	e9 9e f9 ff ff       	jmp    5717 <fwp_write.constprop.0+0x727>
    5d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d80:	ba 02 00 00 00       	mov    $0x2,%edx
    5d85:	48 8d 35 3a 53 00 00 	lea    0x533a(%rip),%rsi        # b0c6 <_IO_stdin_used+0xc6>
    5d8c:	e9 8d f7 ff ff       	jmp    551e <fwp_write.constprop.0+0x52e>
    5d91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d98:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d9c:	48 8d 35 1f 53 00 00 	lea    0x531f(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5da3:	48 8d 05 17 53 00 00 	lea    0x5317(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5daa:	4c 89 e7             	mov    %r12,%rdi
    5dad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5db1:	48 0f 46 f0          	cmovbe %rax,%rsi
    5db5:	e8 16 c6 ff ff       	call   23d0 <strcpy@plt>
    5dba:	e9 a1 f2 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5dbf:	90                   	nop
    5dc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dc4:	48 8d 35 f7 52 00 00 	lea    0x52f7(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5dcb:	48 8d 05 ef 52 00 00 	lea    0x52ef(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5dd2:	0f 2f c8             	comiss %xmm0,%xmm1
    5dd5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ddc:	00 
    5ddd:	4c 89 e7             	mov    %r12,%rdi
    5de0:	48 0f 46 f0          	cmovbe %rax,%rsi
    5de4:	e8 e7 c5 ff ff       	call   23d0 <strcpy@plt>
    5de9:	e9 72 f2 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5dee:	66 90                	xchg   %ax,%ax
    5df0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5df5:	45 85 c0             	test   %r8d,%r8d
    5df8:	75 34                	jne    5e2e <fwp_write.constprop.0+0xe3e>
    5dfa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5e01:	00 
    5e02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5e09:	00 00 
    5e0b:	0f 85 24 f7 ff ff    	jne    5535 <fwp_write.constprop.0+0x545>
    5e11:	ba 02 00 00 00       	mov    $0x2,%edx
    5e16:	48 8d 35 20 53 00 00 	lea    0x5320(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5e1d:	e9 e1 f3 ff ff       	jmp    5203 <fwp_write.constprop.0+0x213>
    5e22:	48 03 75 10          	add    0x10(%rbp),%rsi
    5e26:	49 89 f0             	mov    %rsi,%r8
    5e29:	e9 85 fe ff ff       	jmp    5cb3 <fwp_write.constprop.0+0xcc3>
    5e2e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5e33:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e38:	85 ff                	test   %edi,%edi
    5e3a:	0f 84 3a f4 ff ff    	je     527a <fwp_write.constprop.0+0x28a>
    5e40:	ba 01 00 00 00       	mov    $0x1,%edx
    5e45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5e4a:	48 89 df             	mov    %rbx,%rdi
    5e4d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5e52:	e8 29 d1 ff ff       	call   2f80 <buf_put>
    5e57:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5e5c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e61:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5e67:	85 d2                	test   %edx,%edx
    5e69:	0f 8f 30 f4 ff ff    	jg     529f <fwp_write.constprop.0+0x2af>
    5e6f:	e9 72 f4 ff ff       	jmp    52e6 <fwp_write.constprop.0+0x2f6>
    5e74:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e78:	49 89 c5             	mov    %rax,%r13
    5e7b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5e80:	49 89 c4             	mov    %rax,%r12
    5e83:	49 c1 fd 3f          	sar    $0x3f,%r13
    5e87:	4c 09 e8             	or     %r13,%rax
    5e8a:	0f 84 a7 00 00 00    	je     5f37 <fwp_write.constprop.0+0xf47>
    5e90:	48 8d 2d c9 6c 00 00 	lea    0x6cc9(%rip),%rbp        # cb60 <units.0>
    5e97:	4d 89 e7             	mov    %r12,%r15
    5e9a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e9e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5ea3:	4c 89 ff             	mov    %r15,%rdi
    5ea6:	4c 89 ee             	mov    %r13,%rsi
    5ea9:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ead:	48 99                	cqto
    5eaf:	48 89 d1             	mov    %rdx,%rcx
    5eb2:	48 89 c2             	mov    %rax,%rdx
    5eb5:	e8 16 4b 00 00       	call   a9d0 <__divmodti4>
    5eba:	44 8b 0c 24          	mov    (%rsp),%r9d
    5ebe:	48 89 c1             	mov    %rax,%rcx
    5ec1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5ec6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5ecb:	0f 84 94 00 00 00    	je     5f65 <fwp_write.constprop.0+0xf75>
    5ed1:	41 83 c1 01          	add    $0x1,%r9d
    5ed5:	48 83 c5 10          	add    $0x10,%rbp
    5ed9:	41 83 f9 05          	cmp    $0x5,%r9d
    5edd:	75 bb                	jne    5e9a <fwp_write.constprop.0+0xeaa>
    5edf:	4d 85 ed             	test   %r13,%r13
    5ee2:	79 53                	jns    5f37 <fwp_write.constprop.0+0xf47>
    5ee4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5ee9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5eee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5ef3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5ef8:	48 99                	cqto
    5efa:	48 f7 d8             	neg    %rax
    5efd:	48 83 d2 00          	adc    $0x0,%rdx
    5f01:	48 89 c6             	mov    %rax,%rsi
    5f04:	48 f7 da             	neg    %rdx
    5f07:	e8 f4 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f0c:	49 89 e8             	mov    %rbp,%r8
    5f0f:	ba 00 02 00 00       	mov    $0x200,%edx
    5f14:	be 02 00 00 00       	mov    $0x2,%esi
    5f19:	31 c0                	xor    %eax,%eax
    5f1b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f22:	00 
    5f23:	48 8d 0d 0e 52 00 00 	lea    0x520e(%rip),%rcx        # b138 <_IO_stdin_used+0x138>
    5f2a:	4c 89 e7             	mov    %r12,%rdi
    5f2d:	e8 6e c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f32:	e9 29 f1 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5f37:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f3c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5f41:	31 d2                	xor    %edx,%edx
    5f43:	48 89 ef             	mov    %rbp,%rdi
    5f46:	e8 b5 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f4b:	eb bf                	jmp    5f0c <fwp_write.constprop.0+0xf1c>
    5f4d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5f54:	4e 61 4e 00 
    5f58:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f5f:	00 
    5f60:	e9 fb f0 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5f65:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f69:	48 89 c8             	mov    %rcx,%rax
    5f6c:	48 85 d2             	test   %rdx,%rdx
    5f6f:	78 51                	js     5fc2 <fwp_write.constprop.0+0xfd2>
    5f71:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f76:	48 89 c6             	mov    %rax,%rsi
    5f79:	48 89 ef             	mov    %rbp,%rdi
    5f7c:	e8 7f ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f81:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f85:	49 63 c1             	movslq %r9d,%rax
    5f88:	49 89 e8             	mov    %rbp,%r8
    5f8b:	ba 00 02 00 00       	mov    $0x200,%edx
    5f90:	be 02 00 00 00       	mov    $0x2,%esi
    5f95:	48 c1 e0 04          	shl    $0x4,%rax
    5f99:	48 8d 0d c0 6b 00 00 	lea    0x6bc0(%rip),%rcx        # cb60 <units.0>
    5fa0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5fa7:	00 
    5fa8:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5fac:	4c 89 e7             	mov    %r12,%rdi
    5faf:	48 8d 0d 7d 51 00 00 	lea    0x517d(%rip),%rcx        # b133 <_IO_stdin_used+0x133>
    5fb6:	31 c0                	xor    %eax,%eax
    5fb8:	e8 e3 c6 ff ff       	call   26a0 <__sprintf_chk@plt>
    5fbd:	e9 9e f0 ff ff       	jmp    5060 <fwp_write.constprop.0+0x70>
    5fc2:	48 f7 d8             	neg    %rax
    5fc5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5fca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5fcf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5fd4:	48 83 d2 00          	adc    $0x0,%rdx
    5fd8:	48 89 c6             	mov    %rax,%rsi
    5fdb:	48 f7 da             	neg    %rdx
    5fde:	e8 1d ca ff ff       	call   2a00 <fwp_fmt_u128>
    5fe3:	44 8b 0c 24          	mov    (%rsp),%r9d
    5fe7:	eb 9c                	jmp    5f85 <fwp_write.constprop.0+0xf95>
    5fe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005ff0 <fwp_hof0.constprop.0>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	41 54                	push   %r12
    5ff8:	55                   	push   %rbp
    5ff9:	53                   	push   %rbx
    5ffa:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    6001:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6008:	00 00 
    600a:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    6011:	00 
    6012:	31 c0                	xor    %eax,%eax
    6014:	48 85 f6             	test   %rsi,%rsi
    6017:	0f 84 2a 0e 00 00    	je     6e47 <fwp_hof0.constprop.0+0xe57>
    601d:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
    6022:	48 89 fb             	mov    %rdi,%rbx
    6025:	48 8d 2d 14 77 01 00 	lea    0x17714(%rip),%rbp        # 1d740 <fwp_heap>
    602c:	0f 1f 40 00          	nopl   0x0(%rax)
    6030:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6037:	48 89 d8             	mov    %rbx,%rax
    603a:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6041:	48 c1 e2 10          	shl    $0x10,%rdx
    6045:	48 39 d0             	cmp    %rdx,%rax
    6048:	73 61                	jae    60ab <fwp_hof0.constprop.0+0xbb>
    604a:	48 89 c2             	mov    %rax,%rdx
    604d:	48 c1 ea 10          	shr    $0x10,%rdx
    6051:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6055:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    605c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6060:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    6064:	4d 85 e4             	test   %r12,%r12
    6067:	74 42                	je     60ab <fwp_hof0.constprop.0+0xbb>
    6069:	0f b6 0a             	movzbl (%rdx),%ecx
    606c:	80 f9 02             	cmp    $0x2,%cl
    606f:	0f 84 83 11 00 00    	je     71f8 <fwp_hof0.constprop.0+0x1208>
    6075:	80 f9 01             	cmp    $0x1,%cl
    6078:	75 31                	jne    60ab <fwp_hof0.constprop.0+0xbb>
    607a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    607d:	0f b7 c0             	movzwl %ax,%eax
    6080:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6083:	48 0f af c1          	imul   %rcx,%rax
    6087:	48 c1 e8 20          	shr    $0x20,%rax
    608b:	48 39 d0             	cmp    %rdx,%rax
    608e:	73 1b                	jae    60ab <fwp_hof0.constprop.0+0xbb>
    6090:	49 01 c4             	add    %rax,%r12
    6093:	41 0f b6 04 24       	movzbl (%r12),%eax
    6098:	84 c0                	test   %al,%al
    609a:	74 0f                	je     60ab <fwp_hof0.constprop.0+0xbb>
    609c:	3c fd                	cmp    $0xfd,%al
    609e:	0f 87 fc 13 00 00    	ja     74a0 <fwp_hof0.constprop.0+0x14b0>
    60a4:	83 c0 01             	add    $0x1,%eax
    60a7:	41 88 04 24          	mov    %al,(%r12)
    60ab:	48 85 db             	test   %rbx,%rbx
    60ae:	0f 84 56 11 00 00    	je     720a <fwp_hof0.constprop.0+0x121a>
    60b4:	48 89 d8             	mov    %rbx,%rax
    60b7:	31 ff                	xor    %edi,%edi
    60b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    60c4:	48 83 c7 01          	add    $0x1,%rdi
    60c8:	48 85 c0             	test   %rax,%rax
    60cb:	75 f3                	jne    60c0 <fwp_hof0.constprop.0+0xd0>
    60cd:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    60d4:	ff ff 1f 
    60d7:	48 39 f8             	cmp    %rdi,%rax
    60da:	0f 82 88 14 00 00    	jb     7568 <fwp_hof0.constprop.0+0x1578>
    60e0:	e8 6b e7 ff ff       	call   4850 <fwp_array_new_packed.constprop.0>
    60e5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    60ec:	49 89 c6             	mov    %rax,%r14
    60ef:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    60f6:	48 c1 e2 10          	shl    $0x10,%rdx
    60fa:	48 39 d0             	cmp    %rdx,%rax
    60fd:	73 62                	jae    6161 <fwp_hof0.constprop.0+0x171>
    60ff:	48 89 c2             	mov    %rax,%rdx
    6102:	48 c1 ea 10          	shr    $0x10,%rdx
    6106:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    610a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    6111:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6115:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    6119:	4d 85 e4             	test   %r12,%r12
    611c:	74 43                	je     6161 <fwp_hof0.constprop.0+0x171>
    611e:	0f b6 0a             	movzbl (%rdx),%ecx
    6121:	80 f9 02             	cmp    $0x2,%cl
    6124:	0f 84 a6 10 00 00    	je     71d0 <fwp_hof0.constprop.0+0x11e0>
    612a:	80 f9 01             	cmp    $0x1,%cl
    612d:	75 29                	jne    6158 <fwp_hof0.constprop.0+0x168>
    612f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6132:	0f b7 c0             	movzwl %ax,%eax
    6135:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6138:	48 0f af c1          	imul   %rcx,%rax
    613c:	48 c1 e8 20          	shr    $0x20,%rax
    6140:	48 39 d0             	cmp    %rdx,%rax
    6143:	73 13                	jae    6158 <fwp_hof0.constprop.0+0x168>
    6145:	49 01 c4             	add    %rax,%r12
    6148:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    614d:	0f 84 91 10 00 00    	je     71e4 <fwp_hof0.constprop.0+0x11f4>
    6153:	41 c6 04 24 01       	movb   $0x1,(%r12)
    6158:	48 85 db             	test   %rbx,%rbx
    615b:	0f 84 1f 10 00 00    	je     7180 <fwp_hof0.constprop.0+0x1190>
    6161:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    6165:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6169:	49 89 d9             	mov    %rbx,%r9
    616c:	48 89 da             	mov    %rbx,%rdx
    616f:	49 89 d8             	mov    %rbx,%r8
    6172:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6178:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    617f:	48 89 d0             	mov    %rdx,%rax
    6182:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6189:	48 c1 e6 10          	shl    $0x10,%rsi
    618d:	48 39 f0             	cmp    %rsi,%rax
    6190:	73 7c                	jae    620e <fwp_hof0.constprop.0+0x21e>
    6192:	48 89 c6             	mov    %rax,%rsi
    6195:	48 c1 ee 10          	shr    $0x10,%rsi
    6199:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    619d:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    61a4:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    61a8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    61ac:	48 85 ff             	test   %rdi,%rdi
    61af:	74 5d                	je     620e <fwp_hof0.constprop.0+0x21e>
    61b1:	44 0f b6 16          	movzbl (%rsi),%r10d
    61b5:	41 80 fa 02          	cmp    $0x2,%r10b
    61b9:	0f 84 09 0a 00 00    	je     6bc8 <fwp_hof0.constprop.0+0xbd8>
    61bf:	41 80 fa 01          	cmp    $0x1,%r10b
    61c3:	75 49                	jne    620e <fwp_hof0.constprop.0+0x21e>
    61c5:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    61c9:	0f b7 c0             	movzwl %ax,%eax
    61cc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    61cf:	49 0f af c2          	imul   %r10,%rax
    61d3:	48 c1 e8 20          	shr    $0x20,%rax
    61d7:	48 39 f0             	cmp    %rsi,%rax
    61da:	73 32                	jae    620e <fwp_hof0.constprop.0+0x21e>
    61dc:	48 01 c7             	add    %rax,%rdi
    61df:	80 3f 01             	cmpb   $0x1,(%rdi)
    61e2:	75 2a                	jne    620e <fwp_hof0.constprop.0+0x21e>
    61e4:	e9 27 09 00 00       	jmp    6b10 <fwp_hof0.constprop.0+0xb20>
    61e9:	90                   	nop
    61ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61f1:	00 00 00 00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    6205:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    620a:	49 83 c5 01          	add    $0x1,%r13
    620e:	49 83 3e 00          	cmpq   $0x0,(%r14)
    6212:	0f 88 44 13 00 00    	js     755c <fwp_hof0.constprop.0+0x156c>
    6218:	4b 89 0c ee          	mov    %rcx,(%r14,%r13,8)
    621c:	4d 85 e4             	test   %r12,%r12
    621f:	75 df                	jne    6200 <fwp_hof0.constprop.0+0x210>
    6221:	4c 89 c7             	mov    %r8,%rdi
    6224:	4d 89 f4             	mov    %r14,%r12
    6227:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    622d:	e8 ee ea ff ff       	call   4d20 <fwp_drop0>
    6232:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
    6237:	31 c0                	xor    %eax,%eax
    6239:	48 85 c0             	test   %rax,%rax
    623c:	0f 85 c9 c4 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    6242:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    6249:	ff ff 7f 
    624c:	49 23 04 24          	and    (%r12),%rax
    6250:	49 89 c0             	mov    %rax,%r8
    6253:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    625a:	ff ff 1f 
    625d:	4c 39 c0             	cmp    %r8,%rax
    6260:	0f 82 02 13 00 00    	jb     7568 <fwp_hof0.constprop.0+0x1578>
    6266:	4c 89 c7             	mov    %r8,%rdi
    6269:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    626e:	e8 dd e5 ff ff       	call   4850 <fwp_array_new_packed.constprop.0>
    6273:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    627a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    627f:	49 89 c5             	mov    %rax,%r13
    6282:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6289:	48 c1 e2 10          	shl    $0x10,%rdx
    628d:	48 39 d0             	cmp    %rdx,%rax
    6290:	73 55                	jae    62e7 <fwp_hof0.constprop.0+0x2f7>
    6292:	48 89 c2             	mov    %rax,%rdx
    6295:	48 c1 ea 10          	shr    $0x10,%rdx
    6299:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    629d:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    62a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    62a8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    62ac:	48 85 db             	test   %rbx,%rbx
    62af:	74 36                	je     62e7 <fwp_hof0.constprop.0+0x2f7>
    62b1:	0f b6 0a             	movzbl (%rdx),%ecx
    62b4:	80 f9 02             	cmp    $0x2,%cl
    62b7:	0f 84 2b 0d 00 00    	je     6fe8 <fwp_hof0.constprop.0+0xff8>
    62bd:	80 f9 01             	cmp    $0x1,%cl
    62c0:	75 25                	jne    62e7 <fwp_hof0.constprop.0+0x2f7>
    62c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    62c5:	0f b7 c0             	movzwl %ax,%eax
    62c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    62cb:	48 0f af c1          	imul   %rcx,%rax
    62cf:	48 c1 e8 20          	shr    $0x20,%rax
    62d3:	48 39 d0             	cmp    %rdx,%rax
    62d6:	73 0f                	jae    62e7 <fwp_hof0.constprop.0+0x2f7>
    62d8:	48 01 c3             	add    %rax,%rbx
    62db:	80 3b ff             	cmpb   $0xff,(%rbx)
    62de:	0f 84 16 0d 00 00    	je     6ffa <fwp_hof0.constprop.0+0x100a>
    62e4:	c6 03 01             	movb   $0x1,(%rbx)
    62e7:	31 db                	xor    %ebx,%ebx
    62e9:	4d 85 c0             	test   %r8,%r8
    62ec:	0f 84 d3 05 00 00    	je     68c5 <fwp_hof0.constprop.0+0x8d5>
    62f2:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
    62f7:	41 bf 08 00 00 00    	mov    $0x8,%r15d
    62fd:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6302:	e9 0f 04 00 00       	jmp    6716 <fwp_hof0.constprop.0+0x726>
    6307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    630e:	00 00 
    6310:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    6315:	48 85 d2             	test   %rdx,%rdx
    6318:	0f 88 9a 08 00 00    	js     6bb8 <fwp_hof0.constprop.0+0xbc8>
    631e:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
    6325:	00 00 
    6327:	48 8b 3c d9          	mov    (%rcx,%rbx,8),%rdi
    632b:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    6330:	48 85 db             	test   %rbx,%rbx
    6333:	74 73                	je     63a8 <fwp_hof0.constprop.0+0x3b8>
    6335:	f2 42 0f 10 54 39 f0 	movsd  -0x10(%rcx,%r15,1),%xmm2
    633c:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6342:	66 0f ef e4          	pxor   %xmm4,%xmm4
    6346:	66 0f 28 c2          	movapd %xmm2,%xmm0
    634a:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    634e:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6352:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6356:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
    635a:	66 0f 28 d8          	movapd %xmm0,%xmm3
    635e:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
    6362:	f2 0f 10 05 7e 51 00 	movsd  0x517e(%rip),%xmm0        # b4e8 <msg.3+0xa8>
    6369:	00 
    636a:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    636e:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6372:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6376:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    637a:	f2 0f 59 05 6e 51 00 	mulsd  0x516e(%rip),%xmm0        # b4f0 <msg.3+0xb0>
    6381:	00 
    6382:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6386:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    638a:	f2 0f 10 0d 56 51 00 	movsd  0x5156(%rip),%xmm1        # b4e8 <msg.3+0xa8>
    6391:	00 
    6392:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    6396:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    639a:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    639e:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    63a2:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    63a8:	48 83 c3 01          	add    $0x1,%rbx
    63ac:	48 39 d8             	cmp    %rbx,%rax
    63af:	0f 84 b3 03 00 00    	je     6768 <fwp_hof0.constprop.0+0x778>
    63b5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    63bc:	00 f0 3f 
    63bf:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    63c6:	00 
    63c7:	31 ff                	xor    %edi,%edi
    63c9:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    63d0:	00 
    63d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    63d6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    63dd:	00 
    63de:	e8 3d e3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    63e3:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    63ea:	49 89 c6             	mov    %rax,%r14
    63ed:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    63f4:	48 c1 e2 10          	shl    $0x10,%rdx
    63f8:	48 39 d0             	cmp    %rdx,%rax
    63fb:	73 57                	jae    6454 <fwp_hof0.constprop.0+0x464>
    63fd:	48 89 c2             	mov    %rax,%rdx
    6400:	48 c1 ea 10          	shr    $0x10,%rdx
    6404:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6408:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    640f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6413:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6417:	48 85 d2             	test   %rdx,%rdx
    641a:	74 38                	je     6454 <fwp_hof0.constprop.0+0x464>
    641c:	0f b6 31             	movzbl (%rcx),%esi
    641f:	40 80 fe 02          	cmp    $0x2,%sil
    6423:	0f 84 2f 04 00 00    	je     6858 <fwp_hof0.constprop.0+0x868>
    6429:	40 80 fe 01          	cmp    $0x1,%sil
    642d:	75 25                	jne    6454 <fwp_hof0.constprop.0+0x464>
    642f:	8b 71 18             	mov    0x18(%rcx),%esi
    6432:	0f b7 c0             	movzwl %ax,%eax
    6435:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6438:	48 0f af c6          	imul   %rsi,%rax
    643c:	48 c1 e8 20          	shr    $0x20,%rax
    6440:	48 39 c8             	cmp    %rcx,%rax
    6443:	73 0f                	jae    6454 <fwp_hof0.constprop.0+0x464>
    6445:	48 01 c2             	add    %rax,%rdx
    6448:	80 3a ff             	cmpb   $0xff,(%rdx)
    644b:	0f 84 1f 04 00 00    	je     6870 <fwp_hof0.constprop.0+0x880>
    6451:	c6 02 01             	movb   $0x1,(%rdx)
    6454:	49 8b 04 24          	mov    (%r12),%rax
    6458:	48 89 c2             	mov    %rax,%rdx
    645b:	48 0f ba f2 3f       	btr    $0x3f,%rdx
    6460:	48 39 d3             	cmp    %rdx,%rbx
    6463:	0f 83 c2 02 00 00    	jae    672b <fwp_hof0.constprop.0+0x73b>
    6469:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 88 99 0a 00 00    	js     6f10 <fwp_hof0.constprop.0+0xf20>
    6477:	4a 8b 04 3a          	mov    (%rdx,%r15,1),%rax
    647b:	31 ff                	xor    %edi,%edi
    647d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    6484:	00 
    6485:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
    648c:	00 00 00 00 00 
    6491:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    6498:	00 
    6499:	e8 82 e2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    649e:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    64a5:	48 89 c2             	mov    %rax,%rdx
    64a8:	48 89 c6             	mov    %rax,%rsi
    64ab:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    64b2:	48 29 fa             	sub    %rdi,%rdx
    64b5:	48 c1 e0 10          	shl    $0x10,%rax
    64b9:	48 39 c2             	cmp    %rax,%rdx
    64bc:	0f 83 7e 02 00 00    	jae    6740 <fwp_hof0.constprop.0+0x750>
    64c2:	48 89 d1             	mov    %rdx,%rcx
    64c5:	48 c1 e9 10          	shr    $0x10,%rcx
    64c9:	4c 8d 0c 89          	lea    (%rcx,%rcx,4),%r9
    64cd:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    64d4:	4e 8d 14 c9          	lea    (%rcx,%r9,8),%r10
    64d8:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    64dc:	4d 85 c9             	test   %r9,%r9
    64df:	0f 84 54 03 00 00    	je     6839 <fwp_hof0.constprop.0+0x849>
    64e5:	41 0f b6 0a          	movzbl (%r10),%ecx
    64e9:	80 f9 02             	cmp    $0x2,%cl
    64ec:	0f 84 3e 03 00 00    	je     6830 <fwp_hof0.constprop.0+0x840>
    64f2:	80 f9 01             	cmp    $0x1,%cl
    64f5:	0f 85 3e 03 00 00    	jne    6839 <fwp_hof0.constprop.0+0x849>
    64fb:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    64ff:	0f b7 ca             	movzwl %dx,%ecx
    6502:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    6506:	49 0f af cb          	imul   %r11,%rcx
    650a:	48 c1 e9 20          	shr    $0x20,%rcx
    650e:	4c 39 d1             	cmp    %r10,%rcx
    6511:	0f 83 22 03 00 00    	jae    6839 <fwp_hof0.constprop.0+0x849>
    6517:	49 01 c9             	add    %rcx,%r9
    651a:	41 80 39 ff          	cmpb   $0xff,(%r9)
    651e:	0f 84 fc 09 00 00    	je     6f20 <fwp_hof0.constprop.0+0xf30>
    6524:	41 c6 01 01          	movb   $0x1,(%r9)
    6528:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    652f:	48 89 f2             	mov    %rsi,%rdx
    6532:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6539:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    653d:	48 29 fa             	sub    %rdi,%rdx
    6540:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    6546:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    654b:	48 c1 e0 10          	shl    $0x10,%rax
    654f:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6554:	48 39 c2             	cmp    %rax,%rdx
    6557:	0f 83 f7 01 00 00    	jae    6754 <fwp_hof0.constprop.0+0x764>
    655d:	49 89 d1             	mov    %rdx,%r9
    6560:	49 c1 e9 10          	shr    $0x10,%r9
    6564:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
    6568:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    656f:	4f 8d 14 d1          	lea    (%r9,%r10,8),%r10
    6573:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    6577:	4d 85 c9             	test   %r9,%r9
    657a:	0f 84 d4 01 00 00    	je     6754 <fwp_hof0.constprop.0+0x764>
    6580:	45 0f b6 1a          	movzbl (%r10),%r11d
    6584:	41 80 fb 02          	cmp    $0x2,%r11b
    6588:	0f 84 12 03 00 00    	je     68a0 <fwp_hof0.constprop.0+0x8b0>
    658e:	41 80 fb 01          	cmp    $0x1,%r11b
    6592:	0f 85 bc 01 00 00    	jne    6754 <fwp_hof0.constprop.0+0x764>
    6598:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    659c:	0f b7 d2             	movzwl %dx,%edx
    659f:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    65a3:	49 0f af d3          	imul   %r11,%rdx
    65a7:	48 c1 ea 20          	shr    $0x20,%rdx
    65ab:	4c 39 d2             	cmp    %r10,%rdx
    65ae:	0f 83 a0 01 00 00    	jae    6754 <fwp_hof0.constprop.0+0x764>
    65b4:	49 01 d1             	add    %rdx,%r9
    65b7:	41 0f b6 11          	movzbl (%r9),%edx
    65bb:	84 d2                	test   %dl,%dl
    65bd:	0f 84 91 01 00 00    	je     6754 <fwp_hof0.constprop.0+0x764>
    65c3:	80 fa 01             	cmp    $0x1,%dl
    65c6:	0f 84 ac 01 00 00    	je     6778 <fwp_hof0.constprop.0+0x788>
    65cc:	80 fa ff             	cmp    $0xff,%dl
    65cf:	0f 84 1b 0b 00 00    	je     70f0 <fwp_hof0.constprop.0+0x1100>
    65d5:	83 ea 01             	sub    $0x1,%edx
    65d8:	41 88 11             	mov    %dl,(%r9)
    65db:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    65e2:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    65e8:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    65ee:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    65f5:	48 c1 e0 10          	shl    $0x10,%rax
    65f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6600:	4c 89 f2             	mov    %r14,%rdx
    6603:	48 29 fa             	sub    %rdi,%rdx
    6606:	48 39 c2             	cmp    %rax,%rdx
    6609:	73 75                	jae    6680 <fwp_hof0.constprop.0+0x690>
    660b:	48 89 d0             	mov    %rdx,%rax
    660e:	48 c1 e8 10          	shr    $0x10,%rax
    6612:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    6616:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    661d:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    6621:	48 8b 46 20          	mov    0x20(%rsi),%rax
    6625:	48 85 c0             	test   %rax,%rax
    6628:	74 56                	je     6680 <fwp_hof0.constprop.0+0x690>
    662a:	0f b6 3e             	movzbl (%rsi),%edi
    662d:	40 80 ff 02          	cmp    $0x2,%dil
    6631:	0f 84 59 02 00 00    	je     6890 <fwp_hof0.constprop.0+0x8a0>
    6637:	40 80 ff 01          	cmp    $0x1,%dil
    663b:	75 43                	jne    6680 <fwp_hof0.constprop.0+0x690>
    663d:	8b 7e 18             	mov    0x18(%rsi),%edi
    6640:	0f b7 d2             	movzwl %dx,%edx
    6643:	48 0f af fa          	imul   %rdx,%rdi
    6647:	8b 56 1c             	mov    0x1c(%rsi),%edx
    664a:	48 c1 ef 20          	shr    $0x20,%rdi
    664e:	48 39 d7             	cmp    %rdx,%rdi
    6651:	73 2d                	jae    6680 <fwp_hof0.constprop.0+0x690>
    6653:	48 01 f8             	add    %rdi,%rax
    6656:	0f b6 10             	movzbl (%rax),%edx
    6659:	84 d2                	test   %dl,%dl
    665b:	74 23                	je     6680 <fwp_hof0.constprop.0+0x690>
    665d:	80 fa 01             	cmp    $0x1,%dl
    6660:	0f 84 72 01 00 00    	je     67d8 <fwp_hof0.constprop.0+0x7e8>
    6666:	80 fa ff             	cmp    $0xff,%dl
    6669:	0f 84 c1 09 00 00    	je     7030 <fwp_hof0.constprop.0+0x1040>
    666f:	83 ea 01             	sub    $0x1,%edx
    6672:	88 10                	mov    %dl,(%rax)
    6674:	90                   	nop
    6675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    667c:	00 00 00 00 
    6680:	66 48 0f 6e d1       	movq   %rcx,%xmm2
    6685:	66 0f 28 f2          	movapd %xmm2,%xmm6
    6689:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
    668d:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
    6691:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
    6695:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6699:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    669d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    66a1:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    66a5:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    66a9:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    66ad:	f2 0f 59 05 3b 4e 00 	mulsd  0x4e3b(%rip),%xmm0        # b4f0 <msg.3+0xb0>
    66b4:	00 
    66b5:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    66b9:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
    66bd:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    66c1:	66 0f 28 ca          	movapd %xmm2,%xmm1
    66c5:	f2 0f 10 15 1b 4e 00 	movsd  0x4e1b(%rip),%xmm2        # b4e8 <msg.3+0xa8>
    66cc:	00 
    66cd:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    66d1:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    66d5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    66d9:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    66dd:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    66e2:	0f 88 74 0e 00 00    	js     755c <fwp_hof0.constprop.0+0x156c>
    66e8:	f2 0f 58 44 24 10    	addsd  0x10(%rsp),%xmm0
    66ee:	f2 0f 59 05 02 4e 00 	mulsd  0x4e02(%rip),%xmm0        # b4f8 <msg.3+0xb8>
    66f5:	00 
    66f6:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    66fc:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6700:	f2 43 0f 11 4c 3d 00 	movsd  %xmm1,0x0(%r13,%r15,1)
    6707:	49 83 c7 08          	add    $0x8,%r15
    670b:	48 39 5c 24 18       	cmp    %rbx,0x18(%rsp)
    6710:	0f 84 aa 01 00 00    	je     68c0 <fwp_hof0.constprop.0+0x8d0>
    6716:	49 8b 14 24          	mov    (%r12),%rdx
    671a:	48 89 d0             	mov    %rdx,%rax
    671d:	48 0f ba f0 3f       	btr    $0x3f,%rax
    6722:	48 39 c3             	cmp    %rax,%rbx
    6725:	0f 82 e5 fb ff ff    	jb     6310 <fwp_hof0.constprop.0+0x320>
    672b:	48 8d 3d f6 68 00 00 	lea    0x68f6(%rip),%rdi        # d028 <s0+0x8>
    6732:	e8 79 c9 ff ff       	call   30b0 <fwp_trap>
    6737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    673e:	00 00 
    6740:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    6744:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    674a:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    674f:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6754:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    6759:	66 0f 28 e5          	movapd %xmm5,%xmm4
    675d:	e9 9e fe ff ff       	jmp    6600 <fwp_hof0.constprop.0+0x610>
    6762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6768:	66 0f ef c0          	pxor   %xmm0,%xmm0
    676c:	e9 6c ff ff ff       	jmp    66dd <fwp_hof0.constprop.0+0x6ed>
    6771:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6778:	48 89 f7             	mov    %rsi,%rdi
    677b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    6780:	66 0f d6 4c 24 38    	movq   %xmm1,0x38(%rsp)
    6786:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    678c:	f2 0f 11 6c 24 28    	movsd  %xmm5,0x28(%rsp)
    6792:	e8 e9 dd ff ff       	call   4580 <fwp_rc_free_arr>
    6797:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    679d:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    67a4:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    67aa:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    67b1:	f3 0f 7e 4c 24 38    	movq   0x38(%rsp),%xmm1
    67b7:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    67bd:	48 c1 e0 10          	shl    $0x10,%rax
    67c1:	f2 0f 10 6c 24 28    	movsd  0x28(%rsp),%xmm5
    67c7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    67cc:	e9 2f fe ff ff       	jmp    6600 <fwp_hof0.constprop.0+0x610>
    67d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67d8:	4c 89 f7             	mov    %r14,%rdi
    67db:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    67e0:	66 0f d6 4c 24 48    	movq   %xmm1,0x48(%rsp)
    67e6:	66 0f d6 44 24 40    	movq   %xmm0,0x40(%rsp)
    67ec:	f2 0f 11 6c 24 38    	movsd  %xmm5,0x38(%rsp)
    67f2:	f2 0f 11 64 24 28    	movsd  %xmm4,0x28(%rsp)
    67f8:	66 0f d6 5c 24 20    	movq   %xmm3,0x20(%rsp)
    67fe:	e8 7d dd ff ff       	call   4580 <fwp_rc_free_arr>
    6803:	f2 0f 10 6c 24 38    	movsd  0x38(%rsp),%xmm5
    6809:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    680e:	f3 0f 7e 4c 24 48    	movq   0x48(%rsp),%xmm1
    6814:	f3 0f 7e 44 24 40    	movq   0x40(%rsp),%xmm0
    681a:	f2 0f 10 64 24 28    	movsd  0x28(%rsp),%xmm4
    6820:	f3 0f 7e 5c 24 20    	movq   0x20(%rsp),%xmm3
    6826:	e9 55 fe ff ff       	jmp    6680 <fwp_hof0.constprop.0+0x690>
    682b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6830:	66 85 d2             	test   %dx,%dx
    6833:	0f 84 e1 fc ff ff    	je     651a <fwp_hof0.constprop.0+0x52a>
    6839:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    683d:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    6843:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    6848:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    684d:	e9 0b fd ff ff       	jmp    655d <fwp_hof0.constprop.0+0x56d>
    6852:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6858:	66 85 c0             	test   %ax,%ax
    685b:	0f 85 f3 fb ff ff    	jne    6454 <fwp_hof0.constprop.0+0x464>
    6861:	80 3a ff             	cmpb   $0xff,(%rdx)
    6864:	0f 85 e7 fb ff ff    	jne    6451 <fwp_hof0.constprop.0+0x461>
    686a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6870:	48 89 d7             	mov    %rdx,%rdi
    6873:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6878:	e8 13 d5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    687d:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6882:	e9 ca fb ff ff       	jmp    6451 <fwp_hof0.constprop.0+0x461>
    6887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    688e:	00 00 
    6890:	66 85 d2             	test   %dx,%dx
    6893:	0f 85 e7 fd ff ff    	jne    6680 <fwp_hof0.constprop.0+0x690>
    6899:	e9 b8 fd ff ff       	jmp    6656 <fwp_hof0.constprop.0+0x666>
    689e:	66 90                	xchg   %ax,%ax
    68a0:	66 85 d2             	test   %dx,%dx
    68a3:	0f 84 0e fd ff ff    	je     65b7 <fwp_hof0.constprop.0+0x5c7>
    68a9:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    68ae:	66 0f 28 e5          	movapd %xmm5,%xmm4
    68b2:	e9 49 fd ff ff       	jmp    6600 <fwp_hof0.constprop.0+0x610>
    68b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68be:	00 00 
    68c0:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
    68c5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    68cc:	4c 89 e0             	mov    %r12,%rax
    68cf:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    68d6:	48 c1 e2 10          	shl    $0x10,%rdx
    68da:	48 39 d0             	cmp    %rdx,%rax
    68dd:	73 71                	jae    6950 <fwp_hof0.constprop.0+0x960>
    68df:	48 89 c2             	mov    %rax,%rdx
    68e2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    68e9:	48 c1 ea 10          	shr    $0x10,%rdx
    68ed:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    68f1:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    68f5:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    68f9:	48 85 db             	test   %rbx,%rbx
    68fc:	74 52                	je     6950 <fwp_hof0.constprop.0+0x960>
    68fe:	0f b6 32             	movzbl (%rdx),%esi
    6901:	40 80 fe 02          	cmp    $0x2,%sil
    6905:	0f 84 3d 06 00 00    	je     6f48 <fwp_hof0.constprop.0+0xf58>
    690b:	40 80 fe 01          	cmp    $0x1,%sil
    690f:	75 3f                	jne    6950 <fwp_hof0.constprop.0+0x960>
    6911:	8b 72 18             	mov    0x18(%rdx),%esi
    6914:	0f b7 c0             	movzwl %ax,%eax
    6917:	8b 52 1c             	mov    0x1c(%rdx),%edx
    691a:	48 0f af c6          	imul   %rsi,%rax
    691e:	48 c1 e8 20          	shr    $0x20,%rax
    6922:	48 39 d0             	cmp    %rdx,%rax
    6925:	73 29                	jae    6950 <fwp_hof0.constprop.0+0x960>
    6927:	48 01 c3             	add    %rax,%rbx
    692a:	0f b6 03             	movzbl (%rbx),%eax
    692d:	84 c0                	test   %al,%al
    692f:	74 1f                	je     6950 <fwp_hof0.constprop.0+0x960>
    6931:	3c 01                	cmp    $0x1,%al
    6933:	0f 84 17 01 00 00    	je     6a50 <fwp_hof0.constprop.0+0xa60>
    6939:	3c ff                	cmp    $0xff,%al
    693b:	0f 84 8b 09 00 00    	je     72cc <fwp_hof0.constprop.0+0x12dc>
    6941:	83 e8 01             	sub    $0x1,%eax
    6944:	88 03                	mov    %al,(%rbx)
    6946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    694d:	00 00 00 
    6950:	4d 85 ff             	test   %r15,%r15
    6953:	0f 85 97 01 00 00    	jne    6af0 <fwp_hof0.constprop.0+0xb00>
    6959:	4d 89 ef             	mov    %r13,%r15
    695c:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
    6961:	4c 8d 6c 24 70       	lea    0x70(%rsp),%r13
    6966:	45 31 e4             	xor    %r12d,%r12d
    6969:	66 0f ef c0          	pxor   %xmm0,%xmm0
    696d:	4c 89 ef             	mov    %r13,%rdi
    6970:	be 01 00 00 00       	mov    $0x1,%esi
    6975:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    697c:	00 00 00 00 00 
    6981:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
    6986:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
    698b:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    6992:	ff ff 7f 
    6995:	e8 26 c5 ff ff       	call   2ec0 <buf_grow>
    699a:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    699f:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    69a4:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    69a8:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    69ad:	48 8d 50 01          	lea    0x1(%rax),%rdx
    69b1:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    69b6:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    69bb:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    69c0:	4c 89 f8             	mov    %r15,%rax
    69c3:	4d 8d 7f 08          	lea    0x8(%r15),%r15
    69c7:	4c 23 30             	and    (%rax),%r14
    69ca:	0f 84 15 02 00 00    	je     6be5 <fwp_hof0.constprop.0+0xbf5>
    69d0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    69d5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    69da:	eb 5b                	jmp    6a37 <fwp_hof0.constprop.0+0xa47>
    69dc:	0f 1f 40 00          	nopl   0x0(%rax)
    69e0:	4a 8b 34 e0          	mov    (%rax,%r12,8),%rsi
    69e4:	48 8d 15 d5 61 00 00 	lea    0x61d5(%rip),%rdx        # cbc0 <d0>
    69eb:	4c 89 ef             	mov    %r13,%rdi
    69ee:	49 83 c4 01          	add    $0x1,%r12
    69f2:	e8 f9 e5 ff ff       	call   4ff0 <fwp_write.constprop.0>
    69f7:	4d 39 e6             	cmp    %r12,%r14
    69fa:	0f 84 e0 01 00 00    	je     6be0 <fwp_hof0.constprop.0+0xbf0>
    6a00:	be 02 00 00 00       	mov    $0x2,%esi
    6a05:	4c 89 ef             	mov    %r13,%rdi
    6a08:	e8 b3 c4 ff ff       	call   2ec0 <buf_grow>
    6a0d:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6a12:	ba 2c 20 00 00       	mov    $0x202c,%edx
    6a17:	48 03 44 24 70       	add    0x70(%rsp),%rax
    6a1c:	66 89 10             	mov    %dx,(%rax)
    6a1f:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6a24:	48 8d 50 02          	lea    0x2(%rax),%rdx
    6a28:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6a2d:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6a32:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    6a37:	4c 89 f8             	mov    %r15,%rax
    6a3a:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    6a3e:	79 a0                	jns    69e0 <fwp_hof0.constprop.0+0x9f0>
    6a40:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a44:	eb 9a                	jmp    69e0 <fwp_hof0.constprop.0+0x9f0>
    6a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a4d:	00 00 00 
    6a50:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    6a57:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6a5e:	4c 89 e0             	mov    %r12,%rax
    6a61:	4c 89 e7             	mov    %r12,%rdi
    6a64:	48 29 f0             	sub    %rsi,%rax
    6a67:	48 c1 e2 10          	shl    $0x10,%rdx
    6a6b:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    6a70:	0f 88 ea 04 00 00    	js     6f60 <fwp_hof0.constprop.0+0xf70>
    6a76:	48 39 d0             	cmp    %rdx,%rax
    6a79:	0f 83 d1 fe ff ff    	jae    6950 <fwp_hof0.constprop.0+0x960>
    6a7f:	48 89 c2             	mov    %rax,%rdx
    6a82:	48 c1 ea 10          	shr    $0x10,%rdx
    6a86:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6a8a:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6a8e:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6a92:	48 85 c9             	test   %rcx,%rcx
    6a95:	0f 84 b5 fe ff ff    	je     6950 <fwp_hof0.constprop.0+0x960>
    6a9b:	0f b6 32             	movzbl (%rdx),%esi
    6a9e:	40 80 fe 02          	cmp    $0x2,%sil
    6aa2:	0f 84 70 05 00 00    	je     7018 <fwp_hof0.constprop.0+0x1028>
    6aa8:	40 80 fe 01          	cmp    $0x1,%sil
    6aac:	0f 85 9e fe ff ff    	jne    6950 <fwp_hof0.constprop.0+0x960>
    6ab2:	8b 72 18             	mov    0x18(%rdx),%esi
    6ab5:	0f b7 c0             	movzwl %ax,%eax
    6ab8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6abb:	48 0f af c6          	imul   %rsi,%rax
    6abf:	48 c1 e8 20          	shr    $0x20,%rax
    6ac3:	48 39 d0             	cmp    %rdx,%rax
    6ac6:	0f 83 84 fe ff ff    	jae    6950 <fwp_hof0.constprop.0+0x960>
    6acc:	48 01 c1             	add    %rax,%rcx
    6acf:	80 39 01             	cmpb   $0x1,(%rcx)
    6ad2:	0f 85 78 fe ff ff    	jne    6950 <fwp_hof0.constprop.0+0x960>
    6ad8:	4c 89 e7             	mov    %r12,%rdi
    6adb:	e8 f0 d4 ff ff       	call   3fd0 <fwp_mem_free>
    6ae0:	4d 85 ff             	test   %r15,%r15
    6ae3:	0f 84 70 fe ff ff    	je     6959 <fwp_hof0.constprop.0+0x969>
    6ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6af0:	4c 89 fa             	mov    %r15,%rdx
    6af3:	31 c0                	xor    %eax,%eax
    6af5:	4d 89 ec             	mov    %r13,%r12
    6af8:	48 83 ea 01          	sub    $0x1,%rdx
    6afc:	0f 90 c0             	seto   %al
    6aff:	49 89 d7             	mov    %rdx,%r15
    6b02:	e9 32 f7 ff ff       	jmp    6239 <fwp_hof0.constprop.0+0x249>
    6b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b0e:	00 00 
    6b10:	49 83 3e 00          	cmpq   $0x0,(%r14)
    6b14:	0f 88 42 0a 00 00    	js     755c <fwp_hof0.constprop.0+0x156c>
    6b1a:	4b 89 0c ee          	mov    %rcx,(%r14,%r13,8)
    6b1e:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6b25:	48 2b 95 b0 13 00 00 	sub    0x13b0(%rbp),%rdx
    6b2c:	48 c1 e0 10          	shl    $0x10,%rax
    6b30:	48 39 c2             	cmp    %rax,%rdx
    6b33:	73 58                	jae    6b8d <fwp_hof0.constprop.0+0xb9d>
    6b35:	48 89 d0             	mov    %rdx,%rax
    6b38:	48 c1 e8 10          	shr    $0x10,%rax
    6b3c:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    6b40:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    6b47:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    6b4b:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6b4f:	48 85 c9             	test   %rcx,%rcx
    6b52:	74 39                	je     6b8d <fwp_hof0.constprop.0+0xb9d>
    6b54:	0f b6 30             	movzbl (%rax),%esi
    6b57:	40 80 fe 02          	cmp    $0x2,%sil
    6b5b:	0f 84 ff 05 00 00    	je     7160 <fwp_hof0.constprop.0+0x1170>
    6b61:	40 80 fe 01          	cmp    $0x1,%sil
    6b65:	75 26                	jne    6b8d <fwp_hof0.constprop.0+0xb9d>
    6b67:	8b 70 18             	mov    0x18(%rax),%esi
    6b6a:	0f b7 d2             	movzwl %dx,%edx
    6b6d:	8b 40 1c             	mov    0x1c(%rax),%eax
    6b70:	48 0f af d6          	imul   %rsi,%rdx
    6b74:	48 c1 ea 20          	shr    $0x20,%rdx
    6b78:	48 39 c2             	cmp    %rax,%rdx
    6b7b:	73 10                	jae    6b8d <fwp_hof0.constprop.0+0xb9d>
    6b7d:	48 01 d1             	add    %rdx,%rcx
    6b80:	80 39 01             	cmpb   $0x1,(%rcx)
    6b83:	75 08                	jne    6b8d <fwp_hof0.constprop.0+0xb9d>
    6b85:	4c 89 cf             	mov    %r9,%rdi
    6b88:	e8 43 d4 ff ff       	call   3fd0 <fwp_mem_free>
    6b8d:	4d 85 e4             	test   %r12,%r12
    6b90:	0f 84 ea 05 00 00    	je     7180 <fwp_hof0.constprop.0+0x1190>
    6b96:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    6b9b:	4d 89 e1             	mov    %r12,%r9
    6b9e:	4c 89 e2             	mov    %r12,%rdx
    6ba1:	4d 89 e0             	mov    %r12,%r8
    6ba4:	49 83 c5 01          	add    $0x1,%r13
    6ba8:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    6bad:	e9 c6 f5 ff ff       	jmp    6178 <fwp_hof0.constprop.0+0x188>
    6bb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bb8:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    6bbd:	e9 5c f7 ff ff       	jmp    631e <fwp_hof0.constprop.0+0x32e>
    6bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bc8:	66 85 c0             	test   %ax,%ax
    6bcb:	0f 85 3d f6 ff ff    	jne    620e <fwp_hof0.constprop.0+0x21e>
    6bd1:	e9 09 f6 ff ff       	jmp    61df <fwp_hof0.constprop.0+0x1ef>
    6bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bdd:	00 00 00 
    6be0:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    6be5:	be 01 00 00 00       	mov    $0x1,%esi
    6bea:	4c 89 ef             	mov    %r13,%rdi
    6bed:	e8 ce c2 ff ff       	call   2ec0 <buf_grow>
    6bf2:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6bf7:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6bfc:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    6c00:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6c05:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6c09:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6c0e:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6c13:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6c18:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    6c1d:	48 8d 05 0a 44 00 00 	lea    0x440a(%rip),%rax        # b02e <_IO_stdin_used+0x2e>
    6c24:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    6c29:	48 85 c9             	test   %rcx,%rcx
    6c2c:	48 0f 44 c8          	cmove  %rax,%rcx
    6c30:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    6c34:	0f 87 72 09 00 00    	ja     75ac <fwp_hof0.constprop.0+0x15bc>
    6c3a:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    6c3e:	be 01 00 00 00       	mov    $0x1,%esi
    6c43:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6c48:	e8 b3 d9 ff ff       	call   4600 <fwp_heap_alloc>
    6c4d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6c52:	4c 89 f2             	mov    %r14,%rdx
    6c55:	4c 89 30             	mov    %r14,(%rax)
    6c58:	4c 8d 60 08          	lea    0x8(%rax),%r12
    6c5c:	49 89 c5             	mov    %rax,%r13
    6c5f:	4c 89 e7             	mov    %r12,%rdi
    6c62:	e8 09 b9 ff ff       	call   2570 <memcpy@plt>
    6c67:	43 c6 44 35 08 00    	movb   $0x0,0x8(%r13,%r14,1)
    6c6d:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
    6c72:	e8 29 b7 ff ff       	call   23a0 <free@plt>
    6c77:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    6c7e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6c85:	4c 89 e8             	mov    %r13,%rax
    6c88:	48 29 c8             	sub    %rcx,%rax
    6c8b:	48 c1 e2 10          	shl    $0x10,%rdx
    6c8f:	48 39 d0             	cmp    %rdx,%rax
    6c92:	73 6b                	jae    6cff <fwp_hof0.constprop.0+0xd0f>
    6c94:	48 89 c6             	mov    %rax,%rsi
    6c97:	48 c1 ee 10          	shr    $0x10,%rsi
    6c9b:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6c9f:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    6ca6:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6caa:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    6cae:	4d 85 f6             	test   %r14,%r14
    6cb1:	74 4c                	je     6cff <fwp_hof0.constprop.0+0xd0f>
    6cb3:	0f b6 3e             	movzbl (%rsi),%edi
    6cb6:	40 80 ff 02          	cmp    $0x2,%dil
    6cba:	0f 84 a0 05 00 00    	je     7260 <fwp_hof0.constprop.0+0x1270>
    6cc0:	40 80 ff 01          	cmp    $0x1,%dil
    6cc4:	75 39                	jne    6cff <fwp_hof0.constprop.0+0xd0f>
    6cc6:	8b 7e 18             	mov    0x18(%rsi),%edi
    6cc9:	0f b7 c0             	movzwl %ax,%eax
    6ccc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ccf:	48 0f af c7          	imul   %rdi,%rax
    6cd3:	48 c1 e8 20          	shr    $0x20,%rax
    6cd7:	48 39 f0             	cmp    %rsi,%rax
    6cda:	73 23                	jae    6cff <fwp_hof0.constprop.0+0xd0f>
    6cdc:	49 01 c6             	add    %rax,%r14
    6cdf:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6ce3:	0f 84 8a 05 00 00    	je     7273 <fwp_hof0.constprop.0+0x1283>
    6ce9:	41 c6 06 01          	movb   $0x1,(%r14)
    6ced:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6cf4:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    6cfb:	48 c1 e2 10          	shl    $0x10,%rdx
    6cff:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6d04:	48 89 f8             	mov    %rdi,%rax
    6d07:	48 29 c8             	sub    %rcx,%rax
    6d0a:	48 39 d0             	cmp    %rdx,%rax
    6d0d:	73 71                	jae    6d80 <fwp_hof0.constprop.0+0xd90>
    6d0f:	48 89 c2             	mov    %rax,%rdx
    6d12:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    6d19:	48 c1 ea 10          	shr    $0x10,%rdx
    6d1d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6d21:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6d25:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6d29:	4d 85 f6             	test   %r14,%r14
    6d2c:	74 52                	je     6d80 <fwp_hof0.constprop.0+0xd90>
    6d2e:	0f b6 32             	movzbl (%rdx),%esi
    6d31:	40 80 fe 02          	cmp    $0x2,%sil
    6d35:	0f 84 55 04 00 00    	je     7190 <fwp_hof0.constprop.0+0x11a0>
    6d3b:	40 80 fe 01          	cmp    $0x1,%sil
    6d3f:	75 3f                	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    6d41:	8b 72 18             	mov    0x18(%rdx),%esi
    6d44:	0f b7 c0             	movzwl %ax,%eax
    6d47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d4a:	48 0f af c6          	imul   %rsi,%rax
    6d4e:	48 c1 e8 20          	shr    $0x20,%rax
    6d52:	48 39 d0             	cmp    %rdx,%rax
    6d55:	73 29                	jae    6d80 <fwp_hof0.constprop.0+0xd90>
    6d57:	49 01 c6             	add    %rax,%r14
    6d5a:	41 0f b6 06          	movzbl (%r14),%eax
    6d5e:	84 c0                	test   %al,%al
    6d60:	74 1e                	je     6d80 <fwp_hof0.constprop.0+0xd90>
    6d62:	3c 01                	cmp    $0x1,%al
    6d64:	0f 84 0e 01 00 00    	je     6e78 <fwp_hof0.constprop.0+0xe88>
    6d6a:	3c ff                	cmp    $0xff,%al
    6d6c:	0f 84 33 06 00 00    	je     73a5 <fwp_hof0.constprop.0+0x13b5>
    6d72:	83 e8 01             	sub    $0x1,%eax
    6d75:	41 88 06             	mov    %al,(%r14)
    6d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d7f:	00 
    6d80:	49 8b 55 00          	mov    0x0(%r13),%rdx
    6d84:	48 8b 0d 0d 86 01 00 	mov    0x1860d(%rip),%rcx        # 1f398 <fwp_prog_out>
    6d8b:	be 01 00 00 00       	mov    $0x1,%esi
    6d90:	4c 89 e7             	mov    %r12,%rdi
    6d93:	e8 a8 b8 ff ff       	call   2640 <fwrite@plt>
    6d98:	48 8b 35 f9 85 01 00 	mov    0x185f9(%rip),%rsi        # 1f398 <fwp_prog_out>
    6d9f:	bf 0a 00 00 00       	mov    $0xa,%edi
    6da4:	e8 17 b7 ff ff       	call   24c0 <fputc@plt>
    6da9:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6db0:	4c 89 e8             	mov    %r13,%rax
    6db3:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6dba:	48 c1 e2 10          	shl    $0x10,%rdx
    6dbe:	48 39 d0             	cmp    %rdx,%rax
    6dc1:	73 6d                	jae    6e30 <fwp_hof0.constprop.0+0xe40>
    6dc3:	48 89 c2             	mov    %rax,%rdx
    6dc6:	48 c1 ea 10          	shr    $0x10,%rdx
    6dca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dce:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    6dd5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6dd9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    6ddd:	4d 85 e4             	test   %r12,%r12
    6de0:	74 4e                	je     6e30 <fwp_hof0.constprop.0+0xe40>
    6de2:	0f b6 0a             	movzbl (%rdx),%ecx
    6de5:	80 f9 02             	cmp    $0x2,%cl
    6de8:	0f 84 92 04 00 00    	je     7280 <fwp_hof0.constprop.0+0x1290>
    6dee:	80 f9 01             	cmp    $0x1,%cl
    6df1:	75 3d                	jne    6e30 <fwp_hof0.constprop.0+0xe40>
    6df3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6df6:	0f b7 c0             	movzwl %ax,%eax
    6df9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6dfc:	48 0f af c1          	imul   %rcx,%rax
    6e00:	48 c1 e8 20          	shr    $0x20,%rax
    6e04:	48 39 d0             	cmp    %rdx,%rax
    6e07:	73 27                	jae    6e30 <fwp_hof0.constprop.0+0xe40>
    6e09:	49 01 c4             	add    %rax,%r12
    6e0c:	41 0f b6 04 24       	movzbl (%r12),%eax
    6e11:	84 c0                	test   %al,%al
    6e13:	74 1b                	je     6e30 <fwp_hof0.constprop.0+0xe40>
    6e15:	3c 01                	cmp    $0x1,%al
    6e17:	0f 84 81 04 00 00    	je     729e <fwp_hof0.constprop.0+0x12ae>
    6e1d:	3c ff                	cmp    $0xff,%al
    6e1f:	0f 84 fa 05 00 00    	je     741f <fwp_hof0.constprop.0+0x142f>
    6e25:	83 e8 01             	sub    $0x1,%eax
    6e28:	41 88 04 24          	mov    %al,(%r12)
    6e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e30:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6e35:	48 8b 40 10          	mov    0x10(%rax),%rax
    6e39:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    6e3e:	48 85 c0             	test   %rax,%rax
    6e41:	0f 85 e9 f1 ff ff    	jne    6030 <fwp_hof0.constprop.0+0x40>
    6e47:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
    6e4e:	00 
    6e4f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e56:	00 00 
    6e58:	0f 85 6b 07 00 00    	jne    75c9 <fwp_hof0.constprop.0+0x15d9>
    6e5e:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    6e65:	31 c0                	xor    %eax,%eax
    6e67:	5b                   	pop    %rbx
    6e68:	5d                   	pop    %rbp
    6e69:	41 5c                	pop    %r12
    6e6b:	41 5d                	pop    %r13
    6e6d:	41 5e                	pop    %r14
    6e6f:	41 5f                	pop    %r15
    6e71:	c3                   	ret
    6e72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e78:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    6e7c:	0f 88 1e 03 00 00    	js     71a0 <fwp_hof0.constprop.0+0x11b0>
    6e82:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6e89:	48 89 f8             	mov    %rdi,%rax
    6e8c:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    6e91:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6e98:	48 c1 e2 10          	shl    $0x10,%rdx
    6e9c:	48 39 d0             	cmp    %rdx,%rax
    6e9f:	0f 83 db fe ff ff    	jae    6d80 <fwp_hof0.constprop.0+0xd90>
    6ea5:	48 89 c2             	mov    %rax,%rdx
    6ea8:	48 c1 ea 10          	shr    $0x10,%rdx
    6eac:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6eb0:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6eb4:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6eb8:	48 85 c9             	test   %rcx,%rcx
    6ebb:	0f 84 bf fe ff ff    	je     6d80 <fwp_hof0.constprop.0+0xd90>
    6ec1:	0f b6 32             	movzbl (%rdx),%esi
    6ec4:	40 80 fe 02          	cmp    $0x2,%sil
    6ec8:	0f 84 e2 03 00 00    	je     72b0 <fwp_hof0.constprop.0+0x12c0>
    6ece:	40 80 fe 01          	cmp    $0x1,%sil
    6ed2:	0f 85 a8 fe ff ff    	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    6ed8:	8b 72 18             	mov    0x18(%rdx),%esi
    6edb:	0f b7 c0             	movzwl %ax,%eax
    6ede:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ee1:	48 0f af c6          	imul   %rsi,%rax
    6ee5:	48 c1 e8 20          	shr    $0x20,%rax
    6ee9:	48 39 d0             	cmp    %rdx,%rax
    6eec:	0f 83 8e fe ff ff    	jae    6d80 <fwp_hof0.constprop.0+0xd90>
    6ef2:	48 01 c1             	add    %rax,%rcx
    6ef5:	80 39 01             	cmpb   $0x1,(%rcx)
    6ef8:	0f 85 82 fe ff ff    	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    6efe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f03:	e8 c8 d0 ff ff       	call   3fd0 <fwp_mem_free>
    6f08:	e9 73 fe ff ff       	jmp    6d80 <fwp_hof0.constprop.0+0xd90>
    6f0d:	0f 1f 00             	nopl   (%rax)
    6f10:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
    6f15:	e9 5d f5 ff ff       	jmp    6477 <fwp_hof0.constprop.0+0x487>
    6f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f20:	4c 89 cf             	mov    %r9,%rdi
    6f23:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
    6f28:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6f2d:	e8 5e ce ff ff       	call   3d90 <fwp_rc_forget_slot>
    6f32:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
    6f37:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6f3c:	e9 e3 f5 ff ff       	jmp    6524 <fwp_hof0.constprop.0+0x534>
    6f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f48:	66 85 c0             	test   %ax,%ax
    6f4b:	0f 85 ff f9 ff ff    	jne    6950 <fwp_hof0.constprop.0+0x960>
    6f51:	e9 d4 f9 ff ff       	jmp    692a <fwp_hof0.constprop.0+0x93a>
    6f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f5d:	00 00 00 
    6f60:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    6f65:	48 39 d0             	cmp    %rdx,%rax
    6f68:	73 63                	jae    6fcd <fwp_hof0.constprop.0+0xfdd>
    6f6a:	49 89 c0             	mov    %rax,%r8
    6f6d:	49 c1 e8 10          	shr    $0x10,%r8
    6f71:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    6f75:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
    6f79:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    6f7d:	4d 85 c0             	test   %r8,%r8
    6f80:	74 4b                	je     6fcd <fwp_hof0.constprop.0+0xfdd>
    6f82:	44 0f b6 09          	movzbl (%rcx),%r9d
    6f86:	41 80 f9 02          	cmp    $0x2,%r9b
    6f8a:	0f 84 2e 03 00 00    	je     72be <fwp_hof0.constprop.0+0x12ce>
    6f90:	41 80 f9 01          	cmp    $0x1,%r9b
    6f94:	75 37                	jne    6fcd <fwp_hof0.constprop.0+0xfdd>
    6f96:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    6f9a:	0f b7 c0             	movzwl %ax,%eax
    6f9d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fa0:	49 0f af c1          	imul   %r9,%rax
    6fa4:	48 c1 e8 20          	shr    $0x20,%rax
    6fa8:	48 39 c8             	cmp    %rcx,%rax
    6fab:	73 20                	jae    6fcd <fwp_hof0.constprop.0+0xfdd>
    6fad:	49 01 c0             	add    %rax,%r8
    6fb0:	41 80 38 01          	cmpb   $0x1,(%r8)
    6fb4:	75 17                	jne    6fcd <fwp_hof0.constprop.0+0xfdd>
    6fb6:	e8 15 d0 ff ff       	call   3fd0 <fwp_mem_free>
    6fbb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6fc2:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    6fc9:	48 c1 e2 10          	shl    $0x10,%rdx
    6fcd:	4c 89 e0             	mov    %r12,%rax
    6fd0:	48 29 f0             	sub    %rsi,%rax
    6fd3:	48 39 d0             	cmp    %rdx,%rax
    6fd6:	0f 82 03 f9 ff ff    	jb     68df <fwp_hof0.constprop.0+0x8ef>
    6fdc:	e9 6f f9 ff ff       	jmp    6950 <fwp_hof0.constprop.0+0x960>
    6fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fe8:	66 85 c0             	test   %ax,%ax
    6feb:	0f 85 f6 f2 ff ff    	jne    62e7 <fwp_hof0.constprop.0+0x2f7>
    6ff1:	80 3b ff             	cmpb   $0xff,(%rbx)
    6ff4:	0f 85 ea f2 ff ff    	jne    62e4 <fwp_hof0.constprop.0+0x2f4>
    6ffa:	48 89 df             	mov    %rbx,%rdi
    6ffd:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7002:	e8 89 cd ff ff       	call   3d90 <fwp_rc_forget_slot>
    7007:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    700c:	e9 d3 f2 ff ff       	jmp    62e4 <fwp_hof0.constprop.0+0x2f4>
    7011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7018:	66 85 c0             	test   %ax,%ax
    701b:	0f 85 2f f9 ff ff    	jne    6950 <fwp_hof0.constprop.0+0x960>
    7021:	e9 a9 fa ff ff       	jmp    6acf <fwp_hof0.constprop.0+0xadf>
    7026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    702d:	00 00 00 
    7030:	48 89 c2             	mov    %rax,%rdx
    7033:	48 c1 ea 11          	shr    $0x11,%rdx
    7037:	48 31 c2             	xor    %rax,%rdx
    703a:	48 89 d6             	mov    %rdx,%rsi
    703d:	48 c1 ee 09          	shr    $0x9,%rsi
    7041:	48 31 f2             	xor    %rsi,%rdx
    7044:	0f b6 f2             	movzbl %dl,%esi
    7047:	48 8b 94 f5 48 14 00 	mov    0x1448(%rbp,%rsi,8),%rdx
    704e:	00 
    704f:	48 85 d2             	test   %rdx,%rdx
    7052:	75 19                	jne    706d <fwp_hof0.constprop.0+0x107d>
    7054:	e9 47 05 00 00       	jmp    75a0 <fwp_hof0.constprop.0+0x15b0>
    7059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7060:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7064:	48 85 d2             	test   %rdx,%rdx
    7067:	0f 84 33 05 00 00    	je     75a0 <fwp_hof0.constprop.0+0x15b0>
    706d:	48 89 d6             	mov    %rdx,%rsi
    7070:	48 3b 02             	cmp    (%rdx),%rax
    7073:	75 eb                	jne    7060 <fwp_hof0.constprop.0+0x1070>
    7075:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7079:	48 8d 77 ff          	lea    -0x1(%rdi),%rsi
    707d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7081:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7088:	0f 85 f2 f5 ff ff    	jne    6680 <fwp_hof0.constprop.0+0x690>
    708e:	48 89 c7             	mov    %rax,%rdi
    7091:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    7096:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    709b:	66 0f d6 4c 24 68    	movq   %xmm1,0x68(%rsp)
    70a1:	66 0f d6 44 24 48    	movq   %xmm0,0x48(%rsp)
    70a7:	f2 0f 11 6c 24 40    	movsd  %xmm5,0x40(%rsp)
    70ad:	f2 0f 11 64 24 30    	movsd  %xmm4,0x30(%rsp)
    70b3:	66 0f d6 5c 24 28    	movq   %xmm3,0x28(%rsp)
    70b9:	e8 d2 cc ff ff       	call   3d90 <fwp_rc_forget_slot>
    70be:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    70c3:	f2 0f 10 64 24 30    	movsd  0x30(%rsp),%xmm4
    70c9:	f3 0f 7e 5c 24 28    	movq   0x28(%rsp),%xmm3
    70cf:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    70d4:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
    70da:	c6 00 fe             	movb   $0xfe,(%rax)
    70dd:	f3 0f 7e 44 24 48    	movq   0x48(%rsp),%xmm0
    70e3:	f3 0f 7e 4c 24 68    	movq   0x68(%rsp),%xmm1
    70e9:	e9 92 f5 ff ff       	jmp    6680 <fwp_hof0.constprop.0+0x690>
    70ee:	66 90                	xchg   %ax,%ax
    70f0:	4c 89 ca             	mov    %r9,%rdx
    70f3:	48 c1 ea 11          	shr    $0x11,%rdx
    70f7:	4c 31 ca             	xor    %r9,%rdx
    70fa:	48 89 d6             	mov    %rdx,%rsi
    70fd:	48 c1 ee 09          	shr    $0x9,%rsi
    7101:	48 31 d6             	xor    %rdx,%rsi
    7104:	40 0f b6 f6          	movzbl %sil,%esi
    7108:	48 8b 94 f5 48 14 00 	mov    0x1448(%rbp,%rsi,8),%rdx
    710f:	00 
    7110:	48 85 d2             	test   %rdx,%rdx
    7113:	75 18                	jne    712d <fwp_hof0.constprop.0+0x113d>
    7115:	e9 86 04 00 00       	jmp    75a0 <fwp_hof0.constprop.0+0x15b0>
    711a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7120:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7124:	48 85 d2             	test   %rdx,%rdx
    7127:	0f 84 73 04 00 00    	je     75a0 <fwp_hof0.constprop.0+0x15b0>
    712d:	48 89 d6             	mov    %rdx,%rsi
    7130:	4c 3b 0a             	cmp    (%rdx),%r9
    7133:	75 eb                	jne    7120 <fwp_hof0.constprop.0+0x1130>
    7135:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    7139:	48 83 ee 01          	sub    $0x1,%rsi
    713d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7141:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7148:	0f 84 f0 01 00 00    	je     733e <fwp_hof0.constprop.0+0x134e>
    714e:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    7154:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    715a:	e9 a1 f4 ff ff       	jmp    6600 <fwp_hof0.constprop.0+0x610>
    715f:	90                   	nop
    7160:	66 85 d2             	test   %dx,%dx
    7163:	0f 84 17 fa ff ff    	je     6b80 <fwp_hof0.constprop.0+0xb90>
    7169:	4d 85 e4             	test   %r12,%r12
    716c:	0f 85 24 fa ff ff    	jne    6b96 <fwp_hof0.constprop.0+0xba6>
    7172:	0f 1f 00             	nopl   (%rax)
    7175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    717c:	00 00 00 00 
    7180:	45 31 c0             	xor    %r8d,%r8d
    7183:	e9 99 f0 ff ff       	jmp    6221 <fwp_hof0.constprop.0+0x231>
    7188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    718f:	00 
    7190:	66 85 c0             	test   %ax,%ax
    7193:	0f 85 e7 fb ff ff    	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    7199:	e9 bc fb ff ff       	jmp    6d5a <fwp_hof0.constprop.0+0xd6a>
    719e:	66 90                	xchg   %ax,%ax
    71a0:	4c 8b 77 08          	mov    0x8(%rdi),%r14
    71a4:	e8 d7 d3 ff ff       	call   4580 <fwp_rc_free_arr>
    71a9:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    71b0:	4c 89 f0             	mov    %r14,%rax
    71b3:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    71ba:	48 c1 e2 10          	shl    $0x10,%rdx
    71be:	48 39 d0             	cmp    %rdx,%rax
    71c1:	0f 83 b9 fb ff ff    	jae    6d80 <fwp_hof0.constprop.0+0xd90>
    71c7:	4c 89 f7             	mov    %r14,%rdi
    71ca:	e9 40 fb ff ff       	jmp    6d0f <fwp_hof0.constprop.0+0xd1f>
    71cf:	90                   	nop
    71d0:	66 85 c0             	test   %ax,%ax
    71d3:	0f 85 7f ef ff ff    	jne    6158 <fwp_hof0.constprop.0+0x168>
    71d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    71de:	0f 85 6f ef ff ff    	jne    6153 <fwp_hof0.constprop.0+0x163>
    71e4:	4c 89 e7             	mov    %r12,%rdi
    71e7:	e8 a4 cb ff ff       	call   3d90 <fwp_rc_forget_slot>
    71ec:	e9 62 ef ff ff       	jmp    6153 <fwp_hof0.constprop.0+0x163>
    71f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71f8:	66 85 c0             	test   %ax,%ax
    71fb:	0f 84 92 ee ff ff    	je     6093 <fwp_hof0.constprop.0+0xa3>
    7201:	48 85 db             	test   %rbx,%rbx
    7204:	0f 85 aa ee ff ff    	jne    60b4 <fwp_hof0.constprop.0+0xc4>
    720a:	31 ff                	xor    %edi,%edi
    720c:	e8 3f d6 ff ff       	call   4850 <fwp_array_new_packed.constprop.0>
    7211:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    7218:	49 89 c6             	mov    %rax,%r14
    721b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    7222:	48 c1 e2 10          	shl    $0x10,%rdx
    7226:	48 39 d0             	cmp    %rdx,%rax
    7229:	0f 83 51 ff ff ff    	jae    7180 <fwp_hof0.constprop.0+0x1190>
    722f:	48 89 c2             	mov    %rax,%rdx
    7232:	48 c1 ea 10          	shr    $0x10,%rdx
    7236:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    723a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    7241:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7245:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7249:	4d 85 e4             	test   %r12,%r12
    724c:	0f 85 cc ee ff ff    	jne    611e <fwp_hof0.constprop.0+0x12e>
    7252:	e9 29 ff ff ff       	jmp    7180 <fwp_hof0.constprop.0+0x1190>
    7257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    725e:	00 00 
    7260:	66 85 c0             	test   %ax,%ax
    7263:	0f 85 96 fa ff ff    	jne    6cff <fwp_hof0.constprop.0+0xd0f>
    7269:	41 80 3e ff          	cmpb   $0xff,(%r14)
    726d:	0f 85 76 fa ff ff    	jne    6ce9 <fwp_hof0.constprop.0+0xcf9>
    7273:	4c 89 f7             	mov    %r14,%rdi
    7276:	e8 15 cb ff ff       	call   3d90 <fwp_rc_forget_slot>
    727b:	e9 69 fa ff ff       	jmp    6ce9 <fwp_hof0.constprop.0+0xcf9>
    7280:	66 85 c0             	test   %ax,%ax
    7283:	0f 85 a7 fb ff ff    	jne    6e30 <fwp_hof0.constprop.0+0xe40>
    7289:	41 0f b6 04 24       	movzbl (%r12),%eax
    728e:	84 c0                	test   %al,%al
    7290:	0f 84 9a fb ff ff    	je     6e30 <fwp_hof0.constprop.0+0xe40>
    7296:	3c 01                	cmp    $0x1,%al
    7298:	0f 85 7f fb ff ff    	jne    6e1d <fwp_hof0.constprop.0+0xe2d>
    729e:	4c 89 ef             	mov    %r13,%rdi
    72a1:	e8 2a cd ff ff       	call   3fd0 <fwp_mem_free>
    72a6:	e9 85 fb ff ff       	jmp    6e30 <fwp_hof0.constprop.0+0xe40>
    72ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72b0:	66 85 c0             	test   %ax,%ax
    72b3:	0f 85 c7 fa ff ff    	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    72b9:	e9 37 fc ff ff       	jmp    6ef5 <fwp_hof0.constprop.0+0xf05>
    72be:	66 85 c0             	test   %ax,%ax
    72c1:	0f 85 06 fd ff ff    	jne    6fcd <fwp_hof0.constprop.0+0xfdd>
    72c7:	e9 e4 fc ff ff       	jmp    6fb0 <fwp_hof0.constprop.0+0xfc0>
    72cc:	48 89 d8             	mov    %rbx,%rax
    72cf:	48 c1 e8 11          	shr    $0x11,%rax
    72d3:	48 31 d8             	xor    %rbx,%rax
    72d6:	48 89 c2             	mov    %rax,%rdx
    72d9:	48 c1 ea 09          	shr    $0x9,%rdx
    72dd:	48 31 d0             	xor    %rdx,%rax
    72e0:	0f b6 d0             	movzbl %al,%edx
    72e3:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    72ea:	00 
    72eb:	48 85 c0             	test   %rax,%rax
    72ee:	75 1d                	jne    730d <fwp_hof0.constprop.0+0x131d>
    72f0:	e9 ab 02 00 00       	jmp    75a0 <fwp_hof0.constprop.0+0x15b0>
    72f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72fc:	00 00 00 00 
    7300:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7304:	48 85 c0             	test   %rax,%rax
    7307:	0f 84 93 02 00 00    	je     75a0 <fwp_hof0.constprop.0+0x15b0>
    730d:	48 89 c2             	mov    %rax,%rdx
    7310:	48 3b 18             	cmp    (%rax),%rbx
    7313:	75 eb                	jne    7300 <fwp_hof0.constprop.0+0x1310>
    7315:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7319:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    731d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7321:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7328:	0f 85 22 f6 ff ff    	jne    6950 <fwp_hof0.constprop.0+0x960>
    732e:	48 89 df             	mov    %rbx,%rdi
    7331:	e8 5a ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    7336:	c6 03 fe             	movb   $0xfe,(%rbx)
    7339:	e9 12 f6 ff ff       	jmp    6950 <fwp_hof0.constprop.0+0x960>
    733e:	4c 89 cf             	mov    %r9,%rdi
    7341:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    7346:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    734b:	66 0f d6 4c 24 40    	movq   %xmm1,0x40(%rsp)
    7351:	66 0f d6 44 24 38    	movq   %xmm0,0x38(%rsp)
    7357:	f2 0f 11 6c 24 30    	movsd  %xmm5,0x30(%rsp)
    735d:	e8 2e ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    7362:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    7367:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    736c:	f2 0f 10 6c 24 30    	movsd  0x30(%rsp),%xmm5
    7372:	f3 0f 7e 44 24 38    	movq   0x38(%rsp),%xmm0
    7378:	41 c6 01 fe          	movb   $0xfe,(%r9)
    737c:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    7383:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    7389:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    738f:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    7396:	f3 0f 7e 4c 24 40    	movq   0x40(%rsp),%xmm1
    739c:	48 c1 e0 10          	shl    $0x10,%rax
    73a0:	e9 5b f2 ff ff       	jmp    6600 <fwp_hof0.constprop.0+0x610>
    73a5:	4c 89 f2             	mov    %r14,%rdx
    73a8:	48 c1 ea 11          	shr    $0x11,%rdx
    73ac:	4c 31 f2             	xor    %r14,%rdx
    73af:	48 89 d0             	mov    %rdx,%rax
    73b2:	48 c1 e8 09          	shr    $0x9,%rax
    73b6:	48 31 c2             	xor    %rax,%rdx
    73b9:	0f b6 d2             	movzbl %dl,%edx
    73bc:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    73c3:	00 
    73c4:	48 85 c0             	test   %rax,%rax
    73c7:	75 24                	jne    73ed <fwp_hof0.constprop.0+0x13fd>
    73c9:	e9 d2 01 00 00       	jmp    75a0 <fwp_hof0.constprop.0+0x15b0>
    73ce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73dc:	00 00 00 00 
    73e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    73e4:	48 85 c0             	test   %rax,%rax
    73e7:	0f 84 b3 01 00 00    	je     75a0 <fwp_hof0.constprop.0+0x15b0>
    73ed:	48 89 c2             	mov    %rax,%rdx
    73f0:	4c 3b 30             	cmp    (%rax),%r14
    73f3:	75 eb                	jne    73e0 <fwp_hof0.constprop.0+0x13f0>
    73f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    73f9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    73fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7401:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7408:	0f 85 72 f9 ff ff    	jne    6d80 <fwp_hof0.constprop.0+0xd90>
    740e:	4c 89 f7             	mov    %r14,%rdi
    7411:	e8 7a c9 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7416:	41 c6 06 fe          	movb   $0xfe,(%r14)
    741a:	e9 61 f9 ff ff       	jmp    6d80 <fwp_hof0.constprop.0+0xd90>
    741f:	4c 89 e0             	mov    %r12,%rax
    7422:	48 c1 e8 11          	shr    $0x11,%rax
    7426:	4c 31 e0             	xor    %r12,%rax
    7429:	48 89 c2             	mov    %rax,%rdx
    742c:	48 c1 ea 09          	shr    $0x9,%rdx
    7430:	48 31 d0             	xor    %rdx,%rax
    7433:	0f b6 d0             	movzbl %al,%edx
    7436:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    743d:	00 
    743e:	48 85 c0             	test   %rax,%rax
    7441:	75 2a                	jne    746d <fwp_hof0.constprop.0+0x147d>
    7443:	e9 58 01 00 00       	jmp    75a0 <fwp_hof0.constprop.0+0x15b0>
    7448:	66 90                	xchg   %ax,%ax
    744a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7451:	00 00 00 00 
    7455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    745c:	00 00 00 00 
    7460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7464:	48 85 c0             	test   %rax,%rax
    7467:	0f 84 33 01 00 00    	je     75a0 <fwp_hof0.constprop.0+0x15b0>
    746d:	48 89 c2             	mov    %rax,%rdx
    7470:	4c 3b 20             	cmp    (%rax),%r12
    7473:	75 eb                	jne    7460 <fwp_hof0.constprop.0+0x1470>
    7475:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7479:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    747d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7481:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7488:	0f 85 a2 f9 ff ff    	jne    6e30 <fwp_hof0.constprop.0+0xe40>
    748e:	4c 89 e7             	mov    %r12,%rdi
    7491:	e8 fa c8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7496:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    749b:	e9 90 f9 ff ff       	jmp    6e30 <fwp_hof0.constprop.0+0xe40>
    74a0:	4c 89 e1             	mov    %r12,%rcx
    74a3:	48 c1 e9 11          	shr    $0x11,%rcx
    74a7:	4c 31 e1             	xor    %r12,%rcx
    74aa:	48 89 ca             	mov    %rcx,%rdx
    74ad:	48 c1 ea 09          	shr    $0x9,%rdx
    74b1:	48 31 d1             	xor    %rdx,%rcx
    74b4:	0f b6 c9             	movzbl %cl,%ecx
    74b7:	4c 8d ac cd 48 14 00 	lea    0x1448(%rbp,%rcx,8),%r13
    74be:	00 
    74bf:	49 8b 55 00          	mov    0x0(%r13),%rdx
    74c3:	48 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%rbp,%rcx,8)
    74ca:	00 00 
    74cc:	75 1e                	jne    74ec <fwp_hof0.constprop.0+0x14fc>
    74ce:	e9 a1 00 00 00       	jmp    7574 <fwp_hof0.constprop.0+0x1584>
    74d3:	66 90                	xchg   %ax,%ax
    74d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74dc:	00 00 00 00 
    74e0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    74e4:	48 85 c9             	test   %rcx,%rcx
    74e7:	74 2b                	je     7514 <fwp_hof0.constprop.0+0x1524>
    74e9:	48 89 ca             	mov    %rcx,%rdx
    74ec:	4c 39 22             	cmp    %r12,(%rdx)
    74ef:	75 ef                	jne    74e0 <fwp_hof0.constprop.0+0x14f0>
    74f1:	3c fe                	cmp    $0xfe,%al
    74f3:	0f 84 84 00 00 00    	je     757d <fwp_hof0.constprop.0+0x158d>
    74f9:	48 8b 42 08          	mov    0x8(%rdx),%rax
    74fd:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    7501:	0f 84 b6 00 00 00    	je     75bd <fwp_hof0.constprop.0+0x15cd>
    7507:	48 83 c0 01          	add    $0x1,%rax
    750b:	48 89 42 08          	mov    %rax,0x8(%rdx)
    750f:	e9 97 eb ff ff       	jmp    60ab <fwp_hof0.constprop.0+0xbb>
    7514:	3c fe                	cmp    $0xfe,%al
    7516:	0f 85 84 00 00 00    	jne    75a0 <fwp_hof0.constprop.0+0x15b0>
    751c:	4c 8d 6a 10          	lea    0x10(%rdx),%r13
    7520:	bf 18 00 00 00       	mov    $0x18,%edi
    7525:	e8 56 b0 ff ff       	call   2580 <malloc@plt>
    752a:	48 85 c0             	test   %rax,%rax
    752d:	0f 84 85 00 00 00    	je     75b8 <fwp_hof0.constprop.0+0x15c8>
    7533:	4c 89 20             	mov    %r12,(%rax)
    7536:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    753d:	00 
    753e:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    7545:	00 
    7546:	49 89 45 00          	mov    %rax,0x0(%r13)
    754a:	41 c6 04 24 ff       	movb   $0xff,(%r12)
    754f:	48 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%rbp)
    7556:	01 
    7557:	e9 4f eb ff ff       	jmp    60ab <fwp_hof0.constprop.0+0xbb>
    755c:	48 8d 3d 75 3d 00 00 	lea    0x3d75(%rip),%rdi        # b2d8 <_IO_stdin_used+0x2d8>
    7563:	e8 48 bb ff ff       	call   30b0 <fwp_trap>
    7568:	48 8d 3d 36 3b 00 00 	lea    0x3b36(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    756f:	e8 3c bb ff ff       	call   30b0 <fwp_trap>
    7574:	3c fe                	cmp    $0xfe,%al
    7576:	75 18                	jne    7590 <fwp_hof0.constprop.0+0x15a0>
    7578:	48 85 d2             	test   %rdx,%rdx
    757b:	74 a3                	je     7520 <fwp_hof0.constprop.0+0x1530>
    757d:	48 8d 3d 2c 3d 00 00 	lea    0x3d2c(%rip),%rdi        # b2b0 <_IO_stdin_used+0x2b0>
    7584:	e8 27 bb ff ff       	call   30b0 <fwp_trap>
    7589:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7590:	48 85 d2             	test   %rdx,%rdx
    7593:	0f 85 60 ff ff ff    	jne    74f9 <fwp_hof0.constprop.0+0x1509>
    7599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75a0:	48 8d 3d e1 3c 00 00 	lea    0x3ce1(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    75a7:	e8 04 bb ff ff       	call   30b0 <fwp_trap>
    75ac:	48 8d 3d aa 3b 00 00 	lea    0x3baa(%rip),%rdi        # b15d <_IO_stdin_used+0x15d>
    75b3:	e8 f8 ba ff ff       	call   30b0 <fwp_trap>
    75b8:	e8 43 b6 ff ff       	call   2c00 <fwp_heap_oom>
    75bd:	48 8d 3d 80 3b 00 00 	lea    0x3b80(%rip),%rdi        # b144 <_IO_stdin_used+0x144>
    75c4:	e8 e7 ba ff ff       	call   30b0 <fwp_trap>
    75c9:	e8 72 ae ff ff       	call   2440 <__stack_chk_fail@plt>
    75ce:	66 90                	xchg   %ax,%ax

00000000000075d0 <f0>:
    75d0:	41 56                	push   %r14
    75d2:	4c 8d 35 67 61 01 00 	lea    0x16167(%rip),%r14        # 1d740 <fwp_heap>
    75d9:	41 55                	push   %r13
    75db:	41 54                	push   %r12
    75dd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    75e3:	55                   	push   %rbp
    75e4:	53                   	push   %rbx
    75e5:	31 db                	xor    %ebx,%ebx
    75e7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    75ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    75f5:	00 00 
    75f7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    75fe:	00 
    75ff:	31 c0                	xor    %eax,%eax
    7601:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    7608:	00 
    7609:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    7610:	00 00 
    7612:	66 48 0f 6e c0       	movq   %rax,%xmm0
    7617:	48 8d 05 72 d8 ff ff 	lea    -0x278e(%rip),%rax        # 4e90 <fwp_drop1>
    761e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7623:	48 8b 05 a6 7d 01 00 	mov    0x17da6(%rip),%rax        # 1f3d0 <fwp_cleanups>
    762a:	48 89 25 9f 7d 01 00 	mov    %rsp,0x17d9f(%rip)        # 1f3d0 <fwp_cleanups>
    7631:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    7635:	48 89 04 24          	mov    %rax,(%rsp)
    7639:	48 8d 05 50 b5 ff ff 	lea    -0x4ab0(%rip),%rax        # 2b90 <fwp_range_release>
    7640:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7645:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    764a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    764f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    7654:	eb 47                	jmp    769d <f0+0xcd>
    7656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    765d:	00 00 00 
    7660:	80 f9 01             	cmp    $0x1,%cl
    7663:	75 29                	jne    768e <f0+0xbe>
    7665:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7668:	0f b7 c0             	movzwl %ax,%eax
    766b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    766e:	48 0f af c1          	imul   %rcx,%rax
    7672:	48 c1 e8 20          	shr    $0x20,%rax
    7676:	48 39 d0             	cmp    %rdx,%rax
    7679:	73 13                	jae    768e <f0+0xbe>
    767b:	49 01 c5             	add    %rax,%r13
    767e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7683:	0f 84 c7 27 00 00    	je     9e50 <f0+0x2880>
    7689:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    768e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7693:	49 83 ec 01          	sub    $0x1,%r12
    7697:	0f 82 83 00 00 00    	jb     7720 <f0+0x150>
    769d:	48 89 ee             	mov    %rbp,%rsi
    76a0:	bf 01 00 00 00       	mov    $0x1,%edi
    76a5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    76ac:	00 
    76ad:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    76b2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    76b9:	00 
    76ba:	e8 61 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76bf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    76c6:	48 89 c3             	mov    %rax,%rbx
    76c9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    76d0:	48 c1 e2 10          	shl    $0x10,%rdx
    76d4:	48 39 d0             	cmp    %rdx,%rax
    76d7:	73 b5                	jae    768e <f0+0xbe>
    76d9:	48 89 c2             	mov    %rax,%rdx
    76dc:	48 c1 ea 10          	shr    $0x10,%rdx
    76e0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76e4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    76eb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76ef:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    76f3:	4d 85 ed             	test   %r13,%r13
    76f6:	74 96                	je     768e <f0+0xbe>
    76f8:	0f b6 0a             	movzbl (%rdx),%ecx
    76fb:	80 f9 02             	cmp    $0x2,%cl
    76fe:	0f 85 5c ff ff ff    	jne    7660 <f0+0x90>
    7704:	66 85 c0             	test   %ax,%ax
    7707:	0f 84 71 ff ff ff    	je     767e <f0+0xae>
    770d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7712:	49 83 ec 01          	sub    $0x1,%r12
    7716:	73 85                	jae    769d <f0+0xcd>
    7718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    771f:	00 
    7720:	48 8b 04 24          	mov    (%rsp),%rax
    7724:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    7729:	bf 01 00 00 00       	mov    $0x1,%edi
    772e:	66 0f 6f 05 9a 3d 00 	movdqa 0x3d9a(%rip),%xmm0        # b4d0 <msg.3+0x90>
    7735:	00 
    7736:	48 89 05 93 7c 01 00 	mov    %rax,0x17c93(%rip)        # 1f3d0 <fwp_cleanups>
    773d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    7742:	e8 d9 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7747:	48 8b 15 ca 73 01 00 	mov    0x173ca(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    774e:	49 89 c5             	mov    %rax,%r13
    7751:	48 2b 05 98 73 01 00 	sub    0x17398(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    7758:	48 c1 e2 10          	shl    $0x10,%rdx
    775c:	48 39 d0             	cmp    %rdx,%rax
    775f:	73 59                	jae    77ba <f0+0x1ea>
    7761:	48 89 c2             	mov    %rax,%rdx
    7764:	48 c1 ea 10          	shr    $0x10,%rdx
    7768:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    776c:	48 8b 15 c5 73 01 00 	mov    0x173c5(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    7773:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7777:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    777b:	4d 85 e4             	test   %r12,%r12
    777e:	74 3a                	je     77ba <f0+0x1ea>
    7780:	0f b6 0a             	movzbl (%rdx),%ecx
    7783:	80 f9 02             	cmp    $0x2,%cl
    7786:	0f 84 74 27 00 00    	je     9f00 <f0+0x2930>
    778c:	80 f9 01             	cmp    $0x1,%cl
    778f:	75 29                	jne    77ba <f0+0x1ea>
    7791:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7794:	0f b7 c0             	movzwl %ax,%eax
    7797:	8b 52 1c             	mov    0x1c(%rdx),%edx
    779a:	48 0f af c1          	imul   %rcx,%rax
    779e:	48 c1 e8 20          	shr    $0x20,%rax
    77a2:	48 39 d0             	cmp    %rdx,%rax
    77a5:	73 13                	jae    77ba <f0+0x1ea>
    77a7:	49 01 c4             	add    %rax,%r12
    77aa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    77af:	0f 84 26 29 00 00    	je     a0db <f0+0x2b0b>
    77b5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    77ba:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    77bf:	bf 01 00 00 00       	mov    $0x1,%edi
    77c4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    77c9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    77d0:	00 f0 3f 
    77d3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    77d8:	e8 43 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77dd:	48 8b 15 34 73 01 00 	mov    0x17334(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    77e4:	49 89 c5             	mov    %rax,%r13
    77e7:	48 2b 05 02 73 01 00 	sub    0x17302(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    77ee:	48 c1 e2 10          	shl    $0x10,%rdx
    77f2:	48 39 d0             	cmp    %rdx,%rax
    77f5:	73 59                	jae    7850 <f0+0x280>
    77f7:	48 89 c2             	mov    %rax,%rdx
    77fa:	48 c1 ea 10          	shr    $0x10,%rdx
    77fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7802:	48 8b 15 2f 73 01 00 	mov    0x1732f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    7809:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    780d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7811:	4d 85 e4             	test   %r12,%r12
    7814:	74 3a                	je     7850 <f0+0x280>
    7816:	0f b6 0a             	movzbl (%rdx),%ecx
    7819:	80 f9 02             	cmp    $0x2,%cl
    781c:	0f 84 ce 26 00 00    	je     9ef0 <f0+0x2920>
    7822:	80 f9 01             	cmp    $0x1,%cl
    7825:	75 29                	jne    7850 <f0+0x280>
    7827:	8b 4a 18             	mov    0x18(%rdx),%ecx
    782a:	0f b7 c0             	movzwl %ax,%eax
    782d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7830:	48 0f af c1          	imul   %rcx,%rax
    7834:	48 c1 e8 20          	shr    $0x20,%rax
    7838:	48 39 d0             	cmp    %rdx,%rax
    783b:	73 13                	jae    7850 <f0+0x280>
    783d:	49 01 c4             	add    %rax,%r12
    7840:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7845:	0f 84 9d 28 00 00    	je     a0e8 <f0+0x2b18>
    784b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7850:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    7855:	bf 01 00 00 00       	mov    $0x1,%edi
    785a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    785f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    7866:	33 f3 bf 
    7869:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    786e:	e8 ad ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7873:	48 8b 15 9e 72 01 00 	mov    0x1729e(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    787a:	49 89 c5             	mov    %rax,%r13
    787d:	48 2b 05 6c 72 01 00 	sub    0x1726c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    7884:	48 c1 e2 10          	shl    $0x10,%rdx
    7888:	48 39 d0             	cmp    %rdx,%rax
    788b:	73 59                	jae    78e6 <f0+0x316>
    788d:	48 89 c2             	mov    %rax,%rdx
    7890:	48 c1 ea 10          	shr    $0x10,%rdx
    7894:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7898:	48 8b 15 99 72 01 00 	mov    0x17299(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    789f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78a3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    78a7:	4d 85 e4             	test   %r12,%r12
    78aa:	74 3a                	je     78e6 <f0+0x316>
    78ac:	0f b6 0a             	movzbl (%rdx),%ecx
    78af:	80 f9 02             	cmp    $0x2,%cl
    78b2:	0f 84 28 26 00 00    	je     9ee0 <f0+0x2910>
    78b8:	80 f9 01             	cmp    $0x1,%cl
    78bb:	75 29                	jne    78e6 <f0+0x316>
    78bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78c0:	0f b7 c0             	movzwl %ax,%eax
    78c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78c6:	48 0f af c1          	imul   %rcx,%rax
    78ca:	48 c1 e8 20          	shr    $0x20,%rax
    78ce:	48 39 d0             	cmp    %rdx,%rax
    78d1:	73 13                	jae    78e6 <f0+0x316>
    78d3:	49 01 c4             	add    %rax,%r12
    78d6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    78db:	0f 84 14 28 00 00    	je     a0f5 <f0+0x2b25>
    78e1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    78e6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    78eb:	bf 01 00 00 00       	mov    $0x1,%edi
    78f0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    78f5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    78fc:	00 f0 3f 
    78ff:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7904:	e8 17 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7909:	48 8b 15 08 72 01 00 	mov    0x17208(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    7910:	49 89 c5             	mov    %rax,%r13
    7913:	48 2b 05 d6 71 01 00 	sub    0x171d6(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    791a:	48 c1 e2 10          	shl    $0x10,%rdx
    791e:	48 39 d0             	cmp    %rdx,%rax
    7921:	73 59                	jae    797c <f0+0x3ac>
    7923:	48 89 c2             	mov    %rax,%rdx
    7926:	48 c1 ea 10          	shr    $0x10,%rdx
    792a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    792e:	48 8b 15 03 72 01 00 	mov    0x17203(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    7935:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7939:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    793d:	4d 85 e4             	test   %r12,%r12
    7940:	74 3a                	je     797c <f0+0x3ac>
    7942:	0f b6 0a             	movzbl (%rdx),%ecx
    7945:	80 f9 02             	cmp    $0x2,%cl
    7948:	0f 84 f2 25 00 00    	je     9f40 <f0+0x2970>
    794e:	80 f9 01             	cmp    $0x1,%cl
    7951:	75 29                	jne    797c <f0+0x3ac>
    7953:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7956:	0f b7 c0             	movzwl %ax,%eax
    7959:	8b 52 1c             	mov    0x1c(%rdx),%edx
    795c:	48 0f af c1          	imul   %rcx,%rax
    7960:	48 c1 e8 20          	shr    $0x20,%rax
    7964:	48 39 d0             	cmp    %rdx,%rax
    7967:	73 13                	jae    797c <f0+0x3ac>
    7969:	49 01 c4             	add    %rax,%r12
    796c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7971:	0f 84 8b 27 00 00    	je     a102 <f0+0x2b32>
    7977:	41 c6 04 24 01       	movb   $0x1,(%r12)
    797c:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    7983:	33 f3 bf 
    7986:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    798d:	00 
    798e:	bf 01 00 00 00       	mov    $0x1,%edi
    7993:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    799a:	00 
    799b:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    79a2:	00 
    79a3:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    79aa:	00 f0 3f 
    79ad:	e8 6e cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79b2:	48 89 c7             	mov    %rax,%rdi
    79b5:	e8 16 cb ff ff       	call   44d0 <fwp_rc_fresh>
    79ba:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    79c1:	00 
    79c2:	bf 01 00 00 00       	mov    $0x1,%edi
    79c7:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    79ce:	00 
    79cf:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    79d6:	00 
    79d7:	e8 44 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79dc:	48 89 c7             	mov    %rax,%rdi
    79df:	e8 ec ca ff ff       	call   44d0 <fwp_rc_fresh>
    79e4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    79eb:	00 
    79ec:	bf 01 00 00 00       	mov    $0x1,%edi
    79f1:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    79f8:	00 
    79f9:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    7a00:	00 
    7a01:	e8 1a cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a06:	48 89 c7             	mov    %rax,%rdi
    7a09:	e8 c2 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a0e:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    7a15:	00 
    7a16:	bf 01 00 00 00       	mov    $0x1,%edi
    7a1b:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    7a22:	00 
    7a23:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7a2a:	00 
    7a2b:	e8 f0 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a30:	48 89 c7             	mov    %rax,%rdi
    7a33:	e8 98 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a38:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    7a3f:	00 
    7a40:	bf 01 00 00 00       	mov    $0x1,%edi
    7a45:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    7a4c:	00 
    7a4d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7a54:	00 
    7a55:	e8 c6 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a5a:	48 89 c7             	mov    %rax,%rdi
    7a5d:	e8 6e ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a62:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    7a69:	00 
    7a6a:	bf 01 00 00 00       	mov    $0x1,%edi
    7a6f:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    7a76:	00 
    7a77:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7a7e:	00 
    7a7f:	e8 9c cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a84:	48 89 c7             	mov    %rax,%rdi
    7a87:	e8 44 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a8c:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    7a93:	00 
    7a94:	bf 01 00 00 00       	mov    $0x1,%edi
    7a99:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    7aa0:	00 
    7aa1:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    7aa8:	00 
    7aa9:	e8 72 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7aae:	48 89 c7             	mov    %rax,%rdi
    7ab1:	e8 1a ca ff ff       	call   44d0 <fwp_rc_fresh>
    7ab6:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    7abd:	00 
    7abe:	bf 01 00 00 00       	mov    $0x1,%edi
    7ac3:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    7aca:	00 
    7acb:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    7ad2:	00 
    7ad3:	e8 48 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ad8:	48 89 c7             	mov    %rax,%rdi
    7adb:	e8 f0 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7ae0:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    7ae7:	00 
    7ae8:	bf 01 00 00 00       	mov    $0x1,%edi
    7aed:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    7af4:	00 
    7af5:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    7afc:	00 
    7afd:	e8 1e cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b02:	48 89 c7             	mov    %rax,%rdi
    7b05:	e8 c6 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b0a:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    7b11:	00 
    7b12:	bf 01 00 00 00       	mov    $0x1,%edi
    7b17:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7b1e:	00 
    7b1f:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7b26:	00 
    7b27:	e8 f4 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b2c:	48 89 c7             	mov    %rax,%rdi
    7b2f:	e8 9c c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b34:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    7b3b:	00 
    7b3c:	bf 01 00 00 00       	mov    $0x1,%edi
    7b41:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    7b48:	00 
    7b49:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7b50:	00 
    7b51:	e8 ca cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b56:	48 89 c7             	mov    %rax,%rdi
    7b59:	e8 72 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b5e:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    7b65:	00 
    7b66:	bf 01 00 00 00       	mov    $0x1,%edi
    7b6b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    7b72:	00 
    7b73:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    7b7a:	00 
    7b7b:	e8 a0 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b80:	48 89 c7             	mov    %rax,%rdi
    7b83:	e8 48 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b88:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    7b8f:	00 
    7b90:	bf 01 00 00 00       	mov    $0x1,%edi
    7b95:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    7b9c:	00 
    7b9d:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    7ba4:	00 
    7ba5:	e8 76 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7baa:	48 89 c7             	mov    %rax,%rdi
    7bad:	e8 1e c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7bb2:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    7bb9:	00 
    7bba:	bf 01 00 00 00       	mov    $0x1,%edi
    7bbf:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    7bc6:	00 
    7bc7:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    7bce:	00 
    7bcf:	e8 4c cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bd4:	48 89 c7             	mov    %rax,%rdi
    7bd7:	e8 f4 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7bdc:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    7be3:	00 
    7be4:	bf 01 00 00 00       	mov    $0x1,%edi
    7be9:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    7bf0:	00 
    7bf1:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    7bf8:	00 
    7bf9:	e8 22 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bfe:	48 89 c7             	mov    %rax,%rdi
    7c01:	e8 ca c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c06:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    7c0d:	00 
    7c0e:	bf 01 00 00 00       	mov    $0x1,%edi
    7c13:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    7c1a:	00 
    7c1b:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    7c22:	00 
    7c23:	e8 f8 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c28:	48 89 c7             	mov    %rax,%rdi
    7c2b:	e8 a0 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c30:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    7c37:	00 
    7c38:	bf 01 00 00 00       	mov    $0x1,%edi
    7c3d:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    7c44:	00 
    7c45:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7c4c:	00 
    7c4d:	e8 ce ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c52:	48 89 c7             	mov    %rax,%rdi
    7c55:	e8 76 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c5a:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    7c61:	00 
    7c62:	bf 01 00 00 00       	mov    $0x1,%edi
    7c67:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7c6e:	00 
    7c6f:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7c76:	00 
    7c77:	e8 a4 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c7c:	48 89 c7             	mov    %rax,%rdi
    7c7f:	e8 4c c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c84:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    7c8b:	00 
    7c8c:	bf 01 00 00 00       	mov    $0x1,%edi
    7c91:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    7c98:	00 
    7c99:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    7ca0:	00 
    7ca1:	e8 7a ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ca6:	48 89 c7             	mov    %rax,%rdi
    7ca9:	e8 22 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7cae:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    7cb5:	00 
    7cb6:	bf 01 00 00 00       	mov    $0x1,%edi
    7cbb:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    7cc2:	00 
    7cc3:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    7cca:	00 
    7ccb:	e8 50 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7cd0:	48 89 c7             	mov    %rax,%rdi
    7cd3:	e8 f8 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7cd8:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    7cdf:	00 
    7ce0:	bf 01 00 00 00       	mov    $0x1,%edi
    7ce5:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    7cec:	00 
    7ced:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    7cf4:	00 
    7cf5:	e8 26 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7cfa:	48 89 c7             	mov    %rax,%rdi
    7cfd:	e8 ce c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d02:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    7d09:	00 
    7d0a:	bf 01 00 00 00       	mov    $0x1,%edi
    7d0f:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    7d16:	00 
    7d17:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    7d1e:	00 
    7d1f:	e8 fc c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d24:	48 89 c7             	mov    %rax,%rdi
    7d27:	e8 a4 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d2c:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    7d33:	00 
    7d34:	bf 01 00 00 00       	mov    $0x1,%edi
    7d39:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    7d40:	00 
    7d41:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    7d48:	00 
    7d49:	e8 d2 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d4e:	48 89 c7             	mov    %rax,%rdi
    7d51:	e8 7a c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d56:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    7d5d:	00 
    7d5e:	bf 01 00 00 00       	mov    $0x1,%edi
    7d63:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    7d6a:	00 
    7d6b:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    7d72:	00 
    7d73:	e8 a8 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d78:	48 89 c7             	mov    %rax,%rdi
    7d7b:	e8 50 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d80:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    7d87:	00 
    7d88:	bf 01 00 00 00       	mov    $0x1,%edi
    7d8d:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    7d94:	00 
    7d95:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    7d9c:	00 
    7d9d:	e8 7e c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7da2:	48 89 c7             	mov    %rax,%rdi
    7da5:	e8 26 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7daa:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    7db1:	00 
    7db2:	bf 01 00 00 00       	mov    $0x1,%edi
    7db7:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    7dbe:	00 
    7dbf:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    7dc6:	00 
    7dc7:	e8 54 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7dcc:	48 89 c7             	mov    %rax,%rdi
    7dcf:	e8 fc c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7dd4:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    7ddb:	00 
    7ddc:	bf 01 00 00 00       	mov    $0x1,%edi
    7de1:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    7de8:	00 
    7de9:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    7df0:	00 
    7df1:	e8 2a c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7df6:	48 89 c7             	mov    %rax,%rdi
    7df9:	e8 d2 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7dfe:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    7e05:	00 
    7e06:	bf 01 00 00 00       	mov    $0x1,%edi
    7e0b:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    7e12:	00 
    7e13:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    7e1a:	00 
    7e1b:	e8 00 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e20:	48 89 c7             	mov    %rax,%rdi
    7e23:	e8 a8 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e28:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    7e2f:	00 
    7e30:	bf 01 00 00 00       	mov    $0x1,%edi
    7e35:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    7e3c:	00 
    7e3d:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    7e44:	00 
    7e45:	e8 d6 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e4a:	48 89 c7             	mov    %rax,%rdi
    7e4d:	e8 7e c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e52:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    7e59:	00 
    7e5a:	bf 01 00 00 00       	mov    $0x1,%edi
    7e5f:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    7e66:	00 
    7e67:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    7e6e:	00 
    7e6f:	e8 ac c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e74:	48 89 c7             	mov    %rax,%rdi
    7e77:	e8 54 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e7c:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    7e83:	00 
    7e84:	bf 01 00 00 00       	mov    $0x1,%edi
    7e89:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    7e90:	00 
    7e91:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    7e98:	00 
    7e99:	e8 82 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e9e:	48 89 c7             	mov    %rax,%rdi
    7ea1:	e8 2a c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7ea6:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    7ead:	00 
    7eae:	bf 01 00 00 00       	mov    $0x1,%edi
    7eb3:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    7eba:	00 
    7ebb:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    7ec2:	00 
    7ec3:	e8 58 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ec8:	48 89 c7             	mov    %rax,%rdi
    7ecb:	e8 00 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7ed0:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    7ed7:	00 
    7ed8:	bf 01 00 00 00       	mov    $0x1,%edi
    7edd:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    7ee4:	00 
    7ee5:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    7eec:	00 
    7eed:	e8 2e c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ef2:	48 89 c7             	mov    %rax,%rdi
    7ef5:	e8 d6 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7efa:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    7f01:	00 
    7f02:	bf 01 00 00 00       	mov    $0x1,%edi
    7f07:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    7f0e:	00 
    7f0f:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    7f16:	00 
    7f17:	e8 04 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f1c:	48 89 c7             	mov    %rax,%rdi
    7f1f:	e8 ac c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f24:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    7f2b:	00 
    7f2c:	bf 01 00 00 00       	mov    $0x1,%edi
    7f31:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    7f38:	00 
    7f39:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    7f40:	00 
    7f41:	e8 da c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f46:	48 89 c7             	mov    %rax,%rdi
    7f49:	e8 82 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f4e:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    7f55:	00 
    7f56:	bf 01 00 00 00       	mov    $0x1,%edi
    7f5b:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    7f62:	00 
    7f63:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    7f6a:	00 
    7f6b:	e8 b0 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f70:	48 89 c7             	mov    %rax,%rdi
    7f73:	e8 58 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f78:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    7f7f:	00 
    7f80:	bf 01 00 00 00       	mov    $0x1,%edi
    7f85:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    7f8c:	00 
    7f8d:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    7f94:	00 
    7f95:	e8 86 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f9a:	48 89 c7             	mov    %rax,%rdi
    7f9d:	e8 2e c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7fa2:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    7fa9:	00 
    7faa:	bf 01 00 00 00       	mov    $0x1,%edi
    7faf:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    7fb6:	00 
    7fb7:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    7fbe:	00 
    7fbf:	e8 5c c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fc4:	48 89 c7             	mov    %rax,%rdi
    7fc7:	e8 04 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7fcc:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    7fd3:	00 
    7fd4:	bf 01 00 00 00       	mov    $0x1,%edi
    7fd9:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    7fe0:	00 
    7fe1:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    7fe8:	00 
    7fe9:	e8 32 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fee:	48 89 c7             	mov    %rax,%rdi
    7ff1:	e8 da c4 ff ff       	call   44d0 <fwp_rc_fresh>
    7ff6:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    7ffd:	00 
    7ffe:	bf 01 00 00 00       	mov    $0x1,%edi
    8003:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    800a:	00 
    800b:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    8012:	00 
    8013:	e8 08 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8018:	48 89 c7             	mov    %rax,%rdi
    801b:	e8 b0 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    8020:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    8027:	00 
    8028:	bf 01 00 00 00       	mov    $0x1,%edi
    802d:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    8034:	00 
    8035:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    803c:	00 
    803d:	e8 de c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8042:	48 89 c7             	mov    %rax,%rdi
    8045:	e8 86 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    804a:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    8051:	00 
    8052:	bf 01 00 00 00       	mov    $0x1,%edi
    8057:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    805e:	00 
    805f:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    8066:	00 
    8067:	e8 b4 c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    806c:	48 89 c7             	mov    %rax,%rdi
    806f:	e8 5c c4 ff ff       	call   44d0 <fwp_rc_fresh>
    8074:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    807b:	00 
    807c:	bf 01 00 00 00       	mov    $0x1,%edi
    8081:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    8088:	00 
    8089:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    8090:	00 
    8091:	e8 8a c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8096:	48 89 c7             	mov    %rax,%rdi
    8099:	e8 32 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    809e:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    80a5:	00 
    80a6:	bf 01 00 00 00       	mov    $0x1,%edi
    80ab:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    80b2:	00 
    80b3:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    80ba:	00 
    80bb:	e8 60 c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    80c0:	48 89 c7             	mov    %rax,%rdi
    80c3:	e8 08 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    80c8:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    80cf:	00 
    80d0:	bf 01 00 00 00       	mov    $0x1,%edi
    80d5:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    80dc:	00 
    80dd:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    80e4:	00 
    80e5:	e8 36 c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    80ea:	48 89 c7             	mov    %rax,%rdi
    80ed:	e8 de c3 ff ff       	call   44d0 <fwp_rc_fresh>
    80f2:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    80f9:	00 
    80fa:	bf 01 00 00 00       	mov    $0x1,%edi
    80ff:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    8106:	00 
    8107:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    810e:	00 
    810f:	e8 0c c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8114:	48 89 c7             	mov    %rax,%rdi
    8117:	e8 b4 c3 ff ff       	call   44d0 <fwp_rc_fresh>
    811c:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    8123:	00 
    8124:	bf 01 00 00 00       	mov    $0x1,%edi
    8129:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    8130:	00 
    8131:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    8138:	00 
    8139:	e8 e2 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    813e:	48 89 c7             	mov    %rax,%rdi
    8141:	e8 8a c3 ff ff       	call   44d0 <fwp_rc_fresh>
    8146:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    814d:	00 
    814e:	bf 01 00 00 00       	mov    $0x1,%edi
    8153:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    815a:	00 
    815b:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    8162:	00 
    8163:	e8 b8 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8168:	48 89 c7             	mov    %rax,%rdi
    816b:	e8 60 c3 ff ff       	call   44d0 <fwp_rc_fresh>
    8170:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    8177:	00 
    8178:	bf 01 00 00 00       	mov    $0x1,%edi
    817d:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    8184:	00 
    8185:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    818c:	00 
    818d:	e8 8e c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8192:	48 89 c7             	mov    %rax,%rdi
    8195:	e8 36 c3 ff ff       	call   44d0 <fwp_rc_fresh>
    819a:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    81a1:	00 
    81a2:	bf 01 00 00 00       	mov    $0x1,%edi
    81a7:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    81ae:	00 
    81af:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    81b6:	00 
    81b7:	e8 64 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    81bc:	48 89 c7             	mov    %rax,%rdi
    81bf:	e8 0c c3 ff ff       	call   44d0 <fwp_rc_fresh>
    81c4:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    81cb:	00 
    81cc:	bf 01 00 00 00       	mov    $0x1,%edi
    81d1:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    81d8:	00 
    81d9:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    81e0:	00 
    81e1:	e8 3a c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    81e6:	48 89 c7             	mov    %rax,%rdi
    81e9:	e8 e2 c2 ff ff       	call   44d0 <fwp_rc_fresh>
    81ee:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    81f5:	00 
    81f6:	bf 01 00 00 00       	mov    $0x1,%edi
    81fb:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    8202:	00 
    8203:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    820a:	00 
    820b:	e8 10 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8210:	48 89 c7             	mov    %rax,%rdi
    8213:	e8 b8 c2 ff ff       	call   44d0 <fwp_rc_fresh>
    8218:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    821f:	00 
    8220:	bf 01 00 00 00       	mov    $0x1,%edi
    8225:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    822c:	00 
    822d:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    8234:	00 
    8235:	e8 e6 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    823a:	48 89 c7             	mov    %rax,%rdi
    823d:	e8 8e c2 ff ff       	call   44d0 <fwp_rc_fresh>
    8242:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    8249:	00 
    824a:	bf 01 00 00 00       	mov    $0x1,%edi
    824f:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    8256:	00 
    8257:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    825e:	00 
    825f:	e8 bc c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8264:	48 89 c7             	mov    %rax,%rdi
    8267:	e8 64 c2 ff ff       	call   44d0 <fwp_rc_fresh>
    826c:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    8273:	00 
    8274:	bf 01 00 00 00       	mov    $0x1,%edi
    8279:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    8280:	00 
    8281:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    8288:	00 
    8289:	e8 92 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    828e:	48 89 c7             	mov    %rax,%rdi
    8291:	e8 3a c2 ff ff       	call   44d0 <fwp_rc_fresh>
    8296:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    829d:	00 
    829e:	bf 01 00 00 00       	mov    $0x1,%edi
    82a3:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    82aa:	00 
    82ab:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    82b2:	00 
    82b3:	e8 68 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    82b8:	48 89 c7             	mov    %rax,%rdi
    82bb:	e8 10 c2 ff ff       	call   44d0 <fwp_rc_fresh>
    82c0:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    82c7:	00 
    82c8:	bf 01 00 00 00       	mov    $0x1,%edi
    82cd:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    82d4:	00 
    82d5:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    82dc:	00 
    82dd:	e8 3e c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    82e2:	48 89 c7             	mov    %rax,%rdi
    82e5:	e8 e6 c1 ff ff       	call   44d0 <fwp_rc_fresh>
    82ea:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    82f1:	00 
    82f2:	bf 01 00 00 00       	mov    $0x1,%edi
    82f7:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    82fe:	00 
    82ff:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    8306:	00 
    8307:	e8 14 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    830c:	48 89 c7             	mov    %rax,%rdi
    830f:	e8 bc c1 ff ff       	call   44d0 <fwp_rc_fresh>
    8314:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    831b:	00 
    831c:	bf 01 00 00 00       	mov    $0x1,%edi
    8321:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    8328:	00 
    8329:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    8330:	00 
    8331:	e8 ea c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8336:	48 89 c7             	mov    %rax,%rdi
    8339:	e8 92 c1 ff ff       	call   44d0 <fwp_rc_fresh>
    833e:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    8345:	00 
    8346:	bf 01 00 00 00       	mov    $0x1,%edi
    834b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    8352:	00 
    8353:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    835a:	00 
    835b:	e8 c0 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8360:	48 89 c7             	mov    %rax,%rdi
    8363:	e8 68 c1 ff ff       	call   44d0 <fwp_rc_fresh>
    8368:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    836f:	00 
    8370:	bf 01 00 00 00       	mov    $0x1,%edi
    8375:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    837c:	00 
    837d:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    8384:	00 
    8385:	e8 96 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    838a:	48 89 c7             	mov    %rax,%rdi
    838d:	e8 3e c1 ff ff       	call   44d0 <fwp_rc_fresh>
    8392:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    8399:	00 
    839a:	bf 01 00 00 00       	mov    $0x1,%edi
    839f:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    83a6:	00 
    83a7:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    83ae:	00 
    83af:	e8 6c c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    83b4:	48 89 c7             	mov    %rax,%rdi
    83b7:	e8 14 c1 ff ff       	call   44d0 <fwp_rc_fresh>
    83bc:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    83c3:	00 
    83c4:	bf 01 00 00 00       	mov    $0x1,%edi
    83c9:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    83d0:	00 
    83d1:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    83d8:	00 
    83d9:	e8 42 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    83de:	48 89 c7             	mov    %rax,%rdi
    83e1:	e8 ea c0 ff ff       	call   44d0 <fwp_rc_fresh>
    83e6:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    83ed:	00 
    83ee:	bf 01 00 00 00       	mov    $0x1,%edi
    83f3:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    83fa:	00 
    83fb:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    8402:	00 
    8403:	e8 18 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8408:	48 89 c7             	mov    %rax,%rdi
    840b:	e8 c0 c0 ff ff       	call   44d0 <fwp_rc_fresh>
    8410:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    8417:	00 
    8418:	bf 01 00 00 00       	mov    $0x1,%edi
    841d:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    8424:	00 
    8425:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    842c:	00 
    842d:	e8 ee c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8432:	48 89 c7             	mov    %rax,%rdi
    8435:	e8 96 c0 ff ff       	call   44d0 <fwp_rc_fresh>
    843a:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    8441:	00 
    8442:	bf 01 00 00 00       	mov    $0x1,%edi
    8447:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    844e:	00 
    844f:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    8456:	00 
    8457:	e8 c4 c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    845c:	48 89 c7             	mov    %rax,%rdi
    845f:	e8 6c c0 ff ff       	call   44d0 <fwp_rc_fresh>
    8464:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    846b:	00 
    846c:	bf 01 00 00 00       	mov    $0x1,%edi
    8471:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    8478:	00 
    8479:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    8480:	00 
    8481:	e8 9a c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8486:	48 89 c7             	mov    %rax,%rdi
    8489:	e8 42 c0 ff ff       	call   44d0 <fwp_rc_fresh>
    848e:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    8495:	00 
    8496:	bf 01 00 00 00       	mov    $0x1,%edi
    849b:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    84a2:	00 
    84a3:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    84aa:	00 
    84ab:	e8 70 c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    84b0:	48 89 c7             	mov    %rax,%rdi
    84b3:	e8 18 c0 ff ff       	call   44d0 <fwp_rc_fresh>
    84b8:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    84bf:	00 
    84c0:	bf 01 00 00 00       	mov    $0x1,%edi
    84c5:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    84cc:	00 
    84cd:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    84d4:	00 
    84d5:	e8 46 c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    84da:	48 89 c7             	mov    %rax,%rdi
    84dd:	e8 ee bf ff ff       	call   44d0 <fwp_rc_fresh>
    84e2:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    84e9:	00 
    84ea:	bf 01 00 00 00       	mov    $0x1,%edi
    84ef:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    84f6:	00 
    84f7:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    84fe:	00 
    84ff:	e8 1c c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8504:	48 89 c7             	mov    %rax,%rdi
    8507:	e8 c4 bf ff ff       	call   44d0 <fwp_rc_fresh>
    850c:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    8513:	00 
    8514:	bf 01 00 00 00       	mov    $0x1,%edi
    8519:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    8520:	00 
    8521:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    8528:	00 
    8529:	e8 f2 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    852e:	48 89 c7             	mov    %rax,%rdi
    8531:	e8 9a bf ff ff       	call   44d0 <fwp_rc_fresh>
    8536:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    853d:	00 
    853e:	bf 01 00 00 00       	mov    $0x1,%edi
    8543:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    854a:	00 
    854b:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    8552:	00 
    8553:	e8 c8 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8558:	48 89 c7             	mov    %rax,%rdi
    855b:	e8 70 bf ff ff       	call   44d0 <fwp_rc_fresh>
    8560:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    8567:	00 
    8568:	bf 01 00 00 00       	mov    $0x1,%edi
    856d:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    8574:	00 
    8575:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    857c:	00 
    857d:	e8 9e c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8582:	48 89 c7             	mov    %rax,%rdi
    8585:	e8 46 bf ff ff       	call   44d0 <fwp_rc_fresh>
    858a:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    8591:	00 
    8592:	bf 01 00 00 00       	mov    $0x1,%edi
    8597:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    859e:	00 
    859f:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    85a6:	00 
    85a7:	e8 74 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    85ac:	48 89 c7             	mov    %rax,%rdi
    85af:	e8 1c bf ff ff       	call   44d0 <fwp_rc_fresh>
    85b4:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    85bb:	00 
    85bc:	bf 01 00 00 00       	mov    $0x1,%edi
    85c1:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    85c8:	00 
    85c9:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    85d0:	00 
    85d1:	e8 4a c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    85d6:	48 89 c7             	mov    %rax,%rdi
    85d9:	e8 f2 be ff ff       	call   44d0 <fwp_rc_fresh>
    85de:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    85e5:	00 
    85e6:	bf 01 00 00 00       	mov    $0x1,%edi
    85eb:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    85f2:	00 
    85f3:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    85fa:	00 
    85fb:	e8 20 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8600:	48 89 c7             	mov    %rax,%rdi
    8603:	e8 c8 be ff ff       	call   44d0 <fwp_rc_fresh>
    8608:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    860f:	00 
    8610:	bf 01 00 00 00       	mov    $0x1,%edi
    8615:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    861c:	00 
    861d:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    8624:	00 
    8625:	e8 f6 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    862a:	48 89 c7             	mov    %rax,%rdi
    862d:	e8 9e be ff ff       	call   44d0 <fwp_rc_fresh>
    8632:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    8639:	00 
    863a:	bf 01 00 00 00       	mov    $0x1,%edi
    863f:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    8646:	00 
    8647:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    864e:	00 
    864f:	e8 cc c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8654:	48 89 c7             	mov    %rax,%rdi
    8657:	e8 74 be ff ff       	call   44d0 <fwp_rc_fresh>
    865c:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    8663:	00 
    8664:	bf 01 00 00 00       	mov    $0x1,%edi
    8669:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    8670:	00 
    8671:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    8678:	00 
    8679:	e8 a2 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    867e:	48 89 c7             	mov    %rax,%rdi
    8681:	e8 4a be ff ff       	call   44d0 <fwp_rc_fresh>
    8686:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    868d:	00 
    868e:	bf 01 00 00 00       	mov    $0x1,%edi
    8693:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    869a:	00 
    869b:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    86a2:	00 
    86a3:	e8 78 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    86a8:	48 89 c7             	mov    %rax,%rdi
    86ab:	e8 20 be ff ff       	call   44d0 <fwp_rc_fresh>
    86b0:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    86b7:	00 
    86b8:	bf 01 00 00 00       	mov    $0x1,%edi
    86bd:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    86c4:	00 
    86c5:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    86cc:	00 
    86cd:	e8 4e c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    86d2:	48 89 c7             	mov    %rax,%rdi
    86d5:	e8 f6 bd ff ff       	call   44d0 <fwp_rc_fresh>
    86da:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    86e1:	00 
    86e2:	bf 01 00 00 00       	mov    $0x1,%edi
    86e7:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    86ee:	00 
    86ef:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    86f6:	00 
    86f7:	e8 24 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    86fc:	48 89 c7             	mov    %rax,%rdi
    86ff:	e8 cc bd ff ff       	call   44d0 <fwp_rc_fresh>
    8704:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    870b:	00 
    870c:	bf 01 00 00 00       	mov    $0x1,%edi
    8711:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    8718:	00 
    8719:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    8720:	00 
    8721:	e8 fa bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8726:	48 89 c7             	mov    %rax,%rdi
    8729:	e8 a2 bd ff ff       	call   44d0 <fwp_rc_fresh>
    872e:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    8735:	00 
    8736:	bf 01 00 00 00       	mov    $0x1,%edi
    873b:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    8742:	00 
    8743:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    874a:	00 
    874b:	e8 d0 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8750:	48 89 c7             	mov    %rax,%rdi
    8753:	e8 78 bd ff ff       	call   44d0 <fwp_rc_fresh>
    8758:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    875f:	00 
    8760:	bf 01 00 00 00       	mov    $0x1,%edi
    8765:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    876c:	00 
    876d:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    8774:	00 
    8775:	e8 a6 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    877a:	48 89 c7             	mov    %rax,%rdi
    877d:	e8 4e bd ff ff       	call   44d0 <fwp_rc_fresh>
    8782:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    8789:	00 
    878a:	bf 01 00 00 00       	mov    $0x1,%edi
    878f:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    8796:	00 
    8797:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    879e:	00 
    879f:	e8 7c bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    87a4:	48 89 c7             	mov    %rax,%rdi
    87a7:	e8 24 bd ff ff       	call   44d0 <fwp_rc_fresh>
    87ac:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    87b3:	00 
    87b4:	bf 01 00 00 00       	mov    $0x1,%edi
    87b9:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    87c0:	00 
    87c1:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    87c8:	00 
    87c9:	e8 52 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    87ce:	48 89 c7             	mov    %rax,%rdi
    87d1:	e8 fa bc ff ff       	call   44d0 <fwp_rc_fresh>
    87d6:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    87dd:	00 
    87de:	bf 01 00 00 00       	mov    $0x1,%edi
    87e3:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    87ea:	00 
    87eb:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    87f2:	00 
    87f3:	e8 28 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    87f8:	48 89 c7             	mov    %rax,%rdi
    87fb:	e8 d0 bc ff ff       	call   44d0 <fwp_rc_fresh>
    8800:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    8807:	00 
    8808:	bf 01 00 00 00       	mov    $0x1,%edi
    880d:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    8814:	00 
    8815:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    881c:	00 
    881d:	e8 fe be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8822:	48 89 c7             	mov    %rax,%rdi
    8825:	e8 a6 bc ff ff       	call   44d0 <fwp_rc_fresh>
    882a:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    8831:	00 
    8832:	bf 01 00 00 00       	mov    $0x1,%edi
    8837:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    883e:	00 
    883f:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    8846:	00 
    8847:	e8 d4 be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    884c:	48 89 c7             	mov    %rax,%rdi
    884f:	e8 7c bc ff ff       	call   44d0 <fwp_rc_fresh>
    8854:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    885b:	00 
    885c:	bf 01 00 00 00       	mov    $0x1,%edi
    8861:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    8868:	00 
    8869:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    8870:	00 
    8871:	e8 aa be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8876:	48 8b 15 9b 62 01 00 	mov    0x1629b(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    887d:	49 89 c5             	mov    %rax,%r13
    8880:	48 2b 05 69 62 01 00 	sub    0x16269(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8887:	48 c1 e2 10          	shl    $0x10,%rdx
    888b:	48 39 d0             	cmp    %rdx,%rax
    888e:	73 59                	jae    88e9 <f0+0x1319>
    8890:	48 89 c2             	mov    %rax,%rdx
    8893:	48 c1 ea 10          	shr    $0x10,%rdx
    8897:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    889b:	48 8b 15 96 62 01 00 	mov    0x16296(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    88a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    88aa:	4d 85 e4             	test   %r12,%r12
    88ad:	74 3a                	je     88e9 <f0+0x1319>
    88af:	0f b6 0a             	movzbl (%rdx),%ecx
    88b2:	80 f9 02             	cmp    $0x2,%cl
    88b5:	0f 84 75 16 00 00    	je     9f30 <f0+0x2960>
    88bb:	80 f9 01             	cmp    $0x1,%cl
    88be:	75 29                	jne    88e9 <f0+0x1319>
    88c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88c3:	0f b7 c0             	movzwl %ax,%eax
    88c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88c9:	48 0f af c1          	imul   %rcx,%rax
    88cd:	48 c1 e8 20          	shr    $0x20,%rax
    88d1:	48 39 d0             	cmp    %rdx,%rax
    88d4:	73 13                	jae    88e9 <f0+0x1319>
    88d6:	49 01 c4             	add    %rax,%r12
    88d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    88de:	0f 84 2b 18 00 00    	je     a10f <f0+0x2b3f>
    88e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    88e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    88f0:	00 f0 3f 
    88f3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    88fa:	00 
    88fb:	bf 01 00 00 00       	mov    $0x1,%edi
    8900:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    8907:	00 
    8908:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    890f:	00 
    8910:	e8 0b be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8915:	48 8b 15 fc 61 01 00 	mov    0x161fc(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    891c:	49 89 c5             	mov    %rax,%r13
    891f:	48 2b 05 ca 61 01 00 	sub    0x161ca(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8926:	48 c1 e2 10          	shl    $0x10,%rdx
    892a:	48 39 d0             	cmp    %rdx,%rax
    892d:	73 59                	jae    8988 <f0+0x13b8>
    892f:	48 89 c2             	mov    %rax,%rdx
    8932:	48 c1 ea 10          	shr    $0x10,%rdx
    8936:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    893a:	48 8b 15 f7 61 01 00 	mov    0x161f7(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8941:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8945:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8949:	4d 85 e4             	test   %r12,%r12
    894c:	74 3a                	je     8988 <f0+0x13b8>
    894e:	0f b6 0a             	movzbl (%rdx),%ecx
    8951:	80 f9 02             	cmp    $0x2,%cl
    8954:	0f 84 c6 15 00 00    	je     9f20 <f0+0x2950>
    895a:	80 f9 01             	cmp    $0x1,%cl
    895d:	75 29                	jne    8988 <f0+0x13b8>
    895f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8962:	0f b7 c0             	movzwl %ax,%eax
    8965:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8968:	48 0f af c1          	imul   %rcx,%rax
    896c:	48 c1 e8 20          	shr    $0x20,%rax
    8970:	48 39 d0             	cmp    %rdx,%rax
    8973:	73 13                	jae    8988 <f0+0x13b8>
    8975:	49 01 c4             	add    %rax,%r12
    8978:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    897d:	0f 84 99 17 00 00    	je     a11c <f0+0x2b4c>
    8983:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8988:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    898f:	33 f3 bf 
    8992:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    8999:	00 
    899a:	bf 01 00 00 00       	mov    $0x1,%edi
    899f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    89a6:	00 
    89a7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    89ae:	00 
    89af:	e8 6c bd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    89b4:	48 8b 15 5d 61 01 00 	mov    0x1615d(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    89bb:	49 89 c5             	mov    %rax,%r13
    89be:	48 2b 05 2b 61 01 00 	sub    0x1612b(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    89c5:	48 c1 e2 10          	shl    $0x10,%rdx
    89c9:	48 39 d0             	cmp    %rdx,%rax
    89cc:	73 59                	jae    8a27 <f0+0x1457>
    89ce:	48 89 c2             	mov    %rax,%rdx
    89d1:	48 c1 ea 10          	shr    $0x10,%rdx
    89d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89d9:	48 8b 15 58 61 01 00 	mov    0x16158(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    89e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89e4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    89e8:	4d 85 e4             	test   %r12,%r12
    89eb:	74 3a                	je     8a27 <f0+0x1457>
    89ed:	0f b6 0a             	movzbl (%rdx),%ecx
    89f0:	80 f9 02             	cmp    $0x2,%cl
    89f3:	0f 84 17 15 00 00    	je     9f10 <f0+0x2940>
    89f9:	80 f9 01             	cmp    $0x1,%cl
    89fc:	75 29                	jne    8a27 <f0+0x1457>
    89fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a01:	0f b7 c0             	movzwl %ax,%eax
    8a04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a07:	48 0f af c1          	imul   %rcx,%rax
    8a0b:	48 c1 e8 20          	shr    $0x20,%rax
    8a0f:	48 39 d0             	cmp    %rdx,%rax
    8a12:	73 13                	jae    8a27 <f0+0x1457>
    8a14:	49 01 c4             	add    %rax,%r12
    8a17:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a1c:	0f 84 07 17 00 00    	je     a129 <f0+0x2b59>
    8a22:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8a27:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8a2e:	00 f0 3f 
    8a31:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    8a38:	00 
    8a39:	bf 01 00 00 00       	mov    $0x1,%edi
    8a3e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    8a45:	00 
    8a46:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    8a4d:	00 
    8a4e:	e8 cd bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8a53:	48 8b 15 be 60 01 00 	mov    0x160be(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8a5a:	49 89 c5             	mov    %rax,%r13
    8a5d:	48 2b 05 8c 60 01 00 	sub    0x1608c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8a64:	48 c1 e2 10          	shl    $0x10,%rdx
    8a68:	48 39 d0             	cmp    %rdx,%rax
    8a6b:	73 59                	jae    8ac6 <f0+0x14f6>
    8a6d:	48 89 c2             	mov    %rax,%rdx
    8a70:	48 c1 ea 10          	shr    $0x10,%rdx
    8a74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a78:	48 8b 15 b9 60 01 00 	mov    0x160b9(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8a7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a83:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8a87:	4d 85 e4             	test   %r12,%r12
    8a8a:	74 3a                	je     8ac6 <f0+0x14f6>
    8a8c:	0f b6 0a             	movzbl (%rdx),%ecx
    8a8f:	80 f9 02             	cmp    $0x2,%cl
    8a92:	0f 84 28 15 00 00    	je     9fc0 <f0+0x29f0>
    8a98:	80 f9 01             	cmp    $0x1,%cl
    8a9b:	75 29                	jne    8ac6 <f0+0x14f6>
    8a9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8aa0:	0f b7 c0             	movzwl %ax,%eax
    8aa3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8aa6:	48 0f af c1          	imul   %rcx,%rax
    8aaa:	48 c1 e8 20          	shr    $0x20,%rax
    8aae:	48 39 d0             	cmp    %rdx,%rax
    8ab1:	73 13                	jae    8ac6 <f0+0x14f6>
    8ab3:	49 01 c4             	add    %rax,%r12
    8ab6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8abb:	0f 84 75 16 00 00    	je     a136 <f0+0x2b66>
    8ac1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8ac6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8acd:	33 f3 bf 
    8ad0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    8ad7:	00 
    8ad8:	bf 01 00 00 00       	mov    $0x1,%edi
    8add:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    8ae4:	00 
    8ae5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    8aec:	00 
    8aed:	e8 2e bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8af2:	48 8b 15 1f 60 01 00 	mov    0x1601f(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8af9:	49 89 c5             	mov    %rax,%r13
    8afc:	48 2b 05 ed 5f 01 00 	sub    0x15fed(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8b03:	48 c1 e2 10          	shl    $0x10,%rdx
    8b07:	48 39 d0             	cmp    %rdx,%rax
    8b0a:	73 59                	jae    8b65 <f0+0x1595>
    8b0c:	48 89 c2             	mov    %rax,%rdx
    8b0f:	48 c1 ea 10          	shr    $0x10,%rdx
    8b13:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b17:	48 8b 15 1a 60 01 00 	mov    0x1601a(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8b1e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b22:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b26:	4d 85 e4             	test   %r12,%r12
    8b29:	74 3a                	je     8b65 <f0+0x1595>
    8b2b:	0f b6 0a             	movzbl (%rdx),%ecx
    8b2e:	80 f9 02             	cmp    $0x2,%cl
    8b31:	0f 84 79 14 00 00    	je     9fb0 <f0+0x29e0>
    8b37:	80 f9 01             	cmp    $0x1,%cl
    8b3a:	75 29                	jne    8b65 <f0+0x1595>
    8b3c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b3f:	0f b7 c0             	movzwl %ax,%eax
    8b42:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b45:	48 0f af c1          	imul   %rcx,%rax
    8b49:	48 c1 e8 20          	shr    $0x20,%rax
    8b4d:	48 39 d0             	cmp    %rdx,%rax
    8b50:	73 13                	jae    8b65 <f0+0x1595>
    8b52:	49 01 c4             	add    %rax,%r12
    8b55:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b5a:	0f 84 e3 15 00 00    	je     a143 <f0+0x2b73>
    8b60:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8b65:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8b6c:	00 f0 3f 
    8b6f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    8b76:	00 
    8b77:	bf 01 00 00 00       	mov    $0x1,%edi
    8b7c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    8b83:	00 
    8b84:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    8b8b:	00 
    8b8c:	e8 8f bb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8b91:	48 8b 15 80 5f 01 00 	mov    0x15f80(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8b98:	49 89 c5             	mov    %rax,%r13
    8b9b:	48 2b 05 4e 5f 01 00 	sub    0x15f4e(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8ba2:	48 c1 e2 10          	shl    $0x10,%rdx
    8ba6:	48 39 d0             	cmp    %rdx,%rax
    8ba9:	73 59                	jae    8c04 <f0+0x1634>
    8bab:	48 89 c2             	mov    %rax,%rdx
    8bae:	48 c1 ea 10          	shr    $0x10,%rdx
    8bb2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bb6:	48 8b 15 7b 5f 01 00 	mov    0x15f7b(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8bbd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8bc1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8bc5:	4d 85 e4             	test   %r12,%r12
    8bc8:	74 3a                	je     8c04 <f0+0x1634>
    8bca:	0f b6 0a             	movzbl (%rdx),%ecx
    8bcd:	80 f9 02             	cmp    $0x2,%cl
    8bd0:	0f 84 ca 13 00 00    	je     9fa0 <f0+0x29d0>
    8bd6:	80 f9 01             	cmp    $0x1,%cl
    8bd9:	75 29                	jne    8c04 <f0+0x1634>
    8bdb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8bde:	0f b7 c0             	movzwl %ax,%eax
    8be1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8be4:	48 0f af c1          	imul   %rcx,%rax
    8be8:	48 c1 e8 20          	shr    $0x20,%rax
    8bec:	48 39 d0             	cmp    %rdx,%rax
    8bef:	73 13                	jae    8c04 <f0+0x1634>
    8bf1:	49 01 c4             	add    %rax,%r12
    8bf4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8bf9:	0f 84 51 15 00 00    	je     a150 <f0+0x2b80>
    8bff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c04:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8c0b:	33 f3 bf 
    8c0e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    8c15:	00 
    8c16:	bf 01 00 00 00       	mov    $0x1,%edi
    8c1b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    8c22:	00 
    8c23:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    8c2a:	00 
    8c2b:	e8 f0 ba ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8c30:	48 8b 15 e1 5e 01 00 	mov    0x15ee1(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8c37:	49 89 c5             	mov    %rax,%r13
    8c3a:	48 2b 05 af 5e 01 00 	sub    0x15eaf(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8c41:	48 c1 e2 10          	shl    $0x10,%rdx
    8c45:	48 39 d0             	cmp    %rdx,%rax
    8c48:	73 59                	jae    8ca3 <f0+0x16d3>
    8c4a:	48 89 c2             	mov    %rax,%rdx
    8c4d:	48 c1 ea 10          	shr    $0x10,%rdx
    8c51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c55:	48 8b 15 dc 5e 01 00 	mov    0x15edc(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8c5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c60:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c64:	4d 85 e4             	test   %r12,%r12
    8c67:	74 3a                	je     8ca3 <f0+0x16d3>
    8c69:	0f b6 0a             	movzbl (%rdx),%ecx
    8c6c:	80 f9 02             	cmp    $0x2,%cl
    8c6f:	0f 84 1b 13 00 00    	je     9f90 <f0+0x29c0>
    8c75:	80 f9 01             	cmp    $0x1,%cl
    8c78:	75 29                	jne    8ca3 <f0+0x16d3>
    8c7a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c7d:	0f b7 c0             	movzwl %ax,%eax
    8c80:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c83:	48 0f af c1          	imul   %rcx,%rax
    8c87:	48 c1 e8 20          	shr    $0x20,%rax
    8c8b:	48 39 d0             	cmp    %rdx,%rax
    8c8e:	73 13                	jae    8ca3 <f0+0x16d3>
    8c90:	49 01 c4             	add    %rax,%r12
    8c93:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c98:	0f 84 bf 14 00 00    	je     a15d <f0+0x2b8d>
    8c9e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8ca3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8caa:	00 f0 3f 
    8cad:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    8cb4:	00 
    8cb5:	bf 01 00 00 00       	mov    $0x1,%edi
    8cba:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    8cc1:	00 
    8cc2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    8cc9:	00 
    8cca:	e8 51 ba ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8ccf:	48 8b 15 42 5e 01 00 	mov    0x15e42(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8cd6:	49 89 c5             	mov    %rax,%r13
    8cd9:	48 2b 05 10 5e 01 00 	sub    0x15e10(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8ce0:	48 c1 e2 10          	shl    $0x10,%rdx
    8ce4:	48 39 d0             	cmp    %rdx,%rax
    8ce7:	73 59                	jae    8d42 <f0+0x1772>
    8ce9:	48 89 c2             	mov    %rax,%rdx
    8cec:	48 c1 ea 10          	shr    $0x10,%rdx
    8cf0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cf4:	48 8b 15 3d 5e 01 00 	mov    0x15e3d(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8cfb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8cff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d03:	4d 85 e4             	test   %r12,%r12
    8d06:	74 3a                	je     8d42 <f0+0x1772>
    8d08:	0f b6 0a             	movzbl (%rdx),%ecx
    8d0b:	80 f9 02             	cmp    $0x2,%cl
    8d0e:	0f 84 6c 12 00 00    	je     9f80 <f0+0x29b0>
    8d14:	80 f9 01             	cmp    $0x1,%cl
    8d17:	75 29                	jne    8d42 <f0+0x1772>
    8d19:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d1c:	0f b7 c0             	movzwl %ax,%eax
    8d1f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d22:	48 0f af c1          	imul   %rcx,%rax
    8d26:	48 c1 e8 20          	shr    $0x20,%rax
    8d2a:	48 39 d0             	cmp    %rdx,%rax
    8d2d:	73 13                	jae    8d42 <f0+0x1772>
    8d2f:	49 01 c4             	add    %rax,%r12
    8d32:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d37:	0f 84 2d 14 00 00    	je     a16a <f0+0x2b9a>
    8d3d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d42:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8d49:	33 f3 bf 
    8d4c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    8d53:	00 
    8d54:	bf 01 00 00 00       	mov    $0x1,%edi
    8d59:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    8d60:	00 
    8d61:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    8d68:	00 
    8d69:	e8 b2 b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8d6e:	48 8b 15 a3 5d 01 00 	mov    0x15da3(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8d75:	49 89 c5             	mov    %rax,%r13
    8d78:	48 2b 05 71 5d 01 00 	sub    0x15d71(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8d7f:	48 c1 e2 10          	shl    $0x10,%rdx
    8d83:	48 39 d0             	cmp    %rdx,%rax
    8d86:	73 59                	jae    8de1 <f0+0x1811>
    8d88:	48 89 c2             	mov    %rax,%rdx
    8d8b:	48 c1 ea 10          	shr    $0x10,%rdx
    8d8f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d93:	48 8b 15 9e 5d 01 00 	mov    0x15d9e(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8d9a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d9e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8da2:	4d 85 e4             	test   %r12,%r12
    8da5:	74 3a                	je     8de1 <f0+0x1811>
    8da7:	0f b6 0a             	movzbl (%rdx),%ecx
    8daa:	80 f9 02             	cmp    $0x2,%cl
    8dad:	0f 84 bd 11 00 00    	je     9f70 <f0+0x29a0>
    8db3:	80 f9 01             	cmp    $0x1,%cl
    8db6:	75 29                	jne    8de1 <f0+0x1811>
    8db8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8dbb:	0f b7 c0             	movzwl %ax,%eax
    8dbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8dc1:	48 0f af c1          	imul   %rcx,%rax
    8dc5:	48 c1 e8 20          	shr    $0x20,%rax
    8dc9:	48 39 d0             	cmp    %rdx,%rax
    8dcc:	73 13                	jae    8de1 <f0+0x1811>
    8dce:	49 01 c4             	add    %rax,%r12
    8dd1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8dd6:	0f 84 9b 13 00 00    	je     a177 <f0+0x2ba7>
    8ddc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8de1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8de8:	00 f0 3f 
    8deb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    8df2:	00 
    8df3:	bf 01 00 00 00       	mov    $0x1,%edi
    8df8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    8dff:	00 
    8e00:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    8e07:	00 
    8e08:	e8 13 b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8e0d:	48 8b 15 04 5d 01 00 	mov    0x15d04(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8e14:	49 89 c5             	mov    %rax,%r13
    8e17:	48 2b 05 d2 5c 01 00 	sub    0x15cd2(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8e1e:	48 c1 e2 10          	shl    $0x10,%rdx
    8e22:	48 39 d0             	cmp    %rdx,%rax
    8e25:	73 59                	jae    8e80 <f0+0x18b0>
    8e27:	48 89 c2             	mov    %rax,%rdx
    8e2a:	48 c1 ea 10          	shr    $0x10,%rdx
    8e2e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e32:	48 8b 15 ff 5c 01 00 	mov    0x15cff(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8e39:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e3d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e41:	4d 85 e4             	test   %r12,%r12
    8e44:	74 3a                	je     8e80 <f0+0x18b0>
    8e46:	0f b6 0a             	movzbl (%rdx),%ecx
    8e49:	80 f9 02             	cmp    $0x2,%cl
    8e4c:	0f 84 0e 11 00 00    	je     9f60 <f0+0x2990>
    8e52:	80 f9 01             	cmp    $0x1,%cl
    8e55:	75 29                	jne    8e80 <f0+0x18b0>
    8e57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e5a:	0f b7 c0             	movzwl %ax,%eax
    8e5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e60:	48 0f af c1          	imul   %rcx,%rax
    8e64:	48 c1 e8 20          	shr    $0x20,%rax
    8e68:	48 39 d0             	cmp    %rdx,%rax
    8e6b:	73 13                	jae    8e80 <f0+0x18b0>
    8e6d:	49 01 c4             	add    %rax,%r12
    8e70:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e75:	0f 84 09 13 00 00    	je     a184 <f0+0x2bb4>
    8e7b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e80:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8e87:	33 f3 bf 
    8e8a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    8e91:	00 
    8e92:	bf 01 00 00 00       	mov    $0x1,%edi
    8e97:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    8e9e:	00 
    8e9f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    8ea6:	00 
    8ea7:	e8 74 b8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8eac:	48 8b 15 65 5c 01 00 	mov    0x15c65(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8eb3:	49 89 c5             	mov    %rax,%r13
    8eb6:	48 2b 05 33 5c 01 00 	sub    0x15c33(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8ebd:	48 c1 e2 10          	shl    $0x10,%rdx
    8ec1:	48 39 d0             	cmp    %rdx,%rax
    8ec4:	73 59                	jae    8f1f <f0+0x194f>
    8ec6:	48 89 c2             	mov    %rax,%rdx
    8ec9:	48 c1 ea 10          	shr    $0x10,%rdx
    8ecd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ed1:	48 8b 15 60 5c 01 00 	mov    0x15c60(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8ed8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8edc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ee0:	4d 85 e4             	test   %r12,%r12
    8ee3:	74 3a                	je     8f1f <f0+0x194f>
    8ee5:	0f b6 0a             	movzbl (%rdx),%ecx
    8ee8:	80 f9 02             	cmp    $0x2,%cl
    8eeb:	0f 84 5f 10 00 00    	je     9f50 <f0+0x2980>
    8ef1:	80 f9 01             	cmp    $0x1,%cl
    8ef4:	75 29                	jne    8f1f <f0+0x194f>
    8ef6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ef9:	0f b7 c0             	movzwl %ax,%eax
    8efc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8eff:	48 0f af c1          	imul   %rcx,%rax
    8f03:	48 c1 e8 20          	shr    $0x20,%rax
    8f07:	48 39 d0             	cmp    %rdx,%rax
    8f0a:	73 13                	jae    8f1f <f0+0x194f>
    8f0c:	49 01 c4             	add    %rax,%r12
    8f0f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f14:	0f 84 77 12 00 00    	je     a191 <f0+0x2bc1>
    8f1a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f1f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8f26:	00 f0 3f 
    8f29:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    8f30:	00 
    8f31:	bf 01 00 00 00       	mov    $0x1,%edi
    8f36:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    8f3d:	00 
    8f3e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    8f45:	00 
    8f46:	e8 d5 b7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8f4b:	48 8b 15 c6 5b 01 00 	mov    0x15bc6(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8f52:	49 89 c5             	mov    %rax,%r13
    8f55:	48 2b 05 94 5b 01 00 	sub    0x15b94(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8f5c:	48 c1 e2 10          	shl    $0x10,%rdx
    8f60:	48 39 d0             	cmp    %rdx,%rax
    8f63:	73 59                	jae    8fbe <f0+0x19ee>
    8f65:	48 89 c2             	mov    %rax,%rdx
    8f68:	48 c1 ea 10          	shr    $0x10,%rdx
    8f6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f70:	48 8b 15 c1 5b 01 00 	mov    0x15bc1(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8f77:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f7b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f7f:	4d 85 e4             	test   %r12,%r12
    8f82:	74 3a                	je     8fbe <f0+0x19ee>
    8f84:	0f b6 0a             	movzbl (%rdx),%ecx
    8f87:	80 f9 02             	cmp    $0x2,%cl
    8f8a:	0f 84 40 0f 00 00    	je     9ed0 <f0+0x2900>
    8f90:	80 f9 01             	cmp    $0x1,%cl
    8f93:	75 29                	jne    8fbe <f0+0x19ee>
    8f95:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f98:	0f b7 c0             	movzwl %ax,%eax
    8f9b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f9e:	48 0f af c1          	imul   %rcx,%rax
    8fa2:	48 c1 e8 20          	shr    $0x20,%rax
    8fa6:	48 39 d0             	cmp    %rdx,%rax
    8fa9:	73 13                	jae    8fbe <f0+0x19ee>
    8fab:	49 01 c4             	add    %rax,%r12
    8fae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8fb3:	0f 84 e5 11 00 00    	je     a19e <f0+0x2bce>
    8fb9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8fbe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8fc5:	33 f3 bf 
    8fc8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    8fcf:	00 
    8fd0:	bf 01 00 00 00       	mov    $0x1,%edi
    8fd5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    8fdc:	00 
    8fdd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    8fe4:	00 
    8fe5:	e8 36 b7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8fea:	48 8b 15 27 5b 01 00 	mov    0x15b27(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8ff1:	49 89 c5             	mov    %rax,%r13
    8ff4:	48 2b 05 f5 5a 01 00 	sub    0x15af5(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8ffb:	48 c1 e2 10          	shl    $0x10,%rdx
    8fff:	48 39 d0             	cmp    %rdx,%rax
    9002:	73 59                	jae    905d <f0+0x1a8d>
    9004:	48 89 c2             	mov    %rax,%rdx
    9007:	48 c1 ea 10          	shr    $0x10,%rdx
    900b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    900f:	48 8b 15 22 5b 01 00 	mov    0x15b22(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9016:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    901a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    901e:	4d 85 e4             	test   %r12,%r12
    9021:	74 3a                	je     905d <f0+0x1a8d>
    9023:	0f b6 0a             	movzbl (%rdx),%ecx
    9026:	80 f9 02             	cmp    $0x2,%cl
    9029:	0f 84 91 0e 00 00    	je     9ec0 <f0+0x28f0>
    902f:	80 f9 01             	cmp    $0x1,%cl
    9032:	75 29                	jne    905d <f0+0x1a8d>
    9034:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9037:	0f b7 c0             	movzwl %ax,%eax
    903a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    903d:	48 0f af c1          	imul   %rcx,%rax
    9041:	48 c1 e8 20          	shr    $0x20,%rax
    9045:	48 39 d0             	cmp    %rdx,%rax
    9048:	73 13                	jae    905d <f0+0x1a8d>
    904a:	49 01 c4             	add    %rax,%r12
    904d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9052:	0f 84 53 11 00 00    	je     a1ab <f0+0x2bdb>
    9058:	41 c6 04 24 01       	movb   $0x1,(%r12)
    905d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9064:	00 f0 3f 
    9067:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    906e:	00 
    906f:	bf 01 00 00 00       	mov    $0x1,%edi
    9074:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    907b:	00 
    907c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    9083:	00 
    9084:	e8 97 b6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9089:	48 8b 15 88 5a 01 00 	mov    0x15a88(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9090:	49 89 c5             	mov    %rax,%r13
    9093:	48 2b 05 56 5a 01 00 	sub    0x15a56(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    909a:	48 c1 e2 10          	shl    $0x10,%rdx
    909e:	48 39 d0             	cmp    %rdx,%rax
    90a1:	73 59                	jae    90fc <f0+0x1b2c>
    90a3:	48 89 c2             	mov    %rax,%rdx
    90a6:	48 c1 ea 10          	shr    $0x10,%rdx
    90aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90ae:	48 8b 15 83 5a 01 00 	mov    0x15a83(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    90b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    90bd:	4d 85 e4             	test   %r12,%r12
    90c0:	74 3a                	je     90fc <f0+0x1b2c>
    90c2:	0f b6 0a             	movzbl (%rdx),%ecx
    90c5:	80 f9 02             	cmp    $0x2,%cl
    90c8:	0f 84 e2 0d 00 00    	je     9eb0 <f0+0x28e0>
    90ce:	80 f9 01             	cmp    $0x1,%cl
    90d1:	75 29                	jne    90fc <f0+0x1b2c>
    90d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90d6:	0f b7 c0             	movzwl %ax,%eax
    90d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90dc:	48 0f af c1          	imul   %rcx,%rax
    90e0:	48 c1 e8 20          	shr    $0x20,%rax
    90e4:	48 39 d0             	cmp    %rdx,%rax
    90e7:	73 13                	jae    90fc <f0+0x1b2c>
    90e9:	49 01 c4             	add    %rax,%r12
    90ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    90f1:	0f 84 c1 10 00 00    	je     a1b8 <f0+0x2be8>
    90f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    90fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9103:	33 f3 bf 
    9106:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    910d:	00 
    910e:	bf 01 00 00 00       	mov    $0x1,%edi
    9113:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    911a:	00 
    911b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    9122:	00 
    9123:	e8 f8 b5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9128:	48 8b 15 e9 59 01 00 	mov    0x159e9(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    912f:	49 89 c5             	mov    %rax,%r13
    9132:	48 2b 05 b7 59 01 00 	sub    0x159b7(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9139:	48 c1 e2 10          	shl    $0x10,%rdx
    913d:	48 39 d0             	cmp    %rdx,%rax
    9140:	73 59                	jae    919b <f0+0x1bcb>
    9142:	48 89 c2             	mov    %rax,%rdx
    9145:	48 c1 ea 10          	shr    $0x10,%rdx
    9149:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    914d:	48 8b 15 e4 59 01 00 	mov    0x159e4(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9154:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9158:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    915c:	4d 85 e4             	test   %r12,%r12
    915f:	74 3a                	je     919b <f0+0x1bcb>
    9161:	0f b6 0a             	movzbl (%rdx),%ecx
    9164:	80 f9 02             	cmp    $0x2,%cl
    9167:	0f 84 33 0d 00 00    	je     9ea0 <f0+0x28d0>
    916d:	80 f9 01             	cmp    $0x1,%cl
    9170:	75 29                	jne    919b <f0+0x1bcb>
    9172:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9175:	0f b7 c0             	movzwl %ax,%eax
    9178:	8b 52 1c             	mov    0x1c(%rdx),%edx
    917b:	48 0f af c1          	imul   %rcx,%rax
    917f:	48 c1 e8 20          	shr    $0x20,%rax
    9183:	48 39 d0             	cmp    %rdx,%rax
    9186:	73 13                	jae    919b <f0+0x1bcb>
    9188:	49 01 c4             	add    %rax,%r12
    918b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9190:	0f 84 2f 10 00 00    	je     a1c5 <f0+0x2bf5>
    9196:	41 c6 04 24 01       	movb   $0x1,(%r12)
    919b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    91a2:	00 f0 3f 
    91a5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    91ac:	00 
    91ad:	bf 01 00 00 00       	mov    $0x1,%edi
    91b2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    91b9:	00 
    91ba:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    91c1:	00 
    91c2:	e8 59 b5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    91c7:	48 8b 15 4a 59 01 00 	mov    0x1594a(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    91ce:	49 89 c5             	mov    %rax,%r13
    91d1:	48 2b 05 18 59 01 00 	sub    0x15918(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    91d8:	48 c1 e2 10          	shl    $0x10,%rdx
    91dc:	48 39 d0             	cmp    %rdx,%rax
    91df:	73 59                	jae    923a <f0+0x1c6a>
    91e1:	48 89 c2             	mov    %rax,%rdx
    91e4:	48 c1 ea 10          	shr    $0x10,%rdx
    91e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    91ec:	48 8b 15 45 59 01 00 	mov    0x15945(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    91f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    91f7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    91fb:	4d 85 e4             	test   %r12,%r12
    91fe:	74 3a                	je     923a <f0+0x1c6a>
    9200:	0f b6 0a             	movzbl (%rdx),%ecx
    9203:	80 f9 02             	cmp    $0x2,%cl
    9206:	0f 84 84 0c 00 00    	je     9e90 <f0+0x28c0>
    920c:	80 f9 01             	cmp    $0x1,%cl
    920f:	75 29                	jne    923a <f0+0x1c6a>
    9211:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9214:	0f b7 c0             	movzwl %ax,%eax
    9217:	8b 52 1c             	mov    0x1c(%rdx),%edx
    921a:	48 0f af c1          	imul   %rcx,%rax
    921e:	48 c1 e8 20          	shr    $0x20,%rax
    9222:	48 39 d0             	cmp    %rdx,%rax
    9225:	73 13                	jae    923a <f0+0x1c6a>
    9227:	49 01 c4             	add    %rax,%r12
    922a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    922f:	0f 84 9d 0f 00 00    	je     a1d2 <f0+0x2c02>
    9235:	41 c6 04 24 01       	movb   $0x1,(%r12)
    923a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9241:	33 f3 bf 
    9244:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    924b:	00 
    924c:	bf 01 00 00 00       	mov    $0x1,%edi
    9251:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    9258:	00 
    9259:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    9260:	00 
    9261:	e8 ba b4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9266:	48 8b 15 ab 58 01 00 	mov    0x158ab(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    926d:	49 89 c5             	mov    %rax,%r13
    9270:	48 2b 05 79 58 01 00 	sub    0x15879(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9277:	48 c1 e2 10          	shl    $0x10,%rdx
    927b:	48 39 d0             	cmp    %rdx,%rax
    927e:	73 59                	jae    92d9 <f0+0x1d09>
    9280:	48 89 c2             	mov    %rax,%rdx
    9283:	48 c1 ea 10          	shr    $0x10,%rdx
    9287:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    928b:	48 8b 15 a6 58 01 00 	mov    0x158a6(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9292:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9296:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    929a:	4d 85 e4             	test   %r12,%r12
    929d:	74 3a                	je     92d9 <f0+0x1d09>
    929f:	0f b6 0a             	movzbl (%rdx),%ecx
    92a2:	80 f9 02             	cmp    $0x2,%cl
    92a5:	0f 84 d5 0b 00 00    	je     9e80 <f0+0x28b0>
    92ab:	80 f9 01             	cmp    $0x1,%cl
    92ae:	75 29                	jne    92d9 <f0+0x1d09>
    92b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92b3:	0f b7 c0             	movzwl %ax,%eax
    92b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92b9:	48 0f af c1          	imul   %rcx,%rax
    92bd:	48 c1 e8 20          	shr    $0x20,%rax
    92c1:	48 39 d0             	cmp    %rdx,%rax
    92c4:	73 13                	jae    92d9 <f0+0x1d09>
    92c6:	49 01 c4             	add    %rax,%r12
    92c9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    92ce:	0f 84 0b 0f 00 00    	je     a1df <f0+0x2c0f>
    92d4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    92d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    92e0:	00 f0 3f 
    92e3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    92ea:	00 
    92eb:	bf 01 00 00 00       	mov    $0x1,%edi
    92f0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    92f7:	00 
    92f8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    92ff:	00 
    9300:	e8 1b b4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9305:	48 8b 15 0c 58 01 00 	mov    0x1580c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    930c:	49 89 c5             	mov    %rax,%r13
    930f:	48 2b 05 da 57 01 00 	sub    0x157da(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9316:	48 c1 e2 10          	shl    $0x10,%rdx
    931a:	48 39 d0             	cmp    %rdx,%rax
    931d:	73 59                	jae    9378 <f0+0x1da8>
    931f:	48 89 c2             	mov    %rax,%rdx
    9322:	48 c1 ea 10          	shr    $0x10,%rdx
    9326:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    932a:	48 8b 15 07 58 01 00 	mov    0x15807(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9331:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9335:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9339:	4d 85 e4             	test   %r12,%r12
    933c:	74 3a                	je     9378 <f0+0x1da8>
    933e:	0f b6 0a             	movzbl (%rdx),%ecx
    9341:	80 f9 02             	cmp    $0x2,%cl
    9344:	0f 84 26 0b 00 00    	je     9e70 <f0+0x28a0>
    934a:	80 f9 01             	cmp    $0x1,%cl
    934d:	75 29                	jne    9378 <f0+0x1da8>
    934f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9352:	0f b7 c0             	movzwl %ax,%eax
    9355:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9358:	48 0f af c1          	imul   %rcx,%rax
    935c:	48 c1 e8 20          	shr    $0x20,%rax
    9360:	48 39 d0             	cmp    %rdx,%rax
    9363:	73 13                	jae    9378 <f0+0x1da8>
    9365:	49 01 c4             	add    %rax,%r12
    9368:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    936d:	0f 84 79 0e 00 00    	je     a1ec <f0+0x2c1c>
    9373:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9378:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    937f:	33 f3 bf 
    9382:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    9389:	00 
    938a:	bf 01 00 00 00       	mov    $0x1,%edi
    938f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    9396:	00 
    9397:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    939e:	00 
    939f:	e8 7c b3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    93a4:	48 8b 15 6d 57 01 00 	mov    0x1576d(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    93ab:	49 89 c5             	mov    %rax,%r13
    93ae:	48 2b 05 3b 57 01 00 	sub    0x1573b(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    93b5:	48 c1 e2 10          	shl    $0x10,%rdx
    93b9:	48 39 d0             	cmp    %rdx,%rax
    93bc:	73 59                	jae    9417 <f0+0x1e47>
    93be:	48 89 c2             	mov    %rax,%rdx
    93c1:	48 c1 ea 10          	shr    $0x10,%rdx
    93c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93c9:	48 8b 15 68 57 01 00 	mov    0x15768(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    93d0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93d4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    93d8:	4d 85 e4             	test   %r12,%r12
    93db:	74 3a                	je     9417 <f0+0x1e47>
    93dd:	0f b6 0a             	movzbl (%rdx),%ecx
    93e0:	80 f9 02             	cmp    $0x2,%cl
    93e3:	0f 84 77 0a 00 00    	je     9e60 <f0+0x2890>
    93e9:	80 f9 01             	cmp    $0x1,%cl
    93ec:	75 29                	jne    9417 <f0+0x1e47>
    93ee:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93f1:	0f b7 c0             	movzwl %ax,%eax
    93f4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93f7:	48 0f af c1          	imul   %rcx,%rax
    93fb:	48 c1 e8 20          	shr    $0x20,%rax
    93ff:	48 39 d0             	cmp    %rdx,%rax
    9402:	73 13                	jae    9417 <f0+0x1e47>
    9404:	49 01 c4             	add    %rax,%r12
    9407:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    940c:	0f 84 e7 0d 00 00    	je     a1f9 <f0+0x2c29>
    9412:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9417:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    941e:	00 f0 3f 
    9421:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    9428:	00 
    9429:	bf 01 00 00 00       	mov    $0x1,%edi
    942e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    9435:	00 
    9436:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    943d:	00 
    943e:	e8 dd b2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9443:	48 8b 15 ce 56 01 00 	mov    0x156ce(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    944a:	49 89 c5             	mov    %rax,%r13
    944d:	48 2b 05 9c 56 01 00 	sub    0x1569c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9454:	48 c1 e2 10          	shl    $0x10,%rdx
    9458:	48 39 d0             	cmp    %rdx,%rax
    945b:	73 59                	jae    94b6 <f0+0x1ee6>
    945d:	48 89 c2             	mov    %rax,%rdx
    9460:	48 c1 ea 10          	shr    $0x10,%rdx
    9464:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9468:	48 8b 15 c9 56 01 00 	mov    0x156c9(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    946f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9473:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9477:	4d 85 e4             	test   %r12,%r12
    947a:	74 3a                	je     94b6 <f0+0x1ee6>
    947c:	0f b6 0a             	movzbl (%rdx),%ecx
    947f:	80 f9 02             	cmp    $0x2,%cl
    9482:	0f 84 38 0c 00 00    	je     a0c0 <f0+0x2af0>
    9488:	80 f9 01             	cmp    $0x1,%cl
    948b:	75 29                	jne    94b6 <f0+0x1ee6>
    948d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9490:	0f b7 c0             	movzwl %ax,%eax
    9493:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9496:	48 0f af c1          	imul   %rcx,%rax
    949a:	48 c1 e8 20          	shr    $0x20,%rax
    949e:	48 39 d0             	cmp    %rdx,%rax
    94a1:	73 13                	jae    94b6 <f0+0x1ee6>
    94a3:	49 01 c4             	add    %rax,%r12
    94a6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    94ab:	0f 84 55 0d 00 00    	je     a206 <f0+0x2c36>
    94b1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    94b6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    94bd:	33 f3 bf 
    94c0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    94c7:	00 
    94c8:	bf 01 00 00 00       	mov    $0x1,%edi
    94cd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    94d4:	00 
    94d5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    94dc:	00 
    94dd:	e8 3e b2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    94e2:	48 8b 15 2f 56 01 00 	mov    0x1562f(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    94e9:	49 89 c5             	mov    %rax,%r13
    94ec:	48 2b 05 fd 55 01 00 	sub    0x155fd(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    94f3:	48 c1 e2 10          	shl    $0x10,%rdx
    94f7:	48 39 d0             	cmp    %rdx,%rax
    94fa:	73 59                	jae    9555 <f0+0x1f85>
    94fc:	48 89 c2             	mov    %rax,%rdx
    94ff:	48 c1 ea 10          	shr    $0x10,%rdx
    9503:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9507:	48 8b 15 2a 56 01 00 	mov    0x1562a(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    950e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9512:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9516:	4d 85 e4             	test   %r12,%r12
    9519:	74 3a                	je     9555 <f0+0x1f85>
    951b:	0f b6 0a             	movzbl (%rdx),%ecx
    951e:	80 f9 02             	cmp    $0x2,%cl
    9521:	0f 84 89 0b 00 00    	je     a0b0 <f0+0x2ae0>
    9527:	80 f9 01             	cmp    $0x1,%cl
    952a:	75 29                	jne    9555 <f0+0x1f85>
    952c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    952f:	0f b7 c0             	movzwl %ax,%eax
    9532:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9535:	48 0f af c1          	imul   %rcx,%rax
    9539:	48 c1 e8 20          	shr    $0x20,%rax
    953d:	48 39 d0             	cmp    %rdx,%rax
    9540:	73 13                	jae    9555 <f0+0x1f85>
    9542:	49 01 c4             	add    %rax,%r12
    9545:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    954a:	0f 84 c3 0c 00 00    	je     a213 <f0+0x2c43>
    9550:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9555:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    955c:	00 f0 3f 
    955f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    9566:	00 
    9567:	bf 01 00 00 00       	mov    $0x1,%edi
    956c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    9573:	00 
    9574:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    957b:	00 
    957c:	e8 9f b1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9581:	48 8b 15 90 55 01 00 	mov    0x15590(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9588:	49 89 c5             	mov    %rax,%r13
    958b:	48 2b 05 5e 55 01 00 	sub    0x1555e(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9592:	48 c1 e2 10          	shl    $0x10,%rdx
    9596:	48 39 d0             	cmp    %rdx,%rax
    9599:	73 59                	jae    95f4 <f0+0x2024>
    959b:	48 89 c2             	mov    %rax,%rdx
    959e:	48 c1 ea 10          	shr    $0x10,%rdx
    95a2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95a6:	48 8b 15 8b 55 01 00 	mov    0x1558b(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    95ad:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95b1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    95b5:	4d 85 e4             	test   %r12,%r12
    95b8:	74 3a                	je     95f4 <f0+0x2024>
    95ba:	0f b6 0a             	movzbl (%rdx),%ecx
    95bd:	80 f9 02             	cmp    $0x2,%cl
    95c0:	0f 84 da 0a 00 00    	je     a0a0 <f0+0x2ad0>
    95c6:	80 f9 01             	cmp    $0x1,%cl
    95c9:	75 29                	jne    95f4 <f0+0x2024>
    95cb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95ce:	0f b7 c0             	movzwl %ax,%eax
    95d1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95d4:	48 0f af c1          	imul   %rcx,%rax
    95d8:	48 c1 e8 20          	shr    $0x20,%rax
    95dc:	48 39 d0             	cmp    %rdx,%rax
    95df:	73 13                	jae    95f4 <f0+0x2024>
    95e1:	49 01 c4             	add    %rax,%r12
    95e4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    95e9:	0f 84 31 0c 00 00    	je     a220 <f0+0x2c50>
    95ef:	41 c6 04 24 01       	movb   $0x1,(%r12)
    95f4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    95fb:	33 f3 bf 
    95fe:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    9605:	00 
    9606:	bf 01 00 00 00       	mov    $0x1,%edi
    960b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    9612:	00 
    9613:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    961a:	00 
    961b:	e8 00 b1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9620:	48 8b 15 f1 54 01 00 	mov    0x154f1(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9627:	49 89 c5             	mov    %rax,%r13
    962a:	48 2b 05 bf 54 01 00 	sub    0x154bf(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9631:	48 c1 e2 10          	shl    $0x10,%rdx
    9635:	48 39 d0             	cmp    %rdx,%rax
    9638:	73 59                	jae    9693 <f0+0x20c3>
    963a:	48 89 c2             	mov    %rax,%rdx
    963d:	48 c1 ea 10          	shr    $0x10,%rdx
    9641:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9645:	48 8b 15 ec 54 01 00 	mov    0x154ec(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    964c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9650:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9654:	4d 85 e4             	test   %r12,%r12
    9657:	74 3a                	je     9693 <f0+0x20c3>
    9659:	0f b6 0a             	movzbl (%rdx),%ecx
    965c:	80 f9 02             	cmp    $0x2,%cl
    965f:	0f 84 2b 0a 00 00    	je     a090 <f0+0x2ac0>
    9665:	80 f9 01             	cmp    $0x1,%cl
    9668:	75 29                	jne    9693 <f0+0x20c3>
    966a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    966d:	0f b7 c0             	movzwl %ax,%eax
    9670:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9673:	48 0f af c1          	imul   %rcx,%rax
    9677:	48 c1 e8 20          	shr    $0x20,%rax
    967b:	48 39 d0             	cmp    %rdx,%rax
    967e:	73 13                	jae    9693 <f0+0x20c3>
    9680:	49 01 c4             	add    %rax,%r12
    9683:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9688:	0f 84 9f 0b 00 00    	je     a22d <f0+0x2c5d>
    968e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9693:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    969a:	00 f0 3f 
    969d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    96a4:	00 
    96a5:	bf 01 00 00 00       	mov    $0x1,%edi
    96aa:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    96b1:	00 
    96b2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    96b9:	00 
    96ba:	e8 61 b0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    96bf:	48 8b 15 52 54 01 00 	mov    0x15452(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    96c6:	49 89 c5             	mov    %rax,%r13
    96c9:	48 2b 05 20 54 01 00 	sub    0x15420(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    96d0:	48 c1 e2 10          	shl    $0x10,%rdx
    96d4:	48 39 d0             	cmp    %rdx,%rax
    96d7:	73 59                	jae    9732 <f0+0x2162>
    96d9:	48 89 c2             	mov    %rax,%rdx
    96dc:	48 c1 ea 10          	shr    $0x10,%rdx
    96e0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96e4:	48 8b 15 4d 54 01 00 	mov    0x1544d(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    96eb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96ef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    96f3:	4d 85 e4             	test   %r12,%r12
    96f6:	74 3a                	je     9732 <f0+0x2162>
    96f8:	0f b6 0a             	movzbl (%rdx),%ecx
    96fb:	80 f9 02             	cmp    $0x2,%cl
    96fe:	0f 84 7c 09 00 00    	je     a080 <f0+0x2ab0>
    9704:	80 f9 01             	cmp    $0x1,%cl
    9707:	75 29                	jne    9732 <f0+0x2162>
    9709:	8b 4a 18             	mov    0x18(%rdx),%ecx
    970c:	0f b7 c0             	movzwl %ax,%eax
    970f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9712:	48 0f af c1          	imul   %rcx,%rax
    9716:	48 c1 e8 20          	shr    $0x20,%rax
    971a:	48 39 d0             	cmp    %rdx,%rax
    971d:	73 13                	jae    9732 <f0+0x2162>
    971f:	49 01 c4             	add    %rax,%r12
    9722:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9727:	0f 84 0d 0b 00 00    	je     a23a <f0+0x2c6a>
    972d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9732:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9739:	33 f3 bf 
    973c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    9743:	00 
    9744:	bf 01 00 00 00       	mov    $0x1,%edi
    9749:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    9750:	00 
    9751:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    9758:	00 
    9759:	e8 c2 af ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    975e:	48 8b 15 b3 53 01 00 	mov    0x153b3(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9765:	49 89 c5             	mov    %rax,%r13
    9768:	48 2b 05 81 53 01 00 	sub    0x15381(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    976f:	48 c1 e2 10          	shl    $0x10,%rdx
    9773:	48 39 d0             	cmp    %rdx,%rax
    9776:	73 59                	jae    97d1 <f0+0x2201>
    9778:	48 89 c2             	mov    %rax,%rdx
    977b:	48 c1 ea 10          	shr    $0x10,%rdx
    977f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9783:	48 8b 15 ae 53 01 00 	mov    0x153ae(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    978a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    978e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9792:	4d 85 e4             	test   %r12,%r12
    9795:	74 3a                	je     97d1 <f0+0x2201>
    9797:	0f b6 0a             	movzbl (%rdx),%ecx
    979a:	80 f9 02             	cmp    $0x2,%cl
    979d:	0f 84 cd 08 00 00    	je     a070 <f0+0x2aa0>
    97a3:	80 f9 01             	cmp    $0x1,%cl
    97a6:	75 29                	jne    97d1 <f0+0x2201>
    97a8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97ab:	0f b7 c0             	movzwl %ax,%eax
    97ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97b1:	48 0f af c1          	imul   %rcx,%rax
    97b5:	48 c1 e8 20          	shr    $0x20,%rax
    97b9:	48 39 d0             	cmp    %rdx,%rax
    97bc:	73 13                	jae    97d1 <f0+0x2201>
    97be:	49 01 c4             	add    %rax,%r12
    97c1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    97c6:	0f 84 7b 0a 00 00    	je     a247 <f0+0x2c77>
    97cc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    97d1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    97d8:	00 f0 3f 
    97db:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    97e2:	00 
    97e3:	bf 01 00 00 00       	mov    $0x1,%edi
    97e8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    97ef:	00 
    97f0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    97f7:	00 
    97f8:	e8 23 af ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    97fd:	48 8b 15 14 53 01 00 	mov    0x15314(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9804:	49 89 c5             	mov    %rax,%r13
    9807:	48 2b 05 e2 52 01 00 	sub    0x152e2(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    980e:	48 c1 e2 10          	shl    $0x10,%rdx
    9812:	48 39 d0             	cmp    %rdx,%rax
    9815:	73 59                	jae    9870 <f0+0x22a0>
    9817:	48 89 c2             	mov    %rax,%rdx
    981a:	48 c1 ea 10          	shr    $0x10,%rdx
    981e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9822:	48 8b 15 0f 53 01 00 	mov    0x1530f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9829:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    982d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9831:	4d 85 e4             	test   %r12,%r12
    9834:	74 3a                	je     9870 <f0+0x22a0>
    9836:	0f b6 0a             	movzbl (%rdx),%ecx
    9839:	80 f9 02             	cmp    $0x2,%cl
    983c:	0f 84 1e 08 00 00    	je     a060 <f0+0x2a90>
    9842:	80 f9 01             	cmp    $0x1,%cl
    9845:	75 29                	jne    9870 <f0+0x22a0>
    9847:	8b 4a 18             	mov    0x18(%rdx),%ecx
    984a:	0f b7 c0             	movzwl %ax,%eax
    984d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9850:	48 0f af c1          	imul   %rcx,%rax
    9854:	48 c1 e8 20          	shr    $0x20,%rax
    9858:	48 39 d0             	cmp    %rdx,%rax
    985b:	73 13                	jae    9870 <f0+0x22a0>
    985d:	49 01 c4             	add    %rax,%r12
    9860:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9865:	0f 84 e9 09 00 00    	je     a254 <f0+0x2c84>
    986b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9870:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9877:	33 f3 bf 
    987a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    9881:	00 
    9882:	bf 01 00 00 00       	mov    $0x1,%edi
    9887:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    988e:	00 
    988f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    9896:	00 
    9897:	e8 84 ae ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    989c:	48 8b 15 75 52 01 00 	mov    0x15275(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    98a3:	49 89 c5             	mov    %rax,%r13
    98a6:	48 2b 05 43 52 01 00 	sub    0x15243(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    98ad:	48 c1 e2 10          	shl    $0x10,%rdx
    98b1:	48 39 d0             	cmp    %rdx,%rax
    98b4:	73 59                	jae    990f <f0+0x233f>
    98b6:	48 89 c2             	mov    %rax,%rdx
    98b9:	48 c1 ea 10          	shr    $0x10,%rdx
    98bd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98c1:	48 8b 15 70 52 01 00 	mov    0x15270(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    98c8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98cc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    98d0:	4d 85 e4             	test   %r12,%r12
    98d3:	74 3a                	je     990f <f0+0x233f>
    98d5:	0f b6 0a             	movzbl (%rdx),%ecx
    98d8:	80 f9 02             	cmp    $0x2,%cl
    98db:	0f 84 6f 07 00 00    	je     a050 <f0+0x2a80>
    98e1:	80 f9 01             	cmp    $0x1,%cl
    98e4:	75 29                	jne    990f <f0+0x233f>
    98e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98e9:	0f b7 c0             	movzwl %ax,%eax
    98ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98ef:	48 0f af c1          	imul   %rcx,%rax
    98f3:	48 c1 e8 20          	shr    $0x20,%rax
    98f7:	48 39 d0             	cmp    %rdx,%rax
    98fa:	73 13                	jae    990f <f0+0x233f>
    98fc:	49 01 c4             	add    %rax,%r12
    98ff:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9904:	0f 84 57 09 00 00    	je     a261 <f0+0x2c91>
    990a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    990f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9916:	00 f0 3f 
    9919:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    9920:	00 
    9921:	bf 01 00 00 00       	mov    $0x1,%edi
    9926:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    992d:	00 
    992e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9935:	00 
    9936:	e8 e5 ad ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    993b:	48 8b 15 d6 51 01 00 	mov    0x151d6(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9942:	49 89 c5             	mov    %rax,%r13
    9945:	48 2b 05 a4 51 01 00 	sub    0x151a4(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    994c:	48 c1 e2 10          	shl    $0x10,%rdx
    9950:	48 39 d0             	cmp    %rdx,%rax
    9953:	73 59                	jae    99ae <f0+0x23de>
    9955:	48 89 c2             	mov    %rax,%rdx
    9958:	48 c1 ea 10          	shr    $0x10,%rdx
    995c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9960:	48 8b 15 d1 51 01 00 	mov    0x151d1(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9967:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    996b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    996f:	4d 85 e4             	test   %r12,%r12
    9972:	74 3a                	je     99ae <f0+0x23de>
    9974:	0f b6 0a             	movzbl (%rdx),%ecx
    9977:	80 f9 02             	cmp    $0x2,%cl
    997a:	0f 84 c0 06 00 00    	je     a040 <f0+0x2a70>
    9980:	80 f9 01             	cmp    $0x1,%cl
    9983:	75 29                	jne    99ae <f0+0x23de>
    9985:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9988:	0f b7 c0             	movzwl %ax,%eax
    998b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    998e:	48 0f af c1          	imul   %rcx,%rax
    9992:	48 c1 e8 20          	shr    $0x20,%rax
    9996:	48 39 d0             	cmp    %rdx,%rax
    9999:	73 13                	jae    99ae <f0+0x23de>
    999b:	49 01 c4             	add    %rax,%r12
    999e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    99a3:	0f 84 c5 08 00 00    	je     a26e <f0+0x2c9e>
    99a9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    99ae:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    99b5:	33 f3 bf 
    99b8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    99bf:	00 
    99c0:	bf 01 00 00 00       	mov    $0x1,%edi
    99c5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    99cc:	00 
    99cd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    99d4:	00 
    99d5:	e8 46 ad ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    99da:	48 8b 15 37 51 01 00 	mov    0x15137(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    99e1:	49 89 c5             	mov    %rax,%r13
    99e4:	48 2b 05 05 51 01 00 	sub    0x15105(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    99eb:	48 c1 e2 10          	shl    $0x10,%rdx
    99ef:	48 39 d0             	cmp    %rdx,%rax
    99f2:	73 59                	jae    9a4d <f0+0x247d>
    99f4:	48 89 c2             	mov    %rax,%rdx
    99f7:	48 c1 ea 10          	shr    $0x10,%rdx
    99fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99ff:	48 8b 15 32 51 01 00 	mov    0x15132(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9a06:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a0a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9a0e:	4d 85 e4             	test   %r12,%r12
    9a11:	74 3a                	je     9a4d <f0+0x247d>
    9a13:	0f b6 0a             	movzbl (%rdx),%ecx
    9a16:	80 f9 02             	cmp    $0x2,%cl
    9a19:	0f 84 11 06 00 00    	je     a030 <f0+0x2a60>
    9a1f:	80 f9 01             	cmp    $0x1,%cl
    9a22:	75 29                	jne    9a4d <f0+0x247d>
    9a24:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a27:	0f b7 c0             	movzwl %ax,%eax
    9a2a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a2d:	48 0f af c1          	imul   %rcx,%rax
    9a31:	48 c1 e8 20          	shr    $0x20,%rax
    9a35:	48 39 d0             	cmp    %rdx,%rax
    9a38:	73 13                	jae    9a4d <f0+0x247d>
    9a3a:	49 01 c4             	add    %rax,%r12
    9a3d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9a42:	0f 84 33 08 00 00    	je     a27b <f0+0x2cab>
    9a48:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9a4d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9a54:	00 f0 3f 
    9a57:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    9a5e:	00 
    9a5f:	bf 01 00 00 00       	mov    $0x1,%edi
    9a64:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9a6b:	00 
    9a6c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9a73:	00 
    9a74:	e8 a7 ac ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9a79:	48 8b 15 98 50 01 00 	mov    0x15098(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9a80:	49 89 c5             	mov    %rax,%r13
    9a83:	48 2b 05 66 50 01 00 	sub    0x15066(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9a8a:	48 c1 e2 10          	shl    $0x10,%rdx
    9a8e:	48 39 d0             	cmp    %rdx,%rax
    9a91:	73 59                	jae    9aec <f0+0x251c>
    9a93:	48 89 c2             	mov    %rax,%rdx
    9a96:	48 c1 ea 10          	shr    $0x10,%rdx
    9a9a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a9e:	48 8b 15 93 50 01 00 	mov    0x15093(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9aa5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aa9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9aad:	4d 85 e4             	test   %r12,%r12
    9ab0:	74 3a                	je     9aec <f0+0x251c>
    9ab2:	0f b6 0a             	movzbl (%rdx),%ecx
    9ab5:	80 f9 02             	cmp    $0x2,%cl
    9ab8:	0f 84 62 05 00 00    	je     a020 <f0+0x2a50>
    9abe:	80 f9 01             	cmp    $0x1,%cl
    9ac1:	75 29                	jne    9aec <f0+0x251c>
    9ac3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ac6:	0f b7 c0             	movzwl %ax,%eax
    9ac9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9acc:	48 0f af c1          	imul   %rcx,%rax
    9ad0:	48 c1 e8 20          	shr    $0x20,%rax
    9ad4:	48 39 d0             	cmp    %rdx,%rax
    9ad7:	73 13                	jae    9aec <f0+0x251c>
    9ad9:	49 01 c4             	add    %rax,%r12
    9adc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9ae1:	0f 84 a1 07 00 00    	je     a288 <f0+0x2cb8>
    9ae7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9aec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9af3:	33 f3 bf 
    9af6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    9afd:	00 
    9afe:	bf 01 00 00 00       	mov    $0x1,%edi
    9b03:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    9b0a:	00 
    9b0b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    9b12:	00 
    9b13:	e8 08 ac ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9b18:	48 8b 15 f9 4f 01 00 	mov    0x14ff9(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9b1f:	49 89 c5             	mov    %rax,%r13
    9b22:	48 2b 05 c7 4f 01 00 	sub    0x14fc7(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9b29:	48 c1 e2 10          	shl    $0x10,%rdx
    9b2d:	48 39 d0             	cmp    %rdx,%rax
    9b30:	73 59                	jae    9b8b <f0+0x25bb>
    9b32:	48 89 c2             	mov    %rax,%rdx
    9b35:	48 c1 ea 10          	shr    $0x10,%rdx
    9b39:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b3d:	48 8b 15 f4 4f 01 00 	mov    0x14ff4(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9b44:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b48:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9b4c:	4d 85 e4             	test   %r12,%r12
    9b4f:	74 3a                	je     9b8b <f0+0x25bb>
    9b51:	0f b6 0a             	movzbl (%rdx),%ecx
    9b54:	80 f9 02             	cmp    $0x2,%cl
    9b57:	0f 84 b3 04 00 00    	je     a010 <f0+0x2a40>
    9b5d:	80 f9 01             	cmp    $0x1,%cl
    9b60:	75 29                	jne    9b8b <f0+0x25bb>
    9b62:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b65:	0f b7 c0             	movzwl %ax,%eax
    9b68:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b6b:	48 0f af c1          	imul   %rcx,%rax
    9b6f:	48 c1 e8 20          	shr    $0x20,%rax
    9b73:	48 39 d0             	cmp    %rdx,%rax
    9b76:	73 13                	jae    9b8b <f0+0x25bb>
    9b78:	49 01 c4             	add    %rax,%r12
    9b7b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9b80:	0f 84 0f 07 00 00    	je     a295 <f0+0x2cc5>
    9b86:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9b8b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9b92:	00 f0 3f 
    9b95:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    9b9c:	00 
    9b9d:	bf 01 00 00 00       	mov    $0x1,%edi
    9ba2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    9ba9:	00 
    9baa:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    9bb1:	00 
    9bb2:	e8 69 ab ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9bb7:	48 8b 15 5a 4f 01 00 	mov    0x14f5a(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9bbe:	49 89 c5             	mov    %rax,%r13
    9bc1:	48 2b 05 28 4f 01 00 	sub    0x14f28(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9bc8:	48 c1 e2 10          	shl    $0x10,%rdx
    9bcc:	48 39 d0             	cmp    %rdx,%rax
    9bcf:	73 59                	jae    9c2a <f0+0x265a>
    9bd1:	48 89 c2             	mov    %rax,%rdx
    9bd4:	48 c1 ea 10          	shr    $0x10,%rdx
    9bd8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bdc:	48 8b 15 55 4f 01 00 	mov    0x14f55(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9be3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9be7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9beb:	4d 85 e4             	test   %r12,%r12
    9bee:	74 3a                	je     9c2a <f0+0x265a>
    9bf0:	0f b6 0a             	movzbl (%rdx),%ecx
    9bf3:	80 f9 02             	cmp    $0x2,%cl
    9bf6:	0f 84 04 04 00 00    	je     a000 <f0+0x2a30>
    9bfc:	80 f9 01             	cmp    $0x1,%cl
    9bff:	75 29                	jne    9c2a <f0+0x265a>
    9c01:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c04:	0f b7 c0             	movzwl %ax,%eax
    9c07:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c0a:	48 0f af c1          	imul   %rcx,%rax
    9c0e:	48 c1 e8 20          	shr    $0x20,%rax
    9c12:	48 39 d0             	cmp    %rdx,%rax
    9c15:	73 13                	jae    9c2a <f0+0x265a>
    9c17:	49 01 c4             	add    %rax,%r12
    9c1a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9c1f:	0f 84 7d 06 00 00    	je     a2a2 <f0+0x2cd2>
    9c25:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9c2a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9c31:	33 f3 bf 
    9c34:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    9c3b:	00 
    9c3c:	bf 01 00 00 00       	mov    $0x1,%edi
    9c41:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    9c48:	00 
    9c49:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9c50:	00 
    9c51:	e8 ca aa ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9c56:	48 8b 15 bb 4e 01 00 	mov    0x14ebb(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9c5d:	49 89 c5             	mov    %rax,%r13
    9c60:	48 2b 05 89 4e 01 00 	sub    0x14e89(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9c67:	48 c1 e2 10          	shl    $0x10,%rdx
    9c6b:	48 39 d0             	cmp    %rdx,%rax
    9c6e:	73 59                	jae    9cc9 <f0+0x26f9>
    9c70:	48 89 c2             	mov    %rax,%rdx
    9c73:	48 c1 ea 10          	shr    $0x10,%rdx
    9c77:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c7b:	48 8b 15 b6 4e 01 00 	mov    0x14eb6(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9c82:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c86:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9c8a:	4d 85 e4             	test   %r12,%r12
    9c8d:	74 3a                	je     9cc9 <f0+0x26f9>
    9c8f:	0f b6 0a             	movzbl (%rdx),%ecx
    9c92:	80 f9 02             	cmp    $0x2,%cl
    9c95:	0f 84 55 03 00 00    	je     9ff0 <f0+0x2a20>
    9c9b:	80 f9 01             	cmp    $0x1,%cl
    9c9e:	75 29                	jne    9cc9 <f0+0x26f9>
    9ca0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ca3:	0f b7 c0             	movzwl %ax,%eax
    9ca6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ca9:	48 0f af c1          	imul   %rcx,%rax
    9cad:	48 c1 e8 20          	shr    $0x20,%rax
    9cb1:	48 39 d0             	cmp    %rdx,%rax
    9cb4:	73 13                	jae    9cc9 <f0+0x26f9>
    9cb6:	49 01 c4             	add    %rax,%r12
    9cb9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9cbe:	0f 84 eb 05 00 00    	je     a2af <f0+0x2cdf>
    9cc4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9cc9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9cd0:	00 f0 3f 
    9cd3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    9cda:	00 
    9cdb:	bf 01 00 00 00       	mov    $0x1,%edi
    9ce0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    9ce7:	00 
    9ce8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    9cef:	00 
    9cf0:	e8 2b aa ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9cf5:	48 8b 15 1c 4e 01 00 	mov    0x14e1c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9cfc:	49 89 c5             	mov    %rax,%r13
    9cff:	48 2b 05 ea 4d 01 00 	sub    0x14dea(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9d06:	48 c1 e2 10          	shl    $0x10,%rdx
    9d0a:	48 39 d0             	cmp    %rdx,%rax
    9d0d:	73 59                	jae    9d68 <f0+0x2798>
    9d0f:	48 89 c2             	mov    %rax,%rdx
    9d12:	48 c1 ea 10          	shr    $0x10,%rdx
    9d16:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d1a:	48 8b 15 17 4e 01 00 	mov    0x14e17(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9d21:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d25:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9d29:	4d 85 e4             	test   %r12,%r12
    9d2c:	74 3a                	je     9d68 <f0+0x2798>
    9d2e:	0f b6 0a             	movzbl (%rdx),%ecx
    9d31:	80 f9 02             	cmp    $0x2,%cl
    9d34:	0f 84 a6 02 00 00    	je     9fe0 <f0+0x2a10>
    9d3a:	80 f9 01             	cmp    $0x1,%cl
    9d3d:	75 29                	jne    9d68 <f0+0x2798>
    9d3f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d42:	0f b7 c0             	movzwl %ax,%eax
    9d45:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d48:	48 0f af c1          	imul   %rcx,%rax
    9d4c:	48 c1 e8 20          	shr    $0x20,%rax
    9d50:	48 39 d0             	cmp    %rdx,%rax
    9d53:	73 13                	jae    9d68 <f0+0x2798>
    9d55:	49 01 c4             	add    %rax,%r12
    9d58:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9d5d:	0f 84 59 05 00 00    	je     a2bc <f0+0x2cec>
    9d63:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9d68:	48 89 ee             	mov    %rbp,%rsi
    9d6b:	bf 01 00 00 00       	mov    $0x1,%edi
    9d70:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9d77:	33 f3 bf 
    9d7a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    9d81:	00 
    9d82:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    9d89:	00 
    9d8a:	e8 91 a9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9d8f:	48 8b 15 82 4d 01 00 	mov    0x14d82(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9d96:	48 89 c5             	mov    %rax,%rbp
    9d99:	48 2b 05 50 4d 01 00 	sub    0x14d50(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9da0:	48 c1 e2 10          	shl    $0x10,%rdx
    9da4:	48 39 d0             	cmp    %rdx,%rax
    9da7:	73 59                	jae    9e02 <f0+0x2832>
    9da9:	48 89 c2             	mov    %rax,%rdx
    9dac:	48 c1 ea 10          	shr    $0x10,%rdx
    9db0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9db4:	48 8b 15 7d 4d 01 00 	mov    0x14d7d(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9dbb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9dbf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9dc3:	4d 85 e4             	test   %r12,%r12
    9dc6:	74 3a                	je     9e02 <f0+0x2832>
    9dc8:	0f b6 0a             	movzbl (%rdx),%ecx
    9dcb:	80 f9 02             	cmp    $0x2,%cl
    9dce:	0f 84 fc 01 00 00    	je     9fd0 <f0+0x2a00>
    9dd4:	80 f9 01             	cmp    $0x1,%cl
    9dd7:	75 29                	jne    9e02 <f0+0x2832>
    9dd9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ddc:	0f b7 c0             	movzwl %ax,%eax
    9ddf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9de2:	48 0f af c1          	imul   %rcx,%rax
    9de6:	48 c1 e8 20          	shr    $0x20,%rax
    9dea:	48 39 d0             	cmp    %rdx,%rax
    9ded:	73 13                	jae    9e02 <f0+0x2832>
    9def:	49 01 c4             	add    %rax,%r12
    9df2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9df7:	0f 84 d1 02 00 00    	je     a0ce <f0+0x2afe>
    9dfd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9e02:	48 89 de             	mov    %rbx,%rsi
    9e05:	48 89 ef             	mov    %rbp,%rdi
    9e08:	e8 e3 c1 ff ff       	call   5ff0 <fwp_hof0.constprop.0>
    9e0d:	48 89 ef             	mov    %rbp,%rdi
    9e10:	e8 0b af ff ff       	call   4d20 <fwp_drop0>
    9e15:	48 89 df             	mov    %rbx,%rdi
    9e18:	e8 03 af ff ff       	call   4d20 <fwp_drop0>
    9e1d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    9e24:	00 
    9e25:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e2c:	00 00 
    9e2e:	0f 85 95 04 00 00    	jne    a2c9 <f0+0x2cf9>
    9e34:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    9e3b:	31 c0                	xor    %eax,%eax
    9e3d:	5b                   	pop    %rbx
    9e3e:	5d                   	pop    %rbp
    9e3f:	41 5c                	pop    %r12
    9e41:	41 5d                	pop    %r13
    9e43:	41 5e                	pop    %r14
    9e45:	c3                   	ret
    9e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e4d:	00 00 00 
    9e50:	4c 89 ef             	mov    %r13,%rdi
    9e53:	e8 38 9f ff ff       	call   3d90 <fwp_rc_forget_slot>
    9e58:	e9 2c d8 ff ff       	jmp    7689 <f0+0xb9>
    9e5d:	0f 1f 00             	nopl   (%rax)
    9e60:	66 85 c0             	test   %ax,%ax
    9e63:	0f 85 ae f5 ff ff    	jne    9417 <f0+0x1e47>
    9e69:	e9 99 f5 ff ff       	jmp    9407 <f0+0x1e37>
    9e6e:	66 90                	xchg   %ax,%ax
    9e70:	66 85 c0             	test   %ax,%ax
    9e73:	0f 85 ff f4 ff ff    	jne    9378 <f0+0x1da8>
    9e79:	e9 ea f4 ff ff       	jmp    9368 <f0+0x1d98>
    9e7e:	66 90                	xchg   %ax,%ax
    9e80:	66 85 c0             	test   %ax,%ax
    9e83:	0f 85 50 f4 ff ff    	jne    92d9 <f0+0x1d09>
    9e89:	e9 3b f4 ff ff       	jmp    92c9 <f0+0x1cf9>
    9e8e:	66 90                	xchg   %ax,%ax
    9e90:	66 85 c0             	test   %ax,%ax
    9e93:	0f 85 a1 f3 ff ff    	jne    923a <f0+0x1c6a>
    9e99:	e9 8c f3 ff ff       	jmp    922a <f0+0x1c5a>
    9e9e:	66 90                	xchg   %ax,%ax
    9ea0:	66 85 c0             	test   %ax,%ax
    9ea3:	0f 85 f2 f2 ff ff    	jne    919b <f0+0x1bcb>
    9ea9:	e9 dd f2 ff ff       	jmp    918b <f0+0x1bbb>
    9eae:	66 90                	xchg   %ax,%ax
    9eb0:	66 85 c0             	test   %ax,%ax
    9eb3:	0f 85 43 f2 ff ff    	jne    90fc <f0+0x1b2c>
    9eb9:	e9 2e f2 ff ff       	jmp    90ec <f0+0x1b1c>
    9ebe:	66 90                	xchg   %ax,%ax
    9ec0:	66 85 c0             	test   %ax,%ax
    9ec3:	0f 85 94 f1 ff ff    	jne    905d <f0+0x1a8d>
    9ec9:	e9 7f f1 ff ff       	jmp    904d <f0+0x1a7d>
    9ece:	66 90                	xchg   %ax,%ax
    9ed0:	66 85 c0             	test   %ax,%ax
    9ed3:	0f 85 e5 f0 ff ff    	jne    8fbe <f0+0x19ee>
    9ed9:	e9 d0 f0 ff ff       	jmp    8fae <f0+0x19de>
    9ede:	66 90                	xchg   %ax,%ax
    9ee0:	66 85 c0             	test   %ax,%ax
    9ee3:	0f 85 fd d9 ff ff    	jne    78e6 <f0+0x316>
    9ee9:	e9 e8 d9 ff ff       	jmp    78d6 <f0+0x306>
    9eee:	66 90                	xchg   %ax,%ax
    9ef0:	66 85 c0             	test   %ax,%ax
    9ef3:	0f 85 57 d9 ff ff    	jne    7850 <f0+0x280>
    9ef9:	e9 42 d9 ff ff       	jmp    7840 <f0+0x270>
    9efe:	66 90                	xchg   %ax,%ax
    9f00:	66 85 c0             	test   %ax,%ax
    9f03:	0f 85 b1 d8 ff ff    	jne    77ba <f0+0x1ea>
    9f09:	e9 9c d8 ff ff       	jmp    77aa <f0+0x1da>
    9f0e:	66 90                	xchg   %ax,%ax
    9f10:	66 85 c0             	test   %ax,%ax
    9f13:	0f 85 0e eb ff ff    	jne    8a27 <f0+0x1457>
    9f19:	e9 f9 ea ff ff       	jmp    8a17 <f0+0x1447>
    9f1e:	66 90                	xchg   %ax,%ax
    9f20:	66 85 c0             	test   %ax,%ax
    9f23:	0f 85 5f ea ff ff    	jne    8988 <f0+0x13b8>
    9f29:	e9 4a ea ff ff       	jmp    8978 <f0+0x13a8>
    9f2e:	66 90                	xchg   %ax,%ax
    9f30:	66 85 c0             	test   %ax,%ax
    9f33:	0f 85 b0 e9 ff ff    	jne    88e9 <f0+0x1319>
    9f39:	e9 9b e9 ff ff       	jmp    88d9 <f0+0x1309>
    9f3e:	66 90                	xchg   %ax,%ax
    9f40:	66 85 c0             	test   %ax,%ax
    9f43:	0f 85 33 da ff ff    	jne    797c <f0+0x3ac>
    9f49:	e9 1e da ff ff       	jmp    796c <f0+0x39c>
    9f4e:	66 90                	xchg   %ax,%ax
    9f50:	66 85 c0             	test   %ax,%ax
    9f53:	0f 85 c6 ef ff ff    	jne    8f1f <f0+0x194f>
    9f59:	e9 b1 ef ff ff       	jmp    8f0f <f0+0x193f>
    9f5e:	66 90                	xchg   %ax,%ax
    9f60:	66 85 c0             	test   %ax,%ax
    9f63:	0f 85 17 ef ff ff    	jne    8e80 <f0+0x18b0>
    9f69:	e9 02 ef ff ff       	jmp    8e70 <f0+0x18a0>
    9f6e:	66 90                	xchg   %ax,%ax
    9f70:	66 85 c0             	test   %ax,%ax
    9f73:	0f 85 68 ee ff ff    	jne    8de1 <f0+0x1811>
    9f79:	e9 53 ee ff ff       	jmp    8dd1 <f0+0x1801>
    9f7e:	66 90                	xchg   %ax,%ax
    9f80:	66 85 c0             	test   %ax,%ax
    9f83:	0f 85 b9 ed ff ff    	jne    8d42 <f0+0x1772>
    9f89:	e9 a4 ed ff ff       	jmp    8d32 <f0+0x1762>
    9f8e:	66 90                	xchg   %ax,%ax
    9f90:	66 85 c0             	test   %ax,%ax
    9f93:	0f 85 0a ed ff ff    	jne    8ca3 <f0+0x16d3>
    9f99:	e9 f5 ec ff ff       	jmp    8c93 <f0+0x16c3>
    9f9e:	66 90                	xchg   %ax,%ax
    9fa0:	66 85 c0             	test   %ax,%ax
    9fa3:	0f 85 5b ec ff ff    	jne    8c04 <f0+0x1634>
    9fa9:	e9 46 ec ff ff       	jmp    8bf4 <f0+0x1624>
    9fae:	66 90                	xchg   %ax,%ax
    9fb0:	66 85 c0             	test   %ax,%ax
    9fb3:	0f 85 ac eb ff ff    	jne    8b65 <f0+0x1595>
    9fb9:	e9 97 eb ff ff       	jmp    8b55 <f0+0x1585>
    9fbe:	66 90                	xchg   %ax,%ax
    9fc0:	66 85 c0             	test   %ax,%ax
    9fc3:	0f 85 fd ea ff ff    	jne    8ac6 <f0+0x14f6>
    9fc9:	e9 e8 ea ff ff       	jmp    8ab6 <f0+0x14e6>
    9fce:	66 90                	xchg   %ax,%ax
    9fd0:	66 85 c0             	test   %ax,%ax
    9fd3:	0f 85 29 fe ff ff    	jne    9e02 <f0+0x2832>
    9fd9:	e9 14 fe ff ff       	jmp    9df2 <f0+0x2822>
    9fde:	66 90                	xchg   %ax,%ax
    9fe0:	66 85 c0             	test   %ax,%ax
    9fe3:	0f 85 7f fd ff ff    	jne    9d68 <f0+0x2798>
    9fe9:	e9 6a fd ff ff       	jmp    9d58 <f0+0x2788>
    9fee:	66 90                	xchg   %ax,%ax
    9ff0:	66 85 c0             	test   %ax,%ax
    9ff3:	0f 85 d0 fc ff ff    	jne    9cc9 <f0+0x26f9>
    9ff9:	e9 bb fc ff ff       	jmp    9cb9 <f0+0x26e9>
    9ffe:	66 90                	xchg   %ax,%ax
    a000:	66 85 c0             	test   %ax,%ax
    a003:	0f 85 21 fc ff ff    	jne    9c2a <f0+0x265a>
    a009:	e9 0c fc ff ff       	jmp    9c1a <f0+0x264a>
    a00e:	66 90                	xchg   %ax,%ax
    a010:	66 85 c0             	test   %ax,%ax
    a013:	0f 85 72 fb ff ff    	jne    9b8b <f0+0x25bb>
    a019:	e9 5d fb ff ff       	jmp    9b7b <f0+0x25ab>
    a01e:	66 90                	xchg   %ax,%ax
    a020:	66 85 c0             	test   %ax,%ax
    a023:	0f 85 c3 fa ff ff    	jne    9aec <f0+0x251c>
    a029:	e9 ae fa ff ff       	jmp    9adc <f0+0x250c>
    a02e:	66 90                	xchg   %ax,%ax
    a030:	66 85 c0             	test   %ax,%ax
    a033:	0f 85 14 fa ff ff    	jne    9a4d <f0+0x247d>
    a039:	e9 ff f9 ff ff       	jmp    9a3d <f0+0x246d>
    a03e:	66 90                	xchg   %ax,%ax
    a040:	66 85 c0             	test   %ax,%ax
    a043:	0f 85 65 f9 ff ff    	jne    99ae <f0+0x23de>
    a049:	e9 50 f9 ff ff       	jmp    999e <f0+0x23ce>
    a04e:	66 90                	xchg   %ax,%ax
    a050:	66 85 c0             	test   %ax,%ax
    a053:	0f 85 b6 f8 ff ff    	jne    990f <f0+0x233f>
    a059:	e9 a1 f8 ff ff       	jmp    98ff <f0+0x232f>
    a05e:	66 90                	xchg   %ax,%ax
    a060:	66 85 c0             	test   %ax,%ax
    a063:	0f 85 07 f8 ff ff    	jne    9870 <f0+0x22a0>
    a069:	e9 f2 f7 ff ff       	jmp    9860 <f0+0x2290>
    a06e:	66 90                	xchg   %ax,%ax
    a070:	66 85 c0             	test   %ax,%ax
    a073:	0f 85 58 f7 ff ff    	jne    97d1 <f0+0x2201>
    a079:	e9 43 f7 ff ff       	jmp    97c1 <f0+0x21f1>
    a07e:	66 90                	xchg   %ax,%ax
    a080:	66 85 c0             	test   %ax,%ax
    a083:	0f 85 a9 f6 ff ff    	jne    9732 <f0+0x2162>
    a089:	e9 94 f6 ff ff       	jmp    9722 <f0+0x2152>
    a08e:	66 90                	xchg   %ax,%ax
    a090:	66 85 c0             	test   %ax,%ax
    a093:	0f 85 fa f5 ff ff    	jne    9693 <f0+0x20c3>
    a099:	e9 e5 f5 ff ff       	jmp    9683 <f0+0x20b3>
    a09e:	66 90                	xchg   %ax,%ax
    a0a0:	66 85 c0             	test   %ax,%ax
    a0a3:	0f 85 4b f5 ff ff    	jne    95f4 <f0+0x2024>
    a0a9:	e9 36 f5 ff ff       	jmp    95e4 <f0+0x2014>
    a0ae:	66 90                	xchg   %ax,%ax
    a0b0:	66 85 c0             	test   %ax,%ax
    a0b3:	0f 85 9c f4 ff ff    	jne    9555 <f0+0x1f85>
    a0b9:	e9 87 f4 ff ff       	jmp    9545 <f0+0x1f75>
    a0be:	66 90                	xchg   %ax,%ax
    a0c0:	66 85 c0             	test   %ax,%ax
    a0c3:	0f 85 ed f3 ff ff    	jne    94b6 <f0+0x1ee6>
    a0c9:	e9 d8 f3 ff ff       	jmp    94a6 <f0+0x1ed6>
    a0ce:	4c 89 e7             	mov    %r12,%rdi
    a0d1:	e8 ba 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a0d6:	e9 22 fd ff ff       	jmp    9dfd <f0+0x282d>
    a0db:	4c 89 e7             	mov    %r12,%rdi
    a0de:	e8 ad 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a0e3:	e9 cd d6 ff ff       	jmp    77b5 <f0+0x1e5>
    a0e8:	4c 89 e7             	mov    %r12,%rdi
    a0eb:	e8 a0 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a0f0:	e9 56 d7 ff ff       	jmp    784b <f0+0x27b>
    a0f5:	4c 89 e7             	mov    %r12,%rdi
    a0f8:	e8 93 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a0fd:	e9 df d7 ff ff       	jmp    78e1 <f0+0x311>
    a102:	4c 89 e7             	mov    %r12,%rdi
    a105:	e8 86 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a10a:	e9 68 d8 ff ff       	jmp    7977 <f0+0x3a7>
    a10f:	4c 89 e7             	mov    %r12,%rdi
    a112:	e8 79 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a117:	e9 c8 e7 ff ff       	jmp    88e4 <f0+0x1314>
    a11c:	4c 89 e7             	mov    %r12,%rdi
    a11f:	e8 6c 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a124:	e9 5a e8 ff ff       	jmp    8983 <f0+0x13b3>
    a129:	4c 89 e7             	mov    %r12,%rdi
    a12c:	e8 5f 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a131:	e9 ec e8 ff ff       	jmp    8a22 <f0+0x1452>
    a136:	4c 89 e7             	mov    %r12,%rdi
    a139:	e8 52 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a13e:	e9 7e e9 ff ff       	jmp    8ac1 <f0+0x14f1>
    a143:	4c 89 e7             	mov    %r12,%rdi
    a146:	e8 45 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a14b:	e9 10 ea ff ff       	jmp    8b60 <f0+0x1590>
    a150:	4c 89 e7             	mov    %r12,%rdi
    a153:	e8 38 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a158:	e9 a2 ea ff ff       	jmp    8bff <f0+0x162f>
    a15d:	4c 89 e7             	mov    %r12,%rdi
    a160:	e8 2b 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a165:	e9 34 eb ff ff       	jmp    8c9e <f0+0x16ce>
    a16a:	4c 89 e7             	mov    %r12,%rdi
    a16d:	e8 1e 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a172:	e9 c6 eb ff ff       	jmp    8d3d <f0+0x176d>
    a177:	4c 89 e7             	mov    %r12,%rdi
    a17a:	e8 11 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a17f:	e9 58 ec ff ff       	jmp    8ddc <f0+0x180c>
    a184:	4c 89 e7             	mov    %r12,%rdi
    a187:	e8 04 9c ff ff       	call   3d90 <fwp_rc_forget_slot>
    a18c:	e9 ea ec ff ff       	jmp    8e7b <f0+0x18ab>
    a191:	4c 89 e7             	mov    %r12,%rdi
    a194:	e8 f7 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a199:	e9 7c ed ff ff       	jmp    8f1a <f0+0x194a>
    a19e:	4c 89 e7             	mov    %r12,%rdi
    a1a1:	e8 ea 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1a6:	e9 0e ee ff ff       	jmp    8fb9 <f0+0x19e9>
    a1ab:	4c 89 e7             	mov    %r12,%rdi
    a1ae:	e8 dd 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1b3:	e9 a0 ee ff ff       	jmp    9058 <f0+0x1a88>
    a1b8:	4c 89 e7             	mov    %r12,%rdi
    a1bb:	e8 d0 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1c0:	e9 32 ef ff ff       	jmp    90f7 <f0+0x1b27>
    a1c5:	4c 89 e7             	mov    %r12,%rdi
    a1c8:	e8 c3 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1cd:	e9 c4 ef ff ff       	jmp    9196 <f0+0x1bc6>
    a1d2:	4c 89 e7             	mov    %r12,%rdi
    a1d5:	e8 b6 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1da:	e9 56 f0 ff ff       	jmp    9235 <f0+0x1c65>
    a1df:	4c 89 e7             	mov    %r12,%rdi
    a1e2:	e8 a9 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1e7:	e9 e8 f0 ff ff       	jmp    92d4 <f0+0x1d04>
    a1ec:	4c 89 e7             	mov    %r12,%rdi
    a1ef:	e8 9c 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a1f4:	e9 7a f1 ff ff       	jmp    9373 <f0+0x1da3>
    a1f9:	4c 89 e7             	mov    %r12,%rdi
    a1fc:	e8 8f 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a201:	e9 0c f2 ff ff       	jmp    9412 <f0+0x1e42>
    a206:	4c 89 e7             	mov    %r12,%rdi
    a209:	e8 82 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a20e:	e9 9e f2 ff ff       	jmp    94b1 <f0+0x1ee1>
    a213:	4c 89 e7             	mov    %r12,%rdi
    a216:	e8 75 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a21b:	e9 30 f3 ff ff       	jmp    9550 <f0+0x1f80>
    a220:	4c 89 e7             	mov    %r12,%rdi
    a223:	e8 68 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a228:	e9 c2 f3 ff ff       	jmp    95ef <f0+0x201f>
    a22d:	4c 89 e7             	mov    %r12,%rdi
    a230:	e8 5b 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a235:	e9 54 f4 ff ff       	jmp    968e <f0+0x20be>
    a23a:	4c 89 e7             	mov    %r12,%rdi
    a23d:	e8 4e 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a242:	e9 e6 f4 ff ff       	jmp    972d <f0+0x215d>
    a247:	4c 89 e7             	mov    %r12,%rdi
    a24a:	e8 41 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a24f:	e9 78 f5 ff ff       	jmp    97cc <f0+0x21fc>
    a254:	4c 89 e7             	mov    %r12,%rdi
    a257:	e8 34 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a25c:	e9 0a f6 ff ff       	jmp    986b <f0+0x229b>
    a261:	4c 89 e7             	mov    %r12,%rdi
    a264:	e8 27 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a269:	e9 9c f6 ff ff       	jmp    990a <f0+0x233a>
    a26e:	4c 89 e7             	mov    %r12,%rdi
    a271:	e8 1a 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a276:	e9 2e f7 ff ff       	jmp    99a9 <f0+0x23d9>
    a27b:	4c 89 e7             	mov    %r12,%rdi
    a27e:	e8 0d 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a283:	e9 c0 f7 ff ff       	jmp    9a48 <f0+0x2478>
    a288:	4c 89 e7             	mov    %r12,%rdi
    a28b:	e8 00 9b ff ff       	call   3d90 <fwp_rc_forget_slot>
    a290:	e9 52 f8 ff ff       	jmp    9ae7 <f0+0x2517>
    a295:	4c 89 e7             	mov    %r12,%rdi
    a298:	e8 f3 9a ff ff       	call   3d90 <fwp_rc_forget_slot>
    a29d:	e9 e4 f8 ff ff       	jmp    9b86 <f0+0x25b6>
    a2a2:	4c 89 e7             	mov    %r12,%rdi
    a2a5:	e8 e6 9a ff ff       	call   3d90 <fwp_rc_forget_slot>
    a2aa:	e9 76 f9 ff ff       	jmp    9c25 <f0+0x2655>
    a2af:	4c 89 e7             	mov    %r12,%rdi
    a2b2:	e8 d9 9a ff ff       	call   3d90 <fwp_rc_forget_slot>
    a2b7:	e9 08 fa ff ff       	jmp    9cc4 <f0+0x26f4>
    a2bc:	4c 89 e7             	mov    %r12,%rdi
    a2bf:	e8 cc 9a ff ff       	call   3d90 <fwp_rc_forget_slot>
    a2c4:	e9 9a fa ff ff       	jmp    9d63 <f0+0x2793>
    a2c9:	e8 72 81 ff ff       	call   2440 <__stack_chk_fail@plt>
    a2ce:	66 90                	xchg   %ax,%ax

000000000000a2d0 <fwp_main_thread>:
    a2d0:	f3 0f 1e fa          	endbr64
    a2d4:	41 54                	push   %r12
    a2d6:	55                   	push   %rbp
    a2d7:	53                   	push   %rbx
    a2d8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    a2df:	8b 0d ff 47 01 00    	mov    0x147ff(%rip),%ecx        # 1eae4 <fwp_heap+0x13a4>
    a2e5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a2ec:	00 00 
    a2ee:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    a2f5:	00 
    a2f6:	31 c0                	xor    %eax,%eax
    a2f8:	85 c9                	test   %ecx,%ecx
    a2fa:	0f 84 68 06 00 00    	je     a968 <fwp_main_thread+0x698>
    a300:	8b 15 e2 47 01 00    	mov    0x147e2(%rip),%edx        # 1eae8 <fwp_heap+0x13a8>
    a306:	85 d2                	test   %edx,%edx
    a308:	0f 85 42 06 00 00    	jne    a950 <fwp_main_thread+0x680>
    a30e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    a313:	31 f6                	xor    %esi,%esi
    a315:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    a31a:	48 c7 05 c3 2d 01 00 	movq   $0x40000000,0x12dc3(%rip)        # 1d0e8 <fwp_main_stack_size>
    a321:	00 00 00 40 
    a325:	48 89 05 c4 2d 01 00 	mov    %rax,0x12dc4(%rip)        # 1d0f0 <fwp_main_stack_top>
    a32c:	48 8d 05 ad 2d 00 00 	lea    0x2dad(%rip),%rax        # d0e0 <alt.4>
    a333:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a338:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    a33f:	01 00 
    a341:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    a348:	00 
    a349:	e8 32 83 ff ff       	call   2680 <sigaltstack@plt>
    a34e:	85 c0                	test   %eax,%eax
    a350:	0f 85 4a 06 00 00    	jne    a9a0 <fwp_main_thread+0x6d0>
    a356:	31 c0                	xor    %eax,%eax
    a358:	b9 12 00 00 00       	mov    $0x12,%ecx
    a35d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    a362:	f3 48 ab             	rep stos %rax,(%rdi)
    a365:	48 8d 05 d4 88 ff ff 	lea    -0x772c(%rip),%rax        # 2c40 <fwp_segv>
    a36c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    a371:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    a378:	04 00 00 08 
    a37c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a381:	e8 ca 81 ff ff       	call   2550 <sigemptyset@plt>
    a386:	85 c0                	test   %eax,%eax
    a388:	0f 85 12 06 00 00    	jne    a9a0 <fwp_main_thread+0x6d0>
    a38e:	31 d2                	xor    %edx,%edx
    a390:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    a395:	bf 0b 00 00 00       	mov    $0xb,%edi
    a39a:	e8 41 80 ff ff       	call   23e0 <sigaction@plt>
    a39f:	85 c0                	test   %eax,%eax
    a3a1:	0f 85 f9 05 00 00    	jne    a9a0 <fwp_main_thread+0x6d0>
    a3a7:	31 d2                	xor    %edx,%edx
    a3a9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    a3ae:	bf 07 00 00 00       	mov    $0x7,%edi
    a3b3:	e8 28 80 ff ff       	call   23e0 <sigaction@plt>
    a3b8:	85 c0                	test   %eax,%eax
    a3ba:	0f 85 e0 05 00 00    	jne    a9a0 <fwp_main_thread+0x6d0>
    a3c0:	8b 05 02 2d 00 00    	mov    0x2d02(%rip),%eax        # d0c8 <st.2>
    a3c6:	85 c0                	test   %eax,%eax
    a3c8:	0f 84 62 05 00 00    	je     a930 <fwp_main_thread+0x660>
    a3ce:	48 8b 2d 4b 33 01 00 	mov    0x1334b(%rip),%rbp        # 1d720 <fwp_cur>
    a3d5:	48 85 ed             	test   %rbp,%rbp
    a3d8:	0f 84 72 03 00 00    	je     a750 <fwp_main_thread+0x480>
    a3de:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    a3e3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    a3e7:	48 89 eb             	mov    %rbp,%rbx
    a3ea:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    a3ef:	0f 84 41 01 00 00    	je     a536 <fwp_main_thread+0x266>
    a3f5:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    a3fa:	0f 84 80 02 00 00    	je     a680 <fwp_main_thread+0x3b0>
    a400:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a404:	0f 84 66 02 00 00    	je     a670 <fwp_main_thread+0x3a0>
    a40a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a40e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a412:	0f 85 e8 02 00 00    	jne    a700 <fwp_main_thread+0x430>
    a418:	48 8b 43 60          	mov    0x60(%rbx),%rax
    a41c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a423:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a427:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a42e:	00 00 00 00 
    a432:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a439:	48 85 d2             	test   %rdx,%rdx
    a43c:	74 07                	je     a445 <fwp_main_thread+0x175>
    a43e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a445:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a449:	48 85 c0             	test   %rax,%rax
    a44c:	74 34                	je     a482 <fwp_main_thread+0x1b2>
    a44e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    a452:	48 8b 05 9f 32 01 00 	mov    0x1329f(%rip),%rax        # 1d6f8 <fwp_timers>
    a459:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    a45d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    a464:	00 00 00 00 
    a468:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    a46f:	48 85 c0             	test   %rax,%rax
    a472:	74 07                	je     a47b <fwp_main_thread+0x1ab>
    a474:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    a47b:	48 89 1d 76 32 01 00 	mov    %rbx,0x13276(%rip)        # 1d6f8 <fwp_timers>
    a482:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    a486:	e8 e5 a6 ff ff       	call   4b70 <fwp_block>
    a48b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    a492:	48 85 c9             	test   %rcx,%rcx
    a495:	74 47                	je     a4de <fwp_main_thread+0x20e>
    a497:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    a49e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    a4a5:	48 85 d2             	test   %rdx,%rdx
    a4a8:	0f 84 92 02 00 00    	je     a740 <fwp_main_thread+0x470>
    a4ae:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    a4b5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    a4bc:	48 85 c0             	test   %rax,%rax
    a4bf:	74 07                	je     a4c8 <fwp_main_thread+0x1f8>
    a4c1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    a4c8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    a4cf:	00 00 00 00 
    a4d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a4d7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    a4de:	48 8b 0d 3b 32 01 00 	mov    0x1323b(%rip),%rcx        # 1d720 <fwp_cur>
    a4e5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    a4e9:	0f 84 01 02 00 00    	je     a6f0 <fwp_main_thread+0x420>
    a4ef:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    a4f6:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    a4fd:	48 85 d2             	test   %rdx,%rdx
    a500:	0f 84 fa 03 00 00    	je     a900 <fwp_main_thread+0x630>
    a506:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    a50d:	48 85 c0             	test   %rax,%rax
    a510:	74 07                	je     a519 <fwp_main_thread+0x249>
    a512:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    a519:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a51d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    a521:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    a528:	48 89 cb             	mov    %rcx,%rbx
    a52b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    a530:	0f 85 bf fe ff ff    	jne    a3f5 <fwp_main_thread+0x125>
    a536:	48 83 3d 72 4e 01 00 	cmpq   $0x0,0x14e72(%rip)        # 1f3b0 <fwp_state_len>
    a53d:	00 
    a53e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    a542:	0f 84 ba 00 00 00    	je     a602 <fwp_main_thread+0x332>
    a548:	48 39 1d c9 31 01 00 	cmp    %rbx,0x131c9(%rip)        # 1d718 <fwp_root>
    a54f:	c7 05 87 2b 01 00 00 	movl   $0x0,0x12b87(%rip)        # 1d0e0 <fwp_exit_code>
    a556:	00 00 00 
    a559:	0f 85 5f 04 00 00    	jne    a9be <fwp_main_thread+0x6ee>
    a55f:	48 85 db             	test   %rbx,%rbx
    a562:	0f 84 0e 02 00 00    	je     a776 <fwp_main_thread+0x4a6>
    a568:	48 8b 15 79 31 01 00 	mov    0x13179(%rip),%rdx        # 1d6e8 <fwp_tasks_active>
    a56f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    a573:	48 85 d2             	test   %rdx,%rdx
    a576:	0f 84 fa 01 00 00    	je     a776 <fwp_main_thread+0x4a6>
    a57c:	0f 1f 40 00          	nopl   0x0(%rax)
    a580:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    a584:	75 08                	jne    a58e <fwp_main_thread+0x2be>
    a586:	48 89 d7             	mov    %rdx,%rdi
    a589:	e8 32 8a ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    a58e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    a595:	48 85 d2             	test   %rdx,%rdx
    a598:	75 e6                	jne    a580 <fwp_main_thread+0x2b0>
    a59a:	eb 31                	jmp    a5cd <fwp_main_thread+0x2fd>
    a59c:	0f 1f 40 00          	nopl   0x0(%rax)
    a5a0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    a5a7:	48 89 1d 52 31 01 00 	mov    %rbx,0x13152(%rip)        # 1d700 <fwp_ready_tail>
    a5ae:	e8 bd a5 ff ff       	call   4b70 <fwp_block>
    a5b3:	e8 b8 a3 ff ff       	call   4970 <fwp_free_zombie>
    a5b8:	48 83 3d 28 31 01 00 	cmpq   $0x0,0x13128(%rip)        # 1d6e8 <fwp_tasks_active>
    a5bf:	00 
    a5c0:	0f 84 b0 01 00 00    	je     a776 <fwp_main_thread+0x4a6>
    a5c6:	48 8b 1d 4b 31 01 00 	mov    0x1314b(%rip),%rbx        # 1d718 <fwp_root>
    a5cd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    a5d1:	75 db                	jne    a5ae <fwp_main_thread+0x2de>
    a5d3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    a5d7:	75 d5                	jne    a5ae <fwp_main_thread+0x2de>
    a5d9:	48 8b 05 20 31 01 00 	mov    0x13120(%rip),%rax        # 1d700 <fwp_ready_tail>
    a5e0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    a5e4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    a5eb:	00 00 00 00 
    a5ef:	48 85 c0             	test   %rax,%rax
    a5f2:	75 ac                	jne    a5a0 <fwp_main_thread+0x2d0>
    a5f4:	48 89 1d 0d 31 01 00 	mov    %rbx,0x1310d(%rip)        # 1d708 <fwp_ready_head>
    a5fb:	eb aa                	jmp    a5a7 <fwp_main_thread+0x2d7>
    a5fd:	0f 1f 00             	nopl   (%rax)
    a600:	31 db                	xor    %ebx,%ebx
    a602:	48 83 3d 96 4d 01 00 	cmpq   $0x0,0x14d96(%rip)        # 1f3a0 <fwp_state_owners>
    a609:	00 
    a60a:	0f 85 38 ff ff ff    	jne    a548 <fwp_main_thread+0x278>
    a610:	48 8b 3d a1 4d 01 00 	mov    0x14da1(%rip),%rdi        # 1f3b8 <fwp_state>
    a617:	e8 b4 99 ff ff       	call   3fd0 <fwp_mem_free>
    a61c:	48 c7 05 91 4d 01 00 	movq   $0x0,0x14d91(%rip)        # 1f3b8 <fwp_state>
    a623:	00 00 00 00 
    a627:	48 c7 05 76 4d 01 00 	movq   $0x0,0x14d76(%rip)        # 1f3a8 <fwp_state_cap>
    a62e:	00 00 00 00 
    a632:	48 85 db             	test   %rbx,%rbx
    a635:	0f 84 46 03 00 00    	je     a981 <fwp_main_thread+0x6b1>
    a63b:	48 39 1d d6 30 01 00 	cmp    %rbx,0x130d6(%rip)        # 1d718 <fwp_root>
    a642:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    a649:	00 00 00 00 
    a64d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    a654:	00 00 00 00 
    a658:	c7 05 7e 2a 01 00 00 	movl   $0x0,0x12a7e(%rip)        # 1d0e0 <fwp_exit_code>
    a65f:	00 00 00 
    a662:	0f 84 00 ff ff ff    	je     a568 <fwp_main_thread+0x298>
    a668:	e9 a3 80 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a66d:	0f 1f 00             	nopl   (%rax)
    a670:	e8 6b 8a ff ff       	call   30e0 <fwp_now_ns>
    a675:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a679:	0f 8d 91 02 00 00    	jge    a910 <fwp_main_thread+0x640>
    a67f:	90                   	nop
    a680:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a684:	0f 85 80 fd ff ff    	jne    a40a <fwp_main_thread+0x13a>
    a68a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a68e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a692:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a696:	0f 85 80 fd ff ff    	jne    a41c <fwp_main_thread+0x14c>
    a69c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a6a0:	48 85 c9             	test   %rcx,%rcx
    a6a3:	0f 84 73 fd ff ff    	je     a41c <fwp_main_thread+0x14c>
    a6a9:	48 85 c0             	test   %rax,%rax
    a6ac:	0f 84 ff 02 00 00    	je     a9b1 <fwp_main_thread+0x6e1>
    a6b2:	48 39 c8             	cmp    %rcx,%rax
    a6b5:	48 0f 4f c1          	cmovg  %rcx,%rax
    a6b9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a6c0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a6c4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a6cb:	00 00 00 00 
    a6cf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a6d6:	48 85 d2             	test   %rdx,%rdx
    a6d9:	74 07                	je     a6e2 <fwp_main_thread+0x412>
    a6db:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a6e2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a6e6:	e9 63 fd ff ff       	jmp    a44e <fwp_main_thread+0x17e>
    a6eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a6f0:	48 89 cb             	mov    %rcx,%rbx
    a6f3:	e9 f2 fc ff ff       	jmp    a3ea <fwp_main_thread+0x11a>
    a6f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a6ff:	00 
    a700:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a704:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a70b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a712:	00 00 00 00 
    a716:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a71d:	48 85 c0             	test   %rax,%rax
    a720:	0f 84 52 02 00 00    	je     a978 <fwp_main_thread+0x6a8>
    a726:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a72d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a731:	e9 4c fd ff ff       	jmp    a482 <fwp_main_thread+0x1b2>
    a736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a73d:	00 00 00 
    a740:	48 89 01             	mov    %rax,(%rcx)
    a743:	e9 74 fd ff ff       	jmp    a4bc <fwp_main_thread+0x1ec>
    a748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a74f:	00 
    a750:	48 83 3d 58 4c 01 00 	cmpq   $0x0,0x14c58(%rip)        # 1f3b0 <fwp_state_len>
    a757:	00 
    a758:	0f 84 a2 fe ff ff    	je     a600 <fwp_main_thread+0x330>
    a75e:	48 83 3d b2 2f 01 00 	cmpq   $0x0,0x12fb2(%rip)        # 1d718 <fwp_root>
    a765:	00 
    a766:	c7 05 70 29 01 00 00 	movl   $0x0,0x12970(%rip)        # 1d0e0 <fwp_exit_code>
    a76d:	00 00 00 
    a770:	0f 85 43 02 00 00    	jne    a9b9 <fwp_main_thread+0x6e9>
    a776:	e8 f5 a1 ff ff       	call   4970 <fwp_free_zombie>
    a77b:	48 83 3d 85 2f 01 00 	cmpq   $0x0,0x12f85(%rip)        # 1d708 <fwp_ready_head>
    a782:	00 
    a783:	0f 85 87 7f ff ff    	jne    2710 <fwp_main_thread.cold>
    a789:	48 83 3d 67 2f 01 00 	cmpq   $0x0,0x12f67(%rip)        # 1d6f8 <fwp_timers>
    a790:	00 
    a791:	0f 85 79 7f ff ff    	jne    2710 <fwp_main_thread.cold>
    a797:	8b 1d 5f 29 01 00    	mov    0x1295f(%rip),%ebx        # 1d0fc <fwp_stack_pool_n>
    a79d:	85 db                	test   %ebx,%ebx
    a79f:	74 36                	je     a7d7 <fwp_main_thread+0x507>
    a7a1:	83 eb 01             	sub    $0x1,%ebx
    a7a4:	48 8d 05 55 29 01 00 	lea    0x12955(%rip),%rax        # 1d100 <fwp_stack_pool>
    a7ab:	48 63 d3             	movslq %ebx,%rdx
    a7ae:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    a7b2:	eb 07                	jmp    a7bb <fwp_main_thread+0x4eb>
    a7b4:	0f 1f 40 00          	nopl   0x0(%rax)
    a7b8:	83 eb 01             	sub    $0x1,%ebx
    a7bb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a7bf:	be 00 00 00 10       	mov    $0x10000000,%esi
    a7c4:	89 1d 32 29 01 00    	mov    %ebx,0x12932(%rip)        # 1d0fc <fwp_stack_pool_n>
    a7ca:	48 83 ed 08          	sub    $0x8,%rbp
    a7ce:	e8 dd 7d ff ff       	call   25b0 <munmap@plt>
    a7d3:	85 db                	test   %ebx,%ebx
    a7d5:	75 e1                	jne    a7b8 <fwp_main_thread+0x4e8>
    a7d7:	8b 3d 83 28 00 00    	mov    0x2883(%rip),%edi        # d060 <fwp_epfd>
    a7dd:	85 ff                	test   %edi,%edi
    a7df:	78 05                	js     a7e6 <fwp_main_thread+0x516>
    a7e1:	e8 ca 7c ff ff       	call   24b0 <close@plt>
    a7e6:	4c 8b 25 13 2b 01 00 	mov    0x12b13(%rip),%r12        # 1d300 <fwp_nfdws>
    a7ed:	48 8b 2d 14 2b 01 00 	mov    0x12b14(%rip),%rbp        # 1d308 <fwp_fdws>
    a7f4:	31 db                	xor    %ebx,%ebx
    a7f6:	c7 05 60 28 00 00 ff 	movl   $0xffffffff,0x2860(%rip)        # d060 <fwp_epfd>
    a7fd:	ff ff ff 
    a800:	4d 85 e4             	test   %r12,%r12
    a803:	74 38                	je     a83d <fwp_main_thread+0x56d>
    a805:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a80c:	00 00 00 00 
    a810:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    a815:	48 85 ff             	test   %rdi,%rdi
    a818:	74 1a                	je     a834 <fwp_main_thread+0x564>
    a81a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    a81e:	0f 85 ec 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a824:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    a829:	0f 85 e1 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a82f:	e8 9c 97 ff ff       	call   3fd0 <fwp_mem_free>
    a834:	48 83 c3 01          	add    $0x1,%rbx
    a838:	4c 39 e3             	cmp    %r12,%rbx
    a83b:	75 d3                	jne    a810 <fwp_main_thread+0x540>
    a83d:	48 89 ef             	mov    %rbp,%rdi
    a840:	e8 8b 97 ff ff       	call   3fd0 <fwp_mem_free>
    a845:	48 8b 15 cc 2e 01 00 	mov    0x12ecc(%rip),%rdx        # 1d718 <fwp_root>
    a84c:	48 c7 05 b1 2a 01 00 	movq   $0x0,0x12ab1(%rip)        # 1d308 <fwp_fdws>
    a853:	00 00 00 00 
    a857:	48 c7 05 9e 2a 01 00 	movq   $0x0,0x12a9e(%rip)        # 1d300 <fwp_nfdws>
    a85e:	00 00 00 00 
    a862:	48 85 d2             	test   %rdx,%rdx
    a865:	74 4e                	je     a8b5 <fwp_main_thread+0x5e5>
    a867:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    a86c:	0f 85 9e 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a872:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    a879:	00 
    a87a:	0f 85 90 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a880:	48 83 3d 28 4b 01 00 	cmpq   $0x0,0x14b28(%rip)        # 1f3b0 <fwp_state_len>
    a887:	00 
    a888:	0f 85 82 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a88e:	48 83 3d 0a 4b 01 00 	cmpq   $0x0,0x14b0a(%rip)        # 1f3a0 <fwp_state_owners>
    a895:	00 
    a896:	0f 85 74 7e ff ff    	jne    2710 <fwp_main_thread.cold>
    a89c:	b9 79 00 00 00       	mov    $0x79,%ecx
    a8a1:	31 c0                	xor    %eax,%eax
    a8a3:	48 8d 3d 76 2a 01 00 	lea    0x12a76(%rip),%rdi        # 1d320 <fwp_root_context>
    a8aa:	f3 48 ab             	rep stos %rax,(%rdi)
    a8ad:	48 89 d7             	mov    %rdx,%rdi
    a8b0:	e8 1b 97 ff ff       	call   3fd0 <fwp_mem_free>
    a8b5:	48 8b 3d c4 27 00 00 	mov    0x27c4(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    a8bc:	48 c7 05 59 2e 01 00 	movq   $0x0,0x12e59(%rip)        # 1d720 <fwp_cur>
    a8c3:	00 00 00 00 
    a8c7:	48 c7 05 46 2e 01 00 	movq   $0x0,0x12e46(%rip)        # 1d718 <fwp_root>
    a8ce:	00 00 00 00 
    a8d2:	e8 b9 7c ff ff       	call   2590 <fflush@plt>
    a8d7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    a8de:	00 
    a8df:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a8e6:	00 00 
    a8e8:	0f 85 be 00 00 00    	jne    a9ac <fwp_main_thread+0x6dc>
    a8ee:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    a8f5:	31 c0                	xor    %eax,%eax
    a8f7:	5b                   	pop    %rbx
    a8f8:	5d                   	pop    %rbp
    a8f9:	41 5c                	pop    %r12
    a8fb:	c3                   	ret
    a8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a900:	48 89 05 f1 2d 01 00 	mov    %rax,0x12df1(%rip)        # 1d6f8 <fwp_timers>
    a907:	e9 01 fc ff ff       	jmp    a50d <fwp_main_thread+0x23d>
    a90c:	0f 1f 40 00          	nopl   0x0(%rax)
    a910:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a914:	0f 85 66 fd ff ff    	jne    a680 <fwp_main_thread+0x3b0>
    a91a:	48 89 ef             	mov    %rbp,%rdi
    a91d:	e8 9e 86 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    a922:	e9 59 fd ff ff       	jmp    a680 <fwp_main_thread+0x3b0>
    a927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a92e:	00 00 
    a930:	e8 9b cc ff ff       	call   75d0 <f0>
    a935:	48 c7 05 80 27 00 00 	movq   $0x0,0x2780(%rip)        # d0c0 <v.1>
    a93c:	00 00 00 00 
    a940:	c7 05 7e 27 00 00 01 	movl   $0x1,0x277e(%rip)        # d0c8 <st.2>
    a947:	00 00 00 
    a94a:	e9 7f fa ff ff       	jmp    a3ce <fwp_main_thread+0xfe>
    a94f:	90                   	nop
    a950:	48 8d 3d 89 8d ff ff 	lea    -0x7277(%rip),%rdi        # 36e0 <fwp_heap_report>
    a957:	e8 84 02 00 00       	call   abe0 <atexit>
    a95c:	e9 ad f9 ff ff       	jmp    a30e <fwp_main_thread+0x3e>
    a961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a968:	e8 83 8e ff ff       	call   37f0 <fwp_heap_init>
    a96d:	e9 8e f9 ff ff       	jmp    a300 <fwp_main_thread+0x30>
    a972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a978:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a97c:	e9 01 fb ff ff       	jmp    a482 <fwp_main_thread+0x1b2>
    a981:	48 83 3d 8f 2d 01 00 	cmpq   $0x0,0x12d8f(%rip)        # 1d718 <fwp_root>
    a988:	00 
    a989:	c7 05 4d 27 01 00 00 	movl   $0x0,0x1274d(%rip)        # 1d0e0 <fwp_exit_code>
    a990:	00 00 00 
    a993:	0f 84 dd fd ff ff    	je     a776 <fwp_main_thread+0x4a6>
    a999:	e9 72 7d ff ff       	jmp    2710 <fwp_main_thread.cold>
    a99e:	66 90                	xchg   %ax,%ax
    a9a0:	48 8d 3d 59 09 00 00 	lea    0x959(%rip),%rdi        # b300 <_IO_stdin_used+0x300>
    a9a7:	e8 04 87 ff ff       	call   30b0 <fwp_trap>
    a9ac:	e8 8f 7a ff ff       	call   2440 <__stack_chk_fail@plt>
    a9b1:	48 89 c8             	mov    %rcx,%rax
    a9b4:	e9 00 fd ff ff       	jmp    a6b9 <fwp_main_thread+0x3e9>
    a9b9:	e9 52 7d ff ff       	jmp    2710 <fwp_main_thread.cold>
    a9be:	e9 4d 7d ff ff       	jmp    2710 <fwp_main_thread.cold>
    a9c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9ca:	00 00 00 
    a9cd:	0f 1f 00             	nopl   (%rax)

000000000000a9d0 <__divmodti4>:
    a9d0:	f3 0f 1e fa          	endbr64
    a9d4:	55                   	push   %rbp
    a9d5:	49 89 f1             	mov    %rsi,%r9
    a9d8:	49 89 d2             	mov    %rdx,%r10
    a9db:	48 89 fe             	mov    %rdi,%rsi
    a9de:	49 89 cb             	mov    %rcx,%r11
    a9e1:	48 89 e5             	mov    %rsp,%rbp
    a9e4:	41 57                	push   %r15
    a9e6:	41 56                	push   %r14
    a9e8:	41 55                	push   %r13
    a9ea:	41 54                	push   %r12
    a9ec:	53                   	push   %rbx
    a9ed:	4c 89 c3             	mov    %r8,%rbx
    a9f0:	45 31 c0             	xor    %r8d,%r8d
    a9f3:	4d 85 c9             	test   %r9,%r9
    a9f6:	79 12                	jns    aa0a <__divmodti4+0x3a>
    a9f8:	31 ff                	xor    %edi,%edi
    a9fa:	48 f7 de             	neg    %rsi
    a9fd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    aa04:	4c 19 cf             	sbb    %r9,%rdi
    aa07:	49 89 f9             	mov    %rdi,%r9
    aa0a:	4c 89 d8             	mov    %r11,%rax
    aa0d:	4d 85 db             	test   %r11,%r11
    aa10:	0f 88 1a 01 00 00    	js     ab30 <__divmodti4+0x160>
    aa16:	4c 89 d9             	mov    %r11,%rcx
    aa19:	49 89 f3             	mov    %rsi,%r11
    aa1c:	75 62                	jne    aa80 <__divmodti4+0xb0>
    aa1e:	4d 89 c4             	mov    %r8,%r12
    aa21:	4d 39 d1             	cmp    %r10,%r9
    aa24:	0f 83 46 01 00 00    	jae    ab70 <__divmodti4+0x1a0>
    aa2a:	4c 89 d8             	mov    %r11,%rax
    aa2d:	4c 89 ca             	mov    %r9,%rdx
    aa30:	49 f7 f2             	div    %r10
    aa33:	49 89 c3             	mov    %rax,%r11
    aa36:	31 c0                	xor    %eax,%eax
    aa38:	48 89 d6             	mov    %rdx,%rsi
    aa3b:	31 ff                	xor    %edi,%edi
    aa3d:	4c 89 d9             	mov    %r11,%rcx
    aa40:	48 89 c2             	mov    %rax,%rdx
    aa43:	48 89 c8             	mov    %rcx,%rax
    aa46:	4d 85 e4             	test   %r12,%r12
    aa49:	74 0a                	je     aa55 <__divmodti4+0x85>
    aa4b:	48 f7 d8             	neg    %rax
    aa4e:	48 83 d2 00          	adc    $0x0,%rdx
    aa52:	48 f7 da             	neg    %rdx
    aa55:	4d 85 c0             	test   %r8,%r8
    aa58:	74 0a                	je     aa64 <__divmodti4+0x94>
    aa5a:	48 f7 de             	neg    %rsi
    aa5d:	48 83 d7 00          	adc    $0x0,%rdi
    aa61:	48 f7 df             	neg    %rdi
    aa64:	48 89 33             	mov    %rsi,(%rbx)
    aa67:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    aa6b:	5b                   	pop    %rbx
    aa6c:	41 5c                	pop    %r12
    aa6e:	41 5d                	pop    %r13
    aa70:	41 5e                	pop    %r14
    aa72:	41 5f                	pop    %r15
    aa74:	5d                   	pop    %rbp
    aa75:	c3                   	ret
    aa76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa7d:	00 00 00 
    aa80:	4d 89 c4             	mov    %r8,%r12
    aa83:	49 39 c1             	cmp    %rax,%r9
    aa86:	0f 82 ce 00 00 00    	jb     ab5a <__divmodti4+0x18a>
    aa8c:	31 ff                	xor    %edi,%edi
    aa8e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    aa93:	48 63 c7             	movslq %edi,%rax
    aa96:	be 40 00 00 00       	mov    $0x40,%esi
    aa9b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    aaa0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    aaa5:	48 29 c6             	sub    %rax,%rsi
    aaa8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    aaad:	48 09 c8             	or     %rcx,%rax
    aab0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    aab5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    aaba:	49 89 c6             	mov    %rax,%r14
    aabd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aac1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    aac6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    aacb:	49 09 c1             	or     %rax,%r9
    aace:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    aad2:	4c 89 c8             	mov    %r9,%rax
    aad5:	49 f7 f6             	div    %r14
    aad8:	48 89 d1             	mov    %rdx,%rcx
    aadb:	49 89 c3             	mov    %rax,%r11
    aade:	49 89 c1             	mov    %rax,%r9
    aae1:	49 f7 e2             	mul    %r10
    aae4:	49 89 c6             	mov    %rax,%r14
    aae7:	49 89 d2             	mov    %rdx,%r10
    aaea:	48 39 d1             	cmp    %rdx,%rcx
    aaed:	72 07                	jb     aaf6 <__divmodti4+0x126>
    aaef:	75 17                	jne    ab08 <__divmodti4+0x138>
    aaf1:	49 39 c7             	cmp    %rax,%r15
    aaf4:	73 12                	jae    ab08 <__divmodti4+0x138>
    aaf6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    aafa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    aafe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ab02:	49 89 d2             	mov    %rdx,%r10
    ab05:	49 89 c6             	mov    %rax,%r14
    ab08:	4c 89 f8             	mov    %r15,%rax
    ab0b:	4c 29 f0             	sub    %r14,%rax
    ab0e:	4c 19 d1             	sbb    %r10,%rcx
    ab11:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ab16:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ab1b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ab20:	48 09 c6             	or     %rax,%rsi
    ab23:	48 89 cf             	mov    %rcx,%rdi
    ab26:	31 c0                	xor    %eax,%eax
    ab28:	4c 89 c9             	mov    %r9,%rcx
    ab2b:	e9 10 ff ff ff       	jmp    aa40 <__divmodti4+0x70>
    ab30:	4c 89 d0             	mov    %r10,%rax
    ab33:	4c 89 da             	mov    %r11,%rdx
    ab36:	4d 89 c4             	mov    %r8,%r12
    ab39:	49 89 f3             	mov    %rsi,%r11
    ab3c:	48 f7 d8             	neg    %rax
    ab3f:	49 f7 d4             	not    %r12
    ab42:	48 83 d2 00          	adc    $0x0,%rdx
    ab46:	49 89 c2             	mov    %rax,%r10
    ab49:	48 f7 da             	neg    %rdx
    ab4c:	48 89 d1             	mov    %rdx,%rcx
    ab4f:	0f 84 cc fe ff ff    	je     aa21 <__divmodti4+0x51>
    ab55:	49 39 d1             	cmp    %rdx,%r9
    ab58:	73 46                	jae    aba0 <__divmodti4+0x1d0>
    ab5a:	4c 89 cf             	mov    %r9,%rdi
    ab5d:	31 c0                	xor    %eax,%eax
    ab5f:	31 c9                	xor    %ecx,%ecx
    ab61:	e9 da fe ff ff       	jmp    aa40 <__divmodti4+0x70>
    ab66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab6d:	00 00 00 
    ab70:	4d 85 d2             	test   %r10,%r10
    ab73:	75 0d                	jne    ab82 <__divmodti4+0x1b2>
    ab75:	b8 01 00 00 00       	mov    $0x1,%eax
    ab7a:	31 d2                	xor    %edx,%edx
    ab7c:	49 f7 f2             	div    %r10
    ab7f:	49 89 c2             	mov    %rax,%r10
    ab82:	4c 89 c8             	mov    %r9,%rax
    ab85:	31 d2                	xor    %edx,%edx
    ab87:	49 f7 f2             	div    %r10
    ab8a:	49 89 c1             	mov    %rax,%r9
    ab8d:	4c 89 d8             	mov    %r11,%rax
    ab90:	49 f7 f2             	div    %r10
    ab93:	49 89 c3             	mov    %rax,%r11
    ab96:	4c 89 c8             	mov    %r9,%rax
    ab99:	e9 9a fe ff ff       	jmp    aa38 <__divmodti4+0x68>
    ab9e:	66 90                	xchg   %ax,%ax
    aba0:	45 31 f6             	xor    %r14d,%r14d
    aba3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    aba8:	44 89 f7             	mov    %r14d,%edi
    abab:	45 85 f6             	test   %r14d,%r14d
    abae:	0f 85 df fe ff ff    	jne    aa93 <__divmodti4+0xc3>
    abb4:	4c 39 ca             	cmp    %r9,%rdx
    abb7:	72 17                	jb     abd0 <__divmodti4+0x200>
    abb9:	31 c9                	xor    %ecx,%ecx
    abbb:	48 39 c6             	cmp    %rax,%rsi
    abbe:	73 10                	jae    abd0 <__divmodti4+0x200>
    abc0:	4c 89 cf             	mov    %r9,%rdi
    abc3:	31 c0                	xor    %eax,%eax
    abc5:	e9 76 fe ff ff       	jmp    aa40 <__divmodti4+0x70>
    abca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abd0:	4c 89 de             	mov    %r11,%rsi
    abd3:	b9 01 00 00 00       	mov    $0x1,%ecx
    abd8:	48 29 c6             	sub    %rax,%rsi
    abdb:	49 19 d1             	sbb    %rdx,%r9
    abde:	eb e0                	jmp    abc0 <__divmodti4+0x1f0>

000000000000abe0 <atexit>:
    abe0:	f3 0f 1e fa          	endbr64
    abe4:	48 8b 15 1d 24 00 00 	mov    0x241d(%rip),%rdx        # d008 <__dso_handle>
    abeb:	31 f6                	xor    %esi,%esi
    abed:	e9 2e 7a ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000abf4 <_fini>:
    abf4:	f3 0f 1e fa          	endbr64
    abf8:	48 83 ec 08          	sub    $0x8,%rsp
    abfc:	48 83 c4 08          	add    $0x8,%rsp
    ac00:	c3                   	ret
