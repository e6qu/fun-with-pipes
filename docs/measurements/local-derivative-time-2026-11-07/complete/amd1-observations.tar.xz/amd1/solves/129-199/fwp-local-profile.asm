
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # dfd8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # de18 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # de20 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 6e bc 00 00    	jmp    *0xbc6e(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 9e ba 00 00    	jmp    *0xba9e(%rip)        # de28 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 96 ba 00 00    	jmp    *0xba96(%rip)        # de30 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # de38 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # de40 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # de48 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # de50 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # de58 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # de60 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # de68 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # de70 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # de78 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # de80 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # de88 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # de90 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # de98 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # dea0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # dea8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # deb0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # deb8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # dec0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # dec8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ded0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ded8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # dee0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # dee8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # def0 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # def8 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # df00 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # df08 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # df10 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # df18 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # df20 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # df28 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # df30 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # df38 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # df40 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # df48 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # df50 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # df58 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # df60 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # df68 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # df70 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # df78 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # df80 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # df88 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # df90 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # df98 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # dfa0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # dfa8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # dfb0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # dfb8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # dfc0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 89 00 00 	lea    0x89e0(%rip),%r9        # b0b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 89 00 00 	lea    0x89dd(%rip),%r8        # b0bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 fa 0a 00 00       	call   3200 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 41 b9 00 00 	mov    0xb941(%rip),%rax        # e080 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 72 dc 01 00 	mov    %rax,0x1dc72(%rip)        # 203b8 <fwp_prog_out>
    2746:	e8 e5 0a 00 00       	call   3230 <fwp_now_ns>
    274b:	48 8d 3d 77 8a 00 00 	lea    0x8a77(%rip),%rdi        # b1c9 <_IO_stdin_used+0x1c9>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d c6 b8 00 00 	mov    0xb8c6(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 9d 7d 00 00 	lea    0x7d9d(%rip),%rdx        # a5b0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 31 b8 00 00 	mov    0xb831(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 86 b8 01 00    	mov    0x1b886(%rip),%eax        # 1e0e0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 27 89 00 00 	lea    0x8927(%rip),%rdi        # b1d2 <_IO_stdin_used+0x1d2>
    28ab:	e8 50 09 00 00       	call   3200 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 74 8c 00 00 	lea    0x8c74(%rip),%rdi        # b530 <_IO_stdin_used+0x530>
    28bc:	e8 3f 09 00 00       	call   3200 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d 2e 8c 00 00 	lea    0x8c2e(%rip),%rdi        # b508 <_IO_stdin_used+0x508>
    28da:	e8 21 09 00 00       	call   3200 <fwp_trap>
    28df:	48 8d 3d f2 8b 00 00 	lea    0x8bf2(%rip),%rdi        # b4d8 <_IO_stdin_used+0x4d8>
    28e6:	e8 15 09 00 00       	call   3200 <fwp_trap>
    28eb:	48 8d 3d be 8b 00 00 	lea    0x8bbe(%rip),%rdi        # b4b0 <_IO_stdin_used+0x4b0>
    28f2:	e8 09 09 00 00       	call   3200 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 a3 b6 00 00    	call   *0xb6a3(%rip)        # dfc8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 31 b7 00 00 	lea    0xb731(%rip),%rdi        # e068 <__TMC_END__>
    2937:	48 8d 05 2a b7 00 00 	lea    0xb72a(%rip),%rax        # e068 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 86 b6 00 00 	mov    0xb686(%rip),%rax        # dfd0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d 01 b7 00 00 	lea    0xb701(%rip),%rdi        # e068 <__TMC_END__>
    2967:	48 8d 35 fa b6 00 00 	lea    0xb6fa(%rip),%rsi        # e068 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 55 b6 00 00 	mov    0xb655(%rip),%rax        # dfe0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d fd b6 00 00 00 	cmpb   $0x0,0xb6fd(%rip)        # e0a8 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 32 b6 00 00 	cmpq   $0x0,0xb632(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 b6 00 00 	mov    0xb646(%rip),%rdi        # e008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 d5 b6 00 00 01 	movb   $0x1,0xb6d5(%rip)        # e0a8 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d f1 d7 01 00 	mov    0x1d7f1(%rip),%rdi        # 203b8 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d a4 b4 00 00 	mov    0xb4a4(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 91 b4 00 00 	mov    0xb491(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_segv>:
    2c00:	f3 0f 1e fa          	endbr64
    2c04:	48 83 ec 28          	sub    $0x28,%rsp
    2c08:	48 8b 05 31 bb 01 00 	mov    0x1bb31(%rip),%rax        # 1e740 <fwp_cur>
    2c0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c13:	41 89 f8             	mov    %edi,%r8d
    2c16:	48 85 c0             	test   %rax,%rax
    2c19:	74 6d                	je     2c88 <fwp_segv+0x88>
    2c1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c1f:	48 85 d2             	test   %rdx,%rdx
    2c22:	74 64                	je     2c88 <fwp_segv+0x88>
    2c24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c37:	e8 c4 f9 ff ff       	call   2600 <sysconf@plt>
    2c3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c4b:	48 01 d0             	add    %rdx,%rax
    2c4e:	48 39 c1             	cmp    %rax,%rcx
    2c51:	b8 00 00 00 00       	mov    $0x0,%eax
    2c56:	40 0f 92 c6          	setb   %sil
    2c5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2c61:	48 0f 42 d0          	cmovb  %rax,%rdx
    2c65:	31 c0                	xor    %eax,%eax
    2c67:	48 39 d1             	cmp    %rdx,%rcx
    2c6a:	0f 93 c0             	setae  %al
    2c6d:	21 f0                	and    %esi,%eax
    2c6f:	85 c0                	test   %eax,%eax
    2c71:	75 4a                	jne    2cbd <fwp_segv+0xbd>
    2c73:	31 f6                	xor    %esi,%esi
    2c75:	44 89 c7             	mov    %r8d,%edi
    2c78:	48 83 c4 28          	add    $0x28,%rsp
    2c7c:	e9 9f f8 ff ff       	jmp    2520 <signal@plt>
    2c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2c88:	48 8b 05 69 b4 01 00 	mov    0x1b469(%rip),%rax        # 1e0f8 <fwp_main_stack_top>
    2c8f:	48 85 c0             	test   %rax,%rax
    2c92:	74 df                	je     2c73 <fwp_segv+0x73>
    2c94:	48 2b 05 55 b4 01 00 	sub    0x1b455(%rip),%rax        # 1e0f0 <fwp_main_stack_size>
    2c9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ca2:	48 39 d1             	cmp    %rdx,%rcx
    2ca5:	0f 93 c2             	setae  %dl
    2ca8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cae:	48 39 c1             	cmp    %rax,%rcx
    2cb1:	0f 92 c0             	setb   %al
    2cb4:	0f b6 c0             	movzbl %al,%eax
    2cb7:	21 d0                	and    %edx,%eax
    2cb9:	85 c0                	test   %eax,%eax
    2cbb:	74 b6                	je     2c73 <fwp_segv+0x73>
    2cbd:	e8 fe fe ff ff       	call   2bc0 <fwp_flush>
    2cc2:	bf 02 00 00 00       	mov    $0x2,%edi
    2cc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2ccc:	48 8d 35 fd 88 00 00 	lea    0x88fd(%rip),%rsi        # b5d0 <msg.3>
    2cd3:	e8 38 f7 ff ff       	call   2410 <write@plt>
    2cd8:	bf 65 00 00 00       	mov    $0x65,%edi
    2cdd:	e8 de f6 ff ff       	call   23c0 <_exit@plt>
    2ce2:	0f 1f 00             	nopl   (%rax)
    2ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cec:	00 00 00 00 

0000000000002cf0 <fwp_heap_oom>:
    2cf0:	50                   	push   %rax
    2cf1:	58                   	pop    %rax
    2cf2:	ba 13 00 00 00       	mov    $0x13,%edx
    2cf7:	be 01 00 00 00       	mov    $0x1,%esi
    2cfc:	48 8d 3d 05 83 00 00 	lea    0x8305(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2d03:	48 83 ec 08          	sub    $0x8,%rsp
    2d07:	48 8b 0d 92 b3 00 00 	mov    0xb392(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    2d0e:	e8 2d f9 ff ff       	call   2640 <fwrite@plt>
    2d13:	31 ff                	xor    %edi,%edi
    2d15:	e8 76 f8 ff ff       	call   2590 <fflush@plt>
    2d1a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d1f:	e8 3c f9 ff ff       	call   2660 <_Exit@plt>
    2d24:	90                   	nop
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 0b ce 01 00 	mov    0x1ce0b(%rip),%rax        # 1fb50 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 04 ce 01 00 	lea    0x1ce04(%rip),%r8        # 1fb50 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d e5 cd 01 00 	mov    0x1cde5(%rip),%rbx        # 1fb38 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d f5 cd 01 00 	mov    0x1cdf5(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 91 cd 01 00 	mov    0x1cd91(%rip),%rdi        # 1fb40 <fwp_heap+0x13e0>
    2daf:	48 29 35 da cd 01 00 	sub    %rsi,0x1cdda(%rip)        # 1fb90 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 6a cd 01 00 	mov    0x1cd6a(%rip),%rax        # 1fb30 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 20 cd 01 00 	add    0x1cd20(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 2e cd 01 00 	mov    0x1cd2e(%rip),%rsi        # 1fb40 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 3c cd 01 00 	mov    0x1cd3c(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 eb cc 01 00 	mov    %r12,0x1cceb(%rip)        # 1fb40 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d d9 cc 01 00 	mov    %rbp,0x1ccd9(%rip)        # 1fb38 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d be cc 01 00 	cmp    %rdi,0x1ccbe(%rip)        # 1fb28 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d b5 cc 01 00 	mov    %rdi,0x1ccb5(%rip)        # 1fb28 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d f9 cc 01 00 	sub    %rdi,0x1ccf9(%rip)        # 1fb90 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 a1 cc 01 00 	mov    0x1cca1(%rip),%rax        # 1fb48 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 9a cc 01 00 	lea    0x1cc9a(%rip),%r8        # 1fb48 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 31 fe ff ff       	call   2cf0 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <ad_raw_fail>:
    2ec0:	50                   	push   %rax
    2ec1:	58                   	pop    %rax
    2ec2:	48 8d 15 2f 83 00 00 	lea    0x832f(%rip),%rdx        # b1f8 <_IO_stdin_used+0x1f8>
    2ec9:	be 02 00 00 00       	mov    $0x2,%esi
    2ece:	31 c0                	xor    %eax,%eax
    2ed0:	48 83 ec 08          	sub    $0x8,%rsp
    2ed4:	48 89 f9             	mov    %rdi,%rcx
    2ed7:	48 8b 3d c2 b1 00 00 	mov    0xb1c2(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    2ede:	e8 6d f7 ff ff       	call   2650 <__fprintf_chk@plt>
    2ee3:	bf e8 00 00 00       	mov    $0xe8,%edi
    2ee8:	e8 43 f7 ff ff       	call   2630 <exit@plt>
    2eed:	0f 1f 00             	nopl   (%rax)

0000000000002ef0 <buf_grow>:
    2ef0:	48 83 ec 18          	sub    $0x18,%rsp
    2ef4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ef8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2efc:	74 7e                	je     2f7c <buf_grow+0x8c>
    2efe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f05:	48 29 c2             	sub    %rax,%rdx
    2f08:	48 39 f2             	cmp    %rsi,%rdx
    2f0b:	72 6f                	jb     2f7c <buf_grow+0x8c>
    2f0d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f12:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f16:	48 89 f9             	mov    %rdi,%rcx
    2f19:	48 39 d0             	cmp    %rdx,%rax
    2f1c:	73 48                	jae    2f66 <buf_grow+0x76>
    2f1e:	48 85 c0             	test   %rax,%rax
    2f21:	75 15                	jne    2f38 <buf_grow+0x48>
    2f23:	48 83 fa 40          	cmp    $0x40,%rdx
    2f27:	76 4c                	jbe    2f75 <buf_grow+0x85>
    2f29:	b8 40 00 00 00       	mov    $0x40,%eax
    2f2e:	eb 08                	jmp    2f38 <buf_grow+0x48>
    2f30:	48 01 c0             	add    %rax,%rax
    2f33:	48 39 d0             	cmp    %rdx,%rax
    2f36:	73 38                	jae    2f70 <buf_grow+0x80>
    2f38:	48 85 c0             	test   %rax,%rax
    2f3b:	79 f3                	jns    2f30 <buf_grow+0x40>
    2f3d:	48 8b 39             	mov    (%rcx),%rdi
    2f40:	48 89 d6             	mov    %rdx,%rsi
    2f43:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f48:	48 89 14 24          	mov    %rdx,(%rsp)
    2f4c:	e8 4f f6 ff ff       	call   25a0 <realloc@plt>
    2f51:	48 8b 14 24          	mov    (%rsp),%rdx
    2f55:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f5a:	48 85 c0             	test   %rax,%rax
    2f5d:	74 1d                	je     2f7c <buf_grow+0x8c>
    2f5f:	48 89 01             	mov    %rax,(%rcx)
    2f62:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f66:	48 83 c4 18          	add    $0x18,%rsp
    2f6a:	c3                   	ret
    2f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f70:	48 89 c2             	mov    %rax,%rdx
    2f73:	eb c8                	jmp    2f3d <buf_grow+0x4d>
    2f75:	ba 40 00 00 00       	mov    $0x40,%edx
    2f7a:	eb c1                	jmp    2f3d <buf_grow+0x4d>
    2f7c:	48 8b 0d 1d b1 00 00 	mov    0xb11d(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    2f83:	ba 13 00 00 00       	mov    $0x13,%edx
    2f88:	be 01 00 00 00       	mov    $0x1,%esi
    2f8d:	48 8d 3d 74 80 00 00 	lea    0x8074(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f94:	e8 a7 f6 ff ff       	call   2640 <fwrite@plt>
    2f99:	31 ff                	xor    %edi,%edi
    2f9b:	e8 f0 f5 ff ff       	call   2590 <fflush@plt>
    2fa0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fa5:	e8 b6 f6 ff ff       	call   2660 <_Exit@plt>
    2faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002fb0 <buf_put>:
    2fb0:	41 54                	push   %r12
    2fb2:	49 89 f4             	mov    %rsi,%r12
    2fb5:	48 89 d6             	mov    %rdx,%rsi
    2fb8:	55                   	push   %rbp
    2fb9:	48 89 fd             	mov    %rdi,%rbp
    2fbc:	53                   	push   %rbx
    2fbd:	48 89 d3             	mov    %rdx,%rbx
    2fc0:	e8 2b ff ff ff       	call   2ef0 <buf_grow>
    2fc5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2fc9:	48 89 da             	mov    %rbx,%rdx
    2fcc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fd0:	4c 89 e6             	mov    %r12,%rsi
    2fd3:	e8 98 f5 ff ff       	call   2570 <memcpy@plt>
    2fd8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fdc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fe0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fe4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fe8:	5b                   	pop    %rbx
    2fe9:	5d                   	pop    %rbp
    2fea:	41 5c                	pop    %r12
    2fec:	c3                   	ret
    2fed:	0f 1f 00             	nopl   (%rax)

0000000000002ff0 <fwp_cancel_tree.part.0>:
    2ff0:	48 3b 3d 49 b7 01 00 	cmp    0x1b749(%rip),%rdi        # 1e740 <fwp_cur>
    2ff7:	53                   	push   %rbx
    2ff8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2ffc:	74 35                	je     3033 <fwp_cancel_tree.part.0+0x43>
    2ffe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3002:	75 2f                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    3004:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3008:	75 29                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    300a:	48 8b 05 0f b7 01 00 	mov    0x1b70f(%rip),%rax        # 1e720 <fwp_ready_tail>
    3011:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3015:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    301c:	00 00 00 00 
    3020:	48 85 c0             	test   %rax,%rax
    3023:	74 33                	je     3058 <fwp_cancel_tree.part.0+0x68>
    3025:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    302c:	48 89 3d ed b6 01 00 	mov    %rdi,0x1b6ed(%rip)        # 1e720 <fwp_ready_tail>
    3033:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3037:	48 85 db             	test   %rbx,%rbx
    303a:	74 17                	je     3053 <fwp_cancel_tree.part.0+0x63>
    303c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3040:	75 08                	jne    304a <fwp_cancel_tree.part.0+0x5a>
    3042:	48 89 df             	mov    %rbx,%rdi
    3045:	e8 a6 ff ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    304a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    304e:	48 85 db             	test   %rbx,%rbx
    3051:	75 e9                	jne    303c <fwp_cancel_tree.part.0+0x4c>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	48 89 3d c9 b6 01 00 	mov    %rdi,0x1b6c9(%rip)        # 1e728 <fwp_ready_head>
    305f:	eb cb                	jmp    302c <fwp_cancel_tree.part.0+0x3c>
    3061:	0f 1f 40 00          	nopl   0x0(%rax)
    3065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    306c:	00 00 00 00 

0000000000003070 <fwp_finish_float>:
    3070:	53                   	push   %rbx
    3071:	be 2e 00 00 00       	mov    $0x2e,%esi
    3076:	48 89 fb             	mov    %rdi,%rbx
    3079:	e8 e2 f3 ff ff       	call   2460 <strchr@plt>
    307e:	48 85 c0             	test   %rax,%rax
    3081:	74 05                	je     3088 <fwp_finish_float+0x18>
    3083:	5b                   	pop    %rbx
    3084:	c3                   	ret
    3085:	0f 1f 00             	nopl   (%rax)
    3088:	be 65 00 00 00       	mov    $0x65,%esi
    308d:	48 89 df             	mov    %rbx,%rdi
    3090:	e8 cb f3 ff ff       	call   2460 <strchr@plt>
    3095:	48 85 c0             	test   %rax,%rax
    3098:	75 e9                	jne    3083 <fwp_finish_float+0x13>
    309a:	48 8d 35 61 80 00 00 	lea    0x8061(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    30a1:	48 89 df             	mov    %rbx,%rdi
    30a4:	e8 e7 f5 ff ff       	call   2690 <strstr@plt>
    30a9:	48 85 c0             	test   %rax,%rax
    30ac:	75 d5                	jne    3083 <fwp_finish_float+0x13>
    30ae:	48 8d 35 67 7f 00 00 	lea    0x7f67(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    30b5:	48 89 df             	mov    %rbx,%rdi
    30b8:	e8 d3 f5 ff ff       	call   2690 <strstr@plt>
    30bd:	48 85 c0             	test   %rax,%rax
    30c0:	75 c1                	jne    3083 <fwp_finish_float+0x13>
    30c2:	48 89 df             	mov    %rbx,%rdi
    30c5:	e8 66 f3 ff ff       	call   2430 <strlen@plt>
    30ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    30cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30d8:	5b                   	pop    %rbx
    30d9:	c3                   	ret
    30da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030e0 <ad_raw_report>:
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	55                   	push   %rbp
    30e5:	31 c9                	xor    %ecx,%ecx
    30e7:	45 31 c9             	xor    %r9d,%r9d
    30ea:	48 8d 15 2f 81 00 00 	lea    0x812f(%rip),%rdx        # b220 <_IO_stdin_used+0x220>
    30f1:	53                   	push   %rbx
    30f2:	be 02 00 00 00       	mov    $0x2,%esi
    30f7:	31 db                	xor    %ebx,%ebx
    30f9:	48 83 ec 38          	sub    $0x38,%rsp
    30fd:	4c 8b 05 e4 af 01 00 	mov    0x1afe4(%rip),%r8        # 1e0e8 <ad_raw_before_shutdown>
    3104:	48 8b 3d 95 af 00 00 	mov    0xaf95(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    310b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3112:	00 00 
    3114:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3119:	31 c0                	xor    %eax,%eax
    311b:	48 89 e5             	mov    %rsp,%rbp
    311e:	e8 2d f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3123:	48 8d 05 01 7f 00 00 	lea    0x7f01(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    312a:	f3 0f 7e 05 de aa 00 	movq   0xaade(%rip),%xmm0        # dc10 <d0+0x70>
    3131:	00 
    3132:	48 8d 0d 35 7f 00 00 	lea    0x7f35(%rip),%rcx        # b06e <_IO_stdin_used+0x6e>
    3139:	66 48 0f 6e c8       	movq   %rax,%xmm1
    313e:	48 8d 05 f9 7e 00 00 	lea    0x7ef9(%rip),%rax        # b03e <_IO_stdin_used+0x3e>
    3145:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3149:	66 48 0f 6e d0       	movq   %rax,%xmm2
    314e:	66 49 0f 7e c0       	movq   %xmm0,%r8
    3153:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3157:	f3 0f 7e 05 b9 aa 00 	movq   0xaab9(%rip),%xmm0        # dc18 <d0+0x78>
    315e:	00 
    315f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3163:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3168:	6a 00                	push   $0x0
    316a:	48 8b 3d 2f af 00 00 	mov    0xaf2f(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    3171:	45 31 c9             	xor    %r9d,%r9d
    3174:	31 c0                	xor    %eax,%eax
    3176:	6a 00                	push   $0x0
    3178:	48 8d 15 01 81 00 00 	lea    0x8101(%rip),%rdx        # b280 <_IO_stdin_used+0x280>
    317f:	be 02 00 00 00       	mov    $0x2,%esi
    3184:	83 c3 01             	add    $0x1,%ebx
    3187:	e8 c4 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    318c:	58                   	pop    %rax
    318d:	5a                   	pop    %rdx
    318e:	83 fb 04             	cmp    $0x4,%ebx
    3191:	74 15                	je     31a8 <ad_raw_report+0xc8>
    3193:	48 83 c5 08          	add    $0x8,%rbp
    3197:	48 8d 0d 82 7e 00 00 	lea    0x7e82(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    319e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    31a2:	eb c4                	jmp    3168 <ad_raw_report+0x88>
    31a4:	0f 1f 40 00          	nopl   0x0(%rax)
    31a8:	48 8b 0d f1 ae 00 00 	mov    0xaef1(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    31af:	ba 13 00 00 00       	mov    $0x13,%edx
    31b4:	be 01 00 00 00       	mov    $0x1,%esi
    31b9:	48 8d 3d 87 7e 00 00 	lea    0x7e87(%rip),%rdi        # b047 <_IO_stdin_used+0x47>
    31c0:	e8 7b f4 ff ff       	call   2640 <fwrite@plt>
    31c5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    31ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    31d1:	00 00 
    31d3:	75 23                	jne    31f8 <ad_raw_report+0x118>
    31d5:	48 8b 0d c4 ae 00 00 	mov    0xaec4(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    31dc:	48 83 c4 38          	add    $0x38,%rsp
    31e0:	ba 04 00 00 00       	mov    $0x4,%edx
    31e5:	be 01 00 00 00       	mov    $0x1,%esi
    31ea:	5b                   	pop    %rbx
    31eb:	48 8d 3d 69 7e 00 00 	lea    0x7e69(%rip),%rdi        # b05b <_IO_stdin_used+0x5b>
    31f2:	5d                   	pop    %rbp
    31f3:	e9 48 f4 ff ff       	jmp    2640 <fwrite@plt>
    31f8:	e8 43 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31fd:	0f 1f 00             	nopl   (%rax)

0000000000003200 <fwp_trap>:
    3200:	53                   	push   %rbx
    3201:	48 89 fb             	mov    %rdi,%rbx
    3204:	e8 b7 f9 ff ff       	call   2bc0 <fwp_flush>
    3209:	48 89 d9             	mov    %rbx,%rcx
    320c:	be 02 00 00 00       	mov    $0x2,%esi
    3211:	31 c0                	xor    %eax,%eax
    3213:	48 8b 3d 86 ae 00 00 	mov    0xae86(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    321a:	48 8d 15 3f 7e 00 00 	lea    0x7e3f(%rip),%rdx        # b060 <_IO_stdin_used+0x60>
    3221:	e8 2a f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3226:	bf 65 00 00 00       	mov    $0x65,%edi
    322b:	e8 00 f4 ff ff       	call   2630 <exit@plt>

0000000000003230 <fwp_now_ns>:
    3230:	53                   	push   %rbx
    3231:	bf 01 00 00 00       	mov    $0x1,%edi
    3236:	48 83 ec 20          	sub    $0x20,%rsp
    323a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3241:	00 00 
    3243:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3248:	31 db                	xor    %ebx,%ebx
    324a:	48 89 e6             	mov    %rsp,%rsi
    324d:	e8 ae f1 ff ff       	call   2400 <clock_gettime@plt>
    3252:	85 c0                	test   %eax,%eax
    3254:	75 52                	jne    32a8 <fwp_now_ns+0x78>
    3256:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    325b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3260:	48 f7 2c 24          	imulq  (%rsp)
    3264:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    326b:	48 89 f7             	mov    %rsi,%rdi
    326e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3272:	48 01 f0             	add    %rsi,%rax
    3275:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    327c:	00 00 80 
    327f:	48 11 fa             	adc    %rdi,%rdx
    3282:	31 ff                	xor    %edi,%edi
    3284:	48 01 c6             	add    %rax,%rsi
    3287:	48 11 d7             	adc    %rdx,%rdi
    328a:	48 39 f1             	cmp    %rsi,%rcx
    328d:	48 19 fb             	sbb    %rdi,%rbx
    3290:	72 27                	jb     32b9 <fwp_now_ns+0x89>
    3292:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3297:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    329e:	00 00 
    32a0:	75 12                	jne    32b4 <fwp_now_ns+0x84>
    32a2:	48 83 c4 20          	add    $0x20,%rsp
    32a6:	5b                   	pop    %rbx
    32a7:	c3                   	ret
    32a8:	48 8d 3d c0 7d 00 00 	lea    0x7dc0(%rip),%rdi        # b06f <_IO_stdin_used+0x6f>
    32af:	e8 4c ff ff ff       	call   3200 <fwp_trap>
    32b4:	e8 87 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    32b9:	48 8d 3d 00 80 00 00 	lea    0x8000(%rip),%rdi        # b2c0 <_IO_stdin_used+0x2c0>
    32c0:	e8 3b ff ff ff       	call   3200 <fwp_trap>
    32c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    32cc:	00 00 00 00 

00000000000032d0 <fwp_format_g.constprop.0>:
    32d0:	41 57                	push   %r15
    32d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    32d7:	ba 02 00 00 00       	mov    $0x2,%edx
    32dc:	4c 8d 05 a8 7d 00 00 	lea    0x7da8(%rip),%r8        # b08b <_IO_stdin_used+0x8b>
    32e3:	41 56                	push   %r14
    32e5:	b8 01 00 00 00       	mov    $0x1,%eax
    32ea:	41 55                	push   %r13
    32ec:	41 54                	push   %r12
    32ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    32f2:	55                   	push   %rbp
    32f3:	45 89 e1             	mov    %r12d,%r9d
    32f6:	53                   	push   %rbx
    32f7:	48 89 fb             	mov    %rdi,%rbx
    32fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3301:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3308:	00 00 
    330a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3311:	00 
    3312:	41 89 f7             	mov    %esi,%r15d
    3315:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    331a:	be 40 00 00 00       	mov    $0x40,%esi
    331f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3324:	4c 89 f7             	mov    %r14,%rdi
    3327:	e8 64 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    332c:	be 65 00 00 00       	mov    $0x65,%esi
    3331:	4c 89 f7             	mov    %r14,%rdi
    3334:	e8 27 f1 ff ff       	call   2460 <strchr@plt>
    3339:	31 f6                	xor    %esi,%esi
    333b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3340:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3344:	48 89 c5             	mov    %rax,%rbp
    3347:	e8 14 f2 ff ff       	call   2560 <strtol@plt>
    334c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3351:	49 89 c0             	mov    %rax,%r8
    3354:	83 c0 05             	add    $0x5,%eax
    3357:	83 f8 15             	cmp    $0x15,%eax
    335a:	0f 87 e0 01 00 00    	ja     3540 <fwp_format_g.constprop.0+0x270>
    3360:	45 89 e5             	mov    %r12d,%r13d
    3363:	45 29 c5             	sub    %r8d,%r13d
    3366:	45 85 ed             	test   %r13d,%r13d
    3369:	0f 8e 21 01 00 00    	jle    3490 <fwp_format_g.constprop.0+0x1c0>
    336f:	41 83 ff 01          	cmp    $0x1,%r15d
    3373:	0f 84 17 01 00 00    	je     3490 <fwp_format_g.constprop.0+0x1c0>
    3379:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    337e:	31 d2                	xor    %edx,%edx
    3380:	4d 63 df             	movslq %r15d,%r11
    3383:	3c 2d                	cmp    $0x2d,%al
    3385:	0f 94 c2             	sete   %dl
    3388:	4c 29 dd             	sub    %r11,%rbp
    338b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    338f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3393:	4d 89 f1             	mov    %r14,%r9
    3396:	4d 29 d1             	sub    %r10,%r9
    3399:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    339d:	3c 2d                	cmp    $0x2d,%al
    339f:	0f 84 fb 03 00 00    	je     37a0 <fwp_format_g.constprop.0+0x4d0>
    33a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    33aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    33af:	48 89 e8             	mov    %rbp,%rax
    33b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    33ba:	49 83 c1 47          	add    $0x47,%r9
    33be:	45 85 c0             	test   %r8d,%r8d
    33c1:	0f 88 f1 02 00 00    	js     36b8 <fwp_format_g.constprop.0+0x3e8>
    33c7:	45 0f b6 12          	movzbl (%r10),%r10d
    33cb:	4d 63 e0             	movslq %r8d,%r12
    33ce:	44 88 10             	mov    %r10b,(%rax)
    33d1:	41 83 f8 07          	cmp    $0x7,%r8d
    33d5:	0f 87 2d 02 00 00    	ja     3608 <fwp_format_g.constprop.0+0x338>
    33db:	41 f6 c4 04          	test   $0x4,%r12b
    33df:	0f 85 f2 03 00 00    	jne    37d7 <fwp_format_g.constprop.0+0x507>
    33e5:	45 85 e4             	test   %r12d,%r12d
    33e8:	74 12                	je     33fc <fwp_format_g.constprop.0+0x12c>
    33ea:	45 0f b6 06          	movzbl (%r14),%r8d
    33ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    33f2:	41 f6 c4 02          	test   $0x2,%r12b
    33f6:	0f 85 03 04 00 00    	jne    37ff <fwp_format_g.constprop.0+0x52f>
    33fc:	4c 29 e1             	sub    %r12,%rcx
    33ff:	4c 01 e7             	add    %r12,%rdi
    3402:	4c 89 fa             	mov    %r15,%rdx
    3405:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    340a:	48 83 e9 01          	sub    $0x1,%rcx
    340e:	4d 63 ed             	movslq %r13d,%r13
    3411:	48 89 0c 24          	mov    %rcx,(%rsp)
    3415:	e8 26 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    341a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    341f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3423:	ba 48 00 00 00       	mov    $0x48,%edx
    3428:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    342c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3430:	4c 89 c8             	mov    %r9,%rax
    3433:	48 29 c8             	sub    %rcx,%rax
    3436:	48 39 d0             	cmp    %rdx,%rax
    3439:	48 0f 42 c2          	cmovb  %rdx,%rax
    343d:	4c 29 c9             	sub    %r9,%rcx
    3440:	4c 89 ea             	mov    %r13,%rdx
    3443:	48 01 c1             	add    %rax,%rcx
    3446:	e8 f5 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    344b:	4c 01 e8             	add    %r13,%rax
    344e:	48 29 e8             	sub    %rbp,%rax
    3451:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3456:	48 39 d0             	cmp    %rdx,%rax
    3459:	48 0f 47 c2          	cmova  %rdx,%rax
    345d:	89 c1                	mov    %eax,%ecx
    345f:	83 f8 08             	cmp    $0x8,%eax
    3462:	0f 83 18 02 00 00    	jae    3680 <fwp_format_g.constprop.0+0x3b0>
    3468:	a8 04                	test   $0x4,%al
    346a:	0f 85 54 03 00 00    	jne    37c4 <fwp_format_g.constprop.0+0x4f4>
    3470:	85 c0                	test   %eax,%eax
    3472:	74 0f                	je     3483 <fwp_format_g.constprop.0+0x1b3>
    3474:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3479:	88 13                	mov    %dl,(%rbx)
    347b:	a8 02                	test   $0x2,%al
    347d:	0f 85 6b 03 00 00    	jne    37ee <fwp_format_g.constprop.0+0x51e>
    3483:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3487:	eb 36                	jmp    34bf <fwp_format_g.constprop.0+0x1ef>
    3489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3490:	45 31 c9             	xor    %r9d,%r9d
    3493:	45 85 ed             	test   %r13d,%r13d
    3496:	4c 8d 05 fd 7b 00 00 	lea    0x7bfd(%rip),%r8        # b09a <_IO_stdin_used+0x9a>
    349d:	48 89 df             	mov    %rbx,%rdi
    34a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    34a4:	ba 02 00 00 00       	mov    $0x2,%edx
    34a9:	be 90 01 00 00       	mov    $0x190,%esi
    34ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    34b5:	b8 01 00 00 00       	mov    $0x1,%eax
    34ba:	e8 d1 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    34c4:	48 89 df             	mov    %rbx,%rdi
    34c7:	e8 94 ef ff ff       	call   2460 <strchr@plt>
    34cc:	48 85 c0             	test   %rax,%rax
    34cf:	74 3f                	je     3510 <fwp_format_g.constprop.0+0x240>
    34d1:	48 89 df             	mov    %rbx,%rdi
    34d4:	e8 57 ef ff ff       	call   2430 <strlen@plt>
    34d9:	48 85 c0             	test   %rax,%rax
    34dc:	75 0b                	jne    34e9 <fwp_format_g.constprop.0+0x219>
    34de:	eb 30                	jmp    3510 <fwp_format_g.constprop.0+0x240>
    34e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    34e4:	48 85 c0             	test   %rax,%rax
    34e7:	74 27                	je     3510 <fwp_format_g.constprop.0+0x240>
    34e9:	48 89 c2             	mov    %rax,%rdx
    34ec:	48 83 e8 01          	sub    $0x1,%rax
    34f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    34f4:	74 ea                	je     34e0 <fwp_format_g.constprop.0+0x210>
    34f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    34fb:	0f 84 6f 01 00 00    	je     3670 <fwp_format_g.constprop.0+0x3a0>
    3501:	0f 1f 40 00          	nopl   0x0(%rax)
    3505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    350c:	00 00 00 00 
    3510:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3517:	00 
    3518:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    351f:	00 00 
    3521:	0f 85 ec 02 00 00    	jne    3813 <fwp_format_g.constprop.0+0x543>
    3527:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    352e:	5b                   	pop    %rbx
    352f:	5d                   	pop    %rbp
    3530:	41 5c                	pop    %r12
    3532:	41 5d                	pop    %r13
    3534:	41 5e                	pop    %r14
    3536:	41 5f                	pop    %r15
    3538:	c3                   	ret
    3539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3540:	4c 29 f5             	sub    %r14,%rbp
    3543:	b9 40 00 00 00       	mov    $0x40,%ecx
    3548:	4c 89 f6             	mov    %r14,%rsi
    354b:	4c 89 04 24          	mov    %r8,(%rsp)
    354f:	49 89 ec             	mov    %rbp,%r12
    3552:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3557:	4c 89 e2             	mov    %r12,%rdx
    355a:	48 89 ef             	mov    %rbp,%rdi
    355d:	e8 de ef ff ff       	call   2540 <__memcpy_chk@plt>
    3562:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3568:	be 2e 00 00 00       	mov    $0x2e,%esi
    356d:	48 89 ef             	mov    %rbp,%rdi
    3570:	e8 eb ee ff ff       	call   2460 <strchr@plt>
    3575:	4c 8b 04 24          	mov    (%rsp),%r8
    3579:	48 85 c0             	test   %rax,%rax
    357c:	74 40                	je     35be <fwp_format_g.constprop.0+0x2ee>
    357e:	4d 85 e4             	test   %r12,%r12
    3581:	74 3b                	je     35be <fwp_format_g.constprop.0+0x2ee>
    3583:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3588:	eb 23                	jmp    35ad <fwp_format_g.constprop.0+0x2dd>
    358a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3591:	00 00 00 00 
    3595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    359c:	00 00 00 00 
    35a0:	c6 00 00             	movb   $0x0,(%rax)
    35a3:	48 83 e8 01          	sub    $0x1,%rax
    35a7:	49 83 ec 01          	sub    $0x1,%r12
    35ab:	74 11                	je     35be <fwp_format_g.constprop.0+0x2ee>
    35ad:	80 38 30             	cmpb   $0x30,(%rax)
    35b0:	74 ee                	je     35a0 <fwp_format_g.constprop.0+0x2d0>
    35b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    35b8:	0f 84 fb 01 00 00    	je     37b9 <fwp_format_g.constprop.0+0x4e9>
    35be:	44 89 c0             	mov    %r8d,%eax
    35c1:	ba 02 00 00 00       	mov    $0x2,%edx
    35c6:	49 89 e9             	mov    %rbp,%r9
    35c9:	be 90 01 00 00       	mov    $0x190,%esi
    35ce:	f7 d8                	neg    %eax
    35d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    35d7:	48 89 df             	mov    %rbx,%rdi
    35da:	41 0f 48 c0          	cmovs  %r8d,%eax
    35de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    35e2:	41 83 e0 02          	and    $0x2,%r8d
    35e6:	41 83 c0 2b          	add    $0x2b,%r8d
    35ea:	50                   	push   %rax
    35eb:	31 c0                	xor    %eax,%eax
    35ed:	41 50                	push   %r8
    35ef:	4c 8d 05 9a 7a 00 00 	lea    0x7a9a(%rip),%r8        # b090 <_IO_stdin_used+0x90>
    35f6:	e8 95 ed ff ff       	call   2390 <__snprintf_chk@plt>
    35fb:	58                   	pop    %rax
    35fc:	5a                   	pop    %rdx
    35fd:	e9 0e ff ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    3602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3608:	4d 8b 06             	mov    (%r14),%r8
    360b:	48 83 c0 09          	add    $0x9,%rax
    360f:	4c 89 f2             	mov    %r14,%rdx
    3612:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3616:	4c 89 07             	mov    %r8,(%rdi)
    3619:	45 89 e0             	mov    %r12d,%r8d
    361c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3621:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3626:	49 89 f8             	mov    %rdi,%r8
    3629:	49 29 c0             	sub    %rax,%r8
    362c:	4c 29 c2             	sub    %r8,%rdx
    362f:	45 01 e0             	add    %r12d,%r8d
    3632:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3636:	41 83 f8 08          	cmp    $0x8,%r8d
    363a:	0f 82 bc fd ff ff    	jb     33fc <fwp_format_g.constprop.0+0x12c>
    3640:	48 89 0c 24          	mov    %rcx,(%rsp)
    3644:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3648:	45 31 d2             	xor    %r10d,%r10d
    364b:	45 89 d3             	mov    %r10d,%r11d
    364e:	41 83 c2 08          	add    $0x8,%r10d
    3652:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3656:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    365a:	45 39 c2             	cmp    %r8d,%r10d
    365d:	72 ec                	jb     364b <fwp_format_g.constprop.0+0x37b>
    365f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3663:	e9 94 fd ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    366f:	00 
    3670:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3675:	e9 96 fe ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3680:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3685:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3689:	48 89 ee             	mov    %rbp,%rsi
    368c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3690:	48 89 13             	mov    %rdx,(%rbx)
    3693:	89 c2                	mov    %eax,%edx
    3695:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    369a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    369f:	48 89 d9             	mov    %rbx,%rcx
    36a2:	48 29 f9             	sub    %rdi,%rcx
    36a5:	48 29 ce             	sub    %rcx,%rsi
    36a8:	01 c1                	add    %eax,%ecx
    36aa:	c1 e9 03             	shr    $0x3,%ecx
    36ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    36b0:	e9 ce fd ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    36b5:	0f 1f 00             	nopl   (%rax)
    36b8:	c6 00 30             	movb   $0x30,(%rax)
    36bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    36bf:	4c 89 fa             	mov    %r15,%rdx
    36c2:	4c 89 e9             	mov    %r13,%rcx
    36c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    36ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    36cf:	4c 89 14 24          	mov    %r10,(%rsp)
    36d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    36d8:	e8 63 ee ff ff       	call   2540 <__memcpy_chk@plt>
    36dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    36e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    36e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    36ec:	48 89 c7             	mov    %rax,%rdi
    36ef:	4c 8b 14 24          	mov    (%rsp),%r10
    36f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    36f8:	4c 89 c8             	mov    %r9,%rax
    36fb:	4c 29 e8             	sub    %r13,%rax
    36fe:	48 39 c8             	cmp    %rcx,%rax
    3701:	48 0f 42 c1          	cmovb  %rcx,%rax
    3705:	4d 29 cd             	sub    %r9,%r13
    3708:	49 01 ff             	add    %rdi,%r15
    370b:	4c 01 e8             	add    %r13,%rax
    370e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3712:	74 3d                	je     3751 <fwp_format_g.constprop.0+0x481>
    3714:	41 f7 d0             	not    %r8d
    3717:	31 f6                	xor    %esi,%esi
    3719:	ba 48 00 00 00       	mov    $0x48,%edx
    371e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3723:	48 39 d0             	cmp    %rdx,%rax
    3726:	48 0f 43 d0          	cmovae %rax,%rdx
    372a:	48 89 d1             	mov    %rdx,%rcx
    372d:	48 29 c1             	sub    %rax,%rcx
    3730:	48 83 c1 01          	add    $0x1,%rcx
    3734:	48 39 d1             	cmp    %rdx,%rcx
    3737:	48 0f 42 ca          	cmovb  %rdx,%rcx
    373b:	48 83 e8 01          	sub    $0x1,%rax
    373f:	48 83 c6 01          	add    $0x1,%rsi
    3743:	48 29 d0             	sub    %rdx,%rax
    3746:	48 01 c8             	add    %rcx,%rax
    3749:	41 39 f0             	cmp    %esi,%r8d
    374c:	7f cb                	jg     3719 <fwp_format_g.constprop.0+0x449>
    374e:	4d 01 c7             	add    %r8,%r15
    3751:	b9 48 00 00 00       	mov    $0x48,%ecx
    3756:	41 0f b6 12          	movzbl (%r10),%edx
    375a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    375e:	4c 89 f6             	mov    %r14,%rsi
    3761:	48 39 c8             	cmp    %rcx,%rax
    3764:	4c 89 1c 24          	mov    %r11,(%rsp)
    3768:	48 0f 43 c8          	cmovae %rax,%rcx
    376c:	41 88 17             	mov    %dl,(%r15)
    376f:	48 89 ca             	mov    %rcx,%rdx
    3772:	48 29 c2             	sub    %rax,%rdx
    3775:	48 83 c2 01          	add    $0x1,%rdx
    3779:	48 39 ca             	cmp    %rcx,%rdx
    377c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3780:	48 83 e8 01          	sub    $0x1,%rax
    3784:	48 29 c8             	sub    %rcx,%rax
    3787:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    378b:	49 63 d4             	movslq %r12d,%rdx
    378e:	e8 ad ed ff ff       	call   2540 <__memcpy_chk@plt>
    3793:	4c 8b 1c 24          	mov    (%rsp),%r11
    3797:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    379b:	e9 ae fc ff ff       	jmp    344e <fwp_format_g.constprop.0+0x17e>
    37a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    37a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    37aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    37af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    37b4:	e9 f9 fb ff ff       	jmp    33b2 <fwp_format_g.constprop.0+0xe2>
    37b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    37bf:	e9 fa fd ff ff       	jmp    35be <fwp_format_g.constprop.0+0x2ee>
    37c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    37c8:	89 13                	mov    %edx,(%rbx)
    37ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    37ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    37d2:	e9 ac fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37d7:	41 8b 06             	mov    (%r14),%eax
    37da:	89 07                	mov    %eax,(%rdi)
    37dc:	44 89 e0             	mov    %r12d,%eax
    37df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    37e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    37e9:	e9 0e fc ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    37ee:	89 c2                	mov    %eax,%edx
    37f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    37f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    37fa:	e9 84 fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37ff:	44 89 e0             	mov    %r12d,%eax
    3802:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3808:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    380e:	e9 e9 fb ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3813:	e8 28 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    381f:	00 

0000000000003820 <fwp_heap_report>:
    3820:	f3 0f 1e fa          	endbr64
    3824:	41 54                	push   %r12
    3826:	48 8d 3d 72 78 00 00 	lea    0x7872(%rip),%rdi        # b09f <_IO_stdin_used+0x9f>
    382d:	55                   	push   %rbp
    382e:	53                   	push   %rbx
    382f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3836:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    383d:	00 00 
    383f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3846:	00 
    3847:	48 8d 35 fc 78 00 00 	lea    0x78fc(%rip),%rsi        # b14a <_IO_stdin_used+0x14a>
    384e:	e8 9d ed ff ff       	call   25f0 <fopen@plt>
    3853:	48 85 c0             	test   %rax,%rax
    3856:	0f 84 c5 00 00 00    	je     3921 <fwp_heap_report+0x101>
    385c:	48 89 c5             	mov    %rax,%rbp
    385f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3866:	48 89 e3             	mov    %rsp,%rbx
    3869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3870:	48 89 ea             	mov    %rbp,%rdx
    3873:	be 00 01 00 00       	mov    $0x100,%esi
    3878:	48 89 df             	mov    %rbx,%rdi
    387b:	e8 60 ec ff ff       	call   24e0 <fgets@plt>
    3880:	48 85 c0             	test   %rax,%rax
    3883:	74 2b                	je     38b0 <fwp_heap_report+0x90>
    3885:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    388b:	75 e3                	jne    3870 <fwp_heap_report+0x50>
    388d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3891:	75 dd                	jne    3870 <fwp_heap_report+0x50>
    3893:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3898:	75 d6                	jne    3870 <fwp_heap_report+0x50>
    389a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    389f:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a4:	31 f6                	xor    %esi,%esi
    38a6:	e8 b5 ec ff ff       	call   2560 <strtol@plt>
    38ab:	49 89 c4             	mov    %rax,%r12
    38ae:	eb c0                	jmp    3870 <fwp_heap_report+0x50>
    38b0:	48 89 ef             	mov    %rbp,%rdi
    38b3:	e8 68 eb ff ff       	call   2420 <fclose@plt>
    38b8:	48 83 ec 08          	sub    $0x8,%rsp
    38bc:	4c 8b 0d 65 c2 01 00 	mov    0x1c265(%rip),%r9        # 1fb28 <fwp_heap+0x13c8>
    38c3:	4c 8b 05 be c2 01 00 	mov    0x1c2be(%rip),%r8        # 1fb88 <fwp_heap+0x1428>
    38ca:	48 8d 15 17 7a 00 00 	lea    0x7a17(%rip),%rdx        # b2e8 <_IO_stdin_used+0x2e8>
    38d1:	41 54                	push   %r12
    38d3:	48 8b 0d a6 c2 01 00 	mov    0x1c2a6(%rip),%rcx        # 1fb80 <fwp_heap+0x1420>
    38da:	be 02 00 00 00       	mov    $0x2,%esi
    38df:	b8 02 00 00 00       	mov    $0x2,%eax
    38e4:	f2 0f 10 0d b4 c2 01 	movsd  0x1c2b4(%rip),%xmm1        # 1fba0 <fwp_heap+0x1440>
    38eb:	00 
    38ec:	f2 0f 10 05 a4 c2 01 	movsd  0x1c2a4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    38f3:	00 
    38f4:	48 8b 3d a5 a7 00 00 	mov    0xa7a5(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    38fb:	e8 50 ed ff ff       	call   2650 <__fprintf_chk@plt>
    3900:	58                   	pop    %rax
    3901:	5a                   	pop    %rdx
    3902:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3909:	00 
    390a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3911:	00 00 
    3913:	75 15                	jne    392a <fwp_heap_report+0x10a>
    3915:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    391c:	5b                   	pop    %rbx
    391d:	5d                   	pop    %rbp
    391e:	41 5c                	pop    %r12
    3920:	c3                   	ret
    3921:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3928:	eb 8e                	jmp    38b8 <fwp_heap_report+0x98>
    392a:	e8 11 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    392f:	90                   	nop

0000000000003930 <fwp_heap_init>:
    3930:	66 0f 6f 05 b8 7c 00 	movdqa 0x7cb8(%rip),%xmm0        # b5f0 <msg.3+0x20>
    3937:	00 
    3938:	41 54                	push   %r12
    393a:	48 8d 05 5f bd 01 00 	lea    0x1bd5f(%rip),%rax        # 1f6a0 <fwp_heap+0xf40>
    3941:	ba 00 01 00 00       	mov    $0x100,%edx
    3946:	55                   	push   %rbp
    3947:	66 0f 6f 15 e1 7c 00 	movdqa 0x7ce1(%rip),%xmm2        # b630 <msg.3+0x60>
    394e:	00 
    394f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3953:	53                   	push   %rbx
    3954:	0f 29 05 05 bd 01 00 	movaps %xmm0,0x1bd05(%rip)        # 1f660 <fwp_heap+0xf00>
    395b:	66 0f 6f 05 9d 7c 00 	movdqa 0x7c9d(%rip),%xmm0        # b600 <msg.3+0x30>
    3962:	00 
    3963:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3967:	c7 05 93 c1 01 00 01 	movl   $0x1,0x1c193(%rip)        # 1fb04 <fwp_heap+0x13a4>
    396e:	00 00 00 
    3971:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3976:	0f 29 05 f3 bc 01 00 	movaps %xmm0,0x1bcf3(%rip)        # 1f670 <fwp_heap+0xf10>
    397d:	66 0f 6f 05 8b 7c 00 	movdqa 0x7c8b(%rip),%xmm0        # b610 <msg.3+0x40>
    3984:	00 
    3985:	0f 29 05 f4 bc 01 00 	movaps %xmm0,0x1bcf4(%rip)        # 1f680 <fwp_heap+0xf20>
    398c:	66 0f 6f 05 8c 7c 00 	movdqa 0x7c8c(%rip),%xmm0        # b620 <msg.3+0x50>
    3993:	00 
    3994:	0f 29 05 f5 bc 01 00 	movaps %xmm0,0x1bcf5(%rip)        # 1f690 <fwp_heap+0xf30>
    399b:	89 d3                	mov    %edx,%ebx
    399d:	66 0f 6e e2          	movd   %edx,%xmm4
    39a1:	48 83 c0 10          	add    $0x10,%rax
    39a5:	01 d2                	add    %edx,%edx
    39a7:	c1 eb 02             	shr    $0x2,%ebx
    39aa:	66 0f 6e c3          	movd   %ebx,%xmm0
    39ae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    39b3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    39b7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    39bc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    39c0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    39c4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    39c9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    39ce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    39d2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    39d7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    39db:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    39df:	48 39 c7             	cmp    %rax,%rdi
    39e2:	75 b7                	jne    399b <fwp_heap_init+0x6b>
    39e4:	4c 8d 05 75 ad 01 00 	lea    0x1ad75(%rip),%r8        # 1e760 <fwp_heap>
    39eb:	31 c9                	xor    %ecx,%ecx
    39ed:	31 c0                	xor    %eax,%eax
    39ef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    39f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    39fd:	00 00 00 
    3a00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a07:	00 
    3a08:	48 39 ca             	cmp    %rcx,%rdx
    3a0b:	73 0f                	jae    3a1c <fwp_heap_init+0xec>
    3a0d:	0f 1f 00             	nopl   (%rax)
    3a10:	48 83 c0 01          	add    $0x1,%rax
    3a14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a17:	48 39 ca             	cmp    %rcx,%rdx
    3a1a:	72 f4                	jb     3a10 <fwp_heap_init+0xe0>
    3a1c:	48 83 c1 10          	add    $0x10,%rcx
    3a20:	88 07                	mov    %al,(%rdi)
    3a22:	48 83 c7 01          	add    $0x1,%rdi
    3a26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3a2d:	75 d1                	jne    3a00 <fwp_heap_init+0xd0>
    3a2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3a36:	00 00 00 
    3a39:	bd 05 00 00 00       	mov    $0x5,%ebp
    3a3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3a45:	45 31 c9             	xor    %r9d,%r9d
    3a48:	31 d2                	xor    %edx,%edx
    3a4a:	31 ff                	xor    %edi,%edi
    3a4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3a57:	4c 89 e6             	mov    %r12,%rsi
    3a5a:	e8 f1 e9 ff ff       	call   2450 <mmap@plt>
    3a5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a63:	75 13                	jne    3a78 <fwp_heap_init+0x148>
    3a65:	48 c1 eb 02          	shr    $0x2,%rbx
    3a69:	83 ed 01             	sub    $0x1,%ebp
    3a6c:	75 d0                	jne    3a3e <fwp_heap_init+0x10e>
    3a6e:	e8 7d f2 ff ff       	call   2cf0 <fwp_heap_oom>
    3a73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3a78:	48 85 c0             	test   %rax,%rax
    3a7b:	74 f1                	je     3a6e <fwp_heap_init+0x13e>
    3a7d:	48 c1 eb 10          	shr    $0x10,%rbx
    3a81:	48 89 05 90 c0 01 00 	mov    %rax,0x1c090(%rip)        # 1fb18 <fwp_heap+0x13b8>
    3a88:	45 31 c9             	xor    %r9d,%r9d
    3a8b:	31 d2                	xor    %edx,%edx
    3a8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3a93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3a97:	31 ff                	xor    %edi,%edi
    3a99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a9f:	66 31 c0             	xor    %ax,%ax
    3aa2:	48 c1 e6 03          	shl    $0x3,%rsi
    3aa6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3aab:	4c 89 25 6e c0 01 00 	mov    %r12,0x1c06e(%rip)        # 1fb20 <fwp_heap+0x13c0>
    3ab2:	48 89 05 57 c0 01 00 	mov    %rax,0x1c057(%rip)        # 1fb10 <fwp_heap+0x13b0>
    3ab9:	48 89 1d 70 c0 01 00 	mov    %rbx,0x1c070(%rip)        # 1fb30 <fwp_heap+0x13d0>
    3ac0:	48 89 35 99 c0 01 00 	mov    %rsi,0x1c099(%rip)        # 1fb60 <fwp_heap+0x1400>
    3ac7:	e8 84 e9 ff ff       	call   2450 <mmap@plt>
    3acc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ad0:	74 9c                	je     3a6e <fwp_heap_init+0x13e>
    3ad2:	48 8d 3d fc 75 00 00 	lea    0x75fc(%rip),%rdi        # b0d5 <_IO_stdin_used+0xd5>
    3ad9:	48 89 05 78 c0 01 00 	mov    %rax,0x1c078(%rip)        # 1fb58 <fwp_heap+0x13f8>
    3ae0:	e8 9b e8 ff ff       	call   2380 <getenv@plt>
    3ae5:	48 89 c2             	mov    %rax,%rdx
    3ae8:	31 c0                	xor    %eax,%eax
    3aea:	48 85 d2             	test   %rdx,%rdx
    3aed:	74 15                	je     3b04 <fwp_heap_init+0x1d4>
    3aef:	80 3a 00             	cmpb   $0x0,(%rdx)
    3af2:	74 10                	je     3b04 <fwp_heap_init+0x1d4>
    3af4:	0f b6 02             	movzbl (%rdx),%eax
    3af7:	83 e8 30             	sub    $0x30,%eax
    3afa:	74 13                	je     3b0f <fwp_heap_init+0x1df>
    3afc:	85 c0                	test   %eax,%eax
    3afe:	0f 95 c0             	setne  %al
    3b01:	0f b6 c0             	movzbl %al,%eax
    3b04:	5b                   	pop    %rbx
    3b05:	5d                   	pop    %rbp
    3b06:	89 05 fc bf 01 00    	mov    %eax,0x1bffc(%rip)        # 1fb08 <fwp_heap+0x13a8>
    3b0c:	41 5c                	pop    %r12
    3b0e:	c3                   	ret
    3b0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b13:	85 c0                	test   %eax,%eax
    3b15:	0f 95 c0             	setne  %al
    3b18:	0f b6 c0             	movzbl %al,%eax
    3b1b:	eb e7                	jmp    3b04 <fwp_heap_init+0x1d4>
    3b1d:	0f 1f 00             	nopl   (%rax)

0000000000003b20 <fwp_wake_io>:
    3b20:	48 8b 07             	mov    (%rdi),%rax
    3b23:	48 85 c0             	test   %rax,%rax
    3b26:	0f 84 f4 00 00 00    	je     3c20 <fwp_wake_io+0x100>
    3b2c:	53                   	push   %rbx
    3b2d:	4c 8b 05 ec ab 01 00 	mov    0x1abec(%rip),%r8        # 1e720 <fwp_ready_tail>
    3b34:	49 89 f9             	mov    %rdi,%r9
    3b37:	48 89 c2             	mov    %rax,%rdx
    3b3a:	45 31 db             	xor    %r11d,%r11d
    3b3d:	45 31 d2             	xor    %r10d,%r10d
    3b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3b44:	eb 71                	jmp    3bb7 <fwp_wake_io+0x97>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3b57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b5e:	48 85 c9             	test   %rcx,%rcx
    3b61:	74 07                	je     3b6a <fwp_wake_io+0x4a>
    3b63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3b6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3b71:	00 00 00 00 
    3b75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3b7c:	49 8b 01             	mov    (%r9),%rax
    3b7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3b83:	75 2a                	jne    3baf <fwp_wake_io+0x8f>
    3b85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3b89:	75 24                	jne    3baf <fwp_wake_io+0x8f>
    3b8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3b8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3b96:	00 00 00 00 
    3b9a:	4d 85 c0             	test   %r8,%r8
    3b9d:	74 51                	je     3bf0 <fwp_wake_io+0xd0>
    3b9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3ba6:	49 89 d0             	mov    %rdx,%r8
    3ba9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3baf:	48 89 c2             	mov    %rax,%rdx
    3bb2:	48 85 c0             	test   %rax,%rax
    3bb5:	74 49                	je     3c00 <fwp_wake_io+0xe0>
    3bb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3bbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3bc2:	48 85 ff             	test   %rdi,%rdi
    3bc5:	74 b8                	je     3b7f <fwp_wake_io+0x5f>
    3bc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3bce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bd5:	48 85 f6             	test   %rsi,%rsi
    3bd8:	0f 85 72 ff ff ff    	jne    3b50 <fwp_wake_io+0x30>
    3bde:	48 89 0f             	mov    %rcx,(%rdi)
    3be1:	e9 78 ff ff ff       	jmp    3b5e <fwp_wake_io+0x3e>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 d3             	mov    %rdx,%rbx
    3bf3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3bf9:	eb ab                	jmp    3ba6 <fwp_wake_io+0x86>
    3bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3c00:	45 84 db             	test   %r11b,%r11b
    3c03:	74 07                	je     3c0c <fwp_wake_io+0xec>
    3c05:	48 89 1d 1c ab 01 00 	mov    %rbx,0x1ab1c(%rip)        # 1e728 <fwp_ready_head>
    3c0c:	45 84 d2             	test   %r10b,%r10b
    3c0f:	74 07                	je     3c18 <fwp_wake_io+0xf8>
    3c11:	4c 89 05 08 ab 01 00 	mov    %r8,0x1ab08(%rip)        # 1e720 <fwp_ready_tail>
    3c18:	5b                   	pop    %rbx
    3c19:	c3                   	ret
    3c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3c20:	c3                   	ret
    3c21:	0f 1f 40 00          	nopl   0x0(%rax)
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_poll_events>:
    3c30:	53                   	push   %rbx
    3c31:	48 83 ec 20          	sub    $0x20,%rsp
    3c35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3c3c:	00 00 
    3c3e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3c43:	31 c0                	xor    %eax,%eax
    3c45:	e8 e6 f5 ff ff       	call   3230 <fwp_now_ns>
    3c4a:	48 8b 1d c7 aa 01 00 	mov    0x1aac7(%rip),%rbx        # 1e718 <fwp_timers>
    3c51:	48 85 db             	test   %rbx,%rbx
    3c54:	0f 84 e6 00 00 00    	je     3d40 <fwp_poll_events+0x110>
    3c5a:	48 89 c6             	mov    %rax,%rsi
    3c5d:	48 89 da             	mov    %rbx,%rdx
    3c60:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3c67:	eb 26                	jmp    3c8f <fwp_poll_events+0x5f>
    3c69:	90                   	nop
    3c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c71:	00 00 00 00 
    3c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c7c:	00 00 00 00 
    3c80:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c87:	48 89 c8             	mov    %rcx,%rax
    3c8a:	48 85 d2             	test   %rdx,%rdx
    3c8d:	74 31                	je     3cc0 <fwp_poll_events+0x90>
    3c8f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c93:	48 85 c0             	test   %rax,%rax
    3c96:	78 e8                	js     3c80 <fwp_poll_events+0x50>
    3c98:	48 39 c1             	cmp    %rax,%rcx
    3c9b:	7c e3                	jl     3c80 <fwp_poll_events+0x50>
    3c9d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3ca4:	48 85 d2             	test   %rdx,%rdx
    3ca7:	74 1c                	je     3cc5 <fwp_poll_events+0x95>
    3ca9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3cad:	48 39 c1             	cmp    %rax,%rcx
    3cb0:	7c ce                	jl     3c80 <fwp_poll_events+0x50>
    3cb2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3cb9:	48 85 d2             	test   %rdx,%rdx
    3cbc:	75 d1                	jne    3c8f <fwp_poll_events+0x5f>
    3cbe:	66 90                	xchg   %ax,%ax
    3cc0:	48 85 c0             	test   %rax,%rax
    3cc3:	78 7b                	js     3d40 <fwp_poll_events+0x110>
    3cc5:	48 29 f0             	sub    %rsi,%rax
    3cc8:	48 89 c1             	mov    %rax,%rcx
    3ccb:	48 85 c0             	test   %rax,%rax
    3cce:	0f 8e 9c 00 00 00    	jle    3d70 <fwp_poll_events+0x140>
    3cd4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3cdb:	de 1b 43 
    3cde:	48 f7 ea             	imul   %rdx
    3ce1:	48 89 c8             	mov    %rcx,%rax
    3ce4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ce8:	48 c1 fa 12          	sar    $0x12,%rdx
    3cec:	48 29 c2             	sub    %rax,%rdx
    3cef:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3cf6:	48 39 c1             	cmp    %rax,%rcx
    3cf9:	0f 95 c0             	setne  %al
    3cfc:	0f b6 c0             	movzbl %al,%eax
    3cff:	48 01 d0             	add    %rdx,%rax
    3d02:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3d08:	0f 8f 32 01 00 00    	jg     3e40 <fwp_poll_events+0x210>
    3d0e:	48 85 c0             	test   %rax,%rax
    3d11:	74 5d                	je     3d70 <fwp_poll_events+0x140>
    3d13:	89 c1                	mov    %eax,%ecx
    3d15:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3d1c:	48 c1 e9 26          	shr    $0x26,%rcx
    3d20:	48 63 d1             	movslq %ecx,%rdx
    3d23:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3d29:	29 c8                	sub    %ecx,%eax
    3d2b:	48 98                	cltq
    3d2d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3d34:	e9 11 01 00 00       	jmp    3e4a <fwp_poll_events+0x21a>
    3d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d40:	e8 7b ee ff ff       	call   2bc0 <fwp_flush>
    3d45:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3d4a:	be 01 00 00 00       	mov    $0x1,%esi
    3d4f:	48 8b 0d 4a a3 00 00 	mov    0xa34a(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    3d56:	48 8d 3d 13 76 00 00 	lea    0x7613(%rip),%rdi        # b370 <_IO_stdin_used+0x370>
    3d5d:	e8 de e8 ff ff       	call   2640 <fwrite@plt>
    3d62:	bf 65 00 00 00       	mov    $0x65,%edi
    3d67:	e8 c4 e8 ff ff       	call   2630 <exit@plt>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	e8 bb f4 ff ff       	call   3230 <fwp_now_ns>
    3d75:	48 89 c1             	mov    %rax,%rcx
    3d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3d7c:	eb 44                	jmp    3dc2 <fwp_poll_events+0x192>
    3d7e:	66 90                	xchg   %ax,%ax
    3d80:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3d84:	75 33                	jne    3db9 <fwp_poll_events+0x189>
    3d86:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8a:	75 2d                	jne    3db9 <fwp_poll_events+0x189>
    3d8c:	48 8b 05 8d a9 01 00 	mov    0x1a98d(%rip),%rax        # 1e720 <fwp_ready_tail>
    3d93:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3d97:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3d9e:	00 00 00 00 
    3da2:	48 85 c0             	test   %rax,%rax
    3da5:	0f 84 05 01 00 00    	je     3eb0 <fwp_poll_events+0x280>
    3dab:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3db2:	48 89 15 67 a9 01 00 	mov    %rdx,0x1a967(%rip)        # 1e720 <fwp_ready_tail>
    3db9:	48 85 db             	test   %rbx,%rbx
    3dbc:	0f 84 be 00 00 00    	je     3e80 <fwp_poll_events+0x250>
    3dc2:	48 89 da             	mov    %rbx,%rdx
    3dc5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3dcc:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3dd0:	7f e7                	jg     3db9 <fwp_poll_events+0x189>
    3dd2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3dd6:	74 2e                	je     3e06 <fwp_poll_events+0x1d6>
    3dd8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3ddf:	48 85 c0             	test   %rax,%rax
    3de2:	0f 84 b8 00 00 00    	je     3ea0 <fwp_poll_events+0x270>
    3de8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3def:	48 85 db             	test   %rbx,%rbx
    3df2:	74 07                	je     3dfb <fwp_poll_events+0x1cb>
    3df4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3dfb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3dff:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3e06:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3e0a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3e0e:	48 85 c0             	test   %rax,%rax
    3e11:	0f 84 69 ff ff ff    	je     3d80 <fwp_poll_events+0x150>
    3e17:	48 39 c8             	cmp    %rcx,%rax
    3e1a:	0f 8f 60 ff ff ff    	jg     3d80 <fwp_poll_events+0x150>
    3e20:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3e24:	0f 85 56 ff ff ff    	jne    3d80 <fwp_poll_events+0x150>
    3e2a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2e:	75 89                	jne    3db9 <fwp_poll_events+0x189>
    3e30:	48 89 d7             	mov    %rdx,%rdi
    3e33:	e8 b8 f1 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    3e38:	e9 43 ff ff ff       	jmp    3d80 <fwp_poll_events+0x150>
    3e3d:	0f 1f 00             	nopl   (%rax)
    3e40:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3e45:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3e4a:	48 89 e7             	mov    %rsp,%rdi
    3e4d:	31 f6                	xor    %esi,%esi
    3e4f:	48 89 14 24          	mov    %rdx,(%rsp)
    3e53:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3e58:	e8 23 e6 ff ff       	call   2480 <nanosleep@plt>
    3e5d:	48 8b 1d b4 a8 01 00 	mov    0x1a8b4(%rip),%rbx        # 1e718 <fwp_timers>
    3e64:	e8 c7 f3 ff ff       	call   3230 <fwp_now_ns>
    3e69:	48 89 c1             	mov    %rax,%rcx
    3e6c:	48 85 db             	test   %rbx,%rbx
    3e6f:	0f 85 03 ff ff ff    	jne    3d78 <fwp_poll_events+0x148>
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3e85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3e8c:	00 00 
    3e8e:	75 2c                	jne    3ebc <fwp_poll_events+0x28c>
    3e90:	48 83 c4 20          	add    $0x20,%rsp
    3e94:	5b                   	pop    %rbx
    3e95:	c3                   	ret
    3e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3e9d:	00 00 00 
    3ea0:	48 89 1d 71 a8 01 00 	mov    %rbx,0x1a871(%rip)        # 1e718 <fwp_timers>
    3ea7:	e9 43 ff ff ff       	jmp    3def <fwp_poll_events+0x1bf>
    3eac:	0f 1f 40 00          	nopl   0x0(%rax)
    3eb0:	48 89 15 71 a8 01 00 	mov    %rdx,0x1a871(%rip)        # 1e728 <fwp_ready_head>
    3eb7:	e9 f6 fe ff ff       	jmp    3db2 <fwp_poll_events+0x182>
    3ebc:	e8 7f e5 ff ff       	call   2440 <__stack_chk_fail@plt>
    3ec1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ecc:	00 00 00 00 

0000000000003ed0 <fwp_rc_forget_slot>:
    3ed0:	80 3f ff             	cmpb   $0xff,(%rdi)
    3ed3:	74 0b                	je     3ee0 <fwp_rc_forget_slot+0x10>
    3ed5:	c3                   	ret
    3ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3edd:	00 00 00 
    3ee0:	48 89 f8             	mov    %rdi,%rax
    3ee3:	48 83 ec 08          	sub    $0x8,%rsp
    3ee7:	48 89 fa             	mov    %rdi,%rdx
    3eea:	48 c1 e8 11          	shr    $0x11,%rax
    3eee:	48 31 f8             	xor    %rdi,%rax
    3ef1:	48 89 c1             	mov    %rax,%rcx
    3ef4:	48 c1 e9 09          	shr    $0x9,%rcx
    3ef8:	48 31 c8             	xor    %rcx,%rax
    3efb:	48 8d 0d 5e a8 01 00 	lea    0x1a85e(%rip),%rcx        # 1e760 <fwp_heap>
    3f02:	0f b6 c0             	movzbl %al,%eax
    3f05:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f0c:	00 
    3f0d:	48 85 ff             	test   %rdi,%rdi
    3f10:	74 3c                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f12:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f19:	00 
    3f1a:	48 8b 01             	mov    (%rcx),%rax
    3f1d:	eb 11                	jmp    3f30 <fwp_rc_forget_slot+0x60>
    3f1f:	90                   	nop
    3f20:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3f24:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3f28:	48 85 ff             	test   %rdi,%rdi
    3f2b:	74 21                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f2d:	48 89 f8             	mov    %rdi,%rax
    3f30:	48 3b 10             	cmp    (%rax),%rdx
    3f33:	75 eb                	jne    3f20 <fwp_rc_forget_slot+0x50>
    3f35:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f39:	48 89 01             	mov    %rax,(%rcx)
    3f3c:	e8 5f e4 ff ff       	call   23a0 <free@plt>
    3f41:	48 83 2d 5f c4 01 00 	subq   $0x1,0x1c45f(%rip)        # 203a8 <fwp_heap+0x1c48>
    3f48:	01 
    3f49:	48 83 c4 08          	add    $0x8,%rsp
    3f4d:	c3                   	ret
    3f4e:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    3f55:	e8 a6 f2 ff ff       	call   3200 <fwp_trap>
    3f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f60 <fwp_rc_prepare_chunk>:
    3f60:	48 83 3d 40 c4 01 00 	cmpq   $0x0,0x1c440(%rip)        # 203a8 <fwp_heap+0x1c48>
    3f67:	00 
    3f68:	41 54                	push   %r12
    3f6a:	49 89 f4             	mov    %rsi,%r12
    3f6d:	55                   	push   %rbp
    3f6e:	48 89 fd             	mov    %rdi,%rbp
    3f71:	53                   	push   %rbx
    3f72:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3f75:	0f 84 7d 00 00 00    	je     3ff8 <fwp_rc_prepare_chunk+0x98>
    3f7b:	31 db                	xor    %ebx,%ebx
    3f7d:	85 c0                	test   %eax,%eax
    3f7f:	75 5f                	jne    3fe0 <fwp_rc_prepare_chunk+0x80>
    3f81:	48 85 f6             	test   %rsi,%rsi
    3f84:	74 7c                	je     4002 <fwp_rc_prepare_chunk+0xa2>
    3f86:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3f8a:	e8 11 e4 ff ff       	call   23a0 <free@plt>
    3f8f:	90                   	nop
    3f90:	be 01 00 00 00       	mov    $0x1,%esi
    3f95:	4c 89 e7             	mov    %r12,%rdi
    3f98:	e8 63 e5 ff ff       	call   2500 <calloc@plt>
    3f9d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3fa1:	48 85 c0             	test   %rax,%rax
    3fa4:	0f 85 87 00 00 00    	jne    4031 <fwp_rc_prepare_chunk+0xd1>
    3faa:	e8 41 ed ff ff       	call   2cf0 <fwp_heap_oom>
    3faf:	90                   	nop
    3fb0:	e8 1b ff ff ff       	call   3ed0 <fwp_rc_forget_slot>
    3fb5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fb8:	48 83 c3 01          	add    $0x1,%rbx
    3fbc:	48 39 c3             	cmp    %rax,%rbx
    3fbf:	73 37                	jae    3ff8 <fwp_rc_prepare_chunk+0x98>
    3fc1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fc8:	00 00 
    3fca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fd1:	00 00 00 00 
    3fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fdc:	00 00 00 00 
    3fe0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3fe4:	48 01 df             	add    %rbx,%rdi
    3fe7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3fea:	74 c4                	je     3fb0 <fwp_rc_prepare_chunk+0x50>
    3fec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fef:	48 83 c3 01          	add    $0x1,%rbx
    3ff3:	48 39 c3             	cmp    %rax,%rbx
    3ff6:	72 e8                	jb     3fe0 <fwp_rc_prepare_chunk+0x80>
    3ff8:	49 39 c4             	cmp    %rax,%r12
    3ffb:	75 13                	jne    4010 <fwp_rc_prepare_chunk+0xb0>
    3ffd:	4d 85 e4             	test   %r12,%r12
    4000:	75 46                	jne    4048 <fwp_rc_prepare_chunk+0xe8>
    4002:	5b                   	pop    %rbx
    4003:	5d                   	pop    %rbp
    4004:	41 5c                	pop    %r12
    4006:	c3                   	ret
    4007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    400e:	00 00 
    4010:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4014:	48 29 05 95 c3 01 00 	sub    %rax,0x1c395(%rip)        # 203b0 <fwp_heap+0x1c50>
    401b:	e8 80 e3 ff ff       	call   23a0 <free@plt>
    4020:	4d 85 e4             	test   %r12,%r12
    4023:	0f 85 67 ff ff ff    	jne    3f90 <fwp_rc_prepare_chunk+0x30>
    4029:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    4030:	00 
    4031:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    4035:	5b                   	pop    %rbx
    4036:	4c 01 25 73 c3 01 00 	add    %r12,0x1c373(%rip)        # 203b0 <fwp_heap+0x1c50>
    403d:	5d                   	pop    %rbp
    403e:	41 5c                	pop    %r12
    4040:	c3                   	ret
    4041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4048:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    404c:	5b                   	pop    %rbx
    404d:	4c 89 e2             	mov    %r12,%rdx
    4050:	31 f6                	xor    %esi,%esi
    4052:	5d                   	pop    %rbp
    4053:	41 5c                	pop    %r12
    4055:	e9 46 e4 ff ff       	jmp    24a0 <memset@plt>
    405a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004060 <fwp_heap_refill>:
    4060:	41 56                	push   %r14
    4062:	41 89 d6             	mov    %edx,%r14d
    4065:	41 55                	push   %r13
    4067:	41 89 f5             	mov    %esi,%r13d
    406a:	41 54                	push   %r12
    406c:	49 89 fc             	mov    %rdi,%r12
    406f:	bf 01 00 00 00       	mov    $0x1,%edi
    4074:	55                   	push   %rbp
    4075:	53                   	push   %rbx
    4076:	e8 b5 ec ff ff       	call   2d30 <fwp_heap_chunks>
    407b:	48 89 c3             	mov    %rax,%rbx
    407e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4082:	48 8b 05 cf ba 01 00 	mov    0x1bacf(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    4089:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    408d:	48 8d 05 cc a6 01 00 	lea    0x1a6cc(%rip),%rax        # 1e760 <fwp_heap>
    4094:	31 d2                	xor    %edx,%edx
    4096:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    409a:	48 89 ef             	mov    %rbp,%rdi
    409d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    40a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    40a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    40ac:	00 
    40ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    40b2:	f7 f1                	div    %ecx
    40b4:	31 d2                	xor    %edx,%edx
    40b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    40ba:	66 0f 6e c8          	movd   %eax,%xmm1
    40be:	89 c6                	mov    %eax,%esi
    40c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    40c5:	48 01 c8             	add    %rcx,%rax
    40c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    40cc:	48 f7 f1             	div    %rcx
    40cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    40d4:	89 45 18             	mov    %eax,0x18(%rbp)
    40d7:	e8 84 fe ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    40dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    40df:	48 89 d8             	mov    %rbx,%rax
    40e2:	48 c1 e0 10          	shl    $0x10,%rax
    40e6:	48 03 05 23 ba 01 00 	add    0x1ba23(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    40ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    40f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    40f6:	8b 55 08             	mov    0x8(%rbp),%edx
    40f9:	48 0f af d1          	imul   %rcx,%rdx
    40fd:	48 01 c2             	add    %rax,%rdx
    4100:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4105:	5b                   	pop    %rbx
    4106:	5d                   	pop    %rbp
    4107:	41 5c                	pop    %r12
    4109:	41 5d                	pop    %r13
    410b:	41 5e                	pop    %r14
    410d:	c3                   	ret
    410e:	66 90                	xchg   %ax,%ax

0000000000004110 <fwp_mem_free>:
    4110:	48 85 ff             	test   %rdi,%rdi
    4113:	0f 84 17 02 00 00    	je     4330 <fwp_mem_free+0x220>
    4119:	48 8b 35 f0 b9 01 00 	mov    0x1b9f0(%rip),%rsi        # 1fb10 <fwp_heap+0x13b0>
    4120:	48 8b 05 11 ba 01 00 	mov    0x1ba11(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    4127:	48 89 fa             	mov    %rdi,%rdx
    412a:	48 29 f2             	sub    %rsi,%rdx
    412d:	48 c1 e0 10          	shl    $0x10,%rax
    4131:	48 39 c2             	cmp    %rax,%rdx
    4134:	0f 83 f6 01 00 00    	jae    4330 <fwp_mem_free+0x220>
    413a:	49 89 d1             	mov    %rdx,%r9
    413d:	49 c1 e9 10          	shr    $0x10,%r9
    4141:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4145:	48 c1 e0 03          	shl    $0x3,%rax
    4149:	49 89 c0             	mov    %rax,%r8
    414c:	4c 03 05 05 ba 01 00 	add    0x1ba05(%rip),%r8        # 1fb58 <fwp_heap+0x13f8>
    4153:	0f 84 d7 01 00 00    	je     4330 <fwp_mem_free+0x220>
    4159:	48 83 ec 38          	sub    $0x38,%rsp
    415d:	48 89 f9             	mov    %rdi,%rcx
    4160:	41 0f b6 38          	movzbl (%r8),%edi
    4164:	40 80 ff 01          	cmp    $0x1,%dil
    4168:	74 16                	je     4180 <fwp_mem_free+0x70>
    416a:	40 80 ff 02          	cmp    $0x2,%dil
    416e:	0f 84 94 00 00 00    	je     4208 <fwp_mem_free+0xf8>
    4174:	48 83 c4 38          	add    $0x38,%rsp
    4178:	c3                   	ret
    4179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4180:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4184:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4189:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    418e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4192:	4d 85 d2             	test   %r10,%r10
    4195:	74 1d                	je     41b4 <fwp_mem_free+0xa4>
    4197:	0f b7 c1             	movzwl %cx,%eax
    419a:	31 d2                	xor    %edx,%edx
    419c:	48 f7 f7             	div    %rdi
    419f:	49 01 c2             	add    %rax,%r10
    41a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    41a6:	0f 84 44 01 00 00    	je     42f0 <fwp_mem_free+0x1e0>
    41ac:	41 c6 02 00          	movb   $0x0,(%r10)
    41b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    41b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    41bb:	49 63 c1             	movslq %r9d,%rax
    41be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    41c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    41c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    41cb:	f2 0f 58 05 cd b9 01 	addsd  0x1b9cd(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    41d2:	00 
    41d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    41d7:	48 8d 05 82 a5 01 00 	lea    0x1a582(%rip),%rax        # 1e760 <fwp_heap>
    41de:	48 01 d0             	add    %rdx,%rax
    41e1:	48 8b 10             	mov    (%rax),%rdx
    41e4:	48 f7 d2             	not    %rdx
    41e7:	48 89 11             	mov    %rdx,(%rcx)
    41ea:	48 89 08             	mov    %rcx,(%rax)
    41ed:	48 29 3d 8c b9 01 00 	sub    %rdi,0x1b98c(%rip)        # 1fb80 <fwp_heap+0x1420>
    41f4:	f2 0f 11 05 a4 b9 01 	movsd  %xmm0,0x1b9a4(%rip)        # 1fba0 <fwp_heap+0x1440>
    41fb:	00 
    41fc:	48 83 c4 38          	add    $0x38,%rsp
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	66 31 d2             	xor    %dx,%dx
    420b:	48 01 d6             	add    %rdx,%rsi
    420e:	48 39 f1             	cmp    %rsi,%rcx
    4211:	0f 85 5d ff ff ff    	jne    4174 <fwp_mem_free+0x64>
    4217:	49 8b 50 10          	mov    0x10(%r8),%rdx
    421b:	48 29 15 5e b9 01 00 	sub    %rdx,0x1b95e(%rip)        # 1fb80 <fwp_heap+0x1420>
    4222:	48 85 d2             	test   %rdx,%rdx
    4225:	0f 88 a5 00 00 00    	js     42d0 <fwp_mem_free+0x1c0>
    422b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    422f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4234:	f2 0f 58 05 64 b9 01 	addsd  0x1b964(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    423b:	00 
    423c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4240:	f2 0f 11 05 58 b9 01 	movsd  %xmm0,0x1b958(%rip)        # 1fba0 <fwp_heap+0x1440>
    4247:	00 
    4248:	48 85 d2             	test   %rdx,%rdx
    424b:	74 0c                	je     4259 <fwp_mem_free+0x149>
    424d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4250:	0f 84 db 00 00 00    	je     4331 <fwp_mem_free+0x221>
    4256:	c6 02 00             	movb   $0x0,(%rdx)
    4259:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    425d:	48 85 c9             	test   %rcx,%rcx
    4260:	74 3e                	je     42a0 <fwp_mem_free+0x190>
    4262:	48 8b 15 ef b8 01 00 	mov    0x1b8ef(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    4269:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    426d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4271:	48 01 d0             	add    %rdx,%rax
    4274:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4278:	48 89 d6             	mov    %rdx,%rsi
    427b:	48 29 c6             	sub    %rax,%rsi
    427e:	83 e6 08             	and    $0x8,%esi
    4281:	74 0d                	je     4290 <fwp_mem_free+0x180>
    4283:	c6 00 00             	movb   $0x0,(%rax)
    4286:	48 83 c0 28          	add    $0x28,%rax
    428a:	48 39 c2             	cmp    %rax,%rdx
    428d:	74 11                	je     42a0 <fwp_mem_free+0x190>
    428f:	90                   	nop
    4290:	c6 00 00             	movb   $0x0,(%rax)
    4293:	48 83 c0 50          	add    $0x50,%rax
    4297:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    429b:	48 39 c2             	cmp    %rax,%rdx
    429e:	75 f0                	jne    4290 <fwp_mem_free+0x180>
    42a0:	48 01 0d e9 b8 01 00 	add    %rcx,0x1b8e9(%rip)        # 1fb90 <fwp_heap+0x1430>
    42a7:	4c 3b 0d a2 b8 01 00 	cmp    0x1b8a2(%rip),%r9        # 1fb50 <fwp_heap+0x13f0>
    42ae:	73 07                	jae    42b7 <fwp_mem_free+0x1a7>
    42b0:	4c 89 0d 99 b8 01 00 	mov    %r9,0x1b899(%rip)        # 1fb50 <fwp_heap+0x13f0>
    42b7:	4c 3b 0d 8a b8 01 00 	cmp    0x1b88a(%rip),%r9        # 1fb48 <fwp_heap+0x13e8>
    42be:	0f 83 b0 fe ff ff    	jae    4174 <fwp_mem_free+0x64>
    42c4:	4c 89 0d 7d b8 01 00 	mov    %r9,0x1b87d(%rip)        # 1fb48 <fwp_heap+0x13e8>
    42cb:	e9 a4 fe ff ff       	jmp    4174 <fwp_mem_free+0x64>
    42d0:	48 89 d1             	mov    %rdx,%rcx
    42d3:	83 e2 01             	and    $0x1,%edx
    42d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42da:	48 d1 e9             	shr    $1,%rcx
    42dd:	48 09 d1             	or     %rdx,%rcx
    42e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    42e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    42e9:	e9 46 ff ff ff       	jmp    4234 <fwp_mem_free+0x124>
    42ee:	66 90                	xchg   %ax,%ax
    42f0:	4c 89 d7             	mov    %r10,%rdi
    42f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    42f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    42fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4302:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4306:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    430b:	e8 c0 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4310:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4315:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    431a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    431f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    4324:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    4329:	e9 7e fe ff ff       	jmp    41ac <fwp_mem_free+0x9c>
    432e:	66 90                	xchg   %ax,%ax
    4330:	c3                   	ret
    4331:	48 89 d7             	mov    %rdx,%rdi
    4334:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    4339:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    433e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4343:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4348:	e8 83 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    434d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4352:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4357:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    435c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4361:	e9 f0 fe ff ff       	jmp    4256 <fwp_mem_free+0x146>
    4366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    436d:	00 00 00 

0000000000004370 <fwp_heap_alloc_big>:
    4370:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4377:	00 00 40 
    437a:	41 57                	push   %r15
    437c:	41 56                	push   %r14
    437e:	41 55                	push   %r13
    4380:	41 54                	push   %r12
    4382:	55                   	push   %rbp
    4383:	53                   	push   %rbx
    4384:	48 83 ec 08          	sub    $0x8,%rsp
    4388:	48 39 f8             	cmp    %rdi,%rax
    438b:	0f 82 fa 00 00 00    	jb     448b <fwp_heap_alloc_big+0x11b>
    4391:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4398:	49 89 fd             	mov    %rdi,%r13
    439b:	41 89 f6             	mov    %esi,%r14d
    439e:	48 c1 ed 10          	shr    $0x10,%rbp
    43a2:	48 89 ef             	mov    %rbp,%rdi
    43a5:	e8 86 e9 ff ff       	call   2d30 <fwp_heap_chunks>
    43aa:	be 01 00 00 00       	mov    $0x1,%esi
    43af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    43b3:	49 89 c4             	mov    %rax,%r12
    43b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    43bd:	00 
    43be:	48 03 3d 93 b7 01 00 	add    0x1b793(%rip),%rdi        # 1fb58 <fwp_heap+0x13f8>
    43c5:	c6 07 02             	movb   $0x2,(%rdi)
    43c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    43cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    43cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    43d3:	e8 88 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    43d8:	48 83 fd 01          	cmp    $0x1,%rbp
    43dc:	76 47                	jbe    4425 <fwp_heap_alloc_big+0xb5>
    43de:	4c 01 e5             	add    %r12,%rbp
    43e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    43e8:	00 
    43e9:	4c 8d 3d 70 a3 01 00 	lea    0x1a370(%rip),%r15        # 1e760 <fwp_heap>
    43f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    43f5:	49 c1 e6 03          	shl    $0x3,%r14
    43f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4400:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4407:	31 f6                	xor    %esi,%esi
    4409:	48 01 dd             	add    %rbx,%rbp
    440c:	48 83 c3 28          	add    $0x28,%rbx
    4410:	48 89 ef             	mov    %rbp,%rdi
    4413:	e8 48 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    4418:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    441c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    4420:	49 39 de             	cmp    %rbx,%r14
    4423:	75 db                	jne    4400 <fwp_heap_alloc_big+0x90>
    4425:	49 c1 e4 10          	shl    $0x10,%r12
    4429:	4c 03 25 e0 b6 01 00 	add    0x1b6e0(%rip),%r12        # 1fb10 <fwp_heap+0x13b0>
    4430:	4c 89 ea             	mov    %r13,%rdx
    4433:	31 f6                	xor    %esi,%esi
    4435:	4c 89 e7             	mov    %r12,%rdi
    4438:	e8 63 e0 ff ff       	call   24a0 <memset@plt>
    443d:	4c 89 e8             	mov    %r13,%rax
    4440:	48 03 05 39 b7 01 00 	add    0x1b739(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4447:	72 42                	jb     448b <fwp_heap_alloc_big+0x11b>
    4449:	48 39 05 38 b7 01 00 	cmp    %rax,0x1b738(%rip)        # 1fb88 <fwp_heap+0x1428>
    4450:	48 89 05 29 b7 01 00 	mov    %rax,0x1b729(%rip)        # 1fb80 <fwp_heap+0x1420>
    4457:	73 07                	jae    4460 <fwp_heap_alloc_big+0xf0>
    4459:	48 89 05 28 b7 01 00 	mov    %rax,0x1b728(%rip)        # 1fb88 <fwp_heap+0x1428>
    4460:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4464:	4c 89 e0             	mov    %r12,%rax
    4467:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    446c:	f2 0f 58 05 24 b7 01 	addsd  0x1b724(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4473:	00 
    4474:	f2 0f 11 05 1c b7 01 	movsd  %xmm0,0x1b71c(%rip)        # 1fb98 <fwp_heap+0x1438>
    447b:	00 
    447c:	48 83 c4 08          	add    $0x8,%rsp
    4480:	5b                   	pop    %rbx
    4481:	5d                   	pop    %rbp
    4482:	41 5c                	pop    %r12
    4484:	41 5d                	pop    %r13
    4486:	41 5e                	pop    %r14
    4488:	41 5f                	pop    %r15
    448a:	c3                   	ret
    448b:	e8 60 e8 ff ff       	call   2cf0 <fwp_heap_oom>

0000000000004490 <fwp_heap_alloc_slow>:
    4490:	53                   	push   %rbx
    4491:	48 89 f9             	mov    %rdi,%rcx
    4494:	41 89 f1             	mov    %esi,%r9d
    4497:	48 83 ec 10          	sub    $0x10,%rsp
    449b:	8b 05 63 b6 01 00    	mov    0x1b663(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    44a1:	85 c0                	test   %eax,%eax
    44a3:	0f 84 c7 00 00 00    	je     4570 <fwp_heap_alloc_slow+0xe0>
    44a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    44b0:	0f 87 dd 00 00 00    	ja     4593 <fwp_heap_alloc_slow+0x103>
    44b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    44ba:	48 8d 3d 9f a2 01 00 	lea    0x1a29f(%rip),%rdi        # 1e760 <fwp_heap>
    44c1:	49 63 f1             	movslq %r9d,%rsi
    44c4:	48 c1 e8 04          	shr    $0x4,%rax
    44c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    44cf:	00 00 
    44d1:	41 0f b6 c2          	movzbl %r10b,%eax
    44d5:	4c 89 d2             	mov    %r10,%rdx
    44d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    44dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    44e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    44ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    44ee:	48 01 f8             	add    %rdi,%rax
    44f1:	4c 8b 00             	mov    (%rax),%r8
    44f4:	4d 85 c0             	test   %r8,%r8
    44f7:	0f 84 ab 00 00 00    	je     45a8 <fwp_heap_alloc_slow+0x118>
    44fd:	49 8b 10             	mov    (%r8),%rdx
    4500:	48 f7 d2             	not    %rdx
    4503:	48 89 10             	mov    %rdx,(%rax)
    4506:	41 83 f9 01          	cmp    $0x1,%r9d
    450a:	4c 89 c7             	mov    %r8,%rdi
    450d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4511:	31 f6                	xor    %esi,%esi
    4513:	48 89 ca             	mov    %rcx,%rdx
    4516:	e8 85 df ff ff       	call   24a0 <memset@plt>
    451b:	49 89 c0             	mov    %rax,%r8
    451e:	48 89 d8             	mov    %rbx,%rax
    4521:	48 03 05 58 b6 01 00 	add    0x1b658(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4528:	0f 82 d9 00 00 00    	jb     4607 <fwp_heap_alloc_slow+0x177>
    452e:	48 39 05 53 b6 01 00 	cmp    %rax,0x1b653(%rip)        # 1fb88 <fwp_heap+0x1428>
    4535:	48 89 05 44 b6 01 00 	mov    %rax,0x1b644(%rip)        # 1fb80 <fwp_heap+0x1420>
    453c:	73 07                	jae    4545 <fwp_heap_alloc_slow+0xb5>
    453e:	48 89 05 43 b6 01 00 	mov    %rax,0x1b643(%rip)        # 1fb88 <fwp_heap+0x1428>
    4545:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4549:	4c 89 c0             	mov    %r8,%rax
    454c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4551:	f2 0f 58 05 3f b6 01 	addsd  0x1b63f(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4558:	00 
    4559:	f2 0f 11 05 37 b6 01 	movsd  %xmm0,0x1b637(%rip)        # 1fb98 <fwp_heap+0x1438>
    4560:	00 
    4561:	48 83 c4 10          	add    $0x10,%rsp
    4565:	5b                   	pop    %rbx
    4566:	c3                   	ret
    4567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    456e:	00 00 
    4570:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4574:	48 89 3c 24          	mov    %rdi,(%rsp)
    4578:	e8 b3 f3 ff ff       	call   3930 <fwp_heap_init>
    457d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4581:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4586:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    458d:	0f 86 23 ff ff ff    	jbe    44b6 <fwp_heap_alloc_slow+0x26>
    4593:	48 83 c4 10          	add    $0x10,%rsp
    4597:	44 89 ce             	mov    %r9d,%esi
    459a:	48 89 cf             	mov    %rcx,%rdi
    459d:	5b                   	pop    %rbx
    459e:	e9 cd fd ff ff       	jmp    4370 <fwp_heap_alloc_big>
    45a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    45ac:	4d 85 c0             	test   %r8,%r8
    45af:	74 1f                	je     45d0 <fwp_heap_alloc_slow+0x140>
    45b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    45b5:	4d 29 c3             	sub    %r8,%r11
    45b8:	49 39 db             	cmp    %rbx,%r11
    45bb:	72 13                	jb     45d0 <fwp_heap_alloc_slow+0x140>
    45bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    45c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    45c5:	e9 3c ff ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    45ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    45d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    45d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    45db:	44 89 ca             	mov    %r9d,%edx
    45de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    45e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    45e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    45eb:	44 89 d6             	mov    %r10d,%esi
    45ee:	48 01 c7             	add    %rax,%rdi
    45f1:	e8 6a fa ff ff       	call   4060 <fwp_heap_refill>
    45f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    45fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    45ff:	49 89 c0             	mov    %rax,%r8
    4602:	e9 ff fe ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    4607:	e8 e4 e6 ff ff       	call   2cf0 <fwp_heap_oom>
    460c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004610 <fwp_rc_fresh>:
    4610:	48 8b 15 21 b5 01 00 	mov    0x1b521(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    4617:	48 89 f8             	mov    %rdi,%rax
    461a:	48 89 fe             	mov    %rdi,%rsi
    461d:	48 2b 05 ec b4 01 00 	sub    0x1b4ec(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4624:	48 c1 e2 10          	shl    $0x10,%rdx
    4628:	48 39 d0             	cmp    %rdx,%rax
    462b:	73 4f                	jae    467c <fwp_rc_fresh+0x6c>
    462d:	48 89 c2             	mov    %rax,%rdx
    4630:	48 c1 ea 10          	shr    $0x10,%rdx
    4634:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4638:	48 8b 15 19 b5 01 00 	mov    0x1b519(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    463f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4643:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4647:	48 85 d2             	test   %rdx,%rdx
    464a:	74 30                	je     467c <fwp_rc_fresh+0x6c>
    464c:	0f b6 39             	movzbl (%rcx),%edi
    464f:	40 80 ff 02          	cmp    $0x2,%dil
    4653:	74 2b                	je     4680 <fwp_rc_fresh+0x70>
    4655:	40 80 ff 01          	cmp    $0x1,%dil
    4659:	75 21                	jne    467c <fwp_rc_fresh+0x6c>
    465b:	8b 79 18             	mov    0x18(%rcx),%edi
    465e:	0f b7 c0             	movzwl %ax,%eax
    4661:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4664:	48 0f af c7          	imul   %rdi,%rax
    4668:	48 c1 e8 20          	shr    $0x20,%rax
    466c:	48 39 c8             	cmp    %rcx,%rax
    466f:	73 0b                	jae    467c <fwp_rc_fresh+0x6c>
    4671:	48 01 c2             	add    %rax,%rdx
    4674:	80 3a ff             	cmpb   $0xff,(%rdx)
    4677:	74 17                	je     4690 <fwp_rc_fresh+0x80>
    4679:	c6 02 01             	movb   $0x1,(%rdx)
    467c:	48 89 f0             	mov    %rsi,%rax
    467f:	c3                   	ret
    4680:	66 85 c0             	test   %ax,%ax
    4683:	74 ef                	je     4674 <fwp_rc_fresh+0x64>
    4685:	48 89 f0             	mov    %rsi,%rax
    4688:	c3                   	ret
    4689:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4690:	48 83 ec 18          	sub    $0x18,%rsp
    4694:	48 89 d7             	mov    %rdx,%rdi
    4697:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    469c:	48 89 14 24          	mov    %rdx,(%rsp)
    46a0:	e8 2b f8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    46a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    46aa:	48 8b 14 24          	mov    (%rsp),%rdx
    46ae:	48 89 f0             	mov    %rsi,%rax
    46b1:	c6 02 01             	movb   $0x1,(%rdx)
    46b4:	48 83 c4 18          	add    $0x18,%rsp
    46b8:	c3                   	ret
    46b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000046c0 <fwp_rc_free_arr>:
    46c0:	48 8b 15 71 b4 01 00 	mov    0x1b471(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    46c7:	48 89 f8             	mov    %rdi,%rax
    46ca:	48 2b 05 3f b4 01 00 	sub    0x1b43f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    46d1:	48 c1 e2 10          	shl    $0x10,%rdx
    46d5:	48 39 d0             	cmp    %rdx,%rax
    46d8:	73 5b                	jae    4735 <fwp_rc_free_arr+0x75>
    46da:	48 89 c2             	mov    %rax,%rdx
    46dd:	48 c1 ea 10          	shr    $0x10,%rdx
    46e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    46e5:	48 8b 15 6c b4 01 00 	mov    0x1b46c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    46ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    46f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    46f4:	48 85 c9             	test   %rcx,%rcx
    46f7:	74 3c                	je     4735 <fwp_rc_free_arr+0x75>
    46f9:	0f b6 32             	movzbl (%rdx),%esi
    46fc:	40 80 fe 02          	cmp    $0x2,%sil
    4700:	74 2e                	je     4730 <fwp_rc_free_arr+0x70>
    4702:	40 80 fe 01          	cmp    $0x1,%sil
    4706:	75 2d                	jne    4735 <fwp_rc_free_arr+0x75>
    4708:	8b 72 18             	mov    0x18(%rdx),%esi
    470b:	0f b7 c0             	movzwl %ax,%eax
    470e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4711:	48 0f af c6          	imul   %rsi,%rax
    4715:	48 c1 e8 20          	shr    $0x20,%rax
    4719:	48 39 d0             	cmp    %rdx,%rax
    471c:	73 17                	jae    4735 <fwp_rc_free_arr+0x75>
    471e:	48 01 c1             	add    %rax,%rcx
    4721:	80 39 01             	cmpb   $0x1,(%rcx)
    4724:	75 0f                	jne    4735 <fwp_rc_free_arr+0x75>
    4726:	e9 e5 f9 ff ff       	jmp    4110 <fwp_mem_free>
    472b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4730:	66 85 c0             	test   %ax,%ax
    4733:	74 ec                	je     4721 <fwp_rc_free_arr+0x61>
    4735:	c3                   	ret
    4736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    473d:	00 00 00 

0000000000004740 <fwp_heap_alloc>:
    4740:	53                   	push   %rbx
    4741:	48 89 fa             	mov    %rdi,%rdx
    4744:	48 83 ec 10          	sub    $0x10,%rsp
    4748:	8b 1d d2 bc 01 00    	mov    0x1bcd2(%rip),%ebx        # 20420 <iteration_active>
    474e:	8b 05 b0 b3 01 00    	mov    0x1b3b0(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    4754:	85 db                	test   %ebx,%ebx
    4756:	0f 85 04 01 00 00    	jne    4860 <fwp_heap_alloc+0x120>
    475c:	85 c0                	test   %eax,%eax
    475e:	0f 84 ac 01 00 00    	je     4910 <fwp_heap_alloc+0x1d0>
    4764:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    476b:	0f 87 9f 01 00 00    	ja     4910 <fwp_heap_alloc+0x1d0>
    4771:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4775:	48 8d 05 e4 9f 01 00 	lea    0x19fe4(%rip),%rax        # 1e760 <fwp_heap>
    477c:	48 c1 e9 04          	shr    $0x4,%rcx
    4780:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    4787:	00 
    4788:	48 63 ce             	movslq %esi,%rcx
    478b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4792:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    4799:	00 
    479a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    479e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    47a2:	48 01 c8             	add    %rcx,%rax
    47a5:	48 8b 08             	mov    (%rax),%rcx
    47a8:	48 85 c9             	test   %rcx,%rcx
    47ab:	0f 84 ff 00 00 00    	je     48b0 <fwp_heap_alloc+0x170>
    47b1:	48 8b 39             	mov    (%rcx),%rdi
    47b4:	48 f7 d7             	not    %rdi
    47b7:	48 89 38             	mov    %rdi,(%rax)
    47ba:	83 fe 01             	cmp    $0x1,%esi
    47bd:	48 89 cf             	mov    %rcx,%rdi
    47c0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    47c5:	49 0f 45 d0          	cmovne %r8,%rdx
    47c9:	31 f6                	xor    %esi,%esi
    47cb:	e8 d0 dc ff ff       	call   24a0 <memset@plt>
    47d0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    47d5:	48 89 c1             	mov    %rax,%rcx
    47d8:	4c 89 c0             	mov    %r8,%rax
    47db:	48 03 05 9e b3 01 00 	add    0x1b39e(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    47e2:	0f 82 35 01 00 00    	jb     491d <fwp_heap_alloc+0x1dd>
    47e8:	48 39 05 99 b3 01 00 	cmp    %rax,0x1b399(%rip)        # 1fb88 <fwp_heap+0x1428>
    47ef:	48 89 05 8a b3 01 00 	mov    %rax,0x1b38a(%rip)        # 1fb80 <fwp_heap+0x1420>
    47f6:	73 07                	jae    47ff <fwp_heap_alloc+0xbf>
    47f8:	48 89 05 89 b3 01 00 	mov    %rax,0x1b389(%rip)        # 1fb88 <fwp_heap+0x1428>
    47ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4803:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4808:	f2 0f 58 05 88 b3 01 	addsd  0x1b388(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    480f:	00 
    4810:	f2 0f 11 05 80 b3 01 	movsd  %xmm0,0x1b380(%rip)        # 1fb98 <fwp_heap+0x1438>
    4817:	00 
    4818:	85 db                	test   %ebx,%ebx
    481a:	74 33                	je     484f <fwp_heap_alloc+0x10f>
    481c:	48 8b 05 5d b3 01 00 	mov    0x1b35d(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4823:	48 85 c0             	test   %rax,%rax
    4826:	0f 88 ac 00 00 00    	js     48d8 <fwp_heap_alloc+0x198>
    482c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4830:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4835:	f2 0f 5c 05 c3 bb 01 	subsd  0x1bbc3(%rip),%xmm0        # 20400 <iteration_start_charge>
    483c:	00 
    483d:	66 0f 2f 05 b3 bb 01 	comisd 0x1bbb3(%rip),%xmm0        # 203f8 <iteration_peak>
    4844:	00 
    4845:	76 08                	jbe    484f <fwp_heap_alloc+0x10f>
    4847:	f2 0f 11 05 a9 bb 01 	movsd  %xmm0,0x1bba9(%rip)        # 203f8 <iteration_peak>
    484e:	00 
    484f:	48 83 c4 10          	add    $0x10,%rsp
    4853:	48 89 c8             	mov    %rcx,%rax
    4856:	5b                   	pop    %rbx
    4857:	c3                   	ret
    4858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    485f:	00 
    4860:	85 f6                	test   %esi,%esi
    4862:	74 34                	je     4898 <fwp_heap_alloc+0x158>
    4864:	48 83 05 ac bb 01 00 	addq   $0x1,0x1bbac(%rip)        # 20418 <iteration_requests>
    486b:	01 
    486c:	48 01 3d 9d bb 01 00 	add    %rdi,0x1bb9d(%rip)        # 20410 <iteration_bytes>
    4873:	85 c0                	test   %eax,%eax
    4875:	74 0d                	je     4884 <fwp_heap_alloc+0x144>
    4877:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    487e:	0f 86 ed fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    4884:	48 89 d7             	mov    %rdx,%rdi
    4887:	e8 04 fc ff ff       	call   4490 <fwp_heap_alloc_slow>
    488c:	48 89 c1             	mov    %rax,%rcx
    488f:	eb 8b                	jmp    481c <fwp_heap_alloc+0xdc>
    4891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4898:	85 c0                	test   %eax,%eax
    489a:	74 0d                	je     48a9 <fwp_heap_alloc+0x169>
    489c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    48a3:	0f 86 c8 fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    48a9:	31 f6                	xor    %esi,%esi
    48ab:	eb d7                	jmp    4884 <fwp_heap_alloc+0x144>
    48ad:	0f 1f 00             	nopl   (%rax)
    48b0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    48b4:	48 85 c9             	test   %rcx,%rcx
    48b7:	74 0c                	je     48c5 <fwp_heap_alloc+0x185>
    48b9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    48bd:	48 29 cf             	sub    %rcx,%rdi
    48c0:	4c 39 c7             	cmp    %r8,%rdi
    48c3:	73 3b                	jae    4900 <fwp_heap_alloc+0x1c0>
    48c5:	48 89 d7             	mov    %rdx,%rdi
    48c8:	e8 c3 fb ff ff       	call   4490 <fwp_heap_alloc_slow>
    48cd:	48 89 c1             	mov    %rax,%rcx
    48d0:	e9 43 ff ff ff       	jmp    4818 <fwp_heap_alloc+0xd8>
    48d5:	0f 1f 00             	nopl   (%rax)
    48d8:	48 89 c2             	mov    %rax,%rdx
    48db:	83 e0 01             	and    $0x1,%eax
    48de:	66 0f ef c0          	pxor   %xmm0,%xmm0
    48e2:	48 d1 ea             	shr    $1,%rdx
    48e5:	48 09 c2             	or     %rax,%rdx
    48e8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    48ed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    48f1:	e9 3f ff ff ff       	jmp    4835 <fwp_heap_alloc+0xf5>
    48f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    48fd:	00 00 00 
    4900:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    4904:	48 89 78 08          	mov    %rdi,0x8(%rax)
    4908:	e9 ad fe ff ff       	jmp    47ba <fwp_heap_alloc+0x7a>
    490d:	0f 1f 00             	nopl   (%rax)
    4910:	48 83 c4 10          	add    $0x10,%rsp
    4914:	48 89 d7             	mov    %rdx,%rdi
    4917:	5b                   	pop    %rbx
    4918:	e9 73 fb ff ff       	jmp    4490 <fwp_heap_alloc_slow>
    491d:	e8 ce e3 ff ff       	call   2cf0 <fwp_heap_oom>
    4922:	0f 1f 00             	nopl   (%rax)
    4925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    492c:	00 00 00 00 

0000000000004930 <fwp_data.part.0.constprop.0>:
    4930:	41 56                	push   %r14
    4932:	8b 05 cc b1 01 00    	mov    0x1b1cc(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    4938:	41 89 fe             	mov    %edi,%r14d
    493b:	41 55                	push   %r13
    493d:	44 8b 2d dc ba 01 00 	mov    0x1badc(%rip),%r13d        # 20420 <iteration_active>
    4944:	41 54                	push   %r12
    4946:	49 89 f4             	mov    %rsi,%r12
    4949:	55                   	push   %rbp
    494a:	53                   	push   %rbx
    494b:	45 85 ed             	test   %r13d,%r13d
    494e:	0f 84 1c 01 00 00    	je     4a70 <fwp_data.part.0.constprop.0+0x140>
    4954:	48 83 05 bc ba 01 00 	addq   $0x1,0x1babc(%rip)        # 20418 <iteration_requests>
    495b:	01 
    495c:	48 83 05 ac ba 01 00 	addq   $0x18,0x1baac(%rip)        # 20410 <iteration_bytes>
    4963:	18 
    4964:	85 c0                	test   %eax,%eax
    4966:	0f 84 8c 01 00 00    	je     4af8 <fwp_data.part.0.constprop.0+0x1c8>
    496c:	0f b6 05 8f ad 01 00 	movzbl 0x1ad8f(%rip),%eax        # 1f702 <fwp_heap+0xfa2>
    4973:	48 8d 15 e6 9d 01 00 	lea    0x19de6(%rip),%rdx        # 1e760 <fwp_heap>
    497a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    4981:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4985:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    4989:	48 8b 18             	mov    (%rax),%rbx
    498c:	48 85 db             	test   %rbx,%rbx
    498f:	0f 84 fb 00 00 00    	je     4a90 <fwp_data.part.0.constprop.0+0x160>
    4995:	48 8b 13             	mov    (%rbx),%rdx
    4998:	48 f7 d2             	not    %rdx
    499b:	48 89 10             	mov    %rdx,(%rax)
    499e:	48 83 fd 18          	cmp    $0x18,%rbp
    49a2:	76 1b                	jbe    49bf <fwp_data.part.0.constprop.0+0x8f>
    49a4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    49a8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    49ac:	31 f6                	xor    %esi,%esi
    49ae:	48 c1 e8 03          	shr    $0x3,%rax
    49b2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    49b9:	00 
    49ba:	e8 e1 da ff ff       	call   24a0 <memset@plt>
    49bf:	48 89 e8             	mov    %rbp,%rax
    49c2:	48 03 05 b7 b1 01 00 	add    0x1b1b7(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    49c9:	0f 82 3d 01 00 00    	jb     4b0c <fwp_data.part.0.constprop.0+0x1dc>
    49cf:	48 39 05 b2 b1 01 00 	cmp    %rax,0x1b1b2(%rip)        # 1fb88 <fwp_heap+0x1428>
    49d6:	48 89 05 a3 b1 01 00 	mov    %rax,0x1b1a3(%rip)        # 1fb80 <fwp_heap+0x1420>
    49dd:	73 07                	jae    49e6 <fwp_data.part.0.constprop.0+0xb6>
    49df:	48 89 05 a2 b1 01 00 	mov    %rax,0x1b1a2(%rip)        # 1fb88 <fwp_heap+0x1428>
    49e6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49ea:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    49ef:	f2 0f 58 05 a1 b1 01 	addsd  0x1b1a1(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    49f6:	00 
    49f7:	f2 0f 11 05 99 b1 01 	movsd  %xmm0,0x1b199(%rip)        # 1fb98 <fwp_heap+0x1438>
    49fe:	00 
    49ff:	45 85 ed             	test   %r13d,%r13d
    4a02:	74 33                	je     4a37 <fwp_data.part.0.constprop.0+0x107>
    4a04:	48 8b 05 75 b1 01 00 	mov    0x1b175(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4a0b:	48 85 c0             	test   %rax,%rax
    4a0e:	0f 88 a4 00 00 00    	js     4ab8 <fwp_data.part.0.constprop.0+0x188>
    4a14:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4a18:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4a1d:	f2 0f 5c 05 db b9 01 	subsd  0x1b9db(%rip),%xmm0        # 20400 <iteration_start_charge>
    4a24:	00 
    4a25:	66 0f 2f 05 cb b9 01 	comisd 0x1b9cb(%rip),%xmm0        # 203f8 <iteration_peak>
    4a2c:	00 
    4a2d:	76 08                	jbe    4a37 <fwp_data.part.0.constprop.0+0x107>
    4a2f:	f2 0f 11 05 c1 b9 01 	movsd  %xmm0,0x1b9c1(%rip)        # 203f8 <iteration_peak>
    4a36:	00 
    4a37:	b8 02 00 00 00       	mov    $0x2,%eax
    4a3c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    4a41:	66 0f 6e c8          	movd   %eax,%xmm1
    4a45:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    4a49:	66 0f d6 03          	movq   %xmm0,(%rbx)
    4a4d:	49 8b 04 24          	mov    (%r12),%rax
    4a51:	48 89 43 08          	mov    %rax,0x8(%rbx)
    4a55:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    4a5a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4a5e:	48 89 d8             	mov    %rbx,%rax
    4a61:	5b                   	pop    %rbx
    4a62:	5d                   	pop    %rbp
    4a63:	41 5c                	pop    %r12
    4a65:	41 5d                	pop    %r13
    4a67:	41 5e                	pop    %r14
    4a69:	c3                   	ret
    4a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a70:	85 c0                	test   %eax,%eax
    4a72:	0f 85 f4 fe ff ff    	jne    496c <fwp_data.part.0.constprop.0+0x3c>
    4a78:	31 f6                	xor    %esi,%esi
    4a7a:	bf 18 00 00 00       	mov    $0x18,%edi
    4a7f:	e8 bc fc ff ff       	call   4740 <fwp_heap_alloc>
    4a84:	48 89 c3             	mov    %rax,%rbx
    4a87:	eb ae                	jmp    4a37 <fwp_data.part.0.constprop.0+0x107>
    4a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a90:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4a94:	48 85 db             	test   %rbx,%rbx
    4a97:	74 47                	je     4ae0 <fwp_data.part.0.constprop.0+0x1b0>
    4a99:	48 8b 50 10          	mov    0x10(%rax),%rdx
    4a9d:	48 29 da             	sub    %rbx,%rdx
    4aa0:	48 39 ea             	cmp    %rbp,%rdx
    4aa3:	72 3b                	jb     4ae0 <fwp_data.part.0.constprop.0+0x1b0>
    4aa5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4aa9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4aad:	e9 ec fe ff ff       	jmp    499e <fwp_data.part.0.constprop.0+0x6e>
    4ab2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ab8:	48 89 c2             	mov    %rax,%rdx
    4abb:	83 e0 01             	and    $0x1,%eax
    4abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4ac2:	48 d1 ea             	shr    $1,%rdx
    4ac5:	48 09 c2             	or     %rax,%rdx
    4ac8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4acd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4ad1:	e9 47 ff ff ff       	jmp    4a1d <fwp_data.part.0.constprop.0+0xed>
    4ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4add:	00 00 00 
    4ae0:	31 f6                	xor    %esi,%esi
    4ae2:	bf 18 00 00 00       	mov    $0x18,%edi
    4ae7:	e8 54 fc ff ff       	call   4740 <fwp_heap_alloc>
    4aec:	48 89 c3             	mov    %rax,%rbx
    4aef:	e9 0b ff ff ff       	jmp    49ff <fwp_data.part.0.constprop.0+0xcf>
    4af4:	0f 1f 40 00          	nopl   0x0(%rax)
    4af8:	31 f6                	xor    %esi,%esi
    4afa:	bf 18 00 00 00       	mov    $0x18,%edi
    4aff:	e8 3c fc ff ff       	call   4740 <fwp_heap_alloc>
    4b04:	48 89 c3             	mov    %rax,%rbx
    4b07:	e9 f8 fe ff ff       	jmp    4a04 <fwp_data.part.0.constprop.0+0xd4>
    4b0c:	e8 df e1 ff ff       	call   2cf0 <fwp_heap_oom>
    4b11:	0f 1f 40 00          	nopl   0x0(%rax)
    4b15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b1c:	00 00 00 00 

0000000000004b20 <fwp_array_new_packed.constprop.0>:
    4b20:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4b27:	ff ff 1f 
    4b2a:	53                   	push   %rbx
    4b2b:	48 39 f8             	cmp    %rdi,%rax
    4b2e:	72 1a                	jb     4b4a <fwp_array_new_packed.constprop.0+0x2a>
    4b30:	48 89 fb             	mov    %rdi,%rbx
    4b33:	be 01 00 00 00       	mov    $0x1,%esi
    4b38:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    4b3f:	00 
    4b40:	e8 fb fb ff ff       	call   4740 <fwp_heap_alloc>
    4b45:	48 89 18             	mov    %rbx,(%rax)
    4b48:	5b                   	pop    %rbx
    4b49:	c3                   	ret
    4b4a:	48 8d 3d 94 65 00 00 	lea    0x6594(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    4b51:	e8 aa e6 ff ff       	call   3200 <fwp_trap>
    4b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4b5d:	00 00 00 

0000000000004b60 <fwp_task_dispose>:
    4b60:	53                   	push   %rbx
    4b61:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4b65:	0f 84 9b db ff ff    	je     2706 <fwp_task_dispose.cold>
    4b6b:	48 89 fb             	mov    %rdi,%rbx
    4b6e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4b73:	0f 85 8d db ff ff    	jne    2706 <fwp_task_dispose.cold>
    4b79:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    4b7d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4b84:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    4b8b:	00 
    4b8c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4b90:	48 85 ff             	test   %rdi,%rdi
    4b93:	74 07                	je     4b9c <fwp_task_dispose+0x3c>
    4b95:	48 85 c0             	test   %rax,%rax
    4b98:	74 02                	je     4b9c <fwp_task_dispose+0x3c>
    4b9a:	ff d0                	call   *%rax
    4b9c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4ba3:	e8 68 f5 ff ff       	call   4110 <fwp_mem_free>
    4ba8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    4baf:	00 00 00 00 
    4bb3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4bb7:	74 6f                	je     4c28 <fwp_task_dispose+0xc8>
    4bb9:	48 8b 15 78 af 01 00 	mov    0x1af78(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    4bc0:	48 89 d8             	mov    %rbx,%rax
    4bc3:	48 2b 05 46 af 01 00 	sub    0x1af46(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4bca:	48 c1 e2 10          	shl    $0x10,%rdx
    4bce:	48 39 d0             	cmp    %rdx,%rax
    4bd1:	73 4c                	jae    4c1f <fwp_task_dispose+0xbf>
    4bd3:	48 89 c2             	mov    %rax,%rdx
    4bd6:	48 c1 ea 10          	shr    $0x10,%rdx
    4bda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4bde:	48 8b 15 73 af 01 00 	mov    0x1af73(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    4be5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4be9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4bed:	48 85 c9             	test   %rcx,%rcx
    4bf0:	74 2d                	je     4c1f <fwp_task_dispose+0xbf>
    4bf2:	0f b6 32             	movzbl (%rdx),%esi
    4bf5:	40 80 fe 02          	cmp    $0x2,%sil
    4bf9:	74 3d                	je     4c38 <fwp_task_dispose+0xd8>
    4bfb:	40 80 fe 01          	cmp    $0x1,%sil
    4bff:	75 1e                	jne    4c1f <fwp_task_dispose+0xbf>
    4c01:	8b 72 18             	mov    0x18(%rdx),%esi
    4c04:	0f b7 c0             	movzwl %ax,%eax
    4c07:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4c0a:	48 0f af c6          	imul   %rsi,%rax
    4c0e:	48 c1 e8 20          	shr    $0x20,%rax
    4c12:	48 39 d0             	cmp    %rdx,%rax
    4c15:	73 08                	jae    4c1f <fwp_task_dispose+0xbf>
    4c17:	48 01 c1             	add    %rax,%rcx
    4c1a:	80 39 01             	cmpb   $0x1,(%rcx)
    4c1d:	74 09                	je     4c28 <fwp_task_dispose+0xc8>
    4c1f:	5b                   	pop    %rbx
    4c20:	c3                   	ret
    4c21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c28:	48 89 df             	mov    %rbx,%rdi
    4c2b:	5b                   	pop    %rbx
    4c2c:	e9 df f4 ff ff       	jmp    4110 <fwp_mem_free>
    4c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c38:	66 85 c0             	test   %ax,%ax
    4c3b:	74 dd                	je     4c1a <fwp_task_dispose+0xba>
    4c3d:	5b                   	pop    %rbx
    4c3e:	c3                   	ret
    4c3f:	90                   	nop

0000000000004c40 <fwp_free_zombie>:
    4c40:	48 8b 15 e9 9a 01 00 	mov    0x19ae9(%rip),%rdx        # 1e730 <fwp_zombie>
    4c47:	48 85 d2             	test   %rdx,%rdx
    4c4a:	0f 84 98 00 00 00    	je     4ce8 <fwp_free_zombie+0xa8>
    4c50:	48 3b 15 e9 9a 01 00 	cmp    0x19ae9(%rip),%rdx        # 1e740 <fwp_cur>
    4c57:	0f 84 8b 00 00 00    	je     4ce8 <fwp_free_zombie+0xa8>
    4c5d:	48 83 ec 18          	sub    $0x18,%rsp
    4c61:	48 63 05 9c 94 01 00 	movslq 0x1949c(%rip),%rax        # 1e104 <fwp_stack_pool_n>
    4c68:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4c6c:	83 f8 3f             	cmp    $0x3f,%eax
    4c6f:	7f 7f                	jg     4cf0 <fwp_free_zombie+0xb0>
    4c71:	8d 48 01             	lea    0x1(%rax),%ecx
    4c74:	89 0d 8a 94 01 00    	mov    %ecx,0x1948a(%rip)        # 1e104 <fwp_stack_pool_n>
    4c7a:	48 8d 0d 9f 94 01 00 	lea    0x1949f(%rip),%rcx        # 1e120 <fwp_stack_pool>
    4c81:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4c85:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4c8c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4c90:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4c97:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4c9b:	48 85 c9             	test   %rcx,%rcx
    4c9e:	0f 84 fc 00 00 00    	je     4da0 <fwp_free_zombie+0x160>
    4ca4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4cab:	48 85 c0             	test   %rax,%rax
    4cae:	74 07                	je     4cb7 <fwp_free_zombie+0x77>
    4cb0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4cb7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4cba:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4cbe:	48 c7 05 67 9a 01 00 	movq   $0x0,0x19a67(%rip)        # 1e730 <fwp_zombie>
    4cc5:	00 00 00 00 
    4cc9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4cd0:	85 c0                	test   %eax,%eax
    4cd2:	74 34                	je     4d08 <fwp_free_zombie+0xc8>
    4cd4:	83 f8 01             	cmp    $0x1,%eax
    4cd7:	0f 84 b3 00 00 00    	je     4d90 <fwp_free_zombie+0x150>
    4cdd:	48 83 c4 18          	add    $0x18,%rsp
    4ce1:	c3                   	ret
    4ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ce8:	c3                   	ret
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4cf4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4cf9:	e8 b2 d8 ff ff       	call   25b0 <munmap@plt>
    4cfe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4d03:	eb 80                	jmp    4c85 <fwp_free_zombie+0x45>
    4d05:	0f 1f 00             	nopl   (%rax)
    4d08:	48 8b 0d 29 ae 01 00 	mov    0x1ae29(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    4d0f:	48 89 d0             	mov    %rdx,%rax
    4d12:	48 2b 05 f7 ad 01 00 	sub    0x1adf7(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4d19:	48 c1 e1 10          	shl    $0x10,%rcx
    4d1d:	48 39 c8             	cmp    %rcx,%rax
    4d20:	73 bb                	jae    4cdd <fwp_free_zombie+0x9d>
    4d22:	48 89 c1             	mov    %rax,%rcx
    4d25:	48 c1 e9 10          	shr    $0x10,%rcx
    4d29:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4d2d:	48 8b 0d 24 ae 01 00 	mov    0x1ae24(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    4d34:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4d38:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4d3c:	48 85 c9             	test   %rcx,%rcx
    4d3f:	74 9c                	je     4cdd <fwp_free_zombie+0x9d>
    4d41:	0f b6 3e             	movzbl (%rsi),%edi
    4d44:	40 80 ff 02          	cmp    $0x2,%dil
    4d48:	74 66                	je     4db0 <fwp_free_zombie+0x170>
    4d4a:	40 80 ff 01          	cmp    $0x1,%dil
    4d4e:	75 8d                	jne    4cdd <fwp_free_zombie+0x9d>
    4d50:	8b 7e 18             	mov    0x18(%rsi),%edi
    4d53:	0f b7 c0             	movzwl %ax,%eax
    4d56:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4d59:	48 0f af c7          	imul   %rdi,%rax
    4d5d:	48 c1 e8 20          	shr    $0x20,%rax
    4d61:	48 39 f0             	cmp    %rsi,%rax
    4d64:	0f 83 73 ff ff ff    	jae    4cdd <fwp_free_zombie+0x9d>
    4d6a:	48 01 c1             	add    %rax,%rcx
    4d6d:	0f b6 01             	movzbl (%rcx),%eax
    4d70:	84 c0                	test   %al,%al
    4d72:	0f 84 65 ff ff ff    	je     4cdd <fwp_free_zombie+0x9d>
    4d78:	3c 01                	cmp    $0x1,%al
    4d7a:	74 14                	je     4d90 <fwp_free_zombie+0x150>
    4d7c:	3c ff                	cmp    $0xff,%al
    4d7e:	74 3b                	je     4dbb <fwp_free_zombie+0x17b>
    4d80:	83 e8 01             	sub    $0x1,%eax
    4d83:	88 01                	mov    %al,(%rcx)
    4d85:	e9 53 ff ff ff       	jmp    4cdd <fwp_free_zombie+0x9d>
    4d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d90:	48 89 d7             	mov    %rdx,%rdi
    4d93:	48 83 c4 18          	add    $0x18,%rsp
    4d97:	e9 c4 fd ff ff       	jmp    4b60 <fwp_task_dispose>
    4d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    4da0:	48 89 05 61 99 01 00 	mov    %rax,0x19961(%rip)        # 1e708 <fwp_tasks_active>
    4da7:	e9 ff fe ff ff       	jmp    4cab <fwp_free_zombie+0x6b>
    4dac:	0f 1f 40 00          	nopl   0x0(%rax)
    4db0:	66 85 c0             	test   %ax,%ax
    4db3:	0f 85 24 ff ff ff    	jne    4cdd <fwp_free_zombie+0x9d>
    4db9:	eb b2                	jmp    4d6d <fwp_free_zombie+0x12d>
    4dbb:	48 89 ca             	mov    %rcx,%rdx
    4dbe:	48 8d 35 9b 99 01 00 	lea    0x1999b(%rip),%rsi        # 1e760 <fwp_heap>
    4dc5:	48 c1 ea 11          	shr    $0x11,%rdx
    4dc9:	48 31 ca             	xor    %rcx,%rdx
    4dcc:	48 89 d0             	mov    %rdx,%rax
    4dcf:	48 c1 e8 09          	shr    $0x9,%rax
    4dd3:	48 31 c2             	xor    %rax,%rdx
    4dd6:	0f b6 d2             	movzbl %dl,%edx
    4dd9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4de0:	00 
    4de1:	48 85 c0             	test   %rax,%rax
    4de4:	75 23                	jne    4e09 <fwp_free_zombie+0x1c9>
    4de6:	eb 5c                	jmp    4e44 <fwp_free_zombie+0x204>
    4de8:	66 90                	xchg   %ax,%ax
    4dea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4df1:	00 00 00 00 
    4df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dfc:	00 00 00 00 
    4e00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4e04:	48 85 c0             	test   %rax,%rax
    4e07:	74 3b                	je     4e44 <fwp_free_zombie+0x204>
    4e09:	48 89 c2             	mov    %rax,%rdx
    4e0c:	48 39 08             	cmp    %rcx,(%rax)
    4e0f:	75 ef                	jne    4e00 <fwp_free_zombie+0x1c0>
    4e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4e15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4e19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4e1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4e24:	0f 85 b3 fe ff ff    	jne    4cdd <fwp_free_zombie+0x9d>
    4e2a:	48 89 cf             	mov    %rcx,%rdi
    4e2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e32:	e8 99 f0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4e37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4e3f:	e9 99 fe ff ff       	jmp    4cdd <fwp_free_zombie+0x9d>
    4e44:	48 8d 3d 55 65 00 00 	lea    0x6555(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    4e4b:	e8 b0 e3 ff ff       	call   3200 <fwp_trap>

0000000000004e50 <fwp_block>:
    4e50:	48 83 ec 08          	sub    $0x8,%rsp
    4e54:	48 8b 05 cd 98 01 00 	mov    0x198cd(%rip),%rax        # 1e728 <fwp_ready_head>
    4e5b:	48 85 c0             	test   %rax,%rax
    4e5e:	0f 84 1c 01 00 00    	je     4f80 <fwp_block+0x130>
    4e64:	90                   	nop
    4e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e6c:	00 00 00 00 
    4e70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4e77:	48 89 15 aa 98 01 00 	mov    %rdx,0x198aa(%rip)        # 1e728 <fwp_ready_head>
    4e7e:	48 85 d2             	test   %rdx,%rdx
    4e81:	0f 84 19 01 00 00    	je     4fa0 <fwp_block+0x150>
    4e87:	48 8b 15 b2 98 01 00 	mov    0x198b2(%rip),%rdx        # 1e740 <fwp_cur>
    4e8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4e92:	48 39 c2             	cmp    %rax,%rdx
    4e95:	0f 84 d5 00 00 00    	je     4f70 <fwp_block+0x120>
    4e9b:	48 8b 0d 1e b5 01 00 	mov    0x1b51e(%rip),%rcx        # 203c0 <fwp_state_owners>
    4ea2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4ea6:	48 89 05 93 98 01 00 	mov    %rax,0x19893(%rip)        # 1e740 <fwp_cur>
    4ead:	f3 0f 7e 05 33 b5 01 	movq   0x1b533(%rip),%xmm0        # 203e8 <fwp_foreign_callbacks>
    4eb4:	00 
    4eb5:	0f 16 05 1c b5 01 00 	movhps 0x1b51c(%rip),%xmm0        # 203d8 <fwp_state>
    4ebc:	f3 0f 7e 0d 1c b5 01 	movq   0x1b51c(%rip),%xmm1        # 203e0 <fwp_handlers>
    4ec3:	00 
    4ec4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4ecb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4ed2:	0f 16 0d 17 b5 01 00 	movhps 0x1b517(%rip),%xmm1        # 203f0 <fwp_cleanups>
    4ed9:	f3 0f 7e 05 ef b4 01 	movq   0x1b4ef(%rip),%xmm0        # 203d0 <fwp_state_len>
    4ee0:	00 
    4ee1:	0f 16 05 e0 b4 01 00 	movhps 0x1b4e0(%rip),%xmm0        # 203c8 <fwp_state_cap>
    4ee8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4eef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4ef6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4efa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4f01:	48 89 0d d8 b4 01 00 	mov    %rcx,0x1b4d8(%rip)        # 203e0 <fwp_handlers>
    4f08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4f0f:	48 89 0d da b4 01 00 	mov    %rcx,0x1b4da(%rip)        # 203f0 <fwp_cleanups>
    4f16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4f1d:	48 89 0d c4 b4 01 00 	mov    %rcx,0x1b4c4(%rip)        # 203e8 <fwp_foreign_callbacks>
    4f24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4f2b:	48 89 0d a6 b4 01 00 	mov    %rcx,0x1b4a6(%rip)        # 203d8 <fwp_state>
    4f32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4f39:	48 89 0d 90 b4 01 00 	mov    %rcx,0x1b490(%rip)        # 203d0 <fwp_state_len>
    4f40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4f47:	48 89 0d 7a b4 01 00 	mov    %rcx,0x1b47a(%rip)        # 203c8 <fwp_state_cap>
    4f4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4f55:	48 89 0d 64 b4 01 00 	mov    %rcx,0x1b464(%rip)        # 203c0 <fwp_state_owners>
    4f5c:	e8 0f d5 ff ff       	call   2470 <swapcontext@plt>
    4f61:	f3 0f 1e fa          	endbr64
    4f65:	e8 d6 fc ff ff       	call   4c40 <fwp_free_zombie>
    4f6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f70:	8b 05 8a 91 01 00    	mov    0x1918a(%rip),%eax        # 1e100 <fwp_slice>
    4f76:	85 c0                	test   %eax,%eax
    4f78:	74 36                	je     4fb0 <fwp_block+0x160>
    4f7a:	48 83 c4 08          	add    $0x8,%rsp
    4f7e:	c3                   	ret
    4f7f:	90                   	nop
    4f80:	e8 ab ec ff ff       	call   3c30 <fwp_poll_events>
    4f85:	48 8b 05 9c 97 01 00 	mov    0x1979c(%rip),%rax        # 1e728 <fwp_ready_head>
    4f8c:	48 85 c0             	test   %rax,%rax
    4f8f:	0f 85 db fe ff ff    	jne    4e70 <fwp_block+0x20>
    4f95:	eb e9                	jmp    4f80 <fwp_block+0x130>
    4f97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4f9e:	00 00 
    4fa0:	48 c7 05 75 97 01 00 	movq   $0x0,0x19775(%rip)        # 1e720 <fwp_ready_tail>
    4fa7:	00 00 00 00 
    4fab:	e9 d7 fe ff ff       	jmp    4e87 <fwp_block+0x37>
    4fb0:	48 8d 3d 3e 61 00 00 	lea    0x613e(%rip),%rdi        # b0f5 <_IO_stdin_used+0xf5>
    4fb7:	e8 c4 d3 ff ff       	call   2380 <getenv@plt>
    4fbc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4fc1:	48 85 c0             	test   %rax,%rax
    4fc4:	74 05                	je     4fcb <fwp_block+0x17b>
    4fc6:	80 38 00             	cmpb   $0x0,(%rax)
    4fc9:	75 0b                	jne    4fd6 <fwp_block+0x186>
    4fcb:	89 15 2f 91 01 00    	mov    %edx,0x1912f(%rip)        # 1e100 <fwp_slice>
    4fd1:	48 83 c4 08          	add    $0x8,%rsp
    4fd5:	c3                   	ret
    4fd6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4fdb:	31 f6                	xor    %esi,%esi
    4fdd:	48 89 c7             	mov    %rax,%rdi
    4fe0:	e8 4b d5 ff ff       	call   2530 <strtoll@plt>
    4fe5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4fe9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4ff0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4ff5:	0f 46 d0             	cmovbe %eax,%edx
    4ff8:	eb d1                	jmp    4fcb <fwp_block+0x17b>
    4ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005000 <fwp_drop0>:
    5000:	48 8b 15 31 ab 01 00 	mov    0x1ab31(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    5007:	48 89 f8             	mov    %rdi,%rax
    500a:	48 2b 05 ff aa 01 00 	sub    0x1aaff(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    5011:	48 c1 e2 10          	shl    $0x10,%rdx
    5015:	48 39 d0             	cmp    %rdx,%rax
    5018:	0f 83 c2 00 00 00    	jae    50e0 <fwp_drop0+0xe0>
    501e:	48 83 ec 18          	sub    $0x18,%rsp
    5022:	4c 8d 05 37 97 01 00 	lea    0x19737(%rip),%r8        # 1e760 <fwp_heap>
    5029:	48 89 c2             	mov    %rax,%rdx
    502c:	48 c1 ea 10          	shr    $0x10,%rdx
    5030:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5034:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    503b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    503f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5043:	48 85 d2             	test   %rdx,%rdx
    5046:	74 3c                	je     5084 <fwp_drop0+0x84>
    5048:	0f b6 31             	movzbl (%rcx),%esi
    504b:	40 80 fe 02          	cmp    $0x2,%sil
    504f:	74 3f                	je     5090 <fwp_drop0+0x90>
    5051:	40 80 fe 01          	cmp    $0x1,%sil
    5055:	75 2d                	jne    5084 <fwp_drop0+0x84>
    5057:	8b 71 18             	mov    0x18(%rcx),%esi
    505a:	0f b7 c0             	movzwl %ax,%eax
    505d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5060:	48 0f af c6          	imul   %rsi,%rax
    5064:	48 c1 e8 20          	shr    $0x20,%rax
    5068:	48 39 c8             	cmp    %rcx,%rax
    506b:	73 17                	jae    5084 <fwp_drop0+0x84>
    506d:	48 01 c2             	add    %rax,%rdx
    5070:	0f b6 02             	movzbl (%rdx),%eax
    5073:	84 c0                	test   %al,%al
    5075:	74 0d                	je     5084 <fwp_drop0+0x84>
    5077:	3c 01                	cmp    $0x1,%al
    5079:	74 25                	je     50a0 <fwp_drop0+0xa0>
    507b:	3c ff                	cmp    $0xff,%al
    507d:	74 69                	je     50e8 <fwp_drop0+0xe8>
    507f:	83 e8 01             	sub    $0x1,%eax
    5082:	88 02                	mov    %al,(%rdx)
    5084:	48 83 c4 18          	add    $0x18,%rsp
    5088:	c3                   	ret
    5089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5090:	66 85 c0             	test   %ax,%ax
    5093:	74 db                	je     5070 <fwp_drop0+0x70>
    5095:	48 83 c4 18          	add    $0x18,%rsp
    5099:	c3                   	ret
    509a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50a0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    50a4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50a9:	e8 12 f6 ff ff       	call   46c0 <fwp_rc_free_arr>
    50ae:	4c 8d 05 ab 96 01 00 	lea    0x196ab(%rip),%r8        # 1e760 <fwp_heap>
    50b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    50ba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    50c1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    50c8:	48 c1 e2 10          	shl    $0x10,%rdx
    50cc:	48 39 d0             	cmp    %rdx,%rax
    50cf:	73 b3                	jae    5084 <fwp_drop0+0x84>
    50d1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    50d6:	e9 4e ff ff ff       	jmp    5029 <fwp_drop0+0x29>
    50db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50e0:	c3                   	ret
    50e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50e8:	48 89 d0             	mov    %rdx,%rax
    50eb:	48 c1 e8 11          	shr    $0x11,%rax
    50ef:	48 31 d0             	xor    %rdx,%rax
    50f2:	48 89 c1             	mov    %rax,%rcx
    50f5:	48 c1 e9 09          	shr    $0x9,%rcx
    50f9:	48 31 c8             	xor    %rcx,%rax
    50fc:	0f b6 c8             	movzbl %al,%ecx
    50ff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    5106:	00 
    5107:	48 85 c0             	test   %rax,%rax
    510a:	75 1d                	jne    5129 <fwp_drop0+0x129>
    510c:	eb 56                	jmp    5164 <fwp_drop0+0x164>
    510e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    511c:	00 00 00 00 
    5120:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5124:	48 85 c0             	test   %rax,%rax
    5127:	74 3b                	je     5164 <fwp_drop0+0x164>
    5129:	48 89 c1             	mov    %rax,%rcx
    512c:	48 39 10             	cmp    %rdx,(%rax)
    512f:	75 ef                	jne    5120 <fwp_drop0+0x120>
    5131:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5135:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5139:	48 89 48 08          	mov    %rcx,0x8(%rax)
    513d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5144:	0f 85 3a ff ff ff    	jne    5084 <fwp_drop0+0x84>
    514a:	48 89 d7             	mov    %rdx,%rdi
    514d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5152:	e8 79 ed ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5157:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    515c:	c6 02 fe             	movb   $0xfe,(%rdx)
    515f:	e9 20 ff ff ff       	jmp    5084 <fwp_drop0+0x84>
    5164:	48 8d 3d 35 62 00 00 	lea    0x6235(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    516b:	e8 90 e0 ff ff       	call   3200 <fwp_trap>

0000000000005170 <fwp_drop1>:
    5170:	f3 0f 1e fa          	endbr64
    5174:	48 8b 15 bd a9 01 00 	mov    0x1a9bd(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    517b:	48 89 f8             	mov    %rdi,%rax
    517e:	48 2b 05 8b a9 01 00 	sub    0x1a98b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    5185:	48 c1 e2 10          	shl    $0x10,%rdx
    5189:	48 39 d0             	cmp    %rdx,%rax
    518c:	0f 83 be 00 00 00    	jae    5250 <fwp_drop1+0xe0>
    5192:	48 83 ec 18          	sub    $0x18,%rsp
    5196:	4c 8d 05 c3 95 01 00 	lea    0x195c3(%rip),%r8        # 1e760 <fwp_heap>
    519d:	48 89 c2             	mov    %rax,%rdx
    51a0:	48 c1 ea 10          	shr    $0x10,%rdx
    51a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    51a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    51af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    51b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    51b7:	48 85 d2             	test   %rdx,%rdx
    51ba:	74 3c                	je     51f8 <fwp_drop1+0x88>
    51bc:	0f b6 31             	movzbl (%rcx),%esi
    51bf:	40 80 fe 02          	cmp    $0x2,%sil
    51c3:	74 3b                	je     5200 <fwp_drop1+0x90>
    51c5:	40 80 fe 01          	cmp    $0x1,%sil
    51c9:	75 2d                	jne    51f8 <fwp_drop1+0x88>
    51cb:	8b 71 18             	mov    0x18(%rcx),%esi
    51ce:	0f b7 c0             	movzwl %ax,%eax
    51d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    51d4:	48 0f af c6          	imul   %rsi,%rax
    51d8:	48 c1 e8 20          	shr    $0x20,%rax
    51dc:	48 39 c8             	cmp    %rcx,%rax
    51df:	73 17                	jae    51f8 <fwp_drop1+0x88>
    51e1:	48 01 c2             	add    %rax,%rdx
    51e4:	0f b6 02             	movzbl (%rdx),%eax
    51e7:	84 c0                	test   %al,%al
    51e9:	74 0d                	je     51f8 <fwp_drop1+0x88>
    51eb:	3c 01                	cmp    $0x1,%al
    51ed:	74 21                	je     5210 <fwp_drop1+0xa0>
    51ef:	3c ff                	cmp    $0xff,%al
    51f1:	74 65                	je     5258 <fwp_drop1+0xe8>
    51f3:	83 e8 01             	sub    $0x1,%eax
    51f6:	88 02                	mov    %al,(%rdx)
    51f8:	48 83 c4 18          	add    $0x18,%rsp
    51fc:	c3                   	ret
    51fd:	0f 1f 00             	nopl   (%rax)
    5200:	66 85 c0             	test   %ax,%ax
    5203:	74 df                	je     51e4 <fwp_drop1+0x74>
    5205:	48 83 c4 18          	add    $0x18,%rsp
    5209:	c3                   	ret
    520a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5210:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    5214:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5219:	e8 a2 f4 ff ff       	call   46c0 <fwp_rc_free_arr>
    521e:	4c 8d 05 3b 95 01 00 	lea    0x1953b(%rip),%r8        # 1e760 <fwp_heap>
    5225:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    522a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    5231:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    5238:	48 c1 e2 10          	shl    $0x10,%rdx
    523c:	48 39 d0             	cmp    %rdx,%rax
    523f:	73 b7                	jae    51f8 <fwp_drop1+0x88>
    5241:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    5246:	e9 52 ff ff ff       	jmp    519d <fwp_drop1+0x2d>
    524b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5250:	c3                   	ret
    5251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5258:	48 89 d0             	mov    %rdx,%rax
    525b:	48 c1 e8 11          	shr    $0x11,%rax
    525f:	48 31 d0             	xor    %rdx,%rax
    5262:	48 89 c1             	mov    %rax,%rcx
    5265:	48 c1 e9 09          	shr    $0x9,%rcx
    5269:	48 31 c8             	xor    %rcx,%rax
    526c:	0f b6 c8             	movzbl %al,%ecx
    526f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    5276:	00 
    5277:	48 85 c0             	test   %rax,%rax
    527a:	75 0d                	jne    5289 <fwp_drop1+0x119>
    527c:	eb 46                	jmp    52c4 <fwp_drop1+0x154>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5284:	48 85 c0             	test   %rax,%rax
    5287:	74 3b                	je     52c4 <fwp_drop1+0x154>
    5289:	48 89 c1             	mov    %rax,%rcx
    528c:	48 39 10             	cmp    %rdx,(%rax)
    528f:	75 ef                	jne    5280 <fwp_drop1+0x110>
    5291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5295:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5299:	48 89 48 08          	mov    %rcx,0x8(%rax)
    529d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    52a4:	0f 85 4e ff ff ff    	jne    51f8 <fwp_drop1+0x88>
    52aa:	48 89 d7             	mov    %rdx,%rdi
    52ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    52b2:	e8 19 ec ff ff       	call   3ed0 <fwp_rc_forget_slot>
    52b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    52bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    52bf:	e9 34 ff ff ff       	jmp    51f8 <fwp_drop1+0x88>
    52c4:	48 8d 3d d5 60 00 00 	lea    0x60d5(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    52cb:	e8 30 df ff ff       	call   3200 <fwp_trap>

00000000000052d0 <fwp_write.constprop.0>:
    52d0:	41 57                	push   %r15
    52d2:	41 56                	push   %r14
    52d4:	41 55                	push   %r13
    52d6:	41 54                	push   %r12
    52d8:	55                   	push   %rbp
    52d9:	53                   	push   %rbx
    52da:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    52e1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    52e8:	00 00 
    52ea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    52f1:	00 
    52f2:	49 89 d4             	mov    %rdx,%r12
    52f5:	8b 12                	mov    (%rdx),%edx
    52f7:	83 fa 19             	cmp    $0x19,%edx
    52fa:	77 64                	ja     5360 <fwp_write.constprop.0+0x90>
    52fc:	48 8d 0d 5d 62 00 00 	lea    0x625d(%rip),%rcx        # b560 <_IO_stdin_used+0x560>
    5303:	89 d0                	mov    %edx,%eax
    5305:	48 89 fb             	mov    %rdi,%rbx
    5308:	48 89 f5             	mov    %rsi,%rbp
    530b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    530f:	48 01 c8             	add    %rcx,%rax
    5312:	3e ff e0             	notrack jmp *%rax
    5315:	0f 1f 00             	nopl   (%rax)
    5318:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    531c:	48 8b 06             	mov    (%rsi),%rax
    531f:	48 89 ca             	mov    %rcx,%rdx
    5322:	48 85 c9             	test   %rcx,%rcx
    5325:	0f 88 b5 0c 00 00    	js     5fe0 <fwp_write.constprop.0+0xd10>
    532b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5332:	00 
    5333:	48 89 c6             	mov    %rax,%rsi
    5336:	4c 89 e7             	mov    %r12,%rdi
    5339:	e8 c2 d6 ff ff       	call   2a00 <fwp_fmt_u128>
    533e:	66 90                	xchg   %ax,%ax
    5340:	4c 89 e7             	mov    %r12,%rdi
    5343:	e8 e8 d0 ff ff       	call   2430 <strlen@plt>
    5348:	4c 89 e6             	mov    %r12,%rsi
    534b:	48 89 df             	mov    %rbx,%rdi
    534e:	48 89 c2             	mov    %rax,%rdx
    5351:	e8 5a dc ff ff       	call   2fb0 <buf_put>
    5356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    535d:	00 00 00 
    5360:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5367:	00 
    5368:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    536f:	00 00 
    5371:	0f 85 9e 04 00 00    	jne    5815 <fwp_write.constprop.0+0x545>
    5377:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    537e:	5b                   	pop    %rbx
    537f:	5d                   	pop    %rbp
    5380:	41 5c                	pop    %r12
    5382:	41 5d                	pop    %r13
    5384:	41 5e                	pop    %r14
    5386:	41 5f                	pop    %r15
    5388:	c3                   	ret
    5389:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5390:	49 89 f1             	mov    %rsi,%r9
    5393:	4c 8d 05 83 5d 00 00 	lea    0x5d83(%rip),%r8        # b11d <_IO_stdin_used+0x11d>
    539a:	b9 00 02 00 00       	mov    $0x200,%ecx
    539f:	ba 02 00 00 00       	mov    $0x2,%edx
    53a4:	be 00 02 00 00       	mov    $0x200,%esi
    53a9:	31 c0                	xor    %eax,%eax
    53ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    53b2:	00 
    53b3:	e8 d8 cf ff ff       	call   2390 <__snprintf_chk@plt>
    53b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    53bf:	00 
    53c0:	e8 6b d0 ff ff       	call   2430 <strlen@plt>
    53c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    53cc:	00 
    53cd:	48 89 df             	mov    %rbx,%rdi
    53d0:	48 89 c2             	mov    %rax,%rdx
    53d3:	e8 d8 db ff ff       	call   2fb0 <buf_put>
    53d8:	eb 86                	jmp    5360 <fwp_write.constprop.0+0x90>
    53da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    53e0:	49 89 f1             	mov    %rsi,%r9
    53e3:	4c 8d 05 2e 5d 00 00 	lea    0x5d2e(%rip),%r8        # b118 <_IO_stdin_used+0x118>
    53ea:	eb ae                	jmp    539a <fwp_write.constprop.0+0xca>
    53ec:	0f 1f 40 00          	nopl   0x0(%rax)
    53f0:	83 fa 13             	cmp    $0x13,%edx
    53f3:	48 8d 05 14 5d 00 00 	lea    0x5d14(%rip),%rax        # b10e <_IO_stdin_used+0x10e>
    53fa:	48 8d 35 12 5d 00 00 	lea    0x5d12(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    5401:	ba 04 00 00 00       	mov    $0x4,%edx
    5406:	48 0f 44 f0          	cmove  %rax,%rsi
    540a:	45 31 ed             	xor    %r13d,%r13d
    540d:	e8 9e db ff ff       	call   2fb0 <buf_put>
    5412:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5417:	0f 84 b3 09 00 00    	je     5dd0 <fwp_write.constprop.0+0xb00>
    541d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5422:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5427:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    542c:	48 89 df             	mov    %rbx,%rdi
    542f:	49 0f 44 c5          	cmove  %r13,%rax
    5433:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5438:	e8 93 fe ff ff       	call   52d0 <fwp_write.constprop.0>
    543d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5442:	0f 84 80 0a 00 00    	je     5ec8 <fwp_write.constprop.0+0xbf8>
    5448:	49 83 c5 01          	add    $0x1,%r13
    544c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5450:	0f 83 7a 09 00 00    	jae    5dd0 <fwp_write.constprop.0+0xb00>
    5456:	ba 02 00 00 00       	mov    $0x2,%edx
    545b:	48 8d 35 fb 5c 00 00 	lea    0x5cfb(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5462:	48 89 df             	mov    %rbx,%rdi
    5465:	e8 46 db ff ff       	call   2fb0 <buf_put>
    546a:	eb b1                	jmp    541d <fwp_write.constprop.0+0x14d>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	ba 06 00 00 00       	mov    $0x6,%edx
    5475:	48 8d 35 ba 5c 00 00 	lea    0x5cba(%rip),%rsi        # b136 <_IO_stdin_used+0x136>
    547c:	48 83 c5 10          	add    $0x10,%rbp
    5480:	e8 2b db ff ff       	call   2fb0 <buf_put>
    5485:	48 89 ef             	mov    %rbp,%rdi
    5488:	e8 a3 cf ff ff       	call   2430 <strlen@plt>
    548d:	48 89 ee             	mov    %rbp,%rsi
    5490:	48 89 df             	mov    %rbx,%rdi
    5493:	48 89 c2             	mov    %rax,%rdx
    5496:	e8 15 db ff ff       	call   2fb0 <buf_put>
    549b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    54a0:	ba 01 00 00 00       	mov    $0x1,%edx
    54a5:	48 89 df             	mov    %rbx,%rdi
    54a8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    54ad:	e8 fe da ff ff       	call   2fb0 <buf_put>
    54b2:	e9 a9 fe ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    54b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54be:	00 00 
    54c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    54c7:	00 
    54c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    54cf:	00 00 
    54d1:	0f 85 3e 03 00 00    	jne    5815 <fwp_write.constprop.0+0x545>
    54d7:	ba 0a 00 00 00       	mov    $0xa,%edx
    54dc:	48 8d 35 3f 5c 00 00 	lea    0x5c3f(%rip),%rsi        # b122 <_IO_stdin_used+0x122>
    54e3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    54ea:	48 89 df             	mov    %rbx,%rdi
    54ed:	5b                   	pop    %rbx
    54ee:	5d                   	pop    %rbp
    54ef:	41 5c                	pop    %r12
    54f1:	41 5d                	pop    %r13
    54f3:	41 5e                	pop    %r14
    54f5:	41 5f                	pop    %r15
    54f7:	e9 b4 da ff ff       	jmp    2fb0 <buf_put>
    54fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5500:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5505:	4d 85 ed             	test   %r13,%r13
    5508:	0f 84 c2 0b 00 00    	je     60d0 <fwp_write.constprop.0+0xe00>
    550e:	48 8d 35 55 5c 00 00 	lea    0x5c55(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    5515:	4c 89 ef             	mov    %r13,%rdi
    5518:	e8 f3 cf ff ff       	call   2510 <strcmp@plt>
    551d:	41 89 c1             	mov    %eax,%r9d
    5520:	85 c0                	test   %eax,%eax
    5522:	0f 84 2c 0c 00 00    	je     6154 <fwp_write.constprop.0+0xe84>
    5528:	4c 89 ef             	mov    %r13,%rdi
    552b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5530:	e8 fb ce ff ff       	call   2430 <strlen@plt>
    5535:	4c 89 ee             	mov    %r13,%rsi
    5538:	48 89 df             	mov    %rbx,%rdi
    553b:	48 89 c2             	mov    %rax,%rdx
    553e:	e8 6d da ff ff       	call   2fb0 <buf_put>
    5543:	ba 01 00 00 00       	mov    $0x1,%edx
    5548:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    554d:	48 89 df             	mov    %rbx,%rdi
    5550:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5555:	e8 56 da ff ff       	call   2fb0 <buf_put>
    555a:	ba 01 00 00 00       	mov    $0x1,%edx
    555f:	4c 89 fe             	mov    %r15,%rsi
    5562:	48 89 df             	mov    %rbx,%rdi
    5565:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    556a:	e8 41 da ff ff       	call   2fb0 <buf_put>
    556f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5574:	45 31 f6             	xor    %r14d,%r14d
    5577:	85 c0                	test   %eax,%eax
    5579:	0f 8e 91 0a 00 00    	jle    6010 <fwp_write.constprop.0+0xd40>
    557f:	45 31 ed             	xor    %r13d,%r13d
    5582:	4d 85 ed             	test   %r13,%r13
    5585:	0f 85 d5 08 00 00    	jne    5e60 <fwp_write.constprop.0+0xb90>
    558b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5592:	00 
    5593:	45 85 f6             	test   %r14d,%r14d
    5596:	0f 84 74 08 00 00    	je     5e10 <fwp_write.constprop.0+0xb40>
    559c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    55a1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    55a6:	48 89 df             	mov    %rbx,%rdi
    55a9:	49 83 c5 01          	add    $0x1,%r13
    55ad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    55b1:	e8 1a fd ff ff       	call   52d0 <fwp_write.constprop.0>
    55b6:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    55bb:	7f c5                	jg     5582 <fwp_write.constprop.0+0x2b2>
    55bd:	45 85 f6             	test   %r14d,%r14d
    55c0:	0f 84 4a 0a 00 00    	je     6010 <fwp_write.constprop.0+0xd40>
    55c6:	b8 29 00 00 00       	mov    $0x29,%eax
    55cb:	ba 01 00 00 00       	mov    $0x1,%edx
    55d0:	4c 89 fe             	mov    %r15,%rsi
    55d3:	48 89 df             	mov    %rbx,%rdi
    55d6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    55da:	e8 d1 d9 ff ff       	call   2fb0 <buf_put>
    55df:	e9 7c fd ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    55e4:	0f 1f 40 00          	nopl   0x0(%rax)
    55e8:	ba 01 00 00 00       	mov    $0x1,%edx
    55ed:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    55f2:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    55f7:	e8 b4 d9 ff ff       	call   2fb0 <buf_put>
    55fc:	48 85 ed             	test   %rbp,%rbp
    55ff:	0f 84 8b 07 00 00    	je     5d90 <fwp_write.constprop.0+0xac0>
    5605:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5609:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    560e:	48 89 df             	mov    %rbx,%rdi
    5611:	e8 ba fc ff ff       	call   52d0 <fwp_write.constprop.0>
    5616:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    561a:	48 85 ed             	test   %rbp,%rbp
    561d:	0f 84 6d 07 00 00    	je     5d90 <fwp_write.constprop.0+0xac0>
    5623:	ba 02 00 00 00       	mov    $0x2,%edx
    5628:	48 8d 35 2e 5b 00 00 	lea    0x5b2e(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    562f:	48 89 df             	mov    %rbx,%rdi
    5632:	e8 79 d9 ff ff       	call   2fb0 <buf_put>
    5637:	eb cc                	jmp    5605 <fwp_write.constprop.0+0x335>
    5639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5640:	4c 8b 2e             	mov    (%rsi),%r13
    5643:	ba 01 00 00 00       	mov    $0x1,%edx
    5648:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    564d:	48 83 c5 08          	add    $0x8,%rbp
    5651:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5656:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    565b:	e8 50 d9 ff ff       	call   2fb0 <buf_put>
    5660:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5665:	4d 85 ed             	test   %r13,%r13
    5668:	75 43                	jne    56ad <fwp_write.constprop.0+0x3dd>
    566a:	e9 81 07 00 00       	jmp    5df0 <fwp_write.constprop.0+0xb20>
    566f:	90                   	nop
    5670:	41 80 f9 09          	cmp    $0x9,%r9b
    5674:	0f 84 f6 06 00 00    	je     5d70 <fwp_write.constprop.0+0xaa0>
    567a:	41 80 f9 0a          	cmp    $0xa,%r9b
    567e:	0f 85 bc 06 00 00    	jne    5d40 <fwp_write.constprop.0+0xa70>
    5684:	ba 02 00 00 00       	mov    $0x2,%edx
    5689:	48 8d 35 b3 5a 00 00 	lea    0x5ab3(%rip),%rsi        # b143 <_IO_stdin_used+0x143>
    5690:	48 89 df             	mov    %rbx,%rdi
    5693:	e8 18 d9 ff ff       	call   2fb0 <buf_put>
    5698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    569f:	00 
    56a0:	48 83 c5 01          	add    $0x1,%rbp
    56a4:	49 39 ec             	cmp    %rbp,%r12
    56a7:	0f 84 43 07 00 00    	je     5df0 <fwp_write.constprop.0+0xb20>
    56ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    56b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    56b6:	0f 84 64 06 00 00    	je     5d20 <fwp_write.constprop.0+0xa50>
    56bc:	7e b2                	jle    5670 <fwp_write.constprop.0+0x3a0>
    56be:	41 80 f9 22          	cmp    $0x22,%r9b
    56c2:	0f 84 38 06 00 00    	je     5d00 <fwp_write.constprop.0+0xa30>
    56c8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    56cc:	0f 85 6e 06 00 00    	jne    5d40 <fwp_write.constprop.0+0xa70>
    56d2:	ba 02 00 00 00       	mov    $0x2,%edx
    56d7:	48 8d 35 62 5a 00 00 	lea    0x5a62(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    56de:	48 89 df             	mov    %rbx,%rdi
    56e1:	e8 ca d8 ff ff       	call   2fb0 <buf_put>
    56e6:	eb b8                	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    56e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56ef:	00 
    56f0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    56f5:	ba 01 00 00 00       	mov    $0x1,%edx
    56fa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    56ff:	48 89 ee             	mov    %rbp,%rsi
    5702:	e8 a9 d8 ff ff       	call   2fb0 <buf_put>
    5707:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    570c:	4c 89 e7             	mov    %r12,%rdi
    570f:	e8 1c cd ff ff       	call   2430 <strlen@plt>
    5714:	4c 89 e6             	mov    %r12,%rsi
    5717:	48 89 df             	mov    %rbx,%rdi
    571a:	48 89 c2             	mov    %rax,%rdx
    571d:	e8 8e d8 ff ff       	call   2fb0 <buf_put>
    5722:	ba 01 00 00 00       	mov    $0x1,%edx
    5727:	48 89 ee             	mov    %rbp,%rsi
    572a:	48 89 df             	mov    %rbx,%rdi
    572d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5732:	e8 79 d8 ff ff       	call   2fb0 <buf_put>
    5737:	e9 24 fc ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    573c:	0f 1f 40 00          	nopl   0x0(%rax)
    5740:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5745:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5749:	0f 8a de 0a 00 00    	jp     622d <fwp_write.constprop.0+0xf5d>
    574f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5753:	66 0f 54 05 f5 5e 00 	andpd  0x5ef5(%rip),%xmm0        # b650 <msg.3+0x80>
    575a:	00 
    575b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5760:	66 0f 2e 05 08 5f 00 	ucomisd 0x5f08(%rip),%xmm0        # b670 <msg.3+0xa0>
    5767:	00 
    5768:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    576f:	00 
    5770:	0f 87 02 09 00 00    	ja     6078 <fwp_write.constprop.0+0xda8>
    5776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    577d:	00 00 00 
    5780:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5784:	89 ee                	mov    %ebp,%esi
    5786:	4c 89 e7             	mov    %r12,%rdi
    5789:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    578e:	e8 3d db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5793:	31 f6                	xor    %esi,%esi
    5795:	4c 89 e7             	mov    %r12,%rdi
    5798:	e8 53 cc ff ff       	call   23f0 <strtod@plt>
    579d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    57a2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    57a6:	7a 06                	jp     57ae <fwp_write.constprop.0+0x4de>
    57a8:	0f 84 09 03 00 00    	je     5ab7 <fwp_write.constprop.0+0x7e7>
    57ae:	83 c5 01             	add    $0x1,%ebp
    57b1:	83 fd 12             	cmp    $0x12,%ebp
    57b4:	75 ca                	jne    5780 <fwp_write.constprop.0+0x4b0>
    57b6:	be 11 00 00 00       	mov    $0x11,%esi
    57bb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    57bf:	4c 89 e7             	mov    %r12,%rdi
    57c2:	e8 09 db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    57c7:	e9 eb 02 00 00       	jmp    5ab7 <fwp_write.constprop.0+0x7e7>
    57cc:	0f 1f 40 00          	nopl   0x0(%rax)
    57d0:	48 83 fe 01          	cmp    $0x1,%rsi
    57d4:	0f 84 86 08 00 00    	je     6060 <fwp_write.constprop.0+0xd90>
    57da:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    57de:	b8 02 00 00 00       	mov    $0x2,%eax
    57e3:	ba 01 00 00 00       	mov    $0x1,%edx
    57e8:	48 0f 44 d0          	cmove  %rax,%rdx
    57ec:	48 8d 35 19 59 00 00 	lea    0x5919(%rip),%rsi        # b10c <_IO_stdin_used+0x10c>
    57f3:	48 8d 05 0f 59 00 00 	lea    0x590f(%rip),%rax        # b109 <_IO_stdin_used+0x109>
    57fa:	48 0f 44 f0          	cmove  %rax,%rsi
    57fe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5805:	00 
    5806:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    580d:	00 00 
    580f:	0f 84 ce fc ff ff    	je     54e3 <fwp_write.constprop.0+0x213>
    5815:	e8 26 cc ff ff       	call   2440 <__stack_chk_fail@plt>
    581a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5820:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5825:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    582a:	e8 c1 d6 ff ff       	call   2ef0 <buf_grow>
    582f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5833:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5839:	4c 03 0b             	add    (%rbx),%r9
    583c:	66 45 89 11          	mov    %r10w,(%r9)
    5840:	49 83 c1 01          	add    $0x1,%r9
    5844:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    584b:	55 55 55 
    584e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5855:	aa aa aa 
    5858:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    585c:	45 85 e4             	test   %r12d,%r12d
    585f:	7f 4c                	jg     58ad <fwp_write.constprop.0+0x5dd>
    5861:	e9 4a 05 00 00       	jmp    5db0 <fwp_write.constprop.0+0xae0>
    5866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    586d:	00 00 00 
    5870:	be 01 00 00 00       	mov    $0x1,%esi
    5875:	b8 2d 00 00 00       	mov    $0x2d,%eax
    587a:	88 07                	mov    %al,(%rdi)
    587c:	48 89 e8             	mov    %rbp,%rax
    587f:	49 f7 e8             	imul   %r8
    5882:	48 89 e8             	mov    %rbp,%rax
    5885:	48 c1 f8 3f          	sar    $0x3f,%rax
    5889:	48 29 c2             	sub    %rax,%rdx
    588c:	48 85 c9             	test   %rcx,%rcx
    588f:	0f 95 c0             	setne  %al
    5892:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5896:	48 83 ef 01          	sub    $0x1,%rdi
    589a:	48 21 c5             	and    %rax,%rbp
    589d:	48 29 ea             	sub    %rbp,%rdx
    58a0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    58a4:	49 39 f9             	cmp    %rdi,%r9
    58a7:	0f 84 03 05 00 00    	je     5db0 <fwp_write.constprop.0+0xae0>
    58ad:	48 89 e8             	mov    %rbp,%rax
    58b0:	49 f7 e8             	imul   %r8
    58b3:	48 89 e8             	mov    %rbp,%rax
    58b6:	48 c1 f8 3f          	sar    $0x3f,%rax
    58ba:	48 89 d1             	mov    %rdx,%rcx
    58bd:	48 29 c1             	sub    %rax,%rcx
    58c0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    58c4:	48 89 e9             	mov    %rbp,%rcx
    58c7:	48 29 c1             	sub    %rax,%rcx
    58ca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    58ce:	49 f7 e2             	mul    %r10
    58d1:	b8 30 00 00 00       	mov    $0x30,%eax
    58d6:	48 89 d6             	mov    %rdx,%rsi
    58d9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    58dd:	48 d1 ee             	shr    $1,%rsi
    58e0:	48 01 f2             	add    %rsi,%rdx
    58e3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    58e7:	48 29 d6             	sub    %rdx,%rsi
    58ea:	74 8e                	je     587a <fwp_write.constprop.0+0x5aa>
    58ec:	48 83 fe 01          	cmp    $0x1,%rsi
    58f0:	0f 85 7a ff ff ff    	jne    5870 <fwp_write.constprop.0+0x5a0>
    58f6:	31 f6                	xor    %esi,%esi
    58f8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    58fd:	e9 78 ff ff ff       	jmp    587a <fwp_write.constprop.0+0x5aa>
    5902:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5908:	ba 06 00 00 00       	mov    $0x6,%edx
    590d:	48 8d 35 4c 58 00 00 	lea    0x584c(%rip),%rsi        # b160 <_IO_stdin_used+0x160>
    5914:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    591a:	e8 91 d6 ff ff       	call   2fb0 <buf_put>
    591f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5926:	ff ff 7f 
    5929:	48 23 55 00          	and    0x0(%rbp),%rdx
    592d:	0f 84 4e 03 00 00    	je     5c81 <fwp_write.constprop.0+0x9b1>
    5933:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5938:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    593c:	48 85 d2             	test   %rdx,%rdx
    593f:	0f 84 a4 00 00 00    	je     59e9 <fwp_write.constprop.0+0x719>
    5945:	8b 0a                	mov    (%rdx),%ecx
    5947:	83 f9 1c             	cmp    $0x1c,%ecx
    594a:	0f 84 d0 06 00 00    	je     6020 <fwp_write.constprop.0+0xd50>
    5950:	83 f9 1b             	cmp    $0x1b,%ecx
    5953:	0f 87 90 00 00 00    	ja     59e9 <fwp_write.constprop.0+0x719>
    5959:	be 01 00 00 00       	mov    $0x1,%esi
    595e:	48 d3 e6             	shl    %cl,%rsi
    5961:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5967:	0f 85 13 06 00 00    	jne    5f80 <fwp_write.constprop.0+0xcb0>
    596d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5973:	0f 85 d7 05 00 00    	jne    5f50 <fwp_write.constprop.0+0xc80>
    5979:	83 e6 21             	and    $0x21,%esi
    597c:	74 6b                	je     59e9 <fwp_write.constprop.0+0x719>
    597e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5983:	48 85 ff             	test   %rdi,%rdi
    5986:	79 07                	jns    598f <fwp_write.constprop.0+0x6bf>
    5988:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    598c:	4c 01 ee             	add    %r13,%rsi
    598f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5993:	85 c9                	test   %ecx,%ecx
    5995:	40 0f b6 f7          	movzbl %dil,%esi
    5999:	48 0f 44 f7          	cmove  %rdi,%rsi
    599d:	0f 1f 00             	nopl   (%rax)
    59a0:	48 89 df             	mov    %rbx,%rdi
    59a3:	49 83 c5 01          	add    $0x1,%r13
    59a7:	e8 24 f9 ff ff       	call   52d0 <fwp_write.constprop.0>
    59ac:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    59b3:	ff ff 7f 
    59b6:	48 23 55 00          	and    0x0(%rbp),%rdx
    59ba:	49 39 d5             	cmp    %rdx,%r13
    59bd:	0f 83 be 02 00 00    	jae    5c81 <fwp_write.constprop.0+0x9b1>
    59c3:	ba 02 00 00 00       	mov    $0x2,%edx
    59c8:	48 89 df             	mov    %rbx,%rdi
    59cb:	48 8d 35 8b 57 00 00 	lea    0x578b(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    59d2:	e8 d9 d5 ff ff       	call   2fb0 <buf_put>
    59d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    59dc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    59e0:	48 85 d2             	test   %rdx,%rdx
    59e3:	0f 85 5c ff ff ff    	jne    5945 <fwp_write.constprop.0+0x675>
    59e9:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    59ee:	48 85 ff             	test   %rdi,%rdi
    59f1:	0f 88 51 06 00 00    	js     6048 <fwp_write.constprop.0+0xd78>
    59f7:	48 8b 31             	mov    (%rcx),%rsi
    59fa:	eb a4                	jmp    59a0 <fwp_write.constprop.0+0x6d0>
    59fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5a00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5a07:	00 
    5a08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5a0f:	00 00 
    5a11:	0f 85 fe fd ff ff    	jne    5815 <fwp_write.constprop.0+0x545>
    5a17:	ba 08 00 00 00       	mov    $0x8,%edx
    5a1c:	48 8d 35 0a 57 00 00 	lea    0x570a(%rip),%rsi        # b12d <_IO_stdin_used+0x12d>
    5a23:	e9 bb fa ff ff       	jmp    54e3 <fwp_write.constprop.0+0x213>
    5a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5a2f:	00 
    5a30:	66 0f 6e ce          	movd   %esi,%xmm1
    5a34:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5a37:	0f 8a f0 07 00 00    	jp     622d <fwp_write.constprop.0+0xf5d>
    5a3d:	0f 28 c1             	movaps %xmm1,%xmm0
    5a40:	0f 54 05 f9 5b 00 00 	andps  0x5bf9(%rip),%xmm0        # b640 <msg.3+0x70>
    5a47:	0f 2e 05 b6 55 00 00 	ucomiss 0x55b6(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    5a4e:	0f 87 4c 06 00 00    	ja     60a0 <fwp_write.constprop.0+0xdd0>
    5a54:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5a58:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    5a5e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5a65:	00 
    5a66:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    5a6a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    5a6f:	90                   	nop
    5a70:	44 89 ee             	mov    %r13d,%esi
    5a73:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5a78:	4c 89 e7             	mov    %r12,%rdi
    5a7b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5a80:	e8 4b d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5a85:	31 f6                	xor    %esi,%esi
    5a87:	4c 89 e7             	mov    %r12,%rdi
    5a8a:	e8 01 ca ff ff       	call   2490 <strtof@plt>
    5a8f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5a94:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5a97:	7a 02                	jp     5a9b <fwp_write.constprop.0+0x7cb>
    5a99:	74 1c                	je     5ab7 <fwp_write.constprop.0+0x7e7>
    5a9b:	41 83 c5 01          	add    $0x1,%r13d
    5a9f:	41 83 fd 0a          	cmp    $0xa,%r13d
    5aa3:	75 cb                	jne    5a70 <fwp_write.constprop.0+0x7a0>
    5aa5:	be 09 00 00 00       	mov    $0x9,%esi
    5aaa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5aaf:	4c 89 e7             	mov    %r12,%rdi
    5ab2:	e8 19 d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5ab7:	4c 89 e7             	mov    %r12,%rdi
    5aba:	e8 b1 d5 ff ff       	call   3070 <fwp_finish_float>
    5abf:	e9 7c f8 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    5ac4:	0f 1f 40 00          	nopl   0x0(%rax)
    5ac8:	89 f0                	mov    %esi,%eax
    5aca:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5ad1:	76 02                	jbe    5ad5 <fwp_write.constprop.0+0x805>
    5ad3:	8b 06                	mov    (%rsi),%eax
    5ad5:	41 89 c6             	mov    %eax,%r14d
    5ad8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5add:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5ae2:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5ae6:	4c 89 ef             	mov    %r13,%rdi
    5ae9:	e8 42 c9 ff ff       	call   2430 <strlen@plt>
    5aee:	4c 89 ee             	mov    %r13,%rsi
    5af1:	48 89 df             	mov    %rbx,%rdi
    5af4:	48 89 c2             	mov    %rax,%rdx
    5af7:	e8 b4 d4 ff ff       	call   2fb0 <buf_put>
    5afc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5b01:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5b05:	85 f6                	test   %esi,%esi
    5b07:	0f 8e 53 f8 ff ff    	jle    5360 <fwp_write.constprop.0+0x90>
    5b0d:	45 31 ed             	xor    %r13d,%r13d
    5b10:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5b15:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    5b1a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b1f:	4c 89 fe             	mov    %r15,%rsi
    5b22:	48 89 df             	mov    %rbx,%rdi
    5b25:	ba 01 00 00 00       	mov    $0x1,%edx
    5b2a:	48 89 04 24          	mov    %rax,(%rsp)
    5b2e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5b33:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5b37:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    5b3b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5b40:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5b45:	e8 66 d4 ff ff       	call   2fb0 <buf_put>
    5b4a:	41 8b 06             	mov    (%r14),%eax
    5b4d:	83 f8 0e             	cmp    $0xe,%eax
    5b50:	0f 84 5a 03 00 00    	je     5eb0 <fwp_write.constprop.0+0xbe0>
    5b56:	83 f8 10             	cmp    $0x10,%eax
    5b59:	0f 84 21 03 00 00    	je     5e80 <fwp_write.constprop.0+0xbb0>
    5b5f:	83 f8 0a             	cmp    $0xa,%eax
    5b62:	0f 84 68 04 00 00    	je     5fd0 <fwp_write.constprop.0+0xd00>
    5b68:	0f 8f 32 01 00 00    	jg     5ca0 <fwp_write.constprop.0+0x9d0>
    5b6e:	83 f8 03             	cmp    $0x3,%eax
    5b71:	0f 8f 39 04 00 00    	jg     5fb0 <fwp_write.constprop.0+0xce0>
    5b77:	85 c0                	test   %eax,%eax
    5b79:	78 10                	js     5b8b <fwp_write.constprop.0+0x8bb>
    5b7b:	48 8b 04 24          	mov    (%rsp),%rax
    5b7f:	48 c1 e8 3f          	shr    $0x3f,%rax
    5b83:	85 c0                	test   %eax,%eax
    5b85:	0f 85 32 01 00 00    	jne    5cbd <fwp_write.constprop.0+0x9ed>
    5b8b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5b90:	48 8b 34 24          	mov    (%rsp),%rsi
    5b94:	48 89 df             	mov    %rbx,%rdi
    5b97:	e8 34 f7 ff ff       	call   52d0 <fwp_write.constprop.0>
    5b9c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5ba1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5ba6:	49 83 c5 01          	add    $0x1,%r13
    5baa:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    5bae:	0f 8f 61 ff ff ff    	jg     5b15 <fwp_write.constprop.0+0x845>
    5bb4:	e9 a7 f7 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5bc0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5bc4:	48 8b 36             	mov    (%rsi),%rsi
    5bc7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    5bce:	00 
    5bcf:	48 89 ef             	mov    %rbp,%rdi
    5bd2:	e8 29 ce ff ff       	call   2a00 <fwp_fmt_u128>
    5bd7:	48 89 ef             	mov    %rbp,%rdi
    5bda:	e8 51 c8 ff ff       	call   2430 <strlen@plt>
    5bdf:	48 89 ee             	mov    %rbp,%rsi
    5be2:	48 89 df             	mov    %rbx,%rdi
    5be5:	48 89 c2             	mov    %rax,%rdx
    5be8:	e8 c3 d3 ff ff       	call   2fb0 <buf_put>
    5bed:	e9 6e f7 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5bf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bf8:	ba 06 00 00 00       	mov    $0x6,%edx
    5bfd:	48 8d 35 4f 55 00 00 	lea    0x554f(%rip),%rsi        # b153 <_IO_stdin_used+0x153>
    5c04:	45 31 ed             	xor    %r13d,%r13d
    5c07:	e8 a4 d3 ff ff       	call   2fb0 <buf_put>
    5c0c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5c11:	75 19                	jne    5c2c <fwp_write.constprop.0+0x95c>
    5c13:	eb 6c                	jmp    5c81 <fwp_write.constprop.0+0x9b1>
    5c15:	0f 1f 00             	nopl   (%rax)
    5c18:	ba 02 00 00 00       	mov    $0x2,%edx
    5c1d:	48 8d 35 39 55 00 00 	lea    0x5539(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5c24:	48 89 df             	mov    %rbx,%rdi
    5c27:	e8 84 d3 ff ff       	call   2fb0 <buf_put>
    5c2c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5c32:	b9 00 02 00 00       	mov    $0x200,%ecx
    5c37:	31 c0                	xor    %eax,%eax
    5c39:	49 83 c5 01          	add    $0x1,%r13
    5c3d:	4c 8d 05 16 55 00 00 	lea    0x5516(%rip),%r8        # b15a <_IO_stdin_used+0x15a>
    5c44:	ba 02 00 00 00       	mov    $0x2,%edx
    5c49:	be 00 02 00 00       	mov    $0x200,%esi
    5c4e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c55:	00 
    5c56:	e8 35 c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c5b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c62:	00 
    5c63:	e8 c8 c7 ff ff       	call   2430 <strlen@plt>
    5c68:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c6f:	00 
    5c70:	48 89 df             	mov    %rbx,%rdi
    5c73:	48 89 c2             	mov    %rax,%rdx
    5c76:	e8 35 d3 ff ff       	call   2fb0 <buf_put>
    5c7b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5c7f:	72 97                	jb     5c18 <fwp_write.constprop.0+0x948>
    5c81:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5c86:	ba 01 00 00 00       	mov    $0x1,%edx
    5c8b:	48 89 df             	mov    %rbx,%rdi
    5c8e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5c93:	e8 18 d3 ff ff       	call   2fb0 <buf_put>
    5c98:	e9 c3 f6 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5c9d:	0f 1f 00             	nopl   (%rax)
    5ca0:	83 f8 0b             	cmp    $0xb,%eax
    5ca3:	0f 85 e2 fe ff ff    	jne    5b8b <fwp_write.constprop.0+0x8bb>
    5ca9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5cae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5cb2:	83 e0 01             	and    $0x1,%eax
    5cb5:	85 c0                	test   %eax,%eax
    5cb7:	0f 84 ce fe ff ff    	je     5b8b <fwp_write.constprop.0+0x8bb>
    5cbd:	4c 89 fe             	mov    %r15,%rsi
    5cc0:	48 89 df             	mov    %rbx,%rdi
    5cc3:	ba 01 00 00 00       	mov    $0x1,%edx
    5cc8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5ccd:	e8 de d2 ff ff       	call   2fb0 <buf_put>
    5cd2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5cd7:	48 8b 34 24          	mov    (%rsp),%rsi
    5cdb:	48 89 df             	mov    %rbx,%rdi
    5cde:	e8 ed f5 ff ff       	call   52d0 <fwp_write.constprop.0>
    5ce3:	ba 01 00 00 00       	mov    $0x1,%edx
    5ce8:	4c 89 fe             	mov    %r15,%rsi
    5ceb:	48 89 df             	mov    %rbx,%rdi
    5cee:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5cf3:	e8 b8 d2 ff ff       	call   2fb0 <buf_put>
    5cf8:	e9 9f fe ff ff       	jmp    5b9c <fwp_write.constprop.0+0x8cc>
    5cfd:	0f 1f 00             	nopl   (%rax)
    5d00:	ba 02 00 00 00       	mov    $0x2,%edx
    5d05:	48 8d 35 31 54 00 00 	lea    0x5431(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5d0c:	48 89 df             	mov    %rbx,%rdi
    5d0f:	e8 9c d2 ff ff       	call   2fb0 <buf_put>
    5d14:	e9 87 f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    5d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d20:	ba 02 00 00 00       	mov    $0x2,%edx
    5d25:	48 8d 35 1d 54 00 00 	lea    0x541d(%rip),%rsi        # b149 <_IO_stdin_used+0x149>
    5d2c:	48 89 df             	mov    %rbx,%rdi
    5d2f:	e8 7c d2 ff ff       	call   2fb0 <buf_put>
    5d34:	e9 67 f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    5d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5d44:	0f 86 b6 01 00 00    	jbe    5f00 <fwp_write.constprop.0+0xc30>
    5d4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5d4e:	0f 84 ac 01 00 00    	je     5f00 <fwp_write.constprop.0+0xc30>
    5d54:	ba 01 00 00 00       	mov    $0x1,%edx
    5d59:	4c 89 fe             	mov    %r15,%rsi
    5d5c:	48 89 df             	mov    %rbx,%rdi
    5d5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5d64:	e8 47 d2 ff ff       	call   2fb0 <buf_put>
    5d69:	e9 32 f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    5d6e:	66 90                	xchg   %ax,%ax
    5d70:	ba 02 00 00 00       	mov    $0x2,%edx
    5d75:	48 8d 35 ca 53 00 00 	lea    0x53ca(%rip),%rsi        # b146 <_IO_stdin_used+0x146>
    5d7c:	48 89 df             	mov    %rbx,%rdi
    5d7f:	e8 2c d2 ff ff       	call   2fb0 <buf_put>
    5d84:	e9 17 f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    5d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d90:	ba 01 00 00 00       	mov    $0x1,%edx
    5d95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5d9a:	48 89 df             	mov    %rbx,%rdi
    5d9d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5da2:	e8 09 d2 ff ff       	call   2fb0 <buf_put>
    5da7:	e9 b4 f5 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5dac:	0f 1f 40 00          	nopl   0x0(%rax)
    5db0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5db4:	48 8b 13             	mov    (%rbx),%rdx
    5db7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5dbc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5dc0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5dc4:	e9 97 f5 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5dc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5dd0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5dd5:	ba 01 00 00 00       	mov    $0x1,%edx
    5dda:	48 89 df             	mov    %rbx,%rdi
    5ddd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5de2:	e8 c9 d1 ff ff       	call   2fb0 <buf_put>
    5de7:	e9 74 f5 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5dec:	0f 1f 40 00          	nopl   0x0(%rax)
    5df0:	ba 01 00 00 00       	mov    $0x1,%edx
    5df5:	4c 89 fe             	mov    %r15,%rsi
    5df8:	48 89 df             	mov    %rbx,%rdi
    5dfb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5e00:	e8 ab d1 ff ff       	call   2fb0 <buf_put>
    5e05:	e9 56 f5 ff ff       	jmp    5360 <fwp_write.constprop.0+0x90>
    5e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e10:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5e15:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e1a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5e1e:	48 89 f7             	mov    %rsi,%rdi
    5e21:	48 89 34 24          	mov    %rsi,(%rsp)
    5e25:	e8 06 c6 ff ff       	call   2430 <strlen@plt>
    5e2a:	48 8b 34 24          	mov    (%rsp),%rsi
    5e2e:	48 89 df             	mov    %rbx,%rdi
    5e31:	48 89 c2             	mov    %rax,%rdx
    5e34:	e8 77 d1 ff ff       	call   2fb0 <buf_put>
    5e39:	ba 03 00 00 00       	mov    $0x3,%edx
    5e3e:	48 8d 35 3b 53 00 00 	lea    0x533b(%rip),%rsi        # b180 <_IO_stdin_used+0x180>
    5e45:	48 89 df             	mov    %rbx,%rdi
    5e48:	e8 63 d1 ff ff       	call   2fb0 <buf_put>
    5e4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e52:	e9 45 f7 ff ff       	jmp    559c <fwp_write.constprop.0+0x2cc>
    5e57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e5e:	00 00 
    5e60:	ba 02 00 00 00       	mov    $0x2,%edx
    5e65:	48 8d 35 f1 52 00 00 	lea    0x52f1(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5e6c:	48 89 df             	mov    %rbx,%rdi
    5e6f:	e8 3c d1 ff ff       	call   2fb0 <buf_put>
    5e74:	e9 12 f7 ff ff       	jmp    558b <fwp_write.constprop.0+0x2bb>
    5e79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5e85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5e89:	48 85 ff             	test   %rdi,%rdi
    5e8c:	0f 84 f9 fc ff ff    	je     5b8b <fwp_write.constprop.0+0x8bb>
    5e92:	48 8d 35 d1 52 00 00 	lea    0x52d1(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    5e99:	e8 72 c6 ff ff       	call   2510 <strcmp@plt>
    5e9e:	85 c0                	test   %eax,%eax
    5ea0:	0f 95 c0             	setne  %al
    5ea3:	0f b6 c0             	movzbl %al,%eax
    5ea6:	e9 d8 fc ff ff       	jmp    5b83 <fwp_write.constprop.0+0x8b3>
    5eab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5eb0:	31 c0                	xor    %eax,%eax
    5eb2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5eb9:	00 
    5eba:	0f 97 c0             	seta   %al
    5ebd:	e9 c1 fc ff ff       	jmp    5b83 <fwp_write.constprop.0+0x8b3>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	48 89 df             	mov    %rbx,%rdi
    5ecb:	ba 02 00 00 00       	mov    $0x2,%edx
    5ed0:	48 8d 35 90 52 00 00 	lea    0x5290(%rip),%rsi        # b167 <_IO_stdin_used+0x167>
    5ed7:	e8 d4 d0 ff ff       	call   2fb0 <buf_put>
    5edc:	4c 89 e8             	mov    %r13,%rax
    5edf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5ee4:	48 89 df             	mov    %rbx,%rdi
    5ee7:	48 c1 e0 04          	shl    $0x4,%rax
    5eeb:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5ef0:	e8 db f3 ff ff       	call   52d0 <fwp_write.constprop.0>
    5ef5:	e9 4e f5 ff ff       	jmp    5448 <fwp_write.constprop.0+0x178>
    5efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f00:	4c 8d 05 45 52 00 00 	lea    0x5245(%rip),%r8        # b14c <_IO_stdin_used+0x14c>
    5f07:	b9 10 00 00 00       	mov    $0x10,%ecx
    5f0c:	31 c0                	xor    %eax,%eax
    5f0e:	ba 02 00 00 00       	mov    $0x2,%edx
    5f13:	be 10 00 00 00       	mov    $0x10,%esi
    5f18:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f1f:	00 
    5f20:	e8 6b c4 ff ff       	call   2390 <__snprintf_chk@plt>
    5f25:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f2c:	00 
    5f2d:	e8 fe c4 ff ff       	call   2430 <strlen@plt>
    5f32:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5f39:	00 
    5f3a:	48 89 df             	mov    %rbx,%rdi
    5f3d:	48 89 c2             	mov    %rax,%rdx
    5f40:	e8 6b d0 ff ff       	call   2fb0 <buf_put>
    5f45:	e9 56 f7 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x3d0>
    5f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f50:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5f55:	48 85 ff             	test   %rdi,%rdi
    5f58:	79 0c                	jns    5f66 <fwp_write.constprop.0+0xc96>
    5f5a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5f61:	00 
    5f62:	48 03 75 10          	add    0x10(%rbp),%rsi
    5f66:	48 63 3e             	movslq (%rsi),%rdi
    5f69:	83 f9 02             	cmp    $0x2,%ecx
    5f6c:	89 fe                	mov    %edi,%esi
    5f6e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5f72:	e9 29 fa ff ff       	jmp    59a0 <fwp_write.constprop.0+0x6d0>
    5f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f7e:	00 00 
    5f80:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5f85:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5f8a:	48 85 ff             	test   %rdi,%rdi
    5f8d:	0f 88 6f 01 00 00    	js     6102 <fwp_write.constprop.0+0xe32>
    5f93:	49 0f bf 38          	movswq (%r8),%rdi
    5f97:	83 f9 01             	cmp    $0x1,%ecx
    5f9a:	0f b7 f7             	movzwl %di,%esi
    5f9d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5fa1:	e9 fa f9 ff ff       	jmp    59a0 <fwp_write.constprop.0+0x6d0>
    5fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5fad:	00 00 00 
    5fb0:	83 f8 04             	cmp    $0x4,%eax
    5fb3:	0f 85 d2 fb ff ff    	jne    5b8b <fwp_write.constprop.0+0x8bb>
    5fb9:	48 8b 04 24          	mov    (%rsp),%rax
    5fbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    5fc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5fc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5fca:	e9 e6 fc ff ff       	jmp    5cb5 <fwp_write.constprop.0+0x9e5>
    5fcf:	90                   	nop
    5fd0:	8b 0c 24             	mov    (%rsp),%ecx
    5fd3:	31 c0                	xor    %eax,%eax
    5fd5:	85 c9                	test   %ecx,%ecx
    5fd7:	0f 98 c0             	sets   %al
    5fda:	e9 d6 fc ff ff       	jmp    5cb5 <fwp_write.constprop.0+0x9e5>
    5fdf:	90                   	nop
    5fe0:	48 f7 d8             	neg    %rax
    5fe3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5fea:	00 
    5feb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5ff2:	2d 
    5ff3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ffa:	00 
    5ffb:	48 83 d2 00          	adc    $0x0,%rdx
    5fff:	48 89 c6             	mov    %rax,%rsi
    6002:	48 f7 da             	neg    %rdx
    6005:	e8 f6 c9 ff ff       	call   2a00 <fwp_fmt_u128>
    600a:	e9 31 f3 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    600f:	90                   	nop
    6010:	b8 7d 00 00 00       	mov    $0x7d,%eax
    6015:	e9 b1 f5 ff ff       	jmp    55cb <fwp_write.constprop.0+0x2fb>
    601a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6020:	4c 89 e9             	mov    %r13,%rcx
    6023:	48 c1 e1 04          	shl    $0x4,%rcx
    6027:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    602c:	48 85 ff             	test   %rdi,%rdi
    602f:	0f 89 6b f9 ff ff    	jns    59a0 <fwp_write.constprop.0+0x6d0>
    6035:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6039:	48 89 ce             	mov    %rcx,%rsi
    603c:	e9 5f f9 ff ff       	jmp    59a0 <fwp_write.constprop.0+0x6d0>
    6041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6048:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    604f:	00 
    6050:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6054:	e9 9e f9 ff ff       	jmp    59f7 <fwp_write.constprop.0+0x727>
    6059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6060:	ba 02 00 00 00       	mov    $0x2,%edx
    6065:	48 8d 35 9a 50 00 00 	lea    0x509a(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    606c:	e9 8d f7 ff ff       	jmp    57fe <fwp_write.constprop.0+0x52e>
    6071:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6078:	66 0f ef c0          	pxor   %xmm0,%xmm0
    607c:	48 8d 35 7f 50 00 00 	lea    0x507f(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    6083:	48 8d 05 77 50 00 00 	lea    0x5077(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    608a:	4c 89 e7             	mov    %r12,%rdi
    608d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    6091:	48 0f 46 f0          	cmovbe %rax,%rsi
    6095:	e8 36 c3 ff ff       	call   23d0 <strcpy@plt>
    609a:	e9 a1 f2 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    609f:	90                   	nop
    60a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60a4:	48 8d 35 57 50 00 00 	lea    0x5057(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    60ab:	48 8d 05 4f 50 00 00 	lea    0x504f(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    60b2:	0f 2f c8             	comiss %xmm0,%xmm1
    60b5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    60bc:	00 
    60bd:	4c 89 e7             	mov    %r12,%rdi
    60c0:	48 0f 46 f0          	cmovbe %rax,%rsi
    60c4:	e8 07 c3 ff ff       	call   23d0 <strcpy@plt>
    60c9:	e9 72 f2 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    60ce:	66 90                	xchg   %ax,%ax
    60d0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    60d5:	45 85 c0             	test   %r8d,%r8d
    60d8:	75 34                	jne    610e <fwp_write.constprop.0+0xe3e>
    60da:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    60e1:	00 
    60e2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60e9:	00 00 
    60eb:	0f 85 24 f7 ff ff    	jne    5815 <fwp_write.constprop.0+0x545>
    60f1:	ba 02 00 00 00       	mov    $0x2,%edx
    60f6:	48 8d 35 80 50 00 00 	lea    0x5080(%rip),%rsi        # b17d <_IO_stdin_used+0x17d>
    60fd:	e9 e1 f3 ff ff       	jmp    54e3 <fwp_write.constprop.0+0x213>
    6102:	48 03 75 10          	add    0x10(%rbp),%rsi
    6106:	49 89 f0             	mov    %rsi,%r8
    6109:	e9 85 fe ff ff       	jmp    5f93 <fwp_write.constprop.0+0xcc3>
    610e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    6113:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6118:	85 ff                	test   %edi,%edi
    611a:	0f 84 3a f4 ff ff    	je     555a <fwp_write.constprop.0+0x28a>
    6120:	ba 01 00 00 00       	mov    $0x1,%edx
    6125:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    612a:	48 89 df             	mov    %rbx,%rdi
    612d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6132:	e8 79 ce ff ff       	call   2fb0 <buf_put>
    6137:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    613c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6141:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6147:	85 d2                	test   %edx,%edx
    6149:	0f 8f 30 f4 ff ff    	jg     557f <fwp_write.constprop.0+0x2af>
    614f:	e9 72 f4 ff ff       	jmp    55c6 <fwp_write.constprop.0+0x2f6>
    6154:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6158:	49 89 c5             	mov    %rax,%r13
    615b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6160:	49 89 c4             	mov    %rax,%r12
    6163:	49 c1 fd 3f          	sar    $0x3f,%r13
    6167:	4c 09 e8             	or     %r13,%rax
    616a:	0f 84 a7 00 00 00    	je     6217 <fwp_write.constprop.0+0xf47>
    6170:	48 8d 2d c9 79 00 00 	lea    0x79c9(%rip),%rbp        # db40 <units.0>
    6177:	4d 89 e7             	mov    %r12,%r15
    617a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    617e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6183:	4c 89 ff             	mov    %r15,%rdi
    6186:	4c 89 ee             	mov    %r13,%rsi
    6189:	44 89 0c 24          	mov    %r9d,(%rsp)
    618d:	48 99                	cqto
    618f:	48 89 d1             	mov    %rdx,%rcx
    6192:	48 89 c2             	mov    %rax,%rdx
    6195:	e8 d6 4b 00 00       	call   ad70 <__divmodti4>
    619a:	44 8b 0c 24          	mov    (%rsp),%r9d
    619e:	48 89 c1             	mov    %rax,%rcx
    61a1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    61a6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    61ab:	0f 84 94 00 00 00    	je     6245 <fwp_write.constprop.0+0xf75>
    61b1:	41 83 c1 01          	add    $0x1,%r9d
    61b5:	48 83 c5 10          	add    $0x10,%rbp
    61b9:	41 83 f9 05          	cmp    $0x5,%r9d
    61bd:	75 bb                	jne    617a <fwp_write.constprop.0+0xeaa>
    61bf:	4d 85 ed             	test   %r13,%r13
    61c2:	79 53                	jns    6217 <fwp_write.constprop.0+0xf47>
    61c4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    61c9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    61ce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    61d3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61d8:	48 99                	cqto
    61da:	48 f7 d8             	neg    %rax
    61dd:	48 83 d2 00          	adc    $0x0,%rdx
    61e1:	48 89 c6             	mov    %rax,%rsi
    61e4:	48 f7 da             	neg    %rdx
    61e7:	e8 14 c8 ff ff       	call   2a00 <fwp_fmt_u128>
    61ec:	49 89 e8             	mov    %rbp,%r8
    61ef:	ba 00 02 00 00       	mov    $0x200,%edx
    61f4:	be 02 00 00 00       	mov    $0x2,%esi
    61f9:	31 c0                	xor    %eax,%eax
    61fb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6202:	00 
    6203:	48 8d 0d 6e 4f 00 00 	lea    0x4f6e(%rip),%rcx        # b178 <_IO_stdin_used+0x178>
    620a:	4c 89 e7             	mov    %r12,%rdi
    620d:	e8 8e c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    6212:	e9 29 f1 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    6217:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    621c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6221:	31 d2                	xor    %edx,%edx
    6223:	48 89 ef             	mov    %rbp,%rdi
    6226:	e8 d5 c7 ff ff       	call   2a00 <fwp_fmt_u128>
    622b:	eb bf                	jmp    61ec <fwp_write.constprop.0+0xf1c>
    622d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6234:	4e 61 4e 00 
    6238:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    623f:	00 
    6240:	e9 fb f0 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    6245:	44 89 0c 24          	mov    %r9d,(%rsp)
    6249:	48 89 c8             	mov    %rcx,%rax
    624c:	48 85 d2             	test   %rdx,%rdx
    624f:	78 51                	js     62a2 <fwp_write.constprop.0+0xfd2>
    6251:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6256:	48 89 c6             	mov    %rax,%rsi
    6259:	48 89 ef             	mov    %rbp,%rdi
    625c:	e8 9f c7 ff ff       	call   2a00 <fwp_fmt_u128>
    6261:	44 8b 0c 24          	mov    (%rsp),%r9d
    6265:	49 63 c1             	movslq %r9d,%rax
    6268:	49 89 e8             	mov    %rbp,%r8
    626b:	ba 00 02 00 00       	mov    $0x200,%edx
    6270:	be 02 00 00 00       	mov    $0x2,%esi
    6275:	48 c1 e0 04          	shl    $0x4,%rax
    6279:	48 8d 0d c0 78 00 00 	lea    0x78c0(%rip),%rcx        # db40 <units.0>
    6280:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6287:	00 
    6288:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    628c:	4c 89 e7             	mov    %r12,%rdi
    628f:	48 8d 0d dd 4e 00 00 	lea    0x4edd(%rip),%rcx        # b173 <_IO_stdin_used+0x173>
    6296:	31 c0                	xor    %eax,%eax
    6298:	e8 03 c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    629d:	e9 9e f0 ff ff       	jmp    5340 <fwp_write.constprop.0+0x70>
    62a2:	48 f7 d8             	neg    %rax
    62a5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    62aa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    62af:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    62b4:	48 83 d2 00          	adc    $0x0,%rdx
    62b8:	48 89 c6             	mov    %rax,%rsi
    62bb:	48 f7 da             	neg    %rdx
    62be:	e8 3d c7 ff ff       	call   2a00 <fwp_fmt_u128>
    62c3:	44 8b 0c 24          	mov    (%rsp),%r9d
    62c7:	eb 9c                	jmp    6265 <fwp_write.constprop.0+0xf95>
    62c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000062d0 <fwp_hof0.constprop.0>:
    62d0:	41 57                	push   %r15
    62d2:	41 56                	push   %r14
    62d4:	41 55                	push   %r13
    62d6:	41 54                	push   %r12
    62d8:	55                   	push   %rbp
    62d9:	53                   	push   %rbx
    62da:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    62e1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    62e8:	00 00 
    62ea:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    62f1:	00 
    62f2:	31 c0                	xor    %eax,%eax
    62f4:	48 85 f6             	test   %rsi,%rsi
    62f7:	0f 84 2a 0e 00 00    	je     7127 <fwp_hof0.constprop.0+0xe57>
    62fd:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
    6302:	48 89 fb             	mov    %rdi,%rbx
    6305:	48 8d 2d 54 84 01 00 	lea    0x18454(%rip),%rbp        # 1e760 <fwp_heap>
    630c:	0f 1f 40 00          	nopl   0x0(%rax)
    6310:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6317:	48 89 d8             	mov    %rbx,%rax
    631a:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6321:	48 c1 e2 10          	shl    $0x10,%rdx
    6325:	48 39 d0             	cmp    %rdx,%rax
    6328:	73 73                	jae    639d <fwp_hof0.constprop.0+0xcd>
    632a:	48 89 c2             	mov    %rax,%rdx
    632d:	48 c1 ea 10          	shr    $0x10,%rdx
    6331:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6335:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    633c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6340:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    6344:	4d 85 e4             	test   %r12,%r12
    6347:	74 54                	je     639d <fwp_hof0.constprop.0+0xcd>
    6349:	0f b6 0a             	movzbl (%rdx),%ecx
    634c:	80 f9 02             	cmp    $0x2,%cl
    634f:	0f 84 83 11 00 00    	je     74d8 <fwp_hof0.constprop.0+0x1208>
    6355:	80 f9 01             	cmp    $0x1,%cl
    6358:	75 43                	jne    639d <fwp_hof0.constprop.0+0xcd>
    635a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    635d:	0f b7 c0             	movzwl %ax,%eax
    6360:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6363:	48 0f af c1          	imul   %rcx,%rax
    6367:	48 c1 e8 20          	shr    $0x20,%rax
    636b:	48 39 d0             	cmp    %rdx,%rax
    636e:	73 2d                	jae    639d <fwp_hof0.constprop.0+0xcd>
    6370:	49 01 c4             	add    %rax,%r12
    6373:	41 0f b6 04 24       	movzbl (%r12),%eax
    6378:	84 c0                	test   %al,%al
    637a:	74 21                	je     639d <fwp_hof0.constprop.0+0xcd>
    637c:	8b 0d 9e a0 01 00    	mov    0x1a09e(%rip),%ecx        # 20420 <iteration_active>
    6382:	85 c9                	test   %ecx,%ecx
    6384:	74 08                	je     638e <fwp_hof0.constprop.0+0xbe>
    6386:	48 83 05 7a a0 01 00 	addq   $0x1,0x1a07a(%rip)        # 20408 <iteration_retains>
    638d:	01 
    638e:	3c fd                	cmp    $0xfd,%al
    6390:	0f 87 ea 13 00 00    	ja     7780 <fwp_hof0.constprop.0+0x14b0>
    6396:	83 c0 01             	add    $0x1,%eax
    6399:	41 88 04 24          	mov    %al,(%r12)
    639d:	48 85 db             	test   %rbx,%rbx
    63a0:	0f 84 44 11 00 00    	je     74ea <fwp_hof0.constprop.0+0x121a>
    63a6:	48 89 d8             	mov    %rbx,%rax
    63a9:	31 ff                	xor    %edi,%edi
    63ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    63b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    63b4:	48 83 c7 01          	add    $0x1,%rdi
    63b8:	48 85 c0             	test   %rax,%rax
    63bb:	75 f3                	jne    63b0 <fwp_hof0.constprop.0+0xe0>
    63bd:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    63c4:	ff ff 1f 
    63c7:	48 39 f8             	cmp    %rdi,%rax
    63ca:	0f 82 78 14 00 00    	jb     7848 <fwp_hof0.constprop.0+0x1578>
    63d0:	e8 4b e7 ff ff       	call   4b20 <fwp_array_new_packed.constprop.0>
    63d5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    63dc:	49 89 c6             	mov    %rax,%r14
    63df:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    63e6:	48 c1 e2 10          	shl    $0x10,%rdx
    63ea:	48 39 d0             	cmp    %rdx,%rax
    63ed:	73 62                	jae    6451 <fwp_hof0.constprop.0+0x181>
    63ef:	48 89 c2             	mov    %rax,%rdx
    63f2:	48 c1 ea 10          	shr    $0x10,%rdx
    63f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    63fa:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    6401:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6405:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    6409:	4d 85 e4             	test   %r12,%r12
    640c:	74 43                	je     6451 <fwp_hof0.constprop.0+0x181>
    640e:	0f b6 0a             	movzbl (%rdx),%ecx
    6411:	80 f9 02             	cmp    $0x2,%cl
    6414:	0f 84 96 10 00 00    	je     74b0 <fwp_hof0.constprop.0+0x11e0>
    641a:	80 f9 01             	cmp    $0x1,%cl
    641d:	75 29                	jne    6448 <fwp_hof0.constprop.0+0x178>
    641f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6422:	0f b7 c0             	movzwl %ax,%eax
    6425:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6428:	48 0f af c1          	imul   %rcx,%rax
    642c:	48 c1 e8 20          	shr    $0x20,%rax
    6430:	48 39 d0             	cmp    %rdx,%rax
    6433:	73 13                	jae    6448 <fwp_hof0.constprop.0+0x178>
    6435:	49 01 c4             	add    %rax,%r12
    6438:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    643d:	0f 84 81 10 00 00    	je     74c4 <fwp_hof0.constprop.0+0x11f4>
    6443:	41 c6 04 24 01       	movb   $0x1,(%r12)
    6448:	48 85 db             	test   %rbx,%rbx
    644b:	0f 84 0f 10 00 00    	je     7460 <fwp_hof0.constprop.0+0x1190>
    6451:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    6455:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6459:	49 89 d9             	mov    %rbx,%r9
    645c:	49 89 d8             	mov    %rbx,%r8
    645f:	48 89 da             	mov    %rbx,%rdx
    6462:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6468:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    646f:	48 89 d0             	mov    %rdx,%rax
    6472:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6479:	48 c1 e6 10          	shl    $0x10,%rsi
    647d:	48 39 f0             	cmp    %rsi,%rax
    6480:	73 6c                	jae    64ee <fwp_hof0.constprop.0+0x21e>
    6482:	48 89 c6             	mov    %rax,%rsi
    6485:	48 c1 ee 10          	shr    $0x10,%rsi
    6489:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    648d:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    6494:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6498:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    649c:	48 85 ff             	test   %rdi,%rdi
    649f:	74 4d                	je     64ee <fwp_hof0.constprop.0+0x21e>
    64a1:	44 0f b6 16          	movzbl (%rsi),%r10d
    64a5:	41 80 fa 02          	cmp    $0x2,%r10b
    64a9:	0f 84 f9 09 00 00    	je     6ea8 <fwp_hof0.constprop.0+0xbd8>
    64af:	41 80 fa 01          	cmp    $0x1,%r10b
    64b3:	75 39                	jne    64ee <fwp_hof0.constprop.0+0x21e>
    64b5:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    64b9:	0f b7 c0             	movzwl %ax,%eax
    64bc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    64bf:	49 0f af c2          	imul   %r10,%rax
    64c3:	48 c1 e8 20          	shr    $0x20,%rax
    64c7:	48 39 f0             	cmp    %rsi,%rax
    64ca:	73 22                	jae    64ee <fwp_hof0.constprop.0+0x21e>
    64cc:	48 01 c7             	add    %rax,%rdi
    64cf:	80 3f 01             	cmpb   $0x1,(%rdi)
    64d2:	75 1a                	jne    64ee <fwp_hof0.constprop.0+0x21e>
    64d4:	e9 17 09 00 00       	jmp    6df0 <fwp_hof0.constprop.0+0xb20>
    64d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64e0:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    64e5:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    64ea:	49 83 c5 01          	add    $0x1,%r13
    64ee:	49 83 3e 00          	cmpq   $0x0,(%r14)
    64f2:	0f 88 44 13 00 00    	js     783c <fwp_hof0.constprop.0+0x156c>
    64f8:	4b 89 0c ee          	mov    %rcx,(%r14,%r13,8)
    64fc:	4d 85 e4             	test   %r12,%r12
    64ff:	75 df                	jne    64e0 <fwp_hof0.constprop.0+0x210>
    6501:	4c 89 c7             	mov    %r8,%rdi
    6504:	4d 89 f4             	mov    %r14,%r12
    6507:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    650d:	e8 ee ea ff ff       	call   5000 <fwp_drop0>
    6512:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
    6517:	31 c0                	xor    %eax,%eax
    6519:	48 85 c0             	test   %rax,%rax
    651c:	0f 85 e9 c1 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    6522:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    6529:	ff ff 7f 
    652c:	49 23 04 24          	and    (%r12),%rax
    6530:	49 89 c0             	mov    %rax,%r8
    6533:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    653a:	ff ff 1f 
    653d:	4c 39 c0             	cmp    %r8,%rax
    6540:	0f 82 02 13 00 00    	jb     7848 <fwp_hof0.constprop.0+0x1578>
    6546:	4c 89 c7             	mov    %r8,%rdi
    6549:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    654e:	e8 cd e5 ff ff       	call   4b20 <fwp_array_new_packed.constprop.0>
    6553:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    655a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    655f:	49 89 c5             	mov    %rax,%r13
    6562:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6569:	48 c1 e2 10          	shl    $0x10,%rdx
    656d:	48 39 d0             	cmp    %rdx,%rax
    6570:	73 55                	jae    65c7 <fwp_hof0.constprop.0+0x2f7>
    6572:	48 89 c2             	mov    %rax,%rdx
    6575:	48 c1 ea 10          	shr    $0x10,%rdx
    6579:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    657d:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    6584:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6588:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    658c:	48 85 db             	test   %rbx,%rbx
    658f:	74 36                	je     65c7 <fwp_hof0.constprop.0+0x2f7>
    6591:	0f b6 0a             	movzbl (%rdx),%ecx
    6594:	80 f9 02             	cmp    $0x2,%cl
    6597:	0f 84 2b 0d 00 00    	je     72c8 <fwp_hof0.constprop.0+0xff8>
    659d:	80 f9 01             	cmp    $0x1,%cl
    65a0:	75 25                	jne    65c7 <fwp_hof0.constprop.0+0x2f7>
    65a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    65a5:	0f b7 c0             	movzwl %ax,%eax
    65a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65ab:	48 0f af c1          	imul   %rcx,%rax
    65af:	48 c1 e8 20          	shr    $0x20,%rax
    65b3:	48 39 d0             	cmp    %rdx,%rax
    65b6:	73 0f                	jae    65c7 <fwp_hof0.constprop.0+0x2f7>
    65b8:	48 01 c3             	add    %rax,%rbx
    65bb:	80 3b ff             	cmpb   $0xff,(%rbx)
    65be:	0f 84 16 0d 00 00    	je     72da <fwp_hof0.constprop.0+0x100a>
    65c4:	c6 03 01             	movb   $0x1,(%rbx)
    65c7:	31 db                	xor    %ebx,%ebx
    65c9:	4d 85 c0             	test   %r8,%r8
    65cc:	0f 84 d3 05 00 00    	je     6ba5 <fwp_hof0.constprop.0+0x8d5>
    65d2:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
    65d7:	41 bf 08 00 00 00    	mov    $0x8,%r15d
    65dd:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    65e2:	e9 0f 04 00 00       	jmp    69f6 <fwp_hof0.constprop.0+0x726>
    65e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    65ee:	00 00 
    65f0:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    65f5:	48 85 d2             	test   %rdx,%rdx
    65f8:	0f 88 9a 08 00 00    	js     6e98 <fwp_hof0.constprop.0+0xbc8>
    65fe:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
    6605:	00 00 
    6607:	48 8b 3c d9          	mov    (%rcx,%rbx,8),%rdi
    660b:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    6610:	48 85 db             	test   %rbx,%rbx
    6613:	74 73                	je     6688 <fwp_hof0.constprop.0+0x3b8>
    6615:	f2 42 0f 10 54 39 f0 	movsd  -0x10(%rcx,%r15,1),%xmm2
    661c:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6622:	66 0f ef e4          	pxor   %xmm4,%xmm4
    6626:	66 0f 28 c2          	movapd %xmm2,%xmm0
    662a:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    662e:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6632:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6636:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
    663a:	66 0f 28 d8          	movapd %xmm0,%xmm3
    663e:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
    6642:	f2 0f 10 05 2e 50 00 	movsd  0x502e(%rip),%xmm0        # b678 <msg.3+0xa8>
    6649:	00 
    664a:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    664e:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6652:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6656:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    665a:	f2 0f 59 05 1e 50 00 	mulsd  0x501e(%rip),%xmm0        # b680 <msg.3+0xb0>
    6661:	00 
    6662:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6666:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    666a:	f2 0f 10 0d 06 50 00 	movsd  0x5006(%rip),%xmm1        # b678 <msg.3+0xa8>
    6671:	00 
    6672:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    6676:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    667a:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    667e:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6682:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6688:	48 83 c3 01          	add    $0x1,%rbx
    668c:	48 39 d8             	cmp    %rbx,%rax
    668f:	0f 84 b3 03 00 00    	je     6a48 <fwp_hof0.constprop.0+0x778>
    6695:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    669c:	00 f0 3f 
    669f:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    66a6:	00 
    66a7:	31 ff                	xor    %edi,%edi
    66a9:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    66b0:	00 
    66b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    66b6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    66bd:	00 
    66be:	e8 6d e2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    66c3:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    66ca:	49 89 c6             	mov    %rax,%r14
    66cd:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    66d4:	48 c1 e2 10          	shl    $0x10,%rdx
    66d8:	48 39 d0             	cmp    %rdx,%rax
    66db:	73 57                	jae    6734 <fwp_hof0.constprop.0+0x464>
    66dd:	48 89 c2             	mov    %rax,%rdx
    66e0:	48 c1 ea 10          	shr    $0x10,%rdx
    66e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66e8:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    66ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66f7:	48 85 d2             	test   %rdx,%rdx
    66fa:	74 38                	je     6734 <fwp_hof0.constprop.0+0x464>
    66fc:	0f b6 31             	movzbl (%rcx),%esi
    66ff:	40 80 fe 02          	cmp    $0x2,%sil
    6703:	0f 84 2f 04 00 00    	je     6b38 <fwp_hof0.constprop.0+0x868>
    6709:	40 80 fe 01          	cmp    $0x1,%sil
    670d:	75 25                	jne    6734 <fwp_hof0.constprop.0+0x464>
    670f:	8b 71 18             	mov    0x18(%rcx),%esi
    6712:	0f b7 c0             	movzwl %ax,%eax
    6715:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6718:	48 0f af c6          	imul   %rsi,%rax
    671c:	48 c1 e8 20          	shr    $0x20,%rax
    6720:	48 39 c8             	cmp    %rcx,%rax
    6723:	73 0f                	jae    6734 <fwp_hof0.constprop.0+0x464>
    6725:	48 01 c2             	add    %rax,%rdx
    6728:	80 3a ff             	cmpb   $0xff,(%rdx)
    672b:	0f 84 1f 04 00 00    	je     6b50 <fwp_hof0.constprop.0+0x880>
    6731:	c6 02 01             	movb   $0x1,(%rdx)
    6734:	49 8b 04 24          	mov    (%r12),%rax
    6738:	48 89 c2             	mov    %rax,%rdx
    673b:	48 0f ba f2 3f       	btr    $0x3f,%rdx
    6740:	48 39 d3             	cmp    %rdx,%rbx
    6743:	0f 83 c2 02 00 00    	jae    6a0b <fwp_hof0.constprop.0+0x73b>
    6749:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
    674e:	48 85 c0             	test   %rax,%rax
    6751:	0f 88 99 0a 00 00    	js     71f0 <fwp_hof0.constprop.0+0xf20>
    6757:	4a 8b 04 3a          	mov    (%rdx,%r15,1),%rax
    675b:	31 ff                	xor    %edi,%edi
    675d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    6764:	00 
    6765:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
    676c:	00 00 00 00 00 
    6771:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    6778:	00 
    6779:	e8 b2 e1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    677e:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    6785:	48 89 c2             	mov    %rax,%rdx
    6788:	48 89 c6             	mov    %rax,%rsi
    678b:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6792:	48 29 fa             	sub    %rdi,%rdx
    6795:	48 c1 e0 10          	shl    $0x10,%rax
    6799:	48 39 c2             	cmp    %rax,%rdx
    679c:	0f 83 7e 02 00 00    	jae    6a20 <fwp_hof0.constprop.0+0x750>
    67a2:	48 89 d1             	mov    %rdx,%rcx
    67a5:	48 c1 e9 10          	shr    $0x10,%rcx
    67a9:	4c 8d 0c 89          	lea    (%rcx,%rcx,4),%r9
    67ad:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    67b4:	4e 8d 14 c9          	lea    (%rcx,%r9,8),%r10
    67b8:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    67bc:	4d 85 c9             	test   %r9,%r9
    67bf:	0f 84 54 03 00 00    	je     6b19 <fwp_hof0.constprop.0+0x849>
    67c5:	41 0f b6 0a          	movzbl (%r10),%ecx
    67c9:	80 f9 02             	cmp    $0x2,%cl
    67cc:	0f 84 3e 03 00 00    	je     6b10 <fwp_hof0.constprop.0+0x840>
    67d2:	80 f9 01             	cmp    $0x1,%cl
    67d5:	0f 85 3e 03 00 00    	jne    6b19 <fwp_hof0.constprop.0+0x849>
    67db:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    67df:	0f b7 ca             	movzwl %dx,%ecx
    67e2:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    67e6:	49 0f af cb          	imul   %r11,%rcx
    67ea:	48 c1 e9 20          	shr    $0x20,%rcx
    67ee:	4c 39 d1             	cmp    %r10,%rcx
    67f1:	0f 83 22 03 00 00    	jae    6b19 <fwp_hof0.constprop.0+0x849>
    67f7:	49 01 c9             	add    %rcx,%r9
    67fa:	41 80 39 ff          	cmpb   $0xff,(%r9)
    67fe:	0f 84 fc 09 00 00    	je     7200 <fwp_hof0.constprop.0+0xf30>
    6804:	41 c6 01 01          	movb   $0x1,(%r9)
    6808:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    680f:	48 89 f2             	mov    %rsi,%rdx
    6812:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6819:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    681d:	48 29 fa             	sub    %rdi,%rdx
    6820:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    6826:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    682b:	48 c1 e0 10          	shl    $0x10,%rax
    682f:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6834:	48 39 c2             	cmp    %rax,%rdx
    6837:	0f 83 f7 01 00 00    	jae    6a34 <fwp_hof0.constprop.0+0x764>
    683d:	49 89 d1             	mov    %rdx,%r9
    6840:	49 c1 e9 10          	shr    $0x10,%r9
    6844:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
    6848:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    684f:	4f 8d 14 d1          	lea    (%r9,%r10,8),%r10
    6853:	4d 8b 4a 20          	mov    0x20(%r10),%r9
    6857:	4d 85 c9             	test   %r9,%r9
    685a:	0f 84 d4 01 00 00    	je     6a34 <fwp_hof0.constprop.0+0x764>
    6860:	45 0f b6 1a          	movzbl (%r10),%r11d
    6864:	41 80 fb 02          	cmp    $0x2,%r11b
    6868:	0f 84 12 03 00 00    	je     6b80 <fwp_hof0.constprop.0+0x8b0>
    686e:	41 80 fb 01          	cmp    $0x1,%r11b
    6872:	0f 85 bc 01 00 00    	jne    6a34 <fwp_hof0.constprop.0+0x764>
    6878:	45 8b 5a 18          	mov    0x18(%r10),%r11d
    687c:	0f b7 d2             	movzwl %dx,%edx
    687f:	45 8b 52 1c          	mov    0x1c(%r10),%r10d
    6883:	49 0f af d3          	imul   %r11,%rdx
    6887:	48 c1 ea 20          	shr    $0x20,%rdx
    688b:	4c 39 d2             	cmp    %r10,%rdx
    688e:	0f 83 a0 01 00 00    	jae    6a34 <fwp_hof0.constprop.0+0x764>
    6894:	49 01 d1             	add    %rdx,%r9
    6897:	41 0f b6 11          	movzbl (%r9),%edx
    689b:	84 d2                	test   %dl,%dl
    689d:	0f 84 91 01 00 00    	je     6a34 <fwp_hof0.constprop.0+0x764>
    68a3:	80 fa 01             	cmp    $0x1,%dl
    68a6:	0f 84 ac 01 00 00    	je     6a58 <fwp_hof0.constprop.0+0x788>
    68ac:	80 fa ff             	cmp    $0xff,%dl
    68af:	0f 84 1b 0b 00 00    	je     73d0 <fwp_hof0.constprop.0+0x1100>
    68b5:	83 ea 01             	sub    $0x1,%edx
    68b8:	41 88 11             	mov    %dl,(%r9)
    68bb:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    68c2:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    68c8:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    68ce:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    68d5:	48 c1 e0 10          	shl    $0x10,%rax
    68d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68e0:	4c 89 f2             	mov    %r14,%rdx
    68e3:	48 29 fa             	sub    %rdi,%rdx
    68e6:	48 39 c2             	cmp    %rax,%rdx
    68e9:	73 75                	jae    6960 <fwp_hof0.constprop.0+0x690>
    68eb:	48 89 d0             	mov    %rdx,%rax
    68ee:	48 c1 e8 10          	shr    $0x10,%rax
    68f2:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    68f6:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    68fd:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    6901:	48 8b 46 20          	mov    0x20(%rsi),%rax
    6905:	48 85 c0             	test   %rax,%rax
    6908:	74 56                	je     6960 <fwp_hof0.constprop.0+0x690>
    690a:	0f b6 3e             	movzbl (%rsi),%edi
    690d:	40 80 ff 02          	cmp    $0x2,%dil
    6911:	0f 84 59 02 00 00    	je     6b70 <fwp_hof0.constprop.0+0x8a0>
    6917:	40 80 ff 01          	cmp    $0x1,%dil
    691b:	75 43                	jne    6960 <fwp_hof0.constprop.0+0x690>
    691d:	8b 7e 18             	mov    0x18(%rsi),%edi
    6920:	0f b7 d2             	movzwl %dx,%edx
    6923:	48 0f af fa          	imul   %rdx,%rdi
    6927:	8b 56 1c             	mov    0x1c(%rsi),%edx
    692a:	48 c1 ef 20          	shr    $0x20,%rdi
    692e:	48 39 d7             	cmp    %rdx,%rdi
    6931:	73 2d                	jae    6960 <fwp_hof0.constprop.0+0x690>
    6933:	48 01 f8             	add    %rdi,%rax
    6936:	0f b6 10             	movzbl (%rax),%edx
    6939:	84 d2                	test   %dl,%dl
    693b:	74 23                	je     6960 <fwp_hof0.constprop.0+0x690>
    693d:	80 fa 01             	cmp    $0x1,%dl
    6940:	0f 84 72 01 00 00    	je     6ab8 <fwp_hof0.constprop.0+0x7e8>
    6946:	80 fa ff             	cmp    $0xff,%dl
    6949:	0f 84 c1 09 00 00    	je     7310 <fwp_hof0.constprop.0+0x1040>
    694f:	83 ea 01             	sub    $0x1,%edx
    6952:	88 10                	mov    %dl,(%rax)
    6954:	90                   	nop
    6955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    695c:	00 00 00 00 
    6960:	66 48 0f 6e d1       	movq   %rcx,%xmm2
    6965:	66 0f 28 f2          	movapd %xmm2,%xmm6
    6969:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
    696d:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
    6971:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
    6975:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6979:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    697d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6981:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6985:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6989:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    698d:	f2 0f 59 05 eb 4c 00 	mulsd  0x4ceb(%rip),%xmm0        # b680 <msg.3+0xb0>
    6994:	00 
    6995:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    6999:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
    699d:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    69a1:	66 0f 28 ca          	movapd %xmm2,%xmm1
    69a5:	f2 0f 10 15 cb 4c 00 	movsd  0x4ccb(%rip),%xmm2        # b678 <msg.3+0xa8>
    69ac:	00 
    69ad:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    69b1:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    69b5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    69b9:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    69bd:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    69c2:	0f 88 74 0e 00 00    	js     783c <fwp_hof0.constprop.0+0x156c>
    69c8:	f2 0f 58 44 24 10    	addsd  0x10(%rsp),%xmm0
    69ce:	f2 0f 59 05 b2 4c 00 	mulsd  0x4cb2(%rip),%xmm0        # b688 <msg.3+0xb8>
    69d5:	00 
    69d6:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    69dc:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    69e0:	f2 43 0f 11 4c 3d 00 	movsd  %xmm1,0x0(%r13,%r15,1)
    69e7:	49 83 c7 08          	add    $0x8,%r15
    69eb:	48 39 5c 24 18       	cmp    %rbx,0x18(%rsp)
    69f0:	0f 84 aa 01 00 00    	je     6ba0 <fwp_hof0.constprop.0+0x8d0>
    69f6:	49 8b 14 24          	mov    (%r12),%rdx
    69fa:	48 89 d0             	mov    %rdx,%rax
    69fd:	48 0f ba f0 3f       	btr    $0x3f,%rax
    6a02:	48 39 c3             	cmp    %rax,%rbx
    6a05:	0f 82 e5 fb ff ff    	jb     65f0 <fwp_hof0.constprop.0+0x320>
    6a0b:	48 8d 3d 16 76 00 00 	lea    0x7616(%rip),%rdi        # e028 <s0+0x8>
    6a12:	e8 e9 c7 ff ff       	call   3200 <fwp_trap>
    6a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a1e:	00 00 
    6a20:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    6a24:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    6a2a:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    6a2f:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6a34:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    6a39:	66 0f 28 e5          	movapd %xmm5,%xmm4
    6a3d:	e9 9e fe ff ff       	jmp    68e0 <fwp_hof0.constprop.0+0x610>
    6a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a4c:	e9 6c ff ff ff       	jmp    69bd <fwp_hof0.constprop.0+0x6ed>
    6a51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a58:	48 89 f7             	mov    %rsi,%rdi
    6a5b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    6a60:	66 0f d6 4c 24 38    	movq   %xmm1,0x38(%rsp)
    6a66:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    6a6c:	f2 0f 11 6c 24 28    	movsd  %xmm5,0x28(%rsp)
    6a72:	e8 49 dc ff ff       	call   46c0 <fwp_rc_free_arr>
    6a77:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    6a7d:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6a84:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    6a8a:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    6a91:	f3 0f 7e 4c 24 38    	movq   0x38(%rsp),%xmm1
    6a97:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    6a9d:	48 c1 e0 10          	shl    $0x10,%rax
    6aa1:	f2 0f 10 6c 24 28    	movsd  0x28(%rsp),%xmm5
    6aa7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6aac:	e9 2f fe ff ff       	jmp    68e0 <fwp_hof0.constprop.0+0x610>
    6ab1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ab8:	4c 89 f7             	mov    %r14,%rdi
    6abb:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    6ac0:	66 0f d6 4c 24 48    	movq   %xmm1,0x48(%rsp)
    6ac6:	66 0f d6 44 24 40    	movq   %xmm0,0x40(%rsp)
    6acc:	f2 0f 11 6c 24 38    	movsd  %xmm5,0x38(%rsp)
    6ad2:	f2 0f 11 64 24 28    	movsd  %xmm4,0x28(%rsp)
    6ad8:	66 0f d6 5c 24 20    	movq   %xmm3,0x20(%rsp)
    6ade:	e8 dd db ff ff       	call   46c0 <fwp_rc_free_arr>
    6ae3:	f2 0f 10 6c 24 38    	movsd  0x38(%rsp),%xmm5
    6ae9:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    6aee:	f3 0f 7e 4c 24 48    	movq   0x48(%rsp),%xmm1
    6af4:	f3 0f 7e 44 24 40    	movq   0x40(%rsp),%xmm0
    6afa:	f2 0f 10 64 24 28    	movsd  0x28(%rsp),%xmm4
    6b00:	f3 0f 7e 5c 24 20    	movq   0x20(%rsp),%xmm3
    6b06:	e9 55 fe ff ff       	jmp    6960 <fwp_hof0.constprop.0+0x690>
    6b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b10:	66 85 d2             	test   %dx,%dx
    6b13:	0f 84 e1 fc ff ff    	je     67fa <fwp_hof0.constprop.0+0x52a>
    6b19:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    6b1d:	f2 41 0f 10 6e 08    	movsd  0x8(%r14),%xmm5
    6b23:	f3 0f 7e 46 08       	movq   0x8(%rsi),%xmm0
    6b28:	f3 0f 7e 4e 10       	movq   0x10(%rsi),%xmm1
    6b2d:	e9 0b fd ff ff       	jmp    683d <fwp_hof0.constprop.0+0x56d>
    6b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b38:	66 85 c0             	test   %ax,%ax
    6b3b:	0f 85 f3 fb ff ff    	jne    6734 <fwp_hof0.constprop.0+0x464>
    6b41:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b44:	0f 85 e7 fb ff ff    	jne    6731 <fwp_hof0.constprop.0+0x461>
    6b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b50:	48 89 d7             	mov    %rdx,%rdi
    6b53:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6b58:	e8 73 d3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6b5d:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6b62:	e9 ca fb ff ff       	jmp    6731 <fwp_hof0.constprop.0+0x461>
    6b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b6e:	00 00 
    6b70:	66 85 d2             	test   %dx,%dx
    6b73:	0f 85 e7 fd ff ff    	jne    6960 <fwp_hof0.constprop.0+0x690>
    6b79:	e9 b8 fd ff ff       	jmp    6936 <fwp_hof0.constprop.0+0x666>
    6b7e:	66 90                	xchg   %ax,%ax
    6b80:	66 85 d2             	test   %dx,%dx
    6b83:	0f 84 0e fd ff ff    	je     6897 <fwp_hof0.constprop.0+0x5c7>
    6b89:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    6b8e:	66 0f 28 e5          	movapd %xmm5,%xmm4
    6b92:	e9 49 fd ff ff       	jmp    68e0 <fwp_hof0.constprop.0+0x610>
    6b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b9e:	00 00 
    6ba0:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
    6ba5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6bac:	4c 89 e0             	mov    %r12,%rax
    6baf:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    6bb6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bba:	48 39 d0             	cmp    %rdx,%rax
    6bbd:	73 71                	jae    6c30 <fwp_hof0.constprop.0+0x960>
    6bbf:	48 89 c2             	mov    %rax,%rdx
    6bc2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    6bc9:	48 c1 ea 10          	shr    $0x10,%rdx
    6bcd:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6bd1:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6bd5:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6bd9:	48 85 db             	test   %rbx,%rbx
    6bdc:	74 52                	je     6c30 <fwp_hof0.constprop.0+0x960>
    6bde:	0f b6 32             	movzbl (%rdx),%esi
    6be1:	40 80 fe 02          	cmp    $0x2,%sil
    6be5:	0f 84 3d 06 00 00    	je     7228 <fwp_hof0.constprop.0+0xf58>
    6beb:	40 80 fe 01          	cmp    $0x1,%sil
    6bef:	75 3f                	jne    6c30 <fwp_hof0.constprop.0+0x960>
    6bf1:	8b 72 18             	mov    0x18(%rdx),%esi
    6bf4:	0f b7 c0             	movzwl %ax,%eax
    6bf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bfa:	48 0f af c6          	imul   %rsi,%rax
    6bfe:	48 c1 e8 20          	shr    $0x20,%rax
    6c02:	48 39 d0             	cmp    %rdx,%rax
    6c05:	73 29                	jae    6c30 <fwp_hof0.constprop.0+0x960>
    6c07:	48 01 c3             	add    %rax,%rbx
    6c0a:	0f b6 03             	movzbl (%rbx),%eax
    6c0d:	84 c0                	test   %al,%al
    6c0f:	74 1f                	je     6c30 <fwp_hof0.constprop.0+0x960>
    6c11:	3c 01                	cmp    $0x1,%al
    6c13:	0f 84 17 01 00 00    	je     6d30 <fwp_hof0.constprop.0+0xa60>
    6c19:	3c ff                	cmp    $0xff,%al
    6c1b:	0f 84 8b 09 00 00    	je     75ac <fwp_hof0.constprop.0+0x12dc>
    6c21:	83 e8 01             	sub    $0x1,%eax
    6c24:	88 03                	mov    %al,(%rbx)
    6c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c2d:	00 00 00 
    6c30:	4d 85 ff             	test   %r15,%r15
    6c33:	0f 85 97 01 00 00    	jne    6dd0 <fwp_hof0.constprop.0+0xb00>
    6c39:	4d 89 ef             	mov    %r13,%r15
    6c3c:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
    6c41:	4c 8d 6c 24 70       	lea    0x70(%rsp),%r13
    6c46:	45 31 e4             	xor    %r12d,%r12d
    6c49:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6c4d:	4c 89 ef             	mov    %r13,%rdi
    6c50:	be 01 00 00 00       	mov    $0x1,%esi
    6c55:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6c5c:	00 00 00 00 00 
    6c61:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
    6c66:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
    6c6b:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    6c72:	ff ff 7f 
    6c75:	e8 76 c2 ff ff       	call   2ef0 <buf_grow>
    6c7a:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6c7f:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6c84:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    6c88:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6c8d:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6c91:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6c96:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6c9b:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6ca0:	4c 89 f8             	mov    %r15,%rax
    6ca3:	4d 8d 7f 08          	lea    0x8(%r15),%r15
    6ca7:	4c 23 30             	and    (%rax),%r14
    6caa:	0f 84 15 02 00 00    	je     6ec5 <fwp_hof0.constprop.0+0xbf5>
    6cb0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    6cb5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    6cba:	eb 5b                	jmp    6d17 <fwp_hof0.constprop.0+0xa47>
    6cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    6cc0:	4a 8b 34 e0          	mov    (%rax,%r12,8),%rsi
    6cc4:	48 8d 15 d5 6e 00 00 	lea    0x6ed5(%rip),%rdx        # dba0 <d0>
    6ccb:	4c 89 ef             	mov    %r13,%rdi
    6cce:	49 83 c4 01          	add    $0x1,%r12
    6cd2:	e8 f9 e5 ff ff       	call   52d0 <fwp_write.constprop.0>
    6cd7:	4d 39 e6             	cmp    %r12,%r14
    6cda:	0f 84 e0 01 00 00    	je     6ec0 <fwp_hof0.constprop.0+0xbf0>
    6ce0:	be 02 00 00 00       	mov    $0x2,%esi
    6ce5:	4c 89 ef             	mov    %r13,%rdi
    6ce8:	e8 03 c2 ff ff       	call   2ef0 <buf_grow>
    6ced:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6cf2:	ba 2c 20 00 00       	mov    $0x202c,%edx
    6cf7:	48 03 44 24 70       	add    0x70(%rsp),%rax
    6cfc:	66 89 10             	mov    %dx,(%rax)
    6cff:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6d04:	48 8d 50 02          	lea    0x2(%rax),%rdx
    6d08:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6d0d:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6d12:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    6d17:	4c 89 f8             	mov    %r15,%rax
    6d1a:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    6d1e:	79 a0                	jns    6cc0 <fwp_hof0.constprop.0+0x9f0>
    6d20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d24:	eb 9a                	jmp    6cc0 <fwp_hof0.constprop.0+0x9f0>
    6d26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d2d:	00 00 00 
    6d30:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    6d37:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6d3e:	4c 89 e0             	mov    %r12,%rax
    6d41:	4c 89 e7             	mov    %r12,%rdi
    6d44:	48 29 f0             	sub    %rsi,%rax
    6d47:	48 c1 e2 10          	shl    $0x10,%rdx
    6d4b:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    6d50:	0f 88 ea 04 00 00    	js     7240 <fwp_hof0.constprop.0+0xf70>
    6d56:	48 39 d0             	cmp    %rdx,%rax
    6d59:	0f 83 d1 fe ff ff    	jae    6c30 <fwp_hof0.constprop.0+0x960>
    6d5f:	48 89 c2             	mov    %rax,%rdx
    6d62:	48 c1 ea 10          	shr    $0x10,%rdx
    6d66:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6d6a:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6d6e:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d72:	48 85 c9             	test   %rcx,%rcx
    6d75:	0f 84 b5 fe ff ff    	je     6c30 <fwp_hof0.constprop.0+0x960>
    6d7b:	0f b6 32             	movzbl (%rdx),%esi
    6d7e:	40 80 fe 02          	cmp    $0x2,%sil
    6d82:	0f 84 70 05 00 00    	je     72f8 <fwp_hof0.constprop.0+0x1028>
    6d88:	40 80 fe 01          	cmp    $0x1,%sil
    6d8c:	0f 85 9e fe ff ff    	jne    6c30 <fwp_hof0.constprop.0+0x960>
    6d92:	8b 72 18             	mov    0x18(%rdx),%esi
    6d95:	0f b7 c0             	movzwl %ax,%eax
    6d98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d9b:	48 0f af c6          	imul   %rsi,%rax
    6d9f:	48 c1 e8 20          	shr    $0x20,%rax
    6da3:	48 39 d0             	cmp    %rdx,%rax
    6da6:	0f 83 84 fe ff ff    	jae    6c30 <fwp_hof0.constprop.0+0x960>
    6dac:	48 01 c1             	add    %rax,%rcx
    6daf:	80 39 01             	cmpb   $0x1,(%rcx)
    6db2:	0f 85 78 fe ff ff    	jne    6c30 <fwp_hof0.constprop.0+0x960>
    6db8:	4c 89 e7             	mov    %r12,%rdi
    6dbb:	e8 50 d3 ff ff       	call   4110 <fwp_mem_free>
    6dc0:	4d 85 ff             	test   %r15,%r15
    6dc3:	0f 84 70 fe ff ff    	je     6c39 <fwp_hof0.constprop.0+0x969>
    6dc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dd0:	4c 89 fa             	mov    %r15,%rdx
    6dd3:	31 c0                	xor    %eax,%eax
    6dd5:	4d 89 ec             	mov    %r13,%r12
    6dd8:	48 83 ea 01          	sub    $0x1,%rdx
    6ddc:	0f 90 c0             	seto   %al
    6ddf:	49 89 d7             	mov    %rdx,%r15
    6de2:	e9 32 f7 ff ff       	jmp    6519 <fwp_hof0.constprop.0+0x249>
    6de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dee:	00 00 
    6df0:	49 83 3e 00          	cmpq   $0x0,(%r14)
    6df4:	0f 88 42 0a 00 00    	js     783c <fwp_hof0.constprop.0+0x156c>
    6dfa:	4b 89 0c ee          	mov    %rcx,(%r14,%r13,8)
    6dfe:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    6e05:	48 2b 95 b0 13 00 00 	sub    0x13b0(%rbp),%rdx
    6e0c:	48 c1 e0 10          	shl    $0x10,%rax
    6e10:	48 39 c2             	cmp    %rax,%rdx
    6e13:	73 58                	jae    6e6d <fwp_hof0.constprop.0+0xb9d>
    6e15:	48 89 d0             	mov    %rdx,%rax
    6e18:	48 c1 e8 10          	shr    $0x10,%rax
    6e1c:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    6e20:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    6e27:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    6e2b:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6e2f:	48 85 c9             	test   %rcx,%rcx
    6e32:	74 39                	je     6e6d <fwp_hof0.constprop.0+0xb9d>
    6e34:	0f b6 30             	movzbl (%rax),%esi
    6e37:	40 80 fe 02          	cmp    $0x2,%sil
    6e3b:	0f 84 ff 05 00 00    	je     7440 <fwp_hof0.constprop.0+0x1170>
    6e41:	40 80 fe 01          	cmp    $0x1,%sil
    6e45:	75 26                	jne    6e6d <fwp_hof0.constprop.0+0xb9d>
    6e47:	8b 70 18             	mov    0x18(%rax),%esi
    6e4a:	0f b7 d2             	movzwl %dx,%edx
    6e4d:	8b 40 1c             	mov    0x1c(%rax),%eax
    6e50:	48 0f af d6          	imul   %rsi,%rdx
    6e54:	48 c1 ea 20          	shr    $0x20,%rdx
    6e58:	48 39 c2             	cmp    %rax,%rdx
    6e5b:	73 10                	jae    6e6d <fwp_hof0.constprop.0+0xb9d>
    6e5d:	48 01 d1             	add    %rdx,%rcx
    6e60:	80 39 01             	cmpb   $0x1,(%rcx)
    6e63:	75 08                	jne    6e6d <fwp_hof0.constprop.0+0xb9d>
    6e65:	4c 89 cf             	mov    %r9,%rdi
    6e68:	e8 a3 d2 ff ff       	call   4110 <fwp_mem_free>
    6e6d:	4d 85 e4             	test   %r12,%r12
    6e70:	0f 84 ea 05 00 00    	je     7460 <fwp_hof0.constprop.0+0x1190>
    6e76:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    6e7b:	4d 89 e1             	mov    %r12,%r9
    6e7e:	4d 89 e0             	mov    %r12,%r8
    6e81:	4c 89 e2             	mov    %r12,%rdx
    6e84:	49 83 c5 01          	add    $0x1,%r13
    6e88:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    6e8d:	e9 d6 f5 ff ff       	jmp    6468 <fwp_hof0.constprop.0+0x198>
    6e92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e98:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    6e9d:	e9 5c f7 ff ff       	jmp    65fe <fwp_hof0.constprop.0+0x32e>
    6ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ea8:	66 85 c0             	test   %ax,%ax
    6eab:	0f 85 3d f6 ff ff    	jne    64ee <fwp_hof0.constprop.0+0x21e>
    6eb1:	e9 19 f6 ff ff       	jmp    64cf <fwp_hof0.constprop.0+0x1ff>
    6eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ebd:	00 00 00 
    6ec0:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    6ec5:	be 01 00 00 00       	mov    $0x1,%esi
    6eca:	4c 89 ef             	mov    %r13,%rdi
    6ecd:	e8 1e c0 ff ff       	call   2ef0 <buf_grow>
    6ed2:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6ed7:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6edc:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    6ee0:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    6ee5:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6ee9:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6eee:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    6ef3:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6ef8:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    6efd:	48 8d 05 6a 41 00 00 	lea    0x416a(%rip),%rax        # b06e <_IO_stdin_used+0x6e>
    6f04:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    6f09:	48 85 c9             	test   %rcx,%rcx
    6f0c:	48 0f 44 c8          	cmove  %rax,%rcx
    6f10:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    6f14:	0f 87 72 09 00 00    	ja     788c <fwp_hof0.constprop.0+0x15bc>
    6f1a:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    6f1e:	be 01 00 00 00       	mov    $0x1,%esi
    6f23:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6f28:	e8 13 d8 ff ff       	call   4740 <fwp_heap_alloc>
    6f2d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6f32:	4c 89 f2             	mov    %r14,%rdx
    6f35:	4c 89 30             	mov    %r14,(%rax)
    6f38:	4c 8d 60 08          	lea    0x8(%rax),%r12
    6f3c:	49 89 c5             	mov    %rax,%r13
    6f3f:	4c 89 e7             	mov    %r12,%rdi
    6f42:	e8 29 b6 ff ff       	call   2570 <memcpy@plt>
    6f47:	43 c6 44 35 08 00    	movb   $0x0,0x8(%r13,%r14,1)
    6f4d:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
    6f52:	e8 49 b4 ff ff       	call   23a0 <free@plt>
    6f57:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    6f5e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6f65:	4c 89 e8             	mov    %r13,%rax
    6f68:	48 29 c8             	sub    %rcx,%rax
    6f6b:	48 c1 e2 10          	shl    $0x10,%rdx
    6f6f:	48 39 d0             	cmp    %rdx,%rax
    6f72:	73 6b                	jae    6fdf <fwp_hof0.constprop.0+0xd0f>
    6f74:	48 89 c6             	mov    %rax,%rsi
    6f77:	48 c1 ee 10          	shr    $0x10,%rsi
    6f7b:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6f7f:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    6f86:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6f8a:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    6f8e:	4d 85 f6             	test   %r14,%r14
    6f91:	74 4c                	je     6fdf <fwp_hof0.constprop.0+0xd0f>
    6f93:	0f b6 3e             	movzbl (%rsi),%edi
    6f96:	40 80 ff 02          	cmp    $0x2,%dil
    6f9a:	0f 84 a0 05 00 00    	je     7540 <fwp_hof0.constprop.0+0x1270>
    6fa0:	40 80 ff 01          	cmp    $0x1,%dil
    6fa4:	75 39                	jne    6fdf <fwp_hof0.constprop.0+0xd0f>
    6fa6:	8b 7e 18             	mov    0x18(%rsi),%edi
    6fa9:	0f b7 c0             	movzwl %ax,%eax
    6fac:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6faf:	48 0f af c7          	imul   %rdi,%rax
    6fb3:	48 c1 e8 20          	shr    $0x20,%rax
    6fb7:	48 39 f0             	cmp    %rsi,%rax
    6fba:	73 23                	jae    6fdf <fwp_hof0.constprop.0+0xd0f>
    6fbc:	49 01 c6             	add    %rax,%r14
    6fbf:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6fc3:	0f 84 8a 05 00 00    	je     7553 <fwp_hof0.constprop.0+0x1283>
    6fc9:	41 c6 06 01          	movb   $0x1,(%r14)
    6fcd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    6fd4:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    6fdb:	48 c1 e2 10          	shl    $0x10,%rdx
    6fdf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6fe4:	48 89 f8             	mov    %rdi,%rax
    6fe7:	48 29 c8             	sub    %rcx,%rax
    6fea:	48 39 d0             	cmp    %rdx,%rax
    6fed:	73 71                	jae    7060 <fwp_hof0.constprop.0+0xd90>
    6fef:	48 89 c2             	mov    %rax,%rdx
    6ff2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    6ff9:	48 c1 ea 10          	shr    $0x10,%rdx
    6ffd:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7001:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    7005:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    7009:	4d 85 f6             	test   %r14,%r14
    700c:	74 52                	je     7060 <fwp_hof0.constprop.0+0xd90>
    700e:	0f b6 32             	movzbl (%rdx),%esi
    7011:	40 80 fe 02          	cmp    $0x2,%sil
    7015:	0f 84 55 04 00 00    	je     7470 <fwp_hof0.constprop.0+0x11a0>
    701b:	40 80 fe 01          	cmp    $0x1,%sil
    701f:	75 3f                	jne    7060 <fwp_hof0.constprop.0+0xd90>
    7021:	8b 72 18             	mov    0x18(%rdx),%esi
    7024:	0f b7 c0             	movzwl %ax,%eax
    7027:	8b 52 1c             	mov    0x1c(%rdx),%edx
    702a:	48 0f af c6          	imul   %rsi,%rax
    702e:	48 c1 e8 20          	shr    $0x20,%rax
    7032:	48 39 d0             	cmp    %rdx,%rax
    7035:	73 29                	jae    7060 <fwp_hof0.constprop.0+0xd90>
    7037:	49 01 c6             	add    %rax,%r14
    703a:	41 0f b6 06          	movzbl (%r14),%eax
    703e:	84 c0                	test   %al,%al
    7040:	74 1e                	je     7060 <fwp_hof0.constprop.0+0xd90>
    7042:	3c 01                	cmp    $0x1,%al
    7044:	0f 84 0e 01 00 00    	je     7158 <fwp_hof0.constprop.0+0xe88>
    704a:	3c ff                	cmp    $0xff,%al
    704c:	0f 84 33 06 00 00    	je     7685 <fwp_hof0.constprop.0+0x13b5>
    7052:	83 e8 01             	sub    $0x1,%eax
    7055:	41 88 06             	mov    %al,(%r14)
    7058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    705f:	00 
    7060:	49 8b 55 00          	mov    0x0(%r13),%rdx
    7064:	48 8b 0d 4d 93 01 00 	mov    0x1934d(%rip),%rcx        # 203b8 <fwp_prog_out>
    706b:	be 01 00 00 00       	mov    $0x1,%esi
    7070:	4c 89 e7             	mov    %r12,%rdi
    7073:	e8 c8 b5 ff ff       	call   2640 <fwrite@plt>
    7078:	48 8b 35 39 93 01 00 	mov    0x19339(%rip),%rsi        # 203b8 <fwp_prog_out>
    707f:	bf 0a 00 00 00       	mov    $0xa,%edi
    7084:	e8 37 b4 ff ff       	call   24c0 <fputc@plt>
    7089:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    7090:	4c 89 e8             	mov    %r13,%rax
    7093:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    709a:	48 c1 e2 10          	shl    $0x10,%rdx
    709e:	48 39 d0             	cmp    %rdx,%rax
    70a1:	73 6d                	jae    7110 <fwp_hof0.constprop.0+0xe40>
    70a3:	48 89 c2             	mov    %rax,%rdx
    70a6:	48 c1 ea 10          	shr    $0x10,%rdx
    70aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70ae:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    70b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    70b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    70bd:	4d 85 e4             	test   %r12,%r12
    70c0:	74 4e                	je     7110 <fwp_hof0.constprop.0+0xe40>
    70c2:	0f b6 0a             	movzbl (%rdx),%ecx
    70c5:	80 f9 02             	cmp    $0x2,%cl
    70c8:	0f 84 92 04 00 00    	je     7560 <fwp_hof0.constprop.0+0x1290>
    70ce:	80 f9 01             	cmp    $0x1,%cl
    70d1:	75 3d                	jne    7110 <fwp_hof0.constprop.0+0xe40>
    70d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    70d6:	0f b7 c0             	movzwl %ax,%eax
    70d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    70dc:	48 0f af c1          	imul   %rcx,%rax
    70e0:	48 c1 e8 20          	shr    $0x20,%rax
    70e4:	48 39 d0             	cmp    %rdx,%rax
    70e7:	73 27                	jae    7110 <fwp_hof0.constprop.0+0xe40>
    70e9:	49 01 c4             	add    %rax,%r12
    70ec:	41 0f b6 04 24       	movzbl (%r12),%eax
    70f1:	84 c0                	test   %al,%al
    70f3:	74 1b                	je     7110 <fwp_hof0.constprop.0+0xe40>
    70f5:	3c 01                	cmp    $0x1,%al
    70f7:	0f 84 81 04 00 00    	je     757e <fwp_hof0.constprop.0+0x12ae>
    70fd:	3c ff                	cmp    $0xff,%al
    70ff:	0f 84 fa 05 00 00    	je     76ff <fwp_hof0.constprop.0+0x142f>
    7105:	83 e8 01             	sub    $0x1,%eax
    7108:	41 88 04 24          	mov    %al,(%r12)
    710c:	0f 1f 40 00          	nopl   0x0(%rax)
    7110:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    7115:	48 8b 40 10          	mov    0x10(%rax),%rax
    7119:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    711e:	48 85 c0             	test   %rax,%rax
    7121:	0f 85 e9 f1 ff ff    	jne    6310 <fwp_hof0.constprop.0+0x40>
    7127:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
    712e:	00 
    712f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7136:	00 00 
    7138:	0f 85 6b 07 00 00    	jne    78a9 <fwp_hof0.constprop.0+0x15d9>
    713e:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    7145:	31 c0                	xor    %eax,%eax
    7147:	5b                   	pop    %rbx
    7148:	5d                   	pop    %rbp
    7149:	41 5c                	pop    %r12
    714b:	41 5d                	pop    %r13
    714d:	41 5e                	pop    %r14
    714f:	41 5f                	pop    %r15
    7151:	c3                   	ret
    7152:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7158:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    715c:	0f 88 1e 03 00 00    	js     7480 <fwp_hof0.constprop.0+0x11b0>
    7162:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    7169:	48 89 f8             	mov    %rdi,%rax
    716c:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7171:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    7178:	48 c1 e2 10          	shl    $0x10,%rdx
    717c:	48 39 d0             	cmp    %rdx,%rax
    717f:	0f 83 db fe ff ff    	jae    7060 <fwp_hof0.constprop.0+0xd90>
    7185:	48 89 c2             	mov    %rax,%rdx
    7188:	48 c1 ea 10          	shr    $0x10,%rdx
    718c:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7190:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    7194:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7198:	48 85 c9             	test   %rcx,%rcx
    719b:	0f 84 bf fe ff ff    	je     7060 <fwp_hof0.constprop.0+0xd90>
    71a1:	0f b6 32             	movzbl (%rdx),%esi
    71a4:	40 80 fe 02          	cmp    $0x2,%sil
    71a8:	0f 84 e2 03 00 00    	je     7590 <fwp_hof0.constprop.0+0x12c0>
    71ae:	40 80 fe 01          	cmp    $0x1,%sil
    71b2:	0f 85 a8 fe ff ff    	jne    7060 <fwp_hof0.constprop.0+0xd90>
    71b8:	8b 72 18             	mov    0x18(%rdx),%esi
    71bb:	0f b7 c0             	movzwl %ax,%eax
    71be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71c1:	48 0f af c6          	imul   %rsi,%rax
    71c5:	48 c1 e8 20          	shr    $0x20,%rax
    71c9:	48 39 d0             	cmp    %rdx,%rax
    71cc:	0f 83 8e fe ff ff    	jae    7060 <fwp_hof0.constprop.0+0xd90>
    71d2:	48 01 c1             	add    %rax,%rcx
    71d5:	80 39 01             	cmpb   $0x1,(%rcx)
    71d8:	0f 85 82 fe ff ff    	jne    7060 <fwp_hof0.constprop.0+0xd90>
    71de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    71e3:	e8 28 cf ff ff       	call   4110 <fwp_mem_free>
    71e8:	e9 73 fe ff ff       	jmp    7060 <fwp_hof0.constprop.0+0xd90>
    71ed:	0f 1f 00             	nopl   (%rax)
    71f0:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
    71f5:	e9 5d f5 ff ff       	jmp    6757 <fwp_hof0.constprop.0+0x487>
    71fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7200:	4c 89 cf             	mov    %r9,%rdi
    7203:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
    7208:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    720d:	e8 be cc ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7212:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
    7217:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    721c:	e9 e3 f5 ff ff       	jmp    6804 <fwp_hof0.constprop.0+0x534>
    7221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7228:	66 85 c0             	test   %ax,%ax
    722b:	0f 85 ff f9 ff ff    	jne    6c30 <fwp_hof0.constprop.0+0x960>
    7231:	e9 d4 f9 ff ff       	jmp    6c0a <fwp_hof0.constprop.0+0x93a>
    7236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    723d:	00 00 00 
    7240:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    7245:	48 39 d0             	cmp    %rdx,%rax
    7248:	73 63                	jae    72ad <fwp_hof0.constprop.0+0xfdd>
    724a:	49 89 c0             	mov    %rax,%r8
    724d:	49 c1 e8 10          	shr    $0x10,%r8
    7251:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    7255:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
    7259:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    725d:	4d 85 c0             	test   %r8,%r8
    7260:	74 4b                	je     72ad <fwp_hof0.constprop.0+0xfdd>
    7262:	44 0f b6 09          	movzbl (%rcx),%r9d
    7266:	41 80 f9 02          	cmp    $0x2,%r9b
    726a:	0f 84 2e 03 00 00    	je     759e <fwp_hof0.constprop.0+0x12ce>
    7270:	41 80 f9 01          	cmp    $0x1,%r9b
    7274:	75 37                	jne    72ad <fwp_hof0.constprop.0+0xfdd>
    7276:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    727a:	0f b7 c0             	movzwl %ax,%eax
    727d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7280:	49 0f af c1          	imul   %r9,%rax
    7284:	48 c1 e8 20          	shr    $0x20,%rax
    7288:	48 39 c8             	cmp    %rcx,%rax
    728b:	73 20                	jae    72ad <fwp_hof0.constprop.0+0xfdd>
    728d:	49 01 c0             	add    %rax,%r8
    7290:	41 80 38 01          	cmpb   $0x1,(%r8)
    7294:	75 17                	jne    72ad <fwp_hof0.constprop.0+0xfdd>
    7296:	e8 75 ce ff ff       	call   4110 <fwp_mem_free>
    729b:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    72a2:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    72a9:	48 c1 e2 10          	shl    $0x10,%rdx
    72ad:	4c 89 e0             	mov    %r12,%rax
    72b0:	48 29 f0             	sub    %rsi,%rax
    72b3:	48 39 d0             	cmp    %rdx,%rax
    72b6:	0f 82 03 f9 ff ff    	jb     6bbf <fwp_hof0.constprop.0+0x8ef>
    72bc:	e9 6f f9 ff ff       	jmp    6c30 <fwp_hof0.constprop.0+0x960>
    72c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72c8:	66 85 c0             	test   %ax,%ax
    72cb:	0f 85 f6 f2 ff ff    	jne    65c7 <fwp_hof0.constprop.0+0x2f7>
    72d1:	80 3b ff             	cmpb   $0xff,(%rbx)
    72d4:	0f 85 ea f2 ff ff    	jne    65c4 <fwp_hof0.constprop.0+0x2f4>
    72da:	48 89 df             	mov    %rbx,%rdi
    72dd:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    72e2:	e8 e9 cb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    72e7:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    72ec:	e9 d3 f2 ff ff       	jmp    65c4 <fwp_hof0.constprop.0+0x2f4>
    72f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f8:	66 85 c0             	test   %ax,%ax
    72fb:	0f 85 2f f9 ff ff    	jne    6c30 <fwp_hof0.constprop.0+0x960>
    7301:	e9 a9 fa ff ff       	jmp    6daf <fwp_hof0.constprop.0+0xadf>
    7306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    730d:	00 00 00 
    7310:	48 89 c2             	mov    %rax,%rdx
    7313:	48 c1 ea 11          	shr    $0x11,%rdx
    7317:	48 31 c2             	xor    %rax,%rdx
    731a:	48 89 d6             	mov    %rdx,%rsi
    731d:	48 c1 ee 09          	shr    $0x9,%rsi
    7321:	48 31 f2             	xor    %rsi,%rdx
    7324:	0f b6 f2             	movzbl %dl,%esi
    7327:	48 8b 94 f5 48 14 00 	mov    0x1448(%rbp,%rsi,8),%rdx
    732e:	00 
    732f:	48 85 d2             	test   %rdx,%rdx
    7332:	75 19                	jne    734d <fwp_hof0.constprop.0+0x107d>
    7334:	e9 47 05 00 00       	jmp    7880 <fwp_hof0.constprop.0+0x15b0>
    7339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7340:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7344:	48 85 d2             	test   %rdx,%rdx
    7347:	0f 84 33 05 00 00    	je     7880 <fwp_hof0.constprop.0+0x15b0>
    734d:	48 89 d6             	mov    %rdx,%rsi
    7350:	48 3b 02             	cmp    (%rdx),%rax
    7353:	75 eb                	jne    7340 <fwp_hof0.constprop.0+0x1070>
    7355:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7359:	48 8d 77 ff          	lea    -0x1(%rdi),%rsi
    735d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7361:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7368:	0f 85 f2 f5 ff ff    	jne    6960 <fwp_hof0.constprop.0+0x690>
    736e:	48 89 c7             	mov    %rax,%rdi
    7371:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    7376:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    737b:	66 0f d6 4c 24 68    	movq   %xmm1,0x68(%rsp)
    7381:	66 0f d6 44 24 48    	movq   %xmm0,0x48(%rsp)
    7387:	f2 0f 11 6c 24 40    	movsd  %xmm5,0x40(%rsp)
    738d:	f2 0f 11 64 24 30    	movsd  %xmm4,0x30(%rsp)
    7393:	66 0f d6 5c 24 28    	movq   %xmm3,0x28(%rsp)
    7399:	e8 32 cb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    739e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    73a3:	f2 0f 10 64 24 30    	movsd  0x30(%rsp),%xmm4
    73a9:	f3 0f 7e 5c 24 28    	movq   0x28(%rsp),%xmm3
    73af:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    73b4:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
    73ba:	c6 00 fe             	movb   $0xfe,(%rax)
    73bd:	f3 0f 7e 44 24 48    	movq   0x48(%rsp),%xmm0
    73c3:	f3 0f 7e 4c 24 68    	movq   0x68(%rsp),%xmm1
    73c9:	e9 92 f5 ff ff       	jmp    6960 <fwp_hof0.constprop.0+0x690>
    73ce:	66 90                	xchg   %ax,%ax
    73d0:	4c 89 ca             	mov    %r9,%rdx
    73d3:	48 c1 ea 11          	shr    $0x11,%rdx
    73d7:	4c 31 ca             	xor    %r9,%rdx
    73da:	48 89 d6             	mov    %rdx,%rsi
    73dd:	48 c1 ee 09          	shr    $0x9,%rsi
    73e1:	48 31 d6             	xor    %rdx,%rsi
    73e4:	40 0f b6 f6          	movzbl %sil,%esi
    73e8:	48 8b 94 f5 48 14 00 	mov    0x1448(%rbp,%rsi,8),%rdx
    73ef:	00 
    73f0:	48 85 d2             	test   %rdx,%rdx
    73f3:	75 18                	jne    740d <fwp_hof0.constprop.0+0x113d>
    73f5:	e9 86 04 00 00       	jmp    7880 <fwp_hof0.constprop.0+0x15b0>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7400:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7404:	48 85 d2             	test   %rdx,%rdx
    7407:	0f 84 73 04 00 00    	je     7880 <fwp_hof0.constprop.0+0x15b0>
    740d:	48 89 d6             	mov    %rdx,%rsi
    7410:	4c 3b 0a             	cmp    (%rdx),%r9
    7413:	75 eb                	jne    7400 <fwp_hof0.constprop.0+0x1130>
    7415:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    7419:	48 83 ee 01          	sub    $0x1,%rsi
    741d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    7421:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7428:	0f 84 f0 01 00 00    	je     761e <fwp_hof0.constprop.0+0x134e>
    742e:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    7434:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    743a:	e9 a1 f4 ff ff       	jmp    68e0 <fwp_hof0.constprop.0+0x610>
    743f:	90                   	nop
    7440:	66 85 d2             	test   %dx,%dx
    7443:	0f 84 17 fa ff ff    	je     6e60 <fwp_hof0.constprop.0+0xb90>
    7449:	4d 85 e4             	test   %r12,%r12
    744c:	0f 85 24 fa ff ff    	jne    6e76 <fwp_hof0.constprop.0+0xba6>
    7452:	0f 1f 00             	nopl   (%rax)
    7455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    745c:	00 00 00 00 
    7460:	45 31 c0             	xor    %r8d,%r8d
    7463:	e9 99 f0 ff ff       	jmp    6501 <fwp_hof0.constprop.0+0x231>
    7468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    746f:	00 
    7470:	66 85 c0             	test   %ax,%ax
    7473:	0f 85 e7 fb ff ff    	jne    7060 <fwp_hof0.constprop.0+0xd90>
    7479:	e9 bc fb ff ff       	jmp    703a <fwp_hof0.constprop.0+0xd6a>
    747e:	66 90                	xchg   %ax,%ax
    7480:	4c 8b 77 08          	mov    0x8(%rdi),%r14
    7484:	e8 37 d2 ff ff       	call   46c0 <fwp_rc_free_arr>
    7489:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    7490:	4c 89 f0             	mov    %r14,%rax
    7493:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    749a:	48 c1 e2 10          	shl    $0x10,%rdx
    749e:	48 39 d0             	cmp    %rdx,%rax
    74a1:	0f 83 b9 fb ff ff    	jae    7060 <fwp_hof0.constprop.0+0xd90>
    74a7:	4c 89 f7             	mov    %r14,%rdi
    74aa:	e9 40 fb ff ff       	jmp    6fef <fwp_hof0.constprop.0+0xd1f>
    74af:	90                   	nop
    74b0:	66 85 c0             	test   %ax,%ax
    74b3:	0f 85 8f ef ff ff    	jne    6448 <fwp_hof0.constprop.0+0x178>
    74b9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    74be:	0f 85 7f ef ff ff    	jne    6443 <fwp_hof0.constprop.0+0x173>
    74c4:	4c 89 e7             	mov    %r12,%rdi
    74c7:	e8 04 ca ff ff       	call   3ed0 <fwp_rc_forget_slot>
    74cc:	e9 72 ef ff ff       	jmp    6443 <fwp_hof0.constprop.0+0x173>
    74d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74d8:	66 85 c0             	test   %ax,%ax
    74db:	0f 84 92 ee ff ff    	je     6373 <fwp_hof0.constprop.0+0xa3>
    74e1:	48 85 db             	test   %rbx,%rbx
    74e4:	0f 85 bc ee ff ff    	jne    63a6 <fwp_hof0.constprop.0+0xd6>
    74ea:	31 ff                	xor    %edi,%edi
    74ec:	e8 2f d6 ff ff       	call   4b20 <fwp_array_new_packed.constprop.0>
    74f1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    74f8:	49 89 c6             	mov    %rax,%r14
    74fb:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    7502:	48 c1 e2 10          	shl    $0x10,%rdx
    7506:	48 39 d0             	cmp    %rdx,%rax
    7509:	0f 83 51 ff ff ff    	jae    7460 <fwp_hof0.constprop.0+0x1190>
    750f:	48 89 c2             	mov    %rax,%rdx
    7512:	48 c1 ea 10          	shr    $0x10,%rdx
    7516:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    751a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    7521:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7525:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7529:	4d 85 e4             	test   %r12,%r12
    752c:	0f 85 dc ee ff ff    	jne    640e <fwp_hof0.constprop.0+0x13e>
    7532:	e9 29 ff ff ff       	jmp    7460 <fwp_hof0.constprop.0+0x1190>
    7537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    753e:	00 00 
    7540:	66 85 c0             	test   %ax,%ax
    7543:	0f 85 96 fa ff ff    	jne    6fdf <fwp_hof0.constprop.0+0xd0f>
    7549:	41 80 3e ff          	cmpb   $0xff,(%r14)
    754d:	0f 85 76 fa ff ff    	jne    6fc9 <fwp_hof0.constprop.0+0xcf9>
    7553:	4c 89 f7             	mov    %r14,%rdi
    7556:	e8 75 c9 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    755b:	e9 69 fa ff ff       	jmp    6fc9 <fwp_hof0.constprop.0+0xcf9>
    7560:	66 85 c0             	test   %ax,%ax
    7563:	0f 85 a7 fb ff ff    	jne    7110 <fwp_hof0.constprop.0+0xe40>
    7569:	41 0f b6 04 24       	movzbl (%r12),%eax
    756e:	84 c0                	test   %al,%al
    7570:	0f 84 9a fb ff ff    	je     7110 <fwp_hof0.constprop.0+0xe40>
    7576:	3c 01                	cmp    $0x1,%al
    7578:	0f 85 7f fb ff ff    	jne    70fd <fwp_hof0.constprop.0+0xe2d>
    757e:	4c 89 ef             	mov    %r13,%rdi
    7581:	e8 8a cb ff ff       	call   4110 <fwp_mem_free>
    7586:	e9 85 fb ff ff       	jmp    7110 <fwp_hof0.constprop.0+0xe40>
    758b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7590:	66 85 c0             	test   %ax,%ax
    7593:	0f 85 c7 fa ff ff    	jne    7060 <fwp_hof0.constprop.0+0xd90>
    7599:	e9 37 fc ff ff       	jmp    71d5 <fwp_hof0.constprop.0+0xf05>
    759e:	66 85 c0             	test   %ax,%ax
    75a1:	0f 85 06 fd ff ff    	jne    72ad <fwp_hof0.constprop.0+0xfdd>
    75a7:	e9 e4 fc ff ff       	jmp    7290 <fwp_hof0.constprop.0+0xfc0>
    75ac:	48 89 d8             	mov    %rbx,%rax
    75af:	48 c1 e8 11          	shr    $0x11,%rax
    75b3:	48 31 d8             	xor    %rbx,%rax
    75b6:	48 89 c2             	mov    %rax,%rdx
    75b9:	48 c1 ea 09          	shr    $0x9,%rdx
    75bd:	48 31 d0             	xor    %rdx,%rax
    75c0:	0f b6 d0             	movzbl %al,%edx
    75c3:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    75ca:	00 
    75cb:	48 85 c0             	test   %rax,%rax
    75ce:	75 1d                	jne    75ed <fwp_hof0.constprop.0+0x131d>
    75d0:	e9 ab 02 00 00       	jmp    7880 <fwp_hof0.constprop.0+0x15b0>
    75d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75dc:	00 00 00 00 
    75e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    75e4:	48 85 c0             	test   %rax,%rax
    75e7:	0f 84 93 02 00 00    	je     7880 <fwp_hof0.constprop.0+0x15b0>
    75ed:	48 89 c2             	mov    %rax,%rdx
    75f0:	48 3b 18             	cmp    (%rax),%rbx
    75f3:	75 eb                	jne    75e0 <fwp_hof0.constprop.0+0x1310>
    75f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    75f9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    75fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7601:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7608:	0f 85 22 f6 ff ff    	jne    6c30 <fwp_hof0.constprop.0+0x960>
    760e:	48 89 df             	mov    %rbx,%rdi
    7611:	e8 ba c8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7616:	c6 03 fe             	movb   $0xfe,(%rbx)
    7619:	e9 12 f6 ff ff       	jmp    6c30 <fwp_hof0.constprop.0+0x960>
    761e:	4c 89 cf             	mov    %r9,%rdi
    7621:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    7626:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    762b:	66 0f d6 4c 24 40    	movq   %xmm1,0x40(%rsp)
    7631:	66 0f d6 44 24 38    	movq   %xmm0,0x38(%rsp)
    7637:	f2 0f 11 6c 24 30    	movsd  %xmm5,0x30(%rsp)
    763d:	e8 8e c8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7642:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    7647:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    764c:	f2 0f 10 6c 24 30    	movsd  0x30(%rsp),%xmm5
    7652:	f3 0f 7e 44 24 38    	movq   0x38(%rsp),%xmm0
    7658:	41 c6 01 fe          	movb   $0xfe,(%r9)
    765c:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    7663:	f2 41 0f 10 66 08    	movsd  0x8(%r14),%xmm4
    7669:	f3 41 0f 7e 5e 10    	movq   0x10(%r14),%xmm3
    766f:	48 8b bd b0 13 00 00 	mov    0x13b0(%rbp),%rdi
    7676:	f3 0f 7e 4c 24 40    	movq   0x40(%rsp),%xmm1
    767c:	48 c1 e0 10          	shl    $0x10,%rax
    7680:	e9 5b f2 ff ff       	jmp    68e0 <fwp_hof0.constprop.0+0x610>
    7685:	4c 89 f2             	mov    %r14,%rdx
    7688:	48 c1 ea 11          	shr    $0x11,%rdx
    768c:	4c 31 f2             	xor    %r14,%rdx
    768f:	48 89 d0             	mov    %rdx,%rax
    7692:	48 c1 e8 09          	shr    $0x9,%rax
    7696:	48 31 c2             	xor    %rax,%rdx
    7699:	0f b6 d2             	movzbl %dl,%edx
    769c:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    76a3:	00 
    76a4:	48 85 c0             	test   %rax,%rax
    76a7:	75 24                	jne    76cd <fwp_hof0.constprop.0+0x13fd>
    76a9:	e9 d2 01 00 00       	jmp    7880 <fwp_hof0.constprop.0+0x15b0>
    76ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76bc:	00 00 00 00 
    76c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76c4:	48 85 c0             	test   %rax,%rax
    76c7:	0f 84 b3 01 00 00    	je     7880 <fwp_hof0.constprop.0+0x15b0>
    76cd:	48 89 c2             	mov    %rax,%rdx
    76d0:	4c 3b 30             	cmp    (%rax),%r14
    76d3:	75 eb                	jne    76c0 <fwp_hof0.constprop.0+0x13f0>
    76d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    76d9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    76dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76e8:	0f 85 72 f9 ff ff    	jne    7060 <fwp_hof0.constprop.0+0xd90>
    76ee:	4c 89 f7             	mov    %r14,%rdi
    76f1:	e8 da c7 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    76f6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    76fa:	e9 61 f9 ff ff       	jmp    7060 <fwp_hof0.constprop.0+0xd90>
    76ff:	4c 89 e0             	mov    %r12,%rax
    7702:	48 c1 e8 11          	shr    $0x11,%rax
    7706:	4c 31 e0             	xor    %r12,%rax
    7709:	48 89 c2             	mov    %rax,%rdx
    770c:	48 c1 ea 09          	shr    $0x9,%rdx
    7710:	48 31 d0             	xor    %rdx,%rax
    7713:	0f b6 d0             	movzbl %al,%edx
    7716:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    771d:	00 
    771e:	48 85 c0             	test   %rax,%rax
    7721:	75 2a                	jne    774d <fwp_hof0.constprop.0+0x147d>
    7723:	e9 58 01 00 00       	jmp    7880 <fwp_hof0.constprop.0+0x15b0>
    7728:	66 90                	xchg   %ax,%ax
    772a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7731:	00 00 00 00 
    7735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    773c:	00 00 00 00 
    7740:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7744:	48 85 c0             	test   %rax,%rax
    7747:	0f 84 33 01 00 00    	je     7880 <fwp_hof0.constprop.0+0x15b0>
    774d:	48 89 c2             	mov    %rax,%rdx
    7750:	4c 3b 20             	cmp    (%rax),%r12
    7753:	75 eb                	jne    7740 <fwp_hof0.constprop.0+0x1470>
    7755:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7759:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    775d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7761:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7768:	0f 85 a2 f9 ff ff    	jne    7110 <fwp_hof0.constprop.0+0xe40>
    776e:	4c 89 e7             	mov    %r12,%rdi
    7771:	e8 5a c7 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7776:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    777b:	e9 90 f9 ff ff       	jmp    7110 <fwp_hof0.constprop.0+0xe40>
    7780:	4c 89 e1             	mov    %r12,%rcx
    7783:	48 c1 e9 11          	shr    $0x11,%rcx
    7787:	4c 31 e1             	xor    %r12,%rcx
    778a:	48 89 ca             	mov    %rcx,%rdx
    778d:	48 c1 ea 09          	shr    $0x9,%rdx
    7791:	48 31 d1             	xor    %rdx,%rcx
    7794:	0f b6 c9             	movzbl %cl,%ecx
    7797:	4c 8d ac cd 48 14 00 	lea    0x1448(%rbp,%rcx,8),%r13
    779e:	00 
    779f:	49 8b 55 00          	mov    0x0(%r13),%rdx
    77a3:	48 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%rbp,%rcx,8)
    77aa:	00 00 
    77ac:	75 1e                	jne    77cc <fwp_hof0.constprop.0+0x14fc>
    77ae:	e9 a1 00 00 00       	jmp    7854 <fwp_hof0.constprop.0+0x1584>
    77b3:	66 90                	xchg   %ax,%ax
    77b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77bc:	00 00 00 00 
    77c0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    77c4:	48 85 c9             	test   %rcx,%rcx
    77c7:	74 2b                	je     77f4 <fwp_hof0.constprop.0+0x1524>
    77c9:	48 89 ca             	mov    %rcx,%rdx
    77cc:	4c 39 22             	cmp    %r12,(%rdx)
    77cf:	75 ef                	jne    77c0 <fwp_hof0.constprop.0+0x14f0>
    77d1:	3c fe                	cmp    $0xfe,%al
    77d3:	0f 84 84 00 00 00    	je     785d <fwp_hof0.constprop.0+0x158d>
    77d9:	48 8b 42 08          	mov    0x8(%rdx),%rax
    77dd:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    77e1:	0f 84 b6 00 00 00    	je     789d <fwp_hof0.constprop.0+0x15cd>
    77e7:	48 83 c0 01          	add    $0x1,%rax
    77eb:	48 89 42 08          	mov    %rax,0x8(%rdx)
    77ef:	e9 a9 eb ff ff       	jmp    639d <fwp_hof0.constprop.0+0xcd>
    77f4:	3c fe                	cmp    $0xfe,%al
    77f6:	0f 85 84 00 00 00    	jne    7880 <fwp_hof0.constprop.0+0x15b0>
    77fc:	4c 8d 6a 10          	lea    0x10(%rdx),%r13
    7800:	bf 18 00 00 00       	mov    $0x18,%edi
    7805:	e8 76 ad ff ff       	call   2580 <malloc@plt>
    780a:	48 85 c0             	test   %rax,%rax
    780d:	0f 84 85 00 00 00    	je     7898 <fwp_hof0.constprop.0+0x15c8>
    7813:	4c 89 20             	mov    %r12,(%rax)
    7816:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    781d:	00 
    781e:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    7825:	00 
    7826:	49 89 45 00          	mov    %rax,0x0(%r13)
    782a:	41 c6 04 24 ff       	movb   $0xff,(%r12)
    782f:	48 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%rbp)
    7836:	01 
    7837:	e9 61 eb ff ff       	jmp    639d <fwp_hof0.constprop.0+0xcd>
    783c:	48 8d 3d ad 3b 00 00 	lea    0x3bad(%rip),%rdi        # b3f0 <_IO_stdin_used+0x3f0>
    7843:	e8 b8 b9 ff ff       	call   3200 <fwp_trap>
    7848:	48 8d 3d 96 38 00 00 	lea    0x3896(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    784f:	e8 ac b9 ff ff       	call   3200 <fwp_trap>
    7854:	3c fe                	cmp    $0xfe,%al
    7856:	75 18                	jne    7870 <fwp_hof0.constprop.0+0x15a0>
    7858:	48 85 d2             	test   %rdx,%rdx
    785b:	74 a3                	je     7800 <fwp_hof0.constprop.0+0x1530>
    785d:	48 8d 3d 64 3b 00 00 	lea    0x3b64(%rip),%rdi        # b3c8 <_IO_stdin_used+0x3c8>
    7864:	e8 97 b9 ff ff       	call   3200 <fwp_trap>
    7869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7870:	48 85 d2             	test   %rdx,%rdx
    7873:	0f 85 60 ff ff ff    	jne    77d9 <fwp_hof0.constprop.0+0x1509>
    7879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7880:	48 8d 3d 19 3b 00 00 	lea    0x3b19(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    7887:	e8 74 b9 ff ff       	call   3200 <fwp_trap>
    788c:	48 8d 3d 0a 39 00 00 	lea    0x390a(%rip),%rdi        # b19d <_IO_stdin_used+0x19d>
    7893:	e8 68 b9 ff ff       	call   3200 <fwp_trap>
    7898:	e8 53 b4 ff ff       	call   2cf0 <fwp_heap_oom>
    789d:	48 8d 3d e0 38 00 00 	lea    0x38e0(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    78a4:	e8 57 b9 ff ff       	call   3200 <fwp_trap>
    78a9:	e8 92 ab ff ff       	call   2440 <__stack_chk_fail@plt>
    78ae:	66 90                	xchg   %ax,%ax

00000000000078b0 <f0>:
    78b0:	41 56                	push   %r14
    78b2:	4c 8d 35 a7 6e 01 00 	lea    0x16ea7(%rip),%r14        # 1e760 <fwp_heap>
    78b9:	41 55                	push   %r13
    78bb:	41 54                	push   %r12
    78bd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    78c3:	55                   	push   %rbp
    78c4:	53                   	push   %rbx
    78c5:	31 db                	xor    %ebx,%ebx
    78c7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    78ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    78d5:	00 00 
    78d7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    78de:	00 
    78df:	31 c0                	xor    %eax,%eax
    78e1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    78e8:	00 
    78e9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    78f0:	00 00 
    78f2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    78f7:	48 8d 05 72 d8 ff ff 	lea    -0x278e(%rip),%rax        # 5170 <fwp_drop1>
    78fe:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7903:	48 8b 05 e6 8a 01 00 	mov    0x18ae6(%rip),%rax        # 203f0 <fwp_cleanups>
    790a:	48 89 25 df 8a 01 00 	mov    %rsp,0x18adf(%rip)        # 203f0 <fwp_cleanups>
    7911:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    7915:	48 89 04 24          	mov    %rax,(%rsp)
    7919:	48 8d 05 70 b2 ff ff 	lea    -0x4d90(%rip),%rax        # 2b90 <fwp_range_release>
    7920:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7925:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    792a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    792f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    7934:	eb 47                	jmp    797d <f0+0xcd>
    7936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    793d:	00 00 00 
    7940:	80 f9 01             	cmp    $0x1,%cl
    7943:	75 29                	jne    796e <f0+0xbe>
    7945:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7948:	0f b7 c0             	movzwl %ax,%eax
    794b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    794e:	48 0f af c1          	imul   %rcx,%rax
    7952:	48 c1 e8 20          	shr    $0x20,%rax
    7956:	48 39 d0             	cmp    %rdx,%rax
    7959:	73 13                	jae    796e <f0+0xbe>
    795b:	49 01 c5             	add    %rax,%r13
    795e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7963:	0f 84 c7 27 00 00    	je     a130 <f0+0x2880>
    7969:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    796e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7973:	49 83 ec 01          	sub    $0x1,%r12
    7977:	0f 82 83 00 00 00    	jb     7a00 <f0+0x150>
    797d:	48 89 ee             	mov    %rbp,%rsi
    7980:	bf 01 00 00 00       	mov    $0x1,%edi
    7985:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    798c:	00 
    798d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7992:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    7999:	00 
    799a:	e8 91 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    799f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    79a6:	48 89 c3             	mov    %rax,%rbx
    79a9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    79b0:	48 c1 e2 10          	shl    $0x10,%rdx
    79b4:	48 39 d0             	cmp    %rdx,%rax
    79b7:	73 b5                	jae    796e <f0+0xbe>
    79b9:	48 89 c2             	mov    %rax,%rdx
    79bc:	48 c1 ea 10          	shr    $0x10,%rdx
    79c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79c4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    79cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79cf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    79d3:	4d 85 ed             	test   %r13,%r13
    79d6:	74 96                	je     796e <f0+0xbe>
    79d8:	0f b6 0a             	movzbl (%rdx),%ecx
    79db:	80 f9 02             	cmp    $0x2,%cl
    79de:	0f 85 5c ff ff ff    	jne    7940 <f0+0x90>
    79e4:	66 85 c0             	test   %ax,%ax
    79e7:	0f 84 71 ff ff ff    	je     795e <f0+0xae>
    79ed:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    79f2:	49 83 ec 01          	sub    $0x1,%r12
    79f6:	73 85                	jae    797d <f0+0xcd>
    79f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    79ff:	00 
    7a00:	48 8b 04 24          	mov    (%rsp),%rax
    7a04:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    7a09:	bf 01 00 00 00       	mov    $0x1,%edi
    7a0e:	66 0f 6f 05 4a 3c 00 	movdqa 0x3c4a(%rip),%xmm0        # b660 <msg.3+0x90>
    7a15:	00 
    7a16:	48 89 05 d3 89 01 00 	mov    %rax,0x189d3(%rip)        # 203f0 <fwp_cleanups>
    7a1d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    7a22:	e8 09 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a27:	48 8b 15 0a 81 01 00 	mov    0x1810a(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7a2e:	49 89 c5             	mov    %rax,%r13
    7a31:	48 2b 05 d8 80 01 00 	sub    0x180d8(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7a38:	48 c1 e2 10          	shl    $0x10,%rdx
    7a3c:	48 39 d0             	cmp    %rdx,%rax
    7a3f:	73 59                	jae    7a9a <f0+0x1ea>
    7a41:	48 89 c2             	mov    %rax,%rdx
    7a44:	48 c1 ea 10          	shr    $0x10,%rdx
    7a48:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a4c:	48 8b 15 05 81 01 00 	mov    0x18105(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7a53:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a57:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7a5b:	4d 85 e4             	test   %r12,%r12
    7a5e:	74 3a                	je     7a9a <f0+0x1ea>
    7a60:	0f b6 0a             	movzbl (%rdx),%ecx
    7a63:	80 f9 02             	cmp    $0x2,%cl
    7a66:	0f 84 74 27 00 00    	je     a1e0 <f0+0x2930>
    7a6c:	80 f9 01             	cmp    $0x1,%cl
    7a6f:	75 29                	jne    7a9a <f0+0x1ea>
    7a71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a74:	0f b7 c0             	movzwl %ax,%eax
    7a77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a7a:	48 0f af c1          	imul   %rcx,%rax
    7a7e:	48 c1 e8 20          	shr    $0x20,%rax
    7a82:	48 39 d0             	cmp    %rdx,%rax
    7a85:	73 13                	jae    7a9a <f0+0x1ea>
    7a87:	49 01 c4             	add    %rax,%r12
    7a8a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7a8f:	0f 84 26 29 00 00    	je     a3bb <f0+0x2b0b>
    7a95:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7a9a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    7a9f:	bf 01 00 00 00       	mov    $0x1,%edi
    7aa4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    7aa9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    7ab0:	00 f0 3f 
    7ab3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    7ab8:	e8 73 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7abd:	48 8b 15 74 80 01 00 	mov    0x18074(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7ac4:	49 89 c5             	mov    %rax,%r13
    7ac7:	48 2b 05 42 80 01 00 	sub    0x18042(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7ace:	48 c1 e2 10          	shl    $0x10,%rdx
    7ad2:	48 39 d0             	cmp    %rdx,%rax
    7ad5:	73 59                	jae    7b30 <f0+0x280>
    7ad7:	48 89 c2             	mov    %rax,%rdx
    7ada:	48 c1 ea 10          	shr    $0x10,%rdx
    7ade:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ae2:	48 8b 15 6f 80 01 00 	mov    0x1806f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7ae9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7aed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7af1:	4d 85 e4             	test   %r12,%r12
    7af4:	74 3a                	je     7b30 <f0+0x280>
    7af6:	0f b6 0a             	movzbl (%rdx),%ecx
    7af9:	80 f9 02             	cmp    $0x2,%cl
    7afc:	0f 84 ce 26 00 00    	je     a1d0 <f0+0x2920>
    7b02:	80 f9 01             	cmp    $0x1,%cl
    7b05:	75 29                	jne    7b30 <f0+0x280>
    7b07:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b0a:	0f b7 c0             	movzwl %ax,%eax
    7b0d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b10:	48 0f af c1          	imul   %rcx,%rax
    7b14:	48 c1 e8 20          	shr    $0x20,%rax
    7b18:	48 39 d0             	cmp    %rdx,%rax
    7b1b:	73 13                	jae    7b30 <f0+0x280>
    7b1d:	49 01 c4             	add    %rax,%r12
    7b20:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7b25:	0f 84 9d 28 00 00    	je     a3c8 <f0+0x2b18>
    7b2b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7b30:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    7b35:	bf 01 00 00 00       	mov    $0x1,%edi
    7b3a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7b3f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    7b46:	33 f3 bf 
    7b49:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7b4e:	e8 dd cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b53:	48 8b 15 de 7f 01 00 	mov    0x17fde(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7b5a:	49 89 c5             	mov    %rax,%r13
    7b5d:	48 2b 05 ac 7f 01 00 	sub    0x17fac(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7b64:	48 c1 e2 10          	shl    $0x10,%rdx
    7b68:	48 39 d0             	cmp    %rdx,%rax
    7b6b:	73 59                	jae    7bc6 <f0+0x316>
    7b6d:	48 89 c2             	mov    %rax,%rdx
    7b70:	48 c1 ea 10          	shr    $0x10,%rdx
    7b74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b78:	48 8b 15 d9 7f 01 00 	mov    0x17fd9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7b7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b83:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7b87:	4d 85 e4             	test   %r12,%r12
    7b8a:	74 3a                	je     7bc6 <f0+0x316>
    7b8c:	0f b6 0a             	movzbl (%rdx),%ecx
    7b8f:	80 f9 02             	cmp    $0x2,%cl
    7b92:	0f 84 28 26 00 00    	je     a1c0 <f0+0x2910>
    7b98:	80 f9 01             	cmp    $0x1,%cl
    7b9b:	75 29                	jne    7bc6 <f0+0x316>
    7b9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ba0:	0f b7 c0             	movzwl %ax,%eax
    7ba3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ba6:	48 0f af c1          	imul   %rcx,%rax
    7baa:	48 c1 e8 20          	shr    $0x20,%rax
    7bae:	48 39 d0             	cmp    %rdx,%rax
    7bb1:	73 13                	jae    7bc6 <f0+0x316>
    7bb3:	49 01 c4             	add    %rax,%r12
    7bb6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7bbb:	0f 84 14 28 00 00    	je     a3d5 <f0+0x2b25>
    7bc1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7bc6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    7bcb:	bf 01 00 00 00       	mov    $0x1,%edi
    7bd0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    7bd5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    7bdc:	00 f0 3f 
    7bdf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7be4:	e8 47 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7be9:	48 8b 15 48 7f 01 00 	mov    0x17f48(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7bf0:	49 89 c5             	mov    %rax,%r13
    7bf3:	48 2b 05 16 7f 01 00 	sub    0x17f16(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7bfa:	48 c1 e2 10          	shl    $0x10,%rdx
    7bfe:	48 39 d0             	cmp    %rdx,%rax
    7c01:	73 59                	jae    7c5c <f0+0x3ac>
    7c03:	48 89 c2             	mov    %rax,%rdx
    7c06:	48 c1 ea 10          	shr    $0x10,%rdx
    7c0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c0e:	48 8b 15 43 7f 01 00 	mov    0x17f43(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7c15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c19:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7c1d:	4d 85 e4             	test   %r12,%r12
    7c20:	74 3a                	je     7c5c <f0+0x3ac>
    7c22:	0f b6 0a             	movzbl (%rdx),%ecx
    7c25:	80 f9 02             	cmp    $0x2,%cl
    7c28:	0f 84 f2 25 00 00    	je     a220 <f0+0x2970>
    7c2e:	80 f9 01             	cmp    $0x1,%cl
    7c31:	75 29                	jne    7c5c <f0+0x3ac>
    7c33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c36:	0f b7 c0             	movzwl %ax,%eax
    7c39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c3c:	48 0f af c1          	imul   %rcx,%rax
    7c40:	48 c1 e8 20          	shr    $0x20,%rax
    7c44:	48 39 d0             	cmp    %rdx,%rax
    7c47:	73 13                	jae    7c5c <f0+0x3ac>
    7c49:	49 01 c4             	add    %rax,%r12
    7c4c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7c51:	0f 84 8b 27 00 00    	je     a3e2 <f0+0x2b32>
    7c57:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7c5c:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    7c63:	33 f3 bf 
    7c66:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    7c6d:	00 
    7c6e:	bf 01 00 00 00       	mov    $0x1,%edi
    7c73:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    7c7a:	00 
    7c7b:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    7c82:	00 
    7c83:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    7c8a:	00 f0 3f 
    7c8d:	e8 9e cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c92:	48 89 c7             	mov    %rax,%rdi
    7c95:	e8 76 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c9a:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    7ca1:	00 
    7ca2:	bf 01 00 00 00       	mov    $0x1,%edi
    7ca7:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    7cae:	00 
    7caf:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    7cb6:	00 
    7cb7:	e8 74 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7cbc:	48 89 c7             	mov    %rax,%rdi
    7cbf:	e8 4c c9 ff ff       	call   4610 <fwp_rc_fresh>
    7cc4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    7ccb:	00 
    7ccc:	bf 01 00 00 00       	mov    $0x1,%edi
    7cd1:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    7cd8:	00 
    7cd9:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    7ce0:	00 
    7ce1:	e8 4a cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ce6:	48 89 c7             	mov    %rax,%rdi
    7ce9:	e8 22 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7cee:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    7cf5:	00 
    7cf6:	bf 01 00 00 00       	mov    $0x1,%edi
    7cfb:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    7d02:	00 
    7d03:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7d0a:	00 
    7d0b:	e8 20 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d10:	48 89 c7             	mov    %rax,%rdi
    7d13:	e8 f8 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d18:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    7d1f:	00 
    7d20:	bf 01 00 00 00       	mov    $0x1,%edi
    7d25:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    7d2c:	00 
    7d2d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7d34:	00 
    7d35:	e8 f6 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d3a:	48 89 c7             	mov    %rax,%rdi
    7d3d:	e8 ce c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d42:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    7d49:	00 
    7d4a:	bf 01 00 00 00       	mov    $0x1,%edi
    7d4f:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    7d56:	00 
    7d57:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7d5e:	00 
    7d5f:	e8 cc cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d64:	48 89 c7             	mov    %rax,%rdi
    7d67:	e8 a4 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d6c:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    7d73:	00 
    7d74:	bf 01 00 00 00       	mov    $0x1,%edi
    7d79:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    7d80:	00 
    7d81:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    7d88:	00 
    7d89:	e8 a2 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d8e:	48 89 c7             	mov    %rax,%rdi
    7d91:	e8 7a c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d96:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    7d9d:	00 
    7d9e:	bf 01 00 00 00       	mov    $0x1,%edi
    7da3:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    7daa:	00 
    7dab:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    7db2:	00 
    7db3:	e8 78 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7db8:	48 89 c7             	mov    %rax,%rdi
    7dbb:	e8 50 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7dc0:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    7dc7:	00 
    7dc8:	bf 01 00 00 00       	mov    $0x1,%edi
    7dcd:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    7dd4:	00 
    7dd5:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    7ddc:	00 
    7ddd:	e8 4e cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7de2:	48 89 c7             	mov    %rax,%rdi
    7de5:	e8 26 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7dea:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    7df1:	00 
    7df2:	bf 01 00 00 00       	mov    $0x1,%edi
    7df7:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7dfe:	00 
    7dff:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7e06:	00 
    7e07:	e8 24 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e0c:	48 89 c7             	mov    %rax,%rdi
    7e0f:	e8 fc c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e14:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    7e1b:	00 
    7e1c:	bf 01 00 00 00       	mov    $0x1,%edi
    7e21:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    7e28:	00 
    7e29:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7e30:	00 
    7e31:	e8 fa ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e36:	48 89 c7             	mov    %rax,%rdi
    7e39:	e8 d2 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e3e:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    7e45:	00 
    7e46:	bf 01 00 00 00       	mov    $0x1,%edi
    7e4b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    7e52:	00 
    7e53:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    7e5a:	00 
    7e5b:	e8 d0 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e60:	48 89 c7             	mov    %rax,%rdi
    7e63:	e8 a8 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e68:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    7e6f:	00 
    7e70:	bf 01 00 00 00       	mov    $0x1,%edi
    7e75:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    7e7c:	00 
    7e7d:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    7e84:	00 
    7e85:	e8 a6 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e8a:	48 89 c7             	mov    %rax,%rdi
    7e8d:	e8 7e c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e92:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    7e99:	00 
    7e9a:	bf 01 00 00 00       	mov    $0x1,%edi
    7e9f:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    7ea6:	00 
    7ea7:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    7eae:	00 
    7eaf:	e8 7c ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7eb4:	48 89 c7             	mov    %rax,%rdi
    7eb7:	e8 54 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ebc:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    7ec3:	00 
    7ec4:	bf 01 00 00 00       	mov    $0x1,%edi
    7ec9:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    7ed0:	00 
    7ed1:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    7ed8:	00 
    7ed9:	e8 52 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ede:	48 89 c7             	mov    %rax,%rdi
    7ee1:	e8 2a c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ee6:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    7eed:	00 
    7eee:	bf 01 00 00 00       	mov    $0x1,%edi
    7ef3:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    7efa:	00 
    7efb:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    7f02:	00 
    7f03:	e8 28 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f08:	48 89 c7             	mov    %rax,%rdi
    7f0b:	e8 00 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7f10:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    7f17:	00 
    7f18:	bf 01 00 00 00       	mov    $0x1,%edi
    7f1d:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    7f24:	00 
    7f25:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7f2c:	00 
    7f2d:	e8 fe c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f32:	48 89 c7             	mov    %rax,%rdi
    7f35:	e8 d6 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f3a:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    7f41:	00 
    7f42:	bf 01 00 00 00       	mov    $0x1,%edi
    7f47:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7f4e:	00 
    7f4f:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7f56:	00 
    7f57:	e8 d4 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f5c:	48 89 c7             	mov    %rax,%rdi
    7f5f:	e8 ac c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f64:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    7f6b:	00 
    7f6c:	bf 01 00 00 00       	mov    $0x1,%edi
    7f71:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    7f78:	00 
    7f79:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    7f80:	00 
    7f81:	e8 aa c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f86:	48 89 c7             	mov    %rax,%rdi
    7f89:	e8 82 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f8e:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    7f95:	00 
    7f96:	bf 01 00 00 00       	mov    $0x1,%edi
    7f9b:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    7fa2:	00 
    7fa3:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    7faa:	00 
    7fab:	e8 80 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fb0:	48 89 c7             	mov    %rax,%rdi
    7fb3:	e8 58 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fb8:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    7fbf:	00 
    7fc0:	bf 01 00 00 00       	mov    $0x1,%edi
    7fc5:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    7fcc:	00 
    7fcd:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    7fd4:	00 
    7fd5:	e8 56 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fda:	48 89 c7             	mov    %rax,%rdi
    7fdd:	e8 2e c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fe2:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    7fe9:	00 
    7fea:	bf 01 00 00 00       	mov    $0x1,%edi
    7fef:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    7ff6:	00 
    7ff7:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    7ffe:	00 
    7fff:	e8 2c c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8004:	48 89 c7             	mov    %rax,%rdi
    8007:	e8 04 c6 ff ff       	call   4610 <fwp_rc_fresh>
    800c:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    8013:	00 
    8014:	bf 01 00 00 00       	mov    $0x1,%edi
    8019:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    8020:	00 
    8021:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    8028:	00 
    8029:	e8 02 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    802e:	48 89 c7             	mov    %rax,%rdi
    8031:	e8 da c5 ff ff       	call   4610 <fwp_rc_fresh>
    8036:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    803d:	00 
    803e:	bf 01 00 00 00       	mov    $0x1,%edi
    8043:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    804a:	00 
    804b:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    8052:	00 
    8053:	e8 d8 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8058:	48 89 c7             	mov    %rax,%rdi
    805b:	e8 b0 c5 ff ff       	call   4610 <fwp_rc_fresh>
    8060:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    8067:	00 
    8068:	bf 01 00 00 00       	mov    $0x1,%edi
    806d:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    8074:	00 
    8075:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    807c:	00 
    807d:	e8 ae c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8082:	48 89 c7             	mov    %rax,%rdi
    8085:	e8 86 c5 ff ff       	call   4610 <fwp_rc_fresh>
    808a:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    8091:	00 
    8092:	bf 01 00 00 00       	mov    $0x1,%edi
    8097:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    809e:	00 
    809f:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    80a6:	00 
    80a7:	e8 84 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80ac:	48 89 c7             	mov    %rax,%rdi
    80af:	e8 5c c5 ff ff       	call   4610 <fwp_rc_fresh>
    80b4:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    80bb:	00 
    80bc:	bf 01 00 00 00       	mov    $0x1,%edi
    80c1:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    80c8:	00 
    80c9:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    80d0:	00 
    80d1:	e8 5a c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80d6:	48 89 c7             	mov    %rax,%rdi
    80d9:	e8 32 c5 ff ff       	call   4610 <fwp_rc_fresh>
    80de:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    80e5:	00 
    80e6:	bf 01 00 00 00       	mov    $0x1,%edi
    80eb:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    80f2:	00 
    80f3:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    80fa:	00 
    80fb:	e8 30 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8100:	48 89 c7             	mov    %rax,%rdi
    8103:	e8 08 c5 ff ff       	call   4610 <fwp_rc_fresh>
    8108:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    810f:	00 
    8110:	bf 01 00 00 00       	mov    $0x1,%edi
    8115:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    811c:	00 
    811d:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    8124:	00 
    8125:	e8 06 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    812a:	48 89 c7             	mov    %rax,%rdi
    812d:	e8 de c4 ff ff       	call   4610 <fwp_rc_fresh>
    8132:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    8139:	00 
    813a:	bf 01 00 00 00       	mov    $0x1,%edi
    813f:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    8146:	00 
    8147:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    814e:	00 
    814f:	e8 dc c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8154:	48 89 c7             	mov    %rax,%rdi
    8157:	e8 b4 c4 ff ff       	call   4610 <fwp_rc_fresh>
    815c:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    8163:	00 
    8164:	bf 01 00 00 00       	mov    $0x1,%edi
    8169:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    8170:	00 
    8171:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    8178:	00 
    8179:	e8 b2 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    817e:	48 89 c7             	mov    %rax,%rdi
    8181:	e8 8a c4 ff ff       	call   4610 <fwp_rc_fresh>
    8186:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    818d:	00 
    818e:	bf 01 00 00 00       	mov    $0x1,%edi
    8193:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    819a:	00 
    819b:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    81a2:	00 
    81a3:	e8 88 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81a8:	48 89 c7             	mov    %rax,%rdi
    81ab:	e8 60 c4 ff ff       	call   4610 <fwp_rc_fresh>
    81b0:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    81b7:	00 
    81b8:	bf 01 00 00 00       	mov    $0x1,%edi
    81bd:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    81c4:	00 
    81c5:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    81cc:	00 
    81cd:	e8 5e c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81d2:	48 89 c7             	mov    %rax,%rdi
    81d5:	e8 36 c4 ff ff       	call   4610 <fwp_rc_fresh>
    81da:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    81e1:	00 
    81e2:	bf 01 00 00 00       	mov    $0x1,%edi
    81e7:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    81ee:	00 
    81ef:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    81f6:	00 
    81f7:	e8 34 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81fc:	48 89 c7             	mov    %rax,%rdi
    81ff:	e8 0c c4 ff ff       	call   4610 <fwp_rc_fresh>
    8204:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    820b:	00 
    820c:	bf 01 00 00 00       	mov    $0x1,%edi
    8211:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    8218:	00 
    8219:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    8220:	00 
    8221:	e8 0a c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8226:	48 89 c7             	mov    %rax,%rdi
    8229:	e8 e2 c3 ff ff       	call   4610 <fwp_rc_fresh>
    822e:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    8235:	00 
    8236:	bf 01 00 00 00       	mov    $0x1,%edi
    823b:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    8242:	00 
    8243:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    824a:	00 
    824b:	e8 e0 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8250:	48 89 c7             	mov    %rax,%rdi
    8253:	e8 b8 c3 ff ff       	call   4610 <fwp_rc_fresh>
    8258:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    825f:	00 
    8260:	bf 01 00 00 00       	mov    $0x1,%edi
    8265:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    826c:	00 
    826d:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    8274:	00 
    8275:	e8 b6 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    827a:	48 89 c7             	mov    %rax,%rdi
    827d:	e8 8e c3 ff ff       	call   4610 <fwp_rc_fresh>
    8282:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    8289:	00 
    828a:	bf 01 00 00 00       	mov    $0x1,%edi
    828f:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    8296:	00 
    8297:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    829e:	00 
    829f:	e8 8c c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82a4:	48 89 c7             	mov    %rax,%rdi
    82a7:	e8 64 c3 ff ff       	call   4610 <fwp_rc_fresh>
    82ac:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    82b3:	00 
    82b4:	bf 01 00 00 00       	mov    $0x1,%edi
    82b9:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    82c0:	00 
    82c1:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    82c8:	00 
    82c9:	e8 62 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82ce:	48 89 c7             	mov    %rax,%rdi
    82d1:	e8 3a c3 ff ff       	call   4610 <fwp_rc_fresh>
    82d6:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    82dd:	00 
    82de:	bf 01 00 00 00       	mov    $0x1,%edi
    82e3:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    82ea:	00 
    82eb:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    82f2:	00 
    82f3:	e8 38 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82f8:	48 89 c7             	mov    %rax,%rdi
    82fb:	e8 10 c3 ff ff       	call   4610 <fwp_rc_fresh>
    8300:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    8307:	00 
    8308:	bf 01 00 00 00       	mov    $0x1,%edi
    830d:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    8314:	00 
    8315:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    831c:	00 
    831d:	e8 0e c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8322:	48 89 c7             	mov    %rax,%rdi
    8325:	e8 e6 c2 ff ff       	call   4610 <fwp_rc_fresh>
    832a:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    8331:	00 
    8332:	bf 01 00 00 00       	mov    $0x1,%edi
    8337:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    833e:	00 
    833f:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    8346:	00 
    8347:	e8 e4 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    834c:	48 89 c7             	mov    %rax,%rdi
    834f:	e8 bc c2 ff ff       	call   4610 <fwp_rc_fresh>
    8354:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    835b:	00 
    835c:	bf 01 00 00 00       	mov    $0x1,%edi
    8361:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    8368:	00 
    8369:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    8370:	00 
    8371:	e8 ba c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8376:	48 89 c7             	mov    %rax,%rdi
    8379:	e8 92 c2 ff ff       	call   4610 <fwp_rc_fresh>
    837e:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    8385:	00 
    8386:	bf 01 00 00 00       	mov    $0x1,%edi
    838b:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    8392:	00 
    8393:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    839a:	00 
    839b:	e8 90 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    83a0:	48 89 c7             	mov    %rax,%rdi
    83a3:	e8 68 c2 ff ff       	call   4610 <fwp_rc_fresh>
    83a8:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    83af:	00 
    83b0:	bf 01 00 00 00       	mov    $0x1,%edi
    83b5:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    83bc:	00 
    83bd:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    83c4:	00 
    83c5:	e8 66 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    83ca:	48 89 c7             	mov    %rax,%rdi
    83cd:	e8 3e c2 ff ff       	call   4610 <fwp_rc_fresh>
    83d2:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    83d9:	00 
    83da:	bf 01 00 00 00       	mov    $0x1,%edi
    83df:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    83e6:	00 
    83e7:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    83ee:	00 
    83ef:	e8 3c c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    83f4:	48 89 c7             	mov    %rax,%rdi
    83f7:	e8 14 c2 ff ff       	call   4610 <fwp_rc_fresh>
    83fc:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    8403:	00 
    8404:	bf 01 00 00 00       	mov    $0x1,%edi
    8409:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    8410:	00 
    8411:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    8418:	00 
    8419:	e8 12 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    841e:	48 89 c7             	mov    %rax,%rdi
    8421:	e8 ea c1 ff ff       	call   4610 <fwp_rc_fresh>
    8426:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    842d:	00 
    842e:	bf 01 00 00 00       	mov    $0x1,%edi
    8433:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    843a:	00 
    843b:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    8442:	00 
    8443:	e8 e8 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8448:	48 89 c7             	mov    %rax,%rdi
    844b:	e8 c0 c1 ff ff       	call   4610 <fwp_rc_fresh>
    8450:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    8457:	00 
    8458:	bf 01 00 00 00       	mov    $0x1,%edi
    845d:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    8464:	00 
    8465:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    846c:	00 
    846d:	e8 be c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8472:	48 89 c7             	mov    %rax,%rdi
    8475:	e8 96 c1 ff ff       	call   4610 <fwp_rc_fresh>
    847a:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    8481:	00 
    8482:	bf 01 00 00 00       	mov    $0x1,%edi
    8487:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    848e:	00 
    848f:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    8496:	00 
    8497:	e8 94 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    849c:	48 89 c7             	mov    %rax,%rdi
    849f:	e8 6c c1 ff ff       	call   4610 <fwp_rc_fresh>
    84a4:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    84ab:	00 
    84ac:	bf 01 00 00 00       	mov    $0x1,%edi
    84b1:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    84b8:	00 
    84b9:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    84c0:	00 
    84c1:	e8 6a c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    84c6:	48 89 c7             	mov    %rax,%rdi
    84c9:	e8 42 c1 ff ff       	call   4610 <fwp_rc_fresh>
    84ce:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    84d5:	00 
    84d6:	bf 01 00 00 00       	mov    $0x1,%edi
    84db:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    84e2:	00 
    84e3:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    84ea:	00 
    84eb:	e8 40 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    84f0:	48 89 c7             	mov    %rax,%rdi
    84f3:	e8 18 c1 ff ff       	call   4610 <fwp_rc_fresh>
    84f8:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    84ff:	00 
    8500:	bf 01 00 00 00       	mov    $0x1,%edi
    8505:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    850c:	00 
    850d:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    8514:	00 
    8515:	e8 16 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    851a:	48 89 c7             	mov    %rax,%rdi
    851d:	e8 ee c0 ff ff       	call   4610 <fwp_rc_fresh>
    8522:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    8529:	00 
    852a:	bf 01 00 00 00       	mov    $0x1,%edi
    852f:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    8536:	00 
    8537:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    853e:	00 
    853f:	e8 ec c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8544:	48 89 c7             	mov    %rax,%rdi
    8547:	e8 c4 c0 ff ff       	call   4610 <fwp_rc_fresh>
    854c:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    8553:	00 
    8554:	bf 01 00 00 00       	mov    $0x1,%edi
    8559:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    8560:	00 
    8561:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    8568:	00 
    8569:	e8 c2 c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    856e:	48 89 c7             	mov    %rax,%rdi
    8571:	e8 9a c0 ff ff       	call   4610 <fwp_rc_fresh>
    8576:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    857d:	00 
    857e:	bf 01 00 00 00       	mov    $0x1,%edi
    8583:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    858a:	00 
    858b:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    8592:	00 
    8593:	e8 98 c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8598:	48 89 c7             	mov    %rax,%rdi
    859b:	e8 70 c0 ff ff       	call   4610 <fwp_rc_fresh>
    85a0:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    85a7:	00 
    85a8:	bf 01 00 00 00       	mov    $0x1,%edi
    85ad:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    85b4:	00 
    85b5:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    85bc:	00 
    85bd:	e8 6e c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    85c2:	48 89 c7             	mov    %rax,%rdi
    85c5:	e8 46 c0 ff ff       	call   4610 <fwp_rc_fresh>
    85ca:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    85d1:	00 
    85d2:	bf 01 00 00 00       	mov    $0x1,%edi
    85d7:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    85de:	00 
    85df:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    85e6:	00 
    85e7:	e8 44 c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    85ec:	48 89 c7             	mov    %rax,%rdi
    85ef:	e8 1c c0 ff ff       	call   4610 <fwp_rc_fresh>
    85f4:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    85fb:	00 
    85fc:	bf 01 00 00 00       	mov    $0x1,%edi
    8601:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    8608:	00 
    8609:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    8610:	00 
    8611:	e8 1a c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8616:	48 89 c7             	mov    %rax,%rdi
    8619:	e8 f2 bf ff ff       	call   4610 <fwp_rc_fresh>
    861e:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    8625:	00 
    8626:	bf 01 00 00 00       	mov    $0x1,%edi
    862b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    8632:	00 
    8633:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    863a:	00 
    863b:	e8 f0 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8640:	48 89 c7             	mov    %rax,%rdi
    8643:	e8 c8 bf ff ff       	call   4610 <fwp_rc_fresh>
    8648:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    864f:	00 
    8650:	bf 01 00 00 00       	mov    $0x1,%edi
    8655:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    865c:	00 
    865d:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    8664:	00 
    8665:	e8 c6 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    866a:	48 89 c7             	mov    %rax,%rdi
    866d:	e8 9e bf ff ff       	call   4610 <fwp_rc_fresh>
    8672:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    8679:	00 
    867a:	bf 01 00 00 00       	mov    $0x1,%edi
    867f:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    8686:	00 
    8687:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    868e:	00 
    868f:	e8 9c c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8694:	48 89 c7             	mov    %rax,%rdi
    8697:	e8 74 bf ff ff       	call   4610 <fwp_rc_fresh>
    869c:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    86a3:	00 
    86a4:	bf 01 00 00 00       	mov    $0x1,%edi
    86a9:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    86b0:	00 
    86b1:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    86b8:	00 
    86b9:	e8 72 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    86be:	48 89 c7             	mov    %rax,%rdi
    86c1:	e8 4a bf ff ff       	call   4610 <fwp_rc_fresh>
    86c6:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    86cd:	00 
    86ce:	bf 01 00 00 00       	mov    $0x1,%edi
    86d3:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    86da:	00 
    86db:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    86e2:	00 
    86e3:	e8 48 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    86e8:	48 89 c7             	mov    %rax,%rdi
    86eb:	e8 20 bf ff ff       	call   4610 <fwp_rc_fresh>
    86f0:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    86f7:	00 
    86f8:	bf 01 00 00 00       	mov    $0x1,%edi
    86fd:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    8704:	00 
    8705:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    870c:	00 
    870d:	e8 1e c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8712:	48 89 c7             	mov    %rax,%rdi
    8715:	e8 f6 be ff ff       	call   4610 <fwp_rc_fresh>
    871a:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    8721:	00 
    8722:	bf 01 00 00 00       	mov    $0x1,%edi
    8727:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    872e:	00 
    872f:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    8736:	00 
    8737:	e8 f4 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    873c:	48 89 c7             	mov    %rax,%rdi
    873f:	e8 cc be ff ff       	call   4610 <fwp_rc_fresh>
    8744:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    874b:	00 
    874c:	bf 01 00 00 00       	mov    $0x1,%edi
    8751:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    8758:	00 
    8759:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    8760:	00 
    8761:	e8 ca c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8766:	48 89 c7             	mov    %rax,%rdi
    8769:	e8 a2 be ff ff       	call   4610 <fwp_rc_fresh>
    876e:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    8775:	00 
    8776:	bf 01 00 00 00       	mov    $0x1,%edi
    877b:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    8782:	00 
    8783:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    878a:	00 
    878b:	e8 a0 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8790:	48 89 c7             	mov    %rax,%rdi
    8793:	e8 78 be ff ff       	call   4610 <fwp_rc_fresh>
    8798:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    879f:	00 
    87a0:	bf 01 00 00 00       	mov    $0x1,%edi
    87a5:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    87ac:	00 
    87ad:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    87b4:	00 
    87b5:	e8 76 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    87ba:	48 89 c7             	mov    %rax,%rdi
    87bd:	e8 4e be ff ff       	call   4610 <fwp_rc_fresh>
    87c2:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    87c9:	00 
    87ca:	bf 01 00 00 00       	mov    $0x1,%edi
    87cf:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    87d6:	00 
    87d7:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    87de:	00 
    87df:	e8 4c c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    87e4:	48 89 c7             	mov    %rax,%rdi
    87e7:	e8 24 be ff ff       	call   4610 <fwp_rc_fresh>
    87ec:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    87f3:	00 
    87f4:	bf 01 00 00 00       	mov    $0x1,%edi
    87f9:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    8800:	00 
    8801:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    8808:	00 
    8809:	e8 22 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    880e:	48 89 c7             	mov    %rax,%rdi
    8811:	e8 fa bd ff ff       	call   4610 <fwp_rc_fresh>
    8816:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    881d:	00 
    881e:	bf 01 00 00 00       	mov    $0x1,%edi
    8823:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    882a:	00 
    882b:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    8832:	00 
    8833:	e8 f8 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8838:	48 89 c7             	mov    %rax,%rdi
    883b:	e8 d0 bd ff ff       	call   4610 <fwp_rc_fresh>
    8840:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    8847:	00 
    8848:	bf 01 00 00 00       	mov    $0x1,%edi
    884d:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    8854:	00 
    8855:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    885c:	00 
    885d:	e8 ce c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8862:	48 89 c7             	mov    %rax,%rdi
    8865:	e8 a6 bd ff ff       	call   4610 <fwp_rc_fresh>
    886a:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    8871:	00 
    8872:	bf 01 00 00 00       	mov    $0x1,%edi
    8877:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    887e:	00 
    887f:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    8886:	00 
    8887:	e8 a4 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    888c:	48 89 c7             	mov    %rax,%rdi
    888f:	e8 7c bd ff ff       	call   4610 <fwp_rc_fresh>
    8894:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    889b:	00 
    889c:	bf 01 00 00 00       	mov    $0x1,%edi
    88a1:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    88a8:	00 
    88a9:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    88b0:	00 
    88b1:	e8 7a c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    88b6:	48 89 c7             	mov    %rax,%rdi
    88b9:	e8 52 bd ff ff       	call   4610 <fwp_rc_fresh>
    88be:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    88c5:	00 
    88c6:	bf 01 00 00 00       	mov    $0x1,%edi
    88cb:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    88d2:	00 
    88d3:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    88da:	00 
    88db:	e8 50 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    88e0:	48 89 c7             	mov    %rax,%rdi
    88e3:	e8 28 bd ff ff       	call   4610 <fwp_rc_fresh>
    88e8:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    88ef:	00 
    88f0:	bf 01 00 00 00       	mov    $0x1,%edi
    88f5:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    88fc:	00 
    88fd:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    8904:	00 
    8905:	e8 26 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    890a:	48 89 c7             	mov    %rax,%rdi
    890d:	e8 fe bc ff ff       	call   4610 <fwp_rc_fresh>
    8912:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    8919:	00 
    891a:	bf 01 00 00 00       	mov    $0x1,%edi
    891f:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    8926:	00 
    8927:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    892e:	00 
    892f:	e8 fc bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8934:	48 89 c7             	mov    %rax,%rdi
    8937:	e8 d4 bc ff ff       	call   4610 <fwp_rc_fresh>
    893c:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    8943:	00 
    8944:	bf 01 00 00 00       	mov    $0x1,%edi
    8949:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    8950:	00 
    8951:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    8958:	00 
    8959:	e8 d2 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    895e:	48 89 c7             	mov    %rax,%rdi
    8961:	e8 aa bc ff ff       	call   4610 <fwp_rc_fresh>
    8966:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    896d:	00 
    896e:	bf 01 00 00 00       	mov    $0x1,%edi
    8973:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    897a:	00 
    897b:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    8982:	00 
    8983:	e8 a8 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8988:	48 89 c7             	mov    %rax,%rdi
    898b:	e8 80 bc ff ff       	call   4610 <fwp_rc_fresh>
    8990:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    8997:	00 
    8998:	bf 01 00 00 00       	mov    $0x1,%edi
    899d:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    89a4:	00 
    89a5:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    89ac:	00 
    89ad:	e8 7e bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    89b2:	48 89 c7             	mov    %rax,%rdi
    89b5:	e8 56 bc ff ff       	call   4610 <fwp_rc_fresh>
    89ba:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    89c1:	00 
    89c2:	bf 01 00 00 00       	mov    $0x1,%edi
    89c7:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    89ce:	00 
    89cf:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    89d6:	00 
    89d7:	e8 54 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    89dc:	48 89 c7             	mov    %rax,%rdi
    89df:	e8 2c bc ff ff       	call   4610 <fwp_rc_fresh>
    89e4:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    89eb:	00 
    89ec:	bf 01 00 00 00       	mov    $0x1,%edi
    89f1:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    89f8:	00 
    89f9:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    8a00:	00 
    8a01:	e8 2a bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a06:	48 89 c7             	mov    %rax,%rdi
    8a09:	e8 02 bc ff ff       	call   4610 <fwp_rc_fresh>
    8a0e:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    8a15:	00 
    8a16:	bf 01 00 00 00       	mov    $0x1,%edi
    8a1b:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    8a22:	00 
    8a23:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    8a2a:	00 
    8a2b:	e8 00 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a30:	48 89 c7             	mov    %rax,%rdi
    8a33:	e8 d8 bb ff ff       	call   4610 <fwp_rc_fresh>
    8a38:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    8a3f:	00 
    8a40:	bf 01 00 00 00       	mov    $0x1,%edi
    8a45:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    8a4c:	00 
    8a4d:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    8a54:	00 
    8a55:	e8 d6 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a5a:	48 89 c7             	mov    %rax,%rdi
    8a5d:	e8 ae bb ff ff       	call   4610 <fwp_rc_fresh>
    8a62:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    8a69:	00 
    8a6a:	bf 01 00 00 00       	mov    $0x1,%edi
    8a6f:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    8a76:	00 
    8a77:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    8a7e:	00 
    8a7f:	e8 ac be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a84:	48 89 c7             	mov    %rax,%rdi
    8a87:	e8 84 bb ff ff       	call   4610 <fwp_rc_fresh>
    8a8c:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    8a93:	00 
    8a94:	bf 01 00 00 00       	mov    $0x1,%edi
    8a99:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    8aa0:	00 
    8aa1:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    8aa8:	00 
    8aa9:	e8 82 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8aae:	48 89 c7             	mov    %rax,%rdi
    8ab1:	e8 5a bb ff ff       	call   4610 <fwp_rc_fresh>
    8ab6:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    8abd:	00 
    8abe:	bf 01 00 00 00       	mov    $0x1,%edi
    8ac3:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    8aca:	00 
    8acb:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    8ad2:	00 
    8ad3:	e8 58 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8ad8:	48 89 c7             	mov    %rax,%rdi
    8adb:	e8 30 bb ff ff       	call   4610 <fwp_rc_fresh>
    8ae0:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    8ae7:	00 
    8ae8:	bf 01 00 00 00       	mov    $0x1,%edi
    8aed:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    8af4:	00 
    8af5:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    8afc:	00 
    8afd:	e8 2e be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8b02:	48 89 c7             	mov    %rax,%rdi
    8b05:	e8 06 bb ff ff       	call   4610 <fwp_rc_fresh>
    8b0a:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    8b11:	00 
    8b12:	bf 01 00 00 00       	mov    $0x1,%edi
    8b17:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    8b1e:	00 
    8b1f:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    8b26:	00 
    8b27:	e8 04 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8b2c:	48 89 c7             	mov    %rax,%rdi
    8b2f:	e8 dc ba ff ff       	call   4610 <fwp_rc_fresh>
    8b34:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    8b3b:	00 
    8b3c:	bf 01 00 00 00       	mov    $0x1,%edi
    8b41:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    8b48:	00 
    8b49:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    8b50:	00 
    8b51:	e8 da bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8b56:	48 8b 15 db 6f 01 00 	mov    0x16fdb(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8b5d:	49 89 c5             	mov    %rax,%r13
    8b60:	48 2b 05 a9 6f 01 00 	sub    0x16fa9(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8b67:	48 c1 e2 10          	shl    $0x10,%rdx
    8b6b:	48 39 d0             	cmp    %rdx,%rax
    8b6e:	73 59                	jae    8bc9 <f0+0x1319>
    8b70:	48 89 c2             	mov    %rax,%rdx
    8b73:	48 c1 ea 10          	shr    $0x10,%rdx
    8b77:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b7b:	48 8b 15 d6 6f 01 00 	mov    0x16fd6(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8b82:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b86:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b8a:	4d 85 e4             	test   %r12,%r12
    8b8d:	74 3a                	je     8bc9 <f0+0x1319>
    8b8f:	0f b6 0a             	movzbl (%rdx),%ecx
    8b92:	80 f9 02             	cmp    $0x2,%cl
    8b95:	0f 84 75 16 00 00    	je     a210 <f0+0x2960>
    8b9b:	80 f9 01             	cmp    $0x1,%cl
    8b9e:	75 29                	jne    8bc9 <f0+0x1319>
    8ba0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ba3:	0f b7 c0             	movzwl %ax,%eax
    8ba6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ba9:	48 0f af c1          	imul   %rcx,%rax
    8bad:	48 c1 e8 20          	shr    $0x20,%rax
    8bb1:	48 39 d0             	cmp    %rdx,%rax
    8bb4:	73 13                	jae    8bc9 <f0+0x1319>
    8bb6:	49 01 c4             	add    %rax,%r12
    8bb9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8bbe:	0f 84 2b 18 00 00    	je     a3ef <f0+0x2b3f>
    8bc4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8bc9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8bd0:	00 f0 3f 
    8bd3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    8bda:	00 
    8bdb:	bf 01 00 00 00       	mov    $0x1,%edi
    8be0:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    8be7:	00 
    8be8:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    8bef:	00 
    8bf0:	e8 3b bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8bf5:	48 8b 15 3c 6f 01 00 	mov    0x16f3c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8bfc:	49 89 c5             	mov    %rax,%r13
    8bff:	48 2b 05 0a 6f 01 00 	sub    0x16f0a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8c06:	48 c1 e2 10          	shl    $0x10,%rdx
    8c0a:	48 39 d0             	cmp    %rdx,%rax
    8c0d:	73 59                	jae    8c68 <f0+0x13b8>
    8c0f:	48 89 c2             	mov    %rax,%rdx
    8c12:	48 c1 ea 10          	shr    $0x10,%rdx
    8c16:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c1a:	48 8b 15 37 6f 01 00 	mov    0x16f37(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8c21:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c25:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c29:	4d 85 e4             	test   %r12,%r12
    8c2c:	74 3a                	je     8c68 <f0+0x13b8>
    8c2e:	0f b6 0a             	movzbl (%rdx),%ecx
    8c31:	80 f9 02             	cmp    $0x2,%cl
    8c34:	0f 84 c6 15 00 00    	je     a200 <f0+0x2950>
    8c3a:	80 f9 01             	cmp    $0x1,%cl
    8c3d:	75 29                	jne    8c68 <f0+0x13b8>
    8c3f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c42:	0f b7 c0             	movzwl %ax,%eax
    8c45:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c48:	48 0f af c1          	imul   %rcx,%rax
    8c4c:	48 c1 e8 20          	shr    $0x20,%rax
    8c50:	48 39 d0             	cmp    %rdx,%rax
    8c53:	73 13                	jae    8c68 <f0+0x13b8>
    8c55:	49 01 c4             	add    %rax,%r12
    8c58:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c5d:	0f 84 99 17 00 00    	je     a3fc <f0+0x2b4c>
    8c63:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c68:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8c6f:	33 f3 bf 
    8c72:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    8c79:	00 
    8c7a:	bf 01 00 00 00       	mov    $0x1,%edi
    8c7f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    8c86:	00 
    8c87:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    8c8e:	00 
    8c8f:	e8 9c bc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8c94:	48 8b 15 9d 6e 01 00 	mov    0x16e9d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8c9b:	49 89 c5             	mov    %rax,%r13
    8c9e:	48 2b 05 6b 6e 01 00 	sub    0x16e6b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8ca5:	48 c1 e2 10          	shl    $0x10,%rdx
    8ca9:	48 39 d0             	cmp    %rdx,%rax
    8cac:	73 59                	jae    8d07 <f0+0x1457>
    8cae:	48 89 c2             	mov    %rax,%rdx
    8cb1:	48 c1 ea 10          	shr    $0x10,%rdx
    8cb5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cb9:	48 8b 15 98 6e 01 00 	mov    0x16e98(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8cc0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8cc4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8cc8:	4d 85 e4             	test   %r12,%r12
    8ccb:	74 3a                	je     8d07 <f0+0x1457>
    8ccd:	0f b6 0a             	movzbl (%rdx),%ecx
    8cd0:	80 f9 02             	cmp    $0x2,%cl
    8cd3:	0f 84 17 15 00 00    	je     a1f0 <f0+0x2940>
    8cd9:	80 f9 01             	cmp    $0x1,%cl
    8cdc:	75 29                	jne    8d07 <f0+0x1457>
    8cde:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ce1:	0f b7 c0             	movzwl %ax,%eax
    8ce4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ce7:	48 0f af c1          	imul   %rcx,%rax
    8ceb:	48 c1 e8 20          	shr    $0x20,%rax
    8cef:	48 39 d0             	cmp    %rdx,%rax
    8cf2:	73 13                	jae    8d07 <f0+0x1457>
    8cf4:	49 01 c4             	add    %rax,%r12
    8cf7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8cfc:	0f 84 07 17 00 00    	je     a409 <f0+0x2b59>
    8d02:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d07:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8d0e:	00 f0 3f 
    8d11:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    8d18:	00 
    8d19:	bf 01 00 00 00       	mov    $0x1,%edi
    8d1e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    8d25:	00 
    8d26:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    8d2d:	00 
    8d2e:	e8 fd bb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8d33:	48 8b 15 fe 6d 01 00 	mov    0x16dfe(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8d3a:	49 89 c5             	mov    %rax,%r13
    8d3d:	48 2b 05 cc 6d 01 00 	sub    0x16dcc(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8d44:	48 c1 e2 10          	shl    $0x10,%rdx
    8d48:	48 39 d0             	cmp    %rdx,%rax
    8d4b:	73 59                	jae    8da6 <f0+0x14f6>
    8d4d:	48 89 c2             	mov    %rax,%rdx
    8d50:	48 c1 ea 10          	shr    $0x10,%rdx
    8d54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d58:	48 8b 15 f9 6d 01 00 	mov    0x16df9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8d5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d63:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d67:	4d 85 e4             	test   %r12,%r12
    8d6a:	74 3a                	je     8da6 <f0+0x14f6>
    8d6c:	0f b6 0a             	movzbl (%rdx),%ecx
    8d6f:	80 f9 02             	cmp    $0x2,%cl
    8d72:	0f 84 28 15 00 00    	je     a2a0 <f0+0x29f0>
    8d78:	80 f9 01             	cmp    $0x1,%cl
    8d7b:	75 29                	jne    8da6 <f0+0x14f6>
    8d7d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d80:	0f b7 c0             	movzwl %ax,%eax
    8d83:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d86:	48 0f af c1          	imul   %rcx,%rax
    8d8a:	48 c1 e8 20          	shr    $0x20,%rax
    8d8e:	48 39 d0             	cmp    %rdx,%rax
    8d91:	73 13                	jae    8da6 <f0+0x14f6>
    8d93:	49 01 c4             	add    %rax,%r12
    8d96:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d9b:	0f 84 75 16 00 00    	je     a416 <f0+0x2b66>
    8da1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8da6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8dad:	33 f3 bf 
    8db0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    8db7:	00 
    8db8:	bf 01 00 00 00       	mov    $0x1,%edi
    8dbd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    8dc4:	00 
    8dc5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    8dcc:	00 
    8dcd:	e8 5e bb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8dd2:	48 8b 15 5f 6d 01 00 	mov    0x16d5f(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8dd9:	49 89 c5             	mov    %rax,%r13
    8ddc:	48 2b 05 2d 6d 01 00 	sub    0x16d2d(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8de3:	48 c1 e2 10          	shl    $0x10,%rdx
    8de7:	48 39 d0             	cmp    %rdx,%rax
    8dea:	73 59                	jae    8e45 <f0+0x1595>
    8dec:	48 89 c2             	mov    %rax,%rdx
    8def:	48 c1 ea 10          	shr    $0x10,%rdx
    8df3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8df7:	48 8b 15 5a 6d 01 00 	mov    0x16d5a(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8dfe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e02:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e06:	4d 85 e4             	test   %r12,%r12
    8e09:	74 3a                	je     8e45 <f0+0x1595>
    8e0b:	0f b6 0a             	movzbl (%rdx),%ecx
    8e0e:	80 f9 02             	cmp    $0x2,%cl
    8e11:	0f 84 79 14 00 00    	je     a290 <f0+0x29e0>
    8e17:	80 f9 01             	cmp    $0x1,%cl
    8e1a:	75 29                	jne    8e45 <f0+0x1595>
    8e1c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e1f:	0f b7 c0             	movzwl %ax,%eax
    8e22:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e25:	48 0f af c1          	imul   %rcx,%rax
    8e29:	48 c1 e8 20          	shr    $0x20,%rax
    8e2d:	48 39 d0             	cmp    %rdx,%rax
    8e30:	73 13                	jae    8e45 <f0+0x1595>
    8e32:	49 01 c4             	add    %rax,%r12
    8e35:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e3a:	0f 84 e3 15 00 00    	je     a423 <f0+0x2b73>
    8e40:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e45:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8e4c:	00 f0 3f 
    8e4f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    8e56:	00 
    8e57:	bf 01 00 00 00       	mov    $0x1,%edi
    8e5c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    8e63:	00 
    8e64:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    8e6b:	00 
    8e6c:	e8 bf ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8e71:	48 8b 15 c0 6c 01 00 	mov    0x16cc0(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8e78:	49 89 c5             	mov    %rax,%r13
    8e7b:	48 2b 05 8e 6c 01 00 	sub    0x16c8e(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8e82:	48 c1 e2 10          	shl    $0x10,%rdx
    8e86:	48 39 d0             	cmp    %rdx,%rax
    8e89:	73 59                	jae    8ee4 <f0+0x1634>
    8e8b:	48 89 c2             	mov    %rax,%rdx
    8e8e:	48 c1 ea 10          	shr    $0x10,%rdx
    8e92:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e96:	48 8b 15 bb 6c 01 00 	mov    0x16cbb(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8e9d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ea1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ea5:	4d 85 e4             	test   %r12,%r12
    8ea8:	74 3a                	je     8ee4 <f0+0x1634>
    8eaa:	0f b6 0a             	movzbl (%rdx),%ecx
    8ead:	80 f9 02             	cmp    $0x2,%cl
    8eb0:	0f 84 ca 13 00 00    	je     a280 <f0+0x29d0>
    8eb6:	80 f9 01             	cmp    $0x1,%cl
    8eb9:	75 29                	jne    8ee4 <f0+0x1634>
    8ebb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ebe:	0f b7 c0             	movzwl %ax,%eax
    8ec1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ec4:	48 0f af c1          	imul   %rcx,%rax
    8ec8:	48 c1 e8 20          	shr    $0x20,%rax
    8ecc:	48 39 d0             	cmp    %rdx,%rax
    8ecf:	73 13                	jae    8ee4 <f0+0x1634>
    8ed1:	49 01 c4             	add    %rax,%r12
    8ed4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ed9:	0f 84 51 15 00 00    	je     a430 <f0+0x2b80>
    8edf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8ee4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8eeb:	33 f3 bf 
    8eee:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    8ef5:	00 
    8ef6:	bf 01 00 00 00       	mov    $0x1,%edi
    8efb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    8f02:	00 
    8f03:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    8f0a:	00 
    8f0b:	e8 20 ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8f10:	48 8b 15 21 6c 01 00 	mov    0x16c21(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8f17:	49 89 c5             	mov    %rax,%r13
    8f1a:	48 2b 05 ef 6b 01 00 	sub    0x16bef(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8f21:	48 c1 e2 10          	shl    $0x10,%rdx
    8f25:	48 39 d0             	cmp    %rdx,%rax
    8f28:	73 59                	jae    8f83 <f0+0x16d3>
    8f2a:	48 89 c2             	mov    %rax,%rdx
    8f2d:	48 c1 ea 10          	shr    $0x10,%rdx
    8f31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f35:	48 8b 15 1c 6c 01 00 	mov    0x16c1c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8f3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f40:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f44:	4d 85 e4             	test   %r12,%r12
    8f47:	74 3a                	je     8f83 <f0+0x16d3>
    8f49:	0f b6 0a             	movzbl (%rdx),%ecx
    8f4c:	80 f9 02             	cmp    $0x2,%cl
    8f4f:	0f 84 1b 13 00 00    	je     a270 <f0+0x29c0>
    8f55:	80 f9 01             	cmp    $0x1,%cl
    8f58:	75 29                	jne    8f83 <f0+0x16d3>
    8f5a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f5d:	0f b7 c0             	movzwl %ax,%eax
    8f60:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f63:	48 0f af c1          	imul   %rcx,%rax
    8f67:	48 c1 e8 20          	shr    $0x20,%rax
    8f6b:	48 39 d0             	cmp    %rdx,%rax
    8f6e:	73 13                	jae    8f83 <f0+0x16d3>
    8f70:	49 01 c4             	add    %rax,%r12
    8f73:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f78:	0f 84 bf 14 00 00    	je     a43d <f0+0x2b8d>
    8f7e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f83:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8f8a:	00 f0 3f 
    8f8d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    8f94:	00 
    8f95:	bf 01 00 00 00       	mov    $0x1,%edi
    8f9a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    8fa1:	00 
    8fa2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    8fa9:	00 
    8faa:	e8 81 b9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8faf:	48 8b 15 82 6b 01 00 	mov    0x16b82(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8fb6:	49 89 c5             	mov    %rax,%r13
    8fb9:	48 2b 05 50 6b 01 00 	sub    0x16b50(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8fc0:	48 c1 e2 10          	shl    $0x10,%rdx
    8fc4:	48 39 d0             	cmp    %rdx,%rax
    8fc7:	73 59                	jae    9022 <f0+0x1772>
    8fc9:	48 89 c2             	mov    %rax,%rdx
    8fcc:	48 c1 ea 10          	shr    $0x10,%rdx
    8fd0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8fd4:	48 8b 15 7d 6b 01 00 	mov    0x16b7d(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8fdb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8fdf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8fe3:	4d 85 e4             	test   %r12,%r12
    8fe6:	74 3a                	je     9022 <f0+0x1772>
    8fe8:	0f b6 0a             	movzbl (%rdx),%ecx
    8feb:	80 f9 02             	cmp    $0x2,%cl
    8fee:	0f 84 6c 12 00 00    	je     a260 <f0+0x29b0>
    8ff4:	80 f9 01             	cmp    $0x1,%cl
    8ff7:	75 29                	jne    9022 <f0+0x1772>
    8ff9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ffc:	0f b7 c0             	movzwl %ax,%eax
    8fff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9002:	48 0f af c1          	imul   %rcx,%rax
    9006:	48 c1 e8 20          	shr    $0x20,%rax
    900a:	48 39 d0             	cmp    %rdx,%rax
    900d:	73 13                	jae    9022 <f0+0x1772>
    900f:	49 01 c4             	add    %rax,%r12
    9012:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9017:	0f 84 2d 14 00 00    	je     a44a <f0+0x2b9a>
    901d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9022:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9029:	33 f3 bf 
    902c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    9033:	00 
    9034:	bf 01 00 00 00       	mov    $0x1,%edi
    9039:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    9040:	00 
    9041:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    9048:	00 
    9049:	e8 e2 b8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    904e:	48 8b 15 e3 6a 01 00 	mov    0x16ae3(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9055:	49 89 c5             	mov    %rax,%r13
    9058:	48 2b 05 b1 6a 01 00 	sub    0x16ab1(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    905f:	48 c1 e2 10          	shl    $0x10,%rdx
    9063:	48 39 d0             	cmp    %rdx,%rax
    9066:	73 59                	jae    90c1 <f0+0x1811>
    9068:	48 89 c2             	mov    %rax,%rdx
    906b:	48 c1 ea 10          	shr    $0x10,%rdx
    906f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9073:	48 8b 15 de 6a 01 00 	mov    0x16ade(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    907a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    907e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9082:	4d 85 e4             	test   %r12,%r12
    9085:	74 3a                	je     90c1 <f0+0x1811>
    9087:	0f b6 0a             	movzbl (%rdx),%ecx
    908a:	80 f9 02             	cmp    $0x2,%cl
    908d:	0f 84 bd 11 00 00    	je     a250 <f0+0x29a0>
    9093:	80 f9 01             	cmp    $0x1,%cl
    9096:	75 29                	jne    90c1 <f0+0x1811>
    9098:	8b 4a 18             	mov    0x18(%rdx),%ecx
    909b:	0f b7 c0             	movzwl %ax,%eax
    909e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90a1:	48 0f af c1          	imul   %rcx,%rax
    90a5:	48 c1 e8 20          	shr    $0x20,%rax
    90a9:	48 39 d0             	cmp    %rdx,%rax
    90ac:	73 13                	jae    90c1 <f0+0x1811>
    90ae:	49 01 c4             	add    %rax,%r12
    90b1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    90b6:	0f 84 9b 13 00 00    	je     a457 <f0+0x2ba7>
    90bc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    90c1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    90c8:	00 f0 3f 
    90cb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    90d2:	00 
    90d3:	bf 01 00 00 00       	mov    $0x1,%edi
    90d8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    90df:	00 
    90e0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    90e7:	00 
    90e8:	e8 43 b8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    90ed:	48 8b 15 44 6a 01 00 	mov    0x16a44(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    90f4:	49 89 c5             	mov    %rax,%r13
    90f7:	48 2b 05 12 6a 01 00 	sub    0x16a12(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    90fe:	48 c1 e2 10          	shl    $0x10,%rdx
    9102:	48 39 d0             	cmp    %rdx,%rax
    9105:	73 59                	jae    9160 <f0+0x18b0>
    9107:	48 89 c2             	mov    %rax,%rdx
    910a:	48 c1 ea 10          	shr    $0x10,%rdx
    910e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9112:	48 8b 15 3f 6a 01 00 	mov    0x16a3f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9119:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    911d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9121:	4d 85 e4             	test   %r12,%r12
    9124:	74 3a                	je     9160 <f0+0x18b0>
    9126:	0f b6 0a             	movzbl (%rdx),%ecx
    9129:	80 f9 02             	cmp    $0x2,%cl
    912c:	0f 84 0e 11 00 00    	je     a240 <f0+0x2990>
    9132:	80 f9 01             	cmp    $0x1,%cl
    9135:	75 29                	jne    9160 <f0+0x18b0>
    9137:	8b 4a 18             	mov    0x18(%rdx),%ecx
    913a:	0f b7 c0             	movzwl %ax,%eax
    913d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9140:	48 0f af c1          	imul   %rcx,%rax
    9144:	48 c1 e8 20          	shr    $0x20,%rax
    9148:	48 39 d0             	cmp    %rdx,%rax
    914b:	73 13                	jae    9160 <f0+0x18b0>
    914d:	49 01 c4             	add    %rax,%r12
    9150:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9155:	0f 84 09 13 00 00    	je     a464 <f0+0x2bb4>
    915b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9160:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9167:	33 f3 bf 
    916a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    9171:	00 
    9172:	bf 01 00 00 00       	mov    $0x1,%edi
    9177:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    917e:	00 
    917f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    9186:	00 
    9187:	e8 a4 b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    918c:	48 8b 15 a5 69 01 00 	mov    0x169a5(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9193:	49 89 c5             	mov    %rax,%r13
    9196:	48 2b 05 73 69 01 00 	sub    0x16973(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    919d:	48 c1 e2 10          	shl    $0x10,%rdx
    91a1:	48 39 d0             	cmp    %rdx,%rax
    91a4:	73 59                	jae    91ff <f0+0x194f>
    91a6:	48 89 c2             	mov    %rax,%rdx
    91a9:	48 c1 ea 10          	shr    $0x10,%rdx
    91ad:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    91b1:	48 8b 15 a0 69 01 00 	mov    0x169a0(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    91b8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    91bc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    91c0:	4d 85 e4             	test   %r12,%r12
    91c3:	74 3a                	je     91ff <f0+0x194f>
    91c5:	0f b6 0a             	movzbl (%rdx),%ecx
    91c8:	80 f9 02             	cmp    $0x2,%cl
    91cb:	0f 84 5f 10 00 00    	je     a230 <f0+0x2980>
    91d1:	80 f9 01             	cmp    $0x1,%cl
    91d4:	75 29                	jne    91ff <f0+0x194f>
    91d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91d9:	0f b7 c0             	movzwl %ax,%eax
    91dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91df:	48 0f af c1          	imul   %rcx,%rax
    91e3:	48 c1 e8 20          	shr    $0x20,%rax
    91e7:	48 39 d0             	cmp    %rdx,%rax
    91ea:	73 13                	jae    91ff <f0+0x194f>
    91ec:	49 01 c4             	add    %rax,%r12
    91ef:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    91f4:	0f 84 77 12 00 00    	je     a471 <f0+0x2bc1>
    91fa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    91ff:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9206:	00 f0 3f 
    9209:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    9210:	00 
    9211:	bf 01 00 00 00       	mov    $0x1,%edi
    9216:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    921d:	00 
    921e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    9225:	00 
    9226:	e8 05 b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    922b:	48 8b 15 06 69 01 00 	mov    0x16906(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9232:	49 89 c5             	mov    %rax,%r13
    9235:	48 2b 05 d4 68 01 00 	sub    0x168d4(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    923c:	48 c1 e2 10          	shl    $0x10,%rdx
    9240:	48 39 d0             	cmp    %rdx,%rax
    9243:	73 59                	jae    929e <f0+0x19ee>
    9245:	48 89 c2             	mov    %rax,%rdx
    9248:	48 c1 ea 10          	shr    $0x10,%rdx
    924c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9250:	48 8b 15 01 69 01 00 	mov    0x16901(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9257:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    925b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    925f:	4d 85 e4             	test   %r12,%r12
    9262:	74 3a                	je     929e <f0+0x19ee>
    9264:	0f b6 0a             	movzbl (%rdx),%ecx
    9267:	80 f9 02             	cmp    $0x2,%cl
    926a:	0f 84 40 0f 00 00    	je     a1b0 <f0+0x2900>
    9270:	80 f9 01             	cmp    $0x1,%cl
    9273:	75 29                	jne    929e <f0+0x19ee>
    9275:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9278:	0f b7 c0             	movzwl %ax,%eax
    927b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    927e:	48 0f af c1          	imul   %rcx,%rax
    9282:	48 c1 e8 20          	shr    $0x20,%rax
    9286:	48 39 d0             	cmp    %rdx,%rax
    9289:	73 13                	jae    929e <f0+0x19ee>
    928b:	49 01 c4             	add    %rax,%r12
    928e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9293:	0f 84 e5 11 00 00    	je     a47e <f0+0x2bce>
    9299:	41 c6 04 24 01       	movb   $0x1,(%r12)
    929e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    92a5:	33 f3 bf 
    92a8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    92af:	00 
    92b0:	bf 01 00 00 00       	mov    $0x1,%edi
    92b5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    92bc:	00 
    92bd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    92c4:	00 
    92c5:	e8 66 b6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    92ca:	48 8b 15 67 68 01 00 	mov    0x16867(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    92d1:	49 89 c5             	mov    %rax,%r13
    92d4:	48 2b 05 35 68 01 00 	sub    0x16835(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    92db:	48 c1 e2 10          	shl    $0x10,%rdx
    92df:	48 39 d0             	cmp    %rdx,%rax
    92e2:	73 59                	jae    933d <f0+0x1a8d>
    92e4:	48 89 c2             	mov    %rax,%rdx
    92e7:	48 c1 ea 10          	shr    $0x10,%rdx
    92eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92ef:	48 8b 15 62 68 01 00 	mov    0x16862(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    92f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92fa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    92fe:	4d 85 e4             	test   %r12,%r12
    9301:	74 3a                	je     933d <f0+0x1a8d>
    9303:	0f b6 0a             	movzbl (%rdx),%ecx
    9306:	80 f9 02             	cmp    $0x2,%cl
    9309:	0f 84 91 0e 00 00    	je     a1a0 <f0+0x28f0>
    930f:	80 f9 01             	cmp    $0x1,%cl
    9312:	75 29                	jne    933d <f0+0x1a8d>
    9314:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9317:	0f b7 c0             	movzwl %ax,%eax
    931a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    931d:	48 0f af c1          	imul   %rcx,%rax
    9321:	48 c1 e8 20          	shr    $0x20,%rax
    9325:	48 39 d0             	cmp    %rdx,%rax
    9328:	73 13                	jae    933d <f0+0x1a8d>
    932a:	49 01 c4             	add    %rax,%r12
    932d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9332:	0f 84 53 11 00 00    	je     a48b <f0+0x2bdb>
    9338:	41 c6 04 24 01       	movb   $0x1,(%r12)
    933d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9344:	00 f0 3f 
    9347:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    934e:	00 
    934f:	bf 01 00 00 00       	mov    $0x1,%edi
    9354:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    935b:	00 
    935c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    9363:	00 
    9364:	e8 c7 b5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9369:	48 8b 15 c8 67 01 00 	mov    0x167c8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9370:	49 89 c5             	mov    %rax,%r13
    9373:	48 2b 05 96 67 01 00 	sub    0x16796(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    937a:	48 c1 e2 10          	shl    $0x10,%rdx
    937e:	48 39 d0             	cmp    %rdx,%rax
    9381:	73 59                	jae    93dc <f0+0x1b2c>
    9383:	48 89 c2             	mov    %rax,%rdx
    9386:	48 c1 ea 10          	shr    $0x10,%rdx
    938a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    938e:	48 8b 15 c3 67 01 00 	mov    0x167c3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9395:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9399:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    939d:	4d 85 e4             	test   %r12,%r12
    93a0:	74 3a                	je     93dc <f0+0x1b2c>
    93a2:	0f b6 0a             	movzbl (%rdx),%ecx
    93a5:	80 f9 02             	cmp    $0x2,%cl
    93a8:	0f 84 e2 0d 00 00    	je     a190 <f0+0x28e0>
    93ae:	80 f9 01             	cmp    $0x1,%cl
    93b1:	75 29                	jne    93dc <f0+0x1b2c>
    93b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93b6:	0f b7 c0             	movzwl %ax,%eax
    93b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93bc:	48 0f af c1          	imul   %rcx,%rax
    93c0:	48 c1 e8 20          	shr    $0x20,%rax
    93c4:	48 39 d0             	cmp    %rdx,%rax
    93c7:	73 13                	jae    93dc <f0+0x1b2c>
    93c9:	49 01 c4             	add    %rax,%r12
    93cc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    93d1:	0f 84 c1 10 00 00    	je     a498 <f0+0x2be8>
    93d7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    93dc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    93e3:	33 f3 bf 
    93e6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    93ed:	00 
    93ee:	bf 01 00 00 00       	mov    $0x1,%edi
    93f3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    93fa:	00 
    93fb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    9402:	00 
    9403:	e8 28 b5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9408:	48 8b 15 29 67 01 00 	mov    0x16729(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    940f:	49 89 c5             	mov    %rax,%r13
    9412:	48 2b 05 f7 66 01 00 	sub    0x166f7(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9419:	48 c1 e2 10          	shl    $0x10,%rdx
    941d:	48 39 d0             	cmp    %rdx,%rax
    9420:	73 59                	jae    947b <f0+0x1bcb>
    9422:	48 89 c2             	mov    %rax,%rdx
    9425:	48 c1 ea 10          	shr    $0x10,%rdx
    9429:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    942d:	48 8b 15 24 67 01 00 	mov    0x16724(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9434:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9438:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    943c:	4d 85 e4             	test   %r12,%r12
    943f:	74 3a                	je     947b <f0+0x1bcb>
    9441:	0f b6 0a             	movzbl (%rdx),%ecx
    9444:	80 f9 02             	cmp    $0x2,%cl
    9447:	0f 84 33 0d 00 00    	je     a180 <f0+0x28d0>
    944d:	80 f9 01             	cmp    $0x1,%cl
    9450:	75 29                	jne    947b <f0+0x1bcb>
    9452:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9455:	0f b7 c0             	movzwl %ax,%eax
    9458:	8b 52 1c             	mov    0x1c(%rdx),%edx
    945b:	48 0f af c1          	imul   %rcx,%rax
    945f:	48 c1 e8 20          	shr    $0x20,%rax
    9463:	48 39 d0             	cmp    %rdx,%rax
    9466:	73 13                	jae    947b <f0+0x1bcb>
    9468:	49 01 c4             	add    %rax,%r12
    946b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9470:	0f 84 2f 10 00 00    	je     a4a5 <f0+0x2bf5>
    9476:	41 c6 04 24 01       	movb   $0x1,(%r12)
    947b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9482:	00 f0 3f 
    9485:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    948c:	00 
    948d:	bf 01 00 00 00       	mov    $0x1,%edi
    9492:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    9499:	00 
    949a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    94a1:	00 
    94a2:	e8 89 b4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    94a7:	48 8b 15 8a 66 01 00 	mov    0x1668a(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    94ae:	49 89 c5             	mov    %rax,%r13
    94b1:	48 2b 05 58 66 01 00 	sub    0x16658(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    94b8:	48 c1 e2 10          	shl    $0x10,%rdx
    94bc:	48 39 d0             	cmp    %rdx,%rax
    94bf:	73 59                	jae    951a <f0+0x1c6a>
    94c1:	48 89 c2             	mov    %rax,%rdx
    94c4:	48 c1 ea 10          	shr    $0x10,%rdx
    94c8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94cc:	48 8b 15 85 66 01 00 	mov    0x16685(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    94d3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94d7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    94db:	4d 85 e4             	test   %r12,%r12
    94de:	74 3a                	je     951a <f0+0x1c6a>
    94e0:	0f b6 0a             	movzbl (%rdx),%ecx
    94e3:	80 f9 02             	cmp    $0x2,%cl
    94e6:	0f 84 84 0c 00 00    	je     a170 <f0+0x28c0>
    94ec:	80 f9 01             	cmp    $0x1,%cl
    94ef:	75 29                	jne    951a <f0+0x1c6a>
    94f1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94f4:	0f b7 c0             	movzwl %ax,%eax
    94f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94fa:	48 0f af c1          	imul   %rcx,%rax
    94fe:	48 c1 e8 20          	shr    $0x20,%rax
    9502:	48 39 d0             	cmp    %rdx,%rax
    9505:	73 13                	jae    951a <f0+0x1c6a>
    9507:	49 01 c4             	add    %rax,%r12
    950a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    950f:	0f 84 9d 0f 00 00    	je     a4b2 <f0+0x2c02>
    9515:	41 c6 04 24 01       	movb   $0x1,(%r12)
    951a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9521:	33 f3 bf 
    9524:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    952b:	00 
    952c:	bf 01 00 00 00       	mov    $0x1,%edi
    9531:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    9538:	00 
    9539:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    9540:	00 
    9541:	e8 ea b3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9546:	48 8b 15 eb 65 01 00 	mov    0x165eb(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    954d:	49 89 c5             	mov    %rax,%r13
    9550:	48 2b 05 b9 65 01 00 	sub    0x165b9(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9557:	48 c1 e2 10          	shl    $0x10,%rdx
    955b:	48 39 d0             	cmp    %rdx,%rax
    955e:	73 59                	jae    95b9 <f0+0x1d09>
    9560:	48 89 c2             	mov    %rax,%rdx
    9563:	48 c1 ea 10          	shr    $0x10,%rdx
    9567:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    956b:	48 8b 15 e6 65 01 00 	mov    0x165e6(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9572:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9576:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    957a:	4d 85 e4             	test   %r12,%r12
    957d:	74 3a                	je     95b9 <f0+0x1d09>
    957f:	0f b6 0a             	movzbl (%rdx),%ecx
    9582:	80 f9 02             	cmp    $0x2,%cl
    9585:	0f 84 d5 0b 00 00    	je     a160 <f0+0x28b0>
    958b:	80 f9 01             	cmp    $0x1,%cl
    958e:	75 29                	jne    95b9 <f0+0x1d09>
    9590:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9593:	0f b7 c0             	movzwl %ax,%eax
    9596:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9599:	48 0f af c1          	imul   %rcx,%rax
    959d:	48 c1 e8 20          	shr    $0x20,%rax
    95a1:	48 39 d0             	cmp    %rdx,%rax
    95a4:	73 13                	jae    95b9 <f0+0x1d09>
    95a6:	49 01 c4             	add    %rax,%r12
    95a9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    95ae:	0f 84 0b 0f 00 00    	je     a4bf <f0+0x2c0f>
    95b4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    95b9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    95c0:	00 f0 3f 
    95c3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    95ca:	00 
    95cb:	bf 01 00 00 00       	mov    $0x1,%edi
    95d0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    95d7:	00 
    95d8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    95df:	00 
    95e0:	e8 4b b3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    95e5:	48 8b 15 4c 65 01 00 	mov    0x1654c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    95ec:	49 89 c5             	mov    %rax,%r13
    95ef:	48 2b 05 1a 65 01 00 	sub    0x1651a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    95f6:	48 c1 e2 10          	shl    $0x10,%rdx
    95fa:	48 39 d0             	cmp    %rdx,%rax
    95fd:	73 59                	jae    9658 <f0+0x1da8>
    95ff:	48 89 c2             	mov    %rax,%rdx
    9602:	48 c1 ea 10          	shr    $0x10,%rdx
    9606:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    960a:	48 8b 15 47 65 01 00 	mov    0x16547(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9611:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9615:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9619:	4d 85 e4             	test   %r12,%r12
    961c:	74 3a                	je     9658 <f0+0x1da8>
    961e:	0f b6 0a             	movzbl (%rdx),%ecx
    9621:	80 f9 02             	cmp    $0x2,%cl
    9624:	0f 84 26 0b 00 00    	je     a150 <f0+0x28a0>
    962a:	80 f9 01             	cmp    $0x1,%cl
    962d:	75 29                	jne    9658 <f0+0x1da8>
    962f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9632:	0f b7 c0             	movzwl %ax,%eax
    9635:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9638:	48 0f af c1          	imul   %rcx,%rax
    963c:	48 c1 e8 20          	shr    $0x20,%rax
    9640:	48 39 d0             	cmp    %rdx,%rax
    9643:	73 13                	jae    9658 <f0+0x1da8>
    9645:	49 01 c4             	add    %rax,%r12
    9648:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    964d:	0f 84 79 0e 00 00    	je     a4cc <f0+0x2c1c>
    9653:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9658:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    965f:	33 f3 bf 
    9662:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    9669:	00 
    966a:	bf 01 00 00 00       	mov    $0x1,%edi
    966f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    9676:	00 
    9677:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    967e:	00 
    967f:	e8 ac b2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9684:	48 8b 15 ad 64 01 00 	mov    0x164ad(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    968b:	49 89 c5             	mov    %rax,%r13
    968e:	48 2b 05 7b 64 01 00 	sub    0x1647b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9695:	48 c1 e2 10          	shl    $0x10,%rdx
    9699:	48 39 d0             	cmp    %rdx,%rax
    969c:	73 59                	jae    96f7 <f0+0x1e47>
    969e:	48 89 c2             	mov    %rax,%rdx
    96a1:	48 c1 ea 10          	shr    $0x10,%rdx
    96a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96a9:	48 8b 15 a8 64 01 00 	mov    0x164a8(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    96b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    96b8:	4d 85 e4             	test   %r12,%r12
    96bb:	74 3a                	je     96f7 <f0+0x1e47>
    96bd:	0f b6 0a             	movzbl (%rdx),%ecx
    96c0:	80 f9 02             	cmp    $0x2,%cl
    96c3:	0f 84 77 0a 00 00    	je     a140 <f0+0x2890>
    96c9:	80 f9 01             	cmp    $0x1,%cl
    96cc:	75 29                	jne    96f7 <f0+0x1e47>
    96ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96d1:	0f b7 c0             	movzwl %ax,%eax
    96d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96d7:	48 0f af c1          	imul   %rcx,%rax
    96db:	48 c1 e8 20          	shr    $0x20,%rax
    96df:	48 39 d0             	cmp    %rdx,%rax
    96e2:	73 13                	jae    96f7 <f0+0x1e47>
    96e4:	49 01 c4             	add    %rax,%r12
    96e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    96ec:	0f 84 e7 0d 00 00    	je     a4d9 <f0+0x2c29>
    96f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    96f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    96fe:	00 f0 3f 
    9701:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    9708:	00 
    9709:	bf 01 00 00 00       	mov    $0x1,%edi
    970e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    9715:	00 
    9716:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    971d:	00 
    971e:	e8 0d b2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9723:	48 8b 15 0e 64 01 00 	mov    0x1640e(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    972a:	49 89 c5             	mov    %rax,%r13
    972d:	48 2b 05 dc 63 01 00 	sub    0x163dc(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9734:	48 c1 e2 10          	shl    $0x10,%rdx
    9738:	48 39 d0             	cmp    %rdx,%rax
    973b:	73 59                	jae    9796 <f0+0x1ee6>
    973d:	48 89 c2             	mov    %rax,%rdx
    9740:	48 c1 ea 10          	shr    $0x10,%rdx
    9744:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9748:	48 8b 15 09 64 01 00 	mov    0x16409(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    974f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9753:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9757:	4d 85 e4             	test   %r12,%r12
    975a:	74 3a                	je     9796 <f0+0x1ee6>
    975c:	0f b6 0a             	movzbl (%rdx),%ecx
    975f:	80 f9 02             	cmp    $0x2,%cl
    9762:	0f 84 38 0c 00 00    	je     a3a0 <f0+0x2af0>
    9768:	80 f9 01             	cmp    $0x1,%cl
    976b:	75 29                	jne    9796 <f0+0x1ee6>
    976d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9770:	0f b7 c0             	movzwl %ax,%eax
    9773:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9776:	48 0f af c1          	imul   %rcx,%rax
    977a:	48 c1 e8 20          	shr    $0x20,%rax
    977e:	48 39 d0             	cmp    %rdx,%rax
    9781:	73 13                	jae    9796 <f0+0x1ee6>
    9783:	49 01 c4             	add    %rax,%r12
    9786:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    978b:	0f 84 55 0d 00 00    	je     a4e6 <f0+0x2c36>
    9791:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9796:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    979d:	33 f3 bf 
    97a0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    97a7:	00 
    97a8:	bf 01 00 00 00       	mov    $0x1,%edi
    97ad:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    97b4:	00 
    97b5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    97bc:	00 
    97bd:	e8 6e b1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    97c2:	48 8b 15 6f 63 01 00 	mov    0x1636f(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    97c9:	49 89 c5             	mov    %rax,%r13
    97cc:	48 2b 05 3d 63 01 00 	sub    0x1633d(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    97d3:	48 c1 e2 10          	shl    $0x10,%rdx
    97d7:	48 39 d0             	cmp    %rdx,%rax
    97da:	73 59                	jae    9835 <f0+0x1f85>
    97dc:	48 89 c2             	mov    %rax,%rdx
    97df:	48 c1 ea 10          	shr    $0x10,%rdx
    97e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97e7:	48 8b 15 6a 63 01 00 	mov    0x1636a(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    97ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    97f6:	4d 85 e4             	test   %r12,%r12
    97f9:	74 3a                	je     9835 <f0+0x1f85>
    97fb:	0f b6 0a             	movzbl (%rdx),%ecx
    97fe:	80 f9 02             	cmp    $0x2,%cl
    9801:	0f 84 89 0b 00 00    	je     a390 <f0+0x2ae0>
    9807:	80 f9 01             	cmp    $0x1,%cl
    980a:	75 29                	jne    9835 <f0+0x1f85>
    980c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    980f:	0f b7 c0             	movzwl %ax,%eax
    9812:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9815:	48 0f af c1          	imul   %rcx,%rax
    9819:	48 c1 e8 20          	shr    $0x20,%rax
    981d:	48 39 d0             	cmp    %rdx,%rax
    9820:	73 13                	jae    9835 <f0+0x1f85>
    9822:	49 01 c4             	add    %rax,%r12
    9825:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    982a:	0f 84 c3 0c 00 00    	je     a4f3 <f0+0x2c43>
    9830:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9835:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    983c:	00 f0 3f 
    983f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    9846:	00 
    9847:	bf 01 00 00 00       	mov    $0x1,%edi
    984c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    9853:	00 
    9854:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    985b:	00 
    985c:	e8 cf b0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9861:	48 8b 15 d0 62 01 00 	mov    0x162d0(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9868:	49 89 c5             	mov    %rax,%r13
    986b:	48 2b 05 9e 62 01 00 	sub    0x1629e(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9872:	48 c1 e2 10          	shl    $0x10,%rdx
    9876:	48 39 d0             	cmp    %rdx,%rax
    9879:	73 59                	jae    98d4 <f0+0x2024>
    987b:	48 89 c2             	mov    %rax,%rdx
    987e:	48 c1 ea 10          	shr    $0x10,%rdx
    9882:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9886:	48 8b 15 cb 62 01 00 	mov    0x162cb(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    988d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9891:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9895:	4d 85 e4             	test   %r12,%r12
    9898:	74 3a                	je     98d4 <f0+0x2024>
    989a:	0f b6 0a             	movzbl (%rdx),%ecx
    989d:	80 f9 02             	cmp    $0x2,%cl
    98a0:	0f 84 da 0a 00 00    	je     a380 <f0+0x2ad0>
    98a6:	80 f9 01             	cmp    $0x1,%cl
    98a9:	75 29                	jne    98d4 <f0+0x2024>
    98ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98ae:	0f b7 c0             	movzwl %ax,%eax
    98b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98b4:	48 0f af c1          	imul   %rcx,%rax
    98b8:	48 c1 e8 20          	shr    $0x20,%rax
    98bc:	48 39 d0             	cmp    %rdx,%rax
    98bf:	73 13                	jae    98d4 <f0+0x2024>
    98c1:	49 01 c4             	add    %rax,%r12
    98c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    98c9:	0f 84 31 0c 00 00    	je     a500 <f0+0x2c50>
    98cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    98d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    98db:	33 f3 bf 
    98de:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    98e5:	00 
    98e6:	bf 01 00 00 00       	mov    $0x1,%edi
    98eb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    98f2:	00 
    98f3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    98fa:	00 
    98fb:	e8 30 b0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9900:	48 8b 15 31 62 01 00 	mov    0x16231(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9907:	49 89 c5             	mov    %rax,%r13
    990a:	48 2b 05 ff 61 01 00 	sub    0x161ff(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9911:	48 c1 e2 10          	shl    $0x10,%rdx
    9915:	48 39 d0             	cmp    %rdx,%rax
    9918:	73 59                	jae    9973 <f0+0x20c3>
    991a:	48 89 c2             	mov    %rax,%rdx
    991d:	48 c1 ea 10          	shr    $0x10,%rdx
    9921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9925:	48 8b 15 2c 62 01 00 	mov    0x1622c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    992c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9930:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9934:	4d 85 e4             	test   %r12,%r12
    9937:	74 3a                	je     9973 <f0+0x20c3>
    9939:	0f b6 0a             	movzbl (%rdx),%ecx
    993c:	80 f9 02             	cmp    $0x2,%cl
    993f:	0f 84 2b 0a 00 00    	je     a370 <f0+0x2ac0>
    9945:	80 f9 01             	cmp    $0x1,%cl
    9948:	75 29                	jne    9973 <f0+0x20c3>
    994a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    994d:	0f b7 c0             	movzwl %ax,%eax
    9950:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9953:	48 0f af c1          	imul   %rcx,%rax
    9957:	48 c1 e8 20          	shr    $0x20,%rax
    995b:	48 39 d0             	cmp    %rdx,%rax
    995e:	73 13                	jae    9973 <f0+0x20c3>
    9960:	49 01 c4             	add    %rax,%r12
    9963:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9968:	0f 84 9f 0b 00 00    	je     a50d <f0+0x2c5d>
    996e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9973:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    997a:	00 f0 3f 
    997d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    9984:	00 
    9985:	bf 01 00 00 00       	mov    $0x1,%edi
    998a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    9991:	00 
    9992:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    9999:	00 
    999a:	e8 91 af ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    999f:	48 8b 15 92 61 01 00 	mov    0x16192(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    99a6:	49 89 c5             	mov    %rax,%r13
    99a9:	48 2b 05 60 61 01 00 	sub    0x16160(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    99b0:	48 c1 e2 10          	shl    $0x10,%rdx
    99b4:	48 39 d0             	cmp    %rdx,%rax
    99b7:	73 59                	jae    9a12 <f0+0x2162>
    99b9:	48 89 c2             	mov    %rax,%rdx
    99bc:	48 c1 ea 10          	shr    $0x10,%rdx
    99c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99c4:	48 8b 15 8d 61 01 00 	mov    0x1618d(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    99cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    99d3:	4d 85 e4             	test   %r12,%r12
    99d6:	74 3a                	je     9a12 <f0+0x2162>
    99d8:	0f b6 0a             	movzbl (%rdx),%ecx
    99db:	80 f9 02             	cmp    $0x2,%cl
    99de:	0f 84 7c 09 00 00    	je     a360 <f0+0x2ab0>
    99e4:	80 f9 01             	cmp    $0x1,%cl
    99e7:	75 29                	jne    9a12 <f0+0x2162>
    99e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99ec:	0f b7 c0             	movzwl %ax,%eax
    99ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99f2:	48 0f af c1          	imul   %rcx,%rax
    99f6:	48 c1 e8 20          	shr    $0x20,%rax
    99fa:	48 39 d0             	cmp    %rdx,%rax
    99fd:	73 13                	jae    9a12 <f0+0x2162>
    99ff:	49 01 c4             	add    %rax,%r12
    9a02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9a07:	0f 84 0d 0b 00 00    	je     a51a <f0+0x2c6a>
    9a0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9a12:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9a19:	33 f3 bf 
    9a1c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    9a23:	00 
    9a24:	bf 01 00 00 00       	mov    $0x1,%edi
    9a29:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    9a30:	00 
    9a31:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    9a38:	00 
    9a39:	e8 f2 ae ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9a3e:	48 8b 15 f3 60 01 00 	mov    0x160f3(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9a45:	49 89 c5             	mov    %rax,%r13
    9a48:	48 2b 05 c1 60 01 00 	sub    0x160c1(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9a4f:	48 c1 e2 10          	shl    $0x10,%rdx
    9a53:	48 39 d0             	cmp    %rdx,%rax
    9a56:	73 59                	jae    9ab1 <f0+0x2201>
    9a58:	48 89 c2             	mov    %rax,%rdx
    9a5b:	48 c1 ea 10          	shr    $0x10,%rdx
    9a5f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a63:	48 8b 15 ee 60 01 00 	mov    0x160ee(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9a6a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a6e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9a72:	4d 85 e4             	test   %r12,%r12
    9a75:	74 3a                	je     9ab1 <f0+0x2201>
    9a77:	0f b6 0a             	movzbl (%rdx),%ecx
    9a7a:	80 f9 02             	cmp    $0x2,%cl
    9a7d:	0f 84 cd 08 00 00    	je     a350 <f0+0x2aa0>
    9a83:	80 f9 01             	cmp    $0x1,%cl
    9a86:	75 29                	jne    9ab1 <f0+0x2201>
    9a88:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a8b:	0f b7 c0             	movzwl %ax,%eax
    9a8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a91:	48 0f af c1          	imul   %rcx,%rax
    9a95:	48 c1 e8 20          	shr    $0x20,%rax
    9a99:	48 39 d0             	cmp    %rdx,%rax
    9a9c:	73 13                	jae    9ab1 <f0+0x2201>
    9a9e:	49 01 c4             	add    %rax,%r12
    9aa1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9aa6:	0f 84 7b 0a 00 00    	je     a527 <f0+0x2c77>
    9aac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ab1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9ab8:	00 f0 3f 
    9abb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    9ac2:	00 
    9ac3:	bf 01 00 00 00       	mov    $0x1,%edi
    9ac8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    9acf:	00 
    9ad0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    9ad7:	00 
    9ad8:	e8 53 ae ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9add:	48 8b 15 54 60 01 00 	mov    0x16054(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9ae4:	49 89 c5             	mov    %rax,%r13
    9ae7:	48 2b 05 22 60 01 00 	sub    0x16022(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9aee:	48 c1 e2 10          	shl    $0x10,%rdx
    9af2:	48 39 d0             	cmp    %rdx,%rax
    9af5:	73 59                	jae    9b50 <f0+0x22a0>
    9af7:	48 89 c2             	mov    %rax,%rdx
    9afa:	48 c1 ea 10          	shr    $0x10,%rdx
    9afe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b02:	48 8b 15 4f 60 01 00 	mov    0x1604f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9b09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9b11:	4d 85 e4             	test   %r12,%r12
    9b14:	74 3a                	je     9b50 <f0+0x22a0>
    9b16:	0f b6 0a             	movzbl (%rdx),%ecx
    9b19:	80 f9 02             	cmp    $0x2,%cl
    9b1c:	0f 84 1e 08 00 00    	je     a340 <f0+0x2a90>
    9b22:	80 f9 01             	cmp    $0x1,%cl
    9b25:	75 29                	jne    9b50 <f0+0x22a0>
    9b27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b2a:	0f b7 c0             	movzwl %ax,%eax
    9b2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b30:	48 0f af c1          	imul   %rcx,%rax
    9b34:	48 c1 e8 20          	shr    $0x20,%rax
    9b38:	48 39 d0             	cmp    %rdx,%rax
    9b3b:	73 13                	jae    9b50 <f0+0x22a0>
    9b3d:	49 01 c4             	add    %rax,%r12
    9b40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9b45:	0f 84 e9 09 00 00    	je     a534 <f0+0x2c84>
    9b4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9b50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9b57:	33 f3 bf 
    9b5a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    9b61:	00 
    9b62:	bf 01 00 00 00       	mov    $0x1,%edi
    9b67:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    9b6e:	00 
    9b6f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    9b76:	00 
    9b77:	e8 b4 ad ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9b7c:	48 8b 15 b5 5f 01 00 	mov    0x15fb5(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9b83:	49 89 c5             	mov    %rax,%r13
    9b86:	48 2b 05 83 5f 01 00 	sub    0x15f83(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9b8d:	48 c1 e2 10          	shl    $0x10,%rdx
    9b91:	48 39 d0             	cmp    %rdx,%rax
    9b94:	73 59                	jae    9bef <f0+0x233f>
    9b96:	48 89 c2             	mov    %rax,%rdx
    9b99:	48 c1 ea 10          	shr    $0x10,%rdx
    9b9d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ba1:	48 8b 15 b0 5f 01 00 	mov    0x15fb0(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9ba8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9bb0:	4d 85 e4             	test   %r12,%r12
    9bb3:	74 3a                	je     9bef <f0+0x233f>
    9bb5:	0f b6 0a             	movzbl (%rdx),%ecx
    9bb8:	80 f9 02             	cmp    $0x2,%cl
    9bbb:	0f 84 6f 07 00 00    	je     a330 <f0+0x2a80>
    9bc1:	80 f9 01             	cmp    $0x1,%cl
    9bc4:	75 29                	jne    9bef <f0+0x233f>
    9bc6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bc9:	0f b7 c0             	movzwl %ax,%eax
    9bcc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bcf:	48 0f af c1          	imul   %rcx,%rax
    9bd3:	48 c1 e8 20          	shr    $0x20,%rax
    9bd7:	48 39 d0             	cmp    %rdx,%rax
    9bda:	73 13                	jae    9bef <f0+0x233f>
    9bdc:	49 01 c4             	add    %rax,%r12
    9bdf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9be4:	0f 84 57 09 00 00    	je     a541 <f0+0x2c91>
    9bea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9bef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9bf6:	00 f0 3f 
    9bf9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    9c00:	00 
    9c01:	bf 01 00 00 00       	mov    $0x1,%edi
    9c06:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    9c0d:	00 
    9c0e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9c15:	00 
    9c16:	e8 15 ad ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9c1b:	48 8b 15 16 5f 01 00 	mov    0x15f16(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9c22:	49 89 c5             	mov    %rax,%r13
    9c25:	48 2b 05 e4 5e 01 00 	sub    0x15ee4(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9c2c:	48 c1 e2 10          	shl    $0x10,%rdx
    9c30:	48 39 d0             	cmp    %rdx,%rax
    9c33:	73 59                	jae    9c8e <f0+0x23de>
    9c35:	48 89 c2             	mov    %rax,%rdx
    9c38:	48 c1 ea 10          	shr    $0x10,%rdx
    9c3c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c40:	48 8b 15 11 5f 01 00 	mov    0x15f11(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9c47:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c4b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9c4f:	4d 85 e4             	test   %r12,%r12
    9c52:	74 3a                	je     9c8e <f0+0x23de>
    9c54:	0f b6 0a             	movzbl (%rdx),%ecx
    9c57:	80 f9 02             	cmp    $0x2,%cl
    9c5a:	0f 84 c0 06 00 00    	je     a320 <f0+0x2a70>
    9c60:	80 f9 01             	cmp    $0x1,%cl
    9c63:	75 29                	jne    9c8e <f0+0x23de>
    9c65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c68:	0f b7 c0             	movzwl %ax,%eax
    9c6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c6e:	48 0f af c1          	imul   %rcx,%rax
    9c72:	48 c1 e8 20          	shr    $0x20,%rax
    9c76:	48 39 d0             	cmp    %rdx,%rax
    9c79:	73 13                	jae    9c8e <f0+0x23de>
    9c7b:	49 01 c4             	add    %rax,%r12
    9c7e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9c83:	0f 84 c5 08 00 00    	je     a54e <f0+0x2c9e>
    9c89:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9c8e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9c95:	33 f3 bf 
    9c98:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    9c9f:	00 
    9ca0:	bf 01 00 00 00       	mov    $0x1,%edi
    9ca5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    9cac:	00 
    9cad:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    9cb4:	00 
    9cb5:	e8 76 ac ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9cba:	48 8b 15 77 5e 01 00 	mov    0x15e77(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9cc1:	49 89 c5             	mov    %rax,%r13
    9cc4:	48 2b 05 45 5e 01 00 	sub    0x15e45(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9ccb:	48 c1 e2 10          	shl    $0x10,%rdx
    9ccf:	48 39 d0             	cmp    %rdx,%rax
    9cd2:	73 59                	jae    9d2d <f0+0x247d>
    9cd4:	48 89 c2             	mov    %rax,%rdx
    9cd7:	48 c1 ea 10          	shr    $0x10,%rdx
    9cdb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9cdf:	48 8b 15 72 5e 01 00 	mov    0x15e72(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9ce6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9cea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9cee:	4d 85 e4             	test   %r12,%r12
    9cf1:	74 3a                	je     9d2d <f0+0x247d>
    9cf3:	0f b6 0a             	movzbl (%rdx),%ecx
    9cf6:	80 f9 02             	cmp    $0x2,%cl
    9cf9:	0f 84 11 06 00 00    	je     a310 <f0+0x2a60>
    9cff:	80 f9 01             	cmp    $0x1,%cl
    9d02:	75 29                	jne    9d2d <f0+0x247d>
    9d04:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d07:	0f b7 c0             	movzwl %ax,%eax
    9d0a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d0d:	48 0f af c1          	imul   %rcx,%rax
    9d11:	48 c1 e8 20          	shr    $0x20,%rax
    9d15:	48 39 d0             	cmp    %rdx,%rax
    9d18:	73 13                	jae    9d2d <f0+0x247d>
    9d1a:	49 01 c4             	add    %rax,%r12
    9d1d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9d22:	0f 84 33 08 00 00    	je     a55b <f0+0x2cab>
    9d28:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9d2d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9d34:	00 f0 3f 
    9d37:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    9d3e:	00 
    9d3f:	bf 01 00 00 00       	mov    $0x1,%edi
    9d44:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9d4b:	00 
    9d4c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9d53:	00 
    9d54:	e8 d7 ab ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9d59:	48 8b 15 d8 5d 01 00 	mov    0x15dd8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9d60:	49 89 c5             	mov    %rax,%r13
    9d63:	48 2b 05 a6 5d 01 00 	sub    0x15da6(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9d6a:	48 c1 e2 10          	shl    $0x10,%rdx
    9d6e:	48 39 d0             	cmp    %rdx,%rax
    9d71:	73 59                	jae    9dcc <f0+0x251c>
    9d73:	48 89 c2             	mov    %rax,%rdx
    9d76:	48 c1 ea 10          	shr    $0x10,%rdx
    9d7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d7e:	48 8b 15 d3 5d 01 00 	mov    0x15dd3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9d85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d89:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9d8d:	4d 85 e4             	test   %r12,%r12
    9d90:	74 3a                	je     9dcc <f0+0x251c>
    9d92:	0f b6 0a             	movzbl (%rdx),%ecx
    9d95:	80 f9 02             	cmp    $0x2,%cl
    9d98:	0f 84 62 05 00 00    	je     a300 <f0+0x2a50>
    9d9e:	80 f9 01             	cmp    $0x1,%cl
    9da1:	75 29                	jne    9dcc <f0+0x251c>
    9da3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9da6:	0f b7 c0             	movzwl %ax,%eax
    9da9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dac:	48 0f af c1          	imul   %rcx,%rax
    9db0:	48 c1 e8 20          	shr    $0x20,%rax
    9db4:	48 39 d0             	cmp    %rdx,%rax
    9db7:	73 13                	jae    9dcc <f0+0x251c>
    9db9:	49 01 c4             	add    %rax,%r12
    9dbc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9dc1:	0f 84 a1 07 00 00    	je     a568 <f0+0x2cb8>
    9dc7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9dcc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9dd3:	33 f3 bf 
    9dd6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    9ddd:	00 
    9dde:	bf 01 00 00 00       	mov    $0x1,%edi
    9de3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    9dea:	00 
    9deb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    9df2:	00 
    9df3:	e8 38 ab ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9df8:	48 8b 15 39 5d 01 00 	mov    0x15d39(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9dff:	49 89 c5             	mov    %rax,%r13
    9e02:	48 2b 05 07 5d 01 00 	sub    0x15d07(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9e09:	48 c1 e2 10          	shl    $0x10,%rdx
    9e0d:	48 39 d0             	cmp    %rdx,%rax
    9e10:	73 59                	jae    9e6b <f0+0x25bb>
    9e12:	48 89 c2             	mov    %rax,%rdx
    9e15:	48 c1 ea 10          	shr    $0x10,%rdx
    9e19:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e1d:	48 8b 15 34 5d 01 00 	mov    0x15d34(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9e24:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e28:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9e2c:	4d 85 e4             	test   %r12,%r12
    9e2f:	74 3a                	je     9e6b <f0+0x25bb>
    9e31:	0f b6 0a             	movzbl (%rdx),%ecx
    9e34:	80 f9 02             	cmp    $0x2,%cl
    9e37:	0f 84 b3 04 00 00    	je     a2f0 <f0+0x2a40>
    9e3d:	80 f9 01             	cmp    $0x1,%cl
    9e40:	75 29                	jne    9e6b <f0+0x25bb>
    9e42:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e45:	0f b7 c0             	movzwl %ax,%eax
    9e48:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e4b:	48 0f af c1          	imul   %rcx,%rax
    9e4f:	48 c1 e8 20          	shr    $0x20,%rax
    9e53:	48 39 d0             	cmp    %rdx,%rax
    9e56:	73 13                	jae    9e6b <f0+0x25bb>
    9e58:	49 01 c4             	add    %rax,%r12
    9e5b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9e60:	0f 84 0f 07 00 00    	je     a575 <f0+0x2cc5>
    9e66:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9e6b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9e72:	00 f0 3f 
    9e75:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    9e7c:	00 
    9e7d:	bf 01 00 00 00       	mov    $0x1,%edi
    9e82:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    9e89:	00 
    9e8a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    9e91:	00 
    9e92:	e8 99 aa ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9e97:	48 8b 15 9a 5c 01 00 	mov    0x15c9a(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9e9e:	49 89 c5             	mov    %rax,%r13
    9ea1:	48 2b 05 68 5c 01 00 	sub    0x15c68(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9ea8:	48 c1 e2 10          	shl    $0x10,%rdx
    9eac:	48 39 d0             	cmp    %rdx,%rax
    9eaf:	73 59                	jae    9f0a <f0+0x265a>
    9eb1:	48 89 c2             	mov    %rax,%rdx
    9eb4:	48 c1 ea 10          	shr    $0x10,%rdx
    9eb8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ebc:	48 8b 15 95 5c 01 00 	mov    0x15c95(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9ec3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ec7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9ecb:	4d 85 e4             	test   %r12,%r12
    9ece:	74 3a                	je     9f0a <f0+0x265a>
    9ed0:	0f b6 0a             	movzbl (%rdx),%ecx
    9ed3:	80 f9 02             	cmp    $0x2,%cl
    9ed6:	0f 84 04 04 00 00    	je     a2e0 <f0+0x2a30>
    9edc:	80 f9 01             	cmp    $0x1,%cl
    9edf:	75 29                	jne    9f0a <f0+0x265a>
    9ee1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ee4:	0f b7 c0             	movzwl %ax,%eax
    9ee7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9eea:	48 0f af c1          	imul   %rcx,%rax
    9eee:	48 c1 e8 20          	shr    $0x20,%rax
    9ef2:	48 39 d0             	cmp    %rdx,%rax
    9ef5:	73 13                	jae    9f0a <f0+0x265a>
    9ef7:	49 01 c4             	add    %rax,%r12
    9efa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9eff:	0f 84 7d 06 00 00    	je     a582 <f0+0x2cd2>
    9f05:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9f0a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9f11:	33 f3 bf 
    9f14:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    9f1b:	00 
    9f1c:	bf 01 00 00 00       	mov    $0x1,%edi
    9f21:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    9f28:	00 
    9f29:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9f30:	00 
    9f31:	e8 fa a9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9f36:	48 8b 15 fb 5b 01 00 	mov    0x15bfb(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9f3d:	49 89 c5             	mov    %rax,%r13
    9f40:	48 2b 05 c9 5b 01 00 	sub    0x15bc9(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9f47:	48 c1 e2 10          	shl    $0x10,%rdx
    9f4b:	48 39 d0             	cmp    %rdx,%rax
    9f4e:	73 59                	jae    9fa9 <f0+0x26f9>
    9f50:	48 89 c2             	mov    %rax,%rdx
    9f53:	48 c1 ea 10          	shr    $0x10,%rdx
    9f57:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f5b:	48 8b 15 f6 5b 01 00 	mov    0x15bf6(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9f62:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f66:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9f6a:	4d 85 e4             	test   %r12,%r12
    9f6d:	74 3a                	je     9fa9 <f0+0x26f9>
    9f6f:	0f b6 0a             	movzbl (%rdx),%ecx
    9f72:	80 f9 02             	cmp    $0x2,%cl
    9f75:	0f 84 55 03 00 00    	je     a2d0 <f0+0x2a20>
    9f7b:	80 f9 01             	cmp    $0x1,%cl
    9f7e:	75 29                	jne    9fa9 <f0+0x26f9>
    9f80:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f83:	0f b7 c0             	movzwl %ax,%eax
    9f86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f89:	48 0f af c1          	imul   %rcx,%rax
    9f8d:	48 c1 e8 20          	shr    $0x20,%rax
    9f91:	48 39 d0             	cmp    %rdx,%rax
    9f94:	73 13                	jae    9fa9 <f0+0x26f9>
    9f96:	49 01 c4             	add    %rax,%r12
    9f99:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9f9e:	0f 84 eb 05 00 00    	je     a58f <f0+0x2cdf>
    9fa4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9fa9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9fb0:	00 f0 3f 
    9fb3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    9fba:	00 
    9fbb:	bf 01 00 00 00       	mov    $0x1,%edi
    9fc0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    9fc7:	00 
    9fc8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    9fcf:	00 
    9fd0:	e8 5b a9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9fd5:	48 8b 15 5c 5b 01 00 	mov    0x15b5c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9fdc:	49 89 c5             	mov    %rax,%r13
    9fdf:	48 2b 05 2a 5b 01 00 	sub    0x15b2a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9fe6:	48 c1 e2 10          	shl    $0x10,%rdx
    9fea:	48 39 d0             	cmp    %rdx,%rax
    9fed:	73 59                	jae    a048 <f0+0x2798>
    9fef:	48 89 c2             	mov    %rax,%rdx
    9ff2:	48 c1 ea 10          	shr    $0x10,%rdx
    9ff6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ffa:	48 8b 15 57 5b 01 00 	mov    0x15b57(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    a001:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a005:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a009:	4d 85 e4             	test   %r12,%r12
    a00c:	74 3a                	je     a048 <f0+0x2798>
    a00e:	0f b6 0a             	movzbl (%rdx),%ecx
    a011:	80 f9 02             	cmp    $0x2,%cl
    a014:	0f 84 a6 02 00 00    	je     a2c0 <f0+0x2a10>
    a01a:	80 f9 01             	cmp    $0x1,%cl
    a01d:	75 29                	jne    a048 <f0+0x2798>
    a01f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a022:	0f b7 c0             	movzwl %ax,%eax
    a025:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a028:	48 0f af c1          	imul   %rcx,%rax
    a02c:	48 c1 e8 20          	shr    $0x20,%rax
    a030:	48 39 d0             	cmp    %rdx,%rax
    a033:	73 13                	jae    a048 <f0+0x2798>
    a035:	49 01 c4             	add    %rax,%r12
    a038:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a03d:	0f 84 59 05 00 00    	je     a59c <f0+0x2cec>
    a043:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a048:	48 89 ee             	mov    %rbp,%rsi
    a04b:	bf 01 00 00 00       	mov    $0x1,%edi
    a050:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a057:	33 f3 bf 
    a05a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    a061:	00 
    a062:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    a069:	00 
    a06a:	e8 c1 a8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    a06f:	48 8b 15 c2 5a 01 00 	mov    0x15ac2(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    a076:	48 89 c5             	mov    %rax,%rbp
    a079:	48 2b 05 90 5a 01 00 	sub    0x15a90(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    a080:	48 c1 e2 10          	shl    $0x10,%rdx
    a084:	48 39 d0             	cmp    %rdx,%rax
    a087:	73 59                	jae    a0e2 <f0+0x2832>
    a089:	48 89 c2             	mov    %rax,%rdx
    a08c:	48 c1 ea 10          	shr    $0x10,%rdx
    a090:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a094:	48 8b 15 bd 5a 01 00 	mov    0x15abd(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    a09b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a09f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a0a3:	4d 85 e4             	test   %r12,%r12
    a0a6:	74 3a                	je     a0e2 <f0+0x2832>
    a0a8:	0f b6 0a             	movzbl (%rdx),%ecx
    a0ab:	80 f9 02             	cmp    $0x2,%cl
    a0ae:	0f 84 fc 01 00 00    	je     a2b0 <f0+0x2a00>
    a0b4:	80 f9 01             	cmp    $0x1,%cl
    a0b7:	75 29                	jne    a0e2 <f0+0x2832>
    a0b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0bc:	0f b7 c0             	movzwl %ax,%eax
    a0bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0c2:	48 0f af c1          	imul   %rcx,%rax
    a0c6:	48 c1 e8 20          	shr    $0x20,%rax
    a0ca:	48 39 d0             	cmp    %rdx,%rax
    a0cd:	73 13                	jae    a0e2 <f0+0x2832>
    a0cf:	49 01 c4             	add    %rax,%r12
    a0d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a0d7:	0f 84 d1 02 00 00    	je     a3ae <f0+0x2afe>
    a0dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a0e2:	48 89 de             	mov    %rbx,%rsi
    a0e5:	48 89 ef             	mov    %rbp,%rdi
    a0e8:	e8 e3 c1 ff ff       	call   62d0 <fwp_hof0.constprop.0>
    a0ed:	48 89 ef             	mov    %rbp,%rdi
    a0f0:	e8 0b af ff ff       	call   5000 <fwp_drop0>
    a0f5:	48 89 df             	mov    %rbx,%rdi
    a0f8:	e8 03 af ff ff       	call   5000 <fwp_drop0>
    a0fd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    a104:	00 
    a105:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a10c:	00 00 
    a10e:	0f 85 95 04 00 00    	jne    a5a9 <f0+0x2cf9>
    a114:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    a11b:	31 c0                	xor    %eax,%eax
    a11d:	5b                   	pop    %rbx
    a11e:	5d                   	pop    %rbp
    a11f:	41 5c                	pop    %r12
    a121:	41 5d                	pop    %r13
    a123:	41 5e                	pop    %r14
    a125:	c3                   	ret
    a126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a12d:	00 00 00 
    a130:	4c 89 ef             	mov    %r13,%rdi
    a133:	e8 98 9d ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a138:	e9 2c d8 ff ff       	jmp    7969 <f0+0xb9>
    a13d:	0f 1f 00             	nopl   (%rax)
    a140:	66 85 c0             	test   %ax,%ax
    a143:	0f 85 ae f5 ff ff    	jne    96f7 <f0+0x1e47>
    a149:	e9 99 f5 ff ff       	jmp    96e7 <f0+0x1e37>
    a14e:	66 90                	xchg   %ax,%ax
    a150:	66 85 c0             	test   %ax,%ax
    a153:	0f 85 ff f4 ff ff    	jne    9658 <f0+0x1da8>
    a159:	e9 ea f4 ff ff       	jmp    9648 <f0+0x1d98>
    a15e:	66 90                	xchg   %ax,%ax
    a160:	66 85 c0             	test   %ax,%ax
    a163:	0f 85 50 f4 ff ff    	jne    95b9 <f0+0x1d09>
    a169:	e9 3b f4 ff ff       	jmp    95a9 <f0+0x1cf9>
    a16e:	66 90                	xchg   %ax,%ax
    a170:	66 85 c0             	test   %ax,%ax
    a173:	0f 85 a1 f3 ff ff    	jne    951a <f0+0x1c6a>
    a179:	e9 8c f3 ff ff       	jmp    950a <f0+0x1c5a>
    a17e:	66 90                	xchg   %ax,%ax
    a180:	66 85 c0             	test   %ax,%ax
    a183:	0f 85 f2 f2 ff ff    	jne    947b <f0+0x1bcb>
    a189:	e9 dd f2 ff ff       	jmp    946b <f0+0x1bbb>
    a18e:	66 90                	xchg   %ax,%ax
    a190:	66 85 c0             	test   %ax,%ax
    a193:	0f 85 43 f2 ff ff    	jne    93dc <f0+0x1b2c>
    a199:	e9 2e f2 ff ff       	jmp    93cc <f0+0x1b1c>
    a19e:	66 90                	xchg   %ax,%ax
    a1a0:	66 85 c0             	test   %ax,%ax
    a1a3:	0f 85 94 f1 ff ff    	jne    933d <f0+0x1a8d>
    a1a9:	e9 7f f1 ff ff       	jmp    932d <f0+0x1a7d>
    a1ae:	66 90                	xchg   %ax,%ax
    a1b0:	66 85 c0             	test   %ax,%ax
    a1b3:	0f 85 e5 f0 ff ff    	jne    929e <f0+0x19ee>
    a1b9:	e9 d0 f0 ff ff       	jmp    928e <f0+0x19de>
    a1be:	66 90                	xchg   %ax,%ax
    a1c0:	66 85 c0             	test   %ax,%ax
    a1c3:	0f 85 fd d9 ff ff    	jne    7bc6 <f0+0x316>
    a1c9:	e9 e8 d9 ff ff       	jmp    7bb6 <f0+0x306>
    a1ce:	66 90                	xchg   %ax,%ax
    a1d0:	66 85 c0             	test   %ax,%ax
    a1d3:	0f 85 57 d9 ff ff    	jne    7b30 <f0+0x280>
    a1d9:	e9 42 d9 ff ff       	jmp    7b20 <f0+0x270>
    a1de:	66 90                	xchg   %ax,%ax
    a1e0:	66 85 c0             	test   %ax,%ax
    a1e3:	0f 85 b1 d8 ff ff    	jne    7a9a <f0+0x1ea>
    a1e9:	e9 9c d8 ff ff       	jmp    7a8a <f0+0x1da>
    a1ee:	66 90                	xchg   %ax,%ax
    a1f0:	66 85 c0             	test   %ax,%ax
    a1f3:	0f 85 0e eb ff ff    	jne    8d07 <f0+0x1457>
    a1f9:	e9 f9 ea ff ff       	jmp    8cf7 <f0+0x1447>
    a1fe:	66 90                	xchg   %ax,%ax
    a200:	66 85 c0             	test   %ax,%ax
    a203:	0f 85 5f ea ff ff    	jne    8c68 <f0+0x13b8>
    a209:	e9 4a ea ff ff       	jmp    8c58 <f0+0x13a8>
    a20e:	66 90                	xchg   %ax,%ax
    a210:	66 85 c0             	test   %ax,%ax
    a213:	0f 85 b0 e9 ff ff    	jne    8bc9 <f0+0x1319>
    a219:	e9 9b e9 ff ff       	jmp    8bb9 <f0+0x1309>
    a21e:	66 90                	xchg   %ax,%ax
    a220:	66 85 c0             	test   %ax,%ax
    a223:	0f 85 33 da ff ff    	jne    7c5c <f0+0x3ac>
    a229:	e9 1e da ff ff       	jmp    7c4c <f0+0x39c>
    a22e:	66 90                	xchg   %ax,%ax
    a230:	66 85 c0             	test   %ax,%ax
    a233:	0f 85 c6 ef ff ff    	jne    91ff <f0+0x194f>
    a239:	e9 b1 ef ff ff       	jmp    91ef <f0+0x193f>
    a23e:	66 90                	xchg   %ax,%ax
    a240:	66 85 c0             	test   %ax,%ax
    a243:	0f 85 17 ef ff ff    	jne    9160 <f0+0x18b0>
    a249:	e9 02 ef ff ff       	jmp    9150 <f0+0x18a0>
    a24e:	66 90                	xchg   %ax,%ax
    a250:	66 85 c0             	test   %ax,%ax
    a253:	0f 85 68 ee ff ff    	jne    90c1 <f0+0x1811>
    a259:	e9 53 ee ff ff       	jmp    90b1 <f0+0x1801>
    a25e:	66 90                	xchg   %ax,%ax
    a260:	66 85 c0             	test   %ax,%ax
    a263:	0f 85 b9 ed ff ff    	jne    9022 <f0+0x1772>
    a269:	e9 a4 ed ff ff       	jmp    9012 <f0+0x1762>
    a26e:	66 90                	xchg   %ax,%ax
    a270:	66 85 c0             	test   %ax,%ax
    a273:	0f 85 0a ed ff ff    	jne    8f83 <f0+0x16d3>
    a279:	e9 f5 ec ff ff       	jmp    8f73 <f0+0x16c3>
    a27e:	66 90                	xchg   %ax,%ax
    a280:	66 85 c0             	test   %ax,%ax
    a283:	0f 85 5b ec ff ff    	jne    8ee4 <f0+0x1634>
    a289:	e9 46 ec ff ff       	jmp    8ed4 <f0+0x1624>
    a28e:	66 90                	xchg   %ax,%ax
    a290:	66 85 c0             	test   %ax,%ax
    a293:	0f 85 ac eb ff ff    	jne    8e45 <f0+0x1595>
    a299:	e9 97 eb ff ff       	jmp    8e35 <f0+0x1585>
    a29e:	66 90                	xchg   %ax,%ax
    a2a0:	66 85 c0             	test   %ax,%ax
    a2a3:	0f 85 fd ea ff ff    	jne    8da6 <f0+0x14f6>
    a2a9:	e9 e8 ea ff ff       	jmp    8d96 <f0+0x14e6>
    a2ae:	66 90                	xchg   %ax,%ax
    a2b0:	66 85 c0             	test   %ax,%ax
    a2b3:	0f 85 29 fe ff ff    	jne    a0e2 <f0+0x2832>
    a2b9:	e9 14 fe ff ff       	jmp    a0d2 <f0+0x2822>
    a2be:	66 90                	xchg   %ax,%ax
    a2c0:	66 85 c0             	test   %ax,%ax
    a2c3:	0f 85 7f fd ff ff    	jne    a048 <f0+0x2798>
    a2c9:	e9 6a fd ff ff       	jmp    a038 <f0+0x2788>
    a2ce:	66 90                	xchg   %ax,%ax
    a2d0:	66 85 c0             	test   %ax,%ax
    a2d3:	0f 85 d0 fc ff ff    	jne    9fa9 <f0+0x26f9>
    a2d9:	e9 bb fc ff ff       	jmp    9f99 <f0+0x26e9>
    a2de:	66 90                	xchg   %ax,%ax
    a2e0:	66 85 c0             	test   %ax,%ax
    a2e3:	0f 85 21 fc ff ff    	jne    9f0a <f0+0x265a>
    a2e9:	e9 0c fc ff ff       	jmp    9efa <f0+0x264a>
    a2ee:	66 90                	xchg   %ax,%ax
    a2f0:	66 85 c0             	test   %ax,%ax
    a2f3:	0f 85 72 fb ff ff    	jne    9e6b <f0+0x25bb>
    a2f9:	e9 5d fb ff ff       	jmp    9e5b <f0+0x25ab>
    a2fe:	66 90                	xchg   %ax,%ax
    a300:	66 85 c0             	test   %ax,%ax
    a303:	0f 85 c3 fa ff ff    	jne    9dcc <f0+0x251c>
    a309:	e9 ae fa ff ff       	jmp    9dbc <f0+0x250c>
    a30e:	66 90                	xchg   %ax,%ax
    a310:	66 85 c0             	test   %ax,%ax
    a313:	0f 85 14 fa ff ff    	jne    9d2d <f0+0x247d>
    a319:	e9 ff f9 ff ff       	jmp    9d1d <f0+0x246d>
    a31e:	66 90                	xchg   %ax,%ax
    a320:	66 85 c0             	test   %ax,%ax
    a323:	0f 85 65 f9 ff ff    	jne    9c8e <f0+0x23de>
    a329:	e9 50 f9 ff ff       	jmp    9c7e <f0+0x23ce>
    a32e:	66 90                	xchg   %ax,%ax
    a330:	66 85 c0             	test   %ax,%ax
    a333:	0f 85 b6 f8 ff ff    	jne    9bef <f0+0x233f>
    a339:	e9 a1 f8 ff ff       	jmp    9bdf <f0+0x232f>
    a33e:	66 90                	xchg   %ax,%ax
    a340:	66 85 c0             	test   %ax,%ax
    a343:	0f 85 07 f8 ff ff    	jne    9b50 <f0+0x22a0>
    a349:	e9 f2 f7 ff ff       	jmp    9b40 <f0+0x2290>
    a34e:	66 90                	xchg   %ax,%ax
    a350:	66 85 c0             	test   %ax,%ax
    a353:	0f 85 58 f7 ff ff    	jne    9ab1 <f0+0x2201>
    a359:	e9 43 f7 ff ff       	jmp    9aa1 <f0+0x21f1>
    a35e:	66 90                	xchg   %ax,%ax
    a360:	66 85 c0             	test   %ax,%ax
    a363:	0f 85 a9 f6 ff ff    	jne    9a12 <f0+0x2162>
    a369:	e9 94 f6 ff ff       	jmp    9a02 <f0+0x2152>
    a36e:	66 90                	xchg   %ax,%ax
    a370:	66 85 c0             	test   %ax,%ax
    a373:	0f 85 fa f5 ff ff    	jne    9973 <f0+0x20c3>
    a379:	e9 e5 f5 ff ff       	jmp    9963 <f0+0x20b3>
    a37e:	66 90                	xchg   %ax,%ax
    a380:	66 85 c0             	test   %ax,%ax
    a383:	0f 85 4b f5 ff ff    	jne    98d4 <f0+0x2024>
    a389:	e9 36 f5 ff ff       	jmp    98c4 <f0+0x2014>
    a38e:	66 90                	xchg   %ax,%ax
    a390:	66 85 c0             	test   %ax,%ax
    a393:	0f 85 9c f4 ff ff    	jne    9835 <f0+0x1f85>
    a399:	e9 87 f4 ff ff       	jmp    9825 <f0+0x1f75>
    a39e:	66 90                	xchg   %ax,%ax
    a3a0:	66 85 c0             	test   %ax,%ax
    a3a3:	0f 85 ed f3 ff ff    	jne    9796 <f0+0x1ee6>
    a3a9:	e9 d8 f3 ff ff       	jmp    9786 <f0+0x1ed6>
    a3ae:	4c 89 e7             	mov    %r12,%rdi
    a3b1:	e8 1a 9b ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3b6:	e9 22 fd ff ff       	jmp    a0dd <f0+0x282d>
    a3bb:	4c 89 e7             	mov    %r12,%rdi
    a3be:	e8 0d 9b ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3c3:	e9 cd d6 ff ff       	jmp    7a95 <f0+0x1e5>
    a3c8:	4c 89 e7             	mov    %r12,%rdi
    a3cb:	e8 00 9b ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3d0:	e9 56 d7 ff ff       	jmp    7b2b <f0+0x27b>
    a3d5:	4c 89 e7             	mov    %r12,%rdi
    a3d8:	e8 f3 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3dd:	e9 df d7 ff ff       	jmp    7bc1 <f0+0x311>
    a3e2:	4c 89 e7             	mov    %r12,%rdi
    a3e5:	e8 e6 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3ea:	e9 68 d8 ff ff       	jmp    7c57 <f0+0x3a7>
    a3ef:	4c 89 e7             	mov    %r12,%rdi
    a3f2:	e8 d9 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a3f7:	e9 c8 e7 ff ff       	jmp    8bc4 <f0+0x1314>
    a3fc:	4c 89 e7             	mov    %r12,%rdi
    a3ff:	e8 cc 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a404:	e9 5a e8 ff ff       	jmp    8c63 <f0+0x13b3>
    a409:	4c 89 e7             	mov    %r12,%rdi
    a40c:	e8 bf 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a411:	e9 ec e8 ff ff       	jmp    8d02 <f0+0x1452>
    a416:	4c 89 e7             	mov    %r12,%rdi
    a419:	e8 b2 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a41e:	e9 7e e9 ff ff       	jmp    8da1 <f0+0x14f1>
    a423:	4c 89 e7             	mov    %r12,%rdi
    a426:	e8 a5 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a42b:	e9 10 ea ff ff       	jmp    8e40 <f0+0x1590>
    a430:	4c 89 e7             	mov    %r12,%rdi
    a433:	e8 98 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a438:	e9 a2 ea ff ff       	jmp    8edf <f0+0x162f>
    a43d:	4c 89 e7             	mov    %r12,%rdi
    a440:	e8 8b 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a445:	e9 34 eb ff ff       	jmp    8f7e <f0+0x16ce>
    a44a:	4c 89 e7             	mov    %r12,%rdi
    a44d:	e8 7e 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a452:	e9 c6 eb ff ff       	jmp    901d <f0+0x176d>
    a457:	4c 89 e7             	mov    %r12,%rdi
    a45a:	e8 71 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a45f:	e9 58 ec ff ff       	jmp    90bc <f0+0x180c>
    a464:	4c 89 e7             	mov    %r12,%rdi
    a467:	e8 64 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a46c:	e9 ea ec ff ff       	jmp    915b <f0+0x18ab>
    a471:	4c 89 e7             	mov    %r12,%rdi
    a474:	e8 57 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a479:	e9 7c ed ff ff       	jmp    91fa <f0+0x194a>
    a47e:	4c 89 e7             	mov    %r12,%rdi
    a481:	e8 4a 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a486:	e9 0e ee ff ff       	jmp    9299 <f0+0x19e9>
    a48b:	4c 89 e7             	mov    %r12,%rdi
    a48e:	e8 3d 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a493:	e9 a0 ee ff ff       	jmp    9338 <f0+0x1a88>
    a498:	4c 89 e7             	mov    %r12,%rdi
    a49b:	e8 30 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4a0:	e9 32 ef ff ff       	jmp    93d7 <f0+0x1b27>
    a4a5:	4c 89 e7             	mov    %r12,%rdi
    a4a8:	e8 23 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4ad:	e9 c4 ef ff ff       	jmp    9476 <f0+0x1bc6>
    a4b2:	4c 89 e7             	mov    %r12,%rdi
    a4b5:	e8 16 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4ba:	e9 56 f0 ff ff       	jmp    9515 <f0+0x1c65>
    a4bf:	4c 89 e7             	mov    %r12,%rdi
    a4c2:	e8 09 9a ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4c7:	e9 e8 f0 ff ff       	jmp    95b4 <f0+0x1d04>
    a4cc:	4c 89 e7             	mov    %r12,%rdi
    a4cf:	e8 fc 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4d4:	e9 7a f1 ff ff       	jmp    9653 <f0+0x1da3>
    a4d9:	4c 89 e7             	mov    %r12,%rdi
    a4dc:	e8 ef 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4e1:	e9 0c f2 ff ff       	jmp    96f2 <f0+0x1e42>
    a4e6:	4c 89 e7             	mov    %r12,%rdi
    a4e9:	e8 e2 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4ee:	e9 9e f2 ff ff       	jmp    9791 <f0+0x1ee1>
    a4f3:	4c 89 e7             	mov    %r12,%rdi
    a4f6:	e8 d5 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a4fb:	e9 30 f3 ff ff       	jmp    9830 <f0+0x1f80>
    a500:	4c 89 e7             	mov    %r12,%rdi
    a503:	e8 c8 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a508:	e9 c2 f3 ff ff       	jmp    98cf <f0+0x201f>
    a50d:	4c 89 e7             	mov    %r12,%rdi
    a510:	e8 bb 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a515:	e9 54 f4 ff ff       	jmp    996e <f0+0x20be>
    a51a:	4c 89 e7             	mov    %r12,%rdi
    a51d:	e8 ae 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a522:	e9 e6 f4 ff ff       	jmp    9a0d <f0+0x215d>
    a527:	4c 89 e7             	mov    %r12,%rdi
    a52a:	e8 a1 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a52f:	e9 78 f5 ff ff       	jmp    9aac <f0+0x21fc>
    a534:	4c 89 e7             	mov    %r12,%rdi
    a537:	e8 94 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a53c:	e9 0a f6 ff ff       	jmp    9b4b <f0+0x229b>
    a541:	4c 89 e7             	mov    %r12,%rdi
    a544:	e8 87 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a549:	e9 9c f6 ff ff       	jmp    9bea <f0+0x233a>
    a54e:	4c 89 e7             	mov    %r12,%rdi
    a551:	e8 7a 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a556:	e9 2e f7 ff ff       	jmp    9c89 <f0+0x23d9>
    a55b:	4c 89 e7             	mov    %r12,%rdi
    a55e:	e8 6d 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a563:	e9 c0 f7 ff ff       	jmp    9d28 <f0+0x2478>
    a568:	4c 89 e7             	mov    %r12,%rdi
    a56b:	e8 60 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a570:	e9 52 f8 ff ff       	jmp    9dc7 <f0+0x2517>
    a575:	4c 89 e7             	mov    %r12,%rdi
    a578:	e8 53 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a57d:	e9 e4 f8 ff ff       	jmp    9e66 <f0+0x25b6>
    a582:	4c 89 e7             	mov    %r12,%rdi
    a585:	e8 46 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a58a:	e9 76 f9 ff ff       	jmp    9f05 <f0+0x2655>
    a58f:	4c 89 e7             	mov    %r12,%rdi
    a592:	e8 39 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a597:	e9 08 fa ff ff       	jmp    9fa4 <f0+0x26f4>
    a59c:	4c 89 e7             	mov    %r12,%rdi
    a59f:	e8 2c 99 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    a5a4:	e9 9a fa ff ff       	jmp    a043 <f0+0x2793>
    a5a9:	e8 92 7e ff ff       	call   2440 <__stack_chk_fail@plt>
    a5ae:	66 90                	xchg   %ax,%ax

000000000000a5b0 <fwp_main_thread>:
    a5b0:	f3 0f 1e fa          	endbr64
    a5b4:	41 54                	push   %r12
    a5b6:	55                   	push   %rbp
    a5b7:	53                   	push   %rbx
    a5b8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    a5bf:	8b 0d 3f 55 01 00    	mov    0x1553f(%rip),%ecx        # 1fb04 <fwp_heap+0x13a4>
    a5c5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a5cc:	00 00 
    a5ce:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    a5d5:	00 
    a5d6:	31 c0                	xor    %eax,%eax
    a5d8:	85 c9                	test   %ecx,%ecx
    a5da:	0f 84 18 07 00 00    	je     acf8 <fwp_main_thread+0x748>
    a5e0:	8b 15 22 55 01 00    	mov    0x15522(%rip),%edx        # 1fb08 <fwp_heap+0x13a8>
    a5e6:	85 d2                	test   %edx,%edx
    a5e8:	0f 85 f2 06 00 00    	jne    ace0 <fwp_main_thread+0x730>
    a5ee:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    a5f3:	31 f6                	xor    %esi,%esi
    a5f5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    a5fa:	48 c7 05 eb 3a 01 00 	movq   $0x40000000,0x13aeb(%rip)        # 1e0f0 <fwp_main_stack_size>
    a601:	00 00 00 40 
    a605:	48 89 05 ec 3a 01 00 	mov    %rax,0x13aec(%rip)        # 1e0f8 <fwp_main_stack_top>
    a60c:	48 8d 05 cd 3a 00 00 	lea    0x3acd(%rip),%rax        # e0e0 <alt.4>
    a613:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a618:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    a61f:	01 00 
    a621:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    a628:	00 
    a629:	e8 52 80 ff ff       	call   2680 <sigaltstack@plt>
    a62e:	85 c0                	test   %eax,%eax
    a630:	0f 85 03 07 00 00    	jne    ad39 <fwp_main_thread+0x789>
    a636:	31 c0                	xor    %eax,%eax
    a638:	b9 12 00 00 00       	mov    $0x12,%ecx
    a63d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    a642:	f3 48 ab             	rep stos %rax,(%rdi)
    a645:	48 8d 05 b4 85 ff ff 	lea    -0x7a4c(%rip),%rax        # 2c00 <fwp_segv>
    a64c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    a651:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    a658:	04 00 00 08 
    a65c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a661:	e8 ea 7e ff ff       	call   2550 <sigemptyset@plt>
    a666:	85 c0                	test   %eax,%eax
    a668:	0f 85 cb 06 00 00    	jne    ad39 <fwp_main_thread+0x789>
    a66e:	31 d2                	xor    %edx,%edx
    a670:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    a675:	bf 0b 00 00 00       	mov    $0xb,%edi
    a67a:	e8 61 7d ff ff       	call   23e0 <sigaction@plt>
    a67f:	85 c0                	test   %eax,%eax
    a681:	0f 85 b2 06 00 00    	jne    ad39 <fwp_main_thread+0x789>
    a687:	31 d2                	xor    %edx,%edx
    a689:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    a68e:	bf 07 00 00 00       	mov    $0x7,%edi
    a693:	e8 48 7d ff ff       	call   23e0 <sigaction@plt>
    a698:	85 c0                	test   %eax,%eax
    a69a:	0f 85 99 06 00 00    	jne    ad39 <fwp_main_thread+0x789>
    a6a0:	48 8b 05 d9 54 01 00 	mov    0x154d9(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    a6a7:	48 85 c0             	test   %rax,%rax
    a6aa:	0f 88 10 06 00 00    	js     acc0 <fwp_main_thread+0x710>
    a6b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a6b4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    a6b9:	48 8d 3d 20 8a ff ff 	lea    -0x75e0(%rip),%rdi        # 30e0 <ad_raw_report>
    a6c0:	f2 0f 11 05 38 5d 01 	movsd  %xmm0,0x15d38(%rip)        # 20400 <iteration_start_charge>
    a6c7:	00 
    a6c8:	c7 05 4e 5d 01 00 01 	movl   $0x1,0x15d4e(%rip)        # 20420 <iteration_active>
    a6cf:	00 00 00 
    a6d2:	e8 a9 08 00 00       	call   af80 <atexit>
    a6d7:	85 c0                	test   %eax,%eax
    a6d9:	0f 85 66 06 00 00    	jne    ad45 <fwp_main_thread+0x795>
    a6df:	8b 05 e3 39 00 00    	mov    0x39e3(%rip),%eax        # e0c8 <st.2>
    a6e5:	85 c0                	test   %eax,%eax
    a6e7:	0f 84 1b 06 00 00    	je     ad08 <fwp_main_thread+0x758>
    a6ed:	48 8b 2d 4c 40 01 00 	mov    0x1404c(%rip),%rbp        # 1e740 <fwp_cur>
    a6f4:	48 85 ed             	test   %rbp,%rbp
    a6f7:	0f 84 5f 01 00 00    	je     a85c <fwp_main_thread+0x2ac>
    a6fd:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    a702:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    a706:	48 89 eb             	mov    %rbp,%rbx
    a709:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    a70e:	0f 84 41 01 00 00    	je     a855 <fwp_main_thread+0x2a5>
    a714:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    a719:	0f 84 21 02 00 00    	je     a940 <fwp_main_thread+0x390>
    a71f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a723:	0f 84 07 02 00 00    	je     a930 <fwp_main_thread+0x380>
    a729:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a72d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a731:	0f 85 89 02 00 00    	jne    a9c0 <fwp_main_thread+0x410>
    a737:	48 8b 43 60          	mov    0x60(%rbx),%rax
    a73b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a742:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a746:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a74d:	00 00 00 00 
    a751:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a758:	48 85 d2             	test   %rdx,%rdx
    a75b:	74 07                	je     a764 <fwp_main_thread+0x1b4>
    a75d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a764:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a768:	48 85 c0             	test   %rax,%rax
    a76b:	74 34                	je     a7a1 <fwp_main_thread+0x1f1>
    a76d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    a771:	48 8b 05 a0 3f 01 00 	mov    0x13fa0(%rip),%rax        # 1e718 <fwp_timers>
    a778:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    a77c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    a783:	00 00 00 00 
    a787:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    a78e:	48 85 c0             	test   %rax,%rax
    a791:	74 07                	je     a79a <fwp_main_thread+0x1ea>
    a793:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    a79a:	48 89 1d 77 3f 01 00 	mov    %rbx,0x13f77(%rip)        # 1e718 <fwp_timers>
    a7a1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    a7a5:	e8 a6 a6 ff ff       	call   4e50 <fwp_block>
    a7aa:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    a7b1:	48 85 c9             	test   %rcx,%rcx
    a7b4:	74 47                	je     a7fd <fwp_main_thread+0x24d>
    a7b6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    a7bd:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    a7c4:	48 85 d2             	test   %rdx,%rdx
    a7c7:	0f 84 33 02 00 00    	je     aa00 <fwp_main_thread+0x450>
    a7cd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    a7d4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    a7db:	48 85 c0             	test   %rax,%rax
    a7de:	74 07                	je     a7e7 <fwp_main_thread+0x237>
    a7e0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    a7e7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    a7ee:	00 00 00 00 
    a7f2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a7f6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    a7fd:	48 8b 0d 3c 3f 01 00 	mov    0x13f3c(%rip),%rcx        # 1e740 <fwp_cur>
    a804:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    a808:	0f 84 a2 01 00 00    	je     a9b0 <fwp_main_thread+0x400>
    a80e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    a815:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    a81c:	48 85 d2             	test   %rdx,%rdx
    a81f:	0f 84 db 03 00 00    	je     ac00 <fwp_main_thread+0x650>
    a825:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    a82c:	48 85 c0             	test   %rax,%rax
    a82f:	74 07                	je     a838 <fwp_main_thread+0x288>
    a831:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    a838:	66 0f ef db          	pxor   %xmm3,%xmm3
    a83c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    a840:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    a847:	48 89 cb             	mov    %rcx,%rbx
    a84a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    a84f:	0f 85 bf fe ff ff    	jne    a714 <fwp_main_thread+0x164>
    a855:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    a859:	48 89 dd             	mov    %rbx,%rbp
    a85c:	48 83 3d 6c 5b 01 00 	cmpq   $0x0,0x15b6c(%rip)        # 203d0 <fwp_state_len>
    a863:	00 
    a864:	0f 84 a6 03 00 00    	je     ac10 <fwp_main_thread+0x660>
    a86a:	48 8b 15 c7 3e 01 00 	mov    0x13ec7(%rip),%rdx        # 1e738 <fwp_root>
    a871:	c7 05 65 38 01 00 00 	movl   $0x0,0x13865(%rip)        # 1e0e0 <fwp_exit_code>
    a878:	00 00 00 
    a87b:	48 39 d5             	cmp    %rdx,%rbp
    a87e:	0f 85 da 04 00 00    	jne    ad5e <fwp_main_thread+0x7ae>
    a884:	48 85 d2             	test   %rdx,%rdx
    a887:	0f 84 83 01 00 00    	je     aa10 <fwp_main_thread+0x460>
    a88d:	48 8b 0d 74 3e 01 00 	mov    0x13e74(%rip),%rcx        # 1e708 <fwp_tasks_active>
    a894:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    a898:	48 85 c9             	test   %rcx,%rcx
    a89b:	0f 84 6f 01 00 00    	je     aa10 <fwp_main_thread+0x460>
    a8a1:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8ac:	00 00 00 00 
    a8b0:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    a8b4:	75 08                	jne    a8be <fwp_main_thread+0x30e>
    a8b6:	48 89 cf             	mov    %rcx,%rdi
    a8b9:	e8 32 87 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    a8be:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    a8c5:	48 85 c9             	test   %rcx,%rcx
    a8c8:	75 e6                	jne    a8b0 <fwp_main_thread+0x300>
    a8ca:	eb 31                	jmp    a8fd <fwp_main_thread+0x34d>
    a8cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a8d0:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    a8d7:	48 89 15 42 3e 01 00 	mov    %rdx,0x13e42(%rip)        # 1e720 <fwp_ready_tail>
    a8de:	e8 6d a5 ff ff       	call   4e50 <fwp_block>
    a8e3:	e8 58 a3 ff ff       	call   4c40 <fwp_free_zombie>
    a8e8:	48 83 3d 18 3e 01 00 	cmpq   $0x0,0x13e18(%rip)        # 1e708 <fwp_tasks_active>
    a8ef:	00 
    a8f0:	0f 84 1a 01 00 00    	je     aa10 <fwp_main_thread+0x460>
    a8f6:	48 8b 15 3b 3e 01 00 	mov    0x13e3b(%rip),%rdx        # 1e738 <fwp_root>
    a8fd:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    a901:	75 db                	jne    a8de <fwp_main_thread+0x32e>
    a903:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    a907:	75 d5                	jne    a8de <fwp_main_thread+0x32e>
    a909:	48 8b 05 10 3e 01 00 	mov    0x13e10(%rip),%rax        # 1e720 <fwp_ready_tail>
    a910:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    a914:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    a91b:	00 00 00 00 
    a91f:	48 85 c0             	test   %rax,%rax
    a922:	75 ac                	jne    a8d0 <fwp_main_thread+0x320>
    a924:	48 89 15 fd 3d 01 00 	mov    %rdx,0x13dfd(%rip)        # 1e728 <fwp_ready_head>
    a92b:	eb aa                	jmp    a8d7 <fwp_main_thread+0x327>
    a92d:	0f 1f 00             	nopl   (%rax)
    a930:	e8 fb 88 ff ff       	call   3230 <fwp_now_ns>
    a935:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a939:	0f 8d 41 03 00 00    	jge    ac80 <fwp_main_thread+0x6d0>
    a93f:	90                   	nop
    a940:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a944:	0f 85 df fd ff ff    	jne    a729 <fwp_main_thread+0x179>
    a94a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a94e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a952:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a956:	0f 85 df fd ff ff    	jne    a73b <fwp_main_thread+0x18b>
    a95c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a960:	48 85 c9             	test   %rcx,%rcx
    a963:	0f 84 d2 fd ff ff    	je     a73b <fwp_main_thread+0x18b>
    a969:	48 85 c0             	test   %rax,%rax
    a96c:	0f 84 df 03 00 00    	je     ad51 <fwp_main_thread+0x7a1>
    a972:	48 39 c8             	cmp    %rcx,%rax
    a975:	48 0f 4f c1          	cmovg  %rcx,%rax
    a979:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a980:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a984:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a98b:	00 00 00 00 
    a98f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a996:	48 85 d2             	test   %rdx,%rdx
    a999:	74 07                	je     a9a2 <fwp_main_thread+0x3f2>
    a99b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a9a2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a9a6:	e9 c2 fd ff ff       	jmp    a76d <fwp_main_thread+0x1bd>
    a9ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a9b0:	48 89 cb             	mov    %rcx,%rbx
    a9b3:	e9 51 fd ff ff       	jmp    a709 <fwp_main_thread+0x159>
    a9b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a9bf:	00 
    a9c0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a9c4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a9cb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a9d2:	00 00 00 00 
    a9d6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a9dd:	48 85 c0             	test   %rax,%rax
    a9e0:	0f 84 4a 03 00 00    	je     ad30 <fwp_main_thread+0x780>
    a9e6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a9ed:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a9f1:	e9 ab fd ff ff       	jmp    a7a1 <fwp_main_thread+0x1f1>
    a9f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9fd:	00 00 00 
    aa00:	48 89 01             	mov    %rax,(%rcx)
    aa03:	e9 d3 fd ff ff       	jmp    a7db <fwp_main_thread+0x22b>
    aa08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa0f:	00 
    aa10:	e8 2b a2 ff ff       	call   4c40 <fwp_free_zombie>
    aa15:	48 83 3d 0b 3d 01 00 	cmpq   $0x0,0x13d0b(%rip)        # 1e728 <fwp_ready_head>
    aa1c:	00 
    aa1d:	0f 85 ed 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    aa23:	48 83 3d ed 3c 01 00 	cmpq   $0x0,0x13ced(%rip)        # 1e718 <fwp_timers>
    aa2a:	00 
    aa2b:	0f 85 df 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    aa31:	8b 1d cd 36 01 00    	mov    0x136cd(%rip),%ebx        # 1e104 <fwp_stack_pool_n>
    aa37:	85 db                	test   %ebx,%ebx
    aa39:	74 34                	je     aa6f <fwp_main_thread+0x4bf>
    aa3b:	83 eb 01             	sub    $0x1,%ebx
    aa3e:	48 8d 05 db 36 01 00 	lea    0x136db(%rip),%rax        # 1e120 <fwp_stack_pool>
    aa45:	48 63 d3             	movslq %ebx,%rdx
    aa48:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    aa4c:	eb 05                	jmp    aa53 <fwp_main_thread+0x4a3>
    aa4e:	66 90                	xchg   %ax,%ax
    aa50:	83 eb 01             	sub    $0x1,%ebx
    aa53:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    aa57:	be 00 00 00 10       	mov    $0x10000000,%esi
    aa5c:	89 1d a2 36 01 00    	mov    %ebx,0x136a2(%rip)        # 1e104 <fwp_stack_pool_n>
    aa62:	48 83 ed 08          	sub    $0x8,%rbp
    aa66:	e8 45 7b ff ff       	call   25b0 <munmap@plt>
    aa6b:	85 db                	test   %ebx,%ebx
    aa6d:	75 e1                	jne    aa50 <fwp_main_thread+0x4a0>
    aa6f:	8b 3d eb 35 00 00    	mov    0x35eb(%rip),%edi        # e060 <fwp_epfd>
    aa75:	85 ff                	test   %edi,%edi
    aa77:	78 05                	js     aa7e <fwp_main_thread+0x4ce>
    aa79:	e8 32 7a ff ff       	call   24b0 <close@plt>
    aa7e:	4c 8b 25 9b 38 01 00 	mov    0x1389b(%rip),%r12        # 1e320 <fwp_nfdws>
    aa85:	48 8b 2d 9c 38 01 00 	mov    0x1389c(%rip),%rbp        # 1e328 <fwp_fdws>
    aa8c:	31 db                	xor    %ebx,%ebx
    aa8e:	c7 05 c8 35 00 00 ff 	movl   $0xffffffff,0x35c8(%rip)        # e060 <fwp_epfd>
    aa95:	ff ff ff 
    aa98:	4d 85 e4             	test   %r12,%r12
    aa9b:	74 30                	je     aacd <fwp_main_thread+0x51d>
    aa9d:	0f 1f 00             	nopl   (%rax)
    aaa0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    aaa5:	48 85 ff             	test   %rdi,%rdi
    aaa8:	74 1a                	je     aac4 <fwp_main_thread+0x514>
    aaaa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    aaae:	0f 85 5c 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    aab4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    aab9:	0f 85 51 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    aabf:	e8 4c 96 ff ff       	call   4110 <fwp_mem_free>
    aac4:	48 83 c3 01          	add    $0x1,%rbx
    aac8:	49 39 dc             	cmp    %rbx,%r12
    aacb:	75 d3                	jne    aaa0 <fwp_main_thread+0x4f0>
    aacd:	48 89 ef             	mov    %rbp,%rdi
    aad0:	e8 3b 96 ff ff       	call   4110 <fwp_mem_free>
    aad5:	48 8b 15 5c 3c 01 00 	mov    0x13c5c(%rip),%rdx        # 1e738 <fwp_root>
    aadc:	48 c7 05 41 38 01 00 	movq   $0x0,0x13841(%rip)        # 1e328 <fwp_fdws>
    aae3:	00 00 00 00 
    aae7:	48 c7 05 2e 38 01 00 	movq   $0x0,0x1382e(%rip)        # 1e320 <fwp_nfdws>
    aaee:	00 00 00 00 
    aaf2:	48 85 d2             	test   %rdx,%rdx
    aaf5:	74 4e                	je     ab45 <fwp_main_thread+0x595>
    aaf7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    aafc:	0f 85 0e 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    ab02:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    ab09:	00 
    ab0a:	0f 85 00 7c ff ff    	jne    2710 <fwp_main_thread.cold>
    ab10:	48 83 3d b8 58 01 00 	cmpq   $0x0,0x158b8(%rip)        # 203d0 <fwp_state_len>
    ab17:	00 
    ab18:	0f 85 f2 7b ff ff    	jne    2710 <fwp_main_thread.cold>
    ab1e:	48 83 3d 9a 58 01 00 	cmpq   $0x0,0x1589a(%rip)        # 203c0 <fwp_state_owners>
    ab25:	00 
    ab26:	0f 85 e4 7b ff ff    	jne    2710 <fwp_main_thread.cold>
    ab2c:	b9 79 00 00 00       	mov    $0x79,%ecx
    ab31:	31 c0                	xor    %eax,%eax
    ab33:	48 8d 3d 06 38 01 00 	lea    0x13806(%rip),%rdi        # 1e340 <fwp_root_context>
    ab3a:	f3 48 ab             	rep stos %rax,(%rdi)
    ab3d:	48 89 d7             	mov    %rdx,%rdi
    ab40:	e8 cb 95 ff ff       	call   4110 <fwp_mem_free>
    ab45:	48 8b 05 34 50 01 00 	mov    0x15034(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    ab4c:	48 c7 05 e9 3b 01 00 	movq   $0x0,0x13be9(%rip)        # 1e740 <fwp_cur>
    ab53:	00 00 00 00 
    ab57:	48 c7 05 d6 3b 01 00 	movq   $0x0,0x13bd6(%rip)        # 1e738 <fwp_root>
    ab5e:	00 00 00 00 
    ab62:	48 c7 05 7b 35 01 00 	movq   $0x0,0x1357b(%rip)        # 1e0e8 <ad_raw_before_shutdown>
    ab69:	00 00 00 00 
    ab6d:	c7 05 a9 58 01 00 00 	movl   $0x0,0x158a9(%rip)        # 20420 <iteration_active>
    ab74:	00 00 00 
    ab77:	48 85 c0             	test   %rax,%rax
    ab7a:	0f 88 20 01 00 00    	js     aca0 <fwp_main_thread+0x6f0>
    ab80:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ab84:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    ab89:	f2 0f 5c 0d 6f 58 01 	subsd  0x1586f(%rip),%xmm1        # 20400 <iteration_start_charge>
    ab90:	00 
    ab91:	48 8b 3d 08 35 00 00 	mov    0x3508(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    ab98:	48 8d 15 a1 08 00 00 	lea    0x8a1(%rip),%rdx        # b440 <_IO_stdin_used+0x440>
    ab9f:	be 02 00 00 00       	mov    $0x2,%esi
    aba4:	f2 0f 10 05 4c 58 01 	movsd  0x1584c(%rip),%xmm0        # 203f8 <iteration_peak>
    abab:	00 
    abac:	4c 8b 0d 55 58 01 00 	mov    0x15855(%rip),%r9        # 20408 <iteration_retains>
    abb3:	b8 02 00 00 00       	mov    $0x2,%eax
    abb8:	4c 8b 05 51 58 01 00 	mov    0x15851(%rip),%r8        # 20410 <iteration_bytes>
    abbf:	48 8b 0d 52 58 01 00 	mov    0x15852(%rip),%rcx        # 20418 <iteration_requests>
    abc6:	e8 85 7a ff ff       	call   2650 <__fprintf_chk@plt>
    abcb:	48 8b 3d ae 34 00 00 	mov    0x34ae(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    abd2:	e8 b9 79 ff ff       	call   2590 <fflush@plt>
    abd7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    abde:	00 
    abdf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    abe6:	00 00 
    abe8:	0f 85 6b 01 00 00    	jne    ad59 <fwp_main_thread+0x7a9>
    abee:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    abf5:	31 c0                	xor    %eax,%eax
    abf7:	5b                   	pop    %rbx
    abf8:	5d                   	pop    %rbp
    abf9:	41 5c                	pop    %r12
    abfb:	c3                   	ret
    abfc:	0f 1f 40 00          	nopl   0x0(%rax)
    ac00:	48 89 05 11 3b 01 00 	mov    %rax,0x13b11(%rip)        # 1e718 <fwp_timers>
    ac07:	e9 20 fc ff ff       	jmp    a82c <fwp_main_thread+0x27c>
    ac0c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac10:	48 83 3d a8 57 01 00 	cmpq   $0x0,0x157a8(%rip)        # 203c0 <fwp_state_owners>
    ac17:	00 
    ac18:	0f 85 4c fc ff ff    	jne    a86a <fwp_main_thread+0x2ba>
    ac1e:	48 8b 3d b3 57 01 00 	mov    0x157b3(%rip),%rdi        # 203d8 <fwp_state>
    ac25:	e8 e6 94 ff ff       	call   4110 <fwp_mem_free>
    ac2a:	48 c7 05 a3 57 01 00 	movq   $0x0,0x157a3(%rip)        # 203d8 <fwp_state>
    ac31:	00 00 00 00 
    ac35:	48 c7 05 88 57 01 00 	movq   $0x0,0x15788(%rip)        # 203c8 <fwp_state_cap>
    ac3c:	00 00 00 00 
    ac40:	48 85 ed             	test   %rbp,%rbp
    ac43:	0f 84 21 fc ff ff    	je     a86a <fwp_main_thread+0x2ba>
    ac49:	48 8b 15 e8 3a 01 00 	mov    0x13ae8(%rip),%rdx        # 1e738 <fwp_root>
    ac50:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    ac57:	00 00 00 00 
    ac5b:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    ac62:	00 00 00 00 
    ac66:	c7 05 70 34 01 00 00 	movl   $0x0,0x13470(%rip)        # 1e0e0 <fwp_exit_code>
    ac6d:	00 00 00 
    ac70:	48 39 d5             	cmp    %rdx,%rbp
    ac73:	0f 84 14 fc ff ff    	je     a88d <fwp_main_thread+0x2dd>
    ac79:	e9 92 7a ff ff       	jmp    2710 <fwp_main_thread.cold>
    ac7e:	66 90                	xchg   %ax,%ax
    ac80:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ac84:	0f 85 b6 fc ff ff    	jne    a940 <fwp_main_thread+0x390>
    ac8a:	48 89 ef             	mov    %rbp,%rdi
    ac8d:	e8 5e 83 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    ac92:	e9 a9 fc ff ff       	jmp    a940 <fwp_main_thread+0x390>
    ac97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac9e:	00 00 
    aca0:	48 89 c2             	mov    %rax,%rdx
    aca3:	83 e0 01             	and    $0x1,%eax
    aca6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    acaa:	48 d1 ea             	shr    $1,%rdx
    acad:	48 09 c2             	or     %rax,%rdx
    acb0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    acb5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    acb9:	e9 cb fe ff ff       	jmp    ab89 <fwp_main_thread+0x5d9>
    acbe:	66 90                	xchg   %ax,%ax
    acc0:	48 89 c2             	mov    %rax,%rdx
    acc3:	83 e0 01             	and    $0x1,%eax
    acc6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    acca:	48 d1 ea             	shr    $1,%rdx
    accd:	48 09 c2             	or     %rax,%rdx
    acd0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    acd5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    acd9:	e9 db f9 ff ff       	jmp    a6b9 <fwp_main_thread+0x109>
    acde:	66 90                	xchg   %ax,%ax
    ace0:	48 8d 3d 39 8b ff ff 	lea    -0x74c7(%rip),%rdi        # 3820 <fwp_heap_report>
    ace7:	e8 94 02 00 00       	call   af80 <atexit>
    acec:	e9 fd f8 ff ff       	jmp    a5ee <fwp_main_thread+0x3e>
    acf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    acf8:	e8 33 8c ff ff       	call   3930 <fwp_heap_init>
    acfd:	e9 de f8 ff ff       	jmp    a5e0 <fwp_main_thread+0x30>
    ad02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad08:	e8 a3 cb ff ff       	call   78b0 <f0>
    ad0d:	48 c7 05 a8 33 00 00 	movq   $0x0,0x33a8(%rip)        # e0c0 <v.1>
    ad14:	00 00 00 00 
    ad18:	c7 05 a6 33 00 00 01 	movl   $0x1,0x33a6(%rip)        # e0c8 <st.2>
    ad1f:	00 00 00 
    ad22:	e9 c6 f9 ff ff       	jmp    a6ed <fwp_main_thread+0x13d>
    ad27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad2e:	00 00 
    ad30:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ad34:	e9 68 fa ff ff       	jmp    a7a1 <fwp_main_thread+0x1f1>
    ad39:	48 8d 3d d8 06 00 00 	lea    0x6d8(%rip),%rdi        # b418 <_IO_stdin_used+0x418>
    ad40:	e8 bb 84 ff ff       	call   3200 <fwp_trap>
    ad45:	48 8d 3d 62 04 00 00 	lea    0x462(%rip),%rdi        # b1ae <_IO_stdin_used+0x1ae>
    ad4c:	e8 6f 81 ff ff       	call   2ec0 <ad_raw_fail>
    ad51:	48 89 c8             	mov    %rcx,%rax
    ad54:	e9 20 fc ff ff       	jmp    a979 <fwp_main_thread+0x3c9>
    ad59:	e8 e2 76 ff ff       	call   2440 <__stack_chk_fail@plt>
    ad5e:	e9 ad 79 ff ff       	jmp    2710 <fwp_main_thread.cold>
    ad63:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad6a:	00 00 00 
    ad6d:	0f 1f 00             	nopl   (%rax)

000000000000ad70 <__divmodti4>:
    ad70:	f3 0f 1e fa          	endbr64
    ad74:	55                   	push   %rbp
    ad75:	49 89 f1             	mov    %rsi,%r9
    ad78:	49 89 d2             	mov    %rdx,%r10
    ad7b:	48 89 fe             	mov    %rdi,%rsi
    ad7e:	49 89 cb             	mov    %rcx,%r11
    ad81:	48 89 e5             	mov    %rsp,%rbp
    ad84:	41 57                	push   %r15
    ad86:	41 56                	push   %r14
    ad88:	41 55                	push   %r13
    ad8a:	41 54                	push   %r12
    ad8c:	53                   	push   %rbx
    ad8d:	4c 89 c3             	mov    %r8,%rbx
    ad90:	45 31 c0             	xor    %r8d,%r8d
    ad93:	4d 85 c9             	test   %r9,%r9
    ad96:	79 12                	jns    adaa <__divmodti4+0x3a>
    ad98:	31 ff                	xor    %edi,%edi
    ad9a:	48 f7 de             	neg    %rsi
    ad9d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    ada4:	4c 19 cf             	sbb    %r9,%rdi
    ada7:	49 89 f9             	mov    %rdi,%r9
    adaa:	4c 89 d8             	mov    %r11,%rax
    adad:	4d 85 db             	test   %r11,%r11
    adb0:	0f 88 1a 01 00 00    	js     aed0 <__divmodti4+0x160>
    adb6:	4c 89 d9             	mov    %r11,%rcx
    adb9:	49 89 f3             	mov    %rsi,%r11
    adbc:	75 62                	jne    ae20 <__divmodti4+0xb0>
    adbe:	4d 89 c4             	mov    %r8,%r12
    adc1:	4d 39 d1             	cmp    %r10,%r9
    adc4:	0f 83 46 01 00 00    	jae    af10 <__divmodti4+0x1a0>
    adca:	4c 89 d8             	mov    %r11,%rax
    adcd:	4c 89 ca             	mov    %r9,%rdx
    add0:	49 f7 f2             	div    %r10
    add3:	49 89 c3             	mov    %rax,%r11
    add6:	31 c0                	xor    %eax,%eax
    add8:	48 89 d6             	mov    %rdx,%rsi
    addb:	31 ff                	xor    %edi,%edi
    addd:	4c 89 d9             	mov    %r11,%rcx
    ade0:	48 89 c2             	mov    %rax,%rdx
    ade3:	48 89 c8             	mov    %rcx,%rax
    ade6:	4d 85 e4             	test   %r12,%r12
    ade9:	74 0a                	je     adf5 <__divmodti4+0x85>
    adeb:	48 f7 d8             	neg    %rax
    adee:	48 83 d2 00          	adc    $0x0,%rdx
    adf2:	48 f7 da             	neg    %rdx
    adf5:	4d 85 c0             	test   %r8,%r8
    adf8:	74 0a                	je     ae04 <__divmodti4+0x94>
    adfa:	48 f7 de             	neg    %rsi
    adfd:	48 83 d7 00          	adc    $0x0,%rdi
    ae01:	48 f7 df             	neg    %rdi
    ae04:	48 89 33             	mov    %rsi,(%rbx)
    ae07:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ae0b:	5b                   	pop    %rbx
    ae0c:	41 5c                	pop    %r12
    ae0e:	41 5d                	pop    %r13
    ae10:	41 5e                	pop    %r14
    ae12:	41 5f                	pop    %r15
    ae14:	5d                   	pop    %rbp
    ae15:	c3                   	ret
    ae16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae1d:	00 00 00 
    ae20:	4d 89 c4             	mov    %r8,%r12
    ae23:	49 39 c1             	cmp    %rax,%r9
    ae26:	0f 82 ce 00 00 00    	jb     aefa <__divmodti4+0x18a>
    ae2c:	31 ff                	xor    %edi,%edi
    ae2e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ae33:	48 63 c7             	movslq %edi,%rax
    ae36:	be 40 00 00 00       	mov    $0x40,%esi
    ae3b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ae40:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ae45:	48 29 c6             	sub    %rax,%rsi
    ae48:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ae4d:	48 09 c8             	or     %rcx,%rax
    ae50:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ae55:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ae5a:	49 89 c6             	mov    %rax,%r14
    ae5d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ae61:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ae66:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ae6b:	49 09 c1             	or     %rax,%r9
    ae6e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ae72:	4c 89 c8             	mov    %r9,%rax
    ae75:	49 f7 f6             	div    %r14
    ae78:	48 89 d1             	mov    %rdx,%rcx
    ae7b:	49 89 c3             	mov    %rax,%r11
    ae7e:	49 89 c1             	mov    %rax,%r9
    ae81:	49 f7 e2             	mul    %r10
    ae84:	49 89 c6             	mov    %rax,%r14
    ae87:	49 89 d2             	mov    %rdx,%r10
    ae8a:	48 39 d1             	cmp    %rdx,%rcx
    ae8d:	72 07                	jb     ae96 <__divmodti4+0x126>
    ae8f:	75 17                	jne    aea8 <__divmodti4+0x138>
    ae91:	49 39 c7             	cmp    %rax,%r15
    ae94:	73 12                	jae    aea8 <__divmodti4+0x138>
    ae96:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ae9a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ae9e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    aea2:	49 89 d2             	mov    %rdx,%r10
    aea5:	49 89 c6             	mov    %rax,%r14
    aea8:	4c 89 f8             	mov    %r15,%rax
    aeab:	4c 29 f0             	sub    %r14,%rax
    aeae:	4c 19 d1             	sbb    %r10,%rcx
    aeb1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    aeb6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    aebb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    aec0:	48 09 c6             	or     %rax,%rsi
    aec3:	48 89 cf             	mov    %rcx,%rdi
    aec6:	31 c0                	xor    %eax,%eax
    aec8:	4c 89 c9             	mov    %r9,%rcx
    aecb:	e9 10 ff ff ff       	jmp    ade0 <__divmodti4+0x70>
    aed0:	4c 89 d0             	mov    %r10,%rax
    aed3:	4c 89 da             	mov    %r11,%rdx
    aed6:	4d 89 c4             	mov    %r8,%r12
    aed9:	49 89 f3             	mov    %rsi,%r11
    aedc:	48 f7 d8             	neg    %rax
    aedf:	49 f7 d4             	not    %r12
    aee2:	48 83 d2 00          	adc    $0x0,%rdx
    aee6:	49 89 c2             	mov    %rax,%r10
    aee9:	48 f7 da             	neg    %rdx
    aeec:	48 89 d1             	mov    %rdx,%rcx
    aeef:	0f 84 cc fe ff ff    	je     adc1 <__divmodti4+0x51>
    aef5:	49 39 d1             	cmp    %rdx,%r9
    aef8:	73 46                	jae    af40 <__divmodti4+0x1d0>
    aefa:	4c 89 cf             	mov    %r9,%rdi
    aefd:	31 c0                	xor    %eax,%eax
    aeff:	31 c9                	xor    %ecx,%ecx
    af01:	e9 da fe ff ff       	jmp    ade0 <__divmodti4+0x70>
    af06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    af0d:	00 00 00 
    af10:	4d 85 d2             	test   %r10,%r10
    af13:	75 0d                	jne    af22 <__divmodti4+0x1b2>
    af15:	b8 01 00 00 00       	mov    $0x1,%eax
    af1a:	31 d2                	xor    %edx,%edx
    af1c:	49 f7 f2             	div    %r10
    af1f:	49 89 c2             	mov    %rax,%r10
    af22:	4c 89 c8             	mov    %r9,%rax
    af25:	31 d2                	xor    %edx,%edx
    af27:	49 f7 f2             	div    %r10
    af2a:	49 89 c1             	mov    %rax,%r9
    af2d:	4c 89 d8             	mov    %r11,%rax
    af30:	49 f7 f2             	div    %r10
    af33:	49 89 c3             	mov    %rax,%r11
    af36:	4c 89 c8             	mov    %r9,%rax
    af39:	e9 9a fe ff ff       	jmp    add8 <__divmodti4+0x68>
    af3e:	66 90                	xchg   %ax,%ax
    af40:	45 31 f6             	xor    %r14d,%r14d
    af43:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    af48:	44 89 f7             	mov    %r14d,%edi
    af4b:	45 85 f6             	test   %r14d,%r14d
    af4e:	0f 85 df fe ff ff    	jne    ae33 <__divmodti4+0xc3>
    af54:	4c 39 ca             	cmp    %r9,%rdx
    af57:	72 17                	jb     af70 <__divmodti4+0x200>
    af59:	31 c9                	xor    %ecx,%ecx
    af5b:	48 39 c6             	cmp    %rax,%rsi
    af5e:	73 10                	jae    af70 <__divmodti4+0x200>
    af60:	4c 89 cf             	mov    %r9,%rdi
    af63:	31 c0                	xor    %eax,%eax
    af65:	e9 76 fe ff ff       	jmp    ade0 <__divmodti4+0x70>
    af6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af70:	4c 89 de             	mov    %r11,%rsi
    af73:	b9 01 00 00 00       	mov    $0x1,%ecx
    af78:	48 29 c6             	sub    %rax,%rsi
    af7b:	49 19 d1             	sbb    %rdx,%r9
    af7e:	eb e0                	jmp    af60 <__divmodti4+0x1f0>

000000000000af80 <atexit>:
    af80:	f3 0f 1e fa          	endbr64
    af84:	48 8b 15 7d 30 00 00 	mov    0x307d(%rip),%rdx        # e008 <__dso_handle>
    af8b:	31 f6                	xor    %esi,%esi
    af8d:	e9 8e 76 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000af94 <_fini>:
    af94:	f3 0f 1e fa          	endbr64
    af98:	48 83 ec 08          	sub    $0x8,%rsp
    af9c:	48 83 c4 08          	add    $0x8,%rsp
    afa0:	c3                   	ret
