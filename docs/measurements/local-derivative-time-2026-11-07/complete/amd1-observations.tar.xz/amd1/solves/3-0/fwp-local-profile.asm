
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-local-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c9 8f 00 00 	mov    0x8fc9(%rip),%rax        # afd8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 f2 8d 00 00    	push   0x8df2(%rip)        # ae18 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 f4 8d 00 00    	jmp    *0x8df4(%rip)        # ae20 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 6e 8c 00 00    	jmp    *0x8c6e(%rip)        # afe8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 9e 8a 00 00    	jmp    *0x8a9e(%rip)        # ae28 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 96 8a 00 00    	jmp    *0x8a96(%rip)        # ae30 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 8e 8a 00 00    	jmp    *0x8a8e(%rip)        # ae38 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 86 8a 00 00    	jmp    *0x8a86(%rip)        # ae40 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 7e 8a 00 00    	jmp    *0x8a7e(%rip)        # ae48 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 76 8a 00 00    	jmp    *0x8a76(%rip)        # ae50 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 6e 8a 00 00    	jmp    *0x8a6e(%rip)        # ae58 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 66 8a 00 00    	jmp    *0x8a66(%rip)        # ae60 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 5e 8a 00 00    	jmp    *0x8a5e(%rip)        # ae68 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 56 8a 00 00    	jmp    *0x8a56(%rip)        # ae70 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 4e 8a 00 00    	jmp    *0x8a4e(%rip)        # ae78 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 46 8a 00 00    	jmp    *0x8a46(%rip)        # ae80 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 3e 8a 00 00    	jmp    *0x8a3e(%rip)        # ae88 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 36 8a 00 00    	jmp    *0x8a36(%rip)        # ae90 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 2e 8a 00 00    	jmp    *0x8a2e(%rip)        # ae98 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 26 8a 00 00    	jmp    *0x8a26(%rip)        # aea0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 1e 8a 00 00    	jmp    *0x8a1e(%rip)        # aea8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 16 8a 00 00    	jmp    *0x8a16(%rip)        # aeb0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 0e 8a 00 00    	jmp    *0x8a0e(%rip)        # aeb8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 06 8a 00 00    	jmp    *0x8a06(%rip)        # aec0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 fe 89 00 00    	jmp    *0x89fe(%rip)        # aec8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 f6 89 00 00    	jmp    *0x89f6(%rip)        # aed0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 ee 89 00 00    	jmp    *0x89ee(%rip)        # aed8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 e6 89 00 00    	jmp    *0x89e6(%rip)        # aee0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 de 89 00 00    	jmp    *0x89de(%rip)        # aee8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 d6 89 00 00    	jmp    *0x89d6(%rip)        # aef0 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 ce 89 00 00    	jmp    *0x89ce(%rip)        # aef8 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 c6 89 00 00    	jmp    *0x89c6(%rip)        # af00 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 be 89 00 00    	jmp    *0x89be(%rip)        # af08 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 b6 89 00 00    	jmp    *0x89b6(%rip)        # af10 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 ae 89 00 00    	jmp    *0x89ae(%rip)        # af18 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 a6 89 00 00    	jmp    *0x89a6(%rip)        # af20 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 9e 89 00 00    	jmp    *0x899e(%rip)        # af28 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 96 89 00 00    	jmp    *0x8996(%rip)        # af30 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 8e 89 00 00    	jmp    *0x898e(%rip)        # af38 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 86 89 00 00    	jmp    *0x8986(%rip)        # af40 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 7e 89 00 00    	jmp    *0x897e(%rip)        # af48 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 76 89 00 00    	jmp    *0x8976(%rip)        # af50 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 6e 89 00 00    	jmp    *0x896e(%rip)        # af58 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 66 89 00 00    	jmp    *0x8966(%rip)        # af60 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 5e 89 00 00    	jmp    *0x895e(%rip)        # af68 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 56 89 00 00    	jmp    *0x8956(%rip)        # af70 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 4e 89 00 00    	jmp    *0x894e(%rip)        # af78 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 46 89 00 00    	jmp    *0x8946(%rip)        # af80 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 3e 89 00 00    	jmp    *0x893e(%rip)        # af88 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 36 89 00 00    	jmp    *0x8936(%rip)        # af90 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 2e 89 00 00    	jmp    *0x892e(%rip)        # af98 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 26 89 00 00    	jmp    *0x8926(%rip)        # afa0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 1e 89 00 00    	jmp    *0x891e(%rip)        # afa8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 16 89 00 00    	jmp    *0x8916(%rip)        # afb0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 0e 89 00 00    	jmp    *0x890e(%rip)        # afb8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 06 89 00 00    	jmp    *0x8906(%rip)        # afc0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 59 00 00 	lea    0x59e0(%rip),%r9        # 80b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 59 00 00 	lea    0x59dd(%rip),%r8        # 80bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 fa 0a 00 00       	call   3200 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 88 00 00 	mov    0x88e1(%rip),%rax        # b020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 12 ac 01 00 	mov    %rax,0x1ac12(%rip)        # 1d358 <fwp_prog_out>
    2746:	e8 e5 0a 00 00       	call   3230 <fwp_now_ns>
    274b:	48 8d 3d 77 5a 00 00 	lea    0x5a77(%rip),%rdi        # 81c9 <_IO_stdin_used+0x1c9>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 88 00 00 	mov    0x8866(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 fd 39 00 00 	lea    0x39fd(%rip),%rdx        # 6210 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d d1 87 00 00 	mov    0x87d1(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 88 01 00    	mov    0x18826(%rip),%eax        # 1b080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 27 59 00 00 	lea    0x5927(%rip),%rdi        # 81d2 <_IO_stdin_used+0x1d2>
    28ab:	e8 50 09 00 00       	call   3200 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 74 5c 00 00 	lea    0x5c74(%rip),%rdi        # 8530 <_IO_stdin_used+0x530>
    28bc:	e8 3f 09 00 00       	call   3200 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d 2e 5c 00 00 	lea    0x5c2e(%rip),%rdi        # 8508 <_IO_stdin_used+0x508>
    28da:	e8 21 09 00 00       	call   3200 <fwp_trap>
    28df:	48 8d 3d f2 5b 00 00 	lea    0x5bf2(%rip),%rdi        # 84d8 <_IO_stdin_used+0x4d8>
    28e6:	e8 15 09 00 00       	call   3200 <fwp_trap>
    28eb:	48 8d 3d be 5b 00 00 	lea    0x5bbe(%rip),%rdi        # 84b0 <_IO_stdin_used+0x4b0>
    28f2:	e8 09 09 00 00       	call   3200 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 a3 86 00 00    	call   *0x86a3(%rip)        # afc8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 86 00 00 	lea    0x86e1(%rip),%rdi        # b018 <__TMC_END__>
    2937:	48 8d 05 da 86 00 00 	lea    0x86da(%rip),%rax        # b018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 86 86 00 00 	mov    0x8686(%rip),%rax        # afd0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 86 00 00 	lea    0x86b1(%rip),%rdi        # b018 <__TMC_END__>
    2967:	48 8d 35 aa 86 00 00 	lea    0x86aa(%rip),%rsi        # b018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 55 86 00 00 	mov    0x8655(%rip),%rax        # afe0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d 86 00 00 00 	cmpb   $0x0,0x869d(%rip)        # b048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 32 86 00 00 	cmpq   $0x0,0x8632(%rip)        # afe8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 86 00 00 	mov    0x8646(%rip),%rdi        # b008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 86 00 00 01 	movb   $0x1,0x8675(%rip)        # b048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d 91 a7 01 00 	mov    0x1a791(%rip),%rdi        # 1d358 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d 44 84 00 00 	mov    0x8444(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 31 84 00 00 	mov    0x8431(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_segv>:
    2c00:	f3 0f 1e fa          	endbr64
    2c04:	48 83 ec 28          	sub    $0x28,%rsp
    2c08:	48 8b 05 d1 8a 01 00 	mov    0x18ad1(%rip),%rax        # 1b6e0 <fwp_cur>
    2c0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c13:	41 89 f8             	mov    %edi,%r8d
    2c16:	48 85 c0             	test   %rax,%rax
    2c19:	74 6d                	je     2c88 <fwp_segv+0x88>
    2c1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c1f:	48 85 d2             	test   %rdx,%rdx
    2c22:	74 64                	je     2c88 <fwp_segv+0x88>
    2c24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c37:	e8 c4 f9 ff ff       	call   2600 <sysconf@plt>
    2c3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c4b:	48 01 d0             	add    %rdx,%rax
    2c4e:	48 39 c1             	cmp    %rax,%rcx
    2c51:	b8 00 00 00 00       	mov    $0x0,%eax
    2c56:	40 0f 92 c6          	setb   %sil
    2c5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2c61:	48 0f 42 d0          	cmovb  %rax,%rdx
    2c65:	31 c0                	xor    %eax,%eax
    2c67:	48 39 d1             	cmp    %rdx,%rcx
    2c6a:	0f 93 c0             	setae  %al
    2c6d:	21 f0                	and    %esi,%eax
    2c6f:	85 c0                	test   %eax,%eax
    2c71:	75 4a                	jne    2cbd <fwp_segv+0xbd>
    2c73:	31 f6                	xor    %esi,%esi
    2c75:	44 89 c7             	mov    %r8d,%edi
    2c78:	48 83 c4 28          	add    $0x28,%rsp
    2c7c:	e9 9f f8 ff ff       	jmp    2520 <signal@plt>
    2c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2c88:	48 8b 05 09 84 01 00 	mov    0x18409(%rip),%rax        # 1b098 <fwp_main_stack_top>
    2c8f:	48 85 c0             	test   %rax,%rax
    2c92:	74 df                	je     2c73 <fwp_segv+0x73>
    2c94:	48 2b 05 f5 83 01 00 	sub    0x183f5(%rip),%rax        # 1b090 <fwp_main_stack_size>
    2c9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ca2:	48 39 d1             	cmp    %rdx,%rcx
    2ca5:	0f 93 c2             	setae  %dl
    2ca8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cae:	48 39 c1             	cmp    %rax,%rcx
    2cb1:	0f 92 c0             	setb   %al
    2cb4:	0f b6 c0             	movzbl %al,%eax
    2cb7:	21 d0                	and    %edx,%eax
    2cb9:	85 c0                	test   %eax,%eax
    2cbb:	74 b6                	je     2c73 <fwp_segv+0x73>
    2cbd:	e8 fe fe ff ff       	call   2bc0 <fwp_flush>
    2cc2:	bf 02 00 00 00       	mov    $0x2,%edi
    2cc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2ccc:	48 8d 35 fd 58 00 00 	lea    0x58fd(%rip),%rsi        # 85d0 <msg.3>
    2cd3:	e8 38 f7 ff ff       	call   2410 <write@plt>
    2cd8:	bf 65 00 00 00       	mov    $0x65,%edi
    2cdd:	e8 de f6 ff ff       	call   23c0 <_exit@plt>
    2ce2:	0f 1f 00             	nopl   (%rax)
    2ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cec:	00 00 00 00 

0000000000002cf0 <fwp_heap_oom>:
    2cf0:	50                   	push   %rax
    2cf1:	58                   	pop    %rax
    2cf2:	ba 13 00 00 00       	mov    $0x13,%edx
    2cf7:	be 01 00 00 00       	mov    $0x1,%esi
    2cfc:	48 8d 3d 05 53 00 00 	lea    0x5305(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2d03:	48 83 ec 08          	sub    $0x8,%rsp
    2d07:	48 8b 0d 32 83 00 00 	mov    0x8332(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    2d0e:	e8 2d f9 ff ff       	call   2640 <fwrite@plt>
    2d13:	31 ff                	xor    %edi,%edi
    2d15:	e8 76 f8 ff ff       	call   2590 <fflush@plt>
    2d1a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d1f:	e8 3c f9 ff ff       	call   2660 <_Exit@plt>
    2d24:	90                   	nop
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 ab 9d 01 00 	mov    0x19dab(%rip),%rax        # 1caf0 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 a4 9d 01 00 	lea    0x19da4(%rip),%r8        # 1caf0 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d 85 9d 01 00 	mov    0x19d85(%rip),%rbx        # 1cad8 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d 95 9d 01 00 	mov    0x19d95(%rip),%rcx        # 1caf8 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 31 9d 01 00 	mov    0x19d31(%rip),%rdi        # 1cae0 <fwp_heap+0x13e0>
    2daf:	48 29 35 7a 9d 01 00 	sub    %rsi,0x19d7a(%rip)        # 1cb30 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 0a 9d 01 00 	mov    0x19d0a(%rip),%rax        # 1cad0 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d c0 9c 01 00 	add    0x19cc0(%rip),%rdi        # 1cab0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 ce 9c 01 00 	mov    0x19cce(%rip),%rsi        # 1cae0 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 dc 9c 01 00 	mov    0x19cdc(%rip),%rax        # 1caf8 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 8b 9c 01 00 	mov    %r12,0x19c8b(%rip)        # 1cae0 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d 79 9c 01 00 	mov    %rbp,0x19c79(%rip)        # 1cad8 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 5e 9c 01 00 	cmp    %rdi,0x19c5e(%rip)        # 1cac8 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 55 9c 01 00 	mov    %rdi,0x19c55(%rip)        # 1cac8 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d 99 9c 01 00 	sub    %rdi,0x19c99(%rip)        # 1cb30 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 41 9c 01 00 	mov    0x19c41(%rip),%rax        # 1cae8 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 3a 9c 01 00 	lea    0x19c3a(%rip),%r8        # 1cae8 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 31 fe ff ff       	call   2cf0 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <ad_raw_fail>:
    2ec0:	50                   	push   %rax
    2ec1:	58                   	pop    %rax
    2ec2:	48 8d 15 2f 53 00 00 	lea    0x532f(%rip),%rdx        # 81f8 <_IO_stdin_used+0x1f8>
    2ec9:	be 02 00 00 00       	mov    $0x2,%esi
    2ece:	31 c0                	xor    %eax,%eax
    2ed0:	48 83 ec 08          	sub    $0x8,%rsp
    2ed4:	48 89 f9             	mov    %rdi,%rcx
    2ed7:	48 8b 3d 62 81 00 00 	mov    0x8162(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    2ede:	e8 6d f7 ff ff       	call   2650 <__fprintf_chk@plt>
    2ee3:	bf e8 00 00 00       	mov    $0xe8,%edi
    2ee8:	e8 43 f7 ff ff       	call   2630 <exit@plt>
    2eed:	0f 1f 00             	nopl   (%rax)

0000000000002ef0 <buf_grow>:
    2ef0:	48 83 ec 18          	sub    $0x18,%rsp
    2ef4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ef8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2efc:	74 7e                	je     2f7c <buf_grow+0x8c>
    2efe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f05:	48 29 c2             	sub    %rax,%rdx
    2f08:	48 39 f2             	cmp    %rsi,%rdx
    2f0b:	72 6f                	jb     2f7c <buf_grow+0x8c>
    2f0d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f12:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f16:	48 89 f9             	mov    %rdi,%rcx
    2f19:	48 39 d0             	cmp    %rdx,%rax
    2f1c:	73 48                	jae    2f66 <buf_grow+0x76>
    2f1e:	48 85 c0             	test   %rax,%rax
    2f21:	75 15                	jne    2f38 <buf_grow+0x48>
    2f23:	48 83 fa 40          	cmp    $0x40,%rdx
    2f27:	76 4c                	jbe    2f75 <buf_grow+0x85>
    2f29:	b8 40 00 00 00       	mov    $0x40,%eax
    2f2e:	eb 08                	jmp    2f38 <buf_grow+0x48>
    2f30:	48 01 c0             	add    %rax,%rax
    2f33:	48 39 d0             	cmp    %rdx,%rax
    2f36:	73 38                	jae    2f70 <buf_grow+0x80>
    2f38:	48 85 c0             	test   %rax,%rax
    2f3b:	79 f3                	jns    2f30 <buf_grow+0x40>
    2f3d:	48 8b 39             	mov    (%rcx),%rdi
    2f40:	48 89 d6             	mov    %rdx,%rsi
    2f43:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f48:	48 89 14 24          	mov    %rdx,(%rsp)
    2f4c:	e8 4f f6 ff ff       	call   25a0 <realloc@plt>
    2f51:	48 8b 14 24          	mov    (%rsp),%rdx
    2f55:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f5a:	48 85 c0             	test   %rax,%rax
    2f5d:	74 1d                	je     2f7c <buf_grow+0x8c>
    2f5f:	48 89 01             	mov    %rax,(%rcx)
    2f62:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f66:	48 83 c4 18          	add    $0x18,%rsp
    2f6a:	c3                   	ret
    2f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f70:	48 89 c2             	mov    %rax,%rdx
    2f73:	eb c8                	jmp    2f3d <buf_grow+0x4d>
    2f75:	ba 40 00 00 00       	mov    $0x40,%edx
    2f7a:	eb c1                	jmp    2f3d <buf_grow+0x4d>
    2f7c:	48 8b 0d bd 80 00 00 	mov    0x80bd(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    2f83:	ba 13 00 00 00       	mov    $0x13,%edx
    2f88:	be 01 00 00 00       	mov    $0x1,%esi
    2f8d:	48 8d 3d 74 50 00 00 	lea    0x5074(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2f94:	e8 a7 f6 ff ff       	call   2640 <fwrite@plt>
    2f99:	31 ff                	xor    %edi,%edi
    2f9b:	e8 f0 f5 ff ff       	call   2590 <fflush@plt>
    2fa0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fa5:	e8 b6 f6 ff ff       	call   2660 <_Exit@plt>
    2faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002fb0 <buf_put>:
    2fb0:	41 54                	push   %r12
    2fb2:	49 89 f4             	mov    %rsi,%r12
    2fb5:	48 89 d6             	mov    %rdx,%rsi
    2fb8:	55                   	push   %rbp
    2fb9:	48 89 fd             	mov    %rdi,%rbp
    2fbc:	53                   	push   %rbx
    2fbd:	48 89 d3             	mov    %rdx,%rbx
    2fc0:	e8 2b ff ff ff       	call   2ef0 <buf_grow>
    2fc5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2fc9:	48 89 da             	mov    %rbx,%rdx
    2fcc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fd0:	4c 89 e6             	mov    %r12,%rsi
    2fd3:	e8 98 f5 ff ff       	call   2570 <memcpy@plt>
    2fd8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fdc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fe0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fe4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fe8:	5b                   	pop    %rbx
    2fe9:	5d                   	pop    %rbp
    2fea:	41 5c                	pop    %r12
    2fec:	c3                   	ret
    2fed:	0f 1f 00             	nopl   (%rax)

0000000000002ff0 <fwp_cancel_tree.part.0>:
    2ff0:	48 3b 3d e9 86 01 00 	cmp    0x186e9(%rip),%rdi        # 1b6e0 <fwp_cur>
    2ff7:	53                   	push   %rbx
    2ff8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2ffc:	74 35                	je     3033 <fwp_cancel_tree.part.0+0x43>
    2ffe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3002:	75 2f                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    3004:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3008:	75 29                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    300a:	48 8b 05 af 86 01 00 	mov    0x186af(%rip),%rax        # 1b6c0 <fwp_ready_tail>
    3011:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3015:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    301c:	00 00 00 00 
    3020:	48 85 c0             	test   %rax,%rax
    3023:	74 33                	je     3058 <fwp_cancel_tree.part.0+0x68>
    3025:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    302c:	48 89 3d 8d 86 01 00 	mov    %rdi,0x1868d(%rip)        # 1b6c0 <fwp_ready_tail>
    3033:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3037:	48 85 db             	test   %rbx,%rbx
    303a:	74 17                	je     3053 <fwp_cancel_tree.part.0+0x63>
    303c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3040:	75 08                	jne    304a <fwp_cancel_tree.part.0+0x5a>
    3042:	48 89 df             	mov    %rbx,%rdi
    3045:	e8 a6 ff ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    304a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    304e:	48 85 db             	test   %rbx,%rbx
    3051:	75 e9                	jne    303c <fwp_cancel_tree.part.0+0x4c>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	48 89 3d 69 86 01 00 	mov    %rdi,0x18669(%rip)        # 1b6c8 <fwp_ready_head>
    305f:	eb cb                	jmp    302c <fwp_cancel_tree.part.0+0x3c>
    3061:	0f 1f 40 00          	nopl   0x0(%rax)
    3065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    306c:	00 00 00 00 

0000000000003070 <fwp_finish_float>:
    3070:	53                   	push   %rbx
    3071:	be 2e 00 00 00       	mov    $0x2e,%esi
    3076:	48 89 fb             	mov    %rdi,%rbx
    3079:	e8 e2 f3 ff ff       	call   2460 <strchr@plt>
    307e:	48 85 c0             	test   %rax,%rax
    3081:	74 05                	je     3088 <fwp_finish_float+0x18>
    3083:	5b                   	pop    %rbx
    3084:	c3                   	ret
    3085:	0f 1f 00             	nopl   (%rax)
    3088:	be 65 00 00 00       	mov    $0x65,%esi
    308d:	48 89 df             	mov    %rbx,%rdi
    3090:	e8 cb f3 ff ff       	call   2460 <strchr@plt>
    3095:	48 85 c0             	test   %rax,%rax
    3098:	75 e9                	jne    3083 <fwp_finish_float+0x13>
    309a:	48 8d 35 61 50 00 00 	lea    0x5061(%rip),%rsi        # 8102 <_IO_stdin_used+0x102>
    30a1:	48 89 df             	mov    %rbx,%rdi
    30a4:	e8 e7 f5 ff ff       	call   2690 <strstr@plt>
    30a9:	48 85 c0             	test   %rax,%rax
    30ac:	75 d5                	jne    3083 <fwp_finish_float+0x13>
    30ae:	48 8d 35 67 4f 00 00 	lea    0x4f67(%rip),%rsi        # 801c <_IO_stdin_used+0x1c>
    30b5:	48 89 df             	mov    %rbx,%rdi
    30b8:	e8 d3 f5 ff ff       	call   2690 <strstr@plt>
    30bd:	48 85 c0             	test   %rax,%rax
    30c0:	75 c1                	jne    3083 <fwp_finish_float+0x13>
    30c2:	48 89 df             	mov    %rbx,%rdi
    30c5:	e8 66 f3 ff ff       	call   2430 <strlen@plt>
    30ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    30cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30d8:	5b                   	pop    %rbx
    30d9:	c3                   	ret
    30da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030e0 <ad_raw_report>:
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	55                   	push   %rbp
    30e5:	31 c9                	xor    %ecx,%ecx
    30e7:	45 31 c9             	xor    %r9d,%r9d
    30ea:	48 8d 15 2f 51 00 00 	lea    0x512f(%rip),%rdx        # 8220 <_IO_stdin_used+0x220>
    30f1:	53                   	push   %rbx
    30f2:	be 02 00 00 00       	mov    $0x2,%esi
    30f7:	31 db                	xor    %ebx,%ebx
    30f9:	48 83 ec 38          	sub    $0x38,%rsp
    30fd:	4c 8b 05 84 7f 01 00 	mov    0x17f84(%rip),%r8        # 1b088 <ad_raw_before_shutdown>
    3104:	48 8b 3d 35 7f 00 00 	mov    0x7f35(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    310b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3112:	00 00 
    3114:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3119:	31 c0                	xor    %eax,%eax
    311b:	48 89 e5             	mov    %rsp,%rbp
    311e:	e8 2d f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3123:	48 8d 05 01 4f 00 00 	lea    0x4f01(%rip),%rax        # 802b <_IO_stdin_used+0x2b>
    312a:	f3 0f 7e 05 de 7a 00 	movq   0x7ade(%rip),%xmm0        # ac10 <d0+0x70>
    3131:	00 
    3132:	48 8d 0d 35 4f 00 00 	lea    0x4f35(%rip),%rcx        # 806e <_IO_stdin_used+0x6e>
    3139:	66 48 0f 6e c8       	movq   %rax,%xmm1
    313e:	48 8d 05 f9 4e 00 00 	lea    0x4ef9(%rip),%rax        # 803e <_IO_stdin_used+0x3e>
    3145:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3149:	66 48 0f 6e d0       	movq   %rax,%xmm2
    314e:	66 49 0f 7e c0       	movq   %xmm0,%r8
    3153:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3157:	f3 0f 7e 05 b9 7a 00 	movq   0x7ab9(%rip),%xmm0        # ac18 <d0+0x78>
    315e:	00 
    315f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3163:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3168:	6a 00                	push   $0x0
    316a:	48 8b 3d cf 7e 00 00 	mov    0x7ecf(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    3171:	45 31 c9             	xor    %r9d,%r9d
    3174:	31 c0                	xor    %eax,%eax
    3176:	6a 00                	push   $0x0
    3178:	48 8d 15 01 51 00 00 	lea    0x5101(%rip),%rdx        # 8280 <_IO_stdin_used+0x280>
    317f:	be 02 00 00 00       	mov    $0x2,%esi
    3184:	83 c3 01             	add    $0x1,%ebx
    3187:	e8 c4 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    318c:	58                   	pop    %rax
    318d:	5a                   	pop    %rdx
    318e:	83 fb 04             	cmp    $0x4,%ebx
    3191:	74 15                	je     31a8 <ad_raw_report+0xc8>
    3193:	48 83 c5 08          	add    $0x8,%rbp
    3197:	48 8d 0d 82 4e 00 00 	lea    0x4e82(%rip),%rcx        # 8020 <_IO_stdin_used+0x20>
    319e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    31a2:	eb c4                	jmp    3168 <ad_raw_report+0x88>
    31a4:	0f 1f 40 00          	nopl   0x0(%rax)
    31a8:	48 8b 0d 91 7e 00 00 	mov    0x7e91(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    31af:	ba 13 00 00 00       	mov    $0x13,%edx
    31b4:	be 01 00 00 00       	mov    $0x1,%esi
    31b9:	48 8d 3d 87 4e 00 00 	lea    0x4e87(%rip),%rdi        # 8047 <_IO_stdin_used+0x47>
    31c0:	e8 7b f4 ff ff       	call   2640 <fwrite@plt>
    31c5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    31ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    31d1:	00 00 
    31d3:	75 23                	jne    31f8 <ad_raw_report+0x118>
    31d5:	48 8b 0d 64 7e 00 00 	mov    0x7e64(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    31dc:	48 83 c4 38          	add    $0x38,%rsp
    31e0:	ba 04 00 00 00       	mov    $0x4,%edx
    31e5:	be 01 00 00 00       	mov    $0x1,%esi
    31ea:	5b                   	pop    %rbx
    31eb:	48 8d 3d 69 4e 00 00 	lea    0x4e69(%rip),%rdi        # 805b <_IO_stdin_used+0x5b>
    31f2:	5d                   	pop    %rbp
    31f3:	e9 48 f4 ff ff       	jmp    2640 <fwrite@plt>
    31f8:	e8 43 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31fd:	0f 1f 00             	nopl   (%rax)

0000000000003200 <fwp_trap>:
    3200:	53                   	push   %rbx
    3201:	48 89 fb             	mov    %rdi,%rbx
    3204:	e8 b7 f9 ff ff       	call   2bc0 <fwp_flush>
    3209:	48 89 d9             	mov    %rbx,%rcx
    320c:	be 02 00 00 00       	mov    $0x2,%esi
    3211:	31 c0                	xor    %eax,%eax
    3213:	48 8b 3d 26 7e 00 00 	mov    0x7e26(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    321a:	48 8d 15 3f 4e 00 00 	lea    0x4e3f(%rip),%rdx        # 8060 <_IO_stdin_used+0x60>
    3221:	e8 2a f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3226:	bf 65 00 00 00       	mov    $0x65,%edi
    322b:	e8 00 f4 ff ff       	call   2630 <exit@plt>

0000000000003230 <fwp_now_ns>:
    3230:	53                   	push   %rbx
    3231:	bf 01 00 00 00       	mov    $0x1,%edi
    3236:	48 83 ec 20          	sub    $0x20,%rsp
    323a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3241:	00 00 
    3243:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3248:	31 db                	xor    %ebx,%ebx
    324a:	48 89 e6             	mov    %rsp,%rsi
    324d:	e8 ae f1 ff ff       	call   2400 <clock_gettime@plt>
    3252:	85 c0                	test   %eax,%eax
    3254:	75 52                	jne    32a8 <fwp_now_ns+0x78>
    3256:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    325b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3260:	48 f7 2c 24          	imulq  (%rsp)
    3264:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    326b:	48 89 f7             	mov    %rsi,%rdi
    326e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3272:	48 01 f0             	add    %rsi,%rax
    3275:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    327c:	00 00 80 
    327f:	48 11 fa             	adc    %rdi,%rdx
    3282:	31 ff                	xor    %edi,%edi
    3284:	48 01 c6             	add    %rax,%rsi
    3287:	48 11 d7             	adc    %rdx,%rdi
    328a:	48 39 f1             	cmp    %rsi,%rcx
    328d:	48 19 fb             	sbb    %rdi,%rbx
    3290:	72 27                	jb     32b9 <fwp_now_ns+0x89>
    3292:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3297:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    329e:	00 00 
    32a0:	75 12                	jne    32b4 <fwp_now_ns+0x84>
    32a2:	48 83 c4 20          	add    $0x20,%rsp
    32a6:	5b                   	pop    %rbx
    32a7:	c3                   	ret
    32a8:	48 8d 3d c0 4d 00 00 	lea    0x4dc0(%rip),%rdi        # 806f <_IO_stdin_used+0x6f>
    32af:	e8 4c ff ff ff       	call   3200 <fwp_trap>
    32b4:	e8 87 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    32b9:	48 8d 3d 00 50 00 00 	lea    0x5000(%rip),%rdi        # 82c0 <_IO_stdin_used+0x2c0>
    32c0:	e8 3b ff ff ff       	call   3200 <fwp_trap>
    32c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    32cc:	00 00 00 00 

00000000000032d0 <fwp_format_g.constprop.0>:
    32d0:	41 57                	push   %r15
    32d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    32d7:	ba 02 00 00 00       	mov    $0x2,%edx
    32dc:	4c 8d 05 a8 4d 00 00 	lea    0x4da8(%rip),%r8        # 808b <_IO_stdin_used+0x8b>
    32e3:	41 56                	push   %r14
    32e5:	b8 01 00 00 00       	mov    $0x1,%eax
    32ea:	41 55                	push   %r13
    32ec:	41 54                	push   %r12
    32ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    32f2:	55                   	push   %rbp
    32f3:	45 89 e1             	mov    %r12d,%r9d
    32f6:	53                   	push   %rbx
    32f7:	48 89 fb             	mov    %rdi,%rbx
    32fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3301:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3308:	00 00 
    330a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3311:	00 
    3312:	41 89 f7             	mov    %esi,%r15d
    3315:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    331a:	be 40 00 00 00       	mov    $0x40,%esi
    331f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3324:	4c 89 f7             	mov    %r14,%rdi
    3327:	e8 64 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    332c:	be 65 00 00 00       	mov    $0x65,%esi
    3331:	4c 89 f7             	mov    %r14,%rdi
    3334:	e8 27 f1 ff ff       	call   2460 <strchr@plt>
    3339:	31 f6                	xor    %esi,%esi
    333b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3340:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3344:	48 89 c5             	mov    %rax,%rbp
    3347:	e8 14 f2 ff ff       	call   2560 <strtol@plt>
    334c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3351:	49 89 c0             	mov    %rax,%r8
    3354:	83 c0 05             	add    $0x5,%eax
    3357:	83 f8 15             	cmp    $0x15,%eax
    335a:	0f 87 e0 01 00 00    	ja     3540 <fwp_format_g.constprop.0+0x270>
    3360:	45 89 e5             	mov    %r12d,%r13d
    3363:	45 29 c5             	sub    %r8d,%r13d
    3366:	45 85 ed             	test   %r13d,%r13d
    3369:	0f 8e 21 01 00 00    	jle    3490 <fwp_format_g.constprop.0+0x1c0>
    336f:	41 83 ff 01          	cmp    $0x1,%r15d
    3373:	0f 84 17 01 00 00    	je     3490 <fwp_format_g.constprop.0+0x1c0>
    3379:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    337e:	31 d2                	xor    %edx,%edx
    3380:	4d 63 df             	movslq %r15d,%r11
    3383:	3c 2d                	cmp    $0x2d,%al
    3385:	0f 94 c2             	sete   %dl
    3388:	4c 29 dd             	sub    %r11,%rbp
    338b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    338f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3393:	4d 89 f1             	mov    %r14,%r9
    3396:	4d 29 d1             	sub    %r10,%r9
    3399:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    339d:	3c 2d                	cmp    $0x2d,%al
    339f:	0f 84 fb 03 00 00    	je     37a0 <fwp_format_g.constprop.0+0x4d0>
    33a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    33aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    33af:	48 89 e8             	mov    %rbp,%rax
    33b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    33ba:	49 83 c1 47          	add    $0x47,%r9
    33be:	45 85 c0             	test   %r8d,%r8d
    33c1:	0f 88 f1 02 00 00    	js     36b8 <fwp_format_g.constprop.0+0x3e8>
    33c7:	45 0f b6 12          	movzbl (%r10),%r10d
    33cb:	4d 63 e0             	movslq %r8d,%r12
    33ce:	44 88 10             	mov    %r10b,(%rax)
    33d1:	41 83 f8 07          	cmp    $0x7,%r8d
    33d5:	0f 87 2d 02 00 00    	ja     3608 <fwp_format_g.constprop.0+0x338>
    33db:	41 f6 c4 04          	test   $0x4,%r12b
    33df:	0f 85 f2 03 00 00    	jne    37d7 <fwp_format_g.constprop.0+0x507>
    33e5:	45 85 e4             	test   %r12d,%r12d
    33e8:	74 12                	je     33fc <fwp_format_g.constprop.0+0x12c>
    33ea:	45 0f b6 06          	movzbl (%r14),%r8d
    33ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    33f2:	41 f6 c4 02          	test   $0x2,%r12b
    33f6:	0f 85 03 04 00 00    	jne    37ff <fwp_format_g.constprop.0+0x52f>
    33fc:	4c 29 e1             	sub    %r12,%rcx
    33ff:	4c 01 e7             	add    %r12,%rdi
    3402:	4c 89 fa             	mov    %r15,%rdx
    3405:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    340a:	48 83 e9 01          	sub    $0x1,%rcx
    340e:	4d 63 ed             	movslq %r13d,%r13
    3411:	48 89 0c 24          	mov    %rcx,(%rsp)
    3415:	e8 26 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    341a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    341f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3423:	ba 48 00 00 00       	mov    $0x48,%edx
    3428:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    342c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3430:	4c 89 c8             	mov    %r9,%rax
    3433:	48 29 c8             	sub    %rcx,%rax
    3436:	48 39 d0             	cmp    %rdx,%rax
    3439:	48 0f 42 c2          	cmovb  %rdx,%rax
    343d:	4c 29 c9             	sub    %r9,%rcx
    3440:	4c 89 ea             	mov    %r13,%rdx
    3443:	48 01 c1             	add    %rax,%rcx
    3446:	e8 f5 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    344b:	4c 01 e8             	add    %r13,%rax
    344e:	48 29 e8             	sub    %rbp,%rax
    3451:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3456:	48 39 d0             	cmp    %rdx,%rax
    3459:	48 0f 47 c2          	cmova  %rdx,%rax
    345d:	89 c1                	mov    %eax,%ecx
    345f:	83 f8 08             	cmp    $0x8,%eax
    3462:	0f 83 18 02 00 00    	jae    3680 <fwp_format_g.constprop.0+0x3b0>
    3468:	a8 04                	test   $0x4,%al
    346a:	0f 85 54 03 00 00    	jne    37c4 <fwp_format_g.constprop.0+0x4f4>
    3470:	85 c0                	test   %eax,%eax
    3472:	74 0f                	je     3483 <fwp_format_g.constprop.0+0x1b3>
    3474:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3479:	88 13                	mov    %dl,(%rbx)
    347b:	a8 02                	test   $0x2,%al
    347d:	0f 85 6b 03 00 00    	jne    37ee <fwp_format_g.constprop.0+0x51e>
    3483:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3487:	eb 36                	jmp    34bf <fwp_format_g.constprop.0+0x1ef>
    3489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3490:	45 31 c9             	xor    %r9d,%r9d
    3493:	45 85 ed             	test   %r13d,%r13d
    3496:	4c 8d 05 fd 4b 00 00 	lea    0x4bfd(%rip),%r8        # 809a <_IO_stdin_used+0x9a>
    349d:	48 89 df             	mov    %rbx,%rdi
    34a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    34a4:	ba 02 00 00 00       	mov    $0x2,%edx
    34a9:	be 90 01 00 00       	mov    $0x190,%esi
    34ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    34b5:	b8 01 00 00 00       	mov    $0x1,%eax
    34ba:	e8 d1 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    34c4:	48 89 df             	mov    %rbx,%rdi
    34c7:	e8 94 ef ff ff       	call   2460 <strchr@plt>
    34cc:	48 85 c0             	test   %rax,%rax
    34cf:	74 3f                	je     3510 <fwp_format_g.constprop.0+0x240>
    34d1:	48 89 df             	mov    %rbx,%rdi
    34d4:	e8 57 ef ff ff       	call   2430 <strlen@plt>
    34d9:	48 85 c0             	test   %rax,%rax
    34dc:	75 0b                	jne    34e9 <fwp_format_g.constprop.0+0x219>
    34de:	eb 30                	jmp    3510 <fwp_format_g.constprop.0+0x240>
    34e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    34e4:	48 85 c0             	test   %rax,%rax
    34e7:	74 27                	je     3510 <fwp_format_g.constprop.0+0x240>
    34e9:	48 89 c2             	mov    %rax,%rdx
    34ec:	48 83 e8 01          	sub    $0x1,%rax
    34f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    34f4:	74 ea                	je     34e0 <fwp_format_g.constprop.0+0x210>
    34f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    34fb:	0f 84 6f 01 00 00    	je     3670 <fwp_format_g.constprop.0+0x3a0>
    3501:	0f 1f 40 00          	nopl   0x0(%rax)
    3505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    350c:	00 00 00 00 
    3510:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3517:	00 
    3518:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    351f:	00 00 
    3521:	0f 85 ec 02 00 00    	jne    3813 <fwp_format_g.constprop.0+0x543>
    3527:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    352e:	5b                   	pop    %rbx
    352f:	5d                   	pop    %rbp
    3530:	41 5c                	pop    %r12
    3532:	41 5d                	pop    %r13
    3534:	41 5e                	pop    %r14
    3536:	41 5f                	pop    %r15
    3538:	c3                   	ret
    3539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3540:	4c 29 f5             	sub    %r14,%rbp
    3543:	b9 40 00 00 00       	mov    $0x40,%ecx
    3548:	4c 89 f6             	mov    %r14,%rsi
    354b:	4c 89 04 24          	mov    %r8,(%rsp)
    354f:	49 89 ec             	mov    %rbp,%r12
    3552:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3557:	4c 89 e2             	mov    %r12,%rdx
    355a:	48 89 ef             	mov    %rbp,%rdi
    355d:	e8 de ef ff ff       	call   2540 <__memcpy_chk@plt>
    3562:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3568:	be 2e 00 00 00       	mov    $0x2e,%esi
    356d:	48 89 ef             	mov    %rbp,%rdi
    3570:	e8 eb ee ff ff       	call   2460 <strchr@plt>
    3575:	4c 8b 04 24          	mov    (%rsp),%r8
    3579:	48 85 c0             	test   %rax,%rax
    357c:	74 40                	je     35be <fwp_format_g.constprop.0+0x2ee>
    357e:	4d 85 e4             	test   %r12,%r12
    3581:	74 3b                	je     35be <fwp_format_g.constprop.0+0x2ee>
    3583:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3588:	eb 23                	jmp    35ad <fwp_format_g.constprop.0+0x2dd>
    358a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3591:	00 00 00 00 
    3595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    359c:	00 00 00 00 
    35a0:	c6 00 00             	movb   $0x0,(%rax)
    35a3:	48 83 e8 01          	sub    $0x1,%rax
    35a7:	49 83 ec 01          	sub    $0x1,%r12
    35ab:	74 11                	je     35be <fwp_format_g.constprop.0+0x2ee>
    35ad:	80 38 30             	cmpb   $0x30,(%rax)
    35b0:	74 ee                	je     35a0 <fwp_format_g.constprop.0+0x2d0>
    35b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    35b8:	0f 84 fb 01 00 00    	je     37b9 <fwp_format_g.constprop.0+0x4e9>
    35be:	44 89 c0             	mov    %r8d,%eax
    35c1:	ba 02 00 00 00       	mov    $0x2,%edx
    35c6:	49 89 e9             	mov    %rbp,%r9
    35c9:	be 90 01 00 00       	mov    $0x190,%esi
    35ce:	f7 d8                	neg    %eax
    35d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    35d7:	48 89 df             	mov    %rbx,%rdi
    35da:	41 0f 48 c0          	cmovs  %r8d,%eax
    35de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    35e2:	41 83 e0 02          	and    $0x2,%r8d
    35e6:	41 83 c0 2b          	add    $0x2b,%r8d
    35ea:	50                   	push   %rax
    35eb:	31 c0                	xor    %eax,%eax
    35ed:	41 50                	push   %r8
    35ef:	4c 8d 05 9a 4a 00 00 	lea    0x4a9a(%rip),%r8        # 8090 <_IO_stdin_used+0x90>
    35f6:	e8 95 ed ff ff       	call   2390 <__snprintf_chk@plt>
    35fb:	58                   	pop    %rax
    35fc:	5a                   	pop    %rdx
    35fd:	e9 0e ff ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    3602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3608:	4d 8b 06             	mov    (%r14),%r8
    360b:	48 83 c0 09          	add    $0x9,%rax
    360f:	4c 89 f2             	mov    %r14,%rdx
    3612:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3616:	4c 89 07             	mov    %r8,(%rdi)
    3619:	45 89 e0             	mov    %r12d,%r8d
    361c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3621:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3626:	49 89 f8             	mov    %rdi,%r8
    3629:	49 29 c0             	sub    %rax,%r8
    362c:	4c 29 c2             	sub    %r8,%rdx
    362f:	45 01 e0             	add    %r12d,%r8d
    3632:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3636:	41 83 f8 08          	cmp    $0x8,%r8d
    363a:	0f 82 bc fd ff ff    	jb     33fc <fwp_format_g.constprop.0+0x12c>
    3640:	48 89 0c 24          	mov    %rcx,(%rsp)
    3644:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3648:	45 31 d2             	xor    %r10d,%r10d
    364b:	45 89 d3             	mov    %r10d,%r11d
    364e:	41 83 c2 08          	add    $0x8,%r10d
    3652:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3656:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    365a:	45 39 c2             	cmp    %r8d,%r10d
    365d:	72 ec                	jb     364b <fwp_format_g.constprop.0+0x37b>
    365f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3663:	e9 94 fd ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    366f:	00 
    3670:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3675:	e9 96 fe ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3680:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3685:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3689:	48 89 ee             	mov    %rbp,%rsi
    368c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3690:	48 89 13             	mov    %rdx,(%rbx)
    3693:	89 c2                	mov    %eax,%edx
    3695:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    369a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    369f:	48 89 d9             	mov    %rbx,%rcx
    36a2:	48 29 f9             	sub    %rdi,%rcx
    36a5:	48 29 ce             	sub    %rcx,%rsi
    36a8:	01 c1                	add    %eax,%ecx
    36aa:	c1 e9 03             	shr    $0x3,%ecx
    36ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    36b0:	e9 ce fd ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    36b5:	0f 1f 00             	nopl   (%rax)
    36b8:	c6 00 30             	movb   $0x30,(%rax)
    36bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    36bf:	4c 89 fa             	mov    %r15,%rdx
    36c2:	4c 89 e9             	mov    %r13,%rcx
    36c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    36ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    36cf:	4c 89 14 24          	mov    %r10,(%rsp)
    36d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    36d8:	e8 63 ee ff ff       	call   2540 <__memcpy_chk@plt>
    36dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    36e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    36e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    36ec:	48 89 c7             	mov    %rax,%rdi
    36ef:	4c 8b 14 24          	mov    (%rsp),%r10
    36f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    36f8:	4c 89 c8             	mov    %r9,%rax
    36fb:	4c 29 e8             	sub    %r13,%rax
    36fe:	48 39 c8             	cmp    %rcx,%rax
    3701:	48 0f 42 c1          	cmovb  %rcx,%rax
    3705:	4d 29 cd             	sub    %r9,%r13
    3708:	49 01 ff             	add    %rdi,%r15
    370b:	4c 01 e8             	add    %r13,%rax
    370e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3712:	74 3d                	je     3751 <fwp_format_g.constprop.0+0x481>
    3714:	41 f7 d0             	not    %r8d
    3717:	31 f6                	xor    %esi,%esi
    3719:	ba 48 00 00 00       	mov    $0x48,%edx
    371e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3723:	48 39 d0             	cmp    %rdx,%rax
    3726:	48 0f 43 d0          	cmovae %rax,%rdx
    372a:	48 89 d1             	mov    %rdx,%rcx
    372d:	48 29 c1             	sub    %rax,%rcx
    3730:	48 83 c1 01          	add    $0x1,%rcx
    3734:	48 39 d1             	cmp    %rdx,%rcx
    3737:	48 0f 42 ca          	cmovb  %rdx,%rcx
    373b:	48 83 e8 01          	sub    $0x1,%rax
    373f:	48 83 c6 01          	add    $0x1,%rsi
    3743:	48 29 d0             	sub    %rdx,%rax
    3746:	48 01 c8             	add    %rcx,%rax
    3749:	41 39 f0             	cmp    %esi,%r8d
    374c:	7f cb                	jg     3719 <fwp_format_g.constprop.0+0x449>
    374e:	4d 01 c7             	add    %r8,%r15
    3751:	b9 48 00 00 00       	mov    $0x48,%ecx
    3756:	41 0f b6 12          	movzbl (%r10),%edx
    375a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    375e:	4c 89 f6             	mov    %r14,%rsi
    3761:	48 39 c8             	cmp    %rcx,%rax
    3764:	4c 89 1c 24          	mov    %r11,(%rsp)
    3768:	48 0f 43 c8          	cmovae %rax,%rcx
    376c:	41 88 17             	mov    %dl,(%r15)
    376f:	48 89 ca             	mov    %rcx,%rdx
    3772:	48 29 c2             	sub    %rax,%rdx
    3775:	48 83 c2 01          	add    $0x1,%rdx
    3779:	48 39 ca             	cmp    %rcx,%rdx
    377c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3780:	48 83 e8 01          	sub    $0x1,%rax
    3784:	48 29 c8             	sub    %rcx,%rax
    3787:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    378b:	49 63 d4             	movslq %r12d,%rdx
    378e:	e8 ad ed ff ff       	call   2540 <__memcpy_chk@plt>
    3793:	4c 8b 1c 24          	mov    (%rsp),%r11
    3797:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    379b:	e9 ae fc ff ff       	jmp    344e <fwp_format_g.constprop.0+0x17e>
    37a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    37a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    37aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    37af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    37b4:	e9 f9 fb ff ff       	jmp    33b2 <fwp_format_g.constprop.0+0xe2>
    37b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    37bf:	e9 fa fd ff ff       	jmp    35be <fwp_format_g.constprop.0+0x2ee>
    37c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    37c8:	89 13                	mov    %edx,(%rbx)
    37ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    37ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    37d2:	e9 ac fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37d7:	41 8b 06             	mov    (%r14),%eax
    37da:	89 07                	mov    %eax,(%rdi)
    37dc:	44 89 e0             	mov    %r12d,%eax
    37df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    37e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    37e9:	e9 0e fc ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    37ee:	89 c2                	mov    %eax,%edx
    37f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    37f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    37fa:	e9 84 fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37ff:	44 89 e0             	mov    %r12d,%eax
    3802:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3808:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    380e:	e9 e9 fb ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3813:	e8 28 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    381f:	00 

0000000000003820 <fwp_heap_report>:
    3820:	f3 0f 1e fa          	endbr64
    3824:	41 54                	push   %r12
    3826:	48 8d 3d 72 48 00 00 	lea    0x4872(%rip),%rdi        # 809f <_IO_stdin_used+0x9f>
    382d:	55                   	push   %rbp
    382e:	53                   	push   %rbx
    382f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3836:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    383d:	00 00 
    383f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3846:	00 
    3847:	48 8d 35 fc 48 00 00 	lea    0x48fc(%rip),%rsi        # 814a <_IO_stdin_used+0x14a>
    384e:	e8 9d ed ff ff       	call   25f0 <fopen@plt>
    3853:	48 85 c0             	test   %rax,%rax
    3856:	0f 84 c5 00 00 00    	je     3921 <fwp_heap_report+0x101>
    385c:	48 89 c5             	mov    %rax,%rbp
    385f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3866:	48 89 e3             	mov    %rsp,%rbx
    3869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3870:	48 89 ea             	mov    %rbp,%rdx
    3873:	be 00 01 00 00       	mov    $0x100,%esi
    3878:	48 89 df             	mov    %rbx,%rdi
    387b:	e8 60 ec ff ff       	call   24e0 <fgets@plt>
    3880:	48 85 c0             	test   %rax,%rax
    3883:	74 2b                	je     38b0 <fwp_heap_report+0x90>
    3885:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    388b:	75 e3                	jne    3870 <fwp_heap_report+0x50>
    388d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3891:	75 dd                	jne    3870 <fwp_heap_report+0x50>
    3893:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3898:	75 d6                	jne    3870 <fwp_heap_report+0x50>
    389a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    389f:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a4:	31 f6                	xor    %esi,%esi
    38a6:	e8 b5 ec ff ff       	call   2560 <strtol@plt>
    38ab:	49 89 c4             	mov    %rax,%r12
    38ae:	eb c0                	jmp    3870 <fwp_heap_report+0x50>
    38b0:	48 89 ef             	mov    %rbp,%rdi
    38b3:	e8 68 eb ff ff       	call   2420 <fclose@plt>
    38b8:	48 83 ec 08          	sub    $0x8,%rsp
    38bc:	4c 8b 0d 05 92 01 00 	mov    0x19205(%rip),%r9        # 1cac8 <fwp_heap+0x13c8>
    38c3:	4c 8b 05 5e 92 01 00 	mov    0x1925e(%rip),%r8        # 1cb28 <fwp_heap+0x1428>
    38ca:	48 8d 15 17 4a 00 00 	lea    0x4a17(%rip),%rdx        # 82e8 <_IO_stdin_used+0x2e8>
    38d1:	41 54                	push   %r12
    38d3:	48 8b 0d 46 92 01 00 	mov    0x19246(%rip),%rcx        # 1cb20 <fwp_heap+0x1420>
    38da:	be 02 00 00 00       	mov    $0x2,%esi
    38df:	b8 02 00 00 00       	mov    $0x2,%eax
    38e4:	f2 0f 10 0d 54 92 01 	movsd  0x19254(%rip),%xmm1        # 1cb40 <fwp_heap+0x1440>
    38eb:	00 
    38ec:	f2 0f 10 05 44 92 01 	movsd  0x19244(%rip),%xmm0        # 1cb38 <fwp_heap+0x1438>
    38f3:	00 
    38f4:	48 8b 3d 45 77 00 00 	mov    0x7745(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    38fb:	e8 50 ed ff ff       	call   2650 <__fprintf_chk@plt>
    3900:	58                   	pop    %rax
    3901:	5a                   	pop    %rdx
    3902:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3909:	00 
    390a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3911:	00 00 
    3913:	75 15                	jne    392a <fwp_heap_report+0x10a>
    3915:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    391c:	5b                   	pop    %rbx
    391d:	5d                   	pop    %rbp
    391e:	41 5c                	pop    %r12
    3920:	c3                   	ret
    3921:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3928:	eb 8e                	jmp    38b8 <fwp_heap_report+0x98>
    392a:	e8 11 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    392f:	90                   	nop

0000000000003930 <fwp_heap_init>:
    3930:	66 0f 6f 05 b8 4c 00 	movdqa 0x4cb8(%rip),%xmm0        # 85f0 <msg.3+0x20>
    3937:	00 
    3938:	41 54                	push   %r12
    393a:	48 8d 05 ff 8c 01 00 	lea    0x18cff(%rip),%rax        # 1c640 <fwp_heap+0xf40>
    3941:	ba 00 01 00 00       	mov    $0x100,%edx
    3946:	55                   	push   %rbp
    3947:	66 0f 6f 15 e1 4c 00 	movdqa 0x4ce1(%rip),%xmm2        # 8630 <msg.3+0x60>
    394e:	00 
    394f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3953:	53                   	push   %rbx
    3954:	0f 29 05 a5 8c 01 00 	movaps %xmm0,0x18ca5(%rip)        # 1c600 <fwp_heap+0xf00>
    395b:	66 0f 6f 05 9d 4c 00 	movdqa 0x4c9d(%rip),%xmm0        # 8600 <msg.3+0x30>
    3962:	00 
    3963:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3967:	c7 05 33 91 01 00 01 	movl   $0x1,0x19133(%rip)        # 1caa4 <fwp_heap+0x13a4>
    396e:	00 00 00 
    3971:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3976:	0f 29 05 93 8c 01 00 	movaps %xmm0,0x18c93(%rip)        # 1c610 <fwp_heap+0xf10>
    397d:	66 0f 6f 05 8b 4c 00 	movdqa 0x4c8b(%rip),%xmm0        # 8610 <msg.3+0x40>
    3984:	00 
    3985:	0f 29 05 94 8c 01 00 	movaps %xmm0,0x18c94(%rip)        # 1c620 <fwp_heap+0xf20>
    398c:	66 0f 6f 05 8c 4c 00 	movdqa 0x4c8c(%rip),%xmm0        # 8620 <msg.3+0x50>
    3993:	00 
    3994:	0f 29 05 95 8c 01 00 	movaps %xmm0,0x18c95(%rip)        # 1c630 <fwp_heap+0xf30>
    399b:	89 d3                	mov    %edx,%ebx
    399d:	66 0f 6e e2          	movd   %edx,%xmm4
    39a1:	48 83 c0 10          	add    $0x10,%rax
    39a5:	01 d2                	add    %edx,%edx
    39a7:	c1 eb 02             	shr    $0x2,%ebx
    39aa:	66 0f 6e c3          	movd   %ebx,%xmm0
    39ae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    39b3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    39b7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    39bc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    39c0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    39c4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    39c9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    39ce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    39d2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    39d7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    39db:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    39df:	48 39 c7             	cmp    %rax,%rdi
    39e2:	75 b7                	jne    399b <fwp_heap_init+0x6b>
    39e4:	4c 8d 05 15 7d 01 00 	lea    0x17d15(%rip),%r8        # 1b700 <fwp_heap>
    39eb:	31 c9                	xor    %ecx,%ecx
    39ed:	31 c0                	xor    %eax,%eax
    39ef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    39f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    39fd:	00 00 00 
    3a00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a07:	00 
    3a08:	48 39 ca             	cmp    %rcx,%rdx
    3a0b:	73 0f                	jae    3a1c <fwp_heap_init+0xec>
    3a0d:	0f 1f 00             	nopl   (%rax)
    3a10:	48 83 c0 01          	add    $0x1,%rax
    3a14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a17:	48 39 ca             	cmp    %rcx,%rdx
    3a1a:	72 f4                	jb     3a10 <fwp_heap_init+0xe0>
    3a1c:	48 83 c1 10          	add    $0x10,%rcx
    3a20:	88 07                	mov    %al,(%rdi)
    3a22:	48 83 c7 01          	add    $0x1,%rdi
    3a26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3a2d:	75 d1                	jne    3a00 <fwp_heap_init+0xd0>
    3a2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3a36:	00 00 00 
    3a39:	bd 05 00 00 00       	mov    $0x5,%ebp
    3a3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3a45:	45 31 c9             	xor    %r9d,%r9d
    3a48:	31 d2                	xor    %edx,%edx
    3a4a:	31 ff                	xor    %edi,%edi
    3a4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3a57:	4c 89 e6             	mov    %r12,%rsi
    3a5a:	e8 f1 e9 ff ff       	call   2450 <mmap@plt>
    3a5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a63:	75 13                	jne    3a78 <fwp_heap_init+0x148>
    3a65:	48 c1 eb 02          	shr    $0x2,%rbx
    3a69:	83 ed 01             	sub    $0x1,%ebp
    3a6c:	75 d0                	jne    3a3e <fwp_heap_init+0x10e>
    3a6e:	e8 7d f2 ff ff       	call   2cf0 <fwp_heap_oom>
    3a73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3a78:	48 85 c0             	test   %rax,%rax
    3a7b:	74 f1                	je     3a6e <fwp_heap_init+0x13e>
    3a7d:	48 c1 eb 10          	shr    $0x10,%rbx
    3a81:	48 89 05 30 90 01 00 	mov    %rax,0x19030(%rip)        # 1cab8 <fwp_heap+0x13b8>
    3a88:	45 31 c9             	xor    %r9d,%r9d
    3a8b:	31 d2                	xor    %edx,%edx
    3a8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3a93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3a97:	31 ff                	xor    %edi,%edi
    3a99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a9f:	66 31 c0             	xor    %ax,%ax
    3aa2:	48 c1 e6 03          	shl    $0x3,%rsi
    3aa6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3aab:	4c 89 25 0e 90 01 00 	mov    %r12,0x1900e(%rip)        # 1cac0 <fwp_heap+0x13c0>
    3ab2:	48 89 05 f7 8f 01 00 	mov    %rax,0x18ff7(%rip)        # 1cab0 <fwp_heap+0x13b0>
    3ab9:	48 89 1d 10 90 01 00 	mov    %rbx,0x19010(%rip)        # 1cad0 <fwp_heap+0x13d0>
    3ac0:	48 89 35 39 90 01 00 	mov    %rsi,0x19039(%rip)        # 1cb00 <fwp_heap+0x1400>
    3ac7:	e8 84 e9 ff ff       	call   2450 <mmap@plt>
    3acc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ad0:	74 9c                	je     3a6e <fwp_heap_init+0x13e>
    3ad2:	48 8d 3d fc 45 00 00 	lea    0x45fc(%rip),%rdi        # 80d5 <_IO_stdin_used+0xd5>
    3ad9:	48 89 05 18 90 01 00 	mov    %rax,0x19018(%rip)        # 1caf8 <fwp_heap+0x13f8>
    3ae0:	e8 9b e8 ff ff       	call   2380 <getenv@plt>
    3ae5:	48 89 c2             	mov    %rax,%rdx
    3ae8:	31 c0                	xor    %eax,%eax
    3aea:	48 85 d2             	test   %rdx,%rdx
    3aed:	74 15                	je     3b04 <fwp_heap_init+0x1d4>
    3aef:	80 3a 00             	cmpb   $0x0,(%rdx)
    3af2:	74 10                	je     3b04 <fwp_heap_init+0x1d4>
    3af4:	0f b6 02             	movzbl (%rdx),%eax
    3af7:	83 e8 30             	sub    $0x30,%eax
    3afa:	74 13                	je     3b0f <fwp_heap_init+0x1df>
    3afc:	85 c0                	test   %eax,%eax
    3afe:	0f 95 c0             	setne  %al
    3b01:	0f b6 c0             	movzbl %al,%eax
    3b04:	5b                   	pop    %rbx
    3b05:	5d                   	pop    %rbp
    3b06:	89 05 9c 8f 01 00    	mov    %eax,0x18f9c(%rip)        # 1caa8 <fwp_heap+0x13a8>
    3b0c:	41 5c                	pop    %r12
    3b0e:	c3                   	ret
    3b0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b13:	85 c0                	test   %eax,%eax
    3b15:	0f 95 c0             	setne  %al
    3b18:	0f b6 c0             	movzbl %al,%eax
    3b1b:	eb e7                	jmp    3b04 <fwp_heap_init+0x1d4>
    3b1d:	0f 1f 00             	nopl   (%rax)

0000000000003b20 <fwp_wake_io>:
    3b20:	48 8b 07             	mov    (%rdi),%rax
    3b23:	48 85 c0             	test   %rax,%rax
    3b26:	0f 84 f4 00 00 00    	je     3c20 <fwp_wake_io+0x100>
    3b2c:	53                   	push   %rbx
    3b2d:	4c 8b 05 8c 7b 01 00 	mov    0x17b8c(%rip),%r8        # 1b6c0 <fwp_ready_tail>
    3b34:	49 89 f9             	mov    %rdi,%r9
    3b37:	48 89 c2             	mov    %rax,%rdx
    3b3a:	45 31 db             	xor    %r11d,%r11d
    3b3d:	45 31 d2             	xor    %r10d,%r10d
    3b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3b44:	eb 71                	jmp    3bb7 <fwp_wake_io+0x97>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3b57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b5e:	48 85 c9             	test   %rcx,%rcx
    3b61:	74 07                	je     3b6a <fwp_wake_io+0x4a>
    3b63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3b6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3b71:	00 00 00 00 
    3b75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3b7c:	49 8b 01             	mov    (%r9),%rax
    3b7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3b83:	75 2a                	jne    3baf <fwp_wake_io+0x8f>
    3b85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3b89:	75 24                	jne    3baf <fwp_wake_io+0x8f>
    3b8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3b8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3b96:	00 00 00 00 
    3b9a:	4d 85 c0             	test   %r8,%r8
    3b9d:	74 51                	je     3bf0 <fwp_wake_io+0xd0>
    3b9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3ba6:	49 89 d0             	mov    %rdx,%r8
    3ba9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3baf:	48 89 c2             	mov    %rax,%rdx
    3bb2:	48 85 c0             	test   %rax,%rax
    3bb5:	74 49                	je     3c00 <fwp_wake_io+0xe0>
    3bb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3bbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3bc2:	48 85 ff             	test   %rdi,%rdi
    3bc5:	74 b8                	je     3b7f <fwp_wake_io+0x5f>
    3bc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3bce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bd5:	48 85 f6             	test   %rsi,%rsi
    3bd8:	0f 85 72 ff ff ff    	jne    3b50 <fwp_wake_io+0x30>
    3bde:	48 89 0f             	mov    %rcx,(%rdi)
    3be1:	e9 78 ff ff ff       	jmp    3b5e <fwp_wake_io+0x3e>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 d3             	mov    %rdx,%rbx
    3bf3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3bf9:	eb ab                	jmp    3ba6 <fwp_wake_io+0x86>
    3bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3c00:	45 84 db             	test   %r11b,%r11b
    3c03:	74 07                	je     3c0c <fwp_wake_io+0xec>
    3c05:	48 89 1d bc 7a 01 00 	mov    %rbx,0x17abc(%rip)        # 1b6c8 <fwp_ready_head>
    3c0c:	45 84 d2             	test   %r10b,%r10b
    3c0f:	74 07                	je     3c18 <fwp_wake_io+0xf8>
    3c11:	4c 89 05 a8 7a 01 00 	mov    %r8,0x17aa8(%rip)        # 1b6c0 <fwp_ready_tail>
    3c18:	5b                   	pop    %rbx
    3c19:	c3                   	ret
    3c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3c20:	c3                   	ret
    3c21:	0f 1f 40 00          	nopl   0x0(%rax)
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_poll_events>:
    3c30:	53                   	push   %rbx
    3c31:	48 83 ec 20          	sub    $0x20,%rsp
    3c35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3c3c:	00 00 
    3c3e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3c43:	31 c0                	xor    %eax,%eax
    3c45:	e8 e6 f5 ff ff       	call   3230 <fwp_now_ns>
    3c4a:	48 8b 1d 67 7a 01 00 	mov    0x17a67(%rip),%rbx        # 1b6b8 <fwp_timers>
    3c51:	48 85 db             	test   %rbx,%rbx
    3c54:	0f 84 e6 00 00 00    	je     3d40 <fwp_poll_events+0x110>
    3c5a:	48 89 c6             	mov    %rax,%rsi
    3c5d:	48 89 da             	mov    %rbx,%rdx
    3c60:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3c67:	eb 26                	jmp    3c8f <fwp_poll_events+0x5f>
    3c69:	90                   	nop
    3c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c71:	00 00 00 00 
    3c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c7c:	00 00 00 00 
    3c80:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c87:	48 89 c8             	mov    %rcx,%rax
    3c8a:	48 85 d2             	test   %rdx,%rdx
    3c8d:	74 31                	je     3cc0 <fwp_poll_events+0x90>
    3c8f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c93:	48 85 c0             	test   %rax,%rax
    3c96:	78 e8                	js     3c80 <fwp_poll_events+0x50>
    3c98:	48 39 c1             	cmp    %rax,%rcx
    3c9b:	7c e3                	jl     3c80 <fwp_poll_events+0x50>
    3c9d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3ca4:	48 85 d2             	test   %rdx,%rdx
    3ca7:	74 1c                	je     3cc5 <fwp_poll_events+0x95>
    3ca9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3cad:	48 39 c1             	cmp    %rax,%rcx
    3cb0:	7c ce                	jl     3c80 <fwp_poll_events+0x50>
    3cb2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3cb9:	48 85 d2             	test   %rdx,%rdx
    3cbc:	75 d1                	jne    3c8f <fwp_poll_events+0x5f>
    3cbe:	66 90                	xchg   %ax,%ax
    3cc0:	48 85 c0             	test   %rax,%rax
    3cc3:	78 7b                	js     3d40 <fwp_poll_events+0x110>
    3cc5:	48 29 f0             	sub    %rsi,%rax
    3cc8:	48 89 c1             	mov    %rax,%rcx
    3ccb:	48 85 c0             	test   %rax,%rax
    3cce:	0f 8e 9c 00 00 00    	jle    3d70 <fwp_poll_events+0x140>
    3cd4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3cdb:	de 1b 43 
    3cde:	48 f7 ea             	imul   %rdx
    3ce1:	48 89 c8             	mov    %rcx,%rax
    3ce4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ce8:	48 c1 fa 12          	sar    $0x12,%rdx
    3cec:	48 29 c2             	sub    %rax,%rdx
    3cef:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3cf6:	48 39 c1             	cmp    %rax,%rcx
    3cf9:	0f 95 c0             	setne  %al
    3cfc:	0f b6 c0             	movzbl %al,%eax
    3cff:	48 01 d0             	add    %rdx,%rax
    3d02:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3d08:	0f 8f 32 01 00 00    	jg     3e40 <fwp_poll_events+0x210>
    3d0e:	48 85 c0             	test   %rax,%rax
    3d11:	74 5d                	je     3d70 <fwp_poll_events+0x140>
    3d13:	89 c1                	mov    %eax,%ecx
    3d15:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3d1c:	48 c1 e9 26          	shr    $0x26,%rcx
    3d20:	48 63 d1             	movslq %ecx,%rdx
    3d23:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3d29:	29 c8                	sub    %ecx,%eax
    3d2b:	48 98                	cltq
    3d2d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3d34:	e9 11 01 00 00       	jmp    3e4a <fwp_poll_events+0x21a>
    3d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d40:	e8 7b ee ff ff       	call   2bc0 <fwp_flush>
    3d45:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3d4a:	be 01 00 00 00       	mov    $0x1,%esi
    3d4f:	48 8b 0d ea 72 00 00 	mov    0x72ea(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    3d56:	48 8d 3d 13 46 00 00 	lea    0x4613(%rip),%rdi        # 8370 <_IO_stdin_used+0x370>
    3d5d:	e8 de e8 ff ff       	call   2640 <fwrite@plt>
    3d62:	bf 65 00 00 00       	mov    $0x65,%edi
    3d67:	e8 c4 e8 ff ff       	call   2630 <exit@plt>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	e8 bb f4 ff ff       	call   3230 <fwp_now_ns>
    3d75:	48 89 c1             	mov    %rax,%rcx
    3d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3d7c:	eb 44                	jmp    3dc2 <fwp_poll_events+0x192>
    3d7e:	66 90                	xchg   %ax,%ax
    3d80:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3d84:	75 33                	jne    3db9 <fwp_poll_events+0x189>
    3d86:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8a:	75 2d                	jne    3db9 <fwp_poll_events+0x189>
    3d8c:	48 8b 05 2d 79 01 00 	mov    0x1792d(%rip),%rax        # 1b6c0 <fwp_ready_tail>
    3d93:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3d97:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3d9e:	00 00 00 00 
    3da2:	48 85 c0             	test   %rax,%rax
    3da5:	0f 84 05 01 00 00    	je     3eb0 <fwp_poll_events+0x280>
    3dab:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3db2:	48 89 15 07 79 01 00 	mov    %rdx,0x17907(%rip)        # 1b6c0 <fwp_ready_tail>
    3db9:	48 85 db             	test   %rbx,%rbx
    3dbc:	0f 84 be 00 00 00    	je     3e80 <fwp_poll_events+0x250>
    3dc2:	48 89 da             	mov    %rbx,%rdx
    3dc5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3dcc:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3dd0:	7f e7                	jg     3db9 <fwp_poll_events+0x189>
    3dd2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3dd6:	74 2e                	je     3e06 <fwp_poll_events+0x1d6>
    3dd8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3ddf:	48 85 c0             	test   %rax,%rax
    3de2:	0f 84 b8 00 00 00    	je     3ea0 <fwp_poll_events+0x270>
    3de8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3def:	48 85 db             	test   %rbx,%rbx
    3df2:	74 07                	je     3dfb <fwp_poll_events+0x1cb>
    3df4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3dfb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3dff:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3e06:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3e0a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3e0e:	48 85 c0             	test   %rax,%rax
    3e11:	0f 84 69 ff ff ff    	je     3d80 <fwp_poll_events+0x150>
    3e17:	48 39 c8             	cmp    %rcx,%rax
    3e1a:	0f 8f 60 ff ff ff    	jg     3d80 <fwp_poll_events+0x150>
    3e20:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3e24:	0f 85 56 ff ff ff    	jne    3d80 <fwp_poll_events+0x150>
    3e2a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2e:	75 89                	jne    3db9 <fwp_poll_events+0x189>
    3e30:	48 89 d7             	mov    %rdx,%rdi
    3e33:	e8 b8 f1 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    3e38:	e9 43 ff ff ff       	jmp    3d80 <fwp_poll_events+0x150>
    3e3d:	0f 1f 00             	nopl   (%rax)
    3e40:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3e45:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3e4a:	48 89 e7             	mov    %rsp,%rdi
    3e4d:	31 f6                	xor    %esi,%esi
    3e4f:	48 89 14 24          	mov    %rdx,(%rsp)
    3e53:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3e58:	e8 23 e6 ff ff       	call   2480 <nanosleep@plt>
    3e5d:	48 8b 1d 54 78 01 00 	mov    0x17854(%rip),%rbx        # 1b6b8 <fwp_timers>
    3e64:	e8 c7 f3 ff ff       	call   3230 <fwp_now_ns>
    3e69:	48 89 c1             	mov    %rax,%rcx
    3e6c:	48 85 db             	test   %rbx,%rbx
    3e6f:	0f 85 03 ff ff ff    	jne    3d78 <fwp_poll_events+0x148>
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3e85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3e8c:	00 00 
    3e8e:	75 2c                	jne    3ebc <fwp_poll_events+0x28c>
    3e90:	48 83 c4 20          	add    $0x20,%rsp
    3e94:	5b                   	pop    %rbx
    3e95:	c3                   	ret
    3e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3e9d:	00 00 00 
    3ea0:	48 89 1d 11 78 01 00 	mov    %rbx,0x17811(%rip)        # 1b6b8 <fwp_timers>
    3ea7:	e9 43 ff ff ff       	jmp    3def <fwp_poll_events+0x1bf>
    3eac:	0f 1f 40 00          	nopl   0x0(%rax)
    3eb0:	48 89 15 11 78 01 00 	mov    %rdx,0x17811(%rip)        # 1b6c8 <fwp_ready_head>
    3eb7:	e9 f6 fe ff ff       	jmp    3db2 <fwp_poll_events+0x182>
    3ebc:	e8 7f e5 ff ff       	call   2440 <__stack_chk_fail@plt>
    3ec1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ecc:	00 00 00 00 

0000000000003ed0 <fwp_rc_forget_slot>:
    3ed0:	80 3f ff             	cmpb   $0xff,(%rdi)
    3ed3:	74 0b                	je     3ee0 <fwp_rc_forget_slot+0x10>
    3ed5:	c3                   	ret
    3ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3edd:	00 00 00 
    3ee0:	48 89 f8             	mov    %rdi,%rax
    3ee3:	48 83 ec 08          	sub    $0x8,%rsp
    3ee7:	48 89 fa             	mov    %rdi,%rdx
    3eea:	48 c1 e8 11          	shr    $0x11,%rax
    3eee:	48 31 f8             	xor    %rdi,%rax
    3ef1:	48 89 c1             	mov    %rax,%rcx
    3ef4:	48 c1 e9 09          	shr    $0x9,%rcx
    3ef8:	48 31 c8             	xor    %rcx,%rax
    3efb:	48 8d 0d fe 77 01 00 	lea    0x177fe(%rip),%rcx        # 1b700 <fwp_heap>
    3f02:	0f b6 c0             	movzbl %al,%eax
    3f05:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f0c:	00 
    3f0d:	48 85 ff             	test   %rdi,%rdi
    3f10:	74 3c                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f12:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f19:	00 
    3f1a:	48 8b 01             	mov    (%rcx),%rax
    3f1d:	eb 11                	jmp    3f30 <fwp_rc_forget_slot+0x60>
    3f1f:	90                   	nop
    3f20:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3f24:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3f28:	48 85 ff             	test   %rdi,%rdi
    3f2b:	74 21                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f2d:	48 89 f8             	mov    %rdi,%rax
    3f30:	48 3b 10             	cmp    (%rax),%rdx
    3f33:	75 eb                	jne    3f20 <fwp_rc_forget_slot+0x50>
    3f35:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f39:	48 89 01             	mov    %rax,(%rcx)
    3f3c:	e8 5f e4 ff ff       	call   23a0 <free@plt>
    3f41:	48 83 2d ff 93 01 00 	subq   $0x1,0x193ff(%rip)        # 1d348 <fwp_heap+0x1c48>
    3f48:	01 
    3f49:	48 83 c4 08          	add    $0x8,%rsp
    3f4d:	c3                   	ret
    3f4e:	48 8d 3d 4b 44 00 00 	lea    0x444b(%rip),%rdi        # 83a0 <_IO_stdin_used+0x3a0>
    3f55:	e8 a6 f2 ff ff       	call   3200 <fwp_trap>
    3f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f60 <fwp_rc_prepare_chunk>:
    3f60:	48 83 3d e0 93 01 00 	cmpq   $0x0,0x193e0(%rip)        # 1d348 <fwp_heap+0x1c48>
    3f67:	00 
    3f68:	41 54                	push   %r12
    3f6a:	49 89 f4             	mov    %rsi,%r12
    3f6d:	55                   	push   %rbp
    3f6e:	48 89 fd             	mov    %rdi,%rbp
    3f71:	53                   	push   %rbx
    3f72:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3f75:	0f 84 7d 00 00 00    	je     3ff8 <fwp_rc_prepare_chunk+0x98>
    3f7b:	31 db                	xor    %ebx,%ebx
    3f7d:	85 c0                	test   %eax,%eax
    3f7f:	75 5f                	jne    3fe0 <fwp_rc_prepare_chunk+0x80>
    3f81:	48 85 f6             	test   %rsi,%rsi
    3f84:	74 7c                	je     4002 <fwp_rc_prepare_chunk+0xa2>
    3f86:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3f8a:	e8 11 e4 ff ff       	call   23a0 <free@plt>
    3f8f:	90                   	nop
    3f90:	be 01 00 00 00       	mov    $0x1,%esi
    3f95:	4c 89 e7             	mov    %r12,%rdi
    3f98:	e8 63 e5 ff ff       	call   2500 <calloc@plt>
    3f9d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3fa1:	48 85 c0             	test   %rax,%rax
    3fa4:	0f 85 87 00 00 00    	jne    4031 <fwp_rc_prepare_chunk+0xd1>
    3faa:	e8 41 ed ff ff       	call   2cf0 <fwp_heap_oom>
    3faf:	90                   	nop
    3fb0:	e8 1b ff ff ff       	call   3ed0 <fwp_rc_forget_slot>
    3fb5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fb8:	48 83 c3 01          	add    $0x1,%rbx
    3fbc:	48 39 c3             	cmp    %rax,%rbx
    3fbf:	73 37                	jae    3ff8 <fwp_rc_prepare_chunk+0x98>
    3fc1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fc8:	00 00 
    3fca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fd1:	00 00 00 00 
    3fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fdc:	00 00 00 00 
    3fe0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3fe4:	48 01 df             	add    %rbx,%rdi
    3fe7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3fea:	74 c4                	je     3fb0 <fwp_rc_prepare_chunk+0x50>
    3fec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fef:	48 83 c3 01          	add    $0x1,%rbx
    3ff3:	48 39 c3             	cmp    %rax,%rbx
    3ff6:	72 e8                	jb     3fe0 <fwp_rc_prepare_chunk+0x80>
    3ff8:	49 39 c4             	cmp    %rax,%r12
    3ffb:	75 13                	jne    4010 <fwp_rc_prepare_chunk+0xb0>
    3ffd:	4d 85 e4             	test   %r12,%r12
    4000:	75 46                	jne    4048 <fwp_rc_prepare_chunk+0xe8>
    4002:	5b                   	pop    %rbx
    4003:	5d                   	pop    %rbp
    4004:	41 5c                	pop    %r12
    4006:	c3                   	ret
    4007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    400e:	00 00 
    4010:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4014:	48 29 05 35 93 01 00 	sub    %rax,0x19335(%rip)        # 1d350 <fwp_heap+0x1c50>
    401b:	e8 80 e3 ff ff       	call   23a0 <free@plt>
    4020:	4d 85 e4             	test   %r12,%r12
    4023:	0f 85 67 ff ff ff    	jne    3f90 <fwp_rc_prepare_chunk+0x30>
    4029:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    4030:	00 
    4031:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    4035:	5b                   	pop    %rbx
    4036:	4c 01 25 13 93 01 00 	add    %r12,0x19313(%rip)        # 1d350 <fwp_heap+0x1c50>
    403d:	5d                   	pop    %rbp
    403e:	41 5c                	pop    %r12
    4040:	c3                   	ret
    4041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4048:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    404c:	5b                   	pop    %rbx
    404d:	4c 89 e2             	mov    %r12,%rdx
    4050:	31 f6                	xor    %esi,%esi
    4052:	5d                   	pop    %rbp
    4053:	41 5c                	pop    %r12
    4055:	e9 46 e4 ff ff       	jmp    24a0 <memset@plt>
    405a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004060 <fwp_heap_refill>:
    4060:	41 56                	push   %r14
    4062:	41 89 d6             	mov    %edx,%r14d
    4065:	41 55                	push   %r13
    4067:	41 89 f5             	mov    %esi,%r13d
    406a:	41 54                	push   %r12
    406c:	49 89 fc             	mov    %rdi,%r12
    406f:	bf 01 00 00 00       	mov    $0x1,%edi
    4074:	55                   	push   %rbp
    4075:	53                   	push   %rbx
    4076:	e8 b5 ec ff ff       	call   2d30 <fwp_heap_chunks>
    407b:	48 89 c3             	mov    %rax,%rbx
    407e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4082:	48 8b 05 6f 8a 01 00 	mov    0x18a6f(%rip),%rax        # 1caf8 <fwp_heap+0x13f8>
    4089:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    408d:	48 8d 05 6c 76 01 00 	lea    0x1766c(%rip),%rax        # 1b700 <fwp_heap>
    4094:	31 d2                	xor    %edx,%edx
    4096:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    409a:	48 89 ef             	mov    %rbp,%rdi
    409d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    40a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    40a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    40ac:	00 
    40ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    40b2:	f7 f1                	div    %ecx
    40b4:	31 d2                	xor    %edx,%edx
    40b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    40ba:	66 0f 6e c8          	movd   %eax,%xmm1
    40be:	89 c6                	mov    %eax,%esi
    40c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    40c5:	48 01 c8             	add    %rcx,%rax
    40c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    40cc:	48 f7 f1             	div    %rcx
    40cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    40d4:	89 45 18             	mov    %eax,0x18(%rbp)
    40d7:	e8 84 fe ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    40dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    40df:	48 89 d8             	mov    %rbx,%rax
    40e2:	48 c1 e0 10          	shl    $0x10,%rax
    40e6:	48 03 05 c3 89 01 00 	add    0x189c3(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    40ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    40f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    40f6:	8b 55 08             	mov    0x8(%rbp),%edx
    40f9:	48 0f af d1          	imul   %rcx,%rdx
    40fd:	48 01 c2             	add    %rax,%rdx
    4100:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4105:	5b                   	pop    %rbx
    4106:	5d                   	pop    %rbp
    4107:	41 5c                	pop    %r12
    4109:	41 5d                	pop    %r13
    410b:	41 5e                	pop    %r14
    410d:	c3                   	ret
    410e:	66 90                	xchg   %ax,%ax

0000000000004110 <fwp_mem_free>:
    4110:	48 85 ff             	test   %rdi,%rdi
    4113:	0f 84 17 02 00 00    	je     4330 <fwp_mem_free+0x220>
    4119:	48 8b 35 90 89 01 00 	mov    0x18990(%rip),%rsi        # 1cab0 <fwp_heap+0x13b0>
    4120:	48 8b 05 b1 89 01 00 	mov    0x189b1(%rip),%rax        # 1cad8 <fwp_heap+0x13d8>
    4127:	48 89 fa             	mov    %rdi,%rdx
    412a:	48 29 f2             	sub    %rsi,%rdx
    412d:	48 c1 e0 10          	shl    $0x10,%rax
    4131:	48 39 c2             	cmp    %rax,%rdx
    4134:	0f 83 f6 01 00 00    	jae    4330 <fwp_mem_free+0x220>
    413a:	49 89 d1             	mov    %rdx,%r9
    413d:	49 c1 e9 10          	shr    $0x10,%r9
    4141:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4145:	48 c1 e0 03          	shl    $0x3,%rax
    4149:	49 89 c0             	mov    %rax,%r8
    414c:	4c 03 05 a5 89 01 00 	add    0x189a5(%rip),%r8        # 1caf8 <fwp_heap+0x13f8>
    4153:	0f 84 d7 01 00 00    	je     4330 <fwp_mem_free+0x220>
    4159:	48 83 ec 38          	sub    $0x38,%rsp
    415d:	48 89 f9             	mov    %rdi,%rcx
    4160:	41 0f b6 38          	movzbl (%r8),%edi
    4164:	40 80 ff 01          	cmp    $0x1,%dil
    4168:	74 16                	je     4180 <fwp_mem_free+0x70>
    416a:	40 80 ff 02          	cmp    $0x2,%dil
    416e:	0f 84 94 00 00 00    	je     4208 <fwp_mem_free+0xf8>
    4174:	48 83 c4 38          	add    $0x38,%rsp
    4178:	c3                   	ret
    4179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4180:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4184:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4189:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    418e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4192:	4d 85 d2             	test   %r10,%r10
    4195:	74 1d                	je     41b4 <fwp_mem_free+0xa4>
    4197:	0f b7 c1             	movzwl %cx,%eax
    419a:	31 d2                	xor    %edx,%edx
    419c:	48 f7 f7             	div    %rdi
    419f:	49 01 c2             	add    %rax,%r10
    41a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    41a6:	0f 84 44 01 00 00    	je     42f0 <fwp_mem_free+0x1e0>
    41ac:	41 c6 02 00          	movb   $0x0,(%r10)
    41b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    41b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    41bb:	49 63 c1             	movslq %r9d,%rax
    41be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    41c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    41c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    41cb:	f2 0f 58 05 6d 89 01 	addsd  0x1896d(%rip),%xmm0        # 1cb40 <fwp_heap+0x1440>
    41d2:	00 
    41d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    41d7:	48 8d 05 22 75 01 00 	lea    0x17522(%rip),%rax        # 1b700 <fwp_heap>
    41de:	48 01 d0             	add    %rdx,%rax
    41e1:	48 8b 10             	mov    (%rax),%rdx
    41e4:	48 f7 d2             	not    %rdx
    41e7:	48 89 11             	mov    %rdx,(%rcx)
    41ea:	48 89 08             	mov    %rcx,(%rax)
    41ed:	48 29 3d 2c 89 01 00 	sub    %rdi,0x1892c(%rip)        # 1cb20 <fwp_heap+0x1420>
    41f4:	f2 0f 11 05 44 89 01 	movsd  %xmm0,0x18944(%rip)        # 1cb40 <fwp_heap+0x1440>
    41fb:	00 
    41fc:	48 83 c4 38          	add    $0x38,%rsp
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	66 31 d2             	xor    %dx,%dx
    420b:	48 01 d6             	add    %rdx,%rsi
    420e:	48 39 f1             	cmp    %rsi,%rcx
    4211:	0f 85 5d ff ff ff    	jne    4174 <fwp_mem_free+0x64>
    4217:	49 8b 50 10          	mov    0x10(%r8),%rdx
    421b:	48 29 15 fe 88 01 00 	sub    %rdx,0x188fe(%rip)        # 1cb20 <fwp_heap+0x1420>
    4222:	48 85 d2             	test   %rdx,%rdx
    4225:	0f 88 a5 00 00 00    	js     42d0 <fwp_mem_free+0x1c0>
    422b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    422f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4234:	f2 0f 58 05 04 89 01 	addsd  0x18904(%rip),%xmm0        # 1cb40 <fwp_heap+0x1440>
    423b:	00 
    423c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4240:	f2 0f 11 05 f8 88 01 	movsd  %xmm0,0x188f8(%rip)        # 1cb40 <fwp_heap+0x1440>
    4247:	00 
    4248:	48 85 d2             	test   %rdx,%rdx
    424b:	74 0c                	je     4259 <fwp_mem_free+0x149>
    424d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4250:	0f 84 db 00 00 00    	je     4331 <fwp_mem_free+0x221>
    4256:	c6 02 00             	movb   $0x0,(%rdx)
    4259:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    425d:	48 85 c9             	test   %rcx,%rcx
    4260:	74 3e                	je     42a0 <fwp_mem_free+0x190>
    4262:	48 8b 15 8f 88 01 00 	mov    0x1888f(%rip),%rdx        # 1caf8 <fwp_heap+0x13f8>
    4269:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    426d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4271:	48 01 d0             	add    %rdx,%rax
    4274:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4278:	48 89 d6             	mov    %rdx,%rsi
    427b:	48 29 c6             	sub    %rax,%rsi
    427e:	83 e6 08             	and    $0x8,%esi
    4281:	74 0d                	je     4290 <fwp_mem_free+0x180>
    4283:	c6 00 00             	movb   $0x0,(%rax)
    4286:	48 83 c0 28          	add    $0x28,%rax
    428a:	48 39 c2             	cmp    %rax,%rdx
    428d:	74 11                	je     42a0 <fwp_mem_free+0x190>
    428f:	90                   	nop
    4290:	c6 00 00             	movb   $0x0,(%rax)
    4293:	48 83 c0 50          	add    $0x50,%rax
    4297:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    429b:	48 39 c2             	cmp    %rax,%rdx
    429e:	75 f0                	jne    4290 <fwp_mem_free+0x180>
    42a0:	48 01 0d 89 88 01 00 	add    %rcx,0x18889(%rip)        # 1cb30 <fwp_heap+0x1430>
    42a7:	4c 3b 0d 42 88 01 00 	cmp    0x18842(%rip),%r9        # 1caf0 <fwp_heap+0x13f0>
    42ae:	73 07                	jae    42b7 <fwp_mem_free+0x1a7>
    42b0:	4c 89 0d 39 88 01 00 	mov    %r9,0x18839(%rip)        # 1caf0 <fwp_heap+0x13f0>
    42b7:	4c 3b 0d 2a 88 01 00 	cmp    0x1882a(%rip),%r9        # 1cae8 <fwp_heap+0x13e8>
    42be:	0f 83 b0 fe ff ff    	jae    4174 <fwp_mem_free+0x64>
    42c4:	4c 89 0d 1d 88 01 00 	mov    %r9,0x1881d(%rip)        # 1cae8 <fwp_heap+0x13e8>
    42cb:	e9 a4 fe ff ff       	jmp    4174 <fwp_mem_free+0x64>
    42d0:	48 89 d1             	mov    %rdx,%rcx
    42d3:	83 e2 01             	and    $0x1,%edx
    42d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42da:	48 d1 e9             	shr    $1,%rcx
    42dd:	48 09 d1             	or     %rdx,%rcx
    42e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    42e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    42e9:	e9 46 ff ff ff       	jmp    4234 <fwp_mem_free+0x124>
    42ee:	66 90                	xchg   %ax,%ax
    42f0:	4c 89 d7             	mov    %r10,%rdi
    42f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    42f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    42fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4302:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4306:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    430b:	e8 c0 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4310:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4315:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    431a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    431f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    4324:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    4329:	e9 7e fe ff ff       	jmp    41ac <fwp_mem_free+0x9c>
    432e:	66 90                	xchg   %ax,%ax
    4330:	c3                   	ret
    4331:	48 89 d7             	mov    %rdx,%rdi
    4334:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    4339:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    433e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4343:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4348:	e8 83 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    434d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4352:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4357:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    435c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4361:	e9 f0 fe ff ff       	jmp    4256 <fwp_mem_free+0x146>
    4366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    436d:	00 00 00 

0000000000004370 <fwp_heap_alloc_big>:
    4370:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4377:	00 00 40 
    437a:	41 57                	push   %r15
    437c:	41 56                	push   %r14
    437e:	41 55                	push   %r13
    4380:	41 54                	push   %r12
    4382:	55                   	push   %rbp
    4383:	53                   	push   %rbx
    4384:	48 83 ec 08          	sub    $0x8,%rsp
    4388:	48 39 f8             	cmp    %rdi,%rax
    438b:	0f 82 fa 00 00 00    	jb     448b <fwp_heap_alloc_big+0x11b>
    4391:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4398:	49 89 fd             	mov    %rdi,%r13
    439b:	41 89 f6             	mov    %esi,%r14d
    439e:	48 c1 ed 10          	shr    $0x10,%rbp
    43a2:	48 89 ef             	mov    %rbp,%rdi
    43a5:	e8 86 e9 ff ff       	call   2d30 <fwp_heap_chunks>
    43aa:	be 01 00 00 00       	mov    $0x1,%esi
    43af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    43b3:	49 89 c4             	mov    %rax,%r12
    43b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    43bd:	00 
    43be:	48 03 3d 33 87 01 00 	add    0x18733(%rip),%rdi        # 1caf8 <fwp_heap+0x13f8>
    43c5:	c6 07 02             	movb   $0x2,(%rdi)
    43c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    43cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    43cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    43d3:	e8 88 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    43d8:	48 83 fd 01          	cmp    $0x1,%rbp
    43dc:	76 47                	jbe    4425 <fwp_heap_alloc_big+0xb5>
    43de:	4c 01 e5             	add    %r12,%rbp
    43e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    43e8:	00 
    43e9:	4c 8d 3d 10 73 01 00 	lea    0x17310(%rip),%r15        # 1b700 <fwp_heap>
    43f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    43f5:	49 c1 e6 03          	shl    $0x3,%r14
    43f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4400:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4407:	31 f6                	xor    %esi,%esi
    4409:	48 01 dd             	add    %rbx,%rbp
    440c:	48 83 c3 28          	add    $0x28,%rbx
    4410:	48 89 ef             	mov    %rbp,%rdi
    4413:	e8 48 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    4418:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    441c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    4420:	49 39 de             	cmp    %rbx,%r14
    4423:	75 db                	jne    4400 <fwp_heap_alloc_big+0x90>
    4425:	49 c1 e4 10          	shl    $0x10,%r12
    4429:	4c 03 25 80 86 01 00 	add    0x18680(%rip),%r12        # 1cab0 <fwp_heap+0x13b0>
    4430:	4c 89 ea             	mov    %r13,%rdx
    4433:	31 f6                	xor    %esi,%esi
    4435:	4c 89 e7             	mov    %r12,%rdi
    4438:	e8 63 e0 ff ff       	call   24a0 <memset@plt>
    443d:	4c 89 e8             	mov    %r13,%rax
    4440:	48 03 05 d9 86 01 00 	add    0x186d9(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    4447:	72 42                	jb     448b <fwp_heap_alloc_big+0x11b>
    4449:	48 39 05 d8 86 01 00 	cmp    %rax,0x186d8(%rip)        # 1cb28 <fwp_heap+0x1428>
    4450:	48 89 05 c9 86 01 00 	mov    %rax,0x186c9(%rip)        # 1cb20 <fwp_heap+0x1420>
    4457:	73 07                	jae    4460 <fwp_heap_alloc_big+0xf0>
    4459:	48 89 05 c8 86 01 00 	mov    %rax,0x186c8(%rip)        # 1cb28 <fwp_heap+0x1428>
    4460:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4464:	4c 89 e0             	mov    %r12,%rax
    4467:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    446c:	f2 0f 58 05 c4 86 01 	addsd  0x186c4(%rip),%xmm0        # 1cb38 <fwp_heap+0x1438>
    4473:	00 
    4474:	f2 0f 11 05 bc 86 01 	movsd  %xmm0,0x186bc(%rip)        # 1cb38 <fwp_heap+0x1438>
    447b:	00 
    447c:	48 83 c4 08          	add    $0x8,%rsp
    4480:	5b                   	pop    %rbx
    4481:	5d                   	pop    %rbp
    4482:	41 5c                	pop    %r12
    4484:	41 5d                	pop    %r13
    4486:	41 5e                	pop    %r14
    4488:	41 5f                	pop    %r15
    448a:	c3                   	ret
    448b:	e8 60 e8 ff ff       	call   2cf0 <fwp_heap_oom>

0000000000004490 <fwp_heap_alloc_slow>:
    4490:	53                   	push   %rbx
    4491:	48 89 f9             	mov    %rdi,%rcx
    4494:	41 89 f1             	mov    %esi,%r9d
    4497:	48 83 ec 10          	sub    $0x10,%rsp
    449b:	8b 05 03 86 01 00    	mov    0x18603(%rip),%eax        # 1caa4 <fwp_heap+0x13a4>
    44a1:	85 c0                	test   %eax,%eax
    44a3:	0f 84 c7 00 00 00    	je     4570 <fwp_heap_alloc_slow+0xe0>
    44a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    44b0:	0f 87 dd 00 00 00    	ja     4593 <fwp_heap_alloc_slow+0x103>
    44b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    44ba:	48 8d 3d 3f 72 01 00 	lea    0x1723f(%rip),%rdi        # 1b700 <fwp_heap>
    44c1:	49 63 f1             	movslq %r9d,%rsi
    44c4:	48 c1 e8 04          	shr    $0x4,%rax
    44c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    44cf:	00 00 
    44d1:	41 0f b6 c2          	movzbl %r10b,%eax
    44d5:	4c 89 d2             	mov    %r10,%rdx
    44d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    44dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    44e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    44ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    44ee:	48 01 f8             	add    %rdi,%rax
    44f1:	4c 8b 00             	mov    (%rax),%r8
    44f4:	4d 85 c0             	test   %r8,%r8
    44f7:	0f 84 ab 00 00 00    	je     45a8 <fwp_heap_alloc_slow+0x118>
    44fd:	49 8b 10             	mov    (%r8),%rdx
    4500:	48 f7 d2             	not    %rdx
    4503:	48 89 10             	mov    %rdx,(%rax)
    4506:	41 83 f9 01          	cmp    $0x1,%r9d
    450a:	4c 89 c7             	mov    %r8,%rdi
    450d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4511:	31 f6                	xor    %esi,%esi
    4513:	48 89 ca             	mov    %rcx,%rdx
    4516:	e8 85 df ff ff       	call   24a0 <memset@plt>
    451b:	49 89 c0             	mov    %rax,%r8
    451e:	48 89 d8             	mov    %rbx,%rax
    4521:	48 03 05 f8 85 01 00 	add    0x185f8(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    4528:	0f 82 d9 00 00 00    	jb     4607 <fwp_heap_alloc_slow+0x177>
    452e:	48 39 05 f3 85 01 00 	cmp    %rax,0x185f3(%rip)        # 1cb28 <fwp_heap+0x1428>
    4535:	48 89 05 e4 85 01 00 	mov    %rax,0x185e4(%rip)        # 1cb20 <fwp_heap+0x1420>
    453c:	73 07                	jae    4545 <fwp_heap_alloc_slow+0xb5>
    453e:	48 89 05 e3 85 01 00 	mov    %rax,0x185e3(%rip)        # 1cb28 <fwp_heap+0x1428>
    4545:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4549:	4c 89 c0             	mov    %r8,%rax
    454c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4551:	f2 0f 58 05 df 85 01 	addsd  0x185df(%rip),%xmm0        # 1cb38 <fwp_heap+0x1438>
    4558:	00 
    4559:	f2 0f 11 05 d7 85 01 	movsd  %xmm0,0x185d7(%rip)        # 1cb38 <fwp_heap+0x1438>
    4560:	00 
    4561:	48 83 c4 10          	add    $0x10,%rsp
    4565:	5b                   	pop    %rbx
    4566:	c3                   	ret
    4567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    456e:	00 00 
    4570:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4574:	48 89 3c 24          	mov    %rdi,(%rsp)
    4578:	e8 b3 f3 ff ff       	call   3930 <fwp_heap_init>
    457d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4581:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4586:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    458d:	0f 86 23 ff ff ff    	jbe    44b6 <fwp_heap_alloc_slow+0x26>
    4593:	48 83 c4 10          	add    $0x10,%rsp
    4597:	44 89 ce             	mov    %r9d,%esi
    459a:	48 89 cf             	mov    %rcx,%rdi
    459d:	5b                   	pop    %rbx
    459e:	e9 cd fd ff ff       	jmp    4370 <fwp_heap_alloc_big>
    45a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    45ac:	4d 85 c0             	test   %r8,%r8
    45af:	74 1f                	je     45d0 <fwp_heap_alloc_slow+0x140>
    45b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    45b5:	4d 29 c3             	sub    %r8,%r11
    45b8:	49 39 db             	cmp    %rbx,%r11
    45bb:	72 13                	jb     45d0 <fwp_heap_alloc_slow+0x140>
    45bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    45c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    45c5:	e9 3c ff ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    45ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    45d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    45d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    45db:	44 89 ca             	mov    %r9d,%edx
    45de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    45e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    45e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    45eb:	44 89 d6             	mov    %r10d,%esi
    45ee:	48 01 c7             	add    %rax,%rdi
    45f1:	e8 6a fa ff ff       	call   4060 <fwp_heap_refill>
    45f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    45fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    45ff:	49 89 c0             	mov    %rax,%r8
    4602:	e9 ff fe ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    4607:	e8 e4 e6 ff ff       	call   2cf0 <fwp_heap_oom>
    460c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004610 <fwp_rc_free_arr>:
    4610:	48 8b 15 c1 84 01 00 	mov    0x184c1(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    4617:	48 89 f8             	mov    %rdi,%rax
    461a:	48 2b 05 8f 84 01 00 	sub    0x1848f(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    4621:	48 c1 e2 10          	shl    $0x10,%rdx
    4625:	48 39 d0             	cmp    %rdx,%rax
    4628:	73 5b                	jae    4685 <fwp_rc_free_arr+0x75>
    462a:	48 89 c2             	mov    %rax,%rdx
    462d:	48 c1 ea 10          	shr    $0x10,%rdx
    4631:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4635:	48 8b 15 bc 84 01 00 	mov    0x184bc(%rip),%rdx        # 1caf8 <fwp_heap+0x13f8>
    463c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4640:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4644:	48 85 c9             	test   %rcx,%rcx
    4647:	74 3c                	je     4685 <fwp_rc_free_arr+0x75>
    4649:	0f b6 32             	movzbl (%rdx),%esi
    464c:	40 80 fe 02          	cmp    $0x2,%sil
    4650:	74 2e                	je     4680 <fwp_rc_free_arr+0x70>
    4652:	40 80 fe 01          	cmp    $0x1,%sil
    4656:	75 2d                	jne    4685 <fwp_rc_free_arr+0x75>
    4658:	8b 72 18             	mov    0x18(%rdx),%esi
    465b:	0f b7 c0             	movzwl %ax,%eax
    465e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4661:	48 0f af c6          	imul   %rsi,%rax
    4665:	48 c1 e8 20          	shr    $0x20,%rax
    4669:	48 39 d0             	cmp    %rdx,%rax
    466c:	73 17                	jae    4685 <fwp_rc_free_arr+0x75>
    466e:	48 01 c1             	add    %rax,%rcx
    4671:	80 39 01             	cmpb   $0x1,(%rcx)
    4674:	75 0f                	jne    4685 <fwp_rc_free_arr+0x75>
    4676:	e9 95 fa ff ff       	jmp    4110 <fwp_mem_free>
    467b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4680:	66 85 c0             	test   %ax,%ax
    4683:	74 ec                	je     4671 <fwp_rc_free_arr+0x61>
    4685:	c3                   	ret
    4686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    468d:	00 00 00 

0000000000004690 <fwp_heap_alloc>:
    4690:	53                   	push   %rbx
    4691:	48 89 fa             	mov    %rdi,%rdx
    4694:	48 83 ec 10          	sub    $0x10,%rsp
    4698:	8b 1d 22 8d 01 00    	mov    0x18d22(%rip),%ebx        # 1d3c0 <iteration_active>
    469e:	8b 05 00 84 01 00    	mov    0x18400(%rip),%eax        # 1caa4 <fwp_heap+0x13a4>
    46a4:	85 db                	test   %ebx,%ebx
    46a6:	0f 85 04 01 00 00    	jne    47b0 <fwp_heap_alloc+0x120>
    46ac:	85 c0                	test   %eax,%eax
    46ae:	0f 84 ac 01 00 00    	je     4860 <fwp_heap_alloc+0x1d0>
    46b4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    46bb:	0f 87 9f 01 00 00    	ja     4860 <fwp_heap_alloc+0x1d0>
    46c1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    46c5:	48 8d 05 34 70 01 00 	lea    0x17034(%rip),%rax        # 1b700 <fwp_heap>
    46cc:	48 c1 e9 04          	shr    $0x4,%rcx
    46d0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    46d7:	00 
    46d8:	48 63 ce             	movslq %esi,%rcx
    46db:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    46e2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    46e9:	00 
    46ea:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    46ee:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    46f2:	48 01 c8             	add    %rcx,%rax
    46f5:	48 8b 08             	mov    (%rax),%rcx
    46f8:	48 85 c9             	test   %rcx,%rcx
    46fb:	0f 84 ff 00 00 00    	je     4800 <fwp_heap_alloc+0x170>
    4701:	48 8b 39             	mov    (%rcx),%rdi
    4704:	48 f7 d7             	not    %rdi
    4707:	48 89 38             	mov    %rdi,(%rax)
    470a:	83 fe 01             	cmp    $0x1,%esi
    470d:	48 89 cf             	mov    %rcx,%rdi
    4710:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    4715:	49 0f 45 d0          	cmovne %r8,%rdx
    4719:	31 f6                	xor    %esi,%esi
    471b:	e8 80 dd ff ff       	call   24a0 <memset@plt>
    4720:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4725:	48 89 c1             	mov    %rax,%rcx
    4728:	4c 89 c0             	mov    %r8,%rax
    472b:	48 03 05 ee 83 01 00 	add    0x183ee(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    4732:	0f 82 35 01 00 00    	jb     486d <fwp_heap_alloc+0x1dd>
    4738:	48 39 05 e9 83 01 00 	cmp    %rax,0x183e9(%rip)        # 1cb28 <fwp_heap+0x1428>
    473f:	48 89 05 da 83 01 00 	mov    %rax,0x183da(%rip)        # 1cb20 <fwp_heap+0x1420>
    4746:	73 07                	jae    474f <fwp_heap_alloc+0xbf>
    4748:	48 89 05 d9 83 01 00 	mov    %rax,0x183d9(%rip)        # 1cb28 <fwp_heap+0x1428>
    474f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4753:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4758:	f2 0f 58 05 d8 83 01 	addsd  0x183d8(%rip),%xmm0        # 1cb38 <fwp_heap+0x1438>
    475f:	00 
    4760:	f2 0f 11 05 d0 83 01 	movsd  %xmm0,0x183d0(%rip)        # 1cb38 <fwp_heap+0x1438>
    4767:	00 
    4768:	85 db                	test   %ebx,%ebx
    476a:	74 33                	je     479f <fwp_heap_alloc+0x10f>
    476c:	48 8b 05 ad 83 01 00 	mov    0x183ad(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    4773:	48 85 c0             	test   %rax,%rax
    4776:	0f 88 ac 00 00 00    	js     4828 <fwp_heap_alloc+0x198>
    477c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4780:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4785:	f2 0f 5c 05 13 8c 01 	subsd  0x18c13(%rip),%xmm0        # 1d3a0 <iteration_start_charge>
    478c:	00 
    478d:	66 0f 2f 05 03 8c 01 	comisd 0x18c03(%rip),%xmm0        # 1d398 <iteration_peak>
    4794:	00 
    4795:	76 08                	jbe    479f <fwp_heap_alloc+0x10f>
    4797:	f2 0f 11 05 f9 8b 01 	movsd  %xmm0,0x18bf9(%rip)        # 1d398 <iteration_peak>
    479e:	00 
    479f:	48 83 c4 10          	add    $0x10,%rsp
    47a3:	48 89 c8             	mov    %rcx,%rax
    47a6:	5b                   	pop    %rbx
    47a7:	c3                   	ret
    47a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    47af:	00 
    47b0:	85 f6                	test   %esi,%esi
    47b2:	74 34                	je     47e8 <fwp_heap_alloc+0x158>
    47b4:	48 83 05 fc 8b 01 00 	addq   $0x1,0x18bfc(%rip)        # 1d3b8 <iteration_requests>
    47bb:	01 
    47bc:	48 01 3d ed 8b 01 00 	add    %rdi,0x18bed(%rip)        # 1d3b0 <iteration_bytes>
    47c3:	85 c0                	test   %eax,%eax
    47c5:	74 0d                	je     47d4 <fwp_heap_alloc+0x144>
    47c7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    47ce:	0f 86 ed fe ff ff    	jbe    46c1 <fwp_heap_alloc+0x31>
    47d4:	48 89 d7             	mov    %rdx,%rdi
    47d7:	e8 b4 fc ff ff       	call   4490 <fwp_heap_alloc_slow>
    47dc:	48 89 c1             	mov    %rax,%rcx
    47df:	eb 8b                	jmp    476c <fwp_heap_alloc+0xdc>
    47e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    47e8:	85 c0                	test   %eax,%eax
    47ea:	74 0d                	je     47f9 <fwp_heap_alloc+0x169>
    47ec:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    47f3:	0f 86 c8 fe ff ff    	jbe    46c1 <fwp_heap_alloc+0x31>
    47f9:	31 f6                	xor    %esi,%esi
    47fb:	eb d7                	jmp    47d4 <fwp_heap_alloc+0x144>
    47fd:	0f 1f 00             	nopl   (%rax)
    4800:	48 8b 48 08          	mov    0x8(%rax),%rcx
    4804:	48 85 c9             	test   %rcx,%rcx
    4807:	74 0c                	je     4815 <fwp_heap_alloc+0x185>
    4809:	48 8b 78 10          	mov    0x10(%rax),%rdi
    480d:	48 29 cf             	sub    %rcx,%rdi
    4810:	4c 39 c7             	cmp    %r8,%rdi
    4813:	73 3b                	jae    4850 <fwp_heap_alloc+0x1c0>
    4815:	48 89 d7             	mov    %rdx,%rdi
    4818:	e8 73 fc ff ff       	call   4490 <fwp_heap_alloc_slow>
    481d:	48 89 c1             	mov    %rax,%rcx
    4820:	e9 43 ff ff ff       	jmp    4768 <fwp_heap_alloc+0xd8>
    4825:	0f 1f 00             	nopl   (%rax)
    4828:	48 89 c2             	mov    %rax,%rdx
    482b:	83 e0 01             	and    $0x1,%eax
    482e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4832:	48 d1 ea             	shr    $1,%rdx
    4835:	48 09 c2             	or     %rax,%rdx
    4838:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    483d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4841:	e9 3f ff ff ff       	jmp    4785 <fwp_heap_alloc+0xf5>
    4846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    484d:	00 00 00 
    4850:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    4854:	48 89 78 08          	mov    %rdi,0x8(%rax)
    4858:	e9 ad fe ff ff       	jmp    470a <fwp_heap_alloc+0x7a>
    485d:	0f 1f 00             	nopl   (%rax)
    4860:	48 83 c4 10          	add    $0x10,%rsp
    4864:	48 89 d7             	mov    %rdx,%rdi
    4867:	5b                   	pop    %rbx
    4868:	e9 23 fc ff ff       	jmp    4490 <fwp_heap_alloc_slow>
    486d:	e8 7e e4 ff ff       	call   2cf0 <fwp_heap_oom>
    4872:	0f 1f 00             	nopl   (%rax)
    4875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    487c:	00 00 00 00 

0000000000004880 <fwp_data.part.0.constprop.0>:
    4880:	41 56                	push   %r14
    4882:	8b 05 1c 82 01 00    	mov    0x1821c(%rip),%eax        # 1caa4 <fwp_heap+0x13a4>
    4888:	41 89 fe             	mov    %edi,%r14d
    488b:	41 55                	push   %r13
    488d:	44 8b 2d 2c 8b 01 00 	mov    0x18b2c(%rip),%r13d        # 1d3c0 <iteration_active>
    4894:	41 54                	push   %r12
    4896:	49 89 f4             	mov    %rsi,%r12
    4899:	55                   	push   %rbp
    489a:	53                   	push   %rbx
    489b:	45 85 ed             	test   %r13d,%r13d
    489e:	0f 84 1c 01 00 00    	je     49c0 <fwp_data.part.0.constprop.0+0x140>
    48a4:	48 83 05 0c 8b 01 00 	addq   $0x1,0x18b0c(%rip)        # 1d3b8 <iteration_requests>
    48ab:	01 
    48ac:	48 83 05 fc 8a 01 00 	addq   $0x18,0x18afc(%rip)        # 1d3b0 <iteration_bytes>
    48b3:	18 
    48b4:	85 c0                	test   %eax,%eax
    48b6:	0f 84 8c 01 00 00    	je     4a48 <fwp_data.part.0.constprop.0+0x1c8>
    48bc:	0f b6 05 df 7d 01 00 	movzbl 0x17ddf(%rip),%eax        # 1c6a2 <fwp_heap+0xfa2>
    48c3:	48 8d 15 36 6e 01 00 	lea    0x16e36(%rip),%rdx        # 1b700 <fwp_heap>
    48ca:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    48d1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    48d5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    48d9:	48 8b 18             	mov    (%rax),%rbx
    48dc:	48 85 db             	test   %rbx,%rbx
    48df:	0f 84 fb 00 00 00    	je     49e0 <fwp_data.part.0.constprop.0+0x160>
    48e5:	48 8b 13             	mov    (%rbx),%rdx
    48e8:	48 f7 d2             	not    %rdx
    48eb:	48 89 10             	mov    %rdx,(%rax)
    48ee:	48 83 fd 18          	cmp    $0x18,%rbp
    48f2:	76 1b                	jbe    490f <fwp_data.part.0.constprop.0+0x8f>
    48f4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    48f8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    48fc:	31 f6                	xor    %esi,%esi
    48fe:	48 c1 e8 03          	shr    $0x3,%rax
    4902:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    4909:	00 
    490a:	e8 91 db ff ff       	call   24a0 <memset@plt>
    490f:	48 89 e8             	mov    %rbp,%rax
    4912:	48 03 05 07 82 01 00 	add    0x18207(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    4919:	0f 82 3d 01 00 00    	jb     4a5c <fwp_data.part.0.constprop.0+0x1dc>
    491f:	48 39 05 02 82 01 00 	cmp    %rax,0x18202(%rip)        # 1cb28 <fwp_heap+0x1428>
    4926:	48 89 05 f3 81 01 00 	mov    %rax,0x181f3(%rip)        # 1cb20 <fwp_heap+0x1420>
    492d:	73 07                	jae    4936 <fwp_data.part.0.constprop.0+0xb6>
    492f:	48 89 05 f2 81 01 00 	mov    %rax,0x181f2(%rip)        # 1cb28 <fwp_heap+0x1428>
    4936:	66 0f ef c0          	pxor   %xmm0,%xmm0
    493a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    493f:	f2 0f 58 05 f1 81 01 	addsd  0x181f1(%rip),%xmm0        # 1cb38 <fwp_heap+0x1438>
    4946:	00 
    4947:	f2 0f 11 05 e9 81 01 	movsd  %xmm0,0x181e9(%rip)        # 1cb38 <fwp_heap+0x1438>
    494e:	00 
    494f:	45 85 ed             	test   %r13d,%r13d
    4952:	74 33                	je     4987 <fwp_data.part.0.constprop.0+0x107>
    4954:	48 8b 05 c5 81 01 00 	mov    0x181c5(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    495b:	48 85 c0             	test   %rax,%rax
    495e:	0f 88 a4 00 00 00    	js     4a08 <fwp_data.part.0.constprop.0+0x188>
    4964:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4968:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    496d:	f2 0f 5c 05 2b 8a 01 	subsd  0x18a2b(%rip),%xmm0        # 1d3a0 <iteration_start_charge>
    4974:	00 
    4975:	66 0f 2f 05 1b 8a 01 	comisd 0x18a1b(%rip),%xmm0        # 1d398 <iteration_peak>
    497c:	00 
    497d:	76 08                	jbe    4987 <fwp_data.part.0.constprop.0+0x107>
    497f:	f2 0f 11 05 11 8a 01 	movsd  %xmm0,0x18a11(%rip)        # 1d398 <iteration_peak>
    4986:	00 
    4987:	b8 02 00 00 00       	mov    $0x2,%eax
    498c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    4991:	66 0f 6e c8          	movd   %eax,%xmm1
    4995:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    4999:	66 0f d6 03          	movq   %xmm0,(%rbx)
    499d:	49 8b 04 24          	mov    (%r12),%rax
    49a1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    49a5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    49aa:	48 89 43 10          	mov    %rax,0x10(%rbx)
    49ae:	48 89 d8             	mov    %rbx,%rax
    49b1:	5b                   	pop    %rbx
    49b2:	5d                   	pop    %rbp
    49b3:	41 5c                	pop    %r12
    49b5:	41 5d                	pop    %r13
    49b7:	41 5e                	pop    %r14
    49b9:	c3                   	ret
    49ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    49c0:	85 c0                	test   %eax,%eax
    49c2:	0f 85 f4 fe ff ff    	jne    48bc <fwp_data.part.0.constprop.0+0x3c>
    49c8:	31 f6                	xor    %esi,%esi
    49ca:	bf 18 00 00 00       	mov    $0x18,%edi
    49cf:	e8 bc fc ff ff       	call   4690 <fwp_heap_alloc>
    49d4:	48 89 c3             	mov    %rax,%rbx
    49d7:	eb ae                	jmp    4987 <fwp_data.part.0.constprop.0+0x107>
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    49e4:	48 85 db             	test   %rbx,%rbx
    49e7:	74 47                	je     4a30 <fwp_data.part.0.constprop.0+0x1b0>
    49e9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    49ed:	48 29 da             	sub    %rbx,%rdx
    49f0:	48 39 ea             	cmp    %rbp,%rdx
    49f3:	72 3b                	jb     4a30 <fwp_data.part.0.constprop.0+0x1b0>
    49f5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    49f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    49fd:	e9 ec fe ff ff       	jmp    48ee <fwp_data.part.0.constprop.0+0x6e>
    4a02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a08:	48 89 c2             	mov    %rax,%rdx
    4a0b:	83 e0 01             	and    $0x1,%eax
    4a0e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4a12:	48 d1 ea             	shr    $1,%rdx
    4a15:	48 09 c2             	or     %rax,%rdx
    4a18:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4a1d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4a21:	e9 47 ff ff ff       	jmp    496d <fwp_data.part.0.constprop.0+0xed>
    4a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4a2d:	00 00 00 
    4a30:	31 f6                	xor    %esi,%esi
    4a32:	bf 18 00 00 00       	mov    $0x18,%edi
    4a37:	e8 54 fc ff ff       	call   4690 <fwp_heap_alloc>
    4a3c:	48 89 c3             	mov    %rax,%rbx
    4a3f:	e9 0b ff ff ff       	jmp    494f <fwp_data.part.0.constprop.0+0xcf>
    4a44:	0f 1f 40 00          	nopl   0x0(%rax)
    4a48:	31 f6                	xor    %esi,%esi
    4a4a:	bf 18 00 00 00       	mov    $0x18,%edi
    4a4f:	e8 3c fc ff ff       	call   4690 <fwp_heap_alloc>
    4a54:	48 89 c3             	mov    %rax,%rbx
    4a57:	e9 f8 fe ff ff       	jmp    4954 <fwp_data.part.0.constprop.0+0xd4>
    4a5c:	e8 8f e2 ff ff       	call   2cf0 <fwp_heap_oom>
    4a61:	0f 1f 40 00          	nopl   0x0(%rax)
    4a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a6c:	00 00 00 00 

0000000000004a70 <fwp_array_new_packed.constprop.0>:
    4a70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4a77:	ff ff 1f 
    4a7a:	53                   	push   %rbx
    4a7b:	48 39 f8             	cmp    %rdi,%rax
    4a7e:	72 1a                	jb     4a9a <fwp_array_new_packed.constprop.0+0x2a>
    4a80:	48 89 fb             	mov    %rdi,%rbx
    4a83:	be 01 00 00 00       	mov    $0x1,%esi
    4a88:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    4a8f:	00 
    4a90:	e8 fb fb ff ff       	call   4690 <fwp_heap_alloc>
    4a95:	48 89 18             	mov    %rbx,(%rax)
    4a98:	5b                   	pop    %rbx
    4a99:	c3                   	ret
    4a9a:	48 8d 3d 44 36 00 00 	lea    0x3644(%rip),%rdi        # 80e5 <_IO_stdin_used+0xe5>
    4aa1:	e8 5a e7 ff ff       	call   3200 <fwp_trap>
    4aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4aad:	00 00 00 

0000000000004ab0 <fwp_task_dispose>:
    4ab0:	53                   	push   %rbx
    4ab1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4ab5:	0f 84 4b dc ff ff    	je     2706 <fwp_task_dispose.cold>
    4abb:	48 89 fb             	mov    %rdi,%rbx
    4abe:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4ac3:	0f 85 3d dc ff ff    	jne    2706 <fwp_task_dispose.cold>
    4ac9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    4acd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4ad4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    4adb:	00 
    4adc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4ae0:	48 85 ff             	test   %rdi,%rdi
    4ae3:	74 07                	je     4aec <fwp_task_dispose+0x3c>
    4ae5:	48 85 c0             	test   %rax,%rax
    4ae8:	74 02                	je     4aec <fwp_task_dispose+0x3c>
    4aea:	ff d0                	call   *%rax
    4aec:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4af3:	e8 18 f6 ff ff       	call   4110 <fwp_mem_free>
    4af8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    4aff:	00 00 00 00 
    4b03:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4b07:	74 6f                	je     4b78 <fwp_task_dispose+0xc8>
    4b09:	48 8b 15 c8 7f 01 00 	mov    0x17fc8(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    4b10:	48 89 d8             	mov    %rbx,%rax
    4b13:	48 2b 05 96 7f 01 00 	sub    0x17f96(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    4b1a:	48 c1 e2 10          	shl    $0x10,%rdx
    4b1e:	48 39 d0             	cmp    %rdx,%rax
    4b21:	73 4c                	jae    4b6f <fwp_task_dispose+0xbf>
    4b23:	48 89 c2             	mov    %rax,%rdx
    4b26:	48 c1 ea 10          	shr    $0x10,%rdx
    4b2a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4b2e:	48 8b 15 c3 7f 01 00 	mov    0x17fc3(%rip),%rdx        # 1caf8 <fwp_heap+0x13f8>
    4b35:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4b39:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4b3d:	48 85 c9             	test   %rcx,%rcx
    4b40:	74 2d                	je     4b6f <fwp_task_dispose+0xbf>
    4b42:	0f b6 32             	movzbl (%rdx),%esi
    4b45:	40 80 fe 02          	cmp    $0x2,%sil
    4b49:	74 3d                	je     4b88 <fwp_task_dispose+0xd8>
    4b4b:	40 80 fe 01          	cmp    $0x1,%sil
    4b4f:	75 1e                	jne    4b6f <fwp_task_dispose+0xbf>
    4b51:	8b 72 18             	mov    0x18(%rdx),%esi
    4b54:	0f b7 c0             	movzwl %ax,%eax
    4b57:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4b5a:	48 0f af c6          	imul   %rsi,%rax
    4b5e:	48 c1 e8 20          	shr    $0x20,%rax
    4b62:	48 39 d0             	cmp    %rdx,%rax
    4b65:	73 08                	jae    4b6f <fwp_task_dispose+0xbf>
    4b67:	48 01 c1             	add    %rax,%rcx
    4b6a:	80 39 01             	cmpb   $0x1,(%rcx)
    4b6d:	74 09                	je     4b78 <fwp_task_dispose+0xc8>
    4b6f:	5b                   	pop    %rbx
    4b70:	c3                   	ret
    4b71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4b78:	48 89 df             	mov    %rbx,%rdi
    4b7b:	5b                   	pop    %rbx
    4b7c:	e9 8f f5 ff ff       	jmp    4110 <fwp_mem_free>
    4b81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4b88:	66 85 c0             	test   %ax,%ax
    4b8b:	74 dd                	je     4b6a <fwp_task_dispose+0xba>
    4b8d:	5b                   	pop    %rbx
    4b8e:	c3                   	ret
    4b8f:	90                   	nop

0000000000004b90 <fwp_free_zombie>:
    4b90:	48 8b 15 39 6b 01 00 	mov    0x16b39(%rip),%rdx        # 1b6d0 <fwp_zombie>
    4b97:	48 85 d2             	test   %rdx,%rdx
    4b9a:	0f 84 98 00 00 00    	je     4c38 <fwp_free_zombie+0xa8>
    4ba0:	48 3b 15 39 6b 01 00 	cmp    0x16b39(%rip),%rdx        # 1b6e0 <fwp_cur>
    4ba7:	0f 84 8b 00 00 00    	je     4c38 <fwp_free_zombie+0xa8>
    4bad:	48 83 ec 18          	sub    $0x18,%rsp
    4bb1:	48 63 05 ec 64 01 00 	movslq 0x164ec(%rip),%rax        # 1b0a4 <fwp_stack_pool_n>
    4bb8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4bbc:	83 f8 3f             	cmp    $0x3f,%eax
    4bbf:	7f 7f                	jg     4c40 <fwp_free_zombie+0xb0>
    4bc1:	8d 48 01             	lea    0x1(%rax),%ecx
    4bc4:	89 0d da 64 01 00    	mov    %ecx,0x164da(%rip)        # 1b0a4 <fwp_stack_pool_n>
    4bca:	48 8d 0d ef 64 01 00 	lea    0x164ef(%rip),%rcx        # 1b0c0 <fwp_stack_pool>
    4bd1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4bd5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4bdc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4be0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4be7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4beb:	48 85 c9             	test   %rcx,%rcx
    4bee:	0f 84 fc 00 00 00    	je     4cf0 <fwp_free_zombie+0x160>
    4bf4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4bfb:	48 85 c0             	test   %rax,%rax
    4bfe:	74 07                	je     4c07 <fwp_free_zombie+0x77>
    4c00:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4c07:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4c0a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4c0e:	48 c7 05 b7 6a 01 00 	movq   $0x0,0x16ab7(%rip)        # 1b6d0 <fwp_zombie>
    4c15:	00 00 00 00 
    4c19:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4c20:	85 c0                	test   %eax,%eax
    4c22:	74 34                	je     4c58 <fwp_free_zombie+0xc8>
    4c24:	83 f8 01             	cmp    $0x1,%eax
    4c27:	0f 84 b3 00 00 00    	je     4ce0 <fwp_free_zombie+0x150>
    4c2d:	48 83 c4 18          	add    $0x18,%rsp
    4c31:	c3                   	ret
    4c32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c38:	c3                   	ret
    4c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c40:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4c44:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4c49:	e8 62 d9 ff ff       	call   25b0 <munmap@plt>
    4c4e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4c53:	eb 80                	jmp    4bd5 <fwp_free_zombie+0x45>
    4c55:	0f 1f 00             	nopl   (%rax)
    4c58:	48 8b 0d 79 7e 01 00 	mov    0x17e79(%rip),%rcx        # 1cad8 <fwp_heap+0x13d8>
    4c5f:	48 89 d0             	mov    %rdx,%rax
    4c62:	48 2b 05 47 7e 01 00 	sub    0x17e47(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    4c69:	48 c1 e1 10          	shl    $0x10,%rcx
    4c6d:	48 39 c8             	cmp    %rcx,%rax
    4c70:	73 bb                	jae    4c2d <fwp_free_zombie+0x9d>
    4c72:	48 89 c1             	mov    %rax,%rcx
    4c75:	48 c1 e9 10          	shr    $0x10,%rcx
    4c79:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4c7d:	48 8b 0d 74 7e 01 00 	mov    0x17e74(%rip),%rcx        # 1caf8 <fwp_heap+0x13f8>
    4c84:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4c88:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4c8c:	48 85 c9             	test   %rcx,%rcx
    4c8f:	74 9c                	je     4c2d <fwp_free_zombie+0x9d>
    4c91:	0f b6 3e             	movzbl (%rsi),%edi
    4c94:	40 80 ff 02          	cmp    $0x2,%dil
    4c98:	74 66                	je     4d00 <fwp_free_zombie+0x170>
    4c9a:	40 80 ff 01          	cmp    $0x1,%dil
    4c9e:	75 8d                	jne    4c2d <fwp_free_zombie+0x9d>
    4ca0:	8b 7e 18             	mov    0x18(%rsi),%edi
    4ca3:	0f b7 c0             	movzwl %ax,%eax
    4ca6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4ca9:	48 0f af c7          	imul   %rdi,%rax
    4cad:	48 c1 e8 20          	shr    $0x20,%rax
    4cb1:	48 39 f0             	cmp    %rsi,%rax
    4cb4:	0f 83 73 ff ff ff    	jae    4c2d <fwp_free_zombie+0x9d>
    4cba:	48 01 c1             	add    %rax,%rcx
    4cbd:	0f b6 01             	movzbl (%rcx),%eax
    4cc0:	84 c0                	test   %al,%al
    4cc2:	0f 84 65 ff ff ff    	je     4c2d <fwp_free_zombie+0x9d>
    4cc8:	3c 01                	cmp    $0x1,%al
    4cca:	74 14                	je     4ce0 <fwp_free_zombie+0x150>
    4ccc:	3c ff                	cmp    $0xff,%al
    4cce:	74 3b                	je     4d0b <fwp_free_zombie+0x17b>
    4cd0:	83 e8 01             	sub    $0x1,%eax
    4cd3:	88 01                	mov    %al,(%rcx)
    4cd5:	e9 53 ff ff ff       	jmp    4c2d <fwp_free_zombie+0x9d>
    4cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ce0:	48 89 d7             	mov    %rdx,%rdi
    4ce3:	48 83 c4 18          	add    $0x18,%rsp
    4ce7:	e9 c4 fd ff ff       	jmp    4ab0 <fwp_task_dispose>
    4cec:	0f 1f 40 00          	nopl   0x0(%rax)
    4cf0:	48 89 05 b1 69 01 00 	mov    %rax,0x169b1(%rip)        # 1b6a8 <fwp_tasks_active>
    4cf7:	e9 ff fe ff ff       	jmp    4bfb <fwp_free_zombie+0x6b>
    4cfc:	0f 1f 40 00          	nopl   0x0(%rax)
    4d00:	66 85 c0             	test   %ax,%ax
    4d03:	0f 85 24 ff ff ff    	jne    4c2d <fwp_free_zombie+0x9d>
    4d09:	eb b2                	jmp    4cbd <fwp_free_zombie+0x12d>
    4d0b:	48 89 ca             	mov    %rcx,%rdx
    4d0e:	48 8d 35 eb 69 01 00 	lea    0x169eb(%rip),%rsi        # 1b700 <fwp_heap>
    4d15:	48 c1 ea 11          	shr    $0x11,%rdx
    4d19:	48 31 ca             	xor    %rcx,%rdx
    4d1c:	48 89 d0             	mov    %rdx,%rax
    4d1f:	48 c1 e8 09          	shr    $0x9,%rax
    4d23:	48 31 c2             	xor    %rax,%rdx
    4d26:	0f b6 d2             	movzbl %dl,%edx
    4d29:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4d30:	00 
    4d31:	48 85 c0             	test   %rax,%rax
    4d34:	75 13                	jne    4d49 <fwp_free_zombie+0x1b9>
    4d36:	eb 4c                	jmp    4d84 <fwp_free_zombie+0x1f4>
    4d38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4d3f:	00 
    4d40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4d44:	48 85 c0             	test   %rax,%rax
    4d47:	74 3b                	je     4d84 <fwp_free_zombie+0x1f4>
    4d49:	48 89 c2             	mov    %rax,%rdx
    4d4c:	48 39 08             	cmp    %rcx,(%rax)
    4d4f:	75 ef                	jne    4d40 <fwp_free_zombie+0x1b0>
    4d51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4d55:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4d59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4d5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4d64:	0f 85 c3 fe ff ff    	jne    4c2d <fwp_free_zombie+0x9d>
    4d6a:	48 89 cf             	mov    %rcx,%rdi
    4d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4d72:	e8 59 f1 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4d77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4d7c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4d7f:	e9 a9 fe ff ff       	jmp    4c2d <fwp_free_zombie+0x9d>
    4d84:	48 8d 3d 15 36 00 00 	lea    0x3615(%rip),%rdi        # 83a0 <_IO_stdin_used+0x3a0>
    4d8b:	e8 70 e4 ff ff       	call   3200 <fwp_trap>

0000000000004d90 <fwp_block>:
    4d90:	48 83 ec 08          	sub    $0x8,%rsp
    4d94:	48 8b 05 2d 69 01 00 	mov    0x1692d(%rip),%rax        # 1b6c8 <fwp_ready_head>
    4d9b:	48 85 c0             	test   %rax,%rax
    4d9e:	0f 84 1c 01 00 00    	je     4ec0 <fwp_block+0x130>
    4da4:	90                   	nop
    4da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dac:	00 00 00 00 
    4db0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4db7:	48 89 15 0a 69 01 00 	mov    %rdx,0x1690a(%rip)        # 1b6c8 <fwp_ready_head>
    4dbe:	48 85 d2             	test   %rdx,%rdx
    4dc1:	0f 84 19 01 00 00    	je     4ee0 <fwp_block+0x150>
    4dc7:	48 8b 15 12 69 01 00 	mov    0x16912(%rip),%rdx        # 1b6e0 <fwp_cur>
    4dce:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4dd2:	48 39 c2             	cmp    %rax,%rdx
    4dd5:	0f 84 d5 00 00 00    	je     4eb0 <fwp_block+0x120>
    4ddb:	48 8b 0d 7e 85 01 00 	mov    0x1857e(%rip),%rcx        # 1d360 <fwp_state_owners>
    4de2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4de6:	48 89 05 f3 68 01 00 	mov    %rax,0x168f3(%rip)        # 1b6e0 <fwp_cur>
    4ded:	f3 0f 7e 05 93 85 01 	movq   0x18593(%rip),%xmm0        # 1d388 <fwp_foreign_callbacks>
    4df4:	00 
    4df5:	0f 16 05 7c 85 01 00 	movhps 0x1857c(%rip),%xmm0        # 1d378 <fwp_state>
    4dfc:	f3 0f 7e 0d 7c 85 01 	movq   0x1857c(%rip),%xmm1        # 1d380 <fwp_handlers>
    4e03:	00 
    4e04:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4e0b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4e12:	0f 16 0d 77 85 01 00 	movhps 0x18577(%rip),%xmm1        # 1d390 <fwp_cleanups>
    4e19:	f3 0f 7e 05 4f 85 01 	movq   0x1854f(%rip),%xmm0        # 1d370 <fwp_state_len>
    4e20:	00 
    4e21:	0f 16 05 40 85 01 00 	movhps 0x18540(%rip),%xmm0        # 1d368 <fwp_state_cap>
    4e28:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4e2f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4e36:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4e3a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4e41:	48 89 0d 38 85 01 00 	mov    %rcx,0x18538(%rip)        # 1d380 <fwp_handlers>
    4e48:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4e4f:	48 89 0d 3a 85 01 00 	mov    %rcx,0x1853a(%rip)        # 1d390 <fwp_cleanups>
    4e56:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4e5d:	48 89 0d 24 85 01 00 	mov    %rcx,0x18524(%rip)        # 1d388 <fwp_foreign_callbacks>
    4e64:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4e6b:	48 89 0d 06 85 01 00 	mov    %rcx,0x18506(%rip)        # 1d378 <fwp_state>
    4e72:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4e79:	48 89 0d f0 84 01 00 	mov    %rcx,0x184f0(%rip)        # 1d370 <fwp_state_len>
    4e80:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4e87:	48 89 0d da 84 01 00 	mov    %rcx,0x184da(%rip)        # 1d368 <fwp_state_cap>
    4e8e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4e95:	48 89 0d c4 84 01 00 	mov    %rcx,0x184c4(%rip)        # 1d360 <fwp_state_owners>
    4e9c:	e8 cf d5 ff ff       	call   2470 <swapcontext@plt>
    4ea1:	f3 0f 1e fa          	endbr64
    4ea5:	e8 e6 fc ff ff       	call   4b90 <fwp_free_zombie>
    4eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4eb0:	8b 05 ea 61 01 00    	mov    0x161ea(%rip),%eax        # 1b0a0 <fwp_slice>
    4eb6:	85 c0                	test   %eax,%eax
    4eb8:	74 36                	je     4ef0 <fwp_block+0x160>
    4eba:	48 83 c4 08          	add    $0x8,%rsp
    4ebe:	c3                   	ret
    4ebf:	90                   	nop
    4ec0:	e8 6b ed ff ff       	call   3c30 <fwp_poll_events>
    4ec5:	48 8b 05 fc 67 01 00 	mov    0x167fc(%rip),%rax        # 1b6c8 <fwp_ready_head>
    4ecc:	48 85 c0             	test   %rax,%rax
    4ecf:	0f 85 db fe ff ff    	jne    4db0 <fwp_block+0x20>
    4ed5:	eb e9                	jmp    4ec0 <fwp_block+0x130>
    4ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4ede:	00 00 
    4ee0:	48 c7 05 d5 67 01 00 	movq   $0x0,0x167d5(%rip)        # 1b6c0 <fwp_ready_tail>
    4ee7:	00 00 00 00 
    4eeb:	e9 d7 fe ff ff       	jmp    4dc7 <fwp_block+0x37>
    4ef0:	48 8d 3d fe 31 00 00 	lea    0x31fe(%rip),%rdi        # 80f5 <_IO_stdin_used+0xf5>
    4ef7:	e8 84 d4 ff ff       	call   2380 <getenv@plt>
    4efc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4f01:	48 85 c0             	test   %rax,%rax
    4f04:	74 05                	je     4f0b <fwp_block+0x17b>
    4f06:	80 38 00             	cmpb   $0x0,(%rax)
    4f09:	75 0b                	jne    4f16 <fwp_block+0x186>
    4f0b:	89 15 8f 61 01 00    	mov    %edx,0x1618f(%rip)        # 1b0a0 <fwp_slice>
    4f11:	48 83 c4 08          	add    $0x8,%rsp
    4f15:	c3                   	ret
    4f16:	ba 0a 00 00 00       	mov    $0xa,%edx
    4f1b:	31 f6                	xor    %esi,%esi
    4f1d:	48 89 c7             	mov    %rax,%rdi
    4f20:	e8 0b d6 ff ff       	call   2530 <strtoll@plt>
    4f25:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4f29:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4f30:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4f35:	0f 46 d0             	cmovbe %eax,%edx
    4f38:	eb d1                	jmp    4f0b <fwp_block+0x17b>
    4f3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004f40 <fwp_drop0>:
    4f40:	48 8b 15 91 7b 01 00 	mov    0x17b91(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    4f47:	48 89 f8             	mov    %rdi,%rax
    4f4a:	48 2b 05 5f 7b 01 00 	sub    0x17b5f(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    4f51:	48 c1 e2 10          	shl    $0x10,%rdx
    4f55:	48 39 d0             	cmp    %rdx,%rax
    4f58:	0f 83 c2 00 00 00    	jae    5020 <fwp_drop0+0xe0>
    4f5e:	48 83 ec 18          	sub    $0x18,%rsp
    4f62:	4c 8d 05 97 67 01 00 	lea    0x16797(%rip),%r8        # 1b700 <fwp_heap>
    4f69:	48 89 c2             	mov    %rax,%rdx
    4f6c:	48 c1 ea 10          	shr    $0x10,%rdx
    4f70:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f74:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4f7b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4f7f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4f83:	48 85 d2             	test   %rdx,%rdx
    4f86:	74 3c                	je     4fc4 <fwp_drop0+0x84>
    4f88:	0f b6 31             	movzbl (%rcx),%esi
    4f8b:	40 80 fe 02          	cmp    $0x2,%sil
    4f8f:	74 3f                	je     4fd0 <fwp_drop0+0x90>
    4f91:	40 80 fe 01          	cmp    $0x1,%sil
    4f95:	75 2d                	jne    4fc4 <fwp_drop0+0x84>
    4f97:	8b 71 18             	mov    0x18(%rcx),%esi
    4f9a:	0f b7 c0             	movzwl %ax,%eax
    4f9d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4fa0:	48 0f af c6          	imul   %rsi,%rax
    4fa4:	48 c1 e8 20          	shr    $0x20,%rax
    4fa8:	48 39 c8             	cmp    %rcx,%rax
    4fab:	73 17                	jae    4fc4 <fwp_drop0+0x84>
    4fad:	48 01 c2             	add    %rax,%rdx
    4fb0:	0f b6 02             	movzbl (%rdx),%eax
    4fb3:	84 c0                	test   %al,%al
    4fb5:	74 0d                	je     4fc4 <fwp_drop0+0x84>
    4fb7:	3c 01                	cmp    $0x1,%al
    4fb9:	74 25                	je     4fe0 <fwp_drop0+0xa0>
    4fbb:	3c ff                	cmp    $0xff,%al
    4fbd:	74 69                	je     5028 <fwp_drop0+0xe8>
    4fbf:	83 e8 01             	sub    $0x1,%eax
    4fc2:	88 02                	mov    %al,(%rdx)
    4fc4:	48 83 c4 18          	add    $0x18,%rsp
    4fc8:	c3                   	ret
    4fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fd0:	66 85 c0             	test   %ax,%ax
    4fd3:	74 db                	je     4fb0 <fwp_drop0+0x70>
    4fd5:	48 83 c4 18          	add    $0x18,%rsp
    4fd9:	c3                   	ret
    4fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fe0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4fe4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4fe9:	e8 22 f6 ff ff       	call   4610 <fwp_rc_free_arr>
    4fee:	4c 8d 05 0b 67 01 00 	lea    0x1670b(%rip),%r8        # 1b700 <fwp_heap>
    4ff5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4ffa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    5001:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    5008:	48 c1 e2 10          	shl    $0x10,%rdx
    500c:	48 39 d0             	cmp    %rdx,%rax
    500f:	73 b3                	jae    4fc4 <fwp_drop0+0x84>
    5011:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    5016:	e9 4e ff ff ff       	jmp    4f69 <fwp_drop0+0x29>
    501b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5020:	c3                   	ret
    5021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5028:	48 89 d0             	mov    %rdx,%rax
    502b:	48 c1 e8 11          	shr    $0x11,%rax
    502f:	48 31 d0             	xor    %rdx,%rax
    5032:	48 89 c1             	mov    %rax,%rcx
    5035:	48 c1 e9 09          	shr    $0x9,%rcx
    5039:	48 31 c8             	xor    %rcx,%rax
    503c:	0f b6 c8             	movzbl %al,%ecx
    503f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    5046:	00 
    5047:	48 85 c0             	test   %rax,%rax
    504a:	75 1d                	jne    5069 <fwp_drop0+0x129>
    504c:	eb 56                	jmp    50a4 <fwp_drop0+0x164>
    504e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    505c:	00 00 00 00 
    5060:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5064:	48 85 c0             	test   %rax,%rax
    5067:	74 3b                	je     50a4 <fwp_drop0+0x164>
    5069:	48 89 c1             	mov    %rax,%rcx
    506c:	48 39 10             	cmp    %rdx,(%rax)
    506f:	75 ef                	jne    5060 <fwp_drop0+0x120>
    5071:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5075:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5079:	48 89 48 08          	mov    %rcx,0x8(%rax)
    507d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5084:	0f 85 3a ff ff ff    	jne    4fc4 <fwp_drop0+0x84>
    508a:	48 89 d7             	mov    %rdx,%rdi
    508d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5092:	e8 39 ee ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5097:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    509c:	c6 02 fe             	movb   $0xfe,(%rdx)
    509f:	e9 20 ff ff ff       	jmp    4fc4 <fwp_drop0+0x84>
    50a4:	48 8d 3d f5 32 00 00 	lea    0x32f5(%rip),%rdi        # 83a0 <_IO_stdin_used+0x3a0>
    50ab:	e8 50 e1 ff ff       	call   3200 <fwp_trap>

00000000000050b0 <fwp_drop1>:
    50b0:	f3 0f 1e fa          	endbr64
    50b4:	48 8b 15 1d 7a 01 00 	mov    0x17a1d(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    50bb:	48 89 f8             	mov    %rdi,%rax
    50be:	48 2b 05 eb 79 01 00 	sub    0x179eb(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    50c5:	48 c1 e2 10          	shl    $0x10,%rdx
    50c9:	48 39 d0             	cmp    %rdx,%rax
    50cc:	0f 83 be 00 00 00    	jae    5190 <fwp_drop1+0xe0>
    50d2:	48 83 ec 18          	sub    $0x18,%rsp
    50d6:	4c 8d 05 23 66 01 00 	lea    0x16623(%rip),%r8        # 1b700 <fwp_heap>
    50dd:	48 89 c2             	mov    %rax,%rdx
    50e0:	48 c1 ea 10          	shr    $0x10,%rdx
    50e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    50e8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    50ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    50f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    50f7:	48 85 d2             	test   %rdx,%rdx
    50fa:	74 3c                	je     5138 <fwp_drop1+0x88>
    50fc:	0f b6 31             	movzbl (%rcx),%esi
    50ff:	40 80 fe 02          	cmp    $0x2,%sil
    5103:	74 3b                	je     5140 <fwp_drop1+0x90>
    5105:	40 80 fe 01          	cmp    $0x1,%sil
    5109:	75 2d                	jne    5138 <fwp_drop1+0x88>
    510b:	8b 71 18             	mov    0x18(%rcx),%esi
    510e:	0f b7 c0             	movzwl %ax,%eax
    5111:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5114:	48 0f af c6          	imul   %rsi,%rax
    5118:	48 c1 e8 20          	shr    $0x20,%rax
    511c:	48 39 c8             	cmp    %rcx,%rax
    511f:	73 17                	jae    5138 <fwp_drop1+0x88>
    5121:	48 01 c2             	add    %rax,%rdx
    5124:	0f b6 02             	movzbl (%rdx),%eax
    5127:	84 c0                	test   %al,%al
    5129:	74 0d                	je     5138 <fwp_drop1+0x88>
    512b:	3c 01                	cmp    $0x1,%al
    512d:	74 21                	je     5150 <fwp_drop1+0xa0>
    512f:	3c ff                	cmp    $0xff,%al
    5131:	74 65                	je     5198 <fwp_drop1+0xe8>
    5133:	83 e8 01             	sub    $0x1,%eax
    5136:	88 02                	mov    %al,(%rdx)
    5138:	48 83 c4 18          	add    $0x18,%rsp
    513c:	c3                   	ret
    513d:	0f 1f 00             	nopl   (%rax)
    5140:	66 85 c0             	test   %ax,%ax
    5143:	74 df                	je     5124 <fwp_drop1+0x74>
    5145:	48 83 c4 18          	add    $0x18,%rsp
    5149:	c3                   	ret
    514a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5150:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    5154:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5159:	e8 b2 f4 ff ff       	call   4610 <fwp_rc_free_arr>
    515e:	4c 8d 05 9b 65 01 00 	lea    0x1659b(%rip),%r8        # 1b700 <fwp_heap>
    5165:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    516a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    5171:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    5178:	48 c1 e2 10          	shl    $0x10,%rdx
    517c:	48 39 d0             	cmp    %rdx,%rax
    517f:	73 b7                	jae    5138 <fwp_drop1+0x88>
    5181:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    5186:	e9 52 ff ff ff       	jmp    50dd <fwp_drop1+0x2d>
    518b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5190:	c3                   	ret
    5191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5198:	48 89 d0             	mov    %rdx,%rax
    519b:	48 c1 e8 11          	shr    $0x11,%rax
    519f:	48 31 d0             	xor    %rdx,%rax
    51a2:	48 89 c1             	mov    %rax,%rcx
    51a5:	48 c1 e9 09          	shr    $0x9,%rcx
    51a9:	48 31 c8             	xor    %rcx,%rax
    51ac:	0f b6 c8             	movzbl %al,%ecx
    51af:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    51b6:	00 
    51b7:	48 85 c0             	test   %rax,%rax
    51ba:	75 0d                	jne    51c9 <fwp_drop1+0x119>
    51bc:	eb 46                	jmp    5204 <fwp_drop1+0x154>
    51be:	66 90                	xchg   %ax,%ax
    51c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    51c4:	48 85 c0             	test   %rax,%rax
    51c7:	74 3b                	je     5204 <fwp_drop1+0x154>
    51c9:	48 89 c1             	mov    %rax,%rcx
    51cc:	48 39 10             	cmp    %rdx,(%rax)
    51cf:	75 ef                	jne    51c0 <fwp_drop1+0x110>
    51d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    51d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    51d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    51dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    51e4:	0f 85 4e ff ff ff    	jne    5138 <fwp_drop1+0x88>
    51ea:	48 89 d7             	mov    %rdx,%rdi
    51ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    51f2:	e8 d9 ec ff ff       	call   3ed0 <fwp_rc_forget_slot>
    51f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    51fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    51ff:	e9 34 ff ff ff       	jmp    5138 <fwp_drop1+0x88>
    5204:	48 8d 3d 95 31 00 00 	lea    0x3195(%rip),%rdi        # 83a0 <_IO_stdin_used+0x3a0>
    520b:	e8 f0 df ff ff       	call   3200 <fwp_trap>

0000000000005210 <fwp_write.constprop.0>:
    5210:	41 57                	push   %r15
    5212:	41 56                	push   %r14
    5214:	41 55                	push   %r13
    5216:	41 54                	push   %r12
    5218:	55                   	push   %rbp
    5219:	53                   	push   %rbx
    521a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    5221:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5228:	00 00 
    522a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    5231:	00 
    5232:	49 89 d4             	mov    %rdx,%r12
    5235:	8b 12                	mov    (%rdx),%edx
    5237:	83 fa 19             	cmp    $0x19,%edx
    523a:	77 64                	ja     52a0 <fwp_write.constprop.0+0x90>
    523c:	48 8d 0d 1d 33 00 00 	lea    0x331d(%rip),%rcx        # 8560 <_IO_stdin_used+0x560>
    5243:	89 d0                	mov    %edx,%eax
    5245:	48 89 fb             	mov    %rdi,%rbx
    5248:	48 89 f5             	mov    %rsi,%rbp
    524b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    524f:	48 01 c8             	add    %rcx,%rax
    5252:	3e ff e0             	notrack jmp *%rax
    5255:	0f 1f 00             	nopl   (%rax)
    5258:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    525c:	48 8b 06             	mov    (%rsi),%rax
    525f:	48 89 ca             	mov    %rcx,%rdx
    5262:	48 85 c9             	test   %rcx,%rcx
    5265:	0f 88 b5 0c 00 00    	js     5f20 <fwp_write.constprop.0+0xd10>
    526b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5272:	00 
    5273:	48 89 c6             	mov    %rax,%rsi
    5276:	4c 89 e7             	mov    %r12,%rdi
    5279:	e8 82 d7 ff ff       	call   2a00 <fwp_fmt_u128>
    527e:	66 90                	xchg   %ax,%ax
    5280:	4c 89 e7             	mov    %r12,%rdi
    5283:	e8 a8 d1 ff ff       	call   2430 <strlen@plt>
    5288:	4c 89 e6             	mov    %r12,%rsi
    528b:	48 89 df             	mov    %rbx,%rdi
    528e:	48 89 c2             	mov    %rax,%rdx
    5291:	e8 1a dd ff ff       	call   2fb0 <buf_put>
    5296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    529d:	00 00 00 
    52a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    52a7:	00 
    52a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    52af:	00 00 
    52b1:	0f 85 9e 04 00 00    	jne    5755 <fwp_write.constprop.0+0x545>
    52b7:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    52be:	5b                   	pop    %rbx
    52bf:	5d                   	pop    %rbp
    52c0:	41 5c                	pop    %r12
    52c2:	41 5d                	pop    %r13
    52c4:	41 5e                	pop    %r14
    52c6:	41 5f                	pop    %r15
    52c8:	c3                   	ret
    52c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52d0:	49 89 f1             	mov    %rsi,%r9
    52d3:	4c 8d 05 43 2e 00 00 	lea    0x2e43(%rip),%r8        # 811d <_IO_stdin_used+0x11d>
    52da:	b9 00 02 00 00       	mov    $0x200,%ecx
    52df:	ba 02 00 00 00       	mov    $0x2,%edx
    52e4:	be 00 02 00 00       	mov    $0x200,%esi
    52e9:	31 c0                	xor    %eax,%eax
    52eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    52f2:	00 
    52f3:	e8 98 d0 ff ff       	call   2390 <__snprintf_chk@plt>
    52f8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    52ff:	00 
    5300:	e8 2b d1 ff ff       	call   2430 <strlen@plt>
    5305:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    530c:	00 
    530d:	48 89 df             	mov    %rbx,%rdi
    5310:	48 89 c2             	mov    %rax,%rdx
    5313:	e8 98 dc ff ff       	call   2fb0 <buf_put>
    5318:	eb 86                	jmp    52a0 <fwp_write.constprop.0+0x90>
    531a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5320:	49 89 f1             	mov    %rsi,%r9
    5323:	4c 8d 05 ee 2d 00 00 	lea    0x2dee(%rip),%r8        # 8118 <_IO_stdin_used+0x118>
    532a:	eb ae                	jmp    52da <fwp_write.constprop.0+0xca>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	83 fa 13             	cmp    $0x13,%edx
    5333:	48 8d 05 d4 2d 00 00 	lea    0x2dd4(%rip),%rax        # 810e <_IO_stdin_used+0x10e>
    533a:	48 8d 35 d2 2d 00 00 	lea    0x2dd2(%rip),%rsi        # 8113 <_IO_stdin_used+0x113>
    5341:	ba 04 00 00 00       	mov    $0x4,%edx
    5346:	48 0f 44 f0          	cmove  %rax,%rsi
    534a:	45 31 ed             	xor    %r13d,%r13d
    534d:	e8 5e dc ff ff       	call   2fb0 <buf_put>
    5352:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5357:	0f 84 b3 09 00 00    	je     5d10 <fwp_write.constprop.0+0xb00>
    535d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5362:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5367:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    536c:	48 89 df             	mov    %rbx,%rdi
    536f:	49 0f 44 c5          	cmove  %r13,%rax
    5373:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5378:	e8 93 fe ff ff       	call   5210 <fwp_write.constprop.0>
    537d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5382:	0f 84 80 0a 00 00    	je     5e08 <fwp_write.constprop.0+0xbf8>
    5388:	49 83 c5 01          	add    $0x1,%r13
    538c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5390:	0f 83 7a 09 00 00    	jae    5d10 <fwp_write.constprop.0+0xb00>
    5396:	ba 02 00 00 00       	mov    $0x2,%edx
    539b:	48 8d 35 bb 2d 00 00 	lea    0x2dbb(%rip),%rsi        # 815d <_IO_stdin_used+0x15d>
    53a2:	48 89 df             	mov    %rbx,%rdi
    53a5:	e8 06 dc ff ff       	call   2fb0 <buf_put>
    53aa:	eb b1                	jmp    535d <fwp_write.constprop.0+0x14d>
    53ac:	0f 1f 40 00          	nopl   0x0(%rax)
    53b0:	ba 06 00 00 00       	mov    $0x6,%edx
    53b5:	48 8d 35 7a 2d 00 00 	lea    0x2d7a(%rip),%rsi        # 8136 <_IO_stdin_used+0x136>
    53bc:	48 83 c5 10          	add    $0x10,%rbp
    53c0:	e8 eb db ff ff       	call   2fb0 <buf_put>
    53c5:	48 89 ef             	mov    %rbp,%rdi
    53c8:	e8 63 d0 ff ff       	call   2430 <strlen@plt>
    53cd:	48 89 ee             	mov    %rbp,%rsi
    53d0:	48 89 df             	mov    %rbx,%rdi
    53d3:	48 89 c2             	mov    %rax,%rdx
    53d6:	e8 d5 db ff ff       	call   2fb0 <buf_put>
    53db:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    53e0:	ba 01 00 00 00       	mov    $0x1,%edx
    53e5:	48 89 df             	mov    %rbx,%rdi
    53e8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    53ed:	e8 be db ff ff       	call   2fb0 <buf_put>
    53f2:	e9 a9 fe ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    53f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53fe:	00 00 
    5400:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5407:	00 
    5408:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    540f:	00 00 
    5411:	0f 85 3e 03 00 00    	jne    5755 <fwp_write.constprop.0+0x545>
    5417:	ba 0a 00 00 00       	mov    $0xa,%edx
    541c:	48 8d 35 ff 2c 00 00 	lea    0x2cff(%rip),%rsi        # 8122 <_IO_stdin_used+0x122>
    5423:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    542a:	48 89 df             	mov    %rbx,%rdi
    542d:	5b                   	pop    %rbx
    542e:	5d                   	pop    %rbp
    542f:	41 5c                	pop    %r12
    5431:	41 5d                	pop    %r13
    5433:	41 5e                	pop    %r14
    5435:	41 5f                	pop    %r15
    5437:	e9 74 db ff ff       	jmp    2fb0 <buf_put>
    543c:	0f 1f 40 00          	nopl   0x0(%rax)
    5440:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5445:	4d 85 ed             	test   %r13,%r13
    5448:	0f 84 c2 0b 00 00    	je     6010 <fwp_write.constprop.0+0xe00>
    544e:	48 8d 35 15 2d 00 00 	lea    0x2d15(%rip),%rsi        # 816a <_IO_stdin_used+0x16a>
    5455:	4c 89 ef             	mov    %r13,%rdi
    5458:	e8 b3 d0 ff ff       	call   2510 <strcmp@plt>
    545d:	41 89 c1             	mov    %eax,%r9d
    5460:	85 c0                	test   %eax,%eax
    5462:	0f 84 2c 0c 00 00    	je     6094 <fwp_write.constprop.0+0xe84>
    5468:	4c 89 ef             	mov    %r13,%rdi
    546b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5470:	e8 bb cf ff ff       	call   2430 <strlen@plt>
    5475:	4c 89 ee             	mov    %r13,%rsi
    5478:	48 89 df             	mov    %rbx,%rdi
    547b:	48 89 c2             	mov    %rax,%rdx
    547e:	e8 2d db ff ff       	call   2fb0 <buf_put>
    5483:	ba 01 00 00 00       	mov    $0x1,%edx
    5488:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    548d:	48 89 df             	mov    %rbx,%rdi
    5490:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5495:	e8 16 db ff ff       	call   2fb0 <buf_put>
    549a:	ba 01 00 00 00       	mov    $0x1,%edx
    549f:	4c 89 fe             	mov    %r15,%rsi
    54a2:	48 89 df             	mov    %rbx,%rdi
    54a5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    54aa:	e8 01 db ff ff       	call   2fb0 <buf_put>
    54af:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    54b4:	45 31 f6             	xor    %r14d,%r14d
    54b7:	85 c0                	test   %eax,%eax
    54b9:	0f 8e 91 0a 00 00    	jle    5f50 <fwp_write.constprop.0+0xd40>
    54bf:	45 31 ed             	xor    %r13d,%r13d
    54c2:	4d 85 ed             	test   %r13,%r13
    54c5:	0f 85 d5 08 00 00    	jne    5da0 <fwp_write.constprop.0+0xb90>
    54cb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    54d2:	00 
    54d3:	45 85 f6             	test   %r14d,%r14d
    54d6:	0f 84 74 08 00 00    	je     5d50 <fwp_write.constprop.0+0xb40>
    54dc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    54e1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    54e6:	48 89 df             	mov    %rbx,%rdi
    54e9:	49 83 c5 01          	add    $0x1,%r13
    54ed:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    54f1:	e8 1a fd ff ff       	call   5210 <fwp_write.constprop.0>
    54f6:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    54fb:	7f c5                	jg     54c2 <fwp_write.constprop.0+0x2b2>
    54fd:	45 85 f6             	test   %r14d,%r14d
    5500:	0f 84 4a 0a 00 00    	je     5f50 <fwp_write.constprop.0+0xd40>
    5506:	b8 29 00 00 00       	mov    $0x29,%eax
    550b:	ba 01 00 00 00       	mov    $0x1,%edx
    5510:	4c 89 fe             	mov    %r15,%rsi
    5513:	48 89 df             	mov    %rbx,%rdi
    5516:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    551a:	e8 91 da ff ff       	call   2fb0 <buf_put>
    551f:	e9 7c fd ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5524:	0f 1f 40 00          	nopl   0x0(%rax)
    5528:	ba 01 00 00 00       	mov    $0x1,%edx
    552d:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5532:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    5537:	e8 74 da ff ff       	call   2fb0 <buf_put>
    553c:	48 85 ed             	test   %rbp,%rbp
    553f:	0f 84 8b 07 00 00    	je     5cd0 <fwp_write.constprop.0+0xac0>
    5545:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5549:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    554e:	48 89 df             	mov    %rbx,%rdi
    5551:	e8 ba fc ff ff       	call   5210 <fwp_write.constprop.0>
    5556:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    555a:	48 85 ed             	test   %rbp,%rbp
    555d:	0f 84 6d 07 00 00    	je     5cd0 <fwp_write.constprop.0+0xac0>
    5563:	ba 02 00 00 00       	mov    $0x2,%edx
    5568:	48 8d 35 ee 2b 00 00 	lea    0x2bee(%rip),%rsi        # 815d <_IO_stdin_used+0x15d>
    556f:	48 89 df             	mov    %rbx,%rdi
    5572:	e8 39 da ff ff       	call   2fb0 <buf_put>
    5577:	eb cc                	jmp    5545 <fwp_write.constprop.0+0x335>
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	4c 8b 2e             	mov    (%rsi),%r13
    5583:	ba 01 00 00 00       	mov    $0x1,%edx
    5588:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    558d:	48 83 c5 08          	add    $0x8,%rbp
    5591:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5596:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    559b:	e8 10 da ff ff       	call   2fb0 <buf_put>
    55a0:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    55a5:	4d 85 ed             	test   %r13,%r13
    55a8:	75 43                	jne    55ed <fwp_write.constprop.0+0x3dd>
    55aa:	e9 81 07 00 00       	jmp    5d30 <fwp_write.constprop.0+0xb20>
    55af:	90                   	nop
    55b0:	41 80 f9 09          	cmp    $0x9,%r9b
    55b4:	0f 84 f6 06 00 00    	je     5cb0 <fwp_write.constprop.0+0xaa0>
    55ba:	41 80 f9 0a          	cmp    $0xa,%r9b
    55be:	0f 85 bc 06 00 00    	jne    5c80 <fwp_write.constprop.0+0xa70>
    55c4:	ba 02 00 00 00       	mov    $0x2,%edx
    55c9:	48 8d 35 73 2b 00 00 	lea    0x2b73(%rip),%rsi        # 8143 <_IO_stdin_used+0x143>
    55d0:	48 89 df             	mov    %rbx,%rdi
    55d3:	e8 d8 d9 ff ff       	call   2fb0 <buf_put>
    55d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    55df:	00 
    55e0:	48 83 c5 01          	add    $0x1,%rbp
    55e4:	49 39 ec             	cmp    %rbp,%r12
    55e7:	0f 84 43 07 00 00    	je     5d30 <fwp_write.constprop.0+0xb20>
    55ed:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    55f2:	41 80 f9 0d          	cmp    $0xd,%r9b
    55f6:	0f 84 64 06 00 00    	je     5c60 <fwp_write.constprop.0+0xa50>
    55fc:	7e b2                	jle    55b0 <fwp_write.constprop.0+0x3a0>
    55fe:	41 80 f9 22          	cmp    $0x22,%r9b
    5602:	0f 84 38 06 00 00    	je     5c40 <fwp_write.constprop.0+0xa30>
    5608:	41 80 f9 5c          	cmp    $0x5c,%r9b
    560c:	0f 85 6e 06 00 00    	jne    5c80 <fwp_write.constprop.0+0xa70>
    5612:	ba 02 00 00 00       	mov    $0x2,%edx
    5617:	48 8d 35 22 2b 00 00 	lea    0x2b22(%rip),%rsi        # 8140 <_IO_stdin_used+0x140>
    561e:	48 89 df             	mov    %rbx,%rdi
    5621:	e8 8a d9 ff ff       	call   2fb0 <buf_put>
    5626:	eb b8                	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    562f:	00 
    5630:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    5635:	ba 01 00 00 00       	mov    $0x1,%edx
    563a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    563f:	48 89 ee             	mov    %rbp,%rsi
    5642:	e8 69 d9 ff ff       	call   2fb0 <buf_put>
    5647:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    564c:	4c 89 e7             	mov    %r12,%rdi
    564f:	e8 dc cd ff ff       	call   2430 <strlen@plt>
    5654:	4c 89 e6             	mov    %r12,%rsi
    5657:	48 89 df             	mov    %rbx,%rdi
    565a:	48 89 c2             	mov    %rax,%rdx
    565d:	e8 4e d9 ff ff       	call   2fb0 <buf_put>
    5662:	ba 01 00 00 00       	mov    $0x1,%edx
    5667:	48 89 ee             	mov    %rbp,%rsi
    566a:	48 89 df             	mov    %rbx,%rdi
    566d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5672:	e8 39 d9 ff ff       	call   2fb0 <buf_put>
    5677:	e9 24 fc ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    567c:	0f 1f 40 00          	nopl   0x0(%rax)
    5680:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5685:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5689:	0f 8a de 0a 00 00    	jp     616d <fwp_write.constprop.0+0xf5d>
    568f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5693:	66 0f 54 05 b5 2f 00 	andpd  0x2fb5(%rip),%xmm0        # 8650 <msg.3+0x80>
    569a:	00 
    569b:	bd 01 00 00 00       	mov    $0x1,%ebp
    56a0:	66 0f 2e 05 c8 2f 00 	ucomisd 0x2fc8(%rip),%xmm0        # 8670 <msg.3+0xa0>
    56a7:	00 
    56a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    56af:	00 
    56b0:	0f 87 02 09 00 00    	ja     5fb8 <fwp_write.constprop.0+0xda8>
    56b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56bd:	00 00 00 
    56c0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    56c4:	89 ee                	mov    %ebp,%esi
    56c6:	4c 89 e7             	mov    %r12,%rdi
    56c9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    56ce:	e8 fd db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    56d3:	31 f6                	xor    %esi,%esi
    56d5:	4c 89 e7             	mov    %r12,%rdi
    56d8:	e8 13 cd ff ff       	call   23f0 <strtod@plt>
    56dd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    56e2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    56e6:	7a 06                	jp     56ee <fwp_write.constprop.0+0x4de>
    56e8:	0f 84 09 03 00 00    	je     59f7 <fwp_write.constprop.0+0x7e7>
    56ee:	83 c5 01             	add    $0x1,%ebp
    56f1:	83 fd 12             	cmp    $0x12,%ebp
    56f4:	75 ca                	jne    56c0 <fwp_write.constprop.0+0x4b0>
    56f6:	be 11 00 00 00       	mov    $0x11,%esi
    56fb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    56ff:	4c 89 e7             	mov    %r12,%rdi
    5702:	e8 c9 db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5707:	e9 eb 02 00 00       	jmp    59f7 <fwp_write.constprop.0+0x7e7>
    570c:	0f 1f 40 00          	nopl   0x0(%rax)
    5710:	48 83 fe 01          	cmp    $0x1,%rsi
    5714:	0f 84 86 08 00 00    	je     5fa0 <fwp_write.constprop.0+0xd90>
    571a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    571e:	b8 02 00 00 00       	mov    $0x2,%eax
    5723:	ba 01 00 00 00       	mov    $0x1,%edx
    5728:	48 0f 44 d0          	cmove  %rax,%rdx
    572c:	48 8d 35 d9 29 00 00 	lea    0x29d9(%rip),%rsi        # 810c <_IO_stdin_used+0x10c>
    5733:	48 8d 05 cf 29 00 00 	lea    0x29cf(%rip),%rax        # 8109 <_IO_stdin_used+0x109>
    573a:	48 0f 44 f0          	cmove  %rax,%rsi
    573e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5745:	00 
    5746:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    574d:	00 00 
    574f:	0f 84 ce fc ff ff    	je     5423 <fwp_write.constprop.0+0x213>
    5755:	e8 e6 cc ff ff       	call   2440 <__stack_chk_fail@plt>
    575a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5760:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5765:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    576a:	e8 81 d7 ff ff       	call   2ef0 <buf_grow>
    576f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5773:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5779:	4c 03 0b             	add    (%rbx),%r9
    577c:	66 45 89 11          	mov    %r10w,(%r9)
    5780:	49 83 c1 01          	add    $0x1,%r9
    5784:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    578b:	55 55 55 
    578e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5795:	aa aa aa 
    5798:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    579c:	45 85 e4             	test   %r12d,%r12d
    579f:	7f 4c                	jg     57ed <fwp_write.constprop.0+0x5dd>
    57a1:	e9 4a 05 00 00       	jmp    5cf0 <fwp_write.constprop.0+0xae0>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 
    57b0:	be 01 00 00 00       	mov    $0x1,%esi
    57b5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    57ba:	88 07                	mov    %al,(%rdi)
    57bc:	48 89 e8             	mov    %rbp,%rax
    57bf:	49 f7 e8             	imul   %r8
    57c2:	48 89 e8             	mov    %rbp,%rax
    57c5:	48 c1 f8 3f          	sar    $0x3f,%rax
    57c9:	48 29 c2             	sub    %rax,%rdx
    57cc:	48 85 c9             	test   %rcx,%rcx
    57cf:	0f 95 c0             	setne  %al
    57d2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    57d6:	48 83 ef 01          	sub    $0x1,%rdi
    57da:	48 21 c5             	and    %rax,%rbp
    57dd:	48 29 ea             	sub    %rbp,%rdx
    57e0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    57e4:	49 39 f9             	cmp    %rdi,%r9
    57e7:	0f 84 03 05 00 00    	je     5cf0 <fwp_write.constprop.0+0xae0>
    57ed:	48 89 e8             	mov    %rbp,%rax
    57f0:	49 f7 e8             	imul   %r8
    57f3:	48 89 e8             	mov    %rbp,%rax
    57f6:	48 c1 f8 3f          	sar    $0x3f,%rax
    57fa:	48 89 d1             	mov    %rdx,%rcx
    57fd:	48 29 c1             	sub    %rax,%rcx
    5800:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    5804:	48 89 e9             	mov    %rbp,%rcx
    5807:	48 29 c1             	sub    %rax,%rcx
    580a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    580e:	49 f7 e2             	mul    %r10
    5811:	b8 30 00 00 00       	mov    $0x30,%eax
    5816:	48 89 d6             	mov    %rdx,%rsi
    5819:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    581d:	48 d1 ee             	shr    $1,%rsi
    5820:	48 01 f2             	add    %rsi,%rdx
    5823:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    5827:	48 29 d6             	sub    %rdx,%rsi
    582a:	74 8e                	je     57ba <fwp_write.constprop.0+0x5aa>
    582c:	48 83 fe 01          	cmp    $0x1,%rsi
    5830:	0f 85 7a ff ff ff    	jne    57b0 <fwp_write.constprop.0+0x5a0>
    5836:	31 f6                	xor    %esi,%esi
    5838:	b8 2b 00 00 00       	mov    $0x2b,%eax
    583d:	e9 78 ff ff ff       	jmp    57ba <fwp_write.constprop.0+0x5aa>
    5842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5848:	ba 06 00 00 00       	mov    $0x6,%edx
    584d:	48 8d 35 0c 29 00 00 	lea    0x290c(%rip),%rsi        # 8160 <_IO_stdin_used+0x160>
    5854:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    585a:	e8 51 d7 ff ff       	call   2fb0 <buf_put>
    585f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5866:	ff ff 7f 
    5869:	48 23 55 00          	and    0x0(%rbp),%rdx
    586d:	0f 84 4e 03 00 00    	je     5bc1 <fwp_write.constprop.0+0x9b1>
    5873:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5878:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    587c:	48 85 d2             	test   %rdx,%rdx
    587f:	0f 84 a4 00 00 00    	je     5929 <fwp_write.constprop.0+0x719>
    5885:	8b 0a                	mov    (%rdx),%ecx
    5887:	83 f9 1c             	cmp    $0x1c,%ecx
    588a:	0f 84 d0 06 00 00    	je     5f60 <fwp_write.constprop.0+0xd50>
    5890:	83 f9 1b             	cmp    $0x1b,%ecx
    5893:	0f 87 90 00 00 00    	ja     5929 <fwp_write.constprop.0+0x719>
    5899:	be 01 00 00 00       	mov    $0x1,%esi
    589e:	48 d3 e6             	shl    %cl,%rsi
    58a1:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    58a7:	0f 85 13 06 00 00    	jne    5ec0 <fwp_write.constprop.0+0xcb0>
    58ad:	f7 c6 84 04 00 00    	test   $0x484,%esi
    58b3:	0f 85 d7 05 00 00    	jne    5e90 <fwp_write.constprop.0+0xc80>
    58b9:	83 e6 21             	and    $0x21,%esi
    58bc:	74 6b                	je     5929 <fwp_write.constprop.0+0x719>
    58be:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    58c3:	48 85 ff             	test   %rdi,%rdi
    58c6:	79 07                	jns    58cf <fwp_write.constprop.0+0x6bf>
    58c8:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    58cc:	4c 01 ee             	add    %r13,%rsi
    58cf:	48 0f be 3e          	movsbq (%rsi),%rdi
    58d3:	85 c9                	test   %ecx,%ecx
    58d5:	40 0f b6 f7          	movzbl %dil,%esi
    58d9:	48 0f 44 f7          	cmove  %rdi,%rsi
    58dd:	0f 1f 00             	nopl   (%rax)
    58e0:	48 89 df             	mov    %rbx,%rdi
    58e3:	49 83 c5 01          	add    $0x1,%r13
    58e7:	e8 24 f9 ff ff       	call   5210 <fwp_write.constprop.0>
    58ec:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    58f3:	ff ff 7f 
    58f6:	48 23 55 00          	and    0x0(%rbp),%rdx
    58fa:	49 39 d5             	cmp    %rdx,%r13
    58fd:	0f 83 be 02 00 00    	jae    5bc1 <fwp_write.constprop.0+0x9b1>
    5903:	ba 02 00 00 00       	mov    $0x2,%edx
    5908:	48 89 df             	mov    %rbx,%rdi
    590b:	48 8d 35 4b 28 00 00 	lea    0x284b(%rip),%rsi        # 815d <_IO_stdin_used+0x15d>
    5912:	e8 99 d6 ff ff       	call   2fb0 <buf_put>
    5917:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    591c:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    5920:	48 85 d2             	test   %rdx,%rdx
    5923:	0f 85 5c ff ff ff    	jne    5885 <fwp_write.constprop.0+0x675>
    5929:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    592e:	48 85 ff             	test   %rdi,%rdi
    5931:	0f 88 51 06 00 00    	js     5f88 <fwp_write.constprop.0+0xd78>
    5937:	48 8b 31             	mov    (%rcx),%rsi
    593a:	eb a4                	jmp    58e0 <fwp_write.constprop.0+0x6d0>
    593c:	0f 1f 40 00          	nopl   0x0(%rax)
    5940:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5947:	00 
    5948:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    594f:	00 00 
    5951:	0f 85 fe fd ff ff    	jne    5755 <fwp_write.constprop.0+0x545>
    5957:	ba 08 00 00 00       	mov    $0x8,%edx
    595c:	48 8d 35 ca 27 00 00 	lea    0x27ca(%rip),%rsi        # 812d <_IO_stdin_used+0x12d>
    5963:	e9 bb fa ff ff       	jmp    5423 <fwp_write.constprop.0+0x213>
    5968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    596f:	00 
    5970:	66 0f 6e ce          	movd   %esi,%xmm1
    5974:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5977:	0f 8a f0 07 00 00    	jp     616d <fwp_write.constprop.0+0xf5d>
    597d:	0f 28 c1             	movaps %xmm1,%xmm0
    5980:	0f 54 05 b9 2c 00 00 	andps  0x2cb9(%rip),%xmm0        # 8640 <msg.3+0x70>
    5987:	0f 2e 05 76 26 00 00 	ucomiss 0x2676(%rip),%xmm0        # 8004 <_IO_stdin_used+0x4>
    598e:	0f 87 4c 06 00 00    	ja     5fe0 <fwp_write.constprop.0+0xdd0>
    5994:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5998:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    599e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    59a5:	00 
    59a6:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    59aa:	66 49 0f 7e d7       	movq   %xmm2,%r15
    59af:	90                   	nop
    59b0:	44 89 ee             	mov    %r13d,%esi
    59b3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    59b8:	4c 89 e7             	mov    %r12,%rdi
    59bb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    59c0:	e8 0b d9 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    59c5:	31 f6                	xor    %esi,%esi
    59c7:	4c 89 e7             	mov    %r12,%rdi
    59ca:	e8 c1 ca ff ff       	call   2490 <strtof@plt>
    59cf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    59d4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    59d7:	7a 02                	jp     59db <fwp_write.constprop.0+0x7cb>
    59d9:	74 1c                	je     59f7 <fwp_write.constprop.0+0x7e7>
    59db:	41 83 c5 01          	add    $0x1,%r13d
    59df:	41 83 fd 0a          	cmp    $0xa,%r13d
    59e3:	75 cb                	jne    59b0 <fwp_write.constprop.0+0x7a0>
    59e5:	be 09 00 00 00       	mov    $0x9,%esi
    59ea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    59ef:	4c 89 e7             	mov    %r12,%rdi
    59f2:	e8 d9 d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    59f7:	4c 89 e7             	mov    %r12,%rdi
    59fa:	e8 71 d6 ff ff       	call   3070 <fwp_finish_float>
    59ff:	e9 7c f8 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    5a04:	0f 1f 40 00          	nopl   0x0(%rax)
    5a08:	89 f0                	mov    %esi,%eax
    5a0a:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5a11:	76 02                	jbe    5a15 <fwp_write.constprop.0+0x805>
    5a13:	8b 06                	mov    (%rsi),%eax
    5a15:	41 89 c6             	mov    %eax,%r14d
    5a18:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5a1d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5a22:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5a26:	4c 89 ef             	mov    %r13,%rdi
    5a29:	e8 02 ca ff ff       	call   2430 <strlen@plt>
    5a2e:	4c 89 ee             	mov    %r13,%rsi
    5a31:	48 89 df             	mov    %rbx,%rdi
    5a34:	48 89 c2             	mov    %rax,%rdx
    5a37:	e8 74 d5 ff ff       	call   2fb0 <buf_put>
    5a3c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5a41:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5a45:	85 f6                	test   %esi,%esi
    5a47:	0f 8e 53 f8 ff ff    	jle    52a0 <fwp_write.constprop.0+0x90>
    5a4d:	45 31 ed             	xor    %r13d,%r13d
    5a50:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5a55:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    5a5a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a5f:	4c 89 fe             	mov    %r15,%rsi
    5a62:	48 89 df             	mov    %rbx,%rdi
    5a65:	ba 01 00 00 00       	mov    $0x1,%edx
    5a6a:	48 89 04 24          	mov    %rax,(%rsp)
    5a6e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5a73:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5a77:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    5a7b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5a80:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5a85:	e8 26 d5 ff ff       	call   2fb0 <buf_put>
    5a8a:	41 8b 06             	mov    (%r14),%eax
    5a8d:	83 f8 0e             	cmp    $0xe,%eax
    5a90:	0f 84 5a 03 00 00    	je     5df0 <fwp_write.constprop.0+0xbe0>
    5a96:	83 f8 10             	cmp    $0x10,%eax
    5a99:	0f 84 21 03 00 00    	je     5dc0 <fwp_write.constprop.0+0xbb0>
    5a9f:	83 f8 0a             	cmp    $0xa,%eax
    5aa2:	0f 84 68 04 00 00    	je     5f10 <fwp_write.constprop.0+0xd00>
    5aa8:	0f 8f 32 01 00 00    	jg     5be0 <fwp_write.constprop.0+0x9d0>
    5aae:	83 f8 03             	cmp    $0x3,%eax
    5ab1:	0f 8f 39 04 00 00    	jg     5ef0 <fwp_write.constprop.0+0xce0>
    5ab7:	85 c0                	test   %eax,%eax
    5ab9:	78 10                	js     5acb <fwp_write.constprop.0+0x8bb>
    5abb:	48 8b 04 24          	mov    (%rsp),%rax
    5abf:	48 c1 e8 3f          	shr    $0x3f,%rax
    5ac3:	85 c0                	test   %eax,%eax
    5ac5:	0f 85 32 01 00 00    	jne    5bfd <fwp_write.constprop.0+0x9ed>
    5acb:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5ad0:	48 8b 34 24          	mov    (%rsp),%rsi
    5ad4:	48 89 df             	mov    %rbx,%rdi
    5ad7:	e8 34 f7 ff ff       	call   5210 <fwp_write.constprop.0>
    5adc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5ae1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5ae6:	49 83 c5 01          	add    $0x1,%r13
    5aea:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    5aee:	0f 8f 61 ff ff ff    	jg     5a55 <fwp_write.constprop.0+0x845>
    5af4:	e9 a7 f7 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b00:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5b04:	48 8b 36             	mov    (%rsi),%rsi
    5b07:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    5b0e:	00 
    5b0f:	48 89 ef             	mov    %rbp,%rdi
    5b12:	e8 e9 ce ff ff       	call   2a00 <fwp_fmt_u128>
    5b17:	48 89 ef             	mov    %rbp,%rdi
    5b1a:	e8 11 c9 ff ff       	call   2430 <strlen@plt>
    5b1f:	48 89 ee             	mov    %rbp,%rsi
    5b22:	48 89 df             	mov    %rbx,%rdi
    5b25:	48 89 c2             	mov    %rax,%rdx
    5b28:	e8 83 d4 ff ff       	call   2fb0 <buf_put>
    5b2d:	e9 6e f7 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b38:	ba 06 00 00 00       	mov    $0x6,%edx
    5b3d:	48 8d 35 0f 26 00 00 	lea    0x260f(%rip),%rsi        # 8153 <_IO_stdin_used+0x153>
    5b44:	45 31 ed             	xor    %r13d,%r13d
    5b47:	e8 64 d4 ff ff       	call   2fb0 <buf_put>
    5b4c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5b51:	75 19                	jne    5b6c <fwp_write.constprop.0+0x95c>
    5b53:	eb 6c                	jmp    5bc1 <fwp_write.constprop.0+0x9b1>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	ba 02 00 00 00       	mov    $0x2,%edx
    5b5d:	48 8d 35 f9 25 00 00 	lea    0x25f9(%rip),%rsi        # 815d <_IO_stdin_used+0x15d>
    5b64:	48 89 df             	mov    %rbx,%rdi
    5b67:	e8 44 d4 ff ff       	call   2fb0 <buf_put>
    5b6c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5b72:	b9 00 02 00 00       	mov    $0x200,%ecx
    5b77:	31 c0                	xor    %eax,%eax
    5b79:	49 83 c5 01          	add    $0x1,%r13
    5b7d:	4c 8d 05 d6 25 00 00 	lea    0x25d6(%rip),%r8        # 815a <_IO_stdin_used+0x15a>
    5b84:	ba 02 00 00 00       	mov    $0x2,%edx
    5b89:	be 00 02 00 00       	mov    $0x200,%esi
    5b8e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5b95:	00 
    5b96:	e8 f5 c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5b9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5ba2:	00 
    5ba3:	e8 88 c8 ff ff       	call   2430 <strlen@plt>
    5ba8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5baf:	00 
    5bb0:	48 89 df             	mov    %rbx,%rdi
    5bb3:	48 89 c2             	mov    %rax,%rdx
    5bb6:	e8 f5 d3 ff ff       	call   2fb0 <buf_put>
    5bbb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5bbf:	72 97                	jb     5b58 <fwp_write.constprop.0+0x948>
    5bc1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5bc6:	ba 01 00 00 00       	mov    $0x1,%edx
    5bcb:	48 89 df             	mov    %rbx,%rdi
    5bce:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5bd3:	e8 d8 d3 ff ff       	call   2fb0 <buf_put>
    5bd8:	e9 c3 f6 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5bdd:	0f 1f 00             	nopl   (%rax)
    5be0:	83 f8 0b             	cmp    $0xb,%eax
    5be3:	0f 85 e2 fe ff ff    	jne    5acb <fwp_write.constprop.0+0x8bb>
    5be9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5bee:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5bf2:	83 e0 01             	and    $0x1,%eax
    5bf5:	85 c0                	test   %eax,%eax
    5bf7:	0f 84 ce fe ff ff    	je     5acb <fwp_write.constprop.0+0x8bb>
    5bfd:	4c 89 fe             	mov    %r15,%rsi
    5c00:	48 89 df             	mov    %rbx,%rdi
    5c03:	ba 01 00 00 00       	mov    $0x1,%edx
    5c08:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5c0d:	e8 9e d3 ff ff       	call   2fb0 <buf_put>
    5c12:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5c17:	48 8b 34 24          	mov    (%rsp),%rsi
    5c1b:	48 89 df             	mov    %rbx,%rdi
    5c1e:	e8 ed f5 ff ff       	call   5210 <fwp_write.constprop.0>
    5c23:	ba 01 00 00 00       	mov    $0x1,%edx
    5c28:	4c 89 fe             	mov    %r15,%rsi
    5c2b:	48 89 df             	mov    %rbx,%rdi
    5c2e:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5c33:	e8 78 d3 ff ff       	call   2fb0 <buf_put>
    5c38:	e9 9f fe ff ff       	jmp    5adc <fwp_write.constprop.0+0x8cc>
    5c3d:	0f 1f 00             	nopl   (%rax)
    5c40:	ba 02 00 00 00       	mov    $0x2,%edx
    5c45:	48 8d 35 f1 24 00 00 	lea    0x24f1(%rip),%rsi        # 813d <_IO_stdin_used+0x13d>
    5c4c:	48 89 df             	mov    %rbx,%rdi
    5c4f:	e8 5c d3 ff ff       	call   2fb0 <buf_put>
    5c54:	e9 87 f9 ff ff       	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5c60:	ba 02 00 00 00       	mov    $0x2,%edx
    5c65:	48 8d 35 dd 24 00 00 	lea    0x24dd(%rip),%rsi        # 8149 <_IO_stdin_used+0x149>
    5c6c:	48 89 df             	mov    %rbx,%rdi
    5c6f:	e8 3c d3 ff ff       	call   2fb0 <buf_put>
    5c74:	e9 67 f9 ff ff       	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5c80:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5c84:	0f 86 b6 01 00 00    	jbe    5e40 <fwp_write.constprop.0+0xc30>
    5c8a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5c8e:	0f 84 ac 01 00 00    	je     5e40 <fwp_write.constprop.0+0xc30>
    5c94:	ba 01 00 00 00       	mov    $0x1,%edx
    5c99:	4c 89 fe             	mov    %r15,%rsi
    5c9c:	48 89 df             	mov    %rbx,%rdi
    5c9f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5ca4:	e8 07 d3 ff ff       	call   2fb0 <buf_put>
    5ca9:	e9 32 f9 ff ff       	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5cae:	66 90                	xchg   %ax,%ax
    5cb0:	ba 02 00 00 00       	mov    $0x2,%edx
    5cb5:	48 8d 35 8a 24 00 00 	lea    0x248a(%rip),%rsi        # 8146 <_IO_stdin_used+0x146>
    5cbc:	48 89 df             	mov    %rbx,%rdi
    5cbf:	e8 ec d2 ff ff       	call   2fb0 <buf_put>
    5cc4:	e9 17 f9 ff ff       	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cd0:	ba 01 00 00 00       	mov    $0x1,%edx
    5cd5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5cda:	48 89 df             	mov    %rbx,%rdi
    5cdd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5ce2:	e8 c9 d2 ff ff       	call   2fb0 <buf_put>
    5ce7:	e9 b4 f5 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)
    5cf0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5cf4:	48 8b 13             	mov    (%rbx),%rdx
    5cf7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5cfc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5d00:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5d04:	e9 97 f5 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5d15:	ba 01 00 00 00       	mov    $0x1,%edx
    5d1a:	48 89 df             	mov    %rbx,%rdi
    5d1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5d22:	e8 89 d2 ff ff       	call   2fb0 <buf_put>
    5d27:	e9 74 f5 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5d2c:	0f 1f 40 00          	nopl   0x0(%rax)
    5d30:	ba 01 00 00 00       	mov    $0x1,%edx
    5d35:	4c 89 fe             	mov    %r15,%rsi
    5d38:	48 89 df             	mov    %rbx,%rdi
    5d3b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5d40:	e8 6b d2 ff ff       	call   2fb0 <buf_put>
    5d45:	e9 56 f5 ff ff       	jmp    52a0 <fwp_write.constprop.0+0x90>
    5d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d50:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5d55:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5d5a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5d5e:	48 89 f7             	mov    %rsi,%rdi
    5d61:	48 89 34 24          	mov    %rsi,(%rsp)
    5d65:	e8 c6 c6 ff ff       	call   2430 <strlen@plt>
    5d6a:	48 8b 34 24          	mov    (%rsp),%rsi
    5d6e:	48 89 df             	mov    %rbx,%rdi
    5d71:	48 89 c2             	mov    %rax,%rdx
    5d74:	e8 37 d2 ff ff       	call   2fb0 <buf_put>
    5d79:	ba 03 00 00 00       	mov    $0x3,%edx
    5d7e:	48 8d 35 fb 23 00 00 	lea    0x23fb(%rip),%rsi        # 8180 <_IO_stdin_used+0x180>
    5d85:	48 89 df             	mov    %rbx,%rdi
    5d88:	e8 23 d2 ff ff       	call   2fb0 <buf_put>
    5d8d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5d92:	e9 45 f7 ff ff       	jmp    54dc <fwp_write.constprop.0+0x2cc>
    5d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5d9e:	00 00 
    5da0:	ba 02 00 00 00       	mov    $0x2,%edx
    5da5:	48 8d 35 b1 23 00 00 	lea    0x23b1(%rip),%rsi        # 815d <_IO_stdin_used+0x15d>
    5dac:	48 89 df             	mov    %rbx,%rdi
    5daf:	e8 fc d1 ff ff       	call   2fb0 <buf_put>
    5db4:	e9 12 f7 ff ff       	jmp    54cb <fwp_write.constprop.0+0x2bb>
    5db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5dc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5dc5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	0f 84 f9 fc ff ff    	je     5acb <fwp_write.constprop.0+0x8bb>
    5dd2:	48 8d 35 91 23 00 00 	lea    0x2391(%rip),%rsi        # 816a <_IO_stdin_used+0x16a>
    5dd9:	e8 32 c7 ff ff       	call   2510 <strcmp@plt>
    5dde:	85 c0                	test   %eax,%eax
    5de0:	0f 95 c0             	setne  %al
    5de3:	0f b6 c0             	movzbl %al,%eax
    5de6:	e9 d8 fc ff ff       	jmp    5ac3 <fwp_write.constprop.0+0x8b3>
    5deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5df0:	31 c0                	xor    %eax,%eax
    5df2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5df9:	00 
    5dfa:	0f 97 c0             	seta   %al
    5dfd:	e9 c1 fc ff ff       	jmp    5ac3 <fwp_write.constprop.0+0x8b3>
    5e02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e08:	48 89 df             	mov    %rbx,%rdi
    5e0b:	ba 02 00 00 00       	mov    $0x2,%edx
    5e10:	48 8d 35 50 23 00 00 	lea    0x2350(%rip),%rsi        # 8167 <_IO_stdin_used+0x167>
    5e17:	e8 94 d1 ff ff       	call   2fb0 <buf_put>
    5e1c:	4c 89 e8             	mov    %r13,%rax
    5e1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5e24:	48 89 df             	mov    %rbx,%rdi
    5e27:	48 c1 e0 04          	shl    $0x4,%rax
    5e2b:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5e30:	e8 db f3 ff ff       	call   5210 <fwp_write.constprop.0>
    5e35:	e9 4e f5 ff ff       	jmp    5388 <fwp_write.constprop.0+0x178>
    5e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e40:	4c 8d 05 05 23 00 00 	lea    0x2305(%rip),%r8        # 814c <_IO_stdin_used+0x14c>
    5e47:	b9 10 00 00 00       	mov    $0x10,%ecx
    5e4c:	31 c0                	xor    %eax,%eax
    5e4e:	ba 02 00 00 00       	mov    $0x2,%edx
    5e53:	be 10 00 00 00       	mov    $0x10,%esi
    5e58:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5e5f:	00 
    5e60:	e8 2b c5 ff ff       	call   2390 <__snprintf_chk@plt>
    5e65:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5e6c:	00 
    5e6d:	e8 be c5 ff ff       	call   2430 <strlen@plt>
    5e72:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5e79:	00 
    5e7a:	48 89 df             	mov    %rbx,%rdi
    5e7d:	48 89 c2             	mov    %rax,%rdx
    5e80:	e8 2b d1 ff ff       	call   2fb0 <buf_put>
    5e85:	e9 56 f7 ff ff       	jmp    55e0 <fwp_write.constprop.0+0x3d0>
    5e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e90:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5e95:	48 85 ff             	test   %rdi,%rdi
    5e98:	79 0c                	jns    5ea6 <fwp_write.constprop.0+0xc96>
    5e9a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5ea1:	00 
    5ea2:	48 03 75 10          	add    0x10(%rbp),%rsi
    5ea6:	48 63 3e             	movslq (%rsi),%rdi
    5ea9:	83 f9 02             	cmp    $0x2,%ecx
    5eac:	89 fe                	mov    %edi,%esi
    5eae:	48 0f 44 f7          	cmove  %rdi,%rsi
    5eb2:	e9 29 fa ff ff       	jmp    58e0 <fwp_write.constprop.0+0x6d0>
    5eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ebe:	00 00 
    5ec0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5ec5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5eca:	48 85 ff             	test   %rdi,%rdi
    5ecd:	0f 88 6f 01 00 00    	js     6042 <fwp_write.constprop.0+0xe32>
    5ed3:	49 0f bf 38          	movswq (%r8),%rdi
    5ed7:	83 f9 01             	cmp    $0x1,%ecx
    5eda:	0f b7 f7             	movzwl %di,%esi
    5edd:	48 0f 44 f7          	cmove  %rdi,%rsi
    5ee1:	e9 fa f9 ff ff       	jmp    58e0 <fwp_write.constprop.0+0x6d0>
    5ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5eed:	00 00 00 
    5ef0:	83 f8 04             	cmp    $0x4,%eax
    5ef3:	0f 85 d2 fb ff ff    	jne    5acb <fwp_write.constprop.0+0x8bb>
    5ef9:	48 8b 04 24          	mov    (%rsp),%rax
    5efd:	48 8b 40 08          	mov    0x8(%rax),%rax
    5f01:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5f06:	48 c1 e8 3f          	shr    $0x3f,%rax
    5f0a:	e9 e6 fc ff ff       	jmp    5bf5 <fwp_write.constprop.0+0x9e5>
    5f0f:	90                   	nop
    5f10:	8b 0c 24             	mov    (%rsp),%ecx
    5f13:	31 c0                	xor    %eax,%eax
    5f15:	85 c9                	test   %ecx,%ecx
    5f17:	0f 98 c0             	sets   %al
    5f1a:	e9 d6 fc ff ff       	jmp    5bf5 <fwp_write.constprop.0+0x9e5>
    5f1f:	90                   	nop
    5f20:	48 f7 d8             	neg    %rax
    5f23:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5f2a:	00 
    5f2b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5f32:	2d 
    5f33:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f3a:	00 
    5f3b:	48 83 d2 00          	adc    $0x0,%rdx
    5f3f:	48 89 c6             	mov    %rax,%rsi
    5f42:	48 f7 da             	neg    %rdx
    5f45:	e8 b6 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f4a:	e9 31 f3 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    5f4f:	90                   	nop
    5f50:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5f55:	e9 b1 f5 ff ff       	jmp    550b <fwp_write.constprop.0+0x2fb>
    5f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f60:	4c 89 e9             	mov    %r13,%rcx
    5f63:	48 c1 e1 04          	shl    $0x4,%rcx
    5f67:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5f6c:	48 85 ff             	test   %rdi,%rdi
    5f6f:	0f 89 6b f9 ff ff    	jns    58e0 <fwp_write.constprop.0+0x6d0>
    5f75:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5f79:	48 89 ce             	mov    %rcx,%rsi
    5f7c:	e9 5f f9 ff ff       	jmp    58e0 <fwp_write.constprop.0+0x6d0>
    5f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5f88:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5f8f:	00 
    5f90:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5f94:	e9 9e f9 ff ff       	jmp    5937 <fwp_write.constprop.0+0x727>
    5f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa0:	ba 02 00 00 00       	mov    $0x2,%edx
    5fa5:	48 8d 35 5a 21 00 00 	lea    0x215a(%rip),%rsi        # 8106 <_IO_stdin_used+0x106>
    5fac:	e9 8d f7 ff ff       	jmp    573e <fwp_write.constprop.0+0x52e>
    5fb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fb8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fbc:	48 8d 35 3f 21 00 00 	lea    0x213f(%rip),%rsi        # 8102 <_IO_stdin_used+0x102>
    5fc3:	48 8d 05 37 21 00 00 	lea    0x2137(%rip),%rax        # 8101 <_IO_stdin_used+0x101>
    5fca:	4c 89 e7             	mov    %r12,%rdi
    5fcd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5fd1:	48 0f 46 f0          	cmovbe %rax,%rsi
    5fd5:	e8 f6 c3 ff ff       	call   23d0 <strcpy@plt>
    5fda:	e9 a1 f2 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    5fdf:	90                   	nop
    5fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fe4:	48 8d 35 17 21 00 00 	lea    0x2117(%rip),%rsi        # 8102 <_IO_stdin_used+0x102>
    5feb:	48 8d 05 0f 21 00 00 	lea    0x210f(%rip),%rax        # 8101 <_IO_stdin_used+0x101>
    5ff2:	0f 2f c8             	comiss %xmm0,%xmm1
    5ff5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ffc:	00 
    5ffd:	4c 89 e7             	mov    %r12,%rdi
    6000:	48 0f 46 f0          	cmovbe %rax,%rsi
    6004:	e8 c7 c3 ff ff       	call   23d0 <strcpy@plt>
    6009:	e9 72 f2 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    600e:	66 90                	xchg   %ax,%ax
    6010:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    6015:	45 85 c0             	test   %r8d,%r8d
    6018:	75 34                	jne    604e <fwp_write.constprop.0+0xe3e>
    601a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6021:	00 
    6022:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6029:	00 00 
    602b:	0f 85 24 f7 ff ff    	jne    5755 <fwp_write.constprop.0+0x545>
    6031:	ba 02 00 00 00       	mov    $0x2,%edx
    6036:	48 8d 35 40 21 00 00 	lea    0x2140(%rip),%rsi        # 817d <_IO_stdin_used+0x17d>
    603d:	e9 e1 f3 ff ff       	jmp    5423 <fwp_write.constprop.0+0x213>
    6042:	48 03 75 10          	add    0x10(%rbp),%rsi
    6046:	49 89 f0             	mov    %rsi,%r8
    6049:	e9 85 fe ff ff       	jmp    5ed3 <fwp_write.constprop.0+0xcc3>
    604e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    6053:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6058:	85 ff                	test   %edi,%edi
    605a:	0f 84 3a f4 ff ff    	je     549a <fwp_write.constprop.0+0x28a>
    6060:	ba 01 00 00 00       	mov    $0x1,%edx
    6065:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    606a:	48 89 df             	mov    %rbx,%rdi
    606d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6072:	e8 39 cf ff ff       	call   2fb0 <buf_put>
    6077:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    607c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6081:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6087:	85 d2                	test   %edx,%edx
    6089:	0f 8f 30 f4 ff ff    	jg     54bf <fwp_write.constprop.0+0x2af>
    608f:	e9 72 f4 ff ff       	jmp    5506 <fwp_write.constprop.0+0x2f6>
    6094:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6098:	49 89 c5             	mov    %rax,%r13
    609b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    60a0:	49 89 c4             	mov    %rax,%r12
    60a3:	49 c1 fd 3f          	sar    $0x3f,%r13
    60a7:	4c 09 e8             	or     %r13,%rax
    60aa:	0f 84 a7 00 00 00    	je     6157 <fwp_write.constprop.0+0xf47>
    60b0:	48 8d 2d 89 4a 00 00 	lea    0x4a89(%rip),%rbp        # ab40 <units.0>
    60b7:	4d 89 e7             	mov    %r12,%r15
    60ba:	48 8b 45 08          	mov    0x8(%rbp),%rax
    60be:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    60c3:	4c 89 ff             	mov    %r15,%rdi
    60c6:	4c 89 ee             	mov    %r13,%rsi
    60c9:	44 89 0c 24          	mov    %r9d,(%rsp)
    60cd:	48 99                	cqto
    60cf:	48 89 d1             	mov    %rdx,%rcx
    60d2:	48 89 c2             	mov    %rax,%rdx
    60d5:	e8 b6 16 00 00       	call   7790 <__divmodti4>
    60da:	44 8b 0c 24          	mov    (%rsp),%r9d
    60de:	48 89 c1             	mov    %rax,%rcx
    60e1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    60e6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    60eb:	0f 84 94 00 00 00    	je     6185 <fwp_write.constprop.0+0xf75>
    60f1:	41 83 c1 01          	add    $0x1,%r9d
    60f5:	48 83 c5 10          	add    $0x10,%rbp
    60f9:	41 83 f9 05          	cmp    $0x5,%r9d
    60fd:	75 bb                	jne    60ba <fwp_write.constprop.0+0xeaa>
    60ff:	4d 85 ed             	test   %r13,%r13
    6102:	79 53                	jns    6157 <fwp_write.constprop.0+0xf47>
    6104:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6109:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    610e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    6113:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6118:	48 99                	cqto
    611a:	48 f7 d8             	neg    %rax
    611d:	48 83 d2 00          	adc    $0x0,%rdx
    6121:	48 89 c6             	mov    %rax,%rsi
    6124:	48 f7 da             	neg    %rdx
    6127:	e8 d4 c8 ff ff       	call   2a00 <fwp_fmt_u128>
    612c:	49 89 e8             	mov    %rbp,%r8
    612f:	ba 00 02 00 00       	mov    $0x200,%edx
    6134:	be 02 00 00 00       	mov    $0x2,%esi
    6139:	31 c0                	xor    %eax,%eax
    613b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6142:	00 
    6143:	48 8d 0d 2e 20 00 00 	lea    0x202e(%rip),%rcx        # 8178 <_IO_stdin_used+0x178>
    614a:	4c 89 e7             	mov    %r12,%rdi
    614d:	e8 4e c5 ff ff       	call   26a0 <__sprintf_chk@plt>
    6152:	e9 29 f1 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    6157:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    615c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6161:	31 d2                	xor    %edx,%edx
    6163:	48 89 ef             	mov    %rbp,%rdi
    6166:	e8 95 c8 ff ff       	call   2a00 <fwp_fmt_u128>
    616b:	eb bf                	jmp    612c <fwp_write.constprop.0+0xf1c>
    616d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6174:	4e 61 4e 00 
    6178:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    617f:	00 
    6180:	e9 fb f0 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    6185:	44 89 0c 24          	mov    %r9d,(%rsp)
    6189:	48 89 c8             	mov    %rcx,%rax
    618c:	48 85 d2             	test   %rdx,%rdx
    618f:	78 51                	js     61e2 <fwp_write.constprop.0+0xfd2>
    6191:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6196:	48 89 c6             	mov    %rax,%rsi
    6199:	48 89 ef             	mov    %rbp,%rdi
    619c:	e8 5f c8 ff ff       	call   2a00 <fwp_fmt_u128>
    61a1:	44 8b 0c 24          	mov    (%rsp),%r9d
    61a5:	49 63 c1             	movslq %r9d,%rax
    61a8:	49 89 e8             	mov    %rbp,%r8
    61ab:	ba 00 02 00 00       	mov    $0x200,%edx
    61b0:	be 02 00 00 00       	mov    $0x2,%esi
    61b5:	48 c1 e0 04          	shl    $0x4,%rax
    61b9:	48 8d 0d 80 49 00 00 	lea    0x4980(%rip),%rcx        # ab40 <units.0>
    61c0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    61c7:	00 
    61c8:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    61cc:	4c 89 e7             	mov    %r12,%rdi
    61cf:	48 8d 0d 9d 1f 00 00 	lea    0x1f9d(%rip),%rcx        # 8173 <_IO_stdin_used+0x173>
    61d6:	31 c0                	xor    %eax,%eax
    61d8:	e8 c3 c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    61dd:	e9 9e f0 ff ff       	jmp    5280 <fwp_write.constprop.0+0x70>
    61e2:	48 f7 d8             	neg    %rax
    61e5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    61ea:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    61ef:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61f4:	48 83 d2 00          	adc    $0x0,%rdx
    61f8:	48 89 c6             	mov    %rax,%rsi
    61fb:	48 f7 da             	neg    %rdx
    61fe:	e8 fd c7 ff ff       	call   2a00 <fwp_fmt_u128>
    6203:	44 8b 0c 24          	mov    (%rsp),%r9d
    6207:	eb 9c                	jmp    61a5 <fwp_write.constprop.0+0xf95>
    6209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006210 <fwp_main_thread>:
    6210:	f3 0f 1e fa          	endbr64
    6214:	41 57                	push   %r15
    6216:	41 56                	push   %r14
    6218:	41 55                	push   %r13
    621a:	41 54                	push   %r12
    621c:	55                   	push   %rbp
    621d:	53                   	push   %rbx
    621e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    6225:	44 8b 05 78 68 01 00 	mov    0x16878(%rip),%r8d        # 1caa4 <fwp_heap+0x13a4>
    622c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6233:	00 00 
    6235:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    623c:	00 
    623d:	31 c0                	xor    %eax,%eax
    623f:	45 85 c0             	test   %r8d,%r8d
    6242:	0f 84 30 0d 00 00    	je     6f78 <fwp_main_thread+0xd68>
    6248:	8b 3d 5a 68 01 00    	mov    0x1685a(%rip),%edi        # 1caa8 <fwp_heap+0x13a8>
    624e:	85 ff                	test   %edi,%edi
    6250:	0f 85 0a 0d 00 00    	jne    6f60 <fwp_main_thread+0xd50>
    6256:	4c 8d 74 24 40       	lea    0x40(%rsp),%r14
    625b:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    6260:	31 f6                	xor    %esi,%esi
    6262:	48 c7 05 23 4e 01 00 	movq   $0x40000000,0x14e23(%rip)        # 1b090 <fwp_main_stack_size>
    6269:	00 00 00 40 
    626d:	48 8d 05 0c 4e 00 00 	lea    0x4e0c(%rip),%rax        # b080 <alt.4>
    6274:	4c 89 f7             	mov    %r14,%rdi
    6277:	48 89 1d 1a 4e 01 00 	mov    %rbx,0x14e1a(%rip)        # 1b098 <fwp_main_stack_top>
    627e:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    6283:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    628a:	01 00 
    628c:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    6293:	00 
    6294:	e8 e7 c3 ff ff       	call   2680 <sigaltstack@plt>
    6299:	85 c0                	test   %eax,%eax
    629b:	0f 85 87 14 00 00    	jne    7728 <fwp_main_thread+0x1518>
    62a1:	31 c0                	xor    %eax,%eax
    62a3:	b9 12 00 00 00       	mov    $0x12,%ecx
    62a8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    62af:	00 
    62b0:	f3 48 ab             	rep stos %rax,(%rdi)
    62b3:	48 8d 05 46 c9 ff ff 	lea    -0x36ba(%rip),%rax        # 2c00 <fwp_segv>
    62ba:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    62c1:	00 
    62c2:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    62c9:	04 00 00 08 
    62cd:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    62d4:	00 
    62d5:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    62dc:	00 
    62dd:	e8 6e c2 ff ff       	call   2550 <sigemptyset@plt>
    62e2:	85 c0                	test   %eax,%eax
    62e4:	0f 85 3e 14 00 00    	jne    7728 <fwp_main_thread+0x1518>
    62ea:	31 d2                	xor    %edx,%edx
    62ec:	48 89 ee             	mov    %rbp,%rsi
    62ef:	bf 0b 00 00 00       	mov    $0xb,%edi
    62f4:	e8 e7 c0 ff ff       	call   23e0 <sigaction@plt>
    62f9:	85 c0                	test   %eax,%eax
    62fb:	0f 85 27 14 00 00    	jne    7728 <fwp_main_thread+0x1518>
    6301:	31 d2                	xor    %edx,%edx
    6303:	48 89 ee             	mov    %rbp,%rsi
    6306:	bf 07 00 00 00       	mov    $0x7,%edi
    630b:	e8 d0 c0 ff ff       	call   23e0 <sigaction@plt>
    6310:	85 c0                	test   %eax,%eax
    6312:	0f 85 10 14 00 00    	jne    7728 <fwp_main_thread+0x1518>
    6318:	48 8b 05 01 68 01 00 	mov    0x16801(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    631f:	48 85 c0             	test   %rax,%rax
    6322:	0f 88 18 06 00 00    	js     6940 <fwp_main_thread+0x730>
    6328:	66 0f ef c0          	pxor   %xmm0,%xmm0
    632c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6331:	48 8d 3d a8 cd ff ff 	lea    -0x3258(%rip),%rdi        # 30e0 <ad_raw_report>
    6338:	f2 0f 11 05 60 70 01 	movsd  %xmm0,0x17060(%rip)        # 1d3a0 <iteration_start_charge>
    633f:	00 
    6340:	c7 05 76 70 01 00 01 	movl   $0x1,0x17076(%rip)        # 1d3c0 <iteration_active>
    6347:	00 00 00 
    634a:	e8 51 16 00 00       	call   79a0 <atexit>
    634f:	85 c0                	test   %eax,%eax
    6351:	0f 85 15 14 00 00    	jne    776c <fwp_main_thread+0x155c>
    6357:	8b 35 0b 4d 00 00    	mov    0x4d0b(%rip),%esi        # b068 <st.2>
    635d:	85 f6                	test   %esi,%esi
    635f:	0f 84 1b 06 00 00    	je     6980 <fwp_main_thread+0x770>
    6365:	48 8b 2d 74 53 01 00 	mov    0x15374(%rip),%rbp        # 1b6e0 <fwp_cur>
    636c:	48 85 ed             	test   %rbp,%rbp
    636f:	0f 84 0b 03 00 00    	je     6680 <fwp_main_thread+0x470>
    6375:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    637a:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    637e:	48 89 eb             	mov    %rbp,%rbx
    6381:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    6386:	0f 84 41 01 00 00    	je     64cd <fwp_main_thread+0x2bd>
    638c:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    6391:	0f 84 19 02 00 00    	je     65b0 <fwp_main_thread+0x3a0>
    6397:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    639b:	0f 84 ff 01 00 00    	je     65a0 <fwp_main_thread+0x390>
    63a1:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    63a5:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    63a9:	0f 85 81 02 00 00    	jne    6630 <fwp_main_thread+0x420>
    63af:	48 8b 43 60          	mov    0x60(%rbx),%rax
    63b3:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    63ba:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    63be:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    63c5:	00 00 00 00 
    63c9:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    63d0:	48 85 d2             	test   %rdx,%rdx
    63d3:	74 07                	je     63dc <fwp_main_thread+0x1cc>
    63d5:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    63dc:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    63e0:	48 85 c0             	test   %rax,%rax
    63e3:	74 34                	je     6419 <fwp_main_thread+0x209>
    63e5:	48 89 43 68          	mov    %rax,0x68(%rbx)
    63e9:	48 8b 05 c8 52 01 00 	mov    0x152c8(%rip),%rax        # 1b6b8 <fwp_timers>
    63f0:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    63f4:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    63fb:	00 00 00 00 
    63ff:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    6406:	48 85 c0             	test   %rax,%rax
    6409:	74 07                	je     6412 <fwp_main_thread+0x202>
    640b:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    6412:	48 89 1d 9f 52 01 00 	mov    %rbx,0x1529f(%rip)        # 1b6b8 <fwp_timers>
    6419:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    641d:	e8 6e e9 ff ff       	call   4d90 <fwp_block>
    6422:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    6429:	48 85 c9             	test   %rcx,%rcx
    642c:	74 47                	je     6475 <fwp_main_thread+0x265>
    642e:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    6435:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    643c:	48 85 d2             	test   %rdx,%rdx
    643f:	0f 84 2b 02 00 00    	je     6670 <fwp_main_thread+0x460>
    6445:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    644c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    6453:	48 85 c0             	test   %rax,%rax
    6456:	74 07                	je     645f <fwp_main_thread+0x24f>
    6458:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    645f:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    6466:	00 00 00 00 
    646a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    646e:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    6475:	48 8b 0d 64 52 01 00 	mov    0x15264(%rip),%rcx        # 1b6e0 <fwp_cur>
    647c:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    6480:	0f 84 9a 01 00 00    	je     6620 <fwp_main_thread+0x410>
    6486:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    648d:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    6494:	48 85 d2             	test   %rdx,%rdx
    6497:	0f 84 0b 04 00 00    	je     68a8 <fwp_main_thread+0x698>
    649d:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    64a4:	48 85 c0             	test   %rax,%rax
    64a7:	74 07                	je     64b0 <fwp_main_thread+0x2a0>
    64a9:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    64b0:	66 0f ef db          	pxor   %xmm3,%xmm3
    64b4:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    64b8:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    64bf:	48 89 cb             	mov    %rcx,%rbx
    64c2:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    64c7:	0f 85 bf fe ff ff    	jne    638c <fwp_main_thread+0x17c>
    64cd:	48 83 3d 9b 6e 01 00 	cmpq   $0x0,0x16e9b(%rip)        # 1d370 <fwp_state_len>
    64d4:	00 
    64d5:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    64d9:	0f 84 f3 03 00 00    	je     68d2 <fwp_main_thread+0x6c2>
    64df:	48 39 1d f2 51 01 00 	cmp    %rbx,0x151f2(%rip)        # 1b6d8 <fwp_root>
    64e6:	c7 05 90 4b 01 00 00 	movl   $0x0,0x14b90(%rip)        # 1b080 <fwp_exit_code>
    64ed:	00 00 00 
    64f0:	0f 85 8f 12 00 00    	jne    7785 <fwp_main_thread+0x1575>
    64f6:	48 85 db             	test   %rbx,%rbx
    64f9:	0f 84 a7 01 00 00    	je     66a6 <fwp_main_thread+0x496>
    64ff:	48 8b 15 a2 51 01 00 	mov    0x151a2(%rip),%rdx        # 1b6a8 <fwp_tasks_active>
    6506:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    650a:	48 85 d2             	test   %rdx,%rdx
    650d:	0f 84 93 01 00 00    	je     66a6 <fwp_main_thread+0x496>
    6513:	66 90                	xchg   %ax,%ax
    6515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    651c:	00 00 00 00 
    6520:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    6524:	75 08                	jne    652e <fwp_main_thread+0x31e>
    6526:	48 89 d7             	mov    %rdx,%rdi
    6529:	e8 c2 ca ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    652e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    6535:	48 85 d2             	test   %rdx,%rdx
    6538:	75 e6                	jne    6520 <fwp_main_thread+0x310>
    653a:	eb 31                	jmp    656d <fwp_main_thread+0x35d>
    653c:	0f 1f 40 00          	nopl   0x0(%rax)
    6540:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    6547:	48 89 1d 72 51 01 00 	mov    %rbx,0x15172(%rip)        # 1b6c0 <fwp_ready_tail>
    654e:	e8 3d e8 ff ff       	call   4d90 <fwp_block>
    6553:	e8 38 e6 ff ff       	call   4b90 <fwp_free_zombie>
    6558:	48 83 3d 48 51 01 00 	cmpq   $0x0,0x15148(%rip)        # 1b6a8 <fwp_tasks_active>
    655f:	00 
    6560:	0f 84 40 01 00 00    	je     66a6 <fwp_main_thread+0x496>
    6566:	48 8b 1d 6b 51 01 00 	mov    0x1516b(%rip),%rbx        # 1b6d8 <fwp_root>
    656d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    6571:	75 db                	jne    654e <fwp_main_thread+0x33e>
    6573:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    6577:	75 d5                	jne    654e <fwp_main_thread+0x33e>
    6579:	48 8b 05 40 51 01 00 	mov    0x15140(%rip),%rax        # 1b6c0 <fwp_ready_tail>
    6580:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    6584:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    658b:	00 00 00 00 
    658f:	48 85 c0             	test   %rax,%rax
    6592:	75 ac                	jne    6540 <fwp_main_thread+0x330>
    6594:	48 89 1d 2d 51 01 00 	mov    %rbx,0x1512d(%rip)        # 1b6c8 <fwp_ready_head>
    659b:	eb aa                	jmp    6547 <fwp_main_thread+0x337>
    659d:	0f 1f 00             	nopl   (%rax)
    65a0:	e8 8b cc ff ff       	call   3230 <fwp_now_ns>
    65a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    65a9:	0f 8d 09 03 00 00    	jge    68b8 <fwp_main_thread+0x6a8>
    65af:	90                   	nop
    65b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    65b4:	0f 85 e7 fd ff ff    	jne    63a1 <fwp_main_thread+0x191>
    65ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    65be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    65c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    65c6:	0f 85 e7 fd ff ff    	jne    63b3 <fwp_main_thread+0x1a3>
    65cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    65d0:	48 85 c9             	test   %rcx,%rcx
    65d3:	0f 84 da fd ff ff    	je     63b3 <fwp_main_thread+0x1a3>
    65d9:	48 85 c0             	test   %rax,%rax
    65dc:	0f 84 96 11 00 00    	je     7778 <fwp_main_thread+0x1568>
    65e2:	48 39 c8             	cmp    %rcx,%rax
    65e5:	48 0f 4f c1          	cmovg  %rcx,%rax
    65e9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    65f0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    65f4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    65fb:	00 00 00 00 
    65ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    6606:	48 85 d2             	test   %rdx,%rdx
    6609:	74 07                	je     6612 <fwp_main_thread+0x402>
    660b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    6612:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    6616:	e9 ca fd ff ff       	jmp    63e5 <fwp_main_thread+0x1d5>
    661b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6620:	48 89 cb             	mov    %rcx,%rbx
    6623:	e9 59 fd ff ff       	jmp    6381 <fwp_main_thread+0x171>
    6628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    662f:	00 
    6630:	48 8b 45 40          	mov    0x40(%rbp),%rax
    6634:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    663b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    6642:	00 00 00 00 
    6646:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    664d:	48 85 c0             	test   %rax,%rax
    6650:	0f 84 2a 0e 00 00    	je     7480 <fwp_main_thread+0x1270>
    6656:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    665d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    6661:	e9 b3 fd ff ff       	jmp    6419 <fwp_main_thread+0x209>
    6666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    666d:	00 00 00 
    6670:	48 89 01             	mov    %rax,(%rcx)
    6673:	e9 db fd ff ff       	jmp    6453 <fwp_main_thread+0x243>
    6678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    667f:	00 
    6680:	48 83 3d e8 6c 01 00 	cmpq   $0x0,0x16ce8(%rip)        # 1d370 <fwp_state_len>
    6687:	00 
    6688:	0f 84 42 02 00 00    	je     68d0 <fwp_main_thread+0x6c0>
    668e:	48 83 3d 42 50 01 00 	cmpq   $0x0,0x15042(%rip)        # 1b6d8 <fwp_root>
    6695:	00 
    6696:	c7 05 e0 49 01 00 00 	movl   $0x0,0x149e0(%rip)        # 1b080 <fwp_exit_code>
    669d:	00 00 00 
    66a0:	0f 85 e4 10 00 00    	jne    778a <fwp_main_thread+0x157a>
    66a6:	e8 e5 e4 ff ff       	call   4b90 <fwp_free_zombie>
    66ab:	48 83 3d 15 50 01 00 	cmpq   $0x0,0x15015(%rip)        # 1b6c8 <fwp_ready_head>
    66b2:	00 
    66b3:	0f 85 52 c0 ff ff    	jne    270b <fwp_main_thread.cold>
    66b9:	48 83 3d f7 4f 01 00 	cmpq   $0x0,0x14ff7(%rip)        # 1b6b8 <fwp_timers>
    66c0:	00 
    66c1:	0f 85 44 c0 ff ff    	jne    270b <fwp_main_thread.cold>
    66c7:	8b 05 d7 49 01 00    	mov    0x149d7(%rip),%eax        # 1b0a4 <fwp_stack_pool_n>
    66cd:	85 c0                	test   %eax,%eax
    66cf:	74 3c                	je     670d <fwp_main_thread+0x4fd>
    66d1:	83 e8 01             	sub    $0x1,%eax
    66d4:	4c 8d 25 e5 49 01 00 	lea    0x149e5(%rip),%r12        # 1b0c0 <fwp_stack_pool>
    66db:	48 63 d8             	movslq %eax,%rbx
    66de:	89 c0                	mov    %eax,%eax
    66e0:	48 89 da             	mov    %rbx,%rdx
    66e3:	48 29 c2             	sub    %rax,%rdx
    66e6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    66ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66f0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    66f4:	89 1d aa 49 01 00    	mov    %ebx,0x149aa(%rip)        # 1b0a4 <fwp_stack_pool_n>
    66fa:	be 00 00 00 10       	mov    $0x10000000,%esi
    66ff:	48 83 eb 01          	sub    $0x1,%rbx
    6703:	e8 a8 be ff ff       	call   25b0 <munmap@plt>
    6708:	48 39 dd             	cmp    %rbx,%rbp
    670b:	75 e3                	jne    66f0 <fwp_main_thread+0x4e0>
    670d:	8b 3d fd 48 00 00    	mov    0x48fd(%rip),%edi        # b010 <fwp_epfd>
    6713:	85 ff                	test   %edi,%edi
    6715:	78 05                	js     671c <fwp_main_thread+0x50c>
    6717:	e8 94 bd ff ff       	call   24b0 <close@plt>
    671c:	4c 8b 25 9d 4b 01 00 	mov    0x14b9d(%rip),%r12        # 1b2c0 <fwp_nfdws>
    6723:	48 8b 2d 9e 4b 01 00 	mov    0x14b9e(%rip),%rbp        # 1b2c8 <fwp_fdws>
    672a:	31 db                	xor    %ebx,%ebx
    672c:	c7 05 da 48 00 00 ff 	movl   $0xffffffff,0x48da(%rip)        # b010 <fwp_epfd>
    6733:	ff ff ff 
    6736:	4d 85 e4             	test   %r12,%r12
    6739:	74 32                	je     676d <fwp_main_thread+0x55d>
    673b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6740:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    6745:	48 85 ff             	test   %rdi,%rdi
    6748:	74 1a                	je     6764 <fwp_main_thread+0x554>
    674a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    674e:	0f 85 b7 bf ff ff    	jne    270b <fwp_main_thread.cold>
    6754:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    6759:	0f 85 ac bf ff ff    	jne    270b <fwp_main_thread.cold>
    675f:	e8 ac d9 ff ff       	call   4110 <fwp_mem_free>
    6764:	48 83 c3 01          	add    $0x1,%rbx
    6768:	4c 39 e3             	cmp    %r12,%rbx
    676b:	75 d3                	jne    6740 <fwp_main_thread+0x530>
    676d:	48 89 ef             	mov    %rbp,%rdi
    6770:	e8 9b d9 ff ff       	call   4110 <fwp_mem_free>
    6775:	48 8b 15 5c 4f 01 00 	mov    0x14f5c(%rip),%rdx        # 1b6d8 <fwp_root>
    677c:	48 c7 05 41 4b 01 00 	movq   $0x0,0x14b41(%rip)        # 1b2c8 <fwp_fdws>
    6783:	00 00 00 00 
    6787:	48 c7 05 2e 4b 01 00 	movq   $0x0,0x14b2e(%rip)        # 1b2c0 <fwp_nfdws>
    678e:	00 00 00 00 
    6792:	48 85 d2             	test   %rdx,%rdx
    6795:	74 4e                	je     67e5 <fwp_main_thread+0x5d5>
    6797:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    679c:	0f 85 69 bf ff ff    	jne    270b <fwp_main_thread.cold>
    67a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    67a9:	00 
    67aa:	0f 85 5b bf ff ff    	jne    270b <fwp_main_thread.cold>
    67b0:	48 83 3d b8 6b 01 00 	cmpq   $0x0,0x16bb8(%rip)        # 1d370 <fwp_state_len>
    67b7:	00 
    67b8:	0f 85 4d bf ff ff    	jne    270b <fwp_main_thread.cold>
    67be:	48 83 3d 9a 6b 01 00 	cmpq   $0x0,0x16b9a(%rip)        # 1d360 <fwp_state_owners>
    67c5:	00 
    67c6:	0f 85 3f bf ff ff    	jne    270b <fwp_main_thread.cold>
    67cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    67d1:	31 c0                	xor    %eax,%eax
    67d3:	48 8d 3d 06 4b 01 00 	lea    0x14b06(%rip),%rdi        # 1b2e0 <fwp_root_context>
    67da:	f3 48 ab             	rep stos %rax,(%rdi)
    67dd:	48 89 d7             	mov    %rdx,%rdi
    67e0:	e8 2b d9 ff ff       	call   4110 <fwp_mem_free>
    67e5:	48 8b 05 34 63 01 00 	mov    0x16334(%rip),%rax        # 1cb20 <fwp_heap+0x1420>
    67ec:	48 c7 05 e9 4e 01 00 	movq   $0x0,0x14ee9(%rip)        # 1b6e0 <fwp_cur>
    67f3:	00 00 00 00 
    67f7:	48 c7 05 d6 4e 01 00 	movq   $0x0,0x14ed6(%rip)        # 1b6d8 <fwp_root>
    67fe:	00 00 00 00 
    6802:	48 c7 05 7b 48 01 00 	movq   $0x0,0x1487b(%rip)        # 1b088 <ad_raw_before_shutdown>
    6809:	00 00 00 00 
    680d:	c7 05 a9 6b 01 00 00 	movl   $0x0,0x16ba9(%rip)        # 1d3c0 <iteration_active>
    6814:	00 00 00 
    6817:	48 85 c0             	test   %rax,%rax
    681a:	0f 88 40 01 00 00    	js     6960 <fwp_main_thread+0x750>
    6820:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6824:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    6829:	f2 0f 5c 0d 6f 6b 01 	subsd  0x16b6f(%rip),%xmm1        # 1d3a0 <iteration_start_charge>
    6830:	00 
    6831:	48 8b 3d 08 48 00 00 	mov    0x4808(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    6838:	48 8d 15 01 1c 00 00 	lea    0x1c01(%rip),%rdx        # 8440 <_IO_stdin_used+0x440>
    683f:	be 02 00 00 00       	mov    $0x2,%esi
    6844:	f2 0f 10 05 4c 6b 01 	movsd  0x16b4c(%rip),%xmm0        # 1d398 <iteration_peak>
    684b:	00 
    684c:	4c 8b 0d 55 6b 01 00 	mov    0x16b55(%rip),%r9        # 1d3a8 <iteration_retains>
    6853:	b8 02 00 00 00       	mov    $0x2,%eax
    6858:	4c 8b 05 51 6b 01 00 	mov    0x16b51(%rip),%r8        # 1d3b0 <iteration_bytes>
    685f:	48 8b 0d 52 6b 01 00 	mov    0x16b52(%rip),%rcx        # 1d3b8 <iteration_requests>
    6866:	e8 e5 bd ff ff       	call   2650 <__fprintf_chk@plt>
    686b:	48 8b 3d ae 47 00 00 	mov    0x47ae(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    6872:	e8 19 bd ff ff       	call   2590 <fflush@plt>
    6877:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    687e:	00 
    687f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6886:	00 00 
    6888:	0f 85 f2 0e 00 00    	jne    7780 <fwp_main_thread+0x1570>
    688e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    6895:	31 c0                	xor    %eax,%eax
    6897:	5b                   	pop    %rbx
    6898:	5d                   	pop    %rbp
    6899:	41 5c                	pop    %r12
    689b:	41 5d                	pop    %r13
    689d:	41 5e                	pop    %r14
    689f:	41 5f                	pop    %r15
    68a1:	c3                   	ret
    68a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68a8:	48 89 05 09 4e 01 00 	mov    %rax,0x14e09(%rip)        # 1b6b8 <fwp_timers>
    68af:	e9 f0 fb ff ff       	jmp    64a4 <fwp_main_thread+0x294>
    68b4:	0f 1f 40 00          	nopl   0x0(%rax)
    68b8:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    68bc:	0f 85 ee fc ff ff    	jne    65b0 <fwp_main_thread+0x3a0>
    68c2:	48 89 ef             	mov    %rbp,%rdi
    68c5:	e8 26 c7 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    68ca:	e9 e1 fc ff ff       	jmp    65b0 <fwp_main_thread+0x3a0>
    68cf:	90                   	nop
    68d0:	31 db                	xor    %ebx,%ebx
    68d2:	48 83 3d 86 6a 01 00 	cmpq   $0x0,0x16a86(%rip)        # 1d360 <fwp_state_owners>
    68d9:	00 
    68da:	0f 85 ff fb ff ff    	jne    64df <fwp_main_thread+0x2cf>
    68e0:	48 8b 3d 91 6a 01 00 	mov    0x16a91(%rip),%rdi        # 1d378 <fwp_state>
    68e7:	e8 24 d8 ff ff       	call   4110 <fwp_mem_free>
    68ec:	48 c7 05 81 6a 01 00 	movq   $0x0,0x16a81(%rip)        # 1d378 <fwp_state>
    68f3:	00 00 00 00 
    68f7:	48 c7 05 66 6a 01 00 	movq   $0x0,0x16a66(%rip)        # 1d368 <fwp_state_cap>
    68fe:	00 00 00 00 
    6902:	48 85 db             	test   %rbx,%rbx
    6905:	0f 84 90 0d 00 00    	je     769b <fwp_main_thread+0x148b>
    690b:	48 3b 1d c6 4d 01 00 	cmp    0x14dc6(%rip),%rbx        # 1b6d8 <fwp_root>
    6912:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6919:	00 00 00 00 
    691d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    6924:	00 00 00 00 
    6928:	c7 05 4e 47 01 00 00 	movl   $0x0,0x1474e(%rip)        # 1b080 <fwp_exit_code>
    692f:	00 00 00 
    6932:	0f 84 c7 fb ff ff    	je     64ff <fwp_main_thread+0x2ef>
    6938:	e9 ce bd ff ff       	jmp    270b <fwp_main_thread.cold>
    693d:	0f 1f 00             	nopl   (%rax)
    6940:	48 89 c2             	mov    %rax,%rdx
    6943:	83 e0 01             	and    $0x1,%eax
    6946:	66 0f ef c0          	pxor   %xmm0,%xmm0
    694a:	48 d1 ea             	shr    $1,%rdx
    694d:	48 09 c2             	or     %rax,%rdx
    6950:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6955:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6959:	e9 d3 f9 ff ff       	jmp    6331 <fwp_main_thread+0x121>
    695e:	66 90                	xchg   %ax,%ax
    6960:	48 89 c2             	mov    %rax,%rdx
    6963:	83 e0 01             	and    $0x1,%eax
    6966:	66 0f ef c9          	pxor   %xmm1,%xmm1
    696a:	48 d1 ea             	shr    $1,%rdx
    696d:	48 09 c2             	or     %rax,%rdx
    6970:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    6975:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6979:	e9 ab fe ff ff       	jmp    6829 <fwp_main_thread+0x619>
    697e:	66 90                	xchg   %ax,%ax
    6980:	48 8d 05 29 e7 ff ff 	lea    -0x18d7(%rip),%rax        # 50b0 <fwp_drop1>
    6987:	66 0f ef c0          	pxor   %xmm0,%xmm0
    698b:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    6992:	00 00 
    6994:	41 bd ff 7f 00 00    	mov    $0x7fff,%r13d
    699a:	66 48 0f 6e e0       	movq   %rax,%xmm4
    699f:	48 8b 05 ea 69 01 00 	mov    0x169ea(%rip),%rax        # 1d390 <fwp_cleanups>
    69a6:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
    69ab:	4c 8d 25 4e 4d 01 00 	lea    0x14d4e(%rip),%r12        # 1b700 <fwp_heap>
    69b2:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    69b6:	48 89 1d d3 69 01 00 	mov    %rbx,0x169d3(%rip)        # 1d390 <fwp_cleanups>
    69bd:	31 db                	xor    %ebx,%ebx
    69bf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    69c4:	48 8d 05 c5 c1 ff ff 	lea    -0x3e3b(%rip),%rax        # 2b90 <fwp_range_release>
    69cb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    69d0:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    69d5:	eb 44                	jmp    6a1b <fwp_main_thread+0x80b>
    69d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69de:	00 00 
    69e0:	80 f9 01             	cmp    $0x1,%cl
    69e3:	75 27                	jne    6a0c <fwp_main_thread+0x7fc>
    69e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69e8:	0f b7 c0             	movzwl %ax,%eax
    69eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69ee:	48 0f af c1          	imul   %rcx,%rax
    69f2:	48 c1 e8 20          	shr    $0x20,%rax
    69f6:	48 39 d0             	cmp    %rdx,%rax
    69f9:	73 11                	jae    6a0c <fwp_main_thread+0x7fc>
    69fb:	49 01 c7             	add    %rax,%r15
    69fe:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6a02:	0f 84 e2 0a 00 00    	je     74ea <fwp_main_thread+0x12da>
    6a08:	41 c6 07 01          	movb   $0x1,(%r15)
    6a0c:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    6a11:	49 83 ed 01          	sub    $0x1,%r13
    6a15:	0f 82 85 00 00 00    	jb     6aa0 <fwp_main_thread+0x890>
    6a1b:	48 89 ee             	mov    %rbp,%rsi
    6a1e:	bf 01 00 00 00       	mov    $0x1,%edi
    6a23:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    6a2a:	00 
    6a2b:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
    6a30:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
    6a37:	00 
    6a38:	e8 43 de ff ff       	call   4880 <fwp_data.part.0.constprop.0>
    6a3d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6a44:	00 
    6a45:	48 89 c3             	mov    %rax,%rbx
    6a48:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6a4f:	00 
    6a50:	48 c1 e2 10          	shl    $0x10,%rdx
    6a54:	48 39 d0             	cmp    %rdx,%rax
    6a57:	73 b3                	jae    6a0c <fwp_main_thread+0x7fc>
    6a59:	48 89 c2             	mov    %rax,%rdx
    6a5c:	48 c1 ea 10          	shr    $0x10,%rdx
    6a60:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a64:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6a6b:	00 
    6a6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6a70:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    6a74:	4d 85 ff             	test   %r15,%r15
    6a77:	74 93                	je     6a0c <fwp_main_thread+0x7fc>
    6a79:	0f b6 0a             	movzbl (%rdx),%ecx
    6a7c:	80 f9 02             	cmp    $0x2,%cl
    6a7f:	0f 85 5b ff ff ff    	jne    69e0 <fwp_main_thread+0x7d0>
    6a85:	66 85 c0             	test   %ax,%ax
    6a88:	0f 84 70 ff ff ff    	je     69fe <fwp_main_thread+0x7ee>
    6a8e:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    6a93:	49 83 ed 01          	sub    $0x1,%r13
    6a97:	73 82                	jae    6a1b <fwp_main_thread+0x80b>
    6a99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6aa0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6aa5:	66 0f 6f 05 b3 1b 00 	movdqa 0x1bb3(%rip),%xmm0        # 8660 <msg.3+0x90>
    6aac:	00 
    6aad:	48 89 ee             	mov    %rbp,%rsi
    6ab0:	bf 01 00 00 00       	mov    $0x1,%edi
    6ab5:	48 89 05 d4 68 01 00 	mov    %rax,0x168d4(%rip)        # 1d390 <fwp_cleanups>
    6abc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    6ac3:	00 
    6ac4:	e8 b7 dd ff ff       	call   4880 <fwp_data.part.0.constprop.0>
    6ac9:	48 8b 15 08 60 01 00 	mov    0x16008(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    6ad0:	49 89 c5             	mov    %rax,%r13
    6ad3:	48 2b 05 d6 5f 01 00 	sub    0x15fd6(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    6ada:	48 c1 e2 10          	shl    $0x10,%rdx
    6ade:	48 39 d0             	cmp    %rdx,%rax
    6ae1:	73 57                	jae    6b3a <fwp_main_thread+0x92a>
    6ae3:	48 89 c2             	mov    %rax,%rdx
    6ae6:	48 c1 ea 10          	shr    $0x10,%rdx
    6aea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6aee:	48 8b 15 03 60 01 00 	mov    0x16003(%rip),%rdx        # 1caf8 <fwp_heap+0x13f8>
    6af5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6af9:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6afd:	48 85 ed             	test   %rbp,%rbp
    6b00:	74 38                	je     6b3a <fwp_main_thread+0x92a>
    6b02:	0f b6 0a             	movzbl (%rdx),%ecx
    6b05:	80 f9 02             	cmp    $0x2,%cl
    6b08:	0f 84 ce 09 00 00    	je     74dc <fwp_main_thread+0x12cc>
    6b0e:	80 f9 01             	cmp    $0x1,%cl
    6b11:	75 27                	jne    6b3a <fwp_main_thread+0x92a>
    6b13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b16:	0f b7 c0             	movzwl %ax,%eax
    6b19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b1c:	48 0f af c1          	imul   %rcx,%rax
    6b20:	48 c1 e8 20          	shr    $0x20,%rax
    6b24:	48 39 d0             	cmp    %rdx,%rax
    6b27:	73 11                	jae    6b3a <fwp_main_thread+0x92a>
    6b29:	48 01 c5             	add    %rax,%rbp
    6b2c:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6b30:	0f 84 97 0b 00 00    	je     76cd <fwp_main_thread+0x14bd>
    6b36:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6b3a:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    6b3f:	bf 01 00 00 00       	mov    $0x1,%edi
    6b44:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    6b49:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    6b50:	00 f0 3f 
    6b53:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6b58:	e8 23 dd ff ff       	call   4880 <fwp_data.part.0.constprop.0>
    6b5d:	48 8b 15 74 5f 01 00 	mov    0x15f74(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    6b64:	49 89 c5             	mov    %rax,%r13
    6b67:	48 2b 05 42 5f 01 00 	sub    0x15f42(%rip),%rax        # 1cab0 <fwp_heap+0x13b0>
    6b6e:	48 c1 e2 10          	shl    $0x10,%rdx
    6b72:	48 39 d0             	cmp    %rdx,%rax
    6b75:	73 57                	jae    6bce <fwp_main_thread+0x9be>
    6b77:	48 89 c2             	mov    %rax,%rdx
    6b7a:	48 c1 ea 10          	shr    $0x10,%rdx
    6b7e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b82:	48 8b 15 6f 5f 01 00 	mov    0x15f6f(%rip),%rdx        # 1caf8 <fwp_heap+0x13f8>
    6b89:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6b8d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6b91:	48 85 ed             	test   %rbp,%rbp
    6b94:	74 38                	je     6bce <fwp_main_thread+0x9be>
    6b96:	0f b6 0a             	movzbl (%rdx),%ecx
    6b99:	80 f9 02             	cmp    $0x2,%cl
    6b9c:	0f 84 2c 09 00 00    	je     74ce <fwp_main_thread+0x12be>
    6ba2:	80 f9 01             	cmp    $0x1,%cl
    6ba5:	75 27                	jne    6bce <fwp_main_thread+0x9be>
    6ba7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6baa:	0f b7 c0             	movzwl %ax,%eax
    6bad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bb0:	48 0f af c1          	imul   %rcx,%rax
    6bb4:	48 c1 e8 20          	shr    $0x20,%rax
    6bb8:	48 39 d0             	cmp    %rdx,%rax
    6bbb:	73 11                	jae    6bce <fwp_main_thread+0x9be>
    6bbd:	48 01 c5             	add    %rax,%rbp
    6bc0:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6bc4:	0f 84 10 0b 00 00    	je     76da <fwp_main_thread+0x14ca>
    6bca:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6bce:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    6bd3:	bf 01 00 00 00       	mov    $0x1,%edi
    6bd8:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    6bdd:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    6be4:	33 f3 bf 
    6be7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    6bec:	e8 8f dc ff ff       	call   4880 <fwp_data.part.0.constprop.0>
    6bf1:	48 8b 15 e0 5e 01 00 	mov    0x15ee0(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    6bf8:	48 8b 0d b1 5e 01 00 	mov    0x15eb1(%rip),%rcx        # 1cab0 <fwp_heap+0x13b0>
    6bff:	48 89 04 24          	mov    %rax,(%rsp)
    6c03:	48 89 d6             	mov    %rdx,%rsi
    6c06:	48 29 c8             	sub    %rcx,%rax
    6c09:	48 c1 e6 10          	shl    $0x10,%rsi
    6c0d:	48 39 f0             	cmp    %rsi,%rax
    6c10:	73 67                	jae    6c79 <fwp_main_thread+0xa69>
    6c12:	48 89 c6             	mov    %rax,%rsi
    6c15:	48 c1 ee 10          	shr    $0x10,%rsi
    6c19:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6c1d:	48 8b 35 d4 5e 01 00 	mov    0x15ed4(%rip),%rsi        # 1caf8 <fwp_heap+0x13f8>
    6c24:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6c28:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    6c2c:	48 85 ed             	test   %rbp,%rbp
    6c2f:	74 48                	je     6c79 <fwp_main_thread+0xa69>
    6c31:	0f b6 3e             	movzbl (%rsi),%edi
    6c34:	40 80 ff 02          	cmp    $0x2,%dil
    6c38:	0f 84 82 08 00 00    	je     74c0 <fwp_main_thread+0x12b0>
    6c3e:	40 80 ff 01          	cmp    $0x1,%dil
    6c42:	75 35                	jne    6c79 <fwp_main_thread+0xa69>
    6c44:	8b 7e 18             	mov    0x18(%rsi),%edi
    6c47:	0f b7 c0             	movzwl %ax,%eax
    6c4a:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6c4d:	48 0f af c7          	imul   %rdi,%rax
    6c51:	48 c1 e8 20          	shr    $0x20,%rax
    6c55:	48 39 f0             	cmp    %rsi,%rax
    6c58:	73 1f                	jae    6c79 <fwp_main_thread+0xa69>
    6c5a:	48 01 c5             	add    %rax,%rbp
    6c5d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6c61:	0f 84 59 0a 00 00    	je     76c0 <fwp_main_thread+0x14b0>
    6c67:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6c6b:	48 8b 0d 3e 5e 01 00 	mov    0x15e3e(%rip),%rcx        # 1cab0 <fwp_heap+0x13b0>
    6c72:	48 8b 15 5f 5e 01 00 	mov    0x15e5f(%rip),%rdx        # 1cad8 <fwp_heap+0x13d8>
    6c79:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    6c7e:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    6c83:	66 90                	xchg   %ax,%ax
    6c85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c8c:	00 00 00 00 
    6c90:	48 8b 04 24          	mov    (%rsp),%rax
    6c94:	48 c1 e2 10          	shl    $0x10,%rdx
    6c98:	48 29 c8             	sub    %rcx,%rax
    6c9b:	48 39 d0             	cmp    %rdx,%rax
    6c9e:	73 70                	jae    6d10 <fwp_main_thread+0xb00>
    6ca0:	48 89 c2             	mov    %rax,%rdx
    6ca3:	48 c1 ea 10          	shr    $0x10,%rdx
    6ca7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cab:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6cb2:	00 
    6cb3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6cb7:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6cbb:	48 85 db             	test   %rbx,%rbx
    6cbe:	74 50                	je     6d10 <fwp_main_thread+0xb00>
    6cc0:	0f b6 0a             	movzbl (%rdx),%ecx
    6cc3:	80 f9 02             	cmp    $0x2,%cl
    6cc6:	0f 84 fc 06 00 00    	je     73c8 <fwp_main_thread+0x11b8>
    6ccc:	80 f9 01             	cmp    $0x1,%cl
    6ccf:	75 3f                	jne    6d10 <fwp_main_thread+0xb00>
    6cd1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6cd4:	0f b7 c0             	movzwl %ax,%eax
    6cd7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6cda:	48 0f af c1          	imul   %rcx,%rax
    6cde:	48 c1 e8 20          	shr    $0x20,%rax
    6ce2:	48 39 d0             	cmp    %rdx,%rax
    6ce5:	73 29                	jae    6d10 <fwp_main_thread+0xb00>
    6ce7:	48 01 c3             	add    %rax,%rbx
    6cea:	0f b6 03             	movzbl (%rbx),%eax
    6ced:	84 c0                	test   %al,%al
    6cef:	74 1f                	je     6d10 <fwp_main_thread+0xb00>
    6cf1:	8b 0d c9 66 01 00    	mov    0x166c9(%rip),%ecx        # 1d3c0 <iteration_active>
    6cf7:	85 c9                	test   %ecx,%ecx
    6cf9:	74 08                	je     6d03 <fwp_main_thread+0xaf3>
    6cfb:	48 83 05 a5 66 01 00 	addq   $0x1,0x166a5(%rip)        # 1d3a8 <iteration_retains>
    6d02:	01 
    6d03:	3c fd                	cmp    $0xfd,%al
    6d05:	0f 87 d3 08 00 00    	ja     75de <fwp_main_thread+0x13ce>
    6d0b:	83 c0 01             	add    $0x1,%eax
    6d0e:	88 03                	mov    %al,(%rbx)
    6d10:	48 8b 1c 24          	mov    (%rsp),%rbx
    6d14:	31 ff                	xor    %edi,%edi
    6d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d1d:	00 00 00 
    6d20:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    6d24:	48 83 c7 01          	add    $0x1,%rdi
    6d28:	48 85 db             	test   %rbx,%rbx
    6d2b:	75 f3                	jne    6d20 <fwp_main_thread+0xb10>
    6d2d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    6d34:	ff ff 1f 
    6d37:	48 39 f8             	cmp    %rdi,%rax
    6d3a:	0f 82 00 0a 00 00    	jb     7740 <fwp_main_thread+0x1530>
    6d40:	e8 2b dd ff ff       	call   4a70 <fwp_array_new_packed.constprop.0>
    6d45:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6d4c:	00 
    6d4d:	48 89 c5             	mov    %rax,%rbp
    6d50:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6d57:	00 
    6d58:	48 c1 e2 10          	shl    $0x10,%rdx
    6d5c:	48 39 d0             	cmp    %rdx,%rax
    6d5f:	73 5a                	jae    6dbb <fwp_main_thread+0xbab>
    6d61:	48 89 c2             	mov    %rax,%rdx
    6d64:	48 c1 ea 10          	shr    $0x10,%rdx
    6d68:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d6c:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6d73:	00 
    6d74:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d78:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    6d7c:	4d 85 ed             	test   %r13,%r13
    6d7f:	74 3a                	je     6dbb <fwp_main_thread+0xbab>
    6d81:	0f b6 0a             	movzbl (%rdx),%ecx
    6d84:	80 f9 02             	cmp    $0x2,%cl
    6d87:	0f 84 53 06 00 00    	je     73e0 <fwp_main_thread+0x11d0>
    6d8d:	80 f9 01             	cmp    $0x1,%cl
    6d90:	75 29                	jne    6dbb <fwp_main_thread+0xbab>
    6d92:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6d95:	0f b7 c0             	movzwl %ax,%eax
    6d98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d9b:	48 0f af c1          	imul   %rcx,%rax
    6d9f:	48 c1 e8 20          	shr    $0x20,%rax
    6da3:	48 39 d0             	cmp    %rdx,%rax
    6da6:	73 13                	jae    6dbb <fwp_main_thread+0xbab>
    6da8:	49 01 c5             	add    %rax,%r13
    6dab:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    6db0:	0f 84 3e 06 00 00    	je     73f4 <fwp_main_thread+0x11e4>
    6db6:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    6dbb:	48 8b 0c 24          	mov    (%rsp),%rcx
    6dbf:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    6dc5:	48 8b 71 08          	mov    0x8(%rcx),%rsi
    6dc9:	4c 8b 69 10          	mov    0x10(%rcx),%r13
    6dcd:	49 89 ca             	mov    %rcx,%r10
    6dd0:	49 89 c9             	mov    %rcx,%r9
    6dd3:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6dda:	00 
    6ddb:	48 89 c8             	mov    %rcx,%rax
    6dde:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6de5:	00 
    6de6:	48 c1 e2 10          	shl    $0x10,%rdx
    6dea:	48 39 d0             	cmp    %rdx,%rax
    6ded:	73 7d                	jae    6e6c <fwp_main_thread+0xc5c>
    6def:	48 89 c2             	mov    %rax,%rdx
    6df2:	48 c1 ea 10          	shr    $0x10,%rdx
    6df6:	48 8d 3c 92          	lea    (%rdx,%rdx,4),%rdi
    6dfa:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6e01:	00 
    6e02:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
    6e06:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    6e0a:	48 85 ff             	test   %rdi,%rdi
    6e0d:	74 5d                	je     6e6c <fwp_main_thread+0xc5c>
    6e0f:	44 0f b6 02          	movzbl (%rdx),%r8d
    6e13:	41 80 f8 02          	cmp    $0x2,%r8b
    6e17:	0f 84 13 02 00 00    	je     7030 <fwp_main_thread+0xe20>
    6e1d:	41 80 f8 01          	cmp    $0x1,%r8b
    6e21:	75 49                	jne    6e6c <fwp_main_thread+0xc5c>
    6e23:	44 8b 42 18          	mov    0x18(%rdx),%r8d
    6e27:	0f b7 c0             	movzwl %ax,%eax
    6e2a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e2d:	49 0f af c0          	imul   %r8,%rax
    6e31:	48 c1 e8 20          	shr    $0x20,%rax
    6e35:	48 39 d0             	cmp    %rdx,%rax
    6e38:	73 32                	jae    6e6c <fwp_main_thread+0xc5c>
    6e3a:	48 01 c7             	add    %rax,%rdi
    6e3d:	80 3f 01             	cmpb   $0x1,(%rdi)
    6e40:	75 2a                	jne    6e6c <fwp_main_thread+0xc5c>
    6e42:	e9 41 01 00 00       	jmp    6f88 <fwp_main_thread+0xd78>
    6e47:	0f 1f 00             	nopl   (%rax)
    6e4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e51:	00 00 00 00 
    6e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e5c:	00 00 00 00 
    6e60:	49 8b 75 08          	mov    0x8(%r13),%rsi
    6e64:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    6e68:	49 83 c7 01          	add    $0x1,%r15
    6e6c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6e71:	0f 88 70 08 00 00    	js     76e7 <fwp_main_thread+0x14d7>
    6e77:	4a 89 74 fd 00       	mov    %rsi,0x0(%rbp,%r15,8)
    6e7c:	4d 85 ed             	test   %r13,%r13
    6e7f:	75 df                	jne    6e60 <fwp_main_thread+0xc50>
    6e81:	4c 89 cf             	mov    %r9,%rdi
    6e84:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    6e88:	49 bd ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r13
    6e8f:	ff ff 7f 
    6e92:	e8 a9 e0 ff ff       	call   4f40 <fwp_drop0>
    6e97:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e9b:	be 01 00 00 00       	mov    $0x1,%esi
    6ea0:	4c 89 f7             	mov    %r14,%rdi
    6ea3:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    6eaa:	00 00 
    6eac:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    6eb1:	e8 3a c0 ff ff       	call   2ef0 <buf_grow>
    6eb6:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ebb:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6ec0:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    6ec4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ec9:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6ecd:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    6ed2:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6ed7:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6edc:	4c 23 6d 00          	and    0x0(%rbp),%r13
    6ee0:	75 65                	jne    6f47 <fwp_main_thread+0xd37>
    6ee2:	e9 59 01 00 00       	jmp    7040 <fwp_main_thread+0xe30>
    6ee7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6eee:	00 00 
    6ef0:	48 8b 34 d8          	mov    (%rax,%rbx,8),%rsi
    6ef4:	48 8d 15 a5 3c 00 00 	lea    0x3ca5(%rip),%rdx        # aba0 <d0>
    6efb:	4c 89 f7             	mov    %r14,%rdi
    6efe:	48 83 c3 01          	add    $0x1,%rbx
    6f02:	e8 09 e3 ff ff       	call   5210 <fwp_write.constprop.0>
    6f07:	49 39 dd             	cmp    %rbx,%r13
    6f0a:	0f 84 30 01 00 00    	je     7040 <fwp_main_thread+0xe30>
    6f10:	be 02 00 00 00       	mov    $0x2,%esi
    6f15:	4c 89 f7             	mov    %r14,%rdi
    6f18:	e8 d3 bf ff ff       	call   2ef0 <buf_grow>
    6f1d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6f22:	ba 2c 20 00 00       	mov    $0x202c,%edx
    6f27:	48 03 44 24 40       	add    0x40(%rsp),%rax
    6f2c:	66 89 10             	mov    %dx,(%rax)
    6f2f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6f34:	48 8d 50 02          	lea    0x2(%rax),%rdx
    6f38:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    6f3d:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6f42:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    6f47:	4c 89 f8             	mov    %r15,%rax
    6f4a:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6f4f:	79 9f                	jns    6ef0 <fwp_main_thread+0xce0>
    6f51:	48 8b 45 10          	mov    0x10(%rbp),%rax
    6f55:	eb 99                	jmp    6ef0 <fwp_main_thread+0xce0>
    6f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f5e:	00 00 
    6f60:	48 8d 3d b9 c8 ff ff 	lea    -0x3747(%rip),%rdi        # 3820 <fwp_heap_report>
    6f67:	e8 34 0a 00 00       	call   79a0 <atexit>
    6f6c:	e9 e5 f2 ff ff       	jmp    6256 <fwp_main_thread+0x46>
    6f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f78:	e8 b3 c9 ff ff       	call   3930 <fwp_heap_init>
    6f7d:	e9 c6 f2 ff ff       	jmp    6248 <fwp_main_thread+0x38>
    6f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f88:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6f8d:	0f 88 54 07 00 00    	js     76e7 <fwp_main_thread+0x14d7>
    6f93:	4a 89 74 fd 00       	mov    %rsi,0x0(%rbp,%r15,8)
    6f98:	49 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%rax
    6f9f:	00 
    6fa0:	49 2b 8c 24 b0 13 00 	sub    0x13b0(%r12),%rcx
    6fa7:	00 
    6fa8:	48 c1 e0 10          	shl    $0x10,%rax
    6fac:	48 39 c1             	cmp    %rax,%rcx
    6faf:	73 59                	jae    700a <fwp_main_thread+0xdfa>
    6fb1:	48 89 c8             	mov    %rcx,%rax
    6fb4:	48 c1 e8 10          	shr    $0x10,%rax
    6fb8:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6fbc:	49 8b 84 24 f8 13 00 	mov    0x13f8(%r12),%rax
    6fc3:	00 
    6fc4:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6fc8:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6fcc:	48 85 d2             	test   %rdx,%rdx
    6fcf:	74 39                	je     700a <fwp_main_thread+0xdfa>
    6fd1:	0f b6 30             	movzbl (%rax),%esi
    6fd4:	40 80 fe 02          	cmp    $0x2,%sil
    6fd8:	0f 84 7a 03 00 00    	je     7358 <fwp_main_thread+0x1148>
    6fde:	40 80 fe 01          	cmp    $0x1,%sil
    6fe2:	75 26                	jne    700a <fwp_main_thread+0xdfa>
    6fe4:	8b 70 18             	mov    0x18(%rax),%esi
    6fe7:	0f b7 c9             	movzwl %cx,%ecx
    6fea:	8b 40 1c             	mov    0x1c(%rax),%eax
    6fed:	48 0f af ce          	imul   %rsi,%rcx
    6ff1:	48 c1 e9 20          	shr    $0x20,%rcx
    6ff5:	48 39 c1             	cmp    %rax,%rcx
    6ff8:	73 10                	jae    700a <fwp_main_thread+0xdfa>
    6ffa:	48 01 ca             	add    %rcx,%rdx
    6ffd:	80 3a 01             	cmpb   $0x1,(%rdx)
    7000:	75 08                	jne    700a <fwp_main_thread+0xdfa>
    7002:	4c 89 d7             	mov    %r10,%rdi
    7005:	e8 06 d1 ff ff       	call   4110 <fwp_mem_free>
    700a:	4d 85 ed             	test   %r13,%r13
    700d:	0f 84 57 03 00 00    	je     736a <fwp_main_thread+0x115a>
    7013:	49 8b 75 08          	mov    0x8(%r13),%rsi
    7017:	4d 89 ea             	mov    %r13,%r10
    701a:	4d 89 e9             	mov    %r13,%r9
    701d:	4c 89 e9             	mov    %r13,%rcx
    7020:	49 83 c7 01          	add    $0x1,%r15
    7024:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7028:	e9 a6 fd ff ff       	jmp    6dd3 <fwp_main_thread+0xbc3>
    702d:	0f 1f 00             	nopl   (%rax)
    7030:	66 85 c0             	test   %ax,%ax
    7033:	0f 85 33 fe ff ff    	jne    6e6c <fwp_main_thread+0xc5c>
    7039:	e9 ff fd ff ff       	jmp    6e3d <fwp_main_thread+0xc2d>
    703e:	66 90                	xchg   %ax,%ax
    7040:	be 01 00 00 00       	mov    $0x1,%esi
    7045:	4c 89 f7             	mov    %r14,%rdi
    7048:	e8 a3 be ff ff       	call   2ef0 <buf_grow>
    704d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7052:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    7057:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    705b:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7060:	48 8d 50 01          	lea    0x1(%rax),%rdx
    7064:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    7069:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    706e:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    7073:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    7078:	48 8d 05 ef 0f 00 00 	lea    0xfef(%rip),%rax        # 806e <_IO_stdin_used+0x6e>
    707f:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
    7084:	48 85 c9             	test   %rcx,%rcx
    7087:	48 0f 44 c8          	cmove  %rax,%rcx
    708b:	48 83 fb f6          	cmp    $0xfffffffffffffff6,%rbx
    708f:	0f 87 cb 06 00 00    	ja     7760 <fwp_main_thread+0x1550>
    7095:	48 8d 7b 09          	lea    0x9(%rbx),%rdi
    7099:	be 01 00 00 00       	mov    $0x1,%esi
    709e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    70a3:	e8 e8 d5 ff ff       	call   4690 <fwp_heap_alloc>
    70a8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    70ad:	48 89 da             	mov    %rbx,%rdx
    70b0:	48 89 18             	mov    %rbx,(%rax)
    70b3:	4c 8d 78 08          	lea    0x8(%rax),%r15
    70b7:	49 89 c5             	mov    %rax,%r13
    70ba:	4c 89 ff             	mov    %r15,%rdi
    70bd:	e8 ae b4 ff ff       	call   2570 <memcpy@plt>
    70c2:	41 c6 44 1d 08 00    	movb   $0x0,0x8(%r13,%rbx,1)
    70c8:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    70cd:	e8 ce b2 ff ff       	call   23a0 <free@plt>
    70d2:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    70d9:	00 
    70da:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    70e1:	00 
    70e2:	4c 89 e8             	mov    %r13,%rax
    70e5:	48 29 c8             	sub    %rcx,%rax
    70e8:	48 c1 e2 10          	shl    $0x10,%rdx
    70ec:	48 39 d0             	cmp    %rdx,%rax
    70ef:	73 6e                	jae    715f <fwp_main_thread+0xf4f>
    70f1:	48 89 c6             	mov    %rax,%rsi
    70f4:	48 c1 ee 10          	shr    $0x10,%rsi
    70f8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    70fc:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    7103:	00 
    7104:	48 8d 3c fe          	lea    (%rsi,%rdi,8),%rdi
    7108:	48 8b 77 20          	mov    0x20(%rdi),%rsi
    710c:	48 85 f6             	test   %rsi,%rsi
    710f:	74 4e                	je     715f <fwp_main_thread+0xf4f>
    7111:	44 0f b6 07          	movzbl (%rdi),%r8d
    7115:	41 80 f8 02          	cmp    $0x2,%r8b
    7119:	0f 84 e9 02 00 00    	je     7408 <fwp_main_thread+0x11f8>
    711f:	41 80 f8 01          	cmp    $0x1,%r8b
    7123:	75 3a                	jne    715f <fwp_main_thread+0xf4f>
    7125:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    7129:	0f b7 c0             	movzwl %ax,%eax
    712c:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    712f:	49 0f af c0          	imul   %r8,%rax
    7133:	48 c1 e8 20          	shr    $0x20,%rax
    7137:	48 39 f8             	cmp    %rdi,%rax
    713a:	73 23                	jae    715f <fwp_main_thread+0xf4f>
    713c:	48 01 c6             	add    %rax,%rsi
    713f:	80 3e ff             	cmpb   $0xff,(%rsi)
    7142:	0f 84 d2 02 00 00    	je     741a <fwp_main_thread+0x120a>
    7148:	c6 06 01             	movb   $0x1,(%rsi)
    714b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7152:	00 
    7153:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    715a:	00 
    715b:	48 c1 e2 10          	shl    $0x10,%rdx
    715f:	48 89 e8             	mov    %rbp,%rax
    7162:	48 29 c8             	sub    %rcx,%rax
    7165:	48 39 d0             	cmp    %rdx,%rax
    7168:	73 76                	jae    71e0 <fwp_main_thread+0xfd0>
    716a:	48 89 c2             	mov    %rax,%rdx
    716d:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    7174:	00 
    7175:	48 c1 ea 10          	shr    $0x10,%rdx
    7179:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    717d:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    7181:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    7185:	48 85 d2             	test   %rdx,%rdx
    7188:	74 56                	je     71e0 <fwp_main_thread+0xfd0>
    718a:	0f b6 3e             	movzbl (%rsi),%edi
    718d:	40 80 ff 02          	cmp    $0x2,%dil
    7191:	0f 84 e1 01 00 00    	je     7378 <fwp_main_thread+0x1168>
    7197:	40 80 ff 01          	cmp    $0x1,%dil
    719b:	75 43                	jne    71e0 <fwp_main_thread+0xfd0>
    719d:	8b 7e 18             	mov    0x18(%rsi),%edi
    71a0:	0f b7 c0             	movzwl %ax,%eax
    71a3:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71a6:	48 0f af c7          	imul   %rdi,%rax
    71aa:	48 c1 e8 20          	shr    $0x20,%rax
    71ae:	48 39 f0             	cmp    %rsi,%rax
    71b1:	73 2d                	jae    71e0 <fwp_main_thread+0xfd0>
    71b3:	48 01 c2             	add    %rax,%rdx
    71b6:	0f b6 02             	movzbl (%rdx),%eax
    71b9:	84 c0                	test   %al,%al
    71bb:	74 23                	je     71e0 <fwp_main_thread+0xfd0>
    71bd:	3c 01                	cmp    $0x1,%al
    71bf:	0f 84 fb 00 00 00    	je     72c0 <fwp_main_thread+0x10b0>
    71c5:	3c ff                	cmp    $0xff,%al
    71c7:	0f 84 2a 03 00 00    	je     74f7 <fwp_main_thread+0x12e7>
    71cd:	83 e8 01             	sub    $0x1,%eax
    71d0:	88 02                	mov    %al,(%rdx)
    71d2:	0f 1f 00             	nopl   (%rax)
    71d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71dc:	00 00 00 00 
    71e0:	49 8b 55 00          	mov    0x0(%r13),%rdx
    71e4:	48 8b 0d 6d 61 01 00 	mov    0x1616d(%rip),%rcx        # 1d358 <fwp_prog_out>
    71eb:	be 01 00 00 00       	mov    $0x1,%esi
    71f0:	4c 89 ff             	mov    %r15,%rdi
    71f3:	e8 48 b4 ff ff       	call   2640 <fwrite@plt>
    71f8:	48 8b 35 59 61 01 00 	mov    0x16159(%rip),%rsi        # 1d358 <fwp_prog_out>
    71ff:	bf 0a 00 00 00       	mov    $0xa,%edi
    7204:	e8 b7 b2 ff ff       	call   24c0 <fputc@plt>
    7209:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7210:	00 
    7211:	4c 89 e8             	mov    %r13,%rax
    7214:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    721b:	00 
    721c:	48 c1 e2 10          	shl    $0x10,%rdx
    7220:	48 39 d0             	cmp    %rdx,%rax
    7223:	73 6b                	jae    7290 <fwp_main_thread+0x1080>
    7225:	48 89 c2             	mov    %rax,%rdx
    7228:	48 c1 ea 10          	shr    $0x10,%rdx
    722c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7230:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7237:	00 
    7238:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    723c:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7240:	48 85 db             	test   %rbx,%rbx
    7243:	74 4b                	je     7290 <fwp_main_thread+0x1080>
    7245:	0f b6 0a             	movzbl (%rdx),%ecx
    7248:	80 f9 02             	cmp    $0x2,%cl
    724b:	0f 84 e7 01 00 00    	je     7438 <fwp_main_thread+0x1228>
    7251:	80 f9 01             	cmp    $0x1,%cl
    7254:	75 3a                	jne    7290 <fwp_main_thread+0x1080>
    7256:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7259:	0f b7 c0             	movzwl %ax,%eax
    725c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    725f:	48 0f af c1          	imul   %rcx,%rax
    7263:	48 c1 e8 20          	shr    $0x20,%rax
    7267:	48 39 d0             	cmp    %rdx,%rax
    726a:	73 24                	jae    7290 <fwp_main_thread+0x1080>
    726c:	48 01 c3             	add    %rax,%rbx
    726f:	0f b6 03             	movzbl (%rbx),%eax
    7272:	84 c0                	test   %al,%al
    7274:	74 1a                	je     7290 <fwp_main_thread+0x1080>
    7276:	3c 01                	cmp    $0x1,%al
    7278:	0f 84 e2 01 00 00    	je     7460 <fwp_main_thread+0x1250>
    727e:	3c ff                	cmp    $0xff,%al
    7280:	0f 84 e2 02 00 00    	je     7568 <fwp_main_thread+0x1358>
    7286:	83 e8 01             	sub    $0x1,%eax
    7289:	88 03                	mov    %al,(%rbx)
    728b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7290:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7295:	48 8b 40 10          	mov    0x10(%rax),%rax
    7299:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    729e:	48 85 c0             	test   %rax,%rax
    72a1:	0f 84 e9 01 00 00    	je     7490 <fwp_main_thread+0x1280>
    72a7:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    72ae:	00 
    72af:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    72b6:	00 
    72b7:	e9 d4 f9 ff ff       	jmp    6c90 <fwp_main_thread+0xa80>
    72bc:	0f 1f 40 00          	nopl   0x0(%rax)
    72c0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    72c5:	0f 88 c5 00 00 00    	js     7390 <fwp_main_thread+0x1180>
    72cb:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    72d2:	00 
    72d3:	48 89 e8             	mov    %rbp,%rax
    72d6:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    72dd:	00 
    72de:	48 c1 e2 10          	shl    $0x10,%rdx
    72e2:	48 39 d0             	cmp    %rdx,%rax
    72e5:	0f 83 f5 fe ff ff    	jae    71e0 <fwp_main_thread+0xfd0>
    72eb:	48 89 c2             	mov    %rax,%rdx
    72ee:	48 c1 ea 10          	shr    $0x10,%rdx
    72f2:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    72f6:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    72fa:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    72fe:	48 85 c9             	test   %rcx,%rcx
    7301:	0f 84 d9 fe ff ff    	je     71e0 <fwp_main_thread+0xfd0>
    7307:	0f b6 32             	movzbl (%rdx),%esi
    730a:	40 80 fe 02          	cmp    $0x2,%sil
    730e:	0f 84 5c 01 00 00    	je     7470 <fwp_main_thread+0x1260>
    7314:	40 80 fe 01          	cmp    $0x1,%sil
    7318:	0f 85 c2 fe ff ff    	jne    71e0 <fwp_main_thread+0xfd0>
    731e:	8b 72 18             	mov    0x18(%rdx),%esi
    7321:	0f b7 c0             	movzwl %ax,%eax
    7324:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7327:	48 0f af c6          	imul   %rsi,%rax
    732b:	48 c1 e8 20          	shr    $0x20,%rax
    732f:	48 39 d0             	cmp    %rdx,%rax
    7332:	0f 83 a8 fe ff ff    	jae    71e0 <fwp_main_thread+0xfd0>
    7338:	48 01 c1             	add    %rax,%rcx
    733b:	80 39 01             	cmpb   $0x1,(%rcx)
    733e:	0f 85 9c fe ff ff    	jne    71e0 <fwp_main_thread+0xfd0>
    7344:	48 89 ef             	mov    %rbp,%rdi
    7347:	e8 c4 cd ff ff       	call   4110 <fwp_mem_free>
    734c:	e9 8f fe ff ff       	jmp    71e0 <fwp_main_thread+0xfd0>
    7351:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7358:	66 85 c9             	test   %cx,%cx
    735b:	0f 84 9c fc ff ff    	je     6ffd <fwp_main_thread+0xded>
    7361:	4d 85 ed             	test   %r13,%r13
    7364:	0f 85 a9 fc ff ff    	jne    7013 <fwp_main_thread+0xe03>
    736a:	45 31 c9             	xor    %r9d,%r9d
    736d:	e9 0f fb ff ff       	jmp    6e81 <fwp_main_thread+0xc71>
    7372:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7378:	66 85 c0             	test   %ax,%ax
    737b:	0f 85 5f fe ff ff    	jne    71e0 <fwp_main_thread+0xfd0>
    7381:	e9 30 fe ff ff       	jmp    71b6 <fwp_main_thread+0xfa6>
    7386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    738d:	00 00 00 
    7390:	48 89 ef             	mov    %rbp,%rdi
    7393:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    7397:	e8 74 d2 ff ff       	call   4610 <fwp_rc_free_arr>
    739c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    73a3:	00 
    73a4:	48 89 d8             	mov    %rbx,%rax
    73a7:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    73ae:	00 
    73af:	48 c1 e2 10          	shl    $0x10,%rdx
    73b3:	48 39 d0             	cmp    %rdx,%rax
    73b6:	0f 83 24 fe ff ff    	jae    71e0 <fwp_main_thread+0xfd0>
    73bc:	48 89 dd             	mov    %rbx,%rbp
    73bf:	e9 a6 fd ff ff       	jmp    716a <fwp_main_thread+0xf5a>
    73c4:	0f 1f 40 00          	nopl   0x0(%rax)
    73c8:	66 85 c0             	test   %ax,%ax
    73cb:	0f 85 3f f9 ff ff    	jne    6d10 <fwp_main_thread+0xb00>
    73d1:	e9 14 f9 ff ff       	jmp    6cea <fwp_main_thread+0xada>
    73d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    73dd:	00 00 00 
    73e0:	66 85 c0             	test   %ax,%ax
    73e3:	0f 85 d2 f9 ff ff    	jne    6dbb <fwp_main_thread+0xbab>
    73e9:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    73ee:	0f 85 c2 f9 ff ff    	jne    6db6 <fwp_main_thread+0xba6>
    73f4:	4c 89 ef             	mov    %r13,%rdi
    73f7:	e8 d4 ca ff ff       	call   3ed0 <fwp_rc_forget_slot>
    73fc:	e9 b5 f9 ff ff       	jmp    6db6 <fwp_main_thread+0xba6>
    7401:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7408:	66 85 c0             	test   %ax,%ax
    740b:	0f 85 4e fd ff ff    	jne    715f <fwp_main_thread+0xf4f>
    7411:	80 3e ff             	cmpb   $0xff,(%rsi)
    7414:	0f 85 2e fd ff ff    	jne    7148 <fwp_main_thread+0xf38>
    741a:	48 89 f7             	mov    %rsi,%rdi
    741d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    7422:	e8 a9 ca ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7427:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    742c:	e9 17 fd ff ff       	jmp    7148 <fwp_main_thread+0xf38>
    7431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7438:	66 85 c0             	test   %ax,%ax
    743b:	0f 85 4f fe ff ff    	jne    7290 <fwp_main_thread+0x1080>
    7441:	0f b6 03             	movzbl (%rbx),%eax
    7444:	84 c0                	test   %al,%al
    7446:	0f 84 44 fe ff ff    	je     7290 <fwp_main_thread+0x1080>
    744c:	3c 01                	cmp    $0x1,%al
    744e:	0f 85 2a fe ff ff    	jne    727e <fwp_main_thread+0x106e>
    7454:	90                   	nop
    7455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    745c:	00 00 00 00 
    7460:	4c 89 ef             	mov    %r13,%rdi
    7463:	e8 a8 cc ff ff       	call   4110 <fwp_mem_free>
    7468:	e9 23 fe ff ff       	jmp    7290 <fwp_main_thread+0x1080>
    746d:	0f 1f 00             	nopl   (%rax)
    7470:	66 85 c0             	test   %ax,%ax
    7473:	0f 85 67 fd ff ff    	jne    71e0 <fwp_main_thread+0xfd0>
    7479:	e9 bd fe ff ff       	jmp    733b <fwp_main_thread+0x112b>
    747e:	66 90                	xchg   %ax,%ax
    7480:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7484:	e9 90 ef ff ff       	jmp    6419 <fwp_main_thread+0x209>
    7489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7490:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    7495:	48 8b 3c 24          	mov    (%rsp),%rdi
    7499:	e8 a2 da ff ff       	call   4f40 <fwp_drop0>
    749e:	48 89 df             	mov    %rbx,%rdi
    74a1:	e8 9a da ff ff       	call   4f40 <fwp_drop0>
    74a6:	48 c7 05 af 3b 00 00 	movq   $0x0,0x3baf(%rip)        # b060 <v.1>
    74ad:	00 00 00 00 
    74b1:	c7 05 ad 3b 00 00 01 	movl   $0x1,0x3bad(%rip)        # b068 <st.2>
    74b8:	00 00 00 
    74bb:	e9 a5 ee ff ff       	jmp    6365 <fwp_main_thread+0x155>
    74c0:	66 85 c0             	test   %ax,%ax
    74c3:	0f 85 b0 f7 ff ff    	jne    6c79 <fwp_main_thread+0xa69>
    74c9:	e9 8f f7 ff ff       	jmp    6c5d <fwp_main_thread+0xa4d>
    74ce:	66 85 c0             	test   %ax,%ax
    74d1:	0f 85 f7 f6 ff ff    	jne    6bce <fwp_main_thread+0x9be>
    74d7:	e9 e4 f6 ff ff       	jmp    6bc0 <fwp_main_thread+0x9b0>
    74dc:	66 85 c0             	test   %ax,%ax
    74df:	0f 85 55 f6 ff ff    	jne    6b3a <fwp_main_thread+0x92a>
    74e5:	e9 42 f6 ff ff       	jmp    6b2c <fwp_main_thread+0x91c>
    74ea:	4c 89 ff             	mov    %r15,%rdi
    74ed:	e8 de c9 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    74f2:	e9 11 f5 ff ff       	jmp    6a08 <fwp_main_thread+0x7f8>
    74f7:	48 89 d1             	mov    %rdx,%rcx
    74fa:	48 c1 e9 11          	shr    $0x11,%rcx
    74fe:	48 31 d1             	xor    %rdx,%rcx
    7501:	48 89 c8             	mov    %rcx,%rax
    7504:	48 c1 e8 09          	shr    $0x9,%rax
    7508:	48 31 c1             	xor    %rax,%rcx
    750b:	0f b6 c9             	movzbl %cl,%ecx
    750e:	49 8b 84 cc 48 14 00 	mov    0x1448(%r12,%rcx,8),%rax
    7515:	00 
    7516:	48 85 c0             	test   %rax,%rax
    7519:	75 12                	jne    752d <fwp_main_thread+0x131d>
    751b:	e9 f9 01 00 00       	jmp    7719 <fwp_main_thread+0x1509>
    7520:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7524:	48 85 c0             	test   %rax,%rax
    7527:	0f 84 ec 01 00 00    	je     7719 <fwp_main_thread+0x1509>
    752d:	48 89 c1             	mov    %rax,%rcx
    7530:	48 3b 10             	cmp    (%rax),%rdx
    7533:	75 eb                	jne    7520 <fwp_main_thread+0x1310>
    7535:	48 8b 48 08          	mov    0x8(%rax),%rcx
    7539:	48 83 e9 01          	sub    $0x1,%rcx
    753d:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7541:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7548:	0f 85 92 fc ff ff    	jne    71e0 <fwp_main_thread+0xfd0>
    754e:	48 89 d7             	mov    %rdx,%rdi
    7551:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    7556:	e8 75 c9 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    755b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7560:	c6 02 fe             	movb   $0xfe,(%rdx)
    7563:	e9 78 fc ff ff       	jmp    71e0 <fwp_main_thread+0xfd0>
    7568:	48 89 da             	mov    %rbx,%rdx
    756b:	48 c1 ea 11          	shr    $0x11,%rdx
    756f:	48 31 da             	xor    %rbx,%rdx
    7572:	48 89 d0             	mov    %rdx,%rax
    7575:	48 c1 e8 09          	shr    $0x9,%rax
    7579:	48 31 c2             	xor    %rax,%rdx
    757c:	0f b6 d2             	movzbl %dl,%edx
    757f:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    7586:	00 
    7587:	48 85 c0             	test   %rax,%rax
    758a:	75 21                	jne    75ad <fwp_main_thread+0x139d>
    758c:	e9 88 01 00 00       	jmp    7719 <fwp_main_thread+0x1509>
    7591:	0f 1f 40 00          	nopl   0x0(%rax)
    7595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    759c:	00 00 00 00 
    75a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    75a4:	48 85 c0             	test   %rax,%rax
    75a7:	0f 84 6c 01 00 00    	je     7719 <fwp_main_thread+0x1509>
    75ad:	48 89 c2             	mov    %rax,%rdx
    75b0:	48 3b 18             	cmp    (%rax),%rbx
    75b3:	75 eb                	jne    75a0 <fwp_main_thread+0x1390>
    75b5:	48 8b 48 08          	mov    0x8(%rax),%rcx
    75b9:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    75bd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    75c1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    75c8:	0f 85 c2 fc ff ff    	jne    7290 <fwp_main_thread+0x1080>
    75ce:	48 89 df             	mov    %rbx,%rdi
    75d1:	e8 fa c8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    75d6:	c6 03 fe             	movb   $0xfe,(%rbx)
    75d9:	e9 b2 fc ff ff       	jmp    7290 <fwp_main_thread+0x1080>
    75de:	48 89 d9             	mov    %rbx,%rcx
    75e1:	48 c1 e9 11          	shr    $0x11,%rcx
    75e5:	48 31 d9             	xor    %rbx,%rcx
    75e8:	48 89 ca             	mov    %rcx,%rdx
    75eb:	48 c1 ea 09          	shr    $0x9,%rdx
    75ef:	48 31 d1             	xor    %rdx,%rcx
    75f2:	0f b6 c9             	movzbl %cl,%ecx
    75f5:	49 8d ac cc 48 14 00 	lea    0x1448(%r12,%rcx,8),%rbp
    75fc:	00 
    75fd:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    7601:	49 83 bc cc 48 14 00 	cmpq   $0x0,0x1448(%r12,%rcx,8)
    7608:	00 00 
    760a:	75 20                	jne    762c <fwp_main_thread+0x141c>
    760c:	e9 e2 00 00 00       	jmp    76f3 <fwp_main_thread+0x14e3>
    7611:	0f 1f 40 00          	nopl   0x0(%rax)
    7615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    761c:	00 00 00 00 
    7620:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7624:	48 85 c9             	test   %rcx,%rcx
    7627:	74 2b                	je     7654 <fwp_main_thread+0x1444>
    7629:	48 89 ca             	mov    %rcx,%rdx
    762c:	48 39 1a             	cmp    %rbx,(%rdx)
    762f:	75 ef                	jne    7620 <fwp_main_thread+0x1410>
    7631:	3c fe                	cmp    $0xfe,%al
    7633:	0f 84 c7 00 00 00    	je     7700 <fwp_main_thread+0x14f0>
    7639:	48 8b 42 08          	mov    0x8(%rdx),%rax
    763d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    7641:	0f 84 05 01 00 00    	je     774c <fwp_main_thread+0x153c>
    7647:	48 83 c0 01          	add    $0x1,%rax
    764b:	48 89 42 08          	mov    %rax,0x8(%rdx)
    764f:	e9 bc f6 ff ff       	jmp    6d10 <fwp_main_thread+0xb00>
    7654:	3c fe                	cmp    $0xfe,%al
    7656:	0f 85 bd 00 00 00    	jne    7719 <fwp_main_thread+0x1509>
    765c:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    7660:	bf 18 00 00 00       	mov    $0x18,%edi
    7665:	e8 16 af ff ff       	call   2580 <malloc@plt>
    766a:	48 85 c0             	test   %rax,%rax
    766d:	0f 84 c1 00 00 00    	je     7734 <fwp_main_thread+0x1524>
    7673:	48 89 18             	mov    %rbx,(%rax)
    7676:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    767d:	00 
    767e:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    7685:	00 
    7686:	48 89 45 00          	mov    %rax,0x0(%rbp)
    768a:	c6 03 ff             	movb   $0xff,(%rbx)
    768d:	49 83 84 24 48 1c 00 	addq   $0x1,0x1c48(%r12)
    7694:	00 01 
    7696:	e9 75 f6 ff ff       	jmp    6d10 <fwp_main_thread+0xb00>
    769b:	48 83 3d 35 40 01 00 	cmpq   $0x0,0x14035(%rip)        # 1b6d8 <fwp_root>
    76a2:	00 
    76a3:	c7 05 d3 39 01 00 00 	movl   $0x0,0x139d3(%rip)        # 1b080 <fwp_exit_code>
    76aa:	00 00 00 
    76ad:	0f 84 f3 ef ff ff    	je     66a6 <fwp_main_thread+0x496>
    76b3:	e9 53 b0 ff ff       	jmp    270b <fwp_main_thread.cold>
    76b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    76bf:	00 
    76c0:	48 89 ef             	mov    %rbp,%rdi
    76c3:	e8 08 c8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    76c8:	e9 9a f5 ff ff       	jmp    6c67 <fwp_main_thread+0xa57>
    76cd:	48 89 ef             	mov    %rbp,%rdi
    76d0:	e8 fb c7 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    76d5:	e9 5c f4 ff ff       	jmp    6b36 <fwp_main_thread+0x926>
    76da:	48 89 ef             	mov    %rbp,%rdi
    76dd:	e8 ee c7 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    76e2:	e9 e3 f4 ff ff       	jmp    6bca <fwp_main_thread+0x9ba>
    76e7:	48 8d 3d 2a 0d 00 00 	lea    0xd2a(%rip),%rdi        # 8418 <_IO_stdin_used+0x418>
    76ee:	e8 0d bb ff ff       	call   3200 <fwp_trap>
    76f3:	3c fe                	cmp    $0xfe,%al
    76f5:	75 19                	jne    7710 <fwp_main_thread+0x1500>
    76f7:	48 85 d2             	test   %rdx,%rdx
    76fa:	0f 84 60 ff ff ff    	je     7660 <fwp_main_thread+0x1450>
    7700:	48 8d 3d e9 0c 00 00 	lea    0xce9(%rip),%rdi        # 83f0 <_IO_stdin_used+0x3f0>
    7707:	e8 f4 ba ff ff       	call   3200 <fwp_trap>
    770c:	0f 1f 40 00          	nopl   0x0(%rax)
    7710:	48 85 d2             	test   %rdx,%rdx
    7713:	0f 85 20 ff ff ff    	jne    7639 <fwp_main_thread+0x1429>
    7719:	48 8d 3d 80 0c 00 00 	lea    0xc80(%rip),%rdi        # 83a0 <_IO_stdin_used+0x3a0>
    7720:	e8 db ba ff ff       	call   3200 <fwp_trap>
    7725:	0f 1f 00             	nopl   (%rax)
    7728:	48 8d 3d 99 0c 00 00 	lea    0xc99(%rip),%rdi        # 83c8 <_IO_stdin_used+0x3c8>
    772f:	e8 cc ba ff ff       	call   3200 <fwp_trap>
    7734:	e8 b7 b5 ff ff       	call   2cf0 <fwp_heap_oom>
    7739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7740:	48 8d 3d 9e 09 00 00 	lea    0x99e(%rip),%rdi        # 80e5 <_IO_stdin_used+0xe5>
    7747:	e8 b4 ba ff ff       	call   3200 <fwp_trap>
    774c:	48 8d 3d 4c 0a 00 00 	lea    0xa4c(%rip),%rdi        # 819f <_IO_stdin_used+0x19f>
    7753:	e8 a8 ba ff ff       	call   3200 <fwp_trap>
    7758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    775f:	00 
    7760:	48 8d 3d 51 0a 00 00 	lea    0xa51(%rip),%rdi        # 81b8 <_IO_stdin_used+0x1b8>
    7767:	e8 94 ba ff ff       	call   3200 <fwp_trap>
    776c:	48 8d 3d 11 0a 00 00 	lea    0xa11(%rip),%rdi        # 8184 <_IO_stdin_used+0x184>
    7773:	e8 48 b7 ff ff       	call   2ec0 <ad_raw_fail>
    7778:	48 89 c8             	mov    %rcx,%rax
    777b:	e9 69 ee ff ff       	jmp    65e9 <fwp_main_thread+0x3d9>
    7780:	e8 bb ac ff ff       	call   2440 <__stack_chk_fail@plt>
    7785:	e9 81 af ff ff       	jmp    270b <fwp_main_thread.cold>
    778a:	e9 7c af ff ff       	jmp    270b <fwp_main_thread.cold>
    778f:	90                   	nop

0000000000007790 <__divmodti4>:
    7790:	f3 0f 1e fa          	endbr64
    7794:	55                   	push   %rbp
    7795:	49 89 f1             	mov    %rsi,%r9
    7798:	49 89 d2             	mov    %rdx,%r10
    779b:	48 89 fe             	mov    %rdi,%rsi
    779e:	49 89 cb             	mov    %rcx,%r11
    77a1:	48 89 e5             	mov    %rsp,%rbp
    77a4:	41 57                	push   %r15
    77a6:	41 56                	push   %r14
    77a8:	41 55                	push   %r13
    77aa:	41 54                	push   %r12
    77ac:	53                   	push   %rbx
    77ad:	4c 89 c3             	mov    %r8,%rbx
    77b0:	45 31 c0             	xor    %r8d,%r8d
    77b3:	4d 85 c9             	test   %r9,%r9
    77b6:	79 12                	jns    77ca <__divmodti4+0x3a>
    77b8:	31 ff                	xor    %edi,%edi
    77ba:	48 f7 de             	neg    %rsi
    77bd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    77c4:	4c 19 cf             	sbb    %r9,%rdi
    77c7:	49 89 f9             	mov    %rdi,%r9
    77ca:	4c 89 d8             	mov    %r11,%rax
    77cd:	4d 85 db             	test   %r11,%r11
    77d0:	0f 88 1a 01 00 00    	js     78f0 <__divmodti4+0x160>
    77d6:	4c 89 d9             	mov    %r11,%rcx
    77d9:	49 89 f3             	mov    %rsi,%r11
    77dc:	75 62                	jne    7840 <__divmodti4+0xb0>
    77de:	4d 89 c4             	mov    %r8,%r12
    77e1:	4d 39 d1             	cmp    %r10,%r9
    77e4:	0f 83 46 01 00 00    	jae    7930 <__divmodti4+0x1a0>
    77ea:	4c 89 d8             	mov    %r11,%rax
    77ed:	4c 89 ca             	mov    %r9,%rdx
    77f0:	49 f7 f2             	div    %r10
    77f3:	49 89 c3             	mov    %rax,%r11
    77f6:	31 c0                	xor    %eax,%eax
    77f8:	48 89 d6             	mov    %rdx,%rsi
    77fb:	31 ff                	xor    %edi,%edi
    77fd:	4c 89 d9             	mov    %r11,%rcx
    7800:	48 89 c2             	mov    %rax,%rdx
    7803:	48 89 c8             	mov    %rcx,%rax
    7806:	4d 85 e4             	test   %r12,%r12
    7809:	74 0a                	je     7815 <__divmodti4+0x85>
    780b:	48 f7 d8             	neg    %rax
    780e:	48 83 d2 00          	adc    $0x0,%rdx
    7812:	48 f7 da             	neg    %rdx
    7815:	4d 85 c0             	test   %r8,%r8
    7818:	74 0a                	je     7824 <__divmodti4+0x94>
    781a:	48 f7 de             	neg    %rsi
    781d:	48 83 d7 00          	adc    $0x0,%rdi
    7821:	48 f7 df             	neg    %rdi
    7824:	48 89 33             	mov    %rsi,(%rbx)
    7827:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    782b:	5b                   	pop    %rbx
    782c:	41 5c                	pop    %r12
    782e:	41 5d                	pop    %r13
    7830:	41 5e                	pop    %r14
    7832:	41 5f                	pop    %r15
    7834:	5d                   	pop    %rbp
    7835:	c3                   	ret
    7836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    783d:	00 00 00 
    7840:	4d 89 c4             	mov    %r8,%r12
    7843:	49 39 c1             	cmp    %rax,%r9
    7846:	0f 82 ce 00 00 00    	jb     791a <__divmodti4+0x18a>
    784c:	31 ff                	xor    %edi,%edi
    784e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    7853:	48 63 c7             	movslq %edi,%rax
    7856:	be 40 00 00 00       	mov    $0x40,%esi
    785b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    7860:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    7865:	48 29 c6             	sub    %rax,%rsi
    7868:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    786d:	48 09 c8             	or     %rcx,%rax
    7870:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    7875:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    787a:	49 89 c6             	mov    %rax,%r14
    787d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    7881:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    7886:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    788b:	49 09 c1             	or     %rax,%r9
    788e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    7892:	4c 89 c8             	mov    %r9,%rax
    7895:	49 f7 f6             	div    %r14
    7898:	48 89 d1             	mov    %rdx,%rcx
    789b:	49 89 c3             	mov    %rax,%r11
    789e:	49 89 c1             	mov    %rax,%r9
    78a1:	49 f7 e2             	mul    %r10
    78a4:	49 89 c6             	mov    %rax,%r14
    78a7:	49 89 d2             	mov    %rdx,%r10
    78aa:	48 39 d1             	cmp    %rdx,%rcx
    78ad:	72 07                	jb     78b6 <__divmodti4+0x126>
    78af:	75 17                	jne    78c8 <__divmodti4+0x138>
    78b1:	49 39 c7             	cmp    %rax,%r15
    78b4:	73 12                	jae    78c8 <__divmodti4+0x138>
    78b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    78ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    78be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    78c2:	49 89 d2             	mov    %rdx,%r10
    78c5:	49 89 c6             	mov    %rax,%r14
    78c8:	4c 89 f8             	mov    %r15,%rax
    78cb:	4c 29 f0             	sub    %r14,%rax
    78ce:	4c 19 d1             	sbb    %r10,%rcx
    78d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    78d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    78db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    78e0:	48 09 c6             	or     %rax,%rsi
    78e3:	48 89 cf             	mov    %rcx,%rdi
    78e6:	31 c0                	xor    %eax,%eax
    78e8:	4c 89 c9             	mov    %r9,%rcx
    78eb:	e9 10 ff ff ff       	jmp    7800 <__divmodti4+0x70>
    78f0:	4c 89 d0             	mov    %r10,%rax
    78f3:	4c 89 da             	mov    %r11,%rdx
    78f6:	4d 89 c4             	mov    %r8,%r12
    78f9:	49 89 f3             	mov    %rsi,%r11
    78fc:	48 f7 d8             	neg    %rax
    78ff:	49 f7 d4             	not    %r12
    7902:	48 83 d2 00          	adc    $0x0,%rdx
    7906:	49 89 c2             	mov    %rax,%r10
    7909:	48 f7 da             	neg    %rdx
    790c:	48 89 d1             	mov    %rdx,%rcx
    790f:	0f 84 cc fe ff ff    	je     77e1 <__divmodti4+0x51>
    7915:	49 39 d1             	cmp    %rdx,%r9
    7918:	73 46                	jae    7960 <__divmodti4+0x1d0>
    791a:	4c 89 cf             	mov    %r9,%rdi
    791d:	31 c0                	xor    %eax,%eax
    791f:	31 c9                	xor    %ecx,%ecx
    7921:	e9 da fe ff ff       	jmp    7800 <__divmodti4+0x70>
    7926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    792d:	00 00 00 
    7930:	4d 85 d2             	test   %r10,%r10
    7933:	75 0d                	jne    7942 <__divmodti4+0x1b2>
    7935:	b8 01 00 00 00       	mov    $0x1,%eax
    793a:	31 d2                	xor    %edx,%edx
    793c:	49 f7 f2             	div    %r10
    793f:	49 89 c2             	mov    %rax,%r10
    7942:	4c 89 c8             	mov    %r9,%rax
    7945:	31 d2                	xor    %edx,%edx
    7947:	49 f7 f2             	div    %r10
    794a:	49 89 c1             	mov    %rax,%r9
    794d:	4c 89 d8             	mov    %r11,%rax
    7950:	49 f7 f2             	div    %r10
    7953:	49 89 c3             	mov    %rax,%r11
    7956:	4c 89 c8             	mov    %r9,%rax
    7959:	e9 9a fe ff ff       	jmp    77f8 <__divmodti4+0x68>
    795e:	66 90                	xchg   %ax,%ax
    7960:	45 31 f6             	xor    %r14d,%r14d
    7963:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    7968:	44 89 f7             	mov    %r14d,%edi
    796b:	45 85 f6             	test   %r14d,%r14d
    796e:	0f 85 df fe ff ff    	jne    7853 <__divmodti4+0xc3>
    7974:	4c 39 ca             	cmp    %r9,%rdx
    7977:	72 17                	jb     7990 <__divmodti4+0x200>
    7979:	31 c9                	xor    %ecx,%ecx
    797b:	48 39 c6             	cmp    %rax,%rsi
    797e:	73 10                	jae    7990 <__divmodti4+0x200>
    7980:	4c 89 cf             	mov    %r9,%rdi
    7983:	31 c0                	xor    %eax,%eax
    7985:	e9 76 fe ff ff       	jmp    7800 <__divmodti4+0x70>
    798a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7990:	4c 89 de             	mov    %r11,%rsi
    7993:	b9 01 00 00 00       	mov    $0x1,%ecx
    7998:	48 29 c6             	sub    %rax,%rsi
    799b:	49 19 d1             	sbb    %rdx,%r9
    799e:	eb e0                	jmp    7980 <__divmodti4+0x1f0>

00000000000079a0 <atexit>:
    79a0:	f3 0f 1e fa          	endbr64
    79a4:	48 8b 15 5d 36 00 00 	mov    0x365d(%rip),%rdx        # b008 <__dso_handle>
    79ab:	31 f6                	xor    %esi,%esi
    79ad:	e9 6e ac ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000079b4 <_fini>:
    79b4:	f3 0f 1e fa          	endbr64
    79b8:	48 83 ec 08          	sub    $0x8,%rsp
    79bc:	48 83 c4 08          	add    $0x8,%rsp
    79c0:	c3                   	ret
