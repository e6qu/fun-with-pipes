
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-local:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 7f 00 00 	mov    0x7fd9(%rip),%rax        # 9fe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 7e 00 00    	push   0x7e02(%rip)        # 9e28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 7e 00 00    	jmp    *0x7e04(%rip)        # 9e30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e 7c 00 00    	jmp    *0x7c7e(%rip)        # 9ff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae 7a 00 00    	jmp    *0x7aae(%rip)        # 9e38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 7a 00 00    	jmp    *0x7aa6(%rip)        # 9e40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e 7a 00 00    	jmp    *0x7a9e(%rip)        # 9e48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 7a 00 00    	jmp    *0x7a96(%rip)        # 9e50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e 7a 00 00    	jmp    *0x7a8e(%rip)        # 9e58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 7a 00 00    	jmp    *0x7a86(%rip)        # 9e60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e 7a 00 00    	jmp    *0x7a7e(%rip)        # 9e68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 7a 00 00    	jmp    *0x7a76(%rip)        # 9e70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e 7a 00 00    	jmp    *0x7a6e(%rip)        # 9e78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 7a 00 00    	jmp    *0x7a66(%rip)        # 9e80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e 7a 00 00    	jmp    *0x7a5e(%rip)        # 9e88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 7a 00 00    	jmp    *0x7a56(%rip)        # 9e90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e 7a 00 00    	jmp    *0x7a4e(%rip)        # 9e98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 7a 00 00    	jmp    *0x7a46(%rip)        # 9ea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e 7a 00 00    	jmp    *0x7a3e(%rip)        # 9ea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 7a 00 00    	jmp    *0x7a36(%rip)        # 9eb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e 7a 00 00    	jmp    *0x7a2e(%rip)        # 9eb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 7a 00 00    	jmp    *0x7a26(%rip)        # 9ec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e 7a 00 00    	jmp    *0x7a1e(%rip)        # 9ec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 7a 00 00    	jmp    *0x7a16(%rip)        # 9ed0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e 7a 00 00    	jmp    *0x7a0e(%rip)        # 9ed8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 7a 00 00    	jmp    *0x7a06(%rip)        # 9ee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe 79 00 00    	jmp    *0x79fe(%rip)        # 9ee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 79 00 00    	jmp    *0x79f6(%rip)        # 9ef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee 79 00 00    	jmp    *0x79ee(%rip)        # 9ef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 79 00 00    	jmp    *0x79e6(%rip)        # 9f00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de 79 00 00    	jmp    *0x79de(%rip)        # 9f08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 79 00 00    	jmp    *0x79d6(%rip)        # 9f10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce 79 00 00    	jmp    *0x79ce(%rip)        # 9f18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 79 00 00    	jmp    *0x79c6(%rip)        # 9f20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be 79 00 00    	jmp    *0x79be(%rip)        # 9f28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 79 00 00    	jmp    *0x79b6(%rip)        # 9f30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae 79 00 00    	jmp    *0x79ae(%rip)        # 9f38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 79 00 00    	jmp    *0x79a6(%rip)        # 9f40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e 79 00 00    	jmp    *0x799e(%rip)        # 9f48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 79 00 00    	jmp    *0x7996(%rip)        # 9f50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e 79 00 00    	jmp    *0x798e(%rip)        # 9f58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 79 00 00    	jmp    *0x7986(%rip)        # 9f60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e 79 00 00    	jmp    *0x797e(%rip)        # 9f68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 79 00 00    	jmp    *0x7976(%rip)        # 9f70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e 79 00 00    	jmp    *0x796e(%rip)        # 9f78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 79 00 00    	jmp    *0x7966(%rip)        # 9f80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e 79 00 00    	jmp    *0x795e(%rip)        # 9f88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 79 00 00    	jmp    *0x7956(%rip)        # 9f90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e 79 00 00    	jmp    *0x794e(%rip)        # 9f98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 79 00 00    	jmp    *0x7946(%rip)        # 9fa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e 79 00 00    	jmp    *0x793e(%rip)        # 9fa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 79 00 00    	jmp    *0x7936(%rip)        # 9fb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e 79 00 00    	jmp    *0x792e(%rip)        # 9fb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 79 00 00    	jmp    *0x7926(%rip)        # 9fc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e 79 00 00    	jmp    *0x791e(%rip)        # 9fc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 79 00 00    	jmp    *0x7916(%rip)        # 9fd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 59 00 00 	lea    0x59a0(%rip),%r9        # 8077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 59 00 00 	lea    0x599d(%rip),%r8        # 807b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 78 00 00 	mov    0x78e1(%rip),%rax        # a020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 f2 9b 01 00 	mov    %rax,0x19bf2(%rip)        # 1c338 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 5a 00 00 	lea    0x5a1c(%rip),%rdi        # 816e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 78 00 00 	mov    0x7866(%rip),%rdi        # a020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 3d 37 00 00 	lea    0x373d(%rip),%rdx        # 5f50 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d d1 77 00 00 	mov    0x77d1(%rip),%rdi        # a020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 78 01 00    	mov    0x17826(%rip),%eax        # 1a080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 58 00 00 	lea    0x58cc(%rip),%rdi        # 8177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 5a 00 00 	lea    0x5aec(%rip),%rdi        # 83a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d a6 5a 00 00 	lea    0x5aa6(%rip),%rdi        # 8380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 5a 00 00 	lea    0x5a6a(%rip),%rdi        # 8350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 5a 00 00 	lea    0x5a36(%rip),%rdi        # 8328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 76 00 00    	call   *0x76b3(%rip)        # 9fd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 76 00 00 	lea    0x76e1(%rip),%rdi        # a018 <__TMC_END__>
    2937:	48 8d 05 da 76 00 00 	lea    0x76da(%rip),%rax        # a018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 76 00 00 	mov    0x7696(%rip),%rax        # 9fe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 76 00 00 	lea    0x76b1(%rip),%rdi        # a018 <__TMC_END__>
    2967:	48 8d 35 aa 76 00 00 	lea    0x76aa(%rip),%rsi        # a018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 76 00 00 	mov    0x7665(%rip),%rax        # 9ff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d 76 00 00 00 	cmpb   $0x0,0x769d(%rip)        # a048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 76 00 00 	cmpq   $0x0,0x7642(%rip)        # 9ff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 76 00 00 	mov    0x7646(%rip),%rdi        # a008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 76 00 00 01 	movb   $0x1,0x7675(%rip)        # a048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d 71 97 01 00 	mov    0x19771(%rip),%rdi        # 1c338 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d 44 74 00 00 	mov    0x7444(%rip),%rdi        # a020 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 31 74 00 00 	mov    0x7431(%rip),%rdi        # a020 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 53 00 00 	lea    0x53f5(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 22 74 00 00 	mov    0x7422(%rip),%rcx        # a040 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 71 7a 01 00 	mov    0x17a71(%rip),%rax        # 1a6c0 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 c1 73 01 00 	mov    0x173c1(%rip),%rax        # 1a090 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 ad 73 01 00 	sub    0x173ad(%rip),%rax        # 1a088 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 57 00 00 	lea    0x572d(%rip),%rsi        # 8440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 8b 8d 01 00 	mov    0x18d8b(%rip),%rax        # 1bad0 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 84 8d 01 00 	lea    0x18d84(%rip),%r8        # 1bad0 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d 65 8d 01 00 	mov    0x18d65(%rip),%rbx        # 1bab8 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d 75 8d 01 00 	mov    0x18d75(%rip),%rcx        # 1bad8 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 11 8d 01 00 	mov    0x18d11(%rip),%rdi        # 1bac0 <fwp_heap+0x13e0>
    2daf:	48 29 35 5a 8d 01 00 	sub    %rsi,0x18d5a(%rip)        # 1bb10 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 ea 8c 01 00 	mov    0x18cea(%rip),%rax        # 1bab0 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d a0 8c 01 00 	add    0x18ca0(%rip),%rdi        # 1ba90 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 ae 8c 01 00 	mov    0x18cae(%rip),%rsi        # 1bac0 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 bc 8c 01 00 	mov    0x18cbc(%rip),%rax        # 1bad8 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 6b 8c 01 00 	mov    %r12,0x18c6b(%rip)        # 1bac0 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d 59 8c 01 00 	mov    %rbp,0x18c59(%rip)        # 1bab8 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 3e 8c 01 00 	cmp    %rdi,0x18c3e(%rip)        # 1baa8 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 35 8c 01 00 	mov    %rdi,0x18c35(%rip)        # 1baa8 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d 79 8c 01 00 	sub    %rdi,0x18c79(%rip)        # 1bb10 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 21 8c 01 00 	mov    0x18c21(%rip),%rax        # 1bac8 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 1a 8c 01 00 	lea    0x18c1a(%rip),%r8        # 1bac8 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d ed 70 00 00 	mov    0x70ed(%rip),%rcx        # a040 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 50 00 00 	lea    0x50a4(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d f9 76 01 00 	cmp    0x176f9(%rip),%rdi        # 1a6c0 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 bf 76 01 00 	mov    0x176bf(%rip),%rax        # 1a6a0 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d 9d 76 01 00 	mov    %rdi,0x1769d(%rip)        # 1a6a0 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d 79 76 01 00 	mov    %rdi,0x17679(%rip)        # 1a6a8 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 50 00 00 	lea    0x5051(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 4f 00 00 	lea    0x4f97(%rip),%rsi        # 801c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d 76 6f 00 00 	mov    0x6f76(%rip),%rdi        # a040 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 4f 00 00 	lea    0x4f4f(%rip),%rdx        # 8020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 4e 00 00 	lea    0x4ed0(%rip),%rdi        # 802f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 50 00 00 	lea    0x5030(%rip),%rdi        # 81a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 4e 00 00 	lea    0x4eb8(%rip),%r8        # 804b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 4d 00 00 	lea    0x4d0d(%rip),%r8        # 805a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 4b 00 00 	lea    0x4b9a(%rip),%r8        # 8050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 49 00 00 	lea    0x4972(%rip),%rdi        # 805f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 49 00 00 	lea    0x49fc(%rip),%rsi        # 810a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 25 83 01 00 	mov    0x18325(%rip),%r9        # 1baa8 <fwp_heap+0x13c8>
    3783:	4c 8b 05 7e 83 01 00 	mov    0x1837e(%rip),%r8        # 1bb08 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 4a 00 00 	lea    0x4a3f(%rip),%rdx        # 81d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d 66 83 01 00 	mov    0x18366(%rip),%rcx        # 1bb00 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d 74 83 01 	movsd  0x18374(%rip),%xmm1        # 1bb20 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 64 83 01 	movsd  0x18364(%rip),%xmm0        # 1bb18 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d 85 68 00 00 	mov    0x6885(%rip),%rdi        # a040 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 4c 00 	movdqa 0x4c68(%rip),%xmm0        # 8460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 1f 7e 01 00 	lea    0x17e1f(%rip),%rax        # 1b620 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 4c 00 	movdqa 0x4c91(%rip),%xmm2        # 84a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 c5 7d 01 00 	movaps %xmm0,0x17dc5(%rip)        # 1b5e0 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 4c 00 	movdqa 0x4c4d(%rip),%xmm0        # 8470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 53 82 01 00 01 	movl   $0x1,0x18253(%rip)        # 1ba84 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 b3 7d 01 00 	movaps %xmm0,0x17db3(%rip)        # 1b5f0 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 4c 00 	movdqa 0x4c3b(%rip),%xmm0        # 8480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 b4 7d 01 00 	movaps %xmm0,0x17db4(%rip)        # 1b600 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 4c 00 	movdqa 0x4c3c(%rip),%xmm0        # 8490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 b5 7d 01 00 	movaps %xmm0,0x17db5(%rip)        # 1b610 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 35 6e 01 00 	lea    0x16e35(%rip),%r8        # 1a6e0 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 50 81 01 00 	mov    %rax,0x18150(%rip)        # 1ba98 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 2e 81 01 00 	mov    %r12,0x1812e(%rip)        # 1baa0 <fwp_heap+0x13c0>
    3972:	48 89 05 17 81 01 00 	mov    %rax,0x18117(%rip)        # 1ba90 <fwp_heap+0x13b0>
    3979:	48 89 1d 30 81 01 00 	mov    %rbx,0x18130(%rip)        # 1bab0 <fwp_heap+0x13d0>
    3980:	48 89 35 59 81 01 00 	mov    %rsi,0x18159(%rip)        # 1bae0 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 46 00 00 	lea    0x46fc(%rip),%rdi        # 8095 <_IO_stdin_used+0x95>
    3999:	48 89 05 38 81 01 00 	mov    %rax,0x18138(%rip)        # 1bad8 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 bc 80 01 00    	mov    %eax,0x180bc(%rip)        # 1ba88 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 ac 6c 01 00 	mov    0x16cac(%rip),%r8        # 1a6a0 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d dc 6b 01 00 	mov    %rbx,0x16bdc(%rip)        # 1a6a8 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 c8 6b 01 00 	mov    %r8,0x16bc8(%rip)        # 1a6a0 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d 87 6b 01 00 	mov    0x16b87(%rip),%rbx        # 1a698 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 2a 64 00 00 	mov    0x642a(%rip),%rcx        # a040 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 46 00 00 	lea    0x463b(%rip),%rdi        # 8258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 4d 6a 01 00 	mov    0x16a4d(%rip),%rax        # 1a6a0 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 27 6a 01 00 	mov    %rdx,0x16a27(%rip)        # 1a6a0 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d 74 69 01 00 	mov    0x16974(%rip),%rbx        # 1a698 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 31 69 01 00 	mov    %rbx,0x16931(%rip)        # 1a698 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 31 69 01 00 	mov    %rdx,0x16931(%rip)        # 1a6a8 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 1e 69 01 00 	lea    0x1691e(%rip),%rcx        # 1a6e0 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 1f 85 01 00 	subq   $0x1,0x1851f(%rip)        # 1c328 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 44 00 00 	lea    0x4473(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 00 85 01 00 	cmpq   $0x0,0x18500(%rip)        # 1c328 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 55 84 01 00 	sub    %rax,0x18455(%rip)        # 1c330 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 33 84 01 00 	add    %r12,0x18433(%rip)        # 1c330 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 8f 7b 01 00 	mov    0x17b8f(%rip),%rax        # 1bad8 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 8c 67 01 00 	lea    0x1678c(%rip),%rax        # 1a6e0 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 e3 7a 01 00 	add    0x17ae3(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 b0 7a 01 00 	mov    0x17ab0(%rip),%rsi        # 1ba90 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 d1 7a 01 00 	mov    0x17ad1(%rip),%rax        # 1bab8 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 c5 7a 01 00 	add    0x17ac5(%rip),%r8        # 1bad8 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 8d 7a 01 	addsd  0x17a8d(%rip),%xmm0        # 1bb20 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 42 66 01 00 	lea    0x16642(%rip),%rax        # 1a6e0 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d 4c 7a 01 00 	sub    %rdi,0x17a4c(%rip)        # 1bb00 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 64 7a 01 	movsd  %xmm0,0x17a64(%rip)        # 1bb20 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 1e 7a 01 00 	sub    %rdx,0x17a1e(%rip)        # 1bb00 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 24 7a 01 	addsd  0x17a24(%rip),%xmm0        # 1bb20 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 18 7a 01 	movsd  %xmm0,0x17a18(%rip)        # 1bb20 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 af 79 01 00 	mov    0x179af(%rip),%rdx        # 1bad8 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d a9 79 01 00 	add    %rcx,0x179a9(%rip)        # 1bb10 <fwp_heap+0x1430>
    4167:	4c 3b 0d 62 79 01 00 	cmp    0x17962(%rip),%r9        # 1bad0 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d 59 79 01 00 	mov    %r9,0x17959(%rip)        # 1bad0 <fwp_heap+0x13f0>
    4177:	4c 3b 0d 4a 79 01 00 	cmp    0x1794a(%rip),%r9        # 1bac8 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 3d 79 01 00 	mov    %r9,0x1793d(%rip)        # 1bac8 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d 53 78 01 00 	add    0x17853(%rip),%rdi        # 1bad8 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 30 64 01 00 	lea    0x16430(%rip),%r15        # 1a6e0 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 a0 77 01 00 	add    0x177a0(%rip),%r12        # 1ba90 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 f9 77 01 00 	add    0x177f9(%rip),%rax        # 1bb00 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 f8 77 01 00 	cmp    %rax,0x177f8(%rip)        # 1bb08 <fwp_heap+0x1428>
    4310:	48 89 05 e9 77 01 00 	mov    %rax,0x177e9(%rip)        # 1bb00 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 e8 77 01 00 	mov    %rax,0x177e8(%rip)        # 1bb08 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 e4 77 01 	addsd  0x177e4(%rip),%xmm0        # 1bb18 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 dc 77 01 	movsd  %xmm0,0x177dc(%rip)        # 1bb18 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 23 77 01 00    	mov    0x17723(%rip),%eax        # 1ba84 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d 5f 63 01 00 	lea    0x1635f(%rip),%rdi        # 1a6e0 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 18 77 01 00 	add    0x17718(%rip),%rax        # 1bb00 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 13 77 01 00 	cmp    %rax,0x17713(%rip)        # 1bb08 <fwp_heap+0x1428>
    43f5:	48 89 05 04 77 01 00 	mov    %rax,0x17704(%rip)        # 1bb00 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 03 77 01 00 	mov    %rax,0x17703(%rip)        # 1bb08 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 ff 76 01 	addsd  0x176ff(%rip),%xmm0        # 1bb18 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 f7 76 01 	movsd  %xmm0,0x176f7(%rip)        # 1bb18 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_free_arr>:
    44d0:	48 8b 15 e1 75 01 00 	mov    0x175e1(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 2b 05 af 75 01 00 	sub    0x175af(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    44e1:	48 c1 e2 10          	shl    $0x10,%rdx
    44e5:	48 39 d0             	cmp    %rdx,%rax
    44e8:	73 5b                	jae    4545 <fwp_rc_free_arr+0x75>
    44ea:	48 89 c2             	mov    %rax,%rdx
    44ed:	48 c1 ea 10          	shr    $0x10,%rdx
    44f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f5:	48 8b 15 dc 75 01 00 	mov    0x175dc(%rip),%rdx        # 1bad8 <fwp_heap+0x13f8>
    44fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4500:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4504:	48 85 c9             	test   %rcx,%rcx
    4507:	74 3c                	je     4545 <fwp_rc_free_arr+0x75>
    4509:	0f b6 32             	movzbl (%rdx),%esi
    450c:	40 80 fe 02          	cmp    $0x2,%sil
    4510:	74 2e                	je     4540 <fwp_rc_free_arr+0x70>
    4512:	40 80 fe 01          	cmp    $0x1,%sil
    4516:	75 2d                	jne    4545 <fwp_rc_free_arr+0x75>
    4518:	8b 72 18             	mov    0x18(%rdx),%esi
    451b:	0f b7 c0             	movzwl %ax,%eax
    451e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4521:	48 0f af c6          	imul   %rsi,%rax
    4525:	48 c1 e8 20          	shr    $0x20,%rax
    4529:	48 39 d0             	cmp    %rdx,%rax
    452c:	73 17                	jae    4545 <fwp_rc_free_arr+0x75>
    452e:	48 01 c1             	add    %rax,%rcx
    4531:	80 39 01             	cmpb   $0x1,(%rcx)
    4534:	75 0f                	jne    4545 <fwp_rc_free_arr+0x75>
    4536:	e9 95 fa ff ff       	jmp    3fd0 <fwp_mem_free>
    453b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ec                	je     4531 <fwp_rc_free_arr+0x61>
    4545:	c3                   	ret
    4546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    454d:	00 00 00 

0000000000004550 <fwp_heap_alloc>:
    4550:	8b 05 2e 75 01 00    	mov    0x1752e(%rip),%eax        # 1ba84 <fwp_heap+0x13a4>
    4556:	48 89 fa             	mov    %rdi,%rdx
    4559:	89 f7                	mov    %esi,%edi
    455b:	85 c0                	test   %eax,%eax
    455d:	0f 84 f5 00 00 00    	je     4658 <fwp_heap_alloc+0x108>
    4563:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    456a:	0f 87 e8 00 00 00    	ja     4658 <fwp_heap_alloc+0x108>
    4570:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4574:	48 8d 05 65 61 01 00 	lea    0x16165(%rip),%rax        # 1a6e0 <fwp_heap>
    457b:	48 83 ec 18          	sub    $0x18,%rsp
    457f:	41 89 f0             	mov    %esi,%r8d
    4582:	48 c1 e9 04          	shr    $0x4,%rcx
    4586:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    458d:	00 
    458e:	48 63 cf             	movslq %edi,%rcx
    4591:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4598:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    459f:	00 
    45a0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    45a4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    45a8:	48 01 c8             	add    %rcx,%rax
    45ab:	48 8b 08             	mov    (%rax),%rcx
    45ae:	48 85 c9             	test   %rcx,%rcx
    45b1:	74 6d                	je     4620 <fwp_heap_alloc+0xd0>
    45b3:	48 8b 31             	mov    (%rcx),%rsi
    45b6:	48 f7 d6             	not    %rsi
    45b9:	48 89 30             	mov    %rsi,(%rax)
    45bc:	41 83 f8 01          	cmp    $0x1,%r8d
    45c0:	48 89 cf             	mov    %rcx,%rdi
    45c3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45c8:	49 0f 45 d1          	cmovne %r9,%rdx
    45cc:	31 f6                	xor    %esi,%esi
    45ce:	e8 cd de ff ff       	call   24a0 <memset@plt>
    45d3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    45d8:	48 89 c1             	mov    %rax,%rcx
    45db:	4c 89 c8             	mov    %r9,%rax
    45de:	48 03 05 1b 75 01 00 	add    0x1751b(%rip),%rax        # 1bb00 <fwp_heap+0x1420>
    45e5:	72 7b                	jb     4662 <fwp_heap_alloc+0x112>
    45e7:	48 39 05 1a 75 01 00 	cmp    %rax,0x1751a(%rip)        # 1bb08 <fwp_heap+0x1428>
    45ee:	48 89 05 0b 75 01 00 	mov    %rax,0x1750b(%rip)        # 1bb00 <fwp_heap+0x1420>
    45f5:	73 07                	jae    45fe <fwp_heap_alloc+0xae>
    45f7:	48 89 05 0a 75 01 00 	mov    %rax,0x1750a(%rip)        # 1bb08 <fwp_heap+0x1428>
    45fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4602:	48 89 c8             	mov    %rcx,%rax
    4605:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    460a:	f2 0f 58 05 06 75 01 	addsd  0x17506(%rip),%xmm0        # 1bb18 <fwp_heap+0x1438>
    4611:	00 
    4612:	f2 0f 11 05 fe 74 01 	movsd  %xmm0,0x174fe(%rip)        # 1bb18 <fwp_heap+0x1438>
    4619:	00 
    461a:	48 83 c4 18          	add    $0x18,%rsp
    461e:	c3                   	ret
    461f:	90                   	nop
    4620:	48 8b 48 08          	mov    0x8(%rax),%rcx
    4624:	48 85 c9             	test   %rcx,%rcx
    4627:	74 0c                	je     4635 <fwp_heap_alloc+0xe5>
    4629:	48 8b 70 10          	mov    0x10(%rax),%rsi
    462d:	48 29 ce             	sub    %rcx,%rsi
    4630:	4c 39 ce             	cmp    %r9,%rsi
    4633:	73 13                	jae    4648 <fwp_heap_alloc+0xf8>
    4635:	89 fe                	mov    %edi,%esi
    4637:	48 83 c4 18          	add    $0x18,%rsp
    463b:	48 89 d7             	mov    %rdx,%rdi
    463e:	e9 0d fd ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4643:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4648:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    464c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4650:	e9 67 ff ff ff       	jmp    45bc <fwp_heap_alloc+0x6c>
    4655:	0f 1f 00             	nopl   (%rax)
    4658:	89 fe                	mov    %edi,%esi
    465a:	48 89 d7             	mov    %rdx,%rdi
    465d:	e9 ee fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4662:	e8 99 e5 ff ff       	call   2c00 <fwp_heap_oom>
    4667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    466e:	00 00 

0000000000004670 <fwp_data.part.0.constprop.0>:
    4670:	41 56                	push   %r14
    4672:	41 89 fe             	mov    %edi,%r14d
    4675:	41 54                	push   %r12
    4677:	49 89 f4             	mov    %rsi,%r12
    467a:	55                   	push   %rbp
    467b:	53                   	push   %rbx
    467c:	48 83 ec 08          	sub    $0x8,%rsp
    4680:	8b 05 fe 73 01 00    	mov    0x173fe(%rip),%eax        # 1ba84 <fwp_heap+0x13a4>
    4686:	85 c0                	test   %eax,%eax
    4688:	0f 84 fa 00 00 00    	je     4788 <fwp_data.part.0.constprop.0+0x118>
    468e:	0f b6 05 ed 6f 01 00 	movzbl 0x16fed(%rip),%eax        # 1b682 <fwp_heap+0xfa2>
    4695:	48 8d 15 44 60 01 00 	lea    0x16044(%rip),%rdx        # 1a6e0 <fwp_heap>
    469c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    46a3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    46a7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    46ab:	48 8b 18             	mov    (%rax),%rbx
    46ae:	48 85 db             	test   %rbx,%rbx
    46b1:	0f 84 a9 00 00 00    	je     4760 <fwp_data.part.0.constprop.0+0xf0>
    46b7:	48 8b 13             	mov    (%rbx),%rdx
    46ba:	48 f7 d2             	not    %rdx
    46bd:	48 89 10             	mov    %rdx,(%rax)
    46c0:	48 83 fd 18          	cmp    $0x18,%rbp
    46c4:	76 1b                	jbe    46e1 <fwp_data.part.0.constprop.0+0x71>
    46c6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    46ca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    46ce:	31 f6                	xor    %esi,%esi
    46d0:	48 c1 e8 03          	shr    $0x3,%rax
    46d4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    46db:	00 
    46dc:	e8 bf dd ff ff       	call   24a0 <memset@plt>
    46e1:	48 89 e8             	mov    %rbp,%rax
    46e4:	48 03 05 15 74 01 00 	add    0x17415(%rip),%rax        # 1bb00 <fwp_heap+0x1420>
    46eb:	0f 82 a8 00 00 00    	jb     4799 <fwp_data.part.0.constprop.0+0x129>
    46f1:	48 39 05 10 74 01 00 	cmp    %rax,0x17410(%rip)        # 1bb08 <fwp_heap+0x1428>
    46f8:	48 89 05 01 74 01 00 	mov    %rax,0x17401(%rip)        # 1bb00 <fwp_heap+0x1420>
    46ff:	73 07                	jae    4708 <fwp_data.part.0.constprop.0+0x98>
    4701:	48 89 05 00 74 01 00 	mov    %rax,0x17400(%rip)        # 1bb08 <fwp_heap+0x1428>
    4708:	66 0f ef c0          	pxor   %xmm0,%xmm0
    470c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    4711:	f2 0f 58 05 ff 73 01 	addsd  0x173ff(%rip),%xmm0        # 1bb18 <fwp_heap+0x1438>
    4718:	00 
    4719:	f2 0f 11 05 f7 73 01 	movsd  %xmm0,0x173f7(%rip)        # 1bb18 <fwp_heap+0x1438>
    4720:	00 
    4721:	b8 02 00 00 00       	mov    $0x2,%eax
    4726:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    472b:	66 0f 6e c8          	movd   %eax,%xmm1
    472f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    4733:	66 0f d6 03          	movq   %xmm0,(%rbx)
    4737:	49 8b 04 24          	mov    (%r12),%rax
    473b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    473f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    4744:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4748:	48 83 c4 08          	add    $0x8,%rsp
    474c:	48 89 d8             	mov    %rbx,%rax
    474f:	5b                   	pop    %rbx
    4750:	5d                   	pop    %rbp
    4751:	41 5c                	pop    %r12
    4753:	41 5e                	pop    %r14
    4755:	c3                   	ret
    4756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    475d:	00 00 00 
    4760:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4764:	48 85 db             	test   %rbx,%rbx
    4767:	74 1f                	je     4788 <fwp_data.part.0.constprop.0+0x118>
    4769:	48 8b 50 10          	mov    0x10(%rax),%rdx
    476d:	48 29 da             	sub    %rbx,%rdx
    4770:	48 39 ea             	cmp    %rbp,%rdx
    4773:	72 13                	jb     4788 <fwp_data.part.0.constprop.0+0x118>
    4775:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4779:	48 89 50 08          	mov    %rdx,0x8(%rax)
    477d:	e9 3e ff ff ff       	jmp    46c0 <fwp_data.part.0.constprop.0+0x50>
    4782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4788:	31 f6                	xor    %esi,%esi
    478a:	bf 18 00 00 00       	mov    $0x18,%edi
    478f:	e8 bc fd ff ff       	call   4550 <fwp_heap_alloc>
    4794:	48 89 c3             	mov    %rax,%rbx
    4797:	eb 88                	jmp    4721 <fwp_data.part.0.constprop.0+0xb1>
    4799:	e8 62 e4 ff ff       	call   2c00 <fwp_heap_oom>
    479e:	66 90                	xchg   %ax,%ax

00000000000047a0 <fwp_array_new_packed.constprop.0>:
    47a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    47a7:	ff ff 1f 
    47aa:	53                   	push   %rbx
    47ab:	48 39 f8             	cmp    %rdi,%rax
    47ae:	72 1a                	jb     47ca <fwp_array_new_packed.constprop.0+0x2a>
    47b0:	48 89 fb             	mov    %rdi,%rbx
    47b3:	be 01 00 00 00       	mov    $0x1,%esi
    47b8:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    47bf:	00 
    47c0:	e8 8b fd ff ff       	call   4550 <fwp_heap_alloc>
    47c5:	48 89 18             	mov    %rbx,(%rax)
    47c8:	5b                   	pop    %rbx
    47c9:	c3                   	ret
    47ca:	48 8d 3d d4 38 00 00 	lea    0x38d4(%rip),%rdi        # 80a5 <_IO_stdin_used+0xa5>
    47d1:	e8 da e8 ff ff       	call   30b0 <fwp_trap>
    47d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    47dd:	00 00 00 

00000000000047e0 <fwp_task_dispose>:
    47e0:	53                   	push   %rbx
    47e1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    47e5:	0f 84 1b df ff ff    	je     2706 <fwp_task_dispose.cold>
    47eb:	48 89 fb             	mov    %rdi,%rbx
    47ee:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    47f3:	0f 85 0d df ff ff    	jne    2706 <fwp_task_dispose.cold>
    47f9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    47fd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4804:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    480b:	00 
    480c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4810:	48 85 ff             	test   %rdi,%rdi
    4813:	74 07                	je     481c <fwp_task_dispose+0x3c>
    4815:	48 85 c0             	test   %rax,%rax
    4818:	74 02                	je     481c <fwp_task_dispose+0x3c>
    481a:	ff d0                	call   *%rax
    481c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4823:	e8 a8 f7 ff ff       	call   3fd0 <fwp_mem_free>
    4828:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    482f:	00 00 00 00 
    4833:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4837:	74 6f                	je     48a8 <fwp_task_dispose+0xc8>
    4839:	48 8b 15 78 72 01 00 	mov    0x17278(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    4840:	48 89 d8             	mov    %rbx,%rax
    4843:	48 2b 05 46 72 01 00 	sub    0x17246(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    484a:	48 c1 e2 10          	shl    $0x10,%rdx
    484e:	48 39 d0             	cmp    %rdx,%rax
    4851:	73 4c                	jae    489f <fwp_task_dispose+0xbf>
    4853:	48 89 c2             	mov    %rax,%rdx
    4856:	48 c1 ea 10          	shr    $0x10,%rdx
    485a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    485e:	48 8b 15 73 72 01 00 	mov    0x17273(%rip),%rdx        # 1bad8 <fwp_heap+0x13f8>
    4865:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4869:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    486d:	48 85 c9             	test   %rcx,%rcx
    4870:	74 2d                	je     489f <fwp_task_dispose+0xbf>
    4872:	0f b6 32             	movzbl (%rdx),%esi
    4875:	40 80 fe 02          	cmp    $0x2,%sil
    4879:	74 3d                	je     48b8 <fwp_task_dispose+0xd8>
    487b:	40 80 fe 01          	cmp    $0x1,%sil
    487f:	75 1e                	jne    489f <fwp_task_dispose+0xbf>
    4881:	8b 72 18             	mov    0x18(%rdx),%esi
    4884:	0f b7 c0             	movzwl %ax,%eax
    4887:	8b 52 1c             	mov    0x1c(%rdx),%edx
    488a:	48 0f af c6          	imul   %rsi,%rax
    488e:	48 c1 e8 20          	shr    $0x20,%rax
    4892:	48 39 d0             	cmp    %rdx,%rax
    4895:	73 08                	jae    489f <fwp_task_dispose+0xbf>
    4897:	48 01 c1             	add    %rax,%rcx
    489a:	80 39 01             	cmpb   $0x1,(%rcx)
    489d:	74 09                	je     48a8 <fwp_task_dispose+0xc8>
    489f:	5b                   	pop    %rbx
    48a0:	c3                   	ret
    48a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48a8:	48 89 df             	mov    %rbx,%rdi
    48ab:	5b                   	pop    %rbx
    48ac:	e9 1f f7 ff ff       	jmp    3fd0 <fwp_mem_free>
    48b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48b8:	66 85 c0             	test   %ax,%ax
    48bb:	74 dd                	je     489a <fwp_task_dispose+0xba>
    48bd:	5b                   	pop    %rbx
    48be:	c3                   	ret
    48bf:	90                   	nop

00000000000048c0 <fwp_free_zombie>:
    48c0:	48 8b 15 e9 5d 01 00 	mov    0x15de9(%rip),%rdx        # 1a6b0 <fwp_zombie>
    48c7:	48 85 d2             	test   %rdx,%rdx
    48ca:	0f 84 98 00 00 00    	je     4968 <fwp_free_zombie+0xa8>
    48d0:	48 3b 15 e9 5d 01 00 	cmp    0x15de9(%rip),%rdx        # 1a6c0 <fwp_cur>
    48d7:	0f 84 8b 00 00 00    	je     4968 <fwp_free_zombie+0xa8>
    48dd:	48 83 ec 18          	sub    $0x18,%rsp
    48e1:	48 63 05 b4 57 01 00 	movslq 0x157b4(%rip),%rax        # 1a09c <fwp_stack_pool_n>
    48e8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    48ec:	83 f8 3f             	cmp    $0x3f,%eax
    48ef:	7f 7f                	jg     4970 <fwp_free_zombie+0xb0>
    48f1:	8d 48 01             	lea    0x1(%rax),%ecx
    48f4:	89 0d a2 57 01 00    	mov    %ecx,0x157a2(%rip)        # 1a09c <fwp_stack_pool_n>
    48fa:	48 8d 0d 9f 57 01 00 	lea    0x1579f(%rip),%rcx        # 1a0a0 <fwp_stack_pool>
    4901:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4905:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    490c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4910:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4917:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    491b:	48 85 c9             	test   %rcx,%rcx
    491e:	0f 84 fc 00 00 00    	je     4a20 <fwp_free_zombie+0x160>
    4924:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    492b:	48 85 c0             	test   %rax,%rax
    492e:	74 07                	je     4937 <fwp_free_zombie+0x77>
    4930:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4937:	8b 42 5c             	mov    0x5c(%rdx),%eax
    493a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    493e:	48 c7 05 67 5d 01 00 	movq   $0x0,0x15d67(%rip)        # 1a6b0 <fwp_zombie>
    4945:	00 00 00 00 
    4949:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4950:	85 c0                	test   %eax,%eax
    4952:	74 34                	je     4988 <fwp_free_zombie+0xc8>
    4954:	83 f8 01             	cmp    $0x1,%eax
    4957:	0f 84 b3 00 00 00    	je     4a10 <fwp_free_zombie+0x150>
    495d:	48 83 c4 18          	add    $0x18,%rsp
    4961:	c3                   	ret
    4962:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4968:	c3                   	ret
    4969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4970:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4974:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4979:	e8 32 dc ff ff       	call   25b0 <munmap@plt>
    497e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4983:	eb 80                	jmp    4905 <fwp_free_zombie+0x45>
    4985:	0f 1f 00             	nopl   (%rax)
    4988:	48 8b 0d 29 71 01 00 	mov    0x17129(%rip),%rcx        # 1bab8 <fwp_heap+0x13d8>
    498f:	48 89 d0             	mov    %rdx,%rax
    4992:	48 2b 05 f7 70 01 00 	sub    0x170f7(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    4999:	48 c1 e1 10          	shl    $0x10,%rcx
    499d:	48 39 c8             	cmp    %rcx,%rax
    49a0:	73 bb                	jae    495d <fwp_free_zombie+0x9d>
    49a2:	48 89 c1             	mov    %rax,%rcx
    49a5:	48 c1 e9 10          	shr    $0x10,%rcx
    49a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    49ad:	48 8b 0d 24 71 01 00 	mov    0x17124(%rip),%rcx        # 1bad8 <fwp_heap+0x13f8>
    49b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    49b8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    49bc:	48 85 c9             	test   %rcx,%rcx
    49bf:	74 9c                	je     495d <fwp_free_zombie+0x9d>
    49c1:	0f b6 3e             	movzbl (%rsi),%edi
    49c4:	40 80 ff 02          	cmp    $0x2,%dil
    49c8:	74 66                	je     4a30 <fwp_free_zombie+0x170>
    49ca:	40 80 ff 01          	cmp    $0x1,%dil
    49ce:	75 8d                	jne    495d <fwp_free_zombie+0x9d>
    49d0:	8b 7e 18             	mov    0x18(%rsi),%edi
    49d3:	0f b7 c0             	movzwl %ax,%eax
    49d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    49d9:	48 0f af c7          	imul   %rdi,%rax
    49dd:	48 c1 e8 20          	shr    $0x20,%rax
    49e1:	48 39 f0             	cmp    %rsi,%rax
    49e4:	0f 83 73 ff ff ff    	jae    495d <fwp_free_zombie+0x9d>
    49ea:	48 01 c1             	add    %rax,%rcx
    49ed:	0f b6 01             	movzbl (%rcx),%eax
    49f0:	84 c0                	test   %al,%al
    49f2:	0f 84 65 ff ff ff    	je     495d <fwp_free_zombie+0x9d>
    49f8:	3c 01                	cmp    $0x1,%al
    49fa:	74 14                	je     4a10 <fwp_free_zombie+0x150>
    49fc:	3c ff                	cmp    $0xff,%al
    49fe:	74 3b                	je     4a3b <fwp_free_zombie+0x17b>
    4a00:	83 e8 01             	sub    $0x1,%eax
    4a03:	88 01                	mov    %al,(%rcx)
    4a05:	e9 53 ff ff ff       	jmp    495d <fwp_free_zombie+0x9d>
    4a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a10:	48 89 d7             	mov    %rdx,%rdi
    4a13:	48 83 c4 18          	add    $0x18,%rsp
    4a17:	e9 c4 fd ff ff       	jmp    47e0 <fwp_task_dispose>
    4a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a20:	48 89 05 61 5c 01 00 	mov    %rax,0x15c61(%rip)        # 1a688 <fwp_tasks_active>
    4a27:	e9 ff fe ff ff       	jmp    492b <fwp_free_zombie+0x6b>
    4a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a30:	66 85 c0             	test   %ax,%ax
    4a33:	0f 85 24 ff ff ff    	jne    495d <fwp_free_zombie+0x9d>
    4a39:	eb b2                	jmp    49ed <fwp_free_zombie+0x12d>
    4a3b:	48 89 ca             	mov    %rcx,%rdx
    4a3e:	48 8d 35 9b 5c 01 00 	lea    0x15c9b(%rip),%rsi        # 1a6e0 <fwp_heap>
    4a45:	48 c1 ea 11          	shr    $0x11,%rdx
    4a49:	48 31 ca             	xor    %rcx,%rdx
    4a4c:	48 89 d0             	mov    %rdx,%rax
    4a4f:	48 c1 e8 09          	shr    $0x9,%rax
    4a53:	48 31 c2             	xor    %rax,%rdx
    4a56:	0f b6 d2             	movzbl %dl,%edx
    4a59:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4a60:	00 
    4a61:	48 85 c0             	test   %rax,%rax
    4a64:	75 23                	jne    4a89 <fwp_free_zombie+0x1c9>
    4a66:	eb 5c                	jmp    4ac4 <fwp_free_zombie+0x204>
    4a68:	66 90                	xchg   %ax,%ax
    4a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a71:	00 00 00 00 
    4a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a7c:	00 00 00 00 
    4a80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4a84:	48 85 c0             	test   %rax,%rax
    4a87:	74 3b                	je     4ac4 <fwp_free_zombie+0x204>
    4a89:	48 89 c2             	mov    %rax,%rdx
    4a8c:	48 39 08             	cmp    %rcx,(%rax)
    4a8f:	75 ef                	jne    4a80 <fwp_free_zombie+0x1c0>
    4a91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4a95:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4a99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4a9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4aa4:	0f 85 b3 fe ff ff    	jne    495d <fwp_free_zombie+0x9d>
    4aaa:	48 89 cf             	mov    %rcx,%rdi
    4aad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4ab2:	e8 d9 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4ab7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4abc:	c6 01 fe             	movb   $0xfe,(%rcx)
    4abf:	e9 99 fe ff ff       	jmp    495d <fwp_free_zombie+0x9d>
    4ac4:	48 8d 3d bd 37 00 00 	lea    0x37bd(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4acb:	e8 e0 e5 ff ff       	call   30b0 <fwp_trap>

0000000000004ad0 <fwp_block>:
    4ad0:	48 83 ec 08          	sub    $0x8,%rsp
    4ad4:	48 8b 05 cd 5b 01 00 	mov    0x15bcd(%rip),%rax        # 1a6a8 <fwp_ready_head>
    4adb:	48 85 c0             	test   %rax,%rax
    4ade:	0f 84 1c 01 00 00    	je     4c00 <fwp_block+0x130>
    4ae4:	90                   	nop
    4ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4aec:	00 00 00 00 
    4af0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4af7:	48 89 15 aa 5b 01 00 	mov    %rdx,0x15baa(%rip)        # 1a6a8 <fwp_ready_head>
    4afe:	48 85 d2             	test   %rdx,%rdx
    4b01:	0f 84 19 01 00 00    	je     4c20 <fwp_block+0x150>
    4b07:	48 8b 15 b2 5b 01 00 	mov    0x15bb2(%rip),%rdx        # 1a6c0 <fwp_cur>
    4b0e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b12:	48 39 c2             	cmp    %rax,%rdx
    4b15:	0f 84 d5 00 00 00    	je     4bf0 <fwp_block+0x120>
    4b1b:	48 8b 0d 1e 78 01 00 	mov    0x1781e(%rip),%rcx        # 1c340 <fwp_state_owners>
    4b22:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4b26:	48 89 05 93 5b 01 00 	mov    %rax,0x15b93(%rip)        # 1a6c0 <fwp_cur>
    4b2d:	f3 0f 7e 05 33 78 01 	movq   0x17833(%rip),%xmm0        # 1c368 <fwp_foreign_callbacks>
    4b34:	00 
    4b35:	0f 16 05 1c 78 01 00 	movhps 0x1781c(%rip),%xmm0        # 1c358 <fwp_state>
    4b3c:	f3 0f 7e 0d 1c 78 01 	movq   0x1781c(%rip),%xmm1        # 1c360 <fwp_handlers>
    4b43:	00 
    4b44:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4b4b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4b52:	0f 16 0d 17 78 01 00 	movhps 0x17817(%rip),%xmm1        # 1c370 <fwp_cleanups>
    4b59:	f3 0f 7e 05 ef 77 01 	movq   0x177ef(%rip),%xmm0        # 1c350 <fwp_state_len>
    4b60:	00 
    4b61:	0f 16 05 e0 77 01 00 	movhps 0x177e0(%rip),%xmm0        # 1c348 <fwp_state_cap>
    4b68:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4b6f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4b76:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b7a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4b81:	48 89 0d d8 77 01 00 	mov    %rcx,0x177d8(%rip)        # 1c360 <fwp_handlers>
    4b88:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4b8f:	48 89 0d da 77 01 00 	mov    %rcx,0x177da(%rip)        # 1c370 <fwp_cleanups>
    4b96:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4b9d:	48 89 0d c4 77 01 00 	mov    %rcx,0x177c4(%rip)        # 1c368 <fwp_foreign_callbacks>
    4ba4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4bab:	48 89 0d a6 77 01 00 	mov    %rcx,0x177a6(%rip)        # 1c358 <fwp_state>
    4bb2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4bb9:	48 89 0d 90 77 01 00 	mov    %rcx,0x17790(%rip)        # 1c350 <fwp_state_len>
    4bc0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4bc7:	48 89 0d 7a 77 01 00 	mov    %rcx,0x1777a(%rip)        # 1c348 <fwp_state_cap>
    4bce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4bd5:	48 89 0d 64 77 01 00 	mov    %rcx,0x17764(%rip)        # 1c340 <fwp_state_owners>
    4bdc:	e8 8f d8 ff ff       	call   2470 <swapcontext@plt>
    4be1:	f3 0f 1e fa          	endbr64
    4be5:	e8 d6 fc ff ff       	call   48c0 <fwp_free_zombie>
    4bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4bf0:	8b 05 a2 54 01 00    	mov    0x154a2(%rip),%eax        # 1a098 <fwp_slice>
    4bf6:	85 c0                	test   %eax,%eax
    4bf8:	74 36                	je     4c30 <fwp_block+0x160>
    4bfa:	48 83 c4 08          	add    $0x8,%rsp
    4bfe:	c3                   	ret
    4bff:	90                   	nop
    4c00:	e8 eb ee ff ff       	call   3af0 <fwp_poll_events>
    4c05:	48 8b 05 9c 5a 01 00 	mov    0x15a9c(%rip),%rax        # 1a6a8 <fwp_ready_head>
    4c0c:	48 85 c0             	test   %rax,%rax
    4c0f:	0f 85 db fe ff ff    	jne    4af0 <fwp_block+0x20>
    4c15:	eb e9                	jmp    4c00 <fwp_block+0x130>
    4c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c1e:	00 00 
    4c20:	48 c7 05 75 5a 01 00 	movq   $0x0,0x15a75(%rip)        # 1a6a0 <fwp_ready_tail>
    4c27:	00 00 00 00 
    4c2b:	e9 d7 fe ff ff       	jmp    4b07 <fwp_block+0x37>
    4c30:	48 8d 3d 7e 34 00 00 	lea    0x347e(%rip),%rdi        # 80b5 <_IO_stdin_used+0xb5>
    4c37:	e8 44 d7 ff ff       	call   2380 <getenv@plt>
    4c3c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4c41:	48 85 c0             	test   %rax,%rax
    4c44:	74 05                	je     4c4b <fwp_block+0x17b>
    4c46:	80 38 00             	cmpb   $0x0,(%rax)
    4c49:	75 0b                	jne    4c56 <fwp_block+0x186>
    4c4b:	89 15 47 54 01 00    	mov    %edx,0x15447(%rip)        # 1a098 <fwp_slice>
    4c51:	48 83 c4 08          	add    $0x8,%rsp
    4c55:	c3                   	ret
    4c56:	ba 0a 00 00 00       	mov    $0xa,%edx
    4c5b:	31 f6                	xor    %esi,%esi
    4c5d:	48 89 c7             	mov    %rax,%rdi
    4c60:	e8 cb d8 ff ff       	call   2530 <strtoll@plt>
    4c65:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4c69:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4c70:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4c75:	0f 46 d0             	cmovbe %eax,%edx
    4c78:	eb d1                	jmp    4c4b <fwp_block+0x17b>
    4c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004c80 <fwp_drop0>:
    4c80:	48 8b 15 31 6e 01 00 	mov    0x16e31(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    4c87:	48 89 f8             	mov    %rdi,%rax
    4c8a:	48 2b 05 ff 6d 01 00 	sub    0x16dff(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    4c91:	48 c1 e2 10          	shl    $0x10,%rdx
    4c95:	48 39 d0             	cmp    %rdx,%rax
    4c98:	0f 83 c2 00 00 00    	jae    4d60 <fwp_drop0+0xe0>
    4c9e:	48 83 ec 18          	sub    $0x18,%rsp
    4ca2:	4c 8d 05 37 5a 01 00 	lea    0x15a37(%rip),%r8        # 1a6e0 <fwp_heap>
    4ca9:	48 89 c2             	mov    %rax,%rdx
    4cac:	48 c1 ea 10          	shr    $0x10,%rdx
    4cb0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4cb4:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4cbb:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4cbf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4cc3:	48 85 d2             	test   %rdx,%rdx
    4cc6:	74 3c                	je     4d04 <fwp_drop0+0x84>
    4cc8:	0f b6 31             	movzbl (%rcx),%esi
    4ccb:	40 80 fe 02          	cmp    $0x2,%sil
    4ccf:	74 3f                	je     4d10 <fwp_drop0+0x90>
    4cd1:	40 80 fe 01          	cmp    $0x1,%sil
    4cd5:	75 2d                	jne    4d04 <fwp_drop0+0x84>
    4cd7:	8b 71 18             	mov    0x18(%rcx),%esi
    4cda:	0f b7 c0             	movzwl %ax,%eax
    4cdd:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4ce0:	48 0f af c6          	imul   %rsi,%rax
    4ce4:	48 c1 e8 20          	shr    $0x20,%rax
    4ce8:	48 39 c8             	cmp    %rcx,%rax
    4ceb:	73 17                	jae    4d04 <fwp_drop0+0x84>
    4ced:	48 01 c2             	add    %rax,%rdx
    4cf0:	0f b6 02             	movzbl (%rdx),%eax
    4cf3:	84 c0                	test   %al,%al
    4cf5:	74 0d                	je     4d04 <fwp_drop0+0x84>
    4cf7:	3c 01                	cmp    $0x1,%al
    4cf9:	74 25                	je     4d20 <fwp_drop0+0xa0>
    4cfb:	3c ff                	cmp    $0xff,%al
    4cfd:	74 69                	je     4d68 <fwp_drop0+0xe8>
    4cff:	83 e8 01             	sub    $0x1,%eax
    4d02:	88 02                	mov    %al,(%rdx)
    4d04:	48 83 c4 18          	add    $0x18,%rsp
    4d08:	c3                   	ret
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	66 85 c0             	test   %ax,%ax
    4d13:	74 db                	je     4cf0 <fwp_drop0+0x70>
    4d15:	48 83 c4 18          	add    $0x18,%rsp
    4d19:	c3                   	ret
    4d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d20:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4d24:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4d29:	e8 a2 f7 ff ff       	call   44d0 <fwp_rc_free_arr>
    4d2e:	4c 8d 05 ab 59 01 00 	lea    0x159ab(%rip),%r8        # 1a6e0 <fwp_heap>
    4d35:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4d3a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4d41:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4d48:	48 c1 e2 10          	shl    $0x10,%rdx
    4d4c:	48 39 d0             	cmp    %rdx,%rax
    4d4f:	73 b3                	jae    4d04 <fwp_drop0+0x84>
    4d51:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4d56:	e9 4e ff ff ff       	jmp    4ca9 <fwp_drop0+0x29>
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	c3                   	ret
    4d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d68:	48 89 d0             	mov    %rdx,%rax
    4d6b:	48 c1 e8 11          	shr    $0x11,%rax
    4d6f:	48 31 d0             	xor    %rdx,%rax
    4d72:	48 89 c1             	mov    %rax,%rcx
    4d75:	48 c1 e9 09          	shr    $0x9,%rcx
    4d79:	48 31 c8             	xor    %rcx,%rax
    4d7c:	0f b6 c8             	movzbl %al,%ecx
    4d7f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4d86:	00 
    4d87:	48 85 c0             	test   %rax,%rax
    4d8a:	75 1d                	jne    4da9 <fwp_drop0+0x129>
    4d8c:	eb 56                	jmp    4de4 <fwp_drop0+0x164>
    4d8e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4d9c:	00 00 00 00 
    4da0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4da4:	48 85 c0             	test   %rax,%rax
    4da7:	74 3b                	je     4de4 <fwp_drop0+0x164>
    4da9:	48 89 c1             	mov    %rax,%rcx
    4dac:	48 39 10             	cmp    %rdx,(%rax)
    4daf:	75 ef                	jne    4da0 <fwp_drop0+0x120>
    4db1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4db5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4db9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4dbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4dc4:	0f 85 3a ff ff ff    	jne    4d04 <fwp_drop0+0x84>
    4dca:	48 89 d7             	mov    %rdx,%rdi
    4dcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4dd2:	e8 b9 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4dd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4ddc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4ddf:	e9 20 ff ff ff       	jmp    4d04 <fwp_drop0+0x84>
    4de4:	48 8d 3d 9d 34 00 00 	lea    0x349d(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4deb:	e8 c0 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004df0 <fwp_drop1>:
    4df0:	f3 0f 1e fa          	endbr64
    4df4:	48 8b 15 bd 6c 01 00 	mov    0x16cbd(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    4dfb:	48 89 f8             	mov    %rdi,%rax
    4dfe:	48 2b 05 8b 6c 01 00 	sub    0x16c8b(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    4e05:	48 c1 e2 10          	shl    $0x10,%rdx
    4e09:	48 39 d0             	cmp    %rdx,%rax
    4e0c:	0f 83 be 00 00 00    	jae    4ed0 <fwp_drop1+0xe0>
    4e12:	48 83 ec 18          	sub    $0x18,%rsp
    4e16:	4c 8d 05 c3 58 01 00 	lea    0x158c3(%rip),%r8        # 1a6e0 <fwp_heap>
    4e1d:	48 89 c2             	mov    %rax,%rdx
    4e20:	48 c1 ea 10          	shr    $0x10,%rdx
    4e24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4e2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4e33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4e37:	48 85 d2             	test   %rdx,%rdx
    4e3a:	74 3c                	je     4e78 <fwp_drop1+0x88>
    4e3c:	0f b6 31             	movzbl (%rcx),%esi
    4e3f:	40 80 fe 02          	cmp    $0x2,%sil
    4e43:	74 3b                	je     4e80 <fwp_drop1+0x90>
    4e45:	40 80 fe 01          	cmp    $0x1,%sil
    4e49:	75 2d                	jne    4e78 <fwp_drop1+0x88>
    4e4b:	8b 71 18             	mov    0x18(%rcx),%esi
    4e4e:	0f b7 c0             	movzwl %ax,%eax
    4e51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4e54:	48 0f af c6          	imul   %rsi,%rax
    4e58:	48 c1 e8 20          	shr    $0x20,%rax
    4e5c:	48 39 c8             	cmp    %rcx,%rax
    4e5f:	73 17                	jae    4e78 <fwp_drop1+0x88>
    4e61:	48 01 c2             	add    %rax,%rdx
    4e64:	0f b6 02             	movzbl (%rdx),%eax
    4e67:	84 c0                	test   %al,%al
    4e69:	74 0d                	je     4e78 <fwp_drop1+0x88>
    4e6b:	3c 01                	cmp    $0x1,%al
    4e6d:	74 21                	je     4e90 <fwp_drop1+0xa0>
    4e6f:	3c ff                	cmp    $0xff,%al
    4e71:	74 65                	je     4ed8 <fwp_drop1+0xe8>
    4e73:	83 e8 01             	sub    $0x1,%eax
    4e76:	88 02                	mov    %al,(%rdx)
    4e78:	48 83 c4 18          	add    $0x18,%rsp
    4e7c:	c3                   	ret
    4e7d:	0f 1f 00             	nopl   (%rax)
    4e80:	66 85 c0             	test   %ax,%ax
    4e83:	74 df                	je     4e64 <fwp_drop1+0x74>
    4e85:	48 83 c4 18          	add    $0x18,%rsp
    4e89:	c3                   	ret
    4e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4e94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e99:	e8 32 f6 ff ff       	call   44d0 <fwp_rc_free_arr>
    4e9e:	4c 8d 05 3b 58 01 00 	lea    0x1583b(%rip),%r8        # 1a6e0 <fwp_heap>
    4ea5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4eaa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4eb1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4eb8:	48 c1 e2 10          	shl    $0x10,%rdx
    4ebc:	48 39 d0             	cmp    %rdx,%rax
    4ebf:	73 b7                	jae    4e78 <fwp_drop1+0x88>
    4ec1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4ec6:	e9 52 ff ff ff       	jmp    4e1d <fwp_drop1+0x2d>
    4ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed0:	c3                   	ret
    4ed1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ed8:	48 89 d0             	mov    %rdx,%rax
    4edb:	48 c1 e8 11          	shr    $0x11,%rax
    4edf:	48 31 d0             	xor    %rdx,%rax
    4ee2:	48 89 c1             	mov    %rax,%rcx
    4ee5:	48 c1 e9 09          	shr    $0x9,%rcx
    4ee9:	48 31 c8             	xor    %rcx,%rax
    4eec:	0f b6 c8             	movzbl %al,%ecx
    4eef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4ef6:	00 
    4ef7:	48 85 c0             	test   %rax,%rax
    4efa:	75 0d                	jne    4f09 <fwp_drop1+0x119>
    4efc:	eb 46                	jmp    4f44 <fwp_drop1+0x154>
    4efe:	66 90                	xchg   %ax,%ax
    4f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4f04:	48 85 c0             	test   %rax,%rax
    4f07:	74 3b                	je     4f44 <fwp_drop1+0x154>
    4f09:	48 89 c1             	mov    %rax,%rcx
    4f0c:	48 39 10             	cmp    %rdx,(%rax)
    4f0f:	75 ef                	jne    4f00 <fwp_drop1+0x110>
    4f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4f24:	0f 85 4e ff ff ff    	jne    4e78 <fwp_drop1+0x88>
    4f2a:	48 89 d7             	mov    %rdx,%rdi
    4f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4f32:	e8 59 ee ff ff       	call   3d90 <fwp_rc_forget_slot>
    4f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4f3f:	e9 34 ff ff ff       	jmp    4e78 <fwp_drop1+0x88>
    4f44:	48 8d 3d 3d 33 00 00 	lea    0x333d(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4f4b:	e8 60 e1 ff ff       	call   30b0 <fwp_trap>

0000000000004f50 <fwp_write.constprop.0>:
    4f50:	41 57                	push   %r15
    4f52:	41 56                	push   %r14
    4f54:	41 55                	push   %r13
    4f56:	41 54                	push   %r12
    4f58:	55                   	push   %rbp
    4f59:	53                   	push   %rbx
    4f5a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    4f61:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    4f68:	00 00 
    4f6a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    4f71:	00 
    4f72:	49 89 d4             	mov    %rdx,%r12
    4f75:	8b 12                	mov    (%rdx),%edx
    4f77:	83 fa 19             	cmp    $0x19,%edx
    4f7a:	77 64                	ja     4fe0 <fwp_write.constprop.0+0x90>
    4f7c:	48 8d 0d 4d 34 00 00 	lea    0x344d(%rip),%rcx        # 83d0 <_IO_stdin_used+0x3d0>
    4f83:	89 d0                	mov    %edx,%eax
    4f85:	48 89 fb             	mov    %rdi,%rbx
    4f88:	48 89 f5             	mov    %rsi,%rbp
    4f8b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    4f8f:	48 01 c8             	add    %rcx,%rax
    4f92:	3e ff e0             	notrack jmp *%rax
    4f95:	0f 1f 00             	nopl   (%rax)
    4f98:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    4f9c:	48 8b 06             	mov    (%rsi),%rax
    4f9f:	48 89 ca             	mov    %rcx,%rdx
    4fa2:	48 85 c9             	test   %rcx,%rcx
    4fa5:	0f 88 b5 0c 00 00    	js     5c60 <fwp_write.constprop.0+0xd10>
    4fab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    4fb2:	00 
    4fb3:	48 89 c6             	mov    %rax,%rsi
    4fb6:	4c 89 e7             	mov    %r12,%rdi
    4fb9:	e8 42 da ff ff       	call   2a00 <fwp_fmt_u128>
    4fbe:	66 90                	xchg   %ax,%ax
    4fc0:	4c 89 e7             	mov    %r12,%rdi
    4fc3:	e8 68 d4 ff ff       	call   2430 <strlen@plt>
    4fc8:	4c 89 e6             	mov    %r12,%rsi
    4fcb:	48 89 df             	mov    %rbx,%rdi
    4fce:	48 89 c2             	mov    %rax,%rdx
    4fd1:	e8 aa df ff ff       	call   2f80 <buf_put>
    4fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fdd:	00 00 00 
    4fe0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    4fe7:	00 
    4fe8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4fef:	00 00 
    4ff1:	0f 85 9e 04 00 00    	jne    5495 <fwp_write.constprop.0+0x545>
    4ff7:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    4ffe:	5b                   	pop    %rbx
    4fff:	5d                   	pop    %rbp
    5000:	41 5c                	pop    %r12
    5002:	41 5d                	pop    %r13
    5004:	41 5e                	pop    %r14
    5006:	41 5f                	pop    %r15
    5008:	c3                   	ret
    5009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5010:	49 89 f1             	mov    %rsi,%r9
    5013:	4c 8d 05 c3 30 00 00 	lea    0x30c3(%rip),%r8        # 80dd <_IO_stdin_used+0xdd>
    501a:	b9 00 02 00 00       	mov    $0x200,%ecx
    501f:	ba 02 00 00 00       	mov    $0x2,%edx
    5024:	be 00 02 00 00       	mov    $0x200,%esi
    5029:	31 c0                	xor    %eax,%eax
    502b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5032:	00 
    5033:	e8 58 d3 ff ff       	call   2390 <__snprintf_chk@plt>
    5038:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    503f:	00 
    5040:	e8 eb d3 ff ff       	call   2430 <strlen@plt>
    5045:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    504c:	00 
    504d:	48 89 df             	mov    %rbx,%rdi
    5050:	48 89 c2             	mov    %rax,%rdx
    5053:	e8 28 df ff ff       	call   2f80 <buf_put>
    5058:	eb 86                	jmp    4fe0 <fwp_write.constprop.0+0x90>
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	49 89 f1             	mov    %rsi,%r9
    5063:	4c 8d 05 6e 30 00 00 	lea    0x306e(%rip),%r8        # 80d8 <_IO_stdin_used+0xd8>
    506a:	eb ae                	jmp    501a <fwp_write.constprop.0+0xca>
    506c:	0f 1f 40 00          	nopl   0x0(%rax)
    5070:	83 fa 13             	cmp    $0x13,%edx
    5073:	48 8d 05 54 30 00 00 	lea    0x3054(%rip),%rax        # 80ce <_IO_stdin_used+0xce>
    507a:	48 8d 35 52 30 00 00 	lea    0x3052(%rip),%rsi        # 80d3 <_IO_stdin_used+0xd3>
    5081:	ba 04 00 00 00       	mov    $0x4,%edx
    5086:	48 0f 44 f0          	cmove  %rax,%rsi
    508a:	45 31 ed             	xor    %r13d,%r13d
    508d:	e8 ee de ff ff       	call   2f80 <buf_put>
    5092:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5097:	0f 84 b3 09 00 00    	je     5a50 <fwp_write.constprop.0+0xb00>
    509d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    50a2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    50a7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    50ac:	48 89 df             	mov    %rbx,%rdi
    50af:	49 0f 44 c5          	cmove  %r13,%rax
    50b3:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    50b8:	e8 93 fe ff ff       	call   4f50 <fwp_write.constprop.0>
    50bd:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    50c2:	0f 84 80 0a 00 00    	je     5b48 <fwp_write.constprop.0+0xbf8>
    50c8:	49 83 c5 01          	add    $0x1,%r13
    50cc:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    50d0:	0f 83 7a 09 00 00    	jae    5a50 <fwp_write.constprop.0+0xb00>
    50d6:	ba 02 00 00 00       	mov    $0x2,%edx
    50db:	48 8d 35 3b 30 00 00 	lea    0x303b(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    50e2:	48 89 df             	mov    %rbx,%rdi
    50e5:	e8 96 de ff ff       	call   2f80 <buf_put>
    50ea:	eb b1                	jmp    509d <fwp_write.constprop.0+0x14d>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	ba 06 00 00 00       	mov    $0x6,%edx
    50f5:	48 8d 35 fa 2f 00 00 	lea    0x2ffa(%rip),%rsi        # 80f6 <_IO_stdin_used+0xf6>
    50fc:	48 83 c5 10          	add    $0x10,%rbp
    5100:	e8 7b de ff ff       	call   2f80 <buf_put>
    5105:	48 89 ef             	mov    %rbp,%rdi
    5108:	e8 23 d3 ff ff       	call   2430 <strlen@plt>
    510d:	48 89 ee             	mov    %rbp,%rsi
    5110:	48 89 df             	mov    %rbx,%rdi
    5113:	48 89 c2             	mov    %rax,%rdx
    5116:	e8 65 de ff ff       	call   2f80 <buf_put>
    511b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5120:	ba 01 00 00 00       	mov    $0x1,%edx
    5125:	48 89 df             	mov    %rbx,%rdi
    5128:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    512d:	e8 4e de ff ff       	call   2f80 <buf_put>
    5132:	e9 a9 fe ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    513e:	00 00 
    5140:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5147:	00 
    5148:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    514f:	00 00 
    5151:	0f 85 3e 03 00 00    	jne    5495 <fwp_write.constprop.0+0x545>
    5157:	ba 0a 00 00 00       	mov    $0xa,%edx
    515c:	48 8d 35 7f 2f 00 00 	lea    0x2f7f(%rip),%rsi        # 80e2 <_IO_stdin_used+0xe2>
    5163:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    516a:	48 89 df             	mov    %rbx,%rdi
    516d:	5b                   	pop    %rbx
    516e:	5d                   	pop    %rbp
    516f:	41 5c                	pop    %r12
    5171:	41 5d                	pop    %r13
    5173:	41 5e                	pop    %r14
    5175:	41 5f                	pop    %r15
    5177:	e9 04 de ff ff       	jmp    2f80 <buf_put>
    517c:	0f 1f 40 00          	nopl   0x0(%rax)
    5180:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5185:	4d 85 ed             	test   %r13,%r13
    5188:	0f 84 c2 0b 00 00    	je     5d50 <fwp_write.constprop.0+0xe00>
    518e:	48 8d 35 95 2f 00 00 	lea    0x2f95(%rip),%rsi        # 812a <_IO_stdin_used+0x12a>
    5195:	4c 89 ef             	mov    %r13,%rdi
    5198:	e8 73 d3 ff ff       	call   2510 <strcmp@plt>
    519d:	41 89 c1             	mov    %eax,%r9d
    51a0:	85 c0                	test   %eax,%eax
    51a2:	0f 84 2c 0c 00 00    	je     5dd4 <fwp_write.constprop.0+0xe84>
    51a8:	4c 89 ef             	mov    %r13,%rdi
    51ab:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    51b0:	e8 7b d2 ff ff       	call   2430 <strlen@plt>
    51b5:	4c 89 ee             	mov    %r13,%rsi
    51b8:	48 89 df             	mov    %rbx,%rdi
    51bb:	48 89 c2             	mov    %rax,%rdx
    51be:	e8 bd dd ff ff       	call   2f80 <buf_put>
    51c3:	ba 01 00 00 00       	mov    $0x1,%edx
    51c8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51cd:	48 89 df             	mov    %rbx,%rdi
    51d0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    51d5:	e8 a6 dd ff ff       	call   2f80 <buf_put>
    51da:	ba 01 00 00 00       	mov    $0x1,%edx
    51df:	4c 89 fe             	mov    %r15,%rsi
    51e2:	48 89 df             	mov    %rbx,%rdi
    51e5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    51ea:	e8 91 dd ff ff       	call   2f80 <buf_put>
    51ef:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    51f4:	45 31 f6             	xor    %r14d,%r14d
    51f7:	85 c0                	test   %eax,%eax
    51f9:	0f 8e 91 0a 00 00    	jle    5c90 <fwp_write.constprop.0+0xd40>
    51ff:	45 31 ed             	xor    %r13d,%r13d
    5202:	4d 85 ed             	test   %r13,%r13
    5205:	0f 85 d5 08 00 00    	jne    5ae0 <fwp_write.constprop.0+0xb90>
    520b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5212:	00 
    5213:	45 85 f6             	test   %r14d,%r14d
    5216:	0f 84 74 08 00 00    	je     5a90 <fwp_write.constprop.0+0xb40>
    521c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    5221:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    5226:	48 89 df             	mov    %rbx,%rdi
    5229:	49 83 c5 01          	add    $0x1,%r13
    522d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    5231:	e8 1a fd ff ff       	call   4f50 <fwp_write.constprop.0>
    5236:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    523b:	7f c5                	jg     5202 <fwp_write.constprop.0+0x2b2>
    523d:	45 85 f6             	test   %r14d,%r14d
    5240:	0f 84 4a 0a 00 00    	je     5c90 <fwp_write.constprop.0+0xd40>
    5246:	b8 29 00 00 00       	mov    $0x29,%eax
    524b:	ba 01 00 00 00       	mov    $0x1,%edx
    5250:	4c 89 fe             	mov    %r15,%rsi
    5253:	48 89 df             	mov    %rbx,%rdi
    5256:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    525a:	e8 21 dd ff ff       	call   2f80 <buf_put>
    525f:	e9 7c fd ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5264:	0f 1f 40 00          	nopl   0x0(%rax)
    5268:	ba 01 00 00 00       	mov    $0x1,%edx
    526d:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5272:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    5277:	e8 04 dd ff ff       	call   2f80 <buf_put>
    527c:	48 85 ed             	test   %rbp,%rbp
    527f:	0f 84 8b 07 00 00    	je     5a10 <fwp_write.constprop.0+0xac0>
    5285:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5289:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    528e:	48 89 df             	mov    %rbx,%rdi
    5291:	e8 ba fc ff ff       	call   4f50 <fwp_write.constprop.0>
    5296:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    529a:	48 85 ed             	test   %rbp,%rbp
    529d:	0f 84 6d 07 00 00    	je     5a10 <fwp_write.constprop.0+0xac0>
    52a3:	ba 02 00 00 00       	mov    $0x2,%edx
    52a8:	48 8d 35 6e 2e 00 00 	lea    0x2e6e(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    52af:	48 89 df             	mov    %rbx,%rdi
    52b2:	e8 c9 dc ff ff       	call   2f80 <buf_put>
    52b7:	eb cc                	jmp    5285 <fwp_write.constprop.0+0x335>
    52b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52c0:	4c 8b 2e             	mov    (%rsi),%r13
    52c3:	ba 01 00 00 00       	mov    $0x1,%edx
    52c8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    52cd:	48 83 c5 08          	add    $0x8,%rbp
    52d1:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    52d6:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    52db:	e8 a0 dc ff ff       	call   2f80 <buf_put>
    52e0:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    52e5:	4d 85 ed             	test   %r13,%r13
    52e8:	75 43                	jne    532d <fwp_write.constprop.0+0x3dd>
    52ea:	e9 81 07 00 00       	jmp    5a70 <fwp_write.constprop.0+0xb20>
    52ef:	90                   	nop
    52f0:	41 80 f9 09          	cmp    $0x9,%r9b
    52f4:	0f 84 f6 06 00 00    	je     59f0 <fwp_write.constprop.0+0xaa0>
    52fa:	41 80 f9 0a          	cmp    $0xa,%r9b
    52fe:	0f 85 bc 06 00 00    	jne    59c0 <fwp_write.constprop.0+0xa70>
    5304:	ba 02 00 00 00       	mov    $0x2,%edx
    5309:	48 8d 35 f3 2d 00 00 	lea    0x2df3(%rip),%rsi        # 8103 <_IO_stdin_used+0x103>
    5310:	48 89 df             	mov    %rbx,%rdi
    5313:	e8 68 dc ff ff       	call   2f80 <buf_put>
    5318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    531f:	00 
    5320:	48 83 c5 01          	add    $0x1,%rbp
    5324:	49 39 ec             	cmp    %rbp,%r12
    5327:	0f 84 43 07 00 00    	je     5a70 <fwp_write.constprop.0+0xb20>
    532d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    5332:	41 80 f9 0d          	cmp    $0xd,%r9b
    5336:	0f 84 64 06 00 00    	je     59a0 <fwp_write.constprop.0+0xa50>
    533c:	7e b2                	jle    52f0 <fwp_write.constprop.0+0x3a0>
    533e:	41 80 f9 22          	cmp    $0x22,%r9b
    5342:	0f 84 38 06 00 00    	je     5980 <fwp_write.constprop.0+0xa30>
    5348:	41 80 f9 5c          	cmp    $0x5c,%r9b
    534c:	0f 85 6e 06 00 00    	jne    59c0 <fwp_write.constprop.0+0xa70>
    5352:	ba 02 00 00 00       	mov    $0x2,%edx
    5357:	48 8d 35 a2 2d 00 00 	lea    0x2da2(%rip),%rsi        # 8100 <_IO_stdin_used+0x100>
    535e:	48 89 df             	mov    %rbx,%rdi
    5361:	e8 1a dc ff ff       	call   2f80 <buf_put>
    5366:	eb b8                	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    536f:	00 
    5370:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    5375:	ba 01 00 00 00       	mov    $0x1,%edx
    537a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    537f:	48 89 ee             	mov    %rbp,%rsi
    5382:	e8 f9 db ff ff       	call   2f80 <buf_put>
    5387:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    538c:	4c 89 e7             	mov    %r12,%rdi
    538f:	e8 9c d0 ff ff       	call   2430 <strlen@plt>
    5394:	4c 89 e6             	mov    %r12,%rsi
    5397:	48 89 df             	mov    %rbx,%rdi
    539a:	48 89 c2             	mov    %rax,%rdx
    539d:	e8 de db ff ff       	call   2f80 <buf_put>
    53a2:	ba 01 00 00 00       	mov    $0x1,%edx
    53a7:	48 89 ee             	mov    %rbp,%rsi
    53aa:	48 89 df             	mov    %rbx,%rdi
    53ad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    53b2:	e8 c9 db ff ff       	call   2f80 <buf_put>
    53b7:	e9 24 fc ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    53bc:	0f 1f 40 00          	nopl   0x0(%rax)
    53c0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    53c5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    53c9:	0f 8a de 0a 00 00    	jp     5ead <fwp_write.constprop.0+0xf5d>
    53cf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    53d3:	66 0f 54 05 e5 30 00 	andpd  0x30e5(%rip),%xmm0        # 84c0 <msg.3+0x80>
    53da:	00 
    53db:	bd 01 00 00 00       	mov    $0x1,%ebp
    53e0:	66 0f 2e 05 f8 30 00 	ucomisd 0x30f8(%rip),%xmm0        # 84e0 <msg.3+0xa0>
    53e7:	00 
    53e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    53ef:	00 
    53f0:	0f 87 02 09 00 00    	ja     5cf8 <fwp_write.constprop.0+0xda8>
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5404:	89 ee                	mov    %ebp,%esi
    5406:	4c 89 e7             	mov    %r12,%rdi
    5409:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    540e:	e8 6d dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    5413:	31 f6                	xor    %esi,%esi
    5415:	4c 89 e7             	mov    %r12,%rdi
    5418:	e8 d3 cf ff ff       	call   23f0 <strtod@plt>
    541d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    5422:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    5426:	7a 06                	jp     542e <fwp_write.constprop.0+0x4de>
    5428:	0f 84 09 03 00 00    	je     5737 <fwp_write.constprop.0+0x7e7>
    542e:	83 c5 01             	add    $0x1,%ebp
    5431:	83 fd 12             	cmp    $0x12,%ebp
    5434:	75 ca                	jne    5400 <fwp_write.constprop.0+0x4b0>
    5436:	be 11 00 00 00       	mov    $0x11,%esi
    543b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    543f:	4c 89 e7             	mov    %r12,%rdi
    5442:	e8 39 dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    5447:	e9 eb 02 00 00       	jmp    5737 <fwp_write.constprop.0+0x7e7>
    544c:	0f 1f 40 00          	nopl   0x0(%rax)
    5450:	48 83 fe 01          	cmp    $0x1,%rsi
    5454:	0f 84 86 08 00 00    	je     5ce0 <fwp_write.constprop.0+0xd90>
    545a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    545e:	b8 02 00 00 00       	mov    $0x2,%eax
    5463:	ba 01 00 00 00       	mov    $0x1,%edx
    5468:	48 0f 44 d0          	cmove  %rax,%rdx
    546c:	48 8d 35 59 2c 00 00 	lea    0x2c59(%rip),%rsi        # 80cc <_IO_stdin_used+0xcc>
    5473:	48 8d 05 4f 2c 00 00 	lea    0x2c4f(%rip),%rax        # 80c9 <_IO_stdin_used+0xc9>
    547a:	48 0f 44 f0          	cmove  %rax,%rsi
    547e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5485:	00 
    5486:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    548d:	00 00 
    548f:	0f 84 ce fc ff ff    	je     5163 <fwp_write.constprop.0+0x213>
    5495:	e8 a6 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    54a0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    54a5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    54aa:	e8 11 da ff ff       	call   2ec0 <buf_grow>
    54af:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    54b3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    54b9:	4c 03 0b             	add    (%rbx),%r9
    54bc:	66 45 89 11          	mov    %r10w,(%r9)
    54c0:	49 83 c1 01          	add    $0x1,%r9
    54c4:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    54cb:	55 55 55 
    54ce:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    54d5:	aa aa aa 
    54d8:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    54dc:	45 85 e4             	test   %r12d,%r12d
    54df:	7f 4c                	jg     552d <fwp_write.constprop.0+0x5dd>
    54e1:	e9 4a 05 00 00       	jmp    5a30 <fwp_write.constprop.0+0xae0>
    54e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    54ed:	00 00 00 
    54f0:	be 01 00 00 00       	mov    $0x1,%esi
    54f5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    54fa:	88 07                	mov    %al,(%rdi)
    54fc:	48 89 e8             	mov    %rbp,%rax
    54ff:	49 f7 e8             	imul   %r8
    5502:	48 89 e8             	mov    %rbp,%rax
    5505:	48 c1 f8 3f          	sar    $0x3f,%rax
    5509:	48 29 c2             	sub    %rax,%rdx
    550c:	48 85 c9             	test   %rcx,%rcx
    550f:	0f 95 c0             	setne  %al
    5512:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5516:	48 83 ef 01          	sub    $0x1,%rdi
    551a:	48 21 c5             	and    %rax,%rbp
    551d:	48 29 ea             	sub    %rbp,%rdx
    5520:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    5524:	49 39 f9             	cmp    %rdi,%r9
    5527:	0f 84 03 05 00 00    	je     5a30 <fwp_write.constprop.0+0xae0>
    552d:	48 89 e8             	mov    %rbp,%rax
    5530:	49 f7 e8             	imul   %r8
    5533:	48 89 e8             	mov    %rbp,%rax
    5536:	48 c1 f8 3f          	sar    $0x3f,%rax
    553a:	48 89 d1             	mov    %rdx,%rcx
    553d:	48 29 c1             	sub    %rax,%rcx
    5540:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    5544:	48 89 e9             	mov    %rbp,%rcx
    5547:	48 29 c1             	sub    %rax,%rcx
    554a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    554e:	49 f7 e2             	mul    %r10
    5551:	b8 30 00 00 00       	mov    $0x30,%eax
    5556:	48 89 d6             	mov    %rdx,%rsi
    5559:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    555d:	48 d1 ee             	shr    $1,%rsi
    5560:	48 01 f2             	add    %rsi,%rdx
    5563:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    5567:	48 29 d6             	sub    %rdx,%rsi
    556a:	74 8e                	je     54fa <fwp_write.constprop.0+0x5aa>
    556c:	48 83 fe 01          	cmp    $0x1,%rsi
    5570:	0f 85 7a ff ff ff    	jne    54f0 <fwp_write.constprop.0+0x5a0>
    5576:	31 f6                	xor    %esi,%esi
    5578:	b8 2b 00 00 00       	mov    $0x2b,%eax
    557d:	e9 78 ff ff ff       	jmp    54fa <fwp_write.constprop.0+0x5aa>
    5582:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5588:	ba 06 00 00 00       	mov    $0x6,%edx
    558d:	48 8d 35 8c 2b 00 00 	lea    0x2b8c(%rip),%rsi        # 8120 <_IO_stdin_used+0x120>
    5594:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    559a:	e8 e1 d9 ff ff       	call   2f80 <buf_put>
    559f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    55a6:	ff ff 7f 
    55a9:	48 23 55 00          	and    0x0(%rbp),%rdx
    55ad:	0f 84 4e 03 00 00    	je     5901 <fwp_write.constprop.0+0x9b1>
    55b3:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    55b8:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    55bc:	48 85 d2             	test   %rdx,%rdx
    55bf:	0f 84 a4 00 00 00    	je     5669 <fwp_write.constprop.0+0x719>
    55c5:	8b 0a                	mov    (%rdx),%ecx
    55c7:	83 f9 1c             	cmp    $0x1c,%ecx
    55ca:	0f 84 d0 06 00 00    	je     5ca0 <fwp_write.constprop.0+0xd50>
    55d0:	83 f9 1b             	cmp    $0x1b,%ecx
    55d3:	0f 87 90 00 00 00    	ja     5669 <fwp_write.constprop.0+0x719>
    55d9:	be 01 00 00 00       	mov    $0x1,%esi
    55de:	48 d3 e6             	shl    %cl,%rsi
    55e1:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    55e7:	0f 85 13 06 00 00    	jne    5c00 <fwp_write.constprop.0+0xcb0>
    55ed:	f7 c6 84 04 00 00    	test   $0x484,%esi
    55f3:	0f 85 d7 05 00 00    	jne    5bd0 <fwp_write.constprop.0+0xc80>
    55f9:	83 e6 21             	and    $0x21,%esi
    55fc:	74 6b                	je     5669 <fwp_write.constprop.0+0x719>
    55fe:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5603:	48 85 ff             	test   %rdi,%rdi
    5606:	79 07                	jns    560f <fwp_write.constprop.0+0x6bf>
    5608:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    560c:	4c 01 ee             	add    %r13,%rsi
    560f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5613:	85 c9                	test   %ecx,%ecx
    5615:	40 0f b6 f7          	movzbl %dil,%esi
    5619:	48 0f 44 f7          	cmove  %rdi,%rsi
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	48 89 df             	mov    %rbx,%rdi
    5623:	49 83 c5 01          	add    $0x1,%r13
    5627:	e8 24 f9 ff ff       	call   4f50 <fwp_write.constprop.0>
    562c:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5633:	ff ff 7f 
    5636:	48 23 55 00          	and    0x0(%rbp),%rdx
    563a:	49 39 d5             	cmp    %rdx,%r13
    563d:	0f 83 be 02 00 00    	jae    5901 <fwp_write.constprop.0+0x9b1>
    5643:	ba 02 00 00 00       	mov    $0x2,%edx
    5648:	48 89 df             	mov    %rbx,%rdi
    564b:	48 8d 35 cb 2a 00 00 	lea    0x2acb(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    5652:	e8 29 d9 ff ff       	call   2f80 <buf_put>
    5657:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    565c:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    5660:	48 85 d2             	test   %rdx,%rdx
    5663:	0f 85 5c ff ff ff    	jne    55c5 <fwp_write.constprop.0+0x675>
    5669:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    566e:	48 85 ff             	test   %rdi,%rdi
    5671:	0f 88 51 06 00 00    	js     5cc8 <fwp_write.constprop.0+0xd78>
    5677:	48 8b 31             	mov    (%rcx),%rsi
    567a:	eb a4                	jmp    5620 <fwp_write.constprop.0+0x6d0>
    567c:	0f 1f 40 00          	nopl   0x0(%rax)
    5680:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5687:	00 
    5688:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    568f:	00 00 
    5691:	0f 85 fe fd ff ff    	jne    5495 <fwp_write.constprop.0+0x545>
    5697:	ba 08 00 00 00       	mov    $0x8,%edx
    569c:	48 8d 35 4a 2a 00 00 	lea    0x2a4a(%rip),%rsi        # 80ed <_IO_stdin_used+0xed>
    56a3:	e9 bb fa ff ff       	jmp    5163 <fwp_write.constprop.0+0x213>
    56a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56af:	00 
    56b0:	66 0f 6e ce          	movd   %esi,%xmm1
    56b4:	0f 2e c9             	ucomiss %xmm1,%xmm1
    56b7:	0f 8a f0 07 00 00    	jp     5ead <fwp_write.constprop.0+0xf5d>
    56bd:	0f 28 c1             	movaps %xmm1,%xmm0
    56c0:	0f 54 05 e9 2d 00 00 	andps  0x2de9(%rip),%xmm0        # 84b0 <msg.3+0x70>
    56c7:	0f 2e 05 36 29 00 00 	ucomiss 0x2936(%rip),%xmm0        # 8004 <_IO_stdin_used+0x4>
    56ce:	0f 87 4c 06 00 00    	ja     5d20 <fwp_write.constprop.0+0xdd0>
    56d4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    56d8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    56de:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    56e5:	00 
    56e6:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    56ea:	66 49 0f 7e d7       	movq   %xmm2,%r15
    56ef:	90                   	nop
    56f0:	44 89 ee             	mov    %r13d,%esi
    56f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    56f8:	4c 89 e7             	mov    %r12,%rdi
    56fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5700:	e8 7b da ff ff       	call   3180 <fwp_format_g.constprop.0>
    5705:	31 f6                	xor    %esi,%esi
    5707:	4c 89 e7             	mov    %r12,%rdi
    570a:	e8 81 cd ff ff       	call   2490 <strtof@plt>
    570f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5714:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5717:	7a 02                	jp     571b <fwp_write.constprop.0+0x7cb>
    5719:	74 1c                	je     5737 <fwp_write.constprop.0+0x7e7>
    571b:	41 83 c5 01          	add    $0x1,%r13d
    571f:	41 83 fd 0a          	cmp    $0xa,%r13d
    5723:	75 cb                	jne    56f0 <fwp_write.constprop.0+0x7a0>
    5725:	be 09 00 00 00       	mov    $0x9,%esi
    572a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    572f:	4c 89 e7             	mov    %r12,%rdi
    5732:	e8 49 da ff ff       	call   3180 <fwp_format_g.constprop.0>
    5737:	4c 89 e7             	mov    %r12,%rdi
    573a:	e8 01 d9 ff ff       	call   3040 <fwp_finish_float>
    573f:	e9 7c f8 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5744:	0f 1f 40 00          	nopl   0x0(%rax)
    5748:	89 f0                	mov    %esi,%eax
    574a:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5751:	76 02                	jbe    5755 <fwp_write.constprop.0+0x805>
    5753:	8b 06                	mov    (%rsi),%eax
    5755:	41 89 c6             	mov    %eax,%r14d
    5758:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    575d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5762:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5766:	4c 89 ef             	mov    %r13,%rdi
    5769:	e8 c2 cc ff ff       	call   2430 <strlen@plt>
    576e:	4c 89 ee             	mov    %r13,%rsi
    5771:	48 89 df             	mov    %rbx,%rdi
    5774:	48 89 c2             	mov    %rax,%rdx
    5777:	e8 04 d8 ff ff       	call   2f80 <buf_put>
    577c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5781:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5785:	85 f6                	test   %esi,%esi
    5787:	0f 8e 53 f8 ff ff    	jle    4fe0 <fwp_write.constprop.0+0x90>
    578d:	45 31 ed             	xor    %r13d,%r13d
    5790:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5795:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    579a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    579f:	4c 89 fe             	mov    %r15,%rsi
    57a2:	48 89 df             	mov    %rbx,%rdi
    57a5:	ba 01 00 00 00       	mov    $0x1,%edx
    57aa:	48 89 04 24          	mov    %rax,(%rsp)
    57ae:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    57b3:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    57b7:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    57bb:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    57c0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    57c5:	e8 b6 d7 ff ff       	call   2f80 <buf_put>
    57ca:	41 8b 06             	mov    (%r14),%eax
    57cd:	83 f8 0e             	cmp    $0xe,%eax
    57d0:	0f 84 5a 03 00 00    	je     5b30 <fwp_write.constprop.0+0xbe0>
    57d6:	83 f8 10             	cmp    $0x10,%eax
    57d9:	0f 84 21 03 00 00    	je     5b00 <fwp_write.constprop.0+0xbb0>
    57df:	83 f8 0a             	cmp    $0xa,%eax
    57e2:	0f 84 68 04 00 00    	je     5c50 <fwp_write.constprop.0+0xd00>
    57e8:	0f 8f 32 01 00 00    	jg     5920 <fwp_write.constprop.0+0x9d0>
    57ee:	83 f8 03             	cmp    $0x3,%eax
    57f1:	0f 8f 39 04 00 00    	jg     5c30 <fwp_write.constprop.0+0xce0>
    57f7:	85 c0                	test   %eax,%eax
    57f9:	78 10                	js     580b <fwp_write.constprop.0+0x8bb>
    57fb:	48 8b 04 24          	mov    (%rsp),%rax
    57ff:	48 c1 e8 3f          	shr    $0x3f,%rax
    5803:	85 c0                	test   %eax,%eax
    5805:	0f 85 32 01 00 00    	jne    593d <fwp_write.constprop.0+0x9ed>
    580b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5810:	48 8b 34 24          	mov    (%rsp),%rsi
    5814:	48 89 df             	mov    %rbx,%rdi
    5817:	e8 34 f7 ff ff       	call   4f50 <fwp_write.constprop.0>
    581c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5821:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5826:	49 83 c5 01          	add    $0x1,%r13
    582a:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    582e:	0f 8f 61 ff ff ff    	jg     5795 <fwp_write.constprop.0+0x845>
    5834:	e9 a7 f7 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5844:	48 8b 36             	mov    (%rsi),%rsi
    5847:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    584e:	00 
    584f:	48 89 ef             	mov    %rbp,%rdi
    5852:	e8 a9 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    5857:	48 89 ef             	mov    %rbp,%rdi
    585a:	e8 d1 cb ff ff       	call   2430 <strlen@plt>
    585f:	48 89 ee             	mov    %rbp,%rsi
    5862:	48 89 df             	mov    %rbx,%rdi
    5865:	48 89 c2             	mov    %rax,%rdx
    5868:	e8 13 d7 ff ff       	call   2f80 <buf_put>
    586d:	e9 6e f7 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5878:	ba 06 00 00 00       	mov    $0x6,%edx
    587d:	48 8d 35 8f 28 00 00 	lea    0x288f(%rip),%rsi        # 8113 <_IO_stdin_used+0x113>
    5884:	45 31 ed             	xor    %r13d,%r13d
    5887:	e8 f4 d6 ff ff       	call   2f80 <buf_put>
    588c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5891:	75 19                	jne    58ac <fwp_write.constprop.0+0x95c>
    5893:	eb 6c                	jmp    5901 <fwp_write.constprop.0+0x9b1>
    5895:	0f 1f 00             	nopl   (%rax)
    5898:	ba 02 00 00 00       	mov    $0x2,%edx
    589d:	48 8d 35 79 28 00 00 	lea    0x2879(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    58a4:	48 89 df             	mov    %rbx,%rdi
    58a7:	e8 d4 d6 ff ff       	call   2f80 <buf_put>
    58ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    58b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    58b7:	31 c0                	xor    %eax,%eax
    58b9:	49 83 c5 01          	add    $0x1,%r13
    58bd:	4c 8d 05 56 28 00 00 	lea    0x2856(%rip),%r8        # 811a <_IO_stdin_used+0x11a>
    58c4:	ba 02 00 00 00       	mov    $0x2,%edx
    58c9:	be 00 02 00 00       	mov    $0x200,%esi
    58ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58d5:	00 
    58d6:	e8 b5 ca ff ff       	call   2390 <__snprintf_chk@plt>
    58db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58e2:	00 
    58e3:	e8 48 cb ff ff       	call   2430 <strlen@plt>
    58e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    58ef:	00 
    58f0:	48 89 df             	mov    %rbx,%rdi
    58f3:	48 89 c2             	mov    %rax,%rdx
    58f6:	e8 85 d6 ff ff       	call   2f80 <buf_put>
    58fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    58ff:	72 97                	jb     5898 <fwp_write.constprop.0+0x948>
    5901:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5906:	ba 01 00 00 00       	mov    $0x1,%edx
    590b:	48 89 df             	mov    %rbx,%rdi
    590e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5913:	e8 68 d6 ff ff       	call   2f80 <buf_put>
    5918:	e9 c3 f6 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    591d:	0f 1f 00             	nopl   (%rax)
    5920:	83 f8 0b             	cmp    $0xb,%eax
    5923:	0f 85 e2 fe ff ff    	jne    580b <fwp_write.constprop.0+0x8bb>
    5929:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    592e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5932:	83 e0 01             	and    $0x1,%eax
    5935:	85 c0                	test   %eax,%eax
    5937:	0f 84 ce fe ff ff    	je     580b <fwp_write.constprop.0+0x8bb>
    593d:	4c 89 fe             	mov    %r15,%rsi
    5940:	48 89 df             	mov    %rbx,%rdi
    5943:	ba 01 00 00 00       	mov    $0x1,%edx
    5948:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    594d:	e8 2e d6 ff ff       	call   2f80 <buf_put>
    5952:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5957:	48 8b 34 24          	mov    (%rsp),%rsi
    595b:	48 89 df             	mov    %rbx,%rdi
    595e:	e8 ed f5 ff ff       	call   4f50 <fwp_write.constprop.0>
    5963:	ba 01 00 00 00       	mov    $0x1,%edx
    5968:	4c 89 fe             	mov    %r15,%rsi
    596b:	48 89 df             	mov    %rbx,%rdi
    596e:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5973:	e8 08 d6 ff ff       	call   2f80 <buf_put>
    5978:	e9 9f fe ff ff       	jmp    581c <fwp_write.constprop.0+0x8cc>
    597d:	0f 1f 00             	nopl   (%rax)
    5980:	ba 02 00 00 00       	mov    $0x2,%edx
    5985:	48 8d 35 71 27 00 00 	lea    0x2771(%rip),%rsi        # 80fd <_IO_stdin_used+0xfd>
    598c:	48 89 df             	mov    %rbx,%rdi
    598f:	e8 ec d5 ff ff       	call   2f80 <buf_put>
    5994:	e9 87 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a0:	ba 02 00 00 00       	mov    $0x2,%edx
    59a5:	48 8d 35 5d 27 00 00 	lea    0x275d(%rip),%rsi        # 8109 <_IO_stdin_used+0x109>
    59ac:	48 89 df             	mov    %rbx,%rdi
    59af:	e8 cc d5 ff ff       	call   2f80 <buf_put>
    59b4:	e9 67 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    59b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    59c4:	0f 86 b6 01 00 00    	jbe    5b80 <fwp_write.constprop.0+0xc30>
    59ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    59ce:	0f 84 ac 01 00 00    	je     5b80 <fwp_write.constprop.0+0xc30>
    59d4:	ba 01 00 00 00       	mov    $0x1,%edx
    59d9:	4c 89 fe             	mov    %r15,%rsi
    59dc:	48 89 df             	mov    %rbx,%rdi
    59df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    59e4:	e8 97 d5 ff ff       	call   2f80 <buf_put>
    59e9:	e9 32 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    59ee:	66 90                	xchg   %ax,%ax
    59f0:	ba 02 00 00 00       	mov    $0x2,%edx
    59f5:	48 8d 35 0a 27 00 00 	lea    0x270a(%rip),%rsi        # 8106 <_IO_stdin_used+0x106>
    59fc:	48 89 df             	mov    %rbx,%rdi
    59ff:	e8 7c d5 ff ff       	call   2f80 <buf_put>
    5a04:	e9 17 f9 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a10:	ba 01 00 00 00       	mov    $0x1,%edx
    5a15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a1a:	48 89 df             	mov    %rbx,%rdi
    5a1d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5a22:	e8 59 d5 ff ff       	call   2f80 <buf_put>
    5a27:	e9 b4 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5a34:	48 8b 13             	mov    (%rbx),%rdx
    5a37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5a3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5a40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5a44:	e9 97 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a50:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a55:	ba 01 00 00 00       	mov    $0x1,%edx
    5a5a:	48 89 df             	mov    %rbx,%rdi
    5a5d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5a62:	e8 19 d5 ff ff       	call   2f80 <buf_put>
    5a67:	e9 74 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a70:	ba 01 00 00 00       	mov    $0x1,%edx
    5a75:	4c 89 fe             	mov    %r15,%rsi
    5a78:	48 89 df             	mov    %rbx,%rdi
    5a7b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5a80:	e8 fb d4 ff ff       	call   2f80 <buf_put>
    5a85:	e9 56 f5 ff ff       	jmp    4fe0 <fwp_write.constprop.0+0x90>
    5a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a90:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5a95:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a9a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5a9e:	48 89 f7             	mov    %rsi,%rdi
    5aa1:	48 89 34 24          	mov    %rsi,(%rsp)
    5aa5:	e8 86 c9 ff ff       	call   2430 <strlen@plt>
    5aaa:	48 8b 34 24          	mov    (%rsp),%rsi
    5aae:	48 89 df             	mov    %rbx,%rdi
    5ab1:	48 89 c2             	mov    %rax,%rdx
    5ab4:	e8 c7 d4 ff ff       	call   2f80 <buf_put>
    5ab9:	ba 03 00 00 00       	mov    $0x3,%edx
    5abe:	48 8d 35 7b 26 00 00 	lea    0x267b(%rip),%rsi        # 8140 <_IO_stdin_used+0x140>
    5ac5:	48 89 df             	mov    %rbx,%rdi
    5ac8:	e8 b3 d4 ff ff       	call   2f80 <buf_put>
    5acd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5ad2:	e9 45 f7 ff ff       	jmp    521c <fwp_write.constprop.0+0x2cc>
    5ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ade:	00 00 
    5ae0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ae5:	48 8d 35 31 26 00 00 	lea    0x2631(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    5aec:	48 89 df             	mov    %rbx,%rdi
    5aef:	e8 8c d4 ff ff       	call   2f80 <buf_put>
    5af4:	e9 12 f7 ff ff       	jmp    520b <fwp_write.constprop.0+0x2bb>
    5af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b00:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5b05:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5b09:	48 85 ff             	test   %rdi,%rdi
    5b0c:	0f 84 f9 fc ff ff    	je     580b <fwp_write.constprop.0+0x8bb>
    5b12:	48 8d 35 11 26 00 00 	lea    0x2611(%rip),%rsi        # 812a <_IO_stdin_used+0x12a>
    5b19:	e8 f2 c9 ff ff       	call   2510 <strcmp@plt>
    5b1e:	85 c0                	test   %eax,%eax
    5b20:	0f 95 c0             	setne  %al
    5b23:	0f b6 c0             	movzbl %al,%eax
    5b26:	e9 d8 fc ff ff       	jmp    5803 <fwp_write.constprop.0+0x8b3>
    5b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b30:	31 c0                	xor    %eax,%eax
    5b32:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5b39:	00 
    5b3a:	0f 97 c0             	seta   %al
    5b3d:	e9 c1 fc ff ff       	jmp    5803 <fwp_write.constprop.0+0x8b3>
    5b42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b48:	48 89 df             	mov    %rbx,%rdi
    5b4b:	ba 02 00 00 00       	mov    $0x2,%edx
    5b50:	48 8d 35 d0 25 00 00 	lea    0x25d0(%rip),%rsi        # 8127 <_IO_stdin_used+0x127>
    5b57:	e8 24 d4 ff ff       	call   2f80 <buf_put>
    5b5c:	4c 89 e8             	mov    %r13,%rax
    5b5f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5b64:	48 89 df             	mov    %rbx,%rdi
    5b67:	48 c1 e0 04          	shl    $0x4,%rax
    5b6b:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5b70:	e8 db f3 ff ff       	call   4f50 <fwp_write.constprop.0>
    5b75:	e9 4e f5 ff ff       	jmp    50c8 <fwp_write.constprop.0+0x178>
    5b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b80:	4c 8d 05 85 25 00 00 	lea    0x2585(%rip),%r8        # 810c <_IO_stdin_used+0x10c>
    5b87:	b9 10 00 00 00       	mov    $0x10,%ecx
    5b8c:	31 c0                	xor    %eax,%eax
    5b8e:	ba 02 00 00 00       	mov    $0x2,%edx
    5b93:	be 10 00 00 00       	mov    $0x10,%esi
    5b98:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5b9f:	00 
    5ba0:	e8 eb c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5ba5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5bac:	00 
    5bad:	e8 7e c8 ff ff       	call   2430 <strlen@plt>
    5bb2:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5bb9:	00 
    5bba:	48 89 df             	mov    %rbx,%rdi
    5bbd:	48 89 c2             	mov    %rax,%rdx
    5bc0:	e8 bb d3 ff ff       	call   2f80 <buf_put>
    5bc5:	e9 56 f7 ff ff       	jmp    5320 <fwp_write.constprop.0+0x3d0>
    5bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bd0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5bd5:	48 85 ff             	test   %rdi,%rdi
    5bd8:	79 0c                	jns    5be6 <fwp_write.constprop.0+0xc96>
    5bda:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5be1:	00 
    5be2:	48 03 75 10          	add    0x10(%rbp),%rsi
    5be6:	48 63 3e             	movslq (%rsi),%rdi
    5be9:	83 f9 02             	cmp    $0x2,%ecx
    5bec:	89 fe                	mov    %edi,%esi
    5bee:	48 0f 44 f7          	cmove  %rdi,%rsi
    5bf2:	e9 29 fa ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bfe:	00 00 
    5c00:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5c05:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5c0a:	48 85 ff             	test   %rdi,%rdi
    5c0d:	0f 88 6f 01 00 00    	js     5d82 <fwp_write.constprop.0+0xe32>
    5c13:	49 0f bf 38          	movswq (%r8),%rdi
    5c17:	83 f9 01             	cmp    $0x1,%ecx
    5c1a:	0f b7 f7             	movzwl %di,%esi
    5c1d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c21:	e9 fa f9 ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c2d:	00 00 00 
    5c30:	83 f8 04             	cmp    $0x4,%eax
    5c33:	0f 85 d2 fb ff ff    	jne    580b <fwp_write.constprop.0+0x8bb>
    5c39:	48 8b 04 24          	mov    (%rsp),%rax
    5c3d:	48 8b 40 08          	mov    0x8(%rax),%rax
    5c41:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5c46:	48 c1 e8 3f          	shr    $0x3f,%rax
    5c4a:	e9 e6 fc ff ff       	jmp    5935 <fwp_write.constprop.0+0x9e5>
    5c4f:	90                   	nop
    5c50:	8b 0c 24             	mov    (%rsp),%ecx
    5c53:	31 c0                	xor    %eax,%eax
    5c55:	85 c9                	test   %ecx,%ecx
    5c57:	0f 98 c0             	sets   %al
    5c5a:	e9 d6 fc ff ff       	jmp    5935 <fwp_write.constprop.0+0x9e5>
    5c5f:	90                   	nop
    5c60:	48 f7 d8             	neg    %rax
    5c63:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5c6a:	00 
    5c6b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5c72:	2d 
    5c73:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5c7a:	00 
    5c7b:	48 83 d2 00          	adc    $0x0,%rdx
    5c7f:	48 89 c6             	mov    %rax,%rsi
    5c82:	48 f7 da             	neg    %rdx
    5c85:	e8 76 cd ff ff       	call   2a00 <fwp_fmt_u128>
    5c8a:	e9 31 f3 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5c8f:	90                   	nop
    5c90:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5c95:	e9 b1 f5 ff ff       	jmp    524b <fwp_write.constprop.0+0x2fb>
    5c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ca0:	4c 89 e9             	mov    %r13,%rcx
    5ca3:	48 c1 e1 04          	shl    $0x4,%rcx
    5ca7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5cac:	48 85 ff             	test   %rdi,%rdi
    5caf:	0f 89 6b f9 ff ff    	jns    5620 <fwp_write.constprop.0+0x6d0>
    5cb5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5cb9:	48 89 ce             	mov    %rcx,%rsi
    5cbc:	e9 5f f9 ff ff       	jmp    5620 <fwp_write.constprop.0+0x6d0>
    5cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cc8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5ccf:	00 
    5cd0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5cd4:	e9 9e f9 ff ff       	jmp    5677 <fwp_write.constprop.0+0x727>
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ce5:	48 8d 35 da 23 00 00 	lea    0x23da(%rip),%rsi        # 80c6 <_IO_stdin_used+0xc6>
    5cec:	e9 8d f7 ff ff       	jmp    547e <fwp_write.constprop.0+0x52e>
    5cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cf8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5cfc:	48 8d 35 bf 23 00 00 	lea    0x23bf(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    5d03:	48 8d 05 b7 23 00 00 	lea    0x23b7(%rip),%rax        # 80c1 <_IO_stdin_used+0xc1>
    5d0a:	4c 89 e7             	mov    %r12,%rdi
    5d0d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5d11:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d15:	e8 b6 c6 ff ff       	call   23d0 <strcpy@plt>
    5d1a:	e9 a1 f2 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5d1f:	90                   	nop
    5d20:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d24:	48 8d 35 97 23 00 00 	lea    0x2397(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    5d2b:	48 8d 05 8f 23 00 00 	lea    0x238f(%rip),%rax        # 80c1 <_IO_stdin_used+0xc1>
    5d32:	0f 2f c8             	comiss %xmm0,%xmm1
    5d35:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5d3c:	00 
    5d3d:	4c 89 e7             	mov    %r12,%rdi
    5d40:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d44:	e8 87 c6 ff ff       	call   23d0 <strcpy@plt>
    5d49:	e9 72 f2 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5d4e:	66 90                	xchg   %ax,%ax
    5d50:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5d55:	45 85 c0             	test   %r8d,%r8d
    5d58:	75 34                	jne    5d8e <fwp_write.constprop.0+0xe3e>
    5d5a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5d61:	00 
    5d62:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d69:	00 00 
    5d6b:	0f 85 24 f7 ff ff    	jne    5495 <fwp_write.constprop.0+0x545>
    5d71:	ba 02 00 00 00       	mov    $0x2,%edx
    5d76:	48 8d 35 c0 23 00 00 	lea    0x23c0(%rip),%rsi        # 813d <_IO_stdin_used+0x13d>
    5d7d:	e9 e1 f3 ff ff       	jmp    5163 <fwp_write.constprop.0+0x213>
    5d82:	48 03 75 10          	add    0x10(%rbp),%rsi
    5d86:	49 89 f0             	mov    %rsi,%r8
    5d89:	e9 85 fe ff ff       	jmp    5c13 <fwp_write.constprop.0+0xcc3>
    5d8e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5d93:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5d98:	85 ff                	test   %edi,%edi
    5d9a:	0f 84 3a f4 ff ff    	je     51da <fwp_write.constprop.0+0x28a>
    5da0:	ba 01 00 00 00       	mov    $0x1,%edx
    5da5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5daa:	48 89 df             	mov    %rbx,%rdi
    5dad:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5db2:	e8 c9 d1 ff ff       	call   2f80 <buf_put>
    5db7:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5dbc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5dc1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5dc7:	85 d2                	test   %edx,%edx
    5dc9:	0f 8f 30 f4 ff ff    	jg     51ff <fwp_write.constprop.0+0x2af>
    5dcf:	e9 72 f4 ff ff       	jmp    5246 <fwp_write.constprop.0+0x2f6>
    5dd4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5dd8:	49 89 c5             	mov    %rax,%r13
    5ddb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5de0:	49 89 c4             	mov    %rax,%r12
    5de3:	49 c1 fd 3f          	sar    $0x3f,%r13
    5de7:	4c 09 e8             	or     %r13,%rax
    5dea:	0f 84 a7 00 00 00    	je     5e97 <fwp_write.constprop.0+0xf47>
    5df0:	48 8d 2d 69 3d 00 00 	lea    0x3d69(%rip),%rbp        # 9b60 <units.0>
    5df7:	4d 89 e7             	mov    %r12,%r15
    5dfa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5dfe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5e03:	4c 89 ff             	mov    %r15,%rdi
    5e06:	4c 89 ee             	mov    %r13,%rsi
    5e09:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e0d:	48 99                	cqto
    5e0f:	48 89 d1             	mov    %rdx,%rcx
    5e12:	48 89 c2             	mov    %rax,%rdx
    5e15:	e8 a6 15 00 00       	call   73c0 <__divmodti4>
    5e1a:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e1e:	48 89 c1             	mov    %rax,%rcx
    5e21:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5e26:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5e2b:	0f 84 94 00 00 00    	je     5ec5 <fwp_write.constprop.0+0xf75>
    5e31:	41 83 c1 01          	add    $0x1,%r9d
    5e35:	48 83 c5 10          	add    $0x10,%rbp
    5e39:	41 83 f9 05          	cmp    $0x5,%r9d
    5e3d:	75 bb                	jne    5dfa <fwp_write.constprop.0+0xeaa>
    5e3f:	4d 85 ed             	test   %r13,%r13
    5e42:	79 53                	jns    5e97 <fwp_write.constprop.0+0xf47>
    5e44:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5e49:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5e4e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5e53:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e58:	48 99                	cqto
    5e5a:	48 f7 d8             	neg    %rax
    5e5d:	48 83 d2 00          	adc    $0x0,%rdx
    5e61:	48 89 c6             	mov    %rax,%rsi
    5e64:	48 f7 da             	neg    %rdx
    5e67:	e8 94 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5e6c:	49 89 e8             	mov    %rbp,%r8
    5e6f:	ba 00 02 00 00       	mov    $0x200,%edx
    5e74:	be 02 00 00 00       	mov    $0x2,%esi
    5e79:	31 c0                	xor    %eax,%eax
    5e7b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5e82:	00 
    5e83:	48 8d 0d ae 22 00 00 	lea    0x22ae(%rip),%rcx        # 8138 <_IO_stdin_used+0x138>
    5e8a:	4c 89 e7             	mov    %r12,%rdi
    5e8d:	e8 0e c8 ff ff       	call   26a0 <__sprintf_chk@plt>
    5e92:	e9 29 f1 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5e97:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e9c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5ea1:	31 d2                	xor    %edx,%edx
    5ea3:	48 89 ef             	mov    %rbp,%rdi
    5ea6:	e8 55 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5eab:	eb bf                	jmp    5e6c <fwp_write.constprop.0+0xf1c>
    5ead:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5eb4:	4e 61 4e 00 
    5eb8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ebf:	00 
    5ec0:	e9 fb f0 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5ec5:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec9:	48 89 c8             	mov    %rcx,%rax
    5ecc:	48 85 d2             	test   %rdx,%rdx
    5ecf:	78 51                	js     5f22 <fwp_write.constprop.0+0xfd2>
    5ed1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5ed6:	48 89 c6             	mov    %rax,%rsi
    5ed9:	48 89 ef             	mov    %rbp,%rdi
    5edc:	e8 1f cb ff ff       	call   2a00 <fwp_fmt_u128>
    5ee1:	44 8b 0c 24          	mov    (%rsp),%r9d
    5ee5:	49 63 c1             	movslq %r9d,%rax
    5ee8:	49 89 e8             	mov    %rbp,%r8
    5eeb:	ba 00 02 00 00       	mov    $0x200,%edx
    5ef0:	be 02 00 00 00       	mov    $0x2,%esi
    5ef5:	48 c1 e0 04          	shl    $0x4,%rax
    5ef9:	48 8d 0d 60 3c 00 00 	lea    0x3c60(%rip),%rcx        # 9b60 <units.0>
    5f00:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f07:	00 
    5f08:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5f0c:	4c 89 e7             	mov    %r12,%rdi
    5f0f:	48 8d 0d 1d 22 00 00 	lea    0x221d(%rip),%rcx        # 8133 <_IO_stdin_used+0x133>
    5f16:	31 c0                	xor    %eax,%eax
    5f18:	e8 83 c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f1d:	e9 9e f0 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x70>
    5f22:	48 f7 d8             	neg    %rax
    5f25:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5f2a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5f2f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f34:	48 83 d2 00          	adc    $0x0,%rdx
    5f38:	48 89 c6             	mov    %rax,%rsi
    5f3b:	48 f7 da             	neg    %rdx
    5f3e:	e8 bd ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f43:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f47:	eb 9c                	jmp    5ee5 <fwp_write.constprop.0+0xf95>
    5f49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005f50 <fwp_main_thread>:
    5f50:	f3 0f 1e fa          	endbr64
    5f54:	41 57                	push   %r15
    5f56:	41 56                	push   %r14
    5f58:	41 55                	push   %r13
    5f5a:	41 54                	push   %r12
    5f5c:	55                   	push   %rbp
    5f5d:	53                   	push   %rbx
    5f5e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    5f65:	8b 3d 19 5b 01 00    	mov    0x15b19(%rip),%edi        # 1ba84 <fwp_heap+0x13a4>
    5f6b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5f72:	00 00 
    5f74:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    5f7b:	00 
    5f7c:	31 c0                	xor    %eax,%eax
    5f7e:	85 ff                	test   %edi,%edi
    5f80:	0f 84 32 0c 00 00    	je     6bb8 <fwp_main_thread+0xc68>
    5f86:	8b 35 fc 5a 01 00    	mov    0x15afc(%rip),%esi        # 1ba88 <fwp_heap+0x13a8>
    5f8c:	85 f6                	test   %esi,%esi
    5f8e:	0f 85 0c 0c 00 00    	jne    6ba0 <fwp_main_thread+0xc50>
    5f94:	4c 8d 74 24 40       	lea    0x40(%rsp),%r14
    5f99:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    5f9e:	31 f6                	xor    %esi,%esi
    5fa0:	48 c7 05 dd 40 01 00 	movq   $0x40000000,0x140dd(%rip)        # 1a088 <fwp_main_stack_size>
    5fa7:	00 00 00 40 
    5fab:	48 8d 05 ce 40 00 00 	lea    0x40ce(%rip),%rax        # a080 <alt.4>
    5fb2:	4c 89 f7             	mov    %r14,%rdi
    5fb5:	4c 89 25 d4 40 01 00 	mov    %r12,0x140d4(%rip)        # 1a090 <fwp_main_stack_top>
    5fbc:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    5fc1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    5fc8:	01 00 
    5fca:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    5fd1:	00 
    5fd2:	e8 a9 c6 ff ff       	call   2680 <sigaltstack@plt>
    5fd7:	85 c0                	test   %eax,%eax
    5fd9:	0f 85 91 13 00 00    	jne    7370 <fwp_main_thread+0x1420>
    5fdf:	31 db                	xor    %ebx,%ebx
    5fe1:	b9 12 00 00 00       	mov    $0x12,%ecx
    5fe6:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    5fed:	00 
    5fee:	48 89 d8             	mov    %rbx,%rax
    5ff1:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    5ff8:	00 
    5ff9:	f3 48 ab             	rep stos %rax,(%rdi)
    5ffc:	48 8d 05 3d cc ff ff 	lea    -0x33c3(%rip),%rax        # 2c40 <fwp_segv>
    6003:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    600a:	00 
    600b:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    6012:	04 00 00 08 
    6016:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    601d:	00 
    601e:	e8 2d c5 ff ff       	call   2550 <sigemptyset@plt>
    6023:	85 c0                	test   %eax,%eax
    6025:	0f 85 45 13 00 00    	jne    7370 <fwp_main_thread+0x1420>
    602b:	31 d2                	xor    %edx,%edx
    602d:	48 89 ee             	mov    %rbp,%rsi
    6030:	bf 0b 00 00 00       	mov    $0xb,%edi
    6035:	e8 a6 c3 ff ff       	call   23e0 <sigaction@plt>
    603a:	85 c0                	test   %eax,%eax
    603c:	0f 85 2e 13 00 00    	jne    7370 <fwp_main_thread+0x1420>
    6042:	31 d2                	xor    %edx,%edx
    6044:	48 89 ee             	mov    %rbp,%rsi
    6047:	bf 07 00 00 00       	mov    $0x7,%edi
    604c:	e8 8f c3 ff ff       	call   23e0 <sigaction@plt>
    6051:	85 c0                	test   %eax,%eax
    6053:	0f 85 17 13 00 00    	jne    7370 <fwp_main_thread+0x1420>
    6059:	8b 0d 09 40 00 00    	mov    0x4009(%rip),%ecx        # a068 <st.2>
    605f:	85 c9                	test   %ecx,%ecx
    6061:	0f 84 69 05 00 00    	je     65d0 <fwp_main_thread+0x680>
    6067:	48 8b 2d 52 46 01 00 	mov    0x14652(%rip),%rbp        # 1a6c0 <fwp_cur>
    606e:	48 85 ed             	test   %rbp,%rbp
    6071:	0f 84 09 03 00 00    	je     6380 <fwp_main_thread+0x430>
    6077:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    607c:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    6080:	48 89 eb             	mov    %rbp,%rbx
    6083:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    6088:	0f 84 41 01 00 00    	je     61cf <fwp_main_thread+0x27f>
    608e:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    6093:	0f 84 17 02 00 00    	je     62b0 <fwp_main_thread+0x360>
    6099:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    609d:	0f 84 fd 01 00 00    	je     62a0 <fwp_main_thread+0x350>
    60a3:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    60a7:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    60ab:	0f 85 7f 02 00 00    	jne    6330 <fwp_main_thread+0x3e0>
    60b1:	48 8b 43 60          	mov    0x60(%rbx),%rax
    60b5:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    60bc:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    60c0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    60c7:	00 00 00 00 
    60cb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    60d2:	48 85 d2             	test   %rdx,%rdx
    60d5:	74 07                	je     60de <fwp_main_thread+0x18e>
    60d7:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    60de:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    60e2:	48 85 c0             	test   %rax,%rax
    60e5:	74 34                	je     611b <fwp_main_thread+0x1cb>
    60e7:	48 89 43 68          	mov    %rax,0x68(%rbx)
    60eb:	48 8b 05 a6 45 01 00 	mov    0x145a6(%rip),%rax        # 1a698 <fwp_timers>
    60f2:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    60f6:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    60fd:	00 00 00 00 
    6101:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    6108:	48 85 c0             	test   %rax,%rax
    610b:	74 07                	je     6114 <fwp_main_thread+0x1c4>
    610d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    6114:	48 89 1d 7d 45 01 00 	mov    %rbx,0x1457d(%rip)        # 1a698 <fwp_timers>
    611b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    611f:	e8 ac e9 ff ff       	call   4ad0 <fwp_block>
    6124:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    612b:	48 85 c9             	test   %rcx,%rcx
    612e:	74 47                	je     6177 <fwp_main_thread+0x227>
    6130:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    6137:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    613e:	48 85 d2             	test   %rdx,%rdx
    6141:	0f 84 29 02 00 00    	je     6370 <fwp_main_thread+0x420>
    6147:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    614e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    6155:	48 85 c0             	test   %rax,%rax
    6158:	74 07                	je     6161 <fwp_main_thread+0x211>
    615a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    6161:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    6168:	00 00 00 00 
    616c:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6170:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    6177:	48 8b 0d 42 45 01 00 	mov    0x14542(%rip),%rcx        # 1a6c0 <fwp_cur>
    617e:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    6182:	0f 84 98 01 00 00    	je     6320 <fwp_main_thread+0x3d0>
    6188:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    618f:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    6196:	48 85 d2             	test   %rdx,%rdx
    6199:	0f 84 99 03 00 00    	je     6538 <fwp_main_thread+0x5e8>
    619f:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    61a6:	48 85 c0             	test   %rax,%rax
    61a9:	74 07                	je     61b2 <fwp_main_thread+0x262>
    61ab:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    61b2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    61b6:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    61ba:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    61c1:	48 89 cb             	mov    %rcx,%rbx
    61c4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    61c9:	0f 85 bf fe ff ff    	jne    608e <fwp_main_thread+0x13e>
    61cf:	48 83 3d 79 61 01 00 	cmpq   $0x0,0x16179(%rip)        # 1c350 <fwp_state_len>
    61d6:	00 
    61d7:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    61db:	0f 84 81 03 00 00    	je     6562 <fwp_main_thread+0x612>
    61e1:	48 39 1d d0 44 01 00 	cmp    %rbx,0x144d0(%rip)        # 1a6b8 <fwp_root>
    61e8:	c7 05 8e 3e 01 00 00 	movl   $0x0,0x13e8e(%rip)        # 1a080 <fwp_exit_code>
    61ef:	00 00 00 
    61f2:	0f 85 b2 11 00 00    	jne    73aa <fwp_main_thread+0x145a>
    61f8:	48 85 db             	test   %rbx,%rbx
    61fb:	0f 84 a5 01 00 00    	je     63a6 <fwp_main_thread+0x456>
    6201:	48 8b 15 80 44 01 00 	mov    0x14480(%rip),%rdx        # 1a688 <fwp_tasks_active>
    6208:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    620c:	48 85 d2             	test   %rdx,%rdx
    620f:	0f 84 91 01 00 00    	je     63a6 <fwp_main_thread+0x456>
    6215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    621c:	00 00 00 00 
    6220:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    6224:	75 08                	jne    622e <fwp_main_thread+0x2de>
    6226:	48 89 d7             	mov    %rdx,%rdi
    6229:	e8 92 cd ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    622e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    6235:	48 85 d2             	test   %rdx,%rdx
    6238:	75 e6                	jne    6220 <fwp_main_thread+0x2d0>
    623a:	eb 31                	jmp    626d <fwp_main_thread+0x31d>
    623c:	0f 1f 40 00          	nopl   0x0(%rax)
    6240:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    6247:	48 89 1d 52 44 01 00 	mov    %rbx,0x14452(%rip)        # 1a6a0 <fwp_ready_tail>
    624e:	e8 7d e8 ff ff       	call   4ad0 <fwp_block>
    6253:	e8 68 e6 ff ff       	call   48c0 <fwp_free_zombie>
    6258:	48 83 3d 28 44 01 00 	cmpq   $0x0,0x14428(%rip)        # 1a688 <fwp_tasks_active>
    625f:	00 
    6260:	0f 84 40 01 00 00    	je     63a6 <fwp_main_thread+0x456>
    6266:	48 8b 1d 4b 44 01 00 	mov    0x1444b(%rip),%rbx        # 1a6b8 <fwp_root>
    626d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    6271:	75 db                	jne    624e <fwp_main_thread+0x2fe>
    6273:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    6277:	75 d5                	jne    624e <fwp_main_thread+0x2fe>
    6279:	48 8b 05 20 44 01 00 	mov    0x14420(%rip),%rax        # 1a6a0 <fwp_ready_tail>
    6280:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    6284:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    628b:	00 00 00 00 
    628f:	48 85 c0             	test   %rax,%rax
    6292:	75 ac                	jne    6240 <fwp_main_thread+0x2f0>
    6294:	48 89 1d 0d 44 01 00 	mov    %rbx,0x1440d(%rip)        # 1a6a8 <fwp_ready_head>
    629b:	eb aa                	jmp    6247 <fwp_main_thread+0x2f7>
    629d:	0f 1f 00             	nopl   (%rax)
    62a0:	e8 3b ce ff ff       	call   30e0 <fwp_now_ns>
    62a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    62a9:	0f 8d 99 02 00 00    	jge    6548 <fwp_main_thread+0x5f8>
    62af:	90                   	nop
    62b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    62b4:	0f 85 e9 fd ff ff    	jne    60a3 <fwp_main_thread+0x153>
    62ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    62be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    62c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    62c6:	0f 85 e9 fd ff ff    	jne    60b5 <fwp_main_thread+0x165>
    62cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    62d0:	48 85 c9             	test   %rcx,%rcx
    62d3:	0f 84 dc fd ff ff    	je     60b5 <fwp_main_thread+0x165>
    62d9:	48 39 c8             	cmp    %rcx,%rax
    62dc:	48 89 ce             	mov    %rcx,%rsi
    62df:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    62e6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    62ea:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    62f1:	00 00 00 00 
    62f5:	48 0f 4e f0          	cmovle %rax,%rsi
    62f9:	48 85 c0             	test   %rax,%rax
    62fc:	48 89 c8             	mov    %rcx,%rax
    62ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    6306:	48 0f 45 c6          	cmovne %rsi,%rax
    630a:	48 85 d2             	test   %rdx,%rdx
    630d:	74 07                	je     6316 <fwp_main_thread+0x3c6>
    630f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    6316:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    631a:	e9 c8 fd ff ff       	jmp    60e7 <fwp_main_thread+0x197>
    631f:	90                   	nop
    6320:	48 89 cb             	mov    %rcx,%rbx
    6323:	e9 5b fd ff ff       	jmp    6083 <fwp_main_thread+0x133>
    6328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    632f:	00 
    6330:	48 8b 45 40          	mov    0x40(%rbp),%rax
    6334:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    633b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    6342:	00 00 00 00 
    6346:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    634d:	48 85 c0             	test   %rax,%rax
    6350:	0f 84 5a 0d 00 00    	je     70b0 <fwp_main_thread+0x1160>
    6356:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    635d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    6361:	e9 b5 fd ff ff       	jmp    611b <fwp_main_thread+0x1cb>
    6366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    636d:	00 00 00 
    6370:	48 89 01             	mov    %rax,(%rcx)
    6373:	e9 dd fd ff ff       	jmp    6155 <fwp_main_thread+0x205>
    6378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    637f:	00 
    6380:	48 83 3d c8 5f 01 00 	cmpq   $0x0,0x15fc8(%rip)        # 1c350 <fwp_state_len>
    6387:	00 
    6388:	0f 84 d2 01 00 00    	je     6560 <fwp_main_thread+0x610>
    638e:	48 83 3d 22 43 01 00 	cmpq   $0x0,0x14322(%rip)        # 1a6b8 <fwp_root>
    6395:	00 
    6396:	c7 05 e0 3c 01 00 00 	movl   $0x0,0x13ce0(%rip)        # 1a080 <fwp_exit_code>
    639d:	00 00 00 
    63a0:	0f 85 09 10 00 00    	jne    73af <fwp_main_thread+0x145f>
    63a6:	e8 15 e5 ff ff       	call   48c0 <fwp_free_zombie>
    63ab:	48 83 3d f5 42 01 00 	cmpq   $0x0,0x142f5(%rip)        # 1a6a8 <fwp_ready_head>
    63b2:	00 
    63b3:	0f 85 52 c3 ff ff    	jne    270b <fwp_main_thread.cold>
    63b9:	48 83 3d d7 42 01 00 	cmpq   $0x0,0x142d7(%rip)        # 1a698 <fwp_timers>
    63c0:	00 
    63c1:	0f 85 44 c3 ff ff    	jne    270b <fwp_main_thread.cold>
    63c7:	8b 05 cf 3c 01 00    	mov    0x13ccf(%rip),%eax        # 1a09c <fwp_stack_pool_n>
    63cd:	85 c0                	test   %eax,%eax
    63cf:	74 3c                	je     640d <fwp_main_thread+0x4bd>
    63d1:	83 e8 01             	sub    $0x1,%eax
    63d4:	4c 8d 25 c5 3c 01 00 	lea    0x13cc5(%rip),%r12        # 1a0a0 <fwp_stack_pool>
    63db:	48 63 d8             	movslq %eax,%rbx
    63de:	89 c0                	mov    %eax,%eax
    63e0:	48 89 da             	mov    %rbx,%rdx
    63e3:	48 29 c2             	sub    %rax,%rdx
    63e6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    63ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63f0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    63f4:	89 1d a2 3c 01 00    	mov    %ebx,0x13ca2(%rip)        # 1a09c <fwp_stack_pool_n>
    63fa:	be 00 00 00 10       	mov    $0x10000000,%esi
    63ff:	48 83 eb 01          	sub    $0x1,%rbx
    6403:	e8 a8 c1 ff ff       	call   25b0 <munmap@plt>
    6408:	48 39 dd             	cmp    %rbx,%rbp
    640b:	75 e3                	jne    63f0 <fwp_main_thread+0x4a0>
    640d:	8b 3d fd 3b 00 00    	mov    0x3bfd(%rip),%edi        # a010 <fwp_epfd>
    6413:	85 ff                	test   %edi,%edi
    6415:	78 05                	js     641c <fwp_main_thread+0x4cc>
    6417:	e8 94 c0 ff ff       	call   24b0 <close@plt>
    641c:	4c 8b 25 7d 3e 01 00 	mov    0x13e7d(%rip),%r12        # 1a2a0 <fwp_nfdws>
    6423:	48 8b 2d 7e 3e 01 00 	mov    0x13e7e(%rip),%rbp        # 1a2a8 <fwp_fdws>
    642a:	31 db                	xor    %ebx,%ebx
    642c:	c7 05 da 3b 00 00 ff 	movl   $0xffffffff,0x3bda(%rip)        # a010 <fwp_epfd>
    6433:	ff ff ff 
    6436:	4d 85 e4             	test   %r12,%r12
    6439:	74 32                	je     646d <fwp_main_thread+0x51d>
    643b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6440:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    6445:	48 85 ff             	test   %rdi,%rdi
    6448:	74 1a                	je     6464 <fwp_main_thread+0x514>
    644a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    644e:	0f 85 b7 c2 ff ff    	jne    270b <fwp_main_thread.cold>
    6454:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    6459:	0f 85 ac c2 ff ff    	jne    270b <fwp_main_thread.cold>
    645f:	e8 6c db ff ff       	call   3fd0 <fwp_mem_free>
    6464:	48 83 c3 01          	add    $0x1,%rbx
    6468:	4c 39 e3             	cmp    %r12,%rbx
    646b:	75 d3                	jne    6440 <fwp_main_thread+0x4f0>
    646d:	48 89 ef             	mov    %rbp,%rdi
    6470:	e8 5b db ff ff       	call   3fd0 <fwp_mem_free>
    6475:	48 8b 15 3c 42 01 00 	mov    0x1423c(%rip),%rdx        # 1a6b8 <fwp_root>
    647c:	48 c7 05 21 3e 01 00 	movq   $0x0,0x13e21(%rip)        # 1a2a8 <fwp_fdws>
    6483:	00 00 00 00 
    6487:	48 c7 05 0e 3e 01 00 	movq   $0x0,0x13e0e(%rip)        # 1a2a0 <fwp_nfdws>
    648e:	00 00 00 00 
    6492:	48 85 d2             	test   %rdx,%rdx
    6495:	74 4e                	je     64e5 <fwp_main_thread+0x595>
    6497:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    649c:	0f 85 69 c2 ff ff    	jne    270b <fwp_main_thread.cold>
    64a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    64a9:	00 
    64aa:	0f 85 5b c2 ff ff    	jne    270b <fwp_main_thread.cold>
    64b0:	48 83 3d 98 5e 01 00 	cmpq   $0x0,0x15e98(%rip)        # 1c350 <fwp_state_len>
    64b7:	00 
    64b8:	0f 85 4d c2 ff ff    	jne    270b <fwp_main_thread.cold>
    64be:	48 83 3d 7a 5e 01 00 	cmpq   $0x0,0x15e7a(%rip)        # 1c340 <fwp_state_owners>
    64c5:	00 
    64c6:	0f 85 3f c2 ff ff    	jne    270b <fwp_main_thread.cold>
    64cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    64d1:	31 c0                	xor    %eax,%eax
    64d3:	48 8d 3d e6 3d 01 00 	lea    0x13de6(%rip),%rdi        # 1a2c0 <fwp_root_context>
    64da:	f3 48 ab             	rep stos %rax,(%rdi)
    64dd:	48 89 d7             	mov    %rdx,%rdi
    64e0:	e8 eb da ff ff       	call   3fd0 <fwp_mem_free>
    64e5:	48 8b 3d 34 3b 00 00 	mov    0x3b34(%rip),%rdi        # a020 <stdout@GLIBC_2.2.5>
    64ec:	48 c7 05 c9 41 01 00 	movq   $0x0,0x141c9(%rip)        # 1a6c0 <fwp_cur>
    64f3:	00 00 00 00 
    64f7:	48 c7 05 b6 41 01 00 	movq   $0x0,0x141b6(%rip)        # 1a6b8 <fwp_root>
    64fe:	00 00 00 00 
    6502:	e8 89 c0 ff ff       	call   2590 <fflush@plt>
    6507:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    650e:	00 
    650f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6516:	00 00 
    6518:	0f 85 6f 0e 00 00    	jne    738d <fwp_main_thread+0x143d>
    651e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    6525:	31 c0                	xor    %eax,%eax
    6527:	5b                   	pop    %rbx
    6528:	5d                   	pop    %rbp
    6529:	41 5c                	pop    %r12
    652b:	41 5d                	pop    %r13
    652d:	41 5e                	pop    %r14
    652f:	41 5f                	pop    %r15
    6531:	c3                   	ret
    6532:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6538:	48 89 05 59 41 01 00 	mov    %rax,0x14159(%rip)        # 1a698 <fwp_timers>
    653f:	e9 62 fc ff ff       	jmp    61a6 <fwp_main_thread+0x256>
    6544:	0f 1f 40 00          	nopl   0x0(%rax)
    6548:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    654c:	0f 85 5e fd ff ff    	jne    62b0 <fwp_main_thread+0x360>
    6552:	48 89 ef             	mov    %rbp,%rdi
    6555:	e8 66 ca ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    655a:	e9 51 fd ff ff       	jmp    62b0 <fwp_main_thread+0x360>
    655f:	90                   	nop
    6560:	31 db                	xor    %ebx,%ebx
    6562:	48 83 3d d6 5d 01 00 	cmpq   $0x0,0x15dd6(%rip)        # 1c340 <fwp_state_owners>
    6569:	00 
    656a:	0f 85 71 fc ff ff    	jne    61e1 <fwp_main_thread+0x291>
    6570:	48 8b 3d e1 5d 01 00 	mov    0x15de1(%rip),%rdi        # 1c358 <fwp_state>
    6577:	e8 54 da ff ff       	call   3fd0 <fwp_mem_free>
    657c:	48 c7 05 d1 5d 01 00 	movq   $0x0,0x15dd1(%rip)        # 1c358 <fwp_state>
    6583:	00 00 00 00 
    6587:	48 c7 05 b6 5d 01 00 	movq   $0x0,0x15db6(%rip)        # 1c348 <fwp_state_cap>
    658e:	00 00 00 00 
    6592:	48 85 db             	test   %rbx,%rbx
    6595:	0f 84 4a 0d 00 00    	je     72e5 <fwp_main_thread+0x1395>
    659b:	48 3b 1d 16 41 01 00 	cmp    0x14116(%rip),%rbx        # 1a6b8 <fwp_root>
    65a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    65a9:	00 00 00 00 
    65ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    65b4:	00 00 00 00 
    65b8:	c7 05 be 3a 01 00 00 	movl   $0x0,0x13abe(%rip)        # 1a080 <fwp_exit_code>
    65bf:	00 00 00 
    65c2:	0f 84 39 fc ff ff    	je     6201 <fwp_main_thread+0x2b1>
    65c8:	e9 3e c1 ff ff       	jmp    270b <fwp_main_thread.cold>
    65cd:	0f 1f 00             	nopl   (%rax)
    65d0:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    65d5:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
    65da:	48 8d 05 0f e8 ff ff 	lea    -0x17f1(%rip),%rax        # 4df0 <fwp_drop1>
    65e1:	41 bd ff 7f 00 00    	mov    $0x7fff,%r13d
    65e7:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    65ee:	00 00 
    65f0:	66 48 0f 6e d8       	movq   %rax,%xmm3
    65f5:	48 8b 05 74 5d 01 00 	mov    0x15d74(%rip),%rax        # 1c370 <fwp_cleanups>
    65fc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    6600:	4c 89 25 69 5d 01 00 	mov    %r12,0x15d69(%rip)        # 1c370 <fwp_cleanups>
    6607:	4c 8d 25 d2 40 01 00 	lea    0x140d2(%rip),%r12        # 1a6e0 <fwp_heap>
    660e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6613:	48 8d 05 76 c5 ff ff 	lea    -0x3a8a(%rip),%rax        # 2b90 <fwp_range_release>
    661a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    661f:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    6624:	eb 45                	jmp    666b <fwp_main_thread+0x71b>
    6626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    662d:	00 00 00 
    6630:	80 f9 01             	cmp    $0x1,%cl
    6633:	75 27                	jne    665c <fwp_main_thread+0x70c>
    6635:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6638:	0f b7 c0             	movzwl %ax,%eax
    663b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    663e:	48 0f af c1          	imul   %rcx,%rax
    6642:	48 c1 e8 20          	shr    $0x20,%rax
    6646:	48 39 d0             	cmp    %rdx,%rax
    6649:	73 11                	jae    665c <fwp_main_thread+0x70c>
    664b:	49 01 c7             	add    %rax,%r15
    664e:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6652:	0f 84 c2 0a 00 00    	je     711a <fwp_main_thread+0x11ca>
    6658:	41 c6 07 01          	movb   $0x1,(%r15)
    665c:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    6661:	49 83 ed 01          	sub    $0x1,%r13
    6665:	0f 82 85 00 00 00    	jb     66f0 <fwp_main_thread+0x7a0>
    666b:	48 89 ee             	mov    %rbp,%rsi
    666e:	bf 01 00 00 00       	mov    $0x1,%edi
    6673:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    667a:	00 
    667b:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
    6680:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
    6687:	00 
    6688:	e8 e3 df ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    668d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6694:	00 
    6695:	48 89 c3             	mov    %rax,%rbx
    6698:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    669f:	00 
    66a0:	48 c1 e2 10          	shl    $0x10,%rdx
    66a4:	48 39 d0             	cmp    %rdx,%rax
    66a7:	73 b3                	jae    665c <fwp_main_thread+0x70c>
    66a9:	48 89 c2             	mov    %rax,%rdx
    66ac:	48 c1 ea 10          	shr    $0x10,%rdx
    66b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66b4:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    66bb:	00 
    66bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    66c0:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    66c4:	4d 85 ff             	test   %r15,%r15
    66c7:	74 93                	je     665c <fwp_main_thread+0x70c>
    66c9:	0f b6 0a             	movzbl (%rdx),%ecx
    66cc:	80 f9 02             	cmp    $0x2,%cl
    66cf:	0f 85 5b ff ff ff    	jne    6630 <fwp_main_thread+0x6e0>
    66d5:	66 85 c0             	test   %ax,%ax
    66d8:	0f 84 70 ff ff ff    	je     664e <fwp_main_thread+0x6fe>
    66de:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    66e3:	49 83 ed 01          	sub    $0x1,%r13
    66e7:	73 82                	jae    666b <fwp_main_thread+0x71b>
    66e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66f0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    66f5:	66 0f 6f 05 d3 1d 00 	movdqa 0x1dd3(%rip),%xmm0        # 84d0 <msg.3+0x90>
    66fc:	00 
    66fd:	48 89 ee             	mov    %rbp,%rsi
    6700:	bf 01 00 00 00       	mov    $0x1,%edi
    6705:	48 89 05 64 5c 01 00 	mov    %rax,0x15c64(%rip)        # 1c370 <fwp_cleanups>
    670c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    6713:	00 
    6714:	e8 57 df ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6719:	48 8b 15 98 53 01 00 	mov    0x15398(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    6720:	49 89 c5             	mov    %rax,%r13
    6723:	48 2b 05 66 53 01 00 	sub    0x15366(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    672a:	48 c1 e2 10          	shl    $0x10,%rdx
    672e:	48 39 d0             	cmp    %rdx,%rax
    6731:	73 57                	jae    678a <fwp_main_thread+0x83a>
    6733:	48 89 c2             	mov    %rax,%rdx
    6736:	48 c1 ea 10          	shr    $0x10,%rdx
    673a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    673e:	48 8b 15 93 53 01 00 	mov    0x15393(%rip),%rdx        # 1bad8 <fwp_heap+0x13f8>
    6745:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6749:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    674d:	48 85 ed             	test   %rbp,%rbp
    6750:	74 38                	je     678a <fwp_main_thread+0x83a>
    6752:	0f b6 0a             	movzbl (%rdx),%ecx
    6755:	80 f9 02             	cmp    $0x2,%cl
    6758:	0f 84 ae 09 00 00    	je     710c <fwp_main_thread+0x11bc>
    675e:	80 f9 01             	cmp    $0x1,%cl
    6761:	75 27                	jne    678a <fwp_main_thread+0x83a>
    6763:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6766:	0f b7 c0             	movzwl %ax,%eax
    6769:	8b 52 1c             	mov    0x1c(%rdx),%edx
    676c:	48 0f af c1          	imul   %rcx,%rax
    6770:	48 c1 e8 20          	shr    $0x20,%rax
    6774:	48 39 d0             	cmp    %rdx,%rax
    6777:	73 11                	jae    678a <fwp_main_thread+0x83a>
    6779:	48 01 c5             	add    %rax,%rbp
    677c:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6780:	0f 84 8f 0b 00 00    	je     7315 <fwp_main_thread+0x13c5>
    6786:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    678a:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    678f:	bf 01 00 00 00       	mov    $0x1,%edi
    6794:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    6799:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    67a0:	00 f0 3f 
    67a3:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    67a8:	e8 c3 de ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    67ad:	48 8b 15 04 53 01 00 	mov    0x15304(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    67b4:	49 89 c5             	mov    %rax,%r13
    67b7:	48 2b 05 d2 52 01 00 	sub    0x152d2(%rip),%rax        # 1ba90 <fwp_heap+0x13b0>
    67be:	48 c1 e2 10          	shl    $0x10,%rdx
    67c2:	48 39 d0             	cmp    %rdx,%rax
    67c5:	73 57                	jae    681e <fwp_main_thread+0x8ce>
    67c7:	48 89 c2             	mov    %rax,%rdx
    67ca:	48 c1 ea 10          	shr    $0x10,%rdx
    67ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67d2:	48 8b 15 ff 52 01 00 	mov    0x152ff(%rip),%rdx        # 1bad8 <fwp_heap+0x13f8>
    67d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    67dd:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    67e1:	48 85 ed             	test   %rbp,%rbp
    67e4:	74 38                	je     681e <fwp_main_thread+0x8ce>
    67e6:	0f b6 0a             	movzbl (%rdx),%ecx
    67e9:	80 f9 02             	cmp    $0x2,%cl
    67ec:	0f 84 0c 09 00 00    	je     70fe <fwp_main_thread+0x11ae>
    67f2:	80 f9 01             	cmp    $0x1,%cl
    67f5:	75 27                	jne    681e <fwp_main_thread+0x8ce>
    67f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    67fa:	0f b7 c0             	movzwl %ax,%eax
    67fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6800:	48 0f af c1          	imul   %rcx,%rax
    6804:	48 c1 e8 20          	shr    $0x20,%rax
    6808:	48 39 d0             	cmp    %rdx,%rax
    680b:	73 11                	jae    681e <fwp_main_thread+0x8ce>
    680d:	48 01 c5             	add    %rax,%rbp
    6810:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6814:	0f 84 ee 0a 00 00    	je     7308 <fwp_main_thread+0x13b8>
    681a:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    681e:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    6823:	bf 01 00 00 00       	mov    $0x1,%edi
    6828:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    682d:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    6834:	33 f3 bf 
    6837:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    683c:	e8 2f de ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6841:	48 8b 15 70 52 01 00 	mov    0x15270(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    6848:	48 8b 0d 41 52 01 00 	mov    0x15241(%rip),%rcx        # 1ba90 <fwp_heap+0x13b0>
    684f:	48 89 04 24          	mov    %rax,(%rsp)
    6853:	48 89 d6             	mov    %rdx,%rsi
    6856:	48 29 c8             	sub    %rcx,%rax
    6859:	48 c1 e6 10          	shl    $0x10,%rsi
    685d:	48 39 f0             	cmp    %rsi,%rax
    6860:	73 67                	jae    68c9 <fwp_main_thread+0x979>
    6862:	48 89 c6             	mov    %rax,%rsi
    6865:	48 c1 ee 10          	shr    $0x10,%rsi
    6869:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    686d:	48 8b 35 64 52 01 00 	mov    0x15264(%rip),%rsi        # 1bad8 <fwp_heap+0x13f8>
    6874:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6878:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    687c:	48 85 ed             	test   %rbp,%rbp
    687f:	74 48                	je     68c9 <fwp_main_thread+0x979>
    6881:	0f b6 3e             	movzbl (%rsi),%edi
    6884:	40 80 ff 02          	cmp    $0x2,%dil
    6888:	0f 84 62 08 00 00    	je     70f0 <fwp_main_thread+0x11a0>
    688e:	40 80 ff 01          	cmp    $0x1,%dil
    6892:	75 35                	jne    68c9 <fwp_main_thread+0x979>
    6894:	8b 7e 18             	mov    0x18(%rsi),%edi
    6897:	0f b7 c0             	movzwl %ax,%eax
    689a:	8b 76 1c             	mov    0x1c(%rsi),%esi
    689d:	48 0f af c7          	imul   %rdi,%rax
    68a1:	48 c1 e8 20          	shr    $0x20,%rax
    68a5:	48 39 f0             	cmp    %rsi,%rax
    68a8:	73 1f                	jae    68c9 <fwp_main_thread+0x979>
    68aa:	48 01 c5             	add    %rax,%rbp
    68ad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    68b1:	0f 84 6b 0a 00 00    	je     7322 <fwp_main_thread+0x13d2>
    68b7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    68bb:	48 8b 0d ce 51 01 00 	mov    0x151ce(%rip),%rcx        # 1ba90 <fwp_heap+0x13b0>
    68c2:	48 8b 15 ef 51 01 00 	mov    0x151ef(%rip),%rdx        # 1bab8 <fwp_heap+0x13d8>
    68c9:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    68ce:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    68d3:	66 90                	xchg   %ax,%ax
    68d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68dc:	00 00 00 00 
    68e0:	48 8b 04 24          	mov    (%rsp),%rax
    68e4:	48 c1 e2 10          	shl    $0x10,%rdx
    68e8:	48 29 c8             	sub    %rcx,%rax
    68eb:	48 39 d0             	cmp    %rdx,%rax
    68ee:	73 5e                	jae    694e <fwp_main_thread+0x9fe>
    68f0:	48 89 c2             	mov    %rax,%rdx
    68f3:	48 c1 ea 10          	shr    $0x10,%rdx
    68f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68fb:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6902:	00 
    6903:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6907:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    690b:	48 85 db             	test   %rbx,%rbx
    690e:	74 3e                	je     694e <fwp_main_thread+0x9fe>
    6910:	0f b6 0a             	movzbl (%rdx),%ecx
    6913:	80 f9 02             	cmp    $0x2,%cl
    6916:	0f 84 fc 06 00 00    	je     7018 <fwp_main_thread+0x10c8>
    691c:	80 f9 01             	cmp    $0x1,%cl
    691f:	75 2d                	jne    694e <fwp_main_thread+0x9fe>
    6921:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6924:	0f b7 c0             	movzwl %ax,%eax
    6927:	8b 52 1c             	mov    0x1c(%rdx),%edx
    692a:	48 0f af c1          	imul   %rcx,%rax
    692e:	48 c1 e8 20          	shr    $0x20,%rax
    6932:	48 39 d0             	cmp    %rdx,%rax
    6935:	73 17                	jae    694e <fwp_main_thread+0x9fe>
    6937:	48 01 c3             	add    %rax,%rbx
    693a:	0f b6 03             	movzbl (%rbx),%eax
    693d:	84 c0                	test   %al,%al
    693f:	74 0d                	je     694e <fwp_main_thread+0x9fe>
    6941:	3c fd                	cmp    $0xfd,%al
    6943:	0f 87 5f 08 00 00    	ja     71a8 <fwp_main_thread+0x1258>
    6949:	83 c0 01             	add    $0x1,%eax
    694c:	88 03                	mov    %al,(%rbx)
    694e:	48 8b 1c 24          	mov    (%rsp),%rbx
    6952:	31 ff                	xor    %edi,%edi
    6954:	90                   	nop
    6955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    695c:	00 00 00 00 
    6960:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    6964:	48 83 c7 01          	add    $0x1,%rdi
    6968:	48 85 db             	test   %rbx,%rbx
    696b:	75 f3                	jne    6960 <fwp_main_thread+0xa10>
    696d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    6974:	ff ff 1f 
    6977:	48 39 f8             	cmp    %rdi,%rax
    697a:	0f 82 12 0a 00 00    	jb     7392 <fwp_main_thread+0x1442>
    6980:	e8 1b de ff ff       	call   47a0 <fwp_array_new_packed.constprop.0>
    6985:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    698c:	00 
    698d:	48 89 c5             	mov    %rax,%rbp
    6990:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6997:	00 
    6998:	48 c1 e2 10          	shl    $0x10,%rdx
    699c:	48 39 d0             	cmp    %rdx,%rax
    699f:	73 5a                	jae    69fb <fwp_main_thread+0xaab>
    69a1:	48 89 c2             	mov    %rax,%rdx
    69a4:	48 c1 ea 10          	shr    $0x10,%rdx
    69a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69ac:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    69b3:	00 
    69b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    69b8:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    69bc:	4d 85 ed             	test   %r13,%r13
    69bf:	74 3a                	je     69fb <fwp_main_thread+0xaab>
    69c1:	0f b6 0a             	movzbl (%rdx),%ecx
    69c4:	80 f9 02             	cmp    $0x2,%cl
    69c7:	0f 84 63 06 00 00    	je     7030 <fwp_main_thread+0x10e0>
    69cd:	80 f9 01             	cmp    $0x1,%cl
    69d0:	75 29                	jne    69fb <fwp_main_thread+0xaab>
    69d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69d5:	0f b7 c0             	movzwl %ax,%eax
    69d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69db:	48 0f af c1          	imul   %rcx,%rax
    69df:	48 c1 e8 20          	shr    $0x20,%rax
    69e3:	48 39 d0             	cmp    %rdx,%rax
    69e6:	73 13                	jae    69fb <fwp_main_thread+0xaab>
    69e8:	49 01 c5             	add    %rax,%r13
    69eb:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    69f0:	0f 84 4e 06 00 00    	je     7044 <fwp_main_thread+0x10f4>
    69f6:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    69fb:	4c 8b 0c 24          	mov    (%rsp),%r9
    69ff:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    6a05:	49 8b 71 08          	mov    0x8(%r9),%rsi
    6a09:	4d 8b 69 10          	mov    0x10(%r9),%r13
    6a0d:	4d 89 ca             	mov    %r9,%r10
    6a10:	4c 89 c9             	mov    %r9,%rcx
    6a13:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6a1a:	00 
    6a1b:	48 89 c8             	mov    %rcx,%rax
    6a1e:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6a25:	00 
    6a26:	48 c1 e2 10          	shl    $0x10,%rdx
    6a2a:	48 39 d0             	cmp    %rdx,%rax
    6a2d:	73 7d                	jae    6aac <fwp_main_thread+0xb5c>
    6a2f:	48 89 c2             	mov    %rax,%rdx
    6a32:	48 c1 ea 10          	shr    $0x10,%rdx
    6a36:	48 8d 3c 92          	lea    (%rdx,%rdx,4),%rdi
    6a3a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6a41:	00 
    6a42:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
    6a46:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    6a4a:	48 85 ff             	test   %rdi,%rdi
    6a4d:	74 5d                	je     6aac <fwp_main_thread+0xb5c>
    6a4f:	44 0f b6 02          	movzbl (%rdx),%r8d
    6a53:	41 80 f8 02          	cmp    $0x2,%r8b
    6a57:	0f 84 13 02 00 00    	je     6c70 <fwp_main_thread+0xd20>
    6a5d:	41 80 f8 01          	cmp    $0x1,%r8b
    6a61:	75 49                	jne    6aac <fwp_main_thread+0xb5c>
    6a63:	44 8b 42 18          	mov    0x18(%rdx),%r8d
    6a67:	0f b7 c0             	movzwl %ax,%eax
    6a6a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a6d:	49 0f af c0          	imul   %r8,%rax
    6a71:	48 c1 e8 20          	shr    $0x20,%rax
    6a75:	48 39 d0             	cmp    %rdx,%rax
    6a78:	73 32                	jae    6aac <fwp_main_thread+0xb5c>
    6a7a:	48 01 c7             	add    %rax,%rdi
    6a7d:	80 3f 01             	cmpb   $0x1,(%rdi)
    6a80:	75 2a                	jne    6aac <fwp_main_thread+0xb5c>
    6a82:	e9 41 01 00 00       	jmp    6bc8 <fwp_main_thread+0xc78>
    6a87:	0f 1f 00             	nopl   (%rax)
    6a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a91:	00 00 00 00 
    6a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a9c:	00 00 00 00 
    6aa0:	49 8b 75 08          	mov    0x8(%r13),%rsi
    6aa4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    6aa8:	49 83 c7 01          	add    $0x1,%r15
    6aac:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6ab1:	0f 88 78 08 00 00    	js     732f <fwp_main_thread+0x13df>
    6ab7:	4a 89 74 fd 00       	mov    %rsi,0x0(%rbp,%r15,8)
    6abc:	4d 85 ed             	test   %r13,%r13
    6abf:	75 df                	jne    6aa0 <fwp_main_thread+0xb50>
    6ac1:	4c 89 cf             	mov    %r9,%rdi
    6ac4:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    6ac8:	49 bd ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r13
    6acf:	ff ff 7f 
    6ad2:	e8 a9 e1 ff ff       	call   4c80 <fwp_drop0>
    6ad7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6adb:	be 01 00 00 00       	mov    $0x1,%esi
    6ae0:	4c 89 f7             	mov    %r14,%rdi
    6ae3:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    6aea:	00 00 
    6aec:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    6af1:	e8 ca c3 ff ff       	call   2ec0 <buf_grow>
    6af6:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6afb:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6b00:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    6b04:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6b09:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6b0d:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    6b12:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6b17:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6b1c:	4c 23 6d 00          	and    0x0(%rbp),%r13
    6b20:	75 65                	jne    6b87 <fwp_main_thread+0xc37>
    6b22:	e9 59 01 00 00       	jmp    6c80 <fwp_main_thread+0xd30>
    6b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b2e:	00 00 
    6b30:	48 8b 34 d8          	mov    (%rax,%rbx,8),%rsi
    6b34:	48 8d 15 85 30 00 00 	lea    0x3085(%rip),%rdx        # 9bc0 <d0>
    6b3b:	4c 89 f7             	mov    %r14,%rdi
    6b3e:	48 83 c3 01          	add    $0x1,%rbx
    6b42:	e8 09 e4 ff ff       	call   4f50 <fwp_write.constprop.0>
    6b47:	49 39 dd             	cmp    %rbx,%r13
    6b4a:	0f 84 30 01 00 00    	je     6c80 <fwp_main_thread+0xd30>
    6b50:	be 02 00 00 00       	mov    $0x2,%esi
    6b55:	4c 89 f7             	mov    %r14,%rdi
    6b58:	e8 63 c3 ff ff       	call   2ec0 <buf_grow>
    6b5d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6b62:	ba 2c 20 00 00       	mov    $0x202c,%edx
    6b67:	48 03 44 24 40       	add    0x40(%rsp),%rax
    6b6c:	66 89 10             	mov    %dx,(%rax)
    6b6f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6b74:	48 8d 50 02          	lea    0x2(%rax),%rdx
    6b78:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    6b7d:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6b82:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    6b87:	4c 89 f8             	mov    %r15,%rax
    6b8a:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6b8f:	79 9f                	jns    6b30 <fwp_main_thread+0xbe0>
    6b91:	48 8b 45 10          	mov    0x10(%rbp),%rax
    6b95:	eb 99                	jmp    6b30 <fwp_main_thread+0xbe0>
    6b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b9e:	00 00 
    6ba0:	48 8d 3d 39 cb ff ff 	lea    -0x34c7(%rip),%rdi        # 36e0 <fwp_heap_report>
    6ba7:	e8 24 0a 00 00       	call   75d0 <atexit>
    6bac:	e9 e3 f3 ff ff       	jmp    5f94 <fwp_main_thread+0x44>
    6bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bb8:	e8 33 cc ff ff       	call   37f0 <fwp_heap_init>
    6bbd:	e9 c4 f3 ff ff       	jmp    5f86 <fwp_main_thread+0x36>
    6bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bc8:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6bcd:	0f 88 5c 07 00 00    	js     732f <fwp_main_thread+0x13df>
    6bd3:	4a 89 74 fd 00       	mov    %rsi,0x0(%rbp,%r15,8)
    6bd8:	49 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%rax
    6bdf:	00 
    6be0:	49 2b 8c 24 b0 13 00 	sub    0x13b0(%r12),%rcx
    6be7:	00 
    6be8:	48 c1 e0 10          	shl    $0x10,%rax
    6bec:	48 39 c1             	cmp    %rax,%rcx
    6bef:	73 59                	jae    6c4a <fwp_main_thread+0xcfa>
    6bf1:	48 89 c8             	mov    %rcx,%rax
    6bf4:	48 c1 e8 10          	shr    $0x10,%rax
    6bf8:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6bfc:	49 8b 84 24 f8 13 00 	mov    0x13f8(%r12),%rax
    6c03:	00 
    6c04:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6c08:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6c0c:	48 85 d2             	test   %rdx,%rdx
    6c0f:	74 39                	je     6c4a <fwp_main_thread+0xcfa>
    6c11:	0f b6 30             	movzbl (%rax),%esi
    6c14:	40 80 fe 02          	cmp    $0x2,%sil
    6c18:	0f 84 8a 03 00 00    	je     6fa8 <fwp_main_thread+0x1058>
    6c1e:	40 80 fe 01          	cmp    $0x1,%sil
    6c22:	75 26                	jne    6c4a <fwp_main_thread+0xcfa>
    6c24:	8b 70 18             	mov    0x18(%rax),%esi
    6c27:	0f b7 c9             	movzwl %cx,%ecx
    6c2a:	8b 40 1c             	mov    0x1c(%rax),%eax
    6c2d:	48 0f af ce          	imul   %rsi,%rcx
    6c31:	48 c1 e9 20          	shr    $0x20,%rcx
    6c35:	48 39 c1             	cmp    %rax,%rcx
    6c38:	73 10                	jae    6c4a <fwp_main_thread+0xcfa>
    6c3a:	48 01 ca             	add    %rcx,%rdx
    6c3d:	80 3a 01             	cmpb   $0x1,(%rdx)
    6c40:	75 08                	jne    6c4a <fwp_main_thread+0xcfa>
    6c42:	4c 89 d7             	mov    %r10,%rdi
    6c45:	e8 86 d3 ff ff       	call   3fd0 <fwp_mem_free>
    6c4a:	4d 85 ed             	test   %r13,%r13
    6c4d:	0f 84 67 03 00 00    	je     6fba <fwp_main_thread+0x106a>
    6c53:	49 8b 75 08          	mov    0x8(%r13),%rsi
    6c57:	4d 89 ea             	mov    %r13,%r10
    6c5a:	4c 89 e9             	mov    %r13,%rcx
    6c5d:	4d 89 e9             	mov    %r13,%r9
    6c60:	49 83 c7 01          	add    $0x1,%r15
    6c64:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    6c68:	e9 a6 fd ff ff       	jmp    6a13 <fwp_main_thread+0xac3>
    6c6d:	0f 1f 00             	nopl   (%rax)
    6c70:	66 85 c0             	test   %ax,%ax
    6c73:	0f 85 33 fe ff ff    	jne    6aac <fwp_main_thread+0xb5c>
    6c79:	e9 ff fd ff ff       	jmp    6a7d <fwp_main_thread+0xb2d>
    6c7e:	66 90                	xchg   %ax,%ax
    6c80:	be 01 00 00 00       	mov    $0x1,%esi
    6c85:	4c 89 f7             	mov    %r14,%rdi
    6c88:	e8 33 c2 ff ff       	call   2ec0 <buf_grow>
    6c8d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6c92:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6c97:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    6c9b:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ca0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6ca4:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    6ca9:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    6cae:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6cb3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    6cb8:	48 8d 05 6f 13 00 00 	lea    0x136f(%rip),%rax        # 802e <_IO_stdin_used+0x2e>
    6cbf:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
    6cc4:	48 85 c9             	test   %rcx,%rcx
    6cc7:	48 0f 44 c8          	cmove  %rax,%rcx
    6ccb:	48 83 fb f6          	cmp    $0xfffffffffffffff6,%rbx
    6ccf:	0f 87 c9 06 00 00    	ja     739e <fwp_main_thread+0x144e>
    6cd5:	48 8d 7b 09          	lea    0x9(%rbx),%rdi
    6cd9:	be 01 00 00 00       	mov    $0x1,%esi
    6cde:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6ce3:	e8 68 d8 ff ff       	call   4550 <fwp_heap_alloc>
    6ce8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6ced:	48 89 da             	mov    %rbx,%rdx
    6cf0:	48 89 18             	mov    %rbx,(%rax)
    6cf3:	4c 8d 78 08          	lea    0x8(%rax),%r15
    6cf7:	49 89 c5             	mov    %rax,%r13
    6cfa:	4c 89 ff             	mov    %r15,%rdi
    6cfd:	e8 6e b8 ff ff       	call   2570 <memcpy@plt>
    6d02:	41 c6 44 1d 08 00    	movb   $0x0,0x8(%r13,%rbx,1)
    6d08:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    6d0d:	e8 8e b6 ff ff       	call   23a0 <free@plt>
    6d12:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    6d19:	00 
    6d1a:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6d21:	00 
    6d22:	4c 89 e8             	mov    %r13,%rax
    6d25:	48 29 c8             	sub    %rcx,%rax
    6d28:	48 c1 e2 10          	shl    $0x10,%rdx
    6d2c:	48 39 d0             	cmp    %rdx,%rax
    6d2f:	73 6e                	jae    6d9f <fwp_main_thread+0xe4f>
    6d31:	48 89 c6             	mov    %rax,%rsi
    6d34:	48 c1 ee 10          	shr    $0x10,%rsi
    6d38:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6d3c:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6d43:	00 
    6d44:	48 8d 3c fe          	lea    (%rsi,%rdi,8),%rdi
    6d48:	48 8b 77 20          	mov    0x20(%rdi),%rsi
    6d4c:	48 85 f6             	test   %rsi,%rsi
    6d4f:	74 4e                	je     6d9f <fwp_main_thread+0xe4f>
    6d51:	44 0f b6 07          	movzbl (%rdi),%r8d
    6d55:	41 80 f8 02          	cmp    $0x2,%r8b
    6d59:	0f 84 f9 02 00 00    	je     7058 <fwp_main_thread+0x1108>
    6d5f:	41 80 f8 01          	cmp    $0x1,%r8b
    6d63:	75 3a                	jne    6d9f <fwp_main_thread+0xe4f>
    6d65:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    6d69:	0f b7 c0             	movzwl %ax,%eax
    6d6c:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    6d6f:	49 0f af c0          	imul   %r8,%rax
    6d73:	48 c1 e8 20          	shr    $0x20,%rax
    6d77:	48 39 f8             	cmp    %rdi,%rax
    6d7a:	73 23                	jae    6d9f <fwp_main_thread+0xe4f>
    6d7c:	48 01 c6             	add    %rax,%rsi
    6d7f:	80 3e ff             	cmpb   $0xff,(%rsi)
    6d82:	0f 84 e2 02 00 00    	je     706a <fwp_main_thread+0x111a>
    6d88:	c6 06 01             	movb   $0x1,(%rsi)
    6d8b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6d92:	00 
    6d93:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    6d9a:	00 
    6d9b:	48 c1 e2 10          	shl    $0x10,%rdx
    6d9f:	48 89 e8             	mov    %rbp,%rax
    6da2:	48 29 c8             	sub    %rcx,%rax
    6da5:	48 39 d0             	cmp    %rdx,%rax
    6da8:	73 76                	jae    6e20 <fwp_main_thread+0xed0>
    6daa:	48 89 c2             	mov    %rax,%rdx
    6dad:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    6db4:	00 
    6db5:	48 c1 ea 10          	shr    $0x10,%rdx
    6db9:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6dbd:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    6dc1:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    6dc5:	48 85 d2             	test   %rdx,%rdx
    6dc8:	74 56                	je     6e20 <fwp_main_thread+0xed0>
    6dca:	0f b6 3e             	movzbl (%rsi),%edi
    6dcd:	40 80 ff 02          	cmp    $0x2,%dil
    6dd1:	0f 84 f1 01 00 00    	je     6fc8 <fwp_main_thread+0x1078>
    6dd7:	40 80 ff 01          	cmp    $0x1,%dil
    6ddb:	75 43                	jne    6e20 <fwp_main_thread+0xed0>
    6ddd:	8b 7e 18             	mov    0x18(%rsi),%edi
    6de0:	0f b7 c0             	movzwl %ax,%eax
    6de3:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6de6:	48 0f af c7          	imul   %rdi,%rax
    6dea:	48 c1 e8 20          	shr    $0x20,%rax
    6dee:	48 39 f0             	cmp    %rsi,%rax
    6df1:	73 2d                	jae    6e20 <fwp_main_thread+0xed0>
    6df3:	48 01 c2             	add    %rax,%rdx
    6df6:	0f b6 02             	movzbl (%rdx),%eax
    6df9:	84 c0                	test   %al,%al
    6dfb:	74 23                	je     6e20 <fwp_main_thread+0xed0>
    6dfd:	3c 01                	cmp    $0x1,%al
    6dff:	0f 84 fb 00 00 00    	je     6f00 <fwp_main_thread+0xfb0>
    6e05:	3c ff                	cmp    $0xff,%al
    6e07:	0f 84 1a 03 00 00    	je     7127 <fwp_main_thread+0x11d7>
    6e0d:	83 e8 01             	sub    $0x1,%eax
    6e10:	88 02                	mov    %al,(%rdx)
    6e12:	0f 1f 00             	nopl   (%rax)
    6e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e1c:	00 00 00 00 
    6e20:	49 8b 55 00          	mov    0x0(%r13),%rdx
    6e24:	48 8b 0d 0d 55 01 00 	mov    0x1550d(%rip),%rcx        # 1c338 <fwp_prog_out>
    6e2b:	be 01 00 00 00       	mov    $0x1,%esi
    6e30:	4c 89 ff             	mov    %r15,%rdi
    6e33:	e8 08 b8 ff ff       	call   2640 <fwrite@plt>
    6e38:	48 8b 35 f9 54 01 00 	mov    0x154f9(%rip),%rsi        # 1c338 <fwp_prog_out>
    6e3f:	bf 0a 00 00 00       	mov    $0xa,%edi
    6e44:	e8 77 b6 ff ff       	call   24c0 <fputc@plt>
    6e49:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6e50:	00 
    6e51:	4c 89 e8             	mov    %r13,%rax
    6e54:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6e5b:	00 
    6e5c:	48 c1 e2 10          	shl    $0x10,%rdx
    6e60:	48 39 d0             	cmp    %rdx,%rax
    6e63:	73 6b                	jae    6ed0 <fwp_main_thread+0xf80>
    6e65:	48 89 c2             	mov    %rax,%rdx
    6e68:	48 c1 ea 10          	shr    $0x10,%rdx
    6e6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e70:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6e77:	00 
    6e78:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6e7c:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6e80:	48 85 db             	test   %rbx,%rbx
    6e83:	74 4b                	je     6ed0 <fwp_main_thread+0xf80>
    6e85:	0f b6 0a             	movzbl (%rdx),%ecx
    6e88:	80 f9 02             	cmp    $0x2,%cl
    6e8b:	0f 84 f7 01 00 00    	je     7088 <fwp_main_thread+0x1138>
    6e91:	80 f9 01             	cmp    $0x1,%cl
    6e94:	75 3a                	jne    6ed0 <fwp_main_thread+0xf80>
    6e96:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6e99:	0f b7 c0             	movzwl %ax,%eax
    6e9c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e9f:	48 0f af c1          	imul   %rcx,%rax
    6ea3:	48 c1 e8 20          	shr    $0x20,%rax
    6ea7:	48 39 d0             	cmp    %rdx,%rax
    6eaa:	73 24                	jae    6ed0 <fwp_main_thread+0xf80>
    6eac:	48 01 c3             	add    %rax,%rbx
    6eaf:	0f b6 03             	movzbl (%rbx),%eax
    6eb2:	84 c0                	test   %al,%al
    6eb4:	74 1a                	je     6ed0 <fwp_main_thread+0xf80>
    6eb6:	3c 01                	cmp    $0x1,%al
    6eb8:	0f 84 da 00 00 00    	je     6f98 <fwp_main_thread+0x1048>
    6ebe:	3c ff                	cmp    $0xff,%al
    6ec0:	0f 84 52 03 00 00    	je     7218 <fwp_main_thread+0x12c8>
    6ec6:	83 e8 01             	sub    $0x1,%eax
    6ec9:	88 03                	mov    %al,(%rbx)
    6ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ed0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6ed5:	48 8b 40 10          	mov    0x10(%rax),%rax
    6ed9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6ede:	48 85 c0             	test   %rax,%rax
    6ee1:	0f 84 d9 01 00 00    	je     70c0 <fwp_main_thread+0x1170>
    6ee7:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    6eee:	00 
    6eef:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6ef6:	00 
    6ef7:	e9 e4 f9 ff ff       	jmp    68e0 <fwp_main_thread+0x990>
    6efc:	0f 1f 40 00          	nopl   0x0(%rax)
    6f00:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6f05:	0f 88 d5 00 00 00    	js     6fe0 <fwp_main_thread+0x1090>
    6f0b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6f12:	00 
    6f13:	48 89 e8             	mov    %rbp,%rax
    6f16:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6f1d:	00 
    6f1e:	48 c1 e2 10          	shl    $0x10,%rdx
    6f22:	48 39 d0             	cmp    %rdx,%rax
    6f25:	0f 83 f5 fe ff ff    	jae    6e20 <fwp_main_thread+0xed0>
    6f2b:	48 89 c2             	mov    %rax,%rdx
    6f2e:	48 c1 ea 10          	shr    $0x10,%rdx
    6f32:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6f36:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6f3a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f3e:	48 85 c9             	test   %rcx,%rcx
    6f41:	0f 84 d9 fe ff ff    	je     6e20 <fwp_main_thread+0xed0>
    6f47:	0f b6 32             	movzbl (%rdx),%esi
    6f4a:	40 80 fe 02          	cmp    $0x2,%sil
    6f4e:	0f 84 4c 01 00 00    	je     70a0 <fwp_main_thread+0x1150>
    6f54:	40 80 fe 01          	cmp    $0x1,%sil
    6f58:	0f 85 c2 fe ff ff    	jne    6e20 <fwp_main_thread+0xed0>
    6f5e:	8b 72 18             	mov    0x18(%rdx),%esi
    6f61:	0f b7 c0             	movzwl %ax,%eax
    6f64:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6f67:	48 0f af c6          	imul   %rsi,%rax
    6f6b:	48 c1 e8 20          	shr    $0x20,%rax
    6f6f:	48 39 d0             	cmp    %rdx,%rax
    6f72:	0f 83 a8 fe ff ff    	jae    6e20 <fwp_main_thread+0xed0>
    6f78:	48 01 c1             	add    %rax,%rcx
    6f7b:	80 39 01             	cmpb   $0x1,(%rcx)
    6f7e:	0f 85 9c fe ff ff    	jne    6e20 <fwp_main_thread+0xed0>
    6f84:	48 89 ef             	mov    %rbp,%rdi
    6f87:	e8 44 d0 ff ff       	call   3fd0 <fwp_mem_free>
    6f8c:	e9 8f fe ff ff       	jmp    6e20 <fwp_main_thread+0xed0>
    6f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f98:	4c 89 ef             	mov    %r13,%rdi
    6f9b:	e8 30 d5 ff ff       	call   44d0 <fwp_rc_free_arr>
    6fa0:	e9 2b ff ff ff       	jmp    6ed0 <fwp_main_thread+0xf80>
    6fa5:	0f 1f 00             	nopl   (%rax)
    6fa8:	66 85 c9             	test   %cx,%cx
    6fab:	0f 84 8c fc ff ff    	je     6c3d <fwp_main_thread+0xced>
    6fb1:	4d 85 ed             	test   %r13,%r13
    6fb4:	0f 85 99 fc ff ff    	jne    6c53 <fwp_main_thread+0xd03>
    6fba:	45 31 c9             	xor    %r9d,%r9d
    6fbd:	e9 ff fa ff ff       	jmp    6ac1 <fwp_main_thread+0xb71>
    6fc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fc8:	66 85 c0             	test   %ax,%ax
    6fcb:	0f 85 4f fe ff ff    	jne    6e20 <fwp_main_thread+0xed0>
    6fd1:	e9 20 fe ff ff       	jmp    6df6 <fwp_main_thread+0xea6>
    6fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fdd:	00 00 00 
    6fe0:	48 89 ef             	mov    %rbp,%rdi
    6fe3:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    6fe7:	e8 e4 d4 ff ff       	call   44d0 <fwp_rc_free_arr>
    6fec:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6ff3:	00 
    6ff4:	48 89 d8             	mov    %rbx,%rax
    6ff7:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6ffe:	00 
    6fff:	48 c1 e2 10          	shl    $0x10,%rdx
    7003:	48 39 d0             	cmp    %rdx,%rax
    7006:	0f 83 14 fe ff ff    	jae    6e20 <fwp_main_thread+0xed0>
    700c:	48 89 dd             	mov    %rbx,%rbp
    700f:	e9 96 fd ff ff       	jmp    6daa <fwp_main_thread+0xe5a>
    7014:	0f 1f 40 00          	nopl   0x0(%rax)
    7018:	66 85 c0             	test   %ax,%ax
    701b:	0f 85 2d f9 ff ff    	jne    694e <fwp_main_thread+0x9fe>
    7021:	e9 14 f9 ff ff       	jmp    693a <fwp_main_thread+0x9ea>
    7026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    702d:	00 00 00 
    7030:	66 85 c0             	test   %ax,%ax
    7033:	0f 85 c2 f9 ff ff    	jne    69fb <fwp_main_thread+0xaab>
    7039:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    703e:	0f 85 b2 f9 ff ff    	jne    69f6 <fwp_main_thread+0xaa6>
    7044:	4c 89 ef             	mov    %r13,%rdi
    7047:	e8 44 cd ff ff       	call   3d90 <fwp_rc_forget_slot>
    704c:	e9 a5 f9 ff ff       	jmp    69f6 <fwp_main_thread+0xaa6>
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	66 85 c0             	test   %ax,%ax
    705b:	0f 85 3e fd ff ff    	jne    6d9f <fwp_main_thread+0xe4f>
    7061:	80 3e ff             	cmpb   $0xff,(%rsi)
    7064:	0f 85 1e fd ff ff    	jne    6d88 <fwp_main_thread+0xe38>
    706a:	48 89 f7             	mov    %rsi,%rdi
    706d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    7072:	e8 19 cd ff ff       	call   3d90 <fwp_rc_forget_slot>
    7077:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    707c:	e9 07 fd ff ff       	jmp    6d88 <fwp_main_thread+0xe38>
    7081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7088:	66 85 c0             	test   %ax,%ax
    708b:	0f 85 3f fe ff ff    	jne    6ed0 <fwp_main_thread+0xf80>
    7091:	e9 19 fe ff ff       	jmp    6eaf <fwp_main_thread+0xf5f>
    7096:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    709d:	00 00 00 
    70a0:	66 85 c0             	test   %ax,%ax
    70a3:	0f 85 77 fd ff ff    	jne    6e20 <fwp_main_thread+0xed0>
    70a9:	e9 cd fe ff ff       	jmp    6f7b <fwp_main_thread+0x102b>
    70ae:	66 90                	xchg   %ax,%ax
    70b0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    70b4:	e9 62 f0 ff ff       	jmp    611b <fwp_main_thread+0x1cb>
    70b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70c0:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    70c5:	48 8b 3c 24          	mov    (%rsp),%rdi
    70c9:	e8 b2 db ff ff       	call   4c80 <fwp_drop0>
    70ce:	48 89 df             	mov    %rbx,%rdi
    70d1:	e8 aa db ff ff       	call   4c80 <fwp_drop0>
    70d6:	48 c7 05 7f 2f 00 00 	movq   $0x0,0x2f7f(%rip)        # a060 <v.1>
    70dd:	00 00 00 00 
    70e1:	c7 05 7d 2f 00 00 01 	movl   $0x1,0x2f7d(%rip)        # a068 <st.2>
    70e8:	00 00 00 
    70eb:	e9 77 ef ff ff       	jmp    6067 <fwp_main_thread+0x117>
    70f0:	66 85 c0             	test   %ax,%ax
    70f3:	0f 85 d0 f7 ff ff    	jne    68c9 <fwp_main_thread+0x979>
    70f9:	e9 af f7 ff ff       	jmp    68ad <fwp_main_thread+0x95d>
    70fe:	66 85 c0             	test   %ax,%ax
    7101:	0f 85 17 f7 ff ff    	jne    681e <fwp_main_thread+0x8ce>
    7107:	e9 04 f7 ff ff       	jmp    6810 <fwp_main_thread+0x8c0>
    710c:	66 85 c0             	test   %ax,%ax
    710f:	0f 85 75 f6 ff ff    	jne    678a <fwp_main_thread+0x83a>
    7115:	e9 62 f6 ff ff       	jmp    677c <fwp_main_thread+0x82c>
    711a:	4c 89 ff             	mov    %r15,%rdi
    711d:	e8 6e cc ff ff       	call   3d90 <fwp_rc_forget_slot>
    7122:	e9 31 f5 ff ff       	jmp    6658 <fwp_main_thread+0x708>
    7127:	48 89 d1             	mov    %rdx,%rcx
    712a:	48 c1 e9 11          	shr    $0x11,%rcx
    712e:	48 31 d1             	xor    %rdx,%rcx
    7131:	48 89 c8             	mov    %rcx,%rax
    7134:	48 c1 e8 09          	shr    $0x9,%rax
    7138:	48 31 c1             	xor    %rax,%rcx
    713b:	0f b6 c9             	movzbl %cl,%ecx
    713e:	49 8b 84 cc 48 14 00 	mov    0x1448(%r12,%rcx,8),%rax
    7145:	00 
    7146:	48 85 c0             	test   %rax,%rax
    7149:	75 22                	jne    716d <fwp_main_thread+0x121d>
    714b:	e9 11 02 00 00       	jmp    7361 <fwp_main_thread+0x1411>
    7150:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    715c:	00 00 00 00 
    7160:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7164:	48 85 c0             	test   %rax,%rax
    7167:	0f 84 f4 01 00 00    	je     7361 <fwp_main_thread+0x1411>
    716d:	48 89 c1             	mov    %rax,%rcx
    7170:	48 3b 10             	cmp    (%rax),%rdx
    7173:	75 eb                	jne    7160 <fwp_main_thread+0x1210>
    7175:	48 8b 48 08          	mov    0x8(%rax),%rcx
    7179:	48 83 e9 01          	sub    $0x1,%rcx
    717d:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7181:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7188:	0f 85 92 fc ff ff    	jne    6e20 <fwp_main_thread+0xed0>
    718e:	48 89 d7             	mov    %rdx,%rdi
    7191:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    7196:	e8 f5 cb ff ff       	call   3d90 <fwp_rc_forget_slot>
    719b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    71a0:	c6 02 fe             	movb   $0xfe,(%rdx)
    71a3:	e9 78 fc ff ff       	jmp    6e20 <fwp_main_thread+0xed0>
    71a8:	48 89 d9             	mov    %rbx,%rcx
    71ab:	48 c1 e9 11          	shr    $0x11,%rcx
    71af:	48 31 d9             	xor    %rbx,%rcx
    71b2:	48 89 ca             	mov    %rcx,%rdx
    71b5:	48 c1 ea 09          	shr    $0x9,%rdx
    71b9:	48 31 d1             	xor    %rdx,%rcx
    71bc:	0f b6 c9             	movzbl %cl,%ecx
    71bf:	49 8d ac cc 48 14 00 	lea    0x1448(%r12,%rcx,8),%rbp
    71c6:	00 
    71c7:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    71cb:	49 83 bc cc 48 14 00 	cmpq   $0x0,0x1448(%r12,%rcx,8)
    71d2:	00 00 
    71d4:	75 1a                	jne    71f0 <fwp_main_thread+0x12a0>
    71d6:	e9 60 01 00 00       	jmp    733b <fwp_main_thread+0x13eb>
    71db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    71e0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    71e4:	48 85 c9             	test   %rcx,%rcx
    71e7:	0f 84 b1 00 00 00    	je     729e <fwp_main_thread+0x134e>
    71ed:	48 89 ca             	mov    %rcx,%rdx
    71f0:	48 39 1a             	cmp    %rbx,(%rdx)
    71f3:	75 eb                	jne    71e0 <fwp_main_thread+0x1290>
    71f5:	3c fe                	cmp    $0xfe,%al
    71f7:	0f 84 4b 01 00 00    	je     7348 <fwp_main_thread+0x13f8>
    71fd:	48 8b 42 08          	mov    0x8(%rdx),%rax
    7201:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    7205:	0f 84 71 01 00 00    	je     737c <fwp_main_thread+0x142c>
    720b:	48 83 c0 01          	add    $0x1,%rax
    720f:	48 89 42 08          	mov    %rax,0x8(%rdx)
    7213:	e9 36 f7 ff ff       	jmp    694e <fwp_main_thread+0x9fe>
    7218:	48 89 da             	mov    %rbx,%rdx
    721b:	48 c1 ea 11          	shr    $0x11,%rdx
    721f:	48 31 da             	xor    %rbx,%rdx
    7222:	48 89 d0             	mov    %rdx,%rax
    7225:	48 c1 e8 09          	shr    $0x9,%rax
    7229:	48 31 c2             	xor    %rax,%rdx
    722c:	0f b6 d2             	movzbl %dl,%edx
    722f:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    7236:	00 
    7237:	48 85 c0             	test   %rax,%rax
    723a:	75 31                	jne    726d <fwp_main_thread+0x131d>
    723c:	e9 20 01 00 00       	jmp    7361 <fwp_main_thread+0x1411>
    7241:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7248:	00 00 
    724a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7251:	00 00 00 00 
    7255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    725c:	00 00 00 00 
    7260:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	0f 84 f4 00 00 00    	je     7361 <fwp_main_thread+0x1411>
    726d:	48 89 c2             	mov    %rax,%rdx
    7270:	48 3b 18             	cmp    (%rax),%rbx
    7273:	75 eb                	jne    7260 <fwp_main_thread+0x1310>
    7275:	48 8b 48 08          	mov    0x8(%rax),%rcx
    7279:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    727d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7281:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7288:	0f 85 42 fc ff ff    	jne    6ed0 <fwp_main_thread+0xf80>
    728e:	48 89 df             	mov    %rbx,%rdi
    7291:	e8 fa ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    7296:	c6 03 fe             	movb   $0xfe,(%rbx)
    7299:	e9 32 fc ff ff       	jmp    6ed0 <fwp_main_thread+0xf80>
    729e:	3c fe                	cmp    $0xfe,%al
    72a0:	0f 85 bb 00 00 00    	jne    7361 <fwp_main_thread+0x1411>
    72a6:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    72aa:	bf 18 00 00 00       	mov    $0x18,%edi
    72af:	e8 cc b2 ff ff       	call   2580 <malloc@plt>
    72b4:	48 85 c0             	test   %rax,%rax
    72b7:	0f 84 cb 00 00 00    	je     7388 <fwp_main_thread+0x1438>
    72bd:	48 89 18             	mov    %rbx,(%rax)
    72c0:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    72c7:	00 
    72c8:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    72cf:	00 
    72d0:	48 89 45 00          	mov    %rax,0x0(%rbp)
    72d4:	c6 03 ff             	movb   $0xff,(%rbx)
    72d7:	49 83 84 24 48 1c 00 	addq   $0x1,0x1c48(%r12)
    72de:	00 01 
    72e0:	e9 69 f6 ff ff       	jmp    694e <fwp_main_thread+0x9fe>
    72e5:	48 83 3d cb 33 01 00 	cmpq   $0x0,0x133cb(%rip)        # 1a6b8 <fwp_root>
    72ec:	00 
    72ed:	c7 05 89 2d 01 00 00 	movl   $0x0,0x12d89(%rip)        # 1a080 <fwp_exit_code>
    72f4:	00 00 00 
    72f7:	0f 84 a9 f0 ff ff    	je     63a6 <fwp_main_thread+0x456>
    72fd:	e9 09 b4 ff ff       	jmp    270b <fwp_main_thread.cold>
    7302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7308:	48 89 ef             	mov    %rbp,%rdi
    730b:	e8 80 ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    7310:	e9 05 f5 ff ff       	jmp    681a <fwp_main_thread+0x8ca>
    7315:	48 89 ef             	mov    %rbp,%rdi
    7318:	e8 73 ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    731d:	e9 64 f4 ff ff       	jmp    6786 <fwp_main_thread+0x836>
    7322:	48 89 ef             	mov    %rbp,%rdi
    7325:	e8 66 ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    732a:	e9 88 f5 ff ff       	jmp    68b7 <fwp_main_thread+0x967>
    732f:	48 8d 3d ca 0f 00 00 	lea    0xfca(%rip),%rdi        # 8300 <_IO_stdin_used+0x300>
    7336:	e8 75 bd ff ff       	call   30b0 <fwp_trap>
    733b:	3c fe                	cmp    $0xfe,%al
    733d:	75 19                	jne    7358 <fwp_main_thread+0x1408>
    733f:	48 85 d2             	test   %rdx,%rdx
    7342:	0f 84 62 ff ff ff    	je     72aa <fwp_main_thread+0x135a>
    7348:	48 8d 3d 89 0f 00 00 	lea    0xf89(%rip),%rdi        # 82d8 <_IO_stdin_used+0x2d8>
    734f:	e8 5c bd ff ff       	call   30b0 <fwp_trap>
    7354:	0f 1f 40 00          	nopl   0x0(%rax)
    7358:	48 85 d2             	test   %rdx,%rdx
    735b:	0f 85 9c fe ff ff    	jne    71fd <fwp_main_thread+0x12ad>
    7361:	48 8d 3d 20 0f 00 00 	lea    0xf20(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    7368:	e8 43 bd ff ff       	call   30b0 <fwp_trap>
    736d:	0f 1f 00             	nopl   (%rax)
    7370:	48 8d 3d 39 0f 00 00 	lea    0xf39(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    7377:	e8 34 bd ff ff       	call   30b0 <fwp_trap>
    737c:	48 8d 3d c1 0d 00 00 	lea    0xdc1(%rip),%rdi        # 8144 <_IO_stdin_used+0x144>
    7383:	e8 28 bd ff ff       	call   30b0 <fwp_trap>
    7388:	e8 73 b8 ff ff       	call   2c00 <fwp_heap_oom>
    738d:	e8 ae b0 ff ff       	call   2440 <__stack_chk_fail@plt>
    7392:	48 8d 3d 0c 0d 00 00 	lea    0xd0c(%rip),%rdi        # 80a5 <_IO_stdin_used+0xa5>
    7399:	e8 12 bd ff ff       	call   30b0 <fwp_trap>
    739e:	48 8d 3d b8 0d 00 00 	lea    0xdb8(%rip),%rdi        # 815d <_IO_stdin_used+0x15d>
    73a5:	e8 06 bd ff ff       	call   30b0 <fwp_trap>
    73aa:	e9 5c b3 ff ff       	jmp    270b <fwp_main_thread.cold>
    73af:	e9 57 b3 ff ff       	jmp    270b <fwp_main_thread.cold>
    73b4:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    73bb:	00 00 00 
    73be:	66 90                	xchg   %ax,%ax

00000000000073c0 <__divmodti4>:
    73c0:	f3 0f 1e fa          	endbr64
    73c4:	55                   	push   %rbp
    73c5:	49 89 f1             	mov    %rsi,%r9
    73c8:	49 89 d2             	mov    %rdx,%r10
    73cb:	48 89 fe             	mov    %rdi,%rsi
    73ce:	49 89 cb             	mov    %rcx,%r11
    73d1:	48 89 e5             	mov    %rsp,%rbp
    73d4:	41 57                	push   %r15
    73d6:	41 56                	push   %r14
    73d8:	41 55                	push   %r13
    73da:	41 54                	push   %r12
    73dc:	53                   	push   %rbx
    73dd:	4c 89 c3             	mov    %r8,%rbx
    73e0:	45 31 c0             	xor    %r8d,%r8d
    73e3:	4d 85 c9             	test   %r9,%r9
    73e6:	79 12                	jns    73fa <__divmodti4+0x3a>
    73e8:	31 ff                	xor    %edi,%edi
    73ea:	48 f7 de             	neg    %rsi
    73ed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    73f4:	4c 19 cf             	sbb    %r9,%rdi
    73f7:	49 89 f9             	mov    %rdi,%r9
    73fa:	4c 89 d8             	mov    %r11,%rax
    73fd:	4d 85 db             	test   %r11,%r11
    7400:	0f 88 1a 01 00 00    	js     7520 <__divmodti4+0x160>
    7406:	4c 89 d9             	mov    %r11,%rcx
    7409:	49 89 f3             	mov    %rsi,%r11
    740c:	75 62                	jne    7470 <__divmodti4+0xb0>
    740e:	4d 89 c4             	mov    %r8,%r12
    7411:	4d 39 d1             	cmp    %r10,%r9
    7414:	0f 83 46 01 00 00    	jae    7560 <__divmodti4+0x1a0>
    741a:	4c 89 d8             	mov    %r11,%rax
    741d:	4c 89 ca             	mov    %r9,%rdx
    7420:	49 f7 f2             	div    %r10
    7423:	49 89 c3             	mov    %rax,%r11
    7426:	31 c0                	xor    %eax,%eax
    7428:	48 89 d6             	mov    %rdx,%rsi
    742b:	31 ff                	xor    %edi,%edi
    742d:	4c 89 d9             	mov    %r11,%rcx
    7430:	48 89 c2             	mov    %rax,%rdx
    7433:	48 89 c8             	mov    %rcx,%rax
    7436:	4d 85 e4             	test   %r12,%r12
    7439:	74 0a                	je     7445 <__divmodti4+0x85>
    743b:	48 f7 d8             	neg    %rax
    743e:	48 83 d2 00          	adc    $0x0,%rdx
    7442:	48 f7 da             	neg    %rdx
    7445:	4d 85 c0             	test   %r8,%r8
    7448:	74 0a                	je     7454 <__divmodti4+0x94>
    744a:	48 f7 de             	neg    %rsi
    744d:	48 83 d7 00          	adc    $0x0,%rdi
    7451:	48 f7 df             	neg    %rdi
    7454:	48 89 33             	mov    %rsi,(%rbx)
    7457:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    745b:	5b                   	pop    %rbx
    745c:	41 5c                	pop    %r12
    745e:	41 5d                	pop    %r13
    7460:	41 5e                	pop    %r14
    7462:	41 5f                	pop    %r15
    7464:	5d                   	pop    %rbp
    7465:	c3                   	ret
    7466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    746d:	00 00 00 
    7470:	4d 89 c4             	mov    %r8,%r12
    7473:	49 39 c1             	cmp    %rax,%r9
    7476:	0f 82 ce 00 00 00    	jb     754a <__divmodti4+0x18a>
    747c:	31 ff                	xor    %edi,%edi
    747e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    7483:	48 63 c7             	movslq %edi,%rax
    7486:	be 40 00 00 00       	mov    $0x40,%esi
    748b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    7490:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    7495:	48 29 c6             	sub    %rax,%rsi
    7498:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    749d:	48 09 c8             	or     %rcx,%rax
    74a0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    74a5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    74aa:	49 89 c6             	mov    %rax,%r14
    74ad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    74b1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    74b6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    74bb:	49 09 c1             	or     %rax,%r9
    74be:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    74c2:	4c 89 c8             	mov    %r9,%rax
    74c5:	49 f7 f6             	div    %r14
    74c8:	48 89 d1             	mov    %rdx,%rcx
    74cb:	49 89 c3             	mov    %rax,%r11
    74ce:	49 89 c1             	mov    %rax,%r9
    74d1:	49 f7 e2             	mul    %r10
    74d4:	49 89 c6             	mov    %rax,%r14
    74d7:	49 89 d2             	mov    %rdx,%r10
    74da:	48 39 d1             	cmp    %rdx,%rcx
    74dd:	72 07                	jb     74e6 <__divmodti4+0x126>
    74df:	75 17                	jne    74f8 <__divmodti4+0x138>
    74e1:	49 39 c7             	cmp    %rax,%r15
    74e4:	73 12                	jae    74f8 <__divmodti4+0x138>
    74e6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    74ea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    74ee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    74f2:	49 89 d2             	mov    %rdx,%r10
    74f5:	49 89 c6             	mov    %rax,%r14
    74f8:	4c 89 f8             	mov    %r15,%rax
    74fb:	4c 29 f0             	sub    %r14,%rax
    74fe:	4c 19 d1             	sbb    %r10,%rcx
    7501:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    7506:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    750b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    7510:	48 09 c6             	or     %rax,%rsi
    7513:	48 89 cf             	mov    %rcx,%rdi
    7516:	31 c0                	xor    %eax,%eax
    7518:	4c 89 c9             	mov    %r9,%rcx
    751b:	e9 10 ff ff ff       	jmp    7430 <__divmodti4+0x70>
    7520:	4c 89 d0             	mov    %r10,%rax
    7523:	4c 89 da             	mov    %r11,%rdx
    7526:	4d 89 c4             	mov    %r8,%r12
    7529:	49 89 f3             	mov    %rsi,%r11
    752c:	48 f7 d8             	neg    %rax
    752f:	49 f7 d4             	not    %r12
    7532:	48 83 d2 00          	adc    $0x0,%rdx
    7536:	49 89 c2             	mov    %rax,%r10
    7539:	48 f7 da             	neg    %rdx
    753c:	48 89 d1             	mov    %rdx,%rcx
    753f:	0f 84 cc fe ff ff    	je     7411 <__divmodti4+0x51>
    7545:	49 39 d1             	cmp    %rdx,%r9
    7548:	73 46                	jae    7590 <__divmodti4+0x1d0>
    754a:	4c 89 cf             	mov    %r9,%rdi
    754d:	31 c0                	xor    %eax,%eax
    754f:	31 c9                	xor    %ecx,%ecx
    7551:	e9 da fe ff ff       	jmp    7430 <__divmodti4+0x70>
    7556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    755d:	00 00 00 
    7560:	4d 85 d2             	test   %r10,%r10
    7563:	75 0d                	jne    7572 <__divmodti4+0x1b2>
    7565:	b8 01 00 00 00       	mov    $0x1,%eax
    756a:	31 d2                	xor    %edx,%edx
    756c:	49 f7 f2             	div    %r10
    756f:	49 89 c2             	mov    %rax,%r10
    7572:	4c 89 c8             	mov    %r9,%rax
    7575:	31 d2                	xor    %edx,%edx
    7577:	49 f7 f2             	div    %r10
    757a:	49 89 c1             	mov    %rax,%r9
    757d:	4c 89 d8             	mov    %r11,%rax
    7580:	49 f7 f2             	div    %r10
    7583:	49 89 c3             	mov    %rax,%r11
    7586:	4c 89 c8             	mov    %r9,%rax
    7589:	e9 9a fe ff ff       	jmp    7428 <__divmodti4+0x68>
    758e:	66 90                	xchg   %ax,%ax
    7590:	45 31 f6             	xor    %r14d,%r14d
    7593:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    7598:	44 89 f7             	mov    %r14d,%edi
    759b:	45 85 f6             	test   %r14d,%r14d
    759e:	0f 85 df fe ff ff    	jne    7483 <__divmodti4+0xc3>
    75a4:	4c 39 ca             	cmp    %r9,%rdx
    75a7:	72 17                	jb     75c0 <__divmodti4+0x200>
    75a9:	31 c9                	xor    %ecx,%ecx
    75ab:	48 39 c6             	cmp    %rax,%rsi
    75ae:	73 10                	jae    75c0 <__divmodti4+0x200>
    75b0:	4c 89 cf             	mov    %r9,%rdi
    75b3:	31 c0                	xor    %eax,%eax
    75b5:	e9 76 fe ff ff       	jmp    7430 <__divmodti4+0x70>
    75ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75c0:	4c 89 de             	mov    %r11,%rsi
    75c3:	b9 01 00 00 00       	mov    $0x1,%ecx
    75c8:	48 29 c6             	sub    %rax,%rsi
    75cb:	49 19 d1             	sbb    %rdx,%r9
    75ce:	eb e0                	jmp    75b0 <__divmodti4+0x1f0>

00000000000075d0 <atexit>:
    75d0:	f3 0f 1e fa          	endbr64
    75d4:	48 8b 15 2d 2a 00 00 	mov    0x2a2d(%rip),%rdx        # a008 <__dso_handle>
    75db:	31 f6                	xor    %esi,%esi
    75dd:	e9 3e b0 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000075e4 <_fini>:
    75e4:	f3 0f 1e fa          	endbr64
    75e8:	48 83 ec 08          	sub    $0x8,%rsp
    75ec:	48 83 c4 08          	add    $0x8,%rsp
    75f0:	c3                   	ret
