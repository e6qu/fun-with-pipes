
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#include <stdio.h>
#include <unistd.h>
__attribute__((noinline)) int capture_control(void) {
    void *frames[64];
    int count = unw_backtrace(frames, 64);
    unw_context_t context;
    unw_cursor_t cursor;
    int context_status = unw_getcontext(&context);
    int init_status = unw_init_local(&cursor, &context);
    int steps = 0, status = init_status;
    if (!context_status && !init_status)
        while ((status = unw_step(&cursor)) > 0 && steps < 64) steps++;
    printf("{\"frames\":%d,\"steps\":%d,\"stepStatus\":%d,\"contextStatus\":%d,\"initStatus\":%d,\"pageBytes\":%ld}\n",
           count, steps, status, context_status, init_status, sysconf(_SC_PAGESIZE));
    return count;
}
__attribute__((noinline)) int caller_control(void) {
    int count = capture_control();
    return count + 1;
}
int main(void) { return caller_control() < 0; }
