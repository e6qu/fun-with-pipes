
#include <stdlib.h>
#include <stdio.h>
static volatile size_t control_size = 1048576;
__attribute__((noinline)) void *allocate_control(size_t index) {
    volatile unsigned char *p = malloc(control_size + index);
    if (!p) abort();
    p[0] = (unsigned char)index;
    return (void *)p;
}
int main(int argc, char **argv) {
    (void)argv;
    void *p[3];
    unsigned sum = 0;
    for(size_t i=0;i<3;i++) p[i]=allocate_control(i);
    for(size_t i=0;i<3;i++) sum+=*(volatile unsigned char *)p[i];
    for(size_t i=0;i<3;i++) if(argc==1 || i!=2) free(p[i]);
    printf("%u\n",sum);
    return 0;
}
