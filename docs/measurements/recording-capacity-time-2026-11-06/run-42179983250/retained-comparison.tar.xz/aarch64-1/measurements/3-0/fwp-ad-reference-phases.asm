
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000025 	adrp	x5, 9000 <fwp_main_thread+0xb30>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	912c80a5 	add	x5, x5, #0xb20
    2b20:	f0000024 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	912ca084 	add	x4, x4, #0xb28
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	94000590 	bl	4190 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b7c:	f947ee94 	ldr	x20, [x20, #4056]
    2b80:	f9400282 	ldr	x2, [x20]
    2b84:	f90043f5 	str	x21, [sp, #128]
    2b88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b8c:	910182a1 	add	x1, x21, #0x60
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12820>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9006420 	str	x0, [x1, #200]
    2bac:	94000799 	bl	4a10 <fwp_now_ns>
    2bb0:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2bb4:	91360000 	add	x0, x0, #0xd80
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f3 	mov	x19, x0
    2bc8:	350008c1 	cbnz	w1, 2ce0 <main+0x180>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	350007e0 	cbnz	w0, 2cd4 <main+0x174>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b5000620 	cbnz	x0, 2cc8 <main+0x168>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f3 	add	x19, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1303e0 	mov	x0, x19
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007a0 	cbnz	w0, 2d28 <main+0x1c8>
    2c38:	aa1303e0 	mov	x0, x19
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000660 	cbnz	w0, 2d10 <main+0x1b0>
    2c48:	aa1303e1 	mov	x1, x19
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xb1c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91134042 	add	x2, x2, #0x4d0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	2a0103f3 	mov	w19, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	35000613 	cbnz	w19, 2d34 <main+0x1d4>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	910182b5 	add	x21, x21, #0x60
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435aa0 	ldr	w0, [x21, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	54000481 	b.ne	2d40 <main+0x1e0>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2ccc:	9136c000 	add	x0, x0, #0xdb0
    2cd0:	94000530 	bl	4190 <fwp_trap>
    2cd4:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2cd8:	91364000 	add	x0, x0, #0xd90
    2cdc:	9400052d 	bl	4190 <fwp_trap>
    2ce0:	910003e1 	mov	x1, sp
    2ce4:	52800142 	mov	w2, #0xa                   	// #10
    2ce8:	97ffff46 	bl	2a00 <strtoull@plt>
    2cec:	f94003e0 	ldr	x0, [sp]
    2cf0:	39400000 	ldrb	w0, [x0]
    2cf4:	35fff6c0 	cbnz	w0, 2bcc <main+0x6c>
    2cf8:	39400260 	ldrb	w0, [x19]
    2cfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2d00:	5100ac00 	sub	w0, w0, #0x2b
    2d04:	6a01001f 	tst	w0, w1
    2d08:	54fff620 	b.eq	2bcc <main+0x6c>  // b.none
    2d0c:	17ffffbf 	b	2c08 <main+0xa8>
    2d10:	aa1303e0 	mov	x0, x19
    2d14:	97fffeeb 	bl	28c0 <pthread_attr_destroy@plt>
    2d18:	35000160 	cbnz	w0, 2d44 <main+0x1e4>
    2d1c:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2d20:	91382000 	add	x0, x0, #0xe08
    2d24:	9400051b 	bl	4190 <fwp_trap>
    2d28:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2d2c:	91376000 	add	x0, x0, #0xdd8
    2d30:	94000518 	bl	4190 <fwp_trap>
    2d34:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    2d38:	9138c000 	add	x0, x0, #0xe30
    2d3c:	94000515 	bl	4190 <fwp_trap>
    2d40:	97fffef4 	bl	2910 <__stack_chk_fail@plt>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91014000 	add	x0, x0, #0x50
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91014021 	add	x1, x1, #0x50
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91014000 	add	x0, x0, #0x50
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91014021 	add	x1, x1, #0x50
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39414260 	ldrb	w0, [x19, #80]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39014260 	strb	w0, [x19, #80]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x860>
    2f34:	9112c021 	add	x1, x1, #0x4b0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403084 	ldr	x4, [x4, #96]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403063 	ldr	x3, [x3, #96]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403400 	ldr	x0, [x0, #104]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    30d0:	911ea000 	add	x0, x0, #0x7a8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	91018043 	add	x3, x2, #0x60
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	91018042 	add	x2, x2, #0x60
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x860>
    3198:	91124021 	add	x1, x1, #0x490
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    31d0:	911f0000 	add	x0, x0, #0x7c0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	91018294 	add	x20, x20, #0x60
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0xb30>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000036 	adrp	x22, 9000 <fwp_main_thread+0xb30>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	f0000038 	adrp	x24, a000 <_IO_stdin_used+0x860>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	91202042 	add	x2, x2, #0x808
    3260:	912182d6 	add	x22, x22, #0x860
    3264:	9108e318 	add	x24, x24, #0x238
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000039 	adrp	x25, 9000 <fwp_main_thread+0xb30>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	91216323 	add	x3, x25, #0x858
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	9121c000 	add	x0, x0, #0x870
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    3344:	911702a1 	add	x1, x21, #0x5c0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    3358:	9126c0a5 	add	x5, x5, #0x9b0
    335c:	911702a1 	add	x1, x21, #0x5c0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911702b7 	add	x23, x21, #0x5c0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911702b5 	add	x21, x21, #0x5c0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911702b5 	add	x21, x21, #0x5c0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    34e8:	9126a0a5 	add	x5, x5, #0x9a8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    35f0:	911ea000 	add	x0, x0, #0x7a8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	91018022 	add	x2, x1, #0x60
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	91018023 	add	x3, x1, #0x60
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	91018021 	add	x1, x1, #0x60
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	91018022 	add	x2, x1, #0x60
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	91018021 	add	x1, x1, #0x60
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    3830:	aa1303e0 	mov	x0, x19
    3834:	9121e021 	add	x1, x1, #0x878
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91220021 	add	x1, x1, #0x880
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    3860:	91222021 	add	x1, x1, #0x888
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_format_g.constprop.0>:
    3880:	d10483ff 	sub	sp, sp, #0x120
    3884:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    3888:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    388c:	f947f442 	ldr	x2, [x2, #4072]
    3890:	91224084 	add	x4, x4, #0x890
    3894:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3898:	9102c3fd 	add	x29, sp, #0xb0
    389c:	d2800803 	mov	x3, #0x40                  	// #64
    38a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    38a4:	93407c38 	sxtw	x24, w1
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	fd008be8 	str	d8, [sp, #272]
    38b0:	1e604008 	fmov	d8, d0
    38b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    38b8:	910083f4 	add	x20, sp, #0x20
    38bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38c0:	aa0003f5 	mov	x21, x0
    38c4:	a91073fb 	stp	x27, x28, [sp, #256]
    38c8:	5100071c 	sub	w28, w24, #0x1
    38cc:	2a1c03e5 	mov	w5, w28
    38d0:	f9400040 	ldr	x0, [x2]
    38d4:	f90057e0 	str	x0, [sp, #168]
    38d8:	d2800000 	mov	x0, #0x0                   	// #0
    38dc:	52800042 	mov	w2, #0x2                   	// #2
    38e0:	aa1403e0 	mov	x0, x20
    38e4:	97fffbe7 	bl	2880 <__snprintf_chk@plt>
    38e8:	52800ca1 	mov	w1, #0x65                  	// #101
    38ec:	aa1403e0 	mov	x0, x20
    38f0:	97fffc40 	bl	29f0 <strchr@plt>
    38f4:	aa0003f3 	mov	x19, x0
    38f8:	52800142 	mov	w2, #0xa                   	// #10
    38fc:	91000400 	add	x0, x0, #0x1
    3900:	d2800001 	mov	x1, #0x0                   	// #0
    3904:	97fffc2b 	bl	29b0 <strtol@plt>
    3908:	aa0003f7 	mov	x23, x0
    390c:	11001400 	add	w0, w0, #0x5
    3910:	7100541f 	cmp	w0, #0x15
    3914:	54000d68 	b.hi	3ac0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3918:	4b170385 	sub	w5, w28, w23
    391c:	710000bf 	cmp	w5, #0x0
    3920:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3924:	54000b80 	b.eq	3a94 <fwp_format_g.constprop.0+0x214>  // b.none
    3928:	394083e0 	ldrb	w0, [sp, #32]
    392c:	cb180273 	sub	x19, x19, x24
    3930:	91000673 	add	x19, x19, #0x1
    3934:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3938:	7100b41f 	cmp	w0, #0x2d
    393c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3940:	1a9f17e4 	cset	w4, eq	// eq = none
    3944:	cb010266 	sub	x6, x19, x1
    3948:	d10004da 	sub	x26, x6, #0x1
    394c:	540018a0 	b.eq	3c60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3950:	910183f9 	add	x25, sp, #0x60
    3954:	d280091b 	mov	x27, #0x48                  	// #72
    3958:	aa1903e7 	mov	x7, x25
    395c:	91000423 	add	x3, x1, #0x1
    3960:	91011cc6 	add	x6, x6, #0x47
    3964:	910004f6 	add	x22, x7, #0x1
    3968:	37f80ff7 	tbnz	w23, #31, 3b64 <fwp_format_g.constprop.0+0x2e4>
    396c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3970:	93407ef7 	sxtw	x23, w23
    3974:	390000e4 	strb	w4, [x7]
    3978:	aa1303e1 	mov	x1, x19
    397c:	aa1703e2 	mov	x2, x23
    3980:	aa1603e0 	mov	x0, x22
    3984:	b9000be5 	str	w5, [sp, #8]
    3988:	cb170374 	sub	x20, x27, x23
    398c:	a9011be3 	stp	x3, x6, [sp, #16]
    3990:	97fffb74 	bl	2760 <memcpy@plt>
    3994:	d1000694 	sub	x20, x20, #0x1
    3998:	f9400be3 	ldr	x3, [sp, #16]
    399c:	8b1702d6 	add	x22, x22, x23
    39a0:	aa1603e0 	mov	x0, x22
    39a4:	aa1a03e2 	mov	x2, x26
    39a8:	aa0303e1 	mov	x1, x3
    39ac:	aa1403e3 	mov	x3, x20
    39b0:	97fffbac 	bl	2860 <__memcpy_chk@plt>
    39b4:	8b1a02d6 	add	x22, x22, x26
    39b8:	f9400fe6 	ldr	x6, [sp, #24]
    39bc:	d2800900 	mov	x0, #0x48                  	// #72
    39c0:	b9400be5 	ldr	w5, [sp, #8]
    39c4:	8b170261 	add	x1, x19, x23
    39c8:	cb1400c3 	sub	x3, x6, x20
    39cc:	cb060294 	sub	x20, x20, x6
    39d0:	f101207f 	cmp	x3, #0x48
    39d4:	93407cb8 	sxtw	x24, w5
    39d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39dc:	aa1803e2 	mov	x2, x24
    39e0:	8b1802d3 	add	x19, x22, x24
    39e4:	8b140063 	add	x3, x3, x20
    39e8:	aa1603e0 	mov	x0, x22
    39ec:	97fffb9d 	bl	2860 <__memcpy_chk@plt>
    39f0:	cb190273 	sub	x19, x19, x25
    39f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    39f8:	eb00027f 	cmp	x19, x0
    39fc:	aa1903e1 	mov	x1, x25
    3a00:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a04:	aa1503e0 	mov	x0, x21
    3a08:	aa1303e2 	mov	x2, x19
    3a0c:	97fffb55 	bl	2760 <memcpy@plt>
    3a10:	38336abf 	strb	wzr, [x21, x19]
    3a14:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	97fffb61 	bl	27a0 <strlen@plt>
    3a20:	aa0003f3 	mov	x19, x0
    3a24:	528005c1 	mov	w1, #0x2e                  	// #46
    3a28:	aa1503e0 	mov	x0, x21
    3a2c:	97fffbf1 	bl	29f0 <strchr@plt>
    3a30:	b4000140 	cbz	x0, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a34:	b4000133 	cbz	x19, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a38:	aa1303e1 	mov	x1, x19
    3a3c:	d1000673 	sub	x19, x19, #0x1
    3a40:	38736aa0 	ldrb	w0, [x21, x19]
    3a44:	7100c01f 	cmp	w0, #0x30
    3a48:	54001001 	b.ne	3c48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    3a4c:	38336abf 	strb	wzr, [x21, x19]
    3a50:	b5ffff53 	cbnz	x19, 3a38 <fwp_format_g.constprop.0+0x1b8>
    3a54:	d503201f 	nop
    3a58:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a5c:	f947f400 	ldr	x0, [x0, #4072]
    3a60:	f94057e2 	ldr	x2, [sp, #168]
    3a64:	f9400001 	ldr	x1, [x0]
    3a68:	eb010042 	subs	x2, x2, x1
    3a6c:	d2800001 	mov	x1, #0x0                   	// #0
    3a70:	54001061 	b.ne	3c7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3a74:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a78:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a7c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a80:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a84:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a88:	fd408be8 	ldr	d8, [sp, #272]
    3a8c:	910483ff 	add	sp, sp, #0x120
    3a90:	d65f03c0 	ret
    3a94:	1e604100 	fmov	d0, d8
    3a98:	710000bf 	cmp	w5, #0x0
    3a9c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3aa0:	aa1503e0 	mov	x0, x21
    3aa4:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    3aa8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3aac:	9122a084 	add	x4, x4, #0x8a8
    3ab0:	52800042 	mov	w2, #0x2                   	// #2
    3ab4:	d2803201 	mov	x1, #0x190                 	// #400
    3ab8:	97fffb72 	bl	2880 <__snprintf_chk@plt>
    3abc:	17ffffd7 	b	3a18 <fwp_format_g.constprop.0+0x198>
    3ac0:	cb140273 	sub	x19, x19, x20
    3ac4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ac8:	910183f9 	add	x25, sp, #0x60
    3acc:	aa1303e2 	mov	x2, x19
    3ad0:	aa1403e1 	mov	x1, x20
    3ad4:	aa1903e0 	mov	x0, x25
    3ad8:	d2800803 	mov	x3, #0x40                  	// #64
    3adc:	97fffb61 	bl	2860 <__memcpy_chk@plt>
    3ae0:	38336b3f 	strb	wzr, [x25, x19]
    3ae4:	aa1903e0 	mov	x0, x25
    3ae8:	528005c1 	mov	w1, #0x2e                  	// #46
    3aec:	97fffbc1 	bl	29f0 <strchr@plt>
    3af0:	b40001c0 	cbz	x0, 3b28 <fwp_format_g.constprop.0+0x2a8>
    3af4:	b50000b3 	cbnz	x19, 3b08 <fwp_format_g.constprop.0+0x288>
    3af8:	1400000c 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3afc:	381ff01f 	sturb	wzr, [x0, #-1]
    3b00:	f1000673 	subs	x19, x19, #0x1
    3b04:	54000120 	b.eq	3b28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3b08:	8b130320 	add	x0, x25, x19
    3b0c:	385ff001 	ldurb	w1, [x0, #-1]
    3b10:	7100c03f 	cmp	w1, #0x30
    3b14:	54ffff40 	b.eq	3afc <fwp_format_g.constprop.0+0x27c>  // b.none
    3b18:	d1000673 	sub	x19, x19, #0x1
    3b1c:	38736b20 	ldrb	w0, [x25, x19]
    3b20:	7100b81f 	cmp	w0, #0x2e
    3b24:	54000a80 	b.eq	3c74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3b28:	710002ff 	cmp	w23, #0x0
    3b2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3b30:	aa1903e5 	mov	x5, x25
    3b34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	52800566 	mov	w6, #0x2b                  	// #43
    3b40:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    3b44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b48:	91226084 	add	x4, x4, #0x898
    3b4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b50:	52800042 	mov	w2, #0x2                   	// #2
    3b54:	d2803201 	mov	x1, #0x190                 	// #400
    3b58:	97fffb4a 	bl	2880 <__snprintf_chk@plt>
    3b5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b60:	17ffffbe 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3b64:	52800605 	mov	w5, #0x30                  	// #48
    3b68:	390000e5 	strb	w5, [x7]
    3b6c:	d100077b 	sub	x27, x27, #0x1
    3b70:	aa0303e1 	mov	x1, x3
    3b74:	aa1603e0 	mov	x0, x22
    3b78:	aa1b03e3 	mov	x3, x27
    3b7c:	aa1a03e2 	mov	x2, x26
    3b80:	f90007e6 	str	x6, [sp, #8]
    3b84:	b90013e4 	str	w4, [sp, #16]
    3b88:	8b1a02d6 	add	x22, x22, x26
    3b8c:	b9001be5 	str	w5, [sp, #24]
    3b90:	97fffb34 	bl	2860 <__memcpy_chk@plt>
    3b94:	f94007e6 	ldr	x6, [sp, #8]
    3b98:	2a3703e7 	mvn	w7, w23
    3b9c:	b94013e4 	ldr	w4, [sp, #16]
    3ba0:	cb1b00c1 	sub	x1, x6, x27
    3ba4:	cb06037b 	sub	x27, x27, x6
    3ba8:	f101203f 	cmp	x1, #0x48
    3bac:	d2800906 	mov	x6, #0x48                  	// #72
    3bb0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bb4:	8b1b0023 	add	x3, x1, x27
    3bb8:	310006ff 	cmn	w23, #0x1
    3bbc:	54000220 	b.eq	3c00 <fwp_format_g.constprop.0+0x380>  // b.none
    3bc0:	b9401be5 	ldr	w5, [sp, #24]
    3bc4:	d2800001 	mov	x1, #0x0                   	// #0
    3bc8:	f101207f 	cmp	x3, #0x48
    3bcc:	d1000462 	sub	x2, x3, #0x1
    3bd0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bd4:	38216ac5 	strb	w5, [x22, x1]
    3bd8:	cb030003 	sub	x3, x0, x3
    3bdc:	91000421 	add	x1, x1, #0x1
    3be0:	91000463 	add	x3, x3, #0x1
    3be4:	eb00007f 	cmp	x3, x0
    3be8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3bec:	cb000063 	sub	x3, x3, x0
    3bf0:	8b020063 	add	x3, x3, x2
    3bf4:	6b0100ff 	cmp	w7, w1
    3bf8:	54fffe8c 	b.gt	3bc8 <fwp_format_g.constprop.0+0x348>
    3bfc:	8b2742d6 	add	x22, x22, w7, uxtw
    3c00:	f101207f 	cmp	x3, #0x48
    3c04:	d2800905 	mov	x5, #0x48                  	// #72
    3c08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	cb0300a1 	sub	x1, x5, x3
    3c14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c18:	91000421 	add	x1, x1, #0x1
    3c1c:	d1000463 	sub	x3, x3, #0x1
    3c20:	eb05003f 	cmp	x1, x5
    3c24:	38001402 	strb	w2, [x0], #1
    3c28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c2c:	93407f82 	sxtw	x2, w28
    3c30:	cb050025 	sub	x5, x1, x5
    3c34:	aa1303e1 	mov	x1, x19
    3c38:	8b0300a3 	add	x3, x5, x3
    3c3c:	8b1802d3 	add	x19, x22, x24
    3c40:	97fffb08 	bl	2860 <__memcpy_chk@plt>
    3c44:	17ffff6b 	b	39f0 <fwp_format_g.constprop.0+0x170>
    3c48:	d1000421 	sub	x1, x1, #0x1
    3c4c:	38616aa0 	ldrb	w0, [x21, x1]
    3c50:	7100b81f 	cmp	w0, #0x2e
    3c54:	54fff021 	b.ne	3a58 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3c58:	38216abf 	strb	wzr, [x21, x1]
    3c5c:	17ffff7f 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3c60:	910187e7 	add	x7, sp, #0x61
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d28008fb 	mov	x27, #0x47                  	// #71
    3c6c:	390183e0 	strb	w0, [sp, #96]
    3c70:	17ffff3b 	b	395c <fwp_format_g.constprop.0+0xdc>
    3c74:	38336b3f 	strb	wzr, [x25, x19]
    3c78:	17ffffac 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3c7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c80:	97fffb24 	bl	2910 <__stack_chk_fail@plt>

0000000000003c84 <fwp_heap_report>:
    3c84:	d105c3ff 	sub	sp, sp, #0x170
    3c88:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    3c8c:	91170042 	add	x2, x2, #0x5c0
    3c90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3c94:	f947e821 	ldr	x1, [x1, #4048]
    3c98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c9c:	910443fd 	add	x29, sp, #0x110
    3ca0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ca4:	f947f400 	ldr	x0, [x0, #4072]
    3ca8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cac:	a91463f7 	stp	x23, x24, [sp, #320]
    3cb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3cc0:	f9400036 	ldr	x22, [x1]
    3cc4:	f9400001 	ldr	x1, [x0]
    3cc8:	f90087e1 	str	x1, [sp, #264]
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	f949e459 	ldr	x25, [x2, #5064]
    3cd4:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    3cd8:	f94a1057 	ldr	x23, [x2, #5152]
    3cdc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    3ce0:	f94a1458 	ldr	x24, [x2, #5160]
    3ce4:	9122c021 	add	x1, x1, #0x8b0
    3ce8:	9122e000 	add	x0, x0, #0x8b8
    3cec:	97fffaed 	bl	28a0 <fopen@plt>
    3cf0:	b4000760 	cbz	x0, 3ddc <fwp_heap_report+0x158>
    3cf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3cf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3cfc:	aa0003f4 	mov	x20, x0
    3d00:	910023f3 	add	x19, sp, #0x8
    3d04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d08:	72aae915 	movk	w21, #0x5748, lsl #16
    3d0c:	d503201f 	nop
    3d10:	aa1403e2 	mov	x2, x20
    3d14:	aa1303e0 	mov	x0, x19
    3d18:	52802001 	mov	w1, #0x100                 	// #256
    3d1c:	97fffb6d 	bl	2ad0 <fgets@plt>
    3d20:	b4000280 	cbz	x0, 3d70 <fwp_heap_report+0xec>
    3d24:	b9400261 	ldr	w1, [x19]
    3d28:	6b15003f 	cmp	w1, w21
    3d2c:	54ffff21 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d30:	39401260 	ldrb	w0, [x19, #4]
    3d34:	7101341f 	cmp	w0, #0x4d
    3d38:	54fffec1 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d3c:	394037e0 	ldrb	w0, [sp, #13]
    3d40:	7100e81f 	cmp	w0, #0x3a
    3d44:	54fffe61 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d48:	52800142 	mov	w2, #0xa                   	// #10
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	91003be0 	add	x0, sp, #0xe
    3d54:	97fffb17 	bl	29b0 <strtol@plt>
    3d58:	aa1403e2 	mov	x2, x20
    3d5c:	aa0003fa 	mov	x26, x0
    3d60:	52802001 	mov	w1, #0x100                 	// #256
    3d64:	aa1303e0 	mov	x0, x19
    3d68:	97fffb5a 	bl	2ad0 <fgets@plt>
    3d6c:	b5fffdc0 	cbnz	x0, 3d24 <fwp_heap_report+0xa0>
    3d70:	aa1403e0 	mov	x0, x20
    3d74:	97fffac7 	bl	2890 <fclose@plt>
    3d78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d80:	f947f400 	ldr	x0, [x0, #4072]
    3d84:	f94087e2 	ldr	x2, [sp, #264]
    3d88:	f9400001 	ldr	x1, [x0]
    3d8c:	eb010042 	subs	x2, x2, x1
    3d90:	d2800001 	mov	x1, #0x0                   	// #0
    3d94:	54000281 	b.ne	3de4 <fwp_heap_report+0x160>  // b.any
    3d98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d9c:	aa1a03e6 	mov	x6, x26
    3da0:	aa1903e5 	mov	x5, x25
    3da4:	aa1803e4 	mov	x4, x24
    3da8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dac:	aa1703e3 	mov	x3, x23
    3db0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3db4:	aa1603e0 	mov	x0, x22
    3db8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dbc:	1e604121 	fmov	d1, d9
    3dc0:	1e604100 	fmov	d0, d8
    3dc4:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0xb30>
    3dc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3dcc:	91236042 	add	x2, x2, #0x8d8
    3dd0:	9105c3ff 	add	sp, sp, #0x170
    3dd4:	52800041 	mov	w1, #0x2                   	// #2
    3dd8:	17fffaea 	b	2980 <__fprintf_chk@plt>
    3ddc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3de0:	17ffffe7 	b	3d7c <fwp_heap_report+0xf8>
    3de4:	a91253f3 	stp	x19, x20, [sp, #288]
    3de8:	97fffaca 	bl	2910 <__stack_chk_fail@plt>
    3dec:	d503201f 	nop

0000000000003df0 <fwp_heap_init>:
    3df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3df4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa40>
    3df8:	91130061 	add	x1, x3, #0x4c0
    3dfc:	910003fd 	mov	x29, sp
    3e00:	a90153f3 	stp	x19, x20, [sp, #16]
    3e04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    3e08:	91170262 	add	x2, x19, #0x5c0
    3e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e10:	52800024 	mov	w4, #0x1                   	// #1
    3e14:	52800200 	mov	w0, #0x10                  	// #16
    3e18:	b913a444 	str	w4, [x2, #5028]
    3e1c:	d503201f 	nop
    3e20:	b8004420 	str	w0, [x1], #4
    3e24:	11004000 	add	w0, w0, #0x10
    3e28:	7104401f 	cmp	w0, #0x110
    3e2c:	54ffffa1 	b.ne	3e20 <fwp_heap_init+0x30>  // b.any
    3e30:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0x860>
    3e34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa40>
    3e3c:	91140021 	add	x1, x1, #0x500
    3e40:	3dc13043 	ldr	q3, [x2, #1216]
    3e44:	d2800000 	mov	x0, #0x0                   	// #0
    3e48:	4e040401 	dup	v1.4s, v0.s[0]
    3e4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e50:	0f215400 	shl	v0.2s, v0.2s, #1
    3e54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e58:	3ca06821 	str	q1, [x1, x0]
    3e5c:	91004000 	add	x0, x0, #0x10
    3e60:	f101801f 	cmp	x0, #0x60
    3e64:	54ffff21 	b.ne	3e48 <fwp_heap_init+0x58>  // b.any
    3e68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa40>
    3e6c:	91130063 	add	x3, x3, #0x4c0
    3e70:	91158084 	add	x4, x4, #0x560
    3e74:	91170266 	add	x6, x19, #0x5c0
    3e78:	d2800002 	mov	x2, #0x0                   	// #0
    3e7c:	d2800000 	mov	x0, #0x0                   	// #0
    3e80:	d2880205 	mov	x5, #0x4010                	// #16400
    3e84:	d503201f 	nop
    3e88:	910f0001 	add	x1, x0, #0x3c0
    3e8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e90:	eb02003f 	cmp	x1, x2
    3e94:	540000a2 	b.cs	3ea8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e98:	91000400 	add	x0, x0, #0x1
    3e9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	54ffffa3 	b.cc	3e98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ea8:	91004042 	add	x2, x2, #0x10
    3eac:	38001480 	strb	w0, [x4], #1
    3eb0:	eb05005f 	cmp	x2, x5
    3eb4:	54fffea1 	b.ne	3e88 <fwp_heap_init+0x98>  // b.any
    3eb8:	528000b5 	mov	w21, #0x5                   	// #5
    3ebc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ec0:	14000004 	b	3ed0 <fwp_heap_init+0xe0>
    3ec4:	d342fe94 	lsr	x20, x20, #2
    3ec8:	710006b5 	subs	w21, w21, #0x1
    3ecc:	54000720 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3ed0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ed4:	d2800005 	mov	x5, #0x0                   	// #0
    3ed8:	aa1603e1 	mov	x1, x22
    3edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ee0:	52880443 	mov	w3, #0x4022                	// #16418
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	d2800000 	mov	x0, #0x0                   	// #0
    3eec:	97fffaad 	bl	29a0 <mmap@plt>
    3ef0:	aa0003e6 	mov	x6, x0
    3ef4:	b100041f 	cmn	x0, #0x1
    3ef8:	54fffe60 	b.eq	3ec4 <fwp_heap_init+0xd4>  // b.none
    3efc:	b40005a0 	cbz	x0, 3fb0 <fwp_heap_init+0x1c0>
    3f00:	d350fe94 	lsr	x20, x20, #16
    3f04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f08:	8b0000c7 	add	x7, x6, x0
    3f0c:	91170275 	add	x21, x19, #0x5c0
    3f10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f14:	8b140a81 	add	x1, x20, x20, lsl #2
    3f18:	d2800005 	mov	x5, #0x0                   	// #0
    3f1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f20:	d37df021 	lsl	x1, x1, #3
    3f24:	52880443 	mov	w3, #0x4022                	// #16418
    3f28:	52800002 	mov	w2, #0x0                   	// #0
    3f2c:	d2800000 	mov	x0, #0x0                   	// #0
    3f30:	f909daa7 	str	x7, [x21, #5040]
    3f34:	f909dea6 	str	x6, [x21, #5048]
    3f38:	f909e2b6 	str	x22, [x21, #5056]
    3f3c:	f909eab4 	str	x20, [x21, #5072]
    3f40:	f90a02a1 	str	x1, [x21, #5120]
    3f44:	97fffa97 	bl	29a0 <mmap@plt>
    3f48:	aa0003e1 	mov	x1, x0
    3f4c:	b100041f 	cmn	x0, #0x1
    3f50:	54000300 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3f54:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    3f58:	91258000 	add	x0, x0, #0x960
    3f5c:	f909fea1 	str	x1, [x21, #5112]
    3f60:	97fffad0 	bl	2aa0 <getenv@plt>
    3f64:	52800002 	mov	w2, #0x0                   	// #0
    3f68:	aa0003e1 	mov	x1, x0
    3f6c:	b40000e0 	cbz	x0, 3f88 <fwp_heap_init+0x198>
    3f70:	39400000 	ldrb	w0, [x0]
    3f74:	340000a0 	cbz	w0, 3f88 <fwp_heap_init+0x198>
    3f78:	7100c000 	subs	w0, w0, #0x30
    3f7c:	54000120 	b.eq	3fa0 <fwp_heap_init+0x1b0>  // b.none
    3f80:	7100001f 	cmp	w0, #0x0
    3f84:	1a9f07e2 	cset	w2, ne	// ne = any
    3f88:	91170273 	add	x19, x19, #0x5c0
    3f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f90:	b913aa62 	str	w2, [x19, #5032]
    3f94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f9c:	d65f03c0 	ret
    3fa0:	39400420 	ldrb	w0, [x1, #1]
    3fa4:	7100001f 	cmp	w0, #0x0
    3fa8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fac:	17fffff7 	b	3f88 <fwp_heap_init+0x198>
    3fb0:	97fffc40 	bl	30b0 <fwp_heap_oom>

0000000000003fb4 <fwp_wake_io>:
    3fb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fb8:	91018122 	add	x2, x9, #0x60
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	5280000a 	mov	w10, #0x0                   	// #0
    3fc4:	f9403c46 	ldr	x6, [x2, #120]
    3fc8:	52800008 	mov	w8, #0x0                   	// #0
    3fcc:	4f000400 	movi	v0.4s, #0x0
    3fd0:	52800027 	mov	w7, #0x1                   	// #1
    3fd4:	aa0103e2 	mov	x2, x1
    3fd8:	b4000321 	cbz	x1, 403c <fwp_wake_io+0x88>
    3fdc:	f9408c25 	ldr	x5, [x1, #280]
    3fe0:	39015c27 	strb	w7, [x1, #87]
    3fe4:	b4000165 	cbz	x5, 4010 <fwp_wake_io+0x5c>
    3fe8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3fec:	b4000364 	cbz	x4, 4058 <fwp_wake_io+0xa4>
    3ff0:	f9009483 	str	x3, [x4, #296]
    3ff4:	f9409423 	ldr	x3, [x1, #296]
    3ff8:	b4000043 	cbz	x3, 4000 <fwp_wake_io+0x4c>
    3ffc:	f9009064 	str	x4, [x3, #288]
    4000:	91080023 	add	x3, x1, #0x200
    4004:	f900943f 	str	xzr, [x1, #296]
    4008:	3c918060 	stur	q0, [x3, #-232]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	f9402843 	ldr	x3, [x2, #80]
    4014:	f2001c7f 	tst	x3, #0xff000000ff
    4018:	54fffde1 	b.ne	3fd4 <fwp_wake_io+0x20>  // b.any
    401c:	39015047 	strb	w7, [x2, #84]
    4020:	f900805f 	str	xzr, [x2, #256]
    4024:	b40001e6 	cbz	x6, 4060 <fwp_wake_io+0xac>
    4028:	f90080c2 	str	x2, [x6, #256]
    402c:	aa0203e6 	mov	x6, x2
    4030:	52800028 	mov	w8, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b5fffd21 	cbnz	x1, 3fdc <fwp_wake_io+0x28>
    403c:	3400006a 	cbz	w10, 4048 <fwp_wake_io+0x94>
    4040:	91018120 	add	x0, x9, #0x60
    4044:	f900400b 	str	x11, [x0, #128]
    4048:	34000068 	cbz	w8, 4054 <fwp_wake_io+0xa0>
    404c:	91018129 	add	x9, x9, #0x60
    4050:	f9003d26 	str	x6, [x9, #120]
    4054:	d65f03c0 	ret
    4058:	f90000a3 	str	x3, [x5]
    405c:	17ffffe7 	b	3ff8 <fwp_wake_io+0x44>
    4060:	aa0203eb 	mov	x11, x2
    4064:	5280002a 	mov	w10, #0x1                   	// #1
    4068:	17fffff1 	b	402c <fwp_wake_io+0x78>
    406c:	d503201f 	nop

0000000000004070 <fwp_tape_buffers_release>:
    4070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4074:	910003fd 	mov	x29, sp
    4078:	a90153f3 	stp	x19, x20, [sp, #16]
    407c:	aa0003f3 	mov	x19, x0
    4080:	f9401400 	ldr	x0, [x0, #40]
    4084:	b7f80760 	tbnz	x0, #63, 4170 <fwp_tape_buffers_release+0x100>
    4088:	f9401a61 	ldr	x1, [x19, #48]
    408c:	b7f80301 	tbnz	x1, #63, 40ec <fwp_tape_buffers_release+0x7c>
    4090:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4094:	eb02001f 	cmp	x0, x2
    4098:	540002a8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    409c:	8b000400 	add	x0, x0, x0, lsl #1
    40a0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40a4:	d37df000 	lsl	x0, x0, #3
    40a8:	cb000042 	sub	x2, x2, x0
    40ac:	eb420c3f 	cmp	x1, x2, lsr #3
    40b0:	540001e8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    40b4:	8b010c14 	add	x20, x0, x1, lsl #3
    40b8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    40bc:	9125c000 	add	x0, x0, #0x970
    40c0:	97fffa78 	bl	2aa0 <getenv@plt>
    40c4:	b4000240 	cbz	x0, 410c <fwp_tape_buffers_release+0x9c>
    40c8:	39400001 	ldrb	w1, [x0]
    40cc:	7100c03f 	cmp	w1, #0x30
    40d0:	540001e1 	b.ne	410c <fwp_tape_buffers_release+0x9c>  // b.any
    40d4:	39400400 	ldrb	w0, [x0, #1]
    40d8:	350001a0 	cbnz	w0, 410c <fwp_tape_buffers_release+0x9c>
    40dc:	aa1303e0 	mov	x0, x19
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e8:	17fffd06 	b	3500 <fwp_tape_buffers_dispose>
    40ec:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    40f0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f4:	9125c000 	add	x0, x0, #0x970
    40f8:	97fffa6a 	bl	2aa0 <getenv@plt>
    40fc:	b4ffff00 	cbz	x0, 40dc <fwp_tape_buffers_release+0x6c>
    4100:	39400001 	ldrb	w1, [x0]
    4104:	7100c03f 	cmp	w1, #0x30
    4108:	54fffe60 	b.eq	40d4 <fwp_tape_buffers_release+0x64>  // b.none
    410c:	d1000681 	sub	x1, x20, #0x1
    4110:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4114:	eb00003f 	cmp	x1, x0
    4118:	54fffe28 	b.hi	40dc <fwp_tape_buffers_release+0x6c>  // b.pmore
    411c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4120:	900000f6 	adrp	x22, 20000 <__data_start>
    4124:	910182d6 	add	x22, x22, #0x60
    4128:	910222d5 	add	x21, x22, #0x88
    412c:	aa1503e0 	mov	x0, x21
    4130:	97fffcf4 	bl	3500 <fwp_tape_buffers_dispose>
    4134:	ad400a61 	ldp	q1, q2, [x19]
    4138:	f90062d4 	str	x20, [x22, #192]
    413c:	4f000400 	movi	v0.4s, #0x0
    4140:	ad000aa1 	stp	q1, q2, [x21]
    4144:	3dc00a61 	ldr	q1, [x19, #32]
    4148:	3d800aa1 	str	q1, [x21, #32]
    414c:	f9401a60 	ldr	x0, [x19, #48]
    4150:	f9001aa0 	str	x0, [x21, #48]
    4154:	f9001a7f 	str	xzr, [x19, #48]
    4158:	ad000260 	stp	q0, q0, [x19]
    415c:	3d800a60 	str	q0, [x19, #32]
    4160:	a94153f3 	ldp	x19, x20, [sp, #16]
    4164:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    416c:	d65f03c0 	ret
    4170:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4174:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4178:	9125c000 	add	x0, x0, #0x970
    417c:	97fffa49 	bl	2aa0 <getenv@plt>
    4180:	b5fffa40 	cbnz	x0, 40c8 <fwp_tape_buffers_release+0x58>
    4184:	17ffffd6 	b	40dc <fwp_tape_buffers_release+0x6c>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <fwp_trap>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	900000e2 	adrp	x2, 20000 <__data_start>
    4198:	d53bd041 	mrs	x1, tpidr_el0
    419c:	910003fd 	mov	x29, sp
    41a0:	f9403442 	ldr	x2, [x2, #104]
    41a4:	91400021 	add	x1, x1, #0x0, lsl #12
    41a8:	91004021 	add	x1, x1, #0x10
    41ac:	a90153f3 	stp	x19, x20, [sp, #16]
    41b0:	aa0003f3 	mov	x19, x0
    41b4:	f9400034 	ldr	x20, [x1]
    41b8:	b4000062 	cbz	x2, 41c4 <fwp_trap+0x34>
    41bc:	aa0203e0 	mov	x0, x2
    41c0:	97fffa20 	bl	2a40 <fflush@plt>
    41c4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    41c8:	f947ec00 	ldr	x0, [x0, #4056]
    41cc:	f9400000 	ldr	x0, [x0]
    41d0:	97fffa1c 	bl	2a40 <fflush@plt>
    41d4:	aa1303e3 	mov	x3, x19
    41d8:	b0000022 	adrp	x2, 9000 <fwp_main_thread+0xb30>
    41dc:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    41e0:	f947ea73 	ldr	x19, [x19, #4048]
    41e4:	91262042 	add	x2, x2, #0x988
    41e8:	52800041 	mov	w1, #0x2                   	// #2
    41ec:	f9400260 	ldr	x0, [x19]
    41f0:	97fff9e4 	bl	2980 <__fprintf_chk@plt>
    41f4:	b40000b4 	cbz	x20, 4208 <fwp_trap+0x78>
    41f8:	f9400260 	ldr	x0, [x19]
    41fc:	97fffa11 	bl	2a40 <fflush@plt>
    4200:	52800ca0 	mov	w0, #0x65                  	// #101
    4204:	97fffa1f 	bl	2a80 <_Exit@plt>
    4208:	52800ca0 	mov	w0, #0x65                  	// #101
    420c:	97fff96d 	bl	27c0 <exit@plt>

0000000000004210 <fwp_rc_forget_slot.part.0>:
    4210:	ca404401 	eor	x1, x0, x0, lsr #17
    4214:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4218:	ca412421 	eor	x1, x1, x1, lsr #9
    421c:	910003fd 	mov	x29, sp
    4220:	92401c21 	and	x1, x1, #0xff
    4224:	f9000bf3 	str	x19, [sp, #16]
    4228:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    422c:	91170262 	add	x2, x19, #0x5c0
    4230:	910a2423 	add	x3, x1, #0x289
    4234:	8b010c41 	add	x1, x2, x1, lsl #3
    4238:	8b030c43 	add	x3, x2, x3, lsl #3
    423c:	f94a2421 	ldr	x1, [x1, #5192]
    4240:	b50000a1 	cbnz	x1, 4254 <fwp_rc_forget_slot.part.0+0x44>
    4244:	14000012 	b	428c <fwp_rc_forget_slot.part.0+0x7c>
    4248:	91004023 	add	x3, x1, #0x10
    424c:	f9400821 	ldr	x1, [x1, #16]
    4250:	b40001e1 	cbz	x1, 428c <fwp_rc_forget_slot.part.0+0x7c>
    4254:	f9400022 	ldr	x2, [x1]
    4258:	eb02001f 	cmp	x0, x2
    425c:	54ffff61 	b.ne	4248 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4260:	f9400060 	ldr	x0, [x3]
    4264:	91170273 	add	x19, x19, #0x5c0
    4268:	f9400801 	ldr	x1, [x0, #16]
    426c:	f9000061 	str	x1, [x3]
    4270:	97fff9d8 	bl	29d0 <free@plt>
    4274:	f94e2660 	ldr	x0, [x19, #7240]
    4278:	d1000400 	sub	x0, x0, #0x1
    427c:	f90e2660 	str	x0, [x19, #7240]
    4280:	f9400bf3 	ldr	x19, [sp, #16]
    4284:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4288:	d65f03c0 	ret
    428c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4290:	91266000 	add	x0, x0, #0x998
    4294:	97ffffbf 	bl	4190 <fwp_trap>
    4298:	d503201f 	nop
    429c:	d503201f 	nop

00000000000042a0 <fwp_rc_prepare_chunk>:
    42a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42a4:	910003fd 	mov	x29, sp
    42a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    42ac:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc20>
    42b0:	911702c2 	add	x2, x22, #0x5c0
    42b4:	b9401c03 	ldr	w3, [x0, #28]
    42b8:	aa0103f5 	mov	x21, x1
    42bc:	a90153f3 	stp	x19, x20, [sp, #16]
    42c0:	aa0003f4 	mov	x20, x0
    42c4:	f94e2440 	ldr	x0, [x2, #7240]
    42c8:	b4000440 	cbz	x0, 4350 <fwp_rc_prepare_chunk+0xb0>
    42cc:	d2800013 	mov	x19, #0x0                   	// #0
    42d0:	35000203 	cbnz	w3, 4310 <fwp_rc_prepare_chunk+0x70>
    42d4:	b4000361 	cbz	x1, 4340 <fwp_rc_prepare_chunk+0xa0>
    42d8:	f9401280 	ldr	x0, [x20, #32]
    42dc:	97fff9bd 	bl	29d0 <free@plt>
    42e0:	aa1503e0 	mov	x0, x21
    42e4:	d2800021 	mov	x1, #0x1                   	// #1
    42e8:	97fff982 	bl	28f0 <calloc@plt>
    42ec:	f9001280 	str	x0, [x20, #32]
    42f0:	b5000460 	cbnz	x0, 437c <fwp_rc_prepare_chunk+0xdc>
    42f4:	97fffb6f 	bl	30b0 <fwp_heap_oom>
    42f8:	97ffffc6 	bl	4210 <fwp_rc_forget_slot.part.0>
    42fc:	91000673 	add	x19, x19, #0x1
    4300:	b9401e83 	ldr	w3, [x20, #28]
    4304:	eb13007f 	cmp	x3, x19
    4308:	54000169 	b.ls	4334 <fwp_rc_prepare_chunk+0x94>  // b.plast
    430c:	d503201f 	nop
    4310:	f9401283 	ldr	x3, [x20, #32]
    4314:	8b130060 	add	x0, x3, x19
    4318:	38736863 	ldrb	w3, [x3, x19]
    431c:	7103fc7f 	cmp	w3, #0xff
    4320:	54fffec0 	b.eq	42f8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4324:	b9401e83 	ldr	w3, [x20, #28]
    4328:	91000673 	add	x19, x19, #0x1
    432c:	eb13007f 	cmp	x3, x19
    4330:	54ffff08 	b.hi	4310 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4334:	eb0302bf 	cmp	x21, x3
    4338:	54000121 	b.ne	435c <fwp_rc_prepare_chunk+0xbc>  // b.any
    433c:	b5000335 	cbnz	x21, 43a0 <fwp_rc_prepare_chunk+0x100>
    4340:	a94153f3 	ldp	x19, x20, [sp, #16]
    4344:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4348:	a8c37bfd 	ldp	x29, x30, [sp], #48
    434c:	d65f03c0 	ret
    4350:	2a0303e3 	mov	w3, w3
    4354:	eb0302bf 	cmp	x21, x3
    4358:	54ffff20 	b.eq	433c <fwp_rc_prepare_chunk+0x9c>  // b.none
    435c:	911702c2 	add	x2, x22, #0x5c0
    4360:	f9401280 	ldr	x0, [x20, #32]
    4364:	f94e2841 	ldr	x1, [x2, #7248]
    4368:	cb030021 	sub	x1, x1, x3
    436c:	f90e2841 	str	x1, [x2, #7248]
    4370:	97fff998 	bl	29d0 <free@plt>
    4374:	b5fffb75 	cbnz	x21, 42e0 <fwp_rc_prepare_chunk+0x40>
    4378:	f900129f 	str	xzr, [x20, #32]
    437c:	911702d6 	add	x22, x22, #0x5c0
    4380:	f94e2ac0 	ldr	x0, [x22, #7248]
    4384:	b9001e95 	str	w21, [x20, #28]
    4388:	a94153f3 	ldp	x19, x20, [sp, #16]
    438c:	8b150000 	add	x0, x0, x21
    4390:	f90e2ac0 	str	x0, [x22, #7248]
    4394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4398:	a8c37bfd 	ldp	x29, x30, [sp], #48
    439c:	d65f03c0 	ret
    43a0:	f9401280 	ldr	x0, [x20, #32]
    43a4:	aa1503e2 	mov	x2, x21
    43a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43ac:	52800001 	mov	w1, #0x0                   	// #0
    43b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43b8:	17fff94a 	b	28e0 <memset@plt>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_heap_refill>:
    43c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    43d0:	911702b5 	add	x21, x21, #0x5c0
    43d4:	aa0003f6 	mov	x22, x0
    43d8:	d2800020 	mov	x0, #0x1                   	// #1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	a90363f7 	stp	x23, x24, [sp, #48]
    43e4:	2a0103f7 	mov	w23, w1
    43e8:	2a0203f8 	mov	w24, w2
    43ec:	97fffbd1 	bl	3330 <fwp_heap_chunks>
    43f0:	aa0003f3 	mov	x19, x0
    43f4:	f949fea2 	ldr	x2, [x21, #5112]
    43f8:	8b000800 	add	x0, x0, x0, lsl #2
    43fc:	2a1703e1 	mov	w1, w23
    4400:	52800025 	mov	w5, #0x1                   	// #1
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	910f0021 	add	x1, x1, #0x3c0
    440c:	8b000054 	add	x20, x2, x0
    4410:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4414:	52a00024 	mov	w4, #0x10000               	// #65536
    4418:	38206845 	strb	w5, [x2, x0]
    441c:	aa1403e0 	mov	x0, x20
    4420:	39000698 	strb	w24, [x20, #1]
    4424:	39000a97 	strb	w23, [x20, #2]
    4428:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    442c:	b9000681 	str	w1, [x20, #4]
    4430:	2a0103e5 	mov	w5, w1
    4434:	8b0300a2 	add	x2, x5, x3
    4438:	1ac10881 	udiv	w1, w4, w1
    443c:	9ac50842 	udiv	x2, x2, x5
    4440:	b9000a81 	str	w1, [x20, #8]
    4444:	92404021 	and	x1, x1, #0x1ffff
    4448:	b9001a82 	str	w2, [x20, #24]
    444c:	97ffff95 	bl	42a0 <fwp_rc_prepare_chunk>
    4450:	f949daa0 	ldr	x0, [x21, #5040]
    4454:	29408a81 	ldp	w1, w2, [x20, #4]
    4458:	8b134000 	add	x0, x0, x19, lsl #16
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	8b214003 	add	x3, x0, w1, uxtw
    4464:	9ba20021 	umaddl	x1, w1, w2, x0
    4468:	a94363f7 	ldp	x23, x24, [sp, #48]
    446c:	a90086c3 	stp	x3, x1, [x22, #8]
    4470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4474:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4478:	d65f03c0 	ret
    447c:	d503201f 	nop

0000000000004480 <fwp_mem_free>:
    4480:	b40003c0 	cbz	x0, 44f8 <fwp_mem_free+0x78>
    4484:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4488:	910003fd 	mov	x29, sp
    448c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4490:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4494:	911702a1 	add	x1, x21, #0x5c0
    4498:	a90153f3 	stp	x19, x20, [sp, #16]
    449c:	aa0003f3 	mov	x19, x0
    44a0:	f949d823 	ldr	x3, [x1, #5040]
    44a4:	f949ec22 	ldr	x2, [x1, #5080]
    44a8:	cb030000 	sub	x0, x0, x3
    44ac:	eb02401f 	cmp	x0, x2, lsl #16
    44b0:	540001c2 	b.cs	44e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    44b4:	d350fc16 	lsr	x22, x0, #16
    44b8:	a90363f7 	stp	x23, x24, [sp, #48]
    44bc:	f949fc22 	ldr	x2, [x1, #5112]
    44c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    44c4:	d37df294 	lsl	x20, x20, #3
    44c8:	ab140057 	adds	x23, x2, x20
    44cc:	540000c0 	b.eq	44e4 <fwp_mem_free+0x64>  // b.none
    44d0:	38746842 	ldrb	w2, [x2, x20]
    44d4:	7100045f 	cmp	w2, #0x1
    44d8:	54000120 	b.eq	44fc <fwp_mem_free+0x7c>  // b.none
    44dc:	7100085f 	cmp	w2, #0x2
    44e0:	540005e0 	b.eq	459c <fwp_mem_free+0x11c>  // b.none
    44e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44f4:	d65f03c0 	ret
    44f8:	d65f03c0 	ret
    44fc:	f94012f8 	ldr	x24, [x23, #32]
    4500:	b94006e1 	ldr	w1, [x23, #4]
    4504:	f90023f9 	str	x25, [sp, #64]
    4508:	2a0103e2 	mov	w2, w1
    450c:	394006f9 	ldrb	w25, [x23, #1]
    4510:	39400af4 	ldrb	w20, [x23, #2]
    4514:	b4000158 	cbz	x24, 453c <fwp_mem_free+0xbc>
    4518:	92403e76 	and	x22, x19, #0xffff
    451c:	9ac20ad6 	udiv	x22, x22, x2
    4520:	38766b01 	ldrb	w1, [x24, x22]
    4524:	8b160300 	add	x0, x24, x22
    4528:	7103fc3f 	cmp	w1, #0xff
    452c:	54000980 	b.eq	465c <fwp_mem_free+0x1dc>  // b.none
    4530:	38366b1f 	strb	wzr, [x24, x22]
    4534:	b94006e1 	ldr	w1, [x23, #4]
    4538:	2a0103e2 	mov	w2, w1
    453c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4540:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4544:	cb390000 	sub	x0, x0, w25, uxtb
    4548:	8b340074 	add	x20, x3, w20, uxtb
    454c:	911702b5 	add	x21, x21, #0x5c0
    4550:	1e630021 	ucvtf	d1, w1
    4554:	d37ae400 	lsl	x0, x0, #6
    4558:	8b140c14 	add	x20, x0, x20, lsl #3
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	f8746aa0 	ldr	x0, [x21, x20]
    4564:	f94023f9 	ldr	x25, [sp, #64]
    4568:	aa2003e0 	mvn	x0, x0
    456c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4570:	f9000260 	str	x0, [x19]
    4574:	f8346ab3 	str	x19, [x21, x20]
    4578:	f94a12a0 	ldr	x0, [x21, #5152]
    457c:	1e612800 	fadd	d0, d0, d1
    4580:	a94153f3 	ldp	x19, x20, [sp, #16]
    4584:	cb020000 	sub	x0, x0, x2
    4588:	f90a12a0 	str	x0, [x21, #5152]
    458c:	fd0a22a0 	str	d0, [x21, #5184]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4598:	d65f03c0 	ret
    459c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    45a0:	8b000063 	add	x3, x3, x0
    45a4:	eb03027f 	cmp	x19, x3
    45a8:	54fff9e1 	b.ne	44e4 <fwp_mem_free+0x64>  // b.any
    45ac:	fd400ae1 	ldr	d1, [x23, #16]
    45b0:	fd4a2020 	ldr	d0, [x1, #5184]
    45b4:	f9400ae0 	ldr	x0, [x23, #16]
    45b8:	7e61d821 	ucvtf	d1, d1
    45bc:	f94a1022 	ldr	x2, [x1, #5152]
    45c0:	f94012f3 	ldr	x19, [x23, #32]
    45c4:	1e612800 	fadd	d0, d0, d1
    45c8:	cb000042 	sub	x2, x2, x0
    45cc:	f90a1022 	str	x2, [x1, #5152]
    45d0:	fd0a2020 	str	d0, [x1, #5184]
    45d4:	b40000b3 	cbz	x19, 45e8 <fwp_mem_free+0x168>
    45d8:	39400260 	ldrb	w0, [x19]
    45dc:	7103fc1f 	cmp	w0, #0xff
    45e0:	54000380 	b.eq	4650 <fwp_mem_free+0x1d0>  // b.none
    45e4:	3900027f 	strb	wzr, [x19]
    45e8:	b9400ee2 	ldr	w2, [x23, #12]
    45ec:	b4000142 	cbz	x2, 4614 <fwp_mem_free+0x194>
    45f0:	911702a1 	add	x1, x21, #0x5c0
    45f4:	8b160040 	add	x0, x2, x22
    45f8:	8b000800 	add	x0, x0, x0, lsl #2
    45fc:	f949fc21 	ldr	x1, [x1, #5112]
    4600:	8b140034 	add	x20, x1, x20
    4604:	8b000c20 	add	x0, x1, x0, lsl #3
    4608:	3802869f 	strb	wzr, [x20], #40
    460c:	eb00029f 	cmp	x20, x0
    4610:	54ffffc1 	b.ne	4608 <fwp_mem_free+0x188>  // b.any
    4614:	911702a0 	add	x0, x21, #0x5c0
    4618:	f94a1801 	ldr	x1, [x0, #5168]
    461c:	f949f803 	ldr	x3, [x0, #5104]
    4620:	8b020021 	add	x1, x1, x2
    4624:	f90a1801 	str	x1, [x0, #5168]
    4628:	eb16007f 	cmp	x3, x22
    462c:	54000049 	b.ls	4634 <fwp_mem_free+0x1b4>  // b.plast
    4630:	f909f816 	str	x22, [x0, #5104]
    4634:	911702b5 	add	x21, x21, #0x5c0
    4638:	f949f6a0 	ldr	x0, [x21, #5096]
    463c:	eb16001f 	cmp	x0, x22
    4640:	54fff529 	b.ls	44e4 <fwp_mem_free+0x64>  // b.plast
    4644:	a94363f7 	ldp	x23, x24, [sp, #48]
    4648:	f909f6b6 	str	x22, [x21, #5096]
    464c:	17ffffa7 	b	44e8 <fwp_mem_free+0x68>
    4650:	aa1303e0 	mov	x0, x19
    4654:	97fffeef 	bl	4210 <fwp_rc_forget_slot.part.0>
    4658:	17ffffe3 	b	45e4 <fwp_mem_free+0x164>
    465c:	97fffeed 	bl	4210 <fwp_rc_forget_slot.part.0>
    4660:	17ffffb4 	b	4530 <fwp_mem_free+0xb0>

0000000000004664 <fwp_rc_wide_dup>:
    4664:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4668:	910003fd 	mov	x29, sp
    466c:	a90153f3 	stp	x19, x20, [sp, #16]
    4670:	aa0003f3 	mov	x19, x0
    4674:	ca404400 	eor	x0, x0, x0, lsr #17
    4678:	f90013f5 	str	x21, [sp, #32]
    467c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4680:	ca402400 	eor	x0, x0, x0, lsr #9
    4684:	911702a2 	add	x2, x21, #0x5c0
    4688:	92401c00 	and	x0, x0, #0xff
    468c:	910a2403 	add	x3, x0, #0x289
    4690:	8b000c40 	add	x0, x2, x0, lsl #3
    4694:	8b030c54 	add	x20, x2, x3, lsl #3
    4698:	f94a2401 	ldr	x1, [x0, #5192]
    469c:	b50000a1 	cbnz	x1, 46b0 <fwp_rc_wide_dup+0x4c>
    46a0:	14000033 	b	476c <fwp_rc_wide_dup+0x108>
    46a4:	91004034 	add	x20, x1, #0x10
    46a8:	f9400821 	ldr	x1, [x1, #16]
    46ac:	b4000241 	cbz	x1, 46f4 <fwp_rc_wide_dup+0x90>
    46b0:	f9400022 	ldr	x2, [x1]
    46b4:	eb02027f 	cmp	x19, x2
    46b8:	54ffff61 	b.ne	46a4 <fwp_rc_wide_dup+0x40>  // b.any
    46bc:	f9400281 	ldr	x1, [x20]
    46c0:	39400260 	ldrb	w0, [x19]
    46c4:	7103f81f 	cmp	w0, #0xfe
    46c8:	54000220 	b.eq	470c <fwp_rc_wide_dup+0xa8>  // b.none
    46cc:	b40001a1 	cbz	x1, 4700 <fwp_rc_wide_dup+0x9c>
    46d0:	f9400420 	ldr	x0, [x1, #8]
    46d4:	b100041f 	cmn	x0, #0x1
    46d8:	54000440 	b.eq	4760 <fwp_rc_wide_dup+0xfc>  // b.none
    46dc:	91000400 	add	x0, x0, #0x1
    46e0:	f9000420 	str	x0, [x1, #8]
    46e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e8:	f94013f5 	ldr	x21, [sp, #32]
    46ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f0:	d65f03c0 	ret
    46f4:	39400260 	ldrb	w0, [x19]
    46f8:	7103f81f 	cmp	w0, #0xfe
    46fc:	54000100 	b.eq	471c <fwp_rc_wide_dup+0xb8>  // b.none
    4700:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4704:	91266000 	add	x0, x0, #0x998
    4708:	97fffea2 	bl	4190 <fwp_trap>
    470c:	b4000081 	cbz	x1, 471c <fwp_rc_wide_dup+0xb8>
    4710:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4714:	91270000 	add	x0, x0, #0x9c0
    4718:	97fffe9e 	bl	4190 <fwp_trap>
    471c:	d2800300 	mov	x0, #0x18                  	// #24
    4720:	97fff864 	bl	28b0 <malloc@plt>
    4724:	b4000280 	cbz	x0, 4774 <fwp_rc_wide_dup+0x110>
    4728:	d2801fe1 	mov	x1, #0xff                  	// #255
    472c:	a9000413 	stp	x19, x1, [x0]
    4730:	911702b5 	add	x21, x21, #0x5c0
    4734:	f900081f 	str	xzr, [x0, #16]
    4738:	12800001 	mov	w1, #0xffffffff            	// #-1
    473c:	f9000280 	str	x0, [x20]
    4740:	39000261 	strb	w1, [x19]
    4744:	f94e26a0 	ldr	x0, [x21, #7240]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f90e26a0 	str	x0, [x21, #7240]
    4754:	f94013f5 	ldr	x21, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4764:	9127a000 	add	x0, x0, #0x9e8
    4768:	97fffe8a 	bl	4190 <fwp_trap>
    476c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4770:	17ffffd4 	b	46c0 <fwp_rc_wide_dup+0x5c>
    4774:	97fffa4f 	bl	30b0 <fwp_heap_oom>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_closure_drop_push>:
    4780:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	a9408014 	ldp	x20, x0, [x0, #8]
    4794:	a9025bf5 	stp	x21, x22, [sp, #32]
    4798:	aa0103f5 	mov	x21, x1
    479c:	a90363f7 	stp	x23, x24, [sp, #48]
    47a0:	eb00029f 	cmp	x20, x0
    47a4:	54000160 	b.eq	47d0 <fwp_closure_drop_push+0x50>  // b.none
    47a8:	f9400276 	ldr	x22, [x19]
    47ac:	d37df297 	lsl	x23, x20, #3
    47b0:	91000694 	add	x20, x20, #0x1
    47b4:	f9000674 	str	x20, [x19, #8]
    47b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47bc:	f8376ad5 	str	x21, [x22, x23]
    47c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47cc:	d65f03c0 	ret
    47d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    47d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    47d8:	eb00029f 	cmp	x20, x0
    47dc:	540003e8 	b.hi	4858 <fwp_closure_drop_push+0xd8>  // b.pmore
    47e0:	d37cee99 	lsl	x25, x20, #4
    47e4:	d37ffa9a 	lsl	x26, x20, #1
    47e8:	aa1903e0 	mov	x0, x25
    47ec:	97fff831 	bl	28b0 <malloc@plt>
    47f0:	aa0003f6 	mov	x22, x0
    47f4:	b4000380 	cbz	x0, 4864 <fwp_closure_drop_push+0xe4>
    47f8:	aa1303f8 	mov	x24, x19
    47fc:	aa1903e3 	mov	x3, x25
    4800:	d37df297 	lsl	x23, x20, #3
    4804:	aa1703e2 	mov	x2, x23
    4808:	f8418719 	ldr	x25, [x24], #24
    480c:	aa1903e1 	mov	x1, x25
    4810:	97fff814 	bl	2860 <__memcpy_chk@plt>
    4814:	eb18033f 	cmp	x25, x24
    4818:	540000a0 	b.eq	482c <fwp_closure_drop_push+0xac>  // b.none
    481c:	aa1903e0 	mov	x0, x25
    4820:	97fff86c 	bl	29d0 <free@plt>
    4824:	f9400674 	ldr	x20, [x19, #8]
    4828:	d37df297 	lsl	x23, x20, #3
    482c:	91000694 	add	x20, x20, #0x1
    4830:	f9000276 	str	x22, [x19]
    4834:	f9000a7a 	str	x26, [x19, #16]
    4838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    483c:	f9000674 	str	x20, [x19, #8]
    4840:	f8376ad5 	str	x21, [x22, x23]
    4844:	a94153f3 	ldp	x19, x20, [sp, #16]
    4848:	a9425bf5 	ldp	x21, x22, [sp, #32]
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4854:	d65f03c0 	ret
    4858:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    485c:	91282000 	add	x0, x0, #0xa08
    4860:	97fffe4c 	bl	4190 <fwp_trap>
    4864:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4868:	f947e863 	ldr	x3, [x3, #4048]
    486c:	d2800262 	mov	x2, #0x13                  	// #19
    4870:	d2800021 	mov	x1, #0x1                   	// #1
    4874:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4878:	911ea000 	add	x0, x0, #0x7a8
    487c:	f9400063 	ldr	x3, [x3]
    4880:	97fff864 	bl	2a10 <fwrite@plt>
    4884:	d2800000 	mov	x0, #0x0                   	// #0
    4888:	97fff86e 	bl	2a40 <fflush@plt>
    488c:	52800cc0 	mov	w0, #0x66                  	// #102
    4890:	97fff87c 	bl	2a80 <_Exit@plt>

0000000000004894 <fwp_closure_drop.part.0>:
    4894:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4898:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0x860>
    489c:	910003fd 	mov	x29, sp
    48a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    48a4:	f947f463 	ldr	x3, [x3, #4072]
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	d10883ff 	sub	sp, sp, #0x220
    48b0:	910003e2 	mov	x2, sp
    48b4:	d53bd053 	mrs	x19, tpidr_el0
    48b8:	910063f4 	add	x20, sp, #0x18
    48bc:	3dc13420 	ldr	q0, [x1, #1232]
    48c0:	91400264 	add	x4, x19, #0x0, lsl #12
    48c4:	91004084 	add	x4, x4, #0x10
    48c8:	aa0003e1 	mov	x1, x0
    48cc:	aa0203e0 	mov	x0, x2
    48d0:	f9400062 	ldr	x2, [x3]
    48d4:	f9010fe2 	str	x2, [sp, #536]
    48d8:	d2800002 	mov	x2, #0x0                   	// #0
    48dc:	f90003f4 	str	x20, [sp]
    48e0:	f9000080 	str	x0, [x4]
    48e4:	3c8083e0 	stur	q0, [sp, #8]
    48e8:	97ffffa6 	bl	4780 <fwp_closure_drop_push>
    48ec:	f94007e0 	ldr	x0, [sp, #8]
    48f0:	b40002e0 	cbz	x0, 494c <fwp_closure_drop.part.0+0xb8>
    48f4:	f90123f5 	str	x21, [sp, #576]
    48f8:	900000f5 	adrp	x21, 20000 <__data_start>
    48fc:	910182b5 	add	x21, x21, #0x60
    4900:	14000006 	b	4918 <fwp_closure_drop.part.0+0x84>
    4904:	f9400422 	ldr	x2, [x1, #8]
    4908:	52800001 	mov	w1, #0x0                   	// #0
    490c:	d63f0040 	blr	x2
    4910:	f94007e0 	ldr	x0, [sp, #8]
    4914:	b40001a0 	cbz	x0, 4948 <fwp_closure_drop.part.0+0xb4>
    4918:	f94003e1 	ldr	x1, [sp]
    491c:	d1000400 	sub	x0, x0, #0x1
    4920:	f90007e0 	str	x0, [sp, #8]
    4924:	f94066a2 	ldr	x2, [x21, #200]
    4928:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    492c:	b9400001 	ldr	w1, [x0]
    4930:	8b011441 	add	x1, x2, x1, lsl #5
    4934:	f9400c21 	ldr	x1, [x1, #24]
    4938:	b5fffe61 	cbnz	x1, 4904 <fwp_closure_drop.part.0+0x70>
    493c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4940:	9128a000 	add	x0, x0, #0xa28
    4944:	97fffe13 	bl	4190 <fwp_trap>
    4948:	f94123f5 	ldr	x21, [sp, #576]
    494c:	91400273 	add	x19, x19, #0x0, lsl #12
    4950:	91004273 	add	x19, x19, #0x10
    4954:	f94003e0 	ldr	x0, [sp]
    4958:	f900027f 	str	xzr, [x19]
    495c:	eb14001f 	cmp	x0, x20
    4960:	54000040 	b.eq	4968 <fwp_closure_drop.part.0+0xd4>  // b.none
    4964:	97fff81b 	bl	29d0 <free@plt>
    4968:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    496c:	f947f400 	ldr	x0, [x0, #4072]
    4970:	f9410fe2 	ldr	x2, [sp, #536]
    4974:	f9400001 	ldr	x1, [x0]
    4978:	eb010042 	subs	x2, x2, x1
    497c:	d2800001 	mov	x1, #0x0                   	// #0
    4980:	540000a1 	b.ne	4994 <fwp_closure_drop.part.0+0x100>  // b.any
    4984:	910883ff 	add	sp, sp, #0x220
    4988:	a94153f3 	ldp	x19, x20, [sp, #16]
    498c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4990:	d65f03c0 	ret
    4994:	f90123f5 	str	x21, [sp, #576]
    4998:	97fff7de 	bl	2910 <__stack_chk_fail@plt>
    499c:	d503201f 	nop

00000000000049a0 <fwp_tape_of>:
    49a0:	aa0003e1 	mov	x1, x0
    49a4:	92403c00 	and	x0, x0, #0xffff
    49a8:	b40000e0 	cbz	x0, 49c4 <fwp_tape_of+0x24>
    49ac:	d1000402 	sub	x2, x0, #0x1
    49b0:	900000e3 	adrp	x3, 20000 <__data_start>
    49b4:	91018060 	add	x0, x3, #0x60
    49b8:	f9406800 	ldr	x0, [x0, #208]
    49bc:	eb02001f 	cmp	x0, x2
    49c0:	540000cc 	b.gt	49d8 <fwp_tape_of+0x38>
    49c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    49c8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    49cc:	91296000 	add	x0, x0, #0xa58
    49d0:	910003fd 	mov	x29, sp
    49d4:	97fffdef 	bl	4190 <fwp_trap>
    49d8:	8b020440 	add	x0, x2, x2, lsl #1
    49dc:	f9403063 	ldr	x3, [x3, #96]
    49e0:	8b000842 	add	x2, x2, x0, lsl #2
    49e4:	d37df042 	lsl	x2, x2, #3
    49e8:	8b020060 	add	x0, x3, x2
    49ec:	b9400404 	ldr	w4, [x0, #4]
    49f0:	34fffea4 	cbz	w4, 49c4 <fwp_tape_of+0x24>
    49f4:	b8626862 	ldr	w2, [x3, x2]
    49f8:	9350fc21 	asr	x1, x1, #16
    49fc:	6b01005f 	cmp	w2, w1
    4a00:	54fffe21 	b.ne	49c4 <fwp_tape_of+0x24>  // b.any
    4a04:	d65f03c0 	ret
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_now_ns>:
    4a10:	d100c3ff 	sub	sp, sp, #0x30
    4a14:	52800020 	mov	w0, #0x1                   	// #1
    4a18:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    4a1c:	f947f442 	ldr	x2, [x2, #4072]
    4a20:	910023e1 	add	x1, sp, #0x8
    4a24:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a28:	910083fd 	add	x29, sp, #0x20
    4a2c:	f9400043 	ldr	x3, [x2]
    4a30:	f9000fe3 	str	x3, [sp, #24]
    4a34:	d2800003 	mov	x3, #0x0                   	// #0
    4a38:	97fff782 	bl	2840 <clock_gettime@plt>
    4a3c:	350002c0 	cbnz	w0, 4a94 <fwp_now_ns+0x84>
    4a40:	a9408be1 	ldp	x1, x2, [sp, #8]
    4a44:	d2994003 	mov	x3, #0xca00                	// #51712
    4a48:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4a4c:	9b037c20 	mul	x0, x1, x3
    4a50:	9b437c21 	smulh	x1, x1, x3
    4a54:	ab020000 	adds	x0, x0, x2
    4a58:	937ffc42 	asr	x2, x2, #63
    4a5c:	9a020021 	adc	x1, x1, x2
    4a60:	f100001f 	cmp	x0, #0x0
    4a64:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4a68:	b50001c1 	cbnz	x1, 4aa0 <fwp_now_ns+0x90>
    4a6c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4a70:	f947f421 	ldr	x1, [x1, #4072]
    4a74:	f9400fe3 	ldr	x3, [sp, #24]
    4a78:	f9400022 	ldr	x2, [x1]
    4a7c:	eb020063 	subs	x3, x3, x2
    4a80:	d2800002 	mov	x2, #0x0                   	// #0
    4a84:	54000141 	b.ne	4aac <fwp_now_ns+0x9c>  // b.any
    4a88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a8c:	9100c3ff 	add	sp, sp, #0x30
    4a90:	d65f03c0 	ret
    4a94:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4a98:	912aa000 	add	x0, x0, #0xaa8
    4a9c:	97fffdbd 	bl	4190 <fwp_trap>
    4aa0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4aa4:	912b2000 	add	x0, x0, #0xac8
    4aa8:	97fffdba 	bl	4190 <fwp_trap>
    4aac:	97fff799 	bl	2910 <__stack_chk_fail@plt>

0000000000004ab0 <fwp_poll_events>:
    4ab0:	d10103ff 	sub	sp, sp, #0x40
    4ab4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4ab8:	f947f400 	ldr	x0, [x0, #4072]
    4abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4ac0:	910083fd 	add	x29, sp, #0x20
    4ac4:	f9001bf3 	str	x19, [sp, #48]
    4ac8:	900000f3 	adrp	x19, 20000 <__data_start>
    4acc:	f9400001 	ldr	x1, [x0]
    4ad0:	f9000fe1 	str	x1, [sp, #24]
    4ad4:	d2800001 	mov	x1, #0x0                   	// #0
    4ad8:	97ffffce 	bl	4a10 <fwp_now_ns>
    4adc:	91018261 	add	x1, x19, #0x60
    4ae0:	f9406c21 	ldr	x1, [x1, #216]
    4ae4:	b4000e01 	cbz	x1, 4ca4 <fwp_poll_events+0x1f4>
    4ae8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4aec:	14000005 	b	4b00 <fwp_poll_events+0x50>
    4af0:	f9408821 	ldr	x1, [x1, #272]
    4af4:	eb03005f 	cmp	x2, x3
    4af8:	9a83d042 	csel	x2, x2, x3, le
    4afc:	b40000c1 	cbz	x1, 4b14 <fwp_poll_events+0x64>
    4b00:	f9403423 	ldr	x3, [x1, #104]
    4b04:	b6ffff62 	tbz	x2, #63, 4af0 <fwp_poll_events+0x40>
    4b08:	f9408821 	ldr	x1, [x1, #272]
    4b0c:	aa0303e2 	mov	x2, x3
    4b10:	b5ffff81 	cbnz	x1, 4b00 <fwp_poll_events+0x50>
    4b14:	b7f80c82 	tbnz	x2, #63, 4ca4 <fwp_poll_events+0x1f4>
    4b18:	cb000042 	sub	x2, x2, x0
    4b1c:	f100005f 	cmp	x2, #0x0
    4b20:	540003ad 	b.le	4b94 <fwp_poll_events+0xe4>
    4b24:	d2869b60 	mov	x0, #0x34db                	// #13531
    4b28:	d2884804 	mov	x4, #0x4240                	// #16960
    4b2c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4b30:	f2a001e4 	movk	x4, #0xf, lsl #16
    4b34:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4b38:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4b3c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4b40:	9b407c40 	smulh	x0, x2, x0
    4b44:	9352fc00 	asr	x0, x0, #18
    4b48:	cb82fc00 	sub	x0, x0, x2, asr #63
    4b4c:	9b048802 	msub	x2, x0, x4, x2
    4b50:	f100005f 	cmp	x2, #0x0
    4b54:	9a800400 	cinc	x0, x0, ne	// ne = any
    4b58:	eb01001f 	cmp	x0, x1
    4b5c:	5400098c 	b.gt	4c8c <fwp_poll_events+0x1dc>
    4b60:	340001a0 	cbz	w0, 4b94 <fwp_poll_events+0xe4>
    4b64:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4b68:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4b6c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4b70:	9ba17c01 	umull	x1, w0, w1
    4b74:	d366fc23 	lsr	x3, x1, #38
    4b78:	aa0303e2 	mov	x2, x3
    4b7c:	1b058063 	msub	w3, w3, w5, w0
    4b80:	9b247c63 	smull	x3, w3, w4
    4b84:	910023e0 	add	x0, sp, #0x8
    4b88:	d2800001 	mov	x1, #0x0                   	// #0
    4b8c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b90:	97fff794 	bl	29e0 <nanosleep@plt>
    4b94:	97ffff9f 	bl	4a10 <fwp_now_ns>
    4b98:	91018268 	add	x8, x19, #0x60
    4b9c:	aa0003e7 	mov	x7, x0
    4ba0:	4f000400 	movi	v0.4s, #0x0
    4ba4:	52800029 	mov	w9, #0x1                   	// #1
    4ba8:	f9406d06 	ldr	x6, [x8, #216]
    4bac:	d503201f 	nop
    4bb0:	b40003e6 	cbz	x6, 4c2c <fwp_poll_events+0x17c>
    4bb4:	f94034c1 	ldr	x1, [x6, #104]
    4bb8:	aa0603e5 	mov	x5, x6
    4bbc:	f94088c6 	ldr	x6, [x6, #272]
    4bc0:	eb07003f 	cmp	x1, x7
    4bc4:	54ffff6c 	b.gt	4bb0 <fwp_poll_events+0x100>
    4bc8:	394154a0 	ldrb	w0, [x5, #85]
    4bcc:	36000120 	tbz	w0, #0, 4bf0 <fwp_poll_events+0x140>
    4bd0:	f94084a0 	ldr	x0, [x5, #264]
    4bd4:	b4000560 	cbz	x0, 4c80 <fwp_poll_events+0x1d0>
    4bd8:	f9008806 	str	x6, [x0, #272]
    4bdc:	b4000046 	cbz	x6, 4be4 <fwp_poll_events+0x134>
    4be0:	f90084c0 	str	x0, [x6, #264]
    4be4:	910800a0 	add	x0, x5, #0x200
    4be8:	390154bf 	strb	wzr, [x5, #85]
    4bec:	3c908000 	stur	q0, [x0, #-248]
    4bf0:	f94030a0 	ldr	x0, [x5, #96]
    4bf4:	390158a9 	strb	w9, [x5, #86]
    4bf8:	f100001f 	cmp	x0, #0x0
    4bfc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4c00:	540002cd 	b.le	4c58 <fwp_poll_events+0x1a8>
    4c04:	f94028a0 	ldr	x0, [x5, #80]
    4c08:	f2001c1f 	tst	x0, #0xff000000ff
    4c0c:	54fffd21 	b.ne	4bb0 <fwp_poll_events+0x100>  // b.any
    4c10:	f9403d00 	ldr	x0, [x8, #120]
    4c14:	390150a9 	strb	w9, [x5, #84]
    4c18:	f90080bf 	str	xzr, [x5, #256]
    4c1c:	b40002c0 	cbz	x0, 4c74 <fwp_poll_events+0x1c4>
    4c20:	f9003d05 	str	x5, [x8, #120]
    4c24:	f9008005 	str	x5, [x0, #256]
    4c28:	b5fffc66 	cbnz	x6, 4bb4 <fwp_poll_events+0x104>
    4c2c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4c30:	f947f400 	ldr	x0, [x0, #4072]
    4c34:	f9400fe2 	ldr	x2, [sp, #24]
    4c38:	f9400001 	ldr	x1, [x0]
    4c3c:	eb010042 	subs	x2, x2, x1
    4c40:	d2800001 	mov	x1, #0x0                   	// #0
    4c44:	540002e1 	b.ne	4ca0 <fwp_poll_events+0x1f0>  // b.any
    4c48:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c4c:	f9401bf3 	ldr	x19, [sp, #48]
    4c50:	910103ff 	add	sp, sp, #0x40
    4c54:	d65f03c0 	ret
    4c58:	394144a0 	ldrb	w0, [x5, #81]
    4c5c:	3707fd40 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c60:	394140a0 	ldrb	w0, [x5, #80]
    4c64:	3707fd00 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c68:	aa0503e0 	mov	x0, x5
    4c6c:	97fffac1 	bl	3770 <fwp_cancel_tree.part.0>
    4c70:	17ffffe5 	b	4c04 <fwp_poll_events+0x154>
    4c74:	f9003d05 	str	x5, [x8, #120]
    4c78:	f9004105 	str	x5, [x8, #128]
    4c7c:	17ffffeb 	b	4c28 <fwp_poll_events+0x178>
    4c80:	91018261 	add	x1, x19, #0x60
    4c84:	f9006c26 	str	x6, [x1, #216]
    4c88:	17ffffd5 	b	4bdc <fwp_poll_events+0x12c>
    4c8c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c90:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c94:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c98:	f2a00402 	movk	x2, #0x20, lsl #16
    4c9c:	17ffffba 	b	4b84 <fwp_poll_events+0xd4>
    4ca0:	97fff71c 	bl	2910 <__stack_chk_fail@plt>
    4ca4:	97fff8f3 	bl	3070 <fwp_flush>
    4ca8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4cac:	f947e863 	ldr	x3, [x3, #4048]
    4cb0:	d2800562 	mov	x2, #0x2b                  	// #43
    4cb4:	d2800021 	mov	x1, #0x1                   	// #1
    4cb8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    4cbc:	912bc000 	add	x0, x0, #0xaf0
    4cc0:	f9400063 	ldr	x3, [x3]
    4cc4:	97fff753 	bl	2a10 <fwrite@plt>
    4cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    4ccc:	97fff6bd 	bl	27c0 <exit@plt>

0000000000004cd0 <fwp_heap_alloc_big>:
    4cd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd4:	910003fd 	mov	x29, sp
    4cd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce4:	aa0003f7 	mov	x23, x0
    4ce8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf0:	eb0002ff 	cmp	x23, x0
    4cf4:	540008a8 	b.hi	4e08 <fwp_heap_alloc_big+0x138>  // b.pmore
    4cf8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cfc:	8b0002f4 	add	x20, x23, x0
    4d00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc20>
    4d04:	91170359 	add	x25, x26, #0x5c0
    4d08:	d350fe94 	lsr	x20, x20, #16
    4d0c:	2a0103f5 	mov	w21, w1
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff987 	bl	3330 <fwp_heap_chunks>
    4d18:	f949ff22 	ldr	x2, [x25, #5112]
    4d1c:	8b000813 	add	x19, x0, x0, lsl #2
    4d20:	aa0003f8 	mov	x24, x0
    4d24:	52800043 	mov	w3, #0x2                   	// #2
    4d28:	d37df273 	lsl	x19, x19, #3
    4d2c:	d2800021 	mov	x1, #0x1                   	// #1
    4d30:	8b130040 	add	x0, x2, x19
    4d34:	38336843 	strb	w3, [x2, x19]
    4d38:	39000415 	strb	w21, [x0, #1]
    4d3c:	b9000c14 	str	w20, [x0, #12]
    4d40:	f9000817 	str	x23, [x0, #16]
    4d44:	97fffd57 	bl	42a0 <fwp_rc_prepare_chunk>
    4d48:	f100069f 	cmp	x20, #0x1
    4d4c:	54000289 	b.ls	4d9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4d50:	8b180294 	add	x20, x20, x24
    4d54:	9100a273 	add	x19, x19, #0x28
    4d58:	a90573fb 	stp	x27, x28, [sp, #80]
    4d5c:	5280007b 	mov	w27, #0x3                   	// #3
    4d60:	8b140a94 	add	x20, x20, x20, lsl #2
    4d64:	2a1803fc 	mov	w28, w24
    4d68:	9adb2296 	lsl	x22, x20, x27
    4d6c:	d503201f 	nop
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffd48 	bl	42a0 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0xa0>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91170353 	add	x19, x26, #0x5c0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x108>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117035a 	add	x26, x26, #0x5c0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    4e20:	91170262 	add	x2, x19, #0x5c0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91170262 	add	x2, x19, #0x5c0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91170260 	add	x0, x19, #0x5c0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91170273 	add	x19, x19, #0x5c0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffbbf 	bl	3df0 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff6f 	b	4cd0 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91170260 	add	x0, x19, #0x5c0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffd19 	bl	43c0 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    4f84:	91170293 	add	x19, x20, #0x5c0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91170294 	add	x20, x20, #0x5c0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    5094:	91170283 	add	x3, x20, #0x5c0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91170282 	add	x2, x20, #0x5c0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91170294 	add	x20, x20, #0x5c0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_tape_reserve>:
    51a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51a8:	910003fd 	mov	x29, sp
    51ac:	a90153f3 	stp	x19, x20, [sp, #16]
    51b0:	aa0003f3 	mov	x19, x0
    51b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51b8:	eb00003f 	cmp	x1, x0
    51bc:	54000868 	b.hi	52c8 <fwp_tape_reserve+0x124>  // b.pmore
    51c0:	f9400e74 	ldr	x20, [x19, #24]
    51c4:	eb01029f 	cmp	x20, x1
    51c8:	5400076a 	b.ge	52b4 <fwp_tape_reserve+0x110>  // b.tcont
    51cc:	f100029f 	cmp	x20, #0x0
    51d0:	d2800802 	mov	x2, #0x40                  	// #64
    51d4:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    51d8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    51dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51e0:	a90363f7 	stp	x23, x24, [sp, #48]
    51e4:	eb01029f 	cmp	x20, x1
    51e8:	5400008a 	b.ge	51f8 <fwp_tape_reserve+0x54>  // b.tcont
    51ec:	eb00029f 	cmp	x20, x0
    51f0:	5400068d 	b.le	52c0 <fwp_tape_reserve+0x11c>
    51f4:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    51f8:	a940d662 	ldp	x2, x21, [x19, #8]
    51fc:	d37df297 	lsl	x23, x20, #3
    5200:	f9401260 	ldr	x0, [x19, #32]
    5204:	aa1703e1 	mov	x1, x23
    5208:	f9403276 	ldr	x22, [x19, #96]
    520c:	cb0202b5 	sub	x21, x21, x2
    5210:	97fff5bc 	bl	2900 <realloc@plt>
    5214:	b4000b00 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    5218:	f9400e61 	ldr	x1, [x19, #24]
    521c:	8b010801 	add	x1, x0, x1, lsl #2
    5220:	a9020660 	stp	x0, x1, [x19, #32]
    5224:	b40008b6 	cbz	x22, 5338 <fwp_tape_reserve+0x194>
    5228:	f94032d7 	ldr	x23, [x22, #96]
    522c:	eb17029f 	cmp	x20, x23
    5230:	5400034d 	b.le	5298 <fwp_tape_reserve+0xf4>
    5234:	a9046bf9 	stp	x25, x26, [sp, #64]
    5238:	d37cee9a 	lsl	x26, x20, #4
    523c:	aa1a03e0 	mov	x0, x26
    5240:	f94022d9 	ldr	x25, [x22, #64]
    5244:	52800041 	mov	w1, #0x2                   	// #2
    5248:	97ffff4a 	bl	4f70 <fwp_heap_alloc>
    524c:	aa0003f8 	mov	x24, x0
    5250:	b4000119 	cbz	x25, 5270 <fwp_tape_reserve+0xcc>
    5254:	d37ceef7 	lsl	x23, x23, #4
    5258:	aa1903e1 	mov	x1, x25
    525c:	eb1a02ff 	cmp	x23, x26
    5260:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    5264:	97fff53f 	bl	2760 <memcpy@plt>
    5268:	aa1903e0 	mov	x0, x25
    526c:	97fffc85 	bl	4480 <fwp_mem_free>
    5270:	f94032c0 	ldr	x0, [x22, #96]
    5274:	52800001 	mov	w1, #0x0                   	// #0
    5278:	cb000282 	sub	x2, x20, x0
    527c:	8b001300 	add	x0, x24, x0, lsl #4
    5280:	d37cec42 	lsl	x2, x2, #4
    5284:	97fff597 	bl	28e0 <memset@plt>
    5288:	f9401260 	ldr	x0, [x19, #32]
    528c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5290:	f90022d8 	str	x24, [x22, #64]
    5294:	f90032d4 	str	x20, [x22, #96]
    5298:	d37ef696 	lsl	x22, x20, #2
    529c:	b5000375 	cbnz	x21, 5308 <fwp_tape_reserve+0x164>
    52a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    52a4:	8b160000 	add	x0, x0, x22
    52a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52ac:	f9000e74 	str	x20, [x19, #24]
    52b0:	f9001660 	str	x0, [x19, #40]
    52b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52bc:	d65f03c0 	ret
    52c0:	d37ffa94 	lsl	x20, x20, #1
    52c4:	17ffffc8 	b	51e4 <fwp_tape_reserve+0x40>
    52c8:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    52cc:	912d2000 	add	x0, x0, #0xb48
    52d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    52d4:	a90363f7 	stp	x23, x24, [sp, #48]
    52d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52dc:	97fffbad 	bl	4190 <fwp_trap>
    52e0:	eb1602ff 	cmp	x23, x22
    52e4:	aa0403e0 	mov	x0, x4
    52e8:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    52ec:	d37df2a2 	lsl	x2, x21, #3
    52f0:	cb170063 	sub	x3, x3, x23
    52f4:	97fff5ef 	bl	2ab0 <__memmove_chk@plt>
    52f8:	f9401a61 	ldr	x1, [x19, #48]
    52fc:	f9401260 	ldr	x0, [x19, #32]
    5300:	8b170021 	add	x1, x1, x23
    5304:	f9001e61 	str	x1, [x19, #56]
    5308:	f9401661 	ldr	x1, [x19, #40]
    530c:	d37ef696 	lsl	x22, x20, #2
    5310:	d37ef6a2 	lsl	x2, x21, #2
    5314:	8b160000 	add	x0, x0, x22
    5318:	97fff51a 	bl	2780 <memmove@plt>
    531c:	f9401260 	ldr	x0, [x19, #32]
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	8b160000 	add	x0, x0, x22
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000e74 	str	x20, [x19, #24]
    5330:	f9001660 	str	x0, [x19, #40]
    5334:	17ffffe0 	b	52b4 <fwp_tape_reserve+0x110>
    5338:	f9401a60 	ldr	x0, [x19, #48]
    533c:	d37cee96 	lsl	x22, x20, #4
    5340:	aa1603e1 	mov	x1, x22
    5344:	97fff56f 	bl	2900 <realloc@plt>
    5348:	b4000160 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    534c:	f9400e62 	ldr	x2, [x19, #24]
    5350:	f9001a60 	str	x0, [x19, #48]
    5354:	8b170004 	add	x4, x0, x23
    5358:	8b020c01 	add	x1, x0, x2, lsl #3
    535c:	f9001e61 	str	x1, [x19, #56]
    5360:	b5fffc15 	cbnz	x21, 52e0 <fwp_tape_reserve+0x13c>
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	d37ef696 	lsl	x22, x20, #2
    536c:	f9001e64 	str	x4, [x19, #56]
    5370:	17ffffcc 	b	52a0 <fwp_tape_reserve+0xfc>
    5374:	aa1303e0 	mov	x0, x19
    5378:	a9046bf9 	stp	x25, x26, [sp, #64]
    537c:	97fff725 	bl	3010 <fwp_tape_unlink_scope>
    5380:	f9401260 	ldr	x0, [x19, #32]
    5384:	97fff593 	bl	29d0 <free@plt>
    5388:	f9401a60 	ldr	x0, [x19, #48]
    538c:	97fff591 	bl	29d0 <free@plt>
    5390:	f9402260 	ldr	x0, [x19, #64]
    5394:	97fff58f 	bl	29d0 <free@plt>
    5398:	f9000e7f 	str	xzr, [x19, #24]
    539c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    53a0:	f947e821 	ldr	x1, [x1, #4048]
    53a4:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    53a8:	d2800262 	mov	x2, #0x13                  	// #19
    53ac:	4f000400 	movi	v0.4s, #0x0
    53b0:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    53b4:	f9400023 	ldr	x3, [x1]
    53b8:	b900067f 	str	wzr, [x19, #4]
    53bc:	d2800021 	mov	x1, #0x1                   	// #1
    53c0:	911ea000 	add	x0, x0, #0x7a8
    53c4:	3c808260 	stur	q0, [x19, #8]
    53c8:	ad010260 	stp	q0, q0, [x19, #32]
    53cc:	97fff591 	bl	2a10 <fwrite@plt>
    53d0:	d2800000 	mov	x0, #0x0                   	// #0
    53d4:	97fff59b 	bl	2a40 <fflush@plt>
    53d8:	52800cc0 	mov	w0, #0x66                  	// #102
    53dc:	97fff5a9 	bl	2a80 <_Exit@plt>

00000000000053e0 <f141.constprop.0>:
    53e0:	f100001f 	cmp	x0, #0x0
    53e4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    53e8:	5400094b 	b.lt	5510 <f141.constprop.0+0x130>  // b.tstop
    53ec:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53f0:	aa0003e2 	mov	x2, x0
    53f4:	910003fd 	mov	x29, sp
    53f8:	a90153f3 	stp	x19, x20, [sp, #16]
    53fc:	aa0003f4 	mov	x20, x0
    5400:	aa010000 	orr	x0, x0, x1
    5404:	a9025bf5 	stp	x21, x22, [sp, #32]
    5408:	aa0103f6 	mov	x22, x1
    540c:	f9001bf7 	str	x23, [sp, #48]
    5410:	fd001fe8 	str	d8, [sp, #56]
    5414:	b7f80180 	tbnz	x0, #63, 5444 <f141.constprop.0+0x64>
    5418:	9360fc20 	asr	x0, x1, #32
    541c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5420:	eb82801f 	cmp	x0, x2, asr #32
    5424:	540007a1 	b.ne	5518 <f141.constprop.0+0x138>  // b.any
    5428:	97fffd5e 	bl	49a0 <fwp_tape_of>
    542c:	aa0003f3 	mov	x19, x0
    5430:	f9403000 	ldr	x0, [x0, #96]
    5434:	b40001e0 	cbz	x0, 5470 <f141.constprop.0+0x90>
    5438:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    543c:	912ec000 	add	x0, x0, #0xbb0
    5440:	97fffb54 	bl	4190 <fwp_trap>
    5444:	9360fc40 	asr	x0, x2, #32
    5448:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    544c:	b6fffee2 	tbz	x2, #63, 5428 <f141.constprop.0+0x48>
    5450:	2f00e408 	movi	d8, #0x0
    5454:	9360fc20 	asr	x0, x1, #32
    5458:	aa0103f4 	mov	x20, x1
    545c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5460:	97fffd50 	bl	49a0 <fwp_tape_of>
    5464:	aa0003f3 	mov	x19, x0
    5468:	f9403000 	ldr	x0, [x0, #96]
    546c:	b5fffe60 	cbnz	x0, 5438 <f141.constprop.0+0x58>
    5470:	f9400a77 	ldr	x23, [x19, #16]
    5474:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5478:	eb0002ff 	cmp	x23, x0
    547c:	5400044c 	b.gt	5504 <f141.constprop.0+0x124>
    5480:	eb3442ff 	cmp	x23, w20, uxtw
    5484:	5400008d 	b.le	5494 <f141.constprop.0+0xb4>
    5488:	b7f800d6 	tbnz	x22, #63, 54a0 <f141.constprop.0+0xc0>
    548c:	eb3642ff 	cmp	x23, w22, uxtw
    5490:	5400008c 	b.gt	54a0 <f141.constprop.0+0xc0>
    5494:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    5498:	912f8000 	add	x0, x0, #0xbe0
    549c:	97fffb3d 	bl	4190 <fwp_trap>
    54a0:	f9400675 	ldr	x21, [x19, #8]
    54a4:	aa1303e0 	mov	x0, x19
    54a8:	cb1502f5 	sub	x21, x23, x21
    54ac:	910006a1 	add	x1, x21, #0x1
    54b0:	97ffff3d 	bl	51a4 <fwp_tape_reserve>
    54b4:	a9420262 	ldp	x2, x0, [x19, #32]
    54b8:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54bc:	f9401a61 	ldr	x1, [x19, #48]
    54c0:	b8357854 	str	w20, [x2, x21, lsl #2]
    54c4:	f9401e62 	ldr	x2, [x19, #56]
    54c8:	f10002df 	cmp	x22, #0x0
    54cc:	fc357820 	str	d0, [x1, x21, lsl #3]
    54d0:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    54d4:	b8357816 	str	w22, [x0, x21, lsl #2]
    54d8:	92607e80 	and	x0, x20, #0xffffffff00000000
    54dc:	910006e1 	add	x1, x23, #0x1
    54e0:	aa170000 	orr	x0, x0, x23
    54e4:	fc357848 	str	d8, [x2, x21, lsl #3]
    54e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54ec:	f9401bf7 	ldr	x23, [sp, #48]
    54f0:	fd401fe8 	ldr	d8, [sp, #56]
    54f4:	f9000a61 	str	x1, [x19, #16]
    54f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    54fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5500:	d65f03c0 	ret
    5504:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    5508:	912d2000 	add	x0, x0, #0xb48
    550c:	97fffb21 	bl	4190 <fwp_trap>
    5510:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5514:	d65f03c0 	ret
    5518:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    551c:	912da000 	add	x0, x0, #0xb68
    5520:	97fffb1c 	bl	4190 <fwp_trap>

0000000000005524 <w120>:
    5524:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5528:	910003fd 	mov	x29, sp
    552c:	a90153f3 	stp	x19, x20, [sp, #16]
    5530:	a9025bf5 	stp	x21, x22, [sp, #32]
    5534:	aa0003f5 	mov	x21, x0
    5538:	a90363f7 	stp	x23, x24, [sp, #48]
    553c:	aa0103f7 	mov	x23, x1
    5540:	a9046bf9 	stp	x25, x26, [sp, #64]
    5544:	f9002bfb 	str	x27, [sp, #80]
    5548:	6d0627e8 	stp	d8, d9, [sp, #96]
    554c:	1e604028 	fmov	d8, d1
    5550:	1e600809 	fmul	d9, d0, d0
    5554:	6d072fea 	stp	d10, d11, [sp, #112]
    5558:	1e60400b 	fmov	d11, d0
    555c:	b7f81c80 	tbnz	x0, #63, 58ec <w120+0x3c8>
    5560:	9360fc19 	asr	x25, x0, #32
    5564:	aa1903e0 	mov	x0, x25
    5568:	97fffd0e 	bl	49a0 <fwp_tape_of>
    556c:	f9403001 	ldr	x1, [x0, #96]
    5570:	aa0003f3 	mov	x19, x0
    5574:	b4000081 	cbz	x1, 5584 <w120+0x60>
    5578:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    557c:	912ec000 	add	x0, x0, #0xbb0
    5580:	97fffb04 	bl	4190 <fwp_trap>
    5584:	f9400818 	ldr	x24, [x0, #16]
    5588:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    558c:	eb01031f 	cmp	x24, x1
    5590:	54001a8c 	b.gt	58e0 <w120+0x3bc>
    5594:	eb35431f 	cmp	x24, w21, uxtw
    5598:	540019ed 	b.le	58d4 <w120+0x3b0>
    559c:	f9400416 	ldr	x22, [x0, #8]
    55a0:	92607eb4 	and	x20, x21, #0xffffffff00000000
    55a4:	aa180294 	orr	x20, x20, x24
    55a8:	cb160316 	sub	x22, x24, x22
    55ac:	910006c1 	add	x1, x22, #0x1
    55b0:	97fffefd 	bl	51a4 <fwp_tape_reserve>
    55b4:	a9420a61 	ldp	x1, x2, [x19, #32]
    55b8:	91000700 	add	x0, x24, #0x1
    55bc:	f9401a63 	ldr	x3, [x19, #48]
    55c0:	b8367835 	str	w21, [x1, x22, lsl #2]
    55c4:	f9401e61 	ldr	x1, [x19, #56]
    55c8:	1e693908 	fsub	d8, d8, d9
    55cc:	fc36786b 	str	d11, [x3, x22, lsl #3]
    55d0:	9360fe9a 	asr	x26, x20, #32
    55d4:	b8367855 	str	w21, [x2, x22, lsl #2]
    55d8:	fc36782b 	str	d11, [x1, x22, lsl #3]
    55dc:	f9000a60 	str	x0, [x19, #16]
    55e0:	b7f80077 	tbnz	x23, #63, 55ec <w120+0xc8>
    55e4:	eb97835f 	cmp	x26, x23, asr #32
    55e8:	540019a1 	b.ne	591c <w120+0x3f8>  // b.any
    55ec:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    55f0:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    55f4:	eb19035f 	cmp	x26, x25
    55f8:	540000c0 	b.eq	5610 <w120+0xec>  // b.none
    55fc:	aa1a03e0 	mov	x0, x26
    5600:	97fffce8 	bl	49a0 <fwp_tape_of>
    5604:	aa0003f3 	mov	x19, x0
    5608:	f9403000 	ldr	x0, [x0, #96]
    560c:	b5fffb60 	cbnz	x0, 5578 <w120+0x54>
    5610:	f9400a79 	ldr	x25, [x19, #16]
    5614:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5618:	eb00033f 	cmp	x25, x0
    561c:	5400162c 	b.gt	58e0 <w120+0x3bc>
    5620:	eb34433f 	cmp	x25, w20, uxtw
    5624:	5400158d 	b.le	58d4 <w120+0x3b0>
    5628:	b7f80077 	tbnz	x23, #63, 5634 <w120+0x110>
    562c:	eb37433f 	cmp	x25, w23, uxtw
    5630:	5400152d 	b.le	58d4 <w120+0x3b0>
    5634:	f9400676 	ldr	x22, [x19, #8]
    5638:	aa1303e0 	mov	x0, x19
    563c:	cb160336 	sub	x22, x25, x22
    5640:	910006c1 	add	x1, x22, #0x1
    5644:	97fffed8 	bl	51a4 <fwp_tape_reserve>
    5648:	a9420e62 	ldp	x2, x3, [x19, #32]
    564c:	f10002ff 	cmp	x23, #0x0
    5650:	f9401a61 	ldr	x1, [x19, #48]
    5654:	b8367854 	str	w20, [x2, x22, lsl #2]
    5658:	f9401e62 	ldr	x2, [x19, #56]
    565c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5660:	fc367829 	str	d9, [x1, x22, lsl #3]
    5664:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5668:	b8367861 	str	w1, [x3, x22, lsl #2]
    566c:	91000737 	add	x23, x25, #0x1
    5670:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5674:	92607e94 	and	x20, x20, #0xffffffff00000000
    5678:	fc36784a 	str	d10, [x2, x22, lsl #3]
    567c:	aa190294 	orr	x20, x20, x25
    5680:	f9000a77 	str	x23, [x19, #16]
    5684:	1e6b3929 	fsub	d9, d9, d11
    5688:	b7f81675 	tbnz	x21, #63, 5954 <w120+0x430>
    568c:	9360febb 	asr	x27, x21, #32
    5690:	eb1a037f 	cmp	x27, x26
    5694:	540000e0 	b.eq	56b0 <w120+0x18c>  // b.none
    5698:	aa1b03e0 	mov	x0, x27
    569c:	97fffcc1 	bl	49a0 <fwp_tape_of>
    56a0:	aa0003f3 	mov	x19, x0
    56a4:	f9403000 	ldr	x0, [x0, #96]
    56a8:	b5fff680 	cbnz	x0, 5578 <w120+0x54>
    56ac:	f9400a77 	ldr	x23, [x19, #16]
    56b0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56b4:	eb0002ff 	cmp	x23, x0
    56b8:	5400114c 	b.gt	58e0 <w120+0x3bc>
    56bc:	eb3542ff 	cmp	x23, w21, uxtw
    56c0:	540010ad 	b.le	58d4 <w120+0x3b0>
    56c4:	f9400676 	ldr	x22, [x19, #8]
    56c8:	aa1303e0 	mov	x0, x19
    56cc:	cb1602f6 	sub	x22, x23, x22
    56d0:	910006c1 	add	x1, x22, #0x1
    56d4:	97fffeb4 	bl	51a4 <fwp_tape_reserve>
    56d8:	a9420261 	ldp	x1, x0, [x19, #32]
    56dc:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    56e0:	f9401a63 	ldr	x3, [x19, #48]
    56e4:	b8367835 	str	w21, [x1, x22, lsl #2]
    56e8:	f9401e61 	ldr	x1, [x19, #56]
    56ec:	12800002 	mov	w2, #0xffffffff            	// #-1
    56f0:	fc367860 	str	d0, [x3, x22, lsl #3]
    56f4:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56f8:	b8367802 	str	w2, [x0, x22, lsl #2]
    56fc:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5700:	910006e0 	add	x0, x23, #0x1
    5704:	aa1702b7 	orr	x23, x21, x23
    5708:	fc367820 	str	d0, [x1, x22, lsl #3]
    570c:	f9000a60 	str	x0, [x19, #16]
    5710:	9360fe99 	asr	x25, x20, #32
    5714:	1e68090a 	fmul	d10, d8, d8
    5718:	eb1b033f 	cmp	x25, x27
    571c:	540000c0 	b.eq	5734 <w120+0x210>  // b.none
    5720:	aa1903e0 	mov	x0, x25
    5724:	97fffc9f 	bl	49a0 <fwp_tape_of>
    5728:	aa0003f3 	mov	x19, x0
    572c:	f9403000 	ldr	x0, [x0, #96]
    5730:	b5fff240 	cbnz	x0, 5578 <w120+0x54>
    5734:	f9400a75 	ldr	x21, [x19, #16]
    5738:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    573c:	eb0002bf 	cmp	x21, x0
    5740:	54000d0c 	b.gt	58e0 <w120+0x3bc>
    5744:	eb3442bf 	cmp	x21, w20, uxtw
    5748:	54000c6d 	b.le	58d4 <w120+0x3b0>
    574c:	f9400678 	ldr	x24, [x19, #8]
    5750:	aa1303e0 	mov	x0, x19
    5754:	92607e96 	and	x22, x20, #0xffffffff00000000
    5758:	cb1802b8 	sub	x24, x21, x24
    575c:	aa1502d6 	orr	x22, x22, x21
    5760:	91000701 	add	x1, x24, #0x1
    5764:	97fffe90 	bl	51a4 <fwp_tape_reserve>
    5768:	a9420261 	ldp	x1, x0, [x19, #32]
    576c:	f9401a62 	ldr	x2, [x19, #48]
    5770:	b8387834 	str	w20, [x1, x24, lsl #2]
    5774:	f9401e61 	ldr	x1, [x19, #56]
    5778:	fc387848 	str	d8, [x2, x24, lsl #3]
    577c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5780:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5784:	9e670000 	fmov	d0, x0
    5788:	910006b4 	add	x20, x21, #0x1
    578c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5790:	9360fed8 	asr	x24, x22, #32
    5794:	f9000a74 	str	x20, [x19, #16]
    5798:	1e60094a 	fmul	d10, d10, d0
    579c:	eb19031f 	cmp	x24, x25
    57a0:	540000e0 	b.eq	57bc <w120+0x298>  // b.none
    57a4:	aa1803e0 	mov	x0, x24
    57a8:	97fffc7e 	bl	49a0 <fwp_tape_of>
    57ac:	aa0003f3 	mov	x19, x0
    57b0:	f9403000 	ldr	x0, [x0, #96]
    57b4:	b5ffee20 	cbnz	x0, 5578 <w120+0x54>
    57b8:	f9400a74 	ldr	x20, [x19, #16]
    57bc:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57c0:	eb00029f 	cmp	x20, x0
    57c4:	540008ec 	b.gt	58e0 <w120+0x3bc>
    57c8:	eb36429f 	cmp	x20, w22, uxtw
    57cc:	5400084d 	b.le	58d4 <w120+0x3b0>
    57d0:	f9400675 	ldr	x21, [x19, #8]
    57d4:	aa1303e0 	mov	x0, x19
    57d8:	cb150295 	sub	x21, x20, x21
    57dc:	910006a1 	add	x1, x21, #0x1
    57e0:	97fffe71 	bl	51a4 <fwp_tape_reserve>
    57e4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    57e8:	9e670000 	fmov	d0, x0
    57ec:	a9420261 	ldp	x1, x0, [x19, #32]
    57f0:	1e690928 	fmul	d8, d9, d9
    57f4:	f9401a62 	ldr	x2, [x19, #48]
    57f8:	b8357836 	str	w22, [x1, x21, lsl #2]
    57fc:	f9401e61 	ldr	x1, [x19, #56]
    5800:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5804:	fc357840 	str	d0, [x2, x21, lsl #3]
    5808:	12800002 	mov	w2, #0xffffffff            	// #-1
    580c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5810:	91000680 	add	x0, x20, #0x1
    5814:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5818:	aa1402d6 	orr	x22, x22, x20
    581c:	f9000a60 	str	x0, [x19, #16]
    5820:	b10006ff 	cmn	x23, #0x1
    5824:	540009e0 	b.eq	5960 <w120+0x43c>  // b.none
    5828:	9360fee0 	asr	x0, x23, #32
    582c:	eb18001f 	cmp	x0, x24
    5830:	540000a0 	b.eq	5844 <w120+0x320>  // b.none
    5834:	97fffc5b 	bl	49a0 <fwp_tape_of>
    5838:	aa0003f3 	mov	x19, x0
    583c:	f9403000 	ldr	x0, [x0, #96]
    5840:	b5ffe9c0 	cbnz	x0, 5578 <w120+0x54>
    5844:	f9400a74 	ldr	x20, [x19, #16]
    5848:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    584c:	eb00029f 	cmp	x20, x0
    5850:	5400048c 	b.gt	58e0 <w120+0x3bc>
    5854:	eb37429f 	cmp	x20, w23, uxtw
    5858:	540003ed 	b.le	58d4 <w120+0x3b0>
    585c:	f9400675 	ldr	x21, [x19, #8]
    5860:	aa1303e0 	mov	x0, x19
    5864:	cb150295 	sub	x21, x20, x21
    5868:	910006a1 	add	x1, x21, #0x1
    586c:	97fffe4e 	bl	51a4 <fwp_tape_reserve>
    5870:	a9420a61 	ldp	x1, x2, [x19, #32]
    5874:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5878:	f9401a63 	ldr	x3, [x19, #48]
    587c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5880:	f9401e61 	ldr	x1, [x19, #56]
    5884:	aa140000 	orr	x0, x0, x20
    5888:	fc357869 	str	d9, [x3, x21, lsl #3]
    588c:	91000694 	add	x20, x20, #0x1
    5890:	b8357857 	str	w23, [x2, x21, lsl #2]
    5894:	fc357829 	str	d9, [x1, x21, lsl #3]
    5898:	f9000a74 	str	x20, [x19, #16]
    589c:	1e6a2908 	fadd	d8, d8, d10
    58a0:	aa1603e1 	mov	x1, x22
    58a4:	97fffecf 	bl	53e0 <f141.constprop.0>
    58a8:	aa0003e1 	mov	x1, x0
    58ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    58b0:	9e660100 	fmov	x0, d8
    58b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    58bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    58c0:	f9402bfb 	ldr	x27, [sp, #80]
    58c4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    58c8:	6d472fea 	ldp	d10, d11, [sp, #112]
    58cc:	a8c87bfd 	ldp	x29, x30, [sp], #128
    58d0:	d65f03c0 	ret
    58d4:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    58d8:	912f8000 	add	x0, x0, #0xbe0
    58dc:	97fffa2d 	bl	4190 <fwp_trap>
    58e0:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    58e4:	912d2000 	add	x0, x0, #0xb48
    58e8:	97fffa2a 	bl	4190 <fwp_trap>
    58ec:	1e693828 	fsub	d8, d1, d9
    58f0:	b6f801c1 	tbz	x1, #63, 5928 <w120+0x404>
    58f4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    58f8:	1e68090a 	fmul	d10, d8, d8
    58fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5900:	9e670000 	fmov	d0, x0
    5904:	1e6b3828 	fsub	d8, d1, d11
    5908:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    590c:	aa1603e0 	mov	x0, x22
    5910:	1e60094a 	fmul	d10, d10, d0
    5914:	1e680908 	fmul	d8, d8, d8
    5918:	17ffffe1 	b	589c <w120+0x378>
    591c:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    5920:	912da000 	add	x0, x0, #0xb68
    5924:	97fffa1b 	bl	4190 <fwp_trap>
    5928:	2f00e40a 	movi	d10, #0x0
    592c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5930:	9360fc3a 	asr	x26, x1, #32
    5934:	aa0103f4 	mov	x20, x1
    5938:	aa1a03e0 	mov	x0, x26
    593c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5940:	97fffc18 	bl	49a0 <fwp_tape_of>
    5944:	aa0003f3 	mov	x19, x0
    5948:	f9403000 	ldr	x0, [x0, #96]
    594c:	b5ffe160 	cbnz	x0, 5578 <w120+0x54>
    5950:	17ffff30 	b	5610 <w120+0xec>
    5954:	aa1a03fb 	mov	x27, x26
    5958:	aa0003f7 	mov	x23, x0
    595c:	17ffff6d 	b	5710 <w120+0x1ec>
    5960:	aa1703e0 	mov	x0, x23
    5964:	17ffffce 	b	589c <w120+0x378>
    5968:	d503201f 	nop
    596c:	d503201f 	nop

0000000000005970 <fwp_rc_share>:
    5970:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5974:	91170042 	add	x2, x2, #0x5c0
    5978:	f949d843 	ldr	x3, [x2, #5040]
    597c:	f949ec41 	ldr	x1, [x2, #5080]
    5980:	cb030000 	sub	x0, x0, x3
    5984:	eb01401f 	cmp	x0, x1, lsl #16
    5988:	540003a2 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    598c:	d350fc01 	lsr	x1, x0, #16
    5990:	f949fc44 	ldr	x4, [x2, #5112]
    5994:	8b010821 	add	x1, x1, x1, lsl #2
    5998:	d37df021 	lsl	x1, x1, #3
    599c:	8b010083 	add	x3, x4, x1
    59a0:	f9401062 	ldr	x2, [x3, #32]
    59a4:	b40002c2 	cbz	x2, 59fc <fwp_rc_share+0x8c>
    59a8:	38616881 	ldrb	w1, [x4, x1]
    59ac:	7100083f 	cmp	w1, #0x2
    59b0:	54000220 	b.eq	59f4 <fwp_rc_share+0x84>  // b.none
    59b4:	7100043f 	cmp	w1, #0x1
    59b8:	54000221 	b.ne	59fc <fwp_rc_share+0x8c>  // b.any
    59bc:	29430464 	ldp	w4, w1, [x3, #24]
    59c0:	92403c00 	and	x0, x0, #0xffff
    59c4:	9b047c00 	mul	x0, x0, x4
    59c8:	d360fc00 	lsr	x0, x0, #32
    59cc:	eb01001f 	cmp	x0, x1
    59d0:	54000162 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    59d4:	8b000042 	add	x2, x2, x0
    59d8:	39400040 	ldrb	w0, [x2]
    59dc:	34000100 	cbz	w0, 59fc <fwp_rc_share+0x8c>
    59e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    59e4:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    59e8:	91300000 	add	x0, x0, #0xc00
    59ec:	910003fd 	mov	x29, sp
    59f0:	97fff9e8 	bl	4190 <fwp_trap>
    59f4:	72003c1f 	tst	w0, #0xffff
    59f8:	54ffff00 	b.eq	59d8 <fwp_rc_share+0x68>  // b.none
    59fc:	d65f03c0 	ret

0000000000005a00 <fwp_rc_free_arr>:
    5a00:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5a04:	91170063 	add	x3, x3, #0x5c0
    5a08:	f949d861 	ldr	x1, [x3, #5040]
    5a0c:	f949ec62 	ldr	x2, [x3, #5080]
    5a10:	cb010001 	sub	x1, x0, x1
    5a14:	eb02403f 	cmp	x1, x2, lsl #16
    5a18:	54000342 	b.cs	5a80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a1c:	d350fc22 	lsr	x2, x1, #16
    5a20:	f949fc65 	ldr	x5, [x3, #5112]
    5a24:	8b020842 	add	x2, x2, x2, lsl #2
    5a28:	d37df042 	lsl	x2, x2, #3
    5a2c:	8b0200a4 	add	x4, x5, x2
    5a30:	f9401083 	ldr	x3, [x4, #32]
    5a34:	b4000263 	cbz	x3, 5a80 <fwp_rc_free_arr+0x80>
    5a38:	386268a2 	ldrb	w2, [x5, x2]
    5a3c:	7100085f 	cmp	w2, #0x2
    5a40:	540001c0 	b.eq	5a78 <fwp_rc_free_arr+0x78>  // b.none
    5a44:	7100045f 	cmp	w2, #0x1
    5a48:	540001c1 	b.ne	5a80 <fwp_rc_free_arr+0x80>  // b.any
    5a4c:	29430885 	ldp	w5, w2, [x4, #24]
    5a50:	92403c21 	and	x1, x1, #0xffff
    5a54:	9b057c21 	mul	x1, x1, x5
    5a58:	d360fc21 	lsr	x1, x1, #32
    5a5c:	eb02003f 	cmp	x1, x2
    5a60:	54000102 	b.cs	5a80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a64:	8b010063 	add	x3, x3, x1
    5a68:	39400061 	ldrb	w1, [x3]
    5a6c:	7100043f 	cmp	w1, #0x1
    5a70:	54000081 	b.ne	5a80 <fwp_rc_free_arr+0x80>  // b.any
    5a74:	17fffa83 	b	4480 <fwp_mem_free>
    5a78:	72003c3f 	tst	w1, #0xffff
    5a7c:	54ffff60 	b.eq	5a68 <fwp_rc_free_arr+0x68>  // b.none
    5a80:	d65f03c0 	ret

0000000000005a84 <fwp_rc_dup>:
    5a84:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5a88:	91170042 	add	x2, x2, #0x5c0
    5a8c:	f949d841 	ldr	x1, [x2, #5040]
    5a90:	f949ec43 	ldr	x3, [x2, #5080]
    5a94:	cb010001 	sub	x1, x0, x1
    5a98:	eb03403f 	cmp	x1, x3, lsl #16
    5a9c:	54000342 	b.cs	5b04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5aa0:	d350fc20 	lsr	x0, x1, #16
    5aa4:	f949fc44 	ldr	x4, [x2, #5112]
    5aa8:	8b000800 	add	x0, x0, x0, lsl #2
    5aac:	d37df002 	lsl	x2, x0, #3
    5ab0:	8b020083 	add	x3, x4, x2
    5ab4:	f9401060 	ldr	x0, [x3, #32]
    5ab8:	b4000260 	cbz	x0, 5b04 <fwp_rc_dup+0x80>
    5abc:	38626882 	ldrb	w2, [x4, x2]
    5ac0:	7100085f 	cmp	w2, #0x2
    5ac4:	54000220 	b.eq	5b08 <fwp_rc_dup+0x84>  // b.none
    5ac8:	7100045f 	cmp	w2, #0x1
    5acc:	540001c1 	b.ne	5b04 <fwp_rc_dup+0x80>  // b.any
    5ad0:	29430864 	ldp	w4, w2, [x3, #24]
    5ad4:	92403c21 	and	x1, x1, #0xffff
    5ad8:	9b047c21 	mul	x1, x1, x4
    5adc:	d360fc21 	lsr	x1, x1, #32
    5ae0:	eb02003f 	cmp	x1, x2
    5ae4:	54000102 	b.cs	5b04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ae8:	8b010000 	add	x0, x0, x1
    5aec:	39400001 	ldrb	w1, [x0]
    5af0:	340000a1 	cbz	w1, 5b04 <fwp_rc_dup+0x80>
    5af4:	7103f43f 	cmp	w1, #0xfd
    5af8:	540000e8 	b.hi	5b14 <fwp_rc_dup+0x90>  // b.pmore
    5afc:	11000421 	add	w1, w1, #0x1
    5b00:	39000001 	strb	w1, [x0]
    5b04:	d65f03c0 	ret
    5b08:	72003c3f 	tst	w1, #0xffff
    5b0c:	54ffff00 	b.eq	5aec <fwp_rc_dup+0x68>  // b.none
    5b10:	d65f03c0 	ret
    5b14:	17fffad4 	b	4664 <fwp_rc_wide_dup>
    5b18:	d503201f 	nop
    5b1c:	d503201f 	nop

0000000000005b20 <fwp_owned_entry173>:
    5b20:	d10103ff 	sub	sp, sp, #0x40
    5b24:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5b28:	f947f442 	ldr	x2, [x2, #4072]
    5b2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b30:	910083fd 	add	x29, sp, #0x20
    5b34:	a90353f3 	stp	x19, x20, [sp, #48]
    5b38:	f9400043 	ldr	x3, [x2]
    5b3c:	f9000fe3 	str	x3, [sp, #24]
    5b40:	d2800003 	mov	x3, #0x0                   	// #0
    5b44:	a9400c01 	ldp	x1, x3, [x0]
    5b48:	f9400802 	ldr	x2, [x0, #16]
    5b4c:	ab020022 	adds	x2, x1, x2
    5b50:	540006e6 	b.vs	5c2c <fwp_owned_entry173+0x10c>
    5b54:	910023e1 	add	x1, sp, #0x8
    5b58:	52800000 	mov	w0, #0x0                   	// #0
    5b5c:	a9008be3 	stp	x3, x2, [sp, #8]
    5b60:	97fffd49 	bl	5084 <fwp_data.part.0.constprop.0>
    5b64:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5b68:	91170063 	add	x3, x3, #0x5c0
    5b6c:	aa0003f3 	mov	x19, x0
    5b70:	f949d861 	ldr	x1, [x3, #5040]
    5b74:	f949ec60 	ldr	x0, [x3, #5080]
    5b78:	cb010261 	sub	x1, x19, x1
    5b7c:	eb00403f 	cmp	x1, x0, lsl #16
    5b80:	54000322 	b.cs	5be4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b84:	d350fc22 	lsr	x2, x1, #16
    5b88:	f949fc63 	ldr	x3, [x3, #5112]
    5b8c:	8b020842 	add	x2, x2, x2, lsl #2
    5b90:	d37df042 	lsl	x2, x2, #3
    5b94:	8b020060 	add	x0, x3, x2
    5b98:	f9401014 	ldr	x20, [x0, #32]
    5b9c:	b4000254 	cbz	x20, 5be4 <fwp_owned_entry173+0xc4>
    5ba0:	38626862 	ldrb	w2, [x3, x2]
    5ba4:	7100085f 	cmp	w2, #0x2
    5ba8:	54000360 	b.eq	5c14 <fwp_owned_entry173+0xf4>  // b.none
    5bac:	7100045f 	cmp	w2, #0x1
    5bb0:	540001a1 	b.ne	5be4 <fwp_owned_entry173+0xc4>  // b.any
    5bb4:	29430002 	ldp	w2, w0, [x0, #24]
    5bb8:	92403c21 	and	x1, x1, #0xffff
    5bbc:	9b027c21 	mul	x1, x1, x2
    5bc0:	d360fc21 	lsr	x1, x1, #32
    5bc4:	eb00003f 	cmp	x1, x0
    5bc8:	540000e2 	b.cs	5be4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5bcc:	8b010294 	add	x20, x20, x1
    5bd0:	39400280 	ldrb	w0, [x20]
    5bd4:	7103fc1f 	cmp	w0, #0xff
    5bd8:	54000240 	b.eq	5c20 <fwp_owned_entry173+0x100>  // b.none
    5bdc:	52800020 	mov	w0, #0x1                   	// #1
    5be0:	39000280 	strb	w0, [x20]
    5be4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5be8:	f947f400 	ldr	x0, [x0, #4072]
    5bec:	f9400fe2 	ldr	x2, [sp, #24]
    5bf0:	f9400001 	ldr	x1, [x0]
    5bf4:	eb010042 	subs	x2, x2, x1
    5bf8:	d2800001 	mov	x1, #0x0                   	// #0
    5bfc:	540001a1 	b.ne	5c30 <fwp_owned_entry173+0x110>  // b.any
    5c00:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c04:	aa1303e0 	mov	x0, x19
    5c08:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c0c:	910103ff 	add	sp, sp, #0x40
    5c10:	d65f03c0 	ret
    5c14:	72003c3f 	tst	w1, #0xffff
    5c18:	54fffe61 	b.ne	5be4 <fwp_owned_entry173+0xc4>  // b.any
    5c1c:	17ffffed 	b	5bd0 <fwp_owned_entry173+0xb0>
    5c20:	aa1403e0 	mov	x0, x20
    5c24:	97fff97b 	bl	4210 <fwp_rc_forget_slot.part.0>
    5c28:	17ffffed 	b	5bdc <fwp_owned_entry173+0xbc>
    5c2c:	97fff3b5 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5c30:	97fff338 	bl	2910 <__stack_chk_fail@plt>

0000000000005c34 <e173>:
    5c34:	d10103ff 	sub	sp, sp, #0x40
    5c38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5c3c:	f947f442 	ldr	x2, [x2, #4072]
    5c40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c44:	910083fd 	add	x29, sp, #0x20
    5c48:	a90353f3 	stp	x19, x20, [sp, #48]
    5c4c:	f9400043 	ldr	x3, [x2]
    5c50:	f9000fe3 	str	x3, [sp, #24]
    5c54:	d2800003 	mov	x3, #0x0                   	// #0
    5c58:	a9400c01 	ldp	x1, x3, [x0]
    5c5c:	f9400802 	ldr	x2, [x0, #16]
    5c60:	ab020022 	adds	x2, x1, x2
    5c64:	54000726 	b.vs	5d48 <e173+0x114>
    5c68:	910023e1 	add	x1, sp, #0x8
    5c6c:	52800000 	mov	w0, #0x0                   	// #0
    5c70:	a9008be3 	stp	x3, x2, [sp, #8]
    5c74:	97fffd04 	bl	5084 <fwp_data.part.0.constprop.0>
    5c78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5c7c:	91170063 	add	x3, x3, #0x5c0
    5c80:	aa0003f3 	mov	x19, x0
    5c84:	f949d861 	ldr	x1, [x3, #5040]
    5c88:	f949ec60 	ldr	x0, [x3, #5080]
    5c8c:	cb010261 	sub	x1, x19, x1
    5c90:	eb00403f 	cmp	x1, x0, lsl #16
    5c94:	54000322 	b.cs	5cf8 <e173+0xc4>  // b.hs, b.nlast
    5c98:	d350fc22 	lsr	x2, x1, #16
    5c9c:	f949fc63 	ldr	x3, [x3, #5112]
    5ca0:	8b020842 	add	x2, x2, x2, lsl #2
    5ca4:	d37df042 	lsl	x2, x2, #3
    5ca8:	8b020060 	add	x0, x3, x2
    5cac:	f9401014 	ldr	x20, [x0, #32]
    5cb0:	b4000254 	cbz	x20, 5cf8 <e173+0xc4>
    5cb4:	38626862 	ldrb	w2, [x3, x2]
    5cb8:	7100085f 	cmp	w2, #0x2
    5cbc:	540003a0 	b.eq	5d30 <e173+0xfc>  // b.none
    5cc0:	7100045f 	cmp	w2, #0x1
    5cc4:	540001a1 	b.ne	5cf8 <e173+0xc4>  // b.any
    5cc8:	29430002 	ldp	w2, w0, [x0, #24]
    5ccc:	92403c21 	and	x1, x1, #0xffff
    5cd0:	9b027c21 	mul	x1, x1, x2
    5cd4:	d360fc21 	lsr	x1, x1, #32
    5cd8:	eb00003f 	cmp	x1, x0
    5cdc:	540000e2 	b.cs	5cf8 <e173+0xc4>  // b.hs, b.nlast
    5ce0:	8b010294 	add	x20, x20, x1
    5ce4:	39400280 	ldrb	w0, [x20]
    5ce8:	7103fc1f 	cmp	w0, #0xff
    5cec:	54000280 	b.eq	5d3c <e173+0x108>  // b.none
    5cf0:	52800020 	mov	w0, #0x1                   	// #1
    5cf4:	39000280 	strb	w0, [x20]
    5cf8:	aa1303e0 	mov	x0, x19
    5cfc:	97ffff1d 	bl	5970 <fwp_rc_share>
    5d00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d04:	f947f400 	ldr	x0, [x0, #4072]
    5d08:	f9400fe2 	ldr	x2, [sp, #24]
    5d0c:	f9400001 	ldr	x1, [x0]
    5d10:	eb010042 	subs	x2, x2, x1
    5d14:	d2800001 	mov	x1, #0x0                   	// #0
    5d18:	540001a1 	b.ne	5d4c <e173+0x118>  // b.any
    5d1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d20:	aa1303e0 	mov	x0, x19
    5d24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d28:	910103ff 	add	sp, sp, #0x40
    5d2c:	d65f03c0 	ret
    5d30:	72003c3f 	tst	w1, #0xffff
    5d34:	54fffe21 	b.ne	5cf8 <e173+0xc4>  // b.any
    5d38:	17ffffeb 	b	5ce4 <e173+0xb0>
    5d3c:	aa1403e0 	mov	x0, x20
    5d40:	97fff934 	bl	4210 <fwp_rc_forget_slot.part.0>
    5d44:	17ffffeb 	b	5cf0 <e173+0xbc>
    5d48:	97fff36e 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5d4c:	97fff2f1 	bl	2910 <__stack_chk_fail@plt>

0000000000005d50 <fwp_drop1>:
    5d50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d54:	910003fd 	mov	x29, sp
    5d58:	a90153f3 	stp	x19, x20, [sp, #16]
    5d5c:	f90013f5 	str	x21, [sp, #32]
    5d60:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5d64:	911702b4 	add	x20, x21, #0x5c0
    5d68:	f949da81 	ldr	x1, [x20, #5040]
    5d6c:	f949ee82 	ldr	x2, [x20, #5080]
    5d70:	cb010001 	sub	x1, x0, x1
    5d74:	eb02403f 	cmp	x1, x2, lsl #16
    5d78:	54000382 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d7c:	d350fc22 	lsr	x2, x1, #16
    5d80:	f949fe84 	ldr	x4, [x20, #5112]
    5d84:	8b020842 	add	x2, x2, x2, lsl #2
    5d88:	d37df042 	lsl	x2, x2, #3
    5d8c:	8b020083 	add	x3, x4, x2
    5d90:	f9401073 	ldr	x19, [x3, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_drop1+0x98>
    5d98:	38626882 	ldrb	w2, [x4, x2]
    5d9c:	7100085f 	cmp	w2, #0x2
    5da0:	540002c0 	b.eq	5df8 <fwp_drop1+0xa8>  // b.none
    5da4:	7100045f 	cmp	w2, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5dac:	29430864 	ldp	w4, w2, [x3, #24]
    5db0:	92403c21 	and	x1, x1, #0xffff
    5db4:	9b047c21 	mul	x1, x1, x4
    5db8:	d360fc21 	lsr	x1, x1, #32
    5dbc:	eb02003f 	cmp	x1, x2
    5dc0:	54000142 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dc4:	8b010273 	add	x19, x19, x1
    5dc8:	39400261 	ldrb	w1, [x19]
    5dcc:	340000e1 	cbz	w1, 5de8 <fwp_drop1+0x98>
    5dd0:	7100043f 	cmp	w1, #0x1
    5dd4:	540001e0 	b.eq	5e10 <fwp_drop1+0xc0>  // b.none
    5dd8:	7103fc3f 	cmp	w1, #0xff
    5ddc:	540002e0 	b.eq	5e38 <fwp_drop1+0xe8>  // b.none
    5de0:	51000421 	sub	w1, w1, #0x1
    5de4:	39000261 	strb	w1, [x19]
    5de8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dec:	f94013f5 	ldr	x21, [sp, #32]
    5df0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5df4:	d65f03c0 	ret
    5df8:	72003c3f 	tst	w1, #0xffff
    5dfc:	54fffe60 	b.eq	5dc8 <fwp_drop1+0x78>  // b.none
    5e00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e04:	f94013f5 	ldr	x21, [sp, #32]
    5e08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e0c:	d65f03c0 	ret
    5e10:	f9400813 	ldr	x19, [x0, #16]
    5e14:	97fffefb 	bl	5a00 <fwp_rc_free_arr>
    5e18:	911702a0 	add	x0, x21, #0x5c0
    5e1c:	f949d801 	ldr	x1, [x0, #5040]
    5e20:	f949ec00 	ldr	x0, [x0, #5080]
    5e24:	cb010261 	sub	x1, x19, x1
    5e28:	eb00403f 	cmp	x1, x0, lsl #16
    5e2c:	54fffde2 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e30:	aa1303e0 	mov	x0, x19
    5e34:	17ffffd2 	b	5d7c <fwp_drop1+0x2c>
    5e38:	ca534660 	eor	x0, x19, x19, lsr #17
    5e3c:	911702b5 	add	x21, x21, #0x5c0
    5e40:	ca402400 	eor	x0, x0, x0, lsr #9
    5e44:	92401c00 	and	x0, x0, #0xff
    5e48:	910a2402 	add	x2, x0, #0x289
    5e4c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e50:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e54:	f94a2400 	ldr	x0, [x0, #5192]
    5e58:	b50000a0 	cbnz	x0, 5e6c <fwp_drop1+0x11c>
    5e5c:	14000013 	b	5ea8 <fwp_drop1+0x158>
    5e60:	91004002 	add	x2, x0, #0x10
    5e64:	f9400800 	ldr	x0, [x0, #16]
    5e68:	b4000200 	cbz	x0, 5ea8 <fwp_drop1+0x158>
    5e6c:	f9400001 	ldr	x1, [x0]
    5e70:	eb13003f 	cmp	x1, x19
    5e74:	54ffff61 	b.ne	5e60 <fwp_drop1+0x110>  // b.any
    5e78:	f9400041 	ldr	x1, [x2]
    5e7c:	f9400420 	ldr	x0, [x1, #8]
    5e80:	d1000400 	sub	x0, x0, #0x1
    5e84:	f9000420 	str	x0, [x1, #8]
    5e88:	f103f81f 	cmp	x0, #0xfe
    5e8c:	54fffae1 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5e90:	39400260 	ldrb	w0, [x19]
    5e94:	7103fc1f 	cmp	w0, #0xff
    5e98:	540000e0 	b.eq	5eb4 <fwp_drop1+0x164>  // b.none
    5e9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ea0:	39000260 	strb	w0, [x19]
    5ea4:	17ffffd1 	b	5de8 <fwp_drop1+0x98>
    5ea8:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    5eac:	91266000 	add	x0, x0, #0x998
    5eb0:	97fff8b8 	bl	4190 <fwp_trap>
    5eb4:	aa1303e0 	mov	x0, x19
    5eb8:	97fff8d6 	bl	4210 <fwp_rc_forget_slot.part.0>
    5ebc:	17fffff8 	b	5e9c <fwp_drop1+0x14c>

0000000000005ec0 <fwp_drop0>:
    5ec0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ec4:	910003fd 	mov	x29, sp
    5ec8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ecc:	f90013f5 	str	x21, [sp, #32]
    5ed0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5ed4:	911702b4 	add	x20, x21, #0x5c0
    5ed8:	f949da81 	ldr	x1, [x20, #5040]
    5edc:	f949ee82 	ldr	x2, [x20, #5080]
    5ee0:	cb010001 	sub	x1, x0, x1
    5ee4:	eb02403f 	cmp	x1, x2, lsl #16
    5ee8:	54000382 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5eec:	d350fc22 	lsr	x2, x1, #16
    5ef0:	f949fe84 	ldr	x4, [x20, #5112]
    5ef4:	8b020842 	add	x2, x2, x2, lsl #2
    5ef8:	d37df042 	lsl	x2, x2, #3
    5efc:	8b020083 	add	x3, x4, x2
    5f00:	f9401073 	ldr	x19, [x3, #32]
    5f04:	b40002b3 	cbz	x19, 5f58 <fwp_drop0+0x98>
    5f08:	38626882 	ldrb	w2, [x4, x2]
    5f0c:	7100085f 	cmp	w2, #0x2
    5f10:	540002c0 	b.eq	5f68 <fwp_drop0+0xa8>  // b.none
    5f14:	7100045f 	cmp	w2, #0x1
    5f18:	54000201 	b.ne	5f58 <fwp_drop0+0x98>  // b.any
    5f1c:	29430864 	ldp	w4, w2, [x3, #24]
    5f20:	92403c21 	and	x1, x1, #0xffff
    5f24:	9b047c21 	mul	x1, x1, x4
    5f28:	d360fc21 	lsr	x1, x1, #32
    5f2c:	eb02003f 	cmp	x1, x2
    5f30:	54000142 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f34:	8b010273 	add	x19, x19, x1
    5f38:	39400261 	ldrb	w1, [x19]
    5f3c:	340000e1 	cbz	w1, 5f58 <fwp_drop0+0x98>
    5f40:	7100043f 	cmp	w1, #0x1
    5f44:	540001e0 	b.eq	5f80 <fwp_drop0+0xc0>  // b.none
    5f48:	7103fc3f 	cmp	w1, #0xff
    5f4c:	540002e0 	b.eq	5fa8 <fwp_drop0+0xe8>  // b.none
    5f50:	51000421 	sub	w1, w1, #0x1
    5f54:	39000261 	strb	w1, [x19]
    5f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f5c:	f94013f5 	ldr	x21, [sp, #32]
    5f60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f64:	d65f03c0 	ret
    5f68:	72003c3f 	tst	w1, #0xffff
    5f6c:	54fffe60 	b.eq	5f38 <fwp_drop0+0x78>  // b.none
    5f70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f74:	f94013f5 	ldr	x21, [sp, #32]
    5f78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f7c:	d65f03c0 	ret
    5f80:	f9400813 	ldr	x19, [x0, #16]
    5f84:	97fffe9f 	bl	5a00 <fwp_rc_free_arr>
    5f88:	911702a0 	add	x0, x21, #0x5c0
    5f8c:	f949d801 	ldr	x1, [x0, #5040]
    5f90:	f949ec00 	ldr	x0, [x0, #5080]
    5f94:	cb010261 	sub	x1, x19, x1
    5f98:	eb00403f 	cmp	x1, x0, lsl #16
    5f9c:	54fffde2 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fa0:	aa1303e0 	mov	x0, x19
    5fa4:	17ffffd2 	b	5eec <fwp_drop0+0x2c>
    5fa8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fac:	911702b5 	add	x21, x21, #0x5c0
    5fb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fb4:	92401c00 	and	x0, x0, #0xff
    5fb8:	910a2402 	add	x2, x0, #0x289
    5fbc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5fc0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5fc4:	f94a2400 	ldr	x0, [x0, #5192]
    5fc8:	b50000a0 	cbnz	x0, 5fdc <fwp_drop0+0x11c>
    5fcc:	14000013 	b	6018 <fwp_drop0+0x158>
    5fd0:	91004002 	add	x2, x0, #0x10
    5fd4:	f9400800 	ldr	x0, [x0, #16]
    5fd8:	b4000200 	cbz	x0, 6018 <fwp_drop0+0x158>
    5fdc:	f9400001 	ldr	x1, [x0]
    5fe0:	eb13003f 	cmp	x1, x19
    5fe4:	54ffff61 	b.ne	5fd0 <fwp_drop0+0x110>  // b.any
    5fe8:	f9400041 	ldr	x1, [x2]
    5fec:	f9400420 	ldr	x0, [x1, #8]
    5ff0:	d1000400 	sub	x0, x0, #0x1
    5ff4:	f9000420 	str	x0, [x1, #8]
    5ff8:	f103f81f 	cmp	x0, #0xfe
    5ffc:	54fffae1 	b.ne	5f58 <fwp_drop0+0x98>  // b.any
    6000:	39400260 	ldrb	w0, [x19]
    6004:	7103fc1f 	cmp	w0, #0xff
    6008:	540000e0 	b.eq	6024 <fwp_drop0+0x164>  // b.none
    600c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6010:	39000260 	strb	w0, [x19]
    6014:	17ffffd1 	b	5f58 <fwp_drop0+0x98>
    6018:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    601c:	91266000 	add	x0, x0, #0x998
    6020:	97fff85c 	bl	4190 <fwp_trap>
    6024:	aa1303e0 	mov	x0, x19
    6028:	97fff87a 	bl	4210 <fwp_rc_forget_slot.part.0>
    602c:	17fffff8 	b	600c <fwp_drop0+0x14c>

0000000000006030 <fwp_closure_drop>:
    6030:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc20>
    6034:	911700a4 	add	x4, x5, #0x5c0
    6038:	aa0003e1 	mov	x1, x0
    603c:	f949d882 	ldr	x2, [x4, #5040]
    6040:	f949ec80 	ldr	x0, [x4, #5080]
    6044:	cb020022 	sub	x2, x1, x2
    6048:	eb00405f 	cmp	x2, x0, lsl #16
    604c:	54000662 	b.cs	6118 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6050:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6054:	d350fc43 	lsr	x3, x2, #16
    6058:	910003fd 	mov	x29, sp
    605c:	8b030863 	add	x3, x3, x3, lsl #2
    6060:	f949fc84 	ldr	x4, [x4, #5112]
    6064:	d37df063 	lsl	x3, x3, #3
    6068:	f9000bf3 	str	x19, [sp, #16]
    606c:	8b030080 	add	x0, x4, x3
    6070:	f9401013 	ldr	x19, [x0, #32]
    6074:	b40002b3 	cbz	x19, 60c8 <fwp_closure_drop+0x98>
    6078:	38636883 	ldrb	w3, [x4, x3]
    607c:	7100087f 	cmp	w3, #0x2
    6080:	54000420 	b.eq	6104 <fwp_closure_drop+0xd4>  // b.none
    6084:	7100047f 	cmp	w3, #0x1
    6088:	54000201 	b.ne	60c8 <fwp_closure_drop+0x98>  // b.any
    608c:	29430003 	ldp	w3, w0, [x0, #24]
    6090:	92403c42 	and	x2, x2, #0xffff
    6094:	9b037c42 	mul	x2, x2, x3
    6098:	d360fc42 	lsr	x2, x2, #32
    609c:	eb00005f 	cmp	x2, x0
    60a0:	54000142 	b.cs	60c8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    60a4:	8b020273 	add	x19, x19, x2
    60a8:	39400260 	ldrb	w0, [x19]
    60ac:	340000e0 	cbz	w0, 60c8 <fwp_closure_drop+0x98>
    60b0:	7100041f 	cmp	w0, #0x1
    60b4:	54000100 	b.eq	60d4 <fwp_closure_drop+0xa4>  // b.none
    60b8:	7103fc1f 	cmp	w0, #0xff
    60bc:	54000300 	b.eq	611c <fwp_closure_drop+0xec>  // b.none
    60c0:	51000400 	sub	w0, w0, #0x1
    60c4:	39000260 	strb	w0, [x19]
    60c8:	f9400bf3 	ldr	x19, [sp, #16]
    60cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60d0:	d65f03c0 	ret
    60d4:	d53bd040 	mrs	x0, tpidr_el0
    60d8:	91400000 	add	x0, x0, #0x0, lsl #12
    60dc:	91004000 	add	x0, x0, #0x10
    60e0:	f9400000 	ldr	x0, [x0]
    60e4:	b4000080 	cbz	x0, 60f4 <fwp_closure_drop+0xc4>
    60e8:	f9400bf3 	ldr	x19, [sp, #16]
    60ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60f0:	17fff9a4 	b	4780 <fwp_closure_drop_push>
    60f4:	f9400bf3 	ldr	x19, [sp, #16]
    60f8:	aa0103e0 	mov	x0, x1
    60fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6100:	17fff9e5 	b	4894 <fwp_closure_drop.part.0>
    6104:	72003c5f 	tst	w2, #0xffff
    6108:	54fffd00 	b.eq	60a8 <fwp_closure_drop+0x78>  // b.none
    610c:	f9400bf3 	ldr	x19, [sp, #16]
    6110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6114:	d65f03c0 	ret
    6118:	d65f03c0 	ret
    611c:	ca534660 	eor	x0, x19, x19, lsr #17
    6120:	911700a5 	add	x5, x5, #0x5c0
    6124:	ca402400 	eor	x0, x0, x0, lsr #9
    6128:	92401c00 	and	x0, x0, #0xff
    612c:	910a2402 	add	x2, x0, #0x289
    6130:	8b000ca0 	add	x0, x5, x0, lsl #3
    6134:	8b020ca2 	add	x2, x5, x2, lsl #3
    6138:	f94a2400 	ldr	x0, [x0, #5192]
    613c:	b50000a0 	cbnz	x0, 6150 <fwp_closure_drop+0x120>
    6140:	14000013 	b	618c <fwp_closure_drop+0x15c>
    6144:	91004002 	add	x2, x0, #0x10
    6148:	f9400800 	ldr	x0, [x0, #16]
    614c:	b4000200 	cbz	x0, 618c <fwp_closure_drop+0x15c>
    6150:	f9400001 	ldr	x1, [x0]
    6154:	eb13003f 	cmp	x1, x19
    6158:	54ffff61 	b.ne	6144 <fwp_closure_drop+0x114>  // b.any
    615c:	f9400041 	ldr	x1, [x2]
    6160:	f9400420 	ldr	x0, [x1, #8]
    6164:	d1000400 	sub	x0, x0, #0x1
    6168:	f9000420 	str	x0, [x1, #8]
    616c:	f103f81f 	cmp	x0, #0xfe
    6170:	54fffac1 	b.ne	60c8 <fwp_closure_drop+0x98>  // b.any
    6174:	39400260 	ldrb	w0, [x19]
    6178:	7103fc1f 	cmp	w0, #0xff
    617c:	540000e0 	b.eq	6198 <fwp_closure_drop+0x168>  // b.none
    6180:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6184:	39000260 	strb	w0, [x19]
    6188:	17ffffd0 	b	60c8 <fwp_closure_drop+0x98>
    618c:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    6190:	91266000 	add	x0, x0, #0x998
    6194:	97fff7ff 	bl	4190 <fwp_trap>
    6198:	aa1303e0 	mov	x0, x19
    619c:	97fff81d 	bl	4210 <fwp_rc_forget_slot.part.0>
    61a0:	17fffff8 	b	6180 <fwp_closure_drop+0x150>

00000000000061a4 <fwp_owned_tape_release>:
    61a4:	b4000920 	cbz	x0, 62c8 <fwp_owned_tape_release+0x124>
    61a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61ac:	910003fd 	mov	x29, sp
    61b0:	a90153f3 	stp	x19, x20, [sp, #16]
    61b4:	aa0003f3 	mov	x19, x0
    61b8:	f9400000 	ldr	x0, [x0]
    61bc:	b4000060 	cbz	x0, 61c8 <fwp_owned_tape_release+0x24>
    61c0:	f9400661 	ldr	x1, [x19, #8]
    61c4:	f9000401 	str	x1, [x0, #8]
    61c8:	f9400661 	ldr	x1, [x19, #8]
    61cc:	b4000041 	cbz	x1, 61d4 <fwp_owned_tape_release+0x30>
    61d0:	f9000020 	str	x0, [x1]
    61d4:	f9400a60 	ldr	x0, [x19, #16]
    61d8:	f9403401 	ldr	x1, [x0, #104]
    61dc:	b40005a1 	cbz	x1, 6290 <fwp_owned_tape_release+0xec>
    61e0:	a9450a60 	ldp	x0, x2, [x19, #80]
    61e4:	eb00005f 	cmp	x2, x0
    61e8:	540002cd 	b.le	6240 <fwp_owned_tape_release+0x9c>
    61ec:	d2800014 	mov	x20, #0x0                   	// #0
    61f0:	f90013f5 	str	x21, [sp, #32]
    61f4:	d2800015 	mov	x21, #0x0                   	// #0
    61f8:	f9402260 	ldr	x0, [x19, #64]
    61fc:	910006b5 	add	x21, x21, #0x1
    6200:	f8746800 	ldr	x0, [x0, x20]
    6204:	d63f0020 	blr	x1
    6208:	f9402260 	ldr	x0, [x19, #64]
    620c:	f9400a61 	ldr	x1, [x19, #16]
    6210:	8b140000 	add	x0, x0, x20
    6214:	91004294 	add	x20, x20, #0x10
    6218:	f9400400 	ldr	x0, [x0, #8]
    621c:	f9403421 	ldr	x1, [x1, #104]
    6220:	d63f0020 	blr	x1
    6224:	a9450261 	ldp	x1, x0, [x19, #80]
    6228:	cb010000 	sub	x0, x0, x1
    622c:	eb15001f 	cmp	x0, x21
    6230:	f9400a60 	ldr	x0, [x19, #16]
    6234:	f9403401 	ldr	x1, [x0, #104]
    6238:	54fffe0c 	b.gt	61f8 <fwp_owned_tape_release+0x54>
    623c:	f94013f5 	ldr	x21, [sp, #32]
    6240:	f9403663 	ldr	x3, [x19, #104]
    6244:	f9401262 	ldr	x2, [x19, #32]
    6248:	f100007f 	cmp	x3, #0x0
    624c:	540001ed 	b.le	6288 <fwp_owned_tape_release+0xe4>
    6250:	d2800014 	mov	x20, #0x0                   	// #0
    6254:	d503201f 	nop
    6258:	f9402660 	ldr	x0, [x19, #72]
    625c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6260:	eb02001f 	cmp	x0, x2
    6264:	540000c0 	b.eq	627c <fwp_owned_tape_release+0xd8>  // b.none
    6268:	d63f0020 	blr	x1
    626c:	f9400a60 	ldr	x0, [x19, #16]
    6270:	f9401262 	ldr	x2, [x19, #32]
    6274:	f9403663 	ldr	x3, [x19, #104]
    6278:	f9403401 	ldr	x1, [x0, #104]
    627c:	91000694 	add	x20, x20, #0x1
    6280:	eb14007f 	cmp	x3, x20
    6284:	54fffeac 	b.gt	6258 <fwp_owned_tape_release+0xb4>
    6288:	aa0203e0 	mov	x0, x2
    628c:	d63f0020 	blr	x1
    6290:	f9401660 	ldr	x0, [x19, #40]
    6294:	97ffff67 	bl	6030 <fwp_closure_drop>
    6298:	f9401a60 	ldr	x0, [x19, #48]
    629c:	97ffff65 	bl	6030 <fwp_closure_drop>
    62a0:	f9401e60 	ldr	x0, [x19, #56]
    62a4:	97ffff63 	bl	6030 <fwp_closure_drop>
    62a8:	f9402260 	ldr	x0, [x19, #64]
    62ac:	97fff875 	bl	4480 <fwp_mem_free>
    62b0:	f9402660 	ldr	x0, [x19, #72]
    62b4:	97fff873 	bl	4480 <fwp_mem_free>
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	17fff86f 	b	4480 <fwp_mem_free>
    62c8:	d65f03c0 	ret
    62cc:	d503201f 	nop

00000000000062d0 <fwp_tape_finish>:
    62d0:	d10203ff 	sub	sp, sp, #0x80
    62d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    62d8:	f947f421 	ldr	x1, [x1, #4072]
    62dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    62e0:	910103fd 	add	x29, sp, #0x40
    62e4:	a90553f3 	stp	x19, x20, [sp, #80]
    62e8:	a9065bf5 	stp	x21, x22, [sp, #96]
    62ec:	a90763f7 	stp	x23, x24, [sp, #112]
    62f0:	d00000d8 	adrp	x24, 20000 <__data_start>
    62f4:	91018316 	add	x22, x24, #0x60
    62f8:	f9400022 	ldr	x2, [x1]
    62fc:	f9001fe2 	str	x2, [sp, #56]
    6300:	d2800002 	mov	x2, #0x0                   	// #0
    6304:	910222c0 	add	x0, x22, #0x88
    6308:	97fff47e 	bl	3500 <fwp_tape_buffers_dispose>
    630c:	f90062df 	str	xzr, [x22, #192]
    6310:	f9406ac0 	ldr	x0, [x22, #208]
    6314:	f100001f 	cmp	x0, #0x0
    6318:	5400030d 	b.le	6378 <fwp_tape_finish+0xa8>
    631c:	910003f7 	mov	x23, sp
    6320:	d2800015 	mov	x21, #0x0                   	// #0
    6324:	d2800014 	mov	x20, #0x0                   	// #0
    6328:	f94002d3 	ldr	x19, [x22]
    632c:	91000694 	add	x20, x20, #0x1
    6330:	8b150273 	add	x19, x19, x21
    6334:	9101a2b5 	add	x21, x21, #0x68
    6338:	aa1303e0 	mov	x0, x19
    633c:	97fff335 	bl	3010 <fwp_tape_unlink_scope>
    6340:	aa1703e0 	mov	x0, x23
    6344:	f9401261 	ldr	x1, [x19, #32]
    6348:	f90003e1 	str	x1, [sp]
    634c:	f9401a62 	ldr	x2, [x19, #48]
    6350:	f9000be2 	str	x2, [sp, #16]
    6354:	f9402261 	ldr	x1, [x19, #64]
    6358:	f90013e1 	str	x1, [sp, #32]
    635c:	97fff469 	bl	3500 <fwp_tape_buffers_dispose>
    6360:	f9403260 	ldr	x0, [x19, #96]
    6364:	97ffff90 	bl	61a4 <fwp_owned_tape_release>
    6368:	f900327f 	str	xzr, [x19, #96]
    636c:	f9406ac0 	ldr	x0, [x22, #208]
    6370:	eb14001f 	cmp	x0, x20
    6374:	54fffdac 	b.gt	6328 <fwp_tape_finish+0x58>
    6378:	f9403300 	ldr	x0, [x24, #96]
    637c:	91018313 	add	x19, x24, #0x60
    6380:	97fff194 	bl	29d0 <free@plt>
    6384:	f900331f 	str	xzr, [x24, #96]
    6388:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    638c:	f947f400 	ldr	x0, [x0, #4072]
    6390:	f9006a7f 	str	xzr, [x19, #208]
    6394:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6398:	f9401fe2 	ldr	x2, [sp, #56]
    639c:	f9400001 	ldr	x1, [x0]
    63a0:	eb010042 	subs	x2, x2, x1
    63a4:	d2800001 	mov	x1, #0x0                   	// #0
    63a8:	540000e1 	b.ne	63c4 <fwp_tape_finish+0xf4>  // b.any
    63ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    63b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    63bc:	910203ff 	add	sp, sp, #0x80
    63c0:	d65f03c0 	ret
    63c4:	97fff153 	bl	2910 <__stack_chk_fail@plt>
    63c8:	d503201f 	nop
    63cc:	d503201f 	nop

00000000000063d0 <fwp_tape_scope_release>:
    63d0:	d10243ff 	sub	sp, sp, #0x90
    63d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    63d8:	910103fd 	add	x29, sp, #0x40
    63dc:	a90553f3 	stp	x19, x20, [sp, #80]
    63e0:	aa0003f4 	mov	x20, x0
    63e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    63e8:	f947f400 	ldr	x0, [x0, #4072]
    63ec:	b9400285 	ldr	w5, [x20]
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	f9001fe1 	str	x1, [sp, #56]
    63f8:	d2800001 	mov	x1, #0x0                   	// #0
    63fc:	37f806c5 	tbnz	w5, #31, 64d4 <fwp_tape_scope_release+0x104>
    6400:	a90763f7 	stp	x23, x24, [sp, #112]
    6404:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6408:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    640c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6410:	d00000d3 	adrp	x19, 20000 <__data_start>
    6414:	910003f7 	mov	x23, sp
    6418:	91018273 	add	x19, x19, #0x60
    641c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6420:	a9065bf5 	stp	x21, x22, [sp, #96]
    6424:	52800d16 	mov	w22, #0x68                  	// #104
    6428:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    642c:	f90043f9 	str	x25, [sp, #128]
    6430:	14000006 	b	6448 <fwp_tape_scope_release+0x78>
    6434:	97fff433 	bl	3500 <fwp_tape_buffers_dispose>
    6438:	aa1903e0 	mov	x0, x25
    643c:	97ffff5a 	bl	61a4 <fwp_owned_tape_release>
    6440:	b9400285 	ldr	w5, [x20]
    6444:	37f80425 	tbnz	w5, #31, 64c8 <fwp_tape_scope_release+0xf8>
    6448:	f9400266 	ldr	x6, [x19]
    644c:	9b367ca5 	smull	x5, w5, w22
    6450:	8b0500c0 	add	x0, x6, x5
    6454:	97fff2ef 	bl	3010 <fwp_tape_unlink_scope>
    6458:	ad410001 	ldp	q1, q0, [x0, #32]
    645c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6460:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6464:	f9400c03 	ldr	x3, [x0, #24]
    6468:	ad0003e1 	stp	q1, q0, [sp]
    646c:	b86568c1 	ldr	w1, [x6, x5]
    6470:	a9440804 	ldp	x4, x2, [x0, #64]
    6474:	b900041f 	str	wzr, [x0, #4]
    6478:	f9403019 	ldr	x25, [x0, #96]
    647c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6480:	f9000c1f 	str	xzr, [x0, #24]
    6484:	a9020fe4 	stp	x4, x3, [sp, #32]
    6488:	f9001be2 	str	x2, [sp, #48]
    648c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6490:	f900301f 	str	xzr, [x0, #96]
    6494:	6b15003f 	cmp	w1, w21
    6498:	540000e8 	b.hi	64b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    649c:	9343fca5 	asr	x5, x5, #3
    64a0:	f9407660 	ldr	x0, [x19, #232]
    64a4:	9b187ca5 	mul	x5, x5, x24
    64a8:	eb0000bf 	cmp	x5, x0
    64ac:	5400004a 	b.ge	64b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    64b0:	f9007665 	str	x5, [x19, #232]
    64b4:	aa1703e0 	mov	x0, x23
    64b8:	b5fffbf9 	cbnz	x25, 6434 <fwp_tape_scope_release+0x64>
    64bc:	97fff6ed 	bl	4070 <fwp_tape_buffers_release>
    64c0:	b9400285 	ldr	w5, [x20]
    64c4:	36fffc25 	tbz	w5, #31, 6448 <fwp_tape_scope_release+0x78>
    64c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    64cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    64d0:	f94043f9 	ldr	x25, [sp, #128]
    64d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    64d8:	f947f400 	ldr	x0, [x0, #4072]
    64dc:	f9401fe2 	ldr	x2, [sp, #56]
    64e0:	f9400001 	ldr	x1, [x0]
    64e4:	eb010042 	subs	x2, x2, x1
    64e8:	d2800001 	mov	x1, #0x0                   	// #0
    64ec:	540000a1 	b.ne	6500 <fwp_tape_scope_release+0x130>  // b.any
    64f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    64f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    64f8:	910243ff 	add	sp, sp, #0x90
    64fc:	d65f03c0 	ret
    6500:	a9065bf5 	stp	x21, x22, [sp, #96]
    6504:	a90763f7 	stp	x23, x24, [sp, #112]
    6508:	f90043f9 	str	x25, [sp, #128]
    650c:	97fff101 	bl	2910 <__stack_chk_fail@plt>

0000000000006510 <fwp_drop4>:
    6510:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6514:	910003fd 	mov	x29, sp
    6518:	a9025bf5 	stp	x21, x22, [sp, #32]
    651c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    6520:	911702d5 	add	x21, x22, #0x5c0
    6524:	a90153f3 	stp	x19, x20, [sp, #16]
    6528:	aa0003f3 	mov	x19, x0
    652c:	f949daa1 	ldr	x1, [x21, #5040]
    6530:	f949eea0 	ldr	x0, [x21, #5080]
    6534:	cb010261 	sub	x1, x19, x1
    6538:	eb00403f 	cmp	x1, x0, lsl #16
    653c:	54000382 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6540:	d350fc22 	lsr	x2, x1, #16
    6544:	f949fea3 	ldr	x3, [x21, #5112]
    6548:	8b020842 	add	x2, x2, x2, lsl #2
    654c:	d37df042 	lsl	x2, x2, #3
    6550:	8b020060 	add	x0, x3, x2
    6554:	f9401014 	ldr	x20, [x0, #32]
    6558:	b40002b4 	cbz	x20, 65ac <fwp_drop4+0x9c>
    655c:	38626862 	ldrb	w2, [x3, x2]
    6560:	7100085f 	cmp	w2, #0x2
    6564:	540002c0 	b.eq	65bc <fwp_drop4+0xac>  // b.none
    6568:	7100045f 	cmp	w2, #0x1
    656c:	54000201 	b.ne	65ac <fwp_drop4+0x9c>  // b.any
    6570:	29430002 	ldp	w2, w0, [x0, #24]
    6574:	92403c21 	and	x1, x1, #0xffff
    6578:	9b027c21 	mul	x1, x1, x2
    657c:	d360fc21 	lsr	x1, x1, #32
    6580:	eb00003f 	cmp	x1, x0
    6584:	54000142 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6588:	8b010294 	add	x20, x20, x1
    658c:	39400280 	ldrb	w0, [x20]
    6590:	340000e0 	cbz	w0, 65ac <fwp_drop4+0x9c>
    6594:	7100041f 	cmp	w0, #0x1
    6598:	540001e0 	b.eq	65d4 <fwp_drop4+0xc4>  // b.none
    659c:	7103fc1f 	cmp	w0, #0xff
    65a0:	540007c0 	b.eq	6698 <fwp_drop4+0x188>  // b.none
    65a4:	51000400 	sub	w0, w0, #0x1
    65a8:	39000280 	strb	w0, [x20]
    65ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    65b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65b8:	d65f03c0 	ret
    65bc:	72003c3f 	tst	w1, #0xffff
    65c0:	54fffe60 	b.eq	658c <fwp_drop4+0x7c>  // b.none
    65c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    65c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65d0:	d65f03c0 	ret
    65d4:	911702c2 	add	x2, x22, #0x5c0
    65d8:	f9400660 	ldr	x0, [x19, #8]
    65dc:	f949d841 	ldr	x1, [x2, #5040]
    65e0:	f949ec42 	ldr	x2, [x2, #5080]
    65e4:	cb010001 	sub	x1, x0, x1
    65e8:	eb02403f 	cmp	x1, x2, lsl #16
    65ec:	54000362 	b.cs	6658 <fwp_drop4+0x148>  // b.hs, b.nlast
    65f0:	d350fc22 	lsr	x2, x1, #16
    65f4:	8b020842 	add	x2, x2, x2, lsl #2
    65f8:	d37df042 	lsl	x2, x2, #3
    65fc:	8b020064 	add	x4, x3, x2
    6600:	f9401094 	ldr	x20, [x4, #32]
    6604:	b40002b4 	cbz	x20, 6658 <fwp_drop4+0x148>
    6608:	38626862 	ldrb	w2, [x3, x2]
    660c:	7100085f 	cmp	w2, #0x2
    6610:	540003e0 	b.eq	668c <fwp_drop4+0x17c>  // b.none
    6614:	7100045f 	cmp	w2, #0x1
    6618:	54000201 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    661c:	29430883 	ldp	w3, w2, [x4, #24]
    6620:	92403c21 	and	x1, x1, #0xffff
    6624:	9b037c21 	mul	x1, x1, x3
    6628:	d360fc21 	lsr	x1, x1, #32
    662c:	eb02003f 	cmp	x1, x2
    6630:	54000142 	b.cs	6658 <fwp_drop4+0x148>  // b.hs, b.nlast
    6634:	8b010294 	add	x20, x20, x1
    6638:	39400281 	ldrb	w1, [x20]
    663c:	340000e1 	cbz	w1, 6658 <fwp_drop4+0x148>
    6640:	7100043f 	cmp	w1, #0x1
    6644:	54000200 	b.eq	6684 <fwp_drop4+0x174>  // b.none
    6648:	7103fc3f 	cmp	w1, #0xff
    664c:	54000640 	b.eq	6714 <fwp_drop4+0x204>  // b.none
    6650:	51000421 	sub	w1, w1, #0x1
    6654:	39000281 	strb	w1, [x20]
    6658:	f9400a74 	ldr	x20, [x19, #16]
    665c:	aa1303e0 	mov	x0, x19
    6660:	97fffce8 	bl	5a00 <fwp_rc_free_arr>
    6664:	911702c0 	add	x0, x22, #0x5c0
    6668:	f949d801 	ldr	x1, [x0, #5040]
    666c:	f949ec00 	ldr	x0, [x0, #5080]
    6670:	cb010281 	sub	x1, x20, x1
    6674:	eb00403f 	cmp	x1, x0, lsl #16
    6678:	54fff9a2 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    667c:	aa1403f3 	mov	x19, x20
    6680:	17ffffb0 	b	6540 <fwp_drop4+0x30>
    6684:	97fffcdf 	bl	5a00 <fwp_rc_free_arr>
    6688:	17fffff4 	b	6658 <fwp_drop4+0x148>
    668c:	72003c3f 	tst	w1, #0xffff
    6690:	54fffe41 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    6694:	17ffffe9 	b	6638 <fwp_drop4+0x128>
    6698:	ca544681 	eor	x1, x20, x20, lsr #17
    669c:	911702c0 	add	x0, x22, #0x5c0
    66a0:	ca412421 	eor	x1, x1, x1, lsr #9
    66a4:	92401c21 	and	x1, x1, #0xff
    66a8:	910a2422 	add	x2, x1, #0x289
    66ac:	8b010c01 	add	x1, x0, x1, lsl #3
    66b0:	8b020c02 	add	x2, x0, x2, lsl #3
    66b4:	f94a2420 	ldr	x0, [x1, #5192]
    66b8:	b50000a0 	cbnz	x0, 66cc <fwp_drop4+0x1bc>
    66bc:	14000013 	b	6708 <fwp_drop4+0x1f8>
    66c0:	91004002 	add	x2, x0, #0x10
    66c4:	f9400800 	ldr	x0, [x0, #16]
    66c8:	b4000200 	cbz	x0, 6708 <fwp_drop4+0x1f8>
    66cc:	f9400001 	ldr	x1, [x0]
    66d0:	eb14003f 	cmp	x1, x20
    66d4:	54ffff61 	b.ne	66c0 <fwp_drop4+0x1b0>  // b.any
    66d8:	f9400041 	ldr	x1, [x2]
    66dc:	f9400420 	ldr	x0, [x1, #8]
    66e0:	d1000400 	sub	x0, x0, #0x1
    66e4:	f9000420 	str	x0, [x1, #8]
    66e8:	f103f81f 	cmp	x0, #0xfe
    66ec:	54fff601 	b.ne	65ac <fwp_drop4+0x9c>  // b.any
    66f0:	39400280 	ldrb	w0, [x20]
    66f4:	7103fc1f 	cmp	w0, #0xff
    66f8:	54000460 	b.eq	6784 <fwp_drop4+0x274>  // b.none
    66fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6700:	39000280 	strb	w0, [x20]
    6704:	17ffffaa 	b	65ac <fwp_drop4+0x9c>
    6708:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    670c:	91266000 	add	x0, x0, #0x998
    6710:	97fff6a0 	bl	4190 <fwp_trap>
    6714:	ca544680 	eor	x0, x20, x20, lsr #17
    6718:	911702c1 	add	x1, x22, #0x5c0
    671c:	ca402400 	eor	x0, x0, x0, lsr #9
    6720:	92401c00 	and	x0, x0, #0xff
    6724:	910a2402 	add	x2, x0, #0x289
    6728:	8b000c20 	add	x0, x1, x0, lsl #3
    672c:	8b020c22 	add	x2, x1, x2, lsl #3
    6730:	f94a2400 	ldr	x0, [x0, #5192]
    6734:	b50000a0 	cbnz	x0, 6748 <fwp_drop4+0x238>
    6738:	17fffff4 	b	6708 <fwp_drop4+0x1f8>
    673c:	91004002 	add	x2, x0, #0x10
    6740:	f9400800 	ldr	x0, [x0, #16]
    6744:	b4fffe20 	cbz	x0, 6708 <fwp_drop4+0x1f8>
    6748:	f9400001 	ldr	x1, [x0]
    674c:	eb14003f 	cmp	x1, x20
    6750:	54ffff61 	b.ne	673c <fwp_drop4+0x22c>  // b.any
    6754:	f9400041 	ldr	x1, [x2]
    6758:	f9400420 	ldr	x0, [x1, #8]
    675c:	d1000400 	sub	x0, x0, #0x1
    6760:	f9000420 	str	x0, [x1, #8]
    6764:	f103f81f 	cmp	x0, #0xfe
    6768:	54fff781 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    676c:	39400280 	ldrb	w0, [x20]
    6770:	7103fc1f 	cmp	w0, #0xff
    6774:	540000e0 	b.eq	6790 <fwp_drop4+0x280>  // b.none
    6778:	12800020 	mov	w0, #0xfffffffe            	// #-2
    677c:	39000280 	strb	w0, [x20]
    6780:	17ffffb6 	b	6658 <fwp_drop4+0x148>
    6784:	aa1403e0 	mov	x0, x20
    6788:	97fff6a2 	bl	4210 <fwp_rc_forget_slot.part.0>
    678c:	17ffffdc 	b	66fc <fwp_drop4+0x1ec>
    6790:	aa1403e0 	mov	x0, x20
    6794:	97fff69f 	bl	4210 <fwp_rc_forget_slot.part.0>
    6798:	17fffff8 	b	6778 <fwp_drop4+0x268>
    679c:	d503201f 	nop

00000000000067a0 <fwp_arg_drop37>:
    67a0:	7100003f 	cmp	w1, #0x0
    67a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    67a8:	54000041 	b.ne	67b0 <fwp_arg_drop37+0x10>  // b.any
    67ac:	d65f03c0 	ret
    67b0:	f9400000 	ldr	x0, [x0]
    67b4:	17ffff57 	b	6510 <fwp_drop4>
    67b8:	d503201f 	nop
    67bc:	d503201f 	nop

00000000000067c0 <fwp_task_dispose>:
    67c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67c4:	910003fd 	mov	x29, sp
    67c8:	f9000bf3 	str	x19, [sp, #16]
    67cc:	aa0003f3 	mov	x19, x0
    67d0:	39414000 	ldrb	w0, [x0, #80]
    67d4:	36000720 	tbz	w0, #0, 68b8 <fwp_task_dispose+0xf8>
    67d8:	f9400a60 	ldr	x0, [x19, #16]
    67dc:	b50006e0 	cbnz	x0, 68b8 <fwp_task_dispose+0xf8>
    67e0:	a9478660 	ldp	x0, x1, [x19, #120]
    67e4:	39014e7f 	strb	wzr, [x19, #83]
    67e8:	f9003e7f 	str	xzr, [x19, #120]
    67ec:	f100003f 	cmp	x1, #0x0
    67f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67f4:	54000040 	b.eq	67fc <fwp_task_dispose+0x3c>  // b.none
    67f8:	d63f0020 	blr	x1
    67fc:	f9405660 	ldr	x0, [x19, #168]
    6800:	97fff720 	bl	4480 <fwp_mem_free>
    6804:	f900567f 	str	xzr, [x19, #168]
    6808:	b9405e60 	ldr	w0, [x19, #92]
    680c:	7100041f 	cmp	w0, #0x1
    6810:	54000420 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6814:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6818:	91170042 	add	x2, x2, #0x5c0
    681c:	f949d840 	ldr	x0, [x2, #5040]
    6820:	f949ec41 	ldr	x1, [x2, #5080]
    6824:	cb000260 	sub	x0, x19, x0
    6828:	eb01401f 	cmp	x0, x1, lsl #16
    682c:	540002e2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6830:	d350fc01 	lsr	x1, x0, #16
    6834:	f949fc44 	ldr	x4, [x2, #5112]
    6838:	8b010821 	add	x1, x1, x1, lsl #2
    683c:	d37df021 	lsl	x1, x1, #3
    6840:	8b010083 	add	x3, x4, x1
    6844:	f9401062 	ldr	x2, [x3, #32]
    6848:	b4000202 	cbz	x2, 6888 <fwp_task_dispose+0xc8>
    684c:	38616881 	ldrb	w1, [x4, x1]
    6850:	7100083f 	cmp	w1, #0x2
    6854:	54000280 	b.eq	68a4 <fwp_task_dispose+0xe4>  // b.none
    6858:	7100043f 	cmp	w1, #0x1
    685c:	54000161 	b.ne	6888 <fwp_task_dispose+0xc8>  // b.any
    6860:	29430464 	ldp	w4, w1, [x3, #24]
    6864:	92403c00 	and	x0, x0, #0xffff
    6868:	9b047c00 	mul	x0, x0, x4
    686c:	d360fc00 	lsr	x0, x0, #32
    6870:	eb01001f 	cmp	x0, x1
    6874:	540000a2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6878:	8b000042 	add	x2, x2, x0
    687c:	39400040 	ldrb	w0, [x2]
    6880:	7100041f 	cmp	w0, #0x1
    6884:	54000080 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6888:	f9400bf3 	ldr	x19, [sp, #16]
    688c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6890:	d65f03c0 	ret
    6894:	aa1303e0 	mov	x0, x19
    6898:	f9400bf3 	ldr	x19, [sp, #16]
    689c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a0:	17fff6f8 	b	4480 <fwp_mem_free>
    68a4:	72003c1f 	tst	w0, #0xffff
    68a8:	54fffea0 	b.eq	687c <fwp_task_dispose+0xbc>  // b.none
    68ac:	f9400bf3 	ldr	x19, [sp, #16]
    68b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b4:	d65f03c0 	ret
    68b8:	97fff02a 	bl	2960 <abort@plt>
    68bc:	d503201f 	nop

00000000000068c0 <fwp_free_zombie>:
    68c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68c4:	910003fd 	mov	x29, sp
    68c8:	a90153f3 	stp	x19, x20, [sp, #16]
    68cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    68d0:	91018281 	add	x1, x20, #0x60
    68d4:	f9407833 	ldr	x19, [x1, #240]
    68d8:	b4000333 	cbz	x19, 693c <fwp_free_zombie+0x7c>
    68dc:	f9400820 	ldr	x0, [x1, #16]
    68e0:	eb00027f 	cmp	x19, x0
    68e4:	540002c0 	b.eq	693c <fwp_free_zombie+0x7c>  // b.none
    68e8:	b940f822 	ldr	w2, [x1, #248]
    68ec:	f9400a60 	ldr	x0, [x19, #16]
    68f0:	7100fc5f 	cmp	w2, #0x3f
    68f4:	5400078c 	b.gt	69e4 <fwp_free_zombie+0x124>
    68f8:	91040023 	add	x3, x1, #0x100
    68fc:	11000444 	add	w4, w2, #0x1
    6900:	b900f824 	str	w4, [x1, #248]
    6904:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6908:	f822d860 	str	x0, [x3, w2, sxtw #3]
    690c:	a9530261 	ldp	x1, x0, [x19, #304]
    6910:	b4000741 	cbz	x1, 69f8 <fwp_free_zombie+0x138>
    6914:	f9009c20 	str	x0, [x1, #312]
    6918:	b4000040 	cbz	x0, 6920 <fwp_free_zombie+0x60>
    691c:	f9009801 	str	x1, [x0, #304]
    6920:	91018294 	add	x20, x20, #0x60
    6924:	b9405e60 	ldr	w0, [x19, #92]
    6928:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    692c:	f9007a9f 	str	xzr, [x20, #240]
    6930:	34000140 	cbz	w0, 6958 <fwp_free_zombie+0x98>
    6934:	7100041f 	cmp	w0, #0x1
    6938:	54000080 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    693c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6944:	d65f03c0 	ret
    6948:	aa1303e0 	mov	x0, x19
    694c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6950:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6954:	17ffff9b 	b	67c0 <fwp_task_dispose>
    6958:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc20>
    695c:	91170082 	add	x2, x4, #0x5c0
    6960:	f949d841 	ldr	x1, [x2, #5040]
    6964:	f949ec40 	ldr	x0, [x2, #5080]
    6968:	cb010261 	sub	x1, x19, x1
    696c:	eb00403f 	cmp	x1, x0, lsl #16
    6970:	54fffe62 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6974:	d350fc20 	lsr	x0, x1, #16
    6978:	f949fc43 	ldr	x3, [x2, #5112]
    697c:	8b000800 	add	x0, x0, x0, lsl #2
    6980:	d37df000 	lsl	x0, x0, #3
    6984:	8b000062 	add	x2, x3, x0
    6988:	f9401054 	ldr	x20, [x2, #32]
    698c:	b4fffd94 	cbz	x20, 693c <fwp_free_zombie+0x7c>
    6990:	38606860 	ldrb	w0, [x3, x0]
    6994:	7100081f 	cmp	w0, #0x2
    6998:	54000360 	b.eq	6a04 <fwp_free_zombie+0x144>  // b.none
    699c:	7100041f 	cmp	w0, #0x1
    69a0:	54fffce1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    69a4:	29430043 	ldp	w3, w0, [x2, #24]
    69a8:	92403c21 	and	x1, x1, #0xffff
    69ac:	9b037c21 	mul	x1, x1, x3
    69b0:	d360fc21 	lsr	x1, x1, #32
    69b4:	eb00003f 	cmp	x1, x0
    69b8:	54fffc22 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    69bc:	8b010294 	add	x20, x20, x1
    69c0:	39400280 	ldrb	w0, [x20]
    69c4:	34fffbc0 	cbz	w0, 693c <fwp_free_zombie+0x7c>
    69c8:	7100041f 	cmp	w0, #0x1
    69cc:	54fffbe0 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    69d0:	7103fc1f 	cmp	w0, #0xff
    69d4:	540001e0 	b.eq	6a10 <fwp_free_zombie+0x150>  // b.none
    69d8:	51000400 	sub	w0, w0, #0x1
    69dc:	39000280 	strb	w0, [x20]
    69e0:	17ffffd7 	b	693c <fwp_free_zombie+0x7c>
    69e4:	f9400e61 	ldr	x1, [x19, #24]
    69e8:	97fff012 	bl	2a30 <munmap@plt>
    69ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69f0:	a9530261 	ldp	x1, x0, [x19, #304]
    69f4:	b5fff901 	cbnz	x1, 6914 <fwp_free_zombie+0x54>
    69f8:	91018282 	add	x2, x20, #0x60
    69fc:	f9018040 	str	x0, [x2, #768]
    6a00:	17ffffc6 	b	6918 <fwp_free_zombie+0x58>
    6a04:	72003c3f 	tst	w1, #0xffff
    6a08:	54fff9a1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a0c:	17ffffed 	b	69c0 <fwp_free_zombie+0x100>
    6a10:	ca544680 	eor	x0, x20, x20, lsr #17
    6a14:	91170084 	add	x4, x4, #0x5c0
    6a18:	ca402400 	eor	x0, x0, x0, lsr #9
    6a1c:	92401c00 	and	x0, x0, #0xff
    6a20:	910a2402 	add	x2, x0, #0x289
    6a24:	8b000c80 	add	x0, x4, x0, lsl #3
    6a28:	8b020c82 	add	x2, x4, x2, lsl #3
    6a2c:	f94a2400 	ldr	x0, [x0, #5192]
    6a30:	b50000a0 	cbnz	x0, 6a44 <fwp_free_zombie+0x184>
    6a34:	14000013 	b	6a80 <fwp_free_zombie+0x1c0>
    6a38:	91004002 	add	x2, x0, #0x10
    6a3c:	f9400800 	ldr	x0, [x0, #16]
    6a40:	b4000200 	cbz	x0, 6a80 <fwp_free_zombie+0x1c0>
    6a44:	f9400001 	ldr	x1, [x0]
    6a48:	eb14003f 	cmp	x1, x20
    6a4c:	54ffff61 	b.ne	6a38 <fwp_free_zombie+0x178>  // b.any
    6a50:	f9400041 	ldr	x1, [x2]
    6a54:	f9400420 	ldr	x0, [x1, #8]
    6a58:	d1000400 	sub	x0, x0, #0x1
    6a5c:	f9000420 	str	x0, [x1, #8]
    6a60:	f103f81f 	cmp	x0, #0xfe
    6a64:	54fff6c1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a68:	39400280 	ldrb	w0, [x20]
    6a6c:	7103fc1f 	cmp	w0, #0xff
    6a70:	540000e0 	b.eq	6a8c <fwp_free_zombie+0x1cc>  // b.none
    6a74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a78:	39000280 	strb	w0, [x20]
    6a7c:	17ffffb0 	b	693c <fwp_free_zombie+0x7c>
    6a80:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    6a84:	91266000 	add	x0, x0, #0x998
    6a88:	97fff5c2 	bl	4190 <fwp_trap>
    6a8c:	aa1403e0 	mov	x0, x20
    6a90:	97fff5e0 	bl	4210 <fwp_rc_forget_slot.part.0>
    6a94:	17fffff8 	b	6a74 <fwp_free_zombie+0x1b4>
    6a98:	d503201f 	nop
    6a9c:	d503201f 	nop

0000000000006aa0 <fwp_block>:
    6aa0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6aa4:	910003fd 	mov	x29, sp
    6aa8:	a90153f3 	stp	x19, x20, [sp, #16]
    6aac:	d00000d3 	adrp	x19, 20000 <__data_start>
    6ab0:	91018274 	add	x20, x19, #0x60
    6ab4:	f9404282 	ldr	x2, [x20, #128]
    6ab8:	b4000642 	cbz	x2, 6b80 <fwp_block+0xe0>
    6abc:	91018261 	add	x1, x19, #0x60
    6ac0:	f9408040 	ldr	x0, [x2, #256]
    6ac4:	f9004020 	str	x0, [x1, #128]
    6ac8:	b40006a0 	cbz	x0, 6b9c <fwp_block+0xfc>
    6acc:	d503201f 	nop
    6ad0:	91018263 	add	x3, x19, #0x60
    6ad4:	3901505f 	strb	wzr, [x2, #84]
    6ad8:	f9400864 	ldr	x4, [x3, #16]
    6adc:	eb02009f 	cmp	x4, x2
    6ae0:	54000440 	b.eq	6b68 <fwp_block+0xc8>  // b.none
    6ae4:	f9418465 	ldr	x5, [x3, #776]
    6ae8:	f9000862 	str	x2, [x3, #16]
    6aec:	f9400441 	ldr	x1, [x2, #8]
    6af0:	f9004885 	str	x5, [x4, #144]
    6af4:	f9418865 	ldr	x5, [x3, #784]
    6af8:	f9004c85 	str	x5, [x4, #152]
    6afc:	f9418c65 	ldr	x5, [x3, #792]
    6b00:	f9005085 	str	x5, [x4, #160]
    6b04:	f9419065 	ldr	x5, [x3, #800]
    6b08:	f9005485 	str	x5, [x4, #168]
    6b0c:	f9419465 	ldr	x5, [x3, #808]
    6b10:	f9005885 	str	x5, [x4, #176]
    6b14:	f9419865 	ldr	x5, [x3, #816]
    6b18:	f9005c85 	str	x5, [x4, #184]
    6b1c:	f9419c65 	ldr	x5, [x3, #824]
    6b20:	f9006085 	str	x5, [x4, #192]
    6b24:	f9400480 	ldr	x0, [x4, #8]
    6b28:	f9404844 	ldr	x4, [x2, #144]
    6b2c:	f9018464 	str	x4, [x3, #776]
    6b30:	f9404c44 	ldr	x4, [x2, #152]
    6b34:	f9018864 	str	x4, [x3, #784]
    6b38:	f9405044 	ldr	x4, [x2, #160]
    6b3c:	f9018c64 	str	x4, [x3, #792]
    6b40:	f9405444 	ldr	x4, [x2, #168]
    6b44:	f9019064 	str	x4, [x3, #800]
    6b48:	f9405844 	ldr	x4, [x2, #176]
    6b4c:	f9019464 	str	x4, [x3, #808]
    6b50:	a94b8844 	ldp	x4, x2, [x2, #184]
    6b54:	f9019864 	str	x4, [x3, #816]
    6b58:	f9019c62 	str	x2, [x3, #824]
    6b5c:	97ffef85 	bl	2970 <swapcontext@plt>
    6b60:	97ffff58 	bl	68c0 <fwp_free_zombie>
    6b64:	d503201f 	nop
    6b68:	91018260 	add	x0, x19, #0x60
    6b6c:	b9434000 	ldr	w0, [x0, #832]
    6b70:	340001a0 	cbz	w0, 6ba4 <fwp_block+0x104>
    6b74:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b7c:	d65f03c0 	ret
    6b80:	97fff7cc 	bl	4ab0 <fwp_poll_events>
    6b84:	f9404282 	ldr	x2, [x20, #128]
    6b88:	b4ffffc2 	cbz	x2, 6b80 <fwp_block+0xe0>
    6b8c:	91018261 	add	x1, x19, #0x60
    6b90:	f9408040 	ldr	x0, [x2, #256]
    6b94:	f9004020 	str	x0, [x1, #128]
    6b98:	b5fff9c0 	cbnz	x0, 6ad0 <fwp_block+0x30>
    6b9c:	f9003c3f 	str	xzr, [x1, #120]
    6ba0:	17ffffcc 	b	6ad0 <fwp_block+0x30>
    6ba4:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    6ba8:	9130c000 	add	x0, x0, #0xc30
    6bac:	97ffefbd 	bl	2aa0 <getenv@plt>
    6bb0:	5284e202 	mov	w2, #0x2710                	// #10000
    6bb4:	b4000060 	cbz	x0, 6bc0 <fwp_block+0x120>
    6bb8:	39400001 	ldrb	w1, [x0]
    6bbc:	350000c1 	cbnz	w1, 6bd4 <fwp_block+0x134>
    6bc0:	91018273 	add	x19, x19, #0x60
    6bc4:	b9034262 	str	w2, [x19, #832]
    6bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bd0:	d65f03c0 	ret
    6bd4:	52800142 	mov	w2, #0xa                   	// #10
    6bd8:	d2800001 	mov	x1, #0x0                   	// #0
    6bdc:	97ffef01 	bl	27e0 <strtoll@plt>
    6be0:	d1000403 	sub	x3, x0, #0x1
    6be4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6be8:	eb02007f 	cmp	x3, x2
    6bec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6bf0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6bf4:	17fffff3 	b	6bc0 <fwp_block+0x120>
    6bf8:	d503201f 	nop
    6bfc:	d503201f 	nop

0000000000006c00 <fwp_drop10>:
    6c00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6c04:	910003fd 	mov	x29, sp
    6c08:	a90153f3 	stp	x19, x20, [sp, #16]
    6c0c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    6c10:	f90013f5 	str	x21, [sp, #32]
    6c14:	91170275 	add	x21, x19, #0x5c0
    6c18:	f949daa1 	ldr	x1, [x21, #5040]
    6c1c:	f949eea2 	ldr	x2, [x21, #5080]
    6c20:	cb010001 	sub	x1, x0, x1
    6c24:	eb02403f 	cmp	x1, x2, lsl #16
    6c28:	54000382 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c2c:	d350fc22 	lsr	x2, x1, #16
    6c30:	f949fea3 	ldr	x3, [x21, #5112]
    6c34:	8b020842 	add	x2, x2, x2, lsl #2
    6c38:	d37df042 	lsl	x2, x2, #3
    6c3c:	8b020064 	add	x4, x3, x2
    6c40:	f9401094 	ldr	x20, [x4, #32]
    6c44:	b40002b4 	cbz	x20, 6c98 <fwp_drop10+0x98>
    6c48:	38626862 	ldrb	w2, [x3, x2]
    6c4c:	7100085f 	cmp	w2, #0x2
    6c50:	540007a0 	b.eq	6d44 <fwp_drop10+0x144>  // b.none
    6c54:	7100045f 	cmp	w2, #0x1
    6c58:	54000201 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6c5c:	29430885 	ldp	w5, w2, [x4, #24]
    6c60:	92403c21 	and	x1, x1, #0xffff
    6c64:	9b057c21 	mul	x1, x1, x5
    6c68:	d360fc21 	lsr	x1, x1, #32
    6c6c:	eb02003f 	cmp	x1, x2
    6c70:	54000142 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c74:	8b010294 	add	x20, x20, x1
    6c78:	39400281 	ldrb	w1, [x20]
    6c7c:	340000e1 	cbz	w1, 6c98 <fwp_drop10+0x98>
    6c80:	7100043f 	cmp	w1, #0x1
    6c84:	54000120 	b.eq	6ca8 <fwp_drop10+0xa8>  // b.none
    6c88:	7103fc3f 	cmp	w1, #0xff
    6c8c:	540007c0 	b.eq	6d84 <fwp_drop10+0x184>  // b.none
    6c90:	51000421 	sub	w1, w1, #0x1
    6c94:	39000281 	strb	w1, [x20]
    6c98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c9c:	f94013f5 	ldr	x21, [sp, #32]
    6ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ca4:	d65f03c0 	ret
    6ca8:	f9400001 	ldr	x1, [x0]
    6cac:	b7f80581 	tbnz	x1, #63, 6d5c <fwp_drop10+0x15c>
    6cb0:	91170273 	add	x19, x19, #0x5c0
    6cb4:	f949da61 	ldr	x1, [x19, #5040]
    6cb8:	f949ee62 	ldr	x2, [x19, #5080]
    6cbc:	cb010001 	sub	x1, x0, x1
    6cc0:	eb02403f 	cmp	x1, x2, lsl #16
    6cc4:	54fffea2 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cc8:	d350fc22 	lsr	x2, x1, #16
    6ccc:	8b020842 	add	x2, x2, x2, lsl #2
    6cd0:	d37df042 	lsl	x2, x2, #3
    6cd4:	8b020065 	add	x5, x3, x2
    6cd8:	f94010a4 	ldr	x4, [x5, #32]
    6cdc:	b4fffde4 	cbz	x4, 6c98 <fwp_drop10+0x98>
    6ce0:	38626862 	ldrb	w2, [x3, x2]
    6ce4:	7100085f 	cmp	w2, #0x2
    6ce8:	54000220 	b.eq	6d2c <fwp_drop10+0x12c>  // b.none
    6cec:	7100045f 	cmp	w2, #0x1
    6cf0:	54fffd41 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6cf4:	294308a3 	ldp	w3, w2, [x5, #24]
    6cf8:	92403c21 	and	x1, x1, #0xffff
    6cfc:	9b037c21 	mul	x1, x1, x3
    6d00:	d360fc21 	lsr	x1, x1, #32
    6d04:	eb02003f 	cmp	x1, x2
    6d08:	54fffc82 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d0c:	8b010084 	add	x4, x4, x1
    6d10:	39400081 	ldrb	w1, [x4]
    6d14:	7100043f 	cmp	w1, #0x1
    6d18:	54fffc01 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6d1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d20:	f94013f5 	ldr	x21, [sp, #32]
    6d24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d28:	17fff5d6 	b	4480 <fwp_mem_free>
    6d2c:	72003c3f 	tst	w1, #0xffff
    6d30:	54ffff00 	b.eq	6d10 <fwp_drop10+0x110>  // b.none
    6d34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d38:	f94013f5 	ldr	x21, [sp, #32]
    6d3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d40:	d65f03c0 	ret
    6d44:	72003c3f 	tst	w1, #0xffff
    6d48:	54fff980 	b.eq	6c78 <fwp_drop10+0x78>  // b.none
    6d4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d50:	f94013f5 	ldr	x21, [sp, #32]
    6d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d58:	d65f03c0 	ret
    6d5c:	f9400414 	ldr	x20, [x0, #8]
    6d60:	97fffb28 	bl	5a00 <fwp_rc_free_arr>
    6d64:	91170260 	add	x0, x19, #0x5c0
    6d68:	f949d801 	ldr	x1, [x0, #5040]
    6d6c:	f949ec00 	ldr	x0, [x0, #5080]
    6d70:	cb010281 	sub	x1, x20, x1
    6d74:	eb00403f 	cmp	x1, x0, lsl #16
    6d78:	54fff902 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d7c:	aa1403e0 	mov	x0, x20
    6d80:	17ffffab 	b	6c2c <fwp_drop10+0x2c>
    6d84:	ca544680 	eor	x0, x20, x20, lsr #17
    6d88:	91170273 	add	x19, x19, #0x5c0
    6d8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d90:	92401c00 	and	x0, x0, #0xff
    6d94:	910a2402 	add	x2, x0, #0x289
    6d98:	8b000e60 	add	x0, x19, x0, lsl #3
    6d9c:	8b020e62 	add	x2, x19, x2, lsl #3
    6da0:	f94a2400 	ldr	x0, [x0, #5192]
    6da4:	b50000a0 	cbnz	x0, 6db8 <fwp_drop10+0x1b8>
    6da8:	14000013 	b	6df4 <fwp_drop10+0x1f4>
    6dac:	91004002 	add	x2, x0, #0x10
    6db0:	f9400800 	ldr	x0, [x0, #16]
    6db4:	b4000200 	cbz	x0, 6df4 <fwp_drop10+0x1f4>
    6db8:	f9400001 	ldr	x1, [x0]
    6dbc:	eb14003f 	cmp	x1, x20
    6dc0:	54ffff61 	b.ne	6dac <fwp_drop10+0x1ac>  // b.any
    6dc4:	f9400041 	ldr	x1, [x2]
    6dc8:	f9400420 	ldr	x0, [x1, #8]
    6dcc:	d1000400 	sub	x0, x0, #0x1
    6dd0:	f9000420 	str	x0, [x1, #8]
    6dd4:	f103f81f 	cmp	x0, #0xfe
    6dd8:	54fff601 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6ddc:	39400280 	ldrb	w0, [x20]
    6de0:	7103fc1f 	cmp	w0, #0xff
    6de4:	540000e0 	b.eq	6e00 <fwp_drop10+0x200>  // b.none
    6de8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6dec:	39000280 	strb	w0, [x20]
    6df0:	17ffffaa 	b	6c98 <fwp_drop10+0x98>
    6df4:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    6df8:	91266000 	add	x0, x0, #0x998
    6dfc:	97fff4e5 	bl	4190 <fwp_trap>
    6e00:	aa1403e0 	mov	x0, x20
    6e04:	97fff503 	bl	4210 <fwp_rc_forget_slot.part.0>
    6e08:	17fffff8 	b	6de8 <fwp_drop10+0x1e8>
    6e0c:	d503201f 	nop

0000000000006e10 <fwp_caps173>:
    6e10:	34000041 	cbz	w1, 6e18 <fwp_caps173+0x8>
    6e14:	d65f03c0 	ret
    6e18:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc20>
    6e1c:	91170063 	add	x3, x3, #0x5c0
    6e20:	f949d861 	ldr	x1, [x3, #5040]
    6e24:	f949ec62 	ldr	x2, [x3, #5080]
    6e28:	cb010001 	sub	x1, x0, x1
    6e2c:	eb02403f 	cmp	x1, x2, lsl #16
    6e30:	54ffff22 	b.cs	6e14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e34:	d350fc22 	lsr	x2, x1, #16
    6e38:	f949fc65 	ldr	x5, [x3, #5112]
    6e3c:	8b020842 	add	x2, x2, x2, lsl #2
    6e40:	d37df042 	lsl	x2, x2, #3
    6e44:	8b0200a4 	add	x4, x5, x2
    6e48:	f9401083 	ldr	x3, [x4, #32]
    6e4c:	b4fffe43 	cbz	x3, 6e14 <fwp_caps173+0x4>
    6e50:	386268a2 	ldrb	w2, [x5, x2]
    6e54:	7100085f 	cmp	w2, #0x2
    6e58:	540001c0 	b.eq	6e90 <fwp_caps173+0x80>  // b.none
    6e5c:	7100045f 	cmp	w2, #0x1
    6e60:	54fffda1 	b.ne	6e14 <fwp_caps173+0x4>  // b.any
    6e64:	29430885 	ldp	w5, w2, [x4, #24]
    6e68:	92403c21 	and	x1, x1, #0xffff
    6e6c:	9b057c21 	mul	x1, x1, x5
    6e70:	d360fc21 	lsr	x1, x1, #32
    6e74:	eb02003f 	cmp	x1, x2
    6e78:	54fffce2 	b.cs	6e14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e7c:	8b010063 	add	x3, x3, x1
    6e80:	39400061 	ldrb	w1, [x3]
    6e84:	7100043f 	cmp	w1, #0x1
    6e88:	54fffc61 	b.ne	6e14 <fwp_caps173+0x4>  // b.any
    6e8c:	17fff57d 	b	4480 <fwp_mem_free>
    6e90:	72003c3f 	tst	w1, #0xffff
    6e94:	54ffff60 	b.eq	6e80 <fwp_caps173+0x70>  // b.none
    6e98:	d65f03c0 	ret
    6e9c:	d503201f 	nop

0000000000006ea0 <f37>:
    6ea0:	d10203ff 	sub	sp, sp, #0x80
    6ea4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6ea8:	f947f421 	ldr	x1, [x1, #4072]
    6eac:	a9027bfd 	stp	x29, x30, [sp, #32]
    6eb0:	910083fd 	add	x29, sp, #0x20
    6eb4:	a9045bf5 	stp	x21, x22, [sp, #64]
    6eb8:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc20>
    6ebc:	911702a3 	add	x3, x21, #0x5c0
    6ec0:	a90353f3 	stp	x19, x20, [sp, #48]
    6ec4:	aa0003f6 	mov	x22, x0
    6ec8:	a90563f7 	stp	x23, x24, [sp, #80]
    6ecc:	a9066bf9 	stp	x25, x26, [sp, #96]
    6ed0:	f949ec62 	ldr	x2, [x3, #5080]
    6ed4:	f9400024 	ldr	x4, [x1]
    6ed8:	f9000fe4 	str	x4, [sp, #24]
    6edc:	d2800004 	mov	x4, #0x0                   	// #0
    6ee0:	f949d861 	ldr	x1, [x3, #5040]
    6ee4:	d370bc42 	lsl	x2, x2, #16
    6ee8:	b4001820 	cbz	x0, 71ec <f37+0x34c>
    6eec:	f9400817 	ldr	x23, [x0, #16]
    6ef0:	cb0102e1 	sub	x1, x23, x1
    6ef4:	eb02003f 	cmp	x1, x2
    6ef8:	54000362 	b.cs	6f64 <f37+0xc4>  // b.hs, b.nlast
    6efc:	f949fc60 	ldr	x0, [x3, #5112]
    6f00:	d350fc22 	lsr	x2, x1, #16
    6f04:	8b020842 	add	x2, x2, x2, lsl #2
    6f08:	8b020c02 	add	x2, x0, x2, lsl #3
    6f0c:	f9401040 	ldr	x0, [x2, #32]
    6f10:	b40002a0 	cbz	x0, 6f64 <f37+0xc4>
    6f14:	39400043 	ldrb	w3, [x2]
    6f18:	7100087f 	cmp	w3, #0x2
    6f1c:	54001560 	b.eq	71c8 <f37+0x328>  // b.none
    6f20:	7100047f 	cmp	w3, #0x1
    6f24:	540001c1 	b.ne	6f5c <f37+0xbc>  // b.any
    6f28:	29430843 	ldp	w3, w2, [x2, #24]
    6f2c:	92403c21 	and	x1, x1, #0xffff
    6f30:	9b037c21 	mul	x1, x1, x3
    6f34:	d360fc21 	lsr	x1, x1, #32
    6f38:	eb02003f 	cmp	x1, x2
    6f3c:	54000102 	b.cs	6f5c <f37+0xbc>  // b.hs, b.nlast
    6f40:	8b010000 	add	x0, x0, x1
    6f44:	39400001 	ldrb	w1, [x0]
    6f48:	340000a1 	cbz	w1, 6f5c <f37+0xbc>
    6f4c:	7103f43f 	cmp	w1, #0xfd
    6f50:	54001808 	b.hi	7250 <f37+0x3b0>  // b.pmore
    6f54:	11000421 	add	w1, w1, #0x1
    6f58:	39000001 	strb	w1, [x0]
    6f5c:	d2800002 	mov	x2, #0x0                   	// #0
    6f60:	b40000f6 	cbz	x22, 6f7c <f37+0xdc>
    6f64:	aa1603e1 	mov	x1, x22
    6f68:	d2800002 	mov	x2, #0x0                   	// #0
    6f6c:	d503201f 	nop
    6f70:	f9400821 	ldr	x1, [x1, #16]
    6f74:	91000442 	add	x2, x2, #0x1
    6f78:	b5ffffc1 	cbnz	x1, 6f70 <f37+0xd0>
    6f7c:	b40013f7 	cbz	x23, 71f8 <f37+0x358>
    6f80:	aa1703e1 	mov	x1, x23
    6f84:	d2800003 	mov	x3, #0x0                   	// #0
    6f88:	f9400821 	ldr	x1, [x1, #16]
    6f8c:	91000463 	add	x3, x3, #0x1
    6f90:	b5ffffc1 	cbnz	x1, 6f88 <f37+0xe8>
    6f94:	eb02007f 	cmp	x3, x2
    6f98:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6f9c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6fa0:	eb00027f 	cmp	x19, x0
    6fa4:	540010a8 	b.hi	71b8 <f37+0x318>  // b.pmore
    6fa8:	d37ffa74 	lsl	x20, x19, #1
    6fac:	52800041 	mov	w1, #0x2                   	// #2
    6fb0:	91000680 	add	x0, x20, #0x1
    6fb4:	d37df000 	lsl	x0, x0, #3
    6fb8:	97fff7ee 	bl	4f70 <fwp_heap_alloc>
    6fbc:	aa0003f8 	mov	x24, x0
    6fc0:	911702a1 	add	x1, x21, #0x5c0
    6fc4:	aa0103e0 	mov	x0, x1
    6fc8:	f9000314 	str	x20, [x24]
    6fcc:	f949d821 	ldr	x1, [x1, #5040]
    6fd0:	f949ec00 	ldr	x0, [x0, #5080]
    6fd4:	cb010301 	sub	x1, x24, x1
    6fd8:	eb00403f 	cmp	x1, x0, lsl #16
    6fdc:	54000342 	b.cs	7044 <f37+0x1a4>  // b.hs, b.nlast
    6fe0:	911702a2 	add	x2, x21, #0x5c0
    6fe4:	d350fc20 	lsr	x0, x1, #16
    6fe8:	8b000800 	add	x0, x0, x0, lsl #2
    6fec:	f949fc43 	ldr	x3, [x2, #5112]
    6ff0:	d37df002 	lsl	x2, x0, #3
    6ff4:	8b020060 	add	x0, x3, x2
    6ff8:	f9401014 	ldr	x20, [x0, #32]
    6ffc:	b4000254 	cbz	x20, 7044 <f37+0x1a4>
    7000:	38626862 	ldrb	w2, [x3, x2]
    7004:	7100085f 	cmp	w2, #0x2
    7008:	54000ec0 	b.eq	71e0 <f37+0x340>  // b.none
    700c:	7100045f 	cmp	w2, #0x1
    7010:	540001a1 	b.ne	7044 <f37+0x1a4>  // b.any
    7014:	29430002 	ldp	w2, w0, [x0, #24]
    7018:	92403c21 	and	x1, x1, #0xffff
    701c:	9b027c21 	mul	x1, x1, x2
    7020:	d360fc21 	lsr	x1, x1, #32
    7024:	eb00003f 	cmp	x1, x0
    7028:	540000e2 	b.cs	7044 <f37+0x1a4>  // b.hs, b.nlast
    702c:	8b010294 	add	x20, x20, x1
    7030:	39400280 	ldrb	w0, [x20]
    7034:	7103fc1f 	cmp	w0, #0xff
    7038:	54001100 	b.eq	7258 <f37+0x3b8>  // b.none
    703c:	52800020 	mov	w0, #0x1                   	// #1
    7040:	39000280 	strb	w0, [x20]
    7044:	b4000253 	cbz	x19, 708c <f37+0x1ec>
    7048:	8b131313 	add	x19, x24, x19, lsl #4
    704c:	aa1803f4 	mov	x20, x24
    7050:	aa1603fa 	mov	x26, x22
    7054:	aa1703f9 	mov	x25, x23
    7058:	f9400723 	ldr	x3, [x25, #8]
    705c:	f9400742 	ldr	x2, [x26, #8]
    7060:	f9400861 	ldr	x1, [x3, #16]
    7064:	f9400840 	ldr	x0, [x2, #16]
    7068:	fd400461 	ldr	d1, [x3, #8]
    706c:	fd400440 	ldr	d0, [x2, #8]
    7070:	97fff92d 	bl	5524 <w120>
    7074:	f9000680 	str	x0, [x20, #8]
    7078:	f8010e81 	str	x1, [x20, #16]!
    707c:	f9400b39 	ldr	x25, [x25, #16]
    7080:	f9400b5a 	ldr	x26, [x26, #16]
    7084:	eb14027f 	cmp	x19, x20
    7088:	54fffe81 	b.ne	7058 <f37+0x1b8>  // b.any
    708c:	aa1703e0 	mov	x0, x23
    7090:	97fffd20 	bl	6510 <fwp_drop4>
    7094:	aa1603e0 	mov	x0, x22
    7098:	97fffd1e 	bl	6510 <fwp_drop4>
    709c:	f9400316 	ldr	x22, [x24]
    70a0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    70a4:	b4000236 	cbz	x22, 70e8 <f37+0x248>
    70a8:	fd003be8 	str	d8, [sp, #112]
    70ac:	2f00e408 	movi	d8, #0x0
    70b0:	91002319 	add	x25, x24, #0x8
    70b4:	91004317 	add	x23, x24, #0x10
    70b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    70bc:	d2800013 	mov	x19, #0x0                   	// #0
    70c0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    70c4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    70c8:	91000a73 	add	x19, x19, #0x2
    70cc:	1e602908 	fadd	d8, d8, d0
    70d0:	97fff8c4 	bl	53e0 <f141.constprop.0>
    70d4:	aa0003f4 	mov	x20, x0
    70d8:	eb1302df 	cmp	x22, x19
    70dc:	54ffff28 	b.hi	70c0 <f37+0x220>  // b.pmore
    70e0:	9e660116 	fmov	x22, d8
    70e4:	fd403be8 	ldr	d8, [sp, #112]
    70e8:	911702b5 	add	x21, x21, #0x5c0
    70ec:	aa1803e0 	mov	x0, x24
    70f0:	97fffec4 	bl	6c00 <fwp_drop10>
    70f4:	a900d3f6 	stp	x22, x20, [sp, #8]
    70f8:	910023e1 	add	x1, sp, #0x8
    70fc:	52800000 	mov	w0, #0x0                   	// #0
    7100:	97fff7e1 	bl	5084 <fwp_data.part.0.constprop.0>
    7104:	f949daa1 	ldr	x1, [x21, #5040]
    7108:	aa0003f3 	mov	x19, x0
    710c:	f949eea0 	ldr	x0, [x21, #5080]
    7110:	cb010261 	sub	x1, x19, x1
    7114:	eb00403f 	cmp	x1, x0, lsl #16
    7118:	54000322 	b.cs	717c <f37+0x2dc>  // b.hs, b.nlast
    711c:	d350fc22 	lsr	x2, x1, #16
    7120:	f949fea3 	ldr	x3, [x21, #5112]
    7124:	8b020842 	add	x2, x2, x2, lsl #2
    7128:	d37df042 	lsl	x2, x2, #3
    712c:	8b020060 	add	x0, x3, x2
    7130:	f9401014 	ldr	x20, [x0, #32]
    7134:	b4000254 	cbz	x20, 717c <f37+0x2dc>
    7138:	38626862 	ldrb	w2, [x3, x2]
    713c:	7100085f 	cmp	w2, #0x2
    7140:	540004a0 	b.eq	71d4 <f37+0x334>  // b.none
    7144:	7100045f 	cmp	w2, #0x1
    7148:	540001a1 	b.ne	717c <f37+0x2dc>  // b.any
    714c:	29430002 	ldp	w2, w0, [x0, #24]
    7150:	92403c21 	and	x1, x1, #0xffff
    7154:	9b027c21 	mul	x1, x1, x2
    7158:	d360fc21 	lsr	x1, x1, #32
    715c:	eb00003f 	cmp	x1, x0
    7160:	540000e2 	b.cs	717c <f37+0x2dc>  // b.hs, b.nlast
    7164:	8b010294 	add	x20, x20, x1
    7168:	39400280 	ldrb	w0, [x20]
    716c:	7103fc1f 	cmp	w0, #0xff
    7170:	540007a0 	b.eq	7264 <f37+0x3c4>  // b.none
    7174:	52800020 	mov	w0, #0x1                   	// #1
    7178:	39000280 	strb	w0, [x20]
    717c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7180:	f947f400 	ldr	x0, [x0, #4072]
    7184:	f9400fe2 	ldr	x2, [sp, #24]
    7188:	f9400001 	ldr	x1, [x0]
    718c:	eb010042 	subs	x2, x2, x1
    7190:	d2800001 	mov	x1, #0x0                   	// #0
    7194:	54000721 	b.ne	7278 <f37+0x3d8>  // b.any
    7198:	a9427bfd 	ldp	x29, x30, [sp, #32]
    719c:	aa1303e0 	mov	x0, x19
    71a0:	a94353f3 	ldp	x19, x20, [sp, #48]
    71a4:	a9445bf5 	ldp	x21, x22, [sp, #64]
    71a8:	a94563f7 	ldp	x23, x24, [sp, #80]
    71ac:	a9466bf9 	ldp	x25, x26, [sp, #96]
    71b0:	910203ff 	add	sp, sp, #0x80
    71b4:	d65f03c0 	ret
    71b8:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    71bc:	91310000 	add	x0, x0, #0xc40
    71c0:	fd003be8 	str	d8, [sp, #112]
    71c4:	97fff3f3 	bl	4190 <fwp_trap>
    71c8:	72003c3f 	tst	w1, #0xffff
    71cc:	54ffec81 	b.ne	6f5c <f37+0xbc>  // b.any
    71d0:	17ffff5d 	b	6f44 <f37+0xa4>
    71d4:	72003c3f 	tst	w1, #0xffff
    71d8:	54fffd21 	b.ne	717c <f37+0x2dc>  // b.any
    71dc:	17ffffe3 	b	7168 <f37+0x2c8>
    71e0:	72003c3f 	tst	w1, #0xffff
    71e4:	54fff301 	b.ne	7044 <f37+0x1a4>  // b.any
    71e8:	17ffff92 	b	7030 <f37+0x190>
    71ec:	cb0103e1 	neg	x1, x1
    71f0:	eb02003f 	cmp	x1, x2
    71f4:	540001e3 	b.cc	7230 <f37+0x390>  // b.lo, b.ul, b.last
    71f8:	52800041 	mov	w1, #0x2                   	// #2
    71fc:	d2800100 	mov	x0, #0x8                   	// #8
    7200:	97fff75c 	bl	4f70 <fwp_heap_alloc>
    7204:	aa0003f8 	mov	x24, x0
    7208:	911702a0 	add	x0, x21, #0x5c0
    720c:	f900031f 	str	xzr, [x24]
    7210:	f949d801 	ldr	x1, [x0, #5040]
    7214:	f949ec00 	ldr	x0, [x0, #5080]
    7218:	cb010301 	sub	x1, x24, x1
    721c:	eb00403f 	cmp	x1, x0, lsl #16
    7220:	54000282 	b.cs	7270 <f37+0x3d0>  // b.hs, b.nlast
    7224:	d2800013 	mov	x19, #0x0                   	// #0
    7228:	d2800017 	mov	x23, #0x0                   	// #0
    722c:	17ffff6d 	b	6fe0 <f37+0x140>
    7230:	f949fc62 	ldr	x2, [x3, #5112]
    7234:	d350fc20 	lsr	x0, x1, #16
    7238:	8b000800 	add	x0, x0, x0, lsl #2
    723c:	8b000c42 	add	x2, x2, x0, lsl #3
    7240:	f9401040 	ldr	x0, [x2, #32]
    7244:	b4fffda0 	cbz	x0, 71f8 <f37+0x358>
    7248:	d2800017 	mov	x23, #0x0                   	// #0
    724c:	17ffff32 	b	6f14 <f37+0x74>
    7250:	97fff505 	bl	4664 <fwp_rc_wide_dup>
    7254:	17ffff42 	b	6f5c <f37+0xbc>
    7258:	aa1403e0 	mov	x0, x20
    725c:	97fff3ed 	bl	4210 <fwp_rc_forget_slot.part.0>
    7260:	17ffff77 	b	703c <f37+0x19c>
    7264:	aa1403e0 	mov	x0, x20
    7268:	97fff3ea 	bl	4210 <fwp_rc_forget_slot.part.0>
    726c:	17ffffc2 	b	7174 <f37+0x2d4>
    7270:	d2800017 	mov	x23, #0x0                   	// #0
    7274:	17ffff86 	b	708c <f37+0x1ec>
    7278:	fd003be8 	str	d8, [sp, #112]
    727c:	97ffeda5 	bl	2910 <__stack_chk_fail@plt>

0000000000007280 <fwp_owned_entry37>:
    7280:	f9400000 	ldr	x0, [x0]
    7284:	17ffff07 	b	6ea0 <f37>
    7288:	d503201f 	nop
    728c:	d503201f 	nop

0000000000007290 <e37>:
    7290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7294:	910003fd 	mov	x29, sp
    7298:	f9000bf3 	str	x19, [sp, #16]
    729c:	f9400013 	ldr	x19, [x0]
    72a0:	aa1303e0 	mov	x0, x19
    72a4:	97fff9b3 	bl	5970 <fwp_rc_share>
    72a8:	aa1303e0 	mov	x0, x19
    72ac:	97fffefd 	bl	6ea0 <f37>
    72b0:	aa0003f3 	mov	x19, x0
    72b4:	97fff9af 	bl	5970 <fwp_rc_share>
    72b8:	aa1303e0 	mov	x0, x19
    72bc:	f9400bf3 	ldr	x19, [sp, #16]
    72c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72c4:	d65f03c0 	ret
    72c8:	d503201f 	nop
    72cc:	d503201f 	nop

00000000000072d0 <fwp_args37>:
    72d0:	7100003f 	cmp	w1, #0x0
    72d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    72d8:	54000041 	b.ne	72e0 <fwp_args37+0x10>  // b.any
    72dc:	d65f03c0 	ret
    72e0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    72e4:	91170042 	add	x2, x2, #0x5c0
    72e8:	f9400001 	ldr	x1, [x0]
    72ec:	f949d843 	ldr	x3, [x2, #5040]
    72f0:	f949ec40 	ldr	x0, [x2, #5080]
    72f4:	cb030021 	sub	x1, x1, x3
    72f8:	eb00403f 	cmp	x1, x0, lsl #16
    72fc:	54ffff02 	b.cs	72dc <fwp_args37+0xc>  // b.hs, b.nlast
    7300:	d350fc20 	lsr	x0, x1, #16
    7304:	f949fc44 	ldr	x4, [x2, #5112]
    7308:	8b000800 	add	x0, x0, x0, lsl #2
    730c:	d37df002 	lsl	x2, x0, #3
    7310:	8b020083 	add	x3, x4, x2
    7314:	f9401060 	ldr	x0, [x3, #32]
    7318:	b4fffe20 	cbz	x0, 72dc <fwp_args37+0xc>
    731c:	38626882 	ldrb	w2, [x4, x2]
    7320:	7100085f 	cmp	w2, #0x2
    7324:	54000220 	b.eq	7368 <fwp_args37+0x98>  // b.none
    7328:	7100045f 	cmp	w2, #0x1
    732c:	54fffd81 	b.ne	72dc <fwp_args37+0xc>  // b.any
    7330:	29430864 	ldp	w4, w2, [x3, #24]
    7334:	92403c21 	and	x1, x1, #0xffff
    7338:	9b047c21 	mul	x1, x1, x4
    733c:	d360fc21 	lsr	x1, x1, #32
    7340:	eb02003f 	cmp	x1, x2
    7344:	54fffcc2 	b.cs	72dc <fwp_args37+0xc>  // b.hs, b.nlast
    7348:	8b010000 	add	x0, x0, x1
    734c:	39400001 	ldrb	w1, [x0]
    7350:	34fffc61 	cbz	w1, 72dc <fwp_args37+0xc>
    7354:	7103f43f 	cmp	w1, #0xfd
    7358:	540000e8 	b.hi	7374 <fwp_args37+0xa4>  // b.pmore
    735c:	11000421 	add	w1, w1, #0x1
    7360:	39000001 	strb	w1, [x0]
    7364:	d65f03c0 	ret
    7368:	72003c3f 	tst	w1, #0xffff
    736c:	54ffff00 	b.eq	734c <fwp_args37+0x7c>  // b.none
    7370:	d65f03c0 	ret
    7374:	17fff4bc 	b	4664 <fwp_rc_wide_dup>
    7378:	d503201f 	nop
    737c:	d503201f 	nop

0000000000007380 <fwp_caps37>:
    7380:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7384:	910003fd 	mov	x29, sp
    7388:	f9000bf3 	str	x19, [sp, #16]
    738c:	aa0003f3 	mov	x19, x0
    7390:	b9400400 	ldr	w0, [x0, #4]
    7394:	340004a0 	cbz	w0, 7428 <fwp_caps37+0xa8>
    7398:	f9400660 	ldr	x0, [x19, #8]
    739c:	350004e1 	cbnz	w1, 7438 <fwp_caps37+0xb8>
    73a0:	97fffc5c 	bl	6510 <fwp_drop4>
    73a4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    73a8:	91170042 	add	x2, x2, #0x5c0
    73ac:	f949d840 	ldr	x0, [x2, #5040]
    73b0:	f949ec41 	ldr	x1, [x2, #5080]
    73b4:	cb000260 	sub	x0, x19, x0
    73b8:	eb01401f 	cmp	x0, x1, lsl #16
    73bc:	54000382 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    73c0:	d350fc01 	lsr	x1, x0, #16
    73c4:	f949fc44 	ldr	x4, [x2, #5112]
    73c8:	8b010821 	add	x1, x1, x1, lsl #2
    73cc:	d37df021 	lsl	x1, x1, #3
    73d0:	8b010083 	add	x3, x4, x1
    73d4:	f9401062 	ldr	x2, [x3, #32]
    73d8:	b40002a2 	cbz	x2, 742c <fwp_caps37+0xac>
    73dc:	38616881 	ldrb	w1, [x4, x1]
    73e0:	7100083f 	cmp	w1, #0x2
    73e4:	540006c0 	b.eq	74bc <fwp_caps37+0x13c>  // b.none
    73e8:	7100043f 	cmp	w1, #0x1
    73ec:	54000201 	b.ne	742c <fwp_caps37+0xac>  // b.any
    73f0:	29430464 	ldp	w4, w1, [x3, #24]
    73f4:	92403c00 	and	x0, x0, #0xffff
    73f8:	9b047c00 	mul	x0, x0, x4
    73fc:	d360fc00 	lsr	x0, x0, #32
    7400:	eb01001f 	cmp	x0, x1
    7404:	54000142 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    7408:	8b000042 	add	x2, x2, x0
    740c:	39400040 	ldrb	w0, [x2]
    7410:	7100041f 	cmp	w0, #0x1
    7414:	540000c1 	b.ne	742c <fwp_caps37+0xac>  // b.any
    7418:	aa1303e0 	mov	x0, x19
    741c:	f9400bf3 	ldr	x19, [sp, #16]
    7420:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7424:	17fff417 	b	4480 <fwp_mem_free>
    7428:	34fffbe1 	cbz	w1, 73a4 <fwp_caps37+0x24>
    742c:	f9400bf3 	ldr	x19, [sp, #16]
    7430:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7434:	d65f03c0 	ret
    7438:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    743c:	91170042 	add	x2, x2, #0x5c0
    7440:	f949d843 	ldr	x3, [x2, #5040]
    7444:	f949ec41 	ldr	x1, [x2, #5080]
    7448:	cb030000 	sub	x0, x0, x3
    744c:	eb01401f 	cmp	x0, x1, lsl #16
    7450:	54fffee2 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    7454:	d350fc01 	lsr	x1, x0, #16
    7458:	f949fc44 	ldr	x4, [x2, #5112]
    745c:	8b010821 	add	x1, x1, x1, lsl #2
    7460:	d37df021 	lsl	x1, x1, #3
    7464:	8b010083 	add	x3, x4, x1
    7468:	f9401062 	ldr	x2, [x3, #32]
    746c:	b4fffe02 	cbz	x2, 742c <fwp_caps37+0xac>
    7470:	38616881 	ldrb	w1, [x4, x1]
    7474:	7100083f 	cmp	w1, #0x2
    7478:	54000280 	b.eq	74c8 <fwp_caps37+0x148>  // b.none
    747c:	7100043f 	cmp	w1, #0x1
    7480:	54fffd61 	b.ne	742c <fwp_caps37+0xac>  // b.any
    7484:	92403c01 	and	x1, x0, #0xffff
    7488:	29430064 	ldp	w4, w0, [x3, #24]
    748c:	9b047c21 	mul	x1, x1, x4
    7490:	d360fc21 	lsr	x1, x1, #32
    7494:	eb00003f 	cmp	x1, x0
    7498:	54fffca2 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    749c:	8b010042 	add	x2, x2, x1
    74a0:	39400040 	ldrb	w0, [x2]
    74a4:	34fffc40 	cbz	w0, 742c <fwp_caps37+0xac>
    74a8:	7103f41f 	cmp	w0, #0xfd
    74ac:	54000148 	b.hi	74d4 <fwp_caps37+0x154>  // b.pmore
    74b0:	11000400 	add	w0, w0, #0x1
    74b4:	39000040 	strb	w0, [x2]
    74b8:	17ffffdd 	b	742c <fwp_caps37+0xac>
    74bc:	72003c1f 	tst	w0, #0xffff
    74c0:	54fffb61 	b.ne	742c <fwp_caps37+0xac>  // b.any
    74c4:	17ffffd2 	b	740c <fwp_caps37+0x8c>
    74c8:	72003c1f 	tst	w0, #0xffff
    74cc:	54fffb01 	b.ne	742c <fwp_caps37+0xac>  // b.any
    74d0:	17fffff4 	b	74a0 <fwp_caps37+0x120>
    74d4:	f9400bf3 	ldr	x19, [sp, #16]
    74d8:	aa0203e0 	mov	x0, x2
    74dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74e0:	17fff461 	b	4664 <fwp_rc_wide_dup>

00000000000074e4 <fwp_write>:
    74e4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    74e8:	910003fd 	mov	x29, sp
    74ec:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    74f0:	f947f484 	ldr	x4, [x4, #4072]
    74f4:	a90153f3 	stp	x19, x20, [sp, #16]
    74f8:	d10943ff 	sub	sp, sp, #0x250
    74fc:	b9400045 	ldr	w5, [x2]
    7500:	aa0003f4 	mov	x20, x0
    7504:	f9400080 	ldr	x0, [x4]
    7508:	f90127e0 	str	x0, [sp, #584]
    750c:	d2800000 	mov	x0, #0x0                   	// #0
    7510:	710064bf 	cmp	w5, #0x19
    7514:	54000408 	b.hi	7594 <fwp_write+0xb0>  // b.pmore
    7518:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x860>
    751c:	aa0103f3 	mov	x19, x1
    7520:	91114000 	add	x0, x0, #0x450
    7524:	f9013bf5 	str	x21, [sp, #624]
    7528:	f9013ff6 	str	x22, [sp, #632]
    752c:	f90153fb 	str	x27, [sp, #672]
    7530:	f90157fc 	str	x28, [sp, #680]
    7534:	aa0203fc 	mov	x28, x2
    7538:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    753c:	10000061 	adr	x1, 7548 <fwp_write+0x64>
    7540:	8b20a820 	add	x0, x1, w0, sxth #2
    7544:	d61f0000 	br	x0
    7548:	910123e0 	add	x0, sp, #0x48
    754c:	aa1303e5 	mov	x5, x19
    7550:	d0000004 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    7554:	aa0003f3 	mov	x19, x0
    7558:	91322084 	add	x4, x4, #0xc88
    755c:	d2804003 	mov	x3, #0x200                 	// #512
    7560:	aa0303e1 	mov	x1, x3
    7564:	52800042 	mov	w2, #0x2                   	// #2
    7568:	97ffecc6 	bl	2880 <__snprintf_chk@plt>
    756c:	aa1303e0 	mov	x0, x19
    7570:	97ffec8c 	bl	27a0 <strlen@plt>
    7574:	aa1303e1 	mov	x1, x19
    7578:	aa0003e2 	mov	x2, x0
    757c:	aa1403e0 	mov	x0, x20
    7580:	97fff024 	bl	3610 <buf_put>
    7584:	f9413bf5 	ldr	x21, [sp, #624]
    7588:	f9413ff6 	ldr	x22, [sp, #632]
    758c:	f94153fb 	ldr	x27, [sp, #672]
    7590:	f94157fc 	ldr	x28, [sp, #680]
    7594:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7598:	f947f400 	ldr	x0, [x0, #4072]
    759c:	f94127e2 	ldr	x2, [sp, #584]
    75a0:	f9400001 	ldr	x1, [x0]
    75a4:	eb010042 	subs	x2, x2, x1
    75a8:	d2800001 	mov	x1, #0x0                   	// #0
    75ac:	540077a1 	b.ne	84a0 <fwp_write+0xfbc>  // b.any
    75b0:	910943ff 	add	sp, sp, #0x250
    75b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    75b8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    75bc:	d65f03c0 	ret
    75c0:	910123e0 	add	x0, sp, #0x48
    75c4:	aa1303e5 	mov	x5, x19
    75c8:	d0000004 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    75cc:	aa0003f3 	mov	x19, x0
    75d0:	91320084 	add	x4, x4, #0xc80
    75d4:	d2804003 	mov	x3, #0x200                 	// #512
    75d8:	17ffffe2 	b	7560 <fwp_write+0x7c>
    75dc:	71004cbf 	cmp	w5, #0x13
    75e0:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    75e4:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    75e8:	9131c000 	add	x0, x0, #0xc70
    75ec:	9131e021 	add	x1, x1, #0xc78
    75f0:	d2800082 	mov	x2, #0x4                   	// #4
    75f4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	f90143f7 	str	x23, [sp, #640]
    7600:	d2800016 	mov	x22, #0x0                   	// #0
    7604:	f90147f8 	str	x24, [sp, #648]
    7608:	97fff002 	bl	3610 <buf_put>
    760c:	f9400260 	ldr	x0, [x19]
    7610:	d0000017 	adrp	x23, 9000 <fwp_main_thread+0xb30>
    7614:	d2800015 	mov	x21, #0x0                   	// #0
    7618:	9133e2f7 	add	x23, x23, #0xcf8
    761c:	b4004780 	cbz	x0, 7f0c <fwp_write+0xa28>
    7620:	b9400380 	ldr	w0, [x28]
    7624:	52800003 	mov	w3, #0x0                   	// #0
    7628:	f9401f82 	ldr	x2, [x28, #56]
    762c:	71004c1f 	cmp	w0, #0x13
    7630:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7634:	aa1403e0 	mov	x0, x20
    7638:	8b010e61 	add	x1, x19, x1, lsl #3
    763c:	f9400421 	ldr	x1, [x1, #8]
    7640:	97ffffa9 	bl	74e4 <fwp_write>
    7644:	b9400380 	ldr	w0, [x28]
    7648:	7100481f 	cmp	w0, #0x12
    764c:	54004b20 	b.eq	7fb0 <fwp_write+0xacc>  // b.none
    7650:	f9400260 	ldr	x0, [x19]
    7654:	910006b5 	add	x21, x21, #0x1
    7658:	91000ad6 	add	x22, x22, #0x2
    765c:	eb15001f 	cmp	x0, x21
    7660:	54004569 	b.ls	7f0c <fwp_write+0xa28>  // b.plast
    7664:	aa1703e1 	mov	x1, x23
    7668:	aa1403e0 	mov	x0, x20
    766c:	d2800042 	mov	x2, #0x2                   	// #2
    7670:	97ffefe8 	bl	3610 <buf_put>
    7674:	17ffffeb 	b	7620 <fwp_write+0x13c>
    7678:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    767c:	9132c021 	add	x1, x1, #0xcb0
    7680:	d28000c2 	mov	x2, #0x6                   	// #6
    7684:	aa1403e0 	mov	x0, x20
    7688:	91004273 	add	x19, x19, #0x10
    768c:	97ffefe1 	bl	3610 <buf_put>
    7690:	aa1303e0 	mov	x0, x19
    7694:	97ffec43 	bl	27a0 <strlen@plt>
    7698:	aa1303e1 	mov	x1, x19
    769c:	aa0003e2 	mov	x2, x0
    76a0:	aa1403e0 	mov	x0, x20
    76a4:	97ffefdb 	bl	3610 <buf_put>
    76a8:	528007c3 	mov	w3, #0x3e                  	// #62
    76ac:	aa1403e0 	mov	x0, x20
    76b0:	91001fe1 	add	x1, sp, #0x7
    76b4:	d2800022 	mov	x2, #0x1                   	// #1
    76b8:	39001fe3 	strb	w3, [sp, #7]
    76bc:	17ffffb1 	b	7580 <fwp_write+0x9c>
    76c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76c4:	f947f400 	ldr	x0, [x0, #4072]
    76c8:	f94127e2 	ldr	x2, [sp, #584]
    76cc:	f9400001 	ldr	x1, [x0]
    76d0:	eb010042 	subs	x2, x2, x1
    76d4:	d2800001 	mov	x1, #0x0                   	// #0
    76d8:	540034c1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    76dc:	f9413bf5 	ldr	x21, [sp, #624]
    76e0:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    76e4:	f9413ff6 	ldr	x22, [sp, #632]
    76e8:	aa1403e0 	mov	x0, x20
    76ec:	91324021 	add	x1, x1, #0xc90
    76f0:	d2800142 	mov	x2, #0xa                   	// #10
    76f4:	f94153fb 	ldr	x27, [sp, #672]
    76f8:	f94157fc 	ldr	x28, [sp, #680]
    76fc:	910943ff 	add	sp, sp, #0x250
    7700:	a94153f3 	ldp	x19, x20, [sp, #16]
    7704:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7708:	17ffefc2 	b	3610 <buf_put>
    770c:	f9400456 	ldr	x22, [x2, #8]
    7710:	f90143f7 	str	x23, [sp, #640]
    7714:	f90147f8 	str	x24, [sp, #648]
    7718:	b4005af6 	cbz	x22, 8274 <fwp_write+0xd90>
    771c:	aa1603e0 	mov	x0, x22
    7720:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7724:	91344021 	add	x1, x1, #0xd10
    7728:	97ffec9a 	bl	2990 <strcmp@plt>
    772c:	2a0003f5 	mov	w21, w0
    7730:	34005fc0 	cbz	w0, 8328 <fwp_write+0xe44>
    7734:	aa1603e0 	mov	x0, x22
    7738:	97ffec1a 	bl	27a0 <strlen@plt>
    773c:	aa1603e1 	mov	x1, x22
    7740:	aa0003e2 	mov	x2, x0
    7744:	aa1403e0 	mov	x0, x20
    7748:	97ffefb2 	bl	3610 <buf_put>
    774c:	52800403 	mov	w3, #0x20                  	// #32
    7750:	91001ff5 	add	x21, sp, #0x7
    7754:	aa1503e1 	mov	x1, x21
    7758:	aa1403e0 	mov	x0, x20
    775c:	d2800022 	mov	x2, #0x1                   	// #1
    7760:	39001fe3 	strb	w3, [sp, #7]
    7764:	97ffefab 	bl	3610 <buf_put>
    7768:	52800f63 	mov	w3, #0x7b                  	// #123
    776c:	aa1403e0 	mov	x0, x20
    7770:	aa1503e1 	mov	x1, x21
    7774:	d2800022 	mov	x2, #0x1                   	// #1
    7778:	39001fe3 	strb	w3, [sp, #7]
    777c:	97ffefa5 	bl	3610 <buf_put>
    7780:	b9401380 	ldr	w0, [x28, #16]
    7784:	52800018 	mov	w24, #0x0                   	// #0
    7788:	7100001f 	cmp	w0, #0x0
    778c:	54003a8d 	b.le	7edc <fwp_write+0x9f8>
    7790:	f9014bf9 	str	x25, [sp, #656]
    7794:	d0000019 	adrp	x25, 9000 <fwp_main_thread+0xb30>
    7798:	9134e339 	add	x25, x25, #0xd38
    779c:	f9014ffa 	str	x26, [sp, #664]
    77a0:	d000001a 	adrp	x26, 9000 <fwp_main_thread+0xb30>
    77a4:	9133e35a 	add	x26, x26, #0xcf8
    77a8:	91002276 	add	x22, x19, #0x8
    77ac:	d2800013 	mov	x19, #0x0                   	// #0
    77b0:	b5003e73 	cbnz	x19, 7f7c <fwp_write+0xa98>
    77b4:	d37df277 	lsl	x23, x19, #3
    77b8:	34003c98 	cbz	w24, 7f48 <fwp_write+0xa64>
    77bc:	f9401382 	ldr	x2, [x28, #32]
    77c0:	aa1403e0 	mov	x0, x20
    77c4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    77c8:	52800003 	mov	w3, #0x0                   	// #0
    77cc:	f8776842 	ldr	x2, [x2, x23]
    77d0:	91000673 	add	x19, x19, #0x1
    77d4:	97ffff44 	bl	74e4 <fwp_write>
    77d8:	b9401380 	ldr	w0, [x28, #16]
    77dc:	6b13001f 	cmp	w0, w19
    77e0:	54fffe8c 	b.gt	77b0 <fwp_write+0x2cc>
    77e4:	f9414bf9 	ldr	x25, [sp, #656]
    77e8:	f9414ffa 	ldr	x26, [sp, #664]
    77ec:	34003798 	cbz	w24, 7edc <fwp_write+0x9f8>
    77f0:	52800523 	mov	w3, #0x29                  	// #41
    77f4:	aa1503e1 	mov	x1, x21
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	d2800022 	mov	x2, #0x1                   	// #1
    7800:	39001fe3 	strb	w3, [sp, #7]
    7804:	97ffef83 	bl	3610 <buf_put>
    7808:	f9413bf5 	ldr	x21, [sp, #624]
    780c:	f9413ff6 	ldr	x22, [sp, #632]
    7810:	f94143f7 	ldr	x23, [sp, #640]
    7814:	f94147f8 	ldr	x24, [sp, #648]
    7818:	f94153fb 	ldr	x27, [sp, #672]
    781c:	f94157fc 	ldr	x28, [sp, #680]
    7820:	17ffff5d 	b	7594 <fwp_write+0xb0>
    7824:	b9404855 	ldr	w21, [x2, #72]
    7828:	aa1403e0 	mov	x0, x20
    782c:	93407eb6 	sxtw	x22, w21
    7830:	91000ac1 	add	x1, x22, #0x2
    7834:	97ffef44 	bl	3544 <buf_grow>
    7838:	a9400281 	ldp	x1, x0, [x20]
    783c:	528e8603 	mov	w3, #0x7430                	// #29744
    7840:	78206823 	strh	w3, [x1, x0]
    7844:	8b000022 	add	x2, x1, x0
    7848:	710002bf 	cmp	w21, #0x0
    784c:	540036ad 	b.le	7f20 <fwp_write+0xa3c>
    7850:	110006a3 	add	w3, w21, #0x1
    7854:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7858:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    785c:	91000449 	add	x9, x2, #0x1
    7860:	8b23c043 	add	x3, x2, w3, sxtw
    7864:	f28aaac6 	movk	x6, #0x5556
    7868:	f2955568 	movk	x8, #0xaaab
    786c:	1400000d 	b	78a0 <fwp_write+0x3bc>
    7870:	d2800021 	mov	x1, #0x1                   	// #1
    7874:	528005a5 	mov	w5, #0x2d                  	// #45
    7878:	f100001f 	cmp	x0, #0x0
    787c:	9b467e60 	smulh	x0, x19, x6
    7880:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7884:	381ff465 	strb	w5, [x3], #-1
    7888:	cb040000 	sub	x0, x0, x4
    788c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7890:	cb020000 	sub	x0, x0, x2
    7894:	8b010013 	add	x19, x0, x1
    7898:	eb03013f 	cmp	x9, x3
    789c:	54003420 	b.eq	7f20 <fwp_write+0xa3c>  // b.none
    78a0:	9b467e60 	smulh	x0, x19, x6
    78a4:	937ffe64 	asr	x4, x19, #63
    78a8:	52800605 	mov	w5, #0x30                  	// #48
    78ac:	cb040000 	sub	x0, x0, x4
    78b0:	8b000400 	add	x0, x0, x0, lsl #1
    78b4:	cb000260 	sub	x0, x19, x0
    78b8:	91000c01 	add	x1, x0, #0x3
    78bc:	9bc87c22 	umulh	x2, x1, x8
    78c0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    78c4:	8b4204e2 	add	x2, x7, x2, lsr #1
    78c8:	eb020021 	subs	x1, x1, x2
    78cc:	54fffd60 	b.eq	7878 <fwp_write+0x394>  // b.none
    78d0:	f100043f 	cmp	x1, #0x1
    78d4:	54fffce1 	b.ne	7870 <fwp_write+0x38c>  // b.any
    78d8:	d2800001 	mov	x1, #0x0                   	// #0
    78dc:	52800565 	mov	w5, #0x2b                  	// #43
    78e0:	17ffffe6 	b	7878 <fwp_write+0x394>
    78e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    78e8:	f947f400 	ldr	x0, [x0, #4072]
    78ec:	f94127e2 	ldr	x2, [sp, #584]
    78f0:	f9400001 	ldr	x1, [x0]
    78f4:	eb010042 	subs	x2, x2, x1
    78f8:	d2800001 	mov	x1, #0x0                   	// #0
    78fc:	540023a1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    7900:	f9413bf5 	ldr	x21, [sp, #624]
    7904:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7908:	f9413ff6 	ldr	x22, [sp, #632]
    790c:	aa1403e0 	mov	x0, x20
    7910:	91328021 	add	x1, x1, #0xca0
    7914:	d2800102 	mov	x2, #0x8                   	// #8
    7918:	17ffff77 	b	76f4 <fwp_write+0x210>
    791c:	aa1403e0 	mov	x0, x20
    7920:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7924:	d28000c2 	mov	x2, #0x6                   	// #6
    7928:	91340021 	add	x1, x1, #0xd00
    792c:	97ffef39 	bl	3610 <buf_put>
    7930:	d2800015 	mov	x21, #0x0                   	// #0
    7934:	f9400263 	ldr	x3, [x19]
    7938:	f240f87f 	tst	x3, #0x7fffffffffffffff
    793c:	54002c40 	b.eq	7ec4 <fwp_write+0x9e0>  // b.none
    7940:	f9401f82 	ldr	x2, [x28, #56]
    7944:	f90143f7 	str	x23, [sp, #640]
    7948:	f90147f8 	str	x24, [sp, #648]
    794c:	d2800857 	mov	x23, #0x42                  	// #66
    7950:	f9014bf9 	str	x25, [sp, #656]
    7954:	d0000016 	adrp	x22, 9000 <fwp_main_thread+0xb30>
    7958:	f9014ffa 	str	x26, [sp, #664]
    795c:	9133e2d6 	add	x22, x22, #0xcf8
    7960:	d2800038 	mov	x24, #0x1                   	// #1
    7964:	f2a18017 	movk	x23, #0xc00, lsl #16
    7968:	d2809099 	mov	x25, #0x484                 	// #1156
    796c:	b4000482 	cbz	x2, 79fc <fwp_write+0x518>
    7970:	b9400040 	ldr	w0, [x2]
    7974:	7100701f 	cmp	w0, #0x1c
    7978:	540042a0 	b.eq	81cc <fwp_write+0xce8>  // b.none
    797c:	71006c1f 	cmp	w0, #0x1b
    7980:	540003e8 	b.hi	79fc <fwp_write+0x518>  // b.pmore
    7984:	9ac02301 	lsl	x1, x24, x0
    7988:	ea17003f 	tst	x1, x23
    798c:	54003681 	b.ne	805c <fwp_write+0xb78>  // b.any
    7990:	ea19003f 	tst	x1, x25
    7994:	54003501 	b.ne	8034 <fwp_write+0xb50>  // b.any
    7998:	d2800424 	mov	x4, #0x21                  	// #33
    799c:	ea04003f 	tst	x1, x4
    79a0:	540002e0 	b.eq	79fc <fwp_write+0x518>  // b.none
    79a4:	b7f849a3 	tbnz	x3, #63, 82d8 <fwp_write+0xdf4>
    79a8:	91002261 	add	x1, x19, #0x8
    79ac:	8b150021 	add	x1, x1, x21
    79b0:	39400021 	ldrb	w1, [x1]
    79b4:	7100001f 	cmp	w0, #0x0
    79b8:	93401c23 	sxtb	x3, w1
    79bc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    79c0:	aa1403e0 	mov	x0, x20
    79c4:	52800003 	mov	w3, #0x0                   	// #0
    79c8:	97fffec7 	bl	74e4 <fwp_write>
    79cc:	910006b5 	add	x21, x21, #0x1
    79d0:	f9400260 	ldr	x0, [x19]
    79d4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    79d8:	eb0002bf 	cmp	x21, x0
    79dc:	540026c2 	b.cs	7eb4 <fwp_write+0x9d0>  // b.hs, b.nlast
    79e0:	d2800042 	mov	x2, #0x2                   	// #2
    79e4:	aa1603e1 	mov	x1, x22
    79e8:	aa1403e0 	mov	x0, x20
    79ec:	97ffef09 	bl	3610 <buf_put>
    79f0:	f9401f82 	ldr	x2, [x28, #56]
    79f4:	f9400263 	ldr	x3, [x19]
    79f8:	b5fffbc2 	cbnz	x2, 7970 <fwp_write+0x48c>
    79fc:	d37df2a0 	lsl	x0, x21, #3
    7a00:	b7f83f03 	tbnz	x3, #63, 81e0 <fwp_write+0xcfc>
    7a04:	91002261 	add	x1, x19, #0x8
    7a08:	8b000020 	add	x0, x1, x0
    7a0c:	f9400001 	ldr	x1, [x0]
    7a10:	17ffffec 	b	79c0 <fwp_write+0x4dc>
    7a14:	a9400e62 	ldp	x2, x3, [x19]
    7a18:	b7f83ca3 	tbnz	x3, #63, 81ac <fwp_write+0xcc8>
    7a1c:	910123f5 	add	x21, sp, #0x48
    7a20:	aa1503e0 	mov	x0, x21
    7a24:	97ffed1f 	bl	2ea0 <fwp_fmt_u128>
    7a28:	aa1503e0 	mov	x0, x21
    7a2c:	97ffeb5d 	bl	27a0 <strlen@plt>
    7a30:	aa1503e1 	mov	x1, x21
    7a34:	aa0003e2 	mov	x2, x0
    7a38:	17fffed1 	b	757c <fwp_write+0x98>
    7a3c:	fd015be8 	str	d8, [sp, #688]
    7a40:	1e270268 	fmov	s8, w19
    7a44:	fd015fe9 	str	d9, [sp, #696]
    7a48:	1e282100 	fcmp	s8, s8
    7a4c:	54004d26 	b.vs	83f0 <fwp_write+0xf0c>
    7a50:	1e20c101 	fabs	s1, s8
    7a54:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7a58:	1e270000 	fmov	s0, w0
    7a5c:	1e202020 	fcmp	s1, s0
    7a60:	54002c0d 	b.le	7fe0 <fwp_write+0xafc>
    7a64:	1e202118 	fcmpe	s8, #0.0
    7a68:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0xb30>
    7a6c:	9121e042 	add	x2, x2, #0x878
    7a70:	910123f5 	add	x21, sp, #0x48
    7a74:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7a78:	91314021 	add	x1, x1, #0xc50
    7a7c:	aa1503e0 	mov	x0, x21
    7a80:	9a81c041 	csel	x1, x2, x1, gt
    7a84:	97ffebf3 	bl	2a50 <strcpy@plt>
    7a88:	aa1503e0 	mov	x0, x21
    7a8c:	97ffeb45 	bl	27a0 <strlen@plt>
    7a90:	aa1503e1 	mov	x1, x21
    7a94:	aa0003e2 	mov	x2, x0
    7a98:	aa1403e0 	mov	x0, x20
    7a9c:	97ffeedd 	bl	3610 <buf_put>
    7aa0:	f9413bf5 	ldr	x21, [sp, #624]
    7aa4:	f9413ff6 	ldr	x22, [sp, #632]
    7aa8:	f94153fb 	ldr	x27, [sp, #672]
    7aac:	f94157fc 	ldr	x28, [sp, #680]
    7ab0:	fd415be8 	ldr	d8, [sp, #688]
    7ab4:	fd415fe9 	ldr	d9, [sp, #696]
    7ab8:	17fffeb7 	b	7594 <fwp_write+0xb0>
    7abc:	f9400276 	ldr	x22, [x19]
    7ac0:	34002e03 	cbz	w3, 8080 <fwp_write+0xb9c>
    7ac4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ac8:	f947f400 	ldr	x0, [x0, #4072]
    7acc:	f94127e2 	ldr	x2, [sp, #584]
    7ad0:	f9400001 	ldr	x1, [x0]
    7ad4:	eb010042 	subs	x2, x2, x1
    7ad8:	d2800001 	mov	x1, #0x0                   	// #0
    7adc:	540014a1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    7ae0:	aa1603e2 	mov	x2, x22
    7ae4:	91002261 	add	x1, x19, #0x8
    7ae8:	f9413bf5 	ldr	x21, [sp, #624]
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	f9413ff6 	ldr	x22, [sp, #632]
    7af4:	17ffff00 	b	76f4 <fwp_write+0x210>
    7af8:	fd015be8 	str	d8, [sp, #688]
    7afc:	9e670268 	fmov	d8, x19
    7b00:	fd015fe9 	str	d9, [sp, #696]
    7b04:	1e682100 	fcmp	d8, d8
    7b08:	54004746 	b.vs	83f0 <fwp_write+0xf0c>
    7b0c:	1e60c101 	fabs	d1, d8
    7b10:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7b14:	9e670000 	fmov	d0, x0
    7b18:	910123f5 	add	x21, sp, #0x48
    7b1c:	52800033 	mov	w19, #0x1                   	// #1
    7b20:	1e602020 	fcmp	d1, d0
    7b24:	540001ad 	b.le	7b58 <fwp_write+0x674>
    7b28:	1e602118 	fcmpe	d8, #0.0
    7b2c:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0xb30>
    7b30:	9121e042 	add	x2, x2, #0x878
    7b34:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7b38:	91314021 	add	x1, x1, #0xc50
    7b3c:	aa1503e0 	mov	x0, x21
    7b40:	9a81c041 	csel	x1, x2, x1, gt
    7b44:	97ffebc3 	bl	2a50 <strcpy@plt>
    7b48:	17ffffd0 	b	7a88 <fwp_write+0x5a4>
    7b4c:	11000673 	add	w19, w19, #0x1
    7b50:	71004a7f 	cmp	w19, #0x12
    7b54:	54003860 	b.eq	8260 <fwp_write+0xd7c>  // b.none
    7b58:	1e604100 	fmov	d0, d8
    7b5c:	2a1303e1 	mov	w1, w19
    7b60:	aa1503e0 	mov	x0, x21
    7b64:	97ffef47 	bl	3880 <fwp_format_g.constprop.0>
    7b68:	aa1503e0 	mov	x0, x21
    7b6c:	d2800001 	mov	x1, #0x0                   	// #0
    7b70:	97ffeb20 	bl	27f0 <strtod@plt>
    7b74:	1e602100 	fcmp	d8, d0
    7b78:	54fffea1 	b.ne	7b4c <fwp_write+0x668>  // b.any
    7b7c:	aa1503e0 	mov	x0, x21
    7b80:	97ffef1d 	bl	37f4 <fwp_finish_float>
    7b84:	17ffffc1 	b	7a88 <fwp_write+0x5a4>
    7b88:	a9400e62 	ldp	x2, x3, [x19]
    7b8c:	910123f3 	add	x19, sp, #0x48
    7b90:	aa1303e0 	mov	x0, x19
    7b94:	97ffecc3 	bl	2ea0 <fwp_fmt_u128>
    7b98:	17fffe75 	b	756c <fwp_write+0x88>
    7b9c:	f90143f7 	str	x23, [sp, #640]
    7ba0:	f90147f8 	str	x24, [sp, #648]
    7ba4:	2a1303f8 	mov	w24, w19
    7ba8:	f9014bf9 	str	x25, [sp, #656]
    7bac:	f9014ffa 	str	x26, [sp, #664]
    7bb0:	f13ffe7f 	cmp	x19, #0xfff
    7bb4:	54000049 	b.ls	7bbc <fwp_write+0x6d8>  // b.plast
    7bb8:	b9400278 	ldr	w24, [x19]
    7bbc:	f9400f80 	ldr	x0, [x28, #24]
    7bc0:	2a1803f5 	mov	w21, w24
    7bc4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7bc8:	d37ef6b9 	lsl	x25, x21, #2
    7bcc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7bd0:	aa1603e0 	mov	x0, x22
    7bd4:	97ffeaf3 	bl	27a0 <strlen@plt>
    7bd8:	aa1603e1 	mov	x1, x22
    7bdc:	aa0003e2 	mov	x2, x0
    7be0:	aa1403e0 	mov	x0, x20
    7be4:	97ffee8b 	bl	3610 <buf_put>
    7be8:	f9401780 	ldr	x0, [x28, #40]
    7bec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7bf0:	7100001f 	cmp	w0, #0x0
    7bf4:	5400068d 	b.le	7cc4 <fwp_write+0x7e0>
    7bf8:	91002276 	add	x22, x19, #0x8
    7bfc:	91001ff5 	add	x21, sp, #0x7
    7c00:	d280001b 	mov	x27, #0x0                   	// #0
    7c04:	5280041a 	mov	w26, #0x20                  	// #32
    7c08:	f9401b80 	ldr	x0, [x28, #48]
    7c0c:	aa1503e1 	mov	x1, x21
    7c10:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7c14:	d2800022 	mov	x2, #0x1                   	// #1
    7c18:	f8786803 	ldr	x3, [x0, x24]
    7c1c:	aa1403e0 	mov	x0, x20
    7c20:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7c24:	39001ffa 	strb	w26, [sp, #7]
    7c28:	97ffee7a 	bl	3610 <buf_put>
    7c2c:	f13ffeff 	cmp	x23, #0xfff
    7c30:	b9400261 	ldr	w1, [x19]
    7c34:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7c38:	7100383f 	cmp	w1, #0xe
    7c3c:	54000160 	b.eq	7c68 <fwp_write+0x784>  // b.none
    7c40:	7100403f 	cmp	w1, #0x10
    7c44:	54001a60 	b.eq	7f90 <fwp_write+0xaac>  // b.none
    7c48:	7100283f 	cmp	w1, #0xa
    7c4c:	54002aa0 	b.eq	81a0 <fwp_write+0xcbc>  // b.none
    7c50:	540014ac 	b.gt	7ee4 <fwp_write+0xa00>
    7c54:	71000c3f 	cmp	w1, #0x3
    7c58:	540029ac 	b.gt	818c <fwp_write+0xca8>
    7c5c:	d37ffee0 	lsr	x0, x23, #63
    7c60:	37f814a1 	tbnz	w1, #31, 7ef4 <fwp_write+0xa10>
    7c64:	d503201f 	nop
    7c68:	34001460 	cbz	w0, 7ef4 <fwp_write+0xa10>
    7c6c:	52800503 	mov	w3, #0x28                  	// #40
    7c70:	aa1503e1 	mov	x1, x21
    7c74:	aa1403e0 	mov	x0, x20
    7c78:	d2800022 	mov	x2, #0x1                   	// #1
    7c7c:	39001fe3 	strb	w3, [sp, #7]
    7c80:	97ffee64 	bl	3610 <buf_put>
    7c84:	aa1303e2 	mov	x2, x19
    7c88:	aa1703e1 	mov	x1, x23
    7c8c:	aa1403e0 	mov	x0, x20
    7c90:	52800003 	mov	w3, #0x0                   	// #0
    7c94:	97fffe14 	bl	74e4 <fwp_write>
    7c98:	52800523 	mov	w3, #0x29                  	// #41
    7c9c:	aa1503e1 	mov	x1, x21
    7ca0:	aa1403e0 	mov	x0, x20
    7ca4:	d2800022 	mov	x2, #0x1                   	// #1
    7ca8:	39001fe3 	strb	w3, [sp, #7]
    7cac:	97ffee59 	bl	3610 <buf_put>
    7cb0:	f9401780 	ldr	x0, [x28, #40]
    7cb4:	9100077b 	add	x27, x27, #0x1
    7cb8:	b8796800 	ldr	w0, [x0, x25]
    7cbc:	6b1b001f 	cmp	w0, w27
    7cc0:	54fffa4c 	b.gt	7c08 <fwp_write+0x724>
    7cc4:	f9413bf5 	ldr	x21, [sp, #624]
    7cc8:	f9413ff6 	ldr	x22, [sp, #632]
    7ccc:	f94143f7 	ldr	x23, [sp, #640]
    7cd0:	f94147f8 	ldr	x24, [sp, #648]
    7cd4:	f9414bf9 	ldr	x25, [sp, #656]
    7cd8:	f9414ffa 	ldr	x26, [sp, #664]
    7cdc:	f94153fb 	ldr	x27, [sp, #672]
    7ce0:	f94157fc 	ldr	x28, [sp, #680]
    7ce4:	17fffe2c 	b	7594 <fwp_write+0xb0>
    7ce8:	52800783 	mov	w3, #0x3c                  	// #60
    7cec:	91001ff3 	add	x19, sp, #0x7
    7cf0:	aa1303e1 	mov	x1, x19
    7cf4:	d2800022 	mov	x2, #0x1                   	// #1
    7cf8:	aa1403e0 	mov	x0, x20
    7cfc:	39001fe3 	strb	w3, [sp, #7]
    7d00:	97ffee44 	bl	3610 <buf_put>
    7d04:	f9400795 	ldr	x21, [x28, #8]
    7d08:	aa1503e0 	mov	x0, x21
    7d0c:	97ffeaa5 	bl	27a0 <strlen@plt>
    7d10:	aa1503e1 	mov	x1, x21
    7d14:	aa0003e2 	mov	x2, x0
    7d18:	aa1403e0 	mov	x0, x20
    7d1c:	97ffee3d 	bl	3610 <buf_put>
    7d20:	528007c3 	mov	w3, #0x3e                  	// #62
    7d24:	aa1303e1 	mov	x1, x19
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	d2800022 	mov	x2, #0x1                   	// #1
    7d30:	39001fe3 	strb	w3, [sp, #7]
    7d34:	17fffe13 	b	7580 <fwp_write+0x9c>
    7d38:	f100067f 	cmp	x19, #0x1
    7d3c:	540025a0 	b.eq	81f0 <fwp_write+0xd0c>  // b.none
    7d40:	b100067f 	cmn	x19, #0x1
    7d44:	54002bc0 	b.eq	82bc <fwp_write+0xdd8>  // b.none
    7d48:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7d4c:	91316021 	add	x1, x1, #0xc58
    7d50:	d2800022 	mov	x2, #0x1                   	// #1
    7d54:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7d58:	f947f400 	ldr	x0, [x0, #4072]
    7d5c:	f94127e4 	ldr	x4, [sp, #584]
    7d60:	f9400003 	ldr	x3, [x0]
    7d64:	eb030084 	subs	x4, x4, x3
    7d68:	d2800003 	mov	x3, #0x0                   	// #0
    7d6c:	54ffebe0 	b.eq	7ae8 <fwp_write+0x604>  // b.none
    7d70:	f90143f7 	str	x23, [sp, #640]
    7d74:	f90147f8 	str	x24, [sp, #648]
    7d78:	f9014bf9 	str	x25, [sp, #656]
    7d7c:	f9014ffa 	str	x26, [sp, #664]
    7d80:	fd015be8 	str	d8, [sp, #688]
    7d84:	fd015fe9 	str	d9, [sp, #696]
    7d88:	97ffeae2 	bl	2910 <__stack_chk_fail@plt>
    7d8c:	52800b63 	mov	w3, #0x5b                  	// #91
    7d90:	91001ff5 	add	x21, sp, #0x7
    7d94:	aa1503e1 	mov	x1, x21
    7d98:	aa1403e0 	mov	x0, x20
    7d9c:	d2800022 	mov	x2, #0x1                   	// #1
    7da0:	d0000016 	adrp	x22, 9000 <fwp_main_thread+0xb30>
    7da4:	9133e2d6 	add	x22, x22, #0xcf8
    7da8:	39001fe3 	strb	w3, [sp, #7]
    7dac:	97ffee19 	bl	3610 <buf_put>
    7db0:	b4000273 	cbz	x19, 7dfc <fwp_write+0x918>
    7db4:	f9400661 	ldr	x1, [x19, #8]
    7db8:	aa1403e0 	mov	x0, x20
    7dbc:	f9401f82 	ldr	x2, [x28, #56]
    7dc0:	52800003 	mov	w3, #0x0                   	// #0
    7dc4:	97fffdc8 	bl	74e4 <fwp_write>
    7dc8:	f9400a73 	ldr	x19, [x19, #16]
    7dcc:	b4000193 	cbz	x19, 7dfc <fwp_write+0x918>
    7dd0:	aa1603e1 	mov	x1, x22
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	d2800042 	mov	x2, #0x2                   	// #2
    7ddc:	97ffee0d 	bl	3610 <buf_put>
    7de0:	f9400661 	ldr	x1, [x19, #8]
    7de4:	aa1403e0 	mov	x0, x20
    7de8:	f9401f82 	ldr	x2, [x28, #56]
    7dec:	52800003 	mov	w3, #0x0                   	// #0
    7df0:	97fffdbd 	bl	74e4 <fwp_write>
    7df4:	f9400a73 	ldr	x19, [x19, #16]
    7df8:	b5fffed3 	cbnz	x19, 7dd0 <fwp_write+0x8ec>
    7dfc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7e00:	aa1503e1 	mov	x1, x21
    7e04:	aa1403e0 	mov	x0, x20
    7e08:	d2800022 	mov	x2, #0x1                   	// #1
    7e0c:	39001fe3 	strb	w3, [sp, #7]
    7e10:	17fffddc 	b	7580 <fwp_write+0x9c>
    7e14:	aa1403e0 	mov	x0, x20
    7e18:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7e1c:	d28000c2 	mov	x2, #0x6                   	// #6
    7e20:	9133a021 	add	x1, x1, #0xce8
    7e24:	97ffedfb 	bl	3610 <buf_put>
    7e28:	f9400260 	ldr	x0, [x19]
    7e2c:	b40004c0 	cbz	x0, 7ec4 <fwp_write+0x9e0>
    7e30:	910123f5 	add	x21, sp, #0x48
    7e34:	91002276 	add	x22, x19, #0x8
    7e38:	f90143f7 	str	x23, [sp, #640]
    7e3c:	d2800017 	mov	x23, #0x0                   	// #0
    7e40:	f90147f8 	str	x24, [sp, #648]
    7e44:	d0000018 	adrp	x24, 9000 <fwp_main_thread+0xb30>
    7e48:	9133c318 	add	x24, x24, #0xcf0
    7e4c:	f9014bf9 	str	x25, [sp, #656]
    7e50:	d0000019 	adrp	x25, 9000 <fwp_main_thread+0xb30>
    7e54:	9133e339 	add	x25, x25, #0xcf8
    7e58:	f9014ffa 	str	x26, [sp, #664]
    7e5c:	14000005 	b	7e70 <fwp_write+0x98c>
    7e60:	aa1903e1 	mov	x1, x25
    7e64:	aa1403e0 	mov	x0, x20
    7e68:	d2800042 	mov	x2, #0x2                   	// #2
    7e6c:	97ffede9 	bl	3610 <buf_put>
    7e70:	38776ac5 	ldrb	w5, [x22, x23]
    7e74:	d2804003 	mov	x3, #0x200                 	// #512
    7e78:	aa1803e4 	mov	x4, x24
    7e7c:	aa0303e1 	mov	x1, x3
    7e80:	52800042 	mov	w2, #0x2                   	// #2
    7e84:	aa1503e0 	mov	x0, x21
    7e88:	910006f7 	add	x23, x23, #0x1
    7e8c:	97ffea7d 	bl	2880 <__snprintf_chk@plt>
    7e90:	aa1503e0 	mov	x0, x21
    7e94:	97ffea43 	bl	27a0 <strlen@plt>
    7e98:	aa1503e1 	mov	x1, x21
    7e9c:	aa0003e2 	mov	x2, x0
    7ea0:	aa1403e0 	mov	x0, x20
    7ea4:	97ffeddb 	bl	3610 <buf_put>
    7ea8:	f9400260 	ldr	x0, [x19]
    7eac:	eb17001f 	cmp	x0, x23
    7eb0:	54fffd88 	b.hi	7e60 <fwp_write+0x97c>  // b.pmore
    7eb4:	f94143f7 	ldr	x23, [sp, #640]
    7eb8:	f94147f8 	ldr	x24, [sp, #648]
    7ebc:	f9414bf9 	ldr	x25, [sp, #656]
    7ec0:	f9414ffa 	ldr	x26, [sp, #664]
    7ec4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ec8:	aa1403e0 	mov	x0, x20
    7ecc:	91001fe1 	add	x1, sp, #0x7
    7ed0:	d2800022 	mov	x2, #0x1                   	// #1
    7ed4:	39001fe3 	strb	w3, [sp, #7]
    7ed8:	17fffdaa 	b	7580 <fwp_write+0x9c>
    7edc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ee0:	17fffe45 	b	77f4 <fwp_write+0x310>
    7ee4:	f10002ff 	cmp	x23, #0x0
    7ee8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7eec:	71002c3f 	cmp	w1, #0xb
    7ef0:	54ffebc0 	b.eq	7c68 <fwp_write+0x784>  // b.none
    7ef4:	aa1303e2 	mov	x2, x19
    7ef8:	aa1703e1 	mov	x1, x23
    7efc:	aa1403e0 	mov	x0, x20
    7f00:	52800003 	mov	w3, #0x0                   	// #0
    7f04:	97fffd78 	bl	74e4 <fwp_write>
    7f08:	17ffff6a 	b	7cb0 <fwp_write+0x7cc>
    7f0c:	aa1403e0 	mov	x0, x20
    7f10:	91001fe1 	add	x1, sp, #0x7
    7f14:	52800fa3 	mov	w3, #0x7d                  	// #125
    7f18:	d2800022 	mov	x2, #0x1                   	// #1
    7f1c:	17fffe39 	b	7800 <fwp_write+0x31c>
    7f20:	a9400281 	ldp	x1, x0, [x20]
    7f24:	91000800 	add	x0, x0, #0x2
    7f28:	8b160000 	add	x0, x0, x22
    7f2c:	f9000680 	str	x0, [x20, #8]
    7f30:	3820683f 	strb	wzr, [x1, x0]
    7f34:	f9413bf5 	ldr	x21, [sp, #624]
    7f38:	f9413ff6 	ldr	x22, [sp, #632]
    7f3c:	f94153fb 	ldr	x27, [sp, #672]
    7f40:	f94157fc 	ldr	x28, [sp, #680]
    7f44:	17fffd94 	b	7594 <fwp_write+0xb0>
    7f48:	f9400f80 	ldr	x0, [x28, #24]
    7f4c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7f50:	aa1b03e0 	mov	x0, x27
    7f54:	97ffea13 	bl	27a0 <strlen@plt>
    7f58:	aa1b03e1 	mov	x1, x27
    7f5c:	aa0003e2 	mov	x2, x0
    7f60:	aa1403e0 	mov	x0, x20
    7f64:	97ffedab 	bl	3610 <buf_put>
    7f68:	aa1903e1 	mov	x1, x25
    7f6c:	aa1403e0 	mov	x0, x20
    7f70:	d2800062 	mov	x2, #0x3                   	// #3
    7f74:	97ffeda7 	bl	3610 <buf_put>
    7f78:	17fffe11 	b	77bc <fwp_write+0x2d8>
    7f7c:	aa1a03e1 	mov	x1, x26
    7f80:	aa1403e0 	mov	x0, x20
    7f84:	d2800042 	mov	x2, #0x2                   	// #2
    7f88:	97ffeda2 	bl	3610 <buf_put>
    7f8c:	17fffe0a 	b	77b4 <fwp_write+0x2d0>
    7f90:	f9400660 	ldr	x0, [x19, #8]
    7f94:	b4fffb00 	cbz	x0, 7ef4 <fwp_write+0xa10>
    7f98:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7f9c:	91344021 	add	x1, x1, #0xd10
    7fa0:	97ffea7c 	bl	2990 <strcmp@plt>
    7fa4:	7100001f 	cmp	w0, #0x0
    7fa8:	1a9f07e0 	cset	w0, ne	// ne = any
    7fac:	17ffff2f 	b	7c68 <fwp_write+0x784>
    7fb0:	aa1403e0 	mov	x0, x20
    7fb4:	d2800042 	mov	x2, #0x2                   	// #2
    7fb8:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    7fbc:	91342021 	add	x1, x1, #0xd08
    7fc0:	97ffed94 	bl	3610 <buf_put>
    7fc4:	91004261 	add	x1, x19, #0x10
    7fc8:	aa1403e0 	mov	x0, x20
    7fcc:	f9402382 	ldr	x2, [x28, #64]
    7fd0:	52800003 	mov	w3, #0x0                   	// #0
    7fd4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7fd8:	97fffd43 	bl	74e4 <fwp_write>
    7fdc:	17fffd9d 	b	7650 <fwp_write+0x16c>
    7fe0:	1e22c109 	fcvt	d9, s8
    7fe4:	910123f5 	add	x21, sp, #0x48
    7fe8:	52800033 	mov	w19, #0x1                   	// #1
    7fec:	d503201f 	nop
    7ff0:	1e604120 	fmov	d0, d9
    7ff4:	2a1303e1 	mov	w1, w19
    7ff8:	aa1503e0 	mov	x0, x21
    7ffc:	97ffee21 	bl	3880 <fwp_format_g.constprop.0>
    8000:	aa1503e0 	mov	x0, x21
    8004:	d2800001 	mov	x1, #0x0                   	// #0
    8008:	97ffea6e 	bl	29c0 <strtof@plt>
    800c:	1e202100 	fcmp	s8, s0
    8010:	54ffdb60 	b.eq	7b7c <fwp_write+0x698>  // b.none
    8014:	11000673 	add	w19, w19, #0x1
    8018:	71002a7f 	cmp	w19, #0xa
    801c:	54fffea1 	b.ne	7ff0 <fwp_write+0xb0c>  // b.any
    8020:	1e604120 	fmov	d0, d9
    8024:	aa1503e0 	mov	x0, x21
    8028:	52800121 	mov	w1, #0x9                   	// #9
    802c:	97ffee15 	bl	3880 <fwp_format_g.constprop.0>
    8030:	17fffed3 	b	7b7c <fwp_write+0x698>
    8034:	d37ef6a1 	lsl	x1, x21, #2
    8038:	b7f81563 	tbnz	x3, #63, 82e4 <fwp_write+0xe00>
    803c:	91002263 	add	x3, x19, #0x8
    8040:	8b010061 	add	x1, x3, x1
    8044:	b9400023 	ldr	w3, [x1]
    8048:	7100081f 	cmp	w0, #0x2
    804c:	2a0303e1 	mov	w1, w3
    8050:	93407c63 	sxtw	x3, w3
    8054:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8058:	17fffe5a 	b	79c0 <fwp_write+0x4dc>
    805c:	d37ffaa1 	lsl	x1, x21, #1
    8060:	b7f81363 	tbnz	x3, #63, 82cc <fwp_write+0xde8>
    8064:	91002263 	add	x3, x19, #0x8
    8068:	8b010061 	add	x1, x3, x1
    806c:	79400021 	ldrh	w1, [x1]
    8070:	7100041f 	cmp	w0, #0x1
    8074:	93403c23 	sxth	x3, w1
    8078:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    807c:	17fffe51 	b	79c0 <fwp_write+0x4dc>
    8080:	52800443 	mov	w3, #0x22                  	// #34
    8084:	91001ff5 	add	x21, sp, #0x7
    8088:	91002273 	add	x19, x19, #0x8
    808c:	aa1503e1 	mov	x1, x21
    8090:	aa1403e0 	mov	x0, x20
    8094:	d2800022 	mov	x2, #0x1                   	// #1
    8098:	39001fe3 	strb	w3, [sp, #7]
    809c:	f90143f7 	str	x23, [sp, #640]
    80a0:	8b160277 	add	x23, x19, x22
    80a4:	f90147f8 	str	x24, [sp, #648]
    80a8:	97ffed5a 	bl	3610 <buf_put>
    80ac:	b4000696 	cbz	x22, 817c <fwp_write+0xc98>
    80b0:	b0000018 	adrp	x24, 9000 <fwp_main_thread+0xb30>
    80b4:	9132e318 	add	x24, x24, #0xcb8
    80b8:	f9014bf9 	str	x25, [sp, #656]
    80bc:	b0000019 	adrp	x25, 9000 <fwp_main_thread+0xb30>
    80c0:	91336339 	add	x25, x25, #0xcd8
    80c4:	f9014ffa 	str	x26, [sp, #664]
    80c8:	1400000d 	b	80fc <fwp_write+0xc18>
    80cc:	710024bf 	cmp	w5, #0x9
    80d0:	54000460 	b.eq	815c <fwp_write+0xc78>  // b.none
    80d4:	710028bf 	cmp	w5, #0xa
    80d8:	54000a61 	b.ne	8224 <fwp_write+0xd40>  // b.any
    80dc:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	91332021 	add	x1, x1, #0xcc8
    80e8:	d2800042 	mov	x2, #0x2                   	// #2
    80ec:	97ffed49 	bl	3610 <buf_put>
    80f0:	91000673 	add	x19, x19, #0x1
    80f4:	eb17027f 	cmp	x19, x23
    80f8:	540003e0 	b.eq	8174 <fwp_write+0xc90>  // b.none
    80fc:	39400265 	ldrb	w5, [x19]
    8100:	710034bf 	cmp	w5, #0xd
    8104:	54000180 	b.eq	8134 <fwp_write+0xc50>  // b.none
    8108:	54fffe29 	b.ls	80cc <fwp_write+0xbe8>  // b.plast
    810c:	710088bf 	cmp	w5, #0x22
    8110:	540001c0 	b.eq	8148 <fwp_write+0xc64>  // b.none
    8114:	710170bf 	cmp	w5, #0x5c
    8118:	54000741 	b.ne	8200 <fwp_write+0xd1c>  // b.any
    811c:	aa1403e0 	mov	x0, x20
    8120:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    8124:	d2800042 	mov	x2, #0x2                   	// #2
    8128:	91330021 	add	x1, x1, #0xcc0
    812c:	97ffed39 	bl	3610 <buf_put>
    8130:	17fffff0 	b	80f0 <fwp_write+0xc0c>
    8134:	aa1903e1 	mov	x1, x25
    8138:	aa1403e0 	mov	x0, x20
    813c:	d2800042 	mov	x2, #0x2                   	// #2
    8140:	97ffed34 	bl	3610 <buf_put>
    8144:	17ffffeb 	b	80f0 <fwp_write+0xc0c>
    8148:	aa1803e1 	mov	x1, x24
    814c:	aa1403e0 	mov	x0, x20
    8150:	d2800042 	mov	x2, #0x2                   	// #2
    8154:	97ffed2f 	bl	3610 <buf_put>
    8158:	17ffffe6 	b	80f0 <fwp_write+0xc0c>
    815c:	aa1403e0 	mov	x0, x20
    8160:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    8164:	d2800042 	mov	x2, #0x2                   	// #2
    8168:	91334021 	add	x1, x1, #0xcd0
    816c:	97ffed29 	bl	3610 <buf_put>
    8170:	17ffffe0 	b	80f0 <fwp_write+0xc0c>
    8174:	f9414bf9 	ldr	x25, [sp, #656]
    8178:	f9414ffa 	ldr	x26, [sp, #664]
    817c:	aa1503e1 	mov	x1, x21
    8180:	aa1403e0 	mov	x0, x20
    8184:	52800443 	mov	w3, #0x22                  	// #34
    8188:	17fffd9d 	b	77fc <fwp_write+0x318>
    818c:	7100103f 	cmp	w1, #0x4
    8190:	54ffeb21 	b.ne	7ef4 <fwp_write+0xa10>  // b.any
    8194:	f94006e0 	ldr	x0, [x23, #8]
    8198:	d37ffc00 	lsr	x0, x0, #63
    819c:	17fffeb3 	b	7c68 <fwp_write+0x784>
    81a0:	710002ff 	cmp	w23, #0x0
    81a4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    81a8:	17fffeb0 	b	7c68 <fwp_write+0x784>
    81ac:	528005a1 	mov	w1, #0x2d                  	// #45
    81b0:	eb0203e2 	negs	x2, x2
    81b4:	da0303e3 	ngc	x3, x3
    81b8:	910127e0 	add	x0, sp, #0x49
    81bc:	910123f5 	add	x21, sp, #0x48
    81c0:	390123e1 	strb	w1, [sp, #72]
    81c4:	97ffeb37 	bl	2ea0 <fwp_fmt_u128>
    81c8:	17fffe18 	b	7a28 <fwp_write+0x544>
    81cc:	d37ceea1 	lsl	x1, x21, #4
    81d0:	b7f810a3 	tbnz	x3, #63, 83e4 <fwp_write+0xf00>
    81d4:	91002260 	add	x0, x19, #0x8
    81d8:	8b010001 	add	x1, x0, x1
    81dc:	17fffdf9 	b	79c0 <fwp_write+0x4dc>
    81e0:	f9400a61 	ldr	x1, [x19, #16]
    81e4:	8b010000 	add	x0, x0, x1
    81e8:	f9400001 	ldr	x1, [x0]
    81ec:	17fffdf5 	b	79c0 <fwp_write+0x4dc>
    81f0:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    81f4:	d2800042 	mov	x2, #0x2                   	// #2
    81f8:	91318021 	add	x1, x1, #0xc60
    81fc:	17fffed6 	b	7d54 <fwp_write+0x870>
    8200:	7101fcbf 	cmp	w5, #0x7f
    8204:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8208:	540000e9 	b.ls	8224 <fwp_write+0xd40>  // b.plast
    820c:	aa1503e1 	mov	x1, x21
    8210:	aa1403e0 	mov	x0, x20
    8214:	d2800022 	mov	x2, #0x1                   	// #1
    8218:	39001fe5 	strb	w5, [sp, #7]
    821c:	97ffecfd 	bl	3610 <buf_put>
    8220:	17ffffb4 	b	80f0 <fwp_write+0xc0c>
    8224:	d2800203 	mov	x3, #0x10                  	// #16
    8228:	b0000004 	adrp	x4, 9000 <fwp_main_thread+0xb30>
    822c:	aa0303e1 	mov	x1, x3
    8230:	91338084 	add	x4, x4, #0xce0
    8234:	910123f6 	add	x22, sp, #0x48
    8238:	52800042 	mov	w2, #0x2                   	// #2
    823c:	aa1603e0 	mov	x0, x22
    8240:	97ffe990 	bl	2880 <__snprintf_chk@plt>
    8244:	aa1603e0 	mov	x0, x22
    8248:	97ffe956 	bl	27a0 <strlen@plt>
    824c:	aa1603e1 	mov	x1, x22
    8250:	aa0003e2 	mov	x2, x0
    8254:	aa1403e0 	mov	x0, x20
    8258:	97ffecee 	bl	3610 <buf_put>
    825c:	17ffffa5 	b	80f0 <fwp_write+0xc0c>
    8260:	1e604100 	fmov	d0, d8
    8264:	aa1503e0 	mov	x0, x21
    8268:	52800221 	mov	w1, #0x11                  	// #17
    826c:	97ffed85 	bl	3880 <fwp_format_g.constprop.0>
    8270:	17fffe43 	b	7b7c <fwp_write+0x698>
    8274:	b9401040 	ldr	w0, [x2, #16]
    8278:	350003c0 	cbnz	w0, 82f0 <fwp_write+0xe0c>
    827c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8280:	f947f400 	ldr	x0, [x0, #4072]
    8284:	f94127e2 	ldr	x2, [sp, #584]
    8288:	f9400001 	ldr	x1, [x0]
    828c:	eb010042 	subs	x2, x2, x1
    8290:	d2800001 	mov	x1, #0x0                   	// #0
    8294:	54ffd721 	b.ne	7d78 <fwp_write+0x894>  // b.any
    8298:	f9413bf5 	ldr	x21, [sp, #624]
    829c:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    82a0:	f9413ff6 	ldr	x22, [sp, #632]
    82a4:	aa1403e0 	mov	x0, x20
    82a8:	f94143f7 	ldr	x23, [sp, #640]
    82ac:	9134c021 	add	x1, x1, #0xd30
    82b0:	f94147f8 	ldr	x24, [sp, #648]
    82b4:	d2800042 	mov	x2, #0x2                   	// #2
    82b8:	17fffd0f 	b	76f4 <fwp_write+0x210>
    82bc:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xb30>
    82c0:	d2800042 	mov	x2, #0x2                   	// #2
    82c4:	9131a021 	add	x1, x1, #0xc68
    82c8:	17fffea3 	b	7d54 <fwp_write+0x870>
    82cc:	f9400a63 	ldr	x3, [x19, #16]
    82d0:	8b030021 	add	x1, x1, x3
    82d4:	17ffff66 	b	806c <fwp_write+0xb88>
    82d8:	f9400a61 	ldr	x1, [x19, #16]
    82dc:	8b0102a1 	add	x1, x21, x1
    82e0:	17fffdb4 	b	79b0 <fwp_write+0x4cc>
    82e4:	f9400a63 	ldr	x3, [x19, #16]
    82e8:	8b030021 	add	x1, x1, x3
    82ec:	17ffff56 	b	8044 <fwp_write+0xb60>
    82f0:	b9404840 	ldr	w0, [x2, #72]
    82f4:	91001ff5 	add	x21, sp, #0x7
    82f8:	34ffa380 	cbz	w0, 7768 <fwp_write+0x284>
    82fc:	52800503 	mov	w3, #0x28                  	// #40
    8300:	aa1403e0 	mov	x0, x20
    8304:	aa1503e1 	mov	x1, x21
    8308:	d2800022 	mov	x2, #0x1                   	// #1
    830c:	39001fe3 	strb	w3, [sp, #7]
    8310:	97ffecc0 	bl	3610 <buf_put>
    8314:	b9401380 	ldr	w0, [x28, #16]
    8318:	52800038 	mov	w24, #0x1                   	// #1
    831c:	7100001f 	cmp	w0, #0x0
    8320:	54ffa38c 	b.gt	7790 <fwp_write+0x2ac>
    8324:	17fffd33 	b	77f0 <fwp_write+0x30c>
    8328:	f9014bf9 	str	x25, [sp, #656]
    832c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12820>
    8330:	f9014ffa 	str	x26, [sp, #664]
    8334:	f9400676 	ldr	x22, [x19, #8]
    8338:	910aa333 	add	x19, x25, #0x2a8
    833c:	91002273 	add	x19, x19, #0x8
    8340:	937ffed8 	asr	x24, x22, #63
    8344:	aa1802c0 	orr	x0, x22, x24
    8348:	b5000320 	cbnz	x0, 83ac <fwp_write+0xec8>
    834c:	110006b5 	add	w21, w21, #0x1
    8350:	710016bf 	cmp	w21, #0x5
    8354:	54ffffc1 	b.ne	834c <fwp_write+0xe68>  // b.any
    8358:	b7f80578 	tbnz	x24, #63, 8404 <fwp_write+0xf20>
    835c:	910023f3 	add	x19, sp, #0x8
    8360:	aa1603e2 	mov	x2, x22
    8364:	aa1303e0 	mov	x0, x19
    8368:	d2800003 	mov	x3, #0x0                   	// #0
    836c:	97ffeacd 	bl	2ea0 <fwp_fmt_u128>
    8370:	910123f5 	add	x21, sp, #0x48
    8374:	b0000003 	adrp	x3, 9000 <fwp_main_thread+0xb30>
    8378:	aa1303e4 	mov	x4, x19
    837c:	aa1503e0 	mov	x0, x21
    8380:	9134a063 	add	x3, x3, #0xd28
    8384:	d2804002 	mov	x2, #0x200                 	// #512
    8388:	52800041 	mov	w1, #0x2                   	// #2
    838c:	97ffe909 	bl	27b0 <__sprintf_chk@plt>
    8390:	aa1503e0 	mov	x0, x21
    8394:	97ffe903 	bl	27a0 <strlen@plt>
    8398:	aa1503e1 	mov	x1, x21
    839c:	aa0003e2 	mov	x2, x0
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	97ffec9b 	bl	3610 <buf_put>
    83a8:	17fffe47 	b	7cc4 <fwp_write+0x7e0>
    83ac:	f9400277 	ldr	x23, [x19]
    83b0:	aa1603e0 	mov	x0, x22
    83b4:	aa1803e1 	mov	x1, x24
    83b8:	aa1703e2 	mov	x2, x23
    83bc:	937ffefa 	asr	x26, x23, #63
    83c0:	aa1a03e3 	mov	x3, x26
    83c4:	9400040f 	bl	9400 <__modti3>
    83c8:	aa010000 	orr	x0, x0, x1
    83cc:	b40002c0 	cbz	x0, 8424 <fwp_write+0xf40>
    83d0:	110006b5 	add	w21, w21, #0x1
    83d4:	91004273 	add	x19, x19, #0x10
    83d8:	710016bf 	cmp	w21, #0x5
    83dc:	54fffe81 	b.ne	83ac <fwp_write+0xec8>  // b.any
    83e0:	17ffffde 	b	8358 <fwp_write+0xe74>
    83e4:	f9400a60 	ldr	x0, [x19, #16]
    83e8:	8b000021 	add	x1, x1, x0
    83ec:	17fffd75 	b	79c0 <fwp_write+0x4dc>
    83f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    83f4:	910123f5 	add	x21, sp, #0x48
    83f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    83fc:	b9004be0 	str	w0, [sp, #72]
    8400:	17fffda2 	b	7a88 <fwp_write+0x5a4>
    8404:	528005a1 	mov	w1, #0x2d                  	// #45
    8408:	eb1603e2 	negs	x2, x22
    840c:	da1803e3 	ngc	x3, x24
    8410:	910027e0 	add	x0, sp, #0x9
    8414:	910023f3 	add	x19, sp, #0x8
    8418:	390023e1 	strb	w1, [sp, #8]
    841c:	97ffeaa1 	bl	2ea0 <fwp_fmt_u128>
    8420:	17ffffd4 	b	8370 <fwp_write+0xe8c>
    8424:	aa1703e2 	mov	x2, x23
    8428:	aa1a03e3 	mov	x3, x26
    842c:	aa1603e0 	mov	x0, x22
    8430:	aa1803e1 	mov	x1, x24
    8434:	94000313 	bl	9080 <__divti3>
    8438:	aa0003e2 	mov	x2, x0
    843c:	aa0103e3 	mov	x3, x1
    8440:	b7f80201 	tbnz	x1, #63, 8480 <fwp_write+0xf9c>
    8444:	910023f3 	add	x19, sp, #0x8
    8448:	aa1303e0 	mov	x0, x19
    844c:	97ffea95 	bl	2ea0 <fwp_fmt_u128>
    8450:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8454:	910aa339 	add	x25, x25, #0x2a8
    8458:	910123f5 	add	x21, sp, #0x48
    845c:	aa1303e4 	mov	x4, x19
    8460:	aa1503e0 	mov	x0, x21
    8464:	b0000003 	adrp	x3, 9000 <fwp_main_thread+0xb30>
    8468:	f8616b25 	ldr	x5, [x25, x1]
    846c:	91348063 	add	x3, x3, #0xd20
    8470:	d2804002 	mov	x2, #0x200                 	// #512
    8474:	52800041 	mov	w1, #0x2                   	// #2
    8478:	97ffe8ce 	bl	27b0 <__sprintf_chk@plt>
    847c:	17ffffc5 	b	8390 <fwp_write+0xeac>
    8480:	528005a4 	mov	w4, #0x2d                  	// #45
    8484:	eb0003e2 	negs	x2, x0
    8488:	da0103e3 	ngc	x3, x1
    848c:	910027e0 	add	x0, sp, #0x9
    8490:	910023f3 	add	x19, sp, #0x8
    8494:	390023e4 	strb	w4, [sp, #8]
    8498:	97ffea82 	bl	2ea0 <fwp_fmt_u128>
    849c:	17ffffed 	b	8450 <fwp_write+0xf6c>
    84a0:	f9013bf5 	str	x21, [sp, #624]
    84a4:	f9013ff6 	str	x22, [sp, #632]
    84a8:	f90143f7 	str	x23, [sp, #640]
    84ac:	f90147f8 	str	x24, [sp, #648]
    84b0:	f9014bf9 	str	x25, [sp, #656]
    84b4:	f9014ffa 	str	x26, [sp, #664]
    84b8:	f90153fb 	str	x27, [sp, #672]
    84bc:	f90157fc 	str	x28, [sp, #680]
    84c0:	fd015be8 	str	d8, [sp, #688]
    84c4:	fd015fe9 	str	d9, [sp, #696]
    84c8:	97ffe912 	bl	2910 <__stack_chk_fail@plt>
    84cc:	d503201f 	nop

00000000000084d0 <fwp_main_thread>:
    84d0:	d105c3ff 	sub	sp, sp, #0x170
    84d4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    84d8:	f947f400 	ldr	x0, [x0, #4072]
    84dc:	a9117bfd 	stp	x29, x30, [sp, #272]
    84e0:	910443fd 	add	x29, sp, #0x110
    84e4:	a91253f3 	stp	x19, x20, [sp, #288]
    84e8:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    84ec:	91170261 	add	x1, x19, #0x5c0
    84f0:	a9135bf5 	stp	x21, x22, [sp, #304]
    84f4:	a91463f7 	stp	x23, x24, [sp, #320]
    84f8:	b953a421 	ldr	w1, [x1, #5028]
    84fc:	f9400002 	ldr	x2, [x0]
    8500:	f90087e2 	str	x2, [sp, #264]
    8504:	d2800002 	mov	x2, #0x0                   	// #0
    8508:	34000e81 	cbz	w1, 86d8 <fwp_main_thread+0x208>
    850c:	91170260 	add	x0, x19, #0x5c0
    8510:	b953a800 	ldr	w0, [x0, #5032]
    8514:	35000da0 	cbnz	w0, 86c8 <fwp_main_thread+0x1f8>
    8518:	900000d5 	adrp	x21, 20000 <__data_start>
    851c:	900000c2 	adrp	x2, 20000 <__data_start>
    8520:	910182b4 	add	x20, x21, #0x60
    8524:	910f8042 	add	x2, x2, #0x3e0
    8528:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    852c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8530:	9100c3f7 	add	x23, sp, #0x30
    8534:	910063f6 	add	x22, sp, #0x18
    8538:	aa1703e0 	mov	x0, x23
    853c:	d2800001 	mov	x1, #0x0                   	// #0
    8540:	a9018e96 	stp	x22, x3, [x20, #24]
    8544:	f9001be2 	str	x2, [sp, #48]
    8548:	b9003bff 	str	wzr, [sp, #56]
    854c:	f90023e4 	str	x4, [sp, #64]
    8550:	97ffe888 	bl	2770 <sigaltstack@plt>
    8554:	35000220 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    8558:	4f000400 	movi	v0.4s, #0x0
    855c:	9101e3e0 	add	x0, sp, #0x78
    8560:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8564:	9103c021 	add	x1, x1, #0xf0
    8568:	f9003be1 	str	x1, [sp, #112]
    856c:	52800082 	mov	w2, #0x4                   	// #4
    8570:	72a10002 	movk	w2, #0x800, lsl #16
    8574:	9101c3f8 	add	x24, sp, #0x70
    8578:	3d802000 	str	q0, [x0, #128]
    857c:	b900fbe2 	str	w2, [sp, #248]
    8580:	ad000000 	stp	q0, q0, [x0]
    8584:	ad010000 	stp	q0, q0, [x0, #32]
    8588:	ad020000 	stp	q0, q0, [x0, #64]
    858c:	ad030000 	stp	q0, q0, [x0, #96]
    8590:	97ffe8d0 	bl	28d0 <sigemptyset@plt>
    8594:	340000c0 	cbz	w0, 85ac <fwp_main_thread+0xdc>
    8598:	b0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    859c:	91350000 	add	x0, x0, #0xd40
    85a0:	a9156bf9 	stp	x25, x26, [sp, #336]
    85a4:	a91673fb 	stp	x27, x28, [sp, #352]
    85a8:	97ffeefa 	bl	4190 <fwp_trap>
    85ac:	aa1803e1 	mov	x1, x24
    85b0:	d2800002 	mov	x2, #0x0                   	// #0
    85b4:	52800160 	mov	w0, #0xb                   	// #11
    85b8:	97ffe8de 	bl	2930 <sigaction@plt>
    85bc:	35fffee0 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    85c0:	aa1803e1 	mov	x1, x24
    85c4:	d2800002 	mov	x2, #0x0                   	// #0
    85c8:	528000e0 	mov	w0, #0x7                   	// #7
    85cc:	97ffe8d9 	bl	2930 <sigaction@plt>
    85d0:	35fffe40 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    85d4:	b9434680 	ldr	w0, [x20, #836]
    85d8:	34000840 	cbz	w0, 86e0 <fwp_main_thread+0x210>
    85dc:	910182a0 	add	x0, x21, #0x60
    85e0:	b9434801 	ldr	w1, [x0, #840]
    85e4:	340008c1 	cbz	w1, 86fc <fwp_main_thread+0x22c>
    85e8:	910182b6 	add	x22, x21, #0x60
    85ec:	f9400ad4 	ldr	x20, [x22, #16]
    85f0:	b4001514 	cbz	x20, 8890 <fwp_main_thread+0x3c0>
    85f4:	91010297 	add	x23, x20, #0x40
    85f8:	a9156bf9 	stp	x25, x26, [sp, #336]
    85fc:	52800038 	mov	w24, #0x1                   	// #1
    8600:	39414a99 	ldrb	w25, [x20, #82]
    8604:	39014a98 	strb	w24, [x20, #82]
    8608:	f9401680 	ldr	x0, [x20, #40]
    860c:	b40013e0 	cbz	x0, 8888 <fwp_main_thread+0x3b8>
    8610:	f9403281 	ldr	x1, [x20, #96]
    8614:	39414680 	ldrb	w0, [x20, #81]
    8618:	b4001001 	cbz	x1, 8818 <fwp_main_thread+0x348>
    861c:	36000ec0 	tbz	w0, #0, 87f4 <fwp_main_thread+0x324>
    8620:	f9400ad3 	ldr	x19, [x22, #16]
    8624:	f9402280 	ldr	x0, [x20, #64]
    8628:	39414a61 	ldrb	w1, [x19, #82]
    862c:	370011e1 	tbnz	w1, #0, 8868 <fwp_main_thread+0x398>
    8630:	f9403261 	ldr	x1, [x19, #96]
    8634:	a911fe77 	stp	x23, xzr, [x19, #280]
    8638:	f9009660 	str	x0, [x19, #296]
    863c:	b4000040 	cbz	x0, 8644 <fwp_main_thread+0x174>
    8640:	f9009013 	str	x19, [x0, #288]
    8644:	f9002293 	str	x19, [x20, #64]
    8648:	b4000101 	cbz	x1, 8668 <fwp_main_thread+0x198>
    864c:	f9406ec0 	ldr	x0, [x22, #216]
    8650:	39015678 	strb	w24, [x19, #85]
    8654:	f9003661 	str	x1, [x19, #104]
    8658:	a910827f 	stp	xzr, x0, [x19, #264]
    865c:	b4000040 	cbz	x0, 8664 <fwp_main_thread+0x194>
    8660:	f9008413 	str	x19, [x0, #264]
    8664:	f9006ed3 	str	x19, [x22, #216]
    8668:	39015a7f 	strb	wzr, [x19, #86]
    866c:	97fff90d 	bl	6aa0 <fwp_block>
    8670:	f9408e62 	ldr	x2, [x19, #280]
    8674:	b4000142 	cbz	x2, 869c <fwp_main_thread+0x1cc>
    8678:	a9520261 	ldp	x1, x0, [x19, #288]
    867c:	b4001021 	cbz	x1, 8880 <fwp_main_thread+0x3b0>
    8680:	f9009420 	str	x0, [x1, #296]
    8684:	f9409660 	ldr	x0, [x19, #296]
    8688:	b4000040 	cbz	x0, 8690 <fwp_main_thread+0x1c0>
    868c:	f9009001 	str	x1, [x0, #288]
    8690:	91080260 	add	x0, x19, #0x200
    8694:	f900967f 	str	xzr, [x19, #296]
    8698:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    869c:	39415660 	ldrb	w0, [x19, #85]
    86a0:	3607fb40 	tbz	w0, #0, 8608 <fwp_main_thread+0x138>
    86a4:	a9508261 	ldp	x1, x0, [x19, #264]
    86a8:	b4001fc1 	cbz	x1, 8aa0 <fwp_main_thread+0x5d0>
    86ac:	f9008820 	str	x0, [x1, #272]
    86b0:	b4000040 	cbz	x0, 86b8 <fwp_main_thread+0x1e8>
    86b4:	f9008401 	str	x1, [x0, #264]
    86b8:	91080260 	add	x0, x19, #0x200
    86bc:	3901567f 	strb	wzr, [x19, #85]
    86c0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    86c4:	17ffffd1 	b	8608 <fwp_main_thread+0x138>
    86c8:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    86cc:	91321000 	add	x0, x0, #0xc84
    86d0:	94000428 	bl	9770 <atexit>
    86d4:	17ffff91 	b	8518 <fwp_main_thread+0x48>
    86d8:	97ffedc6 	bl	3df0 <fwp_heap_init>
    86dc:	17ffff8c 	b	850c <fwp_main_thread+0x3c>
    86e0:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    86e4:	91078000 	add	x0, x0, #0x1e0
    86e8:	94000422 	bl	9770 <atexit>
    86ec:	35004680 	cbnz	w0, 8fbc <fwp_main_thread+0xaec>
    86f0:	52800020 	mov	w0, #0x1                   	// #1
    86f4:	b9034680 	str	w0, [x20, #836]
    86f8:	17ffffb9 	b	85dc <fwp_main_thread+0x10c>
    86fc:	f9418803 	ldr	x3, [x0, #784]
    8700:	a9156bf9 	stp	x25, x26, [sp, #336]
    8704:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8708:	a91673fb 	stp	x27, x28, [sp, #352]
    870c:	91354021 	add	x1, x1, #0xd50
    8710:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8714:	91170279 	add	x25, x19, #0x5c0
    8718:	913f4042 	add	x2, x2, #0xfd0
    871c:	d280001a 	mov	x26, #0x0                   	// #0
    8720:	d290001b 	mov	x27, #0x8000                	// #32768
    8724:	f90003ff 	str	xzr, [sp]
    8728:	a9018be3 	stp	x3, x2, [sp, #24]
    872c:	a902fff7 	stp	x23, xzr, [sp, #40]
    8730:	a90407ff 	stp	xzr, x1, [sp, #64]
    8734:	f9018816 	str	x22, [x0, #784]
    8738:	14000012 	b	8780 <fwp_main_thread+0x2b0>
    873c:	7100045f 	cmp	w2, #0x1
    8740:	540001a1 	b.ne	8774 <fwp_main_thread+0x2a4>  // b.any
    8744:	294308a6 	ldp	w6, w2, [x5, #24]
    8748:	92403c21 	and	x1, x1, #0xffff
    874c:	9b067c21 	mul	x1, x1, x6
    8750:	d360fc21 	lsr	x1, x1, #32
    8754:	eb02003f 	cmp	x1, x2
    8758:	540000e2 	b.cs	8774 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    875c:	8b010000 	add	x0, x0, x1
    8760:	39400001 	ldrb	w1, [x0]
    8764:	7103fc3f 	cmp	w1, #0xff
    8768:	54003c40 	b.eq	8ef0 <fwp_main_thread+0xa20>  // b.none
    876c:	52800021 	mov	w1, #0x1                   	// #1
    8770:	39000001 	strb	w1, [x0]
    8774:	a9037ffa 	stp	x26, xzr, [sp, #48]
    8778:	aa14039c 	orr	x28, x28, x20
    877c:	b400197c 	cbz	x28, 8aa8 <fwp_main_thread+0x5d8>
    8780:	f94003e0 	ldr	x0, [sp]
    8784:	f100077c 	subs	x28, x27, #0x1
    8788:	aa1803e1 	mov	x1, x24
    878c:	f9001ffc 	str	x28, [sp, #56]
    8790:	da1f0014 	sbc	x20, x0, xzr
    8794:	52800020 	mov	w0, #0x1                   	// #1
    8798:	f90003f4 	str	x20, [sp]
    879c:	aa1c03fb 	mov	x27, x28
    87a0:	a9076bfc 	stp	x28, x26, [sp, #112]
    87a4:	97fff238 	bl	5084 <fwp_data.part.0.constprop.0>
    87a8:	aa0003fa 	mov	x26, x0
    87ac:	f949db21 	ldr	x1, [x25, #5040]
    87b0:	f949ef20 	ldr	x0, [x25, #5080]
    87b4:	cb010341 	sub	x1, x26, x1
    87b8:	eb00403f 	cmp	x1, x0, lsl #16
    87bc:	54fffdc2 	b.cs	8774 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    87c0:	d350fc22 	lsr	x2, x1, #16
    87c4:	f949ff26 	ldr	x6, [x25, #5112]
    87c8:	8b020842 	add	x2, x2, x2, lsl #2
    87cc:	d37df042 	lsl	x2, x2, #3
    87d0:	8b0200c5 	add	x5, x6, x2
    87d4:	f94010a0 	ldr	x0, [x5, #32]
    87d8:	b4fffce0 	cbz	x0, 8774 <fwp_main_thread+0x2a4>
    87dc:	386268c2 	ldrb	w2, [x6, x2]
    87e0:	7100085f 	cmp	w2, #0x2
    87e4:	54fffac1 	b.ne	873c <fwp_main_thread+0x26c>  // b.any
    87e8:	72003c3f 	tst	w1, #0xffff
    87ec:	54fffc41 	b.ne	8774 <fwp_main_thread+0x2a4>  // b.any
    87f0:	17ffffdc 	b	8760 <fwp_main_thread+0x290>
    87f4:	97fff087 	bl	4a10 <fwp_now_ns>
    87f8:	f9403281 	ldr	x1, [x20, #96]
    87fc:	eb01001f 	cmp	x0, x1
    8800:	540000ab 	b.lt	8814 <fwp_main_thread+0x344>  // b.tstop
    8804:	39414280 	ldrb	w0, [x20, #80]
    8808:	37000060 	tbnz	w0, #0, 8814 <fwp_main_thread+0x344>
    880c:	aa1403e0 	mov	x0, x20
    8810:	97ffebd8 	bl	3770 <fwp_cancel_tree.part.0>
    8814:	39414680 	ldrb	w0, [x20, #81]
    8818:	f9400ad3 	ldr	x19, [x22, #16]
    881c:	39414a62 	ldrb	w2, [x19, #82]
    8820:	3707f000 	tbnz	w0, #0, 8620 <fwp_main_thread+0x150>
    8824:	f9403281 	ldr	x1, [x20, #96]
    8828:	370001c2 	tbnz	w2, #0, 8860 <fwp_main_thread+0x390>
    882c:	f9403260 	ldr	x0, [x19, #96]
    8830:	b4000180 	cbz	x0, 8860 <fwp_main_thread+0x390>
    8834:	b4000061 	cbz	x1, 8840 <fwp_main_thread+0x370>
    8838:	eb01001f 	cmp	x0, x1
    883c:	9a81d000 	csel	x0, x0, x1, le
    8840:	f9402281 	ldr	x1, [x20, #64]
    8844:	a911fe77 	stp	x23, xzr, [x19, #280]
    8848:	f9009661 	str	x1, [x19, #296]
    884c:	b40035a1 	cbz	x1, 8f00 <fwp_main_thread+0xa30>
    8850:	f9009033 	str	x19, [x1, #288]
    8854:	aa0003e1 	mov	x1, x0
    8858:	f9002293 	str	x19, [x20, #64]
    885c:	17ffff7c 	b	864c <fwp_main_thread+0x17c>
    8860:	f9402280 	ldr	x0, [x20, #64]
    8864:	17ffff74 	b	8634 <fwp_main_thread+0x164>
    8868:	a911fe77 	stp	x23, xzr, [x19, #280]
    886c:	f9009660 	str	x0, [x19, #296]
    8870:	b4000040 	cbz	x0, 8878 <fwp_main_thread+0x3a8>
    8874:	f9009013 	str	x19, [x0, #288]
    8878:	f9002293 	str	x19, [x20, #64]
    887c:	17ffff7b 	b	8668 <fwp_main_thread+0x198>
    8880:	f9000040 	str	x0, [x2]
    8884:	17ffff81 	b	8688 <fwp_main_thread+0x1b8>
    8888:	39014a99 	strb	w25, [x20, #82]
    888c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8890:	910182b3 	add	x19, x21, #0x60
    8894:	f9419660 	ldr	x0, [x19, #808]
    8898:	b5000060 	cbnz	x0, 88a4 <fwp_main_thread+0x3d4>
    889c:	f9419e60 	ldr	x0, [x19, #824]
    88a0:	b40034e0 	cbz	x0, 8f3c <fwp_main_thread+0xa6c>
    88a4:	910182a0 	add	x0, x21, #0x60
    88a8:	f9400800 	ldr	x0, [x0, #16]
    88ac:	910182a1 	add	x1, x21, #0x60
    88b0:	f941b026 	ldr	x6, [x1, #864]
    88b4:	b903583f 	str	wzr, [x1, #856]
    88b8:	eb0000df 	cmp	x6, x0
    88bc:	54003d61 	b.ne	9068 <fwp_main_thread+0xb98>  // b.any
    88c0:	b40003e0 	cbz	x0, 893c <fwp_main_thread+0x46c>
    88c4:	f9418025 	ldr	x5, [x1, #768]
    88c8:	52800021 	mov	w1, #0x1                   	// #1
    88cc:	39014801 	strb	w1, [x0, #82]
    88d0:	b4000365 	cbz	x5, 893c <fwp_main_thread+0x46c>
    88d4:	d503201f 	nop
    88d8:	394140a0 	ldrb	w0, [x5, #80]
    88dc:	37000060 	tbnz	w0, #0, 88e8 <fwp_main_thread+0x418>
    88e0:	aa0503e0 	mov	x0, x5
    88e4:	97ffeba3 	bl	3770 <fwp_cancel_tree.part.0>
    88e8:	f9409ca5 	ldr	x5, [x5, #312]
    88ec:	b5ffff65 	cbnz	x5, 88d8 <fwp_main_thread+0x408>
    88f0:	910182b3 	add	x19, x21, #0x60
    88f4:	52800034 	mov	w20, #0x1                   	// #1
    88f8:	f94028c0 	ldr	x0, [x6, #80]
    88fc:	f2001c1f 	tst	x0, #0xff000000ff
    8900:	540000e1 	b.ne	891c <fwp_main_thread+0x44c>  // b.any
    8904:	f9403e60 	ldr	x0, [x19, #120]
    8908:	390150d4 	strb	w20, [x6, #84]
    890c:	f90080df 	str	xzr, [x6, #256]
    8910:	b4000120 	cbz	x0, 8934 <fwp_main_thread+0x464>
    8914:	f9008006 	str	x6, [x0, #256]
    8918:	f9003e66 	str	x6, [x19, #120]
    891c:	97fff861 	bl	6aa0 <fwp_block>
    8920:	97fff7e8 	bl	68c0 <fwp_free_zombie>
    8924:	f9418260 	ldr	x0, [x19, #768]
    8928:	b40000a0 	cbz	x0, 893c <fwp_main_thread+0x46c>
    892c:	f941b266 	ldr	x6, [x19, #864]
    8930:	17fffff2 	b	88f8 <fwp_main_thread+0x428>
    8934:	f9004266 	str	x6, [x19, #128]
    8938:	17fffff8 	b	8918 <fwp_main_thread+0x448>
    893c:	910182b4 	add	x20, x21, #0x60
    8940:	97fff7e0 	bl	68c0 <fwp_free_zombie>
    8944:	f9404280 	ldr	x0, [x20, #128]
    8948:	b5003900 	cbnz	x0, 9068 <fwp_main_thread+0xb98>
    894c:	f9406e80 	ldr	x0, [x20, #216]
    8950:	b50038c0 	cbnz	x0, 9068 <fwp_main_thread+0xb98>
    8954:	b940fa93 	ldr	w19, [x20, #248]
    8958:	340001f3 	cbz	w19, 8994 <fwp_main_thread+0x4c4>
    895c:	93407e76 	sxtw	x22, w19
    8960:	51000673 	sub	w19, w19, #0x1
    8964:	d1000ad6 	sub	x22, x22, #0x2
    8968:	91040297 	add	x23, x20, #0x100
    896c:	cb3342d6 	sub	x22, x22, w19, uxtw
    8970:	93407e73 	sxtw	x19, w19
    8974:	d503201f 	nop
    8978:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    897c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8980:	b900fa93 	str	w19, [x20, #248]
    8984:	d1000673 	sub	x19, x19, #0x1
    8988:	97ffe82a 	bl	2a30 <munmap@plt>
    898c:	eb1302df 	cmp	x22, x19
    8990:	54ffff41 	b.ne	8978 <fwp_main_thread+0x4a8>  // b.any
    8994:	900000d3 	adrp	x19, 20000 <__data_start>
    8998:	91004260 	add	x0, x19, #0x10
    899c:	b9403800 	ldr	w0, [x0, #56]
    89a0:	37f80040 	tbnz	w0, #31, 89a8 <fwp_main_thread+0x4d8>
    89a4:	97ffe7df 	bl	2920 <close@plt>
    89a8:	910182b4 	add	x20, x21, #0x60
    89ac:	91004273 	add	x19, x19, #0x10
    89b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    89b4:	f941ba80 	ldr	x0, [x20, #880]
    89b8:	b9003a61 	str	w1, [x19, #56]
    89bc:	f941b681 	ldr	x1, [x20, #872]
    89c0:	b40001c0 	cbz	x0, 89f8 <fwp_main_thread+0x528>
    89c4:	d2800013 	mov	x19, #0x0                   	// #0
    89c8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    89cc:	b40000e0 	cbz	x0, 89e8 <fwp_main_thread+0x518>
    89d0:	f9400001 	ldr	x1, [x0]
    89d4:	b50034a1 	cbnz	x1, 9068 <fwp_main_thread+0xb98>
    89d8:	f9400401 	ldr	x1, [x0, #8]
    89dc:	b5003461 	cbnz	x1, 9068 <fwp_main_thread+0xb98>
    89e0:	97ffeea8 	bl	4480 <fwp_mem_free>
    89e4:	f941b681 	ldr	x1, [x20, #872]
    89e8:	91000673 	add	x19, x19, #0x1
    89ec:	f941ba80 	ldr	x0, [x20, #880]
    89f0:	eb00027f 	cmp	x19, x0
    89f4:	54fffea3 	b.cc	89c8 <fwp_main_thread+0x4f8>  // b.lo, b.ul, b.last
    89f8:	aa0103e0 	mov	x0, x1
    89fc:	97ffeea1 	bl	4480 <fwp_mem_free>
    8a00:	910182a0 	add	x0, x21, #0x60
    8a04:	f941b013 	ldr	x19, [x0, #864]
    8a08:	f901b41f 	str	xzr, [x0, #872]
    8a0c:	f901b81f 	str	xzr, [x0, #880]
    8a10:	b40001f3 	cbz	x19, 8a4c <fwp_main_thread+0x57c>
    8a14:	f9401661 	ldr	x1, [x19, #40]
    8a18:	b5003281 	cbnz	x1, 9068 <fwp_main_thread+0xb98>
    8a1c:	f9405661 	ldr	x1, [x19, #168]
    8a20:	b5003241 	cbnz	x1, 9068 <fwp_main_thread+0xb98>
    8a24:	f9419401 	ldr	x1, [x0, #808]
    8a28:	b5003201 	cbnz	x1, 9068 <fwp_main_thread+0xb98>
    8a2c:	f9419c00 	ldr	x0, [x0, #824]
    8a30:	b50031c0 	cbnz	x0, 9068 <fwp_main_thread+0xb98>
    8a34:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8a38:	90000140 	adrp	x0, 30000 <alt.5+0xfc20>
    8a3c:	910f8000 	add	x0, x0, #0x3e0
    8a40:	97ffe7a8 	bl	28e0 <memset@plt>
    8a44:	aa1303e0 	mov	x0, x19
    8a48:	97ffee8e 	bl	4480 <fwp_mem_free>
    8a4c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8a50:	f947ec00 	ldr	x0, [x0, #4056]
    8a54:	910182b5 	add	x21, x21, #0x60
    8a58:	f9400000 	ldr	x0, [x0]
    8a5c:	f9000abf 	str	xzr, [x21, #16]
    8a60:	f901b2bf 	str	xzr, [x21, #864]
    8a64:	97ffe7f7 	bl	2a40 <fflush@plt>
    8a68:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8a6c:	f947f400 	ldr	x0, [x0, #4072]
    8a70:	f94087e2 	ldr	x2, [sp, #264]
    8a74:	f9400001 	ldr	x1, [x0]
    8a78:	eb010042 	subs	x2, x2, x1
    8a7c:	d2800001 	mov	x1, #0x0                   	// #0
    8a80:	54002a41 	b.ne	8fc8 <fwp_main_thread+0xaf8>  // b.any
    8a84:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8a88:	d2800000 	mov	x0, #0x0                   	// #0
    8a8c:	a95253f3 	ldp	x19, x20, [sp, #288]
    8a90:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8a94:	a95463f7 	ldp	x23, x24, [sp, #320]
    8a98:	9105c3ff 	add	sp, sp, #0x170
    8a9c:	d65f03c0 	ret
    8aa0:	f9006ec0 	str	x0, [x22, #216]
    8aa4:	17ffff03 	b	86b0 <fwp_main_thread+0x1e0>
    8aa8:	910182a2 	add	x2, x21, #0x60
    8aac:	f9001bff 	str	xzr, [sp, #48]
    8ab0:	f9418840 	ldr	x0, [x2, #784]
    8ab4:	eb16001f 	cmp	x0, x22
    8ab8:	54002dc1 	b.ne	9070 <fwp_main_thread+0xba0>  // b.any
    8abc:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x860>
    8ac0:	910143e1 	add	x1, sp, #0x50
    8ac4:	f9400fe3 	ldr	x3, [sp, #24]
    8ac8:	f9018843 	str	x3, [x2, #784]
    8acc:	3dc13800 	ldr	q0, [x0, #1248]
    8ad0:	52800020 	mov	w0, #0x1                   	// #1
    8ad4:	3d8017e0 	str	q0, [sp, #80]
    8ad8:	97fff16b 	bl	5084 <fwp_data.part.0.constprop.0>
    8adc:	91170263 	add	x3, x19, #0x5c0
    8ae0:	aa0003f4 	mov	x20, x0
    8ae4:	f949d861 	ldr	x1, [x3, #5040]
    8ae8:	f949ec60 	ldr	x0, [x3, #5080]
    8aec:	cb010281 	sub	x1, x20, x1
    8af0:	eb00403f 	cmp	x1, x0, lsl #16
    8af4:	54000322 	b.cs	8b58 <fwp_main_thread+0x688>  // b.hs, b.nlast
    8af8:	d350fc22 	lsr	x2, x1, #16
    8afc:	f949fc63 	ldr	x3, [x3, #5112]
    8b00:	8b020842 	add	x2, x2, x2, lsl #2
    8b04:	d37df042 	lsl	x2, x2, #3
    8b08:	8b020060 	add	x0, x3, x2
    8b0c:	f9401016 	ldr	x22, [x0, #32]
    8b10:	b4000256 	cbz	x22, 8b58 <fwp_main_thread+0x688>
    8b14:	38626862 	ldrb	w2, [x3, x2]
    8b18:	7100085f 	cmp	w2, #0x2
    8b1c:	54001f80 	b.eq	8f0c <fwp_main_thread+0xa3c>  // b.none
    8b20:	7100045f 	cmp	w2, #0x1
    8b24:	540001a1 	b.ne	8b58 <fwp_main_thread+0x688>  // b.any
    8b28:	29430002 	ldp	w2, w0, [x0, #24]
    8b2c:	92403c21 	and	x1, x1, #0xffff
    8b30:	9b027c21 	mul	x1, x1, x2
    8b34:	d360fc21 	lsr	x1, x1, #32
    8b38:	eb00003f 	cmp	x1, x0
    8b3c:	540000e2 	b.cs	8b58 <fwp_main_thread+0x688>  // b.hs, b.nlast
    8b40:	8b0102d6 	add	x22, x22, x1
    8b44:	394002c0 	ldrb	w0, [x22]
    8b48:	7103fc1f 	cmp	w0, #0xff
    8b4c:	54002160 	b.eq	8f78 <fwp_main_thread+0xaa8>  // b.none
    8b50:	52800020 	mov	w0, #0x1                   	// #1
    8b54:	390002c0 	strb	w0, [x22]
    8b58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8b5c:	aa1803e1 	mov	x1, x24
    8b60:	52800020 	mov	w0, #0x1                   	// #1
    8b64:	a90753e2 	stp	x2, x20, [sp, #112]
    8b68:	97fff147 	bl	5084 <fwp_data.part.0.constprop.0>
    8b6c:	91170263 	add	x3, x19, #0x5c0
    8b70:	aa0003f4 	mov	x20, x0
    8b74:	f949d861 	ldr	x1, [x3, #5040]
    8b78:	f949ec60 	ldr	x0, [x3, #5080]
    8b7c:	cb010281 	sub	x1, x20, x1
    8b80:	eb00403f 	cmp	x1, x0, lsl #16
    8b84:	54000322 	b.cs	8be8 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8b88:	d350fc22 	lsr	x2, x1, #16
    8b8c:	f949fc63 	ldr	x3, [x3, #5112]
    8b90:	8b020842 	add	x2, x2, x2, lsl #2
    8b94:	d37df042 	lsl	x2, x2, #3
    8b98:	8b020060 	add	x0, x3, x2
    8b9c:	f9401016 	ldr	x22, [x0, #32]
    8ba0:	b4000256 	cbz	x22, 8be8 <fwp_main_thread+0x718>
    8ba4:	38626862 	ldrb	w2, [x3, x2]
    8ba8:	7100085f 	cmp	w2, #0x2
    8bac:	54001b60 	b.eq	8f18 <fwp_main_thread+0xa48>  // b.none
    8bb0:	7100045f 	cmp	w2, #0x1
    8bb4:	540001a1 	b.ne	8be8 <fwp_main_thread+0x718>  // b.any
    8bb8:	29430002 	ldp	w2, w0, [x0, #24]
    8bbc:	92403c21 	and	x1, x1, #0xffff
    8bc0:	9b027c21 	mul	x1, x1, x2
    8bc4:	d360fc21 	lsr	x1, x1, #32
    8bc8:	eb00003f 	cmp	x1, x0
    8bcc:	540000e2 	b.cs	8be8 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8bd0:	8b0102d6 	add	x22, x22, x1
    8bd4:	394002c0 	ldrb	w0, [x22]
    8bd8:	7103fc1f 	cmp	w0, #0xff
    8bdc:	54001c20 	b.eq	8f60 <fwp_main_thread+0xa90>  // b.none
    8be0:	52800020 	mov	w0, #0x1                   	// #1
    8be4:	390002c0 	strb	w0, [x22]
    8be8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8bec:	910183e1 	add	x1, sp, #0x60
    8bf0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8bf4:	52800020 	mov	w0, #0x1                   	// #1
    8bf8:	a90653e2 	stp	x2, x20, [sp, #96]
    8bfc:	97fff122 	bl	5084 <fwp_data.part.0.constprop.0>
    8c00:	91170263 	add	x3, x19, #0x5c0
    8c04:	aa0003f9 	mov	x25, x0
    8c08:	f949d861 	ldr	x1, [x3, #5040]
    8c0c:	f949ec60 	ldr	x0, [x3, #5080]
    8c10:	cb010321 	sub	x1, x25, x1
    8c14:	eb00403f 	cmp	x1, x0, lsl #16
    8c18:	54000322 	b.cs	8c7c <fwp_main_thread+0x7ac>  // b.hs, b.nlast
    8c1c:	d350fc22 	lsr	x2, x1, #16
    8c20:	f949fc63 	ldr	x3, [x3, #5112]
    8c24:	8b020842 	add	x2, x2, x2, lsl #2
    8c28:	d37df042 	lsl	x2, x2, #3
    8c2c:	8b020060 	add	x0, x3, x2
    8c30:	f9401014 	ldr	x20, [x0, #32]
    8c34:	b4000254 	cbz	x20, 8c7c <fwp_main_thread+0x7ac>
    8c38:	38626862 	ldrb	w2, [x3, x2]
    8c3c:	7100085f 	cmp	w2, #0x2
    8c40:	54001720 	b.eq	8f24 <fwp_main_thread+0xa54>  // b.none
    8c44:	7100045f 	cmp	w2, #0x1
    8c48:	540001a1 	b.ne	8c7c <fwp_main_thread+0x7ac>  // b.any
    8c4c:	29430002 	ldp	w2, w0, [x0, #24]
    8c50:	92403c21 	and	x1, x1, #0xffff
    8c54:	9b027c21 	mul	x1, x1, x2
    8c58:	d360fc21 	lsr	x1, x1, #32
    8c5c:	eb00003f 	cmp	x1, x0
    8c60:	540000e2 	b.cs	8c7c <fwp_main_thread+0x7ac>  // b.hs, b.nlast
    8c64:	8b010294 	add	x20, x20, x1
    8c68:	39400280 	ldrb	w0, [x20]
    8c6c:	7103fc1f 	cmp	w0, #0xff
    8c70:	540017e0 	b.eq	8f6c <fwp_main_thread+0xa9c>  // b.none
    8c74:	52800020 	mov	w0, #0x1                   	// #1
    8c78:	39000280 	strb	w0, [x20]
    8c7c:	aa1a03f8 	mov	x24, x26
    8c80:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12820>
    8c84:	b400121a 	cbz	x26, 8ec4 <fwp_main_thread+0x9f4>
    8c88:	910aa000 	add	x0, x0, #0x2a8
    8c8c:	d0000016 	adrp	x22, a000 <_IO_stdin_used+0x860>
    8c90:	91014014 	add	x20, x0, #0x50
    8c94:	9108e2d6 	add	x22, x22, #0x238
    8c98:	9117027b 	add	x27, x19, #0x5c0
    8c9c:	f949db61 	ldr	x1, [x27, #5040]
    8ca0:	f949ef60 	ldr	x0, [x27, #5080]
    8ca4:	cb010321 	sub	x1, x25, x1
    8ca8:	eb00403f 	cmp	x1, x0, lsl #16
    8cac:	54000342 	b.cs	8d14 <fwp_main_thread+0x844>  // b.hs, b.nlast
    8cb0:	d350fc22 	lsr	x2, x1, #16
    8cb4:	f949ff65 	ldr	x5, [x27, #5112]
    8cb8:	8b020842 	add	x2, x2, x2, lsl #2
    8cbc:	d37df042 	lsl	x2, x2, #3
    8cc0:	8b0200a3 	add	x3, x5, x2
    8cc4:	f9401060 	ldr	x0, [x3, #32]
    8cc8:	b4000260 	cbz	x0, 8d14 <fwp_main_thread+0x844>
    8ccc:	386268a2 	ldrb	w2, [x5, x2]
    8cd0:	7100085f 	cmp	w2, #0x2
    8cd4:	540012e0 	b.eq	8f30 <fwp_main_thread+0xa60>  // b.none
    8cd8:	7100045f 	cmp	w2, #0x1
    8cdc:	540001c1 	b.ne	8d14 <fwp_main_thread+0x844>  // b.any
    8ce0:	29430865 	ldp	w5, w2, [x3, #24]
    8ce4:	92403c21 	and	x1, x1, #0xffff
    8ce8:	9b057c21 	mul	x1, x1, x5
    8cec:	d360fc21 	lsr	x1, x1, #32
    8cf0:	eb02003f 	cmp	x1, x2
    8cf4:	54000102 	b.cs	8d14 <fwp_main_thread+0x844>  // b.hs, b.nlast
    8cf8:	8b010000 	add	x0, x0, x1
    8cfc:	39400001 	ldrb	w1, [x0]
    8d00:	340000a1 	cbz	w1, 8d14 <fwp_main_thread+0x844>
    8d04:	7103f43f 	cmp	w1, #0xfd
    8d08:	540013e8 	b.hi	8f84 <fwp_main_thread+0xab4>  // b.pmore
    8d0c:	11000421 	add	w1, w1, #0x1
    8d10:	39000001 	strb	w1, [x0]
    8d14:	aa1403e2 	mov	x2, x20
    8d18:	aa1903e1 	mov	x1, x25
    8d1c:	aa1703e0 	mov	x0, x23
    8d20:	52800023 	mov	w3, #0x1                   	// #1
    8d24:	a9037fff 	stp	xzr, xzr, [sp, #48]
    8d28:	f90023ff 	str	xzr, [sp, #64]
    8d2c:	97fff9ee 	bl	74e4 <fwp_write>
    8d30:	a9430bfc 	ldp	x28, x2, [sp, #48]
    8d34:	f100039f 	cmp	x28, #0x0
    8d38:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    8d3c:	b100285f 	cmn	x2, #0xa
    8d40:	54001268 	b.hi	8f8c <fwp_main_thread+0xabc>  // b.pmore
    8d44:	91002440 	add	x0, x2, #0x9
    8d48:	52800021 	mov	w1, #0x1                   	// #1
    8d4c:	f90007e2 	str	x2, [sp, #8]
    8d50:	97fff088 	bl	4f70 <fwp_heap_alloc>
    8d54:	aa1c03e1 	mov	x1, x28
    8d58:	aa0003fc 	mov	x28, x0
    8d5c:	f94007e2 	ldr	x2, [sp, #8]
    8d60:	f90003e0 	str	x0, [sp]
    8d64:	f8008782 	str	x2, [x28], #8
    8d68:	aa1c03e0 	mov	x0, x28
    8d6c:	97ffe67d 	bl	2760 <memcpy@plt>
    8d70:	a9400be0 	ldp	x0, x2, [sp]
    8d74:	8b020002 	add	x2, x0, x2
    8d78:	3900205f 	strb	wzr, [x2, #8]
    8d7c:	f9401be0 	ldr	x0, [sp, #48]
    8d80:	97ffe714 	bl	29d0 <free@plt>
    8d84:	91170260 	add	x0, x19, #0x5c0
    8d88:	f94003e3 	ldr	x3, [sp]
    8d8c:	f949d801 	ldr	x1, [x0, #5040]
    8d90:	f949ec02 	ldr	x2, [x0, #5080]
    8d94:	cb010061 	sub	x1, x3, x1
    8d98:	eb02403f 	cmp	x1, x2, lsl #16
    8d9c:	54000322 	b.cs	8e00 <fwp_main_thread+0x930>  // b.hs, b.nlast
    8da0:	d350fc22 	lsr	x2, x1, #16
    8da4:	d2800503 	mov	x3, #0x28                  	// #40
    8da8:	f949fc05 	ldr	x5, [x0, #5112]
    8dac:	9b037c42 	mul	x2, x2, x3
    8db0:	8b0200a3 	add	x3, x5, x2
    8db4:	f9401060 	ldr	x0, [x3, #32]
    8db8:	b4000240 	cbz	x0, 8e00 <fwp_main_thread+0x930>
    8dbc:	386268a2 	ldrb	w2, [x5, x2]
    8dc0:	7100085f 	cmp	w2, #0x2
    8dc4:	54000f60 	b.eq	8fb0 <fwp_main_thread+0xae0>  // b.none
    8dc8:	7100045f 	cmp	w2, #0x1
    8dcc:	540001a1 	b.ne	8e00 <fwp_main_thread+0x930>  // b.any
    8dd0:	29430865 	ldp	w5, w2, [x3, #24]
    8dd4:	92403c21 	and	x1, x1, #0xffff
    8dd8:	9b057c21 	mul	x1, x1, x5
    8ddc:	d360fc21 	lsr	x1, x1, #32
    8de0:	eb02003f 	cmp	x1, x2
    8de4:	540000e2 	b.cs	8e00 <fwp_main_thread+0x930>  // b.hs, b.nlast
    8de8:	8b010000 	add	x0, x0, x1
    8dec:	39400001 	ldrb	w1, [x0]
    8df0:	7103fc3f 	cmp	w1, #0xff
    8df4:	540010e0 	b.eq	9010 <fwp_main_thread+0xb40>  // b.none
    8df8:	52800021 	mov	w1, #0x1                   	// #1
    8dfc:	39000001 	strb	w1, [x0]
    8e00:	aa1903e0 	mov	x0, x25
    8e04:	97fff42f 	bl	5ec0 <fwp_drop0>
    8e08:	f94003e1 	ldr	x1, [sp]
    8e0c:	910182a3 	add	x3, x21, #0x60
    8e10:	aa1c03e0 	mov	x0, x28
    8e14:	aa0303fc 	mov	x28, x3
    8e18:	f9400022 	ldr	x2, [x1]
    8e1c:	d2800021 	mov	x1, #0x1                   	// #1
    8e20:	f9400463 	ldr	x3, [x3, #8]
    8e24:	97ffe6fb 	bl	2a10 <fwrite@plt>
    8e28:	f9400781 	ldr	x1, [x28, #8]
    8e2c:	52800140 	mov	w0, #0xa                   	// #10
    8e30:	97ffe680 	bl	2830 <fputc@plt>
    8e34:	91170262 	add	x2, x19, #0x5c0
    8e38:	f94003e3 	ldr	x3, [sp]
    8e3c:	f949d841 	ldr	x1, [x2, #5040]
    8e40:	f949ec40 	ldr	x0, [x2, #5080]
    8e44:	cb010061 	sub	x1, x3, x1
    8e48:	eb00403f 	cmp	x1, x0, lsl #16
    8e4c:	54000382 	b.cs	8ebc <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    8e50:	d350fc20 	lsr	x0, x1, #16
    8e54:	d2800505 	mov	x5, #0x28                  	// #40
    8e58:	f949fc43 	ldr	x3, [x2, #5112]
    8e5c:	9b057c00 	mul	x0, x0, x5
    8e60:	8b000062 	add	x2, x3, x0
    8e64:	f940105c 	ldr	x28, [x2, #32]
    8e68:	b40002bc 	cbz	x28, 8ebc <fwp_main_thread+0x9ec>
    8e6c:	38606860 	ldrb	w0, [x3, x0]
    8e70:	7100081f 	cmp	w0, #0x2
    8e74:	54000980 	b.eq	8fa4 <fwp_main_thread+0xad4>  // b.none
    8e78:	7100041f 	cmp	w0, #0x1
    8e7c:	54000201 	b.ne	8ebc <fwp_main_thread+0x9ec>  // b.any
    8e80:	29430043 	ldp	w3, w0, [x2, #24]
    8e84:	92403c21 	and	x1, x1, #0xffff
    8e88:	9b037c21 	mul	x1, x1, x3
    8e8c:	d360fc21 	lsr	x1, x1, #32
    8e90:	eb00003f 	cmp	x1, x0
    8e94:	54000142 	b.cs	8ebc <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    8e98:	8b01039c 	add	x28, x28, x1
    8e9c:	39400380 	ldrb	w0, [x28]
    8ea0:	340000e0 	cbz	w0, 8ebc <fwp_main_thread+0x9ec>
    8ea4:	7100041f 	cmp	w0, #0x1
    8ea8:	54000780 	b.eq	8f98 <fwp_main_thread+0xac8>  // b.none
    8eac:	7103fc1f 	cmp	w0, #0xff
    8eb0:	54000920 	b.eq	8fd4 <fwp_main_thread+0xb04>  // b.none
    8eb4:	51000400 	sub	w0, w0, #0x1
    8eb8:	39000380 	strb	w0, [x28]
    8ebc:	f9400b18 	ldr	x24, [x24, #16]
    8ec0:	b5ffeef8 	cbnz	x24, 8c9c <fwp_main_thread+0x7cc>
    8ec4:	aa1903e0 	mov	x0, x25
    8ec8:	97fff3fe 	bl	5ec0 <fwp_drop0>
    8ecc:	aa1a03e0 	mov	x0, x26
    8ed0:	97fff3fc 	bl	5ec0 <fwp_drop0>
    8ed4:	910182a0 	add	x0, x21, #0x60
    8ed8:	52800021 	mov	w1, #0x1                   	// #1
    8edc:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8ee0:	a95673fb 	ldp	x27, x28, [sp, #352]
    8ee4:	b9034801 	str	w1, [x0, #840]
    8ee8:	f901a81f 	str	xzr, [x0, #848]
    8eec:	17fffdbf 	b	85e8 <fwp_main_thread+0x118>
    8ef0:	f90007e0 	str	x0, [sp, #8]
    8ef4:	97ffecc7 	bl	4210 <fwp_rc_forget_slot.part.0>
    8ef8:	f94007e0 	ldr	x0, [sp, #8]
    8efc:	17fffe1c 	b	876c <fwp_main_thread+0x29c>
    8f00:	aa0003e1 	mov	x1, x0
    8f04:	f9002293 	str	x19, [x20, #64]
    8f08:	17fffdd1 	b	864c <fwp_main_thread+0x17c>
    8f0c:	72003c3f 	tst	w1, #0xffff
    8f10:	54ffe241 	b.ne	8b58 <fwp_main_thread+0x688>  // b.any
    8f14:	17ffff0c 	b	8b44 <fwp_main_thread+0x674>
    8f18:	72003c3f 	tst	w1, #0xffff
    8f1c:	54ffe661 	b.ne	8be8 <fwp_main_thread+0x718>  // b.any
    8f20:	17ffff2d 	b	8bd4 <fwp_main_thread+0x704>
    8f24:	72003c3f 	tst	w1, #0xffff
    8f28:	54ffeaa1 	b.ne	8c7c <fwp_main_thread+0x7ac>  // b.any
    8f2c:	17ffff4f 	b	8c68 <fwp_main_thread+0x798>
    8f30:	72003c3f 	tst	w1, #0xffff
    8f34:	54ffef01 	b.ne	8d14 <fwp_main_thread+0x844>  // b.any
    8f38:	17ffff71 	b	8cfc <fwp_main_thread+0x82c>
    8f3c:	f9419260 	ldr	x0, [x19, #800]
    8f40:	97ffed50 	bl	4480 <fwp_mem_free>
    8f44:	f901927f 	str	xzr, [x19, #800]
    8f48:	f9400a60 	ldr	x0, [x19, #16]
    8f4c:	f9019a7f 	str	xzr, [x19, #816]
    8f50:	b4ffcae0 	cbz	x0, 88ac <fwp_main_thread+0x3dc>
    8f54:	f900541f 	str	xzr, [x0, #168]
    8f58:	f9005c1f 	str	xzr, [x0, #184]
    8f5c:	17fffe54 	b	88ac <fwp_main_thread+0x3dc>
    8f60:	aa1603e0 	mov	x0, x22
    8f64:	97ffecab 	bl	4210 <fwp_rc_forget_slot.part.0>
    8f68:	17ffff1e 	b	8be0 <fwp_main_thread+0x710>
    8f6c:	aa1403e0 	mov	x0, x20
    8f70:	97ffeca8 	bl	4210 <fwp_rc_forget_slot.part.0>
    8f74:	17ffff40 	b	8c74 <fwp_main_thread+0x7a4>
    8f78:	aa1603e0 	mov	x0, x22
    8f7c:	97ffeca5 	bl	4210 <fwp_rc_forget_slot.part.0>
    8f80:	17fffef4 	b	8b50 <fwp_main_thread+0x680>
    8f84:	97ffedb8 	bl	4664 <fwp_rc_wide_dup>
    8f88:	17ffff63 	b	8d14 <fwp_main_thread+0x844>
    8f8c:	b0000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    8f90:	9135a000 	add	x0, x0, #0xd68
    8f94:	97ffec7f 	bl	4190 <fwp_trap>
    8f98:	f94003e0 	ldr	x0, [sp]
    8f9c:	97fff299 	bl	5a00 <fwp_rc_free_arr>
    8fa0:	17ffffc7 	b	8ebc <fwp_main_thread+0x9ec>
    8fa4:	72003c3f 	tst	w1, #0xffff
    8fa8:	54fff8a1 	b.ne	8ebc <fwp_main_thread+0x9ec>  // b.any
    8fac:	17ffffbc 	b	8e9c <fwp_main_thread+0x9cc>
    8fb0:	72003c3f 	tst	w1, #0xffff
    8fb4:	54fff261 	b.ne	8e00 <fwp_main_thread+0x930>  // b.any
    8fb8:	17ffff8d 	b	8dec <fwp_main_thread+0x91c>
    8fbc:	a9156bf9 	stp	x25, x26, [sp, #336]
    8fc0:	a91673fb 	stp	x27, x28, [sp, #352]
    8fc4:	97ffe87b 	bl	31b0 <descent_phase_fail>
    8fc8:	a9156bf9 	stp	x25, x26, [sp, #336]
    8fcc:	a91673fb 	stp	x27, x28, [sp, #352]
    8fd0:	97ffe650 	bl	2910 <__stack_chk_fail@plt>
    8fd4:	ca5c4780 	eor	x0, x28, x28, lsr #17
    8fd8:	91170262 	add	x2, x19, #0x5c0
    8fdc:	ca402400 	eor	x0, x0, x0, lsr #9
    8fe0:	92401c00 	and	x0, x0, #0xff
    8fe4:	910a2401 	add	x1, x0, #0x289
    8fe8:	8b000c40 	add	x0, x2, x0, lsl #3
    8fec:	8b010c41 	add	x1, x2, x1, lsl #3
    8ff0:	f94a2400 	ldr	x0, [x0, #5192]
    8ff4:	b40002e0 	cbz	x0, 9050 <fwp_main_thread+0xb80>
    8ff8:	f9400002 	ldr	x2, [x0]
    8ffc:	eb02039f 	cmp	x28, x2
    9000:	54000100 	b.eq	9020 <fwp_main_thread+0xb50>  // b.none
    9004:	91004001 	add	x1, x0, #0x10
    9008:	f9400800 	ldr	x0, [x0, #16]
    900c:	17fffffa 	b	8ff4 <fwp_main_thread+0xb24>
    9010:	f90007e0 	str	x0, [sp, #8]
    9014:	97ffec7f 	bl	4210 <fwp_rc_forget_slot.part.0>
    9018:	f94007e0 	ldr	x0, [sp, #8]
    901c:	17ffff77 	b	8df8 <fwp_main_thread+0x928>
    9020:	f9400021 	ldr	x1, [x1]
    9024:	f9400420 	ldr	x0, [x1, #8]
    9028:	d1000400 	sub	x0, x0, #0x1
    902c:	f9000420 	str	x0, [x1, #8]
    9030:	f103f81f 	cmp	x0, #0xfe
    9034:	54fff441 	b.ne	8ebc <fwp_main_thread+0x9ec>  // b.any
    9038:	39400380 	ldrb	w0, [x28]
    903c:	7103fc1f 	cmp	w0, #0xff
    9040:	540000e0 	b.eq	905c <fwp_main_thread+0xb8c>  // b.none
    9044:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9048:	39000380 	strb	w0, [x28]
    904c:	17ffff9c 	b	8ebc <fwp_main_thread+0x9ec>
    9050:	90000000 	adrp	x0, 9000 <fwp_main_thread+0xb30>
    9054:	91266000 	add	x0, x0, #0x998
    9058:	97ffec4e 	bl	4190 <fwp_trap>
    905c:	aa1c03e0 	mov	x0, x28
    9060:	97ffec6c 	bl	4210 <fwp_rc_forget_slot.part.0>
    9064:	17fffff8 	b	9044 <fwp_main_thread+0xb74>
    9068:	a9156bf9 	stp	x25, x26, [sp, #336]
    906c:	a91673fb 	stp	x27, x28, [sp, #352]
    9070:	97ffe63c 	bl	2960 <abort@plt>
    9074:	d503201f 	nop
    9078:	d503201f 	nop
    907c:	d503201f 	nop

0000000000009080 <__divti3>:
    9080:	d503245f 	bti	c
    9084:	d2800004 	mov	x4, #0x0                   	// #0
    9088:	b7f80721 	tbnz	x1, #63, 916c <__divti3+0xec>
    908c:	b6f80083 	tbz	x3, #63, 909c <__divti3+0x1c>
    9090:	eb0203e2 	negs	x2, x2
    9094:	aa2403e4 	mvn	x4, x4
    9098:	da0303e3 	ngc	x3, x3
    909c:	aa0203e6 	mov	x6, x2
    90a0:	aa0003e7 	mov	x7, x0
    90a4:	aa0103e5 	mov	x5, x1
    90a8:	b5000583 	cbnz	x3, 9158 <__divti3+0xd8>
    90ac:	eb01005f 	cmp	x2, x1
    90b0:	54000e69 	b.ls	927c <__divti3+0x1fc>  // b.plast
    90b4:	dac01040 	clz	x0, x2
    90b8:	b40000e0 	cbz	x0, 90d4 <__divti3+0x54>
    90bc:	4b0003e1 	neg	w1, w0
    90c0:	9ac020a5 	lsl	x5, x5, x0
    90c4:	9ac02046 	lsl	x6, x2, x0
    90c8:	9ac124e1 	lsr	x1, x7, x1
    90cc:	aa050025 	orr	x5, x1, x5
    90d0:	9ac020e7 	lsl	x7, x7, x0
    90d4:	d360fcc8 	lsr	x8, x6, #32
    90d8:	92407cc2 	and	x2, x6, #0xffffffff
    90dc:	9ac808a3 	udiv	x3, x5, x8
    90e0:	9b089465 	msub	x5, x3, x8, x5
    90e4:	aa0303e0 	mov	x0, x3
    90e8:	9b037c41 	mul	x1, x2, x3
    90ec:	93c780a5 	extr	x5, x5, x7, #32
    90f0:	eb05003f 	cmp	x1, x5
    90f4:	540000a9 	b.ls	9108 <__divti3+0x88>  // b.plast
    90f8:	ab0500c5 	adds	x5, x6, x5
    90fc:	d1000460 	sub	x0, x3, #0x1
    9100:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9104:	540015a8 	b.hi	93b8 <__divti3+0x338>  // b.pmore
    9108:	cb0100a5 	sub	x5, x5, x1
    910c:	9ac808a3 	udiv	x3, x5, x8
    9110:	9b089465 	msub	x5, x3, x8, x5
    9114:	aa0303e1 	mov	x1, x3
    9118:	9b037c42 	mul	x2, x2, x3
    911c:	aa0703e3 	mov	x3, x7
    9120:	b3607ca3 	bfi	x3, x5, #32, #32
    9124:	eb03005f 	cmp	x2, x3
    9128:	540000c9 	b.ls	9140 <__divti3+0xc0>  // b.plast
    912c:	ab0300c3 	adds	x3, x6, x3
    9130:	d1000425 	sub	x5, x1, #0x1
    9134:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9138:	d1000821 	sub	x1, x1, #0x2
    913c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9140:	aa008020 	orr	x0, x1, x0, lsl #32
    9144:	d2800001 	mov	x1, #0x0                   	// #0
    9148:	b4000064 	cbz	x4, 9154 <__divti3+0xd4>
    914c:	eb0003e0 	negs	x0, x0
    9150:	da0103e1 	ngc	x1, x1
    9154:	d65f03c0 	ret
    9158:	eb01007f 	cmp	x3, x1
    915c:	54000109 	b.ls	917c <__divti3+0xfc>  // b.plast
    9160:	d2800001 	mov	x1, #0x0                   	// #0
    9164:	d2800000 	mov	x0, #0x0                   	// #0
    9168:	17fffff8 	b	9148 <__divti3+0xc8>
    916c:	eb0003e0 	negs	x0, x0
    9170:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9174:	da0103e1 	ngc	x1, x1
    9178:	17ffffc5 	b	908c <__divti3+0xc>
    917c:	dac01067 	clz	x7, x3
    9180:	b40010e7 	cbz	x7, 939c <__divti3+0x31c>
    9184:	d2800805 	mov	x5, #0x40                  	// #64
    9188:	cb0700a5 	sub	x5, x5, x7
    918c:	9ac72063 	lsl	x3, x3, x7
    9190:	9ac52448 	lsr	x8, x2, x5
    9194:	aa030108 	orr	x8, x8, x3
    9198:	9ac52426 	lsr	x6, x1, x5
    919c:	92407d0a 	and	x10, x8, #0xffffffff
    91a0:	d360fd09 	lsr	x9, x8, #32
    91a4:	9ac52403 	lsr	x3, x0, x5
    91a8:	9ac72021 	lsl	x1, x1, x7
    91ac:	aa010063 	orr	x3, x3, x1
    91b0:	9ac72042 	lsl	x2, x2, x7
    91b4:	9ac908cb 	udiv	x11, x6, x9
    91b8:	9b099965 	msub	x5, x11, x9, x6
    91bc:	aa0b03e1 	mov	x1, x11
    91c0:	9b0b7d46 	mul	x6, x10, x11
    91c4:	93c380a5 	extr	x5, x5, x3, #32
    91c8:	eb0500df 	cmp	x6, x5
    91cc:	540000a9 	b.ls	91e0 <__divti3+0x160>  // b.plast
    91d0:	ab050105 	adds	x5, x8, x5
    91d4:	d1000561 	sub	x1, x11, #0x1
    91d8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    91dc:	54000f48 	b.hi	93c4 <__divti3+0x344>  // b.pmore
    91e0:	cb0600a6 	sub	x6, x5, x6
    91e4:	9ac908cb 	udiv	x11, x6, x9
    91e8:	9b099969 	msub	x9, x11, x9, x6
    91ec:	aa0b03e5 	mov	x5, x11
    91f0:	9b0b7d4a 	mul	x10, x10, x11
    91f4:	b3607d23 	bfi	x3, x9, #32, #32
    91f8:	eb03015f 	cmp	x10, x3
    91fc:	540000a9 	b.ls	9210 <__divti3+0x190>  // b.plast
    9200:	ab030103 	adds	x3, x8, x3
    9204:	d1000565 	sub	x5, x11, #0x1
    9208:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    920c:	54000e28 	b.hi	93d0 <__divti3+0x350>  // b.pmore
    9210:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9214:	92407c48 	and	x8, x2, #0xffffffff
    9218:	2a0503e5 	mov	w5, w5
    921c:	d360fc42 	lsr	x2, x2, #32
    9220:	d360fc26 	lsr	x6, x1, #32
    9224:	cb0a0063 	sub	x3, x3, x10
    9228:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    922c:	9b087caa 	mul	x10, x5, x8
    9230:	9b087cc8 	mul	x8, x6, x8
    9234:	9b0220a5 	madd	x5, x5, x2, x8
    9238:	9b027cc6 	mul	x6, x6, x2
    923c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9240:	8b0900c5 	add	x5, x6, x9
    9244:	eb02011f 	cmp	x8, x2
    9248:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    924c:	8b4280c6 	add	x6, x6, x2, lsr #32
    9250:	eb06007f 	cmp	x3, x6
    9254:	540000e3 	b.cc	9270 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    9258:	92407d4a 	and	x10, x10, #0xffffffff
    925c:	9ac72000 	lsl	x0, x0, x7
    9260:	8b028142 	add	x2, x10, x2, lsl #32
    9264:	eb02001f 	cmp	x0, x2
    9268:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    926c:	54000a01 	b.ne	93ac <__divti3+0x32c>  // b.any
    9270:	d1000420 	sub	x0, x1, #0x1
    9274:	d2800001 	mov	x1, #0x0                   	// #0
    9278:	17ffffb4 	b	9148 <__divti3+0xc8>
    927c:	b5000062 	cbnz	x2, 9288 <__divti3+0x208>
    9280:	d2800022 	mov	x2, #0x1                   	// #1
    9284:	9ac30846 	udiv	x6, x2, x3
    9288:	dac010c8 	clz	x8, x6
    928c:	b5000408 	cbnz	x8, 930c <__divti3+0x28c>
    9290:	d360fcc9 	lsr	x9, x6, #32
    9294:	92407cc5 	and	x5, x6, #0xffffffff
    9298:	cb060023 	sub	x3, x1, x6
    929c:	d2800021 	mov	x1, #0x1                   	// #1
    92a0:	9ac90868 	udiv	x8, x3, x9
    92a4:	9b098d03 	msub	x3, x8, x9, x3
    92a8:	aa0803e0 	mov	x0, x8
    92ac:	9b057d02 	mul	x2, x8, x5
    92b0:	93c78063 	extr	x3, x3, x7, #32
    92b4:	eb03005f 	cmp	x2, x3
    92b8:	540000a9 	b.ls	92cc <__divti3+0x24c>  // b.plast
    92bc:	ab0300c3 	adds	x3, x6, x3
    92c0:	d1000500 	sub	x0, x8, #0x1
    92c4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    92c8:	54000968 	b.hi	93f4 <__divti3+0x374>  // b.pmore
    92cc:	cb020063 	sub	x3, x3, x2
    92d0:	9ac90862 	udiv	x2, x3, x9
    92d4:	aa0203e8 	mov	x8, x2
    92d8:	9b098c42 	msub	x2, x2, x9, x3
    92dc:	aa0703e3 	mov	x3, x7
    92e0:	9b057d05 	mul	x5, x8, x5
    92e4:	b3607c43 	bfi	x3, x2, #32, #32
    92e8:	eb0300bf 	cmp	x5, x3
    92ec:	540000c9 	b.ls	9304 <__divti3+0x284>  // b.plast
    92f0:	ab0300c2 	adds	x2, x6, x3
    92f4:	d1000503 	sub	x3, x8, #0x1
    92f8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    92fc:	d1000908 	sub	x8, x8, #0x2
    9300:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9304:	aa008100 	orr	x0, x8, x0, lsl #32
    9308:	17ffff90 	b	9148 <__divti3+0xc8>
    930c:	9ac820c6 	lsl	x6, x6, x8
    9310:	d2800803 	mov	x3, #0x40                  	// #64
    9314:	cb080063 	sub	x3, x3, x8
    9318:	d360fcc9 	lsr	x9, x6, #32
    931c:	9ac82027 	lsl	x7, x1, x8
    9320:	92407cc5 	and	x5, x6, #0xffffffff
    9324:	9ac32422 	lsr	x2, x1, x3
    9328:	9ac32403 	lsr	x3, x0, x3
    932c:	aa070063 	orr	x3, x3, x7
    9330:	9ac9084a 	udiv	x10, x2, x9
    9334:	9ac82007 	lsl	x7, x0, x8
    9338:	9b098940 	msub	x0, x10, x9, x2
    933c:	aa0a03e1 	mov	x1, x10
    9340:	9b0a7ca2 	mul	x2, x5, x10
    9344:	93c38000 	extr	x0, x0, x3, #32
    9348:	eb00005f 	cmp	x2, x0
    934c:	540000a9 	b.ls	9360 <__divti3+0x2e0>  // b.plast
    9350:	ab0000c0 	adds	x0, x6, x0
    9354:	d1000541 	sub	x1, x10, #0x1
    9358:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    935c:	54000468 	b.hi	93e8 <__divti3+0x368>  // b.pmore
    9360:	cb020000 	sub	x0, x0, x2
    9364:	9ac9080a 	udiv	x10, x0, x9
    9368:	9b098140 	msub	x0, x10, x9, x0
    936c:	aa0a03e2 	mov	x2, x10
    9370:	9b0a7ca8 	mul	x8, x5, x10
    9374:	b3607c03 	bfi	x3, x0, #32, #32
    9378:	eb03011f 	cmp	x8, x3
    937c:	540000a9 	b.ls	9390 <__divti3+0x310>  // b.plast
    9380:	ab0300c3 	adds	x3, x6, x3
    9384:	d1000542 	sub	x2, x10, #0x1
    9388:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    938c:	54000288 	b.hi	93dc <__divti3+0x35c>  // b.pmore
    9390:	cb080063 	sub	x3, x3, x8
    9394:	aa018041 	orr	x1, x2, x1, lsl #32
    9398:	17ffffc2 	b	92a0 <__divti3+0x220>
    939c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    93a0:	d2800001 	mov	x1, #0x0                   	// #0
    93a4:	9a9f87e0 	cset	x0, ls	// ls = plast
    93a8:	17ffff68 	b	9148 <__divti3+0xc8>
    93ac:	aa0103e0 	mov	x0, x1
    93b0:	d2800001 	mov	x1, #0x0                   	// #0
    93b4:	17ffff65 	b	9148 <__divti3+0xc8>
    93b8:	d1000860 	sub	x0, x3, #0x2
    93bc:	8b0600a5 	add	x5, x5, x6
    93c0:	17ffff52 	b	9108 <__divti3+0x88>
    93c4:	d1000961 	sub	x1, x11, #0x2
    93c8:	8b0800a5 	add	x5, x5, x8
    93cc:	17ffff85 	b	91e0 <__divti3+0x160>
    93d0:	d1000965 	sub	x5, x11, #0x2
    93d4:	8b080063 	add	x3, x3, x8
    93d8:	17ffff8e 	b	9210 <__divti3+0x190>
    93dc:	d1000942 	sub	x2, x10, #0x2
    93e0:	8b060063 	add	x3, x3, x6
    93e4:	17ffffeb 	b	9390 <__divti3+0x310>
    93e8:	d1000941 	sub	x1, x10, #0x2
    93ec:	8b060000 	add	x0, x0, x6
    93f0:	17ffffdc 	b	9360 <__divti3+0x2e0>
    93f4:	d1000900 	sub	x0, x8, #0x2
    93f8:	8b060063 	add	x3, x3, x6
    93fc:	17ffffb4 	b	92cc <__divti3+0x24c>

0000000000009400 <__modti3>:
    9400:	d503245f 	bti	c
    9404:	d2800004 	mov	x4, #0x0                   	// #0
    9408:	b6f80081 	tbz	x1, #63, 9418 <__modti3+0x18>
    940c:	eb0003e0 	negs	x0, x0
    9410:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9414:	da0103e1 	ngc	x1, x1
    9418:	f100007f 	cmp	x3, #0x0
    941c:	5400128b 	b.lt	966c <__modti3+0x26c>  // b.tstop
    9420:	aa0003e7 	mov	x7, x0
    9424:	aa0103e6 	mov	x6, x1
    9428:	540004e1 	b.ne	94c4 <__modti3+0xc4>  // b.any
    942c:	eb02003f 	cmp	x1, x2
    9430:	54000dc2 	b.cs	95e8 <__modti3+0x1e8>  // b.hs, b.nlast
    9434:	dac01043 	clz	x3, x2
    9438:	aa0303e5 	mov	x5, x3
    943c:	b40000e3 	cbz	x3, 9458 <__modti3+0x58>
    9440:	4b0303e6 	neg	w6, w3
    9444:	9ac32021 	lsl	x1, x1, x3
    9448:	9ac32042 	lsl	x2, x2, x3
    944c:	9ac62406 	lsr	x6, x0, x6
    9450:	aa0100c6 	orr	x6, x6, x1
    9454:	9ac32007 	lsl	x7, x0, x3
    9458:	d360fc40 	lsr	x0, x2, #32
    945c:	92407c43 	and	x3, x2, #0xffffffff
    9460:	9ac008c1 	udiv	x1, x6, x0
    9464:	9b009826 	msub	x6, x1, x0, x6
    9468:	9b017c61 	mul	x1, x3, x1
    946c:	93c780c6 	extr	x6, x6, x7, #32
    9470:	eb06003f 	cmp	x1, x6
    9474:	540000a9 	b.ls	9488 <__modti3+0x88>  // b.plast
    9478:	ab060046 	adds	x6, x2, x6
    947c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9480:	8b0200c8 	add	x8, x6, x2
    9484:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9488:	cb0100c6 	sub	x6, x6, x1
    948c:	9ac008c8 	udiv	x8, x6, x0
    9490:	9b009901 	msub	x1, x8, x0, x6
    9494:	aa0703e0 	mov	x0, x7
    9498:	9b087c63 	mul	x3, x3, x8
    949c:	b3607c20 	bfi	x0, x1, #32, #32
    94a0:	eb00007f 	cmp	x3, x0
    94a4:	54001088 	b.hi	96b4 <__modti3+0x2b4>  // b.pmore
    94a8:	cb030000 	sub	x0, x0, x3
    94ac:	9ac52400 	lsr	x0, x0, x5
    94b0:	d2800001 	mov	x1, #0x0                   	// #0
    94b4:	b4000064 	cbz	x4, 94c0 <__modti3+0xc0>
    94b8:	eb0003e0 	negs	x0, x0
    94bc:	da0103e1 	ngc	x1, x1
    94c0:	d65f03c0 	ret
    94c4:	dac01066 	clz	x6, x3
    94c8:	eb03003f 	cmp	x1, x3
    94cc:	54ffff43 	b.cc	94b4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    94d0:	93407cc5 	sxtw	x5, w6
    94d4:	d2800808 	mov	x8, #0x40                  	// #64
    94d8:	cb050108 	sub	x8, x8, x5
    94dc:	9ac62063 	lsl	x3, x3, x6
    94e0:	9ac62025 	lsl	x5, x1, x6
    94e4:	9ac82447 	lsr	x7, x2, x8
    94e8:	aa0300e7 	orr	x7, x7, x3
    94ec:	9ac82423 	lsr	x3, x1, x8
    94f0:	92407cec 	and	x12, x7, #0xffffffff
    94f4:	d360fcea 	lsr	x10, x7, #32
    94f8:	9ac82401 	lsr	x1, x0, x8
    94fc:	aa050021 	orr	x1, x1, x5
    9500:	9ac62042 	lsl	x2, x2, x6
    9504:	9ac62000 	lsl	x0, x0, x6
    9508:	9aca086b 	udiv	x11, x3, x10
    950c:	9b0a8d63 	msub	x3, x11, x10, x3
    9510:	aa0b03e5 	mov	x5, x11
    9514:	9b0b7d89 	mul	x9, x12, x11
    9518:	93c18063 	extr	x3, x3, x1, #32
    951c:	eb03013f 	cmp	x9, x3
    9520:	540000a9 	b.ls	9534 <__modti3+0x134>  // b.plast
    9524:	ab0300e3 	adds	x3, x7, x3
    9528:	d1000565 	sub	x5, x11, #0x1
    952c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9530:	54001168 	b.hi	975c <__modti3+0x35c>  // b.pmore
    9534:	cb090063 	sub	x3, x3, x9
    9538:	9aca086b 	udiv	x11, x3, x10
    953c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9540:	aa0b03e9 	mov	x9, x11
    9544:	9b0b7d8c 	mul	x12, x12, x11
    9548:	b3607d41 	bfi	x1, x10, #32, #32
    954c:	eb01019f 	cmp	x12, x1
    9550:	540000a9 	b.ls	9564 <__modti3+0x164>  // b.plast
    9554:	ab0100e1 	adds	x1, x7, x1
    9558:	d1000569 	sub	x9, x11, #0x1
    955c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9560:	54000f88 	b.hi	9750 <__modti3+0x350>  // b.pmore
    9564:	aa058123 	orr	x3, x9, x5, lsl #32
    9568:	92407c4b 	and	x11, x2, #0xffffffff
    956c:	2a0903e9 	mov	w9, w9
    9570:	d360fc4a 	lsr	x10, x2, #32
    9574:	d360fc63 	lsr	x3, x3, #32
    9578:	cb0c0021 	sub	x1, x1, x12
    957c:	aa0a03ec 	mov	x12, x10
    9580:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9584:	9b0b7d25 	mul	x5, x9, x11
    9588:	9b0b7c6b 	mul	x11, x3, x11
    958c:	9b0a2d29 	madd	x9, x9, x10, x11
    9590:	92407caa 	and	x10, x5, #0xffffffff
    9594:	9b0c7c63 	mul	x3, x3, x12
    9598:	8b458125 	add	x5, x9, x5, lsr #32
    959c:	8b0d0069 	add	x9, x3, x13
    95a0:	eb05017f 	cmp	x11, x5
    95a4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    95a8:	8b058149 	add	x9, x10, x5, lsl #32
    95ac:	8b458063 	add	x3, x3, x5, lsr #32
    95b0:	eb03003f 	cmp	x1, x3
    95b4:	54000063 	b.cc	95c0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    95b8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    95bc:	54000082 	b.cs	95cc <__modti3+0x1cc>  // b.hs, b.nlast
    95c0:	eb020129 	subs	x9, x9, x2
    95c4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    95c8:	cb070063 	sub	x3, x3, x7
    95cc:	eb090000 	subs	x0, x0, x9
    95d0:	da030021 	sbc	x1, x1, x3
    95d4:	9ac62400 	lsr	x0, x0, x6
    95d8:	9ac82028 	lsl	x8, x1, x8
    95dc:	aa000100 	orr	x0, x8, x0
    95e0:	9ac62421 	lsr	x1, x1, x6
    95e4:	17ffffb4 	b	94b4 <__modti3+0xb4>
    95e8:	b5000062 	cbnz	x2, 95f4 <__modti3+0x1f4>
    95ec:	d2800023 	mov	x3, #0x1                   	// #1
    95f0:	9ac20862 	udiv	x2, x3, x2
    95f4:	dac01048 	clz	x8, x2
    95f8:	aa0803e5 	mov	x5, x8
    95fc:	b5000668 	cbnz	x8, 96c8 <__modti3+0x2c8>
    9600:	cb020020 	sub	x0, x1, x2
    9604:	d360fc49 	lsr	x9, x2, #32
    9608:	92407c4a 	and	x10, x2, #0xffffffff
    960c:	9ac90801 	udiv	x1, x0, x9
    9610:	9b098020 	msub	x0, x1, x9, x0
    9614:	9b0a7c21 	mul	x1, x1, x10
    9618:	93c78000 	extr	x0, x0, x7, #32
    961c:	eb00003f 	cmp	x1, x0
    9620:	540000a9 	b.ls	9634 <__modti3+0x234>  // b.plast
    9624:	ab000040 	adds	x0, x2, x0
    9628:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    962c:	8b020003 	add	x3, x0, x2
    9630:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9634:	cb010001 	sub	x1, x0, x1
    9638:	9ac90820 	udiv	x0, x1, x9
    963c:	9b098403 	msub	x3, x0, x9, x1
    9640:	aa0703e1 	mov	x1, x7
    9644:	9b0a7c00 	mul	x0, x0, x10
    9648:	b3607c61 	bfi	x1, x3, #32, #32
    964c:	eb01001f 	cmp	x0, x1
    9650:	540000a9 	b.ls	9664 <__modti3+0x264>  // b.plast
    9654:	ab010041 	adds	x1, x2, x1
    9658:	8b020022 	add	x2, x1, x2
    965c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9660:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9664:	cb000020 	sub	x0, x1, x0
    9668:	17ffff91 	b	94ac <__modti3+0xac>
    966c:	eb0203e5 	negs	x5, x2
    9670:	aa0003e7 	mov	x7, x0
    9674:	da0303e8 	ngc	x8, x3
    9678:	aa0503e2 	mov	x2, x5
    967c:	aa0803e3 	mov	x3, x8
    9680:	aa0103e6 	mov	x6, x1
    9684:	b4ffed48 	cbz	x8, 942c <__modti3+0x2c>
    9688:	eb01011f 	cmp	x8, x1
    968c:	54fff148 	b.hi	94b4 <__modti3+0xb4>  // b.pmore
    9690:	dac01109 	clz	x9, x8
    9694:	2a0903e6 	mov	w6, w9
    9698:	b5fff1c9 	cbnz	x9, 94d0 <__modti3+0xd0>
    969c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    96a0:	54000068 	b.hi	96ac <__modti3+0x2ac>  // b.pmore
    96a4:	eb050007 	subs	x7, x0, x5
    96a8:	da080021 	sbc	x1, x1, x8
    96ac:	aa0703e0 	mov	x0, x7
    96b0:	17ffff81 	b	94b4 <__modti3+0xb4>
    96b4:	ab000040 	adds	x0, x2, x0
    96b8:	8b020002 	add	x2, x0, x2
    96bc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    96c0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    96c4:	17ffff79 	b	94a8 <__modti3+0xa8>
    96c8:	9ac82042 	lsl	x2, x2, x8
    96cc:	d2800803 	mov	x3, #0x40                  	// #64
    96d0:	cb080063 	sub	x3, x3, x8
    96d4:	d360fc49 	lsr	x9, x2, #32
    96d8:	9ac82027 	lsl	x7, x1, x8
    96dc:	92407c4a 	and	x10, x2, #0xffffffff
    96e0:	9ac32426 	lsr	x6, x1, x3
    96e4:	9ac32403 	lsr	x3, x0, x3
    96e8:	aa070063 	orr	x3, x3, x7
    96ec:	9ac908c1 	udiv	x1, x6, x9
    96f0:	9ac82007 	lsl	x7, x0, x8
    96f4:	9b099820 	msub	x0, x1, x9, x6
    96f8:	9b017d41 	mul	x1, x10, x1
    96fc:	93c38000 	extr	x0, x0, x3, #32
    9700:	eb00003f 	cmp	x1, x0
    9704:	540000a9 	b.ls	9718 <__modti3+0x318>  // b.plast
    9708:	ab000040 	adds	x0, x2, x0
    970c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9710:	8b020006 	add	x6, x0, x2
    9714:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9718:	cb010000 	sub	x0, x0, x1
    971c:	9ac90801 	udiv	x1, x0, x9
    9720:	9b098026 	msub	x6, x1, x9, x0
    9724:	aa0303e0 	mov	x0, x3
    9728:	9b017d41 	mul	x1, x10, x1
    972c:	b3607cc0 	bfi	x0, x6, #32, #32
    9730:	eb00003f 	cmp	x1, x0
    9734:	540000a9 	b.ls	9748 <__modti3+0x348>  // b.plast
    9738:	ab000040 	adds	x0, x2, x0
    973c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9740:	8b020003 	add	x3, x0, x2
    9744:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9748:	cb010000 	sub	x0, x0, x1
    974c:	17ffffb0 	b	960c <__modti3+0x20c>
    9750:	d1000969 	sub	x9, x11, #0x2
    9754:	8b070021 	add	x1, x1, x7
    9758:	17ffff83 	b	9564 <__modti3+0x164>
    975c:	d1000965 	sub	x5, x11, #0x2
    9760:	8b070063 	add	x3, x3, x7
    9764:	17ffff74 	b	9534 <__modti3+0x134>
    9768:	d503201f 	nop
    976c:	d503201f 	nop

0000000000009770 <atexit>:
    9770:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9774:	f00000a2 	adrp	x2, 20000 <__data_start>
    9778:	d2800001 	mov	x1, #0x0                   	// #0
    977c:	910003fd 	mov	x29, sp
    9780:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9784:	f9400442 	ldr	x2, [x2, #8]
    9788:	17ffe422 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000978c <_fini>:
    978c:	d503201f 	nop
    9790:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9794:	910003fd 	mov	x29, sp
    9798:	a8c17bfd 	ldp	x29, x30, [sp], #16
    979c:	d65f03c0 	ret
