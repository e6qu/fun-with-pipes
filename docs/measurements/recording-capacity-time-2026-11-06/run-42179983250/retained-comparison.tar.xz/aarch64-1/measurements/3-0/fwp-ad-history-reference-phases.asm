
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__modti3+0x280>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911280a5 	add	x5, x5, #0x4a0
    2aa0:	b0000044 	adrp	x4, b000 <__modti3+0x280>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9112a084 	add	x4, x4, #0x4a8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000590 	bl	4110 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10c40>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9006420 	str	x0, [x1, #200]
    2b2c:	94000799 	bl	4990 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2b34:	911ee000 	add	x0, x0, #0x7b8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x3d0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91308042 	add	x2, x2, #0xc20
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435aa0 	ldr	w0, [x21, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2c4c:	911fa000 	add	x0, x0, #0x7e8
    2c50:	94000530 	bl	4110 <fwp_trap>
    2c54:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2c58:	911f2000 	add	x0, x0, #0x7c8
    2c5c:	9400052d 	bl	4110 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2ca0:	91210000 	add	x0, x0, #0x840
    2ca4:	9400051b 	bl	4110 <fwp_trap>
    2ca8:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2cac:	91204000 	add	x0, x0, #0x810
    2cb0:	94000518 	bl	4110 <fwp_trap>
    2cb4:	b0000040 	adrp	x0, b000 <__modti3+0x280>
    2cb8:	9121a000 	add	x0, x0, #0x868
    2cbc:	94000515 	bl	4110 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91016000 	add	x0, x0, #0x58
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91016021 	add	x1, x1, #0x58
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91016000 	add	x0, x0, #0x58
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91016021 	add	x1, x1, #0x58
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <__modti3+0x280>
    2eb4:	913b4021 	add	x1, x1, #0xed0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3050:	9104a000 	add	x0, x0, #0x128
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <__modti3+0x280>
    3118:	913ac021 	add	x1, x1, #0xeb0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3150:	91050000 	add	x0, x0, #0x140
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__modti3+0x280>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__modti3+0x280>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	90000058 	adrp	x24, b000 <__modti3+0x280>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	91062042 	add	x2, x2, #0x188
    31e0:	910782d6 	add	x22, x22, #0x1e0
    31e4:	9130e318 	add	x24, x24, #0xc38
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__modti3+0x280>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	91076323 	add	x3, x25, #0x1d8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	9107c000 	add	x0, x0, #0x1f0
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3570:	9104a000 	add	x0, x0, #0x128
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__modti3+0x280>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9107e021 	add	x1, x1, #0x1f8
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__modti3+0x280>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91080021 	add	x1, x1, #0x200
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__modti3+0x280>
    37e0:	91082021 	add	x1, x1, #0x208
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	90000044 	adrp	x4, b000 <__modti3+0x280>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	91084084 	add	x4, x4, #0x210
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe3 	bl	27f0 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc3c 	bl	2960 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc27 	bl	2920 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb70 	bl	26d0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffba8 	bl	27d0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb99 	bl	27d0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb51 	bl	26d0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb5d 	bl	2710 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbed 	bl	2960 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	90000044 	adrp	x4, b000 <__modti3+0x280>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	9108a084 	add	x4, x4, #0x228
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb6e 	bl	27f0 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb5d 	bl	27d0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbbd 	bl	2960 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	90000044 	adrp	x4, b000 <__modti3+0x280>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	91086084 	add	x4, x4, #0x218
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb46 	bl	27f0 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb30 	bl	27d0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb04 	bl	27d0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb20 	bl	2880 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c0c:	91174042 	add	x2, x2, #0x5d0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	90000041 	adrp	x1, b000 <__modti3+0x280>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	9108c021 	add	x1, x1, #0x230
    3c68:	9108e000 	add	x0, x0, #0x238
    3c6c:	97fffae9 	bl	2810 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb13 	bl	2920 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac3 	bl	2800 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	90000042 	adrp	x2, b000 <__modti3+0x280>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	91096042 	add	x2, x2, #0x258
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffae6 	b	28f0 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffac6 	bl	2880 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3d78:	91134061 	add	x1, x3, #0x4d0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3d88:	91174262 	add	x2, x19, #0x5d0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	90000042 	adrp	x2, b000 <__modti3+0x280>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3dbc:	91144021 	add	x1, x1, #0x510
    3dc0:	3dc3b843 	ldr	q3, [x2, #3808]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3dec:	91134063 	add	x3, x3, #0x4d0
    3df0:	9115c084 	add	x4, x4, #0x570
    3df4:	91174266 	add	x6, x19, #0x5d0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaa9 	bl	2910 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91174275 	add	x21, x19, #0x5d0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa93 	bl	2910 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	90000040 	adrp	x0, b000 <__modti3+0x280>
    3ed8:	910b8000 	add	x0, x0, #0x2e0
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffacc 	bl	2a10 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91174273 	add	x19, x19, #0x5d0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9401400 	ldr	x0, [x0, #40]
    4004:	b7f80760 	tbnz	x0, #63, 40f0 <fwp_tape_buffers_release+0x100>
    4008:	f9401a61 	ldr	x1, [x19, #48]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    403c:	910bc000 	add	x0, x0, #0x2f0
    4040:	97fffa74 	bl	2a10 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	910bc000 	add	x0, x0, #0x2f0
    4078:	97fffa66 	bl	2a10 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400a61 	ldp	q1, q2, [x19]
    40b8:	f90062d4 	str	x20, [x22, #192]
    40bc:	4f000400 	movi	v0.4s, #0x0
    40c0:	ad000aa1 	stp	q1, q2, [x21]
    40c4:	3dc00a61 	ldr	q1, [x19, #32]
    40c8:	3d800aa1 	str	q1, [x21, #32]
    40cc:	f9401a60 	ldr	x0, [x19, #48]
    40d0:	f9001aa0 	str	x0, [x21, #48]
    40d4:	f9001a7f 	str	xzr, [x19, #48]
    40d8:	ad000260 	stp	q0, q0, [x19]
    40dc:	3d800a60 	str	q0, [x19, #32]
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40ec:	d65f03c0 	ret
    40f0:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    40f4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f8:	910bc000 	add	x0, x0, #0x2f0
    40fc:	97fffa45 	bl	2a10 <getenv@plt>
    4100:	b5fffa40 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    4104:	17ffffd6 	b	405c <fwp_tape_buffers_release+0x6c>
    4108:	d503201f 	nop
    410c:	d503201f 	nop

0000000000004110 <fwp_trap>:
    4110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4114:	900000e2 	adrp	x2, 20000 <__data_start>
    4118:	d53bd041 	mrs	x1, tpidr_el0
    411c:	910003fd 	mov	x29, sp
    4120:	f9403c42 	ldr	x2, [x2, #120]
    4124:	91400021 	add	x1, x1, #0x0, lsl #12
    4128:	91004021 	add	x1, x1, #0x10
    412c:	a90153f3 	stp	x19, x20, [sp, #16]
    4130:	aa0003f3 	mov	x19, x0
    4134:	f9400034 	ldr	x20, [x1]
    4138:	b4000062 	cbz	x2, 4144 <fwp_trap+0x34>
    413c:	aa0203e0 	mov	x0, x2
    4140:	97fffa1c 	bl	29b0 <fflush@plt>
    4144:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4148:	f947ec00 	ldr	x0, [x0, #4056]
    414c:	f9400000 	ldr	x0, [x0]
    4150:	97fffa18 	bl	29b0 <fflush@plt>
    4154:	aa1303e3 	mov	x3, x19
    4158:	f0000022 	adrp	x2, b000 <__modti3+0x280>
    415c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    4160:	f947ea73 	ldr	x19, [x19, #4048]
    4164:	910c2042 	add	x2, x2, #0x308
    4168:	52800041 	mov	w1, #0x2                   	// #2
    416c:	f9400260 	ldr	x0, [x19]
    4170:	97fff9e0 	bl	28f0 <__fprintf_chk@plt>
    4174:	b40000b4 	cbz	x20, 4188 <fwp_trap+0x78>
    4178:	f9400260 	ldr	x0, [x19]
    417c:	97fffa0d 	bl	29b0 <fflush@plt>
    4180:	52800ca0 	mov	w0, #0x65                  	// #101
    4184:	97fffa1b 	bl	29f0 <_Exit@plt>
    4188:	52800ca0 	mov	w0, #0x65                  	// #101
    418c:	97fff969 	bl	2730 <exit@plt>

0000000000004190 <fwp_rc_forget_slot.part.0>:
    4190:	ca404401 	eor	x1, x0, x0, lsr #17
    4194:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4198:	ca412421 	eor	x1, x1, x1, lsr #9
    419c:	910003fd 	mov	x29, sp
    41a0:	92401c21 	and	x1, x1, #0xff
    41a4:	f9000bf3 	str	x19, [sp, #16]
    41a8:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    41ac:	91174262 	add	x2, x19, #0x5d0
    41b0:	910a2423 	add	x3, x1, #0x289
    41b4:	8b010c41 	add	x1, x2, x1, lsl #3
    41b8:	8b030c43 	add	x3, x2, x3, lsl #3
    41bc:	f94a2421 	ldr	x1, [x1, #5192]
    41c0:	b50000a1 	cbnz	x1, 41d4 <fwp_rc_forget_slot.part.0+0x44>
    41c4:	14000012 	b	420c <fwp_rc_forget_slot.part.0+0x7c>
    41c8:	91004023 	add	x3, x1, #0x10
    41cc:	f9400821 	ldr	x1, [x1, #16]
    41d0:	b40001e1 	cbz	x1, 420c <fwp_rc_forget_slot.part.0+0x7c>
    41d4:	f9400022 	ldr	x2, [x1]
    41d8:	eb02001f 	cmp	x0, x2
    41dc:	54ffff61 	b.ne	41c8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41e0:	f9400060 	ldr	x0, [x3]
    41e4:	91174273 	add	x19, x19, #0x5d0
    41e8:	f9400801 	ldr	x1, [x0, #16]
    41ec:	f9000061 	str	x1, [x3]
    41f0:	97fff9d4 	bl	2940 <free@plt>
    41f4:	f94e2660 	ldr	x0, [x19, #7240]
    41f8:	d1000400 	sub	x0, x0, #0x1
    41fc:	f90e2660 	str	x0, [x19, #7240]
    4200:	f9400bf3 	ldr	x19, [sp, #16]
    4204:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4208:	d65f03c0 	ret
    420c:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4210:	910c6000 	add	x0, x0, #0x318
    4214:	97ffffbf 	bl	4110 <fwp_trap>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_rc_prepare_chunk>:
    4220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4224:	910003fd 	mov	x29, sp
    4228:	a9025bf5 	stp	x21, x22, [sp, #32]
    422c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4230:	911742c2 	add	x2, x22, #0x5d0
    4234:	b9401c03 	ldr	w3, [x0, #28]
    4238:	aa0103f5 	mov	x21, x1
    423c:	a90153f3 	stp	x19, x20, [sp, #16]
    4240:	aa0003f4 	mov	x20, x0
    4244:	f94e2440 	ldr	x0, [x2, #7240]
    4248:	b4000440 	cbz	x0, 42d0 <fwp_rc_prepare_chunk+0xb0>
    424c:	d2800013 	mov	x19, #0x0                   	// #0
    4250:	35000203 	cbnz	w3, 4290 <fwp_rc_prepare_chunk+0x70>
    4254:	b4000361 	cbz	x1, 42c0 <fwp_rc_prepare_chunk+0xa0>
    4258:	f9401280 	ldr	x0, [x20, #32]
    425c:	97fff9b9 	bl	2940 <free@plt>
    4260:	aa1503e0 	mov	x0, x21
    4264:	d2800021 	mov	x1, #0x1                   	// #1
    4268:	97fff97e 	bl	2860 <calloc@plt>
    426c:	f9001280 	str	x0, [x20, #32]
    4270:	b5000460 	cbnz	x0, 42fc <fwp_rc_prepare_chunk+0xdc>
    4274:	97fffb6f 	bl	3030 <fwp_heap_oom>
    4278:	97ffffc6 	bl	4190 <fwp_rc_forget_slot.part.0>
    427c:	91000673 	add	x19, x19, #0x1
    4280:	b9401e83 	ldr	w3, [x20, #28]
    4284:	eb13007f 	cmp	x3, x19
    4288:	54000169 	b.ls	42b4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    428c:	d503201f 	nop
    4290:	f9401283 	ldr	x3, [x20, #32]
    4294:	8b130060 	add	x0, x3, x19
    4298:	38736863 	ldrb	w3, [x3, x19]
    429c:	7103fc7f 	cmp	w3, #0xff
    42a0:	54fffec0 	b.eq	4278 <fwp_rc_prepare_chunk+0x58>  // b.none
    42a4:	b9401e83 	ldr	w3, [x20, #28]
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb13007f 	cmp	x3, x19
    42b0:	54ffff08 	b.hi	4290 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42b4:	eb0302bf 	cmp	x21, x3
    42b8:	54000121 	b.ne	42dc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42bc:	b5000335 	cbnz	x21, 4320 <fwp_rc_prepare_chunk+0x100>
    42c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42cc:	d65f03c0 	ret
    42d0:	2a0303e3 	mov	w3, w3
    42d4:	eb0302bf 	cmp	x21, x3
    42d8:	54ffff20 	b.eq	42bc <fwp_rc_prepare_chunk+0x9c>  // b.none
    42dc:	911742c2 	add	x2, x22, #0x5d0
    42e0:	f9401280 	ldr	x0, [x20, #32]
    42e4:	f94e2841 	ldr	x1, [x2, #7248]
    42e8:	cb030021 	sub	x1, x1, x3
    42ec:	f90e2841 	str	x1, [x2, #7248]
    42f0:	97fff994 	bl	2940 <free@plt>
    42f4:	b5fffb75 	cbnz	x21, 4260 <fwp_rc_prepare_chunk+0x40>
    42f8:	f900129f 	str	xzr, [x20, #32]
    42fc:	911742d6 	add	x22, x22, #0x5d0
    4300:	f94e2ac0 	ldr	x0, [x22, #7248]
    4304:	b9001e95 	str	w21, [x20, #28]
    4308:	a94153f3 	ldp	x19, x20, [sp, #16]
    430c:	8b150000 	add	x0, x0, x21
    4310:	f90e2ac0 	str	x0, [x22, #7248]
    4314:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4318:	a8c37bfd 	ldp	x29, x30, [sp], #48
    431c:	d65f03c0 	ret
    4320:	f9401280 	ldr	x0, [x20, #32]
    4324:	aa1503e2 	mov	x2, x21
    4328:	a94153f3 	ldp	x19, x20, [sp, #16]
    432c:	52800001 	mov	w1, #0x0                   	// #0
    4330:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4334:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4338:	17fff946 	b	2850 <memset@plt>
    433c:	d503201f 	nop

0000000000004340 <fwp_heap_refill>:
    4340:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4344:	910003fd 	mov	x29, sp
    4348:	a9025bf5 	stp	x21, x22, [sp, #32]
    434c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4350:	911742b5 	add	x21, x21, #0x5d0
    4354:	aa0003f6 	mov	x22, x0
    4358:	d2800020 	mov	x0, #0x1                   	// #1
    435c:	a90153f3 	stp	x19, x20, [sp, #16]
    4360:	a90363f7 	stp	x23, x24, [sp, #48]
    4364:	2a0103f7 	mov	w23, w1
    4368:	2a0203f8 	mov	w24, w2
    436c:	97fffbd1 	bl	32b0 <fwp_heap_chunks>
    4370:	aa0003f3 	mov	x19, x0
    4374:	f949fea2 	ldr	x2, [x21, #5112]
    4378:	8b000800 	add	x0, x0, x0, lsl #2
    437c:	2a1703e1 	mov	w1, w23
    4380:	52800025 	mov	w5, #0x1                   	// #1
    4384:	d37df000 	lsl	x0, x0, #3
    4388:	910f0021 	add	x1, x1, #0x3c0
    438c:	8b000054 	add	x20, x2, x0
    4390:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4394:	52a00024 	mov	w4, #0x10000               	// #65536
    4398:	38206845 	strb	w5, [x2, x0]
    439c:	aa1403e0 	mov	x0, x20
    43a0:	39000698 	strb	w24, [x20, #1]
    43a4:	39000a97 	strb	w23, [x20, #2]
    43a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    43ac:	b9000681 	str	w1, [x20, #4]
    43b0:	2a0103e5 	mov	w5, w1
    43b4:	8b0300a2 	add	x2, x5, x3
    43b8:	1ac10881 	udiv	w1, w4, w1
    43bc:	9ac50842 	udiv	x2, x2, x5
    43c0:	b9000a81 	str	w1, [x20, #8]
    43c4:	92404021 	and	x1, x1, #0x1ffff
    43c8:	b9001a82 	str	w2, [x20, #24]
    43cc:	97ffff95 	bl	4220 <fwp_rc_prepare_chunk>
    43d0:	f949daa0 	ldr	x0, [x21, #5040]
    43d4:	29408a81 	ldp	w1, w2, [x20, #4]
    43d8:	8b134000 	add	x0, x0, x19, lsl #16
    43dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e0:	8b214003 	add	x3, x0, w1, uxtw
    43e4:	9ba20021 	umaddl	x1, w1, w2, x0
    43e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43ec:	a90086c3 	stp	x3, x1, [x22, #8]
    43f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43f8:	d65f03c0 	ret
    43fc:	d503201f 	nop

0000000000004400 <fwp_mem_free>:
    4400:	b40003c0 	cbz	x0, 4478 <fwp_mem_free+0x78>
    4404:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4408:	910003fd 	mov	x29, sp
    440c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4410:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4414:	911742a1 	add	x1, x21, #0x5d0
    4418:	a90153f3 	stp	x19, x20, [sp, #16]
    441c:	aa0003f3 	mov	x19, x0
    4420:	f949d823 	ldr	x3, [x1, #5040]
    4424:	f949ec22 	ldr	x2, [x1, #5080]
    4428:	cb030000 	sub	x0, x0, x3
    442c:	eb02401f 	cmp	x0, x2, lsl #16
    4430:	540001c2 	b.cs	4468 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4434:	d350fc16 	lsr	x22, x0, #16
    4438:	a90363f7 	stp	x23, x24, [sp, #48]
    443c:	f949fc22 	ldr	x2, [x1, #5112]
    4440:	8b160ad4 	add	x20, x22, x22, lsl #2
    4444:	d37df294 	lsl	x20, x20, #3
    4448:	ab140057 	adds	x23, x2, x20
    444c:	540000c0 	b.eq	4464 <fwp_mem_free+0x64>  // b.none
    4450:	38746842 	ldrb	w2, [x2, x20]
    4454:	7100045f 	cmp	w2, #0x1
    4458:	54000120 	b.eq	447c <fwp_mem_free+0x7c>  // b.none
    445c:	7100085f 	cmp	w2, #0x2
    4460:	540005e0 	b.eq	451c <fwp_mem_free+0x11c>  // b.none
    4464:	a94363f7 	ldp	x23, x24, [sp, #48]
    4468:	a94153f3 	ldp	x19, x20, [sp, #16]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4474:	d65f03c0 	ret
    4478:	d65f03c0 	ret
    447c:	f94012f8 	ldr	x24, [x23, #32]
    4480:	b94006e1 	ldr	w1, [x23, #4]
    4484:	f90023f9 	str	x25, [sp, #64]
    4488:	2a0103e2 	mov	w2, w1
    448c:	394006f9 	ldrb	w25, [x23, #1]
    4490:	39400af4 	ldrb	w20, [x23, #2]
    4494:	b4000158 	cbz	x24, 44bc <fwp_mem_free+0xbc>
    4498:	92403e76 	and	x22, x19, #0xffff
    449c:	9ac20ad6 	udiv	x22, x22, x2
    44a0:	38766b01 	ldrb	w1, [x24, x22]
    44a4:	8b160300 	add	x0, x24, x22
    44a8:	7103fc3f 	cmp	w1, #0xff
    44ac:	54000980 	b.eq	45dc <fwp_mem_free+0x1dc>  // b.none
    44b0:	38366b1f 	strb	wzr, [x24, x22]
    44b4:	b94006e1 	ldr	w1, [x23, #4]
    44b8:	2a0103e2 	mov	w2, w1
    44bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44c4:	cb390000 	sub	x0, x0, w25, uxtb
    44c8:	8b340074 	add	x20, x3, w20, uxtb
    44cc:	911742b5 	add	x21, x21, #0x5d0
    44d0:	1e630021 	ucvtf	d1, w1
    44d4:	d37ae400 	lsl	x0, x0, #6
    44d8:	8b140c14 	add	x20, x0, x20, lsl #3
    44dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e0:	f8746aa0 	ldr	x0, [x21, x20]
    44e4:	f94023f9 	ldr	x25, [sp, #64]
    44e8:	aa2003e0 	mvn	x0, x0
    44ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    44f0:	f9000260 	str	x0, [x19]
    44f4:	f8346ab3 	str	x19, [x21, x20]
    44f8:	f94a12a0 	ldr	x0, [x21, #5152]
    44fc:	1e612800 	fadd	d0, d0, d1
    4500:	a94153f3 	ldp	x19, x20, [sp, #16]
    4504:	cb020000 	sub	x0, x0, x2
    4508:	f90a12a0 	str	x0, [x21, #5152]
    450c:	fd0a22a0 	str	d0, [x21, #5184]
    4510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4514:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4518:	d65f03c0 	ret
    451c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4520:	8b000063 	add	x3, x3, x0
    4524:	eb03027f 	cmp	x19, x3
    4528:	54fff9e1 	b.ne	4464 <fwp_mem_free+0x64>  // b.any
    452c:	fd400ae1 	ldr	d1, [x23, #16]
    4530:	fd4a2020 	ldr	d0, [x1, #5184]
    4534:	f9400ae0 	ldr	x0, [x23, #16]
    4538:	7e61d821 	ucvtf	d1, d1
    453c:	f94a1022 	ldr	x2, [x1, #5152]
    4540:	f94012f3 	ldr	x19, [x23, #32]
    4544:	1e612800 	fadd	d0, d0, d1
    4548:	cb000042 	sub	x2, x2, x0
    454c:	f90a1022 	str	x2, [x1, #5152]
    4550:	fd0a2020 	str	d0, [x1, #5184]
    4554:	b40000b3 	cbz	x19, 4568 <fwp_mem_free+0x168>
    4558:	39400260 	ldrb	w0, [x19]
    455c:	7103fc1f 	cmp	w0, #0xff
    4560:	54000380 	b.eq	45d0 <fwp_mem_free+0x1d0>  // b.none
    4564:	3900027f 	strb	wzr, [x19]
    4568:	b9400ee2 	ldr	w2, [x23, #12]
    456c:	b4000142 	cbz	x2, 4594 <fwp_mem_free+0x194>
    4570:	911742a1 	add	x1, x21, #0x5d0
    4574:	8b160040 	add	x0, x2, x22
    4578:	8b000800 	add	x0, x0, x0, lsl #2
    457c:	f949fc21 	ldr	x1, [x1, #5112]
    4580:	8b140034 	add	x20, x1, x20
    4584:	8b000c20 	add	x0, x1, x0, lsl #3
    4588:	3802869f 	strb	wzr, [x20], #40
    458c:	eb00029f 	cmp	x20, x0
    4590:	54ffffc1 	b.ne	4588 <fwp_mem_free+0x188>  // b.any
    4594:	911742a0 	add	x0, x21, #0x5d0
    4598:	f94a1801 	ldr	x1, [x0, #5168]
    459c:	f949f803 	ldr	x3, [x0, #5104]
    45a0:	8b020021 	add	x1, x1, x2
    45a4:	f90a1801 	str	x1, [x0, #5168]
    45a8:	eb16007f 	cmp	x3, x22
    45ac:	54000049 	b.ls	45b4 <fwp_mem_free+0x1b4>  // b.plast
    45b0:	f909f816 	str	x22, [x0, #5104]
    45b4:	911742b5 	add	x21, x21, #0x5d0
    45b8:	f949f6a0 	ldr	x0, [x21, #5096]
    45bc:	eb16001f 	cmp	x0, x22
    45c0:	54fff529 	b.ls	4464 <fwp_mem_free+0x64>  // b.plast
    45c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45c8:	f909f6b6 	str	x22, [x21, #5096]
    45cc:	17ffffa7 	b	4468 <fwp_mem_free+0x68>
    45d0:	aa1303e0 	mov	x0, x19
    45d4:	97fffeef 	bl	4190 <fwp_rc_forget_slot.part.0>
    45d8:	17ffffe3 	b	4564 <fwp_mem_free+0x164>
    45dc:	97fffeed 	bl	4190 <fwp_rc_forget_slot.part.0>
    45e0:	17ffffb4 	b	44b0 <fwp_mem_free+0xb0>

00000000000045e4 <fwp_rc_wide_dup>:
    45e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e8:	910003fd 	mov	x29, sp
    45ec:	a90153f3 	stp	x19, x20, [sp, #16]
    45f0:	aa0003f3 	mov	x19, x0
    45f4:	ca404400 	eor	x0, x0, x0, lsr #17
    45f8:	f90013f5 	str	x21, [sp, #32]
    45fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4600:	ca402400 	eor	x0, x0, x0, lsr #9
    4604:	911742a2 	add	x2, x21, #0x5d0
    4608:	92401c00 	and	x0, x0, #0xff
    460c:	910a2403 	add	x3, x0, #0x289
    4610:	8b000c40 	add	x0, x2, x0, lsl #3
    4614:	8b030c54 	add	x20, x2, x3, lsl #3
    4618:	f94a2401 	ldr	x1, [x0, #5192]
    461c:	b50000a1 	cbnz	x1, 4630 <fwp_rc_wide_dup+0x4c>
    4620:	14000033 	b	46ec <fwp_rc_wide_dup+0x108>
    4624:	91004034 	add	x20, x1, #0x10
    4628:	f9400821 	ldr	x1, [x1, #16]
    462c:	b4000241 	cbz	x1, 4674 <fwp_rc_wide_dup+0x90>
    4630:	f9400022 	ldr	x2, [x1]
    4634:	eb02027f 	cmp	x19, x2
    4638:	54ffff61 	b.ne	4624 <fwp_rc_wide_dup+0x40>  // b.any
    463c:	f9400281 	ldr	x1, [x20]
    4640:	39400260 	ldrb	w0, [x19]
    4644:	7103f81f 	cmp	w0, #0xfe
    4648:	54000220 	b.eq	468c <fwp_rc_wide_dup+0xa8>  // b.none
    464c:	b40001a1 	cbz	x1, 4680 <fwp_rc_wide_dup+0x9c>
    4650:	f9400420 	ldr	x0, [x1, #8]
    4654:	b100041f 	cmn	x0, #0x1
    4658:	54000440 	b.eq	46e0 <fwp_rc_wide_dup+0xfc>  // b.none
    465c:	91000400 	add	x0, x0, #0x1
    4660:	f9000420 	str	x0, [x1, #8]
    4664:	a94153f3 	ldp	x19, x20, [sp, #16]
    4668:	f94013f5 	ldr	x21, [sp, #32]
    466c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4670:	d65f03c0 	ret
    4674:	39400260 	ldrb	w0, [x19]
    4678:	7103f81f 	cmp	w0, #0xfe
    467c:	54000100 	b.eq	469c <fwp_rc_wide_dup+0xb8>  // b.none
    4680:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4684:	910c6000 	add	x0, x0, #0x318
    4688:	97fffea2 	bl	4110 <fwp_trap>
    468c:	b4000081 	cbz	x1, 469c <fwp_rc_wide_dup+0xb8>
    4690:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4694:	910d0000 	add	x0, x0, #0x340
    4698:	97fffe9e 	bl	4110 <fwp_trap>
    469c:	d2800300 	mov	x0, #0x18                  	// #24
    46a0:	97fff860 	bl	2820 <malloc@plt>
    46a4:	b4000280 	cbz	x0, 46f4 <fwp_rc_wide_dup+0x110>
    46a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    46ac:	a9000413 	stp	x19, x1, [x0]
    46b0:	911742b5 	add	x21, x21, #0x5d0
    46b4:	f900081f 	str	xzr, [x0, #16]
    46b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46bc:	f9000280 	str	x0, [x20]
    46c0:	39000261 	strb	w1, [x19]
    46c4:	f94e26a0 	ldr	x0, [x21, #7240]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	91000400 	add	x0, x0, #0x1
    46d0:	f90e26a0 	str	x0, [x21, #7240]
    46d4:	f94013f5 	ldr	x21, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    46e4:	910da000 	add	x0, x0, #0x368
    46e8:	97fffe8a 	bl	4110 <fwp_trap>
    46ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46f0:	17ffffd4 	b	4640 <fwp_rc_wide_dup+0x5c>
    46f4:	97fffa4f 	bl	3030 <fwp_heap_oom>
    46f8:	d503201f 	nop
    46fc:	d503201f 	nop

0000000000004700 <fwp_closure_drop_push>:
    4700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4704:	910003fd 	mov	x29, sp
    4708:	a90153f3 	stp	x19, x20, [sp, #16]
    470c:	aa0003f3 	mov	x19, x0
    4710:	a9408014 	ldp	x20, x0, [x0, #8]
    4714:	a9025bf5 	stp	x21, x22, [sp, #32]
    4718:	aa0103f5 	mov	x21, x1
    471c:	a90363f7 	stp	x23, x24, [sp, #48]
    4720:	eb00029f 	cmp	x20, x0
    4724:	54000160 	b.eq	4750 <fwp_closure_drop_push+0x50>  // b.none
    4728:	f9400276 	ldr	x22, [x19]
    472c:	d37df297 	lsl	x23, x20, #3
    4730:	91000694 	add	x20, x20, #0x1
    4734:	f9000674 	str	x20, [x19, #8]
    4738:	a94153f3 	ldp	x19, x20, [sp, #16]
    473c:	f8376ad5 	str	x21, [x22, x23]
    4740:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4744:	a94363f7 	ldp	x23, x24, [sp, #48]
    4748:	a8c57bfd 	ldp	x29, x30, [sp], #80
    474c:	d65f03c0 	ret
    4750:	a9046bf9 	stp	x25, x26, [sp, #64]
    4754:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4758:	eb00029f 	cmp	x20, x0
    475c:	540003e8 	b.hi	47d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4760:	d37cee99 	lsl	x25, x20, #4
    4764:	d37ffa9a 	lsl	x26, x20, #1
    4768:	aa1903e0 	mov	x0, x25
    476c:	97fff82d 	bl	2820 <malloc@plt>
    4770:	aa0003f6 	mov	x22, x0
    4774:	b4000380 	cbz	x0, 47e4 <fwp_closure_drop_push+0xe4>
    4778:	aa1303f8 	mov	x24, x19
    477c:	aa1903e3 	mov	x3, x25
    4780:	d37df297 	lsl	x23, x20, #3
    4784:	aa1703e2 	mov	x2, x23
    4788:	f8418719 	ldr	x25, [x24], #24
    478c:	aa1903e1 	mov	x1, x25
    4790:	97fff810 	bl	27d0 <__memcpy_chk@plt>
    4794:	eb18033f 	cmp	x25, x24
    4798:	540000a0 	b.eq	47ac <fwp_closure_drop_push+0xac>  // b.none
    479c:	aa1903e0 	mov	x0, x25
    47a0:	97fff868 	bl	2940 <free@plt>
    47a4:	f9400674 	ldr	x20, [x19, #8]
    47a8:	d37df297 	lsl	x23, x20, #3
    47ac:	91000694 	add	x20, x20, #0x1
    47b0:	f9000276 	str	x22, [x19]
    47b4:	f9000a7a 	str	x26, [x19, #16]
    47b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47bc:	f9000674 	str	x20, [x19, #8]
    47c0:	f8376ad5 	str	x21, [x22, x23]
    47c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47d4:	d65f03c0 	ret
    47d8:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    47dc:	910e2000 	add	x0, x0, #0x388
    47e0:	97fffe4c 	bl	4110 <fwp_trap>
    47e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    47e8:	f947e863 	ldr	x3, [x3, #4048]
    47ec:	d2800262 	mov	x2, #0x13                  	// #19
    47f0:	d2800021 	mov	x1, #0x1                   	// #1
    47f4:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    47f8:	9104a000 	add	x0, x0, #0x128
    47fc:	f9400063 	ldr	x3, [x3]
    4800:	97fff860 	bl	2980 <fwrite@plt>
    4804:	d2800000 	mov	x0, #0x0                   	// #0
    4808:	97fff86a 	bl	29b0 <fflush@plt>
    480c:	52800cc0 	mov	w0, #0x66                  	// #102
    4810:	97fff878 	bl	29f0 <_Exit@plt>

0000000000004814 <fwp_closure_drop.part.0>:
    4814:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4818:	f0000021 	adrp	x1, b000 <__modti3+0x280>
    481c:	910003fd 	mov	x29, sp
    4820:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4824:	f947f463 	ldr	x3, [x3, #4072]
    4828:	a90153f3 	stp	x19, x20, [sp, #16]
    482c:	d10883ff 	sub	sp, sp, #0x220
    4830:	910003e2 	mov	x2, sp
    4834:	d53bd053 	mrs	x19, tpidr_el0
    4838:	910063f4 	add	x20, sp, #0x18
    483c:	3dc3bc20 	ldr	q0, [x1, #3824]
    4840:	91400264 	add	x4, x19, #0x0, lsl #12
    4844:	91004084 	add	x4, x4, #0x10
    4848:	aa0003e1 	mov	x1, x0
    484c:	aa0203e0 	mov	x0, x2
    4850:	f9400062 	ldr	x2, [x3]
    4854:	f9010fe2 	str	x2, [sp, #536]
    4858:	d2800002 	mov	x2, #0x0                   	// #0
    485c:	f90003f4 	str	x20, [sp]
    4860:	f9000080 	str	x0, [x4]
    4864:	3c8083e0 	stur	q0, [sp, #8]
    4868:	97ffffa6 	bl	4700 <fwp_closure_drop_push>
    486c:	f94007e0 	ldr	x0, [sp, #8]
    4870:	b40002e0 	cbz	x0, 48cc <fwp_closure_drop.part.0+0xb8>
    4874:	f90123f5 	str	x21, [sp, #576]
    4878:	900000f5 	adrp	x21, 20000 <__data_start>
    487c:	9101c2b5 	add	x21, x21, #0x70
    4880:	14000006 	b	4898 <fwp_closure_drop.part.0+0x84>
    4884:	f9400422 	ldr	x2, [x1, #8]
    4888:	52800001 	mov	w1, #0x0                   	// #0
    488c:	d63f0040 	blr	x2
    4890:	f94007e0 	ldr	x0, [sp, #8]
    4894:	b40001a0 	cbz	x0, 48c8 <fwp_closure_drop.part.0+0xb4>
    4898:	f94003e1 	ldr	x1, [sp]
    489c:	d1000400 	sub	x0, x0, #0x1
    48a0:	f90007e0 	str	x0, [sp, #8]
    48a4:	f94066a2 	ldr	x2, [x21, #200]
    48a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    48ac:	b9400001 	ldr	w1, [x0]
    48b0:	8b011441 	add	x1, x2, x1, lsl #5
    48b4:	f9400c21 	ldr	x1, [x1, #24]
    48b8:	b5fffe61 	cbnz	x1, 4884 <fwp_closure_drop.part.0+0x70>
    48bc:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    48c0:	910ea000 	add	x0, x0, #0x3a8
    48c4:	97fffe13 	bl	4110 <fwp_trap>
    48c8:	f94123f5 	ldr	x21, [sp, #576]
    48cc:	91400273 	add	x19, x19, #0x0, lsl #12
    48d0:	91004273 	add	x19, x19, #0x10
    48d4:	f94003e0 	ldr	x0, [sp]
    48d8:	f900027f 	str	xzr, [x19]
    48dc:	eb14001f 	cmp	x0, x20
    48e0:	54000040 	b.eq	48e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48e4:	97fff817 	bl	2940 <free@plt>
    48e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48ec:	f947f400 	ldr	x0, [x0, #4072]
    48f0:	f9410fe2 	ldr	x2, [sp, #536]
    48f4:	f9400001 	ldr	x1, [x0]
    48f8:	eb010042 	subs	x2, x2, x1
    48fc:	d2800001 	mov	x1, #0x0                   	// #0
    4900:	540000a1 	b.ne	4914 <fwp_closure_drop.part.0+0x100>  // b.any
    4904:	910883ff 	add	sp, sp, #0x220
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4910:	d65f03c0 	ret
    4914:	f90123f5 	str	x21, [sp, #576]
    4918:	97fff7da 	bl	2880 <__stack_chk_fail@plt>
    491c:	d503201f 	nop

0000000000004920 <fwp_tape_of>:
    4920:	aa0003e1 	mov	x1, x0
    4924:	92403c00 	and	x0, x0, #0xffff
    4928:	b40000e0 	cbz	x0, 4944 <fwp_tape_of+0x24>
    492c:	d1000402 	sub	x2, x0, #0x1
    4930:	900000e3 	adrp	x3, 20000 <__data_start>
    4934:	9101c060 	add	x0, x3, #0x70
    4938:	f9406800 	ldr	x0, [x0, #208]
    493c:	eb02001f 	cmp	x0, x2
    4940:	540000cc 	b.gt	4958 <fwp_tape_of+0x38>
    4944:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4948:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    494c:	910f6000 	add	x0, x0, #0x3d8
    4950:	910003fd 	mov	x29, sp
    4954:	97fffdef 	bl	4110 <fwp_trap>
    4958:	8b020440 	add	x0, x2, x2, lsl #1
    495c:	f9403863 	ldr	x3, [x3, #112]
    4960:	8b000842 	add	x2, x2, x0, lsl #2
    4964:	d37df042 	lsl	x2, x2, #3
    4968:	8b020060 	add	x0, x3, x2
    496c:	b9400404 	ldr	w4, [x0, #4]
    4970:	34fffea4 	cbz	w4, 4944 <fwp_tape_of+0x24>
    4974:	b8626862 	ldr	w2, [x3, x2]
    4978:	9350fc21 	asr	x1, x1, #16
    497c:	6b01005f 	cmp	w2, w1
    4980:	54fffe21 	b.ne	4944 <fwp_tape_of+0x24>  // b.any
    4984:	d65f03c0 	ret
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_now_ns>:
    4990:	d100c3ff 	sub	sp, sp, #0x30
    4994:	52800020 	mov	w0, #0x1                   	// #1
    4998:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    499c:	f947f442 	ldr	x2, [x2, #4072]
    49a0:	910023e1 	add	x1, sp, #0x8
    49a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    49a8:	910083fd 	add	x29, sp, #0x20
    49ac:	f9400043 	ldr	x3, [x2]
    49b0:	f9000fe3 	str	x3, [sp, #24]
    49b4:	d2800003 	mov	x3, #0x0                   	// #0
    49b8:	97fff77e 	bl	27b0 <clock_gettime@plt>
    49bc:	350002c0 	cbnz	w0, 4a14 <fwp_now_ns+0x84>
    49c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49c4:	d2994003 	mov	x3, #0xca00                	// #51712
    49c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49cc:	9b037c20 	mul	x0, x1, x3
    49d0:	9b437c21 	smulh	x1, x1, x3
    49d4:	ab020000 	adds	x0, x0, x2
    49d8:	937ffc42 	asr	x2, x2, #63
    49dc:	9a020021 	adc	x1, x1, x2
    49e0:	f100001f 	cmp	x0, #0x0
    49e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49e8:	b50001c1 	cbnz	x1, 4a20 <fwp_now_ns+0x90>
    49ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    49f0:	f947f421 	ldr	x1, [x1, #4072]
    49f4:	f9400fe3 	ldr	x3, [sp, #24]
    49f8:	f9400022 	ldr	x2, [x1]
    49fc:	eb020063 	subs	x3, x3, x2
    4a00:	d2800002 	mov	x2, #0x0                   	// #0
    4a04:	54000141 	b.ne	4a2c <fwp_now_ns+0x9c>  // b.any
    4a08:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a0c:	9100c3ff 	add	sp, sp, #0x30
    4a10:	d65f03c0 	ret
    4a14:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4a18:	9110a000 	add	x0, x0, #0x428
    4a1c:	97fffdbd 	bl	4110 <fwp_trap>
    4a20:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4a24:	91112000 	add	x0, x0, #0x448
    4a28:	97fffdba 	bl	4110 <fwp_trap>
    4a2c:	97fff795 	bl	2880 <__stack_chk_fail@plt>

0000000000004a30 <fwp_poll_events>:
    4a30:	d10103ff 	sub	sp, sp, #0x40
    4a34:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4a38:	f947f400 	ldr	x0, [x0, #4072]
    4a3c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a40:	910083fd 	add	x29, sp, #0x20
    4a44:	f9001bf3 	str	x19, [sp, #48]
    4a48:	900000f3 	adrp	x19, 20000 <__data_start>
    4a4c:	f9400001 	ldr	x1, [x0]
    4a50:	f9000fe1 	str	x1, [sp, #24]
    4a54:	d2800001 	mov	x1, #0x0                   	// #0
    4a58:	97ffffce 	bl	4990 <fwp_now_ns>
    4a5c:	9101c261 	add	x1, x19, #0x70
    4a60:	f9406c21 	ldr	x1, [x1, #216]
    4a64:	b4000e01 	cbz	x1, 4c24 <fwp_poll_events+0x1f4>
    4a68:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a6c:	14000005 	b	4a80 <fwp_poll_events+0x50>
    4a70:	f9408821 	ldr	x1, [x1, #272]
    4a74:	eb03005f 	cmp	x2, x3
    4a78:	9a83d042 	csel	x2, x2, x3, le
    4a7c:	b40000c1 	cbz	x1, 4a94 <fwp_poll_events+0x64>
    4a80:	f9403423 	ldr	x3, [x1, #104]
    4a84:	b6ffff62 	tbz	x2, #63, 4a70 <fwp_poll_events+0x40>
    4a88:	f9408821 	ldr	x1, [x1, #272]
    4a8c:	aa0303e2 	mov	x2, x3
    4a90:	b5ffff81 	cbnz	x1, 4a80 <fwp_poll_events+0x50>
    4a94:	b7f80c82 	tbnz	x2, #63, 4c24 <fwp_poll_events+0x1f4>
    4a98:	cb000042 	sub	x2, x2, x0
    4a9c:	f100005f 	cmp	x2, #0x0
    4aa0:	540003ad 	b.le	4b14 <fwp_poll_events+0xe4>
    4aa4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4aa8:	d2884804 	mov	x4, #0x4240                	// #16960
    4aac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4ab0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4ab4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4ab8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4abc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ac0:	9b407c40 	smulh	x0, x2, x0
    4ac4:	9352fc00 	asr	x0, x0, #18
    4ac8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4acc:	9b048802 	msub	x2, x0, x4, x2
    4ad0:	f100005f 	cmp	x2, #0x0
    4ad4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ad8:	eb01001f 	cmp	x0, x1
    4adc:	5400098c 	b.gt	4c0c <fwp_poll_events+0x1dc>
    4ae0:	340001a0 	cbz	w0, 4b14 <fwp_poll_events+0xe4>
    4ae4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ae8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4aec:	72a20c41 	movk	w1, #0x1062, lsl #16
    4af0:	9ba17c01 	umull	x1, w0, w1
    4af4:	d366fc23 	lsr	x3, x1, #38
    4af8:	aa0303e2 	mov	x2, x3
    4afc:	1b058063 	msub	w3, w3, w5, w0
    4b00:	9b247c63 	smull	x3, w3, w4
    4b04:	910023e0 	add	x0, sp, #0x8
    4b08:	d2800001 	mov	x1, #0x0                   	// #0
    4b0c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b10:	97fff790 	bl	2950 <nanosleep@plt>
    4b14:	97ffff9f 	bl	4990 <fwp_now_ns>
    4b18:	9101c268 	add	x8, x19, #0x70
    4b1c:	aa0003e7 	mov	x7, x0
    4b20:	4f000400 	movi	v0.4s, #0x0
    4b24:	52800029 	mov	w9, #0x1                   	// #1
    4b28:	f9406d06 	ldr	x6, [x8, #216]
    4b2c:	d503201f 	nop
    4b30:	b40003e6 	cbz	x6, 4bac <fwp_poll_events+0x17c>
    4b34:	f94034c1 	ldr	x1, [x6, #104]
    4b38:	aa0603e5 	mov	x5, x6
    4b3c:	f94088c6 	ldr	x6, [x6, #272]
    4b40:	eb07003f 	cmp	x1, x7
    4b44:	54ffff6c 	b.gt	4b30 <fwp_poll_events+0x100>
    4b48:	394154a0 	ldrb	w0, [x5, #85]
    4b4c:	36000120 	tbz	w0, #0, 4b70 <fwp_poll_events+0x140>
    4b50:	f94084a0 	ldr	x0, [x5, #264]
    4b54:	b4000560 	cbz	x0, 4c00 <fwp_poll_events+0x1d0>
    4b58:	f9008806 	str	x6, [x0, #272]
    4b5c:	b4000046 	cbz	x6, 4b64 <fwp_poll_events+0x134>
    4b60:	f90084c0 	str	x0, [x6, #264]
    4b64:	910800a0 	add	x0, x5, #0x200
    4b68:	390154bf 	strb	wzr, [x5, #85]
    4b6c:	3c908000 	stur	q0, [x0, #-248]
    4b70:	f94030a0 	ldr	x0, [x5, #96]
    4b74:	390158a9 	strb	w9, [x5, #86]
    4b78:	f100001f 	cmp	x0, #0x0
    4b7c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b80:	540002cd 	b.le	4bd8 <fwp_poll_events+0x1a8>
    4b84:	f94028a0 	ldr	x0, [x5, #80]
    4b88:	f2001c1f 	tst	x0, #0xff000000ff
    4b8c:	54fffd21 	b.ne	4b30 <fwp_poll_events+0x100>  // b.any
    4b90:	f9403d00 	ldr	x0, [x8, #120]
    4b94:	390150a9 	strb	w9, [x5, #84]
    4b98:	f90080bf 	str	xzr, [x5, #256]
    4b9c:	b40002c0 	cbz	x0, 4bf4 <fwp_poll_events+0x1c4>
    4ba0:	f9003d05 	str	x5, [x8, #120]
    4ba4:	f9008005 	str	x5, [x0, #256]
    4ba8:	b5fffc66 	cbnz	x6, 4b34 <fwp_poll_events+0x104>
    4bac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4bb0:	f947f400 	ldr	x0, [x0, #4072]
    4bb4:	f9400fe2 	ldr	x2, [sp, #24]
    4bb8:	f9400001 	ldr	x1, [x0]
    4bbc:	eb010042 	subs	x2, x2, x1
    4bc0:	d2800001 	mov	x1, #0x0                   	// #0
    4bc4:	540002e1 	b.ne	4c20 <fwp_poll_events+0x1f0>  // b.any
    4bc8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bcc:	f9401bf3 	ldr	x19, [sp, #48]
    4bd0:	910103ff 	add	sp, sp, #0x40
    4bd4:	d65f03c0 	ret
    4bd8:	394144a0 	ldrb	w0, [x5, #81]
    4bdc:	3707fd40 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be0:	394140a0 	ldrb	w0, [x5, #80]
    4be4:	3707fd00 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be8:	aa0503e0 	mov	x0, x5
    4bec:	97fffac1 	bl	36f0 <fwp_cancel_tree.part.0>
    4bf0:	17ffffe5 	b	4b84 <fwp_poll_events+0x154>
    4bf4:	f9003d05 	str	x5, [x8, #120]
    4bf8:	f9004105 	str	x5, [x8, #128]
    4bfc:	17ffffeb 	b	4ba8 <fwp_poll_events+0x178>
    4c00:	9101c261 	add	x1, x19, #0x70
    4c04:	f9006c26 	str	x6, [x1, #216]
    4c08:	17ffffd5 	b	4b5c <fwp_poll_events+0x12c>
    4c0c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c10:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c14:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c18:	f2a00402 	movk	x2, #0x20, lsl #16
    4c1c:	17ffffba 	b	4b04 <fwp_poll_events+0xd4>
    4c20:	97fff718 	bl	2880 <__stack_chk_fail@plt>
    4c24:	97fff8f3 	bl	2ff0 <fwp_flush>
    4c28:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4c2c:	f947e863 	ldr	x3, [x3, #4048]
    4c30:	d2800562 	mov	x2, #0x2b                  	// #43
    4c34:	d2800021 	mov	x1, #0x1                   	// #1
    4c38:	f0000020 	adrp	x0, b000 <__modti3+0x280>
    4c3c:	9111c000 	add	x0, x0, #0x470
    4c40:	f9400063 	ldr	x3, [x3]
    4c44:	97fff74f 	bl	2980 <fwrite@plt>
    4c48:	52800ca0 	mov	w0, #0x65                  	// #101
    4c4c:	97fff6b9 	bl	2730 <exit@plt>

0000000000004c50 <fwp_heap_alloc_big>:
    4c50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c54:	910003fd 	mov	x29, sp
    4c58:	a90153f3 	stp	x19, x20, [sp, #16]
    4c5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c60:	a90363f7 	stp	x23, x24, [sp, #48]
    4c64:	aa0003f7 	mov	x23, x0
    4c68:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c70:	eb0002ff 	cmp	x23, x0
    4c74:	540008a8 	b.hi	4d88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c78:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c7c:	8b0002f4 	add	x20, x23, x0
    4c80:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c84:	91174359 	add	x25, x26, #0x5d0
    4c88:	d350fe94 	lsr	x20, x20, #16
    4c8c:	2a0103f5 	mov	w21, w1
    4c90:	aa1403e0 	mov	x0, x20
    4c94:	97fff987 	bl	32b0 <fwp_heap_chunks>
    4c98:	f949ff22 	ldr	x2, [x25, #5112]
    4c9c:	8b000813 	add	x19, x0, x0, lsl #2
    4ca0:	aa0003f8 	mov	x24, x0
    4ca4:	52800043 	mov	w3, #0x2                   	// #2
    4ca8:	d37df273 	lsl	x19, x19, #3
    4cac:	d2800021 	mov	x1, #0x1                   	// #1
    4cb0:	8b130040 	add	x0, x2, x19
    4cb4:	38336843 	strb	w3, [x2, x19]
    4cb8:	39000415 	strb	w21, [x0, #1]
    4cbc:	b9000c14 	str	w20, [x0, #12]
    4cc0:	f9000817 	str	x23, [x0, #16]
    4cc4:	97fffd57 	bl	4220 <fwp_rc_prepare_chunk>
    4cc8:	f100069f 	cmp	x20, #0x1
    4ccc:	54000289 	b.ls	4d1c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cd0:	8b180294 	add	x20, x20, x24
    4cd4:	9100a273 	add	x19, x19, #0x28
    4cd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4cdc:	5280007b 	mov	w27, #0x3                   	// #3
    4ce0:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce4:	2a1803fc 	mov	w28, w24
    4ce8:	9adb2296 	lsl	x22, x20, x27
    4cec:	d503201f 	nop
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffd48 	bl	4220 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x108>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffbbf 	bl	3d70 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff6f 	b	4c50 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffd19 	bl	4340 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94066e0 	ldr	x0, [x23, #200]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_tape_reserve>:
    5224:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5228:	910003fd 	mov	x29, sp
    522c:	a90153f3 	stp	x19, x20, [sp, #16]
    5230:	aa0003f3 	mov	x19, x0
    5234:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5238:	eb00003f 	cmp	x1, x0
    523c:	54000868 	b.hi	5348 <fwp_tape_reserve+0x124>  // b.pmore
    5240:	f9400e74 	ldr	x20, [x19, #24]
    5244:	eb01029f 	cmp	x20, x1
    5248:	5400076a 	b.ge	5334 <fwp_tape_reserve+0x110>  // b.tcont
    524c:	f100029f 	cmp	x20, #0x0
    5250:	d2800802 	mov	x2, #0x40                  	// #64
    5254:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5258:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    525c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5260:	a90363f7 	stp	x23, x24, [sp, #48]
    5264:	eb01029f 	cmp	x20, x1
    5268:	5400008a 	b.ge	5278 <fwp_tape_reserve+0x54>  // b.tcont
    526c:	eb00029f 	cmp	x20, x0
    5270:	5400068d 	b.le	5340 <fwp_tape_reserve+0x11c>
    5274:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5278:	a940d662 	ldp	x2, x21, [x19, #8]
    527c:	d37df297 	lsl	x23, x20, #3
    5280:	f9401260 	ldr	x0, [x19, #32]
    5284:	aa1703e1 	mov	x1, x23
    5288:	f9403276 	ldr	x22, [x19, #96]
    528c:	cb0202b5 	sub	x21, x21, x2
    5290:	97fff578 	bl	2870 <realloc@plt>
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_tape_reserve+0x1d0>
    5298:	f9400e61 	ldr	x1, [x19, #24]
    529c:	8b010801 	add	x1, x0, x1, lsl #2
    52a0:	a9020660 	stp	x0, x1, [x19, #32]
    52a4:	b40008b6 	cbz	x22, 53b8 <fwp_tape_reserve+0x194>
    52a8:	f94032d7 	ldr	x23, [x22, #96]
    52ac:	eb17029f 	cmp	x20, x23
    52b0:	5400034d 	b.le	5318 <fwp_tape_reserve+0xf4>
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	d37cee9a 	lsl	x26, x20, #4
    52bc:	aa1a03e0 	mov	x0, x26
    52c0:	f94022d9 	ldr	x25, [x22, #64]
    52c4:	52800041 	mov	w1, #0x2                   	// #2
    52c8:	97ffff0a 	bl	4ef0 <fwp_heap_alloc>
    52cc:	aa0003f8 	mov	x24, x0
    52d0:	b4000119 	cbz	x25, 52f0 <fwp_tape_reserve+0xcc>
    52d4:	d37ceef7 	lsl	x23, x23, #4
    52d8:	aa1903e1 	mov	x1, x25
    52dc:	eb1a02ff 	cmp	x23, x26
    52e0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    52e4:	97fff4fb 	bl	26d0 <memcpy@plt>
    52e8:	aa1903e0 	mov	x0, x25
    52ec:	97fffc45 	bl	4400 <fwp_mem_free>
    52f0:	f94032c0 	ldr	x0, [x22, #96]
    52f4:	52800001 	mov	w1, #0x0                   	// #0
    52f8:	cb000282 	sub	x2, x20, x0
    52fc:	8b001300 	add	x0, x24, x0, lsl #4
    5300:	d37cec42 	lsl	x2, x2, #4
    5304:	97fff553 	bl	2850 <memset@plt>
    5308:	f9401260 	ldr	x0, [x19, #32]
    530c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5310:	f90022d8 	str	x24, [x22, #64]
    5314:	f90032d4 	str	x20, [x22, #96]
    5318:	d37ef696 	lsl	x22, x20, #2
    531c:	b5000375 	cbnz	x21, 5388 <fwp_tape_reserve+0x164>
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	8b160000 	add	x0, x0, x22
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000e74 	str	x20, [x19, #24]
    5330:	f9001660 	str	x0, [x19, #40]
    5334:	a94153f3 	ldp	x19, x20, [sp, #16]
    5338:	a8c57bfd 	ldp	x29, x30, [sp], #80
    533c:	d65f03c0 	ret
    5340:	d37ffa94 	lsl	x20, x20, #1
    5344:	17ffffc8 	b	5264 <fwp_tape_reserve+0x40>
    5348:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    534c:	91132000 	add	x0, x0, #0x4c8
    5350:	a9025bf5 	stp	x21, x22, [sp, #32]
    5354:	a90363f7 	stp	x23, x24, [sp, #48]
    5358:	a9046bf9 	stp	x25, x26, [sp, #64]
    535c:	97fffb6d 	bl	4110 <fwp_trap>
    5360:	eb1602ff 	cmp	x23, x22
    5364:	aa0403e0 	mov	x0, x4
    5368:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    536c:	d37df2a2 	lsl	x2, x21, #3
    5370:	cb170063 	sub	x3, x3, x23
    5374:	97fff5ab 	bl	2a20 <__memmove_chk@plt>
    5378:	f9401a61 	ldr	x1, [x19, #48]
    537c:	f9401260 	ldr	x0, [x19, #32]
    5380:	8b170021 	add	x1, x1, x23
    5384:	f9001e61 	str	x1, [x19, #56]
    5388:	f9401661 	ldr	x1, [x19, #40]
    538c:	d37ef696 	lsl	x22, x20, #2
    5390:	d37ef6a2 	lsl	x2, x21, #2
    5394:	8b160000 	add	x0, x0, x22
    5398:	97fff4d6 	bl	26f0 <memmove@plt>
    539c:	f9401260 	ldr	x0, [x19, #32]
    53a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53a4:	8b160000 	add	x0, x0, x22
    53a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ac:	f9000e74 	str	x20, [x19, #24]
    53b0:	f9001660 	str	x0, [x19, #40]
    53b4:	17ffffe0 	b	5334 <fwp_tape_reserve+0x110>
    53b8:	f9401a60 	ldr	x0, [x19, #48]
    53bc:	d37cee96 	lsl	x22, x20, #4
    53c0:	aa1603e1 	mov	x1, x22
    53c4:	97fff52b 	bl	2870 <realloc@plt>
    53c8:	b4000160 	cbz	x0, 53f4 <fwp_tape_reserve+0x1d0>
    53cc:	f9400e62 	ldr	x2, [x19, #24]
    53d0:	f9001a60 	str	x0, [x19, #48]
    53d4:	8b170004 	add	x4, x0, x23
    53d8:	8b020c01 	add	x1, x0, x2, lsl #3
    53dc:	f9001e61 	str	x1, [x19, #56]
    53e0:	b5fffc15 	cbnz	x21, 5360 <fwp_tape_reserve+0x13c>
    53e4:	f9401260 	ldr	x0, [x19, #32]
    53e8:	d37ef696 	lsl	x22, x20, #2
    53ec:	f9001e64 	str	x4, [x19, #56]
    53f0:	17ffffcc 	b	5320 <fwp_tape_reserve+0xfc>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53fc:	97fff6e5 	bl	2f90 <fwp_tape_unlink_scope>
    5400:	f9401260 	ldr	x0, [x19, #32]
    5404:	97fff54f 	bl	2940 <free@plt>
    5408:	f9401a60 	ldr	x0, [x19, #48]
    540c:	97fff54d 	bl	2940 <free@plt>
    5410:	f9402260 	ldr	x0, [x19, #64]
    5414:	97fff54b 	bl	2940 <free@plt>
    5418:	f9000e7f 	str	xzr, [x19, #24]
    541c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5420:	f947e821 	ldr	x1, [x1, #4048]
    5424:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5428:	d2800262 	mov	x2, #0x13                  	// #19
    542c:	4f000400 	movi	v0.4s, #0x0
    5430:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5434:	f9400023 	ldr	x3, [x1]
    5438:	b900067f 	str	wzr, [x19, #4]
    543c:	d2800021 	mov	x1, #0x1                   	// #1
    5440:	9104a000 	add	x0, x0, #0x128
    5444:	3c808260 	stur	q0, [x19, #8]
    5448:	ad010260 	stp	q0, q0, [x19, #32]
    544c:	97fff54d 	bl	2980 <fwrite@plt>
    5450:	d2800000 	mov	x0, #0x0                   	// #0
    5454:	97fff557 	bl	29b0 <fflush@plt>
    5458:	52800cc0 	mov	w0, #0x66                  	// #102
    545c:	97fff565 	bl	29f0 <_Exit@plt>

0000000000005460 <f128.constprop.0>:
    5460:	f100001f 	cmp	x0, #0x0
    5464:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5468:	5400094b 	b.lt	5590 <f128.constprop.0+0x130>  // b.tstop
    546c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5470:	aa0003e2 	mov	x2, x0
    5474:	910003fd 	mov	x29, sp
    5478:	a90153f3 	stp	x19, x20, [sp, #16]
    547c:	aa0003f4 	mov	x20, x0
    5480:	aa010000 	orr	x0, x0, x1
    5484:	a9025bf5 	stp	x21, x22, [sp, #32]
    5488:	aa0103f6 	mov	x22, x1
    548c:	f9001bf7 	str	x23, [sp, #48]
    5490:	fd001fe8 	str	d8, [sp, #56]
    5494:	b7f80180 	tbnz	x0, #63, 54c4 <f128.constprop.0+0x64>
    5498:	9360fc20 	asr	x0, x1, #32
    549c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54a0:	eb82801f 	cmp	x0, x2, asr #32
    54a4:	540007a1 	b.ne	5598 <f128.constprop.0+0x138>  // b.any
    54a8:	97fffd1e 	bl	4920 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b40001e0 	cbz	x0, 54f0 <f128.constprop.0+0x90>
    54b8:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    54bc:	9114c000 	add	x0, x0, #0x530
    54c0:	97fffb14 	bl	4110 <fwp_trap>
    54c4:	9360fc40 	asr	x0, x2, #32
    54c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54cc:	b6fffee2 	tbz	x2, #63, 54a8 <f128.constprop.0+0x48>
    54d0:	2f00e408 	movi	d8, #0x0
    54d4:	9360fc20 	asr	x0, x1, #32
    54d8:	aa0103f4 	mov	x20, x1
    54dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    54e0:	97fffd10 	bl	4920 <fwp_tape_of>
    54e4:	aa0003f3 	mov	x19, x0
    54e8:	f9403000 	ldr	x0, [x0, #96]
    54ec:	b5fffe60 	cbnz	x0, 54b8 <f128.constprop.0+0x58>
    54f0:	f9400a77 	ldr	x23, [x19, #16]
    54f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54f8:	eb0002ff 	cmp	x23, x0
    54fc:	5400044c 	b.gt	5584 <f128.constprop.0+0x124>
    5500:	eb3442ff 	cmp	x23, w20, uxtw
    5504:	5400008d 	b.le	5514 <f128.constprop.0+0xb4>
    5508:	b7f800d6 	tbnz	x22, #63, 5520 <f128.constprop.0+0xc0>
    550c:	eb3642ff 	cmp	x23, w22, uxtw
    5510:	5400008c 	b.gt	5520 <f128.constprop.0+0xc0>
    5514:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5518:	91158000 	add	x0, x0, #0x560
    551c:	97fffafd 	bl	4110 <fwp_trap>
    5520:	f9400675 	ldr	x21, [x19, #8]
    5524:	aa1303e0 	mov	x0, x19
    5528:	cb1502f5 	sub	x21, x23, x21
    552c:	910006a1 	add	x1, x21, #0x1
    5530:	97ffff3d 	bl	5224 <fwp_tape_reserve>
    5534:	a9420262 	ldp	x2, x0, [x19, #32]
    5538:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    553c:	f9401a61 	ldr	x1, [x19, #48]
    5540:	b8357854 	str	w20, [x2, x21, lsl #2]
    5544:	f9401e62 	ldr	x2, [x19, #56]
    5548:	f10002df 	cmp	x22, #0x0
    554c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5550:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5554:	b8357816 	str	w22, [x0, x21, lsl #2]
    5558:	92607e80 	and	x0, x20, #0xffffffff00000000
    555c:	910006e1 	add	x1, x23, #0x1
    5560:	aa170000 	orr	x0, x0, x23
    5564:	fc357848 	str	d8, [x2, x21, lsl #3]
    5568:	a9425bf5 	ldp	x21, x22, [sp, #32]
    556c:	f9401bf7 	ldr	x23, [sp, #48]
    5570:	fd401fe8 	ldr	d8, [sp, #56]
    5574:	f9000a61 	str	x1, [x19, #16]
    5578:	a94153f3 	ldp	x19, x20, [sp, #16]
    557c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5580:	d65f03c0 	ret
    5584:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5588:	91132000 	add	x0, x0, #0x4c8
    558c:	97fffae1 	bl	4110 <fwp_trap>
    5590:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5594:	d65f03c0 	ret
    5598:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    559c:	9113a000 	add	x0, x0, #0x4e8
    55a0:	97fffadc 	bl	4110 <fwp_trap>

00000000000055a4 <w107>:
    55a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    55a8:	910003fd 	mov	x29, sp
    55ac:	a90153f3 	stp	x19, x20, [sp, #16]
    55b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    55b4:	aa0003f5 	mov	x21, x0
    55b8:	a90363f7 	stp	x23, x24, [sp, #48]
    55bc:	aa0103f7 	mov	x23, x1
    55c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    55c4:	f9002bfb 	str	x27, [sp, #80]
    55c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    55cc:	1e604028 	fmov	d8, d1
    55d0:	1e600809 	fmul	d9, d0, d0
    55d4:	6d072fea 	stp	d10, d11, [sp, #112]
    55d8:	1e60400b 	fmov	d11, d0
    55dc:	b7f81c80 	tbnz	x0, #63, 596c <w107+0x3c8>
    55e0:	9360fc19 	asr	x25, x0, #32
    55e4:	aa1903e0 	mov	x0, x25
    55e8:	97fffcce 	bl	4920 <fwp_tape_of>
    55ec:	f9403001 	ldr	x1, [x0, #96]
    55f0:	aa0003f3 	mov	x19, x0
    55f4:	b4000081 	cbz	x1, 5604 <w107+0x60>
    55f8:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    55fc:	9114c000 	add	x0, x0, #0x530
    5600:	97fffac4 	bl	4110 <fwp_trap>
    5604:	f9400818 	ldr	x24, [x0, #16]
    5608:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    560c:	eb01031f 	cmp	x24, x1
    5610:	54001a8c 	b.gt	5960 <w107+0x3bc>
    5614:	eb35431f 	cmp	x24, w21, uxtw
    5618:	540019ed 	b.le	5954 <w107+0x3b0>
    561c:	f9400416 	ldr	x22, [x0, #8]
    5620:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5624:	aa180294 	orr	x20, x20, x24
    5628:	cb160316 	sub	x22, x24, x22
    562c:	910006c1 	add	x1, x22, #0x1
    5630:	97fffefd 	bl	5224 <fwp_tape_reserve>
    5634:	a9420a61 	ldp	x1, x2, [x19, #32]
    5638:	91000700 	add	x0, x24, #0x1
    563c:	f9401a63 	ldr	x3, [x19, #48]
    5640:	b8367835 	str	w21, [x1, x22, lsl #2]
    5644:	f9401e61 	ldr	x1, [x19, #56]
    5648:	1e693908 	fsub	d8, d8, d9
    564c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5650:	9360fe9a 	asr	x26, x20, #32
    5654:	b8367855 	str	w21, [x2, x22, lsl #2]
    5658:	fc36782b 	str	d11, [x1, x22, lsl #3]
    565c:	f9000a60 	str	x0, [x19, #16]
    5660:	b7f80077 	tbnz	x23, #63, 566c <w107+0xc8>
    5664:	eb97835f 	cmp	x26, x23, asr #32
    5668:	540019a1 	b.ne	599c <w107+0x3f8>  // b.any
    566c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5670:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5674:	eb19035f 	cmp	x26, x25
    5678:	540000c0 	b.eq	5690 <w107+0xec>  // b.none
    567c:	aa1a03e0 	mov	x0, x26
    5680:	97fffca8 	bl	4920 <fwp_tape_of>
    5684:	aa0003f3 	mov	x19, x0
    5688:	f9403000 	ldr	x0, [x0, #96]
    568c:	b5fffb60 	cbnz	x0, 55f8 <w107+0x54>
    5690:	f9400a79 	ldr	x25, [x19, #16]
    5694:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5698:	eb00033f 	cmp	x25, x0
    569c:	5400162c 	b.gt	5960 <w107+0x3bc>
    56a0:	eb34433f 	cmp	x25, w20, uxtw
    56a4:	5400158d 	b.le	5954 <w107+0x3b0>
    56a8:	b7f80077 	tbnz	x23, #63, 56b4 <w107+0x110>
    56ac:	eb37433f 	cmp	x25, w23, uxtw
    56b0:	5400152d 	b.le	5954 <w107+0x3b0>
    56b4:	f9400676 	ldr	x22, [x19, #8]
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	cb160336 	sub	x22, x25, x22
    56c0:	910006c1 	add	x1, x22, #0x1
    56c4:	97fffed8 	bl	5224 <fwp_tape_reserve>
    56c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    56cc:	f10002ff 	cmp	x23, #0x0
    56d0:	f9401a61 	ldr	x1, [x19, #48]
    56d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    56d8:	f9401e62 	ldr	x2, [x19, #56]
    56dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    56e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    56e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    56ec:	91000737 	add	x23, x25, #0x1
    56f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    56f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    56fc:	aa190294 	orr	x20, x20, x25
    5700:	f9000a77 	str	x23, [x19, #16]
    5704:	1e6b3929 	fsub	d9, d9, d11
    5708:	b7f81675 	tbnz	x21, #63, 59d4 <w107+0x430>
    570c:	9360febb 	asr	x27, x21, #32
    5710:	eb1a037f 	cmp	x27, x26
    5714:	540000e0 	b.eq	5730 <w107+0x18c>  // b.none
    5718:	aa1b03e0 	mov	x0, x27
    571c:	97fffc81 	bl	4920 <fwp_tape_of>
    5720:	aa0003f3 	mov	x19, x0
    5724:	f9403000 	ldr	x0, [x0, #96]
    5728:	b5fff680 	cbnz	x0, 55f8 <w107+0x54>
    572c:	f9400a77 	ldr	x23, [x19, #16]
    5730:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5734:	eb0002ff 	cmp	x23, x0
    5738:	5400114c 	b.gt	5960 <w107+0x3bc>
    573c:	eb3542ff 	cmp	x23, w21, uxtw
    5740:	540010ad 	b.le	5954 <w107+0x3b0>
    5744:	f9400676 	ldr	x22, [x19, #8]
    5748:	aa1303e0 	mov	x0, x19
    574c:	cb1602f6 	sub	x22, x23, x22
    5750:	910006c1 	add	x1, x22, #0x1
    5754:	97fffeb4 	bl	5224 <fwp_tape_reserve>
    5758:	a9420261 	ldp	x1, x0, [x19, #32]
    575c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5760:	f9401a63 	ldr	x3, [x19, #48]
    5764:	b8367835 	str	w21, [x1, x22, lsl #2]
    5768:	f9401e61 	ldr	x1, [x19, #56]
    576c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5770:	fc367860 	str	d0, [x3, x22, lsl #3]
    5774:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5778:	b8367802 	str	w2, [x0, x22, lsl #2]
    577c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5780:	910006e0 	add	x0, x23, #0x1
    5784:	aa1702b7 	orr	x23, x21, x23
    5788:	fc367820 	str	d0, [x1, x22, lsl #3]
    578c:	f9000a60 	str	x0, [x19, #16]
    5790:	9360fe99 	asr	x25, x20, #32
    5794:	1e68090a 	fmul	d10, d8, d8
    5798:	eb1b033f 	cmp	x25, x27
    579c:	540000c0 	b.eq	57b4 <w107+0x210>  // b.none
    57a0:	aa1903e0 	mov	x0, x25
    57a4:	97fffc5f 	bl	4920 <fwp_tape_of>
    57a8:	aa0003f3 	mov	x19, x0
    57ac:	f9403000 	ldr	x0, [x0, #96]
    57b0:	b5fff240 	cbnz	x0, 55f8 <w107+0x54>
    57b4:	f9400a75 	ldr	x21, [x19, #16]
    57b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57bc:	eb0002bf 	cmp	x21, x0
    57c0:	54000d0c 	b.gt	5960 <w107+0x3bc>
    57c4:	eb3442bf 	cmp	x21, w20, uxtw
    57c8:	54000c6d 	b.le	5954 <w107+0x3b0>
    57cc:	f9400678 	ldr	x24, [x19, #8]
    57d0:	aa1303e0 	mov	x0, x19
    57d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    57d8:	cb1802b8 	sub	x24, x21, x24
    57dc:	aa1502d6 	orr	x22, x22, x21
    57e0:	91000701 	add	x1, x24, #0x1
    57e4:	97fffe90 	bl	5224 <fwp_tape_reserve>
    57e8:	a9420261 	ldp	x1, x0, [x19, #32]
    57ec:	f9401a62 	ldr	x2, [x19, #48]
    57f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    57f4:	f9401e61 	ldr	x1, [x19, #56]
    57f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    57fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5800:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5804:	9e670000 	fmov	d0, x0
    5808:	910006b4 	add	x20, x21, #0x1
    580c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5810:	9360fed8 	asr	x24, x22, #32
    5814:	f9000a74 	str	x20, [x19, #16]
    5818:	1e60094a 	fmul	d10, d10, d0
    581c:	eb19031f 	cmp	x24, x25
    5820:	540000e0 	b.eq	583c <w107+0x298>  // b.none
    5824:	aa1803e0 	mov	x0, x24
    5828:	97fffc3e 	bl	4920 <fwp_tape_of>
    582c:	aa0003f3 	mov	x19, x0
    5830:	f9403000 	ldr	x0, [x0, #96]
    5834:	b5ffee20 	cbnz	x0, 55f8 <w107+0x54>
    5838:	f9400a74 	ldr	x20, [x19, #16]
    583c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5840:	eb00029f 	cmp	x20, x0
    5844:	540008ec 	b.gt	5960 <w107+0x3bc>
    5848:	eb36429f 	cmp	x20, w22, uxtw
    584c:	5400084d 	b.le	5954 <w107+0x3b0>
    5850:	f9400675 	ldr	x21, [x19, #8]
    5854:	aa1303e0 	mov	x0, x19
    5858:	cb150295 	sub	x21, x20, x21
    585c:	910006a1 	add	x1, x21, #0x1
    5860:	97fffe71 	bl	5224 <fwp_tape_reserve>
    5864:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5868:	9e670000 	fmov	d0, x0
    586c:	a9420261 	ldp	x1, x0, [x19, #32]
    5870:	1e690928 	fmul	d8, d9, d9
    5874:	f9401a62 	ldr	x2, [x19, #48]
    5878:	b8357836 	str	w22, [x1, x21, lsl #2]
    587c:	f9401e61 	ldr	x1, [x19, #56]
    5880:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5884:	fc357840 	str	d0, [x2, x21, lsl #3]
    5888:	12800002 	mov	w2, #0xffffffff            	// #-1
    588c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5890:	91000680 	add	x0, x20, #0x1
    5894:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5898:	aa1402d6 	orr	x22, x22, x20
    589c:	f9000a60 	str	x0, [x19, #16]
    58a0:	b10006ff 	cmn	x23, #0x1
    58a4:	540009e0 	b.eq	59e0 <w107+0x43c>  // b.none
    58a8:	9360fee0 	asr	x0, x23, #32
    58ac:	eb18001f 	cmp	x0, x24
    58b0:	540000a0 	b.eq	58c4 <w107+0x320>  // b.none
    58b4:	97fffc1b 	bl	4920 <fwp_tape_of>
    58b8:	aa0003f3 	mov	x19, x0
    58bc:	f9403000 	ldr	x0, [x0, #96]
    58c0:	b5ffe9c0 	cbnz	x0, 55f8 <w107+0x54>
    58c4:	f9400a74 	ldr	x20, [x19, #16]
    58c8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58cc:	eb00029f 	cmp	x20, x0
    58d0:	5400048c 	b.gt	5960 <w107+0x3bc>
    58d4:	eb37429f 	cmp	x20, w23, uxtw
    58d8:	540003ed 	b.le	5954 <w107+0x3b0>
    58dc:	f9400675 	ldr	x21, [x19, #8]
    58e0:	aa1303e0 	mov	x0, x19
    58e4:	cb150295 	sub	x21, x20, x21
    58e8:	910006a1 	add	x1, x21, #0x1
    58ec:	97fffe4e 	bl	5224 <fwp_tape_reserve>
    58f0:	a9420a61 	ldp	x1, x2, [x19, #32]
    58f4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    58f8:	f9401a63 	ldr	x3, [x19, #48]
    58fc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5900:	f9401e61 	ldr	x1, [x19, #56]
    5904:	aa140000 	orr	x0, x0, x20
    5908:	fc357869 	str	d9, [x3, x21, lsl #3]
    590c:	91000694 	add	x20, x20, #0x1
    5910:	b8357857 	str	w23, [x2, x21, lsl #2]
    5914:	fc357829 	str	d9, [x1, x21, lsl #3]
    5918:	f9000a74 	str	x20, [x19, #16]
    591c:	1e6a2908 	fadd	d8, d8, d10
    5920:	aa1603e1 	mov	x1, x22
    5924:	97fffecf 	bl	5460 <f128.constprop.0>
    5928:	aa0003e1 	mov	x1, x0
    592c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5930:	9e660100 	fmov	x0, d8
    5934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5938:	a94363f7 	ldp	x23, x24, [sp, #48]
    593c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5940:	f9402bfb 	ldr	x27, [sp, #80]
    5944:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5948:	6d472fea 	ldp	d10, d11, [sp, #112]
    594c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5950:	d65f03c0 	ret
    5954:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5958:	91158000 	add	x0, x0, #0x560
    595c:	97fff9ed 	bl	4110 <fwp_trap>
    5960:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5964:	91132000 	add	x0, x0, #0x4c8
    5968:	97fff9ea 	bl	4110 <fwp_trap>
    596c:	1e693828 	fsub	d8, d1, d9
    5970:	b6f801c1 	tbz	x1, #63, 59a8 <w107+0x404>
    5974:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5978:	1e68090a 	fmul	d10, d8, d8
    597c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5980:	9e670000 	fmov	d0, x0
    5984:	1e6b3828 	fsub	d8, d1, d11
    5988:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    598c:	aa1603e0 	mov	x0, x22
    5990:	1e60094a 	fmul	d10, d10, d0
    5994:	1e680908 	fmul	d8, d8, d8
    5998:	17ffffe1 	b	591c <w107+0x378>
    599c:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    59a0:	9113a000 	add	x0, x0, #0x4e8
    59a4:	97fff9db 	bl	4110 <fwp_trap>
    59a8:	2f00e40a 	movi	d10, #0x0
    59ac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    59b0:	9360fc3a 	asr	x26, x1, #32
    59b4:	aa0103f4 	mov	x20, x1
    59b8:	aa1a03e0 	mov	x0, x26
    59bc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    59c0:	97fffbd8 	bl	4920 <fwp_tape_of>
    59c4:	aa0003f3 	mov	x19, x0
    59c8:	f9403000 	ldr	x0, [x0, #96]
    59cc:	b5ffe160 	cbnz	x0, 55f8 <w107+0x54>
    59d0:	17ffff30 	b	5690 <w107+0xec>
    59d4:	aa1a03fb 	mov	x27, x26
    59d8:	aa0003f7 	mov	x23, x0
    59dc:	17ffff6d 	b	5790 <w107+0x1ec>
    59e0:	aa1703e0 	mov	x0, x23
    59e4:	17ffffce 	b	591c <w107+0x378>
    59e8:	d503201f 	nop
    59ec:	d503201f 	nop

00000000000059f0 <fwp_data.part.0.constprop.0>:
    59f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    59f4:	910003fd 	mov	x29, sp
    59f8:	a90153f3 	stp	x19, x20, [sp, #16]
    59fc:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5a00:	91174283 	add	x3, x20, #0x5d0
    5a04:	a9025bf5 	stp	x21, x22, [sp, #32]
    5a08:	aa0103f5 	mov	x21, x1
    5a0c:	b953a461 	ldr	w1, [x3, #5028]
    5a10:	a90363f7 	stp	x23, x24, [sp, #48]
    5a14:	2a0003f8 	mov	w24, w0
    5a18:	34000701 	cbz	w1, 5af8 <fwp_data.part.0.constprop.0+0x108>
    5a1c:	397e8862 	ldrb	w2, [x3, #4002]
    5a20:	910f0040 	add	x0, x2, #0x3c0
    5a24:	8b020442 	add	x2, x2, x2, lsl #1
    5a28:	d37df042 	lsl	x2, x2, #3
    5a2c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5a30:	2a1703f6 	mov	w22, w23
    5a34:	f8626873 	ldr	x19, [x3, x2]
    5a38:	b40004d3 	cbz	x19, 5ad0 <fwp_data.part.0.constprop.0+0xe0>
    5a3c:	f9400260 	ldr	x0, [x19]
    5a40:	aa2003e0 	mvn	x0, x0
    5a44:	f8226860 	str	x0, [x3, x2]
    5a48:	f10062df 	cmp	x22, #0x18
    5a4c:	540000e9 	b.ls	5a68 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5a50:	d10066c2 	sub	x2, x22, #0x19
    5a54:	91006260 	add	x0, x19, #0x18
    5a58:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5a5c:	52800001 	mov	w1, #0x0                   	// #0
    5a60:	91002042 	add	x2, x2, #0x8
    5a64:	97fff37b 	bl	2850 <memset@plt>
    5a68:	91174282 	add	x2, x20, #0x5d0
    5a6c:	f94a1041 	ldr	x1, [x2, #5152]
    5a70:	ab160021 	adds	x1, x1, x22
    5a74:	540004c2 	b.cs	5b0c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5a78:	f94a1440 	ldr	x0, [x2, #5160]
    5a7c:	f90a1041 	str	x1, [x2, #5152]
    5a80:	eb00003f 	cmp	x1, x0
    5a84:	54000049 	b.ls	5a8c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5a88:	f90a1441 	str	x1, [x2, #5160]
    5a8c:	91174294 	add	x20, x20, #0x5d0
    5a90:	1e6302e1 	ucvtf	d1, w23
    5a94:	fd4a1e80 	ldr	d0, [x20, #5176]
    5a98:	1e612800 	fadd	d0, d0, d1
    5a9c:	fd0a1e80 	str	d0, [x20, #5176]
    5aa0:	52800041 	mov	w1, #0x2                   	// #2
    5aa4:	29000678 	stp	w24, w1, [x19]
    5aa8:	aa1303e0 	mov	x0, x19
    5aac:	f94002a1 	ldr	x1, [x21]
    5ab0:	f9000661 	str	x1, [x19, #8]
    5ab4:	f94006a1 	ldr	x1, [x21, #8]
    5ab8:	f9000a61 	str	x1, [x19, #16]
    5abc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ac0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5ac4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5ac8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5acc:	d65f03c0 	ret
    5ad0:	8b020063 	add	x3, x3, x2
    5ad4:	f9400473 	ldr	x19, [x3, #8]
    5ad8:	b4000113 	cbz	x19, 5af8 <fwp_data.part.0.constprop.0+0x108>
    5adc:	f9400860 	ldr	x0, [x3, #16]
    5ae0:	cb130000 	sub	x0, x0, x19
    5ae4:	eb0002df 	cmp	x22, x0
    5ae8:	54000088 	b.hi	5af8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5aec:	8b160260 	add	x0, x19, x22
    5af0:	f9000460 	str	x0, [x3, #8]
    5af4:	17ffffd5 	b	5a48 <fwp_data.part.0.constprop.0+0x58>
    5af8:	52800001 	mov	w1, #0x0                   	// #0
    5afc:	d2800300 	mov	x0, #0x18                  	// #24
    5b00:	97fffcfc 	bl	4ef0 <fwp_heap_alloc>
    5b04:	aa0003f3 	mov	x19, x0
    5b08:	17ffffe6 	b	5aa0 <fwp_data.part.0.constprop.0+0xb0>
    5b0c:	97fff549 	bl	3030 <fwp_heap_oom>

0000000000005b10 <fwp_rc_share>:
    5b10:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5b14:	91174042 	add	x2, x2, #0x5d0
    5b18:	f949d843 	ldr	x3, [x2, #5040]
    5b1c:	f949ec41 	ldr	x1, [x2, #5080]
    5b20:	cb030000 	sub	x0, x0, x3
    5b24:	eb01401f 	cmp	x0, x1, lsl #16
    5b28:	540003a2 	b.cs	5b9c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5b2c:	d350fc01 	lsr	x1, x0, #16
    5b30:	f949fc44 	ldr	x4, [x2, #5112]
    5b34:	8b010821 	add	x1, x1, x1, lsl #2
    5b38:	d37df021 	lsl	x1, x1, #3
    5b3c:	8b010083 	add	x3, x4, x1
    5b40:	f9401062 	ldr	x2, [x3, #32]
    5b44:	b40002c2 	cbz	x2, 5b9c <fwp_rc_share+0x8c>
    5b48:	38616881 	ldrb	w1, [x4, x1]
    5b4c:	7100083f 	cmp	w1, #0x2
    5b50:	54000220 	b.eq	5b94 <fwp_rc_share+0x84>  // b.none
    5b54:	7100043f 	cmp	w1, #0x1
    5b58:	54000221 	b.ne	5b9c <fwp_rc_share+0x8c>  // b.any
    5b5c:	29430464 	ldp	w4, w1, [x3, #24]
    5b60:	92403c00 	and	x0, x0, #0xffff
    5b64:	9b047c00 	mul	x0, x0, x4
    5b68:	d360fc00 	lsr	x0, x0, #32
    5b6c:	eb01001f 	cmp	x0, x1
    5b70:	54000162 	b.cs	5b9c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5b74:	8b000042 	add	x2, x2, x0
    5b78:	39400040 	ldrb	w0, [x2]
    5b7c:	34000100 	cbz	w0, 5b9c <fwp_rc_share+0x8c>
    5b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5b84:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5b88:	91160000 	add	x0, x0, #0x580
    5b8c:	910003fd 	mov	x29, sp
    5b90:	97fff960 	bl	4110 <fwp_trap>
    5b94:	72003c1f 	tst	w0, #0xffff
    5b98:	54ffff00 	b.eq	5b78 <fwp_rc_share+0x68>  // b.none
    5b9c:	d65f03c0 	ret

0000000000005ba0 <fwp_rc_free_arr>:
    5ba0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5ba4:	91174063 	add	x3, x3, #0x5d0
    5ba8:	f949d861 	ldr	x1, [x3, #5040]
    5bac:	f949ec62 	ldr	x2, [x3, #5080]
    5bb0:	cb010001 	sub	x1, x0, x1
    5bb4:	eb02403f 	cmp	x1, x2, lsl #16
    5bb8:	54000342 	b.cs	5c20 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5bbc:	d350fc22 	lsr	x2, x1, #16
    5bc0:	f949fc65 	ldr	x5, [x3, #5112]
    5bc4:	8b020842 	add	x2, x2, x2, lsl #2
    5bc8:	d37df042 	lsl	x2, x2, #3
    5bcc:	8b0200a4 	add	x4, x5, x2
    5bd0:	f9401083 	ldr	x3, [x4, #32]
    5bd4:	b4000263 	cbz	x3, 5c20 <fwp_rc_free_arr+0x80>
    5bd8:	386268a2 	ldrb	w2, [x5, x2]
    5bdc:	7100085f 	cmp	w2, #0x2
    5be0:	540001c0 	b.eq	5c18 <fwp_rc_free_arr+0x78>  // b.none
    5be4:	7100045f 	cmp	w2, #0x1
    5be8:	540001c1 	b.ne	5c20 <fwp_rc_free_arr+0x80>  // b.any
    5bec:	29430885 	ldp	w5, w2, [x4, #24]
    5bf0:	92403c21 	and	x1, x1, #0xffff
    5bf4:	9b057c21 	mul	x1, x1, x5
    5bf8:	d360fc21 	lsr	x1, x1, #32
    5bfc:	eb02003f 	cmp	x1, x2
    5c00:	54000102 	b.cs	5c20 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c04:	8b010063 	add	x3, x3, x1
    5c08:	39400061 	ldrb	w1, [x3]
    5c0c:	7100043f 	cmp	w1, #0x1
    5c10:	54000081 	b.ne	5c20 <fwp_rc_free_arr+0x80>  // b.any
    5c14:	17fff9fb 	b	4400 <fwp_mem_free>
    5c18:	72003c3f 	tst	w1, #0xffff
    5c1c:	54ffff60 	b.eq	5c08 <fwp_rc_free_arr+0x68>  // b.none
    5c20:	d65f03c0 	ret

0000000000005c24 <fwp_rc_dup>:
    5c24:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5c28:	91174042 	add	x2, x2, #0x5d0
    5c2c:	f949d841 	ldr	x1, [x2, #5040]
    5c30:	f949ec43 	ldr	x3, [x2, #5080]
    5c34:	cb010001 	sub	x1, x0, x1
    5c38:	eb03403f 	cmp	x1, x3, lsl #16
    5c3c:	54000342 	b.cs	5ca4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5c40:	d350fc20 	lsr	x0, x1, #16
    5c44:	f949fc44 	ldr	x4, [x2, #5112]
    5c48:	8b000800 	add	x0, x0, x0, lsl #2
    5c4c:	d37df002 	lsl	x2, x0, #3
    5c50:	8b020083 	add	x3, x4, x2
    5c54:	f9401060 	ldr	x0, [x3, #32]
    5c58:	b4000260 	cbz	x0, 5ca4 <fwp_rc_dup+0x80>
    5c5c:	38626882 	ldrb	w2, [x4, x2]
    5c60:	7100085f 	cmp	w2, #0x2
    5c64:	54000220 	b.eq	5ca8 <fwp_rc_dup+0x84>  // b.none
    5c68:	7100045f 	cmp	w2, #0x1
    5c6c:	540001c1 	b.ne	5ca4 <fwp_rc_dup+0x80>  // b.any
    5c70:	29430864 	ldp	w4, w2, [x3, #24]
    5c74:	92403c21 	and	x1, x1, #0xffff
    5c78:	9b047c21 	mul	x1, x1, x4
    5c7c:	d360fc21 	lsr	x1, x1, #32
    5c80:	eb02003f 	cmp	x1, x2
    5c84:	54000102 	b.cs	5ca4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5c88:	8b010000 	add	x0, x0, x1
    5c8c:	39400001 	ldrb	w1, [x0]
    5c90:	340000a1 	cbz	w1, 5ca4 <fwp_rc_dup+0x80>
    5c94:	7103f43f 	cmp	w1, #0xfd
    5c98:	540000e8 	b.hi	5cb4 <fwp_rc_dup+0x90>  // b.pmore
    5c9c:	11000421 	add	w1, w1, #0x1
    5ca0:	39000001 	strb	w1, [x0]
    5ca4:	d65f03c0 	ret
    5ca8:	72003c3f 	tst	w1, #0xffff
    5cac:	54ffff00 	b.eq	5c8c <fwp_rc_dup+0x68>  // b.none
    5cb0:	d65f03c0 	ret
    5cb4:	17fffa4c 	b	45e4 <fwp_rc_wide_dup>
    5cb8:	d503201f 	nop
    5cbc:	d503201f 	nop

0000000000005cc0 <fwp_drop1>:
    5cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5cc4:	910003fd 	mov	x29, sp
    5cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ccc:	f90013f5 	str	x21, [sp, #32]
    5cd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5cd4:	911742b4 	add	x20, x21, #0x5d0
    5cd8:	f949da81 	ldr	x1, [x20, #5040]
    5cdc:	f949ee82 	ldr	x2, [x20, #5080]
    5ce0:	cb010001 	sub	x1, x0, x1
    5ce4:	eb02403f 	cmp	x1, x2, lsl #16
    5ce8:	54000382 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cec:	d350fc22 	lsr	x2, x1, #16
    5cf0:	f949fe84 	ldr	x4, [x20, #5112]
    5cf4:	8b020842 	add	x2, x2, x2, lsl #2
    5cf8:	d37df042 	lsl	x2, x2, #3
    5cfc:	8b020083 	add	x3, x4, x2
    5d00:	f9401073 	ldr	x19, [x3, #32]
    5d04:	b40002b3 	cbz	x19, 5d58 <fwp_drop1+0x98>
    5d08:	38626882 	ldrb	w2, [x4, x2]
    5d0c:	7100085f 	cmp	w2, #0x2
    5d10:	540002c0 	b.eq	5d68 <fwp_drop1+0xa8>  // b.none
    5d14:	7100045f 	cmp	w2, #0x1
    5d18:	54000201 	b.ne	5d58 <fwp_drop1+0x98>  // b.any
    5d1c:	29430864 	ldp	w4, w2, [x3, #24]
    5d20:	92403c21 	and	x1, x1, #0xffff
    5d24:	9b047c21 	mul	x1, x1, x4
    5d28:	d360fc21 	lsr	x1, x1, #32
    5d2c:	eb02003f 	cmp	x1, x2
    5d30:	54000142 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d34:	8b010273 	add	x19, x19, x1
    5d38:	39400261 	ldrb	w1, [x19]
    5d3c:	340000e1 	cbz	w1, 5d58 <fwp_drop1+0x98>
    5d40:	7100043f 	cmp	w1, #0x1
    5d44:	540001e0 	b.eq	5d80 <fwp_drop1+0xc0>  // b.none
    5d48:	7103fc3f 	cmp	w1, #0xff
    5d4c:	540002e0 	b.eq	5da8 <fwp_drop1+0xe8>  // b.none
    5d50:	51000421 	sub	w1, w1, #0x1
    5d54:	39000261 	strb	w1, [x19]
    5d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d5c:	f94013f5 	ldr	x21, [sp, #32]
    5d60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d64:	d65f03c0 	ret
    5d68:	72003c3f 	tst	w1, #0xffff
    5d6c:	54fffe60 	b.eq	5d38 <fwp_drop1+0x78>  // b.none
    5d70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d74:	f94013f5 	ldr	x21, [sp, #32]
    5d78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d7c:	d65f03c0 	ret
    5d80:	f9400813 	ldr	x19, [x0, #16]
    5d84:	97ffff87 	bl	5ba0 <fwp_rc_free_arr>
    5d88:	911742a0 	add	x0, x21, #0x5d0
    5d8c:	f949d801 	ldr	x1, [x0, #5040]
    5d90:	f949ec00 	ldr	x0, [x0, #5080]
    5d94:	cb010261 	sub	x1, x19, x1
    5d98:	eb00403f 	cmp	x1, x0, lsl #16
    5d9c:	54fffde2 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5da0:	aa1303e0 	mov	x0, x19
    5da4:	17ffffd2 	b	5cec <fwp_drop1+0x2c>
    5da8:	ca534660 	eor	x0, x19, x19, lsr #17
    5dac:	911742b5 	add	x21, x21, #0x5d0
    5db0:	ca402400 	eor	x0, x0, x0, lsr #9
    5db4:	92401c00 	and	x0, x0, #0xff
    5db8:	910a2402 	add	x2, x0, #0x289
    5dbc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5dc0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5dc4:	f94a2400 	ldr	x0, [x0, #5192]
    5dc8:	b50000a0 	cbnz	x0, 5ddc <fwp_drop1+0x11c>
    5dcc:	14000013 	b	5e18 <fwp_drop1+0x158>
    5dd0:	91004002 	add	x2, x0, #0x10
    5dd4:	f9400800 	ldr	x0, [x0, #16]
    5dd8:	b4000200 	cbz	x0, 5e18 <fwp_drop1+0x158>
    5ddc:	f9400001 	ldr	x1, [x0]
    5de0:	eb13003f 	cmp	x1, x19
    5de4:	54ffff61 	b.ne	5dd0 <fwp_drop1+0x110>  // b.any
    5de8:	f9400041 	ldr	x1, [x2]
    5dec:	f9400420 	ldr	x0, [x1, #8]
    5df0:	d1000400 	sub	x0, x0, #0x1
    5df4:	f9000420 	str	x0, [x1, #8]
    5df8:	f103f81f 	cmp	x0, #0xfe
    5dfc:	54fffae1 	b.ne	5d58 <fwp_drop1+0x98>  // b.any
    5e00:	39400260 	ldrb	w0, [x19]
    5e04:	7103fc1f 	cmp	w0, #0xff
    5e08:	540000e0 	b.eq	5e24 <fwp_drop1+0x164>  // b.none
    5e0c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e10:	39000260 	strb	w0, [x19]
    5e14:	17ffffd1 	b	5d58 <fwp_drop1+0x98>
    5e18:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5e1c:	910c6000 	add	x0, x0, #0x318
    5e20:	97fff8bc 	bl	4110 <fwp_trap>
    5e24:	aa1303e0 	mov	x0, x19
    5e28:	97fff8da 	bl	4190 <fwp_rc_forget_slot.part.0>
    5e2c:	17fffff8 	b	5e0c <fwp_drop1+0x14c>

0000000000005e30 <fwp_drop0>:
    5e30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e34:	910003fd 	mov	x29, sp
    5e38:	a90153f3 	stp	x19, x20, [sp, #16]
    5e3c:	f90013f5 	str	x21, [sp, #32]
    5e40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5e44:	911742b4 	add	x20, x21, #0x5d0
    5e48:	f949da81 	ldr	x1, [x20, #5040]
    5e4c:	f949ee82 	ldr	x2, [x20, #5080]
    5e50:	cb010001 	sub	x1, x0, x1
    5e54:	eb02403f 	cmp	x1, x2, lsl #16
    5e58:	54000382 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e5c:	d350fc22 	lsr	x2, x1, #16
    5e60:	f949fe84 	ldr	x4, [x20, #5112]
    5e64:	8b020842 	add	x2, x2, x2, lsl #2
    5e68:	d37df042 	lsl	x2, x2, #3
    5e6c:	8b020083 	add	x3, x4, x2
    5e70:	f9401073 	ldr	x19, [x3, #32]
    5e74:	b40002b3 	cbz	x19, 5ec8 <fwp_drop0+0x98>
    5e78:	38626882 	ldrb	w2, [x4, x2]
    5e7c:	7100085f 	cmp	w2, #0x2
    5e80:	540002c0 	b.eq	5ed8 <fwp_drop0+0xa8>  // b.none
    5e84:	7100045f 	cmp	w2, #0x1
    5e88:	54000201 	b.ne	5ec8 <fwp_drop0+0x98>  // b.any
    5e8c:	29430864 	ldp	w4, w2, [x3, #24]
    5e90:	92403c21 	and	x1, x1, #0xffff
    5e94:	9b047c21 	mul	x1, x1, x4
    5e98:	d360fc21 	lsr	x1, x1, #32
    5e9c:	eb02003f 	cmp	x1, x2
    5ea0:	54000142 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ea4:	8b010273 	add	x19, x19, x1
    5ea8:	39400261 	ldrb	w1, [x19]
    5eac:	340000e1 	cbz	w1, 5ec8 <fwp_drop0+0x98>
    5eb0:	7100043f 	cmp	w1, #0x1
    5eb4:	540001e0 	b.eq	5ef0 <fwp_drop0+0xc0>  // b.none
    5eb8:	7103fc3f 	cmp	w1, #0xff
    5ebc:	540002e0 	b.eq	5f18 <fwp_drop0+0xe8>  // b.none
    5ec0:	51000421 	sub	w1, w1, #0x1
    5ec4:	39000261 	strb	w1, [x19]
    5ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ecc:	f94013f5 	ldr	x21, [sp, #32]
    5ed0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ed4:	d65f03c0 	ret
    5ed8:	72003c3f 	tst	w1, #0xffff
    5edc:	54fffe60 	b.eq	5ea8 <fwp_drop0+0x78>  // b.none
    5ee0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ee4:	f94013f5 	ldr	x21, [sp, #32]
    5ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5eec:	d65f03c0 	ret
    5ef0:	f9400813 	ldr	x19, [x0, #16]
    5ef4:	97ffff2b 	bl	5ba0 <fwp_rc_free_arr>
    5ef8:	911742a0 	add	x0, x21, #0x5d0
    5efc:	f949d801 	ldr	x1, [x0, #5040]
    5f00:	f949ec00 	ldr	x0, [x0, #5080]
    5f04:	cb010261 	sub	x1, x19, x1
    5f08:	eb00403f 	cmp	x1, x0, lsl #16
    5f0c:	54fffde2 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f10:	aa1303e0 	mov	x0, x19
    5f14:	17ffffd2 	b	5e5c <fwp_drop0+0x2c>
    5f18:	ca534660 	eor	x0, x19, x19, lsr #17
    5f1c:	911742b5 	add	x21, x21, #0x5d0
    5f20:	ca402400 	eor	x0, x0, x0, lsr #9
    5f24:	92401c00 	and	x0, x0, #0xff
    5f28:	910a2402 	add	x2, x0, #0x289
    5f2c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5f30:	8b020ea2 	add	x2, x21, x2, lsl #3
    5f34:	f94a2400 	ldr	x0, [x0, #5192]
    5f38:	b50000a0 	cbnz	x0, 5f4c <fwp_drop0+0x11c>
    5f3c:	14000013 	b	5f88 <fwp_drop0+0x158>
    5f40:	91004002 	add	x2, x0, #0x10
    5f44:	f9400800 	ldr	x0, [x0, #16]
    5f48:	b4000200 	cbz	x0, 5f88 <fwp_drop0+0x158>
    5f4c:	f9400001 	ldr	x1, [x0]
    5f50:	eb13003f 	cmp	x1, x19
    5f54:	54ffff61 	b.ne	5f40 <fwp_drop0+0x110>  // b.any
    5f58:	f9400041 	ldr	x1, [x2]
    5f5c:	f9400420 	ldr	x0, [x1, #8]
    5f60:	d1000400 	sub	x0, x0, #0x1
    5f64:	f9000420 	str	x0, [x1, #8]
    5f68:	f103f81f 	cmp	x0, #0xfe
    5f6c:	54fffae1 	b.ne	5ec8 <fwp_drop0+0x98>  // b.any
    5f70:	39400260 	ldrb	w0, [x19]
    5f74:	7103fc1f 	cmp	w0, #0xff
    5f78:	540000e0 	b.eq	5f94 <fwp_drop0+0x164>  // b.none
    5f7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f80:	39000260 	strb	w0, [x19]
    5f84:	17ffffd1 	b	5ec8 <fwp_drop0+0x98>
    5f88:	d0000020 	adrp	x0, b000 <__modti3+0x280>
    5f8c:	910c6000 	add	x0, x0, #0x318
    5f90:	97fff860 	bl	4110 <fwp_trap>
    5f94:	aa1303e0 	mov	x0, x19
    5f98:	97fff87e 	bl	4190 <fwp_rc_forget_slot.part.0>
    5f9c:	17fffff8 	b	5f7c <fwp_drop0+0x14c>

0000000000005fa0 <fwp_arg_drop12>:
    5fa0:	7100003f 	cmp	w1, #0x0
    5fa4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5fa8:	54000041 	b.ne	5fb0 <fwp_arg_drop12+0x10>  // b.any
    5fac:	d65f03c0 	ret
    5fb0:	f9400000 	ldr	x0, [x0]
    5fb4:	17ffff9f 	b	5e30 <fwp_drop0>
    5fb8:	d503201f 	nop
    5fbc:	d503201f 	nop

0000000000005fc0 <fwp_closure_drop>:
    5fc0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5fc4:	911740a4 	add	x4, x5, #0x5d0
    5fc8:	aa0003e1 	mov	x1, x0
    5fcc:	f949d882 	ldr	x2, [x4, #5040]
    5fd0:	f949ec80 	ldr	x0, [x4, #5080]
    5fd4:	cb020022 	sub	x2, x1, x2
    5fd8:	eb00405f 	cmp	x2, x0, lsl #16
    5fdc:	54000662 	b.cs	60a8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5fe0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5fe4:	d350fc43 	lsr	x3, x2, #16
    5fe8:	910003fd 	mov	x29, sp
    5fec:	8b030863 	add	x3, x3, x3, lsl #2
    5ff0:	f949fc84 	ldr	x4, [x4, #5112]
    5ff4:	d37df063 	lsl	x3, x3, #3
    5ff8:	f9000bf3 	str	x19, [sp, #16]
    5ffc:	8b030080 	add	x0, x4, x3
    6000:	f9401013 	ldr	x19, [x0, #32]
    6004:	b40002b3 	cbz	x19, 6058 <fwp_closure_drop+0x98>
    6008:	38636883 	ldrb	w3, [x4, x3]
    600c:	7100087f 	cmp	w3, #0x2
    6010:	54000420 	b.eq	6094 <fwp_closure_drop+0xd4>  // b.none
    6014:	7100047f 	cmp	w3, #0x1
    6018:	54000201 	b.ne	6058 <fwp_closure_drop+0x98>  // b.any
    601c:	29430003 	ldp	w3, w0, [x0, #24]
    6020:	92403c42 	and	x2, x2, #0xffff
    6024:	9b037c42 	mul	x2, x2, x3
    6028:	d360fc42 	lsr	x2, x2, #32
    602c:	eb00005f 	cmp	x2, x0
    6030:	54000142 	b.cs	6058 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6034:	8b020273 	add	x19, x19, x2
    6038:	39400260 	ldrb	w0, [x19]
    603c:	340000e0 	cbz	w0, 6058 <fwp_closure_drop+0x98>
    6040:	7100041f 	cmp	w0, #0x1
    6044:	54000100 	b.eq	6064 <fwp_closure_drop+0xa4>  // b.none
    6048:	7103fc1f 	cmp	w0, #0xff
    604c:	54000300 	b.eq	60ac <fwp_closure_drop+0xec>  // b.none
    6050:	51000400 	sub	w0, w0, #0x1
    6054:	39000260 	strb	w0, [x19]
    6058:	f9400bf3 	ldr	x19, [sp, #16]
    605c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6060:	d65f03c0 	ret
    6064:	d53bd040 	mrs	x0, tpidr_el0
    6068:	91400000 	add	x0, x0, #0x0, lsl #12
    606c:	91004000 	add	x0, x0, #0x10
    6070:	f9400000 	ldr	x0, [x0]
    6074:	b4000080 	cbz	x0, 6084 <fwp_closure_drop+0xc4>
    6078:	f9400bf3 	ldr	x19, [sp, #16]
    607c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6080:	17fff9a0 	b	4700 <fwp_closure_drop_push>
    6084:	f9400bf3 	ldr	x19, [sp, #16]
    6088:	aa0103e0 	mov	x0, x1
    608c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6090:	17fff9e1 	b	4814 <fwp_closure_drop.part.0>
    6094:	72003c5f 	tst	w2, #0xffff
    6098:	54fffd00 	b.eq	6038 <fwp_closure_drop+0x78>  // b.none
    609c:	f9400bf3 	ldr	x19, [sp, #16]
    60a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60a4:	d65f03c0 	ret
    60a8:	d65f03c0 	ret
    60ac:	ca534660 	eor	x0, x19, x19, lsr #17
    60b0:	911740a5 	add	x5, x5, #0x5d0
    60b4:	ca402400 	eor	x0, x0, x0, lsr #9
    60b8:	92401c00 	and	x0, x0, #0xff
    60bc:	910a2402 	add	x2, x0, #0x289
    60c0:	8b000ca0 	add	x0, x5, x0, lsl #3
    60c4:	8b020ca2 	add	x2, x5, x2, lsl #3
    60c8:	f94a2400 	ldr	x0, [x0, #5192]
    60cc:	b50000a0 	cbnz	x0, 60e0 <fwp_closure_drop+0x120>
    60d0:	14000013 	b	611c <fwp_closure_drop+0x15c>
    60d4:	91004002 	add	x2, x0, #0x10
    60d8:	f9400800 	ldr	x0, [x0, #16]
    60dc:	b4000200 	cbz	x0, 611c <fwp_closure_drop+0x15c>
    60e0:	f9400001 	ldr	x1, [x0]
    60e4:	eb13003f 	cmp	x1, x19
    60e8:	54ffff61 	b.ne	60d4 <fwp_closure_drop+0x114>  // b.any
    60ec:	f9400041 	ldr	x1, [x2]
    60f0:	f9400420 	ldr	x0, [x1, #8]
    60f4:	d1000400 	sub	x0, x0, #0x1
    60f8:	f9000420 	str	x0, [x1, #8]
    60fc:	f103f81f 	cmp	x0, #0xfe
    6100:	54fffac1 	b.ne	6058 <fwp_closure_drop+0x98>  // b.any
    6104:	39400260 	ldrb	w0, [x19]
    6108:	7103fc1f 	cmp	w0, #0xff
    610c:	540000e0 	b.eq	6128 <fwp_closure_drop+0x168>  // b.none
    6110:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6114:	39000260 	strb	w0, [x19]
    6118:	17ffffd0 	b	6058 <fwp_closure_drop+0x98>
    611c:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    6120:	910c6000 	add	x0, x0, #0x318
    6124:	97fff7fb 	bl	4110 <fwp_trap>
    6128:	aa1303e0 	mov	x0, x19
    612c:	97fff819 	bl	4190 <fwp_rc_forget_slot.part.0>
    6130:	17fffff8 	b	6110 <fwp_closure_drop+0x150>

0000000000006134 <fwp_owned_tape_release>:
    6134:	b4000920 	cbz	x0, 6258 <fwp_owned_tape_release+0x124>
    6138:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    613c:	910003fd 	mov	x29, sp
    6140:	a90153f3 	stp	x19, x20, [sp, #16]
    6144:	aa0003f3 	mov	x19, x0
    6148:	f9400000 	ldr	x0, [x0]
    614c:	b4000060 	cbz	x0, 6158 <fwp_owned_tape_release+0x24>
    6150:	f9400661 	ldr	x1, [x19, #8]
    6154:	f9000401 	str	x1, [x0, #8]
    6158:	f9400661 	ldr	x1, [x19, #8]
    615c:	b4000041 	cbz	x1, 6164 <fwp_owned_tape_release+0x30>
    6160:	f9000020 	str	x0, [x1]
    6164:	f9400a60 	ldr	x0, [x19, #16]
    6168:	f9403401 	ldr	x1, [x0, #104]
    616c:	b40005a1 	cbz	x1, 6220 <fwp_owned_tape_release+0xec>
    6170:	a9450a60 	ldp	x0, x2, [x19, #80]
    6174:	eb00005f 	cmp	x2, x0
    6178:	540002cd 	b.le	61d0 <fwp_owned_tape_release+0x9c>
    617c:	d2800014 	mov	x20, #0x0                   	// #0
    6180:	f90013f5 	str	x21, [sp, #32]
    6184:	d2800015 	mov	x21, #0x0                   	// #0
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	910006b5 	add	x21, x21, #0x1
    6190:	f8746800 	ldr	x0, [x0, x20]
    6194:	d63f0020 	blr	x1
    6198:	f9402260 	ldr	x0, [x19, #64]
    619c:	f9400a61 	ldr	x1, [x19, #16]
    61a0:	8b140000 	add	x0, x0, x20
    61a4:	91004294 	add	x20, x20, #0x10
    61a8:	f9400400 	ldr	x0, [x0, #8]
    61ac:	f9403421 	ldr	x1, [x1, #104]
    61b0:	d63f0020 	blr	x1
    61b4:	a9450261 	ldp	x1, x0, [x19, #80]
    61b8:	cb010000 	sub	x0, x0, x1
    61bc:	eb15001f 	cmp	x0, x21
    61c0:	f9400a60 	ldr	x0, [x19, #16]
    61c4:	f9403401 	ldr	x1, [x0, #104]
    61c8:	54fffe0c 	b.gt	6188 <fwp_owned_tape_release+0x54>
    61cc:	f94013f5 	ldr	x21, [sp, #32]
    61d0:	f9403663 	ldr	x3, [x19, #104]
    61d4:	f9401262 	ldr	x2, [x19, #32]
    61d8:	f100007f 	cmp	x3, #0x0
    61dc:	540001ed 	b.le	6218 <fwp_owned_tape_release+0xe4>
    61e0:	d2800014 	mov	x20, #0x0                   	// #0
    61e4:	d503201f 	nop
    61e8:	f9402660 	ldr	x0, [x19, #72]
    61ec:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    61f0:	eb02001f 	cmp	x0, x2
    61f4:	540000c0 	b.eq	620c <fwp_owned_tape_release+0xd8>  // b.none
    61f8:	d63f0020 	blr	x1
    61fc:	f9400a60 	ldr	x0, [x19, #16]
    6200:	f9401262 	ldr	x2, [x19, #32]
    6204:	f9403663 	ldr	x3, [x19, #104]
    6208:	f9403401 	ldr	x1, [x0, #104]
    620c:	91000694 	add	x20, x20, #0x1
    6210:	eb14007f 	cmp	x3, x20
    6214:	54fffeac 	b.gt	61e8 <fwp_owned_tape_release+0xb4>
    6218:	aa0203e0 	mov	x0, x2
    621c:	d63f0020 	blr	x1
    6220:	f9401660 	ldr	x0, [x19, #40]
    6224:	97ffff67 	bl	5fc0 <fwp_closure_drop>
    6228:	f9401a60 	ldr	x0, [x19, #48]
    622c:	97ffff65 	bl	5fc0 <fwp_closure_drop>
    6230:	f9401e60 	ldr	x0, [x19, #56]
    6234:	97ffff63 	bl	5fc0 <fwp_closure_drop>
    6238:	f9402260 	ldr	x0, [x19, #64]
    623c:	97fff871 	bl	4400 <fwp_mem_free>
    6240:	f9402660 	ldr	x0, [x19, #72]
    6244:	97fff86f 	bl	4400 <fwp_mem_free>
    6248:	aa1303e0 	mov	x0, x19
    624c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6250:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6254:	17fff86b 	b	4400 <fwp_mem_free>
    6258:	d65f03c0 	ret
    625c:	d503201f 	nop

0000000000006260 <fwp_tape_finish>:
    6260:	d10203ff 	sub	sp, sp, #0x80
    6264:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6268:	f947f421 	ldr	x1, [x1, #4072]
    626c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6270:	910103fd 	add	x29, sp, #0x40
    6274:	a90553f3 	stp	x19, x20, [sp, #80]
    6278:	a9065bf5 	stp	x21, x22, [sp, #96]
    627c:	a90763f7 	stp	x23, x24, [sp, #112]
    6280:	d00000d8 	adrp	x24, 20000 <__data_start>
    6284:	9101c316 	add	x22, x24, #0x70
    6288:	f9400022 	ldr	x2, [x1]
    628c:	f9001fe2 	str	x2, [sp, #56]
    6290:	d2800002 	mov	x2, #0x0                   	// #0
    6294:	910222c0 	add	x0, x22, #0x88
    6298:	97fff47a 	bl	3480 <fwp_tape_buffers_dispose>
    629c:	f90062df 	str	xzr, [x22, #192]
    62a0:	f9406ac0 	ldr	x0, [x22, #208]
    62a4:	f100001f 	cmp	x0, #0x0
    62a8:	5400030d 	b.le	6308 <fwp_tape_finish+0xa8>
    62ac:	910003f7 	mov	x23, sp
    62b0:	d2800015 	mov	x21, #0x0                   	// #0
    62b4:	d2800014 	mov	x20, #0x0                   	// #0
    62b8:	f94002d3 	ldr	x19, [x22]
    62bc:	91000694 	add	x20, x20, #0x1
    62c0:	8b150273 	add	x19, x19, x21
    62c4:	9101a2b5 	add	x21, x21, #0x68
    62c8:	aa1303e0 	mov	x0, x19
    62cc:	97fff331 	bl	2f90 <fwp_tape_unlink_scope>
    62d0:	aa1703e0 	mov	x0, x23
    62d4:	f9401261 	ldr	x1, [x19, #32]
    62d8:	f90003e1 	str	x1, [sp]
    62dc:	f9401a62 	ldr	x2, [x19, #48]
    62e0:	f9000be2 	str	x2, [sp, #16]
    62e4:	f9402261 	ldr	x1, [x19, #64]
    62e8:	f90013e1 	str	x1, [sp, #32]
    62ec:	97fff465 	bl	3480 <fwp_tape_buffers_dispose>
    62f0:	f9403260 	ldr	x0, [x19, #96]
    62f4:	97ffff90 	bl	6134 <fwp_owned_tape_release>
    62f8:	f900327f 	str	xzr, [x19, #96]
    62fc:	f9406ac0 	ldr	x0, [x22, #208]
    6300:	eb14001f 	cmp	x0, x20
    6304:	54fffdac 	b.gt	62b8 <fwp_tape_finish+0x58>
    6308:	f9403b00 	ldr	x0, [x24, #112]
    630c:	9101c313 	add	x19, x24, #0x70
    6310:	97fff18c 	bl	2940 <free@plt>
    6314:	f9003b1f 	str	xzr, [x24, #112]
    6318:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    631c:	f947f400 	ldr	x0, [x0, #4072]
    6320:	f9006a7f 	str	xzr, [x19, #208]
    6324:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6328:	f9401fe2 	ldr	x2, [sp, #56]
    632c:	f9400001 	ldr	x1, [x0]
    6330:	eb010042 	subs	x2, x2, x1
    6334:	d2800001 	mov	x1, #0x0                   	// #0
    6338:	540000e1 	b.ne	6354 <fwp_tape_finish+0xf4>  // b.any
    633c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6340:	a94553f3 	ldp	x19, x20, [sp, #80]
    6344:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6348:	a94763f7 	ldp	x23, x24, [sp, #112]
    634c:	910203ff 	add	sp, sp, #0x80
    6350:	d65f03c0 	ret
    6354:	97fff14b 	bl	2880 <__stack_chk_fail@plt>
    6358:	d503201f 	nop
    635c:	d503201f 	nop

0000000000006360 <fwp_tape_scope_release>:
    6360:	d10243ff 	sub	sp, sp, #0x90
    6364:	a9047bfd 	stp	x29, x30, [sp, #64]
    6368:	910103fd 	add	x29, sp, #0x40
    636c:	a90553f3 	stp	x19, x20, [sp, #80]
    6370:	aa0003f4 	mov	x20, x0
    6374:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6378:	f947f400 	ldr	x0, [x0, #4072]
    637c:	b9400285 	ldr	w5, [x20]
    6380:	f9400001 	ldr	x1, [x0]
    6384:	f9001fe1 	str	x1, [sp, #56]
    6388:	d2800001 	mov	x1, #0x0                   	// #0
    638c:	37f806c5 	tbnz	w5, #31, 6464 <fwp_tape_scope_release+0x104>
    6390:	a90763f7 	stp	x23, x24, [sp, #112]
    6394:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6398:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    639c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    63a0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63a4:	910003f7 	mov	x23, sp
    63a8:	9101c273 	add	x19, x19, #0x70
    63ac:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    63b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63b4:	52800d16 	mov	w22, #0x68                  	// #104
    63b8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    63bc:	f90043f9 	str	x25, [sp, #128]
    63c0:	14000006 	b	63d8 <fwp_tape_scope_release+0x78>
    63c4:	97fff42f 	bl	3480 <fwp_tape_buffers_dispose>
    63c8:	aa1903e0 	mov	x0, x25
    63cc:	97ffff5a 	bl	6134 <fwp_owned_tape_release>
    63d0:	b9400285 	ldr	w5, [x20]
    63d4:	37f80425 	tbnz	w5, #31, 6458 <fwp_tape_scope_release+0xf8>
    63d8:	f9400266 	ldr	x6, [x19]
    63dc:	9b367ca5 	smull	x5, w5, w22
    63e0:	8b0500c0 	add	x0, x6, x5
    63e4:	97fff2eb 	bl	2f90 <fwp_tape_unlink_scope>
    63e8:	ad410001 	ldp	q1, q0, [x0, #32]
    63ec:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    63f0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    63f4:	f9400c03 	ldr	x3, [x0, #24]
    63f8:	ad0003e1 	stp	q1, q0, [sp]
    63fc:	b86568c1 	ldr	w1, [x6, x5]
    6400:	a9440804 	ldp	x4, x2, [x0, #64]
    6404:	b900041f 	str	wzr, [x0, #4]
    6408:	f9403019 	ldr	x25, [x0, #96]
    640c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6410:	f9000c1f 	str	xzr, [x0, #24]
    6414:	a9020fe4 	stp	x4, x3, [sp, #32]
    6418:	f9001be2 	str	x2, [sp, #48]
    641c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6420:	f900301f 	str	xzr, [x0, #96]
    6424:	6b15003f 	cmp	w1, w21
    6428:	540000e8 	b.hi	6444 <fwp_tape_scope_release+0xe4>  // b.pmore
    642c:	9343fca5 	asr	x5, x5, #3
    6430:	f9407660 	ldr	x0, [x19, #232]
    6434:	9b187ca5 	mul	x5, x5, x24
    6438:	eb0000bf 	cmp	x5, x0
    643c:	5400004a 	b.ge	6444 <fwp_tape_scope_release+0xe4>  // b.tcont
    6440:	f9007665 	str	x5, [x19, #232]
    6444:	aa1703e0 	mov	x0, x23
    6448:	b5fffbf9 	cbnz	x25, 63c4 <fwp_tape_scope_release+0x64>
    644c:	97fff6e9 	bl	3ff0 <fwp_tape_buffers_release>
    6450:	b9400285 	ldr	w5, [x20]
    6454:	36fffc25 	tbz	w5, #31, 63d8 <fwp_tape_scope_release+0x78>
    6458:	a9465bf5 	ldp	x21, x22, [sp, #96]
    645c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6460:	f94043f9 	ldr	x25, [sp, #128]
    6464:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6468:	f947f400 	ldr	x0, [x0, #4072]
    646c:	f9401fe2 	ldr	x2, [sp, #56]
    6470:	f9400001 	ldr	x1, [x0]
    6474:	eb010042 	subs	x2, x2, x1
    6478:	d2800001 	mov	x1, #0x0                   	// #0
    647c:	540000a1 	b.ne	6490 <fwp_tape_scope_release+0x130>  // b.any
    6480:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6484:	a94553f3 	ldp	x19, x20, [sp, #80]
    6488:	910243ff 	add	sp, sp, #0x90
    648c:	d65f03c0 	ret
    6490:	a9065bf5 	stp	x21, x22, [sp, #96]
    6494:	a90763f7 	stp	x23, x24, [sp, #112]
    6498:	f90043f9 	str	x25, [sp, #128]
    649c:	97fff0f9 	bl	2880 <__stack_chk_fail@plt>

00000000000064a0 <fwp_task_dispose>:
    64a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64a4:	910003fd 	mov	x29, sp
    64a8:	f9000bf3 	str	x19, [sp, #16]
    64ac:	aa0003f3 	mov	x19, x0
    64b0:	39414000 	ldrb	w0, [x0, #80]
    64b4:	36000720 	tbz	w0, #0, 6598 <fwp_task_dispose+0xf8>
    64b8:	f9400a60 	ldr	x0, [x19, #16]
    64bc:	b50006e0 	cbnz	x0, 6598 <fwp_task_dispose+0xf8>
    64c0:	a9478660 	ldp	x0, x1, [x19, #120]
    64c4:	39014e7f 	strb	wzr, [x19, #83]
    64c8:	f9003e7f 	str	xzr, [x19, #120]
    64cc:	f100003f 	cmp	x1, #0x0
    64d0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64d4:	54000040 	b.eq	64dc <fwp_task_dispose+0x3c>  // b.none
    64d8:	d63f0020 	blr	x1
    64dc:	f9405660 	ldr	x0, [x19, #168]
    64e0:	97fff7c8 	bl	4400 <fwp_mem_free>
    64e4:	f900567f 	str	xzr, [x19, #168]
    64e8:	b9405e60 	ldr	w0, [x19, #92]
    64ec:	7100041f 	cmp	w0, #0x1
    64f0:	54000420 	b.eq	6574 <fwp_task_dispose+0xd4>  // b.none
    64f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    64f8:	91174042 	add	x2, x2, #0x5d0
    64fc:	f949d840 	ldr	x0, [x2, #5040]
    6500:	f949ec41 	ldr	x1, [x2, #5080]
    6504:	cb000260 	sub	x0, x19, x0
    6508:	eb01401f 	cmp	x0, x1, lsl #16
    650c:	540002e2 	b.cs	6568 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6510:	d350fc01 	lsr	x1, x0, #16
    6514:	f949fc44 	ldr	x4, [x2, #5112]
    6518:	8b010821 	add	x1, x1, x1, lsl #2
    651c:	d37df021 	lsl	x1, x1, #3
    6520:	8b010083 	add	x3, x4, x1
    6524:	f9401062 	ldr	x2, [x3, #32]
    6528:	b4000202 	cbz	x2, 6568 <fwp_task_dispose+0xc8>
    652c:	38616881 	ldrb	w1, [x4, x1]
    6530:	7100083f 	cmp	w1, #0x2
    6534:	54000280 	b.eq	6584 <fwp_task_dispose+0xe4>  // b.none
    6538:	7100043f 	cmp	w1, #0x1
    653c:	54000161 	b.ne	6568 <fwp_task_dispose+0xc8>  // b.any
    6540:	29430464 	ldp	w4, w1, [x3, #24]
    6544:	92403c00 	and	x0, x0, #0xffff
    6548:	9b047c00 	mul	x0, x0, x4
    654c:	d360fc00 	lsr	x0, x0, #32
    6550:	eb01001f 	cmp	x0, x1
    6554:	540000a2 	b.cs	6568 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6558:	8b000042 	add	x2, x2, x0
    655c:	39400040 	ldrb	w0, [x2]
    6560:	7100041f 	cmp	w0, #0x1
    6564:	54000080 	b.eq	6574 <fwp_task_dispose+0xd4>  // b.none
    6568:	f9400bf3 	ldr	x19, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	d65f03c0 	ret
    6574:	aa1303e0 	mov	x0, x19
    6578:	f9400bf3 	ldr	x19, [sp, #16]
    657c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6580:	17fff7a0 	b	4400 <fwp_mem_free>
    6584:	72003c1f 	tst	w0, #0xffff
    6588:	54fffea0 	b.eq	655c <fwp_task_dispose+0xbc>  // b.none
    658c:	f9400bf3 	ldr	x19, [sp, #16]
    6590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6594:	d65f03c0 	ret
    6598:	97fff0ce 	bl	28d0 <abort@plt>
    659c:	d503201f 	nop

00000000000065a0 <fwp_free_zombie>:
    65a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	a90153f3 	stp	x19, x20, [sp, #16]
    65ac:	d00000d4 	adrp	x20, 20000 <__data_start>
    65b0:	9101c281 	add	x1, x20, #0x70
    65b4:	f9407833 	ldr	x19, [x1, #240]
    65b8:	b4000333 	cbz	x19, 661c <fwp_free_zombie+0x7c>
    65bc:	f9400820 	ldr	x0, [x1, #16]
    65c0:	eb00027f 	cmp	x19, x0
    65c4:	540002c0 	b.eq	661c <fwp_free_zombie+0x7c>  // b.none
    65c8:	b940f822 	ldr	w2, [x1, #248]
    65cc:	f9400a60 	ldr	x0, [x19, #16]
    65d0:	7100fc5f 	cmp	w2, #0x3f
    65d4:	5400078c 	b.gt	66c4 <fwp_free_zombie+0x124>
    65d8:	91040023 	add	x3, x1, #0x100
    65dc:	11000444 	add	w4, w2, #0x1
    65e0:	b900f824 	str	w4, [x1, #248]
    65e4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65e8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65ec:	a9530261 	ldp	x1, x0, [x19, #304]
    65f0:	b4000741 	cbz	x1, 66d8 <fwp_free_zombie+0x138>
    65f4:	f9009c20 	str	x0, [x1, #312]
    65f8:	b4000040 	cbz	x0, 6600 <fwp_free_zombie+0x60>
    65fc:	f9009801 	str	x1, [x0, #304]
    6600:	9101c294 	add	x20, x20, #0x70
    6604:	b9405e60 	ldr	w0, [x19, #92]
    6608:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    660c:	f9007a9f 	str	xzr, [x20, #240]
    6610:	34000140 	cbz	w0, 6638 <fwp_free_zombie+0x98>
    6614:	7100041f 	cmp	w0, #0x1
    6618:	54000080 	b.eq	6628 <fwp_free_zombie+0x88>  // b.none
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6624:	d65f03c0 	ret
    6628:	aa1303e0 	mov	x0, x19
    662c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6630:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6634:	17ffff9b 	b	64a0 <fwp_task_dispose>
    6638:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    663c:	91174082 	add	x2, x4, #0x5d0
    6640:	f949d841 	ldr	x1, [x2, #5040]
    6644:	f949ec40 	ldr	x0, [x2, #5080]
    6648:	cb010261 	sub	x1, x19, x1
    664c:	eb00403f 	cmp	x1, x0, lsl #16
    6650:	54fffe62 	b.cs	661c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6654:	d350fc20 	lsr	x0, x1, #16
    6658:	f949fc43 	ldr	x3, [x2, #5112]
    665c:	8b000800 	add	x0, x0, x0, lsl #2
    6660:	d37df000 	lsl	x0, x0, #3
    6664:	8b000062 	add	x2, x3, x0
    6668:	f9401054 	ldr	x20, [x2, #32]
    666c:	b4fffd94 	cbz	x20, 661c <fwp_free_zombie+0x7c>
    6670:	38606860 	ldrb	w0, [x3, x0]
    6674:	7100081f 	cmp	w0, #0x2
    6678:	54000360 	b.eq	66e4 <fwp_free_zombie+0x144>  // b.none
    667c:	7100041f 	cmp	w0, #0x1
    6680:	54fffce1 	b.ne	661c <fwp_free_zombie+0x7c>  // b.any
    6684:	29430043 	ldp	w3, w0, [x2, #24]
    6688:	92403c21 	and	x1, x1, #0xffff
    668c:	9b037c21 	mul	x1, x1, x3
    6690:	d360fc21 	lsr	x1, x1, #32
    6694:	eb00003f 	cmp	x1, x0
    6698:	54fffc22 	b.cs	661c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    669c:	8b010294 	add	x20, x20, x1
    66a0:	39400280 	ldrb	w0, [x20]
    66a4:	34fffbc0 	cbz	w0, 661c <fwp_free_zombie+0x7c>
    66a8:	7100041f 	cmp	w0, #0x1
    66ac:	54fffbe0 	b.eq	6628 <fwp_free_zombie+0x88>  // b.none
    66b0:	7103fc1f 	cmp	w0, #0xff
    66b4:	540001e0 	b.eq	66f0 <fwp_free_zombie+0x150>  // b.none
    66b8:	51000400 	sub	w0, w0, #0x1
    66bc:	39000280 	strb	w0, [x20]
    66c0:	17ffffd7 	b	661c <fwp_free_zombie+0x7c>
    66c4:	f9400e61 	ldr	x1, [x19, #24]
    66c8:	97fff0b6 	bl	29a0 <munmap@plt>
    66cc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66d0:	a9530261 	ldp	x1, x0, [x19, #304]
    66d4:	b5fff901 	cbnz	x1, 65f4 <fwp_free_zombie+0x54>
    66d8:	9101c282 	add	x2, x20, #0x70
    66dc:	f9018040 	str	x0, [x2, #768]
    66e0:	17ffffc6 	b	65f8 <fwp_free_zombie+0x58>
    66e4:	72003c3f 	tst	w1, #0xffff
    66e8:	54fff9a1 	b.ne	661c <fwp_free_zombie+0x7c>  // b.any
    66ec:	17ffffed 	b	66a0 <fwp_free_zombie+0x100>
    66f0:	ca544680 	eor	x0, x20, x20, lsr #17
    66f4:	91174084 	add	x4, x4, #0x5d0
    66f8:	ca402400 	eor	x0, x0, x0, lsr #9
    66fc:	92401c00 	and	x0, x0, #0xff
    6700:	910a2402 	add	x2, x0, #0x289
    6704:	8b000c80 	add	x0, x4, x0, lsl #3
    6708:	8b020c82 	add	x2, x4, x2, lsl #3
    670c:	f94a2400 	ldr	x0, [x0, #5192]
    6710:	b50000a0 	cbnz	x0, 6724 <fwp_free_zombie+0x184>
    6714:	14000013 	b	6760 <fwp_free_zombie+0x1c0>
    6718:	91004002 	add	x2, x0, #0x10
    671c:	f9400800 	ldr	x0, [x0, #16]
    6720:	b4000200 	cbz	x0, 6760 <fwp_free_zombie+0x1c0>
    6724:	f9400001 	ldr	x1, [x0]
    6728:	eb14003f 	cmp	x1, x20
    672c:	54ffff61 	b.ne	6718 <fwp_free_zombie+0x178>  // b.any
    6730:	f9400041 	ldr	x1, [x2]
    6734:	f9400420 	ldr	x0, [x1, #8]
    6738:	d1000400 	sub	x0, x0, #0x1
    673c:	f9000420 	str	x0, [x1, #8]
    6740:	f103f81f 	cmp	x0, #0xfe
    6744:	54fff6c1 	b.ne	661c <fwp_free_zombie+0x7c>  // b.any
    6748:	39400280 	ldrb	w0, [x20]
    674c:	7103fc1f 	cmp	w0, #0xff
    6750:	540000e0 	b.eq	676c <fwp_free_zombie+0x1cc>  // b.none
    6754:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6758:	39000280 	strb	w0, [x20]
    675c:	17ffffb0 	b	661c <fwp_free_zombie+0x7c>
    6760:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    6764:	910c6000 	add	x0, x0, #0x318
    6768:	97fff66a 	bl	4110 <fwp_trap>
    676c:	aa1403e0 	mov	x0, x20
    6770:	97fff688 	bl	4190 <fwp_rc_forget_slot.part.0>
    6774:	17fffff8 	b	6754 <fwp_free_zombie+0x1b4>
    6778:	d503201f 	nop
    677c:	d503201f 	nop

0000000000006780 <fwp_block>:
    6780:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6784:	910003fd 	mov	x29, sp
    6788:	a90153f3 	stp	x19, x20, [sp, #16]
    678c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6790:	9101c274 	add	x20, x19, #0x70
    6794:	f9404282 	ldr	x2, [x20, #128]
    6798:	b4000642 	cbz	x2, 6860 <fwp_block+0xe0>
    679c:	9101c261 	add	x1, x19, #0x70
    67a0:	f9408040 	ldr	x0, [x2, #256]
    67a4:	f9004020 	str	x0, [x1, #128]
    67a8:	b40006a0 	cbz	x0, 687c <fwp_block+0xfc>
    67ac:	d503201f 	nop
    67b0:	9101c263 	add	x3, x19, #0x70
    67b4:	3901505f 	strb	wzr, [x2, #84]
    67b8:	f9400864 	ldr	x4, [x3, #16]
    67bc:	eb02009f 	cmp	x4, x2
    67c0:	54000440 	b.eq	6848 <fwp_block+0xc8>  // b.none
    67c4:	f9418465 	ldr	x5, [x3, #776]
    67c8:	f9000862 	str	x2, [x3, #16]
    67cc:	f9400441 	ldr	x1, [x2, #8]
    67d0:	f9004885 	str	x5, [x4, #144]
    67d4:	f9418865 	ldr	x5, [x3, #784]
    67d8:	f9004c85 	str	x5, [x4, #152]
    67dc:	f9418c65 	ldr	x5, [x3, #792]
    67e0:	f9005085 	str	x5, [x4, #160]
    67e4:	f9419065 	ldr	x5, [x3, #800]
    67e8:	f9005485 	str	x5, [x4, #168]
    67ec:	f9419465 	ldr	x5, [x3, #808]
    67f0:	f9005885 	str	x5, [x4, #176]
    67f4:	f9419865 	ldr	x5, [x3, #816]
    67f8:	f9005c85 	str	x5, [x4, #184]
    67fc:	f9419c65 	ldr	x5, [x3, #824]
    6800:	f9006085 	str	x5, [x4, #192]
    6804:	f9400480 	ldr	x0, [x4, #8]
    6808:	f9404844 	ldr	x4, [x2, #144]
    680c:	f9018464 	str	x4, [x3, #776]
    6810:	f9404c44 	ldr	x4, [x2, #152]
    6814:	f9018864 	str	x4, [x3, #784]
    6818:	f9405044 	ldr	x4, [x2, #160]
    681c:	f9018c64 	str	x4, [x3, #792]
    6820:	f9405444 	ldr	x4, [x2, #168]
    6824:	f9019064 	str	x4, [x3, #800]
    6828:	f9405844 	ldr	x4, [x2, #176]
    682c:	f9019464 	str	x4, [x3, #808]
    6830:	a94b8844 	ldp	x4, x2, [x2, #184]
    6834:	f9019864 	str	x4, [x3, #816]
    6838:	f9019c62 	str	x2, [x3, #824]
    683c:	97fff029 	bl	28e0 <swapcontext@plt>
    6840:	97ffff58 	bl	65a0 <fwp_free_zombie>
    6844:	d503201f 	nop
    6848:	9101c260 	add	x0, x19, #0x70
    684c:	b9434000 	ldr	w0, [x0, #832]
    6850:	340001a0 	cbz	w0, 6884 <fwp_block+0x104>
    6854:	a94153f3 	ldp	x19, x20, [sp, #16]
    6858:	a8c27bfd 	ldp	x29, x30, [sp], #32
    685c:	d65f03c0 	ret
    6860:	97fff874 	bl	4a30 <fwp_poll_events>
    6864:	f9404282 	ldr	x2, [x20, #128]
    6868:	b4ffffc2 	cbz	x2, 6860 <fwp_block+0xe0>
    686c:	9101c261 	add	x1, x19, #0x70
    6870:	f9408040 	ldr	x0, [x2, #256]
    6874:	f9004020 	str	x0, [x1, #128]
    6878:	b5fff9c0 	cbnz	x0, 67b0 <fwp_block+0x30>
    687c:	f9003c3f 	str	xzr, [x1, #120]
    6880:	17ffffcc 	b	67b0 <fwp_block+0x30>
    6884:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    6888:	9116c000 	add	x0, x0, #0x5b0
    688c:	97fff061 	bl	2a10 <getenv@plt>
    6890:	5284e202 	mov	w2, #0x2710                	// #10000
    6894:	b4000060 	cbz	x0, 68a0 <fwp_block+0x120>
    6898:	39400001 	ldrb	w1, [x0]
    689c:	350000c1 	cbnz	w1, 68b4 <fwp_block+0x134>
    68a0:	9101c273 	add	x19, x19, #0x70
    68a4:	b9034262 	str	w2, [x19, #832]
    68a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b0:	d65f03c0 	ret
    68b4:	52800142 	mov	w2, #0xa                   	// #10
    68b8:	d2800001 	mov	x1, #0x0                   	// #0
    68bc:	97ffefa5 	bl	2750 <strtoll@plt>
    68c0:	d1000403 	sub	x3, x0, #0x1
    68c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    68c8:	eb02007f 	cmp	x3, x2
    68cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    68d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    68d4:	17fffff3 	b	68a0 <fwp_block+0x120>
    68d8:	d503201f 	nop
    68dc:	d503201f 	nop

00000000000068e0 <fwp_owned_entry161>:
    68e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    68e4:	910003fd 	mov	x29, sp
    68e8:	a90363f7 	stp	x23, x24, [sp, #48]
    68ec:	a9406002 	ldp	x2, x24, [x0]
    68f0:	a90153f3 	stp	x19, x20, [sp, #16]
    68f4:	f9400801 	ldr	x1, [x0, #16]
    68f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    68fc:	ab010055 	adds	x21, x2, x1
    6900:	54000d06 	b.vs	6aa0 <fwp_owned_entry161+0x1c0>
    6904:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6908:	91174281 	add	x1, x20, #0x5d0
    690c:	b953a420 	ldr	w0, [x1, #5028]
    6910:	34000a80 	cbz	w0, 6a60 <fwp_owned_entry161+0x180>
    6914:	397e8820 	ldrb	w0, [x1, #4002]
    6918:	910f0002 	add	x2, x0, #0x3c0
    691c:	8b000400 	add	x0, x0, x0, lsl #1
    6920:	d37df000 	lsl	x0, x0, #3
    6924:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6928:	2a1703f6 	mov	w22, w23
    692c:	f8606833 	ldr	x19, [x1, x0]
    6930:	b4000853 	cbz	x19, 6a38 <fwp_owned_entry161+0x158>
    6934:	f9400262 	ldr	x2, [x19]
    6938:	aa2203e2 	mvn	x2, x2
    693c:	f8206822 	str	x2, [x1, x0]
    6940:	f10062df 	cmp	x22, #0x18
    6944:	540000e9 	b.ls	6960 <fwp_owned_entry161+0x80>  // b.plast
    6948:	d10066c2 	sub	x2, x22, #0x19
    694c:	91006260 	add	x0, x19, #0x18
    6950:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6954:	52800001 	mov	w1, #0x0                   	// #0
    6958:	91002042 	add	x2, x2, #0x8
    695c:	97ffefbd 	bl	2850 <memset@plt>
    6960:	91174281 	add	x1, x20, #0x5d0
    6964:	f94a1020 	ldr	x0, [x1, #5152]
    6968:	ab160000 	adds	x0, x0, x22
    696c:	540009c2 	b.cs	6aa4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6970:	f94a1422 	ldr	x2, [x1, #5160]
    6974:	f90a1020 	str	x0, [x1, #5152]
    6978:	eb02001f 	cmp	x0, x2
    697c:	54000049 	b.ls	6984 <fwp_owned_entry161+0xa4>  // b.plast
    6980:	f90a1420 	str	x0, [x1, #5160]
    6984:	91174280 	add	x0, x20, #0x5d0
    6988:	1e6302e1 	ucvtf	d1, w23
    698c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6990:	1e612800 	fadd	d0, d0, d1
    6994:	fd0a1c00 	str	d0, [x0, #5176]
    6998:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    699c:	91174294 	add	x20, x20, #0x5d0
    69a0:	a900d678 	stp	x24, x21, [x19, #8]
    69a4:	fd478800 	ldr	d0, [x0, #3856]
    69a8:	fd000260 	str	d0, [x19]
    69ac:	f949da81 	ldr	x1, [x20, #5040]
    69b0:	f949ee80 	ldr	x0, [x20, #5080]
    69b4:	cb010261 	sub	x1, x19, x1
    69b8:	eb00403f 	cmp	x1, x0, lsl #16
    69bc:	54000322 	b.cs	6a20 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    69c0:	d350fc20 	lsr	x0, x1, #16
    69c4:	f949fe83 	ldr	x3, [x20, #5112]
    69c8:	8b000800 	add	x0, x0, x0, lsl #2
    69cc:	d37df002 	lsl	x2, x0, #3
    69d0:	8b020060 	add	x0, x3, x2
    69d4:	f9401014 	ldr	x20, [x0, #32]
    69d8:	b4000254 	cbz	x20, 6a20 <fwp_owned_entry161+0x140>
    69dc:	38626862 	ldrb	w2, [x3, x2]
    69e0:	7100085f 	cmp	w2, #0x2
    69e4:	54000480 	b.eq	6a74 <fwp_owned_entry161+0x194>  // b.none
    69e8:	7100045f 	cmp	w2, #0x1
    69ec:	540001a1 	b.ne	6a20 <fwp_owned_entry161+0x140>  // b.any
    69f0:	29430002 	ldp	w2, w0, [x0, #24]
    69f4:	92403c21 	and	x1, x1, #0xffff
    69f8:	9b027c21 	mul	x1, x1, x2
    69fc:	d360fc21 	lsr	x1, x1, #32
    6a00:	eb00003f 	cmp	x1, x0
    6a04:	540000e2 	b.cs	6a20 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6a08:	8b010294 	add	x20, x20, x1
    6a0c:	39400280 	ldrb	w0, [x20]
    6a10:	7103fc1f 	cmp	w0, #0xff
    6a14:	54000400 	b.eq	6a94 <fwp_owned_entry161+0x1b4>  // b.none
    6a18:	52800020 	mov	w0, #0x1                   	// #1
    6a1c:	39000280 	strb	w0, [x20]
    6a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a24:	aa1303e0 	mov	x0, x19
    6a28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a2c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6a30:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6a34:	d65f03c0 	ret
    6a38:	8b000021 	add	x1, x1, x0
    6a3c:	f9400433 	ldr	x19, [x1, #8]
    6a40:	b4000113 	cbz	x19, 6a60 <fwp_owned_entry161+0x180>
    6a44:	f9400820 	ldr	x0, [x1, #16]
    6a48:	cb130000 	sub	x0, x0, x19
    6a4c:	eb0002df 	cmp	x22, x0
    6a50:	54000088 	b.hi	6a60 <fwp_owned_entry161+0x180>  // b.pmore
    6a54:	8b160260 	add	x0, x19, x22
    6a58:	f9000420 	str	x0, [x1, #8]
    6a5c:	17ffffb9 	b	6940 <fwp_owned_entry161+0x60>
    6a60:	52800001 	mov	w1, #0x0                   	// #0
    6a64:	d2800300 	mov	x0, #0x18                  	// #24
    6a68:	97fff922 	bl	4ef0 <fwp_heap_alloc>
    6a6c:	aa0003f3 	mov	x19, x0
    6a70:	17ffffca 	b	6998 <fwp_owned_entry161+0xb8>
    6a74:	72003c3f 	tst	w1, #0xffff
    6a78:	54fffca0 	b.eq	6a0c <fwp_owned_entry161+0x12c>  // b.none
    6a7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a80:	aa1303e0 	mov	x0, x19
    6a84:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a88:	a94363f7 	ldp	x23, x24, [sp, #48]
    6a8c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6a90:	d65f03c0 	ret
    6a94:	aa1403e0 	mov	x0, x20
    6a98:	97fff5be 	bl	4190 <fwp_rc_forget_slot.part.0>
    6a9c:	17ffffdf 	b	6a18 <fwp_owned_entry161+0x138>
    6aa0:	97ffeff8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6aa4:	97fff163 	bl	3030 <fwp_heap_oom>
    6aa8:	d503201f 	nop
    6aac:	d503201f 	nop

0000000000006ab0 <e161>:
    6ab0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6ab4:	910003fd 	mov	x29, sp
    6ab8:	a90363f7 	stp	x23, x24, [sp, #48]
    6abc:	a9406002 	ldp	x2, x24, [x0]
    6ac0:	a90153f3 	stp	x19, x20, [sp, #16]
    6ac4:	f9400801 	ldr	x1, [x0, #16]
    6ac8:	a9025bf5 	stp	x21, x22, [sp, #32]
    6acc:	ab010055 	adds	x21, x2, x1
    6ad0:	54000d86 	b.vs	6c80 <e161+0x1d0>
    6ad4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6ad8:	91174281 	add	x1, x20, #0x5d0
    6adc:	b953a420 	ldr	w0, [x1, #5028]
    6ae0:	34000ac0 	cbz	w0, 6c38 <e161+0x188>
    6ae4:	397e8820 	ldrb	w0, [x1, #4002]
    6ae8:	910f0002 	add	x2, x0, #0x3c0
    6aec:	8b000400 	add	x0, x0, x0, lsl #1
    6af0:	d37df000 	lsl	x0, x0, #3
    6af4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6af8:	2a1703f6 	mov	w22, w23
    6afc:	f8606833 	ldr	x19, [x1, x0]
    6b00:	b4000893 	cbz	x19, 6c10 <e161+0x160>
    6b04:	f9400262 	ldr	x2, [x19]
    6b08:	aa2203e2 	mvn	x2, x2
    6b0c:	f8206822 	str	x2, [x1, x0]
    6b10:	f10062df 	cmp	x22, #0x18
    6b14:	540000e9 	b.ls	6b30 <e161+0x80>  // b.plast
    6b18:	d10066c2 	sub	x2, x22, #0x19
    6b1c:	91006260 	add	x0, x19, #0x18
    6b20:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6b24:	52800001 	mov	w1, #0x0                   	// #0
    6b28:	91002042 	add	x2, x2, #0x8
    6b2c:	97ffef49 	bl	2850 <memset@plt>
    6b30:	91174281 	add	x1, x20, #0x5d0
    6b34:	f94a1020 	ldr	x0, [x1, #5152]
    6b38:	ab160000 	adds	x0, x0, x22
    6b3c:	54000a42 	b.cs	6c84 <e161+0x1d4>  // b.hs, b.nlast
    6b40:	f94a1422 	ldr	x2, [x1, #5160]
    6b44:	f90a1020 	str	x0, [x1, #5152]
    6b48:	eb02001f 	cmp	x0, x2
    6b4c:	54000049 	b.ls	6b54 <e161+0xa4>  // b.plast
    6b50:	f90a1420 	str	x0, [x1, #5160]
    6b54:	91174280 	add	x0, x20, #0x5d0
    6b58:	1e6302e1 	ucvtf	d1, w23
    6b5c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6b60:	1e612800 	fadd	d0, d0, d1
    6b64:	fd0a1c00 	str	d0, [x0, #5176]
    6b68:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    6b6c:	91174294 	add	x20, x20, #0x5d0
    6b70:	a900d678 	stp	x24, x21, [x19, #8]
    6b74:	fd478800 	ldr	d0, [x0, #3856]
    6b78:	fd000260 	str	d0, [x19]
    6b7c:	f949da81 	ldr	x1, [x20, #5040]
    6b80:	f949ee80 	ldr	x0, [x20, #5080]
    6b84:	cb010261 	sub	x1, x19, x1
    6b88:	eb00403f 	cmp	x1, x0, lsl #16
    6b8c:	54000322 	b.cs	6bf0 <e161+0x140>  // b.hs, b.nlast
    6b90:	d350fc20 	lsr	x0, x1, #16
    6b94:	f949fe83 	ldr	x3, [x20, #5112]
    6b98:	8b000800 	add	x0, x0, x0, lsl #2
    6b9c:	d37df002 	lsl	x2, x0, #3
    6ba0:	8b020060 	add	x0, x3, x2
    6ba4:	f9401014 	ldr	x20, [x0, #32]
    6ba8:	b4000254 	cbz	x20, 6bf0 <e161+0x140>
    6bac:	38626862 	ldrb	w2, [x3, x2]
    6bb0:	7100085f 	cmp	w2, #0x2
    6bb4:	540004c0 	b.eq	6c4c <e161+0x19c>  // b.none
    6bb8:	7100045f 	cmp	w2, #0x1
    6bbc:	540001a1 	b.ne	6bf0 <e161+0x140>  // b.any
    6bc0:	29430002 	ldp	w2, w0, [x0, #24]
    6bc4:	92403c21 	and	x1, x1, #0xffff
    6bc8:	9b027c21 	mul	x1, x1, x2
    6bcc:	d360fc21 	lsr	x1, x1, #32
    6bd0:	eb00003f 	cmp	x1, x0
    6bd4:	540000e2 	b.cs	6bf0 <e161+0x140>  // b.hs, b.nlast
    6bd8:	8b010294 	add	x20, x20, x1
    6bdc:	39400280 	ldrb	w0, [x20]
    6be0:	7103fc1f 	cmp	w0, #0xff
    6be4:	54000480 	b.eq	6c74 <e161+0x1c4>  // b.none
    6be8:	52800020 	mov	w0, #0x1                   	// #1
    6bec:	39000280 	strb	w0, [x20]
    6bf0:	aa1303e0 	mov	x0, x19
    6bf4:	97fffbc7 	bl	5b10 <fwp_rc_share>
    6bf8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6bfc:	aa1303e0 	mov	x0, x19
    6c00:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c04:	a94363f7 	ldp	x23, x24, [sp, #48]
    6c08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6c0c:	d65f03c0 	ret
    6c10:	8b000021 	add	x1, x1, x0
    6c14:	f9400433 	ldr	x19, [x1, #8]
    6c18:	b4000113 	cbz	x19, 6c38 <e161+0x188>
    6c1c:	f9400820 	ldr	x0, [x1, #16]
    6c20:	cb130000 	sub	x0, x0, x19
    6c24:	eb0002df 	cmp	x22, x0
    6c28:	54000088 	b.hi	6c38 <e161+0x188>  // b.pmore
    6c2c:	8b160260 	add	x0, x19, x22
    6c30:	f9000420 	str	x0, [x1, #8]
    6c34:	17ffffb7 	b	6b10 <e161+0x60>
    6c38:	52800001 	mov	w1, #0x0                   	// #0
    6c3c:	d2800300 	mov	x0, #0x18                  	// #24
    6c40:	97fff8ac 	bl	4ef0 <fwp_heap_alloc>
    6c44:	aa0003f3 	mov	x19, x0
    6c48:	17ffffc8 	b	6b68 <e161+0xb8>
    6c4c:	72003c3f 	tst	w1, #0xffff
    6c50:	54fffc60 	b.eq	6bdc <e161+0x12c>  // b.none
    6c54:	aa1303e0 	mov	x0, x19
    6c58:	97fffbae 	bl	5b10 <fwp_rc_share>
    6c5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6c60:	aa1303e0 	mov	x0, x19
    6c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c68:	a94363f7 	ldp	x23, x24, [sp, #48]
    6c6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6c70:	d65f03c0 	ret
    6c74:	aa1403e0 	mov	x0, x20
    6c78:	97fff546 	bl	4190 <fwp_rc_forget_slot.part.0>
    6c7c:	17ffffdb 	b	6be8 <e161+0x138>
    6c80:	97ffef80 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6c84:	97fff0eb 	bl	3030 <fwp_heap_oom>
    6c88:	d503201f 	nop
    6c8c:	d503201f 	nop

0000000000006c90 <fwp_drop4>:
    6c90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6c94:	910003fd 	mov	x29, sp
    6c98:	a90153f3 	stp	x19, x20, [sp, #16]
    6c9c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6ca0:	f90013f5 	str	x21, [sp, #32]
    6ca4:	91174275 	add	x21, x19, #0x5d0
    6ca8:	f949daa1 	ldr	x1, [x21, #5040]
    6cac:	f949eea2 	ldr	x2, [x21, #5080]
    6cb0:	cb010001 	sub	x1, x0, x1
    6cb4:	eb02403f 	cmp	x1, x2, lsl #16
    6cb8:	54000382 	b.cs	6d28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6cbc:	d350fc22 	lsr	x2, x1, #16
    6cc0:	f949fea3 	ldr	x3, [x21, #5112]
    6cc4:	8b020842 	add	x2, x2, x2, lsl #2
    6cc8:	d37df042 	lsl	x2, x2, #3
    6ccc:	8b020064 	add	x4, x3, x2
    6cd0:	f9401094 	ldr	x20, [x4, #32]
    6cd4:	b40002b4 	cbz	x20, 6d28 <fwp_drop4+0x98>
    6cd8:	38626862 	ldrb	w2, [x3, x2]
    6cdc:	7100085f 	cmp	w2, #0x2
    6ce0:	540007a0 	b.eq	6dd4 <fwp_drop4+0x144>  // b.none
    6ce4:	7100045f 	cmp	w2, #0x1
    6ce8:	54000201 	b.ne	6d28 <fwp_drop4+0x98>  // b.any
    6cec:	29430885 	ldp	w5, w2, [x4, #24]
    6cf0:	92403c21 	and	x1, x1, #0xffff
    6cf4:	9b057c21 	mul	x1, x1, x5
    6cf8:	d360fc21 	lsr	x1, x1, #32
    6cfc:	eb02003f 	cmp	x1, x2
    6d00:	54000142 	b.cs	6d28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d04:	8b010294 	add	x20, x20, x1
    6d08:	39400281 	ldrb	w1, [x20]
    6d0c:	340000e1 	cbz	w1, 6d28 <fwp_drop4+0x98>
    6d10:	7100043f 	cmp	w1, #0x1
    6d14:	54000120 	b.eq	6d38 <fwp_drop4+0xa8>  // b.none
    6d18:	7103fc3f 	cmp	w1, #0xff
    6d1c:	540007c0 	b.eq	6e14 <fwp_drop4+0x184>  // b.none
    6d20:	51000421 	sub	w1, w1, #0x1
    6d24:	39000281 	strb	w1, [x20]
    6d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d2c:	f94013f5 	ldr	x21, [sp, #32]
    6d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d34:	d65f03c0 	ret
    6d38:	f9400001 	ldr	x1, [x0]
    6d3c:	b7f80581 	tbnz	x1, #63, 6dec <fwp_drop4+0x15c>
    6d40:	91174273 	add	x19, x19, #0x5d0
    6d44:	f949da61 	ldr	x1, [x19, #5040]
    6d48:	f949ee62 	ldr	x2, [x19, #5080]
    6d4c:	cb010001 	sub	x1, x0, x1
    6d50:	eb02403f 	cmp	x1, x2, lsl #16
    6d54:	54fffea2 	b.cs	6d28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d58:	d350fc22 	lsr	x2, x1, #16
    6d5c:	8b020842 	add	x2, x2, x2, lsl #2
    6d60:	d37df042 	lsl	x2, x2, #3
    6d64:	8b020065 	add	x5, x3, x2
    6d68:	f94010a4 	ldr	x4, [x5, #32]
    6d6c:	b4fffde4 	cbz	x4, 6d28 <fwp_drop4+0x98>
    6d70:	38626862 	ldrb	w2, [x3, x2]
    6d74:	7100085f 	cmp	w2, #0x2
    6d78:	54000220 	b.eq	6dbc <fwp_drop4+0x12c>  // b.none
    6d7c:	7100045f 	cmp	w2, #0x1
    6d80:	54fffd41 	b.ne	6d28 <fwp_drop4+0x98>  // b.any
    6d84:	294308a3 	ldp	w3, w2, [x5, #24]
    6d88:	92403c21 	and	x1, x1, #0xffff
    6d8c:	9b037c21 	mul	x1, x1, x3
    6d90:	d360fc21 	lsr	x1, x1, #32
    6d94:	eb02003f 	cmp	x1, x2
    6d98:	54fffc82 	b.cs	6d28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d9c:	8b010084 	add	x4, x4, x1
    6da0:	39400081 	ldrb	w1, [x4]
    6da4:	7100043f 	cmp	w1, #0x1
    6da8:	54fffc01 	b.ne	6d28 <fwp_drop4+0x98>  // b.any
    6dac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6db0:	f94013f5 	ldr	x21, [sp, #32]
    6db4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6db8:	17fff592 	b	4400 <fwp_mem_free>
    6dbc:	72003c3f 	tst	w1, #0xffff
    6dc0:	54ffff00 	b.eq	6da0 <fwp_drop4+0x110>  // b.none
    6dc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6dc8:	f94013f5 	ldr	x21, [sp, #32]
    6dcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6dd0:	d65f03c0 	ret
    6dd4:	72003c3f 	tst	w1, #0xffff
    6dd8:	54fff980 	b.eq	6d08 <fwp_drop4+0x78>  // b.none
    6ddc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6de0:	f94013f5 	ldr	x21, [sp, #32]
    6de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6de8:	d65f03c0 	ret
    6dec:	f9400414 	ldr	x20, [x0, #8]
    6df0:	97fffb6c 	bl	5ba0 <fwp_rc_free_arr>
    6df4:	91174260 	add	x0, x19, #0x5d0
    6df8:	f949d801 	ldr	x1, [x0, #5040]
    6dfc:	f949ec00 	ldr	x0, [x0, #5080]
    6e00:	cb010281 	sub	x1, x20, x1
    6e04:	eb00403f 	cmp	x1, x0, lsl #16
    6e08:	54fff902 	b.cs	6d28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e0c:	aa1403e0 	mov	x0, x20
    6e10:	17ffffab 	b	6cbc <fwp_drop4+0x2c>
    6e14:	ca544680 	eor	x0, x20, x20, lsr #17
    6e18:	91174273 	add	x19, x19, #0x5d0
    6e1c:	ca402400 	eor	x0, x0, x0, lsr #9
    6e20:	92401c00 	and	x0, x0, #0xff
    6e24:	910a2402 	add	x2, x0, #0x289
    6e28:	8b000e60 	add	x0, x19, x0, lsl #3
    6e2c:	8b020e62 	add	x2, x19, x2, lsl #3
    6e30:	f94a2400 	ldr	x0, [x0, #5192]
    6e34:	b50000a0 	cbnz	x0, 6e48 <fwp_drop4+0x1b8>
    6e38:	14000013 	b	6e84 <fwp_drop4+0x1f4>
    6e3c:	91004002 	add	x2, x0, #0x10
    6e40:	f9400800 	ldr	x0, [x0, #16]
    6e44:	b4000200 	cbz	x0, 6e84 <fwp_drop4+0x1f4>
    6e48:	f9400001 	ldr	x1, [x0]
    6e4c:	eb14003f 	cmp	x1, x20
    6e50:	54ffff61 	b.ne	6e3c <fwp_drop4+0x1ac>  // b.any
    6e54:	f9400041 	ldr	x1, [x2]
    6e58:	f9400420 	ldr	x0, [x1, #8]
    6e5c:	d1000400 	sub	x0, x0, #0x1
    6e60:	f9000420 	str	x0, [x1, #8]
    6e64:	f103f81f 	cmp	x0, #0xfe
    6e68:	54fff601 	b.ne	6d28 <fwp_drop4+0x98>  // b.any
    6e6c:	39400280 	ldrb	w0, [x20]
    6e70:	7103fc1f 	cmp	w0, #0xff
    6e74:	540000e0 	b.eq	6e90 <fwp_drop4+0x200>  // b.none
    6e78:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e7c:	39000280 	strb	w0, [x20]
    6e80:	17ffffaa 	b	6d28 <fwp_drop4+0x98>
    6e84:	b0000020 	adrp	x0, b000 <__modti3+0x280>
    6e88:	910c6000 	add	x0, x0, #0x318
    6e8c:	97fff4a1 	bl	4110 <fwp_trap>
    6e90:	aa1403e0 	mov	x0, x20
    6e94:	97fff4bf 	bl	4190 <fwp_rc_forget_slot.part.0>
    6e98:	17fffff8 	b	6e78 <fwp_drop4+0x1e8>
    6e9c:	d503201f 	nop

0000000000006ea0 <fwp_caps161>:
    6ea0:	34000041 	cbz	w1, 6ea8 <fwp_caps161+0x8>
    6ea4:	d65f03c0 	ret
    6ea8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6eac:	91174063 	add	x3, x3, #0x5d0
    6eb0:	f949d861 	ldr	x1, [x3, #5040]
    6eb4:	f949ec62 	ldr	x2, [x3, #5080]
    6eb8:	cb010001 	sub	x1, x0, x1
    6ebc:	eb02403f 	cmp	x1, x2, lsl #16
    6ec0:	54ffff22 	b.cs	6ea4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ec4:	d350fc22 	lsr	x2, x1, #16
    6ec8:	f949fc65 	ldr	x5, [x3, #5112]
    6ecc:	8b020842 	add	x2, x2, x2, lsl #2
    6ed0:	d37df042 	lsl	x2, x2, #3
    6ed4:	8b0200a4 	add	x4, x5, x2
    6ed8:	f9401083 	ldr	x3, [x4, #32]
    6edc:	b4fffe43 	cbz	x3, 6ea4 <fwp_caps161+0x4>
    6ee0:	386268a2 	ldrb	w2, [x5, x2]
    6ee4:	7100085f 	cmp	w2, #0x2
    6ee8:	540001c0 	b.eq	6f20 <fwp_caps161+0x80>  // b.none
    6eec:	7100045f 	cmp	w2, #0x1
    6ef0:	54fffda1 	b.ne	6ea4 <fwp_caps161+0x4>  // b.any
    6ef4:	29430885 	ldp	w5, w2, [x4, #24]
    6ef8:	92403c21 	and	x1, x1, #0xffff
    6efc:	9b057c21 	mul	x1, x1, x5
    6f00:	d360fc21 	lsr	x1, x1, #32
    6f04:	eb02003f 	cmp	x1, x2
    6f08:	54fffce2 	b.cs	6ea4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6f0c:	8b010063 	add	x3, x3, x1
    6f10:	39400061 	ldrb	w1, [x3]
    6f14:	7100043f 	cmp	w1, #0x1
    6f18:	54fffc61 	b.ne	6ea4 <fwp_caps161+0x4>  // b.any
    6f1c:	17fff539 	b	4400 <fwp_mem_free>
    6f20:	72003c3f 	tst	w1, #0xffff
    6f24:	54ffff60 	b.eq	6f10 <fwp_caps161+0x70>  // b.none
    6f28:	d65f03c0 	ret
    6f2c:	d503201f 	nop

0000000000006f30 <f12>:
    6f30:	d10483ff 	sub	sp, sp, #0x120
    6f34:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6f38:	f947f442 	ldr	x2, [x2, #4072]
    6f3c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6f40:	9102c3fd 	add	x29, sp, #0xb0
    6f44:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6f48:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    6f4c:	911742a3 	add	x3, x21, #0x5d0
    6f50:	a90c53f3 	stp	x19, x20, [sp, #192]
    6f54:	d00000d4 	adrp	x20, 20000 <__data_start>
    6f58:	9101c284 	add	x4, x20, #0x70
    6f5c:	f949d861 	ldr	x1, [x3, #5040]
    6f60:	a90e63f7 	stp	x23, x24, [sp, #224]
    6f64:	d00000d8 	adrp	x24, 20000 <__data_start>
    6f68:	f949ec65 	ldr	x5, [x3, #5080]
    6f6c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6f70:	91004318 	add	x24, x24, #0x10
    6f74:	a91073fb 	stp	x27, x28, [sp, #256]
    6f78:	9100e318 	add	x24, x24, #0x38
    6f7c:	910103f7 	add	x23, sp, #0x40
    6f80:	f9418886 	ldr	x6, [x4, #784]
    6f84:	fd008be8 	str	d8, [sp, #272]
    6f88:	f9400047 	ldr	x7, [x2]
    6f8c:	f90057e7 	str	x7, [sp, #168]
    6f90:	d2800007 	mov	x7, #0x0                   	// #0
    6f94:	9100e3f6 	add	x22, sp, #0x38
    6f98:	90000019 	adrp	x25, 6000 <fwp_closure_drop+0x40>
    6f9c:	12800007 	mov	w7, #0xffffffff            	// #-1
    6fa0:	910d8322 	add	x2, x25, #0x360
    6fa4:	cb010301 	sub	x1, x24, x1
    6fa8:	b9003be7 	str	w7, [sp, #56]
    6fac:	aa0003f3 	mov	x19, x0
    6fb0:	a9040be6 	stp	x6, x2, [sp, #64]
    6fb4:	f9002bf6 	str	x22, [sp, #80]
    6fb8:	f9018897 	str	x23, [x4, #784]
    6fbc:	eb05403f 	cmp	x1, x5, lsl #16
    6fc0:	54000342 	b.cs	7028 <f12+0xf8>  // b.hs, b.nlast
    6fc4:	d350fc20 	lsr	x0, x1, #16
    6fc8:	f949fc64 	ldr	x4, [x3, #5112]
    6fcc:	8b000800 	add	x0, x0, x0, lsl #2
    6fd0:	d37df002 	lsl	x2, x0, #3
    6fd4:	8b020083 	add	x3, x4, x2
    6fd8:	f9401060 	ldr	x0, [x3, #32]
    6fdc:	b4000260 	cbz	x0, 7028 <f12+0xf8>
    6fe0:	38626882 	ldrb	w2, [x4, x2]
    6fe4:	7100085f 	cmp	w2, #0x2
    6fe8:	54000b20 	b.eq	714c <f12+0x21c>  // b.none
    6fec:	7100045f 	cmp	w2, #0x1
    6ff0:	540001c1 	b.ne	7028 <f12+0xf8>  // b.any
    6ff4:	29430864 	ldp	w4, w2, [x3, #24]
    6ff8:	92403c21 	and	x1, x1, #0xffff
    6ffc:	9b047c21 	mul	x1, x1, x4
    7000:	d360fc21 	lsr	x1, x1, #32
    7004:	eb02003f 	cmp	x1, x2
    7008:	54000102 	b.cs	7028 <f12+0xf8>  // b.hs, b.nlast
    700c:	8b010000 	add	x0, x0, x1
    7010:	39400001 	ldrb	w1, [x0]
    7014:	340000a1 	cbz	w1, 7028 <f12+0xf8>
    7018:	7103f43f 	cmp	w1, #0xfd
    701c:	54002848 	b.hi	7524 <f12+0x5f4>  // b.pmore
    7020:	11000421 	add	w1, w1, #0x1
    7024:	39000001 	strb	w1, [x0]
    7028:	aa1803e0 	mov	x0, x24
    702c:	97fffbe5 	bl	5fc0 <fwp_closure_drop>
    7030:	b40001f3 	cbz	x19, 706c <f12+0x13c>
    7034:	aa1303e0 	mov	x0, x19
    7038:	d2800018 	mov	x24, #0x0                   	// #0
    703c:	d503201f 	nop
    7040:	f9400800 	ldr	x0, [x0, #16]
    7044:	91000718 	add	x24, x24, #0x1
    7048:	b5ffffc0 	cbnz	x0, 7040 <f12+0x110>
    704c:	52800000 	mov	w0, #0x0                   	// #0
    7050:	97fff168 	bl	35f0 <descent_phase_step>
    7054:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7058:	eb00031f 	cmp	x24, x0
    705c:	540000e9 	b.ls	7078 <f12+0x148>  // b.plast
    7060:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7064:	91170000 	add	x0, x0, #0x5c0
    7068:	97fff42a 	bl	4110 <fwp_trap>
    706c:	d2800018 	mov	x24, #0x0                   	// #0
    7070:	52800000 	mov	w0, #0x0                   	// #0
    7074:	97fff15f 	bl	35f0 <descent_phase_step>
    7078:	9101c29a 	add	x26, x20, #0x70
    707c:	b9434740 	ldr	w0, [x26, #836]
    7080:	34001280 	cbz	w0, 72d0 <f12+0x3a0>
    7084:	9101c280 	add	x0, x20, #0x70
    7088:	f940681b 	ldr	x27, [x0, #208]
    708c:	f940741a 	ldr	x26, [x0, #232]
    7090:	eb1b035f 	cmp	x26, x27
    7094:	5400062a 	b.ge	7158 <f12+0x228>  // b.tcont
    7098:	f9403a81 	ldr	x1, [x20, #112]
    709c:	8b1a0740 	add	x0, x26, x26, lsl #1
    70a0:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    70a4:	8b000b40 	add	x0, x26, x0, lsl #2
    70a8:	8b000c20 	add	x0, x1, x0, lsl #3
    70ac:	d503201f 	nop
    70b0:	b9400401 	ldr	w1, [x0, #4]
    70b4:	35000081 	cbnz	w1, 70c4 <f12+0x194>
    70b8:	b9400001 	ldr	w1, [x0]
    70bc:	6b02003f 	cmp	w1, w2
    70c0:	540004c9 	b.ls	7158 <f12+0x228>  // b.plast
    70c4:	9100075a 	add	x26, x26, #0x1
    70c8:	9101a000 	add	x0, x0, #0x68
    70cc:	eb1b035f 	cmp	x26, x27
    70d0:	54ffff01 	b.ne	70b0 <f12+0x180>  // b.any
    70d4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    70d8:	eb00037f 	cmp	x27, x0
    70dc:	54001dac 	b.gt	7490 <f12+0x560>
    70e0:	9101c280 	add	x0, x20, #0x70
    70e4:	f9403a83 	ldr	x3, [x20, #112]
    70e8:	f9407000 	ldr	x0, [x0, #224]
    70ec:	eb1b001f 	cmp	x0, x27
    70f0:	54000161 	b.ne	711c <f12+0x1ec>  // b.any
    70f4:	b5001dbb 	cbnz	x27, 74a8 <f12+0x578>
    70f8:	d2800d01 	mov	x1, #0x68                  	// #104
    70fc:	d280003c 	mov	x28, #0x1                   	// #1
    7100:	aa0303e0 	mov	x0, x3
    7104:	97ffeddb 	bl	2870 <realloc@plt>
    7108:	aa0003e3 	mov	x3, x0
    710c:	b4004a00 	cbz	x0, 7a4c <f12+0xb1c>
    7110:	9101c280 	add	x0, x20, #0x70
    7114:	f9003a83 	str	x3, [x20, #112]
    7118:	f900701c 	str	x28, [x0, #224]
    711c:	8b1b0761 	add	x1, x27, x27, lsl #1
    7120:	9101c280 	add	x0, x20, #0x70
    7124:	4f000400 	movi	v0.4s, #0x0
    7128:	91000762 	add	x2, x27, #0x1
    712c:	8b010b61 	add	x1, x27, x1, lsl #2
    7130:	f9006802 	str	x2, [x0, #208]
    7134:	8b010c61 	add	x1, x3, x1, lsl #3
    7138:	ad000020 	stp	q0, q0, [x1]
    713c:	ad010020 	stp	q0, q0, [x1, #32]
    7140:	ad020020 	stp	q0, q0, [x1, #64]
    7144:	f900303f 	str	xzr, [x1, #96]
    7148:	14000007 	b	7164 <f12+0x234>
    714c:	72003c3f 	tst	w1, #0xffff
    7150:	54fff6c1 	b.ne	7028 <f12+0xf8>  // b.any
    7154:	17ffffaf 	b	7010 <f12+0xe0>
    7158:	eb1b035f 	cmp	x26, x27
    715c:	54fffbc0 	b.eq	70d4 <f12+0x1a4>  // b.none
    7160:	f9403a83 	ldr	x3, [x20, #112]
    7164:	8b1a075b 	add	x27, x26, x26, lsl #1
    7168:	90000020 	adrp	x0, b000 <__modti3+0x280>
    716c:	910bc000 	add	x0, x0, #0x2f0
    7170:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7174:	f90003e3 	str	x3, [sp]
    7178:	8b1b0c7b 	add	x27, x3, x27, lsl #3
    717c:	f900337f 	str	xzr, [x27, #96]
    7180:	97ffee24 	bl	2a10 <getenv@plt>
    7184:	f94003e3 	ldr	x3, [sp]
    7188:	b4000800 	cbz	x0, 7288 <f12+0x358>
    718c:	39400001 	ldrb	w1, [x0]
    7190:	7100c03f 	cmp	w1, #0x30
    7194:	540007a1 	b.ne	7288 <f12+0x358>  // b.any
    7198:	39400400 	ldrb	w0, [x0, #1]
    719c:	35000760 	cbnz	w0, 7288 <f12+0x358>
    71a0:	9101c282 	add	x2, x20, #0x70
    71a4:	2f000400 	mvni	v0.2s, #0x0
    71a8:	b9400360 	ldr	w0, [x27]
    71ac:	52800025 	mov	w5, #0x1                   	// #1
    71b0:	91000744 	add	x4, x26, #0x1
    71b4:	a900e378 	stp	x24, x24, [x27, #8]
    71b8:	0b05001c 	add	w28, w0, w5
    71bc:	f9418841 	ldr	x1, [x2, #784]
    71c0:	2900177c 	stp	w28, w5, [x27]
    71c4:	f9002b7f 	str	xzr, [x27, #80]
    71c8:	f9007444 	str	x4, [x2, #232]
    71cc:	fd002f60 	str	d0, [x27, #88]
    71d0:	b4001661 	cbz	x1, 749c <f12+0x56c>
    71d4:	910d8339 	add	x25, x25, #0x360
    71d8:	14000003 	b	71e4 <f12+0x2b4>
    71dc:	f9400021 	ldr	x1, [x1]
    71e0:	b40015e1 	cbz	x1, 749c <f12+0x56c>
    71e4:	f9400422 	ldr	x2, [x1, #8]
    71e8:	eb19005f 	cmp	x2, x25
    71ec:	54ffff81 	b.ne	71dc <f12+0x2ac>  // b.any
    71f0:	f9400820 	ldr	x0, [x1, #16]
    71f4:	2a1a03e2 	mov	w2, w26
    71f8:	b9400001 	ldr	w1, [x0]
    71fc:	f9002b60 	str	x0, [x27, #80]
    7200:	b9005f61 	str	w1, [x27, #92]
    7204:	37f80081 	tbnz	w1, #31, 7214 <f12+0x2e4>
    7208:	52800d05 	mov	w5, #0x68                  	// #104
    720c:	9b250c21 	smaddl	x1, w1, w5, x3
    7210:	b900583a 	str	w26, [x1, #88]
    7214:	b9000002 	str	w2, [x0]
    7218:	52800020 	mov	w0, #0x1                   	// #1
    721c:	f90003e4 	str	x4, [sp]
    7220:	97fff0f4 	bl	35f0 <descent_phase_step>
    7224:	f94003e4 	ldr	x4, [sp]
    7228:	aa1303e0 	mov	x0, x19
    722c:	d2800002 	mov	x2, #0x0                   	// #0
    7230:	b40005f3 	cbz	x19, 72ec <f12+0x3bc>
    7234:	d503201f 	nop
    7238:	f9400800 	ldr	x0, [x0, #16]
    723c:	91000442 	add	x2, x2, #0x1
    7240:	b5ffffc0 	cbnz	x0, 7238 <f12+0x308>
    7244:	aa1303e1 	mov	x1, x19
    7248:	f9400821 	ldr	x1, [x1, #16]
    724c:	91000400 	add	x0, x0, #0x1
    7250:	b5ffffc1 	cbnz	x1, 7248 <f12+0x318>
    7254:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7258:	eb01001f 	cmp	x0, x1
    725c:	54000108 	b.hi	727c <f12+0x34c>  // b.pmore
    7260:	f100005f 	cmp	x2, #0x0
    7264:	5400044d 	b.le	72ec <f12+0x3bc>
    7268:	eb00005f 	cmp	x2, x0
    726c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7270:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7274:	eb01033f 	cmp	x25, x1
    7278:	54001289 	b.ls	74c8 <f12+0x598>  // b.plast
    727c:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7280:	91190000 	add	x0, x0, #0x640
    7284:	97fff3a3 	bl	4110 <fwp_trap>
    7288:	9101c280 	add	x0, x20, #0x70
    728c:	f9406001 	ldr	x1, [x0, #192]
    7290:	b4fff881 	cbz	x1, 71a0 <f12+0x270>
    7294:	3cc88002 	ldur	q2, [x0, #136]
    7298:	91022001 	add	x1, x0, #0x88
    729c:	3cc98001 	ldur	q1, [x0, #152]
    72a0:	f900601f 	str	xzr, [x0, #192]
    72a4:	4f000400 	movi	v0.4s, #0x0
    72a8:	ad010762 	stp	q2, q1, [x27, #32]
    72ac:	a94a8002 	ldp	x2, x0, [x0, #168]
    72b0:	f9000f60 	str	x0, [x27, #24]
    72b4:	f9401820 	ldr	x0, [x1, #48]
    72b8:	f9002362 	str	x2, [x27, #64]
    72bc:	f9002760 	str	x0, [x27, #72]
    72c0:	ad000020 	stp	q0, q0, [x1]
    72c4:	3d800820 	str	q0, [x1, #32]
    72c8:	f900183f 	str	xzr, [x1, #48]
    72cc:	17ffffb5 	b	71a0 <f12+0x270>
    72d0:	f0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x40>
    72d4:	91098000 	add	x0, x0, #0x260
    72d8:	94000f86 	bl	b0f0 <atexit>
    72dc:	35003b80 	cbnz	w0, 7a4c <f12+0xb1c>
    72e0:	52800020 	mov	w0, #0x1                   	// #1
    72e4:	b9034740 	str	w0, [x26, #836]
    72e8:	17ffff67 	b	7084 <f12+0x154>
    72ec:	d3707f80 	ubfiz	x0, x28, #16, #32
    72f0:	52800041 	mov	w1, #0x2                   	// #2
    72f4:	aa040018 	orr	x24, x0, x4
    72f8:	d2800100 	mov	x0, #0x8                   	// #8
    72fc:	97fff6fd 	bl	4ef0 <fwp_heap_alloc>
    7300:	aa0003fa 	mov	x26, x0
    7304:	911742a0 	add	x0, x21, #0x5d0
    7308:	f900035f 	str	xzr, [x26]
    730c:	f949d801 	ldr	x1, [x0, #5040]
    7310:	f949ec00 	ldr	x0, [x0, #5080]
    7314:	cb010341 	sub	x1, x26, x1
    7318:	eb00403f 	cmp	x1, x0, lsl #16
    731c:	54000f82 	b.cs	750c <f12+0x5dc>  // b.hs, b.nlast
    7320:	d2800019 	mov	x25, #0x0                   	// #0
    7324:	911742a2 	add	x2, x21, #0x5d0
    7328:	d350fc20 	lsr	x0, x1, #16
    732c:	8b000800 	add	x0, x0, x0, lsl #2
    7330:	f949fc43 	ldr	x3, [x2, #5112]
    7334:	d37df002 	lsl	x2, x0, #3
    7338:	8b020060 	add	x0, x3, x2
    733c:	f940101b 	ldr	x27, [x0, #32]
    7340:	b400025b 	cbz	x27, 7388 <f12+0x458>
    7344:	38626862 	ldrb	w2, [x3, x2]
    7348:	7100085f 	cmp	w2, #0x2
    734c:	54000e60 	b.eq	7518 <f12+0x5e8>  // b.none
    7350:	7100045f 	cmp	w2, #0x1
    7354:	540001a1 	b.ne	7388 <f12+0x458>  // b.any
    7358:	29430002 	ldp	w2, w0, [x0, #24]
    735c:	92403c21 	and	x1, x1, #0xffff
    7360:	9b027c21 	mul	x1, x1, x2
    7364:	d360fc21 	lsr	x1, x1, #32
    7368:	eb00003f 	cmp	x1, x0
    736c:	540000e2 	b.cs	7388 <f12+0x458>  // b.hs, b.nlast
    7370:	8b01037b 	add	x27, x27, x1
    7374:	39400360 	ldrb	w0, [x27]
    7378:	7103fc1f 	cmp	w0, #0xff
    737c:	540034c0 	b.eq	7a14 <f12+0xae4>  // b.none
    7380:	52800020 	mov	w0, #0x1                   	// #1
    7384:	39000360 	strb	w0, [x27]
    7388:	b4000239 	cbz	x25, 73cc <f12+0x49c>
    738c:	d3607f04 	lsl	x4, x24, #32
    7390:	aa1303e0 	mov	x0, x19
    7394:	f9400665 	ldr	x5, [x19, #8]
    7398:	aa0403e3 	mov	x3, x4
    739c:	91002342 	add	x2, x26, #0x8
    73a0:	d2800001 	mov	x1, #0x0                   	// #0
    73a4:	14000005 	b	73b8 <f12+0x488>
    73a8:	f9400405 	ldr	x5, [x0, #8]
    73ac:	ab040023 	adds	x3, x1, x4
    73b0:	91004042 	add	x2, x2, #0x10
    73b4:	54006926 	b.vs	80d8 <f12+0x11a8>
    73b8:	a9000c45 	stp	x5, x3, [x2]
    73bc:	91000421 	add	x1, x1, #0x1
    73c0:	f9400800 	ldr	x0, [x0, #16]
    73c4:	eb01033f 	cmp	x25, x1
    73c8:	54ffff08 	b.hi	73a8 <f12+0x478>  // b.pmore
    73cc:	f9400340 	ldr	x0, [x26]
    73d0:	f100041f 	cmp	x0, #0x1
    73d4:	540009c9 	b.ls	750c <f12+0x5dc>  // b.plast
    73d8:	d341fc00 	lsr	x0, x0, #1
    73dc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    73e0:	d100041c 	sub	x28, x0, #0x1
    73e4:	eb01039f 	cmp	x28, x1
    73e8:	54fff4a8 	b.hi	727c <f12+0x34c>  // b.pmore
    73ec:	b400091c 	cbz	x28, 750c <f12+0x5dc>
    73f0:	d1002341 	sub	x1, x26, #0x8
    73f4:	91002359 	add	x25, x26, #0x8
    73f8:	8b00103b 	add	x27, x1, x0, lsl #4
    73fc:	d503201f 	nop
    7400:	f9400720 	ldr	x0, [x25, #8]
    7404:	f9400f21 	ldr	x1, [x25, #24]
    7408:	fd400320 	ldr	d0, [x25]
    740c:	fd400b21 	ldr	d1, [x25, #16]
    7410:	97fff865 	bl	55a4 <w107>
    7414:	a9000720 	stp	x0, x1, [x25]
    7418:	91004339 	add	x25, x25, #0x10
    741c:	eb1b033f 	cmp	x25, x27
    7420:	54ffff01 	b.ne	7400 <f12+0x4d0>  // b.any
    7424:	aa1a03fb 	mov	x27, x26
    7428:	d37ffb99 	lsl	x25, x28, #1
    742c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7430:	d280001c 	mov	x28, #0x0                   	// #0
    7434:	f8010779 	str	x25, [x27], #16
    7438:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    743c:	aa0303e0 	mov	x0, x3
    7440:	91000b9c 	add	x28, x28, #0x2
    7444:	97fff807 	bl	5460 <f128.constprop.0>
    7448:	aa0003e3 	mov	x3, x0
    744c:	eb19039f 	cmp	x28, x25
    7450:	54ffff43 	b.cc	7438 <f12+0x508>  // b.lo, b.ul, b.last
    7454:	aa1a03e0 	mov	x0, x26
    7458:	f90003e3 	str	x3, [sp]
    745c:	97fffe0d 	bl	6c90 <fwp_drop4>
    7460:	93407f18 	sxtw	x24, w24
    7464:	52800040 	mov	w0, #0x2                   	// #2
    7468:	97fff062 	bl	35f0 <descent_phase_step>
    746c:	aa1803e0 	mov	x0, x24
    7470:	97fff52c 	bl	4920 <fwp_tape_of>
    7474:	f940301b 	ldr	x27, [x0, #96]
    7478:	aa0003e5 	mov	x5, x0
    747c:	f94003e3 	ldr	x3, [sp]
    7480:	b400057b 	cbz	x27, 752c <f12+0x5fc>
    7484:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7488:	9114c000 	add	x0, x0, #0x530
    748c:	97fff321 	bl	4110 <fwp_trap>
    7490:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7494:	91178000 	add	x0, x0, #0x5e0
    7498:	97fff31e 	bl	4110 <fwp_trap>
    749c:	90000020 	adrp	x0, b000 <__modti3+0x280>
    74a0:	91184000 	add	x0, x0, #0x610
    74a4:	97fff31b 	bl	4110 <fwp_trap>
    74a8:	d37ffb7c 	lsl	x28, x27, #1
    74ac:	d29fffe0 	mov	x0, #0xffff                	// #65535
    74b0:	eb00039f 	cmp	x28, x0
    74b4:	9a80d39c 	csel	x28, x28, x0, le
    74b8:	8b1c0781 	add	x1, x28, x28, lsl #1
    74bc:	8b010b81 	add	x1, x28, x1, lsl #2
    74c0:	d37df021 	lsl	x1, x1, #3
    74c4:	17ffff0f 	b	7100 <f12+0x1d0>
    74c8:	d37ffb3b 	lsl	x27, x25, #1
    74cc:	d3707f9c 	ubfiz	x28, x28, #16, #32
    74d0:	91000760 	add	x0, x27, #0x1
    74d4:	52800041 	mov	w1, #0x2                   	// #2
    74d8:	aa040398 	orr	x24, x28, x4
    74dc:	d37df000 	lsl	x0, x0, #3
    74e0:	97fff684 	bl	4ef0 <fwp_heap_alloc>
    74e4:	aa0003fa 	mov	x26, x0
    74e8:	911742a1 	add	x1, x21, #0x5d0
    74ec:	aa0103e0 	mov	x0, x1
    74f0:	f900035b 	str	x27, [x26]
    74f4:	f949d821 	ldr	x1, [x1, #5040]
    74f8:	f949ec00 	ldr	x0, [x0, #5080]
    74fc:	cb010341 	sub	x1, x26, x1
    7500:	eb00403f 	cmp	x1, x0, lsl #16
    7504:	54fff103 	b.cc	7324 <f12+0x3f4>  // b.lo, b.ul, b.last
    7508:	b5fff439 	cbnz	x25, 738c <f12+0x45c>
    750c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7510:	f900035f 	str	xzr, [x26]
    7514:	17ffffd0 	b	7454 <f12+0x524>
    7518:	72003c3f 	tst	w1, #0xffff
    751c:	54fff361 	b.ne	7388 <f12+0x458>  // b.any
    7520:	17ffff95 	b	7374 <f12+0x444>
    7524:	97fff430 	bl	45e4 <fwp_rc_wide_dup>
    7528:	17fffec0 	b	7028 <f12+0xf8>
    752c:	f9000be3 	str	x3, [sp, #16]
    7530:	97ffee98 	bl	2f90 <fwp_tape_unlink_scope>
    7534:	a94288bb 	ldp	x27, x2, [x5, #40]
    7538:	f90003e2 	str	x2, [sp]
    753c:	f9401ca2 	ldr	x2, [x5, #56]
    7540:	b90004bf 	str	wzr, [x5, #4]
    7544:	b94000a1 	ldr	w1, [x5]
    7548:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    754c:	f90007e2 	str	x2, [sp, #8]
    7550:	a940a4bc 	ldp	x28, x9, [x5, #8]
    7554:	6b00003f 	cmp	w1, w0
    7558:	f9400be3 	ldr	x3, [sp, #16]
    755c:	a941e8a7 	ldp	x7, x26, [x5, #24]
    7560:	f94020b9 	ldr	x25, [x5, #64]
    7564:	f94024a2 	ldr	x2, [x5, #72]
    7568:	54000108 	b.hi	7588 <f12+0x658>  // b.pmore
    756c:	9101c281 	add	x1, x20, #0x70
    7570:	92403f00 	and	x0, x24, #0xffff
    7574:	d1000400 	sub	x0, x0, #0x1
    7578:	f9407428 	ldr	x8, [x1, #232]
    757c:	eb08001f 	cmp	x0, x8
    7580:	5400004a 	b.ge	7588 <f12+0x658>  // b.tcont
    7584:	f9007420 	str	x0, [x1, #232]
    7588:	4f000400 	movi	v0.4s, #0x0
    758c:	9101c281 	add	x1, x20, #0x70
    7590:	90ffffe0 	adrp	x0, 3000 <fwp_flush+0x10>
    7594:	913fc000 	add	x0, x0, #0xff0
    7598:	f9000cbf 	str	xzr, [x5, #24]
    759c:	910163e4 	add	x4, sp, #0x58
    75a0:	f9418828 	ldr	x8, [x1, #784]
    75a4:	3c8080a0 	stur	q0, [x5, #8]
    75a8:	9101c3e6 	add	x6, sp, #0x70
    75ac:	a90583e8 	stp	x8, x0, [sp, #88]
    75b0:	f94003e0 	ldr	x0, [sp]
    75b4:	ad0100a0 	stp	q0, q0, [x5, #32]
    75b8:	f90043e0 	str	x0, [sp, #128]
    75bc:	f94007e0 	ldr	x0, [sp, #8]
    75c0:	a90113e6 	stp	x6, x4, [sp, #16]
    75c4:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    75c8:	a906ebe6 	stp	x6, x26, [sp, #104]
    75cc:	f9003ffb 	str	x27, [sp, #120]
    75d0:	f90047e0 	str	x0, [sp, #136]
    75d4:	a9091ff9 	stp	x25, x7, [sp, #144]
    75d8:	f90053e2 	str	x2, [sp, #160]
    75dc:	f9018824 	str	x4, [x1, #784]
    75e0:	b7f82163 	tbnz	x3, #63, 7a0c <f12+0xadc>
    75e4:	eb83831f 	cmp	x24, x3, asr #32
    75e8:	54000080 	b.eq	75f8 <f12+0x6c8>  // b.none
    75ec:	90000020 	adrp	x0, b000 <__modti3+0x280>
    75f0:	9113a000 	add	x0, x0, #0x4e8
    75f4:	97fff2c7 	bl	4110 <fwp_trap>
    75f8:	92407c60 	and	x0, x3, #0xffffffff
    75fc:	eb00039f 	cmp	x28, x0
    7600:	9a80c798 	csinc	x24, x28, x0, gt
    7604:	eb23413f 	cmp	x9, w3, uxtw
    7608:	540020cd 	b.le	7a20 <f12+0xaf0>
    760c:	eb18005f 	cmp	x2, x24
    7610:	540020ea 	b.ge	7a2c <f12+0xafc>  // b.tcont
    7614:	f100005f 	cmp	x2, #0x0
    7618:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    761c:	9a981042 	csel	x2, x2, x24, ne	// ne = any
    7620:	14000004 	b	7630 <f12+0x700>
    7624:	eb01005f 	cmp	x2, x1
    7628:	d37ff842 	lsl	x2, x2, #1
    762c:	9a98d042 	csel	x2, x2, x24, le
    7630:	eb18005f 	cmp	x2, x24
    7634:	54ffff8b 	b.lt	7624 <f12+0x6f4>  // b.tstop
    7638:	f90017e3 	str	x3, [sp, #40]
    763c:	b4003d79 	cbz	x25, 7de8 <f12+0xeb8>
    7640:	aa1903e0 	mov	x0, x25
    7644:	d37df041 	lsl	x1, x2, #3
    7648:	f90013e2 	str	x2, [sp, #32]
    764c:	97ffec89 	bl	2870 <realloc@plt>
    7650:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7654:	aa0003f9 	mov	x25, x0
    7658:	b4001eb9 	cbz	x25, 7a2c <f12+0xafc>
    765c:	f9004bf9 	str	x25, [sp, #144]
    7660:	f90053e2 	str	x2, [sp, #160]
    7664:	b5001c78 	cbnz	x24, 79f0 <f12+0xac0>
    7668:	b7f800c3 	tbnz	x3, #63, 7680 <f12+0x750>
    766c:	92407c63 	and	x3, x3, #0xffffffff
    7670:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7674:	fc637b20 	ldr	d0, [x25, x3, lsl #3]
    7678:	1e612800 	fadd	d0, d0, d1
    767c:	fc237b20 	str	d0, [x25, x3, lsl #3]
    7680:	9101c281 	add	x1, x20, #0x70
    7684:	cb1c0303 	sub	x3, x24, x28
    7688:	52800060 	mov	w0, #0x3                   	// #3
    768c:	a9428825 	ldp	x5, x2, [x1, #40]
    7690:	8b1c0042 	add	x2, x2, x28
    7694:	8b050063 	add	x3, x3, x5
    7698:	a9028823 	stp	x3, x2, [x1, #40]
    769c:	97ffefd5 	bl	35f0 <descent_phase_step>
    76a0:	d1000700 	sub	x0, x24, #0x1
    76a4:	d1000782 	sub	x2, x28, #0x1
    76a8:	eb00039f 	cmp	x28, x0
    76ac:	540003ec 	b.gt	7728 <f12+0x7f8>
    76b0:	fc607b20 	ldr	d0, [x25, x0, lsl #3]
    76b4:	1e602008 	fcmp	d0, #0.0
    76b8:	54000320 	b.eq	771c <f12+0x7ec>  // b.none
    76bc:	cb1c0be1 	neg	x1, x28, lsl #2
    76c0:	cb1c03e5 	neg	x5, x28
    76c4:	8b010343 	add	x3, x26, x1
    76c8:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    76cc:	37f80123 	tbnz	w3, #31, 76f0 <f12+0x7c0>
    76d0:	f94003e4 	ldr	x4, [sp]
    76d4:	93407c63 	sxtw	x3, w3
    76d8:	8b050c87 	add	x7, x4, x5, lsl #3
    76dc:	fc637b21 	ldr	d1, [x25, x3, lsl #3]
    76e0:	fc6078e2 	ldr	d2, [x7, x0, lsl #3]
    76e4:	1e620802 	fmul	d2, d0, d2
    76e8:	1e622821 	fadd	d1, d1, d2
    76ec:	fc237b21 	str	d1, [x25, x3, lsl #3]
    76f0:	8b010361 	add	x1, x27, x1
    76f4:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    76f8:	37f80121 	tbnz	w1, #31, 771c <f12+0x7ec>
    76fc:	f94007e3 	ldr	x3, [sp, #8]
    7700:	93407c21 	sxtw	x1, w1
    7704:	8b050c65 	add	x5, x3, x5, lsl #3
    7708:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    770c:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    7710:	1e620800 	fmul	d0, d0, d2
    7714:	1e602820 	fadd	d0, d1, d0
    7718:	fc217b20 	str	d0, [x25, x1, lsl #3]
    771c:	d1000400 	sub	x0, x0, #0x1
    7720:	eb00005f 	cmp	x2, x0
    7724:	54fffc61 	b.ne	76b0 <f12+0x780>  // b.any
    7728:	52800080 	mov	w0, #0x4                   	// #4
    772c:	97ffefb1 	bl	35f0 <descent_phase_step>
    7730:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7734:	eb00039f 	cmp	x28, x0
    7738:	54001a28 	b.hi	7a7c <f12+0xb4c>  // b.pmore
    773c:	91000780 	add	x0, x28, #0x1
    7740:	52800041 	mov	w1, #0x2                   	// #2
    7744:	d37df000 	lsl	x0, x0, #3
    7748:	97fff5ea 	bl	4ef0 <fwp_heap_alloc>
    774c:	aa0003f8 	mov	x24, x0
    7750:	f800841c 	str	x28, [x0], #8
    7754:	d2800001 	mov	x1, #0x0                   	// #0
    7758:	b40000dc 	cbz	x28, 7770 <f12+0x840>
    775c:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    7760:	f8217802 	str	x2, [x0, x1, lsl #3]
    7764:	91000421 	add	x1, x1, #0x1
    7768:	eb01039f 	cmp	x28, x1
    776c:	54ffff81 	b.ne	775c <f12+0x82c>  // b.any
    7770:	528000a0 	mov	w0, #0x5                   	// #5
    7774:	97ffef9f 	bl	35f0 <descent_phase_step>
    7778:	9101c281 	add	x1, x20, #0x70
    777c:	f9400fe2 	ldr	x2, [sp, #24]
    7780:	f9418820 	ldr	x0, [x1, #784]
    7784:	eb02001f 	cmp	x0, x2
    7788:	54004aa1 	b.ne	80dc <f12+0x11ac>  // b.any
    778c:	f9400be0 	ldr	x0, [sp, #16]
    7790:	f9402ffa 	ldr	x26, [sp, #88]
    7794:	f901883a 	str	x26, [x1, #784]
    7798:	97fff216 	bl	3ff0 <fwp_tape_buffers_release>
    779c:	528000c0 	mov	w0, #0x6                   	// #6
    77a0:	97ffef94 	bl	35f0 <descent_phase_step>
    77a4:	911742a2 	add	x2, x21, #0x5d0
    77a8:	f949d841 	ldr	x1, [x2, #5040]
    77ac:	f949ec40 	ldr	x0, [x2, #5080]
    77b0:	cb010301 	sub	x1, x24, x1
    77b4:	eb00403f 	cmp	x1, x0, lsl #16
    77b8:	54000322 	b.cs	781c <f12+0x8ec>  // b.hs, b.nlast
    77bc:	d350fc20 	lsr	x0, x1, #16
    77c0:	f949fc43 	ldr	x3, [x2, #5112]
    77c4:	8b000800 	add	x0, x0, x0, lsl #2
    77c8:	d37df002 	lsl	x2, x0, #3
    77cc:	8b020060 	add	x0, x3, x2
    77d0:	f9401019 	ldr	x25, [x0, #32]
    77d4:	b4000259 	cbz	x25, 781c <f12+0x8ec>
    77d8:	38626862 	ldrb	w2, [x3, x2]
    77dc:	7100085f 	cmp	w2, #0x2
    77e0:	54003180 	b.eq	7e10 <f12+0xee0>  // b.none
    77e4:	7100045f 	cmp	w2, #0x1
    77e8:	540001a1 	b.ne	781c <f12+0x8ec>  // b.any
    77ec:	29430002 	ldp	w2, w0, [x0, #24]
    77f0:	92403c21 	and	x1, x1, #0xffff
    77f4:	9b027c21 	mul	x1, x1, x2
    77f8:	d360fc21 	lsr	x1, x1, #32
    77fc:	eb00003f 	cmp	x1, x0
    7800:	540000e2 	b.cs	781c <f12+0x8ec>  // b.hs, b.nlast
    7804:	8b010339 	add	x25, x25, x1
    7808:	39400320 	ldrb	w0, [x25]
    780c:	7103fc1f 	cmp	w0, #0xff
    7810:	54003060 	b.eq	7e1c <f12+0xeec>  // b.none
    7814:	52800020 	mov	w0, #0x1                   	// #1
    7818:	39000320 	strb	w0, [x25]
    781c:	eb17035f 	cmp	x26, x23
    7820:	540045e1 	b.ne	80dc <f12+0x11ac>  // b.any
    7824:	f94023e1 	ldr	x1, [sp, #64]
    7828:	9101c294 	add	x20, x20, #0x70
    782c:	aa1603e0 	mov	x0, x22
    7830:	f9018a81 	str	x1, [x20, #784]
    7834:	97fffacb 	bl	6360 <fwp_tape_scope_release>
    7838:	f9400300 	ldr	x0, [x24]
    783c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7840:	b7f812c0 	tbnz	x0, #63, 7a98 <f12+0xb68>
    7844:	911742a2 	add	x2, x21, #0x5d0
    7848:	f949d840 	ldr	x0, [x2, #5040]
    784c:	f949ec41 	ldr	x1, [x2, #5080]
    7850:	cb000300 	sub	x0, x24, x0
    7854:	eb01401f 	cmp	x0, x1, lsl #16
    7858:	54001202 	b.cs	7a98 <f12+0xb68>  // b.hs, b.nlast
    785c:	d350fc01 	lsr	x1, x0, #16
    7860:	f949fc44 	ldr	x4, [x2, #5112]
    7864:	8b010821 	add	x1, x1, x1, lsl #2
    7868:	d37df021 	lsl	x1, x1, #3
    786c:	8b010083 	add	x3, x4, x1
    7870:	f9401062 	ldr	x2, [x3, #32]
    7874:	b4001122 	cbz	x2, 7a98 <f12+0xb68>
    7878:	38616881 	ldrb	w1, [x4, x1]
    787c:	7100083f 	cmp	w1, #0x2
    7880:	54001080 	b.eq	7a90 <f12+0xb60>  // b.none
    7884:	7100043f 	cmp	w1, #0x1
    7888:	54001081 	b.ne	7a98 <f12+0xb68>  // b.any
    788c:	29430464 	ldp	w4, w1, [x3, #24]
    7890:	92403c00 	and	x0, x0, #0xffff
    7894:	9b047c00 	mul	x0, x0, x4
    7898:	d360fc00 	lsr	x0, x0, #32
    789c:	eb01001f 	cmp	x0, x1
    78a0:	54000fc2 	b.cs	7a98 <f12+0xb68>  // b.hs, b.nlast
    78a4:	8b000042 	add	x2, x2, x0
    78a8:	39400040 	ldrb	w0, [x2]
    78ac:	7100041f 	cmp	w0, #0x1
    78b0:	54000f41 	b.ne	7a98 <f12+0xb68>  // b.any
    78b4:	aa1803f6 	mov	x22, x24
    78b8:	d2800000 	mov	x0, #0x0                   	// #0
    78bc:	910022c2 	add	x2, x22, #0x8
    78c0:	d2800001 	mov	x1, #0x0                   	// #0
    78c4:	b40001f7 	cbz	x23, 7900 <f12+0x9d0>
    78c8:	90000023 	adrp	x3, b000 <__modti3+0x280>
    78cc:	91002304 	add	x4, x24, #0x8
    78d0:	fd478c61 	ldr	d1, [x3, #3864]
    78d4:	f9400305 	ldr	x5, [x24]
    78d8:	aa0403e3 	mov	x3, x4
    78dc:	b7f80d65 	tbnz	x5, #63, 7a88 <f12+0xb58>
    78e0:	f94002c5 	ldr	x5, [x22]
    78e4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    78e8:	b7f828e5 	tbnz	x5, #63, 7e04 <f12+0xed4>
    78ec:	1e600820 	fmul	d0, d1, d0
    78f0:	91000421 	add	x1, x1, #0x1
    78f4:	fc008440 	str	d0, [x2], #8
    78f8:	eb0102ff 	cmp	x23, x1
    78fc:	54fffec1 	b.ne	78d4 <f12+0x9a4>  // b.any
    7900:	97fffce4 	bl	6c90 <fwp_drop4>
    7904:	b4002ed3 	cbz	x19, 7edc <f12+0xfac>
    7908:	aa1303e0 	mov	x0, x19
    790c:	d2800018 	mov	x24, #0x0                   	// #0
    7910:	f9400800 	ldr	x0, [x0, #16]
    7914:	91000718 	add	x24, x24, #0x1
    7918:	b5ffffc0 	cbnz	x0, 7910 <f12+0x9e0>
    791c:	f94002c0 	ldr	x0, [x22]
    7920:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7924:	b7f810c0 	tbnz	x0, #63, 7b3c <f12+0xc0c>
    7928:	911742a1 	add	x1, x21, #0x5d0
    792c:	f949d820 	ldr	x0, [x1, #5040]
    7930:	f949ec22 	ldr	x2, [x1, #5080]
    7934:	cb0002c0 	sub	x0, x22, x0
    7938:	eb02401f 	cmp	x0, x2, lsl #16
    793c:	540027e2 	b.cs	7e38 <f12+0xf08>  // b.hs, b.nlast
    7940:	d350fc02 	lsr	x2, x0, #16
    7944:	d2800503 	mov	x3, #0x28                  	// #40
    7948:	f949fc24 	ldr	x4, [x1, #5112]
    794c:	9b037c42 	mul	x2, x2, x3
    7950:	8b020083 	add	x3, x4, x2
    7954:	f9401061 	ldr	x1, [x3, #32]
    7958:	b4002701 	cbz	x1, 7e38 <f12+0xf08>
    795c:	38626882 	ldrb	w2, [x4, x2]
    7960:	7100085f 	cmp	w2, #0x2
    7964:	54002660 	b.eq	7e30 <f12+0xf00>  // b.none
    7968:	7100045f 	cmp	w2, #0x1
    796c:	54002661 	b.ne	7e38 <f12+0xf08>  // b.any
    7970:	29430864 	ldp	w4, w2, [x3, #24]
    7974:	92403c00 	and	x0, x0, #0xffff
    7978:	9b047c00 	mul	x0, x0, x4
    797c:	d360fc00 	lsr	x0, x0, #32
    7980:	eb02001f 	cmp	x0, x2
    7984:	540025a2 	b.cs	7e38 <f12+0xf08>  // b.hs, b.nlast
    7988:	8b000021 	add	x1, x1, x0
    798c:	39400037 	ldrb	w23, [x1]
    7990:	710006ff 	cmp	w23, #0x1
    7994:	54002521 	b.ne	7e38 <f12+0xf08>  // b.any
    7998:	910022db 	add	x27, x22, #0x8
    799c:	eb18029f 	cmp	x20, x24
    79a0:	9a989294 	csel	x20, x20, x24, ls	// ls = plast
    79a4:	b4002574 	cbz	x20, 7e50 <f12+0xf20>
    79a8:	d37df284 	lsl	x4, x20, #3
    79ac:	aa1303e1 	mov	x1, x19
    79b0:	910022c3 	add	x3, x22, #0x8
    79b4:	d2800000 	mov	x0, #0x0                   	// #0
    79b8:	14000009 	b	79dc <f12+0xaac>
    79bc:	fc606841 	ldr	d1, [x2, x0]
    79c0:	fd400420 	ldr	d0, [x1, #8]
    79c4:	1e613800 	fsub	d0, d0, d1
    79c8:	fc206b60 	str	d0, [x27, x0]
    79cc:	91002000 	add	x0, x0, #0x8
    79d0:	f9400821 	ldr	x1, [x1, #16]
    79d4:	eb04001f 	cmp	x0, x4
    79d8:	54000de0 	b.eq	7b94 <f12+0xc64>  // b.none
    79dc:	f94002c5 	ldr	x5, [x22]
    79e0:	aa0303e2 	mov	x2, x3
    79e4:	b6fffec5 	tbz	x5, #63, 79bc <f12+0xa8c>
    79e8:	f9400ac2 	ldr	x2, [x22, #16]
    79ec:	17fffff4 	b	79bc <f12+0xa8c>
    79f0:	d37df302 	lsl	x2, x24, #3
    79f4:	aa1903e0 	mov	x0, x25
    79f8:	52800001 	mov	w1, #0x0                   	// #0
    79fc:	f90013e3 	str	x3, [sp, #32]
    7a00:	97ffeb94 	bl	2850 <memset@plt>
    7a04:	f94013e3 	ldr	x3, [sp, #32]
    7a08:	17ffff18 	b	7668 <f12+0x738>
    7a0c:	aa1c03f8 	mov	x24, x28
    7a10:	17fffeff 	b	760c <f12+0x6dc>
    7a14:	aa1b03e0 	mov	x0, x27
    7a18:	97fff1de 	bl	4190 <fwp_rc_forget_slot.part.0>
    7a1c:	17fffe59 	b	7380 <f12+0x450>
    7a20:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7a24:	91158000 	add	x0, x0, #0x560
    7a28:	97fff1ba 	bl	4110 <fwp_trap>
    7a2c:	f100031f 	cmp	x24, #0x0
    7a30:	fa401b20 	ccmp	x25, #0x0, #0x0, ne	// ne = any
    7a34:	54ffe181 	b.ne	7664 <f12+0x734>  // b.any
    7a38:	f9400be0 	ldr	x0, [sp, #16]
    7a3c:	9101c294 	add	x20, x20, #0x70
    7a40:	f9402fe1 	ldr	x1, [sp, #88]
    7a44:	f9018a81 	str	x1, [x20, #784]
    7a48:	97fff16a 	bl	3ff0 <fwp_tape_buffers_release>
    7a4c:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7a50:	f947e863 	ldr	x3, [x3, #4048]
    7a54:	d2800262 	mov	x2, #0x13                  	// #19
    7a58:	d2800021 	mov	x1, #0x1                   	// #1
    7a5c:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7a60:	9104a000 	add	x0, x0, #0x128
    7a64:	f9400063 	ldr	x3, [x3]
    7a68:	97ffebc6 	bl	2980 <fwrite@plt>
    7a6c:	d2800000 	mov	x0, #0x0                   	// #0
    7a70:	97ffebd0 	bl	29b0 <fflush@plt>
    7a74:	52800cc0 	mov	w0, #0x66                  	// #102
    7a78:	97ffebde 	bl	29f0 <_Exit@plt>
    7a7c:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7a80:	91194000 	add	x0, x0, #0x650
    7a84:	97fff1a3 	bl	4110 <fwp_trap>
    7a88:	f9400b03 	ldr	x3, [x24, #16]
    7a8c:	17ffff95 	b	78e0 <f12+0x9b0>
    7a90:	72003c1f 	tst	w0, #0xffff
    7a94:	54fff0a0 	b.eq	78a8 <f12+0x978>  // b.none
    7a98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7a9c:	eb0002ff 	cmp	x23, x0
    7aa0:	54fffee8 	b.hi	7a7c <f12+0xb4c>  // b.pmore
    7aa4:	910006e0 	add	x0, x23, #0x1
    7aa8:	52800021 	mov	w1, #0x1                   	// #1
    7aac:	d37df000 	lsl	x0, x0, #3
    7ab0:	97fff510 	bl	4ef0 <fwp_heap_alloc>
    7ab4:	911742a2 	add	x2, x21, #0x5d0
    7ab8:	f9000017 	str	x23, [x0]
    7abc:	aa0003f6 	mov	x22, x0
    7ac0:	f949d841 	ldr	x1, [x2, #5040]
    7ac4:	f949ec40 	ldr	x0, [x2, #5080]
    7ac8:	cb0102c1 	sub	x1, x22, x1
    7acc:	eb00403f 	cmp	x1, x0, lsl #16
    7ad0:	54000322 	b.cs	7b34 <f12+0xc04>  // b.hs, b.nlast
    7ad4:	d350fc20 	lsr	x0, x1, #16
    7ad8:	d2800504 	mov	x4, #0x28                  	// #40
    7adc:	f949fc43 	ldr	x3, [x2, #5112]
    7ae0:	9b047c00 	mul	x0, x0, x4
    7ae4:	8b000062 	add	x2, x3, x0
    7ae8:	f9401054 	ldr	x20, [x2, #32]
    7aec:	b4000254 	cbz	x20, 7b34 <f12+0xc04>
    7af0:	38606860 	ldrb	w0, [x3, x0]
    7af4:	7100081f 	cmp	w0, #0x2
    7af8:	54001e60 	b.eq	7ec4 <f12+0xf94>  // b.none
    7afc:	7100041f 	cmp	w0, #0x1
    7b00:	540001a1 	b.ne	7b34 <f12+0xc04>  // b.any
    7b04:	29430043 	ldp	w3, w0, [x2, #24]
    7b08:	92403c21 	and	x1, x1, #0xffff
    7b0c:	9b037c21 	mul	x1, x1, x3
    7b10:	d360fc21 	lsr	x1, x1, #32
    7b14:	eb00003f 	cmp	x1, x0
    7b18:	540000e2 	b.cs	7b34 <f12+0xc04>  // b.hs, b.nlast
    7b1c:	8b010294 	add	x20, x20, x1
    7b20:	39400280 	ldrb	w0, [x20]
    7b24:	7103fc1f 	cmp	w0, #0xff
    7b28:	54001c80 	b.eq	7eb8 <f12+0xf88>  // b.none
    7b2c:	52800020 	mov	w0, #0x1                   	// #1
    7b30:	39000280 	strb	w0, [x20]
    7b34:	aa1803e0 	mov	x0, x24
    7b38:	17ffff61 	b	78bc <f12+0x98c>
    7b3c:	aa1303f7 	mov	x23, x19
    7b40:	d2800018 	mov	x24, #0x0                   	// #0
    7b44:	f9400af7 	ldr	x23, [x23, #16]
    7b48:	aa1803e0 	mov	x0, x24
    7b4c:	91000718 	add	x24, x24, #0x1
    7b50:	b5ffffb7 	cbnz	x23, 7b44 <f12+0xc14>
    7b54:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7b58:	eb01031f 	cmp	x24, x1
    7b5c:	54ffb908 	b.hi	727c <f12+0x34c>  // b.pmore
    7b60:	91000800 	add	x0, x0, #0x2
    7b64:	52800041 	mov	w1, #0x2                   	// #2
    7b68:	d37df000 	lsl	x0, x0, #3
    7b6c:	97fff4e1 	bl	4ef0 <fwp_heap_alloc>
    7b70:	aa1303e1 	mov	x1, x19
    7b74:	aa0003fb 	mov	x27, x0
    7b78:	f9400420 	ldr	x0, [x1, #8]
    7b7c:	f8377b60 	str	x0, [x27, x23, lsl #3]
    7b80:	910006f7 	add	x23, x23, #0x1
    7b84:	f9400821 	ldr	x1, [x1, #16]
    7b88:	b5ffff81 	cbnz	x1, 7b78 <f12+0xc48>
    7b8c:	52800017 	mov	w23, #0x0                   	// #0
    7b90:	17ffff83 	b	799c <f12+0xa6c>
    7b94:	b4001a13 	cbz	x19, 7ed4 <f12+0xfa4>
    7b98:	911742a0 	add	x0, x21, #0x5d0
    7b9c:	aa1303e2 	mov	x2, x19
    7ba0:	d2800019 	mov	x25, #0x0                   	// #0
    7ba4:	f949ec05 	ldr	x5, [x0, #5080]
    7ba8:	f949d808 	ldr	x8, [x0, #5040]
    7bac:	f949fc07 	ldr	x7, [x0, #5112]
    7bb0:	d370bca5 	lsl	x5, x5, #16
    7bb4:	14000006 	b	7bcc <f12+0xc9c>
    7bb8:	f9400842 	ldr	x2, [x2, #16]
    7bbc:	91000739 	add	x25, x25, #0x1
    7bc0:	f100005f 	cmp	x2, #0x0
    7bc4:	fa541322 	ccmp	x25, x20, #0x2, ne	// ne = any
    7bc8:	54000322 	b.cs	7c2c <f12+0xcfc>  // b.hs, b.nlast
    7bcc:	cb080040 	sub	x0, x2, x8
    7bd0:	eb05001f 	cmp	x0, x5
    7bd4:	540002c2 	b.cs	7c2c <f12+0xcfc>  // b.hs, b.nlast
    7bd8:	d350fc01 	lsr	x1, x0, #16
    7bdc:	8b010821 	add	x1, x1, x1, lsl #2
    7be0:	d37df021 	lsl	x1, x1, #3
    7be4:	8b0100e6 	add	x6, x7, x1
    7be8:	f94010c4 	ldr	x4, [x6, #32]
    7bec:	b4000204 	cbz	x4, 7c2c <f12+0xcfc>
    7bf0:	386168e1 	ldrb	w1, [x7, x1]
    7bf4:	7100083f 	cmp	w1, #0x2
    7bf8:	54000f20 	b.eq	7ddc <f12+0xeac>  // b.none
    7bfc:	7100043f 	cmp	w1, #0x1
    7c00:	54000161 	b.ne	7c2c <f12+0xcfc>  // b.any
    7c04:	294304c9 	ldp	w9, w1, [x6, #24]
    7c08:	92403c00 	and	x0, x0, #0xffff
    7c0c:	9b097c00 	mul	x0, x0, x9
    7c10:	d360fc00 	lsr	x0, x0, #32
    7c14:	eb01001f 	cmp	x0, x1
    7c18:	540000a2 	b.cs	7c2c <f12+0xcfc>  // b.hs, b.nlast
    7c1c:	8b000084 	add	x4, x4, x0
    7c20:	39400080 	ldrb	w0, [x4]
    7c24:	7100041f 	cmp	w0, #0x1
    7c28:	54fffc80 	b.eq	7bb8 <f12+0xc88>  // b.none
    7c2c:	d2800018 	mov	x24, #0x0                   	// #0
    7c30:	eb14033f 	cmp	x25, x20
    7c34:	54001602 	b.cs	7ef4 <f12+0xfc4>  // b.hs, b.nlast
    7c38:	d1002360 	sub	x0, x27, #0x8
    7c3c:	f90007e0 	str	x0, [sp, #8]
    7c40:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7c44:	911742bc 	add	x28, x21, #0x5d0
    7c48:	d2800018 	mov	x24, #0x0                   	// #0
    7c4c:	fd477008 	ldr	d8, [x0, #3808]
    7c50:	14000043 	b	7d5c <f12+0xe2c>
    7c54:	f9400340 	ldr	x0, [x26]
    7c58:	aa2003e0 	mvn	x0, x0
    7c5c:	f8217b80 	str	x0, [x28, x1, lsl #3]
    7c60:	f10060bf 	cmp	x5, #0x18
    7c64:	54000169 	b.ls	7c90 <f12+0xd60>  // b.plast
    7c68:	d10064a2 	sub	x2, x5, #0x19
    7c6c:	91006340 	add	x0, x26, #0x18
    7c70:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7c74:	52800001 	mov	w1, #0x0                   	// #0
    7c78:	91002042 	add	x2, x2, #0x8
    7c7c:	f9000be5 	str	x5, [sp, #16]
    7c80:	b9001be6 	str	w6, [sp, #24]
    7c84:	97ffeaf3 	bl	2850 <memset@plt>
    7c88:	f9400be5 	ldr	x5, [sp, #16]
    7c8c:	b9401be6 	ldr	w6, [sp, #24]
    7c90:	911742a1 	add	x1, x21, #0x5d0
    7c94:	f94a1020 	ldr	x0, [x1, #5152]
    7c98:	ab050000 	adds	x0, x0, x5
    7c9c:	540014c2 	b.cs	7f34 <f12+0x1004>  // b.hs, b.nlast
    7ca0:	f94a1422 	ldr	x2, [x1, #5160]
    7ca4:	f90a1020 	str	x0, [x1, #5152]
    7ca8:	eb02001f 	cmp	x0, x2
    7cac:	54000049 	b.ls	7cb4 <f12+0xd84>  // b.plast
    7cb0:	f90a1420 	str	x0, [x1, #5160]
    7cb4:	911742a0 	add	x0, x21, #0x5d0
    7cb8:	1e6300c1 	ucvtf	d1, w6
    7cbc:	fd4a1c00 	ldr	d0, [x0, #5176]
    7cc0:	1e612800 	fadd	d0, d0, d1
    7cc4:	fd0a1c00 	str	d0, [x0, #5176]
    7cc8:	f94003e0 	ldr	x0, [sp]
    7ccc:	a900e340 	stp	x0, x24, [x26, #8]
    7cd0:	aa1a03f8 	mov	x24, x26
    7cd4:	fd000348 	str	d8, [x26]
    7cd8:	f949db81 	ldr	x1, [x28, #5040]
    7cdc:	f949ef80 	ldr	x0, [x28, #5080]
    7ce0:	cb010341 	sub	x1, x26, x1
    7ce4:	eb00403f 	cmp	x1, x0, lsl #16
    7ce8:	54000322 	b.cs	7d4c <f12+0xe1c>  // b.hs, b.nlast
    7cec:	d350fc20 	lsr	x0, x1, #16
    7cf0:	f949ff85 	ldr	x5, [x28, #5112]
    7cf4:	8b000800 	add	x0, x0, x0, lsl #2
    7cf8:	d37df002 	lsl	x2, x0, #3
    7cfc:	8b0200a0 	add	x0, x5, x2
    7d00:	f940101a 	ldr	x26, [x0, #32]
    7d04:	b400025a 	cbz	x26, 7d4c <f12+0xe1c>
    7d08:	386268a2 	ldrb	w2, [x5, x2]
    7d0c:	7100085f 	cmp	w2, #0x2
    7d10:	54000600 	b.eq	7dd0 <f12+0xea0>  // b.none
    7d14:	7100045f 	cmp	w2, #0x1
    7d18:	540001a1 	b.ne	7d4c <f12+0xe1c>  // b.any
    7d1c:	29430002 	ldp	w2, w0, [x0, #24]
    7d20:	92403c21 	and	x1, x1, #0xffff
    7d24:	9b027c21 	mul	x1, x1, x2
    7d28:	d360fc21 	lsr	x1, x1, #32
    7d2c:	eb00003f 	cmp	x1, x0
    7d30:	540000e2 	b.cs	7d4c <f12+0xe1c>  // b.hs, b.nlast
    7d34:	8b01035a 	add	x26, x26, x1
    7d38:	39400340 	ldrb	w0, [x26]
    7d3c:	7103fc1f 	cmp	w0, #0xff
    7d40:	54000f40 	b.eq	7f28 <f12+0xff8>  // b.none
    7d44:	52800020 	mov	w0, #0x1                   	// #1
    7d48:	39000340 	strb	w0, [x26]
    7d4c:	d1000680 	sub	x0, x20, #0x1
    7d50:	eb19001f 	cmp	x0, x25
    7d54:	54000f29 	b.ls	7f38 <f12+0x1008>  // b.plast
    7d58:	aa0003f4 	mov	x20, x0
    7d5c:	f94007e1 	ldr	x1, [sp, #8]
    7d60:	b953a780 	ldr	w0, [x28, #5028]
    7d64:	f8747821 	ldr	x1, [x1, x20, lsl #3]
    7d68:	f90003e1 	str	x1, [sp]
    7d6c:	34000280 	cbz	w0, 7dbc <f12+0xe8c>
    7d70:	397e8b80 	ldrb	w0, [x28, #4002]
    7d74:	910f0002 	add	x2, x0, #0x3c0
    7d78:	8b000401 	add	x1, x0, x0, lsl #1
    7d7c:	b8627b86 	ldr	w6, [x28, x2, lsl #2]
    7d80:	8b010f82 	add	x2, x28, x1, lsl #3
    7d84:	f8617b9a 	ldr	x26, [x28, x1, lsl #3]
    7d88:	2a0603e5 	mov	w5, w6
    7d8c:	b5fff65a 	cbnz	x26, 7c54 <f12+0xd24>
    7d90:	f940045a 	ldr	x26, [x2, #8]
    7d94:	b400015a 	cbz	x26, 7dbc <f12+0xe8c>
    7d98:	f9400841 	ldr	x1, [x2, #16]
    7d9c:	cb1a0021 	sub	x1, x1, x26
    7da0:	eb0100bf 	cmp	x5, x1
    7da4:	540000c8 	b.hi	7dbc <f12+0xe8c>  // b.pmore
    7da8:	d2800302 	mov	x2, #0x18                  	// #24
    7dac:	8b050341 	add	x1, x26, x5
    7db0:	9b027000 	madd	x0, x0, x2, x28
    7db4:	f9000401 	str	x1, [x0, #8]
    7db8:	17ffffaa 	b	7c60 <f12+0xd30>
    7dbc:	52800001 	mov	w1, #0x0                   	// #0
    7dc0:	d2800300 	mov	x0, #0x18                  	// #24
    7dc4:	97fff44b 	bl	4ef0 <fwp_heap_alloc>
    7dc8:	aa0003fa 	mov	x26, x0
    7dcc:	17ffffbf 	b	7cc8 <f12+0xd98>
    7dd0:	72003c3f 	tst	w1, #0xffff
    7dd4:	54fffbc1 	b.ne	7d4c <f12+0xe1c>  // b.any
    7dd8:	17ffffd8 	b	7d38 <f12+0xe08>
    7ddc:	72003c1f 	tst	w0, #0xffff
    7de0:	54fff261 	b.ne	7c2c <f12+0xcfc>  // b.any
    7de4:	17ffff8f 	b	7c20 <f12+0xcf0>
    7de8:	aa0203e0 	mov	x0, x2
    7dec:	d2800101 	mov	x1, #0x8                   	// #8
    7df0:	f90013e2 	str	x2, [sp, #32]
    7df4:	97ffea9b 	bl	2860 <calloc@plt>
    7df8:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7dfc:	aa0003f9 	mov	x25, x0
    7e00:	17fffe16 	b	7658 <f12+0x728>
    7e04:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7e08:	91198000 	add	x0, x0, #0x660
    7e0c:	97fff0c1 	bl	4110 <fwp_trap>
    7e10:	72003c3f 	tst	w1, #0xffff
    7e14:	54ffd041 	b.ne	781c <f12+0x8ec>  // b.any
    7e18:	17fffe7c 	b	7808 <f12+0x8d8>
    7e1c:	aa1903e0 	mov	x0, x25
    7e20:	97fff0dc 	bl	4190 <fwp_rc_forget_slot.part.0>
    7e24:	9101c280 	add	x0, x20, #0x70
    7e28:	f941881a 	ldr	x26, [x0, #784]
    7e2c:	17fffe7a 	b	7814 <f12+0x8e4>
    7e30:	72003c1f 	tst	w0, #0xffff
    7e34:	54ffdac0 	b.eq	798c <f12+0xa5c>  // b.none
    7e38:	b5ffe833 	cbnz	x19, 7b3c <f12+0xc0c>
    7e3c:	52800041 	mov	w1, #0x2                   	// #2
    7e40:	d2800100 	mov	x0, #0x8                   	// #8
    7e44:	97fff42b 	bl	4ef0 <fwp_heap_alloc>
    7e48:	aa0003fb 	mov	x27, x0
    7e4c:	52800017 	mov	w23, #0x0                   	// #0
    7e50:	d2800018 	mov	x24, #0x0                   	// #0
    7e54:	710002ff 	cmp	w23, #0x0
    7e58:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7e5c:	aa1b03e0 	mov	x0, x27
    7e60:	97fff168 	bl	4400 <fwp_mem_free>
    7e64:	aa1603e0 	mov	x0, x22
    7e68:	97fffb8a 	bl	6c90 <fwp_drop4>
    7e6c:	aa1303e0 	mov	x0, x19
    7e70:	97fff7f0 	bl	5e30 <fwp_drop0>
    7e74:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7e78:	f947f400 	ldr	x0, [x0, #4072]
    7e7c:	f94057e2 	ldr	x2, [sp, #168]
    7e80:	f9400001 	ldr	x1, [x0]
    7e84:	eb010042 	subs	x2, x2, x1
    7e88:	d2800001 	mov	x1, #0x0                   	// #0
    7e8c:	54000321 	b.ne	7ef0 <f12+0xfc0>  // b.any
    7e90:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7e94:	aa1803e0 	mov	x0, x24
    7e98:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7e9c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7ea0:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7ea4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7ea8:	a95073fb 	ldp	x27, x28, [sp, #256]
    7eac:	fd408be8 	ldr	d8, [sp, #272]
    7eb0:	910483ff 	add	sp, sp, #0x120
    7eb4:	d65f03c0 	ret
    7eb8:	aa1403e0 	mov	x0, x20
    7ebc:	97fff0b5 	bl	4190 <fwp_rc_forget_slot.part.0>
    7ec0:	17ffff1b 	b	7b2c <f12+0xbfc>
    7ec4:	72003c3f 	tst	w1, #0xffff
    7ec8:	54ffe2c0 	b.eq	7b20 <f12+0xbf0>  // b.none
    7ecc:	aa1803e0 	mov	x0, x24
    7ed0:	17fffe7b 	b	78bc <f12+0x98c>
    7ed4:	d2800019 	mov	x25, #0x0                   	// #0
    7ed8:	17ffff58 	b	7c38 <f12+0xd08>
    7edc:	f94002d4 	ldr	x20, [x22]
    7ee0:	b7fffaf4 	tbnz	x20, #63, 7e3c <f12+0xf0c>
    7ee4:	9240fa94 	and	x20, x20, #0x7fffffffffffffff
    7ee8:	d2800018 	mov	x24, #0x0                   	// #0
    7eec:	17fffe8f 	b	7928 <f12+0x9f8>
    7ef0:	97ffea64 	bl	2880 <__stack_chk_fail@plt>
    7ef4:	aa1303e0 	mov	x0, x19
    7ef8:	d2800001 	mov	x1, #0x0                   	// #0
    7efc:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    7f00:	91000421 	add	x1, x1, #0x1
    7f04:	f9000402 	str	x2, [x0, #8]
    7f08:	aa0003e2 	mov	x2, x0
    7f0c:	f9400800 	ldr	x0, [x0, #16]
    7f10:	eb01033f 	cmp	x25, x1
    7f14:	54ffff48 	b.hi	7efc <f12+0xfcc>  // b.pmore
    7f18:	f9000858 	str	x24, [x2, #16]
    7f1c:	aa1303f8 	mov	x24, x19
    7f20:	aa0003f3 	mov	x19, x0
    7f24:	17ffffcc 	b	7e54 <f12+0xf24>
    7f28:	aa1a03e0 	mov	x0, x26
    7f2c:	97fff099 	bl	4190 <fwp_rc_forget_slot.part.0>
    7f30:	17ffff85 	b	7d44 <f12+0xe14>
    7f34:	97ffec3f 	bl	3030 <fwp_heap_oom>
    7f38:	b5fffdf9 	cbnz	x25, 7ef4 <f12+0xfc4>
    7f3c:	710002ff 	cmp	w23, #0x0
    7f40:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7f44:	b4fff8c0 	cbz	x0, 7e5c <f12+0xf2c>
    7f48:	90000020 	adrp	x0, b000 <__modti3+0x280>
    7f4c:	d1000a94 	sub	x20, x20, #0x2
    7f50:	911742b5 	add	x21, x21, #0x5d0
    7f54:	d280031a 	mov	x26, #0x18                  	// #24
    7f58:	fd477008 	ldr	d8, [x0, #3808]
    7f5c:	52800039 	mov	w25, #0x1                   	// #1
    7f60:	b953a6a0 	ldr	w0, [x21, #5028]
    7f64:	f8747b7c 	ldr	x28, [x27, x20, lsl #3]
    7f68:	34000a20 	cbz	w0, 80ac <f12+0x117c>
    7f6c:	397e8aa0 	ldrb	w0, [x21, #4002]
    7f70:	910f0002 	add	x2, x0, #0x3c0
    7f74:	8b000401 	add	x1, x0, x0, lsl #1
    7f78:	b8627aa4 	ldr	w4, [x21, x2, lsl #2]
    7f7c:	8b010ea2 	add	x2, x21, x1, lsl #3
    7f80:	f8617ab7 	ldr	x23, [x21, x1, lsl #3]
    7f84:	2a0403e3 	mov	w3, w4
    7f88:	b40007f7 	cbz	x23, 8084 <f12+0x1154>
    7f8c:	f94002e0 	ldr	x0, [x23]
    7f90:	aa2003e0 	mvn	x0, x0
    7f94:	f8217aa0 	str	x0, [x21, x1, lsl #3]
    7f98:	f100607f 	cmp	x3, #0x18
    7f9c:	54000169 	b.ls	7fc8 <f12+0x1098>  // b.plast
    7fa0:	d1006462 	sub	x2, x3, #0x19
    7fa4:	910062e0 	add	x0, x23, #0x18
    7fa8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7fac:	52800001 	mov	w1, #0x0                   	// #0
    7fb0:	91002042 	add	x2, x2, #0x8
    7fb4:	f90003e3 	str	x3, [sp]
    7fb8:	b9000be4 	str	w4, [sp, #8]
    7fbc:	97ffea25 	bl	2850 <memset@plt>
    7fc0:	f94003e3 	ldr	x3, [sp]
    7fc4:	b9400be4 	ldr	w4, [sp, #8]
    7fc8:	f94a12a0 	ldr	x0, [x21, #5152]
    7fcc:	ab030000 	adds	x0, x0, x3
    7fd0:	54fffb22 	b.cs	7f34 <f12+0x1004>  // b.hs, b.nlast
    7fd4:	f94a16a1 	ldr	x1, [x21, #5160]
    7fd8:	f90a12a0 	str	x0, [x21, #5152]
    7fdc:	eb01001f 	cmp	x0, x1
    7fe0:	54000049 	b.ls	7fe8 <f12+0x10b8>  // b.plast
    7fe4:	f90a16a0 	str	x0, [x21, #5160]
    7fe8:	1e630081 	ucvtf	d1, w4
    7fec:	fd4a1ea0 	ldr	d0, [x21, #5176]
    7ff0:	1e612800 	fadd	d0, d0, d1
    7ff4:	fd0a1ea0 	str	d0, [x21, #5176]
    7ff8:	a900e2fc 	stp	x28, x24, [x23, #8]
    7ffc:	aa1703f8 	mov	x24, x23
    8000:	fd0002e8 	str	d8, [x23]
    8004:	f949daa1 	ldr	x1, [x21, #5040]
    8008:	f949eea0 	ldr	x0, [x21, #5080]
    800c:	cb0102e1 	sub	x1, x23, x1
    8010:	eb00403f 	cmp	x1, x0, lsl #16
    8014:	54000302 	b.cs	8074 <f12+0x1144>  // b.hs, b.nlast
    8018:	d350fc20 	lsr	x0, x1, #16
    801c:	f949fea3 	ldr	x3, [x21, #5112]
    8020:	8b000800 	add	x0, x0, x0, lsl #2
    8024:	d37df002 	lsl	x2, x0, #3
    8028:	8b020060 	add	x0, x3, x2
    802c:	f9401017 	ldr	x23, [x0, #32]
    8030:	b4000237 	cbz	x23, 8074 <f12+0x1144>
    8034:	38626862 	ldrb	w2, [x3, x2]
    8038:	7100085f 	cmp	w2, #0x2
    803c:	54000420 	b.eq	80c0 <f12+0x1190>  // b.none
    8040:	7100045f 	cmp	w2, #0x1
    8044:	54000181 	b.ne	8074 <f12+0x1144>  // b.any
    8048:	29430002 	ldp	w2, w0, [x0, #24]
    804c:	92403c21 	and	x1, x1, #0xffff
    8050:	9b027c21 	mul	x1, x1, x2
    8054:	d360fc21 	lsr	x1, x1, #32
    8058:	eb00003f 	cmp	x1, x0
    805c:	540000c2 	b.cs	8074 <f12+0x1144>  // b.hs, b.nlast
    8060:	8b0102f7 	add	x23, x23, x1
    8064:	394002e0 	ldrb	w0, [x23]
    8068:	7103fc1f 	cmp	w0, #0xff
    806c:	54000300 	b.eq	80cc <f12+0x119c>  // b.none
    8070:	390002f9 	strb	w25, [x23]
    8074:	d1000694 	sub	x20, x20, #0x1
    8078:	b100069f 	cmn	x20, #0x1
    807c:	54fff721 	b.ne	7f60 <f12+0x1030>  // b.any
    8080:	17ffff77 	b	7e5c <f12+0xf2c>
    8084:	f9400457 	ldr	x23, [x2, #8]
    8088:	b4000137 	cbz	x23, 80ac <f12+0x117c>
    808c:	f9400841 	ldr	x1, [x2, #16]
    8090:	cb170021 	sub	x1, x1, x23
    8094:	eb01007f 	cmp	x3, x1
    8098:	540000a8 	b.hi	80ac <f12+0x117c>  // b.pmore
    809c:	9b1a5400 	madd	x0, x0, x26, x21
    80a0:	8b0302e1 	add	x1, x23, x3
    80a4:	f9000401 	str	x1, [x0, #8]
    80a8:	17ffffbc 	b	7f98 <f12+0x1068>
    80ac:	52800001 	mov	w1, #0x0                   	// #0
    80b0:	d2800300 	mov	x0, #0x18                  	// #24
    80b4:	97fff38f 	bl	4ef0 <fwp_heap_alloc>
    80b8:	aa0003f7 	mov	x23, x0
    80bc:	17ffffcf 	b	7ff8 <f12+0x10c8>
    80c0:	72003c3f 	tst	w1, #0xffff
    80c4:	54fffd81 	b.ne	8074 <f12+0x1144>  // b.any
    80c8:	17ffffe7 	b	8064 <f12+0x1134>
    80cc:	aa1703e0 	mov	x0, x23
    80d0:	97fff030 	bl	4190 <fwp_rc_forget_slot.part.0>
    80d4:	17ffffe7 	b	8070 <f12+0x1140>
    80d8:	97ffea6a 	bl	2a80 <fwp_trap_overflow.constprop.0>
    80dc:	97ffe9fd 	bl	28d0 <abort@plt>

00000000000080e0 <fwp_owned_entry12>:
    80e0:	f9400000 	ldr	x0, [x0]
    80e4:	17fffb93 	b	6f30 <f12>
    80e8:	d503201f 	nop
    80ec:	d503201f 	nop

00000000000080f0 <e12>:
    80f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    80f4:	910003fd 	mov	x29, sp
    80f8:	f9000bf3 	str	x19, [sp, #16]
    80fc:	f9400013 	ldr	x19, [x0]
    8100:	aa1303e0 	mov	x0, x19
    8104:	97fff683 	bl	5b10 <fwp_rc_share>
    8108:	aa1303e0 	mov	x0, x19
    810c:	97fffb89 	bl	6f30 <f12>
    8110:	aa0003f3 	mov	x19, x0
    8114:	97fff67f 	bl	5b10 <fwp_rc_share>
    8118:	aa1303e0 	mov	x0, x19
    811c:	f9400bf3 	ldr	x19, [sp, #16]
    8120:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8124:	d65f03c0 	ret
    8128:	d503201f 	nop
    812c:	d503201f 	nop

0000000000008130 <fwp_args23>:
    8130:	7100003f 	cmp	w1, #0x0
    8134:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8138:	54000041 	b.ne	8140 <fwp_args23+0x10>  // b.any
    813c:	d65f03c0 	ret
    8140:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8144:	91174042 	add	x2, x2, #0x5d0
    8148:	f9400001 	ldr	x1, [x0]
    814c:	f949d843 	ldr	x3, [x2, #5040]
    8150:	f949ec40 	ldr	x0, [x2, #5080]
    8154:	cb030021 	sub	x1, x1, x3
    8158:	eb00403f 	cmp	x1, x0, lsl #16
    815c:	54ffff02 	b.cs	813c <fwp_args23+0xc>  // b.hs, b.nlast
    8160:	d350fc20 	lsr	x0, x1, #16
    8164:	f949fc44 	ldr	x4, [x2, #5112]
    8168:	8b000800 	add	x0, x0, x0, lsl #2
    816c:	d37df002 	lsl	x2, x0, #3
    8170:	8b020083 	add	x3, x4, x2
    8174:	f9401060 	ldr	x0, [x3, #32]
    8178:	b4fffe20 	cbz	x0, 813c <fwp_args23+0xc>
    817c:	38626882 	ldrb	w2, [x4, x2]
    8180:	7100085f 	cmp	w2, #0x2
    8184:	54000220 	b.eq	81c8 <fwp_args23+0x98>  // b.none
    8188:	7100045f 	cmp	w2, #0x1
    818c:	54fffd81 	b.ne	813c <fwp_args23+0xc>  // b.any
    8190:	29430864 	ldp	w4, w2, [x3, #24]
    8194:	92403c21 	and	x1, x1, #0xffff
    8198:	9b047c21 	mul	x1, x1, x4
    819c:	d360fc21 	lsr	x1, x1, #32
    81a0:	eb02003f 	cmp	x1, x2
    81a4:	54fffcc2 	b.cs	813c <fwp_args23+0xc>  // b.hs, b.nlast
    81a8:	8b010000 	add	x0, x0, x1
    81ac:	39400001 	ldrb	w1, [x0]
    81b0:	34fffc61 	cbz	w1, 813c <fwp_args23+0xc>
    81b4:	7103f43f 	cmp	w1, #0xfd
    81b8:	540000e8 	b.hi	81d4 <fwp_args23+0xa4>  // b.pmore
    81bc:	11000421 	add	w1, w1, #0x1
    81c0:	39000001 	strb	w1, [x0]
    81c4:	d65f03c0 	ret
    81c8:	72003c3f 	tst	w1, #0xffff
    81cc:	54ffff00 	b.eq	81ac <fwp_args23+0x7c>  // b.none
    81d0:	d65f03c0 	ret
    81d4:	17fff104 	b	45e4 <fwp_rc_wide_dup>
    81d8:	d503201f 	nop
    81dc:	d503201f 	nop

00000000000081e0 <fwp_args12>:
    81e0:	7100003f 	cmp	w1, #0x0
    81e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    81e8:	54000041 	b.ne	81f0 <fwp_args12+0x10>  // b.any
    81ec:	d65f03c0 	ret
    81f0:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    81f4:	91174042 	add	x2, x2, #0x5d0
    81f8:	f9400001 	ldr	x1, [x0]
    81fc:	f949d843 	ldr	x3, [x2, #5040]
    8200:	f949ec40 	ldr	x0, [x2, #5080]
    8204:	cb030021 	sub	x1, x1, x3
    8208:	eb00403f 	cmp	x1, x0, lsl #16
    820c:	54ffff02 	b.cs	81ec <fwp_args12+0xc>  // b.hs, b.nlast
    8210:	d350fc20 	lsr	x0, x1, #16
    8214:	f949fc44 	ldr	x4, [x2, #5112]
    8218:	8b000800 	add	x0, x0, x0, lsl #2
    821c:	d37df002 	lsl	x2, x0, #3
    8220:	8b020083 	add	x3, x4, x2
    8224:	f9401060 	ldr	x0, [x3, #32]
    8228:	b4fffe20 	cbz	x0, 81ec <fwp_args12+0xc>
    822c:	38626882 	ldrb	w2, [x4, x2]
    8230:	7100085f 	cmp	w2, #0x2
    8234:	54000220 	b.eq	8278 <fwp_args12+0x98>  // b.none
    8238:	7100045f 	cmp	w2, #0x1
    823c:	54fffd81 	b.ne	81ec <fwp_args12+0xc>  // b.any
    8240:	29430864 	ldp	w4, w2, [x3, #24]
    8244:	92403c21 	and	x1, x1, #0xffff
    8248:	9b047c21 	mul	x1, x1, x4
    824c:	d360fc21 	lsr	x1, x1, #32
    8250:	eb02003f 	cmp	x1, x2
    8254:	54fffcc2 	b.cs	81ec <fwp_args12+0xc>  // b.hs, b.nlast
    8258:	8b010000 	add	x0, x0, x1
    825c:	39400001 	ldrb	w1, [x0]
    8260:	34fffc61 	cbz	w1, 81ec <fwp_args12+0xc>
    8264:	7103f43f 	cmp	w1, #0xfd
    8268:	540000e8 	b.hi	8284 <fwp_args12+0xa4>  // b.pmore
    826c:	11000421 	add	w1, w1, #0x1
    8270:	39000001 	strb	w1, [x0]
    8274:	d65f03c0 	ret
    8278:	72003c3f 	tst	w1, #0xffff
    827c:	54ffff00 	b.eq	825c <fwp_args12+0x7c>  // b.none
    8280:	d65f03c0 	ret
    8284:	17fff0d8 	b	45e4 <fwp_rc_wide_dup>
    8288:	d503201f 	nop
    828c:	d503201f 	nop

0000000000008290 <fwp_caps12>:
    8290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8294:	910003fd 	mov	x29, sp
    8298:	f9000bf3 	str	x19, [sp, #16]
    829c:	aa0003f3 	mov	x19, x0
    82a0:	b9400400 	ldr	w0, [x0, #4]
    82a4:	340004a0 	cbz	w0, 8338 <fwp_caps12+0xa8>
    82a8:	f9400660 	ldr	x0, [x19, #8]
    82ac:	350004e1 	cbnz	w1, 8348 <fwp_caps12+0xb8>
    82b0:	97fff6e0 	bl	5e30 <fwp_drop0>
    82b4:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    82b8:	91174042 	add	x2, x2, #0x5d0
    82bc:	f949d840 	ldr	x0, [x2, #5040]
    82c0:	f949ec41 	ldr	x1, [x2, #5080]
    82c4:	cb000260 	sub	x0, x19, x0
    82c8:	eb01401f 	cmp	x0, x1, lsl #16
    82cc:	54000382 	b.cs	833c <fwp_caps12+0xac>  // b.hs, b.nlast
    82d0:	d350fc01 	lsr	x1, x0, #16
    82d4:	f949fc44 	ldr	x4, [x2, #5112]
    82d8:	8b010821 	add	x1, x1, x1, lsl #2
    82dc:	d37df021 	lsl	x1, x1, #3
    82e0:	8b010083 	add	x3, x4, x1
    82e4:	f9401062 	ldr	x2, [x3, #32]
    82e8:	b40002a2 	cbz	x2, 833c <fwp_caps12+0xac>
    82ec:	38616881 	ldrb	w1, [x4, x1]
    82f0:	7100083f 	cmp	w1, #0x2
    82f4:	540006c0 	b.eq	83cc <fwp_caps12+0x13c>  // b.none
    82f8:	7100043f 	cmp	w1, #0x1
    82fc:	54000201 	b.ne	833c <fwp_caps12+0xac>  // b.any
    8300:	29430464 	ldp	w4, w1, [x3, #24]
    8304:	92403c00 	and	x0, x0, #0xffff
    8308:	9b047c00 	mul	x0, x0, x4
    830c:	d360fc00 	lsr	x0, x0, #32
    8310:	eb01001f 	cmp	x0, x1
    8314:	54000142 	b.cs	833c <fwp_caps12+0xac>  // b.hs, b.nlast
    8318:	8b000042 	add	x2, x2, x0
    831c:	39400040 	ldrb	w0, [x2]
    8320:	7100041f 	cmp	w0, #0x1
    8324:	540000c1 	b.ne	833c <fwp_caps12+0xac>  // b.any
    8328:	aa1303e0 	mov	x0, x19
    832c:	f9400bf3 	ldr	x19, [sp, #16]
    8330:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8334:	17fff033 	b	4400 <fwp_mem_free>
    8338:	34fffbe1 	cbz	w1, 82b4 <fwp_caps12+0x24>
    833c:	f9400bf3 	ldr	x19, [sp, #16]
    8340:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8344:	d65f03c0 	ret
    8348:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    834c:	91174042 	add	x2, x2, #0x5d0
    8350:	f949d843 	ldr	x3, [x2, #5040]
    8354:	f949ec41 	ldr	x1, [x2, #5080]
    8358:	cb030000 	sub	x0, x0, x3
    835c:	eb01401f 	cmp	x0, x1, lsl #16
    8360:	54fffee2 	b.cs	833c <fwp_caps12+0xac>  // b.hs, b.nlast
    8364:	d350fc01 	lsr	x1, x0, #16
    8368:	f949fc44 	ldr	x4, [x2, #5112]
    836c:	8b010821 	add	x1, x1, x1, lsl #2
    8370:	d37df021 	lsl	x1, x1, #3
    8374:	8b010083 	add	x3, x4, x1
    8378:	f9401062 	ldr	x2, [x3, #32]
    837c:	b4fffe02 	cbz	x2, 833c <fwp_caps12+0xac>
    8380:	38616881 	ldrb	w1, [x4, x1]
    8384:	7100083f 	cmp	w1, #0x2
    8388:	54000280 	b.eq	83d8 <fwp_caps12+0x148>  // b.none
    838c:	7100043f 	cmp	w1, #0x1
    8390:	54fffd61 	b.ne	833c <fwp_caps12+0xac>  // b.any
    8394:	92403c01 	and	x1, x0, #0xffff
    8398:	29430064 	ldp	w4, w0, [x3, #24]
    839c:	9b047c21 	mul	x1, x1, x4
    83a0:	d360fc21 	lsr	x1, x1, #32
    83a4:	eb00003f 	cmp	x1, x0
    83a8:	54fffca2 	b.cs	833c <fwp_caps12+0xac>  // b.hs, b.nlast
    83ac:	8b010042 	add	x2, x2, x1
    83b0:	39400040 	ldrb	w0, [x2]
    83b4:	34fffc40 	cbz	w0, 833c <fwp_caps12+0xac>
    83b8:	7103f41f 	cmp	w0, #0xfd
    83bc:	54000148 	b.hi	83e4 <fwp_caps12+0x154>  // b.pmore
    83c0:	11000400 	add	w0, w0, #0x1
    83c4:	39000040 	strb	w0, [x2]
    83c8:	17ffffdd 	b	833c <fwp_caps12+0xac>
    83cc:	72003c1f 	tst	w0, #0xffff
    83d0:	54fffb61 	b.ne	833c <fwp_caps12+0xac>  // b.any
    83d4:	17ffffd2 	b	831c <fwp_caps12+0x8c>
    83d8:	72003c1f 	tst	w0, #0xffff
    83dc:	54fffb01 	b.ne	833c <fwp_caps12+0xac>  // b.any
    83e0:	17fffff4 	b	83b0 <fwp_caps12+0x120>
    83e4:	f9400bf3 	ldr	x19, [sp, #16]
    83e8:	aa0203e0 	mov	x0, x2
    83ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83f0:	17fff07d 	b	45e4 <fwp_rc_wide_dup>

00000000000083f4 <fwp_drop2>:
    83f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    83f8:	910003fd 	mov	x29, sp
    83fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    8400:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    8404:	911742d5 	add	x21, x22, #0x5d0
    8408:	a90153f3 	stp	x19, x20, [sp, #16]
    840c:	aa0003f3 	mov	x19, x0
    8410:	f949daa1 	ldr	x1, [x21, #5040]
    8414:	f949eea0 	ldr	x0, [x21, #5080]
    8418:	cb010261 	sub	x1, x19, x1
    841c:	eb00403f 	cmp	x1, x0, lsl #16
    8420:	54000382 	b.cs	8490 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8424:	d350fc22 	lsr	x2, x1, #16
    8428:	f949fea3 	ldr	x3, [x21, #5112]
    842c:	8b020842 	add	x2, x2, x2, lsl #2
    8430:	d37df042 	lsl	x2, x2, #3
    8434:	8b020060 	add	x0, x3, x2
    8438:	f9401014 	ldr	x20, [x0, #32]
    843c:	b40002b4 	cbz	x20, 8490 <fwp_drop2+0x9c>
    8440:	38626862 	ldrb	w2, [x3, x2]
    8444:	7100085f 	cmp	w2, #0x2
    8448:	540002c0 	b.eq	84a0 <fwp_drop2+0xac>  // b.none
    844c:	7100045f 	cmp	w2, #0x1
    8450:	54000201 	b.ne	8490 <fwp_drop2+0x9c>  // b.any
    8454:	29430002 	ldp	w2, w0, [x0, #24]
    8458:	92403c21 	and	x1, x1, #0xffff
    845c:	9b027c21 	mul	x1, x1, x2
    8460:	d360fc21 	lsr	x1, x1, #32
    8464:	eb00003f 	cmp	x1, x0
    8468:	54000142 	b.cs	8490 <fwp_drop2+0x9c>  // b.hs, b.nlast
    846c:	8b010294 	add	x20, x20, x1
    8470:	39400280 	ldrb	w0, [x20]
    8474:	340000e0 	cbz	w0, 8490 <fwp_drop2+0x9c>
    8478:	7100041f 	cmp	w0, #0x1
    847c:	540001e0 	b.eq	84b8 <fwp_drop2+0xc4>  // b.none
    8480:	7103fc1f 	cmp	w0, #0xff
    8484:	540007e0 	b.eq	8580 <fwp_drop2+0x18c>  // b.none
    8488:	51000400 	sub	w0, w0, #0x1
    848c:	39000280 	strb	w0, [x20]
    8490:	a94153f3 	ldp	x19, x20, [sp, #16]
    8494:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8498:	a8c37bfd 	ldp	x29, x30, [sp], #48
    849c:	d65f03c0 	ret
    84a0:	72003c3f 	tst	w1, #0xffff
    84a4:	54fffe60 	b.eq	8470 <fwp_drop2+0x7c>  // b.none
    84a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    84ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    84b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    84b4:	d65f03c0 	ret
    84b8:	911742c2 	add	x2, x22, #0x5d0
    84bc:	f9400660 	ldr	x0, [x19, #8]
    84c0:	f949d841 	ldr	x1, [x2, #5040]
    84c4:	f949ec42 	ldr	x2, [x2, #5080]
    84c8:	cb010001 	sub	x1, x0, x1
    84cc:	eb02403f 	cmp	x1, x2, lsl #16
    84d0:	54000382 	b.cs	8540 <fwp_drop2+0x14c>  // b.hs, b.nlast
    84d4:	d350fc22 	lsr	x2, x1, #16
    84d8:	8b020842 	add	x2, x2, x2, lsl #2
    84dc:	d37df042 	lsl	x2, x2, #3
    84e0:	8b020064 	add	x4, x3, x2
    84e4:	f9401094 	ldr	x20, [x4, #32]
    84e8:	b40002d4 	cbz	x20, 8540 <fwp_drop2+0x14c>
    84ec:	38626862 	ldrb	w2, [x3, x2]
    84f0:	7100085f 	cmp	w2, #0x2
    84f4:	54000400 	b.eq	8574 <fwp_drop2+0x180>  // b.none
    84f8:	7100045f 	cmp	w2, #0x1
    84fc:	54000221 	b.ne	8540 <fwp_drop2+0x14c>  // b.any
    8500:	29430883 	ldp	w3, w2, [x4, #24]
    8504:	92403c21 	and	x1, x1, #0xffff
    8508:	9b037c21 	mul	x1, x1, x3
    850c:	d360fc21 	lsr	x1, x1, #32
    8510:	eb02003f 	cmp	x1, x2
    8514:	54000162 	b.cs	8540 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8518:	8b010294 	add	x20, x20, x1
    851c:	39400281 	ldrb	w1, [x20]
    8520:	34000101 	cbz	w1, 8540 <fwp_drop2+0x14c>
    8524:	7100043f 	cmp	w1, #0x1
    8528:	54000220 	b.eq	856c <fwp_drop2+0x178>  // b.none
    852c:	7103fc3f 	cmp	w1, #0xff
    8530:	54000660 	b.eq	85fc <fwp_drop2+0x208>  // b.none
    8534:	51000421 	sub	w1, w1, #0x1
    8538:	39000281 	strb	w1, [x20]
    853c:	d503201f 	nop
    8540:	f9400a74 	ldr	x20, [x19, #16]
    8544:	aa1303e0 	mov	x0, x19
    8548:	97fff596 	bl	5ba0 <fwp_rc_free_arr>
    854c:	911742c0 	add	x0, x22, #0x5d0
    8550:	f949d801 	ldr	x1, [x0, #5040]
    8554:	f949ec00 	ldr	x0, [x0, #5080]
    8558:	cb010281 	sub	x1, x20, x1
    855c:	eb00403f 	cmp	x1, x0, lsl #16
    8560:	54fff982 	b.cs	8490 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8564:	aa1403f3 	mov	x19, x20
    8568:	17ffffaf 	b	8424 <fwp_drop2+0x30>
    856c:	97fff58d 	bl	5ba0 <fwp_rc_free_arr>
    8570:	17fffff4 	b	8540 <fwp_drop2+0x14c>
    8574:	72003c3f 	tst	w1, #0xffff
    8578:	54fffe41 	b.ne	8540 <fwp_drop2+0x14c>  // b.any
    857c:	17ffffe8 	b	851c <fwp_drop2+0x128>
    8580:	ca544681 	eor	x1, x20, x20, lsr #17
    8584:	911742c0 	add	x0, x22, #0x5d0
    8588:	ca412421 	eor	x1, x1, x1, lsr #9
    858c:	92401c21 	and	x1, x1, #0xff
    8590:	910a2422 	add	x2, x1, #0x289
    8594:	8b010c01 	add	x1, x0, x1, lsl #3
    8598:	8b020c02 	add	x2, x0, x2, lsl #3
    859c:	f94a2420 	ldr	x0, [x1, #5192]
    85a0:	b50000a0 	cbnz	x0, 85b4 <fwp_drop2+0x1c0>
    85a4:	14000013 	b	85f0 <fwp_drop2+0x1fc>
    85a8:	91004002 	add	x2, x0, #0x10
    85ac:	f9400800 	ldr	x0, [x0, #16]
    85b0:	b4000200 	cbz	x0, 85f0 <fwp_drop2+0x1fc>
    85b4:	f9400001 	ldr	x1, [x0]
    85b8:	eb14003f 	cmp	x1, x20
    85bc:	54ffff61 	b.ne	85a8 <fwp_drop2+0x1b4>  // b.any
    85c0:	f9400041 	ldr	x1, [x2]
    85c4:	f9400420 	ldr	x0, [x1, #8]
    85c8:	d1000400 	sub	x0, x0, #0x1
    85cc:	f9000420 	str	x0, [x1, #8]
    85d0:	f103f81f 	cmp	x0, #0xfe
    85d4:	54fff5e1 	b.ne	8490 <fwp_drop2+0x9c>  // b.any
    85d8:	39400280 	ldrb	w0, [x20]
    85dc:	7103fc1f 	cmp	w0, #0xff
    85e0:	54000460 	b.eq	866c <fwp_drop2+0x278>  // b.none
    85e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    85e8:	39000280 	strb	w0, [x20]
    85ec:	17ffffa9 	b	8490 <fwp_drop2+0x9c>
    85f0:	f0000000 	adrp	x0, b000 <__modti3+0x280>
    85f4:	910c6000 	add	x0, x0, #0x318
    85f8:	97ffeec6 	bl	4110 <fwp_trap>
    85fc:	ca544680 	eor	x0, x20, x20, lsr #17
    8600:	911742c1 	add	x1, x22, #0x5d0
    8604:	ca402400 	eor	x0, x0, x0, lsr #9
    8608:	92401c00 	and	x0, x0, #0xff
    860c:	910a2402 	add	x2, x0, #0x289
    8610:	8b000c20 	add	x0, x1, x0, lsl #3
    8614:	8b020c22 	add	x2, x1, x2, lsl #3
    8618:	f94a2400 	ldr	x0, [x0, #5192]
    861c:	b50000a0 	cbnz	x0, 8630 <fwp_drop2+0x23c>
    8620:	17fffff4 	b	85f0 <fwp_drop2+0x1fc>
    8624:	91004002 	add	x2, x0, #0x10
    8628:	f9400800 	ldr	x0, [x0, #16]
    862c:	b4fffe20 	cbz	x0, 85f0 <fwp_drop2+0x1fc>
    8630:	f9400001 	ldr	x1, [x0]
    8634:	eb14003f 	cmp	x1, x20
    8638:	54ffff61 	b.ne	8624 <fwp_drop2+0x230>  // b.any
    863c:	f9400041 	ldr	x1, [x2]
    8640:	f9400420 	ldr	x0, [x1, #8]
    8644:	d1000400 	sub	x0, x0, #0x1
    8648:	f9000420 	str	x0, [x1, #8]
    864c:	f103f81f 	cmp	x0, #0xfe
    8650:	54fff781 	b.ne	8540 <fwp_drop2+0x14c>  // b.any
    8654:	39400280 	ldrb	w0, [x20]
    8658:	7103fc1f 	cmp	w0, #0xff
    865c:	540000e0 	b.eq	8678 <fwp_drop2+0x284>  // b.none
    8660:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8664:	39000280 	strb	w0, [x20]
    8668:	17ffffb6 	b	8540 <fwp_drop2+0x14c>
    866c:	aa1403e0 	mov	x0, x20
    8670:	97ffeec8 	bl	4190 <fwp_rc_forget_slot.part.0>
    8674:	17ffffdc 	b	85e4 <fwp_drop2+0x1f0>
    8678:	aa1403e0 	mov	x0, x20
    867c:	97ffeec5 	bl	4190 <fwp_rc_forget_slot.part.0>
    8680:	17fffff8 	b	8660 <fwp_drop2+0x26c>

0000000000008684 <fwp_arg_drop23>:
    8684:	7100003f 	cmp	w1, #0x0
    8688:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    868c:	54000041 	b.ne	8694 <fwp_arg_drop23+0x10>  // b.any
    8690:	d65f03c0 	ret
    8694:	f9400000 	ldr	x0, [x0]
    8698:	17ffff57 	b	83f4 <fwp_drop2>
    869c:	d503201f 	nop

00000000000086a0 <fwp_caps23>:
    86a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    86a4:	910003fd 	mov	x29, sp
    86a8:	f9000bf3 	str	x19, [sp, #16]
    86ac:	aa0003f3 	mov	x19, x0
    86b0:	b9400400 	ldr	w0, [x0, #4]
    86b4:	340004a0 	cbz	w0, 8748 <fwp_caps23+0xa8>
    86b8:	f9400660 	ldr	x0, [x19, #8]
    86bc:	350004e1 	cbnz	w1, 8758 <fwp_caps23+0xb8>
    86c0:	97ffff4d 	bl	83f4 <fwp_drop2>
    86c4:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    86c8:	91174042 	add	x2, x2, #0x5d0
    86cc:	f949d840 	ldr	x0, [x2, #5040]
    86d0:	f949ec41 	ldr	x1, [x2, #5080]
    86d4:	cb000260 	sub	x0, x19, x0
    86d8:	eb01401f 	cmp	x0, x1, lsl #16
    86dc:	54000382 	b.cs	874c <fwp_caps23+0xac>  // b.hs, b.nlast
    86e0:	d350fc01 	lsr	x1, x0, #16
    86e4:	f949fc44 	ldr	x4, [x2, #5112]
    86e8:	8b010821 	add	x1, x1, x1, lsl #2
    86ec:	d37df021 	lsl	x1, x1, #3
    86f0:	8b010083 	add	x3, x4, x1
    86f4:	f9401062 	ldr	x2, [x3, #32]
    86f8:	b40002a2 	cbz	x2, 874c <fwp_caps23+0xac>
    86fc:	38616881 	ldrb	w1, [x4, x1]
    8700:	7100083f 	cmp	w1, #0x2
    8704:	540006c0 	b.eq	87dc <fwp_caps23+0x13c>  // b.none
    8708:	7100043f 	cmp	w1, #0x1
    870c:	54000201 	b.ne	874c <fwp_caps23+0xac>  // b.any
    8710:	29430464 	ldp	w4, w1, [x3, #24]
    8714:	92403c00 	and	x0, x0, #0xffff
    8718:	9b047c00 	mul	x0, x0, x4
    871c:	d360fc00 	lsr	x0, x0, #32
    8720:	eb01001f 	cmp	x0, x1
    8724:	54000142 	b.cs	874c <fwp_caps23+0xac>  // b.hs, b.nlast
    8728:	8b000042 	add	x2, x2, x0
    872c:	39400040 	ldrb	w0, [x2]
    8730:	7100041f 	cmp	w0, #0x1
    8734:	540000c1 	b.ne	874c <fwp_caps23+0xac>  // b.any
    8738:	aa1303e0 	mov	x0, x19
    873c:	f9400bf3 	ldr	x19, [sp, #16]
    8740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8744:	17ffef2f 	b	4400 <fwp_mem_free>
    8748:	34fffbe1 	cbz	w1, 86c4 <fwp_caps23+0x24>
    874c:	f9400bf3 	ldr	x19, [sp, #16]
    8750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8754:	d65f03c0 	ret
    8758:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    875c:	91174042 	add	x2, x2, #0x5d0
    8760:	f949d843 	ldr	x3, [x2, #5040]
    8764:	f949ec41 	ldr	x1, [x2, #5080]
    8768:	cb030000 	sub	x0, x0, x3
    876c:	eb01401f 	cmp	x0, x1, lsl #16
    8770:	54fffee2 	b.cs	874c <fwp_caps23+0xac>  // b.hs, b.nlast
    8774:	d350fc01 	lsr	x1, x0, #16
    8778:	f949fc44 	ldr	x4, [x2, #5112]
    877c:	8b010821 	add	x1, x1, x1, lsl #2
    8780:	d37df021 	lsl	x1, x1, #3
    8784:	8b010083 	add	x3, x4, x1
    8788:	f9401062 	ldr	x2, [x3, #32]
    878c:	b4fffe02 	cbz	x2, 874c <fwp_caps23+0xac>
    8790:	38616881 	ldrb	w1, [x4, x1]
    8794:	7100083f 	cmp	w1, #0x2
    8798:	54000280 	b.eq	87e8 <fwp_caps23+0x148>  // b.none
    879c:	7100043f 	cmp	w1, #0x1
    87a0:	54fffd61 	b.ne	874c <fwp_caps23+0xac>  // b.any
    87a4:	92403c01 	and	x1, x0, #0xffff
    87a8:	29430064 	ldp	w4, w0, [x3, #24]
    87ac:	9b047c21 	mul	x1, x1, x4
    87b0:	d360fc21 	lsr	x1, x1, #32
    87b4:	eb00003f 	cmp	x1, x0
    87b8:	54fffca2 	b.cs	874c <fwp_caps23+0xac>  // b.hs, b.nlast
    87bc:	8b010042 	add	x2, x2, x1
    87c0:	39400040 	ldrb	w0, [x2]
    87c4:	34fffc40 	cbz	w0, 874c <fwp_caps23+0xac>
    87c8:	7103f41f 	cmp	w0, #0xfd
    87cc:	54000148 	b.hi	87f4 <fwp_caps23+0x154>  // b.pmore
    87d0:	11000400 	add	w0, w0, #0x1
    87d4:	39000040 	strb	w0, [x2]
    87d8:	17ffffdd 	b	874c <fwp_caps23+0xac>
    87dc:	72003c1f 	tst	w0, #0xffff
    87e0:	54fffb61 	b.ne	874c <fwp_caps23+0xac>  // b.any
    87e4:	17ffffd2 	b	872c <fwp_caps23+0x8c>
    87e8:	72003c1f 	tst	w0, #0xffff
    87ec:	54fffb01 	b.ne	874c <fwp_caps23+0xac>  // b.any
    87f0:	17fffff4 	b	87c0 <fwp_caps23+0x120>
    87f4:	f9400bf3 	ldr	x19, [sp, #16]
    87f8:	aa0203e0 	mov	x0, x2
    87fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8800:	17ffef79 	b	45e4 <fwp_rc_wide_dup>

0000000000008804 <f23>:
    8804:	d10203ff 	sub	sp, sp, #0x80
    8808:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    880c:	f947f421 	ldr	x1, [x1, #4072]
    8810:	a9027bfd 	stp	x29, x30, [sp, #32]
    8814:	910083fd 	add	x29, sp, #0x20
    8818:	a9045bf5 	stp	x21, x22, [sp, #64]
    881c:	b0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    8820:	911742a3 	add	x3, x21, #0x5d0
    8824:	a90353f3 	stp	x19, x20, [sp, #48]
    8828:	aa0003f6 	mov	x22, x0
    882c:	a90563f7 	stp	x23, x24, [sp, #80]
    8830:	a9066bf9 	stp	x25, x26, [sp, #96]
    8834:	f949ec62 	ldr	x2, [x3, #5080]
    8838:	f9400024 	ldr	x4, [x1]
    883c:	f9000fe4 	str	x4, [sp, #24]
    8840:	d2800004 	mov	x4, #0x0                   	// #0
    8844:	f949d861 	ldr	x1, [x3, #5040]
    8848:	d370bc42 	lsl	x2, x2, #16
    884c:	b4001800 	cbz	x0, 8b4c <f23+0x348>
    8850:	f9400817 	ldr	x23, [x0, #16]
    8854:	cb0102e1 	sub	x1, x23, x1
    8858:	eb02003f 	cmp	x1, x2
    885c:	54000362 	b.cs	88c8 <f23+0xc4>  // b.hs, b.nlast
    8860:	f949fc60 	ldr	x0, [x3, #5112]
    8864:	d350fc22 	lsr	x2, x1, #16
    8868:	8b020842 	add	x2, x2, x2, lsl #2
    886c:	8b020c02 	add	x2, x0, x2, lsl #3
    8870:	f9401040 	ldr	x0, [x2, #32]
    8874:	b40002a0 	cbz	x0, 88c8 <f23+0xc4>
    8878:	39400043 	ldrb	w3, [x2]
    887c:	7100087f 	cmp	w3, #0x2
    8880:	54001540 	b.eq	8b28 <f23+0x324>  // b.none
    8884:	7100047f 	cmp	w3, #0x1
    8888:	540001c1 	b.ne	88c0 <f23+0xbc>  // b.any
    888c:	29430843 	ldp	w3, w2, [x2, #24]
    8890:	92403c21 	and	x1, x1, #0xffff
    8894:	9b037c21 	mul	x1, x1, x3
    8898:	d360fc21 	lsr	x1, x1, #32
    889c:	eb02003f 	cmp	x1, x2
    88a0:	54000102 	b.cs	88c0 <f23+0xbc>  // b.hs, b.nlast
    88a4:	8b010000 	add	x0, x0, x1
    88a8:	39400001 	ldrb	w1, [x0]
    88ac:	340000a1 	cbz	w1, 88c0 <f23+0xbc>
    88b0:	7103f43f 	cmp	w1, #0xfd
    88b4:	540017e8 	b.hi	8bb0 <f23+0x3ac>  // b.pmore
    88b8:	11000421 	add	w1, w1, #0x1
    88bc:	39000001 	strb	w1, [x0]
    88c0:	d2800002 	mov	x2, #0x0                   	// #0
    88c4:	b40000d6 	cbz	x22, 88dc <f23+0xd8>
    88c8:	aa1603e1 	mov	x1, x22
    88cc:	d2800002 	mov	x2, #0x0                   	// #0
    88d0:	f9400821 	ldr	x1, [x1, #16]
    88d4:	91000442 	add	x2, x2, #0x1
    88d8:	b5ffffc1 	cbnz	x1, 88d0 <f23+0xcc>
    88dc:	b40013f7 	cbz	x23, 8b58 <f23+0x354>
    88e0:	aa1703e1 	mov	x1, x23
    88e4:	d2800003 	mov	x3, #0x0                   	// #0
    88e8:	f9400821 	ldr	x1, [x1, #16]
    88ec:	91000463 	add	x3, x3, #0x1
    88f0:	b5ffffc1 	cbnz	x1, 88e8 <f23+0xe4>
    88f4:	eb02007f 	cmp	x3, x2
    88f8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    88fc:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    8900:	eb00027f 	cmp	x19, x0
    8904:	540010a8 	b.hi	8b18 <f23+0x314>  // b.pmore
    8908:	d37ffa74 	lsl	x20, x19, #1
    890c:	52800041 	mov	w1, #0x2                   	// #2
    8910:	91000680 	add	x0, x20, #0x1
    8914:	d37df000 	lsl	x0, x0, #3
    8918:	97fff176 	bl	4ef0 <fwp_heap_alloc>
    891c:	aa0003f8 	mov	x24, x0
    8920:	911742a1 	add	x1, x21, #0x5d0
    8924:	aa0103e0 	mov	x0, x1
    8928:	f9000314 	str	x20, [x24]
    892c:	f949d821 	ldr	x1, [x1, #5040]
    8930:	f949ec00 	ldr	x0, [x0, #5080]
    8934:	cb010301 	sub	x1, x24, x1
    8938:	eb00403f 	cmp	x1, x0, lsl #16
    893c:	54000342 	b.cs	89a4 <f23+0x1a0>  // b.hs, b.nlast
    8940:	911742a2 	add	x2, x21, #0x5d0
    8944:	d350fc20 	lsr	x0, x1, #16
    8948:	8b000800 	add	x0, x0, x0, lsl #2
    894c:	f949fc43 	ldr	x3, [x2, #5112]
    8950:	d37df002 	lsl	x2, x0, #3
    8954:	8b020060 	add	x0, x3, x2
    8958:	f9401014 	ldr	x20, [x0, #32]
    895c:	b4000254 	cbz	x20, 89a4 <f23+0x1a0>
    8960:	38626862 	ldrb	w2, [x3, x2]
    8964:	7100085f 	cmp	w2, #0x2
    8968:	54000ec0 	b.eq	8b40 <f23+0x33c>  // b.none
    896c:	7100045f 	cmp	w2, #0x1
    8970:	540001a1 	b.ne	89a4 <f23+0x1a0>  // b.any
    8974:	29430002 	ldp	w2, w0, [x0, #24]
    8978:	92403c21 	and	x1, x1, #0xffff
    897c:	9b027c21 	mul	x1, x1, x2
    8980:	d360fc21 	lsr	x1, x1, #32
    8984:	eb00003f 	cmp	x1, x0
    8988:	540000e2 	b.cs	89a4 <f23+0x1a0>  // b.hs, b.nlast
    898c:	8b010294 	add	x20, x20, x1
    8990:	39400280 	ldrb	w0, [x20]
    8994:	7103fc1f 	cmp	w0, #0xff
    8998:	54001100 	b.eq	8bb8 <f23+0x3b4>  // b.none
    899c:	52800020 	mov	w0, #0x1                   	// #1
    89a0:	39000280 	strb	w0, [x20]
    89a4:	b4000253 	cbz	x19, 89ec <f23+0x1e8>
    89a8:	8b131313 	add	x19, x24, x19, lsl #4
    89ac:	aa1803f4 	mov	x20, x24
    89b0:	aa1603fa 	mov	x26, x22
    89b4:	aa1703f9 	mov	x25, x23
    89b8:	f9400723 	ldr	x3, [x25, #8]
    89bc:	f9400742 	ldr	x2, [x26, #8]
    89c0:	f9400861 	ldr	x1, [x3, #16]
    89c4:	f9400840 	ldr	x0, [x2, #16]
    89c8:	fd400461 	ldr	d1, [x3, #8]
    89cc:	fd400440 	ldr	d0, [x2, #8]
    89d0:	97fff2f5 	bl	55a4 <w107>
    89d4:	f9000680 	str	x0, [x20, #8]
    89d8:	f8010e81 	str	x1, [x20, #16]!
    89dc:	f9400b39 	ldr	x25, [x25, #16]
    89e0:	f9400b5a 	ldr	x26, [x26, #16]
    89e4:	eb14027f 	cmp	x19, x20
    89e8:	54fffe81 	b.ne	89b8 <f23+0x1b4>  // b.any
    89ec:	aa1703e0 	mov	x0, x23
    89f0:	97fffe81 	bl	83f4 <fwp_drop2>
    89f4:	aa1603e0 	mov	x0, x22
    89f8:	97fffe7f 	bl	83f4 <fwp_drop2>
    89fc:	f9400316 	ldr	x22, [x24]
    8a00:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8a04:	b4000236 	cbz	x22, 8a48 <f23+0x244>
    8a08:	fd003be8 	str	d8, [sp, #112]
    8a0c:	2f00e408 	movi	d8, #0x0
    8a10:	91002319 	add	x25, x24, #0x8
    8a14:	91004317 	add	x23, x24, #0x10
    8a18:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    8a1c:	d2800013 	mov	x19, #0x0                   	// #0
    8a20:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8a24:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    8a28:	91000a73 	add	x19, x19, #0x2
    8a2c:	1e602908 	fadd	d8, d8, d0
    8a30:	97fff28c 	bl	5460 <f128.constprop.0>
    8a34:	aa0003f4 	mov	x20, x0
    8a38:	eb1302df 	cmp	x22, x19
    8a3c:	54ffff28 	b.hi	8a20 <f23+0x21c>  // b.pmore
    8a40:	9e660116 	fmov	x22, d8
    8a44:	fd403be8 	ldr	d8, [sp, #112]
    8a48:	911742b5 	add	x21, x21, #0x5d0
    8a4c:	aa1803e0 	mov	x0, x24
    8a50:	97fff890 	bl	6c90 <fwp_drop4>
    8a54:	a900d3f6 	stp	x22, x20, [sp, #8]
    8a58:	910023e1 	add	x1, sp, #0x8
    8a5c:	52800000 	mov	w0, #0x0                   	// #0
    8a60:	97fff3e4 	bl	59f0 <fwp_data.part.0.constprop.0>
    8a64:	f949daa1 	ldr	x1, [x21, #5040]
    8a68:	aa0003f3 	mov	x19, x0
    8a6c:	f949eea0 	ldr	x0, [x21, #5080]
    8a70:	cb010261 	sub	x1, x19, x1
    8a74:	eb00403f 	cmp	x1, x0, lsl #16
    8a78:	54000322 	b.cs	8adc <f23+0x2d8>  // b.hs, b.nlast
    8a7c:	d350fc22 	lsr	x2, x1, #16
    8a80:	f949fea3 	ldr	x3, [x21, #5112]
    8a84:	8b020842 	add	x2, x2, x2, lsl #2
    8a88:	d37df042 	lsl	x2, x2, #3
    8a8c:	8b020060 	add	x0, x3, x2
    8a90:	f9401014 	ldr	x20, [x0, #32]
    8a94:	b4000254 	cbz	x20, 8adc <f23+0x2d8>
    8a98:	38626862 	ldrb	w2, [x3, x2]
    8a9c:	7100085f 	cmp	w2, #0x2
    8aa0:	540004a0 	b.eq	8b34 <f23+0x330>  // b.none
    8aa4:	7100045f 	cmp	w2, #0x1
    8aa8:	540001a1 	b.ne	8adc <f23+0x2d8>  // b.any
    8aac:	29430002 	ldp	w2, w0, [x0, #24]
    8ab0:	92403c21 	and	x1, x1, #0xffff
    8ab4:	9b027c21 	mul	x1, x1, x2
    8ab8:	d360fc21 	lsr	x1, x1, #32
    8abc:	eb00003f 	cmp	x1, x0
    8ac0:	540000e2 	b.cs	8adc <f23+0x2d8>  // b.hs, b.nlast
    8ac4:	8b010294 	add	x20, x20, x1
    8ac8:	39400280 	ldrb	w0, [x20]
    8acc:	7103fc1f 	cmp	w0, #0xff
    8ad0:	540007a0 	b.eq	8bc4 <f23+0x3c0>  // b.none
    8ad4:	52800020 	mov	w0, #0x1                   	// #1
    8ad8:	39000280 	strb	w0, [x20]
    8adc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ae0:	f947f400 	ldr	x0, [x0, #4072]
    8ae4:	f9400fe2 	ldr	x2, [sp, #24]
    8ae8:	f9400001 	ldr	x1, [x0]
    8aec:	eb010042 	subs	x2, x2, x1
    8af0:	d2800001 	mov	x1, #0x0                   	// #0
    8af4:	54000721 	b.ne	8bd8 <f23+0x3d4>  // b.any
    8af8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8afc:	aa1303e0 	mov	x0, x19
    8b00:	a94353f3 	ldp	x19, x20, [sp, #48]
    8b04:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8b08:	a94563f7 	ldp	x23, x24, [sp, #80]
    8b0c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8b10:	910203ff 	add	sp, sp, #0x80
    8b14:	d65f03c0 	ret
    8b18:	f0000000 	adrp	x0, b000 <__modti3+0x280>
    8b1c:	91190000 	add	x0, x0, #0x640
    8b20:	fd003be8 	str	d8, [sp, #112]
    8b24:	97ffed7b 	bl	4110 <fwp_trap>
    8b28:	72003c3f 	tst	w1, #0xffff
    8b2c:	54ffeca1 	b.ne	88c0 <f23+0xbc>  // b.any
    8b30:	17ffff5e 	b	88a8 <f23+0xa4>
    8b34:	72003c3f 	tst	w1, #0xffff
    8b38:	54fffd21 	b.ne	8adc <f23+0x2d8>  // b.any
    8b3c:	17ffffe3 	b	8ac8 <f23+0x2c4>
    8b40:	72003c3f 	tst	w1, #0xffff
    8b44:	54fff301 	b.ne	89a4 <f23+0x1a0>  // b.any
    8b48:	17ffff92 	b	8990 <f23+0x18c>
    8b4c:	cb0103e1 	neg	x1, x1
    8b50:	eb02003f 	cmp	x1, x2
    8b54:	540001e3 	b.cc	8b90 <f23+0x38c>  // b.lo, b.ul, b.last
    8b58:	52800041 	mov	w1, #0x2                   	// #2
    8b5c:	d2800100 	mov	x0, #0x8                   	// #8
    8b60:	97fff0e4 	bl	4ef0 <fwp_heap_alloc>
    8b64:	aa0003f8 	mov	x24, x0
    8b68:	911742a0 	add	x0, x21, #0x5d0
    8b6c:	f900031f 	str	xzr, [x24]
    8b70:	f949d801 	ldr	x1, [x0, #5040]
    8b74:	f949ec00 	ldr	x0, [x0, #5080]
    8b78:	cb010301 	sub	x1, x24, x1
    8b7c:	eb00403f 	cmp	x1, x0, lsl #16
    8b80:	54000282 	b.cs	8bd0 <f23+0x3cc>  // b.hs, b.nlast
    8b84:	d2800013 	mov	x19, #0x0                   	// #0
    8b88:	d2800017 	mov	x23, #0x0                   	// #0
    8b8c:	17ffff6d 	b	8940 <f23+0x13c>
    8b90:	f949fc62 	ldr	x2, [x3, #5112]
    8b94:	d350fc20 	lsr	x0, x1, #16
    8b98:	8b000800 	add	x0, x0, x0, lsl #2
    8b9c:	8b000c42 	add	x2, x2, x0, lsl #3
    8ba0:	f9401040 	ldr	x0, [x2, #32]
    8ba4:	b4fffda0 	cbz	x0, 8b58 <f23+0x354>
    8ba8:	d2800017 	mov	x23, #0x0                   	// #0
    8bac:	17ffff33 	b	8878 <f23+0x74>
    8bb0:	97ffee8d 	bl	45e4 <fwp_rc_wide_dup>
    8bb4:	17ffff43 	b	88c0 <f23+0xbc>
    8bb8:	aa1403e0 	mov	x0, x20
    8bbc:	97ffed75 	bl	4190 <fwp_rc_forget_slot.part.0>
    8bc0:	17ffff77 	b	899c <f23+0x198>
    8bc4:	aa1403e0 	mov	x0, x20
    8bc8:	97ffed72 	bl	4190 <fwp_rc_forget_slot.part.0>
    8bcc:	17ffffc2 	b	8ad4 <f23+0x2d0>
    8bd0:	d2800017 	mov	x23, #0x0                   	// #0
    8bd4:	17ffff86 	b	89ec <f23+0x1e8>
    8bd8:	fd003be8 	str	d8, [sp, #112]
    8bdc:	97ffe729 	bl	2880 <__stack_chk_fail@plt>

0000000000008be0 <fwp_owned_entry23>:
    8be0:	f9400000 	ldr	x0, [x0]
    8be4:	17ffff08 	b	8804 <f23>
    8be8:	d503201f 	nop
    8bec:	d503201f 	nop

0000000000008bf0 <e23>:
    8bf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8bf4:	910003fd 	mov	x29, sp
    8bf8:	f9000bf3 	str	x19, [sp, #16]
    8bfc:	f9400013 	ldr	x19, [x0]
    8c00:	aa1303e0 	mov	x0, x19
    8c04:	97fff3c3 	bl	5b10 <fwp_rc_share>
    8c08:	aa1303e0 	mov	x0, x19
    8c0c:	97fffefe 	bl	8804 <f23>
    8c10:	aa0003f3 	mov	x19, x0
    8c14:	97fff3bf 	bl	5b10 <fwp_rc_share>
    8c18:	aa1303e0 	mov	x0, x19
    8c1c:	f9400bf3 	ldr	x19, [sp, #16]
    8c20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8c24:	d65f03c0 	ret
    8c28:	d503201f 	nop
    8c2c:	d503201f 	nop

0000000000008c30 <fwp_write>:
    8c30:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8c34:	910003fd 	mov	x29, sp
    8c38:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    8c3c:	f947f484 	ldr	x4, [x4, #4072]
    8c40:	a90153f3 	stp	x19, x20, [sp, #16]
    8c44:	d10943ff 	sub	sp, sp, #0x250
    8c48:	b9400045 	ldr	w5, [x2]
    8c4c:	aa0003f4 	mov	x20, x0
    8c50:	f9400080 	ldr	x0, [x4]
    8c54:	f90127e0 	str	x0, [sp, #584]
    8c58:	d2800000 	mov	x0, #0x0                   	// #0
    8c5c:	710064bf 	cmp	w5, #0x19
    8c60:	54000408 	b.hi	8ce0 <fwp_write+0xb0>  // b.pmore
    8c64:	f0000000 	adrp	x0, b000 <__modti3+0x280>
    8c68:	aa0103f3 	mov	x19, x1
    8c6c:	9139c000 	add	x0, x0, #0xe70
    8c70:	f9013bf5 	str	x21, [sp, #624]
    8c74:	f9013ff6 	str	x22, [sp, #632]
    8c78:	f90153fb 	str	x27, [sp, #672]
    8c7c:	f90157fc 	str	x28, [sp, #680]
    8c80:	aa0203fc 	mov	x28, x2
    8c84:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8c88:	10000061 	adr	x1, 8c94 <fwp_write+0x64>
    8c8c:	8b20a820 	add	x0, x1, w0, sxth #2
    8c90:	d61f0000 	br	x0
    8c94:	910123e0 	add	x0, sp, #0x48
    8c98:	aa1303e5 	mov	x5, x19
    8c9c:	f0000004 	adrp	x4, b000 <__modti3+0x280>
    8ca0:	aa0003f3 	mov	x19, x0
    8ca4:	911b0084 	add	x4, x4, #0x6c0
    8ca8:	d2804003 	mov	x3, #0x200                 	// #512
    8cac:	aa0303e1 	mov	x1, x3
    8cb0:	52800042 	mov	w2, #0x2                   	// #2
    8cb4:	97ffe6cf 	bl	27f0 <__snprintf_chk@plt>
    8cb8:	aa1303e0 	mov	x0, x19
    8cbc:	97ffe695 	bl	2710 <strlen@plt>
    8cc0:	aa1303e1 	mov	x1, x19
    8cc4:	aa0003e2 	mov	x2, x0
    8cc8:	aa1403e0 	mov	x0, x20
    8ccc:	97ffea31 	bl	3590 <buf_put>
    8cd0:	f9413bf5 	ldr	x21, [sp, #624]
    8cd4:	f9413ff6 	ldr	x22, [sp, #632]
    8cd8:	f94153fb 	ldr	x27, [sp, #672]
    8cdc:	f94157fc 	ldr	x28, [sp, #680]
    8ce0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ce4:	f947f400 	ldr	x0, [x0, #4072]
    8ce8:	f94127e2 	ldr	x2, [sp, #584]
    8cec:	f9400001 	ldr	x1, [x0]
    8cf0:	eb010042 	subs	x2, x2, x1
    8cf4:	d2800001 	mov	x1, #0x0                   	// #0
    8cf8:	540077c1 	b.ne	9bf0 <fwp_write+0xfc0>  // b.any
    8cfc:	910943ff 	add	sp, sp, #0x250
    8d00:	a94153f3 	ldp	x19, x20, [sp, #16]
    8d04:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8d08:	d65f03c0 	ret
    8d0c:	910123e0 	add	x0, sp, #0x48
    8d10:	aa1303e5 	mov	x5, x19
    8d14:	f0000004 	adrp	x4, b000 <__modti3+0x280>
    8d18:	aa0003f3 	mov	x19, x0
    8d1c:	911ae084 	add	x4, x4, #0x6b8
    8d20:	d2804003 	mov	x3, #0x200                 	// #512
    8d24:	17ffffe2 	b	8cac <fwp_write+0x7c>
    8d28:	71004cbf 	cmp	w5, #0x13
    8d2c:	f0000000 	adrp	x0, b000 <__modti3+0x280>
    8d30:	f0000001 	adrp	x1, b000 <__modti3+0x280>
    8d34:	911aa000 	add	x0, x0, #0x6a8
    8d38:	911ac021 	add	x1, x1, #0x6b0
    8d3c:	d2800082 	mov	x2, #0x4                   	// #4
    8d40:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8d44:	aa1403e0 	mov	x0, x20
    8d48:	f90143f7 	str	x23, [sp, #640]
    8d4c:	d2800016 	mov	x22, #0x0                   	// #0
    8d50:	f90147f8 	str	x24, [sp, #648]
    8d54:	97ffea0f 	bl	3590 <buf_put>
    8d58:	f9400260 	ldr	x0, [x19]
    8d5c:	f0000017 	adrp	x23, b000 <__modti3+0x280>
    8d60:	d2800015 	mov	x21, #0x0                   	// #0
    8d64:	911cc2f7 	add	x23, x23, #0x730
    8d68:	b40047a0 	cbz	x0, 965c <fwp_write+0xa2c>
    8d6c:	b9400380 	ldr	w0, [x28]
    8d70:	52800003 	mov	w3, #0x0                   	// #0
    8d74:	f9401f82 	ldr	x2, [x28, #56]
    8d78:	71004c1f 	cmp	w0, #0x13
    8d7c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8d80:	aa1403e0 	mov	x0, x20
    8d84:	8b010e61 	add	x1, x19, x1, lsl #3
    8d88:	f9400421 	ldr	x1, [x1, #8]
    8d8c:	97ffffa9 	bl	8c30 <fwp_write>
    8d90:	b9400380 	ldr	w0, [x28]
    8d94:	7100481f 	cmp	w0, #0x12
    8d98:	54004b40 	b.eq	9700 <fwp_write+0xad0>  // b.none
    8d9c:	f9400260 	ldr	x0, [x19]
    8da0:	910006b5 	add	x21, x21, #0x1
    8da4:	91000ad6 	add	x22, x22, #0x2
    8da8:	eb15001f 	cmp	x0, x21
    8dac:	54004589 	b.ls	965c <fwp_write+0xa2c>  // b.plast
    8db0:	aa1703e1 	mov	x1, x23
    8db4:	aa1403e0 	mov	x0, x20
    8db8:	d2800042 	mov	x2, #0x2                   	// #2
    8dbc:	97ffe9f5 	bl	3590 <buf_put>
    8dc0:	17ffffeb 	b	8d6c <fwp_write+0x13c>
    8dc4:	f0000001 	adrp	x1, b000 <__modti3+0x280>
    8dc8:	911ba021 	add	x1, x1, #0x6e8
    8dcc:	d28000c2 	mov	x2, #0x6                   	// #6
    8dd0:	aa1403e0 	mov	x0, x20
    8dd4:	91004273 	add	x19, x19, #0x10
    8dd8:	97ffe9ee 	bl	3590 <buf_put>
    8ddc:	aa1303e0 	mov	x0, x19
    8de0:	97ffe64c 	bl	2710 <strlen@plt>
    8de4:	aa1303e1 	mov	x1, x19
    8de8:	aa0003e2 	mov	x2, x0
    8dec:	aa1403e0 	mov	x0, x20
    8df0:	97ffe9e8 	bl	3590 <buf_put>
    8df4:	528007c3 	mov	w3, #0x3e                  	// #62
    8df8:	aa1403e0 	mov	x0, x20
    8dfc:	91001fe1 	add	x1, sp, #0x7
    8e00:	d2800022 	mov	x2, #0x1                   	// #1
    8e04:	39001fe3 	strb	w3, [sp, #7]
    8e08:	17ffffb1 	b	8ccc <fwp_write+0x9c>
    8e0c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8e10:	f947f400 	ldr	x0, [x0, #4072]
    8e14:	f94127e2 	ldr	x2, [sp, #584]
    8e18:	f9400001 	ldr	x1, [x0]
    8e1c:	eb010042 	subs	x2, x2, x1
    8e20:	d2800001 	mov	x1, #0x0                   	// #0
    8e24:	540034e1 	b.ne	94c0 <fwp_write+0x890>  // b.any
    8e28:	f9413bf5 	ldr	x21, [sp, #624]
    8e2c:	f0000001 	adrp	x1, b000 <__modti3+0x280>
    8e30:	f9413ff6 	ldr	x22, [sp, #632]
    8e34:	aa1403e0 	mov	x0, x20
    8e38:	911b2021 	add	x1, x1, #0x6c8
    8e3c:	d2800142 	mov	x2, #0xa                   	// #10
    8e40:	f94153fb 	ldr	x27, [sp, #672]
    8e44:	f94157fc 	ldr	x28, [sp, #680]
    8e48:	910943ff 	add	sp, sp, #0x250
    8e4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8e50:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8e54:	17ffe9cf 	b	3590 <buf_put>
    8e58:	f9400456 	ldr	x22, [x2, #8]
    8e5c:	f90143f7 	str	x23, [sp, #640]
    8e60:	f90147f8 	str	x24, [sp, #648]
    8e64:	b4005b16 	cbz	x22, 99c4 <fwp_write+0xd94>
    8e68:	aa1603e0 	mov	x0, x22
    8e6c:	f0000001 	adrp	x1, b000 <__modti3+0x280>
    8e70:	911d2021 	add	x1, x1, #0x748
    8e74:	97ffe6a3 	bl	2900 <strcmp@plt>
    8e78:	2a0003f5 	mov	w21, w0
    8e7c:	34005fe0 	cbz	w0, 9a78 <fwp_write+0xe48>
    8e80:	aa1603e0 	mov	x0, x22
    8e84:	97ffe623 	bl	2710 <strlen@plt>
    8e88:	aa1603e1 	mov	x1, x22
    8e8c:	aa0003e2 	mov	x2, x0
    8e90:	aa1403e0 	mov	x0, x20
    8e94:	97ffe9bf 	bl	3590 <buf_put>
    8e98:	52800403 	mov	w3, #0x20                  	// #32
    8e9c:	91001ff5 	add	x21, sp, #0x7
    8ea0:	aa1503e1 	mov	x1, x21
    8ea4:	aa1403e0 	mov	x0, x20
    8ea8:	d2800022 	mov	x2, #0x1                   	// #1
    8eac:	39001fe3 	strb	w3, [sp, #7]
    8eb0:	97ffe9b8 	bl	3590 <buf_put>
    8eb4:	52800f63 	mov	w3, #0x7b                  	// #123
    8eb8:	aa1403e0 	mov	x0, x20
    8ebc:	aa1503e1 	mov	x1, x21
    8ec0:	d2800022 	mov	x2, #0x1                   	// #1
    8ec4:	39001fe3 	strb	w3, [sp, #7]
    8ec8:	97ffe9b2 	bl	3590 <buf_put>
    8ecc:	b9401380 	ldr	w0, [x28, #16]
    8ed0:	52800018 	mov	w24, #0x0                   	// #0
    8ed4:	7100001f 	cmp	w0, #0x0
    8ed8:	54003aad 	b.le	962c <fwp_write+0x9fc>
    8edc:	f9014bf9 	str	x25, [sp, #656]
    8ee0:	f0000019 	adrp	x25, b000 <__modti3+0x280>
    8ee4:	911dc339 	add	x25, x25, #0x770
    8ee8:	f9014ffa 	str	x26, [sp, #664]
    8eec:	f000001a 	adrp	x26, b000 <__modti3+0x280>
    8ef0:	911cc35a 	add	x26, x26, #0x730
    8ef4:	91002276 	add	x22, x19, #0x8
    8ef8:	d2800013 	mov	x19, #0x0                   	// #0
    8efc:	b5003e93 	cbnz	x19, 96cc <fwp_write+0xa9c>
    8f00:	d37df277 	lsl	x23, x19, #3
    8f04:	34003cb8 	cbz	w24, 9698 <fwp_write+0xa68>
    8f08:	f9401382 	ldr	x2, [x28, #32]
    8f0c:	aa1403e0 	mov	x0, x20
    8f10:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8f14:	52800003 	mov	w3, #0x0                   	// #0
    8f18:	f8776842 	ldr	x2, [x2, x23]
    8f1c:	91000673 	add	x19, x19, #0x1
    8f20:	97ffff44 	bl	8c30 <fwp_write>
    8f24:	b9401380 	ldr	w0, [x28, #16]
    8f28:	6b13001f 	cmp	w0, w19
    8f2c:	54fffe8c 	b.gt	8efc <fwp_write+0x2cc>
    8f30:	f9414bf9 	ldr	x25, [sp, #656]
    8f34:	f9414ffa 	ldr	x26, [sp, #664]
    8f38:	340037b8 	cbz	w24, 962c <fwp_write+0x9fc>
    8f3c:	52800523 	mov	w3, #0x29                  	// #41
    8f40:	aa1503e1 	mov	x1, x21
    8f44:	aa1403e0 	mov	x0, x20
    8f48:	d2800022 	mov	x2, #0x1                   	// #1
    8f4c:	39001fe3 	strb	w3, [sp, #7]
    8f50:	97ffe990 	bl	3590 <buf_put>
    8f54:	f9413bf5 	ldr	x21, [sp, #624]
    8f58:	f9413ff6 	ldr	x22, [sp, #632]
    8f5c:	f94143f7 	ldr	x23, [sp, #640]
    8f60:	f94147f8 	ldr	x24, [sp, #648]
    8f64:	f94153fb 	ldr	x27, [sp, #672]
    8f68:	f94157fc 	ldr	x28, [sp, #680]
    8f6c:	17ffff5d 	b	8ce0 <fwp_write+0xb0>
    8f70:	b9404855 	ldr	w21, [x2, #72]
    8f74:	aa1403e0 	mov	x0, x20
    8f78:	93407eb6 	sxtw	x22, w21
    8f7c:	91000ac1 	add	x1, x22, #0x2
    8f80:	97ffe951 	bl	34c4 <buf_grow>
    8f84:	a9400281 	ldp	x1, x0, [x20]
    8f88:	528e8603 	mov	w3, #0x7430                	// #29744
    8f8c:	78206823 	strh	w3, [x1, x0]
    8f90:	8b000022 	add	x2, x1, x0
    8f94:	710002bf 	cmp	w21, #0x0
    8f98:	540036cd 	b.le	9670 <fwp_write+0xa40>
    8f9c:	110006a3 	add	w3, w21, #0x1
    8fa0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8fa4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8fa8:	91000449 	add	x9, x2, #0x1
    8fac:	8b23c043 	add	x3, x2, w3, sxtw
    8fb0:	f28aaac6 	movk	x6, #0x5556
    8fb4:	f2955568 	movk	x8, #0xaaab
    8fb8:	1400000d 	b	8fec <fwp_write+0x3bc>
    8fbc:	d2800021 	mov	x1, #0x1                   	// #1
    8fc0:	528005a5 	mov	w5, #0x2d                  	// #45
    8fc4:	f100001f 	cmp	x0, #0x0
    8fc8:	9b467e60 	smulh	x0, x19, x6
    8fcc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8fd0:	381ff465 	strb	w5, [x3], #-1
    8fd4:	cb040000 	sub	x0, x0, x4
    8fd8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8fdc:	cb020000 	sub	x0, x0, x2
    8fe0:	8b010013 	add	x19, x0, x1
    8fe4:	eb03013f 	cmp	x9, x3
    8fe8:	54003440 	b.eq	9670 <fwp_write+0xa40>  // b.none
    8fec:	9b467e60 	smulh	x0, x19, x6
    8ff0:	937ffe64 	asr	x4, x19, #63
    8ff4:	52800605 	mov	w5, #0x30                  	// #48
    8ff8:	cb040000 	sub	x0, x0, x4
    8ffc:	8b000400 	add	x0, x0, x0, lsl #1
    9000:	cb000260 	sub	x0, x19, x0
    9004:	91000c01 	add	x1, x0, #0x3
    9008:	9bc87c22 	umulh	x2, x1, x8
    900c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    9010:	8b4204e2 	add	x2, x7, x2, lsr #1
    9014:	eb020021 	subs	x1, x1, x2
    9018:	54fffd60 	b.eq	8fc4 <fwp_write+0x394>  // b.none
    901c:	f100043f 	cmp	x1, #0x1
    9020:	54fffce1 	b.ne	8fbc <fwp_write+0x38c>  // b.any
    9024:	d2800001 	mov	x1, #0x0                   	// #0
    9028:	52800565 	mov	w5, #0x2b                  	// #43
    902c:	17ffffe6 	b	8fc4 <fwp_write+0x394>
    9030:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9034:	f947f400 	ldr	x0, [x0, #4072]
    9038:	f94127e2 	ldr	x2, [sp, #584]
    903c:	f9400001 	ldr	x1, [x0]
    9040:	eb010042 	subs	x2, x2, x1
    9044:	d2800001 	mov	x1, #0x0                   	// #0
    9048:	540023c1 	b.ne	94c0 <fwp_write+0x890>  // b.any
    904c:	f9413bf5 	ldr	x21, [sp, #624]
    9050:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9054:	f9413ff6 	ldr	x22, [sp, #632]
    9058:	aa1403e0 	mov	x0, x20
    905c:	911b6021 	add	x1, x1, #0x6d8
    9060:	d2800102 	mov	x2, #0x8                   	// #8
    9064:	17ffff77 	b	8e40 <fwp_write+0x210>
    9068:	aa1403e0 	mov	x0, x20
    906c:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9070:	d28000c2 	mov	x2, #0x6                   	// #6
    9074:	911ce021 	add	x1, x1, #0x738
    9078:	97ffe946 	bl	3590 <buf_put>
    907c:	d2800015 	mov	x21, #0x0                   	// #0
    9080:	f9400263 	ldr	x3, [x19]
    9084:	f240f87f 	tst	x3, #0x7fffffffffffffff
    9088:	54002c60 	b.eq	9614 <fwp_write+0x9e4>  // b.none
    908c:	f9401f82 	ldr	x2, [x28, #56]
    9090:	f90143f7 	str	x23, [sp, #640]
    9094:	f90147f8 	str	x24, [sp, #648]
    9098:	d2800857 	mov	x23, #0x42                  	// #66
    909c:	f9014bf9 	str	x25, [sp, #656]
    90a0:	d0000016 	adrp	x22, b000 <__modti3+0x280>
    90a4:	f9014ffa 	str	x26, [sp, #664]
    90a8:	911cc2d6 	add	x22, x22, #0x730
    90ac:	d2800038 	mov	x24, #0x1                   	// #1
    90b0:	f2a18017 	movk	x23, #0xc00, lsl #16
    90b4:	d2809099 	mov	x25, #0x484                 	// #1156
    90b8:	b40004a2 	cbz	x2, 914c <fwp_write+0x51c>
    90bc:	b9400040 	ldr	w0, [x2]
    90c0:	7100701f 	cmp	w0, #0x1c
    90c4:	540042c0 	b.eq	991c <fwp_write+0xcec>  // b.none
    90c8:	71006c1f 	cmp	w0, #0x1b
    90cc:	54000408 	b.hi	914c <fwp_write+0x51c>  // b.pmore
    90d0:	9ac02301 	lsl	x1, x24, x0
    90d4:	ea17003f 	tst	x1, x23
    90d8:	540036a1 	b.ne	97ac <fwp_write+0xb7c>  // b.any
    90dc:	ea19003f 	tst	x1, x25
    90e0:	54003521 	b.ne	9784 <fwp_write+0xb54>  // b.any
    90e4:	d2800424 	mov	x4, #0x21                  	// #33
    90e8:	ea04003f 	tst	x1, x4
    90ec:	54000300 	b.eq	914c <fwp_write+0x51c>  // b.none
    90f0:	b7f849c3 	tbnz	x3, #63, 9a28 <fwp_write+0xdf8>
    90f4:	91002261 	add	x1, x19, #0x8
    90f8:	8b150021 	add	x1, x1, x21
    90fc:	39400021 	ldrb	w1, [x1]
    9100:	7100001f 	cmp	w0, #0x0
    9104:	93401c23 	sxtb	x3, w1
    9108:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    910c:	d503201f 	nop
    9110:	aa1403e0 	mov	x0, x20
    9114:	52800003 	mov	w3, #0x0                   	// #0
    9118:	97fffec6 	bl	8c30 <fwp_write>
    911c:	910006b5 	add	x21, x21, #0x1
    9120:	f9400260 	ldr	x0, [x19]
    9124:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    9128:	eb0002bf 	cmp	x21, x0
    912c:	540026c2 	b.cs	9604 <fwp_write+0x9d4>  // b.hs, b.nlast
    9130:	d2800042 	mov	x2, #0x2                   	// #2
    9134:	aa1603e1 	mov	x1, x22
    9138:	aa1403e0 	mov	x0, x20
    913c:	97ffe915 	bl	3590 <buf_put>
    9140:	f9401f82 	ldr	x2, [x28, #56]
    9144:	f9400263 	ldr	x3, [x19]
    9148:	b5fffba2 	cbnz	x2, 90bc <fwp_write+0x48c>
    914c:	d37df2a0 	lsl	x0, x21, #3
    9150:	b7f83f03 	tbnz	x3, #63, 9930 <fwp_write+0xd00>
    9154:	91002261 	add	x1, x19, #0x8
    9158:	8b000020 	add	x0, x1, x0
    915c:	f9400001 	ldr	x1, [x0]
    9160:	17ffffec 	b	9110 <fwp_write+0x4e0>
    9164:	a9400e62 	ldp	x2, x3, [x19]
    9168:	b7f83ca3 	tbnz	x3, #63, 98fc <fwp_write+0xccc>
    916c:	910123f5 	add	x21, sp, #0x48
    9170:	aa1503e0 	mov	x0, x21
    9174:	97ffe72b 	bl	2e20 <fwp_fmt_u128>
    9178:	aa1503e0 	mov	x0, x21
    917c:	97ffe565 	bl	2710 <strlen@plt>
    9180:	aa1503e1 	mov	x1, x21
    9184:	aa0003e2 	mov	x2, x0
    9188:	17fffed0 	b	8cc8 <fwp_write+0x98>
    918c:	fd015be8 	str	d8, [sp, #688]
    9190:	1e270268 	fmov	s8, w19
    9194:	fd015fe9 	str	d9, [sp, #696]
    9198:	1e282100 	fcmp	s8, s8
    919c:	54004d26 	b.vs	9b40 <fwp_write+0xf10>
    91a0:	1e20c101 	fabs	s1, s8
    91a4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    91a8:	1e270000 	fmov	s0, w0
    91ac:	1e202020 	fcmp	s1, s0
    91b0:	54002c0d 	b.le	9730 <fwp_write+0xb00>
    91b4:	1e202118 	fcmpe	s8, #0.0
    91b8:	d0000002 	adrp	x2, b000 <__modti3+0x280>
    91bc:	9107e042 	add	x2, x2, #0x1f8
    91c0:	910123f5 	add	x21, sp, #0x48
    91c4:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    91c8:	911a2021 	add	x1, x1, #0x688
    91cc:	aa1503e0 	mov	x0, x21
    91d0:	9a81c041 	csel	x1, x2, x1, gt
    91d4:	97ffe5fb 	bl	29c0 <strcpy@plt>
    91d8:	aa1503e0 	mov	x0, x21
    91dc:	97ffe54d 	bl	2710 <strlen@plt>
    91e0:	aa1503e1 	mov	x1, x21
    91e4:	aa0003e2 	mov	x2, x0
    91e8:	aa1403e0 	mov	x0, x20
    91ec:	97ffe8e9 	bl	3590 <buf_put>
    91f0:	f9413bf5 	ldr	x21, [sp, #624]
    91f4:	f9413ff6 	ldr	x22, [sp, #632]
    91f8:	f94153fb 	ldr	x27, [sp, #672]
    91fc:	f94157fc 	ldr	x28, [sp, #680]
    9200:	fd415be8 	ldr	d8, [sp, #688]
    9204:	fd415fe9 	ldr	d9, [sp, #696]
    9208:	17fffeb6 	b	8ce0 <fwp_write+0xb0>
    920c:	f9400276 	ldr	x22, [x19]
    9210:	34002e03 	cbz	w3, 97d0 <fwp_write+0xba0>
    9214:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9218:	f947f400 	ldr	x0, [x0, #4072]
    921c:	f94127e2 	ldr	x2, [sp, #584]
    9220:	f9400001 	ldr	x1, [x0]
    9224:	eb010042 	subs	x2, x2, x1
    9228:	d2800001 	mov	x1, #0x0                   	// #0
    922c:	540014a1 	b.ne	94c0 <fwp_write+0x890>  // b.any
    9230:	aa1603e2 	mov	x2, x22
    9234:	91002261 	add	x1, x19, #0x8
    9238:	f9413bf5 	ldr	x21, [sp, #624]
    923c:	aa1403e0 	mov	x0, x20
    9240:	f9413ff6 	ldr	x22, [sp, #632]
    9244:	17fffeff 	b	8e40 <fwp_write+0x210>
    9248:	fd015be8 	str	d8, [sp, #688]
    924c:	9e670268 	fmov	d8, x19
    9250:	fd015fe9 	str	d9, [sp, #696]
    9254:	1e682100 	fcmp	d8, d8
    9258:	54004746 	b.vs	9b40 <fwp_write+0xf10>
    925c:	1e60c101 	fabs	d1, d8
    9260:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    9264:	9e670000 	fmov	d0, x0
    9268:	910123f5 	add	x21, sp, #0x48
    926c:	52800033 	mov	w19, #0x1                   	// #1
    9270:	1e602020 	fcmp	d1, d0
    9274:	540001ad 	b.le	92a8 <fwp_write+0x678>
    9278:	1e602118 	fcmpe	d8, #0.0
    927c:	d0000002 	adrp	x2, b000 <__modti3+0x280>
    9280:	9107e042 	add	x2, x2, #0x1f8
    9284:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9288:	911a2021 	add	x1, x1, #0x688
    928c:	aa1503e0 	mov	x0, x21
    9290:	9a81c041 	csel	x1, x2, x1, gt
    9294:	97ffe5cb 	bl	29c0 <strcpy@plt>
    9298:	17ffffd0 	b	91d8 <fwp_write+0x5a8>
    929c:	11000673 	add	w19, w19, #0x1
    92a0:	71004a7f 	cmp	w19, #0x12
    92a4:	54003860 	b.eq	99b0 <fwp_write+0xd80>  // b.none
    92a8:	1e604100 	fmov	d0, d8
    92ac:	2a1303e1 	mov	w1, w19
    92b0:	aa1503e0 	mov	x0, x21
    92b4:	97ffe953 	bl	3800 <fwp_format_g.constprop.0>
    92b8:	aa1503e0 	mov	x0, x21
    92bc:	d2800001 	mov	x1, #0x0                   	// #0
    92c0:	97ffe528 	bl	2760 <strtod@plt>
    92c4:	1e602100 	fcmp	d8, d0
    92c8:	54fffea1 	b.ne	929c <fwp_write+0x66c>  // b.any
    92cc:	aa1503e0 	mov	x0, x21
    92d0:	97ffe929 	bl	3774 <fwp_finish_float>
    92d4:	17ffffc1 	b	91d8 <fwp_write+0x5a8>
    92d8:	a9400e62 	ldp	x2, x3, [x19]
    92dc:	910123f3 	add	x19, sp, #0x48
    92e0:	aa1303e0 	mov	x0, x19
    92e4:	97ffe6cf 	bl	2e20 <fwp_fmt_u128>
    92e8:	17fffe74 	b	8cb8 <fwp_write+0x88>
    92ec:	f90143f7 	str	x23, [sp, #640]
    92f0:	f90147f8 	str	x24, [sp, #648]
    92f4:	2a1303f8 	mov	w24, w19
    92f8:	f9014bf9 	str	x25, [sp, #656]
    92fc:	f9014ffa 	str	x26, [sp, #664]
    9300:	f13ffe7f 	cmp	x19, #0xfff
    9304:	54000049 	b.ls	930c <fwp_write+0x6dc>  // b.plast
    9308:	b9400278 	ldr	w24, [x19]
    930c:	f9400f80 	ldr	x0, [x28, #24]
    9310:	2a1803f5 	mov	w21, w24
    9314:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9318:	d37ef6b9 	lsl	x25, x21, #2
    931c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9320:	aa1603e0 	mov	x0, x22
    9324:	97ffe4fb 	bl	2710 <strlen@plt>
    9328:	aa1603e1 	mov	x1, x22
    932c:	aa0003e2 	mov	x2, x0
    9330:	aa1403e0 	mov	x0, x20
    9334:	97ffe897 	bl	3590 <buf_put>
    9338:	f9401780 	ldr	x0, [x28, #40]
    933c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9340:	7100001f 	cmp	w0, #0x0
    9344:	5400068d 	b.le	9414 <fwp_write+0x7e4>
    9348:	91002276 	add	x22, x19, #0x8
    934c:	91001ff5 	add	x21, sp, #0x7
    9350:	d280001b 	mov	x27, #0x0                   	// #0
    9354:	5280041a 	mov	w26, #0x20                  	// #32
    9358:	f9401b80 	ldr	x0, [x28, #48]
    935c:	aa1503e1 	mov	x1, x21
    9360:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9364:	d2800022 	mov	x2, #0x1                   	// #1
    9368:	f8786803 	ldr	x3, [x0, x24]
    936c:	aa1403e0 	mov	x0, x20
    9370:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9374:	39001ffa 	strb	w26, [sp, #7]
    9378:	97ffe886 	bl	3590 <buf_put>
    937c:	f13ffeff 	cmp	x23, #0xfff
    9380:	b9400261 	ldr	w1, [x19]
    9384:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9388:	7100383f 	cmp	w1, #0xe
    938c:	54000160 	b.eq	93b8 <fwp_write+0x788>  // b.none
    9390:	7100403f 	cmp	w1, #0x10
    9394:	54001a60 	b.eq	96e0 <fwp_write+0xab0>  // b.none
    9398:	7100283f 	cmp	w1, #0xa
    939c:	54002aa0 	b.eq	98f0 <fwp_write+0xcc0>  // b.none
    93a0:	540014ac 	b.gt	9634 <fwp_write+0xa04>
    93a4:	71000c3f 	cmp	w1, #0x3
    93a8:	540029ac 	b.gt	98dc <fwp_write+0xcac>
    93ac:	d37ffee0 	lsr	x0, x23, #63
    93b0:	37f814a1 	tbnz	w1, #31, 9644 <fwp_write+0xa14>
    93b4:	d503201f 	nop
    93b8:	34001460 	cbz	w0, 9644 <fwp_write+0xa14>
    93bc:	52800503 	mov	w3, #0x28                  	// #40
    93c0:	aa1503e1 	mov	x1, x21
    93c4:	aa1403e0 	mov	x0, x20
    93c8:	d2800022 	mov	x2, #0x1                   	// #1
    93cc:	39001fe3 	strb	w3, [sp, #7]
    93d0:	97ffe870 	bl	3590 <buf_put>
    93d4:	aa1303e2 	mov	x2, x19
    93d8:	aa1703e1 	mov	x1, x23
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	52800003 	mov	w3, #0x0                   	// #0
    93e4:	97fffe13 	bl	8c30 <fwp_write>
    93e8:	52800523 	mov	w3, #0x29                  	// #41
    93ec:	aa1503e1 	mov	x1, x21
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	d2800022 	mov	x2, #0x1                   	// #1
    93f8:	39001fe3 	strb	w3, [sp, #7]
    93fc:	97ffe865 	bl	3590 <buf_put>
    9400:	f9401780 	ldr	x0, [x28, #40]
    9404:	9100077b 	add	x27, x27, #0x1
    9408:	b8796800 	ldr	w0, [x0, x25]
    940c:	6b1b001f 	cmp	w0, w27
    9410:	54fffa4c 	b.gt	9358 <fwp_write+0x728>
    9414:	f9413bf5 	ldr	x21, [sp, #624]
    9418:	f9413ff6 	ldr	x22, [sp, #632]
    941c:	f94143f7 	ldr	x23, [sp, #640]
    9420:	f94147f8 	ldr	x24, [sp, #648]
    9424:	f9414bf9 	ldr	x25, [sp, #656]
    9428:	f9414ffa 	ldr	x26, [sp, #664]
    942c:	f94153fb 	ldr	x27, [sp, #672]
    9430:	f94157fc 	ldr	x28, [sp, #680]
    9434:	17fffe2b 	b	8ce0 <fwp_write+0xb0>
    9438:	52800783 	mov	w3, #0x3c                  	// #60
    943c:	91001ff3 	add	x19, sp, #0x7
    9440:	aa1303e1 	mov	x1, x19
    9444:	d2800022 	mov	x2, #0x1                   	// #1
    9448:	aa1403e0 	mov	x0, x20
    944c:	39001fe3 	strb	w3, [sp, #7]
    9450:	97ffe850 	bl	3590 <buf_put>
    9454:	f9400795 	ldr	x21, [x28, #8]
    9458:	aa1503e0 	mov	x0, x21
    945c:	97ffe4ad 	bl	2710 <strlen@plt>
    9460:	aa1503e1 	mov	x1, x21
    9464:	aa0003e2 	mov	x2, x0
    9468:	aa1403e0 	mov	x0, x20
    946c:	97ffe849 	bl	3590 <buf_put>
    9470:	528007c3 	mov	w3, #0x3e                  	// #62
    9474:	aa1303e1 	mov	x1, x19
    9478:	aa1403e0 	mov	x0, x20
    947c:	d2800022 	mov	x2, #0x1                   	// #1
    9480:	39001fe3 	strb	w3, [sp, #7]
    9484:	17fffe12 	b	8ccc <fwp_write+0x9c>
    9488:	f100067f 	cmp	x19, #0x1
    948c:	540025a0 	b.eq	9940 <fwp_write+0xd10>  // b.none
    9490:	b100067f 	cmn	x19, #0x1
    9494:	54002bc0 	b.eq	9a0c <fwp_write+0xddc>  // b.none
    9498:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    949c:	911a4021 	add	x1, x1, #0x690
    94a0:	d2800022 	mov	x2, #0x1                   	// #1
    94a4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    94a8:	f947f400 	ldr	x0, [x0, #4072]
    94ac:	f94127e4 	ldr	x4, [sp, #584]
    94b0:	f9400003 	ldr	x3, [x0]
    94b4:	eb030084 	subs	x4, x4, x3
    94b8:	d2800003 	mov	x3, #0x0                   	// #0
    94bc:	54ffebe0 	b.eq	9238 <fwp_write+0x608>  // b.none
    94c0:	f90143f7 	str	x23, [sp, #640]
    94c4:	f90147f8 	str	x24, [sp, #648]
    94c8:	f9014bf9 	str	x25, [sp, #656]
    94cc:	f9014ffa 	str	x26, [sp, #664]
    94d0:	fd015be8 	str	d8, [sp, #688]
    94d4:	fd015fe9 	str	d9, [sp, #696]
    94d8:	97ffe4ea 	bl	2880 <__stack_chk_fail@plt>
    94dc:	52800b63 	mov	w3, #0x5b                  	// #91
    94e0:	91001ff5 	add	x21, sp, #0x7
    94e4:	aa1503e1 	mov	x1, x21
    94e8:	aa1403e0 	mov	x0, x20
    94ec:	d2800022 	mov	x2, #0x1                   	// #1
    94f0:	d0000016 	adrp	x22, b000 <__modti3+0x280>
    94f4:	911cc2d6 	add	x22, x22, #0x730
    94f8:	39001fe3 	strb	w3, [sp, #7]
    94fc:	97ffe825 	bl	3590 <buf_put>
    9500:	b4000273 	cbz	x19, 954c <fwp_write+0x91c>
    9504:	f9400661 	ldr	x1, [x19, #8]
    9508:	aa1403e0 	mov	x0, x20
    950c:	f9401f82 	ldr	x2, [x28, #56]
    9510:	52800003 	mov	w3, #0x0                   	// #0
    9514:	97fffdc7 	bl	8c30 <fwp_write>
    9518:	f9400a73 	ldr	x19, [x19, #16]
    951c:	b4000193 	cbz	x19, 954c <fwp_write+0x91c>
    9520:	aa1603e1 	mov	x1, x22
    9524:	aa1403e0 	mov	x0, x20
    9528:	d2800042 	mov	x2, #0x2                   	// #2
    952c:	97ffe819 	bl	3590 <buf_put>
    9530:	f9400661 	ldr	x1, [x19, #8]
    9534:	aa1403e0 	mov	x0, x20
    9538:	f9401f82 	ldr	x2, [x28, #56]
    953c:	52800003 	mov	w3, #0x0                   	// #0
    9540:	97fffdbc 	bl	8c30 <fwp_write>
    9544:	f9400a73 	ldr	x19, [x19, #16]
    9548:	b5fffed3 	cbnz	x19, 9520 <fwp_write+0x8f0>
    954c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9550:	aa1503e1 	mov	x1, x21
    9554:	aa1403e0 	mov	x0, x20
    9558:	d2800022 	mov	x2, #0x1                   	// #1
    955c:	39001fe3 	strb	w3, [sp, #7]
    9560:	17fffddb 	b	8ccc <fwp_write+0x9c>
    9564:	aa1403e0 	mov	x0, x20
    9568:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    956c:	d28000c2 	mov	x2, #0x6                   	// #6
    9570:	911c8021 	add	x1, x1, #0x720
    9574:	97ffe807 	bl	3590 <buf_put>
    9578:	f9400260 	ldr	x0, [x19]
    957c:	b40004c0 	cbz	x0, 9614 <fwp_write+0x9e4>
    9580:	910123f5 	add	x21, sp, #0x48
    9584:	91002276 	add	x22, x19, #0x8
    9588:	f90143f7 	str	x23, [sp, #640]
    958c:	d2800017 	mov	x23, #0x0                   	// #0
    9590:	f90147f8 	str	x24, [sp, #648]
    9594:	d0000018 	adrp	x24, b000 <__modti3+0x280>
    9598:	911ca318 	add	x24, x24, #0x728
    959c:	f9014bf9 	str	x25, [sp, #656]
    95a0:	d0000019 	adrp	x25, b000 <__modti3+0x280>
    95a4:	911cc339 	add	x25, x25, #0x730
    95a8:	f9014ffa 	str	x26, [sp, #664]
    95ac:	14000005 	b	95c0 <fwp_write+0x990>
    95b0:	aa1903e1 	mov	x1, x25
    95b4:	aa1403e0 	mov	x0, x20
    95b8:	d2800042 	mov	x2, #0x2                   	// #2
    95bc:	97ffe7f5 	bl	3590 <buf_put>
    95c0:	38776ac5 	ldrb	w5, [x22, x23]
    95c4:	d2804003 	mov	x3, #0x200                 	// #512
    95c8:	aa1803e4 	mov	x4, x24
    95cc:	aa0303e1 	mov	x1, x3
    95d0:	52800042 	mov	w2, #0x2                   	// #2
    95d4:	aa1503e0 	mov	x0, x21
    95d8:	910006f7 	add	x23, x23, #0x1
    95dc:	97ffe485 	bl	27f0 <__snprintf_chk@plt>
    95e0:	aa1503e0 	mov	x0, x21
    95e4:	97ffe44b 	bl	2710 <strlen@plt>
    95e8:	aa1503e1 	mov	x1, x21
    95ec:	aa0003e2 	mov	x2, x0
    95f0:	aa1403e0 	mov	x0, x20
    95f4:	97ffe7e7 	bl	3590 <buf_put>
    95f8:	f9400260 	ldr	x0, [x19]
    95fc:	eb17001f 	cmp	x0, x23
    9600:	54fffd88 	b.hi	95b0 <fwp_write+0x980>  // b.pmore
    9604:	f94143f7 	ldr	x23, [sp, #640]
    9608:	f94147f8 	ldr	x24, [sp, #648]
    960c:	f9414bf9 	ldr	x25, [sp, #656]
    9610:	f9414ffa 	ldr	x26, [sp, #664]
    9614:	52800ba3 	mov	w3, #0x5d                  	// #93
    9618:	aa1403e0 	mov	x0, x20
    961c:	91001fe1 	add	x1, sp, #0x7
    9620:	d2800022 	mov	x2, #0x1                   	// #1
    9624:	39001fe3 	strb	w3, [sp, #7]
    9628:	17fffda9 	b	8ccc <fwp_write+0x9c>
    962c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9630:	17fffe44 	b	8f40 <fwp_write+0x310>
    9634:	f10002ff 	cmp	x23, #0x0
    9638:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    963c:	71002c3f 	cmp	w1, #0xb
    9640:	54ffebc0 	b.eq	93b8 <fwp_write+0x788>  // b.none
    9644:	aa1303e2 	mov	x2, x19
    9648:	aa1703e1 	mov	x1, x23
    964c:	aa1403e0 	mov	x0, x20
    9650:	52800003 	mov	w3, #0x0                   	// #0
    9654:	97fffd77 	bl	8c30 <fwp_write>
    9658:	17ffff6a 	b	9400 <fwp_write+0x7d0>
    965c:	aa1403e0 	mov	x0, x20
    9660:	91001fe1 	add	x1, sp, #0x7
    9664:	52800fa3 	mov	w3, #0x7d                  	// #125
    9668:	d2800022 	mov	x2, #0x1                   	// #1
    966c:	17fffe38 	b	8f4c <fwp_write+0x31c>
    9670:	a9400281 	ldp	x1, x0, [x20]
    9674:	91000800 	add	x0, x0, #0x2
    9678:	8b160000 	add	x0, x0, x22
    967c:	f9000680 	str	x0, [x20, #8]
    9680:	3820683f 	strb	wzr, [x1, x0]
    9684:	f9413bf5 	ldr	x21, [sp, #624]
    9688:	f9413ff6 	ldr	x22, [sp, #632]
    968c:	f94153fb 	ldr	x27, [sp, #672]
    9690:	f94157fc 	ldr	x28, [sp, #680]
    9694:	17fffd93 	b	8ce0 <fwp_write+0xb0>
    9698:	f9400f80 	ldr	x0, [x28, #24]
    969c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    96a0:	aa1b03e0 	mov	x0, x27
    96a4:	97ffe41b 	bl	2710 <strlen@plt>
    96a8:	aa1b03e1 	mov	x1, x27
    96ac:	aa0003e2 	mov	x2, x0
    96b0:	aa1403e0 	mov	x0, x20
    96b4:	97ffe7b7 	bl	3590 <buf_put>
    96b8:	aa1903e1 	mov	x1, x25
    96bc:	aa1403e0 	mov	x0, x20
    96c0:	d2800062 	mov	x2, #0x3                   	// #3
    96c4:	97ffe7b3 	bl	3590 <buf_put>
    96c8:	17fffe10 	b	8f08 <fwp_write+0x2d8>
    96cc:	aa1a03e1 	mov	x1, x26
    96d0:	aa1403e0 	mov	x0, x20
    96d4:	d2800042 	mov	x2, #0x2                   	// #2
    96d8:	97ffe7ae 	bl	3590 <buf_put>
    96dc:	17fffe09 	b	8f00 <fwp_write+0x2d0>
    96e0:	f9400660 	ldr	x0, [x19, #8]
    96e4:	b4fffb00 	cbz	x0, 9644 <fwp_write+0xa14>
    96e8:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    96ec:	911d2021 	add	x1, x1, #0x748
    96f0:	97ffe484 	bl	2900 <strcmp@plt>
    96f4:	7100001f 	cmp	w0, #0x0
    96f8:	1a9f07e0 	cset	w0, ne	// ne = any
    96fc:	17ffff2f 	b	93b8 <fwp_write+0x788>
    9700:	aa1403e0 	mov	x0, x20
    9704:	d2800042 	mov	x2, #0x2                   	// #2
    9708:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    970c:	911d0021 	add	x1, x1, #0x740
    9710:	97ffe7a0 	bl	3590 <buf_put>
    9714:	91004261 	add	x1, x19, #0x10
    9718:	aa1403e0 	mov	x0, x20
    971c:	f9402382 	ldr	x2, [x28, #64]
    9720:	52800003 	mov	w3, #0x0                   	// #0
    9724:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9728:	97fffd42 	bl	8c30 <fwp_write>
    972c:	17fffd9c 	b	8d9c <fwp_write+0x16c>
    9730:	1e22c109 	fcvt	d9, s8
    9734:	910123f5 	add	x21, sp, #0x48
    9738:	52800033 	mov	w19, #0x1                   	// #1
    973c:	d503201f 	nop
    9740:	1e604120 	fmov	d0, d9
    9744:	2a1303e1 	mov	w1, w19
    9748:	aa1503e0 	mov	x0, x21
    974c:	97ffe82d 	bl	3800 <fwp_format_g.constprop.0>
    9750:	aa1503e0 	mov	x0, x21
    9754:	d2800001 	mov	x1, #0x0                   	// #0
    9758:	97ffe476 	bl	2930 <strtof@plt>
    975c:	1e202100 	fcmp	s8, s0
    9760:	54ffdb60 	b.eq	92cc <fwp_write+0x69c>  // b.none
    9764:	11000673 	add	w19, w19, #0x1
    9768:	71002a7f 	cmp	w19, #0xa
    976c:	54fffea1 	b.ne	9740 <fwp_write+0xb10>  // b.any
    9770:	1e604120 	fmov	d0, d9
    9774:	aa1503e0 	mov	x0, x21
    9778:	52800121 	mov	w1, #0x9                   	// #9
    977c:	97ffe821 	bl	3800 <fwp_format_g.constprop.0>
    9780:	17fffed3 	b	92cc <fwp_write+0x69c>
    9784:	d37ef6a1 	lsl	x1, x21, #2
    9788:	b7f81563 	tbnz	x3, #63, 9a34 <fwp_write+0xe04>
    978c:	91002263 	add	x3, x19, #0x8
    9790:	8b010061 	add	x1, x3, x1
    9794:	b9400023 	ldr	w3, [x1]
    9798:	7100081f 	cmp	w0, #0x2
    979c:	2a0303e1 	mov	w1, w3
    97a0:	93407c63 	sxtw	x3, w3
    97a4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    97a8:	17fffe5a 	b	9110 <fwp_write+0x4e0>
    97ac:	d37ffaa1 	lsl	x1, x21, #1
    97b0:	b7f81363 	tbnz	x3, #63, 9a1c <fwp_write+0xdec>
    97b4:	91002263 	add	x3, x19, #0x8
    97b8:	8b010061 	add	x1, x3, x1
    97bc:	79400021 	ldrh	w1, [x1]
    97c0:	7100041f 	cmp	w0, #0x1
    97c4:	93403c23 	sxth	x3, w1
    97c8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    97cc:	17fffe51 	b	9110 <fwp_write+0x4e0>
    97d0:	52800443 	mov	w3, #0x22                  	// #34
    97d4:	91001ff5 	add	x21, sp, #0x7
    97d8:	91002273 	add	x19, x19, #0x8
    97dc:	aa1503e1 	mov	x1, x21
    97e0:	aa1403e0 	mov	x0, x20
    97e4:	d2800022 	mov	x2, #0x1                   	// #1
    97e8:	39001fe3 	strb	w3, [sp, #7]
    97ec:	f90143f7 	str	x23, [sp, #640]
    97f0:	8b160277 	add	x23, x19, x22
    97f4:	f90147f8 	str	x24, [sp, #648]
    97f8:	97ffe766 	bl	3590 <buf_put>
    97fc:	b4000696 	cbz	x22, 98cc <fwp_write+0xc9c>
    9800:	d0000018 	adrp	x24, b000 <__modti3+0x280>
    9804:	911bc318 	add	x24, x24, #0x6f0
    9808:	f9014bf9 	str	x25, [sp, #656]
    980c:	d0000019 	adrp	x25, b000 <__modti3+0x280>
    9810:	911c4339 	add	x25, x25, #0x710
    9814:	f9014ffa 	str	x26, [sp, #664]
    9818:	1400000d 	b	984c <fwp_write+0xc1c>
    981c:	710024bf 	cmp	w5, #0x9
    9820:	54000460 	b.eq	98ac <fwp_write+0xc7c>  // b.none
    9824:	710028bf 	cmp	w5, #0xa
    9828:	54000a61 	b.ne	9974 <fwp_write+0xd44>  // b.any
    982c:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9830:	aa1403e0 	mov	x0, x20
    9834:	911c0021 	add	x1, x1, #0x700
    9838:	d2800042 	mov	x2, #0x2                   	// #2
    983c:	97ffe755 	bl	3590 <buf_put>
    9840:	91000673 	add	x19, x19, #0x1
    9844:	eb17027f 	cmp	x19, x23
    9848:	540003e0 	b.eq	98c4 <fwp_write+0xc94>  // b.none
    984c:	39400265 	ldrb	w5, [x19]
    9850:	710034bf 	cmp	w5, #0xd
    9854:	54000180 	b.eq	9884 <fwp_write+0xc54>  // b.none
    9858:	54fffe29 	b.ls	981c <fwp_write+0xbec>  // b.plast
    985c:	710088bf 	cmp	w5, #0x22
    9860:	540001c0 	b.eq	9898 <fwp_write+0xc68>  // b.none
    9864:	710170bf 	cmp	w5, #0x5c
    9868:	54000741 	b.ne	9950 <fwp_write+0xd20>  // b.any
    986c:	aa1403e0 	mov	x0, x20
    9870:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9874:	d2800042 	mov	x2, #0x2                   	// #2
    9878:	911be021 	add	x1, x1, #0x6f8
    987c:	97ffe745 	bl	3590 <buf_put>
    9880:	17fffff0 	b	9840 <fwp_write+0xc10>
    9884:	aa1903e1 	mov	x1, x25
    9888:	aa1403e0 	mov	x0, x20
    988c:	d2800042 	mov	x2, #0x2                   	// #2
    9890:	97ffe740 	bl	3590 <buf_put>
    9894:	17ffffeb 	b	9840 <fwp_write+0xc10>
    9898:	aa1803e1 	mov	x1, x24
    989c:	aa1403e0 	mov	x0, x20
    98a0:	d2800042 	mov	x2, #0x2                   	// #2
    98a4:	97ffe73b 	bl	3590 <buf_put>
    98a8:	17ffffe6 	b	9840 <fwp_write+0xc10>
    98ac:	aa1403e0 	mov	x0, x20
    98b0:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    98b4:	d2800042 	mov	x2, #0x2                   	// #2
    98b8:	911c2021 	add	x1, x1, #0x708
    98bc:	97ffe735 	bl	3590 <buf_put>
    98c0:	17ffffe0 	b	9840 <fwp_write+0xc10>
    98c4:	f9414bf9 	ldr	x25, [sp, #656]
    98c8:	f9414ffa 	ldr	x26, [sp, #664]
    98cc:	aa1503e1 	mov	x1, x21
    98d0:	aa1403e0 	mov	x0, x20
    98d4:	52800443 	mov	w3, #0x22                  	// #34
    98d8:	17fffd9c 	b	8f48 <fwp_write+0x318>
    98dc:	7100103f 	cmp	w1, #0x4
    98e0:	54ffeb21 	b.ne	9644 <fwp_write+0xa14>  // b.any
    98e4:	f94006e0 	ldr	x0, [x23, #8]
    98e8:	d37ffc00 	lsr	x0, x0, #63
    98ec:	17fffeb3 	b	93b8 <fwp_write+0x788>
    98f0:	710002ff 	cmp	w23, #0x0
    98f4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    98f8:	17fffeb0 	b	93b8 <fwp_write+0x788>
    98fc:	528005a1 	mov	w1, #0x2d                  	// #45
    9900:	eb0203e2 	negs	x2, x2
    9904:	da0303e3 	ngc	x3, x3
    9908:	910127e0 	add	x0, sp, #0x49
    990c:	910123f5 	add	x21, sp, #0x48
    9910:	390123e1 	strb	w1, [sp, #72]
    9914:	97ffe543 	bl	2e20 <fwp_fmt_u128>
    9918:	17fffe18 	b	9178 <fwp_write+0x548>
    991c:	d37ceea1 	lsl	x1, x21, #4
    9920:	b7f810a3 	tbnz	x3, #63, 9b34 <fwp_write+0xf04>
    9924:	91002260 	add	x0, x19, #0x8
    9928:	8b010001 	add	x1, x0, x1
    992c:	17fffdf9 	b	9110 <fwp_write+0x4e0>
    9930:	f9400a61 	ldr	x1, [x19, #16]
    9934:	8b010000 	add	x0, x0, x1
    9938:	f9400001 	ldr	x1, [x0]
    993c:	17fffdf5 	b	9110 <fwp_write+0x4e0>
    9940:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9944:	d2800042 	mov	x2, #0x2                   	// #2
    9948:	911a6021 	add	x1, x1, #0x698
    994c:	17fffed6 	b	94a4 <fwp_write+0x874>
    9950:	7101fcbf 	cmp	w5, #0x7f
    9954:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9958:	540000e9 	b.ls	9974 <fwp_write+0xd44>  // b.plast
    995c:	aa1503e1 	mov	x1, x21
    9960:	aa1403e0 	mov	x0, x20
    9964:	d2800022 	mov	x2, #0x1                   	// #1
    9968:	39001fe5 	strb	w5, [sp, #7]
    996c:	97ffe709 	bl	3590 <buf_put>
    9970:	17ffffb4 	b	9840 <fwp_write+0xc10>
    9974:	d2800203 	mov	x3, #0x10                  	// #16
    9978:	d0000004 	adrp	x4, b000 <__modti3+0x280>
    997c:	aa0303e1 	mov	x1, x3
    9980:	911c6084 	add	x4, x4, #0x718
    9984:	910123f6 	add	x22, sp, #0x48
    9988:	52800042 	mov	w2, #0x2                   	// #2
    998c:	aa1603e0 	mov	x0, x22
    9990:	97ffe398 	bl	27f0 <__snprintf_chk@plt>
    9994:	aa1603e0 	mov	x0, x22
    9998:	97ffe35e 	bl	2710 <strlen@plt>
    999c:	aa1603e1 	mov	x1, x22
    99a0:	aa0003e2 	mov	x2, x0
    99a4:	aa1403e0 	mov	x0, x20
    99a8:	97ffe6fa 	bl	3590 <buf_put>
    99ac:	17ffffa5 	b	9840 <fwp_write+0xc10>
    99b0:	1e604100 	fmov	d0, d8
    99b4:	aa1503e0 	mov	x0, x21
    99b8:	52800221 	mov	w1, #0x11                  	// #17
    99bc:	97ffe791 	bl	3800 <fwp_format_g.constprop.0>
    99c0:	17fffe43 	b	92cc <fwp_write+0x69c>
    99c4:	b9401040 	ldr	w0, [x2, #16]
    99c8:	350003c0 	cbnz	w0, 9a40 <fwp_write+0xe10>
    99cc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    99d0:	f947f400 	ldr	x0, [x0, #4072]
    99d4:	f94127e2 	ldr	x2, [sp, #584]
    99d8:	f9400001 	ldr	x1, [x0]
    99dc:	eb010042 	subs	x2, x2, x1
    99e0:	d2800001 	mov	x1, #0x0                   	// #0
    99e4:	54ffd721 	b.ne	94c8 <fwp_write+0x898>  // b.any
    99e8:	f9413bf5 	ldr	x21, [sp, #624]
    99ec:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    99f0:	f9413ff6 	ldr	x22, [sp, #632]
    99f4:	aa1403e0 	mov	x0, x20
    99f8:	f94143f7 	ldr	x23, [sp, #640]
    99fc:	911da021 	add	x1, x1, #0x768
    9a00:	f94147f8 	ldr	x24, [sp, #648]
    9a04:	d2800042 	mov	x2, #0x2                   	// #2
    9a08:	17fffd0e 	b	8e40 <fwp_write+0x210>
    9a0c:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9a10:	d2800042 	mov	x2, #0x2                   	// #2
    9a14:	911a8021 	add	x1, x1, #0x6a0
    9a18:	17fffea3 	b	94a4 <fwp_write+0x874>
    9a1c:	f9400a63 	ldr	x3, [x19, #16]
    9a20:	8b030021 	add	x1, x1, x3
    9a24:	17ffff66 	b	97bc <fwp_write+0xb8c>
    9a28:	f9400a61 	ldr	x1, [x19, #16]
    9a2c:	8b0102a1 	add	x1, x21, x1
    9a30:	17fffdb3 	b	90fc <fwp_write+0x4cc>
    9a34:	f9400a63 	ldr	x3, [x19, #16]
    9a38:	8b030021 	add	x1, x1, x3
    9a3c:	17ffff56 	b	9794 <fwp_write+0xb64>
    9a40:	b9404840 	ldr	w0, [x2, #72]
    9a44:	91001ff5 	add	x21, sp, #0x7
    9a48:	34ffa360 	cbz	w0, 8eb4 <fwp_write+0x284>
    9a4c:	52800503 	mov	w3, #0x28                  	// #40
    9a50:	aa1403e0 	mov	x0, x20
    9a54:	aa1503e1 	mov	x1, x21
    9a58:	d2800022 	mov	x2, #0x1                   	// #1
    9a5c:	39001fe3 	strb	w3, [sp, #7]
    9a60:	97ffe6cc 	bl	3590 <buf_put>
    9a64:	b9401380 	ldr	w0, [x28, #16]
    9a68:	52800038 	mov	w24, #0x1                   	// #1
    9a6c:	7100001f 	cmp	w0, #0x0
    9a70:	54ffa36c 	b.gt	8edc <fwp_write+0x2ac>
    9a74:	17fffd32 	b	8f3c <fwp_write+0x30c>
    9a78:	f9014bf9 	str	x25, [sp, #656]
    9a7c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10c40>
    9a80:	f9014ffa 	str	x26, [sp, #664]
    9a84:	f9400676 	ldr	x22, [x19, #8]
    9a88:	91102333 	add	x19, x25, #0x408
    9a8c:	91002273 	add	x19, x19, #0x8
    9a90:	937ffed8 	asr	x24, x22, #63
    9a94:	aa1802c0 	orr	x0, x22, x24
    9a98:	b5000320 	cbnz	x0, 9afc <fwp_write+0xecc>
    9a9c:	110006b5 	add	w21, w21, #0x1
    9aa0:	710016bf 	cmp	w21, #0x5
    9aa4:	54ffffc1 	b.ne	9a9c <fwp_write+0xe6c>  // b.any
    9aa8:	b7f80578 	tbnz	x24, #63, 9b54 <fwp_write+0xf24>
    9aac:	910023f3 	add	x19, sp, #0x8
    9ab0:	aa1603e2 	mov	x2, x22
    9ab4:	aa1303e0 	mov	x0, x19
    9ab8:	d2800003 	mov	x3, #0x0                   	// #0
    9abc:	97ffe4d9 	bl	2e20 <fwp_fmt_u128>
    9ac0:	910123f5 	add	x21, sp, #0x48
    9ac4:	d0000003 	adrp	x3, b000 <__modti3+0x280>
    9ac8:	aa1303e4 	mov	x4, x19
    9acc:	aa1503e0 	mov	x0, x21
    9ad0:	911d8063 	add	x3, x3, #0x760
    9ad4:	d2804002 	mov	x2, #0x200                 	// #512
    9ad8:	52800041 	mov	w1, #0x2                   	// #2
    9adc:	97ffe311 	bl	2720 <__sprintf_chk@plt>
    9ae0:	aa1503e0 	mov	x0, x21
    9ae4:	97ffe30b 	bl	2710 <strlen@plt>
    9ae8:	aa1503e1 	mov	x1, x21
    9aec:	aa0003e2 	mov	x2, x0
    9af0:	aa1403e0 	mov	x0, x20
    9af4:	97ffe6a7 	bl	3590 <buf_put>
    9af8:	17fffe47 	b	9414 <fwp_write+0x7e4>
    9afc:	f9400277 	ldr	x23, [x19]
    9b00:	aa1603e0 	mov	x0, x22
    9b04:	aa1803e1 	mov	x1, x24
    9b08:	aa1703e2 	mov	x2, x23
    9b0c:	937ffefa 	asr	x26, x23, #63
    9b10:	aa1a03e3 	mov	x3, x26
    9b14:	9400049b 	bl	ad80 <__modti3>
    9b18:	aa010000 	orr	x0, x0, x1
    9b1c:	b40002c0 	cbz	x0, 9b74 <fwp_write+0xf44>
    9b20:	110006b5 	add	w21, w21, #0x1
    9b24:	91004273 	add	x19, x19, #0x10
    9b28:	710016bf 	cmp	w21, #0x5
    9b2c:	54fffe81 	b.ne	9afc <fwp_write+0xecc>  // b.any
    9b30:	17ffffde 	b	9aa8 <fwp_write+0xe78>
    9b34:	f9400a60 	ldr	x0, [x19, #16]
    9b38:	8b000021 	add	x1, x1, x0
    9b3c:	17fffd75 	b	9110 <fwp_write+0x4e0>
    9b40:	528c29c0 	mov	w0, #0x614e                	// #24910
    9b44:	910123f5 	add	x21, sp, #0x48
    9b48:	72a009c0 	movk	w0, #0x4e, lsl #16
    9b4c:	b9004be0 	str	w0, [sp, #72]
    9b50:	17fffda2 	b	91d8 <fwp_write+0x5a8>
    9b54:	528005a1 	mov	w1, #0x2d                  	// #45
    9b58:	eb1603e2 	negs	x2, x22
    9b5c:	da1803e3 	ngc	x3, x24
    9b60:	910027e0 	add	x0, sp, #0x9
    9b64:	910023f3 	add	x19, sp, #0x8
    9b68:	390023e1 	strb	w1, [sp, #8]
    9b6c:	97ffe4ad 	bl	2e20 <fwp_fmt_u128>
    9b70:	17ffffd4 	b	9ac0 <fwp_write+0xe90>
    9b74:	aa1703e2 	mov	x2, x23
    9b78:	aa1a03e3 	mov	x3, x26
    9b7c:	aa1603e0 	mov	x0, x22
    9b80:	aa1803e1 	mov	x1, x24
    9b84:	9400039f 	bl	aa00 <__divti3>
    9b88:	aa0003e2 	mov	x2, x0
    9b8c:	aa0103e3 	mov	x3, x1
    9b90:	b7f80201 	tbnz	x1, #63, 9bd0 <fwp_write+0xfa0>
    9b94:	910023f3 	add	x19, sp, #0x8
    9b98:	aa1303e0 	mov	x0, x19
    9b9c:	97ffe4a1 	bl	2e20 <fwp_fmt_u128>
    9ba0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9ba4:	91102339 	add	x25, x25, #0x408
    9ba8:	910123f5 	add	x21, sp, #0x48
    9bac:	aa1303e4 	mov	x4, x19
    9bb0:	aa1503e0 	mov	x0, x21
    9bb4:	d0000003 	adrp	x3, b000 <__modti3+0x280>
    9bb8:	f8616b25 	ldr	x5, [x25, x1]
    9bbc:	911d6063 	add	x3, x3, #0x758
    9bc0:	d2804002 	mov	x2, #0x200                 	// #512
    9bc4:	52800041 	mov	w1, #0x2                   	// #2
    9bc8:	97ffe2d6 	bl	2720 <__sprintf_chk@plt>
    9bcc:	17ffffc5 	b	9ae0 <fwp_write+0xeb0>
    9bd0:	528005a4 	mov	w4, #0x2d                  	// #45
    9bd4:	eb0003e2 	negs	x2, x0
    9bd8:	da0103e3 	ngc	x3, x1
    9bdc:	910027e0 	add	x0, sp, #0x9
    9be0:	910023f3 	add	x19, sp, #0x8
    9be4:	390023e4 	strb	w4, [sp, #8]
    9be8:	97ffe48e 	bl	2e20 <fwp_fmt_u128>
    9bec:	17ffffed 	b	9ba0 <fwp_write+0xf70>
    9bf0:	f9013bf5 	str	x21, [sp, #624]
    9bf4:	f9013ff6 	str	x22, [sp, #632]
    9bf8:	f90143f7 	str	x23, [sp, #640]
    9bfc:	f90147f8 	str	x24, [sp, #648]
    9c00:	f9014bf9 	str	x25, [sp, #656]
    9c04:	f9014ffa 	str	x26, [sp, #664]
    9c08:	f90153fb 	str	x27, [sp, #672]
    9c0c:	f90157fc 	str	x28, [sp, #680]
    9c10:	fd015be8 	str	d8, [sp, #688]
    9c14:	fd015fe9 	str	d9, [sp, #696]
    9c18:	97ffe31a 	bl	2880 <__stack_chk_fail@plt>
    9c1c:	d503201f 	nop

0000000000009c20 <fwp_main_thread>:
    9c20:	d10643ff 	sub	sp, sp, #0x190
    9c24:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9c28:	f947f400 	ldr	x0, [x0, #4072]
    9c2c:	a9127bfd 	stp	x29, x30, [sp, #288]
    9c30:	910483fd 	add	x29, sp, #0x120
    9c34:	a91353f3 	stp	x19, x20, [sp, #304]
    9c38:	90000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    9c3c:	91174261 	add	x1, x19, #0x5d0
    9c40:	a9145bf5 	stp	x21, x22, [sp, #320]
    9c44:	a91563f7 	stp	x23, x24, [sp, #336]
    9c48:	b953a421 	ldr	w1, [x1, #5028]
    9c4c:	a9166bf9 	stp	x25, x26, [sp, #352]
    9c50:	f9400002 	ldr	x2, [x0]
    9c54:	f9008fe2 	str	x2, [sp, #280]
    9c58:	d2800002 	mov	x2, #0x0                   	// #0
    9c5c:	34000e61 	cbz	w1, 9e28 <fwp_main_thread+0x208>
    9c60:	91174260 	add	x0, x19, #0x5d0
    9c64:	b953a800 	ldr	w0, [x0, #5032]
    9c68:	35000d80 	cbnz	w0, 9e18 <fwp_main_thread+0x1f8>
    9c6c:	f00000b5 	adrp	x21, 20000 <__data_start>
    9c70:	f00000a2 	adrp	x2, 20000 <__data_start>
    9c74:	9101c2b4 	add	x20, x21, #0x70
    9c78:	910fc042 	add	x2, x2, #0x3f0
    9c7c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9c80:	d2a00024 	mov	x4, #0x10000               	// #65536
    9c84:	910103f7 	add	x23, sp, #0x40
    9c88:	9100a3f6 	add	x22, sp, #0x28
    9c8c:	aa1703e0 	mov	x0, x23
    9c90:	d2800001 	mov	x1, #0x0                   	// #0
    9c94:	a9018e96 	stp	x22, x3, [x20, #24]
    9c98:	f90023e2 	str	x2, [sp, #64]
    9c9c:	b9004bff 	str	wzr, [sp, #72]
    9ca0:	f9002be4 	str	x4, [sp, #80]
    9ca4:	97ffe28f 	bl	26e0 <sigaltstack@plt>
    9ca8:	35000220 	cbnz	w0, 9cec <fwp_main_thread+0xcc>
    9cac:	4f000400 	movi	v0.4s, #0x0
    9cb0:	910223e0 	add	x0, sp, #0x88
    9cb4:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    9cb8:	9101c021 	add	x1, x1, #0x70
    9cbc:	f90043e1 	str	x1, [sp, #128]
    9cc0:	52800082 	mov	w2, #0x4                   	// #4
    9cc4:	72a10002 	movk	w2, #0x800, lsl #16
    9cc8:	910203f9 	add	x25, sp, #0x80
    9ccc:	3d802000 	str	q0, [x0, #128]
    9cd0:	b9010be2 	str	w2, [sp, #264]
    9cd4:	ad000000 	stp	q0, q0, [x0]
    9cd8:	ad010000 	stp	q0, q0, [x0, #32]
    9cdc:	ad020000 	stp	q0, q0, [x0, #64]
    9ce0:	ad030000 	stp	q0, q0, [x0, #96]
    9ce4:	97ffe2d7 	bl	2840 <sigemptyset@plt>
    9ce8:	340000c0 	cbz	w0, 9d00 <fwp_main_thread+0xe0>
    9cec:	d0000000 	adrp	x0, b000 <__modti3+0x280>
    9cf0:	911de000 	add	x0, x0, #0x778
    9cf4:	a91773fb 	stp	x27, x28, [sp, #368]
    9cf8:	fd00c3e8 	str	d8, [sp, #384]
    9cfc:	97ffe905 	bl	4110 <fwp_trap>
    9d00:	aa1903e1 	mov	x1, x25
    9d04:	d2800002 	mov	x2, #0x0                   	// #0
    9d08:	52800160 	mov	w0, #0xb                   	// #11
    9d0c:	97ffe2e5 	bl	28a0 <sigaction@plt>
    9d10:	35fffee0 	cbnz	w0, 9cec <fwp_main_thread+0xcc>
    9d14:	aa1903e1 	mov	x1, x25
    9d18:	d2800002 	mov	x2, #0x0                   	// #0
    9d1c:	528000e0 	mov	w0, #0x7                   	// #7
    9d20:	97ffe2e0 	bl	28a0 <sigaction@plt>
    9d24:	35fffe40 	cbnz	w0, 9cec <fwp_main_thread+0xcc>
    9d28:	b9434a80 	ldr	w0, [x20, #840]
    9d2c:	34000820 	cbz	w0, 9e30 <fwp_main_thread+0x210>
    9d30:	9101c2a0 	add	x0, x21, #0x70
    9d34:	b9434c01 	ldr	w1, [x0, #844]
    9d38:	340008a1 	cbz	w1, 9e4c <fwp_main_thread+0x22c>
    9d3c:	9101c2b6 	add	x22, x21, #0x70
    9d40:	f9400ad4 	ldr	x20, [x22, #16]
    9d44:	b4001b54 	cbz	x20, a0ac <fwp_main_thread+0x48c>
    9d48:	91010297 	add	x23, x20, #0x40
    9d4c:	39414a99 	ldrb	w25, [x20, #82]
    9d50:	52800038 	mov	w24, #0x1                   	// #1
    9d54:	39014a98 	strb	w24, [x20, #82]
    9d58:	f9401680 	ldr	x0, [x20, #40]
    9d5c:	b4001a60 	cbz	x0, a0a8 <fwp_main_thread+0x488>
    9d60:	f9403281 	ldr	x1, [x20, #96]
    9d64:	39414680 	ldrb	w0, [x20, #81]
    9d68:	b40015a1 	cbz	x1, a01c <fwp_main_thread+0x3fc>
    9d6c:	36001460 	tbz	w0, #0, 9ff8 <fwp_main_thread+0x3d8>
    9d70:	f9400ad3 	ldr	x19, [x22, #16]
    9d74:	f9402280 	ldr	x0, [x20, #64]
    9d78:	39414a61 	ldrb	w1, [x19, #82]
    9d7c:	37001861 	tbnz	w1, #0, a088 <fwp_main_thread+0x468>
    9d80:	f9403261 	ldr	x1, [x19, #96]
    9d84:	a911fe77 	stp	x23, xzr, [x19, #280]
    9d88:	f9009660 	str	x0, [x19, #296]
    9d8c:	b4000040 	cbz	x0, 9d94 <fwp_main_thread+0x174>
    9d90:	f9009013 	str	x19, [x0, #288]
    9d94:	f9002293 	str	x19, [x20, #64]
    9d98:	b4000101 	cbz	x1, 9db8 <fwp_main_thread+0x198>
    9d9c:	f9406ec0 	ldr	x0, [x22, #216]
    9da0:	39015678 	strb	w24, [x19, #85]
    9da4:	f9003661 	str	x1, [x19, #104]
    9da8:	a910827f 	stp	xzr, x0, [x19, #264]
    9dac:	b4000040 	cbz	x0, 9db4 <fwp_main_thread+0x194>
    9db0:	f9008413 	str	x19, [x0, #264]
    9db4:	f9006ed3 	str	x19, [x22, #216]
    9db8:	39015a7f 	strb	wzr, [x19, #86]
    9dbc:	97fff271 	bl	6780 <fwp_block>
    9dc0:	f9408e62 	ldr	x2, [x19, #280]
    9dc4:	b4000142 	cbz	x2, 9dec <fwp_main_thread+0x1cc>
    9dc8:	a9520261 	ldp	x1, x0, [x19, #288]
    9dcc:	b40016a1 	cbz	x1, a0a0 <fwp_main_thread+0x480>
    9dd0:	f9009420 	str	x0, [x1, #296]
    9dd4:	f9409660 	ldr	x0, [x19, #296]
    9dd8:	b4000040 	cbz	x0, 9de0 <fwp_main_thread+0x1c0>
    9ddc:	f9009001 	str	x1, [x0, #288]
    9de0:	91080260 	add	x0, x19, #0x200
    9de4:	f900967f 	str	xzr, [x19, #296]
    9de8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9dec:	39415660 	ldrb	w0, [x19, #85]
    9df0:	3607fb40 	tbz	w0, #0, 9d58 <fwp_main_thread+0x138>
    9df4:	a9508261 	ldp	x1, x0, [x19, #264]
    9df8:	b4002681 	cbz	x1, a2c8 <fwp_main_thread+0x6a8>
    9dfc:	f9008820 	str	x0, [x1, #272]
    9e00:	b4000040 	cbz	x0, 9e08 <fwp_main_thread+0x1e8>
    9e04:	f9008401 	str	x1, [x0, #264]
    9e08:	91080260 	add	x0, x19, #0x200
    9e0c:	3901567f 	strb	wzr, [x19, #85]
    9e10:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9e14:	17ffffd1 	b	9d58 <fwp_main_thread+0x138>
    9e18:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9e1c:	91301000 	add	x0, x0, #0xc04
    9e20:	940004b4 	bl	b0f0 <atexit>
    9e24:	17ffff92 	b	9c6c <fwp_main_thread+0x4c>
    9e28:	97ffe7d2 	bl	3d70 <fwp_heap_init>
    9e2c:	17ffff8d 	b	9c60 <fwp_main_thread+0x40>
    9e30:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9e34:	91058000 	add	x0, x0, #0x160
    9e38:	940004ae 	bl	b0f0 <atexit>
    9e3c:	35005440 	cbnz	w0, a8c4 <fwp_main_thread+0xca4>
    9e40:	52800020 	mov	w0, #0x1                   	// #1
    9e44:	b9034a80 	str	w0, [x20, #840]
    9e48:	17ffffba 	b	9d30 <fwp_main_thread+0x110>
    9e4c:	d0000001 	adrp	x1, b000 <__modti3+0x280>
    9e50:	a91773fb 	stp	x27, x28, [sp, #368]
    9e54:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9e58:	f9418805 	ldr	x5, [x0, #784]
    9e5c:	fd00c3e8 	str	d8, [sp, #384]
    9e60:	913d4042 	add	x2, x2, #0xf50
    9e64:	fd477028 	ldr	d8, [x1, #3808]
    9e68:	91174274 	add	x20, x19, #0x5d0
    9e6c:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    9e70:	d2800004 	mov	x4, #0x0                   	// #0
    9e74:	91330021 	add	x1, x1, #0xcc0
    9e78:	d290001c 	mov	x28, #0x8000                	// #32768
    9e7c:	d280001a 	mov	x26, #0x0                   	// #0
    9e80:	a9028be5 	stp	x5, x2, [sp, #40]
    9e84:	a903fff7 	stp	x23, xzr, [sp, #56]
    9e88:	f9002bff 	str	xzr, [sp, #80]
    9e8c:	f9002fe1 	str	x1, [sp, #88]
    9e90:	f9018816 	str	x22, [x0, #784]
    9e94:	14000041 	b	9f98 <fwp_main_thread+0x378>
    9e98:	f9400301 	ldr	x1, [x24]
    9e9c:	aa2103e1 	mvn	x1, x1
    9ea0:	f8207a81 	str	x1, [x20, x0, lsl #3]
    9ea4:	f10060df 	cmp	x6, #0x18
    9ea8:	540001a9 	b.ls	9edc <fwp_main_thread+0x2bc>  // b.plast
    9eac:	d10064c2 	sub	x2, x6, #0x19
    9eb0:	91006300 	add	x0, x24, #0x18
    9eb4:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9eb8:	52800001 	mov	w1, #0x0                   	// #0
    9ebc:	91002042 	add	x2, x2, #0x8
    9ec0:	a90013e6 	stp	x6, x4, [sp]
    9ec4:	b90013e7 	str	w7, [sp, #16]
    9ec8:	f9000fe5 	str	x5, [sp, #24]
    9ecc:	97ffe261 	bl	2850 <memset@plt>
    9ed0:	a94013e6 	ldp	x6, x4, [sp]
    9ed4:	f9400fe5 	ldr	x5, [sp, #24]
    9ed8:	b94013e7 	ldr	w7, [sp, #16]
    9edc:	f94a1280 	ldr	x0, [x20, #5152]
    9ee0:	ab060000 	adds	x0, x0, x6
    9ee4:	54005442 	b.cs	a96c <fwp_main_thread+0xd4c>  // b.hs, b.nlast
    9ee8:	f94a1681 	ldr	x1, [x20, #5160]
    9eec:	f90a1280 	str	x0, [x20, #5152]
    9ef0:	eb01001f 	cmp	x0, x1
    9ef4:	54000049 	b.ls	9efc <fwp_main_thread+0x2dc>  // b.plast
    9ef8:	f90a1680 	str	x0, [x20, #5160]
    9efc:	1e6300e1 	ucvtf	d1, w7
    9f00:	fd4a1e80 	ldr	d0, [x20, #5176]
    9f04:	1e612800 	fadd	d0, d0, d1
    9f08:	fd0a1e80 	str	d0, [x20, #5176]
    9f0c:	a900931b 	stp	x27, x4, [x24, #8]
    9f10:	aa1803e4 	mov	x4, x24
    9f14:	fd000308 	str	d8, [x24]
    9f18:	f949da81 	ldr	x1, [x20, #5040]
    9f1c:	f949ee80 	ldr	x0, [x20, #5080]
    9f20:	cb010301 	sub	x1, x24, x1
    9f24:	eb00403f 	cmp	x1, x0, lsl #16
    9f28:	54000322 	b.cs	9f8c <fwp_main_thread+0x36c>  // b.hs, b.nlast
    9f2c:	d350fc20 	lsr	x0, x1, #16
    9f30:	f949fe87 	ldr	x7, [x20, #5112]
    9f34:	8b000800 	add	x0, x0, x0, lsl #2
    9f38:	d37df002 	lsl	x2, x0, #3
    9f3c:	8b0200e6 	add	x6, x7, x2
    9f40:	f94010c0 	ldr	x0, [x6, #32]
    9f44:	b4000240 	cbz	x0, 9f8c <fwp_main_thread+0x36c>
    9f48:	386268e2 	ldrb	w2, [x7, x2]
    9f4c:	7100085f 	cmp	w2, #0x2
    9f50:	54001b60 	b.eq	a2bc <fwp_main_thread+0x69c>  // b.none
    9f54:	7100045f 	cmp	w2, #0x1
    9f58:	540001a1 	b.ne	9f8c <fwp_main_thread+0x36c>  // b.any
    9f5c:	294308c7 	ldp	w7, w2, [x6, #24]
    9f60:	92403c21 	and	x1, x1, #0xffff
    9f64:	9b077c21 	mul	x1, x1, x7
    9f68:	d360fc21 	lsr	x1, x1, #32
    9f6c:	eb02003f 	cmp	x1, x2
    9f70:	540000e2 	b.cs	9f8c <fwp_main_thread+0x36c>  // b.hs, b.nlast
    9f74:	8b010000 	add	x0, x0, x1
    9f78:	39400001 	ldrb	w1, [x0]
    9f7c:	7103fc3f 	cmp	w1, #0xff
    9f80:	54004000 	b.eq	a780 <fwp_main_thread+0xb60>  // b.none
    9f84:	52800021 	mov	w1, #0x1                   	// #1
    9f88:	39000001 	strb	w1, [x0]
    9f8c:	a9047ff8 	stp	x24, xzr, [sp, #64]
    9f90:	aa05037b 	orr	x27, x27, x5
    9f94:	b40019fb 	cbz	x27, a2d0 <fwp_main_thread+0x6b0>
    9f98:	b953a680 	ldr	w0, [x20, #5028]
    9f9c:	f100079b 	subs	x27, x28, #0x1
    9fa0:	f90027fb 	str	x27, [sp, #72]
    9fa4:	da1f0345 	sbc	x5, x26, xzr
    9fa8:	aa1b03fc 	mov	x28, x27
    9fac:	aa0503fa 	mov	x26, x5
    9fb0:	340005e0 	cbz	w0, a06c <fwp_main_thread+0x44c>
    9fb4:	397e8a80 	ldrb	w0, [x20, #4002]
    9fb8:	910f0001 	add	x1, x0, #0x3c0
    9fbc:	8b000400 	add	x0, x0, x0, lsl #1
    9fc0:	b8617a87 	ldr	w7, [x20, x1, lsl #2]
    9fc4:	8b000e81 	add	x1, x20, x0, lsl #3
    9fc8:	f8607a98 	ldr	x24, [x20, x0, lsl #3]
    9fcc:	2a0703e6 	mov	w6, w7
    9fd0:	b5fff658 	cbnz	x24, 9e98 <fwp_main_thread+0x278>
    9fd4:	f9400438 	ldr	x24, [x1, #8]
    9fd8:	b40004b8 	cbz	x24, a06c <fwp_main_thread+0x44c>
    9fdc:	f9400820 	ldr	x0, [x1, #16]
    9fe0:	cb180000 	sub	x0, x0, x24
    9fe4:	eb0000df 	cmp	x6, x0
    9fe8:	54000428 	b.hi	a06c <fwp_main_thread+0x44c>  // b.pmore
    9fec:	8b060300 	add	x0, x24, x6
    9ff0:	f9000420 	str	x0, [x1, #8]
    9ff4:	17ffffac 	b	9ea4 <fwp_main_thread+0x284>
    9ff8:	97ffea66 	bl	4990 <fwp_now_ns>
    9ffc:	f9403281 	ldr	x1, [x20, #96]
    a000:	eb01001f 	cmp	x0, x1
    a004:	540000ab 	b.lt	a018 <fwp_main_thread+0x3f8>  // b.tstop
    a008:	39414280 	ldrb	w0, [x20, #80]
    a00c:	37000060 	tbnz	w0, #0, a018 <fwp_main_thread+0x3f8>
    a010:	aa1403e0 	mov	x0, x20
    a014:	97ffe5b7 	bl	36f0 <fwp_cancel_tree.part.0>
    a018:	39414680 	ldrb	w0, [x20, #81]
    a01c:	f9400ad3 	ldr	x19, [x22, #16]
    a020:	39414a62 	ldrb	w2, [x19, #82]
    a024:	3707ea60 	tbnz	w0, #0, 9d70 <fwp_main_thread+0x150>
    a028:	f9403281 	ldr	x1, [x20, #96]
    a02c:	370001c2 	tbnz	w2, #0, a064 <fwp_main_thread+0x444>
    a030:	f9403260 	ldr	x0, [x19, #96]
    a034:	b4000180 	cbz	x0, a064 <fwp_main_thread+0x444>
    a038:	b4000061 	cbz	x1, a044 <fwp_main_thread+0x424>
    a03c:	eb01001f 	cmp	x0, x1
    a040:	9a81d000 	csel	x0, x0, x1, le
    a044:	f9402281 	ldr	x1, [x20, #64]
    a048:	a911fe77 	stp	x23, xzr, [x19, #280]
    a04c:	f9009661 	str	x1, [x19, #296]
    a050:	b4003a41 	cbz	x1, a798 <fwp_main_thread+0xb78>
    a054:	f9009033 	str	x19, [x1, #288]
    a058:	aa0003e1 	mov	x1, x0
    a05c:	f9002293 	str	x19, [x20, #64]
    a060:	17ffff4f 	b	9d9c <fwp_main_thread+0x17c>
    a064:	f9402280 	ldr	x0, [x20, #64]
    a068:	17ffff47 	b	9d84 <fwp_main_thread+0x164>
    a06c:	52800001 	mov	w1, #0x0                   	// #0
    a070:	d2800300 	mov	x0, #0x18                  	// #24
    a074:	a90017e4 	stp	x4, x5, [sp]
    a078:	97ffeb9e 	bl	4ef0 <fwp_heap_alloc>
    a07c:	aa0003f8 	mov	x24, x0
    a080:	a94017e4 	ldp	x4, x5, [sp]
    a084:	17ffffa2 	b	9f0c <fwp_main_thread+0x2ec>
    a088:	a911fe77 	stp	x23, xzr, [x19, #280]
    a08c:	f9009660 	str	x0, [x19, #296]
    a090:	b4000040 	cbz	x0, a098 <fwp_main_thread+0x478>
    a094:	f9009013 	str	x19, [x0, #288]
    a098:	f9002293 	str	x19, [x20, #64]
    a09c:	17ffff47 	b	9db8 <fwp_main_thread+0x198>
    a0a0:	f9000040 	str	x0, [x2]
    a0a4:	17ffff4d 	b	9dd8 <fwp_main_thread+0x1b8>
    a0a8:	39014a99 	strb	w25, [x20, #82]
    a0ac:	9101c2b3 	add	x19, x21, #0x70
    a0b0:	f9419660 	ldr	x0, [x19, #808]
    a0b4:	b5000060 	cbnz	x0, a0c0 <fwp_main_thread+0x4a0>
    a0b8:	f9419e60 	ldr	x0, [x19, #824]
    a0bc:	b40038c0 	cbz	x0, a7d4 <fwp_main_thread+0xbb4>
    a0c0:	9101c2a0 	add	x0, x21, #0x70
    a0c4:	f9400800 	ldr	x0, [x0, #16]
    a0c8:	9101c2a1 	add	x1, x21, #0x70
    a0cc:	f941b025 	ldr	x5, [x1, #864]
    a0d0:	b903583f 	str	wzr, [x1, #856]
    a0d4:	eb0000bf 	cmp	x5, x0
    a0d8:	540048e1 	b.ne	a9f4 <fwp_main_thread+0xdd4>  // b.any
    a0dc:	b40003c0 	cbz	x0, a154 <fwp_main_thread+0x534>
    a0e0:	f9418026 	ldr	x6, [x1, #768]
    a0e4:	52800021 	mov	w1, #0x1                   	// #1
    a0e8:	39014801 	strb	w1, [x0, #82]
    a0ec:	b4000346 	cbz	x6, a154 <fwp_main_thread+0x534>
    a0f0:	394140c0 	ldrb	w0, [x6, #80]
    a0f4:	37000060 	tbnz	w0, #0, a100 <fwp_main_thread+0x4e0>
    a0f8:	aa0603e0 	mov	x0, x6
    a0fc:	97ffe57d 	bl	36f0 <fwp_cancel_tree.part.0>
    a100:	f9409cc6 	ldr	x6, [x6, #312]
    a104:	b5ffff66 	cbnz	x6, a0f0 <fwp_main_thread+0x4d0>
    a108:	9101c2b3 	add	x19, x21, #0x70
    a10c:	52800034 	mov	w20, #0x1                   	// #1
    a110:	f94028a0 	ldr	x0, [x5, #80]
    a114:	f2001c1f 	tst	x0, #0xff000000ff
    a118:	540000e1 	b.ne	a134 <fwp_main_thread+0x514>  // b.any
    a11c:	f9403e60 	ldr	x0, [x19, #120]
    a120:	390150b4 	strb	w20, [x5, #84]
    a124:	f90080bf 	str	xzr, [x5, #256]
    a128:	b4000120 	cbz	x0, a14c <fwp_main_thread+0x52c>
    a12c:	f9008005 	str	x5, [x0, #256]
    a130:	f9003e65 	str	x5, [x19, #120]
    a134:	97fff193 	bl	6780 <fwp_block>
    a138:	97fff11a 	bl	65a0 <fwp_free_zombie>
    a13c:	f9418260 	ldr	x0, [x19, #768]
    a140:	b40000a0 	cbz	x0, a154 <fwp_main_thread+0x534>
    a144:	f941b265 	ldr	x5, [x19, #864]
    a148:	17fffff2 	b	a110 <fwp_main_thread+0x4f0>
    a14c:	f9004265 	str	x5, [x19, #128]
    a150:	17fffff8 	b	a130 <fwp_main_thread+0x510>
    a154:	9101c2b4 	add	x20, x21, #0x70
    a158:	97fff112 	bl	65a0 <fwp_free_zombie>
    a15c:	f9404280 	ldr	x0, [x20, #128]
    a160:	b50044a0 	cbnz	x0, a9f4 <fwp_main_thread+0xdd4>
    a164:	f9406e80 	ldr	x0, [x20, #216]
    a168:	b5004460 	cbnz	x0, a9f4 <fwp_main_thread+0xdd4>
    a16c:	b940fa80 	ldr	w0, [x20, #248]
    a170:	340001e0 	cbz	w0, a1ac <fwp_main_thread+0x58c>
    a174:	93407c16 	sxtw	x22, w0
    a178:	51000400 	sub	w0, w0, #0x1
    a17c:	d1000ad6 	sub	x22, x22, #0x2
    a180:	91040297 	add	x23, x20, #0x100
    a184:	cb2042d6 	sub	x22, x22, w0, uxtw
    a188:	93407c13 	sxtw	x19, w0
    a18c:	d503201f 	nop
    a190:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    a194:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a198:	b900fa93 	str	w19, [x20, #248]
    a19c:	d1000673 	sub	x19, x19, #0x1
    a1a0:	97ffe200 	bl	29a0 <munmap@plt>
    a1a4:	eb16027f 	cmp	x19, x22
    a1a8:	54ffff41 	b.ne	a190 <fwp_main_thread+0x570>  // b.any
    a1ac:	d00000b3 	adrp	x19, 20000 <__data_start>
    a1b0:	91004260 	add	x0, x19, #0x10
    a1b4:	b9404000 	ldr	w0, [x0, #64]
    a1b8:	37f80040 	tbnz	w0, #31, a1c0 <fwp_main_thread+0x5a0>
    a1bc:	97ffe1b5 	bl	2890 <close@plt>
    a1c0:	9101c2b4 	add	x20, x21, #0x70
    a1c4:	91004273 	add	x19, x19, #0x10
    a1c8:	12800001 	mov	w1, #0xffffffff            	// #-1
    a1cc:	f941ba80 	ldr	x0, [x20, #880]
    a1d0:	b9004261 	str	w1, [x19, #64]
    a1d4:	f941b681 	ldr	x1, [x20, #872]
    a1d8:	b40001c0 	cbz	x0, a210 <fwp_main_thread+0x5f0>
    a1dc:	d2800013 	mov	x19, #0x0                   	// #0
    a1e0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    a1e4:	b40000e0 	cbz	x0, a200 <fwp_main_thread+0x5e0>
    a1e8:	f9400001 	ldr	x1, [x0]
    a1ec:	b5004041 	cbnz	x1, a9f4 <fwp_main_thread+0xdd4>
    a1f0:	f9400401 	ldr	x1, [x0, #8]
    a1f4:	b5004001 	cbnz	x1, a9f4 <fwp_main_thread+0xdd4>
    a1f8:	97ffe882 	bl	4400 <fwp_mem_free>
    a1fc:	f941b681 	ldr	x1, [x20, #872]
    a200:	91000673 	add	x19, x19, #0x1
    a204:	f941ba80 	ldr	x0, [x20, #880]
    a208:	eb00027f 	cmp	x19, x0
    a20c:	54fffea3 	b.cc	a1e0 <fwp_main_thread+0x5c0>  // b.lo, b.ul, b.last
    a210:	aa0103e0 	mov	x0, x1
    a214:	97ffe87b 	bl	4400 <fwp_mem_free>
    a218:	9101c2a0 	add	x0, x21, #0x70
    a21c:	f941b013 	ldr	x19, [x0, #864]
    a220:	f901b41f 	str	xzr, [x0, #872]
    a224:	f901b81f 	str	xzr, [x0, #880]
    a228:	b40001f3 	cbz	x19, a264 <fwp_main_thread+0x644>
    a22c:	f9401661 	ldr	x1, [x19, #40]
    a230:	b5003e21 	cbnz	x1, a9f4 <fwp_main_thread+0xdd4>
    a234:	f9405661 	ldr	x1, [x19, #168]
    a238:	b5003de1 	cbnz	x1, a9f4 <fwp_main_thread+0xdd4>
    a23c:	f9419401 	ldr	x1, [x0, #808]
    a240:	b5003da1 	cbnz	x1, a9f4 <fwp_main_thread+0xdd4>
    a244:	f9419c00 	ldr	x0, [x0, #824]
    a248:	b5003d60 	cbnz	x0, a9f4 <fwp_main_thread+0xdd4>
    a24c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a250:	d0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    a254:	910fc000 	add	x0, x0, #0x3f0
    a258:	97ffe17e 	bl	2850 <memset@plt>
    a25c:	aa1303e0 	mov	x0, x19
    a260:	97ffe868 	bl	4400 <fwp_mem_free>
    a264:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a268:	f947ec00 	ldr	x0, [x0, #4056]
    a26c:	9101c2b5 	add	x21, x21, #0x70
    a270:	f9400000 	ldr	x0, [x0]
    a274:	f9000abf 	str	xzr, [x21, #16]
    a278:	f901b2bf 	str	xzr, [x21, #864]
    a27c:	97ffe1cd 	bl	29b0 <fflush@plt>
    a280:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a284:	f947f400 	ldr	x0, [x0, #4072]
    a288:	f9408fe2 	ldr	x2, [sp, #280]
    a28c:	f9400001 	ldr	x1, [x0]
    a290:	eb010042 	subs	x2, x2, x1
    a294:	d2800001 	mov	x1, #0x0                   	// #0
    a298:	540036c1 	b.ne	a970 <fwp_main_thread+0xd50>  // b.any
    a29c:	a9527bfd 	ldp	x29, x30, [sp, #288]
    a2a0:	d2800000 	mov	x0, #0x0                   	// #0
    a2a4:	a95353f3 	ldp	x19, x20, [sp, #304]
    a2a8:	a9545bf5 	ldp	x21, x22, [sp, #320]
    a2ac:	a95563f7 	ldp	x23, x24, [sp, #336]
    a2b0:	a9566bf9 	ldp	x25, x26, [sp, #352]
    a2b4:	910643ff 	add	sp, sp, #0x190
    a2b8:	d65f03c0 	ret
    a2bc:	72003c3f 	tst	w1, #0xffff
    a2c0:	54ffe661 	b.ne	9f8c <fwp_main_thread+0x36c>  // b.any
    a2c4:	17ffff2d 	b	9f78 <fwp_main_thread+0x358>
    a2c8:	f9006ec0 	str	x0, [x22, #216]
    a2cc:	17fffecd 	b	9e00 <fwp_main_thread+0x1e0>
    a2d0:	9101c2a2 	add	x2, x21, #0x70
    a2d4:	f90023ff 	str	xzr, [sp, #64]
    a2d8:	f9418840 	ldr	x0, [x2, #784]
    a2dc:	eb16001f 	cmp	x0, x22
    a2e0:	540038e1 	b.ne	a9fc <fwp_main_thread+0xddc>  // b.any
    a2e4:	b0000000 	adrp	x0, b000 <__modti3+0x280>
    a2e8:	910183e1 	add	x1, sp, #0x60
    a2ec:	f94017e3 	ldr	x3, [sp, #40]
    a2f0:	f9018843 	str	x3, [x2, #784]
    a2f4:	3dc3c000 	ldr	q0, [x0, #3840]
    a2f8:	52800020 	mov	w0, #0x1                   	// #1
    a2fc:	3d801be0 	str	q0, [sp, #96]
    a300:	97ffedbc 	bl	59f0 <fwp_data.part.0.constprop.0>
    a304:	91174263 	add	x3, x19, #0x5d0
    a308:	aa0003f4 	mov	x20, x0
    a30c:	f949d861 	ldr	x1, [x3, #5040]
    a310:	f949ec60 	ldr	x0, [x3, #5080]
    a314:	cb010281 	sub	x1, x20, x1
    a318:	eb00403f 	cmp	x1, x0, lsl #16
    a31c:	54000322 	b.cs	a380 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a320:	d350fc22 	lsr	x2, x1, #16
    a324:	f949fc63 	ldr	x3, [x3, #5112]
    a328:	8b020842 	add	x2, x2, x2, lsl #2
    a32c:	d37df042 	lsl	x2, x2, #3
    a330:	8b020060 	add	x0, x3, x2
    a334:	f9401016 	ldr	x22, [x0, #32]
    a338:	b4000256 	cbz	x22, a380 <fwp_main_thread+0x760>
    a33c:	38626862 	ldrb	w2, [x3, x2]
    a340:	7100085f 	cmp	w2, #0x2
    a344:	540023c0 	b.eq	a7bc <fwp_main_thread+0xb9c>  // b.none
    a348:	7100045f 	cmp	w2, #0x1
    a34c:	540001a1 	b.ne	a380 <fwp_main_thread+0x760>  // b.any
    a350:	29430002 	ldp	w2, w0, [x0, #24]
    a354:	92403c21 	and	x1, x1, #0xffff
    a358:	9b027c21 	mul	x1, x1, x2
    a35c:	d360fc21 	lsr	x1, x1, #32
    a360:	eb00003f 	cmp	x1, x0
    a364:	540000e2 	b.cs	a380 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a368:	8b0102d6 	add	x22, x22, x1
    a36c:	394002c0 	ldrb	w0, [x22]
    a370:	7103fc1f 	cmp	w0, #0xff
    a374:	54002580 	b.eq	a824 <fwp_main_thread+0xc04>  // b.none
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	390002c0 	strb	w0, [x22]
    a380:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a384:	aa1903e1 	mov	x1, x25
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	a90853e2 	stp	x2, x20, [sp, #128]
    a390:	97ffed98 	bl	59f0 <fwp_data.part.0.constprop.0>
    a394:	91174263 	add	x3, x19, #0x5d0
    a398:	aa0003f4 	mov	x20, x0
    a39c:	f949d861 	ldr	x1, [x3, #5040]
    a3a0:	f949ec60 	ldr	x0, [x3, #5080]
    a3a4:	cb010281 	sub	x1, x20, x1
    a3a8:	eb00403f 	cmp	x1, x0, lsl #16
    a3ac:	54000322 	b.cs	a410 <fwp_main_thread+0x7f0>  // b.hs, b.nlast
    a3b0:	d350fc22 	lsr	x2, x1, #16
    a3b4:	f949fc63 	ldr	x3, [x3, #5112]
    a3b8:	8b020842 	add	x2, x2, x2, lsl #2
    a3bc:	d37df042 	lsl	x2, x2, #3
    a3c0:	8b020060 	add	x0, x3, x2
    a3c4:	f9401016 	ldr	x22, [x0, #32]
    a3c8:	b4000256 	cbz	x22, a410 <fwp_main_thread+0x7f0>
    a3cc:	38626862 	ldrb	w2, [x3, x2]
    a3d0:	7100085f 	cmp	w2, #0x2
    a3d4:	54001e80 	b.eq	a7a4 <fwp_main_thread+0xb84>  // b.none
    a3d8:	7100045f 	cmp	w2, #0x1
    a3dc:	540001a1 	b.ne	a410 <fwp_main_thread+0x7f0>  // b.any
    a3e0:	29430002 	ldp	w2, w0, [x0, #24]
    a3e4:	92403c21 	and	x1, x1, #0xffff
    a3e8:	9b027c21 	mul	x1, x1, x2
    a3ec:	d360fc21 	lsr	x1, x1, #32
    a3f0:	eb00003f 	cmp	x1, x0
    a3f4:	540000e2 	b.cs	a410 <fwp_main_thread+0x7f0>  // b.hs, b.nlast
    a3f8:	8b0102d6 	add	x22, x22, x1
    a3fc:	394002c0 	ldrb	w0, [x22]
    a400:	7103fc1f 	cmp	w0, #0xff
    a404:	54002160 	b.eq	a830 <fwp_main_thread+0xc10>  // b.none
    a408:	52800020 	mov	w0, #0x1                   	// #1
    a40c:	390002c0 	strb	w0, [x22]
    a410:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a414:	9101c3e1 	add	x1, sp, #0x70
    a418:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a41c:	52800020 	mov	w0, #0x1                   	// #1
    a420:	a90753e2 	stp	x2, x20, [sp, #112]
    a424:	97ffed73 	bl	59f0 <fwp_data.part.0.constprop.0>
    a428:	91174264 	add	x4, x19, #0x5d0
    a42c:	aa0003f4 	mov	x20, x0
    a430:	f949ec83 	ldr	x3, [x4, #5080]
    a434:	f949d881 	ldr	x1, [x4, #5040]
    a438:	d370bc63 	lsl	x3, x3, #16
    a43c:	cb010001 	sub	x1, x0, x1
    a440:	eb03003f 	cmp	x1, x3
    a444:	540003c2 	b.cs	a4bc <fwp_main_thread+0x89c>  // b.hs, b.nlast
    a448:	d350fc22 	lsr	x2, x1, #16
    a44c:	f949fc80 	ldr	x0, [x4, #5112]
    a450:	8b020842 	add	x2, x2, x2, lsl #2
    a454:	d37df042 	lsl	x2, x2, #3
    a458:	8b020004 	add	x4, x0, x2
    a45c:	f9401096 	ldr	x22, [x4, #32]
    a460:	b40002f6 	cbz	x22, a4bc <fwp_main_thread+0x89c>
    a464:	38626800 	ldrb	w0, [x0, x2]
    a468:	7100081f 	cmp	w0, #0x2
    a46c:	54001a20 	b.eq	a7b0 <fwp_main_thread+0xb90>  // b.none
    a470:	7100041f 	cmp	w0, #0x1
    a474:	54000241 	b.ne	a4bc <fwp_main_thread+0x89c>  // b.any
    a478:	29430885 	ldp	w5, w2, [x4, #24]
    a47c:	92403c20 	and	x0, x1, #0xffff
    a480:	9b057c00 	mul	x0, x0, x5
    a484:	d360fc00 	lsr	x0, x0, #32
    a488:	eb02001f 	cmp	x0, x2
    a48c:	54000182 	b.cs	a4bc <fwp_main_thread+0x89c>  // b.hs, b.nlast
    a490:	8b0002d6 	add	x22, x22, x0
    a494:	394002c0 	ldrb	w0, [x22]
    a498:	7103fc1f 	cmp	w0, #0xff
    a49c:	54001d00 	b.eq	a83c <fwp_main_thread+0xc1c>  // b.none
    a4a0:	91174260 	add	x0, x19, #0x5d0
    a4a4:	52800021 	mov	w1, #0x1                   	// #1
    a4a8:	390002c1 	strb	w1, [x22]
    a4ac:	f949ec03 	ldr	x3, [x0, #5080]
    a4b0:	f949d801 	ldr	x1, [x0, #5040]
    a4b4:	d370bc63 	lsl	x3, x3, #16
    a4b8:	cb010281 	sub	x1, x20, x1
    a4bc:	900000b6 	adrp	x22, 1e000 <__FRAME_END__+0x10c40>
    a4c0:	911022d6 	add	x22, x22, #0x408
    a4c4:	b0000019 	adrp	x25, b000 <__modti3+0x280>
    a4c8:	910142d6 	add	x22, x22, #0x50
    a4cc:	aa1803fa 	mov	x26, x24
    a4d0:	9130e339 	add	x25, x25, #0xc38
    a4d4:	eb03003f 	cmp	x1, x3
    a4d8:	54000362 	b.cs	a544 <fwp_main_thread+0x924>  // b.hs, b.nlast
    a4dc:	91174262 	add	x2, x19, #0x5d0
    a4e0:	d350fc20 	lsr	x0, x1, #16
    a4e4:	8b000800 	add	x0, x0, x0, lsl #2
    a4e8:	f949fc44 	ldr	x4, [x2, #5112]
    a4ec:	d37df002 	lsl	x2, x0, #3
    a4f0:	8b020083 	add	x3, x4, x2
    a4f4:	f9401060 	ldr	x0, [x3, #32]
    a4f8:	b4000260 	cbz	x0, a544 <fwp_main_thread+0x924>
    a4fc:	38626882 	ldrb	w2, [x4, x2]
    a500:	7100085f 	cmp	w2, #0x2
    a504:	54001620 	b.eq	a7c8 <fwp_main_thread+0xba8>  // b.none
    a508:	7100045f 	cmp	w2, #0x1
    a50c:	540001c1 	b.ne	a544 <fwp_main_thread+0x924>  // b.any
    a510:	29430864 	ldp	w4, w2, [x3, #24]
    a514:	92403c21 	and	x1, x1, #0xffff
    a518:	9b047c21 	mul	x1, x1, x4
    a51c:	d360fc21 	lsr	x1, x1, #32
    a520:	eb02003f 	cmp	x1, x2
    a524:	54000102 	b.cs	a544 <fwp_main_thread+0x924>  // b.hs, b.nlast
    a528:	8b010000 	add	x0, x0, x1
    a52c:	39400001 	ldrb	w1, [x0]
    a530:	340000a1 	cbz	w1, a544 <fwp_main_thread+0x924>
    a534:	7103f43f 	cmp	w1, #0xfd
    a538:	54001888 	b.hi	a848 <fwp_main_thread+0xc28>  // b.pmore
    a53c:	11000421 	add	w1, w1, #0x1
    a540:	39000001 	strb	w1, [x0]
    a544:	aa1603e2 	mov	x2, x22
    a548:	aa1403e1 	mov	x1, x20
    a54c:	aa1703e0 	mov	x0, x23
    a550:	52800023 	mov	w3, #0x1                   	// #1
    a554:	a9047fff 	stp	xzr, xzr, [sp, #64]
    a558:	f9002bff 	str	xzr, [sp, #80]
    a55c:	97fff9b5 	bl	8c30 <fwp_write>
    a560:	a9440bfb 	ldp	x27, x2, [sp, #64]
    a564:	f100037f 	cmp	x27, #0x0
    a568:	9a9b033b 	csel	x27, x25, x27, eq	// eq = none
    a56c:	b100285f 	cmn	x2, #0xa
    a570:	54001708 	b.hi	a850 <fwp_main_thread+0xc30>  // b.pmore
    a574:	91002440 	add	x0, x2, #0x9
    a578:	52800021 	mov	w1, #0x1                   	// #1
    a57c:	f90003e2 	str	x2, [sp]
    a580:	97ffea5c 	bl	4ef0 <fwp_heap_alloc>
    a584:	aa1b03e1 	mov	x1, x27
    a588:	aa0003fb 	mov	x27, x0
    a58c:	f94003e2 	ldr	x2, [sp]
    a590:	aa0003fc 	mov	x28, x0
    a594:	f8008762 	str	x2, [x27], #8
    a598:	aa1b03e0 	mov	x0, x27
    a59c:	97ffe04d 	bl	26d0 <memcpy@plt>
    a5a0:	f94003e2 	ldr	x2, [sp]
    a5a4:	8b020382 	add	x2, x28, x2
    a5a8:	3900205f 	strb	wzr, [x2, #8]
    a5ac:	f94023e0 	ldr	x0, [sp, #64]
    a5b0:	97ffe0e4 	bl	2940 <free@plt>
    a5b4:	91174260 	add	x0, x19, #0x5d0
    a5b8:	f949d801 	ldr	x1, [x0, #5040]
    a5bc:	f949ec02 	ldr	x2, [x0, #5080]
    a5c0:	cb010381 	sub	x1, x28, x1
    a5c4:	eb02403f 	cmp	x1, x2, lsl #16
    a5c8:	54000322 	b.cs	a62c <fwp_main_thread+0xa0c>  // b.hs, b.nlast
    a5cc:	d350fc22 	lsr	x2, x1, #16
    a5d0:	d2800503 	mov	x3, #0x28                  	// #40
    a5d4:	f949fc04 	ldr	x4, [x0, #5112]
    a5d8:	9b037c42 	mul	x2, x2, x3
    a5dc:	8b020083 	add	x3, x4, x2
    a5e0:	f9401060 	ldr	x0, [x3, #32]
    a5e4:	b4000240 	cbz	x0, a62c <fwp_main_thread+0xa0c>
    a5e8:	38626882 	ldrb	w2, [x4, x2]
    a5ec:	7100085f 	cmp	w2, #0x2
    a5f0:	54001480 	b.eq	a880 <fwp_main_thread+0xc60>  // b.none
    a5f4:	7100045f 	cmp	w2, #0x1
    a5f8:	540001a1 	b.ne	a62c <fwp_main_thread+0xa0c>  // b.any
    a5fc:	29430864 	ldp	w4, w2, [x3, #24]
    a600:	92403c21 	and	x1, x1, #0xffff
    a604:	9b047c21 	mul	x1, x1, x4
    a608:	d360fc21 	lsr	x1, x1, #32
    a60c:	eb02003f 	cmp	x1, x2
    a610:	540000e2 	b.cs	a62c <fwp_main_thread+0xa0c>  // b.hs, b.nlast
    a614:	8b010000 	add	x0, x0, x1
    a618:	39400001 	ldrb	w1, [x0]
    a61c:	7103fc3f 	cmp	w1, #0xff
    a620:	54001760 	b.eq	a90c <fwp_main_thread+0xcec>  // b.none
    a624:	52800021 	mov	w1, #0x1                   	// #1
    a628:	39000001 	strb	w1, [x0]
    a62c:	aa1403e0 	mov	x0, x20
    a630:	91174264 	add	x4, x19, #0x5d0
    a634:	f949d881 	ldr	x1, [x4, #5040]
    a638:	f949ec82 	ldr	x2, [x4, #5080]
    a63c:	cb010001 	sub	x1, x0, x1
    a640:	eb02403f 	cmp	x1, x2, lsl #16
    a644:	54000382 	b.cs	a6b4 <fwp_main_thread+0xa94>  // b.hs, b.nlast
    a648:	d350fc23 	lsr	x3, x1, #16
    a64c:	d2800502 	mov	x2, #0x28                  	// #40
    a650:	f949fc86 	ldr	x6, [x4, #5112]
    a654:	9b027c63 	mul	x3, x3, x2
    a658:	8b0300c5 	add	x5, x6, x3
    a65c:	f94010a2 	ldr	x2, [x5, #32]
    a660:	b40002a2 	cbz	x2, a6b4 <fwp_main_thread+0xa94>
    a664:	386368c3 	ldrb	w3, [x6, x3]
    a668:	7100087f 	cmp	w3, #0x2
    a66c:	54001040 	b.eq	a874 <fwp_main_thread+0xc54>  // b.none
    a670:	7100047f 	cmp	w3, #0x1
    a674:	54000201 	b.ne	a6b4 <fwp_main_thread+0xa94>  // b.any
    a678:	29430ca6 	ldp	w6, w3, [x5, #24]
    a67c:	92403c21 	and	x1, x1, #0xffff
    a680:	9b067c21 	mul	x1, x1, x6
    a684:	d360fc21 	lsr	x1, x1, #32
    a688:	eb03003f 	cmp	x1, x3
    a68c:	54000142 	b.cs	a6b4 <fwp_main_thread+0xa94>  // b.hs, b.nlast
    a690:	8b010042 	add	x2, x2, x1
    a694:	39400041 	ldrb	w1, [x2]
    a698:	340000e1 	cbz	w1, a6b4 <fwp_main_thread+0xa94>
    a69c:	7100043f 	cmp	w1, #0x1
    a6a0:	54000de0 	b.eq	a85c <fwp_main_thread+0xc3c>  // b.none
    a6a4:	7103fc3f 	cmp	w1, #0xff
    a6a8:	54001140 	b.eq	a8d0 <fwp_main_thread+0xcb0>  // b.none
    a6ac:	51000421 	sub	w1, w1, #0x1
    a6b0:	39000041 	strb	w1, [x2]
    a6b4:	9101c2a3 	add	x3, x21, #0x70
    a6b8:	aa1b03e0 	mov	x0, x27
    a6bc:	f9400382 	ldr	x2, [x28]
    a6c0:	aa0303fb 	mov	x27, x3
    a6c4:	f9400463 	ldr	x3, [x3, #8]
    a6c8:	d2800021 	mov	x1, #0x1                   	// #1
    a6cc:	97ffe0ad 	bl	2980 <fwrite@plt>
    a6d0:	f9400761 	ldr	x1, [x27, #8]
    a6d4:	52800140 	mov	w0, #0xa                   	// #10
    a6d8:	97ffe032 	bl	27a0 <fputc@plt>
    a6dc:	91174262 	add	x2, x19, #0x5d0
    a6e0:	f949d841 	ldr	x1, [x2, #5040]
    a6e4:	f949ec40 	ldr	x0, [x2, #5080]
    a6e8:	cb010381 	sub	x1, x28, x1
    a6ec:	eb00403f 	cmp	x1, x0, lsl #16
    a6f0:	54000382 	b.cs	a760 <fwp_main_thread+0xb40>  // b.hs, b.nlast
    a6f4:	d350fc20 	lsr	x0, x1, #16
    a6f8:	d2800504 	mov	x4, #0x28                  	// #40
    a6fc:	f949fc43 	ldr	x3, [x2, #5112]
    a700:	9b047c00 	mul	x0, x0, x4
    a704:	8b000062 	add	x2, x3, x0
    a708:	f940105b 	ldr	x27, [x2, #32]
    a70c:	b40002bb 	cbz	x27, a760 <fwp_main_thread+0xb40>
    a710:	38606863 	ldrb	w3, [x3, x0]
    a714:	7100087f 	cmp	w3, #0x2
    a718:	54000cc0 	b.eq	a8b0 <fwp_main_thread+0xc90>  // b.none
    a71c:	7100047f 	cmp	w3, #0x1
    a720:	54000201 	b.ne	a760 <fwp_main_thread+0xb40>  // b.any
    a724:	29431040 	ldp	w0, w4, [x2, #24]
    a728:	92403c21 	and	x1, x1, #0xffff
    a72c:	9b007c20 	mul	x0, x1, x0
    a730:	d360fc00 	lsr	x0, x0, #32
    a734:	eb04001f 	cmp	x0, x4
    a738:	54000142 	b.cs	a760 <fwp_main_thread+0xb40>  // b.hs, b.nlast
    a73c:	8b00037b 	add	x27, x27, x0
    a740:	39400360 	ldrb	w0, [x27]
    a744:	340000e0 	cbz	w0, a760 <fwp_main_thread+0xb40>
    a748:	7100041f 	cmp	w0, #0x1
    a74c:	54000a00 	b.eq	a88c <fwp_main_thread+0xc6c>  // b.none
    a750:	7103fc1f 	cmp	w0, #0xff
    a754:	54001140 	b.eq	a97c <fwp_main_thread+0xd5c>  // b.none
    a758:	51000400 	sub	w0, w0, #0x1
    a75c:	39000360 	strb	w0, [x27]
    a760:	f9400b5a 	ldr	x26, [x26, #16]
    a764:	b40004ba 	cbz	x26, a7f8 <fwp_main_thread+0xbd8>
    a768:	91174260 	add	x0, x19, #0x5d0
    a76c:	f949ec03 	ldr	x3, [x0, #5080]
    a770:	f949d801 	ldr	x1, [x0, #5040]
    a774:	d370bc63 	lsl	x3, x3, #16
    a778:	cb010281 	sub	x1, x20, x1
    a77c:	17ffff56 	b	a4d4 <fwp_main_thread+0x8b4>
    a780:	a90013e0 	stp	x0, x4, [sp]
    a784:	f9000be5 	str	x5, [sp, #16]
    a788:	97ffe682 	bl	4190 <fwp_rc_forget_slot.part.0>
    a78c:	a94013e0 	ldp	x0, x4, [sp]
    a790:	f9400be5 	ldr	x5, [sp, #16]
    a794:	17fffdfc 	b	9f84 <fwp_main_thread+0x364>
    a798:	aa0003e1 	mov	x1, x0
    a79c:	f9002293 	str	x19, [x20, #64]
    a7a0:	17fffd7f 	b	9d9c <fwp_main_thread+0x17c>
    a7a4:	72003c3f 	tst	w1, #0xffff
    a7a8:	54ffe341 	b.ne	a410 <fwp_main_thread+0x7f0>  // b.any
    a7ac:	17ffff14 	b	a3fc <fwp_main_thread+0x7dc>
    a7b0:	72003c3f 	tst	w1, #0xffff
    a7b4:	54ffe841 	b.ne	a4bc <fwp_main_thread+0x89c>  // b.any
    a7b8:	17ffff37 	b	a494 <fwp_main_thread+0x874>
    a7bc:	72003c3f 	tst	w1, #0xffff
    a7c0:	54ffde01 	b.ne	a380 <fwp_main_thread+0x760>  // b.any
    a7c4:	17fffeea 	b	a36c <fwp_main_thread+0x74c>
    a7c8:	72003c3f 	tst	w1, #0xffff
    a7cc:	54ffebc1 	b.ne	a544 <fwp_main_thread+0x924>  // b.any
    a7d0:	17ffff57 	b	a52c <fwp_main_thread+0x90c>
    a7d4:	f9419260 	ldr	x0, [x19, #800]
    a7d8:	97ffe70a 	bl	4400 <fwp_mem_free>
    a7dc:	f901927f 	str	xzr, [x19, #800]
    a7e0:	f9400a60 	ldr	x0, [x19, #16]
    a7e4:	f9019a7f 	str	xzr, [x19, #816]
    a7e8:	b4ffc700 	cbz	x0, a0c8 <fwp_main_thread+0x4a8>
    a7ec:	f900541f 	str	xzr, [x0, #168]
    a7f0:	f9005c1f 	str	xzr, [x0, #184]
    a7f4:	17fffe35 	b	a0c8 <fwp_main_thread+0x4a8>
    a7f8:	aa1403e0 	mov	x0, x20
    a7fc:	97ffed8d 	bl	5e30 <fwp_drop0>
    a800:	aa1803e0 	mov	x0, x24
    a804:	97ffed8b 	bl	5e30 <fwp_drop0>
    a808:	9101c2a0 	add	x0, x21, #0x70
    a80c:	fd40c3e8 	ldr	d8, [sp, #384]
    a810:	a95773fb 	ldp	x27, x28, [sp, #368]
    a814:	52800021 	mov	w1, #0x1                   	// #1
    a818:	b9034c01 	str	w1, [x0, #844]
    a81c:	f901a81f 	str	xzr, [x0, #848]
    a820:	17fffd47 	b	9d3c <fwp_main_thread+0x11c>
    a824:	aa1603e0 	mov	x0, x22
    a828:	97ffe65a 	bl	4190 <fwp_rc_forget_slot.part.0>
    a82c:	17fffed3 	b	a378 <fwp_main_thread+0x758>
    a830:	aa1603e0 	mov	x0, x22
    a834:	97ffe657 	bl	4190 <fwp_rc_forget_slot.part.0>
    a838:	17fffef4 	b	a408 <fwp_main_thread+0x7e8>
    a83c:	aa1603e0 	mov	x0, x22
    a840:	97ffe654 	bl	4190 <fwp_rc_forget_slot.part.0>
    a844:	17ffff17 	b	a4a0 <fwp_main_thread+0x880>
    a848:	97ffe767 	bl	45e4 <fwp_rc_wide_dup>
    a84c:	17ffff3e 	b	a544 <fwp_main_thread+0x924>
    a850:	b0000000 	adrp	x0, b000 <__modti3+0x280>
    a854:	911e8000 	add	x0, x0, #0x7a0
    a858:	97ffe62e 	bl	4110 <fwp_trap>
    a85c:	f9400801 	ldr	x1, [x0, #16]
    a860:	a90013e1 	stp	x1, x4, [sp]
    a864:	97ffeccf 	bl	5ba0 <fwp_rc_free_arr>
    a868:	a94013e1 	ldp	x1, x4, [sp]
    a86c:	aa0103e0 	mov	x0, x1
    a870:	17ffff71 	b	a634 <fwp_main_thread+0xa14>
    a874:	72003c3f 	tst	w1, #0xffff
    a878:	54fff1e1 	b.ne	a6b4 <fwp_main_thread+0xa94>  // b.any
    a87c:	17ffff86 	b	a694 <fwp_main_thread+0xa74>
    a880:	72003c3f 	tst	w1, #0xffff
    a884:	54ffed41 	b.ne	a62c <fwp_main_thread+0xa0c>  // b.any
    a888:	17ffff64 	b	a618 <fwp_main_thread+0x9f8>
    a88c:	7100087f 	cmp	w3, #0x2
    a890:	54000160 	b.eq	a8bc <fwp_main_thread+0xc9c>  // b.none
    a894:	29430043 	ldp	w3, w0, [x2, #24]
    a898:	9b037c21 	mul	x1, x1, x3
    a89c:	eb41801f 	cmp	x0, x1, lsr #32
    a8a0:	54fff609 	b.ls	a760 <fwp_main_thread+0xb40>  // b.plast
    a8a4:	aa1c03e0 	mov	x0, x28
    a8a8:	97ffe6d6 	bl	4400 <fwp_mem_free>
    a8ac:	17ffffad 	b	a760 <fwp_main_thread+0xb40>
    a8b0:	f2403c21 	ands	x1, x1, #0xffff
    a8b4:	54fff561 	b.ne	a760 <fwp_main_thread+0xb40>  // b.any
    a8b8:	17ffffa2 	b	a740 <fwp_main_thread+0xb20>
    a8bc:	b5fff521 	cbnz	x1, a760 <fwp_main_thread+0xb40>
    a8c0:	17fffff9 	b	a8a4 <fwp_main_thread+0xc84>
    a8c4:	a91773fb 	stp	x27, x28, [sp, #368]
    a8c8:	fd00c3e8 	str	d8, [sp, #384]
    a8cc:	97ffe219 	bl	3130 <descent_phase_fail>
    a8d0:	ca424441 	eor	x1, x2, x2, lsr #17
    a8d4:	91174260 	add	x0, x19, #0x5d0
    a8d8:	ca412421 	eor	x1, x1, x1, lsr #9
    a8dc:	92401c21 	and	x1, x1, #0xff
    a8e0:	910a2423 	add	x3, x1, #0x289
    a8e4:	8b010c01 	add	x1, x0, x1, lsl #3
    a8e8:	8b030c03 	add	x3, x0, x3, lsl #3
    a8ec:	f94a2420 	ldr	x0, [x1, #5192]
    a8f0:	b40002e0 	cbz	x0, a94c <fwp_main_thread+0xd2c>
    a8f4:	f9400001 	ldr	x1, [x0]
    a8f8:	eb01005f 	cmp	x2, x1
    a8fc:	54000100 	b.eq	a91c <fwp_main_thread+0xcfc>  // b.none
    a900:	91004003 	add	x3, x0, #0x10
    a904:	f9400800 	ldr	x0, [x0, #16]
    a908:	17fffffa 	b	a8f0 <fwp_main_thread+0xcd0>
    a90c:	f90003e0 	str	x0, [sp]
    a910:	97ffe620 	bl	4190 <fwp_rc_forget_slot.part.0>
    a914:	f94003e0 	ldr	x0, [sp]
    a918:	17ffff43 	b	a624 <fwp_main_thread+0xa04>
    a91c:	f9400061 	ldr	x1, [x3]
    a920:	f9400420 	ldr	x0, [x1, #8]
    a924:	d1000400 	sub	x0, x0, #0x1
    a928:	f9000420 	str	x0, [x1, #8]
    a92c:	f103f81f 	cmp	x0, #0xfe
    a930:	54ffec21 	b.ne	a6b4 <fwp_main_thread+0xa94>  // b.any
    a934:	39400040 	ldrb	w0, [x2]
    a938:	7103fc1f 	cmp	w0, #0xff
    a93c:	540000e0 	b.eq	a958 <fwp_main_thread+0xd38>  // b.none
    a940:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a944:	39000040 	strb	w0, [x2]
    a948:	17ffff5b 	b	a6b4 <fwp_main_thread+0xa94>
    a94c:	b0000000 	adrp	x0, b000 <__modti3+0x280>
    a950:	910c6000 	add	x0, x0, #0x318
    a954:	97ffe5ef 	bl	4110 <fwp_trap>
    a958:	aa0203e0 	mov	x0, x2
    a95c:	f90003e2 	str	x2, [sp]
    a960:	97ffe60c 	bl	4190 <fwp_rc_forget_slot.part.0>
    a964:	f94003e2 	ldr	x2, [sp]
    a968:	17fffff6 	b	a940 <fwp_main_thread+0xd20>
    a96c:	97ffe1b1 	bl	3030 <fwp_heap_oom>
    a970:	a91773fb 	stp	x27, x28, [sp, #368]
    a974:	fd00c3e8 	str	d8, [sp, #384]
    a978:	97ffdfc2 	bl	2880 <__stack_chk_fail@plt>
    a97c:	ca5b4761 	eor	x1, x27, x27, lsr #17
    a980:	91174260 	add	x0, x19, #0x5d0
    a984:	ca412421 	eor	x1, x1, x1, lsr #9
    a988:	92401c21 	and	x1, x1, #0xff
    a98c:	910a2422 	add	x2, x1, #0x289
    a990:	8b010c01 	add	x1, x0, x1, lsl #3
    a994:	8b020c02 	add	x2, x0, x2, lsl #3
    a998:	f94a2420 	ldr	x0, [x1, #5192]
    a99c:	b4fffd80 	cbz	x0, a94c <fwp_main_thread+0xd2c>
    a9a0:	f9400001 	ldr	x1, [x0]
    a9a4:	eb01037f 	cmp	x27, x1
    a9a8:	54000080 	b.eq	a9b8 <fwp_main_thread+0xd98>  // b.none
    a9ac:	91004002 	add	x2, x0, #0x10
    a9b0:	f9400800 	ldr	x0, [x0, #16]
    a9b4:	17fffffa 	b	a99c <fwp_main_thread+0xd7c>
    a9b8:	f9400041 	ldr	x1, [x2]
    a9bc:	f9400420 	ldr	x0, [x1, #8]
    a9c0:	d1000400 	sub	x0, x0, #0x1
    a9c4:	f9000420 	str	x0, [x1, #8]
    a9c8:	f103f81f 	cmp	x0, #0xfe
    a9cc:	54ffeca1 	b.ne	a760 <fwp_main_thread+0xb40>  // b.any
    a9d0:	39400360 	ldrb	w0, [x27]
    a9d4:	7103fc1f 	cmp	w0, #0xff
    a9d8:	54000080 	b.eq	a9e8 <fwp_main_thread+0xdc8>  // b.none
    a9dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a9e0:	39000360 	strb	w0, [x27]
    a9e4:	17ffff5f 	b	a760 <fwp_main_thread+0xb40>
    a9e8:	aa1b03e0 	mov	x0, x27
    a9ec:	97ffe5e9 	bl	4190 <fwp_rc_forget_slot.part.0>
    a9f0:	17fffffb 	b	a9dc <fwp_main_thread+0xdbc>
    a9f4:	a91773fb 	stp	x27, x28, [sp, #368]
    a9f8:	fd00c3e8 	str	d8, [sp, #384]
    a9fc:	97ffdfb5 	bl	28d0 <abort@plt>

000000000000aa00 <__divti3>:
    aa00:	d503245f 	bti	c
    aa04:	d2800004 	mov	x4, #0x0                   	// #0
    aa08:	b7f80721 	tbnz	x1, #63, aaec <__divti3+0xec>
    aa0c:	b6f80083 	tbz	x3, #63, aa1c <__divti3+0x1c>
    aa10:	eb0203e2 	negs	x2, x2
    aa14:	aa2403e4 	mvn	x4, x4
    aa18:	da0303e3 	ngc	x3, x3
    aa1c:	aa0203e6 	mov	x6, x2
    aa20:	aa0003e7 	mov	x7, x0
    aa24:	aa0103e5 	mov	x5, x1
    aa28:	b5000583 	cbnz	x3, aad8 <__divti3+0xd8>
    aa2c:	eb01005f 	cmp	x2, x1
    aa30:	54000e69 	b.ls	abfc <__divti3+0x1fc>  // b.plast
    aa34:	dac01040 	clz	x0, x2
    aa38:	b40000e0 	cbz	x0, aa54 <__divti3+0x54>
    aa3c:	4b0003e1 	neg	w1, w0
    aa40:	9ac020a5 	lsl	x5, x5, x0
    aa44:	9ac02046 	lsl	x6, x2, x0
    aa48:	9ac124e1 	lsr	x1, x7, x1
    aa4c:	aa050025 	orr	x5, x1, x5
    aa50:	9ac020e7 	lsl	x7, x7, x0
    aa54:	d360fcc8 	lsr	x8, x6, #32
    aa58:	92407cc2 	and	x2, x6, #0xffffffff
    aa5c:	9ac808a3 	udiv	x3, x5, x8
    aa60:	9b089465 	msub	x5, x3, x8, x5
    aa64:	aa0303e0 	mov	x0, x3
    aa68:	9b037c41 	mul	x1, x2, x3
    aa6c:	93c780a5 	extr	x5, x5, x7, #32
    aa70:	eb05003f 	cmp	x1, x5
    aa74:	540000a9 	b.ls	aa88 <__divti3+0x88>  // b.plast
    aa78:	ab0500c5 	adds	x5, x6, x5
    aa7c:	d1000460 	sub	x0, x3, #0x1
    aa80:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    aa84:	540015a8 	b.hi	ad38 <__divti3+0x338>  // b.pmore
    aa88:	cb0100a5 	sub	x5, x5, x1
    aa8c:	9ac808a3 	udiv	x3, x5, x8
    aa90:	9b089465 	msub	x5, x3, x8, x5
    aa94:	aa0303e1 	mov	x1, x3
    aa98:	9b037c42 	mul	x2, x2, x3
    aa9c:	aa0703e3 	mov	x3, x7
    aaa0:	b3607ca3 	bfi	x3, x5, #32, #32
    aaa4:	eb03005f 	cmp	x2, x3
    aaa8:	540000c9 	b.ls	aac0 <__divti3+0xc0>  // b.plast
    aaac:	ab0300c3 	adds	x3, x6, x3
    aab0:	d1000425 	sub	x5, x1, #0x1
    aab4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    aab8:	d1000821 	sub	x1, x1, #0x2
    aabc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    aac0:	aa008020 	orr	x0, x1, x0, lsl #32
    aac4:	d2800001 	mov	x1, #0x0                   	// #0
    aac8:	b4000064 	cbz	x4, aad4 <__divti3+0xd4>
    aacc:	eb0003e0 	negs	x0, x0
    aad0:	da0103e1 	ngc	x1, x1
    aad4:	d65f03c0 	ret
    aad8:	eb01007f 	cmp	x3, x1
    aadc:	54000109 	b.ls	aafc <__divti3+0xfc>  // b.plast
    aae0:	d2800001 	mov	x1, #0x0                   	// #0
    aae4:	d2800000 	mov	x0, #0x0                   	// #0
    aae8:	17fffff8 	b	aac8 <__divti3+0xc8>
    aaec:	eb0003e0 	negs	x0, x0
    aaf0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    aaf4:	da0103e1 	ngc	x1, x1
    aaf8:	17ffffc5 	b	aa0c <__divti3+0xc>
    aafc:	dac01067 	clz	x7, x3
    ab00:	b40010e7 	cbz	x7, ad1c <__divti3+0x31c>
    ab04:	d2800805 	mov	x5, #0x40                  	// #64
    ab08:	cb0700a5 	sub	x5, x5, x7
    ab0c:	9ac72063 	lsl	x3, x3, x7
    ab10:	9ac52448 	lsr	x8, x2, x5
    ab14:	aa030108 	orr	x8, x8, x3
    ab18:	9ac52426 	lsr	x6, x1, x5
    ab1c:	92407d0a 	and	x10, x8, #0xffffffff
    ab20:	d360fd09 	lsr	x9, x8, #32
    ab24:	9ac52403 	lsr	x3, x0, x5
    ab28:	9ac72021 	lsl	x1, x1, x7
    ab2c:	aa010063 	orr	x3, x3, x1
    ab30:	9ac72042 	lsl	x2, x2, x7
    ab34:	9ac908cb 	udiv	x11, x6, x9
    ab38:	9b099965 	msub	x5, x11, x9, x6
    ab3c:	aa0b03e1 	mov	x1, x11
    ab40:	9b0b7d46 	mul	x6, x10, x11
    ab44:	93c380a5 	extr	x5, x5, x3, #32
    ab48:	eb0500df 	cmp	x6, x5
    ab4c:	540000a9 	b.ls	ab60 <__divti3+0x160>  // b.plast
    ab50:	ab050105 	adds	x5, x8, x5
    ab54:	d1000561 	sub	x1, x11, #0x1
    ab58:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ab5c:	54000f48 	b.hi	ad44 <__divti3+0x344>  // b.pmore
    ab60:	cb0600a6 	sub	x6, x5, x6
    ab64:	9ac908cb 	udiv	x11, x6, x9
    ab68:	9b099969 	msub	x9, x11, x9, x6
    ab6c:	aa0b03e5 	mov	x5, x11
    ab70:	9b0b7d4a 	mul	x10, x10, x11
    ab74:	b3607d23 	bfi	x3, x9, #32, #32
    ab78:	eb03015f 	cmp	x10, x3
    ab7c:	540000a9 	b.ls	ab90 <__divti3+0x190>  // b.plast
    ab80:	ab030103 	adds	x3, x8, x3
    ab84:	d1000565 	sub	x5, x11, #0x1
    ab88:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ab8c:	54000e28 	b.hi	ad50 <__divti3+0x350>  // b.pmore
    ab90:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ab94:	92407c48 	and	x8, x2, #0xffffffff
    ab98:	2a0503e5 	mov	w5, w5
    ab9c:	d360fc42 	lsr	x2, x2, #32
    aba0:	d360fc26 	lsr	x6, x1, #32
    aba4:	cb0a0063 	sub	x3, x3, x10
    aba8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    abac:	9b087caa 	mul	x10, x5, x8
    abb0:	9b087cc8 	mul	x8, x6, x8
    abb4:	9b0220a5 	madd	x5, x5, x2, x8
    abb8:	9b027cc6 	mul	x6, x6, x2
    abbc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    abc0:	8b0900c5 	add	x5, x6, x9
    abc4:	eb02011f 	cmp	x8, x2
    abc8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    abcc:	8b4280c6 	add	x6, x6, x2, lsr #32
    abd0:	eb06007f 	cmp	x3, x6
    abd4:	540000e3 	b.cc	abf0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    abd8:	92407d4a 	and	x10, x10, #0xffffffff
    abdc:	9ac72000 	lsl	x0, x0, x7
    abe0:	8b028142 	add	x2, x10, x2, lsl #32
    abe4:	eb02001f 	cmp	x0, x2
    abe8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    abec:	54000a01 	b.ne	ad2c <__divti3+0x32c>  // b.any
    abf0:	d1000420 	sub	x0, x1, #0x1
    abf4:	d2800001 	mov	x1, #0x0                   	// #0
    abf8:	17ffffb4 	b	aac8 <__divti3+0xc8>
    abfc:	b5000062 	cbnz	x2, ac08 <__divti3+0x208>
    ac00:	d2800022 	mov	x2, #0x1                   	// #1
    ac04:	9ac30846 	udiv	x6, x2, x3
    ac08:	dac010c8 	clz	x8, x6
    ac0c:	b5000408 	cbnz	x8, ac8c <__divti3+0x28c>
    ac10:	d360fcc9 	lsr	x9, x6, #32
    ac14:	92407cc5 	and	x5, x6, #0xffffffff
    ac18:	cb060023 	sub	x3, x1, x6
    ac1c:	d2800021 	mov	x1, #0x1                   	// #1
    ac20:	9ac90868 	udiv	x8, x3, x9
    ac24:	9b098d03 	msub	x3, x8, x9, x3
    ac28:	aa0803e0 	mov	x0, x8
    ac2c:	9b057d02 	mul	x2, x8, x5
    ac30:	93c78063 	extr	x3, x3, x7, #32
    ac34:	eb03005f 	cmp	x2, x3
    ac38:	540000a9 	b.ls	ac4c <__divti3+0x24c>  // b.plast
    ac3c:	ab0300c3 	adds	x3, x6, x3
    ac40:	d1000500 	sub	x0, x8, #0x1
    ac44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ac48:	54000968 	b.hi	ad74 <__divti3+0x374>  // b.pmore
    ac4c:	cb020063 	sub	x3, x3, x2
    ac50:	9ac90862 	udiv	x2, x3, x9
    ac54:	aa0203e8 	mov	x8, x2
    ac58:	9b098c42 	msub	x2, x2, x9, x3
    ac5c:	aa0703e3 	mov	x3, x7
    ac60:	9b057d05 	mul	x5, x8, x5
    ac64:	b3607c43 	bfi	x3, x2, #32, #32
    ac68:	eb0300bf 	cmp	x5, x3
    ac6c:	540000c9 	b.ls	ac84 <__divti3+0x284>  // b.plast
    ac70:	ab0300c2 	adds	x2, x6, x3
    ac74:	d1000503 	sub	x3, x8, #0x1
    ac78:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ac7c:	d1000908 	sub	x8, x8, #0x2
    ac80:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ac84:	aa008100 	orr	x0, x8, x0, lsl #32
    ac88:	17ffff90 	b	aac8 <__divti3+0xc8>
    ac8c:	9ac820c6 	lsl	x6, x6, x8
    ac90:	d2800803 	mov	x3, #0x40                  	// #64
    ac94:	cb080063 	sub	x3, x3, x8
    ac98:	d360fcc9 	lsr	x9, x6, #32
    ac9c:	9ac82027 	lsl	x7, x1, x8
    aca0:	92407cc5 	and	x5, x6, #0xffffffff
    aca4:	9ac32422 	lsr	x2, x1, x3
    aca8:	9ac32403 	lsr	x3, x0, x3
    acac:	aa070063 	orr	x3, x3, x7
    acb0:	9ac9084a 	udiv	x10, x2, x9
    acb4:	9ac82007 	lsl	x7, x0, x8
    acb8:	9b098940 	msub	x0, x10, x9, x2
    acbc:	aa0a03e1 	mov	x1, x10
    acc0:	9b0a7ca2 	mul	x2, x5, x10
    acc4:	93c38000 	extr	x0, x0, x3, #32
    acc8:	eb00005f 	cmp	x2, x0
    accc:	540000a9 	b.ls	ace0 <__divti3+0x2e0>  // b.plast
    acd0:	ab0000c0 	adds	x0, x6, x0
    acd4:	d1000541 	sub	x1, x10, #0x1
    acd8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    acdc:	54000468 	b.hi	ad68 <__divti3+0x368>  // b.pmore
    ace0:	cb020000 	sub	x0, x0, x2
    ace4:	9ac9080a 	udiv	x10, x0, x9
    ace8:	9b098140 	msub	x0, x10, x9, x0
    acec:	aa0a03e2 	mov	x2, x10
    acf0:	9b0a7ca8 	mul	x8, x5, x10
    acf4:	b3607c03 	bfi	x3, x0, #32, #32
    acf8:	eb03011f 	cmp	x8, x3
    acfc:	540000a9 	b.ls	ad10 <__divti3+0x310>  // b.plast
    ad00:	ab0300c3 	adds	x3, x6, x3
    ad04:	d1000542 	sub	x2, x10, #0x1
    ad08:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    ad0c:	54000288 	b.hi	ad5c <__divti3+0x35c>  // b.pmore
    ad10:	cb080063 	sub	x3, x3, x8
    ad14:	aa018041 	orr	x1, x2, x1, lsl #32
    ad18:	17ffffc2 	b	ac20 <__divti3+0x220>
    ad1c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ad20:	d2800001 	mov	x1, #0x0                   	// #0
    ad24:	9a9f87e0 	cset	x0, ls	// ls = plast
    ad28:	17ffff68 	b	aac8 <__divti3+0xc8>
    ad2c:	aa0103e0 	mov	x0, x1
    ad30:	d2800001 	mov	x1, #0x0                   	// #0
    ad34:	17ffff65 	b	aac8 <__divti3+0xc8>
    ad38:	d1000860 	sub	x0, x3, #0x2
    ad3c:	8b0600a5 	add	x5, x5, x6
    ad40:	17ffff52 	b	aa88 <__divti3+0x88>
    ad44:	d1000961 	sub	x1, x11, #0x2
    ad48:	8b0800a5 	add	x5, x5, x8
    ad4c:	17ffff85 	b	ab60 <__divti3+0x160>
    ad50:	d1000965 	sub	x5, x11, #0x2
    ad54:	8b080063 	add	x3, x3, x8
    ad58:	17ffff8e 	b	ab90 <__divti3+0x190>
    ad5c:	d1000942 	sub	x2, x10, #0x2
    ad60:	8b060063 	add	x3, x3, x6
    ad64:	17ffffeb 	b	ad10 <__divti3+0x310>
    ad68:	d1000941 	sub	x1, x10, #0x2
    ad6c:	8b060000 	add	x0, x0, x6
    ad70:	17ffffdc 	b	ace0 <__divti3+0x2e0>
    ad74:	d1000900 	sub	x0, x8, #0x2
    ad78:	8b060063 	add	x3, x3, x6
    ad7c:	17ffffb4 	b	ac4c <__divti3+0x24c>

000000000000ad80 <__modti3>:
    ad80:	d503245f 	bti	c
    ad84:	d2800004 	mov	x4, #0x0                   	// #0
    ad88:	b6f80081 	tbz	x1, #63, ad98 <__modti3+0x18>
    ad8c:	eb0003e0 	negs	x0, x0
    ad90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ad94:	da0103e1 	ngc	x1, x1
    ad98:	f100007f 	cmp	x3, #0x0
    ad9c:	5400128b 	b.lt	afec <__modti3+0x26c>  // b.tstop
    ada0:	aa0003e7 	mov	x7, x0
    ada4:	aa0103e6 	mov	x6, x1
    ada8:	540004e1 	b.ne	ae44 <__modti3+0xc4>  // b.any
    adac:	eb02003f 	cmp	x1, x2
    adb0:	54000dc2 	b.cs	af68 <__modti3+0x1e8>  // b.hs, b.nlast
    adb4:	dac01043 	clz	x3, x2
    adb8:	aa0303e5 	mov	x5, x3
    adbc:	b40000e3 	cbz	x3, add8 <__modti3+0x58>
    adc0:	4b0303e6 	neg	w6, w3
    adc4:	9ac32021 	lsl	x1, x1, x3
    adc8:	9ac32042 	lsl	x2, x2, x3
    adcc:	9ac62406 	lsr	x6, x0, x6
    add0:	aa0100c6 	orr	x6, x6, x1
    add4:	9ac32007 	lsl	x7, x0, x3
    add8:	d360fc40 	lsr	x0, x2, #32
    addc:	92407c43 	and	x3, x2, #0xffffffff
    ade0:	9ac008c1 	udiv	x1, x6, x0
    ade4:	9b009826 	msub	x6, x1, x0, x6
    ade8:	9b017c61 	mul	x1, x3, x1
    adec:	93c780c6 	extr	x6, x6, x7, #32
    adf0:	eb06003f 	cmp	x1, x6
    adf4:	540000a9 	b.ls	ae08 <__modti3+0x88>  // b.plast
    adf8:	ab060046 	adds	x6, x2, x6
    adfc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ae00:	8b0200c8 	add	x8, x6, x2
    ae04:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ae08:	cb0100c6 	sub	x6, x6, x1
    ae0c:	9ac008c8 	udiv	x8, x6, x0
    ae10:	9b009901 	msub	x1, x8, x0, x6
    ae14:	aa0703e0 	mov	x0, x7
    ae18:	9b087c63 	mul	x3, x3, x8
    ae1c:	b3607c20 	bfi	x0, x1, #32, #32
    ae20:	eb00007f 	cmp	x3, x0
    ae24:	54001088 	b.hi	b034 <__modti3+0x2b4>  // b.pmore
    ae28:	cb030000 	sub	x0, x0, x3
    ae2c:	9ac52400 	lsr	x0, x0, x5
    ae30:	d2800001 	mov	x1, #0x0                   	// #0
    ae34:	b4000064 	cbz	x4, ae40 <__modti3+0xc0>
    ae38:	eb0003e0 	negs	x0, x0
    ae3c:	da0103e1 	ngc	x1, x1
    ae40:	d65f03c0 	ret
    ae44:	dac01066 	clz	x6, x3
    ae48:	eb03003f 	cmp	x1, x3
    ae4c:	54ffff43 	b.cc	ae34 <__modti3+0xb4>  // b.lo, b.ul, b.last
    ae50:	93407cc5 	sxtw	x5, w6
    ae54:	d2800808 	mov	x8, #0x40                  	// #64
    ae58:	cb050108 	sub	x8, x8, x5
    ae5c:	9ac62063 	lsl	x3, x3, x6
    ae60:	9ac62025 	lsl	x5, x1, x6
    ae64:	9ac82447 	lsr	x7, x2, x8
    ae68:	aa0300e7 	orr	x7, x7, x3
    ae6c:	9ac82423 	lsr	x3, x1, x8
    ae70:	92407cec 	and	x12, x7, #0xffffffff
    ae74:	d360fcea 	lsr	x10, x7, #32
    ae78:	9ac82401 	lsr	x1, x0, x8
    ae7c:	aa050021 	orr	x1, x1, x5
    ae80:	9ac62042 	lsl	x2, x2, x6
    ae84:	9ac62000 	lsl	x0, x0, x6
    ae88:	9aca086b 	udiv	x11, x3, x10
    ae8c:	9b0a8d63 	msub	x3, x11, x10, x3
    ae90:	aa0b03e5 	mov	x5, x11
    ae94:	9b0b7d89 	mul	x9, x12, x11
    ae98:	93c18063 	extr	x3, x3, x1, #32
    ae9c:	eb03013f 	cmp	x9, x3
    aea0:	540000a9 	b.ls	aeb4 <__modti3+0x134>  // b.plast
    aea4:	ab0300e3 	adds	x3, x7, x3
    aea8:	d1000565 	sub	x5, x11, #0x1
    aeac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    aeb0:	54001168 	b.hi	b0dc <__modti3+0x35c>  // b.pmore
    aeb4:	cb090063 	sub	x3, x3, x9
    aeb8:	9aca086b 	udiv	x11, x3, x10
    aebc:	9b0a8d6a 	msub	x10, x11, x10, x3
    aec0:	aa0b03e9 	mov	x9, x11
    aec4:	9b0b7d8c 	mul	x12, x12, x11
    aec8:	b3607d41 	bfi	x1, x10, #32, #32
    aecc:	eb01019f 	cmp	x12, x1
    aed0:	540000a9 	b.ls	aee4 <__modti3+0x164>  // b.plast
    aed4:	ab0100e1 	adds	x1, x7, x1
    aed8:	d1000569 	sub	x9, x11, #0x1
    aedc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    aee0:	54000f88 	b.hi	b0d0 <__modti3+0x350>  // b.pmore
    aee4:	aa058123 	orr	x3, x9, x5, lsl #32
    aee8:	92407c4b 	and	x11, x2, #0xffffffff
    aeec:	2a0903e9 	mov	w9, w9
    aef0:	d360fc4a 	lsr	x10, x2, #32
    aef4:	d360fc63 	lsr	x3, x3, #32
    aef8:	cb0c0021 	sub	x1, x1, x12
    aefc:	aa0a03ec 	mov	x12, x10
    af00:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    af04:	9b0b7d25 	mul	x5, x9, x11
    af08:	9b0b7c6b 	mul	x11, x3, x11
    af0c:	9b0a2d29 	madd	x9, x9, x10, x11
    af10:	92407caa 	and	x10, x5, #0xffffffff
    af14:	9b0c7c63 	mul	x3, x3, x12
    af18:	8b458125 	add	x5, x9, x5, lsr #32
    af1c:	8b0d0069 	add	x9, x3, x13
    af20:	eb05017f 	cmp	x11, x5
    af24:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    af28:	8b058149 	add	x9, x10, x5, lsl #32
    af2c:	8b458063 	add	x3, x3, x5, lsr #32
    af30:	eb03003f 	cmp	x1, x3
    af34:	54000063 	b.cc	af40 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    af38:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    af3c:	54000082 	b.cs	af4c <__modti3+0x1cc>  // b.hs, b.nlast
    af40:	eb020129 	subs	x9, x9, x2
    af44:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    af48:	cb070063 	sub	x3, x3, x7
    af4c:	eb090000 	subs	x0, x0, x9
    af50:	da030021 	sbc	x1, x1, x3
    af54:	9ac62400 	lsr	x0, x0, x6
    af58:	9ac82028 	lsl	x8, x1, x8
    af5c:	aa000100 	orr	x0, x8, x0
    af60:	9ac62421 	lsr	x1, x1, x6
    af64:	17ffffb4 	b	ae34 <__modti3+0xb4>
    af68:	b5000062 	cbnz	x2, af74 <__modti3+0x1f4>
    af6c:	d2800023 	mov	x3, #0x1                   	// #1
    af70:	9ac20862 	udiv	x2, x3, x2
    af74:	dac01048 	clz	x8, x2
    af78:	aa0803e5 	mov	x5, x8
    af7c:	b5000668 	cbnz	x8, b048 <__modti3+0x2c8>
    af80:	cb020020 	sub	x0, x1, x2
    af84:	d360fc49 	lsr	x9, x2, #32
    af88:	92407c4a 	and	x10, x2, #0xffffffff
    af8c:	9ac90801 	udiv	x1, x0, x9
    af90:	9b098020 	msub	x0, x1, x9, x0
    af94:	9b0a7c21 	mul	x1, x1, x10
    af98:	93c78000 	extr	x0, x0, x7, #32
    af9c:	eb00003f 	cmp	x1, x0
    afa0:	540000a9 	b.ls	afb4 <__modti3+0x234>  // b.plast
    afa4:	ab000040 	adds	x0, x2, x0
    afa8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    afac:	8b020003 	add	x3, x0, x2
    afb0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    afb4:	cb010001 	sub	x1, x0, x1
    afb8:	9ac90820 	udiv	x0, x1, x9
    afbc:	9b098403 	msub	x3, x0, x9, x1
    afc0:	aa0703e1 	mov	x1, x7
    afc4:	9b0a7c00 	mul	x0, x0, x10
    afc8:	b3607c61 	bfi	x1, x3, #32, #32
    afcc:	eb01001f 	cmp	x0, x1
    afd0:	540000a9 	b.ls	afe4 <__modti3+0x264>  // b.plast
    afd4:	ab010041 	adds	x1, x2, x1
    afd8:	8b020022 	add	x2, x1, x2
    afdc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    afe0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    afe4:	cb000020 	sub	x0, x1, x0
    afe8:	17ffff91 	b	ae2c <__modti3+0xac>
    afec:	eb0203e5 	negs	x5, x2
    aff0:	aa0003e7 	mov	x7, x0
    aff4:	da0303e8 	ngc	x8, x3
    aff8:	aa0503e2 	mov	x2, x5
    affc:	aa0803e3 	mov	x3, x8
    b000:	aa0103e6 	mov	x6, x1
    b004:	b4ffed48 	cbz	x8, adac <__modti3+0x2c>
    b008:	eb01011f 	cmp	x8, x1
    b00c:	54fff148 	b.hi	ae34 <__modti3+0xb4>  // b.pmore
    b010:	dac01109 	clz	x9, x8
    b014:	2a0903e6 	mov	w6, w9
    b018:	b5fff1c9 	cbnz	x9, ae50 <__modti3+0xd0>
    b01c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b020:	54000068 	b.hi	b02c <__modti3+0x2ac>  // b.pmore
    b024:	eb050007 	subs	x7, x0, x5
    b028:	da080021 	sbc	x1, x1, x8
    b02c:	aa0703e0 	mov	x0, x7
    b030:	17ffff81 	b	ae34 <__modti3+0xb4>
    b034:	ab000040 	adds	x0, x2, x0
    b038:	8b020002 	add	x2, x0, x2
    b03c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b040:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b044:	17ffff79 	b	ae28 <__modti3+0xa8>
    b048:	9ac82042 	lsl	x2, x2, x8
    b04c:	d2800803 	mov	x3, #0x40                  	// #64
    b050:	cb080063 	sub	x3, x3, x8
    b054:	d360fc49 	lsr	x9, x2, #32
    b058:	9ac82027 	lsl	x7, x1, x8
    b05c:	92407c4a 	and	x10, x2, #0xffffffff
    b060:	9ac32426 	lsr	x6, x1, x3
    b064:	9ac32403 	lsr	x3, x0, x3
    b068:	aa070063 	orr	x3, x3, x7
    b06c:	9ac908c1 	udiv	x1, x6, x9
    b070:	9ac82007 	lsl	x7, x0, x8
    b074:	9b099820 	msub	x0, x1, x9, x6
    b078:	9b017d41 	mul	x1, x10, x1
    b07c:	93c38000 	extr	x0, x0, x3, #32
    b080:	eb00003f 	cmp	x1, x0
    b084:	540000a9 	b.ls	b098 <__modti3+0x318>  // b.plast
    b088:	ab000040 	adds	x0, x2, x0
    b08c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b090:	8b020006 	add	x6, x0, x2
    b094:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b098:	cb010000 	sub	x0, x0, x1
    b09c:	9ac90801 	udiv	x1, x0, x9
    b0a0:	9b098026 	msub	x6, x1, x9, x0
    b0a4:	aa0303e0 	mov	x0, x3
    b0a8:	9b017d41 	mul	x1, x10, x1
    b0ac:	b3607cc0 	bfi	x0, x6, #32, #32
    b0b0:	eb00003f 	cmp	x1, x0
    b0b4:	540000a9 	b.ls	b0c8 <__modti3+0x348>  // b.plast
    b0b8:	ab000040 	adds	x0, x2, x0
    b0bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b0c0:	8b020003 	add	x3, x0, x2
    b0c4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b0c8:	cb010000 	sub	x0, x0, x1
    b0cc:	17ffffb0 	b	af8c <__modti3+0x20c>
    b0d0:	d1000969 	sub	x9, x11, #0x2
    b0d4:	8b070021 	add	x1, x1, x7
    b0d8:	17ffff83 	b	aee4 <__modti3+0x164>
    b0dc:	d1000965 	sub	x5, x11, #0x2
    b0e0:	8b070063 	add	x3, x3, x7
    b0e4:	17ffff74 	b	aeb4 <__modti3+0x134>
    b0e8:	d503201f 	nop
    b0ec:	d503201f 	nop

000000000000b0f0 <atexit>:
    b0f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b0f4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b0f8:	d2800001 	mov	x1, #0x0                   	// #0
    b0fc:	910003fd 	mov	x29, sp
    b100:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b104:	f9400442 	ldr	x2, [x2, #8]
    b108:	17ffdd9e 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b10c <_fini>:
    b10c:	d503201f 	nop
    b110:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b114:	910003fd 	mov	x29, sp
    b118:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b11c:	d65f03c0 	ret
