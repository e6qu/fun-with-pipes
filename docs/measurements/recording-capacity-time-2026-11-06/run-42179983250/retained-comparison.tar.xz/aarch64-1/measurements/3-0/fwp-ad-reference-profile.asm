
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <fwp_main_thread+0x820>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913fc0a5 	add	x5, x5, #0xff0
    2aa0:	f0000024 	adrp	x4, 9000 <fwp_main_thread+0x820>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	913fe084 	add	x4, x4, #0xff8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000619 	bl	4334 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	910142a1 	add	x1, x21, #0x50
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x122d8>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9008c20 	str	x0, [x1, #280]
    2b2c:	94000821 	bl	4bb0 <fwp_now_ns>
    2b30:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2b34:	910b8000 	add	x0, x0, #0x2e0
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0x80c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911f8042 	add	x2, x2, #0x7e0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	910142b5 	add	x21, x21, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943d2a0 	ldr	w0, [x21, #976]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2c4c:	910c4000 	add	x0, x0, #0x310
    2c50:	940005b9 	bl	4334 <fwp_trap>
    2c54:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2c58:	910bc000 	add	x0, x0, #0x2f0
    2c5c:	940005b6 	bl	4334 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff4a 	bl	2990 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeef 	bl	2850 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2ca0:	910da000 	add	x0, x0, #0x368
    2ca4:	940005a4 	bl	4334 <fwp_trap>
    2ca8:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2cac:	910ce000 	add	x0, x0, #0x338
    2cb0:	940005a1 	bl	4334 <fwp_trap>
    2cb4:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    2cb8:	910e4000 	add	x0, x0, #0x390
    2cbc:	9400059e 	bl	4334 <fwp_trap>
    2cc0:	97fffef8 	bl	28a0 <__stack_chk_fail@plt>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	9100e000 	add	x0, x0, #0x38
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	9100e021 	add	x1, x1, #0x38
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	9100e000 	add	x0, x0, #0x38
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	9100e021 	add	x1, x1, #0x38
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    2eb4:	91278021 	add	x1, x1, #0x9e0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    3158:	91270021 	add	x1, x1, #0x9c0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    3190:	912c6000 	add	x0, x0, #0xb18
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    31c4:	911882a1 	add	x1, x21, #0x620
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    31d8:	912840a5 	add	x5, x5, #0xa10
    31dc:	911882a1 	add	x1, x21, #0x620
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911882b7 	add	x23, x21, #0x620
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911882b5 	add	x21, x21, #0x620
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911882b5 	add	x21, x21, #0x620
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3368:	912820a5 	add	x5, x5, #0xa08
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x820>
    339c:	912cc042 	add	x2, x2, #0xb30
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x820>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	912e2042 	add	x2, x2, #0xb88
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000039 	adrp	x25, 9000 <fwp_main_thread+0x820>
    3428:	d000003a 	adrp	x26, 9000 <fwp_main_thread+0x820>
    342c:	912fa339 	add	x25, x25, #0xbe8
    3430:	912d435a 	add	x26, x26, #0xb50
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000003b 	adrp	x27, 9000 <fwp_main_thread+0x820>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	912d6377 	add	x23, x27, #0xb58
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	9130a000 	add	x0, x0, #0xc28
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbc0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbc0>
    34fc:	d0000023 	adrp	x3, 9000 <fwp_main_thread+0x820>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000035 	adrp	x21, 9000 <fwp_main_thread+0x820>
    3508:	f9422024 	ldr	x4, [x1, #1088]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f94224a5 	ldr	x5, [x5, #1096]
    3514:	91110033 	add	x19, x1, #0x440
    3518:	f9422846 	ldr	x6, [x2, #1104]
    351c:	912d4063 	add	x3, x3, #0xb50
    3520:	913102b5 	add	x21, x21, #0xc40
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91320000 	add	x0, x0, #0xc80
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    35ac:	912d8000 	add	x0, x0, #0xb60
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    366c:	912c6000 	add	x0, x0, #0xb18
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91322021 	add	x1, x1, #0xc88
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91324021 	add	x1, x1, #0xc90
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    37e0:	91326021 	add	x1, x1, #0xc98
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x820>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	91328084 	add	x4, x4, #0xca0
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbeb 	bl	2810 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc44 	bl	2980 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2f 	bl	2940 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbb0 	bl	27f0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffba1 	bl	27f0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb65 	bl	2730 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf5 	bl	2980 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x820>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	9132e084 	add	x4, x4, #0xcb8
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb76 	bl	2810 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb65 	bl	27f0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc5 	bl	2980 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x820>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	9132a084 	add	x4, x4, #0xca8
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4e 	bl	2810 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb38 	bl	27f0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb0c 	bl	27f0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb28 	bl	28a0 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    3c0c:	91188042 	add	x2, x2, #0x620
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91330021 	add	x1, x1, #0xcc0
    3c68:	91332000 	add	x0, x0, #0xcc8
    3c6c:	97fffaf1 	bl	2830 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb6d 	bl	2a50 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb1b 	bl	2940 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb5a 	bl	2a50 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffacb 	bl	2820 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x820>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9133a042 	add	x2, x2, #0xce8
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaee 	b	2910 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97ffface 	bl	28a0 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9e0>
    3d78:	91148061 	add	x1, x3, #0x520
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    3d88:	91188262 	add	x2, x19, #0x620
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0x4f0>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9e0>
    3dbc:	91158021 	add	x1, x1, #0x560
    3dc0:	3dc27c43 	ldr	q3, [x2, #2544]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9e0>
    3dec:	91148063 	add	x3, x3, #0x520
    3df0:	91170084 	add	x4, x4, #0x5c0
    3df4:	91188266 	add	x6, x19, #0x620
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffab1 	bl	2930 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91188275 	add	x21, x19, #0x620
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa9b 	bl	2930 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    3ed8:	9135c000 	add	x0, x0, #0xd70
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad4 	bl	2a30 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91188273 	add	x19, x19, #0x620
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc90 	bl	3170 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	91014122 	add	x2, x9, #0x50
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9406046 	ldr	x6, [x2, #192]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	91014120 	add	x0, x9, #0x50
    3fc4:	f900640b 	str	x11, [x0, #200]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	91014129 	add	x9, x9, #0x50
    3fd0:	f9006126 	str	x6, [x9, #192]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <ad_raw_free.part.0>:
    3ff0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbc0>
    3ff4:	d2800001 	mov	x1, #0x0                   	// #0
    3ff8:	91110082 	add	x2, x4, #0x440
    3ffc:	14000005 	b	4010 <ad_raw_free.part.0+0x20>
    4000:	91000421 	add	x1, x1, #0x1
    4004:	91006042 	add	x2, x2, #0x18
    4008:	f140043f 	cmp	x1, #0x1, lsl #12
    400c:	54000220 	b.eq	4050 <ad_raw_free.part.0+0x60>  // b.none
    4010:	f9400043 	ldr	x3, [x2]
    4014:	eb03001f 	cmp	x0, x3
    4018:	54ffff41 	b.ne	4000 <ad_raw_free.part.0+0x10>  // b.any
    401c:	8b010421 	add	x1, x1, x1, lsl #1
    4020:	91110084 	add	x4, x4, #0x440
    4024:	900000e2 	adrp	x2, 20000 <__data_start>
    4028:	91014042 	add	x2, x2, #0x50
    402c:	8b010c81 	add	x1, x4, x1, lsl #3
    4030:	b9401024 	ldr	w4, [x1, #16]
    4034:	f9400425 	ldr	x5, [x1, #8]
    4038:	a9007c3f 	stp	xzr, xzr, [x1]
    403c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4040:	f900083f 	str	xzr, [x1, #16]
    4044:	cb050061 	sub	x1, x3, x5
    4048:	f8247841 	str	x1, [x2, x4, lsl #3]
    404c:	17fffa45 	b	2960 <free@plt>
    4050:	f100001f 	cmp	x0, #0x0
    4054:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    4058:	91366021 	add	x1, x1, #0xd98
    405c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4060:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4064:	91360000 	add	x0, x0, #0xd80
    4068:	910003fd 	mov	x29, sp
    406c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4070:	97fffcc4 	bl	3380 <ad_raw_fail>

0000000000004074 <fwp_tape_buffers_dispose>:
    4074:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4078:	910003fd 	mov	x29, sp
    407c:	f9000bf3 	str	x19, [sp, #16]
    4080:	aa0003f3 	mov	x19, x0
    4084:	f9400000 	ldr	x0, [x0]
    4088:	b4000040 	cbz	x0, 4090 <fwp_tape_buffers_dispose+0x1c>
    408c:	97ffffd9 	bl	3ff0 <ad_raw_free.part.0>
    4090:	f9400a60 	ldr	x0, [x19, #16]
    4094:	b4000040 	cbz	x0, 409c <fwp_tape_buffers_dispose+0x28>
    4098:	97ffffd6 	bl	3ff0 <ad_raw_free.part.0>
    409c:	f9401260 	ldr	x0, [x19, #32]
    40a0:	b4000040 	cbz	x0, 40a8 <fwp_tape_buffers_dispose+0x34>
    40a4:	97ffffd3 	bl	3ff0 <ad_raw_free.part.0>
    40a8:	4f000400 	movi	v0.4s, #0x0
    40ac:	f9001a7f 	str	xzr, [x19, #48]
    40b0:	ad000260 	stp	q0, q0, [x19]
    40b4:	3d800a60 	str	q0, [x19, #32]
    40b8:	f9400bf3 	ldr	x19, [sp, #16]
    40bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40c0:	d65f03c0 	ret

00000000000040c4 <ad_raw_realloc>:
    40c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	f90013f5 	str	x21, [sp, #32]
    40d4:	b40005a1 	cbz	x1, 4188 <ad_raw_realloc+0xc4>
    40d8:	aa0103f4 	mov	x20, x1
    40dc:	2a0203f5 	mov	w21, w2
    40e0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbc0>
    40e4:	d2800004 	mov	x4, #0x0                   	// #0
    40e8:	91110025 	add	x5, x1, #0x440
    40ec:	14000005 	b	4100 <ad_raw_realloc+0x3c>
    40f0:	91000484 	add	x4, x4, #0x1
    40f4:	910060a5 	add	x5, x5, #0x18
    40f8:	f140049f 	cmp	x4, #0x1, lsl #12
    40fc:	54000320 	b.eq	4160 <ad_raw_realloc+0x9c>  // b.none
    4100:	f94000a6 	ldr	x6, [x5]
    4104:	eb06001f 	cmp	x0, x6
    4108:	54ffff41 	b.ne	40f0 <ad_raw_realloc+0x2c>  // b.any
    410c:	8b040484 	add	x4, x4, x4, lsl #1
    4110:	91110021 	add	x1, x1, #0x440
    4114:	8b040c33 	add	x19, x1, x4, lsl #3
    4118:	b4000080 	cbz	x0, 4128 <ad_raw_realloc+0x64>
    411c:	b9401261 	ldr	w1, [x19, #16]
    4120:	6b15003f 	cmp	w1, w21
    4124:	540002c1 	b.ne	417c <ad_raw_realloc+0xb8>  // b.any
    4128:	aa1403e1 	mov	x1, x20
    412c:	97fff9d9 	bl	2890 <realloc@plt>
    4130:	aa0003ed 	mov	x13, x0
    4134:	b40000c0 	cbz	x0, 414c <ad_raw_realloc+0x88>
    4138:	2a1503e3 	mov	w3, w21
    413c:	aa1403e2 	mov	x2, x20
    4140:	aa1303e0 	mov	x0, x19
    4144:	aa0d03e1 	mov	x1, x13
    4148:	97fffb92 	bl	2f90 <ad_raw_record>
    414c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4150:	aa0d03e0 	mov	x0, x13
    4154:	f94013f5 	ldr	x21, [sp, #32]
    4158:	a8c37bfd 	ldp	x29, x30, [sp], #48
    415c:	d65f03c0 	ret
    4160:	f100001f 	cmp	x0, #0x0
    4164:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x820>
    4168:	91366021 	add	x1, x1, #0xd98
    416c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4170:	91360000 	add	x0, x0, #0xd80
    4174:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4178:	97fffc82 	bl	3380 <ad_raw_fail>
    417c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4180:	91376000 	add	x0, x0, #0xdd8
    4184:	97fffc7f 	bl	3380 <ad_raw_fail>
    4188:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    418c:	9136e000 	add	x0, x0, #0xdb8
    4190:	97fffc7c 	bl	3380 <ad_raw_fail>

0000000000004194 <fwp_tape_buffers_release>:
    4194:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4198:	910003fd 	mov	x29, sp
    419c:	a90153f3 	stp	x19, x20, [sp, #16]
    41a0:	aa0003f4 	mov	x20, x0
    41a4:	f9401400 	ldr	x0, [x0, #40]
    41a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    41ac:	b7f80560 	tbnz	x0, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b0:	f9401a93 	ldr	x19, [x20, #48]
    41b4:	b7f80533 	tbnz	x19, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    41bc:	eb01001f 	cmp	x0, x1
    41c0:	540004c8 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41c4:	8b000400 	add	x0, x0, x0, lsl #1
    41c8:	d2a00101 	mov	x1, #0x80000               	// #524288
    41cc:	d37df000 	lsl	x0, x0, #3
    41d0:	cb000021 	sub	x1, x1, x0
    41d4:	eb410e7f 	cmp	x19, x1, lsr #3
    41d8:	54000408 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41dc:	8b130c13 	add	x19, x0, x19, lsl #3
    41e0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    41e4:	9137c000 	add	x0, x0, #0xdf0
    41e8:	97fffa12 	bl	2a30 <getenv@plt>
    41ec:	b4000080 	cbz	x0, 41fc <fwp_tape_buffers_release+0x68>
    41f0:	39400001 	ldrb	w1, [x0]
    41f4:	7100c03f 	cmp	w1, #0x30
    41f8:	54000880 	b.eq	4308 <fwp_tape_buffers_release+0x174>  // b.none
    41fc:	d1000661 	sub	x1, x19, #0x1
    4200:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4204:	eb00003f 	cmp	x1, x0
    4208:	54000328 	b.hi	426c <fwp_tape_buffers_release+0xd8>  // b.pmore
    420c:	900000f5 	adrp	x21, 20000 <__data_start>
    4210:	f9001bf7 	str	x23, [sp, #48]
    4214:	910142b7 	add	x23, x21, #0x50
    4218:	910342f6 	add	x22, x23, #0xd0
    421c:	aa1603e0 	mov	x0, x22
    4220:	97ffff95 	bl	4074 <fwp_tape_buffers_dispose>
    4224:	ad400a81 	ldp	q1, q2, [x20]
    4228:	f90086f3 	str	x19, [x23, #264]
    422c:	4f000400 	movi	v0.4s, #0x0
    4230:	ad000ac1 	stp	q1, q2, [x22]
    4234:	3dc00a81 	ldr	q1, [x20, #32]
    4238:	3d800ac1 	str	q1, [x22, #32]
    423c:	f9401a80 	ldr	x0, [x20, #48]
    4240:	f9001ac0 	str	x0, [x22, #48]
    4244:	f9001a9f 	str	xzr, [x20, #48]
    4248:	ad000280 	stp	q0, q0, [x20]
    424c:	3d800a80 	str	q0, [x20, #32]
    4250:	f9401bf7 	ldr	x23, [sp, #48]
    4254:	1400000b 	b	4280 <fwp_tape_buffers_release+0xec>
    4258:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    425c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4260:	9137c000 	add	x0, x0, #0xdf0
    4264:	97fff9f3 	bl	2a30 <getenv@plt>
    4268:	b5fffc40 	cbnz	x0, 41f0 <fwp_tape_buffers_release+0x5c>
    426c:	aa1403e0 	mov	x0, x20
    4270:	97ffff81 	bl	4074 <fwp_tape_buffers_dispose>
    4274:	900000f5 	adrp	x21, 20000 <__data_start>
    4278:	910142a0 	add	x0, x21, #0x50
    427c:	f9408413 	ldr	x19, [x0, #264]
    4280:	910142a2 	add	x2, x21, #0x50
    4284:	f9408844 	ldr	x4, [x2, #272]
    4288:	a9400c45 	ldp	x5, x3, [x2]
    428c:	8b040481 	add	x1, x4, x4, lsl #1
    4290:	f9400840 	ldr	x0, [x2, #16]
    4294:	8b010881 	add	x1, x4, x1, lsl #2
    4298:	f9400c44 	ldr	x4, [x2, #24]
    429c:	8b0300a3 	add	x3, x5, x3
    42a0:	d37df021 	lsl	x1, x1, #3
    42a4:	8b040000 	add	x0, x0, x4
    42a8:	8b030000 	add	x0, x0, x3
    42ac:	eb05003f 	cmp	x1, x5
    42b0:	54000321 	b.ne	4314 <fwp_tape_buffers_release+0x180>  // b.any
    42b4:	8b130023 	add	x3, x1, x19
    42b8:	eb00007f 	cmp	x3, x0
    42bc:	540002c8 	b.hi	4314 <fwp_tape_buffers_release+0x180>  // b.pmore
    42c0:	f9405c43 	ldr	x3, [x2, #184]
    42c4:	f140087f 	cmp	x3, #0x2, lsl #12
    42c8:	540002e0 	b.eq	4324 <fwp_tape_buffers_release+0x190>  // b.none
    42cc:	8b030464 	add	x4, x3, x3, lsl #1
    42d0:	90000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    42d4:	911100a5 	add	x5, x5, #0x440
    42d8:	cb010000 	sub	x0, x0, x1
    42dc:	d37df084 	lsl	x4, x4, #3
    42e0:	cb130000 	sub	x0, x0, x19
    42e4:	8b0400a6 	add	x6, x5, x4
    42e8:	91000463 	add	x3, x3, #0x1
    42ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42f0:	f82468a1 	str	x1, [x5, x4]
    42f4:	a90080d3 	stp	x19, x0, [x6, #8]
    42f8:	f9005c43 	str	x3, [x2, #184]
    42fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4300:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4304:	d65f03c0 	ret
    4308:	39400400 	ldrb	w0, [x0, #1]
    430c:	34fffb00 	cbz	w0, 426c <fwp_tape_buffers_release+0xd8>
    4310:	17ffffbb 	b	41fc <fwp_tape_buffers_release+0x68>
    4314:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4318:	91382000 	add	x0, x0, #0xe08
    431c:	f9001bf7 	str	x23, [sp, #48]
    4320:	97fffc18 	bl	3380 <ad_raw_fail>
    4324:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4328:	9138e000 	add	x0, x0, #0xe38
    432c:	f9001bf7 	str	x23, [sp, #48]
    4330:	97fffc14 	bl	3380 <ad_raw_fail>

0000000000004334 <fwp_trap>:
    4334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4338:	900000e2 	adrp	x2, 20000 <__data_start>
    433c:	d53bd041 	mrs	x1, tpidr_el0
    4340:	910003fd 	mov	x29, sp
    4344:	f9407042 	ldr	x2, [x2, #224]
    4348:	91400021 	add	x1, x1, #0x0, lsl #12
    434c:	91004021 	add	x1, x1, #0x10
    4350:	a90153f3 	stp	x19, x20, [sp, #16]
    4354:	aa0003f3 	mov	x19, x0
    4358:	f9400034 	ldr	x20, [x1]
    435c:	b4000062 	cbz	x2, 4368 <fwp_trap+0x34>
    4360:	aa0203e0 	mov	x0, x2
    4364:	97fff99b 	bl	29d0 <fflush@plt>
    4368:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    436c:	f947ec00 	ldr	x0, [x0, #4056]
    4370:	f9400000 	ldr	x0, [x0]
    4374:	97fff997 	bl	29d0 <fflush@plt>
    4378:	aa1303e3 	mov	x3, x19
    437c:	b0000022 	adrp	x2, 9000 <fwp_main_thread+0x820>
    4380:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc90>
    4384:	f947ea73 	ldr	x19, [x19, #4048]
    4388:	91396042 	add	x2, x2, #0xe58
    438c:	52800041 	mov	w1, #0x2                   	// #2
    4390:	f9400260 	ldr	x0, [x19]
    4394:	97fff95f 	bl	2910 <__fprintf_chk@plt>
    4398:	b40000b4 	cbz	x20, 43ac <fwp_trap+0x78>
    439c:	f9400260 	ldr	x0, [x19]
    43a0:	97fff98c 	bl	29d0 <fflush@plt>
    43a4:	52800ca0 	mov	w0, #0x65                  	// #101
    43a8:	97fff99a 	bl	2a10 <_Exit@plt>
    43ac:	52800ca0 	mov	w0, #0x65                  	// #101
    43b0:	97fff8e8 	bl	2750 <exit@plt>

00000000000043b4 <fwp_rc_forget_slot.part.0>:
    43b4:	ca404401 	eor	x1, x0, x0, lsr #17
    43b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43bc:	ca412421 	eor	x1, x1, x1, lsr #9
    43c0:	910003fd 	mov	x29, sp
    43c4:	92401c21 	and	x1, x1, #0xff
    43c8:	f9000bf3 	str	x19, [sp, #16]
    43cc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    43d0:	91188262 	add	x2, x19, #0x620
    43d4:	910a2423 	add	x3, x1, #0x289
    43d8:	8b010c41 	add	x1, x2, x1, lsl #3
    43dc:	8b030c43 	add	x3, x2, x3, lsl #3
    43e0:	f94a2421 	ldr	x1, [x1, #5192]
    43e4:	b50000a1 	cbnz	x1, 43f8 <fwp_rc_forget_slot.part.0+0x44>
    43e8:	14000012 	b	4430 <fwp_rc_forget_slot.part.0+0x7c>
    43ec:	91004023 	add	x3, x1, #0x10
    43f0:	f9400821 	ldr	x1, [x1, #16]
    43f4:	b40001e1 	cbz	x1, 4430 <fwp_rc_forget_slot.part.0+0x7c>
    43f8:	f9400022 	ldr	x2, [x1]
    43fc:	eb02001f 	cmp	x0, x2
    4400:	54ffff61 	b.ne	43ec <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4404:	f9400060 	ldr	x0, [x3]
    4408:	91188273 	add	x19, x19, #0x620
    440c:	f9400801 	ldr	x1, [x0, #16]
    4410:	f9000061 	str	x1, [x3]
    4414:	97fff953 	bl	2960 <free@plt>
    4418:	f94e2660 	ldr	x0, [x19, #7240]
    441c:	d1000400 	sub	x0, x0, #0x1
    4420:	f90e2660 	str	x0, [x19, #7240]
    4424:	f9400bf3 	ldr	x19, [sp, #16]
    4428:	a8c27bfd 	ldp	x29, x30, [sp], #32
    442c:	d65f03c0 	ret
    4430:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4434:	9139a000 	add	x0, x0, #0xe68
    4438:	97ffffbf 	bl	4334 <fwp_trap>
    443c:	d503201f 	nop

0000000000004440 <fwp_rc_prepare_chunk>:
    4440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4444:	910003fd 	mov	x29, sp
    4448:	a9025bf5 	stp	x21, x22, [sp, #32]
    444c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    4450:	911882c2 	add	x2, x22, #0x620
    4454:	b9401c03 	ldr	w3, [x0, #28]
    4458:	aa0103f5 	mov	x21, x1
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f4 	mov	x20, x0
    4464:	f94e2440 	ldr	x0, [x2, #7240]
    4468:	b4000440 	cbz	x0, 44f0 <fwp_rc_prepare_chunk+0xb0>
    446c:	d2800013 	mov	x19, #0x0                   	// #0
    4470:	35000203 	cbnz	w3, 44b0 <fwp_rc_prepare_chunk+0x70>
    4474:	b4000361 	cbz	x1, 44e0 <fwp_rc_prepare_chunk+0xa0>
    4478:	f9401280 	ldr	x0, [x20, #32]
    447c:	97fff939 	bl	2960 <free@plt>
    4480:	aa1503e0 	mov	x0, x21
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	97fff8fe 	bl	2880 <calloc@plt>
    448c:	f9001280 	str	x0, [x20, #32]
    4490:	b5000460 	cbnz	x0, 451c <fwp_rc_prepare_chunk+0xdc>
    4494:	97fffb37 	bl	3170 <fwp_heap_oom>
    4498:	97ffffc7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    449c:	91000673 	add	x19, x19, #0x1
    44a0:	b9401e83 	ldr	w3, [x20, #28]
    44a4:	eb13007f 	cmp	x3, x19
    44a8:	54000169 	b.ls	44d4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    44ac:	d503201f 	nop
    44b0:	f9401283 	ldr	x3, [x20, #32]
    44b4:	8b130060 	add	x0, x3, x19
    44b8:	38736863 	ldrb	w3, [x3, x19]
    44bc:	7103fc7f 	cmp	w3, #0xff
    44c0:	54fffec0 	b.eq	4498 <fwp_rc_prepare_chunk+0x58>  // b.none
    44c4:	b9401e83 	ldr	w3, [x20, #28]
    44c8:	91000673 	add	x19, x19, #0x1
    44cc:	eb13007f 	cmp	x3, x19
    44d0:	54ffff08 	b.hi	44b0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    44d4:	eb0302bf 	cmp	x21, x3
    44d8:	54000121 	b.ne	44fc <fwp_rc_prepare_chunk+0xbc>  // b.any
    44dc:	b5000335 	cbnz	x21, 4540 <fwp_rc_prepare_chunk+0x100>
    44e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	2a0303e3 	mov	w3, w3
    44f4:	eb0302bf 	cmp	x21, x3
    44f8:	54ffff20 	b.eq	44dc <fwp_rc_prepare_chunk+0x9c>  // b.none
    44fc:	911882c2 	add	x2, x22, #0x620
    4500:	f9401280 	ldr	x0, [x20, #32]
    4504:	f94e2841 	ldr	x1, [x2, #7248]
    4508:	cb030021 	sub	x1, x1, x3
    450c:	f90e2841 	str	x1, [x2, #7248]
    4510:	97fff914 	bl	2960 <free@plt>
    4514:	b5fffb75 	cbnz	x21, 4480 <fwp_rc_prepare_chunk+0x40>
    4518:	f900129f 	str	xzr, [x20, #32]
    451c:	911882d6 	add	x22, x22, #0x620
    4520:	f94e2ac0 	ldr	x0, [x22, #7248]
    4524:	b9001e95 	str	w21, [x20, #28]
    4528:	a94153f3 	ldp	x19, x20, [sp, #16]
    452c:	8b150000 	add	x0, x0, x21
    4530:	f90e2ac0 	str	x0, [x22, #7248]
    4534:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f9401280 	ldr	x0, [x20, #32]
    4544:	aa1503e2 	mov	x2, x21
    4548:	a94153f3 	ldp	x19, x20, [sp, #16]
    454c:	52800001 	mov	w1, #0x0                   	// #0
    4550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4558:	17fff8c6 	b	2870 <memset@plt>
    455c:	d503201f 	nop

0000000000004560 <fwp_heap_refill>:
    4560:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4564:	910003fd 	mov	x29, sp
    4568:	a9025bf5 	stp	x21, x22, [sp, #32]
    456c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4570:	911882b5 	add	x21, x21, #0x620
    4574:	aa0003f6 	mov	x22, x0
    4578:	d2800020 	mov	x0, #0x1                   	// #1
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	a90363f7 	stp	x23, x24, [sp, #48]
    4584:	2a0103f7 	mov	w23, w1
    4588:	2a0203f8 	mov	w24, w2
    458c:	97fffb09 	bl	31b0 <fwp_heap_chunks>
    4590:	aa0003f3 	mov	x19, x0
    4594:	f949fea2 	ldr	x2, [x21, #5112]
    4598:	8b000800 	add	x0, x0, x0, lsl #2
    459c:	2a1703e1 	mov	w1, w23
    45a0:	52800025 	mov	w5, #0x1                   	// #1
    45a4:	d37df000 	lsl	x0, x0, #3
    45a8:	910f0021 	add	x1, x1, #0x3c0
    45ac:	8b000054 	add	x20, x2, x0
    45b0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    45b4:	52a00024 	mov	w4, #0x10000               	// #65536
    45b8:	38206845 	strb	w5, [x2, x0]
    45bc:	aa1403e0 	mov	x0, x20
    45c0:	39000698 	strb	w24, [x20, #1]
    45c4:	39000a97 	strb	w23, [x20, #2]
    45c8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    45cc:	b9000681 	str	w1, [x20, #4]
    45d0:	2a0103e5 	mov	w5, w1
    45d4:	8b0300a2 	add	x2, x5, x3
    45d8:	1ac10881 	udiv	w1, w4, w1
    45dc:	9ac50842 	udiv	x2, x2, x5
    45e0:	b9000a81 	str	w1, [x20, #8]
    45e4:	92404021 	and	x1, x1, #0x1ffff
    45e8:	b9001a82 	str	w2, [x20, #24]
    45ec:	97ffff95 	bl	4440 <fwp_rc_prepare_chunk>
    45f0:	f949daa0 	ldr	x0, [x21, #5040]
    45f4:	29408a81 	ldp	w1, w2, [x20, #4]
    45f8:	8b134000 	add	x0, x0, x19, lsl #16
    45fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4600:	8b214003 	add	x3, x0, w1, uxtw
    4604:	9ba20021 	umaddl	x1, w1, w2, x0
    4608:	a94363f7 	ldp	x23, x24, [sp, #48]
    460c:	a90086c3 	stp	x3, x1, [x22, #8]
    4610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4614:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4618:	d65f03c0 	ret
    461c:	d503201f 	nop

0000000000004620 <fwp_mem_free>:
    4620:	b40003c0 	cbz	x0, 4698 <fwp_mem_free+0x78>
    4624:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4628:	910003fd 	mov	x29, sp
    462c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4630:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4634:	911882a1 	add	x1, x21, #0x620
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	aa0003f3 	mov	x19, x0
    4640:	f949d823 	ldr	x3, [x1, #5040]
    4644:	f949ec22 	ldr	x2, [x1, #5080]
    4648:	cb030000 	sub	x0, x0, x3
    464c:	eb02401f 	cmp	x0, x2, lsl #16
    4650:	540001c2 	b.cs	4688 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4654:	d350fc16 	lsr	x22, x0, #16
    4658:	a90363f7 	stp	x23, x24, [sp, #48]
    465c:	f949fc22 	ldr	x2, [x1, #5112]
    4660:	8b160ad4 	add	x20, x22, x22, lsl #2
    4664:	d37df294 	lsl	x20, x20, #3
    4668:	ab140057 	adds	x23, x2, x20
    466c:	540000c0 	b.eq	4684 <fwp_mem_free+0x64>  // b.none
    4670:	38746842 	ldrb	w2, [x2, x20]
    4674:	7100045f 	cmp	w2, #0x1
    4678:	54000120 	b.eq	469c <fwp_mem_free+0x7c>  // b.none
    467c:	7100085f 	cmp	w2, #0x2
    4680:	540005e0 	b.eq	473c <fwp_mem_free+0x11c>  // b.none
    4684:	a94363f7 	ldp	x23, x24, [sp, #48]
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4690:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4694:	d65f03c0 	ret
    4698:	d65f03c0 	ret
    469c:	f94012f8 	ldr	x24, [x23, #32]
    46a0:	b94006e1 	ldr	w1, [x23, #4]
    46a4:	f90023f9 	str	x25, [sp, #64]
    46a8:	2a0103e2 	mov	w2, w1
    46ac:	394006f9 	ldrb	w25, [x23, #1]
    46b0:	39400af4 	ldrb	w20, [x23, #2]
    46b4:	b4000158 	cbz	x24, 46dc <fwp_mem_free+0xbc>
    46b8:	92403e76 	and	x22, x19, #0xffff
    46bc:	9ac20ad6 	udiv	x22, x22, x2
    46c0:	38766b01 	ldrb	w1, [x24, x22]
    46c4:	8b160300 	add	x0, x24, x22
    46c8:	7103fc3f 	cmp	w1, #0xff
    46cc:	54000980 	b.eq	47fc <fwp_mem_free+0x1dc>  // b.none
    46d0:	38366b1f 	strb	wzr, [x24, x22]
    46d4:	b94006e1 	ldr	w1, [x23, #4]
    46d8:	2a0103e2 	mov	w2, w1
    46dc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    46e0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    46e4:	cb390000 	sub	x0, x0, w25, uxtb
    46e8:	8b340074 	add	x20, x3, w20, uxtb
    46ec:	911882b5 	add	x21, x21, #0x620
    46f0:	1e630021 	ucvtf	d1, w1
    46f4:	d37ae400 	lsl	x0, x0, #6
    46f8:	8b140c14 	add	x20, x0, x20, lsl #3
    46fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4700:	f8746aa0 	ldr	x0, [x21, x20]
    4704:	f94023f9 	ldr	x25, [sp, #64]
    4708:	aa2003e0 	mvn	x0, x0
    470c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4710:	f9000260 	str	x0, [x19]
    4714:	f8346ab3 	str	x19, [x21, x20]
    4718:	f94a12a0 	ldr	x0, [x21, #5152]
    471c:	1e612800 	fadd	d0, d0, d1
    4720:	a94153f3 	ldp	x19, x20, [sp, #16]
    4724:	cb020000 	sub	x0, x0, x2
    4728:	f90a12a0 	str	x0, [x21, #5152]
    472c:	fd0a22a0 	str	d0, [x21, #5184]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4738:	d65f03c0 	ret
    473c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4740:	8b000063 	add	x3, x3, x0
    4744:	eb03027f 	cmp	x19, x3
    4748:	54fff9e1 	b.ne	4684 <fwp_mem_free+0x64>  // b.any
    474c:	fd400ae1 	ldr	d1, [x23, #16]
    4750:	fd4a2020 	ldr	d0, [x1, #5184]
    4754:	f9400ae0 	ldr	x0, [x23, #16]
    4758:	7e61d821 	ucvtf	d1, d1
    475c:	f94a1022 	ldr	x2, [x1, #5152]
    4760:	f94012f3 	ldr	x19, [x23, #32]
    4764:	1e612800 	fadd	d0, d0, d1
    4768:	cb000042 	sub	x2, x2, x0
    476c:	f90a1022 	str	x2, [x1, #5152]
    4770:	fd0a2020 	str	d0, [x1, #5184]
    4774:	b40000b3 	cbz	x19, 4788 <fwp_mem_free+0x168>
    4778:	39400260 	ldrb	w0, [x19]
    477c:	7103fc1f 	cmp	w0, #0xff
    4780:	54000380 	b.eq	47f0 <fwp_mem_free+0x1d0>  // b.none
    4784:	3900027f 	strb	wzr, [x19]
    4788:	b9400ee2 	ldr	w2, [x23, #12]
    478c:	b4000142 	cbz	x2, 47b4 <fwp_mem_free+0x194>
    4790:	911882a1 	add	x1, x21, #0x620
    4794:	8b160040 	add	x0, x2, x22
    4798:	8b000800 	add	x0, x0, x0, lsl #2
    479c:	f949fc21 	ldr	x1, [x1, #5112]
    47a0:	8b140034 	add	x20, x1, x20
    47a4:	8b000c20 	add	x0, x1, x0, lsl #3
    47a8:	3802869f 	strb	wzr, [x20], #40
    47ac:	eb00029f 	cmp	x20, x0
    47b0:	54ffffc1 	b.ne	47a8 <fwp_mem_free+0x188>  // b.any
    47b4:	911882a0 	add	x0, x21, #0x620
    47b8:	f94a1801 	ldr	x1, [x0, #5168]
    47bc:	f949f803 	ldr	x3, [x0, #5104]
    47c0:	8b020021 	add	x1, x1, x2
    47c4:	f90a1801 	str	x1, [x0, #5168]
    47c8:	eb16007f 	cmp	x3, x22
    47cc:	54000049 	b.ls	47d4 <fwp_mem_free+0x1b4>  // b.plast
    47d0:	f909f816 	str	x22, [x0, #5104]
    47d4:	911882b5 	add	x21, x21, #0x620
    47d8:	f949f6a0 	ldr	x0, [x21, #5096]
    47dc:	eb16001f 	cmp	x0, x22
    47e0:	54fff529 	b.ls	4684 <fwp_mem_free+0x64>  // b.plast
    47e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47e8:	f909f6b6 	str	x22, [x21, #5096]
    47ec:	17ffffa7 	b	4688 <fwp_mem_free+0x68>
    47f0:	aa1303e0 	mov	x0, x19
    47f4:	97fffef0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    47f8:	17ffffe3 	b	4784 <fwp_mem_free+0x164>
    47fc:	97fffeee 	bl	43b4 <fwp_rc_forget_slot.part.0>
    4800:	17ffffb4 	b	46d0 <fwp_mem_free+0xb0>

0000000000004804 <fwp_rc_wide_dup>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	910003fd 	mov	x29, sp
    480c:	a90153f3 	stp	x19, x20, [sp, #16]
    4810:	aa0003f3 	mov	x19, x0
    4814:	ca404400 	eor	x0, x0, x0, lsr #17
    4818:	f90013f5 	str	x21, [sp, #32]
    481c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4820:	ca402400 	eor	x0, x0, x0, lsr #9
    4824:	911882a2 	add	x2, x21, #0x620
    4828:	92401c00 	and	x0, x0, #0xff
    482c:	910a2403 	add	x3, x0, #0x289
    4830:	8b000c40 	add	x0, x2, x0, lsl #3
    4834:	8b030c54 	add	x20, x2, x3, lsl #3
    4838:	f94a2401 	ldr	x1, [x0, #5192]
    483c:	b50000a1 	cbnz	x1, 4850 <fwp_rc_wide_dup+0x4c>
    4840:	14000033 	b	490c <fwp_rc_wide_dup+0x108>
    4844:	91004034 	add	x20, x1, #0x10
    4848:	f9400821 	ldr	x1, [x1, #16]
    484c:	b4000241 	cbz	x1, 4894 <fwp_rc_wide_dup+0x90>
    4850:	f9400022 	ldr	x2, [x1]
    4854:	eb02027f 	cmp	x19, x2
    4858:	54ffff61 	b.ne	4844 <fwp_rc_wide_dup+0x40>  // b.any
    485c:	f9400281 	ldr	x1, [x20]
    4860:	39400260 	ldrb	w0, [x19]
    4864:	7103f81f 	cmp	w0, #0xfe
    4868:	54000220 	b.eq	48ac <fwp_rc_wide_dup+0xa8>  // b.none
    486c:	b40001a1 	cbz	x1, 48a0 <fwp_rc_wide_dup+0x9c>
    4870:	f9400420 	ldr	x0, [x1, #8]
    4874:	b100041f 	cmn	x0, #0x1
    4878:	54000440 	b.eq	4900 <fwp_rc_wide_dup+0xfc>  // b.none
    487c:	91000400 	add	x0, x0, #0x1
    4880:	f9000420 	str	x0, [x1, #8]
    4884:	a94153f3 	ldp	x19, x20, [sp, #16]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	39400260 	ldrb	w0, [x19]
    4898:	7103f81f 	cmp	w0, #0xfe
    489c:	54000100 	b.eq	48bc <fwp_rc_wide_dup+0xb8>  // b.none
    48a0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    48a4:	9139a000 	add	x0, x0, #0xe68
    48a8:	97fffea3 	bl	4334 <fwp_trap>
    48ac:	b4000081 	cbz	x1, 48bc <fwp_rc_wide_dup+0xb8>
    48b0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    48b4:	913a4000 	add	x0, x0, #0xe90
    48b8:	97fffe9f 	bl	4334 <fwp_trap>
    48bc:	d2800300 	mov	x0, #0x18                  	// #24
    48c0:	97fff7e0 	bl	2840 <malloc@plt>
    48c4:	b4000280 	cbz	x0, 4914 <fwp_rc_wide_dup+0x110>
    48c8:	d2801fe1 	mov	x1, #0xff                  	// #255
    48cc:	a9000413 	stp	x19, x1, [x0]
    48d0:	911882b5 	add	x21, x21, #0x620
    48d4:	f900081f 	str	xzr, [x0, #16]
    48d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    48dc:	f9000280 	str	x0, [x20]
    48e0:	39000261 	strb	w1, [x19]
    48e4:	f94e26a0 	ldr	x0, [x21, #7240]
    48e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f90e26a0 	str	x0, [x21, #7240]
    48f4:	f94013f5 	ldr	x21, [sp, #32]
    48f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48fc:	d65f03c0 	ret
    4900:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4904:	913ae000 	add	x0, x0, #0xeb8
    4908:	97fffe8b 	bl	4334 <fwp_trap>
    490c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4910:	17ffffd4 	b	4860 <fwp_rc_wide_dup+0x5c>
    4914:	97fffa17 	bl	3170 <fwp_heap_oom>
    4918:	d503201f 	nop
    491c:	d503201f 	nop

0000000000004920 <fwp_closure_drop_push>:
    4920:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4924:	910003fd 	mov	x29, sp
    4928:	a90153f3 	stp	x19, x20, [sp, #16]
    492c:	aa0003f3 	mov	x19, x0
    4930:	a9408014 	ldp	x20, x0, [x0, #8]
    4934:	a9025bf5 	stp	x21, x22, [sp, #32]
    4938:	aa0103f5 	mov	x21, x1
    493c:	a90363f7 	stp	x23, x24, [sp, #48]
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000160 	b.eq	4970 <fwp_closure_drop_push+0x50>  // b.none
    4948:	f9400276 	ldr	x22, [x19]
    494c:	d37df297 	lsl	x23, x20, #3
    4950:	91000694 	add	x20, x20, #0x1
    4954:	f9000674 	str	x20, [x19, #8]
    4958:	a94153f3 	ldp	x19, x20, [sp, #16]
    495c:	f8376ad5 	str	x21, [x22, x23]
    4960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4964:	a94363f7 	ldp	x23, x24, [sp, #48]
    4968:	a8c57bfd 	ldp	x29, x30, [sp], #80
    496c:	d65f03c0 	ret
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4978:	eb00029f 	cmp	x20, x0
    497c:	540003e8 	b.hi	49f8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4980:	d37cee99 	lsl	x25, x20, #4
    4984:	d37ffa9a 	lsl	x26, x20, #1
    4988:	aa1903e0 	mov	x0, x25
    498c:	97fff7ad 	bl	2840 <malloc@plt>
    4990:	aa0003f6 	mov	x22, x0
    4994:	b4000380 	cbz	x0, 4a04 <fwp_closure_drop_push+0xe4>
    4998:	aa1303f8 	mov	x24, x19
    499c:	aa1903e3 	mov	x3, x25
    49a0:	d37df297 	lsl	x23, x20, #3
    49a4:	aa1703e2 	mov	x2, x23
    49a8:	f8418719 	ldr	x25, [x24], #24
    49ac:	aa1903e1 	mov	x1, x25
    49b0:	97fff790 	bl	27f0 <__memcpy_chk@plt>
    49b4:	eb18033f 	cmp	x25, x24
    49b8:	540000a0 	b.eq	49cc <fwp_closure_drop_push+0xac>  // b.none
    49bc:	aa1903e0 	mov	x0, x25
    49c0:	97fff7e8 	bl	2960 <free@plt>
    49c4:	f9400674 	ldr	x20, [x19, #8]
    49c8:	d37df297 	lsl	x23, x20, #3
    49cc:	91000694 	add	x20, x20, #0x1
    49d0:	f9000276 	str	x22, [x19]
    49d4:	f9000a7a 	str	x26, [x19, #16]
    49d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    49dc:	f9000674 	str	x20, [x19, #8]
    49e0:	f8376ad5 	str	x21, [x22, x23]
    49e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    49f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49f4:	d65f03c0 	ret
    49f8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    49fc:	913b6000 	add	x0, x0, #0xed8
    4a00:	97fffe4d 	bl	4334 <fwp_trap>
    4a04:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a08:	f947e863 	ldr	x3, [x3, #4048]
    4a0c:	d2800262 	mov	x2, #0x13                  	// #19
    4a10:	d2800021 	mov	x1, #0x1                   	// #1
    4a14:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4a18:	912c6000 	add	x0, x0, #0xb18
    4a1c:	f9400063 	ldr	x3, [x3]
    4a20:	97fff7e0 	bl	29a0 <fwrite@plt>
    4a24:	d2800000 	mov	x0, #0x0                   	// #0
    4a28:	97fff7ea 	bl	29d0 <fflush@plt>
    4a2c:	52800cc0 	mov	w0, #0x66                  	// #102
    4a30:	97fff7f8 	bl	2a10 <_Exit@plt>

0000000000004a34 <fwp_closure_drop.part.0>:
    4a34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a38:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    4a3c:	910003fd 	mov	x29, sp
    4a40:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a44:	f947f463 	ldr	x3, [x3, #4072]
    4a48:	a90153f3 	stp	x19, x20, [sp, #16]
    4a4c:	d10883ff 	sub	sp, sp, #0x220
    4a50:	910003e2 	mov	x2, sp
    4a54:	d53bd053 	mrs	x19, tpidr_el0
    4a58:	910063f4 	add	x20, sp, #0x18
    4a5c:	3dc28020 	ldr	q0, [x1, #2560]
    4a60:	91400264 	add	x4, x19, #0x0, lsl #12
    4a64:	91004084 	add	x4, x4, #0x10
    4a68:	aa0003e1 	mov	x1, x0
    4a6c:	aa0203e0 	mov	x0, x2
    4a70:	f9400062 	ldr	x2, [x3]
    4a74:	f9010fe2 	str	x2, [sp, #536]
    4a78:	d2800002 	mov	x2, #0x0                   	// #0
    4a7c:	f90003f4 	str	x20, [sp]
    4a80:	f9000080 	str	x0, [x4]
    4a84:	3c8083e0 	stur	q0, [sp, #8]
    4a88:	97ffffa6 	bl	4920 <fwp_closure_drop_push>
    4a8c:	f94007e0 	ldr	x0, [sp, #8]
    4a90:	b40002e0 	cbz	x0, 4aec <fwp_closure_drop.part.0+0xb8>
    4a94:	f90123f5 	str	x21, [sp, #576]
    4a98:	900000f5 	adrp	x21, 20000 <__data_start>
    4a9c:	910142b5 	add	x21, x21, #0x50
    4aa0:	14000006 	b	4ab8 <fwp_closure_drop.part.0+0x84>
    4aa4:	f9400422 	ldr	x2, [x1, #8]
    4aa8:	52800001 	mov	w1, #0x0                   	// #0
    4aac:	d63f0040 	blr	x2
    4ab0:	f94007e0 	ldr	x0, [sp, #8]
    4ab4:	b40001a0 	cbz	x0, 4ae8 <fwp_closure_drop.part.0+0xb4>
    4ab8:	f94003e1 	ldr	x1, [sp]
    4abc:	d1000400 	sub	x0, x0, #0x1
    4ac0:	f90007e0 	str	x0, [sp, #8]
    4ac4:	f9408ea2 	ldr	x2, [x21, #280]
    4ac8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4acc:	b9400001 	ldr	w1, [x0]
    4ad0:	8b011441 	add	x1, x2, x1, lsl #5
    4ad4:	f9400c21 	ldr	x1, [x1, #24]
    4ad8:	b5fffe61 	cbnz	x1, 4aa4 <fwp_closure_drop.part.0+0x70>
    4adc:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4ae0:	913be000 	add	x0, x0, #0xef8
    4ae4:	97fffe14 	bl	4334 <fwp_trap>
    4ae8:	f94123f5 	ldr	x21, [sp, #576]
    4aec:	91400273 	add	x19, x19, #0x0, lsl #12
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	f94003e0 	ldr	x0, [sp]
    4af8:	f900027f 	str	xzr, [x19]
    4afc:	eb14001f 	cmp	x0, x20
    4b00:	54000040 	b.eq	4b08 <fwp_closure_drop.part.0+0xd4>  // b.none
    4b04:	97fff797 	bl	2960 <free@plt>
    4b08:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4b0c:	f947f400 	ldr	x0, [x0, #4072]
    4b10:	f9410fe2 	ldr	x2, [sp, #536]
    4b14:	f9400001 	ldr	x1, [x0]
    4b18:	eb010042 	subs	x2, x2, x1
    4b1c:	d2800001 	mov	x1, #0x0                   	// #0
    4b20:	540000a1 	b.ne	4b34 <fwp_closure_drop.part.0+0x100>  // b.any
    4b24:	910883ff 	add	sp, sp, #0x220
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b30:	d65f03c0 	ret
    4b34:	f90123f5 	str	x21, [sp, #576]
    4b38:	97fff75a 	bl	28a0 <__stack_chk_fail@plt>
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_tape_of>:
    4b40:	aa0003e1 	mov	x1, x0
    4b44:	92403c00 	and	x0, x0, #0xffff
    4b48:	b40000e0 	cbz	x0, 4b64 <fwp_tape_of+0x24>
    4b4c:	d1000402 	sub	x2, x0, #0x1
    4b50:	900000e0 	adrp	x0, 20000 <__data_start>
    4b54:	91014000 	add	x0, x0, #0x50
    4b58:	f9409003 	ldr	x3, [x0, #288]
    4b5c:	eb02007f 	cmp	x3, x2
    4b60:	540000cc 	b.gt	4b78 <fwp_tape_of+0x38>
    4b64:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b68:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4b6c:	913ca000 	add	x0, x0, #0xf28
    4b70:	910003fd 	mov	x29, sp
    4b74:	97fffdf0 	bl	4334 <fwp_trap>
    4b78:	8b020443 	add	x3, x2, x2, lsl #1
    4b7c:	f9404404 	ldr	x4, [x0, #136]
    4b80:	8b030842 	add	x2, x2, x3, lsl #2
    4b84:	d37df042 	lsl	x2, x2, #3
    4b88:	8b020080 	add	x0, x4, x2
    4b8c:	b9400403 	ldr	w3, [x0, #4]
    4b90:	34fffea3 	cbz	w3, 4b64 <fwp_tape_of+0x24>
    4b94:	b8626882 	ldr	w2, [x4, x2]
    4b98:	9350fc21 	asr	x1, x1, #16
    4b9c:	6b01005f 	cmp	w2, w1
    4ba0:	54fffe21 	b.ne	4b64 <fwp_tape_of+0x24>  // b.any
    4ba4:	d65f03c0 	ret
    4ba8:	d503201f 	nop
    4bac:	d503201f 	nop

0000000000004bb0 <fwp_now_ns>:
    4bb0:	d100c3ff 	sub	sp, sp, #0x30
    4bb4:	52800020 	mov	w0, #0x1                   	// #1
    4bb8:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    4bbc:	f947f442 	ldr	x2, [x2, #4072]
    4bc0:	910023e1 	add	x1, sp, #0x8
    4bc4:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bc8:	910083fd 	add	x29, sp, #0x20
    4bcc:	f9400043 	ldr	x3, [x2]
    4bd0:	f9000fe3 	str	x3, [sp, #24]
    4bd4:	d2800003 	mov	x3, #0x0                   	// #0
    4bd8:	97fff6fe 	bl	27d0 <clock_gettime@plt>
    4bdc:	350002c0 	cbnz	w0, 4c34 <fwp_now_ns+0x84>
    4be0:	a9408be1 	ldp	x1, x2, [sp, #8]
    4be4:	d2994003 	mov	x3, #0xca00                	// #51712
    4be8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4bec:	9b037c20 	mul	x0, x1, x3
    4bf0:	9b437c21 	smulh	x1, x1, x3
    4bf4:	ab020000 	adds	x0, x0, x2
    4bf8:	937ffc42 	asr	x2, x2, #63
    4bfc:	9a020021 	adc	x1, x1, x2
    4c00:	f100001f 	cmp	x0, #0x0
    4c04:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4c08:	b50001c1 	cbnz	x1, 4c40 <fwp_now_ns+0x90>
    4c0c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    4c10:	f947f421 	ldr	x1, [x1, #4072]
    4c14:	f9400fe3 	ldr	x3, [sp, #24]
    4c18:	f9400022 	ldr	x2, [x1]
    4c1c:	eb020063 	subs	x3, x3, x2
    4c20:	d2800002 	mov	x2, #0x0                   	// #0
    4c24:	54000141 	b.ne	4c4c <fwp_now_ns+0x9c>  // b.any
    4c28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c2c:	9100c3ff 	add	sp, sp, #0x30
    4c30:	d65f03c0 	ret
    4c34:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4c38:	913de000 	add	x0, x0, #0xf78
    4c3c:	97fffdbe 	bl	4334 <fwp_trap>
    4c40:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4c44:	913e6000 	add	x0, x0, #0xf98
    4c48:	97fffdbb 	bl	4334 <fwp_trap>
    4c4c:	97fff715 	bl	28a0 <__stack_chk_fail@plt>

0000000000004c50 <fwp_poll_events>:
    4c50:	d10103ff 	sub	sp, sp, #0x40
    4c54:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4c58:	f947f400 	ldr	x0, [x0, #4072]
    4c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c60:	910083fd 	add	x29, sp, #0x20
    4c64:	f9001bf3 	str	x19, [sp, #48]
    4c68:	900000f3 	adrp	x19, 20000 <__data_start>
    4c6c:	f9400001 	ldr	x1, [x0]
    4c70:	f9000fe1 	str	x1, [sp, #24]
    4c74:	d2800001 	mov	x1, #0x0                   	// #0
    4c78:	97ffffce 	bl	4bb0 <fwp_now_ns>
    4c7c:	91014261 	add	x1, x19, #0x50
    4c80:	f9409421 	ldr	x1, [x1, #296]
    4c84:	b4000e01 	cbz	x1, 4e44 <fwp_poll_events+0x1f4>
    4c88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c8c:	14000005 	b	4ca0 <fwp_poll_events+0x50>
    4c90:	f9408821 	ldr	x1, [x1, #272]
    4c94:	eb03005f 	cmp	x2, x3
    4c98:	9a83d042 	csel	x2, x2, x3, le
    4c9c:	b40000c1 	cbz	x1, 4cb4 <fwp_poll_events+0x64>
    4ca0:	f9403423 	ldr	x3, [x1, #104]
    4ca4:	b6ffff62 	tbz	x2, #63, 4c90 <fwp_poll_events+0x40>
    4ca8:	f9408821 	ldr	x1, [x1, #272]
    4cac:	aa0303e2 	mov	x2, x3
    4cb0:	b5ffff81 	cbnz	x1, 4ca0 <fwp_poll_events+0x50>
    4cb4:	b7f80c82 	tbnz	x2, #63, 4e44 <fwp_poll_events+0x1f4>
    4cb8:	cb000042 	sub	x2, x2, x0
    4cbc:	f100005f 	cmp	x2, #0x0
    4cc0:	540003ad 	b.le	4d34 <fwp_poll_events+0xe4>
    4cc4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4cc8:	d2884804 	mov	x4, #0x4240                	// #16960
    4ccc:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4cd0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4cd4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4cd8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4cdc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ce0:	9b407c40 	smulh	x0, x2, x0
    4ce4:	9352fc00 	asr	x0, x0, #18
    4ce8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4cec:	9b048802 	msub	x2, x0, x4, x2
    4cf0:	f100005f 	cmp	x2, #0x0
    4cf4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4cf8:	eb01001f 	cmp	x0, x1
    4cfc:	5400098c 	b.gt	4e2c <fwp_poll_events+0x1dc>
    4d00:	340001a0 	cbz	w0, 4d34 <fwp_poll_events+0xe4>
    4d04:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4d08:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4d0c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4d10:	9ba17c01 	umull	x1, w0, w1
    4d14:	d366fc23 	lsr	x3, x1, #38
    4d18:	aa0303e2 	mov	x2, x3
    4d1c:	1b058063 	msub	w3, w3, w5, w0
    4d20:	9b247c63 	smull	x3, w3, w4
    4d24:	910023e0 	add	x0, sp, #0x8
    4d28:	d2800001 	mov	x1, #0x0                   	// #0
    4d2c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4d30:	97fff710 	bl	2970 <nanosleep@plt>
    4d34:	97ffff9f 	bl	4bb0 <fwp_now_ns>
    4d38:	91014268 	add	x8, x19, #0x50
    4d3c:	aa0003e7 	mov	x7, x0
    4d40:	4f000400 	movi	v0.4s, #0x0
    4d44:	52800029 	mov	w9, #0x1                   	// #1
    4d48:	f9409506 	ldr	x6, [x8, #296]
    4d4c:	d503201f 	nop
    4d50:	b40003e6 	cbz	x6, 4dcc <fwp_poll_events+0x17c>
    4d54:	f94034c1 	ldr	x1, [x6, #104]
    4d58:	aa0603e5 	mov	x5, x6
    4d5c:	f94088c6 	ldr	x6, [x6, #272]
    4d60:	eb07003f 	cmp	x1, x7
    4d64:	54ffff6c 	b.gt	4d50 <fwp_poll_events+0x100>
    4d68:	394154a0 	ldrb	w0, [x5, #85]
    4d6c:	36000120 	tbz	w0, #0, 4d90 <fwp_poll_events+0x140>
    4d70:	f94084a0 	ldr	x0, [x5, #264]
    4d74:	b4000560 	cbz	x0, 4e20 <fwp_poll_events+0x1d0>
    4d78:	f9008806 	str	x6, [x0, #272]
    4d7c:	b4000046 	cbz	x6, 4d84 <fwp_poll_events+0x134>
    4d80:	f90084c0 	str	x0, [x6, #264]
    4d84:	910800a0 	add	x0, x5, #0x200
    4d88:	390154bf 	strb	wzr, [x5, #85]
    4d8c:	3c908000 	stur	q0, [x0, #-248]
    4d90:	f94030a0 	ldr	x0, [x5, #96]
    4d94:	390158a9 	strb	w9, [x5, #86]
    4d98:	f100001f 	cmp	x0, #0x0
    4d9c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4da0:	540002cd 	b.le	4df8 <fwp_poll_events+0x1a8>
    4da4:	f94028a0 	ldr	x0, [x5, #80]
    4da8:	f2001c1f 	tst	x0, #0xff000000ff
    4dac:	54fffd21 	b.ne	4d50 <fwp_poll_events+0x100>  // b.any
    4db0:	f9406100 	ldr	x0, [x8, #192]
    4db4:	390150a9 	strb	w9, [x5, #84]
    4db8:	f90080bf 	str	xzr, [x5, #256]
    4dbc:	b40002c0 	cbz	x0, 4e14 <fwp_poll_events+0x1c4>
    4dc0:	f9006105 	str	x5, [x8, #192]
    4dc4:	f9008005 	str	x5, [x0, #256]
    4dc8:	b5fffc66 	cbnz	x6, 4d54 <fwp_poll_events+0x104>
    4dcc:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4dd0:	f947f400 	ldr	x0, [x0, #4072]
    4dd4:	f9400fe2 	ldr	x2, [sp, #24]
    4dd8:	f9400001 	ldr	x1, [x0]
    4ddc:	eb010042 	subs	x2, x2, x1
    4de0:	d2800001 	mov	x1, #0x0                   	// #0
    4de4:	540002e1 	b.ne	4e40 <fwp_poll_events+0x1f0>  // b.any
    4de8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4dec:	f9401bf3 	ldr	x19, [sp, #48]
    4df0:	910103ff 	add	sp, sp, #0x40
    4df4:	d65f03c0 	ret
    4df8:	394144a0 	ldrb	w0, [x5, #81]
    4dfc:	3707fd40 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e00:	394140a0 	ldrb	w0, [x5, #80]
    4e04:	3707fd00 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e08:	aa0503e0 	mov	x0, x5
    4e0c:	97fffa39 	bl	36f0 <fwp_cancel_tree.part.0>
    4e10:	17ffffe5 	b	4da4 <fwp_poll_events+0x154>
    4e14:	f9006105 	str	x5, [x8, #192]
    4e18:	f9006505 	str	x5, [x8, #200]
    4e1c:	17ffffeb 	b	4dc8 <fwp_poll_events+0x178>
    4e20:	91014261 	add	x1, x19, #0x50
    4e24:	f9009426 	str	x6, [x1, #296]
    4e28:	17ffffd5 	b	4d7c <fwp_poll_events+0x12c>
    4e2c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4e30:	d2989362 	mov	x2, #0xc49b                	// #50331
    4e34:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4e38:	f2a00402 	movk	x2, #0x20, lsl #16
    4e3c:	17ffffba 	b	4d24 <fwp_poll_events+0xd4>
    4e40:	97fff698 	bl	28a0 <__stack_chk_fail@plt>
    4e44:	97fff88c 	bl	3074 <fwp_flush>
    4e48:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4e4c:	f947e863 	ldr	x3, [x3, #4048]
    4e50:	d2800562 	mov	x2, #0x2b                  	// #43
    4e54:	d2800021 	mov	x1, #0x1                   	// #1
    4e58:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    4e5c:	913f0000 	add	x0, x0, #0xfc0
    4e60:	f9400063 	ldr	x3, [x3]
    4e64:	97fff6cf 	bl	29a0 <fwrite@plt>
    4e68:	52800ca0 	mov	w0, #0x65                  	// #101
    4e6c:	97fff639 	bl	2750 <exit@plt>

0000000000004e70 <fwp_heap_alloc_big>:
    4e70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	a90153f3 	stp	x19, x20, [sp, #16]
    4e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e80:	a90363f7 	stp	x23, x24, [sp, #48]
    4e84:	aa0003f7 	mov	x23, x0
    4e88:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e8c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e90:	eb0002ff 	cmp	x23, x0
    4e94:	540008a8 	b.hi	4fa8 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e9c:	8b0002f4 	add	x20, x23, x0
    4ea0:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbc0>
    4ea4:	91188359 	add	x25, x26, #0x620
    4ea8:	d350fe94 	lsr	x20, x20, #16
    4eac:	2a0103f5 	mov	w21, w1
    4eb0:	aa1403e0 	mov	x0, x20
    4eb4:	97fff8bf 	bl	31b0 <fwp_heap_chunks>
    4eb8:	f949ff22 	ldr	x2, [x25, #5112]
    4ebc:	8b000813 	add	x19, x0, x0, lsl #2
    4ec0:	aa0003f8 	mov	x24, x0
    4ec4:	52800043 	mov	w3, #0x2                   	// #2
    4ec8:	d37df273 	lsl	x19, x19, #3
    4ecc:	d2800021 	mov	x1, #0x1                   	// #1
    4ed0:	8b130040 	add	x0, x2, x19
    4ed4:	38336843 	strb	w3, [x2, x19]
    4ed8:	39000415 	strb	w21, [x0, #1]
    4edc:	b9000c14 	str	w20, [x0, #12]
    4ee0:	f9000817 	str	x23, [x0, #16]
    4ee4:	97fffd57 	bl	4440 <fwp_rc_prepare_chunk>
    4ee8:	f100069f 	cmp	x20, #0x1
    4eec:	54000289 	b.ls	4f3c <fwp_heap_alloc_big+0xcc>  // b.plast
    4ef0:	8b180294 	add	x20, x20, x24
    4ef4:	9100a273 	add	x19, x19, #0x28
    4ef8:	a90573fb 	stp	x27, x28, [sp, #80]
    4efc:	5280007b 	mov	w27, #0x3                   	// #3
    4f00:	8b140a94 	add	x20, x20, x20, lsl #2
    4f04:	2a1803fc 	mov	w28, w24
    4f08:	9adb2296 	lsl	x22, x20, x27
    4f0c:	d503201f 	nop
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffd48 	bl	4440 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0xa0>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	91188353 	add	x19, x26, #0x620
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x108>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118835a 	add	x26, x26, #0x620
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4fc0:	91188262 	add	x2, x19, #0x620
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	91188262 	add	x2, x19, #0x620
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	91188260 	add	x0, x19, #0x620
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	91188273 	add	x19, x19, #0x620
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffb37 	bl	3d70 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff6f 	b	4e70 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	91188260 	add	x0, x19, #0x620
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffd19 	bl	4560 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	540008a1 	b.ne	524c <fwp_heap_alloc+0x13c>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    5140:	911882f3 	add	x19, x23, #0x620
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	54000722 	b.cs	5298 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	911882e0 	add	x0, x23, #0x620
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	911882e1 	add	x1, x23, #0x620
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	5400030c 	b.gt	5260 <fwp_heap_alloc+0x150>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000249 	b.ls	527c <fwp_heap_alloc+0x16c>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	910142c1 	add	x1, x22, #0x50
    5244:	b9413038 	ldr	w24, [x1, #304]
    5248:	17ffffe6 	b	51e0 <fwp_heap_alloc+0xd0>
    524c:	a9538c44 	ldp	x4, x3, [x2, #312]
    5250:	91000484 	add	x4, x4, #0x1
    5254:	8b000063 	add	x3, x3, x0
    5258:	a9138c44 	stp	x4, x3, [x2, #312]
    525c:	17ffffb8 	b	513c <fwp_heap_alloc+0x2c>
    5260:	a94153f3 	ldp	x19, x20, [sp, #16]
    5264:	fd00a800 	str	d0, [x0, #336]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	aa0403e0 	mov	x0, x4
    5270:	a94363f7 	ldp	x23, x24, [sp, #48]
    5274:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5278:	d65f03c0 	ret
    527c:	7100043f 	cmp	w1, #0x1
    5280:	8b140085 	add	x5, x4, x20
    5284:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5288:	52800001 	mov	w1, #0x0                   	// #0
    528c:	aa0403e0 	mov	x0, x4
    5290:	f9000465 	str	x5, [x3, #8]
    5294:	17ffffc4 	b	51a4 <fwp_heap_alloc+0x94>
    5298:	97fff7b6 	bl	3170 <fwp_heap_oom>
    529c:	d503201f 	nop

00000000000052a0 <fwp_data.part.0.constprop.0>:
    52a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52a4:	910003fd 	mov	x29, sp
    52a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    52ac:	f00000d6 	adrp	x22, 20000 <__data_start>
    52b0:	910142c2 	add	x2, x22, #0x50
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	b9413059 	ldr	w25, [x2, #304]
    52bc:	a90153f3 	stp	x19, x20, [sp, #16]
    52c0:	aa0103f4 	mov	x20, x1
    52c4:	a90363f7 	stp	x23, x24, [sp, #48]
    52c8:	2a0003f7 	mov	w23, w0
    52cc:	340000b9 	cbz	w25, 52e0 <fwp_data.part.0.constprop.0+0x40>
    52d0:	a9538041 	ldp	x1, x0, [x2, #312]
    52d4:	91000421 	add	x1, x1, #0x1
    52d8:	91006000 	add	x0, x0, #0x18
    52dc:	a9138041 	stp	x1, x0, [x2, #312]
    52e0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    52e4:	911882a3 	add	x3, x21, #0x620
    52e8:	b953a460 	ldr	w0, [x3, #5028]
    52ec:	34000840 	cbz	w0, 53f4 <fwp_data.part.0.constprop.0+0x154>
    52f0:	397e8862 	ldrb	w2, [x3, #4002]
    52f4:	910f0040 	add	x0, x2, #0x3c0
    52f8:	8b020442 	add	x2, x2, x2, lsl #1
    52fc:	d37df042 	lsl	x2, x2, #3
    5300:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5304:	2a1a03f8 	mov	w24, w26
    5308:	f8626873 	ldr	x19, [x3, x2]
    530c:	b4000613 	cbz	x19, 53cc <fwp_data.part.0.constprop.0+0x12c>
    5310:	f9400260 	ldr	x0, [x19]
    5314:	aa2003e0 	mvn	x0, x0
    5318:	f8226860 	str	x0, [x3, x2]
    531c:	f100631f 	cmp	x24, #0x18
    5320:	540000e9 	b.ls	533c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5324:	d1006702 	sub	x2, x24, #0x19
    5328:	91006260 	add	x0, x19, #0x18
    532c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5330:	52800001 	mov	w1, #0x0                   	// #0
    5334:	91002042 	add	x2, x2, #0x8
    5338:	97fff54e 	bl	2870 <memset@plt>
    533c:	911882a0 	add	x0, x21, #0x620
    5340:	f94a1001 	ldr	x1, [x0, #5152]
    5344:	ab180021 	adds	x1, x1, x24
    5348:	54000682 	b.cs	5418 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    534c:	f94a1402 	ldr	x2, [x0, #5160]
    5350:	f90a1001 	str	x1, [x0, #5152]
    5354:	eb02003f 	cmp	x1, x2
    5358:	54000049 	b.ls	5360 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    535c:	f90a1401 	str	x1, [x0, #5160]
    5360:	911882a0 	add	x0, x21, #0x620
    5364:	1e630341 	ucvtf	d1, w26
    5368:	fd4a1c00 	ldr	d0, [x0, #5176]
    536c:	1e612800 	fadd	d0, d0, d1
    5370:	fd0a1c00 	str	d0, [x0, #5176]
    5374:	34000139 	cbz	w25, 5398 <fwp_data.part.0.constprop.0+0xf8>
    5378:	911882b5 	add	x21, x21, #0x620
    537c:	910142d6 	add	x22, x22, #0x50
    5380:	fd4a12a0 	ldr	d0, [x21, #5152]
    5384:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5388:	7e61d800 	ucvtf	d0, d0
    538c:	1e623800 	fsub	d0, d0, d2
    5390:	1e612010 	fcmpe	d0, d1
    5394:	540003ec 	b.gt	5410 <fwp_data.part.0.constprop.0+0x170>
    5398:	52800040 	mov	w0, #0x2                   	// #2
    539c:	29000277 	stp	w23, w0, [x19]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	f9400281 	ldr	x1, [x20]
    53a8:	f9000661 	str	x1, [x19, #8]
    53ac:	f9400681 	ldr	x1, [x20, #8]
    53b0:	f9000a61 	str	x1, [x19, #16]
    53b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    53c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53c8:	d65f03c0 	ret
    53cc:	8b020063 	add	x3, x3, x2
    53d0:	f9400473 	ldr	x19, [x3, #8]
    53d4:	b4000113 	cbz	x19, 53f4 <fwp_data.part.0.constprop.0+0x154>
    53d8:	f9400860 	ldr	x0, [x3, #16]
    53dc:	cb130000 	sub	x0, x0, x19
    53e0:	eb00031f 	cmp	x24, x0
    53e4:	54000088 	b.hi	53f4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53e8:	8b180260 	add	x0, x19, x24
    53ec:	f9000460 	str	x0, [x3, #8]
    53f0:	17ffffcb 	b	531c <fwp_data.part.0.constprop.0+0x7c>
    53f4:	52800001 	mov	w1, #0x0                   	// #0
    53f8:	d2800300 	mov	x0, #0x18                  	// #24
    53fc:	97ffff45 	bl	5110 <fwp_heap_alloc>
    5400:	aa0003f3 	mov	x19, x0
    5404:	910142c1 	add	x1, x22, #0x50
    5408:	b9413039 	ldr	w25, [x1, #304]
    540c:	17ffffda 	b	5374 <fwp_data.part.0.constprop.0+0xd4>
    5410:	fd00aac0 	str	d0, [x22, #336]
    5414:	17ffffe1 	b	5398 <fwp_data.part.0.constprop.0+0xf8>
    5418:	97fff756 	bl	3170 <fwp_heap_oom>
    541c:	d503201f 	nop

0000000000005420 <fwp_tape_reserve>:
    5420:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5424:	910003fd 	mov	x29, sp
    5428:	a90153f3 	stp	x19, x20, [sp, #16]
    542c:	aa0003f3 	mov	x19, x0
    5430:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5434:	eb00003f 	cmp	x1, x0
    5438:	54000888 	b.hi	5548 <fwp_tape_reserve+0x128>  // b.pmore
    543c:	f9400e74 	ldr	x20, [x19, #24]
    5440:	eb01029f 	cmp	x20, x1
    5444:	5400078a 	b.ge	5534 <fwp_tape_reserve+0x114>  // b.tcont
    5448:	f100029f 	cmp	x20, #0x0
    544c:	d2800802 	mov	x2, #0x40                  	// #64
    5450:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5454:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    5458:	a9025bf5 	stp	x21, x22, [sp, #32]
    545c:	a90363f7 	stp	x23, x24, [sp, #48]
    5460:	eb01029f 	cmp	x20, x1
    5464:	5400008a 	b.ge	5474 <fwp_tape_reserve+0x54>  // b.tcont
    5468:	eb00029f 	cmp	x20, x0
    546c:	540006ad 	b.le	5540 <fwp_tape_reserve+0x120>
    5470:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5474:	a940d663 	ldp	x3, x21, [x19, #8]
    5478:	d37df297 	lsl	x23, x20, #3
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	aa1703e1 	mov	x1, x23
    5484:	f9403276 	ldr	x22, [x19, #96]
    5488:	52800022 	mov	w2, #0x1                   	// #1
    548c:	cb0302b5 	sub	x21, x21, x3
    5490:	97fffb0d 	bl	40c4 <ad_raw_realloc>
    5494:	b4000aa0 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    5498:	f9400e61 	ldr	x1, [x19, #24]
    549c:	8b010801 	add	x1, x0, x1, lsl #2
    54a0:	a9020660 	stp	x0, x1, [x19, #32]
    54a4:	b4000856 	cbz	x22, 55ac <fwp_tape_reserve+0x18c>
    54a8:	f94032d7 	ldr	x23, [x22, #96]
    54ac:	eb17029f 	cmp	x20, x23
    54b0:	5400034d 	b.le	5518 <fwp_tape_reserve+0xf8>
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	d37cee9a 	lsl	x26, x20, #4
    54bc:	aa1a03e0 	mov	x0, x26
    54c0:	f94022d9 	ldr	x25, [x22, #64]
    54c4:	52800041 	mov	w1, #0x2                   	// #2
    54c8:	97ffff12 	bl	5110 <fwp_heap_alloc>
    54cc:	aa0003f8 	mov	x24, x0
    54d0:	b4000119 	cbz	x25, 54f0 <fwp_tape_reserve+0xd0>
    54d4:	d37ceef7 	lsl	x23, x23, #4
    54d8:	aa1903e1 	mov	x1, x25
    54dc:	eb1a02ff 	cmp	x23, x26
    54e0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    54e4:	97fff483 	bl	26f0 <memcpy@plt>
    54e8:	aa1903e0 	mov	x0, x25
    54ec:	97fffc4d 	bl	4620 <fwp_mem_free>
    54f0:	f94032c0 	ldr	x0, [x22, #96]
    54f4:	52800001 	mov	w1, #0x0                   	// #0
    54f8:	cb000282 	sub	x2, x20, x0
    54fc:	8b001300 	add	x0, x24, x0, lsl #4
    5500:	d37cec42 	lsl	x2, x2, #4
    5504:	97fff4db 	bl	2870 <memset@plt>
    5508:	f9401260 	ldr	x0, [x19, #32]
    550c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5510:	f90022d8 	str	x24, [x22, #64]
    5514:	f90032d4 	str	x20, [x22, #96]
    5518:	d37ef696 	lsl	x22, x20, #2
    551c:	b5000315 	cbnz	x21, 557c <fwp_tape_reserve+0x15c>
    5520:	a94363f7 	ldp	x23, x24, [sp, #48]
    5524:	8b160000 	add	x0, x0, x22
    5528:	a9425bf5 	ldp	x21, x22, [sp, #32]
    552c:	f9000e74 	str	x20, [x19, #24]
    5530:	f9001660 	str	x0, [x19, #40]
    5534:	a94153f3 	ldp	x19, x20, [sp, #16]
    5538:	a8c57bfd 	ldp	x29, x30, [sp], #80
    553c:	d65f03c0 	ret
    5540:	d37ffa94 	lsl	x20, x20, #1
    5544:	17ffffc7 	b	5460 <fwp_tape_reserve+0x40>
    5548:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    554c:	91006000 	add	x0, x0, #0x18
    5550:	a9025bf5 	stp	x21, x22, [sp, #32]
    5554:	a90363f7 	stp	x23, x24, [sp, #48]
    5558:	a9046bf9 	stp	x25, x26, [sp, #64]
    555c:	97fffb76 	bl	4334 <fwp_trap>
    5560:	aa0303e0 	mov	x0, x3
    5564:	d37df2a2 	lsl	x2, x21, #3
    5568:	97fff46a 	bl	2710 <memmove@plt>
    556c:	f9401a61 	ldr	x1, [x19, #48]
    5570:	f9401260 	ldr	x0, [x19, #32]
    5574:	8b170021 	add	x1, x1, x23
    5578:	f9001e61 	str	x1, [x19, #56]
    557c:	f9401661 	ldr	x1, [x19, #40]
    5580:	d37ef696 	lsl	x22, x20, #2
    5584:	d37ef6a2 	lsl	x2, x21, #2
    5588:	8b160000 	add	x0, x0, x22
    558c:	97fff461 	bl	2710 <memmove@plt>
    5590:	f9401260 	ldr	x0, [x19, #32]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	8b160000 	add	x0, x0, x22
    559c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55a0:	f9000e74 	str	x20, [x19, #24]
    55a4:	f9001660 	str	x0, [x19, #40]
    55a8:	17ffffe3 	b	5534 <fwp_tape_reserve+0x114>
    55ac:	f9401a60 	ldr	x0, [x19, #48]
    55b0:	d37cee81 	lsl	x1, x20, #4
    55b4:	52800042 	mov	w2, #0x2                   	// #2
    55b8:	97fffac3 	bl	40c4 <ad_raw_realloc>
    55bc:	b4000160 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    55c0:	f9400e62 	ldr	x2, [x19, #24]
    55c4:	f9001a60 	str	x0, [x19, #48]
    55c8:	8b170003 	add	x3, x0, x23
    55cc:	8b020c01 	add	x1, x0, x2, lsl #3
    55d0:	f9001e61 	str	x1, [x19, #56]
    55d4:	b5fffc75 	cbnz	x21, 5560 <fwp_tape_reserve+0x140>
    55d8:	f9401260 	ldr	x0, [x19, #32]
    55dc:	d37ef696 	lsl	x22, x20, #2
    55e0:	f9001e63 	str	x3, [x19, #56]
    55e4:	17ffffcf 	b	5520 <fwp_tape_reserve+0x100>
    55e8:	aa1303e0 	mov	x0, x19
    55ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    55f0:	97fff689 	bl	3014 <fwp_tape_unlink_scope>
    55f4:	f9401260 	ldr	x0, [x19, #32]
    55f8:	b4000040 	cbz	x0, 5600 <fwp_tape_reserve+0x1e0>
    55fc:	97fffa7d 	bl	3ff0 <ad_raw_free.part.0>
    5600:	f9401a60 	ldr	x0, [x19, #48]
    5604:	b4000040 	cbz	x0, 560c <fwp_tape_reserve+0x1ec>
    5608:	97fffa7a 	bl	3ff0 <ad_raw_free.part.0>
    560c:	f9402260 	ldr	x0, [x19, #64]
    5610:	b4000040 	cbz	x0, 5618 <fwp_tape_reserve+0x1f8>
    5614:	97fffa77 	bl	3ff0 <ad_raw_free.part.0>
    5618:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    561c:	f947e821 	ldr	x1, [x1, #4048]
    5620:	f9000e7f 	str	xzr, [x19, #24]
    5624:	4f000400 	movi	v0.4s, #0x0
    5628:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    562c:	d2800262 	mov	x2, #0x13                  	// #19
    5630:	f9400023 	ldr	x3, [x1]
    5634:	b900067f 	str	wzr, [x19, #4]
    5638:	d2800021 	mov	x1, #0x1                   	// #1
    563c:	90000020 	adrp	x0, 9000 <fwp_main_thread+0x820>
    5640:	912c6000 	add	x0, x0, #0xb18
    5644:	3c808260 	stur	q0, [x19, #8]
    5648:	ad010260 	stp	q0, q0, [x19, #32]
    564c:	97fff4d5 	bl	29a0 <fwrite@plt>
    5650:	d2800000 	mov	x0, #0x0                   	// #0
    5654:	97fff4df 	bl	29d0 <fflush@plt>
    5658:	52800cc0 	mov	w0, #0x66                  	// #102
    565c:	97fff4ed 	bl	2a10 <_Exit@plt>

0000000000005660 <f141.constprop.0>:
    5660:	f100001f 	cmp	x0, #0x0
    5664:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5668:	5400094b 	b.lt	5790 <f141.constprop.0+0x130>  // b.tstop
    566c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5670:	aa0003e2 	mov	x2, x0
    5674:	910003fd 	mov	x29, sp
    5678:	a90153f3 	stp	x19, x20, [sp, #16]
    567c:	aa0003f4 	mov	x20, x0
    5680:	aa010000 	orr	x0, x0, x1
    5684:	a9025bf5 	stp	x21, x22, [sp, #32]
    5688:	aa0103f6 	mov	x22, x1
    568c:	f9001bf7 	str	x23, [sp, #48]
    5690:	fd001fe8 	str	d8, [sp, #56]
    5694:	b7f80180 	tbnz	x0, #63, 56c4 <f141.constprop.0+0x64>
    5698:	9360fc20 	asr	x0, x1, #32
    569c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56a0:	eb82801f 	cmp	x0, x2, asr #32
    56a4:	540007a1 	b.ne	5798 <f141.constprop.0+0x138>  // b.any
    56a8:	97fffd26 	bl	4b40 <fwp_tape_of>
    56ac:	aa0003f3 	mov	x19, x0
    56b0:	f9403000 	ldr	x0, [x0, #96]
    56b4:	b40001e0 	cbz	x0, 56f0 <f141.constprop.0+0x90>
    56b8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    56bc:	91020000 	add	x0, x0, #0x80
    56c0:	97fffb1d 	bl	4334 <fwp_trap>
    56c4:	9360fc40 	asr	x0, x2, #32
    56c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56cc:	b6fffee2 	tbz	x2, #63, 56a8 <f141.constprop.0+0x48>
    56d0:	2f00e408 	movi	d8, #0x0
    56d4:	9360fc20 	asr	x0, x1, #32
    56d8:	aa0103f4 	mov	x20, x1
    56dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    56e0:	97fffd18 	bl	4b40 <fwp_tape_of>
    56e4:	aa0003f3 	mov	x19, x0
    56e8:	f9403000 	ldr	x0, [x0, #96]
    56ec:	b5fffe60 	cbnz	x0, 56b8 <f141.constprop.0+0x58>
    56f0:	f9400a77 	ldr	x23, [x19, #16]
    56f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56f8:	eb0002ff 	cmp	x23, x0
    56fc:	5400044c 	b.gt	5784 <f141.constprop.0+0x124>
    5700:	eb3442ff 	cmp	x23, w20, uxtw
    5704:	5400008d 	b.le	5714 <f141.constprop.0+0xb4>
    5708:	b7f800d6 	tbnz	x22, #63, 5720 <f141.constprop.0+0xc0>
    570c:	eb3642ff 	cmp	x23, w22, uxtw
    5710:	5400008c 	b.gt	5720 <f141.constprop.0+0xc0>
    5714:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5718:	9102c000 	add	x0, x0, #0xb0
    571c:	97fffb06 	bl	4334 <fwp_trap>
    5720:	f9400675 	ldr	x21, [x19, #8]
    5724:	aa1303e0 	mov	x0, x19
    5728:	cb1502f5 	sub	x21, x23, x21
    572c:	910006a1 	add	x1, x21, #0x1
    5730:	97ffff3c 	bl	5420 <fwp_tape_reserve>
    5734:	a9420262 	ldp	x2, x0, [x19, #32]
    5738:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    573c:	f9401a61 	ldr	x1, [x19, #48]
    5740:	b8357854 	str	w20, [x2, x21, lsl #2]
    5744:	f9401e62 	ldr	x2, [x19, #56]
    5748:	f10002df 	cmp	x22, #0x0
    574c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5750:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5754:	b8357816 	str	w22, [x0, x21, lsl #2]
    5758:	92607e80 	and	x0, x20, #0xffffffff00000000
    575c:	910006e1 	add	x1, x23, #0x1
    5760:	aa170000 	orr	x0, x0, x23
    5764:	fc357848 	str	d8, [x2, x21, lsl #3]
    5768:	a9425bf5 	ldp	x21, x22, [sp, #32]
    576c:	f9401bf7 	ldr	x23, [sp, #48]
    5770:	fd401fe8 	ldr	d8, [sp, #56]
    5774:	f9000a61 	str	x1, [x19, #16]
    5778:	a94153f3 	ldp	x19, x20, [sp, #16]
    577c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5780:	d65f03c0 	ret
    5784:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5788:	91006000 	add	x0, x0, #0x18
    578c:	97fffaea 	bl	4334 <fwp_trap>
    5790:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5794:	d65f03c0 	ret
    5798:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    579c:	9100e000 	add	x0, x0, #0x38
    57a0:	97fffae5 	bl	4334 <fwp_trap>

00000000000057a4 <w120>:
    57a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    57a8:	910003fd 	mov	x29, sp
    57ac:	a90153f3 	stp	x19, x20, [sp, #16]
    57b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    57b4:	aa0003f5 	mov	x21, x0
    57b8:	a90363f7 	stp	x23, x24, [sp, #48]
    57bc:	aa0103f7 	mov	x23, x1
    57c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    57c4:	f9002bfb 	str	x27, [sp, #80]
    57c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57cc:	1e604028 	fmov	d8, d1
    57d0:	1e600809 	fmul	d9, d0, d0
    57d4:	6d072fea 	stp	d10, d11, [sp, #112]
    57d8:	1e60400b 	fmov	d11, d0
    57dc:	b7f81c80 	tbnz	x0, #63, 5b6c <w120+0x3c8>
    57e0:	9360fc19 	asr	x25, x0, #32
    57e4:	aa1903e0 	mov	x0, x25
    57e8:	97fffcd6 	bl	4b40 <fwp_tape_of>
    57ec:	f9403001 	ldr	x1, [x0, #96]
    57f0:	aa0003f3 	mov	x19, x0
    57f4:	b4000081 	cbz	x1, 5804 <w120+0x60>
    57f8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    57fc:	91020000 	add	x0, x0, #0x80
    5800:	97fffacd 	bl	4334 <fwp_trap>
    5804:	f9400818 	ldr	x24, [x0, #16]
    5808:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    580c:	eb01031f 	cmp	x24, x1
    5810:	54001a8c 	b.gt	5b60 <w120+0x3bc>
    5814:	eb35431f 	cmp	x24, w21, uxtw
    5818:	540019ed 	b.le	5b54 <w120+0x3b0>
    581c:	f9400416 	ldr	x22, [x0, #8]
    5820:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5824:	aa180294 	orr	x20, x20, x24
    5828:	cb160316 	sub	x22, x24, x22
    582c:	910006c1 	add	x1, x22, #0x1
    5830:	97fffefc 	bl	5420 <fwp_tape_reserve>
    5834:	a9420a61 	ldp	x1, x2, [x19, #32]
    5838:	91000700 	add	x0, x24, #0x1
    583c:	f9401a63 	ldr	x3, [x19, #48]
    5840:	b8367835 	str	w21, [x1, x22, lsl #2]
    5844:	f9401e61 	ldr	x1, [x19, #56]
    5848:	1e693908 	fsub	d8, d8, d9
    584c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5850:	9360fe9a 	asr	x26, x20, #32
    5854:	b8367855 	str	w21, [x2, x22, lsl #2]
    5858:	fc36782b 	str	d11, [x1, x22, lsl #3]
    585c:	f9000a60 	str	x0, [x19, #16]
    5860:	b7f80077 	tbnz	x23, #63, 586c <w120+0xc8>
    5864:	eb97835f 	cmp	x26, x23, asr #32
    5868:	540019a1 	b.ne	5b9c <w120+0x3f8>  // b.any
    586c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5870:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5874:	eb19035f 	cmp	x26, x25
    5878:	540000c0 	b.eq	5890 <w120+0xec>  // b.none
    587c:	aa1a03e0 	mov	x0, x26
    5880:	97fffcb0 	bl	4b40 <fwp_tape_of>
    5884:	aa0003f3 	mov	x19, x0
    5888:	f9403000 	ldr	x0, [x0, #96]
    588c:	b5fffb60 	cbnz	x0, 57f8 <w120+0x54>
    5890:	f9400a79 	ldr	x25, [x19, #16]
    5894:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5898:	eb00033f 	cmp	x25, x0
    589c:	5400162c 	b.gt	5b60 <w120+0x3bc>
    58a0:	eb34433f 	cmp	x25, w20, uxtw
    58a4:	5400158d 	b.le	5b54 <w120+0x3b0>
    58a8:	b7f80077 	tbnz	x23, #63, 58b4 <w120+0x110>
    58ac:	eb37433f 	cmp	x25, w23, uxtw
    58b0:	5400152d 	b.le	5b54 <w120+0x3b0>
    58b4:	f9400676 	ldr	x22, [x19, #8]
    58b8:	aa1303e0 	mov	x0, x19
    58bc:	cb160336 	sub	x22, x25, x22
    58c0:	910006c1 	add	x1, x22, #0x1
    58c4:	97fffed7 	bl	5420 <fwp_tape_reserve>
    58c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    58cc:	f10002ff 	cmp	x23, #0x0
    58d0:	f9401a61 	ldr	x1, [x19, #48]
    58d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    58d8:	f9401e62 	ldr	x2, [x19, #56]
    58dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    58e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    58e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    58e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    58ec:	91000737 	add	x23, x25, #0x1
    58f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    58f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    58fc:	aa190294 	orr	x20, x20, x25
    5900:	f9000a77 	str	x23, [x19, #16]
    5904:	1e6b3929 	fsub	d9, d9, d11
    5908:	b7f81675 	tbnz	x21, #63, 5bd4 <w120+0x430>
    590c:	9360febb 	asr	x27, x21, #32
    5910:	eb1a037f 	cmp	x27, x26
    5914:	540000e0 	b.eq	5930 <w120+0x18c>  // b.none
    5918:	aa1b03e0 	mov	x0, x27
    591c:	97fffc89 	bl	4b40 <fwp_tape_of>
    5920:	aa0003f3 	mov	x19, x0
    5924:	f9403000 	ldr	x0, [x0, #96]
    5928:	b5fff680 	cbnz	x0, 57f8 <w120+0x54>
    592c:	f9400a77 	ldr	x23, [x19, #16]
    5930:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5934:	eb0002ff 	cmp	x23, x0
    5938:	5400114c 	b.gt	5b60 <w120+0x3bc>
    593c:	eb3542ff 	cmp	x23, w21, uxtw
    5940:	540010ad 	b.le	5b54 <w120+0x3b0>
    5944:	f9400676 	ldr	x22, [x19, #8]
    5948:	aa1303e0 	mov	x0, x19
    594c:	cb1602f6 	sub	x22, x23, x22
    5950:	910006c1 	add	x1, x22, #0x1
    5954:	97fffeb3 	bl	5420 <fwp_tape_reserve>
    5958:	a9420261 	ldp	x1, x0, [x19, #32]
    595c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5960:	f9401a63 	ldr	x3, [x19, #48]
    5964:	b8367835 	str	w21, [x1, x22, lsl #2]
    5968:	f9401e61 	ldr	x1, [x19, #56]
    596c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5970:	fc367860 	str	d0, [x3, x22, lsl #3]
    5974:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5978:	b8367802 	str	w2, [x0, x22, lsl #2]
    597c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5980:	910006e0 	add	x0, x23, #0x1
    5984:	aa1702b7 	orr	x23, x21, x23
    5988:	fc367820 	str	d0, [x1, x22, lsl #3]
    598c:	f9000a60 	str	x0, [x19, #16]
    5990:	9360fe99 	asr	x25, x20, #32
    5994:	1e68090a 	fmul	d10, d8, d8
    5998:	eb1b033f 	cmp	x25, x27
    599c:	540000c0 	b.eq	59b4 <w120+0x210>  // b.none
    59a0:	aa1903e0 	mov	x0, x25
    59a4:	97fffc67 	bl	4b40 <fwp_tape_of>
    59a8:	aa0003f3 	mov	x19, x0
    59ac:	f9403000 	ldr	x0, [x0, #96]
    59b0:	b5fff240 	cbnz	x0, 57f8 <w120+0x54>
    59b4:	f9400a75 	ldr	x21, [x19, #16]
    59b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59bc:	eb0002bf 	cmp	x21, x0
    59c0:	54000d0c 	b.gt	5b60 <w120+0x3bc>
    59c4:	eb3442bf 	cmp	x21, w20, uxtw
    59c8:	54000c6d 	b.le	5b54 <w120+0x3b0>
    59cc:	f9400678 	ldr	x24, [x19, #8]
    59d0:	aa1303e0 	mov	x0, x19
    59d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    59d8:	cb1802b8 	sub	x24, x21, x24
    59dc:	aa1502d6 	orr	x22, x22, x21
    59e0:	91000701 	add	x1, x24, #0x1
    59e4:	97fffe8f 	bl	5420 <fwp_tape_reserve>
    59e8:	a9420261 	ldp	x1, x0, [x19, #32]
    59ec:	f9401a62 	ldr	x2, [x19, #48]
    59f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    59f4:	f9401e61 	ldr	x1, [x19, #56]
    59f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    59fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5a00:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a04:	9e670000 	fmov	d0, x0
    5a08:	910006b4 	add	x20, x21, #0x1
    5a0c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5a10:	9360fed8 	asr	x24, x22, #32
    5a14:	f9000a74 	str	x20, [x19, #16]
    5a18:	1e60094a 	fmul	d10, d10, d0
    5a1c:	eb19031f 	cmp	x24, x25
    5a20:	540000e0 	b.eq	5a3c <w120+0x298>  // b.none
    5a24:	aa1803e0 	mov	x0, x24
    5a28:	97fffc46 	bl	4b40 <fwp_tape_of>
    5a2c:	aa0003f3 	mov	x19, x0
    5a30:	f9403000 	ldr	x0, [x0, #96]
    5a34:	b5ffee20 	cbnz	x0, 57f8 <w120+0x54>
    5a38:	f9400a74 	ldr	x20, [x19, #16]
    5a3c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a40:	eb00029f 	cmp	x20, x0
    5a44:	540008ec 	b.gt	5b60 <w120+0x3bc>
    5a48:	eb36429f 	cmp	x20, w22, uxtw
    5a4c:	5400084d 	b.le	5b54 <w120+0x3b0>
    5a50:	f9400675 	ldr	x21, [x19, #8]
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	cb150295 	sub	x21, x20, x21
    5a5c:	910006a1 	add	x1, x21, #0x1
    5a60:	97fffe70 	bl	5420 <fwp_tape_reserve>
    5a64:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a68:	9e670000 	fmov	d0, x0
    5a6c:	a9420261 	ldp	x1, x0, [x19, #32]
    5a70:	1e690928 	fmul	d8, d9, d9
    5a74:	f9401a62 	ldr	x2, [x19, #48]
    5a78:	b8357836 	str	w22, [x1, x21, lsl #2]
    5a7c:	f9401e61 	ldr	x1, [x19, #56]
    5a80:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5a84:	fc357840 	str	d0, [x2, x21, lsl #3]
    5a88:	12800002 	mov	w2, #0xffffffff            	// #-1
    5a8c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5a90:	91000680 	add	x0, x20, #0x1
    5a94:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5a98:	aa1402d6 	orr	x22, x22, x20
    5a9c:	f9000a60 	str	x0, [x19, #16]
    5aa0:	b10006ff 	cmn	x23, #0x1
    5aa4:	540009e0 	b.eq	5be0 <w120+0x43c>  // b.none
    5aa8:	9360fee0 	asr	x0, x23, #32
    5aac:	eb18001f 	cmp	x0, x24
    5ab0:	540000a0 	b.eq	5ac4 <w120+0x320>  // b.none
    5ab4:	97fffc23 	bl	4b40 <fwp_tape_of>
    5ab8:	aa0003f3 	mov	x19, x0
    5abc:	f9403000 	ldr	x0, [x0, #96]
    5ac0:	b5ffe9c0 	cbnz	x0, 57f8 <w120+0x54>
    5ac4:	f9400a74 	ldr	x20, [x19, #16]
    5ac8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5acc:	eb00029f 	cmp	x20, x0
    5ad0:	5400048c 	b.gt	5b60 <w120+0x3bc>
    5ad4:	eb37429f 	cmp	x20, w23, uxtw
    5ad8:	540003ed 	b.le	5b54 <w120+0x3b0>
    5adc:	f9400675 	ldr	x21, [x19, #8]
    5ae0:	aa1303e0 	mov	x0, x19
    5ae4:	cb150295 	sub	x21, x20, x21
    5ae8:	910006a1 	add	x1, x21, #0x1
    5aec:	97fffe4d 	bl	5420 <fwp_tape_reserve>
    5af0:	a9420a61 	ldp	x1, x2, [x19, #32]
    5af4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5af8:	f9401a63 	ldr	x3, [x19, #48]
    5afc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5b00:	f9401e61 	ldr	x1, [x19, #56]
    5b04:	aa140000 	orr	x0, x0, x20
    5b08:	fc357869 	str	d9, [x3, x21, lsl #3]
    5b0c:	91000694 	add	x20, x20, #0x1
    5b10:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b14:	fc357829 	str	d9, [x1, x21, lsl #3]
    5b18:	f9000a74 	str	x20, [x19, #16]
    5b1c:	1e6a2908 	fadd	d8, d8, d10
    5b20:	aa1603e1 	mov	x1, x22
    5b24:	97fffecf 	bl	5660 <f141.constprop.0>
    5b28:	aa0003e1 	mov	x1, x0
    5b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b30:	9e660100 	fmov	x0, d8
    5b34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b38:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b3c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5b40:	f9402bfb 	ldr	x27, [sp, #80]
    5b44:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5b48:	6d472fea 	ldp	d10, d11, [sp, #112]
    5b4c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5b50:	d65f03c0 	ret
    5b54:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5b58:	9102c000 	add	x0, x0, #0xb0
    5b5c:	97fff9f6 	bl	4334 <fwp_trap>
    5b60:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5b64:	91006000 	add	x0, x0, #0x18
    5b68:	97fff9f3 	bl	4334 <fwp_trap>
    5b6c:	1e693828 	fsub	d8, d1, d9
    5b70:	b6f801c1 	tbz	x1, #63, 5ba8 <w120+0x404>
    5b74:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5b78:	1e68090a 	fmul	d10, d8, d8
    5b7c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5b80:	9e670000 	fmov	d0, x0
    5b84:	1e6b3828 	fsub	d8, d1, d11
    5b88:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5b8c:	aa1603e0 	mov	x0, x22
    5b90:	1e60094a 	fmul	d10, d10, d0
    5b94:	1e680908 	fmul	d8, d8, d8
    5b98:	17ffffe1 	b	5b1c <w120+0x378>
    5b9c:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5ba0:	9100e000 	add	x0, x0, #0x38
    5ba4:	97fff9e4 	bl	4334 <fwp_trap>
    5ba8:	2f00e40a 	movi	d10, #0x0
    5bac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5bb0:	9360fc3a 	asr	x26, x1, #32
    5bb4:	aa0103f4 	mov	x20, x1
    5bb8:	aa1a03e0 	mov	x0, x26
    5bbc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5bc0:	97fffbe0 	bl	4b40 <fwp_tape_of>
    5bc4:	aa0003f3 	mov	x19, x0
    5bc8:	f9403000 	ldr	x0, [x0, #96]
    5bcc:	b5ffe160 	cbnz	x0, 57f8 <w120+0x54>
    5bd0:	17ffff30 	b	5890 <w120+0xec>
    5bd4:	aa1a03fb 	mov	x27, x26
    5bd8:	aa0003f7 	mov	x23, x0
    5bdc:	17ffff6d 	b	5990 <w120+0x1ec>
    5be0:	aa1703e0 	mov	x0, x23
    5be4:	17ffffce 	b	5b1c <w120+0x378>
    5be8:	d503201f 	nop
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_rc_share>:
    5bf0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5bf4:	91188042 	add	x2, x2, #0x620
    5bf8:	f949d843 	ldr	x3, [x2, #5040]
    5bfc:	f949ec41 	ldr	x1, [x2, #5080]
    5c00:	cb030000 	sub	x0, x0, x3
    5c04:	eb01401f 	cmp	x0, x1, lsl #16
    5c08:	540003a2 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c0c:	d350fc01 	lsr	x1, x0, #16
    5c10:	f949fc44 	ldr	x4, [x2, #5112]
    5c14:	8b010821 	add	x1, x1, x1, lsl #2
    5c18:	d37df021 	lsl	x1, x1, #3
    5c1c:	8b010083 	add	x3, x4, x1
    5c20:	f9401062 	ldr	x2, [x3, #32]
    5c24:	b40002c2 	cbz	x2, 5c7c <fwp_rc_share+0x8c>
    5c28:	38616881 	ldrb	w1, [x4, x1]
    5c2c:	7100083f 	cmp	w1, #0x2
    5c30:	54000220 	b.eq	5c74 <fwp_rc_share+0x84>  // b.none
    5c34:	7100043f 	cmp	w1, #0x1
    5c38:	54000221 	b.ne	5c7c <fwp_rc_share+0x8c>  // b.any
    5c3c:	29430464 	ldp	w4, w1, [x3, #24]
    5c40:	92403c00 	and	x0, x0, #0xffff
    5c44:	9b047c00 	mul	x0, x0, x4
    5c48:	d360fc00 	lsr	x0, x0, #32
    5c4c:	eb01001f 	cmp	x0, x1
    5c50:	54000162 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c54:	8b000042 	add	x2, x2, x0
    5c58:	39400040 	ldrb	w0, [x2]
    5c5c:	34000100 	cbz	w0, 5c7c <fwp_rc_share+0x8c>
    5c60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5c64:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    5c68:	91034000 	add	x0, x0, #0xd0
    5c6c:	910003fd 	mov	x29, sp
    5c70:	97fff9b1 	bl	4334 <fwp_trap>
    5c74:	72003c1f 	tst	w0, #0xffff
    5c78:	54ffff00 	b.eq	5c58 <fwp_rc_share+0x68>  // b.none
    5c7c:	d65f03c0 	ret

0000000000005c80 <fwp_rc_free_arr>:
    5c80:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5c84:	91188063 	add	x3, x3, #0x620
    5c88:	f949d861 	ldr	x1, [x3, #5040]
    5c8c:	f949ec62 	ldr	x2, [x3, #5080]
    5c90:	cb010001 	sub	x1, x0, x1
    5c94:	eb02403f 	cmp	x1, x2, lsl #16
    5c98:	54000342 	b.cs	5d00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c9c:	d350fc22 	lsr	x2, x1, #16
    5ca0:	f949fc65 	ldr	x5, [x3, #5112]
    5ca4:	8b020842 	add	x2, x2, x2, lsl #2
    5ca8:	d37df042 	lsl	x2, x2, #3
    5cac:	8b0200a4 	add	x4, x5, x2
    5cb0:	f9401083 	ldr	x3, [x4, #32]
    5cb4:	b4000263 	cbz	x3, 5d00 <fwp_rc_free_arr+0x80>
    5cb8:	386268a2 	ldrb	w2, [x5, x2]
    5cbc:	7100085f 	cmp	w2, #0x2
    5cc0:	540001c0 	b.eq	5cf8 <fwp_rc_free_arr+0x78>  // b.none
    5cc4:	7100045f 	cmp	w2, #0x1
    5cc8:	540001c1 	b.ne	5d00 <fwp_rc_free_arr+0x80>  // b.any
    5ccc:	29430885 	ldp	w5, w2, [x4, #24]
    5cd0:	92403c21 	and	x1, x1, #0xffff
    5cd4:	9b057c21 	mul	x1, x1, x5
    5cd8:	d360fc21 	lsr	x1, x1, #32
    5cdc:	eb02003f 	cmp	x1, x2
    5ce0:	54000102 	b.cs	5d00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5ce4:	8b010063 	add	x3, x3, x1
    5ce8:	39400061 	ldrb	w1, [x3]
    5cec:	7100043f 	cmp	w1, #0x1
    5cf0:	54000081 	b.ne	5d00 <fwp_rc_free_arr+0x80>  // b.any
    5cf4:	17fffa4b 	b	4620 <fwp_mem_free>
    5cf8:	72003c3f 	tst	w1, #0xffff
    5cfc:	54ffff60 	b.eq	5ce8 <fwp_rc_free_arr+0x68>  // b.none
    5d00:	d65f03c0 	ret

0000000000005d04 <fwp_rc_dup>:
    5d04:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5d08:	91188042 	add	x2, x2, #0x620
    5d0c:	f949d841 	ldr	x1, [x2, #5040]
    5d10:	f949ec43 	ldr	x3, [x2, #5080]
    5d14:	cb010001 	sub	x1, x0, x1
    5d18:	eb03403f 	cmp	x1, x3, lsl #16
    5d1c:	540003c2 	b.cs	5d94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d20:	d350fc20 	lsr	x0, x1, #16
    5d24:	f949fc44 	ldr	x4, [x2, #5112]
    5d28:	8b000800 	add	x0, x0, x0, lsl #2
    5d2c:	d37df002 	lsl	x2, x0, #3
    5d30:	8b020083 	add	x3, x4, x2
    5d34:	f9401060 	ldr	x0, [x3, #32]
    5d38:	b40002e0 	cbz	x0, 5d94 <fwp_rc_dup+0x90>
    5d3c:	38626882 	ldrb	w2, [x4, x2]
    5d40:	7100085f 	cmp	w2, #0x2
    5d44:	540002a0 	b.eq	5d98 <fwp_rc_dup+0x94>  // b.none
    5d48:	7100045f 	cmp	w2, #0x1
    5d4c:	54000241 	b.ne	5d94 <fwp_rc_dup+0x90>  // b.any
    5d50:	29430864 	ldp	w4, w2, [x3, #24]
    5d54:	92403c21 	and	x1, x1, #0xffff
    5d58:	9b047c21 	mul	x1, x1, x4
    5d5c:	d360fc21 	lsr	x1, x1, #32
    5d60:	eb02003f 	cmp	x1, x2
    5d64:	54000182 	b.cs	5d94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d68:	8b010000 	add	x0, x0, x1
    5d6c:	39400001 	ldrb	w1, [x0]
    5d70:	34000121 	cbz	w1, 5d94 <fwp_rc_dup+0x90>
    5d74:	f00000c2 	adrp	x2, 20000 <__data_start>
    5d78:	91014042 	add	x2, x2, #0x50
    5d7c:	b9413043 	ldr	w3, [x2, #304]
    5d80:	35000123 	cbnz	w3, 5da4 <fwp_rc_dup+0xa0>
    5d84:	7103f43f 	cmp	w1, #0xfd
    5d88:	54000168 	b.hi	5db4 <fwp_rc_dup+0xb0>  // b.pmore
    5d8c:	11000421 	add	w1, w1, #0x1
    5d90:	39000001 	strb	w1, [x0]
    5d94:	d65f03c0 	ret
    5d98:	72003c3f 	tst	w1, #0xffff
    5d9c:	54fffe80 	b.eq	5d6c <fwp_rc_dup+0x68>  // b.none
    5da0:	d65f03c0 	ret
    5da4:	f940ac43 	ldr	x3, [x2, #344]
    5da8:	91000463 	add	x3, x3, #0x1
    5dac:	f900ac43 	str	x3, [x2, #344]
    5db0:	17fffff5 	b	5d84 <fwp_rc_dup+0x80>
    5db4:	17fffa94 	b	4804 <fwp_rc_wide_dup>
    5db8:	d503201f 	nop
    5dbc:	d503201f 	nop

0000000000005dc0 <fwp_owned_entry173>:
    5dc0:	d10103ff 	sub	sp, sp, #0x40
    5dc4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5dc8:	f947f442 	ldr	x2, [x2, #4072]
    5dcc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5dd0:	910083fd 	add	x29, sp, #0x20
    5dd4:	a90353f3 	stp	x19, x20, [sp, #48]
    5dd8:	f9400043 	ldr	x3, [x2]
    5ddc:	f9000fe3 	str	x3, [sp, #24]
    5de0:	d2800003 	mov	x3, #0x0                   	// #0
    5de4:	a9400c01 	ldp	x1, x3, [x0]
    5de8:	f9400802 	ldr	x2, [x0, #16]
    5dec:	ab020022 	adds	x2, x1, x2
    5df0:	540006e6 	b.vs	5ecc <fwp_owned_entry173+0x10c>
    5df4:	910023e1 	add	x1, sp, #0x8
    5df8:	52800000 	mov	w0, #0x0                   	// #0
    5dfc:	a9008be3 	stp	x3, x2, [sp, #8]
    5e00:	97fffd28 	bl	52a0 <fwp_data.part.0.constprop.0>
    5e04:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5e08:	91188063 	add	x3, x3, #0x620
    5e0c:	aa0003f3 	mov	x19, x0
    5e10:	f949d861 	ldr	x1, [x3, #5040]
    5e14:	f949ec60 	ldr	x0, [x3, #5080]
    5e18:	cb010261 	sub	x1, x19, x1
    5e1c:	eb00403f 	cmp	x1, x0, lsl #16
    5e20:	54000322 	b.cs	5e84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5e24:	d350fc22 	lsr	x2, x1, #16
    5e28:	f949fc63 	ldr	x3, [x3, #5112]
    5e2c:	8b020842 	add	x2, x2, x2, lsl #2
    5e30:	d37df042 	lsl	x2, x2, #3
    5e34:	8b020060 	add	x0, x3, x2
    5e38:	f9401014 	ldr	x20, [x0, #32]
    5e3c:	b4000254 	cbz	x20, 5e84 <fwp_owned_entry173+0xc4>
    5e40:	38626862 	ldrb	w2, [x3, x2]
    5e44:	7100085f 	cmp	w2, #0x2
    5e48:	54000360 	b.eq	5eb4 <fwp_owned_entry173+0xf4>  // b.none
    5e4c:	7100045f 	cmp	w2, #0x1
    5e50:	540001a1 	b.ne	5e84 <fwp_owned_entry173+0xc4>  // b.any
    5e54:	29430002 	ldp	w2, w0, [x0, #24]
    5e58:	92403c21 	and	x1, x1, #0xffff
    5e5c:	9b027c21 	mul	x1, x1, x2
    5e60:	d360fc21 	lsr	x1, x1, #32
    5e64:	eb00003f 	cmp	x1, x0
    5e68:	540000e2 	b.cs	5e84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5e6c:	8b010294 	add	x20, x20, x1
    5e70:	39400280 	ldrb	w0, [x20]
    5e74:	7103fc1f 	cmp	w0, #0xff
    5e78:	54000240 	b.eq	5ec0 <fwp_owned_entry173+0x100>  // b.none
    5e7c:	52800020 	mov	w0, #0x1                   	// #1
    5e80:	39000280 	strb	w0, [x20]
    5e84:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5e88:	f947f400 	ldr	x0, [x0, #4072]
    5e8c:	f9400fe2 	ldr	x2, [sp, #24]
    5e90:	f9400001 	ldr	x1, [x0]
    5e94:	eb010042 	subs	x2, x2, x1
    5e98:	d2800001 	mov	x1, #0x0                   	// #0
    5e9c:	540001a1 	b.ne	5ed0 <fwp_owned_entry173+0x110>  // b.any
    5ea0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ea4:	aa1303e0 	mov	x0, x19
    5ea8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5eac:	910103ff 	add	sp, sp, #0x40
    5eb0:	d65f03c0 	ret
    5eb4:	72003c3f 	tst	w1, #0xffff
    5eb8:	54fffe61 	b.ne	5e84 <fwp_owned_entry173+0xc4>  // b.any
    5ebc:	17ffffed 	b	5e70 <fwp_owned_entry173+0xb0>
    5ec0:	aa1403e0 	mov	x0, x20
    5ec4:	97fff93c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5ec8:	17ffffed 	b	5e7c <fwp_owned_entry173+0xbc>
    5ecc:	97fff2ed 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ed0:	97fff274 	bl	28a0 <__stack_chk_fail@plt>

0000000000005ed4 <e173>:
    5ed4:	d10103ff 	sub	sp, sp, #0x40
    5ed8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5edc:	f947f442 	ldr	x2, [x2, #4072]
    5ee0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ee4:	910083fd 	add	x29, sp, #0x20
    5ee8:	a90353f3 	stp	x19, x20, [sp, #48]
    5eec:	f9400043 	ldr	x3, [x2]
    5ef0:	f9000fe3 	str	x3, [sp, #24]
    5ef4:	d2800003 	mov	x3, #0x0                   	// #0
    5ef8:	a9400c01 	ldp	x1, x3, [x0]
    5efc:	f9400802 	ldr	x2, [x0, #16]
    5f00:	ab020022 	adds	x2, x1, x2
    5f04:	54000726 	b.vs	5fe8 <e173+0x114>
    5f08:	910023e1 	add	x1, sp, #0x8
    5f0c:	52800000 	mov	w0, #0x0                   	// #0
    5f10:	a9008be3 	stp	x3, x2, [sp, #8]
    5f14:	97fffce3 	bl	52a0 <fwp_data.part.0.constprop.0>
    5f18:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5f1c:	91188063 	add	x3, x3, #0x620
    5f20:	aa0003f3 	mov	x19, x0
    5f24:	f949d861 	ldr	x1, [x3, #5040]
    5f28:	f949ec60 	ldr	x0, [x3, #5080]
    5f2c:	cb010261 	sub	x1, x19, x1
    5f30:	eb00403f 	cmp	x1, x0, lsl #16
    5f34:	54000322 	b.cs	5f98 <e173+0xc4>  // b.hs, b.nlast
    5f38:	d350fc22 	lsr	x2, x1, #16
    5f3c:	f949fc63 	ldr	x3, [x3, #5112]
    5f40:	8b020842 	add	x2, x2, x2, lsl #2
    5f44:	d37df042 	lsl	x2, x2, #3
    5f48:	8b020060 	add	x0, x3, x2
    5f4c:	f9401014 	ldr	x20, [x0, #32]
    5f50:	b4000254 	cbz	x20, 5f98 <e173+0xc4>
    5f54:	38626862 	ldrb	w2, [x3, x2]
    5f58:	7100085f 	cmp	w2, #0x2
    5f5c:	540003a0 	b.eq	5fd0 <e173+0xfc>  // b.none
    5f60:	7100045f 	cmp	w2, #0x1
    5f64:	540001a1 	b.ne	5f98 <e173+0xc4>  // b.any
    5f68:	29430002 	ldp	w2, w0, [x0, #24]
    5f6c:	92403c21 	and	x1, x1, #0xffff
    5f70:	9b027c21 	mul	x1, x1, x2
    5f74:	d360fc21 	lsr	x1, x1, #32
    5f78:	eb00003f 	cmp	x1, x0
    5f7c:	540000e2 	b.cs	5f98 <e173+0xc4>  // b.hs, b.nlast
    5f80:	8b010294 	add	x20, x20, x1
    5f84:	39400280 	ldrb	w0, [x20]
    5f88:	7103fc1f 	cmp	w0, #0xff
    5f8c:	54000280 	b.eq	5fdc <e173+0x108>  // b.none
    5f90:	52800020 	mov	w0, #0x1                   	// #1
    5f94:	39000280 	strb	w0, [x20]
    5f98:	aa1303e0 	mov	x0, x19
    5f9c:	97ffff15 	bl	5bf0 <fwp_rc_share>
    5fa0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5fa4:	f947f400 	ldr	x0, [x0, #4072]
    5fa8:	f9400fe2 	ldr	x2, [sp, #24]
    5fac:	f9400001 	ldr	x1, [x0]
    5fb0:	eb010042 	subs	x2, x2, x1
    5fb4:	d2800001 	mov	x1, #0x0                   	// #0
    5fb8:	540001a1 	b.ne	5fec <e173+0x118>  // b.any
    5fbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5fc8:	910103ff 	add	sp, sp, #0x40
    5fcc:	d65f03c0 	ret
    5fd0:	72003c3f 	tst	w1, #0xffff
    5fd4:	54fffe21 	b.ne	5f98 <e173+0xc4>  // b.any
    5fd8:	17ffffeb 	b	5f84 <e173+0xb0>
    5fdc:	aa1403e0 	mov	x0, x20
    5fe0:	97fff8f5 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5fe4:	17ffffeb 	b	5f90 <e173+0xbc>
    5fe8:	97fff2a6 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5fec:	97fff22d 	bl	28a0 <__stack_chk_fail@plt>

0000000000005ff0 <fwp_drop1>:
    5ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ff4:	910003fd 	mov	x29, sp
    5ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ffc:	f90013f5 	str	x21, [sp, #32]
    6000:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    6004:	911882b4 	add	x20, x21, #0x620
    6008:	f949da81 	ldr	x1, [x20, #5040]
    600c:	f949ee82 	ldr	x2, [x20, #5080]
    6010:	cb010001 	sub	x1, x0, x1
    6014:	eb02403f 	cmp	x1, x2, lsl #16
    6018:	54000382 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    601c:	d350fc22 	lsr	x2, x1, #16
    6020:	f949fe84 	ldr	x4, [x20, #5112]
    6024:	8b020842 	add	x2, x2, x2, lsl #2
    6028:	d37df042 	lsl	x2, x2, #3
    602c:	8b020083 	add	x3, x4, x2
    6030:	f9401073 	ldr	x19, [x3, #32]
    6034:	b40002b3 	cbz	x19, 6088 <fwp_drop1+0x98>
    6038:	38626882 	ldrb	w2, [x4, x2]
    603c:	7100085f 	cmp	w2, #0x2
    6040:	540002c0 	b.eq	6098 <fwp_drop1+0xa8>  // b.none
    6044:	7100045f 	cmp	w2, #0x1
    6048:	54000201 	b.ne	6088 <fwp_drop1+0x98>  // b.any
    604c:	29430864 	ldp	w4, w2, [x3, #24]
    6050:	92403c21 	and	x1, x1, #0xffff
    6054:	9b047c21 	mul	x1, x1, x4
    6058:	d360fc21 	lsr	x1, x1, #32
    605c:	eb02003f 	cmp	x1, x2
    6060:	54000142 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    6064:	8b010273 	add	x19, x19, x1
    6068:	39400261 	ldrb	w1, [x19]
    606c:	340000e1 	cbz	w1, 6088 <fwp_drop1+0x98>
    6070:	7100043f 	cmp	w1, #0x1
    6074:	540001e0 	b.eq	60b0 <fwp_drop1+0xc0>  // b.none
    6078:	7103fc3f 	cmp	w1, #0xff
    607c:	540002e0 	b.eq	60d8 <fwp_drop1+0xe8>  // b.none
    6080:	51000421 	sub	w1, w1, #0x1
    6084:	39000261 	strb	w1, [x19]
    6088:	a94153f3 	ldp	x19, x20, [sp, #16]
    608c:	f94013f5 	ldr	x21, [sp, #32]
    6090:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6094:	d65f03c0 	ret
    6098:	72003c3f 	tst	w1, #0xffff
    609c:	54fffe60 	b.eq	6068 <fwp_drop1+0x78>  // b.none
    60a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    60a4:	f94013f5 	ldr	x21, [sp, #32]
    60a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60ac:	d65f03c0 	ret
    60b0:	f9400813 	ldr	x19, [x0, #16]
    60b4:	97fffef3 	bl	5c80 <fwp_rc_free_arr>
    60b8:	911882a0 	add	x0, x21, #0x620
    60bc:	f949d801 	ldr	x1, [x0, #5040]
    60c0:	f949ec00 	ldr	x0, [x0, #5080]
    60c4:	cb010261 	sub	x1, x19, x1
    60c8:	eb00403f 	cmp	x1, x0, lsl #16
    60cc:	54fffde2 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    60d0:	aa1303e0 	mov	x0, x19
    60d4:	17ffffd2 	b	601c <fwp_drop1+0x2c>
    60d8:	ca534660 	eor	x0, x19, x19, lsr #17
    60dc:	911882b5 	add	x21, x21, #0x620
    60e0:	ca402400 	eor	x0, x0, x0, lsr #9
    60e4:	92401c00 	and	x0, x0, #0xff
    60e8:	910a2402 	add	x2, x0, #0x289
    60ec:	8b000ea0 	add	x0, x21, x0, lsl #3
    60f0:	8b020ea2 	add	x2, x21, x2, lsl #3
    60f4:	f94a2400 	ldr	x0, [x0, #5192]
    60f8:	b50000a0 	cbnz	x0, 610c <fwp_drop1+0x11c>
    60fc:	14000013 	b	6148 <fwp_drop1+0x158>
    6100:	91004002 	add	x2, x0, #0x10
    6104:	f9400800 	ldr	x0, [x0, #16]
    6108:	b4000200 	cbz	x0, 6148 <fwp_drop1+0x158>
    610c:	f9400001 	ldr	x1, [x0]
    6110:	eb13003f 	cmp	x1, x19
    6114:	54ffff61 	b.ne	6100 <fwp_drop1+0x110>  // b.any
    6118:	f9400041 	ldr	x1, [x2]
    611c:	f9400420 	ldr	x0, [x1, #8]
    6120:	d1000400 	sub	x0, x0, #0x1
    6124:	f9000420 	str	x0, [x1, #8]
    6128:	f103f81f 	cmp	x0, #0xfe
    612c:	54fffae1 	b.ne	6088 <fwp_drop1+0x98>  // b.any
    6130:	39400260 	ldrb	w0, [x19]
    6134:	7103fc1f 	cmp	w0, #0xff
    6138:	540000e0 	b.eq	6154 <fwp_drop1+0x164>  // b.none
    613c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6140:	39000260 	strb	w0, [x19]
    6144:	17ffffd1 	b	6088 <fwp_drop1+0x98>
    6148:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    614c:	9139a000 	add	x0, x0, #0xe68
    6150:	97fff879 	bl	4334 <fwp_trap>
    6154:	aa1303e0 	mov	x0, x19
    6158:	97fff897 	bl	43b4 <fwp_rc_forget_slot.part.0>
    615c:	17fffff8 	b	613c <fwp_drop1+0x14c>

0000000000006160 <fwp_drop0>:
    6160:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6164:	910003fd 	mov	x29, sp
    6168:	a90153f3 	stp	x19, x20, [sp, #16]
    616c:	f90013f5 	str	x21, [sp, #32]
    6170:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    6174:	911882b4 	add	x20, x21, #0x620
    6178:	f949da81 	ldr	x1, [x20, #5040]
    617c:	f949ee82 	ldr	x2, [x20, #5080]
    6180:	cb010001 	sub	x1, x0, x1
    6184:	eb02403f 	cmp	x1, x2, lsl #16
    6188:	54000382 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    618c:	d350fc22 	lsr	x2, x1, #16
    6190:	f949fe84 	ldr	x4, [x20, #5112]
    6194:	8b020842 	add	x2, x2, x2, lsl #2
    6198:	d37df042 	lsl	x2, x2, #3
    619c:	8b020083 	add	x3, x4, x2
    61a0:	f9401073 	ldr	x19, [x3, #32]
    61a4:	b40002b3 	cbz	x19, 61f8 <fwp_drop0+0x98>
    61a8:	38626882 	ldrb	w2, [x4, x2]
    61ac:	7100085f 	cmp	w2, #0x2
    61b0:	540002c0 	b.eq	6208 <fwp_drop0+0xa8>  // b.none
    61b4:	7100045f 	cmp	w2, #0x1
    61b8:	54000201 	b.ne	61f8 <fwp_drop0+0x98>  // b.any
    61bc:	29430864 	ldp	w4, w2, [x3, #24]
    61c0:	92403c21 	and	x1, x1, #0xffff
    61c4:	9b047c21 	mul	x1, x1, x4
    61c8:	d360fc21 	lsr	x1, x1, #32
    61cc:	eb02003f 	cmp	x1, x2
    61d0:	54000142 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    61d4:	8b010273 	add	x19, x19, x1
    61d8:	39400261 	ldrb	w1, [x19]
    61dc:	340000e1 	cbz	w1, 61f8 <fwp_drop0+0x98>
    61e0:	7100043f 	cmp	w1, #0x1
    61e4:	540001e0 	b.eq	6220 <fwp_drop0+0xc0>  // b.none
    61e8:	7103fc3f 	cmp	w1, #0xff
    61ec:	540002e0 	b.eq	6248 <fwp_drop0+0xe8>  // b.none
    61f0:	51000421 	sub	w1, w1, #0x1
    61f4:	39000261 	strb	w1, [x19]
    61f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    61fc:	f94013f5 	ldr	x21, [sp, #32]
    6200:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6204:	d65f03c0 	ret
    6208:	72003c3f 	tst	w1, #0xffff
    620c:	54fffe60 	b.eq	61d8 <fwp_drop0+0x78>  // b.none
    6210:	a94153f3 	ldp	x19, x20, [sp, #16]
    6214:	f94013f5 	ldr	x21, [sp, #32]
    6218:	a8c37bfd 	ldp	x29, x30, [sp], #48
    621c:	d65f03c0 	ret
    6220:	f9400813 	ldr	x19, [x0, #16]
    6224:	97fffe97 	bl	5c80 <fwp_rc_free_arr>
    6228:	911882a0 	add	x0, x21, #0x620
    622c:	f949d801 	ldr	x1, [x0, #5040]
    6230:	f949ec00 	ldr	x0, [x0, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54fffde2 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6240:	aa1303e0 	mov	x0, x19
    6244:	17ffffd2 	b	618c <fwp_drop0+0x2c>
    6248:	ca534660 	eor	x0, x19, x19, lsr #17
    624c:	911882b5 	add	x21, x21, #0x620
    6250:	ca402400 	eor	x0, x0, x0, lsr #9
    6254:	92401c00 	and	x0, x0, #0xff
    6258:	910a2402 	add	x2, x0, #0x289
    625c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6260:	8b020ea2 	add	x2, x21, x2, lsl #3
    6264:	f94a2400 	ldr	x0, [x0, #5192]
    6268:	b50000a0 	cbnz	x0, 627c <fwp_drop0+0x11c>
    626c:	14000013 	b	62b8 <fwp_drop0+0x158>
    6270:	91004002 	add	x2, x0, #0x10
    6274:	f9400800 	ldr	x0, [x0, #16]
    6278:	b4000200 	cbz	x0, 62b8 <fwp_drop0+0x158>
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb13003f 	cmp	x1, x19
    6284:	54ffff61 	b.ne	6270 <fwp_drop0+0x110>  // b.any
    6288:	f9400041 	ldr	x1, [x2]
    628c:	f9400420 	ldr	x0, [x1, #8]
    6290:	d1000400 	sub	x0, x0, #0x1
    6294:	f9000420 	str	x0, [x1, #8]
    6298:	f103f81f 	cmp	x0, #0xfe
    629c:	54fffae1 	b.ne	61f8 <fwp_drop0+0x98>  // b.any
    62a0:	39400260 	ldrb	w0, [x19]
    62a4:	7103fc1f 	cmp	w0, #0xff
    62a8:	540000e0 	b.eq	62c4 <fwp_drop0+0x164>  // b.none
    62ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62b0:	39000260 	strb	w0, [x19]
    62b4:	17ffffd1 	b	61f8 <fwp_drop0+0x98>
    62b8:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    62bc:	9139a000 	add	x0, x0, #0xe68
    62c0:	97fff81d 	bl	4334 <fwp_trap>
    62c4:	aa1303e0 	mov	x0, x19
    62c8:	97fff83b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    62cc:	17fffff8 	b	62ac <fwp_drop0+0x14c>

00000000000062d0 <fwp_closure_drop>:
    62d0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbc0>
    62d4:	911880a4 	add	x4, x5, #0x620
    62d8:	aa0003e1 	mov	x1, x0
    62dc:	f949d882 	ldr	x2, [x4, #5040]
    62e0:	f949ec80 	ldr	x0, [x4, #5080]
    62e4:	cb020022 	sub	x2, x1, x2
    62e8:	eb00405f 	cmp	x2, x0, lsl #16
    62ec:	54000662 	b.cs	63b8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    62f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62f4:	d350fc43 	lsr	x3, x2, #16
    62f8:	910003fd 	mov	x29, sp
    62fc:	8b030863 	add	x3, x3, x3, lsl #2
    6300:	f949fc84 	ldr	x4, [x4, #5112]
    6304:	d37df063 	lsl	x3, x3, #3
    6308:	f9000bf3 	str	x19, [sp, #16]
    630c:	8b030080 	add	x0, x4, x3
    6310:	f9401013 	ldr	x19, [x0, #32]
    6314:	b40002b3 	cbz	x19, 6368 <fwp_closure_drop+0x98>
    6318:	38636883 	ldrb	w3, [x4, x3]
    631c:	7100087f 	cmp	w3, #0x2
    6320:	54000420 	b.eq	63a4 <fwp_closure_drop+0xd4>  // b.none
    6324:	7100047f 	cmp	w3, #0x1
    6328:	54000201 	b.ne	6368 <fwp_closure_drop+0x98>  // b.any
    632c:	29430003 	ldp	w3, w0, [x0, #24]
    6330:	92403c42 	and	x2, x2, #0xffff
    6334:	9b037c42 	mul	x2, x2, x3
    6338:	d360fc42 	lsr	x2, x2, #32
    633c:	eb00005f 	cmp	x2, x0
    6340:	54000142 	b.cs	6368 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6344:	8b020273 	add	x19, x19, x2
    6348:	39400260 	ldrb	w0, [x19]
    634c:	340000e0 	cbz	w0, 6368 <fwp_closure_drop+0x98>
    6350:	7100041f 	cmp	w0, #0x1
    6354:	54000100 	b.eq	6374 <fwp_closure_drop+0xa4>  // b.none
    6358:	7103fc1f 	cmp	w0, #0xff
    635c:	54000300 	b.eq	63bc <fwp_closure_drop+0xec>  // b.none
    6360:	51000400 	sub	w0, w0, #0x1
    6364:	39000260 	strb	w0, [x19]
    6368:	f9400bf3 	ldr	x19, [sp, #16]
    636c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6370:	d65f03c0 	ret
    6374:	d53bd040 	mrs	x0, tpidr_el0
    6378:	91400000 	add	x0, x0, #0x0, lsl #12
    637c:	91004000 	add	x0, x0, #0x10
    6380:	f9400000 	ldr	x0, [x0]
    6384:	b4000080 	cbz	x0, 6394 <fwp_closure_drop+0xc4>
    6388:	f9400bf3 	ldr	x19, [sp, #16]
    638c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6390:	17fff964 	b	4920 <fwp_closure_drop_push>
    6394:	f9400bf3 	ldr	x19, [sp, #16]
    6398:	aa0103e0 	mov	x0, x1
    639c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a0:	17fff9a5 	b	4a34 <fwp_closure_drop.part.0>
    63a4:	72003c5f 	tst	w2, #0xffff
    63a8:	54fffd00 	b.eq	6348 <fwp_closure_drop+0x78>  // b.none
    63ac:	f9400bf3 	ldr	x19, [sp, #16]
    63b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63b4:	d65f03c0 	ret
    63b8:	d65f03c0 	ret
    63bc:	ca534660 	eor	x0, x19, x19, lsr #17
    63c0:	911880a5 	add	x5, x5, #0x620
    63c4:	ca402400 	eor	x0, x0, x0, lsr #9
    63c8:	92401c00 	and	x0, x0, #0xff
    63cc:	910a2402 	add	x2, x0, #0x289
    63d0:	8b000ca0 	add	x0, x5, x0, lsl #3
    63d4:	8b020ca2 	add	x2, x5, x2, lsl #3
    63d8:	f94a2400 	ldr	x0, [x0, #5192]
    63dc:	b50000a0 	cbnz	x0, 63f0 <fwp_closure_drop+0x120>
    63e0:	14000013 	b	642c <fwp_closure_drop+0x15c>
    63e4:	91004002 	add	x2, x0, #0x10
    63e8:	f9400800 	ldr	x0, [x0, #16]
    63ec:	b4000200 	cbz	x0, 642c <fwp_closure_drop+0x15c>
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	eb13003f 	cmp	x1, x19
    63f8:	54ffff61 	b.ne	63e4 <fwp_closure_drop+0x114>  // b.any
    63fc:	f9400041 	ldr	x1, [x2]
    6400:	f9400420 	ldr	x0, [x1, #8]
    6404:	d1000400 	sub	x0, x0, #0x1
    6408:	f9000420 	str	x0, [x1, #8]
    640c:	f103f81f 	cmp	x0, #0xfe
    6410:	54fffac1 	b.ne	6368 <fwp_closure_drop+0x98>  // b.any
    6414:	39400260 	ldrb	w0, [x19]
    6418:	7103fc1f 	cmp	w0, #0xff
    641c:	540000e0 	b.eq	6438 <fwp_closure_drop+0x168>  // b.none
    6420:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6424:	39000260 	strb	w0, [x19]
    6428:	17ffffd0 	b	6368 <fwp_closure_drop+0x98>
    642c:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    6430:	9139a000 	add	x0, x0, #0xe68
    6434:	97fff7c0 	bl	4334 <fwp_trap>
    6438:	aa1303e0 	mov	x0, x19
    643c:	97fff7de 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6440:	17fffff8 	b	6420 <fwp_closure_drop+0x150>

0000000000006444 <fwp_owned_tape_release>:
    6444:	b4000920 	cbz	x0, 6568 <fwp_owned_tape_release+0x124>
    6448:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    644c:	910003fd 	mov	x29, sp
    6450:	a90153f3 	stp	x19, x20, [sp, #16]
    6454:	aa0003f3 	mov	x19, x0
    6458:	f9400000 	ldr	x0, [x0]
    645c:	b4000060 	cbz	x0, 6468 <fwp_owned_tape_release+0x24>
    6460:	f9400661 	ldr	x1, [x19, #8]
    6464:	f9000401 	str	x1, [x0, #8]
    6468:	f9400661 	ldr	x1, [x19, #8]
    646c:	b4000041 	cbz	x1, 6474 <fwp_owned_tape_release+0x30>
    6470:	f9000020 	str	x0, [x1]
    6474:	f9400a60 	ldr	x0, [x19, #16]
    6478:	f9403401 	ldr	x1, [x0, #104]
    647c:	b40005a1 	cbz	x1, 6530 <fwp_owned_tape_release+0xec>
    6480:	a9450a60 	ldp	x0, x2, [x19, #80]
    6484:	eb00005f 	cmp	x2, x0
    6488:	540002cd 	b.le	64e0 <fwp_owned_tape_release+0x9c>
    648c:	d2800014 	mov	x20, #0x0                   	// #0
    6490:	f90013f5 	str	x21, [sp, #32]
    6494:	d2800015 	mov	x21, #0x0                   	// #0
    6498:	f9402260 	ldr	x0, [x19, #64]
    649c:	910006b5 	add	x21, x21, #0x1
    64a0:	f8746800 	ldr	x0, [x0, x20]
    64a4:	d63f0020 	blr	x1
    64a8:	f9402260 	ldr	x0, [x19, #64]
    64ac:	f9400a61 	ldr	x1, [x19, #16]
    64b0:	8b140000 	add	x0, x0, x20
    64b4:	91004294 	add	x20, x20, #0x10
    64b8:	f9400400 	ldr	x0, [x0, #8]
    64bc:	f9403421 	ldr	x1, [x1, #104]
    64c0:	d63f0020 	blr	x1
    64c4:	a9450261 	ldp	x1, x0, [x19, #80]
    64c8:	cb010000 	sub	x0, x0, x1
    64cc:	eb15001f 	cmp	x0, x21
    64d0:	f9400a60 	ldr	x0, [x19, #16]
    64d4:	f9403401 	ldr	x1, [x0, #104]
    64d8:	54fffe0c 	b.gt	6498 <fwp_owned_tape_release+0x54>
    64dc:	f94013f5 	ldr	x21, [sp, #32]
    64e0:	f9403663 	ldr	x3, [x19, #104]
    64e4:	f9401262 	ldr	x2, [x19, #32]
    64e8:	f100007f 	cmp	x3, #0x0
    64ec:	540001ed 	b.le	6528 <fwp_owned_tape_release+0xe4>
    64f0:	d2800014 	mov	x20, #0x0                   	// #0
    64f4:	d503201f 	nop
    64f8:	f9402660 	ldr	x0, [x19, #72]
    64fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6500:	eb02001f 	cmp	x0, x2
    6504:	540000c0 	b.eq	651c <fwp_owned_tape_release+0xd8>  // b.none
    6508:	d63f0020 	blr	x1
    650c:	f9400a60 	ldr	x0, [x19, #16]
    6510:	f9401262 	ldr	x2, [x19, #32]
    6514:	f9403663 	ldr	x3, [x19, #104]
    6518:	f9403401 	ldr	x1, [x0, #104]
    651c:	91000694 	add	x20, x20, #0x1
    6520:	eb14007f 	cmp	x3, x20
    6524:	54fffeac 	b.gt	64f8 <fwp_owned_tape_release+0xb4>
    6528:	aa0203e0 	mov	x0, x2
    652c:	d63f0020 	blr	x1
    6530:	f9401660 	ldr	x0, [x19, #40]
    6534:	97ffff67 	bl	62d0 <fwp_closure_drop>
    6538:	f9401a60 	ldr	x0, [x19, #48]
    653c:	97ffff65 	bl	62d0 <fwp_closure_drop>
    6540:	f9401e60 	ldr	x0, [x19, #56]
    6544:	97ffff63 	bl	62d0 <fwp_closure_drop>
    6548:	f9402260 	ldr	x0, [x19, #64]
    654c:	97fff835 	bl	4620 <fwp_mem_free>
    6550:	f9402660 	ldr	x0, [x19, #72]
    6554:	97fff833 	bl	4620 <fwp_mem_free>
    6558:	aa1303e0 	mov	x0, x19
    655c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6560:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6564:	17fff82f 	b	4620 <fwp_mem_free>
    6568:	d65f03c0 	ret
    656c:	d503201f 	nop

0000000000006570 <fwp_tape_finish>:
    6570:	d10203ff 	sub	sp, sp, #0x80
    6574:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6578:	f947f421 	ldr	x1, [x1, #4072]
    657c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6580:	910103fd 	add	x29, sp, #0x40
    6584:	a9065bf5 	stp	x21, x22, [sp, #96]
    6588:	a90763f7 	stp	x23, x24, [sp, #112]
    658c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6590:	910142f6 	add	x22, x23, #0x50
    6594:	f9400022 	ldr	x2, [x1]
    6598:	f9001fe2 	str	x2, [sp, #56]
    659c:	d2800002 	mov	x2, #0x0                   	// #0
    65a0:	910342c0 	add	x0, x22, #0xd0
    65a4:	97fff6b4 	bl	4074 <fwp_tape_buffers_dispose>
    65a8:	f90086df 	str	xzr, [x22, #264]
    65ac:	f94092c0 	ldr	x0, [x22, #288]
    65b0:	f100001f 	cmp	x0, #0x0
    65b4:	5400034d 	b.le	661c <fwp_tape_finish+0xac>
    65b8:	910003f8 	mov	x24, sp
    65bc:	d2800015 	mov	x21, #0x0                   	// #0
    65c0:	a90553f3 	stp	x19, x20, [sp, #80]
    65c4:	d2800014 	mov	x20, #0x0                   	// #0
    65c8:	91000694 	add	x20, x20, #0x1
    65cc:	f94046d3 	ldr	x19, [x22, #136]
    65d0:	8b150273 	add	x19, x19, x21
    65d4:	9101a2b5 	add	x21, x21, #0x68
    65d8:	aa1303e0 	mov	x0, x19
    65dc:	97fff28e 	bl	3014 <fwp_tape_unlink_scope>
    65e0:	aa1803e0 	mov	x0, x24
    65e4:	a9440663 	ldp	x3, x1, [x19, #64]
    65e8:	f9001be1 	str	x1, [sp, #48]
    65ec:	f9400e62 	ldr	x2, [x19, #24]
    65f0:	a9020be3 	stp	x3, x2, [sp, #32]
    65f4:	ad410261 	ldp	q1, q0, [x19, #32]
    65f8:	ad0003e1 	stp	q1, q0, [sp]
    65fc:	97fff69e 	bl	4074 <fwp_tape_buffers_dispose>
    6600:	f9403260 	ldr	x0, [x19, #96]
    6604:	97ffff90 	bl	6444 <fwp_owned_tape_release>
    6608:	f900327f 	str	xzr, [x19, #96]
    660c:	f94092c0 	ldr	x0, [x22, #288]
    6610:	eb14001f 	cmp	x0, x20
    6614:	54fffdac 	b.gt	65c8 <fwp_tape_finish+0x58>
    6618:	a94553f3 	ldp	x19, x20, [sp, #80]
    661c:	910142e0 	add	x0, x23, #0x50
    6620:	f9404400 	ldr	x0, [x0, #136]
    6624:	b4000040 	cbz	x0, 662c <fwp_tape_finish+0xbc>
    6628:	97fff672 	bl	3ff0 <ad_raw_free.part.0>
    662c:	910142f7 	add	x23, x23, #0x50
    6630:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6634:	f947f400 	ldr	x0, [x0, #4072]
    6638:	f90046ff 	str	xzr, [x23, #136]
    663c:	f9008aff 	str	xzr, [x23, #272]
    6640:	f90092ff 	str	xzr, [x23, #288]
    6644:	f900b2ff 	str	xzr, [x23, #352]
    6648:	f9401fe2 	ldr	x2, [sp, #56]
    664c:	f9400001 	ldr	x1, [x0]
    6650:	eb010042 	subs	x2, x2, x1
    6654:	d2800001 	mov	x1, #0x0                   	// #0
    6658:	540000c1 	b.ne	6670 <fwp_tape_finish+0x100>  // b.any
    665c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6660:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6664:	a94763f7 	ldp	x23, x24, [sp, #112]
    6668:	910203ff 	add	sp, sp, #0x80
    666c:	d65f03c0 	ret
    6670:	a90553f3 	stp	x19, x20, [sp, #80]
    6674:	97fff08b 	bl	28a0 <__stack_chk_fail@plt>
    6678:	d503201f 	nop
    667c:	d503201f 	nop

0000000000006680 <fwp_tape_scope_release>:
    6680:	d10243ff 	sub	sp, sp, #0x90
    6684:	a9047bfd 	stp	x29, x30, [sp, #64]
    6688:	910103fd 	add	x29, sp, #0x40
    668c:	a90553f3 	stp	x19, x20, [sp, #80]
    6690:	aa0003f4 	mov	x20, x0
    6694:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6698:	f947f400 	ldr	x0, [x0, #4072]
    669c:	b9400285 	ldr	w5, [x20]
    66a0:	f9400001 	ldr	x1, [x0]
    66a4:	f9001fe1 	str	x1, [sp, #56]
    66a8:	d2800001 	mov	x1, #0x0                   	// #0
    66ac:	37f806c5 	tbnz	w5, #31, 6784 <fwp_tape_scope_release+0x104>
    66b0:	a90763f7 	stp	x23, x24, [sp, #112]
    66b4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    66b8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    66bc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    66c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    66c4:	910003f7 	mov	x23, sp
    66c8:	91014273 	add	x19, x19, #0x50
    66cc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    66d0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66d4:	52800d16 	mov	w22, #0x68                  	// #104
    66d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    66dc:	f90043f9 	str	x25, [sp, #128]
    66e0:	14000006 	b	66f8 <fwp_tape_scope_release+0x78>
    66e4:	97fff664 	bl	4074 <fwp_tape_buffers_dispose>
    66e8:	aa1903e0 	mov	x0, x25
    66ec:	97ffff56 	bl	6444 <fwp_owned_tape_release>
    66f0:	b9400285 	ldr	w5, [x20]
    66f4:	37f80425 	tbnz	w5, #31, 6778 <fwp_tape_scope_release+0xf8>
    66f8:	f9404666 	ldr	x6, [x19, #136]
    66fc:	9b367ca5 	smull	x5, w5, w22
    6700:	8b0500c0 	add	x0, x6, x5
    6704:	97fff244 	bl	3014 <fwp_tape_unlink_scope>
    6708:	ad410001 	ldp	q1, q0, [x0, #32]
    670c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6710:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6714:	f9400c03 	ldr	x3, [x0, #24]
    6718:	ad0003e1 	stp	q1, q0, [sp]
    671c:	b86568c1 	ldr	w1, [x6, x5]
    6720:	a9440804 	ldp	x4, x2, [x0, #64]
    6724:	b900041f 	str	wzr, [x0, #4]
    6728:	f9403019 	ldr	x25, [x0, #96]
    672c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6730:	f9000c1f 	str	xzr, [x0, #24]
    6734:	a9020fe4 	stp	x4, x3, [sp, #32]
    6738:	f9001be2 	str	x2, [sp, #48]
    673c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6740:	f900301f 	str	xzr, [x0, #96]
    6744:	6b15003f 	cmp	w1, w21
    6748:	540000e8 	b.hi	6764 <fwp_tape_scope_release+0xe4>  // b.pmore
    674c:	9343fca5 	asr	x5, x5, #3
    6750:	f940b260 	ldr	x0, [x19, #352]
    6754:	9b187ca5 	mul	x5, x5, x24
    6758:	eb0000bf 	cmp	x5, x0
    675c:	5400004a 	b.ge	6764 <fwp_tape_scope_release+0xe4>  // b.tcont
    6760:	f900b265 	str	x5, [x19, #352]
    6764:	aa1703e0 	mov	x0, x23
    6768:	b5fffbf9 	cbnz	x25, 66e4 <fwp_tape_scope_release+0x64>
    676c:	97fff68a 	bl	4194 <fwp_tape_buffers_release>
    6770:	b9400285 	ldr	w5, [x20]
    6774:	36fffc25 	tbz	w5, #31, 66f8 <fwp_tape_scope_release+0x78>
    6778:	a9465bf5 	ldp	x21, x22, [sp, #96]
    677c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6780:	f94043f9 	ldr	x25, [sp, #128]
    6784:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6788:	f947f400 	ldr	x0, [x0, #4072]
    678c:	f9401fe2 	ldr	x2, [sp, #56]
    6790:	f9400001 	ldr	x1, [x0]
    6794:	eb010042 	subs	x2, x2, x1
    6798:	d2800001 	mov	x1, #0x0                   	// #0
    679c:	540000a1 	b.ne	67b0 <fwp_tape_scope_release+0x130>  // b.any
    67a0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    67a4:	a94553f3 	ldp	x19, x20, [sp, #80]
    67a8:	910243ff 	add	sp, sp, #0x90
    67ac:	d65f03c0 	ret
    67b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    67b4:	a90763f7 	stp	x23, x24, [sp, #112]
    67b8:	f90043f9 	str	x25, [sp, #128]
    67bc:	97fff039 	bl	28a0 <__stack_chk_fail@plt>

00000000000067c0 <fwp_drop4>:
    67c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    67c4:	910003fd 	mov	x29, sp
    67c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    67cc:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    67d0:	911882d5 	add	x21, x22, #0x620
    67d4:	a90153f3 	stp	x19, x20, [sp, #16]
    67d8:	aa0003f3 	mov	x19, x0
    67dc:	f949daa1 	ldr	x1, [x21, #5040]
    67e0:	f949eea0 	ldr	x0, [x21, #5080]
    67e4:	cb010261 	sub	x1, x19, x1
    67e8:	eb00403f 	cmp	x1, x0, lsl #16
    67ec:	54000382 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    67f0:	d350fc22 	lsr	x2, x1, #16
    67f4:	f949fea3 	ldr	x3, [x21, #5112]
    67f8:	8b020842 	add	x2, x2, x2, lsl #2
    67fc:	d37df042 	lsl	x2, x2, #3
    6800:	8b020060 	add	x0, x3, x2
    6804:	f9401014 	ldr	x20, [x0, #32]
    6808:	b40002b4 	cbz	x20, 685c <fwp_drop4+0x9c>
    680c:	38626862 	ldrb	w2, [x3, x2]
    6810:	7100085f 	cmp	w2, #0x2
    6814:	540002c0 	b.eq	686c <fwp_drop4+0xac>  // b.none
    6818:	7100045f 	cmp	w2, #0x1
    681c:	54000201 	b.ne	685c <fwp_drop4+0x9c>  // b.any
    6820:	29430002 	ldp	w2, w0, [x0, #24]
    6824:	92403c21 	and	x1, x1, #0xffff
    6828:	9b027c21 	mul	x1, x1, x2
    682c:	d360fc21 	lsr	x1, x1, #32
    6830:	eb00003f 	cmp	x1, x0
    6834:	54000142 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6838:	8b010294 	add	x20, x20, x1
    683c:	39400280 	ldrb	w0, [x20]
    6840:	340000e0 	cbz	w0, 685c <fwp_drop4+0x9c>
    6844:	7100041f 	cmp	w0, #0x1
    6848:	540001e0 	b.eq	6884 <fwp_drop4+0xc4>  // b.none
    684c:	7103fc1f 	cmp	w0, #0xff
    6850:	540007c0 	b.eq	6948 <fwp_drop4+0x188>  // b.none
    6854:	51000400 	sub	w0, w0, #0x1
    6858:	39000280 	strb	w0, [x20]
    685c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6860:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6864:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6868:	d65f03c0 	ret
    686c:	72003c3f 	tst	w1, #0xffff
    6870:	54fffe60 	b.eq	683c <fwp_drop4+0x7c>  // b.none
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	a9425bf5 	ldp	x21, x22, [sp, #32]
    687c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6880:	d65f03c0 	ret
    6884:	911882c2 	add	x2, x22, #0x620
    6888:	f9400660 	ldr	x0, [x19, #8]
    688c:	f949d841 	ldr	x1, [x2, #5040]
    6890:	f949ec42 	ldr	x2, [x2, #5080]
    6894:	cb010001 	sub	x1, x0, x1
    6898:	eb02403f 	cmp	x1, x2, lsl #16
    689c:	54000362 	b.cs	6908 <fwp_drop4+0x148>  // b.hs, b.nlast
    68a0:	d350fc22 	lsr	x2, x1, #16
    68a4:	8b020842 	add	x2, x2, x2, lsl #2
    68a8:	d37df042 	lsl	x2, x2, #3
    68ac:	8b020064 	add	x4, x3, x2
    68b0:	f9401094 	ldr	x20, [x4, #32]
    68b4:	b40002b4 	cbz	x20, 6908 <fwp_drop4+0x148>
    68b8:	38626862 	ldrb	w2, [x3, x2]
    68bc:	7100085f 	cmp	w2, #0x2
    68c0:	540003e0 	b.eq	693c <fwp_drop4+0x17c>  // b.none
    68c4:	7100045f 	cmp	w2, #0x1
    68c8:	54000201 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    68cc:	29430883 	ldp	w3, w2, [x4, #24]
    68d0:	92403c21 	and	x1, x1, #0xffff
    68d4:	9b037c21 	mul	x1, x1, x3
    68d8:	d360fc21 	lsr	x1, x1, #32
    68dc:	eb02003f 	cmp	x1, x2
    68e0:	54000142 	b.cs	6908 <fwp_drop4+0x148>  // b.hs, b.nlast
    68e4:	8b010294 	add	x20, x20, x1
    68e8:	39400281 	ldrb	w1, [x20]
    68ec:	340000e1 	cbz	w1, 6908 <fwp_drop4+0x148>
    68f0:	7100043f 	cmp	w1, #0x1
    68f4:	54000200 	b.eq	6934 <fwp_drop4+0x174>  // b.none
    68f8:	7103fc3f 	cmp	w1, #0xff
    68fc:	54000640 	b.eq	69c4 <fwp_drop4+0x204>  // b.none
    6900:	51000421 	sub	w1, w1, #0x1
    6904:	39000281 	strb	w1, [x20]
    6908:	f9400a74 	ldr	x20, [x19, #16]
    690c:	aa1303e0 	mov	x0, x19
    6910:	97fffcdc 	bl	5c80 <fwp_rc_free_arr>
    6914:	911882c0 	add	x0, x22, #0x620
    6918:	f949d801 	ldr	x1, [x0, #5040]
    691c:	f949ec00 	ldr	x0, [x0, #5080]
    6920:	cb010281 	sub	x1, x20, x1
    6924:	eb00403f 	cmp	x1, x0, lsl #16
    6928:	54fff9a2 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    692c:	aa1403f3 	mov	x19, x20
    6930:	17ffffb0 	b	67f0 <fwp_drop4+0x30>
    6934:	97fffcd3 	bl	5c80 <fwp_rc_free_arr>
    6938:	17fffff4 	b	6908 <fwp_drop4+0x148>
    693c:	72003c3f 	tst	w1, #0xffff
    6940:	54fffe41 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    6944:	17ffffe9 	b	68e8 <fwp_drop4+0x128>
    6948:	ca544681 	eor	x1, x20, x20, lsr #17
    694c:	911882c0 	add	x0, x22, #0x620
    6950:	ca412421 	eor	x1, x1, x1, lsr #9
    6954:	92401c21 	and	x1, x1, #0xff
    6958:	910a2422 	add	x2, x1, #0x289
    695c:	8b010c01 	add	x1, x0, x1, lsl #3
    6960:	8b020c02 	add	x2, x0, x2, lsl #3
    6964:	f94a2420 	ldr	x0, [x1, #5192]
    6968:	b50000a0 	cbnz	x0, 697c <fwp_drop4+0x1bc>
    696c:	14000013 	b	69b8 <fwp_drop4+0x1f8>
    6970:	91004002 	add	x2, x0, #0x10
    6974:	f9400800 	ldr	x0, [x0, #16]
    6978:	b4000200 	cbz	x0, 69b8 <fwp_drop4+0x1f8>
    697c:	f9400001 	ldr	x1, [x0]
    6980:	eb14003f 	cmp	x1, x20
    6984:	54ffff61 	b.ne	6970 <fwp_drop4+0x1b0>  // b.any
    6988:	f9400041 	ldr	x1, [x2]
    698c:	f9400420 	ldr	x0, [x1, #8]
    6990:	d1000400 	sub	x0, x0, #0x1
    6994:	f9000420 	str	x0, [x1, #8]
    6998:	f103f81f 	cmp	x0, #0xfe
    699c:	54fff601 	b.ne	685c <fwp_drop4+0x9c>  // b.any
    69a0:	39400280 	ldrb	w0, [x20]
    69a4:	7103fc1f 	cmp	w0, #0xff
    69a8:	54000460 	b.eq	6a34 <fwp_drop4+0x274>  // b.none
    69ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69b0:	39000280 	strb	w0, [x20]
    69b4:	17ffffaa 	b	685c <fwp_drop4+0x9c>
    69b8:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    69bc:	9139a000 	add	x0, x0, #0xe68
    69c0:	97fff65d 	bl	4334 <fwp_trap>
    69c4:	ca544680 	eor	x0, x20, x20, lsr #17
    69c8:	911882c1 	add	x1, x22, #0x620
    69cc:	ca402400 	eor	x0, x0, x0, lsr #9
    69d0:	92401c00 	and	x0, x0, #0xff
    69d4:	910a2402 	add	x2, x0, #0x289
    69d8:	8b000c20 	add	x0, x1, x0, lsl #3
    69dc:	8b020c22 	add	x2, x1, x2, lsl #3
    69e0:	f94a2400 	ldr	x0, [x0, #5192]
    69e4:	b50000a0 	cbnz	x0, 69f8 <fwp_drop4+0x238>
    69e8:	17fffff4 	b	69b8 <fwp_drop4+0x1f8>
    69ec:	91004002 	add	x2, x0, #0x10
    69f0:	f9400800 	ldr	x0, [x0, #16]
    69f4:	b4fffe20 	cbz	x0, 69b8 <fwp_drop4+0x1f8>
    69f8:	f9400001 	ldr	x1, [x0]
    69fc:	eb14003f 	cmp	x1, x20
    6a00:	54ffff61 	b.ne	69ec <fwp_drop4+0x22c>  // b.any
    6a04:	f9400041 	ldr	x1, [x2]
    6a08:	f9400420 	ldr	x0, [x1, #8]
    6a0c:	d1000400 	sub	x0, x0, #0x1
    6a10:	f9000420 	str	x0, [x1, #8]
    6a14:	f103f81f 	cmp	x0, #0xfe
    6a18:	54fff781 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    6a1c:	39400280 	ldrb	w0, [x20]
    6a20:	7103fc1f 	cmp	w0, #0xff
    6a24:	540000e0 	b.eq	6a40 <fwp_drop4+0x280>  // b.none
    6a28:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a2c:	39000280 	strb	w0, [x20]
    6a30:	17ffffb6 	b	6908 <fwp_drop4+0x148>
    6a34:	aa1403e0 	mov	x0, x20
    6a38:	97fff65f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6a3c:	17ffffdc 	b	69ac <fwp_drop4+0x1ec>
    6a40:	aa1403e0 	mov	x0, x20
    6a44:	97fff65c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6a48:	17fffff8 	b	6a28 <fwp_drop4+0x268>
    6a4c:	d503201f 	nop

0000000000006a50 <fwp_arg_drop37>:
    6a50:	7100003f 	cmp	w1, #0x0
    6a54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6a58:	54000041 	b.ne	6a60 <fwp_arg_drop37+0x10>  // b.any
    6a5c:	d65f03c0 	ret
    6a60:	f9400000 	ldr	x0, [x0]
    6a64:	17ffff57 	b	67c0 <fwp_drop4>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_task_dispose>:
    6a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	f9000bf3 	str	x19, [sp, #16]
    6a7c:	aa0003f3 	mov	x19, x0
    6a80:	39414000 	ldrb	w0, [x0, #80]
    6a84:	36000720 	tbz	w0, #0, 6b68 <fwp_task_dispose+0xf8>
    6a88:	f9400a60 	ldr	x0, [x19, #16]
    6a8c:	b50006e0 	cbnz	x0, 6b68 <fwp_task_dispose+0xf8>
    6a90:	a9478660 	ldp	x0, x1, [x19, #120]
    6a94:	39014e7f 	strb	wzr, [x19, #83]
    6a98:	f9003e7f 	str	xzr, [x19, #120]
    6a9c:	f100003f 	cmp	x1, #0x0
    6aa0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6aa4:	54000040 	b.eq	6aac <fwp_task_dispose+0x3c>  // b.none
    6aa8:	d63f0020 	blr	x1
    6aac:	f9405660 	ldr	x0, [x19, #168]
    6ab0:	97fff6dc 	bl	4620 <fwp_mem_free>
    6ab4:	f900567f 	str	xzr, [x19, #168]
    6ab8:	b9405e60 	ldr	w0, [x19, #92]
    6abc:	7100041f 	cmp	w0, #0x1
    6ac0:	54000420 	b.eq	6b44 <fwp_task_dispose+0xd4>  // b.none
    6ac4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    6ac8:	91188042 	add	x2, x2, #0x620
    6acc:	f949d840 	ldr	x0, [x2, #5040]
    6ad0:	f949ec41 	ldr	x1, [x2, #5080]
    6ad4:	cb000260 	sub	x0, x19, x0
    6ad8:	eb01401f 	cmp	x0, x1, lsl #16
    6adc:	540002e2 	b.cs	6b38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6ae0:	d350fc01 	lsr	x1, x0, #16
    6ae4:	f949fc44 	ldr	x4, [x2, #5112]
    6ae8:	8b010821 	add	x1, x1, x1, lsl #2
    6aec:	d37df021 	lsl	x1, x1, #3
    6af0:	8b010083 	add	x3, x4, x1
    6af4:	f9401062 	ldr	x2, [x3, #32]
    6af8:	b4000202 	cbz	x2, 6b38 <fwp_task_dispose+0xc8>
    6afc:	38616881 	ldrb	w1, [x4, x1]
    6b00:	7100083f 	cmp	w1, #0x2
    6b04:	54000280 	b.eq	6b54 <fwp_task_dispose+0xe4>  // b.none
    6b08:	7100043f 	cmp	w1, #0x1
    6b0c:	54000161 	b.ne	6b38 <fwp_task_dispose+0xc8>  // b.any
    6b10:	29430464 	ldp	w4, w1, [x3, #24]
    6b14:	92403c00 	and	x0, x0, #0xffff
    6b18:	9b047c00 	mul	x0, x0, x4
    6b1c:	d360fc00 	lsr	x0, x0, #32
    6b20:	eb01001f 	cmp	x0, x1
    6b24:	540000a2 	b.cs	6b38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6b28:	8b000042 	add	x2, x2, x0
    6b2c:	39400040 	ldrb	w0, [x2]
    6b30:	7100041f 	cmp	w0, #0x1
    6b34:	54000080 	b.eq	6b44 <fwp_task_dispose+0xd4>  // b.none
    6b38:	f9400bf3 	ldr	x19, [sp, #16]
    6b3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b40:	d65f03c0 	ret
    6b44:	aa1303e0 	mov	x0, x19
    6b48:	f9400bf3 	ldr	x19, [sp, #16]
    6b4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b50:	17fff6b4 	b	4620 <fwp_mem_free>
    6b54:	72003c1f 	tst	w0, #0xffff
    6b58:	54fffea0 	b.eq	6b2c <fwp_task_dispose+0xbc>  // b.none
    6b5c:	f9400bf3 	ldr	x19, [sp, #16]
    6b60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b64:	d65f03c0 	ret
    6b68:	97ffef62 	bl	28f0 <abort@plt>
    6b6c:	d503201f 	nop

0000000000006b70 <fwp_free_zombie>:
    6b70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b74:	910003fd 	mov	x29, sp
    6b78:	a90153f3 	stp	x19, x20, [sp, #16]
    6b7c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6b80:	91014281 	add	x1, x20, #0x50
    6b84:	f940b433 	ldr	x19, [x1, #360]
    6b88:	b4000333 	cbz	x19, 6bec <fwp_free_zombie+0x7c>
    6b8c:	f9404c20 	ldr	x0, [x1, #152]
    6b90:	eb00027f 	cmp	x19, x0
    6b94:	540002c0 	b.eq	6bec <fwp_free_zombie+0x7c>  // b.none
    6b98:	b9417022 	ldr	w2, [x1, #368]
    6b9c:	f9400a60 	ldr	x0, [x19, #16]
    6ba0:	7100fc5f 	cmp	w2, #0x3f
    6ba4:	5400078c 	b.gt	6c94 <fwp_free_zombie+0x124>
    6ba8:	91060023 	add	x3, x1, #0x180
    6bac:	11000444 	add	w4, w2, #0x1
    6bb0:	b9017024 	str	w4, [x1, #368]
    6bb4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6bb8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6bbc:	a9530261 	ldp	x1, x0, [x19, #304]
    6bc0:	b4000741 	cbz	x1, 6ca8 <fwp_free_zombie+0x138>
    6bc4:	f9009c20 	str	x0, [x1, #312]
    6bc8:	b4000040 	cbz	x0, 6bd0 <fwp_free_zombie+0x60>
    6bcc:	f9009801 	str	x1, [x0, #304]
    6bd0:	91014294 	add	x20, x20, #0x50
    6bd4:	b9405e60 	ldr	w0, [x19, #92]
    6bd8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6bdc:	f900b69f 	str	xzr, [x20, #360]
    6be0:	34000140 	cbz	w0, 6c08 <fwp_free_zombie+0x98>
    6be4:	7100041f 	cmp	w0, #0x1
    6be8:	54000080 	b.eq	6bf8 <fwp_free_zombie+0x88>  // b.none
    6bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bf4:	d65f03c0 	ret
    6bf8:	aa1303e0 	mov	x0, x19
    6bfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c04:	17ffff9b 	b	6a70 <fwp_task_dispose>
    6c08:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbc0>
    6c0c:	91188082 	add	x2, x4, #0x620
    6c10:	f949d841 	ldr	x1, [x2, #5040]
    6c14:	f949ec40 	ldr	x0, [x2, #5080]
    6c18:	cb010261 	sub	x1, x19, x1
    6c1c:	eb00403f 	cmp	x1, x0, lsl #16
    6c20:	54fffe62 	b.cs	6bec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c24:	d350fc20 	lsr	x0, x1, #16
    6c28:	f949fc43 	ldr	x3, [x2, #5112]
    6c2c:	8b000800 	add	x0, x0, x0, lsl #2
    6c30:	d37df000 	lsl	x0, x0, #3
    6c34:	8b000062 	add	x2, x3, x0
    6c38:	f9401054 	ldr	x20, [x2, #32]
    6c3c:	b4fffd94 	cbz	x20, 6bec <fwp_free_zombie+0x7c>
    6c40:	38606860 	ldrb	w0, [x3, x0]
    6c44:	7100081f 	cmp	w0, #0x2
    6c48:	54000360 	b.eq	6cb4 <fwp_free_zombie+0x144>  // b.none
    6c4c:	7100041f 	cmp	w0, #0x1
    6c50:	54fffce1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6c54:	29430043 	ldp	w3, w0, [x2, #24]
    6c58:	92403c21 	and	x1, x1, #0xffff
    6c5c:	9b037c21 	mul	x1, x1, x3
    6c60:	d360fc21 	lsr	x1, x1, #32
    6c64:	eb00003f 	cmp	x1, x0
    6c68:	54fffc22 	b.cs	6bec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c6c:	8b010294 	add	x20, x20, x1
    6c70:	39400280 	ldrb	w0, [x20]
    6c74:	34fffbc0 	cbz	w0, 6bec <fwp_free_zombie+0x7c>
    6c78:	7100041f 	cmp	w0, #0x1
    6c7c:	54fffbe0 	b.eq	6bf8 <fwp_free_zombie+0x88>  // b.none
    6c80:	7103fc1f 	cmp	w0, #0xff
    6c84:	540001e0 	b.eq	6cc0 <fwp_free_zombie+0x150>  // b.none
    6c88:	51000400 	sub	w0, w0, #0x1
    6c8c:	39000280 	strb	w0, [x20]
    6c90:	17ffffd7 	b	6bec <fwp_free_zombie+0x7c>
    6c94:	f9400e61 	ldr	x1, [x19, #24]
    6c98:	97ffef4a 	bl	29c0 <munmap@plt>
    6c9c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ca0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ca4:	b5fff901 	cbnz	x1, 6bc4 <fwp_free_zombie+0x54>
    6ca8:	91014282 	add	x2, x20, #0x50
    6cac:	f901c040 	str	x0, [x2, #896]
    6cb0:	17ffffc6 	b	6bc8 <fwp_free_zombie+0x58>
    6cb4:	72003c3f 	tst	w1, #0xffff
    6cb8:	54fff9a1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6cbc:	17ffffed 	b	6c70 <fwp_free_zombie+0x100>
    6cc0:	ca544680 	eor	x0, x20, x20, lsr #17
    6cc4:	91188084 	add	x4, x4, #0x620
    6cc8:	ca402400 	eor	x0, x0, x0, lsr #9
    6ccc:	92401c00 	and	x0, x0, #0xff
    6cd0:	910a2402 	add	x2, x0, #0x289
    6cd4:	8b000c80 	add	x0, x4, x0, lsl #3
    6cd8:	8b020c82 	add	x2, x4, x2, lsl #3
    6cdc:	f94a2400 	ldr	x0, [x0, #5192]
    6ce0:	b50000a0 	cbnz	x0, 6cf4 <fwp_free_zombie+0x184>
    6ce4:	14000013 	b	6d30 <fwp_free_zombie+0x1c0>
    6ce8:	91004002 	add	x2, x0, #0x10
    6cec:	f9400800 	ldr	x0, [x0, #16]
    6cf0:	b4000200 	cbz	x0, 6d30 <fwp_free_zombie+0x1c0>
    6cf4:	f9400001 	ldr	x1, [x0]
    6cf8:	eb14003f 	cmp	x1, x20
    6cfc:	54ffff61 	b.ne	6ce8 <fwp_free_zombie+0x178>  // b.any
    6d00:	f9400041 	ldr	x1, [x2]
    6d04:	f9400420 	ldr	x0, [x1, #8]
    6d08:	d1000400 	sub	x0, x0, #0x1
    6d0c:	f9000420 	str	x0, [x1, #8]
    6d10:	f103f81f 	cmp	x0, #0xfe
    6d14:	54fff6c1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6d18:	39400280 	ldrb	w0, [x20]
    6d1c:	7103fc1f 	cmp	w0, #0xff
    6d20:	540000e0 	b.eq	6d3c <fwp_free_zombie+0x1cc>  // b.none
    6d24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d28:	39000280 	strb	w0, [x20]
    6d2c:	17ffffb0 	b	6bec <fwp_free_zombie+0x7c>
    6d30:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    6d34:	9139a000 	add	x0, x0, #0xe68
    6d38:	97fff57f 	bl	4334 <fwp_trap>
    6d3c:	aa1403e0 	mov	x0, x20
    6d40:	97fff59d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6d44:	17fffff8 	b	6d24 <fwp_free_zombie+0x1b4>
    6d48:	d503201f 	nop
    6d4c:	d503201f 	nop

0000000000006d50 <fwp_block>:
    6d50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d54:	910003fd 	mov	x29, sp
    6d58:	a90153f3 	stp	x19, x20, [sp, #16]
    6d5c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6d60:	91014274 	add	x20, x19, #0x50
    6d64:	f9406682 	ldr	x2, [x20, #200]
    6d68:	b4000642 	cbz	x2, 6e30 <fwp_block+0xe0>
    6d6c:	91014261 	add	x1, x19, #0x50
    6d70:	f9408040 	ldr	x0, [x2, #256]
    6d74:	f9006420 	str	x0, [x1, #200]
    6d78:	b40006a0 	cbz	x0, 6e4c <fwp_block+0xfc>
    6d7c:	d503201f 	nop
    6d80:	91014263 	add	x3, x19, #0x50
    6d84:	3901505f 	strb	wzr, [x2, #84]
    6d88:	f9404c64 	ldr	x4, [x3, #152]
    6d8c:	eb02009f 	cmp	x4, x2
    6d90:	54000440 	b.eq	6e18 <fwp_block+0xc8>  // b.none
    6d94:	f941c465 	ldr	x5, [x3, #904]
    6d98:	f9004c62 	str	x2, [x3, #152]
    6d9c:	f9400441 	ldr	x1, [x2, #8]
    6da0:	f9004885 	str	x5, [x4, #144]
    6da4:	f941c865 	ldr	x5, [x3, #912]
    6da8:	f9004c85 	str	x5, [x4, #152]
    6dac:	f941cc65 	ldr	x5, [x3, #920]
    6db0:	f9005085 	str	x5, [x4, #160]
    6db4:	f941d065 	ldr	x5, [x3, #928]
    6db8:	f9005485 	str	x5, [x4, #168]
    6dbc:	f941d465 	ldr	x5, [x3, #936]
    6dc0:	f9005885 	str	x5, [x4, #176]
    6dc4:	f941d865 	ldr	x5, [x3, #944]
    6dc8:	f9005c85 	str	x5, [x4, #184]
    6dcc:	f941dc65 	ldr	x5, [x3, #952]
    6dd0:	f9006085 	str	x5, [x4, #192]
    6dd4:	f9400480 	ldr	x0, [x4, #8]
    6dd8:	f9404844 	ldr	x4, [x2, #144]
    6ddc:	f901c464 	str	x4, [x3, #904]
    6de0:	f9404c44 	ldr	x4, [x2, #152]
    6de4:	f901c864 	str	x4, [x3, #912]
    6de8:	f9405044 	ldr	x4, [x2, #160]
    6dec:	f901cc64 	str	x4, [x3, #920]
    6df0:	f9405444 	ldr	x4, [x2, #168]
    6df4:	f901d064 	str	x4, [x3, #928]
    6df8:	f9405844 	ldr	x4, [x2, #176]
    6dfc:	f901d464 	str	x4, [x3, #936]
    6e00:	a94b8844 	ldp	x4, x2, [x2, #184]
    6e04:	f901d864 	str	x4, [x3, #944]
    6e08:	f901dc62 	str	x2, [x3, #952]
    6e0c:	97ffeebd 	bl	2900 <swapcontext@plt>
    6e10:	97ffff58 	bl	6b70 <fwp_free_zombie>
    6e14:	d503201f 	nop
    6e18:	91014260 	add	x0, x19, #0x50
    6e1c:	b943c000 	ldr	w0, [x0, #960]
    6e20:	340001a0 	cbz	w0, 6e54 <fwp_block+0x104>
    6e24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e2c:	d65f03c0 	ret
    6e30:	97fff788 	bl	4c50 <fwp_poll_events>
    6e34:	f9406682 	ldr	x2, [x20, #200]
    6e38:	b4ffffc2 	cbz	x2, 6e30 <fwp_block+0xe0>
    6e3c:	91014261 	add	x1, x19, #0x50
    6e40:	f9408040 	ldr	x0, [x2, #256]
    6e44:	f9006420 	str	x0, [x1, #200]
    6e48:	b5fff9c0 	cbnz	x0, 6d80 <fwp_block+0x30>
    6e4c:	f900603f 	str	xzr, [x1, #192]
    6e50:	17ffffcc 	b	6d80 <fwp_block+0x30>
    6e54:	90000020 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    6e58:	91040000 	add	x0, x0, #0x100
    6e5c:	97ffeef5 	bl	2a30 <getenv@plt>
    6e60:	5284e202 	mov	w2, #0x2710                	// #10000
    6e64:	b4000060 	cbz	x0, 6e70 <fwp_block+0x120>
    6e68:	39400001 	ldrb	w1, [x0]
    6e6c:	350000c1 	cbnz	w1, 6e84 <fwp_block+0x134>
    6e70:	91014273 	add	x19, x19, #0x50
    6e74:	b903c262 	str	w2, [x19, #960]
    6e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e80:	d65f03c0 	ret
    6e84:	52800142 	mov	w2, #0xa                   	// #10
    6e88:	d2800001 	mov	x1, #0x0                   	// #0
    6e8c:	97ffee39 	bl	2770 <strtoll@plt>
    6e90:	d1000403 	sub	x3, x0, #0x1
    6e94:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6e98:	eb02007f 	cmp	x3, x2
    6e9c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6ea0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6ea4:	17fffff3 	b	6e70 <fwp_block+0x120>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <fwp_drop10>:
    6eb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	a90153f3 	stp	x19, x20, [sp, #16]
    6ebc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    6ec0:	f90013f5 	str	x21, [sp, #32]
    6ec4:	91188275 	add	x21, x19, #0x620
    6ec8:	f949daa1 	ldr	x1, [x21, #5040]
    6ecc:	f949eea2 	ldr	x2, [x21, #5080]
    6ed0:	cb010001 	sub	x1, x0, x1
    6ed4:	eb02403f 	cmp	x1, x2, lsl #16
    6ed8:	54000382 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6edc:	d350fc22 	lsr	x2, x1, #16
    6ee0:	f949fea3 	ldr	x3, [x21, #5112]
    6ee4:	8b020842 	add	x2, x2, x2, lsl #2
    6ee8:	d37df042 	lsl	x2, x2, #3
    6eec:	8b020064 	add	x4, x3, x2
    6ef0:	f9401094 	ldr	x20, [x4, #32]
    6ef4:	b40002b4 	cbz	x20, 6f48 <fwp_drop10+0x98>
    6ef8:	38626862 	ldrb	w2, [x3, x2]
    6efc:	7100085f 	cmp	w2, #0x2
    6f00:	540007a0 	b.eq	6ff4 <fwp_drop10+0x144>  // b.none
    6f04:	7100045f 	cmp	w2, #0x1
    6f08:	54000201 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6f0c:	29430885 	ldp	w5, w2, [x4, #24]
    6f10:	92403c21 	and	x1, x1, #0xffff
    6f14:	9b057c21 	mul	x1, x1, x5
    6f18:	d360fc21 	lsr	x1, x1, #32
    6f1c:	eb02003f 	cmp	x1, x2
    6f20:	54000142 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f24:	8b010294 	add	x20, x20, x1
    6f28:	39400281 	ldrb	w1, [x20]
    6f2c:	340000e1 	cbz	w1, 6f48 <fwp_drop10+0x98>
    6f30:	7100043f 	cmp	w1, #0x1
    6f34:	54000120 	b.eq	6f58 <fwp_drop10+0xa8>  // b.none
    6f38:	7103fc3f 	cmp	w1, #0xff
    6f3c:	540007c0 	b.eq	7034 <fwp_drop10+0x184>  // b.none
    6f40:	51000421 	sub	w1, w1, #0x1
    6f44:	39000281 	strb	w1, [x20]
    6f48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f4c:	f94013f5 	ldr	x21, [sp, #32]
    6f50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f54:	d65f03c0 	ret
    6f58:	f9400001 	ldr	x1, [x0]
    6f5c:	b7f80581 	tbnz	x1, #63, 700c <fwp_drop10+0x15c>
    6f60:	91188273 	add	x19, x19, #0x620
    6f64:	f949da61 	ldr	x1, [x19, #5040]
    6f68:	f949ee62 	ldr	x2, [x19, #5080]
    6f6c:	cb010001 	sub	x1, x0, x1
    6f70:	eb02403f 	cmp	x1, x2, lsl #16
    6f74:	54fffea2 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f78:	d350fc22 	lsr	x2, x1, #16
    6f7c:	8b020842 	add	x2, x2, x2, lsl #2
    6f80:	d37df042 	lsl	x2, x2, #3
    6f84:	8b020065 	add	x5, x3, x2
    6f88:	f94010a4 	ldr	x4, [x5, #32]
    6f8c:	b4fffde4 	cbz	x4, 6f48 <fwp_drop10+0x98>
    6f90:	38626862 	ldrb	w2, [x3, x2]
    6f94:	7100085f 	cmp	w2, #0x2
    6f98:	54000220 	b.eq	6fdc <fwp_drop10+0x12c>  // b.none
    6f9c:	7100045f 	cmp	w2, #0x1
    6fa0:	54fffd41 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6fa4:	294308a3 	ldp	w3, w2, [x5, #24]
    6fa8:	92403c21 	and	x1, x1, #0xffff
    6fac:	9b037c21 	mul	x1, x1, x3
    6fb0:	d360fc21 	lsr	x1, x1, #32
    6fb4:	eb02003f 	cmp	x1, x2
    6fb8:	54fffc82 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6fbc:	8b010084 	add	x4, x4, x1
    6fc0:	39400081 	ldrb	w1, [x4]
    6fc4:	7100043f 	cmp	w1, #0x1
    6fc8:	54fffc01 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fd0:	f94013f5 	ldr	x21, [sp, #32]
    6fd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fd8:	17fff592 	b	4620 <fwp_mem_free>
    6fdc:	72003c3f 	tst	w1, #0xffff
    6fe0:	54ffff00 	b.eq	6fc0 <fwp_drop10+0x110>  // b.none
    6fe4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fe8:	f94013f5 	ldr	x21, [sp, #32]
    6fec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ff0:	d65f03c0 	ret
    6ff4:	72003c3f 	tst	w1, #0xffff
    6ff8:	54fff980 	b.eq	6f28 <fwp_drop10+0x78>  // b.none
    6ffc:	a94153f3 	ldp	x19, x20, [sp, #16]
    7000:	f94013f5 	ldr	x21, [sp, #32]
    7004:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7008:	d65f03c0 	ret
    700c:	f9400414 	ldr	x20, [x0, #8]
    7010:	97fffb1c 	bl	5c80 <fwp_rc_free_arr>
    7014:	91188260 	add	x0, x19, #0x620
    7018:	f949d801 	ldr	x1, [x0, #5040]
    701c:	f949ec00 	ldr	x0, [x0, #5080]
    7020:	cb010281 	sub	x1, x20, x1
    7024:	eb00403f 	cmp	x1, x0, lsl #16
    7028:	54fff902 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    702c:	aa1403e0 	mov	x0, x20
    7030:	17ffffab 	b	6edc <fwp_drop10+0x2c>
    7034:	ca544680 	eor	x0, x20, x20, lsr #17
    7038:	91188273 	add	x19, x19, #0x620
    703c:	ca402400 	eor	x0, x0, x0, lsr #9
    7040:	92401c00 	and	x0, x0, #0xff
    7044:	910a2402 	add	x2, x0, #0x289
    7048:	8b000e60 	add	x0, x19, x0, lsl #3
    704c:	8b020e62 	add	x2, x19, x2, lsl #3
    7050:	f94a2400 	ldr	x0, [x0, #5192]
    7054:	b50000a0 	cbnz	x0, 7068 <fwp_drop10+0x1b8>
    7058:	14000013 	b	70a4 <fwp_drop10+0x1f4>
    705c:	91004002 	add	x2, x0, #0x10
    7060:	f9400800 	ldr	x0, [x0, #16]
    7064:	b4000200 	cbz	x0, 70a4 <fwp_drop10+0x1f4>
    7068:	f9400001 	ldr	x1, [x0]
    706c:	eb14003f 	cmp	x1, x20
    7070:	54ffff61 	b.ne	705c <fwp_drop10+0x1ac>  // b.any
    7074:	f9400041 	ldr	x1, [x2]
    7078:	f9400420 	ldr	x0, [x1, #8]
    707c:	d1000400 	sub	x0, x0, #0x1
    7080:	f9000420 	str	x0, [x1, #8]
    7084:	f103f81f 	cmp	x0, #0xfe
    7088:	54fff601 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    708c:	39400280 	ldrb	w0, [x20]
    7090:	7103fc1f 	cmp	w0, #0xff
    7094:	540000e0 	b.eq	70b0 <fwp_drop10+0x200>  // b.none
    7098:	12800020 	mov	w0, #0xfffffffe            	// #-2
    709c:	39000280 	strb	w0, [x20]
    70a0:	17ffffaa 	b	6f48 <fwp_drop10+0x98>
    70a4:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    70a8:	9139a000 	add	x0, x0, #0xe68
    70ac:	97fff4a2 	bl	4334 <fwp_trap>
    70b0:	aa1403e0 	mov	x0, x20
    70b4:	97fff4c0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    70b8:	17fffff8 	b	7098 <fwp_drop10+0x1e8>
    70bc:	d503201f 	nop

00000000000070c0 <fwp_caps173>:
    70c0:	34000041 	cbz	w1, 70c8 <fwp_caps173+0x8>
    70c4:	d65f03c0 	ret
    70c8:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    70cc:	91188063 	add	x3, x3, #0x620
    70d0:	f949d861 	ldr	x1, [x3, #5040]
    70d4:	f949ec62 	ldr	x2, [x3, #5080]
    70d8:	cb010001 	sub	x1, x0, x1
    70dc:	eb02403f 	cmp	x1, x2, lsl #16
    70e0:	54ffff22 	b.cs	70c4 <fwp_caps173+0x4>  // b.hs, b.nlast
    70e4:	d350fc22 	lsr	x2, x1, #16
    70e8:	f949fc65 	ldr	x5, [x3, #5112]
    70ec:	8b020842 	add	x2, x2, x2, lsl #2
    70f0:	d37df042 	lsl	x2, x2, #3
    70f4:	8b0200a4 	add	x4, x5, x2
    70f8:	f9401083 	ldr	x3, [x4, #32]
    70fc:	b4fffe43 	cbz	x3, 70c4 <fwp_caps173+0x4>
    7100:	386268a2 	ldrb	w2, [x5, x2]
    7104:	7100085f 	cmp	w2, #0x2
    7108:	540001c0 	b.eq	7140 <fwp_caps173+0x80>  // b.none
    710c:	7100045f 	cmp	w2, #0x1
    7110:	54fffda1 	b.ne	70c4 <fwp_caps173+0x4>  // b.any
    7114:	29430885 	ldp	w5, w2, [x4, #24]
    7118:	92403c21 	and	x1, x1, #0xffff
    711c:	9b057c21 	mul	x1, x1, x5
    7120:	d360fc21 	lsr	x1, x1, #32
    7124:	eb02003f 	cmp	x1, x2
    7128:	54fffce2 	b.cs	70c4 <fwp_caps173+0x4>  // b.hs, b.nlast
    712c:	8b010063 	add	x3, x3, x1
    7130:	39400061 	ldrb	w1, [x3]
    7134:	7100043f 	cmp	w1, #0x1
    7138:	54fffc61 	b.ne	70c4 <fwp_caps173+0x4>  // b.any
    713c:	17fff539 	b	4620 <fwp_mem_free>
    7140:	72003c3f 	tst	w1, #0xffff
    7144:	54ffff60 	b.eq	7130 <fwp_caps173+0x70>  // b.none
    7148:	d65f03c0 	ret
    714c:	d503201f 	nop

0000000000007150 <f37>:
    7150:	d10203ff 	sub	sp, sp, #0x80
    7154:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    7158:	f947f421 	ldr	x1, [x1, #4072]
    715c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7160:	910083fd 	add	x29, sp, #0x20
    7164:	a9045bf5 	stp	x21, x22, [sp, #64]
    7168:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    716c:	911882a3 	add	x3, x21, #0x620
    7170:	a90353f3 	stp	x19, x20, [sp, #48]
    7174:	aa0003f6 	mov	x22, x0
    7178:	a90563f7 	stp	x23, x24, [sp, #80]
    717c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7180:	f949ec62 	ldr	x2, [x3, #5080]
    7184:	f9400024 	ldr	x4, [x1]
    7188:	f9000fe4 	str	x4, [sp, #24]
    718c:	d2800004 	mov	x4, #0x0                   	// #0
    7190:	f949d861 	ldr	x1, [x3, #5040]
    7194:	d370bc42 	lsl	x2, x2, #16
    7198:	b4001920 	cbz	x0, 74bc <f37+0x36c>
    719c:	f9400817 	ldr	x23, [x0, #16]
    71a0:	cb0102e1 	sub	x1, x23, x1
    71a4:	eb02003f 	cmp	x1, x2
    71a8:	540003e2 	b.cs	7224 <f37+0xd4>  // b.hs, b.nlast
    71ac:	f949fc60 	ldr	x0, [x3, #5112]
    71b0:	d350fc22 	lsr	x2, x1, #16
    71b4:	8b020842 	add	x2, x2, x2, lsl #2
    71b8:	8b020c02 	add	x2, x0, x2, lsl #3
    71bc:	f9401040 	ldr	x0, [x2, #32]
    71c0:	b4000320 	cbz	x0, 7224 <f37+0xd4>
    71c4:	39400043 	ldrb	w3, [x2]
    71c8:	7100087f 	cmp	w3, #0x2
    71cc:	540015e0 	b.eq	7488 <f37+0x338>  // b.none
    71d0:	7100047f 	cmp	w3, #0x1
    71d4:	54000241 	b.ne	721c <f37+0xcc>  // b.any
    71d8:	29430843 	ldp	w3, w2, [x2, #24]
    71dc:	92403c21 	and	x1, x1, #0xffff
    71e0:	9b037c21 	mul	x1, x1, x3
    71e4:	d360fc21 	lsr	x1, x1, #32
    71e8:	eb02003f 	cmp	x1, x2
    71ec:	54000182 	b.cs	721c <f37+0xcc>  // b.hs, b.nlast
    71f0:	8b010000 	add	x0, x0, x1
    71f4:	39400001 	ldrb	w1, [x0]
    71f8:	34000121 	cbz	w1, 721c <f37+0xcc>
    71fc:	b00000c2 	adrp	x2, 20000 <__data_start>
    7200:	91014042 	add	x2, x2, #0x50
    7204:	b9413043 	ldr	w3, [x2, #304]
    7208:	35001463 	cbnz	w3, 7494 <f37+0x344>
    720c:	7103f43f 	cmp	w1, #0xfd
    7210:	54001888 	b.hi	7520 <f37+0x3d0>  // b.pmore
    7214:	11000421 	add	w1, w1, #0x1
    7218:	39000001 	strb	w1, [x0]
    721c:	d2800002 	mov	x2, #0x0                   	// #0
    7220:	b40000f6 	cbz	x22, 723c <f37+0xec>
    7224:	aa1603e1 	mov	x1, x22
    7228:	d2800002 	mov	x2, #0x0                   	// #0
    722c:	d503201f 	nop
    7230:	f9400821 	ldr	x1, [x1, #16]
    7234:	91000442 	add	x2, x2, #0x1
    7238:	b5ffffc1 	cbnz	x1, 7230 <f37+0xe0>
    723c:	b4001477 	cbz	x23, 74c8 <f37+0x378>
    7240:	aa1703e1 	mov	x1, x23
    7244:	d2800003 	mov	x3, #0x0                   	// #0
    7248:	f9400821 	ldr	x1, [x1, #16]
    724c:	91000463 	add	x3, x3, #0x1
    7250:	b5ffffc1 	cbnz	x1, 7248 <f37+0xf8>
    7254:	eb02007f 	cmp	x3, x2
    7258:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    725c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7260:	eb00027f 	cmp	x19, x0
    7264:	540010a8 	b.hi	7478 <f37+0x328>  // b.pmore
    7268:	d37ffa74 	lsl	x20, x19, #1
    726c:	52800041 	mov	w1, #0x2                   	// #2
    7270:	91000680 	add	x0, x20, #0x1
    7274:	d37df000 	lsl	x0, x0, #3
    7278:	97fff7a6 	bl	5110 <fwp_heap_alloc>
    727c:	aa0003f8 	mov	x24, x0
    7280:	911882a1 	add	x1, x21, #0x620
    7284:	aa0103e0 	mov	x0, x1
    7288:	f9000314 	str	x20, [x24]
    728c:	f949d821 	ldr	x1, [x1, #5040]
    7290:	f949ec00 	ldr	x0, [x0, #5080]
    7294:	cb010301 	sub	x1, x24, x1
    7298:	eb00403f 	cmp	x1, x0, lsl #16
    729c:	54000342 	b.cs	7304 <f37+0x1b4>  // b.hs, b.nlast
    72a0:	911882a2 	add	x2, x21, #0x620
    72a4:	d350fc20 	lsr	x0, x1, #16
    72a8:	8b000800 	add	x0, x0, x0, lsl #2
    72ac:	f949fc43 	ldr	x3, [x2, #5112]
    72b0:	d37df002 	lsl	x2, x0, #3
    72b4:	8b020060 	add	x0, x3, x2
    72b8:	f9401014 	ldr	x20, [x0, #32]
    72bc:	b4000254 	cbz	x20, 7304 <f37+0x1b4>
    72c0:	38626862 	ldrb	w2, [x3, x2]
    72c4:	7100085f 	cmp	w2, #0x2
    72c8:	54000ee0 	b.eq	74a4 <f37+0x354>  // b.none
    72cc:	7100045f 	cmp	w2, #0x1
    72d0:	540001a1 	b.ne	7304 <f37+0x1b4>  // b.any
    72d4:	29430002 	ldp	w2, w0, [x0, #24]
    72d8:	92403c21 	and	x1, x1, #0xffff
    72dc:	9b027c21 	mul	x1, x1, x2
    72e0:	d360fc21 	lsr	x1, x1, #32
    72e4:	eb00003f 	cmp	x1, x0
    72e8:	540000e2 	b.cs	7304 <f37+0x1b4>  // b.hs, b.nlast
    72ec:	8b010294 	add	x20, x20, x1
    72f0:	39400280 	ldrb	w0, [x20]
    72f4:	7103fc1f 	cmp	w0, #0xff
    72f8:	54001180 	b.eq	7528 <f37+0x3d8>  // b.none
    72fc:	52800020 	mov	w0, #0x1                   	// #1
    7300:	39000280 	strb	w0, [x20]
    7304:	b4000253 	cbz	x19, 734c <f37+0x1fc>
    7308:	8b131313 	add	x19, x24, x19, lsl #4
    730c:	aa1803f4 	mov	x20, x24
    7310:	aa1603fa 	mov	x26, x22
    7314:	aa1703f9 	mov	x25, x23
    7318:	f9400723 	ldr	x3, [x25, #8]
    731c:	f9400742 	ldr	x2, [x26, #8]
    7320:	f9400861 	ldr	x1, [x3, #16]
    7324:	f9400840 	ldr	x0, [x2, #16]
    7328:	fd400461 	ldr	d1, [x3, #8]
    732c:	fd400440 	ldr	d0, [x2, #8]
    7330:	97fff91d 	bl	57a4 <w120>
    7334:	f9000680 	str	x0, [x20, #8]
    7338:	f8010e81 	str	x1, [x20, #16]!
    733c:	f9400b39 	ldr	x25, [x25, #16]
    7340:	f9400b5a 	ldr	x26, [x26, #16]
    7344:	eb14027f 	cmp	x19, x20
    7348:	54fffe81 	b.ne	7318 <f37+0x1c8>  // b.any
    734c:	aa1703e0 	mov	x0, x23
    7350:	97fffd1c 	bl	67c0 <fwp_drop4>
    7354:	aa1603e0 	mov	x0, x22
    7358:	97fffd1a 	bl	67c0 <fwp_drop4>
    735c:	f9400316 	ldr	x22, [x24]
    7360:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7364:	b4000236 	cbz	x22, 73a8 <f37+0x258>
    7368:	fd003be8 	str	d8, [sp, #112]
    736c:	2f00e408 	movi	d8, #0x0
    7370:	91002319 	add	x25, x24, #0x8
    7374:	91004317 	add	x23, x24, #0x10
    7378:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    737c:	d2800013 	mov	x19, #0x0                   	// #0
    7380:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7384:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7388:	91000a73 	add	x19, x19, #0x2
    738c:	1e602908 	fadd	d8, d8, d0
    7390:	97fff8b4 	bl	5660 <f141.constprop.0>
    7394:	aa0003f4 	mov	x20, x0
    7398:	eb1302df 	cmp	x22, x19
    739c:	54ffff28 	b.hi	7380 <f37+0x230>  // b.pmore
    73a0:	9e660116 	fmov	x22, d8
    73a4:	fd403be8 	ldr	d8, [sp, #112]
    73a8:	911882b5 	add	x21, x21, #0x620
    73ac:	aa1803e0 	mov	x0, x24
    73b0:	97fffec0 	bl	6eb0 <fwp_drop10>
    73b4:	a900d3f6 	stp	x22, x20, [sp, #8]
    73b8:	910023e1 	add	x1, sp, #0x8
    73bc:	52800000 	mov	w0, #0x0                   	// #0
    73c0:	97fff7b8 	bl	52a0 <fwp_data.part.0.constprop.0>
    73c4:	f949daa1 	ldr	x1, [x21, #5040]
    73c8:	aa0003f3 	mov	x19, x0
    73cc:	f949eea0 	ldr	x0, [x21, #5080]
    73d0:	cb010261 	sub	x1, x19, x1
    73d4:	eb00403f 	cmp	x1, x0, lsl #16
    73d8:	54000322 	b.cs	743c <f37+0x2ec>  // b.hs, b.nlast
    73dc:	d350fc22 	lsr	x2, x1, #16
    73e0:	f949fea3 	ldr	x3, [x21, #5112]
    73e4:	8b020842 	add	x2, x2, x2, lsl #2
    73e8:	d37df042 	lsl	x2, x2, #3
    73ec:	8b020060 	add	x0, x3, x2
    73f0:	f9401014 	ldr	x20, [x0, #32]
    73f4:	b4000254 	cbz	x20, 743c <f37+0x2ec>
    73f8:	38626862 	ldrb	w2, [x3, x2]
    73fc:	7100085f 	cmp	w2, #0x2
    7400:	54000580 	b.eq	74b0 <f37+0x360>  // b.none
    7404:	7100045f 	cmp	w2, #0x1
    7408:	540001a1 	b.ne	743c <f37+0x2ec>  // b.any
    740c:	29430002 	ldp	w2, w0, [x0, #24]
    7410:	92403c21 	and	x1, x1, #0xffff
    7414:	9b027c21 	mul	x1, x1, x2
    7418:	d360fc21 	lsr	x1, x1, #32
    741c:	eb00003f 	cmp	x1, x0
    7420:	540000e2 	b.cs	743c <f37+0x2ec>  // b.hs, b.nlast
    7424:	8b010294 	add	x20, x20, x1
    7428:	39400280 	ldrb	w0, [x20]
    742c:	7103fc1f 	cmp	w0, #0xff
    7430:	54000820 	b.eq	7534 <f37+0x3e4>  // b.none
    7434:	52800020 	mov	w0, #0x1                   	// #1
    7438:	39000280 	strb	w0, [x20]
    743c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7440:	f947f400 	ldr	x0, [x0, #4072]
    7444:	f9400fe2 	ldr	x2, [sp, #24]
    7448:	f9400001 	ldr	x1, [x0]
    744c:	eb010042 	subs	x2, x2, x1
    7450:	d2800001 	mov	x1, #0x0                   	// #0
    7454:	540007a1 	b.ne	7548 <f37+0x3f8>  // b.any
    7458:	a9427bfd 	ldp	x29, x30, [sp, #32]
    745c:	aa1303e0 	mov	x0, x19
    7460:	a94353f3 	ldp	x19, x20, [sp, #48]
    7464:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7468:	a94563f7 	ldp	x23, x24, [sp, #80]
    746c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7470:	910203ff 	add	sp, sp, #0x80
    7474:	d65f03c0 	ret
    7478:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    747c:	91044000 	add	x0, x0, #0x110
    7480:	fd003be8 	str	d8, [sp, #112]
    7484:	97fff3ac 	bl	4334 <fwp_trap>
    7488:	72003c3f 	tst	w1, #0xffff
    748c:	54ffec81 	b.ne	721c <f37+0xcc>  // b.any
    7490:	17ffff59 	b	71f4 <f37+0xa4>
    7494:	f940ac43 	ldr	x3, [x2, #344]
    7498:	91000463 	add	x3, x3, #0x1
    749c:	f900ac43 	str	x3, [x2, #344]
    74a0:	17ffff5b 	b	720c <f37+0xbc>
    74a4:	72003c3f 	tst	w1, #0xffff
    74a8:	54fff2e1 	b.ne	7304 <f37+0x1b4>  // b.any
    74ac:	17ffff91 	b	72f0 <f37+0x1a0>
    74b0:	72003c3f 	tst	w1, #0xffff
    74b4:	54fffc41 	b.ne	743c <f37+0x2ec>  // b.any
    74b8:	17ffffdc 	b	7428 <f37+0x2d8>
    74bc:	cb0103e1 	neg	x1, x1
    74c0:	eb02003f 	cmp	x1, x2
    74c4:	540001e3 	b.cc	7500 <f37+0x3b0>  // b.lo, b.ul, b.last
    74c8:	52800041 	mov	w1, #0x2                   	// #2
    74cc:	d2800100 	mov	x0, #0x8                   	// #8
    74d0:	97fff710 	bl	5110 <fwp_heap_alloc>
    74d4:	aa0003f8 	mov	x24, x0
    74d8:	911882a0 	add	x0, x21, #0x620
    74dc:	f900031f 	str	xzr, [x24]
    74e0:	f949d801 	ldr	x1, [x0, #5040]
    74e4:	f949ec00 	ldr	x0, [x0, #5080]
    74e8:	cb010301 	sub	x1, x24, x1
    74ec:	eb00403f 	cmp	x1, x0, lsl #16
    74f0:	54000282 	b.cs	7540 <f37+0x3f0>  // b.hs, b.nlast
    74f4:	d2800013 	mov	x19, #0x0                   	// #0
    74f8:	d2800017 	mov	x23, #0x0                   	// #0
    74fc:	17ffff69 	b	72a0 <f37+0x150>
    7500:	f949fc62 	ldr	x2, [x3, #5112]
    7504:	d350fc20 	lsr	x0, x1, #16
    7508:	8b000800 	add	x0, x0, x0, lsl #2
    750c:	8b000c42 	add	x2, x2, x0, lsl #3
    7510:	f9401040 	ldr	x0, [x2, #32]
    7514:	b4fffda0 	cbz	x0, 74c8 <f37+0x378>
    7518:	d2800017 	mov	x23, #0x0                   	// #0
    751c:	17ffff2a 	b	71c4 <f37+0x74>
    7520:	97fff4b9 	bl	4804 <fwp_rc_wide_dup>
    7524:	17ffff3e 	b	721c <f37+0xcc>
    7528:	aa1403e0 	mov	x0, x20
    752c:	97fff3a2 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7530:	17ffff73 	b	72fc <f37+0x1ac>
    7534:	aa1403e0 	mov	x0, x20
    7538:	97fff39f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    753c:	17ffffbe 	b	7434 <f37+0x2e4>
    7540:	d2800017 	mov	x23, #0x0                   	// #0
    7544:	17ffff82 	b	734c <f37+0x1fc>
    7548:	fd003be8 	str	d8, [sp, #112]
    754c:	97ffecd5 	bl	28a0 <__stack_chk_fail@plt>

0000000000007550 <fwp_owned_entry37>:
    7550:	f9400000 	ldr	x0, [x0]
    7554:	17fffeff 	b	7150 <f37>
    7558:	d503201f 	nop
    755c:	d503201f 	nop

0000000000007560 <e37>:
    7560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7564:	910003fd 	mov	x29, sp
    7568:	f9000bf3 	str	x19, [sp, #16]
    756c:	f9400013 	ldr	x19, [x0]
    7570:	aa1303e0 	mov	x0, x19
    7574:	97fff99f 	bl	5bf0 <fwp_rc_share>
    7578:	aa1303e0 	mov	x0, x19
    757c:	97fffef5 	bl	7150 <f37>
    7580:	aa0003f3 	mov	x19, x0
    7584:	97fff99b 	bl	5bf0 <fwp_rc_share>
    7588:	aa1303e0 	mov	x0, x19
    758c:	f9400bf3 	ldr	x19, [sp, #16]
    7590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7594:	d65f03c0 	ret
    7598:	d503201f 	nop
    759c:	d503201f 	nop

00000000000075a0 <fwp_args37>:
    75a0:	7100003f 	cmp	w1, #0x0
    75a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    75a8:	54000041 	b.ne	75b0 <fwp_args37+0x10>  // b.any
    75ac:	d65f03c0 	ret
    75b0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    75b4:	91188042 	add	x2, x2, #0x620
    75b8:	f9400001 	ldr	x1, [x0]
    75bc:	f949d843 	ldr	x3, [x2, #5040]
    75c0:	f949ec40 	ldr	x0, [x2, #5080]
    75c4:	cb030021 	sub	x1, x1, x3
    75c8:	eb00403f 	cmp	x1, x0, lsl #16
    75cc:	54ffff02 	b.cs	75ac <fwp_args37+0xc>  // b.hs, b.nlast
    75d0:	d350fc20 	lsr	x0, x1, #16
    75d4:	f949fc44 	ldr	x4, [x2, #5112]
    75d8:	8b000800 	add	x0, x0, x0, lsl #2
    75dc:	d37df002 	lsl	x2, x0, #3
    75e0:	8b020083 	add	x3, x4, x2
    75e4:	f9401060 	ldr	x0, [x3, #32]
    75e8:	b4fffe20 	cbz	x0, 75ac <fwp_args37+0xc>
    75ec:	38626882 	ldrb	w2, [x4, x2]
    75f0:	7100085f 	cmp	w2, #0x2
    75f4:	54000320 	b.eq	7658 <fwp_args37+0xb8>  // b.none
    75f8:	7100045f 	cmp	w2, #0x1
    75fc:	54fffd81 	b.ne	75ac <fwp_args37+0xc>  // b.any
    7600:	29430864 	ldp	w4, w2, [x3, #24]
    7604:	92403c21 	and	x1, x1, #0xffff
    7608:	9b047c21 	mul	x1, x1, x4
    760c:	d360fc21 	lsr	x1, x1, #32
    7610:	eb02003f 	cmp	x1, x2
    7614:	54fffcc2 	b.cs	75ac <fwp_args37+0xc>  // b.hs, b.nlast
    7618:	8b010000 	add	x0, x0, x1
    761c:	39400001 	ldrb	w1, [x0]
    7620:	34fffc61 	cbz	w1, 75ac <fwp_args37+0xc>
    7624:	b00000c2 	adrp	x2, 20000 <__data_start>
    7628:	91014042 	add	x2, x2, #0x50
    762c:	b9413043 	ldr	w3, [x2, #304]
    7630:	350000c3 	cbnz	w3, 7648 <fwp_args37+0xa8>
    7634:	7103f43f 	cmp	w1, #0xfd
    7638:	54000168 	b.hi	7664 <fwp_args37+0xc4>  // b.pmore
    763c:	11000421 	add	w1, w1, #0x1
    7640:	39000001 	strb	w1, [x0]
    7644:	d65f03c0 	ret
    7648:	f940ac43 	ldr	x3, [x2, #344]
    764c:	91000463 	add	x3, x3, #0x1
    7650:	f900ac43 	str	x3, [x2, #344]
    7654:	17fffff8 	b	7634 <fwp_args37+0x94>
    7658:	72003c3f 	tst	w1, #0xffff
    765c:	54fffe00 	b.eq	761c <fwp_args37+0x7c>  // b.none
    7660:	d65f03c0 	ret
    7664:	17fff468 	b	4804 <fwp_rc_wide_dup>
    7668:	d503201f 	nop
    766c:	d503201f 	nop

0000000000007670 <fwp_caps37>:
    7670:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7674:	910003fd 	mov	x29, sp
    7678:	f9000bf3 	str	x19, [sp, #16]
    767c:	aa0003f3 	mov	x19, x0
    7680:	b9400400 	ldr	w0, [x0, #4]
    7684:	340004a0 	cbz	w0, 7718 <fwp_caps37+0xa8>
    7688:	f9400660 	ldr	x0, [x19, #8]
    768c:	350004e1 	cbnz	w1, 7728 <fwp_caps37+0xb8>
    7690:	97fffc4c 	bl	67c0 <fwp_drop4>
    7694:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7698:	91188042 	add	x2, x2, #0x620
    769c:	f949d840 	ldr	x0, [x2, #5040]
    76a0:	f949ec41 	ldr	x1, [x2, #5080]
    76a4:	cb000260 	sub	x0, x19, x0
    76a8:	eb01401f 	cmp	x0, x1, lsl #16
    76ac:	54000382 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    76b0:	d350fc01 	lsr	x1, x0, #16
    76b4:	f949fc44 	ldr	x4, [x2, #5112]
    76b8:	8b010821 	add	x1, x1, x1, lsl #2
    76bc:	d37df021 	lsl	x1, x1, #3
    76c0:	8b010083 	add	x3, x4, x1
    76c4:	f9401062 	ldr	x2, [x3, #32]
    76c8:	b40002a2 	cbz	x2, 771c <fwp_caps37+0xac>
    76cc:	38616881 	ldrb	w1, [x4, x1]
    76d0:	7100083f 	cmp	w1, #0x2
    76d4:	54000740 	b.eq	77bc <fwp_caps37+0x14c>  // b.none
    76d8:	7100043f 	cmp	w1, #0x1
    76dc:	54000201 	b.ne	771c <fwp_caps37+0xac>  // b.any
    76e0:	29430464 	ldp	w4, w1, [x3, #24]
    76e4:	92403c00 	and	x0, x0, #0xffff
    76e8:	9b047c00 	mul	x0, x0, x4
    76ec:	d360fc00 	lsr	x0, x0, #32
    76f0:	eb01001f 	cmp	x0, x1
    76f4:	54000142 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    76f8:	8b000042 	add	x2, x2, x0
    76fc:	39400040 	ldrb	w0, [x2]
    7700:	7100041f 	cmp	w0, #0x1
    7704:	540000c1 	b.ne	771c <fwp_caps37+0xac>  // b.any
    7708:	aa1303e0 	mov	x0, x19
    770c:	f9400bf3 	ldr	x19, [sp, #16]
    7710:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7714:	17fff3c3 	b	4620 <fwp_mem_free>
    7718:	34fffbe1 	cbz	w1, 7694 <fwp_caps37+0x24>
    771c:	f9400bf3 	ldr	x19, [sp, #16]
    7720:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7724:	d65f03c0 	ret
    7728:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    772c:	91188042 	add	x2, x2, #0x620
    7730:	f949d843 	ldr	x3, [x2, #5040]
    7734:	f949ec41 	ldr	x1, [x2, #5080]
    7738:	cb030000 	sub	x0, x0, x3
    773c:	eb01401f 	cmp	x0, x1, lsl #16
    7740:	54fffee2 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    7744:	d350fc01 	lsr	x1, x0, #16
    7748:	f949fc44 	ldr	x4, [x2, #5112]
    774c:	8b010821 	add	x1, x1, x1, lsl #2
    7750:	d37df021 	lsl	x1, x1, #3
    7754:	8b010083 	add	x3, x4, x1
    7758:	f9401062 	ldr	x2, [x3, #32]
    775c:	b4fffe02 	cbz	x2, 771c <fwp_caps37+0xac>
    7760:	38616881 	ldrb	w1, [x4, x1]
    7764:	7100083f 	cmp	w1, #0x2
    7768:	54000300 	b.eq	77c8 <fwp_caps37+0x158>  // b.none
    776c:	7100043f 	cmp	w1, #0x1
    7770:	54fffd61 	b.ne	771c <fwp_caps37+0xac>  // b.any
    7774:	92403c01 	and	x1, x0, #0xffff
    7778:	29430064 	ldp	w4, w0, [x3, #24]
    777c:	9b047c21 	mul	x1, x1, x4
    7780:	d360fc21 	lsr	x1, x1, #32
    7784:	eb00003f 	cmp	x1, x0
    7788:	54fffca2 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    778c:	8b010042 	add	x2, x2, x1
    7790:	39400040 	ldrb	w0, [x2]
    7794:	34fffc40 	cbz	w0, 771c <fwp_caps37+0xac>
    7798:	b00000c1 	adrp	x1, 20000 <__data_start>
    779c:	91014021 	add	x1, x1, #0x50
    77a0:	b9413023 	ldr	w3, [x1, #304]
    77a4:	35000183 	cbnz	w3, 77d4 <fwp_caps37+0x164>
    77a8:	7103f41f 	cmp	w0, #0xfd
    77ac:	540001c8 	b.hi	77e4 <fwp_caps37+0x174>  // b.pmore
    77b0:	11000400 	add	w0, w0, #0x1
    77b4:	39000040 	strb	w0, [x2]
    77b8:	17ffffd9 	b	771c <fwp_caps37+0xac>
    77bc:	72003c1f 	tst	w0, #0xffff
    77c0:	54fffae1 	b.ne	771c <fwp_caps37+0xac>  // b.any
    77c4:	17ffffce 	b	76fc <fwp_caps37+0x8c>
    77c8:	72003c1f 	tst	w0, #0xffff
    77cc:	54fffa81 	b.ne	771c <fwp_caps37+0xac>  // b.any
    77d0:	17fffff0 	b	7790 <fwp_caps37+0x120>
    77d4:	f940ac23 	ldr	x3, [x1, #344]
    77d8:	91000463 	add	x3, x3, #0x1
    77dc:	f900ac23 	str	x3, [x1, #344]
    77e0:	17fffff2 	b	77a8 <fwp_caps37+0x138>
    77e4:	f9400bf3 	ldr	x19, [sp, #16]
    77e8:	aa0203e0 	mov	x0, x2
    77ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77f0:	17fff405 	b	4804 <fwp_rc_wide_dup>

00000000000077f4 <fwp_write>:
    77f4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    77f8:	910003fd 	mov	x29, sp
    77fc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7800:	f947f484 	ldr	x4, [x4, #4072]
    7804:	a90153f3 	stp	x19, x20, [sp, #16]
    7808:	d10943ff 	sub	sp, sp, #0x250
    780c:	b9400045 	ldr	w5, [x2]
    7810:	aa0003f4 	mov	x20, x0
    7814:	f9400080 	ldr	x0, [x4]
    7818:	f90127e0 	str	x0, [sp, #584]
    781c:	d2800000 	mov	x0, #0x0                   	// #0
    7820:	710064bf 	cmp	w5, #0x19
    7824:	54000408 	b.hi	78a4 <fwp_write+0xb0>  // b.pmore
    7828:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    782c:	aa0103f3 	mov	x19, x1
    7830:	91260000 	add	x0, x0, #0x980
    7834:	f9013bf5 	str	x21, [sp, #624]
    7838:	f9013ff6 	str	x22, [sp, #632]
    783c:	f90153fb 	str	x27, [sp, #672]
    7840:	f90157fc 	str	x28, [sp, #680]
    7844:	aa0203fc 	mov	x28, x2
    7848:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    784c:	10000061 	adr	x1, 7858 <fwp_write+0x64>
    7850:	8b20a820 	add	x0, x1, w0, sxth #2
    7854:	d61f0000 	br	x0
    7858:	910123e0 	add	x0, sp, #0x48
    785c:	aa1303e5 	mov	x5, x19
    7860:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x4f0>
    7864:	aa0003f3 	mov	x19, x0
    7868:	91056084 	add	x4, x4, #0x158
    786c:	d2804003 	mov	x3, #0x200                 	// #512
    7870:	aa0303e1 	mov	x1, x3
    7874:	52800042 	mov	w2, #0x2                   	// #2
    7878:	97ffebe6 	bl	2810 <__snprintf_chk@plt>
    787c:	aa1303e0 	mov	x0, x19
    7880:	97ffebac 	bl	2730 <strlen@plt>
    7884:	aa1303e1 	mov	x1, x19
    7888:	aa0003e2 	mov	x2, x0
    788c:	aa1403e0 	mov	x0, x20
    7890:	97ffef80 	bl	3690 <buf_put>
    7894:	f9413bf5 	ldr	x21, [sp, #624]
    7898:	f9413ff6 	ldr	x22, [sp, #632]
    789c:	f94153fb 	ldr	x27, [sp, #672]
    78a0:	f94157fc 	ldr	x28, [sp, #680]
    78a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    78a8:	f947f400 	ldr	x0, [x0, #4072]
    78ac:	f94127e2 	ldr	x2, [sp, #584]
    78b0:	f9400001 	ldr	x1, [x0]
    78b4:	eb010042 	subs	x2, x2, x1
    78b8:	d2800001 	mov	x1, #0x0                   	// #0
    78bc:	540077a1 	b.ne	87b0 <fwp_write+0xfbc>  // b.any
    78c0:	910943ff 	add	sp, sp, #0x250
    78c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    78c8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    78cc:	d65f03c0 	ret
    78d0:	910123e0 	add	x0, sp, #0x48
    78d4:	aa1303e5 	mov	x5, x19
    78d8:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x4f0>
    78dc:	aa0003f3 	mov	x19, x0
    78e0:	91054084 	add	x4, x4, #0x150
    78e4:	d2804003 	mov	x3, #0x200                 	// #512
    78e8:	17ffffe2 	b	7870 <fwp_write+0x7c>
    78ec:	71004cbf 	cmp	w5, #0x13
    78f0:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    78f4:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    78f8:	91050000 	add	x0, x0, #0x140
    78fc:	91052021 	add	x1, x1, #0x148
    7900:	d2800082 	mov	x2, #0x4                   	// #4
    7904:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7908:	aa1403e0 	mov	x0, x20
    790c:	f90143f7 	str	x23, [sp, #640]
    7910:	d2800016 	mov	x22, #0x0                   	// #0
    7914:	f90147f8 	str	x24, [sp, #648]
    7918:	97ffef5e 	bl	3690 <buf_put>
    791c:	f9400260 	ldr	x0, [x19]
    7920:	f0000017 	adrp	x23, a000 <_IO_stdin_used+0x4f0>
    7924:	d2800015 	mov	x21, #0x0                   	// #0
    7928:	910722f7 	add	x23, x23, #0x1c8
    792c:	b4004780 	cbz	x0, 821c <fwp_write+0xa28>
    7930:	b9400380 	ldr	w0, [x28]
    7934:	52800003 	mov	w3, #0x0                   	// #0
    7938:	f9401f82 	ldr	x2, [x28, #56]
    793c:	71004c1f 	cmp	w0, #0x13
    7940:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7944:	aa1403e0 	mov	x0, x20
    7948:	8b010e61 	add	x1, x19, x1, lsl #3
    794c:	f9400421 	ldr	x1, [x1, #8]
    7950:	97ffffa9 	bl	77f4 <fwp_write>
    7954:	b9400380 	ldr	w0, [x28]
    7958:	7100481f 	cmp	w0, #0x12
    795c:	54004b20 	b.eq	82c0 <fwp_write+0xacc>  // b.none
    7960:	f9400260 	ldr	x0, [x19]
    7964:	910006b5 	add	x21, x21, #0x1
    7968:	91000ad6 	add	x22, x22, #0x2
    796c:	eb15001f 	cmp	x0, x21
    7970:	54004569 	b.ls	821c <fwp_write+0xa28>  // b.plast
    7974:	aa1703e1 	mov	x1, x23
    7978:	aa1403e0 	mov	x0, x20
    797c:	d2800042 	mov	x2, #0x2                   	// #2
    7980:	97ffef44 	bl	3690 <buf_put>
    7984:	17ffffeb 	b	7930 <fwp_write+0x13c>
    7988:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    798c:	91060021 	add	x1, x1, #0x180
    7990:	d28000c2 	mov	x2, #0x6                   	// #6
    7994:	aa1403e0 	mov	x0, x20
    7998:	91004273 	add	x19, x19, #0x10
    799c:	97ffef3d 	bl	3690 <buf_put>
    79a0:	aa1303e0 	mov	x0, x19
    79a4:	97ffeb63 	bl	2730 <strlen@plt>
    79a8:	aa1303e1 	mov	x1, x19
    79ac:	aa0003e2 	mov	x2, x0
    79b0:	aa1403e0 	mov	x0, x20
    79b4:	97ffef37 	bl	3690 <buf_put>
    79b8:	528007c3 	mov	w3, #0x3e                  	// #62
    79bc:	aa1403e0 	mov	x0, x20
    79c0:	91001fe1 	add	x1, sp, #0x7
    79c4:	d2800022 	mov	x2, #0x1                   	// #1
    79c8:	39001fe3 	strb	w3, [sp, #7]
    79cc:	17ffffb1 	b	7890 <fwp_write+0x9c>
    79d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    79d4:	f947f400 	ldr	x0, [x0, #4072]
    79d8:	f94127e2 	ldr	x2, [sp, #584]
    79dc:	f9400001 	ldr	x1, [x0]
    79e0:	eb010042 	subs	x2, x2, x1
    79e4:	d2800001 	mov	x1, #0x0                   	// #0
    79e8:	540034c1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    79ec:	f9413bf5 	ldr	x21, [sp, #624]
    79f0:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    79f4:	f9413ff6 	ldr	x22, [sp, #632]
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	91058021 	add	x1, x1, #0x160
    7a00:	d2800142 	mov	x2, #0xa                   	// #10
    7a04:	f94153fb 	ldr	x27, [sp, #672]
    7a08:	f94157fc 	ldr	x28, [sp, #680]
    7a0c:	910943ff 	add	sp, sp, #0x250
    7a10:	a94153f3 	ldp	x19, x20, [sp, #16]
    7a14:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7a18:	17ffef1e 	b	3690 <buf_put>
    7a1c:	f9400456 	ldr	x22, [x2, #8]
    7a20:	f90143f7 	str	x23, [sp, #640]
    7a24:	f90147f8 	str	x24, [sp, #648]
    7a28:	b4005af6 	cbz	x22, 8584 <fwp_write+0xd90>
    7a2c:	aa1603e0 	mov	x0, x22
    7a30:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    7a34:	91078021 	add	x1, x1, #0x1e0
    7a38:	97ffebba 	bl	2920 <strcmp@plt>
    7a3c:	2a0003f5 	mov	w21, w0
    7a40:	34005fc0 	cbz	w0, 8638 <fwp_write+0xe44>
    7a44:	aa1603e0 	mov	x0, x22
    7a48:	97ffeb3a 	bl	2730 <strlen@plt>
    7a4c:	aa1603e1 	mov	x1, x22
    7a50:	aa0003e2 	mov	x2, x0
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	97ffef0e 	bl	3690 <buf_put>
    7a5c:	52800403 	mov	w3, #0x20                  	// #32
    7a60:	91001ff5 	add	x21, sp, #0x7
    7a64:	aa1503e1 	mov	x1, x21
    7a68:	aa1403e0 	mov	x0, x20
    7a6c:	d2800022 	mov	x2, #0x1                   	// #1
    7a70:	39001fe3 	strb	w3, [sp, #7]
    7a74:	97ffef07 	bl	3690 <buf_put>
    7a78:	52800f63 	mov	w3, #0x7b                  	// #123
    7a7c:	aa1403e0 	mov	x0, x20
    7a80:	aa1503e1 	mov	x1, x21
    7a84:	d2800022 	mov	x2, #0x1                   	// #1
    7a88:	39001fe3 	strb	w3, [sp, #7]
    7a8c:	97ffef01 	bl	3690 <buf_put>
    7a90:	b9401380 	ldr	w0, [x28, #16]
    7a94:	52800018 	mov	w24, #0x0                   	// #0
    7a98:	7100001f 	cmp	w0, #0x0
    7a9c:	54003a8d 	b.le	81ec <fwp_write+0x9f8>
    7aa0:	f9014bf9 	str	x25, [sp, #656]
    7aa4:	f0000019 	adrp	x25, a000 <_IO_stdin_used+0x4f0>
    7aa8:	91082339 	add	x25, x25, #0x208
    7aac:	f9014ffa 	str	x26, [sp, #664]
    7ab0:	f000001a 	adrp	x26, a000 <_IO_stdin_used+0x4f0>
    7ab4:	9107235a 	add	x26, x26, #0x1c8
    7ab8:	91002276 	add	x22, x19, #0x8
    7abc:	d2800013 	mov	x19, #0x0                   	// #0
    7ac0:	b5003e73 	cbnz	x19, 828c <fwp_write+0xa98>
    7ac4:	d37df277 	lsl	x23, x19, #3
    7ac8:	34003c98 	cbz	w24, 8258 <fwp_write+0xa64>
    7acc:	f9401382 	ldr	x2, [x28, #32]
    7ad0:	aa1403e0 	mov	x0, x20
    7ad4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7ad8:	52800003 	mov	w3, #0x0                   	// #0
    7adc:	f8776842 	ldr	x2, [x2, x23]
    7ae0:	91000673 	add	x19, x19, #0x1
    7ae4:	97ffff44 	bl	77f4 <fwp_write>
    7ae8:	b9401380 	ldr	w0, [x28, #16]
    7aec:	6b13001f 	cmp	w0, w19
    7af0:	54fffe8c 	b.gt	7ac0 <fwp_write+0x2cc>
    7af4:	f9414bf9 	ldr	x25, [sp, #656]
    7af8:	f9414ffa 	ldr	x26, [sp, #664]
    7afc:	34003798 	cbz	w24, 81ec <fwp_write+0x9f8>
    7b00:	52800523 	mov	w3, #0x29                  	// #41
    7b04:	aa1503e1 	mov	x1, x21
    7b08:	aa1403e0 	mov	x0, x20
    7b0c:	d2800022 	mov	x2, #0x1                   	// #1
    7b10:	39001fe3 	strb	w3, [sp, #7]
    7b14:	97ffeedf 	bl	3690 <buf_put>
    7b18:	f9413bf5 	ldr	x21, [sp, #624]
    7b1c:	f9413ff6 	ldr	x22, [sp, #632]
    7b20:	f94143f7 	ldr	x23, [sp, #640]
    7b24:	f94147f8 	ldr	x24, [sp, #648]
    7b28:	f94153fb 	ldr	x27, [sp, #672]
    7b2c:	f94157fc 	ldr	x28, [sp, #680]
    7b30:	17ffff5d 	b	78a4 <fwp_write+0xb0>
    7b34:	b9404855 	ldr	w21, [x2, #72]
    7b38:	aa1403e0 	mov	x0, x20
    7b3c:	93407eb6 	sxtw	x22, w21
    7b40:	91000ac1 	add	x1, x22, #0x2
    7b44:	97ffee9f 	bl	35c0 <buf_grow>
    7b48:	a9400281 	ldp	x1, x0, [x20]
    7b4c:	528e8603 	mov	w3, #0x7430                	// #29744
    7b50:	78206823 	strh	w3, [x1, x0]
    7b54:	8b000022 	add	x2, x1, x0
    7b58:	710002bf 	cmp	w21, #0x0
    7b5c:	540036ad 	b.le	8230 <fwp_write+0xa3c>
    7b60:	110006a3 	add	w3, w21, #0x1
    7b64:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7b68:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7b6c:	91000449 	add	x9, x2, #0x1
    7b70:	8b23c043 	add	x3, x2, w3, sxtw
    7b74:	f28aaac6 	movk	x6, #0x5556
    7b78:	f2955568 	movk	x8, #0xaaab
    7b7c:	1400000d 	b	7bb0 <fwp_write+0x3bc>
    7b80:	d2800021 	mov	x1, #0x1                   	// #1
    7b84:	528005a5 	mov	w5, #0x2d                  	// #45
    7b88:	f100001f 	cmp	x0, #0x0
    7b8c:	9b467e60 	smulh	x0, x19, x6
    7b90:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7b94:	381ff465 	strb	w5, [x3], #-1
    7b98:	cb040000 	sub	x0, x0, x4
    7b9c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7ba0:	cb020000 	sub	x0, x0, x2
    7ba4:	8b010013 	add	x19, x0, x1
    7ba8:	eb03013f 	cmp	x9, x3
    7bac:	54003420 	b.eq	8230 <fwp_write+0xa3c>  // b.none
    7bb0:	9b467e60 	smulh	x0, x19, x6
    7bb4:	937ffe64 	asr	x4, x19, #63
    7bb8:	52800605 	mov	w5, #0x30                  	// #48
    7bbc:	cb040000 	sub	x0, x0, x4
    7bc0:	8b000400 	add	x0, x0, x0, lsl #1
    7bc4:	cb000260 	sub	x0, x19, x0
    7bc8:	91000c01 	add	x1, x0, #0x3
    7bcc:	9bc87c22 	umulh	x2, x1, x8
    7bd0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7bd4:	8b4204e2 	add	x2, x7, x2, lsr #1
    7bd8:	eb020021 	subs	x1, x1, x2
    7bdc:	54fffd60 	b.eq	7b88 <fwp_write+0x394>  // b.none
    7be0:	f100043f 	cmp	x1, #0x1
    7be4:	54fffce1 	b.ne	7b80 <fwp_write+0x38c>  // b.any
    7be8:	d2800001 	mov	x1, #0x0                   	// #0
    7bec:	52800565 	mov	w5, #0x2b                  	// #43
    7bf0:	17ffffe6 	b	7b88 <fwp_write+0x394>
    7bf4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7bf8:	f947f400 	ldr	x0, [x0, #4072]
    7bfc:	f94127e2 	ldr	x2, [sp, #584]
    7c00:	f9400001 	ldr	x1, [x0]
    7c04:	eb010042 	subs	x2, x2, x1
    7c08:	d2800001 	mov	x1, #0x0                   	// #0
    7c0c:	540023a1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    7c10:	f9413bf5 	ldr	x21, [sp, #624]
    7c14:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    7c18:	f9413ff6 	ldr	x22, [sp, #632]
    7c1c:	aa1403e0 	mov	x0, x20
    7c20:	9105c021 	add	x1, x1, #0x170
    7c24:	d2800102 	mov	x2, #0x8                   	// #8
    7c28:	17ffff77 	b	7a04 <fwp_write+0x210>
    7c2c:	aa1403e0 	mov	x0, x20
    7c30:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    7c34:	d28000c2 	mov	x2, #0x6                   	// #6
    7c38:	91074021 	add	x1, x1, #0x1d0
    7c3c:	97ffee95 	bl	3690 <buf_put>
    7c40:	d2800015 	mov	x21, #0x0                   	// #0
    7c44:	f9400263 	ldr	x3, [x19]
    7c48:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7c4c:	54002c40 	b.eq	81d4 <fwp_write+0x9e0>  // b.none
    7c50:	f9401f82 	ldr	x2, [x28, #56]
    7c54:	f90143f7 	str	x23, [sp, #640]
    7c58:	f90147f8 	str	x24, [sp, #648]
    7c5c:	d2800857 	mov	x23, #0x42                  	// #66
    7c60:	f9014bf9 	str	x25, [sp, #656]
    7c64:	f0000016 	adrp	x22, a000 <_IO_stdin_used+0x4f0>
    7c68:	f9014ffa 	str	x26, [sp, #664]
    7c6c:	910722d6 	add	x22, x22, #0x1c8
    7c70:	d2800038 	mov	x24, #0x1                   	// #1
    7c74:	f2a18017 	movk	x23, #0xc00, lsl #16
    7c78:	d2809099 	mov	x25, #0x484                 	// #1156
    7c7c:	b4000482 	cbz	x2, 7d0c <fwp_write+0x518>
    7c80:	b9400040 	ldr	w0, [x2]
    7c84:	7100701f 	cmp	w0, #0x1c
    7c88:	540042a0 	b.eq	84dc <fwp_write+0xce8>  // b.none
    7c8c:	71006c1f 	cmp	w0, #0x1b
    7c90:	540003e8 	b.hi	7d0c <fwp_write+0x518>  // b.pmore
    7c94:	9ac02301 	lsl	x1, x24, x0
    7c98:	ea17003f 	tst	x1, x23
    7c9c:	54003681 	b.ne	836c <fwp_write+0xb78>  // b.any
    7ca0:	ea19003f 	tst	x1, x25
    7ca4:	54003501 	b.ne	8344 <fwp_write+0xb50>  // b.any
    7ca8:	d2800424 	mov	x4, #0x21                  	// #33
    7cac:	ea04003f 	tst	x1, x4
    7cb0:	540002e0 	b.eq	7d0c <fwp_write+0x518>  // b.none
    7cb4:	b7f849a3 	tbnz	x3, #63, 85e8 <fwp_write+0xdf4>
    7cb8:	91002261 	add	x1, x19, #0x8
    7cbc:	8b150021 	add	x1, x1, x21
    7cc0:	39400021 	ldrb	w1, [x1]
    7cc4:	7100001f 	cmp	w0, #0x0
    7cc8:	93401c23 	sxtb	x3, w1
    7ccc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7cd0:	aa1403e0 	mov	x0, x20
    7cd4:	52800003 	mov	w3, #0x0                   	// #0
    7cd8:	97fffec7 	bl	77f4 <fwp_write>
    7cdc:	910006b5 	add	x21, x21, #0x1
    7ce0:	f9400260 	ldr	x0, [x19]
    7ce4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7ce8:	eb0002bf 	cmp	x21, x0
    7cec:	540026c2 	b.cs	81c4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7cf0:	d2800042 	mov	x2, #0x2                   	// #2
    7cf4:	aa1603e1 	mov	x1, x22
    7cf8:	aa1403e0 	mov	x0, x20
    7cfc:	97ffee65 	bl	3690 <buf_put>
    7d00:	f9401f82 	ldr	x2, [x28, #56]
    7d04:	f9400263 	ldr	x3, [x19]
    7d08:	b5fffbc2 	cbnz	x2, 7c80 <fwp_write+0x48c>
    7d0c:	d37df2a0 	lsl	x0, x21, #3
    7d10:	b7f83f03 	tbnz	x3, #63, 84f0 <fwp_write+0xcfc>
    7d14:	91002261 	add	x1, x19, #0x8
    7d18:	8b000020 	add	x0, x1, x0
    7d1c:	f9400001 	ldr	x1, [x0]
    7d20:	17ffffec 	b	7cd0 <fwp_write+0x4dc>
    7d24:	a9400e62 	ldp	x2, x3, [x19]
    7d28:	b7f83ca3 	tbnz	x3, #63, 84bc <fwp_write+0xcc8>
    7d2c:	910123f5 	add	x21, sp, #0x48
    7d30:	aa1503e0 	mov	x0, x21
    7d34:	97ffec3b 	bl	2e20 <fwp_fmt_u128>
    7d38:	aa1503e0 	mov	x0, x21
    7d3c:	97ffea7d 	bl	2730 <strlen@plt>
    7d40:	aa1503e1 	mov	x1, x21
    7d44:	aa0003e2 	mov	x2, x0
    7d48:	17fffed1 	b	788c <fwp_write+0x98>
    7d4c:	fd015be8 	str	d8, [sp, #688]
    7d50:	1e270268 	fmov	s8, w19
    7d54:	fd015fe9 	str	d9, [sp, #696]
    7d58:	1e282100 	fcmp	s8, s8
    7d5c:	54004d26 	b.vs	8700 <fwp_write+0xf0c>
    7d60:	1e20c101 	fabs	s1, s8
    7d64:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7d68:	1e270000 	fmov	s0, w0
    7d6c:	1e202020 	fcmp	s1, s0
    7d70:	54002c0d 	b.le	82f0 <fwp_write+0xafc>
    7d74:	1e202118 	fcmpe	s8, #0.0
    7d78:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x820>
    7d7c:	91322042 	add	x2, x2, #0xc88
    7d80:	910123f5 	add	x21, sp, #0x48
    7d84:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    7d88:	91048021 	add	x1, x1, #0x120
    7d8c:	aa1503e0 	mov	x0, x21
    7d90:	9a81c041 	csel	x1, x2, x1, gt
    7d94:	97ffeb13 	bl	29e0 <strcpy@plt>
    7d98:	aa1503e0 	mov	x0, x21
    7d9c:	97ffea65 	bl	2730 <strlen@plt>
    7da0:	aa1503e1 	mov	x1, x21
    7da4:	aa0003e2 	mov	x2, x0
    7da8:	aa1403e0 	mov	x0, x20
    7dac:	97ffee39 	bl	3690 <buf_put>
    7db0:	f9413bf5 	ldr	x21, [sp, #624]
    7db4:	f9413ff6 	ldr	x22, [sp, #632]
    7db8:	f94153fb 	ldr	x27, [sp, #672]
    7dbc:	f94157fc 	ldr	x28, [sp, #680]
    7dc0:	fd415be8 	ldr	d8, [sp, #688]
    7dc4:	fd415fe9 	ldr	d9, [sp, #696]
    7dc8:	17fffeb7 	b	78a4 <fwp_write+0xb0>
    7dcc:	f9400276 	ldr	x22, [x19]
    7dd0:	34002e03 	cbz	w3, 8390 <fwp_write+0xb9c>
    7dd4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7dd8:	f947f400 	ldr	x0, [x0, #4072]
    7ddc:	f94127e2 	ldr	x2, [sp, #584]
    7de0:	f9400001 	ldr	x1, [x0]
    7de4:	eb010042 	subs	x2, x2, x1
    7de8:	d2800001 	mov	x1, #0x0                   	// #0
    7dec:	540014a1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    7df0:	aa1603e2 	mov	x2, x22
    7df4:	91002261 	add	x1, x19, #0x8
    7df8:	f9413bf5 	ldr	x21, [sp, #624]
    7dfc:	aa1403e0 	mov	x0, x20
    7e00:	f9413ff6 	ldr	x22, [sp, #632]
    7e04:	17ffff00 	b	7a04 <fwp_write+0x210>
    7e08:	fd015be8 	str	d8, [sp, #688]
    7e0c:	9e670268 	fmov	d8, x19
    7e10:	fd015fe9 	str	d9, [sp, #696]
    7e14:	1e682100 	fcmp	d8, d8
    7e18:	54004746 	b.vs	8700 <fwp_write+0xf0c>
    7e1c:	1e60c101 	fabs	d1, d8
    7e20:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7e24:	9e670000 	fmov	d0, x0
    7e28:	910123f5 	add	x21, sp, #0x48
    7e2c:	52800033 	mov	w19, #0x1                   	// #1
    7e30:	1e602020 	fcmp	d1, d0
    7e34:	540001ad 	b.le	7e68 <fwp_write+0x674>
    7e38:	1e602118 	fcmpe	d8, #0.0
    7e3c:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x820>
    7e40:	91322042 	add	x2, x2, #0xc88
    7e44:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    7e48:	91048021 	add	x1, x1, #0x120
    7e4c:	aa1503e0 	mov	x0, x21
    7e50:	9a81c041 	csel	x1, x2, x1, gt
    7e54:	97ffeae3 	bl	29e0 <strcpy@plt>
    7e58:	17ffffd0 	b	7d98 <fwp_write+0x5a4>
    7e5c:	11000673 	add	w19, w19, #0x1
    7e60:	71004a7f 	cmp	w19, #0x12
    7e64:	54003860 	b.eq	8570 <fwp_write+0xd7c>  // b.none
    7e68:	1e604100 	fmov	d0, d8
    7e6c:	2a1303e1 	mov	w1, w19
    7e70:	aa1503e0 	mov	x0, x21
    7e74:	97ffee63 	bl	3800 <fwp_format_g.constprop.0>
    7e78:	aa1503e0 	mov	x0, x21
    7e7c:	d2800001 	mov	x1, #0x0                   	// #0
    7e80:	97ffea40 	bl	2780 <strtod@plt>
    7e84:	1e602100 	fcmp	d8, d0
    7e88:	54fffea1 	b.ne	7e5c <fwp_write+0x668>  // b.any
    7e8c:	aa1503e0 	mov	x0, x21
    7e90:	97ffee39 	bl	3774 <fwp_finish_float>
    7e94:	17ffffc1 	b	7d98 <fwp_write+0x5a4>
    7e98:	a9400e62 	ldp	x2, x3, [x19]
    7e9c:	910123f3 	add	x19, sp, #0x48
    7ea0:	aa1303e0 	mov	x0, x19
    7ea4:	97ffebdf 	bl	2e20 <fwp_fmt_u128>
    7ea8:	17fffe75 	b	787c <fwp_write+0x88>
    7eac:	f90143f7 	str	x23, [sp, #640]
    7eb0:	f90147f8 	str	x24, [sp, #648]
    7eb4:	2a1303f8 	mov	w24, w19
    7eb8:	f9014bf9 	str	x25, [sp, #656]
    7ebc:	f9014ffa 	str	x26, [sp, #664]
    7ec0:	f13ffe7f 	cmp	x19, #0xfff
    7ec4:	54000049 	b.ls	7ecc <fwp_write+0x6d8>  // b.plast
    7ec8:	b9400278 	ldr	w24, [x19]
    7ecc:	f9400f80 	ldr	x0, [x28, #24]
    7ed0:	2a1803f5 	mov	w21, w24
    7ed4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7ed8:	d37ef6b9 	lsl	x25, x21, #2
    7edc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ee0:	aa1603e0 	mov	x0, x22
    7ee4:	97ffea13 	bl	2730 <strlen@plt>
    7ee8:	aa1603e1 	mov	x1, x22
    7eec:	aa0003e2 	mov	x2, x0
    7ef0:	aa1403e0 	mov	x0, x20
    7ef4:	97ffede7 	bl	3690 <buf_put>
    7ef8:	f9401780 	ldr	x0, [x28, #40]
    7efc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7f00:	7100001f 	cmp	w0, #0x0
    7f04:	5400068d 	b.le	7fd4 <fwp_write+0x7e0>
    7f08:	91002276 	add	x22, x19, #0x8
    7f0c:	91001ff5 	add	x21, sp, #0x7
    7f10:	d280001b 	mov	x27, #0x0                   	// #0
    7f14:	5280041a 	mov	w26, #0x20                  	// #32
    7f18:	f9401b80 	ldr	x0, [x28, #48]
    7f1c:	aa1503e1 	mov	x1, x21
    7f20:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7f24:	d2800022 	mov	x2, #0x1                   	// #1
    7f28:	f8786803 	ldr	x3, [x0, x24]
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7f34:	39001ffa 	strb	w26, [sp, #7]
    7f38:	97ffedd6 	bl	3690 <buf_put>
    7f3c:	f13ffeff 	cmp	x23, #0xfff
    7f40:	b9400261 	ldr	w1, [x19]
    7f44:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7f48:	7100383f 	cmp	w1, #0xe
    7f4c:	54000160 	b.eq	7f78 <fwp_write+0x784>  // b.none
    7f50:	7100403f 	cmp	w1, #0x10
    7f54:	54001a60 	b.eq	82a0 <fwp_write+0xaac>  // b.none
    7f58:	7100283f 	cmp	w1, #0xa
    7f5c:	54002aa0 	b.eq	84b0 <fwp_write+0xcbc>  // b.none
    7f60:	540014ac 	b.gt	81f4 <fwp_write+0xa00>
    7f64:	71000c3f 	cmp	w1, #0x3
    7f68:	540029ac 	b.gt	849c <fwp_write+0xca8>
    7f6c:	d37ffee0 	lsr	x0, x23, #63
    7f70:	37f814a1 	tbnz	w1, #31, 8204 <fwp_write+0xa10>
    7f74:	d503201f 	nop
    7f78:	34001460 	cbz	w0, 8204 <fwp_write+0xa10>
    7f7c:	52800503 	mov	w3, #0x28                  	// #40
    7f80:	aa1503e1 	mov	x1, x21
    7f84:	aa1403e0 	mov	x0, x20
    7f88:	d2800022 	mov	x2, #0x1                   	// #1
    7f8c:	39001fe3 	strb	w3, [sp, #7]
    7f90:	97ffedc0 	bl	3690 <buf_put>
    7f94:	aa1303e2 	mov	x2, x19
    7f98:	aa1703e1 	mov	x1, x23
    7f9c:	aa1403e0 	mov	x0, x20
    7fa0:	52800003 	mov	w3, #0x0                   	// #0
    7fa4:	97fffe14 	bl	77f4 <fwp_write>
    7fa8:	52800523 	mov	w3, #0x29                  	// #41
    7fac:	aa1503e1 	mov	x1, x21
    7fb0:	aa1403e0 	mov	x0, x20
    7fb4:	d2800022 	mov	x2, #0x1                   	// #1
    7fb8:	39001fe3 	strb	w3, [sp, #7]
    7fbc:	97ffedb5 	bl	3690 <buf_put>
    7fc0:	f9401780 	ldr	x0, [x28, #40]
    7fc4:	9100077b 	add	x27, x27, #0x1
    7fc8:	b8796800 	ldr	w0, [x0, x25]
    7fcc:	6b1b001f 	cmp	w0, w27
    7fd0:	54fffa4c 	b.gt	7f18 <fwp_write+0x724>
    7fd4:	f9413bf5 	ldr	x21, [sp, #624]
    7fd8:	f9413ff6 	ldr	x22, [sp, #632]
    7fdc:	f94143f7 	ldr	x23, [sp, #640]
    7fe0:	f94147f8 	ldr	x24, [sp, #648]
    7fe4:	f9414bf9 	ldr	x25, [sp, #656]
    7fe8:	f9414ffa 	ldr	x26, [sp, #664]
    7fec:	f94153fb 	ldr	x27, [sp, #672]
    7ff0:	f94157fc 	ldr	x28, [sp, #680]
    7ff4:	17fffe2c 	b	78a4 <fwp_write+0xb0>
    7ff8:	52800783 	mov	w3, #0x3c                  	// #60
    7ffc:	91001ff3 	add	x19, sp, #0x7
    8000:	aa1303e1 	mov	x1, x19
    8004:	d2800022 	mov	x2, #0x1                   	// #1
    8008:	aa1403e0 	mov	x0, x20
    800c:	39001fe3 	strb	w3, [sp, #7]
    8010:	97ffeda0 	bl	3690 <buf_put>
    8014:	f9400795 	ldr	x21, [x28, #8]
    8018:	aa1503e0 	mov	x0, x21
    801c:	97ffe9c5 	bl	2730 <strlen@plt>
    8020:	aa1503e1 	mov	x1, x21
    8024:	aa0003e2 	mov	x2, x0
    8028:	aa1403e0 	mov	x0, x20
    802c:	97ffed99 	bl	3690 <buf_put>
    8030:	528007c3 	mov	w3, #0x3e                  	// #62
    8034:	aa1303e1 	mov	x1, x19
    8038:	aa1403e0 	mov	x0, x20
    803c:	d2800022 	mov	x2, #0x1                   	// #1
    8040:	39001fe3 	strb	w3, [sp, #7]
    8044:	17fffe13 	b	7890 <fwp_write+0x9c>
    8048:	f100067f 	cmp	x19, #0x1
    804c:	540025a0 	b.eq	8500 <fwp_write+0xd0c>  // b.none
    8050:	b100067f 	cmn	x19, #0x1
    8054:	54002bc0 	b.eq	85cc <fwp_write+0xdd8>  // b.none
    8058:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    805c:	9104a021 	add	x1, x1, #0x128
    8060:	d2800022 	mov	x2, #0x1                   	// #1
    8064:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8068:	f947f400 	ldr	x0, [x0, #4072]
    806c:	f94127e4 	ldr	x4, [sp, #584]
    8070:	f9400003 	ldr	x3, [x0]
    8074:	eb030084 	subs	x4, x4, x3
    8078:	d2800003 	mov	x3, #0x0                   	// #0
    807c:	54ffebe0 	b.eq	7df8 <fwp_write+0x604>  // b.none
    8080:	f90143f7 	str	x23, [sp, #640]
    8084:	f90147f8 	str	x24, [sp, #648]
    8088:	f9014bf9 	str	x25, [sp, #656]
    808c:	f9014ffa 	str	x26, [sp, #664]
    8090:	fd015be8 	str	d8, [sp, #688]
    8094:	fd015fe9 	str	d9, [sp, #696]
    8098:	97ffea02 	bl	28a0 <__stack_chk_fail@plt>
    809c:	52800b63 	mov	w3, #0x5b                  	// #91
    80a0:	91001ff5 	add	x21, sp, #0x7
    80a4:	aa1503e1 	mov	x1, x21
    80a8:	aa1403e0 	mov	x0, x20
    80ac:	d2800022 	mov	x2, #0x1                   	// #1
    80b0:	d0000016 	adrp	x22, a000 <_IO_stdin_used+0x4f0>
    80b4:	910722d6 	add	x22, x22, #0x1c8
    80b8:	39001fe3 	strb	w3, [sp, #7]
    80bc:	97ffed75 	bl	3690 <buf_put>
    80c0:	b4000273 	cbz	x19, 810c <fwp_write+0x918>
    80c4:	f9400661 	ldr	x1, [x19, #8]
    80c8:	aa1403e0 	mov	x0, x20
    80cc:	f9401f82 	ldr	x2, [x28, #56]
    80d0:	52800003 	mov	w3, #0x0                   	// #0
    80d4:	97fffdc8 	bl	77f4 <fwp_write>
    80d8:	f9400a73 	ldr	x19, [x19, #16]
    80dc:	b4000193 	cbz	x19, 810c <fwp_write+0x918>
    80e0:	aa1603e1 	mov	x1, x22
    80e4:	aa1403e0 	mov	x0, x20
    80e8:	d2800042 	mov	x2, #0x2                   	// #2
    80ec:	97ffed69 	bl	3690 <buf_put>
    80f0:	f9400661 	ldr	x1, [x19, #8]
    80f4:	aa1403e0 	mov	x0, x20
    80f8:	f9401f82 	ldr	x2, [x28, #56]
    80fc:	52800003 	mov	w3, #0x0                   	// #0
    8100:	97fffdbd 	bl	77f4 <fwp_write>
    8104:	f9400a73 	ldr	x19, [x19, #16]
    8108:	b5fffed3 	cbnz	x19, 80e0 <fwp_write+0x8ec>
    810c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8110:	aa1503e1 	mov	x1, x21
    8114:	aa1403e0 	mov	x0, x20
    8118:	d2800022 	mov	x2, #0x1                   	// #1
    811c:	39001fe3 	strb	w3, [sp, #7]
    8120:	17fffddc 	b	7890 <fwp_write+0x9c>
    8124:	aa1403e0 	mov	x0, x20
    8128:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    812c:	d28000c2 	mov	x2, #0x6                   	// #6
    8130:	9106e021 	add	x1, x1, #0x1b8
    8134:	97ffed57 	bl	3690 <buf_put>
    8138:	f9400260 	ldr	x0, [x19]
    813c:	b40004c0 	cbz	x0, 81d4 <fwp_write+0x9e0>
    8140:	910123f5 	add	x21, sp, #0x48
    8144:	91002276 	add	x22, x19, #0x8
    8148:	f90143f7 	str	x23, [sp, #640]
    814c:	d2800017 	mov	x23, #0x0                   	// #0
    8150:	f90147f8 	str	x24, [sp, #648]
    8154:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x4f0>
    8158:	91070318 	add	x24, x24, #0x1c0
    815c:	f9014bf9 	str	x25, [sp, #656]
    8160:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x4f0>
    8164:	91072339 	add	x25, x25, #0x1c8
    8168:	f9014ffa 	str	x26, [sp, #664]
    816c:	14000005 	b	8180 <fwp_write+0x98c>
    8170:	aa1903e1 	mov	x1, x25
    8174:	aa1403e0 	mov	x0, x20
    8178:	d2800042 	mov	x2, #0x2                   	// #2
    817c:	97ffed45 	bl	3690 <buf_put>
    8180:	38776ac5 	ldrb	w5, [x22, x23]
    8184:	d2804003 	mov	x3, #0x200                 	// #512
    8188:	aa1803e4 	mov	x4, x24
    818c:	aa0303e1 	mov	x1, x3
    8190:	52800042 	mov	w2, #0x2                   	// #2
    8194:	aa1503e0 	mov	x0, x21
    8198:	910006f7 	add	x23, x23, #0x1
    819c:	97ffe99d 	bl	2810 <__snprintf_chk@plt>
    81a0:	aa1503e0 	mov	x0, x21
    81a4:	97ffe963 	bl	2730 <strlen@plt>
    81a8:	aa1503e1 	mov	x1, x21
    81ac:	aa0003e2 	mov	x2, x0
    81b0:	aa1403e0 	mov	x0, x20
    81b4:	97ffed37 	bl	3690 <buf_put>
    81b8:	f9400260 	ldr	x0, [x19]
    81bc:	eb17001f 	cmp	x0, x23
    81c0:	54fffd88 	b.hi	8170 <fwp_write+0x97c>  // b.pmore
    81c4:	f94143f7 	ldr	x23, [sp, #640]
    81c8:	f94147f8 	ldr	x24, [sp, #648]
    81cc:	f9414bf9 	ldr	x25, [sp, #656]
    81d0:	f9414ffa 	ldr	x26, [sp, #664]
    81d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    81d8:	aa1403e0 	mov	x0, x20
    81dc:	91001fe1 	add	x1, sp, #0x7
    81e0:	d2800022 	mov	x2, #0x1                   	// #1
    81e4:	39001fe3 	strb	w3, [sp, #7]
    81e8:	17fffdaa 	b	7890 <fwp_write+0x9c>
    81ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    81f0:	17fffe45 	b	7b04 <fwp_write+0x310>
    81f4:	f10002ff 	cmp	x23, #0x0
    81f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    81fc:	71002c3f 	cmp	w1, #0xb
    8200:	54ffebc0 	b.eq	7f78 <fwp_write+0x784>  // b.none
    8204:	aa1303e2 	mov	x2, x19
    8208:	aa1703e1 	mov	x1, x23
    820c:	aa1403e0 	mov	x0, x20
    8210:	52800003 	mov	w3, #0x0                   	// #0
    8214:	97fffd78 	bl	77f4 <fwp_write>
    8218:	17ffff6a 	b	7fc0 <fwp_write+0x7cc>
    821c:	aa1403e0 	mov	x0, x20
    8220:	91001fe1 	add	x1, sp, #0x7
    8224:	52800fa3 	mov	w3, #0x7d                  	// #125
    8228:	d2800022 	mov	x2, #0x1                   	// #1
    822c:	17fffe39 	b	7b10 <fwp_write+0x31c>
    8230:	a9400281 	ldp	x1, x0, [x20]
    8234:	91000800 	add	x0, x0, #0x2
    8238:	8b160000 	add	x0, x0, x22
    823c:	f9000680 	str	x0, [x20, #8]
    8240:	3820683f 	strb	wzr, [x1, x0]
    8244:	f9413bf5 	ldr	x21, [sp, #624]
    8248:	f9413ff6 	ldr	x22, [sp, #632]
    824c:	f94153fb 	ldr	x27, [sp, #672]
    8250:	f94157fc 	ldr	x28, [sp, #680]
    8254:	17fffd94 	b	78a4 <fwp_write+0xb0>
    8258:	f9400f80 	ldr	x0, [x28, #24]
    825c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8260:	aa1b03e0 	mov	x0, x27
    8264:	97ffe933 	bl	2730 <strlen@plt>
    8268:	aa1b03e1 	mov	x1, x27
    826c:	aa0003e2 	mov	x2, x0
    8270:	aa1403e0 	mov	x0, x20
    8274:	97ffed07 	bl	3690 <buf_put>
    8278:	aa1903e1 	mov	x1, x25
    827c:	aa1403e0 	mov	x0, x20
    8280:	d2800062 	mov	x2, #0x3                   	// #3
    8284:	97ffed03 	bl	3690 <buf_put>
    8288:	17fffe11 	b	7acc <fwp_write+0x2d8>
    828c:	aa1a03e1 	mov	x1, x26
    8290:	aa1403e0 	mov	x0, x20
    8294:	d2800042 	mov	x2, #0x2                   	// #2
    8298:	97ffecfe 	bl	3690 <buf_put>
    829c:	17fffe0a 	b	7ac4 <fwp_write+0x2d0>
    82a0:	f9400660 	ldr	x0, [x19, #8]
    82a4:	b4fffb00 	cbz	x0, 8204 <fwp_write+0xa10>
    82a8:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    82ac:	91078021 	add	x1, x1, #0x1e0
    82b0:	97ffe99c 	bl	2920 <strcmp@plt>
    82b4:	7100001f 	cmp	w0, #0x0
    82b8:	1a9f07e0 	cset	w0, ne	// ne = any
    82bc:	17ffff2f 	b	7f78 <fwp_write+0x784>
    82c0:	aa1403e0 	mov	x0, x20
    82c4:	d2800042 	mov	x2, #0x2                   	// #2
    82c8:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    82cc:	91076021 	add	x1, x1, #0x1d8
    82d0:	97ffecf0 	bl	3690 <buf_put>
    82d4:	91004261 	add	x1, x19, #0x10
    82d8:	aa1403e0 	mov	x0, x20
    82dc:	f9402382 	ldr	x2, [x28, #64]
    82e0:	52800003 	mov	w3, #0x0                   	// #0
    82e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    82e8:	97fffd43 	bl	77f4 <fwp_write>
    82ec:	17fffd9d 	b	7960 <fwp_write+0x16c>
    82f0:	1e22c109 	fcvt	d9, s8
    82f4:	910123f5 	add	x21, sp, #0x48
    82f8:	52800033 	mov	w19, #0x1                   	// #1
    82fc:	d503201f 	nop
    8300:	1e604120 	fmov	d0, d9
    8304:	2a1303e1 	mov	w1, w19
    8308:	aa1503e0 	mov	x0, x21
    830c:	97ffed3d 	bl	3800 <fwp_format_g.constprop.0>
    8310:	aa1503e0 	mov	x0, x21
    8314:	d2800001 	mov	x1, #0x0                   	// #0
    8318:	97ffe98e 	bl	2950 <strtof@plt>
    831c:	1e202100 	fcmp	s8, s0
    8320:	54ffdb60 	b.eq	7e8c <fwp_write+0x698>  // b.none
    8324:	11000673 	add	w19, w19, #0x1
    8328:	71002a7f 	cmp	w19, #0xa
    832c:	54fffea1 	b.ne	8300 <fwp_write+0xb0c>  // b.any
    8330:	1e604120 	fmov	d0, d9
    8334:	aa1503e0 	mov	x0, x21
    8338:	52800121 	mov	w1, #0x9                   	// #9
    833c:	97ffed31 	bl	3800 <fwp_format_g.constprop.0>
    8340:	17fffed3 	b	7e8c <fwp_write+0x698>
    8344:	d37ef6a1 	lsl	x1, x21, #2
    8348:	b7f81563 	tbnz	x3, #63, 85f4 <fwp_write+0xe00>
    834c:	91002263 	add	x3, x19, #0x8
    8350:	8b010061 	add	x1, x3, x1
    8354:	b9400023 	ldr	w3, [x1]
    8358:	7100081f 	cmp	w0, #0x2
    835c:	2a0303e1 	mov	w1, w3
    8360:	93407c63 	sxtw	x3, w3
    8364:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8368:	17fffe5a 	b	7cd0 <fwp_write+0x4dc>
    836c:	d37ffaa1 	lsl	x1, x21, #1
    8370:	b7f81363 	tbnz	x3, #63, 85dc <fwp_write+0xde8>
    8374:	91002263 	add	x3, x19, #0x8
    8378:	8b010061 	add	x1, x3, x1
    837c:	79400021 	ldrh	w1, [x1]
    8380:	7100041f 	cmp	w0, #0x1
    8384:	93403c23 	sxth	x3, w1
    8388:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    838c:	17fffe51 	b	7cd0 <fwp_write+0x4dc>
    8390:	52800443 	mov	w3, #0x22                  	// #34
    8394:	91001ff5 	add	x21, sp, #0x7
    8398:	91002273 	add	x19, x19, #0x8
    839c:	aa1503e1 	mov	x1, x21
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	d2800022 	mov	x2, #0x1                   	// #1
    83a8:	39001fe3 	strb	w3, [sp, #7]
    83ac:	f90143f7 	str	x23, [sp, #640]
    83b0:	8b160277 	add	x23, x19, x22
    83b4:	f90147f8 	str	x24, [sp, #648]
    83b8:	97ffecb6 	bl	3690 <buf_put>
    83bc:	b4000696 	cbz	x22, 848c <fwp_write+0xc98>
    83c0:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x4f0>
    83c4:	91062318 	add	x24, x24, #0x188
    83c8:	f9014bf9 	str	x25, [sp, #656]
    83cc:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x4f0>
    83d0:	9106a339 	add	x25, x25, #0x1a8
    83d4:	f9014ffa 	str	x26, [sp, #664]
    83d8:	1400000d 	b	840c <fwp_write+0xc18>
    83dc:	710024bf 	cmp	w5, #0x9
    83e0:	54000460 	b.eq	846c <fwp_write+0xc78>  // b.none
    83e4:	710028bf 	cmp	w5, #0xa
    83e8:	54000a61 	b.ne	8534 <fwp_write+0xd40>  // b.any
    83ec:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    83f0:	aa1403e0 	mov	x0, x20
    83f4:	91066021 	add	x1, x1, #0x198
    83f8:	d2800042 	mov	x2, #0x2                   	// #2
    83fc:	97ffeca5 	bl	3690 <buf_put>
    8400:	91000673 	add	x19, x19, #0x1
    8404:	eb17027f 	cmp	x19, x23
    8408:	540003e0 	b.eq	8484 <fwp_write+0xc90>  // b.none
    840c:	39400265 	ldrb	w5, [x19]
    8410:	710034bf 	cmp	w5, #0xd
    8414:	54000180 	b.eq	8444 <fwp_write+0xc50>  // b.none
    8418:	54fffe29 	b.ls	83dc <fwp_write+0xbe8>  // b.plast
    841c:	710088bf 	cmp	w5, #0x22
    8420:	540001c0 	b.eq	8458 <fwp_write+0xc64>  // b.none
    8424:	710170bf 	cmp	w5, #0x5c
    8428:	54000741 	b.ne	8510 <fwp_write+0xd1c>  // b.any
    842c:	aa1403e0 	mov	x0, x20
    8430:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    8434:	d2800042 	mov	x2, #0x2                   	// #2
    8438:	91064021 	add	x1, x1, #0x190
    843c:	97ffec95 	bl	3690 <buf_put>
    8440:	17fffff0 	b	8400 <fwp_write+0xc0c>
    8444:	aa1903e1 	mov	x1, x25
    8448:	aa1403e0 	mov	x0, x20
    844c:	d2800042 	mov	x2, #0x2                   	// #2
    8450:	97ffec90 	bl	3690 <buf_put>
    8454:	17ffffeb 	b	8400 <fwp_write+0xc0c>
    8458:	aa1803e1 	mov	x1, x24
    845c:	aa1403e0 	mov	x0, x20
    8460:	d2800042 	mov	x2, #0x2                   	// #2
    8464:	97ffec8b 	bl	3690 <buf_put>
    8468:	17ffffe6 	b	8400 <fwp_write+0xc0c>
    846c:	aa1403e0 	mov	x0, x20
    8470:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    8474:	d2800042 	mov	x2, #0x2                   	// #2
    8478:	91068021 	add	x1, x1, #0x1a0
    847c:	97ffec85 	bl	3690 <buf_put>
    8480:	17ffffe0 	b	8400 <fwp_write+0xc0c>
    8484:	f9414bf9 	ldr	x25, [sp, #656]
    8488:	f9414ffa 	ldr	x26, [sp, #664]
    848c:	aa1503e1 	mov	x1, x21
    8490:	aa1403e0 	mov	x0, x20
    8494:	52800443 	mov	w3, #0x22                  	// #34
    8498:	17fffd9d 	b	7b0c <fwp_write+0x318>
    849c:	7100103f 	cmp	w1, #0x4
    84a0:	54ffeb21 	b.ne	8204 <fwp_write+0xa10>  // b.any
    84a4:	f94006e0 	ldr	x0, [x23, #8]
    84a8:	d37ffc00 	lsr	x0, x0, #63
    84ac:	17fffeb3 	b	7f78 <fwp_write+0x784>
    84b0:	710002ff 	cmp	w23, #0x0
    84b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    84b8:	17fffeb0 	b	7f78 <fwp_write+0x784>
    84bc:	528005a1 	mov	w1, #0x2d                  	// #45
    84c0:	eb0203e2 	negs	x2, x2
    84c4:	da0303e3 	ngc	x3, x3
    84c8:	910127e0 	add	x0, sp, #0x49
    84cc:	910123f5 	add	x21, sp, #0x48
    84d0:	390123e1 	strb	w1, [sp, #72]
    84d4:	97ffea53 	bl	2e20 <fwp_fmt_u128>
    84d8:	17fffe18 	b	7d38 <fwp_write+0x544>
    84dc:	d37ceea1 	lsl	x1, x21, #4
    84e0:	b7f810a3 	tbnz	x3, #63, 86f4 <fwp_write+0xf00>
    84e4:	91002260 	add	x0, x19, #0x8
    84e8:	8b010001 	add	x1, x0, x1
    84ec:	17fffdf9 	b	7cd0 <fwp_write+0x4dc>
    84f0:	f9400a61 	ldr	x1, [x19, #16]
    84f4:	8b010000 	add	x0, x0, x1
    84f8:	f9400001 	ldr	x1, [x0]
    84fc:	17fffdf5 	b	7cd0 <fwp_write+0x4dc>
    8500:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    8504:	d2800042 	mov	x2, #0x2                   	// #2
    8508:	9104c021 	add	x1, x1, #0x130
    850c:	17fffed6 	b	8064 <fwp_write+0x870>
    8510:	7101fcbf 	cmp	w5, #0x7f
    8514:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8518:	540000e9 	b.ls	8534 <fwp_write+0xd40>  // b.plast
    851c:	aa1503e1 	mov	x1, x21
    8520:	aa1403e0 	mov	x0, x20
    8524:	d2800022 	mov	x2, #0x1                   	// #1
    8528:	39001fe5 	strb	w5, [sp, #7]
    852c:	97ffec59 	bl	3690 <buf_put>
    8530:	17ffffb4 	b	8400 <fwp_write+0xc0c>
    8534:	d2800203 	mov	x3, #0x10                  	// #16
    8538:	d0000004 	adrp	x4, a000 <_IO_stdin_used+0x4f0>
    853c:	aa0303e1 	mov	x1, x3
    8540:	9106c084 	add	x4, x4, #0x1b0
    8544:	910123f6 	add	x22, sp, #0x48
    8548:	52800042 	mov	w2, #0x2                   	// #2
    854c:	aa1603e0 	mov	x0, x22
    8550:	97ffe8b0 	bl	2810 <__snprintf_chk@plt>
    8554:	aa1603e0 	mov	x0, x22
    8558:	97ffe876 	bl	2730 <strlen@plt>
    855c:	aa1603e1 	mov	x1, x22
    8560:	aa0003e2 	mov	x2, x0
    8564:	aa1403e0 	mov	x0, x20
    8568:	97ffec4a 	bl	3690 <buf_put>
    856c:	17ffffa5 	b	8400 <fwp_write+0xc0c>
    8570:	1e604100 	fmov	d0, d8
    8574:	aa1503e0 	mov	x0, x21
    8578:	52800221 	mov	w1, #0x11                  	// #17
    857c:	97ffeca1 	bl	3800 <fwp_format_g.constprop.0>
    8580:	17fffe43 	b	7e8c <fwp_write+0x698>
    8584:	b9401040 	ldr	w0, [x2, #16]
    8588:	350003c0 	cbnz	w0, 8600 <fwp_write+0xe0c>
    858c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8590:	f947f400 	ldr	x0, [x0, #4072]
    8594:	f94127e2 	ldr	x2, [sp, #584]
    8598:	f9400001 	ldr	x1, [x0]
    859c:	eb010042 	subs	x2, x2, x1
    85a0:	d2800001 	mov	x1, #0x0                   	// #0
    85a4:	54ffd721 	b.ne	8088 <fwp_write+0x894>  // b.any
    85a8:	f9413bf5 	ldr	x21, [sp, #624]
    85ac:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    85b0:	f9413ff6 	ldr	x22, [sp, #632]
    85b4:	aa1403e0 	mov	x0, x20
    85b8:	f94143f7 	ldr	x23, [sp, #640]
    85bc:	91080021 	add	x1, x1, #0x200
    85c0:	f94147f8 	ldr	x24, [sp, #648]
    85c4:	d2800042 	mov	x2, #0x2                   	// #2
    85c8:	17fffd0f 	b	7a04 <fwp_write+0x210>
    85cc:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x4f0>
    85d0:	d2800042 	mov	x2, #0x2                   	// #2
    85d4:	9104e021 	add	x1, x1, #0x138
    85d8:	17fffea3 	b	8064 <fwp_write+0x870>
    85dc:	f9400a63 	ldr	x3, [x19, #16]
    85e0:	8b030021 	add	x1, x1, x3
    85e4:	17ffff66 	b	837c <fwp_write+0xb88>
    85e8:	f9400a61 	ldr	x1, [x19, #16]
    85ec:	8b0102a1 	add	x1, x21, x1
    85f0:	17fffdb4 	b	7cc0 <fwp_write+0x4cc>
    85f4:	f9400a63 	ldr	x3, [x19, #16]
    85f8:	8b030021 	add	x1, x1, x3
    85fc:	17ffff56 	b	8354 <fwp_write+0xb60>
    8600:	b9404840 	ldr	w0, [x2, #72]
    8604:	91001ff5 	add	x21, sp, #0x7
    8608:	34ffa380 	cbz	w0, 7a78 <fwp_write+0x284>
    860c:	52800503 	mov	w3, #0x28                  	// #40
    8610:	aa1403e0 	mov	x0, x20
    8614:	aa1503e1 	mov	x1, x21
    8618:	d2800022 	mov	x2, #0x1                   	// #1
    861c:	39001fe3 	strb	w3, [sp, #7]
    8620:	97ffec1c 	bl	3690 <buf_put>
    8624:	b9401380 	ldr	w0, [x28, #16]
    8628:	52800038 	mov	w24, #0x1                   	// #1
    862c:	7100001f 	cmp	w0, #0x0
    8630:	54ffa38c 	b.gt	7aa0 <fwp_write+0x2ac>
    8634:	17fffd33 	b	7b00 <fwp_write+0x30c>
    8638:	f9014bf9 	str	x25, [sp, #656]
    863c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x122d8>
    8640:	f9014ffa 	str	x26, [sp, #664]
    8644:	f9400676 	ldr	x22, [x19, #8]
    8648:	910ac333 	add	x19, x25, #0x2b0
    864c:	91002273 	add	x19, x19, #0x8
    8650:	937ffed8 	asr	x24, x22, #63
    8654:	aa1802c0 	orr	x0, x22, x24
    8658:	b5000320 	cbnz	x0, 86bc <fwp_write+0xec8>
    865c:	110006b5 	add	w21, w21, #0x1
    8660:	710016bf 	cmp	w21, #0x5
    8664:	54ffffc1 	b.ne	865c <fwp_write+0xe68>  // b.any
    8668:	b7f80578 	tbnz	x24, #63, 8714 <fwp_write+0xf20>
    866c:	910023f3 	add	x19, sp, #0x8
    8670:	aa1603e2 	mov	x2, x22
    8674:	aa1303e0 	mov	x0, x19
    8678:	d2800003 	mov	x3, #0x0                   	// #0
    867c:	97ffe9e9 	bl	2e20 <fwp_fmt_u128>
    8680:	910123f5 	add	x21, sp, #0x48
    8684:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x4f0>
    8688:	aa1303e4 	mov	x4, x19
    868c:	aa1503e0 	mov	x0, x21
    8690:	9107e063 	add	x3, x3, #0x1f8
    8694:	d2804002 	mov	x2, #0x200                 	// #512
    8698:	52800041 	mov	w1, #0x2                   	// #2
    869c:	97ffe829 	bl	2740 <__sprintf_chk@plt>
    86a0:	aa1503e0 	mov	x0, x21
    86a4:	97ffe823 	bl	2730 <strlen@plt>
    86a8:	aa1503e1 	mov	x1, x21
    86ac:	aa0003e2 	mov	x2, x0
    86b0:	aa1403e0 	mov	x0, x20
    86b4:	97ffebf7 	bl	3690 <buf_put>
    86b8:	17fffe47 	b	7fd4 <fwp_write+0x7e0>
    86bc:	f9400277 	ldr	x23, [x19]
    86c0:	aa1603e0 	mov	x0, x22
    86c4:	aa1803e1 	mov	x1, x24
    86c8:	aa1703e2 	mov	x2, x23
    86cc:	937ffefa 	asr	x26, x23, #63
    86d0:	aa1a03e3 	mov	x3, x26
    86d4:	94000427 	bl	9770 <__modti3>
    86d8:	aa010000 	orr	x0, x0, x1
    86dc:	b40002c0 	cbz	x0, 8734 <fwp_write+0xf40>
    86e0:	110006b5 	add	w21, w21, #0x1
    86e4:	91004273 	add	x19, x19, #0x10
    86e8:	710016bf 	cmp	w21, #0x5
    86ec:	54fffe81 	b.ne	86bc <fwp_write+0xec8>  // b.any
    86f0:	17ffffde 	b	8668 <fwp_write+0xe74>
    86f4:	f9400a60 	ldr	x0, [x19, #16]
    86f8:	8b000021 	add	x1, x1, x0
    86fc:	17fffd75 	b	7cd0 <fwp_write+0x4dc>
    8700:	528c29c0 	mov	w0, #0x614e                	// #24910
    8704:	910123f5 	add	x21, sp, #0x48
    8708:	72a009c0 	movk	w0, #0x4e, lsl #16
    870c:	b9004be0 	str	w0, [sp, #72]
    8710:	17fffda2 	b	7d98 <fwp_write+0x5a4>
    8714:	528005a1 	mov	w1, #0x2d                  	// #45
    8718:	eb1603e2 	negs	x2, x22
    871c:	da1803e3 	ngc	x3, x24
    8720:	910027e0 	add	x0, sp, #0x9
    8724:	910023f3 	add	x19, sp, #0x8
    8728:	390023e1 	strb	w1, [sp, #8]
    872c:	97ffe9bd 	bl	2e20 <fwp_fmt_u128>
    8730:	17ffffd4 	b	8680 <fwp_write+0xe8c>
    8734:	aa1703e2 	mov	x2, x23
    8738:	aa1a03e3 	mov	x3, x26
    873c:	aa1603e0 	mov	x0, x22
    8740:	aa1803e1 	mov	x1, x24
    8744:	9400032b 	bl	93f0 <__divti3>
    8748:	aa0003e2 	mov	x2, x0
    874c:	aa0103e3 	mov	x3, x1
    8750:	b7f80201 	tbnz	x1, #63, 8790 <fwp_write+0xf9c>
    8754:	910023f3 	add	x19, sp, #0x8
    8758:	aa1303e0 	mov	x0, x19
    875c:	97ffe9b1 	bl	2e20 <fwp_fmt_u128>
    8760:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8764:	910ac339 	add	x25, x25, #0x2b0
    8768:	910123f5 	add	x21, sp, #0x48
    876c:	aa1303e4 	mov	x4, x19
    8770:	aa1503e0 	mov	x0, x21
    8774:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x4f0>
    8778:	f8616b25 	ldr	x5, [x25, x1]
    877c:	9107c063 	add	x3, x3, #0x1f0
    8780:	d2804002 	mov	x2, #0x200                 	// #512
    8784:	52800041 	mov	w1, #0x2                   	// #2
    8788:	97ffe7ee 	bl	2740 <__sprintf_chk@plt>
    878c:	17ffffc5 	b	86a0 <fwp_write+0xeac>
    8790:	528005a4 	mov	w4, #0x2d                  	// #45
    8794:	eb0003e2 	negs	x2, x0
    8798:	da0103e3 	ngc	x3, x1
    879c:	910027e0 	add	x0, sp, #0x9
    87a0:	910023f3 	add	x19, sp, #0x8
    87a4:	390023e4 	strb	w4, [sp, #8]
    87a8:	97ffe99e 	bl	2e20 <fwp_fmt_u128>
    87ac:	17ffffed 	b	8760 <fwp_write+0xf6c>
    87b0:	f9013bf5 	str	x21, [sp, #624]
    87b4:	f9013ff6 	str	x22, [sp, #632]
    87b8:	f90143f7 	str	x23, [sp, #640]
    87bc:	f90147f8 	str	x24, [sp, #648]
    87c0:	f9014bf9 	str	x25, [sp, #656]
    87c4:	f9014ffa 	str	x26, [sp, #664]
    87c8:	f90153fb 	str	x27, [sp, #672]
    87cc:	f90157fc 	str	x28, [sp, #680]
    87d0:	fd015be8 	str	d8, [sp, #688]
    87d4:	fd015fe9 	str	d9, [sp, #696]
    87d8:	97ffe832 	bl	28a0 <__stack_chk_fail@plt>
    87dc:	d503201f 	nop

00000000000087e0 <fwp_main_thread>:
    87e0:	d10603ff 	sub	sp, sp, #0x180
    87e4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    87e8:	f947f400 	ldr	x0, [x0, #4072]
    87ec:	a9127bfd 	stp	x29, x30, [sp, #288]
    87f0:	910483fd 	add	x29, sp, #0x120
    87f4:	a91353f3 	stp	x19, x20, [sp, #304]
    87f8:	b0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    87fc:	91188261 	add	x1, x19, #0x620
    8800:	a9145bf5 	stp	x21, x22, [sp, #320]
    8804:	a91563f7 	stp	x23, x24, [sp, #336]
    8808:	b953a421 	ldr	w1, [x1, #5028]
    880c:	f9400002 	ldr	x2, [x0]
    8810:	f9008fe2 	str	x2, [sp, #280]
    8814:	d2800002 	mov	x2, #0x0                   	// #0
    8818:	34000f81 	cbz	w1, 8a08 <fwp_main_thread+0x228>
    881c:	91188260 	add	x0, x19, #0x620
    8820:	b953a800 	ldr	w0, [x0, #5032]
    8824:	35000ea0 	cbnz	w0, 89f8 <fwp_main_thread+0x218>
    8828:	900000d5 	adrp	x21, 20000 <__data_start>
    882c:	900000c2 	adrp	x2, 20000 <__data_start>
    8830:	910142b4 	add	x20, x21, #0x50
    8834:	91110042 	add	x2, x2, #0x440
    8838:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    883c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8840:	910103f7 	add	x23, sp, #0x40
    8844:	9100a3f6 	add	x22, sp, #0x28
    8848:	aa1703e0 	mov	x0, x23
    884c:	d2800001 	mov	x1, #0x0                   	// #0
    8850:	f90023e2 	str	x2, [sp, #64]
    8854:	b9004bff 	str	wzr, [sp, #72]
    8858:	f9002be4 	str	x4, [sp, #80]
    885c:	a90a0e96 	stp	x22, x3, [x20, #160]
    8860:	97ffe7a8 	bl	2700 <sigaltstack@plt>
    8864:	35000220 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    8868:	4f000400 	movi	v0.4s, #0x0
    886c:	910223e0 	add	x0, sp, #0x88
    8870:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    8874:	9102c021 	add	x1, x1, #0xb0
    8878:	f90043e1 	str	x1, [sp, #128]
    887c:	52800082 	mov	w2, #0x4                   	// #4
    8880:	72a10002 	movk	w2, #0x800, lsl #16
    8884:	910203f8 	add	x24, sp, #0x80
    8888:	3d802000 	str	q0, [x0, #128]
    888c:	b9010be2 	str	w2, [sp, #264]
    8890:	ad000000 	stp	q0, q0, [x0]
    8894:	ad010000 	stp	q0, q0, [x0, #32]
    8898:	ad020000 	stp	q0, q0, [x0, #64]
    889c:	ad030000 	stp	q0, q0, [x0, #96]
    88a0:	97ffe7f0 	bl	2860 <sigemptyset@plt>
    88a4:	340000c0 	cbz	w0, 88bc <fwp_main_thread+0xdc>
    88a8:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    88ac:	91084000 	add	x0, x0, #0x210
    88b0:	a9166bf9 	stp	x25, x26, [sp, #352]
    88b4:	a91773fb 	stp	x27, x28, [sp, #368]
    88b8:	97ffee9f 	bl	4334 <fwp_trap>
    88bc:	aa1803e1 	mov	x1, x24
    88c0:	d2800002 	mov	x2, #0x0                   	// #0
    88c4:	52800160 	mov	w0, #0xb                   	// #11
    88c8:	97ffe7fe 	bl	28c0 <sigaction@plt>
    88cc:	35fffee0 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    88d0:	aa1803e1 	mov	x1, x24
    88d4:	d2800002 	mov	x2, #0x0                   	// #0
    88d8:	528000e0 	mov	w0, #0x7                   	// #7
    88dc:	97ffe7f9 	bl	28c0 <sigaction@plt>
    88e0:	35fffe40 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    88e4:	a9166bf9 	stp	x25, x26, [sp, #352]
    88e8:	9118827a 	add	x26, x19, #0x620
    88ec:	52800039 	mov	w25, #0x1                   	// #1
    88f0:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    88f4:	910ec000 	add	x0, x0, #0x3b0
    88f8:	fd4a1340 	ldr	d0, [x26, #5152]
    88fc:	b9013299 	str	w25, [x20, #304]
    8900:	7e61d800 	ucvtf	d0, d0
    8904:	fd00a680 	str	d0, [x20, #328]
    8908:	94000476 	bl	9ae0 <atexit>
    890c:	35005120 	cbnz	w0, 9330 <fwp_main_thread+0xb50>
    8910:	b943c680 	ldr	w0, [x20, #964]
    8914:	340007e0 	cbz	w0, 8a10 <fwp_main_thread+0x230>
    8918:	910142ba 	add	x26, x21, #0x50
    891c:	f9404f56 	ldr	x22, [x26, #152]
    8920:	b40013f6 	cbz	x22, 8b9c <fwp_main_thread+0x3bc>
    8924:	910102d7 	add	x23, x22, #0x40
    8928:	39414ad9 	ldrb	w25, [x22, #82]
    892c:	52800038 	mov	w24, #0x1                   	// #1
    8930:	39014ad8 	strb	w24, [x22, #82]
    8934:	d503201f 	nop
    8938:	f94016c0 	ldr	x0, [x22, #40]
    893c:	b40012e0 	cbz	x0, 8b98 <fwp_main_thread+0x3b8>
    8940:	f94032c1 	ldr	x1, [x22, #96]
    8944:	394146c0 	ldrb	w0, [x22, #81]
    8948:	b4000f01 	cbz	x1, 8b28 <fwp_main_thread+0x348>
    894c:	36000dc0 	tbz	w0, #0, 8b04 <fwp_main_thread+0x324>
    8950:	f9404f54 	ldr	x20, [x26, #152]
    8954:	f94022c0 	ldr	x0, [x22, #64]
    8958:	39414a81 	ldrb	w1, [x20, #82]
    895c:	370010e1 	tbnz	w1, #0, 8b78 <fwp_main_thread+0x398>
    8960:	f9403281 	ldr	x1, [x20, #96]
    8964:	a911fe97 	stp	x23, xzr, [x20, #280]
    8968:	f9009680 	str	x0, [x20, #296]
    896c:	b4000040 	cbz	x0, 8974 <fwp_main_thread+0x194>
    8970:	f9009014 	str	x20, [x0, #288]
    8974:	f90022d4 	str	x20, [x22, #64]
    8978:	b4000101 	cbz	x1, 8998 <fwp_main_thread+0x1b8>
    897c:	f9409740 	ldr	x0, [x26, #296]
    8980:	39015698 	strb	w24, [x20, #85]
    8984:	f9003681 	str	x1, [x20, #104]
    8988:	a910829f 	stp	xzr, x0, [x20, #264]
    898c:	b4000040 	cbz	x0, 8994 <fwp_main_thread+0x1b4>
    8990:	f9008414 	str	x20, [x0, #264]
    8994:	f9009754 	str	x20, [x26, #296]
    8998:	39015a9f 	strb	wzr, [x20, #86]
    899c:	97fff8ed 	bl	6d50 <fwp_block>
    89a0:	f9408e82 	ldr	x2, [x20, #280]
    89a4:	b4000142 	cbz	x2, 89cc <fwp_main_thread+0x1ec>
    89a8:	a9520281 	ldp	x1, x0, [x20, #288]
    89ac:	b4000f21 	cbz	x1, 8b90 <fwp_main_thread+0x3b0>
    89b0:	f9009420 	str	x0, [x1, #296]
    89b4:	f9409680 	ldr	x0, [x20, #296]
    89b8:	b4000040 	cbz	x0, 89c0 <fwp_main_thread+0x1e0>
    89bc:	f9009001 	str	x1, [x0, #288]
    89c0:	91080280 	add	x0, x20, #0x200
    89c4:	f900969f 	str	xzr, [x20, #296]
    89c8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    89cc:	39415680 	ldrb	w0, [x20, #85]
    89d0:	3607fb40 	tbz	w0, #0, 8938 <fwp_main_thread+0x158>
    89d4:	a9508281 	ldp	x1, x0, [x20, #264]
    89d8:	b4002141 	cbz	x1, 8e00 <fwp_main_thread+0x620>
    89dc:	f9008820 	str	x0, [x1, #272]
    89e0:	b4000040 	cbz	x0, 89e8 <fwp_main_thread+0x208>
    89e4:	f9008401 	str	x1, [x0, #264]
    89e8:	91080280 	add	x0, x20, #0x200
    89ec:	3901569f 	strb	wzr, [x20, #85]
    89f0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    89f4:	17ffffd1 	b	8938 <fwp_main_thread+0x158>
    89f8:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    89fc:	91301000 	add	x0, x0, #0xc04
    8a00:	94000438 	bl	9ae0 <atexit>
    8a04:	17ffff89 	b	8828 <fwp_main_thread+0x48>
    8a08:	97ffecda 	bl	3d70 <fwp_heap_init>
    8a0c:	17ffff84 	b	881c <fwp_main_thread+0x3c>
    8a10:	f941ca82 	ldr	x2, [x20, #912]
    8a14:	a91773fb 	stp	x27, x28, [sp, #368]
    8a18:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0x50>
    8a1c:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8a20:	913fc000 	add	x0, x0, #0xff0
    8a24:	913d4021 	add	x1, x1, #0xf50
    8a28:	d280001b 	mov	x27, #0x0                   	// #0
    8a2c:	d290001c 	mov	x28, #0x8000                	// #32768
    8a30:	f90007ff 	str	xzr, [sp, #8]
    8a34:	390043f9 	strb	w25, [sp, #16]
    8a38:	a90287e2 	stp	x2, x1, [sp, #40]
    8a3c:	a903fff7 	stp	x23, xzr, [sp, #56]
    8a40:	a90503ff 	stp	xzr, x0, [sp, #80]
    8a44:	f901ca96 	str	x22, [x20, #912]
    8a48:	14000012 	b	8a90 <fwp_main_thread+0x2b0>
    8a4c:	7100045f 	cmp	w2, #0x1
    8a50:	540001a1 	b.ne	8a84 <fwp_main_thread+0x2a4>  // b.any
    8a54:	294308a6 	ldp	w6, w2, [x5, #24]
    8a58:	92403c21 	and	x1, x1, #0xffff
    8a5c:	9b067c21 	mul	x1, x1, x6
    8a60:	d360fc21 	lsr	x1, x1, #32
    8a64:	eb02003f 	cmp	x1, x2
    8a68:	540000e2 	b.cs	8a84 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8a6c:	8b010000 	add	x0, x0, x1
    8a70:	39400001 	ldrb	w1, [x0]
    8a74:	7103fc3f 	cmp	w1, #0xff
    8a78:	54003f60 	b.eq	9264 <fwp_main_thread+0xa84>  // b.none
    8a7c:	394043e1 	ldrb	w1, [sp, #16]
    8a80:	39000001 	strb	w1, [x0]
    8a84:	a9047ffb 	stp	x27, xzr, [sp, #64]
    8a88:	aa190294 	orr	x20, x20, x25
    8a8c:	b4001bf4 	cbz	x20, 8e08 <fwp_main_thread+0x628>
    8a90:	f94007e0 	ldr	x0, [sp, #8]
    8a94:	f1000794 	subs	x20, x28, #0x1
    8a98:	aa1803e1 	mov	x1, x24
    8a9c:	f90027f4 	str	x20, [sp, #72]
    8aa0:	da1f0019 	sbc	x25, x0, xzr
    8aa4:	52800020 	mov	w0, #0x1                   	// #1
    8aa8:	f90007f9 	str	x25, [sp, #8]
    8aac:	aa1403fc 	mov	x28, x20
    8ab0:	a9086ff4 	stp	x20, x27, [sp, #128]
    8ab4:	97fff1fb 	bl	52a0 <fwp_data.part.0.constprop.0>
    8ab8:	aa0003fb 	mov	x27, x0
    8abc:	f949db41 	ldr	x1, [x26, #5040]
    8ac0:	f949ef40 	ldr	x0, [x26, #5080]
    8ac4:	cb010361 	sub	x1, x27, x1
    8ac8:	eb00403f 	cmp	x1, x0, lsl #16
    8acc:	54fffdc2 	b.cs	8a84 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8ad0:	d350fc22 	lsr	x2, x1, #16
    8ad4:	f949ff46 	ldr	x6, [x26, #5112]
    8ad8:	8b020842 	add	x2, x2, x2, lsl #2
    8adc:	d37df042 	lsl	x2, x2, #3
    8ae0:	8b0200c5 	add	x5, x6, x2
    8ae4:	f94010a0 	ldr	x0, [x5, #32]
    8ae8:	b4fffce0 	cbz	x0, 8a84 <fwp_main_thread+0x2a4>
    8aec:	386268c2 	ldrb	w2, [x6, x2]
    8af0:	7100085f 	cmp	w2, #0x2
    8af4:	54fffac1 	b.ne	8a4c <fwp_main_thread+0x26c>  // b.any
    8af8:	72003c3f 	tst	w1, #0xffff
    8afc:	54fffc41 	b.ne	8a84 <fwp_main_thread+0x2a4>  // b.any
    8b00:	17ffffdc 	b	8a70 <fwp_main_thread+0x290>
    8b04:	97fff02b 	bl	4bb0 <fwp_now_ns>
    8b08:	f94032c1 	ldr	x1, [x22, #96]
    8b0c:	eb01001f 	cmp	x0, x1
    8b10:	540000ab 	b.lt	8b24 <fwp_main_thread+0x344>  // b.tstop
    8b14:	394142c0 	ldrb	w0, [x22, #80]
    8b18:	37000060 	tbnz	w0, #0, 8b24 <fwp_main_thread+0x344>
    8b1c:	aa1603e0 	mov	x0, x22
    8b20:	97ffeaf4 	bl	36f0 <fwp_cancel_tree.part.0>
    8b24:	394146c0 	ldrb	w0, [x22, #81]
    8b28:	f9404f54 	ldr	x20, [x26, #152]
    8b2c:	39414a82 	ldrb	w2, [x20, #82]
    8b30:	3707f100 	tbnz	w0, #0, 8950 <fwp_main_thread+0x170>
    8b34:	f94032c1 	ldr	x1, [x22, #96]
    8b38:	370001c2 	tbnz	w2, #0, 8b70 <fwp_main_thread+0x390>
    8b3c:	f9403280 	ldr	x0, [x20, #96]
    8b40:	b4000180 	cbz	x0, 8b70 <fwp_main_thread+0x390>
    8b44:	b4000061 	cbz	x1, 8b50 <fwp_main_thread+0x370>
    8b48:	eb01001f 	cmp	x0, x1
    8b4c:	9a81d000 	csel	x0, x0, x1, le
    8b50:	f94022c1 	ldr	x1, [x22, #64]
    8b54:	a911fe97 	stp	x23, xzr, [x20, #280]
    8b58:	f9009681 	str	x1, [x20, #296]
    8b5c:	b40038c1 	cbz	x1, 9274 <fwp_main_thread+0xa94>
    8b60:	f9009034 	str	x20, [x1, #288]
    8b64:	aa0003e1 	mov	x1, x0
    8b68:	f90022d4 	str	x20, [x22, #64]
    8b6c:	17ffff84 	b	897c <fwp_main_thread+0x19c>
    8b70:	f94022c0 	ldr	x0, [x22, #64]
    8b74:	17ffff7c 	b	8964 <fwp_main_thread+0x184>
    8b78:	a911fe97 	stp	x23, xzr, [x20, #280]
    8b7c:	f9009680 	str	x0, [x20, #296]
    8b80:	b4000040 	cbz	x0, 8b88 <fwp_main_thread+0x3a8>
    8b84:	f9009014 	str	x20, [x0, #288]
    8b88:	f90022d4 	str	x20, [x22, #64]
    8b8c:	17ffff83 	b	8998 <fwp_main_thread+0x1b8>
    8b90:	f9000040 	str	x0, [x2]
    8b94:	17ffff89 	b	89b8 <fwp_main_thread+0x1d8>
    8b98:	39014ad9 	strb	w25, [x22, #82]
    8b9c:	910142b4 	add	x20, x21, #0x50
    8ba0:	f941d680 	ldr	x0, [x20, #936]
    8ba4:	b5000060 	cbnz	x0, 8bb0 <fwp_main_thread+0x3d0>
    8ba8:	f941de80 	ldr	x0, [x20, #952]
    8bac:	b4003820 	cbz	x0, 92b0 <fwp_main_thread+0xad0>
    8bb0:	910142a0 	add	x0, x21, #0x50
    8bb4:	f9404c00 	ldr	x0, [x0, #152]
    8bb8:	910142a1 	add	x1, x21, #0x50
    8bbc:	f941ec26 	ldr	x6, [x1, #984]
    8bc0:	b903d03f 	str	wzr, [x1, #976]
    8bc4:	eb0000df 	cmp	x6, x0
    8bc8:	540040a1 	b.ne	93dc <fwp_main_thread+0xbfc>  // b.any
    8bcc:	b40003c0 	cbz	x0, 8c44 <fwp_main_thread+0x464>
    8bd0:	f941c025 	ldr	x5, [x1, #896]
    8bd4:	52800021 	mov	w1, #0x1                   	// #1
    8bd8:	39014801 	strb	w1, [x0, #82]
    8bdc:	b4000345 	cbz	x5, 8c44 <fwp_main_thread+0x464>
    8be0:	394140a0 	ldrb	w0, [x5, #80]
    8be4:	37000060 	tbnz	w0, #0, 8bf0 <fwp_main_thread+0x410>
    8be8:	aa0503e0 	mov	x0, x5
    8bec:	97ffeac1 	bl	36f0 <fwp_cancel_tree.part.0>
    8bf0:	f9409ca5 	ldr	x5, [x5, #312]
    8bf4:	b5ffff65 	cbnz	x5, 8be0 <fwp_main_thread+0x400>
    8bf8:	910142b4 	add	x20, x21, #0x50
    8bfc:	52800036 	mov	w22, #0x1                   	// #1
    8c00:	f94028c0 	ldr	x0, [x6, #80]
    8c04:	f2001c1f 	tst	x0, #0xff000000ff
    8c08:	540000e1 	b.ne	8c24 <fwp_main_thread+0x444>  // b.any
    8c0c:	f9406280 	ldr	x0, [x20, #192]
    8c10:	390150d6 	strb	w22, [x6, #84]
    8c14:	f90080df 	str	xzr, [x6, #256]
    8c18:	b4000120 	cbz	x0, 8c3c <fwp_main_thread+0x45c>
    8c1c:	f9008006 	str	x6, [x0, #256]
    8c20:	f9006286 	str	x6, [x20, #192]
    8c24:	97fff84b 	bl	6d50 <fwp_block>
    8c28:	97fff7d2 	bl	6b70 <fwp_free_zombie>
    8c2c:	f941c280 	ldr	x0, [x20, #896]
    8c30:	b40000a0 	cbz	x0, 8c44 <fwp_main_thread+0x464>
    8c34:	f941ee86 	ldr	x6, [x20, #984]
    8c38:	17fffff2 	b	8c00 <fwp_main_thread+0x420>
    8c3c:	f9006686 	str	x6, [x20, #200]
    8c40:	17fffff8 	b	8c20 <fwp_main_thread+0x440>
    8c44:	910142b6 	add	x22, x21, #0x50
    8c48:	97fff7ca 	bl	6b70 <fwp_free_zombie>
    8c4c:	f94066c0 	ldr	x0, [x22, #200]
    8c50:	b5003c60 	cbnz	x0, 93dc <fwp_main_thread+0xbfc>
    8c54:	f94096c0 	ldr	x0, [x22, #296]
    8c58:	b5003c20 	cbnz	x0, 93dc <fwp_main_thread+0xbfc>
    8c5c:	b94172d4 	ldr	w20, [x22, #368]
    8c60:	340001f4 	cbz	w20, 8c9c <fwp_main_thread+0x4bc>
    8c64:	93407e97 	sxtw	x23, w20
    8c68:	51000694 	sub	w20, w20, #0x1
    8c6c:	d1000af7 	sub	x23, x23, #0x2
    8c70:	910602d8 	add	x24, x22, #0x180
    8c74:	cb3442f7 	sub	x23, x23, w20, uxtw
    8c78:	93407e94 	sxtw	x20, w20
    8c7c:	d503201f 	nop
    8c80:	f8747b00 	ldr	x0, [x24, x20, lsl #3]
    8c84:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8c88:	b90172d4 	str	w20, [x22, #368]
    8c8c:	d1000694 	sub	x20, x20, #0x1
    8c90:	97ffe74c 	bl	29c0 <munmap@plt>
    8c94:	eb17029f 	cmp	x20, x23
    8c98:	54ffff41 	b.ne	8c80 <fwp_main_thread+0x4a0>  // b.any
    8c9c:	900000d4 	adrp	x20, 20000 <__data_start>
    8ca0:	91004280 	add	x0, x20, #0x10
    8ca4:	b9402000 	ldr	w0, [x0, #32]
    8ca8:	37f80040 	tbnz	w0, #31, 8cb0 <fwp_main_thread+0x4d0>
    8cac:	97ffe701 	bl	28b0 <close@plt>
    8cb0:	910142b6 	add	x22, x21, #0x50
    8cb4:	91004294 	add	x20, x20, #0x10
    8cb8:	12800001 	mov	w1, #0xffffffff            	// #-1
    8cbc:	f941f6c0 	ldr	x0, [x22, #1000]
    8cc0:	b9002281 	str	w1, [x20, #32]
    8cc4:	f941f2c1 	ldr	x1, [x22, #992]
    8cc8:	b40001c0 	cbz	x0, 8d00 <fwp_main_thread+0x520>
    8ccc:	d2800014 	mov	x20, #0x0                   	// #0
    8cd0:	f8747820 	ldr	x0, [x1, x20, lsl #3]
    8cd4:	b40000e0 	cbz	x0, 8cf0 <fwp_main_thread+0x510>
    8cd8:	f9400001 	ldr	x1, [x0]
    8cdc:	b5003801 	cbnz	x1, 93dc <fwp_main_thread+0xbfc>
    8ce0:	f9400401 	ldr	x1, [x0, #8]
    8ce4:	b50037c1 	cbnz	x1, 93dc <fwp_main_thread+0xbfc>
    8ce8:	97ffee4e 	bl	4620 <fwp_mem_free>
    8cec:	f941f2c1 	ldr	x1, [x22, #992]
    8cf0:	91000694 	add	x20, x20, #0x1
    8cf4:	f941f6c0 	ldr	x0, [x22, #1000]
    8cf8:	eb00029f 	cmp	x20, x0
    8cfc:	54fffea3 	b.cc	8cd0 <fwp_main_thread+0x4f0>  // b.lo, b.ul, b.last
    8d00:	aa0103e0 	mov	x0, x1
    8d04:	97ffee47 	bl	4620 <fwp_mem_free>
    8d08:	910142a0 	add	x0, x21, #0x50
    8d0c:	f941ec14 	ldr	x20, [x0, #984]
    8d10:	f901f01f 	str	xzr, [x0, #992]
    8d14:	f901f41f 	str	xzr, [x0, #1000]
    8d18:	b40001f4 	cbz	x20, 8d54 <fwp_main_thread+0x574>
    8d1c:	f9401681 	ldr	x1, [x20, #40]
    8d20:	b50035e1 	cbnz	x1, 93dc <fwp_main_thread+0xbfc>
    8d24:	f9405681 	ldr	x1, [x20, #168]
    8d28:	b50035a1 	cbnz	x1, 93dc <fwp_main_thread+0xbfc>
    8d2c:	f941d401 	ldr	x1, [x0, #936]
    8d30:	b5003561 	cbnz	x1, 93dc <fwp_main_thread+0xbfc>
    8d34:	f941dc00 	ldr	x0, [x0, #952]
    8d38:	b5003520 	cbnz	x0, 93dc <fwp_main_thread+0xbfc>
    8d3c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8d40:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bc0>
    8d44:	91110000 	add	x0, x0, #0x440
    8d48:	97ffe6ca 	bl	2870 <memset@plt>
    8d4c:	aa1403e0 	mov	x0, x20
    8d50:	97ffee34 	bl	4620 <fwp_mem_free>
    8d54:	910142a6 	add	x6, x21, #0x50
    8d58:	91188273 	add	x19, x19, #0x620
    8d5c:	3dc016a1 	ldr	q1, [x21, #80]
    8d60:	52800041 	mov	w1, #0x2                   	// #2
    8d64:	3dc004c2 	ldr	q2, [x6, #16]
    8d68:	d0000002 	adrp	x2, a000 <_IO_stdin_used+0x4f0>
    8d6c:	fd4a1260 	ldr	d0, [x19, #5152]
    8d70:	9109c042 	add	x2, x2, #0x270
    8d74:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8d78:	fd40a4c1 	ldr	d1, [x6, #328]
    8d7c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8d80:	f947e800 	ldr	x0, [x0, #4048]
    8d84:	7e61d800 	ucvtf	d0, d0
    8d88:	a95390c3 	ldp	x3, x4, [x6, #312]
    8d8c:	f9004cdf 	str	xzr, [x6, #152]
    8d90:	f9400000 	ldr	x0, [x0]
    8d94:	1e613801 	fsub	d1, d0, d1
    8d98:	f940acc5 	ldr	x5, [x6, #344]
    8d9c:	b90130df 	str	wzr, [x6, #304]
    8da0:	5ef1b842 	addp	d2, v2.2d
    8da4:	fd40a8c0 	ldr	d0, [x6, #336]
    8da8:	f901ecdf 	str	xzr, [x6, #984]
    8dac:	fd0058c2 	str	d2, [x6, #176]
    8db0:	97ffe6d8 	bl	2910 <__fprintf_chk@plt>
    8db4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8db8:	f947ec00 	ldr	x0, [x0, #4056]
    8dbc:	f9400000 	ldr	x0, [x0]
    8dc0:	97ffe704 	bl	29d0 <fflush@plt>
    8dc4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8dc8:	f947f400 	ldr	x0, [x0, #4072]
    8dcc:	f9408fe2 	ldr	x2, [sp, #280]
    8dd0:	f9400001 	ldr	x1, [x0]
    8dd4:	eb010042 	subs	x2, x2, x1
    8dd8:	d2800001 	mov	x1, #0x0                   	// #0
    8ddc:	54002b21 	b.ne	9340 <fwp_main_thread+0xb60>  // b.any
    8de0:	a9527bfd 	ldp	x29, x30, [sp, #288]
    8de4:	d2800000 	mov	x0, #0x0                   	// #0
    8de8:	a95353f3 	ldp	x19, x20, [sp, #304]
    8dec:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8df0:	a95563f7 	ldp	x23, x24, [sp, #336]
    8df4:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8df8:	910603ff 	add	sp, sp, #0x180
    8dfc:	d65f03c0 	ret
    8e00:	f9009740 	str	x0, [x26, #296]
    8e04:	17fffef7 	b	89e0 <fwp_main_thread+0x200>
    8e08:	910142a2 	add	x2, x21, #0x50
    8e0c:	f90023ff 	str	xzr, [sp, #64]
    8e10:	f941c840 	ldr	x0, [x2, #912]
    8e14:	eb16001f 	cmp	x0, x22
    8e18:	54002e41 	b.ne	93e0 <fwp_main_thread+0xc00>  // b.any
    8e1c:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    8e20:	910183e1 	add	x1, sp, #0x60
    8e24:	f94017e3 	ldr	x3, [sp, #40]
    8e28:	f901c843 	str	x3, [x2, #912]
    8e2c:	3dc28400 	ldr	q0, [x0, #2576]
    8e30:	52800020 	mov	w0, #0x1                   	// #1
    8e34:	3d801be0 	str	q0, [sp, #96]
    8e38:	97fff11a 	bl	52a0 <fwp_data.part.0.constprop.0>
    8e3c:	91188263 	add	x3, x19, #0x620
    8e40:	aa0003f4 	mov	x20, x0
    8e44:	f949d861 	ldr	x1, [x3, #5040]
    8e48:	f949ec60 	ldr	x0, [x3, #5080]
    8e4c:	cb010281 	sub	x1, x20, x1
    8e50:	eb00403f 	cmp	x1, x0, lsl #16
    8e54:	54000322 	b.cs	8eb8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8e58:	d350fc22 	lsr	x2, x1, #16
    8e5c:	f949fc63 	ldr	x3, [x3, #5112]
    8e60:	8b020842 	add	x2, x2, x2, lsl #2
    8e64:	d37df042 	lsl	x2, x2, #3
    8e68:	8b020060 	add	x0, x3, x2
    8e6c:	f9401016 	ldr	x22, [x0, #32]
    8e70:	b4000256 	cbz	x22, 8eb8 <fwp_main_thread+0x6d8>
    8e74:	38626862 	ldrb	w2, [x3, x2]
    8e78:	7100085f 	cmp	w2, #0x2
    8e7c:	54002020 	b.eq	9280 <fwp_main_thread+0xaa0>  // b.none
    8e80:	7100045f 	cmp	w2, #0x1
    8e84:	540001a1 	b.ne	8eb8 <fwp_main_thread+0x6d8>  // b.any
    8e88:	29430002 	ldp	w2, w0, [x0, #24]
    8e8c:	92403c21 	and	x1, x1, #0xffff
    8e90:	9b027c21 	mul	x1, x1, x2
    8e94:	d360fc21 	lsr	x1, x1, #32
    8e98:	eb00003f 	cmp	x1, x0
    8e9c:	540000e2 	b.cs	8eb8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8ea0:	8b0102d6 	add	x22, x22, x1
    8ea4:	394002c0 	ldrb	w0, [x22]
    8ea8:	7103fc1f 	cmp	w0, #0xff
    8eac:	54002200 	b.eq	92ec <fwp_main_thread+0xb0c>  // b.none
    8eb0:	52800020 	mov	w0, #0x1                   	// #1
    8eb4:	390002c0 	strb	w0, [x22]
    8eb8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8ebc:	aa1803e1 	mov	x1, x24
    8ec0:	52800020 	mov	w0, #0x1                   	// #1
    8ec4:	a90853e2 	stp	x2, x20, [sp, #128]
    8ec8:	97fff0f6 	bl	52a0 <fwp_data.part.0.constprop.0>
    8ecc:	91188263 	add	x3, x19, #0x620
    8ed0:	aa0003f4 	mov	x20, x0
    8ed4:	f949d861 	ldr	x1, [x3, #5040]
    8ed8:	f949ec60 	ldr	x0, [x3, #5080]
    8edc:	cb010281 	sub	x1, x20, x1
    8ee0:	eb00403f 	cmp	x1, x0, lsl #16
    8ee4:	54000322 	b.cs	8f48 <fwp_main_thread+0x768>  // b.hs, b.nlast
    8ee8:	d350fc22 	lsr	x2, x1, #16
    8eec:	f949fc63 	ldr	x3, [x3, #5112]
    8ef0:	8b020842 	add	x2, x2, x2, lsl #2
    8ef4:	d37df042 	lsl	x2, x2, #3
    8ef8:	8b020060 	add	x0, x3, x2
    8efc:	f9401016 	ldr	x22, [x0, #32]
    8f00:	b4000256 	cbz	x22, 8f48 <fwp_main_thread+0x768>
    8f04:	38626862 	ldrb	w2, [x3, x2]
    8f08:	7100085f 	cmp	w2, #0x2
    8f0c:	54001c00 	b.eq	928c <fwp_main_thread+0xaac>  // b.none
    8f10:	7100045f 	cmp	w2, #0x1
    8f14:	540001a1 	b.ne	8f48 <fwp_main_thread+0x768>  // b.any
    8f18:	29430002 	ldp	w2, w0, [x0, #24]
    8f1c:	92403c21 	and	x1, x1, #0xffff
    8f20:	9b027c21 	mul	x1, x1, x2
    8f24:	d360fc21 	lsr	x1, x1, #32
    8f28:	eb00003f 	cmp	x1, x0
    8f2c:	540000e2 	b.cs	8f48 <fwp_main_thread+0x768>  // b.hs, b.nlast
    8f30:	8b0102d6 	add	x22, x22, x1
    8f34:	394002c0 	ldrb	w0, [x22]
    8f38:	7103fc1f 	cmp	w0, #0xff
    8f3c:	54001cc0 	b.eq	92d4 <fwp_main_thread+0xaf4>  // b.none
    8f40:	52800020 	mov	w0, #0x1                   	// #1
    8f44:	390002c0 	strb	w0, [x22]
    8f48:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8f4c:	9101c3e1 	add	x1, sp, #0x70
    8f50:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8f54:	52800020 	mov	w0, #0x1                   	// #1
    8f58:	a90753e2 	stp	x2, x20, [sp, #112]
    8f5c:	97fff0d1 	bl	52a0 <fwp_data.part.0.constprop.0>
    8f60:	91188263 	add	x3, x19, #0x620
    8f64:	aa0003f9 	mov	x25, x0
    8f68:	f949d861 	ldr	x1, [x3, #5040]
    8f6c:	f949ec60 	ldr	x0, [x3, #5080]
    8f70:	cb010321 	sub	x1, x25, x1
    8f74:	eb00403f 	cmp	x1, x0, lsl #16
    8f78:	54000322 	b.cs	8fdc <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    8f7c:	d350fc22 	lsr	x2, x1, #16
    8f80:	f949fc63 	ldr	x3, [x3, #5112]
    8f84:	8b020842 	add	x2, x2, x2, lsl #2
    8f88:	d37df042 	lsl	x2, x2, #3
    8f8c:	8b020060 	add	x0, x3, x2
    8f90:	f9401014 	ldr	x20, [x0, #32]
    8f94:	b4000254 	cbz	x20, 8fdc <fwp_main_thread+0x7fc>
    8f98:	38626862 	ldrb	w2, [x3, x2]
    8f9c:	7100085f 	cmp	w2, #0x2
    8fa0:	540017c0 	b.eq	9298 <fwp_main_thread+0xab8>  // b.none
    8fa4:	7100045f 	cmp	w2, #0x1
    8fa8:	540001a1 	b.ne	8fdc <fwp_main_thread+0x7fc>  // b.any
    8fac:	29430002 	ldp	w2, w0, [x0, #24]
    8fb0:	92403c21 	and	x1, x1, #0xffff
    8fb4:	9b027c21 	mul	x1, x1, x2
    8fb8:	d360fc21 	lsr	x1, x1, #32
    8fbc:	eb00003f 	cmp	x1, x0
    8fc0:	540000e2 	b.cs	8fdc <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    8fc4:	8b010294 	add	x20, x20, x1
    8fc8:	39400280 	ldrb	w0, [x20]
    8fcc:	7103fc1f 	cmp	w0, #0xff
    8fd0:	54001880 	b.eq	92e0 <fwp_main_thread+0xb00>  // b.none
    8fd4:	52800020 	mov	w0, #0x1                   	// #1
    8fd8:	39000280 	strb	w0, [x20]
    8fdc:	aa1b03f8 	mov	x24, x27
    8fe0:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x122d8>
    8fe4:	b40012db 	cbz	x27, 923c <fwp_main_thread+0xa5c>
    8fe8:	910ac000 	add	x0, x0, #0x2b0
    8fec:	b0000016 	adrp	x22, 9000 <fwp_main_thread+0x820>
    8ff0:	91014014 	add	x20, x0, #0x50
    8ff4:	912d42d6 	add	x22, x22, #0xb50
    8ff8:	9118827a 	add	x26, x19, #0x620
    8ffc:	f949db41 	ldr	x1, [x26, #5040]
    9000:	f949ef40 	ldr	x0, [x26, #5080]
    9004:	cb010321 	sub	x1, x25, x1
    9008:	eb00403f 	cmp	x1, x0, lsl #16
    900c:	54000402 	b.cs	908c <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    9010:	d350fc22 	lsr	x2, x1, #16
    9014:	f949ff45 	ldr	x5, [x26, #5112]
    9018:	8b020842 	add	x2, x2, x2, lsl #2
    901c:	d37df042 	lsl	x2, x2, #3
    9020:	8b0200a3 	add	x3, x5, x2
    9024:	f9401060 	ldr	x0, [x3, #32]
    9028:	b4000320 	cbz	x0, 908c <fwp_main_thread+0x8ac>
    902c:	386268a2 	ldrb	w2, [x5, x2]
    9030:	7100085f 	cmp	w2, #0x2
    9034:	54001380 	b.eq	92a4 <fwp_main_thread+0xac4>  // b.none
    9038:	7100045f 	cmp	w2, #0x1
    903c:	54000281 	b.ne	908c <fwp_main_thread+0x8ac>  // b.any
    9040:	29430865 	ldp	w5, w2, [x3, #24]
    9044:	92403c21 	and	x1, x1, #0xffff
    9048:	9b057c21 	mul	x1, x1, x5
    904c:	d360fc21 	lsr	x1, x1, #32
    9050:	eb02003f 	cmp	x1, x2
    9054:	540001c2 	b.cs	908c <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    9058:	8b010000 	add	x0, x0, x1
    905c:	39400001 	ldrb	w1, [x0]
    9060:	34000161 	cbz	w1, 908c <fwp_main_thread+0x8ac>
    9064:	910142a2 	add	x2, x21, #0x50
    9068:	b9413043 	ldr	w3, [x2, #304]
    906c:	34000083 	cbz	w3, 907c <fwp_main_thread+0x89c>
    9070:	f940ac43 	ldr	x3, [x2, #344]
    9074:	91000463 	add	x3, x3, #0x1
    9078:	f900ac43 	str	x3, [x2, #344]
    907c:	7103f43f 	cmp	w1, #0xfd
    9080:	540013c8 	b.hi	92f8 <fwp_main_thread+0xb18>  // b.pmore
    9084:	11000421 	add	w1, w1, #0x1
    9088:	39000001 	strb	w1, [x0]
    908c:	aa1403e2 	mov	x2, x20
    9090:	aa1903e1 	mov	x1, x25
    9094:	aa1703e0 	mov	x0, x23
    9098:	52800023 	mov	w3, #0x1                   	// #1
    909c:	a9047fff 	stp	xzr, xzr, [sp, #64]
    90a0:	f9002bff 	str	xzr, [sp, #80]
    90a4:	97fff9d4 	bl	77f4 <fwp_write>
    90a8:	a9440bfc 	ldp	x28, x2, [sp, #64]
    90ac:	f100039f 	cmp	x28, #0x0
    90b0:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    90b4:	b100285f 	cmn	x2, #0xa
    90b8:	54001248 	b.hi	9300 <fwp_main_thread+0xb20>  // b.pmore
    90bc:	91002440 	add	x0, x2, #0x9
    90c0:	52800021 	mov	w1, #0x1                   	// #1
    90c4:	f9000be2 	str	x2, [sp, #16]
    90c8:	97fff012 	bl	5110 <fwp_heap_alloc>
    90cc:	aa1c03e1 	mov	x1, x28
    90d0:	aa0003fc 	mov	x28, x0
    90d4:	f9400be2 	ldr	x2, [sp, #16]
    90d8:	f90007e0 	str	x0, [sp, #8]
    90dc:	f8008782 	str	x2, [x28], #8
    90e0:	aa1c03e0 	mov	x0, x28
    90e4:	97ffe583 	bl	26f0 <memcpy@plt>
    90e8:	a9408be0 	ldp	x0, x2, [sp, #8]
    90ec:	8b020002 	add	x2, x0, x2
    90f0:	3900205f 	strb	wzr, [x2, #8]
    90f4:	f94023e0 	ldr	x0, [sp, #64]
    90f8:	97ffe61a 	bl	2960 <free@plt>
    90fc:	91188260 	add	x0, x19, #0x620
    9100:	f94007e3 	ldr	x3, [sp, #8]
    9104:	f949d801 	ldr	x1, [x0, #5040]
    9108:	f949ec02 	ldr	x2, [x0, #5080]
    910c:	cb010061 	sub	x1, x3, x1
    9110:	eb02403f 	cmp	x1, x2, lsl #16
    9114:	54000322 	b.cs	9178 <fwp_main_thread+0x998>  // b.hs, b.nlast
    9118:	d350fc22 	lsr	x2, x1, #16
    911c:	d2800503 	mov	x3, #0x28                  	// #40
    9120:	f949fc05 	ldr	x5, [x0, #5112]
    9124:	9b037c42 	mul	x2, x2, x3
    9128:	8b0200a3 	add	x3, x5, x2
    912c:	f9401060 	ldr	x0, [x3, #32]
    9130:	b4000240 	cbz	x0, 9178 <fwp_main_thread+0x998>
    9134:	386268a2 	ldrb	w2, [x5, x2]
    9138:	7100085f 	cmp	w2, #0x2
    913c:	54000f40 	b.eq	9324 <fwp_main_thread+0xb44>  // b.none
    9140:	7100045f 	cmp	w2, #0x1
    9144:	540001a1 	b.ne	9178 <fwp_main_thread+0x998>  // b.any
    9148:	29430865 	ldp	w5, w2, [x3, #24]
    914c:	92403c21 	and	x1, x1, #0xffff
    9150:	9b057c21 	mul	x1, x1, x5
    9154:	d360fc21 	lsr	x1, x1, #32
    9158:	eb02003f 	cmp	x1, x2
    915c:	540000e2 	b.cs	9178 <fwp_main_thread+0x998>  // b.hs, b.nlast
    9160:	8b010000 	add	x0, x0, x1
    9164:	39400001 	ldrb	w1, [x0]
    9168:	7103fc3f 	cmp	w1, #0xff
    916c:	540010c0 	b.eq	9384 <fwp_main_thread+0xba4>  // b.none
    9170:	52800021 	mov	w1, #0x1                   	// #1
    9174:	39000001 	strb	w1, [x0]
    9178:	aa1903e0 	mov	x0, x25
    917c:	97fff3f9 	bl	6160 <fwp_drop0>
    9180:	f94007e1 	ldr	x1, [sp, #8]
    9184:	910142a3 	add	x3, x21, #0x50
    9188:	aa1c03e0 	mov	x0, x28
    918c:	aa0303fc 	mov	x28, x3
    9190:	f9400022 	ldr	x2, [x1]
    9194:	d2800021 	mov	x1, #0x1                   	// #1
    9198:	f9404863 	ldr	x3, [x3, #144]
    919c:	97ffe601 	bl	29a0 <fwrite@plt>
    91a0:	f9404b81 	ldr	x1, [x28, #144]
    91a4:	52800140 	mov	w0, #0xa                   	// #10
    91a8:	97ffe586 	bl	27c0 <fputc@plt>
    91ac:	91188262 	add	x2, x19, #0x620
    91b0:	f94007e3 	ldr	x3, [sp, #8]
    91b4:	f949d841 	ldr	x1, [x2, #5040]
    91b8:	f949ec40 	ldr	x0, [x2, #5080]
    91bc:	cb010061 	sub	x1, x3, x1
    91c0:	eb00403f 	cmp	x1, x0, lsl #16
    91c4:	54000382 	b.cs	9234 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    91c8:	d350fc20 	lsr	x0, x1, #16
    91cc:	d2800505 	mov	x5, #0x28                  	// #40
    91d0:	f949fc43 	ldr	x3, [x2, #5112]
    91d4:	9b057c00 	mul	x0, x0, x5
    91d8:	8b000062 	add	x2, x3, x0
    91dc:	f940105c 	ldr	x28, [x2, #32]
    91e0:	b40002bc 	cbz	x28, 9234 <fwp_main_thread+0xa54>
    91e4:	38606860 	ldrb	w0, [x3, x0]
    91e8:	7100081f 	cmp	w0, #0x2
    91ec:	54000960 	b.eq	9318 <fwp_main_thread+0xb38>  // b.none
    91f0:	7100041f 	cmp	w0, #0x1
    91f4:	54000201 	b.ne	9234 <fwp_main_thread+0xa54>  // b.any
    91f8:	29430043 	ldp	w3, w0, [x2, #24]
    91fc:	92403c21 	and	x1, x1, #0xffff
    9200:	9b037c21 	mul	x1, x1, x3
    9204:	d360fc21 	lsr	x1, x1, #32
    9208:	eb00003f 	cmp	x1, x0
    920c:	54000142 	b.cs	9234 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    9210:	8b01039c 	add	x28, x28, x1
    9214:	39400380 	ldrb	w0, [x28]
    9218:	340000e0 	cbz	w0, 9234 <fwp_main_thread+0xa54>
    921c:	7100041f 	cmp	w0, #0x1
    9220:	54000760 	b.eq	930c <fwp_main_thread+0xb2c>  // b.none
    9224:	7103fc1f 	cmp	w0, #0xff
    9228:	54000900 	b.eq	9348 <fwp_main_thread+0xb68>  // b.none
    922c:	51000400 	sub	w0, w0, #0x1
    9230:	39000380 	strb	w0, [x28]
    9234:	f9400b18 	ldr	x24, [x24, #16]
    9238:	b5ffee38 	cbnz	x24, 8ffc <fwp_main_thread+0x81c>
    923c:	aa1903e0 	mov	x0, x25
    9240:	97fff3c8 	bl	6160 <fwp_drop0>
    9244:	aa1b03e0 	mov	x0, x27
    9248:	97fff3c6 	bl	6160 <fwp_drop0>
    924c:	910142a0 	add	x0, x21, #0x50
    9250:	52800021 	mov	w1, #0x1                   	// #1
    9254:	a95773fb 	ldp	x27, x28, [sp, #368]
    9258:	b903c401 	str	w1, [x0, #964]
    925c:	f901e41f 	str	xzr, [x0, #968]
    9260:	17fffdae 	b	8918 <fwp_main_thread+0x138>
    9264:	f9000fe0 	str	x0, [sp, #24]
    9268:	97ffec53 	bl	43b4 <fwp_rc_forget_slot.part.0>
    926c:	f9400fe0 	ldr	x0, [sp, #24]
    9270:	17fffe03 	b	8a7c <fwp_main_thread+0x29c>
    9274:	aa0003e1 	mov	x1, x0
    9278:	f90022d4 	str	x20, [x22, #64]
    927c:	17fffdc0 	b	897c <fwp_main_thread+0x19c>
    9280:	72003c3f 	tst	w1, #0xffff
    9284:	54ffe1a1 	b.ne	8eb8 <fwp_main_thread+0x6d8>  // b.any
    9288:	17ffff07 	b	8ea4 <fwp_main_thread+0x6c4>
    928c:	72003c3f 	tst	w1, #0xffff
    9290:	54ffe5c1 	b.ne	8f48 <fwp_main_thread+0x768>  // b.any
    9294:	17ffff28 	b	8f34 <fwp_main_thread+0x754>
    9298:	72003c3f 	tst	w1, #0xffff
    929c:	54ffea01 	b.ne	8fdc <fwp_main_thread+0x7fc>  // b.any
    92a0:	17ffff4a 	b	8fc8 <fwp_main_thread+0x7e8>
    92a4:	72003c3f 	tst	w1, #0xffff
    92a8:	54ffef21 	b.ne	908c <fwp_main_thread+0x8ac>  // b.any
    92ac:	17ffff6c 	b	905c <fwp_main_thread+0x87c>
    92b0:	f941d280 	ldr	x0, [x20, #928]
    92b4:	97ffecdb 	bl	4620 <fwp_mem_free>
    92b8:	f901d29f 	str	xzr, [x20, #928]
    92bc:	f9404e80 	ldr	x0, [x20, #152]
    92c0:	f901da9f 	str	xzr, [x20, #944]
    92c4:	b4ffc7a0 	cbz	x0, 8bb8 <fwp_main_thread+0x3d8>
    92c8:	f900541f 	str	xzr, [x0, #168]
    92cc:	f9005c1f 	str	xzr, [x0, #184]
    92d0:	17fffe3a 	b	8bb8 <fwp_main_thread+0x3d8>
    92d4:	aa1603e0 	mov	x0, x22
    92d8:	97ffec37 	bl	43b4 <fwp_rc_forget_slot.part.0>
    92dc:	17ffff19 	b	8f40 <fwp_main_thread+0x760>
    92e0:	aa1403e0 	mov	x0, x20
    92e4:	97ffec34 	bl	43b4 <fwp_rc_forget_slot.part.0>
    92e8:	17ffff3b 	b	8fd4 <fwp_main_thread+0x7f4>
    92ec:	aa1603e0 	mov	x0, x22
    92f0:	97ffec31 	bl	43b4 <fwp_rc_forget_slot.part.0>
    92f4:	17fffeef 	b	8eb0 <fwp_main_thread+0x6d0>
    92f8:	97ffed43 	bl	4804 <fwp_rc_wide_dup>
    92fc:	17ffff64 	b	908c <fwp_main_thread+0x8ac>
    9300:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    9304:	91096000 	add	x0, x0, #0x258
    9308:	97ffec0b 	bl	4334 <fwp_trap>
    930c:	f94007e0 	ldr	x0, [sp, #8]
    9310:	97fff25c 	bl	5c80 <fwp_rc_free_arr>
    9314:	17ffffc8 	b	9234 <fwp_main_thread+0xa54>
    9318:	72003c3f 	tst	w1, #0xffff
    931c:	54fff8c1 	b.ne	9234 <fwp_main_thread+0xa54>  // b.any
    9320:	17ffffbd 	b	9214 <fwp_main_thread+0xa34>
    9324:	72003c3f 	tst	w1, #0xffff
    9328:	54fff281 	b.ne	9178 <fwp_main_thread+0x998>  // b.any
    932c:	17ffff8e 	b	9164 <fwp_main_thread+0x984>
    9330:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x4f0>
    9334:	9108e000 	add	x0, x0, #0x238
    9338:	a91773fb 	stp	x27, x28, [sp, #368]
    933c:	97ffe811 	bl	3380 <ad_raw_fail>
    9340:	a91773fb 	stp	x27, x28, [sp, #368]
    9344:	97ffe557 	bl	28a0 <__stack_chk_fail@plt>
    9348:	ca5c4780 	eor	x0, x28, x28, lsr #17
    934c:	91188262 	add	x2, x19, #0x620
    9350:	ca402400 	eor	x0, x0, x0, lsr #9
    9354:	92401c00 	and	x0, x0, #0xff
    9358:	910a2401 	add	x1, x0, #0x289
    935c:	8b000c40 	add	x0, x2, x0, lsl #3
    9360:	8b010c41 	add	x1, x2, x1, lsl #3
    9364:	f94a2400 	ldr	x0, [x0, #5192]
    9368:	b40002e0 	cbz	x0, 93c4 <fwp_main_thread+0xbe4>
    936c:	f9400002 	ldr	x2, [x0]
    9370:	eb02039f 	cmp	x28, x2
    9374:	54000100 	b.eq	9394 <fwp_main_thread+0xbb4>  // b.none
    9378:	91004001 	add	x1, x0, #0x10
    937c:	f9400800 	ldr	x0, [x0, #16]
    9380:	17fffffa 	b	9368 <fwp_main_thread+0xb88>
    9384:	f9000be0 	str	x0, [sp, #16]
    9388:	97ffec0b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    938c:	f9400be0 	ldr	x0, [sp, #16]
    9390:	17ffff78 	b	9170 <fwp_main_thread+0x990>
    9394:	f9400021 	ldr	x1, [x1]
    9398:	f9400420 	ldr	x0, [x1, #8]
    939c:	d1000400 	sub	x0, x0, #0x1
    93a0:	f9000420 	str	x0, [x1, #8]
    93a4:	f103f81f 	cmp	x0, #0xfe
    93a8:	54fff461 	b.ne	9234 <fwp_main_thread+0xa54>  // b.any
    93ac:	39400380 	ldrb	w0, [x28]
    93b0:	7103fc1f 	cmp	w0, #0xff
    93b4:	540000e0 	b.eq	93d0 <fwp_main_thread+0xbf0>  // b.none
    93b8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    93bc:	39000380 	strb	w0, [x28]
    93c0:	17ffff9d 	b	9234 <fwp_main_thread+0xa54>
    93c4:	90000000 	adrp	x0, 9000 <fwp_main_thread+0x820>
    93c8:	9139a000 	add	x0, x0, #0xe68
    93cc:	97ffebda 	bl	4334 <fwp_trap>
    93d0:	aa1c03e0 	mov	x0, x28
    93d4:	97ffebf8 	bl	43b4 <fwp_rc_forget_slot.part.0>
    93d8:	17fffff8 	b	93b8 <fwp_main_thread+0xbd8>
    93dc:	a91773fb 	stp	x27, x28, [sp, #368]
    93e0:	97ffe544 	bl	28f0 <abort@plt>
    93e4:	d503201f 	nop
    93e8:	d503201f 	nop
    93ec:	d503201f 	nop

00000000000093f0 <__divti3>:
    93f0:	d503245f 	bti	c
    93f4:	d2800004 	mov	x4, #0x0                   	// #0
    93f8:	b7f80721 	tbnz	x1, #63, 94dc <__divti3+0xec>
    93fc:	b6f80083 	tbz	x3, #63, 940c <__divti3+0x1c>
    9400:	eb0203e2 	negs	x2, x2
    9404:	aa2403e4 	mvn	x4, x4
    9408:	da0303e3 	ngc	x3, x3
    940c:	aa0203e6 	mov	x6, x2
    9410:	aa0003e7 	mov	x7, x0
    9414:	aa0103e5 	mov	x5, x1
    9418:	b5000583 	cbnz	x3, 94c8 <__divti3+0xd8>
    941c:	eb01005f 	cmp	x2, x1
    9420:	54000e69 	b.ls	95ec <__divti3+0x1fc>  // b.plast
    9424:	dac01040 	clz	x0, x2
    9428:	b40000e0 	cbz	x0, 9444 <__divti3+0x54>
    942c:	4b0003e1 	neg	w1, w0
    9430:	9ac020a5 	lsl	x5, x5, x0
    9434:	9ac02046 	lsl	x6, x2, x0
    9438:	9ac124e1 	lsr	x1, x7, x1
    943c:	aa050025 	orr	x5, x1, x5
    9440:	9ac020e7 	lsl	x7, x7, x0
    9444:	d360fcc8 	lsr	x8, x6, #32
    9448:	92407cc2 	and	x2, x6, #0xffffffff
    944c:	9ac808a3 	udiv	x3, x5, x8
    9450:	9b089465 	msub	x5, x3, x8, x5
    9454:	aa0303e0 	mov	x0, x3
    9458:	9b037c41 	mul	x1, x2, x3
    945c:	93c780a5 	extr	x5, x5, x7, #32
    9460:	eb05003f 	cmp	x1, x5
    9464:	540000a9 	b.ls	9478 <__divti3+0x88>  // b.plast
    9468:	ab0500c5 	adds	x5, x6, x5
    946c:	d1000460 	sub	x0, x3, #0x1
    9470:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9474:	540015a8 	b.hi	9728 <__divti3+0x338>  // b.pmore
    9478:	cb0100a5 	sub	x5, x5, x1
    947c:	9ac808a3 	udiv	x3, x5, x8
    9480:	9b089465 	msub	x5, x3, x8, x5
    9484:	aa0303e1 	mov	x1, x3
    9488:	9b037c42 	mul	x2, x2, x3
    948c:	aa0703e3 	mov	x3, x7
    9490:	b3607ca3 	bfi	x3, x5, #32, #32
    9494:	eb03005f 	cmp	x2, x3
    9498:	540000c9 	b.ls	94b0 <__divti3+0xc0>  // b.plast
    949c:	ab0300c3 	adds	x3, x6, x3
    94a0:	d1000425 	sub	x5, x1, #0x1
    94a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    94a8:	d1000821 	sub	x1, x1, #0x2
    94ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    94b0:	aa008020 	orr	x0, x1, x0, lsl #32
    94b4:	d2800001 	mov	x1, #0x0                   	// #0
    94b8:	b4000064 	cbz	x4, 94c4 <__divti3+0xd4>
    94bc:	eb0003e0 	negs	x0, x0
    94c0:	da0103e1 	ngc	x1, x1
    94c4:	d65f03c0 	ret
    94c8:	eb01007f 	cmp	x3, x1
    94cc:	54000109 	b.ls	94ec <__divti3+0xfc>  // b.plast
    94d0:	d2800001 	mov	x1, #0x0                   	// #0
    94d4:	d2800000 	mov	x0, #0x0                   	// #0
    94d8:	17fffff8 	b	94b8 <__divti3+0xc8>
    94dc:	eb0003e0 	negs	x0, x0
    94e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    94e4:	da0103e1 	ngc	x1, x1
    94e8:	17ffffc5 	b	93fc <__divti3+0xc>
    94ec:	dac01067 	clz	x7, x3
    94f0:	b40010e7 	cbz	x7, 970c <__divti3+0x31c>
    94f4:	d2800805 	mov	x5, #0x40                  	// #64
    94f8:	cb0700a5 	sub	x5, x5, x7
    94fc:	9ac72063 	lsl	x3, x3, x7
    9500:	9ac52448 	lsr	x8, x2, x5
    9504:	aa030108 	orr	x8, x8, x3
    9508:	9ac52426 	lsr	x6, x1, x5
    950c:	92407d0a 	and	x10, x8, #0xffffffff
    9510:	d360fd09 	lsr	x9, x8, #32
    9514:	9ac52403 	lsr	x3, x0, x5
    9518:	9ac72021 	lsl	x1, x1, x7
    951c:	aa010063 	orr	x3, x3, x1
    9520:	9ac72042 	lsl	x2, x2, x7
    9524:	9ac908cb 	udiv	x11, x6, x9
    9528:	9b099965 	msub	x5, x11, x9, x6
    952c:	aa0b03e1 	mov	x1, x11
    9530:	9b0b7d46 	mul	x6, x10, x11
    9534:	93c380a5 	extr	x5, x5, x3, #32
    9538:	eb0500df 	cmp	x6, x5
    953c:	540000a9 	b.ls	9550 <__divti3+0x160>  // b.plast
    9540:	ab050105 	adds	x5, x8, x5
    9544:	d1000561 	sub	x1, x11, #0x1
    9548:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    954c:	54000f48 	b.hi	9734 <__divti3+0x344>  // b.pmore
    9550:	cb0600a6 	sub	x6, x5, x6
    9554:	9ac908cb 	udiv	x11, x6, x9
    9558:	9b099969 	msub	x9, x11, x9, x6
    955c:	aa0b03e5 	mov	x5, x11
    9560:	9b0b7d4a 	mul	x10, x10, x11
    9564:	b3607d23 	bfi	x3, x9, #32, #32
    9568:	eb03015f 	cmp	x10, x3
    956c:	540000a9 	b.ls	9580 <__divti3+0x190>  // b.plast
    9570:	ab030103 	adds	x3, x8, x3
    9574:	d1000565 	sub	x5, x11, #0x1
    9578:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    957c:	54000e28 	b.hi	9740 <__divti3+0x350>  // b.pmore
    9580:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9584:	92407c48 	and	x8, x2, #0xffffffff
    9588:	2a0503e5 	mov	w5, w5
    958c:	d360fc42 	lsr	x2, x2, #32
    9590:	d360fc26 	lsr	x6, x1, #32
    9594:	cb0a0063 	sub	x3, x3, x10
    9598:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    959c:	9b087caa 	mul	x10, x5, x8
    95a0:	9b087cc8 	mul	x8, x6, x8
    95a4:	9b0220a5 	madd	x5, x5, x2, x8
    95a8:	9b027cc6 	mul	x6, x6, x2
    95ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    95b0:	8b0900c5 	add	x5, x6, x9
    95b4:	eb02011f 	cmp	x8, x2
    95b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    95bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    95c0:	eb06007f 	cmp	x3, x6
    95c4:	540000e3 	b.cc	95e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    95c8:	92407d4a 	and	x10, x10, #0xffffffff
    95cc:	9ac72000 	lsl	x0, x0, x7
    95d0:	8b028142 	add	x2, x10, x2, lsl #32
    95d4:	eb02001f 	cmp	x0, x2
    95d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    95dc:	54000a01 	b.ne	971c <__divti3+0x32c>  // b.any
    95e0:	d1000420 	sub	x0, x1, #0x1
    95e4:	d2800001 	mov	x1, #0x0                   	// #0
    95e8:	17ffffb4 	b	94b8 <__divti3+0xc8>
    95ec:	b5000062 	cbnz	x2, 95f8 <__divti3+0x208>
    95f0:	d2800022 	mov	x2, #0x1                   	// #1
    95f4:	9ac30846 	udiv	x6, x2, x3
    95f8:	dac010c8 	clz	x8, x6
    95fc:	b5000408 	cbnz	x8, 967c <__divti3+0x28c>
    9600:	d360fcc9 	lsr	x9, x6, #32
    9604:	92407cc5 	and	x5, x6, #0xffffffff
    9608:	cb060023 	sub	x3, x1, x6
    960c:	d2800021 	mov	x1, #0x1                   	// #1
    9610:	9ac90868 	udiv	x8, x3, x9
    9614:	9b098d03 	msub	x3, x8, x9, x3
    9618:	aa0803e0 	mov	x0, x8
    961c:	9b057d02 	mul	x2, x8, x5
    9620:	93c78063 	extr	x3, x3, x7, #32
    9624:	eb03005f 	cmp	x2, x3
    9628:	540000a9 	b.ls	963c <__divti3+0x24c>  // b.plast
    962c:	ab0300c3 	adds	x3, x6, x3
    9630:	d1000500 	sub	x0, x8, #0x1
    9634:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9638:	54000968 	b.hi	9764 <__divti3+0x374>  // b.pmore
    963c:	cb020063 	sub	x3, x3, x2
    9640:	9ac90862 	udiv	x2, x3, x9
    9644:	aa0203e8 	mov	x8, x2
    9648:	9b098c42 	msub	x2, x2, x9, x3
    964c:	aa0703e3 	mov	x3, x7
    9650:	9b057d05 	mul	x5, x8, x5
    9654:	b3607c43 	bfi	x3, x2, #32, #32
    9658:	eb0300bf 	cmp	x5, x3
    965c:	540000c9 	b.ls	9674 <__divti3+0x284>  // b.plast
    9660:	ab0300c2 	adds	x2, x6, x3
    9664:	d1000503 	sub	x3, x8, #0x1
    9668:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    966c:	d1000908 	sub	x8, x8, #0x2
    9670:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9674:	aa008100 	orr	x0, x8, x0, lsl #32
    9678:	17ffff90 	b	94b8 <__divti3+0xc8>
    967c:	9ac820c6 	lsl	x6, x6, x8
    9680:	d2800803 	mov	x3, #0x40                  	// #64
    9684:	cb080063 	sub	x3, x3, x8
    9688:	d360fcc9 	lsr	x9, x6, #32
    968c:	9ac82027 	lsl	x7, x1, x8
    9690:	92407cc5 	and	x5, x6, #0xffffffff
    9694:	9ac32422 	lsr	x2, x1, x3
    9698:	9ac32403 	lsr	x3, x0, x3
    969c:	aa070063 	orr	x3, x3, x7
    96a0:	9ac9084a 	udiv	x10, x2, x9
    96a4:	9ac82007 	lsl	x7, x0, x8
    96a8:	9b098940 	msub	x0, x10, x9, x2
    96ac:	aa0a03e1 	mov	x1, x10
    96b0:	9b0a7ca2 	mul	x2, x5, x10
    96b4:	93c38000 	extr	x0, x0, x3, #32
    96b8:	eb00005f 	cmp	x2, x0
    96bc:	540000a9 	b.ls	96d0 <__divti3+0x2e0>  // b.plast
    96c0:	ab0000c0 	adds	x0, x6, x0
    96c4:	d1000541 	sub	x1, x10, #0x1
    96c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    96cc:	54000468 	b.hi	9758 <__divti3+0x368>  // b.pmore
    96d0:	cb020000 	sub	x0, x0, x2
    96d4:	9ac9080a 	udiv	x10, x0, x9
    96d8:	9b098140 	msub	x0, x10, x9, x0
    96dc:	aa0a03e2 	mov	x2, x10
    96e0:	9b0a7ca8 	mul	x8, x5, x10
    96e4:	b3607c03 	bfi	x3, x0, #32, #32
    96e8:	eb03011f 	cmp	x8, x3
    96ec:	540000a9 	b.ls	9700 <__divti3+0x310>  // b.plast
    96f0:	ab0300c3 	adds	x3, x6, x3
    96f4:	d1000542 	sub	x2, x10, #0x1
    96f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    96fc:	54000288 	b.hi	974c <__divti3+0x35c>  // b.pmore
    9700:	cb080063 	sub	x3, x3, x8
    9704:	aa018041 	orr	x1, x2, x1, lsl #32
    9708:	17ffffc2 	b	9610 <__divti3+0x220>
    970c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9710:	d2800001 	mov	x1, #0x0                   	// #0
    9714:	9a9f87e0 	cset	x0, ls	// ls = plast
    9718:	17ffff68 	b	94b8 <__divti3+0xc8>
    971c:	aa0103e0 	mov	x0, x1
    9720:	d2800001 	mov	x1, #0x0                   	// #0
    9724:	17ffff65 	b	94b8 <__divti3+0xc8>
    9728:	d1000860 	sub	x0, x3, #0x2
    972c:	8b0600a5 	add	x5, x5, x6
    9730:	17ffff52 	b	9478 <__divti3+0x88>
    9734:	d1000961 	sub	x1, x11, #0x2
    9738:	8b0800a5 	add	x5, x5, x8
    973c:	17ffff85 	b	9550 <__divti3+0x160>
    9740:	d1000965 	sub	x5, x11, #0x2
    9744:	8b080063 	add	x3, x3, x8
    9748:	17ffff8e 	b	9580 <__divti3+0x190>
    974c:	d1000942 	sub	x2, x10, #0x2
    9750:	8b060063 	add	x3, x3, x6
    9754:	17ffffeb 	b	9700 <__divti3+0x310>
    9758:	d1000941 	sub	x1, x10, #0x2
    975c:	8b060000 	add	x0, x0, x6
    9760:	17ffffdc 	b	96d0 <__divti3+0x2e0>
    9764:	d1000900 	sub	x0, x8, #0x2
    9768:	8b060063 	add	x3, x3, x6
    976c:	17ffffb4 	b	963c <__divti3+0x24c>

0000000000009770 <__modti3>:
    9770:	d503245f 	bti	c
    9774:	d2800004 	mov	x4, #0x0                   	// #0
    9778:	b6f80081 	tbz	x1, #63, 9788 <__modti3+0x18>
    977c:	eb0003e0 	negs	x0, x0
    9780:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9784:	da0103e1 	ngc	x1, x1
    9788:	f100007f 	cmp	x3, #0x0
    978c:	5400128b 	b.lt	99dc <__modti3+0x26c>  // b.tstop
    9790:	aa0003e7 	mov	x7, x0
    9794:	aa0103e6 	mov	x6, x1
    9798:	540004e1 	b.ne	9834 <__modti3+0xc4>  // b.any
    979c:	eb02003f 	cmp	x1, x2
    97a0:	54000dc2 	b.cs	9958 <__modti3+0x1e8>  // b.hs, b.nlast
    97a4:	dac01043 	clz	x3, x2
    97a8:	aa0303e5 	mov	x5, x3
    97ac:	b40000e3 	cbz	x3, 97c8 <__modti3+0x58>
    97b0:	4b0303e6 	neg	w6, w3
    97b4:	9ac32021 	lsl	x1, x1, x3
    97b8:	9ac32042 	lsl	x2, x2, x3
    97bc:	9ac62406 	lsr	x6, x0, x6
    97c0:	aa0100c6 	orr	x6, x6, x1
    97c4:	9ac32007 	lsl	x7, x0, x3
    97c8:	d360fc40 	lsr	x0, x2, #32
    97cc:	92407c43 	and	x3, x2, #0xffffffff
    97d0:	9ac008c1 	udiv	x1, x6, x0
    97d4:	9b009826 	msub	x6, x1, x0, x6
    97d8:	9b017c61 	mul	x1, x3, x1
    97dc:	93c780c6 	extr	x6, x6, x7, #32
    97e0:	eb06003f 	cmp	x1, x6
    97e4:	540000a9 	b.ls	97f8 <__modti3+0x88>  // b.plast
    97e8:	ab060046 	adds	x6, x2, x6
    97ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    97f0:	8b0200c8 	add	x8, x6, x2
    97f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    97f8:	cb0100c6 	sub	x6, x6, x1
    97fc:	9ac008c8 	udiv	x8, x6, x0
    9800:	9b009901 	msub	x1, x8, x0, x6
    9804:	aa0703e0 	mov	x0, x7
    9808:	9b087c63 	mul	x3, x3, x8
    980c:	b3607c20 	bfi	x0, x1, #32, #32
    9810:	eb00007f 	cmp	x3, x0
    9814:	54001088 	b.hi	9a24 <__modti3+0x2b4>  // b.pmore
    9818:	cb030000 	sub	x0, x0, x3
    981c:	9ac52400 	lsr	x0, x0, x5
    9820:	d2800001 	mov	x1, #0x0                   	// #0
    9824:	b4000064 	cbz	x4, 9830 <__modti3+0xc0>
    9828:	eb0003e0 	negs	x0, x0
    982c:	da0103e1 	ngc	x1, x1
    9830:	d65f03c0 	ret
    9834:	dac01066 	clz	x6, x3
    9838:	eb03003f 	cmp	x1, x3
    983c:	54ffff43 	b.cc	9824 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9840:	93407cc5 	sxtw	x5, w6
    9844:	d2800808 	mov	x8, #0x40                  	// #64
    9848:	cb050108 	sub	x8, x8, x5
    984c:	9ac62063 	lsl	x3, x3, x6
    9850:	9ac62025 	lsl	x5, x1, x6
    9854:	9ac82447 	lsr	x7, x2, x8
    9858:	aa0300e7 	orr	x7, x7, x3
    985c:	9ac82423 	lsr	x3, x1, x8
    9860:	92407cec 	and	x12, x7, #0xffffffff
    9864:	d360fcea 	lsr	x10, x7, #32
    9868:	9ac82401 	lsr	x1, x0, x8
    986c:	aa050021 	orr	x1, x1, x5
    9870:	9ac62042 	lsl	x2, x2, x6
    9874:	9ac62000 	lsl	x0, x0, x6
    9878:	9aca086b 	udiv	x11, x3, x10
    987c:	9b0a8d63 	msub	x3, x11, x10, x3
    9880:	aa0b03e5 	mov	x5, x11
    9884:	9b0b7d89 	mul	x9, x12, x11
    9888:	93c18063 	extr	x3, x3, x1, #32
    988c:	eb03013f 	cmp	x9, x3
    9890:	540000a9 	b.ls	98a4 <__modti3+0x134>  // b.plast
    9894:	ab0300e3 	adds	x3, x7, x3
    9898:	d1000565 	sub	x5, x11, #0x1
    989c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    98a0:	54001168 	b.hi	9acc <__modti3+0x35c>  // b.pmore
    98a4:	cb090063 	sub	x3, x3, x9
    98a8:	9aca086b 	udiv	x11, x3, x10
    98ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    98b0:	aa0b03e9 	mov	x9, x11
    98b4:	9b0b7d8c 	mul	x12, x12, x11
    98b8:	b3607d41 	bfi	x1, x10, #32, #32
    98bc:	eb01019f 	cmp	x12, x1
    98c0:	540000a9 	b.ls	98d4 <__modti3+0x164>  // b.plast
    98c4:	ab0100e1 	adds	x1, x7, x1
    98c8:	d1000569 	sub	x9, x11, #0x1
    98cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    98d0:	54000f88 	b.hi	9ac0 <__modti3+0x350>  // b.pmore
    98d4:	aa058123 	orr	x3, x9, x5, lsl #32
    98d8:	92407c4b 	and	x11, x2, #0xffffffff
    98dc:	2a0903e9 	mov	w9, w9
    98e0:	d360fc4a 	lsr	x10, x2, #32
    98e4:	d360fc63 	lsr	x3, x3, #32
    98e8:	cb0c0021 	sub	x1, x1, x12
    98ec:	aa0a03ec 	mov	x12, x10
    98f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    98f4:	9b0b7d25 	mul	x5, x9, x11
    98f8:	9b0b7c6b 	mul	x11, x3, x11
    98fc:	9b0a2d29 	madd	x9, x9, x10, x11
    9900:	92407caa 	and	x10, x5, #0xffffffff
    9904:	9b0c7c63 	mul	x3, x3, x12
    9908:	8b458125 	add	x5, x9, x5, lsr #32
    990c:	8b0d0069 	add	x9, x3, x13
    9910:	eb05017f 	cmp	x11, x5
    9914:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9918:	8b058149 	add	x9, x10, x5, lsl #32
    991c:	8b458063 	add	x3, x3, x5, lsr #32
    9920:	eb03003f 	cmp	x1, x3
    9924:	54000063 	b.cc	9930 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9928:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    992c:	54000082 	b.cs	993c <__modti3+0x1cc>  // b.hs, b.nlast
    9930:	eb020129 	subs	x9, x9, x2
    9934:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9938:	cb070063 	sub	x3, x3, x7
    993c:	eb090000 	subs	x0, x0, x9
    9940:	da030021 	sbc	x1, x1, x3
    9944:	9ac62400 	lsr	x0, x0, x6
    9948:	9ac82028 	lsl	x8, x1, x8
    994c:	aa000100 	orr	x0, x8, x0
    9950:	9ac62421 	lsr	x1, x1, x6
    9954:	17ffffb4 	b	9824 <__modti3+0xb4>
    9958:	b5000062 	cbnz	x2, 9964 <__modti3+0x1f4>
    995c:	d2800023 	mov	x3, #0x1                   	// #1
    9960:	9ac20862 	udiv	x2, x3, x2
    9964:	dac01048 	clz	x8, x2
    9968:	aa0803e5 	mov	x5, x8
    996c:	b5000668 	cbnz	x8, 9a38 <__modti3+0x2c8>
    9970:	cb020020 	sub	x0, x1, x2
    9974:	d360fc49 	lsr	x9, x2, #32
    9978:	92407c4a 	and	x10, x2, #0xffffffff
    997c:	9ac90801 	udiv	x1, x0, x9
    9980:	9b098020 	msub	x0, x1, x9, x0
    9984:	9b0a7c21 	mul	x1, x1, x10
    9988:	93c78000 	extr	x0, x0, x7, #32
    998c:	eb00003f 	cmp	x1, x0
    9990:	540000a9 	b.ls	99a4 <__modti3+0x234>  // b.plast
    9994:	ab000040 	adds	x0, x2, x0
    9998:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    999c:	8b020003 	add	x3, x0, x2
    99a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    99a4:	cb010001 	sub	x1, x0, x1
    99a8:	9ac90820 	udiv	x0, x1, x9
    99ac:	9b098403 	msub	x3, x0, x9, x1
    99b0:	aa0703e1 	mov	x1, x7
    99b4:	9b0a7c00 	mul	x0, x0, x10
    99b8:	b3607c61 	bfi	x1, x3, #32, #32
    99bc:	eb01001f 	cmp	x0, x1
    99c0:	540000a9 	b.ls	99d4 <__modti3+0x264>  // b.plast
    99c4:	ab010041 	adds	x1, x2, x1
    99c8:	8b020022 	add	x2, x1, x2
    99cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    99d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    99d4:	cb000020 	sub	x0, x1, x0
    99d8:	17ffff91 	b	981c <__modti3+0xac>
    99dc:	eb0203e5 	negs	x5, x2
    99e0:	aa0003e7 	mov	x7, x0
    99e4:	da0303e8 	ngc	x8, x3
    99e8:	aa0503e2 	mov	x2, x5
    99ec:	aa0803e3 	mov	x3, x8
    99f0:	aa0103e6 	mov	x6, x1
    99f4:	b4ffed48 	cbz	x8, 979c <__modti3+0x2c>
    99f8:	eb01011f 	cmp	x8, x1
    99fc:	54fff148 	b.hi	9824 <__modti3+0xb4>  // b.pmore
    9a00:	dac01109 	clz	x9, x8
    9a04:	2a0903e6 	mov	w6, w9
    9a08:	b5fff1c9 	cbnz	x9, 9840 <__modti3+0xd0>
    9a0c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9a10:	54000068 	b.hi	9a1c <__modti3+0x2ac>  // b.pmore
    9a14:	eb050007 	subs	x7, x0, x5
    9a18:	da080021 	sbc	x1, x1, x8
    9a1c:	aa0703e0 	mov	x0, x7
    9a20:	17ffff81 	b	9824 <__modti3+0xb4>
    9a24:	ab000040 	adds	x0, x2, x0
    9a28:	8b020002 	add	x2, x0, x2
    9a2c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9a30:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9a34:	17ffff79 	b	9818 <__modti3+0xa8>
    9a38:	9ac82042 	lsl	x2, x2, x8
    9a3c:	d2800803 	mov	x3, #0x40                  	// #64
    9a40:	cb080063 	sub	x3, x3, x8
    9a44:	d360fc49 	lsr	x9, x2, #32
    9a48:	9ac82027 	lsl	x7, x1, x8
    9a4c:	92407c4a 	and	x10, x2, #0xffffffff
    9a50:	9ac32426 	lsr	x6, x1, x3
    9a54:	9ac32403 	lsr	x3, x0, x3
    9a58:	aa070063 	orr	x3, x3, x7
    9a5c:	9ac908c1 	udiv	x1, x6, x9
    9a60:	9ac82007 	lsl	x7, x0, x8
    9a64:	9b099820 	msub	x0, x1, x9, x6
    9a68:	9b017d41 	mul	x1, x10, x1
    9a6c:	93c38000 	extr	x0, x0, x3, #32
    9a70:	eb00003f 	cmp	x1, x0
    9a74:	540000a9 	b.ls	9a88 <__modti3+0x318>  // b.plast
    9a78:	ab000040 	adds	x0, x2, x0
    9a7c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9a80:	8b020006 	add	x6, x0, x2
    9a84:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9a88:	cb010000 	sub	x0, x0, x1
    9a8c:	9ac90801 	udiv	x1, x0, x9
    9a90:	9b098026 	msub	x6, x1, x9, x0
    9a94:	aa0303e0 	mov	x0, x3
    9a98:	9b017d41 	mul	x1, x10, x1
    9a9c:	b3607cc0 	bfi	x0, x6, #32, #32
    9aa0:	eb00003f 	cmp	x1, x0
    9aa4:	540000a9 	b.ls	9ab8 <__modti3+0x348>  // b.plast
    9aa8:	ab000040 	adds	x0, x2, x0
    9aac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9ab0:	8b020003 	add	x3, x0, x2
    9ab4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9ab8:	cb010000 	sub	x0, x0, x1
    9abc:	17ffffb0 	b	997c <__modti3+0x20c>
    9ac0:	d1000969 	sub	x9, x11, #0x2
    9ac4:	8b070021 	add	x1, x1, x7
    9ac8:	17ffff83 	b	98d4 <__modti3+0x164>
    9acc:	d1000965 	sub	x5, x11, #0x2
    9ad0:	8b070063 	add	x3, x3, x7
    9ad4:	17ffff74 	b	98a4 <__modti3+0x134>
    9ad8:	d503201f 	nop
    9adc:	d503201f 	nop

0000000000009ae0 <atexit>:
    9ae0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9ae4:	f00000a2 	adrp	x2, 20000 <__data_start>
    9ae8:	d2800001 	mov	x1, #0x0                   	// #0
    9aec:	910003fd 	mov	x29, sp
    9af0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9af4:	f9400442 	ldr	x2, [x2, #8]
    9af8:	17ffe32a 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009afc <_fini>:
    9afc:	d503201f 	nop
    9b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9b04:	910003fd 	mov	x29, sp
    9b08:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9b0c:	d65f03c0 	ret
