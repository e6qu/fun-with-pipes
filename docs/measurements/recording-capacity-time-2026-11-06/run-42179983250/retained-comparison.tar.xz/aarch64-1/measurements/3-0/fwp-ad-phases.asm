
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000025 	adrp	x5, 9000 <fwp_main_thread+0xa50>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	913000a5 	add	x5, x5, #0xc00
    2b20:	f0000024 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91302084 	add	x4, x4, #0xc08
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	94000590 	bl	4190 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b7c:	f947ee94 	ldr	x20, [x20, #4056]
    2b80:	f9400282 	ldr	x2, [x20]
    2b84:	f90043f5 	str	x21, [sp, #128]
    2b88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b8c:	910182a1 	add	x1, x21, #0x60
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12730>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9006420 	str	x0, [x1, #200]
    2bac:	94000799 	bl	4a10 <fwp_now_ns>
    2bb0:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2bb4:	91398000 	add	x0, x0, #0xe60
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f3 	mov	x19, x0
    2bc8:	350008c1 	cbnz	w1, 2ce0 <main+0x180>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	350007e0 	cbnz	w0, 2cd4 <main+0x174>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b5000620 	cbnz	x0, 2cc8 <main+0x168>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f3 	add	x19, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1303e0 	mov	x0, x19
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007a0 	cbnz	w0, 2d28 <main+0x1c8>
    2c38:	aa1303e0 	mov	x0, x19
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000660 	cbnz	w0, 2d10 <main+0x1b0>
    2c48:	aa1303e1 	mov	x1, x19
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xa3c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	9116c042 	add	x2, x2, #0x5b0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	2a0103f3 	mov	w19, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	35000613 	cbnz	w19, 2d34 <main+0x1d4>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	910182b5 	add	x21, x21, #0x60
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435aa0 	ldr	w0, [x21, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	54000481 	b.ne	2d40 <main+0x1e0>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2ccc:	913a4000 	add	x0, x0, #0xe90
    2cd0:	94000530 	bl	4190 <fwp_trap>
    2cd4:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2cd8:	9139c000 	add	x0, x0, #0xe70
    2cdc:	9400052d 	bl	4190 <fwp_trap>
    2ce0:	910003e1 	mov	x1, sp
    2ce4:	52800142 	mov	w2, #0xa                   	// #10
    2ce8:	97ffff46 	bl	2a00 <strtoull@plt>
    2cec:	f94003e0 	ldr	x0, [sp]
    2cf0:	39400000 	ldrb	w0, [x0]
    2cf4:	35fff6c0 	cbnz	w0, 2bcc <main+0x6c>
    2cf8:	39400260 	ldrb	w0, [x19]
    2cfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2d00:	5100ac00 	sub	w0, w0, #0x2b
    2d04:	6a01001f 	tst	w0, w1
    2d08:	54fff620 	b.eq	2bcc <main+0x6c>  // b.none
    2d0c:	17ffffbf 	b	2c08 <main+0xa8>
    2d10:	aa1303e0 	mov	x0, x19
    2d14:	97fffeeb 	bl	28c0 <pthread_attr_destroy@plt>
    2d18:	35000160 	cbnz	w0, 2d44 <main+0x1e4>
    2d1c:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2d20:	913ba000 	add	x0, x0, #0xee8
    2d24:	9400051b 	bl	4190 <fwp_trap>
    2d28:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2d2c:	913ae000 	add	x0, x0, #0xeb8
    2d30:	94000518 	bl	4190 <fwp_trap>
    2d34:	f0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    2d38:	913c4000 	add	x0, x0, #0xf10
    2d3c:	94000515 	bl	4190 <fwp_trap>
    2d40:	97fffef4 	bl	2910 <__stack_chk_fail@plt>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91014000 	add	x0, x0, #0x50
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91014021 	add	x1, x1, #0x50
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91014000 	add	x0, x0, #0x50
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91014021 	add	x1, x1, #0x50
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39414260 	ldrb	w0, [x19, #80]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39014260 	strb	w0, [x19, #80]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x780>
    2f34:	91164021 	add	x1, x1, #0x590
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403084 	ldr	x4, [x4, #96]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403063 	ldr	x3, [x3, #96]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403400 	ldr	x0, [x0, #104]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    30d0:	91222000 	add	x0, x0, #0x888
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	91018043 	add	x3, x2, #0x60
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	91018042 	add	x2, x2, #0x60
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x780>
    3198:	9115c021 	add	x1, x1, #0x570
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    31d0:	91228000 	add	x0, x0, #0x8a0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	91018294 	add	x20, x20, #0x60
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0xa50>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000036 	adrp	x22, 9000 <fwp_main_thread+0xa50>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	f0000038 	adrp	x24, a000 <_IO_stdin_used+0x780>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	9123a042 	add	x2, x2, #0x8e8
    3260:	912502d6 	add	x22, x22, #0x940
    3264:	910c6318 	add	x24, x24, #0x318
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000039 	adrp	x25, 9000 <fwp_main_thread+0xa50>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	9124e323 	add	x3, x25, #0x938
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91254000 	add	x0, x0, #0x950
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    3344:	911702a1 	add	x1, x21, #0x5c0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    3358:	9126c0a5 	add	x5, x5, #0x9b0
    335c:	911702a1 	add	x1, x21, #0x5c0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911702b7 	add	x23, x21, #0x5c0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911702b5 	add	x21, x21, #0x5c0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911702b5 	add	x21, x21, #0x5c0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    34e8:	9126a0a5 	add	x5, x5, #0x9a8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    35f0:	91222000 	add	x0, x0, #0x888
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	91018022 	add	x2, x1, #0x60
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	91018023 	add	x3, x1, #0x60
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	91018021 	add	x1, x1, #0x60
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	91018022 	add	x2, x1, #0x60
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	91018021 	add	x1, x1, #0x60
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91256021 	add	x1, x1, #0x958
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91258021 	add	x1, x1, #0x960
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    3860:	9125a021 	add	x1, x1, #0x968
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_format_g.constprop.0>:
    3880:	d10483ff 	sub	sp, sp, #0x120
    3884:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    3888:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    388c:	f947f442 	ldr	x2, [x2, #4072]
    3890:	9125c084 	add	x4, x4, #0x970
    3894:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3898:	9102c3fd 	add	x29, sp, #0xb0
    389c:	d2800803 	mov	x3, #0x40                  	// #64
    38a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    38a4:	93407c38 	sxtw	x24, w1
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	fd008be8 	str	d8, [sp, #272]
    38b0:	1e604008 	fmov	d8, d0
    38b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    38b8:	910083f4 	add	x20, sp, #0x20
    38bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38c0:	aa0003f5 	mov	x21, x0
    38c4:	a91073fb 	stp	x27, x28, [sp, #256]
    38c8:	5100071c 	sub	w28, w24, #0x1
    38cc:	2a1c03e5 	mov	w5, w28
    38d0:	f9400040 	ldr	x0, [x2]
    38d4:	f90057e0 	str	x0, [sp, #168]
    38d8:	d2800000 	mov	x0, #0x0                   	// #0
    38dc:	52800042 	mov	w2, #0x2                   	// #2
    38e0:	aa1403e0 	mov	x0, x20
    38e4:	97fffbe7 	bl	2880 <__snprintf_chk@plt>
    38e8:	52800ca1 	mov	w1, #0x65                  	// #101
    38ec:	aa1403e0 	mov	x0, x20
    38f0:	97fffc40 	bl	29f0 <strchr@plt>
    38f4:	aa0003f3 	mov	x19, x0
    38f8:	52800142 	mov	w2, #0xa                   	// #10
    38fc:	91000400 	add	x0, x0, #0x1
    3900:	d2800001 	mov	x1, #0x0                   	// #0
    3904:	97fffc2b 	bl	29b0 <strtol@plt>
    3908:	aa0003f7 	mov	x23, x0
    390c:	11001400 	add	w0, w0, #0x5
    3910:	7100541f 	cmp	w0, #0x15
    3914:	54000d68 	b.hi	3ac0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3918:	4b170385 	sub	w5, w28, w23
    391c:	710000bf 	cmp	w5, #0x0
    3920:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3924:	54000b80 	b.eq	3a94 <fwp_format_g.constprop.0+0x214>  // b.none
    3928:	394083e0 	ldrb	w0, [sp, #32]
    392c:	cb180273 	sub	x19, x19, x24
    3930:	91000673 	add	x19, x19, #0x1
    3934:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3938:	7100b41f 	cmp	w0, #0x2d
    393c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3940:	1a9f17e4 	cset	w4, eq	// eq = none
    3944:	cb010266 	sub	x6, x19, x1
    3948:	d10004da 	sub	x26, x6, #0x1
    394c:	540018a0 	b.eq	3c60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3950:	910183f9 	add	x25, sp, #0x60
    3954:	d280091b 	mov	x27, #0x48                  	// #72
    3958:	aa1903e7 	mov	x7, x25
    395c:	91000423 	add	x3, x1, #0x1
    3960:	91011cc6 	add	x6, x6, #0x47
    3964:	910004f6 	add	x22, x7, #0x1
    3968:	37f80ff7 	tbnz	w23, #31, 3b64 <fwp_format_g.constprop.0+0x2e4>
    396c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3970:	93407ef7 	sxtw	x23, w23
    3974:	390000e4 	strb	w4, [x7]
    3978:	aa1303e1 	mov	x1, x19
    397c:	aa1703e2 	mov	x2, x23
    3980:	aa1603e0 	mov	x0, x22
    3984:	b9000be5 	str	w5, [sp, #8]
    3988:	cb170374 	sub	x20, x27, x23
    398c:	a9011be3 	stp	x3, x6, [sp, #16]
    3990:	97fffb74 	bl	2760 <memcpy@plt>
    3994:	d1000694 	sub	x20, x20, #0x1
    3998:	f9400be3 	ldr	x3, [sp, #16]
    399c:	8b1702d6 	add	x22, x22, x23
    39a0:	aa1603e0 	mov	x0, x22
    39a4:	aa1a03e2 	mov	x2, x26
    39a8:	aa0303e1 	mov	x1, x3
    39ac:	aa1403e3 	mov	x3, x20
    39b0:	97fffbac 	bl	2860 <__memcpy_chk@plt>
    39b4:	8b1a02d6 	add	x22, x22, x26
    39b8:	f9400fe6 	ldr	x6, [sp, #24]
    39bc:	d2800900 	mov	x0, #0x48                  	// #72
    39c0:	b9400be5 	ldr	w5, [sp, #8]
    39c4:	8b170261 	add	x1, x19, x23
    39c8:	cb1400c3 	sub	x3, x6, x20
    39cc:	cb060294 	sub	x20, x20, x6
    39d0:	f101207f 	cmp	x3, #0x48
    39d4:	93407cb8 	sxtw	x24, w5
    39d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39dc:	aa1803e2 	mov	x2, x24
    39e0:	8b1802d3 	add	x19, x22, x24
    39e4:	8b140063 	add	x3, x3, x20
    39e8:	aa1603e0 	mov	x0, x22
    39ec:	97fffb9d 	bl	2860 <__memcpy_chk@plt>
    39f0:	cb190273 	sub	x19, x19, x25
    39f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    39f8:	eb00027f 	cmp	x19, x0
    39fc:	aa1903e1 	mov	x1, x25
    3a00:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a04:	aa1503e0 	mov	x0, x21
    3a08:	aa1303e2 	mov	x2, x19
    3a0c:	97fffb55 	bl	2760 <memcpy@plt>
    3a10:	38336abf 	strb	wzr, [x21, x19]
    3a14:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	97fffb61 	bl	27a0 <strlen@plt>
    3a20:	aa0003f3 	mov	x19, x0
    3a24:	528005c1 	mov	w1, #0x2e                  	// #46
    3a28:	aa1503e0 	mov	x0, x21
    3a2c:	97fffbf1 	bl	29f0 <strchr@plt>
    3a30:	b4000140 	cbz	x0, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a34:	b4000133 	cbz	x19, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a38:	aa1303e1 	mov	x1, x19
    3a3c:	d1000673 	sub	x19, x19, #0x1
    3a40:	38736aa0 	ldrb	w0, [x21, x19]
    3a44:	7100c01f 	cmp	w0, #0x30
    3a48:	54001001 	b.ne	3c48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    3a4c:	38336abf 	strb	wzr, [x21, x19]
    3a50:	b5ffff53 	cbnz	x19, 3a38 <fwp_format_g.constprop.0+0x1b8>
    3a54:	d503201f 	nop
    3a58:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a5c:	f947f400 	ldr	x0, [x0, #4072]
    3a60:	f94057e2 	ldr	x2, [sp, #168]
    3a64:	f9400001 	ldr	x1, [x0]
    3a68:	eb010042 	subs	x2, x2, x1
    3a6c:	d2800001 	mov	x1, #0x0                   	// #0
    3a70:	54001061 	b.ne	3c7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3a74:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a78:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a7c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a80:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a84:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a88:	fd408be8 	ldr	d8, [sp, #272]
    3a8c:	910483ff 	add	sp, sp, #0x120
    3a90:	d65f03c0 	ret
    3a94:	1e604100 	fmov	d0, d8
    3a98:	710000bf 	cmp	w5, #0x0
    3a9c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3aa0:	aa1503e0 	mov	x0, x21
    3aa4:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    3aa8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3aac:	91262084 	add	x4, x4, #0x988
    3ab0:	52800042 	mov	w2, #0x2                   	// #2
    3ab4:	d2803201 	mov	x1, #0x190                 	// #400
    3ab8:	97fffb72 	bl	2880 <__snprintf_chk@plt>
    3abc:	17ffffd7 	b	3a18 <fwp_format_g.constprop.0+0x198>
    3ac0:	cb140273 	sub	x19, x19, x20
    3ac4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ac8:	910183f9 	add	x25, sp, #0x60
    3acc:	aa1303e2 	mov	x2, x19
    3ad0:	aa1403e1 	mov	x1, x20
    3ad4:	aa1903e0 	mov	x0, x25
    3ad8:	d2800803 	mov	x3, #0x40                  	// #64
    3adc:	97fffb61 	bl	2860 <__memcpy_chk@plt>
    3ae0:	38336b3f 	strb	wzr, [x25, x19]
    3ae4:	aa1903e0 	mov	x0, x25
    3ae8:	528005c1 	mov	w1, #0x2e                  	// #46
    3aec:	97fffbc1 	bl	29f0 <strchr@plt>
    3af0:	b40001c0 	cbz	x0, 3b28 <fwp_format_g.constprop.0+0x2a8>
    3af4:	b50000b3 	cbnz	x19, 3b08 <fwp_format_g.constprop.0+0x288>
    3af8:	1400000c 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3afc:	381ff01f 	sturb	wzr, [x0, #-1]
    3b00:	f1000673 	subs	x19, x19, #0x1
    3b04:	54000120 	b.eq	3b28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3b08:	8b130320 	add	x0, x25, x19
    3b0c:	385ff001 	ldurb	w1, [x0, #-1]
    3b10:	7100c03f 	cmp	w1, #0x30
    3b14:	54ffff40 	b.eq	3afc <fwp_format_g.constprop.0+0x27c>  // b.none
    3b18:	d1000673 	sub	x19, x19, #0x1
    3b1c:	38736b20 	ldrb	w0, [x25, x19]
    3b20:	7100b81f 	cmp	w0, #0x2e
    3b24:	54000a80 	b.eq	3c74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3b28:	710002ff 	cmp	w23, #0x0
    3b2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3b30:	aa1903e5 	mov	x5, x25
    3b34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	52800566 	mov	w6, #0x2b                  	// #43
    3b40:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    3b44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b48:	9125e084 	add	x4, x4, #0x978
    3b4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b50:	52800042 	mov	w2, #0x2                   	// #2
    3b54:	d2803201 	mov	x1, #0x190                 	// #400
    3b58:	97fffb4a 	bl	2880 <__snprintf_chk@plt>
    3b5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b60:	17ffffbe 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3b64:	52800605 	mov	w5, #0x30                  	// #48
    3b68:	390000e5 	strb	w5, [x7]
    3b6c:	d100077b 	sub	x27, x27, #0x1
    3b70:	aa0303e1 	mov	x1, x3
    3b74:	aa1603e0 	mov	x0, x22
    3b78:	aa1b03e3 	mov	x3, x27
    3b7c:	aa1a03e2 	mov	x2, x26
    3b80:	f90007e6 	str	x6, [sp, #8]
    3b84:	b90013e4 	str	w4, [sp, #16]
    3b88:	8b1a02d6 	add	x22, x22, x26
    3b8c:	b9001be5 	str	w5, [sp, #24]
    3b90:	97fffb34 	bl	2860 <__memcpy_chk@plt>
    3b94:	f94007e6 	ldr	x6, [sp, #8]
    3b98:	2a3703e7 	mvn	w7, w23
    3b9c:	b94013e4 	ldr	w4, [sp, #16]
    3ba0:	cb1b00c1 	sub	x1, x6, x27
    3ba4:	cb06037b 	sub	x27, x27, x6
    3ba8:	f101203f 	cmp	x1, #0x48
    3bac:	d2800906 	mov	x6, #0x48                  	// #72
    3bb0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bb4:	8b1b0023 	add	x3, x1, x27
    3bb8:	310006ff 	cmn	w23, #0x1
    3bbc:	54000220 	b.eq	3c00 <fwp_format_g.constprop.0+0x380>  // b.none
    3bc0:	b9401be5 	ldr	w5, [sp, #24]
    3bc4:	d2800001 	mov	x1, #0x0                   	// #0
    3bc8:	f101207f 	cmp	x3, #0x48
    3bcc:	d1000462 	sub	x2, x3, #0x1
    3bd0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bd4:	38216ac5 	strb	w5, [x22, x1]
    3bd8:	cb030003 	sub	x3, x0, x3
    3bdc:	91000421 	add	x1, x1, #0x1
    3be0:	91000463 	add	x3, x3, #0x1
    3be4:	eb00007f 	cmp	x3, x0
    3be8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3bec:	cb000063 	sub	x3, x3, x0
    3bf0:	8b020063 	add	x3, x3, x2
    3bf4:	6b0100ff 	cmp	w7, w1
    3bf8:	54fffe8c 	b.gt	3bc8 <fwp_format_g.constprop.0+0x348>
    3bfc:	8b2742d6 	add	x22, x22, w7, uxtw
    3c00:	f101207f 	cmp	x3, #0x48
    3c04:	d2800905 	mov	x5, #0x48                  	// #72
    3c08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	cb0300a1 	sub	x1, x5, x3
    3c14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c18:	91000421 	add	x1, x1, #0x1
    3c1c:	d1000463 	sub	x3, x3, #0x1
    3c20:	eb05003f 	cmp	x1, x5
    3c24:	38001402 	strb	w2, [x0], #1
    3c28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c2c:	93407f82 	sxtw	x2, w28
    3c30:	cb050025 	sub	x5, x1, x5
    3c34:	aa1303e1 	mov	x1, x19
    3c38:	8b0300a3 	add	x3, x5, x3
    3c3c:	8b1802d3 	add	x19, x22, x24
    3c40:	97fffb08 	bl	2860 <__memcpy_chk@plt>
    3c44:	17ffff6b 	b	39f0 <fwp_format_g.constprop.0+0x170>
    3c48:	d1000421 	sub	x1, x1, #0x1
    3c4c:	38616aa0 	ldrb	w0, [x21, x1]
    3c50:	7100b81f 	cmp	w0, #0x2e
    3c54:	54fff021 	b.ne	3a58 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3c58:	38216abf 	strb	wzr, [x21, x1]
    3c5c:	17ffff7f 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3c60:	910187e7 	add	x7, sp, #0x61
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d28008fb 	mov	x27, #0x47                  	// #71
    3c6c:	390183e0 	strb	w0, [sp, #96]
    3c70:	17ffff3b 	b	395c <fwp_format_g.constprop.0+0xdc>
    3c74:	38336b3f 	strb	wzr, [x25, x19]
    3c78:	17ffffac 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3c7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c80:	97fffb24 	bl	2910 <__stack_chk_fail@plt>

0000000000003c84 <fwp_heap_report>:
    3c84:	d105c3ff 	sub	sp, sp, #0x170
    3c88:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    3c8c:	91170042 	add	x2, x2, #0x5c0
    3c90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3c94:	f947e821 	ldr	x1, [x1, #4048]
    3c98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c9c:	910443fd 	add	x29, sp, #0x110
    3ca0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ca4:	f947f400 	ldr	x0, [x0, #4072]
    3ca8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cac:	a91463f7 	stp	x23, x24, [sp, #320]
    3cb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3cc0:	f9400036 	ldr	x22, [x1]
    3cc4:	f9400001 	ldr	x1, [x0]
    3cc8:	f90087e1 	str	x1, [sp, #264]
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	f949e459 	ldr	x25, [x2, #5064]
    3cd4:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    3cd8:	f94a1057 	ldr	x23, [x2, #5152]
    3cdc:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    3ce0:	f94a1458 	ldr	x24, [x2, #5160]
    3ce4:	91264021 	add	x1, x1, #0x990
    3ce8:	91266000 	add	x0, x0, #0x998
    3cec:	97fffaed 	bl	28a0 <fopen@plt>
    3cf0:	b4000760 	cbz	x0, 3ddc <fwp_heap_report+0x158>
    3cf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3cf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3cfc:	aa0003f4 	mov	x20, x0
    3d00:	910023f3 	add	x19, sp, #0x8
    3d04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d08:	72aae915 	movk	w21, #0x5748, lsl #16
    3d0c:	d503201f 	nop
    3d10:	aa1403e2 	mov	x2, x20
    3d14:	aa1303e0 	mov	x0, x19
    3d18:	52802001 	mov	w1, #0x100                 	// #256
    3d1c:	97fffb6d 	bl	2ad0 <fgets@plt>
    3d20:	b4000280 	cbz	x0, 3d70 <fwp_heap_report+0xec>
    3d24:	b9400261 	ldr	w1, [x19]
    3d28:	6b15003f 	cmp	w1, w21
    3d2c:	54ffff21 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d30:	39401260 	ldrb	w0, [x19, #4]
    3d34:	7101341f 	cmp	w0, #0x4d
    3d38:	54fffec1 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d3c:	394037e0 	ldrb	w0, [sp, #13]
    3d40:	7100e81f 	cmp	w0, #0x3a
    3d44:	54fffe61 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d48:	52800142 	mov	w2, #0xa                   	// #10
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	91003be0 	add	x0, sp, #0xe
    3d54:	97fffb17 	bl	29b0 <strtol@plt>
    3d58:	aa1403e2 	mov	x2, x20
    3d5c:	aa0003fa 	mov	x26, x0
    3d60:	52802001 	mov	w1, #0x100                 	// #256
    3d64:	aa1303e0 	mov	x0, x19
    3d68:	97fffb5a 	bl	2ad0 <fgets@plt>
    3d6c:	b5fffdc0 	cbnz	x0, 3d24 <fwp_heap_report+0xa0>
    3d70:	aa1403e0 	mov	x0, x20
    3d74:	97fffac7 	bl	2890 <fclose@plt>
    3d78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d80:	f947f400 	ldr	x0, [x0, #4072]
    3d84:	f94087e2 	ldr	x2, [sp, #264]
    3d88:	f9400001 	ldr	x1, [x0]
    3d8c:	eb010042 	subs	x2, x2, x1
    3d90:	d2800001 	mov	x1, #0x0                   	// #0
    3d94:	54000281 	b.ne	3de4 <fwp_heap_report+0x160>  // b.any
    3d98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d9c:	aa1a03e6 	mov	x6, x26
    3da0:	aa1903e5 	mov	x5, x25
    3da4:	aa1803e4 	mov	x4, x24
    3da8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dac:	aa1703e3 	mov	x3, x23
    3db0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3db4:	aa1603e0 	mov	x0, x22
    3db8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dbc:	1e604121 	fmov	d1, d9
    3dc0:	1e604100 	fmov	d0, d8
    3dc4:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0xa50>
    3dc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3dcc:	9126e042 	add	x2, x2, #0x9b8
    3dd0:	9105c3ff 	add	sp, sp, #0x170
    3dd4:	52800041 	mov	w1, #0x2                   	// #2
    3dd8:	17fffaea 	b	2980 <__fprintf_chk@plt>
    3ddc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3de0:	17ffffe7 	b	3d7c <fwp_heap_report+0xf8>
    3de4:	a91253f3 	stp	x19, x20, [sp, #288]
    3de8:	97fffaca 	bl	2910 <__stack_chk_fail@plt>
    3dec:	d503201f 	nop

0000000000003df0 <fwp_heap_init>:
    3df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3df4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa40>
    3df8:	91130061 	add	x1, x3, #0x4c0
    3dfc:	910003fd 	mov	x29, sp
    3e00:	a90153f3 	stp	x19, x20, [sp, #16]
    3e04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    3e08:	91170262 	add	x2, x19, #0x5c0
    3e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e10:	52800024 	mov	w4, #0x1                   	// #1
    3e14:	52800200 	mov	w0, #0x10                  	// #16
    3e18:	b913a444 	str	w4, [x2, #5028]
    3e1c:	d503201f 	nop
    3e20:	b8004420 	str	w0, [x1], #4
    3e24:	11004000 	add	w0, w0, #0x10
    3e28:	7104401f 	cmp	w0, #0x110
    3e2c:	54ffffa1 	b.ne	3e20 <fwp_heap_init+0x30>  // b.any
    3e30:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0x780>
    3e34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa40>
    3e3c:	91140021 	add	x1, x1, #0x500
    3e40:	3dc16843 	ldr	q3, [x2, #1440]
    3e44:	d2800000 	mov	x0, #0x0                   	// #0
    3e48:	4e040401 	dup	v1.4s, v0.s[0]
    3e4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e50:	0f215400 	shl	v0.2s, v0.2s, #1
    3e54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e58:	3ca06821 	str	q1, [x1, x0]
    3e5c:	91004000 	add	x0, x0, #0x10
    3e60:	f101801f 	cmp	x0, #0x60
    3e64:	54ffff21 	b.ne	3e48 <fwp_heap_init+0x58>  // b.any
    3e68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa40>
    3e6c:	91130063 	add	x3, x3, #0x4c0
    3e70:	91158084 	add	x4, x4, #0x560
    3e74:	91170266 	add	x6, x19, #0x5c0
    3e78:	d2800002 	mov	x2, #0x0                   	// #0
    3e7c:	d2800000 	mov	x0, #0x0                   	// #0
    3e80:	d2880205 	mov	x5, #0x4010                	// #16400
    3e84:	d503201f 	nop
    3e88:	910f0001 	add	x1, x0, #0x3c0
    3e8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e90:	eb02003f 	cmp	x1, x2
    3e94:	540000a2 	b.cs	3ea8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e98:	91000400 	add	x0, x0, #0x1
    3e9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	54ffffa3 	b.cc	3e98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ea8:	91004042 	add	x2, x2, #0x10
    3eac:	38001480 	strb	w0, [x4], #1
    3eb0:	eb05005f 	cmp	x2, x5
    3eb4:	54fffea1 	b.ne	3e88 <fwp_heap_init+0x98>  // b.any
    3eb8:	528000b5 	mov	w21, #0x5                   	// #5
    3ebc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ec0:	14000004 	b	3ed0 <fwp_heap_init+0xe0>
    3ec4:	d342fe94 	lsr	x20, x20, #2
    3ec8:	710006b5 	subs	w21, w21, #0x1
    3ecc:	54000720 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3ed0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ed4:	d2800005 	mov	x5, #0x0                   	// #0
    3ed8:	aa1603e1 	mov	x1, x22
    3edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ee0:	52880443 	mov	w3, #0x4022                	// #16418
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	d2800000 	mov	x0, #0x0                   	// #0
    3eec:	97fffaad 	bl	29a0 <mmap@plt>
    3ef0:	aa0003e6 	mov	x6, x0
    3ef4:	b100041f 	cmn	x0, #0x1
    3ef8:	54fffe60 	b.eq	3ec4 <fwp_heap_init+0xd4>  // b.none
    3efc:	b40005a0 	cbz	x0, 3fb0 <fwp_heap_init+0x1c0>
    3f00:	d350fe94 	lsr	x20, x20, #16
    3f04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f08:	8b0000c7 	add	x7, x6, x0
    3f0c:	91170275 	add	x21, x19, #0x5c0
    3f10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f14:	8b140a81 	add	x1, x20, x20, lsl #2
    3f18:	d2800005 	mov	x5, #0x0                   	// #0
    3f1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f20:	d37df021 	lsl	x1, x1, #3
    3f24:	52880443 	mov	w3, #0x4022                	// #16418
    3f28:	52800002 	mov	w2, #0x0                   	// #0
    3f2c:	d2800000 	mov	x0, #0x0                   	// #0
    3f30:	f909daa7 	str	x7, [x21, #5040]
    3f34:	f909dea6 	str	x6, [x21, #5048]
    3f38:	f909e2b6 	str	x22, [x21, #5056]
    3f3c:	f909eab4 	str	x20, [x21, #5072]
    3f40:	f90a02a1 	str	x1, [x21, #5120]
    3f44:	97fffa97 	bl	29a0 <mmap@plt>
    3f48:	aa0003e1 	mov	x1, x0
    3f4c:	b100041f 	cmn	x0, #0x1
    3f50:	54000300 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3f54:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    3f58:	91290000 	add	x0, x0, #0xa40
    3f5c:	f909fea1 	str	x1, [x21, #5112]
    3f60:	97fffad0 	bl	2aa0 <getenv@plt>
    3f64:	52800002 	mov	w2, #0x0                   	// #0
    3f68:	aa0003e1 	mov	x1, x0
    3f6c:	b40000e0 	cbz	x0, 3f88 <fwp_heap_init+0x198>
    3f70:	39400000 	ldrb	w0, [x0]
    3f74:	340000a0 	cbz	w0, 3f88 <fwp_heap_init+0x198>
    3f78:	7100c000 	subs	w0, w0, #0x30
    3f7c:	54000120 	b.eq	3fa0 <fwp_heap_init+0x1b0>  // b.none
    3f80:	7100001f 	cmp	w0, #0x0
    3f84:	1a9f07e2 	cset	w2, ne	// ne = any
    3f88:	91170273 	add	x19, x19, #0x5c0
    3f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f90:	b913aa62 	str	w2, [x19, #5032]
    3f94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f9c:	d65f03c0 	ret
    3fa0:	39400420 	ldrb	w0, [x1, #1]
    3fa4:	7100001f 	cmp	w0, #0x0
    3fa8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fac:	17fffff7 	b	3f88 <fwp_heap_init+0x198>
    3fb0:	97fffc40 	bl	30b0 <fwp_heap_oom>

0000000000003fb4 <fwp_wake_io>:
    3fb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fb8:	91018122 	add	x2, x9, #0x60
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	5280000a 	mov	w10, #0x0                   	// #0
    3fc4:	f9403c46 	ldr	x6, [x2, #120]
    3fc8:	52800008 	mov	w8, #0x0                   	// #0
    3fcc:	4f000400 	movi	v0.4s, #0x0
    3fd0:	52800027 	mov	w7, #0x1                   	// #1
    3fd4:	aa0103e2 	mov	x2, x1
    3fd8:	b4000321 	cbz	x1, 403c <fwp_wake_io+0x88>
    3fdc:	f9408c25 	ldr	x5, [x1, #280]
    3fe0:	39015c27 	strb	w7, [x1, #87]
    3fe4:	b4000165 	cbz	x5, 4010 <fwp_wake_io+0x5c>
    3fe8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3fec:	b4000364 	cbz	x4, 4058 <fwp_wake_io+0xa4>
    3ff0:	f9009483 	str	x3, [x4, #296]
    3ff4:	f9409423 	ldr	x3, [x1, #296]
    3ff8:	b4000043 	cbz	x3, 4000 <fwp_wake_io+0x4c>
    3ffc:	f9009064 	str	x4, [x3, #288]
    4000:	91080023 	add	x3, x1, #0x200
    4004:	f900943f 	str	xzr, [x1, #296]
    4008:	3c918060 	stur	q0, [x3, #-232]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	f9402843 	ldr	x3, [x2, #80]
    4014:	f2001c7f 	tst	x3, #0xff000000ff
    4018:	54fffde1 	b.ne	3fd4 <fwp_wake_io+0x20>  // b.any
    401c:	39015047 	strb	w7, [x2, #84]
    4020:	f900805f 	str	xzr, [x2, #256]
    4024:	b40001e6 	cbz	x6, 4060 <fwp_wake_io+0xac>
    4028:	f90080c2 	str	x2, [x6, #256]
    402c:	aa0203e6 	mov	x6, x2
    4030:	52800028 	mov	w8, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b5fffd21 	cbnz	x1, 3fdc <fwp_wake_io+0x28>
    403c:	3400006a 	cbz	w10, 4048 <fwp_wake_io+0x94>
    4040:	91018120 	add	x0, x9, #0x60
    4044:	f900400b 	str	x11, [x0, #128]
    4048:	34000068 	cbz	w8, 4054 <fwp_wake_io+0xa0>
    404c:	91018129 	add	x9, x9, #0x60
    4050:	f9003d26 	str	x6, [x9, #120]
    4054:	d65f03c0 	ret
    4058:	f90000a3 	str	x3, [x5]
    405c:	17ffffe7 	b	3ff8 <fwp_wake_io+0x44>
    4060:	aa0203eb 	mov	x11, x2
    4064:	5280002a 	mov	w10, #0x1                   	// #1
    4068:	17fffff1 	b	402c <fwp_wake_io+0x78>
    406c:	d503201f 	nop

0000000000004070 <fwp_tape_buffers_release>:
    4070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4074:	910003fd 	mov	x29, sp
    4078:	a90153f3 	stp	x19, x20, [sp, #16]
    407c:	aa0003f3 	mov	x19, x0
    4080:	f9401400 	ldr	x0, [x0, #40]
    4084:	b7f80760 	tbnz	x0, #63, 4170 <fwp_tape_buffers_release+0x100>
    4088:	f9401a61 	ldr	x1, [x19, #48]
    408c:	b7f80301 	tbnz	x1, #63, 40ec <fwp_tape_buffers_release+0x7c>
    4090:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4094:	eb02001f 	cmp	x0, x2
    4098:	540002a8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    409c:	8b000400 	add	x0, x0, x0, lsl #1
    40a0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40a4:	d37df000 	lsl	x0, x0, #3
    40a8:	cb000042 	sub	x2, x2, x0
    40ac:	eb420c3f 	cmp	x1, x2, lsr #3
    40b0:	540001e8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    40b4:	8b010c14 	add	x20, x0, x1, lsl #3
    40b8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    40bc:	91294000 	add	x0, x0, #0xa50
    40c0:	97fffa78 	bl	2aa0 <getenv@plt>
    40c4:	b4000240 	cbz	x0, 410c <fwp_tape_buffers_release+0x9c>
    40c8:	39400001 	ldrb	w1, [x0]
    40cc:	7100c03f 	cmp	w1, #0x30
    40d0:	540001e1 	b.ne	410c <fwp_tape_buffers_release+0x9c>  // b.any
    40d4:	39400400 	ldrb	w0, [x0, #1]
    40d8:	350001a0 	cbnz	w0, 410c <fwp_tape_buffers_release+0x9c>
    40dc:	aa1303e0 	mov	x0, x19
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e8:	17fffd06 	b	3500 <fwp_tape_buffers_dispose>
    40ec:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    40f0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f4:	91294000 	add	x0, x0, #0xa50
    40f8:	97fffa6a 	bl	2aa0 <getenv@plt>
    40fc:	b4ffff00 	cbz	x0, 40dc <fwp_tape_buffers_release+0x6c>
    4100:	39400001 	ldrb	w1, [x0]
    4104:	7100c03f 	cmp	w1, #0x30
    4108:	54fffe60 	b.eq	40d4 <fwp_tape_buffers_release+0x64>  // b.none
    410c:	d1000681 	sub	x1, x20, #0x1
    4110:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4114:	eb00003f 	cmp	x1, x0
    4118:	54fffe28 	b.hi	40dc <fwp_tape_buffers_release+0x6c>  // b.pmore
    411c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4120:	900000f6 	adrp	x22, 20000 <__data_start>
    4124:	910182d6 	add	x22, x22, #0x60
    4128:	910222d5 	add	x21, x22, #0x88
    412c:	aa1503e0 	mov	x0, x21
    4130:	97fffcf4 	bl	3500 <fwp_tape_buffers_dispose>
    4134:	ad400a61 	ldp	q1, q2, [x19]
    4138:	f90062d4 	str	x20, [x22, #192]
    413c:	4f000400 	movi	v0.4s, #0x0
    4140:	ad000aa1 	stp	q1, q2, [x21]
    4144:	3dc00a61 	ldr	q1, [x19, #32]
    4148:	3d800aa1 	str	q1, [x21, #32]
    414c:	f9401a60 	ldr	x0, [x19, #48]
    4150:	f9001aa0 	str	x0, [x21, #48]
    4154:	f9001a7f 	str	xzr, [x19, #48]
    4158:	ad000260 	stp	q0, q0, [x19]
    415c:	3d800a60 	str	q0, [x19, #32]
    4160:	a94153f3 	ldp	x19, x20, [sp, #16]
    4164:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    416c:	d65f03c0 	ret
    4170:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4174:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4178:	91294000 	add	x0, x0, #0xa50
    417c:	97fffa49 	bl	2aa0 <getenv@plt>
    4180:	b5fffa40 	cbnz	x0, 40c8 <fwp_tape_buffers_release+0x58>
    4184:	17ffffd6 	b	40dc <fwp_tape_buffers_release+0x6c>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <fwp_trap>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	900000e2 	adrp	x2, 20000 <__data_start>
    4198:	d53bd041 	mrs	x1, tpidr_el0
    419c:	910003fd 	mov	x29, sp
    41a0:	f9403442 	ldr	x2, [x2, #104]
    41a4:	91400021 	add	x1, x1, #0x0, lsl #12
    41a8:	91004021 	add	x1, x1, #0x10
    41ac:	a90153f3 	stp	x19, x20, [sp, #16]
    41b0:	aa0003f3 	mov	x19, x0
    41b4:	f9400034 	ldr	x20, [x1]
    41b8:	b4000062 	cbz	x2, 41c4 <fwp_trap+0x34>
    41bc:	aa0203e0 	mov	x0, x2
    41c0:	97fffa20 	bl	2a40 <fflush@plt>
    41c4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    41c8:	f947ec00 	ldr	x0, [x0, #4056]
    41cc:	f9400000 	ldr	x0, [x0]
    41d0:	97fffa1c 	bl	2a40 <fflush@plt>
    41d4:	aa1303e3 	mov	x3, x19
    41d8:	b0000022 	adrp	x2, 9000 <fwp_main_thread+0xa50>
    41dc:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    41e0:	f947ea73 	ldr	x19, [x19, #4048]
    41e4:	9129a042 	add	x2, x2, #0xa68
    41e8:	52800041 	mov	w1, #0x2                   	// #2
    41ec:	f9400260 	ldr	x0, [x19]
    41f0:	97fff9e4 	bl	2980 <__fprintf_chk@plt>
    41f4:	b40000b4 	cbz	x20, 4208 <fwp_trap+0x78>
    41f8:	f9400260 	ldr	x0, [x19]
    41fc:	97fffa11 	bl	2a40 <fflush@plt>
    4200:	52800ca0 	mov	w0, #0x65                  	// #101
    4204:	97fffa1f 	bl	2a80 <_Exit@plt>
    4208:	52800ca0 	mov	w0, #0x65                  	// #101
    420c:	97fff96d 	bl	27c0 <exit@plt>

0000000000004210 <fwp_rc_forget_slot.part.0>:
    4210:	ca404401 	eor	x1, x0, x0, lsr #17
    4214:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4218:	ca412421 	eor	x1, x1, x1, lsr #9
    421c:	910003fd 	mov	x29, sp
    4220:	92401c21 	and	x1, x1, #0xff
    4224:	f9000bf3 	str	x19, [sp, #16]
    4228:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    422c:	91170262 	add	x2, x19, #0x5c0
    4230:	910a2423 	add	x3, x1, #0x289
    4234:	8b010c41 	add	x1, x2, x1, lsl #3
    4238:	8b030c43 	add	x3, x2, x3, lsl #3
    423c:	f94a2421 	ldr	x1, [x1, #5192]
    4240:	b50000a1 	cbnz	x1, 4254 <fwp_rc_forget_slot.part.0+0x44>
    4244:	14000012 	b	428c <fwp_rc_forget_slot.part.0+0x7c>
    4248:	91004023 	add	x3, x1, #0x10
    424c:	f9400821 	ldr	x1, [x1, #16]
    4250:	b40001e1 	cbz	x1, 428c <fwp_rc_forget_slot.part.0+0x7c>
    4254:	f9400022 	ldr	x2, [x1]
    4258:	eb02001f 	cmp	x0, x2
    425c:	54ffff61 	b.ne	4248 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4260:	f9400060 	ldr	x0, [x3]
    4264:	91170273 	add	x19, x19, #0x5c0
    4268:	f9400801 	ldr	x1, [x0, #16]
    426c:	f9000061 	str	x1, [x3]
    4270:	97fff9d8 	bl	29d0 <free@plt>
    4274:	f94e2660 	ldr	x0, [x19, #7240]
    4278:	d1000400 	sub	x0, x0, #0x1
    427c:	f90e2660 	str	x0, [x19, #7240]
    4280:	f9400bf3 	ldr	x19, [sp, #16]
    4284:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4288:	d65f03c0 	ret
    428c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4290:	9129e000 	add	x0, x0, #0xa78
    4294:	97ffffbf 	bl	4190 <fwp_trap>
    4298:	d503201f 	nop
    429c:	d503201f 	nop

00000000000042a0 <fwp_rc_prepare_chunk>:
    42a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42a4:	910003fd 	mov	x29, sp
    42a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    42ac:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc20>
    42b0:	911702c2 	add	x2, x22, #0x5c0
    42b4:	b9401c03 	ldr	w3, [x0, #28]
    42b8:	aa0103f5 	mov	x21, x1
    42bc:	a90153f3 	stp	x19, x20, [sp, #16]
    42c0:	aa0003f4 	mov	x20, x0
    42c4:	f94e2440 	ldr	x0, [x2, #7240]
    42c8:	b4000440 	cbz	x0, 4350 <fwp_rc_prepare_chunk+0xb0>
    42cc:	d2800013 	mov	x19, #0x0                   	// #0
    42d0:	35000203 	cbnz	w3, 4310 <fwp_rc_prepare_chunk+0x70>
    42d4:	b4000361 	cbz	x1, 4340 <fwp_rc_prepare_chunk+0xa0>
    42d8:	f9401280 	ldr	x0, [x20, #32]
    42dc:	97fff9bd 	bl	29d0 <free@plt>
    42e0:	aa1503e0 	mov	x0, x21
    42e4:	d2800021 	mov	x1, #0x1                   	// #1
    42e8:	97fff982 	bl	28f0 <calloc@plt>
    42ec:	f9001280 	str	x0, [x20, #32]
    42f0:	b5000460 	cbnz	x0, 437c <fwp_rc_prepare_chunk+0xdc>
    42f4:	97fffb6f 	bl	30b0 <fwp_heap_oom>
    42f8:	97ffffc6 	bl	4210 <fwp_rc_forget_slot.part.0>
    42fc:	91000673 	add	x19, x19, #0x1
    4300:	b9401e83 	ldr	w3, [x20, #28]
    4304:	eb13007f 	cmp	x3, x19
    4308:	54000169 	b.ls	4334 <fwp_rc_prepare_chunk+0x94>  // b.plast
    430c:	d503201f 	nop
    4310:	f9401283 	ldr	x3, [x20, #32]
    4314:	8b130060 	add	x0, x3, x19
    4318:	38736863 	ldrb	w3, [x3, x19]
    431c:	7103fc7f 	cmp	w3, #0xff
    4320:	54fffec0 	b.eq	42f8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4324:	b9401e83 	ldr	w3, [x20, #28]
    4328:	91000673 	add	x19, x19, #0x1
    432c:	eb13007f 	cmp	x3, x19
    4330:	54ffff08 	b.hi	4310 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4334:	eb0302bf 	cmp	x21, x3
    4338:	54000121 	b.ne	435c <fwp_rc_prepare_chunk+0xbc>  // b.any
    433c:	b5000335 	cbnz	x21, 43a0 <fwp_rc_prepare_chunk+0x100>
    4340:	a94153f3 	ldp	x19, x20, [sp, #16]
    4344:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4348:	a8c37bfd 	ldp	x29, x30, [sp], #48
    434c:	d65f03c0 	ret
    4350:	2a0303e3 	mov	w3, w3
    4354:	eb0302bf 	cmp	x21, x3
    4358:	54ffff20 	b.eq	433c <fwp_rc_prepare_chunk+0x9c>  // b.none
    435c:	911702c2 	add	x2, x22, #0x5c0
    4360:	f9401280 	ldr	x0, [x20, #32]
    4364:	f94e2841 	ldr	x1, [x2, #7248]
    4368:	cb030021 	sub	x1, x1, x3
    436c:	f90e2841 	str	x1, [x2, #7248]
    4370:	97fff998 	bl	29d0 <free@plt>
    4374:	b5fffb75 	cbnz	x21, 42e0 <fwp_rc_prepare_chunk+0x40>
    4378:	f900129f 	str	xzr, [x20, #32]
    437c:	911702d6 	add	x22, x22, #0x5c0
    4380:	f94e2ac0 	ldr	x0, [x22, #7248]
    4384:	b9001e95 	str	w21, [x20, #28]
    4388:	a94153f3 	ldp	x19, x20, [sp, #16]
    438c:	8b150000 	add	x0, x0, x21
    4390:	f90e2ac0 	str	x0, [x22, #7248]
    4394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4398:	a8c37bfd 	ldp	x29, x30, [sp], #48
    439c:	d65f03c0 	ret
    43a0:	f9401280 	ldr	x0, [x20, #32]
    43a4:	aa1503e2 	mov	x2, x21
    43a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43ac:	52800001 	mov	w1, #0x0                   	// #0
    43b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43b8:	17fff94a 	b	28e0 <memset@plt>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_heap_refill>:
    43c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    43d0:	911702b5 	add	x21, x21, #0x5c0
    43d4:	aa0003f6 	mov	x22, x0
    43d8:	d2800020 	mov	x0, #0x1                   	// #1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	a90363f7 	stp	x23, x24, [sp, #48]
    43e4:	2a0103f7 	mov	w23, w1
    43e8:	2a0203f8 	mov	w24, w2
    43ec:	97fffbd1 	bl	3330 <fwp_heap_chunks>
    43f0:	aa0003f3 	mov	x19, x0
    43f4:	f949fea2 	ldr	x2, [x21, #5112]
    43f8:	8b000800 	add	x0, x0, x0, lsl #2
    43fc:	2a1703e1 	mov	w1, w23
    4400:	52800025 	mov	w5, #0x1                   	// #1
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	910f0021 	add	x1, x1, #0x3c0
    440c:	8b000054 	add	x20, x2, x0
    4410:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4414:	52a00024 	mov	w4, #0x10000               	// #65536
    4418:	38206845 	strb	w5, [x2, x0]
    441c:	aa1403e0 	mov	x0, x20
    4420:	39000698 	strb	w24, [x20, #1]
    4424:	39000a97 	strb	w23, [x20, #2]
    4428:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    442c:	b9000681 	str	w1, [x20, #4]
    4430:	2a0103e5 	mov	w5, w1
    4434:	8b0300a2 	add	x2, x5, x3
    4438:	1ac10881 	udiv	w1, w4, w1
    443c:	9ac50842 	udiv	x2, x2, x5
    4440:	b9000a81 	str	w1, [x20, #8]
    4444:	92404021 	and	x1, x1, #0x1ffff
    4448:	b9001a82 	str	w2, [x20, #24]
    444c:	97ffff95 	bl	42a0 <fwp_rc_prepare_chunk>
    4450:	f949daa0 	ldr	x0, [x21, #5040]
    4454:	29408a81 	ldp	w1, w2, [x20, #4]
    4458:	8b134000 	add	x0, x0, x19, lsl #16
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	8b214003 	add	x3, x0, w1, uxtw
    4464:	9ba20021 	umaddl	x1, w1, w2, x0
    4468:	a94363f7 	ldp	x23, x24, [sp, #48]
    446c:	a90086c3 	stp	x3, x1, [x22, #8]
    4470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4474:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4478:	d65f03c0 	ret
    447c:	d503201f 	nop

0000000000004480 <fwp_mem_free>:
    4480:	b40003c0 	cbz	x0, 44f8 <fwp_mem_free+0x78>
    4484:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4488:	910003fd 	mov	x29, sp
    448c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4490:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4494:	911702a1 	add	x1, x21, #0x5c0
    4498:	a90153f3 	stp	x19, x20, [sp, #16]
    449c:	aa0003f3 	mov	x19, x0
    44a0:	f949d823 	ldr	x3, [x1, #5040]
    44a4:	f949ec22 	ldr	x2, [x1, #5080]
    44a8:	cb030000 	sub	x0, x0, x3
    44ac:	eb02401f 	cmp	x0, x2, lsl #16
    44b0:	540001c2 	b.cs	44e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    44b4:	d350fc16 	lsr	x22, x0, #16
    44b8:	a90363f7 	stp	x23, x24, [sp, #48]
    44bc:	f949fc22 	ldr	x2, [x1, #5112]
    44c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    44c4:	d37df294 	lsl	x20, x20, #3
    44c8:	ab140057 	adds	x23, x2, x20
    44cc:	540000c0 	b.eq	44e4 <fwp_mem_free+0x64>  // b.none
    44d0:	38746842 	ldrb	w2, [x2, x20]
    44d4:	7100045f 	cmp	w2, #0x1
    44d8:	54000120 	b.eq	44fc <fwp_mem_free+0x7c>  // b.none
    44dc:	7100085f 	cmp	w2, #0x2
    44e0:	540005e0 	b.eq	459c <fwp_mem_free+0x11c>  // b.none
    44e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44f4:	d65f03c0 	ret
    44f8:	d65f03c0 	ret
    44fc:	f94012f8 	ldr	x24, [x23, #32]
    4500:	b94006e1 	ldr	w1, [x23, #4]
    4504:	f90023f9 	str	x25, [sp, #64]
    4508:	2a0103e2 	mov	w2, w1
    450c:	394006f9 	ldrb	w25, [x23, #1]
    4510:	39400af4 	ldrb	w20, [x23, #2]
    4514:	b4000158 	cbz	x24, 453c <fwp_mem_free+0xbc>
    4518:	92403e76 	and	x22, x19, #0xffff
    451c:	9ac20ad6 	udiv	x22, x22, x2
    4520:	38766b01 	ldrb	w1, [x24, x22]
    4524:	8b160300 	add	x0, x24, x22
    4528:	7103fc3f 	cmp	w1, #0xff
    452c:	54000980 	b.eq	465c <fwp_mem_free+0x1dc>  // b.none
    4530:	38366b1f 	strb	wzr, [x24, x22]
    4534:	b94006e1 	ldr	w1, [x23, #4]
    4538:	2a0103e2 	mov	w2, w1
    453c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4540:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4544:	cb390000 	sub	x0, x0, w25, uxtb
    4548:	8b340074 	add	x20, x3, w20, uxtb
    454c:	911702b5 	add	x21, x21, #0x5c0
    4550:	1e630021 	ucvtf	d1, w1
    4554:	d37ae400 	lsl	x0, x0, #6
    4558:	8b140c14 	add	x20, x0, x20, lsl #3
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	f8746aa0 	ldr	x0, [x21, x20]
    4564:	f94023f9 	ldr	x25, [sp, #64]
    4568:	aa2003e0 	mvn	x0, x0
    456c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4570:	f9000260 	str	x0, [x19]
    4574:	f8346ab3 	str	x19, [x21, x20]
    4578:	f94a12a0 	ldr	x0, [x21, #5152]
    457c:	1e612800 	fadd	d0, d0, d1
    4580:	a94153f3 	ldp	x19, x20, [sp, #16]
    4584:	cb020000 	sub	x0, x0, x2
    4588:	f90a12a0 	str	x0, [x21, #5152]
    458c:	fd0a22a0 	str	d0, [x21, #5184]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4598:	d65f03c0 	ret
    459c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    45a0:	8b000063 	add	x3, x3, x0
    45a4:	eb03027f 	cmp	x19, x3
    45a8:	54fff9e1 	b.ne	44e4 <fwp_mem_free+0x64>  // b.any
    45ac:	fd400ae1 	ldr	d1, [x23, #16]
    45b0:	fd4a2020 	ldr	d0, [x1, #5184]
    45b4:	f9400ae0 	ldr	x0, [x23, #16]
    45b8:	7e61d821 	ucvtf	d1, d1
    45bc:	f94a1022 	ldr	x2, [x1, #5152]
    45c0:	f94012f3 	ldr	x19, [x23, #32]
    45c4:	1e612800 	fadd	d0, d0, d1
    45c8:	cb000042 	sub	x2, x2, x0
    45cc:	f90a1022 	str	x2, [x1, #5152]
    45d0:	fd0a2020 	str	d0, [x1, #5184]
    45d4:	b40000b3 	cbz	x19, 45e8 <fwp_mem_free+0x168>
    45d8:	39400260 	ldrb	w0, [x19]
    45dc:	7103fc1f 	cmp	w0, #0xff
    45e0:	54000380 	b.eq	4650 <fwp_mem_free+0x1d0>  // b.none
    45e4:	3900027f 	strb	wzr, [x19]
    45e8:	b9400ee2 	ldr	w2, [x23, #12]
    45ec:	b4000142 	cbz	x2, 4614 <fwp_mem_free+0x194>
    45f0:	911702a1 	add	x1, x21, #0x5c0
    45f4:	8b160040 	add	x0, x2, x22
    45f8:	8b000800 	add	x0, x0, x0, lsl #2
    45fc:	f949fc21 	ldr	x1, [x1, #5112]
    4600:	8b140034 	add	x20, x1, x20
    4604:	8b000c20 	add	x0, x1, x0, lsl #3
    4608:	3802869f 	strb	wzr, [x20], #40
    460c:	eb00029f 	cmp	x20, x0
    4610:	54ffffc1 	b.ne	4608 <fwp_mem_free+0x188>  // b.any
    4614:	911702a0 	add	x0, x21, #0x5c0
    4618:	f94a1801 	ldr	x1, [x0, #5168]
    461c:	f949f803 	ldr	x3, [x0, #5104]
    4620:	8b020021 	add	x1, x1, x2
    4624:	f90a1801 	str	x1, [x0, #5168]
    4628:	eb16007f 	cmp	x3, x22
    462c:	54000049 	b.ls	4634 <fwp_mem_free+0x1b4>  // b.plast
    4630:	f909f816 	str	x22, [x0, #5104]
    4634:	911702b5 	add	x21, x21, #0x5c0
    4638:	f949f6a0 	ldr	x0, [x21, #5096]
    463c:	eb16001f 	cmp	x0, x22
    4640:	54fff529 	b.ls	44e4 <fwp_mem_free+0x64>  // b.plast
    4644:	a94363f7 	ldp	x23, x24, [sp, #48]
    4648:	f909f6b6 	str	x22, [x21, #5096]
    464c:	17ffffa7 	b	44e8 <fwp_mem_free+0x68>
    4650:	aa1303e0 	mov	x0, x19
    4654:	97fffeef 	bl	4210 <fwp_rc_forget_slot.part.0>
    4658:	17ffffe3 	b	45e4 <fwp_mem_free+0x164>
    465c:	97fffeed 	bl	4210 <fwp_rc_forget_slot.part.0>
    4660:	17ffffb4 	b	4530 <fwp_mem_free+0xb0>

0000000000004664 <fwp_rc_wide_dup>:
    4664:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4668:	910003fd 	mov	x29, sp
    466c:	a90153f3 	stp	x19, x20, [sp, #16]
    4670:	aa0003f3 	mov	x19, x0
    4674:	ca404400 	eor	x0, x0, x0, lsr #17
    4678:	f90013f5 	str	x21, [sp, #32]
    467c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4680:	ca402400 	eor	x0, x0, x0, lsr #9
    4684:	911702a2 	add	x2, x21, #0x5c0
    4688:	92401c00 	and	x0, x0, #0xff
    468c:	910a2403 	add	x3, x0, #0x289
    4690:	8b000c40 	add	x0, x2, x0, lsl #3
    4694:	8b030c54 	add	x20, x2, x3, lsl #3
    4698:	f94a2401 	ldr	x1, [x0, #5192]
    469c:	b50000a1 	cbnz	x1, 46b0 <fwp_rc_wide_dup+0x4c>
    46a0:	14000033 	b	476c <fwp_rc_wide_dup+0x108>
    46a4:	91004034 	add	x20, x1, #0x10
    46a8:	f9400821 	ldr	x1, [x1, #16]
    46ac:	b4000241 	cbz	x1, 46f4 <fwp_rc_wide_dup+0x90>
    46b0:	f9400022 	ldr	x2, [x1]
    46b4:	eb02027f 	cmp	x19, x2
    46b8:	54ffff61 	b.ne	46a4 <fwp_rc_wide_dup+0x40>  // b.any
    46bc:	f9400281 	ldr	x1, [x20]
    46c0:	39400260 	ldrb	w0, [x19]
    46c4:	7103f81f 	cmp	w0, #0xfe
    46c8:	54000220 	b.eq	470c <fwp_rc_wide_dup+0xa8>  // b.none
    46cc:	b40001a1 	cbz	x1, 4700 <fwp_rc_wide_dup+0x9c>
    46d0:	f9400420 	ldr	x0, [x1, #8]
    46d4:	b100041f 	cmn	x0, #0x1
    46d8:	54000440 	b.eq	4760 <fwp_rc_wide_dup+0xfc>  // b.none
    46dc:	91000400 	add	x0, x0, #0x1
    46e0:	f9000420 	str	x0, [x1, #8]
    46e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e8:	f94013f5 	ldr	x21, [sp, #32]
    46ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f0:	d65f03c0 	ret
    46f4:	39400260 	ldrb	w0, [x19]
    46f8:	7103f81f 	cmp	w0, #0xfe
    46fc:	54000100 	b.eq	471c <fwp_rc_wide_dup+0xb8>  // b.none
    4700:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4704:	9129e000 	add	x0, x0, #0xa78
    4708:	97fffea2 	bl	4190 <fwp_trap>
    470c:	b4000081 	cbz	x1, 471c <fwp_rc_wide_dup+0xb8>
    4710:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4714:	912a8000 	add	x0, x0, #0xaa0
    4718:	97fffe9e 	bl	4190 <fwp_trap>
    471c:	d2800300 	mov	x0, #0x18                  	// #24
    4720:	97fff864 	bl	28b0 <malloc@plt>
    4724:	b4000280 	cbz	x0, 4774 <fwp_rc_wide_dup+0x110>
    4728:	d2801fe1 	mov	x1, #0xff                  	// #255
    472c:	a9000413 	stp	x19, x1, [x0]
    4730:	911702b5 	add	x21, x21, #0x5c0
    4734:	f900081f 	str	xzr, [x0, #16]
    4738:	12800001 	mov	w1, #0xffffffff            	// #-1
    473c:	f9000280 	str	x0, [x20]
    4740:	39000261 	strb	w1, [x19]
    4744:	f94e26a0 	ldr	x0, [x21, #7240]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f90e26a0 	str	x0, [x21, #7240]
    4754:	f94013f5 	ldr	x21, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4764:	912b2000 	add	x0, x0, #0xac8
    4768:	97fffe8a 	bl	4190 <fwp_trap>
    476c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4770:	17ffffd4 	b	46c0 <fwp_rc_wide_dup+0x5c>
    4774:	97fffa4f 	bl	30b0 <fwp_heap_oom>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_closure_drop_push>:
    4780:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	a9408014 	ldp	x20, x0, [x0, #8]
    4794:	a9025bf5 	stp	x21, x22, [sp, #32]
    4798:	aa0103f5 	mov	x21, x1
    479c:	a90363f7 	stp	x23, x24, [sp, #48]
    47a0:	eb00029f 	cmp	x20, x0
    47a4:	54000160 	b.eq	47d0 <fwp_closure_drop_push+0x50>  // b.none
    47a8:	f9400276 	ldr	x22, [x19]
    47ac:	d37df297 	lsl	x23, x20, #3
    47b0:	91000694 	add	x20, x20, #0x1
    47b4:	f9000674 	str	x20, [x19, #8]
    47b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47bc:	f8376ad5 	str	x21, [x22, x23]
    47c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47cc:	d65f03c0 	ret
    47d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    47d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    47d8:	eb00029f 	cmp	x20, x0
    47dc:	540003e8 	b.hi	4858 <fwp_closure_drop_push+0xd8>  // b.pmore
    47e0:	d37cee99 	lsl	x25, x20, #4
    47e4:	d37ffa9a 	lsl	x26, x20, #1
    47e8:	aa1903e0 	mov	x0, x25
    47ec:	97fff831 	bl	28b0 <malloc@plt>
    47f0:	aa0003f6 	mov	x22, x0
    47f4:	b4000380 	cbz	x0, 4864 <fwp_closure_drop_push+0xe4>
    47f8:	aa1303f8 	mov	x24, x19
    47fc:	aa1903e3 	mov	x3, x25
    4800:	d37df297 	lsl	x23, x20, #3
    4804:	aa1703e2 	mov	x2, x23
    4808:	f8418719 	ldr	x25, [x24], #24
    480c:	aa1903e1 	mov	x1, x25
    4810:	97fff814 	bl	2860 <__memcpy_chk@plt>
    4814:	eb18033f 	cmp	x25, x24
    4818:	540000a0 	b.eq	482c <fwp_closure_drop_push+0xac>  // b.none
    481c:	aa1903e0 	mov	x0, x25
    4820:	97fff86c 	bl	29d0 <free@plt>
    4824:	f9400674 	ldr	x20, [x19, #8]
    4828:	d37df297 	lsl	x23, x20, #3
    482c:	91000694 	add	x20, x20, #0x1
    4830:	f9000276 	str	x22, [x19]
    4834:	f9000a7a 	str	x26, [x19, #16]
    4838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    483c:	f9000674 	str	x20, [x19, #8]
    4840:	f8376ad5 	str	x21, [x22, x23]
    4844:	a94153f3 	ldp	x19, x20, [sp, #16]
    4848:	a9425bf5 	ldp	x21, x22, [sp, #32]
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4854:	d65f03c0 	ret
    4858:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    485c:	912ba000 	add	x0, x0, #0xae8
    4860:	97fffe4c 	bl	4190 <fwp_trap>
    4864:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4868:	f947e863 	ldr	x3, [x3, #4048]
    486c:	d2800262 	mov	x2, #0x13                  	// #19
    4870:	d2800021 	mov	x1, #0x1                   	// #1
    4874:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4878:	91222000 	add	x0, x0, #0x888
    487c:	f9400063 	ldr	x3, [x3]
    4880:	97fff864 	bl	2a10 <fwrite@plt>
    4884:	d2800000 	mov	x0, #0x0                   	// #0
    4888:	97fff86e 	bl	2a40 <fflush@plt>
    488c:	52800cc0 	mov	w0, #0x66                  	// #102
    4890:	97fff87c 	bl	2a80 <_Exit@plt>

0000000000004894 <fwp_closure_drop.part.0>:
    4894:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4898:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0x780>
    489c:	910003fd 	mov	x29, sp
    48a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    48a4:	f947f463 	ldr	x3, [x3, #4072]
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	d10883ff 	sub	sp, sp, #0x220
    48b0:	910003e2 	mov	x2, sp
    48b4:	d53bd053 	mrs	x19, tpidr_el0
    48b8:	910063f4 	add	x20, sp, #0x18
    48bc:	3dc16c20 	ldr	q0, [x1, #1456]
    48c0:	91400264 	add	x4, x19, #0x0, lsl #12
    48c4:	91004084 	add	x4, x4, #0x10
    48c8:	aa0003e1 	mov	x1, x0
    48cc:	aa0203e0 	mov	x0, x2
    48d0:	f9400062 	ldr	x2, [x3]
    48d4:	f9010fe2 	str	x2, [sp, #536]
    48d8:	d2800002 	mov	x2, #0x0                   	// #0
    48dc:	f90003f4 	str	x20, [sp]
    48e0:	f9000080 	str	x0, [x4]
    48e4:	3c8083e0 	stur	q0, [sp, #8]
    48e8:	97ffffa6 	bl	4780 <fwp_closure_drop_push>
    48ec:	f94007e0 	ldr	x0, [sp, #8]
    48f0:	b40002e0 	cbz	x0, 494c <fwp_closure_drop.part.0+0xb8>
    48f4:	f90123f5 	str	x21, [sp, #576]
    48f8:	900000f5 	adrp	x21, 20000 <__data_start>
    48fc:	910182b5 	add	x21, x21, #0x60
    4900:	14000006 	b	4918 <fwp_closure_drop.part.0+0x84>
    4904:	f9400422 	ldr	x2, [x1, #8]
    4908:	52800001 	mov	w1, #0x0                   	// #0
    490c:	d63f0040 	blr	x2
    4910:	f94007e0 	ldr	x0, [sp, #8]
    4914:	b40001a0 	cbz	x0, 4948 <fwp_closure_drop.part.0+0xb4>
    4918:	f94003e1 	ldr	x1, [sp]
    491c:	d1000400 	sub	x0, x0, #0x1
    4920:	f90007e0 	str	x0, [sp, #8]
    4924:	f94066a2 	ldr	x2, [x21, #200]
    4928:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    492c:	b9400001 	ldr	w1, [x0]
    4930:	8b011441 	add	x1, x2, x1, lsl #5
    4934:	f9400c21 	ldr	x1, [x1, #24]
    4938:	b5fffe61 	cbnz	x1, 4904 <fwp_closure_drop.part.0+0x70>
    493c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4940:	912c2000 	add	x0, x0, #0xb08
    4944:	97fffe13 	bl	4190 <fwp_trap>
    4948:	f94123f5 	ldr	x21, [sp, #576]
    494c:	91400273 	add	x19, x19, #0x0, lsl #12
    4950:	91004273 	add	x19, x19, #0x10
    4954:	f94003e0 	ldr	x0, [sp]
    4958:	f900027f 	str	xzr, [x19]
    495c:	eb14001f 	cmp	x0, x20
    4960:	54000040 	b.eq	4968 <fwp_closure_drop.part.0+0xd4>  // b.none
    4964:	97fff81b 	bl	29d0 <free@plt>
    4968:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    496c:	f947f400 	ldr	x0, [x0, #4072]
    4970:	f9410fe2 	ldr	x2, [sp, #536]
    4974:	f9400001 	ldr	x1, [x0]
    4978:	eb010042 	subs	x2, x2, x1
    497c:	d2800001 	mov	x1, #0x0                   	// #0
    4980:	540000a1 	b.ne	4994 <fwp_closure_drop.part.0+0x100>  // b.any
    4984:	910883ff 	add	sp, sp, #0x220
    4988:	a94153f3 	ldp	x19, x20, [sp, #16]
    498c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4990:	d65f03c0 	ret
    4994:	f90123f5 	str	x21, [sp, #576]
    4998:	97fff7de 	bl	2910 <__stack_chk_fail@plt>
    499c:	d503201f 	nop

00000000000049a0 <fwp_tape_of>:
    49a0:	aa0003e1 	mov	x1, x0
    49a4:	92403c00 	and	x0, x0, #0xffff
    49a8:	b40000e0 	cbz	x0, 49c4 <fwp_tape_of+0x24>
    49ac:	d1000402 	sub	x2, x0, #0x1
    49b0:	900000e3 	adrp	x3, 20000 <__data_start>
    49b4:	91018060 	add	x0, x3, #0x60
    49b8:	f9406800 	ldr	x0, [x0, #208]
    49bc:	eb02001f 	cmp	x0, x2
    49c0:	540000cc 	b.gt	49d8 <fwp_tape_of+0x38>
    49c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    49c8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    49cc:	912ce000 	add	x0, x0, #0xb38
    49d0:	910003fd 	mov	x29, sp
    49d4:	97fffdef 	bl	4190 <fwp_trap>
    49d8:	8b020440 	add	x0, x2, x2, lsl #1
    49dc:	f9403063 	ldr	x3, [x3, #96]
    49e0:	8b000842 	add	x2, x2, x0, lsl #2
    49e4:	d37df042 	lsl	x2, x2, #3
    49e8:	8b020060 	add	x0, x3, x2
    49ec:	b9400404 	ldr	w4, [x0, #4]
    49f0:	34fffea4 	cbz	w4, 49c4 <fwp_tape_of+0x24>
    49f4:	b8626862 	ldr	w2, [x3, x2]
    49f8:	9350fc21 	asr	x1, x1, #16
    49fc:	6b01005f 	cmp	w2, w1
    4a00:	54fffe21 	b.ne	49c4 <fwp_tape_of+0x24>  // b.any
    4a04:	d65f03c0 	ret
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_now_ns>:
    4a10:	d100c3ff 	sub	sp, sp, #0x30
    4a14:	52800020 	mov	w0, #0x1                   	// #1
    4a18:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    4a1c:	f947f442 	ldr	x2, [x2, #4072]
    4a20:	910023e1 	add	x1, sp, #0x8
    4a24:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a28:	910083fd 	add	x29, sp, #0x20
    4a2c:	f9400043 	ldr	x3, [x2]
    4a30:	f9000fe3 	str	x3, [sp, #24]
    4a34:	d2800003 	mov	x3, #0x0                   	// #0
    4a38:	97fff782 	bl	2840 <clock_gettime@plt>
    4a3c:	350002c0 	cbnz	w0, 4a94 <fwp_now_ns+0x84>
    4a40:	a9408be1 	ldp	x1, x2, [sp, #8]
    4a44:	d2994003 	mov	x3, #0xca00                	// #51712
    4a48:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4a4c:	9b037c20 	mul	x0, x1, x3
    4a50:	9b437c21 	smulh	x1, x1, x3
    4a54:	ab020000 	adds	x0, x0, x2
    4a58:	937ffc42 	asr	x2, x2, #63
    4a5c:	9a020021 	adc	x1, x1, x2
    4a60:	f100001f 	cmp	x0, #0x0
    4a64:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4a68:	b50001c1 	cbnz	x1, 4aa0 <fwp_now_ns+0x90>
    4a6c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4a70:	f947f421 	ldr	x1, [x1, #4072]
    4a74:	f9400fe3 	ldr	x3, [sp, #24]
    4a78:	f9400022 	ldr	x2, [x1]
    4a7c:	eb020063 	subs	x3, x3, x2
    4a80:	d2800002 	mov	x2, #0x0                   	// #0
    4a84:	54000141 	b.ne	4aac <fwp_now_ns+0x9c>  // b.any
    4a88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a8c:	9100c3ff 	add	sp, sp, #0x30
    4a90:	d65f03c0 	ret
    4a94:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4a98:	912e2000 	add	x0, x0, #0xb88
    4a9c:	97fffdbd 	bl	4190 <fwp_trap>
    4aa0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4aa4:	912ea000 	add	x0, x0, #0xba8
    4aa8:	97fffdba 	bl	4190 <fwp_trap>
    4aac:	97fff799 	bl	2910 <__stack_chk_fail@plt>

0000000000004ab0 <fwp_poll_events>:
    4ab0:	d10103ff 	sub	sp, sp, #0x40
    4ab4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4ab8:	f947f400 	ldr	x0, [x0, #4072]
    4abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4ac0:	910083fd 	add	x29, sp, #0x20
    4ac4:	f9001bf3 	str	x19, [sp, #48]
    4ac8:	900000f3 	adrp	x19, 20000 <__data_start>
    4acc:	f9400001 	ldr	x1, [x0]
    4ad0:	f9000fe1 	str	x1, [sp, #24]
    4ad4:	d2800001 	mov	x1, #0x0                   	// #0
    4ad8:	97ffffce 	bl	4a10 <fwp_now_ns>
    4adc:	91018261 	add	x1, x19, #0x60
    4ae0:	f9406c21 	ldr	x1, [x1, #216]
    4ae4:	b4000e01 	cbz	x1, 4ca4 <fwp_poll_events+0x1f4>
    4ae8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4aec:	14000005 	b	4b00 <fwp_poll_events+0x50>
    4af0:	f9408821 	ldr	x1, [x1, #272]
    4af4:	eb03005f 	cmp	x2, x3
    4af8:	9a83d042 	csel	x2, x2, x3, le
    4afc:	b40000c1 	cbz	x1, 4b14 <fwp_poll_events+0x64>
    4b00:	f9403423 	ldr	x3, [x1, #104]
    4b04:	b6ffff62 	tbz	x2, #63, 4af0 <fwp_poll_events+0x40>
    4b08:	f9408821 	ldr	x1, [x1, #272]
    4b0c:	aa0303e2 	mov	x2, x3
    4b10:	b5ffff81 	cbnz	x1, 4b00 <fwp_poll_events+0x50>
    4b14:	b7f80c82 	tbnz	x2, #63, 4ca4 <fwp_poll_events+0x1f4>
    4b18:	cb000042 	sub	x2, x2, x0
    4b1c:	f100005f 	cmp	x2, #0x0
    4b20:	540003ad 	b.le	4b94 <fwp_poll_events+0xe4>
    4b24:	d2869b60 	mov	x0, #0x34db                	// #13531
    4b28:	d2884804 	mov	x4, #0x4240                	// #16960
    4b2c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4b30:	f2a001e4 	movk	x4, #0xf, lsl #16
    4b34:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4b38:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4b3c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4b40:	9b407c40 	smulh	x0, x2, x0
    4b44:	9352fc00 	asr	x0, x0, #18
    4b48:	cb82fc00 	sub	x0, x0, x2, asr #63
    4b4c:	9b048802 	msub	x2, x0, x4, x2
    4b50:	f100005f 	cmp	x2, #0x0
    4b54:	9a800400 	cinc	x0, x0, ne	// ne = any
    4b58:	eb01001f 	cmp	x0, x1
    4b5c:	5400098c 	b.gt	4c8c <fwp_poll_events+0x1dc>
    4b60:	340001a0 	cbz	w0, 4b94 <fwp_poll_events+0xe4>
    4b64:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4b68:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4b6c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4b70:	9ba17c01 	umull	x1, w0, w1
    4b74:	d366fc23 	lsr	x3, x1, #38
    4b78:	aa0303e2 	mov	x2, x3
    4b7c:	1b058063 	msub	w3, w3, w5, w0
    4b80:	9b247c63 	smull	x3, w3, w4
    4b84:	910023e0 	add	x0, sp, #0x8
    4b88:	d2800001 	mov	x1, #0x0                   	// #0
    4b8c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b90:	97fff794 	bl	29e0 <nanosleep@plt>
    4b94:	97ffff9f 	bl	4a10 <fwp_now_ns>
    4b98:	91018268 	add	x8, x19, #0x60
    4b9c:	aa0003e7 	mov	x7, x0
    4ba0:	4f000400 	movi	v0.4s, #0x0
    4ba4:	52800029 	mov	w9, #0x1                   	// #1
    4ba8:	f9406d06 	ldr	x6, [x8, #216]
    4bac:	d503201f 	nop
    4bb0:	b40003e6 	cbz	x6, 4c2c <fwp_poll_events+0x17c>
    4bb4:	f94034c1 	ldr	x1, [x6, #104]
    4bb8:	aa0603e5 	mov	x5, x6
    4bbc:	f94088c6 	ldr	x6, [x6, #272]
    4bc0:	eb07003f 	cmp	x1, x7
    4bc4:	54ffff6c 	b.gt	4bb0 <fwp_poll_events+0x100>
    4bc8:	394154a0 	ldrb	w0, [x5, #85]
    4bcc:	36000120 	tbz	w0, #0, 4bf0 <fwp_poll_events+0x140>
    4bd0:	f94084a0 	ldr	x0, [x5, #264]
    4bd4:	b4000560 	cbz	x0, 4c80 <fwp_poll_events+0x1d0>
    4bd8:	f9008806 	str	x6, [x0, #272]
    4bdc:	b4000046 	cbz	x6, 4be4 <fwp_poll_events+0x134>
    4be0:	f90084c0 	str	x0, [x6, #264]
    4be4:	910800a0 	add	x0, x5, #0x200
    4be8:	390154bf 	strb	wzr, [x5, #85]
    4bec:	3c908000 	stur	q0, [x0, #-248]
    4bf0:	f94030a0 	ldr	x0, [x5, #96]
    4bf4:	390158a9 	strb	w9, [x5, #86]
    4bf8:	f100001f 	cmp	x0, #0x0
    4bfc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4c00:	540002cd 	b.le	4c58 <fwp_poll_events+0x1a8>
    4c04:	f94028a0 	ldr	x0, [x5, #80]
    4c08:	f2001c1f 	tst	x0, #0xff000000ff
    4c0c:	54fffd21 	b.ne	4bb0 <fwp_poll_events+0x100>  // b.any
    4c10:	f9403d00 	ldr	x0, [x8, #120]
    4c14:	390150a9 	strb	w9, [x5, #84]
    4c18:	f90080bf 	str	xzr, [x5, #256]
    4c1c:	b40002c0 	cbz	x0, 4c74 <fwp_poll_events+0x1c4>
    4c20:	f9003d05 	str	x5, [x8, #120]
    4c24:	f9008005 	str	x5, [x0, #256]
    4c28:	b5fffc66 	cbnz	x6, 4bb4 <fwp_poll_events+0x104>
    4c2c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4c30:	f947f400 	ldr	x0, [x0, #4072]
    4c34:	f9400fe2 	ldr	x2, [sp, #24]
    4c38:	f9400001 	ldr	x1, [x0]
    4c3c:	eb010042 	subs	x2, x2, x1
    4c40:	d2800001 	mov	x1, #0x0                   	// #0
    4c44:	540002e1 	b.ne	4ca0 <fwp_poll_events+0x1f0>  // b.any
    4c48:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c4c:	f9401bf3 	ldr	x19, [sp, #48]
    4c50:	910103ff 	add	sp, sp, #0x40
    4c54:	d65f03c0 	ret
    4c58:	394144a0 	ldrb	w0, [x5, #81]
    4c5c:	3707fd40 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c60:	394140a0 	ldrb	w0, [x5, #80]
    4c64:	3707fd00 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c68:	aa0503e0 	mov	x0, x5
    4c6c:	97fffac1 	bl	3770 <fwp_cancel_tree.part.0>
    4c70:	17ffffe5 	b	4c04 <fwp_poll_events+0x154>
    4c74:	f9003d05 	str	x5, [x8, #120]
    4c78:	f9004105 	str	x5, [x8, #128]
    4c7c:	17ffffeb 	b	4c28 <fwp_poll_events+0x178>
    4c80:	91018261 	add	x1, x19, #0x60
    4c84:	f9006c26 	str	x6, [x1, #216]
    4c88:	17ffffd5 	b	4bdc <fwp_poll_events+0x12c>
    4c8c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c90:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c94:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c98:	f2a00402 	movk	x2, #0x20, lsl #16
    4c9c:	17ffffba 	b	4b84 <fwp_poll_events+0xd4>
    4ca0:	97fff71c 	bl	2910 <__stack_chk_fail@plt>
    4ca4:	97fff8f3 	bl	3070 <fwp_flush>
    4ca8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4cac:	f947e863 	ldr	x3, [x3, #4048]
    4cb0:	d2800562 	mov	x2, #0x2b                  	// #43
    4cb4:	d2800021 	mov	x1, #0x1                   	// #1
    4cb8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    4cbc:	912f4000 	add	x0, x0, #0xbd0
    4cc0:	f9400063 	ldr	x3, [x3]
    4cc4:	97fff753 	bl	2a10 <fwrite@plt>
    4cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    4ccc:	97fff6bd 	bl	27c0 <exit@plt>

0000000000004cd0 <fwp_heap_alloc_big>:
    4cd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd4:	910003fd 	mov	x29, sp
    4cd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce4:	aa0003f7 	mov	x23, x0
    4ce8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf0:	eb0002ff 	cmp	x23, x0
    4cf4:	540008a8 	b.hi	4e08 <fwp_heap_alloc_big+0x138>  // b.pmore
    4cf8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cfc:	8b0002f4 	add	x20, x23, x0
    4d00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc20>
    4d04:	91170359 	add	x25, x26, #0x5c0
    4d08:	d350fe94 	lsr	x20, x20, #16
    4d0c:	2a0103f5 	mov	w21, w1
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff987 	bl	3330 <fwp_heap_chunks>
    4d18:	f949ff22 	ldr	x2, [x25, #5112]
    4d1c:	8b000813 	add	x19, x0, x0, lsl #2
    4d20:	aa0003f8 	mov	x24, x0
    4d24:	52800043 	mov	w3, #0x2                   	// #2
    4d28:	d37df273 	lsl	x19, x19, #3
    4d2c:	d2800021 	mov	x1, #0x1                   	// #1
    4d30:	8b130040 	add	x0, x2, x19
    4d34:	38336843 	strb	w3, [x2, x19]
    4d38:	39000415 	strb	w21, [x0, #1]
    4d3c:	b9000c14 	str	w20, [x0, #12]
    4d40:	f9000817 	str	x23, [x0, #16]
    4d44:	97fffd57 	bl	42a0 <fwp_rc_prepare_chunk>
    4d48:	f100069f 	cmp	x20, #0x1
    4d4c:	54000289 	b.ls	4d9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4d50:	8b180294 	add	x20, x20, x24
    4d54:	9100a273 	add	x19, x19, #0x28
    4d58:	a90573fb 	stp	x27, x28, [sp, #80]
    4d5c:	5280007b 	mov	w27, #0x3                   	// #3
    4d60:	8b140a94 	add	x20, x20, x20, lsl #2
    4d64:	2a1803fc 	mov	w28, w24
    4d68:	9adb2296 	lsl	x22, x20, x27
    4d6c:	d503201f 	nop
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffd48 	bl	42a0 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0xa0>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91170353 	add	x19, x26, #0x5c0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x108>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117035a 	add	x26, x26, #0x5c0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    4e20:	91170262 	add	x2, x19, #0x5c0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91170262 	add	x2, x19, #0x5c0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91170260 	add	x0, x19, #0x5c0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91170273 	add	x19, x19, #0x5c0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffbbf 	bl	3df0 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff6f 	b	4cd0 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91170260 	add	x0, x19, #0x5c0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffd19 	bl	43c0 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    4f84:	91170293 	add	x19, x20, #0x5c0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91170294 	add	x20, x20, #0x5c0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    5094:	91170283 	add	x3, x20, #0x5c0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91170282 	add	x2, x20, #0x5c0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91170294 	add	x20, x20, #0x5c0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_tape_grow.constprop.0>:
    51a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51a8:	d2800803 	mov	x3, #0x40                  	// #64
    51ac:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    51b0:	910003fd 	mov	x29, sp
    51b4:	a90153f3 	stp	x19, x20, [sp, #16]
    51b8:	f9400c13 	ldr	x19, [x0, #24]
    51bc:	a90363f7 	stp	x23, x24, [sp, #48]
    51c0:	aa0003f7 	mov	x23, x0
    51c4:	f100027f 	cmp	x19, #0x0
    51c8:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    51cc:	eb13003f 	cmp	x1, x19
    51d0:	540000ed 	b.le	51ec <fwp_tape_grow.constprop.0+0x48>
    51d4:	eb02027f 	cmp	x19, x2
    51d8:	5400076d 	b.le	52c4 <fwp_tape_grow.constprop.0+0x120>
    51dc:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    51e0:	eb13003f 	cmp	x1, x19
    51e4:	5400004d 	b.le	51ec <fwp_tape_grow.constprop.0+0x48>
    51e8:	14000000 	b	51e8 <fwp_tape_grow.constprop.0+0x44>
    51ec:	a940d2e2 	ldp	x2, x20, [x23, #8]
    51f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    51f4:	d37df276 	lsl	x22, x19, #3
    51f8:	f94012e0 	ldr	x0, [x23, #32]
    51fc:	aa1603e1 	mov	x1, x22
    5200:	f94032f5 	ldr	x21, [x23, #96]
    5204:	cb020294 	sub	x20, x20, x2
    5208:	97fff5be 	bl	2900 <realloc@plt>
    520c:	b4000c20 	cbz	x0, 5390 <fwp_tape_grow.constprop.0+0x1ec>
    5210:	f9400ee1 	ldr	x1, [x23, #24]
    5214:	8b010801 	add	x1, x0, x1, lsl #2
    5218:	a90206e0 	stp	x0, x1, [x23, #32]
    521c:	b4000895 	cbz	x21, 532c <fwp_tape_grow.constprop.0+0x188>
    5220:	f94032b6 	ldr	x22, [x21, #96]
    5224:	eb1302df 	cmp	x22, x19
    5228:	540003aa 	b.ge	529c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    522c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5230:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    5234:	eb00027f 	cmp	x19, x0
    5238:	54000a68 	b.hi	5384 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    523c:	f94022b9 	ldr	x25, [x21, #64]
    5240:	d37cee7a 	lsl	x26, x19, #4
    5244:	aa1a03e0 	mov	x0, x26
    5248:	52800041 	mov	w1, #0x2                   	// #2
    524c:	97ffff49 	bl	4f70 <fwp_heap_alloc>
    5250:	aa0003f8 	mov	x24, x0
    5254:	b4000119 	cbz	x25, 5274 <fwp_tape_grow.constprop.0+0xd0>
    5258:	d37ceed6 	lsl	x22, x22, #4
    525c:	aa1903e1 	mov	x1, x25
    5260:	eb1a02df 	cmp	x22, x26
    5264:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    5268:	97fff53e 	bl	2760 <memcpy@plt>
    526c:	aa1903e0 	mov	x0, x25
    5270:	97fffc84 	bl	4480 <fwp_mem_free>
    5274:	f94032a0 	ldr	x0, [x21, #96]
    5278:	52800001 	mov	w1, #0x0                   	// #0
    527c:	cb000262 	sub	x2, x19, x0
    5280:	8b001300 	add	x0, x24, x0, lsl #4
    5284:	d37cec42 	lsl	x2, x2, #4
    5288:	97fff596 	bl	28e0 <memset@plt>
    528c:	f94012e0 	ldr	x0, [x23, #32]
    5290:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5294:	f90022b8 	str	x24, [x21, #64]
    5298:	f90032b3 	str	x19, [x21, #96]
    529c:	d37ef675 	lsl	x21, x19, #2
    52a0:	b50002b4 	cbnz	x20, 52f4 <fwp_tape_grow.constprop.0+0x150>
    52a4:	8b150001 	add	x1, x0, x21
    52a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52ac:	f9000ef3 	str	x19, [x23, #24]
    52b0:	f90016e1 	str	x1, [x23, #40]
    52b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    52bc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52c0:	d65f03c0 	ret
    52c4:	d37ffa73 	lsl	x19, x19, #1
    52c8:	17ffffc1 	b	51cc <fwp_tape_grow.constprop.0+0x28>
    52cc:	eb1502df 	cmp	x22, x21
    52d0:	aa0403e0 	mov	x0, x4
    52d4:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    52d8:	d37df282 	lsl	x2, x20, #3
    52dc:	cb160063 	sub	x3, x3, x22
    52e0:	97fff5f4 	bl	2ab0 <__memmove_chk@plt>
    52e4:	f9401ae1 	ldr	x1, [x23, #48]
    52e8:	f94012e0 	ldr	x0, [x23, #32]
    52ec:	8b160021 	add	x1, x1, x22
    52f0:	f9001ee1 	str	x1, [x23, #56]
    52f4:	f94016e1 	ldr	x1, [x23, #40]
    52f8:	d37ef675 	lsl	x21, x19, #2
    52fc:	d37ef682 	lsl	x2, x20, #2
    5300:	8b150000 	add	x0, x0, x21
    5304:	97fff51f 	bl	2780 <memmove@plt>
    5308:	f94012e0 	ldr	x0, [x23, #32]
    530c:	8b150001 	add	x1, x0, x21
    5310:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5314:	f9000ef3 	str	x19, [x23, #24]
    5318:	f90016e1 	str	x1, [x23, #40]
    531c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5328:	d65f03c0 	ret
    532c:	f9401ae0 	ldr	x0, [x23, #48]
    5330:	d37cee75 	lsl	x21, x19, #4
    5334:	aa1503e1 	mov	x1, x21
    5338:	97fff572 	bl	2900 <realloc@plt>
    533c:	b40002a0 	cbz	x0, 5390 <fwp_tape_grow.constprop.0+0x1ec>
    5340:	f9400ee2 	ldr	x2, [x23, #24]
    5344:	f9001ae0 	str	x0, [x23, #48]
    5348:	8b160004 	add	x4, x0, x22
    534c:	8b020c01 	add	x1, x0, x2, lsl #3
    5350:	f9001ee1 	str	x1, [x23, #56]
    5354:	b5fffbd4 	cbnz	x20, 52cc <fwp_tape_grow.constprop.0+0x128>
    5358:	f94012e0 	ldr	x0, [x23, #32]
    535c:	d37ef675 	lsl	x21, x19, #2
    5360:	f9001ee4 	str	x4, [x23, #56]
    5364:	8b150001 	add	x1, x0, x21
    5368:	a9425bf5 	ldp	x21, x22, [sp, #32]
    536c:	f9000ef3 	str	x19, [x23, #24]
    5370:	f90016e1 	str	x1, [x23, #40]
    5374:	a94153f3 	ldp	x19, x20, [sp, #16]
    5378:	a94363f7 	ldp	x23, x24, [sp, #48]
    537c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5380:	d65f03c0 	ret
    5384:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5388:	9130a000 	add	x0, x0, #0xc28
    538c:	97fffb81 	bl	4190 <fwp_trap>
    5390:	aa1703e0 	mov	x0, x23
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	97fff71e 	bl	3010 <fwp_tape_unlink_scope>
    539c:	f94012e0 	ldr	x0, [x23, #32]
    53a0:	97fff58c 	bl	29d0 <free@plt>
    53a4:	f9401ae0 	ldr	x0, [x23, #48]
    53a8:	97fff58a 	bl	29d0 <free@plt>
    53ac:	f94022e0 	ldr	x0, [x23, #64]
    53b0:	97fff588 	bl	29d0 <free@plt>
    53b4:	f9000eff 	str	xzr, [x23, #24]
    53b8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    53bc:	f947e821 	ldr	x1, [x1, #4048]
    53c0:	a9047eff 	stp	xzr, xzr, [x23, #64]
    53c4:	d2800262 	mov	x2, #0x13                  	// #19
    53c8:	4f000400 	movi	v0.4s, #0x0
    53cc:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    53d0:	f9400023 	ldr	x3, [x1]
    53d4:	b90006ff 	str	wzr, [x23, #4]
    53d8:	d2800021 	mov	x1, #0x1                   	// #1
    53dc:	91222000 	add	x0, x0, #0x888
    53e0:	3c8082e0 	stur	q0, [x23, #8]
    53e4:	ad0102e0 	stp	q0, q0, [x23, #32]
    53e8:	97fff58a 	bl	2a10 <fwrite@plt>
    53ec:	d2800000 	mov	x0, #0x0                   	// #0
    53f0:	97fff594 	bl	2a40 <fflush@plt>
    53f4:	52800cc0 	mov	w0, #0x66                  	// #102
    53f8:	97fff5a2 	bl	2a80 <_Exit@plt>
    53fc:	d503201f 	nop

0000000000005400 <f141.constprop.0>:
    5400:	f100001f 	cmp	x0, #0x0
    5404:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5408:	54000a2b 	b.lt	554c <f141.constprop.0+0x14c>  // b.tstop
    540c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5410:	aa0003e2 	mov	x2, x0
    5414:	910003fd 	mov	x29, sp
    5418:	a90153f3 	stp	x19, x20, [sp, #16]
    541c:	aa0003f4 	mov	x20, x0
    5420:	aa010000 	orr	x0, x0, x1
    5424:	a9025bf5 	stp	x21, x22, [sp, #32]
    5428:	aa0103f6 	mov	x22, x1
    542c:	f9001bf7 	str	x23, [sp, #48]
    5430:	fd001fe8 	str	d8, [sp, #56]
    5434:	b7f80180 	tbnz	x0, #63, 5464 <f141.constprop.0+0x64>
    5438:	9360fc20 	asr	x0, x1, #32
    543c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5440:	eb82801f 	cmp	x0, x2, asr #32
    5444:	54000881 	b.ne	5554 <f141.constprop.0+0x154>  // b.any
    5448:	97fffd56 	bl	49a0 <fwp_tape_of>
    544c:	aa0003f3 	mov	x19, x0
    5450:	f9403000 	ldr	x0, [x0, #96]
    5454:	b40001e0 	cbz	x0, 5490 <f141.constprop.0+0x90>
    5458:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    545c:	91324000 	add	x0, x0, #0xc90
    5460:	97fffb4c 	bl	4190 <fwp_trap>
    5464:	9360fc40 	asr	x0, x2, #32
    5468:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    546c:	b6fffee2 	tbz	x2, #63, 5448 <f141.constprop.0+0x48>
    5470:	2f00e408 	movi	d8, #0x0
    5474:	9360fc20 	asr	x0, x1, #32
    5478:	aa0103f4 	mov	x20, x1
    547c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5480:	97fffd48 	bl	49a0 <fwp_tape_of>
    5484:	aa0003f3 	mov	x19, x0
    5488:	f9403000 	ldr	x0, [x0, #96]
    548c:	b5fffe60 	cbnz	x0, 5458 <f141.constprop.0+0x58>
    5490:	f9400a77 	ldr	x23, [x19, #16]
    5494:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5498:	eb0002ff 	cmp	x23, x0
    549c:	5400046c 	b.gt	5528 <f141.constprop.0+0x128>
    54a0:	eb3442ff 	cmp	x23, w20, uxtw
    54a4:	540004ed 	b.le	5540 <f141.constprop.0+0x140>
    54a8:	b7f80076 	tbnz	x22, #63, 54b4 <f141.constprop.0+0xb4>
    54ac:	eb3642ff 	cmp	x23, w22, uxtw
    54b0:	5400048d 	b.le	5540 <f141.constprop.0+0x140>
    54b4:	f9400675 	ldr	x21, [x19, #8]
    54b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54bc:	cb1502f5 	sub	x21, x23, x21
    54c0:	910006a1 	add	x1, x21, #0x1
    54c4:	eb00003f 	cmp	x1, x0
    54c8:	54000308 	b.hi	5528 <f141.constprop.0+0x128>  // b.pmore
    54cc:	f9400e60 	ldr	x0, [x19, #24]
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	5400030c 	b.gt	5534 <f141.constprop.0+0x134>
    54d8:	a9420262 	ldp	x2, x0, [x19, #32]
    54dc:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54e0:	f9401a61 	ldr	x1, [x19, #48]
    54e4:	b8357854 	str	w20, [x2, x21, lsl #2]
    54e8:	f9401e62 	ldr	x2, [x19, #56]
    54ec:	f10002df 	cmp	x22, #0x0
    54f0:	fc357820 	str	d0, [x1, x21, lsl #3]
    54f4:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    54f8:	b8357816 	str	w22, [x0, x21, lsl #2]
    54fc:	92607e80 	and	x0, x20, #0xffffffff00000000
    5500:	910006e1 	add	x1, x23, #0x1
    5504:	aa170000 	orr	x0, x0, x23
    5508:	fc357848 	str	d8, [x2, x21, lsl #3]
    550c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5510:	f9401bf7 	ldr	x23, [sp, #48]
    5514:	fd401fe8 	ldr	d8, [sp, #56]
    5518:	f9000a61 	str	x1, [x19, #16]
    551c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5520:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5524:	d65f03c0 	ret
    5528:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    552c:	9130a000 	add	x0, x0, #0xc28
    5530:	97fffb18 	bl	4190 <fwp_trap>
    5534:	aa1303e0 	mov	x0, x19
    5538:	97ffff1b 	bl	51a4 <fwp_tape_grow.constprop.0>
    553c:	17ffffe7 	b	54d8 <f141.constprop.0+0xd8>
    5540:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5544:	91330000 	add	x0, x0, #0xcc0
    5548:	97fffb12 	bl	4190 <fwp_trap>
    554c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5550:	d65f03c0 	ret
    5554:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5558:	91312000 	add	x0, x0, #0xc48
    555c:	97fffb0d 	bl	4190 <fwp_trap>

0000000000005560 <w120>:
    5560:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5564:	910003fd 	mov	x29, sp
    5568:	a90153f3 	stp	x19, x20, [sp, #16]
    556c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5570:	a90363f7 	stp	x23, x24, [sp, #48]
    5574:	aa0003f8 	mov	x24, x0
    5578:	a9046bf9 	stp	x25, x26, [sp, #64]
    557c:	aa0103f9 	mov	x25, x1
    5580:	6d0527e8 	stp	d8, d9, [sp, #80]
    5584:	1e604008 	fmov	d8, d0
    5588:	1e604029 	fmov	d9, d1
    558c:	6d062fea 	stp	d10, d11, [sp, #96]
    5590:	1e60080a 	fmul	d10, d0, d0
    5594:	b7f821a0 	tbnz	x0, #63, 59c8 <w120+0x468>
    5598:	9360fc17 	asr	x23, x0, #32
    559c:	aa1703e0 	mov	x0, x23
    55a0:	97fffd00 	bl	49a0 <fwp_tape_of>
    55a4:	f9403001 	ldr	x1, [x0, #96]
    55a8:	aa0003f3 	mov	x19, x0
    55ac:	b4000081 	cbz	x1, 55bc <w120+0x5c>
    55b0:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    55b4:	91324000 	add	x0, x0, #0xc90
    55b8:	97fffaf6 	bl	4190 <fwp_trap>
    55bc:	f9400815 	ldr	x21, [x0, #16]
    55c0:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    55c4:	eb0102bf 	cmp	x21, x1
    55c8:	54001d8c 	b.gt	5978 <w120+0x418>
    55cc:	eb3842bf 	cmp	x21, w24, uxtw
    55d0:	54001ced 	b.le	596c <w120+0x40c>
    55d4:	f9400416 	ldr	x22, [x0, #8]
    55d8:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    55dc:	cb1602b6 	sub	x22, x21, x22
    55e0:	910006c1 	add	x1, x22, #0x1
    55e4:	eb02003f 	cmp	x1, x2
    55e8:	54001c88 	b.hi	5978 <w120+0x418>  // b.pmore
    55ec:	f9400c02 	ldr	x2, [x0, #24]
    55f0:	eb02003f 	cmp	x1, x2
    55f4:	54001c8c 	b.gt	5984 <w120+0x424>
    55f8:	a9420660 	ldp	x0, x1, [x19, #32]
    55fc:	92607f14 	and	x20, x24, #0xffffffff00000000
    5600:	f9401a62 	ldr	x2, [x19, #48]
    5604:	b8367818 	str	w24, [x0, x22, lsl #2]
    5608:	f9401e60 	ldr	x0, [x19, #56]
    560c:	aa150294 	orr	x20, x20, x21
    5610:	fc367848 	str	d8, [x2, x22, lsl #3]
    5614:	910006b5 	add	x21, x21, #0x1
    5618:	b8367838 	str	w24, [x1, x22, lsl #2]
    561c:	1e6a392a 	fsub	d10, d9, d10
    5620:	9360fe9a 	asr	x26, x20, #32
    5624:	fc367808 	str	d8, [x0, x22, lsl #3]
    5628:	f9000a75 	str	x21, [x19, #16]
    562c:	b7f80079 	tbnz	x25, #63, 5638 <w120+0xd8>
    5630:	eb99835f 	cmp	x26, x25, asr #32
    5634:	54001e21 	b.ne	59f8 <w120+0x498>  // b.any
    5638:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    563c:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    5640:	eb1a02ff 	cmp	x23, x26
    5644:	540000c0 	b.eq	565c <w120+0xfc>  // b.none
    5648:	aa1a03e0 	mov	x0, x26
    564c:	97fffcd5 	bl	49a0 <fwp_tape_of>
    5650:	aa0003f3 	mov	x19, x0
    5654:	f9403000 	ldr	x0, [x0, #96]
    5658:	b5fffac0 	cbnz	x0, 55b0 <w120+0x50>
    565c:	f9400a77 	ldr	x23, [x19, #16]
    5660:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5664:	eb0002ff 	cmp	x23, x0
    5668:	5400188c 	b.gt	5978 <w120+0x418>
    566c:	eb3442ff 	cmp	x23, w20, uxtw
    5670:	540017ed 	b.le	596c <w120+0x40c>
    5674:	b7f80079 	tbnz	x25, #63, 5680 <w120+0x120>
    5678:	eb3942ff 	cmp	x23, w25, uxtw
    567c:	5400178d 	b.le	596c <w120+0x40c>
    5680:	f9400675 	ldr	x21, [x19, #8]
    5684:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5688:	cb1502f5 	sub	x21, x23, x21
    568c:	910006a1 	add	x1, x21, #0x1
    5690:	eb00003f 	cmp	x1, x0
    5694:	54001728 	b.hi	5978 <w120+0x418>  // b.pmore
    5698:	f9400e60 	ldr	x0, [x19, #24]
    569c:	eb00003f 	cmp	x1, x0
    56a0:	540018ec 	b.gt	59bc <w120+0x45c>
    56a4:	a9420e62 	ldp	x2, x3, [x19, #32]
    56a8:	f100033f 	cmp	x25, #0x0
    56ac:	f9401a61 	ldr	x1, [x19, #48]
    56b0:	b8357854 	str	w20, [x2, x21, lsl #2]
    56b4:	f9401e62 	ldr	x2, [x19, #56]
    56b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56bc:	fc35782b 	str	d11, [x1, x21, lsl #3]
    56c0:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    56c4:	b8357861 	str	w1, [x3, x21, lsl #2]
    56c8:	910006f6 	add	x22, x23, #0x1
    56cc:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    56d0:	92607e94 	and	x20, x20, #0xffffffff00000000
    56d4:	fc357849 	str	d9, [x2, x21, lsl #3]
    56d8:	aa170294 	orr	x20, x20, x23
    56dc:	f9000a76 	str	x22, [x19, #16]
    56e0:	1e68396b 	fsub	d11, d11, d8
    56e4:	b7f81a78 	tbnz	x24, #63, 5a30 <w120+0x4d0>
    56e8:	9360ff17 	asr	x23, x24, #32
    56ec:	eb1a02ff 	cmp	x23, x26
    56f0:	540000e0 	b.eq	570c <w120+0x1ac>  // b.none
    56f4:	aa1703e0 	mov	x0, x23
    56f8:	97fffcaa 	bl	49a0 <fwp_tape_of>
    56fc:	aa0003f3 	mov	x19, x0
    5700:	f9403000 	ldr	x0, [x0, #96]
    5704:	b5fff560 	cbnz	x0, 55b0 <w120+0x50>
    5708:	f9400a76 	ldr	x22, [x19, #16]
    570c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5710:	eb0002df 	cmp	x22, x0
    5714:	5400132c 	b.gt	5978 <w120+0x418>
    5718:	eb3842df 	cmp	x22, w24, uxtw
    571c:	5400128d 	b.le	596c <w120+0x40c>
    5720:	f9400675 	ldr	x21, [x19, #8]
    5724:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5728:	cb1502d5 	sub	x21, x22, x21
    572c:	910006a1 	add	x1, x21, #0x1
    5730:	eb00003f 	cmp	x1, x0
    5734:	54001228 	b.hi	5978 <w120+0x418>  // b.pmore
    5738:	f9400e60 	ldr	x0, [x19, #24]
    573c:	eb00003f 	cmp	x1, x0
    5740:	5400138c 	b.gt	59b0 <w120+0x450>
    5744:	a9420262 	ldp	x2, x0, [x19, #32]
    5748:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    574c:	f9401a63 	ldr	x3, [x19, #48]
    5750:	b8357858 	str	w24, [x2, x21, lsl #2]
    5754:	f9401e62 	ldr	x2, [x19, #56]
    5758:	12800001 	mov	w1, #0xffffffff            	// #-1
    575c:	fc357860 	str	d0, [x3, x21, lsl #3]
    5760:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5764:	b8357801 	str	w1, [x0, x21, lsl #2]
    5768:	92607f00 	and	x0, x24, #0xffffffff00000000
    576c:	aa160018 	orr	x24, x0, x22
    5770:	910006c1 	add	x1, x22, #0x1
    5774:	fc357840 	str	d0, [x2, x21, lsl #3]
    5778:	f9000a61 	str	x1, [x19, #16]
    577c:	9360fe99 	asr	x25, x20, #32
    5780:	1e6a0949 	fmul	d9, d10, d10
    5784:	eb17033f 	cmp	x25, x23
    5788:	540000c0 	b.eq	57a0 <w120+0x240>  // b.none
    578c:	aa1903e0 	mov	x0, x25
    5790:	97fffc84 	bl	49a0 <fwp_tape_of>
    5794:	aa0003f3 	mov	x19, x0
    5798:	f9403000 	ldr	x0, [x0, #96]
    579c:	b5fff0a0 	cbnz	x0, 55b0 <w120+0x50>
    57a0:	f9400a75 	ldr	x21, [x19, #16]
    57a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57a8:	eb0002bf 	cmp	x21, x0
    57ac:	54000e6c 	b.gt	5978 <w120+0x418>
    57b0:	eb3442bf 	cmp	x21, w20, uxtw
    57b4:	54000dcd 	b.le	596c <w120+0x40c>
    57b8:	f9400676 	ldr	x22, [x19, #8]
    57bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57c0:	cb1602b6 	sub	x22, x21, x22
    57c4:	910006c1 	add	x1, x22, #0x1
    57c8:	eb00003f 	cmp	x1, x0
    57cc:	54000d68 	b.hi	5978 <w120+0x418>  // b.pmore
    57d0:	f9400e60 	ldr	x0, [x19, #24]
    57d4:	eb00003f 	cmp	x1, x0
    57d8:	54000e6c 	b.gt	59a4 <w120+0x444>
    57dc:	92607e80 	and	x0, x20, #0xffffffff00000000
    57e0:	aa150017 	orr	x23, x0, x21
    57e4:	a9420261 	ldp	x1, x0, [x19, #32]
    57e8:	f9401a62 	ldr	x2, [x19, #48]
    57ec:	b8367834 	str	w20, [x1, x22, lsl #2]
    57f0:	f9401e61 	ldr	x1, [x19, #56]
    57f4:	fc36784a 	str	d10, [x2, x22, lsl #3]
    57f8:	b8367814 	str	w20, [x0, x22, lsl #2]
    57fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5800:	9e670000 	fmov	d0, x0
    5804:	910006b4 	add	x20, x21, #0x1
    5808:	fc36782a 	str	d10, [x1, x22, lsl #3]
    580c:	9360fef6 	asr	x22, x23, #32
    5810:	f9000a74 	str	x20, [x19, #16]
    5814:	1e600929 	fmul	d9, d9, d0
    5818:	eb1902df 	cmp	x22, x25
    581c:	540000e0 	b.eq	5838 <w120+0x2d8>  // b.none
    5820:	aa1603e0 	mov	x0, x22
    5824:	97fffc5f 	bl	49a0 <fwp_tape_of>
    5828:	aa0003f3 	mov	x19, x0
    582c:	f9403000 	ldr	x0, [x0, #96]
    5830:	b5ffec00 	cbnz	x0, 55b0 <w120+0x50>
    5834:	f9400a74 	ldr	x20, [x19, #16]
    5838:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    583c:	eb00029f 	cmp	x20, x0
    5840:	540009cc 	b.gt	5978 <w120+0x418>
    5844:	eb37429f 	cmp	x20, w23, uxtw
    5848:	5400092d 	b.le	596c <w120+0x40c>
    584c:	f9400675 	ldr	x21, [x19, #8]
    5850:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5854:	cb150295 	sub	x21, x20, x21
    5858:	910006a1 	add	x1, x21, #0x1
    585c:	eb00003f 	cmp	x1, x0
    5860:	540008c8 	b.hi	5978 <w120+0x418>  // b.pmore
    5864:	f9400e60 	ldr	x0, [x19, #24]
    5868:	eb00003f 	cmp	x1, x0
    586c:	5400096c 	b.gt	5998 <w120+0x438>
    5870:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5874:	9e670000 	fmov	d0, x0
    5878:	a9420262 	ldp	x2, x0, [x19, #32]
    587c:	1e6b0968 	fmul	d8, d11, d11
    5880:	f9401a61 	ldr	x1, [x19, #48]
    5884:	b8357857 	str	w23, [x2, x21, lsl #2]
    5888:	f9401e62 	ldr	x2, [x19, #56]
    588c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5890:	12800001 	mov	w1, #0xffffffff            	// #-1
    5894:	b8357801 	str	w1, [x0, x21, lsl #2]
    5898:	91000681 	add	x1, x20, #0x1
    589c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    58a0:	92607ee0 	and	x0, x23, #0xffffffff00000000
    58a4:	f9000a61 	str	x1, [x19, #16]
    58a8:	aa140014 	orr	x20, x0, x20
    58ac:	b100071f 	cmn	x24, #0x1
    58b0:	54000c60 	b.eq	5a3c <w120+0x4dc>  // b.none
    58b4:	9360ff00 	asr	x0, x24, #32
    58b8:	eb16001f 	cmp	x0, x22
    58bc:	540000a0 	b.eq	58d0 <w120+0x370>  // b.none
    58c0:	97fffc38 	bl	49a0 <fwp_tape_of>
    58c4:	aa0003f3 	mov	x19, x0
    58c8:	f9403000 	ldr	x0, [x0, #96]
    58cc:	b5ffe720 	cbnz	x0, 55b0 <w120+0x50>
    58d0:	f9400a75 	ldr	x21, [x19, #16]
    58d4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58d8:	eb0002bf 	cmp	x21, x0
    58dc:	540004ec 	b.gt	5978 <w120+0x418>
    58e0:	eb3842bf 	cmp	x21, w24, uxtw
    58e4:	5400044d 	b.le	596c <w120+0x40c>
    58e8:	f9400676 	ldr	x22, [x19, #8]
    58ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    58f0:	cb1602b6 	sub	x22, x21, x22
    58f4:	910006c1 	add	x1, x22, #0x1
    58f8:	eb00003f 	cmp	x1, x0
    58fc:	540003e8 	b.hi	5978 <w120+0x418>  // b.pmore
    5900:	f9400e60 	ldr	x0, [x19, #24]
    5904:	eb00003f 	cmp	x1, x0
    5908:	5400042c 	b.gt	598c <w120+0x42c>
    590c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5910:	92607f00 	and	x0, x24, #0xffffffff00000000
    5914:	f9401a63 	ldr	x3, [x19, #48]
    5918:	b8367838 	str	w24, [x1, x22, lsl #2]
    591c:	f9401e61 	ldr	x1, [x19, #56]
    5920:	aa150000 	orr	x0, x0, x21
    5924:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5928:	910006b5 	add	x21, x21, #0x1
    592c:	b8367858 	str	w24, [x2, x22, lsl #2]
    5930:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5934:	f9000a75 	str	x21, [x19, #16]
    5938:	1e692908 	fadd	d8, d8, d9
    593c:	aa1403e1 	mov	x1, x20
    5940:	97fffeb0 	bl	5400 <f141.constprop.0>
    5944:	aa0003e1 	mov	x1, x0
    5948:	a94153f3 	ldp	x19, x20, [sp, #16]
    594c:	9e660100 	fmov	x0, d8
    5950:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5954:	a94363f7 	ldp	x23, x24, [sp, #48]
    5958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    595c:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5960:	6d462fea 	ldp	d10, d11, [sp, #96]
    5964:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5968:	d65f03c0 	ret
    596c:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5970:	91330000 	add	x0, x0, #0xcc0
    5974:	97fffa07 	bl	4190 <fwp_trap>
    5978:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    597c:	9130a000 	add	x0, x0, #0xc28
    5980:	97fffa04 	bl	4190 <fwp_trap>
    5984:	97fffe08 	bl	51a4 <fwp_tape_grow.constprop.0>
    5988:	17ffff1c 	b	55f8 <w120+0x98>
    598c:	aa1303e0 	mov	x0, x19
    5990:	97fffe05 	bl	51a4 <fwp_tape_grow.constprop.0>
    5994:	17ffffde 	b	590c <w120+0x3ac>
    5998:	aa1303e0 	mov	x0, x19
    599c:	97fffe02 	bl	51a4 <fwp_tape_grow.constprop.0>
    59a0:	17ffffb4 	b	5870 <w120+0x310>
    59a4:	aa1303e0 	mov	x0, x19
    59a8:	97fffdff 	bl	51a4 <fwp_tape_grow.constprop.0>
    59ac:	17ffff8c 	b	57dc <w120+0x27c>
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	97fffdfc 	bl	51a4 <fwp_tape_grow.constprop.0>
    59b8:	17ffff63 	b	5744 <w120+0x1e4>
    59bc:	aa1303e0 	mov	x0, x19
    59c0:	97fffdf9 	bl	51a4 <fwp_tape_grow.constprop.0>
    59c4:	17ffff38 	b	56a4 <w120+0x144>
    59c8:	1e6a382a 	fsub	d10, d1, d10
    59cc:	b6f801c1 	tbz	x1, #63, 5a04 <w120+0x4a4>
    59d0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    59d4:	1e6a0949 	fmul	d9, d10, d10
    59d8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    59dc:	9e670001 	fmov	d1, x0
    59e0:	1e683808 	fsub	d8, d0, d8
    59e4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    59e8:	aa1403e0 	mov	x0, x20
    59ec:	1e610929 	fmul	d9, d9, d1
    59f0:	1e680908 	fmul	d8, d8, d8
    59f4:	17ffffd1 	b	5938 <w120+0x3d8>
    59f8:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    59fc:	91312000 	add	x0, x0, #0xc48
    5a00:	97fff9e4 	bl	4190 <fwp_trap>
    5a04:	2f00e409 	movi	d9, #0x0
    5a08:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5a0c:	9360fc3a 	asr	x26, x1, #32
    5a10:	aa0103f4 	mov	x20, x1
    5a14:	aa1a03e0 	mov	x0, x26
    5a18:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5a1c:	97fffbe1 	bl	49a0 <fwp_tape_of>
    5a20:	aa0003f3 	mov	x19, x0
    5a24:	f9403000 	ldr	x0, [x0, #96]
    5a28:	b5ffdc40 	cbnz	x0, 55b0 <w120+0x50>
    5a2c:	17ffff0c 	b	565c <w120+0xfc>
    5a30:	aa1a03f7 	mov	x23, x26
    5a34:	aa0003f8 	mov	x24, x0
    5a38:	17ffff51 	b	577c <w120+0x21c>
    5a3c:	aa1803e0 	mov	x0, x24
    5a40:	17ffffbe 	b	5938 <w120+0x3d8>

0000000000005a44 <fwp_rc_share>:
    5a44:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5a48:	91170042 	add	x2, x2, #0x5c0
    5a4c:	f949d843 	ldr	x3, [x2, #5040]
    5a50:	f949ec41 	ldr	x1, [x2, #5080]
    5a54:	cb030000 	sub	x0, x0, x3
    5a58:	eb01401f 	cmp	x0, x1, lsl #16
    5a5c:	540003a2 	b.cs	5ad0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5a60:	d350fc01 	lsr	x1, x0, #16
    5a64:	f949fc44 	ldr	x4, [x2, #5112]
    5a68:	8b010821 	add	x1, x1, x1, lsl #2
    5a6c:	d37df021 	lsl	x1, x1, #3
    5a70:	8b010083 	add	x3, x4, x1
    5a74:	f9401062 	ldr	x2, [x3, #32]
    5a78:	b40002c2 	cbz	x2, 5ad0 <fwp_rc_share+0x8c>
    5a7c:	38616881 	ldrb	w1, [x4, x1]
    5a80:	7100083f 	cmp	w1, #0x2
    5a84:	54000220 	b.eq	5ac8 <fwp_rc_share+0x84>  // b.none
    5a88:	7100043f 	cmp	w1, #0x1
    5a8c:	54000221 	b.ne	5ad0 <fwp_rc_share+0x8c>  // b.any
    5a90:	29430464 	ldp	w4, w1, [x3, #24]
    5a94:	92403c00 	and	x0, x0, #0xffff
    5a98:	9b047c00 	mul	x0, x0, x4
    5a9c:	d360fc00 	lsr	x0, x0, #32
    5aa0:	eb01001f 	cmp	x0, x1
    5aa4:	54000162 	b.cs	5ad0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5aa8:	8b000042 	add	x2, x2, x0
    5aac:	39400040 	ldrb	w0, [x2]
    5ab0:	34000100 	cbz	w0, 5ad0 <fwp_rc_share+0x8c>
    5ab4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ab8:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5abc:	91338000 	add	x0, x0, #0xce0
    5ac0:	910003fd 	mov	x29, sp
    5ac4:	97fff9b3 	bl	4190 <fwp_trap>
    5ac8:	72003c1f 	tst	w0, #0xffff
    5acc:	54ffff00 	b.eq	5aac <fwp_rc_share+0x68>  // b.none
    5ad0:	d65f03c0 	ret

0000000000005ad4 <fwp_rc_free_arr>:
    5ad4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5ad8:	91170063 	add	x3, x3, #0x5c0
    5adc:	f949d861 	ldr	x1, [x3, #5040]
    5ae0:	f949ec62 	ldr	x2, [x3, #5080]
    5ae4:	cb010001 	sub	x1, x0, x1
    5ae8:	eb02403f 	cmp	x1, x2, lsl #16
    5aec:	54000342 	b.cs	5b54 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5af0:	d350fc22 	lsr	x2, x1, #16
    5af4:	f949fc65 	ldr	x5, [x3, #5112]
    5af8:	8b020842 	add	x2, x2, x2, lsl #2
    5afc:	d37df042 	lsl	x2, x2, #3
    5b00:	8b0200a4 	add	x4, x5, x2
    5b04:	f9401083 	ldr	x3, [x4, #32]
    5b08:	b4000263 	cbz	x3, 5b54 <fwp_rc_free_arr+0x80>
    5b0c:	386268a2 	ldrb	w2, [x5, x2]
    5b10:	7100085f 	cmp	w2, #0x2
    5b14:	540001c0 	b.eq	5b4c <fwp_rc_free_arr+0x78>  // b.none
    5b18:	7100045f 	cmp	w2, #0x1
    5b1c:	540001c1 	b.ne	5b54 <fwp_rc_free_arr+0x80>  // b.any
    5b20:	29430885 	ldp	w5, w2, [x4, #24]
    5b24:	92403c21 	and	x1, x1, #0xffff
    5b28:	9b057c21 	mul	x1, x1, x5
    5b2c:	d360fc21 	lsr	x1, x1, #32
    5b30:	eb02003f 	cmp	x1, x2
    5b34:	54000102 	b.cs	5b54 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b38:	8b010063 	add	x3, x3, x1
    5b3c:	39400061 	ldrb	w1, [x3]
    5b40:	7100043f 	cmp	w1, #0x1
    5b44:	54000081 	b.ne	5b54 <fwp_rc_free_arr+0x80>  // b.any
    5b48:	17fffa4e 	b	4480 <fwp_mem_free>
    5b4c:	72003c3f 	tst	w1, #0xffff
    5b50:	54ffff60 	b.eq	5b3c <fwp_rc_free_arr+0x68>  // b.none
    5b54:	d65f03c0 	ret
    5b58:	d503201f 	nop
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_rc_dup>:
    5b60:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5b64:	91170042 	add	x2, x2, #0x5c0
    5b68:	f949d841 	ldr	x1, [x2, #5040]
    5b6c:	f949ec43 	ldr	x3, [x2, #5080]
    5b70:	cb010001 	sub	x1, x0, x1
    5b74:	eb03403f 	cmp	x1, x3, lsl #16
    5b78:	54000342 	b.cs	5be0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5b7c:	d350fc20 	lsr	x0, x1, #16
    5b80:	f949fc44 	ldr	x4, [x2, #5112]
    5b84:	8b000800 	add	x0, x0, x0, lsl #2
    5b88:	d37df002 	lsl	x2, x0, #3
    5b8c:	8b020083 	add	x3, x4, x2
    5b90:	f9401060 	ldr	x0, [x3, #32]
    5b94:	b4000260 	cbz	x0, 5be0 <fwp_rc_dup+0x80>
    5b98:	38626882 	ldrb	w2, [x4, x2]
    5b9c:	7100085f 	cmp	w2, #0x2
    5ba0:	54000220 	b.eq	5be4 <fwp_rc_dup+0x84>  // b.none
    5ba4:	7100045f 	cmp	w2, #0x1
    5ba8:	540001c1 	b.ne	5be0 <fwp_rc_dup+0x80>  // b.any
    5bac:	29430864 	ldp	w4, w2, [x3, #24]
    5bb0:	92403c21 	and	x1, x1, #0xffff
    5bb4:	9b047c21 	mul	x1, x1, x4
    5bb8:	d360fc21 	lsr	x1, x1, #32
    5bbc:	eb02003f 	cmp	x1, x2
    5bc0:	54000102 	b.cs	5be0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5bc4:	8b010000 	add	x0, x0, x1
    5bc8:	39400001 	ldrb	w1, [x0]
    5bcc:	340000a1 	cbz	w1, 5be0 <fwp_rc_dup+0x80>
    5bd0:	7103f43f 	cmp	w1, #0xfd
    5bd4:	540000e8 	b.hi	5bf0 <fwp_rc_dup+0x90>  // b.pmore
    5bd8:	11000421 	add	w1, w1, #0x1
    5bdc:	39000001 	strb	w1, [x0]
    5be0:	d65f03c0 	ret
    5be4:	72003c3f 	tst	w1, #0xffff
    5be8:	54ffff00 	b.eq	5bc8 <fwp_rc_dup+0x68>  // b.none
    5bec:	d65f03c0 	ret
    5bf0:	17fffa9d 	b	4664 <fwp_rc_wide_dup>

0000000000005bf4 <fwp_owned_entry173>:
    5bf4:	d10103ff 	sub	sp, sp, #0x40
    5bf8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5bfc:	f947f442 	ldr	x2, [x2, #4072]
    5c00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c04:	910083fd 	add	x29, sp, #0x20
    5c08:	a90353f3 	stp	x19, x20, [sp, #48]
    5c0c:	f9400043 	ldr	x3, [x2]
    5c10:	f9000fe3 	str	x3, [sp, #24]
    5c14:	d2800003 	mov	x3, #0x0                   	// #0
    5c18:	a9400c01 	ldp	x1, x3, [x0]
    5c1c:	f9400802 	ldr	x2, [x0, #16]
    5c20:	ab020022 	adds	x2, x1, x2
    5c24:	540006e6 	b.vs	5d00 <fwp_owned_entry173+0x10c>
    5c28:	910023e1 	add	x1, sp, #0x8
    5c2c:	52800000 	mov	w0, #0x0                   	// #0
    5c30:	a9008be3 	stp	x3, x2, [sp, #8]
    5c34:	97fffd14 	bl	5084 <fwp_data.part.0.constprop.0>
    5c38:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5c3c:	91170063 	add	x3, x3, #0x5c0
    5c40:	aa0003f3 	mov	x19, x0
    5c44:	f949d861 	ldr	x1, [x3, #5040]
    5c48:	f949ec60 	ldr	x0, [x3, #5080]
    5c4c:	cb010261 	sub	x1, x19, x1
    5c50:	eb00403f 	cmp	x1, x0, lsl #16
    5c54:	54000322 	b.cs	5cb8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c58:	d350fc22 	lsr	x2, x1, #16
    5c5c:	f949fc63 	ldr	x3, [x3, #5112]
    5c60:	8b020842 	add	x2, x2, x2, lsl #2
    5c64:	d37df042 	lsl	x2, x2, #3
    5c68:	8b020060 	add	x0, x3, x2
    5c6c:	f9401014 	ldr	x20, [x0, #32]
    5c70:	b4000254 	cbz	x20, 5cb8 <fwp_owned_entry173+0xc4>
    5c74:	38626862 	ldrb	w2, [x3, x2]
    5c78:	7100085f 	cmp	w2, #0x2
    5c7c:	54000360 	b.eq	5ce8 <fwp_owned_entry173+0xf4>  // b.none
    5c80:	7100045f 	cmp	w2, #0x1
    5c84:	540001a1 	b.ne	5cb8 <fwp_owned_entry173+0xc4>  // b.any
    5c88:	29430002 	ldp	w2, w0, [x0, #24]
    5c8c:	92403c21 	and	x1, x1, #0xffff
    5c90:	9b027c21 	mul	x1, x1, x2
    5c94:	d360fc21 	lsr	x1, x1, #32
    5c98:	eb00003f 	cmp	x1, x0
    5c9c:	540000e2 	b.cs	5cb8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ca0:	8b010294 	add	x20, x20, x1
    5ca4:	39400280 	ldrb	w0, [x20]
    5ca8:	7103fc1f 	cmp	w0, #0xff
    5cac:	54000240 	b.eq	5cf4 <fwp_owned_entry173+0x100>  // b.none
    5cb0:	52800020 	mov	w0, #0x1                   	// #1
    5cb4:	39000280 	strb	w0, [x20]
    5cb8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5cbc:	f947f400 	ldr	x0, [x0, #4072]
    5cc0:	f9400fe2 	ldr	x2, [sp, #24]
    5cc4:	f9400001 	ldr	x1, [x0]
    5cc8:	eb010042 	subs	x2, x2, x1
    5ccc:	d2800001 	mov	x1, #0x0                   	// #0
    5cd0:	540001a1 	b.ne	5d04 <fwp_owned_entry173+0x110>  // b.any
    5cd4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5cd8:	aa1303e0 	mov	x0, x19
    5cdc:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ce0:	910103ff 	add	sp, sp, #0x40
    5ce4:	d65f03c0 	ret
    5ce8:	72003c3f 	tst	w1, #0xffff
    5cec:	54fffe61 	b.ne	5cb8 <fwp_owned_entry173+0xc4>  // b.any
    5cf0:	17ffffed 	b	5ca4 <fwp_owned_entry173+0xb0>
    5cf4:	aa1403e0 	mov	x0, x20
    5cf8:	97fff946 	bl	4210 <fwp_rc_forget_slot.part.0>
    5cfc:	17ffffed 	b	5cb0 <fwp_owned_entry173+0xbc>
    5d00:	97fff380 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5d04:	97fff303 	bl	2910 <__stack_chk_fail@plt>
    5d08:	d503201f 	nop
    5d0c:	d503201f 	nop

0000000000005d10 <e173>:
    5d10:	d10103ff 	sub	sp, sp, #0x40
    5d14:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5d18:	f947f442 	ldr	x2, [x2, #4072]
    5d1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d20:	910083fd 	add	x29, sp, #0x20
    5d24:	a90353f3 	stp	x19, x20, [sp, #48]
    5d28:	f9400043 	ldr	x3, [x2]
    5d2c:	f9000fe3 	str	x3, [sp, #24]
    5d30:	d2800003 	mov	x3, #0x0                   	// #0
    5d34:	a9400c01 	ldp	x1, x3, [x0]
    5d38:	f9400802 	ldr	x2, [x0, #16]
    5d3c:	ab020022 	adds	x2, x1, x2
    5d40:	54000726 	b.vs	5e24 <e173+0x114>
    5d44:	910023e1 	add	x1, sp, #0x8
    5d48:	52800000 	mov	w0, #0x0                   	// #0
    5d4c:	a9008be3 	stp	x3, x2, [sp, #8]
    5d50:	97fffccd 	bl	5084 <fwp_data.part.0.constprop.0>
    5d54:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5d58:	91170063 	add	x3, x3, #0x5c0
    5d5c:	aa0003f3 	mov	x19, x0
    5d60:	f949d861 	ldr	x1, [x3, #5040]
    5d64:	f949ec60 	ldr	x0, [x3, #5080]
    5d68:	cb010261 	sub	x1, x19, x1
    5d6c:	eb00403f 	cmp	x1, x0, lsl #16
    5d70:	54000322 	b.cs	5dd4 <e173+0xc4>  // b.hs, b.nlast
    5d74:	d350fc22 	lsr	x2, x1, #16
    5d78:	f949fc63 	ldr	x3, [x3, #5112]
    5d7c:	8b020842 	add	x2, x2, x2, lsl #2
    5d80:	d37df042 	lsl	x2, x2, #3
    5d84:	8b020060 	add	x0, x3, x2
    5d88:	f9401014 	ldr	x20, [x0, #32]
    5d8c:	b4000254 	cbz	x20, 5dd4 <e173+0xc4>
    5d90:	38626862 	ldrb	w2, [x3, x2]
    5d94:	7100085f 	cmp	w2, #0x2
    5d98:	540003a0 	b.eq	5e0c <e173+0xfc>  // b.none
    5d9c:	7100045f 	cmp	w2, #0x1
    5da0:	540001a1 	b.ne	5dd4 <e173+0xc4>  // b.any
    5da4:	29430002 	ldp	w2, w0, [x0, #24]
    5da8:	92403c21 	and	x1, x1, #0xffff
    5dac:	9b027c21 	mul	x1, x1, x2
    5db0:	d360fc21 	lsr	x1, x1, #32
    5db4:	eb00003f 	cmp	x1, x0
    5db8:	540000e2 	b.cs	5dd4 <e173+0xc4>  // b.hs, b.nlast
    5dbc:	8b010294 	add	x20, x20, x1
    5dc0:	39400280 	ldrb	w0, [x20]
    5dc4:	7103fc1f 	cmp	w0, #0xff
    5dc8:	54000280 	b.eq	5e18 <e173+0x108>  // b.none
    5dcc:	52800020 	mov	w0, #0x1                   	// #1
    5dd0:	39000280 	strb	w0, [x20]
    5dd4:	aa1303e0 	mov	x0, x19
    5dd8:	97ffff1b 	bl	5a44 <fwp_rc_share>
    5ddc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5de0:	f947f400 	ldr	x0, [x0, #4072]
    5de4:	f9400fe2 	ldr	x2, [sp, #24]
    5de8:	f9400001 	ldr	x1, [x0]
    5dec:	eb010042 	subs	x2, x2, x1
    5df0:	d2800001 	mov	x1, #0x0                   	// #0
    5df4:	540001a1 	b.ne	5e28 <e173+0x118>  // b.any
    5df8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5dfc:	aa1303e0 	mov	x0, x19
    5e00:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e04:	910103ff 	add	sp, sp, #0x40
    5e08:	d65f03c0 	ret
    5e0c:	72003c3f 	tst	w1, #0xffff
    5e10:	54fffe21 	b.ne	5dd4 <e173+0xc4>  // b.any
    5e14:	17ffffeb 	b	5dc0 <e173+0xb0>
    5e18:	aa1403e0 	mov	x0, x20
    5e1c:	97fff8fd 	bl	4210 <fwp_rc_forget_slot.part.0>
    5e20:	17ffffeb 	b	5dcc <e173+0xbc>
    5e24:	97fff337 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5e28:	97fff2ba 	bl	2910 <__stack_chk_fail@plt>
    5e2c:	d503201f 	nop

0000000000005e30 <fwp_drop1>:
    5e30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e34:	910003fd 	mov	x29, sp
    5e38:	a90153f3 	stp	x19, x20, [sp, #16]
    5e3c:	f90013f5 	str	x21, [sp, #32]
    5e40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5e44:	911702b4 	add	x20, x21, #0x5c0
    5e48:	f949da81 	ldr	x1, [x20, #5040]
    5e4c:	f949ee82 	ldr	x2, [x20, #5080]
    5e50:	cb010001 	sub	x1, x0, x1
    5e54:	eb02403f 	cmp	x1, x2, lsl #16
    5e58:	54000382 	b.cs	5ec8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e5c:	d350fc22 	lsr	x2, x1, #16
    5e60:	f949fe84 	ldr	x4, [x20, #5112]
    5e64:	8b020842 	add	x2, x2, x2, lsl #2
    5e68:	d37df042 	lsl	x2, x2, #3
    5e6c:	8b020083 	add	x3, x4, x2
    5e70:	f9401073 	ldr	x19, [x3, #32]
    5e74:	b40002b3 	cbz	x19, 5ec8 <fwp_drop1+0x98>
    5e78:	38626882 	ldrb	w2, [x4, x2]
    5e7c:	7100085f 	cmp	w2, #0x2
    5e80:	540002c0 	b.eq	5ed8 <fwp_drop1+0xa8>  // b.none
    5e84:	7100045f 	cmp	w2, #0x1
    5e88:	54000201 	b.ne	5ec8 <fwp_drop1+0x98>  // b.any
    5e8c:	29430864 	ldp	w4, w2, [x3, #24]
    5e90:	92403c21 	and	x1, x1, #0xffff
    5e94:	9b047c21 	mul	x1, x1, x4
    5e98:	d360fc21 	lsr	x1, x1, #32
    5e9c:	eb02003f 	cmp	x1, x2
    5ea0:	54000142 	b.cs	5ec8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ea4:	8b010273 	add	x19, x19, x1
    5ea8:	39400261 	ldrb	w1, [x19]
    5eac:	340000e1 	cbz	w1, 5ec8 <fwp_drop1+0x98>
    5eb0:	7100043f 	cmp	w1, #0x1
    5eb4:	540001e0 	b.eq	5ef0 <fwp_drop1+0xc0>  // b.none
    5eb8:	7103fc3f 	cmp	w1, #0xff
    5ebc:	540002e0 	b.eq	5f18 <fwp_drop1+0xe8>  // b.none
    5ec0:	51000421 	sub	w1, w1, #0x1
    5ec4:	39000261 	strb	w1, [x19]
    5ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ecc:	f94013f5 	ldr	x21, [sp, #32]
    5ed0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ed4:	d65f03c0 	ret
    5ed8:	72003c3f 	tst	w1, #0xffff
    5edc:	54fffe60 	b.eq	5ea8 <fwp_drop1+0x78>  // b.none
    5ee0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ee4:	f94013f5 	ldr	x21, [sp, #32]
    5ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5eec:	d65f03c0 	ret
    5ef0:	f9400813 	ldr	x19, [x0, #16]
    5ef4:	97fffef8 	bl	5ad4 <fwp_rc_free_arr>
    5ef8:	911702a0 	add	x0, x21, #0x5c0
    5efc:	f949d801 	ldr	x1, [x0, #5040]
    5f00:	f949ec00 	ldr	x0, [x0, #5080]
    5f04:	cb010261 	sub	x1, x19, x1
    5f08:	eb00403f 	cmp	x1, x0, lsl #16
    5f0c:	54fffde2 	b.cs	5ec8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f10:	aa1303e0 	mov	x0, x19
    5f14:	17ffffd2 	b	5e5c <fwp_drop1+0x2c>
    5f18:	ca534660 	eor	x0, x19, x19, lsr #17
    5f1c:	911702b5 	add	x21, x21, #0x5c0
    5f20:	ca402400 	eor	x0, x0, x0, lsr #9
    5f24:	92401c00 	and	x0, x0, #0xff
    5f28:	910a2402 	add	x2, x0, #0x289
    5f2c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5f30:	8b020ea2 	add	x2, x21, x2, lsl #3
    5f34:	f94a2400 	ldr	x0, [x0, #5192]
    5f38:	b50000a0 	cbnz	x0, 5f4c <fwp_drop1+0x11c>
    5f3c:	14000013 	b	5f88 <fwp_drop1+0x158>
    5f40:	91004002 	add	x2, x0, #0x10
    5f44:	f9400800 	ldr	x0, [x0, #16]
    5f48:	b4000200 	cbz	x0, 5f88 <fwp_drop1+0x158>
    5f4c:	f9400001 	ldr	x1, [x0]
    5f50:	eb13003f 	cmp	x1, x19
    5f54:	54ffff61 	b.ne	5f40 <fwp_drop1+0x110>  // b.any
    5f58:	f9400041 	ldr	x1, [x2]
    5f5c:	f9400420 	ldr	x0, [x1, #8]
    5f60:	d1000400 	sub	x0, x0, #0x1
    5f64:	f9000420 	str	x0, [x1, #8]
    5f68:	f103f81f 	cmp	x0, #0xfe
    5f6c:	54fffae1 	b.ne	5ec8 <fwp_drop1+0x98>  // b.any
    5f70:	39400260 	ldrb	w0, [x19]
    5f74:	7103fc1f 	cmp	w0, #0xff
    5f78:	540000e0 	b.eq	5f94 <fwp_drop1+0x164>  // b.none
    5f7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f80:	39000260 	strb	w0, [x19]
    5f84:	17ffffd1 	b	5ec8 <fwp_drop1+0x98>
    5f88:	90000020 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    5f8c:	9129e000 	add	x0, x0, #0xa78
    5f90:	97fff880 	bl	4190 <fwp_trap>
    5f94:	aa1303e0 	mov	x0, x19
    5f98:	97fff89e 	bl	4210 <fwp_rc_forget_slot.part.0>
    5f9c:	17fffff8 	b	5f7c <fwp_drop1+0x14c>

0000000000005fa0 <fwp_drop0>:
    5fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fa4:	910003fd 	mov	x29, sp
    5fa8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fac:	f90013f5 	str	x21, [sp, #32]
    5fb0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5fb4:	911702b4 	add	x20, x21, #0x5c0
    5fb8:	f949da81 	ldr	x1, [x20, #5040]
    5fbc:	f949ee82 	ldr	x2, [x20, #5080]
    5fc0:	cb010001 	sub	x1, x0, x1
    5fc4:	eb02403f 	cmp	x1, x2, lsl #16
    5fc8:	54000382 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fcc:	d350fc22 	lsr	x2, x1, #16
    5fd0:	f949fe84 	ldr	x4, [x20, #5112]
    5fd4:	8b020842 	add	x2, x2, x2, lsl #2
    5fd8:	d37df042 	lsl	x2, x2, #3
    5fdc:	8b020083 	add	x3, x4, x2
    5fe0:	f9401073 	ldr	x19, [x3, #32]
    5fe4:	b40002b3 	cbz	x19, 6038 <fwp_drop0+0x98>
    5fe8:	38626882 	ldrb	w2, [x4, x2]
    5fec:	7100085f 	cmp	w2, #0x2
    5ff0:	540002c0 	b.eq	6048 <fwp_drop0+0xa8>  // b.none
    5ff4:	7100045f 	cmp	w2, #0x1
    5ff8:	54000201 	b.ne	6038 <fwp_drop0+0x98>  // b.any
    5ffc:	29430864 	ldp	w4, w2, [x3, #24]
    6000:	92403c21 	and	x1, x1, #0xffff
    6004:	9b047c21 	mul	x1, x1, x4
    6008:	d360fc21 	lsr	x1, x1, #32
    600c:	eb02003f 	cmp	x1, x2
    6010:	54000142 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    6014:	8b010273 	add	x19, x19, x1
    6018:	39400261 	ldrb	w1, [x19]
    601c:	340000e1 	cbz	w1, 6038 <fwp_drop0+0x98>
    6020:	7100043f 	cmp	w1, #0x1
    6024:	540001e0 	b.eq	6060 <fwp_drop0+0xc0>  // b.none
    6028:	7103fc3f 	cmp	w1, #0xff
    602c:	540002e0 	b.eq	6088 <fwp_drop0+0xe8>  // b.none
    6030:	51000421 	sub	w1, w1, #0x1
    6034:	39000261 	strb	w1, [x19]
    6038:	a94153f3 	ldp	x19, x20, [sp, #16]
    603c:	f94013f5 	ldr	x21, [sp, #32]
    6040:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6044:	d65f03c0 	ret
    6048:	72003c3f 	tst	w1, #0xffff
    604c:	54fffe60 	b.eq	6018 <fwp_drop0+0x78>  // b.none
    6050:	a94153f3 	ldp	x19, x20, [sp, #16]
    6054:	f94013f5 	ldr	x21, [sp, #32]
    6058:	a8c37bfd 	ldp	x29, x30, [sp], #48
    605c:	d65f03c0 	ret
    6060:	f9400813 	ldr	x19, [x0, #16]
    6064:	97fffe9c 	bl	5ad4 <fwp_rc_free_arr>
    6068:	911702a0 	add	x0, x21, #0x5c0
    606c:	f949d801 	ldr	x1, [x0, #5040]
    6070:	f949ec00 	ldr	x0, [x0, #5080]
    6074:	cb010261 	sub	x1, x19, x1
    6078:	eb00403f 	cmp	x1, x0, lsl #16
    607c:	54fffde2 	b.cs	6038 <fwp_drop0+0x98>  // b.hs, b.nlast
    6080:	aa1303e0 	mov	x0, x19
    6084:	17ffffd2 	b	5fcc <fwp_drop0+0x2c>
    6088:	ca534660 	eor	x0, x19, x19, lsr #17
    608c:	911702b5 	add	x21, x21, #0x5c0
    6090:	ca402400 	eor	x0, x0, x0, lsr #9
    6094:	92401c00 	and	x0, x0, #0xff
    6098:	910a2402 	add	x2, x0, #0x289
    609c:	8b000ea0 	add	x0, x21, x0, lsl #3
    60a0:	8b020ea2 	add	x2, x21, x2, lsl #3
    60a4:	f94a2400 	ldr	x0, [x0, #5192]
    60a8:	b50000a0 	cbnz	x0, 60bc <fwp_drop0+0x11c>
    60ac:	14000013 	b	60f8 <fwp_drop0+0x158>
    60b0:	91004002 	add	x2, x0, #0x10
    60b4:	f9400800 	ldr	x0, [x0, #16]
    60b8:	b4000200 	cbz	x0, 60f8 <fwp_drop0+0x158>
    60bc:	f9400001 	ldr	x1, [x0]
    60c0:	eb13003f 	cmp	x1, x19
    60c4:	54ffff61 	b.ne	60b0 <fwp_drop0+0x110>  // b.any
    60c8:	f9400041 	ldr	x1, [x2]
    60cc:	f9400420 	ldr	x0, [x1, #8]
    60d0:	d1000400 	sub	x0, x0, #0x1
    60d4:	f9000420 	str	x0, [x1, #8]
    60d8:	f103f81f 	cmp	x0, #0xfe
    60dc:	54fffae1 	b.ne	6038 <fwp_drop0+0x98>  // b.any
    60e0:	39400260 	ldrb	w0, [x19]
    60e4:	7103fc1f 	cmp	w0, #0xff
    60e8:	540000e0 	b.eq	6104 <fwp_drop0+0x164>  // b.none
    60ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60f0:	39000260 	strb	w0, [x19]
    60f4:	17ffffd1 	b	6038 <fwp_drop0+0x98>
    60f8:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    60fc:	9129e000 	add	x0, x0, #0xa78
    6100:	97fff824 	bl	4190 <fwp_trap>
    6104:	aa1303e0 	mov	x0, x19
    6108:	97fff842 	bl	4210 <fwp_rc_forget_slot.part.0>
    610c:	17fffff8 	b	60ec <fwp_drop0+0x14c>

0000000000006110 <fwp_closure_drop>:
    6110:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc20>
    6114:	911700a4 	add	x4, x5, #0x5c0
    6118:	aa0003e1 	mov	x1, x0
    611c:	f949d882 	ldr	x2, [x4, #5040]
    6120:	f949ec80 	ldr	x0, [x4, #5080]
    6124:	cb020022 	sub	x2, x1, x2
    6128:	eb00405f 	cmp	x2, x0, lsl #16
    612c:	54000662 	b.cs	61f8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6130:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6134:	d350fc43 	lsr	x3, x2, #16
    6138:	910003fd 	mov	x29, sp
    613c:	8b030863 	add	x3, x3, x3, lsl #2
    6140:	f949fc84 	ldr	x4, [x4, #5112]
    6144:	d37df063 	lsl	x3, x3, #3
    6148:	f9000bf3 	str	x19, [sp, #16]
    614c:	8b030080 	add	x0, x4, x3
    6150:	f9401013 	ldr	x19, [x0, #32]
    6154:	b40002b3 	cbz	x19, 61a8 <fwp_closure_drop+0x98>
    6158:	38636883 	ldrb	w3, [x4, x3]
    615c:	7100087f 	cmp	w3, #0x2
    6160:	54000420 	b.eq	61e4 <fwp_closure_drop+0xd4>  // b.none
    6164:	7100047f 	cmp	w3, #0x1
    6168:	54000201 	b.ne	61a8 <fwp_closure_drop+0x98>  // b.any
    616c:	29430003 	ldp	w3, w0, [x0, #24]
    6170:	92403c42 	and	x2, x2, #0xffff
    6174:	9b037c42 	mul	x2, x2, x3
    6178:	d360fc42 	lsr	x2, x2, #32
    617c:	eb00005f 	cmp	x2, x0
    6180:	54000142 	b.cs	61a8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6184:	8b020273 	add	x19, x19, x2
    6188:	39400260 	ldrb	w0, [x19]
    618c:	340000e0 	cbz	w0, 61a8 <fwp_closure_drop+0x98>
    6190:	7100041f 	cmp	w0, #0x1
    6194:	54000100 	b.eq	61b4 <fwp_closure_drop+0xa4>  // b.none
    6198:	7103fc1f 	cmp	w0, #0xff
    619c:	54000300 	b.eq	61fc <fwp_closure_drop+0xec>  // b.none
    61a0:	51000400 	sub	w0, w0, #0x1
    61a4:	39000260 	strb	w0, [x19]
    61a8:	f9400bf3 	ldr	x19, [sp, #16]
    61ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b0:	d65f03c0 	ret
    61b4:	d53bd040 	mrs	x0, tpidr_el0
    61b8:	91400000 	add	x0, x0, #0x0, lsl #12
    61bc:	91004000 	add	x0, x0, #0x10
    61c0:	f9400000 	ldr	x0, [x0]
    61c4:	b4000080 	cbz	x0, 61d4 <fwp_closure_drop+0xc4>
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	17fff96c 	b	4780 <fwp_closure_drop_push>
    61d4:	f9400bf3 	ldr	x19, [sp, #16]
    61d8:	aa0103e0 	mov	x0, x1
    61dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e0:	17fff9ad 	b	4894 <fwp_closure_drop.part.0>
    61e4:	72003c5f 	tst	w2, #0xffff
    61e8:	54fffd00 	b.eq	6188 <fwp_closure_drop+0x78>  // b.none
    61ec:	f9400bf3 	ldr	x19, [sp, #16]
    61f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61f4:	d65f03c0 	ret
    61f8:	d65f03c0 	ret
    61fc:	ca534660 	eor	x0, x19, x19, lsr #17
    6200:	911700a5 	add	x5, x5, #0x5c0
    6204:	ca402400 	eor	x0, x0, x0, lsr #9
    6208:	92401c00 	and	x0, x0, #0xff
    620c:	910a2402 	add	x2, x0, #0x289
    6210:	8b000ca0 	add	x0, x5, x0, lsl #3
    6214:	8b020ca2 	add	x2, x5, x2, lsl #3
    6218:	f94a2400 	ldr	x0, [x0, #5192]
    621c:	b50000a0 	cbnz	x0, 6230 <fwp_closure_drop+0x120>
    6220:	14000013 	b	626c <fwp_closure_drop+0x15c>
    6224:	91004002 	add	x2, x0, #0x10
    6228:	f9400800 	ldr	x0, [x0, #16]
    622c:	b4000200 	cbz	x0, 626c <fwp_closure_drop+0x15c>
    6230:	f9400001 	ldr	x1, [x0]
    6234:	eb13003f 	cmp	x1, x19
    6238:	54ffff61 	b.ne	6224 <fwp_closure_drop+0x114>  // b.any
    623c:	f9400041 	ldr	x1, [x2]
    6240:	f9400420 	ldr	x0, [x1, #8]
    6244:	d1000400 	sub	x0, x0, #0x1
    6248:	f9000420 	str	x0, [x1, #8]
    624c:	f103f81f 	cmp	x0, #0xfe
    6250:	54fffac1 	b.ne	61a8 <fwp_closure_drop+0x98>  // b.any
    6254:	39400260 	ldrb	w0, [x19]
    6258:	7103fc1f 	cmp	w0, #0xff
    625c:	540000e0 	b.eq	6278 <fwp_closure_drop+0x168>  // b.none
    6260:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6264:	39000260 	strb	w0, [x19]
    6268:	17ffffd0 	b	61a8 <fwp_closure_drop+0x98>
    626c:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    6270:	9129e000 	add	x0, x0, #0xa78
    6274:	97fff7c7 	bl	4190 <fwp_trap>
    6278:	aa1303e0 	mov	x0, x19
    627c:	97fff7e5 	bl	4210 <fwp_rc_forget_slot.part.0>
    6280:	17fffff8 	b	6260 <fwp_closure_drop+0x150>

0000000000006284 <fwp_owned_tape_release>:
    6284:	b4000920 	cbz	x0, 63a8 <fwp_owned_tape_release+0x124>
    6288:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    628c:	910003fd 	mov	x29, sp
    6290:	a90153f3 	stp	x19, x20, [sp, #16]
    6294:	aa0003f3 	mov	x19, x0
    6298:	f9400000 	ldr	x0, [x0]
    629c:	b4000060 	cbz	x0, 62a8 <fwp_owned_tape_release+0x24>
    62a0:	f9400661 	ldr	x1, [x19, #8]
    62a4:	f9000401 	str	x1, [x0, #8]
    62a8:	f9400661 	ldr	x1, [x19, #8]
    62ac:	b4000041 	cbz	x1, 62b4 <fwp_owned_tape_release+0x30>
    62b0:	f9000020 	str	x0, [x1]
    62b4:	f9400a60 	ldr	x0, [x19, #16]
    62b8:	f9403401 	ldr	x1, [x0, #104]
    62bc:	b40005a1 	cbz	x1, 6370 <fwp_owned_tape_release+0xec>
    62c0:	a9450a60 	ldp	x0, x2, [x19, #80]
    62c4:	eb00005f 	cmp	x2, x0
    62c8:	540002cd 	b.le	6320 <fwp_owned_tape_release+0x9c>
    62cc:	d2800014 	mov	x20, #0x0                   	// #0
    62d0:	f90013f5 	str	x21, [sp, #32]
    62d4:	d2800015 	mov	x21, #0x0                   	// #0
    62d8:	f9402260 	ldr	x0, [x19, #64]
    62dc:	910006b5 	add	x21, x21, #0x1
    62e0:	f8746800 	ldr	x0, [x0, x20]
    62e4:	d63f0020 	blr	x1
    62e8:	f9402260 	ldr	x0, [x19, #64]
    62ec:	f9400a61 	ldr	x1, [x19, #16]
    62f0:	8b140000 	add	x0, x0, x20
    62f4:	91004294 	add	x20, x20, #0x10
    62f8:	f9400400 	ldr	x0, [x0, #8]
    62fc:	f9403421 	ldr	x1, [x1, #104]
    6300:	d63f0020 	blr	x1
    6304:	a9450261 	ldp	x1, x0, [x19, #80]
    6308:	cb010000 	sub	x0, x0, x1
    630c:	eb15001f 	cmp	x0, x21
    6310:	f9400a60 	ldr	x0, [x19, #16]
    6314:	f9403401 	ldr	x1, [x0, #104]
    6318:	54fffe0c 	b.gt	62d8 <fwp_owned_tape_release+0x54>
    631c:	f94013f5 	ldr	x21, [sp, #32]
    6320:	f9403663 	ldr	x3, [x19, #104]
    6324:	f9401262 	ldr	x2, [x19, #32]
    6328:	f100007f 	cmp	x3, #0x0
    632c:	540001ed 	b.le	6368 <fwp_owned_tape_release+0xe4>
    6330:	d2800014 	mov	x20, #0x0                   	// #0
    6334:	d503201f 	nop
    6338:	f9402660 	ldr	x0, [x19, #72]
    633c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6340:	eb02001f 	cmp	x0, x2
    6344:	540000c0 	b.eq	635c <fwp_owned_tape_release+0xd8>  // b.none
    6348:	d63f0020 	blr	x1
    634c:	f9400a60 	ldr	x0, [x19, #16]
    6350:	f9401262 	ldr	x2, [x19, #32]
    6354:	f9403663 	ldr	x3, [x19, #104]
    6358:	f9403401 	ldr	x1, [x0, #104]
    635c:	91000694 	add	x20, x20, #0x1
    6360:	eb14007f 	cmp	x3, x20
    6364:	54fffeac 	b.gt	6338 <fwp_owned_tape_release+0xb4>
    6368:	aa0203e0 	mov	x0, x2
    636c:	d63f0020 	blr	x1
    6370:	f9401660 	ldr	x0, [x19, #40]
    6374:	97ffff67 	bl	6110 <fwp_closure_drop>
    6378:	f9401a60 	ldr	x0, [x19, #48]
    637c:	97ffff65 	bl	6110 <fwp_closure_drop>
    6380:	f9401e60 	ldr	x0, [x19, #56]
    6384:	97ffff63 	bl	6110 <fwp_closure_drop>
    6388:	f9402260 	ldr	x0, [x19, #64]
    638c:	97fff83d 	bl	4480 <fwp_mem_free>
    6390:	f9402660 	ldr	x0, [x19, #72]
    6394:	97fff83b 	bl	4480 <fwp_mem_free>
    6398:	aa1303e0 	mov	x0, x19
    639c:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63a4:	17fff837 	b	4480 <fwp_mem_free>
    63a8:	d65f03c0 	ret
    63ac:	d503201f 	nop

00000000000063b0 <fwp_tape_finish>:
    63b0:	d10203ff 	sub	sp, sp, #0x80
    63b4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    63b8:	f947f421 	ldr	x1, [x1, #4072]
    63bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    63c0:	910103fd 	add	x29, sp, #0x40
    63c4:	a90553f3 	stp	x19, x20, [sp, #80]
    63c8:	a9065bf5 	stp	x21, x22, [sp, #96]
    63cc:	a90763f7 	stp	x23, x24, [sp, #112]
    63d0:	d00000d8 	adrp	x24, 20000 <__data_start>
    63d4:	91018316 	add	x22, x24, #0x60
    63d8:	f9400022 	ldr	x2, [x1]
    63dc:	f9001fe2 	str	x2, [sp, #56]
    63e0:	d2800002 	mov	x2, #0x0                   	// #0
    63e4:	910222c0 	add	x0, x22, #0x88
    63e8:	97fff446 	bl	3500 <fwp_tape_buffers_dispose>
    63ec:	f90062df 	str	xzr, [x22, #192]
    63f0:	f9406ac0 	ldr	x0, [x22, #208]
    63f4:	f100001f 	cmp	x0, #0x0
    63f8:	5400030d 	b.le	6458 <fwp_tape_finish+0xa8>
    63fc:	910003f7 	mov	x23, sp
    6400:	d2800015 	mov	x21, #0x0                   	// #0
    6404:	d2800014 	mov	x20, #0x0                   	// #0
    6408:	f94002d3 	ldr	x19, [x22]
    640c:	91000694 	add	x20, x20, #0x1
    6410:	8b150273 	add	x19, x19, x21
    6414:	9101a2b5 	add	x21, x21, #0x68
    6418:	aa1303e0 	mov	x0, x19
    641c:	97fff2fd 	bl	3010 <fwp_tape_unlink_scope>
    6420:	aa1703e0 	mov	x0, x23
    6424:	f9401261 	ldr	x1, [x19, #32]
    6428:	f90003e1 	str	x1, [sp]
    642c:	f9401a62 	ldr	x2, [x19, #48]
    6430:	f9000be2 	str	x2, [sp, #16]
    6434:	f9402261 	ldr	x1, [x19, #64]
    6438:	f90013e1 	str	x1, [sp, #32]
    643c:	97fff431 	bl	3500 <fwp_tape_buffers_dispose>
    6440:	f9403260 	ldr	x0, [x19, #96]
    6444:	97ffff90 	bl	6284 <fwp_owned_tape_release>
    6448:	f900327f 	str	xzr, [x19, #96]
    644c:	f9406ac0 	ldr	x0, [x22, #208]
    6450:	eb14001f 	cmp	x0, x20
    6454:	54fffdac 	b.gt	6408 <fwp_tape_finish+0x58>
    6458:	f9403300 	ldr	x0, [x24, #96]
    645c:	91018313 	add	x19, x24, #0x60
    6460:	97fff15c 	bl	29d0 <free@plt>
    6464:	f900331f 	str	xzr, [x24, #96]
    6468:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    646c:	f947f400 	ldr	x0, [x0, #4072]
    6470:	f9006a7f 	str	xzr, [x19, #208]
    6474:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6478:	f9401fe2 	ldr	x2, [sp, #56]
    647c:	f9400001 	ldr	x1, [x0]
    6480:	eb010042 	subs	x2, x2, x1
    6484:	d2800001 	mov	x1, #0x0                   	// #0
    6488:	540000e1 	b.ne	64a4 <fwp_tape_finish+0xf4>  // b.any
    648c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6490:	a94553f3 	ldp	x19, x20, [sp, #80]
    6494:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6498:	a94763f7 	ldp	x23, x24, [sp, #112]
    649c:	910203ff 	add	sp, sp, #0x80
    64a0:	d65f03c0 	ret
    64a4:	97fff11b 	bl	2910 <__stack_chk_fail@plt>
    64a8:	d503201f 	nop
    64ac:	d503201f 	nop

00000000000064b0 <fwp_tape_scope_release>:
    64b0:	d10243ff 	sub	sp, sp, #0x90
    64b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    64b8:	910103fd 	add	x29, sp, #0x40
    64bc:	a90553f3 	stp	x19, x20, [sp, #80]
    64c0:	aa0003f4 	mov	x20, x0
    64c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    64c8:	f947f400 	ldr	x0, [x0, #4072]
    64cc:	b9400285 	ldr	w5, [x20]
    64d0:	f9400001 	ldr	x1, [x0]
    64d4:	f9001fe1 	str	x1, [sp, #56]
    64d8:	d2800001 	mov	x1, #0x0                   	// #0
    64dc:	37f806c5 	tbnz	w5, #31, 65b4 <fwp_tape_scope_release+0x104>
    64e0:	a90763f7 	stp	x23, x24, [sp, #112]
    64e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    64e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    64ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    64f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64f4:	910003f7 	mov	x23, sp
    64f8:	91018273 	add	x19, x19, #0x60
    64fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6500:	a9065bf5 	stp	x21, x22, [sp, #96]
    6504:	52800d16 	mov	w22, #0x68                  	// #104
    6508:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    650c:	f90043f9 	str	x25, [sp, #128]
    6510:	14000006 	b	6528 <fwp_tape_scope_release+0x78>
    6514:	97fff3fb 	bl	3500 <fwp_tape_buffers_dispose>
    6518:	aa1903e0 	mov	x0, x25
    651c:	97ffff5a 	bl	6284 <fwp_owned_tape_release>
    6520:	b9400285 	ldr	w5, [x20]
    6524:	37f80425 	tbnz	w5, #31, 65a8 <fwp_tape_scope_release+0xf8>
    6528:	f9400266 	ldr	x6, [x19]
    652c:	9b367ca5 	smull	x5, w5, w22
    6530:	8b0500c0 	add	x0, x6, x5
    6534:	97fff2b7 	bl	3010 <fwp_tape_unlink_scope>
    6538:	ad410001 	ldp	q1, q0, [x0, #32]
    653c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6540:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6544:	f9400c03 	ldr	x3, [x0, #24]
    6548:	ad0003e1 	stp	q1, q0, [sp]
    654c:	b86568c1 	ldr	w1, [x6, x5]
    6550:	a9440804 	ldp	x4, x2, [x0, #64]
    6554:	b900041f 	str	wzr, [x0, #4]
    6558:	f9403019 	ldr	x25, [x0, #96]
    655c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6560:	f9000c1f 	str	xzr, [x0, #24]
    6564:	a9020fe4 	stp	x4, x3, [sp, #32]
    6568:	f9001be2 	str	x2, [sp, #48]
    656c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6570:	f900301f 	str	xzr, [x0, #96]
    6574:	6b15003f 	cmp	w1, w21
    6578:	540000e8 	b.hi	6594 <fwp_tape_scope_release+0xe4>  // b.pmore
    657c:	9343fca5 	asr	x5, x5, #3
    6580:	f9407660 	ldr	x0, [x19, #232]
    6584:	9b187ca5 	mul	x5, x5, x24
    6588:	eb0000bf 	cmp	x5, x0
    658c:	5400004a 	b.ge	6594 <fwp_tape_scope_release+0xe4>  // b.tcont
    6590:	f9007665 	str	x5, [x19, #232]
    6594:	aa1703e0 	mov	x0, x23
    6598:	b5fffbf9 	cbnz	x25, 6514 <fwp_tape_scope_release+0x64>
    659c:	97fff6b5 	bl	4070 <fwp_tape_buffers_release>
    65a0:	b9400285 	ldr	w5, [x20]
    65a4:	36fffc25 	tbz	w5, #31, 6528 <fwp_tape_scope_release+0x78>
    65a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    65ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    65b0:	f94043f9 	ldr	x25, [sp, #128]
    65b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    65b8:	f947f400 	ldr	x0, [x0, #4072]
    65bc:	f9401fe2 	ldr	x2, [sp, #56]
    65c0:	f9400001 	ldr	x1, [x0]
    65c4:	eb010042 	subs	x2, x2, x1
    65c8:	d2800001 	mov	x1, #0x0                   	// #0
    65cc:	540000a1 	b.ne	65e0 <fwp_tape_scope_release+0x130>  // b.any
    65d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    65d8:	910243ff 	add	sp, sp, #0x90
    65dc:	d65f03c0 	ret
    65e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65e4:	a90763f7 	stp	x23, x24, [sp, #112]
    65e8:	f90043f9 	str	x25, [sp, #128]
    65ec:	97fff0c9 	bl	2910 <__stack_chk_fail@plt>

00000000000065f0 <fwp_drop4>:
    65f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65f4:	910003fd 	mov	x29, sp
    65f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    65fc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    6600:	911702d5 	add	x21, x22, #0x5c0
    6604:	a90153f3 	stp	x19, x20, [sp, #16]
    6608:	aa0003f3 	mov	x19, x0
    660c:	f949daa1 	ldr	x1, [x21, #5040]
    6610:	f949eea0 	ldr	x0, [x21, #5080]
    6614:	cb010261 	sub	x1, x19, x1
    6618:	eb00403f 	cmp	x1, x0, lsl #16
    661c:	54000382 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6620:	d350fc22 	lsr	x2, x1, #16
    6624:	f949fea3 	ldr	x3, [x21, #5112]
    6628:	8b020842 	add	x2, x2, x2, lsl #2
    662c:	d37df042 	lsl	x2, x2, #3
    6630:	8b020060 	add	x0, x3, x2
    6634:	f9401014 	ldr	x20, [x0, #32]
    6638:	b40002b4 	cbz	x20, 668c <fwp_drop4+0x9c>
    663c:	38626862 	ldrb	w2, [x3, x2]
    6640:	7100085f 	cmp	w2, #0x2
    6644:	540002c0 	b.eq	669c <fwp_drop4+0xac>  // b.none
    6648:	7100045f 	cmp	w2, #0x1
    664c:	54000201 	b.ne	668c <fwp_drop4+0x9c>  // b.any
    6650:	29430002 	ldp	w2, w0, [x0, #24]
    6654:	92403c21 	and	x1, x1, #0xffff
    6658:	9b027c21 	mul	x1, x1, x2
    665c:	d360fc21 	lsr	x1, x1, #32
    6660:	eb00003f 	cmp	x1, x0
    6664:	54000142 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6668:	8b010294 	add	x20, x20, x1
    666c:	39400280 	ldrb	w0, [x20]
    6670:	340000e0 	cbz	w0, 668c <fwp_drop4+0x9c>
    6674:	7100041f 	cmp	w0, #0x1
    6678:	540001e0 	b.eq	66b4 <fwp_drop4+0xc4>  // b.none
    667c:	7103fc1f 	cmp	w0, #0xff
    6680:	540007c0 	b.eq	6778 <fwp_drop4+0x188>  // b.none
    6684:	51000400 	sub	w0, w0, #0x1
    6688:	39000280 	strb	w0, [x20]
    668c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6690:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6694:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6698:	d65f03c0 	ret
    669c:	72003c3f 	tst	w1, #0xffff
    66a0:	54fffe60 	b.eq	666c <fwp_drop4+0x7c>  // b.none
    66a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66b0:	d65f03c0 	ret
    66b4:	911702c2 	add	x2, x22, #0x5c0
    66b8:	f9400660 	ldr	x0, [x19, #8]
    66bc:	f949d841 	ldr	x1, [x2, #5040]
    66c0:	f949ec42 	ldr	x2, [x2, #5080]
    66c4:	cb010001 	sub	x1, x0, x1
    66c8:	eb02403f 	cmp	x1, x2, lsl #16
    66cc:	54000362 	b.cs	6738 <fwp_drop4+0x148>  // b.hs, b.nlast
    66d0:	d350fc22 	lsr	x2, x1, #16
    66d4:	8b020842 	add	x2, x2, x2, lsl #2
    66d8:	d37df042 	lsl	x2, x2, #3
    66dc:	8b020064 	add	x4, x3, x2
    66e0:	f9401094 	ldr	x20, [x4, #32]
    66e4:	b40002b4 	cbz	x20, 6738 <fwp_drop4+0x148>
    66e8:	38626862 	ldrb	w2, [x3, x2]
    66ec:	7100085f 	cmp	w2, #0x2
    66f0:	540003e0 	b.eq	676c <fwp_drop4+0x17c>  // b.none
    66f4:	7100045f 	cmp	w2, #0x1
    66f8:	54000201 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    66fc:	29430883 	ldp	w3, w2, [x4, #24]
    6700:	92403c21 	and	x1, x1, #0xffff
    6704:	9b037c21 	mul	x1, x1, x3
    6708:	d360fc21 	lsr	x1, x1, #32
    670c:	eb02003f 	cmp	x1, x2
    6710:	54000142 	b.cs	6738 <fwp_drop4+0x148>  // b.hs, b.nlast
    6714:	8b010294 	add	x20, x20, x1
    6718:	39400281 	ldrb	w1, [x20]
    671c:	340000e1 	cbz	w1, 6738 <fwp_drop4+0x148>
    6720:	7100043f 	cmp	w1, #0x1
    6724:	54000200 	b.eq	6764 <fwp_drop4+0x174>  // b.none
    6728:	7103fc3f 	cmp	w1, #0xff
    672c:	54000640 	b.eq	67f4 <fwp_drop4+0x204>  // b.none
    6730:	51000421 	sub	w1, w1, #0x1
    6734:	39000281 	strb	w1, [x20]
    6738:	f9400a74 	ldr	x20, [x19, #16]
    673c:	aa1303e0 	mov	x0, x19
    6740:	97fffce5 	bl	5ad4 <fwp_rc_free_arr>
    6744:	911702c0 	add	x0, x22, #0x5c0
    6748:	f949d801 	ldr	x1, [x0, #5040]
    674c:	f949ec00 	ldr	x0, [x0, #5080]
    6750:	cb010281 	sub	x1, x20, x1
    6754:	eb00403f 	cmp	x1, x0, lsl #16
    6758:	54fff9a2 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    675c:	aa1403f3 	mov	x19, x20
    6760:	17ffffb0 	b	6620 <fwp_drop4+0x30>
    6764:	97fffcdc 	bl	5ad4 <fwp_rc_free_arr>
    6768:	17fffff4 	b	6738 <fwp_drop4+0x148>
    676c:	72003c3f 	tst	w1, #0xffff
    6770:	54fffe41 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    6774:	17ffffe9 	b	6718 <fwp_drop4+0x128>
    6778:	ca544681 	eor	x1, x20, x20, lsr #17
    677c:	911702c0 	add	x0, x22, #0x5c0
    6780:	ca412421 	eor	x1, x1, x1, lsr #9
    6784:	92401c21 	and	x1, x1, #0xff
    6788:	910a2422 	add	x2, x1, #0x289
    678c:	8b010c01 	add	x1, x0, x1, lsl #3
    6790:	8b020c02 	add	x2, x0, x2, lsl #3
    6794:	f94a2420 	ldr	x0, [x1, #5192]
    6798:	b50000a0 	cbnz	x0, 67ac <fwp_drop4+0x1bc>
    679c:	14000013 	b	67e8 <fwp_drop4+0x1f8>
    67a0:	91004002 	add	x2, x0, #0x10
    67a4:	f9400800 	ldr	x0, [x0, #16]
    67a8:	b4000200 	cbz	x0, 67e8 <fwp_drop4+0x1f8>
    67ac:	f9400001 	ldr	x1, [x0]
    67b0:	eb14003f 	cmp	x1, x20
    67b4:	54ffff61 	b.ne	67a0 <fwp_drop4+0x1b0>  // b.any
    67b8:	f9400041 	ldr	x1, [x2]
    67bc:	f9400420 	ldr	x0, [x1, #8]
    67c0:	d1000400 	sub	x0, x0, #0x1
    67c4:	f9000420 	str	x0, [x1, #8]
    67c8:	f103f81f 	cmp	x0, #0xfe
    67cc:	54fff601 	b.ne	668c <fwp_drop4+0x9c>  // b.any
    67d0:	39400280 	ldrb	w0, [x20]
    67d4:	7103fc1f 	cmp	w0, #0xff
    67d8:	54000460 	b.eq	6864 <fwp_drop4+0x274>  // b.none
    67dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67e0:	39000280 	strb	w0, [x20]
    67e4:	17ffffaa 	b	668c <fwp_drop4+0x9c>
    67e8:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    67ec:	9129e000 	add	x0, x0, #0xa78
    67f0:	97fff668 	bl	4190 <fwp_trap>
    67f4:	ca544680 	eor	x0, x20, x20, lsr #17
    67f8:	911702c1 	add	x1, x22, #0x5c0
    67fc:	ca402400 	eor	x0, x0, x0, lsr #9
    6800:	92401c00 	and	x0, x0, #0xff
    6804:	910a2402 	add	x2, x0, #0x289
    6808:	8b000c20 	add	x0, x1, x0, lsl #3
    680c:	8b020c22 	add	x2, x1, x2, lsl #3
    6810:	f94a2400 	ldr	x0, [x0, #5192]
    6814:	b50000a0 	cbnz	x0, 6828 <fwp_drop4+0x238>
    6818:	17fffff4 	b	67e8 <fwp_drop4+0x1f8>
    681c:	91004002 	add	x2, x0, #0x10
    6820:	f9400800 	ldr	x0, [x0, #16]
    6824:	b4fffe20 	cbz	x0, 67e8 <fwp_drop4+0x1f8>
    6828:	f9400001 	ldr	x1, [x0]
    682c:	eb14003f 	cmp	x1, x20
    6830:	54ffff61 	b.ne	681c <fwp_drop4+0x22c>  // b.any
    6834:	f9400041 	ldr	x1, [x2]
    6838:	f9400420 	ldr	x0, [x1, #8]
    683c:	d1000400 	sub	x0, x0, #0x1
    6840:	f9000420 	str	x0, [x1, #8]
    6844:	f103f81f 	cmp	x0, #0xfe
    6848:	54fff781 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    684c:	39400280 	ldrb	w0, [x20]
    6850:	7103fc1f 	cmp	w0, #0xff
    6854:	540000e0 	b.eq	6870 <fwp_drop4+0x280>  // b.none
    6858:	12800020 	mov	w0, #0xfffffffe            	// #-2
    685c:	39000280 	strb	w0, [x20]
    6860:	17ffffb6 	b	6738 <fwp_drop4+0x148>
    6864:	aa1403e0 	mov	x0, x20
    6868:	97fff66a 	bl	4210 <fwp_rc_forget_slot.part.0>
    686c:	17ffffdc 	b	67dc <fwp_drop4+0x1ec>
    6870:	aa1403e0 	mov	x0, x20
    6874:	97fff667 	bl	4210 <fwp_rc_forget_slot.part.0>
    6878:	17fffff8 	b	6858 <fwp_drop4+0x268>
    687c:	d503201f 	nop

0000000000006880 <fwp_arg_drop37>:
    6880:	7100003f 	cmp	w1, #0x0
    6884:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6888:	54000041 	b.ne	6890 <fwp_arg_drop37+0x10>  // b.any
    688c:	d65f03c0 	ret
    6890:	f9400000 	ldr	x0, [x0]
    6894:	17ffff57 	b	65f0 <fwp_drop4>
    6898:	d503201f 	nop
    689c:	d503201f 	nop

00000000000068a0 <fwp_task_dispose>:
    68a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68a4:	910003fd 	mov	x29, sp
    68a8:	f9000bf3 	str	x19, [sp, #16]
    68ac:	aa0003f3 	mov	x19, x0
    68b0:	39414000 	ldrb	w0, [x0, #80]
    68b4:	36000720 	tbz	w0, #0, 6998 <fwp_task_dispose+0xf8>
    68b8:	f9400a60 	ldr	x0, [x19, #16]
    68bc:	b50006e0 	cbnz	x0, 6998 <fwp_task_dispose+0xf8>
    68c0:	a9478660 	ldp	x0, x1, [x19, #120]
    68c4:	39014e7f 	strb	wzr, [x19, #83]
    68c8:	f9003e7f 	str	xzr, [x19, #120]
    68cc:	f100003f 	cmp	x1, #0x0
    68d0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    68d4:	54000040 	b.eq	68dc <fwp_task_dispose+0x3c>  // b.none
    68d8:	d63f0020 	blr	x1
    68dc:	f9405660 	ldr	x0, [x19, #168]
    68e0:	97fff6e8 	bl	4480 <fwp_mem_free>
    68e4:	f900567f 	str	xzr, [x19, #168]
    68e8:	b9405e60 	ldr	w0, [x19, #92]
    68ec:	7100041f 	cmp	w0, #0x1
    68f0:	54000420 	b.eq	6974 <fwp_task_dispose+0xd4>  // b.none
    68f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    68f8:	91170042 	add	x2, x2, #0x5c0
    68fc:	f949d840 	ldr	x0, [x2, #5040]
    6900:	f949ec41 	ldr	x1, [x2, #5080]
    6904:	cb000260 	sub	x0, x19, x0
    6908:	eb01401f 	cmp	x0, x1, lsl #16
    690c:	540002e2 	b.cs	6968 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6910:	d350fc01 	lsr	x1, x0, #16
    6914:	f949fc44 	ldr	x4, [x2, #5112]
    6918:	8b010821 	add	x1, x1, x1, lsl #2
    691c:	d37df021 	lsl	x1, x1, #3
    6920:	8b010083 	add	x3, x4, x1
    6924:	f9401062 	ldr	x2, [x3, #32]
    6928:	b4000202 	cbz	x2, 6968 <fwp_task_dispose+0xc8>
    692c:	38616881 	ldrb	w1, [x4, x1]
    6930:	7100083f 	cmp	w1, #0x2
    6934:	54000280 	b.eq	6984 <fwp_task_dispose+0xe4>  // b.none
    6938:	7100043f 	cmp	w1, #0x1
    693c:	54000161 	b.ne	6968 <fwp_task_dispose+0xc8>  // b.any
    6940:	29430464 	ldp	w4, w1, [x3, #24]
    6944:	92403c00 	and	x0, x0, #0xffff
    6948:	9b047c00 	mul	x0, x0, x4
    694c:	d360fc00 	lsr	x0, x0, #32
    6950:	eb01001f 	cmp	x0, x1
    6954:	540000a2 	b.cs	6968 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6958:	8b000042 	add	x2, x2, x0
    695c:	39400040 	ldrb	w0, [x2]
    6960:	7100041f 	cmp	w0, #0x1
    6964:	54000080 	b.eq	6974 <fwp_task_dispose+0xd4>  // b.none
    6968:	f9400bf3 	ldr	x19, [sp, #16]
    696c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6970:	d65f03c0 	ret
    6974:	aa1303e0 	mov	x0, x19
    6978:	f9400bf3 	ldr	x19, [sp, #16]
    697c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6980:	17fff6c0 	b	4480 <fwp_mem_free>
    6984:	72003c1f 	tst	w0, #0xffff
    6988:	54fffea0 	b.eq	695c <fwp_task_dispose+0xbc>  // b.none
    698c:	f9400bf3 	ldr	x19, [sp, #16]
    6990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6994:	d65f03c0 	ret
    6998:	97ffeff2 	bl	2960 <abort@plt>
    699c:	d503201f 	nop

00000000000069a0 <fwp_free_zombie>:
    69a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69a4:	910003fd 	mov	x29, sp
    69a8:	a90153f3 	stp	x19, x20, [sp, #16]
    69ac:	d00000d4 	adrp	x20, 20000 <__data_start>
    69b0:	91018281 	add	x1, x20, #0x60
    69b4:	f9407833 	ldr	x19, [x1, #240]
    69b8:	b4000333 	cbz	x19, 6a1c <fwp_free_zombie+0x7c>
    69bc:	f9400820 	ldr	x0, [x1, #16]
    69c0:	eb00027f 	cmp	x19, x0
    69c4:	540002c0 	b.eq	6a1c <fwp_free_zombie+0x7c>  // b.none
    69c8:	b940f822 	ldr	w2, [x1, #248]
    69cc:	f9400a60 	ldr	x0, [x19, #16]
    69d0:	7100fc5f 	cmp	w2, #0x3f
    69d4:	5400078c 	b.gt	6ac4 <fwp_free_zombie+0x124>
    69d8:	91040023 	add	x3, x1, #0x100
    69dc:	11000444 	add	w4, w2, #0x1
    69e0:	b900f824 	str	w4, [x1, #248]
    69e4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69e8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    69ec:	a9530261 	ldp	x1, x0, [x19, #304]
    69f0:	b4000741 	cbz	x1, 6ad8 <fwp_free_zombie+0x138>
    69f4:	f9009c20 	str	x0, [x1, #312]
    69f8:	b4000040 	cbz	x0, 6a00 <fwp_free_zombie+0x60>
    69fc:	f9009801 	str	x1, [x0, #304]
    6a00:	91018294 	add	x20, x20, #0x60
    6a04:	b9405e60 	ldr	w0, [x19, #92]
    6a08:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6a0c:	f9007a9f 	str	xzr, [x20, #240]
    6a10:	34000140 	cbz	w0, 6a38 <fwp_free_zombie+0x98>
    6a14:	7100041f 	cmp	w0, #0x1
    6a18:	54000080 	b.eq	6a28 <fwp_free_zombie+0x88>  // b.none
    6a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a24:	d65f03c0 	ret
    6a28:	aa1303e0 	mov	x0, x19
    6a2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a34:	17ffff9b 	b	68a0 <fwp_task_dispose>
    6a38:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc20>
    6a3c:	91170082 	add	x2, x4, #0x5c0
    6a40:	f949d841 	ldr	x1, [x2, #5040]
    6a44:	f949ec40 	ldr	x0, [x2, #5080]
    6a48:	cb010261 	sub	x1, x19, x1
    6a4c:	eb00403f 	cmp	x1, x0, lsl #16
    6a50:	54fffe62 	b.cs	6a1c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a54:	d350fc20 	lsr	x0, x1, #16
    6a58:	f949fc43 	ldr	x3, [x2, #5112]
    6a5c:	8b000800 	add	x0, x0, x0, lsl #2
    6a60:	d37df000 	lsl	x0, x0, #3
    6a64:	8b000062 	add	x2, x3, x0
    6a68:	f9401054 	ldr	x20, [x2, #32]
    6a6c:	b4fffd94 	cbz	x20, 6a1c <fwp_free_zombie+0x7c>
    6a70:	38606860 	ldrb	w0, [x3, x0]
    6a74:	7100081f 	cmp	w0, #0x2
    6a78:	54000360 	b.eq	6ae4 <fwp_free_zombie+0x144>  // b.none
    6a7c:	7100041f 	cmp	w0, #0x1
    6a80:	54fffce1 	b.ne	6a1c <fwp_free_zombie+0x7c>  // b.any
    6a84:	29430043 	ldp	w3, w0, [x2, #24]
    6a88:	92403c21 	and	x1, x1, #0xffff
    6a8c:	9b037c21 	mul	x1, x1, x3
    6a90:	d360fc21 	lsr	x1, x1, #32
    6a94:	eb00003f 	cmp	x1, x0
    6a98:	54fffc22 	b.cs	6a1c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a9c:	8b010294 	add	x20, x20, x1
    6aa0:	39400280 	ldrb	w0, [x20]
    6aa4:	34fffbc0 	cbz	w0, 6a1c <fwp_free_zombie+0x7c>
    6aa8:	7100041f 	cmp	w0, #0x1
    6aac:	54fffbe0 	b.eq	6a28 <fwp_free_zombie+0x88>  // b.none
    6ab0:	7103fc1f 	cmp	w0, #0xff
    6ab4:	540001e0 	b.eq	6af0 <fwp_free_zombie+0x150>  // b.none
    6ab8:	51000400 	sub	w0, w0, #0x1
    6abc:	39000280 	strb	w0, [x20]
    6ac0:	17ffffd7 	b	6a1c <fwp_free_zombie+0x7c>
    6ac4:	f9400e61 	ldr	x1, [x19, #24]
    6ac8:	97ffefda 	bl	2a30 <munmap@plt>
    6acc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ad0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ad4:	b5fff901 	cbnz	x1, 69f4 <fwp_free_zombie+0x54>
    6ad8:	91018282 	add	x2, x20, #0x60
    6adc:	f9018040 	str	x0, [x2, #768]
    6ae0:	17ffffc6 	b	69f8 <fwp_free_zombie+0x58>
    6ae4:	72003c3f 	tst	w1, #0xffff
    6ae8:	54fff9a1 	b.ne	6a1c <fwp_free_zombie+0x7c>  // b.any
    6aec:	17ffffed 	b	6aa0 <fwp_free_zombie+0x100>
    6af0:	ca544680 	eor	x0, x20, x20, lsr #17
    6af4:	91170084 	add	x4, x4, #0x5c0
    6af8:	ca402400 	eor	x0, x0, x0, lsr #9
    6afc:	92401c00 	and	x0, x0, #0xff
    6b00:	910a2402 	add	x2, x0, #0x289
    6b04:	8b000c80 	add	x0, x4, x0, lsl #3
    6b08:	8b020c82 	add	x2, x4, x2, lsl #3
    6b0c:	f94a2400 	ldr	x0, [x0, #5192]
    6b10:	b50000a0 	cbnz	x0, 6b24 <fwp_free_zombie+0x184>
    6b14:	14000013 	b	6b60 <fwp_free_zombie+0x1c0>
    6b18:	91004002 	add	x2, x0, #0x10
    6b1c:	f9400800 	ldr	x0, [x0, #16]
    6b20:	b4000200 	cbz	x0, 6b60 <fwp_free_zombie+0x1c0>
    6b24:	f9400001 	ldr	x1, [x0]
    6b28:	eb14003f 	cmp	x1, x20
    6b2c:	54ffff61 	b.ne	6b18 <fwp_free_zombie+0x178>  // b.any
    6b30:	f9400041 	ldr	x1, [x2]
    6b34:	f9400420 	ldr	x0, [x1, #8]
    6b38:	d1000400 	sub	x0, x0, #0x1
    6b3c:	f9000420 	str	x0, [x1, #8]
    6b40:	f103f81f 	cmp	x0, #0xfe
    6b44:	54fff6c1 	b.ne	6a1c <fwp_free_zombie+0x7c>  // b.any
    6b48:	39400280 	ldrb	w0, [x20]
    6b4c:	7103fc1f 	cmp	w0, #0xff
    6b50:	540000e0 	b.eq	6b6c <fwp_free_zombie+0x1cc>  // b.none
    6b54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b58:	39000280 	strb	w0, [x20]
    6b5c:	17ffffb0 	b	6a1c <fwp_free_zombie+0x7c>
    6b60:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    6b64:	9129e000 	add	x0, x0, #0xa78
    6b68:	97fff58a 	bl	4190 <fwp_trap>
    6b6c:	aa1403e0 	mov	x0, x20
    6b70:	97fff5a8 	bl	4210 <fwp_rc_forget_slot.part.0>
    6b74:	17fffff8 	b	6b54 <fwp_free_zombie+0x1b4>
    6b78:	d503201f 	nop
    6b7c:	d503201f 	nop

0000000000006b80 <fwp_block>:
    6b80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b84:	910003fd 	mov	x29, sp
    6b88:	a90153f3 	stp	x19, x20, [sp, #16]
    6b8c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6b90:	91018274 	add	x20, x19, #0x60
    6b94:	f9404282 	ldr	x2, [x20, #128]
    6b98:	b4000642 	cbz	x2, 6c60 <fwp_block+0xe0>
    6b9c:	91018261 	add	x1, x19, #0x60
    6ba0:	f9408040 	ldr	x0, [x2, #256]
    6ba4:	f9004020 	str	x0, [x1, #128]
    6ba8:	b40006a0 	cbz	x0, 6c7c <fwp_block+0xfc>
    6bac:	d503201f 	nop
    6bb0:	91018263 	add	x3, x19, #0x60
    6bb4:	3901505f 	strb	wzr, [x2, #84]
    6bb8:	f9400864 	ldr	x4, [x3, #16]
    6bbc:	eb02009f 	cmp	x4, x2
    6bc0:	54000440 	b.eq	6c48 <fwp_block+0xc8>  // b.none
    6bc4:	f9418465 	ldr	x5, [x3, #776]
    6bc8:	f9000862 	str	x2, [x3, #16]
    6bcc:	f9400441 	ldr	x1, [x2, #8]
    6bd0:	f9004885 	str	x5, [x4, #144]
    6bd4:	f9418865 	ldr	x5, [x3, #784]
    6bd8:	f9004c85 	str	x5, [x4, #152]
    6bdc:	f9418c65 	ldr	x5, [x3, #792]
    6be0:	f9005085 	str	x5, [x4, #160]
    6be4:	f9419065 	ldr	x5, [x3, #800]
    6be8:	f9005485 	str	x5, [x4, #168]
    6bec:	f9419465 	ldr	x5, [x3, #808]
    6bf0:	f9005885 	str	x5, [x4, #176]
    6bf4:	f9419865 	ldr	x5, [x3, #816]
    6bf8:	f9005c85 	str	x5, [x4, #184]
    6bfc:	f9419c65 	ldr	x5, [x3, #824]
    6c00:	f9006085 	str	x5, [x4, #192]
    6c04:	f9400480 	ldr	x0, [x4, #8]
    6c08:	f9404844 	ldr	x4, [x2, #144]
    6c0c:	f9018464 	str	x4, [x3, #776]
    6c10:	f9404c44 	ldr	x4, [x2, #152]
    6c14:	f9018864 	str	x4, [x3, #784]
    6c18:	f9405044 	ldr	x4, [x2, #160]
    6c1c:	f9018c64 	str	x4, [x3, #792]
    6c20:	f9405444 	ldr	x4, [x2, #168]
    6c24:	f9019064 	str	x4, [x3, #800]
    6c28:	f9405844 	ldr	x4, [x2, #176]
    6c2c:	f9019464 	str	x4, [x3, #808]
    6c30:	a94b8844 	ldp	x4, x2, [x2, #184]
    6c34:	f9019864 	str	x4, [x3, #816]
    6c38:	f9019c62 	str	x2, [x3, #824]
    6c3c:	97ffef4d 	bl	2970 <swapcontext@plt>
    6c40:	97ffff58 	bl	69a0 <fwp_free_zombie>
    6c44:	d503201f 	nop
    6c48:	91018260 	add	x0, x19, #0x60
    6c4c:	b9434000 	ldr	w0, [x0, #832]
    6c50:	340001a0 	cbz	w0, 6c84 <fwp_block+0x104>
    6c54:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c58:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c5c:	d65f03c0 	ret
    6c60:	97fff794 	bl	4ab0 <fwp_poll_events>
    6c64:	f9404282 	ldr	x2, [x20, #128]
    6c68:	b4ffffc2 	cbz	x2, 6c60 <fwp_block+0xe0>
    6c6c:	91018261 	add	x1, x19, #0x60
    6c70:	f9408040 	ldr	x0, [x2, #256]
    6c74:	f9004020 	str	x0, [x1, #128]
    6c78:	b5fff9c0 	cbnz	x0, 6bb0 <fwp_block+0x30>
    6c7c:	f9003c3f 	str	xzr, [x1, #120]
    6c80:	17ffffcc 	b	6bb0 <fwp_block+0x30>
    6c84:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    6c88:	91344000 	add	x0, x0, #0xd10
    6c8c:	97ffef85 	bl	2aa0 <getenv@plt>
    6c90:	5284e202 	mov	w2, #0x2710                	// #10000
    6c94:	b4000060 	cbz	x0, 6ca0 <fwp_block+0x120>
    6c98:	39400001 	ldrb	w1, [x0]
    6c9c:	350000c1 	cbnz	w1, 6cb4 <fwp_block+0x134>
    6ca0:	91018273 	add	x19, x19, #0x60
    6ca4:	b9034262 	str	w2, [x19, #832]
    6ca8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cb0:	d65f03c0 	ret
    6cb4:	52800142 	mov	w2, #0xa                   	// #10
    6cb8:	d2800001 	mov	x1, #0x0                   	// #0
    6cbc:	97ffeec9 	bl	27e0 <strtoll@plt>
    6cc0:	d1000403 	sub	x3, x0, #0x1
    6cc4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6cc8:	eb02007f 	cmp	x3, x2
    6ccc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6cd0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6cd4:	17fffff3 	b	6ca0 <fwp_block+0x120>
    6cd8:	d503201f 	nop
    6cdc:	d503201f 	nop

0000000000006ce0 <fwp_drop10>:
    6ce0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6ce4:	910003fd 	mov	x29, sp
    6ce8:	a90153f3 	stp	x19, x20, [sp, #16]
    6cec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    6cf0:	f90013f5 	str	x21, [sp, #32]
    6cf4:	91170275 	add	x21, x19, #0x5c0
    6cf8:	f949daa1 	ldr	x1, [x21, #5040]
    6cfc:	f949eea2 	ldr	x2, [x21, #5080]
    6d00:	cb010001 	sub	x1, x0, x1
    6d04:	eb02403f 	cmp	x1, x2, lsl #16
    6d08:	54000382 	b.cs	6d78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d0c:	d350fc22 	lsr	x2, x1, #16
    6d10:	f949fea3 	ldr	x3, [x21, #5112]
    6d14:	8b020842 	add	x2, x2, x2, lsl #2
    6d18:	d37df042 	lsl	x2, x2, #3
    6d1c:	8b020064 	add	x4, x3, x2
    6d20:	f9401094 	ldr	x20, [x4, #32]
    6d24:	b40002b4 	cbz	x20, 6d78 <fwp_drop10+0x98>
    6d28:	38626862 	ldrb	w2, [x3, x2]
    6d2c:	7100085f 	cmp	w2, #0x2
    6d30:	540007a0 	b.eq	6e24 <fwp_drop10+0x144>  // b.none
    6d34:	7100045f 	cmp	w2, #0x1
    6d38:	54000201 	b.ne	6d78 <fwp_drop10+0x98>  // b.any
    6d3c:	29430885 	ldp	w5, w2, [x4, #24]
    6d40:	92403c21 	and	x1, x1, #0xffff
    6d44:	9b057c21 	mul	x1, x1, x5
    6d48:	d360fc21 	lsr	x1, x1, #32
    6d4c:	eb02003f 	cmp	x1, x2
    6d50:	54000142 	b.cs	6d78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d54:	8b010294 	add	x20, x20, x1
    6d58:	39400281 	ldrb	w1, [x20]
    6d5c:	340000e1 	cbz	w1, 6d78 <fwp_drop10+0x98>
    6d60:	7100043f 	cmp	w1, #0x1
    6d64:	54000120 	b.eq	6d88 <fwp_drop10+0xa8>  // b.none
    6d68:	7103fc3f 	cmp	w1, #0xff
    6d6c:	540007c0 	b.eq	6e64 <fwp_drop10+0x184>  // b.none
    6d70:	51000421 	sub	w1, w1, #0x1
    6d74:	39000281 	strb	w1, [x20]
    6d78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d7c:	f94013f5 	ldr	x21, [sp, #32]
    6d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d84:	d65f03c0 	ret
    6d88:	f9400001 	ldr	x1, [x0]
    6d8c:	b7f80581 	tbnz	x1, #63, 6e3c <fwp_drop10+0x15c>
    6d90:	91170273 	add	x19, x19, #0x5c0
    6d94:	f949da61 	ldr	x1, [x19, #5040]
    6d98:	f949ee62 	ldr	x2, [x19, #5080]
    6d9c:	cb010001 	sub	x1, x0, x1
    6da0:	eb02403f 	cmp	x1, x2, lsl #16
    6da4:	54fffea2 	b.cs	6d78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6da8:	d350fc22 	lsr	x2, x1, #16
    6dac:	8b020842 	add	x2, x2, x2, lsl #2
    6db0:	d37df042 	lsl	x2, x2, #3
    6db4:	8b020065 	add	x5, x3, x2
    6db8:	f94010a4 	ldr	x4, [x5, #32]
    6dbc:	b4fffde4 	cbz	x4, 6d78 <fwp_drop10+0x98>
    6dc0:	38626862 	ldrb	w2, [x3, x2]
    6dc4:	7100085f 	cmp	w2, #0x2
    6dc8:	54000220 	b.eq	6e0c <fwp_drop10+0x12c>  // b.none
    6dcc:	7100045f 	cmp	w2, #0x1
    6dd0:	54fffd41 	b.ne	6d78 <fwp_drop10+0x98>  // b.any
    6dd4:	294308a3 	ldp	w3, w2, [x5, #24]
    6dd8:	92403c21 	and	x1, x1, #0xffff
    6ddc:	9b037c21 	mul	x1, x1, x3
    6de0:	d360fc21 	lsr	x1, x1, #32
    6de4:	eb02003f 	cmp	x1, x2
    6de8:	54fffc82 	b.cs	6d78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6dec:	8b010084 	add	x4, x4, x1
    6df0:	39400081 	ldrb	w1, [x4]
    6df4:	7100043f 	cmp	w1, #0x1
    6df8:	54fffc01 	b.ne	6d78 <fwp_drop10+0x98>  // b.any
    6dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e00:	f94013f5 	ldr	x21, [sp, #32]
    6e04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e08:	17fff59e 	b	4480 <fwp_mem_free>
    6e0c:	72003c3f 	tst	w1, #0xffff
    6e10:	54ffff00 	b.eq	6df0 <fwp_drop10+0x110>  // b.none
    6e14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e18:	f94013f5 	ldr	x21, [sp, #32]
    6e1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e20:	d65f03c0 	ret
    6e24:	72003c3f 	tst	w1, #0xffff
    6e28:	54fff980 	b.eq	6d58 <fwp_drop10+0x78>  // b.none
    6e2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e30:	f94013f5 	ldr	x21, [sp, #32]
    6e34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e38:	d65f03c0 	ret
    6e3c:	f9400414 	ldr	x20, [x0, #8]
    6e40:	97fffb25 	bl	5ad4 <fwp_rc_free_arr>
    6e44:	91170260 	add	x0, x19, #0x5c0
    6e48:	f949d801 	ldr	x1, [x0, #5040]
    6e4c:	f949ec00 	ldr	x0, [x0, #5080]
    6e50:	cb010281 	sub	x1, x20, x1
    6e54:	eb00403f 	cmp	x1, x0, lsl #16
    6e58:	54fff902 	b.cs	6d78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e5c:	aa1403e0 	mov	x0, x20
    6e60:	17ffffab 	b	6d0c <fwp_drop10+0x2c>
    6e64:	ca544680 	eor	x0, x20, x20, lsr #17
    6e68:	91170273 	add	x19, x19, #0x5c0
    6e6c:	ca402400 	eor	x0, x0, x0, lsr #9
    6e70:	92401c00 	and	x0, x0, #0xff
    6e74:	910a2402 	add	x2, x0, #0x289
    6e78:	8b000e60 	add	x0, x19, x0, lsl #3
    6e7c:	8b020e62 	add	x2, x19, x2, lsl #3
    6e80:	f94a2400 	ldr	x0, [x0, #5192]
    6e84:	b50000a0 	cbnz	x0, 6e98 <fwp_drop10+0x1b8>
    6e88:	14000013 	b	6ed4 <fwp_drop10+0x1f4>
    6e8c:	91004002 	add	x2, x0, #0x10
    6e90:	f9400800 	ldr	x0, [x0, #16]
    6e94:	b4000200 	cbz	x0, 6ed4 <fwp_drop10+0x1f4>
    6e98:	f9400001 	ldr	x1, [x0]
    6e9c:	eb14003f 	cmp	x1, x20
    6ea0:	54ffff61 	b.ne	6e8c <fwp_drop10+0x1ac>  // b.any
    6ea4:	f9400041 	ldr	x1, [x2]
    6ea8:	f9400420 	ldr	x0, [x1, #8]
    6eac:	d1000400 	sub	x0, x0, #0x1
    6eb0:	f9000420 	str	x0, [x1, #8]
    6eb4:	f103f81f 	cmp	x0, #0xfe
    6eb8:	54fff601 	b.ne	6d78 <fwp_drop10+0x98>  // b.any
    6ebc:	39400280 	ldrb	w0, [x20]
    6ec0:	7103fc1f 	cmp	w0, #0xff
    6ec4:	540000e0 	b.eq	6ee0 <fwp_drop10+0x200>  // b.none
    6ec8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ecc:	39000280 	strb	w0, [x20]
    6ed0:	17ffffaa 	b	6d78 <fwp_drop10+0x98>
    6ed4:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    6ed8:	9129e000 	add	x0, x0, #0xa78
    6edc:	97fff4ad 	bl	4190 <fwp_trap>
    6ee0:	aa1403e0 	mov	x0, x20
    6ee4:	97fff4cb 	bl	4210 <fwp_rc_forget_slot.part.0>
    6ee8:	17fffff8 	b	6ec8 <fwp_drop10+0x1e8>
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_caps173>:
    6ef0:	34000041 	cbz	w1, 6ef8 <fwp_caps173+0x8>
    6ef4:	d65f03c0 	ret
    6ef8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc20>
    6efc:	91170063 	add	x3, x3, #0x5c0
    6f00:	f949d861 	ldr	x1, [x3, #5040]
    6f04:	f949ec62 	ldr	x2, [x3, #5080]
    6f08:	cb010001 	sub	x1, x0, x1
    6f0c:	eb02403f 	cmp	x1, x2, lsl #16
    6f10:	54ffff22 	b.cs	6ef4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6f14:	d350fc22 	lsr	x2, x1, #16
    6f18:	f949fc65 	ldr	x5, [x3, #5112]
    6f1c:	8b020842 	add	x2, x2, x2, lsl #2
    6f20:	d37df042 	lsl	x2, x2, #3
    6f24:	8b0200a4 	add	x4, x5, x2
    6f28:	f9401083 	ldr	x3, [x4, #32]
    6f2c:	b4fffe43 	cbz	x3, 6ef4 <fwp_caps173+0x4>
    6f30:	386268a2 	ldrb	w2, [x5, x2]
    6f34:	7100085f 	cmp	w2, #0x2
    6f38:	540001c0 	b.eq	6f70 <fwp_caps173+0x80>  // b.none
    6f3c:	7100045f 	cmp	w2, #0x1
    6f40:	54fffda1 	b.ne	6ef4 <fwp_caps173+0x4>  // b.any
    6f44:	29430885 	ldp	w5, w2, [x4, #24]
    6f48:	92403c21 	and	x1, x1, #0xffff
    6f4c:	9b057c21 	mul	x1, x1, x5
    6f50:	d360fc21 	lsr	x1, x1, #32
    6f54:	eb02003f 	cmp	x1, x2
    6f58:	54fffce2 	b.cs	6ef4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6f5c:	8b010063 	add	x3, x3, x1
    6f60:	39400061 	ldrb	w1, [x3]
    6f64:	7100043f 	cmp	w1, #0x1
    6f68:	54fffc61 	b.ne	6ef4 <fwp_caps173+0x4>  // b.any
    6f6c:	17fff545 	b	4480 <fwp_mem_free>
    6f70:	72003c3f 	tst	w1, #0xffff
    6f74:	54ffff60 	b.eq	6f60 <fwp_caps173+0x70>  // b.none
    6f78:	d65f03c0 	ret
    6f7c:	d503201f 	nop

0000000000006f80 <f37>:
    6f80:	d10203ff 	sub	sp, sp, #0x80
    6f84:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6f88:	f947f421 	ldr	x1, [x1, #4072]
    6f8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6f90:	910083fd 	add	x29, sp, #0x20
    6f94:	a9045bf5 	stp	x21, x22, [sp, #64]
    6f98:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc20>
    6f9c:	911702a3 	add	x3, x21, #0x5c0
    6fa0:	a90353f3 	stp	x19, x20, [sp, #48]
    6fa4:	aa0003f6 	mov	x22, x0
    6fa8:	a90563f7 	stp	x23, x24, [sp, #80]
    6fac:	a9066bf9 	stp	x25, x26, [sp, #96]
    6fb0:	f949ec62 	ldr	x2, [x3, #5080]
    6fb4:	f9400024 	ldr	x4, [x1]
    6fb8:	f9000fe4 	str	x4, [sp, #24]
    6fbc:	d2800004 	mov	x4, #0x0                   	// #0
    6fc0:	f949d861 	ldr	x1, [x3, #5040]
    6fc4:	d370bc42 	lsl	x2, x2, #16
    6fc8:	b4001820 	cbz	x0, 72cc <f37+0x34c>
    6fcc:	f9400817 	ldr	x23, [x0, #16]
    6fd0:	cb0102e1 	sub	x1, x23, x1
    6fd4:	eb02003f 	cmp	x1, x2
    6fd8:	54000362 	b.cs	7044 <f37+0xc4>  // b.hs, b.nlast
    6fdc:	f949fc60 	ldr	x0, [x3, #5112]
    6fe0:	d350fc22 	lsr	x2, x1, #16
    6fe4:	8b020842 	add	x2, x2, x2, lsl #2
    6fe8:	8b020c02 	add	x2, x0, x2, lsl #3
    6fec:	f9401040 	ldr	x0, [x2, #32]
    6ff0:	b40002a0 	cbz	x0, 7044 <f37+0xc4>
    6ff4:	39400043 	ldrb	w3, [x2]
    6ff8:	7100087f 	cmp	w3, #0x2
    6ffc:	54001560 	b.eq	72a8 <f37+0x328>  // b.none
    7000:	7100047f 	cmp	w3, #0x1
    7004:	540001c1 	b.ne	703c <f37+0xbc>  // b.any
    7008:	29430843 	ldp	w3, w2, [x2, #24]
    700c:	92403c21 	and	x1, x1, #0xffff
    7010:	9b037c21 	mul	x1, x1, x3
    7014:	d360fc21 	lsr	x1, x1, #32
    7018:	eb02003f 	cmp	x1, x2
    701c:	54000102 	b.cs	703c <f37+0xbc>  // b.hs, b.nlast
    7020:	8b010000 	add	x0, x0, x1
    7024:	39400001 	ldrb	w1, [x0]
    7028:	340000a1 	cbz	w1, 703c <f37+0xbc>
    702c:	7103f43f 	cmp	w1, #0xfd
    7030:	54001808 	b.hi	7330 <f37+0x3b0>  // b.pmore
    7034:	11000421 	add	w1, w1, #0x1
    7038:	39000001 	strb	w1, [x0]
    703c:	d2800002 	mov	x2, #0x0                   	// #0
    7040:	b40000f6 	cbz	x22, 705c <f37+0xdc>
    7044:	aa1603e1 	mov	x1, x22
    7048:	d2800002 	mov	x2, #0x0                   	// #0
    704c:	d503201f 	nop
    7050:	f9400821 	ldr	x1, [x1, #16]
    7054:	91000442 	add	x2, x2, #0x1
    7058:	b5ffffc1 	cbnz	x1, 7050 <f37+0xd0>
    705c:	b40013f7 	cbz	x23, 72d8 <f37+0x358>
    7060:	aa1703e1 	mov	x1, x23
    7064:	d2800003 	mov	x3, #0x0                   	// #0
    7068:	f9400821 	ldr	x1, [x1, #16]
    706c:	91000463 	add	x3, x3, #0x1
    7070:	b5ffffc1 	cbnz	x1, 7068 <f37+0xe8>
    7074:	eb02007f 	cmp	x3, x2
    7078:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    707c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7080:	eb00027f 	cmp	x19, x0
    7084:	540010a8 	b.hi	7298 <f37+0x318>  // b.pmore
    7088:	d37ffa74 	lsl	x20, x19, #1
    708c:	52800041 	mov	w1, #0x2                   	// #2
    7090:	91000680 	add	x0, x20, #0x1
    7094:	d37df000 	lsl	x0, x0, #3
    7098:	97fff7b6 	bl	4f70 <fwp_heap_alloc>
    709c:	aa0003f8 	mov	x24, x0
    70a0:	911702a1 	add	x1, x21, #0x5c0
    70a4:	aa0103e0 	mov	x0, x1
    70a8:	f9000314 	str	x20, [x24]
    70ac:	f949d821 	ldr	x1, [x1, #5040]
    70b0:	f949ec00 	ldr	x0, [x0, #5080]
    70b4:	cb010301 	sub	x1, x24, x1
    70b8:	eb00403f 	cmp	x1, x0, lsl #16
    70bc:	54000342 	b.cs	7124 <f37+0x1a4>  // b.hs, b.nlast
    70c0:	911702a2 	add	x2, x21, #0x5c0
    70c4:	d350fc20 	lsr	x0, x1, #16
    70c8:	8b000800 	add	x0, x0, x0, lsl #2
    70cc:	f949fc43 	ldr	x3, [x2, #5112]
    70d0:	d37df002 	lsl	x2, x0, #3
    70d4:	8b020060 	add	x0, x3, x2
    70d8:	f9401014 	ldr	x20, [x0, #32]
    70dc:	b4000254 	cbz	x20, 7124 <f37+0x1a4>
    70e0:	38626862 	ldrb	w2, [x3, x2]
    70e4:	7100085f 	cmp	w2, #0x2
    70e8:	54000ec0 	b.eq	72c0 <f37+0x340>  // b.none
    70ec:	7100045f 	cmp	w2, #0x1
    70f0:	540001a1 	b.ne	7124 <f37+0x1a4>  // b.any
    70f4:	29430002 	ldp	w2, w0, [x0, #24]
    70f8:	92403c21 	and	x1, x1, #0xffff
    70fc:	9b027c21 	mul	x1, x1, x2
    7100:	d360fc21 	lsr	x1, x1, #32
    7104:	eb00003f 	cmp	x1, x0
    7108:	540000e2 	b.cs	7124 <f37+0x1a4>  // b.hs, b.nlast
    710c:	8b010294 	add	x20, x20, x1
    7110:	39400280 	ldrb	w0, [x20]
    7114:	7103fc1f 	cmp	w0, #0xff
    7118:	54001100 	b.eq	7338 <f37+0x3b8>  // b.none
    711c:	52800020 	mov	w0, #0x1                   	// #1
    7120:	39000280 	strb	w0, [x20]
    7124:	b4000253 	cbz	x19, 716c <f37+0x1ec>
    7128:	8b131313 	add	x19, x24, x19, lsl #4
    712c:	aa1803f4 	mov	x20, x24
    7130:	aa1603fa 	mov	x26, x22
    7134:	aa1703f9 	mov	x25, x23
    7138:	f9400723 	ldr	x3, [x25, #8]
    713c:	f9400742 	ldr	x2, [x26, #8]
    7140:	f9400861 	ldr	x1, [x3, #16]
    7144:	f9400840 	ldr	x0, [x2, #16]
    7148:	fd400461 	ldr	d1, [x3, #8]
    714c:	fd400440 	ldr	d0, [x2, #8]
    7150:	97fff904 	bl	5560 <w120>
    7154:	f9000680 	str	x0, [x20, #8]
    7158:	f8010e81 	str	x1, [x20, #16]!
    715c:	f9400b39 	ldr	x25, [x25, #16]
    7160:	f9400b5a 	ldr	x26, [x26, #16]
    7164:	eb14027f 	cmp	x19, x20
    7168:	54fffe81 	b.ne	7138 <f37+0x1b8>  // b.any
    716c:	aa1703e0 	mov	x0, x23
    7170:	97fffd20 	bl	65f0 <fwp_drop4>
    7174:	aa1603e0 	mov	x0, x22
    7178:	97fffd1e 	bl	65f0 <fwp_drop4>
    717c:	f9400316 	ldr	x22, [x24]
    7180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7184:	b4000236 	cbz	x22, 71c8 <f37+0x248>
    7188:	fd003be8 	str	d8, [sp, #112]
    718c:	2f00e408 	movi	d8, #0x0
    7190:	91002319 	add	x25, x24, #0x8
    7194:	91004317 	add	x23, x24, #0x10
    7198:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    719c:	d2800013 	mov	x19, #0x0                   	// #0
    71a0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    71a4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    71a8:	91000a73 	add	x19, x19, #0x2
    71ac:	1e602908 	fadd	d8, d8, d0
    71b0:	97fff894 	bl	5400 <f141.constprop.0>
    71b4:	aa0003f4 	mov	x20, x0
    71b8:	eb1302df 	cmp	x22, x19
    71bc:	54ffff28 	b.hi	71a0 <f37+0x220>  // b.pmore
    71c0:	9e660116 	fmov	x22, d8
    71c4:	fd403be8 	ldr	d8, [sp, #112]
    71c8:	911702b5 	add	x21, x21, #0x5c0
    71cc:	aa1803e0 	mov	x0, x24
    71d0:	97fffec4 	bl	6ce0 <fwp_drop10>
    71d4:	a900d3f6 	stp	x22, x20, [sp, #8]
    71d8:	910023e1 	add	x1, sp, #0x8
    71dc:	52800000 	mov	w0, #0x0                   	// #0
    71e0:	97fff7a9 	bl	5084 <fwp_data.part.0.constprop.0>
    71e4:	f949daa1 	ldr	x1, [x21, #5040]
    71e8:	aa0003f3 	mov	x19, x0
    71ec:	f949eea0 	ldr	x0, [x21, #5080]
    71f0:	cb010261 	sub	x1, x19, x1
    71f4:	eb00403f 	cmp	x1, x0, lsl #16
    71f8:	54000322 	b.cs	725c <f37+0x2dc>  // b.hs, b.nlast
    71fc:	d350fc22 	lsr	x2, x1, #16
    7200:	f949fea3 	ldr	x3, [x21, #5112]
    7204:	8b020842 	add	x2, x2, x2, lsl #2
    7208:	d37df042 	lsl	x2, x2, #3
    720c:	8b020060 	add	x0, x3, x2
    7210:	f9401014 	ldr	x20, [x0, #32]
    7214:	b4000254 	cbz	x20, 725c <f37+0x2dc>
    7218:	38626862 	ldrb	w2, [x3, x2]
    721c:	7100085f 	cmp	w2, #0x2
    7220:	540004a0 	b.eq	72b4 <f37+0x334>  // b.none
    7224:	7100045f 	cmp	w2, #0x1
    7228:	540001a1 	b.ne	725c <f37+0x2dc>  // b.any
    722c:	29430002 	ldp	w2, w0, [x0, #24]
    7230:	92403c21 	and	x1, x1, #0xffff
    7234:	9b027c21 	mul	x1, x1, x2
    7238:	d360fc21 	lsr	x1, x1, #32
    723c:	eb00003f 	cmp	x1, x0
    7240:	540000e2 	b.cs	725c <f37+0x2dc>  // b.hs, b.nlast
    7244:	8b010294 	add	x20, x20, x1
    7248:	39400280 	ldrb	w0, [x20]
    724c:	7103fc1f 	cmp	w0, #0xff
    7250:	540007a0 	b.eq	7344 <f37+0x3c4>  // b.none
    7254:	52800020 	mov	w0, #0x1                   	// #1
    7258:	39000280 	strb	w0, [x20]
    725c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7260:	f947f400 	ldr	x0, [x0, #4072]
    7264:	f9400fe2 	ldr	x2, [sp, #24]
    7268:	f9400001 	ldr	x1, [x0]
    726c:	eb010042 	subs	x2, x2, x1
    7270:	d2800001 	mov	x1, #0x0                   	// #0
    7274:	54000721 	b.ne	7358 <f37+0x3d8>  // b.any
    7278:	a9427bfd 	ldp	x29, x30, [sp, #32]
    727c:	aa1303e0 	mov	x0, x19
    7280:	a94353f3 	ldp	x19, x20, [sp, #48]
    7284:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7288:	a94563f7 	ldp	x23, x24, [sp, #80]
    728c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7290:	910203ff 	add	sp, sp, #0x80
    7294:	d65f03c0 	ret
    7298:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    729c:	91348000 	add	x0, x0, #0xd20
    72a0:	fd003be8 	str	d8, [sp, #112]
    72a4:	97fff3bb 	bl	4190 <fwp_trap>
    72a8:	72003c3f 	tst	w1, #0xffff
    72ac:	54ffec81 	b.ne	703c <f37+0xbc>  // b.any
    72b0:	17ffff5d 	b	7024 <f37+0xa4>
    72b4:	72003c3f 	tst	w1, #0xffff
    72b8:	54fffd21 	b.ne	725c <f37+0x2dc>  // b.any
    72bc:	17ffffe3 	b	7248 <f37+0x2c8>
    72c0:	72003c3f 	tst	w1, #0xffff
    72c4:	54fff301 	b.ne	7124 <f37+0x1a4>  // b.any
    72c8:	17ffff92 	b	7110 <f37+0x190>
    72cc:	cb0103e1 	neg	x1, x1
    72d0:	eb02003f 	cmp	x1, x2
    72d4:	540001e3 	b.cc	7310 <f37+0x390>  // b.lo, b.ul, b.last
    72d8:	52800041 	mov	w1, #0x2                   	// #2
    72dc:	d2800100 	mov	x0, #0x8                   	// #8
    72e0:	97fff724 	bl	4f70 <fwp_heap_alloc>
    72e4:	aa0003f8 	mov	x24, x0
    72e8:	911702a0 	add	x0, x21, #0x5c0
    72ec:	f900031f 	str	xzr, [x24]
    72f0:	f949d801 	ldr	x1, [x0, #5040]
    72f4:	f949ec00 	ldr	x0, [x0, #5080]
    72f8:	cb010301 	sub	x1, x24, x1
    72fc:	eb00403f 	cmp	x1, x0, lsl #16
    7300:	54000282 	b.cs	7350 <f37+0x3d0>  // b.hs, b.nlast
    7304:	d2800013 	mov	x19, #0x0                   	// #0
    7308:	d2800017 	mov	x23, #0x0                   	// #0
    730c:	17ffff6d 	b	70c0 <f37+0x140>
    7310:	f949fc62 	ldr	x2, [x3, #5112]
    7314:	d350fc20 	lsr	x0, x1, #16
    7318:	8b000800 	add	x0, x0, x0, lsl #2
    731c:	8b000c42 	add	x2, x2, x0, lsl #3
    7320:	f9401040 	ldr	x0, [x2, #32]
    7324:	b4fffda0 	cbz	x0, 72d8 <f37+0x358>
    7328:	d2800017 	mov	x23, #0x0                   	// #0
    732c:	17ffff32 	b	6ff4 <f37+0x74>
    7330:	97fff4cd 	bl	4664 <fwp_rc_wide_dup>
    7334:	17ffff42 	b	703c <f37+0xbc>
    7338:	aa1403e0 	mov	x0, x20
    733c:	97fff3b5 	bl	4210 <fwp_rc_forget_slot.part.0>
    7340:	17ffff77 	b	711c <f37+0x19c>
    7344:	aa1403e0 	mov	x0, x20
    7348:	97fff3b2 	bl	4210 <fwp_rc_forget_slot.part.0>
    734c:	17ffffc2 	b	7254 <f37+0x2d4>
    7350:	d2800017 	mov	x23, #0x0                   	// #0
    7354:	17ffff86 	b	716c <f37+0x1ec>
    7358:	fd003be8 	str	d8, [sp, #112]
    735c:	97ffed6d 	bl	2910 <__stack_chk_fail@plt>

0000000000007360 <fwp_owned_entry37>:
    7360:	f9400000 	ldr	x0, [x0]
    7364:	17ffff07 	b	6f80 <f37>
    7368:	d503201f 	nop
    736c:	d503201f 	nop

0000000000007370 <e37>:
    7370:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7374:	910003fd 	mov	x29, sp
    7378:	f9000bf3 	str	x19, [sp, #16]
    737c:	f9400013 	ldr	x19, [x0]
    7380:	aa1303e0 	mov	x0, x19
    7384:	97fff9b0 	bl	5a44 <fwp_rc_share>
    7388:	aa1303e0 	mov	x0, x19
    738c:	97fffefd 	bl	6f80 <f37>
    7390:	aa0003f3 	mov	x19, x0
    7394:	97fff9ac 	bl	5a44 <fwp_rc_share>
    7398:	aa1303e0 	mov	x0, x19
    739c:	f9400bf3 	ldr	x19, [sp, #16]
    73a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73a4:	d65f03c0 	ret
    73a8:	d503201f 	nop
    73ac:	d503201f 	nop

00000000000073b0 <fwp_args37>:
    73b0:	7100003f 	cmp	w1, #0x0
    73b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    73b8:	54000041 	b.ne	73c0 <fwp_args37+0x10>  // b.any
    73bc:	d65f03c0 	ret
    73c0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    73c4:	91170042 	add	x2, x2, #0x5c0
    73c8:	f9400001 	ldr	x1, [x0]
    73cc:	f949d843 	ldr	x3, [x2, #5040]
    73d0:	f949ec40 	ldr	x0, [x2, #5080]
    73d4:	cb030021 	sub	x1, x1, x3
    73d8:	eb00403f 	cmp	x1, x0, lsl #16
    73dc:	54ffff02 	b.cs	73bc <fwp_args37+0xc>  // b.hs, b.nlast
    73e0:	d350fc20 	lsr	x0, x1, #16
    73e4:	f949fc44 	ldr	x4, [x2, #5112]
    73e8:	8b000800 	add	x0, x0, x0, lsl #2
    73ec:	d37df002 	lsl	x2, x0, #3
    73f0:	8b020083 	add	x3, x4, x2
    73f4:	f9401060 	ldr	x0, [x3, #32]
    73f8:	b4fffe20 	cbz	x0, 73bc <fwp_args37+0xc>
    73fc:	38626882 	ldrb	w2, [x4, x2]
    7400:	7100085f 	cmp	w2, #0x2
    7404:	54000220 	b.eq	7448 <fwp_args37+0x98>  // b.none
    7408:	7100045f 	cmp	w2, #0x1
    740c:	54fffd81 	b.ne	73bc <fwp_args37+0xc>  // b.any
    7410:	29430864 	ldp	w4, w2, [x3, #24]
    7414:	92403c21 	and	x1, x1, #0xffff
    7418:	9b047c21 	mul	x1, x1, x4
    741c:	d360fc21 	lsr	x1, x1, #32
    7420:	eb02003f 	cmp	x1, x2
    7424:	54fffcc2 	b.cs	73bc <fwp_args37+0xc>  // b.hs, b.nlast
    7428:	8b010000 	add	x0, x0, x1
    742c:	39400001 	ldrb	w1, [x0]
    7430:	34fffc61 	cbz	w1, 73bc <fwp_args37+0xc>
    7434:	7103f43f 	cmp	w1, #0xfd
    7438:	540000e8 	b.hi	7454 <fwp_args37+0xa4>  // b.pmore
    743c:	11000421 	add	w1, w1, #0x1
    7440:	39000001 	strb	w1, [x0]
    7444:	d65f03c0 	ret
    7448:	72003c3f 	tst	w1, #0xffff
    744c:	54ffff00 	b.eq	742c <fwp_args37+0x7c>  // b.none
    7450:	d65f03c0 	ret
    7454:	17fff484 	b	4664 <fwp_rc_wide_dup>
    7458:	d503201f 	nop
    745c:	d503201f 	nop

0000000000007460 <fwp_caps37>:
    7460:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7464:	910003fd 	mov	x29, sp
    7468:	f9000bf3 	str	x19, [sp, #16]
    746c:	aa0003f3 	mov	x19, x0
    7470:	b9400400 	ldr	w0, [x0, #4]
    7474:	340004a0 	cbz	w0, 7508 <fwp_caps37+0xa8>
    7478:	f9400660 	ldr	x0, [x19, #8]
    747c:	350004e1 	cbnz	w1, 7518 <fwp_caps37+0xb8>
    7480:	97fffc5c 	bl	65f0 <fwp_drop4>
    7484:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    7488:	91170042 	add	x2, x2, #0x5c0
    748c:	f949d840 	ldr	x0, [x2, #5040]
    7490:	f949ec41 	ldr	x1, [x2, #5080]
    7494:	cb000260 	sub	x0, x19, x0
    7498:	eb01401f 	cmp	x0, x1, lsl #16
    749c:	54000382 	b.cs	750c <fwp_caps37+0xac>  // b.hs, b.nlast
    74a0:	d350fc01 	lsr	x1, x0, #16
    74a4:	f949fc44 	ldr	x4, [x2, #5112]
    74a8:	8b010821 	add	x1, x1, x1, lsl #2
    74ac:	d37df021 	lsl	x1, x1, #3
    74b0:	8b010083 	add	x3, x4, x1
    74b4:	f9401062 	ldr	x2, [x3, #32]
    74b8:	b40002a2 	cbz	x2, 750c <fwp_caps37+0xac>
    74bc:	38616881 	ldrb	w1, [x4, x1]
    74c0:	7100083f 	cmp	w1, #0x2
    74c4:	540006c0 	b.eq	759c <fwp_caps37+0x13c>  // b.none
    74c8:	7100043f 	cmp	w1, #0x1
    74cc:	54000201 	b.ne	750c <fwp_caps37+0xac>  // b.any
    74d0:	29430464 	ldp	w4, w1, [x3, #24]
    74d4:	92403c00 	and	x0, x0, #0xffff
    74d8:	9b047c00 	mul	x0, x0, x4
    74dc:	d360fc00 	lsr	x0, x0, #32
    74e0:	eb01001f 	cmp	x0, x1
    74e4:	54000142 	b.cs	750c <fwp_caps37+0xac>  // b.hs, b.nlast
    74e8:	8b000042 	add	x2, x2, x0
    74ec:	39400040 	ldrb	w0, [x2]
    74f0:	7100041f 	cmp	w0, #0x1
    74f4:	540000c1 	b.ne	750c <fwp_caps37+0xac>  // b.any
    74f8:	aa1303e0 	mov	x0, x19
    74fc:	f9400bf3 	ldr	x19, [sp, #16]
    7500:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7504:	17fff3df 	b	4480 <fwp_mem_free>
    7508:	34fffbe1 	cbz	w1, 7484 <fwp_caps37+0x24>
    750c:	f9400bf3 	ldr	x19, [sp, #16]
    7510:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7514:	d65f03c0 	ret
    7518:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    751c:	91170042 	add	x2, x2, #0x5c0
    7520:	f949d843 	ldr	x3, [x2, #5040]
    7524:	f949ec41 	ldr	x1, [x2, #5080]
    7528:	cb030000 	sub	x0, x0, x3
    752c:	eb01401f 	cmp	x0, x1, lsl #16
    7530:	54fffee2 	b.cs	750c <fwp_caps37+0xac>  // b.hs, b.nlast
    7534:	d350fc01 	lsr	x1, x0, #16
    7538:	f949fc44 	ldr	x4, [x2, #5112]
    753c:	8b010821 	add	x1, x1, x1, lsl #2
    7540:	d37df021 	lsl	x1, x1, #3
    7544:	8b010083 	add	x3, x4, x1
    7548:	f9401062 	ldr	x2, [x3, #32]
    754c:	b4fffe02 	cbz	x2, 750c <fwp_caps37+0xac>
    7550:	38616881 	ldrb	w1, [x4, x1]
    7554:	7100083f 	cmp	w1, #0x2
    7558:	54000280 	b.eq	75a8 <fwp_caps37+0x148>  // b.none
    755c:	7100043f 	cmp	w1, #0x1
    7560:	54fffd61 	b.ne	750c <fwp_caps37+0xac>  // b.any
    7564:	92403c01 	and	x1, x0, #0xffff
    7568:	29430064 	ldp	w4, w0, [x3, #24]
    756c:	9b047c21 	mul	x1, x1, x4
    7570:	d360fc21 	lsr	x1, x1, #32
    7574:	eb00003f 	cmp	x1, x0
    7578:	54fffca2 	b.cs	750c <fwp_caps37+0xac>  // b.hs, b.nlast
    757c:	8b010042 	add	x2, x2, x1
    7580:	39400040 	ldrb	w0, [x2]
    7584:	34fffc40 	cbz	w0, 750c <fwp_caps37+0xac>
    7588:	7103f41f 	cmp	w0, #0xfd
    758c:	54000148 	b.hi	75b4 <fwp_caps37+0x154>  // b.pmore
    7590:	11000400 	add	w0, w0, #0x1
    7594:	39000040 	strb	w0, [x2]
    7598:	17ffffdd 	b	750c <fwp_caps37+0xac>
    759c:	72003c1f 	tst	w0, #0xffff
    75a0:	54fffb61 	b.ne	750c <fwp_caps37+0xac>  // b.any
    75a4:	17ffffd2 	b	74ec <fwp_caps37+0x8c>
    75a8:	72003c1f 	tst	w0, #0xffff
    75ac:	54fffb01 	b.ne	750c <fwp_caps37+0xac>  // b.any
    75b0:	17fffff4 	b	7580 <fwp_caps37+0x120>
    75b4:	f9400bf3 	ldr	x19, [sp, #16]
    75b8:	aa0203e0 	mov	x0, x2
    75bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    75c0:	17fff429 	b	4664 <fwp_rc_wide_dup>

00000000000075c4 <fwp_write>:
    75c4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    75c8:	910003fd 	mov	x29, sp
    75cc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    75d0:	f947f484 	ldr	x4, [x4, #4072]
    75d4:	a90153f3 	stp	x19, x20, [sp, #16]
    75d8:	d10943ff 	sub	sp, sp, #0x250
    75dc:	b9400045 	ldr	w5, [x2]
    75e0:	aa0003f4 	mov	x20, x0
    75e4:	f9400080 	ldr	x0, [x4]
    75e8:	f90127e0 	str	x0, [sp, #584]
    75ec:	d2800000 	mov	x0, #0x0                   	// #0
    75f0:	710064bf 	cmp	w5, #0x19
    75f4:	54000408 	b.hi	7674 <fwp_write+0xb0>  // b.pmore
    75f8:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x780>
    75fc:	aa0103f3 	mov	x19, x1
    7600:	9114c000 	add	x0, x0, #0x530
    7604:	f9013bf5 	str	x21, [sp, #624]
    7608:	f9013ff6 	str	x22, [sp, #632]
    760c:	f90153fb 	str	x27, [sp, #672]
    7610:	f90157fc 	str	x28, [sp, #680]
    7614:	aa0203fc 	mov	x28, x2
    7618:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    761c:	10000061 	adr	x1, 7628 <fwp_write+0x64>
    7620:	8b20a820 	add	x0, x1, w0, sxth #2
    7624:	d61f0000 	br	x0
    7628:	910123e0 	add	x0, sp, #0x48
    762c:	aa1303e5 	mov	x5, x19
    7630:	d0000004 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    7634:	aa0003f3 	mov	x19, x0
    7638:	9135a084 	add	x4, x4, #0xd68
    763c:	d2804003 	mov	x3, #0x200                 	// #512
    7640:	aa0303e1 	mov	x1, x3
    7644:	52800042 	mov	w2, #0x2                   	// #2
    7648:	97ffec8e 	bl	2880 <__snprintf_chk@plt>
    764c:	aa1303e0 	mov	x0, x19
    7650:	97ffec54 	bl	27a0 <strlen@plt>
    7654:	aa1303e1 	mov	x1, x19
    7658:	aa0003e2 	mov	x2, x0
    765c:	aa1403e0 	mov	x0, x20
    7660:	97ffefec 	bl	3610 <buf_put>
    7664:	f9413bf5 	ldr	x21, [sp, #624]
    7668:	f9413ff6 	ldr	x22, [sp, #632]
    766c:	f94153fb 	ldr	x27, [sp, #672]
    7670:	f94157fc 	ldr	x28, [sp, #680]
    7674:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7678:	f947f400 	ldr	x0, [x0, #4072]
    767c:	f94127e2 	ldr	x2, [sp, #584]
    7680:	f9400001 	ldr	x1, [x0]
    7684:	eb010042 	subs	x2, x2, x1
    7688:	d2800001 	mov	x1, #0x0                   	// #0
    768c:	540077a1 	b.ne	8580 <fwp_write+0xfbc>  // b.any
    7690:	910943ff 	add	sp, sp, #0x250
    7694:	a94153f3 	ldp	x19, x20, [sp, #16]
    7698:	a8c77bfd 	ldp	x29, x30, [sp], #112
    769c:	d65f03c0 	ret
    76a0:	910123e0 	add	x0, sp, #0x48
    76a4:	aa1303e5 	mov	x5, x19
    76a8:	d0000004 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    76ac:	aa0003f3 	mov	x19, x0
    76b0:	91358084 	add	x4, x4, #0xd60
    76b4:	d2804003 	mov	x3, #0x200                 	// #512
    76b8:	17ffffe2 	b	7640 <fwp_write+0x7c>
    76bc:	71004cbf 	cmp	w5, #0x13
    76c0:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    76c4:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    76c8:	91354000 	add	x0, x0, #0xd50
    76cc:	91356021 	add	x1, x1, #0xd58
    76d0:	d2800082 	mov	x2, #0x4                   	// #4
    76d4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	f90143f7 	str	x23, [sp, #640]
    76e0:	d2800016 	mov	x22, #0x0                   	// #0
    76e4:	f90147f8 	str	x24, [sp, #648]
    76e8:	97ffefca 	bl	3610 <buf_put>
    76ec:	f9400260 	ldr	x0, [x19]
    76f0:	d0000017 	adrp	x23, 9000 <fwp_main_thread+0xa50>
    76f4:	d2800015 	mov	x21, #0x0                   	// #0
    76f8:	913762f7 	add	x23, x23, #0xdd8
    76fc:	b4004780 	cbz	x0, 7fec <fwp_write+0xa28>
    7700:	b9400380 	ldr	w0, [x28]
    7704:	52800003 	mov	w3, #0x0                   	// #0
    7708:	f9401f82 	ldr	x2, [x28, #56]
    770c:	71004c1f 	cmp	w0, #0x13
    7710:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7714:	aa1403e0 	mov	x0, x20
    7718:	8b010e61 	add	x1, x19, x1, lsl #3
    771c:	f9400421 	ldr	x1, [x1, #8]
    7720:	97ffffa9 	bl	75c4 <fwp_write>
    7724:	b9400380 	ldr	w0, [x28]
    7728:	7100481f 	cmp	w0, #0x12
    772c:	54004b20 	b.eq	8090 <fwp_write+0xacc>  // b.none
    7730:	f9400260 	ldr	x0, [x19]
    7734:	910006b5 	add	x21, x21, #0x1
    7738:	91000ad6 	add	x22, x22, #0x2
    773c:	eb15001f 	cmp	x0, x21
    7740:	54004569 	b.ls	7fec <fwp_write+0xa28>  // b.plast
    7744:	aa1703e1 	mov	x1, x23
    7748:	aa1403e0 	mov	x0, x20
    774c:	d2800042 	mov	x2, #0x2                   	// #2
    7750:	97ffefb0 	bl	3610 <buf_put>
    7754:	17ffffeb 	b	7700 <fwp_write+0x13c>
    7758:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    775c:	91364021 	add	x1, x1, #0xd90
    7760:	d28000c2 	mov	x2, #0x6                   	// #6
    7764:	aa1403e0 	mov	x0, x20
    7768:	91004273 	add	x19, x19, #0x10
    776c:	97ffefa9 	bl	3610 <buf_put>
    7770:	aa1303e0 	mov	x0, x19
    7774:	97ffec0b 	bl	27a0 <strlen@plt>
    7778:	aa1303e1 	mov	x1, x19
    777c:	aa0003e2 	mov	x2, x0
    7780:	aa1403e0 	mov	x0, x20
    7784:	97ffefa3 	bl	3610 <buf_put>
    7788:	528007c3 	mov	w3, #0x3e                  	// #62
    778c:	aa1403e0 	mov	x0, x20
    7790:	91001fe1 	add	x1, sp, #0x7
    7794:	d2800022 	mov	x2, #0x1                   	// #1
    7798:	39001fe3 	strb	w3, [sp, #7]
    779c:	17ffffb1 	b	7660 <fwp_write+0x9c>
    77a0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    77a4:	f947f400 	ldr	x0, [x0, #4072]
    77a8:	f94127e2 	ldr	x2, [sp, #584]
    77ac:	f9400001 	ldr	x1, [x0]
    77b0:	eb010042 	subs	x2, x2, x1
    77b4:	d2800001 	mov	x1, #0x0                   	// #0
    77b8:	540034c1 	b.ne	7e50 <fwp_write+0x88c>  // b.any
    77bc:	f9413bf5 	ldr	x21, [sp, #624]
    77c0:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    77c4:	f9413ff6 	ldr	x22, [sp, #632]
    77c8:	aa1403e0 	mov	x0, x20
    77cc:	9135c021 	add	x1, x1, #0xd70
    77d0:	d2800142 	mov	x2, #0xa                   	// #10
    77d4:	f94153fb 	ldr	x27, [sp, #672]
    77d8:	f94157fc 	ldr	x28, [sp, #680]
    77dc:	910943ff 	add	sp, sp, #0x250
    77e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    77e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    77e8:	17ffef8a 	b	3610 <buf_put>
    77ec:	f9400456 	ldr	x22, [x2, #8]
    77f0:	f90143f7 	str	x23, [sp, #640]
    77f4:	f90147f8 	str	x24, [sp, #648]
    77f8:	b4005af6 	cbz	x22, 8354 <fwp_write+0xd90>
    77fc:	aa1603e0 	mov	x0, x22
    7800:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7804:	9137c021 	add	x1, x1, #0xdf0
    7808:	97ffec62 	bl	2990 <strcmp@plt>
    780c:	2a0003f5 	mov	w21, w0
    7810:	34005fc0 	cbz	w0, 8408 <fwp_write+0xe44>
    7814:	aa1603e0 	mov	x0, x22
    7818:	97ffebe2 	bl	27a0 <strlen@plt>
    781c:	aa1603e1 	mov	x1, x22
    7820:	aa0003e2 	mov	x2, x0
    7824:	aa1403e0 	mov	x0, x20
    7828:	97ffef7a 	bl	3610 <buf_put>
    782c:	52800403 	mov	w3, #0x20                  	// #32
    7830:	91001ff5 	add	x21, sp, #0x7
    7834:	aa1503e1 	mov	x1, x21
    7838:	aa1403e0 	mov	x0, x20
    783c:	d2800022 	mov	x2, #0x1                   	// #1
    7840:	39001fe3 	strb	w3, [sp, #7]
    7844:	97ffef73 	bl	3610 <buf_put>
    7848:	52800f63 	mov	w3, #0x7b                  	// #123
    784c:	aa1403e0 	mov	x0, x20
    7850:	aa1503e1 	mov	x1, x21
    7854:	d2800022 	mov	x2, #0x1                   	// #1
    7858:	39001fe3 	strb	w3, [sp, #7]
    785c:	97ffef6d 	bl	3610 <buf_put>
    7860:	b9401380 	ldr	w0, [x28, #16]
    7864:	52800018 	mov	w24, #0x0                   	// #0
    7868:	7100001f 	cmp	w0, #0x0
    786c:	54003a8d 	b.le	7fbc <fwp_write+0x9f8>
    7870:	f9014bf9 	str	x25, [sp, #656]
    7874:	d0000019 	adrp	x25, 9000 <fwp_main_thread+0xa50>
    7878:	91386339 	add	x25, x25, #0xe18
    787c:	f9014ffa 	str	x26, [sp, #664]
    7880:	d000001a 	adrp	x26, 9000 <fwp_main_thread+0xa50>
    7884:	9137635a 	add	x26, x26, #0xdd8
    7888:	91002276 	add	x22, x19, #0x8
    788c:	d2800013 	mov	x19, #0x0                   	// #0
    7890:	b5003e73 	cbnz	x19, 805c <fwp_write+0xa98>
    7894:	d37df277 	lsl	x23, x19, #3
    7898:	34003c98 	cbz	w24, 8028 <fwp_write+0xa64>
    789c:	f9401382 	ldr	x2, [x28, #32]
    78a0:	aa1403e0 	mov	x0, x20
    78a4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    78a8:	52800003 	mov	w3, #0x0                   	// #0
    78ac:	f8776842 	ldr	x2, [x2, x23]
    78b0:	91000673 	add	x19, x19, #0x1
    78b4:	97ffff44 	bl	75c4 <fwp_write>
    78b8:	b9401380 	ldr	w0, [x28, #16]
    78bc:	6b13001f 	cmp	w0, w19
    78c0:	54fffe8c 	b.gt	7890 <fwp_write+0x2cc>
    78c4:	f9414bf9 	ldr	x25, [sp, #656]
    78c8:	f9414ffa 	ldr	x26, [sp, #664]
    78cc:	34003798 	cbz	w24, 7fbc <fwp_write+0x9f8>
    78d0:	52800523 	mov	w3, #0x29                  	// #41
    78d4:	aa1503e1 	mov	x1, x21
    78d8:	aa1403e0 	mov	x0, x20
    78dc:	d2800022 	mov	x2, #0x1                   	// #1
    78e0:	39001fe3 	strb	w3, [sp, #7]
    78e4:	97ffef4b 	bl	3610 <buf_put>
    78e8:	f9413bf5 	ldr	x21, [sp, #624]
    78ec:	f9413ff6 	ldr	x22, [sp, #632]
    78f0:	f94143f7 	ldr	x23, [sp, #640]
    78f4:	f94147f8 	ldr	x24, [sp, #648]
    78f8:	f94153fb 	ldr	x27, [sp, #672]
    78fc:	f94157fc 	ldr	x28, [sp, #680]
    7900:	17ffff5d 	b	7674 <fwp_write+0xb0>
    7904:	b9404855 	ldr	w21, [x2, #72]
    7908:	aa1403e0 	mov	x0, x20
    790c:	93407eb6 	sxtw	x22, w21
    7910:	91000ac1 	add	x1, x22, #0x2
    7914:	97ffef0c 	bl	3544 <buf_grow>
    7918:	a9400281 	ldp	x1, x0, [x20]
    791c:	528e8603 	mov	w3, #0x7430                	// #29744
    7920:	78206823 	strh	w3, [x1, x0]
    7924:	8b000022 	add	x2, x1, x0
    7928:	710002bf 	cmp	w21, #0x0
    792c:	540036ad 	b.le	8000 <fwp_write+0xa3c>
    7930:	110006a3 	add	w3, w21, #0x1
    7934:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7938:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    793c:	91000449 	add	x9, x2, #0x1
    7940:	8b23c043 	add	x3, x2, w3, sxtw
    7944:	f28aaac6 	movk	x6, #0x5556
    7948:	f2955568 	movk	x8, #0xaaab
    794c:	1400000d 	b	7980 <fwp_write+0x3bc>
    7950:	d2800021 	mov	x1, #0x1                   	// #1
    7954:	528005a5 	mov	w5, #0x2d                  	// #45
    7958:	f100001f 	cmp	x0, #0x0
    795c:	9b467e60 	smulh	x0, x19, x6
    7960:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7964:	381ff465 	strb	w5, [x3], #-1
    7968:	cb040000 	sub	x0, x0, x4
    796c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7970:	cb020000 	sub	x0, x0, x2
    7974:	8b010013 	add	x19, x0, x1
    7978:	eb03013f 	cmp	x9, x3
    797c:	54003420 	b.eq	8000 <fwp_write+0xa3c>  // b.none
    7980:	9b467e60 	smulh	x0, x19, x6
    7984:	937ffe64 	asr	x4, x19, #63
    7988:	52800605 	mov	w5, #0x30                  	// #48
    798c:	cb040000 	sub	x0, x0, x4
    7990:	8b000400 	add	x0, x0, x0, lsl #1
    7994:	cb000260 	sub	x0, x19, x0
    7998:	91000c01 	add	x1, x0, #0x3
    799c:	9bc87c22 	umulh	x2, x1, x8
    79a0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    79a4:	8b4204e2 	add	x2, x7, x2, lsr #1
    79a8:	eb020021 	subs	x1, x1, x2
    79ac:	54fffd60 	b.eq	7958 <fwp_write+0x394>  // b.none
    79b0:	f100043f 	cmp	x1, #0x1
    79b4:	54fffce1 	b.ne	7950 <fwp_write+0x38c>  // b.any
    79b8:	d2800001 	mov	x1, #0x0                   	// #0
    79bc:	52800565 	mov	w5, #0x2b                  	// #43
    79c0:	17ffffe6 	b	7958 <fwp_write+0x394>
    79c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    79c8:	f947f400 	ldr	x0, [x0, #4072]
    79cc:	f94127e2 	ldr	x2, [sp, #584]
    79d0:	f9400001 	ldr	x1, [x0]
    79d4:	eb010042 	subs	x2, x2, x1
    79d8:	d2800001 	mov	x1, #0x0                   	// #0
    79dc:	540023a1 	b.ne	7e50 <fwp_write+0x88c>  // b.any
    79e0:	f9413bf5 	ldr	x21, [sp, #624]
    79e4:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    79e8:	f9413ff6 	ldr	x22, [sp, #632]
    79ec:	aa1403e0 	mov	x0, x20
    79f0:	91360021 	add	x1, x1, #0xd80
    79f4:	d2800102 	mov	x2, #0x8                   	// #8
    79f8:	17ffff77 	b	77d4 <fwp_write+0x210>
    79fc:	aa1403e0 	mov	x0, x20
    7a00:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7a04:	d28000c2 	mov	x2, #0x6                   	// #6
    7a08:	91378021 	add	x1, x1, #0xde0
    7a0c:	97ffef01 	bl	3610 <buf_put>
    7a10:	d2800015 	mov	x21, #0x0                   	// #0
    7a14:	f9400263 	ldr	x3, [x19]
    7a18:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7a1c:	54002c40 	b.eq	7fa4 <fwp_write+0x9e0>  // b.none
    7a20:	f9401f82 	ldr	x2, [x28, #56]
    7a24:	f90143f7 	str	x23, [sp, #640]
    7a28:	f90147f8 	str	x24, [sp, #648]
    7a2c:	d2800857 	mov	x23, #0x42                  	// #66
    7a30:	f9014bf9 	str	x25, [sp, #656]
    7a34:	d0000016 	adrp	x22, 9000 <fwp_main_thread+0xa50>
    7a38:	f9014ffa 	str	x26, [sp, #664]
    7a3c:	913762d6 	add	x22, x22, #0xdd8
    7a40:	d2800038 	mov	x24, #0x1                   	// #1
    7a44:	f2a18017 	movk	x23, #0xc00, lsl #16
    7a48:	d2809099 	mov	x25, #0x484                 	// #1156
    7a4c:	b4000482 	cbz	x2, 7adc <fwp_write+0x518>
    7a50:	b9400040 	ldr	w0, [x2]
    7a54:	7100701f 	cmp	w0, #0x1c
    7a58:	540042a0 	b.eq	82ac <fwp_write+0xce8>  // b.none
    7a5c:	71006c1f 	cmp	w0, #0x1b
    7a60:	540003e8 	b.hi	7adc <fwp_write+0x518>  // b.pmore
    7a64:	9ac02301 	lsl	x1, x24, x0
    7a68:	ea17003f 	tst	x1, x23
    7a6c:	54003681 	b.ne	813c <fwp_write+0xb78>  // b.any
    7a70:	ea19003f 	tst	x1, x25
    7a74:	54003501 	b.ne	8114 <fwp_write+0xb50>  // b.any
    7a78:	d2800424 	mov	x4, #0x21                  	// #33
    7a7c:	ea04003f 	tst	x1, x4
    7a80:	540002e0 	b.eq	7adc <fwp_write+0x518>  // b.none
    7a84:	b7f849a3 	tbnz	x3, #63, 83b8 <fwp_write+0xdf4>
    7a88:	91002261 	add	x1, x19, #0x8
    7a8c:	8b150021 	add	x1, x1, x21
    7a90:	39400021 	ldrb	w1, [x1]
    7a94:	7100001f 	cmp	w0, #0x0
    7a98:	93401c23 	sxtb	x3, w1
    7a9c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7aa0:	aa1403e0 	mov	x0, x20
    7aa4:	52800003 	mov	w3, #0x0                   	// #0
    7aa8:	97fffec7 	bl	75c4 <fwp_write>
    7aac:	910006b5 	add	x21, x21, #0x1
    7ab0:	f9400260 	ldr	x0, [x19]
    7ab4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7ab8:	eb0002bf 	cmp	x21, x0
    7abc:	540026c2 	b.cs	7f94 <fwp_write+0x9d0>  // b.hs, b.nlast
    7ac0:	d2800042 	mov	x2, #0x2                   	// #2
    7ac4:	aa1603e1 	mov	x1, x22
    7ac8:	aa1403e0 	mov	x0, x20
    7acc:	97ffeed1 	bl	3610 <buf_put>
    7ad0:	f9401f82 	ldr	x2, [x28, #56]
    7ad4:	f9400263 	ldr	x3, [x19]
    7ad8:	b5fffbc2 	cbnz	x2, 7a50 <fwp_write+0x48c>
    7adc:	d37df2a0 	lsl	x0, x21, #3
    7ae0:	b7f83f03 	tbnz	x3, #63, 82c0 <fwp_write+0xcfc>
    7ae4:	91002261 	add	x1, x19, #0x8
    7ae8:	8b000020 	add	x0, x1, x0
    7aec:	f9400001 	ldr	x1, [x0]
    7af0:	17ffffec 	b	7aa0 <fwp_write+0x4dc>
    7af4:	a9400e62 	ldp	x2, x3, [x19]
    7af8:	b7f83ca3 	tbnz	x3, #63, 828c <fwp_write+0xcc8>
    7afc:	910123f5 	add	x21, sp, #0x48
    7b00:	aa1503e0 	mov	x0, x21
    7b04:	97ffece7 	bl	2ea0 <fwp_fmt_u128>
    7b08:	aa1503e0 	mov	x0, x21
    7b0c:	97ffeb25 	bl	27a0 <strlen@plt>
    7b10:	aa1503e1 	mov	x1, x21
    7b14:	aa0003e2 	mov	x2, x0
    7b18:	17fffed1 	b	765c <fwp_write+0x98>
    7b1c:	fd015be8 	str	d8, [sp, #688]
    7b20:	1e270268 	fmov	s8, w19
    7b24:	fd015fe9 	str	d9, [sp, #696]
    7b28:	1e282100 	fcmp	s8, s8
    7b2c:	54004d26 	b.vs	84d0 <fwp_write+0xf0c>
    7b30:	1e20c101 	fabs	s1, s8
    7b34:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7b38:	1e270000 	fmov	s0, w0
    7b3c:	1e202020 	fcmp	s1, s0
    7b40:	54002c0d 	b.le	80c0 <fwp_write+0xafc>
    7b44:	1e202118 	fcmpe	s8, #0.0
    7b48:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0xa50>
    7b4c:	91256042 	add	x2, x2, #0x958
    7b50:	910123f5 	add	x21, sp, #0x48
    7b54:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7b58:	9134c021 	add	x1, x1, #0xd30
    7b5c:	aa1503e0 	mov	x0, x21
    7b60:	9a81c041 	csel	x1, x2, x1, gt
    7b64:	97ffebbb 	bl	2a50 <strcpy@plt>
    7b68:	aa1503e0 	mov	x0, x21
    7b6c:	97ffeb0d 	bl	27a0 <strlen@plt>
    7b70:	aa1503e1 	mov	x1, x21
    7b74:	aa0003e2 	mov	x2, x0
    7b78:	aa1403e0 	mov	x0, x20
    7b7c:	97ffeea5 	bl	3610 <buf_put>
    7b80:	f9413bf5 	ldr	x21, [sp, #624]
    7b84:	f9413ff6 	ldr	x22, [sp, #632]
    7b88:	f94153fb 	ldr	x27, [sp, #672]
    7b8c:	f94157fc 	ldr	x28, [sp, #680]
    7b90:	fd415be8 	ldr	d8, [sp, #688]
    7b94:	fd415fe9 	ldr	d9, [sp, #696]
    7b98:	17fffeb7 	b	7674 <fwp_write+0xb0>
    7b9c:	f9400276 	ldr	x22, [x19]
    7ba0:	34002e03 	cbz	w3, 8160 <fwp_write+0xb9c>
    7ba4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ba8:	f947f400 	ldr	x0, [x0, #4072]
    7bac:	f94127e2 	ldr	x2, [sp, #584]
    7bb0:	f9400001 	ldr	x1, [x0]
    7bb4:	eb010042 	subs	x2, x2, x1
    7bb8:	d2800001 	mov	x1, #0x0                   	// #0
    7bbc:	540014a1 	b.ne	7e50 <fwp_write+0x88c>  // b.any
    7bc0:	aa1603e2 	mov	x2, x22
    7bc4:	91002261 	add	x1, x19, #0x8
    7bc8:	f9413bf5 	ldr	x21, [sp, #624]
    7bcc:	aa1403e0 	mov	x0, x20
    7bd0:	f9413ff6 	ldr	x22, [sp, #632]
    7bd4:	17ffff00 	b	77d4 <fwp_write+0x210>
    7bd8:	fd015be8 	str	d8, [sp, #688]
    7bdc:	9e670268 	fmov	d8, x19
    7be0:	fd015fe9 	str	d9, [sp, #696]
    7be4:	1e682100 	fcmp	d8, d8
    7be8:	54004746 	b.vs	84d0 <fwp_write+0xf0c>
    7bec:	1e60c101 	fabs	d1, d8
    7bf0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7bf4:	9e670000 	fmov	d0, x0
    7bf8:	910123f5 	add	x21, sp, #0x48
    7bfc:	52800033 	mov	w19, #0x1                   	// #1
    7c00:	1e602020 	fcmp	d1, d0
    7c04:	540001ad 	b.le	7c38 <fwp_write+0x674>
    7c08:	1e602118 	fcmpe	d8, #0.0
    7c0c:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0xa50>
    7c10:	91256042 	add	x2, x2, #0x958
    7c14:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7c18:	9134c021 	add	x1, x1, #0xd30
    7c1c:	aa1503e0 	mov	x0, x21
    7c20:	9a81c041 	csel	x1, x2, x1, gt
    7c24:	97ffeb8b 	bl	2a50 <strcpy@plt>
    7c28:	17ffffd0 	b	7b68 <fwp_write+0x5a4>
    7c2c:	11000673 	add	w19, w19, #0x1
    7c30:	71004a7f 	cmp	w19, #0x12
    7c34:	54003860 	b.eq	8340 <fwp_write+0xd7c>  // b.none
    7c38:	1e604100 	fmov	d0, d8
    7c3c:	2a1303e1 	mov	w1, w19
    7c40:	aa1503e0 	mov	x0, x21
    7c44:	97ffef0f 	bl	3880 <fwp_format_g.constprop.0>
    7c48:	aa1503e0 	mov	x0, x21
    7c4c:	d2800001 	mov	x1, #0x0                   	// #0
    7c50:	97ffeae8 	bl	27f0 <strtod@plt>
    7c54:	1e602100 	fcmp	d8, d0
    7c58:	54fffea1 	b.ne	7c2c <fwp_write+0x668>  // b.any
    7c5c:	aa1503e0 	mov	x0, x21
    7c60:	97ffeee5 	bl	37f4 <fwp_finish_float>
    7c64:	17ffffc1 	b	7b68 <fwp_write+0x5a4>
    7c68:	a9400e62 	ldp	x2, x3, [x19]
    7c6c:	910123f3 	add	x19, sp, #0x48
    7c70:	aa1303e0 	mov	x0, x19
    7c74:	97ffec8b 	bl	2ea0 <fwp_fmt_u128>
    7c78:	17fffe75 	b	764c <fwp_write+0x88>
    7c7c:	f90143f7 	str	x23, [sp, #640]
    7c80:	f90147f8 	str	x24, [sp, #648]
    7c84:	2a1303f8 	mov	w24, w19
    7c88:	f9014bf9 	str	x25, [sp, #656]
    7c8c:	f9014ffa 	str	x26, [sp, #664]
    7c90:	f13ffe7f 	cmp	x19, #0xfff
    7c94:	54000049 	b.ls	7c9c <fwp_write+0x6d8>  // b.plast
    7c98:	b9400278 	ldr	w24, [x19]
    7c9c:	f9400f80 	ldr	x0, [x28, #24]
    7ca0:	2a1803f5 	mov	w21, w24
    7ca4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7ca8:	d37ef6b9 	lsl	x25, x21, #2
    7cac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7cb0:	aa1603e0 	mov	x0, x22
    7cb4:	97ffeabb 	bl	27a0 <strlen@plt>
    7cb8:	aa1603e1 	mov	x1, x22
    7cbc:	aa0003e2 	mov	x2, x0
    7cc0:	aa1403e0 	mov	x0, x20
    7cc4:	97ffee53 	bl	3610 <buf_put>
    7cc8:	f9401780 	ldr	x0, [x28, #40]
    7ccc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7cd0:	7100001f 	cmp	w0, #0x0
    7cd4:	5400068d 	b.le	7da4 <fwp_write+0x7e0>
    7cd8:	91002276 	add	x22, x19, #0x8
    7cdc:	91001ff5 	add	x21, sp, #0x7
    7ce0:	d280001b 	mov	x27, #0x0                   	// #0
    7ce4:	5280041a 	mov	w26, #0x20                  	// #32
    7ce8:	f9401b80 	ldr	x0, [x28, #48]
    7cec:	aa1503e1 	mov	x1, x21
    7cf0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7cf4:	d2800022 	mov	x2, #0x1                   	// #1
    7cf8:	f8786803 	ldr	x3, [x0, x24]
    7cfc:	aa1403e0 	mov	x0, x20
    7d00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7d04:	39001ffa 	strb	w26, [sp, #7]
    7d08:	97ffee42 	bl	3610 <buf_put>
    7d0c:	f13ffeff 	cmp	x23, #0xfff
    7d10:	b9400261 	ldr	w1, [x19]
    7d14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7d18:	7100383f 	cmp	w1, #0xe
    7d1c:	54000160 	b.eq	7d48 <fwp_write+0x784>  // b.none
    7d20:	7100403f 	cmp	w1, #0x10
    7d24:	54001a60 	b.eq	8070 <fwp_write+0xaac>  // b.none
    7d28:	7100283f 	cmp	w1, #0xa
    7d2c:	54002aa0 	b.eq	8280 <fwp_write+0xcbc>  // b.none
    7d30:	540014ac 	b.gt	7fc4 <fwp_write+0xa00>
    7d34:	71000c3f 	cmp	w1, #0x3
    7d38:	540029ac 	b.gt	826c <fwp_write+0xca8>
    7d3c:	d37ffee0 	lsr	x0, x23, #63
    7d40:	37f814a1 	tbnz	w1, #31, 7fd4 <fwp_write+0xa10>
    7d44:	d503201f 	nop
    7d48:	34001460 	cbz	w0, 7fd4 <fwp_write+0xa10>
    7d4c:	52800503 	mov	w3, #0x28                  	// #40
    7d50:	aa1503e1 	mov	x1, x21
    7d54:	aa1403e0 	mov	x0, x20
    7d58:	d2800022 	mov	x2, #0x1                   	// #1
    7d5c:	39001fe3 	strb	w3, [sp, #7]
    7d60:	97ffee2c 	bl	3610 <buf_put>
    7d64:	aa1303e2 	mov	x2, x19
    7d68:	aa1703e1 	mov	x1, x23
    7d6c:	aa1403e0 	mov	x0, x20
    7d70:	52800003 	mov	w3, #0x0                   	// #0
    7d74:	97fffe14 	bl	75c4 <fwp_write>
    7d78:	52800523 	mov	w3, #0x29                  	// #41
    7d7c:	aa1503e1 	mov	x1, x21
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	d2800022 	mov	x2, #0x1                   	// #1
    7d88:	39001fe3 	strb	w3, [sp, #7]
    7d8c:	97ffee21 	bl	3610 <buf_put>
    7d90:	f9401780 	ldr	x0, [x28, #40]
    7d94:	9100077b 	add	x27, x27, #0x1
    7d98:	b8796800 	ldr	w0, [x0, x25]
    7d9c:	6b1b001f 	cmp	w0, w27
    7da0:	54fffa4c 	b.gt	7ce8 <fwp_write+0x724>
    7da4:	f9413bf5 	ldr	x21, [sp, #624]
    7da8:	f9413ff6 	ldr	x22, [sp, #632]
    7dac:	f94143f7 	ldr	x23, [sp, #640]
    7db0:	f94147f8 	ldr	x24, [sp, #648]
    7db4:	f9414bf9 	ldr	x25, [sp, #656]
    7db8:	f9414ffa 	ldr	x26, [sp, #664]
    7dbc:	f94153fb 	ldr	x27, [sp, #672]
    7dc0:	f94157fc 	ldr	x28, [sp, #680]
    7dc4:	17fffe2c 	b	7674 <fwp_write+0xb0>
    7dc8:	52800783 	mov	w3, #0x3c                  	// #60
    7dcc:	91001ff3 	add	x19, sp, #0x7
    7dd0:	aa1303e1 	mov	x1, x19
    7dd4:	d2800022 	mov	x2, #0x1                   	// #1
    7dd8:	aa1403e0 	mov	x0, x20
    7ddc:	39001fe3 	strb	w3, [sp, #7]
    7de0:	97ffee0c 	bl	3610 <buf_put>
    7de4:	f9400795 	ldr	x21, [x28, #8]
    7de8:	aa1503e0 	mov	x0, x21
    7dec:	97ffea6d 	bl	27a0 <strlen@plt>
    7df0:	aa1503e1 	mov	x1, x21
    7df4:	aa0003e2 	mov	x2, x0
    7df8:	aa1403e0 	mov	x0, x20
    7dfc:	97ffee05 	bl	3610 <buf_put>
    7e00:	528007c3 	mov	w3, #0x3e                  	// #62
    7e04:	aa1303e1 	mov	x1, x19
    7e08:	aa1403e0 	mov	x0, x20
    7e0c:	d2800022 	mov	x2, #0x1                   	// #1
    7e10:	39001fe3 	strb	w3, [sp, #7]
    7e14:	17fffe13 	b	7660 <fwp_write+0x9c>
    7e18:	f100067f 	cmp	x19, #0x1
    7e1c:	540025a0 	b.eq	82d0 <fwp_write+0xd0c>  // b.none
    7e20:	b100067f 	cmn	x19, #0x1
    7e24:	54002bc0 	b.eq	839c <fwp_write+0xdd8>  // b.none
    7e28:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7e2c:	9134e021 	add	x1, x1, #0xd38
    7e30:	d2800022 	mov	x2, #0x1                   	// #1
    7e34:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7e38:	f947f400 	ldr	x0, [x0, #4072]
    7e3c:	f94127e4 	ldr	x4, [sp, #584]
    7e40:	f9400003 	ldr	x3, [x0]
    7e44:	eb030084 	subs	x4, x4, x3
    7e48:	d2800003 	mov	x3, #0x0                   	// #0
    7e4c:	54ffebe0 	b.eq	7bc8 <fwp_write+0x604>  // b.none
    7e50:	f90143f7 	str	x23, [sp, #640]
    7e54:	f90147f8 	str	x24, [sp, #648]
    7e58:	f9014bf9 	str	x25, [sp, #656]
    7e5c:	f9014ffa 	str	x26, [sp, #664]
    7e60:	fd015be8 	str	d8, [sp, #688]
    7e64:	fd015fe9 	str	d9, [sp, #696]
    7e68:	97ffeaaa 	bl	2910 <__stack_chk_fail@plt>
    7e6c:	52800b63 	mov	w3, #0x5b                  	// #91
    7e70:	91001ff5 	add	x21, sp, #0x7
    7e74:	aa1503e1 	mov	x1, x21
    7e78:	aa1403e0 	mov	x0, x20
    7e7c:	d2800022 	mov	x2, #0x1                   	// #1
    7e80:	d0000016 	adrp	x22, 9000 <fwp_main_thread+0xa50>
    7e84:	913762d6 	add	x22, x22, #0xdd8
    7e88:	39001fe3 	strb	w3, [sp, #7]
    7e8c:	97ffede1 	bl	3610 <buf_put>
    7e90:	b4000273 	cbz	x19, 7edc <fwp_write+0x918>
    7e94:	f9400661 	ldr	x1, [x19, #8]
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	f9401f82 	ldr	x2, [x28, #56]
    7ea0:	52800003 	mov	w3, #0x0                   	// #0
    7ea4:	97fffdc8 	bl	75c4 <fwp_write>
    7ea8:	f9400a73 	ldr	x19, [x19, #16]
    7eac:	b4000193 	cbz	x19, 7edc <fwp_write+0x918>
    7eb0:	aa1603e1 	mov	x1, x22
    7eb4:	aa1403e0 	mov	x0, x20
    7eb8:	d2800042 	mov	x2, #0x2                   	// #2
    7ebc:	97ffedd5 	bl	3610 <buf_put>
    7ec0:	f9400661 	ldr	x1, [x19, #8]
    7ec4:	aa1403e0 	mov	x0, x20
    7ec8:	f9401f82 	ldr	x2, [x28, #56]
    7ecc:	52800003 	mov	w3, #0x0                   	// #0
    7ed0:	97fffdbd 	bl	75c4 <fwp_write>
    7ed4:	f9400a73 	ldr	x19, [x19, #16]
    7ed8:	b5fffed3 	cbnz	x19, 7eb0 <fwp_write+0x8ec>
    7edc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ee0:	aa1503e1 	mov	x1, x21
    7ee4:	aa1403e0 	mov	x0, x20
    7ee8:	d2800022 	mov	x2, #0x1                   	// #1
    7eec:	39001fe3 	strb	w3, [sp, #7]
    7ef0:	17fffddc 	b	7660 <fwp_write+0x9c>
    7ef4:	aa1403e0 	mov	x0, x20
    7ef8:	d0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    7efc:	d28000c2 	mov	x2, #0x6                   	// #6
    7f00:	91372021 	add	x1, x1, #0xdc8
    7f04:	97ffedc3 	bl	3610 <buf_put>
    7f08:	f9400260 	ldr	x0, [x19]
    7f0c:	b40004c0 	cbz	x0, 7fa4 <fwp_write+0x9e0>
    7f10:	910123f5 	add	x21, sp, #0x48
    7f14:	91002276 	add	x22, x19, #0x8
    7f18:	f90143f7 	str	x23, [sp, #640]
    7f1c:	d2800017 	mov	x23, #0x0                   	// #0
    7f20:	f90147f8 	str	x24, [sp, #648]
    7f24:	d0000018 	adrp	x24, 9000 <fwp_main_thread+0xa50>
    7f28:	91374318 	add	x24, x24, #0xdd0
    7f2c:	f9014bf9 	str	x25, [sp, #656]
    7f30:	d0000019 	adrp	x25, 9000 <fwp_main_thread+0xa50>
    7f34:	91376339 	add	x25, x25, #0xdd8
    7f38:	f9014ffa 	str	x26, [sp, #664]
    7f3c:	14000005 	b	7f50 <fwp_write+0x98c>
    7f40:	aa1903e1 	mov	x1, x25
    7f44:	aa1403e0 	mov	x0, x20
    7f48:	d2800042 	mov	x2, #0x2                   	// #2
    7f4c:	97ffedb1 	bl	3610 <buf_put>
    7f50:	38776ac5 	ldrb	w5, [x22, x23]
    7f54:	d2804003 	mov	x3, #0x200                 	// #512
    7f58:	aa1803e4 	mov	x4, x24
    7f5c:	aa0303e1 	mov	x1, x3
    7f60:	52800042 	mov	w2, #0x2                   	// #2
    7f64:	aa1503e0 	mov	x0, x21
    7f68:	910006f7 	add	x23, x23, #0x1
    7f6c:	97ffea45 	bl	2880 <__snprintf_chk@plt>
    7f70:	aa1503e0 	mov	x0, x21
    7f74:	97ffea0b 	bl	27a0 <strlen@plt>
    7f78:	aa1503e1 	mov	x1, x21
    7f7c:	aa0003e2 	mov	x2, x0
    7f80:	aa1403e0 	mov	x0, x20
    7f84:	97ffeda3 	bl	3610 <buf_put>
    7f88:	f9400260 	ldr	x0, [x19]
    7f8c:	eb17001f 	cmp	x0, x23
    7f90:	54fffd88 	b.hi	7f40 <fwp_write+0x97c>  // b.pmore
    7f94:	f94143f7 	ldr	x23, [sp, #640]
    7f98:	f94147f8 	ldr	x24, [sp, #648]
    7f9c:	f9414bf9 	ldr	x25, [sp, #656]
    7fa0:	f9414ffa 	ldr	x26, [sp, #664]
    7fa4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7fa8:	aa1403e0 	mov	x0, x20
    7fac:	91001fe1 	add	x1, sp, #0x7
    7fb0:	d2800022 	mov	x2, #0x1                   	// #1
    7fb4:	39001fe3 	strb	w3, [sp, #7]
    7fb8:	17fffdaa 	b	7660 <fwp_write+0x9c>
    7fbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7fc0:	17fffe45 	b	78d4 <fwp_write+0x310>
    7fc4:	f10002ff 	cmp	x23, #0x0
    7fc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7fcc:	71002c3f 	cmp	w1, #0xb
    7fd0:	54ffebc0 	b.eq	7d48 <fwp_write+0x784>  // b.none
    7fd4:	aa1303e2 	mov	x2, x19
    7fd8:	aa1703e1 	mov	x1, x23
    7fdc:	aa1403e0 	mov	x0, x20
    7fe0:	52800003 	mov	w3, #0x0                   	// #0
    7fe4:	97fffd78 	bl	75c4 <fwp_write>
    7fe8:	17ffff6a 	b	7d90 <fwp_write+0x7cc>
    7fec:	aa1403e0 	mov	x0, x20
    7ff0:	91001fe1 	add	x1, sp, #0x7
    7ff4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ff8:	d2800022 	mov	x2, #0x1                   	// #1
    7ffc:	17fffe39 	b	78e0 <fwp_write+0x31c>
    8000:	a9400281 	ldp	x1, x0, [x20]
    8004:	91000800 	add	x0, x0, #0x2
    8008:	8b160000 	add	x0, x0, x22
    800c:	f9000680 	str	x0, [x20, #8]
    8010:	3820683f 	strb	wzr, [x1, x0]
    8014:	f9413bf5 	ldr	x21, [sp, #624]
    8018:	f9413ff6 	ldr	x22, [sp, #632]
    801c:	f94153fb 	ldr	x27, [sp, #672]
    8020:	f94157fc 	ldr	x28, [sp, #680]
    8024:	17fffd94 	b	7674 <fwp_write+0xb0>
    8028:	f9400f80 	ldr	x0, [x28, #24]
    802c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8030:	aa1b03e0 	mov	x0, x27
    8034:	97ffe9db 	bl	27a0 <strlen@plt>
    8038:	aa1b03e1 	mov	x1, x27
    803c:	aa0003e2 	mov	x2, x0
    8040:	aa1403e0 	mov	x0, x20
    8044:	97ffed73 	bl	3610 <buf_put>
    8048:	aa1903e1 	mov	x1, x25
    804c:	aa1403e0 	mov	x0, x20
    8050:	d2800062 	mov	x2, #0x3                   	// #3
    8054:	97ffed6f 	bl	3610 <buf_put>
    8058:	17fffe11 	b	789c <fwp_write+0x2d8>
    805c:	aa1a03e1 	mov	x1, x26
    8060:	aa1403e0 	mov	x0, x20
    8064:	d2800042 	mov	x2, #0x2                   	// #2
    8068:	97ffed6a 	bl	3610 <buf_put>
    806c:	17fffe0a 	b	7894 <fwp_write+0x2d0>
    8070:	f9400660 	ldr	x0, [x19, #8]
    8074:	b4fffb00 	cbz	x0, 7fd4 <fwp_write+0xa10>
    8078:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    807c:	9137c021 	add	x1, x1, #0xdf0
    8080:	97ffea44 	bl	2990 <strcmp@plt>
    8084:	7100001f 	cmp	w0, #0x0
    8088:	1a9f07e0 	cset	w0, ne	// ne = any
    808c:	17ffff2f 	b	7d48 <fwp_write+0x784>
    8090:	aa1403e0 	mov	x0, x20
    8094:	d2800042 	mov	x2, #0x2                   	// #2
    8098:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    809c:	9137a021 	add	x1, x1, #0xde8
    80a0:	97ffed5c 	bl	3610 <buf_put>
    80a4:	91004261 	add	x1, x19, #0x10
    80a8:	aa1403e0 	mov	x0, x20
    80ac:	f9402382 	ldr	x2, [x28, #64]
    80b0:	52800003 	mov	w3, #0x0                   	// #0
    80b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    80b8:	97fffd43 	bl	75c4 <fwp_write>
    80bc:	17fffd9d 	b	7730 <fwp_write+0x16c>
    80c0:	1e22c109 	fcvt	d9, s8
    80c4:	910123f5 	add	x21, sp, #0x48
    80c8:	52800033 	mov	w19, #0x1                   	// #1
    80cc:	d503201f 	nop
    80d0:	1e604120 	fmov	d0, d9
    80d4:	2a1303e1 	mov	w1, w19
    80d8:	aa1503e0 	mov	x0, x21
    80dc:	97ffede9 	bl	3880 <fwp_format_g.constprop.0>
    80e0:	aa1503e0 	mov	x0, x21
    80e4:	d2800001 	mov	x1, #0x0                   	// #0
    80e8:	97ffea36 	bl	29c0 <strtof@plt>
    80ec:	1e202100 	fcmp	s8, s0
    80f0:	54ffdb60 	b.eq	7c5c <fwp_write+0x698>  // b.none
    80f4:	11000673 	add	w19, w19, #0x1
    80f8:	71002a7f 	cmp	w19, #0xa
    80fc:	54fffea1 	b.ne	80d0 <fwp_write+0xb0c>  // b.any
    8100:	1e604120 	fmov	d0, d9
    8104:	aa1503e0 	mov	x0, x21
    8108:	52800121 	mov	w1, #0x9                   	// #9
    810c:	97ffeddd 	bl	3880 <fwp_format_g.constprop.0>
    8110:	17fffed3 	b	7c5c <fwp_write+0x698>
    8114:	d37ef6a1 	lsl	x1, x21, #2
    8118:	b7f81563 	tbnz	x3, #63, 83c4 <fwp_write+0xe00>
    811c:	91002263 	add	x3, x19, #0x8
    8120:	8b010061 	add	x1, x3, x1
    8124:	b9400023 	ldr	w3, [x1]
    8128:	7100081f 	cmp	w0, #0x2
    812c:	2a0303e1 	mov	w1, w3
    8130:	93407c63 	sxtw	x3, w3
    8134:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8138:	17fffe5a 	b	7aa0 <fwp_write+0x4dc>
    813c:	d37ffaa1 	lsl	x1, x21, #1
    8140:	b7f81363 	tbnz	x3, #63, 83ac <fwp_write+0xde8>
    8144:	91002263 	add	x3, x19, #0x8
    8148:	8b010061 	add	x1, x3, x1
    814c:	79400021 	ldrh	w1, [x1]
    8150:	7100041f 	cmp	w0, #0x1
    8154:	93403c23 	sxth	x3, w1
    8158:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    815c:	17fffe51 	b	7aa0 <fwp_write+0x4dc>
    8160:	52800443 	mov	w3, #0x22                  	// #34
    8164:	91001ff5 	add	x21, sp, #0x7
    8168:	91002273 	add	x19, x19, #0x8
    816c:	aa1503e1 	mov	x1, x21
    8170:	aa1403e0 	mov	x0, x20
    8174:	d2800022 	mov	x2, #0x1                   	// #1
    8178:	39001fe3 	strb	w3, [sp, #7]
    817c:	f90143f7 	str	x23, [sp, #640]
    8180:	8b160277 	add	x23, x19, x22
    8184:	f90147f8 	str	x24, [sp, #648]
    8188:	97ffed22 	bl	3610 <buf_put>
    818c:	b4000696 	cbz	x22, 825c <fwp_write+0xc98>
    8190:	b0000018 	adrp	x24, 9000 <fwp_main_thread+0xa50>
    8194:	91366318 	add	x24, x24, #0xd98
    8198:	f9014bf9 	str	x25, [sp, #656]
    819c:	b0000019 	adrp	x25, 9000 <fwp_main_thread+0xa50>
    81a0:	9136e339 	add	x25, x25, #0xdb8
    81a4:	f9014ffa 	str	x26, [sp, #664]
    81a8:	1400000d 	b	81dc <fwp_write+0xc18>
    81ac:	710024bf 	cmp	w5, #0x9
    81b0:	54000460 	b.eq	823c <fwp_write+0xc78>  // b.none
    81b4:	710028bf 	cmp	w5, #0xa
    81b8:	54000a61 	b.ne	8304 <fwp_write+0xd40>  // b.any
    81bc:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    81c0:	aa1403e0 	mov	x0, x20
    81c4:	9136a021 	add	x1, x1, #0xda8
    81c8:	d2800042 	mov	x2, #0x2                   	// #2
    81cc:	97ffed11 	bl	3610 <buf_put>
    81d0:	91000673 	add	x19, x19, #0x1
    81d4:	eb17027f 	cmp	x19, x23
    81d8:	540003e0 	b.eq	8254 <fwp_write+0xc90>  // b.none
    81dc:	39400265 	ldrb	w5, [x19]
    81e0:	710034bf 	cmp	w5, #0xd
    81e4:	54000180 	b.eq	8214 <fwp_write+0xc50>  // b.none
    81e8:	54fffe29 	b.ls	81ac <fwp_write+0xbe8>  // b.plast
    81ec:	710088bf 	cmp	w5, #0x22
    81f0:	540001c0 	b.eq	8228 <fwp_write+0xc64>  // b.none
    81f4:	710170bf 	cmp	w5, #0x5c
    81f8:	54000741 	b.ne	82e0 <fwp_write+0xd1c>  // b.any
    81fc:	aa1403e0 	mov	x0, x20
    8200:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    8204:	d2800042 	mov	x2, #0x2                   	// #2
    8208:	91368021 	add	x1, x1, #0xda0
    820c:	97ffed01 	bl	3610 <buf_put>
    8210:	17fffff0 	b	81d0 <fwp_write+0xc0c>
    8214:	aa1903e1 	mov	x1, x25
    8218:	aa1403e0 	mov	x0, x20
    821c:	d2800042 	mov	x2, #0x2                   	// #2
    8220:	97ffecfc 	bl	3610 <buf_put>
    8224:	17ffffeb 	b	81d0 <fwp_write+0xc0c>
    8228:	aa1803e1 	mov	x1, x24
    822c:	aa1403e0 	mov	x0, x20
    8230:	d2800042 	mov	x2, #0x2                   	// #2
    8234:	97ffecf7 	bl	3610 <buf_put>
    8238:	17ffffe6 	b	81d0 <fwp_write+0xc0c>
    823c:	aa1403e0 	mov	x0, x20
    8240:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    8244:	d2800042 	mov	x2, #0x2                   	// #2
    8248:	9136c021 	add	x1, x1, #0xdb0
    824c:	97ffecf1 	bl	3610 <buf_put>
    8250:	17ffffe0 	b	81d0 <fwp_write+0xc0c>
    8254:	f9414bf9 	ldr	x25, [sp, #656]
    8258:	f9414ffa 	ldr	x26, [sp, #664]
    825c:	aa1503e1 	mov	x1, x21
    8260:	aa1403e0 	mov	x0, x20
    8264:	52800443 	mov	w3, #0x22                  	// #34
    8268:	17fffd9d 	b	78dc <fwp_write+0x318>
    826c:	7100103f 	cmp	w1, #0x4
    8270:	54ffeb21 	b.ne	7fd4 <fwp_write+0xa10>  // b.any
    8274:	f94006e0 	ldr	x0, [x23, #8]
    8278:	d37ffc00 	lsr	x0, x0, #63
    827c:	17fffeb3 	b	7d48 <fwp_write+0x784>
    8280:	710002ff 	cmp	w23, #0x0
    8284:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8288:	17fffeb0 	b	7d48 <fwp_write+0x784>
    828c:	528005a1 	mov	w1, #0x2d                  	// #45
    8290:	eb0203e2 	negs	x2, x2
    8294:	da0303e3 	ngc	x3, x3
    8298:	910127e0 	add	x0, sp, #0x49
    829c:	910123f5 	add	x21, sp, #0x48
    82a0:	390123e1 	strb	w1, [sp, #72]
    82a4:	97ffeaff 	bl	2ea0 <fwp_fmt_u128>
    82a8:	17fffe18 	b	7b08 <fwp_write+0x544>
    82ac:	d37ceea1 	lsl	x1, x21, #4
    82b0:	b7f810a3 	tbnz	x3, #63, 84c4 <fwp_write+0xf00>
    82b4:	91002260 	add	x0, x19, #0x8
    82b8:	8b010001 	add	x1, x0, x1
    82bc:	17fffdf9 	b	7aa0 <fwp_write+0x4dc>
    82c0:	f9400a61 	ldr	x1, [x19, #16]
    82c4:	8b010000 	add	x0, x0, x1
    82c8:	f9400001 	ldr	x1, [x0]
    82cc:	17fffdf5 	b	7aa0 <fwp_write+0x4dc>
    82d0:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    82d4:	d2800042 	mov	x2, #0x2                   	// #2
    82d8:	91350021 	add	x1, x1, #0xd40
    82dc:	17fffed6 	b	7e34 <fwp_write+0x870>
    82e0:	7101fcbf 	cmp	w5, #0x7f
    82e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    82e8:	540000e9 	b.ls	8304 <fwp_write+0xd40>  // b.plast
    82ec:	aa1503e1 	mov	x1, x21
    82f0:	aa1403e0 	mov	x0, x20
    82f4:	d2800022 	mov	x2, #0x1                   	// #1
    82f8:	39001fe5 	strb	w5, [sp, #7]
    82fc:	97ffecc5 	bl	3610 <buf_put>
    8300:	17ffffb4 	b	81d0 <fwp_write+0xc0c>
    8304:	d2800203 	mov	x3, #0x10                  	// #16
    8308:	b0000004 	adrp	x4, 9000 <fwp_main_thread+0xa50>
    830c:	aa0303e1 	mov	x1, x3
    8310:	91370084 	add	x4, x4, #0xdc0
    8314:	910123f6 	add	x22, sp, #0x48
    8318:	52800042 	mov	w2, #0x2                   	// #2
    831c:	aa1603e0 	mov	x0, x22
    8320:	97ffe958 	bl	2880 <__snprintf_chk@plt>
    8324:	aa1603e0 	mov	x0, x22
    8328:	97ffe91e 	bl	27a0 <strlen@plt>
    832c:	aa1603e1 	mov	x1, x22
    8330:	aa0003e2 	mov	x2, x0
    8334:	aa1403e0 	mov	x0, x20
    8338:	97ffecb6 	bl	3610 <buf_put>
    833c:	17ffffa5 	b	81d0 <fwp_write+0xc0c>
    8340:	1e604100 	fmov	d0, d8
    8344:	aa1503e0 	mov	x0, x21
    8348:	52800221 	mov	w1, #0x11                  	// #17
    834c:	97ffed4d 	bl	3880 <fwp_format_g.constprop.0>
    8350:	17fffe43 	b	7c5c <fwp_write+0x698>
    8354:	b9401040 	ldr	w0, [x2, #16]
    8358:	350003c0 	cbnz	w0, 83d0 <fwp_write+0xe0c>
    835c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8360:	f947f400 	ldr	x0, [x0, #4072]
    8364:	f94127e2 	ldr	x2, [sp, #584]
    8368:	f9400001 	ldr	x1, [x0]
    836c:	eb010042 	subs	x2, x2, x1
    8370:	d2800001 	mov	x1, #0x0                   	// #0
    8374:	54ffd721 	b.ne	7e58 <fwp_write+0x894>  // b.any
    8378:	f9413bf5 	ldr	x21, [sp, #624]
    837c:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    8380:	f9413ff6 	ldr	x22, [sp, #632]
    8384:	aa1403e0 	mov	x0, x20
    8388:	f94143f7 	ldr	x23, [sp, #640]
    838c:	91384021 	add	x1, x1, #0xe10
    8390:	f94147f8 	ldr	x24, [sp, #648]
    8394:	d2800042 	mov	x2, #0x2                   	// #2
    8398:	17fffd0f 	b	77d4 <fwp_write+0x210>
    839c:	b0000001 	adrp	x1, 9000 <fwp_main_thread+0xa50>
    83a0:	d2800042 	mov	x2, #0x2                   	// #2
    83a4:	91352021 	add	x1, x1, #0xd48
    83a8:	17fffea3 	b	7e34 <fwp_write+0x870>
    83ac:	f9400a63 	ldr	x3, [x19, #16]
    83b0:	8b030021 	add	x1, x1, x3
    83b4:	17ffff66 	b	814c <fwp_write+0xb88>
    83b8:	f9400a61 	ldr	x1, [x19, #16]
    83bc:	8b0102a1 	add	x1, x21, x1
    83c0:	17fffdb4 	b	7a90 <fwp_write+0x4cc>
    83c4:	f9400a63 	ldr	x3, [x19, #16]
    83c8:	8b030021 	add	x1, x1, x3
    83cc:	17ffff56 	b	8124 <fwp_write+0xb60>
    83d0:	b9404840 	ldr	w0, [x2, #72]
    83d4:	91001ff5 	add	x21, sp, #0x7
    83d8:	34ffa380 	cbz	w0, 7848 <fwp_write+0x284>
    83dc:	52800503 	mov	w3, #0x28                  	// #40
    83e0:	aa1403e0 	mov	x0, x20
    83e4:	aa1503e1 	mov	x1, x21
    83e8:	d2800022 	mov	x2, #0x1                   	// #1
    83ec:	39001fe3 	strb	w3, [sp, #7]
    83f0:	97ffec88 	bl	3610 <buf_put>
    83f4:	b9401380 	ldr	w0, [x28, #16]
    83f8:	52800038 	mov	w24, #0x1                   	// #1
    83fc:	7100001f 	cmp	w0, #0x0
    8400:	54ffa38c 	b.gt	7870 <fwp_write+0x2ac>
    8404:	17fffd33 	b	78d0 <fwp_write+0x30c>
    8408:	f9014bf9 	str	x25, [sp, #656]
    840c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12730>
    8410:	f9014ffa 	str	x26, [sp, #664]
    8414:	f9400676 	ldr	x22, [x19, #8]
    8418:	910aa333 	add	x19, x25, #0x2a8
    841c:	91002273 	add	x19, x19, #0x8
    8420:	937ffed8 	asr	x24, x22, #63
    8424:	aa1802c0 	orr	x0, x22, x24
    8428:	b5000320 	cbnz	x0, 848c <fwp_write+0xec8>
    842c:	110006b5 	add	w21, w21, #0x1
    8430:	710016bf 	cmp	w21, #0x5
    8434:	54ffffc1 	b.ne	842c <fwp_write+0xe68>  // b.any
    8438:	b7f80578 	tbnz	x24, #63, 84e4 <fwp_write+0xf20>
    843c:	910023f3 	add	x19, sp, #0x8
    8440:	aa1603e2 	mov	x2, x22
    8444:	aa1303e0 	mov	x0, x19
    8448:	d2800003 	mov	x3, #0x0                   	// #0
    844c:	97ffea95 	bl	2ea0 <fwp_fmt_u128>
    8450:	910123f5 	add	x21, sp, #0x48
    8454:	b0000003 	adrp	x3, 9000 <fwp_main_thread+0xa50>
    8458:	aa1303e4 	mov	x4, x19
    845c:	aa1503e0 	mov	x0, x21
    8460:	91382063 	add	x3, x3, #0xe08
    8464:	d2804002 	mov	x2, #0x200                 	// #512
    8468:	52800041 	mov	w1, #0x2                   	// #2
    846c:	97ffe8d1 	bl	27b0 <__sprintf_chk@plt>
    8470:	aa1503e0 	mov	x0, x21
    8474:	97ffe8cb 	bl	27a0 <strlen@plt>
    8478:	aa1503e1 	mov	x1, x21
    847c:	aa0003e2 	mov	x2, x0
    8480:	aa1403e0 	mov	x0, x20
    8484:	97ffec63 	bl	3610 <buf_put>
    8488:	17fffe47 	b	7da4 <fwp_write+0x7e0>
    848c:	f9400277 	ldr	x23, [x19]
    8490:	aa1603e0 	mov	x0, x22
    8494:	aa1803e1 	mov	x1, x24
    8498:	aa1703e2 	mov	x2, x23
    849c:	937ffefa 	asr	x26, x23, #63
    84a0:	aa1a03e3 	mov	x3, x26
    84a4:	9400040f 	bl	94e0 <__modti3>
    84a8:	aa010000 	orr	x0, x0, x1
    84ac:	b40002c0 	cbz	x0, 8504 <fwp_write+0xf40>
    84b0:	110006b5 	add	w21, w21, #0x1
    84b4:	91004273 	add	x19, x19, #0x10
    84b8:	710016bf 	cmp	w21, #0x5
    84bc:	54fffe81 	b.ne	848c <fwp_write+0xec8>  // b.any
    84c0:	17ffffde 	b	8438 <fwp_write+0xe74>
    84c4:	f9400a60 	ldr	x0, [x19, #16]
    84c8:	8b000021 	add	x1, x1, x0
    84cc:	17fffd75 	b	7aa0 <fwp_write+0x4dc>
    84d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    84d4:	910123f5 	add	x21, sp, #0x48
    84d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    84dc:	b9004be0 	str	w0, [sp, #72]
    84e0:	17fffda2 	b	7b68 <fwp_write+0x5a4>
    84e4:	528005a1 	mov	w1, #0x2d                  	// #45
    84e8:	eb1603e2 	negs	x2, x22
    84ec:	da1803e3 	ngc	x3, x24
    84f0:	910027e0 	add	x0, sp, #0x9
    84f4:	910023f3 	add	x19, sp, #0x8
    84f8:	390023e1 	strb	w1, [sp, #8]
    84fc:	97ffea69 	bl	2ea0 <fwp_fmt_u128>
    8500:	17ffffd4 	b	8450 <fwp_write+0xe8c>
    8504:	aa1703e2 	mov	x2, x23
    8508:	aa1a03e3 	mov	x3, x26
    850c:	aa1603e0 	mov	x0, x22
    8510:	aa1803e1 	mov	x1, x24
    8514:	94000313 	bl	9160 <__divti3>
    8518:	aa0003e2 	mov	x2, x0
    851c:	aa0103e3 	mov	x3, x1
    8520:	b7f80201 	tbnz	x1, #63, 8560 <fwp_write+0xf9c>
    8524:	910023f3 	add	x19, sp, #0x8
    8528:	aa1303e0 	mov	x0, x19
    852c:	97ffea5d 	bl	2ea0 <fwp_fmt_u128>
    8530:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8534:	910aa339 	add	x25, x25, #0x2a8
    8538:	910123f5 	add	x21, sp, #0x48
    853c:	aa1303e4 	mov	x4, x19
    8540:	aa1503e0 	mov	x0, x21
    8544:	b0000003 	adrp	x3, 9000 <fwp_main_thread+0xa50>
    8548:	f8616b25 	ldr	x5, [x25, x1]
    854c:	91380063 	add	x3, x3, #0xe00
    8550:	d2804002 	mov	x2, #0x200                 	// #512
    8554:	52800041 	mov	w1, #0x2                   	// #2
    8558:	97ffe896 	bl	27b0 <__sprintf_chk@plt>
    855c:	17ffffc5 	b	8470 <fwp_write+0xeac>
    8560:	528005a4 	mov	w4, #0x2d                  	// #45
    8564:	eb0003e2 	negs	x2, x0
    8568:	da0103e3 	ngc	x3, x1
    856c:	910027e0 	add	x0, sp, #0x9
    8570:	910023f3 	add	x19, sp, #0x8
    8574:	390023e4 	strb	w4, [sp, #8]
    8578:	97ffea4a 	bl	2ea0 <fwp_fmt_u128>
    857c:	17ffffed 	b	8530 <fwp_write+0xf6c>
    8580:	f9013bf5 	str	x21, [sp, #624]
    8584:	f9013ff6 	str	x22, [sp, #632]
    8588:	f90143f7 	str	x23, [sp, #640]
    858c:	f90147f8 	str	x24, [sp, #648]
    8590:	f9014bf9 	str	x25, [sp, #656]
    8594:	f9014ffa 	str	x26, [sp, #664]
    8598:	f90153fb 	str	x27, [sp, #672]
    859c:	f90157fc 	str	x28, [sp, #680]
    85a0:	fd015be8 	str	d8, [sp, #688]
    85a4:	fd015fe9 	str	d9, [sp, #696]
    85a8:	97ffe8da 	bl	2910 <__stack_chk_fail@plt>
    85ac:	d503201f 	nop

00000000000085b0 <fwp_main_thread>:
    85b0:	d105c3ff 	sub	sp, sp, #0x170
    85b4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    85b8:	f947f400 	ldr	x0, [x0, #4072]
    85bc:	a9117bfd 	stp	x29, x30, [sp, #272]
    85c0:	910443fd 	add	x29, sp, #0x110
    85c4:	a91253f3 	stp	x19, x20, [sp, #288]
    85c8:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    85cc:	91170261 	add	x1, x19, #0x5c0
    85d0:	a9135bf5 	stp	x21, x22, [sp, #304]
    85d4:	a91463f7 	stp	x23, x24, [sp, #320]
    85d8:	b953a421 	ldr	w1, [x1, #5028]
    85dc:	f9400002 	ldr	x2, [x0]
    85e0:	f90087e2 	str	x2, [sp, #264]
    85e4:	d2800002 	mov	x2, #0x0                   	// #0
    85e8:	34000e81 	cbz	w1, 87b8 <fwp_main_thread+0x208>
    85ec:	91170260 	add	x0, x19, #0x5c0
    85f0:	b953a800 	ldr	w0, [x0, #5032]
    85f4:	35000da0 	cbnz	w0, 87a8 <fwp_main_thread+0x1f8>
    85f8:	900000d5 	adrp	x21, 20000 <__data_start>
    85fc:	900000c2 	adrp	x2, 20000 <__data_start>
    8600:	910182b4 	add	x20, x21, #0x60
    8604:	910f8042 	add	x2, x2, #0x3e0
    8608:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    860c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8610:	9100c3f7 	add	x23, sp, #0x30
    8614:	910063f6 	add	x22, sp, #0x18
    8618:	aa1703e0 	mov	x0, x23
    861c:	d2800001 	mov	x1, #0x0                   	// #0
    8620:	a9018e96 	stp	x22, x3, [x20, #24]
    8624:	f9001be2 	str	x2, [sp, #48]
    8628:	b9003bff 	str	wzr, [sp, #56]
    862c:	f90023e4 	str	x4, [sp, #64]
    8630:	97ffe850 	bl	2770 <sigaltstack@plt>
    8634:	35000220 	cbnz	w0, 8678 <fwp_main_thread+0xc8>
    8638:	4f000400 	movi	v0.4s, #0x0
    863c:	9101e3e0 	add	x0, sp, #0x78
    8640:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8644:	9103c021 	add	x1, x1, #0xf0
    8648:	f9003be1 	str	x1, [sp, #112]
    864c:	52800082 	mov	w2, #0x4                   	// #4
    8650:	72a10002 	movk	w2, #0x800, lsl #16
    8654:	9101c3f8 	add	x24, sp, #0x70
    8658:	3d802000 	str	q0, [x0, #128]
    865c:	b900fbe2 	str	w2, [sp, #248]
    8660:	ad000000 	stp	q0, q0, [x0]
    8664:	ad010000 	stp	q0, q0, [x0, #32]
    8668:	ad020000 	stp	q0, q0, [x0, #64]
    866c:	ad030000 	stp	q0, q0, [x0, #96]
    8670:	97ffe898 	bl	28d0 <sigemptyset@plt>
    8674:	340000c0 	cbz	w0, 868c <fwp_main_thread+0xdc>
    8678:	b0000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    867c:	91388000 	add	x0, x0, #0xe20
    8680:	a9156bf9 	stp	x25, x26, [sp, #336]
    8684:	a91673fb 	stp	x27, x28, [sp, #352]
    8688:	97ffeec2 	bl	4190 <fwp_trap>
    868c:	aa1803e1 	mov	x1, x24
    8690:	d2800002 	mov	x2, #0x0                   	// #0
    8694:	52800160 	mov	w0, #0xb                   	// #11
    8698:	97ffe8a6 	bl	2930 <sigaction@plt>
    869c:	35fffee0 	cbnz	w0, 8678 <fwp_main_thread+0xc8>
    86a0:	aa1803e1 	mov	x1, x24
    86a4:	d2800002 	mov	x2, #0x0                   	// #0
    86a8:	528000e0 	mov	w0, #0x7                   	// #7
    86ac:	97ffe8a1 	bl	2930 <sigaction@plt>
    86b0:	35fffe40 	cbnz	w0, 8678 <fwp_main_thread+0xc8>
    86b4:	b9434680 	ldr	w0, [x20, #836]
    86b8:	34000840 	cbz	w0, 87c0 <fwp_main_thread+0x210>
    86bc:	910182a0 	add	x0, x21, #0x60
    86c0:	b9434801 	ldr	w1, [x0, #840]
    86c4:	340008c1 	cbz	w1, 87dc <fwp_main_thread+0x22c>
    86c8:	910182b6 	add	x22, x21, #0x60
    86cc:	f9400ad4 	ldr	x20, [x22, #16]
    86d0:	b4001514 	cbz	x20, 8970 <fwp_main_thread+0x3c0>
    86d4:	91010297 	add	x23, x20, #0x40
    86d8:	a9156bf9 	stp	x25, x26, [sp, #336]
    86dc:	52800038 	mov	w24, #0x1                   	// #1
    86e0:	39414a99 	ldrb	w25, [x20, #82]
    86e4:	39014a98 	strb	w24, [x20, #82]
    86e8:	f9401680 	ldr	x0, [x20, #40]
    86ec:	b40013e0 	cbz	x0, 8968 <fwp_main_thread+0x3b8>
    86f0:	f9403281 	ldr	x1, [x20, #96]
    86f4:	39414680 	ldrb	w0, [x20, #81]
    86f8:	b4001001 	cbz	x1, 88f8 <fwp_main_thread+0x348>
    86fc:	36000ec0 	tbz	w0, #0, 88d4 <fwp_main_thread+0x324>
    8700:	f9400ad3 	ldr	x19, [x22, #16]
    8704:	f9402280 	ldr	x0, [x20, #64]
    8708:	39414a61 	ldrb	w1, [x19, #82]
    870c:	370011e1 	tbnz	w1, #0, 8948 <fwp_main_thread+0x398>
    8710:	f9403261 	ldr	x1, [x19, #96]
    8714:	a911fe77 	stp	x23, xzr, [x19, #280]
    8718:	f9009660 	str	x0, [x19, #296]
    871c:	b4000040 	cbz	x0, 8724 <fwp_main_thread+0x174>
    8720:	f9009013 	str	x19, [x0, #288]
    8724:	f9002293 	str	x19, [x20, #64]
    8728:	b4000101 	cbz	x1, 8748 <fwp_main_thread+0x198>
    872c:	f9406ec0 	ldr	x0, [x22, #216]
    8730:	39015678 	strb	w24, [x19, #85]
    8734:	f9003661 	str	x1, [x19, #104]
    8738:	a910827f 	stp	xzr, x0, [x19, #264]
    873c:	b4000040 	cbz	x0, 8744 <fwp_main_thread+0x194>
    8740:	f9008413 	str	x19, [x0, #264]
    8744:	f9006ed3 	str	x19, [x22, #216]
    8748:	39015a7f 	strb	wzr, [x19, #86]
    874c:	97fff90d 	bl	6b80 <fwp_block>
    8750:	f9408e62 	ldr	x2, [x19, #280]
    8754:	b4000142 	cbz	x2, 877c <fwp_main_thread+0x1cc>
    8758:	a9520261 	ldp	x1, x0, [x19, #288]
    875c:	b4001021 	cbz	x1, 8960 <fwp_main_thread+0x3b0>
    8760:	f9009420 	str	x0, [x1, #296]
    8764:	f9409660 	ldr	x0, [x19, #296]
    8768:	b4000040 	cbz	x0, 8770 <fwp_main_thread+0x1c0>
    876c:	f9009001 	str	x1, [x0, #288]
    8770:	91080260 	add	x0, x19, #0x200
    8774:	f900967f 	str	xzr, [x19, #296]
    8778:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    877c:	39415660 	ldrb	w0, [x19, #85]
    8780:	3607fb40 	tbz	w0, #0, 86e8 <fwp_main_thread+0x138>
    8784:	a9508261 	ldp	x1, x0, [x19, #264]
    8788:	b4001fc1 	cbz	x1, 8b80 <fwp_main_thread+0x5d0>
    878c:	f9008820 	str	x0, [x1, #272]
    8790:	b4000040 	cbz	x0, 8798 <fwp_main_thread+0x1e8>
    8794:	f9008401 	str	x1, [x0, #264]
    8798:	91080260 	add	x0, x19, #0x200
    879c:	3901567f 	strb	wzr, [x19, #85]
    87a0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    87a4:	17ffffd1 	b	86e8 <fwp_main_thread+0x138>
    87a8:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    87ac:	91321000 	add	x0, x0, #0xc84
    87b0:	94000428 	bl	9850 <atexit>
    87b4:	17ffff91 	b	85f8 <fwp_main_thread+0x48>
    87b8:	97ffed8e 	bl	3df0 <fwp_heap_init>
    87bc:	17ffff8c 	b	85ec <fwp_main_thread+0x3c>
    87c0:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    87c4:	91078000 	add	x0, x0, #0x1e0
    87c8:	94000422 	bl	9850 <atexit>
    87cc:	35004680 	cbnz	w0, 909c <fwp_main_thread+0xaec>
    87d0:	52800020 	mov	w0, #0x1                   	// #1
    87d4:	b9034680 	str	w0, [x20, #836]
    87d8:	17ffffb9 	b	86bc <fwp_main_thread+0x10c>
    87dc:	f9418803 	ldr	x3, [x0, #784]
    87e0:	a9156bf9 	stp	x25, x26, [sp, #336]
    87e4:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    87e8:	a91673fb 	stp	x27, x28, [sp, #352]
    87ec:	9138c021 	add	x1, x1, #0xe30
    87f0:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    87f4:	91170279 	add	x25, x19, #0x5c0
    87f8:	913f4042 	add	x2, x2, #0xfd0
    87fc:	d280001a 	mov	x26, #0x0                   	// #0
    8800:	d290001b 	mov	x27, #0x8000                	// #32768
    8804:	f90003ff 	str	xzr, [sp]
    8808:	a9018be3 	stp	x3, x2, [sp, #24]
    880c:	a902fff7 	stp	x23, xzr, [sp, #40]
    8810:	a90407ff 	stp	xzr, x1, [sp, #64]
    8814:	f9018816 	str	x22, [x0, #784]
    8818:	14000012 	b	8860 <fwp_main_thread+0x2b0>
    881c:	7100045f 	cmp	w2, #0x1
    8820:	540001a1 	b.ne	8854 <fwp_main_thread+0x2a4>  // b.any
    8824:	294308a6 	ldp	w6, w2, [x5, #24]
    8828:	92403c21 	and	x1, x1, #0xffff
    882c:	9b067c21 	mul	x1, x1, x6
    8830:	d360fc21 	lsr	x1, x1, #32
    8834:	eb02003f 	cmp	x1, x2
    8838:	540000e2 	b.cs	8854 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    883c:	8b010000 	add	x0, x0, x1
    8840:	39400001 	ldrb	w1, [x0]
    8844:	7103fc3f 	cmp	w1, #0xff
    8848:	54003c40 	b.eq	8fd0 <fwp_main_thread+0xa20>  // b.none
    884c:	52800021 	mov	w1, #0x1                   	// #1
    8850:	39000001 	strb	w1, [x0]
    8854:	a9037ffa 	stp	x26, xzr, [sp, #48]
    8858:	aa14039c 	orr	x28, x28, x20
    885c:	b400197c 	cbz	x28, 8b88 <fwp_main_thread+0x5d8>
    8860:	f94003e0 	ldr	x0, [sp]
    8864:	f100077c 	subs	x28, x27, #0x1
    8868:	aa1803e1 	mov	x1, x24
    886c:	f9001ffc 	str	x28, [sp, #56]
    8870:	da1f0014 	sbc	x20, x0, xzr
    8874:	52800020 	mov	w0, #0x1                   	// #1
    8878:	f90003f4 	str	x20, [sp]
    887c:	aa1c03fb 	mov	x27, x28
    8880:	a9076bfc 	stp	x28, x26, [sp, #112]
    8884:	97fff200 	bl	5084 <fwp_data.part.0.constprop.0>
    8888:	aa0003fa 	mov	x26, x0
    888c:	f949db21 	ldr	x1, [x25, #5040]
    8890:	f949ef20 	ldr	x0, [x25, #5080]
    8894:	cb010341 	sub	x1, x26, x1
    8898:	eb00403f 	cmp	x1, x0, lsl #16
    889c:	54fffdc2 	b.cs	8854 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    88a0:	d350fc22 	lsr	x2, x1, #16
    88a4:	f949ff26 	ldr	x6, [x25, #5112]
    88a8:	8b020842 	add	x2, x2, x2, lsl #2
    88ac:	d37df042 	lsl	x2, x2, #3
    88b0:	8b0200c5 	add	x5, x6, x2
    88b4:	f94010a0 	ldr	x0, [x5, #32]
    88b8:	b4fffce0 	cbz	x0, 8854 <fwp_main_thread+0x2a4>
    88bc:	386268c2 	ldrb	w2, [x6, x2]
    88c0:	7100085f 	cmp	w2, #0x2
    88c4:	54fffac1 	b.ne	881c <fwp_main_thread+0x26c>  // b.any
    88c8:	72003c3f 	tst	w1, #0xffff
    88cc:	54fffc41 	b.ne	8854 <fwp_main_thread+0x2a4>  // b.any
    88d0:	17ffffdc 	b	8840 <fwp_main_thread+0x290>
    88d4:	97fff04f 	bl	4a10 <fwp_now_ns>
    88d8:	f9403281 	ldr	x1, [x20, #96]
    88dc:	eb01001f 	cmp	x0, x1
    88e0:	540000ab 	b.lt	88f4 <fwp_main_thread+0x344>  // b.tstop
    88e4:	39414280 	ldrb	w0, [x20, #80]
    88e8:	37000060 	tbnz	w0, #0, 88f4 <fwp_main_thread+0x344>
    88ec:	aa1403e0 	mov	x0, x20
    88f0:	97ffeba0 	bl	3770 <fwp_cancel_tree.part.0>
    88f4:	39414680 	ldrb	w0, [x20, #81]
    88f8:	f9400ad3 	ldr	x19, [x22, #16]
    88fc:	39414a62 	ldrb	w2, [x19, #82]
    8900:	3707f000 	tbnz	w0, #0, 8700 <fwp_main_thread+0x150>
    8904:	f9403281 	ldr	x1, [x20, #96]
    8908:	370001c2 	tbnz	w2, #0, 8940 <fwp_main_thread+0x390>
    890c:	f9403260 	ldr	x0, [x19, #96]
    8910:	b4000180 	cbz	x0, 8940 <fwp_main_thread+0x390>
    8914:	b4000061 	cbz	x1, 8920 <fwp_main_thread+0x370>
    8918:	eb01001f 	cmp	x0, x1
    891c:	9a81d000 	csel	x0, x0, x1, le
    8920:	f9402281 	ldr	x1, [x20, #64]
    8924:	a911fe77 	stp	x23, xzr, [x19, #280]
    8928:	f9009661 	str	x1, [x19, #296]
    892c:	b40035a1 	cbz	x1, 8fe0 <fwp_main_thread+0xa30>
    8930:	f9009033 	str	x19, [x1, #288]
    8934:	aa0003e1 	mov	x1, x0
    8938:	f9002293 	str	x19, [x20, #64]
    893c:	17ffff7c 	b	872c <fwp_main_thread+0x17c>
    8940:	f9402280 	ldr	x0, [x20, #64]
    8944:	17ffff74 	b	8714 <fwp_main_thread+0x164>
    8948:	a911fe77 	stp	x23, xzr, [x19, #280]
    894c:	f9009660 	str	x0, [x19, #296]
    8950:	b4000040 	cbz	x0, 8958 <fwp_main_thread+0x3a8>
    8954:	f9009013 	str	x19, [x0, #288]
    8958:	f9002293 	str	x19, [x20, #64]
    895c:	17ffff7b 	b	8748 <fwp_main_thread+0x198>
    8960:	f9000040 	str	x0, [x2]
    8964:	17ffff81 	b	8768 <fwp_main_thread+0x1b8>
    8968:	39014a99 	strb	w25, [x20, #82]
    896c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8970:	910182b3 	add	x19, x21, #0x60
    8974:	f9419660 	ldr	x0, [x19, #808]
    8978:	b5000060 	cbnz	x0, 8984 <fwp_main_thread+0x3d4>
    897c:	f9419e60 	ldr	x0, [x19, #824]
    8980:	b40034e0 	cbz	x0, 901c <fwp_main_thread+0xa6c>
    8984:	910182a0 	add	x0, x21, #0x60
    8988:	f9400800 	ldr	x0, [x0, #16]
    898c:	910182a1 	add	x1, x21, #0x60
    8990:	f941b026 	ldr	x6, [x1, #864]
    8994:	b903583f 	str	wzr, [x1, #856]
    8998:	eb0000df 	cmp	x6, x0
    899c:	54003d61 	b.ne	9148 <fwp_main_thread+0xb98>  // b.any
    89a0:	b40003e0 	cbz	x0, 8a1c <fwp_main_thread+0x46c>
    89a4:	f9418025 	ldr	x5, [x1, #768]
    89a8:	52800021 	mov	w1, #0x1                   	// #1
    89ac:	39014801 	strb	w1, [x0, #82]
    89b0:	b4000365 	cbz	x5, 8a1c <fwp_main_thread+0x46c>
    89b4:	d503201f 	nop
    89b8:	394140a0 	ldrb	w0, [x5, #80]
    89bc:	37000060 	tbnz	w0, #0, 89c8 <fwp_main_thread+0x418>
    89c0:	aa0503e0 	mov	x0, x5
    89c4:	97ffeb6b 	bl	3770 <fwp_cancel_tree.part.0>
    89c8:	f9409ca5 	ldr	x5, [x5, #312]
    89cc:	b5ffff65 	cbnz	x5, 89b8 <fwp_main_thread+0x408>
    89d0:	910182b3 	add	x19, x21, #0x60
    89d4:	52800034 	mov	w20, #0x1                   	// #1
    89d8:	f94028c0 	ldr	x0, [x6, #80]
    89dc:	f2001c1f 	tst	x0, #0xff000000ff
    89e0:	540000e1 	b.ne	89fc <fwp_main_thread+0x44c>  // b.any
    89e4:	f9403e60 	ldr	x0, [x19, #120]
    89e8:	390150d4 	strb	w20, [x6, #84]
    89ec:	f90080df 	str	xzr, [x6, #256]
    89f0:	b4000120 	cbz	x0, 8a14 <fwp_main_thread+0x464>
    89f4:	f9008006 	str	x6, [x0, #256]
    89f8:	f9003e66 	str	x6, [x19, #120]
    89fc:	97fff861 	bl	6b80 <fwp_block>
    8a00:	97fff7e8 	bl	69a0 <fwp_free_zombie>
    8a04:	f9418260 	ldr	x0, [x19, #768]
    8a08:	b40000a0 	cbz	x0, 8a1c <fwp_main_thread+0x46c>
    8a0c:	f941b266 	ldr	x6, [x19, #864]
    8a10:	17fffff2 	b	89d8 <fwp_main_thread+0x428>
    8a14:	f9004266 	str	x6, [x19, #128]
    8a18:	17fffff8 	b	89f8 <fwp_main_thread+0x448>
    8a1c:	910182b4 	add	x20, x21, #0x60
    8a20:	97fff7e0 	bl	69a0 <fwp_free_zombie>
    8a24:	f9404280 	ldr	x0, [x20, #128]
    8a28:	b5003900 	cbnz	x0, 9148 <fwp_main_thread+0xb98>
    8a2c:	f9406e80 	ldr	x0, [x20, #216]
    8a30:	b50038c0 	cbnz	x0, 9148 <fwp_main_thread+0xb98>
    8a34:	b940fa93 	ldr	w19, [x20, #248]
    8a38:	340001f3 	cbz	w19, 8a74 <fwp_main_thread+0x4c4>
    8a3c:	93407e76 	sxtw	x22, w19
    8a40:	51000673 	sub	w19, w19, #0x1
    8a44:	d1000ad6 	sub	x22, x22, #0x2
    8a48:	91040297 	add	x23, x20, #0x100
    8a4c:	cb3342d6 	sub	x22, x22, w19, uxtw
    8a50:	93407e73 	sxtw	x19, w19
    8a54:	d503201f 	nop
    8a58:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8a5c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8a60:	b900fa93 	str	w19, [x20, #248]
    8a64:	d1000673 	sub	x19, x19, #0x1
    8a68:	97ffe7f2 	bl	2a30 <munmap@plt>
    8a6c:	eb1302df 	cmp	x22, x19
    8a70:	54ffff41 	b.ne	8a58 <fwp_main_thread+0x4a8>  // b.any
    8a74:	900000d3 	adrp	x19, 20000 <__data_start>
    8a78:	91004260 	add	x0, x19, #0x10
    8a7c:	b9403800 	ldr	w0, [x0, #56]
    8a80:	37f80040 	tbnz	w0, #31, 8a88 <fwp_main_thread+0x4d8>
    8a84:	97ffe7a7 	bl	2920 <close@plt>
    8a88:	910182b4 	add	x20, x21, #0x60
    8a8c:	91004273 	add	x19, x19, #0x10
    8a90:	12800001 	mov	w1, #0xffffffff            	// #-1
    8a94:	f941ba80 	ldr	x0, [x20, #880]
    8a98:	b9003a61 	str	w1, [x19, #56]
    8a9c:	f941b681 	ldr	x1, [x20, #872]
    8aa0:	b40001c0 	cbz	x0, 8ad8 <fwp_main_thread+0x528>
    8aa4:	d2800013 	mov	x19, #0x0                   	// #0
    8aa8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    8aac:	b40000e0 	cbz	x0, 8ac8 <fwp_main_thread+0x518>
    8ab0:	f9400001 	ldr	x1, [x0]
    8ab4:	b50034a1 	cbnz	x1, 9148 <fwp_main_thread+0xb98>
    8ab8:	f9400401 	ldr	x1, [x0, #8]
    8abc:	b5003461 	cbnz	x1, 9148 <fwp_main_thread+0xb98>
    8ac0:	97ffee70 	bl	4480 <fwp_mem_free>
    8ac4:	f941b681 	ldr	x1, [x20, #872]
    8ac8:	91000673 	add	x19, x19, #0x1
    8acc:	f941ba80 	ldr	x0, [x20, #880]
    8ad0:	eb00027f 	cmp	x19, x0
    8ad4:	54fffea3 	b.cc	8aa8 <fwp_main_thread+0x4f8>  // b.lo, b.ul, b.last
    8ad8:	aa0103e0 	mov	x0, x1
    8adc:	97ffee69 	bl	4480 <fwp_mem_free>
    8ae0:	910182a0 	add	x0, x21, #0x60
    8ae4:	f941b013 	ldr	x19, [x0, #864]
    8ae8:	f901b41f 	str	xzr, [x0, #872]
    8aec:	f901b81f 	str	xzr, [x0, #880]
    8af0:	b40001f3 	cbz	x19, 8b2c <fwp_main_thread+0x57c>
    8af4:	f9401661 	ldr	x1, [x19, #40]
    8af8:	b5003281 	cbnz	x1, 9148 <fwp_main_thread+0xb98>
    8afc:	f9405661 	ldr	x1, [x19, #168]
    8b00:	b5003241 	cbnz	x1, 9148 <fwp_main_thread+0xb98>
    8b04:	f9419401 	ldr	x1, [x0, #808]
    8b08:	b5003201 	cbnz	x1, 9148 <fwp_main_thread+0xb98>
    8b0c:	f9419c00 	ldr	x0, [x0, #824]
    8b10:	b50031c0 	cbnz	x0, 9148 <fwp_main_thread+0xb98>
    8b14:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8b18:	90000140 	adrp	x0, 30000 <alt.5+0xfc20>
    8b1c:	910f8000 	add	x0, x0, #0x3e0
    8b20:	97ffe770 	bl	28e0 <memset@plt>
    8b24:	aa1303e0 	mov	x0, x19
    8b28:	97ffee56 	bl	4480 <fwp_mem_free>
    8b2c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8b30:	f947ec00 	ldr	x0, [x0, #4056]
    8b34:	910182b5 	add	x21, x21, #0x60
    8b38:	f9400000 	ldr	x0, [x0]
    8b3c:	f9000abf 	str	xzr, [x21, #16]
    8b40:	f901b2bf 	str	xzr, [x21, #864]
    8b44:	97ffe7bf 	bl	2a40 <fflush@plt>
    8b48:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8b4c:	f947f400 	ldr	x0, [x0, #4072]
    8b50:	f94087e2 	ldr	x2, [sp, #264]
    8b54:	f9400001 	ldr	x1, [x0]
    8b58:	eb010042 	subs	x2, x2, x1
    8b5c:	d2800001 	mov	x1, #0x0                   	// #0
    8b60:	54002a41 	b.ne	90a8 <fwp_main_thread+0xaf8>  // b.any
    8b64:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8b68:	d2800000 	mov	x0, #0x0                   	// #0
    8b6c:	a95253f3 	ldp	x19, x20, [sp, #288]
    8b70:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8b74:	a95463f7 	ldp	x23, x24, [sp, #320]
    8b78:	9105c3ff 	add	sp, sp, #0x170
    8b7c:	d65f03c0 	ret
    8b80:	f9006ec0 	str	x0, [x22, #216]
    8b84:	17ffff03 	b	8790 <fwp_main_thread+0x1e0>
    8b88:	910182a2 	add	x2, x21, #0x60
    8b8c:	f9001bff 	str	xzr, [sp, #48]
    8b90:	f9418840 	ldr	x0, [x2, #784]
    8b94:	eb16001f 	cmp	x0, x22
    8b98:	54002dc1 	b.ne	9150 <fwp_main_thread+0xba0>  // b.any
    8b9c:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x780>
    8ba0:	910143e1 	add	x1, sp, #0x50
    8ba4:	f9400fe3 	ldr	x3, [sp, #24]
    8ba8:	f9018843 	str	x3, [x2, #784]
    8bac:	3dc17000 	ldr	q0, [x0, #1472]
    8bb0:	52800020 	mov	w0, #0x1                   	// #1
    8bb4:	3d8017e0 	str	q0, [sp, #80]
    8bb8:	97fff133 	bl	5084 <fwp_data.part.0.constprop.0>
    8bbc:	91170263 	add	x3, x19, #0x5c0
    8bc0:	aa0003f4 	mov	x20, x0
    8bc4:	f949d861 	ldr	x1, [x3, #5040]
    8bc8:	f949ec60 	ldr	x0, [x3, #5080]
    8bcc:	cb010281 	sub	x1, x20, x1
    8bd0:	eb00403f 	cmp	x1, x0, lsl #16
    8bd4:	54000322 	b.cs	8c38 <fwp_main_thread+0x688>  // b.hs, b.nlast
    8bd8:	d350fc22 	lsr	x2, x1, #16
    8bdc:	f949fc63 	ldr	x3, [x3, #5112]
    8be0:	8b020842 	add	x2, x2, x2, lsl #2
    8be4:	d37df042 	lsl	x2, x2, #3
    8be8:	8b020060 	add	x0, x3, x2
    8bec:	f9401016 	ldr	x22, [x0, #32]
    8bf0:	b4000256 	cbz	x22, 8c38 <fwp_main_thread+0x688>
    8bf4:	38626862 	ldrb	w2, [x3, x2]
    8bf8:	7100085f 	cmp	w2, #0x2
    8bfc:	54001f80 	b.eq	8fec <fwp_main_thread+0xa3c>  // b.none
    8c00:	7100045f 	cmp	w2, #0x1
    8c04:	540001a1 	b.ne	8c38 <fwp_main_thread+0x688>  // b.any
    8c08:	29430002 	ldp	w2, w0, [x0, #24]
    8c0c:	92403c21 	and	x1, x1, #0xffff
    8c10:	9b027c21 	mul	x1, x1, x2
    8c14:	d360fc21 	lsr	x1, x1, #32
    8c18:	eb00003f 	cmp	x1, x0
    8c1c:	540000e2 	b.cs	8c38 <fwp_main_thread+0x688>  // b.hs, b.nlast
    8c20:	8b0102d6 	add	x22, x22, x1
    8c24:	394002c0 	ldrb	w0, [x22]
    8c28:	7103fc1f 	cmp	w0, #0xff
    8c2c:	54002160 	b.eq	9058 <fwp_main_thread+0xaa8>  // b.none
    8c30:	52800020 	mov	w0, #0x1                   	// #1
    8c34:	390002c0 	strb	w0, [x22]
    8c38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8c3c:	aa1803e1 	mov	x1, x24
    8c40:	52800020 	mov	w0, #0x1                   	// #1
    8c44:	a90753e2 	stp	x2, x20, [sp, #112]
    8c48:	97fff10f 	bl	5084 <fwp_data.part.0.constprop.0>
    8c4c:	91170263 	add	x3, x19, #0x5c0
    8c50:	aa0003f4 	mov	x20, x0
    8c54:	f949d861 	ldr	x1, [x3, #5040]
    8c58:	f949ec60 	ldr	x0, [x3, #5080]
    8c5c:	cb010281 	sub	x1, x20, x1
    8c60:	eb00403f 	cmp	x1, x0, lsl #16
    8c64:	54000322 	b.cs	8cc8 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8c68:	d350fc22 	lsr	x2, x1, #16
    8c6c:	f949fc63 	ldr	x3, [x3, #5112]
    8c70:	8b020842 	add	x2, x2, x2, lsl #2
    8c74:	d37df042 	lsl	x2, x2, #3
    8c78:	8b020060 	add	x0, x3, x2
    8c7c:	f9401016 	ldr	x22, [x0, #32]
    8c80:	b4000256 	cbz	x22, 8cc8 <fwp_main_thread+0x718>
    8c84:	38626862 	ldrb	w2, [x3, x2]
    8c88:	7100085f 	cmp	w2, #0x2
    8c8c:	54001b60 	b.eq	8ff8 <fwp_main_thread+0xa48>  // b.none
    8c90:	7100045f 	cmp	w2, #0x1
    8c94:	540001a1 	b.ne	8cc8 <fwp_main_thread+0x718>  // b.any
    8c98:	29430002 	ldp	w2, w0, [x0, #24]
    8c9c:	92403c21 	and	x1, x1, #0xffff
    8ca0:	9b027c21 	mul	x1, x1, x2
    8ca4:	d360fc21 	lsr	x1, x1, #32
    8ca8:	eb00003f 	cmp	x1, x0
    8cac:	540000e2 	b.cs	8cc8 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8cb0:	8b0102d6 	add	x22, x22, x1
    8cb4:	394002c0 	ldrb	w0, [x22]
    8cb8:	7103fc1f 	cmp	w0, #0xff
    8cbc:	54001c20 	b.eq	9040 <fwp_main_thread+0xa90>  // b.none
    8cc0:	52800020 	mov	w0, #0x1                   	// #1
    8cc4:	390002c0 	strb	w0, [x22]
    8cc8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8ccc:	910183e1 	add	x1, sp, #0x60
    8cd0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8cd4:	52800020 	mov	w0, #0x1                   	// #1
    8cd8:	a90653e2 	stp	x2, x20, [sp, #96]
    8cdc:	97fff0ea 	bl	5084 <fwp_data.part.0.constprop.0>
    8ce0:	91170263 	add	x3, x19, #0x5c0
    8ce4:	aa0003f9 	mov	x25, x0
    8ce8:	f949d861 	ldr	x1, [x3, #5040]
    8cec:	f949ec60 	ldr	x0, [x3, #5080]
    8cf0:	cb010321 	sub	x1, x25, x1
    8cf4:	eb00403f 	cmp	x1, x0, lsl #16
    8cf8:	54000322 	b.cs	8d5c <fwp_main_thread+0x7ac>  // b.hs, b.nlast
    8cfc:	d350fc22 	lsr	x2, x1, #16
    8d00:	f949fc63 	ldr	x3, [x3, #5112]
    8d04:	8b020842 	add	x2, x2, x2, lsl #2
    8d08:	d37df042 	lsl	x2, x2, #3
    8d0c:	8b020060 	add	x0, x3, x2
    8d10:	f9401014 	ldr	x20, [x0, #32]
    8d14:	b4000254 	cbz	x20, 8d5c <fwp_main_thread+0x7ac>
    8d18:	38626862 	ldrb	w2, [x3, x2]
    8d1c:	7100085f 	cmp	w2, #0x2
    8d20:	54001720 	b.eq	9004 <fwp_main_thread+0xa54>  // b.none
    8d24:	7100045f 	cmp	w2, #0x1
    8d28:	540001a1 	b.ne	8d5c <fwp_main_thread+0x7ac>  // b.any
    8d2c:	29430002 	ldp	w2, w0, [x0, #24]
    8d30:	92403c21 	and	x1, x1, #0xffff
    8d34:	9b027c21 	mul	x1, x1, x2
    8d38:	d360fc21 	lsr	x1, x1, #32
    8d3c:	eb00003f 	cmp	x1, x0
    8d40:	540000e2 	b.cs	8d5c <fwp_main_thread+0x7ac>  // b.hs, b.nlast
    8d44:	8b010294 	add	x20, x20, x1
    8d48:	39400280 	ldrb	w0, [x20]
    8d4c:	7103fc1f 	cmp	w0, #0xff
    8d50:	540017e0 	b.eq	904c <fwp_main_thread+0xa9c>  // b.none
    8d54:	52800020 	mov	w0, #0x1                   	// #1
    8d58:	39000280 	strb	w0, [x20]
    8d5c:	aa1a03f8 	mov	x24, x26
    8d60:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12730>
    8d64:	b400121a 	cbz	x26, 8fa4 <fwp_main_thread+0x9f4>
    8d68:	910aa000 	add	x0, x0, #0x2a8
    8d6c:	d0000016 	adrp	x22, a000 <_IO_stdin_used+0x780>
    8d70:	91014014 	add	x20, x0, #0x50
    8d74:	910c62d6 	add	x22, x22, #0x318
    8d78:	9117027b 	add	x27, x19, #0x5c0
    8d7c:	f949db61 	ldr	x1, [x27, #5040]
    8d80:	f949ef60 	ldr	x0, [x27, #5080]
    8d84:	cb010321 	sub	x1, x25, x1
    8d88:	eb00403f 	cmp	x1, x0, lsl #16
    8d8c:	54000342 	b.cs	8df4 <fwp_main_thread+0x844>  // b.hs, b.nlast
    8d90:	d350fc22 	lsr	x2, x1, #16
    8d94:	f949ff65 	ldr	x5, [x27, #5112]
    8d98:	8b020842 	add	x2, x2, x2, lsl #2
    8d9c:	d37df042 	lsl	x2, x2, #3
    8da0:	8b0200a3 	add	x3, x5, x2
    8da4:	f9401060 	ldr	x0, [x3, #32]
    8da8:	b4000260 	cbz	x0, 8df4 <fwp_main_thread+0x844>
    8dac:	386268a2 	ldrb	w2, [x5, x2]
    8db0:	7100085f 	cmp	w2, #0x2
    8db4:	540012e0 	b.eq	9010 <fwp_main_thread+0xa60>  // b.none
    8db8:	7100045f 	cmp	w2, #0x1
    8dbc:	540001c1 	b.ne	8df4 <fwp_main_thread+0x844>  // b.any
    8dc0:	29430865 	ldp	w5, w2, [x3, #24]
    8dc4:	92403c21 	and	x1, x1, #0xffff
    8dc8:	9b057c21 	mul	x1, x1, x5
    8dcc:	d360fc21 	lsr	x1, x1, #32
    8dd0:	eb02003f 	cmp	x1, x2
    8dd4:	54000102 	b.cs	8df4 <fwp_main_thread+0x844>  // b.hs, b.nlast
    8dd8:	8b010000 	add	x0, x0, x1
    8ddc:	39400001 	ldrb	w1, [x0]
    8de0:	340000a1 	cbz	w1, 8df4 <fwp_main_thread+0x844>
    8de4:	7103f43f 	cmp	w1, #0xfd
    8de8:	540013e8 	b.hi	9064 <fwp_main_thread+0xab4>  // b.pmore
    8dec:	11000421 	add	w1, w1, #0x1
    8df0:	39000001 	strb	w1, [x0]
    8df4:	aa1403e2 	mov	x2, x20
    8df8:	aa1903e1 	mov	x1, x25
    8dfc:	aa1703e0 	mov	x0, x23
    8e00:	52800023 	mov	w3, #0x1                   	// #1
    8e04:	a9037fff 	stp	xzr, xzr, [sp, #48]
    8e08:	f90023ff 	str	xzr, [sp, #64]
    8e0c:	97fff9ee 	bl	75c4 <fwp_write>
    8e10:	a9430bfc 	ldp	x28, x2, [sp, #48]
    8e14:	f100039f 	cmp	x28, #0x0
    8e18:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    8e1c:	b100285f 	cmn	x2, #0xa
    8e20:	54001268 	b.hi	906c <fwp_main_thread+0xabc>  // b.pmore
    8e24:	91002440 	add	x0, x2, #0x9
    8e28:	52800021 	mov	w1, #0x1                   	// #1
    8e2c:	f90007e2 	str	x2, [sp, #8]
    8e30:	97fff050 	bl	4f70 <fwp_heap_alloc>
    8e34:	aa1c03e1 	mov	x1, x28
    8e38:	aa0003fc 	mov	x28, x0
    8e3c:	f94007e2 	ldr	x2, [sp, #8]
    8e40:	f90003e0 	str	x0, [sp]
    8e44:	f8008782 	str	x2, [x28], #8
    8e48:	aa1c03e0 	mov	x0, x28
    8e4c:	97ffe645 	bl	2760 <memcpy@plt>
    8e50:	a9400be0 	ldp	x0, x2, [sp]
    8e54:	8b020002 	add	x2, x0, x2
    8e58:	3900205f 	strb	wzr, [x2, #8]
    8e5c:	f9401be0 	ldr	x0, [sp, #48]
    8e60:	97ffe6dc 	bl	29d0 <free@plt>
    8e64:	91170260 	add	x0, x19, #0x5c0
    8e68:	f94003e3 	ldr	x3, [sp]
    8e6c:	f949d801 	ldr	x1, [x0, #5040]
    8e70:	f949ec02 	ldr	x2, [x0, #5080]
    8e74:	cb010061 	sub	x1, x3, x1
    8e78:	eb02403f 	cmp	x1, x2, lsl #16
    8e7c:	54000322 	b.cs	8ee0 <fwp_main_thread+0x930>  // b.hs, b.nlast
    8e80:	d350fc22 	lsr	x2, x1, #16
    8e84:	d2800503 	mov	x3, #0x28                  	// #40
    8e88:	f949fc05 	ldr	x5, [x0, #5112]
    8e8c:	9b037c42 	mul	x2, x2, x3
    8e90:	8b0200a3 	add	x3, x5, x2
    8e94:	f9401060 	ldr	x0, [x3, #32]
    8e98:	b4000240 	cbz	x0, 8ee0 <fwp_main_thread+0x930>
    8e9c:	386268a2 	ldrb	w2, [x5, x2]
    8ea0:	7100085f 	cmp	w2, #0x2
    8ea4:	54000f60 	b.eq	9090 <fwp_main_thread+0xae0>  // b.none
    8ea8:	7100045f 	cmp	w2, #0x1
    8eac:	540001a1 	b.ne	8ee0 <fwp_main_thread+0x930>  // b.any
    8eb0:	29430865 	ldp	w5, w2, [x3, #24]
    8eb4:	92403c21 	and	x1, x1, #0xffff
    8eb8:	9b057c21 	mul	x1, x1, x5
    8ebc:	d360fc21 	lsr	x1, x1, #32
    8ec0:	eb02003f 	cmp	x1, x2
    8ec4:	540000e2 	b.cs	8ee0 <fwp_main_thread+0x930>  // b.hs, b.nlast
    8ec8:	8b010000 	add	x0, x0, x1
    8ecc:	39400001 	ldrb	w1, [x0]
    8ed0:	7103fc3f 	cmp	w1, #0xff
    8ed4:	540010e0 	b.eq	90f0 <fwp_main_thread+0xb40>  // b.none
    8ed8:	52800021 	mov	w1, #0x1                   	// #1
    8edc:	39000001 	strb	w1, [x0]
    8ee0:	aa1903e0 	mov	x0, x25
    8ee4:	97fff42f 	bl	5fa0 <fwp_drop0>
    8ee8:	f94003e1 	ldr	x1, [sp]
    8eec:	910182a3 	add	x3, x21, #0x60
    8ef0:	aa1c03e0 	mov	x0, x28
    8ef4:	aa0303fc 	mov	x28, x3
    8ef8:	f9400022 	ldr	x2, [x1]
    8efc:	d2800021 	mov	x1, #0x1                   	// #1
    8f00:	f9400463 	ldr	x3, [x3, #8]
    8f04:	97ffe6c3 	bl	2a10 <fwrite@plt>
    8f08:	f9400781 	ldr	x1, [x28, #8]
    8f0c:	52800140 	mov	w0, #0xa                   	// #10
    8f10:	97ffe648 	bl	2830 <fputc@plt>
    8f14:	91170262 	add	x2, x19, #0x5c0
    8f18:	f94003e3 	ldr	x3, [sp]
    8f1c:	f949d841 	ldr	x1, [x2, #5040]
    8f20:	f949ec40 	ldr	x0, [x2, #5080]
    8f24:	cb010061 	sub	x1, x3, x1
    8f28:	eb00403f 	cmp	x1, x0, lsl #16
    8f2c:	54000382 	b.cs	8f9c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    8f30:	d350fc20 	lsr	x0, x1, #16
    8f34:	d2800505 	mov	x5, #0x28                  	// #40
    8f38:	f949fc43 	ldr	x3, [x2, #5112]
    8f3c:	9b057c00 	mul	x0, x0, x5
    8f40:	8b000062 	add	x2, x3, x0
    8f44:	f940105c 	ldr	x28, [x2, #32]
    8f48:	b40002bc 	cbz	x28, 8f9c <fwp_main_thread+0x9ec>
    8f4c:	38606860 	ldrb	w0, [x3, x0]
    8f50:	7100081f 	cmp	w0, #0x2
    8f54:	54000980 	b.eq	9084 <fwp_main_thread+0xad4>  // b.none
    8f58:	7100041f 	cmp	w0, #0x1
    8f5c:	54000201 	b.ne	8f9c <fwp_main_thread+0x9ec>  // b.any
    8f60:	29430043 	ldp	w3, w0, [x2, #24]
    8f64:	92403c21 	and	x1, x1, #0xffff
    8f68:	9b037c21 	mul	x1, x1, x3
    8f6c:	d360fc21 	lsr	x1, x1, #32
    8f70:	eb00003f 	cmp	x1, x0
    8f74:	54000142 	b.cs	8f9c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    8f78:	8b01039c 	add	x28, x28, x1
    8f7c:	39400380 	ldrb	w0, [x28]
    8f80:	340000e0 	cbz	w0, 8f9c <fwp_main_thread+0x9ec>
    8f84:	7100041f 	cmp	w0, #0x1
    8f88:	54000780 	b.eq	9078 <fwp_main_thread+0xac8>  // b.none
    8f8c:	7103fc1f 	cmp	w0, #0xff
    8f90:	54000920 	b.eq	90b4 <fwp_main_thread+0xb04>  // b.none
    8f94:	51000400 	sub	w0, w0, #0x1
    8f98:	39000380 	strb	w0, [x28]
    8f9c:	f9400b18 	ldr	x24, [x24, #16]
    8fa0:	b5ffeef8 	cbnz	x24, 8d7c <fwp_main_thread+0x7cc>
    8fa4:	aa1903e0 	mov	x0, x25
    8fa8:	97fff3fe 	bl	5fa0 <fwp_drop0>
    8fac:	aa1a03e0 	mov	x0, x26
    8fb0:	97fff3fc 	bl	5fa0 <fwp_drop0>
    8fb4:	910182a0 	add	x0, x21, #0x60
    8fb8:	52800021 	mov	w1, #0x1                   	// #1
    8fbc:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8fc0:	a95673fb 	ldp	x27, x28, [sp, #352]
    8fc4:	b9034801 	str	w1, [x0, #840]
    8fc8:	f901a81f 	str	xzr, [x0, #848]
    8fcc:	17fffdbf 	b	86c8 <fwp_main_thread+0x118>
    8fd0:	f90007e0 	str	x0, [sp, #8]
    8fd4:	97ffec8f 	bl	4210 <fwp_rc_forget_slot.part.0>
    8fd8:	f94007e0 	ldr	x0, [sp, #8]
    8fdc:	17fffe1c 	b	884c <fwp_main_thread+0x29c>
    8fe0:	aa0003e1 	mov	x1, x0
    8fe4:	f9002293 	str	x19, [x20, #64]
    8fe8:	17fffdd1 	b	872c <fwp_main_thread+0x17c>
    8fec:	72003c3f 	tst	w1, #0xffff
    8ff0:	54ffe241 	b.ne	8c38 <fwp_main_thread+0x688>  // b.any
    8ff4:	17ffff0c 	b	8c24 <fwp_main_thread+0x674>
    8ff8:	72003c3f 	tst	w1, #0xffff
    8ffc:	54ffe661 	b.ne	8cc8 <fwp_main_thread+0x718>  // b.any
    9000:	17ffff2d 	b	8cb4 <fwp_main_thread+0x704>
    9004:	72003c3f 	tst	w1, #0xffff
    9008:	54ffeaa1 	b.ne	8d5c <fwp_main_thread+0x7ac>  // b.any
    900c:	17ffff4f 	b	8d48 <fwp_main_thread+0x798>
    9010:	72003c3f 	tst	w1, #0xffff
    9014:	54ffef01 	b.ne	8df4 <fwp_main_thread+0x844>  // b.any
    9018:	17ffff71 	b	8ddc <fwp_main_thread+0x82c>
    901c:	f9419260 	ldr	x0, [x19, #800]
    9020:	97ffed18 	bl	4480 <fwp_mem_free>
    9024:	f901927f 	str	xzr, [x19, #800]
    9028:	f9400a60 	ldr	x0, [x19, #16]
    902c:	f9019a7f 	str	xzr, [x19, #816]
    9030:	b4ffcae0 	cbz	x0, 898c <fwp_main_thread+0x3dc>
    9034:	f900541f 	str	xzr, [x0, #168]
    9038:	f9005c1f 	str	xzr, [x0, #184]
    903c:	17fffe54 	b	898c <fwp_main_thread+0x3dc>
    9040:	aa1603e0 	mov	x0, x22
    9044:	97ffec73 	bl	4210 <fwp_rc_forget_slot.part.0>
    9048:	17ffff1e 	b	8cc0 <fwp_main_thread+0x710>
    904c:	aa1403e0 	mov	x0, x20
    9050:	97ffec70 	bl	4210 <fwp_rc_forget_slot.part.0>
    9054:	17ffff40 	b	8d54 <fwp_main_thread+0x7a4>
    9058:	aa1603e0 	mov	x0, x22
    905c:	97ffec6d 	bl	4210 <fwp_rc_forget_slot.part.0>
    9060:	17fffef4 	b	8c30 <fwp_main_thread+0x680>
    9064:	97ffed80 	bl	4664 <fwp_rc_wide_dup>
    9068:	17ffff63 	b	8df4 <fwp_main_thread+0x844>
    906c:	90000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    9070:	91392000 	add	x0, x0, #0xe48
    9074:	97ffec47 	bl	4190 <fwp_trap>
    9078:	f94003e0 	ldr	x0, [sp]
    907c:	97fff296 	bl	5ad4 <fwp_rc_free_arr>
    9080:	17ffffc7 	b	8f9c <fwp_main_thread+0x9ec>
    9084:	72003c3f 	tst	w1, #0xffff
    9088:	54fff8a1 	b.ne	8f9c <fwp_main_thread+0x9ec>  // b.any
    908c:	17ffffbc 	b	8f7c <fwp_main_thread+0x9cc>
    9090:	72003c3f 	tst	w1, #0xffff
    9094:	54fff261 	b.ne	8ee0 <fwp_main_thread+0x930>  // b.any
    9098:	17ffff8d 	b	8ecc <fwp_main_thread+0x91c>
    909c:	a9156bf9 	stp	x25, x26, [sp, #336]
    90a0:	a91673fb 	stp	x27, x28, [sp, #352]
    90a4:	97ffe843 	bl	31b0 <descent_phase_fail>
    90a8:	a9156bf9 	stp	x25, x26, [sp, #336]
    90ac:	a91673fb 	stp	x27, x28, [sp, #352]
    90b0:	97ffe618 	bl	2910 <__stack_chk_fail@plt>
    90b4:	ca5c4780 	eor	x0, x28, x28, lsr #17
    90b8:	91170262 	add	x2, x19, #0x5c0
    90bc:	ca402400 	eor	x0, x0, x0, lsr #9
    90c0:	92401c00 	and	x0, x0, #0xff
    90c4:	910a2401 	add	x1, x0, #0x289
    90c8:	8b000c40 	add	x0, x2, x0, lsl #3
    90cc:	8b010c41 	add	x1, x2, x1, lsl #3
    90d0:	f94a2400 	ldr	x0, [x0, #5192]
    90d4:	b40002e0 	cbz	x0, 9130 <fwp_main_thread+0xb80>
    90d8:	f9400002 	ldr	x2, [x0]
    90dc:	eb02039f 	cmp	x28, x2
    90e0:	54000100 	b.eq	9100 <fwp_main_thread+0xb50>  // b.none
    90e4:	91004001 	add	x1, x0, #0x10
    90e8:	f9400800 	ldr	x0, [x0, #16]
    90ec:	17fffffa 	b	90d4 <fwp_main_thread+0xb24>
    90f0:	f90007e0 	str	x0, [sp, #8]
    90f4:	97ffec47 	bl	4210 <fwp_rc_forget_slot.part.0>
    90f8:	f94007e0 	ldr	x0, [sp, #8]
    90fc:	17ffff77 	b	8ed8 <fwp_main_thread+0x928>
    9100:	f9400021 	ldr	x1, [x1]
    9104:	f9400420 	ldr	x0, [x1, #8]
    9108:	d1000400 	sub	x0, x0, #0x1
    910c:	f9000420 	str	x0, [x1, #8]
    9110:	f103f81f 	cmp	x0, #0xfe
    9114:	54fff441 	b.ne	8f9c <fwp_main_thread+0x9ec>  // b.any
    9118:	39400380 	ldrb	w0, [x28]
    911c:	7103fc1f 	cmp	w0, #0xff
    9120:	540000e0 	b.eq	913c <fwp_main_thread+0xb8c>  // b.none
    9124:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9128:	39000380 	strb	w0, [x28]
    912c:	17ffff9c 	b	8f9c <fwp_main_thread+0x9ec>
    9130:	90000000 	adrp	x0, 9000 <fwp_main_thread+0xa50>
    9134:	9129e000 	add	x0, x0, #0xa78
    9138:	97ffec16 	bl	4190 <fwp_trap>
    913c:	aa1c03e0 	mov	x0, x28
    9140:	97ffec34 	bl	4210 <fwp_rc_forget_slot.part.0>
    9144:	17fffff8 	b	9124 <fwp_main_thread+0xb74>
    9148:	a9156bf9 	stp	x25, x26, [sp, #336]
    914c:	a91673fb 	stp	x27, x28, [sp, #352]
    9150:	97ffe604 	bl	2960 <abort@plt>
    9154:	d503201f 	nop
    9158:	d503201f 	nop
    915c:	d503201f 	nop

0000000000009160 <__divti3>:
    9160:	d503245f 	bti	c
    9164:	d2800004 	mov	x4, #0x0                   	// #0
    9168:	b7f80721 	tbnz	x1, #63, 924c <__divti3+0xec>
    916c:	b6f80083 	tbz	x3, #63, 917c <__divti3+0x1c>
    9170:	eb0203e2 	negs	x2, x2
    9174:	aa2403e4 	mvn	x4, x4
    9178:	da0303e3 	ngc	x3, x3
    917c:	aa0203e6 	mov	x6, x2
    9180:	aa0003e7 	mov	x7, x0
    9184:	aa0103e5 	mov	x5, x1
    9188:	b5000583 	cbnz	x3, 9238 <__divti3+0xd8>
    918c:	eb01005f 	cmp	x2, x1
    9190:	54000e69 	b.ls	935c <__divti3+0x1fc>  // b.plast
    9194:	dac01040 	clz	x0, x2
    9198:	b40000e0 	cbz	x0, 91b4 <__divti3+0x54>
    919c:	4b0003e1 	neg	w1, w0
    91a0:	9ac020a5 	lsl	x5, x5, x0
    91a4:	9ac02046 	lsl	x6, x2, x0
    91a8:	9ac124e1 	lsr	x1, x7, x1
    91ac:	aa050025 	orr	x5, x1, x5
    91b0:	9ac020e7 	lsl	x7, x7, x0
    91b4:	d360fcc8 	lsr	x8, x6, #32
    91b8:	92407cc2 	and	x2, x6, #0xffffffff
    91bc:	9ac808a3 	udiv	x3, x5, x8
    91c0:	9b089465 	msub	x5, x3, x8, x5
    91c4:	aa0303e0 	mov	x0, x3
    91c8:	9b037c41 	mul	x1, x2, x3
    91cc:	93c780a5 	extr	x5, x5, x7, #32
    91d0:	eb05003f 	cmp	x1, x5
    91d4:	540000a9 	b.ls	91e8 <__divti3+0x88>  // b.plast
    91d8:	ab0500c5 	adds	x5, x6, x5
    91dc:	d1000460 	sub	x0, x3, #0x1
    91e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    91e4:	540015a8 	b.hi	9498 <__divti3+0x338>  // b.pmore
    91e8:	cb0100a5 	sub	x5, x5, x1
    91ec:	9ac808a3 	udiv	x3, x5, x8
    91f0:	9b089465 	msub	x5, x3, x8, x5
    91f4:	aa0303e1 	mov	x1, x3
    91f8:	9b037c42 	mul	x2, x2, x3
    91fc:	aa0703e3 	mov	x3, x7
    9200:	b3607ca3 	bfi	x3, x5, #32, #32
    9204:	eb03005f 	cmp	x2, x3
    9208:	540000c9 	b.ls	9220 <__divti3+0xc0>  // b.plast
    920c:	ab0300c3 	adds	x3, x6, x3
    9210:	d1000425 	sub	x5, x1, #0x1
    9214:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9218:	d1000821 	sub	x1, x1, #0x2
    921c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9220:	aa008020 	orr	x0, x1, x0, lsl #32
    9224:	d2800001 	mov	x1, #0x0                   	// #0
    9228:	b4000064 	cbz	x4, 9234 <__divti3+0xd4>
    922c:	eb0003e0 	negs	x0, x0
    9230:	da0103e1 	ngc	x1, x1
    9234:	d65f03c0 	ret
    9238:	eb01007f 	cmp	x3, x1
    923c:	54000109 	b.ls	925c <__divti3+0xfc>  // b.plast
    9240:	d2800001 	mov	x1, #0x0                   	// #0
    9244:	d2800000 	mov	x0, #0x0                   	// #0
    9248:	17fffff8 	b	9228 <__divti3+0xc8>
    924c:	eb0003e0 	negs	x0, x0
    9250:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9254:	da0103e1 	ngc	x1, x1
    9258:	17ffffc5 	b	916c <__divti3+0xc>
    925c:	dac01067 	clz	x7, x3
    9260:	b40010e7 	cbz	x7, 947c <__divti3+0x31c>
    9264:	d2800805 	mov	x5, #0x40                  	// #64
    9268:	cb0700a5 	sub	x5, x5, x7
    926c:	9ac72063 	lsl	x3, x3, x7
    9270:	9ac52448 	lsr	x8, x2, x5
    9274:	aa030108 	orr	x8, x8, x3
    9278:	9ac52426 	lsr	x6, x1, x5
    927c:	92407d0a 	and	x10, x8, #0xffffffff
    9280:	d360fd09 	lsr	x9, x8, #32
    9284:	9ac52403 	lsr	x3, x0, x5
    9288:	9ac72021 	lsl	x1, x1, x7
    928c:	aa010063 	orr	x3, x3, x1
    9290:	9ac72042 	lsl	x2, x2, x7
    9294:	9ac908cb 	udiv	x11, x6, x9
    9298:	9b099965 	msub	x5, x11, x9, x6
    929c:	aa0b03e1 	mov	x1, x11
    92a0:	9b0b7d46 	mul	x6, x10, x11
    92a4:	93c380a5 	extr	x5, x5, x3, #32
    92a8:	eb0500df 	cmp	x6, x5
    92ac:	540000a9 	b.ls	92c0 <__divti3+0x160>  // b.plast
    92b0:	ab050105 	adds	x5, x8, x5
    92b4:	d1000561 	sub	x1, x11, #0x1
    92b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    92bc:	54000f48 	b.hi	94a4 <__divti3+0x344>  // b.pmore
    92c0:	cb0600a6 	sub	x6, x5, x6
    92c4:	9ac908cb 	udiv	x11, x6, x9
    92c8:	9b099969 	msub	x9, x11, x9, x6
    92cc:	aa0b03e5 	mov	x5, x11
    92d0:	9b0b7d4a 	mul	x10, x10, x11
    92d4:	b3607d23 	bfi	x3, x9, #32, #32
    92d8:	eb03015f 	cmp	x10, x3
    92dc:	540000a9 	b.ls	92f0 <__divti3+0x190>  // b.plast
    92e0:	ab030103 	adds	x3, x8, x3
    92e4:	d1000565 	sub	x5, x11, #0x1
    92e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    92ec:	54000e28 	b.hi	94b0 <__divti3+0x350>  // b.pmore
    92f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    92f4:	92407c48 	and	x8, x2, #0xffffffff
    92f8:	2a0503e5 	mov	w5, w5
    92fc:	d360fc42 	lsr	x2, x2, #32
    9300:	d360fc26 	lsr	x6, x1, #32
    9304:	cb0a0063 	sub	x3, x3, x10
    9308:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    930c:	9b087caa 	mul	x10, x5, x8
    9310:	9b087cc8 	mul	x8, x6, x8
    9314:	9b0220a5 	madd	x5, x5, x2, x8
    9318:	9b027cc6 	mul	x6, x6, x2
    931c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9320:	8b0900c5 	add	x5, x6, x9
    9324:	eb02011f 	cmp	x8, x2
    9328:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    932c:	8b4280c6 	add	x6, x6, x2, lsr #32
    9330:	eb06007f 	cmp	x3, x6
    9334:	540000e3 	b.cc	9350 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    9338:	92407d4a 	and	x10, x10, #0xffffffff
    933c:	9ac72000 	lsl	x0, x0, x7
    9340:	8b028142 	add	x2, x10, x2, lsl #32
    9344:	eb02001f 	cmp	x0, x2
    9348:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    934c:	54000a01 	b.ne	948c <__divti3+0x32c>  // b.any
    9350:	d1000420 	sub	x0, x1, #0x1
    9354:	d2800001 	mov	x1, #0x0                   	// #0
    9358:	17ffffb4 	b	9228 <__divti3+0xc8>
    935c:	b5000062 	cbnz	x2, 9368 <__divti3+0x208>
    9360:	d2800022 	mov	x2, #0x1                   	// #1
    9364:	9ac30846 	udiv	x6, x2, x3
    9368:	dac010c8 	clz	x8, x6
    936c:	b5000408 	cbnz	x8, 93ec <__divti3+0x28c>
    9370:	d360fcc9 	lsr	x9, x6, #32
    9374:	92407cc5 	and	x5, x6, #0xffffffff
    9378:	cb060023 	sub	x3, x1, x6
    937c:	d2800021 	mov	x1, #0x1                   	// #1
    9380:	9ac90868 	udiv	x8, x3, x9
    9384:	9b098d03 	msub	x3, x8, x9, x3
    9388:	aa0803e0 	mov	x0, x8
    938c:	9b057d02 	mul	x2, x8, x5
    9390:	93c78063 	extr	x3, x3, x7, #32
    9394:	eb03005f 	cmp	x2, x3
    9398:	540000a9 	b.ls	93ac <__divti3+0x24c>  // b.plast
    939c:	ab0300c3 	adds	x3, x6, x3
    93a0:	d1000500 	sub	x0, x8, #0x1
    93a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    93a8:	54000968 	b.hi	94d4 <__divti3+0x374>  // b.pmore
    93ac:	cb020063 	sub	x3, x3, x2
    93b0:	9ac90862 	udiv	x2, x3, x9
    93b4:	aa0203e8 	mov	x8, x2
    93b8:	9b098c42 	msub	x2, x2, x9, x3
    93bc:	aa0703e3 	mov	x3, x7
    93c0:	9b057d05 	mul	x5, x8, x5
    93c4:	b3607c43 	bfi	x3, x2, #32, #32
    93c8:	eb0300bf 	cmp	x5, x3
    93cc:	540000c9 	b.ls	93e4 <__divti3+0x284>  // b.plast
    93d0:	ab0300c2 	adds	x2, x6, x3
    93d4:	d1000503 	sub	x3, x8, #0x1
    93d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    93dc:	d1000908 	sub	x8, x8, #0x2
    93e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    93e4:	aa008100 	orr	x0, x8, x0, lsl #32
    93e8:	17ffff90 	b	9228 <__divti3+0xc8>
    93ec:	9ac820c6 	lsl	x6, x6, x8
    93f0:	d2800803 	mov	x3, #0x40                  	// #64
    93f4:	cb080063 	sub	x3, x3, x8
    93f8:	d360fcc9 	lsr	x9, x6, #32
    93fc:	9ac82027 	lsl	x7, x1, x8
    9400:	92407cc5 	and	x5, x6, #0xffffffff
    9404:	9ac32422 	lsr	x2, x1, x3
    9408:	9ac32403 	lsr	x3, x0, x3
    940c:	aa070063 	orr	x3, x3, x7
    9410:	9ac9084a 	udiv	x10, x2, x9
    9414:	9ac82007 	lsl	x7, x0, x8
    9418:	9b098940 	msub	x0, x10, x9, x2
    941c:	aa0a03e1 	mov	x1, x10
    9420:	9b0a7ca2 	mul	x2, x5, x10
    9424:	93c38000 	extr	x0, x0, x3, #32
    9428:	eb00005f 	cmp	x2, x0
    942c:	540000a9 	b.ls	9440 <__divti3+0x2e0>  // b.plast
    9430:	ab0000c0 	adds	x0, x6, x0
    9434:	d1000541 	sub	x1, x10, #0x1
    9438:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    943c:	54000468 	b.hi	94c8 <__divti3+0x368>  // b.pmore
    9440:	cb020000 	sub	x0, x0, x2
    9444:	9ac9080a 	udiv	x10, x0, x9
    9448:	9b098140 	msub	x0, x10, x9, x0
    944c:	aa0a03e2 	mov	x2, x10
    9450:	9b0a7ca8 	mul	x8, x5, x10
    9454:	b3607c03 	bfi	x3, x0, #32, #32
    9458:	eb03011f 	cmp	x8, x3
    945c:	540000a9 	b.ls	9470 <__divti3+0x310>  // b.plast
    9460:	ab0300c3 	adds	x3, x6, x3
    9464:	d1000542 	sub	x2, x10, #0x1
    9468:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    946c:	54000288 	b.hi	94bc <__divti3+0x35c>  // b.pmore
    9470:	cb080063 	sub	x3, x3, x8
    9474:	aa018041 	orr	x1, x2, x1, lsl #32
    9478:	17ffffc2 	b	9380 <__divti3+0x220>
    947c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9480:	d2800001 	mov	x1, #0x0                   	// #0
    9484:	9a9f87e0 	cset	x0, ls	// ls = plast
    9488:	17ffff68 	b	9228 <__divti3+0xc8>
    948c:	aa0103e0 	mov	x0, x1
    9490:	d2800001 	mov	x1, #0x0                   	// #0
    9494:	17ffff65 	b	9228 <__divti3+0xc8>
    9498:	d1000860 	sub	x0, x3, #0x2
    949c:	8b0600a5 	add	x5, x5, x6
    94a0:	17ffff52 	b	91e8 <__divti3+0x88>
    94a4:	d1000961 	sub	x1, x11, #0x2
    94a8:	8b0800a5 	add	x5, x5, x8
    94ac:	17ffff85 	b	92c0 <__divti3+0x160>
    94b0:	d1000965 	sub	x5, x11, #0x2
    94b4:	8b080063 	add	x3, x3, x8
    94b8:	17ffff8e 	b	92f0 <__divti3+0x190>
    94bc:	d1000942 	sub	x2, x10, #0x2
    94c0:	8b060063 	add	x3, x3, x6
    94c4:	17ffffeb 	b	9470 <__divti3+0x310>
    94c8:	d1000941 	sub	x1, x10, #0x2
    94cc:	8b060000 	add	x0, x0, x6
    94d0:	17ffffdc 	b	9440 <__divti3+0x2e0>
    94d4:	d1000900 	sub	x0, x8, #0x2
    94d8:	8b060063 	add	x3, x3, x6
    94dc:	17ffffb4 	b	93ac <__divti3+0x24c>

00000000000094e0 <__modti3>:
    94e0:	d503245f 	bti	c
    94e4:	d2800004 	mov	x4, #0x0                   	// #0
    94e8:	b6f80081 	tbz	x1, #63, 94f8 <__modti3+0x18>
    94ec:	eb0003e0 	negs	x0, x0
    94f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    94f4:	da0103e1 	ngc	x1, x1
    94f8:	f100007f 	cmp	x3, #0x0
    94fc:	5400128b 	b.lt	974c <__modti3+0x26c>  // b.tstop
    9500:	aa0003e7 	mov	x7, x0
    9504:	aa0103e6 	mov	x6, x1
    9508:	540004e1 	b.ne	95a4 <__modti3+0xc4>  // b.any
    950c:	eb02003f 	cmp	x1, x2
    9510:	54000dc2 	b.cs	96c8 <__modti3+0x1e8>  // b.hs, b.nlast
    9514:	dac01043 	clz	x3, x2
    9518:	aa0303e5 	mov	x5, x3
    951c:	b40000e3 	cbz	x3, 9538 <__modti3+0x58>
    9520:	4b0303e6 	neg	w6, w3
    9524:	9ac32021 	lsl	x1, x1, x3
    9528:	9ac32042 	lsl	x2, x2, x3
    952c:	9ac62406 	lsr	x6, x0, x6
    9530:	aa0100c6 	orr	x6, x6, x1
    9534:	9ac32007 	lsl	x7, x0, x3
    9538:	d360fc40 	lsr	x0, x2, #32
    953c:	92407c43 	and	x3, x2, #0xffffffff
    9540:	9ac008c1 	udiv	x1, x6, x0
    9544:	9b009826 	msub	x6, x1, x0, x6
    9548:	9b017c61 	mul	x1, x3, x1
    954c:	93c780c6 	extr	x6, x6, x7, #32
    9550:	eb06003f 	cmp	x1, x6
    9554:	540000a9 	b.ls	9568 <__modti3+0x88>  // b.plast
    9558:	ab060046 	adds	x6, x2, x6
    955c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9560:	8b0200c8 	add	x8, x6, x2
    9564:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9568:	cb0100c6 	sub	x6, x6, x1
    956c:	9ac008c8 	udiv	x8, x6, x0
    9570:	9b009901 	msub	x1, x8, x0, x6
    9574:	aa0703e0 	mov	x0, x7
    9578:	9b087c63 	mul	x3, x3, x8
    957c:	b3607c20 	bfi	x0, x1, #32, #32
    9580:	eb00007f 	cmp	x3, x0
    9584:	54001088 	b.hi	9794 <__modti3+0x2b4>  // b.pmore
    9588:	cb030000 	sub	x0, x0, x3
    958c:	9ac52400 	lsr	x0, x0, x5
    9590:	d2800001 	mov	x1, #0x0                   	// #0
    9594:	b4000064 	cbz	x4, 95a0 <__modti3+0xc0>
    9598:	eb0003e0 	negs	x0, x0
    959c:	da0103e1 	ngc	x1, x1
    95a0:	d65f03c0 	ret
    95a4:	dac01066 	clz	x6, x3
    95a8:	eb03003f 	cmp	x1, x3
    95ac:	54ffff43 	b.cc	9594 <__modti3+0xb4>  // b.lo, b.ul, b.last
    95b0:	93407cc5 	sxtw	x5, w6
    95b4:	d2800808 	mov	x8, #0x40                  	// #64
    95b8:	cb050108 	sub	x8, x8, x5
    95bc:	9ac62063 	lsl	x3, x3, x6
    95c0:	9ac62025 	lsl	x5, x1, x6
    95c4:	9ac82447 	lsr	x7, x2, x8
    95c8:	aa0300e7 	orr	x7, x7, x3
    95cc:	9ac82423 	lsr	x3, x1, x8
    95d0:	92407cec 	and	x12, x7, #0xffffffff
    95d4:	d360fcea 	lsr	x10, x7, #32
    95d8:	9ac82401 	lsr	x1, x0, x8
    95dc:	aa050021 	orr	x1, x1, x5
    95e0:	9ac62042 	lsl	x2, x2, x6
    95e4:	9ac62000 	lsl	x0, x0, x6
    95e8:	9aca086b 	udiv	x11, x3, x10
    95ec:	9b0a8d63 	msub	x3, x11, x10, x3
    95f0:	aa0b03e5 	mov	x5, x11
    95f4:	9b0b7d89 	mul	x9, x12, x11
    95f8:	93c18063 	extr	x3, x3, x1, #32
    95fc:	eb03013f 	cmp	x9, x3
    9600:	540000a9 	b.ls	9614 <__modti3+0x134>  // b.plast
    9604:	ab0300e3 	adds	x3, x7, x3
    9608:	d1000565 	sub	x5, x11, #0x1
    960c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9610:	54001168 	b.hi	983c <__modti3+0x35c>  // b.pmore
    9614:	cb090063 	sub	x3, x3, x9
    9618:	9aca086b 	udiv	x11, x3, x10
    961c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9620:	aa0b03e9 	mov	x9, x11
    9624:	9b0b7d8c 	mul	x12, x12, x11
    9628:	b3607d41 	bfi	x1, x10, #32, #32
    962c:	eb01019f 	cmp	x12, x1
    9630:	540000a9 	b.ls	9644 <__modti3+0x164>  // b.plast
    9634:	ab0100e1 	adds	x1, x7, x1
    9638:	d1000569 	sub	x9, x11, #0x1
    963c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9640:	54000f88 	b.hi	9830 <__modti3+0x350>  // b.pmore
    9644:	aa058123 	orr	x3, x9, x5, lsl #32
    9648:	92407c4b 	and	x11, x2, #0xffffffff
    964c:	2a0903e9 	mov	w9, w9
    9650:	d360fc4a 	lsr	x10, x2, #32
    9654:	d360fc63 	lsr	x3, x3, #32
    9658:	cb0c0021 	sub	x1, x1, x12
    965c:	aa0a03ec 	mov	x12, x10
    9660:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9664:	9b0b7d25 	mul	x5, x9, x11
    9668:	9b0b7c6b 	mul	x11, x3, x11
    966c:	9b0a2d29 	madd	x9, x9, x10, x11
    9670:	92407caa 	and	x10, x5, #0xffffffff
    9674:	9b0c7c63 	mul	x3, x3, x12
    9678:	8b458125 	add	x5, x9, x5, lsr #32
    967c:	8b0d0069 	add	x9, x3, x13
    9680:	eb05017f 	cmp	x11, x5
    9684:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9688:	8b058149 	add	x9, x10, x5, lsl #32
    968c:	8b458063 	add	x3, x3, x5, lsr #32
    9690:	eb03003f 	cmp	x1, x3
    9694:	54000063 	b.cc	96a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9698:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    969c:	54000082 	b.cs	96ac <__modti3+0x1cc>  // b.hs, b.nlast
    96a0:	eb020129 	subs	x9, x9, x2
    96a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    96a8:	cb070063 	sub	x3, x3, x7
    96ac:	eb090000 	subs	x0, x0, x9
    96b0:	da030021 	sbc	x1, x1, x3
    96b4:	9ac62400 	lsr	x0, x0, x6
    96b8:	9ac82028 	lsl	x8, x1, x8
    96bc:	aa000100 	orr	x0, x8, x0
    96c0:	9ac62421 	lsr	x1, x1, x6
    96c4:	17ffffb4 	b	9594 <__modti3+0xb4>
    96c8:	b5000062 	cbnz	x2, 96d4 <__modti3+0x1f4>
    96cc:	d2800023 	mov	x3, #0x1                   	// #1
    96d0:	9ac20862 	udiv	x2, x3, x2
    96d4:	dac01048 	clz	x8, x2
    96d8:	aa0803e5 	mov	x5, x8
    96dc:	b5000668 	cbnz	x8, 97a8 <__modti3+0x2c8>
    96e0:	cb020020 	sub	x0, x1, x2
    96e4:	d360fc49 	lsr	x9, x2, #32
    96e8:	92407c4a 	and	x10, x2, #0xffffffff
    96ec:	9ac90801 	udiv	x1, x0, x9
    96f0:	9b098020 	msub	x0, x1, x9, x0
    96f4:	9b0a7c21 	mul	x1, x1, x10
    96f8:	93c78000 	extr	x0, x0, x7, #32
    96fc:	eb00003f 	cmp	x1, x0
    9700:	540000a9 	b.ls	9714 <__modti3+0x234>  // b.plast
    9704:	ab000040 	adds	x0, x2, x0
    9708:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    970c:	8b020003 	add	x3, x0, x2
    9710:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9714:	cb010001 	sub	x1, x0, x1
    9718:	9ac90820 	udiv	x0, x1, x9
    971c:	9b098403 	msub	x3, x0, x9, x1
    9720:	aa0703e1 	mov	x1, x7
    9724:	9b0a7c00 	mul	x0, x0, x10
    9728:	b3607c61 	bfi	x1, x3, #32, #32
    972c:	eb01001f 	cmp	x0, x1
    9730:	540000a9 	b.ls	9744 <__modti3+0x264>  // b.plast
    9734:	ab010041 	adds	x1, x2, x1
    9738:	8b020022 	add	x2, x1, x2
    973c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9740:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9744:	cb000020 	sub	x0, x1, x0
    9748:	17ffff91 	b	958c <__modti3+0xac>
    974c:	eb0203e5 	negs	x5, x2
    9750:	aa0003e7 	mov	x7, x0
    9754:	da0303e8 	ngc	x8, x3
    9758:	aa0503e2 	mov	x2, x5
    975c:	aa0803e3 	mov	x3, x8
    9760:	aa0103e6 	mov	x6, x1
    9764:	b4ffed48 	cbz	x8, 950c <__modti3+0x2c>
    9768:	eb01011f 	cmp	x8, x1
    976c:	54fff148 	b.hi	9594 <__modti3+0xb4>  // b.pmore
    9770:	dac01109 	clz	x9, x8
    9774:	2a0903e6 	mov	w6, w9
    9778:	b5fff1c9 	cbnz	x9, 95b0 <__modti3+0xd0>
    977c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9780:	54000068 	b.hi	978c <__modti3+0x2ac>  // b.pmore
    9784:	eb050007 	subs	x7, x0, x5
    9788:	da080021 	sbc	x1, x1, x8
    978c:	aa0703e0 	mov	x0, x7
    9790:	17ffff81 	b	9594 <__modti3+0xb4>
    9794:	ab000040 	adds	x0, x2, x0
    9798:	8b020002 	add	x2, x0, x2
    979c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    97a0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    97a4:	17ffff79 	b	9588 <__modti3+0xa8>
    97a8:	9ac82042 	lsl	x2, x2, x8
    97ac:	d2800803 	mov	x3, #0x40                  	// #64
    97b0:	cb080063 	sub	x3, x3, x8
    97b4:	d360fc49 	lsr	x9, x2, #32
    97b8:	9ac82027 	lsl	x7, x1, x8
    97bc:	92407c4a 	and	x10, x2, #0xffffffff
    97c0:	9ac32426 	lsr	x6, x1, x3
    97c4:	9ac32403 	lsr	x3, x0, x3
    97c8:	aa070063 	orr	x3, x3, x7
    97cc:	9ac908c1 	udiv	x1, x6, x9
    97d0:	9ac82007 	lsl	x7, x0, x8
    97d4:	9b099820 	msub	x0, x1, x9, x6
    97d8:	9b017d41 	mul	x1, x10, x1
    97dc:	93c38000 	extr	x0, x0, x3, #32
    97e0:	eb00003f 	cmp	x1, x0
    97e4:	540000a9 	b.ls	97f8 <__modti3+0x318>  // b.plast
    97e8:	ab000040 	adds	x0, x2, x0
    97ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    97f0:	8b020006 	add	x6, x0, x2
    97f4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    97f8:	cb010000 	sub	x0, x0, x1
    97fc:	9ac90801 	udiv	x1, x0, x9
    9800:	9b098026 	msub	x6, x1, x9, x0
    9804:	aa0303e0 	mov	x0, x3
    9808:	9b017d41 	mul	x1, x10, x1
    980c:	b3607cc0 	bfi	x0, x6, #32, #32
    9810:	eb00003f 	cmp	x1, x0
    9814:	540000a9 	b.ls	9828 <__modti3+0x348>  // b.plast
    9818:	ab000040 	adds	x0, x2, x0
    981c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9820:	8b020003 	add	x3, x0, x2
    9824:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9828:	cb010000 	sub	x0, x0, x1
    982c:	17ffffb0 	b	96ec <__modti3+0x20c>
    9830:	d1000969 	sub	x9, x11, #0x2
    9834:	8b070021 	add	x1, x1, x7
    9838:	17ffff83 	b	9644 <__modti3+0x164>
    983c:	d1000965 	sub	x5, x11, #0x2
    9840:	8b070063 	add	x3, x3, x7
    9844:	17ffff74 	b	9614 <__modti3+0x134>
    9848:	d503201f 	nop
    984c:	d503201f 	nop

0000000000009850 <atexit>:
    9850:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9854:	f00000a2 	adrp	x2, 20000 <__data_start>
    9858:	d2800001 	mov	x1, #0x0                   	// #0
    985c:	910003fd 	mov	x29, sp
    9860:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9864:	f9400442 	ldr	x2, [x2, #8]
    9868:	17ffe3ea 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000986c <_fini>:
    986c:	d503201f 	nop
    9870:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9874:	910003fd 	mov	x29, sp
    9878:	a8c17bfd 	ldp	x29, x30, [sp], #16
    987c:	d65f03c0 	ret
