
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__divti3+0x1e0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912020a5 	add	x5, x5, #0x808
    2aa0:	f0000024 	adrp	x4, 9000 <__divti3+0x1e0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91204084 	add	x4, x4, #0x810
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940004f0 	bl	3e90 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9100c2a1 	add	x1, x21, #0x30
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12c30>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9003c20 	str	x0, [x1, #120]
    2b2c:	940006f9 	bl	4710 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2b34:	9129a000 	add	x0, x0, #0xa68
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xd3c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910ac042 	add	x2, x2, #0x2b0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c2b5 	add	x21, x21, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b94302a0 	ldr	w0, [x21, #768]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2c4c:	912a6000 	add	x0, x0, #0xa98
    2c50:	94000490 	bl	3e90 <fwp_trap>
    2c54:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2c58:	9129e000 	add	x0, x0, #0xa78
    2c5c:	9400048d 	bl	3e90 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2ca0:	912bc000 	add	x0, x0, #0xaf0
    2ca4:	9400047b 	bl	3e90 <fwp_trap>
    2ca8:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2cac:	912b0000 	add	x0, x0, #0xac0
    2cb0:	94000478 	bl	3e90 <fwp_trap>
    2cb4:	f0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    2cb8:	912c6000 	add	x0, x0, #0xb18
    2cbc:	94000475 	bl	3e90 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91006000 	add	x0, x0, #0x18
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91006021 	add	x1, x1, #0x18
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91006000 	add	x0, x0, #0x18
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91006021 	add	x1, x1, #0x18
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0xac0>
    2eb4:	9104c021 	add	x1, x1, #0x130
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3050:	91152000 	add	x0, x0, #0x548
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0xac0>
    3118:	91044021 	add	x1, x1, #0x110
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3144:	9114c2a1 	add	x1, x21, #0x530
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    3158:	912480a5 	add	x5, x5, #0x920
    315c:	9114c2a1 	add	x1, x21, #0x530
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	9114c2b7 	add	x23, x21, #0x530
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	9114c2b5 	add	x21, x21, #0x530
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	9114c2b5 	add	x21, x21, #0x530
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    32e8:	912460a5 	add	x5, x5, #0x918
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    33f0:	91152000 	add	x0, x0, #0x548
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000021 	adrp	x1, 9000 <__divti3+0x1e0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91158021 	add	x1, x1, #0x560
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000021 	adrp	x1, 9000 <__divti3+0x1e0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	9115a021 	add	x1, x1, #0x568
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000021 	adrp	x1, 9000 <__divti3+0x1e0>
    3560:	9115c021 	add	x1, x1, #0x570
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_format_g.constprop.0>:
    3580:	d10483ff 	sub	sp, sp, #0x120
    3584:	d0000024 	adrp	x4, 9000 <__divti3+0x1e0>
    3588:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    358c:	f947f442 	ldr	x2, [x2, #4072]
    3590:	9115e084 	add	x4, x4, #0x578
    3594:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3598:	9102c3fd 	add	x29, sp, #0xb0
    359c:	d2800803 	mov	x3, #0x40                  	// #64
    35a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    35a4:	93407c38 	sxtw	x24, w1
    35a8:	aa0303e1 	mov	x1, x3
    35ac:	fd008be8 	str	d8, [sp, #272]
    35b0:	1e604008 	fmov	d8, d0
    35b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    35b8:	910083f4 	add	x20, sp, #0x20
    35bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    35c0:	aa0003f5 	mov	x21, x0
    35c4:	a91073fb 	stp	x27, x28, [sp, #256]
    35c8:	5100071c 	sub	w28, w24, #0x1
    35cc:	2a1c03e5 	mov	w5, w28
    35d0:	f9400040 	ldr	x0, [x2]
    35d4:	f90057e0 	str	x0, [sp, #168]
    35d8:	d2800000 	mov	x0, #0x0                   	// #0
    35dc:	52800042 	mov	w2, #0x2                   	// #2
    35e0:	aa1403e0 	mov	x0, x20
    35e4:	97fffc83 	bl	27f0 <__snprintf_chk@plt>
    35e8:	52800ca1 	mov	w1, #0x65                  	// #101
    35ec:	aa1403e0 	mov	x0, x20
    35f0:	97fffcdc 	bl	2960 <strchr@plt>
    35f4:	aa0003f3 	mov	x19, x0
    35f8:	52800142 	mov	w2, #0xa                   	// #10
    35fc:	91000400 	add	x0, x0, #0x1
    3600:	d2800001 	mov	x1, #0x0                   	// #0
    3604:	97fffcc7 	bl	2920 <strtol@plt>
    3608:	aa0003f7 	mov	x23, x0
    360c:	11001400 	add	w0, w0, #0x5
    3610:	7100541f 	cmp	w0, #0x15
    3614:	54000d68 	b.hi	37c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3618:	4b170385 	sub	w5, w28, w23
    361c:	710000bf 	cmp	w5, #0x0
    3620:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3624:	54000b80 	b.eq	3794 <fwp_format_g.constprop.0+0x214>  // b.none
    3628:	394083e0 	ldrb	w0, [sp, #32]
    362c:	cb180273 	sub	x19, x19, x24
    3630:	91000673 	add	x19, x19, #0x1
    3634:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3638:	7100b41f 	cmp	w0, #0x2d
    363c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3640:	1a9f17e4 	cset	w4, eq	// eq = none
    3644:	cb010266 	sub	x6, x19, x1
    3648:	d10004da 	sub	x26, x6, #0x1
    364c:	540018a0 	b.eq	3960 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3650:	910183f9 	add	x25, sp, #0x60
    3654:	d280091b 	mov	x27, #0x48                  	// #72
    3658:	aa1903e7 	mov	x7, x25
    365c:	91000423 	add	x3, x1, #0x1
    3660:	91011cc6 	add	x6, x6, #0x47
    3664:	910004f6 	add	x22, x7, #0x1
    3668:	37f80ff7 	tbnz	w23, #31, 3864 <fwp_format_g.constprop.0+0x2e4>
    366c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3670:	93407ef7 	sxtw	x23, w23
    3674:	390000e4 	strb	w4, [x7]
    3678:	aa1303e1 	mov	x1, x19
    367c:	aa1703e2 	mov	x2, x23
    3680:	aa1603e0 	mov	x0, x22
    3684:	b9000be5 	str	w5, [sp, #8]
    3688:	cb170374 	sub	x20, x27, x23
    368c:	a9011be3 	stp	x3, x6, [sp, #16]
    3690:	97fffc10 	bl	26d0 <memcpy@plt>
    3694:	d1000694 	sub	x20, x20, #0x1
    3698:	f9400be3 	ldr	x3, [sp, #16]
    369c:	8b1702d6 	add	x22, x22, x23
    36a0:	aa1603e0 	mov	x0, x22
    36a4:	aa1a03e2 	mov	x2, x26
    36a8:	aa0303e1 	mov	x1, x3
    36ac:	aa1403e3 	mov	x3, x20
    36b0:	97fffc48 	bl	27d0 <__memcpy_chk@plt>
    36b4:	8b1a02d6 	add	x22, x22, x26
    36b8:	f9400fe6 	ldr	x6, [sp, #24]
    36bc:	d2800900 	mov	x0, #0x48                  	// #72
    36c0:	b9400be5 	ldr	w5, [sp, #8]
    36c4:	8b170261 	add	x1, x19, x23
    36c8:	cb1400c3 	sub	x3, x6, x20
    36cc:	cb060294 	sub	x20, x20, x6
    36d0:	f101207f 	cmp	x3, #0x48
    36d4:	93407cb8 	sxtw	x24, w5
    36d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    36dc:	aa1803e2 	mov	x2, x24
    36e0:	8b1802d3 	add	x19, x22, x24
    36e4:	8b140063 	add	x3, x3, x20
    36e8:	aa1603e0 	mov	x0, x22
    36ec:	97fffc39 	bl	27d0 <__memcpy_chk@plt>
    36f0:	cb190273 	sub	x19, x19, x25
    36f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    36f8:	eb00027f 	cmp	x19, x0
    36fc:	aa1903e1 	mov	x1, x25
    3700:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3704:	aa1503e0 	mov	x0, x21
    3708:	aa1303e2 	mov	x2, x19
    370c:	97fffbf1 	bl	26d0 <memcpy@plt>
    3710:	38336abf 	strb	wzr, [x21, x19]
    3714:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3718:	aa1503e0 	mov	x0, x21
    371c:	97fffbfd 	bl	2710 <strlen@plt>
    3720:	aa0003f3 	mov	x19, x0
    3724:	528005c1 	mov	w1, #0x2e                  	// #46
    3728:	aa1503e0 	mov	x0, x21
    372c:	97fffc8d 	bl	2960 <strchr@plt>
    3730:	b4000140 	cbz	x0, 3758 <fwp_format_g.constprop.0+0x1d8>
    3734:	b4000133 	cbz	x19, 3758 <fwp_format_g.constprop.0+0x1d8>
    3738:	aa1303e1 	mov	x1, x19
    373c:	d1000673 	sub	x19, x19, #0x1
    3740:	38736aa0 	ldrb	w0, [x21, x19]
    3744:	7100c01f 	cmp	w0, #0x30
    3748:	54001001 	b.ne	3948 <fwp_format_g.constprop.0+0x3c8>  // b.any
    374c:	38336abf 	strb	wzr, [x21, x19]
    3750:	b5ffff53 	cbnz	x19, 3738 <fwp_format_g.constprop.0+0x1b8>
    3754:	d503201f 	nop
    3758:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    375c:	f947f400 	ldr	x0, [x0, #4072]
    3760:	f94057e2 	ldr	x2, [sp, #168]
    3764:	f9400001 	ldr	x1, [x0]
    3768:	eb010042 	subs	x2, x2, x1
    376c:	d2800001 	mov	x1, #0x0                   	// #0
    3770:	54001061 	b.ne	397c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3774:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3778:	a94c53f3 	ldp	x19, x20, [sp, #192]
    377c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3780:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3784:	a95073fb 	ldp	x27, x28, [sp, #256]
    3788:	fd408be8 	ldr	d8, [sp, #272]
    378c:	910483ff 	add	sp, sp, #0x120
    3790:	d65f03c0 	ret
    3794:	1e604100 	fmov	d0, d8
    3798:	710000bf 	cmp	w5, #0x0
    379c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    37a0:	aa1503e0 	mov	x0, x21
    37a4:	d0000024 	adrp	x4, 9000 <__divti3+0x1e0>
    37a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37ac:	91164084 	add	x4, x4, #0x590
    37b0:	52800042 	mov	w2, #0x2                   	// #2
    37b4:	d2803201 	mov	x1, #0x190                 	// #400
    37b8:	97fffc0e 	bl	27f0 <__snprintf_chk@plt>
    37bc:	17ffffd7 	b	3718 <fwp_format_g.constprop.0+0x198>
    37c0:	cb140273 	sub	x19, x19, x20
    37c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    37c8:	910183f9 	add	x25, sp, #0x60
    37cc:	aa1303e2 	mov	x2, x19
    37d0:	aa1403e1 	mov	x1, x20
    37d4:	aa1903e0 	mov	x0, x25
    37d8:	d2800803 	mov	x3, #0x40                  	// #64
    37dc:	97fffbfd 	bl	27d0 <__memcpy_chk@plt>
    37e0:	38336b3f 	strb	wzr, [x25, x19]
    37e4:	aa1903e0 	mov	x0, x25
    37e8:	528005c1 	mov	w1, #0x2e                  	// #46
    37ec:	97fffc5d 	bl	2960 <strchr@plt>
    37f0:	b40001c0 	cbz	x0, 3828 <fwp_format_g.constprop.0+0x2a8>
    37f4:	b50000b3 	cbnz	x19, 3808 <fwp_format_g.constprop.0+0x288>
    37f8:	1400000c 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    37fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3800:	f1000673 	subs	x19, x19, #0x1
    3804:	54000120 	b.eq	3828 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3808:	8b130320 	add	x0, x25, x19
    380c:	385ff001 	ldurb	w1, [x0, #-1]
    3810:	7100c03f 	cmp	w1, #0x30
    3814:	54ffff40 	b.eq	37fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3818:	d1000673 	sub	x19, x19, #0x1
    381c:	38736b20 	ldrb	w0, [x25, x19]
    3820:	7100b81f 	cmp	w0, #0x2e
    3824:	54000a80 	b.eq	3974 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3828:	710002ff 	cmp	w23, #0x0
    382c:	528005a1 	mov	w1, #0x2d                  	// #45
    3830:	aa1903e5 	mov	x5, x25
    3834:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3838:	aa1503e0 	mov	x0, x21
    383c:	52800566 	mov	w6, #0x2b                  	// #43
    3840:	d0000024 	adrp	x4, 9000 <__divti3+0x1e0>
    3844:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3848:	91160084 	add	x4, x4, #0x580
    384c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3850:	52800042 	mov	w2, #0x2                   	// #2
    3854:	d2803201 	mov	x1, #0x190                 	// #400
    3858:	97fffbe6 	bl	27f0 <__snprintf_chk@plt>
    385c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3860:	17ffffbe 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3864:	52800605 	mov	w5, #0x30                  	// #48
    3868:	390000e5 	strb	w5, [x7]
    386c:	d100077b 	sub	x27, x27, #0x1
    3870:	aa0303e1 	mov	x1, x3
    3874:	aa1603e0 	mov	x0, x22
    3878:	aa1b03e3 	mov	x3, x27
    387c:	aa1a03e2 	mov	x2, x26
    3880:	f90007e6 	str	x6, [sp, #8]
    3884:	b90013e4 	str	w4, [sp, #16]
    3888:	8b1a02d6 	add	x22, x22, x26
    388c:	b9001be5 	str	w5, [sp, #24]
    3890:	97fffbd0 	bl	27d0 <__memcpy_chk@plt>
    3894:	f94007e6 	ldr	x6, [sp, #8]
    3898:	2a3703e7 	mvn	w7, w23
    389c:	b94013e4 	ldr	w4, [sp, #16]
    38a0:	cb1b00c1 	sub	x1, x6, x27
    38a4:	cb06037b 	sub	x27, x27, x6
    38a8:	f101203f 	cmp	x1, #0x48
    38ac:	d2800906 	mov	x6, #0x48                  	// #72
    38b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    38b4:	8b1b0023 	add	x3, x1, x27
    38b8:	310006ff 	cmn	w23, #0x1
    38bc:	54000220 	b.eq	3900 <fwp_format_g.constprop.0+0x380>  // b.none
    38c0:	b9401be5 	ldr	w5, [sp, #24]
    38c4:	d2800001 	mov	x1, #0x0                   	// #0
    38c8:	f101207f 	cmp	x3, #0x48
    38cc:	d1000462 	sub	x2, x3, #0x1
    38d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    38d4:	38216ac5 	strb	w5, [x22, x1]
    38d8:	cb030003 	sub	x3, x0, x3
    38dc:	91000421 	add	x1, x1, #0x1
    38e0:	91000463 	add	x3, x3, #0x1
    38e4:	eb00007f 	cmp	x3, x0
    38e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38ec:	cb000063 	sub	x3, x3, x0
    38f0:	8b020063 	add	x3, x3, x2
    38f4:	6b0100ff 	cmp	w7, w1
    38f8:	54fffe8c 	b.gt	38c8 <fwp_format_g.constprop.0+0x348>
    38fc:	8b2742d6 	add	x22, x22, w7, uxtw
    3900:	f101207f 	cmp	x3, #0x48
    3904:	d2800905 	mov	x5, #0x48                  	// #72
    3908:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    390c:	aa1603e0 	mov	x0, x22
    3910:	cb0300a1 	sub	x1, x5, x3
    3914:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3918:	91000421 	add	x1, x1, #0x1
    391c:	d1000463 	sub	x3, x3, #0x1
    3920:	eb05003f 	cmp	x1, x5
    3924:	38001402 	strb	w2, [x0], #1
    3928:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    392c:	93407f82 	sxtw	x2, w28
    3930:	cb050025 	sub	x5, x1, x5
    3934:	aa1303e1 	mov	x1, x19
    3938:	8b0300a3 	add	x3, x5, x3
    393c:	8b1802d3 	add	x19, x22, x24
    3940:	97fffba4 	bl	27d0 <__memcpy_chk@plt>
    3944:	17ffff6b 	b	36f0 <fwp_format_g.constprop.0+0x170>
    3948:	d1000421 	sub	x1, x1, #0x1
    394c:	38616aa0 	ldrb	w0, [x21, x1]
    3950:	7100b81f 	cmp	w0, #0x2e
    3954:	54fff021 	b.ne	3758 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3958:	38216abf 	strb	wzr, [x21, x1]
    395c:	17ffff7f 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3960:	910187e7 	add	x7, sp, #0x61
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d28008fb 	mov	x27, #0x47                  	// #71
    396c:	390183e0 	strb	w0, [sp, #96]
    3970:	17ffff3b 	b	365c <fwp_format_g.constprop.0+0xdc>
    3974:	38336b3f 	strb	wzr, [x25, x19]
    3978:	17ffffac 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    397c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3980:	97fffbc0 	bl	2880 <__stack_chk_fail@plt>

0000000000003984 <fwp_heap_report>:
    3984:	d105c3ff 	sub	sp, sp, #0x170
    3988:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    398c:	9114c042 	add	x2, x2, #0x530
    3990:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3994:	f947e821 	ldr	x1, [x1, #4048]
    3998:	a9117bfd 	stp	x29, x30, [sp, #272]
    399c:	910443fd 	add	x29, sp, #0x110
    39a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    39a4:	f947f400 	ldr	x0, [x0, #4072]
    39a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    39ac:	a91463f7 	stp	x23, x24, [sp, #320]
    39b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    39b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    39b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    39bc:	fd4a2049 	ldr	d9, [x2, #5184]
    39c0:	f9400036 	ldr	x22, [x1]
    39c4:	f9400001 	ldr	x1, [x0]
    39c8:	f90087e1 	str	x1, [sp, #264]
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	f949e459 	ldr	x25, [x2, #5064]
    39d4:	d0000021 	adrp	x1, 9000 <__divti3+0x1e0>
    39d8:	f94a1057 	ldr	x23, [x2, #5152]
    39dc:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    39e0:	f94a1458 	ldr	x24, [x2, #5160]
    39e4:	91166021 	add	x1, x1, #0x598
    39e8:	91168000 	add	x0, x0, #0x5a0
    39ec:	97fffb89 	bl	2810 <fopen@plt>
    39f0:	b4000760 	cbz	x0, 3adc <fwp_heap_report+0x158>
    39f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    39f8:	a91253f3 	stp	x19, x20, [sp, #288]
    39fc:	aa0003f4 	mov	x20, x0
    3a00:	910023f3 	add	x19, sp, #0x8
    3a04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a08:	72aae915 	movk	w21, #0x5748, lsl #16
    3a0c:	d503201f 	nop
    3a10:	aa1403e2 	mov	x2, x20
    3a14:	aa1303e0 	mov	x0, x19
    3a18:	52802001 	mov	w1, #0x100                 	// #256
    3a1c:	97fffc09 	bl	2a40 <fgets@plt>
    3a20:	b4000280 	cbz	x0, 3a70 <fwp_heap_report+0xec>
    3a24:	b9400261 	ldr	w1, [x19]
    3a28:	6b15003f 	cmp	w1, w21
    3a2c:	54ffff21 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a30:	39401260 	ldrb	w0, [x19, #4]
    3a34:	7101341f 	cmp	w0, #0x4d
    3a38:	54fffec1 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a3c:	394037e0 	ldrb	w0, [sp, #13]
    3a40:	7100e81f 	cmp	w0, #0x3a
    3a44:	54fffe61 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a48:	52800142 	mov	w2, #0xa                   	// #10
    3a4c:	d2800001 	mov	x1, #0x0                   	// #0
    3a50:	91003be0 	add	x0, sp, #0xe
    3a54:	97fffbb3 	bl	2920 <strtol@plt>
    3a58:	aa1403e2 	mov	x2, x20
    3a5c:	aa0003fa 	mov	x26, x0
    3a60:	52802001 	mov	w1, #0x100                 	// #256
    3a64:	aa1303e0 	mov	x0, x19
    3a68:	97fffbf6 	bl	2a40 <fgets@plt>
    3a6c:	b5fffdc0 	cbnz	x0, 3a24 <fwp_heap_report+0xa0>
    3a70:	aa1403e0 	mov	x0, x20
    3a74:	97fffb63 	bl	2800 <fclose@plt>
    3a78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3a7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a80:	f947f400 	ldr	x0, [x0, #4072]
    3a84:	f94087e2 	ldr	x2, [sp, #264]
    3a88:	f9400001 	ldr	x1, [x0]
    3a8c:	eb010042 	subs	x2, x2, x1
    3a90:	d2800001 	mov	x1, #0x0                   	// #0
    3a94:	54000281 	b.ne	3ae4 <fwp_heap_report+0x160>  // b.any
    3a98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a9c:	aa1a03e6 	mov	x6, x26
    3aa0:	aa1903e5 	mov	x5, x25
    3aa4:	aa1803e4 	mov	x4, x24
    3aa8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3aac:	aa1703e3 	mov	x3, x23
    3ab0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3abc:	1e604121 	fmov	d1, d9
    3ac0:	1e604100 	fmov	d0, d8
    3ac4:	d0000022 	adrp	x2, 9000 <__divti3+0x1e0>
    3ac8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3acc:	91170042 	add	x2, x2, #0x5c0
    3ad0:	9105c3ff 	add	sp, sp, #0x170
    3ad4:	52800041 	mov	w1, #0x2                   	// #2
    3ad8:	17fffb86 	b	28f0 <__fprintf_chk@plt>
    3adc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ae0:	17ffffe7 	b	3a7c <fwp_heap_report+0xf8>
    3ae4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ae8:	97fffb66 	bl	2880 <__stack_chk_fail@plt>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_heap_init>:
    3af0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3af4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xad0>
    3af8:	9110c061 	add	x1, x3, #0x430
    3afc:	910003fd 	mov	x29, sp
    3b00:	a90153f3 	stp	x19, x20, [sp, #16]
    3b04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3b08:	9114c262 	add	x2, x19, #0x530
    3b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b10:	52800024 	mov	w4, #0x1                   	// #1
    3b14:	52800200 	mov	w0, #0x10                  	// #16
    3b18:	b913a444 	str	w4, [x2, #5028]
    3b1c:	d503201f 	nop
    3b20:	b8004420 	str	w0, [x1], #4
    3b24:	11004000 	add	w0, w0, #0x10
    3b28:	7104401f 	cmp	w0, #0x110
    3b2c:	54ffffa1 	b.ne	3b20 <fwp_heap_init+0x30>  // b.any
    3b30:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0xac0>
    3b34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3b38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xad0>
    3b3c:	9111c021 	add	x1, x1, #0x470
    3b40:	3dc05043 	ldr	q3, [x2, #320]
    3b44:	d2800000 	mov	x0, #0x0                   	// #0
    3b48:	4e040401 	dup	v1.4s, v0.s[0]
    3b4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3b50:	0f215400 	shl	v0.2s, v0.2s, #1
    3b54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3b58:	3ca06821 	str	q1, [x1, x0]
    3b5c:	91004000 	add	x0, x0, #0x10
    3b60:	f101801f 	cmp	x0, #0x60
    3b64:	54ffff21 	b.ne	3b48 <fwp_heap_init+0x58>  // b.any
    3b68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xad0>
    3b6c:	9110c063 	add	x3, x3, #0x430
    3b70:	91134084 	add	x4, x4, #0x4d0
    3b74:	9114c266 	add	x6, x19, #0x530
    3b78:	d2800002 	mov	x2, #0x0                   	// #0
    3b7c:	d2800000 	mov	x0, #0x0                   	// #0
    3b80:	d2880205 	mov	x5, #0x4010                	// #16400
    3b84:	d503201f 	nop
    3b88:	910f0001 	add	x1, x0, #0x3c0
    3b8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b90:	eb02003f 	cmp	x1, x2
    3b94:	540000a2 	b.cs	3ba8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b98:	91000400 	add	x0, x0, #0x1
    3b9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ba0:	eb02003f 	cmp	x1, x2
    3ba4:	54ffffa3 	b.cc	3b98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ba8:	91004042 	add	x2, x2, #0x10
    3bac:	38001480 	strb	w0, [x4], #1
    3bb0:	eb05005f 	cmp	x2, x5
    3bb4:	54fffea1 	b.ne	3b88 <fwp_heap_init+0x98>  // b.any
    3bb8:	528000b5 	mov	w21, #0x5                   	// #5
    3bbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3bc0:	14000004 	b	3bd0 <fwp_heap_init+0xe0>
    3bc4:	d342fe94 	lsr	x20, x20, #2
    3bc8:	710006b5 	subs	w21, w21, #0x1
    3bcc:	54000720 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3bd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3bd4:	d2800005 	mov	x5, #0x0                   	// #0
    3bd8:	aa1603e1 	mov	x1, x22
    3bdc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3be0:	52880443 	mov	w3, #0x4022                	// #16418
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	d2800000 	mov	x0, #0x0                   	// #0
    3bec:	97fffb49 	bl	2910 <mmap@plt>
    3bf0:	aa0003e6 	mov	x6, x0
    3bf4:	b100041f 	cmn	x0, #0x1
    3bf8:	54fffe60 	b.eq	3bc4 <fwp_heap_init+0xd4>  // b.none
    3bfc:	b40005a0 	cbz	x0, 3cb0 <fwp_heap_init+0x1c0>
    3c00:	d350fe94 	lsr	x20, x20, #16
    3c04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3c08:	8b0000c7 	add	x7, x6, x0
    3c0c:	9114c275 	add	x21, x19, #0x530
    3c10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3c14:	8b140a81 	add	x1, x20, x20, lsl #2
    3c18:	d2800005 	mov	x5, #0x0                   	// #0
    3c1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3c20:	d37df021 	lsl	x1, x1, #3
    3c24:	52880443 	mov	w3, #0x4022                	// #16418
    3c28:	52800002 	mov	w2, #0x0                   	// #0
    3c2c:	d2800000 	mov	x0, #0x0                   	// #0
    3c30:	f909daa7 	str	x7, [x21, #5040]
    3c34:	f909dea6 	str	x6, [x21, #5048]
    3c38:	f909e2b6 	str	x22, [x21, #5056]
    3c3c:	f909eab4 	str	x20, [x21, #5072]
    3c40:	f90a02a1 	str	x1, [x21, #5120]
    3c44:	97fffb33 	bl	2910 <mmap@plt>
    3c48:	aa0003e1 	mov	x1, x0
    3c4c:	b100041f 	cmn	x0, #0x1
    3c50:	54000300 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3c54:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3c58:	91192000 	add	x0, x0, #0x648
    3c5c:	f909fea1 	str	x1, [x21, #5112]
    3c60:	97fffb6c 	bl	2a10 <getenv@plt>
    3c64:	52800002 	mov	w2, #0x0                   	// #0
    3c68:	aa0003e1 	mov	x1, x0
    3c6c:	b40000e0 	cbz	x0, 3c88 <fwp_heap_init+0x198>
    3c70:	39400000 	ldrb	w0, [x0]
    3c74:	340000a0 	cbz	w0, 3c88 <fwp_heap_init+0x198>
    3c78:	7100c000 	subs	w0, w0, #0x30
    3c7c:	54000120 	b.eq	3ca0 <fwp_heap_init+0x1b0>  // b.none
    3c80:	7100001f 	cmp	w0, #0x0
    3c84:	1a9f07e2 	cset	w2, ne	// ne = any
    3c88:	9114c273 	add	x19, x19, #0x530
    3c8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c90:	b913aa62 	str	w2, [x19, #5032]
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c9c:	d65f03c0 	ret
    3ca0:	39400420 	ldrb	w0, [x1, #1]
    3ca4:	7100001f 	cmp	w0, #0x0
    3ca8:	1a9f07e2 	cset	w2, ne	// ne = any
    3cac:	17fffff7 	b	3c88 <fwp_heap_init+0x198>
    3cb0:	97fffce0 	bl	3030 <fwp_heap_oom>

0000000000003cb4 <fwp_wake_io>:
    3cb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3cb8:	9100c122 	add	x2, x9, #0x30
    3cbc:	f9400001 	ldr	x1, [x0]
    3cc0:	5280000a 	mov	w10, #0x0                   	// #0
    3cc4:	f9401446 	ldr	x6, [x2, #40]
    3cc8:	52800008 	mov	w8, #0x0                   	// #0
    3ccc:	4f000400 	movi	v0.4s, #0x0
    3cd0:	52800027 	mov	w7, #0x1                   	// #1
    3cd4:	aa0103e2 	mov	x2, x1
    3cd8:	b4000321 	cbz	x1, 3d3c <fwp_wake_io+0x88>
    3cdc:	f9408c25 	ldr	x5, [x1, #280]
    3ce0:	39015c27 	strb	w7, [x1, #87]
    3ce4:	b4000165 	cbz	x5, 3d10 <fwp_wake_io+0x5c>
    3ce8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3cec:	b4000364 	cbz	x4, 3d58 <fwp_wake_io+0xa4>
    3cf0:	f9009483 	str	x3, [x4, #296]
    3cf4:	f9409423 	ldr	x3, [x1, #296]
    3cf8:	b4000043 	cbz	x3, 3d00 <fwp_wake_io+0x4c>
    3cfc:	f9009064 	str	x4, [x3, #288]
    3d00:	91080023 	add	x3, x1, #0x200
    3d04:	f900943f 	str	xzr, [x1, #296]
    3d08:	3c918060 	stur	q0, [x3, #-232]
    3d0c:	f9400001 	ldr	x1, [x0]
    3d10:	f9402843 	ldr	x3, [x2, #80]
    3d14:	f2001c7f 	tst	x3, #0xff000000ff
    3d18:	54fffde1 	b.ne	3cd4 <fwp_wake_io+0x20>  // b.any
    3d1c:	39015047 	strb	w7, [x2, #84]
    3d20:	f900805f 	str	xzr, [x2, #256]
    3d24:	b40001e6 	cbz	x6, 3d60 <fwp_wake_io+0xac>
    3d28:	f90080c2 	str	x2, [x6, #256]
    3d2c:	aa0203e6 	mov	x6, x2
    3d30:	52800028 	mov	w8, #0x1                   	// #1
    3d34:	aa0103e2 	mov	x2, x1
    3d38:	b5fffd21 	cbnz	x1, 3cdc <fwp_wake_io+0x28>
    3d3c:	3400006a 	cbz	w10, 3d48 <fwp_wake_io+0x94>
    3d40:	9100c120 	add	x0, x9, #0x30
    3d44:	f900180b 	str	x11, [x0, #48]
    3d48:	34000068 	cbz	w8, 3d54 <fwp_wake_io+0xa0>
    3d4c:	9100c129 	add	x9, x9, #0x30
    3d50:	f9001526 	str	x6, [x9, #40]
    3d54:	d65f03c0 	ret
    3d58:	f90000a3 	str	x3, [x5]
    3d5c:	17ffffe7 	b	3cf8 <fwp_wake_io+0x44>
    3d60:	aa0203eb 	mov	x11, x2
    3d64:	5280002a 	mov	w10, #0x1                   	// #1
    3d68:	17fffff1 	b	3d2c <fwp_wake_io+0x78>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_tape_buffers_release>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	910003fd 	mov	x29, sp
    3d78:	a90153f3 	stp	x19, x20, [sp, #16]
    3d7c:	aa0003f3 	mov	x19, x0
    3d80:	f9401400 	ldr	x0, [x0, #40]
    3d84:	b7f80760 	tbnz	x0, #63, 3e70 <fwp_tape_buffers_release+0x100>
    3d88:	f9401a61 	ldr	x1, [x19, #48]
    3d8c:	b7f80301 	tbnz	x1, #63, 3dec <fwp_tape_buffers_release+0x7c>
    3d90:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d94:	eb02001f 	cmp	x0, x2
    3d98:	540002a8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d9c:	8b000400 	add	x0, x0, x0, lsl #1
    3da0:	d2a00102 	mov	x2, #0x80000               	// #524288
    3da4:	d37df000 	lsl	x0, x0, #3
    3da8:	cb000042 	sub	x2, x2, x0
    3dac:	eb420c3f 	cmp	x1, x2, lsr #3
    3db0:	540001e8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3db4:	8b010c14 	add	x20, x0, x1, lsl #3
    3db8:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3dbc:	91196000 	add	x0, x0, #0x658
    3dc0:	97fffb14 	bl	2a10 <getenv@plt>
    3dc4:	b4000240 	cbz	x0, 3e0c <fwp_tape_buffers_release+0x9c>
    3dc8:	39400001 	ldrb	w1, [x0]
    3dcc:	7100c03f 	cmp	w1, #0x30
    3dd0:	540001e1 	b.ne	3e0c <fwp_tape_buffers_release+0x9c>  // b.any
    3dd4:	39400400 	ldrb	w0, [x0, #1]
    3dd8:	350001a0 	cbnz	w0, 3e0c <fwp_tape_buffers_release+0x9c>
    3ddc:	aa1303e0 	mov	x0, x19
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de8:	17fffd46 	b	3300 <fwp_tape_buffers_dispose>
    3dec:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3df0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df4:	91196000 	add	x0, x0, #0x658
    3df8:	97fffb06 	bl	2a10 <getenv@plt>
    3dfc:	b4ffff00 	cbz	x0, 3ddc <fwp_tape_buffers_release+0x6c>
    3e00:	39400001 	ldrb	w1, [x0]
    3e04:	7100c03f 	cmp	w1, #0x30
    3e08:	54fffe60 	b.eq	3dd4 <fwp_tape_buffers_release+0x64>  // b.none
    3e0c:	d1000681 	sub	x1, x20, #0x1
    3e10:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3e14:	eb00003f 	cmp	x1, x0
    3e18:	54fffe28 	b.hi	3ddc <fwp_tape_buffers_release+0x6c>  // b.pmore
    3e1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e20:	b00000f6 	adrp	x22, 20000 <__data_start>
    3e24:	9100c2d6 	add	x22, x22, #0x30
    3e28:	9100e2d5 	add	x21, x22, #0x38
    3e2c:	aa1503e0 	mov	x0, x21
    3e30:	97fffd34 	bl	3300 <fwp_tape_buffers_dispose>
    3e34:	ad400a61 	ldp	q1, q2, [x19]
    3e38:	f9003ad4 	str	x20, [x22, #112]
    3e3c:	4f000400 	movi	v0.4s, #0x0
    3e40:	ad000aa1 	stp	q1, q2, [x21]
    3e44:	3dc00a61 	ldr	q1, [x19, #32]
    3e48:	3d800aa1 	str	q1, [x21, #32]
    3e4c:	f9401a60 	ldr	x0, [x19, #48]
    3e50:	f9001aa0 	str	x0, [x21, #48]
    3e54:	f9001a7f 	str	xzr, [x19, #48]
    3e58:	ad000260 	stp	q0, q0, [x19]
    3e5c:	3d800a60 	str	q0, [x19, #32]
    3e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e6c:	d65f03c0 	ret
    3e70:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3e74:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3e78:	91196000 	add	x0, x0, #0x658
    3e7c:	97fffae5 	bl	2a10 <getenv@plt>
    3e80:	b5fffa40 	cbnz	x0, 3dc8 <fwp_tape_buffers_release+0x58>
    3e84:	17ffffd6 	b	3ddc <fwp_tape_buffers_release+0x6c>
    3e88:	d503201f 	nop
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_trap>:
    3e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e94:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e98:	d53bd041 	mrs	x1, tpidr_el0
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	f9401c42 	ldr	x2, [x2, #56]
    3ea4:	91400021 	add	x1, x1, #0x0, lsl #12
    3ea8:	91004021 	add	x1, x1, #0x10
    3eac:	a90153f3 	stp	x19, x20, [sp, #16]
    3eb0:	aa0003f3 	mov	x19, x0
    3eb4:	f9400034 	ldr	x20, [x1]
    3eb8:	b4000062 	cbz	x2, 3ec4 <fwp_trap+0x34>
    3ebc:	aa0203e0 	mov	x0, x2
    3ec0:	97fffabc 	bl	29b0 <fflush@plt>
    3ec4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ec8:	f947ec00 	ldr	x0, [x0, #4056]
    3ecc:	f9400000 	ldr	x0, [x0]
    3ed0:	97fffab8 	bl	29b0 <fflush@plt>
    3ed4:	aa1303e3 	mov	x3, x19
    3ed8:	d0000022 	adrp	x2, 9000 <__divti3+0x1e0>
    3edc:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    3ee0:	f947ea73 	ldr	x19, [x19, #4048]
    3ee4:	9119c042 	add	x2, x2, #0x670
    3ee8:	52800041 	mov	w1, #0x2                   	// #2
    3eec:	f9400260 	ldr	x0, [x19]
    3ef0:	97fffa80 	bl	28f0 <__fprintf_chk@plt>
    3ef4:	b40000b4 	cbz	x20, 3f08 <fwp_trap+0x78>
    3ef8:	f9400260 	ldr	x0, [x19]
    3efc:	97fffaad 	bl	29b0 <fflush@plt>
    3f00:	52800ca0 	mov	w0, #0x65                  	// #101
    3f04:	97fffabb 	bl	29f0 <_Exit@plt>
    3f08:	52800ca0 	mov	w0, #0x65                  	// #101
    3f0c:	97fffa09 	bl	2730 <exit@plt>

0000000000003f10 <fwp_rc_forget_slot.part.0>:
    3f10:	ca404401 	eor	x1, x0, x0, lsr #17
    3f14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3f18:	ca412421 	eor	x1, x1, x1, lsr #9
    3f1c:	910003fd 	mov	x29, sp
    3f20:	92401c21 	and	x1, x1, #0xff
    3f24:	f9000bf3 	str	x19, [sp, #16]
    3f28:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3f2c:	9114c262 	add	x2, x19, #0x530
    3f30:	910a2423 	add	x3, x1, #0x289
    3f34:	8b010c41 	add	x1, x2, x1, lsl #3
    3f38:	8b030c43 	add	x3, x2, x3, lsl #3
    3f3c:	f94a2421 	ldr	x1, [x1, #5192]
    3f40:	b50000a1 	cbnz	x1, 3f54 <fwp_rc_forget_slot.part.0+0x44>
    3f44:	14000012 	b	3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f48:	91004023 	add	x3, x1, #0x10
    3f4c:	f9400821 	ldr	x1, [x1, #16]
    3f50:	b40001e1 	cbz	x1, 3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f54:	f9400022 	ldr	x2, [x1]
    3f58:	eb02001f 	cmp	x0, x2
    3f5c:	54ffff61 	b.ne	3f48 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3f60:	f9400060 	ldr	x0, [x3]
    3f64:	9114c273 	add	x19, x19, #0x530
    3f68:	f9400801 	ldr	x1, [x0, #16]
    3f6c:	f9000061 	str	x1, [x3]
    3f70:	97fffa74 	bl	2940 <free@plt>
    3f74:	f94e2660 	ldr	x0, [x19, #7240]
    3f78:	d1000400 	sub	x0, x0, #0x1
    3f7c:	f90e2660 	str	x0, [x19, #7240]
    3f80:	f9400bf3 	ldr	x19, [sp, #16]
    3f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f88:	d65f03c0 	ret
    3f8c:	d0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    3f90:	911a0000 	add	x0, x0, #0x680
    3f94:	97ffffbf 	bl	3e90 <fwp_trap>
    3f98:	d503201f 	nop
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_rc_prepare_chunk>:
    3fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3fa4:	910003fd 	mov	x29, sp
    3fa8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fac:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    3fb0:	9114c2c2 	add	x2, x22, #0x530
    3fb4:	b9401c03 	ldr	w3, [x0, #28]
    3fb8:	aa0103f5 	mov	x21, x1
    3fbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fc0:	aa0003f4 	mov	x20, x0
    3fc4:	f94e2440 	ldr	x0, [x2, #7240]
    3fc8:	b4000440 	cbz	x0, 4050 <fwp_rc_prepare_chunk+0xb0>
    3fcc:	d2800013 	mov	x19, #0x0                   	// #0
    3fd0:	35000203 	cbnz	w3, 4010 <fwp_rc_prepare_chunk+0x70>
    3fd4:	b4000361 	cbz	x1, 4040 <fwp_rc_prepare_chunk+0xa0>
    3fd8:	f9401280 	ldr	x0, [x20, #32]
    3fdc:	97fffa59 	bl	2940 <free@plt>
    3fe0:	aa1503e0 	mov	x0, x21
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	97fffa1e 	bl	2860 <calloc@plt>
    3fec:	f9001280 	str	x0, [x20, #32]
    3ff0:	b5000460 	cbnz	x0, 407c <fwp_rc_prepare_chunk+0xdc>
    3ff4:	97fffc0f 	bl	3030 <fwp_heap_oom>
    3ff8:	97ffffc6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    3ffc:	91000673 	add	x19, x19, #0x1
    4000:	b9401e83 	ldr	w3, [x20, #28]
    4004:	eb13007f 	cmp	x3, x19
    4008:	54000169 	b.ls	4034 <fwp_rc_prepare_chunk+0x94>  // b.plast
    400c:	d503201f 	nop
    4010:	f9401283 	ldr	x3, [x20, #32]
    4014:	8b130060 	add	x0, x3, x19
    4018:	38736863 	ldrb	w3, [x3, x19]
    401c:	7103fc7f 	cmp	w3, #0xff
    4020:	54fffec0 	b.eq	3ff8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4024:	b9401e83 	ldr	w3, [x20, #28]
    4028:	91000673 	add	x19, x19, #0x1
    402c:	eb13007f 	cmp	x3, x19
    4030:	54ffff08 	b.hi	4010 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4034:	eb0302bf 	cmp	x21, x3
    4038:	54000121 	b.ne	405c <fwp_rc_prepare_chunk+0xbc>  // b.any
    403c:	b5000335 	cbnz	x21, 40a0 <fwp_rc_prepare_chunk+0x100>
    4040:	a94153f3 	ldp	x19, x20, [sp, #16]
    4044:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    404c:	d65f03c0 	ret
    4050:	2a0303e3 	mov	w3, w3
    4054:	eb0302bf 	cmp	x21, x3
    4058:	54ffff20 	b.eq	403c <fwp_rc_prepare_chunk+0x9c>  // b.none
    405c:	9114c2c2 	add	x2, x22, #0x530
    4060:	f9401280 	ldr	x0, [x20, #32]
    4064:	f94e2841 	ldr	x1, [x2, #7248]
    4068:	cb030021 	sub	x1, x1, x3
    406c:	f90e2841 	str	x1, [x2, #7248]
    4070:	97fffa34 	bl	2940 <free@plt>
    4074:	b5fffb75 	cbnz	x21, 3fe0 <fwp_rc_prepare_chunk+0x40>
    4078:	f900129f 	str	xzr, [x20, #32]
    407c:	9114c2d6 	add	x22, x22, #0x530
    4080:	f94e2ac0 	ldr	x0, [x22, #7248]
    4084:	b9001e95 	str	w21, [x20, #28]
    4088:	a94153f3 	ldp	x19, x20, [sp, #16]
    408c:	8b150000 	add	x0, x0, x21
    4090:	f90e2ac0 	str	x0, [x22, #7248]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    409c:	d65f03c0 	ret
    40a0:	f9401280 	ldr	x0, [x20, #32]
    40a4:	aa1503e2 	mov	x2, x21
    40a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    40ac:	52800001 	mov	w1, #0x0                   	// #0
    40b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40b8:	17fff9e6 	b	2850 <memset@plt>
    40bc:	d503201f 	nop

00000000000040c0 <fwp_heap_refill>:
    40c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    40c4:	910003fd 	mov	x29, sp
    40c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    40cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    40d0:	9114c2b5 	add	x21, x21, #0x530
    40d4:	aa0003f6 	mov	x22, x0
    40d8:	d2800020 	mov	x0, #0x1                   	// #1
    40dc:	a90153f3 	stp	x19, x20, [sp, #16]
    40e0:	a90363f7 	stp	x23, x24, [sp, #48]
    40e4:	2a0103f7 	mov	w23, w1
    40e8:	2a0203f8 	mov	w24, w2
    40ec:	97fffc11 	bl	3130 <fwp_heap_chunks>
    40f0:	aa0003f3 	mov	x19, x0
    40f4:	f949fea2 	ldr	x2, [x21, #5112]
    40f8:	8b000800 	add	x0, x0, x0, lsl #2
    40fc:	2a1703e1 	mov	w1, w23
    4100:	52800025 	mov	w5, #0x1                   	// #1
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	910f0021 	add	x1, x1, #0x3c0
    410c:	8b000054 	add	x20, x2, x0
    4110:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4114:	52a00024 	mov	w4, #0x10000               	// #65536
    4118:	38206845 	strb	w5, [x2, x0]
    411c:	aa1403e0 	mov	x0, x20
    4120:	39000698 	strb	w24, [x20, #1]
    4124:	39000a97 	strb	w23, [x20, #2]
    4128:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    412c:	b9000681 	str	w1, [x20, #4]
    4130:	2a0103e5 	mov	w5, w1
    4134:	8b0300a2 	add	x2, x5, x3
    4138:	1ac10881 	udiv	w1, w4, w1
    413c:	9ac50842 	udiv	x2, x2, x5
    4140:	b9000a81 	str	w1, [x20, #8]
    4144:	92404021 	and	x1, x1, #0x1ffff
    4148:	b9001a82 	str	w2, [x20, #24]
    414c:	97ffff95 	bl	3fa0 <fwp_rc_prepare_chunk>
    4150:	f949daa0 	ldr	x0, [x21, #5040]
    4154:	29408a81 	ldp	w1, w2, [x20, #4]
    4158:	8b134000 	add	x0, x0, x19, lsl #16
    415c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4160:	8b214003 	add	x3, x0, w1, uxtw
    4164:	9ba20021 	umaddl	x1, w1, w2, x0
    4168:	a94363f7 	ldp	x23, x24, [sp, #48]
    416c:	a90086c3 	stp	x3, x1, [x22, #8]
    4170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4174:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4178:	d65f03c0 	ret
    417c:	d503201f 	nop

0000000000004180 <fwp_mem_free>:
    4180:	b40003c0 	cbz	x0, 41f8 <fwp_mem_free+0x78>
    4184:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4188:	910003fd 	mov	x29, sp
    418c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4190:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4194:	9114c2a1 	add	x1, x21, #0x530
    4198:	a90153f3 	stp	x19, x20, [sp, #16]
    419c:	aa0003f3 	mov	x19, x0
    41a0:	f949d823 	ldr	x3, [x1, #5040]
    41a4:	f949ec22 	ldr	x2, [x1, #5080]
    41a8:	cb030000 	sub	x0, x0, x3
    41ac:	eb02401f 	cmp	x0, x2, lsl #16
    41b0:	540001c2 	b.cs	41e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    41b4:	d350fc16 	lsr	x22, x0, #16
    41b8:	a90363f7 	stp	x23, x24, [sp, #48]
    41bc:	f949fc22 	ldr	x2, [x1, #5112]
    41c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    41c4:	d37df294 	lsl	x20, x20, #3
    41c8:	ab140057 	adds	x23, x2, x20
    41cc:	540000c0 	b.eq	41e4 <fwp_mem_free+0x64>  // b.none
    41d0:	38746842 	ldrb	w2, [x2, x20]
    41d4:	7100045f 	cmp	w2, #0x1
    41d8:	54000120 	b.eq	41fc <fwp_mem_free+0x7c>  // b.none
    41dc:	7100085f 	cmp	w2, #0x2
    41e0:	540005e0 	b.eq	429c <fwp_mem_free+0x11c>  // b.none
    41e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    41f4:	d65f03c0 	ret
    41f8:	d65f03c0 	ret
    41fc:	f94012f8 	ldr	x24, [x23, #32]
    4200:	b94006e1 	ldr	w1, [x23, #4]
    4204:	f90023f9 	str	x25, [sp, #64]
    4208:	2a0103e2 	mov	w2, w1
    420c:	394006f9 	ldrb	w25, [x23, #1]
    4210:	39400af4 	ldrb	w20, [x23, #2]
    4214:	b4000158 	cbz	x24, 423c <fwp_mem_free+0xbc>
    4218:	92403e76 	and	x22, x19, #0xffff
    421c:	9ac20ad6 	udiv	x22, x22, x2
    4220:	38766b01 	ldrb	w1, [x24, x22]
    4224:	8b160300 	add	x0, x24, x22
    4228:	7103fc3f 	cmp	w1, #0xff
    422c:	54000980 	b.eq	435c <fwp_mem_free+0x1dc>  // b.none
    4230:	38366b1f 	strb	wzr, [x24, x22]
    4234:	b94006e1 	ldr	w1, [x23, #4]
    4238:	2a0103e2 	mov	w2, w1
    423c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4240:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4244:	cb390000 	sub	x0, x0, w25, uxtb
    4248:	8b340074 	add	x20, x3, w20, uxtb
    424c:	9114c2b5 	add	x21, x21, #0x530
    4250:	1e630021 	ucvtf	d1, w1
    4254:	d37ae400 	lsl	x0, x0, #6
    4258:	8b140c14 	add	x20, x0, x20, lsl #3
    425c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4260:	f8746aa0 	ldr	x0, [x21, x20]
    4264:	f94023f9 	ldr	x25, [sp, #64]
    4268:	aa2003e0 	mvn	x0, x0
    426c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4270:	f9000260 	str	x0, [x19]
    4274:	f8346ab3 	str	x19, [x21, x20]
    4278:	f94a12a0 	ldr	x0, [x21, #5152]
    427c:	1e612800 	fadd	d0, d0, d1
    4280:	a94153f3 	ldp	x19, x20, [sp, #16]
    4284:	cb020000 	sub	x0, x0, x2
    4288:	f90a12a0 	str	x0, [x21, #5152]
    428c:	fd0a22a0 	str	d0, [x21, #5184]
    4290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4294:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4298:	d65f03c0 	ret
    429c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    42a0:	8b000063 	add	x3, x3, x0
    42a4:	eb03027f 	cmp	x19, x3
    42a8:	54fff9e1 	b.ne	41e4 <fwp_mem_free+0x64>  // b.any
    42ac:	fd400ae1 	ldr	d1, [x23, #16]
    42b0:	fd4a2020 	ldr	d0, [x1, #5184]
    42b4:	f9400ae0 	ldr	x0, [x23, #16]
    42b8:	7e61d821 	ucvtf	d1, d1
    42bc:	f94a1022 	ldr	x2, [x1, #5152]
    42c0:	f94012f3 	ldr	x19, [x23, #32]
    42c4:	1e612800 	fadd	d0, d0, d1
    42c8:	cb000042 	sub	x2, x2, x0
    42cc:	f90a1022 	str	x2, [x1, #5152]
    42d0:	fd0a2020 	str	d0, [x1, #5184]
    42d4:	b40000b3 	cbz	x19, 42e8 <fwp_mem_free+0x168>
    42d8:	39400260 	ldrb	w0, [x19]
    42dc:	7103fc1f 	cmp	w0, #0xff
    42e0:	54000380 	b.eq	4350 <fwp_mem_free+0x1d0>  // b.none
    42e4:	3900027f 	strb	wzr, [x19]
    42e8:	b9400ee2 	ldr	w2, [x23, #12]
    42ec:	b4000142 	cbz	x2, 4314 <fwp_mem_free+0x194>
    42f0:	9114c2a1 	add	x1, x21, #0x530
    42f4:	8b160040 	add	x0, x2, x22
    42f8:	8b000800 	add	x0, x0, x0, lsl #2
    42fc:	f949fc21 	ldr	x1, [x1, #5112]
    4300:	8b140034 	add	x20, x1, x20
    4304:	8b000c20 	add	x0, x1, x0, lsl #3
    4308:	3802869f 	strb	wzr, [x20], #40
    430c:	eb00029f 	cmp	x20, x0
    4310:	54ffffc1 	b.ne	4308 <fwp_mem_free+0x188>  // b.any
    4314:	9114c2a0 	add	x0, x21, #0x530
    4318:	f94a1801 	ldr	x1, [x0, #5168]
    431c:	f949f803 	ldr	x3, [x0, #5104]
    4320:	8b020021 	add	x1, x1, x2
    4324:	f90a1801 	str	x1, [x0, #5168]
    4328:	eb16007f 	cmp	x3, x22
    432c:	54000049 	b.ls	4334 <fwp_mem_free+0x1b4>  // b.plast
    4330:	f909f816 	str	x22, [x0, #5104]
    4334:	9114c2b5 	add	x21, x21, #0x530
    4338:	f949f6a0 	ldr	x0, [x21, #5096]
    433c:	eb16001f 	cmp	x0, x22
    4340:	54fff529 	b.ls	41e4 <fwp_mem_free+0x64>  // b.plast
    4344:	a94363f7 	ldp	x23, x24, [sp, #48]
    4348:	f909f6b6 	str	x22, [x21, #5096]
    434c:	17ffffa7 	b	41e8 <fwp_mem_free+0x68>
    4350:	aa1303e0 	mov	x0, x19
    4354:	97fffeef 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4358:	17ffffe3 	b	42e4 <fwp_mem_free+0x164>
    435c:	97fffeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4360:	17ffffb4 	b	4230 <fwp_mem_free+0xb0>

0000000000004364 <fwp_rc_wide_dup>:
    4364:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4368:	910003fd 	mov	x29, sp
    436c:	a90153f3 	stp	x19, x20, [sp, #16]
    4370:	aa0003f3 	mov	x19, x0
    4374:	ca404400 	eor	x0, x0, x0, lsr #17
    4378:	f90013f5 	str	x21, [sp, #32]
    437c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4380:	ca402400 	eor	x0, x0, x0, lsr #9
    4384:	9114c2a2 	add	x2, x21, #0x530
    4388:	92401c00 	and	x0, x0, #0xff
    438c:	910a2403 	add	x3, x0, #0x289
    4390:	8b000c40 	add	x0, x2, x0, lsl #3
    4394:	8b030c54 	add	x20, x2, x3, lsl #3
    4398:	f94a2401 	ldr	x1, [x0, #5192]
    439c:	b50000a1 	cbnz	x1, 43b0 <fwp_rc_wide_dup+0x4c>
    43a0:	14000033 	b	446c <fwp_rc_wide_dup+0x108>
    43a4:	91004034 	add	x20, x1, #0x10
    43a8:	f9400821 	ldr	x1, [x1, #16]
    43ac:	b4000241 	cbz	x1, 43f4 <fwp_rc_wide_dup+0x90>
    43b0:	f9400022 	ldr	x2, [x1]
    43b4:	eb02027f 	cmp	x19, x2
    43b8:	54ffff61 	b.ne	43a4 <fwp_rc_wide_dup+0x40>  // b.any
    43bc:	f9400281 	ldr	x1, [x20]
    43c0:	39400260 	ldrb	w0, [x19]
    43c4:	7103f81f 	cmp	w0, #0xfe
    43c8:	54000220 	b.eq	440c <fwp_rc_wide_dup+0xa8>  // b.none
    43cc:	b40001a1 	cbz	x1, 4400 <fwp_rc_wide_dup+0x9c>
    43d0:	f9400420 	ldr	x0, [x1, #8]
    43d4:	b100041f 	cmn	x0, #0x1
    43d8:	54000440 	b.eq	4460 <fwp_rc_wide_dup+0xfc>  // b.none
    43dc:	91000400 	add	x0, x0, #0x1
    43e0:	f9000420 	str	x0, [x1, #8]
    43e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e8:	f94013f5 	ldr	x21, [sp, #32]
    43ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f0:	d65f03c0 	ret
    43f4:	39400260 	ldrb	w0, [x19]
    43f8:	7103f81f 	cmp	w0, #0xfe
    43fc:	54000100 	b.eq	441c <fwp_rc_wide_dup+0xb8>  // b.none
    4400:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4404:	911a0000 	add	x0, x0, #0x680
    4408:	97fffea2 	bl	3e90 <fwp_trap>
    440c:	b4000081 	cbz	x1, 441c <fwp_rc_wide_dup+0xb8>
    4410:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4414:	911aa000 	add	x0, x0, #0x6a8
    4418:	97fffe9e 	bl	3e90 <fwp_trap>
    441c:	d2800300 	mov	x0, #0x18                  	// #24
    4420:	97fff900 	bl	2820 <malloc@plt>
    4424:	b4000280 	cbz	x0, 4474 <fwp_rc_wide_dup+0x110>
    4428:	d2801fe1 	mov	x1, #0xff                  	// #255
    442c:	a9000413 	stp	x19, x1, [x0]
    4430:	9114c2b5 	add	x21, x21, #0x530
    4434:	f900081f 	str	xzr, [x0, #16]
    4438:	12800001 	mov	w1, #0xffffffff            	// #-1
    443c:	f9000280 	str	x0, [x20]
    4440:	39000261 	strb	w1, [x19]
    4444:	f94e26a0 	ldr	x0, [x21, #7240]
    4448:	a94153f3 	ldp	x19, x20, [sp, #16]
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f90e26a0 	str	x0, [x21, #7240]
    4454:	f94013f5 	ldr	x21, [sp, #32]
    4458:	a8c37bfd 	ldp	x29, x30, [sp], #48
    445c:	d65f03c0 	ret
    4460:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4464:	911b4000 	add	x0, x0, #0x6d0
    4468:	97fffe8a 	bl	3e90 <fwp_trap>
    446c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4470:	17ffffd4 	b	43c0 <fwp_rc_wide_dup+0x5c>
    4474:	97fffaef 	bl	3030 <fwp_heap_oom>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_closure_drop_push>:
    4480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4484:	910003fd 	mov	x29, sp
    4488:	a90153f3 	stp	x19, x20, [sp, #16]
    448c:	aa0003f3 	mov	x19, x0
    4490:	a9408014 	ldp	x20, x0, [x0, #8]
    4494:	a9025bf5 	stp	x21, x22, [sp, #32]
    4498:	aa0103f5 	mov	x21, x1
    449c:	a90363f7 	stp	x23, x24, [sp, #48]
    44a0:	eb00029f 	cmp	x20, x0
    44a4:	54000160 	b.eq	44d0 <fwp_closure_drop_push+0x50>  // b.none
    44a8:	f9400276 	ldr	x22, [x19]
    44ac:	d37df297 	lsl	x23, x20, #3
    44b0:	91000694 	add	x20, x20, #0x1
    44b4:	f9000674 	str	x20, [x19, #8]
    44b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44bc:	f8376ad5 	str	x21, [x22, x23]
    44c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44cc:	d65f03c0 	ret
    44d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    44d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    44d8:	eb00029f 	cmp	x20, x0
    44dc:	540003e8 	b.hi	4558 <fwp_closure_drop_push+0xd8>  // b.pmore
    44e0:	d37cee99 	lsl	x25, x20, #4
    44e4:	d37ffa9a 	lsl	x26, x20, #1
    44e8:	aa1903e0 	mov	x0, x25
    44ec:	97fff8cd 	bl	2820 <malloc@plt>
    44f0:	aa0003f6 	mov	x22, x0
    44f4:	b4000380 	cbz	x0, 4564 <fwp_closure_drop_push+0xe4>
    44f8:	aa1303f8 	mov	x24, x19
    44fc:	aa1903e3 	mov	x3, x25
    4500:	d37df297 	lsl	x23, x20, #3
    4504:	aa1703e2 	mov	x2, x23
    4508:	f8418719 	ldr	x25, [x24], #24
    450c:	aa1903e1 	mov	x1, x25
    4510:	97fff8b0 	bl	27d0 <__memcpy_chk@plt>
    4514:	eb18033f 	cmp	x25, x24
    4518:	540000a0 	b.eq	452c <fwp_closure_drop_push+0xac>  // b.none
    451c:	aa1903e0 	mov	x0, x25
    4520:	97fff908 	bl	2940 <free@plt>
    4524:	f9400674 	ldr	x20, [x19, #8]
    4528:	d37df297 	lsl	x23, x20, #3
    452c:	91000694 	add	x20, x20, #0x1
    4530:	f9000276 	str	x22, [x19]
    4534:	f9000a7a 	str	x26, [x19, #16]
    4538:	a9446bf9 	ldp	x25, x26, [sp, #64]
    453c:	f9000674 	str	x20, [x19, #8]
    4540:	f8376ad5 	str	x21, [x22, x23]
    4544:	a94153f3 	ldp	x19, x20, [sp, #16]
    4548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    454c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4550:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4554:	d65f03c0 	ret
    4558:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    455c:	911bc000 	add	x0, x0, #0x6f0
    4560:	97fffe4c 	bl	3e90 <fwp_trap>
    4564:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4568:	f947e863 	ldr	x3, [x3, #4048]
    456c:	d2800262 	mov	x2, #0x13                  	// #19
    4570:	d2800021 	mov	x1, #0x1                   	// #1
    4574:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4578:	91152000 	add	x0, x0, #0x548
    457c:	f9400063 	ldr	x3, [x3]
    4580:	97fff900 	bl	2980 <fwrite@plt>
    4584:	d2800000 	mov	x0, #0x0                   	// #0
    4588:	97fff90a 	bl	29b0 <fflush@plt>
    458c:	52800cc0 	mov	w0, #0x66                  	// #102
    4590:	97fff918 	bl	29f0 <_Exit@plt>

0000000000004594 <fwp_closure_drop.part.0>:
    4594:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4598:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0xac0>
    459c:	910003fd 	mov	x29, sp
    45a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    45a4:	f947f463 	ldr	x3, [x3, #4072]
    45a8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ac:	d10883ff 	sub	sp, sp, #0x220
    45b0:	910003e2 	mov	x2, sp
    45b4:	d53bd053 	mrs	x19, tpidr_el0
    45b8:	910063f4 	add	x20, sp, #0x18
    45bc:	3dc05420 	ldr	q0, [x1, #336]
    45c0:	91400264 	add	x4, x19, #0x0, lsl #12
    45c4:	91004084 	add	x4, x4, #0x10
    45c8:	aa0003e1 	mov	x1, x0
    45cc:	aa0203e0 	mov	x0, x2
    45d0:	f9400062 	ldr	x2, [x3]
    45d4:	f9010fe2 	str	x2, [sp, #536]
    45d8:	d2800002 	mov	x2, #0x0                   	// #0
    45dc:	f90003f4 	str	x20, [sp]
    45e0:	f9000080 	str	x0, [x4]
    45e4:	3c8083e0 	stur	q0, [sp, #8]
    45e8:	97ffffa6 	bl	4480 <fwp_closure_drop_push>
    45ec:	f94007e0 	ldr	x0, [sp, #8]
    45f0:	b40002e0 	cbz	x0, 464c <fwp_closure_drop.part.0+0xb8>
    45f4:	f90123f5 	str	x21, [sp, #576]
    45f8:	900000f5 	adrp	x21, 20000 <__data_start>
    45fc:	9100c2b5 	add	x21, x21, #0x30
    4600:	14000006 	b	4618 <fwp_closure_drop.part.0+0x84>
    4604:	f9400422 	ldr	x2, [x1, #8]
    4608:	52800001 	mov	w1, #0x0                   	// #0
    460c:	d63f0040 	blr	x2
    4610:	f94007e0 	ldr	x0, [sp, #8]
    4614:	b40001a0 	cbz	x0, 4648 <fwp_closure_drop.part.0+0xb4>
    4618:	f94003e1 	ldr	x1, [sp]
    461c:	d1000400 	sub	x0, x0, #0x1
    4620:	f90007e0 	str	x0, [sp, #8]
    4624:	f9403ea2 	ldr	x2, [x21, #120]
    4628:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    462c:	b9400001 	ldr	w1, [x0]
    4630:	8b011441 	add	x1, x2, x1, lsl #5
    4634:	f9400c21 	ldr	x1, [x1, #24]
    4638:	b5fffe61 	cbnz	x1, 4604 <fwp_closure_drop.part.0+0x70>
    463c:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4640:	911c4000 	add	x0, x0, #0x710
    4644:	97fffe13 	bl	3e90 <fwp_trap>
    4648:	f94123f5 	ldr	x21, [sp, #576]
    464c:	91400273 	add	x19, x19, #0x0, lsl #12
    4650:	91004273 	add	x19, x19, #0x10
    4654:	f94003e0 	ldr	x0, [sp]
    4658:	f900027f 	str	xzr, [x19]
    465c:	eb14001f 	cmp	x0, x20
    4660:	54000040 	b.eq	4668 <fwp_closure_drop.part.0+0xd4>  // b.none
    4664:	97fff8b7 	bl	2940 <free@plt>
    4668:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    466c:	f947f400 	ldr	x0, [x0, #4072]
    4670:	f9410fe2 	ldr	x2, [sp, #536]
    4674:	f9400001 	ldr	x1, [x0]
    4678:	eb010042 	subs	x2, x2, x1
    467c:	d2800001 	mov	x1, #0x0                   	// #0
    4680:	540000a1 	b.ne	4694 <fwp_closure_drop.part.0+0x100>  // b.any
    4684:	910883ff 	add	sp, sp, #0x220
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4690:	d65f03c0 	ret
    4694:	f90123f5 	str	x21, [sp, #576]
    4698:	97fff87a 	bl	2880 <__stack_chk_fail@plt>
    469c:	d503201f 	nop

00000000000046a0 <fwp_tape_of>:
    46a0:	aa0003e1 	mov	x1, x0
    46a4:	92403c00 	and	x0, x0, #0xffff
    46a8:	b40000e0 	cbz	x0, 46c4 <fwp_tape_of+0x24>
    46ac:	d1000402 	sub	x2, x0, #0x1
    46b0:	900000e3 	adrp	x3, 20000 <__data_start>
    46b4:	9100c060 	add	x0, x3, #0x30
    46b8:	f9404000 	ldr	x0, [x0, #128]
    46bc:	eb02001f 	cmp	x0, x2
    46c0:	540000cc 	b.gt	46d8 <fwp_tape_of+0x38>
    46c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    46c8:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    46cc:	911d0000 	add	x0, x0, #0x740
    46d0:	910003fd 	mov	x29, sp
    46d4:	97fffdef 	bl	3e90 <fwp_trap>
    46d8:	8b020440 	add	x0, x2, x2, lsl #1
    46dc:	f9401863 	ldr	x3, [x3, #48]
    46e0:	8b000842 	add	x2, x2, x0, lsl #2
    46e4:	d37df042 	lsl	x2, x2, #3
    46e8:	8b020060 	add	x0, x3, x2
    46ec:	b9400404 	ldr	w4, [x0, #4]
    46f0:	34fffea4 	cbz	w4, 46c4 <fwp_tape_of+0x24>
    46f4:	b8626862 	ldr	w2, [x3, x2]
    46f8:	9350fc21 	asr	x1, x1, #16
    46fc:	6b01005f 	cmp	w2, w1
    4700:	54fffe21 	b.ne	46c4 <fwp_tape_of+0x24>  // b.any
    4704:	d65f03c0 	ret
    4708:	d503201f 	nop
    470c:	d503201f 	nop

0000000000004710 <fwp_now_ns>:
    4710:	d100c3ff 	sub	sp, sp, #0x30
    4714:	52800020 	mov	w0, #0x1                   	// #1
    4718:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    471c:	f947f442 	ldr	x2, [x2, #4072]
    4720:	910023e1 	add	x1, sp, #0x8
    4724:	a9027bfd 	stp	x29, x30, [sp, #32]
    4728:	910083fd 	add	x29, sp, #0x20
    472c:	f9400043 	ldr	x3, [x2]
    4730:	f9000fe3 	str	x3, [sp, #24]
    4734:	d2800003 	mov	x3, #0x0                   	// #0
    4738:	97fff81e 	bl	27b0 <clock_gettime@plt>
    473c:	350002c0 	cbnz	w0, 4794 <fwp_now_ns+0x84>
    4740:	a9408be1 	ldp	x1, x2, [sp, #8]
    4744:	d2994003 	mov	x3, #0xca00                	// #51712
    4748:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    474c:	9b037c20 	mul	x0, x1, x3
    4750:	9b437c21 	smulh	x1, x1, x3
    4754:	ab020000 	adds	x0, x0, x2
    4758:	937ffc42 	asr	x2, x2, #63
    475c:	9a020021 	adc	x1, x1, x2
    4760:	f100001f 	cmp	x0, #0x0
    4764:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4768:	b50001c1 	cbnz	x1, 47a0 <fwp_now_ns+0x90>
    476c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4770:	f947f421 	ldr	x1, [x1, #4072]
    4774:	f9400fe3 	ldr	x3, [sp, #24]
    4778:	f9400022 	ldr	x2, [x1]
    477c:	eb020063 	subs	x3, x3, x2
    4780:	d2800002 	mov	x2, #0x0                   	// #0
    4784:	54000141 	b.ne	47ac <fwp_now_ns+0x9c>  // b.any
    4788:	a9427bfd 	ldp	x29, x30, [sp, #32]
    478c:	9100c3ff 	add	sp, sp, #0x30
    4790:	d65f03c0 	ret
    4794:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    4798:	911e4000 	add	x0, x0, #0x790
    479c:	97fffdbd 	bl	3e90 <fwp_trap>
    47a0:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    47a4:	911ec000 	add	x0, x0, #0x7b0
    47a8:	97fffdba 	bl	3e90 <fwp_trap>
    47ac:	97fff835 	bl	2880 <__stack_chk_fail@plt>

00000000000047b0 <fwp_poll_events>:
    47b0:	d10103ff 	sub	sp, sp, #0x40
    47b4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    47b8:	f947f400 	ldr	x0, [x0, #4072]
    47bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    47c0:	910083fd 	add	x29, sp, #0x20
    47c4:	f9001bf3 	str	x19, [sp, #48]
    47c8:	900000f3 	adrp	x19, 20000 <__data_start>
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	f9000fe1 	str	x1, [sp, #24]
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	97ffffce 	bl	4710 <fwp_now_ns>
    47dc:	9100c261 	add	x1, x19, #0x30
    47e0:	f9404421 	ldr	x1, [x1, #136]
    47e4:	b4000e01 	cbz	x1, 49a4 <fwp_poll_events+0x1f4>
    47e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    47ec:	14000005 	b	4800 <fwp_poll_events+0x50>
    47f0:	f9408821 	ldr	x1, [x1, #272]
    47f4:	eb03005f 	cmp	x2, x3
    47f8:	9a83d042 	csel	x2, x2, x3, le
    47fc:	b40000c1 	cbz	x1, 4814 <fwp_poll_events+0x64>
    4800:	f9403423 	ldr	x3, [x1, #104]
    4804:	b6ffff62 	tbz	x2, #63, 47f0 <fwp_poll_events+0x40>
    4808:	f9408821 	ldr	x1, [x1, #272]
    480c:	aa0303e2 	mov	x2, x3
    4810:	b5ffff81 	cbnz	x1, 4800 <fwp_poll_events+0x50>
    4814:	b7f80c82 	tbnz	x2, #63, 49a4 <fwp_poll_events+0x1f4>
    4818:	cb000042 	sub	x2, x2, x0
    481c:	f100005f 	cmp	x2, #0x0
    4820:	540003ad 	b.le	4894 <fwp_poll_events+0xe4>
    4824:	d2869b60 	mov	x0, #0x34db                	// #13531
    4828:	d2884804 	mov	x4, #0x4240                	// #16960
    482c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4830:	f2a001e4 	movk	x4, #0xf, lsl #16
    4834:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4838:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    483c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4840:	9b407c40 	smulh	x0, x2, x0
    4844:	9352fc00 	asr	x0, x0, #18
    4848:	cb82fc00 	sub	x0, x0, x2, asr #63
    484c:	9b048802 	msub	x2, x0, x4, x2
    4850:	f100005f 	cmp	x2, #0x0
    4854:	9a800400 	cinc	x0, x0, ne	// ne = any
    4858:	eb01001f 	cmp	x0, x1
    485c:	5400098c 	b.gt	498c <fwp_poll_events+0x1dc>
    4860:	340001a0 	cbz	w0, 4894 <fwp_poll_events+0xe4>
    4864:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4868:	52807d05 	mov	w5, #0x3e8                 	// #1000
    486c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4870:	9ba17c01 	umull	x1, w0, w1
    4874:	d366fc23 	lsr	x3, x1, #38
    4878:	aa0303e2 	mov	x2, x3
    487c:	1b058063 	msub	w3, w3, w5, w0
    4880:	9b247c63 	smull	x3, w3, w4
    4884:	910023e0 	add	x0, sp, #0x8
    4888:	d2800001 	mov	x1, #0x0                   	// #0
    488c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4890:	97fff830 	bl	2950 <nanosleep@plt>
    4894:	97ffff9f 	bl	4710 <fwp_now_ns>
    4898:	9100c268 	add	x8, x19, #0x30
    489c:	aa0003e7 	mov	x7, x0
    48a0:	4f000400 	movi	v0.4s, #0x0
    48a4:	52800029 	mov	w9, #0x1                   	// #1
    48a8:	f9404506 	ldr	x6, [x8, #136]
    48ac:	d503201f 	nop
    48b0:	b40003e6 	cbz	x6, 492c <fwp_poll_events+0x17c>
    48b4:	f94034c1 	ldr	x1, [x6, #104]
    48b8:	aa0603e5 	mov	x5, x6
    48bc:	f94088c6 	ldr	x6, [x6, #272]
    48c0:	eb07003f 	cmp	x1, x7
    48c4:	54ffff6c 	b.gt	48b0 <fwp_poll_events+0x100>
    48c8:	394154a0 	ldrb	w0, [x5, #85]
    48cc:	36000120 	tbz	w0, #0, 48f0 <fwp_poll_events+0x140>
    48d0:	f94084a0 	ldr	x0, [x5, #264]
    48d4:	b4000560 	cbz	x0, 4980 <fwp_poll_events+0x1d0>
    48d8:	f9008806 	str	x6, [x0, #272]
    48dc:	b4000046 	cbz	x6, 48e4 <fwp_poll_events+0x134>
    48e0:	f90084c0 	str	x0, [x6, #264]
    48e4:	910800a0 	add	x0, x5, #0x200
    48e8:	390154bf 	strb	wzr, [x5, #85]
    48ec:	3c908000 	stur	q0, [x0, #-248]
    48f0:	f94030a0 	ldr	x0, [x5, #96]
    48f4:	390158a9 	strb	w9, [x5, #86]
    48f8:	f100001f 	cmp	x0, #0x0
    48fc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4900:	540002cd 	b.le	4958 <fwp_poll_events+0x1a8>
    4904:	f94028a0 	ldr	x0, [x5, #80]
    4908:	f2001c1f 	tst	x0, #0xff000000ff
    490c:	54fffd21 	b.ne	48b0 <fwp_poll_events+0x100>  // b.any
    4910:	f9401500 	ldr	x0, [x8, #40]
    4914:	390150a9 	strb	w9, [x5, #84]
    4918:	f90080bf 	str	xzr, [x5, #256]
    491c:	b40002c0 	cbz	x0, 4974 <fwp_poll_events+0x1c4>
    4920:	f9001505 	str	x5, [x8, #40]
    4924:	f9008005 	str	x5, [x0, #256]
    4928:	b5fffc66 	cbnz	x6, 48b4 <fwp_poll_events+0x104>
    492c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4930:	f947f400 	ldr	x0, [x0, #4072]
    4934:	f9400fe2 	ldr	x2, [sp, #24]
    4938:	f9400001 	ldr	x1, [x0]
    493c:	eb010042 	subs	x2, x2, x1
    4940:	d2800001 	mov	x1, #0x0                   	// #0
    4944:	540002e1 	b.ne	49a0 <fwp_poll_events+0x1f0>  // b.any
    4948:	a9427bfd 	ldp	x29, x30, [sp, #32]
    494c:	f9401bf3 	ldr	x19, [sp, #48]
    4950:	910103ff 	add	sp, sp, #0x40
    4954:	d65f03c0 	ret
    4958:	394144a0 	ldrb	w0, [x5, #81]
    495c:	3707fd40 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4960:	394140a0 	ldrb	w0, [x5, #80]
    4964:	3707fd00 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4968:	aa0503e0 	mov	x0, x5
    496c:	97fffac1 	bl	3470 <fwp_cancel_tree.part.0>
    4970:	17ffffe5 	b	4904 <fwp_poll_events+0x154>
    4974:	f9001505 	str	x5, [x8, #40]
    4978:	f9001905 	str	x5, [x8, #48]
    497c:	17ffffeb 	b	4928 <fwp_poll_events+0x178>
    4980:	9100c261 	add	x1, x19, #0x30
    4984:	f9004426 	str	x6, [x1, #136]
    4988:	17ffffd5 	b	48dc <fwp_poll_events+0x12c>
    498c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4990:	d2989362 	mov	x2, #0xc49b                	// #50331
    4994:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4998:	f2a00402 	movk	x2, #0x20, lsl #16
    499c:	17ffffba 	b	4884 <fwp_poll_events+0xd4>
    49a0:	97fff7b8 	bl	2880 <__stack_chk_fail@plt>
    49a4:	97fff993 	bl	2ff0 <fwp_flush>
    49a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    49ac:	f947e863 	ldr	x3, [x3, #4048]
    49b0:	d2800562 	mov	x2, #0x2b                  	// #43
    49b4:	d2800021 	mov	x1, #0x1                   	// #1
    49b8:	b0000020 	adrp	x0, 9000 <__divti3+0x1e0>
    49bc:	911f6000 	add	x0, x0, #0x7d8
    49c0:	f9400063 	ldr	x3, [x3]
    49c4:	97fff7ef 	bl	2980 <fwrite@plt>
    49c8:	52800ca0 	mov	w0, #0x65                  	// #101
    49cc:	97fff759 	bl	2730 <exit@plt>

00000000000049d0 <fwp_heap_alloc_big>:
    49d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d4:	910003fd 	mov	x29, sp
    49d8:	a90153f3 	stp	x19, x20, [sp, #16]
    49dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e0:	a90363f7 	stp	x23, x24, [sp, #48]
    49e4:	aa0003f7 	mov	x23, x0
    49e8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f0:	eb0002ff 	cmp	x23, x0
    49f4:	540008a8 	b.hi	4b08 <fwp_heap_alloc_big+0x138>  // b.pmore
    49f8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49fc:	8b0002f4 	add	x20, x23, x0
    4a00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    4a04:	9114c359 	add	x25, x26, #0x530
    4a08:	d350fe94 	lsr	x20, x20, #16
    4a0c:	2a0103f5 	mov	w21, w1
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	97fff9c7 	bl	3130 <fwp_heap_chunks>
    4a18:	f949ff22 	ldr	x2, [x25, #5112]
    4a1c:	8b000813 	add	x19, x0, x0, lsl #2
    4a20:	aa0003f8 	mov	x24, x0
    4a24:	52800043 	mov	w3, #0x2                   	// #2
    4a28:	d37df273 	lsl	x19, x19, #3
    4a2c:	d2800021 	mov	x1, #0x1                   	// #1
    4a30:	8b130040 	add	x0, x2, x19
    4a34:	38336843 	strb	w3, [x2, x19]
    4a38:	39000415 	strb	w21, [x0, #1]
    4a3c:	b9000c14 	str	w20, [x0, #12]
    4a40:	f9000817 	str	x23, [x0, #16]
    4a44:	97fffd57 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a48:	f100069f 	cmp	x20, #0x1
    4a4c:	54000289 	b.ls	4a9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4a50:	8b180294 	add	x20, x20, x24
    4a54:	9100a273 	add	x19, x19, #0x28
    4a58:	a90573fb 	stp	x27, x28, [sp, #80]
    4a5c:	5280007b 	mov	w27, #0x3                   	// #3
    4a60:	8b140a94 	add	x20, x20, x20, lsl #2
    4a64:	2a1803fc 	mov	w28, w24
    4a68:	9adb2296 	lsl	x22, x20, x27
    4a6c:	d503201f 	nop
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffd48 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0xa0>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	9114c353 	add	x19, x26, #0x530
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9114c35a 	add	x26, x26, #0x530
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    4b20:	9114c262 	add	x2, x19, #0x530
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	9114c262 	add	x2, x19, #0x530
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	9114c260 	add	x0, x19, #0x530
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	9114c273 	add	x19, x19, #0x530
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffbbf 	bl	3af0 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff6f 	b	49d0 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	9114c260 	add	x0, x19, #0x530
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffd19 	bl	40c0 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4c84:	9114c293 	add	x19, x20, #0x530
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	9114c294 	add	x20, x20, #0x530
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4d94:	9114c283 	add	x3, x20, #0x530
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	9114c282 	add	x2, x20, #0x530
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	9114c294 	add	x20, x20, #0x530
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_tape_grow.constprop.0>:
    4ea4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ea8:	d2800803 	mov	x3, #0x40                  	// #64
    4eac:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4eb0:	910003fd 	mov	x29, sp
    4eb4:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb8:	f9400c13 	ldr	x19, [x0, #24]
    4ebc:	a90363f7 	stp	x23, x24, [sp, #48]
    4ec0:	aa0003f7 	mov	x23, x0
    4ec4:	f100027f 	cmp	x19, #0x0
    4ec8:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    4ecc:	eb13003f 	cmp	x1, x19
    4ed0:	540000ed 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ed4:	eb02027f 	cmp	x19, x2
    4ed8:	5400076d 	b.le	4fc4 <fwp_tape_grow.constprop.0+0x120>
    4edc:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4ee0:	eb13003f 	cmp	x1, x19
    4ee4:	5400004d 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ee8:	14000000 	b	4ee8 <fwp_tape_grow.constprop.0+0x44>
    4eec:	a940d2e2 	ldp	x2, x20, [x23, #8]
    4ef0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ef4:	d37df276 	lsl	x22, x19, #3
    4ef8:	f94012e0 	ldr	x0, [x23, #32]
    4efc:	aa1603e1 	mov	x1, x22
    4f00:	f94032f5 	ldr	x21, [x23, #96]
    4f04:	cb020294 	sub	x20, x20, x2
    4f08:	97fff65a 	bl	2870 <realloc@plt>
    4f0c:	b4000c20 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    4f10:	f9400ee1 	ldr	x1, [x23, #24]
    4f14:	8b010801 	add	x1, x0, x1, lsl #2
    4f18:	a90206e0 	stp	x0, x1, [x23, #32]
    4f1c:	b4000895 	cbz	x21, 502c <fwp_tape_grow.constprop.0+0x188>
    4f20:	f94032b6 	ldr	x22, [x21, #96]
    4f24:	eb1302df 	cmp	x22, x19
    4f28:	540003aa 	b.ge	4f9c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    4f2c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f30:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4f34:	eb00027f 	cmp	x19, x0
    4f38:	54000a68 	b.hi	5084 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    4f3c:	f94022b9 	ldr	x25, [x21, #64]
    4f40:	d37cee7a 	lsl	x26, x19, #4
    4f44:	aa1a03e0 	mov	x0, x26
    4f48:	52800041 	mov	w1, #0x2                   	// #2
    4f4c:	97ffff49 	bl	4c70 <fwp_heap_alloc>
    4f50:	aa0003f8 	mov	x24, x0
    4f54:	b4000119 	cbz	x25, 4f74 <fwp_tape_grow.constprop.0+0xd0>
    4f58:	d37ceed6 	lsl	x22, x22, #4
    4f5c:	aa1903e1 	mov	x1, x25
    4f60:	eb1a02df 	cmp	x22, x26
    4f64:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    4f68:	97fff5da 	bl	26d0 <memcpy@plt>
    4f6c:	aa1903e0 	mov	x0, x25
    4f70:	97fffc84 	bl	4180 <fwp_mem_free>
    4f74:	f94032a0 	ldr	x0, [x21, #96]
    4f78:	52800001 	mov	w1, #0x0                   	// #0
    4f7c:	cb000262 	sub	x2, x19, x0
    4f80:	8b001300 	add	x0, x24, x0, lsl #4
    4f84:	d37cec42 	lsl	x2, x2, #4
    4f88:	97fff632 	bl	2850 <memset@plt>
    4f8c:	f94012e0 	ldr	x0, [x23, #32]
    4f90:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f94:	f90022b8 	str	x24, [x21, #64]
    4f98:	f90032b3 	str	x19, [x21, #96]
    4f9c:	d37ef675 	lsl	x21, x19, #2
    4fa0:	b50002b4 	cbnz	x20, 4ff4 <fwp_tape_grow.constprop.0+0x150>
    4fa4:	8b150001 	add	x1, x0, x21
    4fa8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fac:	f9000ef3 	str	x19, [x23, #24]
    4fb0:	f90016e1 	str	x1, [x23, #40]
    4fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fbc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4fc0:	d65f03c0 	ret
    4fc4:	d37ffa73 	lsl	x19, x19, #1
    4fc8:	17ffffc1 	b	4ecc <fwp_tape_grow.constprop.0+0x28>
    4fcc:	eb1502df 	cmp	x22, x21
    4fd0:	aa0403e0 	mov	x0, x4
    4fd4:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    4fd8:	d37df282 	lsl	x2, x20, #3
    4fdc:	cb160063 	sub	x3, x3, x22
    4fe0:	97fff690 	bl	2a20 <__memmove_chk@plt>
    4fe4:	f9401ae1 	ldr	x1, [x23, #48]
    4fe8:	f94012e0 	ldr	x0, [x23, #32]
    4fec:	8b160021 	add	x1, x1, x22
    4ff0:	f9001ee1 	str	x1, [x23, #56]
    4ff4:	f94016e1 	ldr	x1, [x23, #40]
    4ff8:	d37ef675 	lsl	x21, x19, #2
    4ffc:	d37ef682 	lsl	x2, x20, #2
    5000:	8b150000 	add	x0, x0, x21
    5004:	97fff5bb 	bl	26f0 <memmove@plt>
    5008:	f94012e0 	ldr	x0, [x23, #32]
    500c:	8b150001 	add	x1, x0, x21
    5010:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5014:	f9000ef3 	str	x19, [x23, #24]
    5018:	f90016e1 	str	x1, [x23, #40]
    501c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5028:	d65f03c0 	ret
    502c:	f9401ae0 	ldr	x0, [x23, #48]
    5030:	d37cee75 	lsl	x21, x19, #4
    5034:	aa1503e1 	mov	x1, x21
    5038:	97fff60e 	bl	2870 <realloc@plt>
    503c:	b40002a0 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    5040:	f9400ee2 	ldr	x2, [x23, #24]
    5044:	f9001ae0 	str	x0, [x23, #48]
    5048:	8b160004 	add	x4, x0, x22
    504c:	8b020c01 	add	x1, x0, x2, lsl #3
    5050:	f9001ee1 	str	x1, [x23, #56]
    5054:	b5fffbd4 	cbnz	x20, 4fcc <fwp_tape_grow.constprop.0+0x128>
    5058:	f94012e0 	ldr	x0, [x23, #32]
    505c:	d37ef675 	lsl	x21, x19, #2
    5060:	f9001ee4 	str	x4, [x23, #56]
    5064:	8b150001 	add	x1, x0, x21
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	f9000ef3 	str	x19, [x23, #24]
    5070:	f90016e1 	str	x1, [x23, #40]
    5074:	a94153f3 	ldp	x19, x20, [sp, #16]
    5078:	a94363f7 	ldp	x23, x24, [sp, #48]
    507c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5080:	d65f03c0 	ret
    5084:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5088:	9120c000 	add	x0, x0, #0x830
    508c:	97fffb81 	bl	3e90 <fwp_trap>
    5090:	aa1703e0 	mov	x0, x23
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	97fff7be 	bl	2f90 <fwp_tape_unlink_scope>
    509c:	f94012e0 	ldr	x0, [x23, #32]
    50a0:	97fff628 	bl	2940 <free@plt>
    50a4:	f9401ae0 	ldr	x0, [x23, #48]
    50a8:	97fff626 	bl	2940 <free@plt>
    50ac:	f94022e0 	ldr	x0, [x23, #64]
    50b0:	97fff624 	bl	2940 <free@plt>
    50b4:	f9000eff 	str	xzr, [x23, #24]
    50b8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    50bc:	f947e821 	ldr	x1, [x1, #4048]
    50c0:	a9047eff 	stp	xzr, xzr, [x23, #64]
    50c4:	d2800262 	mov	x2, #0x13                  	// #19
    50c8:	4f000400 	movi	v0.4s, #0x0
    50cc:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    50d0:	f9400023 	ldr	x3, [x1]
    50d4:	b90006ff 	str	wzr, [x23, #4]
    50d8:	d2800021 	mov	x1, #0x1                   	// #1
    50dc:	91152000 	add	x0, x0, #0x548
    50e0:	3c8082e0 	stur	q0, [x23, #8]
    50e4:	ad0102e0 	stp	q0, q0, [x23, #32]
    50e8:	97fff626 	bl	2980 <fwrite@plt>
    50ec:	d2800000 	mov	x0, #0x0                   	// #0
    50f0:	97fff630 	bl	29b0 <fflush@plt>
    50f4:	52800cc0 	mov	w0, #0x66                  	// #102
    50f8:	97fff63e 	bl	29f0 <_Exit@plt>
    50fc:	d503201f 	nop

0000000000005100 <f141.constprop.0>:
    5100:	f100001f 	cmp	x0, #0x0
    5104:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5108:	54000a2b 	b.lt	524c <f141.constprop.0+0x14c>  // b.tstop
    510c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5110:	aa0003e2 	mov	x2, x0
    5114:	910003fd 	mov	x29, sp
    5118:	a90153f3 	stp	x19, x20, [sp, #16]
    511c:	aa0003f4 	mov	x20, x0
    5120:	aa010000 	orr	x0, x0, x1
    5124:	a9025bf5 	stp	x21, x22, [sp, #32]
    5128:	aa0103f6 	mov	x22, x1
    512c:	f9001bf7 	str	x23, [sp, #48]
    5130:	fd001fe8 	str	d8, [sp, #56]
    5134:	b7f80180 	tbnz	x0, #63, 5164 <f141.constprop.0+0x64>
    5138:	9360fc20 	asr	x0, x1, #32
    513c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5140:	eb82801f 	cmp	x0, x2, asr #32
    5144:	54000881 	b.ne	5254 <f141.constprop.0+0x154>  // b.any
    5148:	97fffd56 	bl	46a0 <fwp_tape_of>
    514c:	aa0003f3 	mov	x19, x0
    5150:	f9403000 	ldr	x0, [x0, #96]
    5154:	b40001e0 	cbz	x0, 5190 <f141.constprop.0+0x90>
    5158:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    515c:	91226000 	add	x0, x0, #0x898
    5160:	97fffb4c 	bl	3e90 <fwp_trap>
    5164:	9360fc40 	asr	x0, x2, #32
    5168:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    516c:	b6fffee2 	tbz	x2, #63, 5148 <f141.constprop.0+0x48>
    5170:	2f00e408 	movi	d8, #0x0
    5174:	9360fc20 	asr	x0, x1, #32
    5178:	aa0103f4 	mov	x20, x1
    517c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5180:	97fffd48 	bl	46a0 <fwp_tape_of>
    5184:	aa0003f3 	mov	x19, x0
    5188:	f9403000 	ldr	x0, [x0, #96]
    518c:	b5fffe60 	cbnz	x0, 5158 <f141.constprop.0+0x58>
    5190:	f9400a77 	ldr	x23, [x19, #16]
    5194:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5198:	eb0002ff 	cmp	x23, x0
    519c:	5400046c 	b.gt	5228 <f141.constprop.0+0x128>
    51a0:	eb3442ff 	cmp	x23, w20, uxtw
    51a4:	540004ed 	b.le	5240 <f141.constprop.0+0x140>
    51a8:	b7f80076 	tbnz	x22, #63, 51b4 <f141.constprop.0+0xb4>
    51ac:	eb3642ff 	cmp	x23, w22, uxtw
    51b0:	5400048d 	b.le	5240 <f141.constprop.0+0x140>
    51b4:	f9400675 	ldr	x21, [x19, #8]
    51b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51bc:	cb1502f5 	sub	x21, x23, x21
    51c0:	910006a1 	add	x1, x21, #0x1
    51c4:	eb00003f 	cmp	x1, x0
    51c8:	54000308 	b.hi	5228 <f141.constprop.0+0x128>  // b.pmore
    51cc:	f9400e60 	ldr	x0, [x19, #24]
    51d0:	eb00003f 	cmp	x1, x0
    51d4:	5400030c 	b.gt	5234 <f141.constprop.0+0x134>
    51d8:	a9420262 	ldp	x2, x0, [x19, #32]
    51dc:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    51e0:	f9401a61 	ldr	x1, [x19, #48]
    51e4:	b8357854 	str	w20, [x2, x21, lsl #2]
    51e8:	f9401e62 	ldr	x2, [x19, #56]
    51ec:	f10002df 	cmp	x22, #0x0
    51f0:	fc357820 	str	d0, [x1, x21, lsl #3]
    51f4:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    51f8:	b8357816 	str	w22, [x0, x21, lsl #2]
    51fc:	92607e80 	and	x0, x20, #0xffffffff00000000
    5200:	910006e1 	add	x1, x23, #0x1
    5204:	aa170000 	orr	x0, x0, x23
    5208:	fc357848 	str	d8, [x2, x21, lsl #3]
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	f9401bf7 	ldr	x23, [sp, #48]
    5214:	fd401fe8 	ldr	d8, [sp, #56]
    5218:	f9000a61 	str	x1, [x19, #16]
    521c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5220:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5224:	d65f03c0 	ret
    5228:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    522c:	9120c000 	add	x0, x0, #0x830
    5230:	97fffb18 	bl	3e90 <fwp_trap>
    5234:	aa1303e0 	mov	x0, x19
    5238:	97ffff1b 	bl	4ea4 <fwp_tape_grow.constprop.0>
    523c:	17ffffe7 	b	51d8 <f141.constprop.0+0xd8>
    5240:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5244:	91232000 	add	x0, x0, #0x8c8
    5248:	97fffb12 	bl	3e90 <fwp_trap>
    524c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5250:	d65f03c0 	ret
    5254:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5258:	91214000 	add	x0, x0, #0x850
    525c:	97fffb0d 	bl	3e90 <fwp_trap>

0000000000005260 <w120>:
    5260:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5264:	910003fd 	mov	x29, sp
    5268:	a90153f3 	stp	x19, x20, [sp, #16]
    526c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5270:	a90363f7 	stp	x23, x24, [sp, #48]
    5274:	aa0003f8 	mov	x24, x0
    5278:	a9046bf9 	stp	x25, x26, [sp, #64]
    527c:	aa0103f9 	mov	x25, x1
    5280:	6d0527e8 	stp	d8, d9, [sp, #80]
    5284:	1e604008 	fmov	d8, d0
    5288:	1e604029 	fmov	d9, d1
    528c:	6d062fea 	stp	d10, d11, [sp, #96]
    5290:	1e60080a 	fmul	d10, d0, d0
    5294:	b7f821a0 	tbnz	x0, #63, 56c8 <w120+0x468>
    5298:	9360fc17 	asr	x23, x0, #32
    529c:	aa1703e0 	mov	x0, x23
    52a0:	97fffd00 	bl	46a0 <fwp_tape_of>
    52a4:	f9403001 	ldr	x1, [x0, #96]
    52a8:	aa0003f3 	mov	x19, x0
    52ac:	b4000081 	cbz	x1, 52bc <w120+0x5c>
    52b0:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    52b4:	91226000 	add	x0, x0, #0x898
    52b8:	97fffaf6 	bl	3e90 <fwp_trap>
    52bc:	f9400815 	ldr	x21, [x0, #16]
    52c0:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    52c4:	eb0102bf 	cmp	x21, x1
    52c8:	54001d8c 	b.gt	5678 <w120+0x418>
    52cc:	eb3842bf 	cmp	x21, w24, uxtw
    52d0:	54001ced 	b.le	566c <w120+0x40c>
    52d4:	f9400416 	ldr	x22, [x0, #8]
    52d8:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    52dc:	cb1602b6 	sub	x22, x21, x22
    52e0:	910006c1 	add	x1, x22, #0x1
    52e4:	eb02003f 	cmp	x1, x2
    52e8:	54001c88 	b.hi	5678 <w120+0x418>  // b.pmore
    52ec:	f9400c02 	ldr	x2, [x0, #24]
    52f0:	eb02003f 	cmp	x1, x2
    52f4:	54001c8c 	b.gt	5684 <w120+0x424>
    52f8:	a9420660 	ldp	x0, x1, [x19, #32]
    52fc:	92607f14 	and	x20, x24, #0xffffffff00000000
    5300:	f9401a62 	ldr	x2, [x19, #48]
    5304:	b8367818 	str	w24, [x0, x22, lsl #2]
    5308:	f9401e60 	ldr	x0, [x19, #56]
    530c:	aa150294 	orr	x20, x20, x21
    5310:	fc367848 	str	d8, [x2, x22, lsl #3]
    5314:	910006b5 	add	x21, x21, #0x1
    5318:	b8367838 	str	w24, [x1, x22, lsl #2]
    531c:	1e6a392a 	fsub	d10, d9, d10
    5320:	9360fe9a 	asr	x26, x20, #32
    5324:	fc367808 	str	d8, [x0, x22, lsl #3]
    5328:	f9000a75 	str	x21, [x19, #16]
    532c:	b7f80079 	tbnz	x25, #63, 5338 <w120+0xd8>
    5330:	eb99835f 	cmp	x26, x25, asr #32
    5334:	54001e21 	b.ne	56f8 <w120+0x498>  // b.any
    5338:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    533c:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    5340:	eb1a02ff 	cmp	x23, x26
    5344:	540000c0 	b.eq	535c <w120+0xfc>  // b.none
    5348:	aa1a03e0 	mov	x0, x26
    534c:	97fffcd5 	bl	46a0 <fwp_tape_of>
    5350:	aa0003f3 	mov	x19, x0
    5354:	f9403000 	ldr	x0, [x0, #96]
    5358:	b5fffac0 	cbnz	x0, 52b0 <w120+0x50>
    535c:	f9400a77 	ldr	x23, [x19, #16]
    5360:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5364:	eb0002ff 	cmp	x23, x0
    5368:	5400188c 	b.gt	5678 <w120+0x418>
    536c:	eb3442ff 	cmp	x23, w20, uxtw
    5370:	540017ed 	b.le	566c <w120+0x40c>
    5374:	b7f80079 	tbnz	x25, #63, 5380 <w120+0x120>
    5378:	eb3942ff 	cmp	x23, w25, uxtw
    537c:	5400178d 	b.le	566c <w120+0x40c>
    5380:	f9400675 	ldr	x21, [x19, #8]
    5384:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5388:	cb1502f5 	sub	x21, x23, x21
    538c:	910006a1 	add	x1, x21, #0x1
    5390:	eb00003f 	cmp	x1, x0
    5394:	54001728 	b.hi	5678 <w120+0x418>  // b.pmore
    5398:	f9400e60 	ldr	x0, [x19, #24]
    539c:	eb00003f 	cmp	x1, x0
    53a0:	540018ec 	b.gt	56bc <w120+0x45c>
    53a4:	a9420e62 	ldp	x2, x3, [x19, #32]
    53a8:	f100033f 	cmp	x25, #0x0
    53ac:	f9401a61 	ldr	x1, [x19, #48]
    53b0:	b8357854 	str	w20, [x2, x21, lsl #2]
    53b4:	f9401e62 	ldr	x2, [x19, #56]
    53b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53bc:	fc35782b 	str	d11, [x1, x21, lsl #3]
    53c0:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    53c4:	b8357861 	str	w1, [x3, x21, lsl #2]
    53c8:	910006f6 	add	x22, x23, #0x1
    53cc:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    53d0:	92607e94 	and	x20, x20, #0xffffffff00000000
    53d4:	fc357849 	str	d9, [x2, x21, lsl #3]
    53d8:	aa170294 	orr	x20, x20, x23
    53dc:	f9000a76 	str	x22, [x19, #16]
    53e0:	1e68396b 	fsub	d11, d11, d8
    53e4:	b7f81a78 	tbnz	x24, #63, 5730 <w120+0x4d0>
    53e8:	9360ff17 	asr	x23, x24, #32
    53ec:	eb1a02ff 	cmp	x23, x26
    53f0:	540000e0 	b.eq	540c <w120+0x1ac>  // b.none
    53f4:	aa1703e0 	mov	x0, x23
    53f8:	97fffcaa 	bl	46a0 <fwp_tape_of>
    53fc:	aa0003f3 	mov	x19, x0
    5400:	f9403000 	ldr	x0, [x0, #96]
    5404:	b5fff560 	cbnz	x0, 52b0 <w120+0x50>
    5408:	f9400a76 	ldr	x22, [x19, #16]
    540c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5410:	eb0002df 	cmp	x22, x0
    5414:	5400132c 	b.gt	5678 <w120+0x418>
    5418:	eb3842df 	cmp	x22, w24, uxtw
    541c:	5400128d 	b.le	566c <w120+0x40c>
    5420:	f9400675 	ldr	x21, [x19, #8]
    5424:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5428:	cb1502d5 	sub	x21, x22, x21
    542c:	910006a1 	add	x1, x21, #0x1
    5430:	eb00003f 	cmp	x1, x0
    5434:	54001228 	b.hi	5678 <w120+0x418>  // b.pmore
    5438:	f9400e60 	ldr	x0, [x19, #24]
    543c:	eb00003f 	cmp	x1, x0
    5440:	5400138c 	b.gt	56b0 <w120+0x450>
    5444:	a9420262 	ldp	x2, x0, [x19, #32]
    5448:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    544c:	f9401a63 	ldr	x3, [x19, #48]
    5450:	b8357858 	str	w24, [x2, x21, lsl #2]
    5454:	f9401e62 	ldr	x2, [x19, #56]
    5458:	12800001 	mov	w1, #0xffffffff            	// #-1
    545c:	fc357860 	str	d0, [x3, x21, lsl #3]
    5460:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5464:	b8357801 	str	w1, [x0, x21, lsl #2]
    5468:	92607f00 	and	x0, x24, #0xffffffff00000000
    546c:	aa160018 	orr	x24, x0, x22
    5470:	910006c1 	add	x1, x22, #0x1
    5474:	fc357840 	str	d0, [x2, x21, lsl #3]
    5478:	f9000a61 	str	x1, [x19, #16]
    547c:	9360fe99 	asr	x25, x20, #32
    5480:	1e6a0949 	fmul	d9, d10, d10
    5484:	eb17033f 	cmp	x25, x23
    5488:	540000c0 	b.eq	54a0 <w120+0x240>  // b.none
    548c:	aa1903e0 	mov	x0, x25
    5490:	97fffc84 	bl	46a0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5fff0a0 	cbnz	x0, 52b0 <w120+0x50>
    54a0:	f9400a75 	ldr	x21, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002bf 	cmp	x21, x0
    54ac:	54000e6c 	b.gt	5678 <w120+0x418>
    54b0:	eb3442bf 	cmp	x21, w20, uxtw
    54b4:	54000dcd 	b.le	566c <w120+0x40c>
    54b8:	f9400676 	ldr	x22, [x19, #8]
    54bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54c0:	cb1602b6 	sub	x22, x21, x22
    54c4:	910006c1 	add	x1, x22, #0x1
    54c8:	eb00003f 	cmp	x1, x0
    54cc:	54000d68 	b.hi	5678 <w120+0x418>  // b.pmore
    54d0:	f9400e60 	ldr	x0, [x19, #24]
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000e6c 	b.gt	56a4 <w120+0x444>
    54dc:	92607e80 	and	x0, x20, #0xffffffff00000000
    54e0:	aa150017 	orr	x23, x0, x21
    54e4:	a9420261 	ldp	x1, x0, [x19, #32]
    54e8:	f9401a62 	ldr	x2, [x19, #48]
    54ec:	b8367834 	str	w20, [x1, x22, lsl #2]
    54f0:	f9401e61 	ldr	x1, [x19, #56]
    54f4:	fc36784a 	str	d10, [x2, x22, lsl #3]
    54f8:	b8367814 	str	w20, [x0, x22, lsl #2]
    54fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5500:	9e670000 	fmov	d0, x0
    5504:	910006b4 	add	x20, x21, #0x1
    5508:	fc36782a 	str	d10, [x1, x22, lsl #3]
    550c:	9360fef6 	asr	x22, x23, #32
    5510:	f9000a74 	str	x20, [x19, #16]
    5514:	1e600929 	fmul	d9, d9, d0
    5518:	eb1902df 	cmp	x22, x25
    551c:	540000e0 	b.eq	5538 <w120+0x2d8>  // b.none
    5520:	aa1603e0 	mov	x0, x22
    5524:	97fffc5f 	bl	46a0 <fwp_tape_of>
    5528:	aa0003f3 	mov	x19, x0
    552c:	f9403000 	ldr	x0, [x0, #96]
    5530:	b5ffec00 	cbnz	x0, 52b0 <w120+0x50>
    5534:	f9400a74 	ldr	x20, [x19, #16]
    5538:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    553c:	eb00029f 	cmp	x20, x0
    5540:	540009cc 	b.gt	5678 <w120+0x418>
    5544:	eb37429f 	cmp	x20, w23, uxtw
    5548:	5400092d 	b.le	566c <w120+0x40c>
    554c:	f9400675 	ldr	x21, [x19, #8]
    5550:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5554:	cb150295 	sub	x21, x20, x21
    5558:	910006a1 	add	x1, x21, #0x1
    555c:	eb00003f 	cmp	x1, x0
    5560:	540008c8 	b.hi	5678 <w120+0x418>  // b.pmore
    5564:	f9400e60 	ldr	x0, [x19, #24]
    5568:	eb00003f 	cmp	x1, x0
    556c:	5400096c 	b.gt	5698 <w120+0x438>
    5570:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5574:	9e670000 	fmov	d0, x0
    5578:	a9420262 	ldp	x2, x0, [x19, #32]
    557c:	1e6b0968 	fmul	d8, d11, d11
    5580:	f9401a61 	ldr	x1, [x19, #48]
    5584:	b8357857 	str	w23, [x2, x21, lsl #2]
    5588:	f9401e62 	ldr	x2, [x19, #56]
    558c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5590:	12800001 	mov	w1, #0xffffffff            	// #-1
    5594:	b8357801 	str	w1, [x0, x21, lsl #2]
    5598:	91000681 	add	x1, x20, #0x1
    559c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    55a0:	92607ee0 	and	x0, x23, #0xffffffff00000000
    55a4:	f9000a61 	str	x1, [x19, #16]
    55a8:	aa140014 	orr	x20, x0, x20
    55ac:	b100071f 	cmn	x24, #0x1
    55b0:	54000c60 	b.eq	573c <w120+0x4dc>  // b.none
    55b4:	9360ff00 	asr	x0, x24, #32
    55b8:	eb16001f 	cmp	x0, x22
    55bc:	540000a0 	b.eq	55d0 <w120+0x370>  // b.none
    55c0:	97fffc38 	bl	46a0 <fwp_tape_of>
    55c4:	aa0003f3 	mov	x19, x0
    55c8:	f9403000 	ldr	x0, [x0, #96]
    55cc:	b5ffe720 	cbnz	x0, 52b0 <w120+0x50>
    55d0:	f9400a75 	ldr	x21, [x19, #16]
    55d4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55d8:	eb0002bf 	cmp	x21, x0
    55dc:	540004ec 	b.gt	5678 <w120+0x418>
    55e0:	eb3842bf 	cmp	x21, w24, uxtw
    55e4:	5400044d 	b.le	566c <w120+0x40c>
    55e8:	f9400676 	ldr	x22, [x19, #8]
    55ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55f0:	cb1602b6 	sub	x22, x21, x22
    55f4:	910006c1 	add	x1, x22, #0x1
    55f8:	eb00003f 	cmp	x1, x0
    55fc:	540003e8 	b.hi	5678 <w120+0x418>  // b.pmore
    5600:	f9400e60 	ldr	x0, [x19, #24]
    5604:	eb00003f 	cmp	x1, x0
    5608:	5400042c 	b.gt	568c <w120+0x42c>
    560c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5610:	92607f00 	and	x0, x24, #0xffffffff00000000
    5614:	f9401a63 	ldr	x3, [x19, #48]
    5618:	b8367838 	str	w24, [x1, x22, lsl #2]
    561c:	f9401e61 	ldr	x1, [x19, #56]
    5620:	aa150000 	orr	x0, x0, x21
    5624:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5628:	910006b5 	add	x21, x21, #0x1
    562c:	b8367858 	str	w24, [x2, x22, lsl #2]
    5630:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5634:	f9000a75 	str	x21, [x19, #16]
    5638:	1e692908 	fadd	d8, d8, d9
    563c:	aa1403e1 	mov	x1, x20
    5640:	97fffeb0 	bl	5100 <f141.constprop.0>
    5644:	aa0003e1 	mov	x1, x0
    5648:	a94153f3 	ldp	x19, x20, [sp, #16]
    564c:	9e660100 	fmov	x0, d8
    5650:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5654:	a94363f7 	ldp	x23, x24, [sp, #48]
    5658:	a9446bf9 	ldp	x25, x26, [sp, #64]
    565c:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5660:	6d462fea 	ldp	d10, d11, [sp, #96]
    5664:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5668:	d65f03c0 	ret
    566c:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5670:	91232000 	add	x0, x0, #0x8c8
    5674:	97fffa07 	bl	3e90 <fwp_trap>
    5678:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    567c:	9120c000 	add	x0, x0, #0x830
    5680:	97fffa04 	bl	3e90 <fwp_trap>
    5684:	97fffe08 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5688:	17ffff1c 	b	52f8 <w120+0x98>
    568c:	aa1303e0 	mov	x0, x19
    5690:	97fffe05 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5694:	17ffffde 	b	560c <w120+0x3ac>
    5698:	aa1303e0 	mov	x0, x19
    569c:	97fffe02 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56a0:	17ffffb4 	b	5570 <w120+0x310>
    56a4:	aa1303e0 	mov	x0, x19
    56a8:	97fffdff 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56ac:	17ffff8c 	b	54dc <w120+0x27c>
    56b0:	aa1303e0 	mov	x0, x19
    56b4:	97fffdfc 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56b8:	17ffff63 	b	5444 <w120+0x1e4>
    56bc:	aa1303e0 	mov	x0, x19
    56c0:	97fffdf9 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56c4:	17ffff38 	b	53a4 <w120+0x144>
    56c8:	1e6a382a 	fsub	d10, d1, d10
    56cc:	b6f801c1 	tbz	x1, #63, 5704 <w120+0x4a4>
    56d0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56d4:	1e6a0949 	fmul	d9, d10, d10
    56d8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    56dc:	9e670001 	fmov	d1, x0
    56e0:	1e683808 	fsub	d8, d0, d8
    56e4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    56e8:	aa1403e0 	mov	x0, x20
    56ec:	1e610929 	fmul	d9, d9, d1
    56f0:	1e680908 	fmul	d8, d8, d8
    56f4:	17ffffd1 	b	5638 <w120+0x3d8>
    56f8:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    56fc:	91214000 	add	x0, x0, #0x850
    5700:	97fff9e4 	bl	3e90 <fwp_trap>
    5704:	2f00e409 	movi	d9, #0x0
    5708:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    570c:	9360fc3a 	asr	x26, x1, #32
    5710:	aa0103f4 	mov	x20, x1
    5714:	aa1a03e0 	mov	x0, x26
    5718:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    571c:	97fffbe1 	bl	46a0 <fwp_tape_of>
    5720:	aa0003f3 	mov	x19, x0
    5724:	f9403000 	ldr	x0, [x0, #96]
    5728:	b5ffdc40 	cbnz	x0, 52b0 <w120+0x50>
    572c:	17ffff0c 	b	535c <w120+0xfc>
    5730:	aa1a03f7 	mov	x23, x26
    5734:	aa0003f8 	mov	x24, x0
    5738:	17ffff51 	b	547c <w120+0x21c>
    573c:	aa1803e0 	mov	x0, x24
    5740:	17ffffbe 	b	5638 <w120+0x3d8>

0000000000005744 <fwp_rc_share>:
    5744:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5748:	9114c042 	add	x2, x2, #0x530
    574c:	f949d843 	ldr	x3, [x2, #5040]
    5750:	f949ec41 	ldr	x1, [x2, #5080]
    5754:	cb030000 	sub	x0, x0, x3
    5758:	eb01401f 	cmp	x0, x1, lsl #16
    575c:	540003a2 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5760:	d350fc01 	lsr	x1, x0, #16
    5764:	f949fc44 	ldr	x4, [x2, #5112]
    5768:	8b010821 	add	x1, x1, x1, lsl #2
    576c:	d37df021 	lsl	x1, x1, #3
    5770:	8b010083 	add	x3, x4, x1
    5774:	f9401062 	ldr	x2, [x3, #32]
    5778:	b40002c2 	cbz	x2, 57d0 <fwp_rc_share+0x8c>
    577c:	38616881 	ldrb	w1, [x4, x1]
    5780:	7100083f 	cmp	w1, #0x2
    5784:	54000220 	b.eq	57c8 <fwp_rc_share+0x84>  // b.none
    5788:	7100043f 	cmp	w1, #0x1
    578c:	54000221 	b.ne	57d0 <fwp_rc_share+0x8c>  // b.any
    5790:	29430464 	ldp	w4, w1, [x3, #24]
    5794:	92403c00 	and	x0, x0, #0xffff
    5798:	9b047c00 	mul	x0, x0, x4
    579c:	d360fc00 	lsr	x0, x0, #32
    57a0:	eb01001f 	cmp	x0, x1
    57a4:	54000162 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    57a8:	8b000042 	add	x2, x2, x0
    57ac:	39400040 	ldrb	w0, [x2]
    57b0:	34000100 	cbz	w0, 57d0 <fwp_rc_share+0x8c>
    57b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57b8:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    57bc:	9123a000 	add	x0, x0, #0x8e8
    57c0:	910003fd 	mov	x29, sp
    57c4:	97fff9b3 	bl	3e90 <fwp_trap>
    57c8:	72003c1f 	tst	w0, #0xffff
    57cc:	54ffff00 	b.eq	57ac <fwp_rc_share+0x68>  // b.none
    57d0:	d65f03c0 	ret

00000000000057d4 <fwp_rc_free_arr>:
    57d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    57d8:	9114c063 	add	x3, x3, #0x530
    57dc:	f949d861 	ldr	x1, [x3, #5040]
    57e0:	f949ec62 	ldr	x2, [x3, #5080]
    57e4:	cb010001 	sub	x1, x0, x1
    57e8:	eb02403f 	cmp	x1, x2, lsl #16
    57ec:	54000342 	b.cs	5854 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57f0:	d350fc22 	lsr	x2, x1, #16
    57f4:	f949fc65 	ldr	x5, [x3, #5112]
    57f8:	8b020842 	add	x2, x2, x2, lsl #2
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	8b0200a4 	add	x4, x5, x2
    5804:	f9401083 	ldr	x3, [x4, #32]
    5808:	b4000263 	cbz	x3, 5854 <fwp_rc_free_arr+0x80>
    580c:	386268a2 	ldrb	w2, [x5, x2]
    5810:	7100085f 	cmp	w2, #0x2
    5814:	540001c0 	b.eq	584c <fwp_rc_free_arr+0x78>  // b.none
    5818:	7100045f 	cmp	w2, #0x1
    581c:	540001c1 	b.ne	5854 <fwp_rc_free_arr+0x80>  // b.any
    5820:	29430885 	ldp	w5, w2, [x4, #24]
    5824:	92403c21 	and	x1, x1, #0xffff
    5828:	9b057c21 	mul	x1, x1, x5
    582c:	d360fc21 	lsr	x1, x1, #32
    5830:	eb02003f 	cmp	x1, x2
    5834:	54000102 	b.cs	5854 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5838:	8b010063 	add	x3, x3, x1
    583c:	39400061 	ldrb	w1, [x3]
    5840:	7100043f 	cmp	w1, #0x1
    5844:	54000081 	b.ne	5854 <fwp_rc_free_arr+0x80>  // b.any
    5848:	17fffa4e 	b	4180 <fwp_mem_free>
    584c:	72003c3f 	tst	w1, #0xffff
    5850:	54ffff60 	b.eq	583c <fwp_rc_free_arr+0x68>  // b.none
    5854:	d65f03c0 	ret
    5858:	d503201f 	nop
    585c:	d503201f 	nop

0000000000005860 <fwp_rc_dup>:
    5860:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5864:	9114c042 	add	x2, x2, #0x530
    5868:	f949d841 	ldr	x1, [x2, #5040]
    586c:	f949ec43 	ldr	x3, [x2, #5080]
    5870:	cb010001 	sub	x1, x0, x1
    5874:	eb03403f 	cmp	x1, x3, lsl #16
    5878:	54000342 	b.cs	58e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    587c:	d350fc20 	lsr	x0, x1, #16
    5880:	f949fc44 	ldr	x4, [x2, #5112]
    5884:	8b000800 	add	x0, x0, x0, lsl #2
    5888:	d37df002 	lsl	x2, x0, #3
    588c:	8b020083 	add	x3, x4, x2
    5890:	f9401060 	ldr	x0, [x3, #32]
    5894:	b4000260 	cbz	x0, 58e0 <fwp_rc_dup+0x80>
    5898:	38626882 	ldrb	w2, [x4, x2]
    589c:	7100085f 	cmp	w2, #0x2
    58a0:	54000220 	b.eq	58e4 <fwp_rc_dup+0x84>  // b.none
    58a4:	7100045f 	cmp	w2, #0x1
    58a8:	540001c1 	b.ne	58e0 <fwp_rc_dup+0x80>  // b.any
    58ac:	29430864 	ldp	w4, w2, [x3, #24]
    58b0:	92403c21 	and	x1, x1, #0xffff
    58b4:	9b047c21 	mul	x1, x1, x4
    58b8:	d360fc21 	lsr	x1, x1, #32
    58bc:	eb02003f 	cmp	x1, x2
    58c0:	54000102 	b.cs	58e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58c4:	8b010000 	add	x0, x0, x1
    58c8:	39400001 	ldrb	w1, [x0]
    58cc:	340000a1 	cbz	w1, 58e0 <fwp_rc_dup+0x80>
    58d0:	7103f43f 	cmp	w1, #0xfd
    58d4:	540000e8 	b.hi	58f0 <fwp_rc_dup+0x90>  // b.pmore
    58d8:	11000421 	add	w1, w1, #0x1
    58dc:	39000001 	strb	w1, [x0]
    58e0:	d65f03c0 	ret
    58e4:	72003c3f 	tst	w1, #0xffff
    58e8:	54ffff00 	b.eq	58c8 <fwp_rc_dup+0x68>  // b.none
    58ec:	d65f03c0 	ret
    58f0:	17fffa9d 	b	4364 <fwp_rc_wide_dup>

00000000000058f4 <fwp_owned_entry173>:
    58f4:	d10103ff 	sub	sp, sp, #0x40
    58f8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    58fc:	f947f442 	ldr	x2, [x2, #4072]
    5900:	a9027bfd 	stp	x29, x30, [sp, #32]
    5904:	910083fd 	add	x29, sp, #0x20
    5908:	a90353f3 	stp	x19, x20, [sp, #48]
    590c:	f9400043 	ldr	x3, [x2]
    5910:	f9000fe3 	str	x3, [sp, #24]
    5914:	d2800003 	mov	x3, #0x0                   	// #0
    5918:	a9400c01 	ldp	x1, x3, [x0]
    591c:	f9400802 	ldr	x2, [x0, #16]
    5920:	ab020022 	adds	x2, x1, x2
    5924:	540006e6 	b.vs	5a00 <fwp_owned_entry173+0x10c>
    5928:	910023e1 	add	x1, sp, #0x8
    592c:	52800000 	mov	w0, #0x0                   	// #0
    5930:	a9008be3 	stp	x3, x2, [sp, #8]
    5934:	97fffd14 	bl	4d84 <fwp_data.part.0.constprop.0>
    5938:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    593c:	9114c063 	add	x3, x3, #0x530
    5940:	aa0003f3 	mov	x19, x0
    5944:	f949d861 	ldr	x1, [x3, #5040]
    5948:	f949ec60 	ldr	x0, [x3, #5080]
    594c:	cb010261 	sub	x1, x19, x1
    5950:	eb00403f 	cmp	x1, x0, lsl #16
    5954:	54000322 	b.cs	59b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5958:	d350fc22 	lsr	x2, x1, #16
    595c:	f949fc63 	ldr	x3, [x3, #5112]
    5960:	8b020842 	add	x2, x2, x2, lsl #2
    5964:	d37df042 	lsl	x2, x2, #3
    5968:	8b020060 	add	x0, x3, x2
    596c:	f9401014 	ldr	x20, [x0, #32]
    5970:	b4000254 	cbz	x20, 59b8 <fwp_owned_entry173+0xc4>
    5974:	38626862 	ldrb	w2, [x3, x2]
    5978:	7100085f 	cmp	w2, #0x2
    597c:	54000360 	b.eq	59e8 <fwp_owned_entry173+0xf4>  // b.none
    5980:	7100045f 	cmp	w2, #0x1
    5984:	540001a1 	b.ne	59b8 <fwp_owned_entry173+0xc4>  // b.any
    5988:	29430002 	ldp	w2, w0, [x0, #24]
    598c:	92403c21 	and	x1, x1, #0xffff
    5990:	9b027c21 	mul	x1, x1, x2
    5994:	d360fc21 	lsr	x1, x1, #32
    5998:	eb00003f 	cmp	x1, x0
    599c:	540000e2 	b.cs	59b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    59a0:	8b010294 	add	x20, x20, x1
    59a4:	39400280 	ldrb	w0, [x20]
    59a8:	7103fc1f 	cmp	w0, #0xff
    59ac:	54000240 	b.eq	59f4 <fwp_owned_entry173+0x100>  // b.none
    59b0:	52800020 	mov	w0, #0x1                   	// #1
    59b4:	39000280 	strb	w0, [x20]
    59b8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59bc:	f947f400 	ldr	x0, [x0, #4072]
    59c0:	f9400fe2 	ldr	x2, [sp, #24]
    59c4:	f9400001 	ldr	x1, [x0]
    59c8:	eb010042 	subs	x2, x2, x1
    59cc:	d2800001 	mov	x1, #0x0                   	// #0
    59d0:	540001a1 	b.ne	5a04 <fwp_owned_entry173+0x110>  // b.any
    59d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59d8:	aa1303e0 	mov	x0, x19
    59dc:	a94353f3 	ldp	x19, x20, [sp, #48]
    59e0:	910103ff 	add	sp, sp, #0x40
    59e4:	d65f03c0 	ret
    59e8:	72003c3f 	tst	w1, #0xffff
    59ec:	54fffe61 	b.ne	59b8 <fwp_owned_entry173+0xc4>  // b.any
    59f0:	17ffffed 	b	59a4 <fwp_owned_entry173+0xb0>
    59f4:	aa1403e0 	mov	x0, x20
    59f8:	97fff946 	bl	3f10 <fwp_rc_forget_slot.part.0>
    59fc:	17ffffed 	b	59b0 <fwp_owned_entry173+0xbc>
    5a00:	97fff420 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5a04:	97fff39f 	bl	2880 <__stack_chk_fail@plt>
    5a08:	d503201f 	nop
    5a0c:	d503201f 	nop

0000000000005a10 <e173>:
    5a10:	d10103ff 	sub	sp, sp, #0x40
    5a14:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5a18:	f947f442 	ldr	x2, [x2, #4072]
    5a1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a20:	910083fd 	add	x29, sp, #0x20
    5a24:	a90353f3 	stp	x19, x20, [sp, #48]
    5a28:	f9400043 	ldr	x3, [x2]
    5a2c:	f9000fe3 	str	x3, [sp, #24]
    5a30:	d2800003 	mov	x3, #0x0                   	// #0
    5a34:	a9400c01 	ldp	x1, x3, [x0]
    5a38:	f9400802 	ldr	x2, [x0, #16]
    5a3c:	ab020022 	adds	x2, x1, x2
    5a40:	54000726 	b.vs	5b24 <e173+0x114>
    5a44:	910023e1 	add	x1, sp, #0x8
    5a48:	52800000 	mov	w0, #0x0                   	// #0
    5a4c:	a9008be3 	stp	x3, x2, [sp, #8]
    5a50:	97fffccd 	bl	4d84 <fwp_data.part.0.constprop.0>
    5a54:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5a58:	9114c063 	add	x3, x3, #0x530
    5a5c:	aa0003f3 	mov	x19, x0
    5a60:	f949d861 	ldr	x1, [x3, #5040]
    5a64:	f949ec60 	ldr	x0, [x3, #5080]
    5a68:	cb010261 	sub	x1, x19, x1
    5a6c:	eb00403f 	cmp	x1, x0, lsl #16
    5a70:	54000322 	b.cs	5ad4 <e173+0xc4>  // b.hs, b.nlast
    5a74:	d350fc22 	lsr	x2, x1, #16
    5a78:	f949fc63 	ldr	x3, [x3, #5112]
    5a7c:	8b020842 	add	x2, x2, x2, lsl #2
    5a80:	d37df042 	lsl	x2, x2, #3
    5a84:	8b020060 	add	x0, x3, x2
    5a88:	f9401014 	ldr	x20, [x0, #32]
    5a8c:	b4000254 	cbz	x20, 5ad4 <e173+0xc4>
    5a90:	38626862 	ldrb	w2, [x3, x2]
    5a94:	7100085f 	cmp	w2, #0x2
    5a98:	540003a0 	b.eq	5b0c <e173+0xfc>  // b.none
    5a9c:	7100045f 	cmp	w2, #0x1
    5aa0:	540001a1 	b.ne	5ad4 <e173+0xc4>  // b.any
    5aa4:	29430002 	ldp	w2, w0, [x0, #24]
    5aa8:	92403c21 	and	x1, x1, #0xffff
    5aac:	9b027c21 	mul	x1, x1, x2
    5ab0:	d360fc21 	lsr	x1, x1, #32
    5ab4:	eb00003f 	cmp	x1, x0
    5ab8:	540000e2 	b.cs	5ad4 <e173+0xc4>  // b.hs, b.nlast
    5abc:	8b010294 	add	x20, x20, x1
    5ac0:	39400280 	ldrb	w0, [x20]
    5ac4:	7103fc1f 	cmp	w0, #0xff
    5ac8:	54000280 	b.eq	5b18 <e173+0x108>  // b.none
    5acc:	52800020 	mov	w0, #0x1                   	// #1
    5ad0:	39000280 	strb	w0, [x20]
    5ad4:	aa1303e0 	mov	x0, x19
    5ad8:	97ffff1b 	bl	5744 <fwp_rc_share>
    5adc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ae0:	f947f400 	ldr	x0, [x0, #4072]
    5ae4:	f9400fe2 	ldr	x2, [sp, #24]
    5ae8:	f9400001 	ldr	x1, [x0]
    5aec:	eb010042 	subs	x2, x2, x1
    5af0:	d2800001 	mov	x1, #0x0                   	// #0
    5af4:	540001a1 	b.ne	5b28 <e173+0x118>  // b.any
    5af8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5afc:	aa1303e0 	mov	x0, x19
    5b00:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b04:	910103ff 	add	sp, sp, #0x40
    5b08:	d65f03c0 	ret
    5b0c:	72003c3f 	tst	w1, #0xffff
    5b10:	54fffe21 	b.ne	5ad4 <e173+0xc4>  // b.any
    5b14:	17ffffeb 	b	5ac0 <e173+0xb0>
    5b18:	aa1403e0 	mov	x0, x20
    5b1c:	97fff8fd 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5b20:	17ffffeb 	b	5acc <e173+0xbc>
    5b24:	97fff3d7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b28:	97fff356 	bl	2880 <__stack_chk_fail@plt>
    5b2c:	d503201f 	nop

0000000000005b30 <fwp_drop1>:
    5b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b34:	910003fd 	mov	x29, sp
    5b38:	a90153f3 	stp	x19, x20, [sp, #16]
    5b3c:	f90013f5 	str	x21, [sp, #32]
    5b40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5b44:	9114c2b4 	add	x20, x21, #0x530
    5b48:	f949da81 	ldr	x1, [x20, #5040]
    5b4c:	f949ee82 	ldr	x2, [x20, #5080]
    5b50:	cb010001 	sub	x1, x0, x1
    5b54:	eb02403f 	cmp	x1, x2, lsl #16
    5b58:	54000382 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b5c:	d350fc22 	lsr	x2, x1, #16
    5b60:	f949fe84 	ldr	x4, [x20, #5112]
    5b64:	8b020842 	add	x2, x2, x2, lsl #2
    5b68:	d37df042 	lsl	x2, x2, #3
    5b6c:	8b020083 	add	x3, x4, x2
    5b70:	f9401073 	ldr	x19, [x3, #32]
    5b74:	b40002b3 	cbz	x19, 5bc8 <fwp_drop1+0x98>
    5b78:	38626882 	ldrb	w2, [x4, x2]
    5b7c:	7100085f 	cmp	w2, #0x2
    5b80:	540002c0 	b.eq	5bd8 <fwp_drop1+0xa8>  // b.none
    5b84:	7100045f 	cmp	w2, #0x1
    5b88:	54000201 	b.ne	5bc8 <fwp_drop1+0x98>  // b.any
    5b8c:	29430864 	ldp	w4, w2, [x3, #24]
    5b90:	92403c21 	and	x1, x1, #0xffff
    5b94:	9b047c21 	mul	x1, x1, x4
    5b98:	d360fc21 	lsr	x1, x1, #32
    5b9c:	eb02003f 	cmp	x1, x2
    5ba0:	54000142 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ba4:	8b010273 	add	x19, x19, x1
    5ba8:	39400261 	ldrb	w1, [x19]
    5bac:	340000e1 	cbz	w1, 5bc8 <fwp_drop1+0x98>
    5bb0:	7100043f 	cmp	w1, #0x1
    5bb4:	540001e0 	b.eq	5bf0 <fwp_drop1+0xc0>  // b.none
    5bb8:	7103fc3f 	cmp	w1, #0xff
    5bbc:	540002e0 	b.eq	5c18 <fwp_drop1+0xe8>  // b.none
    5bc0:	51000421 	sub	w1, w1, #0x1
    5bc4:	39000261 	strb	w1, [x19]
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	f94013f5 	ldr	x21, [sp, #32]
    5bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bd4:	d65f03c0 	ret
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54fffe60 	b.eq	5ba8 <fwp_drop1+0x78>  // b.none
    5be0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5be4:	f94013f5 	ldr	x21, [sp, #32]
    5be8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bec:	d65f03c0 	ret
    5bf0:	f9400813 	ldr	x19, [x0, #16]
    5bf4:	97fffef8 	bl	57d4 <fwp_rc_free_arr>
    5bf8:	9114c2a0 	add	x0, x21, #0x530
    5bfc:	f949d801 	ldr	x1, [x0, #5040]
    5c00:	f949ec00 	ldr	x0, [x0, #5080]
    5c04:	cb010261 	sub	x1, x19, x1
    5c08:	eb00403f 	cmp	x1, x0, lsl #16
    5c0c:	54fffde2 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c10:	aa1303e0 	mov	x0, x19
    5c14:	17ffffd2 	b	5b5c <fwp_drop1+0x2c>
    5c18:	ca534660 	eor	x0, x19, x19, lsr #17
    5c1c:	9114c2b5 	add	x21, x21, #0x530
    5c20:	ca402400 	eor	x0, x0, x0, lsr #9
    5c24:	92401c00 	and	x0, x0, #0xff
    5c28:	910a2402 	add	x2, x0, #0x289
    5c2c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5c30:	8b020ea2 	add	x2, x21, x2, lsl #3
    5c34:	f94a2400 	ldr	x0, [x0, #5192]
    5c38:	b50000a0 	cbnz	x0, 5c4c <fwp_drop1+0x11c>
    5c3c:	14000013 	b	5c88 <fwp_drop1+0x158>
    5c40:	91004002 	add	x2, x0, #0x10
    5c44:	f9400800 	ldr	x0, [x0, #16]
    5c48:	b4000200 	cbz	x0, 5c88 <fwp_drop1+0x158>
    5c4c:	f9400001 	ldr	x1, [x0]
    5c50:	eb13003f 	cmp	x1, x19
    5c54:	54ffff61 	b.ne	5c40 <fwp_drop1+0x110>  // b.any
    5c58:	f9400041 	ldr	x1, [x2]
    5c5c:	f9400420 	ldr	x0, [x1, #8]
    5c60:	d1000400 	sub	x0, x0, #0x1
    5c64:	f9000420 	str	x0, [x1, #8]
    5c68:	f103f81f 	cmp	x0, #0xfe
    5c6c:	54fffae1 	b.ne	5bc8 <fwp_drop1+0x98>  // b.any
    5c70:	39400260 	ldrb	w0, [x19]
    5c74:	7103fc1f 	cmp	w0, #0xff
    5c78:	540000e0 	b.eq	5c94 <fwp_drop1+0x164>  // b.none
    5c7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c80:	39000260 	strb	w0, [x19]
    5c84:	17ffffd1 	b	5bc8 <fwp_drop1+0x98>
    5c88:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5c8c:	911a0000 	add	x0, x0, #0x680
    5c90:	97fff880 	bl	3e90 <fwp_trap>
    5c94:	aa1303e0 	mov	x0, x19
    5c98:	97fff89e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5c9c:	17fffff8 	b	5c7c <fwp_drop1+0x14c>

0000000000005ca0 <fwp_drop0>:
    5ca0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ca4:	910003fd 	mov	x29, sp
    5ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    5cac:	f90013f5 	str	x21, [sp, #32]
    5cb0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5cb4:	9114c2b4 	add	x20, x21, #0x530
    5cb8:	f949da81 	ldr	x1, [x20, #5040]
    5cbc:	f949ee82 	ldr	x2, [x20, #5080]
    5cc0:	cb010001 	sub	x1, x0, x1
    5cc4:	eb02403f 	cmp	x1, x2, lsl #16
    5cc8:	54000382 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ccc:	d350fc22 	lsr	x2, x1, #16
    5cd0:	f949fe84 	ldr	x4, [x20, #5112]
    5cd4:	8b020842 	add	x2, x2, x2, lsl #2
    5cd8:	d37df042 	lsl	x2, x2, #3
    5cdc:	8b020083 	add	x3, x4, x2
    5ce0:	f9401073 	ldr	x19, [x3, #32]
    5ce4:	b40002b3 	cbz	x19, 5d38 <fwp_drop0+0x98>
    5ce8:	38626882 	ldrb	w2, [x4, x2]
    5cec:	7100085f 	cmp	w2, #0x2
    5cf0:	540002c0 	b.eq	5d48 <fwp_drop0+0xa8>  // b.none
    5cf4:	7100045f 	cmp	w2, #0x1
    5cf8:	54000201 	b.ne	5d38 <fwp_drop0+0x98>  // b.any
    5cfc:	29430864 	ldp	w4, w2, [x3, #24]
    5d00:	92403c21 	and	x1, x1, #0xffff
    5d04:	9b047c21 	mul	x1, x1, x4
    5d08:	d360fc21 	lsr	x1, x1, #32
    5d0c:	eb02003f 	cmp	x1, x2
    5d10:	54000142 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d14:	8b010273 	add	x19, x19, x1
    5d18:	39400261 	ldrb	w1, [x19]
    5d1c:	340000e1 	cbz	w1, 5d38 <fwp_drop0+0x98>
    5d20:	7100043f 	cmp	w1, #0x1
    5d24:	540001e0 	b.eq	5d60 <fwp_drop0+0xc0>  // b.none
    5d28:	7103fc3f 	cmp	w1, #0xff
    5d2c:	540002e0 	b.eq	5d88 <fwp_drop0+0xe8>  // b.none
    5d30:	51000421 	sub	w1, w1, #0x1
    5d34:	39000261 	strb	w1, [x19]
    5d38:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d3c:	f94013f5 	ldr	x21, [sp, #32]
    5d40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d44:	d65f03c0 	ret
    5d48:	72003c3f 	tst	w1, #0xffff
    5d4c:	54fffe60 	b.eq	5d18 <fwp_drop0+0x78>  // b.none
    5d50:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d54:	f94013f5 	ldr	x21, [sp, #32]
    5d58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d5c:	d65f03c0 	ret
    5d60:	f9400813 	ldr	x19, [x0, #16]
    5d64:	97fffe9c 	bl	57d4 <fwp_rc_free_arr>
    5d68:	9114c2a0 	add	x0, x21, #0x530
    5d6c:	f949d801 	ldr	x1, [x0, #5040]
    5d70:	f949ec00 	ldr	x0, [x0, #5080]
    5d74:	cb010261 	sub	x1, x19, x1
    5d78:	eb00403f 	cmp	x1, x0, lsl #16
    5d7c:	54fffde2 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d80:	aa1303e0 	mov	x0, x19
    5d84:	17ffffd2 	b	5ccc <fwp_drop0+0x2c>
    5d88:	ca534660 	eor	x0, x19, x19, lsr #17
    5d8c:	9114c2b5 	add	x21, x21, #0x530
    5d90:	ca402400 	eor	x0, x0, x0, lsr #9
    5d94:	92401c00 	and	x0, x0, #0xff
    5d98:	910a2402 	add	x2, x0, #0x289
    5d9c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5da0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5da4:	f94a2400 	ldr	x0, [x0, #5192]
    5da8:	b50000a0 	cbnz	x0, 5dbc <fwp_drop0+0x11c>
    5dac:	14000013 	b	5df8 <fwp_drop0+0x158>
    5db0:	91004002 	add	x2, x0, #0x10
    5db4:	f9400800 	ldr	x0, [x0, #16]
    5db8:	b4000200 	cbz	x0, 5df8 <fwp_drop0+0x158>
    5dbc:	f9400001 	ldr	x1, [x0]
    5dc0:	eb13003f 	cmp	x1, x19
    5dc4:	54ffff61 	b.ne	5db0 <fwp_drop0+0x110>  // b.any
    5dc8:	f9400041 	ldr	x1, [x2]
    5dcc:	f9400420 	ldr	x0, [x1, #8]
    5dd0:	d1000400 	sub	x0, x0, #0x1
    5dd4:	f9000420 	str	x0, [x1, #8]
    5dd8:	f103f81f 	cmp	x0, #0xfe
    5ddc:	54fffae1 	b.ne	5d38 <fwp_drop0+0x98>  // b.any
    5de0:	39400260 	ldrb	w0, [x19]
    5de4:	7103fc1f 	cmp	w0, #0xff
    5de8:	540000e0 	b.eq	5e04 <fwp_drop0+0x164>  // b.none
    5dec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5df0:	39000260 	strb	w0, [x19]
    5df4:	17ffffd1 	b	5d38 <fwp_drop0+0x98>
    5df8:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5dfc:	911a0000 	add	x0, x0, #0x680
    5e00:	97fff824 	bl	3e90 <fwp_trap>
    5e04:	aa1303e0 	mov	x0, x19
    5e08:	97fff842 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5e0c:	17fffff8 	b	5dec <fwp_drop0+0x14c>

0000000000005e10 <fwp_closure_drop>:
    5e10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    5e14:	9114c0a4 	add	x4, x5, #0x530
    5e18:	aa0003e1 	mov	x1, x0
    5e1c:	f949d882 	ldr	x2, [x4, #5040]
    5e20:	f949ec80 	ldr	x0, [x4, #5080]
    5e24:	cb020022 	sub	x2, x1, x2
    5e28:	eb00405f 	cmp	x2, x0, lsl #16
    5e2c:	54000662 	b.cs	5ef8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e34:	d350fc43 	lsr	x3, x2, #16
    5e38:	910003fd 	mov	x29, sp
    5e3c:	8b030863 	add	x3, x3, x3, lsl #2
    5e40:	f949fc84 	ldr	x4, [x4, #5112]
    5e44:	d37df063 	lsl	x3, x3, #3
    5e48:	f9000bf3 	str	x19, [sp, #16]
    5e4c:	8b030080 	add	x0, x4, x3
    5e50:	f9401013 	ldr	x19, [x0, #32]
    5e54:	b40002b3 	cbz	x19, 5ea8 <fwp_closure_drop+0x98>
    5e58:	38636883 	ldrb	w3, [x4, x3]
    5e5c:	7100087f 	cmp	w3, #0x2
    5e60:	54000420 	b.eq	5ee4 <fwp_closure_drop+0xd4>  // b.none
    5e64:	7100047f 	cmp	w3, #0x1
    5e68:	54000201 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5e6c:	29430003 	ldp	w3, w0, [x0, #24]
    5e70:	92403c42 	and	x2, x2, #0xffff
    5e74:	9b037c42 	mul	x2, x2, x3
    5e78:	d360fc42 	lsr	x2, x2, #32
    5e7c:	eb00005f 	cmp	x2, x0
    5e80:	54000142 	b.cs	5ea8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e84:	8b020273 	add	x19, x19, x2
    5e88:	39400260 	ldrb	w0, [x19]
    5e8c:	340000e0 	cbz	w0, 5ea8 <fwp_closure_drop+0x98>
    5e90:	7100041f 	cmp	w0, #0x1
    5e94:	54000100 	b.eq	5eb4 <fwp_closure_drop+0xa4>  // b.none
    5e98:	7103fc1f 	cmp	w0, #0xff
    5e9c:	54000300 	b.eq	5efc <fwp_closure_drop+0xec>  // b.none
    5ea0:	51000400 	sub	w0, w0, #0x1
    5ea4:	39000260 	strb	w0, [x19]
    5ea8:	f9400bf3 	ldr	x19, [sp, #16]
    5eac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb0:	d65f03c0 	ret
    5eb4:	d53bd040 	mrs	x0, tpidr_el0
    5eb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5ebc:	91004000 	add	x0, x0, #0x10
    5ec0:	f9400000 	ldr	x0, [x0]
    5ec4:	b4000080 	cbz	x0, 5ed4 <fwp_closure_drop+0xc4>
    5ec8:	f9400bf3 	ldr	x19, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	17fff96c 	b	4480 <fwp_closure_drop_push>
    5ed4:	f9400bf3 	ldr	x19, [sp, #16]
    5ed8:	aa0103e0 	mov	x0, x1
    5edc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ee0:	17fff9ad 	b	4594 <fwp_closure_drop.part.0>
    5ee4:	72003c5f 	tst	w2, #0xffff
    5ee8:	54fffd00 	b.eq	5e88 <fwp_closure_drop+0x78>  // b.none
    5eec:	f9400bf3 	ldr	x19, [sp, #16]
    5ef0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ef4:	d65f03c0 	ret
    5ef8:	d65f03c0 	ret
    5efc:	ca534660 	eor	x0, x19, x19, lsr #17
    5f00:	9114c0a5 	add	x5, x5, #0x530
    5f04:	ca402400 	eor	x0, x0, x0, lsr #9
    5f08:	92401c00 	and	x0, x0, #0xff
    5f0c:	910a2402 	add	x2, x0, #0x289
    5f10:	8b000ca0 	add	x0, x5, x0, lsl #3
    5f14:	8b020ca2 	add	x2, x5, x2, lsl #3
    5f18:	f94a2400 	ldr	x0, [x0, #5192]
    5f1c:	b50000a0 	cbnz	x0, 5f30 <fwp_closure_drop+0x120>
    5f20:	14000013 	b	5f6c <fwp_closure_drop+0x15c>
    5f24:	91004002 	add	x2, x0, #0x10
    5f28:	f9400800 	ldr	x0, [x0, #16]
    5f2c:	b4000200 	cbz	x0, 5f6c <fwp_closure_drop+0x15c>
    5f30:	f9400001 	ldr	x1, [x0]
    5f34:	eb13003f 	cmp	x1, x19
    5f38:	54ffff61 	b.ne	5f24 <fwp_closure_drop+0x114>  // b.any
    5f3c:	f9400041 	ldr	x1, [x2]
    5f40:	f9400420 	ldr	x0, [x1, #8]
    5f44:	d1000400 	sub	x0, x0, #0x1
    5f48:	f9000420 	str	x0, [x1, #8]
    5f4c:	f103f81f 	cmp	x0, #0xfe
    5f50:	54fffac1 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5f54:	39400260 	ldrb	w0, [x19]
    5f58:	7103fc1f 	cmp	w0, #0xff
    5f5c:	540000e0 	b.eq	5f78 <fwp_closure_drop+0x168>  // b.none
    5f60:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f64:	39000260 	strb	w0, [x19]
    5f68:	17ffffd0 	b	5ea8 <fwp_closure_drop+0x98>
    5f6c:	90000020 	adrp	x0, 9000 <__divti3+0x1e0>
    5f70:	911a0000 	add	x0, x0, #0x680
    5f74:	97fff7c7 	bl	3e90 <fwp_trap>
    5f78:	aa1303e0 	mov	x0, x19
    5f7c:	97fff7e5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5f80:	17fffff8 	b	5f60 <fwp_closure_drop+0x150>

0000000000005f84 <fwp_owned_tape_release>:
    5f84:	b4000920 	cbz	x0, 60a8 <fwp_owned_tape_release+0x124>
    5f88:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f8c:	910003fd 	mov	x29, sp
    5f90:	a90153f3 	stp	x19, x20, [sp, #16]
    5f94:	aa0003f3 	mov	x19, x0
    5f98:	f9400000 	ldr	x0, [x0]
    5f9c:	b4000060 	cbz	x0, 5fa8 <fwp_owned_tape_release+0x24>
    5fa0:	f9400661 	ldr	x1, [x19, #8]
    5fa4:	f9000401 	str	x1, [x0, #8]
    5fa8:	f9400661 	ldr	x1, [x19, #8]
    5fac:	b4000041 	cbz	x1, 5fb4 <fwp_owned_tape_release+0x30>
    5fb0:	f9000020 	str	x0, [x1]
    5fb4:	f9400a60 	ldr	x0, [x19, #16]
    5fb8:	f9403401 	ldr	x1, [x0, #104]
    5fbc:	b40005a1 	cbz	x1, 6070 <fwp_owned_tape_release+0xec>
    5fc0:	a9450a60 	ldp	x0, x2, [x19, #80]
    5fc4:	eb00005f 	cmp	x2, x0
    5fc8:	540002cd 	b.le	6020 <fwp_owned_tape_release+0x9c>
    5fcc:	d2800014 	mov	x20, #0x0                   	// #0
    5fd0:	f90013f5 	str	x21, [sp, #32]
    5fd4:	d2800015 	mov	x21, #0x0                   	// #0
    5fd8:	f9402260 	ldr	x0, [x19, #64]
    5fdc:	910006b5 	add	x21, x21, #0x1
    5fe0:	f8746800 	ldr	x0, [x0, x20]
    5fe4:	d63f0020 	blr	x1
    5fe8:	f9402260 	ldr	x0, [x19, #64]
    5fec:	f9400a61 	ldr	x1, [x19, #16]
    5ff0:	8b140000 	add	x0, x0, x20
    5ff4:	91004294 	add	x20, x20, #0x10
    5ff8:	f9400400 	ldr	x0, [x0, #8]
    5ffc:	f9403421 	ldr	x1, [x1, #104]
    6000:	d63f0020 	blr	x1
    6004:	a9450261 	ldp	x1, x0, [x19, #80]
    6008:	cb010000 	sub	x0, x0, x1
    600c:	eb15001f 	cmp	x0, x21
    6010:	f9400a60 	ldr	x0, [x19, #16]
    6014:	f9403401 	ldr	x1, [x0, #104]
    6018:	54fffe0c 	b.gt	5fd8 <fwp_owned_tape_release+0x54>
    601c:	f94013f5 	ldr	x21, [sp, #32]
    6020:	f9403663 	ldr	x3, [x19, #104]
    6024:	f9401262 	ldr	x2, [x19, #32]
    6028:	f100007f 	cmp	x3, #0x0
    602c:	540001ed 	b.le	6068 <fwp_owned_tape_release+0xe4>
    6030:	d2800014 	mov	x20, #0x0                   	// #0
    6034:	d503201f 	nop
    6038:	f9402660 	ldr	x0, [x19, #72]
    603c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6040:	eb02001f 	cmp	x0, x2
    6044:	540000c0 	b.eq	605c <fwp_owned_tape_release+0xd8>  // b.none
    6048:	d63f0020 	blr	x1
    604c:	f9400a60 	ldr	x0, [x19, #16]
    6050:	f9401262 	ldr	x2, [x19, #32]
    6054:	f9403663 	ldr	x3, [x19, #104]
    6058:	f9403401 	ldr	x1, [x0, #104]
    605c:	91000694 	add	x20, x20, #0x1
    6060:	eb14007f 	cmp	x3, x20
    6064:	54fffeac 	b.gt	6038 <fwp_owned_tape_release+0xb4>
    6068:	aa0203e0 	mov	x0, x2
    606c:	d63f0020 	blr	x1
    6070:	f9401660 	ldr	x0, [x19, #40]
    6074:	97ffff67 	bl	5e10 <fwp_closure_drop>
    6078:	f9401a60 	ldr	x0, [x19, #48]
    607c:	97ffff65 	bl	5e10 <fwp_closure_drop>
    6080:	f9401e60 	ldr	x0, [x19, #56]
    6084:	97ffff63 	bl	5e10 <fwp_closure_drop>
    6088:	f9402260 	ldr	x0, [x19, #64]
    608c:	97fff83d 	bl	4180 <fwp_mem_free>
    6090:	f9402660 	ldr	x0, [x19, #72]
    6094:	97fff83b 	bl	4180 <fwp_mem_free>
    6098:	aa1303e0 	mov	x0, x19
    609c:	a94153f3 	ldp	x19, x20, [sp, #16]
    60a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60a4:	17fff837 	b	4180 <fwp_mem_free>
    60a8:	d65f03c0 	ret
    60ac:	d503201f 	nop

00000000000060b0 <fwp_tape_finish>:
    60b0:	d10203ff 	sub	sp, sp, #0x80
    60b4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    60b8:	f947f421 	ldr	x1, [x1, #4072]
    60bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    60c0:	910103fd 	add	x29, sp, #0x40
    60c4:	a90553f3 	stp	x19, x20, [sp, #80]
    60c8:	a9065bf5 	stp	x21, x22, [sp, #96]
    60cc:	a90763f7 	stp	x23, x24, [sp, #112]
    60d0:	d00000d8 	adrp	x24, 20000 <__data_start>
    60d4:	9100c316 	add	x22, x24, #0x30
    60d8:	f9400022 	ldr	x2, [x1]
    60dc:	f9001fe2 	str	x2, [sp, #56]
    60e0:	d2800002 	mov	x2, #0x0                   	// #0
    60e4:	9100e2c0 	add	x0, x22, #0x38
    60e8:	97fff486 	bl	3300 <fwp_tape_buffers_dispose>
    60ec:	f9003adf 	str	xzr, [x22, #112]
    60f0:	f94042c0 	ldr	x0, [x22, #128]
    60f4:	f100001f 	cmp	x0, #0x0
    60f8:	5400030d 	b.le	6158 <fwp_tape_finish+0xa8>
    60fc:	910003f7 	mov	x23, sp
    6100:	d2800015 	mov	x21, #0x0                   	// #0
    6104:	d2800014 	mov	x20, #0x0                   	// #0
    6108:	f94002d3 	ldr	x19, [x22]
    610c:	91000694 	add	x20, x20, #0x1
    6110:	8b150273 	add	x19, x19, x21
    6114:	9101a2b5 	add	x21, x21, #0x68
    6118:	aa1303e0 	mov	x0, x19
    611c:	97fff39d 	bl	2f90 <fwp_tape_unlink_scope>
    6120:	aa1703e0 	mov	x0, x23
    6124:	f9401261 	ldr	x1, [x19, #32]
    6128:	f90003e1 	str	x1, [sp]
    612c:	f9401a62 	ldr	x2, [x19, #48]
    6130:	f9000be2 	str	x2, [sp, #16]
    6134:	f9402261 	ldr	x1, [x19, #64]
    6138:	f90013e1 	str	x1, [sp, #32]
    613c:	97fff471 	bl	3300 <fwp_tape_buffers_dispose>
    6140:	f9403260 	ldr	x0, [x19, #96]
    6144:	97ffff90 	bl	5f84 <fwp_owned_tape_release>
    6148:	f900327f 	str	xzr, [x19, #96]
    614c:	f94042c0 	ldr	x0, [x22, #128]
    6150:	eb14001f 	cmp	x0, x20
    6154:	54fffdac 	b.gt	6108 <fwp_tape_finish+0x58>
    6158:	f9401b00 	ldr	x0, [x24, #48]
    615c:	9100c313 	add	x19, x24, #0x30
    6160:	97fff1f8 	bl	2940 <free@plt>
    6164:	f9001b1f 	str	xzr, [x24, #48]
    6168:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    616c:	f947f400 	ldr	x0, [x0, #4072]
    6170:	f900427f 	str	xzr, [x19, #128]
    6174:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6178:	f9401fe2 	ldr	x2, [sp, #56]
    617c:	f9400001 	ldr	x1, [x0]
    6180:	eb010042 	subs	x2, x2, x1
    6184:	d2800001 	mov	x1, #0x0                   	// #0
    6188:	540000e1 	b.ne	61a4 <fwp_tape_finish+0xf4>  // b.any
    618c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6190:	a94553f3 	ldp	x19, x20, [sp, #80]
    6194:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6198:	a94763f7 	ldp	x23, x24, [sp, #112]
    619c:	910203ff 	add	sp, sp, #0x80
    61a0:	d65f03c0 	ret
    61a4:	97fff1b7 	bl	2880 <__stack_chk_fail@plt>
    61a8:	d503201f 	nop
    61ac:	d503201f 	nop

00000000000061b0 <fwp_tape_scope_release>:
    61b0:	d10243ff 	sub	sp, sp, #0x90
    61b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    61b8:	910103fd 	add	x29, sp, #0x40
    61bc:	a90553f3 	stp	x19, x20, [sp, #80]
    61c0:	aa0003f4 	mov	x20, x0
    61c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61c8:	f947f400 	ldr	x0, [x0, #4072]
    61cc:	b9400285 	ldr	w5, [x20]
    61d0:	f9400001 	ldr	x1, [x0]
    61d4:	f9001fe1 	str	x1, [sp, #56]
    61d8:	d2800001 	mov	x1, #0x0                   	// #0
    61dc:	37f806c5 	tbnz	w5, #31, 62b4 <fwp_tape_scope_release+0x104>
    61e0:	a90763f7 	stp	x23, x24, [sp, #112]
    61e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    61e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    61ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    61f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    61f4:	910003f7 	mov	x23, sp
    61f8:	9100c273 	add	x19, x19, #0x30
    61fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	52800d16 	mov	w22, #0x68                  	// #104
    6208:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    620c:	f90043f9 	str	x25, [sp, #128]
    6210:	14000006 	b	6228 <fwp_tape_scope_release+0x78>
    6214:	97fff43b 	bl	3300 <fwp_tape_buffers_dispose>
    6218:	aa1903e0 	mov	x0, x25
    621c:	97ffff5a 	bl	5f84 <fwp_owned_tape_release>
    6220:	b9400285 	ldr	w5, [x20]
    6224:	37f80425 	tbnz	w5, #31, 62a8 <fwp_tape_scope_release+0xf8>
    6228:	f9400266 	ldr	x6, [x19]
    622c:	9b367ca5 	smull	x5, w5, w22
    6230:	8b0500c0 	add	x0, x6, x5
    6234:	97fff357 	bl	2f90 <fwp_tape_unlink_scope>
    6238:	ad410001 	ldp	q1, q0, [x0, #32]
    623c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6240:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6244:	f9400c03 	ldr	x3, [x0, #24]
    6248:	ad0003e1 	stp	q1, q0, [sp]
    624c:	b86568c1 	ldr	w1, [x6, x5]
    6250:	a9440804 	ldp	x4, x2, [x0, #64]
    6254:	b900041f 	str	wzr, [x0, #4]
    6258:	f9403019 	ldr	x25, [x0, #96]
    625c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6260:	f9000c1f 	str	xzr, [x0, #24]
    6264:	a9020fe4 	stp	x4, x3, [sp, #32]
    6268:	f9001be2 	str	x2, [sp, #48]
    626c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6270:	f900301f 	str	xzr, [x0, #96]
    6274:	6b15003f 	cmp	w1, w21
    6278:	540000e8 	b.hi	6294 <fwp_tape_scope_release+0xe4>  // b.pmore
    627c:	9343fca5 	asr	x5, x5, #3
    6280:	f9404e60 	ldr	x0, [x19, #152]
    6284:	9b187ca5 	mul	x5, x5, x24
    6288:	eb0000bf 	cmp	x5, x0
    628c:	5400004a 	b.ge	6294 <fwp_tape_scope_release+0xe4>  // b.tcont
    6290:	f9004e65 	str	x5, [x19, #152]
    6294:	aa1703e0 	mov	x0, x23
    6298:	b5fffbf9 	cbnz	x25, 6214 <fwp_tape_scope_release+0x64>
    629c:	97fff6b5 	bl	3d70 <fwp_tape_buffers_release>
    62a0:	b9400285 	ldr	w5, [x20]
    62a4:	36fffc25 	tbz	w5, #31, 6228 <fwp_tape_scope_release+0x78>
    62a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    62ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    62b0:	f94043f9 	ldr	x25, [sp, #128]
    62b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    62b8:	f947f400 	ldr	x0, [x0, #4072]
    62bc:	f9401fe2 	ldr	x2, [sp, #56]
    62c0:	f9400001 	ldr	x1, [x0]
    62c4:	eb010042 	subs	x2, x2, x1
    62c8:	d2800001 	mov	x1, #0x0                   	// #0
    62cc:	540000a1 	b.ne	62e0 <fwp_tape_scope_release+0x130>  // b.any
    62d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    62d8:	910243ff 	add	sp, sp, #0x90
    62dc:	d65f03c0 	ret
    62e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    62e4:	a90763f7 	stp	x23, x24, [sp, #112]
    62e8:	f90043f9 	str	x25, [sp, #128]
    62ec:	97fff165 	bl	2880 <__stack_chk_fail@plt>

00000000000062f0 <fwp_drop4>:
    62f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62f4:	910003fd 	mov	x29, sp
    62f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    62fc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    6300:	9114c2d5 	add	x21, x22, #0x530
    6304:	a90153f3 	stp	x19, x20, [sp, #16]
    6308:	aa0003f3 	mov	x19, x0
    630c:	f949daa1 	ldr	x1, [x21, #5040]
    6310:	f949eea0 	ldr	x0, [x21, #5080]
    6314:	cb010261 	sub	x1, x19, x1
    6318:	eb00403f 	cmp	x1, x0, lsl #16
    631c:	54000382 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6320:	d350fc22 	lsr	x2, x1, #16
    6324:	f949fea3 	ldr	x3, [x21, #5112]
    6328:	8b020842 	add	x2, x2, x2, lsl #2
    632c:	d37df042 	lsl	x2, x2, #3
    6330:	8b020060 	add	x0, x3, x2
    6334:	f9401014 	ldr	x20, [x0, #32]
    6338:	b40002b4 	cbz	x20, 638c <fwp_drop4+0x9c>
    633c:	38626862 	ldrb	w2, [x3, x2]
    6340:	7100085f 	cmp	w2, #0x2
    6344:	540002c0 	b.eq	639c <fwp_drop4+0xac>  // b.none
    6348:	7100045f 	cmp	w2, #0x1
    634c:	54000201 	b.ne	638c <fwp_drop4+0x9c>  // b.any
    6350:	29430002 	ldp	w2, w0, [x0, #24]
    6354:	92403c21 	and	x1, x1, #0xffff
    6358:	9b027c21 	mul	x1, x1, x2
    635c:	d360fc21 	lsr	x1, x1, #32
    6360:	eb00003f 	cmp	x1, x0
    6364:	54000142 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6368:	8b010294 	add	x20, x20, x1
    636c:	39400280 	ldrb	w0, [x20]
    6370:	340000e0 	cbz	w0, 638c <fwp_drop4+0x9c>
    6374:	7100041f 	cmp	w0, #0x1
    6378:	540001e0 	b.eq	63b4 <fwp_drop4+0xc4>  // b.none
    637c:	7103fc1f 	cmp	w0, #0xff
    6380:	540007c0 	b.eq	6478 <fwp_drop4+0x188>  // b.none
    6384:	51000400 	sub	w0, w0, #0x1
    6388:	39000280 	strb	w0, [x20]
    638c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6390:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6394:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6398:	d65f03c0 	ret
    639c:	72003c3f 	tst	w1, #0xffff
    63a0:	54fffe60 	b.eq	636c <fwp_drop4+0x7c>  // b.none
    63a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63b0:	d65f03c0 	ret
    63b4:	9114c2c2 	add	x2, x22, #0x530
    63b8:	f9400660 	ldr	x0, [x19, #8]
    63bc:	f949d841 	ldr	x1, [x2, #5040]
    63c0:	f949ec42 	ldr	x2, [x2, #5080]
    63c4:	cb010001 	sub	x1, x0, x1
    63c8:	eb02403f 	cmp	x1, x2, lsl #16
    63cc:	54000362 	b.cs	6438 <fwp_drop4+0x148>  // b.hs, b.nlast
    63d0:	d350fc22 	lsr	x2, x1, #16
    63d4:	8b020842 	add	x2, x2, x2, lsl #2
    63d8:	d37df042 	lsl	x2, x2, #3
    63dc:	8b020064 	add	x4, x3, x2
    63e0:	f9401094 	ldr	x20, [x4, #32]
    63e4:	b40002b4 	cbz	x20, 6438 <fwp_drop4+0x148>
    63e8:	38626862 	ldrb	w2, [x3, x2]
    63ec:	7100085f 	cmp	w2, #0x2
    63f0:	540003e0 	b.eq	646c <fwp_drop4+0x17c>  // b.none
    63f4:	7100045f 	cmp	w2, #0x1
    63f8:	54000201 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    63fc:	29430883 	ldp	w3, w2, [x4, #24]
    6400:	92403c21 	and	x1, x1, #0xffff
    6404:	9b037c21 	mul	x1, x1, x3
    6408:	d360fc21 	lsr	x1, x1, #32
    640c:	eb02003f 	cmp	x1, x2
    6410:	54000142 	b.cs	6438 <fwp_drop4+0x148>  // b.hs, b.nlast
    6414:	8b010294 	add	x20, x20, x1
    6418:	39400281 	ldrb	w1, [x20]
    641c:	340000e1 	cbz	w1, 6438 <fwp_drop4+0x148>
    6420:	7100043f 	cmp	w1, #0x1
    6424:	54000200 	b.eq	6464 <fwp_drop4+0x174>  // b.none
    6428:	7103fc3f 	cmp	w1, #0xff
    642c:	54000640 	b.eq	64f4 <fwp_drop4+0x204>  // b.none
    6430:	51000421 	sub	w1, w1, #0x1
    6434:	39000281 	strb	w1, [x20]
    6438:	f9400a74 	ldr	x20, [x19, #16]
    643c:	aa1303e0 	mov	x0, x19
    6440:	97fffce5 	bl	57d4 <fwp_rc_free_arr>
    6444:	9114c2c0 	add	x0, x22, #0x530
    6448:	f949d801 	ldr	x1, [x0, #5040]
    644c:	f949ec00 	ldr	x0, [x0, #5080]
    6450:	cb010281 	sub	x1, x20, x1
    6454:	eb00403f 	cmp	x1, x0, lsl #16
    6458:	54fff9a2 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    645c:	aa1403f3 	mov	x19, x20
    6460:	17ffffb0 	b	6320 <fwp_drop4+0x30>
    6464:	97fffcdc 	bl	57d4 <fwp_rc_free_arr>
    6468:	17fffff4 	b	6438 <fwp_drop4+0x148>
    646c:	72003c3f 	tst	w1, #0xffff
    6470:	54fffe41 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    6474:	17ffffe9 	b	6418 <fwp_drop4+0x128>
    6478:	ca544681 	eor	x1, x20, x20, lsr #17
    647c:	9114c2c0 	add	x0, x22, #0x530
    6480:	ca412421 	eor	x1, x1, x1, lsr #9
    6484:	92401c21 	and	x1, x1, #0xff
    6488:	910a2422 	add	x2, x1, #0x289
    648c:	8b010c01 	add	x1, x0, x1, lsl #3
    6490:	8b020c02 	add	x2, x0, x2, lsl #3
    6494:	f94a2420 	ldr	x0, [x1, #5192]
    6498:	b50000a0 	cbnz	x0, 64ac <fwp_drop4+0x1bc>
    649c:	14000013 	b	64e8 <fwp_drop4+0x1f8>
    64a0:	91004002 	add	x2, x0, #0x10
    64a4:	f9400800 	ldr	x0, [x0, #16]
    64a8:	b4000200 	cbz	x0, 64e8 <fwp_drop4+0x1f8>
    64ac:	f9400001 	ldr	x1, [x0]
    64b0:	eb14003f 	cmp	x1, x20
    64b4:	54ffff61 	b.ne	64a0 <fwp_drop4+0x1b0>  // b.any
    64b8:	f9400041 	ldr	x1, [x2]
    64bc:	f9400420 	ldr	x0, [x1, #8]
    64c0:	d1000400 	sub	x0, x0, #0x1
    64c4:	f9000420 	str	x0, [x1, #8]
    64c8:	f103f81f 	cmp	x0, #0xfe
    64cc:	54fff601 	b.ne	638c <fwp_drop4+0x9c>  // b.any
    64d0:	39400280 	ldrb	w0, [x20]
    64d4:	7103fc1f 	cmp	w0, #0xff
    64d8:	54000460 	b.eq	6564 <fwp_drop4+0x274>  // b.none
    64dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64e0:	39000280 	strb	w0, [x20]
    64e4:	17ffffaa 	b	638c <fwp_drop4+0x9c>
    64e8:	f0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    64ec:	911a0000 	add	x0, x0, #0x680
    64f0:	97fff668 	bl	3e90 <fwp_trap>
    64f4:	ca544680 	eor	x0, x20, x20, lsr #17
    64f8:	9114c2c1 	add	x1, x22, #0x530
    64fc:	ca402400 	eor	x0, x0, x0, lsr #9
    6500:	92401c00 	and	x0, x0, #0xff
    6504:	910a2402 	add	x2, x0, #0x289
    6508:	8b000c20 	add	x0, x1, x0, lsl #3
    650c:	8b020c22 	add	x2, x1, x2, lsl #3
    6510:	f94a2400 	ldr	x0, [x0, #5192]
    6514:	b50000a0 	cbnz	x0, 6528 <fwp_drop4+0x238>
    6518:	17fffff4 	b	64e8 <fwp_drop4+0x1f8>
    651c:	91004002 	add	x2, x0, #0x10
    6520:	f9400800 	ldr	x0, [x0, #16]
    6524:	b4fffe20 	cbz	x0, 64e8 <fwp_drop4+0x1f8>
    6528:	f9400001 	ldr	x1, [x0]
    652c:	eb14003f 	cmp	x1, x20
    6530:	54ffff61 	b.ne	651c <fwp_drop4+0x22c>  // b.any
    6534:	f9400041 	ldr	x1, [x2]
    6538:	f9400420 	ldr	x0, [x1, #8]
    653c:	d1000400 	sub	x0, x0, #0x1
    6540:	f9000420 	str	x0, [x1, #8]
    6544:	f103f81f 	cmp	x0, #0xfe
    6548:	54fff781 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    654c:	39400280 	ldrb	w0, [x20]
    6550:	7103fc1f 	cmp	w0, #0xff
    6554:	540000e0 	b.eq	6570 <fwp_drop4+0x280>  // b.none
    6558:	12800020 	mov	w0, #0xfffffffe            	// #-2
    655c:	39000280 	strb	w0, [x20]
    6560:	17ffffb6 	b	6438 <fwp_drop4+0x148>
    6564:	aa1403e0 	mov	x0, x20
    6568:	97fff66a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    656c:	17ffffdc 	b	64dc <fwp_drop4+0x1ec>
    6570:	aa1403e0 	mov	x0, x20
    6574:	97fff667 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6578:	17fffff8 	b	6558 <fwp_drop4+0x268>
    657c:	d503201f 	nop

0000000000006580 <fwp_arg_drop37>:
    6580:	7100003f 	cmp	w1, #0x0
    6584:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6588:	54000041 	b.ne	6590 <fwp_arg_drop37+0x10>  // b.any
    658c:	d65f03c0 	ret
    6590:	f9400000 	ldr	x0, [x0]
    6594:	17ffff57 	b	62f0 <fwp_drop4>
    6598:	d503201f 	nop
    659c:	d503201f 	nop

00000000000065a0 <fwp_task_dispose>:
    65a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	f9000bf3 	str	x19, [sp, #16]
    65ac:	aa0003f3 	mov	x19, x0
    65b0:	39414000 	ldrb	w0, [x0, #80]
    65b4:	36000720 	tbz	w0, #0, 6698 <fwp_task_dispose+0xf8>
    65b8:	f9400a60 	ldr	x0, [x19, #16]
    65bc:	b50006e0 	cbnz	x0, 6698 <fwp_task_dispose+0xf8>
    65c0:	a9478660 	ldp	x0, x1, [x19, #120]
    65c4:	39014e7f 	strb	wzr, [x19, #83]
    65c8:	f9003e7f 	str	xzr, [x19, #120]
    65cc:	f100003f 	cmp	x1, #0x0
    65d0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65d4:	54000040 	b.eq	65dc <fwp_task_dispose+0x3c>  // b.none
    65d8:	d63f0020 	blr	x1
    65dc:	f9405660 	ldr	x0, [x19, #168]
    65e0:	97fff6e8 	bl	4180 <fwp_mem_free>
    65e4:	f900567f 	str	xzr, [x19, #168]
    65e8:	b9405e60 	ldr	w0, [x19, #92]
    65ec:	7100041f 	cmp	w0, #0x1
    65f0:	54000420 	b.eq	6674 <fwp_task_dispose+0xd4>  // b.none
    65f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    65f8:	9114c042 	add	x2, x2, #0x530
    65fc:	f949d840 	ldr	x0, [x2, #5040]
    6600:	f949ec41 	ldr	x1, [x2, #5080]
    6604:	cb000260 	sub	x0, x19, x0
    6608:	eb01401f 	cmp	x0, x1, lsl #16
    660c:	540002e2 	b.cs	6668 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6610:	d350fc01 	lsr	x1, x0, #16
    6614:	f949fc44 	ldr	x4, [x2, #5112]
    6618:	8b010821 	add	x1, x1, x1, lsl #2
    661c:	d37df021 	lsl	x1, x1, #3
    6620:	8b010083 	add	x3, x4, x1
    6624:	f9401062 	ldr	x2, [x3, #32]
    6628:	b4000202 	cbz	x2, 6668 <fwp_task_dispose+0xc8>
    662c:	38616881 	ldrb	w1, [x4, x1]
    6630:	7100083f 	cmp	w1, #0x2
    6634:	54000280 	b.eq	6684 <fwp_task_dispose+0xe4>  // b.none
    6638:	7100043f 	cmp	w1, #0x1
    663c:	54000161 	b.ne	6668 <fwp_task_dispose+0xc8>  // b.any
    6640:	29430464 	ldp	w4, w1, [x3, #24]
    6644:	92403c00 	and	x0, x0, #0xffff
    6648:	9b047c00 	mul	x0, x0, x4
    664c:	d360fc00 	lsr	x0, x0, #32
    6650:	eb01001f 	cmp	x0, x1
    6654:	540000a2 	b.cs	6668 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6658:	8b000042 	add	x2, x2, x0
    665c:	39400040 	ldrb	w0, [x2]
    6660:	7100041f 	cmp	w0, #0x1
    6664:	54000080 	b.eq	6674 <fwp_task_dispose+0xd4>  // b.none
    6668:	f9400bf3 	ldr	x19, [sp, #16]
    666c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6670:	d65f03c0 	ret
    6674:	aa1303e0 	mov	x0, x19
    6678:	f9400bf3 	ldr	x19, [sp, #16]
    667c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6680:	17fff6c0 	b	4180 <fwp_mem_free>
    6684:	72003c1f 	tst	w0, #0xffff
    6688:	54fffea0 	b.eq	665c <fwp_task_dispose+0xbc>  // b.none
    668c:	f9400bf3 	ldr	x19, [sp, #16]
    6690:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6694:	d65f03c0 	ret
    6698:	97fff08e 	bl	28d0 <abort@plt>
    669c:	d503201f 	nop

00000000000066a0 <fwp_free_zombie>:
    66a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66a4:	910003fd 	mov	x29, sp
    66a8:	a90153f3 	stp	x19, x20, [sp, #16]
    66ac:	d00000d4 	adrp	x20, 20000 <__data_start>
    66b0:	9100c281 	add	x1, x20, #0x30
    66b4:	f9405033 	ldr	x19, [x1, #160]
    66b8:	b4000333 	cbz	x19, 671c <fwp_free_zombie+0x7c>
    66bc:	f9400820 	ldr	x0, [x1, #16]
    66c0:	eb00027f 	cmp	x19, x0
    66c4:	540002c0 	b.eq	671c <fwp_free_zombie+0x7c>  // b.none
    66c8:	b940a822 	ldr	w2, [x1, #168]
    66cc:	f9400a60 	ldr	x0, [x19, #16]
    66d0:	7100fc5f 	cmp	w2, #0x3f
    66d4:	5400078c 	b.gt	67c4 <fwp_free_zombie+0x124>
    66d8:	9102c023 	add	x3, x1, #0xb0
    66dc:	11000444 	add	w4, w2, #0x1
    66e0:	b900a824 	str	w4, [x1, #168]
    66e4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66e8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66ec:	a9530261 	ldp	x1, x0, [x19, #304]
    66f0:	b4000741 	cbz	x1, 67d8 <fwp_free_zombie+0x138>
    66f4:	f9009c20 	str	x0, [x1, #312]
    66f8:	b4000040 	cbz	x0, 6700 <fwp_free_zombie+0x60>
    66fc:	f9009801 	str	x1, [x0, #304]
    6700:	9100c294 	add	x20, x20, #0x30
    6704:	b9405e60 	ldr	w0, [x19, #92]
    6708:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    670c:	f900529f 	str	xzr, [x20, #160]
    6710:	34000140 	cbz	w0, 6738 <fwp_free_zombie+0x98>
    6714:	7100041f 	cmp	w0, #0x1
    6718:	54000080 	b.eq	6728 <fwp_free_zombie+0x88>  // b.none
    671c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6720:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6724:	d65f03c0 	ret
    6728:	aa1303e0 	mov	x0, x19
    672c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6730:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6734:	17ffff9b 	b	65a0 <fwp_task_dispose>
    6738:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    673c:	9114c082 	add	x2, x4, #0x530
    6740:	f949d841 	ldr	x1, [x2, #5040]
    6744:	f949ec40 	ldr	x0, [x2, #5080]
    6748:	cb010261 	sub	x1, x19, x1
    674c:	eb00403f 	cmp	x1, x0, lsl #16
    6750:	54fffe62 	b.cs	671c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6754:	d350fc20 	lsr	x0, x1, #16
    6758:	f949fc43 	ldr	x3, [x2, #5112]
    675c:	8b000800 	add	x0, x0, x0, lsl #2
    6760:	d37df000 	lsl	x0, x0, #3
    6764:	8b000062 	add	x2, x3, x0
    6768:	f9401054 	ldr	x20, [x2, #32]
    676c:	b4fffd94 	cbz	x20, 671c <fwp_free_zombie+0x7c>
    6770:	38606860 	ldrb	w0, [x3, x0]
    6774:	7100081f 	cmp	w0, #0x2
    6778:	54000360 	b.eq	67e4 <fwp_free_zombie+0x144>  // b.none
    677c:	7100041f 	cmp	w0, #0x1
    6780:	54fffce1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    6784:	29430043 	ldp	w3, w0, [x2, #24]
    6788:	92403c21 	and	x1, x1, #0xffff
    678c:	9b037c21 	mul	x1, x1, x3
    6790:	d360fc21 	lsr	x1, x1, #32
    6794:	eb00003f 	cmp	x1, x0
    6798:	54fffc22 	b.cs	671c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    679c:	8b010294 	add	x20, x20, x1
    67a0:	39400280 	ldrb	w0, [x20]
    67a4:	34fffbc0 	cbz	w0, 671c <fwp_free_zombie+0x7c>
    67a8:	7100041f 	cmp	w0, #0x1
    67ac:	54fffbe0 	b.eq	6728 <fwp_free_zombie+0x88>  // b.none
    67b0:	7103fc1f 	cmp	w0, #0xff
    67b4:	540001e0 	b.eq	67f0 <fwp_free_zombie+0x150>  // b.none
    67b8:	51000400 	sub	w0, w0, #0x1
    67bc:	39000280 	strb	w0, [x20]
    67c0:	17ffffd7 	b	671c <fwp_free_zombie+0x7c>
    67c4:	f9400e61 	ldr	x1, [x19, #24]
    67c8:	97fff076 	bl	29a0 <munmap@plt>
    67cc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67d0:	a9530261 	ldp	x1, x0, [x19, #304]
    67d4:	b5fff901 	cbnz	x1, 66f4 <fwp_free_zombie+0x54>
    67d8:	9100c282 	add	x2, x20, #0x30
    67dc:	f9015840 	str	x0, [x2, #688]
    67e0:	17ffffc6 	b	66f8 <fwp_free_zombie+0x58>
    67e4:	72003c3f 	tst	w1, #0xffff
    67e8:	54fff9a1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    67ec:	17ffffed 	b	67a0 <fwp_free_zombie+0x100>
    67f0:	ca544680 	eor	x0, x20, x20, lsr #17
    67f4:	9114c084 	add	x4, x4, #0x530
    67f8:	ca402400 	eor	x0, x0, x0, lsr #9
    67fc:	92401c00 	and	x0, x0, #0xff
    6800:	910a2402 	add	x2, x0, #0x289
    6804:	8b000c80 	add	x0, x4, x0, lsl #3
    6808:	8b020c82 	add	x2, x4, x2, lsl #3
    680c:	f94a2400 	ldr	x0, [x0, #5192]
    6810:	b50000a0 	cbnz	x0, 6824 <fwp_free_zombie+0x184>
    6814:	14000013 	b	6860 <fwp_free_zombie+0x1c0>
    6818:	91004002 	add	x2, x0, #0x10
    681c:	f9400800 	ldr	x0, [x0, #16]
    6820:	b4000200 	cbz	x0, 6860 <fwp_free_zombie+0x1c0>
    6824:	f9400001 	ldr	x1, [x0]
    6828:	eb14003f 	cmp	x1, x20
    682c:	54ffff61 	b.ne	6818 <fwp_free_zombie+0x178>  // b.any
    6830:	f9400041 	ldr	x1, [x2]
    6834:	f9400420 	ldr	x0, [x1, #8]
    6838:	d1000400 	sub	x0, x0, #0x1
    683c:	f9000420 	str	x0, [x1, #8]
    6840:	f103f81f 	cmp	x0, #0xfe
    6844:	54fff6c1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    6848:	39400280 	ldrb	w0, [x20]
    684c:	7103fc1f 	cmp	w0, #0xff
    6850:	540000e0 	b.eq	686c <fwp_free_zombie+0x1cc>  // b.none
    6854:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6858:	39000280 	strb	w0, [x20]
    685c:	17ffffb0 	b	671c <fwp_free_zombie+0x7c>
    6860:	f0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    6864:	911a0000 	add	x0, x0, #0x680
    6868:	97fff58a 	bl	3e90 <fwp_trap>
    686c:	aa1403e0 	mov	x0, x20
    6870:	97fff5a8 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6874:	17fffff8 	b	6854 <fwp_free_zombie+0x1b4>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <fwp_block>:
    6880:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6884:	910003fd 	mov	x29, sp
    6888:	a90153f3 	stp	x19, x20, [sp, #16]
    688c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6890:	9100c274 	add	x20, x19, #0x30
    6894:	f9401a82 	ldr	x2, [x20, #48]
    6898:	b4000642 	cbz	x2, 6960 <fwp_block+0xe0>
    689c:	9100c261 	add	x1, x19, #0x30
    68a0:	f9408040 	ldr	x0, [x2, #256]
    68a4:	f9001820 	str	x0, [x1, #48]
    68a8:	b40006a0 	cbz	x0, 697c <fwp_block+0xfc>
    68ac:	d503201f 	nop
    68b0:	9100c263 	add	x3, x19, #0x30
    68b4:	3901505f 	strb	wzr, [x2, #84]
    68b8:	f9400864 	ldr	x4, [x3, #16]
    68bc:	eb02009f 	cmp	x4, x2
    68c0:	54000440 	b.eq	6948 <fwp_block+0xc8>  // b.none
    68c4:	f9415c65 	ldr	x5, [x3, #696]
    68c8:	f9000862 	str	x2, [x3, #16]
    68cc:	f9400441 	ldr	x1, [x2, #8]
    68d0:	f9004885 	str	x5, [x4, #144]
    68d4:	f9416065 	ldr	x5, [x3, #704]
    68d8:	f9004c85 	str	x5, [x4, #152]
    68dc:	f9416465 	ldr	x5, [x3, #712]
    68e0:	f9005085 	str	x5, [x4, #160]
    68e4:	f9416865 	ldr	x5, [x3, #720]
    68e8:	f9005485 	str	x5, [x4, #168]
    68ec:	f9416c65 	ldr	x5, [x3, #728]
    68f0:	f9005885 	str	x5, [x4, #176]
    68f4:	f9417065 	ldr	x5, [x3, #736]
    68f8:	f9005c85 	str	x5, [x4, #184]
    68fc:	f9417465 	ldr	x5, [x3, #744]
    6900:	f9006085 	str	x5, [x4, #192]
    6904:	f9400480 	ldr	x0, [x4, #8]
    6908:	f9404844 	ldr	x4, [x2, #144]
    690c:	f9015c64 	str	x4, [x3, #696]
    6910:	f9404c44 	ldr	x4, [x2, #152]
    6914:	f9016064 	str	x4, [x3, #704]
    6918:	f9405044 	ldr	x4, [x2, #160]
    691c:	f9016464 	str	x4, [x3, #712]
    6920:	f9405444 	ldr	x4, [x2, #168]
    6924:	f9016864 	str	x4, [x3, #720]
    6928:	f9405844 	ldr	x4, [x2, #176]
    692c:	f9016c64 	str	x4, [x3, #728]
    6930:	a94b8844 	ldp	x4, x2, [x2, #184]
    6934:	f9017064 	str	x4, [x3, #736]
    6938:	f9017462 	str	x2, [x3, #744]
    693c:	97ffefe9 	bl	28e0 <swapcontext@plt>
    6940:	97ffff58 	bl	66a0 <fwp_free_zombie>
    6944:	d503201f 	nop
    6948:	9100c260 	add	x0, x19, #0x30
    694c:	b942f000 	ldr	w0, [x0, #752]
    6950:	340001a0 	cbz	w0, 6984 <fwp_block+0x104>
    6954:	a94153f3 	ldp	x19, x20, [sp, #16]
    6958:	a8c27bfd 	ldp	x29, x30, [sp], #32
    695c:	d65f03c0 	ret
    6960:	97fff794 	bl	47b0 <fwp_poll_events>
    6964:	f9401a82 	ldr	x2, [x20, #48]
    6968:	b4ffffc2 	cbz	x2, 6960 <fwp_block+0xe0>
    696c:	9100c261 	add	x1, x19, #0x30
    6970:	f9408040 	ldr	x0, [x2, #256]
    6974:	f9001820 	str	x0, [x1, #48]
    6978:	b5fff9c0 	cbnz	x0, 68b0 <fwp_block+0x30>
    697c:	f900143f 	str	xzr, [x1, #40]
    6980:	17ffffcc 	b	68b0 <fwp_block+0x30>
    6984:	f0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    6988:	91246000 	add	x0, x0, #0x918
    698c:	97fff021 	bl	2a10 <getenv@plt>
    6990:	5284e202 	mov	w2, #0x2710                	// #10000
    6994:	b4000060 	cbz	x0, 69a0 <fwp_block+0x120>
    6998:	39400001 	ldrb	w1, [x0]
    699c:	350000c1 	cbnz	w1, 69b4 <fwp_block+0x134>
    69a0:	9100c273 	add	x19, x19, #0x30
    69a4:	b902f262 	str	w2, [x19, #752]
    69a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69b0:	d65f03c0 	ret
    69b4:	52800142 	mov	w2, #0xa                   	// #10
    69b8:	d2800001 	mov	x1, #0x0                   	// #0
    69bc:	97ffef65 	bl	2750 <strtoll@plt>
    69c0:	d1000403 	sub	x3, x0, #0x1
    69c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69c8:	eb02007f 	cmp	x3, x2
    69cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69d4:	17fffff3 	b	69a0 <fwp_block+0x120>
    69d8:	d503201f 	nop
    69dc:	d503201f 	nop

00000000000069e0 <fwp_drop10>:
    69e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69e4:	910003fd 	mov	x29, sp
    69e8:	a90153f3 	stp	x19, x20, [sp, #16]
    69ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    69f0:	f90013f5 	str	x21, [sp, #32]
    69f4:	9114c275 	add	x21, x19, #0x530
    69f8:	f949daa1 	ldr	x1, [x21, #5040]
    69fc:	f949eea2 	ldr	x2, [x21, #5080]
    6a00:	cb010001 	sub	x1, x0, x1
    6a04:	eb02403f 	cmp	x1, x2, lsl #16
    6a08:	54000382 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a0c:	d350fc22 	lsr	x2, x1, #16
    6a10:	f949fea3 	ldr	x3, [x21, #5112]
    6a14:	8b020842 	add	x2, x2, x2, lsl #2
    6a18:	d37df042 	lsl	x2, x2, #3
    6a1c:	8b020064 	add	x4, x3, x2
    6a20:	f9401094 	ldr	x20, [x4, #32]
    6a24:	b40002b4 	cbz	x20, 6a78 <fwp_drop10+0x98>
    6a28:	38626862 	ldrb	w2, [x3, x2]
    6a2c:	7100085f 	cmp	w2, #0x2
    6a30:	540007a0 	b.eq	6b24 <fwp_drop10+0x144>  // b.none
    6a34:	7100045f 	cmp	w2, #0x1
    6a38:	54000201 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6a3c:	29430885 	ldp	w5, w2, [x4, #24]
    6a40:	92403c21 	and	x1, x1, #0xffff
    6a44:	9b057c21 	mul	x1, x1, x5
    6a48:	d360fc21 	lsr	x1, x1, #32
    6a4c:	eb02003f 	cmp	x1, x2
    6a50:	54000142 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a54:	8b010294 	add	x20, x20, x1
    6a58:	39400281 	ldrb	w1, [x20]
    6a5c:	340000e1 	cbz	w1, 6a78 <fwp_drop10+0x98>
    6a60:	7100043f 	cmp	w1, #0x1
    6a64:	54000120 	b.eq	6a88 <fwp_drop10+0xa8>  // b.none
    6a68:	7103fc3f 	cmp	w1, #0xff
    6a6c:	540007c0 	b.eq	6b64 <fwp_drop10+0x184>  // b.none
    6a70:	51000421 	sub	w1, w1, #0x1
    6a74:	39000281 	strb	w1, [x20]
    6a78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a7c:	f94013f5 	ldr	x21, [sp, #32]
    6a80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a84:	d65f03c0 	ret
    6a88:	f9400001 	ldr	x1, [x0]
    6a8c:	b7f80581 	tbnz	x1, #63, 6b3c <fwp_drop10+0x15c>
    6a90:	9114c273 	add	x19, x19, #0x530
    6a94:	f949da61 	ldr	x1, [x19, #5040]
    6a98:	f949ee62 	ldr	x2, [x19, #5080]
    6a9c:	cb010001 	sub	x1, x0, x1
    6aa0:	eb02403f 	cmp	x1, x2, lsl #16
    6aa4:	54fffea2 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6aa8:	d350fc22 	lsr	x2, x1, #16
    6aac:	8b020842 	add	x2, x2, x2, lsl #2
    6ab0:	d37df042 	lsl	x2, x2, #3
    6ab4:	8b020065 	add	x5, x3, x2
    6ab8:	f94010a4 	ldr	x4, [x5, #32]
    6abc:	b4fffde4 	cbz	x4, 6a78 <fwp_drop10+0x98>
    6ac0:	38626862 	ldrb	w2, [x3, x2]
    6ac4:	7100085f 	cmp	w2, #0x2
    6ac8:	54000220 	b.eq	6b0c <fwp_drop10+0x12c>  // b.none
    6acc:	7100045f 	cmp	w2, #0x1
    6ad0:	54fffd41 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6ad4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ad8:	92403c21 	and	x1, x1, #0xffff
    6adc:	9b037c21 	mul	x1, x1, x3
    6ae0:	d360fc21 	lsr	x1, x1, #32
    6ae4:	eb02003f 	cmp	x1, x2
    6ae8:	54fffc82 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6aec:	8b010084 	add	x4, x4, x1
    6af0:	39400081 	ldrb	w1, [x4]
    6af4:	7100043f 	cmp	w1, #0x1
    6af8:	54fffc01 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	f94013f5 	ldr	x21, [sp, #32]
    6b04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b08:	17fff59e 	b	4180 <fwp_mem_free>
    6b0c:	72003c3f 	tst	w1, #0xffff
    6b10:	54ffff00 	b.eq	6af0 <fwp_drop10+0x110>  // b.none
    6b14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b18:	f94013f5 	ldr	x21, [sp, #32]
    6b1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b20:	d65f03c0 	ret
    6b24:	72003c3f 	tst	w1, #0xffff
    6b28:	54fff980 	b.eq	6a58 <fwp_drop10+0x78>  // b.none
    6b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b30:	f94013f5 	ldr	x21, [sp, #32]
    6b34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b38:	d65f03c0 	ret
    6b3c:	f9400414 	ldr	x20, [x0, #8]
    6b40:	97fffb25 	bl	57d4 <fwp_rc_free_arr>
    6b44:	9114c260 	add	x0, x19, #0x530
    6b48:	f949d801 	ldr	x1, [x0, #5040]
    6b4c:	f949ec00 	ldr	x0, [x0, #5080]
    6b50:	cb010281 	sub	x1, x20, x1
    6b54:	eb00403f 	cmp	x1, x0, lsl #16
    6b58:	54fff902 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b5c:	aa1403e0 	mov	x0, x20
    6b60:	17ffffab 	b	6a0c <fwp_drop10+0x2c>
    6b64:	ca544680 	eor	x0, x20, x20, lsr #17
    6b68:	9114c273 	add	x19, x19, #0x530
    6b6c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b70:	92401c00 	and	x0, x0, #0xff
    6b74:	910a2402 	add	x2, x0, #0x289
    6b78:	8b000e60 	add	x0, x19, x0, lsl #3
    6b7c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b80:	f94a2400 	ldr	x0, [x0, #5192]
    6b84:	b50000a0 	cbnz	x0, 6b98 <fwp_drop10+0x1b8>
    6b88:	14000013 	b	6bd4 <fwp_drop10+0x1f4>
    6b8c:	91004002 	add	x2, x0, #0x10
    6b90:	f9400800 	ldr	x0, [x0, #16]
    6b94:	b4000200 	cbz	x0, 6bd4 <fwp_drop10+0x1f4>
    6b98:	f9400001 	ldr	x1, [x0]
    6b9c:	eb14003f 	cmp	x1, x20
    6ba0:	54ffff61 	b.ne	6b8c <fwp_drop10+0x1ac>  // b.any
    6ba4:	f9400041 	ldr	x1, [x2]
    6ba8:	f9400420 	ldr	x0, [x1, #8]
    6bac:	d1000400 	sub	x0, x0, #0x1
    6bb0:	f9000420 	str	x0, [x1, #8]
    6bb4:	f103f81f 	cmp	x0, #0xfe
    6bb8:	54fff601 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6bbc:	39400280 	ldrb	w0, [x20]
    6bc0:	7103fc1f 	cmp	w0, #0xff
    6bc4:	540000e0 	b.eq	6be0 <fwp_drop10+0x200>  // b.none
    6bc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bcc:	39000280 	strb	w0, [x20]
    6bd0:	17ffffaa 	b	6a78 <fwp_drop10+0x98>
    6bd4:	f0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    6bd8:	911a0000 	add	x0, x0, #0x680
    6bdc:	97fff4ad 	bl	3e90 <fwp_trap>
    6be0:	aa1403e0 	mov	x0, x20
    6be4:	97fff4cb 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6be8:	17fffff8 	b	6bc8 <fwp_drop10+0x1e8>
    6bec:	d503201f 	nop

0000000000006bf0 <fwp_caps173>:
    6bf0:	34000041 	cbz	w1, 6bf8 <fwp_caps173+0x8>
    6bf4:	d65f03c0 	ret
    6bf8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    6bfc:	9114c063 	add	x3, x3, #0x530
    6c00:	f949d861 	ldr	x1, [x3, #5040]
    6c04:	f949ec62 	ldr	x2, [x3, #5080]
    6c08:	cb010001 	sub	x1, x0, x1
    6c0c:	eb02403f 	cmp	x1, x2, lsl #16
    6c10:	54ffff22 	b.cs	6bf4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c14:	d350fc22 	lsr	x2, x1, #16
    6c18:	f949fc65 	ldr	x5, [x3, #5112]
    6c1c:	8b020842 	add	x2, x2, x2, lsl #2
    6c20:	d37df042 	lsl	x2, x2, #3
    6c24:	8b0200a4 	add	x4, x5, x2
    6c28:	f9401083 	ldr	x3, [x4, #32]
    6c2c:	b4fffe43 	cbz	x3, 6bf4 <fwp_caps173+0x4>
    6c30:	386268a2 	ldrb	w2, [x5, x2]
    6c34:	7100085f 	cmp	w2, #0x2
    6c38:	540001c0 	b.eq	6c70 <fwp_caps173+0x80>  // b.none
    6c3c:	7100045f 	cmp	w2, #0x1
    6c40:	54fffda1 	b.ne	6bf4 <fwp_caps173+0x4>  // b.any
    6c44:	29430885 	ldp	w5, w2, [x4, #24]
    6c48:	92403c21 	and	x1, x1, #0xffff
    6c4c:	9b057c21 	mul	x1, x1, x5
    6c50:	d360fc21 	lsr	x1, x1, #32
    6c54:	eb02003f 	cmp	x1, x2
    6c58:	54fffce2 	b.cs	6bf4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c5c:	8b010063 	add	x3, x3, x1
    6c60:	39400061 	ldrb	w1, [x3]
    6c64:	7100043f 	cmp	w1, #0x1
    6c68:	54fffc61 	b.ne	6bf4 <fwp_caps173+0x4>  // b.any
    6c6c:	17fff545 	b	4180 <fwp_mem_free>
    6c70:	72003c3f 	tst	w1, #0xffff
    6c74:	54ffff60 	b.eq	6c60 <fwp_caps173+0x70>  // b.none
    6c78:	d65f03c0 	ret
    6c7c:	d503201f 	nop

0000000000006c80 <f37>:
    6c80:	d10203ff 	sub	sp, sp, #0x80
    6c84:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6c88:	f947f421 	ldr	x1, [x1, #4072]
    6c8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6c90:	910083fd 	add	x29, sp, #0x20
    6c94:	a9045bf5 	stp	x21, x22, [sp, #64]
    6c98:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    6c9c:	9114c2a3 	add	x3, x21, #0x530
    6ca0:	a90353f3 	stp	x19, x20, [sp, #48]
    6ca4:	aa0003f6 	mov	x22, x0
    6ca8:	a90563f7 	stp	x23, x24, [sp, #80]
    6cac:	a9066bf9 	stp	x25, x26, [sp, #96]
    6cb0:	f949ec62 	ldr	x2, [x3, #5080]
    6cb4:	f9400024 	ldr	x4, [x1]
    6cb8:	f9000fe4 	str	x4, [sp, #24]
    6cbc:	d2800004 	mov	x4, #0x0                   	// #0
    6cc0:	f949d861 	ldr	x1, [x3, #5040]
    6cc4:	d370bc42 	lsl	x2, x2, #16
    6cc8:	b4001820 	cbz	x0, 6fcc <f37+0x34c>
    6ccc:	f9400817 	ldr	x23, [x0, #16]
    6cd0:	cb0102e1 	sub	x1, x23, x1
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54000362 	b.cs	6d44 <f37+0xc4>  // b.hs, b.nlast
    6cdc:	f949fc60 	ldr	x0, [x3, #5112]
    6ce0:	d350fc22 	lsr	x2, x1, #16
    6ce4:	8b020842 	add	x2, x2, x2, lsl #2
    6ce8:	8b020c02 	add	x2, x0, x2, lsl #3
    6cec:	f9401040 	ldr	x0, [x2, #32]
    6cf0:	b40002a0 	cbz	x0, 6d44 <f37+0xc4>
    6cf4:	39400043 	ldrb	w3, [x2]
    6cf8:	7100087f 	cmp	w3, #0x2
    6cfc:	54001560 	b.eq	6fa8 <f37+0x328>  // b.none
    6d00:	7100047f 	cmp	w3, #0x1
    6d04:	540001c1 	b.ne	6d3c <f37+0xbc>  // b.any
    6d08:	29430843 	ldp	w3, w2, [x2, #24]
    6d0c:	92403c21 	and	x1, x1, #0xffff
    6d10:	9b037c21 	mul	x1, x1, x3
    6d14:	d360fc21 	lsr	x1, x1, #32
    6d18:	eb02003f 	cmp	x1, x2
    6d1c:	54000102 	b.cs	6d3c <f37+0xbc>  // b.hs, b.nlast
    6d20:	8b010000 	add	x0, x0, x1
    6d24:	39400001 	ldrb	w1, [x0]
    6d28:	340000a1 	cbz	w1, 6d3c <f37+0xbc>
    6d2c:	7103f43f 	cmp	w1, #0xfd
    6d30:	54001808 	b.hi	7030 <f37+0x3b0>  // b.pmore
    6d34:	11000421 	add	w1, w1, #0x1
    6d38:	39000001 	strb	w1, [x0]
    6d3c:	d2800002 	mov	x2, #0x0                   	// #0
    6d40:	b40000f6 	cbz	x22, 6d5c <f37+0xdc>
    6d44:	aa1603e1 	mov	x1, x22
    6d48:	d2800002 	mov	x2, #0x0                   	// #0
    6d4c:	d503201f 	nop
    6d50:	f9400821 	ldr	x1, [x1, #16]
    6d54:	91000442 	add	x2, x2, #0x1
    6d58:	b5ffffc1 	cbnz	x1, 6d50 <f37+0xd0>
    6d5c:	b40013f7 	cbz	x23, 6fd8 <f37+0x358>
    6d60:	aa1703e1 	mov	x1, x23
    6d64:	d2800003 	mov	x3, #0x0                   	// #0
    6d68:	f9400821 	ldr	x1, [x1, #16]
    6d6c:	91000463 	add	x3, x3, #0x1
    6d70:	b5ffffc1 	cbnz	x1, 6d68 <f37+0xe8>
    6d74:	eb02007f 	cmp	x3, x2
    6d78:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6d7c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6d80:	eb00027f 	cmp	x19, x0
    6d84:	540010a8 	b.hi	6f98 <f37+0x318>  // b.pmore
    6d88:	d37ffa74 	lsl	x20, x19, #1
    6d8c:	52800041 	mov	w1, #0x2                   	// #2
    6d90:	91000680 	add	x0, x20, #0x1
    6d94:	d37df000 	lsl	x0, x0, #3
    6d98:	97fff7b6 	bl	4c70 <fwp_heap_alloc>
    6d9c:	aa0003f8 	mov	x24, x0
    6da0:	9114c2a1 	add	x1, x21, #0x530
    6da4:	aa0103e0 	mov	x0, x1
    6da8:	f9000314 	str	x20, [x24]
    6dac:	f949d821 	ldr	x1, [x1, #5040]
    6db0:	f949ec00 	ldr	x0, [x0, #5080]
    6db4:	cb010301 	sub	x1, x24, x1
    6db8:	eb00403f 	cmp	x1, x0, lsl #16
    6dbc:	54000342 	b.cs	6e24 <f37+0x1a4>  // b.hs, b.nlast
    6dc0:	9114c2a2 	add	x2, x21, #0x530
    6dc4:	d350fc20 	lsr	x0, x1, #16
    6dc8:	8b000800 	add	x0, x0, x0, lsl #2
    6dcc:	f949fc43 	ldr	x3, [x2, #5112]
    6dd0:	d37df002 	lsl	x2, x0, #3
    6dd4:	8b020060 	add	x0, x3, x2
    6dd8:	f9401014 	ldr	x20, [x0, #32]
    6ddc:	b4000254 	cbz	x20, 6e24 <f37+0x1a4>
    6de0:	38626862 	ldrb	w2, [x3, x2]
    6de4:	7100085f 	cmp	w2, #0x2
    6de8:	54000ec0 	b.eq	6fc0 <f37+0x340>  // b.none
    6dec:	7100045f 	cmp	w2, #0x1
    6df0:	540001a1 	b.ne	6e24 <f37+0x1a4>  // b.any
    6df4:	29430002 	ldp	w2, w0, [x0, #24]
    6df8:	92403c21 	and	x1, x1, #0xffff
    6dfc:	9b027c21 	mul	x1, x1, x2
    6e00:	d360fc21 	lsr	x1, x1, #32
    6e04:	eb00003f 	cmp	x1, x0
    6e08:	540000e2 	b.cs	6e24 <f37+0x1a4>  // b.hs, b.nlast
    6e0c:	8b010294 	add	x20, x20, x1
    6e10:	39400280 	ldrb	w0, [x20]
    6e14:	7103fc1f 	cmp	w0, #0xff
    6e18:	54001100 	b.eq	7038 <f37+0x3b8>  // b.none
    6e1c:	52800020 	mov	w0, #0x1                   	// #1
    6e20:	39000280 	strb	w0, [x20]
    6e24:	b4000253 	cbz	x19, 6e6c <f37+0x1ec>
    6e28:	8b131313 	add	x19, x24, x19, lsl #4
    6e2c:	aa1803f4 	mov	x20, x24
    6e30:	aa1603fa 	mov	x26, x22
    6e34:	aa1703f9 	mov	x25, x23
    6e38:	f9400723 	ldr	x3, [x25, #8]
    6e3c:	f9400742 	ldr	x2, [x26, #8]
    6e40:	f9400861 	ldr	x1, [x3, #16]
    6e44:	f9400840 	ldr	x0, [x2, #16]
    6e48:	fd400461 	ldr	d1, [x3, #8]
    6e4c:	fd400440 	ldr	d0, [x2, #8]
    6e50:	97fff904 	bl	5260 <w120>
    6e54:	f9000680 	str	x0, [x20, #8]
    6e58:	f8010e81 	str	x1, [x20, #16]!
    6e5c:	f9400b39 	ldr	x25, [x25, #16]
    6e60:	f9400b5a 	ldr	x26, [x26, #16]
    6e64:	eb14027f 	cmp	x19, x20
    6e68:	54fffe81 	b.ne	6e38 <f37+0x1b8>  // b.any
    6e6c:	aa1703e0 	mov	x0, x23
    6e70:	97fffd20 	bl	62f0 <fwp_drop4>
    6e74:	aa1603e0 	mov	x0, x22
    6e78:	97fffd1e 	bl	62f0 <fwp_drop4>
    6e7c:	f9400316 	ldr	x22, [x24]
    6e80:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6e84:	b4000236 	cbz	x22, 6ec8 <f37+0x248>
    6e88:	fd003be8 	str	d8, [sp, #112]
    6e8c:	2f00e408 	movi	d8, #0x0
    6e90:	91002319 	add	x25, x24, #0x8
    6e94:	91004317 	add	x23, x24, #0x10
    6e98:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6e9c:	d2800013 	mov	x19, #0x0                   	// #0
    6ea0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6ea4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    6ea8:	91000a73 	add	x19, x19, #0x2
    6eac:	1e602908 	fadd	d8, d8, d0
    6eb0:	97fff894 	bl	5100 <f141.constprop.0>
    6eb4:	aa0003f4 	mov	x20, x0
    6eb8:	eb1302df 	cmp	x22, x19
    6ebc:	54ffff28 	b.hi	6ea0 <f37+0x220>  // b.pmore
    6ec0:	9e660116 	fmov	x22, d8
    6ec4:	fd403be8 	ldr	d8, [sp, #112]
    6ec8:	9114c2b5 	add	x21, x21, #0x530
    6ecc:	aa1803e0 	mov	x0, x24
    6ed0:	97fffec4 	bl	69e0 <fwp_drop10>
    6ed4:	a900d3f6 	stp	x22, x20, [sp, #8]
    6ed8:	910023e1 	add	x1, sp, #0x8
    6edc:	52800000 	mov	w0, #0x0                   	// #0
    6ee0:	97fff7a9 	bl	4d84 <fwp_data.part.0.constprop.0>
    6ee4:	f949daa1 	ldr	x1, [x21, #5040]
    6ee8:	aa0003f3 	mov	x19, x0
    6eec:	f949eea0 	ldr	x0, [x21, #5080]
    6ef0:	cb010261 	sub	x1, x19, x1
    6ef4:	eb00403f 	cmp	x1, x0, lsl #16
    6ef8:	54000322 	b.cs	6f5c <f37+0x2dc>  // b.hs, b.nlast
    6efc:	d350fc22 	lsr	x2, x1, #16
    6f00:	f949fea3 	ldr	x3, [x21, #5112]
    6f04:	8b020842 	add	x2, x2, x2, lsl #2
    6f08:	d37df042 	lsl	x2, x2, #3
    6f0c:	8b020060 	add	x0, x3, x2
    6f10:	f9401014 	ldr	x20, [x0, #32]
    6f14:	b4000254 	cbz	x20, 6f5c <f37+0x2dc>
    6f18:	38626862 	ldrb	w2, [x3, x2]
    6f1c:	7100085f 	cmp	w2, #0x2
    6f20:	540004a0 	b.eq	6fb4 <f37+0x334>  // b.none
    6f24:	7100045f 	cmp	w2, #0x1
    6f28:	540001a1 	b.ne	6f5c <f37+0x2dc>  // b.any
    6f2c:	29430002 	ldp	w2, w0, [x0, #24]
    6f30:	92403c21 	and	x1, x1, #0xffff
    6f34:	9b027c21 	mul	x1, x1, x2
    6f38:	d360fc21 	lsr	x1, x1, #32
    6f3c:	eb00003f 	cmp	x1, x0
    6f40:	540000e2 	b.cs	6f5c <f37+0x2dc>  // b.hs, b.nlast
    6f44:	8b010294 	add	x20, x20, x1
    6f48:	39400280 	ldrb	w0, [x20]
    6f4c:	7103fc1f 	cmp	w0, #0xff
    6f50:	540007a0 	b.eq	7044 <f37+0x3c4>  // b.none
    6f54:	52800020 	mov	w0, #0x1                   	// #1
    6f58:	39000280 	strb	w0, [x20]
    6f5c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f60:	f947f400 	ldr	x0, [x0, #4072]
    6f64:	f9400fe2 	ldr	x2, [sp, #24]
    6f68:	f9400001 	ldr	x1, [x0]
    6f6c:	eb010042 	subs	x2, x2, x1
    6f70:	d2800001 	mov	x1, #0x0                   	// #0
    6f74:	54000721 	b.ne	7058 <f37+0x3d8>  // b.any
    6f78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6f7c:	aa1303e0 	mov	x0, x19
    6f80:	a94353f3 	ldp	x19, x20, [sp, #48]
    6f84:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6f88:	a94563f7 	ldp	x23, x24, [sp, #80]
    6f8c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6f90:	910203ff 	add	sp, sp, #0x80
    6f94:	d65f03c0 	ret
    6f98:	f0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    6f9c:	9124a000 	add	x0, x0, #0x928
    6fa0:	fd003be8 	str	d8, [sp, #112]
    6fa4:	97fff3bb 	bl	3e90 <fwp_trap>
    6fa8:	72003c3f 	tst	w1, #0xffff
    6fac:	54ffec81 	b.ne	6d3c <f37+0xbc>  // b.any
    6fb0:	17ffff5d 	b	6d24 <f37+0xa4>
    6fb4:	72003c3f 	tst	w1, #0xffff
    6fb8:	54fffd21 	b.ne	6f5c <f37+0x2dc>  // b.any
    6fbc:	17ffffe3 	b	6f48 <f37+0x2c8>
    6fc0:	72003c3f 	tst	w1, #0xffff
    6fc4:	54fff301 	b.ne	6e24 <f37+0x1a4>  // b.any
    6fc8:	17ffff92 	b	6e10 <f37+0x190>
    6fcc:	cb0103e1 	neg	x1, x1
    6fd0:	eb02003f 	cmp	x1, x2
    6fd4:	540001e3 	b.cc	7010 <f37+0x390>  // b.lo, b.ul, b.last
    6fd8:	52800041 	mov	w1, #0x2                   	// #2
    6fdc:	d2800100 	mov	x0, #0x8                   	// #8
    6fe0:	97fff724 	bl	4c70 <fwp_heap_alloc>
    6fe4:	aa0003f8 	mov	x24, x0
    6fe8:	9114c2a0 	add	x0, x21, #0x530
    6fec:	f900031f 	str	xzr, [x24]
    6ff0:	f949d801 	ldr	x1, [x0, #5040]
    6ff4:	f949ec00 	ldr	x0, [x0, #5080]
    6ff8:	cb010301 	sub	x1, x24, x1
    6ffc:	eb00403f 	cmp	x1, x0, lsl #16
    7000:	54000282 	b.cs	7050 <f37+0x3d0>  // b.hs, b.nlast
    7004:	d2800013 	mov	x19, #0x0                   	// #0
    7008:	d2800017 	mov	x23, #0x0                   	// #0
    700c:	17ffff6d 	b	6dc0 <f37+0x140>
    7010:	f949fc62 	ldr	x2, [x3, #5112]
    7014:	d350fc20 	lsr	x0, x1, #16
    7018:	8b000800 	add	x0, x0, x0, lsl #2
    701c:	8b000c42 	add	x2, x2, x0, lsl #3
    7020:	f9401040 	ldr	x0, [x2, #32]
    7024:	b4fffda0 	cbz	x0, 6fd8 <f37+0x358>
    7028:	d2800017 	mov	x23, #0x0                   	// #0
    702c:	17ffff32 	b	6cf4 <f37+0x74>
    7030:	97fff4cd 	bl	4364 <fwp_rc_wide_dup>
    7034:	17ffff42 	b	6d3c <f37+0xbc>
    7038:	aa1403e0 	mov	x0, x20
    703c:	97fff3b5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    7040:	17ffff77 	b	6e1c <f37+0x19c>
    7044:	aa1403e0 	mov	x0, x20
    7048:	97fff3b2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    704c:	17ffffc2 	b	6f54 <f37+0x2d4>
    7050:	d2800017 	mov	x23, #0x0                   	// #0
    7054:	17ffff86 	b	6e6c <f37+0x1ec>
    7058:	fd003be8 	str	d8, [sp, #112]
    705c:	97ffee09 	bl	2880 <__stack_chk_fail@plt>

0000000000007060 <fwp_owned_entry37>:
    7060:	f9400000 	ldr	x0, [x0]
    7064:	17ffff07 	b	6c80 <f37>
    7068:	d503201f 	nop
    706c:	d503201f 	nop

0000000000007070 <e37>:
    7070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7074:	910003fd 	mov	x29, sp
    7078:	f9000bf3 	str	x19, [sp, #16]
    707c:	f9400013 	ldr	x19, [x0]
    7080:	aa1303e0 	mov	x0, x19
    7084:	97fff9b0 	bl	5744 <fwp_rc_share>
    7088:	aa1303e0 	mov	x0, x19
    708c:	97fffefd 	bl	6c80 <f37>
    7090:	aa0003f3 	mov	x19, x0
    7094:	97fff9ac 	bl	5744 <fwp_rc_share>
    7098:	aa1303e0 	mov	x0, x19
    709c:	f9400bf3 	ldr	x19, [sp, #16]
    70a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70a4:	d65f03c0 	ret
    70a8:	d503201f 	nop
    70ac:	d503201f 	nop

00000000000070b0 <fwp_args37>:
    70b0:	7100003f 	cmp	w1, #0x0
    70b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70b8:	54000041 	b.ne	70c0 <fwp_args37+0x10>  // b.any
    70bc:	d65f03c0 	ret
    70c0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    70c4:	9114c042 	add	x2, x2, #0x530
    70c8:	f9400001 	ldr	x1, [x0]
    70cc:	f949d843 	ldr	x3, [x2, #5040]
    70d0:	f949ec40 	ldr	x0, [x2, #5080]
    70d4:	cb030021 	sub	x1, x1, x3
    70d8:	eb00403f 	cmp	x1, x0, lsl #16
    70dc:	54ffff02 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    70e0:	d350fc20 	lsr	x0, x1, #16
    70e4:	f949fc44 	ldr	x4, [x2, #5112]
    70e8:	8b000800 	add	x0, x0, x0, lsl #2
    70ec:	d37df002 	lsl	x2, x0, #3
    70f0:	8b020083 	add	x3, x4, x2
    70f4:	f9401060 	ldr	x0, [x3, #32]
    70f8:	b4fffe20 	cbz	x0, 70bc <fwp_args37+0xc>
    70fc:	38626882 	ldrb	w2, [x4, x2]
    7100:	7100085f 	cmp	w2, #0x2
    7104:	54000220 	b.eq	7148 <fwp_args37+0x98>  // b.none
    7108:	7100045f 	cmp	w2, #0x1
    710c:	54fffd81 	b.ne	70bc <fwp_args37+0xc>  // b.any
    7110:	29430864 	ldp	w4, w2, [x3, #24]
    7114:	92403c21 	and	x1, x1, #0xffff
    7118:	9b047c21 	mul	x1, x1, x4
    711c:	d360fc21 	lsr	x1, x1, #32
    7120:	eb02003f 	cmp	x1, x2
    7124:	54fffcc2 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    7128:	8b010000 	add	x0, x0, x1
    712c:	39400001 	ldrb	w1, [x0]
    7130:	34fffc61 	cbz	w1, 70bc <fwp_args37+0xc>
    7134:	7103f43f 	cmp	w1, #0xfd
    7138:	540000e8 	b.hi	7154 <fwp_args37+0xa4>  // b.pmore
    713c:	11000421 	add	w1, w1, #0x1
    7140:	39000001 	strb	w1, [x0]
    7144:	d65f03c0 	ret
    7148:	72003c3f 	tst	w1, #0xffff
    714c:	54ffff00 	b.eq	712c <fwp_args37+0x7c>  // b.none
    7150:	d65f03c0 	ret
    7154:	17fff484 	b	4364 <fwp_rc_wide_dup>
    7158:	d503201f 	nop
    715c:	d503201f 	nop

0000000000007160 <fwp_caps37>:
    7160:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7164:	910003fd 	mov	x29, sp
    7168:	f9000bf3 	str	x19, [sp, #16]
    716c:	aa0003f3 	mov	x19, x0
    7170:	b9400400 	ldr	w0, [x0, #4]
    7174:	340004a0 	cbz	w0, 7208 <fwp_caps37+0xa8>
    7178:	f9400660 	ldr	x0, [x19, #8]
    717c:	350004e1 	cbnz	w1, 7218 <fwp_caps37+0xb8>
    7180:	97fffc5c 	bl	62f0 <fwp_drop4>
    7184:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    7188:	9114c042 	add	x2, x2, #0x530
    718c:	f949d840 	ldr	x0, [x2, #5040]
    7190:	f949ec41 	ldr	x1, [x2, #5080]
    7194:	cb000260 	sub	x0, x19, x0
    7198:	eb01401f 	cmp	x0, x1, lsl #16
    719c:	54000382 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    71a0:	d350fc01 	lsr	x1, x0, #16
    71a4:	f949fc44 	ldr	x4, [x2, #5112]
    71a8:	8b010821 	add	x1, x1, x1, lsl #2
    71ac:	d37df021 	lsl	x1, x1, #3
    71b0:	8b010083 	add	x3, x4, x1
    71b4:	f9401062 	ldr	x2, [x3, #32]
    71b8:	b40002a2 	cbz	x2, 720c <fwp_caps37+0xac>
    71bc:	38616881 	ldrb	w1, [x4, x1]
    71c0:	7100083f 	cmp	w1, #0x2
    71c4:	540006c0 	b.eq	729c <fwp_caps37+0x13c>  // b.none
    71c8:	7100043f 	cmp	w1, #0x1
    71cc:	54000201 	b.ne	720c <fwp_caps37+0xac>  // b.any
    71d0:	29430464 	ldp	w4, w1, [x3, #24]
    71d4:	92403c00 	and	x0, x0, #0xffff
    71d8:	9b047c00 	mul	x0, x0, x4
    71dc:	d360fc00 	lsr	x0, x0, #32
    71e0:	eb01001f 	cmp	x0, x1
    71e4:	54000142 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    71e8:	8b000042 	add	x2, x2, x0
    71ec:	39400040 	ldrb	w0, [x2]
    71f0:	7100041f 	cmp	w0, #0x1
    71f4:	540000c1 	b.ne	720c <fwp_caps37+0xac>  // b.any
    71f8:	aa1303e0 	mov	x0, x19
    71fc:	f9400bf3 	ldr	x19, [sp, #16]
    7200:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7204:	17fff3df 	b	4180 <fwp_mem_free>
    7208:	34fffbe1 	cbz	w1, 7184 <fwp_caps37+0x24>
    720c:	f9400bf3 	ldr	x19, [sp, #16]
    7210:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7214:	d65f03c0 	ret
    7218:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    721c:	9114c042 	add	x2, x2, #0x530
    7220:	f949d843 	ldr	x3, [x2, #5040]
    7224:	f949ec41 	ldr	x1, [x2, #5080]
    7228:	cb030000 	sub	x0, x0, x3
    722c:	eb01401f 	cmp	x0, x1, lsl #16
    7230:	54fffee2 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    7234:	d350fc01 	lsr	x1, x0, #16
    7238:	f949fc44 	ldr	x4, [x2, #5112]
    723c:	8b010821 	add	x1, x1, x1, lsl #2
    7240:	d37df021 	lsl	x1, x1, #3
    7244:	8b010083 	add	x3, x4, x1
    7248:	f9401062 	ldr	x2, [x3, #32]
    724c:	b4fffe02 	cbz	x2, 720c <fwp_caps37+0xac>
    7250:	38616881 	ldrb	w1, [x4, x1]
    7254:	7100083f 	cmp	w1, #0x2
    7258:	54000280 	b.eq	72a8 <fwp_caps37+0x148>  // b.none
    725c:	7100043f 	cmp	w1, #0x1
    7260:	54fffd61 	b.ne	720c <fwp_caps37+0xac>  // b.any
    7264:	92403c01 	and	x1, x0, #0xffff
    7268:	29430064 	ldp	w4, w0, [x3, #24]
    726c:	9b047c21 	mul	x1, x1, x4
    7270:	d360fc21 	lsr	x1, x1, #32
    7274:	eb00003f 	cmp	x1, x0
    7278:	54fffca2 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    727c:	8b010042 	add	x2, x2, x1
    7280:	39400040 	ldrb	w0, [x2]
    7284:	34fffc40 	cbz	w0, 720c <fwp_caps37+0xac>
    7288:	7103f41f 	cmp	w0, #0xfd
    728c:	54000148 	b.hi	72b4 <fwp_caps37+0x154>  // b.pmore
    7290:	11000400 	add	w0, w0, #0x1
    7294:	39000040 	strb	w0, [x2]
    7298:	17ffffdd 	b	720c <fwp_caps37+0xac>
    729c:	72003c1f 	tst	w0, #0xffff
    72a0:	54fffb61 	b.ne	720c <fwp_caps37+0xac>  // b.any
    72a4:	17ffffd2 	b	71ec <fwp_caps37+0x8c>
    72a8:	72003c1f 	tst	w0, #0xffff
    72ac:	54fffb01 	b.ne	720c <fwp_caps37+0xac>  // b.any
    72b0:	17fffff4 	b	7280 <fwp_caps37+0x120>
    72b4:	f9400bf3 	ldr	x19, [sp, #16]
    72b8:	aa0203e0 	mov	x0, x2
    72bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72c0:	17fff429 	b	4364 <fwp_rc_wide_dup>

00000000000072c4 <fwp_write>:
    72c4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    72c8:	910003fd 	mov	x29, sp
    72cc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    72d0:	f947f484 	ldr	x4, [x4, #4072]
    72d4:	a90153f3 	stp	x19, x20, [sp, #16]
    72d8:	d10943ff 	sub	sp, sp, #0x250
    72dc:	b9400045 	ldr	w5, [x2]
    72e0:	aa0003f4 	mov	x20, x0
    72e4:	f9400080 	ldr	x0, [x4]
    72e8:	f90127e0 	str	x0, [sp, #584]
    72ec:	d2800000 	mov	x0, #0x0                   	// #0
    72f0:	710064bf 	cmp	w5, #0x19
    72f4:	54000408 	b.hi	7374 <fwp_write+0xb0>  // b.pmore
    72f8:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0xac0>
    72fc:	aa0103f3 	mov	x19, x1
    7300:	91034000 	add	x0, x0, #0xd0
    7304:	f9013bf5 	str	x21, [sp, #624]
    7308:	f9013ff6 	str	x22, [sp, #632]
    730c:	f90153fb 	str	x27, [sp, #672]
    7310:	f90157fc 	str	x28, [sp, #680]
    7314:	aa0203fc 	mov	x28, x2
    7318:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    731c:	10000061 	adr	x1, 7328 <fwp_write+0x64>
    7320:	8b20a820 	add	x0, x1, w0, sxth #2
    7324:	d61f0000 	br	x0
    7328:	910123e0 	add	x0, sp, #0x48
    732c:	aa1303e5 	mov	x5, x19
    7330:	d0000004 	adrp	x4, 9000 <__divti3+0x1e0>
    7334:	aa0003f3 	mov	x19, x0
    7338:	9125c084 	add	x4, x4, #0x970
    733c:	d2804003 	mov	x3, #0x200                 	// #512
    7340:	aa0303e1 	mov	x1, x3
    7344:	52800042 	mov	w2, #0x2                   	// #2
    7348:	97ffed2a 	bl	27f0 <__snprintf_chk@plt>
    734c:	aa1303e0 	mov	x0, x19
    7350:	97ffecf0 	bl	2710 <strlen@plt>
    7354:	aa1303e1 	mov	x1, x19
    7358:	aa0003e2 	mov	x2, x0
    735c:	aa1403e0 	mov	x0, x20
    7360:	97fff02c 	bl	3410 <buf_put>
    7364:	f9413bf5 	ldr	x21, [sp, #624]
    7368:	f9413ff6 	ldr	x22, [sp, #632]
    736c:	f94153fb 	ldr	x27, [sp, #672]
    7370:	f94157fc 	ldr	x28, [sp, #680]
    7374:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7378:	f947f400 	ldr	x0, [x0, #4072]
    737c:	f94127e2 	ldr	x2, [sp, #584]
    7380:	f9400001 	ldr	x1, [x0]
    7384:	eb010042 	subs	x2, x2, x1
    7388:	d2800001 	mov	x1, #0x0                   	// #0
    738c:	540077a1 	b.ne	8280 <fwp_write+0xfbc>  // b.any
    7390:	910943ff 	add	sp, sp, #0x250
    7394:	a94153f3 	ldp	x19, x20, [sp, #16]
    7398:	a8c77bfd 	ldp	x29, x30, [sp], #112
    739c:	d65f03c0 	ret
    73a0:	910123e0 	add	x0, sp, #0x48
    73a4:	aa1303e5 	mov	x5, x19
    73a8:	d0000004 	adrp	x4, 9000 <__divti3+0x1e0>
    73ac:	aa0003f3 	mov	x19, x0
    73b0:	9125a084 	add	x4, x4, #0x968
    73b4:	d2804003 	mov	x3, #0x200                 	// #512
    73b8:	17ffffe2 	b	7340 <fwp_write+0x7c>
    73bc:	71004cbf 	cmp	w5, #0x13
    73c0:	d0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    73c4:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    73c8:	91256000 	add	x0, x0, #0x958
    73cc:	91258021 	add	x1, x1, #0x960
    73d0:	d2800082 	mov	x2, #0x4                   	// #4
    73d4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    73d8:	aa1403e0 	mov	x0, x20
    73dc:	f90143f7 	str	x23, [sp, #640]
    73e0:	d2800016 	mov	x22, #0x0                   	// #0
    73e4:	f90147f8 	str	x24, [sp, #648]
    73e8:	97fff00a 	bl	3410 <buf_put>
    73ec:	f9400260 	ldr	x0, [x19]
    73f0:	d0000017 	adrp	x23, 9000 <__divti3+0x1e0>
    73f4:	d2800015 	mov	x21, #0x0                   	// #0
    73f8:	912782f7 	add	x23, x23, #0x9e0
    73fc:	b4004780 	cbz	x0, 7cec <fwp_write+0xa28>
    7400:	b9400380 	ldr	w0, [x28]
    7404:	52800003 	mov	w3, #0x0                   	// #0
    7408:	f9401f82 	ldr	x2, [x28, #56]
    740c:	71004c1f 	cmp	w0, #0x13
    7410:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7414:	aa1403e0 	mov	x0, x20
    7418:	8b010e61 	add	x1, x19, x1, lsl #3
    741c:	f9400421 	ldr	x1, [x1, #8]
    7420:	97ffffa9 	bl	72c4 <fwp_write>
    7424:	b9400380 	ldr	w0, [x28]
    7428:	7100481f 	cmp	w0, #0x12
    742c:	54004b20 	b.eq	7d90 <fwp_write+0xacc>  // b.none
    7430:	f9400260 	ldr	x0, [x19]
    7434:	910006b5 	add	x21, x21, #0x1
    7438:	91000ad6 	add	x22, x22, #0x2
    743c:	eb15001f 	cmp	x0, x21
    7440:	54004569 	b.ls	7cec <fwp_write+0xa28>  // b.plast
    7444:	aa1703e1 	mov	x1, x23
    7448:	aa1403e0 	mov	x0, x20
    744c:	d2800042 	mov	x2, #0x2                   	// #2
    7450:	97ffeff0 	bl	3410 <buf_put>
    7454:	17ffffeb 	b	7400 <fwp_write+0x13c>
    7458:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    745c:	91266021 	add	x1, x1, #0x998
    7460:	d28000c2 	mov	x2, #0x6                   	// #6
    7464:	aa1403e0 	mov	x0, x20
    7468:	91004273 	add	x19, x19, #0x10
    746c:	97ffefe9 	bl	3410 <buf_put>
    7470:	aa1303e0 	mov	x0, x19
    7474:	97ffeca7 	bl	2710 <strlen@plt>
    7478:	aa1303e1 	mov	x1, x19
    747c:	aa0003e2 	mov	x2, x0
    7480:	aa1403e0 	mov	x0, x20
    7484:	97ffefe3 	bl	3410 <buf_put>
    7488:	528007c3 	mov	w3, #0x3e                  	// #62
    748c:	aa1403e0 	mov	x0, x20
    7490:	91001fe1 	add	x1, sp, #0x7
    7494:	d2800022 	mov	x2, #0x1                   	// #1
    7498:	39001fe3 	strb	w3, [sp, #7]
    749c:	17ffffb1 	b	7360 <fwp_write+0x9c>
    74a0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    74a4:	f947f400 	ldr	x0, [x0, #4072]
    74a8:	f94127e2 	ldr	x2, [sp, #584]
    74ac:	f9400001 	ldr	x1, [x0]
    74b0:	eb010042 	subs	x2, x2, x1
    74b4:	d2800001 	mov	x1, #0x0                   	// #0
    74b8:	540034c1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    74bc:	f9413bf5 	ldr	x21, [sp, #624]
    74c0:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    74c4:	f9413ff6 	ldr	x22, [sp, #632]
    74c8:	aa1403e0 	mov	x0, x20
    74cc:	9125e021 	add	x1, x1, #0x978
    74d0:	d2800142 	mov	x2, #0xa                   	// #10
    74d4:	f94153fb 	ldr	x27, [sp, #672]
    74d8:	f94157fc 	ldr	x28, [sp, #680]
    74dc:	910943ff 	add	sp, sp, #0x250
    74e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    74e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74e8:	17ffefca 	b	3410 <buf_put>
    74ec:	f9400456 	ldr	x22, [x2, #8]
    74f0:	f90143f7 	str	x23, [sp, #640]
    74f4:	f90147f8 	str	x24, [sp, #648]
    74f8:	b4005af6 	cbz	x22, 8054 <fwp_write+0xd90>
    74fc:	aa1603e0 	mov	x0, x22
    7500:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7504:	9127e021 	add	x1, x1, #0x9f8
    7508:	97ffecfe 	bl	2900 <strcmp@plt>
    750c:	2a0003f5 	mov	w21, w0
    7510:	34005fc0 	cbz	w0, 8108 <fwp_write+0xe44>
    7514:	aa1603e0 	mov	x0, x22
    7518:	97ffec7e 	bl	2710 <strlen@plt>
    751c:	aa1603e1 	mov	x1, x22
    7520:	aa0003e2 	mov	x2, x0
    7524:	aa1403e0 	mov	x0, x20
    7528:	97ffefba 	bl	3410 <buf_put>
    752c:	52800403 	mov	w3, #0x20                  	// #32
    7530:	91001ff5 	add	x21, sp, #0x7
    7534:	aa1503e1 	mov	x1, x21
    7538:	aa1403e0 	mov	x0, x20
    753c:	d2800022 	mov	x2, #0x1                   	// #1
    7540:	39001fe3 	strb	w3, [sp, #7]
    7544:	97ffefb3 	bl	3410 <buf_put>
    7548:	52800f63 	mov	w3, #0x7b                  	// #123
    754c:	aa1403e0 	mov	x0, x20
    7550:	aa1503e1 	mov	x1, x21
    7554:	d2800022 	mov	x2, #0x1                   	// #1
    7558:	39001fe3 	strb	w3, [sp, #7]
    755c:	97ffefad 	bl	3410 <buf_put>
    7560:	b9401380 	ldr	w0, [x28, #16]
    7564:	52800018 	mov	w24, #0x0                   	// #0
    7568:	7100001f 	cmp	w0, #0x0
    756c:	54003a8d 	b.le	7cbc <fwp_write+0x9f8>
    7570:	f9014bf9 	str	x25, [sp, #656]
    7574:	d0000019 	adrp	x25, 9000 <__divti3+0x1e0>
    7578:	91288339 	add	x25, x25, #0xa20
    757c:	f9014ffa 	str	x26, [sp, #664]
    7580:	d000001a 	adrp	x26, 9000 <__divti3+0x1e0>
    7584:	9127835a 	add	x26, x26, #0x9e0
    7588:	91002276 	add	x22, x19, #0x8
    758c:	d2800013 	mov	x19, #0x0                   	// #0
    7590:	b5003e73 	cbnz	x19, 7d5c <fwp_write+0xa98>
    7594:	d37df277 	lsl	x23, x19, #3
    7598:	34003c98 	cbz	w24, 7d28 <fwp_write+0xa64>
    759c:	f9401382 	ldr	x2, [x28, #32]
    75a0:	aa1403e0 	mov	x0, x20
    75a4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    75a8:	52800003 	mov	w3, #0x0                   	// #0
    75ac:	f8776842 	ldr	x2, [x2, x23]
    75b0:	91000673 	add	x19, x19, #0x1
    75b4:	97ffff44 	bl	72c4 <fwp_write>
    75b8:	b9401380 	ldr	w0, [x28, #16]
    75bc:	6b13001f 	cmp	w0, w19
    75c0:	54fffe8c 	b.gt	7590 <fwp_write+0x2cc>
    75c4:	f9414bf9 	ldr	x25, [sp, #656]
    75c8:	f9414ffa 	ldr	x26, [sp, #664]
    75cc:	34003798 	cbz	w24, 7cbc <fwp_write+0x9f8>
    75d0:	52800523 	mov	w3, #0x29                  	// #41
    75d4:	aa1503e1 	mov	x1, x21
    75d8:	aa1403e0 	mov	x0, x20
    75dc:	d2800022 	mov	x2, #0x1                   	// #1
    75e0:	39001fe3 	strb	w3, [sp, #7]
    75e4:	97ffef8b 	bl	3410 <buf_put>
    75e8:	f9413bf5 	ldr	x21, [sp, #624]
    75ec:	f9413ff6 	ldr	x22, [sp, #632]
    75f0:	f94143f7 	ldr	x23, [sp, #640]
    75f4:	f94147f8 	ldr	x24, [sp, #648]
    75f8:	f94153fb 	ldr	x27, [sp, #672]
    75fc:	f94157fc 	ldr	x28, [sp, #680]
    7600:	17ffff5d 	b	7374 <fwp_write+0xb0>
    7604:	b9404855 	ldr	w21, [x2, #72]
    7608:	aa1403e0 	mov	x0, x20
    760c:	93407eb6 	sxtw	x22, w21
    7610:	91000ac1 	add	x1, x22, #0x2
    7614:	97ffef4c 	bl	3344 <buf_grow>
    7618:	a9400281 	ldp	x1, x0, [x20]
    761c:	528e8603 	mov	w3, #0x7430                	// #29744
    7620:	78206823 	strh	w3, [x1, x0]
    7624:	8b000022 	add	x2, x1, x0
    7628:	710002bf 	cmp	w21, #0x0
    762c:	540036ad 	b.le	7d00 <fwp_write+0xa3c>
    7630:	110006a3 	add	w3, w21, #0x1
    7634:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7638:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    763c:	91000449 	add	x9, x2, #0x1
    7640:	8b23c043 	add	x3, x2, w3, sxtw
    7644:	f28aaac6 	movk	x6, #0x5556
    7648:	f2955568 	movk	x8, #0xaaab
    764c:	1400000d 	b	7680 <fwp_write+0x3bc>
    7650:	d2800021 	mov	x1, #0x1                   	// #1
    7654:	528005a5 	mov	w5, #0x2d                  	// #45
    7658:	f100001f 	cmp	x0, #0x0
    765c:	9b467e60 	smulh	x0, x19, x6
    7660:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7664:	381ff465 	strb	w5, [x3], #-1
    7668:	cb040000 	sub	x0, x0, x4
    766c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7670:	cb020000 	sub	x0, x0, x2
    7674:	8b010013 	add	x19, x0, x1
    7678:	eb03013f 	cmp	x9, x3
    767c:	54003420 	b.eq	7d00 <fwp_write+0xa3c>  // b.none
    7680:	9b467e60 	smulh	x0, x19, x6
    7684:	937ffe64 	asr	x4, x19, #63
    7688:	52800605 	mov	w5, #0x30                  	// #48
    768c:	cb040000 	sub	x0, x0, x4
    7690:	8b000400 	add	x0, x0, x0, lsl #1
    7694:	cb000260 	sub	x0, x19, x0
    7698:	91000c01 	add	x1, x0, #0x3
    769c:	9bc87c22 	umulh	x2, x1, x8
    76a0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    76a4:	8b4204e2 	add	x2, x7, x2, lsr #1
    76a8:	eb020021 	subs	x1, x1, x2
    76ac:	54fffd60 	b.eq	7658 <fwp_write+0x394>  // b.none
    76b0:	f100043f 	cmp	x1, #0x1
    76b4:	54fffce1 	b.ne	7650 <fwp_write+0x38c>  // b.any
    76b8:	d2800001 	mov	x1, #0x0                   	// #0
    76bc:	52800565 	mov	w5, #0x2b                  	// #43
    76c0:	17ffffe6 	b	7658 <fwp_write+0x394>
    76c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76c8:	f947f400 	ldr	x0, [x0, #4072]
    76cc:	f94127e2 	ldr	x2, [sp, #584]
    76d0:	f9400001 	ldr	x1, [x0]
    76d4:	eb010042 	subs	x2, x2, x1
    76d8:	d2800001 	mov	x1, #0x0                   	// #0
    76dc:	540023a1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    76e0:	f9413bf5 	ldr	x21, [sp, #624]
    76e4:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    76e8:	f9413ff6 	ldr	x22, [sp, #632]
    76ec:	aa1403e0 	mov	x0, x20
    76f0:	91262021 	add	x1, x1, #0x988
    76f4:	d2800102 	mov	x2, #0x8                   	// #8
    76f8:	17ffff77 	b	74d4 <fwp_write+0x210>
    76fc:	aa1403e0 	mov	x0, x20
    7700:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7704:	d28000c2 	mov	x2, #0x6                   	// #6
    7708:	9127a021 	add	x1, x1, #0x9e8
    770c:	97ffef41 	bl	3410 <buf_put>
    7710:	d2800015 	mov	x21, #0x0                   	// #0
    7714:	f9400263 	ldr	x3, [x19]
    7718:	f240f87f 	tst	x3, #0x7fffffffffffffff
    771c:	54002c40 	b.eq	7ca4 <fwp_write+0x9e0>  // b.none
    7720:	f9401f82 	ldr	x2, [x28, #56]
    7724:	f90143f7 	str	x23, [sp, #640]
    7728:	f90147f8 	str	x24, [sp, #648]
    772c:	d2800857 	mov	x23, #0x42                  	// #66
    7730:	f9014bf9 	str	x25, [sp, #656]
    7734:	d0000016 	adrp	x22, 9000 <__divti3+0x1e0>
    7738:	f9014ffa 	str	x26, [sp, #664]
    773c:	912782d6 	add	x22, x22, #0x9e0
    7740:	d2800038 	mov	x24, #0x1                   	// #1
    7744:	f2a18017 	movk	x23, #0xc00, lsl #16
    7748:	d2809099 	mov	x25, #0x484                 	// #1156
    774c:	b4000482 	cbz	x2, 77dc <fwp_write+0x518>
    7750:	b9400040 	ldr	w0, [x2]
    7754:	7100701f 	cmp	w0, #0x1c
    7758:	540042a0 	b.eq	7fac <fwp_write+0xce8>  // b.none
    775c:	71006c1f 	cmp	w0, #0x1b
    7760:	540003e8 	b.hi	77dc <fwp_write+0x518>  // b.pmore
    7764:	9ac02301 	lsl	x1, x24, x0
    7768:	ea17003f 	tst	x1, x23
    776c:	54003681 	b.ne	7e3c <fwp_write+0xb78>  // b.any
    7770:	ea19003f 	tst	x1, x25
    7774:	54003501 	b.ne	7e14 <fwp_write+0xb50>  // b.any
    7778:	d2800424 	mov	x4, #0x21                  	// #33
    777c:	ea04003f 	tst	x1, x4
    7780:	540002e0 	b.eq	77dc <fwp_write+0x518>  // b.none
    7784:	b7f849a3 	tbnz	x3, #63, 80b8 <fwp_write+0xdf4>
    7788:	91002261 	add	x1, x19, #0x8
    778c:	8b150021 	add	x1, x1, x21
    7790:	39400021 	ldrb	w1, [x1]
    7794:	7100001f 	cmp	w0, #0x0
    7798:	93401c23 	sxtb	x3, w1
    779c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    77a0:	aa1403e0 	mov	x0, x20
    77a4:	52800003 	mov	w3, #0x0                   	// #0
    77a8:	97fffec7 	bl	72c4 <fwp_write>
    77ac:	910006b5 	add	x21, x21, #0x1
    77b0:	f9400260 	ldr	x0, [x19]
    77b4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    77b8:	eb0002bf 	cmp	x21, x0
    77bc:	540026c2 	b.cs	7c94 <fwp_write+0x9d0>  // b.hs, b.nlast
    77c0:	d2800042 	mov	x2, #0x2                   	// #2
    77c4:	aa1603e1 	mov	x1, x22
    77c8:	aa1403e0 	mov	x0, x20
    77cc:	97ffef11 	bl	3410 <buf_put>
    77d0:	f9401f82 	ldr	x2, [x28, #56]
    77d4:	f9400263 	ldr	x3, [x19]
    77d8:	b5fffbc2 	cbnz	x2, 7750 <fwp_write+0x48c>
    77dc:	d37df2a0 	lsl	x0, x21, #3
    77e0:	b7f83f03 	tbnz	x3, #63, 7fc0 <fwp_write+0xcfc>
    77e4:	91002261 	add	x1, x19, #0x8
    77e8:	8b000020 	add	x0, x1, x0
    77ec:	f9400001 	ldr	x1, [x0]
    77f0:	17ffffec 	b	77a0 <fwp_write+0x4dc>
    77f4:	a9400e62 	ldp	x2, x3, [x19]
    77f8:	b7f83ca3 	tbnz	x3, #63, 7f8c <fwp_write+0xcc8>
    77fc:	910123f5 	add	x21, sp, #0x48
    7800:	aa1503e0 	mov	x0, x21
    7804:	97ffed87 	bl	2e20 <fwp_fmt_u128>
    7808:	aa1503e0 	mov	x0, x21
    780c:	97ffebc1 	bl	2710 <strlen@plt>
    7810:	aa1503e1 	mov	x1, x21
    7814:	aa0003e2 	mov	x2, x0
    7818:	17fffed1 	b	735c <fwp_write+0x98>
    781c:	fd015be8 	str	d8, [sp, #688]
    7820:	1e270268 	fmov	s8, w19
    7824:	fd015fe9 	str	d9, [sp, #696]
    7828:	1e282100 	fcmp	s8, s8
    782c:	54004d26 	b.vs	81d0 <fwp_write+0xf0c>
    7830:	1e20c101 	fabs	s1, s8
    7834:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7838:	1e270000 	fmov	s0, w0
    783c:	1e202020 	fcmp	s1, s0
    7840:	54002c0d 	b.le	7dc0 <fwp_write+0xafc>
    7844:	1e202118 	fcmpe	s8, #0.0
    7848:	d0000002 	adrp	x2, 9000 <__divti3+0x1e0>
    784c:	91158042 	add	x2, x2, #0x560
    7850:	910123f5 	add	x21, sp, #0x48
    7854:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7858:	9124e021 	add	x1, x1, #0x938
    785c:	aa1503e0 	mov	x0, x21
    7860:	9a81c041 	csel	x1, x2, x1, gt
    7864:	97ffec57 	bl	29c0 <strcpy@plt>
    7868:	aa1503e0 	mov	x0, x21
    786c:	97ffeba9 	bl	2710 <strlen@plt>
    7870:	aa1503e1 	mov	x1, x21
    7874:	aa0003e2 	mov	x2, x0
    7878:	aa1403e0 	mov	x0, x20
    787c:	97ffeee5 	bl	3410 <buf_put>
    7880:	f9413bf5 	ldr	x21, [sp, #624]
    7884:	f9413ff6 	ldr	x22, [sp, #632]
    7888:	f94153fb 	ldr	x27, [sp, #672]
    788c:	f94157fc 	ldr	x28, [sp, #680]
    7890:	fd415be8 	ldr	d8, [sp, #688]
    7894:	fd415fe9 	ldr	d9, [sp, #696]
    7898:	17fffeb7 	b	7374 <fwp_write+0xb0>
    789c:	f9400276 	ldr	x22, [x19]
    78a0:	34002e03 	cbz	w3, 7e60 <fwp_write+0xb9c>
    78a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    78a8:	f947f400 	ldr	x0, [x0, #4072]
    78ac:	f94127e2 	ldr	x2, [sp, #584]
    78b0:	f9400001 	ldr	x1, [x0]
    78b4:	eb010042 	subs	x2, x2, x1
    78b8:	d2800001 	mov	x1, #0x0                   	// #0
    78bc:	540014a1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    78c0:	aa1603e2 	mov	x2, x22
    78c4:	91002261 	add	x1, x19, #0x8
    78c8:	f9413bf5 	ldr	x21, [sp, #624]
    78cc:	aa1403e0 	mov	x0, x20
    78d0:	f9413ff6 	ldr	x22, [sp, #632]
    78d4:	17ffff00 	b	74d4 <fwp_write+0x210>
    78d8:	fd015be8 	str	d8, [sp, #688]
    78dc:	9e670268 	fmov	d8, x19
    78e0:	fd015fe9 	str	d9, [sp, #696]
    78e4:	1e682100 	fcmp	d8, d8
    78e8:	54004746 	b.vs	81d0 <fwp_write+0xf0c>
    78ec:	1e60c101 	fabs	d1, d8
    78f0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    78f4:	9e670000 	fmov	d0, x0
    78f8:	910123f5 	add	x21, sp, #0x48
    78fc:	52800033 	mov	w19, #0x1                   	// #1
    7900:	1e602020 	fcmp	d1, d0
    7904:	540001ad 	b.le	7938 <fwp_write+0x674>
    7908:	1e602118 	fcmpe	d8, #0.0
    790c:	d0000002 	adrp	x2, 9000 <__divti3+0x1e0>
    7910:	91158042 	add	x2, x2, #0x560
    7914:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7918:	9124e021 	add	x1, x1, #0x938
    791c:	aa1503e0 	mov	x0, x21
    7920:	9a81c041 	csel	x1, x2, x1, gt
    7924:	97ffec27 	bl	29c0 <strcpy@plt>
    7928:	17ffffd0 	b	7868 <fwp_write+0x5a4>
    792c:	11000673 	add	w19, w19, #0x1
    7930:	71004a7f 	cmp	w19, #0x12
    7934:	54003860 	b.eq	8040 <fwp_write+0xd7c>  // b.none
    7938:	1e604100 	fmov	d0, d8
    793c:	2a1303e1 	mov	w1, w19
    7940:	aa1503e0 	mov	x0, x21
    7944:	97ffef0f 	bl	3580 <fwp_format_g.constprop.0>
    7948:	aa1503e0 	mov	x0, x21
    794c:	d2800001 	mov	x1, #0x0                   	// #0
    7950:	97ffeb84 	bl	2760 <strtod@plt>
    7954:	1e602100 	fcmp	d8, d0
    7958:	54fffea1 	b.ne	792c <fwp_write+0x668>  // b.any
    795c:	aa1503e0 	mov	x0, x21
    7960:	97ffeee5 	bl	34f4 <fwp_finish_float>
    7964:	17ffffc1 	b	7868 <fwp_write+0x5a4>
    7968:	a9400e62 	ldp	x2, x3, [x19]
    796c:	910123f3 	add	x19, sp, #0x48
    7970:	aa1303e0 	mov	x0, x19
    7974:	97ffed2b 	bl	2e20 <fwp_fmt_u128>
    7978:	17fffe75 	b	734c <fwp_write+0x88>
    797c:	f90143f7 	str	x23, [sp, #640]
    7980:	f90147f8 	str	x24, [sp, #648]
    7984:	2a1303f8 	mov	w24, w19
    7988:	f9014bf9 	str	x25, [sp, #656]
    798c:	f9014ffa 	str	x26, [sp, #664]
    7990:	f13ffe7f 	cmp	x19, #0xfff
    7994:	54000049 	b.ls	799c <fwp_write+0x6d8>  // b.plast
    7998:	b9400278 	ldr	w24, [x19]
    799c:	f9400f80 	ldr	x0, [x28, #24]
    79a0:	2a1803f5 	mov	w21, w24
    79a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    79a8:	d37ef6b9 	lsl	x25, x21, #2
    79ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    79b0:	aa1603e0 	mov	x0, x22
    79b4:	97ffeb57 	bl	2710 <strlen@plt>
    79b8:	aa1603e1 	mov	x1, x22
    79bc:	aa0003e2 	mov	x2, x0
    79c0:	aa1403e0 	mov	x0, x20
    79c4:	97ffee93 	bl	3410 <buf_put>
    79c8:	f9401780 	ldr	x0, [x28, #40]
    79cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    79d0:	7100001f 	cmp	w0, #0x0
    79d4:	5400068d 	b.le	7aa4 <fwp_write+0x7e0>
    79d8:	91002276 	add	x22, x19, #0x8
    79dc:	91001ff5 	add	x21, sp, #0x7
    79e0:	d280001b 	mov	x27, #0x0                   	// #0
    79e4:	5280041a 	mov	w26, #0x20                  	// #32
    79e8:	f9401b80 	ldr	x0, [x28, #48]
    79ec:	aa1503e1 	mov	x1, x21
    79f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    79f4:	d2800022 	mov	x2, #0x1                   	// #1
    79f8:	f8786803 	ldr	x3, [x0, x24]
    79fc:	aa1403e0 	mov	x0, x20
    7a00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7a04:	39001ffa 	strb	w26, [sp, #7]
    7a08:	97ffee82 	bl	3410 <buf_put>
    7a0c:	f13ffeff 	cmp	x23, #0xfff
    7a10:	b9400261 	ldr	w1, [x19]
    7a14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7a18:	7100383f 	cmp	w1, #0xe
    7a1c:	54000160 	b.eq	7a48 <fwp_write+0x784>  // b.none
    7a20:	7100403f 	cmp	w1, #0x10
    7a24:	54001a60 	b.eq	7d70 <fwp_write+0xaac>  // b.none
    7a28:	7100283f 	cmp	w1, #0xa
    7a2c:	54002aa0 	b.eq	7f80 <fwp_write+0xcbc>  // b.none
    7a30:	540014ac 	b.gt	7cc4 <fwp_write+0xa00>
    7a34:	71000c3f 	cmp	w1, #0x3
    7a38:	540029ac 	b.gt	7f6c <fwp_write+0xca8>
    7a3c:	d37ffee0 	lsr	x0, x23, #63
    7a40:	37f814a1 	tbnz	w1, #31, 7cd4 <fwp_write+0xa10>
    7a44:	d503201f 	nop
    7a48:	34001460 	cbz	w0, 7cd4 <fwp_write+0xa10>
    7a4c:	52800503 	mov	w3, #0x28                  	// #40
    7a50:	aa1503e1 	mov	x1, x21
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	d2800022 	mov	x2, #0x1                   	// #1
    7a5c:	39001fe3 	strb	w3, [sp, #7]
    7a60:	97ffee6c 	bl	3410 <buf_put>
    7a64:	aa1303e2 	mov	x2, x19
    7a68:	aa1703e1 	mov	x1, x23
    7a6c:	aa1403e0 	mov	x0, x20
    7a70:	52800003 	mov	w3, #0x0                   	// #0
    7a74:	97fffe14 	bl	72c4 <fwp_write>
    7a78:	52800523 	mov	w3, #0x29                  	// #41
    7a7c:	aa1503e1 	mov	x1, x21
    7a80:	aa1403e0 	mov	x0, x20
    7a84:	d2800022 	mov	x2, #0x1                   	// #1
    7a88:	39001fe3 	strb	w3, [sp, #7]
    7a8c:	97ffee61 	bl	3410 <buf_put>
    7a90:	f9401780 	ldr	x0, [x28, #40]
    7a94:	9100077b 	add	x27, x27, #0x1
    7a98:	b8796800 	ldr	w0, [x0, x25]
    7a9c:	6b1b001f 	cmp	w0, w27
    7aa0:	54fffa4c 	b.gt	79e8 <fwp_write+0x724>
    7aa4:	f9413bf5 	ldr	x21, [sp, #624]
    7aa8:	f9413ff6 	ldr	x22, [sp, #632]
    7aac:	f94143f7 	ldr	x23, [sp, #640]
    7ab0:	f94147f8 	ldr	x24, [sp, #648]
    7ab4:	f9414bf9 	ldr	x25, [sp, #656]
    7ab8:	f9414ffa 	ldr	x26, [sp, #664]
    7abc:	f94153fb 	ldr	x27, [sp, #672]
    7ac0:	f94157fc 	ldr	x28, [sp, #680]
    7ac4:	17fffe2c 	b	7374 <fwp_write+0xb0>
    7ac8:	52800783 	mov	w3, #0x3c                  	// #60
    7acc:	91001ff3 	add	x19, sp, #0x7
    7ad0:	aa1303e1 	mov	x1, x19
    7ad4:	d2800022 	mov	x2, #0x1                   	// #1
    7ad8:	aa1403e0 	mov	x0, x20
    7adc:	39001fe3 	strb	w3, [sp, #7]
    7ae0:	97ffee4c 	bl	3410 <buf_put>
    7ae4:	f9400795 	ldr	x21, [x28, #8]
    7ae8:	aa1503e0 	mov	x0, x21
    7aec:	97ffeb09 	bl	2710 <strlen@plt>
    7af0:	aa1503e1 	mov	x1, x21
    7af4:	aa0003e2 	mov	x2, x0
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	97ffee45 	bl	3410 <buf_put>
    7b00:	528007c3 	mov	w3, #0x3e                  	// #62
    7b04:	aa1303e1 	mov	x1, x19
    7b08:	aa1403e0 	mov	x0, x20
    7b0c:	d2800022 	mov	x2, #0x1                   	// #1
    7b10:	39001fe3 	strb	w3, [sp, #7]
    7b14:	17fffe13 	b	7360 <fwp_write+0x9c>
    7b18:	f100067f 	cmp	x19, #0x1
    7b1c:	540025a0 	b.eq	7fd0 <fwp_write+0xd0c>  // b.none
    7b20:	b100067f 	cmn	x19, #0x1
    7b24:	54002bc0 	b.eq	809c <fwp_write+0xdd8>  // b.none
    7b28:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7b2c:	91250021 	add	x1, x1, #0x940
    7b30:	d2800022 	mov	x2, #0x1                   	// #1
    7b34:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b38:	f947f400 	ldr	x0, [x0, #4072]
    7b3c:	f94127e4 	ldr	x4, [sp, #584]
    7b40:	f9400003 	ldr	x3, [x0]
    7b44:	eb030084 	subs	x4, x4, x3
    7b48:	d2800003 	mov	x3, #0x0                   	// #0
    7b4c:	54ffebe0 	b.eq	78c8 <fwp_write+0x604>  // b.none
    7b50:	f90143f7 	str	x23, [sp, #640]
    7b54:	f90147f8 	str	x24, [sp, #648]
    7b58:	f9014bf9 	str	x25, [sp, #656]
    7b5c:	f9014ffa 	str	x26, [sp, #664]
    7b60:	fd015be8 	str	d8, [sp, #688]
    7b64:	fd015fe9 	str	d9, [sp, #696]
    7b68:	97ffeb46 	bl	2880 <__stack_chk_fail@plt>
    7b6c:	52800b63 	mov	w3, #0x5b                  	// #91
    7b70:	91001ff5 	add	x21, sp, #0x7
    7b74:	aa1503e1 	mov	x1, x21
    7b78:	aa1403e0 	mov	x0, x20
    7b7c:	d2800022 	mov	x2, #0x1                   	// #1
    7b80:	d0000016 	adrp	x22, 9000 <__divti3+0x1e0>
    7b84:	912782d6 	add	x22, x22, #0x9e0
    7b88:	39001fe3 	strb	w3, [sp, #7]
    7b8c:	97ffee21 	bl	3410 <buf_put>
    7b90:	b4000273 	cbz	x19, 7bdc <fwp_write+0x918>
    7b94:	f9400661 	ldr	x1, [x19, #8]
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	f9401f82 	ldr	x2, [x28, #56]
    7ba0:	52800003 	mov	w3, #0x0                   	// #0
    7ba4:	97fffdc8 	bl	72c4 <fwp_write>
    7ba8:	f9400a73 	ldr	x19, [x19, #16]
    7bac:	b4000193 	cbz	x19, 7bdc <fwp_write+0x918>
    7bb0:	aa1603e1 	mov	x1, x22
    7bb4:	aa1403e0 	mov	x0, x20
    7bb8:	d2800042 	mov	x2, #0x2                   	// #2
    7bbc:	97ffee15 	bl	3410 <buf_put>
    7bc0:	f9400661 	ldr	x1, [x19, #8]
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	f9401f82 	ldr	x2, [x28, #56]
    7bcc:	52800003 	mov	w3, #0x0                   	// #0
    7bd0:	97fffdbd 	bl	72c4 <fwp_write>
    7bd4:	f9400a73 	ldr	x19, [x19, #16]
    7bd8:	b5fffed3 	cbnz	x19, 7bb0 <fwp_write+0x8ec>
    7bdc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7be0:	aa1503e1 	mov	x1, x21
    7be4:	aa1403e0 	mov	x0, x20
    7be8:	d2800022 	mov	x2, #0x1                   	// #1
    7bec:	39001fe3 	strb	w3, [sp, #7]
    7bf0:	17fffddc 	b	7360 <fwp_write+0x9c>
    7bf4:	aa1403e0 	mov	x0, x20
    7bf8:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7bfc:	d28000c2 	mov	x2, #0x6                   	// #6
    7c00:	91274021 	add	x1, x1, #0x9d0
    7c04:	97ffee03 	bl	3410 <buf_put>
    7c08:	f9400260 	ldr	x0, [x19]
    7c0c:	b40004c0 	cbz	x0, 7ca4 <fwp_write+0x9e0>
    7c10:	910123f5 	add	x21, sp, #0x48
    7c14:	91002276 	add	x22, x19, #0x8
    7c18:	f90143f7 	str	x23, [sp, #640]
    7c1c:	d2800017 	mov	x23, #0x0                   	// #0
    7c20:	f90147f8 	str	x24, [sp, #648]
    7c24:	d0000018 	adrp	x24, 9000 <__divti3+0x1e0>
    7c28:	91276318 	add	x24, x24, #0x9d8
    7c2c:	f9014bf9 	str	x25, [sp, #656]
    7c30:	d0000019 	adrp	x25, 9000 <__divti3+0x1e0>
    7c34:	91278339 	add	x25, x25, #0x9e0
    7c38:	f9014ffa 	str	x26, [sp, #664]
    7c3c:	14000005 	b	7c50 <fwp_write+0x98c>
    7c40:	aa1903e1 	mov	x1, x25
    7c44:	aa1403e0 	mov	x0, x20
    7c48:	d2800042 	mov	x2, #0x2                   	// #2
    7c4c:	97ffedf1 	bl	3410 <buf_put>
    7c50:	38776ac5 	ldrb	w5, [x22, x23]
    7c54:	d2804003 	mov	x3, #0x200                 	// #512
    7c58:	aa1803e4 	mov	x4, x24
    7c5c:	aa0303e1 	mov	x1, x3
    7c60:	52800042 	mov	w2, #0x2                   	// #2
    7c64:	aa1503e0 	mov	x0, x21
    7c68:	910006f7 	add	x23, x23, #0x1
    7c6c:	97ffeae1 	bl	27f0 <__snprintf_chk@plt>
    7c70:	aa1503e0 	mov	x0, x21
    7c74:	97ffeaa7 	bl	2710 <strlen@plt>
    7c78:	aa1503e1 	mov	x1, x21
    7c7c:	aa0003e2 	mov	x2, x0
    7c80:	aa1403e0 	mov	x0, x20
    7c84:	97ffede3 	bl	3410 <buf_put>
    7c88:	f9400260 	ldr	x0, [x19]
    7c8c:	eb17001f 	cmp	x0, x23
    7c90:	54fffd88 	b.hi	7c40 <fwp_write+0x97c>  // b.pmore
    7c94:	f94143f7 	ldr	x23, [sp, #640]
    7c98:	f94147f8 	ldr	x24, [sp, #648]
    7c9c:	f9414bf9 	ldr	x25, [sp, #656]
    7ca0:	f9414ffa 	ldr	x26, [sp, #664]
    7ca4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ca8:	aa1403e0 	mov	x0, x20
    7cac:	91001fe1 	add	x1, sp, #0x7
    7cb0:	d2800022 	mov	x2, #0x1                   	// #1
    7cb4:	39001fe3 	strb	w3, [sp, #7]
    7cb8:	17fffdaa 	b	7360 <fwp_write+0x9c>
    7cbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cc0:	17fffe45 	b	75d4 <fwp_write+0x310>
    7cc4:	f10002ff 	cmp	x23, #0x0
    7cc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ccc:	71002c3f 	cmp	w1, #0xb
    7cd0:	54ffebc0 	b.eq	7a48 <fwp_write+0x784>  // b.none
    7cd4:	aa1303e2 	mov	x2, x19
    7cd8:	aa1703e1 	mov	x1, x23
    7cdc:	aa1403e0 	mov	x0, x20
    7ce0:	52800003 	mov	w3, #0x0                   	// #0
    7ce4:	97fffd78 	bl	72c4 <fwp_write>
    7ce8:	17ffff6a 	b	7a90 <fwp_write+0x7cc>
    7cec:	aa1403e0 	mov	x0, x20
    7cf0:	91001fe1 	add	x1, sp, #0x7
    7cf4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cf8:	d2800022 	mov	x2, #0x1                   	// #1
    7cfc:	17fffe39 	b	75e0 <fwp_write+0x31c>
    7d00:	a9400281 	ldp	x1, x0, [x20]
    7d04:	91000800 	add	x0, x0, #0x2
    7d08:	8b160000 	add	x0, x0, x22
    7d0c:	f9000680 	str	x0, [x20, #8]
    7d10:	3820683f 	strb	wzr, [x1, x0]
    7d14:	f9413bf5 	ldr	x21, [sp, #624]
    7d18:	f9413ff6 	ldr	x22, [sp, #632]
    7d1c:	f94153fb 	ldr	x27, [sp, #672]
    7d20:	f94157fc 	ldr	x28, [sp, #680]
    7d24:	17fffd94 	b	7374 <fwp_write+0xb0>
    7d28:	f9400f80 	ldr	x0, [x28, #24]
    7d2c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7d30:	aa1b03e0 	mov	x0, x27
    7d34:	97ffea77 	bl	2710 <strlen@plt>
    7d38:	aa1b03e1 	mov	x1, x27
    7d3c:	aa0003e2 	mov	x2, x0
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	97ffedb3 	bl	3410 <buf_put>
    7d48:	aa1903e1 	mov	x1, x25
    7d4c:	aa1403e0 	mov	x0, x20
    7d50:	d2800062 	mov	x2, #0x3                   	// #3
    7d54:	97ffedaf 	bl	3410 <buf_put>
    7d58:	17fffe11 	b	759c <fwp_write+0x2d8>
    7d5c:	aa1a03e1 	mov	x1, x26
    7d60:	aa1403e0 	mov	x0, x20
    7d64:	d2800042 	mov	x2, #0x2                   	// #2
    7d68:	97ffedaa 	bl	3410 <buf_put>
    7d6c:	17fffe0a 	b	7594 <fwp_write+0x2d0>
    7d70:	f9400660 	ldr	x0, [x19, #8]
    7d74:	b4fffb00 	cbz	x0, 7cd4 <fwp_write+0xa10>
    7d78:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7d7c:	9127e021 	add	x1, x1, #0x9f8
    7d80:	97ffeae0 	bl	2900 <strcmp@plt>
    7d84:	7100001f 	cmp	w0, #0x0
    7d88:	1a9f07e0 	cset	w0, ne	// ne = any
    7d8c:	17ffff2f 	b	7a48 <fwp_write+0x784>
    7d90:	aa1403e0 	mov	x0, x20
    7d94:	d2800042 	mov	x2, #0x2                   	// #2
    7d98:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7d9c:	9127c021 	add	x1, x1, #0x9f0
    7da0:	97ffed9c 	bl	3410 <buf_put>
    7da4:	91004261 	add	x1, x19, #0x10
    7da8:	aa1403e0 	mov	x0, x20
    7dac:	f9402382 	ldr	x2, [x28, #64]
    7db0:	52800003 	mov	w3, #0x0                   	// #0
    7db4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7db8:	97fffd43 	bl	72c4 <fwp_write>
    7dbc:	17fffd9d 	b	7430 <fwp_write+0x16c>
    7dc0:	1e22c109 	fcvt	d9, s8
    7dc4:	910123f5 	add	x21, sp, #0x48
    7dc8:	52800033 	mov	w19, #0x1                   	// #1
    7dcc:	d503201f 	nop
    7dd0:	1e604120 	fmov	d0, d9
    7dd4:	2a1303e1 	mov	w1, w19
    7dd8:	aa1503e0 	mov	x0, x21
    7ddc:	97ffede9 	bl	3580 <fwp_format_g.constprop.0>
    7de0:	aa1503e0 	mov	x0, x21
    7de4:	d2800001 	mov	x1, #0x0                   	// #0
    7de8:	97ffead2 	bl	2930 <strtof@plt>
    7dec:	1e202100 	fcmp	s8, s0
    7df0:	54ffdb60 	b.eq	795c <fwp_write+0x698>  // b.none
    7df4:	11000673 	add	w19, w19, #0x1
    7df8:	71002a7f 	cmp	w19, #0xa
    7dfc:	54fffea1 	b.ne	7dd0 <fwp_write+0xb0c>  // b.any
    7e00:	1e604120 	fmov	d0, d9
    7e04:	aa1503e0 	mov	x0, x21
    7e08:	52800121 	mov	w1, #0x9                   	// #9
    7e0c:	97ffeddd 	bl	3580 <fwp_format_g.constprop.0>
    7e10:	17fffed3 	b	795c <fwp_write+0x698>
    7e14:	d37ef6a1 	lsl	x1, x21, #2
    7e18:	b7f81563 	tbnz	x3, #63, 80c4 <fwp_write+0xe00>
    7e1c:	91002263 	add	x3, x19, #0x8
    7e20:	8b010061 	add	x1, x3, x1
    7e24:	b9400023 	ldr	w3, [x1]
    7e28:	7100081f 	cmp	w0, #0x2
    7e2c:	2a0303e1 	mov	w1, w3
    7e30:	93407c63 	sxtw	x3, w3
    7e34:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e38:	17fffe5a 	b	77a0 <fwp_write+0x4dc>
    7e3c:	d37ffaa1 	lsl	x1, x21, #1
    7e40:	b7f81363 	tbnz	x3, #63, 80ac <fwp_write+0xde8>
    7e44:	91002263 	add	x3, x19, #0x8
    7e48:	8b010061 	add	x1, x3, x1
    7e4c:	79400021 	ldrh	w1, [x1]
    7e50:	7100041f 	cmp	w0, #0x1
    7e54:	93403c23 	sxth	x3, w1
    7e58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e5c:	17fffe51 	b	77a0 <fwp_write+0x4dc>
    7e60:	52800443 	mov	w3, #0x22                  	// #34
    7e64:	91001ff5 	add	x21, sp, #0x7
    7e68:	91002273 	add	x19, x19, #0x8
    7e6c:	aa1503e1 	mov	x1, x21
    7e70:	aa1403e0 	mov	x0, x20
    7e74:	d2800022 	mov	x2, #0x1                   	// #1
    7e78:	39001fe3 	strb	w3, [sp, #7]
    7e7c:	f90143f7 	str	x23, [sp, #640]
    7e80:	8b160277 	add	x23, x19, x22
    7e84:	f90147f8 	str	x24, [sp, #648]
    7e88:	97ffed62 	bl	3410 <buf_put>
    7e8c:	b4000696 	cbz	x22, 7f5c <fwp_write+0xc98>
    7e90:	d0000018 	adrp	x24, 9000 <__divti3+0x1e0>
    7e94:	91268318 	add	x24, x24, #0x9a0
    7e98:	f9014bf9 	str	x25, [sp, #656]
    7e9c:	d0000019 	adrp	x25, 9000 <__divti3+0x1e0>
    7ea0:	91270339 	add	x25, x25, #0x9c0
    7ea4:	f9014ffa 	str	x26, [sp, #664]
    7ea8:	1400000d 	b	7edc <fwp_write+0xc18>
    7eac:	710024bf 	cmp	w5, #0x9
    7eb0:	54000460 	b.eq	7f3c <fwp_write+0xc78>  // b.none
    7eb4:	710028bf 	cmp	w5, #0xa
    7eb8:	54000a61 	b.ne	8004 <fwp_write+0xd40>  // b.any
    7ebc:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7ec0:	aa1403e0 	mov	x0, x20
    7ec4:	9126c021 	add	x1, x1, #0x9b0
    7ec8:	d2800042 	mov	x2, #0x2                   	// #2
    7ecc:	97ffed51 	bl	3410 <buf_put>
    7ed0:	91000673 	add	x19, x19, #0x1
    7ed4:	eb17027f 	cmp	x19, x23
    7ed8:	540003e0 	b.eq	7f54 <fwp_write+0xc90>  // b.none
    7edc:	39400265 	ldrb	w5, [x19]
    7ee0:	710034bf 	cmp	w5, #0xd
    7ee4:	54000180 	b.eq	7f14 <fwp_write+0xc50>  // b.none
    7ee8:	54fffe29 	b.ls	7eac <fwp_write+0xbe8>  // b.plast
    7eec:	710088bf 	cmp	w5, #0x22
    7ef0:	540001c0 	b.eq	7f28 <fwp_write+0xc64>  // b.none
    7ef4:	710170bf 	cmp	w5, #0x5c
    7ef8:	54000741 	b.ne	7fe0 <fwp_write+0xd1c>  // b.any
    7efc:	aa1403e0 	mov	x0, x20
    7f00:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7f04:	d2800042 	mov	x2, #0x2                   	// #2
    7f08:	9126a021 	add	x1, x1, #0x9a8
    7f0c:	97ffed41 	bl	3410 <buf_put>
    7f10:	17fffff0 	b	7ed0 <fwp_write+0xc0c>
    7f14:	aa1903e1 	mov	x1, x25
    7f18:	aa1403e0 	mov	x0, x20
    7f1c:	d2800042 	mov	x2, #0x2                   	// #2
    7f20:	97ffed3c 	bl	3410 <buf_put>
    7f24:	17ffffeb 	b	7ed0 <fwp_write+0xc0c>
    7f28:	aa1803e1 	mov	x1, x24
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	d2800042 	mov	x2, #0x2                   	// #2
    7f34:	97ffed37 	bl	3410 <buf_put>
    7f38:	17ffffe6 	b	7ed0 <fwp_write+0xc0c>
    7f3c:	aa1403e0 	mov	x0, x20
    7f40:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7f44:	d2800042 	mov	x2, #0x2                   	// #2
    7f48:	9126e021 	add	x1, x1, #0x9b8
    7f4c:	97ffed31 	bl	3410 <buf_put>
    7f50:	17ffffe0 	b	7ed0 <fwp_write+0xc0c>
    7f54:	f9414bf9 	ldr	x25, [sp, #656]
    7f58:	f9414ffa 	ldr	x26, [sp, #664]
    7f5c:	aa1503e1 	mov	x1, x21
    7f60:	aa1403e0 	mov	x0, x20
    7f64:	52800443 	mov	w3, #0x22                  	// #34
    7f68:	17fffd9d 	b	75dc <fwp_write+0x318>
    7f6c:	7100103f 	cmp	w1, #0x4
    7f70:	54ffeb21 	b.ne	7cd4 <fwp_write+0xa10>  // b.any
    7f74:	f94006e0 	ldr	x0, [x23, #8]
    7f78:	d37ffc00 	lsr	x0, x0, #63
    7f7c:	17fffeb3 	b	7a48 <fwp_write+0x784>
    7f80:	710002ff 	cmp	w23, #0x0
    7f84:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f88:	17fffeb0 	b	7a48 <fwp_write+0x784>
    7f8c:	528005a1 	mov	w1, #0x2d                  	// #45
    7f90:	eb0203e2 	negs	x2, x2
    7f94:	da0303e3 	ngc	x3, x3
    7f98:	910127e0 	add	x0, sp, #0x49
    7f9c:	910123f5 	add	x21, sp, #0x48
    7fa0:	390123e1 	strb	w1, [sp, #72]
    7fa4:	97ffeb9f 	bl	2e20 <fwp_fmt_u128>
    7fa8:	17fffe18 	b	7808 <fwp_write+0x544>
    7fac:	d37ceea1 	lsl	x1, x21, #4
    7fb0:	b7f810a3 	tbnz	x3, #63, 81c4 <fwp_write+0xf00>
    7fb4:	91002260 	add	x0, x19, #0x8
    7fb8:	8b010001 	add	x1, x0, x1
    7fbc:	17fffdf9 	b	77a0 <fwp_write+0x4dc>
    7fc0:	f9400a61 	ldr	x1, [x19, #16]
    7fc4:	8b010000 	add	x0, x0, x1
    7fc8:	f9400001 	ldr	x1, [x0]
    7fcc:	17fffdf5 	b	77a0 <fwp_write+0x4dc>
    7fd0:	d0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    7fd4:	d2800042 	mov	x2, #0x2                   	// #2
    7fd8:	91252021 	add	x1, x1, #0x948
    7fdc:	17fffed6 	b	7b34 <fwp_write+0x870>
    7fe0:	7101fcbf 	cmp	w5, #0x7f
    7fe4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7fe8:	540000e9 	b.ls	8004 <fwp_write+0xd40>  // b.plast
    7fec:	aa1503e1 	mov	x1, x21
    7ff0:	aa1403e0 	mov	x0, x20
    7ff4:	d2800022 	mov	x2, #0x1                   	// #1
    7ff8:	39001fe5 	strb	w5, [sp, #7]
    7ffc:	97ffed05 	bl	3410 <buf_put>
    8000:	17ffffb4 	b	7ed0 <fwp_write+0xc0c>
    8004:	d2800203 	mov	x3, #0x10                  	// #16
    8008:	b0000004 	adrp	x4, 9000 <__divti3+0x1e0>
    800c:	aa0303e1 	mov	x1, x3
    8010:	91272084 	add	x4, x4, #0x9c8
    8014:	910123f6 	add	x22, sp, #0x48
    8018:	52800042 	mov	w2, #0x2                   	// #2
    801c:	aa1603e0 	mov	x0, x22
    8020:	97ffe9f4 	bl	27f0 <__snprintf_chk@plt>
    8024:	aa1603e0 	mov	x0, x22
    8028:	97ffe9ba 	bl	2710 <strlen@plt>
    802c:	aa1603e1 	mov	x1, x22
    8030:	aa0003e2 	mov	x2, x0
    8034:	aa1403e0 	mov	x0, x20
    8038:	97ffecf6 	bl	3410 <buf_put>
    803c:	17ffffa5 	b	7ed0 <fwp_write+0xc0c>
    8040:	1e604100 	fmov	d0, d8
    8044:	aa1503e0 	mov	x0, x21
    8048:	52800221 	mov	w1, #0x11                  	// #17
    804c:	97ffed4d 	bl	3580 <fwp_format_g.constprop.0>
    8050:	17fffe43 	b	795c <fwp_write+0x698>
    8054:	b9401040 	ldr	w0, [x2, #16]
    8058:	350003c0 	cbnz	w0, 80d0 <fwp_write+0xe0c>
    805c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8060:	f947f400 	ldr	x0, [x0, #4072]
    8064:	f94127e2 	ldr	x2, [sp, #584]
    8068:	f9400001 	ldr	x1, [x0]
    806c:	eb010042 	subs	x2, x2, x1
    8070:	d2800001 	mov	x1, #0x0                   	// #0
    8074:	54ffd721 	b.ne	7b58 <fwp_write+0x894>  // b.any
    8078:	f9413bf5 	ldr	x21, [sp, #624]
    807c:	b0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    8080:	f9413ff6 	ldr	x22, [sp, #632]
    8084:	aa1403e0 	mov	x0, x20
    8088:	f94143f7 	ldr	x23, [sp, #640]
    808c:	91286021 	add	x1, x1, #0xa18
    8090:	f94147f8 	ldr	x24, [sp, #648]
    8094:	d2800042 	mov	x2, #0x2                   	// #2
    8098:	17fffd0f 	b	74d4 <fwp_write+0x210>
    809c:	b0000001 	adrp	x1, 9000 <__divti3+0x1e0>
    80a0:	d2800042 	mov	x2, #0x2                   	// #2
    80a4:	91254021 	add	x1, x1, #0x950
    80a8:	17fffea3 	b	7b34 <fwp_write+0x870>
    80ac:	f9400a63 	ldr	x3, [x19, #16]
    80b0:	8b030021 	add	x1, x1, x3
    80b4:	17ffff66 	b	7e4c <fwp_write+0xb88>
    80b8:	f9400a61 	ldr	x1, [x19, #16]
    80bc:	8b0102a1 	add	x1, x21, x1
    80c0:	17fffdb4 	b	7790 <fwp_write+0x4cc>
    80c4:	f9400a63 	ldr	x3, [x19, #16]
    80c8:	8b030021 	add	x1, x1, x3
    80cc:	17ffff56 	b	7e24 <fwp_write+0xb60>
    80d0:	b9404840 	ldr	w0, [x2, #72]
    80d4:	91001ff5 	add	x21, sp, #0x7
    80d8:	34ffa380 	cbz	w0, 7548 <fwp_write+0x284>
    80dc:	52800503 	mov	w3, #0x28                  	// #40
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	aa1503e1 	mov	x1, x21
    80e8:	d2800022 	mov	x2, #0x1                   	// #1
    80ec:	39001fe3 	strb	w3, [sp, #7]
    80f0:	97ffecc8 	bl	3410 <buf_put>
    80f4:	b9401380 	ldr	w0, [x28, #16]
    80f8:	52800038 	mov	w24, #0x1                   	// #1
    80fc:	7100001f 	cmp	w0, #0x0
    8100:	54ffa38c 	b.gt	7570 <fwp_write+0x2ac>
    8104:	17fffd33 	b	75d0 <fwp_write+0x30c>
    8108:	f9014bf9 	str	x25, [sp, #656]
    810c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12c30>
    8110:	f9014ffa 	str	x26, [sp, #664]
    8114:	f9400676 	ldr	x22, [x19, #8]
    8118:	910aa333 	add	x19, x25, #0x2a8
    811c:	91002273 	add	x19, x19, #0x8
    8120:	937ffed8 	asr	x24, x22, #63
    8124:	aa1802c0 	orr	x0, x22, x24
    8128:	b5000320 	cbnz	x0, 818c <fwp_write+0xec8>
    812c:	110006b5 	add	w21, w21, #0x1
    8130:	710016bf 	cmp	w21, #0x5
    8134:	54ffffc1 	b.ne	812c <fwp_write+0xe68>  // b.any
    8138:	b7f80578 	tbnz	x24, #63, 81e4 <fwp_write+0xf20>
    813c:	910023f3 	add	x19, sp, #0x8
    8140:	aa1603e2 	mov	x2, x22
    8144:	aa1303e0 	mov	x0, x19
    8148:	d2800003 	mov	x3, #0x0                   	// #0
    814c:	97ffeb35 	bl	2e20 <fwp_fmt_u128>
    8150:	910123f5 	add	x21, sp, #0x48
    8154:	b0000003 	adrp	x3, 9000 <__divti3+0x1e0>
    8158:	aa1303e4 	mov	x4, x19
    815c:	aa1503e0 	mov	x0, x21
    8160:	91284063 	add	x3, x3, #0xa10
    8164:	d2804002 	mov	x2, #0x200                 	// #512
    8168:	52800041 	mov	w1, #0x2                   	// #2
    816c:	97ffe96d 	bl	2720 <__sprintf_chk@plt>
    8170:	aa1503e0 	mov	x0, x21
    8174:	97ffe967 	bl	2710 <strlen@plt>
    8178:	aa1503e1 	mov	x1, x21
    817c:	aa0003e2 	mov	x2, x0
    8180:	aa1403e0 	mov	x0, x20
    8184:	97ffeca3 	bl	3410 <buf_put>
    8188:	17fffe47 	b	7aa4 <fwp_write+0x7e0>
    818c:	f9400277 	ldr	x23, [x19]
    8190:	aa1603e0 	mov	x0, x22
    8194:	aa1803e1 	mov	x1, x24
    8198:	aa1703e2 	mov	x2, x23
    819c:	937ffefa 	asr	x26, x23, #63
    81a0:	aa1a03e3 	mov	x3, x26
    81a4:	940003ff 	bl	91a0 <__modti3>
    81a8:	aa010000 	orr	x0, x0, x1
    81ac:	b40002c0 	cbz	x0, 8204 <fwp_write+0xf40>
    81b0:	110006b5 	add	w21, w21, #0x1
    81b4:	91004273 	add	x19, x19, #0x10
    81b8:	710016bf 	cmp	w21, #0x5
    81bc:	54fffe81 	b.ne	818c <fwp_write+0xec8>  // b.any
    81c0:	17ffffde 	b	8138 <fwp_write+0xe74>
    81c4:	f9400a60 	ldr	x0, [x19, #16]
    81c8:	8b000021 	add	x1, x1, x0
    81cc:	17fffd75 	b	77a0 <fwp_write+0x4dc>
    81d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    81d4:	910123f5 	add	x21, sp, #0x48
    81d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    81dc:	b9004be0 	str	w0, [sp, #72]
    81e0:	17fffda2 	b	7868 <fwp_write+0x5a4>
    81e4:	528005a1 	mov	w1, #0x2d                  	// #45
    81e8:	eb1603e2 	negs	x2, x22
    81ec:	da1803e3 	ngc	x3, x24
    81f0:	910027e0 	add	x0, sp, #0x9
    81f4:	910023f3 	add	x19, sp, #0x8
    81f8:	390023e1 	strb	w1, [sp, #8]
    81fc:	97ffeb09 	bl	2e20 <fwp_fmt_u128>
    8200:	17ffffd4 	b	8150 <fwp_write+0xe8c>
    8204:	aa1703e2 	mov	x2, x23
    8208:	aa1a03e3 	mov	x3, x26
    820c:	aa1603e0 	mov	x0, x22
    8210:	aa1803e1 	mov	x1, x24
    8214:	94000303 	bl	8e20 <__divti3>
    8218:	aa0003e2 	mov	x2, x0
    821c:	aa0103e3 	mov	x3, x1
    8220:	b7f80201 	tbnz	x1, #63, 8260 <fwp_write+0xf9c>
    8224:	910023f3 	add	x19, sp, #0x8
    8228:	aa1303e0 	mov	x0, x19
    822c:	97ffeafd 	bl	2e20 <fwp_fmt_u128>
    8230:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8234:	910aa339 	add	x25, x25, #0x2a8
    8238:	910123f5 	add	x21, sp, #0x48
    823c:	aa1303e4 	mov	x4, x19
    8240:	aa1503e0 	mov	x0, x21
    8244:	b0000003 	adrp	x3, 9000 <__divti3+0x1e0>
    8248:	f8616b25 	ldr	x5, [x25, x1]
    824c:	91282063 	add	x3, x3, #0xa08
    8250:	d2804002 	mov	x2, #0x200                 	// #512
    8254:	52800041 	mov	w1, #0x2                   	// #2
    8258:	97ffe932 	bl	2720 <__sprintf_chk@plt>
    825c:	17ffffc5 	b	8170 <fwp_write+0xeac>
    8260:	528005a4 	mov	w4, #0x2d                  	// #45
    8264:	eb0003e2 	negs	x2, x0
    8268:	da0103e3 	ngc	x3, x1
    826c:	910027e0 	add	x0, sp, #0x9
    8270:	910023f3 	add	x19, sp, #0x8
    8274:	390023e4 	strb	w4, [sp, #8]
    8278:	97ffeaea 	bl	2e20 <fwp_fmt_u128>
    827c:	17ffffed 	b	8230 <fwp_write+0xf6c>
    8280:	f9013bf5 	str	x21, [sp, #624]
    8284:	f9013ff6 	str	x22, [sp, #632]
    8288:	f90143f7 	str	x23, [sp, #640]
    828c:	f90147f8 	str	x24, [sp, #648]
    8290:	f9014bf9 	str	x25, [sp, #656]
    8294:	f9014ffa 	str	x26, [sp, #664]
    8298:	f90153fb 	str	x27, [sp, #672]
    829c:	f90157fc 	str	x28, [sp, #680]
    82a0:	fd015be8 	str	d8, [sp, #688]
    82a4:	fd015fe9 	str	d9, [sp, #696]
    82a8:	97ffe976 	bl	2880 <__stack_chk_fail@plt>
    82ac:	d503201f 	nop

00000000000082b0 <fwp_main_thread>:
    82b0:	d105c3ff 	sub	sp, sp, #0x170
    82b4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    82b8:	f947f400 	ldr	x0, [x0, #4072]
    82bc:	a9117bfd 	stp	x29, x30, [sp, #272]
    82c0:	910443fd 	add	x29, sp, #0x110
    82c4:	a91253f3 	stp	x19, x20, [sp, #288]
    82c8:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    82cc:	9114c261 	add	x1, x19, #0x530
    82d0:	a9135bf5 	stp	x21, x22, [sp, #304]
    82d4:	a91463f7 	stp	x23, x24, [sp, #320]
    82d8:	b953a421 	ldr	w1, [x1, #5028]
    82dc:	f9400002 	ldr	x2, [x0]
    82e0:	f90087e2 	str	x2, [sp, #264]
    82e4:	d2800002 	mov	x2, #0x0                   	// #0
    82e8:	34000e41 	cbz	w1, 84b0 <fwp_main_thread+0x200>
    82ec:	9114c260 	add	x0, x19, #0x530
    82f0:	b953a800 	ldr	w0, [x0, #5032]
    82f4:	35000d60 	cbnz	w0, 84a0 <fwp_main_thread+0x1f0>
    82f8:	900000d5 	adrp	x21, 20000 <__data_start>
    82fc:	900000c2 	adrp	x2, 20000 <__data_start>
    8300:	9100c2b4 	add	x20, x21, #0x30
    8304:	910d4042 	add	x2, x2, #0x350
    8308:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    830c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8310:	9100c3f7 	add	x23, sp, #0x30
    8314:	910063f6 	add	x22, sp, #0x18
    8318:	aa1703e0 	mov	x0, x23
    831c:	d2800001 	mov	x1, #0x0                   	// #0
    8320:	a9018e96 	stp	x22, x3, [x20, #24]
    8324:	f9001be2 	str	x2, [sp, #48]
    8328:	b9003bff 	str	wzr, [sp, #56]
    832c:	f90023e4 	str	x4, [sp, #64]
    8330:	97ffe8ec 	bl	26e0 <sigaltstack@plt>
    8334:	35000220 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    8338:	4f000400 	movi	v0.4s, #0x0
    833c:	9101e3e0 	add	x0, sp, #0x78
    8340:	f0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    8344:	9101c021 	add	x1, x1, #0x70
    8348:	f9003be1 	str	x1, [sp, #112]
    834c:	52800082 	mov	w2, #0x4                   	// #4
    8350:	72a10002 	movk	w2, #0x800, lsl #16
    8354:	9101c3f8 	add	x24, sp, #0x70
    8358:	3d802000 	str	q0, [x0, #128]
    835c:	b900fbe2 	str	w2, [sp, #248]
    8360:	ad000000 	stp	q0, q0, [x0]
    8364:	ad010000 	stp	q0, q0, [x0, #32]
    8368:	ad020000 	stp	q0, q0, [x0, #64]
    836c:	ad030000 	stp	q0, q0, [x0, #96]
    8370:	97ffe934 	bl	2840 <sigemptyset@plt>
    8374:	340000c0 	cbz	w0, 838c <fwp_main_thread+0xdc>
    8378:	b0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    837c:	9128a000 	add	x0, x0, #0xa28
    8380:	a9156bf9 	stp	x25, x26, [sp, #336]
    8384:	a91673fb 	stp	x27, x28, [sp, #352]
    8388:	97ffeec2 	bl	3e90 <fwp_trap>
    838c:	aa1803e1 	mov	x1, x24
    8390:	d2800002 	mov	x2, #0x0                   	// #0
    8394:	52800160 	mov	w0, #0xb                   	// #11
    8398:	97ffe942 	bl	28a0 <sigaction@plt>
    839c:	35fffee0 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    83a0:	aa1803e1 	mov	x1, x24
    83a4:	d2800002 	mov	x2, #0x0                   	// #0
    83a8:	528000e0 	mov	w0, #0x7                   	// #7
    83ac:	97ffe93d 	bl	28a0 <sigaction@plt>
    83b0:	35fffe40 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    83b4:	b942f680 	ldr	w0, [x20, #756]
    83b8:	34000800 	cbz	w0, 84b8 <fwp_main_thread+0x208>
    83bc:	9100c2b6 	add	x22, x21, #0x30
    83c0:	f9400ad4 	ldr	x20, [x22, #16]
    83c4:	b4001454 	cbz	x20, 864c <fwp_main_thread+0x39c>
    83c8:	91010297 	add	x23, x20, #0x40
    83cc:	a9156bf9 	stp	x25, x26, [sp, #336]
    83d0:	52800038 	mov	w24, #0x1                   	// #1
    83d4:	39414a99 	ldrb	w25, [x20, #82]
    83d8:	39014a98 	strb	w24, [x20, #82]
    83dc:	d503201f 	nop
    83e0:	f9401680 	ldr	x0, [x20, #40]
    83e4:	b4001300 	cbz	x0, 8644 <fwp_main_thread+0x394>
    83e8:	f9403281 	ldr	x1, [x20, #96]
    83ec:	39414680 	ldrb	w0, [x20, #81]
    83f0:	b4000f21 	cbz	x1, 85d4 <fwp_main_thread+0x324>
    83f4:	36000de0 	tbz	w0, #0, 85b0 <fwp_main_thread+0x300>
    83f8:	f9400ad3 	ldr	x19, [x22, #16]
    83fc:	f9402280 	ldr	x0, [x20, #64]
    8400:	39414a61 	ldrb	w1, [x19, #82]
    8404:	37001101 	tbnz	w1, #0, 8624 <fwp_main_thread+0x374>
    8408:	f9403261 	ldr	x1, [x19, #96]
    840c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8410:	f9009660 	str	x0, [x19, #296]
    8414:	b4000040 	cbz	x0, 841c <fwp_main_thread+0x16c>
    8418:	f9009013 	str	x19, [x0, #288]
    841c:	f9002293 	str	x19, [x20, #64]
    8420:	b4000101 	cbz	x1, 8440 <fwp_main_thread+0x190>
    8424:	f94046c0 	ldr	x0, [x22, #136]
    8428:	39015678 	strb	w24, [x19, #85]
    842c:	f9003661 	str	x1, [x19, #104]
    8430:	a910827f 	stp	xzr, x0, [x19, #264]
    8434:	b4000040 	cbz	x0, 843c <fwp_main_thread+0x18c>
    8438:	f9008413 	str	x19, [x0, #264]
    843c:	f90046d3 	str	x19, [x22, #136]
    8440:	39015a7f 	strb	wzr, [x19, #86]
    8444:	97fff90f 	bl	6880 <fwp_block>
    8448:	f9408e62 	ldr	x2, [x19, #280]
    844c:	b4000142 	cbz	x2, 8474 <fwp_main_thread+0x1c4>
    8450:	a9520261 	ldp	x1, x0, [x19, #288]
    8454:	b4000f41 	cbz	x1, 863c <fwp_main_thread+0x38c>
    8458:	f9009420 	str	x0, [x1, #296]
    845c:	f9409660 	ldr	x0, [x19, #296]
    8460:	b4000040 	cbz	x0, 8468 <fwp_main_thread+0x1b8>
    8464:	f9009001 	str	x1, [x0, #288]
    8468:	91080260 	add	x0, x19, #0x200
    846c:	f900967f 	str	xzr, [x19, #296]
    8470:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8474:	39415660 	ldrb	w0, [x19, #85]
    8478:	3607fb40 	tbz	w0, #0, 83e0 <fwp_main_thread+0x130>
    847c:	a9508261 	ldp	x1, x0, [x19, #264]
    8480:	b4001e81 	cbz	x1, 8850 <fwp_main_thread+0x5a0>
    8484:	f9008820 	str	x0, [x1, #272]
    8488:	b4000040 	cbz	x0, 8490 <fwp_main_thread+0x1e0>
    848c:	f9008401 	str	x1, [x0, #264]
    8490:	91080260 	add	x0, x19, #0x200
    8494:	3901567f 	strb	wzr, [x19, #85]
    8498:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    849c:	17ffffd1 	b	83e0 <fwp_main_thread+0x130>
    84a0:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    84a4:	91261000 	add	x0, x0, #0x984
    84a8:	9400041a 	bl	9510 <atexit>
    84ac:	17ffff93 	b	82f8 <fwp_main_thread+0x48>
    84b0:	97ffed90 	bl	3af0 <fwp_heap_init>
    84b4:	17ffff8e 	b	82ec <fwp_main_thread+0x3c>
    84b8:	f9416282 	ldr	x2, [x20, #704]
    84bc:	a9156bf9 	stp	x25, x26, [sp, #336]
    84c0:	b0ffffe0 	adrp	x0, 5000 <fwp_tape_grow.constprop.0+0x15c>
    84c4:	a91673fb 	stp	x27, x28, [sp, #352]
    84c8:	912cc000 	add	x0, x0, #0xb30
    84cc:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    84d0:	9114c27a 	add	x26, x19, #0x530
    84d4:	913d4021 	add	x1, x1, #0xf50
    84d8:	d280001b 	mov	x27, #0x0                   	// #0
    84dc:	d290001c 	mov	x28, #0x8000                	// #32768
    84e0:	f90003ff 	str	xzr, [sp]
    84e4:	a90187e2 	stp	x2, x1, [sp, #24]
    84e8:	a902fff7 	stp	x23, xzr, [sp, #40]
    84ec:	a90403ff 	stp	xzr, x0, [sp, #64]
    84f0:	f9016296 	str	x22, [x20, #704]
    84f4:	14000012 	b	853c <fwp_main_thread+0x28c>
    84f8:	7100045f 	cmp	w2, #0x1
    84fc:	540001a1 	b.ne	8530 <fwp_main_thread+0x280>  // b.any
    8500:	294308a6 	ldp	w6, w2, [x5, #24]
    8504:	92403c21 	and	x1, x1, #0xffff
    8508:	9b067c21 	mul	x1, x1, x6
    850c:	d360fc21 	lsr	x1, x1, #32
    8510:	eb02003f 	cmp	x1, x2
    8514:	540000e2 	b.cs	8530 <fwp_main_thread+0x280>  // b.hs, b.nlast
    8518:	8b010000 	add	x0, x0, x1
    851c:	39400001 	ldrb	w1, [x0]
    8520:	7103fc3f 	cmp	w1, #0xff
    8524:	54003be0 	b.eq	8ca0 <fwp_main_thread+0x9f0>  // b.none
    8528:	52800021 	mov	w1, #0x1                   	// #1
    852c:	39000001 	strb	w1, [x0]
    8530:	a9037ffb 	stp	x27, xzr, [sp, #48]
    8534:	aa190294 	orr	x20, x20, x25
    8538:	b4001914 	cbz	x20, 8858 <fwp_main_thread+0x5a8>
    853c:	f94003e0 	ldr	x0, [sp]
    8540:	f1000794 	subs	x20, x28, #0x1
    8544:	aa1803e1 	mov	x1, x24
    8548:	f9001ff4 	str	x20, [sp, #56]
    854c:	da1f0019 	sbc	x25, x0, xzr
    8550:	52800020 	mov	w0, #0x1                   	// #1
    8554:	f90003f9 	str	x25, [sp]
    8558:	aa1403fc 	mov	x28, x20
    855c:	a9076ff4 	stp	x20, x27, [sp, #112]
    8560:	97fff209 	bl	4d84 <fwp_data.part.0.constprop.0>
    8564:	aa0003fb 	mov	x27, x0
    8568:	f949db41 	ldr	x1, [x26, #5040]
    856c:	f949ef40 	ldr	x0, [x26, #5080]
    8570:	cb010361 	sub	x1, x27, x1
    8574:	eb00403f 	cmp	x1, x0, lsl #16
    8578:	54fffdc2 	b.cs	8530 <fwp_main_thread+0x280>  // b.hs, b.nlast
    857c:	d350fc22 	lsr	x2, x1, #16
    8580:	f949ff46 	ldr	x6, [x26, #5112]
    8584:	8b020842 	add	x2, x2, x2, lsl #2
    8588:	d37df042 	lsl	x2, x2, #3
    858c:	8b0200c5 	add	x5, x6, x2
    8590:	f94010a0 	ldr	x0, [x5, #32]
    8594:	b4fffce0 	cbz	x0, 8530 <fwp_main_thread+0x280>
    8598:	386268c2 	ldrb	w2, [x6, x2]
    859c:	7100085f 	cmp	w2, #0x2
    85a0:	54fffac1 	b.ne	84f8 <fwp_main_thread+0x248>  // b.any
    85a4:	72003c3f 	tst	w1, #0xffff
    85a8:	54fffc41 	b.ne	8530 <fwp_main_thread+0x280>  // b.any
    85ac:	17ffffdc 	b	851c <fwp_main_thread+0x26c>
    85b0:	97fff058 	bl	4710 <fwp_now_ns>
    85b4:	f9403281 	ldr	x1, [x20, #96]
    85b8:	eb01001f 	cmp	x0, x1
    85bc:	540000ab 	b.lt	85d0 <fwp_main_thread+0x320>  // b.tstop
    85c0:	39414280 	ldrb	w0, [x20, #80]
    85c4:	37000060 	tbnz	w0, #0, 85d0 <fwp_main_thread+0x320>
    85c8:	aa1403e0 	mov	x0, x20
    85cc:	97ffeba9 	bl	3470 <fwp_cancel_tree.part.0>
    85d0:	39414680 	ldrb	w0, [x20, #81]
    85d4:	f9400ad3 	ldr	x19, [x22, #16]
    85d8:	39414a62 	ldrb	w2, [x19, #82]
    85dc:	3707f0e0 	tbnz	w0, #0, 83f8 <fwp_main_thread+0x148>
    85e0:	f9403281 	ldr	x1, [x20, #96]
    85e4:	370001c2 	tbnz	w2, #0, 861c <fwp_main_thread+0x36c>
    85e8:	f9403260 	ldr	x0, [x19, #96]
    85ec:	b4000180 	cbz	x0, 861c <fwp_main_thread+0x36c>
    85f0:	b4000061 	cbz	x1, 85fc <fwp_main_thread+0x34c>
    85f4:	eb01001f 	cmp	x0, x1
    85f8:	9a81d000 	csel	x0, x0, x1, le
    85fc:	f9402281 	ldr	x1, [x20, #64]
    8600:	a911fe77 	stp	x23, xzr, [x19, #280]
    8604:	f9009661 	str	x1, [x19, #296]
    8608:	b4003541 	cbz	x1, 8cb0 <fwp_main_thread+0xa00>
    860c:	f9009033 	str	x19, [x1, #288]
    8610:	aa0003e1 	mov	x1, x0
    8614:	f9002293 	str	x19, [x20, #64]
    8618:	17ffff83 	b	8424 <fwp_main_thread+0x174>
    861c:	f9402280 	ldr	x0, [x20, #64]
    8620:	17ffff7b 	b	840c <fwp_main_thread+0x15c>
    8624:	a911fe77 	stp	x23, xzr, [x19, #280]
    8628:	f9009660 	str	x0, [x19, #296]
    862c:	b4000040 	cbz	x0, 8634 <fwp_main_thread+0x384>
    8630:	f9009013 	str	x19, [x0, #288]
    8634:	f9002293 	str	x19, [x20, #64]
    8638:	17ffff82 	b	8440 <fwp_main_thread+0x190>
    863c:	f9000040 	str	x0, [x2]
    8640:	17ffff88 	b	8460 <fwp_main_thread+0x1b0>
    8644:	39014a99 	strb	w25, [x20, #82]
    8648:	a9556bf9 	ldp	x25, x26, [sp, #336]
    864c:	9100c2b3 	add	x19, x21, #0x30
    8650:	f9416e60 	ldr	x0, [x19, #728]
    8654:	b5000060 	cbnz	x0, 8660 <fwp_main_thread+0x3b0>
    8658:	f9417660 	ldr	x0, [x19, #744]
    865c:	b4003480 	cbz	x0, 8cec <fwp_main_thread+0xa3c>
    8660:	9100c2a0 	add	x0, x21, #0x30
    8664:	f9400800 	ldr	x0, [x0, #16]
    8668:	9100c2a1 	add	x1, x21, #0x30
    866c:	f9418426 	ldr	x6, [x1, #776]
    8670:	b903003f 	str	wzr, [x1, #768]
    8674:	eb0000df 	cmp	x6, x0
    8678:	54003ca1 	b.ne	8e0c <fwp_main_thread+0xb5c>  // b.any
    867c:	b40003c0 	cbz	x0, 86f4 <fwp_main_thread+0x444>
    8680:	f9415825 	ldr	x5, [x1, #688]
    8684:	52800021 	mov	w1, #0x1                   	// #1
    8688:	39014801 	strb	w1, [x0, #82]
    868c:	b4000345 	cbz	x5, 86f4 <fwp_main_thread+0x444>
    8690:	394140a0 	ldrb	w0, [x5, #80]
    8694:	37000060 	tbnz	w0, #0, 86a0 <fwp_main_thread+0x3f0>
    8698:	aa0503e0 	mov	x0, x5
    869c:	97ffeb75 	bl	3470 <fwp_cancel_tree.part.0>
    86a0:	f9409ca5 	ldr	x5, [x5, #312]
    86a4:	b5ffff65 	cbnz	x5, 8690 <fwp_main_thread+0x3e0>
    86a8:	9100c2b3 	add	x19, x21, #0x30
    86ac:	52800034 	mov	w20, #0x1                   	// #1
    86b0:	f94028c0 	ldr	x0, [x6, #80]
    86b4:	f2001c1f 	tst	x0, #0xff000000ff
    86b8:	540000e1 	b.ne	86d4 <fwp_main_thread+0x424>  // b.any
    86bc:	f9401660 	ldr	x0, [x19, #40]
    86c0:	390150d4 	strb	w20, [x6, #84]
    86c4:	f90080df 	str	xzr, [x6, #256]
    86c8:	b4000120 	cbz	x0, 86ec <fwp_main_thread+0x43c>
    86cc:	f9008006 	str	x6, [x0, #256]
    86d0:	f9001666 	str	x6, [x19, #40]
    86d4:	97fff86b 	bl	6880 <fwp_block>
    86d8:	97fff7f2 	bl	66a0 <fwp_free_zombie>
    86dc:	f9415a60 	ldr	x0, [x19, #688]
    86e0:	b40000a0 	cbz	x0, 86f4 <fwp_main_thread+0x444>
    86e4:	f9418666 	ldr	x6, [x19, #776]
    86e8:	17fffff2 	b	86b0 <fwp_main_thread+0x400>
    86ec:	f9001a66 	str	x6, [x19, #48]
    86f0:	17fffff8 	b	86d0 <fwp_main_thread+0x420>
    86f4:	9100c2b4 	add	x20, x21, #0x30
    86f8:	97fff7ea 	bl	66a0 <fwp_free_zombie>
    86fc:	f9401a80 	ldr	x0, [x20, #48]
    8700:	b5003860 	cbnz	x0, 8e0c <fwp_main_thread+0xb5c>
    8704:	f9404680 	ldr	x0, [x20, #136]
    8708:	b5003820 	cbnz	x0, 8e0c <fwp_main_thread+0xb5c>
    870c:	b940aa93 	ldr	w19, [x20, #168]
    8710:	340001f3 	cbz	w19, 874c <fwp_main_thread+0x49c>
    8714:	93407e76 	sxtw	x22, w19
    8718:	51000673 	sub	w19, w19, #0x1
    871c:	d1000ad6 	sub	x22, x22, #0x2
    8720:	9102c297 	add	x23, x20, #0xb0
    8724:	cb3342d6 	sub	x22, x22, w19, uxtw
    8728:	93407e73 	sxtw	x19, w19
    872c:	d503201f 	nop
    8730:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8734:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8738:	b900aa93 	str	w19, [x20, #168]
    873c:	d1000673 	sub	x19, x19, #0x1
    8740:	97ffe898 	bl	29a0 <munmap@plt>
    8744:	eb1302df 	cmp	x22, x19
    8748:	54ffff41 	b.ne	8730 <fwp_main_thread+0x480>  // b.any
    874c:	900000d3 	adrp	x19, 20000 <__data_start>
    8750:	b9401260 	ldr	w0, [x19, #16]
    8754:	37f80040 	tbnz	w0, #31, 875c <fwp_main_thread+0x4ac>
    8758:	97ffe84e 	bl	2890 <close@plt>
    875c:	9100c2b4 	add	x20, x21, #0x30
    8760:	12800000 	mov	w0, #0xffffffff            	// #-1
    8764:	b9001260 	str	w0, [x19, #16]
    8768:	f9418e80 	ldr	x0, [x20, #792]
    876c:	f9418a81 	ldr	x1, [x20, #784]
    8770:	b40001c0 	cbz	x0, 87a8 <fwp_main_thread+0x4f8>
    8774:	d2800013 	mov	x19, #0x0                   	// #0
    8778:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    877c:	b40000e0 	cbz	x0, 8798 <fwp_main_thread+0x4e8>
    8780:	f9400001 	ldr	x1, [x0]
    8784:	b5003441 	cbnz	x1, 8e0c <fwp_main_thread+0xb5c>
    8788:	f9400401 	ldr	x1, [x0, #8]
    878c:	b5003401 	cbnz	x1, 8e0c <fwp_main_thread+0xb5c>
    8790:	97ffee7c 	bl	4180 <fwp_mem_free>
    8794:	f9418a81 	ldr	x1, [x20, #784]
    8798:	91000673 	add	x19, x19, #0x1
    879c:	f9418e80 	ldr	x0, [x20, #792]
    87a0:	eb00027f 	cmp	x19, x0
    87a4:	54fffea3 	b.cc	8778 <fwp_main_thread+0x4c8>  // b.lo, b.ul, b.last
    87a8:	aa0103e0 	mov	x0, x1
    87ac:	97ffee75 	bl	4180 <fwp_mem_free>
    87b0:	9100c2a0 	add	x0, x21, #0x30
    87b4:	f9418413 	ldr	x19, [x0, #776]
    87b8:	f901881f 	str	xzr, [x0, #784]
    87bc:	f9018c1f 	str	xzr, [x0, #792]
    87c0:	b40001f3 	cbz	x19, 87fc <fwp_main_thread+0x54c>
    87c4:	f9401661 	ldr	x1, [x19, #40]
    87c8:	b5003221 	cbnz	x1, 8e0c <fwp_main_thread+0xb5c>
    87cc:	f9405661 	ldr	x1, [x19, #168]
    87d0:	b50031e1 	cbnz	x1, 8e0c <fwp_main_thread+0xb5c>
    87d4:	f9416c01 	ldr	x1, [x0, #728]
    87d8:	b50031a1 	cbnz	x1, 8e0c <fwp_main_thread+0xb5c>
    87dc:	f9417400 	ldr	x0, [x0, #744]
    87e0:	b5003160 	cbnz	x0, 8e0c <fwp_main_thread+0xb5c>
    87e4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    87e8:	90000140 	adrp	x0, 30000 <alt.5+0xfcb0>
    87ec:	910d4000 	add	x0, x0, #0x350
    87f0:	97ffe818 	bl	2850 <memset@plt>
    87f4:	aa1303e0 	mov	x0, x19
    87f8:	97ffee62 	bl	4180 <fwp_mem_free>
    87fc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8800:	f947ec00 	ldr	x0, [x0, #4056]
    8804:	9100c2b5 	add	x21, x21, #0x30
    8808:	f9400000 	ldr	x0, [x0]
    880c:	f9000abf 	str	xzr, [x21, #16]
    8810:	f90186bf 	str	xzr, [x21, #776]
    8814:	97ffe867 	bl	29b0 <fflush@plt>
    8818:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    881c:	f947f400 	ldr	x0, [x0, #4072]
    8820:	f94087e2 	ldr	x2, [sp, #264]
    8824:	f9400001 	ldr	x1, [x0]
    8828:	eb010042 	subs	x2, x2, x1
    882c:	d2800001 	mov	x1, #0x0                   	// #0
    8830:	54002c41 	b.ne	8db8 <fwp_main_thread+0xb08>  // b.any
    8834:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8838:	d2800000 	mov	x0, #0x0                   	// #0
    883c:	a95253f3 	ldp	x19, x20, [sp, #288]
    8840:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8844:	a95463f7 	ldp	x23, x24, [sp, #320]
    8848:	9105c3ff 	add	sp, sp, #0x170
    884c:	d65f03c0 	ret
    8850:	f90046c0 	str	x0, [x22, #136]
    8854:	17ffff0d 	b	8488 <fwp_main_thread+0x1d8>
    8858:	9100c2a2 	add	x2, x21, #0x30
    885c:	f9001bff 	str	xzr, [sp, #48]
    8860:	f9416040 	ldr	x0, [x2, #704]
    8864:	eb16001f 	cmp	x0, x22
    8868:	54002d61 	b.ne	8e14 <fwp_main_thread+0xb64>  // b.any
    886c:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0xac0>
    8870:	910143e1 	add	x1, sp, #0x50
    8874:	f9400fe3 	ldr	x3, [sp, #24]
    8878:	f9016043 	str	x3, [x2, #704]
    887c:	3dc05800 	ldr	q0, [x0, #352]
    8880:	52800020 	mov	w0, #0x1                   	// #1
    8884:	3d8017e0 	str	q0, [sp, #80]
    8888:	97fff13f 	bl	4d84 <fwp_data.part.0.constprop.0>
    888c:	9114c263 	add	x3, x19, #0x530
    8890:	aa0003f4 	mov	x20, x0
    8894:	f949d861 	ldr	x1, [x3, #5040]
    8898:	f949ec60 	ldr	x0, [x3, #5080]
    889c:	cb010281 	sub	x1, x20, x1
    88a0:	eb00403f 	cmp	x1, x0, lsl #16
    88a4:	54000322 	b.cs	8908 <fwp_main_thread+0x658>  // b.hs, b.nlast
    88a8:	d350fc22 	lsr	x2, x1, #16
    88ac:	f949fc63 	ldr	x3, [x3, #5112]
    88b0:	8b020842 	add	x2, x2, x2, lsl #2
    88b4:	d37df042 	lsl	x2, x2, #3
    88b8:	8b020060 	add	x0, x3, x2
    88bc:	f9401016 	ldr	x22, [x0, #32]
    88c0:	b4000256 	cbz	x22, 8908 <fwp_main_thread+0x658>
    88c4:	38626862 	ldrb	w2, [x3, x2]
    88c8:	7100085f 	cmp	w2, #0x2
    88cc:	54001f80 	b.eq	8cbc <fwp_main_thread+0xa0c>  // b.none
    88d0:	7100045f 	cmp	w2, #0x1
    88d4:	540001a1 	b.ne	8908 <fwp_main_thread+0x658>  // b.any
    88d8:	29430002 	ldp	w2, w0, [x0, #24]
    88dc:	92403c21 	and	x1, x1, #0xffff
    88e0:	9b027c21 	mul	x1, x1, x2
    88e4:	d360fc21 	lsr	x1, x1, #32
    88e8:	eb00003f 	cmp	x1, x0
    88ec:	540000e2 	b.cs	8908 <fwp_main_thread+0x658>  // b.hs, b.nlast
    88f0:	8b0102d6 	add	x22, x22, x1
    88f4:	394002c0 	ldrb	w0, [x22]
    88f8:	7103fc1f 	cmp	w0, #0xff
    88fc:	54002100 	b.eq	8d1c <fwp_main_thread+0xa6c>  // b.none
    8900:	52800020 	mov	w0, #0x1                   	// #1
    8904:	390002c0 	strb	w0, [x22]
    8908:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    890c:	aa1803e1 	mov	x1, x24
    8910:	52800020 	mov	w0, #0x1                   	// #1
    8914:	a90753e2 	stp	x2, x20, [sp, #112]
    8918:	97fff11b 	bl	4d84 <fwp_data.part.0.constprop.0>
    891c:	9114c263 	add	x3, x19, #0x530
    8920:	aa0003f4 	mov	x20, x0
    8924:	f949d861 	ldr	x1, [x3, #5040]
    8928:	f949ec60 	ldr	x0, [x3, #5080]
    892c:	cb010281 	sub	x1, x20, x1
    8930:	eb00403f 	cmp	x1, x0, lsl #16
    8934:	54000322 	b.cs	8998 <fwp_main_thread+0x6e8>  // b.hs, b.nlast
    8938:	d350fc22 	lsr	x2, x1, #16
    893c:	f949fc63 	ldr	x3, [x3, #5112]
    8940:	8b020842 	add	x2, x2, x2, lsl #2
    8944:	d37df042 	lsl	x2, x2, #3
    8948:	8b020060 	add	x0, x3, x2
    894c:	f9401016 	ldr	x22, [x0, #32]
    8950:	b4000256 	cbz	x22, 8998 <fwp_main_thread+0x6e8>
    8954:	38626862 	ldrb	w2, [x3, x2]
    8958:	7100085f 	cmp	w2, #0x2
    895c:	54001b60 	b.eq	8cc8 <fwp_main_thread+0xa18>  // b.none
    8960:	7100045f 	cmp	w2, #0x1
    8964:	540001a1 	b.ne	8998 <fwp_main_thread+0x6e8>  // b.any
    8968:	29430002 	ldp	w2, w0, [x0, #24]
    896c:	92403c21 	and	x1, x1, #0xffff
    8970:	9b027c21 	mul	x1, x1, x2
    8974:	d360fc21 	lsr	x1, x1, #32
    8978:	eb00003f 	cmp	x1, x0
    897c:	540000e2 	b.cs	8998 <fwp_main_thread+0x6e8>  // b.hs, b.nlast
    8980:	8b0102d6 	add	x22, x22, x1
    8984:	394002c0 	ldrb	w0, [x22]
    8988:	7103fc1f 	cmp	w0, #0xff
    898c:	54001ce0 	b.eq	8d28 <fwp_main_thread+0xa78>  // b.none
    8990:	52800020 	mov	w0, #0x1                   	// #1
    8994:	390002c0 	strb	w0, [x22]
    8998:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    899c:	910183e1 	add	x1, sp, #0x60
    89a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    89a4:	52800020 	mov	w0, #0x1                   	// #1
    89a8:	a90653e2 	stp	x2, x20, [sp, #96]
    89ac:	97fff0f6 	bl	4d84 <fwp_data.part.0.constprop.0>
    89b0:	9114c263 	add	x3, x19, #0x530
    89b4:	aa0003f9 	mov	x25, x0
    89b8:	f949d861 	ldr	x1, [x3, #5040]
    89bc:	f949ec60 	ldr	x0, [x3, #5080]
    89c0:	cb010321 	sub	x1, x25, x1
    89c4:	eb00403f 	cmp	x1, x0, lsl #16
    89c8:	54000322 	b.cs	8a2c <fwp_main_thread+0x77c>  // b.hs, b.nlast
    89cc:	d350fc22 	lsr	x2, x1, #16
    89d0:	f949fc63 	ldr	x3, [x3, #5112]
    89d4:	8b020842 	add	x2, x2, x2, lsl #2
    89d8:	d37df042 	lsl	x2, x2, #3
    89dc:	8b020060 	add	x0, x3, x2
    89e0:	f9401014 	ldr	x20, [x0, #32]
    89e4:	b4000254 	cbz	x20, 8a2c <fwp_main_thread+0x77c>
    89e8:	38626862 	ldrb	w2, [x3, x2]
    89ec:	7100085f 	cmp	w2, #0x2
    89f0:	54001720 	b.eq	8cd4 <fwp_main_thread+0xa24>  // b.none
    89f4:	7100045f 	cmp	w2, #0x1
    89f8:	540001a1 	b.ne	8a2c <fwp_main_thread+0x77c>  // b.any
    89fc:	29430002 	ldp	w2, w0, [x0, #24]
    8a00:	92403c21 	and	x1, x1, #0xffff
    8a04:	9b027c21 	mul	x1, x1, x2
    8a08:	d360fc21 	lsr	x1, x1, #32
    8a0c:	eb00003f 	cmp	x1, x0
    8a10:	540000e2 	b.cs	8a2c <fwp_main_thread+0x77c>  // b.hs, b.nlast
    8a14:	8b010294 	add	x20, x20, x1
    8a18:	39400280 	ldrb	w0, [x20]
    8a1c:	7103fc1f 	cmp	w0, #0xff
    8a20:	54001780 	b.eq	8d10 <fwp_main_thread+0xa60>  // b.none
    8a24:	52800020 	mov	w0, #0x1                   	// #1
    8a28:	39000280 	strb	w0, [x20]
    8a2c:	aa1b03f8 	mov	x24, x27
    8a30:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12c30>
    8a34:	b400121b 	cbz	x27, 8c74 <fwp_main_thread+0x9c4>
    8a38:	910aa000 	add	x0, x0, #0x2a8
    8a3c:	b0000016 	adrp	x22, 9000 <__divti3+0x1e0>
    8a40:	91014014 	add	x20, x0, #0x50
    8a44:	913ae2d6 	add	x22, x22, #0xeb8
    8a48:	9114c27a 	add	x26, x19, #0x530
    8a4c:	f949db41 	ldr	x1, [x26, #5040]
    8a50:	f949ef40 	ldr	x0, [x26, #5080]
    8a54:	cb010321 	sub	x1, x25, x1
    8a58:	eb00403f 	cmp	x1, x0, lsl #16
    8a5c:	54000342 	b.cs	8ac4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    8a60:	d350fc22 	lsr	x2, x1, #16
    8a64:	f949ff45 	ldr	x5, [x26, #5112]
    8a68:	8b020842 	add	x2, x2, x2, lsl #2
    8a6c:	d37df042 	lsl	x2, x2, #3
    8a70:	8b0200a3 	add	x3, x5, x2
    8a74:	f9401060 	ldr	x0, [x3, #32]
    8a78:	b4000260 	cbz	x0, 8ac4 <fwp_main_thread+0x814>
    8a7c:	386268a2 	ldrb	w2, [x5, x2]
    8a80:	7100085f 	cmp	w2, #0x2
    8a84:	540012e0 	b.eq	8ce0 <fwp_main_thread+0xa30>  // b.none
    8a88:	7100045f 	cmp	w2, #0x1
    8a8c:	540001c1 	b.ne	8ac4 <fwp_main_thread+0x814>  // b.any
    8a90:	29430865 	ldp	w5, w2, [x3, #24]
    8a94:	92403c21 	and	x1, x1, #0xffff
    8a98:	9b057c21 	mul	x1, x1, x5
    8a9c:	d360fc21 	lsr	x1, x1, #32
    8aa0:	eb02003f 	cmp	x1, x2
    8aa4:	54000102 	b.cs	8ac4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    8aa8:	8b010000 	add	x0, x0, x1
    8aac:	39400001 	ldrb	w1, [x0]
    8ab0:	340000a1 	cbz	w1, 8ac4 <fwp_main_thread+0x814>
    8ab4:	7103f43f 	cmp	w1, #0xfd
    8ab8:	540013e8 	b.hi	8d34 <fwp_main_thread+0xa84>  // b.pmore
    8abc:	11000421 	add	w1, w1, #0x1
    8ac0:	39000001 	strb	w1, [x0]
    8ac4:	aa1403e2 	mov	x2, x20
    8ac8:	aa1903e1 	mov	x1, x25
    8acc:	aa1703e0 	mov	x0, x23
    8ad0:	52800023 	mov	w3, #0x1                   	// #1
    8ad4:	a9037fff 	stp	xzr, xzr, [sp, #48]
    8ad8:	f90023ff 	str	xzr, [sp, #64]
    8adc:	97fff9fa 	bl	72c4 <fwp_write>
    8ae0:	a9430bfc 	ldp	x28, x2, [sp, #48]
    8ae4:	f100039f 	cmp	x28, #0x0
    8ae8:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    8aec:	b100285f 	cmn	x2, #0xa
    8af0:	54001268 	b.hi	8d3c <fwp_main_thread+0xa8c>  // b.pmore
    8af4:	91002440 	add	x0, x2, #0x9
    8af8:	52800021 	mov	w1, #0x1                   	// #1
    8afc:	f90007e2 	str	x2, [sp, #8]
    8b00:	97fff05c 	bl	4c70 <fwp_heap_alloc>
    8b04:	aa1c03e1 	mov	x1, x28
    8b08:	aa0003fc 	mov	x28, x0
    8b0c:	f94007e2 	ldr	x2, [sp, #8]
    8b10:	f90003e0 	str	x0, [sp]
    8b14:	f8008782 	str	x2, [x28], #8
    8b18:	aa1c03e0 	mov	x0, x28
    8b1c:	97ffe6ed 	bl	26d0 <memcpy@plt>
    8b20:	a9400be0 	ldp	x0, x2, [sp]
    8b24:	8b020002 	add	x2, x0, x2
    8b28:	3900205f 	strb	wzr, [x2, #8]
    8b2c:	f9401be0 	ldr	x0, [sp, #48]
    8b30:	97ffe784 	bl	2940 <free@plt>
    8b34:	9114c260 	add	x0, x19, #0x530
    8b38:	f94003e3 	ldr	x3, [sp]
    8b3c:	f949d801 	ldr	x1, [x0, #5040]
    8b40:	f949ec02 	ldr	x2, [x0, #5080]
    8b44:	cb010061 	sub	x1, x3, x1
    8b48:	eb02403f 	cmp	x1, x2, lsl #16
    8b4c:	54000322 	b.cs	8bb0 <fwp_main_thread+0x900>  // b.hs, b.nlast
    8b50:	d350fc22 	lsr	x2, x1, #16
    8b54:	d2800503 	mov	x3, #0x28                  	// #40
    8b58:	f949fc05 	ldr	x5, [x0, #5112]
    8b5c:	9b037c42 	mul	x2, x2, x3
    8b60:	8b0200a3 	add	x3, x5, x2
    8b64:	f9401060 	ldr	x0, [x3, #32]
    8b68:	b4000240 	cbz	x0, 8bb0 <fwp_main_thread+0x900>
    8b6c:	386268a2 	ldrb	w2, [x5, x2]
    8b70:	7100085f 	cmp	w2, #0x2
    8b74:	54000f60 	b.eq	8d60 <fwp_main_thread+0xab0>  // b.none
    8b78:	7100045f 	cmp	w2, #0x1
    8b7c:	540001a1 	b.ne	8bb0 <fwp_main_thread+0x900>  // b.any
    8b80:	29430865 	ldp	w5, w2, [x3, #24]
    8b84:	92403c21 	and	x1, x1, #0xffff
    8b88:	9b057c21 	mul	x1, x1, x5
    8b8c:	d360fc21 	lsr	x1, x1, #32
    8b90:	eb02003f 	cmp	x1, x2
    8b94:	540000e2 	b.cs	8bb0 <fwp_main_thread+0x900>  // b.hs, b.nlast
    8b98:	8b010000 	add	x0, x0, x1
    8b9c:	39400001 	ldrb	w1, [x0]
    8ba0:	7103fc3f 	cmp	w1, #0xff
    8ba4:	54000e40 	b.eq	8d6c <fwp_main_thread+0xabc>  // b.none
    8ba8:	52800021 	mov	w1, #0x1                   	// #1
    8bac:	39000001 	strb	w1, [x0]
    8bb0:	aa1903e0 	mov	x0, x25
    8bb4:	97fff43b 	bl	5ca0 <fwp_drop0>
    8bb8:	f94003e1 	ldr	x1, [sp]
    8bbc:	9100c2a3 	add	x3, x21, #0x30
    8bc0:	aa1c03e0 	mov	x0, x28
    8bc4:	aa0303fc 	mov	x28, x3
    8bc8:	f9400022 	ldr	x2, [x1]
    8bcc:	d2800021 	mov	x1, #0x1                   	// #1
    8bd0:	f9400463 	ldr	x3, [x3, #8]
    8bd4:	97ffe76b 	bl	2980 <fwrite@plt>
    8bd8:	f9400781 	ldr	x1, [x28, #8]
    8bdc:	52800140 	mov	w0, #0xa                   	// #10
    8be0:	97ffe6f0 	bl	27a0 <fputc@plt>
    8be4:	9114c262 	add	x2, x19, #0x530
    8be8:	f94003e3 	ldr	x3, [sp]
    8bec:	f949d841 	ldr	x1, [x2, #5040]
    8bf0:	f949ec40 	ldr	x0, [x2, #5080]
    8bf4:	cb010061 	sub	x1, x3, x1
    8bf8:	eb00403f 	cmp	x1, x0, lsl #16
    8bfc:	54000382 	b.cs	8c6c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8c00:	d350fc20 	lsr	x0, x1, #16
    8c04:	d2800505 	mov	x5, #0x28                  	// #40
    8c08:	f949fc43 	ldr	x3, [x2, #5112]
    8c0c:	9b057c00 	mul	x0, x0, x5
    8c10:	8b000062 	add	x2, x3, x0
    8c14:	f940105c 	ldr	x28, [x2, #32]
    8c18:	b40002bc 	cbz	x28, 8c6c <fwp_main_thread+0x9bc>
    8c1c:	38606860 	ldrb	w0, [x3, x0]
    8c20:	7100081f 	cmp	w0, #0x2
    8c24:	54000980 	b.eq	8d54 <fwp_main_thread+0xaa4>  // b.none
    8c28:	7100041f 	cmp	w0, #0x1
    8c2c:	54000201 	b.ne	8c6c <fwp_main_thread+0x9bc>  // b.any
    8c30:	29430043 	ldp	w3, w0, [x2, #24]
    8c34:	92403c21 	and	x1, x1, #0xffff
    8c38:	9b037c21 	mul	x1, x1, x3
    8c3c:	d360fc21 	lsr	x1, x1, #32
    8c40:	eb00003f 	cmp	x1, x0
    8c44:	54000142 	b.cs	8c6c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8c48:	8b01039c 	add	x28, x28, x1
    8c4c:	39400380 	ldrb	w0, [x28]
    8c50:	340000e0 	cbz	w0, 8c6c <fwp_main_thread+0x9bc>
    8c54:	7100041f 	cmp	w0, #0x1
    8c58:	54000780 	b.eq	8d48 <fwp_main_thread+0xa98>  // b.none
    8c5c:	7103fc1f 	cmp	w0, #0xff
    8c60:	540008e0 	b.eq	8d7c <fwp_main_thread+0xacc>  // b.none
    8c64:	51000400 	sub	w0, w0, #0x1
    8c68:	39000380 	strb	w0, [x28]
    8c6c:	f9400b18 	ldr	x24, [x24, #16]
    8c70:	b5ffeef8 	cbnz	x24, 8a4c <fwp_main_thread+0x79c>
    8c74:	aa1903e0 	mov	x0, x25
    8c78:	97fff40a 	bl	5ca0 <fwp_drop0>
    8c7c:	aa1b03e0 	mov	x0, x27
    8c80:	97fff408 	bl	5ca0 <fwp_drop0>
    8c84:	9100c2a0 	add	x0, x21, #0x30
    8c88:	52800021 	mov	w1, #0x1                   	// #1
    8c8c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8c90:	a95673fb 	ldp	x27, x28, [sp, #352]
    8c94:	b902f401 	str	w1, [x0, #756]
    8c98:	f9017c1f 	str	xzr, [x0, #760]
    8c9c:	17fffdc8 	b	83bc <fwp_main_thread+0x10c>
    8ca0:	f90007e0 	str	x0, [sp, #8]
    8ca4:	97ffec9b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8ca8:	f94007e0 	ldr	x0, [sp, #8]
    8cac:	17fffe1f 	b	8528 <fwp_main_thread+0x278>
    8cb0:	aa0003e1 	mov	x1, x0
    8cb4:	f9002293 	str	x19, [x20, #64]
    8cb8:	17fffddb 	b	8424 <fwp_main_thread+0x174>
    8cbc:	72003c3f 	tst	w1, #0xffff
    8cc0:	54ffe241 	b.ne	8908 <fwp_main_thread+0x658>  // b.any
    8cc4:	17ffff0c 	b	88f4 <fwp_main_thread+0x644>
    8cc8:	72003c3f 	tst	w1, #0xffff
    8ccc:	54ffe661 	b.ne	8998 <fwp_main_thread+0x6e8>  // b.any
    8cd0:	17ffff2d 	b	8984 <fwp_main_thread+0x6d4>
    8cd4:	72003c3f 	tst	w1, #0xffff
    8cd8:	54ffeaa1 	b.ne	8a2c <fwp_main_thread+0x77c>  // b.any
    8cdc:	17ffff4f 	b	8a18 <fwp_main_thread+0x768>
    8ce0:	72003c3f 	tst	w1, #0xffff
    8ce4:	54ffef01 	b.ne	8ac4 <fwp_main_thread+0x814>  // b.any
    8ce8:	17ffff71 	b	8aac <fwp_main_thread+0x7fc>
    8cec:	f9416a60 	ldr	x0, [x19, #720]
    8cf0:	97ffed24 	bl	4180 <fwp_mem_free>
    8cf4:	f9016a7f 	str	xzr, [x19, #720]
    8cf8:	f9400a60 	ldr	x0, [x19, #16]
    8cfc:	f901727f 	str	xzr, [x19, #736]
    8d00:	b4ffcb40 	cbz	x0, 8668 <fwp_main_thread+0x3b8>
    8d04:	f900541f 	str	xzr, [x0, #168]
    8d08:	f9005c1f 	str	xzr, [x0, #184]
    8d0c:	17fffe57 	b	8668 <fwp_main_thread+0x3b8>
    8d10:	aa1403e0 	mov	x0, x20
    8d14:	97ffec7f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8d18:	17ffff43 	b	8a24 <fwp_main_thread+0x774>
    8d1c:	aa1603e0 	mov	x0, x22
    8d20:	97ffec7c 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8d24:	17fffef7 	b	8900 <fwp_main_thread+0x650>
    8d28:	aa1603e0 	mov	x0, x22
    8d2c:	97ffec79 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8d30:	17ffff18 	b	8990 <fwp_main_thread+0x6e0>
    8d34:	97ffed8c 	bl	4364 <fwp_rc_wide_dup>
    8d38:	17ffff63 	b	8ac4 <fwp_main_thread+0x814>
    8d3c:	b0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    8d40:	91294000 	add	x0, x0, #0xa50
    8d44:	97ffec53 	bl	3e90 <fwp_trap>
    8d48:	f94003e0 	ldr	x0, [sp]
    8d4c:	97fff2a2 	bl	57d4 <fwp_rc_free_arr>
    8d50:	17ffffc7 	b	8c6c <fwp_main_thread+0x9bc>
    8d54:	72003c3f 	tst	w1, #0xffff
    8d58:	54fff8a1 	b.ne	8c6c <fwp_main_thread+0x9bc>  // b.any
    8d5c:	17ffffbc 	b	8c4c <fwp_main_thread+0x99c>
    8d60:	72003c3f 	tst	w1, #0xffff
    8d64:	54fff261 	b.ne	8bb0 <fwp_main_thread+0x900>  // b.any
    8d68:	17ffff8d 	b	8b9c <fwp_main_thread+0x8ec>
    8d6c:	f90007e0 	str	x0, [sp, #8]
    8d70:	97ffec68 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8d74:	f94007e0 	ldr	x0, [sp, #8]
    8d78:	17ffff8c 	b	8ba8 <fwp_main_thread+0x8f8>
    8d7c:	ca5c4780 	eor	x0, x28, x28, lsr #17
    8d80:	9114c262 	add	x2, x19, #0x530
    8d84:	ca402400 	eor	x0, x0, x0, lsr #9
    8d88:	92401c00 	and	x0, x0, #0xff
    8d8c:	910a2401 	add	x1, x0, #0x289
    8d90:	8b000c40 	add	x0, x2, x0, lsl #3
    8d94:	8b010c41 	add	x1, x2, x1, lsl #3
    8d98:	f94a2400 	ldr	x0, [x0, #5192]
    8d9c:	b40002c0 	cbz	x0, 8df4 <fwp_main_thread+0xb44>
    8da0:	f9400002 	ldr	x2, [x0]
    8da4:	eb02039f 	cmp	x28, x2
    8da8:	540000e0 	b.eq	8dc4 <fwp_main_thread+0xb14>  // b.none
    8dac:	91004001 	add	x1, x0, #0x10
    8db0:	f9400800 	ldr	x0, [x0, #16]
    8db4:	17fffffa 	b	8d9c <fwp_main_thread+0xaec>
    8db8:	a9156bf9 	stp	x25, x26, [sp, #336]
    8dbc:	a91673fb 	stp	x27, x28, [sp, #352]
    8dc0:	97ffe6b0 	bl	2880 <__stack_chk_fail@plt>
    8dc4:	f9400021 	ldr	x1, [x1]
    8dc8:	f9400420 	ldr	x0, [x1, #8]
    8dcc:	d1000400 	sub	x0, x0, #0x1
    8dd0:	f9000420 	str	x0, [x1, #8]
    8dd4:	f103f81f 	cmp	x0, #0xfe
    8dd8:	54fff4a1 	b.ne	8c6c <fwp_main_thread+0x9bc>  // b.any
    8ddc:	39400380 	ldrb	w0, [x28]
    8de0:	7103fc1f 	cmp	w0, #0xff
    8de4:	540000e0 	b.eq	8e00 <fwp_main_thread+0xb50>  // b.none
    8de8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8dec:	39000380 	strb	w0, [x28]
    8df0:	17ffff9f 	b	8c6c <fwp_main_thread+0x9bc>
    8df4:	b0000000 	adrp	x0, 9000 <__divti3+0x1e0>
    8df8:	911a0000 	add	x0, x0, #0x680
    8dfc:	97ffec25 	bl	3e90 <fwp_trap>
    8e00:	aa1c03e0 	mov	x0, x28
    8e04:	97ffec43 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8e08:	17fffff8 	b	8de8 <fwp_main_thread+0xb38>
    8e0c:	a9156bf9 	stp	x25, x26, [sp, #336]
    8e10:	a91673fb 	stp	x27, x28, [sp, #352]
    8e14:	97ffe6af 	bl	28d0 <abort@plt>
    8e18:	d503201f 	nop
    8e1c:	d503201f 	nop

0000000000008e20 <__divti3>:
    8e20:	d503245f 	bti	c
    8e24:	d2800004 	mov	x4, #0x0                   	// #0
    8e28:	b7f80721 	tbnz	x1, #63, 8f0c <__divti3+0xec>
    8e2c:	b6f80083 	tbz	x3, #63, 8e3c <__divti3+0x1c>
    8e30:	eb0203e2 	negs	x2, x2
    8e34:	aa2403e4 	mvn	x4, x4
    8e38:	da0303e3 	ngc	x3, x3
    8e3c:	aa0203e6 	mov	x6, x2
    8e40:	aa0003e7 	mov	x7, x0
    8e44:	aa0103e5 	mov	x5, x1
    8e48:	b5000583 	cbnz	x3, 8ef8 <__divti3+0xd8>
    8e4c:	eb01005f 	cmp	x2, x1
    8e50:	54000e69 	b.ls	901c <__divti3+0x1fc>  // b.plast
    8e54:	dac01040 	clz	x0, x2
    8e58:	b40000e0 	cbz	x0, 8e74 <__divti3+0x54>
    8e5c:	4b0003e1 	neg	w1, w0
    8e60:	9ac020a5 	lsl	x5, x5, x0
    8e64:	9ac02046 	lsl	x6, x2, x0
    8e68:	9ac124e1 	lsr	x1, x7, x1
    8e6c:	aa050025 	orr	x5, x1, x5
    8e70:	9ac020e7 	lsl	x7, x7, x0
    8e74:	d360fcc8 	lsr	x8, x6, #32
    8e78:	92407cc2 	and	x2, x6, #0xffffffff
    8e7c:	9ac808a3 	udiv	x3, x5, x8
    8e80:	9b089465 	msub	x5, x3, x8, x5
    8e84:	aa0303e0 	mov	x0, x3
    8e88:	9b037c41 	mul	x1, x2, x3
    8e8c:	93c780a5 	extr	x5, x5, x7, #32
    8e90:	eb05003f 	cmp	x1, x5
    8e94:	540000a9 	b.ls	8ea8 <__divti3+0x88>  // b.plast
    8e98:	ab0500c5 	adds	x5, x6, x5
    8e9c:	d1000460 	sub	x0, x3, #0x1
    8ea0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8ea4:	540015a8 	b.hi	9158 <__divti3+0x338>  // b.pmore
    8ea8:	cb0100a5 	sub	x5, x5, x1
    8eac:	9ac808a3 	udiv	x3, x5, x8
    8eb0:	9b089465 	msub	x5, x3, x8, x5
    8eb4:	aa0303e1 	mov	x1, x3
    8eb8:	9b037c42 	mul	x2, x2, x3
    8ebc:	aa0703e3 	mov	x3, x7
    8ec0:	b3607ca3 	bfi	x3, x5, #32, #32
    8ec4:	eb03005f 	cmp	x2, x3
    8ec8:	540000c9 	b.ls	8ee0 <__divti3+0xc0>  // b.plast
    8ecc:	ab0300c3 	adds	x3, x6, x3
    8ed0:	d1000425 	sub	x5, x1, #0x1
    8ed4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8ed8:	d1000821 	sub	x1, x1, #0x2
    8edc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8ee0:	aa008020 	orr	x0, x1, x0, lsl #32
    8ee4:	d2800001 	mov	x1, #0x0                   	// #0
    8ee8:	b4000064 	cbz	x4, 8ef4 <__divti3+0xd4>
    8eec:	eb0003e0 	negs	x0, x0
    8ef0:	da0103e1 	ngc	x1, x1
    8ef4:	d65f03c0 	ret
    8ef8:	eb01007f 	cmp	x3, x1
    8efc:	54000109 	b.ls	8f1c <__divti3+0xfc>  // b.plast
    8f00:	d2800001 	mov	x1, #0x0                   	// #0
    8f04:	d2800000 	mov	x0, #0x0                   	// #0
    8f08:	17fffff8 	b	8ee8 <__divti3+0xc8>
    8f0c:	eb0003e0 	negs	x0, x0
    8f10:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8f14:	da0103e1 	ngc	x1, x1
    8f18:	17ffffc5 	b	8e2c <__divti3+0xc>
    8f1c:	dac01067 	clz	x7, x3
    8f20:	b40010e7 	cbz	x7, 913c <__divti3+0x31c>
    8f24:	d2800805 	mov	x5, #0x40                  	// #64
    8f28:	cb0700a5 	sub	x5, x5, x7
    8f2c:	9ac72063 	lsl	x3, x3, x7
    8f30:	9ac52448 	lsr	x8, x2, x5
    8f34:	aa030108 	orr	x8, x8, x3
    8f38:	9ac52426 	lsr	x6, x1, x5
    8f3c:	92407d0a 	and	x10, x8, #0xffffffff
    8f40:	d360fd09 	lsr	x9, x8, #32
    8f44:	9ac52403 	lsr	x3, x0, x5
    8f48:	9ac72021 	lsl	x1, x1, x7
    8f4c:	aa010063 	orr	x3, x3, x1
    8f50:	9ac72042 	lsl	x2, x2, x7
    8f54:	9ac908cb 	udiv	x11, x6, x9
    8f58:	9b099965 	msub	x5, x11, x9, x6
    8f5c:	aa0b03e1 	mov	x1, x11
    8f60:	9b0b7d46 	mul	x6, x10, x11
    8f64:	93c380a5 	extr	x5, x5, x3, #32
    8f68:	eb0500df 	cmp	x6, x5
    8f6c:	540000a9 	b.ls	8f80 <__divti3+0x160>  // b.plast
    8f70:	ab050105 	adds	x5, x8, x5
    8f74:	d1000561 	sub	x1, x11, #0x1
    8f78:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8f7c:	54000f48 	b.hi	9164 <__divti3+0x344>  // b.pmore
    8f80:	cb0600a6 	sub	x6, x5, x6
    8f84:	9ac908cb 	udiv	x11, x6, x9
    8f88:	9b099969 	msub	x9, x11, x9, x6
    8f8c:	aa0b03e5 	mov	x5, x11
    8f90:	9b0b7d4a 	mul	x10, x10, x11
    8f94:	b3607d23 	bfi	x3, x9, #32, #32
    8f98:	eb03015f 	cmp	x10, x3
    8f9c:	540000a9 	b.ls	8fb0 <__divti3+0x190>  // b.plast
    8fa0:	ab030103 	adds	x3, x8, x3
    8fa4:	d1000565 	sub	x5, x11, #0x1
    8fa8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8fac:	54000e28 	b.hi	9170 <__divti3+0x350>  // b.pmore
    8fb0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8fb4:	92407c48 	and	x8, x2, #0xffffffff
    8fb8:	2a0503e5 	mov	w5, w5
    8fbc:	d360fc42 	lsr	x2, x2, #32
    8fc0:	d360fc26 	lsr	x6, x1, #32
    8fc4:	cb0a0063 	sub	x3, x3, x10
    8fc8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8fcc:	9b087caa 	mul	x10, x5, x8
    8fd0:	9b087cc8 	mul	x8, x6, x8
    8fd4:	9b0220a5 	madd	x5, x5, x2, x8
    8fd8:	9b027cc6 	mul	x6, x6, x2
    8fdc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8fe0:	8b0900c5 	add	x5, x6, x9
    8fe4:	eb02011f 	cmp	x8, x2
    8fe8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8fec:	8b4280c6 	add	x6, x6, x2, lsr #32
    8ff0:	eb06007f 	cmp	x3, x6
    8ff4:	540000e3 	b.cc	9010 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8ff8:	92407d4a 	and	x10, x10, #0xffffffff
    8ffc:	9ac72000 	lsl	x0, x0, x7
    9000:	8b028142 	add	x2, x10, x2, lsl #32
    9004:	eb02001f 	cmp	x0, x2
    9008:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    900c:	54000a01 	b.ne	914c <__divti3+0x32c>  // b.any
    9010:	d1000420 	sub	x0, x1, #0x1
    9014:	d2800001 	mov	x1, #0x0                   	// #0
    9018:	17ffffb4 	b	8ee8 <__divti3+0xc8>
    901c:	b5000062 	cbnz	x2, 9028 <__divti3+0x208>
    9020:	d2800022 	mov	x2, #0x1                   	// #1
    9024:	9ac30846 	udiv	x6, x2, x3
    9028:	dac010c8 	clz	x8, x6
    902c:	b5000408 	cbnz	x8, 90ac <__divti3+0x28c>
    9030:	d360fcc9 	lsr	x9, x6, #32
    9034:	92407cc5 	and	x5, x6, #0xffffffff
    9038:	cb060023 	sub	x3, x1, x6
    903c:	d2800021 	mov	x1, #0x1                   	// #1
    9040:	9ac90868 	udiv	x8, x3, x9
    9044:	9b098d03 	msub	x3, x8, x9, x3
    9048:	aa0803e0 	mov	x0, x8
    904c:	9b057d02 	mul	x2, x8, x5
    9050:	93c78063 	extr	x3, x3, x7, #32
    9054:	eb03005f 	cmp	x2, x3
    9058:	540000a9 	b.ls	906c <__divti3+0x24c>  // b.plast
    905c:	ab0300c3 	adds	x3, x6, x3
    9060:	d1000500 	sub	x0, x8, #0x1
    9064:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9068:	54000968 	b.hi	9194 <__divti3+0x374>  // b.pmore
    906c:	cb020063 	sub	x3, x3, x2
    9070:	9ac90862 	udiv	x2, x3, x9
    9074:	aa0203e8 	mov	x8, x2
    9078:	9b098c42 	msub	x2, x2, x9, x3
    907c:	aa0703e3 	mov	x3, x7
    9080:	9b057d05 	mul	x5, x8, x5
    9084:	b3607c43 	bfi	x3, x2, #32, #32
    9088:	eb0300bf 	cmp	x5, x3
    908c:	540000c9 	b.ls	90a4 <__divti3+0x284>  // b.plast
    9090:	ab0300c2 	adds	x2, x6, x3
    9094:	d1000503 	sub	x3, x8, #0x1
    9098:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    909c:	d1000908 	sub	x8, x8, #0x2
    90a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    90a4:	aa008100 	orr	x0, x8, x0, lsl #32
    90a8:	17ffff90 	b	8ee8 <__divti3+0xc8>
    90ac:	9ac820c6 	lsl	x6, x6, x8
    90b0:	d2800803 	mov	x3, #0x40                  	// #64
    90b4:	cb080063 	sub	x3, x3, x8
    90b8:	d360fcc9 	lsr	x9, x6, #32
    90bc:	9ac82027 	lsl	x7, x1, x8
    90c0:	92407cc5 	and	x5, x6, #0xffffffff
    90c4:	9ac32422 	lsr	x2, x1, x3
    90c8:	9ac32403 	lsr	x3, x0, x3
    90cc:	aa070063 	orr	x3, x3, x7
    90d0:	9ac9084a 	udiv	x10, x2, x9
    90d4:	9ac82007 	lsl	x7, x0, x8
    90d8:	9b098940 	msub	x0, x10, x9, x2
    90dc:	aa0a03e1 	mov	x1, x10
    90e0:	9b0a7ca2 	mul	x2, x5, x10
    90e4:	93c38000 	extr	x0, x0, x3, #32
    90e8:	eb00005f 	cmp	x2, x0
    90ec:	540000a9 	b.ls	9100 <__divti3+0x2e0>  // b.plast
    90f0:	ab0000c0 	adds	x0, x6, x0
    90f4:	d1000541 	sub	x1, x10, #0x1
    90f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    90fc:	54000468 	b.hi	9188 <__divti3+0x368>  // b.pmore
    9100:	cb020000 	sub	x0, x0, x2
    9104:	9ac9080a 	udiv	x10, x0, x9
    9108:	9b098140 	msub	x0, x10, x9, x0
    910c:	aa0a03e2 	mov	x2, x10
    9110:	9b0a7ca8 	mul	x8, x5, x10
    9114:	b3607c03 	bfi	x3, x0, #32, #32
    9118:	eb03011f 	cmp	x8, x3
    911c:	540000a9 	b.ls	9130 <__divti3+0x310>  // b.plast
    9120:	ab0300c3 	adds	x3, x6, x3
    9124:	d1000542 	sub	x2, x10, #0x1
    9128:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    912c:	54000288 	b.hi	917c <__divti3+0x35c>  // b.pmore
    9130:	cb080063 	sub	x3, x3, x8
    9134:	aa018041 	orr	x1, x2, x1, lsl #32
    9138:	17ffffc2 	b	9040 <__divti3+0x220>
    913c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9140:	d2800001 	mov	x1, #0x0                   	// #0
    9144:	9a9f87e0 	cset	x0, ls	// ls = plast
    9148:	17ffff68 	b	8ee8 <__divti3+0xc8>
    914c:	aa0103e0 	mov	x0, x1
    9150:	d2800001 	mov	x1, #0x0                   	// #0
    9154:	17ffff65 	b	8ee8 <__divti3+0xc8>
    9158:	d1000860 	sub	x0, x3, #0x2
    915c:	8b0600a5 	add	x5, x5, x6
    9160:	17ffff52 	b	8ea8 <__divti3+0x88>
    9164:	d1000961 	sub	x1, x11, #0x2
    9168:	8b0800a5 	add	x5, x5, x8
    916c:	17ffff85 	b	8f80 <__divti3+0x160>
    9170:	d1000965 	sub	x5, x11, #0x2
    9174:	8b080063 	add	x3, x3, x8
    9178:	17ffff8e 	b	8fb0 <__divti3+0x190>
    917c:	d1000942 	sub	x2, x10, #0x2
    9180:	8b060063 	add	x3, x3, x6
    9184:	17ffffeb 	b	9130 <__divti3+0x310>
    9188:	d1000941 	sub	x1, x10, #0x2
    918c:	8b060000 	add	x0, x0, x6
    9190:	17ffffdc 	b	9100 <__divti3+0x2e0>
    9194:	d1000900 	sub	x0, x8, #0x2
    9198:	8b060063 	add	x3, x3, x6
    919c:	17ffffb4 	b	906c <__divti3+0x24c>

00000000000091a0 <__modti3>:
    91a0:	d503245f 	bti	c
    91a4:	d2800004 	mov	x4, #0x0                   	// #0
    91a8:	b6f80081 	tbz	x1, #63, 91b8 <__modti3+0x18>
    91ac:	eb0003e0 	negs	x0, x0
    91b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    91b4:	da0103e1 	ngc	x1, x1
    91b8:	f100007f 	cmp	x3, #0x0
    91bc:	5400128b 	b.lt	940c <__modti3+0x26c>  // b.tstop
    91c0:	aa0003e7 	mov	x7, x0
    91c4:	aa0103e6 	mov	x6, x1
    91c8:	540004e1 	b.ne	9264 <__modti3+0xc4>  // b.any
    91cc:	eb02003f 	cmp	x1, x2
    91d0:	54000dc2 	b.cs	9388 <__modti3+0x1e8>  // b.hs, b.nlast
    91d4:	dac01043 	clz	x3, x2
    91d8:	aa0303e5 	mov	x5, x3
    91dc:	b40000e3 	cbz	x3, 91f8 <__modti3+0x58>
    91e0:	4b0303e6 	neg	w6, w3
    91e4:	9ac32021 	lsl	x1, x1, x3
    91e8:	9ac32042 	lsl	x2, x2, x3
    91ec:	9ac62406 	lsr	x6, x0, x6
    91f0:	aa0100c6 	orr	x6, x6, x1
    91f4:	9ac32007 	lsl	x7, x0, x3
    91f8:	d360fc40 	lsr	x0, x2, #32
    91fc:	92407c43 	and	x3, x2, #0xffffffff
    9200:	9ac008c1 	udiv	x1, x6, x0
    9204:	9b009826 	msub	x6, x1, x0, x6
    9208:	9b017c61 	mul	x1, x3, x1
    920c:	93c780c6 	extr	x6, x6, x7, #32
    9210:	eb06003f 	cmp	x1, x6
    9214:	540000a9 	b.ls	9228 <__modti3+0x88>  // b.plast
    9218:	ab060046 	adds	x6, x2, x6
    921c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9220:	8b0200c8 	add	x8, x6, x2
    9224:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9228:	cb0100c6 	sub	x6, x6, x1
    922c:	9ac008c8 	udiv	x8, x6, x0
    9230:	9b009901 	msub	x1, x8, x0, x6
    9234:	aa0703e0 	mov	x0, x7
    9238:	9b087c63 	mul	x3, x3, x8
    923c:	b3607c20 	bfi	x0, x1, #32, #32
    9240:	eb00007f 	cmp	x3, x0
    9244:	54001088 	b.hi	9454 <__modti3+0x2b4>  // b.pmore
    9248:	cb030000 	sub	x0, x0, x3
    924c:	9ac52400 	lsr	x0, x0, x5
    9250:	d2800001 	mov	x1, #0x0                   	// #0
    9254:	b4000064 	cbz	x4, 9260 <__modti3+0xc0>
    9258:	eb0003e0 	negs	x0, x0
    925c:	da0103e1 	ngc	x1, x1
    9260:	d65f03c0 	ret
    9264:	dac01066 	clz	x6, x3
    9268:	eb03003f 	cmp	x1, x3
    926c:	54ffff43 	b.cc	9254 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9270:	93407cc5 	sxtw	x5, w6
    9274:	d2800808 	mov	x8, #0x40                  	// #64
    9278:	cb050108 	sub	x8, x8, x5
    927c:	9ac62063 	lsl	x3, x3, x6
    9280:	9ac62025 	lsl	x5, x1, x6
    9284:	9ac82447 	lsr	x7, x2, x8
    9288:	aa0300e7 	orr	x7, x7, x3
    928c:	9ac82423 	lsr	x3, x1, x8
    9290:	92407cec 	and	x12, x7, #0xffffffff
    9294:	d360fcea 	lsr	x10, x7, #32
    9298:	9ac82401 	lsr	x1, x0, x8
    929c:	aa050021 	orr	x1, x1, x5
    92a0:	9ac62042 	lsl	x2, x2, x6
    92a4:	9ac62000 	lsl	x0, x0, x6
    92a8:	9aca086b 	udiv	x11, x3, x10
    92ac:	9b0a8d63 	msub	x3, x11, x10, x3
    92b0:	aa0b03e5 	mov	x5, x11
    92b4:	9b0b7d89 	mul	x9, x12, x11
    92b8:	93c18063 	extr	x3, x3, x1, #32
    92bc:	eb03013f 	cmp	x9, x3
    92c0:	540000a9 	b.ls	92d4 <__modti3+0x134>  // b.plast
    92c4:	ab0300e3 	adds	x3, x7, x3
    92c8:	d1000565 	sub	x5, x11, #0x1
    92cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    92d0:	54001168 	b.hi	94fc <__modti3+0x35c>  // b.pmore
    92d4:	cb090063 	sub	x3, x3, x9
    92d8:	9aca086b 	udiv	x11, x3, x10
    92dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    92e0:	aa0b03e9 	mov	x9, x11
    92e4:	9b0b7d8c 	mul	x12, x12, x11
    92e8:	b3607d41 	bfi	x1, x10, #32, #32
    92ec:	eb01019f 	cmp	x12, x1
    92f0:	540000a9 	b.ls	9304 <__modti3+0x164>  // b.plast
    92f4:	ab0100e1 	adds	x1, x7, x1
    92f8:	d1000569 	sub	x9, x11, #0x1
    92fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9300:	54000f88 	b.hi	94f0 <__modti3+0x350>  // b.pmore
    9304:	aa058123 	orr	x3, x9, x5, lsl #32
    9308:	92407c4b 	and	x11, x2, #0xffffffff
    930c:	2a0903e9 	mov	w9, w9
    9310:	d360fc4a 	lsr	x10, x2, #32
    9314:	d360fc63 	lsr	x3, x3, #32
    9318:	cb0c0021 	sub	x1, x1, x12
    931c:	aa0a03ec 	mov	x12, x10
    9320:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9324:	9b0b7d25 	mul	x5, x9, x11
    9328:	9b0b7c6b 	mul	x11, x3, x11
    932c:	9b0a2d29 	madd	x9, x9, x10, x11
    9330:	92407caa 	and	x10, x5, #0xffffffff
    9334:	9b0c7c63 	mul	x3, x3, x12
    9338:	8b458125 	add	x5, x9, x5, lsr #32
    933c:	8b0d0069 	add	x9, x3, x13
    9340:	eb05017f 	cmp	x11, x5
    9344:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9348:	8b058149 	add	x9, x10, x5, lsl #32
    934c:	8b458063 	add	x3, x3, x5, lsr #32
    9350:	eb03003f 	cmp	x1, x3
    9354:	54000063 	b.cc	9360 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9358:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    935c:	54000082 	b.cs	936c <__modti3+0x1cc>  // b.hs, b.nlast
    9360:	eb020129 	subs	x9, x9, x2
    9364:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9368:	cb070063 	sub	x3, x3, x7
    936c:	eb090000 	subs	x0, x0, x9
    9370:	da030021 	sbc	x1, x1, x3
    9374:	9ac62400 	lsr	x0, x0, x6
    9378:	9ac82028 	lsl	x8, x1, x8
    937c:	aa000100 	orr	x0, x8, x0
    9380:	9ac62421 	lsr	x1, x1, x6
    9384:	17ffffb4 	b	9254 <__modti3+0xb4>
    9388:	b5000062 	cbnz	x2, 9394 <__modti3+0x1f4>
    938c:	d2800023 	mov	x3, #0x1                   	// #1
    9390:	9ac20862 	udiv	x2, x3, x2
    9394:	dac01048 	clz	x8, x2
    9398:	aa0803e5 	mov	x5, x8
    939c:	b5000668 	cbnz	x8, 9468 <__modti3+0x2c8>
    93a0:	cb020020 	sub	x0, x1, x2
    93a4:	d360fc49 	lsr	x9, x2, #32
    93a8:	92407c4a 	and	x10, x2, #0xffffffff
    93ac:	9ac90801 	udiv	x1, x0, x9
    93b0:	9b098020 	msub	x0, x1, x9, x0
    93b4:	9b0a7c21 	mul	x1, x1, x10
    93b8:	93c78000 	extr	x0, x0, x7, #32
    93bc:	eb00003f 	cmp	x1, x0
    93c0:	540000a9 	b.ls	93d4 <__modti3+0x234>  // b.plast
    93c4:	ab000040 	adds	x0, x2, x0
    93c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    93cc:	8b020003 	add	x3, x0, x2
    93d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    93d4:	cb010001 	sub	x1, x0, x1
    93d8:	9ac90820 	udiv	x0, x1, x9
    93dc:	9b098403 	msub	x3, x0, x9, x1
    93e0:	aa0703e1 	mov	x1, x7
    93e4:	9b0a7c00 	mul	x0, x0, x10
    93e8:	b3607c61 	bfi	x1, x3, #32, #32
    93ec:	eb01001f 	cmp	x0, x1
    93f0:	540000a9 	b.ls	9404 <__modti3+0x264>  // b.plast
    93f4:	ab010041 	adds	x1, x2, x1
    93f8:	8b020022 	add	x2, x1, x2
    93fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9400:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9404:	cb000020 	sub	x0, x1, x0
    9408:	17ffff91 	b	924c <__modti3+0xac>
    940c:	eb0203e5 	negs	x5, x2
    9410:	aa0003e7 	mov	x7, x0
    9414:	da0303e8 	ngc	x8, x3
    9418:	aa0503e2 	mov	x2, x5
    941c:	aa0803e3 	mov	x3, x8
    9420:	aa0103e6 	mov	x6, x1
    9424:	b4ffed48 	cbz	x8, 91cc <__modti3+0x2c>
    9428:	eb01011f 	cmp	x8, x1
    942c:	54fff148 	b.hi	9254 <__modti3+0xb4>  // b.pmore
    9430:	dac01109 	clz	x9, x8
    9434:	2a0903e6 	mov	w6, w9
    9438:	b5fff1c9 	cbnz	x9, 9270 <__modti3+0xd0>
    943c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9440:	54000068 	b.hi	944c <__modti3+0x2ac>  // b.pmore
    9444:	eb050007 	subs	x7, x0, x5
    9448:	da080021 	sbc	x1, x1, x8
    944c:	aa0703e0 	mov	x0, x7
    9450:	17ffff81 	b	9254 <__modti3+0xb4>
    9454:	ab000040 	adds	x0, x2, x0
    9458:	8b020002 	add	x2, x0, x2
    945c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9460:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9464:	17ffff79 	b	9248 <__modti3+0xa8>
    9468:	9ac82042 	lsl	x2, x2, x8
    946c:	d2800803 	mov	x3, #0x40                  	// #64
    9470:	cb080063 	sub	x3, x3, x8
    9474:	d360fc49 	lsr	x9, x2, #32
    9478:	9ac82027 	lsl	x7, x1, x8
    947c:	92407c4a 	and	x10, x2, #0xffffffff
    9480:	9ac32426 	lsr	x6, x1, x3
    9484:	9ac32403 	lsr	x3, x0, x3
    9488:	aa070063 	orr	x3, x3, x7
    948c:	9ac908c1 	udiv	x1, x6, x9
    9490:	9ac82007 	lsl	x7, x0, x8
    9494:	9b099820 	msub	x0, x1, x9, x6
    9498:	9b017d41 	mul	x1, x10, x1
    949c:	93c38000 	extr	x0, x0, x3, #32
    94a0:	eb00003f 	cmp	x1, x0
    94a4:	540000a9 	b.ls	94b8 <__modti3+0x318>  // b.plast
    94a8:	ab000040 	adds	x0, x2, x0
    94ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    94b0:	8b020006 	add	x6, x0, x2
    94b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    94b8:	cb010000 	sub	x0, x0, x1
    94bc:	9ac90801 	udiv	x1, x0, x9
    94c0:	9b098026 	msub	x6, x1, x9, x0
    94c4:	aa0303e0 	mov	x0, x3
    94c8:	9b017d41 	mul	x1, x10, x1
    94cc:	b3607cc0 	bfi	x0, x6, #32, #32
    94d0:	eb00003f 	cmp	x1, x0
    94d4:	540000a9 	b.ls	94e8 <__modti3+0x348>  // b.plast
    94d8:	ab000040 	adds	x0, x2, x0
    94dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    94e0:	8b020003 	add	x3, x0, x2
    94e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    94e8:	cb010000 	sub	x0, x0, x1
    94ec:	17ffffb0 	b	93ac <__modti3+0x20c>
    94f0:	d1000969 	sub	x9, x11, #0x2
    94f4:	8b070021 	add	x1, x1, x7
    94f8:	17ffff83 	b	9304 <__modti3+0x164>
    94fc:	d1000965 	sub	x5, x11, #0x2
    9500:	8b070063 	add	x3, x3, x7
    9504:	17ffff74 	b	92d4 <__modti3+0x134>
    9508:	d503201f 	nop
    950c:	d503201f 	nop

0000000000009510 <atexit>:
    9510:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9514:	f00000a2 	adrp	x2, 20000 <__data_start>
    9518:	d2800001 	mov	x1, #0x0                   	// #0
    951c:	910003fd 	mov	x29, sp
    9520:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9524:	f9400442 	ldr	x2, [x2, #8]
    9528:	17ffe496 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000952c <_fini>:
    952c:	d503201f 	nop
    9530:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9534:	910003fd 	mov	x29, sp
    9538:	a8c17bfd 	ldp	x29, x30, [sp], #16
    953c:	d65f03c0 	ret
