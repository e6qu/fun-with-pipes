
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <_IO_stdin_used+0x180>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910520a5 	add	x5, x5, #0x148
    2a20:	b0000044 	adrp	x4, b000 <_IO_stdin_used+0x180>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91054084 	add	x4, x4, #0x150
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004f0 	bl	3e10 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	9100c2a1 	add	x1, x21, #0x30
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11090>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003c20 	str	x0, [x1, #120]
    2aac:	940006f9 	bl	4690 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2ab4:	91118000 	add	x0, x0, #0x460
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x650>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91268042 	add	x2, x2, #0x9a0
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	9100c2b5 	add	x21, x21, #0x30
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430aa0 	ldr	w0, [x21, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2bcc:	91124000 	add	x0, x0, #0x490
    2bd0:	94000490 	bl	3e10 <fwp_trap>
    2bd4:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2bd8:	9111c000 	add	x0, x0, #0x470
    2bdc:	9400048d 	bl	3e10 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff3e 	bl	28e0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee3 	bl	27a0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2c20:	9113a000 	add	x0, x0, #0x4e8
    2c24:	9400047b 	bl	3e10 <fwp_trap>
    2c28:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2c2c:	9112e000 	add	x0, x0, #0x4b8
    2c30:	94000478 	bl	3e10 <fwp_trap>
    2c34:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x180>
    2c38:	91144000 	add	x0, x0, #0x510
    2c3c:	94000475 	bl	3e10 <fwp_trap>
    2c40:	97fffeec 	bl	27f0 <__stack_chk_fail@plt>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91008000 	add	x0, x0, #0x20
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91008021 	add	x1, x1, #0x20
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91008000 	add	x0, x0, #0x20
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91008021 	add	x1, x1, #0x20
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39408260 	ldrb	w0, [x19, #32]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39008260 	strb	w0, [x19, #32]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x180>
    2e34:	912c4021 	add	x1, x1, #0xb10
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9401884 	ldr	x4, [x4, #48]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9401863 	ldr	x3, [x3, #48]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9401c00 	ldr	x0, [x0, #56]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	90000040 	adrp	x0, a000 <fwp_main_thread+0x660>
    2fd0:	913a2000 	add	x0, x0, #0xe88
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	9100c043 	add	x3, x2, #0x30
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	9100c042 	add	x2, x2, #0x30
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x180>
    3098:	912bc021 	add	x1, x1, #0xaf0
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    30c4:	911502a1 	add	x1, x21, #0x540
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    30d8:	9124c0a5 	add	x5, x5, #0x930
    30dc:	911502a1 	add	x1, x21, #0x540
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911502b7 	add	x23, x21, #0x540
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911502b5 	add	x21, x21, #0x540
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911502b5 	add	x21, x21, #0x540
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3268:	9124a0a5 	add	x5, x5, #0x928
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3370:	913a2000 	add	x0, x0, #0xe88
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	9100c022 	add	x2, x1, #0x30
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	9100c021 	add	x1, x1, #0x30
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x660>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	913a8021 	add	x1, x1, #0xea0
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x660>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	913aa021 	add	x1, x1, #0xea8
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x660>
    34e0:	913ac021 	add	x1, x1, #0xeb0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x660>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	913ae084 	add	x4, x4, #0xeb8
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc7f 	bl	2760 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcd8 	bl	28d0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc3 	bl	2890 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc0c 	bl	2640 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc44 	bl	2740 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc35 	bl	2740 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbed 	bl	2640 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbf9 	bl	2680 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc89 	bl	28d0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x660>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	913b4084 	add	x4, x4, #0xed0
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0a 	bl	2760 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbf9 	bl	2740 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc59 	bl	28d0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x660>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	913b0084 	add	x4, x4, #0xec0
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe2 	bl	2760 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbcc 	bl	2740 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba0 	bl	2740 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbbc 	bl	27f0 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    390c:	91150042 	add	x2, x2, #0x540
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x660>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	913b6021 	add	x1, x1, #0xed8
    3968:	913b8000 	add	x0, x0, #0xee0
    396c:	97fffb85 	bl	2780 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbaf 	bl	2890 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb5f 	bl	2770 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x660>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	913c0042 	add	x2, x2, #0xf00
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb82 	b	2860 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb62 	bl	27f0 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3a78:	91110061 	add	x1, x3, #0x440
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3a88:	91150262 	add	x2, x19, #0x540
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x180>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3abc:	91120021 	add	x1, x1, #0x480
    3ac0:	3dc2c843 	ldr	q3, [x2, #2848]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3aec:	91110063 	add	x3, x3, #0x440
    3af0:	91138084 	add	x4, x4, #0x4e0
    3af4:	91150266 	add	x6, x19, #0x540
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb45 	bl	2880 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	91150275 	add	x21, x19, #0x540
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb2f 	bl	2880 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3bd8:	913e2000 	add	x0, x0, #0xf88
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb68 	bl	2980 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	91150273 	add	x19, x19, #0x540
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	9100c122 	add	x2, x9, #0x30
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	9100c120 	add	x0, x9, #0x30
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	9100c129 	add	x9, x9, #0x30
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9401400 	ldr	x0, [x0, #40]
    3d04:	b7f80760 	tbnz	x0, #63, 3df0 <fwp_tape_buffers_release+0x100>
    3d08:	f9401a61 	ldr	x1, [x19, #48]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3d3c:	913e6000 	add	x0, x0, #0xf98
    3d40:	97fffb10 	bl	2980 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	913e6000 	add	x0, x0, #0xf98
    3d78:	97fffb02 	bl	2980 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	9100c2d6 	add	x22, x22, #0x30
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400a61 	ldp	q1, q2, [x19]
    3db8:	f9003ad4 	str	x20, [x22, #112]
    3dbc:	4f000400 	movi	v0.4s, #0x0
    3dc0:	ad000aa1 	stp	q1, q2, [x21]
    3dc4:	3dc00a61 	ldr	q1, [x19, #32]
    3dc8:	3d800aa1 	str	q1, [x21, #32]
    3dcc:	f9401a60 	ldr	x0, [x19, #48]
    3dd0:	f9001aa0 	str	x0, [x21, #48]
    3dd4:	f9001a7f 	str	xzr, [x19, #48]
    3dd8:	ad000260 	stp	q0, q0, [x19]
    3ddc:	3d800a60 	str	q0, [x19, #32]
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3dec:	d65f03c0 	ret
    3df0:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3df4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df8:	913e6000 	add	x0, x0, #0xf98
    3dfc:	97fffae1 	bl	2980 <getenv@plt>
    3e00:	b5fffa40 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3e04:	17ffffd6 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3e08:	d503201f 	nop
    3e0c:	d503201f 	nop

0000000000003e10 <fwp_trap>:
    3e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e14:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e18:	d53bd041 	mrs	x1, tpidr_el0
    3e1c:	910003fd 	mov	x29, sp
    3e20:	f9401c42 	ldr	x2, [x2, #56]
    3e24:	91400021 	add	x1, x1, #0x0, lsl #12
    3e28:	91004021 	add	x1, x1, #0x10
    3e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e30:	aa0003f3 	mov	x19, x0
    3e34:	f9400034 	ldr	x20, [x1]
    3e38:	b4000062 	cbz	x2, 3e44 <fwp_trap+0x34>
    3e3c:	aa0203e0 	mov	x0, x2
    3e40:	97fffab8 	bl	2920 <fflush@plt>
    3e44:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3e48:	f947ec00 	ldr	x0, [x0, #4056]
    3e4c:	f9400000 	ldr	x0, [x0]
    3e50:	97fffab4 	bl	2920 <fflush@plt>
    3e54:	aa1303e3 	mov	x3, x19
    3e58:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x660>
    3e5c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    3e60:	f947ea73 	ldr	x19, [x19, #4048]
    3e64:	913ec042 	add	x2, x2, #0xfb0
    3e68:	52800041 	mov	w1, #0x2                   	// #2
    3e6c:	f9400260 	ldr	x0, [x19]
    3e70:	97fffa7c 	bl	2860 <__fprintf_chk@plt>
    3e74:	b40000b4 	cbz	x20, 3e88 <fwp_trap+0x78>
    3e78:	f9400260 	ldr	x0, [x19]
    3e7c:	97fffaa9 	bl	2920 <fflush@plt>
    3e80:	52800ca0 	mov	w0, #0x65                  	// #101
    3e84:	97fffab7 	bl	2960 <_Exit@plt>
    3e88:	52800ca0 	mov	w0, #0x65                  	// #101
    3e8c:	97fffa05 	bl	26a0 <exit@plt>

0000000000003e90 <fwp_rc_forget_slot.part.0>:
    3e90:	ca404401 	eor	x1, x0, x0, lsr #17
    3e94:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e98:	ca412421 	eor	x1, x1, x1, lsr #9
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	92401c21 	and	x1, x1, #0xff
    3ea4:	f9000bf3 	str	x19, [sp, #16]
    3ea8:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3eac:	91150262 	add	x2, x19, #0x540
    3eb0:	910a2423 	add	x3, x1, #0x289
    3eb4:	8b010c41 	add	x1, x2, x1, lsl #3
    3eb8:	8b030c43 	add	x3, x2, x3, lsl #3
    3ebc:	f94a2421 	ldr	x1, [x1, #5192]
    3ec0:	b50000a1 	cbnz	x1, 3ed4 <fwp_rc_forget_slot.part.0+0x44>
    3ec4:	14000012 	b	3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ec8:	91004023 	add	x3, x1, #0x10
    3ecc:	f9400821 	ldr	x1, [x1, #16]
    3ed0:	b40001e1 	cbz	x1, 3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ed4:	f9400022 	ldr	x2, [x1]
    3ed8:	eb02001f 	cmp	x0, x2
    3edc:	54ffff61 	b.ne	3ec8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ee0:	f9400060 	ldr	x0, [x3]
    3ee4:	91150273 	add	x19, x19, #0x540
    3ee8:	f9400801 	ldr	x1, [x0, #16]
    3eec:	f9000061 	str	x1, [x3]
    3ef0:	97fffa70 	bl	28b0 <free@plt>
    3ef4:	f94e2660 	ldr	x0, [x19, #7240]
    3ef8:	d1000400 	sub	x0, x0, #0x1
    3efc:	f90e2660 	str	x0, [x19, #7240]
    3f00:	f9400bf3 	ldr	x19, [sp, #16]
    3f04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f08:	d65f03c0 	ret
    3f0c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    3f10:	913f0000 	add	x0, x0, #0xfc0
    3f14:	97ffffbf 	bl	3e10 <fwp_trap>
    3f18:	d503201f 	nop
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_rc_prepare_chunk>:
    3f20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f24:	910003fd 	mov	x29, sp
    3f28:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f2c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    3f30:	911502c2 	add	x2, x22, #0x540
    3f34:	b9401c03 	ldr	w3, [x0, #28]
    3f38:	aa0103f5 	mov	x21, x1
    3f3c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f40:	aa0003f4 	mov	x20, x0
    3f44:	f94e2440 	ldr	x0, [x2, #7240]
    3f48:	b4000440 	cbz	x0, 3fd0 <fwp_rc_prepare_chunk+0xb0>
    3f4c:	d2800013 	mov	x19, #0x0                   	// #0
    3f50:	35000203 	cbnz	w3, 3f90 <fwp_rc_prepare_chunk+0x70>
    3f54:	b4000361 	cbz	x1, 3fc0 <fwp_rc_prepare_chunk+0xa0>
    3f58:	f9401280 	ldr	x0, [x20, #32]
    3f5c:	97fffa55 	bl	28b0 <free@plt>
    3f60:	aa1503e0 	mov	x0, x21
    3f64:	d2800021 	mov	x1, #0x1                   	// #1
    3f68:	97fffa1a 	bl	27d0 <calloc@plt>
    3f6c:	f9001280 	str	x0, [x20, #32]
    3f70:	b5000460 	cbnz	x0, 3ffc <fwp_rc_prepare_chunk+0xdc>
    3f74:	97fffc0f 	bl	2fb0 <fwp_heap_oom>
    3f78:	97ffffc6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    3f7c:	91000673 	add	x19, x19, #0x1
    3f80:	b9401e83 	ldr	w3, [x20, #28]
    3f84:	eb13007f 	cmp	x3, x19
    3f88:	54000169 	b.ls	3fb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f8c:	d503201f 	nop
    3f90:	f9401283 	ldr	x3, [x20, #32]
    3f94:	8b130060 	add	x0, x3, x19
    3f98:	38736863 	ldrb	w3, [x3, x19]
    3f9c:	7103fc7f 	cmp	w3, #0xff
    3fa0:	54fffec0 	b.eq	3f78 <fwp_rc_prepare_chunk+0x58>  // b.none
    3fa4:	b9401e83 	ldr	w3, [x20, #28]
    3fa8:	91000673 	add	x19, x19, #0x1
    3fac:	eb13007f 	cmp	x3, x19
    3fb0:	54ffff08 	b.hi	3f90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fb4:	eb0302bf 	cmp	x21, x3
    3fb8:	54000121 	b.ne	3fdc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fbc:	b5000335 	cbnz	x21, 4020 <fwp_rc_prepare_chunk+0x100>
    3fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fcc:	d65f03c0 	ret
    3fd0:	2a0303e3 	mov	w3, w3
    3fd4:	eb0302bf 	cmp	x21, x3
    3fd8:	54ffff20 	b.eq	3fbc <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fdc:	911502c2 	add	x2, x22, #0x540
    3fe0:	f9401280 	ldr	x0, [x20, #32]
    3fe4:	f94e2841 	ldr	x1, [x2, #7248]
    3fe8:	cb030021 	sub	x1, x1, x3
    3fec:	f90e2841 	str	x1, [x2, #7248]
    3ff0:	97fffa30 	bl	28b0 <free@plt>
    3ff4:	b5fffb75 	cbnz	x21, 3f60 <fwp_rc_prepare_chunk+0x40>
    3ff8:	f900129f 	str	xzr, [x20, #32]
    3ffc:	911502d6 	add	x22, x22, #0x540
    4000:	f94e2ac0 	ldr	x0, [x22, #7248]
    4004:	b9001e95 	str	w21, [x20, #28]
    4008:	a94153f3 	ldp	x19, x20, [sp, #16]
    400c:	8b150000 	add	x0, x0, x21
    4010:	f90e2ac0 	str	x0, [x22, #7248]
    4014:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4018:	a8c37bfd 	ldp	x29, x30, [sp], #48
    401c:	d65f03c0 	ret
    4020:	f9401280 	ldr	x0, [x20, #32]
    4024:	aa1503e2 	mov	x2, x21
    4028:	a94153f3 	ldp	x19, x20, [sp, #16]
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4034:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4038:	17fff9e2 	b	27c0 <memset@plt>
    403c:	d503201f 	nop

0000000000004040 <fwp_heap_refill>:
    4040:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4044:	910003fd 	mov	x29, sp
    4048:	a9025bf5 	stp	x21, x22, [sp, #32]
    404c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4050:	911502b5 	add	x21, x21, #0x540
    4054:	aa0003f6 	mov	x22, x0
    4058:	d2800020 	mov	x0, #0x1                   	// #1
    405c:	a90153f3 	stp	x19, x20, [sp, #16]
    4060:	a90363f7 	stp	x23, x24, [sp, #48]
    4064:	2a0103f7 	mov	w23, w1
    4068:	2a0203f8 	mov	w24, w2
    406c:	97fffc11 	bl	30b0 <fwp_heap_chunks>
    4070:	aa0003f3 	mov	x19, x0
    4074:	f949fea2 	ldr	x2, [x21, #5112]
    4078:	8b000800 	add	x0, x0, x0, lsl #2
    407c:	2a1703e1 	mov	w1, w23
    4080:	52800025 	mov	w5, #0x1                   	// #1
    4084:	d37df000 	lsl	x0, x0, #3
    4088:	910f0021 	add	x1, x1, #0x3c0
    408c:	8b000054 	add	x20, x2, x0
    4090:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4094:	52a00024 	mov	w4, #0x10000               	// #65536
    4098:	38206845 	strb	w5, [x2, x0]
    409c:	aa1403e0 	mov	x0, x20
    40a0:	39000698 	strb	w24, [x20, #1]
    40a4:	39000a97 	strb	w23, [x20, #2]
    40a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    40ac:	b9000681 	str	w1, [x20, #4]
    40b0:	2a0103e5 	mov	w5, w1
    40b4:	8b0300a2 	add	x2, x5, x3
    40b8:	1ac10881 	udiv	w1, w4, w1
    40bc:	9ac50842 	udiv	x2, x2, x5
    40c0:	b9000a81 	str	w1, [x20, #8]
    40c4:	92404021 	and	x1, x1, #0x1ffff
    40c8:	b9001a82 	str	w2, [x20, #24]
    40cc:	97ffff95 	bl	3f20 <fwp_rc_prepare_chunk>
    40d0:	f949daa0 	ldr	x0, [x21, #5040]
    40d4:	29408a81 	ldp	w1, w2, [x20, #4]
    40d8:	8b134000 	add	x0, x0, x19, lsl #16
    40dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e0:	8b214003 	add	x3, x0, w1, uxtw
    40e4:	9ba20021 	umaddl	x1, w1, w2, x0
    40e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40ec:	a90086c3 	stp	x3, x1, [x22, #8]
    40f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40f8:	d65f03c0 	ret
    40fc:	d503201f 	nop

0000000000004100 <fwp_mem_free>:
    4100:	b40003c0 	cbz	x0, 4178 <fwp_mem_free+0x78>
    4104:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4108:	910003fd 	mov	x29, sp
    410c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4110:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4114:	911502a1 	add	x1, x21, #0x540
    4118:	a90153f3 	stp	x19, x20, [sp, #16]
    411c:	aa0003f3 	mov	x19, x0
    4120:	f949d823 	ldr	x3, [x1, #5040]
    4124:	f949ec22 	ldr	x2, [x1, #5080]
    4128:	cb030000 	sub	x0, x0, x3
    412c:	eb02401f 	cmp	x0, x2, lsl #16
    4130:	540001c2 	b.cs	4168 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4134:	d350fc16 	lsr	x22, x0, #16
    4138:	a90363f7 	stp	x23, x24, [sp, #48]
    413c:	f949fc22 	ldr	x2, [x1, #5112]
    4140:	8b160ad4 	add	x20, x22, x22, lsl #2
    4144:	d37df294 	lsl	x20, x20, #3
    4148:	ab140057 	adds	x23, x2, x20
    414c:	540000c0 	b.eq	4164 <fwp_mem_free+0x64>  // b.none
    4150:	38746842 	ldrb	w2, [x2, x20]
    4154:	7100045f 	cmp	w2, #0x1
    4158:	54000120 	b.eq	417c <fwp_mem_free+0x7c>  // b.none
    415c:	7100085f 	cmp	w2, #0x2
    4160:	540005e0 	b.eq	421c <fwp_mem_free+0x11c>  // b.none
    4164:	a94363f7 	ldp	x23, x24, [sp, #48]
    4168:	a94153f3 	ldp	x19, x20, [sp, #16]
    416c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4170:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4174:	d65f03c0 	ret
    4178:	d65f03c0 	ret
    417c:	f94012f8 	ldr	x24, [x23, #32]
    4180:	b94006e1 	ldr	w1, [x23, #4]
    4184:	f90023f9 	str	x25, [sp, #64]
    4188:	2a0103e2 	mov	w2, w1
    418c:	394006f9 	ldrb	w25, [x23, #1]
    4190:	39400af4 	ldrb	w20, [x23, #2]
    4194:	b4000158 	cbz	x24, 41bc <fwp_mem_free+0xbc>
    4198:	92403e76 	and	x22, x19, #0xffff
    419c:	9ac20ad6 	udiv	x22, x22, x2
    41a0:	38766b01 	ldrb	w1, [x24, x22]
    41a4:	8b160300 	add	x0, x24, x22
    41a8:	7103fc3f 	cmp	w1, #0xff
    41ac:	54000980 	b.eq	42dc <fwp_mem_free+0x1dc>  // b.none
    41b0:	38366b1f 	strb	wzr, [x24, x22]
    41b4:	b94006e1 	ldr	w1, [x23, #4]
    41b8:	2a0103e2 	mov	w2, w1
    41bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41c4:	cb390000 	sub	x0, x0, w25, uxtb
    41c8:	8b340074 	add	x20, x3, w20, uxtb
    41cc:	911502b5 	add	x21, x21, #0x540
    41d0:	1e630021 	ucvtf	d1, w1
    41d4:	d37ae400 	lsl	x0, x0, #6
    41d8:	8b140c14 	add	x20, x0, x20, lsl #3
    41dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e0:	f8746aa0 	ldr	x0, [x21, x20]
    41e4:	f94023f9 	ldr	x25, [sp, #64]
    41e8:	aa2003e0 	mvn	x0, x0
    41ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    41f0:	f9000260 	str	x0, [x19]
    41f4:	f8346ab3 	str	x19, [x21, x20]
    41f8:	f94a12a0 	ldr	x0, [x21, #5152]
    41fc:	1e612800 	fadd	d0, d0, d1
    4200:	a94153f3 	ldp	x19, x20, [sp, #16]
    4204:	cb020000 	sub	x0, x0, x2
    4208:	f90a12a0 	str	x0, [x21, #5152]
    420c:	fd0a22a0 	str	d0, [x21, #5184]
    4210:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4214:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4218:	d65f03c0 	ret
    421c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4220:	8b000063 	add	x3, x3, x0
    4224:	eb03027f 	cmp	x19, x3
    4228:	54fff9e1 	b.ne	4164 <fwp_mem_free+0x64>  // b.any
    422c:	fd400ae1 	ldr	d1, [x23, #16]
    4230:	fd4a2020 	ldr	d0, [x1, #5184]
    4234:	f9400ae0 	ldr	x0, [x23, #16]
    4238:	7e61d821 	ucvtf	d1, d1
    423c:	f94a1022 	ldr	x2, [x1, #5152]
    4240:	f94012f3 	ldr	x19, [x23, #32]
    4244:	1e612800 	fadd	d0, d0, d1
    4248:	cb000042 	sub	x2, x2, x0
    424c:	f90a1022 	str	x2, [x1, #5152]
    4250:	fd0a2020 	str	d0, [x1, #5184]
    4254:	b40000b3 	cbz	x19, 4268 <fwp_mem_free+0x168>
    4258:	39400260 	ldrb	w0, [x19]
    425c:	7103fc1f 	cmp	w0, #0xff
    4260:	54000380 	b.eq	42d0 <fwp_mem_free+0x1d0>  // b.none
    4264:	3900027f 	strb	wzr, [x19]
    4268:	b9400ee2 	ldr	w2, [x23, #12]
    426c:	b4000142 	cbz	x2, 4294 <fwp_mem_free+0x194>
    4270:	911502a1 	add	x1, x21, #0x540
    4274:	8b160040 	add	x0, x2, x22
    4278:	8b000800 	add	x0, x0, x0, lsl #2
    427c:	f949fc21 	ldr	x1, [x1, #5112]
    4280:	8b140034 	add	x20, x1, x20
    4284:	8b000c20 	add	x0, x1, x0, lsl #3
    4288:	3802869f 	strb	wzr, [x20], #40
    428c:	eb00029f 	cmp	x20, x0
    4290:	54ffffc1 	b.ne	4288 <fwp_mem_free+0x188>  // b.any
    4294:	911502a0 	add	x0, x21, #0x540
    4298:	f94a1801 	ldr	x1, [x0, #5168]
    429c:	f949f803 	ldr	x3, [x0, #5104]
    42a0:	8b020021 	add	x1, x1, x2
    42a4:	f90a1801 	str	x1, [x0, #5168]
    42a8:	eb16007f 	cmp	x3, x22
    42ac:	54000049 	b.ls	42b4 <fwp_mem_free+0x1b4>  // b.plast
    42b0:	f909f816 	str	x22, [x0, #5104]
    42b4:	911502b5 	add	x21, x21, #0x540
    42b8:	f949f6a0 	ldr	x0, [x21, #5096]
    42bc:	eb16001f 	cmp	x0, x22
    42c0:	54fff529 	b.ls	4164 <fwp_mem_free+0x64>  // b.plast
    42c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42c8:	f909f6b6 	str	x22, [x21, #5096]
    42cc:	17ffffa7 	b	4168 <fwp_mem_free+0x68>
    42d0:	aa1303e0 	mov	x0, x19
    42d4:	97fffeef 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42d8:	17ffffe3 	b	4264 <fwp_mem_free+0x164>
    42dc:	97fffeed 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42e0:	17ffffb4 	b	41b0 <fwp_mem_free+0xb0>

00000000000042e4 <fwp_rc_wide_dup>:
    42e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42e8:	910003fd 	mov	x29, sp
    42ec:	a90153f3 	stp	x19, x20, [sp, #16]
    42f0:	aa0003f3 	mov	x19, x0
    42f4:	ca404400 	eor	x0, x0, x0, lsr #17
    42f8:	f90013f5 	str	x21, [sp, #32]
    42fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4300:	ca402400 	eor	x0, x0, x0, lsr #9
    4304:	911502a2 	add	x2, x21, #0x540
    4308:	92401c00 	and	x0, x0, #0xff
    430c:	910a2403 	add	x3, x0, #0x289
    4310:	8b000c40 	add	x0, x2, x0, lsl #3
    4314:	8b030c54 	add	x20, x2, x3, lsl #3
    4318:	f94a2401 	ldr	x1, [x0, #5192]
    431c:	b50000a1 	cbnz	x1, 4330 <fwp_rc_wide_dup+0x4c>
    4320:	14000033 	b	43ec <fwp_rc_wide_dup+0x108>
    4324:	91004034 	add	x20, x1, #0x10
    4328:	f9400821 	ldr	x1, [x1, #16]
    432c:	b4000241 	cbz	x1, 4374 <fwp_rc_wide_dup+0x90>
    4330:	f9400022 	ldr	x2, [x1]
    4334:	eb02027f 	cmp	x19, x2
    4338:	54ffff61 	b.ne	4324 <fwp_rc_wide_dup+0x40>  // b.any
    433c:	f9400281 	ldr	x1, [x20]
    4340:	39400260 	ldrb	w0, [x19]
    4344:	7103f81f 	cmp	w0, #0xfe
    4348:	54000220 	b.eq	438c <fwp_rc_wide_dup+0xa8>  // b.none
    434c:	b40001a1 	cbz	x1, 4380 <fwp_rc_wide_dup+0x9c>
    4350:	f9400420 	ldr	x0, [x1, #8]
    4354:	b100041f 	cmn	x0, #0x1
    4358:	54000440 	b.eq	43e0 <fwp_rc_wide_dup+0xfc>  // b.none
    435c:	91000400 	add	x0, x0, #0x1
    4360:	f9000420 	str	x0, [x1, #8]
    4364:	a94153f3 	ldp	x19, x20, [sp, #16]
    4368:	f94013f5 	ldr	x21, [sp, #32]
    436c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4370:	d65f03c0 	ret
    4374:	39400260 	ldrb	w0, [x19]
    4378:	7103f81f 	cmp	w0, #0xfe
    437c:	54000100 	b.eq	439c <fwp_rc_wide_dup+0xb8>  // b.none
    4380:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    4384:	913f0000 	add	x0, x0, #0xfc0
    4388:	97fffea2 	bl	3e10 <fwp_trap>
    438c:	b4000081 	cbz	x1, 439c <fwp_rc_wide_dup+0xb8>
    4390:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    4394:	913fa000 	add	x0, x0, #0xfe8
    4398:	97fffe9e 	bl	3e10 <fwp_trap>
    439c:	d2800300 	mov	x0, #0x18                  	// #24
    43a0:	97fff8fc 	bl	2790 <malloc@plt>
    43a4:	b4000280 	cbz	x0, 43f4 <fwp_rc_wide_dup+0x110>
    43a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    43ac:	a9000413 	stp	x19, x1, [x0]
    43b0:	911502b5 	add	x21, x21, #0x540
    43b4:	f900081f 	str	xzr, [x0, #16]
    43b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43bc:	f9000280 	str	x0, [x20]
    43c0:	39000261 	strb	w1, [x19]
    43c4:	f94e26a0 	ldr	x0, [x21, #7240]
    43c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43cc:	91000400 	add	x0, x0, #0x1
    43d0:	f90e26a0 	str	x0, [x21, #7240]
    43d4:	f94013f5 	ldr	x21, [sp, #32]
    43d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43dc:	d65f03c0 	ret
    43e0:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    43e4:	91004000 	add	x0, x0, #0x10
    43e8:	97fffe8a 	bl	3e10 <fwp_trap>
    43ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43f0:	17ffffd4 	b	4340 <fwp_rc_wide_dup+0x5c>
    43f4:	97fffaef 	bl	2fb0 <fwp_heap_oom>
    43f8:	d503201f 	nop
    43fc:	d503201f 	nop

0000000000004400 <fwp_closure_drop_push>:
    4400:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	a9408014 	ldp	x20, x0, [x0, #8]
    4414:	a9025bf5 	stp	x21, x22, [sp, #32]
    4418:	aa0103f5 	mov	x21, x1
    441c:	a90363f7 	stp	x23, x24, [sp, #48]
    4420:	eb00029f 	cmp	x20, x0
    4424:	54000160 	b.eq	4450 <fwp_closure_drop_push+0x50>  // b.none
    4428:	f9400276 	ldr	x22, [x19]
    442c:	d37df297 	lsl	x23, x20, #3
    4430:	91000694 	add	x20, x20, #0x1
    4434:	f9000674 	str	x20, [x19, #8]
    4438:	a94153f3 	ldp	x19, x20, [sp, #16]
    443c:	f8376ad5 	str	x21, [x22, x23]
    4440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4444:	a94363f7 	ldp	x23, x24, [sp, #48]
    4448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    444c:	d65f03c0 	ret
    4450:	a9046bf9 	stp	x25, x26, [sp, #64]
    4454:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4458:	eb00029f 	cmp	x20, x0
    445c:	540003e8 	b.hi	44d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4460:	d37cee99 	lsl	x25, x20, #4
    4464:	d37ffa9a 	lsl	x26, x20, #1
    4468:	aa1903e0 	mov	x0, x25
    446c:	97fff8c9 	bl	2790 <malloc@plt>
    4470:	aa0003f6 	mov	x22, x0
    4474:	b4000380 	cbz	x0, 44e4 <fwp_closure_drop_push+0xe4>
    4478:	aa1303f8 	mov	x24, x19
    447c:	aa1903e3 	mov	x3, x25
    4480:	d37df297 	lsl	x23, x20, #3
    4484:	aa1703e2 	mov	x2, x23
    4488:	f8418719 	ldr	x25, [x24], #24
    448c:	aa1903e1 	mov	x1, x25
    4490:	97fff8ac 	bl	2740 <__memcpy_chk@plt>
    4494:	eb18033f 	cmp	x25, x24
    4498:	540000a0 	b.eq	44ac <fwp_closure_drop_push+0xac>  // b.none
    449c:	aa1903e0 	mov	x0, x25
    44a0:	97fff904 	bl	28b0 <free@plt>
    44a4:	f9400674 	ldr	x20, [x19, #8]
    44a8:	d37df297 	lsl	x23, x20, #3
    44ac:	91000694 	add	x20, x20, #0x1
    44b0:	f9000276 	str	x22, [x19]
    44b4:	f9000a7a 	str	x26, [x19, #16]
    44b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44bc:	f9000674 	str	x20, [x19, #8]
    44c0:	f8376ad5 	str	x21, [x22, x23]
    44c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44d4:	d65f03c0 	ret
    44d8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    44dc:	9100c000 	add	x0, x0, #0x30
    44e0:	97fffe4c 	bl	3e10 <fwp_trap>
    44e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    44e8:	f947e863 	ldr	x3, [x3, #4048]
    44ec:	d2800262 	mov	x2, #0x13                  	// #19
    44f0:	d2800021 	mov	x1, #0x1                   	// #1
    44f4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    44f8:	913a2000 	add	x0, x0, #0xe88
    44fc:	f9400063 	ldr	x3, [x3]
    4500:	97fff8fc 	bl	28f0 <fwrite@plt>
    4504:	d2800000 	mov	x0, #0x0                   	// #0
    4508:	97fff906 	bl	2920 <fflush@plt>
    450c:	52800cc0 	mov	w0, #0x66                  	// #102
    4510:	97fff914 	bl	2960 <_Exit@plt>

0000000000004514 <fwp_closure_drop.part.0>:
    4514:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4518:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x180>
    451c:	910003fd 	mov	x29, sp
    4520:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4524:	f947f463 	ldr	x3, [x3, #4072]
    4528:	a90153f3 	stp	x19, x20, [sp, #16]
    452c:	d10883ff 	sub	sp, sp, #0x220
    4530:	910003e2 	mov	x2, sp
    4534:	d53bd053 	mrs	x19, tpidr_el0
    4538:	910063f4 	add	x20, sp, #0x18
    453c:	3dc2cc20 	ldr	q0, [x1, #2864]
    4540:	91400264 	add	x4, x19, #0x0, lsl #12
    4544:	91004084 	add	x4, x4, #0x10
    4548:	aa0003e1 	mov	x1, x0
    454c:	aa0203e0 	mov	x0, x2
    4550:	f9400062 	ldr	x2, [x3]
    4554:	f9010fe2 	str	x2, [sp, #536]
    4558:	d2800002 	mov	x2, #0x0                   	// #0
    455c:	f90003f4 	str	x20, [sp]
    4560:	f9000080 	str	x0, [x4]
    4564:	3c8083e0 	stur	q0, [sp, #8]
    4568:	97ffffa6 	bl	4400 <fwp_closure_drop_push>
    456c:	f94007e0 	ldr	x0, [sp, #8]
    4570:	b40002e0 	cbz	x0, 45cc <fwp_closure_drop.part.0+0xb8>
    4574:	f90123f5 	str	x21, [sp, #576]
    4578:	900000f5 	adrp	x21, 20000 <__data_start>
    457c:	9100c2b5 	add	x21, x21, #0x30
    4580:	14000006 	b	4598 <fwp_closure_drop.part.0+0x84>
    4584:	f9400422 	ldr	x2, [x1, #8]
    4588:	52800001 	mov	w1, #0x0                   	// #0
    458c:	d63f0040 	blr	x2
    4590:	f94007e0 	ldr	x0, [sp, #8]
    4594:	b40001a0 	cbz	x0, 45c8 <fwp_closure_drop.part.0+0xb4>
    4598:	f94003e1 	ldr	x1, [sp]
    459c:	d1000400 	sub	x0, x0, #0x1
    45a0:	f90007e0 	str	x0, [sp, #8]
    45a4:	f9403ea2 	ldr	x2, [x21, #120]
    45a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    45ac:	b9400001 	ldr	w1, [x0]
    45b0:	8b011441 	add	x1, x2, x1, lsl #5
    45b4:	f9400c21 	ldr	x1, [x1, #24]
    45b8:	b5fffe61 	cbnz	x1, 4584 <fwp_closure_drop.part.0+0x70>
    45bc:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    45c0:	91014000 	add	x0, x0, #0x50
    45c4:	97fffe13 	bl	3e10 <fwp_trap>
    45c8:	f94123f5 	ldr	x21, [sp, #576]
    45cc:	91400273 	add	x19, x19, #0x0, lsl #12
    45d0:	91004273 	add	x19, x19, #0x10
    45d4:	f94003e0 	ldr	x0, [sp]
    45d8:	f900027f 	str	xzr, [x19]
    45dc:	eb14001f 	cmp	x0, x20
    45e0:	54000040 	b.eq	45e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45e4:	97fff8b3 	bl	28b0 <free@plt>
    45e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45ec:	f947f400 	ldr	x0, [x0, #4072]
    45f0:	f9410fe2 	ldr	x2, [sp, #536]
    45f4:	f9400001 	ldr	x1, [x0]
    45f8:	eb010042 	subs	x2, x2, x1
    45fc:	d2800001 	mov	x1, #0x0                   	// #0
    4600:	540000a1 	b.ne	4614 <fwp_closure_drop.part.0+0x100>  // b.any
    4604:	910883ff 	add	sp, sp, #0x220
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4610:	d65f03c0 	ret
    4614:	f90123f5 	str	x21, [sp, #576]
    4618:	97fff876 	bl	27f0 <__stack_chk_fail@plt>
    461c:	d503201f 	nop

0000000000004620 <fwp_tape_of>:
    4620:	aa0003e1 	mov	x1, x0
    4624:	92403c00 	and	x0, x0, #0xffff
    4628:	b40000e0 	cbz	x0, 4644 <fwp_tape_of+0x24>
    462c:	d1000402 	sub	x2, x0, #0x1
    4630:	900000e3 	adrp	x3, 20000 <__data_start>
    4634:	9100c060 	add	x0, x3, #0x30
    4638:	f9404000 	ldr	x0, [x0, #128]
    463c:	eb02001f 	cmp	x0, x2
    4640:	540000cc 	b.gt	4658 <fwp_tape_of+0x38>
    4644:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4648:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    464c:	91020000 	add	x0, x0, #0x80
    4650:	910003fd 	mov	x29, sp
    4654:	97fffdef 	bl	3e10 <fwp_trap>
    4658:	8b020440 	add	x0, x2, x2, lsl #1
    465c:	f9401863 	ldr	x3, [x3, #48]
    4660:	8b000842 	add	x2, x2, x0, lsl #2
    4664:	d37df042 	lsl	x2, x2, #3
    4668:	8b020060 	add	x0, x3, x2
    466c:	b9400404 	ldr	w4, [x0, #4]
    4670:	34fffea4 	cbz	w4, 4644 <fwp_tape_of+0x24>
    4674:	b8626862 	ldr	w2, [x3, x2]
    4678:	9350fc21 	asr	x1, x1, #16
    467c:	6b01005f 	cmp	w2, w1
    4680:	54fffe21 	b.ne	4644 <fwp_tape_of+0x24>  // b.any
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_now_ns>:
    4690:	d100c3ff 	sub	sp, sp, #0x30
    4694:	52800020 	mov	w0, #0x1                   	// #1
    4698:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    469c:	f947f442 	ldr	x2, [x2, #4072]
    46a0:	910023e1 	add	x1, sp, #0x8
    46a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a8:	910083fd 	add	x29, sp, #0x20
    46ac:	f9400043 	ldr	x3, [x2]
    46b0:	f9000fe3 	str	x3, [sp, #24]
    46b4:	d2800003 	mov	x3, #0x0                   	// #0
    46b8:	97fff81a 	bl	2720 <clock_gettime@plt>
    46bc:	350002c0 	cbnz	w0, 4714 <fwp_now_ns+0x84>
    46c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46c4:	d2994003 	mov	x3, #0xca00                	// #51712
    46c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46cc:	9b037c20 	mul	x0, x1, x3
    46d0:	9b437c21 	smulh	x1, x1, x3
    46d4:	ab020000 	adds	x0, x0, x2
    46d8:	937ffc42 	asr	x2, x2, #63
    46dc:	9a020021 	adc	x1, x1, x2
    46e0:	f100001f 	cmp	x0, #0x0
    46e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46e8:	b50001c1 	cbnz	x1, 4720 <fwp_now_ns+0x90>
    46ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    46f0:	f947f421 	ldr	x1, [x1, #4072]
    46f4:	f9400fe3 	ldr	x3, [sp, #24]
    46f8:	f9400022 	ldr	x2, [x1]
    46fc:	eb020063 	subs	x3, x3, x2
    4700:	d2800002 	mov	x2, #0x0                   	// #0
    4704:	54000141 	b.ne	472c <fwp_now_ns+0x9c>  // b.any
    4708:	a9427bfd 	ldp	x29, x30, [sp, #32]
    470c:	9100c3ff 	add	sp, sp, #0x30
    4710:	d65f03c0 	ret
    4714:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    4718:	91034000 	add	x0, x0, #0xd0
    471c:	97fffdbd 	bl	3e10 <fwp_trap>
    4720:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    4724:	9103c000 	add	x0, x0, #0xf0
    4728:	97fffdba 	bl	3e10 <fwp_trap>
    472c:	97fff831 	bl	27f0 <__stack_chk_fail@plt>

0000000000004730 <fwp_poll_events>:
    4730:	d10103ff 	sub	sp, sp, #0x40
    4734:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4738:	f947f400 	ldr	x0, [x0, #4072]
    473c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4740:	910083fd 	add	x29, sp, #0x20
    4744:	f9001bf3 	str	x19, [sp, #48]
    4748:	900000f3 	adrp	x19, 20000 <__data_start>
    474c:	f9400001 	ldr	x1, [x0]
    4750:	f9000fe1 	str	x1, [sp, #24]
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	97ffffce 	bl	4690 <fwp_now_ns>
    475c:	9100c261 	add	x1, x19, #0x30
    4760:	f9404421 	ldr	x1, [x1, #136]
    4764:	b4000e01 	cbz	x1, 4924 <fwp_poll_events+0x1f4>
    4768:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    476c:	14000005 	b	4780 <fwp_poll_events+0x50>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	eb03005f 	cmp	x2, x3
    4778:	9a83d042 	csel	x2, x2, x3, le
    477c:	b40000c1 	cbz	x1, 4794 <fwp_poll_events+0x64>
    4780:	f9403423 	ldr	x3, [x1, #104]
    4784:	b6ffff62 	tbz	x2, #63, 4770 <fwp_poll_events+0x40>
    4788:	f9408821 	ldr	x1, [x1, #272]
    478c:	aa0303e2 	mov	x2, x3
    4790:	b5ffff81 	cbnz	x1, 4780 <fwp_poll_events+0x50>
    4794:	b7f80c82 	tbnz	x2, #63, 4924 <fwp_poll_events+0x1f4>
    4798:	cb000042 	sub	x2, x2, x0
    479c:	f100005f 	cmp	x2, #0x0
    47a0:	540003ad 	b.le	4814 <fwp_poll_events+0xe4>
    47a4:	d2869b60 	mov	x0, #0x34db                	// #13531
    47a8:	d2884804 	mov	x4, #0x4240                	// #16960
    47ac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47b0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47b4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47b8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47bc:	f2e86360 	movk	x0, #0x431b, lsl #48
    47c0:	9b407c40 	smulh	x0, x2, x0
    47c4:	9352fc00 	asr	x0, x0, #18
    47c8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47cc:	9b048802 	msub	x2, x0, x4, x2
    47d0:	f100005f 	cmp	x2, #0x0
    47d4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47d8:	eb01001f 	cmp	x0, x1
    47dc:	5400098c 	b.gt	490c <fwp_poll_events+0x1dc>
    47e0:	340001a0 	cbz	w0, 4814 <fwp_poll_events+0xe4>
    47e4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47e8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47ec:	72a20c41 	movk	w1, #0x1062, lsl #16
    47f0:	9ba17c01 	umull	x1, w0, w1
    47f4:	d366fc23 	lsr	x3, x1, #38
    47f8:	aa0303e2 	mov	x2, x3
    47fc:	1b058063 	msub	w3, w3, w5, w0
    4800:	9b247c63 	smull	x3, w3, w4
    4804:	910023e0 	add	x0, sp, #0x8
    4808:	d2800001 	mov	x1, #0x0                   	// #0
    480c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4810:	97fff82c 	bl	28c0 <nanosleep@plt>
    4814:	97ffff9f 	bl	4690 <fwp_now_ns>
    4818:	9100c268 	add	x8, x19, #0x30
    481c:	aa0003e7 	mov	x7, x0
    4820:	4f000400 	movi	v0.4s, #0x0
    4824:	52800029 	mov	w9, #0x1                   	// #1
    4828:	f9404506 	ldr	x6, [x8, #136]
    482c:	d503201f 	nop
    4830:	b40003e6 	cbz	x6, 48ac <fwp_poll_events+0x17c>
    4834:	f94034c1 	ldr	x1, [x6, #104]
    4838:	aa0603e5 	mov	x5, x6
    483c:	f94088c6 	ldr	x6, [x6, #272]
    4840:	eb07003f 	cmp	x1, x7
    4844:	54ffff6c 	b.gt	4830 <fwp_poll_events+0x100>
    4848:	394154a0 	ldrb	w0, [x5, #85]
    484c:	36000120 	tbz	w0, #0, 4870 <fwp_poll_events+0x140>
    4850:	f94084a0 	ldr	x0, [x5, #264]
    4854:	b4000560 	cbz	x0, 4900 <fwp_poll_events+0x1d0>
    4858:	f9008806 	str	x6, [x0, #272]
    485c:	b4000046 	cbz	x6, 4864 <fwp_poll_events+0x134>
    4860:	f90084c0 	str	x0, [x6, #264]
    4864:	910800a0 	add	x0, x5, #0x200
    4868:	390154bf 	strb	wzr, [x5, #85]
    486c:	3c908000 	stur	q0, [x0, #-248]
    4870:	f94030a0 	ldr	x0, [x5, #96]
    4874:	390158a9 	strb	w9, [x5, #86]
    4878:	f100001f 	cmp	x0, #0x0
    487c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4880:	540002cd 	b.le	48d8 <fwp_poll_events+0x1a8>
    4884:	f94028a0 	ldr	x0, [x5, #80]
    4888:	f2001c1f 	tst	x0, #0xff000000ff
    488c:	54fffd21 	b.ne	4830 <fwp_poll_events+0x100>  // b.any
    4890:	f9401500 	ldr	x0, [x8, #40]
    4894:	390150a9 	strb	w9, [x5, #84]
    4898:	f90080bf 	str	xzr, [x5, #256]
    489c:	b40002c0 	cbz	x0, 48f4 <fwp_poll_events+0x1c4>
    48a0:	f9001505 	str	x5, [x8, #40]
    48a4:	f9008005 	str	x5, [x0, #256]
    48a8:	b5fffc66 	cbnz	x6, 4834 <fwp_poll_events+0x104>
    48ac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48b0:	f947f400 	ldr	x0, [x0, #4072]
    48b4:	f9400fe2 	ldr	x2, [sp, #24]
    48b8:	f9400001 	ldr	x1, [x0]
    48bc:	eb010042 	subs	x2, x2, x1
    48c0:	d2800001 	mov	x1, #0x0                   	// #0
    48c4:	540002e1 	b.ne	4920 <fwp_poll_events+0x1f0>  // b.any
    48c8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48cc:	f9401bf3 	ldr	x19, [sp, #48]
    48d0:	910103ff 	add	sp, sp, #0x40
    48d4:	d65f03c0 	ret
    48d8:	394144a0 	ldrb	w0, [x5, #81]
    48dc:	3707fd40 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e0:	394140a0 	ldrb	w0, [x5, #80]
    48e4:	3707fd00 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e8:	aa0503e0 	mov	x0, x5
    48ec:	97fffac1 	bl	33f0 <fwp_cancel_tree.part.0>
    48f0:	17ffffe5 	b	4884 <fwp_poll_events+0x154>
    48f4:	f9001505 	str	x5, [x8, #40]
    48f8:	f9001905 	str	x5, [x8, #48]
    48fc:	17ffffeb 	b	48a8 <fwp_poll_events+0x178>
    4900:	9100c261 	add	x1, x19, #0x30
    4904:	f9004426 	str	x6, [x1, #136]
    4908:	17ffffd5 	b	485c <fwp_poll_events+0x12c>
    490c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4910:	d2989362 	mov	x2, #0xc49b                	// #50331
    4914:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4918:	f2a00402 	movk	x2, #0x20, lsl #16
    491c:	17ffffba 	b	4804 <fwp_poll_events+0xd4>
    4920:	97fff7b4 	bl	27f0 <__stack_chk_fail@plt>
    4924:	97fff993 	bl	2f70 <fwp_flush>
    4928:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    492c:	f947e863 	ldr	x3, [x3, #4048]
    4930:	d2800562 	mov	x2, #0x2b                  	// #43
    4934:	d2800021 	mov	x1, #0x1                   	// #1
    4938:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    493c:	91046000 	add	x0, x0, #0x118
    4940:	f9400063 	ldr	x3, [x3]
    4944:	97fff7eb 	bl	28f0 <fwrite@plt>
    4948:	52800ca0 	mov	w0, #0x65                  	// #101
    494c:	97fff755 	bl	26a0 <exit@plt>

0000000000004950 <fwp_heap_alloc_big>:
    4950:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4954:	910003fd 	mov	x29, sp
    4958:	a90153f3 	stp	x19, x20, [sp, #16]
    495c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4960:	a90363f7 	stp	x23, x24, [sp, #48]
    4964:	aa0003f7 	mov	x23, x0
    4968:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    496c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4970:	eb0002ff 	cmp	x23, x0
    4974:	540008a8 	b.hi	4a88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4978:	d29fffe0 	mov	x0, #0xffff                	// #65535
    497c:	8b0002f4 	add	x20, x23, x0
    4980:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4984:	91150359 	add	x25, x26, #0x540
    4988:	d350fe94 	lsr	x20, x20, #16
    498c:	2a0103f5 	mov	w21, w1
    4990:	aa1403e0 	mov	x0, x20
    4994:	97fff9c7 	bl	30b0 <fwp_heap_chunks>
    4998:	f949ff22 	ldr	x2, [x25, #5112]
    499c:	8b000813 	add	x19, x0, x0, lsl #2
    49a0:	aa0003f8 	mov	x24, x0
    49a4:	52800043 	mov	w3, #0x2                   	// #2
    49a8:	d37df273 	lsl	x19, x19, #3
    49ac:	d2800021 	mov	x1, #0x1                   	// #1
    49b0:	8b130040 	add	x0, x2, x19
    49b4:	38336843 	strb	w3, [x2, x19]
    49b8:	39000415 	strb	w21, [x0, #1]
    49bc:	b9000c14 	str	w20, [x0, #12]
    49c0:	f9000817 	str	x23, [x0, #16]
    49c4:	97fffd57 	bl	3f20 <fwp_rc_prepare_chunk>
    49c8:	f100069f 	cmp	x20, #0x1
    49cc:	54000289 	b.ls	4a1c <fwp_heap_alloc_big+0xcc>  // b.plast
    49d0:	8b180294 	add	x20, x20, x24
    49d4:	9100a273 	add	x19, x19, #0x28
    49d8:	a90573fb 	stp	x27, x28, [sp, #80]
    49dc:	5280007b 	mov	w27, #0x3                   	// #3
    49e0:	8b140a94 	add	x20, x20, x20, lsl #2
    49e4:	2a1803fc 	mov	w28, w24
    49e8:	9adb2296 	lsl	x22, x20, x27
    49ec:	d503201f 	nop
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffd48 	bl	3f20 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91150353 	add	x19, x26, #0x540
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x108>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115035a 	add	x26, x26, #0x540
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4aa0:	91150262 	add	x2, x19, #0x540
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91150262 	add	x2, x19, #0x540
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91150260 	add	x0, x19, #0x540
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91150273 	add	x19, x19, #0x540
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffbbf 	bl	3a70 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff6f 	b	4950 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91150260 	add	x0, x19, #0x540
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffd19 	bl	4040 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c04:	91150293 	add	x19, x20, #0x540
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91150294 	add	x20, x20, #0x540
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	9100c2f7 	add	x23, x23, #0x30
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9403ee0 	ldr	x0, [x23, #120]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_tape_grow.constprop.0>:
    4f24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4f28:	d2800803 	mov	x3, #0x40                  	// #64
    4f2c:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f30:	910003fd 	mov	x29, sp
    4f34:	a90153f3 	stp	x19, x20, [sp, #16]
    4f38:	f9400c13 	ldr	x19, [x0, #24]
    4f3c:	a90363f7 	stp	x23, x24, [sp, #48]
    4f40:	aa0003f7 	mov	x23, x0
    4f44:	f100027f 	cmp	x19, #0x0
    4f48:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    4f4c:	eb13003f 	cmp	x1, x19
    4f50:	540000ed 	b.le	4f6c <fwp_tape_grow.constprop.0+0x48>
    4f54:	eb02027f 	cmp	x19, x2
    4f58:	5400076d 	b.le	5044 <fwp_tape_grow.constprop.0+0x120>
    4f5c:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4f60:	eb13003f 	cmp	x1, x19
    4f64:	5400004d 	b.le	4f6c <fwp_tape_grow.constprop.0+0x48>
    4f68:	14000000 	b	4f68 <fwp_tape_grow.constprop.0+0x44>
    4f6c:	a940d2e2 	ldp	x2, x20, [x23, #8]
    4f70:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f74:	d37df276 	lsl	x22, x19, #3
    4f78:	f94012e0 	ldr	x0, [x23, #32]
    4f7c:	aa1603e1 	mov	x1, x22
    4f80:	f94032f5 	ldr	x21, [x23, #96]
    4f84:	cb020294 	sub	x20, x20, x2
    4f88:	97fff616 	bl	27e0 <realloc@plt>
    4f8c:	b4000c20 	cbz	x0, 5110 <fwp_tape_grow.constprop.0+0x1ec>
    4f90:	f9400ee1 	ldr	x1, [x23, #24]
    4f94:	8b010801 	add	x1, x0, x1, lsl #2
    4f98:	a90206e0 	stp	x0, x1, [x23, #32]
    4f9c:	b4000895 	cbz	x21, 50ac <fwp_tape_grow.constprop.0+0x188>
    4fa0:	f94032b6 	ldr	x22, [x21, #96]
    4fa4:	eb1302df 	cmp	x22, x19
    4fa8:	540003aa 	b.ge	501c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    4fac:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4fb4:	eb00027f 	cmp	x19, x0
    4fb8:	54000a68 	b.hi	5104 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    4fbc:	f94022b9 	ldr	x25, [x21, #64]
    4fc0:	d37cee7a 	lsl	x26, x19, #4
    4fc4:	aa1a03e0 	mov	x0, x26
    4fc8:	52800041 	mov	w1, #0x2                   	// #2
    4fcc:	97ffff09 	bl	4bf0 <fwp_heap_alloc>
    4fd0:	aa0003f8 	mov	x24, x0
    4fd4:	b4000119 	cbz	x25, 4ff4 <fwp_tape_grow.constprop.0+0xd0>
    4fd8:	d37ceed6 	lsl	x22, x22, #4
    4fdc:	aa1903e1 	mov	x1, x25
    4fe0:	eb1a02df 	cmp	x22, x26
    4fe4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    4fe8:	97fff596 	bl	2640 <memcpy@plt>
    4fec:	aa1903e0 	mov	x0, x25
    4ff0:	97fffc44 	bl	4100 <fwp_mem_free>
    4ff4:	f94032a0 	ldr	x0, [x21, #96]
    4ff8:	52800001 	mov	w1, #0x0                   	// #0
    4ffc:	cb000262 	sub	x2, x19, x0
    5000:	8b001300 	add	x0, x24, x0, lsl #4
    5004:	d37cec42 	lsl	x2, x2, #4
    5008:	97fff5ee 	bl	27c0 <memset@plt>
    500c:	f94012e0 	ldr	x0, [x23, #32]
    5010:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5014:	f90022b8 	str	x24, [x21, #64]
    5018:	f90032b3 	str	x19, [x21, #96]
    501c:	d37ef675 	lsl	x21, x19, #2
    5020:	b50002b4 	cbnz	x20, 5074 <fwp_tape_grow.constprop.0+0x150>
    5024:	8b150001 	add	x1, x0, x21
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000ef3 	str	x19, [x23, #24]
    5030:	f90016e1 	str	x1, [x23, #40]
    5034:	a94153f3 	ldp	x19, x20, [sp, #16]
    5038:	a94363f7 	ldp	x23, x24, [sp, #48]
    503c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5040:	d65f03c0 	ret
    5044:	d37ffa73 	lsl	x19, x19, #1
    5048:	17ffffc1 	b	4f4c <fwp_tape_grow.constprop.0+0x28>
    504c:	eb1502df 	cmp	x22, x21
    5050:	aa0403e0 	mov	x0, x4
    5054:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    5058:	d37df282 	lsl	x2, x20, #3
    505c:	cb160063 	sub	x3, x3, x22
    5060:	97fff64c 	bl	2990 <__memmove_chk@plt>
    5064:	f9401ae1 	ldr	x1, [x23, #48]
    5068:	f94012e0 	ldr	x0, [x23, #32]
    506c:	8b160021 	add	x1, x1, x22
    5070:	f9001ee1 	str	x1, [x23, #56]
    5074:	f94016e1 	ldr	x1, [x23, #40]
    5078:	d37ef675 	lsl	x21, x19, #2
    507c:	d37ef682 	lsl	x2, x20, #2
    5080:	8b150000 	add	x0, x0, x21
    5084:	97fff577 	bl	2660 <memmove@plt>
    5088:	f94012e0 	ldr	x0, [x23, #32]
    508c:	8b150001 	add	x1, x0, x21
    5090:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5094:	f9000ef3 	str	x19, [x23, #24]
    5098:	f90016e1 	str	x1, [x23, #40]
    509c:	a94153f3 	ldp	x19, x20, [sp, #16]
    50a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    50a4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    50a8:	d65f03c0 	ret
    50ac:	f9401ae0 	ldr	x0, [x23, #48]
    50b0:	d37cee75 	lsl	x21, x19, #4
    50b4:	aa1503e1 	mov	x1, x21
    50b8:	97fff5ca 	bl	27e0 <realloc@plt>
    50bc:	b40002a0 	cbz	x0, 5110 <fwp_tape_grow.constprop.0+0x1ec>
    50c0:	f9400ee2 	ldr	x2, [x23, #24]
    50c4:	f9001ae0 	str	x0, [x23, #48]
    50c8:	8b160004 	add	x4, x0, x22
    50cc:	8b020c01 	add	x1, x0, x2, lsl #3
    50d0:	f9001ee1 	str	x1, [x23, #56]
    50d4:	b5fffbd4 	cbnz	x20, 504c <fwp_tape_grow.constprop.0+0x128>
    50d8:	f94012e0 	ldr	x0, [x23, #32]
    50dc:	d37ef675 	lsl	x21, x19, #2
    50e0:	f9001ee4 	str	x4, [x23, #56]
    50e4:	8b150001 	add	x1, x0, x21
    50e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50ec:	f9000ef3 	str	x19, [x23, #24]
    50f0:	f90016e1 	str	x1, [x23, #40]
    50f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5100:	d65f03c0 	ret
    5104:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    5108:	9105c000 	add	x0, x0, #0x170
    510c:	97fffb41 	bl	3e10 <fwp_trap>
    5110:	aa1703e0 	mov	x0, x23
    5114:	a9046bf9 	stp	x25, x26, [sp, #64]
    5118:	97fff77e 	bl	2f10 <fwp_tape_unlink_scope>
    511c:	f94012e0 	ldr	x0, [x23, #32]
    5120:	97fff5e4 	bl	28b0 <free@plt>
    5124:	f9401ae0 	ldr	x0, [x23, #48]
    5128:	97fff5e2 	bl	28b0 <free@plt>
    512c:	f94022e0 	ldr	x0, [x23, #64]
    5130:	97fff5e0 	bl	28b0 <free@plt>
    5134:	f9000eff 	str	xzr, [x23, #24]
    5138:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    513c:	f947e821 	ldr	x1, [x1, #4048]
    5140:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5144:	d2800262 	mov	x2, #0x13                  	// #19
    5148:	4f000400 	movi	v0.4s, #0x0
    514c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    5150:	f9400023 	ldr	x3, [x1]
    5154:	b90006ff 	str	wzr, [x23, #4]
    5158:	d2800021 	mov	x1, #0x1                   	// #1
    515c:	913a2000 	add	x0, x0, #0xe88
    5160:	3c8082e0 	stur	q0, [x23, #8]
    5164:	ad0102e0 	stp	q0, q0, [x23, #32]
    5168:	97fff5e2 	bl	28f0 <fwrite@plt>
    516c:	d2800000 	mov	x0, #0x0                   	// #0
    5170:	97fff5ec 	bl	2920 <fflush@plt>
    5174:	52800cc0 	mov	w0, #0x66                  	// #102
    5178:	97fff5fa 	bl	2960 <_Exit@plt>
    517c:	d503201f 	nop

0000000000005180 <f128.constprop.0>:
    5180:	f100001f 	cmp	x0, #0x0
    5184:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5188:	54000a2b 	b.lt	52cc <f128.constprop.0+0x14c>  // b.tstop
    518c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5190:	aa0003e2 	mov	x2, x0
    5194:	910003fd 	mov	x29, sp
    5198:	a90153f3 	stp	x19, x20, [sp, #16]
    519c:	aa0003f4 	mov	x20, x0
    51a0:	aa010000 	orr	x0, x0, x1
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	aa0103f6 	mov	x22, x1
    51ac:	f9001bf7 	str	x23, [sp, #48]
    51b0:	fd001fe8 	str	d8, [sp, #56]
    51b4:	b7f80180 	tbnz	x0, #63, 51e4 <f128.constprop.0+0x64>
    51b8:	9360fc20 	asr	x0, x1, #32
    51bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51c0:	eb82801f 	cmp	x0, x2, asr #32
    51c4:	54000881 	b.ne	52d4 <f128.constprop.0+0x154>  // b.any
    51c8:	97fffd16 	bl	4620 <fwp_tape_of>
    51cc:	aa0003f3 	mov	x19, x0
    51d0:	f9403000 	ldr	x0, [x0, #96]
    51d4:	b40001e0 	cbz	x0, 5210 <f128.constprop.0+0x90>
    51d8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    51dc:	91076000 	add	x0, x0, #0x1d8
    51e0:	97fffb0c 	bl	3e10 <fwp_trap>
    51e4:	9360fc40 	asr	x0, x2, #32
    51e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51ec:	b6fffee2 	tbz	x2, #63, 51c8 <f128.constprop.0+0x48>
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc20 	asr	x0, x1, #32
    51f8:	aa0103f4 	mov	x20, x1
    51fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5200:	97fffd08 	bl	4620 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5fffe60 	cbnz	x0, 51d8 <f128.constprop.0+0x58>
    5210:	f9400a77 	ldr	x23, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002ff 	cmp	x23, x0
    521c:	5400046c 	b.gt	52a8 <f128.constprop.0+0x128>
    5220:	eb3442ff 	cmp	x23, w20, uxtw
    5224:	540004ed 	b.le	52c0 <f128.constprop.0+0x140>
    5228:	b7f80076 	tbnz	x22, #63, 5234 <f128.constprop.0+0xb4>
    522c:	eb3642ff 	cmp	x23, w22, uxtw
    5230:	5400048d 	b.le	52c0 <f128.constprop.0+0x140>
    5234:	f9400675 	ldr	x21, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1502f5 	sub	x21, x23, x21
    5240:	910006a1 	add	x1, x21, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000308 	b.hi	52a8 <f128.constprop.0+0x128>  // b.pmore
    524c:	f9400e60 	ldr	x0, [x19, #24]
    5250:	eb00003f 	cmp	x1, x0
    5254:	5400030c 	b.gt	52b4 <f128.constprop.0+0x134>
    5258:	a9420262 	ldp	x2, x0, [x19, #32]
    525c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5260:	f9401a61 	ldr	x1, [x19, #48]
    5264:	b8357854 	str	w20, [x2, x21, lsl #2]
    5268:	f9401e62 	ldr	x2, [x19, #56]
    526c:	f10002df 	cmp	x22, #0x0
    5270:	fc357820 	str	d0, [x1, x21, lsl #3]
    5274:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5278:	b8357816 	str	w22, [x0, x21, lsl #2]
    527c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5280:	910006e1 	add	x1, x23, #0x1
    5284:	aa170000 	orr	x0, x0, x23
    5288:	fc357848 	str	d8, [x2, x21, lsl #3]
    528c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5290:	f9401bf7 	ldr	x23, [sp, #48]
    5294:	fd401fe8 	ldr	d8, [sp, #56]
    5298:	f9000a61 	str	x1, [x19, #16]
    529c:	a94153f3 	ldp	x19, x20, [sp, #16]
    52a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52a4:	d65f03c0 	ret
    52a8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    52ac:	9105c000 	add	x0, x0, #0x170
    52b0:	97fffad8 	bl	3e10 <fwp_trap>
    52b4:	aa1303e0 	mov	x0, x19
    52b8:	97ffff1b 	bl	4f24 <fwp_tape_grow.constprop.0>
    52bc:	17ffffe7 	b	5258 <f128.constprop.0+0xd8>
    52c0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    52c4:	91082000 	add	x0, x0, #0x208
    52c8:	97fffad2 	bl	3e10 <fwp_trap>
    52cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52d0:	d65f03c0 	ret
    52d4:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    52d8:	91064000 	add	x0, x0, #0x190
    52dc:	97fffacd 	bl	3e10 <fwp_trap>

00000000000052e0 <w107>:
    52e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    52e4:	910003fd 	mov	x29, sp
    52e8:	a90153f3 	stp	x19, x20, [sp, #16]
    52ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    52f0:	a90363f7 	stp	x23, x24, [sp, #48]
    52f4:	aa0003f8 	mov	x24, x0
    52f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52fc:	aa0103f9 	mov	x25, x1
    5300:	6d0527e8 	stp	d8, d9, [sp, #80]
    5304:	1e604008 	fmov	d8, d0
    5308:	1e604029 	fmov	d9, d1
    530c:	6d062fea 	stp	d10, d11, [sp, #96]
    5310:	1e60080a 	fmul	d10, d0, d0
    5314:	b7f821a0 	tbnz	x0, #63, 5748 <w107+0x468>
    5318:	9360fc17 	asr	x23, x0, #32
    531c:	aa1703e0 	mov	x0, x23
    5320:	97fffcc0 	bl	4620 <fwp_tape_of>
    5324:	f9403001 	ldr	x1, [x0, #96]
    5328:	aa0003f3 	mov	x19, x0
    532c:	b4000081 	cbz	x1, 533c <w107+0x5c>
    5330:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    5334:	91076000 	add	x0, x0, #0x1d8
    5338:	97fffab6 	bl	3e10 <fwp_trap>
    533c:	f9400815 	ldr	x21, [x0, #16]
    5340:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5344:	eb0102bf 	cmp	x21, x1
    5348:	54001d8c 	b.gt	56f8 <w107+0x418>
    534c:	eb3842bf 	cmp	x21, w24, uxtw
    5350:	54001ced 	b.le	56ec <w107+0x40c>
    5354:	f9400416 	ldr	x22, [x0, #8]
    5358:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    535c:	cb1602b6 	sub	x22, x21, x22
    5360:	910006c1 	add	x1, x22, #0x1
    5364:	eb02003f 	cmp	x1, x2
    5368:	54001c88 	b.hi	56f8 <w107+0x418>  // b.pmore
    536c:	f9400c02 	ldr	x2, [x0, #24]
    5370:	eb02003f 	cmp	x1, x2
    5374:	54001c8c 	b.gt	5704 <w107+0x424>
    5378:	a9420660 	ldp	x0, x1, [x19, #32]
    537c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5380:	f9401a62 	ldr	x2, [x19, #48]
    5384:	b8367818 	str	w24, [x0, x22, lsl #2]
    5388:	f9401e60 	ldr	x0, [x19, #56]
    538c:	aa150294 	orr	x20, x20, x21
    5390:	fc367848 	str	d8, [x2, x22, lsl #3]
    5394:	910006b5 	add	x21, x21, #0x1
    5398:	b8367838 	str	w24, [x1, x22, lsl #2]
    539c:	1e6a392a 	fsub	d10, d9, d10
    53a0:	9360fe9a 	asr	x26, x20, #32
    53a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    53a8:	f9000a75 	str	x21, [x19, #16]
    53ac:	b7f80079 	tbnz	x25, #63, 53b8 <w107+0xd8>
    53b0:	eb99835f 	cmp	x26, x25, asr #32
    53b4:	54001e21 	b.ne	5778 <w107+0x498>  // b.any
    53b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    53bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    53c0:	eb1a02ff 	cmp	x23, x26
    53c4:	540000c0 	b.eq	53dc <w107+0xfc>  // b.none
    53c8:	aa1a03e0 	mov	x0, x26
    53cc:	97fffc95 	bl	4620 <fwp_tape_of>
    53d0:	aa0003f3 	mov	x19, x0
    53d4:	f9403000 	ldr	x0, [x0, #96]
    53d8:	b5fffac0 	cbnz	x0, 5330 <w107+0x50>
    53dc:	f9400a77 	ldr	x23, [x19, #16]
    53e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53e4:	eb0002ff 	cmp	x23, x0
    53e8:	5400188c 	b.gt	56f8 <w107+0x418>
    53ec:	eb3442ff 	cmp	x23, w20, uxtw
    53f0:	540017ed 	b.le	56ec <w107+0x40c>
    53f4:	b7f80079 	tbnz	x25, #63, 5400 <w107+0x120>
    53f8:	eb3942ff 	cmp	x23, w25, uxtw
    53fc:	5400178d 	b.le	56ec <w107+0x40c>
    5400:	f9400675 	ldr	x21, [x19, #8]
    5404:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5408:	cb1502f5 	sub	x21, x23, x21
    540c:	910006a1 	add	x1, x21, #0x1
    5410:	eb00003f 	cmp	x1, x0
    5414:	54001728 	b.hi	56f8 <w107+0x418>  // b.pmore
    5418:	f9400e60 	ldr	x0, [x19, #24]
    541c:	eb00003f 	cmp	x1, x0
    5420:	540018ec 	b.gt	573c <w107+0x45c>
    5424:	a9420e62 	ldp	x2, x3, [x19, #32]
    5428:	f100033f 	cmp	x25, #0x0
    542c:	f9401a61 	ldr	x1, [x19, #48]
    5430:	b8357854 	str	w20, [x2, x21, lsl #2]
    5434:	f9401e62 	ldr	x2, [x19, #56]
    5438:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    543c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5440:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5444:	b8357861 	str	w1, [x3, x21, lsl #2]
    5448:	910006f6 	add	x22, x23, #0x1
    544c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5450:	92607e94 	and	x20, x20, #0xffffffff00000000
    5454:	fc357849 	str	d9, [x2, x21, lsl #3]
    5458:	aa170294 	orr	x20, x20, x23
    545c:	f9000a76 	str	x22, [x19, #16]
    5460:	1e68396b 	fsub	d11, d11, d8
    5464:	b7f81a78 	tbnz	x24, #63, 57b0 <w107+0x4d0>
    5468:	9360ff17 	asr	x23, x24, #32
    546c:	eb1a02ff 	cmp	x23, x26
    5470:	540000e0 	b.eq	548c <w107+0x1ac>  // b.none
    5474:	aa1703e0 	mov	x0, x23
    5478:	97fffc6a 	bl	4620 <fwp_tape_of>
    547c:	aa0003f3 	mov	x19, x0
    5480:	f9403000 	ldr	x0, [x0, #96]
    5484:	b5fff560 	cbnz	x0, 5330 <w107+0x50>
    5488:	f9400a76 	ldr	x22, [x19, #16]
    548c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5490:	eb0002df 	cmp	x22, x0
    5494:	5400132c 	b.gt	56f8 <w107+0x418>
    5498:	eb3842df 	cmp	x22, w24, uxtw
    549c:	5400128d 	b.le	56ec <w107+0x40c>
    54a0:	f9400675 	ldr	x21, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1502d5 	sub	x21, x22, x21
    54ac:	910006a1 	add	x1, x21, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54001228 	b.hi	56f8 <w107+0x418>  // b.pmore
    54b8:	f9400e60 	ldr	x0, [x19, #24]
    54bc:	eb00003f 	cmp	x1, x0
    54c0:	5400138c 	b.gt	5730 <w107+0x450>
    54c4:	a9420262 	ldp	x2, x0, [x19, #32]
    54c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    54cc:	f9401a63 	ldr	x3, [x19, #48]
    54d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    54d4:	f9401e62 	ldr	x2, [x19, #56]
    54d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    54dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    54e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    54e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    54ec:	aa160018 	orr	x24, x0, x22
    54f0:	910006c1 	add	x1, x22, #0x1
    54f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    54f8:	f9000a61 	str	x1, [x19, #16]
    54fc:	9360fe99 	asr	x25, x20, #32
    5500:	1e6a0949 	fmul	d9, d10, d10
    5504:	eb17033f 	cmp	x25, x23
    5508:	540000c0 	b.eq	5520 <w107+0x240>  // b.none
    550c:	aa1903e0 	mov	x0, x25
    5510:	97fffc44 	bl	4620 <fwp_tape_of>
    5514:	aa0003f3 	mov	x19, x0
    5518:	f9403000 	ldr	x0, [x0, #96]
    551c:	b5fff0a0 	cbnz	x0, 5330 <w107+0x50>
    5520:	f9400a75 	ldr	x21, [x19, #16]
    5524:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5528:	eb0002bf 	cmp	x21, x0
    552c:	54000e6c 	b.gt	56f8 <w107+0x418>
    5530:	eb3442bf 	cmp	x21, w20, uxtw
    5534:	54000dcd 	b.le	56ec <w107+0x40c>
    5538:	f9400676 	ldr	x22, [x19, #8]
    553c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5540:	cb1602b6 	sub	x22, x21, x22
    5544:	910006c1 	add	x1, x22, #0x1
    5548:	eb00003f 	cmp	x1, x0
    554c:	54000d68 	b.hi	56f8 <w107+0x418>  // b.pmore
    5550:	f9400e60 	ldr	x0, [x19, #24]
    5554:	eb00003f 	cmp	x1, x0
    5558:	54000e6c 	b.gt	5724 <w107+0x444>
    555c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5560:	aa150017 	orr	x23, x0, x21
    5564:	a9420261 	ldp	x1, x0, [x19, #32]
    5568:	f9401a62 	ldr	x2, [x19, #48]
    556c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5570:	f9401e61 	ldr	x1, [x19, #56]
    5574:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5578:	b8367814 	str	w20, [x0, x22, lsl #2]
    557c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5580:	9e670000 	fmov	d0, x0
    5584:	910006b4 	add	x20, x21, #0x1
    5588:	fc36782a 	str	d10, [x1, x22, lsl #3]
    558c:	9360fef6 	asr	x22, x23, #32
    5590:	f9000a74 	str	x20, [x19, #16]
    5594:	1e600929 	fmul	d9, d9, d0
    5598:	eb1902df 	cmp	x22, x25
    559c:	540000e0 	b.eq	55b8 <w107+0x2d8>  // b.none
    55a0:	aa1603e0 	mov	x0, x22
    55a4:	97fffc1f 	bl	4620 <fwp_tape_of>
    55a8:	aa0003f3 	mov	x19, x0
    55ac:	f9403000 	ldr	x0, [x0, #96]
    55b0:	b5ffec00 	cbnz	x0, 5330 <w107+0x50>
    55b4:	f9400a74 	ldr	x20, [x19, #16]
    55b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55bc:	eb00029f 	cmp	x20, x0
    55c0:	540009cc 	b.gt	56f8 <w107+0x418>
    55c4:	eb37429f 	cmp	x20, w23, uxtw
    55c8:	5400092d 	b.le	56ec <w107+0x40c>
    55cc:	f9400675 	ldr	x21, [x19, #8]
    55d0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55d4:	cb150295 	sub	x21, x20, x21
    55d8:	910006a1 	add	x1, x21, #0x1
    55dc:	eb00003f 	cmp	x1, x0
    55e0:	540008c8 	b.hi	56f8 <w107+0x418>  // b.pmore
    55e4:	f9400e60 	ldr	x0, [x19, #24]
    55e8:	eb00003f 	cmp	x1, x0
    55ec:	5400096c 	b.gt	5718 <w107+0x438>
    55f0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    55f4:	9e670000 	fmov	d0, x0
    55f8:	a9420262 	ldp	x2, x0, [x19, #32]
    55fc:	1e6b0968 	fmul	d8, d11, d11
    5600:	f9401a61 	ldr	x1, [x19, #48]
    5604:	b8357857 	str	w23, [x2, x21, lsl #2]
    5608:	f9401e62 	ldr	x2, [x19, #56]
    560c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5610:	12800001 	mov	w1, #0xffffffff            	// #-1
    5614:	b8357801 	str	w1, [x0, x21, lsl #2]
    5618:	91000681 	add	x1, x20, #0x1
    561c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5620:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5624:	f9000a61 	str	x1, [x19, #16]
    5628:	aa140014 	orr	x20, x0, x20
    562c:	b100071f 	cmn	x24, #0x1
    5630:	54000c60 	b.eq	57bc <w107+0x4dc>  // b.none
    5634:	9360ff00 	asr	x0, x24, #32
    5638:	eb16001f 	cmp	x0, x22
    563c:	540000a0 	b.eq	5650 <w107+0x370>  // b.none
    5640:	97fffbf8 	bl	4620 <fwp_tape_of>
    5644:	aa0003f3 	mov	x19, x0
    5648:	f9403000 	ldr	x0, [x0, #96]
    564c:	b5ffe720 	cbnz	x0, 5330 <w107+0x50>
    5650:	f9400a75 	ldr	x21, [x19, #16]
    5654:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5658:	eb0002bf 	cmp	x21, x0
    565c:	540004ec 	b.gt	56f8 <w107+0x418>
    5660:	eb3842bf 	cmp	x21, w24, uxtw
    5664:	5400044d 	b.le	56ec <w107+0x40c>
    5668:	f9400676 	ldr	x22, [x19, #8]
    566c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5670:	cb1602b6 	sub	x22, x21, x22
    5674:	910006c1 	add	x1, x22, #0x1
    5678:	eb00003f 	cmp	x1, x0
    567c:	540003e8 	b.hi	56f8 <w107+0x418>  // b.pmore
    5680:	f9400e60 	ldr	x0, [x19, #24]
    5684:	eb00003f 	cmp	x1, x0
    5688:	5400042c 	b.gt	570c <w107+0x42c>
    568c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5690:	92607f00 	and	x0, x24, #0xffffffff00000000
    5694:	f9401a63 	ldr	x3, [x19, #48]
    5698:	b8367838 	str	w24, [x1, x22, lsl #2]
    569c:	f9401e61 	ldr	x1, [x19, #56]
    56a0:	aa150000 	orr	x0, x0, x21
    56a4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    56a8:	910006b5 	add	x21, x21, #0x1
    56ac:	b8367858 	str	w24, [x2, x22, lsl #2]
    56b0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    56b4:	f9000a75 	str	x21, [x19, #16]
    56b8:	1e692908 	fadd	d8, d8, d9
    56bc:	aa1403e1 	mov	x1, x20
    56c0:	97fffeb0 	bl	5180 <f128.constprop.0>
    56c4:	aa0003e1 	mov	x1, x0
    56c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    56cc:	9e660100 	fmov	x0, d8
    56d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    56d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    56dc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    56e0:	6d462fea 	ldp	d10, d11, [sp, #96]
    56e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    56e8:	d65f03c0 	ret
    56ec:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    56f0:	91082000 	add	x0, x0, #0x208
    56f4:	97fff9c7 	bl	3e10 <fwp_trap>
    56f8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    56fc:	9105c000 	add	x0, x0, #0x170
    5700:	97fff9c4 	bl	3e10 <fwp_trap>
    5704:	97fffe08 	bl	4f24 <fwp_tape_grow.constprop.0>
    5708:	17ffff1c 	b	5378 <w107+0x98>
    570c:	aa1303e0 	mov	x0, x19
    5710:	97fffe05 	bl	4f24 <fwp_tape_grow.constprop.0>
    5714:	17ffffde 	b	568c <w107+0x3ac>
    5718:	aa1303e0 	mov	x0, x19
    571c:	97fffe02 	bl	4f24 <fwp_tape_grow.constprop.0>
    5720:	17ffffb4 	b	55f0 <w107+0x310>
    5724:	aa1303e0 	mov	x0, x19
    5728:	97fffdff 	bl	4f24 <fwp_tape_grow.constprop.0>
    572c:	17ffff8c 	b	555c <w107+0x27c>
    5730:	aa1303e0 	mov	x0, x19
    5734:	97fffdfc 	bl	4f24 <fwp_tape_grow.constprop.0>
    5738:	17ffff63 	b	54c4 <w107+0x1e4>
    573c:	aa1303e0 	mov	x0, x19
    5740:	97fffdf9 	bl	4f24 <fwp_tape_grow.constprop.0>
    5744:	17ffff38 	b	5424 <w107+0x144>
    5748:	1e6a382a 	fsub	d10, d1, d10
    574c:	b6f801c1 	tbz	x1, #63, 5784 <w107+0x4a4>
    5750:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5754:	1e6a0949 	fmul	d9, d10, d10
    5758:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    575c:	9e670001 	fmov	d1, x0
    5760:	1e683808 	fsub	d8, d0, d8
    5764:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5768:	aa1403e0 	mov	x0, x20
    576c:	1e610929 	fmul	d9, d9, d1
    5770:	1e680908 	fmul	d8, d8, d8
    5774:	17ffffd1 	b	56b8 <w107+0x3d8>
    5778:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    577c:	91064000 	add	x0, x0, #0x190
    5780:	97fff9a4 	bl	3e10 <fwp_trap>
    5784:	2f00e409 	movi	d9, #0x0
    5788:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    578c:	9360fc3a 	asr	x26, x1, #32
    5790:	aa0103f4 	mov	x20, x1
    5794:	aa1a03e0 	mov	x0, x26
    5798:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    579c:	97fffba1 	bl	4620 <fwp_tape_of>
    57a0:	aa0003f3 	mov	x19, x0
    57a4:	f9403000 	ldr	x0, [x0, #96]
    57a8:	b5ffdc40 	cbnz	x0, 5330 <w107+0x50>
    57ac:	17ffff0c 	b	53dc <w107+0xfc>
    57b0:	aa1a03f7 	mov	x23, x26
    57b4:	aa0003f8 	mov	x24, x0
    57b8:	17ffff51 	b	54fc <w107+0x21c>
    57bc:	aa1803e0 	mov	x0, x24
    57c0:	17ffffbe 	b	56b8 <w107+0x3d8>

00000000000057c4 <fwp_data.part.0.constprop.0>:
    57c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    57d4:	91150283 	add	x3, x20, #0x540
    57d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57dc:	aa0103f5 	mov	x21, x1
    57e0:	b953a461 	ldr	w1, [x3, #5028]
    57e4:	a90363f7 	stp	x23, x24, [sp, #48]
    57e8:	2a0003f8 	mov	w24, w0
    57ec:	34000701 	cbz	w1, 58cc <fwp_data.part.0.constprop.0+0x108>
    57f0:	397e8862 	ldrb	w2, [x3, #4002]
    57f4:	910f0040 	add	x0, x2, #0x3c0
    57f8:	8b020442 	add	x2, x2, x2, lsl #1
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5804:	2a1703f6 	mov	w22, w23
    5808:	f8626873 	ldr	x19, [x3, x2]
    580c:	b40004d3 	cbz	x19, 58a4 <fwp_data.part.0.constprop.0+0xe0>
    5810:	f9400260 	ldr	x0, [x19]
    5814:	aa2003e0 	mvn	x0, x0
    5818:	f8226860 	str	x0, [x3, x2]
    581c:	f10062df 	cmp	x22, #0x18
    5820:	540000e9 	b.ls	583c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5824:	d10066c2 	sub	x2, x22, #0x19
    5828:	91006260 	add	x0, x19, #0x18
    582c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5830:	52800001 	mov	w1, #0x0                   	// #0
    5834:	91002042 	add	x2, x2, #0x8
    5838:	97fff3e2 	bl	27c0 <memset@plt>
    583c:	91150282 	add	x2, x20, #0x540
    5840:	f94a1041 	ldr	x1, [x2, #5152]
    5844:	ab160021 	adds	x1, x1, x22
    5848:	540004c2 	b.cs	58e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    584c:	f94a1440 	ldr	x0, [x2, #5160]
    5850:	f90a1041 	str	x1, [x2, #5152]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000049 	b.ls	5860 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    585c:	f90a1441 	str	x1, [x2, #5160]
    5860:	91150294 	add	x20, x20, #0x540
    5864:	1e6302e1 	ucvtf	d1, w23
    5868:	fd4a1e80 	ldr	d0, [x20, #5176]
    586c:	1e612800 	fadd	d0, d0, d1
    5870:	fd0a1e80 	str	d0, [x20, #5176]
    5874:	52800041 	mov	w1, #0x2                   	// #2
    5878:	29000678 	stp	w24, w1, [x19]
    587c:	aa1303e0 	mov	x0, x19
    5880:	f94002a1 	ldr	x1, [x21]
    5884:	f9000661 	str	x1, [x19, #8]
    5888:	f94006a1 	ldr	x1, [x21, #8]
    588c:	f9000a61 	str	x1, [x19, #16]
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5898:	a94363f7 	ldp	x23, x24, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	d65f03c0 	ret
    58a4:	8b020063 	add	x3, x3, x2
    58a8:	f9400473 	ldr	x19, [x3, #8]
    58ac:	b4000113 	cbz	x19, 58cc <fwp_data.part.0.constprop.0+0x108>
    58b0:	f9400860 	ldr	x0, [x3, #16]
    58b4:	cb130000 	sub	x0, x0, x19
    58b8:	eb0002df 	cmp	x22, x0
    58bc:	54000088 	b.hi	58cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    58c0:	8b160260 	add	x0, x19, x22
    58c4:	f9000460 	str	x0, [x3, #8]
    58c8:	17ffffd5 	b	581c <fwp_data.part.0.constprop.0+0x58>
    58cc:	52800001 	mov	w1, #0x0                   	// #0
    58d0:	d2800300 	mov	x0, #0x18                  	// #24
    58d4:	97fffcc7 	bl	4bf0 <fwp_heap_alloc>
    58d8:	aa0003f3 	mov	x19, x0
    58dc:	17ffffe6 	b	5874 <fwp_data.part.0.constprop.0+0xb0>
    58e0:	97fff5b4 	bl	2fb0 <fwp_heap_oom>

00000000000058e4 <fwp_rc_share>:
    58e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    58e8:	91150042 	add	x2, x2, #0x540
    58ec:	f949d843 	ldr	x3, [x2, #5040]
    58f0:	f949ec41 	ldr	x1, [x2, #5080]
    58f4:	cb030000 	sub	x0, x0, x3
    58f8:	eb01401f 	cmp	x0, x1, lsl #16
    58fc:	540003a2 	b.cs	5970 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5900:	d350fc01 	lsr	x1, x0, #16
    5904:	f949fc44 	ldr	x4, [x2, #5112]
    5908:	8b010821 	add	x1, x1, x1, lsl #2
    590c:	d37df021 	lsl	x1, x1, #3
    5910:	8b010083 	add	x3, x4, x1
    5914:	f9401062 	ldr	x2, [x3, #32]
    5918:	b40002c2 	cbz	x2, 5970 <fwp_rc_share+0x8c>
    591c:	38616881 	ldrb	w1, [x4, x1]
    5920:	7100083f 	cmp	w1, #0x2
    5924:	54000220 	b.eq	5968 <fwp_rc_share+0x84>  // b.none
    5928:	7100043f 	cmp	w1, #0x1
    592c:	54000221 	b.ne	5970 <fwp_rc_share+0x8c>  // b.any
    5930:	29430464 	ldp	w4, w1, [x3, #24]
    5934:	92403c00 	and	x0, x0, #0xffff
    5938:	9b047c00 	mul	x0, x0, x4
    593c:	d360fc00 	lsr	x0, x0, #32
    5940:	eb01001f 	cmp	x0, x1
    5944:	54000162 	b.cs	5970 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5948:	8b000042 	add	x2, x2, x0
    594c:	39400040 	ldrb	w0, [x2]
    5950:	34000100 	cbz	w0, 5970 <fwp_rc_share+0x8c>
    5954:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5958:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    595c:	9108a000 	add	x0, x0, #0x228
    5960:	910003fd 	mov	x29, sp
    5964:	97fff92b 	bl	3e10 <fwp_trap>
    5968:	72003c1f 	tst	w0, #0xffff
    596c:	54ffff00 	b.eq	594c <fwp_rc_share+0x68>  // b.none
    5970:	d65f03c0 	ret

0000000000005974 <fwp_rc_free_arr>:
    5974:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5978:	91150063 	add	x3, x3, #0x540
    597c:	f949d861 	ldr	x1, [x3, #5040]
    5980:	f949ec62 	ldr	x2, [x3, #5080]
    5984:	cb010001 	sub	x1, x0, x1
    5988:	eb02403f 	cmp	x1, x2, lsl #16
    598c:	54000342 	b.cs	59f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5990:	d350fc22 	lsr	x2, x1, #16
    5994:	f949fc65 	ldr	x5, [x3, #5112]
    5998:	8b020842 	add	x2, x2, x2, lsl #2
    599c:	d37df042 	lsl	x2, x2, #3
    59a0:	8b0200a4 	add	x4, x5, x2
    59a4:	f9401083 	ldr	x3, [x4, #32]
    59a8:	b4000263 	cbz	x3, 59f4 <fwp_rc_free_arr+0x80>
    59ac:	386268a2 	ldrb	w2, [x5, x2]
    59b0:	7100085f 	cmp	w2, #0x2
    59b4:	540001c0 	b.eq	59ec <fwp_rc_free_arr+0x78>  // b.none
    59b8:	7100045f 	cmp	w2, #0x1
    59bc:	540001c1 	b.ne	59f4 <fwp_rc_free_arr+0x80>  // b.any
    59c0:	29430885 	ldp	w5, w2, [x4, #24]
    59c4:	92403c21 	and	x1, x1, #0xffff
    59c8:	9b057c21 	mul	x1, x1, x5
    59cc:	d360fc21 	lsr	x1, x1, #32
    59d0:	eb02003f 	cmp	x1, x2
    59d4:	54000102 	b.cs	59f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59d8:	8b010063 	add	x3, x3, x1
    59dc:	39400061 	ldrb	w1, [x3]
    59e0:	7100043f 	cmp	w1, #0x1
    59e4:	54000081 	b.ne	59f4 <fwp_rc_free_arr+0x80>  // b.any
    59e8:	17fff9c6 	b	4100 <fwp_mem_free>
    59ec:	72003c3f 	tst	w1, #0xffff
    59f0:	54ffff60 	b.eq	59dc <fwp_rc_free_arr+0x68>  // b.none
    59f4:	d65f03c0 	ret
    59f8:	d503201f 	nop
    59fc:	d503201f 	nop

0000000000005a00 <fwp_rc_dup>:
    5a00:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5a04:	91150042 	add	x2, x2, #0x540
    5a08:	f949d841 	ldr	x1, [x2, #5040]
    5a0c:	f949ec43 	ldr	x3, [x2, #5080]
    5a10:	cb010001 	sub	x1, x0, x1
    5a14:	eb03403f 	cmp	x1, x3, lsl #16
    5a18:	54000342 	b.cs	5a80 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a1c:	d350fc20 	lsr	x0, x1, #16
    5a20:	f949fc44 	ldr	x4, [x2, #5112]
    5a24:	8b000800 	add	x0, x0, x0, lsl #2
    5a28:	d37df002 	lsl	x2, x0, #3
    5a2c:	8b020083 	add	x3, x4, x2
    5a30:	f9401060 	ldr	x0, [x3, #32]
    5a34:	b4000260 	cbz	x0, 5a80 <fwp_rc_dup+0x80>
    5a38:	38626882 	ldrb	w2, [x4, x2]
    5a3c:	7100085f 	cmp	w2, #0x2
    5a40:	54000220 	b.eq	5a84 <fwp_rc_dup+0x84>  // b.none
    5a44:	7100045f 	cmp	w2, #0x1
    5a48:	540001c1 	b.ne	5a80 <fwp_rc_dup+0x80>  // b.any
    5a4c:	29430864 	ldp	w4, w2, [x3, #24]
    5a50:	92403c21 	and	x1, x1, #0xffff
    5a54:	9b047c21 	mul	x1, x1, x4
    5a58:	d360fc21 	lsr	x1, x1, #32
    5a5c:	eb02003f 	cmp	x1, x2
    5a60:	54000102 	b.cs	5a80 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a64:	8b010000 	add	x0, x0, x1
    5a68:	39400001 	ldrb	w1, [x0]
    5a6c:	340000a1 	cbz	w1, 5a80 <fwp_rc_dup+0x80>
    5a70:	7103f43f 	cmp	w1, #0xfd
    5a74:	540000e8 	b.hi	5a90 <fwp_rc_dup+0x90>  // b.pmore
    5a78:	11000421 	add	w1, w1, #0x1
    5a7c:	39000001 	strb	w1, [x0]
    5a80:	d65f03c0 	ret
    5a84:	72003c3f 	tst	w1, #0xffff
    5a88:	54ffff00 	b.eq	5a68 <fwp_rc_dup+0x68>  // b.none
    5a8c:	d65f03c0 	ret
    5a90:	17fffa15 	b	42e4 <fwp_rc_wide_dup>

0000000000005a94 <fwp_drop1>:
    5a94:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a98:	910003fd 	mov	x29, sp
    5a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    5aa0:	f90013f5 	str	x21, [sp, #32]
    5aa4:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5aa8:	911502b4 	add	x20, x21, #0x540
    5aac:	f949da81 	ldr	x1, [x20, #5040]
    5ab0:	f949ee82 	ldr	x2, [x20, #5080]
    5ab4:	cb010001 	sub	x1, x0, x1
    5ab8:	eb02403f 	cmp	x1, x2, lsl #16
    5abc:	54000382 	b.cs	5b2c <fwp_drop1+0x98>  // b.hs, b.nlast
    5ac0:	d350fc22 	lsr	x2, x1, #16
    5ac4:	f949fe84 	ldr	x4, [x20, #5112]
    5ac8:	8b020842 	add	x2, x2, x2, lsl #2
    5acc:	d37df042 	lsl	x2, x2, #3
    5ad0:	8b020083 	add	x3, x4, x2
    5ad4:	f9401073 	ldr	x19, [x3, #32]
    5ad8:	b40002b3 	cbz	x19, 5b2c <fwp_drop1+0x98>
    5adc:	38626882 	ldrb	w2, [x4, x2]
    5ae0:	7100085f 	cmp	w2, #0x2
    5ae4:	540002c0 	b.eq	5b3c <fwp_drop1+0xa8>  // b.none
    5ae8:	7100045f 	cmp	w2, #0x1
    5aec:	54000201 	b.ne	5b2c <fwp_drop1+0x98>  // b.any
    5af0:	29430864 	ldp	w4, w2, [x3, #24]
    5af4:	92403c21 	and	x1, x1, #0xffff
    5af8:	9b047c21 	mul	x1, x1, x4
    5afc:	d360fc21 	lsr	x1, x1, #32
    5b00:	eb02003f 	cmp	x1, x2
    5b04:	54000142 	b.cs	5b2c <fwp_drop1+0x98>  // b.hs, b.nlast
    5b08:	8b010273 	add	x19, x19, x1
    5b0c:	39400261 	ldrb	w1, [x19]
    5b10:	340000e1 	cbz	w1, 5b2c <fwp_drop1+0x98>
    5b14:	7100043f 	cmp	w1, #0x1
    5b18:	540001e0 	b.eq	5b54 <fwp_drop1+0xc0>  // b.none
    5b1c:	7103fc3f 	cmp	w1, #0xff
    5b20:	540002e0 	b.eq	5b7c <fwp_drop1+0xe8>  // b.none
    5b24:	51000421 	sub	w1, w1, #0x1
    5b28:	39000261 	strb	w1, [x19]
    5b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b30:	f94013f5 	ldr	x21, [sp, #32]
    5b34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b38:	d65f03c0 	ret
    5b3c:	72003c3f 	tst	w1, #0xffff
    5b40:	54fffe60 	b.eq	5b0c <fwp_drop1+0x78>  // b.none
    5b44:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b48:	f94013f5 	ldr	x21, [sp, #32]
    5b4c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b50:	d65f03c0 	ret
    5b54:	f9400813 	ldr	x19, [x0, #16]
    5b58:	97ffff87 	bl	5974 <fwp_rc_free_arr>
    5b5c:	911502a0 	add	x0, x21, #0x540
    5b60:	f949d801 	ldr	x1, [x0, #5040]
    5b64:	f949ec00 	ldr	x0, [x0, #5080]
    5b68:	cb010261 	sub	x1, x19, x1
    5b6c:	eb00403f 	cmp	x1, x0, lsl #16
    5b70:	54fffde2 	b.cs	5b2c <fwp_drop1+0x98>  // b.hs, b.nlast
    5b74:	aa1303e0 	mov	x0, x19
    5b78:	17ffffd2 	b	5ac0 <fwp_drop1+0x2c>
    5b7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5b80:	911502b5 	add	x21, x21, #0x540
    5b84:	ca402400 	eor	x0, x0, x0, lsr #9
    5b88:	92401c00 	and	x0, x0, #0xff
    5b8c:	910a2402 	add	x2, x0, #0x289
    5b90:	8b000ea0 	add	x0, x21, x0, lsl #3
    5b94:	8b020ea2 	add	x2, x21, x2, lsl #3
    5b98:	f94a2400 	ldr	x0, [x0, #5192]
    5b9c:	b50000a0 	cbnz	x0, 5bb0 <fwp_drop1+0x11c>
    5ba0:	14000013 	b	5bec <fwp_drop1+0x158>
    5ba4:	91004002 	add	x2, x0, #0x10
    5ba8:	f9400800 	ldr	x0, [x0, #16]
    5bac:	b4000200 	cbz	x0, 5bec <fwp_drop1+0x158>
    5bb0:	f9400001 	ldr	x1, [x0]
    5bb4:	eb13003f 	cmp	x1, x19
    5bb8:	54ffff61 	b.ne	5ba4 <fwp_drop1+0x110>  // b.any
    5bbc:	f9400041 	ldr	x1, [x2]
    5bc0:	f9400420 	ldr	x0, [x1, #8]
    5bc4:	d1000400 	sub	x0, x0, #0x1
    5bc8:	f9000420 	str	x0, [x1, #8]
    5bcc:	f103f81f 	cmp	x0, #0xfe
    5bd0:	54fffae1 	b.ne	5b2c <fwp_drop1+0x98>  // b.any
    5bd4:	39400260 	ldrb	w0, [x19]
    5bd8:	7103fc1f 	cmp	w0, #0xff
    5bdc:	540000e0 	b.eq	5bf8 <fwp_drop1+0x164>  // b.none
    5be0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5be4:	39000260 	strb	w0, [x19]
    5be8:	17ffffd1 	b	5b2c <fwp_drop1+0x98>
    5bec:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    5bf0:	913f0000 	add	x0, x0, #0xfc0
    5bf4:	97fff887 	bl	3e10 <fwp_trap>
    5bf8:	aa1303e0 	mov	x0, x19
    5bfc:	97fff8a5 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5c00:	17fffff8 	b	5be0 <fwp_drop1+0x14c>

0000000000005c04 <fwp_drop0>:
    5c04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c08:	910003fd 	mov	x29, sp
    5c0c:	a90153f3 	stp	x19, x20, [sp, #16]
    5c10:	f90013f5 	str	x21, [sp, #32]
    5c14:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5c18:	911502b4 	add	x20, x21, #0x540
    5c1c:	f949da81 	ldr	x1, [x20, #5040]
    5c20:	f949ee82 	ldr	x2, [x20, #5080]
    5c24:	cb010001 	sub	x1, x0, x1
    5c28:	eb02403f 	cmp	x1, x2, lsl #16
    5c2c:	54000382 	b.cs	5c9c <fwp_drop0+0x98>  // b.hs, b.nlast
    5c30:	d350fc22 	lsr	x2, x1, #16
    5c34:	f949fe84 	ldr	x4, [x20, #5112]
    5c38:	8b020842 	add	x2, x2, x2, lsl #2
    5c3c:	d37df042 	lsl	x2, x2, #3
    5c40:	8b020083 	add	x3, x4, x2
    5c44:	f9401073 	ldr	x19, [x3, #32]
    5c48:	b40002b3 	cbz	x19, 5c9c <fwp_drop0+0x98>
    5c4c:	38626882 	ldrb	w2, [x4, x2]
    5c50:	7100085f 	cmp	w2, #0x2
    5c54:	540002c0 	b.eq	5cac <fwp_drop0+0xa8>  // b.none
    5c58:	7100045f 	cmp	w2, #0x1
    5c5c:	54000201 	b.ne	5c9c <fwp_drop0+0x98>  // b.any
    5c60:	29430864 	ldp	w4, w2, [x3, #24]
    5c64:	92403c21 	and	x1, x1, #0xffff
    5c68:	9b047c21 	mul	x1, x1, x4
    5c6c:	d360fc21 	lsr	x1, x1, #32
    5c70:	eb02003f 	cmp	x1, x2
    5c74:	54000142 	b.cs	5c9c <fwp_drop0+0x98>  // b.hs, b.nlast
    5c78:	8b010273 	add	x19, x19, x1
    5c7c:	39400261 	ldrb	w1, [x19]
    5c80:	340000e1 	cbz	w1, 5c9c <fwp_drop0+0x98>
    5c84:	7100043f 	cmp	w1, #0x1
    5c88:	540001e0 	b.eq	5cc4 <fwp_drop0+0xc0>  // b.none
    5c8c:	7103fc3f 	cmp	w1, #0xff
    5c90:	540002e0 	b.eq	5cec <fwp_drop0+0xe8>  // b.none
    5c94:	51000421 	sub	w1, w1, #0x1
    5c98:	39000261 	strb	w1, [x19]
    5c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ca0:	f94013f5 	ldr	x21, [sp, #32]
    5ca4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ca8:	d65f03c0 	ret
    5cac:	72003c3f 	tst	w1, #0xffff
    5cb0:	54fffe60 	b.eq	5c7c <fwp_drop0+0x78>  // b.none
    5cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cb8:	f94013f5 	ldr	x21, [sp, #32]
    5cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cc0:	d65f03c0 	ret
    5cc4:	f9400813 	ldr	x19, [x0, #16]
    5cc8:	97ffff2b 	bl	5974 <fwp_rc_free_arr>
    5ccc:	911502a0 	add	x0, x21, #0x540
    5cd0:	f949d801 	ldr	x1, [x0, #5040]
    5cd4:	f949ec00 	ldr	x0, [x0, #5080]
    5cd8:	cb010261 	sub	x1, x19, x1
    5cdc:	eb00403f 	cmp	x1, x0, lsl #16
    5ce0:	54fffde2 	b.cs	5c9c <fwp_drop0+0x98>  // b.hs, b.nlast
    5ce4:	aa1303e0 	mov	x0, x19
    5ce8:	17ffffd2 	b	5c30 <fwp_drop0+0x2c>
    5cec:	ca534660 	eor	x0, x19, x19, lsr #17
    5cf0:	911502b5 	add	x21, x21, #0x540
    5cf4:	ca402400 	eor	x0, x0, x0, lsr #9
    5cf8:	92401c00 	and	x0, x0, #0xff
    5cfc:	910a2402 	add	x2, x0, #0x289
    5d00:	8b000ea0 	add	x0, x21, x0, lsl #3
    5d04:	8b020ea2 	add	x2, x21, x2, lsl #3
    5d08:	f94a2400 	ldr	x0, [x0, #5192]
    5d0c:	b50000a0 	cbnz	x0, 5d20 <fwp_drop0+0x11c>
    5d10:	14000013 	b	5d5c <fwp_drop0+0x158>
    5d14:	91004002 	add	x2, x0, #0x10
    5d18:	f9400800 	ldr	x0, [x0, #16]
    5d1c:	b4000200 	cbz	x0, 5d5c <fwp_drop0+0x158>
    5d20:	f9400001 	ldr	x1, [x0]
    5d24:	eb13003f 	cmp	x1, x19
    5d28:	54ffff61 	b.ne	5d14 <fwp_drop0+0x110>  // b.any
    5d2c:	f9400041 	ldr	x1, [x2]
    5d30:	f9400420 	ldr	x0, [x1, #8]
    5d34:	d1000400 	sub	x0, x0, #0x1
    5d38:	f9000420 	str	x0, [x1, #8]
    5d3c:	f103f81f 	cmp	x0, #0xfe
    5d40:	54fffae1 	b.ne	5c9c <fwp_drop0+0x98>  // b.any
    5d44:	39400260 	ldrb	w0, [x19]
    5d48:	7103fc1f 	cmp	w0, #0xff
    5d4c:	540000e0 	b.eq	5d68 <fwp_drop0+0x164>  // b.none
    5d50:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d54:	39000260 	strb	w0, [x19]
    5d58:	17ffffd1 	b	5c9c <fwp_drop0+0x98>
    5d5c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    5d60:	913f0000 	add	x0, x0, #0xfc0
    5d64:	97fff82b 	bl	3e10 <fwp_trap>
    5d68:	aa1303e0 	mov	x0, x19
    5d6c:	97fff849 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5d70:	17fffff8 	b	5d50 <fwp_drop0+0x14c>

0000000000005d74 <fwp_arg_drop12>:
    5d74:	7100003f 	cmp	w1, #0x0
    5d78:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5d7c:	54000041 	b.ne	5d84 <fwp_arg_drop12+0x10>  // b.any
    5d80:	d65f03c0 	ret
    5d84:	f9400000 	ldr	x0, [x0]
    5d88:	17ffff9f 	b	5c04 <fwp_drop0>
    5d8c:	d503201f 	nop

0000000000005d90 <fwp_closure_drop>:
    5d90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5d94:	911500a4 	add	x4, x5, #0x540
    5d98:	aa0003e1 	mov	x1, x0
    5d9c:	f949d882 	ldr	x2, [x4, #5040]
    5da0:	f949ec80 	ldr	x0, [x4, #5080]
    5da4:	cb020022 	sub	x2, x1, x2
    5da8:	eb00405f 	cmp	x2, x0, lsl #16
    5dac:	54000662 	b.cs	5e78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5db0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5db4:	d350fc43 	lsr	x3, x2, #16
    5db8:	910003fd 	mov	x29, sp
    5dbc:	8b030863 	add	x3, x3, x3, lsl #2
    5dc0:	f949fc84 	ldr	x4, [x4, #5112]
    5dc4:	d37df063 	lsl	x3, x3, #3
    5dc8:	f9000bf3 	str	x19, [sp, #16]
    5dcc:	8b030080 	add	x0, x4, x3
    5dd0:	f9401013 	ldr	x19, [x0, #32]
    5dd4:	b40002b3 	cbz	x19, 5e28 <fwp_closure_drop+0x98>
    5dd8:	38636883 	ldrb	w3, [x4, x3]
    5ddc:	7100087f 	cmp	w3, #0x2
    5de0:	54000420 	b.eq	5e64 <fwp_closure_drop+0xd4>  // b.none
    5de4:	7100047f 	cmp	w3, #0x1
    5de8:	54000201 	b.ne	5e28 <fwp_closure_drop+0x98>  // b.any
    5dec:	29430003 	ldp	w3, w0, [x0, #24]
    5df0:	92403c42 	and	x2, x2, #0xffff
    5df4:	9b037c42 	mul	x2, x2, x3
    5df8:	d360fc42 	lsr	x2, x2, #32
    5dfc:	eb00005f 	cmp	x2, x0
    5e00:	54000142 	b.cs	5e28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e04:	8b020273 	add	x19, x19, x2
    5e08:	39400260 	ldrb	w0, [x19]
    5e0c:	340000e0 	cbz	w0, 5e28 <fwp_closure_drop+0x98>
    5e10:	7100041f 	cmp	w0, #0x1
    5e14:	54000100 	b.eq	5e34 <fwp_closure_drop+0xa4>  // b.none
    5e18:	7103fc1f 	cmp	w0, #0xff
    5e1c:	54000300 	b.eq	5e7c <fwp_closure_drop+0xec>  // b.none
    5e20:	51000400 	sub	w0, w0, #0x1
    5e24:	39000260 	strb	w0, [x19]
    5e28:	f9400bf3 	ldr	x19, [sp, #16]
    5e2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e30:	d65f03c0 	ret
    5e34:	d53bd040 	mrs	x0, tpidr_el0
    5e38:	91400000 	add	x0, x0, #0x0, lsl #12
    5e3c:	91004000 	add	x0, x0, #0x10
    5e40:	f9400000 	ldr	x0, [x0]
    5e44:	b4000080 	cbz	x0, 5e54 <fwp_closure_drop+0xc4>
    5e48:	f9400bf3 	ldr	x19, [sp, #16]
    5e4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e50:	17fff96c 	b	4400 <fwp_closure_drop_push>
    5e54:	f9400bf3 	ldr	x19, [sp, #16]
    5e58:	aa0103e0 	mov	x0, x1
    5e5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e60:	17fff9ad 	b	4514 <fwp_closure_drop.part.0>
    5e64:	72003c5f 	tst	w2, #0xffff
    5e68:	54fffd00 	b.eq	5e08 <fwp_closure_drop+0x78>  // b.none
    5e6c:	f9400bf3 	ldr	x19, [sp, #16]
    5e70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e74:	d65f03c0 	ret
    5e78:	d65f03c0 	ret
    5e7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e80:	911500a5 	add	x5, x5, #0x540
    5e84:	ca402400 	eor	x0, x0, x0, lsr #9
    5e88:	92401c00 	and	x0, x0, #0xff
    5e8c:	910a2402 	add	x2, x0, #0x289
    5e90:	8b000ca0 	add	x0, x5, x0, lsl #3
    5e94:	8b020ca2 	add	x2, x5, x2, lsl #3
    5e98:	f94a2400 	ldr	x0, [x0, #5192]
    5e9c:	b50000a0 	cbnz	x0, 5eb0 <fwp_closure_drop+0x120>
    5ea0:	14000013 	b	5eec <fwp_closure_drop+0x15c>
    5ea4:	91004002 	add	x2, x0, #0x10
    5ea8:	f9400800 	ldr	x0, [x0, #16]
    5eac:	b4000200 	cbz	x0, 5eec <fwp_closure_drop+0x15c>
    5eb0:	f9400001 	ldr	x1, [x0]
    5eb4:	eb13003f 	cmp	x1, x19
    5eb8:	54ffff61 	b.ne	5ea4 <fwp_closure_drop+0x114>  // b.any
    5ebc:	f9400041 	ldr	x1, [x2]
    5ec0:	f9400420 	ldr	x0, [x1, #8]
    5ec4:	d1000400 	sub	x0, x0, #0x1
    5ec8:	f9000420 	str	x0, [x1, #8]
    5ecc:	f103f81f 	cmp	x0, #0xfe
    5ed0:	54fffac1 	b.ne	5e28 <fwp_closure_drop+0x98>  // b.any
    5ed4:	39400260 	ldrb	w0, [x19]
    5ed8:	7103fc1f 	cmp	w0, #0xff
    5edc:	540000e0 	b.eq	5ef8 <fwp_closure_drop+0x168>  // b.none
    5ee0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ee4:	39000260 	strb	w0, [x19]
    5ee8:	17ffffd0 	b	5e28 <fwp_closure_drop+0x98>
    5eec:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    5ef0:	913f0000 	add	x0, x0, #0xfc0
    5ef4:	97fff7c7 	bl	3e10 <fwp_trap>
    5ef8:	aa1303e0 	mov	x0, x19
    5efc:	97fff7e5 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5f00:	17fffff8 	b	5ee0 <fwp_closure_drop+0x150>

0000000000005f04 <fwp_owned_tape_release>:
    5f04:	b4000920 	cbz	x0, 6028 <fwp_owned_tape_release+0x124>
    5f08:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f0c:	910003fd 	mov	x29, sp
    5f10:	a90153f3 	stp	x19, x20, [sp, #16]
    5f14:	aa0003f3 	mov	x19, x0
    5f18:	f9400000 	ldr	x0, [x0]
    5f1c:	b4000060 	cbz	x0, 5f28 <fwp_owned_tape_release+0x24>
    5f20:	f9400661 	ldr	x1, [x19, #8]
    5f24:	f9000401 	str	x1, [x0, #8]
    5f28:	f9400661 	ldr	x1, [x19, #8]
    5f2c:	b4000041 	cbz	x1, 5f34 <fwp_owned_tape_release+0x30>
    5f30:	f9000020 	str	x0, [x1]
    5f34:	f9400a60 	ldr	x0, [x19, #16]
    5f38:	f9403401 	ldr	x1, [x0, #104]
    5f3c:	b40005a1 	cbz	x1, 5ff0 <fwp_owned_tape_release+0xec>
    5f40:	a9450a60 	ldp	x0, x2, [x19, #80]
    5f44:	eb00005f 	cmp	x2, x0
    5f48:	540002cd 	b.le	5fa0 <fwp_owned_tape_release+0x9c>
    5f4c:	d2800014 	mov	x20, #0x0                   	// #0
    5f50:	f90013f5 	str	x21, [sp, #32]
    5f54:	d2800015 	mov	x21, #0x0                   	// #0
    5f58:	f9402260 	ldr	x0, [x19, #64]
    5f5c:	910006b5 	add	x21, x21, #0x1
    5f60:	f8746800 	ldr	x0, [x0, x20]
    5f64:	d63f0020 	blr	x1
    5f68:	f9402260 	ldr	x0, [x19, #64]
    5f6c:	f9400a61 	ldr	x1, [x19, #16]
    5f70:	8b140000 	add	x0, x0, x20
    5f74:	91004294 	add	x20, x20, #0x10
    5f78:	f9400400 	ldr	x0, [x0, #8]
    5f7c:	f9403421 	ldr	x1, [x1, #104]
    5f80:	d63f0020 	blr	x1
    5f84:	a9450261 	ldp	x1, x0, [x19, #80]
    5f88:	cb010000 	sub	x0, x0, x1
    5f8c:	eb15001f 	cmp	x0, x21
    5f90:	f9400a60 	ldr	x0, [x19, #16]
    5f94:	f9403401 	ldr	x1, [x0, #104]
    5f98:	54fffe0c 	b.gt	5f58 <fwp_owned_tape_release+0x54>
    5f9c:	f94013f5 	ldr	x21, [sp, #32]
    5fa0:	f9403663 	ldr	x3, [x19, #104]
    5fa4:	f9401262 	ldr	x2, [x19, #32]
    5fa8:	f100007f 	cmp	x3, #0x0
    5fac:	540001ed 	b.le	5fe8 <fwp_owned_tape_release+0xe4>
    5fb0:	d2800014 	mov	x20, #0x0                   	// #0
    5fb4:	d503201f 	nop
    5fb8:	f9402660 	ldr	x0, [x19, #72]
    5fbc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5fc0:	eb02001f 	cmp	x0, x2
    5fc4:	540000c0 	b.eq	5fdc <fwp_owned_tape_release+0xd8>  // b.none
    5fc8:	d63f0020 	blr	x1
    5fcc:	f9400a60 	ldr	x0, [x19, #16]
    5fd0:	f9401262 	ldr	x2, [x19, #32]
    5fd4:	f9403663 	ldr	x3, [x19, #104]
    5fd8:	f9403401 	ldr	x1, [x0, #104]
    5fdc:	91000694 	add	x20, x20, #0x1
    5fe0:	eb14007f 	cmp	x3, x20
    5fe4:	54fffeac 	b.gt	5fb8 <fwp_owned_tape_release+0xb4>
    5fe8:	aa0203e0 	mov	x0, x2
    5fec:	d63f0020 	blr	x1
    5ff0:	f9401660 	ldr	x0, [x19, #40]
    5ff4:	97ffff67 	bl	5d90 <fwp_closure_drop>
    5ff8:	f9401a60 	ldr	x0, [x19, #48]
    5ffc:	97ffff65 	bl	5d90 <fwp_closure_drop>
    6000:	f9401e60 	ldr	x0, [x19, #56]
    6004:	97ffff63 	bl	5d90 <fwp_closure_drop>
    6008:	f9402260 	ldr	x0, [x19, #64]
    600c:	97fff83d 	bl	4100 <fwp_mem_free>
    6010:	f9402660 	ldr	x0, [x19, #72]
    6014:	97fff83b 	bl	4100 <fwp_mem_free>
    6018:	aa1303e0 	mov	x0, x19
    601c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6020:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6024:	17fff837 	b	4100 <fwp_mem_free>
    6028:	d65f03c0 	ret
    602c:	d503201f 	nop

0000000000006030 <fwp_tape_finish>:
    6030:	d10203ff 	sub	sp, sp, #0x80
    6034:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6038:	f947f421 	ldr	x1, [x1, #4072]
    603c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6040:	910103fd 	add	x29, sp, #0x40
    6044:	a90553f3 	stp	x19, x20, [sp, #80]
    6048:	a9065bf5 	stp	x21, x22, [sp, #96]
    604c:	a90763f7 	stp	x23, x24, [sp, #112]
    6050:	d00000d8 	adrp	x24, 20000 <__data_start>
    6054:	9100c316 	add	x22, x24, #0x30
    6058:	f9400022 	ldr	x2, [x1]
    605c:	f9001fe2 	str	x2, [sp, #56]
    6060:	d2800002 	mov	x2, #0x0                   	// #0
    6064:	9100e2c0 	add	x0, x22, #0x38
    6068:	97fff486 	bl	3280 <fwp_tape_buffers_dispose>
    606c:	f9003adf 	str	xzr, [x22, #112]
    6070:	f94042c0 	ldr	x0, [x22, #128]
    6074:	f100001f 	cmp	x0, #0x0
    6078:	5400030d 	b.le	60d8 <fwp_tape_finish+0xa8>
    607c:	910003f7 	mov	x23, sp
    6080:	d2800015 	mov	x21, #0x0                   	// #0
    6084:	d2800014 	mov	x20, #0x0                   	// #0
    6088:	f94002d3 	ldr	x19, [x22]
    608c:	91000694 	add	x20, x20, #0x1
    6090:	8b150273 	add	x19, x19, x21
    6094:	9101a2b5 	add	x21, x21, #0x68
    6098:	aa1303e0 	mov	x0, x19
    609c:	97fff39d 	bl	2f10 <fwp_tape_unlink_scope>
    60a0:	aa1703e0 	mov	x0, x23
    60a4:	f9401261 	ldr	x1, [x19, #32]
    60a8:	f90003e1 	str	x1, [sp]
    60ac:	f9401a62 	ldr	x2, [x19, #48]
    60b0:	f9000be2 	str	x2, [sp, #16]
    60b4:	f9402261 	ldr	x1, [x19, #64]
    60b8:	f90013e1 	str	x1, [sp, #32]
    60bc:	97fff471 	bl	3280 <fwp_tape_buffers_dispose>
    60c0:	f9403260 	ldr	x0, [x19, #96]
    60c4:	97ffff90 	bl	5f04 <fwp_owned_tape_release>
    60c8:	f900327f 	str	xzr, [x19, #96]
    60cc:	f94042c0 	ldr	x0, [x22, #128]
    60d0:	eb14001f 	cmp	x0, x20
    60d4:	54fffdac 	b.gt	6088 <fwp_tape_finish+0x58>
    60d8:	f9401b00 	ldr	x0, [x24, #48]
    60dc:	9100c313 	add	x19, x24, #0x30
    60e0:	97fff1f4 	bl	28b0 <free@plt>
    60e4:	f9001b1f 	str	xzr, [x24, #48]
    60e8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    60ec:	f947f400 	ldr	x0, [x0, #4072]
    60f0:	f900427f 	str	xzr, [x19, #128]
    60f4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    60f8:	f9401fe2 	ldr	x2, [sp, #56]
    60fc:	f9400001 	ldr	x1, [x0]
    6100:	eb010042 	subs	x2, x2, x1
    6104:	d2800001 	mov	x1, #0x0                   	// #0
    6108:	540000e1 	b.ne	6124 <fwp_tape_finish+0xf4>  // b.any
    610c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6110:	a94553f3 	ldp	x19, x20, [sp, #80]
    6114:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6118:	a94763f7 	ldp	x23, x24, [sp, #112]
    611c:	910203ff 	add	sp, sp, #0x80
    6120:	d65f03c0 	ret
    6124:	97fff1b3 	bl	27f0 <__stack_chk_fail@plt>
    6128:	d503201f 	nop
    612c:	d503201f 	nop

0000000000006130 <fwp_tape_scope_release>:
    6130:	d10243ff 	sub	sp, sp, #0x90
    6134:	a9047bfd 	stp	x29, x30, [sp, #64]
    6138:	910103fd 	add	x29, sp, #0x40
    613c:	a90553f3 	stp	x19, x20, [sp, #80]
    6140:	aa0003f4 	mov	x20, x0
    6144:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6148:	f947f400 	ldr	x0, [x0, #4072]
    614c:	b9400285 	ldr	w5, [x20]
    6150:	f9400001 	ldr	x1, [x0]
    6154:	f9001fe1 	str	x1, [sp, #56]
    6158:	d2800001 	mov	x1, #0x0                   	// #0
    615c:	37f806c5 	tbnz	w5, #31, 6234 <fwp_tape_scope_release+0x104>
    6160:	a90763f7 	stp	x23, x24, [sp, #112]
    6164:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6168:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    616c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6170:	d00000d3 	adrp	x19, 20000 <__data_start>
    6174:	910003f7 	mov	x23, sp
    6178:	9100c273 	add	x19, x19, #0x30
    617c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6180:	a9065bf5 	stp	x21, x22, [sp, #96]
    6184:	52800d16 	mov	w22, #0x68                  	// #104
    6188:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    618c:	f90043f9 	str	x25, [sp, #128]
    6190:	14000006 	b	61a8 <fwp_tape_scope_release+0x78>
    6194:	97fff43b 	bl	3280 <fwp_tape_buffers_dispose>
    6198:	aa1903e0 	mov	x0, x25
    619c:	97ffff5a 	bl	5f04 <fwp_owned_tape_release>
    61a0:	b9400285 	ldr	w5, [x20]
    61a4:	37f80425 	tbnz	w5, #31, 6228 <fwp_tape_scope_release+0xf8>
    61a8:	f9400266 	ldr	x6, [x19]
    61ac:	9b367ca5 	smull	x5, w5, w22
    61b0:	8b0500c0 	add	x0, x6, x5
    61b4:	97fff357 	bl	2f10 <fwp_tape_unlink_scope>
    61b8:	ad410001 	ldp	q1, q0, [x0, #32]
    61bc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    61c0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    61c4:	f9400c03 	ldr	x3, [x0, #24]
    61c8:	ad0003e1 	stp	q1, q0, [sp]
    61cc:	b86568c1 	ldr	w1, [x6, x5]
    61d0:	a9440804 	ldp	x4, x2, [x0, #64]
    61d4:	b900041f 	str	wzr, [x0, #4]
    61d8:	f9403019 	ldr	x25, [x0, #96]
    61dc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    61e0:	f9000c1f 	str	xzr, [x0, #24]
    61e4:	a9020fe4 	stp	x4, x3, [sp, #32]
    61e8:	f9001be2 	str	x2, [sp, #48]
    61ec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    61f0:	f900301f 	str	xzr, [x0, #96]
    61f4:	6b15003f 	cmp	w1, w21
    61f8:	540000e8 	b.hi	6214 <fwp_tape_scope_release+0xe4>  // b.pmore
    61fc:	9343fca5 	asr	x5, x5, #3
    6200:	f9404e60 	ldr	x0, [x19, #152]
    6204:	9b187ca5 	mul	x5, x5, x24
    6208:	eb0000bf 	cmp	x5, x0
    620c:	5400004a 	b.ge	6214 <fwp_tape_scope_release+0xe4>  // b.tcont
    6210:	f9004e65 	str	x5, [x19, #152]
    6214:	aa1703e0 	mov	x0, x23
    6218:	b5fffbf9 	cbnz	x25, 6194 <fwp_tape_scope_release+0x64>
    621c:	97fff6b5 	bl	3cf0 <fwp_tape_buffers_release>
    6220:	b9400285 	ldr	w5, [x20]
    6224:	36fffc25 	tbz	w5, #31, 61a8 <fwp_tape_scope_release+0x78>
    6228:	a9465bf5 	ldp	x21, x22, [sp, #96]
    622c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6230:	f94043f9 	ldr	x25, [sp, #128]
    6234:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6238:	f947f400 	ldr	x0, [x0, #4072]
    623c:	f9401fe2 	ldr	x2, [sp, #56]
    6240:	f9400001 	ldr	x1, [x0]
    6244:	eb010042 	subs	x2, x2, x1
    6248:	d2800001 	mov	x1, #0x0                   	// #0
    624c:	540000a1 	b.ne	6260 <fwp_tape_scope_release+0x130>  // b.any
    6250:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6254:	a94553f3 	ldp	x19, x20, [sp, #80]
    6258:	910243ff 	add	sp, sp, #0x90
    625c:	d65f03c0 	ret
    6260:	a9065bf5 	stp	x21, x22, [sp, #96]
    6264:	a90763f7 	stp	x23, x24, [sp, #112]
    6268:	f90043f9 	str	x25, [sp, #128]
    626c:	97fff161 	bl	27f0 <__stack_chk_fail@plt>

0000000000006270 <fwp_task_dispose>:
    6270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6274:	910003fd 	mov	x29, sp
    6278:	f9000bf3 	str	x19, [sp, #16]
    627c:	aa0003f3 	mov	x19, x0
    6280:	39414000 	ldrb	w0, [x0, #80]
    6284:	36000720 	tbz	w0, #0, 6368 <fwp_task_dispose+0xf8>
    6288:	f9400a60 	ldr	x0, [x19, #16]
    628c:	b50006e0 	cbnz	x0, 6368 <fwp_task_dispose+0xf8>
    6290:	a9478660 	ldp	x0, x1, [x19, #120]
    6294:	39014e7f 	strb	wzr, [x19, #83]
    6298:	f9003e7f 	str	xzr, [x19, #120]
    629c:	f100003f 	cmp	x1, #0x0
    62a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    62a4:	54000040 	b.eq	62ac <fwp_task_dispose+0x3c>  // b.none
    62a8:	d63f0020 	blr	x1
    62ac:	f9405660 	ldr	x0, [x19, #168]
    62b0:	97fff794 	bl	4100 <fwp_mem_free>
    62b4:	f900567f 	str	xzr, [x19, #168]
    62b8:	b9405e60 	ldr	w0, [x19, #92]
    62bc:	7100041f 	cmp	w0, #0x1
    62c0:	54000420 	b.eq	6344 <fwp_task_dispose+0xd4>  // b.none
    62c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    62c8:	91150042 	add	x2, x2, #0x540
    62cc:	f949d840 	ldr	x0, [x2, #5040]
    62d0:	f949ec41 	ldr	x1, [x2, #5080]
    62d4:	cb000260 	sub	x0, x19, x0
    62d8:	eb01401f 	cmp	x0, x1, lsl #16
    62dc:	540002e2 	b.cs	6338 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62e0:	d350fc01 	lsr	x1, x0, #16
    62e4:	f949fc44 	ldr	x4, [x2, #5112]
    62e8:	8b010821 	add	x1, x1, x1, lsl #2
    62ec:	d37df021 	lsl	x1, x1, #3
    62f0:	8b010083 	add	x3, x4, x1
    62f4:	f9401062 	ldr	x2, [x3, #32]
    62f8:	b4000202 	cbz	x2, 6338 <fwp_task_dispose+0xc8>
    62fc:	38616881 	ldrb	w1, [x4, x1]
    6300:	7100083f 	cmp	w1, #0x2
    6304:	54000280 	b.eq	6354 <fwp_task_dispose+0xe4>  // b.none
    6308:	7100043f 	cmp	w1, #0x1
    630c:	54000161 	b.ne	6338 <fwp_task_dispose+0xc8>  // b.any
    6310:	29430464 	ldp	w4, w1, [x3, #24]
    6314:	92403c00 	and	x0, x0, #0xffff
    6318:	9b047c00 	mul	x0, x0, x4
    631c:	d360fc00 	lsr	x0, x0, #32
    6320:	eb01001f 	cmp	x0, x1
    6324:	540000a2 	b.cs	6338 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6328:	8b000042 	add	x2, x2, x0
    632c:	39400040 	ldrb	w0, [x2]
    6330:	7100041f 	cmp	w0, #0x1
    6334:	54000080 	b.eq	6344 <fwp_task_dispose+0xd4>  // b.none
    6338:	f9400bf3 	ldr	x19, [sp, #16]
    633c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6340:	d65f03c0 	ret
    6344:	aa1303e0 	mov	x0, x19
    6348:	f9400bf3 	ldr	x19, [sp, #16]
    634c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6350:	17fff76c 	b	4100 <fwp_mem_free>
    6354:	72003c1f 	tst	w0, #0xffff
    6358:	54fffea0 	b.eq	632c <fwp_task_dispose+0xbc>  // b.none
    635c:	f9400bf3 	ldr	x19, [sp, #16]
    6360:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6364:	d65f03c0 	ret
    6368:	97fff136 	bl	2840 <abort@plt>
    636c:	d503201f 	nop

0000000000006370 <fwp_free_zombie>:
    6370:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6374:	910003fd 	mov	x29, sp
    6378:	a90153f3 	stp	x19, x20, [sp, #16]
    637c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6380:	9100c281 	add	x1, x20, #0x30
    6384:	f9405033 	ldr	x19, [x1, #160]
    6388:	b4000333 	cbz	x19, 63ec <fwp_free_zombie+0x7c>
    638c:	f9400820 	ldr	x0, [x1, #16]
    6390:	eb00027f 	cmp	x19, x0
    6394:	540002c0 	b.eq	63ec <fwp_free_zombie+0x7c>  // b.none
    6398:	b940a822 	ldr	w2, [x1, #168]
    639c:	f9400a60 	ldr	x0, [x19, #16]
    63a0:	7100fc5f 	cmp	w2, #0x3f
    63a4:	5400078c 	b.gt	6494 <fwp_free_zombie+0x124>
    63a8:	9102c023 	add	x3, x1, #0xb0
    63ac:	11000444 	add	w4, w2, #0x1
    63b0:	b900a824 	str	w4, [x1, #168]
    63b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    63bc:	a9530261 	ldp	x1, x0, [x19, #304]
    63c0:	b4000741 	cbz	x1, 64a8 <fwp_free_zombie+0x138>
    63c4:	f9009c20 	str	x0, [x1, #312]
    63c8:	b4000040 	cbz	x0, 63d0 <fwp_free_zombie+0x60>
    63cc:	f9009801 	str	x1, [x0, #304]
    63d0:	9100c294 	add	x20, x20, #0x30
    63d4:	b9405e60 	ldr	w0, [x19, #92]
    63d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    63dc:	f900529f 	str	xzr, [x20, #160]
    63e0:	34000140 	cbz	w0, 6408 <fwp_free_zombie+0x98>
    63e4:	7100041f 	cmp	w0, #0x1
    63e8:	54000080 	b.eq	63f8 <fwp_free_zombie+0x88>  // b.none
    63ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    63f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63f4:	d65f03c0 	ret
    63f8:	aa1303e0 	mov	x0, x19
    63fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6400:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6404:	17ffff9b 	b	6270 <fwp_task_dispose>
    6408:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    640c:	91150082 	add	x2, x4, #0x540
    6410:	f949d841 	ldr	x1, [x2, #5040]
    6414:	f949ec40 	ldr	x0, [x2, #5080]
    6418:	cb010261 	sub	x1, x19, x1
    641c:	eb00403f 	cmp	x1, x0, lsl #16
    6420:	54fffe62 	b.cs	63ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6424:	d350fc20 	lsr	x0, x1, #16
    6428:	f949fc43 	ldr	x3, [x2, #5112]
    642c:	8b000800 	add	x0, x0, x0, lsl #2
    6430:	d37df000 	lsl	x0, x0, #3
    6434:	8b000062 	add	x2, x3, x0
    6438:	f9401054 	ldr	x20, [x2, #32]
    643c:	b4fffd94 	cbz	x20, 63ec <fwp_free_zombie+0x7c>
    6440:	38606860 	ldrb	w0, [x3, x0]
    6444:	7100081f 	cmp	w0, #0x2
    6448:	54000360 	b.eq	64b4 <fwp_free_zombie+0x144>  // b.none
    644c:	7100041f 	cmp	w0, #0x1
    6450:	54fffce1 	b.ne	63ec <fwp_free_zombie+0x7c>  // b.any
    6454:	29430043 	ldp	w3, w0, [x2, #24]
    6458:	92403c21 	and	x1, x1, #0xffff
    645c:	9b037c21 	mul	x1, x1, x3
    6460:	d360fc21 	lsr	x1, x1, #32
    6464:	eb00003f 	cmp	x1, x0
    6468:	54fffc22 	b.cs	63ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    646c:	8b010294 	add	x20, x20, x1
    6470:	39400280 	ldrb	w0, [x20]
    6474:	34fffbc0 	cbz	w0, 63ec <fwp_free_zombie+0x7c>
    6478:	7100041f 	cmp	w0, #0x1
    647c:	54fffbe0 	b.eq	63f8 <fwp_free_zombie+0x88>  // b.none
    6480:	7103fc1f 	cmp	w0, #0xff
    6484:	540001e0 	b.eq	64c0 <fwp_free_zombie+0x150>  // b.none
    6488:	51000400 	sub	w0, w0, #0x1
    648c:	39000280 	strb	w0, [x20]
    6490:	17ffffd7 	b	63ec <fwp_free_zombie+0x7c>
    6494:	f9400e61 	ldr	x1, [x19, #24]
    6498:	97fff11e 	bl	2910 <munmap@plt>
    649c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    64a0:	a9530261 	ldp	x1, x0, [x19, #304]
    64a4:	b5fff901 	cbnz	x1, 63c4 <fwp_free_zombie+0x54>
    64a8:	9100c282 	add	x2, x20, #0x30
    64ac:	f9015840 	str	x0, [x2, #688]
    64b0:	17ffffc6 	b	63c8 <fwp_free_zombie+0x58>
    64b4:	72003c3f 	tst	w1, #0xffff
    64b8:	54fff9a1 	b.ne	63ec <fwp_free_zombie+0x7c>  // b.any
    64bc:	17ffffed 	b	6470 <fwp_free_zombie+0x100>
    64c0:	ca544680 	eor	x0, x20, x20, lsr #17
    64c4:	91150084 	add	x4, x4, #0x540
    64c8:	ca402400 	eor	x0, x0, x0, lsr #9
    64cc:	92401c00 	and	x0, x0, #0xff
    64d0:	910a2402 	add	x2, x0, #0x289
    64d4:	8b000c80 	add	x0, x4, x0, lsl #3
    64d8:	8b020c82 	add	x2, x4, x2, lsl #3
    64dc:	f94a2400 	ldr	x0, [x0, #5192]
    64e0:	b50000a0 	cbnz	x0, 64f4 <fwp_free_zombie+0x184>
    64e4:	14000013 	b	6530 <fwp_free_zombie+0x1c0>
    64e8:	91004002 	add	x2, x0, #0x10
    64ec:	f9400800 	ldr	x0, [x0, #16]
    64f0:	b4000200 	cbz	x0, 6530 <fwp_free_zombie+0x1c0>
    64f4:	f9400001 	ldr	x1, [x0]
    64f8:	eb14003f 	cmp	x1, x20
    64fc:	54ffff61 	b.ne	64e8 <fwp_free_zombie+0x178>  // b.any
    6500:	f9400041 	ldr	x1, [x2]
    6504:	f9400420 	ldr	x0, [x1, #8]
    6508:	d1000400 	sub	x0, x0, #0x1
    650c:	f9000420 	str	x0, [x1, #8]
    6510:	f103f81f 	cmp	x0, #0xfe
    6514:	54fff6c1 	b.ne	63ec <fwp_free_zombie+0x7c>  // b.any
    6518:	39400280 	ldrb	w0, [x20]
    651c:	7103fc1f 	cmp	w0, #0xff
    6520:	540000e0 	b.eq	653c <fwp_free_zombie+0x1cc>  // b.none
    6524:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6528:	39000280 	strb	w0, [x20]
    652c:	17ffffb0 	b	63ec <fwp_free_zombie+0x7c>
    6530:	90000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    6534:	913f0000 	add	x0, x0, #0xfc0
    6538:	97fff636 	bl	3e10 <fwp_trap>
    653c:	aa1403e0 	mov	x0, x20
    6540:	97fff654 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6544:	17fffff8 	b	6524 <fwp_free_zombie+0x1b4>
    6548:	d503201f 	nop
    654c:	d503201f 	nop

0000000000006550 <fwp_block>:
    6550:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6554:	910003fd 	mov	x29, sp
    6558:	a90153f3 	stp	x19, x20, [sp, #16]
    655c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6560:	9100c274 	add	x20, x19, #0x30
    6564:	f9401a82 	ldr	x2, [x20, #48]
    6568:	b4000642 	cbz	x2, 6630 <fwp_block+0xe0>
    656c:	9100c261 	add	x1, x19, #0x30
    6570:	f9408040 	ldr	x0, [x2, #256]
    6574:	f9001820 	str	x0, [x1, #48]
    6578:	b40006a0 	cbz	x0, 664c <fwp_block+0xfc>
    657c:	d503201f 	nop
    6580:	9100c263 	add	x3, x19, #0x30
    6584:	3901505f 	strb	wzr, [x2, #84]
    6588:	f9400864 	ldr	x4, [x3, #16]
    658c:	eb02009f 	cmp	x4, x2
    6590:	54000440 	b.eq	6618 <fwp_block+0xc8>  // b.none
    6594:	f9415c65 	ldr	x5, [x3, #696]
    6598:	f9000862 	str	x2, [x3, #16]
    659c:	f9400441 	ldr	x1, [x2, #8]
    65a0:	f9004885 	str	x5, [x4, #144]
    65a4:	f9416065 	ldr	x5, [x3, #704]
    65a8:	f9004c85 	str	x5, [x4, #152]
    65ac:	f9416465 	ldr	x5, [x3, #712]
    65b0:	f9005085 	str	x5, [x4, #160]
    65b4:	f9416865 	ldr	x5, [x3, #720]
    65b8:	f9005485 	str	x5, [x4, #168]
    65bc:	f9416c65 	ldr	x5, [x3, #728]
    65c0:	f9005885 	str	x5, [x4, #176]
    65c4:	f9417065 	ldr	x5, [x3, #736]
    65c8:	f9005c85 	str	x5, [x4, #184]
    65cc:	f9417465 	ldr	x5, [x3, #744]
    65d0:	f9006085 	str	x5, [x4, #192]
    65d4:	f9400480 	ldr	x0, [x4, #8]
    65d8:	f9404844 	ldr	x4, [x2, #144]
    65dc:	f9015c64 	str	x4, [x3, #696]
    65e0:	f9404c44 	ldr	x4, [x2, #152]
    65e4:	f9016064 	str	x4, [x3, #704]
    65e8:	f9405044 	ldr	x4, [x2, #160]
    65ec:	f9016464 	str	x4, [x3, #712]
    65f0:	f9405444 	ldr	x4, [x2, #168]
    65f4:	f9016864 	str	x4, [x3, #720]
    65f8:	f9405844 	ldr	x4, [x2, #176]
    65fc:	f9016c64 	str	x4, [x3, #728]
    6600:	a94b8844 	ldp	x4, x2, [x2, #184]
    6604:	f9017064 	str	x4, [x3, #736]
    6608:	f9017462 	str	x2, [x3, #744]
    660c:	97fff091 	bl	2850 <swapcontext@plt>
    6610:	97ffff58 	bl	6370 <fwp_free_zombie>
    6614:	d503201f 	nop
    6618:	9100c260 	add	x0, x19, #0x30
    661c:	b942f000 	ldr	w0, [x0, #752]
    6620:	340001a0 	cbz	w0, 6654 <fwp_block+0x104>
    6624:	a94153f3 	ldp	x19, x20, [sp, #16]
    6628:	a8c27bfd 	ldp	x29, x30, [sp], #32
    662c:	d65f03c0 	ret
    6630:	97fff840 	bl	4730 <fwp_poll_events>
    6634:	f9401a82 	ldr	x2, [x20, #48]
    6638:	b4ffffc2 	cbz	x2, 6630 <fwp_block+0xe0>
    663c:	9100c261 	add	x1, x19, #0x30
    6640:	f9408040 	ldr	x0, [x2, #256]
    6644:	f9001820 	str	x0, [x1, #48]
    6648:	b5fff9c0 	cbnz	x0, 6580 <fwp_block+0x30>
    664c:	f900143f 	str	xzr, [x1, #40]
    6650:	17ffffcc 	b	6580 <fwp_block+0x30>
    6654:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    6658:	91096000 	add	x0, x0, #0x258
    665c:	97fff0c9 	bl	2980 <getenv@plt>
    6660:	5284e202 	mov	w2, #0x2710                	// #10000
    6664:	b4000060 	cbz	x0, 6670 <fwp_block+0x120>
    6668:	39400001 	ldrb	w1, [x0]
    666c:	350000c1 	cbnz	w1, 6684 <fwp_block+0x134>
    6670:	9100c273 	add	x19, x19, #0x30
    6674:	b902f262 	str	w2, [x19, #752]
    6678:	a94153f3 	ldp	x19, x20, [sp, #16]
    667c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6680:	d65f03c0 	ret
    6684:	52800142 	mov	w2, #0xa                   	// #10
    6688:	d2800001 	mov	x1, #0x0                   	// #0
    668c:	97fff00d 	bl	26c0 <strtoll@plt>
    6690:	d1000403 	sub	x3, x0, #0x1
    6694:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6698:	eb02007f 	cmp	x3, x2
    669c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    66a0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    66a4:	17fffff3 	b	6670 <fwp_block+0x120>
    66a8:	d503201f 	nop
    66ac:	d503201f 	nop

00000000000066b0 <fwp_owned_entry161>:
    66b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    66b4:	910003fd 	mov	x29, sp
    66b8:	a90363f7 	stp	x23, x24, [sp, #48]
    66bc:	a9406002 	ldp	x2, x24, [x0]
    66c0:	a90153f3 	stp	x19, x20, [sp, #16]
    66c4:	f9400801 	ldr	x1, [x0, #16]
    66c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    66cc:	ab010055 	adds	x21, x2, x1
    66d0:	54000d06 	b.vs	6870 <fwp_owned_entry161+0x1c0>
    66d4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    66d8:	91150281 	add	x1, x20, #0x540
    66dc:	b953a420 	ldr	w0, [x1, #5028]
    66e0:	34000a80 	cbz	w0, 6830 <fwp_owned_entry161+0x180>
    66e4:	397e8820 	ldrb	w0, [x1, #4002]
    66e8:	910f0002 	add	x2, x0, #0x3c0
    66ec:	8b000400 	add	x0, x0, x0, lsl #1
    66f0:	d37df000 	lsl	x0, x0, #3
    66f4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    66f8:	2a1703f6 	mov	w22, w23
    66fc:	f8606833 	ldr	x19, [x1, x0]
    6700:	b4000853 	cbz	x19, 6808 <fwp_owned_entry161+0x158>
    6704:	f9400262 	ldr	x2, [x19]
    6708:	aa2203e2 	mvn	x2, x2
    670c:	f8206822 	str	x2, [x1, x0]
    6710:	f10062df 	cmp	x22, #0x18
    6714:	540000e9 	b.ls	6730 <fwp_owned_entry161+0x80>  // b.plast
    6718:	d10066c2 	sub	x2, x22, #0x19
    671c:	91006260 	add	x0, x19, #0x18
    6720:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6724:	52800001 	mov	w1, #0x0                   	// #0
    6728:	91002042 	add	x2, x2, #0x8
    672c:	97fff025 	bl	27c0 <memset@plt>
    6730:	91150281 	add	x1, x20, #0x540
    6734:	f94a1020 	ldr	x0, [x1, #5152]
    6738:	ab160000 	adds	x0, x0, x22
    673c:	540009c2 	b.cs	6874 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6740:	f94a1422 	ldr	x2, [x1, #5160]
    6744:	f90a1020 	str	x0, [x1, #5152]
    6748:	eb02001f 	cmp	x0, x2
    674c:	54000049 	b.ls	6754 <fwp_owned_entry161+0xa4>  // b.plast
    6750:	f90a1420 	str	x0, [x1, #5160]
    6754:	91150280 	add	x0, x20, #0x540
    6758:	1e6302e1 	ucvtf	d1, w23
    675c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6760:	1e612800 	fadd	d0, d0, d1
    6764:	fd0a1c00 	str	d0, [x0, #5176]
    6768:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    676c:	91150294 	add	x20, x20, #0x540
    6770:	a900d678 	stp	x24, x21, [x19, #8]
    6774:	fd45a800 	ldr	d0, [x0, #2896]
    6778:	fd000260 	str	d0, [x19]
    677c:	f949da81 	ldr	x1, [x20, #5040]
    6780:	f949ee80 	ldr	x0, [x20, #5080]
    6784:	cb010261 	sub	x1, x19, x1
    6788:	eb00403f 	cmp	x1, x0, lsl #16
    678c:	54000322 	b.cs	67f0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6790:	d350fc20 	lsr	x0, x1, #16
    6794:	f949fe83 	ldr	x3, [x20, #5112]
    6798:	8b000800 	add	x0, x0, x0, lsl #2
    679c:	d37df002 	lsl	x2, x0, #3
    67a0:	8b020060 	add	x0, x3, x2
    67a4:	f9401014 	ldr	x20, [x0, #32]
    67a8:	b4000254 	cbz	x20, 67f0 <fwp_owned_entry161+0x140>
    67ac:	38626862 	ldrb	w2, [x3, x2]
    67b0:	7100085f 	cmp	w2, #0x2
    67b4:	54000480 	b.eq	6844 <fwp_owned_entry161+0x194>  // b.none
    67b8:	7100045f 	cmp	w2, #0x1
    67bc:	540001a1 	b.ne	67f0 <fwp_owned_entry161+0x140>  // b.any
    67c0:	29430002 	ldp	w2, w0, [x0, #24]
    67c4:	92403c21 	and	x1, x1, #0xffff
    67c8:	9b027c21 	mul	x1, x1, x2
    67cc:	d360fc21 	lsr	x1, x1, #32
    67d0:	eb00003f 	cmp	x1, x0
    67d4:	540000e2 	b.cs	67f0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    67d8:	8b010294 	add	x20, x20, x1
    67dc:	39400280 	ldrb	w0, [x20]
    67e0:	7103fc1f 	cmp	w0, #0xff
    67e4:	54000400 	b.eq	6864 <fwp_owned_entry161+0x1b4>  // b.none
    67e8:	52800020 	mov	w0, #0x1                   	// #1
    67ec:	39000280 	strb	w0, [x20]
    67f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    67f4:	aa1303e0 	mov	x0, x19
    67f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    6800:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6804:	d65f03c0 	ret
    6808:	8b000021 	add	x1, x1, x0
    680c:	f9400433 	ldr	x19, [x1, #8]
    6810:	b4000113 	cbz	x19, 6830 <fwp_owned_entry161+0x180>
    6814:	f9400820 	ldr	x0, [x1, #16]
    6818:	cb130000 	sub	x0, x0, x19
    681c:	eb0002df 	cmp	x22, x0
    6820:	54000088 	b.hi	6830 <fwp_owned_entry161+0x180>  // b.pmore
    6824:	8b160260 	add	x0, x19, x22
    6828:	f9000420 	str	x0, [x1, #8]
    682c:	17ffffb9 	b	6710 <fwp_owned_entry161+0x60>
    6830:	52800001 	mov	w1, #0x0                   	// #0
    6834:	d2800300 	mov	x0, #0x18                  	// #24
    6838:	97fff8ee 	bl	4bf0 <fwp_heap_alloc>
    683c:	aa0003f3 	mov	x19, x0
    6840:	17ffffca 	b	6768 <fwp_owned_entry161+0xb8>
    6844:	72003c3f 	tst	w1, #0xffff
    6848:	54fffca0 	b.eq	67dc <fwp_owned_entry161+0x12c>  // b.none
    684c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6850:	aa1303e0 	mov	x0, x19
    6854:	a94153f3 	ldp	x19, x20, [sp, #16]
    6858:	a94363f7 	ldp	x23, x24, [sp, #48]
    685c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6860:	d65f03c0 	ret
    6864:	aa1403e0 	mov	x0, x20
    6868:	97fff58a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    686c:	17ffffdf 	b	67e8 <fwp_owned_entry161+0x138>
    6870:	97fff064 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6874:	97fff1cf 	bl	2fb0 <fwp_heap_oom>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <e161>:
    6880:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6884:	910003fd 	mov	x29, sp
    6888:	a90363f7 	stp	x23, x24, [sp, #48]
    688c:	a9406002 	ldp	x2, x24, [x0]
    6890:	a90153f3 	stp	x19, x20, [sp, #16]
    6894:	f9400801 	ldr	x1, [x0, #16]
    6898:	a9025bf5 	stp	x21, x22, [sp, #32]
    689c:	ab010055 	adds	x21, x2, x1
    68a0:	54000d86 	b.vs	6a50 <e161+0x1d0>
    68a4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    68a8:	91150281 	add	x1, x20, #0x540
    68ac:	b953a420 	ldr	w0, [x1, #5028]
    68b0:	34000ac0 	cbz	w0, 6a08 <e161+0x188>
    68b4:	397e8820 	ldrb	w0, [x1, #4002]
    68b8:	910f0002 	add	x2, x0, #0x3c0
    68bc:	8b000400 	add	x0, x0, x0, lsl #1
    68c0:	d37df000 	lsl	x0, x0, #3
    68c4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    68c8:	2a1703f6 	mov	w22, w23
    68cc:	f8606833 	ldr	x19, [x1, x0]
    68d0:	b4000893 	cbz	x19, 69e0 <e161+0x160>
    68d4:	f9400262 	ldr	x2, [x19]
    68d8:	aa2203e2 	mvn	x2, x2
    68dc:	f8206822 	str	x2, [x1, x0]
    68e0:	f10062df 	cmp	x22, #0x18
    68e4:	540000e9 	b.ls	6900 <e161+0x80>  // b.plast
    68e8:	d10066c2 	sub	x2, x22, #0x19
    68ec:	91006260 	add	x0, x19, #0x18
    68f0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    68f4:	52800001 	mov	w1, #0x0                   	// #0
    68f8:	91002042 	add	x2, x2, #0x8
    68fc:	97ffefb1 	bl	27c0 <memset@plt>
    6900:	91150281 	add	x1, x20, #0x540
    6904:	f94a1020 	ldr	x0, [x1, #5152]
    6908:	ab160000 	adds	x0, x0, x22
    690c:	54000a42 	b.cs	6a54 <e161+0x1d4>  // b.hs, b.nlast
    6910:	f94a1422 	ldr	x2, [x1, #5160]
    6914:	f90a1020 	str	x0, [x1, #5152]
    6918:	eb02001f 	cmp	x0, x2
    691c:	54000049 	b.ls	6924 <e161+0xa4>  // b.plast
    6920:	f90a1420 	str	x0, [x1, #5160]
    6924:	91150280 	add	x0, x20, #0x540
    6928:	1e6302e1 	ucvtf	d1, w23
    692c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6930:	1e612800 	fadd	d0, d0, d1
    6934:	fd0a1c00 	str	d0, [x0, #5176]
    6938:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    693c:	91150294 	add	x20, x20, #0x540
    6940:	a900d678 	stp	x24, x21, [x19, #8]
    6944:	fd45a800 	ldr	d0, [x0, #2896]
    6948:	fd000260 	str	d0, [x19]
    694c:	f949da81 	ldr	x1, [x20, #5040]
    6950:	f949ee80 	ldr	x0, [x20, #5080]
    6954:	cb010261 	sub	x1, x19, x1
    6958:	eb00403f 	cmp	x1, x0, lsl #16
    695c:	54000322 	b.cs	69c0 <e161+0x140>  // b.hs, b.nlast
    6960:	d350fc20 	lsr	x0, x1, #16
    6964:	f949fe83 	ldr	x3, [x20, #5112]
    6968:	8b000800 	add	x0, x0, x0, lsl #2
    696c:	d37df002 	lsl	x2, x0, #3
    6970:	8b020060 	add	x0, x3, x2
    6974:	f9401014 	ldr	x20, [x0, #32]
    6978:	b4000254 	cbz	x20, 69c0 <e161+0x140>
    697c:	38626862 	ldrb	w2, [x3, x2]
    6980:	7100085f 	cmp	w2, #0x2
    6984:	540004c0 	b.eq	6a1c <e161+0x19c>  // b.none
    6988:	7100045f 	cmp	w2, #0x1
    698c:	540001a1 	b.ne	69c0 <e161+0x140>  // b.any
    6990:	29430002 	ldp	w2, w0, [x0, #24]
    6994:	92403c21 	and	x1, x1, #0xffff
    6998:	9b027c21 	mul	x1, x1, x2
    699c:	d360fc21 	lsr	x1, x1, #32
    69a0:	eb00003f 	cmp	x1, x0
    69a4:	540000e2 	b.cs	69c0 <e161+0x140>  // b.hs, b.nlast
    69a8:	8b010294 	add	x20, x20, x1
    69ac:	39400280 	ldrb	w0, [x20]
    69b0:	7103fc1f 	cmp	w0, #0xff
    69b4:	54000480 	b.eq	6a44 <e161+0x1c4>  // b.none
    69b8:	52800020 	mov	w0, #0x1                   	// #1
    69bc:	39000280 	strb	w0, [x20]
    69c0:	aa1303e0 	mov	x0, x19
    69c4:	97fffbc8 	bl	58e4 <fwp_rc_share>
    69c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    69cc:	aa1303e0 	mov	x0, x19
    69d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    69d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    69dc:	d65f03c0 	ret
    69e0:	8b000021 	add	x1, x1, x0
    69e4:	f9400433 	ldr	x19, [x1, #8]
    69e8:	b4000113 	cbz	x19, 6a08 <e161+0x188>
    69ec:	f9400820 	ldr	x0, [x1, #16]
    69f0:	cb130000 	sub	x0, x0, x19
    69f4:	eb0002df 	cmp	x22, x0
    69f8:	54000088 	b.hi	6a08 <e161+0x188>  // b.pmore
    69fc:	8b160260 	add	x0, x19, x22
    6a00:	f9000420 	str	x0, [x1, #8]
    6a04:	17ffffb7 	b	68e0 <e161+0x60>
    6a08:	52800001 	mov	w1, #0x0                   	// #0
    6a0c:	d2800300 	mov	x0, #0x18                  	// #24
    6a10:	97fff878 	bl	4bf0 <fwp_heap_alloc>
    6a14:	aa0003f3 	mov	x19, x0
    6a18:	17ffffc8 	b	6938 <e161+0xb8>
    6a1c:	72003c3f 	tst	w1, #0xffff
    6a20:	54fffc60 	b.eq	69ac <e161+0x12c>  // b.none
    6a24:	aa1303e0 	mov	x0, x19
    6a28:	97fffbaf 	bl	58e4 <fwp_rc_share>
    6a2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a30:	aa1303e0 	mov	x0, x19
    6a34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a38:	a94363f7 	ldp	x23, x24, [sp, #48]
    6a3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6a40:	d65f03c0 	ret
    6a44:	aa1403e0 	mov	x0, x20
    6a48:	97fff512 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6a4c:	17ffffdb 	b	69b8 <e161+0x138>
    6a50:	97ffefec 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6a54:	97fff157 	bl	2fb0 <fwp_heap_oom>
    6a58:	d503201f 	nop
    6a5c:	d503201f 	nop

0000000000006a60 <fwp_drop4>:
    6a60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a64:	910003fd 	mov	x29, sp
    6a68:	a90153f3 	stp	x19, x20, [sp, #16]
    6a6c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    6a70:	f90013f5 	str	x21, [sp, #32]
    6a74:	91150275 	add	x21, x19, #0x540
    6a78:	f949daa1 	ldr	x1, [x21, #5040]
    6a7c:	f949eea2 	ldr	x2, [x21, #5080]
    6a80:	cb010001 	sub	x1, x0, x1
    6a84:	eb02403f 	cmp	x1, x2, lsl #16
    6a88:	54000382 	b.cs	6af8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a8c:	d350fc22 	lsr	x2, x1, #16
    6a90:	f949fea3 	ldr	x3, [x21, #5112]
    6a94:	8b020842 	add	x2, x2, x2, lsl #2
    6a98:	d37df042 	lsl	x2, x2, #3
    6a9c:	8b020064 	add	x4, x3, x2
    6aa0:	f9401094 	ldr	x20, [x4, #32]
    6aa4:	b40002b4 	cbz	x20, 6af8 <fwp_drop4+0x98>
    6aa8:	38626862 	ldrb	w2, [x3, x2]
    6aac:	7100085f 	cmp	w2, #0x2
    6ab0:	540007a0 	b.eq	6ba4 <fwp_drop4+0x144>  // b.none
    6ab4:	7100045f 	cmp	w2, #0x1
    6ab8:	54000201 	b.ne	6af8 <fwp_drop4+0x98>  // b.any
    6abc:	29430885 	ldp	w5, w2, [x4, #24]
    6ac0:	92403c21 	and	x1, x1, #0xffff
    6ac4:	9b057c21 	mul	x1, x1, x5
    6ac8:	d360fc21 	lsr	x1, x1, #32
    6acc:	eb02003f 	cmp	x1, x2
    6ad0:	54000142 	b.cs	6af8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ad4:	8b010294 	add	x20, x20, x1
    6ad8:	39400281 	ldrb	w1, [x20]
    6adc:	340000e1 	cbz	w1, 6af8 <fwp_drop4+0x98>
    6ae0:	7100043f 	cmp	w1, #0x1
    6ae4:	54000120 	b.eq	6b08 <fwp_drop4+0xa8>  // b.none
    6ae8:	7103fc3f 	cmp	w1, #0xff
    6aec:	540007c0 	b.eq	6be4 <fwp_drop4+0x184>  // b.none
    6af0:	51000421 	sub	w1, w1, #0x1
    6af4:	39000281 	strb	w1, [x20]
    6af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6afc:	f94013f5 	ldr	x21, [sp, #32]
    6b00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b04:	d65f03c0 	ret
    6b08:	f9400001 	ldr	x1, [x0]
    6b0c:	b7f80581 	tbnz	x1, #63, 6bbc <fwp_drop4+0x15c>
    6b10:	91150273 	add	x19, x19, #0x540
    6b14:	f949da61 	ldr	x1, [x19, #5040]
    6b18:	f949ee62 	ldr	x2, [x19, #5080]
    6b1c:	cb010001 	sub	x1, x0, x1
    6b20:	eb02403f 	cmp	x1, x2, lsl #16
    6b24:	54fffea2 	b.cs	6af8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b28:	d350fc22 	lsr	x2, x1, #16
    6b2c:	8b020842 	add	x2, x2, x2, lsl #2
    6b30:	d37df042 	lsl	x2, x2, #3
    6b34:	8b020065 	add	x5, x3, x2
    6b38:	f94010a4 	ldr	x4, [x5, #32]
    6b3c:	b4fffde4 	cbz	x4, 6af8 <fwp_drop4+0x98>
    6b40:	38626862 	ldrb	w2, [x3, x2]
    6b44:	7100085f 	cmp	w2, #0x2
    6b48:	54000220 	b.eq	6b8c <fwp_drop4+0x12c>  // b.none
    6b4c:	7100045f 	cmp	w2, #0x1
    6b50:	54fffd41 	b.ne	6af8 <fwp_drop4+0x98>  // b.any
    6b54:	294308a3 	ldp	w3, w2, [x5, #24]
    6b58:	92403c21 	and	x1, x1, #0xffff
    6b5c:	9b037c21 	mul	x1, x1, x3
    6b60:	d360fc21 	lsr	x1, x1, #32
    6b64:	eb02003f 	cmp	x1, x2
    6b68:	54fffc82 	b.cs	6af8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b6c:	8b010084 	add	x4, x4, x1
    6b70:	39400081 	ldrb	w1, [x4]
    6b74:	7100043f 	cmp	w1, #0x1
    6b78:	54fffc01 	b.ne	6af8 <fwp_drop4+0x98>  // b.any
    6b7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b80:	f94013f5 	ldr	x21, [sp, #32]
    6b84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b88:	17fff55e 	b	4100 <fwp_mem_free>
    6b8c:	72003c3f 	tst	w1, #0xffff
    6b90:	54ffff00 	b.eq	6b70 <fwp_drop4+0x110>  // b.none
    6b94:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b98:	f94013f5 	ldr	x21, [sp, #32]
    6b9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ba0:	d65f03c0 	ret
    6ba4:	72003c3f 	tst	w1, #0xffff
    6ba8:	54fff980 	b.eq	6ad8 <fwp_drop4+0x78>  // b.none
    6bac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bb0:	f94013f5 	ldr	x21, [sp, #32]
    6bb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb8:	d65f03c0 	ret
    6bbc:	f9400414 	ldr	x20, [x0, #8]
    6bc0:	97fffb6d 	bl	5974 <fwp_rc_free_arr>
    6bc4:	91150260 	add	x0, x19, #0x540
    6bc8:	f949d801 	ldr	x1, [x0, #5040]
    6bcc:	f949ec00 	ldr	x0, [x0, #5080]
    6bd0:	cb010281 	sub	x1, x20, x1
    6bd4:	eb00403f 	cmp	x1, x0, lsl #16
    6bd8:	54fff902 	b.cs	6af8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bdc:	aa1403e0 	mov	x0, x20
    6be0:	17ffffab 	b	6a8c <fwp_drop4+0x2c>
    6be4:	ca544680 	eor	x0, x20, x20, lsr #17
    6be8:	91150273 	add	x19, x19, #0x540
    6bec:	ca402400 	eor	x0, x0, x0, lsr #9
    6bf0:	92401c00 	and	x0, x0, #0xff
    6bf4:	910a2402 	add	x2, x0, #0x289
    6bf8:	8b000e60 	add	x0, x19, x0, lsl #3
    6bfc:	8b020e62 	add	x2, x19, x2, lsl #3
    6c00:	f94a2400 	ldr	x0, [x0, #5192]
    6c04:	b50000a0 	cbnz	x0, 6c18 <fwp_drop4+0x1b8>
    6c08:	14000013 	b	6c54 <fwp_drop4+0x1f4>
    6c0c:	91004002 	add	x2, x0, #0x10
    6c10:	f9400800 	ldr	x0, [x0, #16]
    6c14:	b4000200 	cbz	x0, 6c54 <fwp_drop4+0x1f4>
    6c18:	f9400001 	ldr	x1, [x0]
    6c1c:	eb14003f 	cmp	x1, x20
    6c20:	54ffff61 	b.ne	6c0c <fwp_drop4+0x1ac>  // b.any
    6c24:	f9400041 	ldr	x1, [x2]
    6c28:	f9400420 	ldr	x0, [x1, #8]
    6c2c:	d1000400 	sub	x0, x0, #0x1
    6c30:	f9000420 	str	x0, [x1, #8]
    6c34:	f103f81f 	cmp	x0, #0xfe
    6c38:	54fff601 	b.ne	6af8 <fwp_drop4+0x98>  // b.any
    6c3c:	39400280 	ldrb	w0, [x20]
    6c40:	7103fc1f 	cmp	w0, #0xff
    6c44:	540000e0 	b.eq	6c60 <fwp_drop4+0x200>  // b.none
    6c48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c4c:	39000280 	strb	w0, [x20]
    6c50:	17ffffaa 	b	6af8 <fwp_drop4+0x98>
    6c54:	90000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    6c58:	913f0000 	add	x0, x0, #0xfc0
    6c5c:	97fff46d 	bl	3e10 <fwp_trap>
    6c60:	aa1403e0 	mov	x0, x20
    6c64:	97fff48b 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6c68:	17fffff8 	b	6c48 <fwp_drop4+0x1e8>
    6c6c:	d503201f 	nop

0000000000006c70 <fwp_caps161>:
    6c70:	34000041 	cbz	w1, 6c78 <fwp_caps161+0x8>
    6c74:	d65f03c0 	ret
    6c78:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    6c7c:	91150063 	add	x3, x3, #0x540
    6c80:	f949d861 	ldr	x1, [x3, #5040]
    6c84:	f949ec62 	ldr	x2, [x3, #5080]
    6c88:	cb010001 	sub	x1, x0, x1
    6c8c:	eb02403f 	cmp	x1, x2, lsl #16
    6c90:	54ffff22 	b.cs	6c74 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c94:	d350fc22 	lsr	x2, x1, #16
    6c98:	f949fc65 	ldr	x5, [x3, #5112]
    6c9c:	8b020842 	add	x2, x2, x2, lsl #2
    6ca0:	d37df042 	lsl	x2, x2, #3
    6ca4:	8b0200a4 	add	x4, x5, x2
    6ca8:	f9401083 	ldr	x3, [x4, #32]
    6cac:	b4fffe43 	cbz	x3, 6c74 <fwp_caps161+0x4>
    6cb0:	386268a2 	ldrb	w2, [x5, x2]
    6cb4:	7100085f 	cmp	w2, #0x2
    6cb8:	540001c0 	b.eq	6cf0 <fwp_caps161+0x80>  // b.none
    6cbc:	7100045f 	cmp	w2, #0x1
    6cc0:	54fffda1 	b.ne	6c74 <fwp_caps161+0x4>  // b.any
    6cc4:	29430885 	ldp	w5, w2, [x4, #24]
    6cc8:	92403c21 	and	x1, x1, #0xffff
    6ccc:	9b057c21 	mul	x1, x1, x5
    6cd0:	d360fc21 	lsr	x1, x1, #32
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54fffce2 	b.cs	6c74 <fwp_caps161+0x4>  // b.hs, b.nlast
    6cdc:	8b010063 	add	x3, x3, x1
    6ce0:	39400061 	ldrb	w1, [x3]
    6ce4:	7100043f 	cmp	w1, #0x1
    6ce8:	54fffc61 	b.ne	6c74 <fwp_caps161+0x4>  // b.any
    6cec:	17fff505 	b	4100 <fwp_mem_free>
    6cf0:	72003c3f 	tst	w1, #0xffff
    6cf4:	54ffff60 	b.eq	6ce0 <fwp_caps161+0x70>  // b.none
    6cf8:	d65f03c0 	ret
    6cfc:	d503201f 	nop

0000000000006d00 <f12>:
    6d00:	d10483ff 	sub	sp, sp, #0x120
    6d04:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6d08:	f947f442 	ldr	x2, [x2, #4072]
    6d0c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6d10:	9102c3fd 	add	x29, sp, #0xb0
    6d14:	a90e63f7 	stp	x23, x24, [sp, #224]
    6d18:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xca0>
    6d1c:	911502e3 	add	x3, x23, #0x540
    6d20:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6d24:	d00000d6 	adrp	x22, 20000 <__data_start>
    6d28:	9100c2c4 	add	x4, x22, #0x30
    6d2c:	f949d861 	ldr	x1, [x3, #5040]
    6d30:	a90c53f3 	stp	x19, x20, [sp, #192]
    6d34:	d00000d3 	adrp	x19, 20000 <__data_start>
    6d38:	f949ec65 	ldr	x5, [x3, #5080]
    6d3c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6d40:	91004273 	add	x19, x19, #0x10
    6d44:	a91073fb 	stp	x27, x28, [sp, #256]
    6d48:	910103f9 	add	x25, sp, #0x40
    6d4c:	9100e3f8 	add	x24, sp, #0x38
    6d50:	f9416086 	ldr	x6, [x4, #704]
    6d54:	fd008be8 	str	d8, [sp, #272]
    6d58:	f9400047 	ldr	x7, [x2]
    6d5c:	f90057e7 	str	x7, [sp, #168]
    6d60:	d2800007 	mov	x7, #0x0                   	// #0
    6d64:	90000015 	adrp	x21, 6000 <fwp_owned_tape_release+0xfc>
    6d68:	12800007 	mov	w7, #0xffffffff            	// #-1
    6d6c:	9104c2a2 	add	x2, x21, #0x130
    6d70:	cb010261 	sub	x1, x19, x1
    6d74:	b9003be7 	str	w7, [sp, #56]
    6d78:	a9040be6 	stp	x6, x2, [sp, #64]
    6d7c:	aa0003f4 	mov	x20, x0
    6d80:	f9002bf8 	str	x24, [sp, #80]
    6d84:	f9016099 	str	x25, [x4, #704]
    6d88:	eb05403f 	cmp	x1, x5, lsl #16
    6d8c:	54000342 	b.cs	6df4 <f12+0xf4>  // b.hs, b.nlast
    6d90:	d350fc20 	lsr	x0, x1, #16
    6d94:	f949fc64 	ldr	x4, [x3, #5112]
    6d98:	8b000800 	add	x0, x0, x0, lsl #2
    6d9c:	d37df002 	lsl	x2, x0, #3
    6da0:	8b020083 	add	x3, x4, x2
    6da4:	f9401060 	ldr	x0, [x3, #32]
    6da8:	b4000260 	cbz	x0, 6df4 <f12+0xf4>
    6dac:	38626882 	ldrb	w2, [x4, x2]
    6db0:	7100085f 	cmp	w2, #0x2
    6db4:	54000b60 	b.eq	6f20 <f12+0x220>  // b.none
    6db8:	7100045f 	cmp	w2, #0x1
    6dbc:	540001c1 	b.ne	6df4 <f12+0xf4>  // b.any
    6dc0:	29430864 	ldp	w4, w2, [x3, #24]
    6dc4:	92403c21 	and	x1, x1, #0xffff
    6dc8:	9b047c21 	mul	x1, x1, x4
    6dcc:	d360fc21 	lsr	x1, x1, #32
    6dd0:	eb02003f 	cmp	x1, x2
    6dd4:	54000102 	b.cs	6df4 <f12+0xf4>  // b.hs, b.nlast
    6dd8:	8b010000 	add	x0, x0, x1
    6ddc:	39400001 	ldrb	w1, [x0]
    6de0:	340000a1 	cbz	w1, 6df4 <f12+0xf4>
    6de4:	7103f43f 	cmp	w1, #0xfd
    6de8:	540026a8 	b.hi	72bc <f12+0x5bc>  // b.pmore
    6dec:	11000421 	add	w1, w1, #0x1
    6df0:	39000001 	strb	w1, [x0]
    6df4:	aa1303e0 	mov	x0, x19
    6df8:	97fffbe6 	bl	5d90 <fwp_closure_drop>
    6dfc:	b40001b4 	cbz	x20, 6e30 <f12+0x130>
    6e00:	aa1403e1 	mov	x1, x20
    6e04:	d2800002 	mov	x2, #0x0                   	// #0
    6e08:	f9400821 	ldr	x1, [x1, #16]
    6e0c:	91000442 	add	x2, x2, #0x1
    6e10:	b5ffffc1 	cbnz	x1, 6e08 <f12+0x108>
    6e14:	aa0203f3 	mov	x19, x2
    6e18:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6e1c:	eb00005f 	cmp	x2, x0
    6e20:	540000a9 	b.ls	6e34 <f12+0x134>  // b.plast
    6e24:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    6e28:	9109a000 	add	x0, x0, #0x268
    6e2c:	97fff3f9 	bl	3e10 <fwp_trap>
    6e30:	d2800013 	mov	x19, #0x0                   	// #0
    6e34:	9100c2da 	add	x26, x22, #0x30
    6e38:	b942f740 	ldr	w0, [x26, #756]
    6e3c:	340012a0 	cbz	w0, 7090 <f12+0x390>
    6e40:	9100c2c0 	add	x0, x22, #0x30
    6e44:	f940401b 	ldr	x27, [x0, #128]
    6e48:	f9404c1a 	ldr	x26, [x0, #152]
    6e4c:	eb1b035f 	cmp	x26, x27
    6e50:	540006ea 	b.ge	6f2c <f12+0x22c>  // b.tcont
    6e54:	f9401ac0 	ldr	x0, [x22, #48]
    6e58:	8b1a0741 	add	x1, x26, x26, lsl #1
    6e5c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6e60:	8b010b41 	add	x1, x26, x1, lsl #2
    6e64:	8b010c01 	add	x1, x0, x1, lsl #3
    6e68:	b9400420 	ldr	w0, [x1, #4]
    6e6c:	35000080 	cbnz	w0, 6e7c <f12+0x17c>
    6e70:	b9400020 	ldr	w0, [x1]
    6e74:	6b02001f 	cmp	w0, w2
    6e78:	540005a9 	b.ls	6f2c <f12+0x22c>  // b.plast
    6e7c:	9100075a 	add	x26, x26, #0x1
    6e80:	9101a021 	add	x1, x1, #0x68
    6e84:	eb1b035f 	cmp	x26, x27
    6e88:	54ffff01 	b.ne	6e68 <f12+0x168>  // b.any
    6e8c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6e90:	eb00037f 	cmp	x27, x0
    6e94:	54001e6c 	b.gt	7260 <f12+0x560>
    6e98:	9100c2c0 	add	x0, x22, #0x30
    6e9c:	f9401adc 	ldr	x28, [x22, #48]
    6ea0:	f9404800 	ldr	x0, [x0, #144]
    6ea4:	eb1b001f 	cmp	x0, x27
    6ea8:	54000241 	b.ne	6ef0 <f12+0x1f0>  // b.any
    6eac:	b400273b 	cbz	x27, 7390 <f12+0x690>
    6eb0:	d37ffb62 	lsl	x2, x27, #1
    6eb4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6eb8:	eb00005f 	cmp	x2, x0
    6ebc:	9a80d042 	csel	x2, x2, x0, le
    6ec0:	8b020441 	add	x1, x2, x2, lsl #1
    6ec4:	8b010841 	add	x1, x2, x1, lsl #2
    6ec8:	d37df021 	lsl	x1, x1, #3
    6ecc:	aa1c03e0 	mov	x0, x28
    6ed0:	f90007e2 	str	x2, [sp, #8]
    6ed4:	97ffee43 	bl	27e0 <realloc@plt>
    6ed8:	aa0003fc 	mov	x28, x0
    6edc:	f94007e2 	ldr	x2, [sp, #8]
    6ee0:	b4004740 	cbz	x0, 77c8 <f12+0xac8>
    6ee4:	9100c2c0 	add	x0, x22, #0x30
    6ee8:	f9001adc 	str	x28, [x22, #48]
    6eec:	f9004802 	str	x2, [x0, #144]
    6ef0:	8b1b0760 	add	x0, x27, x27, lsl #1
    6ef4:	9100c2c1 	add	x1, x22, #0x30
    6ef8:	4f000400 	movi	v0.4s, #0x0
    6efc:	91000762 	add	x2, x27, #0x1
    6f00:	8b000b60 	add	x0, x27, x0, lsl #2
    6f04:	f9004022 	str	x2, [x1, #128]
    6f08:	8b000f80 	add	x0, x28, x0, lsl #3
    6f0c:	ad000000 	stp	q0, q0, [x0]
    6f10:	ad010000 	stp	q0, q0, [x0, #32]
    6f14:	ad020000 	stp	q0, q0, [x0, #64]
    6f18:	f900301f 	str	xzr, [x0, #96]
    6f1c:	14000007 	b	6f38 <f12+0x238>
    6f20:	72003c3f 	tst	w1, #0xffff
    6f24:	54fff681 	b.ne	6df4 <f12+0xf4>  // b.any
    6f28:	17ffffad 	b	6ddc <f12+0xdc>
    6f2c:	eb1b035f 	cmp	x26, x27
    6f30:	54fffae0 	b.eq	6e8c <f12+0x18c>  // b.none
    6f34:	f9401adc 	ldr	x28, [x22, #48]
    6f38:	8b1a075b 	add	x27, x26, x26, lsl #1
    6f3c:	90000020 	adrp	x0, a000 <fwp_main_thread+0x660>
    6f40:	913e6000 	add	x0, x0, #0xf98
    6f44:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    6f48:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6f4c:	f900337f 	str	xzr, [x27, #96]
    6f50:	97ffee8c 	bl	2980 <getenv@plt>
    6f54:	b4000080 	cbz	x0, 6f64 <f12+0x264>
    6f58:	39400001 	ldrb	w1, [x0]
    6f5c:	7100c03f 	cmp	w1, #0x30
    6f60:	54000740 	b.eq	7048 <f12+0x348>  // b.none
    6f64:	9100c2c0 	add	x0, x22, #0x30
    6f68:	f9403801 	ldr	x1, [x0, #112]
    6f6c:	b5000741 	cbnz	x1, 7054 <f12+0x354>
    6f70:	9100c2c2 	add	x2, x22, #0x30
    6f74:	2f000400 	mvni	v0.2s, #0x0
    6f78:	b9400363 	ldr	w3, [x27]
    6f7c:	52800020 	mov	w0, #0x1                   	// #1
    6f80:	91000744 	add	x4, x26, #0x1
    6f84:	a900cf73 	stp	x19, x19, [x27, #8]
    6f88:	0b000063 	add	w3, w3, w0
    6f8c:	f9416041 	ldr	x1, [x2, #704]
    6f90:	29000363 	stp	w3, w0, [x27]
    6f94:	f9002b7f 	str	xzr, [x27, #80]
    6f98:	f9004c44 	str	x4, [x2, #152]
    6f9c:	fd002f60 	str	d0, [x27, #88]
    6fa0:	b4001541 	cbz	x1, 7248 <f12+0x548>
    6fa4:	9104c2b5 	add	x21, x21, #0x130
    6fa8:	14000003 	b	6fb4 <f12+0x2b4>
    6fac:	f9400021 	ldr	x1, [x1]
    6fb0:	b40014c1 	cbz	x1, 7248 <f12+0x548>
    6fb4:	f9400422 	ldr	x2, [x1, #8]
    6fb8:	eb15005f 	cmp	x2, x21
    6fbc:	54ffff81 	b.ne	6fac <f12+0x2ac>  // b.any
    6fc0:	f9400820 	ldr	x0, [x1, #16]
    6fc4:	2a1a03e2 	mov	w2, w26
    6fc8:	b9400001 	ldr	w1, [x0]
    6fcc:	f9002b60 	str	x0, [x27, #80]
    6fd0:	b9005f61 	str	w1, [x27, #92]
    6fd4:	37f80081 	tbnz	w1, #31, 6fe4 <f12+0x2e4>
    6fd8:	52800d05 	mov	w5, #0x68                  	// #104
    6fdc:	9b257021 	smaddl	x1, w1, w5, x28
    6fe0:	b900583a 	str	w26, [x1, #88]
    6fe4:	b9000002 	str	w2, [x0]
    6fe8:	aa1403e0 	mov	x0, x20
    6fec:	d2800002 	mov	x2, #0x0                   	// #0
    6ff0:	b40005f4 	cbz	x20, 70ac <f12+0x3ac>
    6ff4:	d503201f 	nop
    6ff8:	f9400800 	ldr	x0, [x0, #16]
    6ffc:	91000442 	add	x2, x2, #0x1
    7000:	b5ffffc0 	cbnz	x0, 6ff8 <f12+0x2f8>
    7004:	aa1403e1 	mov	x1, x20
    7008:	f9400821 	ldr	x1, [x1, #16]
    700c:	91000400 	add	x0, x0, #0x1
    7010:	b5ffffc1 	cbnz	x1, 7008 <f12+0x308>
    7014:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7018:	eb01001f 	cmp	x0, x1
    701c:	54000108 	b.hi	703c <f12+0x33c>  // b.pmore
    7020:	f100005f 	cmp	x2, #0x0
    7024:	5400044d 	b.le	70ac <f12+0x3ac>
    7028:	eb00005f 	cmp	x2, x0
    702c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7030:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7034:	eb01027f 	cmp	x19, x1
    7038:	540011a9 	b.ls	726c <f12+0x56c>  // b.plast
    703c:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7040:	910ba000 	add	x0, x0, #0x2e8
    7044:	97fff373 	bl	3e10 <fwp_trap>
    7048:	39400400 	ldrb	w0, [x0, #1]
    704c:	34fff920 	cbz	w0, 6f70 <f12+0x270>
    7050:	17ffffc5 	b	6f64 <f12+0x264>
    7054:	3cc38002 	ldur	q2, [x0, #56]
    7058:	9100e001 	add	x1, x0, #0x38
    705c:	3cc48001 	ldur	q1, [x0, #72]
    7060:	f900381f 	str	xzr, [x0, #112]
    7064:	4f000400 	movi	v0.4s, #0x0
    7068:	ad010762 	stp	q2, q1, [x27, #32]
    706c:	a9458002 	ldp	x2, x0, [x0, #88]
    7070:	f9000f60 	str	x0, [x27, #24]
    7074:	f9401820 	ldr	x0, [x1, #48]
    7078:	f9002362 	str	x2, [x27, #64]
    707c:	f9002760 	str	x0, [x27, #72]
    7080:	ad000020 	stp	q0, q0, [x1]
    7084:	3d800820 	str	q0, [x1, #32]
    7088:	f900183f 	str	xzr, [x1, #48]
    708c:	17ffffb9 	b	6f70 <f12+0x270>
    7090:	f0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xfc>
    7094:	9100c000 	add	x0, x0, #0x30
    7098:	94000f6e 	bl	ae50 <atexit>
    709c:	35003960 	cbnz	w0, 77c8 <f12+0xac8>
    70a0:	52800020 	mov	w0, #0x1                   	// #1
    70a4:	b902f740 	str	w0, [x26, #756]
    70a8:	17ffff66 	b	6e40 <f12+0x140>
    70ac:	d3707c63 	ubfiz	x3, x3, #16, #32
    70b0:	52800041 	mov	w1, #0x2                   	// #2
    70b4:	aa040075 	orr	x21, x3, x4
    70b8:	d2800100 	mov	x0, #0x8                   	// #8
    70bc:	97fff6cd 	bl	4bf0 <fwp_heap_alloc>
    70c0:	aa0003fa 	mov	x26, x0
    70c4:	911502e0 	add	x0, x23, #0x540
    70c8:	f900035f 	str	xzr, [x26]
    70cc:	f949d801 	ldr	x1, [x0, #5040]
    70d0:	f949ec00 	ldr	x0, [x0, #5080]
    70d4:	cb010341 	sub	x1, x26, x1
    70d8:	eb00403f 	cmp	x1, x0, lsl #16
    70dc:	54000ea2 	b.cs	72b0 <f12+0x5b0>  // b.hs, b.nlast
    70e0:	d2800013 	mov	x19, #0x0                   	// #0
    70e4:	911502e2 	add	x2, x23, #0x540
    70e8:	d350fc20 	lsr	x0, x1, #16
    70ec:	8b000800 	add	x0, x0, x0, lsl #2
    70f0:	f949fc43 	ldr	x3, [x2, #5112]
    70f4:	d37df002 	lsl	x2, x0, #3
    70f8:	8b020060 	add	x0, x3, x2
    70fc:	f940101b 	ldr	x27, [x0, #32]
    7100:	b400025b 	cbz	x27, 7148 <f12+0x448>
    7104:	38626862 	ldrb	w2, [x3, x2]
    7108:	7100085f 	cmp	w2, #0x2
    710c:	54000a40 	b.eq	7254 <f12+0x554>  // b.none
    7110:	7100045f 	cmp	w2, #0x1
    7114:	540001a1 	b.ne	7148 <f12+0x448>  // b.any
    7118:	29430002 	ldp	w2, w0, [x0, #24]
    711c:	92403c21 	and	x1, x1, #0xffff
    7120:	9b027c21 	mul	x1, x1, x2
    7124:	d360fc21 	lsr	x1, x1, #32
    7128:	eb00003f 	cmp	x1, x0
    712c:	540000e2 	b.cs	7148 <f12+0x448>  // b.hs, b.nlast
    7130:	8b01037b 	add	x27, x27, x1
    7134:	39400360 	ldrb	w0, [x27]
    7138:	7103fc1f 	cmp	w0, #0xff
    713c:	540032a0 	b.eq	7790 <f12+0xa90>  // b.none
    7140:	52800020 	mov	w0, #0x1                   	// #1
    7144:	39000360 	strb	w0, [x27]
    7148:	b4000233 	cbz	x19, 718c <f12+0x48c>
    714c:	d3607ea4 	lsl	x4, x21, #32
    7150:	aa1403e0 	mov	x0, x20
    7154:	f9400685 	ldr	x5, [x20, #8]
    7158:	aa0403e3 	mov	x3, x4
    715c:	91002342 	add	x2, x26, #0x8
    7160:	d2800001 	mov	x1, #0x0                   	// #0
    7164:	14000005 	b	7178 <f12+0x478>
    7168:	f9400405 	ldr	x5, [x0, #8]
    716c:	ab040023 	adds	x3, x1, x4
    7170:	91004042 	add	x2, x2, #0x10
    7174:	54006726 	b.vs	7e58 <f12+0x1158>
    7178:	a9000c45 	stp	x5, x3, [x2]
    717c:	91000421 	add	x1, x1, #0x1
    7180:	f9400800 	ldr	x0, [x0, #16]
    7184:	eb01027f 	cmp	x19, x1
    7188:	54ffff08 	b.hi	7168 <f12+0x468>  // b.pmore
    718c:	f9400340 	ldr	x0, [x26]
    7190:	f100041f 	cmp	x0, #0x1
    7194:	540008e9 	b.ls	72b0 <f12+0x5b0>  // b.plast
    7198:	d341fc00 	lsr	x0, x0, #1
    719c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    71a0:	d100041c 	sub	x28, x0, #0x1
    71a4:	eb01039f 	cmp	x28, x1
    71a8:	54fff4a8 	b.hi	703c <f12+0x33c>  // b.pmore
    71ac:	b400083c 	cbz	x28, 72b0 <f12+0x5b0>
    71b0:	d1002341 	sub	x1, x26, #0x8
    71b4:	91002353 	add	x19, x26, #0x8
    71b8:	8b00103b 	add	x27, x1, x0, lsl #4
    71bc:	d503201f 	nop
    71c0:	f9400660 	ldr	x0, [x19, #8]
    71c4:	f9400e61 	ldr	x1, [x19, #24]
    71c8:	fd400260 	ldr	d0, [x19]
    71cc:	fd400a61 	ldr	d1, [x19, #16]
    71d0:	97fff844 	bl	52e0 <w107>
    71d4:	a9000660 	stp	x0, x1, [x19]
    71d8:	91004273 	add	x19, x19, #0x10
    71dc:	eb1b027f 	cmp	x19, x27
    71e0:	54ffff01 	b.ne	71c0 <f12+0x4c0>  // b.any
    71e4:	aa1a03fb 	mov	x27, x26
    71e8:	d37ffb93 	lsl	x19, x28, #1
    71ec:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    71f0:	d280001c 	mov	x28, #0x0                   	// #0
    71f4:	f8010773 	str	x19, [x27], #16
    71f8:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    71fc:	aa0303e0 	mov	x0, x3
    7200:	91000b9c 	add	x28, x28, #0x2
    7204:	97fff7df 	bl	5180 <f128.constprop.0>
    7208:	aa0003e3 	mov	x3, x0
    720c:	eb13039f 	cmp	x28, x19
    7210:	54ffff43 	b.cc	71f8 <f12+0x4f8>  // b.lo, b.ul, b.last
    7214:	aa1a03e0 	mov	x0, x26
    7218:	93407eb5 	sxtw	x21, w21
    721c:	f90007e3 	str	x3, [sp, #8]
    7220:	97fffe10 	bl	6a60 <fwp_drop4>
    7224:	aa1503e0 	mov	x0, x21
    7228:	97fff4fe 	bl	4620 <fwp_tape_of>
    722c:	f940301b 	ldr	x27, [x0, #96]
    7230:	aa0003e5 	mov	x5, x0
    7234:	f94007e3 	ldr	x3, [sp, #8]
    7238:	b400047b 	cbz	x27, 72c4 <f12+0x5c4>
    723c:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7240:	91076000 	add	x0, x0, #0x1d8
    7244:	97fff2f3 	bl	3e10 <fwp_trap>
    7248:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    724c:	910ae000 	add	x0, x0, #0x2b8
    7250:	97fff2f0 	bl	3e10 <fwp_trap>
    7254:	72003c3f 	tst	w1, #0xffff
    7258:	54fff781 	b.ne	7148 <f12+0x448>  // b.any
    725c:	17ffffb6 	b	7134 <f12+0x434>
    7260:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7264:	910a2000 	add	x0, x0, #0x288
    7268:	97fff2ea 	bl	3e10 <fwp_trap>
    726c:	d37ffa7b 	lsl	x27, x19, #1
    7270:	d3707c63 	ubfiz	x3, x3, #16, #32
    7274:	91000760 	add	x0, x27, #0x1
    7278:	52800041 	mov	w1, #0x2                   	// #2
    727c:	aa040075 	orr	x21, x3, x4
    7280:	d37df000 	lsl	x0, x0, #3
    7284:	97fff65b 	bl	4bf0 <fwp_heap_alloc>
    7288:	aa0003fa 	mov	x26, x0
    728c:	911502e1 	add	x1, x23, #0x540
    7290:	aa0103e0 	mov	x0, x1
    7294:	f900035b 	str	x27, [x26]
    7298:	f949d821 	ldr	x1, [x1, #5040]
    729c:	f949ec00 	ldr	x0, [x0, #5080]
    72a0:	cb010341 	sub	x1, x26, x1
    72a4:	eb00403f 	cmp	x1, x0, lsl #16
    72a8:	54fff1e3 	b.cc	70e4 <f12+0x3e4>  // b.lo, b.ul, b.last
    72ac:	b5fff513 	cbnz	x19, 714c <f12+0x44c>
    72b0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    72b4:	f900035f 	str	xzr, [x26]
    72b8:	17ffffd7 	b	7214 <f12+0x514>
    72bc:	97fff40a 	bl	42e4 <fwp_rc_wide_dup>
    72c0:	17fffecd 	b	6df4 <f12+0xf4>
    72c4:	f9000fe3 	str	x3, [sp, #24]
    72c8:	97ffef12 	bl	2f10 <fwp_tape_unlink_scope>
    72cc:	a94288bc 	ldp	x28, x2, [x5, #40]
    72d0:	f90007e2 	str	x2, [sp, #8]
    72d4:	f9401ca2 	ldr	x2, [x5, #56]
    72d8:	b90004bf 	str	wzr, [x5, #4]
    72dc:	b94000a1 	ldr	w1, [x5]
    72e0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    72e4:	f9000be2 	str	x2, [sp, #16]
    72e8:	a940acba 	ldp	x26, x11, [x5, #8]
    72ec:	6b00003f 	cmp	w1, w0
    72f0:	a941eca9 	ldp	x9, x27, [x5, #24]
    72f4:	f9400fe3 	ldr	x3, [sp, #24]
    72f8:	f94020a4 	ldr	x4, [x5, #64]
    72fc:	f94024a2 	ldr	x2, [x5, #72]
    7300:	54000108 	b.hi	7320 <f12+0x620>  // b.pmore
    7304:	9100c2c1 	add	x1, x22, #0x30
    7308:	92403ea0 	and	x0, x21, #0xffff
    730c:	d1000400 	sub	x0, x0, #0x1
    7310:	f9404c2a 	ldr	x10, [x1, #152]
    7314:	eb0a001f 	cmp	x0, x10
    7318:	5400004a 	b.ge	7320 <f12+0x620>  // b.tcont
    731c:	f9004c20 	str	x0, [x1, #152]
    7320:	4f000400 	movi	v0.4s, #0x0
    7324:	9100c2c1 	add	x1, x22, #0x30
    7328:	90ffffe0 	adrp	x0, 3000 <fwp_segv+0x10>
    732c:	9133c000 	add	x0, x0, #0xcf0
    7330:	f9000cbf 	str	xzr, [x5, #24]
    7334:	910163e6 	add	x6, sp, #0x58
    7338:	f941602a 	ldr	x10, [x1, #704]
    733c:	3c8080a0 	stur	q0, [x5, #8]
    7340:	9101c3f3 	add	x19, sp, #0x70
    7344:	a90583ea 	stp	x10, x0, [sp, #88]
    7348:	f94007e0 	ldr	x0, [sp, #8]
    734c:	ad0100a0 	stp	q0, q0, [x5, #32]
    7350:	f90043e0 	str	x0, [sp, #128]
    7354:	f9400be0 	ldr	x0, [sp, #16]
    7358:	f9000fe6 	str	x6, [sp, #24]
    735c:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    7360:	a906eff3 	stp	x19, x27, [sp, #104]
    7364:	f9003ffc 	str	x28, [sp, #120]
    7368:	f90047e0 	str	x0, [sp, #136]
    736c:	a90927e4 	stp	x4, x9, [sp, #144]
    7370:	f90053e2 	str	x2, [sp, #160]
    7374:	f9016026 	str	x6, [x1, #704]
    7378:	b7f82083 	tbnz	x3, #63, 7788 <f12+0xa88>
    737c:	eb8382bf 	cmp	x21, x3, asr #32
    7380:	540000e0 	b.eq	739c <f12+0x69c>  // b.none
    7384:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7388:	91064000 	add	x0, x0, #0x190
    738c:	97fff2a1 	bl	3e10 <fwp_trap>
    7390:	d2800d01 	mov	x1, #0x68                  	// #104
    7394:	d2800022 	mov	x2, #0x1                   	// #1
    7398:	17fffecd 	b	6ecc <f12+0x1cc>
    739c:	92407c60 	and	x0, x3, #0xffffffff
    73a0:	eb00035f 	cmp	x26, x0
    73a4:	9a80c755 	csinc	x21, x26, x0, gt
    73a8:	eb23417f 	cmp	x11, w3, uxtw
    73ac:	54001f8d 	b.le	779c <f12+0xa9c>
    73b0:	eb15005f 	cmp	x2, x21
    73b4:	54001faa 	b.ge	77a8 <f12+0xaa8>  // b.tcont
    73b8:	f100005f 	cmp	x2, #0x0
    73bc:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    73c0:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    73c4:	14000004 	b	73d4 <f12+0x6d4>
    73c8:	eb01005f 	cmp	x2, x1
    73cc:	d37ff842 	lsl	x2, x2, #1
    73d0:	9a95d042 	csel	x2, x2, x21, le
    73d4:	eb15005f 	cmp	x2, x21
    73d8:	54ffff8b 	b.lt	73c8 <f12+0x6c8>  // b.tstop
    73dc:	f90017e3 	str	x3, [sp, #40]
    73e0:	b40027a4 	cbz	x4, 78d4 <f12+0xbd4>
    73e4:	aa0403e0 	mov	x0, x4
    73e8:	d37df041 	lsl	x1, x2, #3
    73ec:	f90013e2 	str	x2, [sp, #32]
    73f0:	97ffecfc 	bl	27e0 <realloc@plt>
    73f4:	a9420fe2 	ldp	x2, x3, [sp, #32]
    73f8:	aa0003e4 	mov	x4, x0
    73fc:	b4001d64 	cbz	x4, 77a8 <f12+0xaa8>
    7400:	f9004be4 	str	x4, [sp, #144]
    7404:	f90053e2 	str	x2, [sp, #160]
    7408:	b5001b15 	cbnz	x21, 7768 <f12+0xa68>
    740c:	b7f800c3 	tbnz	x3, #63, 7424 <f12+0x724>
    7410:	92407c63 	and	x3, x3, #0xffffffff
    7414:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7418:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    741c:	1e612800 	fadd	d0, d0, d1
    7420:	fc237880 	str	d0, [x4, x3, lsl #3]
    7424:	d10006a0 	sub	x0, x21, #0x1
    7428:	d1000743 	sub	x3, x26, #0x1
    742c:	eb00035f 	cmp	x26, x0
    7430:	540003ec 	b.gt	74ac <f12+0x7ac>
    7434:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    7438:	1e602008 	fcmp	d0, #0.0
    743c:	54000320 	b.eq	74a0 <f12+0x7a0>  // b.none
    7440:	cb1a0be1 	neg	x1, x26, lsl #2
    7444:	cb1a03e5 	neg	x5, x26
    7448:	8b010362 	add	x2, x27, x1
    744c:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    7450:	37f80122 	tbnz	w2, #31, 7474 <f12+0x774>
    7454:	f94007e6 	ldr	x6, [sp, #8]
    7458:	93407c42 	sxtw	x2, w2
    745c:	8b050cc9 	add	x9, x6, x5, lsl #3
    7460:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    7464:	fc607922 	ldr	d2, [x9, x0, lsl #3]
    7468:	1e620802 	fmul	d2, d0, d2
    746c:	1e622821 	fadd	d1, d1, d2
    7470:	fc227881 	str	d1, [x4, x2, lsl #3]
    7474:	8b010381 	add	x1, x28, x1
    7478:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    747c:	37f80121 	tbnz	w1, #31, 74a0 <f12+0x7a0>
    7480:	f9400be2 	ldr	x2, [sp, #16]
    7484:	93407c21 	sxtw	x1, w1
    7488:	8b050c45 	add	x5, x2, x5, lsl #3
    748c:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    7490:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    7494:	1e620800 	fmul	d0, d0, d2
    7498:	1e602820 	fadd	d0, d1, d0
    749c:	fc217880 	str	d0, [x4, x1, lsl #3]
    74a0:	d1000400 	sub	x0, x0, #0x1
    74a4:	eb00007f 	cmp	x3, x0
    74a8:	54fffc61 	b.ne	7434 <f12+0x734>  // b.any
    74ac:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    74b0:	eb00035f 	cmp	x26, x0
    74b4:	54001a28 	b.hi	77f8 <f12+0xaf8>  // b.pmore
    74b8:	91000740 	add	x0, x26, #0x1
    74bc:	52800041 	mov	w1, #0x2                   	// #2
    74c0:	f90007e4 	str	x4, [sp, #8]
    74c4:	d37df000 	lsl	x0, x0, #3
    74c8:	97fff5ca 	bl	4bf0 <fwp_heap_alloc>
    74cc:	aa0003f5 	mov	x21, x0
    74d0:	f800841a 	str	x26, [x0], #8
    74d4:	f94007e4 	ldr	x4, [sp, #8]
    74d8:	d2800001 	mov	x1, #0x0                   	// #0
    74dc:	b40000da 	cbz	x26, 74f4 <f12+0x7f4>
    74e0:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    74e4:	f8217802 	str	x2, [x0, x1, lsl #3]
    74e8:	91000421 	add	x1, x1, #0x1
    74ec:	eb01035f 	cmp	x26, x1
    74f0:	54ffff81 	b.ne	74e0 <f12+0x7e0>  // b.any
    74f4:	9100c2c1 	add	x1, x22, #0x30
    74f8:	f9400fe2 	ldr	x2, [sp, #24]
    74fc:	f9416020 	ldr	x0, [x1, #704]
    7500:	eb02001f 	cmp	x0, x2
    7504:	54004ac1 	b.ne	7e5c <f12+0x115c>  // b.any
    7508:	f9402ffa 	ldr	x26, [sp, #88]
    750c:	aa1303e0 	mov	x0, x19
    7510:	f901603a 	str	x26, [x1, #704]
    7514:	97fff1f7 	bl	3cf0 <fwp_tape_buffers_release>
    7518:	911502e2 	add	x2, x23, #0x540
    751c:	f949d841 	ldr	x1, [x2, #5040]
    7520:	f949ec40 	ldr	x0, [x2, #5080]
    7524:	cb0102a1 	sub	x1, x21, x1
    7528:	eb00403f 	cmp	x1, x0, lsl #16
    752c:	54000322 	b.cs	7590 <f12+0x890>  // b.hs, b.nlast
    7530:	d350fc20 	lsr	x0, x1, #16
    7534:	f949fc43 	ldr	x3, [x2, #5112]
    7538:	8b000800 	add	x0, x0, x0, lsl #2
    753c:	d37df002 	lsl	x2, x0, #3
    7540:	8b020060 	add	x0, x3, x2
    7544:	f9401013 	ldr	x19, [x0, #32]
    7548:	b4000253 	cbz	x19, 7590 <f12+0x890>
    754c:	38626862 	ldrb	w2, [x3, x2]
    7550:	7100085f 	cmp	w2, #0x2
    7554:	54001ba0 	b.eq	78c8 <f12+0xbc8>  // b.none
    7558:	7100045f 	cmp	w2, #0x1
    755c:	540001a1 	b.ne	7590 <f12+0x890>  // b.any
    7560:	29430002 	ldp	w2, w0, [x0, #24]
    7564:	92403c21 	and	x1, x1, #0xffff
    7568:	9b027c21 	mul	x1, x1, x2
    756c:	d360fc21 	lsr	x1, x1, #32
    7570:	eb00003f 	cmp	x1, x0
    7574:	540000e2 	b.cs	7590 <f12+0x890>  // b.hs, b.nlast
    7578:	8b010273 	add	x19, x19, x1
    757c:	39400260 	ldrb	w0, [x19]
    7580:	7103fc1f 	cmp	w0, #0xff
    7584:	54004600 	b.eq	7e44 <f12+0x1144>  // b.none
    7588:	52800020 	mov	w0, #0x1                   	// #1
    758c:	39000260 	strb	w0, [x19]
    7590:	eb19035f 	cmp	x26, x25
    7594:	54004641 	b.ne	7e5c <f12+0x115c>  // b.any
    7598:	f94023e1 	ldr	x1, [sp, #64]
    759c:	9100c2d6 	add	x22, x22, #0x30
    75a0:	aa1803e0 	mov	x0, x24
    75a4:	f90162c1 	str	x1, [x22, #704]
    75a8:	97fffae2 	bl	6130 <fwp_tape_scope_release>
    75ac:	f94002a0 	ldr	x0, [x21]
    75b0:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    75b4:	b7f81360 	tbnz	x0, #63, 7820 <f12+0xb20>
    75b8:	911502e2 	add	x2, x23, #0x540
    75bc:	f949d840 	ldr	x0, [x2, #5040]
    75c0:	f949ec41 	ldr	x1, [x2, #5080]
    75c4:	cb0002a0 	sub	x0, x21, x0
    75c8:	eb01401f 	cmp	x0, x1, lsl #16
    75cc:	540012a2 	b.cs	7820 <f12+0xb20>  // b.hs, b.nlast
    75d0:	d350fc01 	lsr	x1, x0, #16
    75d4:	f949fc44 	ldr	x4, [x2, #5112]
    75d8:	8b010821 	add	x1, x1, x1, lsl #2
    75dc:	d37df021 	lsl	x1, x1, #3
    75e0:	8b010083 	add	x3, x4, x1
    75e4:	f9401062 	ldr	x2, [x3, #32]
    75e8:	b40011c2 	cbz	x2, 7820 <f12+0xb20>
    75ec:	38616881 	ldrb	w1, [x4, x1]
    75f0:	7100083f 	cmp	w1, #0x2
    75f4:	54001120 	b.eq	7818 <f12+0xb18>  // b.none
    75f8:	7100043f 	cmp	w1, #0x1
    75fc:	54001121 	b.ne	7820 <f12+0xb20>  // b.any
    7600:	29430464 	ldp	w4, w1, [x3, #24]
    7604:	92403c00 	and	x0, x0, #0xffff
    7608:	9b047c00 	mul	x0, x0, x4
    760c:	d360fc00 	lsr	x0, x0, #32
    7610:	eb01001f 	cmp	x0, x1
    7614:	54001062 	b.cs	7820 <f12+0xb20>  // b.hs, b.nlast
    7618:	8b000042 	add	x2, x2, x0
    761c:	39400040 	ldrb	w0, [x2]
    7620:	7100041f 	cmp	w0, #0x1
    7624:	54000fe1 	b.ne	7820 <f12+0xb20>  // b.any
    7628:	aa1503f8 	mov	x24, x21
    762c:	aa1503f6 	mov	x22, x21
    7630:	d2800000 	mov	x0, #0x0                   	// #0
    7634:	910022c2 	add	x2, x22, #0x8
    7638:	d2800001 	mov	x1, #0x0                   	// #0
    763c:	b40001f9 	cbz	x25, 7678 <f12+0x978>
    7640:	90000023 	adrp	x3, b000 <_IO_stdin_used+0x180>
    7644:	910022a4 	add	x4, x21, #0x8
    7648:	fd45ac61 	ldr	d1, [x3, #2904]
    764c:	f94002a5 	ldr	x5, [x21]
    7650:	aa0403e3 	mov	x3, x4
    7654:	b7f80de5 	tbnz	x5, #63, 7810 <f12+0xb10>
    7658:	f9400305 	ldr	x5, [x24]
    765c:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    7660:	b7f80d25 	tbnz	x5, #63, 7804 <f12+0xb04>
    7664:	1e600820 	fmul	d0, d1, d0
    7668:	91000421 	add	x1, x1, #0x1
    766c:	fc008440 	str	d0, [x2], #8
    7670:	eb01033f 	cmp	x25, x1
    7674:	54fffec1 	b.ne	764c <f12+0x94c>  // b.any
    7678:	97fffcfa 	bl	6a60 <fwp_drop4>
    767c:	b4003db4 	cbz	x20, 7e30 <f12+0x1130>
    7680:	aa1403e0 	mov	x0, x20
    7684:	d2800013 	mov	x19, #0x0                   	// #0
    7688:	f9400800 	ldr	x0, [x0, #16]
    768c:	91000673 	add	x19, x19, #0x1
    7690:	b5ffffc0 	cbnz	x0, 7688 <f12+0x988>
    7694:	f9400300 	ldr	x0, [x24]
    7698:	9240f815 	and	x21, x0, #0x7fffffffffffffff
    769c:	b7f81300 	tbnz	x0, #63, 78fc <f12+0xbfc>
    76a0:	911502e1 	add	x1, x23, #0x540
    76a4:	f949d820 	ldr	x0, [x1, #5040]
    76a8:	f949ec22 	ldr	x2, [x1, #5080]
    76ac:	cb0002c0 	sub	x0, x22, x0
    76b0:	eb02401f 	cmp	x0, x2, lsl #16
    76b4:	54001222 	b.cs	78f8 <f12+0xbf8>  // b.hs, b.nlast
    76b8:	d350fc02 	lsr	x2, x0, #16
    76bc:	d2800503 	mov	x3, #0x28                  	// #40
    76c0:	f949fc24 	ldr	x4, [x1, #5112]
    76c4:	9b037c42 	mul	x2, x2, x3
    76c8:	8b020083 	add	x3, x4, x2
    76cc:	f9401061 	ldr	x1, [x3, #32]
    76d0:	b4001141 	cbz	x1, 78f8 <f12+0xbf8>
    76d4:	38626882 	ldrb	w2, [x4, x2]
    76d8:	7100085f 	cmp	w2, #0x2
    76dc:	540010a0 	b.eq	78f0 <f12+0xbf0>  // b.none
    76e0:	7100045f 	cmp	w2, #0x1
    76e4:	540010a1 	b.ne	78f8 <f12+0xbf8>  // b.any
    76e8:	29430864 	ldp	w4, w2, [x3, #24]
    76ec:	92403c00 	and	x0, x0, #0xffff
    76f0:	9b047c00 	mul	x0, x0, x4
    76f4:	d360fc00 	lsr	x0, x0, #32
    76f8:	eb02001f 	cmp	x0, x2
    76fc:	54000fe2 	b.cs	78f8 <f12+0xbf8>  // b.hs, b.nlast
    7700:	8b000021 	add	x1, x1, x0
    7704:	39400039 	ldrb	w25, [x1]
    7708:	7100073f 	cmp	w25, #0x1
    770c:	54000f61 	b.ne	78f8 <f12+0xbf8>  // b.any
    7710:	9100231b 	add	x27, x24, #0x8
    7714:	eb15027f 	cmp	x19, x21
    7718:	9a959273 	csel	x19, x19, x21, ls	// ls = plast
    771c:	b4002553 	cbz	x19, 7bc4 <f12+0xec4>
    7720:	d37df264 	lsl	x4, x19, #3
    7724:	aa1403e1 	mov	x1, x20
    7728:	910022c3 	add	x3, x22, #0x8
    772c:	d2800000 	mov	x0, #0x0                   	// #0
    7730:	14000009 	b	7754 <f12+0xa54>
    7734:	fc606841 	ldr	d1, [x2, x0]
    7738:	fd400420 	ldr	d0, [x1, #8]
    773c:	1e613800 	fsub	d0, d0, d1
    7740:	fc206b60 	str	d0, [x27, x0]
    7744:	91002000 	add	x0, x0, #0x8
    7748:	f9400821 	ldr	x1, [x1, #16]
    774c:	eb04001f 	cmp	x0, x4
    7750:	54001020 	b.eq	7954 <f12+0xc54>  // b.none
    7754:	f9400305 	ldr	x5, [x24]
    7758:	aa0303e2 	mov	x2, x3
    775c:	b6fffec5 	tbz	x5, #63, 7734 <f12+0xa34>
    7760:	f9400ac2 	ldr	x2, [x22, #16]
    7764:	17fffff4 	b	7734 <f12+0xa34>
    7768:	aa0403e0 	mov	x0, x4
    776c:	d37df2a2 	lsl	x2, x21, #3
    7770:	52800001 	mov	w1, #0x0                   	// #0
    7774:	f90013e3 	str	x3, [sp, #32]
    7778:	97ffec12 	bl	27c0 <memset@plt>
    777c:	aa0003e4 	mov	x4, x0
    7780:	f94013e3 	ldr	x3, [sp, #32]
    7784:	17ffff22 	b	740c <f12+0x70c>
    7788:	aa1a03f5 	mov	x21, x26
    778c:	17ffff09 	b	73b0 <f12+0x6b0>
    7790:	aa1b03e0 	mov	x0, x27
    7794:	97fff1bf 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7798:	17fffe6a 	b	7140 <f12+0x440>
    779c:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    77a0:	91082000 	add	x0, x0, #0x208
    77a4:	97fff19b 	bl	3e10 <fwp_trap>
    77a8:	f10002bf 	cmp	x21, #0x0
    77ac:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    77b0:	54ffe2c1 	b.ne	7408 <f12+0x708>  // b.any
    77b4:	f9402fe1 	ldr	x1, [sp, #88]
    77b8:	9100c2d6 	add	x22, x22, #0x30
    77bc:	aa1303e0 	mov	x0, x19
    77c0:	f90162c1 	str	x1, [x22, #704]
    77c4:	97fff14b 	bl	3cf0 <fwp_tape_buffers_release>
    77c8:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    77cc:	f947e863 	ldr	x3, [x3, #4048]
    77d0:	d2800262 	mov	x2, #0x13                  	// #19
    77d4:	d2800021 	mov	x1, #0x1                   	// #1
    77d8:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x660>
    77dc:	913a2000 	add	x0, x0, #0xe88
    77e0:	f9400063 	ldr	x3, [x3]
    77e4:	97ffec43 	bl	28f0 <fwrite@plt>
    77e8:	d2800000 	mov	x0, #0x0                   	// #0
    77ec:	97ffec4d 	bl	2920 <fflush@plt>
    77f0:	52800cc0 	mov	w0, #0x66                  	// #102
    77f4:	97ffec5b 	bl	2960 <_Exit@plt>
    77f8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    77fc:	910be000 	add	x0, x0, #0x2f8
    7800:	97fff184 	bl	3e10 <fwp_trap>
    7804:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7808:	910c2000 	add	x0, x0, #0x308
    780c:	97fff181 	bl	3e10 <fwp_trap>
    7810:	f9400aa3 	ldr	x3, [x21, #16]
    7814:	17ffff91 	b	7658 <f12+0x958>
    7818:	72003c1f 	tst	w0, #0xffff
    781c:	54fff000 	b.eq	761c <f12+0x91c>  // b.none
    7820:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7824:	eb00033f 	cmp	x25, x0
    7828:	54fffe88 	b.hi	77f8 <f12+0xaf8>  // b.pmore
    782c:	91000720 	add	x0, x25, #0x1
    7830:	52800021 	mov	w1, #0x1                   	// #1
    7834:	d37df000 	lsl	x0, x0, #3
    7838:	97fff4ee 	bl	4bf0 <fwp_heap_alloc>
    783c:	911502e2 	add	x2, x23, #0x540
    7840:	f9000019 	str	x25, [x0]
    7844:	aa0003f8 	mov	x24, x0
    7848:	aa0003f6 	mov	x22, x0
    784c:	f949d841 	ldr	x1, [x2, #5040]
    7850:	f949ec40 	ldr	x0, [x2, #5080]
    7854:	cb010301 	sub	x1, x24, x1
    7858:	eb00403f 	cmp	x1, x0, lsl #16
    785c:	54000322 	b.cs	78c0 <f12+0xbc0>  // b.hs, b.nlast
    7860:	d350fc20 	lsr	x0, x1, #16
    7864:	d2800504 	mov	x4, #0x28                  	// #40
    7868:	f949fc43 	ldr	x3, [x2, #5112]
    786c:	9b047c00 	mul	x0, x0, x4
    7870:	8b000062 	add	x2, x3, x0
    7874:	f9401053 	ldr	x19, [x2, #32]
    7878:	b4000253 	cbz	x19, 78c0 <f12+0xbc0>
    787c:	38606860 	ldrb	w0, [x3, x0]
    7880:	7100081f 	cmp	w0, #0x2
    7884:	54002ce0 	b.eq	7e20 <f12+0x1120>  // b.none
    7888:	7100041f 	cmp	w0, #0x1
    788c:	540001a1 	b.ne	78c0 <f12+0xbc0>  // b.any
    7890:	29430043 	ldp	w3, w0, [x2, #24]
    7894:	92403c21 	and	x1, x1, #0xffff
    7898:	9b037c21 	mul	x1, x1, x3
    789c:	d360fc21 	lsr	x1, x1, #32
    78a0:	eb00003f 	cmp	x1, x0
    78a4:	540000e2 	b.cs	78c0 <f12+0xbc0>  // b.hs, b.nlast
    78a8:	8b010273 	add	x19, x19, x1
    78ac:	39400260 	ldrb	w0, [x19]
    78b0:	7103fc1f 	cmp	w0, #0xff
    78b4:	54002b00 	b.eq	7e14 <f12+0x1114>  // b.none
    78b8:	52800020 	mov	w0, #0x1                   	// #1
    78bc:	39000260 	strb	w0, [x19]
    78c0:	aa1503e0 	mov	x0, x21
    78c4:	17ffff5c 	b	7634 <f12+0x934>
    78c8:	72003c3f 	tst	w1, #0xffff
    78cc:	54ffe621 	b.ne	7590 <f12+0x890>  // b.any
    78d0:	17ffff2b 	b	757c <f12+0x87c>
    78d4:	aa0203e0 	mov	x0, x2
    78d8:	d2800101 	mov	x1, #0x8                   	// #8
    78dc:	f90013e2 	str	x2, [sp, #32]
    78e0:	97ffebbc 	bl	27d0 <calloc@plt>
    78e4:	a9420fe2 	ldp	x2, x3, [sp, #32]
    78e8:	aa0003e4 	mov	x4, x0
    78ec:	17fffec4 	b	73fc <f12+0x6fc>
    78f0:	72003c1f 	tst	w0, #0xffff
    78f4:	54fff080 	b.eq	7704 <f12+0xa04>  // b.none
    78f8:	b40015d4 	cbz	x20, 7bb0 <f12+0xeb0>
    78fc:	aa1403f9 	mov	x25, x20
    7900:	d2800013 	mov	x19, #0x0                   	// #0
    7904:	f9400b39 	ldr	x25, [x25, #16]
    7908:	aa1303e0 	mov	x0, x19
    790c:	91000673 	add	x19, x19, #0x1
    7910:	b5ffffb9 	cbnz	x25, 7904 <f12+0xc04>
    7914:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7918:	eb01027f 	cmp	x19, x1
    791c:	54ffb908 	b.hi	703c <f12+0x33c>  // b.pmore
    7920:	91000800 	add	x0, x0, #0x2
    7924:	52800041 	mov	w1, #0x2                   	// #2
    7928:	d37df000 	lsl	x0, x0, #3
    792c:	97fff4b1 	bl	4bf0 <fwp_heap_alloc>
    7930:	aa1403e1 	mov	x1, x20
    7934:	aa0003fb 	mov	x27, x0
    7938:	f9400420 	ldr	x0, [x1, #8]
    793c:	f8397b60 	str	x0, [x27, x25, lsl #3]
    7940:	91000739 	add	x25, x25, #0x1
    7944:	f9400821 	ldr	x1, [x1, #16]
    7948:	b5ffff81 	cbnz	x1, 7938 <f12+0xc38>
    794c:	52800019 	mov	w25, #0x0                   	// #0
    7950:	17ffff71 	b	7714 <f12+0xa14>
    7954:	b40012b4 	cbz	x20, 7ba8 <f12+0xea8>
    7958:	911502e0 	add	x0, x23, #0x540
    795c:	aa1403e2 	mov	x2, x20
    7960:	d280001a 	mov	x26, #0x0                   	// #0
    7964:	f949ec05 	ldr	x5, [x0, #5080]
    7968:	f949d808 	ldr	x8, [x0, #5040]
    796c:	f949fc07 	ldr	x7, [x0, #5112]
    7970:	d370bca5 	lsl	x5, x5, #16
    7974:	14000006 	b	798c <f12+0xc8c>
    7978:	f9400842 	ldr	x2, [x2, #16]
    797c:	9100075a 	add	x26, x26, #0x1
    7980:	f100005f 	cmp	x2, #0x0
    7984:	fa531342 	ccmp	x26, x19, #0x2, ne	// ne = any
    7988:	54000322 	b.cs	79ec <f12+0xcec>  // b.hs, b.nlast
    798c:	cb080040 	sub	x0, x2, x8
    7990:	eb05001f 	cmp	x0, x5
    7994:	540002c2 	b.cs	79ec <f12+0xcec>  // b.hs, b.nlast
    7998:	d350fc01 	lsr	x1, x0, #16
    799c:	8b010821 	add	x1, x1, x1, lsl #2
    79a0:	d37df021 	lsl	x1, x1, #3
    79a4:	8b0100e6 	add	x6, x7, x1
    79a8:	f94010c4 	ldr	x4, [x6, #32]
    79ac:	b4000204 	cbz	x4, 79ec <f12+0xcec>
    79b0:	386168e1 	ldrb	w1, [x7, x1]
    79b4:	7100083f 	cmp	w1, #0x2
    79b8:	54000f20 	b.eq	7b9c <f12+0xe9c>  // b.none
    79bc:	7100043f 	cmp	w1, #0x1
    79c0:	54000161 	b.ne	79ec <f12+0xcec>  // b.any
    79c4:	294304c9 	ldp	w9, w1, [x6, #24]
    79c8:	92403c00 	and	x0, x0, #0xffff
    79cc:	9b097c00 	mul	x0, x0, x9
    79d0:	d360fc00 	lsr	x0, x0, #32
    79d4:	eb01001f 	cmp	x0, x1
    79d8:	540000a2 	b.cs	79ec <f12+0xcec>  // b.hs, b.nlast
    79dc:	8b000084 	add	x4, x4, x0
    79e0:	39400080 	ldrb	w0, [x4]
    79e4:	7100041f 	cmp	w0, #0x1
    79e8:	54fffc80 	b.eq	7978 <f12+0xc78>  // b.none
    79ec:	d2800018 	mov	x24, #0x0                   	// #0
    79f0:	eb13035f 	cmp	x26, x19
    79f4:	540011e2 	b.cs	7c30 <f12+0xf30>  // b.hs, b.nlast
    79f8:	d1002360 	sub	x0, x27, #0x8
    79fc:	f9000be0 	str	x0, [sp, #16]
    7a00:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7a04:	911502fc 	add	x28, x23, #0x540
    7a08:	d2800018 	mov	x24, #0x0                   	// #0
    7a0c:	fd459008 	ldr	d8, [x0, #2848]
    7a10:	14000043 	b	7b1c <f12+0xe1c>
    7a14:	f94002a0 	ldr	x0, [x21]
    7a18:	aa2003e0 	mvn	x0, x0
    7a1c:	f8217b80 	str	x0, [x28, x1, lsl #3]
    7a20:	f10060bf 	cmp	x5, #0x18
    7a24:	54000169 	b.ls	7a50 <f12+0xd50>  // b.plast
    7a28:	d10064a2 	sub	x2, x5, #0x19
    7a2c:	910062a0 	add	x0, x21, #0x18
    7a30:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7a34:	52800001 	mov	w1, #0x0                   	// #0
    7a38:	91002042 	add	x2, x2, #0x8
    7a3c:	f9000fe5 	str	x5, [sp, #24]
    7a40:	b90023e6 	str	w6, [sp, #32]
    7a44:	97ffeb5f 	bl	27c0 <memset@plt>
    7a48:	f9400fe5 	ldr	x5, [sp, #24]
    7a4c:	b94023e6 	ldr	w6, [sp, #32]
    7a50:	911502e1 	add	x1, x23, #0x540
    7a54:	f94a1020 	ldr	x0, [x1, #5152]
    7a58:	ab050000 	adds	x0, x0, x5
    7a5c:	540010a2 	b.cs	7c70 <f12+0xf70>  // b.hs, b.nlast
    7a60:	f94a1422 	ldr	x2, [x1, #5160]
    7a64:	f90a1020 	str	x0, [x1, #5152]
    7a68:	eb02001f 	cmp	x0, x2
    7a6c:	54000049 	b.ls	7a74 <f12+0xd74>  // b.plast
    7a70:	f90a1420 	str	x0, [x1, #5160]
    7a74:	911502e0 	add	x0, x23, #0x540
    7a78:	1e6300c1 	ucvtf	d1, w6
    7a7c:	fd4a1c00 	ldr	d0, [x0, #5176]
    7a80:	1e612800 	fadd	d0, d0, d1
    7a84:	fd0a1c00 	str	d0, [x0, #5176]
    7a88:	f94007e0 	ldr	x0, [sp, #8]
    7a8c:	a900e2a0 	stp	x0, x24, [x21, #8]
    7a90:	aa1503f8 	mov	x24, x21
    7a94:	fd0002a8 	str	d8, [x21]
    7a98:	f949db81 	ldr	x1, [x28, #5040]
    7a9c:	f949ef80 	ldr	x0, [x28, #5080]
    7aa0:	cb0102a1 	sub	x1, x21, x1
    7aa4:	eb00403f 	cmp	x1, x0, lsl #16
    7aa8:	54000322 	b.cs	7b0c <f12+0xe0c>  // b.hs, b.nlast
    7aac:	d350fc20 	lsr	x0, x1, #16
    7ab0:	f949ff85 	ldr	x5, [x28, #5112]
    7ab4:	8b000800 	add	x0, x0, x0, lsl #2
    7ab8:	d37df002 	lsl	x2, x0, #3
    7abc:	8b0200a0 	add	x0, x5, x2
    7ac0:	f9401015 	ldr	x21, [x0, #32]
    7ac4:	b4000255 	cbz	x21, 7b0c <f12+0xe0c>
    7ac8:	386268a2 	ldrb	w2, [x5, x2]
    7acc:	7100085f 	cmp	w2, #0x2
    7ad0:	54000600 	b.eq	7b90 <f12+0xe90>  // b.none
    7ad4:	7100045f 	cmp	w2, #0x1
    7ad8:	540001a1 	b.ne	7b0c <f12+0xe0c>  // b.any
    7adc:	29430002 	ldp	w2, w0, [x0, #24]
    7ae0:	92403c21 	and	x1, x1, #0xffff
    7ae4:	9b027c21 	mul	x1, x1, x2
    7ae8:	d360fc21 	lsr	x1, x1, #32
    7aec:	eb00003f 	cmp	x1, x0
    7af0:	540000e2 	b.cs	7b0c <f12+0xe0c>  // b.hs, b.nlast
    7af4:	8b0102b5 	add	x21, x21, x1
    7af8:	394002a0 	ldrb	w0, [x21]
    7afc:	7103fc1f 	cmp	w0, #0xff
    7b00:	54000b20 	b.eq	7c64 <f12+0xf64>  // b.none
    7b04:	52800020 	mov	w0, #0x1                   	// #1
    7b08:	390002a0 	strb	w0, [x21]
    7b0c:	d1000660 	sub	x0, x19, #0x1
    7b10:	eb1a001f 	cmp	x0, x26
    7b14:	54000b09 	b.ls	7c74 <f12+0xf74>  // b.plast
    7b18:	aa0003f3 	mov	x19, x0
    7b1c:	f9400be1 	ldr	x1, [sp, #16]
    7b20:	b953a780 	ldr	w0, [x28, #5028]
    7b24:	f8737821 	ldr	x1, [x1, x19, lsl #3]
    7b28:	f90007e1 	str	x1, [sp, #8]
    7b2c:	34000280 	cbz	w0, 7b7c <f12+0xe7c>
    7b30:	397e8b80 	ldrb	w0, [x28, #4002]
    7b34:	910f0002 	add	x2, x0, #0x3c0
    7b38:	8b000401 	add	x1, x0, x0, lsl #1
    7b3c:	b8627b86 	ldr	w6, [x28, x2, lsl #2]
    7b40:	8b010f82 	add	x2, x28, x1, lsl #3
    7b44:	f8617b95 	ldr	x21, [x28, x1, lsl #3]
    7b48:	2a0603e5 	mov	w5, w6
    7b4c:	b5fff655 	cbnz	x21, 7a14 <f12+0xd14>
    7b50:	f9400455 	ldr	x21, [x2, #8]
    7b54:	b4000155 	cbz	x21, 7b7c <f12+0xe7c>
    7b58:	f9400841 	ldr	x1, [x2, #16]
    7b5c:	cb150021 	sub	x1, x1, x21
    7b60:	eb0100bf 	cmp	x5, x1
    7b64:	540000c8 	b.hi	7b7c <f12+0xe7c>  // b.pmore
    7b68:	d2800302 	mov	x2, #0x18                  	// #24
    7b6c:	8b0502a1 	add	x1, x21, x5
    7b70:	9b027000 	madd	x0, x0, x2, x28
    7b74:	f9000401 	str	x1, [x0, #8]
    7b78:	17ffffaa 	b	7a20 <f12+0xd20>
    7b7c:	52800001 	mov	w1, #0x0                   	// #0
    7b80:	d2800300 	mov	x0, #0x18                  	// #24
    7b84:	97fff41b 	bl	4bf0 <fwp_heap_alloc>
    7b88:	aa0003f5 	mov	x21, x0
    7b8c:	17ffffbf 	b	7a88 <f12+0xd88>
    7b90:	72003c3f 	tst	w1, #0xffff
    7b94:	54fffbc1 	b.ne	7b0c <f12+0xe0c>  // b.any
    7b98:	17ffffd8 	b	7af8 <f12+0xdf8>
    7b9c:	72003c1f 	tst	w0, #0xffff
    7ba0:	54fff261 	b.ne	79ec <f12+0xcec>  // b.any
    7ba4:	17ffff8f 	b	79e0 <f12+0xce0>
    7ba8:	d280001a 	mov	x26, #0x0                   	// #0
    7bac:	17ffff93 	b	79f8 <f12+0xcf8>
    7bb0:	52800041 	mov	w1, #0x2                   	// #2
    7bb4:	d2800100 	mov	x0, #0x8                   	// #8
    7bb8:	97fff40e 	bl	4bf0 <fwp_heap_alloc>
    7bbc:	aa0003fb 	mov	x27, x0
    7bc0:	52800019 	mov	w25, #0x0                   	// #0
    7bc4:	d2800018 	mov	x24, #0x0                   	// #0
    7bc8:	7100033f 	cmp	w25, #0x0
    7bcc:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7bd0:	aa1b03e0 	mov	x0, x27
    7bd4:	97fff14b 	bl	4100 <fwp_mem_free>
    7bd8:	aa1603e0 	mov	x0, x22
    7bdc:	97fffba1 	bl	6a60 <fwp_drop4>
    7be0:	aa1403e0 	mov	x0, x20
    7be4:	97fff808 	bl	5c04 <fwp_drop0>
    7be8:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7bec:	f947f400 	ldr	x0, [x0, #4072]
    7bf0:	f94057e2 	ldr	x2, [sp, #168]
    7bf4:	f9400001 	ldr	x1, [x0]
    7bf8:	eb010042 	subs	x2, x2, x1
    7bfc:	d2800001 	mov	x1, #0x0                   	// #0
    7c00:	54000161 	b.ne	7c2c <f12+0xf2c>  // b.any
    7c04:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7c08:	aa1803e0 	mov	x0, x24
    7c0c:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7c10:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7c14:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7c18:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7c1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    7c20:	fd408be8 	ldr	d8, [sp, #272]
    7c24:	910483ff 	add	sp, sp, #0x120
    7c28:	d65f03c0 	ret
    7c2c:	97ffeaf1 	bl	27f0 <__stack_chk_fail@plt>
    7c30:	aa1403e0 	mov	x0, x20
    7c34:	d2800001 	mov	x1, #0x0                   	// #0
    7c38:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    7c3c:	91000421 	add	x1, x1, #0x1
    7c40:	f9000402 	str	x2, [x0, #8]
    7c44:	aa0003e2 	mov	x2, x0
    7c48:	f9400800 	ldr	x0, [x0, #16]
    7c4c:	eb01035f 	cmp	x26, x1
    7c50:	54ffff48 	b.hi	7c38 <f12+0xf38>  // b.pmore
    7c54:	f9000858 	str	x24, [x2, #16]
    7c58:	aa1403f8 	mov	x24, x20
    7c5c:	aa0003f4 	mov	x20, x0
    7c60:	17ffffda 	b	7bc8 <f12+0xec8>
    7c64:	aa1503e0 	mov	x0, x21
    7c68:	97fff08a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7c6c:	17ffffa6 	b	7b04 <f12+0xe04>
    7c70:	97ffecd0 	bl	2fb0 <fwp_heap_oom>
    7c74:	b5fffdfa 	cbnz	x26, 7c30 <f12+0xf30>
    7c78:	7100033f 	cmp	w25, #0x0
    7c7c:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7c80:	b4fffa80 	cbz	x0, 7bd0 <f12+0xed0>
    7c84:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x180>
    7c88:	d1000a73 	sub	x19, x19, #0x2
    7c8c:	911502f7 	add	x23, x23, #0x540
    7c90:	d280031a 	mov	x26, #0x18                  	// #24
    7c94:	fd459008 	ldr	d8, [x0, #2848]
    7c98:	52800039 	mov	w25, #0x1                   	// #1
    7c9c:	b953a6e0 	ldr	w0, [x23, #5028]
    7ca0:	f8737b7c 	ldr	x28, [x27, x19, lsl #3]
    7ca4:	34000a20 	cbz	w0, 7de8 <f12+0x10e8>
    7ca8:	397e8ae0 	ldrb	w0, [x23, #4002]
    7cac:	910f0002 	add	x2, x0, #0x3c0
    7cb0:	8b000401 	add	x1, x0, x0, lsl #1
    7cb4:	b8627ae4 	ldr	w4, [x23, x2, lsl #2]
    7cb8:	8b010ee2 	add	x2, x23, x1, lsl #3
    7cbc:	f8617af5 	ldr	x21, [x23, x1, lsl #3]
    7cc0:	2a0403e3 	mov	w3, w4
    7cc4:	b40007f5 	cbz	x21, 7dc0 <f12+0x10c0>
    7cc8:	f94002a0 	ldr	x0, [x21]
    7ccc:	aa2003e0 	mvn	x0, x0
    7cd0:	f8217ae0 	str	x0, [x23, x1, lsl #3]
    7cd4:	f100607f 	cmp	x3, #0x18
    7cd8:	54000169 	b.ls	7d04 <f12+0x1004>  // b.plast
    7cdc:	d1006462 	sub	x2, x3, #0x19
    7ce0:	910062a0 	add	x0, x21, #0x18
    7ce4:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7ce8:	52800001 	mov	w1, #0x0                   	// #0
    7cec:	91002042 	add	x2, x2, #0x8
    7cf0:	f90007e3 	str	x3, [sp, #8]
    7cf4:	b90013e4 	str	w4, [sp, #16]
    7cf8:	97ffeab2 	bl	27c0 <memset@plt>
    7cfc:	f94007e3 	ldr	x3, [sp, #8]
    7d00:	b94013e4 	ldr	w4, [sp, #16]
    7d04:	f94a12e0 	ldr	x0, [x23, #5152]
    7d08:	ab030000 	adds	x0, x0, x3
    7d0c:	54fffb22 	b.cs	7c70 <f12+0xf70>  // b.hs, b.nlast
    7d10:	f94a16e1 	ldr	x1, [x23, #5160]
    7d14:	f90a12e0 	str	x0, [x23, #5152]
    7d18:	eb01001f 	cmp	x0, x1
    7d1c:	54000049 	b.ls	7d24 <f12+0x1024>  // b.plast
    7d20:	f90a16e0 	str	x0, [x23, #5160]
    7d24:	1e630081 	ucvtf	d1, w4
    7d28:	fd4a1ee0 	ldr	d0, [x23, #5176]
    7d2c:	1e612800 	fadd	d0, d0, d1
    7d30:	fd0a1ee0 	str	d0, [x23, #5176]
    7d34:	a900e2bc 	stp	x28, x24, [x21, #8]
    7d38:	aa1503f8 	mov	x24, x21
    7d3c:	fd0002a8 	str	d8, [x21]
    7d40:	f949dae1 	ldr	x1, [x23, #5040]
    7d44:	f949eee0 	ldr	x0, [x23, #5080]
    7d48:	cb0102a1 	sub	x1, x21, x1
    7d4c:	eb00403f 	cmp	x1, x0, lsl #16
    7d50:	54000302 	b.cs	7db0 <f12+0x10b0>  // b.hs, b.nlast
    7d54:	d350fc20 	lsr	x0, x1, #16
    7d58:	f949fee3 	ldr	x3, [x23, #5112]
    7d5c:	8b000800 	add	x0, x0, x0, lsl #2
    7d60:	d37df002 	lsl	x2, x0, #3
    7d64:	8b020060 	add	x0, x3, x2
    7d68:	f9401015 	ldr	x21, [x0, #32]
    7d6c:	b4000235 	cbz	x21, 7db0 <f12+0x10b0>
    7d70:	38626862 	ldrb	w2, [x3, x2]
    7d74:	7100085f 	cmp	w2, #0x2
    7d78:	54000420 	b.eq	7dfc <f12+0x10fc>  // b.none
    7d7c:	7100045f 	cmp	w2, #0x1
    7d80:	54000181 	b.ne	7db0 <f12+0x10b0>  // b.any
    7d84:	29430002 	ldp	w2, w0, [x0, #24]
    7d88:	92403c21 	and	x1, x1, #0xffff
    7d8c:	9b027c21 	mul	x1, x1, x2
    7d90:	d360fc21 	lsr	x1, x1, #32
    7d94:	eb00003f 	cmp	x1, x0
    7d98:	540000c2 	b.cs	7db0 <f12+0x10b0>  // b.hs, b.nlast
    7d9c:	8b0102b5 	add	x21, x21, x1
    7da0:	394002a0 	ldrb	w0, [x21]
    7da4:	7103fc1f 	cmp	w0, #0xff
    7da8:	54000300 	b.eq	7e08 <f12+0x1108>  // b.none
    7dac:	390002b9 	strb	w25, [x21]
    7db0:	d1000673 	sub	x19, x19, #0x1
    7db4:	b100067f 	cmn	x19, #0x1
    7db8:	54fff721 	b.ne	7c9c <f12+0xf9c>  // b.any
    7dbc:	17ffff85 	b	7bd0 <f12+0xed0>
    7dc0:	f9400455 	ldr	x21, [x2, #8]
    7dc4:	b4000135 	cbz	x21, 7de8 <f12+0x10e8>
    7dc8:	f9400841 	ldr	x1, [x2, #16]
    7dcc:	cb150021 	sub	x1, x1, x21
    7dd0:	eb01007f 	cmp	x3, x1
    7dd4:	540000a8 	b.hi	7de8 <f12+0x10e8>  // b.pmore
    7dd8:	9b1a5c00 	madd	x0, x0, x26, x23
    7ddc:	8b0302a1 	add	x1, x21, x3
    7de0:	f9000401 	str	x1, [x0, #8]
    7de4:	17ffffbc 	b	7cd4 <f12+0xfd4>
    7de8:	52800001 	mov	w1, #0x0                   	// #0
    7dec:	d2800300 	mov	x0, #0x18                  	// #24
    7df0:	97fff380 	bl	4bf0 <fwp_heap_alloc>
    7df4:	aa0003f5 	mov	x21, x0
    7df8:	17ffffcf 	b	7d34 <f12+0x1034>
    7dfc:	72003c3f 	tst	w1, #0xffff
    7e00:	54fffd81 	b.ne	7db0 <f12+0x10b0>  // b.any
    7e04:	17ffffe7 	b	7da0 <f12+0x10a0>
    7e08:	aa1503e0 	mov	x0, x21
    7e0c:	97fff021 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7e10:	17ffffe7 	b	7dac <f12+0x10ac>
    7e14:	aa1303e0 	mov	x0, x19
    7e18:	97fff01e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7e1c:	17fffea7 	b	78b8 <f12+0xbb8>
    7e20:	72003c3f 	tst	w1, #0xffff
    7e24:	54ffd440 	b.eq	78ac <f12+0xbac>  // b.none
    7e28:	aa1503e0 	mov	x0, x21
    7e2c:	17fffe02 	b	7634 <f12+0x934>
    7e30:	f9400315 	ldr	x21, [x24]
    7e34:	b7ffebf5 	tbnz	x21, #63, 7bb0 <f12+0xeb0>
    7e38:	9240fab5 	and	x21, x21, #0x7fffffffffffffff
    7e3c:	d2800013 	mov	x19, #0x0                   	// #0
    7e40:	17fffe18 	b	76a0 <f12+0x9a0>
    7e44:	aa1303e0 	mov	x0, x19
    7e48:	97fff012 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7e4c:	9100c2c0 	add	x0, x22, #0x30
    7e50:	f941601a 	ldr	x26, [x0, #704]
    7e54:	17fffdcd 	b	7588 <f12+0x888>
    7e58:	97ffeaea 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7e5c:	97ffea79 	bl	2840 <abort@plt>

0000000000007e60 <fwp_owned_entry12>:
    7e60:	f9400000 	ldr	x0, [x0]
    7e64:	17fffba7 	b	6d00 <f12>
    7e68:	d503201f 	nop
    7e6c:	d503201f 	nop

0000000000007e70 <e12>:
    7e70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7e74:	910003fd 	mov	x29, sp
    7e78:	f9000bf3 	str	x19, [sp, #16]
    7e7c:	f9400013 	ldr	x19, [x0]
    7e80:	aa1303e0 	mov	x0, x19
    7e84:	97fff698 	bl	58e4 <fwp_rc_share>
    7e88:	aa1303e0 	mov	x0, x19
    7e8c:	97fffb9d 	bl	6d00 <f12>
    7e90:	aa0003f3 	mov	x19, x0
    7e94:	97fff694 	bl	58e4 <fwp_rc_share>
    7e98:	aa1303e0 	mov	x0, x19
    7e9c:	f9400bf3 	ldr	x19, [sp, #16]
    7ea0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ea4:	d65f03c0 	ret
    7ea8:	d503201f 	nop
    7eac:	d503201f 	nop

0000000000007eb0 <fwp_args23>:
    7eb0:	7100003f 	cmp	w1, #0x0
    7eb4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7eb8:	54000041 	b.ne	7ec0 <fwp_args23+0x10>  // b.any
    7ebc:	d65f03c0 	ret
    7ec0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7ec4:	91150042 	add	x2, x2, #0x540
    7ec8:	f9400001 	ldr	x1, [x0]
    7ecc:	f949d843 	ldr	x3, [x2, #5040]
    7ed0:	f949ec40 	ldr	x0, [x2, #5080]
    7ed4:	cb030021 	sub	x1, x1, x3
    7ed8:	eb00403f 	cmp	x1, x0, lsl #16
    7edc:	54ffff02 	b.cs	7ebc <fwp_args23+0xc>  // b.hs, b.nlast
    7ee0:	d350fc20 	lsr	x0, x1, #16
    7ee4:	f949fc44 	ldr	x4, [x2, #5112]
    7ee8:	8b000800 	add	x0, x0, x0, lsl #2
    7eec:	d37df002 	lsl	x2, x0, #3
    7ef0:	8b020083 	add	x3, x4, x2
    7ef4:	f9401060 	ldr	x0, [x3, #32]
    7ef8:	b4fffe20 	cbz	x0, 7ebc <fwp_args23+0xc>
    7efc:	38626882 	ldrb	w2, [x4, x2]
    7f00:	7100085f 	cmp	w2, #0x2
    7f04:	54000220 	b.eq	7f48 <fwp_args23+0x98>  // b.none
    7f08:	7100045f 	cmp	w2, #0x1
    7f0c:	54fffd81 	b.ne	7ebc <fwp_args23+0xc>  // b.any
    7f10:	29430864 	ldp	w4, w2, [x3, #24]
    7f14:	92403c21 	and	x1, x1, #0xffff
    7f18:	9b047c21 	mul	x1, x1, x4
    7f1c:	d360fc21 	lsr	x1, x1, #32
    7f20:	eb02003f 	cmp	x1, x2
    7f24:	54fffcc2 	b.cs	7ebc <fwp_args23+0xc>  // b.hs, b.nlast
    7f28:	8b010000 	add	x0, x0, x1
    7f2c:	39400001 	ldrb	w1, [x0]
    7f30:	34fffc61 	cbz	w1, 7ebc <fwp_args23+0xc>
    7f34:	7103f43f 	cmp	w1, #0xfd
    7f38:	540000e8 	b.hi	7f54 <fwp_args23+0xa4>  // b.pmore
    7f3c:	11000421 	add	w1, w1, #0x1
    7f40:	39000001 	strb	w1, [x0]
    7f44:	d65f03c0 	ret
    7f48:	72003c3f 	tst	w1, #0xffff
    7f4c:	54ffff00 	b.eq	7f2c <fwp_args23+0x7c>  // b.none
    7f50:	d65f03c0 	ret
    7f54:	17fff0e4 	b	42e4 <fwp_rc_wide_dup>
    7f58:	d503201f 	nop
    7f5c:	d503201f 	nop

0000000000007f60 <fwp_args12>:
    7f60:	7100003f 	cmp	w1, #0x0
    7f64:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7f68:	54000041 	b.ne	7f70 <fwp_args12+0x10>  // b.any
    7f6c:	d65f03c0 	ret
    7f70:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7f74:	91150042 	add	x2, x2, #0x540
    7f78:	f9400001 	ldr	x1, [x0]
    7f7c:	f949d843 	ldr	x3, [x2, #5040]
    7f80:	f949ec40 	ldr	x0, [x2, #5080]
    7f84:	cb030021 	sub	x1, x1, x3
    7f88:	eb00403f 	cmp	x1, x0, lsl #16
    7f8c:	54ffff02 	b.cs	7f6c <fwp_args12+0xc>  // b.hs, b.nlast
    7f90:	d350fc20 	lsr	x0, x1, #16
    7f94:	f949fc44 	ldr	x4, [x2, #5112]
    7f98:	8b000800 	add	x0, x0, x0, lsl #2
    7f9c:	d37df002 	lsl	x2, x0, #3
    7fa0:	8b020083 	add	x3, x4, x2
    7fa4:	f9401060 	ldr	x0, [x3, #32]
    7fa8:	b4fffe20 	cbz	x0, 7f6c <fwp_args12+0xc>
    7fac:	38626882 	ldrb	w2, [x4, x2]
    7fb0:	7100085f 	cmp	w2, #0x2
    7fb4:	54000220 	b.eq	7ff8 <fwp_args12+0x98>  // b.none
    7fb8:	7100045f 	cmp	w2, #0x1
    7fbc:	54fffd81 	b.ne	7f6c <fwp_args12+0xc>  // b.any
    7fc0:	29430864 	ldp	w4, w2, [x3, #24]
    7fc4:	92403c21 	and	x1, x1, #0xffff
    7fc8:	9b047c21 	mul	x1, x1, x4
    7fcc:	d360fc21 	lsr	x1, x1, #32
    7fd0:	eb02003f 	cmp	x1, x2
    7fd4:	54fffcc2 	b.cs	7f6c <fwp_args12+0xc>  // b.hs, b.nlast
    7fd8:	8b010000 	add	x0, x0, x1
    7fdc:	39400001 	ldrb	w1, [x0]
    7fe0:	34fffc61 	cbz	w1, 7f6c <fwp_args12+0xc>
    7fe4:	7103f43f 	cmp	w1, #0xfd
    7fe8:	540000e8 	b.hi	8004 <fwp_args12+0xa4>  // b.pmore
    7fec:	11000421 	add	w1, w1, #0x1
    7ff0:	39000001 	strb	w1, [x0]
    7ff4:	d65f03c0 	ret
    7ff8:	72003c3f 	tst	w1, #0xffff
    7ffc:	54ffff00 	b.eq	7fdc <fwp_args12+0x7c>  // b.none
    8000:	d65f03c0 	ret
    8004:	17fff0b8 	b	42e4 <fwp_rc_wide_dup>
    8008:	d503201f 	nop
    800c:	d503201f 	nop

0000000000008010 <fwp_caps12>:
    8010:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8014:	910003fd 	mov	x29, sp
    8018:	f9000bf3 	str	x19, [sp, #16]
    801c:	aa0003f3 	mov	x19, x0
    8020:	b9400400 	ldr	w0, [x0, #4]
    8024:	340004a0 	cbz	w0, 80b8 <fwp_caps12+0xa8>
    8028:	f9400660 	ldr	x0, [x19, #8]
    802c:	350004e1 	cbnz	w1, 80c8 <fwp_caps12+0xb8>
    8030:	97fff6f5 	bl	5c04 <fwp_drop0>
    8034:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    8038:	91150042 	add	x2, x2, #0x540
    803c:	f949d840 	ldr	x0, [x2, #5040]
    8040:	f949ec41 	ldr	x1, [x2, #5080]
    8044:	cb000260 	sub	x0, x19, x0
    8048:	eb01401f 	cmp	x0, x1, lsl #16
    804c:	54000382 	b.cs	80bc <fwp_caps12+0xac>  // b.hs, b.nlast
    8050:	d350fc01 	lsr	x1, x0, #16
    8054:	f949fc44 	ldr	x4, [x2, #5112]
    8058:	8b010821 	add	x1, x1, x1, lsl #2
    805c:	d37df021 	lsl	x1, x1, #3
    8060:	8b010083 	add	x3, x4, x1
    8064:	f9401062 	ldr	x2, [x3, #32]
    8068:	b40002a2 	cbz	x2, 80bc <fwp_caps12+0xac>
    806c:	38616881 	ldrb	w1, [x4, x1]
    8070:	7100083f 	cmp	w1, #0x2
    8074:	540006c0 	b.eq	814c <fwp_caps12+0x13c>  // b.none
    8078:	7100043f 	cmp	w1, #0x1
    807c:	54000201 	b.ne	80bc <fwp_caps12+0xac>  // b.any
    8080:	29430464 	ldp	w4, w1, [x3, #24]
    8084:	92403c00 	and	x0, x0, #0xffff
    8088:	9b047c00 	mul	x0, x0, x4
    808c:	d360fc00 	lsr	x0, x0, #32
    8090:	eb01001f 	cmp	x0, x1
    8094:	54000142 	b.cs	80bc <fwp_caps12+0xac>  // b.hs, b.nlast
    8098:	8b000042 	add	x2, x2, x0
    809c:	39400040 	ldrb	w0, [x2]
    80a0:	7100041f 	cmp	w0, #0x1
    80a4:	540000c1 	b.ne	80bc <fwp_caps12+0xac>  // b.any
    80a8:	aa1303e0 	mov	x0, x19
    80ac:	f9400bf3 	ldr	x19, [sp, #16]
    80b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80b4:	17fff013 	b	4100 <fwp_mem_free>
    80b8:	34fffbe1 	cbz	w1, 8034 <fwp_caps12+0x24>
    80bc:	f9400bf3 	ldr	x19, [sp, #16]
    80c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80c4:	d65f03c0 	ret
    80c8:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    80cc:	91150042 	add	x2, x2, #0x540
    80d0:	f949d843 	ldr	x3, [x2, #5040]
    80d4:	f949ec41 	ldr	x1, [x2, #5080]
    80d8:	cb030000 	sub	x0, x0, x3
    80dc:	eb01401f 	cmp	x0, x1, lsl #16
    80e0:	54fffee2 	b.cs	80bc <fwp_caps12+0xac>  // b.hs, b.nlast
    80e4:	d350fc01 	lsr	x1, x0, #16
    80e8:	f949fc44 	ldr	x4, [x2, #5112]
    80ec:	8b010821 	add	x1, x1, x1, lsl #2
    80f0:	d37df021 	lsl	x1, x1, #3
    80f4:	8b010083 	add	x3, x4, x1
    80f8:	f9401062 	ldr	x2, [x3, #32]
    80fc:	b4fffe02 	cbz	x2, 80bc <fwp_caps12+0xac>
    8100:	38616881 	ldrb	w1, [x4, x1]
    8104:	7100083f 	cmp	w1, #0x2
    8108:	54000280 	b.eq	8158 <fwp_caps12+0x148>  // b.none
    810c:	7100043f 	cmp	w1, #0x1
    8110:	54fffd61 	b.ne	80bc <fwp_caps12+0xac>  // b.any
    8114:	92403c01 	and	x1, x0, #0xffff
    8118:	29430064 	ldp	w4, w0, [x3, #24]
    811c:	9b047c21 	mul	x1, x1, x4
    8120:	d360fc21 	lsr	x1, x1, #32
    8124:	eb00003f 	cmp	x1, x0
    8128:	54fffca2 	b.cs	80bc <fwp_caps12+0xac>  // b.hs, b.nlast
    812c:	8b010042 	add	x2, x2, x1
    8130:	39400040 	ldrb	w0, [x2]
    8134:	34fffc40 	cbz	w0, 80bc <fwp_caps12+0xac>
    8138:	7103f41f 	cmp	w0, #0xfd
    813c:	54000148 	b.hi	8164 <fwp_caps12+0x154>  // b.pmore
    8140:	11000400 	add	w0, w0, #0x1
    8144:	39000040 	strb	w0, [x2]
    8148:	17ffffdd 	b	80bc <fwp_caps12+0xac>
    814c:	72003c1f 	tst	w0, #0xffff
    8150:	54fffb61 	b.ne	80bc <fwp_caps12+0xac>  // b.any
    8154:	17ffffd2 	b	809c <fwp_caps12+0x8c>
    8158:	72003c1f 	tst	w0, #0xffff
    815c:	54fffb01 	b.ne	80bc <fwp_caps12+0xac>  // b.any
    8160:	17fffff4 	b	8130 <fwp_caps12+0x120>
    8164:	f9400bf3 	ldr	x19, [sp, #16]
    8168:	aa0203e0 	mov	x0, x2
    816c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8170:	17fff05d 	b	42e4 <fwp_rc_wide_dup>

0000000000008174 <fwp_drop2>:
    8174:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    8178:	910003fd 	mov	x29, sp
    817c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8180:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    8184:	911502d5 	add	x21, x22, #0x540
    8188:	a90153f3 	stp	x19, x20, [sp, #16]
    818c:	aa0003f3 	mov	x19, x0
    8190:	f949daa1 	ldr	x1, [x21, #5040]
    8194:	f949eea0 	ldr	x0, [x21, #5080]
    8198:	cb010261 	sub	x1, x19, x1
    819c:	eb00403f 	cmp	x1, x0, lsl #16
    81a0:	54000382 	b.cs	8210 <fwp_drop2+0x9c>  // b.hs, b.nlast
    81a4:	d350fc22 	lsr	x2, x1, #16
    81a8:	f949fea3 	ldr	x3, [x21, #5112]
    81ac:	8b020842 	add	x2, x2, x2, lsl #2
    81b0:	d37df042 	lsl	x2, x2, #3
    81b4:	8b020060 	add	x0, x3, x2
    81b8:	f9401014 	ldr	x20, [x0, #32]
    81bc:	b40002b4 	cbz	x20, 8210 <fwp_drop2+0x9c>
    81c0:	38626862 	ldrb	w2, [x3, x2]
    81c4:	7100085f 	cmp	w2, #0x2
    81c8:	540002c0 	b.eq	8220 <fwp_drop2+0xac>  // b.none
    81cc:	7100045f 	cmp	w2, #0x1
    81d0:	54000201 	b.ne	8210 <fwp_drop2+0x9c>  // b.any
    81d4:	29430002 	ldp	w2, w0, [x0, #24]
    81d8:	92403c21 	and	x1, x1, #0xffff
    81dc:	9b027c21 	mul	x1, x1, x2
    81e0:	d360fc21 	lsr	x1, x1, #32
    81e4:	eb00003f 	cmp	x1, x0
    81e8:	54000142 	b.cs	8210 <fwp_drop2+0x9c>  // b.hs, b.nlast
    81ec:	8b010294 	add	x20, x20, x1
    81f0:	39400280 	ldrb	w0, [x20]
    81f4:	340000e0 	cbz	w0, 8210 <fwp_drop2+0x9c>
    81f8:	7100041f 	cmp	w0, #0x1
    81fc:	540001e0 	b.eq	8238 <fwp_drop2+0xc4>  // b.none
    8200:	7103fc1f 	cmp	w0, #0xff
    8204:	540007e0 	b.eq	8300 <fwp_drop2+0x18c>  // b.none
    8208:	51000400 	sub	w0, w0, #0x1
    820c:	39000280 	strb	w0, [x20]
    8210:	a94153f3 	ldp	x19, x20, [sp, #16]
    8214:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8218:	a8c37bfd 	ldp	x29, x30, [sp], #48
    821c:	d65f03c0 	ret
    8220:	72003c3f 	tst	w1, #0xffff
    8224:	54fffe60 	b.eq	81f0 <fwp_drop2+0x7c>  // b.none
    8228:	a94153f3 	ldp	x19, x20, [sp, #16]
    822c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8230:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8234:	d65f03c0 	ret
    8238:	911502c2 	add	x2, x22, #0x540
    823c:	f9400660 	ldr	x0, [x19, #8]
    8240:	f949d841 	ldr	x1, [x2, #5040]
    8244:	f949ec42 	ldr	x2, [x2, #5080]
    8248:	cb010001 	sub	x1, x0, x1
    824c:	eb02403f 	cmp	x1, x2, lsl #16
    8250:	54000382 	b.cs	82c0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8254:	d350fc22 	lsr	x2, x1, #16
    8258:	8b020842 	add	x2, x2, x2, lsl #2
    825c:	d37df042 	lsl	x2, x2, #3
    8260:	8b020064 	add	x4, x3, x2
    8264:	f9401094 	ldr	x20, [x4, #32]
    8268:	b40002d4 	cbz	x20, 82c0 <fwp_drop2+0x14c>
    826c:	38626862 	ldrb	w2, [x3, x2]
    8270:	7100085f 	cmp	w2, #0x2
    8274:	54000400 	b.eq	82f4 <fwp_drop2+0x180>  // b.none
    8278:	7100045f 	cmp	w2, #0x1
    827c:	54000221 	b.ne	82c0 <fwp_drop2+0x14c>  // b.any
    8280:	29430883 	ldp	w3, w2, [x4, #24]
    8284:	92403c21 	and	x1, x1, #0xffff
    8288:	9b037c21 	mul	x1, x1, x3
    828c:	d360fc21 	lsr	x1, x1, #32
    8290:	eb02003f 	cmp	x1, x2
    8294:	54000162 	b.cs	82c0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8298:	8b010294 	add	x20, x20, x1
    829c:	39400281 	ldrb	w1, [x20]
    82a0:	34000101 	cbz	w1, 82c0 <fwp_drop2+0x14c>
    82a4:	7100043f 	cmp	w1, #0x1
    82a8:	54000220 	b.eq	82ec <fwp_drop2+0x178>  // b.none
    82ac:	7103fc3f 	cmp	w1, #0xff
    82b0:	54000660 	b.eq	837c <fwp_drop2+0x208>  // b.none
    82b4:	51000421 	sub	w1, w1, #0x1
    82b8:	39000281 	strb	w1, [x20]
    82bc:	d503201f 	nop
    82c0:	f9400a74 	ldr	x20, [x19, #16]
    82c4:	aa1303e0 	mov	x0, x19
    82c8:	97fff5ab 	bl	5974 <fwp_rc_free_arr>
    82cc:	911502c0 	add	x0, x22, #0x540
    82d0:	f949d801 	ldr	x1, [x0, #5040]
    82d4:	f949ec00 	ldr	x0, [x0, #5080]
    82d8:	cb010281 	sub	x1, x20, x1
    82dc:	eb00403f 	cmp	x1, x0, lsl #16
    82e0:	54fff982 	b.cs	8210 <fwp_drop2+0x9c>  // b.hs, b.nlast
    82e4:	aa1403f3 	mov	x19, x20
    82e8:	17ffffaf 	b	81a4 <fwp_drop2+0x30>
    82ec:	97fff5a2 	bl	5974 <fwp_rc_free_arr>
    82f0:	17fffff4 	b	82c0 <fwp_drop2+0x14c>
    82f4:	72003c3f 	tst	w1, #0xffff
    82f8:	54fffe41 	b.ne	82c0 <fwp_drop2+0x14c>  // b.any
    82fc:	17ffffe8 	b	829c <fwp_drop2+0x128>
    8300:	ca544681 	eor	x1, x20, x20, lsr #17
    8304:	911502c0 	add	x0, x22, #0x540
    8308:	ca412421 	eor	x1, x1, x1, lsr #9
    830c:	92401c21 	and	x1, x1, #0xff
    8310:	910a2422 	add	x2, x1, #0x289
    8314:	8b010c01 	add	x1, x0, x1, lsl #3
    8318:	8b020c02 	add	x2, x0, x2, lsl #3
    831c:	f94a2420 	ldr	x0, [x1, #5192]
    8320:	b50000a0 	cbnz	x0, 8334 <fwp_drop2+0x1c0>
    8324:	14000013 	b	8370 <fwp_drop2+0x1fc>
    8328:	91004002 	add	x2, x0, #0x10
    832c:	f9400800 	ldr	x0, [x0, #16]
    8330:	b4000200 	cbz	x0, 8370 <fwp_drop2+0x1fc>
    8334:	f9400001 	ldr	x1, [x0]
    8338:	eb14003f 	cmp	x1, x20
    833c:	54ffff61 	b.ne	8328 <fwp_drop2+0x1b4>  // b.any
    8340:	f9400041 	ldr	x1, [x2]
    8344:	f9400420 	ldr	x0, [x1, #8]
    8348:	d1000400 	sub	x0, x0, #0x1
    834c:	f9000420 	str	x0, [x1, #8]
    8350:	f103f81f 	cmp	x0, #0xfe
    8354:	54fff5e1 	b.ne	8210 <fwp_drop2+0x9c>  // b.any
    8358:	39400280 	ldrb	w0, [x20]
    835c:	7103fc1f 	cmp	w0, #0xff
    8360:	54000460 	b.eq	83ec <fwp_drop2+0x278>  // b.none
    8364:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8368:	39000280 	strb	w0, [x20]
    836c:	17ffffa9 	b	8210 <fwp_drop2+0x9c>
    8370:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x660>
    8374:	913f0000 	add	x0, x0, #0xfc0
    8378:	97ffeea6 	bl	3e10 <fwp_trap>
    837c:	ca544680 	eor	x0, x20, x20, lsr #17
    8380:	911502c1 	add	x1, x22, #0x540
    8384:	ca402400 	eor	x0, x0, x0, lsr #9
    8388:	92401c00 	and	x0, x0, #0xff
    838c:	910a2402 	add	x2, x0, #0x289
    8390:	8b000c20 	add	x0, x1, x0, lsl #3
    8394:	8b020c22 	add	x2, x1, x2, lsl #3
    8398:	f94a2400 	ldr	x0, [x0, #5192]
    839c:	b50000a0 	cbnz	x0, 83b0 <fwp_drop2+0x23c>
    83a0:	17fffff4 	b	8370 <fwp_drop2+0x1fc>
    83a4:	91004002 	add	x2, x0, #0x10
    83a8:	f9400800 	ldr	x0, [x0, #16]
    83ac:	b4fffe20 	cbz	x0, 8370 <fwp_drop2+0x1fc>
    83b0:	f9400001 	ldr	x1, [x0]
    83b4:	eb14003f 	cmp	x1, x20
    83b8:	54ffff61 	b.ne	83a4 <fwp_drop2+0x230>  // b.any
    83bc:	f9400041 	ldr	x1, [x2]
    83c0:	f9400420 	ldr	x0, [x1, #8]
    83c4:	d1000400 	sub	x0, x0, #0x1
    83c8:	f9000420 	str	x0, [x1, #8]
    83cc:	f103f81f 	cmp	x0, #0xfe
    83d0:	54fff781 	b.ne	82c0 <fwp_drop2+0x14c>  // b.any
    83d4:	39400280 	ldrb	w0, [x20]
    83d8:	7103fc1f 	cmp	w0, #0xff
    83dc:	540000e0 	b.eq	83f8 <fwp_drop2+0x284>  // b.none
    83e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    83e4:	39000280 	strb	w0, [x20]
    83e8:	17ffffb6 	b	82c0 <fwp_drop2+0x14c>
    83ec:	aa1403e0 	mov	x0, x20
    83f0:	97ffeea8 	bl	3e90 <fwp_rc_forget_slot.part.0>
    83f4:	17ffffdc 	b	8364 <fwp_drop2+0x1f0>
    83f8:	aa1403e0 	mov	x0, x20
    83fc:	97ffeea5 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8400:	17fffff8 	b	83e0 <fwp_drop2+0x26c>

0000000000008404 <fwp_arg_drop23>:
    8404:	7100003f 	cmp	w1, #0x0
    8408:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    840c:	54000041 	b.ne	8414 <fwp_arg_drop23+0x10>  // b.any
    8410:	d65f03c0 	ret
    8414:	f9400000 	ldr	x0, [x0]
    8418:	17ffff57 	b	8174 <fwp_drop2>
    841c:	d503201f 	nop

0000000000008420 <fwp_caps23>:
    8420:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8424:	910003fd 	mov	x29, sp
    8428:	f9000bf3 	str	x19, [sp, #16]
    842c:	aa0003f3 	mov	x19, x0
    8430:	b9400400 	ldr	w0, [x0, #4]
    8434:	340004a0 	cbz	w0, 84c8 <fwp_caps23+0xa8>
    8438:	f9400660 	ldr	x0, [x19, #8]
    843c:	350004e1 	cbnz	w1, 84d8 <fwp_caps23+0xb8>
    8440:	97ffff4d 	bl	8174 <fwp_drop2>
    8444:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    8448:	91150042 	add	x2, x2, #0x540
    844c:	f949d840 	ldr	x0, [x2, #5040]
    8450:	f949ec41 	ldr	x1, [x2, #5080]
    8454:	cb000260 	sub	x0, x19, x0
    8458:	eb01401f 	cmp	x0, x1, lsl #16
    845c:	54000382 	b.cs	84cc <fwp_caps23+0xac>  // b.hs, b.nlast
    8460:	d350fc01 	lsr	x1, x0, #16
    8464:	f949fc44 	ldr	x4, [x2, #5112]
    8468:	8b010821 	add	x1, x1, x1, lsl #2
    846c:	d37df021 	lsl	x1, x1, #3
    8470:	8b010083 	add	x3, x4, x1
    8474:	f9401062 	ldr	x2, [x3, #32]
    8478:	b40002a2 	cbz	x2, 84cc <fwp_caps23+0xac>
    847c:	38616881 	ldrb	w1, [x4, x1]
    8480:	7100083f 	cmp	w1, #0x2
    8484:	540006c0 	b.eq	855c <fwp_caps23+0x13c>  // b.none
    8488:	7100043f 	cmp	w1, #0x1
    848c:	54000201 	b.ne	84cc <fwp_caps23+0xac>  // b.any
    8490:	29430464 	ldp	w4, w1, [x3, #24]
    8494:	92403c00 	and	x0, x0, #0xffff
    8498:	9b047c00 	mul	x0, x0, x4
    849c:	d360fc00 	lsr	x0, x0, #32
    84a0:	eb01001f 	cmp	x0, x1
    84a4:	54000142 	b.cs	84cc <fwp_caps23+0xac>  // b.hs, b.nlast
    84a8:	8b000042 	add	x2, x2, x0
    84ac:	39400040 	ldrb	w0, [x2]
    84b0:	7100041f 	cmp	w0, #0x1
    84b4:	540000c1 	b.ne	84cc <fwp_caps23+0xac>  // b.any
    84b8:	aa1303e0 	mov	x0, x19
    84bc:	f9400bf3 	ldr	x19, [sp, #16]
    84c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    84c4:	17ffef0f 	b	4100 <fwp_mem_free>
    84c8:	34fffbe1 	cbz	w1, 8444 <fwp_caps23+0x24>
    84cc:	f9400bf3 	ldr	x19, [sp, #16]
    84d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    84d4:	d65f03c0 	ret
    84d8:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    84dc:	91150042 	add	x2, x2, #0x540
    84e0:	f949d843 	ldr	x3, [x2, #5040]
    84e4:	f949ec41 	ldr	x1, [x2, #5080]
    84e8:	cb030000 	sub	x0, x0, x3
    84ec:	eb01401f 	cmp	x0, x1, lsl #16
    84f0:	54fffee2 	b.cs	84cc <fwp_caps23+0xac>  // b.hs, b.nlast
    84f4:	d350fc01 	lsr	x1, x0, #16
    84f8:	f949fc44 	ldr	x4, [x2, #5112]
    84fc:	8b010821 	add	x1, x1, x1, lsl #2
    8500:	d37df021 	lsl	x1, x1, #3
    8504:	8b010083 	add	x3, x4, x1
    8508:	f9401062 	ldr	x2, [x3, #32]
    850c:	b4fffe02 	cbz	x2, 84cc <fwp_caps23+0xac>
    8510:	38616881 	ldrb	w1, [x4, x1]
    8514:	7100083f 	cmp	w1, #0x2
    8518:	54000280 	b.eq	8568 <fwp_caps23+0x148>  // b.none
    851c:	7100043f 	cmp	w1, #0x1
    8520:	54fffd61 	b.ne	84cc <fwp_caps23+0xac>  // b.any
    8524:	92403c01 	and	x1, x0, #0xffff
    8528:	29430064 	ldp	w4, w0, [x3, #24]
    852c:	9b047c21 	mul	x1, x1, x4
    8530:	d360fc21 	lsr	x1, x1, #32
    8534:	eb00003f 	cmp	x1, x0
    8538:	54fffca2 	b.cs	84cc <fwp_caps23+0xac>  // b.hs, b.nlast
    853c:	8b010042 	add	x2, x2, x1
    8540:	39400040 	ldrb	w0, [x2]
    8544:	34fffc40 	cbz	w0, 84cc <fwp_caps23+0xac>
    8548:	7103f41f 	cmp	w0, #0xfd
    854c:	54000148 	b.hi	8574 <fwp_caps23+0x154>  // b.pmore
    8550:	11000400 	add	w0, w0, #0x1
    8554:	39000040 	strb	w0, [x2]
    8558:	17ffffdd 	b	84cc <fwp_caps23+0xac>
    855c:	72003c1f 	tst	w0, #0xffff
    8560:	54fffb61 	b.ne	84cc <fwp_caps23+0xac>  // b.any
    8564:	17ffffd2 	b	84ac <fwp_caps23+0x8c>
    8568:	72003c1f 	tst	w0, #0xffff
    856c:	54fffb01 	b.ne	84cc <fwp_caps23+0xac>  // b.any
    8570:	17fffff4 	b	8540 <fwp_caps23+0x120>
    8574:	f9400bf3 	ldr	x19, [sp, #16]
    8578:	aa0203e0 	mov	x0, x2
    857c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8580:	17ffef59 	b	42e4 <fwp_rc_wide_dup>

0000000000008584 <f23>:
    8584:	d10203ff 	sub	sp, sp, #0x80
    8588:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    858c:	f947f421 	ldr	x1, [x1, #4072]
    8590:	a9027bfd 	stp	x29, x30, [sp, #32]
    8594:	910083fd 	add	x29, sp, #0x20
    8598:	a9045bf5 	stp	x21, x22, [sp, #64]
    859c:	b0000155 	adrp	x21, 31000 <fwp_root_context+0xca0>
    85a0:	911502a3 	add	x3, x21, #0x540
    85a4:	a90353f3 	stp	x19, x20, [sp, #48]
    85a8:	aa0003f6 	mov	x22, x0
    85ac:	a90563f7 	stp	x23, x24, [sp, #80]
    85b0:	a9066bf9 	stp	x25, x26, [sp, #96]
    85b4:	f949ec62 	ldr	x2, [x3, #5080]
    85b8:	f9400024 	ldr	x4, [x1]
    85bc:	f9000fe4 	str	x4, [sp, #24]
    85c0:	d2800004 	mov	x4, #0x0                   	// #0
    85c4:	f949d861 	ldr	x1, [x3, #5040]
    85c8:	d370bc42 	lsl	x2, x2, #16
    85cc:	b4001800 	cbz	x0, 88cc <f23+0x348>
    85d0:	f9400817 	ldr	x23, [x0, #16]
    85d4:	cb0102e1 	sub	x1, x23, x1
    85d8:	eb02003f 	cmp	x1, x2
    85dc:	54000362 	b.cs	8648 <f23+0xc4>  // b.hs, b.nlast
    85e0:	f949fc60 	ldr	x0, [x3, #5112]
    85e4:	d350fc22 	lsr	x2, x1, #16
    85e8:	8b020842 	add	x2, x2, x2, lsl #2
    85ec:	8b020c02 	add	x2, x0, x2, lsl #3
    85f0:	f9401040 	ldr	x0, [x2, #32]
    85f4:	b40002a0 	cbz	x0, 8648 <f23+0xc4>
    85f8:	39400043 	ldrb	w3, [x2]
    85fc:	7100087f 	cmp	w3, #0x2
    8600:	54001540 	b.eq	88a8 <f23+0x324>  // b.none
    8604:	7100047f 	cmp	w3, #0x1
    8608:	540001c1 	b.ne	8640 <f23+0xbc>  // b.any
    860c:	29430843 	ldp	w3, w2, [x2, #24]
    8610:	92403c21 	and	x1, x1, #0xffff
    8614:	9b037c21 	mul	x1, x1, x3
    8618:	d360fc21 	lsr	x1, x1, #32
    861c:	eb02003f 	cmp	x1, x2
    8620:	54000102 	b.cs	8640 <f23+0xbc>  // b.hs, b.nlast
    8624:	8b010000 	add	x0, x0, x1
    8628:	39400001 	ldrb	w1, [x0]
    862c:	340000a1 	cbz	w1, 8640 <f23+0xbc>
    8630:	7103f43f 	cmp	w1, #0xfd
    8634:	540017e8 	b.hi	8930 <f23+0x3ac>  // b.pmore
    8638:	11000421 	add	w1, w1, #0x1
    863c:	39000001 	strb	w1, [x0]
    8640:	d2800002 	mov	x2, #0x0                   	// #0
    8644:	b40000d6 	cbz	x22, 865c <f23+0xd8>
    8648:	aa1603e1 	mov	x1, x22
    864c:	d2800002 	mov	x2, #0x0                   	// #0
    8650:	f9400821 	ldr	x1, [x1, #16]
    8654:	91000442 	add	x2, x2, #0x1
    8658:	b5ffffc1 	cbnz	x1, 8650 <f23+0xcc>
    865c:	b40013f7 	cbz	x23, 88d8 <f23+0x354>
    8660:	aa1703e1 	mov	x1, x23
    8664:	d2800003 	mov	x3, #0x0                   	// #0
    8668:	f9400821 	ldr	x1, [x1, #16]
    866c:	91000463 	add	x3, x3, #0x1
    8670:	b5ffffc1 	cbnz	x1, 8668 <f23+0xe4>
    8674:	eb02007f 	cmp	x3, x2
    8678:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    867c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    8680:	eb00027f 	cmp	x19, x0
    8684:	540010a8 	b.hi	8898 <f23+0x314>  // b.pmore
    8688:	d37ffa74 	lsl	x20, x19, #1
    868c:	52800041 	mov	w1, #0x2                   	// #2
    8690:	91000680 	add	x0, x20, #0x1
    8694:	d37df000 	lsl	x0, x0, #3
    8698:	97fff156 	bl	4bf0 <fwp_heap_alloc>
    869c:	aa0003f8 	mov	x24, x0
    86a0:	911502a1 	add	x1, x21, #0x540
    86a4:	aa0103e0 	mov	x0, x1
    86a8:	f9000314 	str	x20, [x24]
    86ac:	f949d821 	ldr	x1, [x1, #5040]
    86b0:	f949ec00 	ldr	x0, [x0, #5080]
    86b4:	cb010301 	sub	x1, x24, x1
    86b8:	eb00403f 	cmp	x1, x0, lsl #16
    86bc:	54000342 	b.cs	8724 <f23+0x1a0>  // b.hs, b.nlast
    86c0:	911502a2 	add	x2, x21, #0x540
    86c4:	d350fc20 	lsr	x0, x1, #16
    86c8:	8b000800 	add	x0, x0, x0, lsl #2
    86cc:	f949fc43 	ldr	x3, [x2, #5112]
    86d0:	d37df002 	lsl	x2, x0, #3
    86d4:	8b020060 	add	x0, x3, x2
    86d8:	f9401014 	ldr	x20, [x0, #32]
    86dc:	b4000254 	cbz	x20, 8724 <f23+0x1a0>
    86e0:	38626862 	ldrb	w2, [x3, x2]
    86e4:	7100085f 	cmp	w2, #0x2
    86e8:	54000ec0 	b.eq	88c0 <f23+0x33c>  // b.none
    86ec:	7100045f 	cmp	w2, #0x1
    86f0:	540001a1 	b.ne	8724 <f23+0x1a0>  // b.any
    86f4:	29430002 	ldp	w2, w0, [x0, #24]
    86f8:	92403c21 	and	x1, x1, #0xffff
    86fc:	9b027c21 	mul	x1, x1, x2
    8700:	d360fc21 	lsr	x1, x1, #32
    8704:	eb00003f 	cmp	x1, x0
    8708:	540000e2 	b.cs	8724 <f23+0x1a0>  // b.hs, b.nlast
    870c:	8b010294 	add	x20, x20, x1
    8710:	39400280 	ldrb	w0, [x20]
    8714:	7103fc1f 	cmp	w0, #0xff
    8718:	54001100 	b.eq	8938 <f23+0x3b4>  // b.none
    871c:	52800020 	mov	w0, #0x1                   	// #1
    8720:	39000280 	strb	w0, [x20]
    8724:	b4000253 	cbz	x19, 876c <f23+0x1e8>
    8728:	8b131313 	add	x19, x24, x19, lsl #4
    872c:	aa1803f4 	mov	x20, x24
    8730:	aa1603fa 	mov	x26, x22
    8734:	aa1703f9 	mov	x25, x23
    8738:	f9400723 	ldr	x3, [x25, #8]
    873c:	f9400742 	ldr	x2, [x26, #8]
    8740:	f9400861 	ldr	x1, [x3, #16]
    8744:	f9400840 	ldr	x0, [x2, #16]
    8748:	fd400461 	ldr	d1, [x3, #8]
    874c:	fd400440 	ldr	d0, [x2, #8]
    8750:	97fff2e4 	bl	52e0 <w107>
    8754:	f9000680 	str	x0, [x20, #8]
    8758:	f8010e81 	str	x1, [x20, #16]!
    875c:	f9400b39 	ldr	x25, [x25, #16]
    8760:	f9400b5a 	ldr	x26, [x26, #16]
    8764:	eb14027f 	cmp	x19, x20
    8768:	54fffe81 	b.ne	8738 <f23+0x1b4>  // b.any
    876c:	aa1703e0 	mov	x0, x23
    8770:	97fffe81 	bl	8174 <fwp_drop2>
    8774:	aa1603e0 	mov	x0, x22
    8778:	97fffe7f 	bl	8174 <fwp_drop2>
    877c:	f9400316 	ldr	x22, [x24]
    8780:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8784:	b4000236 	cbz	x22, 87c8 <f23+0x244>
    8788:	fd003be8 	str	d8, [sp, #112]
    878c:	2f00e408 	movi	d8, #0x0
    8790:	91002319 	add	x25, x24, #0x8
    8794:	91004317 	add	x23, x24, #0x10
    8798:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    879c:	d2800013 	mov	x19, #0x0                   	// #0
    87a0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    87a4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    87a8:	91000a73 	add	x19, x19, #0x2
    87ac:	1e602908 	fadd	d8, d8, d0
    87b0:	97fff274 	bl	5180 <f128.constprop.0>
    87b4:	aa0003f4 	mov	x20, x0
    87b8:	eb1302df 	cmp	x22, x19
    87bc:	54ffff28 	b.hi	87a0 <f23+0x21c>  // b.pmore
    87c0:	9e660116 	fmov	x22, d8
    87c4:	fd403be8 	ldr	d8, [sp, #112]
    87c8:	911502b5 	add	x21, x21, #0x540
    87cc:	aa1803e0 	mov	x0, x24
    87d0:	97fff8a4 	bl	6a60 <fwp_drop4>
    87d4:	a900d3f6 	stp	x22, x20, [sp, #8]
    87d8:	910023e1 	add	x1, sp, #0x8
    87dc:	52800000 	mov	w0, #0x0                   	// #0
    87e0:	97fff3f9 	bl	57c4 <fwp_data.part.0.constprop.0>
    87e4:	f949daa1 	ldr	x1, [x21, #5040]
    87e8:	aa0003f3 	mov	x19, x0
    87ec:	f949eea0 	ldr	x0, [x21, #5080]
    87f0:	cb010261 	sub	x1, x19, x1
    87f4:	eb00403f 	cmp	x1, x0, lsl #16
    87f8:	54000322 	b.cs	885c <f23+0x2d8>  // b.hs, b.nlast
    87fc:	d350fc22 	lsr	x2, x1, #16
    8800:	f949fea3 	ldr	x3, [x21, #5112]
    8804:	8b020842 	add	x2, x2, x2, lsl #2
    8808:	d37df042 	lsl	x2, x2, #3
    880c:	8b020060 	add	x0, x3, x2
    8810:	f9401014 	ldr	x20, [x0, #32]
    8814:	b4000254 	cbz	x20, 885c <f23+0x2d8>
    8818:	38626862 	ldrb	w2, [x3, x2]
    881c:	7100085f 	cmp	w2, #0x2
    8820:	540004a0 	b.eq	88b4 <f23+0x330>  // b.none
    8824:	7100045f 	cmp	w2, #0x1
    8828:	540001a1 	b.ne	885c <f23+0x2d8>  // b.any
    882c:	29430002 	ldp	w2, w0, [x0, #24]
    8830:	92403c21 	and	x1, x1, #0xffff
    8834:	9b027c21 	mul	x1, x1, x2
    8838:	d360fc21 	lsr	x1, x1, #32
    883c:	eb00003f 	cmp	x1, x0
    8840:	540000e2 	b.cs	885c <f23+0x2d8>  // b.hs, b.nlast
    8844:	8b010294 	add	x20, x20, x1
    8848:	39400280 	ldrb	w0, [x20]
    884c:	7103fc1f 	cmp	w0, #0xff
    8850:	540007a0 	b.eq	8944 <f23+0x3c0>  // b.none
    8854:	52800020 	mov	w0, #0x1                   	// #1
    8858:	39000280 	strb	w0, [x20]
    885c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8860:	f947f400 	ldr	x0, [x0, #4072]
    8864:	f9400fe2 	ldr	x2, [sp, #24]
    8868:	f9400001 	ldr	x1, [x0]
    886c:	eb010042 	subs	x2, x2, x1
    8870:	d2800001 	mov	x1, #0x0                   	// #0
    8874:	54000721 	b.ne	8958 <f23+0x3d4>  // b.any
    8878:	a9427bfd 	ldp	x29, x30, [sp, #32]
    887c:	aa1303e0 	mov	x0, x19
    8880:	a94353f3 	ldp	x19, x20, [sp, #48]
    8884:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8888:	a94563f7 	ldp	x23, x24, [sp, #80]
    888c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8890:	910203ff 	add	sp, sp, #0x80
    8894:	d65f03c0 	ret
    8898:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    889c:	910ba000 	add	x0, x0, #0x2e8
    88a0:	fd003be8 	str	d8, [sp, #112]
    88a4:	97ffed5b 	bl	3e10 <fwp_trap>
    88a8:	72003c3f 	tst	w1, #0xffff
    88ac:	54ffeca1 	b.ne	8640 <f23+0xbc>  // b.any
    88b0:	17ffff5e 	b	8628 <f23+0xa4>
    88b4:	72003c3f 	tst	w1, #0xffff
    88b8:	54fffd21 	b.ne	885c <f23+0x2d8>  // b.any
    88bc:	17ffffe3 	b	8848 <f23+0x2c4>
    88c0:	72003c3f 	tst	w1, #0xffff
    88c4:	54fff301 	b.ne	8724 <f23+0x1a0>  // b.any
    88c8:	17ffff92 	b	8710 <f23+0x18c>
    88cc:	cb0103e1 	neg	x1, x1
    88d0:	eb02003f 	cmp	x1, x2
    88d4:	540001e3 	b.cc	8910 <f23+0x38c>  // b.lo, b.ul, b.last
    88d8:	52800041 	mov	w1, #0x2                   	// #2
    88dc:	d2800100 	mov	x0, #0x8                   	// #8
    88e0:	97fff0c4 	bl	4bf0 <fwp_heap_alloc>
    88e4:	aa0003f8 	mov	x24, x0
    88e8:	911502a0 	add	x0, x21, #0x540
    88ec:	f900031f 	str	xzr, [x24]
    88f0:	f949d801 	ldr	x1, [x0, #5040]
    88f4:	f949ec00 	ldr	x0, [x0, #5080]
    88f8:	cb010301 	sub	x1, x24, x1
    88fc:	eb00403f 	cmp	x1, x0, lsl #16
    8900:	54000282 	b.cs	8950 <f23+0x3cc>  // b.hs, b.nlast
    8904:	d2800013 	mov	x19, #0x0                   	// #0
    8908:	d2800017 	mov	x23, #0x0                   	// #0
    890c:	17ffff6d 	b	86c0 <f23+0x13c>
    8910:	f949fc62 	ldr	x2, [x3, #5112]
    8914:	d350fc20 	lsr	x0, x1, #16
    8918:	8b000800 	add	x0, x0, x0, lsl #2
    891c:	8b000c42 	add	x2, x2, x0, lsl #3
    8920:	f9401040 	ldr	x0, [x2, #32]
    8924:	b4fffda0 	cbz	x0, 88d8 <f23+0x354>
    8928:	d2800017 	mov	x23, #0x0                   	// #0
    892c:	17ffff33 	b	85f8 <f23+0x74>
    8930:	97ffee6d 	bl	42e4 <fwp_rc_wide_dup>
    8934:	17ffff43 	b	8640 <f23+0xbc>
    8938:	aa1403e0 	mov	x0, x20
    893c:	97ffed55 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8940:	17ffff77 	b	871c <f23+0x198>
    8944:	aa1403e0 	mov	x0, x20
    8948:	97ffed52 	bl	3e90 <fwp_rc_forget_slot.part.0>
    894c:	17ffffc2 	b	8854 <f23+0x2d0>
    8950:	d2800017 	mov	x23, #0x0                   	// #0
    8954:	17ffff86 	b	876c <f23+0x1e8>
    8958:	fd003be8 	str	d8, [sp, #112]
    895c:	97ffe7a5 	bl	27f0 <__stack_chk_fail@plt>

0000000000008960 <fwp_owned_entry23>:
    8960:	f9400000 	ldr	x0, [x0]
    8964:	17ffff08 	b	8584 <f23>
    8968:	d503201f 	nop
    896c:	d503201f 	nop

0000000000008970 <e23>:
    8970:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8974:	910003fd 	mov	x29, sp
    8978:	f9000bf3 	str	x19, [sp, #16]
    897c:	f9400013 	ldr	x19, [x0]
    8980:	aa1303e0 	mov	x0, x19
    8984:	97fff3d8 	bl	58e4 <fwp_rc_share>
    8988:	aa1303e0 	mov	x0, x19
    898c:	97fffefe 	bl	8584 <f23>
    8990:	aa0003f3 	mov	x19, x0
    8994:	97fff3d4 	bl	58e4 <fwp_rc_share>
    8998:	aa1303e0 	mov	x0, x19
    899c:	f9400bf3 	ldr	x19, [sp, #16]
    89a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    89a4:	d65f03c0 	ret
    89a8:	d503201f 	nop
    89ac:	d503201f 	nop

00000000000089b0 <fwp_write>:
    89b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    89b4:	910003fd 	mov	x29, sp
    89b8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    89bc:	f947f484 	ldr	x4, [x4, #4072]
    89c0:	a90153f3 	stp	x19, x20, [sp, #16]
    89c4:	d10943ff 	sub	sp, sp, #0x250
    89c8:	b9400045 	ldr	w5, [x2]
    89cc:	aa0003f4 	mov	x20, x0
    89d0:	f9400080 	ldr	x0, [x4]
    89d4:	f90127e0 	str	x0, [sp, #584]
    89d8:	d2800000 	mov	x0, #0x0                   	// #0
    89dc:	710064bf 	cmp	w5, #0x19
    89e0:	54000408 	b.hi	8a60 <fwp_write+0xb0>  // b.pmore
    89e4:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    89e8:	aa0103f3 	mov	x19, x1
    89ec:	912ac000 	add	x0, x0, #0xab0
    89f0:	f9013bf5 	str	x21, [sp, #624]
    89f4:	f9013ff6 	str	x22, [sp, #632]
    89f8:	f90153fb 	str	x27, [sp, #672]
    89fc:	f90157fc 	str	x28, [sp, #680]
    8a00:	aa0203fc 	mov	x28, x2
    8a04:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8a08:	10000061 	adr	x1, 8a14 <fwp_write+0x64>
    8a0c:	8b20a820 	add	x0, x1, w0, sxth #2
    8a10:	d61f0000 	br	x0
    8a14:	910123e0 	add	x0, sp, #0x48
    8a18:	aa1303e5 	mov	x5, x19
    8a1c:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x180>
    8a20:	aa0003f3 	mov	x19, x0
    8a24:	910da084 	add	x4, x4, #0x368
    8a28:	d2804003 	mov	x3, #0x200                 	// #512
    8a2c:	aa0303e1 	mov	x1, x3
    8a30:	52800042 	mov	w2, #0x2                   	// #2
    8a34:	97ffe74b 	bl	2760 <__snprintf_chk@plt>
    8a38:	aa1303e0 	mov	x0, x19
    8a3c:	97ffe711 	bl	2680 <strlen@plt>
    8a40:	aa1303e1 	mov	x1, x19
    8a44:	aa0003e2 	mov	x2, x0
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	97ffea51 	bl	3390 <buf_put>
    8a50:	f9413bf5 	ldr	x21, [sp, #624]
    8a54:	f9413ff6 	ldr	x22, [sp, #632]
    8a58:	f94153fb 	ldr	x27, [sp, #672]
    8a5c:	f94157fc 	ldr	x28, [sp, #680]
    8a60:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a64:	f947f400 	ldr	x0, [x0, #4072]
    8a68:	f94127e2 	ldr	x2, [sp, #584]
    8a6c:	f9400001 	ldr	x1, [x0]
    8a70:	eb010042 	subs	x2, x2, x1
    8a74:	d2800001 	mov	x1, #0x0                   	// #0
    8a78:	540077c1 	b.ne	9970 <fwp_write+0xfc0>  // b.any
    8a7c:	910943ff 	add	sp, sp, #0x250
    8a80:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a84:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a88:	d65f03c0 	ret
    8a8c:	910123e0 	add	x0, sp, #0x48
    8a90:	aa1303e5 	mov	x5, x19
    8a94:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x180>
    8a98:	aa0003f3 	mov	x19, x0
    8a9c:	910d8084 	add	x4, x4, #0x360
    8aa0:	d2804003 	mov	x3, #0x200                 	// #512
    8aa4:	17ffffe2 	b	8a2c <fwp_write+0x7c>
    8aa8:	71004cbf 	cmp	w5, #0x13
    8aac:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    8ab0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8ab4:	910d4000 	add	x0, x0, #0x350
    8ab8:	910d6021 	add	x1, x1, #0x358
    8abc:	d2800082 	mov	x2, #0x4                   	// #4
    8ac0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8ac4:	aa1403e0 	mov	x0, x20
    8ac8:	f90143f7 	str	x23, [sp, #640]
    8acc:	d2800016 	mov	x22, #0x0                   	// #0
    8ad0:	f90147f8 	str	x24, [sp, #648]
    8ad4:	97ffea2f 	bl	3390 <buf_put>
    8ad8:	f9400260 	ldr	x0, [x19]
    8adc:	f0000017 	adrp	x23, b000 <_IO_stdin_used+0x180>
    8ae0:	d2800015 	mov	x21, #0x0                   	// #0
    8ae4:	910f62f7 	add	x23, x23, #0x3d8
    8ae8:	b40047a0 	cbz	x0, 93dc <fwp_write+0xa2c>
    8aec:	b9400380 	ldr	w0, [x28]
    8af0:	52800003 	mov	w3, #0x0                   	// #0
    8af4:	f9401f82 	ldr	x2, [x28, #56]
    8af8:	71004c1f 	cmp	w0, #0x13
    8afc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8b00:	aa1403e0 	mov	x0, x20
    8b04:	8b010e61 	add	x1, x19, x1, lsl #3
    8b08:	f9400421 	ldr	x1, [x1, #8]
    8b0c:	97ffffa9 	bl	89b0 <fwp_write>
    8b10:	b9400380 	ldr	w0, [x28]
    8b14:	7100481f 	cmp	w0, #0x12
    8b18:	54004b40 	b.eq	9480 <fwp_write+0xad0>  // b.none
    8b1c:	f9400260 	ldr	x0, [x19]
    8b20:	910006b5 	add	x21, x21, #0x1
    8b24:	91000ad6 	add	x22, x22, #0x2
    8b28:	eb15001f 	cmp	x0, x21
    8b2c:	54004589 	b.ls	93dc <fwp_write+0xa2c>  // b.plast
    8b30:	aa1703e1 	mov	x1, x23
    8b34:	aa1403e0 	mov	x0, x20
    8b38:	d2800042 	mov	x2, #0x2                   	// #2
    8b3c:	97ffea15 	bl	3390 <buf_put>
    8b40:	17ffffeb 	b	8aec <fwp_write+0x13c>
    8b44:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8b48:	910e4021 	add	x1, x1, #0x390
    8b4c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b50:	aa1403e0 	mov	x0, x20
    8b54:	91004273 	add	x19, x19, #0x10
    8b58:	97ffea0e 	bl	3390 <buf_put>
    8b5c:	aa1303e0 	mov	x0, x19
    8b60:	97ffe6c8 	bl	2680 <strlen@plt>
    8b64:	aa1303e1 	mov	x1, x19
    8b68:	aa0003e2 	mov	x2, x0
    8b6c:	aa1403e0 	mov	x0, x20
    8b70:	97ffea08 	bl	3390 <buf_put>
    8b74:	528007c3 	mov	w3, #0x3e                  	// #62
    8b78:	aa1403e0 	mov	x0, x20
    8b7c:	91001fe1 	add	x1, sp, #0x7
    8b80:	d2800022 	mov	x2, #0x1                   	// #1
    8b84:	39001fe3 	strb	w3, [sp, #7]
    8b88:	17ffffb1 	b	8a4c <fwp_write+0x9c>
    8b8c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b90:	f947f400 	ldr	x0, [x0, #4072]
    8b94:	f94127e2 	ldr	x2, [sp, #584]
    8b98:	f9400001 	ldr	x1, [x0]
    8b9c:	eb010042 	subs	x2, x2, x1
    8ba0:	d2800001 	mov	x1, #0x0                   	// #0
    8ba4:	540034e1 	b.ne	9240 <fwp_write+0x890>  // b.any
    8ba8:	f9413bf5 	ldr	x21, [sp, #624]
    8bac:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8bb0:	f9413ff6 	ldr	x22, [sp, #632]
    8bb4:	aa1403e0 	mov	x0, x20
    8bb8:	910dc021 	add	x1, x1, #0x370
    8bbc:	d2800142 	mov	x2, #0xa                   	// #10
    8bc0:	f94153fb 	ldr	x27, [sp, #672]
    8bc4:	f94157fc 	ldr	x28, [sp, #680]
    8bc8:	910943ff 	add	sp, sp, #0x250
    8bcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8bd0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8bd4:	17ffe9ef 	b	3390 <buf_put>
    8bd8:	f9400456 	ldr	x22, [x2, #8]
    8bdc:	f90143f7 	str	x23, [sp, #640]
    8be0:	f90147f8 	str	x24, [sp, #648]
    8be4:	b4005b16 	cbz	x22, 9744 <fwp_write+0xd94>
    8be8:	aa1603e0 	mov	x0, x22
    8bec:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8bf0:	910fc021 	add	x1, x1, #0x3f0
    8bf4:	97ffe71f 	bl	2870 <strcmp@plt>
    8bf8:	2a0003f5 	mov	w21, w0
    8bfc:	34005fe0 	cbz	w0, 97f8 <fwp_write+0xe48>
    8c00:	aa1603e0 	mov	x0, x22
    8c04:	97ffe69f 	bl	2680 <strlen@plt>
    8c08:	aa1603e1 	mov	x1, x22
    8c0c:	aa0003e2 	mov	x2, x0
    8c10:	aa1403e0 	mov	x0, x20
    8c14:	97ffe9df 	bl	3390 <buf_put>
    8c18:	52800403 	mov	w3, #0x20                  	// #32
    8c1c:	91001ff5 	add	x21, sp, #0x7
    8c20:	aa1503e1 	mov	x1, x21
    8c24:	aa1403e0 	mov	x0, x20
    8c28:	d2800022 	mov	x2, #0x1                   	// #1
    8c2c:	39001fe3 	strb	w3, [sp, #7]
    8c30:	97ffe9d8 	bl	3390 <buf_put>
    8c34:	52800f63 	mov	w3, #0x7b                  	// #123
    8c38:	aa1403e0 	mov	x0, x20
    8c3c:	aa1503e1 	mov	x1, x21
    8c40:	d2800022 	mov	x2, #0x1                   	// #1
    8c44:	39001fe3 	strb	w3, [sp, #7]
    8c48:	97ffe9d2 	bl	3390 <buf_put>
    8c4c:	b9401380 	ldr	w0, [x28, #16]
    8c50:	52800018 	mov	w24, #0x0                   	// #0
    8c54:	7100001f 	cmp	w0, #0x0
    8c58:	54003aad 	b.le	93ac <fwp_write+0x9fc>
    8c5c:	f9014bf9 	str	x25, [sp, #656]
    8c60:	f0000019 	adrp	x25, b000 <_IO_stdin_used+0x180>
    8c64:	91106339 	add	x25, x25, #0x418
    8c68:	f9014ffa 	str	x26, [sp, #664]
    8c6c:	f000001a 	adrp	x26, b000 <_IO_stdin_used+0x180>
    8c70:	910f635a 	add	x26, x26, #0x3d8
    8c74:	91002276 	add	x22, x19, #0x8
    8c78:	d2800013 	mov	x19, #0x0                   	// #0
    8c7c:	b5003e93 	cbnz	x19, 944c <fwp_write+0xa9c>
    8c80:	d37df277 	lsl	x23, x19, #3
    8c84:	34003cb8 	cbz	w24, 9418 <fwp_write+0xa68>
    8c88:	f9401382 	ldr	x2, [x28, #32]
    8c8c:	aa1403e0 	mov	x0, x20
    8c90:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8c94:	52800003 	mov	w3, #0x0                   	// #0
    8c98:	f8776842 	ldr	x2, [x2, x23]
    8c9c:	91000673 	add	x19, x19, #0x1
    8ca0:	97ffff44 	bl	89b0 <fwp_write>
    8ca4:	b9401380 	ldr	w0, [x28, #16]
    8ca8:	6b13001f 	cmp	w0, w19
    8cac:	54fffe8c 	b.gt	8c7c <fwp_write+0x2cc>
    8cb0:	f9414bf9 	ldr	x25, [sp, #656]
    8cb4:	f9414ffa 	ldr	x26, [sp, #664]
    8cb8:	340037b8 	cbz	w24, 93ac <fwp_write+0x9fc>
    8cbc:	52800523 	mov	w3, #0x29                  	// #41
    8cc0:	aa1503e1 	mov	x1, x21
    8cc4:	aa1403e0 	mov	x0, x20
    8cc8:	d2800022 	mov	x2, #0x1                   	// #1
    8ccc:	39001fe3 	strb	w3, [sp, #7]
    8cd0:	97ffe9b0 	bl	3390 <buf_put>
    8cd4:	f9413bf5 	ldr	x21, [sp, #624]
    8cd8:	f9413ff6 	ldr	x22, [sp, #632]
    8cdc:	f94143f7 	ldr	x23, [sp, #640]
    8ce0:	f94147f8 	ldr	x24, [sp, #648]
    8ce4:	f94153fb 	ldr	x27, [sp, #672]
    8ce8:	f94157fc 	ldr	x28, [sp, #680]
    8cec:	17ffff5d 	b	8a60 <fwp_write+0xb0>
    8cf0:	b9404855 	ldr	w21, [x2, #72]
    8cf4:	aa1403e0 	mov	x0, x20
    8cf8:	93407eb6 	sxtw	x22, w21
    8cfc:	91000ac1 	add	x1, x22, #0x2
    8d00:	97ffe971 	bl	32c4 <buf_grow>
    8d04:	a9400281 	ldp	x1, x0, [x20]
    8d08:	528e8603 	mov	w3, #0x7430                	// #29744
    8d0c:	78206823 	strh	w3, [x1, x0]
    8d10:	8b000022 	add	x2, x1, x0
    8d14:	710002bf 	cmp	w21, #0x0
    8d18:	540036cd 	b.le	93f0 <fwp_write+0xa40>
    8d1c:	110006a3 	add	w3, w21, #0x1
    8d20:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8d24:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8d28:	91000449 	add	x9, x2, #0x1
    8d2c:	8b23c043 	add	x3, x2, w3, sxtw
    8d30:	f28aaac6 	movk	x6, #0x5556
    8d34:	f2955568 	movk	x8, #0xaaab
    8d38:	1400000d 	b	8d6c <fwp_write+0x3bc>
    8d3c:	d2800021 	mov	x1, #0x1                   	// #1
    8d40:	528005a5 	mov	w5, #0x2d                  	// #45
    8d44:	f100001f 	cmp	x0, #0x0
    8d48:	9b467e60 	smulh	x0, x19, x6
    8d4c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8d50:	381ff465 	strb	w5, [x3], #-1
    8d54:	cb040000 	sub	x0, x0, x4
    8d58:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8d5c:	cb020000 	sub	x0, x0, x2
    8d60:	8b010013 	add	x19, x0, x1
    8d64:	eb03013f 	cmp	x9, x3
    8d68:	54003440 	b.eq	93f0 <fwp_write+0xa40>  // b.none
    8d6c:	9b467e60 	smulh	x0, x19, x6
    8d70:	937ffe64 	asr	x4, x19, #63
    8d74:	52800605 	mov	w5, #0x30                  	// #48
    8d78:	cb040000 	sub	x0, x0, x4
    8d7c:	8b000400 	add	x0, x0, x0, lsl #1
    8d80:	cb000260 	sub	x0, x19, x0
    8d84:	91000c01 	add	x1, x0, #0x3
    8d88:	9bc87c22 	umulh	x2, x1, x8
    8d8c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8d90:	8b4204e2 	add	x2, x7, x2, lsr #1
    8d94:	eb020021 	subs	x1, x1, x2
    8d98:	54fffd60 	b.eq	8d44 <fwp_write+0x394>  // b.none
    8d9c:	f100043f 	cmp	x1, #0x1
    8da0:	54fffce1 	b.ne	8d3c <fwp_write+0x38c>  // b.any
    8da4:	d2800001 	mov	x1, #0x0                   	// #0
    8da8:	52800565 	mov	w5, #0x2b                  	// #43
    8dac:	17ffffe6 	b	8d44 <fwp_write+0x394>
    8db0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8db4:	f947f400 	ldr	x0, [x0, #4072]
    8db8:	f94127e2 	ldr	x2, [sp, #584]
    8dbc:	f9400001 	ldr	x1, [x0]
    8dc0:	eb010042 	subs	x2, x2, x1
    8dc4:	d2800001 	mov	x1, #0x0                   	// #0
    8dc8:	540023c1 	b.ne	9240 <fwp_write+0x890>  // b.any
    8dcc:	f9413bf5 	ldr	x21, [sp, #624]
    8dd0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8dd4:	f9413ff6 	ldr	x22, [sp, #632]
    8dd8:	aa1403e0 	mov	x0, x20
    8ddc:	910e0021 	add	x1, x1, #0x380
    8de0:	d2800102 	mov	x2, #0x8                   	// #8
    8de4:	17ffff77 	b	8bc0 <fwp_write+0x210>
    8de8:	aa1403e0 	mov	x0, x20
    8dec:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8df0:	d28000c2 	mov	x2, #0x6                   	// #6
    8df4:	910f8021 	add	x1, x1, #0x3e0
    8df8:	97ffe966 	bl	3390 <buf_put>
    8dfc:	d2800015 	mov	x21, #0x0                   	// #0
    8e00:	f9400263 	ldr	x3, [x19]
    8e04:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8e08:	54002c60 	b.eq	9394 <fwp_write+0x9e4>  // b.none
    8e0c:	f9401f82 	ldr	x2, [x28, #56]
    8e10:	f90143f7 	str	x23, [sp, #640]
    8e14:	f90147f8 	str	x24, [sp, #648]
    8e18:	d2800857 	mov	x23, #0x42                  	// #66
    8e1c:	f9014bf9 	str	x25, [sp, #656]
    8e20:	f0000016 	adrp	x22, b000 <_IO_stdin_used+0x180>
    8e24:	f9014ffa 	str	x26, [sp, #664]
    8e28:	910f62d6 	add	x22, x22, #0x3d8
    8e2c:	d2800038 	mov	x24, #0x1                   	// #1
    8e30:	f2a18017 	movk	x23, #0xc00, lsl #16
    8e34:	d2809099 	mov	x25, #0x484                 	// #1156
    8e38:	b40004a2 	cbz	x2, 8ecc <fwp_write+0x51c>
    8e3c:	b9400040 	ldr	w0, [x2]
    8e40:	7100701f 	cmp	w0, #0x1c
    8e44:	540042c0 	b.eq	969c <fwp_write+0xcec>  // b.none
    8e48:	71006c1f 	cmp	w0, #0x1b
    8e4c:	54000408 	b.hi	8ecc <fwp_write+0x51c>  // b.pmore
    8e50:	9ac02301 	lsl	x1, x24, x0
    8e54:	ea17003f 	tst	x1, x23
    8e58:	540036a1 	b.ne	952c <fwp_write+0xb7c>  // b.any
    8e5c:	ea19003f 	tst	x1, x25
    8e60:	54003521 	b.ne	9504 <fwp_write+0xb54>  // b.any
    8e64:	d2800424 	mov	x4, #0x21                  	// #33
    8e68:	ea04003f 	tst	x1, x4
    8e6c:	54000300 	b.eq	8ecc <fwp_write+0x51c>  // b.none
    8e70:	b7f849c3 	tbnz	x3, #63, 97a8 <fwp_write+0xdf8>
    8e74:	91002261 	add	x1, x19, #0x8
    8e78:	8b150021 	add	x1, x1, x21
    8e7c:	39400021 	ldrb	w1, [x1]
    8e80:	7100001f 	cmp	w0, #0x0
    8e84:	93401c23 	sxtb	x3, w1
    8e88:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e8c:	d503201f 	nop
    8e90:	aa1403e0 	mov	x0, x20
    8e94:	52800003 	mov	w3, #0x0                   	// #0
    8e98:	97fffec6 	bl	89b0 <fwp_write>
    8e9c:	910006b5 	add	x21, x21, #0x1
    8ea0:	f9400260 	ldr	x0, [x19]
    8ea4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8ea8:	eb0002bf 	cmp	x21, x0
    8eac:	540026c2 	b.cs	9384 <fwp_write+0x9d4>  // b.hs, b.nlast
    8eb0:	d2800042 	mov	x2, #0x2                   	// #2
    8eb4:	aa1603e1 	mov	x1, x22
    8eb8:	aa1403e0 	mov	x0, x20
    8ebc:	97ffe935 	bl	3390 <buf_put>
    8ec0:	f9401f82 	ldr	x2, [x28, #56]
    8ec4:	f9400263 	ldr	x3, [x19]
    8ec8:	b5fffba2 	cbnz	x2, 8e3c <fwp_write+0x48c>
    8ecc:	d37df2a0 	lsl	x0, x21, #3
    8ed0:	b7f83f03 	tbnz	x3, #63, 96b0 <fwp_write+0xd00>
    8ed4:	91002261 	add	x1, x19, #0x8
    8ed8:	8b000020 	add	x0, x1, x0
    8edc:	f9400001 	ldr	x1, [x0]
    8ee0:	17ffffec 	b	8e90 <fwp_write+0x4e0>
    8ee4:	a9400e62 	ldp	x2, x3, [x19]
    8ee8:	b7f83ca3 	tbnz	x3, #63, 967c <fwp_write+0xccc>
    8eec:	910123f5 	add	x21, sp, #0x48
    8ef0:	aa1503e0 	mov	x0, x21
    8ef4:	97ffe7ab 	bl	2da0 <fwp_fmt_u128>
    8ef8:	aa1503e0 	mov	x0, x21
    8efc:	97ffe5e1 	bl	2680 <strlen@plt>
    8f00:	aa1503e1 	mov	x1, x21
    8f04:	aa0003e2 	mov	x2, x0
    8f08:	17fffed0 	b	8a48 <fwp_write+0x98>
    8f0c:	fd015be8 	str	d8, [sp, #688]
    8f10:	1e270268 	fmov	s8, w19
    8f14:	fd015fe9 	str	d9, [sp, #696]
    8f18:	1e282100 	fcmp	s8, s8
    8f1c:	54004d26 	b.vs	98c0 <fwp_write+0xf10>
    8f20:	1e20c101 	fabs	s1, s8
    8f24:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8f28:	1e270000 	fmov	s0, w0
    8f2c:	1e202020 	fcmp	s1, s0
    8f30:	54002c0d 	b.le	94b0 <fwp_write+0xb00>
    8f34:	1e202118 	fcmpe	s8, #0.0
    8f38:	d0000002 	adrp	x2, a000 <fwp_main_thread+0x660>
    8f3c:	913a8042 	add	x2, x2, #0xea0
    8f40:	910123f5 	add	x21, sp, #0x48
    8f44:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    8f48:	910cc021 	add	x1, x1, #0x330
    8f4c:	aa1503e0 	mov	x0, x21
    8f50:	9a81c041 	csel	x1, x2, x1, gt
    8f54:	97ffe677 	bl	2930 <strcpy@plt>
    8f58:	aa1503e0 	mov	x0, x21
    8f5c:	97ffe5c9 	bl	2680 <strlen@plt>
    8f60:	aa1503e1 	mov	x1, x21
    8f64:	aa0003e2 	mov	x2, x0
    8f68:	aa1403e0 	mov	x0, x20
    8f6c:	97ffe909 	bl	3390 <buf_put>
    8f70:	f9413bf5 	ldr	x21, [sp, #624]
    8f74:	f9413ff6 	ldr	x22, [sp, #632]
    8f78:	f94153fb 	ldr	x27, [sp, #672]
    8f7c:	f94157fc 	ldr	x28, [sp, #680]
    8f80:	fd415be8 	ldr	d8, [sp, #688]
    8f84:	fd415fe9 	ldr	d9, [sp, #696]
    8f88:	17fffeb6 	b	8a60 <fwp_write+0xb0>
    8f8c:	f9400276 	ldr	x22, [x19]
    8f90:	34002e03 	cbz	w3, 9550 <fwp_write+0xba0>
    8f94:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8f98:	f947f400 	ldr	x0, [x0, #4072]
    8f9c:	f94127e2 	ldr	x2, [sp, #584]
    8fa0:	f9400001 	ldr	x1, [x0]
    8fa4:	eb010042 	subs	x2, x2, x1
    8fa8:	d2800001 	mov	x1, #0x0                   	// #0
    8fac:	540014a1 	b.ne	9240 <fwp_write+0x890>  // b.any
    8fb0:	aa1603e2 	mov	x2, x22
    8fb4:	91002261 	add	x1, x19, #0x8
    8fb8:	f9413bf5 	ldr	x21, [sp, #624]
    8fbc:	aa1403e0 	mov	x0, x20
    8fc0:	f9413ff6 	ldr	x22, [sp, #632]
    8fc4:	17fffeff 	b	8bc0 <fwp_write+0x210>
    8fc8:	fd015be8 	str	d8, [sp, #688]
    8fcc:	9e670268 	fmov	d8, x19
    8fd0:	fd015fe9 	str	d9, [sp, #696]
    8fd4:	1e682100 	fcmp	d8, d8
    8fd8:	54004746 	b.vs	98c0 <fwp_write+0xf10>
    8fdc:	1e60c101 	fabs	d1, d8
    8fe0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8fe4:	9e670000 	fmov	d0, x0
    8fe8:	910123f5 	add	x21, sp, #0x48
    8fec:	52800033 	mov	w19, #0x1                   	// #1
    8ff0:	1e602020 	fcmp	d1, d0
    8ff4:	540001ad 	b.le	9028 <fwp_write+0x678>
    8ff8:	1e602118 	fcmpe	d8, #0.0
    8ffc:	d0000002 	adrp	x2, a000 <fwp_main_thread+0x660>
    9000:	913a8042 	add	x2, x2, #0xea0
    9004:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    9008:	910cc021 	add	x1, x1, #0x330
    900c:	aa1503e0 	mov	x0, x21
    9010:	9a81c041 	csel	x1, x2, x1, gt
    9014:	97ffe647 	bl	2930 <strcpy@plt>
    9018:	17ffffd0 	b	8f58 <fwp_write+0x5a8>
    901c:	11000673 	add	w19, w19, #0x1
    9020:	71004a7f 	cmp	w19, #0x12
    9024:	54003860 	b.eq	9730 <fwp_write+0xd80>  // b.none
    9028:	1e604100 	fmov	d0, d8
    902c:	2a1303e1 	mov	w1, w19
    9030:	aa1503e0 	mov	x0, x21
    9034:	97ffe933 	bl	3500 <fwp_format_g.constprop.0>
    9038:	aa1503e0 	mov	x0, x21
    903c:	d2800001 	mov	x1, #0x0                   	// #0
    9040:	97ffe5a4 	bl	26d0 <strtod@plt>
    9044:	1e602100 	fcmp	d8, d0
    9048:	54fffea1 	b.ne	901c <fwp_write+0x66c>  // b.any
    904c:	aa1503e0 	mov	x0, x21
    9050:	97ffe909 	bl	3474 <fwp_finish_float>
    9054:	17ffffc1 	b	8f58 <fwp_write+0x5a8>
    9058:	a9400e62 	ldp	x2, x3, [x19]
    905c:	910123f3 	add	x19, sp, #0x48
    9060:	aa1303e0 	mov	x0, x19
    9064:	97ffe74f 	bl	2da0 <fwp_fmt_u128>
    9068:	17fffe74 	b	8a38 <fwp_write+0x88>
    906c:	f90143f7 	str	x23, [sp, #640]
    9070:	f90147f8 	str	x24, [sp, #648]
    9074:	2a1303f8 	mov	w24, w19
    9078:	f9014bf9 	str	x25, [sp, #656]
    907c:	f9014ffa 	str	x26, [sp, #664]
    9080:	f13ffe7f 	cmp	x19, #0xfff
    9084:	54000049 	b.ls	908c <fwp_write+0x6dc>  // b.plast
    9088:	b9400278 	ldr	w24, [x19]
    908c:	f9400f80 	ldr	x0, [x28, #24]
    9090:	2a1803f5 	mov	w21, w24
    9094:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9098:	d37ef6b9 	lsl	x25, x21, #2
    909c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    90a0:	aa1603e0 	mov	x0, x22
    90a4:	97ffe577 	bl	2680 <strlen@plt>
    90a8:	aa1603e1 	mov	x1, x22
    90ac:	aa0003e2 	mov	x2, x0
    90b0:	aa1403e0 	mov	x0, x20
    90b4:	97ffe8b7 	bl	3390 <buf_put>
    90b8:	f9401780 	ldr	x0, [x28, #40]
    90bc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    90c0:	7100001f 	cmp	w0, #0x0
    90c4:	5400068d 	b.le	9194 <fwp_write+0x7e4>
    90c8:	91002276 	add	x22, x19, #0x8
    90cc:	91001ff5 	add	x21, sp, #0x7
    90d0:	d280001b 	mov	x27, #0x0                   	// #0
    90d4:	5280041a 	mov	w26, #0x20                  	// #32
    90d8:	f9401b80 	ldr	x0, [x28, #48]
    90dc:	aa1503e1 	mov	x1, x21
    90e0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    90e4:	d2800022 	mov	x2, #0x1                   	// #1
    90e8:	f8786803 	ldr	x3, [x0, x24]
    90ec:	aa1403e0 	mov	x0, x20
    90f0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    90f4:	39001ffa 	strb	w26, [sp, #7]
    90f8:	97ffe8a6 	bl	3390 <buf_put>
    90fc:	f13ffeff 	cmp	x23, #0xfff
    9100:	b9400261 	ldr	w1, [x19]
    9104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9108:	7100383f 	cmp	w1, #0xe
    910c:	54000160 	b.eq	9138 <fwp_write+0x788>  // b.none
    9110:	7100403f 	cmp	w1, #0x10
    9114:	54001a60 	b.eq	9460 <fwp_write+0xab0>  // b.none
    9118:	7100283f 	cmp	w1, #0xa
    911c:	54002aa0 	b.eq	9670 <fwp_write+0xcc0>  // b.none
    9120:	540014ac 	b.gt	93b4 <fwp_write+0xa04>
    9124:	71000c3f 	cmp	w1, #0x3
    9128:	540029ac 	b.gt	965c <fwp_write+0xcac>
    912c:	d37ffee0 	lsr	x0, x23, #63
    9130:	37f814a1 	tbnz	w1, #31, 93c4 <fwp_write+0xa14>
    9134:	d503201f 	nop
    9138:	34001460 	cbz	w0, 93c4 <fwp_write+0xa14>
    913c:	52800503 	mov	w3, #0x28                  	// #40
    9140:	aa1503e1 	mov	x1, x21
    9144:	aa1403e0 	mov	x0, x20
    9148:	d2800022 	mov	x2, #0x1                   	// #1
    914c:	39001fe3 	strb	w3, [sp, #7]
    9150:	97ffe890 	bl	3390 <buf_put>
    9154:	aa1303e2 	mov	x2, x19
    9158:	aa1703e1 	mov	x1, x23
    915c:	aa1403e0 	mov	x0, x20
    9160:	52800003 	mov	w3, #0x0                   	// #0
    9164:	97fffe13 	bl	89b0 <fwp_write>
    9168:	52800523 	mov	w3, #0x29                  	// #41
    916c:	aa1503e1 	mov	x1, x21
    9170:	aa1403e0 	mov	x0, x20
    9174:	d2800022 	mov	x2, #0x1                   	// #1
    9178:	39001fe3 	strb	w3, [sp, #7]
    917c:	97ffe885 	bl	3390 <buf_put>
    9180:	f9401780 	ldr	x0, [x28, #40]
    9184:	9100077b 	add	x27, x27, #0x1
    9188:	b8796800 	ldr	w0, [x0, x25]
    918c:	6b1b001f 	cmp	w0, w27
    9190:	54fffa4c 	b.gt	90d8 <fwp_write+0x728>
    9194:	f9413bf5 	ldr	x21, [sp, #624]
    9198:	f9413ff6 	ldr	x22, [sp, #632]
    919c:	f94143f7 	ldr	x23, [sp, #640]
    91a0:	f94147f8 	ldr	x24, [sp, #648]
    91a4:	f9414bf9 	ldr	x25, [sp, #656]
    91a8:	f9414ffa 	ldr	x26, [sp, #664]
    91ac:	f94153fb 	ldr	x27, [sp, #672]
    91b0:	f94157fc 	ldr	x28, [sp, #680]
    91b4:	17fffe2b 	b	8a60 <fwp_write+0xb0>
    91b8:	52800783 	mov	w3, #0x3c                  	// #60
    91bc:	91001ff3 	add	x19, sp, #0x7
    91c0:	aa1303e1 	mov	x1, x19
    91c4:	d2800022 	mov	x2, #0x1                   	// #1
    91c8:	aa1403e0 	mov	x0, x20
    91cc:	39001fe3 	strb	w3, [sp, #7]
    91d0:	97ffe870 	bl	3390 <buf_put>
    91d4:	f9400795 	ldr	x21, [x28, #8]
    91d8:	aa1503e0 	mov	x0, x21
    91dc:	97ffe529 	bl	2680 <strlen@plt>
    91e0:	aa1503e1 	mov	x1, x21
    91e4:	aa0003e2 	mov	x2, x0
    91e8:	aa1403e0 	mov	x0, x20
    91ec:	97ffe869 	bl	3390 <buf_put>
    91f0:	528007c3 	mov	w3, #0x3e                  	// #62
    91f4:	aa1303e1 	mov	x1, x19
    91f8:	aa1403e0 	mov	x0, x20
    91fc:	d2800022 	mov	x2, #0x1                   	// #1
    9200:	39001fe3 	strb	w3, [sp, #7]
    9204:	17fffe12 	b	8a4c <fwp_write+0x9c>
    9208:	f100067f 	cmp	x19, #0x1
    920c:	540025a0 	b.eq	96c0 <fwp_write+0xd10>  // b.none
    9210:	b100067f 	cmn	x19, #0x1
    9214:	54002bc0 	b.eq	978c <fwp_write+0xddc>  // b.none
    9218:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    921c:	910ce021 	add	x1, x1, #0x338
    9220:	d2800022 	mov	x2, #0x1                   	// #1
    9224:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9228:	f947f400 	ldr	x0, [x0, #4072]
    922c:	f94127e4 	ldr	x4, [sp, #584]
    9230:	f9400003 	ldr	x3, [x0]
    9234:	eb030084 	subs	x4, x4, x3
    9238:	d2800003 	mov	x3, #0x0                   	// #0
    923c:	54ffebe0 	b.eq	8fb8 <fwp_write+0x608>  // b.none
    9240:	f90143f7 	str	x23, [sp, #640]
    9244:	f90147f8 	str	x24, [sp, #648]
    9248:	f9014bf9 	str	x25, [sp, #656]
    924c:	f9014ffa 	str	x26, [sp, #664]
    9250:	fd015be8 	str	d8, [sp, #688]
    9254:	fd015fe9 	str	d9, [sp, #696]
    9258:	97ffe566 	bl	27f0 <__stack_chk_fail@plt>
    925c:	52800b63 	mov	w3, #0x5b                  	// #91
    9260:	91001ff5 	add	x21, sp, #0x7
    9264:	aa1503e1 	mov	x1, x21
    9268:	aa1403e0 	mov	x0, x20
    926c:	d2800022 	mov	x2, #0x1                   	// #1
    9270:	d0000016 	adrp	x22, b000 <_IO_stdin_used+0x180>
    9274:	910f62d6 	add	x22, x22, #0x3d8
    9278:	39001fe3 	strb	w3, [sp, #7]
    927c:	97ffe845 	bl	3390 <buf_put>
    9280:	b4000273 	cbz	x19, 92cc <fwp_write+0x91c>
    9284:	f9400661 	ldr	x1, [x19, #8]
    9288:	aa1403e0 	mov	x0, x20
    928c:	f9401f82 	ldr	x2, [x28, #56]
    9290:	52800003 	mov	w3, #0x0                   	// #0
    9294:	97fffdc7 	bl	89b0 <fwp_write>
    9298:	f9400a73 	ldr	x19, [x19, #16]
    929c:	b4000193 	cbz	x19, 92cc <fwp_write+0x91c>
    92a0:	aa1603e1 	mov	x1, x22
    92a4:	aa1403e0 	mov	x0, x20
    92a8:	d2800042 	mov	x2, #0x2                   	// #2
    92ac:	97ffe839 	bl	3390 <buf_put>
    92b0:	f9400661 	ldr	x1, [x19, #8]
    92b4:	aa1403e0 	mov	x0, x20
    92b8:	f9401f82 	ldr	x2, [x28, #56]
    92bc:	52800003 	mov	w3, #0x0                   	// #0
    92c0:	97fffdbc 	bl	89b0 <fwp_write>
    92c4:	f9400a73 	ldr	x19, [x19, #16]
    92c8:	b5fffed3 	cbnz	x19, 92a0 <fwp_write+0x8f0>
    92cc:	52800ba3 	mov	w3, #0x5d                  	// #93
    92d0:	aa1503e1 	mov	x1, x21
    92d4:	aa1403e0 	mov	x0, x20
    92d8:	d2800022 	mov	x2, #0x1                   	// #1
    92dc:	39001fe3 	strb	w3, [sp, #7]
    92e0:	17fffddb 	b	8a4c <fwp_write+0x9c>
    92e4:	aa1403e0 	mov	x0, x20
    92e8:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    92ec:	d28000c2 	mov	x2, #0x6                   	// #6
    92f0:	910f2021 	add	x1, x1, #0x3c8
    92f4:	97ffe827 	bl	3390 <buf_put>
    92f8:	f9400260 	ldr	x0, [x19]
    92fc:	b40004c0 	cbz	x0, 9394 <fwp_write+0x9e4>
    9300:	910123f5 	add	x21, sp, #0x48
    9304:	91002276 	add	x22, x19, #0x8
    9308:	f90143f7 	str	x23, [sp, #640]
    930c:	d2800017 	mov	x23, #0x0                   	// #0
    9310:	f90147f8 	str	x24, [sp, #648]
    9314:	d0000018 	adrp	x24, b000 <_IO_stdin_used+0x180>
    9318:	910f4318 	add	x24, x24, #0x3d0
    931c:	f9014bf9 	str	x25, [sp, #656]
    9320:	d0000019 	adrp	x25, b000 <_IO_stdin_used+0x180>
    9324:	910f6339 	add	x25, x25, #0x3d8
    9328:	f9014ffa 	str	x26, [sp, #664]
    932c:	14000005 	b	9340 <fwp_write+0x990>
    9330:	aa1903e1 	mov	x1, x25
    9334:	aa1403e0 	mov	x0, x20
    9338:	d2800042 	mov	x2, #0x2                   	// #2
    933c:	97ffe815 	bl	3390 <buf_put>
    9340:	38776ac5 	ldrb	w5, [x22, x23]
    9344:	d2804003 	mov	x3, #0x200                 	// #512
    9348:	aa1803e4 	mov	x4, x24
    934c:	aa0303e1 	mov	x1, x3
    9350:	52800042 	mov	w2, #0x2                   	// #2
    9354:	aa1503e0 	mov	x0, x21
    9358:	910006f7 	add	x23, x23, #0x1
    935c:	97ffe501 	bl	2760 <__snprintf_chk@plt>
    9360:	aa1503e0 	mov	x0, x21
    9364:	97ffe4c7 	bl	2680 <strlen@plt>
    9368:	aa1503e1 	mov	x1, x21
    936c:	aa0003e2 	mov	x2, x0
    9370:	aa1403e0 	mov	x0, x20
    9374:	97ffe807 	bl	3390 <buf_put>
    9378:	f9400260 	ldr	x0, [x19]
    937c:	eb17001f 	cmp	x0, x23
    9380:	54fffd88 	b.hi	9330 <fwp_write+0x980>  // b.pmore
    9384:	f94143f7 	ldr	x23, [sp, #640]
    9388:	f94147f8 	ldr	x24, [sp, #648]
    938c:	f9414bf9 	ldr	x25, [sp, #656]
    9390:	f9414ffa 	ldr	x26, [sp, #664]
    9394:	52800ba3 	mov	w3, #0x5d                  	// #93
    9398:	aa1403e0 	mov	x0, x20
    939c:	91001fe1 	add	x1, sp, #0x7
    93a0:	d2800022 	mov	x2, #0x1                   	// #1
    93a4:	39001fe3 	strb	w3, [sp, #7]
    93a8:	17fffda9 	b	8a4c <fwp_write+0x9c>
    93ac:	52800fa3 	mov	w3, #0x7d                  	// #125
    93b0:	17fffe44 	b	8cc0 <fwp_write+0x310>
    93b4:	f10002ff 	cmp	x23, #0x0
    93b8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    93bc:	71002c3f 	cmp	w1, #0xb
    93c0:	54ffebc0 	b.eq	9138 <fwp_write+0x788>  // b.none
    93c4:	aa1303e2 	mov	x2, x19
    93c8:	aa1703e1 	mov	x1, x23
    93cc:	aa1403e0 	mov	x0, x20
    93d0:	52800003 	mov	w3, #0x0                   	// #0
    93d4:	97fffd77 	bl	89b0 <fwp_write>
    93d8:	17ffff6a 	b	9180 <fwp_write+0x7d0>
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	91001fe1 	add	x1, sp, #0x7
    93e4:	52800fa3 	mov	w3, #0x7d                  	// #125
    93e8:	d2800022 	mov	x2, #0x1                   	// #1
    93ec:	17fffe38 	b	8ccc <fwp_write+0x31c>
    93f0:	a9400281 	ldp	x1, x0, [x20]
    93f4:	91000800 	add	x0, x0, #0x2
    93f8:	8b160000 	add	x0, x0, x22
    93fc:	f9000680 	str	x0, [x20, #8]
    9400:	3820683f 	strb	wzr, [x1, x0]
    9404:	f9413bf5 	ldr	x21, [sp, #624]
    9408:	f9413ff6 	ldr	x22, [sp, #632]
    940c:	f94153fb 	ldr	x27, [sp, #672]
    9410:	f94157fc 	ldr	x28, [sp, #680]
    9414:	17fffd93 	b	8a60 <fwp_write+0xb0>
    9418:	f9400f80 	ldr	x0, [x28, #24]
    941c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9420:	aa1b03e0 	mov	x0, x27
    9424:	97ffe497 	bl	2680 <strlen@plt>
    9428:	aa1b03e1 	mov	x1, x27
    942c:	aa0003e2 	mov	x2, x0
    9430:	aa1403e0 	mov	x0, x20
    9434:	97ffe7d7 	bl	3390 <buf_put>
    9438:	aa1903e1 	mov	x1, x25
    943c:	aa1403e0 	mov	x0, x20
    9440:	d2800062 	mov	x2, #0x3                   	// #3
    9444:	97ffe7d3 	bl	3390 <buf_put>
    9448:	17fffe10 	b	8c88 <fwp_write+0x2d8>
    944c:	aa1a03e1 	mov	x1, x26
    9450:	aa1403e0 	mov	x0, x20
    9454:	d2800042 	mov	x2, #0x2                   	// #2
    9458:	97ffe7ce 	bl	3390 <buf_put>
    945c:	17fffe09 	b	8c80 <fwp_write+0x2d0>
    9460:	f9400660 	ldr	x0, [x19, #8]
    9464:	b4fffb00 	cbz	x0, 93c4 <fwp_write+0xa14>
    9468:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    946c:	910fc021 	add	x1, x1, #0x3f0
    9470:	97ffe500 	bl	2870 <strcmp@plt>
    9474:	7100001f 	cmp	w0, #0x0
    9478:	1a9f07e0 	cset	w0, ne	// ne = any
    947c:	17ffff2f 	b	9138 <fwp_write+0x788>
    9480:	aa1403e0 	mov	x0, x20
    9484:	d2800042 	mov	x2, #0x2                   	// #2
    9488:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    948c:	910fa021 	add	x1, x1, #0x3e8
    9490:	97ffe7c0 	bl	3390 <buf_put>
    9494:	91004261 	add	x1, x19, #0x10
    9498:	aa1403e0 	mov	x0, x20
    949c:	f9402382 	ldr	x2, [x28, #64]
    94a0:	52800003 	mov	w3, #0x0                   	// #0
    94a4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    94a8:	97fffd42 	bl	89b0 <fwp_write>
    94ac:	17fffd9c 	b	8b1c <fwp_write+0x16c>
    94b0:	1e22c109 	fcvt	d9, s8
    94b4:	910123f5 	add	x21, sp, #0x48
    94b8:	52800033 	mov	w19, #0x1                   	// #1
    94bc:	d503201f 	nop
    94c0:	1e604120 	fmov	d0, d9
    94c4:	2a1303e1 	mov	w1, w19
    94c8:	aa1503e0 	mov	x0, x21
    94cc:	97ffe80d 	bl	3500 <fwp_format_g.constprop.0>
    94d0:	aa1503e0 	mov	x0, x21
    94d4:	d2800001 	mov	x1, #0x0                   	// #0
    94d8:	97ffe4f2 	bl	28a0 <strtof@plt>
    94dc:	1e202100 	fcmp	s8, s0
    94e0:	54ffdb60 	b.eq	904c <fwp_write+0x69c>  // b.none
    94e4:	11000673 	add	w19, w19, #0x1
    94e8:	71002a7f 	cmp	w19, #0xa
    94ec:	54fffea1 	b.ne	94c0 <fwp_write+0xb10>  // b.any
    94f0:	1e604120 	fmov	d0, d9
    94f4:	aa1503e0 	mov	x0, x21
    94f8:	52800121 	mov	w1, #0x9                   	// #9
    94fc:	97ffe801 	bl	3500 <fwp_format_g.constprop.0>
    9500:	17fffed3 	b	904c <fwp_write+0x69c>
    9504:	d37ef6a1 	lsl	x1, x21, #2
    9508:	b7f81563 	tbnz	x3, #63, 97b4 <fwp_write+0xe04>
    950c:	91002263 	add	x3, x19, #0x8
    9510:	8b010061 	add	x1, x3, x1
    9514:	b9400023 	ldr	w3, [x1]
    9518:	7100081f 	cmp	w0, #0x2
    951c:	2a0303e1 	mov	w1, w3
    9520:	93407c63 	sxtw	x3, w3
    9524:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9528:	17fffe5a 	b	8e90 <fwp_write+0x4e0>
    952c:	d37ffaa1 	lsl	x1, x21, #1
    9530:	b7f81363 	tbnz	x3, #63, 979c <fwp_write+0xdec>
    9534:	91002263 	add	x3, x19, #0x8
    9538:	8b010061 	add	x1, x3, x1
    953c:	79400021 	ldrh	w1, [x1]
    9540:	7100041f 	cmp	w0, #0x1
    9544:	93403c23 	sxth	x3, w1
    9548:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    954c:	17fffe51 	b	8e90 <fwp_write+0x4e0>
    9550:	52800443 	mov	w3, #0x22                  	// #34
    9554:	91001ff5 	add	x21, sp, #0x7
    9558:	91002273 	add	x19, x19, #0x8
    955c:	aa1503e1 	mov	x1, x21
    9560:	aa1403e0 	mov	x0, x20
    9564:	d2800022 	mov	x2, #0x1                   	// #1
    9568:	39001fe3 	strb	w3, [sp, #7]
    956c:	f90143f7 	str	x23, [sp, #640]
    9570:	8b160277 	add	x23, x19, x22
    9574:	f90147f8 	str	x24, [sp, #648]
    9578:	97ffe786 	bl	3390 <buf_put>
    957c:	b4000696 	cbz	x22, 964c <fwp_write+0xc9c>
    9580:	d0000018 	adrp	x24, b000 <_IO_stdin_used+0x180>
    9584:	910e6318 	add	x24, x24, #0x398
    9588:	f9014bf9 	str	x25, [sp, #656]
    958c:	d0000019 	adrp	x25, b000 <_IO_stdin_used+0x180>
    9590:	910ee339 	add	x25, x25, #0x3b8
    9594:	f9014ffa 	str	x26, [sp, #664]
    9598:	1400000d 	b	95cc <fwp_write+0xc1c>
    959c:	710024bf 	cmp	w5, #0x9
    95a0:	54000460 	b.eq	962c <fwp_write+0xc7c>  // b.none
    95a4:	710028bf 	cmp	w5, #0xa
    95a8:	54000a61 	b.ne	96f4 <fwp_write+0xd44>  // b.any
    95ac:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    95b0:	aa1403e0 	mov	x0, x20
    95b4:	910ea021 	add	x1, x1, #0x3a8
    95b8:	d2800042 	mov	x2, #0x2                   	// #2
    95bc:	97ffe775 	bl	3390 <buf_put>
    95c0:	91000673 	add	x19, x19, #0x1
    95c4:	eb17027f 	cmp	x19, x23
    95c8:	540003e0 	b.eq	9644 <fwp_write+0xc94>  // b.none
    95cc:	39400265 	ldrb	w5, [x19]
    95d0:	710034bf 	cmp	w5, #0xd
    95d4:	54000180 	b.eq	9604 <fwp_write+0xc54>  // b.none
    95d8:	54fffe29 	b.ls	959c <fwp_write+0xbec>  // b.plast
    95dc:	710088bf 	cmp	w5, #0x22
    95e0:	540001c0 	b.eq	9618 <fwp_write+0xc68>  // b.none
    95e4:	710170bf 	cmp	w5, #0x5c
    95e8:	54000741 	b.ne	96d0 <fwp_write+0xd20>  // b.any
    95ec:	aa1403e0 	mov	x0, x20
    95f0:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    95f4:	d2800042 	mov	x2, #0x2                   	// #2
    95f8:	910e8021 	add	x1, x1, #0x3a0
    95fc:	97ffe765 	bl	3390 <buf_put>
    9600:	17fffff0 	b	95c0 <fwp_write+0xc10>
    9604:	aa1903e1 	mov	x1, x25
    9608:	aa1403e0 	mov	x0, x20
    960c:	d2800042 	mov	x2, #0x2                   	// #2
    9610:	97ffe760 	bl	3390 <buf_put>
    9614:	17ffffeb 	b	95c0 <fwp_write+0xc10>
    9618:	aa1803e1 	mov	x1, x24
    961c:	aa1403e0 	mov	x0, x20
    9620:	d2800042 	mov	x2, #0x2                   	// #2
    9624:	97ffe75b 	bl	3390 <buf_put>
    9628:	17ffffe6 	b	95c0 <fwp_write+0xc10>
    962c:	aa1403e0 	mov	x0, x20
    9630:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    9634:	d2800042 	mov	x2, #0x2                   	// #2
    9638:	910ec021 	add	x1, x1, #0x3b0
    963c:	97ffe755 	bl	3390 <buf_put>
    9640:	17ffffe0 	b	95c0 <fwp_write+0xc10>
    9644:	f9414bf9 	ldr	x25, [sp, #656]
    9648:	f9414ffa 	ldr	x26, [sp, #664]
    964c:	aa1503e1 	mov	x1, x21
    9650:	aa1403e0 	mov	x0, x20
    9654:	52800443 	mov	w3, #0x22                  	// #34
    9658:	17fffd9c 	b	8cc8 <fwp_write+0x318>
    965c:	7100103f 	cmp	w1, #0x4
    9660:	54ffeb21 	b.ne	93c4 <fwp_write+0xa14>  // b.any
    9664:	f94006e0 	ldr	x0, [x23, #8]
    9668:	d37ffc00 	lsr	x0, x0, #63
    966c:	17fffeb3 	b	9138 <fwp_write+0x788>
    9670:	710002ff 	cmp	w23, #0x0
    9674:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9678:	17fffeb0 	b	9138 <fwp_write+0x788>
    967c:	528005a1 	mov	w1, #0x2d                  	// #45
    9680:	eb0203e2 	negs	x2, x2
    9684:	da0303e3 	ngc	x3, x3
    9688:	910127e0 	add	x0, sp, #0x49
    968c:	910123f5 	add	x21, sp, #0x48
    9690:	390123e1 	strb	w1, [sp, #72]
    9694:	97ffe5c3 	bl	2da0 <fwp_fmt_u128>
    9698:	17fffe18 	b	8ef8 <fwp_write+0x548>
    969c:	d37ceea1 	lsl	x1, x21, #4
    96a0:	b7f810a3 	tbnz	x3, #63, 98b4 <fwp_write+0xf04>
    96a4:	91002260 	add	x0, x19, #0x8
    96a8:	8b010001 	add	x1, x0, x1
    96ac:	17fffdf9 	b	8e90 <fwp_write+0x4e0>
    96b0:	f9400a61 	ldr	x1, [x19, #16]
    96b4:	8b010000 	add	x0, x0, x1
    96b8:	f9400001 	ldr	x1, [x0]
    96bc:	17fffdf5 	b	8e90 <fwp_write+0x4e0>
    96c0:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    96c4:	d2800042 	mov	x2, #0x2                   	// #2
    96c8:	910d0021 	add	x1, x1, #0x340
    96cc:	17fffed6 	b	9224 <fwp_write+0x874>
    96d0:	7101fcbf 	cmp	w5, #0x7f
    96d4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    96d8:	540000e9 	b.ls	96f4 <fwp_write+0xd44>  // b.plast
    96dc:	aa1503e1 	mov	x1, x21
    96e0:	aa1403e0 	mov	x0, x20
    96e4:	d2800022 	mov	x2, #0x1                   	// #1
    96e8:	39001fe5 	strb	w5, [sp, #7]
    96ec:	97ffe729 	bl	3390 <buf_put>
    96f0:	17ffffb4 	b	95c0 <fwp_write+0xc10>
    96f4:	d2800203 	mov	x3, #0x10                  	// #16
    96f8:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x180>
    96fc:	aa0303e1 	mov	x1, x3
    9700:	910f0084 	add	x4, x4, #0x3c0
    9704:	910123f6 	add	x22, sp, #0x48
    9708:	52800042 	mov	w2, #0x2                   	// #2
    970c:	aa1603e0 	mov	x0, x22
    9710:	97ffe414 	bl	2760 <__snprintf_chk@plt>
    9714:	aa1603e0 	mov	x0, x22
    9718:	97ffe3da 	bl	2680 <strlen@plt>
    971c:	aa1603e1 	mov	x1, x22
    9720:	aa0003e2 	mov	x2, x0
    9724:	aa1403e0 	mov	x0, x20
    9728:	97ffe71a 	bl	3390 <buf_put>
    972c:	17ffffa5 	b	95c0 <fwp_write+0xc10>
    9730:	1e604100 	fmov	d0, d8
    9734:	aa1503e0 	mov	x0, x21
    9738:	52800221 	mov	w1, #0x11                  	// #17
    973c:	97ffe771 	bl	3500 <fwp_format_g.constprop.0>
    9740:	17fffe43 	b	904c <fwp_write+0x69c>
    9744:	b9401040 	ldr	w0, [x2, #16]
    9748:	350003c0 	cbnz	w0, 97c0 <fwp_write+0xe10>
    974c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9750:	f947f400 	ldr	x0, [x0, #4072]
    9754:	f94127e2 	ldr	x2, [sp, #584]
    9758:	f9400001 	ldr	x1, [x0]
    975c:	eb010042 	subs	x2, x2, x1
    9760:	d2800001 	mov	x1, #0x0                   	// #0
    9764:	54ffd721 	b.ne	9248 <fwp_write+0x898>  // b.any
    9768:	f9413bf5 	ldr	x21, [sp, #624]
    976c:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    9770:	f9413ff6 	ldr	x22, [sp, #632]
    9774:	aa1403e0 	mov	x0, x20
    9778:	f94143f7 	ldr	x23, [sp, #640]
    977c:	91104021 	add	x1, x1, #0x410
    9780:	f94147f8 	ldr	x24, [sp, #648]
    9784:	d2800042 	mov	x2, #0x2                   	// #2
    9788:	17fffd0e 	b	8bc0 <fwp_write+0x210>
    978c:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x180>
    9790:	d2800042 	mov	x2, #0x2                   	// #2
    9794:	910d2021 	add	x1, x1, #0x348
    9798:	17fffea3 	b	9224 <fwp_write+0x874>
    979c:	f9400a63 	ldr	x3, [x19, #16]
    97a0:	8b030021 	add	x1, x1, x3
    97a4:	17ffff66 	b	953c <fwp_write+0xb8c>
    97a8:	f9400a61 	ldr	x1, [x19, #16]
    97ac:	8b0102a1 	add	x1, x21, x1
    97b0:	17fffdb3 	b	8e7c <fwp_write+0x4cc>
    97b4:	f9400a63 	ldr	x3, [x19, #16]
    97b8:	8b030021 	add	x1, x1, x3
    97bc:	17ffff56 	b	9514 <fwp_write+0xb64>
    97c0:	b9404840 	ldr	w0, [x2, #72]
    97c4:	91001ff5 	add	x21, sp, #0x7
    97c8:	34ffa360 	cbz	w0, 8c34 <fwp_write+0x284>
    97cc:	52800503 	mov	w3, #0x28                  	// #40
    97d0:	aa1403e0 	mov	x0, x20
    97d4:	aa1503e1 	mov	x1, x21
    97d8:	d2800022 	mov	x2, #0x1                   	// #1
    97dc:	39001fe3 	strb	w3, [sp, #7]
    97e0:	97ffe6ec 	bl	3390 <buf_put>
    97e4:	b9401380 	ldr	w0, [x28, #16]
    97e8:	52800038 	mov	w24, #0x1                   	// #1
    97ec:	7100001f 	cmp	w0, #0x0
    97f0:	54ffa36c 	b.gt	8c5c <fwp_write+0x2ac>
    97f4:	17fffd32 	b	8cbc <fwp_write+0x30c>
    97f8:	f9014bf9 	str	x25, [sp, #656]
    97fc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11090>
    9800:	f9014ffa 	str	x26, [sp, #664]
    9804:	f9400676 	ldr	x22, [x19, #8]
    9808:	91102333 	add	x19, x25, #0x408
    980c:	91002273 	add	x19, x19, #0x8
    9810:	937ffed8 	asr	x24, x22, #63
    9814:	aa1802c0 	orr	x0, x22, x24
    9818:	b5000320 	cbnz	x0, 987c <fwp_write+0xecc>
    981c:	110006b5 	add	w21, w21, #0x1
    9820:	710016bf 	cmp	w21, #0x5
    9824:	54ffffc1 	b.ne	981c <fwp_write+0xe6c>  // b.any
    9828:	b7f80578 	tbnz	x24, #63, 98d4 <fwp_write+0xf24>
    982c:	910023f3 	add	x19, sp, #0x8
    9830:	aa1603e2 	mov	x2, x22
    9834:	aa1303e0 	mov	x0, x19
    9838:	d2800003 	mov	x3, #0x0                   	// #0
    983c:	97ffe559 	bl	2da0 <fwp_fmt_u128>
    9840:	910123f5 	add	x21, sp, #0x48
    9844:	d0000003 	adrp	x3, b000 <_IO_stdin_used+0x180>
    9848:	aa1303e4 	mov	x4, x19
    984c:	aa1503e0 	mov	x0, x21
    9850:	91102063 	add	x3, x3, #0x408
    9854:	d2804002 	mov	x2, #0x200                 	// #512
    9858:	52800041 	mov	w1, #0x2                   	// #2
    985c:	97ffe38d 	bl	2690 <__sprintf_chk@plt>
    9860:	aa1503e0 	mov	x0, x21
    9864:	97ffe387 	bl	2680 <strlen@plt>
    9868:	aa1503e1 	mov	x1, x21
    986c:	aa0003e2 	mov	x2, x0
    9870:	aa1403e0 	mov	x0, x20
    9874:	97ffe6c7 	bl	3390 <buf_put>
    9878:	17fffe47 	b	9194 <fwp_write+0x7e4>
    987c:	f9400277 	ldr	x23, [x19]
    9880:	aa1603e0 	mov	x0, x22
    9884:	aa1803e1 	mov	x1, x24
    9888:	aa1703e2 	mov	x2, x23
    988c:	937ffefa 	asr	x26, x23, #63
    9890:	aa1a03e3 	mov	x3, x26
    9894:	94000493 	bl	aae0 <__modti3>
    9898:	aa010000 	orr	x0, x0, x1
    989c:	b40002c0 	cbz	x0, 98f4 <fwp_write+0xf44>
    98a0:	110006b5 	add	w21, w21, #0x1
    98a4:	91004273 	add	x19, x19, #0x10
    98a8:	710016bf 	cmp	w21, #0x5
    98ac:	54fffe81 	b.ne	987c <fwp_write+0xecc>  // b.any
    98b0:	17ffffde 	b	9828 <fwp_write+0xe78>
    98b4:	f9400a60 	ldr	x0, [x19, #16]
    98b8:	8b000021 	add	x1, x1, x0
    98bc:	17fffd75 	b	8e90 <fwp_write+0x4e0>
    98c0:	528c29c0 	mov	w0, #0x614e                	// #24910
    98c4:	910123f5 	add	x21, sp, #0x48
    98c8:	72a009c0 	movk	w0, #0x4e, lsl #16
    98cc:	b9004be0 	str	w0, [sp, #72]
    98d0:	17fffda2 	b	8f58 <fwp_write+0x5a8>
    98d4:	528005a1 	mov	w1, #0x2d                  	// #45
    98d8:	eb1603e2 	negs	x2, x22
    98dc:	da1803e3 	ngc	x3, x24
    98e0:	910027e0 	add	x0, sp, #0x9
    98e4:	910023f3 	add	x19, sp, #0x8
    98e8:	390023e1 	strb	w1, [sp, #8]
    98ec:	97ffe52d 	bl	2da0 <fwp_fmt_u128>
    98f0:	17ffffd4 	b	9840 <fwp_write+0xe90>
    98f4:	aa1703e2 	mov	x2, x23
    98f8:	aa1a03e3 	mov	x3, x26
    98fc:	aa1603e0 	mov	x0, x22
    9900:	aa1803e1 	mov	x1, x24
    9904:	94000397 	bl	a760 <__divti3>
    9908:	aa0003e2 	mov	x2, x0
    990c:	aa0103e3 	mov	x3, x1
    9910:	b7f80201 	tbnz	x1, #63, 9950 <fwp_write+0xfa0>
    9914:	910023f3 	add	x19, sp, #0x8
    9918:	aa1303e0 	mov	x0, x19
    991c:	97ffe521 	bl	2da0 <fwp_fmt_u128>
    9920:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9924:	91102339 	add	x25, x25, #0x408
    9928:	910123f5 	add	x21, sp, #0x48
    992c:	aa1303e4 	mov	x4, x19
    9930:	aa1503e0 	mov	x0, x21
    9934:	d0000003 	adrp	x3, b000 <_IO_stdin_used+0x180>
    9938:	f8616b25 	ldr	x5, [x25, x1]
    993c:	91100063 	add	x3, x3, #0x400
    9940:	d2804002 	mov	x2, #0x200                 	// #512
    9944:	52800041 	mov	w1, #0x2                   	// #2
    9948:	97ffe352 	bl	2690 <__sprintf_chk@plt>
    994c:	17ffffc5 	b	9860 <fwp_write+0xeb0>
    9950:	528005a4 	mov	w4, #0x2d                  	// #45
    9954:	eb0003e2 	negs	x2, x0
    9958:	da0103e3 	ngc	x3, x1
    995c:	910027e0 	add	x0, sp, #0x9
    9960:	910023f3 	add	x19, sp, #0x8
    9964:	390023e4 	strb	w4, [sp, #8]
    9968:	97ffe50e 	bl	2da0 <fwp_fmt_u128>
    996c:	17ffffed 	b	9920 <fwp_write+0xf70>
    9970:	f9013bf5 	str	x21, [sp, #624]
    9974:	f9013ff6 	str	x22, [sp, #632]
    9978:	f90143f7 	str	x23, [sp, #640]
    997c:	f90147f8 	str	x24, [sp, #648]
    9980:	f9014bf9 	str	x25, [sp, #656]
    9984:	f9014ffa 	str	x26, [sp, #664]
    9988:	f90153fb 	str	x27, [sp, #672]
    998c:	f90157fc 	str	x28, [sp, #680]
    9990:	fd015be8 	str	d8, [sp, #688]
    9994:	fd015fe9 	str	d9, [sp, #696]
    9998:	97ffe396 	bl	27f0 <__stack_chk_fail@plt>
    999c:	d503201f 	nop

00000000000099a0 <fwp_main_thread>:
    99a0:	d10643ff 	sub	sp, sp, #0x190
    99a4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    99a8:	f947f400 	ldr	x0, [x0, #4072]
    99ac:	a9127bfd 	stp	x29, x30, [sp, #288]
    99b0:	910483fd 	add	x29, sp, #0x120
    99b4:	a91353f3 	stp	x19, x20, [sp, #304]
    99b8:	90000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    99bc:	91150261 	add	x1, x19, #0x540
    99c0:	a9145bf5 	stp	x21, x22, [sp, #320]
    99c4:	a91563f7 	stp	x23, x24, [sp, #336]
    99c8:	b953a421 	ldr	w1, [x1, #5028]
    99cc:	a9166bf9 	stp	x25, x26, [sp, #352]
    99d0:	f9400002 	ldr	x2, [x0]
    99d4:	f9008fe2 	str	x2, [sp, #280]
    99d8:	d2800002 	mov	x2, #0x0                   	// #0
    99dc:	34000e21 	cbz	w1, 9ba0 <fwp_main_thread+0x200>
    99e0:	91150260 	add	x0, x19, #0x540
    99e4:	b953a800 	ldr	w0, [x0, #5032]
    99e8:	35000d40 	cbnz	w0, 9b90 <fwp_main_thread+0x1f0>
    99ec:	f00000b5 	adrp	x21, 20000 <__data_start>
    99f0:	f00000a2 	adrp	x2, 20000 <__data_start>
    99f4:	9100c2b4 	add	x20, x21, #0x30
    99f8:	910d8042 	add	x2, x2, #0x360
    99fc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9a00:	d2a00024 	mov	x4, #0x10000               	// #65536
    9a04:	910103f7 	add	x23, sp, #0x40
    9a08:	9100a3f6 	add	x22, sp, #0x28
    9a0c:	aa1703e0 	mov	x0, x23
    9a10:	d2800001 	mov	x1, #0x0                   	// #0
    9a14:	a9018e96 	stp	x22, x3, [x20, #24]
    9a18:	f90023e2 	str	x2, [sp, #64]
    9a1c:	b9004bff 	str	wzr, [sp, #72]
    9a20:	f9002be4 	str	x4, [sp, #80]
    9a24:	97ffe30b 	bl	2650 <sigaltstack@plt>
    9a28:	35000220 	cbnz	w0, 9a6c <fwp_main_thread+0xcc>
    9a2c:	4f000400 	movi	v0.4s, #0x0
    9a30:	910223e0 	add	x0, sp, #0x88
    9a34:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9a38:	913fc021 	add	x1, x1, #0xff0
    9a3c:	f90043e1 	str	x1, [sp, #128]
    9a40:	52800082 	mov	w2, #0x4                   	// #4
    9a44:	72a10002 	movk	w2, #0x800, lsl #16
    9a48:	910203f9 	add	x25, sp, #0x80
    9a4c:	3d802000 	str	q0, [x0, #128]
    9a50:	b9010be2 	str	w2, [sp, #264]
    9a54:	ad000000 	stp	q0, q0, [x0]
    9a58:	ad010000 	stp	q0, q0, [x0, #32]
    9a5c:	ad020000 	stp	q0, q0, [x0, #64]
    9a60:	ad030000 	stp	q0, q0, [x0, #96]
    9a64:	97ffe353 	bl	27b0 <sigemptyset@plt>
    9a68:	340000c0 	cbz	w0, 9a80 <fwp_main_thread+0xe0>
    9a6c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    9a70:	91108000 	add	x0, x0, #0x420
    9a74:	a91773fb 	stp	x27, x28, [sp, #368]
    9a78:	fd00c3e8 	str	d8, [sp, #384]
    9a7c:	97ffe8e5 	bl	3e10 <fwp_trap>
    9a80:	aa1903e1 	mov	x1, x25
    9a84:	d2800002 	mov	x2, #0x0                   	// #0
    9a88:	52800160 	mov	w0, #0xb                   	// #11
    9a8c:	97ffe361 	bl	2810 <sigaction@plt>
    9a90:	35fffee0 	cbnz	w0, 9a6c <fwp_main_thread+0xcc>
    9a94:	aa1903e1 	mov	x1, x25
    9a98:	d2800002 	mov	x2, #0x0                   	// #0
    9a9c:	528000e0 	mov	w0, #0x7                   	// #7
    9aa0:	97ffe35c 	bl	2810 <sigaction@plt>
    9aa4:	35fffe40 	cbnz	w0, 9a6c <fwp_main_thread+0xcc>
    9aa8:	b942fa80 	ldr	w0, [x20, #760]
    9aac:	340007e0 	cbz	w0, 9ba8 <fwp_main_thread+0x208>
    9ab0:	9100c2b6 	add	x22, x21, #0x30
    9ab4:	f9400ad4 	ldr	x20, [x22, #16]
    9ab8:	b4001a94 	cbz	x20, 9e08 <fwp_main_thread+0x468>
    9abc:	91010297 	add	x23, x20, #0x40
    9ac0:	39414a99 	ldrb	w25, [x20, #82]
    9ac4:	52800038 	mov	w24, #0x1                   	// #1
    9ac8:	39014a98 	strb	w24, [x20, #82]
    9acc:	d503201f 	nop
    9ad0:	f9401680 	ldr	x0, [x20, #40]
    9ad4:	b4001980 	cbz	x0, 9e04 <fwp_main_thread+0x464>
    9ad8:	f9403281 	ldr	x1, [x20, #96]
    9adc:	39414680 	ldrb	w0, [x20, #81]
    9ae0:	b40014c1 	cbz	x1, 9d78 <fwp_main_thread+0x3d8>
    9ae4:	36001380 	tbz	w0, #0, 9d54 <fwp_main_thread+0x3b4>
    9ae8:	f9400ad3 	ldr	x19, [x22, #16]
    9aec:	f9402280 	ldr	x0, [x20, #64]
    9af0:	39414a61 	ldrb	w1, [x19, #82]
    9af4:	37001781 	tbnz	w1, #0, 9de4 <fwp_main_thread+0x444>
    9af8:	f9403261 	ldr	x1, [x19, #96]
    9afc:	a911fe77 	stp	x23, xzr, [x19, #280]
    9b00:	f9009660 	str	x0, [x19, #296]
    9b04:	b4000040 	cbz	x0, 9b0c <fwp_main_thread+0x16c>
    9b08:	f9009013 	str	x19, [x0, #288]
    9b0c:	f9002293 	str	x19, [x20, #64]
    9b10:	b4000101 	cbz	x1, 9b30 <fwp_main_thread+0x190>
    9b14:	f94046c0 	ldr	x0, [x22, #136]
    9b18:	39015678 	strb	w24, [x19, #85]
    9b1c:	f9003661 	str	x1, [x19, #104]
    9b20:	a910827f 	stp	xzr, x0, [x19, #264]
    9b24:	b4000040 	cbz	x0, 9b2c <fwp_main_thread+0x18c>
    9b28:	f9008413 	str	x19, [x0, #264]
    9b2c:	f90046d3 	str	x19, [x22, #136]
    9b30:	39015a7f 	strb	wzr, [x19, #86]
    9b34:	97fff287 	bl	6550 <fwp_block>
    9b38:	f9408e62 	ldr	x2, [x19, #280]
    9b3c:	b4000142 	cbz	x2, 9b64 <fwp_main_thread+0x1c4>
    9b40:	a9520261 	ldp	x1, x0, [x19, #288]
    9b44:	b40015c1 	cbz	x1, 9dfc <fwp_main_thread+0x45c>
    9b48:	f9009420 	str	x0, [x1, #296]
    9b4c:	f9409660 	ldr	x0, [x19, #296]
    9b50:	b4000040 	cbz	x0, 9b58 <fwp_main_thread+0x1b8>
    9b54:	f9009001 	str	x1, [x0, #288]
    9b58:	91080260 	add	x0, x19, #0x200
    9b5c:	f900967f 	str	xzr, [x19, #296]
    9b60:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9b64:	39415660 	ldrb	w0, [x19, #85]
    9b68:	3607fb40 	tbz	w0, #0, 9ad0 <fwp_main_thread+0x130>
    9b6c:	a9508261 	ldp	x1, x0, [x19, #264]
    9b70:	b40025c1 	cbz	x1, a028 <fwp_main_thread+0x688>
    9b74:	f9008820 	str	x0, [x1, #272]
    9b78:	b4000040 	cbz	x0, 9b80 <fwp_main_thread+0x1e0>
    9b7c:	f9008401 	str	x1, [x0, #264]
    9b80:	91080260 	add	x0, x19, #0x200
    9b84:	3901567f 	strb	wzr, [x19, #85]
    9b88:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9b8c:	17ffffd1 	b	9ad0 <fwp_main_thread+0x130>
    9b90:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9b94:	91241000 	add	x0, x0, #0x904
    9b98:	940004ae 	bl	ae50 <atexit>
    9b9c:	17ffff94 	b	99ec <fwp_main_thread+0x4c>
    9ba0:	97ffe7b4 	bl	3a70 <fwp_heap_init>
    9ba4:	17ffff8f 	b	99e0 <fwp_main_thread+0x40>
    9ba8:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    9bac:	a91773fb 	stp	x27, x28, [sp, #368]
    9bb0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9bb4:	f9416282 	ldr	x2, [x20, #704]
    9bb8:	fd00c3e8 	str	d8, [sp, #384]
    9bbc:	913b4021 	add	x1, x1, #0xed0
    9bc0:	fd459008 	ldr	d8, [x0, #2848]
    9bc4:	91150278 	add	x24, x19, #0x540
    9bc8:	90ffffe0 	adrp	x0, 5000 <fwp_tape_grow.constprop.0+0xdc>
    9bcc:	d2800004 	mov	x4, #0x0                   	// #0
    9bd0:	912a5000 	add	x0, x0, #0xa94
    9bd4:	d290001c 	mov	x28, #0x8000                	// #32768
    9bd8:	d280001a 	mov	x26, #0x0                   	// #0
    9bdc:	a90287e2 	stp	x2, x1, [sp, #40]
    9be0:	a903fff7 	stp	x23, xzr, [sp, #56]
    9be4:	f9002bff 	str	xzr, [sp, #80]
    9be8:	f9002fe0 	str	x0, [sp, #88]
    9bec:	f9016296 	str	x22, [x20, #704]
    9bf0:	14000041 	b	9cf4 <fwp_main_thread+0x354>
    9bf4:	f9400281 	ldr	x1, [x20]
    9bf8:	aa2103e1 	mvn	x1, x1
    9bfc:	f8207b01 	str	x1, [x24, x0, lsl #3]
    9c00:	f10060df 	cmp	x6, #0x18
    9c04:	540001a9 	b.ls	9c38 <fwp_main_thread+0x298>  // b.plast
    9c08:	d10064c2 	sub	x2, x6, #0x19
    9c0c:	91006280 	add	x0, x20, #0x18
    9c10:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9c14:	52800001 	mov	w1, #0x0                   	// #0
    9c18:	91002042 	add	x2, x2, #0x8
    9c1c:	a90013e6 	stp	x6, x4, [sp]
    9c20:	b90013e7 	str	w7, [sp, #16]
    9c24:	f9000fe5 	str	x5, [sp, #24]
    9c28:	97ffe2e6 	bl	27c0 <memset@plt>
    9c2c:	a94013e6 	ldp	x6, x4, [sp]
    9c30:	f9400fe5 	ldr	x5, [sp, #24]
    9c34:	b94013e7 	ldr	w7, [sp, #16]
    9c38:	f94a1300 	ldr	x0, [x24, #5152]
    9c3c:	ab060000 	adds	x0, x0, x6
    9c40:	54004fc2 	b.cs	a638 <fwp_main_thread+0xc98>  // b.hs, b.nlast
    9c44:	f94a1701 	ldr	x1, [x24, #5160]
    9c48:	f90a1300 	str	x0, [x24, #5152]
    9c4c:	eb01001f 	cmp	x0, x1
    9c50:	54000049 	b.ls	9c58 <fwp_main_thread+0x2b8>  // b.plast
    9c54:	f90a1700 	str	x0, [x24, #5160]
    9c58:	1e6300e1 	ucvtf	d1, w7
    9c5c:	fd4a1f00 	ldr	d0, [x24, #5176]
    9c60:	1e612800 	fadd	d0, d0, d1
    9c64:	fd0a1f00 	str	d0, [x24, #5176]
    9c68:	a900929b 	stp	x27, x4, [x20, #8]
    9c6c:	aa1403e4 	mov	x4, x20
    9c70:	fd000288 	str	d8, [x20]
    9c74:	f949db01 	ldr	x1, [x24, #5040]
    9c78:	f949ef00 	ldr	x0, [x24, #5080]
    9c7c:	cb010281 	sub	x1, x20, x1
    9c80:	eb00403f 	cmp	x1, x0, lsl #16
    9c84:	54000322 	b.cs	9ce8 <fwp_main_thread+0x348>  // b.hs, b.nlast
    9c88:	d350fc20 	lsr	x0, x1, #16
    9c8c:	f949ff07 	ldr	x7, [x24, #5112]
    9c90:	8b000800 	add	x0, x0, x0, lsl #2
    9c94:	d37df002 	lsl	x2, x0, #3
    9c98:	8b0200e6 	add	x6, x7, x2
    9c9c:	f94010c0 	ldr	x0, [x6, #32]
    9ca0:	b4000240 	cbz	x0, 9ce8 <fwp_main_thread+0x348>
    9ca4:	386268e2 	ldrb	w2, [x7, x2]
    9ca8:	7100085f 	cmp	w2, #0x2
    9cac:	54001b80 	b.eq	a01c <fwp_main_thread+0x67c>  // b.none
    9cb0:	7100045f 	cmp	w2, #0x1
    9cb4:	540001a1 	b.ne	9ce8 <fwp_main_thread+0x348>  // b.any
    9cb8:	294308c7 	ldp	w7, w2, [x6, #24]
    9cbc:	92403c21 	and	x1, x1, #0xffff
    9cc0:	9b077c21 	mul	x1, x1, x7
    9cc4:	d360fc21 	lsr	x1, x1, #32
    9cc8:	eb02003f 	cmp	x1, x2
    9ccc:	540000e2 	b.cs	9ce8 <fwp_main_thread+0x348>  // b.hs, b.nlast
    9cd0:	8b010000 	add	x0, x0, x1
    9cd4:	39400001 	ldrb	w1, [x0]
    9cd8:	7103fc3f 	cmp	w1, #0xff
    9cdc:	54004020 	b.eq	a4e0 <fwp_main_thread+0xb40>  // b.none
    9ce0:	52800021 	mov	w1, #0x1                   	// #1
    9ce4:	39000001 	strb	w1, [x0]
    9ce8:	a9047ff4 	stp	x20, xzr, [sp, #64]
    9cec:	aa05037b 	orr	x27, x27, x5
    9cf0:	b4001a1b 	cbz	x27, a030 <fwp_main_thread+0x690>
    9cf4:	b953a700 	ldr	w0, [x24, #5028]
    9cf8:	f100079b 	subs	x27, x28, #0x1
    9cfc:	f90027fb 	str	x27, [sp, #72]
    9d00:	da1f0345 	sbc	x5, x26, xzr
    9d04:	aa1b03fc 	mov	x28, x27
    9d08:	aa0503fa 	mov	x26, x5
    9d0c:	340005e0 	cbz	w0, 9dc8 <fwp_main_thread+0x428>
    9d10:	397e8b00 	ldrb	w0, [x24, #4002]
    9d14:	910f0001 	add	x1, x0, #0x3c0
    9d18:	8b000400 	add	x0, x0, x0, lsl #1
    9d1c:	b8617b07 	ldr	w7, [x24, x1, lsl #2]
    9d20:	8b000f01 	add	x1, x24, x0, lsl #3
    9d24:	f8607b14 	ldr	x20, [x24, x0, lsl #3]
    9d28:	2a0703e6 	mov	w6, w7
    9d2c:	b5fff654 	cbnz	x20, 9bf4 <fwp_main_thread+0x254>
    9d30:	f9400434 	ldr	x20, [x1, #8]
    9d34:	b40004b4 	cbz	x20, 9dc8 <fwp_main_thread+0x428>
    9d38:	f9400820 	ldr	x0, [x1, #16]
    9d3c:	cb140000 	sub	x0, x0, x20
    9d40:	eb0000df 	cmp	x6, x0
    9d44:	54000428 	b.hi	9dc8 <fwp_main_thread+0x428>  // b.pmore
    9d48:	8b060280 	add	x0, x20, x6
    9d4c:	f9000420 	str	x0, [x1, #8]
    9d50:	17ffffac 	b	9c00 <fwp_main_thread+0x260>
    9d54:	97ffea4f 	bl	4690 <fwp_now_ns>
    9d58:	f9403281 	ldr	x1, [x20, #96]
    9d5c:	eb01001f 	cmp	x0, x1
    9d60:	540000ab 	b.lt	9d74 <fwp_main_thread+0x3d4>  // b.tstop
    9d64:	39414280 	ldrb	w0, [x20, #80]
    9d68:	37000060 	tbnz	w0, #0, 9d74 <fwp_main_thread+0x3d4>
    9d6c:	aa1403e0 	mov	x0, x20
    9d70:	97ffe5a0 	bl	33f0 <fwp_cancel_tree.part.0>
    9d74:	39414680 	ldrb	w0, [x20, #81]
    9d78:	f9400ad3 	ldr	x19, [x22, #16]
    9d7c:	39414a62 	ldrb	w2, [x19, #82]
    9d80:	3707eb40 	tbnz	w0, #0, 9ae8 <fwp_main_thread+0x148>
    9d84:	f9403281 	ldr	x1, [x20, #96]
    9d88:	370001c2 	tbnz	w2, #0, 9dc0 <fwp_main_thread+0x420>
    9d8c:	f9403260 	ldr	x0, [x19, #96]
    9d90:	b4000180 	cbz	x0, 9dc0 <fwp_main_thread+0x420>
    9d94:	b4000061 	cbz	x1, 9da0 <fwp_main_thread+0x400>
    9d98:	eb01001f 	cmp	x0, x1
    9d9c:	9a81d000 	csel	x0, x0, x1, le
    9da0:	f9402281 	ldr	x1, [x20, #64]
    9da4:	a911fe77 	stp	x23, xzr, [x19, #280]
    9da8:	f9009661 	str	x1, [x19, #296]
    9dac:	b4003a61 	cbz	x1, a4f8 <fwp_main_thread+0xb58>
    9db0:	f9009033 	str	x19, [x1, #288]
    9db4:	aa0003e1 	mov	x1, x0
    9db8:	f9002293 	str	x19, [x20, #64]
    9dbc:	17ffff56 	b	9b14 <fwp_main_thread+0x174>
    9dc0:	f9402280 	ldr	x0, [x20, #64]
    9dc4:	17ffff4e 	b	9afc <fwp_main_thread+0x15c>
    9dc8:	52800001 	mov	w1, #0x0                   	// #0
    9dcc:	d2800300 	mov	x0, #0x18                  	// #24
    9dd0:	a90017e4 	stp	x4, x5, [sp]
    9dd4:	97ffeb87 	bl	4bf0 <fwp_heap_alloc>
    9dd8:	aa0003f4 	mov	x20, x0
    9ddc:	a94017e4 	ldp	x4, x5, [sp]
    9de0:	17ffffa2 	b	9c68 <fwp_main_thread+0x2c8>
    9de4:	a911fe77 	stp	x23, xzr, [x19, #280]
    9de8:	f9009660 	str	x0, [x19, #296]
    9dec:	b4000040 	cbz	x0, 9df4 <fwp_main_thread+0x454>
    9df0:	f9009013 	str	x19, [x0, #288]
    9df4:	f9002293 	str	x19, [x20, #64]
    9df8:	17ffff4e 	b	9b30 <fwp_main_thread+0x190>
    9dfc:	f9000040 	str	x0, [x2]
    9e00:	17ffff54 	b	9b50 <fwp_main_thread+0x1b0>
    9e04:	39014a99 	strb	w25, [x20, #82]
    9e08:	9100c2b3 	add	x19, x21, #0x30
    9e0c:	f9416e60 	ldr	x0, [x19, #728]
    9e10:	b5000060 	cbnz	x0, 9e1c <fwp_main_thread+0x47c>
    9e14:	f9417660 	ldr	x0, [x19, #744]
    9e18:	b40038e0 	cbz	x0, a534 <fwp_main_thread+0xb94>
    9e1c:	9100c2a0 	add	x0, x21, #0x30
    9e20:	f9400800 	ldr	x0, [x0, #16]
    9e24:	9100c2a1 	add	x1, x21, #0x30
    9e28:	f9418825 	ldr	x5, [x1, #784]
    9e2c:	b903083f 	str	wzr, [x1, #776]
    9e30:	eb0000bf 	cmp	x5, x0
    9e34:	540048a1 	b.ne	a748 <fwp_main_thread+0xda8>  // b.any
    9e38:	b40003e0 	cbz	x0, 9eb4 <fwp_main_thread+0x514>
    9e3c:	f9415826 	ldr	x6, [x1, #688]
    9e40:	52800021 	mov	w1, #0x1                   	// #1
    9e44:	39014801 	strb	w1, [x0, #82]
    9e48:	b4000366 	cbz	x6, 9eb4 <fwp_main_thread+0x514>
    9e4c:	d503201f 	nop
    9e50:	394140c0 	ldrb	w0, [x6, #80]
    9e54:	37000060 	tbnz	w0, #0, 9e60 <fwp_main_thread+0x4c0>
    9e58:	aa0603e0 	mov	x0, x6
    9e5c:	97ffe565 	bl	33f0 <fwp_cancel_tree.part.0>
    9e60:	f9409cc6 	ldr	x6, [x6, #312]
    9e64:	b5ffff66 	cbnz	x6, 9e50 <fwp_main_thread+0x4b0>
    9e68:	9100c2b3 	add	x19, x21, #0x30
    9e6c:	52800034 	mov	w20, #0x1                   	// #1
    9e70:	f94028a0 	ldr	x0, [x5, #80]
    9e74:	f2001c1f 	tst	x0, #0xff000000ff
    9e78:	540000e1 	b.ne	9e94 <fwp_main_thread+0x4f4>  // b.any
    9e7c:	f9401660 	ldr	x0, [x19, #40]
    9e80:	390150b4 	strb	w20, [x5, #84]
    9e84:	f90080bf 	str	xzr, [x5, #256]
    9e88:	b4000120 	cbz	x0, 9eac <fwp_main_thread+0x50c>
    9e8c:	f9008005 	str	x5, [x0, #256]
    9e90:	f9001665 	str	x5, [x19, #40]
    9e94:	97fff1af 	bl	6550 <fwp_block>
    9e98:	97fff136 	bl	6370 <fwp_free_zombie>
    9e9c:	f9415a60 	ldr	x0, [x19, #688]
    9ea0:	b40000a0 	cbz	x0, 9eb4 <fwp_main_thread+0x514>
    9ea4:	f9418a65 	ldr	x5, [x19, #784]
    9ea8:	17fffff2 	b	9e70 <fwp_main_thread+0x4d0>
    9eac:	f9001a65 	str	x5, [x19, #48]
    9eb0:	17fffff8 	b	9e90 <fwp_main_thread+0x4f0>
    9eb4:	9100c2b4 	add	x20, x21, #0x30
    9eb8:	97fff12e 	bl	6370 <fwp_free_zombie>
    9ebc:	f9401a80 	ldr	x0, [x20, #48]
    9ec0:	b5004440 	cbnz	x0, a748 <fwp_main_thread+0xda8>
    9ec4:	f9404680 	ldr	x0, [x20, #136]
    9ec8:	b5004400 	cbnz	x0, a748 <fwp_main_thread+0xda8>
    9ecc:	b940aa80 	ldr	w0, [x20, #168]
    9ed0:	340001e0 	cbz	w0, 9f0c <fwp_main_thread+0x56c>
    9ed4:	93407c16 	sxtw	x22, w0
    9ed8:	51000400 	sub	w0, w0, #0x1
    9edc:	d1000ad6 	sub	x22, x22, #0x2
    9ee0:	9102c297 	add	x23, x20, #0xb0
    9ee4:	cb2042d6 	sub	x22, x22, w0, uxtw
    9ee8:	93407c13 	sxtw	x19, w0
    9eec:	d503201f 	nop
    9ef0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    9ef4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9ef8:	b900aa93 	str	w19, [x20, #168]
    9efc:	d1000673 	sub	x19, x19, #0x1
    9f00:	97ffe284 	bl	2910 <munmap@plt>
    9f04:	eb16027f 	cmp	x19, x22
    9f08:	54ffff41 	b.ne	9ef0 <fwp_main_thread+0x550>  // b.any
    9f0c:	f00000b3 	adrp	x19, 20000 <__data_start>
    9f10:	91004260 	add	x0, x19, #0x10
    9f14:	b9400800 	ldr	w0, [x0, #8]
    9f18:	37f80040 	tbnz	w0, #31, 9f20 <fwp_main_thread+0x580>
    9f1c:	97ffe239 	bl	2800 <close@plt>
    9f20:	9100c2b4 	add	x20, x21, #0x30
    9f24:	91004273 	add	x19, x19, #0x10
    9f28:	12800001 	mov	w1, #0xffffffff            	// #-1
    9f2c:	f9419280 	ldr	x0, [x20, #800]
    9f30:	b9000a61 	str	w1, [x19, #8]
    9f34:	f9418e81 	ldr	x1, [x20, #792]
    9f38:	b40001c0 	cbz	x0, 9f70 <fwp_main_thread+0x5d0>
    9f3c:	d2800013 	mov	x19, #0x0                   	// #0
    9f40:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    9f44:	b40000e0 	cbz	x0, 9f60 <fwp_main_thread+0x5c0>
    9f48:	f9400001 	ldr	x1, [x0]
    9f4c:	b5003fe1 	cbnz	x1, a748 <fwp_main_thread+0xda8>
    9f50:	f9400401 	ldr	x1, [x0, #8]
    9f54:	b5003fa1 	cbnz	x1, a748 <fwp_main_thread+0xda8>
    9f58:	97ffe86a 	bl	4100 <fwp_mem_free>
    9f5c:	f9418e81 	ldr	x1, [x20, #792]
    9f60:	91000673 	add	x19, x19, #0x1
    9f64:	f9419280 	ldr	x0, [x20, #800]
    9f68:	eb00027f 	cmp	x19, x0
    9f6c:	54fffea3 	b.cc	9f40 <fwp_main_thread+0x5a0>  // b.lo, b.ul, b.last
    9f70:	aa0103e0 	mov	x0, x1
    9f74:	97ffe863 	bl	4100 <fwp_mem_free>
    9f78:	9100c2a0 	add	x0, x21, #0x30
    9f7c:	f9418813 	ldr	x19, [x0, #784]
    9f80:	f9018c1f 	str	xzr, [x0, #792]
    9f84:	f901901f 	str	xzr, [x0, #800]
    9f88:	b40001f3 	cbz	x19, 9fc4 <fwp_main_thread+0x624>
    9f8c:	f9401661 	ldr	x1, [x19, #40]
    9f90:	b5003dc1 	cbnz	x1, a748 <fwp_main_thread+0xda8>
    9f94:	f9405661 	ldr	x1, [x19, #168]
    9f98:	b5003d81 	cbnz	x1, a748 <fwp_main_thread+0xda8>
    9f9c:	f9416c01 	ldr	x1, [x0, #728]
    9fa0:	b5003d41 	cbnz	x1, a748 <fwp_main_thread+0xda8>
    9fa4:	f9417400 	ldr	x0, [x0, #744]
    9fa8:	b5003d00 	cbnz	x0, a748 <fwp_main_thread+0xda8>
    9fac:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9fb0:	f0000120 	adrp	x0, 30000 <alt.5+0xfca0>
    9fb4:	910d8000 	add	x0, x0, #0x360
    9fb8:	97ffe202 	bl	27c0 <memset@plt>
    9fbc:	aa1303e0 	mov	x0, x19
    9fc0:	97ffe850 	bl	4100 <fwp_mem_free>
    9fc4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9fc8:	f947ec00 	ldr	x0, [x0, #4056]
    9fcc:	9100c2b5 	add	x21, x21, #0x30
    9fd0:	f9400000 	ldr	x0, [x0]
    9fd4:	f9000abf 	str	xzr, [x21, #16]
    9fd8:	f9018abf 	str	xzr, [x21, #784]
    9fdc:	97ffe251 	bl	2920 <fflush@plt>
    9fe0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9fe4:	f947f400 	ldr	x0, [x0, #4072]
    9fe8:	f9408fe2 	ldr	x2, [sp, #280]
    9fec:	f9400001 	ldr	x1, [x0]
    9ff0:	eb010042 	subs	x2, x2, x1
    9ff4:	d2800001 	mov	x1, #0x0                   	// #0
    9ff8:	540031a1 	b.ne	a62c <fwp_main_thread+0xc8c>  // b.any
    9ffc:	a9527bfd 	ldp	x29, x30, [sp, #288]
    a000:	d2800000 	mov	x0, #0x0                   	// #0
    a004:	a95353f3 	ldp	x19, x20, [sp, #304]
    a008:	a9545bf5 	ldp	x21, x22, [sp, #320]
    a00c:	a95563f7 	ldp	x23, x24, [sp, #336]
    a010:	a9566bf9 	ldp	x25, x26, [sp, #352]
    a014:	910643ff 	add	sp, sp, #0x190
    a018:	d65f03c0 	ret
    a01c:	72003c3f 	tst	w1, #0xffff
    a020:	54ffe641 	b.ne	9ce8 <fwp_main_thread+0x348>  // b.any
    a024:	17ffff2c 	b	9cd4 <fwp_main_thread+0x334>
    a028:	f90046c0 	str	x0, [x22, #136]
    a02c:	17fffed3 	b	9b78 <fwp_main_thread+0x1d8>
    a030:	9100c2a2 	add	x2, x21, #0x30
    a034:	f90023ff 	str	xzr, [sp, #64]
    a038:	f9416040 	ldr	x0, [x2, #704]
    a03c:	eb16001f 	cmp	x0, x22
    a040:	54003881 	b.ne	a750 <fwp_main_thread+0xdb0>  // b.any
    a044:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    a048:	910183e1 	add	x1, sp, #0x60
    a04c:	f94017e3 	ldr	x3, [sp, #40]
    a050:	f9016043 	str	x3, [x2, #704]
    a054:	3dc2d000 	ldr	q0, [x0, #2880]
    a058:	52800020 	mov	w0, #0x1                   	// #1
    a05c:	3d801be0 	str	q0, [sp, #96]
    a060:	97ffedd9 	bl	57c4 <fwp_data.part.0.constprop.0>
    a064:	91150263 	add	x3, x19, #0x540
    a068:	aa0003f6 	mov	x22, x0
    a06c:	f949d861 	ldr	x1, [x3, #5040]
    a070:	f949ec60 	ldr	x0, [x3, #5080]
    a074:	cb0102c1 	sub	x1, x22, x1
    a078:	eb00403f 	cmp	x1, x0, lsl #16
    a07c:	54000322 	b.cs	a0e0 <fwp_main_thread+0x740>  // b.hs, b.nlast
    a080:	d350fc22 	lsr	x2, x1, #16
    a084:	f949fc63 	ldr	x3, [x3, #5112]
    a088:	8b020842 	add	x2, x2, x2, lsl #2
    a08c:	d37df042 	lsl	x2, x2, #3
    a090:	8b020060 	add	x0, x3, x2
    a094:	f9401018 	ldr	x24, [x0, #32]
    a098:	b4000258 	cbz	x24, a0e0 <fwp_main_thread+0x740>
    a09c:	38626862 	ldrb	w2, [x3, x2]
    a0a0:	7100085f 	cmp	w2, #0x2
    a0a4:	54002300 	b.eq	a504 <fwp_main_thread+0xb64>  // b.none
    a0a8:	7100045f 	cmp	w2, #0x1
    a0ac:	540001a1 	b.ne	a0e0 <fwp_main_thread+0x740>  // b.any
    a0b0:	29430002 	ldp	w2, w0, [x0, #24]
    a0b4:	92403c21 	and	x1, x1, #0xffff
    a0b8:	9b027c21 	mul	x1, x1, x2
    a0bc:	d360fc21 	lsr	x1, x1, #32
    a0c0:	eb00003f 	cmp	x1, x0
    a0c4:	540000e2 	b.cs	a0e0 <fwp_main_thread+0x740>  // b.hs, b.nlast
    a0c8:	8b010318 	add	x24, x24, x1
    a0cc:	39400300 	ldrb	w0, [x24]
    a0d0:	7103fc1f 	cmp	w0, #0xff
    a0d4:	54002640 	b.eq	a59c <fwp_main_thread+0xbfc>  // b.none
    a0d8:	52800020 	mov	w0, #0x1                   	// #1
    a0dc:	39000300 	strb	w0, [x24]
    a0e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a0e4:	aa1903e1 	mov	x1, x25
    a0e8:	52800020 	mov	w0, #0x1                   	// #1
    a0ec:	a9085be2 	stp	x2, x22, [sp, #128]
    a0f0:	97ffedb5 	bl	57c4 <fwp_data.part.0.constprop.0>
    a0f4:	91150263 	add	x3, x19, #0x540
    a0f8:	aa0003f6 	mov	x22, x0
    a0fc:	f949d861 	ldr	x1, [x3, #5040]
    a100:	f949ec60 	ldr	x0, [x3, #5080]
    a104:	cb0102c1 	sub	x1, x22, x1
    a108:	eb00403f 	cmp	x1, x0, lsl #16
    a10c:	54000322 	b.cs	a170 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    a110:	d350fc22 	lsr	x2, x1, #16
    a114:	f949fc63 	ldr	x3, [x3, #5112]
    a118:	8b020842 	add	x2, x2, x2, lsl #2
    a11c:	d37df042 	lsl	x2, x2, #3
    a120:	8b020060 	add	x0, x3, x2
    a124:	f9401018 	ldr	x24, [x0, #32]
    a128:	b4000258 	cbz	x24, a170 <fwp_main_thread+0x7d0>
    a12c:	38626862 	ldrb	w2, [x3, x2]
    a130:	7100085f 	cmp	w2, #0x2
    a134:	54001ee0 	b.eq	a510 <fwp_main_thread+0xb70>  // b.none
    a138:	7100045f 	cmp	w2, #0x1
    a13c:	540001a1 	b.ne	a170 <fwp_main_thread+0x7d0>  // b.any
    a140:	29430002 	ldp	w2, w0, [x0, #24]
    a144:	92403c21 	and	x1, x1, #0xffff
    a148:	9b027c21 	mul	x1, x1, x2
    a14c:	d360fc21 	lsr	x1, x1, #32
    a150:	eb00003f 	cmp	x1, x0
    a154:	540000e2 	b.cs	a170 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    a158:	8b010318 	add	x24, x24, x1
    a15c:	39400300 	ldrb	w0, [x24]
    a160:	7103fc1f 	cmp	w0, #0xff
    a164:	54002100 	b.eq	a584 <fwp_main_thread+0xbe4>  // b.none
    a168:	52800020 	mov	w0, #0x1                   	// #1
    a16c:	39000300 	strb	w0, [x24]
    a170:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a174:	9101c3e1 	add	x1, sp, #0x70
    a178:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a17c:	52800020 	mov	w0, #0x1                   	// #1
    a180:	a9075be2 	stp	x2, x22, [sp, #112]
    a184:	97ffed90 	bl	57c4 <fwp_data.part.0.constprop.0>
    a188:	91150264 	add	x4, x19, #0x540
    a18c:	aa0003f6 	mov	x22, x0
    a190:	f949ec83 	ldr	x3, [x4, #5080]
    a194:	f949d881 	ldr	x1, [x4, #5040]
    a198:	d370bc63 	lsl	x3, x3, #16
    a19c:	cb010001 	sub	x1, x0, x1
    a1a0:	eb03003f 	cmp	x1, x3
    a1a4:	540003c2 	b.cs	a21c <fwp_main_thread+0x87c>  // b.hs, b.nlast
    a1a8:	d350fc22 	lsr	x2, x1, #16
    a1ac:	f949fc80 	ldr	x0, [x4, #5112]
    a1b0:	8b020842 	add	x2, x2, x2, lsl #2
    a1b4:	d37df042 	lsl	x2, x2, #3
    a1b8:	8b020004 	add	x4, x0, x2
    a1bc:	f9401098 	ldr	x24, [x4, #32]
    a1c0:	b40002f8 	cbz	x24, a21c <fwp_main_thread+0x87c>
    a1c4:	38626800 	ldrb	w0, [x0, x2]
    a1c8:	7100081f 	cmp	w0, #0x2
    a1cc:	54001a80 	b.eq	a51c <fwp_main_thread+0xb7c>  // b.none
    a1d0:	7100041f 	cmp	w0, #0x1
    a1d4:	54000241 	b.ne	a21c <fwp_main_thread+0x87c>  // b.any
    a1d8:	29430885 	ldp	w5, w2, [x4, #24]
    a1dc:	92403c20 	and	x0, x1, #0xffff
    a1e0:	9b057c00 	mul	x0, x0, x5
    a1e4:	d360fc00 	lsr	x0, x0, #32
    a1e8:	eb02001f 	cmp	x0, x2
    a1ec:	54000182 	b.cs	a21c <fwp_main_thread+0x87c>  // b.hs, b.nlast
    a1f0:	8b000318 	add	x24, x24, x0
    a1f4:	39400300 	ldrb	w0, [x24]
    a1f8:	7103fc1f 	cmp	w0, #0xff
    a1fc:	54001ca0 	b.eq	a590 <fwp_main_thread+0xbf0>  // b.none
    a200:	91150260 	add	x0, x19, #0x540
    a204:	52800021 	mov	w1, #0x1                   	// #1
    a208:	39000301 	strb	w1, [x24]
    a20c:	f949ec03 	ldr	x3, [x0, #5080]
    a210:	f949d801 	ldr	x1, [x0, #5040]
    a214:	d370bc63 	lsl	x3, x3, #16
    a218:	cb0102c1 	sub	x1, x22, x1
    a21c:	900000b8 	adrp	x24, 1e000 <__FRAME_END__+0x11090>
    a220:	91102318 	add	x24, x24, #0x408
    a224:	b0000019 	adrp	x25, b000 <_IO_stdin_used+0x180>
    a228:	91014318 	add	x24, x24, #0x50
    a22c:	aa1403fa 	mov	x26, x20
    a230:	9121e339 	add	x25, x25, #0x878
    a234:	eb03003f 	cmp	x1, x3
    a238:	54000362 	b.cs	a2a4 <fwp_main_thread+0x904>  // b.hs, b.nlast
    a23c:	91150262 	add	x2, x19, #0x540
    a240:	d350fc20 	lsr	x0, x1, #16
    a244:	8b000800 	add	x0, x0, x0, lsl #2
    a248:	f949fc44 	ldr	x4, [x2, #5112]
    a24c:	d37df002 	lsl	x2, x0, #3
    a250:	8b020083 	add	x3, x4, x2
    a254:	f9401060 	ldr	x0, [x3, #32]
    a258:	b4000260 	cbz	x0, a2a4 <fwp_main_thread+0x904>
    a25c:	38626882 	ldrb	w2, [x4, x2]
    a260:	7100085f 	cmp	w2, #0x2
    a264:	54001620 	b.eq	a528 <fwp_main_thread+0xb88>  // b.none
    a268:	7100045f 	cmp	w2, #0x1
    a26c:	540001c1 	b.ne	a2a4 <fwp_main_thread+0x904>  // b.any
    a270:	29430864 	ldp	w4, w2, [x3, #24]
    a274:	92403c21 	and	x1, x1, #0xffff
    a278:	9b047c21 	mul	x1, x1, x4
    a27c:	d360fc21 	lsr	x1, x1, #32
    a280:	eb02003f 	cmp	x1, x2
    a284:	54000102 	b.cs	a2a4 <fwp_main_thread+0x904>  // b.hs, b.nlast
    a288:	8b010000 	add	x0, x0, x1
    a28c:	39400001 	ldrb	w1, [x0]
    a290:	340000a1 	cbz	w1, a2a4 <fwp_main_thread+0x904>
    a294:	7103f43f 	cmp	w1, #0xfd
    a298:	54001888 	b.hi	a5a8 <fwp_main_thread+0xc08>  // b.pmore
    a29c:	11000421 	add	w1, w1, #0x1
    a2a0:	39000001 	strb	w1, [x0]
    a2a4:	aa1803e2 	mov	x2, x24
    a2a8:	aa1603e1 	mov	x1, x22
    a2ac:	aa1703e0 	mov	x0, x23
    a2b0:	52800023 	mov	w3, #0x1                   	// #1
    a2b4:	a9047fff 	stp	xzr, xzr, [sp, #64]
    a2b8:	f9002bff 	str	xzr, [sp, #80]
    a2bc:	97fff9bd 	bl	89b0 <fwp_write>
    a2c0:	a9440bfb 	ldp	x27, x2, [sp, #64]
    a2c4:	f100037f 	cmp	x27, #0x0
    a2c8:	9a9b033b 	csel	x27, x25, x27, eq	// eq = none
    a2cc:	b100285f 	cmn	x2, #0xa
    a2d0:	54001768 	b.hi	a5bc <fwp_main_thread+0xc1c>  // b.pmore
    a2d4:	91002440 	add	x0, x2, #0x9
    a2d8:	52800021 	mov	w1, #0x1                   	// #1
    a2dc:	f90003e2 	str	x2, [sp]
    a2e0:	97ffea44 	bl	4bf0 <fwp_heap_alloc>
    a2e4:	aa1b03e1 	mov	x1, x27
    a2e8:	aa0003fb 	mov	x27, x0
    a2ec:	f94003e2 	ldr	x2, [sp]
    a2f0:	aa0003fc 	mov	x28, x0
    a2f4:	f8008762 	str	x2, [x27], #8
    a2f8:	aa1b03e0 	mov	x0, x27
    a2fc:	97ffe0d1 	bl	2640 <memcpy@plt>
    a300:	f94003e2 	ldr	x2, [sp]
    a304:	8b020382 	add	x2, x28, x2
    a308:	3900205f 	strb	wzr, [x2, #8]
    a30c:	f94023e0 	ldr	x0, [sp, #64]
    a310:	97ffe168 	bl	28b0 <free@plt>
    a314:	91150260 	add	x0, x19, #0x540
    a318:	f949d801 	ldr	x1, [x0, #5040]
    a31c:	f949ec02 	ldr	x2, [x0, #5080]
    a320:	cb010381 	sub	x1, x28, x1
    a324:	eb02403f 	cmp	x1, x2, lsl #16
    a328:	54000322 	b.cs	a38c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a32c:	d350fc22 	lsr	x2, x1, #16
    a330:	d2800503 	mov	x3, #0x28                  	// #40
    a334:	f949fc04 	ldr	x4, [x0, #5112]
    a338:	9b037c42 	mul	x2, x2, x3
    a33c:	8b020083 	add	x3, x4, x2
    a340:	f9401060 	ldr	x0, [x3, #32]
    a344:	b4000240 	cbz	x0, a38c <fwp_main_thread+0x9ec>
    a348:	38626882 	ldrb	w2, [x4, x2]
    a34c:	7100085f 	cmp	w2, #0x2
    a350:	54001300 	b.eq	a5b0 <fwp_main_thread+0xc10>  // b.none
    a354:	7100045f 	cmp	w2, #0x1
    a358:	540001a1 	b.ne	a38c <fwp_main_thread+0x9ec>  // b.any
    a35c:	29430864 	ldp	w4, w2, [x3, #24]
    a360:	92403c21 	and	x1, x1, #0xffff
    a364:	9b047c21 	mul	x1, x1, x4
    a368:	d360fc21 	lsr	x1, x1, #32
    a36c:	eb02003f 	cmp	x1, x2
    a370:	540000e2 	b.cs	a38c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a374:	8b010000 	add	x0, x0, x1
    a378:	39400001 	ldrb	w1, [x0]
    a37c:	7103fc3f 	cmp	w1, #0xff
    a380:	540014e0 	b.eq	a61c <fwp_main_thread+0xc7c>  // b.none
    a384:	52800021 	mov	w1, #0x1                   	// #1
    a388:	39000001 	strb	w1, [x0]
    a38c:	aa1603e0 	mov	x0, x22
    a390:	91150264 	add	x4, x19, #0x540
    a394:	f949d881 	ldr	x1, [x4, #5040]
    a398:	f949ec82 	ldr	x2, [x4, #5080]
    a39c:	cb010001 	sub	x1, x0, x1
    a3a0:	eb02403f 	cmp	x1, x2, lsl #16
    a3a4:	54000382 	b.cs	a414 <fwp_main_thread+0xa74>  // b.hs, b.nlast
    a3a8:	d350fc23 	lsr	x3, x1, #16
    a3ac:	d2800502 	mov	x2, #0x28                  	// #40
    a3b0:	f949fc86 	ldr	x6, [x4, #5112]
    a3b4:	9b027c63 	mul	x3, x3, x2
    a3b8:	8b0300c5 	add	x5, x6, x3
    a3bc:	f94010a2 	ldr	x2, [x5, #32]
    a3c0:	b40002a2 	cbz	x2, a414 <fwp_main_thread+0xa74>
    a3c4:	386368c3 	ldrb	w3, [x6, x3]
    a3c8:	7100087f 	cmp	w3, #0x2
    a3cc:	540010a0 	b.eq	a5e0 <fwp_main_thread+0xc40>  // b.none
    a3d0:	7100047f 	cmp	w3, #0x1
    a3d4:	54000201 	b.ne	a414 <fwp_main_thread+0xa74>  // b.any
    a3d8:	29430ca6 	ldp	w6, w3, [x5, #24]
    a3dc:	92403c21 	and	x1, x1, #0xffff
    a3e0:	9b067c21 	mul	x1, x1, x6
    a3e4:	d360fc21 	lsr	x1, x1, #32
    a3e8:	eb03003f 	cmp	x1, x3
    a3ec:	54000142 	b.cs	a414 <fwp_main_thread+0xa74>  // b.hs, b.nlast
    a3f0:	8b010042 	add	x2, x2, x1
    a3f4:	39400041 	ldrb	w1, [x2]
    a3f8:	340000e1 	cbz	w1, a414 <fwp_main_thread+0xa74>
    a3fc:	7100043f 	cmp	w1, #0x1
    a400:	54000e40 	b.eq	a5c8 <fwp_main_thread+0xc28>  // b.none
    a404:	7103fc3f 	cmp	w1, #0xff
    a408:	540011a0 	b.eq	a63c <fwp_main_thread+0xc9c>  // b.none
    a40c:	51000421 	sub	w1, w1, #0x1
    a410:	39000041 	strb	w1, [x2]
    a414:	9100c2a3 	add	x3, x21, #0x30
    a418:	aa1b03e0 	mov	x0, x27
    a41c:	f9400382 	ldr	x2, [x28]
    a420:	aa0303fb 	mov	x27, x3
    a424:	f9400463 	ldr	x3, [x3, #8]
    a428:	d2800021 	mov	x1, #0x1                   	// #1
    a42c:	97ffe131 	bl	28f0 <fwrite@plt>
    a430:	f9400761 	ldr	x1, [x27, #8]
    a434:	52800140 	mov	w0, #0xa                   	// #10
    a438:	97ffe0b6 	bl	2710 <fputc@plt>
    a43c:	91150262 	add	x2, x19, #0x540
    a440:	f949d841 	ldr	x1, [x2, #5040]
    a444:	f949ec40 	ldr	x0, [x2, #5080]
    a448:	cb010381 	sub	x1, x28, x1
    a44c:	eb00403f 	cmp	x1, x0, lsl #16
    a450:	54000382 	b.cs	a4c0 <fwp_main_thread+0xb20>  // b.hs, b.nlast
    a454:	d350fc20 	lsr	x0, x1, #16
    a458:	d2800504 	mov	x4, #0x28                  	// #40
    a45c:	f949fc43 	ldr	x3, [x2, #5112]
    a460:	9b047c00 	mul	x0, x0, x4
    a464:	8b000062 	add	x2, x3, x0
    a468:	f940105b 	ldr	x27, [x2, #32]
    a46c:	b40002bb 	cbz	x27, a4c0 <fwp_main_thread+0xb20>
    a470:	38606863 	ldrb	w3, [x3, x0]
    a474:	7100087f 	cmp	w3, #0x2
    a478:	54000cc0 	b.eq	a610 <fwp_main_thread+0xc70>  // b.none
    a47c:	7100047f 	cmp	w3, #0x1
    a480:	54000201 	b.ne	a4c0 <fwp_main_thread+0xb20>  // b.any
    a484:	29431040 	ldp	w0, w4, [x2, #24]
    a488:	92403c21 	and	x1, x1, #0xffff
    a48c:	9b007c20 	mul	x0, x1, x0
    a490:	d360fc00 	lsr	x0, x0, #32
    a494:	eb04001f 	cmp	x0, x4
    a498:	54000142 	b.cs	a4c0 <fwp_main_thread+0xb20>  // b.hs, b.nlast
    a49c:	8b00037b 	add	x27, x27, x0
    a4a0:	39400360 	ldrb	w0, [x27]
    a4a4:	340000e0 	cbz	w0, a4c0 <fwp_main_thread+0xb20>
    a4a8:	7100041f 	cmp	w0, #0x1
    a4ac:	54000a00 	b.eq	a5ec <fwp_main_thread+0xc4c>  // b.none
    a4b0:	7103fc1f 	cmp	w0, #0xff
    a4b4:	54000e20 	b.eq	a678 <fwp_main_thread+0xcd8>  // b.none
    a4b8:	51000400 	sub	w0, w0, #0x1
    a4bc:	39000360 	strb	w0, [x27]
    a4c0:	f9400b5a 	ldr	x26, [x26, #16]
    a4c4:	b40004ba 	cbz	x26, a558 <fwp_main_thread+0xbb8>
    a4c8:	91150260 	add	x0, x19, #0x540
    a4cc:	f949ec03 	ldr	x3, [x0, #5080]
    a4d0:	f949d801 	ldr	x1, [x0, #5040]
    a4d4:	d370bc63 	lsl	x3, x3, #16
    a4d8:	cb0102c1 	sub	x1, x22, x1
    a4dc:	17ffff56 	b	a234 <fwp_main_thread+0x894>
    a4e0:	a90013e0 	stp	x0, x4, [sp]
    a4e4:	f9000be5 	str	x5, [sp, #16]
    a4e8:	97ffe66a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a4ec:	a94013e0 	ldp	x0, x4, [sp]
    a4f0:	f9400be5 	ldr	x5, [sp, #16]
    a4f4:	17fffdfb 	b	9ce0 <fwp_main_thread+0x340>
    a4f8:	aa0003e1 	mov	x1, x0
    a4fc:	f9002293 	str	x19, [x20, #64]
    a500:	17fffd85 	b	9b14 <fwp_main_thread+0x174>
    a504:	72003c3f 	tst	w1, #0xffff
    a508:	54ffdec1 	b.ne	a0e0 <fwp_main_thread+0x740>  // b.any
    a50c:	17fffef0 	b	a0cc <fwp_main_thread+0x72c>
    a510:	72003c3f 	tst	w1, #0xffff
    a514:	54ffe2e1 	b.ne	a170 <fwp_main_thread+0x7d0>  // b.any
    a518:	17ffff11 	b	a15c <fwp_main_thread+0x7bc>
    a51c:	72003c3f 	tst	w1, #0xffff
    a520:	54ffe7e1 	b.ne	a21c <fwp_main_thread+0x87c>  // b.any
    a524:	17ffff34 	b	a1f4 <fwp_main_thread+0x854>
    a528:	72003c3f 	tst	w1, #0xffff
    a52c:	54ffebc1 	b.ne	a2a4 <fwp_main_thread+0x904>  // b.any
    a530:	17ffff57 	b	a28c <fwp_main_thread+0x8ec>
    a534:	f9416a60 	ldr	x0, [x19, #720]
    a538:	97ffe6f2 	bl	4100 <fwp_mem_free>
    a53c:	f9016a7f 	str	xzr, [x19, #720]
    a540:	f9400a60 	ldr	x0, [x19, #16]
    a544:	f901727f 	str	xzr, [x19, #736]
    a548:	b4ffc6e0 	cbz	x0, 9e24 <fwp_main_thread+0x484>
    a54c:	f900541f 	str	xzr, [x0, #168]
    a550:	f9005c1f 	str	xzr, [x0, #184]
    a554:	17fffe34 	b	9e24 <fwp_main_thread+0x484>
    a558:	aa1603e0 	mov	x0, x22
    a55c:	97ffedaa 	bl	5c04 <fwp_drop0>
    a560:	aa1403e0 	mov	x0, x20
    a564:	97ffeda8 	bl	5c04 <fwp_drop0>
    a568:	9100c2a0 	add	x0, x21, #0x30
    a56c:	fd40c3e8 	ldr	d8, [sp, #384]
    a570:	a95773fb 	ldp	x27, x28, [sp, #368]
    a574:	52800021 	mov	w1, #0x1                   	// #1
    a578:	b902f801 	str	w1, [x0, #760]
    a57c:	f901801f 	str	xzr, [x0, #768]
    a580:	17fffd4c 	b	9ab0 <fwp_main_thread+0x110>
    a584:	aa1803e0 	mov	x0, x24
    a588:	97ffe642 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a58c:	17fffef7 	b	a168 <fwp_main_thread+0x7c8>
    a590:	aa1803e0 	mov	x0, x24
    a594:	97ffe63f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a598:	17ffff1a 	b	a200 <fwp_main_thread+0x860>
    a59c:	aa1803e0 	mov	x0, x24
    a5a0:	97ffe63c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a5a4:	17fffecd 	b	a0d8 <fwp_main_thread+0x738>
    a5a8:	97ffe74f 	bl	42e4 <fwp_rc_wide_dup>
    a5ac:	17ffff3e 	b	a2a4 <fwp_main_thread+0x904>
    a5b0:	72003c3f 	tst	w1, #0xffff
    a5b4:	54ffeec1 	b.ne	a38c <fwp_main_thread+0x9ec>  // b.any
    a5b8:	17ffff70 	b	a378 <fwp_main_thread+0x9d8>
    a5bc:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x180>
    a5c0:	91112000 	add	x0, x0, #0x448
    a5c4:	97ffe613 	bl	3e10 <fwp_trap>
    a5c8:	f9400801 	ldr	x1, [x0, #16]
    a5cc:	a90013e1 	stp	x1, x4, [sp]
    a5d0:	97ffece9 	bl	5974 <fwp_rc_free_arr>
    a5d4:	a94013e1 	ldp	x1, x4, [sp]
    a5d8:	aa0103e0 	mov	x0, x1
    a5dc:	17ffff6e 	b	a394 <fwp_main_thread+0x9f4>
    a5e0:	72003c3f 	tst	w1, #0xffff
    a5e4:	54fff181 	b.ne	a414 <fwp_main_thread+0xa74>  // b.any
    a5e8:	17ffff83 	b	a3f4 <fwp_main_thread+0xa54>
    a5ec:	7100087f 	cmp	w3, #0x2
    a5f0:	54000620 	b.eq	a6b4 <fwp_main_thread+0xd14>  // b.none
    a5f4:	29430043 	ldp	w3, w0, [x2, #24]
    a5f8:	9b037c21 	mul	x1, x1, x3
    a5fc:	eb41801f 	cmp	x0, x1, lsr #32
    a600:	54fff609 	b.ls	a4c0 <fwp_main_thread+0xb20>  // b.plast
    a604:	aa1c03e0 	mov	x0, x28
    a608:	97ffe6be 	bl	4100 <fwp_mem_free>
    a60c:	17ffffad 	b	a4c0 <fwp_main_thread+0xb20>
    a610:	f2403c21 	ands	x1, x1, #0xffff
    a614:	54fff561 	b.ne	a4c0 <fwp_main_thread+0xb20>  // b.any
    a618:	17ffffa2 	b	a4a0 <fwp_main_thread+0xb00>
    a61c:	f90003e0 	str	x0, [sp]
    a620:	97ffe61c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a624:	f94003e0 	ldr	x0, [sp]
    a628:	17ffff57 	b	a384 <fwp_main_thread+0x9e4>
    a62c:	a91773fb 	stp	x27, x28, [sp, #368]
    a630:	fd00c3e8 	str	d8, [sp, #384]
    a634:	97ffe06f 	bl	27f0 <__stack_chk_fail@plt>
    a638:	97ffe25e 	bl	2fb0 <fwp_heap_oom>
    a63c:	ca424441 	eor	x1, x2, x2, lsr #17
    a640:	91150260 	add	x0, x19, #0x540
    a644:	ca412421 	eor	x1, x1, x1, lsr #9
    a648:	92401c21 	and	x1, x1, #0xff
    a64c:	910a2423 	add	x3, x1, #0x289
    a650:	8b010c01 	add	x1, x0, x1, lsl #3
    a654:	8b030c03 	add	x3, x0, x3, lsl #3
    a658:	f94a2420 	ldr	x0, [x1, #5192]
    a65c:	b4000480 	cbz	x0, a6ec <fwp_main_thread+0xd4c>
    a660:	f9400001 	ldr	x1, [x0]
    a664:	eb01005f 	cmp	x2, x1
    a668:	540002a0 	b.eq	a6bc <fwp_main_thread+0xd1c>  // b.none
    a66c:	91004003 	add	x3, x0, #0x10
    a670:	f9400800 	ldr	x0, [x0, #16]
    a674:	17fffffa 	b	a65c <fwp_main_thread+0xcbc>
    a678:	ca5b4761 	eor	x1, x27, x27, lsr #17
    a67c:	91150260 	add	x0, x19, #0x540
    a680:	ca412421 	eor	x1, x1, x1, lsr #9
    a684:	92401c21 	and	x1, x1, #0xff
    a688:	910a2422 	add	x2, x1, #0x289
    a68c:	8b010c01 	add	x1, x0, x1, lsl #3
    a690:	8b020c02 	add	x2, x0, x2, lsl #3
    a694:	f94a2420 	ldr	x0, [x1, #5192]
    a698:	b40002a0 	cbz	x0, a6ec <fwp_main_thread+0xd4c>
    a69c:	f9400001 	ldr	x1, [x0]
    a6a0:	eb01037f 	cmp	x27, x1
    a6a4:	540002a0 	b.eq	a6f8 <fwp_main_thread+0xd58>  // b.none
    a6a8:	91004002 	add	x2, x0, #0x10
    a6ac:	f9400800 	ldr	x0, [x0, #16]
    a6b0:	17fffffa 	b	a698 <fwp_main_thread+0xcf8>
    a6b4:	b5fff061 	cbnz	x1, a4c0 <fwp_main_thread+0xb20>
    a6b8:	17ffffd3 	b	a604 <fwp_main_thread+0xc64>
    a6bc:	f9400061 	ldr	x1, [x3]
    a6c0:	f9400420 	ldr	x0, [x1, #8]
    a6c4:	d1000400 	sub	x0, x0, #0x1
    a6c8:	f9000420 	str	x0, [x1, #8]
    a6cc:	f103f81f 	cmp	x0, #0xfe
    a6d0:	54ffea21 	b.ne	a414 <fwp_main_thread+0xa74>  // b.any
    a6d4:	39400040 	ldrb	w0, [x2]
    a6d8:	7103fc1f 	cmp	w0, #0xff
    a6dc:	54000260 	b.eq	a728 <fwp_main_thread+0xd88>  // b.none
    a6e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a6e4:	39000040 	strb	w0, [x2]
    a6e8:	17ffff4b 	b	a414 <fwp_main_thread+0xa74>
    a6ec:	90000000 	adrp	x0, a000 <fwp_main_thread+0x660>
    a6f0:	913f0000 	add	x0, x0, #0xfc0
    a6f4:	97ffe5c7 	bl	3e10 <fwp_trap>
    a6f8:	f9400041 	ldr	x1, [x2]
    a6fc:	f9400420 	ldr	x0, [x1, #8]
    a700:	d1000400 	sub	x0, x0, #0x1
    a704:	f9000420 	str	x0, [x1, #8]
    a708:	f103f81f 	cmp	x0, #0xfe
    a70c:	54ffeda1 	b.ne	a4c0 <fwp_main_thread+0xb20>  // b.any
    a710:	39400360 	ldrb	w0, [x27]
    a714:	7103fc1f 	cmp	w0, #0xff
    a718:	54000120 	b.eq	a73c <fwp_main_thread+0xd9c>  // b.none
    a71c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a720:	39000360 	strb	w0, [x27]
    a724:	17ffff67 	b	a4c0 <fwp_main_thread+0xb20>
    a728:	aa0203e0 	mov	x0, x2
    a72c:	f90003e2 	str	x2, [sp]
    a730:	97ffe5d8 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a734:	f94003e2 	ldr	x2, [sp]
    a738:	17ffffea 	b	a6e0 <fwp_main_thread+0xd40>
    a73c:	aa1b03e0 	mov	x0, x27
    a740:	97ffe5d4 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a744:	17fffff6 	b	a71c <fwp_main_thread+0xd7c>
    a748:	a91773fb 	stp	x27, x28, [sp, #368]
    a74c:	fd00c3e8 	str	d8, [sp, #384]
    a750:	97ffe03c 	bl	2840 <abort@plt>
    a754:	d503201f 	nop
    a758:	d503201f 	nop
    a75c:	d503201f 	nop

000000000000a760 <__divti3>:
    a760:	d503245f 	bti	c
    a764:	d2800004 	mov	x4, #0x0                   	// #0
    a768:	b7f80721 	tbnz	x1, #63, a84c <__divti3+0xec>
    a76c:	b6f80083 	tbz	x3, #63, a77c <__divti3+0x1c>
    a770:	eb0203e2 	negs	x2, x2
    a774:	aa2403e4 	mvn	x4, x4
    a778:	da0303e3 	ngc	x3, x3
    a77c:	aa0203e6 	mov	x6, x2
    a780:	aa0003e7 	mov	x7, x0
    a784:	aa0103e5 	mov	x5, x1
    a788:	b5000583 	cbnz	x3, a838 <__divti3+0xd8>
    a78c:	eb01005f 	cmp	x2, x1
    a790:	54000e69 	b.ls	a95c <__divti3+0x1fc>  // b.plast
    a794:	dac01040 	clz	x0, x2
    a798:	b40000e0 	cbz	x0, a7b4 <__divti3+0x54>
    a79c:	4b0003e1 	neg	w1, w0
    a7a0:	9ac020a5 	lsl	x5, x5, x0
    a7a4:	9ac02046 	lsl	x6, x2, x0
    a7a8:	9ac124e1 	lsr	x1, x7, x1
    a7ac:	aa050025 	orr	x5, x1, x5
    a7b0:	9ac020e7 	lsl	x7, x7, x0
    a7b4:	d360fcc8 	lsr	x8, x6, #32
    a7b8:	92407cc2 	and	x2, x6, #0xffffffff
    a7bc:	9ac808a3 	udiv	x3, x5, x8
    a7c0:	9b089465 	msub	x5, x3, x8, x5
    a7c4:	aa0303e0 	mov	x0, x3
    a7c8:	9b037c41 	mul	x1, x2, x3
    a7cc:	93c780a5 	extr	x5, x5, x7, #32
    a7d0:	eb05003f 	cmp	x1, x5
    a7d4:	540000a9 	b.ls	a7e8 <__divti3+0x88>  // b.plast
    a7d8:	ab0500c5 	adds	x5, x6, x5
    a7dc:	d1000460 	sub	x0, x3, #0x1
    a7e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a7e4:	540015a8 	b.hi	aa98 <__divti3+0x338>  // b.pmore
    a7e8:	cb0100a5 	sub	x5, x5, x1
    a7ec:	9ac808a3 	udiv	x3, x5, x8
    a7f0:	9b089465 	msub	x5, x3, x8, x5
    a7f4:	aa0303e1 	mov	x1, x3
    a7f8:	9b037c42 	mul	x2, x2, x3
    a7fc:	aa0703e3 	mov	x3, x7
    a800:	b3607ca3 	bfi	x3, x5, #32, #32
    a804:	eb03005f 	cmp	x2, x3
    a808:	540000c9 	b.ls	a820 <__divti3+0xc0>  // b.plast
    a80c:	ab0300c3 	adds	x3, x6, x3
    a810:	d1000425 	sub	x5, x1, #0x1
    a814:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a818:	d1000821 	sub	x1, x1, #0x2
    a81c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a820:	aa008020 	orr	x0, x1, x0, lsl #32
    a824:	d2800001 	mov	x1, #0x0                   	// #0
    a828:	b4000064 	cbz	x4, a834 <__divti3+0xd4>
    a82c:	eb0003e0 	negs	x0, x0
    a830:	da0103e1 	ngc	x1, x1
    a834:	d65f03c0 	ret
    a838:	eb01007f 	cmp	x3, x1
    a83c:	54000109 	b.ls	a85c <__divti3+0xfc>  // b.plast
    a840:	d2800001 	mov	x1, #0x0                   	// #0
    a844:	d2800000 	mov	x0, #0x0                   	// #0
    a848:	17fffff8 	b	a828 <__divti3+0xc8>
    a84c:	eb0003e0 	negs	x0, x0
    a850:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a854:	da0103e1 	ngc	x1, x1
    a858:	17ffffc5 	b	a76c <__divti3+0xc>
    a85c:	dac01067 	clz	x7, x3
    a860:	b40010e7 	cbz	x7, aa7c <__divti3+0x31c>
    a864:	d2800805 	mov	x5, #0x40                  	// #64
    a868:	cb0700a5 	sub	x5, x5, x7
    a86c:	9ac72063 	lsl	x3, x3, x7
    a870:	9ac52448 	lsr	x8, x2, x5
    a874:	aa030108 	orr	x8, x8, x3
    a878:	9ac52426 	lsr	x6, x1, x5
    a87c:	92407d0a 	and	x10, x8, #0xffffffff
    a880:	d360fd09 	lsr	x9, x8, #32
    a884:	9ac52403 	lsr	x3, x0, x5
    a888:	9ac72021 	lsl	x1, x1, x7
    a88c:	aa010063 	orr	x3, x3, x1
    a890:	9ac72042 	lsl	x2, x2, x7
    a894:	9ac908cb 	udiv	x11, x6, x9
    a898:	9b099965 	msub	x5, x11, x9, x6
    a89c:	aa0b03e1 	mov	x1, x11
    a8a0:	9b0b7d46 	mul	x6, x10, x11
    a8a4:	93c380a5 	extr	x5, x5, x3, #32
    a8a8:	eb0500df 	cmp	x6, x5
    a8ac:	540000a9 	b.ls	a8c0 <__divti3+0x160>  // b.plast
    a8b0:	ab050105 	adds	x5, x8, x5
    a8b4:	d1000561 	sub	x1, x11, #0x1
    a8b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a8bc:	54000f48 	b.hi	aaa4 <__divti3+0x344>  // b.pmore
    a8c0:	cb0600a6 	sub	x6, x5, x6
    a8c4:	9ac908cb 	udiv	x11, x6, x9
    a8c8:	9b099969 	msub	x9, x11, x9, x6
    a8cc:	aa0b03e5 	mov	x5, x11
    a8d0:	9b0b7d4a 	mul	x10, x10, x11
    a8d4:	b3607d23 	bfi	x3, x9, #32, #32
    a8d8:	eb03015f 	cmp	x10, x3
    a8dc:	540000a9 	b.ls	a8f0 <__divti3+0x190>  // b.plast
    a8e0:	ab030103 	adds	x3, x8, x3
    a8e4:	d1000565 	sub	x5, x11, #0x1
    a8e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a8ec:	54000e28 	b.hi	aab0 <__divti3+0x350>  // b.pmore
    a8f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a8f4:	92407c48 	and	x8, x2, #0xffffffff
    a8f8:	2a0503e5 	mov	w5, w5
    a8fc:	d360fc42 	lsr	x2, x2, #32
    a900:	d360fc26 	lsr	x6, x1, #32
    a904:	cb0a0063 	sub	x3, x3, x10
    a908:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a90c:	9b087caa 	mul	x10, x5, x8
    a910:	9b087cc8 	mul	x8, x6, x8
    a914:	9b0220a5 	madd	x5, x5, x2, x8
    a918:	9b027cc6 	mul	x6, x6, x2
    a91c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a920:	8b0900c5 	add	x5, x6, x9
    a924:	eb02011f 	cmp	x8, x2
    a928:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a92c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a930:	eb06007f 	cmp	x3, x6
    a934:	540000e3 	b.cc	a950 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a938:	92407d4a 	and	x10, x10, #0xffffffff
    a93c:	9ac72000 	lsl	x0, x0, x7
    a940:	8b028142 	add	x2, x10, x2, lsl #32
    a944:	eb02001f 	cmp	x0, x2
    a948:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a94c:	54000a01 	b.ne	aa8c <__divti3+0x32c>  // b.any
    a950:	d1000420 	sub	x0, x1, #0x1
    a954:	d2800001 	mov	x1, #0x0                   	// #0
    a958:	17ffffb4 	b	a828 <__divti3+0xc8>
    a95c:	b5000062 	cbnz	x2, a968 <__divti3+0x208>
    a960:	d2800022 	mov	x2, #0x1                   	// #1
    a964:	9ac30846 	udiv	x6, x2, x3
    a968:	dac010c8 	clz	x8, x6
    a96c:	b5000408 	cbnz	x8, a9ec <__divti3+0x28c>
    a970:	d360fcc9 	lsr	x9, x6, #32
    a974:	92407cc5 	and	x5, x6, #0xffffffff
    a978:	cb060023 	sub	x3, x1, x6
    a97c:	d2800021 	mov	x1, #0x1                   	// #1
    a980:	9ac90868 	udiv	x8, x3, x9
    a984:	9b098d03 	msub	x3, x8, x9, x3
    a988:	aa0803e0 	mov	x0, x8
    a98c:	9b057d02 	mul	x2, x8, x5
    a990:	93c78063 	extr	x3, x3, x7, #32
    a994:	eb03005f 	cmp	x2, x3
    a998:	540000a9 	b.ls	a9ac <__divti3+0x24c>  // b.plast
    a99c:	ab0300c3 	adds	x3, x6, x3
    a9a0:	d1000500 	sub	x0, x8, #0x1
    a9a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a9a8:	54000968 	b.hi	aad4 <__divti3+0x374>  // b.pmore
    a9ac:	cb020063 	sub	x3, x3, x2
    a9b0:	9ac90862 	udiv	x2, x3, x9
    a9b4:	aa0203e8 	mov	x8, x2
    a9b8:	9b098c42 	msub	x2, x2, x9, x3
    a9bc:	aa0703e3 	mov	x3, x7
    a9c0:	9b057d05 	mul	x5, x8, x5
    a9c4:	b3607c43 	bfi	x3, x2, #32, #32
    a9c8:	eb0300bf 	cmp	x5, x3
    a9cc:	540000c9 	b.ls	a9e4 <__divti3+0x284>  // b.plast
    a9d0:	ab0300c2 	adds	x2, x6, x3
    a9d4:	d1000503 	sub	x3, x8, #0x1
    a9d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a9dc:	d1000908 	sub	x8, x8, #0x2
    a9e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a9e4:	aa008100 	orr	x0, x8, x0, lsl #32
    a9e8:	17ffff90 	b	a828 <__divti3+0xc8>
    a9ec:	9ac820c6 	lsl	x6, x6, x8
    a9f0:	d2800803 	mov	x3, #0x40                  	// #64
    a9f4:	cb080063 	sub	x3, x3, x8
    a9f8:	d360fcc9 	lsr	x9, x6, #32
    a9fc:	9ac82027 	lsl	x7, x1, x8
    aa00:	92407cc5 	and	x5, x6, #0xffffffff
    aa04:	9ac32422 	lsr	x2, x1, x3
    aa08:	9ac32403 	lsr	x3, x0, x3
    aa0c:	aa070063 	orr	x3, x3, x7
    aa10:	9ac9084a 	udiv	x10, x2, x9
    aa14:	9ac82007 	lsl	x7, x0, x8
    aa18:	9b098940 	msub	x0, x10, x9, x2
    aa1c:	aa0a03e1 	mov	x1, x10
    aa20:	9b0a7ca2 	mul	x2, x5, x10
    aa24:	93c38000 	extr	x0, x0, x3, #32
    aa28:	eb00005f 	cmp	x2, x0
    aa2c:	540000a9 	b.ls	aa40 <__divti3+0x2e0>  // b.plast
    aa30:	ab0000c0 	adds	x0, x6, x0
    aa34:	d1000541 	sub	x1, x10, #0x1
    aa38:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    aa3c:	54000468 	b.hi	aac8 <__divti3+0x368>  // b.pmore
    aa40:	cb020000 	sub	x0, x0, x2
    aa44:	9ac9080a 	udiv	x10, x0, x9
    aa48:	9b098140 	msub	x0, x10, x9, x0
    aa4c:	aa0a03e2 	mov	x2, x10
    aa50:	9b0a7ca8 	mul	x8, x5, x10
    aa54:	b3607c03 	bfi	x3, x0, #32, #32
    aa58:	eb03011f 	cmp	x8, x3
    aa5c:	540000a9 	b.ls	aa70 <__divti3+0x310>  // b.plast
    aa60:	ab0300c3 	adds	x3, x6, x3
    aa64:	d1000542 	sub	x2, x10, #0x1
    aa68:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    aa6c:	54000288 	b.hi	aabc <__divti3+0x35c>  // b.pmore
    aa70:	cb080063 	sub	x3, x3, x8
    aa74:	aa018041 	orr	x1, x2, x1, lsl #32
    aa78:	17ffffc2 	b	a980 <__divti3+0x220>
    aa7c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    aa80:	d2800001 	mov	x1, #0x0                   	// #0
    aa84:	9a9f87e0 	cset	x0, ls	// ls = plast
    aa88:	17ffff68 	b	a828 <__divti3+0xc8>
    aa8c:	aa0103e0 	mov	x0, x1
    aa90:	d2800001 	mov	x1, #0x0                   	// #0
    aa94:	17ffff65 	b	a828 <__divti3+0xc8>
    aa98:	d1000860 	sub	x0, x3, #0x2
    aa9c:	8b0600a5 	add	x5, x5, x6
    aaa0:	17ffff52 	b	a7e8 <__divti3+0x88>
    aaa4:	d1000961 	sub	x1, x11, #0x2
    aaa8:	8b0800a5 	add	x5, x5, x8
    aaac:	17ffff85 	b	a8c0 <__divti3+0x160>
    aab0:	d1000965 	sub	x5, x11, #0x2
    aab4:	8b080063 	add	x3, x3, x8
    aab8:	17ffff8e 	b	a8f0 <__divti3+0x190>
    aabc:	d1000942 	sub	x2, x10, #0x2
    aac0:	8b060063 	add	x3, x3, x6
    aac4:	17ffffeb 	b	aa70 <__divti3+0x310>
    aac8:	d1000941 	sub	x1, x10, #0x2
    aacc:	8b060000 	add	x0, x0, x6
    aad0:	17ffffdc 	b	aa40 <__divti3+0x2e0>
    aad4:	d1000900 	sub	x0, x8, #0x2
    aad8:	8b060063 	add	x3, x3, x6
    aadc:	17ffffb4 	b	a9ac <__divti3+0x24c>

000000000000aae0 <__modti3>:
    aae0:	d503245f 	bti	c
    aae4:	d2800004 	mov	x4, #0x0                   	// #0
    aae8:	b6f80081 	tbz	x1, #63, aaf8 <__modti3+0x18>
    aaec:	eb0003e0 	negs	x0, x0
    aaf0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    aaf4:	da0103e1 	ngc	x1, x1
    aaf8:	f100007f 	cmp	x3, #0x0
    aafc:	5400128b 	b.lt	ad4c <__modti3+0x26c>  // b.tstop
    ab00:	aa0003e7 	mov	x7, x0
    ab04:	aa0103e6 	mov	x6, x1
    ab08:	540004e1 	b.ne	aba4 <__modti3+0xc4>  // b.any
    ab0c:	eb02003f 	cmp	x1, x2
    ab10:	54000dc2 	b.cs	acc8 <__modti3+0x1e8>  // b.hs, b.nlast
    ab14:	dac01043 	clz	x3, x2
    ab18:	aa0303e5 	mov	x5, x3
    ab1c:	b40000e3 	cbz	x3, ab38 <__modti3+0x58>
    ab20:	4b0303e6 	neg	w6, w3
    ab24:	9ac32021 	lsl	x1, x1, x3
    ab28:	9ac32042 	lsl	x2, x2, x3
    ab2c:	9ac62406 	lsr	x6, x0, x6
    ab30:	aa0100c6 	orr	x6, x6, x1
    ab34:	9ac32007 	lsl	x7, x0, x3
    ab38:	d360fc40 	lsr	x0, x2, #32
    ab3c:	92407c43 	and	x3, x2, #0xffffffff
    ab40:	9ac008c1 	udiv	x1, x6, x0
    ab44:	9b009826 	msub	x6, x1, x0, x6
    ab48:	9b017c61 	mul	x1, x3, x1
    ab4c:	93c780c6 	extr	x6, x6, x7, #32
    ab50:	eb06003f 	cmp	x1, x6
    ab54:	540000a9 	b.ls	ab68 <__modti3+0x88>  // b.plast
    ab58:	ab060046 	adds	x6, x2, x6
    ab5c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ab60:	8b0200c8 	add	x8, x6, x2
    ab64:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ab68:	cb0100c6 	sub	x6, x6, x1
    ab6c:	9ac008c8 	udiv	x8, x6, x0
    ab70:	9b009901 	msub	x1, x8, x0, x6
    ab74:	aa0703e0 	mov	x0, x7
    ab78:	9b087c63 	mul	x3, x3, x8
    ab7c:	b3607c20 	bfi	x0, x1, #32, #32
    ab80:	eb00007f 	cmp	x3, x0
    ab84:	54001088 	b.hi	ad94 <__modti3+0x2b4>  // b.pmore
    ab88:	cb030000 	sub	x0, x0, x3
    ab8c:	9ac52400 	lsr	x0, x0, x5
    ab90:	d2800001 	mov	x1, #0x0                   	// #0
    ab94:	b4000064 	cbz	x4, aba0 <__modti3+0xc0>
    ab98:	eb0003e0 	negs	x0, x0
    ab9c:	da0103e1 	ngc	x1, x1
    aba0:	d65f03c0 	ret
    aba4:	dac01066 	clz	x6, x3
    aba8:	eb03003f 	cmp	x1, x3
    abac:	54ffff43 	b.cc	ab94 <__modti3+0xb4>  // b.lo, b.ul, b.last
    abb0:	93407cc5 	sxtw	x5, w6
    abb4:	d2800808 	mov	x8, #0x40                  	// #64
    abb8:	cb050108 	sub	x8, x8, x5
    abbc:	9ac62063 	lsl	x3, x3, x6
    abc0:	9ac62025 	lsl	x5, x1, x6
    abc4:	9ac82447 	lsr	x7, x2, x8
    abc8:	aa0300e7 	orr	x7, x7, x3
    abcc:	9ac82423 	lsr	x3, x1, x8
    abd0:	92407cec 	and	x12, x7, #0xffffffff
    abd4:	d360fcea 	lsr	x10, x7, #32
    abd8:	9ac82401 	lsr	x1, x0, x8
    abdc:	aa050021 	orr	x1, x1, x5
    abe0:	9ac62042 	lsl	x2, x2, x6
    abe4:	9ac62000 	lsl	x0, x0, x6
    abe8:	9aca086b 	udiv	x11, x3, x10
    abec:	9b0a8d63 	msub	x3, x11, x10, x3
    abf0:	aa0b03e5 	mov	x5, x11
    abf4:	9b0b7d89 	mul	x9, x12, x11
    abf8:	93c18063 	extr	x3, x3, x1, #32
    abfc:	eb03013f 	cmp	x9, x3
    ac00:	540000a9 	b.ls	ac14 <__modti3+0x134>  // b.plast
    ac04:	ab0300e3 	adds	x3, x7, x3
    ac08:	d1000565 	sub	x5, x11, #0x1
    ac0c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ac10:	54001168 	b.hi	ae3c <__modti3+0x35c>  // b.pmore
    ac14:	cb090063 	sub	x3, x3, x9
    ac18:	9aca086b 	udiv	x11, x3, x10
    ac1c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ac20:	aa0b03e9 	mov	x9, x11
    ac24:	9b0b7d8c 	mul	x12, x12, x11
    ac28:	b3607d41 	bfi	x1, x10, #32, #32
    ac2c:	eb01019f 	cmp	x12, x1
    ac30:	540000a9 	b.ls	ac44 <__modti3+0x164>  // b.plast
    ac34:	ab0100e1 	adds	x1, x7, x1
    ac38:	d1000569 	sub	x9, x11, #0x1
    ac3c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ac40:	54000f88 	b.hi	ae30 <__modti3+0x350>  // b.pmore
    ac44:	aa058123 	orr	x3, x9, x5, lsl #32
    ac48:	92407c4b 	and	x11, x2, #0xffffffff
    ac4c:	2a0903e9 	mov	w9, w9
    ac50:	d360fc4a 	lsr	x10, x2, #32
    ac54:	d360fc63 	lsr	x3, x3, #32
    ac58:	cb0c0021 	sub	x1, x1, x12
    ac5c:	aa0a03ec 	mov	x12, x10
    ac60:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ac64:	9b0b7d25 	mul	x5, x9, x11
    ac68:	9b0b7c6b 	mul	x11, x3, x11
    ac6c:	9b0a2d29 	madd	x9, x9, x10, x11
    ac70:	92407caa 	and	x10, x5, #0xffffffff
    ac74:	9b0c7c63 	mul	x3, x3, x12
    ac78:	8b458125 	add	x5, x9, x5, lsr #32
    ac7c:	8b0d0069 	add	x9, x3, x13
    ac80:	eb05017f 	cmp	x11, x5
    ac84:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ac88:	8b058149 	add	x9, x10, x5, lsl #32
    ac8c:	8b458063 	add	x3, x3, x5, lsr #32
    ac90:	eb03003f 	cmp	x1, x3
    ac94:	54000063 	b.cc	aca0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ac98:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ac9c:	54000082 	b.cs	acac <__modti3+0x1cc>  // b.hs, b.nlast
    aca0:	eb020129 	subs	x9, x9, x2
    aca4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    aca8:	cb070063 	sub	x3, x3, x7
    acac:	eb090000 	subs	x0, x0, x9
    acb0:	da030021 	sbc	x1, x1, x3
    acb4:	9ac62400 	lsr	x0, x0, x6
    acb8:	9ac82028 	lsl	x8, x1, x8
    acbc:	aa000100 	orr	x0, x8, x0
    acc0:	9ac62421 	lsr	x1, x1, x6
    acc4:	17ffffb4 	b	ab94 <__modti3+0xb4>
    acc8:	b5000062 	cbnz	x2, acd4 <__modti3+0x1f4>
    accc:	d2800023 	mov	x3, #0x1                   	// #1
    acd0:	9ac20862 	udiv	x2, x3, x2
    acd4:	dac01048 	clz	x8, x2
    acd8:	aa0803e5 	mov	x5, x8
    acdc:	b5000668 	cbnz	x8, ada8 <__modti3+0x2c8>
    ace0:	cb020020 	sub	x0, x1, x2
    ace4:	d360fc49 	lsr	x9, x2, #32
    ace8:	92407c4a 	and	x10, x2, #0xffffffff
    acec:	9ac90801 	udiv	x1, x0, x9
    acf0:	9b098020 	msub	x0, x1, x9, x0
    acf4:	9b0a7c21 	mul	x1, x1, x10
    acf8:	93c78000 	extr	x0, x0, x7, #32
    acfc:	eb00003f 	cmp	x1, x0
    ad00:	540000a9 	b.ls	ad14 <__modti3+0x234>  // b.plast
    ad04:	ab000040 	adds	x0, x2, x0
    ad08:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ad0c:	8b020003 	add	x3, x0, x2
    ad10:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ad14:	cb010001 	sub	x1, x0, x1
    ad18:	9ac90820 	udiv	x0, x1, x9
    ad1c:	9b098403 	msub	x3, x0, x9, x1
    ad20:	aa0703e1 	mov	x1, x7
    ad24:	9b0a7c00 	mul	x0, x0, x10
    ad28:	b3607c61 	bfi	x1, x3, #32, #32
    ad2c:	eb01001f 	cmp	x0, x1
    ad30:	540000a9 	b.ls	ad44 <__modti3+0x264>  // b.plast
    ad34:	ab010041 	adds	x1, x2, x1
    ad38:	8b020022 	add	x2, x1, x2
    ad3c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ad40:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ad44:	cb000020 	sub	x0, x1, x0
    ad48:	17ffff91 	b	ab8c <__modti3+0xac>
    ad4c:	eb0203e5 	negs	x5, x2
    ad50:	aa0003e7 	mov	x7, x0
    ad54:	da0303e8 	ngc	x8, x3
    ad58:	aa0503e2 	mov	x2, x5
    ad5c:	aa0803e3 	mov	x3, x8
    ad60:	aa0103e6 	mov	x6, x1
    ad64:	b4ffed48 	cbz	x8, ab0c <__modti3+0x2c>
    ad68:	eb01011f 	cmp	x8, x1
    ad6c:	54fff148 	b.hi	ab94 <__modti3+0xb4>  // b.pmore
    ad70:	dac01109 	clz	x9, x8
    ad74:	2a0903e6 	mov	w6, w9
    ad78:	b5fff1c9 	cbnz	x9, abb0 <__modti3+0xd0>
    ad7c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ad80:	54000068 	b.hi	ad8c <__modti3+0x2ac>  // b.pmore
    ad84:	eb050007 	subs	x7, x0, x5
    ad88:	da080021 	sbc	x1, x1, x8
    ad8c:	aa0703e0 	mov	x0, x7
    ad90:	17ffff81 	b	ab94 <__modti3+0xb4>
    ad94:	ab000040 	adds	x0, x2, x0
    ad98:	8b020002 	add	x2, x0, x2
    ad9c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    ada0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    ada4:	17ffff79 	b	ab88 <__modti3+0xa8>
    ada8:	9ac82042 	lsl	x2, x2, x8
    adac:	d2800803 	mov	x3, #0x40                  	// #64
    adb0:	cb080063 	sub	x3, x3, x8
    adb4:	d360fc49 	lsr	x9, x2, #32
    adb8:	9ac82027 	lsl	x7, x1, x8
    adbc:	92407c4a 	and	x10, x2, #0xffffffff
    adc0:	9ac32426 	lsr	x6, x1, x3
    adc4:	9ac32403 	lsr	x3, x0, x3
    adc8:	aa070063 	orr	x3, x3, x7
    adcc:	9ac908c1 	udiv	x1, x6, x9
    add0:	9ac82007 	lsl	x7, x0, x8
    add4:	9b099820 	msub	x0, x1, x9, x6
    add8:	9b017d41 	mul	x1, x10, x1
    addc:	93c38000 	extr	x0, x0, x3, #32
    ade0:	eb00003f 	cmp	x1, x0
    ade4:	540000a9 	b.ls	adf8 <__modti3+0x318>  // b.plast
    ade8:	ab000040 	adds	x0, x2, x0
    adec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    adf0:	8b020006 	add	x6, x0, x2
    adf4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    adf8:	cb010000 	sub	x0, x0, x1
    adfc:	9ac90801 	udiv	x1, x0, x9
    ae00:	9b098026 	msub	x6, x1, x9, x0
    ae04:	aa0303e0 	mov	x0, x3
    ae08:	9b017d41 	mul	x1, x10, x1
    ae0c:	b3607cc0 	bfi	x0, x6, #32, #32
    ae10:	eb00003f 	cmp	x1, x0
    ae14:	540000a9 	b.ls	ae28 <__modti3+0x348>  // b.plast
    ae18:	ab000040 	adds	x0, x2, x0
    ae1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ae20:	8b020003 	add	x3, x0, x2
    ae24:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ae28:	cb010000 	sub	x0, x0, x1
    ae2c:	17ffffb0 	b	acec <__modti3+0x20c>
    ae30:	d1000969 	sub	x9, x11, #0x2
    ae34:	8b070021 	add	x1, x1, x7
    ae38:	17ffff83 	b	ac44 <__modti3+0x164>
    ae3c:	d1000965 	sub	x5, x11, #0x2
    ae40:	8b070063 	add	x3, x3, x7
    ae44:	17ffff74 	b	ac14 <__modti3+0x134>
    ae48:	d503201f 	nop
    ae4c:	d503201f 	nop

000000000000ae50 <atexit>:
    ae50:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ae54:	d00000a2 	adrp	x2, 20000 <__data_start>
    ae58:	d2800001 	mov	x1, #0x0                   	// #0
    ae5c:	910003fd 	mov	x29, sp
    ae60:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ae64:	f9400442 	ldr	x2, [x2, #8]
    ae68:	17ffde22 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ae6c <_fini>:
    ae6c:	d503201f 	nop
    ae70:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ae74:	910003fd 	mov	x29, sp
    ae78:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ae7c:	d65f03c0 	ret
