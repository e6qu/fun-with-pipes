
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__modti3+0x1b0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9115c0a5 	add	x5, x5, #0x570
    2aa0:	b0000044 	adrp	x4, b000 <__modti3+0x1b0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9115e084 	add	x4, x4, #0x578
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000590 	bl	4110 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10b60>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9006420 	str	x0, [x1, #200]
    2b2c:	94000799 	bl	4990 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2b34:	91222000 	add	x0, x0, #0x888
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x300>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	9133c042 	add	x2, x2, #0xcf0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435aa0 	ldr	w0, [x21, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2c4c:	9122e000 	add	x0, x0, #0x8b8
    2c50:	94000530 	bl	4110 <fwp_trap>
    2c54:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2c58:	91226000 	add	x0, x0, #0x898
    2c5c:	9400052d 	bl	4110 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2ca0:	91244000 	add	x0, x0, #0x910
    2ca4:	9400051b 	bl	4110 <fwp_trap>
    2ca8:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2cac:	91238000 	add	x0, x0, #0x8e0
    2cb0:	94000518 	bl	4110 <fwp_trap>
    2cb4:	b0000040 	adrp	x0, b000 <__modti3+0x1b0>
    2cb8:	9124e000 	add	x0, x0, #0x938
    2cbc:	94000515 	bl	4110 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91016000 	add	x0, x0, #0x58
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91016021 	add	x1, x1, #0x58
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91016000 	add	x0, x0, #0x58
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91016021 	add	x1, x1, #0x58
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <__modti3+0x1b0>
    2eb4:	913e8021 	add	x1, x1, #0xfa0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3050:	9107e000 	add	x0, x0, #0x1f8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <__modti3+0x1b0>
    3118:	913e0021 	add	x1, x1, #0xf80
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3150:	91084000 	add	x0, x0, #0x210
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__modti3+0x1b0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__modti3+0x1b0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	90000058 	adrp	x24, b000 <__modti3+0x1b0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	91096042 	add	x2, x2, #0x258
    31e0:	910ac2d6 	add	x22, x22, #0x2b0
    31e4:	91342318 	add	x24, x24, #0xd08
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__modti3+0x1b0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	910aa323 	add	x3, x25, #0x2a8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	910b0000 	add	x0, x0, #0x2c0
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3570:	9107e000 	add	x0, x0, #0x1f8
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__modti3+0x1b0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	910b2021 	add	x1, x1, #0x2c8
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__modti3+0x1b0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	910b4021 	add	x1, x1, #0x2d0
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__modti3+0x1b0>
    37e0:	910b6021 	add	x1, x1, #0x2d8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	90000044 	adrp	x4, b000 <__modti3+0x1b0>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	910b8084 	add	x4, x4, #0x2e0
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe3 	bl	27f0 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc3c 	bl	2960 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc27 	bl	2920 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb70 	bl	26d0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffba8 	bl	27d0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb99 	bl	27d0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb51 	bl	26d0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb5d 	bl	2710 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbed 	bl	2960 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	90000044 	adrp	x4, b000 <__modti3+0x1b0>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	910be084 	add	x4, x4, #0x2f8
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb6e 	bl	27f0 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb5d 	bl	27d0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbbd 	bl	2960 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	90000044 	adrp	x4, b000 <__modti3+0x1b0>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	910ba084 	add	x4, x4, #0x2e8
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb46 	bl	27f0 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb30 	bl	27d0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb04 	bl	27d0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb20 	bl	2880 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c0c:	91174042 	add	x2, x2, #0x5d0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	90000041 	adrp	x1, b000 <__modti3+0x1b0>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	910c0021 	add	x1, x1, #0x300
    3c68:	910c2000 	add	x0, x0, #0x308
    3c6c:	97fffae9 	bl	2810 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb13 	bl	2920 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac3 	bl	2800 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	90000042 	adrp	x2, b000 <__modti3+0x1b0>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	910ca042 	add	x2, x2, #0x328
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffae6 	b	28f0 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffac6 	bl	2880 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3d78:	91134061 	add	x1, x3, #0x4d0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3d88:	91174262 	add	x2, x19, #0x5d0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	90000042 	adrp	x2, b000 <__modti3+0x1b0>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3dbc:	91144021 	add	x1, x1, #0x510
    3dc0:	3dc3ec43 	ldr	q3, [x2, #4016]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3dec:	91134063 	add	x3, x3, #0x4d0
    3df0:	9115c084 	add	x4, x4, #0x570
    3df4:	91174266 	add	x6, x19, #0x5d0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaa9 	bl	2910 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91174275 	add	x21, x19, #0x5d0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa93 	bl	2910 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	90000040 	adrp	x0, b000 <__modti3+0x1b0>
    3ed8:	910ec000 	add	x0, x0, #0x3b0
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffacc 	bl	2a10 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91174273 	add	x19, x19, #0x5d0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9401400 	ldr	x0, [x0, #40]
    4004:	b7f80760 	tbnz	x0, #63, 40f0 <fwp_tape_buffers_release+0x100>
    4008:	f9401a61 	ldr	x1, [x19, #48]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    403c:	910f0000 	add	x0, x0, #0x3c0
    4040:	97fffa74 	bl	2a10 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	910f0000 	add	x0, x0, #0x3c0
    4078:	97fffa66 	bl	2a10 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400a61 	ldp	q1, q2, [x19]
    40b8:	f90062d4 	str	x20, [x22, #192]
    40bc:	4f000400 	movi	v0.4s, #0x0
    40c0:	ad000aa1 	stp	q1, q2, [x21]
    40c4:	3dc00a61 	ldr	q1, [x19, #32]
    40c8:	3d800aa1 	str	q1, [x21, #32]
    40cc:	f9401a60 	ldr	x0, [x19, #48]
    40d0:	f9001aa0 	str	x0, [x21, #48]
    40d4:	f9001a7f 	str	xzr, [x19, #48]
    40d8:	ad000260 	stp	q0, q0, [x19]
    40dc:	3d800a60 	str	q0, [x19, #32]
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40ec:	d65f03c0 	ret
    40f0:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    40f4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f8:	910f0000 	add	x0, x0, #0x3c0
    40fc:	97fffa45 	bl	2a10 <getenv@plt>
    4100:	b5fffa40 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    4104:	17ffffd6 	b	405c <fwp_tape_buffers_release+0x6c>
    4108:	d503201f 	nop
    410c:	d503201f 	nop

0000000000004110 <fwp_trap>:
    4110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4114:	900000e2 	adrp	x2, 20000 <__data_start>
    4118:	d53bd041 	mrs	x1, tpidr_el0
    411c:	910003fd 	mov	x29, sp
    4120:	f9403c42 	ldr	x2, [x2, #120]
    4124:	91400021 	add	x1, x1, #0x0, lsl #12
    4128:	91004021 	add	x1, x1, #0x10
    412c:	a90153f3 	stp	x19, x20, [sp, #16]
    4130:	aa0003f3 	mov	x19, x0
    4134:	f9400034 	ldr	x20, [x1]
    4138:	b4000062 	cbz	x2, 4144 <fwp_trap+0x34>
    413c:	aa0203e0 	mov	x0, x2
    4140:	97fffa1c 	bl	29b0 <fflush@plt>
    4144:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4148:	f947ec00 	ldr	x0, [x0, #4056]
    414c:	f9400000 	ldr	x0, [x0]
    4150:	97fffa18 	bl	29b0 <fflush@plt>
    4154:	aa1303e3 	mov	x3, x19
    4158:	f0000022 	adrp	x2, b000 <__modti3+0x1b0>
    415c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    4160:	f947ea73 	ldr	x19, [x19, #4048]
    4164:	910f6042 	add	x2, x2, #0x3d8
    4168:	52800041 	mov	w1, #0x2                   	// #2
    416c:	f9400260 	ldr	x0, [x19]
    4170:	97fff9e0 	bl	28f0 <__fprintf_chk@plt>
    4174:	b40000b4 	cbz	x20, 4188 <fwp_trap+0x78>
    4178:	f9400260 	ldr	x0, [x19]
    417c:	97fffa0d 	bl	29b0 <fflush@plt>
    4180:	52800ca0 	mov	w0, #0x65                  	// #101
    4184:	97fffa1b 	bl	29f0 <_Exit@plt>
    4188:	52800ca0 	mov	w0, #0x65                  	// #101
    418c:	97fff969 	bl	2730 <exit@plt>

0000000000004190 <fwp_rc_forget_slot.part.0>:
    4190:	ca404401 	eor	x1, x0, x0, lsr #17
    4194:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4198:	ca412421 	eor	x1, x1, x1, lsr #9
    419c:	910003fd 	mov	x29, sp
    41a0:	92401c21 	and	x1, x1, #0xff
    41a4:	f9000bf3 	str	x19, [sp, #16]
    41a8:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    41ac:	91174262 	add	x2, x19, #0x5d0
    41b0:	910a2423 	add	x3, x1, #0x289
    41b4:	8b010c41 	add	x1, x2, x1, lsl #3
    41b8:	8b030c43 	add	x3, x2, x3, lsl #3
    41bc:	f94a2421 	ldr	x1, [x1, #5192]
    41c0:	b50000a1 	cbnz	x1, 41d4 <fwp_rc_forget_slot.part.0+0x44>
    41c4:	14000012 	b	420c <fwp_rc_forget_slot.part.0+0x7c>
    41c8:	91004023 	add	x3, x1, #0x10
    41cc:	f9400821 	ldr	x1, [x1, #16]
    41d0:	b40001e1 	cbz	x1, 420c <fwp_rc_forget_slot.part.0+0x7c>
    41d4:	f9400022 	ldr	x2, [x1]
    41d8:	eb02001f 	cmp	x0, x2
    41dc:	54ffff61 	b.ne	41c8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41e0:	f9400060 	ldr	x0, [x3]
    41e4:	91174273 	add	x19, x19, #0x5d0
    41e8:	f9400801 	ldr	x1, [x0, #16]
    41ec:	f9000061 	str	x1, [x3]
    41f0:	97fff9d4 	bl	2940 <free@plt>
    41f4:	f94e2660 	ldr	x0, [x19, #7240]
    41f8:	d1000400 	sub	x0, x0, #0x1
    41fc:	f90e2660 	str	x0, [x19, #7240]
    4200:	f9400bf3 	ldr	x19, [sp, #16]
    4204:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4208:	d65f03c0 	ret
    420c:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4210:	910fa000 	add	x0, x0, #0x3e8
    4214:	97ffffbf 	bl	4110 <fwp_trap>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_rc_prepare_chunk>:
    4220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4224:	910003fd 	mov	x29, sp
    4228:	a9025bf5 	stp	x21, x22, [sp, #32]
    422c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4230:	911742c2 	add	x2, x22, #0x5d0
    4234:	b9401c03 	ldr	w3, [x0, #28]
    4238:	aa0103f5 	mov	x21, x1
    423c:	a90153f3 	stp	x19, x20, [sp, #16]
    4240:	aa0003f4 	mov	x20, x0
    4244:	f94e2440 	ldr	x0, [x2, #7240]
    4248:	b4000440 	cbz	x0, 42d0 <fwp_rc_prepare_chunk+0xb0>
    424c:	d2800013 	mov	x19, #0x0                   	// #0
    4250:	35000203 	cbnz	w3, 4290 <fwp_rc_prepare_chunk+0x70>
    4254:	b4000361 	cbz	x1, 42c0 <fwp_rc_prepare_chunk+0xa0>
    4258:	f9401280 	ldr	x0, [x20, #32]
    425c:	97fff9b9 	bl	2940 <free@plt>
    4260:	aa1503e0 	mov	x0, x21
    4264:	d2800021 	mov	x1, #0x1                   	// #1
    4268:	97fff97e 	bl	2860 <calloc@plt>
    426c:	f9001280 	str	x0, [x20, #32]
    4270:	b5000460 	cbnz	x0, 42fc <fwp_rc_prepare_chunk+0xdc>
    4274:	97fffb6f 	bl	3030 <fwp_heap_oom>
    4278:	97ffffc6 	bl	4190 <fwp_rc_forget_slot.part.0>
    427c:	91000673 	add	x19, x19, #0x1
    4280:	b9401e83 	ldr	w3, [x20, #28]
    4284:	eb13007f 	cmp	x3, x19
    4288:	54000169 	b.ls	42b4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    428c:	d503201f 	nop
    4290:	f9401283 	ldr	x3, [x20, #32]
    4294:	8b130060 	add	x0, x3, x19
    4298:	38736863 	ldrb	w3, [x3, x19]
    429c:	7103fc7f 	cmp	w3, #0xff
    42a0:	54fffec0 	b.eq	4278 <fwp_rc_prepare_chunk+0x58>  // b.none
    42a4:	b9401e83 	ldr	w3, [x20, #28]
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb13007f 	cmp	x3, x19
    42b0:	54ffff08 	b.hi	4290 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42b4:	eb0302bf 	cmp	x21, x3
    42b8:	54000121 	b.ne	42dc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42bc:	b5000335 	cbnz	x21, 4320 <fwp_rc_prepare_chunk+0x100>
    42c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42cc:	d65f03c0 	ret
    42d0:	2a0303e3 	mov	w3, w3
    42d4:	eb0302bf 	cmp	x21, x3
    42d8:	54ffff20 	b.eq	42bc <fwp_rc_prepare_chunk+0x9c>  // b.none
    42dc:	911742c2 	add	x2, x22, #0x5d0
    42e0:	f9401280 	ldr	x0, [x20, #32]
    42e4:	f94e2841 	ldr	x1, [x2, #7248]
    42e8:	cb030021 	sub	x1, x1, x3
    42ec:	f90e2841 	str	x1, [x2, #7248]
    42f0:	97fff994 	bl	2940 <free@plt>
    42f4:	b5fffb75 	cbnz	x21, 4260 <fwp_rc_prepare_chunk+0x40>
    42f8:	f900129f 	str	xzr, [x20, #32]
    42fc:	911742d6 	add	x22, x22, #0x5d0
    4300:	f94e2ac0 	ldr	x0, [x22, #7248]
    4304:	b9001e95 	str	w21, [x20, #28]
    4308:	a94153f3 	ldp	x19, x20, [sp, #16]
    430c:	8b150000 	add	x0, x0, x21
    4310:	f90e2ac0 	str	x0, [x22, #7248]
    4314:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4318:	a8c37bfd 	ldp	x29, x30, [sp], #48
    431c:	d65f03c0 	ret
    4320:	f9401280 	ldr	x0, [x20, #32]
    4324:	aa1503e2 	mov	x2, x21
    4328:	a94153f3 	ldp	x19, x20, [sp, #16]
    432c:	52800001 	mov	w1, #0x0                   	// #0
    4330:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4334:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4338:	17fff946 	b	2850 <memset@plt>
    433c:	d503201f 	nop

0000000000004340 <fwp_heap_refill>:
    4340:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4344:	910003fd 	mov	x29, sp
    4348:	a9025bf5 	stp	x21, x22, [sp, #32]
    434c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4350:	911742b5 	add	x21, x21, #0x5d0
    4354:	aa0003f6 	mov	x22, x0
    4358:	d2800020 	mov	x0, #0x1                   	// #1
    435c:	a90153f3 	stp	x19, x20, [sp, #16]
    4360:	a90363f7 	stp	x23, x24, [sp, #48]
    4364:	2a0103f7 	mov	w23, w1
    4368:	2a0203f8 	mov	w24, w2
    436c:	97fffbd1 	bl	32b0 <fwp_heap_chunks>
    4370:	aa0003f3 	mov	x19, x0
    4374:	f949fea2 	ldr	x2, [x21, #5112]
    4378:	8b000800 	add	x0, x0, x0, lsl #2
    437c:	2a1703e1 	mov	w1, w23
    4380:	52800025 	mov	w5, #0x1                   	// #1
    4384:	d37df000 	lsl	x0, x0, #3
    4388:	910f0021 	add	x1, x1, #0x3c0
    438c:	8b000054 	add	x20, x2, x0
    4390:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4394:	52a00024 	mov	w4, #0x10000               	// #65536
    4398:	38206845 	strb	w5, [x2, x0]
    439c:	aa1403e0 	mov	x0, x20
    43a0:	39000698 	strb	w24, [x20, #1]
    43a4:	39000a97 	strb	w23, [x20, #2]
    43a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    43ac:	b9000681 	str	w1, [x20, #4]
    43b0:	2a0103e5 	mov	w5, w1
    43b4:	8b0300a2 	add	x2, x5, x3
    43b8:	1ac10881 	udiv	w1, w4, w1
    43bc:	9ac50842 	udiv	x2, x2, x5
    43c0:	b9000a81 	str	w1, [x20, #8]
    43c4:	92404021 	and	x1, x1, #0x1ffff
    43c8:	b9001a82 	str	w2, [x20, #24]
    43cc:	97ffff95 	bl	4220 <fwp_rc_prepare_chunk>
    43d0:	f949daa0 	ldr	x0, [x21, #5040]
    43d4:	29408a81 	ldp	w1, w2, [x20, #4]
    43d8:	8b134000 	add	x0, x0, x19, lsl #16
    43dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e0:	8b214003 	add	x3, x0, w1, uxtw
    43e4:	9ba20021 	umaddl	x1, w1, w2, x0
    43e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43ec:	a90086c3 	stp	x3, x1, [x22, #8]
    43f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43f8:	d65f03c0 	ret
    43fc:	d503201f 	nop

0000000000004400 <fwp_mem_free>:
    4400:	b40003c0 	cbz	x0, 4478 <fwp_mem_free+0x78>
    4404:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4408:	910003fd 	mov	x29, sp
    440c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4410:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4414:	911742a1 	add	x1, x21, #0x5d0
    4418:	a90153f3 	stp	x19, x20, [sp, #16]
    441c:	aa0003f3 	mov	x19, x0
    4420:	f949d823 	ldr	x3, [x1, #5040]
    4424:	f949ec22 	ldr	x2, [x1, #5080]
    4428:	cb030000 	sub	x0, x0, x3
    442c:	eb02401f 	cmp	x0, x2, lsl #16
    4430:	540001c2 	b.cs	4468 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4434:	d350fc16 	lsr	x22, x0, #16
    4438:	a90363f7 	stp	x23, x24, [sp, #48]
    443c:	f949fc22 	ldr	x2, [x1, #5112]
    4440:	8b160ad4 	add	x20, x22, x22, lsl #2
    4444:	d37df294 	lsl	x20, x20, #3
    4448:	ab140057 	adds	x23, x2, x20
    444c:	540000c0 	b.eq	4464 <fwp_mem_free+0x64>  // b.none
    4450:	38746842 	ldrb	w2, [x2, x20]
    4454:	7100045f 	cmp	w2, #0x1
    4458:	54000120 	b.eq	447c <fwp_mem_free+0x7c>  // b.none
    445c:	7100085f 	cmp	w2, #0x2
    4460:	540005e0 	b.eq	451c <fwp_mem_free+0x11c>  // b.none
    4464:	a94363f7 	ldp	x23, x24, [sp, #48]
    4468:	a94153f3 	ldp	x19, x20, [sp, #16]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4474:	d65f03c0 	ret
    4478:	d65f03c0 	ret
    447c:	f94012f8 	ldr	x24, [x23, #32]
    4480:	b94006e1 	ldr	w1, [x23, #4]
    4484:	f90023f9 	str	x25, [sp, #64]
    4488:	2a0103e2 	mov	w2, w1
    448c:	394006f9 	ldrb	w25, [x23, #1]
    4490:	39400af4 	ldrb	w20, [x23, #2]
    4494:	b4000158 	cbz	x24, 44bc <fwp_mem_free+0xbc>
    4498:	92403e76 	and	x22, x19, #0xffff
    449c:	9ac20ad6 	udiv	x22, x22, x2
    44a0:	38766b01 	ldrb	w1, [x24, x22]
    44a4:	8b160300 	add	x0, x24, x22
    44a8:	7103fc3f 	cmp	w1, #0xff
    44ac:	54000980 	b.eq	45dc <fwp_mem_free+0x1dc>  // b.none
    44b0:	38366b1f 	strb	wzr, [x24, x22]
    44b4:	b94006e1 	ldr	w1, [x23, #4]
    44b8:	2a0103e2 	mov	w2, w1
    44bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44c4:	cb390000 	sub	x0, x0, w25, uxtb
    44c8:	8b340074 	add	x20, x3, w20, uxtb
    44cc:	911742b5 	add	x21, x21, #0x5d0
    44d0:	1e630021 	ucvtf	d1, w1
    44d4:	d37ae400 	lsl	x0, x0, #6
    44d8:	8b140c14 	add	x20, x0, x20, lsl #3
    44dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e0:	f8746aa0 	ldr	x0, [x21, x20]
    44e4:	f94023f9 	ldr	x25, [sp, #64]
    44e8:	aa2003e0 	mvn	x0, x0
    44ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    44f0:	f9000260 	str	x0, [x19]
    44f4:	f8346ab3 	str	x19, [x21, x20]
    44f8:	f94a12a0 	ldr	x0, [x21, #5152]
    44fc:	1e612800 	fadd	d0, d0, d1
    4500:	a94153f3 	ldp	x19, x20, [sp, #16]
    4504:	cb020000 	sub	x0, x0, x2
    4508:	f90a12a0 	str	x0, [x21, #5152]
    450c:	fd0a22a0 	str	d0, [x21, #5184]
    4510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4514:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4518:	d65f03c0 	ret
    451c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4520:	8b000063 	add	x3, x3, x0
    4524:	eb03027f 	cmp	x19, x3
    4528:	54fff9e1 	b.ne	4464 <fwp_mem_free+0x64>  // b.any
    452c:	fd400ae1 	ldr	d1, [x23, #16]
    4530:	fd4a2020 	ldr	d0, [x1, #5184]
    4534:	f9400ae0 	ldr	x0, [x23, #16]
    4538:	7e61d821 	ucvtf	d1, d1
    453c:	f94a1022 	ldr	x2, [x1, #5152]
    4540:	f94012f3 	ldr	x19, [x23, #32]
    4544:	1e612800 	fadd	d0, d0, d1
    4548:	cb000042 	sub	x2, x2, x0
    454c:	f90a1022 	str	x2, [x1, #5152]
    4550:	fd0a2020 	str	d0, [x1, #5184]
    4554:	b40000b3 	cbz	x19, 4568 <fwp_mem_free+0x168>
    4558:	39400260 	ldrb	w0, [x19]
    455c:	7103fc1f 	cmp	w0, #0xff
    4560:	54000380 	b.eq	45d0 <fwp_mem_free+0x1d0>  // b.none
    4564:	3900027f 	strb	wzr, [x19]
    4568:	b9400ee2 	ldr	w2, [x23, #12]
    456c:	b4000142 	cbz	x2, 4594 <fwp_mem_free+0x194>
    4570:	911742a1 	add	x1, x21, #0x5d0
    4574:	8b160040 	add	x0, x2, x22
    4578:	8b000800 	add	x0, x0, x0, lsl #2
    457c:	f949fc21 	ldr	x1, [x1, #5112]
    4580:	8b140034 	add	x20, x1, x20
    4584:	8b000c20 	add	x0, x1, x0, lsl #3
    4588:	3802869f 	strb	wzr, [x20], #40
    458c:	eb00029f 	cmp	x20, x0
    4590:	54ffffc1 	b.ne	4588 <fwp_mem_free+0x188>  // b.any
    4594:	911742a0 	add	x0, x21, #0x5d0
    4598:	f94a1801 	ldr	x1, [x0, #5168]
    459c:	f949f803 	ldr	x3, [x0, #5104]
    45a0:	8b020021 	add	x1, x1, x2
    45a4:	f90a1801 	str	x1, [x0, #5168]
    45a8:	eb16007f 	cmp	x3, x22
    45ac:	54000049 	b.ls	45b4 <fwp_mem_free+0x1b4>  // b.plast
    45b0:	f909f816 	str	x22, [x0, #5104]
    45b4:	911742b5 	add	x21, x21, #0x5d0
    45b8:	f949f6a0 	ldr	x0, [x21, #5096]
    45bc:	eb16001f 	cmp	x0, x22
    45c0:	54fff529 	b.ls	4464 <fwp_mem_free+0x64>  // b.plast
    45c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45c8:	f909f6b6 	str	x22, [x21, #5096]
    45cc:	17ffffa7 	b	4468 <fwp_mem_free+0x68>
    45d0:	aa1303e0 	mov	x0, x19
    45d4:	97fffeef 	bl	4190 <fwp_rc_forget_slot.part.0>
    45d8:	17ffffe3 	b	4564 <fwp_mem_free+0x164>
    45dc:	97fffeed 	bl	4190 <fwp_rc_forget_slot.part.0>
    45e0:	17ffffb4 	b	44b0 <fwp_mem_free+0xb0>

00000000000045e4 <fwp_rc_wide_dup>:
    45e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e8:	910003fd 	mov	x29, sp
    45ec:	a90153f3 	stp	x19, x20, [sp, #16]
    45f0:	aa0003f3 	mov	x19, x0
    45f4:	ca404400 	eor	x0, x0, x0, lsr #17
    45f8:	f90013f5 	str	x21, [sp, #32]
    45fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4600:	ca402400 	eor	x0, x0, x0, lsr #9
    4604:	911742a2 	add	x2, x21, #0x5d0
    4608:	92401c00 	and	x0, x0, #0xff
    460c:	910a2403 	add	x3, x0, #0x289
    4610:	8b000c40 	add	x0, x2, x0, lsl #3
    4614:	8b030c54 	add	x20, x2, x3, lsl #3
    4618:	f94a2401 	ldr	x1, [x0, #5192]
    461c:	b50000a1 	cbnz	x1, 4630 <fwp_rc_wide_dup+0x4c>
    4620:	14000033 	b	46ec <fwp_rc_wide_dup+0x108>
    4624:	91004034 	add	x20, x1, #0x10
    4628:	f9400821 	ldr	x1, [x1, #16]
    462c:	b4000241 	cbz	x1, 4674 <fwp_rc_wide_dup+0x90>
    4630:	f9400022 	ldr	x2, [x1]
    4634:	eb02027f 	cmp	x19, x2
    4638:	54ffff61 	b.ne	4624 <fwp_rc_wide_dup+0x40>  // b.any
    463c:	f9400281 	ldr	x1, [x20]
    4640:	39400260 	ldrb	w0, [x19]
    4644:	7103f81f 	cmp	w0, #0xfe
    4648:	54000220 	b.eq	468c <fwp_rc_wide_dup+0xa8>  // b.none
    464c:	b40001a1 	cbz	x1, 4680 <fwp_rc_wide_dup+0x9c>
    4650:	f9400420 	ldr	x0, [x1, #8]
    4654:	b100041f 	cmn	x0, #0x1
    4658:	54000440 	b.eq	46e0 <fwp_rc_wide_dup+0xfc>  // b.none
    465c:	91000400 	add	x0, x0, #0x1
    4660:	f9000420 	str	x0, [x1, #8]
    4664:	a94153f3 	ldp	x19, x20, [sp, #16]
    4668:	f94013f5 	ldr	x21, [sp, #32]
    466c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4670:	d65f03c0 	ret
    4674:	39400260 	ldrb	w0, [x19]
    4678:	7103f81f 	cmp	w0, #0xfe
    467c:	54000100 	b.eq	469c <fwp_rc_wide_dup+0xb8>  // b.none
    4680:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4684:	910fa000 	add	x0, x0, #0x3e8
    4688:	97fffea2 	bl	4110 <fwp_trap>
    468c:	b4000081 	cbz	x1, 469c <fwp_rc_wide_dup+0xb8>
    4690:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4694:	91104000 	add	x0, x0, #0x410
    4698:	97fffe9e 	bl	4110 <fwp_trap>
    469c:	d2800300 	mov	x0, #0x18                  	// #24
    46a0:	97fff860 	bl	2820 <malloc@plt>
    46a4:	b4000280 	cbz	x0, 46f4 <fwp_rc_wide_dup+0x110>
    46a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    46ac:	a9000413 	stp	x19, x1, [x0]
    46b0:	911742b5 	add	x21, x21, #0x5d0
    46b4:	f900081f 	str	xzr, [x0, #16]
    46b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46bc:	f9000280 	str	x0, [x20]
    46c0:	39000261 	strb	w1, [x19]
    46c4:	f94e26a0 	ldr	x0, [x21, #7240]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	91000400 	add	x0, x0, #0x1
    46d0:	f90e26a0 	str	x0, [x21, #7240]
    46d4:	f94013f5 	ldr	x21, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    46e4:	9110e000 	add	x0, x0, #0x438
    46e8:	97fffe8a 	bl	4110 <fwp_trap>
    46ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46f0:	17ffffd4 	b	4640 <fwp_rc_wide_dup+0x5c>
    46f4:	97fffa4f 	bl	3030 <fwp_heap_oom>
    46f8:	d503201f 	nop
    46fc:	d503201f 	nop

0000000000004700 <fwp_closure_drop_push>:
    4700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4704:	910003fd 	mov	x29, sp
    4708:	a90153f3 	stp	x19, x20, [sp, #16]
    470c:	aa0003f3 	mov	x19, x0
    4710:	a9408014 	ldp	x20, x0, [x0, #8]
    4714:	a9025bf5 	stp	x21, x22, [sp, #32]
    4718:	aa0103f5 	mov	x21, x1
    471c:	a90363f7 	stp	x23, x24, [sp, #48]
    4720:	eb00029f 	cmp	x20, x0
    4724:	54000160 	b.eq	4750 <fwp_closure_drop_push+0x50>  // b.none
    4728:	f9400276 	ldr	x22, [x19]
    472c:	d37df297 	lsl	x23, x20, #3
    4730:	91000694 	add	x20, x20, #0x1
    4734:	f9000674 	str	x20, [x19, #8]
    4738:	a94153f3 	ldp	x19, x20, [sp, #16]
    473c:	f8376ad5 	str	x21, [x22, x23]
    4740:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4744:	a94363f7 	ldp	x23, x24, [sp, #48]
    4748:	a8c57bfd 	ldp	x29, x30, [sp], #80
    474c:	d65f03c0 	ret
    4750:	a9046bf9 	stp	x25, x26, [sp, #64]
    4754:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4758:	eb00029f 	cmp	x20, x0
    475c:	540003e8 	b.hi	47d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4760:	d37cee99 	lsl	x25, x20, #4
    4764:	d37ffa9a 	lsl	x26, x20, #1
    4768:	aa1903e0 	mov	x0, x25
    476c:	97fff82d 	bl	2820 <malloc@plt>
    4770:	aa0003f6 	mov	x22, x0
    4774:	b4000380 	cbz	x0, 47e4 <fwp_closure_drop_push+0xe4>
    4778:	aa1303f8 	mov	x24, x19
    477c:	aa1903e3 	mov	x3, x25
    4780:	d37df297 	lsl	x23, x20, #3
    4784:	aa1703e2 	mov	x2, x23
    4788:	f8418719 	ldr	x25, [x24], #24
    478c:	aa1903e1 	mov	x1, x25
    4790:	97fff810 	bl	27d0 <__memcpy_chk@plt>
    4794:	eb18033f 	cmp	x25, x24
    4798:	540000a0 	b.eq	47ac <fwp_closure_drop_push+0xac>  // b.none
    479c:	aa1903e0 	mov	x0, x25
    47a0:	97fff868 	bl	2940 <free@plt>
    47a4:	f9400674 	ldr	x20, [x19, #8]
    47a8:	d37df297 	lsl	x23, x20, #3
    47ac:	91000694 	add	x20, x20, #0x1
    47b0:	f9000276 	str	x22, [x19]
    47b4:	f9000a7a 	str	x26, [x19, #16]
    47b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47bc:	f9000674 	str	x20, [x19, #8]
    47c0:	f8376ad5 	str	x21, [x22, x23]
    47c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47d4:	d65f03c0 	ret
    47d8:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    47dc:	91116000 	add	x0, x0, #0x458
    47e0:	97fffe4c 	bl	4110 <fwp_trap>
    47e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    47e8:	f947e863 	ldr	x3, [x3, #4048]
    47ec:	d2800262 	mov	x2, #0x13                  	// #19
    47f0:	d2800021 	mov	x1, #0x1                   	// #1
    47f4:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    47f8:	9107e000 	add	x0, x0, #0x1f8
    47fc:	f9400063 	ldr	x3, [x3]
    4800:	97fff860 	bl	2980 <fwrite@plt>
    4804:	d2800000 	mov	x0, #0x0                   	// #0
    4808:	97fff86a 	bl	29b0 <fflush@plt>
    480c:	52800cc0 	mov	w0, #0x66                  	// #102
    4810:	97fff878 	bl	29f0 <_Exit@plt>

0000000000004814 <fwp_closure_drop.part.0>:
    4814:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4818:	f0000021 	adrp	x1, b000 <__modti3+0x1b0>
    481c:	910003fd 	mov	x29, sp
    4820:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4824:	f947f463 	ldr	x3, [x3, #4072]
    4828:	a90153f3 	stp	x19, x20, [sp, #16]
    482c:	d10883ff 	sub	sp, sp, #0x220
    4830:	910003e2 	mov	x2, sp
    4834:	d53bd053 	mrs	x19, tpidr_el0
    4838:	910063f4 	add	x20, sp, #0x18
    483c:	3dc3f020 	ldr	q0, [x1, #4032]
    4840:	91400264 	add	x4, x19, #0x0, lsl #12
    4844:	91004084 	add	x4, x4, #0x10
    4848:	aa0003e1 	mov	x1, x0
    484c:	aa0203e0 	mov	x0, x2
    4850:	f9400062 	ldr	x2, [x3]
    4854:	f9010fe2 	str	x2, [sp, #536]
    4858:	d2800002 	mov	x2, #0x0                   	// #0
    485c:	f90003f4 	str	x20, [sp]
    4860:	f9000080 	str	x0, [x4]
    4864:	3c8083e0 	stur	q0, [sp, #8]
    4868:	97ffffa6 	bl	4700 <fwp_closure_drop_push>
    486c:	f94007e0 	ldr	x0, [sp, #8]
    4870:	b40002e0 	cbz	x0, 48cc <fwp_closure_drop.part.0+0xb8>
    4874:	f90123f5 	str	x21, [sp, #576]
    4878:	900000f5 	adrp	x21, 20000 <__data_start>
    487c:	9101c2b5 	add	x21, x21, #0x70
    4880:	14000006 	b	4898 <fwp_closure_drop.part.0+0x84>
    4884:	f9400422 	ldr	x2, [x1, #8]
    4888:	52800001 	mov	w1, #0x0                   	// #0
    488c:	d63f0040 	blr	x2
    4890:	f94007e0 	ldr	x0, [sp, #8]
    4894:	b40001a0 	cbz	x0, 48c8 <fwp_closure_drop.part.0+0xb4>
    4898:	f94003e1 	ldr	x1, [sp]
    489c:	d1000400 	sub	x0, x0, #0x1
    48a0:	f90007e0 	str	x0, [sp, #8]
    48a4:	f94066a2 	ldr	x2, [x21, #200]
    48a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    48ac:	b9400001 	ldr	w1, [x0]
    48b0:	8b011441 	add	x1, x2, x1, lsl #5
    48b4:	f9400c21 	ldr	x1, [x1, #24]
    48b8:	b5fffe61 	cbnz	x1, 4884 <fwp_closure_drop.part.0+0x70>
    48bc:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    48c0:	9111e000 	add	x0, x0, #0x478
    48c4:	97fffe13 	bl	4110 <fwp_trap>
    48c8:	f94123f5 	ldr	x21, [sp, #576]
    48cc:	91400273 	add	x19, x19, #0x0, lsl #12
    48d0:	91004273 	add	x19, x19, #0x10
    48d4:	f94003e0 	ldr	x0, [sp]
    48d8:	f900027f 	str	xzr, [x19]
    48dc:	eb14001f 	cmp	x0, x20
    48e0:	54000040 	b.eq	48e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48e4:	97fff817 	bl	2940 <free@plt>
    48e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48ec:	f947f400 	ldr	x0, [x0, #4072]
    48f0:	f9410fe2 	ldr	x2, [sp, #536]
    48f4:	f9400001 	ldr	x1, [x0]
    48f8:	eb010042 	subs	x2, x2, x1
    48fc:	d2800001 	mov	x1, #0x0                   	// #0
    4900:	540000a1 	b.ne	4914 <fwp_closure_drop.part.0+0x100>  // b.any
    4904:	910883ff 	add	sp, sp, #0x220
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4910:	d65f03c0 	ret
    4914:	f90123f5 	str	x21, [sp, #576]
    4918:	97fff7da 	bl	2880 <__stack_chk_fail@plt>
    491c:	d503201f 	nop

0000000000004920 <fwp_tape_of>:
    4920:	aa0003e1 	mov	x1, x0
    4924:	92403c00 	and	x0, x0, #0xffff
    4928:	b40000e0 	cbz	x0, 4944 <fwp_tape_of+0x24>
    492c:	d1000402 	sub	x2, x0, #0x1
    4930:	900000e3 	adrp	x3, 20000 <__data_start>
    4934:	9101c060 	add	x0, x3, #0x70
    4938:	f9406800 	ldr	x0, [x0, #208]
    493c:	eb02001f 	cmp	x0, x2
    4940:	540000cc 	b.gt	4958 <fwp_tape_of+0x38>
    4944:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4948:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    494c:	9112a000 	add	x0, x0, #0x4a8
    4950:	910003fd 	mov	x29, sp
    4954:	97fffdef 	bl	4110 <fwp_trap>
    4958:	8b020440 	add	x0, x2, x2, lsl #1
    495c:	f9403863 	ldr	x3, [x3, #112]
    4960:	8b000842 	add	x2, x2, x0, lsl #2
    4964:	d37df042 	lsl	x2, x2, #3
    4968:	8b020060 	add	x0, x3, x2
    496c:	b9400404 	ldr	w4, [x0, #4]
    4970:	34fffea4 	cbz	w4, 4944 <fwp_tape_of+0x24>
    4974:	b8626862 	ldr	w2, [x3, x2]
    4978:	9350fc21 	asr	x1, x1, #16
    497c:	6b01005f 	cmp	w2, w1
    4980:	54fffe21 	b.ne	4944 <fwp_tape_of+0x24>  // b.any
    4984:	d65f03c0 	ret
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_now_ns>:
    4990:	d100c3ff 	sub	sp, sp, #0x30
    4994:	52800020 	mov	w0, #0x1                   	// #1
    4998:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    499c:	f947f442 	ldr	x2, [x2, #4072]
    49a0:	910023e1 	add	x1, sp, #0x8
    49a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    49a8:	910083fd 	add	x29, sp, #0x20
    49ac:	f9400043 	ldr	x3, [x2]
    49b0:	f9000fe3 	str	x3, [sp, #24]
    49b4:	d2800003 	mov	x3, #0x0                   	// #0
    49b8:	97fff77e 	bl	27b0 <clock_gettime@plt>
    49bc:	350002c0 	cbnz	w0, 4a14 <fwp_now_ns+0x84>
    49c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49c4:	d2994003 	mov	x3, #0xca00                	// #51712
    49c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49cc:	9b037c20 	mul	x0, x1, x3
    49d0:	9b437c21 	smulh	x1, x1, x3
    49d4:	ab020000 	adds	x0, x0, x2
    49d8:	937ffc42 	asr	x2, x2, #63
    49dc:	9a020021 	adc	x1, x1, x2
    49e0:	f100001f 	cmp	x0, #0x0
    49e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49e8:	b50001c1 	cbnz	x1, 4a20 <fwp_now_ns+0x90>
    49ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    49f0:	f947f421 	ldr	x1, [x1, #4072]
    49f4:	f9400fe3 	ldr	x3, [sp, #24]
    49f8:	f9400022 	ldr	x2, [x1]
    49fc:	eb020063 	subs	x3, x3, x2
    4a00:	d2800002 	mov	x2, #0x0                   	// #0
    4a04:	54000141 	b.ne	4a2c <fwp_now_ns+0x9c>  // b.any
    4a08:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a0c:	9100c3ff 	add	sp, sp, #0x30
    4a10:	d65f03c0 	ret
    4a14:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4a18:	9113e000 	add	x0, x0, #0x4f8
    4a1c:	97fffdbd 	bl	4110 <fwp_trap>
    4a20:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4a24:	91146000 	add	x0, x0, #0x518
    4a28:	97fffdba 	bl	4110 <fwp_trap>
    4a2c:	97fff795 	bl	2880 <__stack_chk_fail@plt>

0000000000004a30 <fwp_poll_events>:
    4a30:	d10103ff 	sub	sp, sp, #0x40
    4a34:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4a38:	f947f400 	ldr	x0, [x0, #4072]
    4a3c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a40:	910083fd 	add	x29, sp, #0x20
    4a44:	f9001bf3 	str	x19, [sp, #48]
    4a48:	900000f3 	adrp	x19, 20000 <__data_start>
    4a4c:	f9400001 	ldr	x1, [x0]
    4a50:	f9000fe1 	str	x1, [sp, #24]
    4a54:	d2800001 	mov	x1, #0x0                   	// #0
    4a58:	97ffffce 	bl	4990 <fwp_now_ns>
    4a5c:	9101c261 	add	x1, x19, #0x70
    4a60:	f9406c21 	ldr	x1, [x1, #216]
    4a64:	b4000e01 	cbz	x1, 4c24 <fwp_poll_events+0x1f4>
    4a68:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a6c:	14000005 	b	4a80 <fwp_poll_events+0x50>
    4a70:	f9408821 	ldr	x1, [x1, #272]
    4a74:	eb03005f 	cmp	x2, x3
    4a78:	9a83d042 	csel	x2, x2, x3, le
    4a7c:	b40000c1 	cbz	x1, 4a94 <fwp_poll_events+0x64>
    4a80:	f9403423 	ldr	x3, [x1, #104]
    4a84:	b6ffff62 	tbz	x2, #63, 4a70 <fwp_poll_events+0x40>
    4a88:	f9408821 	ldr	x1, [x1, #272]
    4a8c:	aa0303e2 	mov	x2, x3
    4a90:	b5ffff81 	cbnz	x1, 4a80 <fwp_poll_events+0x50>
    4a94:	b7f80c82 	tbnz	x2, #63, 4c24 <fwp_poll_events+0x1f4>
    4a98:	cb000042 	sub	x2, x2, x0
    4a9c:	f100005f 	cmp	x2, #0x0
    4aa0:	540003ad 	b.le	4b14 <fwp_poll_events+0xe4>
    4aa4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4aa8:	d2884804 	mov	x4, #0x4240                	// #16960
    4aac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4ab0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4ab4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4ab8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4abc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ac0:	9b407c40 	smulh	x0, x2, x0
    4ac4:	9352fc00 	asr	x0, x0, #18
    4ac8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4acc:	9b048802 	msub	x2, x0, x4, x2
    4ad0:	f100005f 	cmp	x2, #0x0
    4ad4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ad8:	eb01001f 	cmp	x0, x1
    4adc:	5400098c 	b.gt	4c0c <fwp_poll_events+0x1dc>
    4ae0:	340001a0 	cbz	w0, 4b14 <fwp_poll_events+0xe4>
    4ae4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ae8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4aec:	72a20c41 	movk	w1, #0x1062, lsl #16
    4af0:	9ba17c01 	umull	x1, w0, w1
    4af4:	d366fc23 	lsr	x3, x1, #38
    4af8:	aa0303e2 	mov	x2, x3
    4afc:	1b058063 	msub	w3, w3, w5, w0
    4b00:	9b247c63 	smull	x3, w3, w4
    4b04:	910023e0 	add	x0, sp, #0x8
    4b08:	d2800001 	mov	x1, #0x0                   	// #0
    4b0c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b10:	97fff790 	bl	2950 <nanosleep@plt>
    4b14:	97ffff9f 	bl	4990 <fwp_now_ns>
    4b18:	9101c268 	add	x8, x19, #0x70
    4b1c:	aa0003e7 	mov	x7, x0
    4b20:	4f000400 	movi	v0.4s, #0x0
    4b24:	52800029 	mov	w9, #0x1                   	// #1
    4b28:	f9406d06 	ldr	x6, [x8, #216]
    4b2c:	d503201f 	nop
    4b30:	b40003e6 	cbz	x6, 4bac <fwp_poll_events+0x17c>
    4b34:	f94034c1 	ldr	x1, [x6, #104]
    4b38:	aa0603e5 	mov	x5, x6
    4b3c:	f94088c6 	ldr	x6, [x6, #272]
    4b40:	eb07003f 	cmp	x1, x7
    4b44:	54ffff6c 	b.gt	4b30 <fwp_poll_events+0x100>
    4b48:	394154a0 	ldrb	w0, [x5, #85]
    4b4c:	36000120 	tbz	w0, #0, 4b70 <fwp_poll_events+0x140>
    4b50:	f94084a0 	ldr	x0, [x5, #264]
    4b54:	b4000560 	cbz	x0, 4c00 <fwp_poll_events+0x1d0>
    4b58:	f9008806 	str	x6, [x0, #272]
    4b5c:	b4000046 	cbz	x6, 4b64 <fwp_poll_events+0x134>
    4b60:	f90084c0 	str	x0, [x6, #264]
    4b64:	910800a0 	add	x0, x5, #0x200
    4b68:	390154bf 	strb	wzr, [x5, #85]
    4b6c:	3c908000 	stur	q0, [x0, #-248]
    4b70:	f94030a0 	ldr	x0, [x5, #96]
    4b74:	390158a9 	strb	w9, [x5, #86]
    4b78:	f100001f 	cmp	x0, #0x0
    4b7c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b80:	540002cd 	b.le	4bd8 <fwp_poll_events+0x1a8>
    4b84:	f94028a0 	ldr	x0, [x5, #80]
    4b88:	f2001c1f 	tst	x0, #0xff000000ff
    4b8c:	54fffd21 	b.ne	4b30 <fwp_poll_events+0x100>  // b.any
    4b90:	f9403d00 	ldr	x0, [x8, #120]
    4b94:	390150a9 	strb	w9, [x5, #84]
    4b98:	f90080bf 	str	xzr, [x5, #256]
    4b9c:	b40002c0 	cbz	x0, 4bf4 <fwp_poll_events+0x1c4>
    4ba0:	f9003d05 	str	x5, [x8, #120]
    4ba4:	f9008005 	str	x5, [x0, #256]
    4ba8:	b5fffc66 	cbnz	x6, 4b34 <fwp_poll_events+0x104>
    4bac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4bb0:	f947f400 	ldr	x0, [x0, #4072]
    4bb4:	f9400fe2 	ldr	x2, [sp, #24]
    4bb8:	f9400001 	ldr	x1, [x0]
    4bbc:	eb010042 	subs	x2, x2, x1
    4bc0:	d2800001 	mov	x1, #0x0                   	// #0
    4bc4:	540002e1 	b.ne	4c20 <fwp_poll_events+0x1f0>  // b.any
    4bc8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bcc:	f9401bf3 	ldr	x19, [sp, #48]
    4bd0:	910103ff 	add	sp, sp, #0x40
    4bd4:	d65f03c0 	ret
    4bd8:	394144a0 	ldrb	w0, [x5, #81]
    4bdc:	3707fd40 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be0:	394140a0 	ldrb	w0, [x5, #80]
    4be4:	3707fd00 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be8:	aa0503e0 	mov	x0, x5
    4bec:	97fffac1 	bl	36f0 <fwp_cancel_tree.part.0>
    4bf0:	17ffffe5 	b	4b84 <fwp_poll_events+0x154>
    4bf4:	f9003d05 	str	x5, [x8, #120]
    4bf8:	f9004105 	str	x5, [x8, #128]
    4bfc:	17ffffeb 	b	4ba8 <fwp_poll_events+0x178>
    4c00:	9101c261 	add	x1, x19, #0x70
    4c04:	f9006c26 	str	x6, [x1, #216]
    4c08:	17ffffd5 	b	4b5c <fwp_poll_events+0x12c>
    4c0c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c10:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c14:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c18:	f2a00402 	movk	x2, #0x20, lsl #16
    4c1c:	17ffffba 	b	4b04 <fwp_poll_events+0xd4>
    4c20:	97fff718 	bl	2880 <__stack_chk_fail@plt>
    4c24:	97fff8f3 	bl	2ff0 <fwp_flush>
    4c28:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4c2c:	f947e863 	ldr	x3, [x3, #4048]
    4c30:	d2800562 	mov	x2, #0x2b                  	// #43
    4c34:	d2800021 	mov	x1, #0x1                   	// #1
    4c38:	f0000020 	adrp	x0, b000 <__modti3+0x1b0>
    4c3c:	91150000 	add	x0, x0, #0x540
    4c40:	f9400063 	ldr	x3, [x3]
    4c44:	97fff74f 	bl	2980 <fwrite@plt>
    4c48:	52800ca0 	mov	w0, #0x65                  	// #101
    4c4c:	97fff6b9 	bl	2730 <exit@plt>

0000000000004c50 <fwp_heap_alloc_big>:
    4c50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c54:	910003fd 	mov	x29, sp
    4c58:	a90153f3 	stp	x19, x20, [sp, #16]
    4c5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c60:	a90363f7 	stp	x23, x24, [sp, #48]
    4c64:	aa0003f7 	mov	x23, x0
    4c68:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c70:	eb0002ff 	cmp	x23, x0
    4c74:	540008a8 	b.hi	4d88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c78:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c7c:	8b0002f4 	add	x20, x23, x0
    4c80:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c84:	91174359 	add	x25, x26, #0x5d0
    4c88:	d350fe94 	lsr	x20, x20, #16
    4c8c:	2a0103f5 	mov	w21, w1
    4c90:	aa1403e0 	mov	x0, x20
    4c94:	97fff987 	bl	32b0 <fwp_heap_chunks>
    4c98:	f949ff22 	ldr	x2, [x25, #5112]
    4c9c:	8b000813 	add	x19, x0, x0, lsl #2
    4ca0:	aa0003f8 	mov	x24, x0
    4ca4:	52800043 	mov	w3, #0x2                   	// #2
    4ca8:	d37df273 	lsl	x19, x19, #3
    4cac:	d2800021 	mov	x1, #0x1                   	// #1
    4cb0:	8b130040 	add	x0, x2, x19
    4cb4:	38336843 	strb	w3, [x2, x19]
    4cb8:	39000415 	strb	w21, [x0, #1]
    4cbc:	b9000c14 	str	w20, [x0, #12]
    4cc0:	f9000817 	str	x23, [x0, #16]
    4cc4:	97fffd57 	bl	4220 <fwp_rc_prepare_chunk>
    4cc8:	f100069f 	cmp	x20, #0x1
    4ccc:	54000289 	b.ls	4d1c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cd0:	8b180294 	add	x20, x20, x24
    4cd4:	9100a273 	add	x19, x19, #0x28
    4cd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4cdc:	5280007b 	mov	w27, #0x3                   	// #3
    4ce0:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce4:	2a1803fc 	mov	w28, w24
    4ce8:	9adb2296 	lsl	x22, x20, x27
    4cec:	d503201f 	nop
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffd48 	bl	4220 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x108>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffbbf 	bl	3d70 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff6f 	b	4c50 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffd19 	bl	4340 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94066e0 	ldr	x0, [x23, #200]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_tape_grow.constprop.0>:
    5224:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5228:	d2800803 	mov	x3, #0x40                  	// #64
    522c:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5230:	910003fd 	mov	x29, sp
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	f9400c13 	ldr	x19, [x0, #24]
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	aa0003f7 	mov	x23, x0
    5244:	f100027f 	cmp	x19, #0x0
    5248:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    524c:	eb13003f 	cmp	x1, x19
    5250:	540000ed 	b.le	526c <fwp_tape_grow.constprop.0+0x48>
    5254:	eb02027f 	cmp	x19, x2
    5258:	5400076d 	b.le	5344 <fwp_tape_grow.constprop.0+0x120>
    525c:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    5260:	eb13003f 	cmp	x1, x19
    5264:	5400004d 	b.le	526c <fwp_tape_grow.constprop.0+0x48>
    5268:	14000000 	b	5268 <fwp_tape_grow.constprop.0+0x44>
    526c:	a940d2e2 	ldp	x2, x20, [x23, #8]
    5270:	a9025bf5 	stp	x21, x22, [sp, #32]
    5274:	d37df276 	lsl	x22, x19, #3
    5278:	f94012e0 	ldr	x0, [x23, #32]
    527c:	aa1603e1 	mov	x1, x22
    5280:	f94032f5 	ldr	x21, [x23, #96]
    5284:	cb020294 	sub	x20, x20, x2
    5288:	97fff57a 	bl	2870 <realloc@plt>
    528c:	b4000c20 	cbz	x0, 5410 <fwp_tape_grow.constprop.0+0x1ec>
    5290:	f9400ee1 	ldr	x1, [x23, #24]
    5294:	8b010801 	add	x1, x0, x1, lsl #2
    5298:	a90206e0 	stp	x0, x1, [x23, #32]
    529c:	b4000895 	cbz	x21, 53ac <fwp_tape_grow.constprop.0+0x188>
    52a0:	f94032b6 	ldr	x22, [x21, #96]
    52a4:	eb1302df 	cmp	x22, x19
    52a8:	540003aa 	b.ge	531c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    52ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    52b4:	eb00027f 	cmp	x19, x0
    52b8:	54000a68 	b.hi	5404 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    52bc:	f94022b9 	ldr	x25, [x21, #64]
    52c0:	d37cee7a 	lsl	x26, x19, #4
    52c4:	aa1a03e0 	mov	x0, x26
    52c8:	52800041 	mov	w1, #0x2                   	// #2
    52cc:	97ffff09 	bl	4ef0 <fwp_heap_alloc>
    52d0:	aa0003f8 	mov	x24, x0
    52d4:	b4000119 	cbz	x25, 52f4 <fwp_tape_grow.constprop.0+0xd0>
    52d8:	d37ceed6 	lsl	x22, x22, #4
    52dc:	aa1903e1 	mov	x1, x25
    52e0:	eb1a02df 	cmp	x22, x26
    52e4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    52e8:	97fff4fa 	bl	26d0 <memcpy@plt>
    52ec:	aa1903e0 	mov	x0, x25
    52f0:	97fffc44 	bl	4400 <fwp_mem_free>
    52f4:	f94032a0 	ldr	x0, [x21, #96]
    52f8:	52800001 	mov	w1, #0x0                   	// #0
    52fc:	cb000262 	sub	x2, x19, x0
    5300:	8b001300 	add	x0, x24, x0, lsl #4
    5304:	d37cec42 	lsl	x2, x2, #4
    5308:	97fff552 	bl	2850 <memset@plt>
    530c:	f94012e0 	ldr	x0, [x23, #32]
    5310:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5314:	f90022b8 	str	x24, [x21, #64]
    5318:	f90032b3 	str	x19, [x21, #96]
    531c:	d37ef675 	lsl	x21, x19, #2
    5320:	b50002b4 	cbnz	x20, 5374 <fwp_tape_grow.constprop.0+0x150>
    5324:	8b150001 	add	x1, x0, x21
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000ef3 	str	x19, [x23, #24]
    5330:	f90016e1 	str	x1, [x23, #40]
    5334:	a94153f3 	ldp	x19, x20, [sp, #16]
    5338:	a94363f7 	ldp	x23, x24, [sp, #48]
    533c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5340:	d65f03c0 	ret
    5344:	d37ffa73 	lsl	x19, x19, #1
    5348:	17ffffc1 	b	524c <fwp_tape_grow.constprop.0+0x28>
    534c:	eb1502df 	cmp	x22, x21
    5350:	aa0403e0 	mov	x0, x4
    5354:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    5358:	d37df282 	lsl	x2, x20, #3
    535c:	cb160063 	sub	x3, x3, x22
    5360:	97fff5b0 	bl	2a20 <__memmove_chk@plt>
    5364:	f9401ae1 	ldr	x1, [x23, #48]
    5368:	f94012e0 	ldr	x0, [x23, #32]
    536c:	8b160021 	add	x1, x1, x22
    5370:	f9001ee1 	str	x1, [x23, #56]
    5374:	f94016e1 	ldr	x1, [x23, #40]
    5378:	d37ef675 	lsl	x21, x19, #2
    537c:	d37ef682 	lsl	x2, x20, #2
    5380:	8b150000 	add	x0, x0, x21
    5384:	97fff4db 	bl	26f0 <memmove@plt>
    5388:	f94012e0 	ldr	x0, [x23, #32]
    538c:	8b150001 	add	x1, x0, x21
    5390:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5394:	f9000ef3 	str	x19, [x23, #24]
    5398:	f90016e1 	str	x1, [x23, #40]
    539c:	a94153f3 	ldp	x19, x20, [sp, #16]
    53a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53a4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53a8:	d65f03c0 	ret
    53ac:	f9401ae0 	ldr	x0, [x23, #48]
    53b0:	d37cee75 	lsl	x21, x19, #4
    53b4:	aa1503e1 	mov	x1, x21
    53b8:	97fff52e 	bl	2870 <realloc@plt>
    53bc:	b40002a0 	cbz	x0, 5410 <fwp_tape_grow.constprop.0+0x1ec>
    53c0:	f9400ee2 	ldr	x2, [x23, #24]
    53c4:	f9001ae0 	str	x0, [x23, #48]
    53c8:	8b160004 	add	x4, x0, x22
    53cc:	8b020c01 	add	x1, x0, x2, lsl #3
    53d0:	f9001ee1 	str	x1, [x23, #56]
    53d4:	b5fffbd4 	cbnz	x20, 534c <fwp_tape_grow.constprop.0+0x128>
    53d8:	f94012e0 	ldr	x0, [x23, #32]
    53dc:	d37ef675 	lsl	x21, x19, #2
    53e0:	f9001ee4 	str	x4, [x23, #56]
    53e4:	8b150001 	add	x1, x0, x21
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	f9000ef3 	str	x19, [x23, #24]
    53f0:	f90016e1 	str	x1, [x23, #40]
    53f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5408:	91166000 	add	x0, x0, #0x598
    540c:	97fffb41 	bl	4110 <fwp_trap>
    5410:	aa1703e0 	mov	x0, x23
    5414:	a9046bf9 	stp	x25, x26, [sp, #64]
    5418:	97fff6de 	bl	2f90 <fwp_tape_unlink_scope>
    541c:	f94012e0 	ldr	x0, [x23, #32]
    5420:	97fff548 	bl	2940 <free@plt>
    5424:	f9401ae0 	ldr	x0, [x23, #48]
    5428:	97fff546 	bl	2940 <free@plt>
    542c:	f94022e0 	ldr	x0, [x23, #64]
    5430:	97fff544 	bl	2940 <free@plt>
    5434:	f9000eff 	str	xzr, [x23, #24]
    5438:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    543c:	f947e821 	ldr	x1, [x1, #4048]
    5440:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5444:	d2800262 	mov	x2, #0x13                  	// #19
    5448:	4f000400 	movi	v0.4s, #0x0
    544c:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5450:	f9400023 	ldr	x3, [x1]
    5454:	b90006ff 	str	wzr, [x23, #4]
    5458:	d2800021 	mov	x1, #0x1                   	// #1
    545c:	9107e000 	add	x0, x0, #0x1f8
    5460:	3c8082e0 	stur	q0, [x23, #8]
    5464:	ad0102e0 	stp	q0, q0, [x23, #32]
    5468:	97fff546 	bl	2980 <fwrite@plt>
    546c:	d2800000 	mov	x0, #0x0                   	// #0
    5470:	97fff550 	bl	29b0 <fflush@plt>
    5474:	52800cc0 	mov	w0, #0x66                  	// #102
    5478:	97fff55e 	bl	29f0 <_Exit@plt>
    547c:	d503201f 	nop

0000000000005480 <f128.constprop.0>:
    5480:	f100001f 	cmp	x0, #0x0
    5484:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5488:	54000a2b 	b.lt	55cc <f128.constprop.0+0x14c>  // b.tstop
    548c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5490:	aa0003e2 	mov	x2, x0
    5494:	910003fd 	mov	x29, sp
    5498:	a90153f3 	stp	x19, x20, [sp, #16]
    549c:	aa0003f4 	mov	x20, x0
    54a0:	aa010000 	orr	x0, x0, x1
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	aa0103f6 	mov	x22, x1
    54ac:	f9001bf7 	str	x23, [sp, #48]
    54b0:	fd001fe8 	str	d8, [sp, #56]
    54b4:	b7f80180 	tbnz	x0, #63, 54e4 <f128.constprop.0+0x64>
    54b8:	9360fc20 	asr	x0, x1, #32
    54bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54c0:	eb82801f 	cmp	x0, x2, asr #32
    54c4:	54000881 	b.ne	55d4 <f128.constprop.0+0x154>  // b.any
    54c8:	97fffd16 	bl	4920 <fwp_tape_of>
    54cc:	aa0003f3 	mov	x19, x0
    54d0:	f9403000 	ldr	x0, [x0, #96]
    54d4:	b40001e0 	cbz	x0, 5510 <f128.constprop.0+0x90>
    54d8:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    54dc:	91180000 	add	x0, x0, #0x600
    54e0:	97fffb0c 	bl	4110 <fwp_trap>
    54e4:	9360fc40 	asr	x0, x2, #32
    54e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54ec:	b6fffee2 	tbz	x2, #63, 54c8 <f128.constprop.0+0x48>
    54f0:	2f00e408 	movi	d8, #0x0
    54f4:	9360fc20 	asr	x0, x1, #32
    54f8:	aa0103f4 	mov	x20, x1
    54fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5500:	97fffd08 	bl	4920 <fwp_tape_of>
    5504:	aa0003f3 	mov	x19, x0
    5508:	f9403000 	ldr	x0, [x0, #96]
    550c:	b5fffe60 	cbnz	x0, 54d8 <f128.constprop.0+0x58>
    5510:	f9400a77 	ldr	x23, [x19, #16]
    5514:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5518:	eb0002ff 	cmp	x23, x0
    551c:	5400046c 	b.gt	55a8 <f128.constprop.0+0x128>
    5520:	eb3442ff 	cmp	x23, w20, uxtw
    5524:	540004ed 	b.le	55c0 <f128.constprop.0+0x140>
    5528:	b7f80076 	tbnz	x22, #63, 5534 <f128.constprop.0+0xb4>
    552c:	eb3642ff 	cmp	x23, w22, uxtw
    5530:	5400048d 	b.le	55c0 <f128.constprop.0+0x140>
    5534:	f9400675 	ldr	x21, [x19, #8]
    5538:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    553c:	cb1502f5 	sub	x21, x23, x21
    5540:	910006a1 	add	x1, x21, #0x1
    5544:	eb00003f 	cmp	x1, x0
    5548:	54000308 	b.hi	55a8 <f128.constprop.0+0x128>  // b.pmore
    554c:	f9400e60 	ldr	x0, [x19, #24]
    5550:	eb00003f 	cmp	x1, x0
    5554:	5400030c 	b.gt	55b4 <f128.constprop.0+0x134>
    5558:	a9420262 	ldp	x2, x0, [x19, #32]
    555c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5560:	f9401a61 	ldr	x1, [x19, #48]
    5564:	b8357854 	str	w20, [x2, x21, lsl #2]
    5568:	f9401e62 	ldr	x2, [x19, #56]
    556c:	f10002df 	cmp	x22, #0x0
    5570:	fc357820 	str	d0, [x1, x21, lsl #3]
    5574:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5578:	b8357816 	str	w22, [x0, x21, lsl #2]
    557c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5580:	910006e1 	add	x1, x23, #0x1
    5584:	aa170000 	orr	x0, x0, x23
    5588:	fc357848 	str	d8, [x2, x21, lsl #3]
    558c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5590:	f9401bf7 	ldr	x23, [sp, #48]
    5594:	fd401fe8 	ldr	d8, [sp, #56]
    5598:	f9000a61 	str	x1, [x19, #16]
    559c:	a94153f3 	ldp	x19, x20, [sp, #16]
    55a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55a4:	d65f03c0 	ret
    55a8:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    55ac:	91166000 	add	x0, x0, #0x598
    55b0:	97fffad8 	bl	4110 <fwp_trap>
    55b4:	aa1303e0 	mov	x0, x19
    55b8:	97ffff1b 	bl	5224 <fwp_tape_grow.constprop.0>
    55bc:	17ffffe7 	b	5558 <f128.constprop.0+0xd8>
    55c0:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    55c4:	9118c000 	add	x0, x0, #0x630
    55c8:	97fffad2 	bl	4110 <fwp_trap>
    55cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55d0:	d65f03c0 	ret
    55d4:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    55d8:	9116e000 	add	x0, x0, #0x5b8
    55dc:	97fffacd 	bl	4110 <fwp_trap>

00000000000055e0 <w107>:
    55e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    55e4:	910003fd 	mov	x29, sp
    55e8:	a90153f3 	stp	x19, x20, [sp, #16]
    55ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    55f0:	a90363f7 	stp	x23, x24, [sp, #48]
    55f4:	aa0003f8 	mov	x24, x0
    55f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55fc:	aa0103f9 	mov	x25, x1
    5600:	6d0527e8 	stp	d8, d9, [sp, #80]
    5604:	1e604008 	fmov	d8, d0
    5608:	1e604029 	fmov	d9, d1
    560c:	6d062fea 	stp	d10, d11, [sp, #96]
    5610:	1e60080a 	fmul	d10, d0, d0
    5614:	b7f821a0 	tbnz	x0, #63, 5a48 <w107+0x468>
    5618:	9360fc17 	asr	x23, x0, #32
    561c:	aa1703e0 	mov	x0, x23
    5620:	97fffcc0 	bl	4920 <fwp_tape_of>
    5624:	f9403001 	ldr	x1, [x0, #96]
    5628:	aa0003f3 	mov	x19, x0
    562c:	b4000081 	cbz	x1, 563c <w107+0x5c>
    5630:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5634:	91180000 	add	x0, x0, #0x600
    5638:	97fffab6 	bl	4110 <fwp_trap>
    563c:	f9400815 	ldr	x21, [x0, #16]
    5640:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5644:	eb0102bf 	cmp	x21, x1
    5648:	54001d8c 	b.gt	59f8 <w107+0x418>
    564c:	eb3842bf 	cmp	x21, w24, uxtw
    5650:	54001ced 	b.le	59ec <w107+0x40c>
    5654:	f9400416 	ldr	x22, [x0, #8]
    5658:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    565c:	cb1602b6 	sub	x22, x21, x22
    5660:	910006c1 	add	x1, x22, #0x1
    5664:	eb02003f 	cmp	x1, x2
    5668:	54001c88 	b.hi	59f8 <w107+0x418>  // b.pmore
    566c:	f9400c02 	ldr	x2, [x0, #24]
    5670:	eb02003f 	cmp	x1, x2
    5674:	54001c8c 	b.gt	5a04 <w107+0x424>
    5678:	a9420660 	ldp	x0, x1, [x19, #32]
    567c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5680:	f9401a62 	ldr	x2, [x19, #48]
    5684:	b8367818 	str	w24, [x0, x22, lsl #2]
    5688:	f9401e60 	ldr	x0, [x19, #56]
    568c:	aa150294 	orr	x20, x20, x21
    5690:	fc367848 	str	d8, [x2, x22, lsl #3]
    5694:	910006b5 	add	x21, x21, #0x1
    5698:	b8367838 	str	w24, [x1, x22, lsl #2]
    569c:	1e6a392a 	fsub	d10, d9, d10
    56a0:	9360fe9a 	asr	x26, x20, #32
    56a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    56a8:	f9000a75 	str	x21, [x19, #16]
    56ac:	b7f80079 	tbnz	x25, #63, 56b8 <w107+0xd8>
    56b0:	eb99835f 	cmp	x26, x25, asr #32
    56b4:	54001e21 	b.ne	5a78 <w107+0x498>  // b.any
    56b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    56c0:	eb1a02ff 	cmp	x23, x26
    56c4:	540000c0 	b.eq	56dc <w107+0xfc>  // b.none
    56c8:	aa1a03e0 	mov	x0, x26
    56cc:	97fffc95 	bl	4920 <fwp_tape_of>
    56d0:	aa0003f3 	mov	x19, x0
    56d4:	f9403000 	ldr	x0, [x0, #96]
    56d8:	b5fffac0 	cbnz	x0, 5630 <w107+0x50>
    56dc:	f9400a77 	ldr	x23, [x19, #16]
    56e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56e4:	eb0002ff 	cmp	x23, x0
    56e8:	5400188c 	b.gt	59f8 <w107+0x418>
    56ec:	eb3442ff 	cmp	x23, w20, uxtw
    56f0:	540017ed 	b.le	59ec <w107+0x40c>
    56f4:	b7f80079 	tbnz	x25, #63, 5700 <w107+0x120>
    56f8:	eb3942ff 	cmp	x23, w25, uxtw
    56fc:	5400178d 	b.le	59ec <w107+0x40c>
    5700:	f9400675 	ldr	x21, [x19, #8]
    5704:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5708:	cb1502f5 	sub	x21, x23, x21
    570c:	910006a1 	add	x1, x21, #0x1
    5710:	eb00003f 	cmp	x1, x0
    5714:	54001728 	b.hi	59f8 <w107+0x418>  // b.pmore
    5718:	f9400e60 	ldr	x0, [x19, #24]
    571c:	eb00003f 	cmp	x1, x0
    5720:	540018ec 	b.gt	5a3c <w107+0x45c>
    5724:	a9420e62 	ldp	x2, x3, [x19, #32]
    5728:	f100033f 	cmp	x25, #0x0
    572c:	f9401a61 	ldr	x1, [x19, #48]
    5730:	b8357854 	str	w20, [x2, x21, lsl #2]
    5734:	f9401e62 	ldr	x2, [x19, #56]
    5738:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    573c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5740:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5744:	b8357861 	str	w1, [x3, x21, lsl #2]
    5748:	910006f6 	add	x22, x23, #0x1
    574c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5750:	92607e94 	and	x20, x20, #0xffffffff00000000
    5754:	fc357849 	str	d9, [x2, x21, lsl #3]
    5758:	aa170294 	orr	x20, x20, x23
    575c:	f9000a76 	str	x22, [x19, #16]
    5760:	1e68396b 	fsub	d11, d11, d8
    5764:	b7f81a78 	tbnz	x24, #63, 5ab0 <w107+0x4d0>
    5768:	9360ff17 	asr	x23, x24, #32
    576c:	eb1a02ff 	cmp	x23, x26
    5770:	540000e0 	b.eq	578c <w107+0x1ac>  // b.none
    5774:	aa1703e0 	mov	x0, x23
    5778:	97fffc6a 	bl	4920 <fwp_tape_of>
    577c:	aa0003f3 	mov	x19, x0
    5780:	f9403000 	ldr	x0, [x0, #96]
    5784:	b5fff560 	cbnz	x0, 5630 <w107+0x50>
    5788:	f9400a76 	ldr	x22, [x19, #16]
    578c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5790:	eb0002df 	cmp	x22, x0
    5794:	5400132c 	b.gt	59f8 <w107+0x418>
    5798:	eb3842df 	cmp	x22, w24, uxtw
    579c:	5400128d 	b.le	59ec <w107+0x40c>
    57a0:	f9400675 	ldr	x21, [x19, #8]
    57a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57a8:	cb1502d5 	sub	x21, x22, x21
    57ac:	910006a1 	add	x1, x21, #0x1
    57b0:	eb00003f 	cmp	x1, x0
    57b4:	54001228 	b.hi	59f8 <w107+0x418>  // b.pmore
    57b8:	f9400e60 	ldr	x0, [x19, #24]
    57bc:	eb00003f 	cmp	x1, x0
    57c0:	5400138c 	b.gt	5a30 <w107+0x450>
    57c4:	a9420262 	ldp	x2, x0, [x19, #32]
    57c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    57cc:	f9401a63 	ldr	x3, [x19, #48]
    57d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    57d4:	f9401e62 	ldr	x2, [x19, #56]
    57d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    57dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    57e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    57e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    57e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    57ec:	aa160018 	orr	x24, x0, x22
    57f0:	910006c1 	add	x1, x22, #0x1
    57f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    57f8:	f9000a61 	str	x1, [x19, #16]
    57fc:	9360fe99 	asr	x25, x20, #32
    5800:	1e6a0949 	fmul	d9, d10, d10
    5804:	eb17033f 	cmp	x25, x23
    5808:	540000c0 	b.eq	5820 <w107+0x240>  // b.none
    580c:	aa1903e0 	mov	x0, x25
    5810:	97fffc44 	bl	4920 <fwp_tape_of>
    5814:	aa0003f3 	mov	x19, x0
    5818:	f9403000 	ldr	x0, [x0, #96]
    581c:	b5fff0a0 	cbnz	x0, 5630 <w107+0x50>
    5820:	f9400a75 	ldr	x21, [x19, #16]
    5824:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5828:	eb0002bf 	cmp	x21, x0
    582c:	54000e6c 	b.gt	59f8 <w107+0x418>
    5830:	eb3442bf 	cmp	x21, w20, uxtw
    5834:	54000dcd 	b.le	59ec <w107+0x40c>
    5838:	f9400676 	ldr	x22, [x19, #8]
    583c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5840:	cb1602b6 	sub	x22, x21, x22
    5844:	910006c1 	add	x1, x22, #0x1
    5848:	eb00003f 	cmp	x1, x0
    584c:	54000d68 	b.hi	59f8 <w107+0x418>  // b.pmore
    5850:	f9400e60 	ldr	x0, [x19, #24]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000e6c 	b.gt	5a24 <w107+0x444>
    585c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5860:	aa150017 	orr	x23, x0, x21
    5864:	a9420261 	ldp	x1, x0, [x19, #32]
    5868:	f9401a62 	ldr	x2, [x19, #48]
    586c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5870:	f9401e61 	ldr	x1, [x19, #56]
    5874:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5878:	b8367814 	str	w20, [x0, x22, lsl #2]
    587c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5880:	9e670000 	fmov	d0, x0
    5884:	910006b4 	add	x20, x21, #0x1
    5888:	fc36782a 	str	d10, [x1, x22, lsl #3]
    588c:	9360fef6 	asr	x22, x23, #32
    5890:	f9000a74 	str	x20, [x19, #16]
    5894:	1e600929 	fmul	d9, d9, d0
    5898:	eb1902df 	cmp	x22, x25
    589c:	540000e0 	b.eq	58b8 <w107+0x2d8>  // b.none
    58a0:	aa1603e0 	mov	x0, x22
    58a4:	97fffc1f 	bl	4920 <fwp_tape_of>
    58a8:	aa0003f3 	mov	x19, x0
    58ac:	f9403000 	ldr	x0, [x0, #96]
    58b0:	b5ffec00 	cbnz	x0, 5630 <w107+0x50>
    58b4:	f9400a74 	ldr	x20, [x19, #16]
    58b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58bc:	eb00029f 	cmp	x20, x0
    58c0:	540009cc 	b.gt	59f8 <w107+0x418>
    58c4:	eb37429f 	cmp	x20, w23, uxtw
    58c8:	5400092d 	b.le	59ec <w107+0x40c>
    58cc:	f9400675 	ldr	x21, [x19, #8]
    58d0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    58d4:	cb150295 	sub	x21, x20, x21
    58d8:	910006a1 	add	x1, x21, #0x1
    58dc:	eb00003f 	cmp	x1, x0
    58e0:	540008c8 	b.hi	59f8 <w107+0x418>  // b.pmore
    58e4:	f9400e60 	ldr	x0, [x19, #24]
    58e8:	eb00003f 	cmp	x1, x0
    58ec:	5400096c 	b.gt	5a18 <w107+0x438>
    58f0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    58f4:	9e670000 	fmov	d0, x0
    58f8:	a9420262 	ldp	x2, x0, [x19, #32]
    58fc:	1e6b0968 	fmul	d8, d11, d11
    5900:	f9401a61 	ldr	x1, [x19, #48]
    5904:	b8357857 	str	w23, [x2, x21, lsl #2]
    5908:	f9401e62 	ldr	x2, [x19, #56]
    590c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5910:	12800001 	mov	w1, #0xffffffff            	// #-1
    5914:	b8357801 	str	w1, [x0, x21, lsl #2]
    5918:	91000681 	add	x1, x20, #0x1
    591c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5920:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5924:	f9000a61 	str	x1, [x19, #16]
    5928:	aa140014 	orr	x20, x0, x20
    592c:	b100071f 	cmn	x24, #0x1
    5930:	54000c60 	b.eq	5abc <w107+0x4dc>  // b.none
    5934:	9360ff00 	asr	x0, x24, #32
    5938:	eb16001f 	cmp	x0, x22
    593c:	540000a0 	b.eq	5950 <w107+0x370>  // b.none
    5940:	97fffbf8 	bl	4920 <fwp_tape_of>
    5944:	aa0003f3 	mov	x19, x0
    5948:	f9403000 	ldr	x0, [x0, #96]
    594c:	b5ffe720 	cbnz	x0, 5630 <w107+0x50>
    5950:	f9400a75 	ldr	x21, [x19, #16]
    5954:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5958:	eb0002bf 	cmp	x21, x0
    595c:	540004ec 	b.gt	59f8 <w107+0x418>
    5960:	eb3842bf 	cmp	x21, w24, uxtw
    5964:	5400044d 	b.le	59ec <w107+0x40c>
    5968:	f9400676 	ldr	x22, [x19, #8]
    596c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5970:	cb1602b6 	sub	x22, x21, x22
    5974:	910006c1 	add	x1, x22, #0x1
    5978:	eb00003f 	cmp	x1, x0
    597c:	540003e8 	b.hi	59f8 <w107+0x418>  // b.pmore
    5980:	f9400e60 	ldr	x0, [x19, #24]
    5984:	eb00003f 	cmp	x1, x0
    5988:	5400042c 	b.gt	5a0c <w107+0x42c>
    598c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5990:	92607f00 	and	x0, x24, #0xffffffff00000000
    5994:	f9401a63 	ldr	x3, [x19, #48]
    5998:	b8367838 	str	w24, [x1, x22, lsl #2]
    599c:	f9401e61 	ldr	x1, [x19, #56]
    59a0:	aa150000 	orr	x0, x0, x21
    59a4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    59a8:	910006b5 	add	x21, x21, #0x1
    59ac:	b8367858 	str	w24, [x2, x22, lsl #2]
    59b0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    59b4:	f9000a75 	str	x21, [x19, #16]
    59b8:	1e692908 	fadd	d8, d8, d9
    59bc:	aa1403e1 	mov	x1, x20
    59c0:	97fffeb0 	bl	5480 <f128.constprop.0>
    59c4:	aa0003e1 	mov	x1, x0
    59c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    59cc:	9e660100 	fmov	x0, d8
    59d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    59d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    59dc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    59e0:	6d462fea 	ldp	d10, d11, [sp, #96]
    59e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    59e8:	d65f03c0 	ret
    59ec:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    59f0:	9118c000 	add	x0, x0, #0x630
    59f4:	97fff9c7 	bl	4110 <fwp_trap>
    59f8:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    59fc:	91166000 	add	x0, x0, #0x598
    5a00:	97fff9c4 	bl	4110 <fwp_trap>
    5a04:	97fffe08 	bl	5224 <fwp_tape_grow.constprop.0>
    5a08:	17ffff1c 	b	5678 <w107+0x98>
    5a0c:	aa1303e0 	mov	x0, x19
    5a10:	97fffe05 	bl	5224 <fwp_tape_grow.constprop.0>
    5a14:	17ffffde 	b	598c <w107+0x3ac>
    5a18:	aa1303e0 	mov	x0, x19
    5a1c:	97fffe02 	bl	5224 <fwp_tape_grow.constprop.0>
    5a20:	17ffffb4 	b	58f0 <w107+0x310>
    5a24:	aa1303e0 	mov	x0, x19
    5a28:	97fffdff 	bl	5224 <fwp_tape_grow.constprop.0>
    5a2c:	17ffff8c 	b	585c <w107+0x27c>
    5a30:	aa1303e0 	mov	x0, x19
    5a34:	97fffdfc 	bl	5224 <fwp_tape_grow.constprop.0>
    5a38:	17ffff63 	b	57c4 <w107+0x1e4>
    5a3c:	aa1303e0 	mov	x0, x19
    5a40:	97fffdf9 	bl	5224 <fwp_tape_grow.constprop.0>
    5a44:	17ffff38 	b	5724 <w107+0x144>
    5a48:	1e6a382a 	fsub	d10, d1, d10
    5a4c:	b6f801c1 	tbz	x1, #63, 5a84 <w107+0x4a4>
    5a50:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5a54:	1e6a0949 	fmul	d9, d10, d10
    5a58:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a5c:	9e670001 	fmov	d1, x0
    5a60:	1e683808 	fsub	d8, d0, d8
    5a64:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5a68:	aa1403e0 	mov	x0, x20
    5a6c:	1e610929 	fmul	d9, d9, d1
    5a70:	1e680908 	fmul	d8, d8, d8
    5a74:	17ffffd1 	b	59b8 <w107+0x3d8>
    5a78:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5a7c:	9116e000 	add	x0, x0, #0x5b8
    5a80:	97fff9a4 	bl	4110 <fwp_trap>
    5a84:	2f00e409 	movi	d9, #0x0
    5a88:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5a8c:	9360fc3a 	asr	x26, x1, #32
    5a90:	aa0103f4 	mov	x20, x1
    5a94:	aa1a03e0 	mov	x0, x26
    5a98:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5a9c:	97fffba1 	bl	4920 <fwp_tape_of>
    5aa0:	aa0003f3 	mov	x19, x0
    5aa4:	f9403000 	ldr	x0, [x0, #96]
    5aa8:	b5ffdc40 	cbnz	x0, 5630 <w107+0x50>
    5aac:	17ffff0c 	b	56dc <w107+0xfc>
    5ab0:	aa1a03f7 	mov	x23, x26
    5ab4:	aa0003f8 	mov	x24, x0
    5ab8:	17ffff51 	b	57fc <w107+0x21c>
    5abc:	aa1803e0 	mov	x0, x24
    5ac0:	17ffffbe 	b	59b8 <w107+0x3d8>

0000000000005ac4 <fwp_data.part.0.constprop.0>:
    5ac4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5ac8:	910003fd 	mov	x29, sp
    5acc:	a90153f3 	stp	x19, x20, [sp, #16]
    5ad0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5ad4:	91174283 	add	x3, x20, #0x5d0
    5ad8:	a9025bf5 	stp	x21, x22, [sp, #32]
    5adc:	aa0103f5 	mov	x21, x1
    5ae0:	b953a461 	ldr	w1, [x3, #5028]
    5ae4:	a90363f7 	stp	x23, x24, [sp, #48]
    5ae8:	2a0003f8 	mov	w24, w0
    5aec:	34000701 	cbz	w1, 5bcc <fwp_data.part.0.constprop.0+0x108>
    5af0:	397e8862 	ldrb	w2, [x3, #4002]
    5af4:	910f0040 	add	x0, x2, #0x3c0
    5af8:	8b020442 	add	x2, x2, x2, lsl #1
    5afc:	d37df042 	lsl	x2, x2, #3
    5b00:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5b04:	2a1703f6 	mov	w22, w23
    5b08:	f8626873 	ldr	x19, [x3, x2]
    5b0c:	b40004d3 	cbz	x19, 5ba4 <fwp_data.part.0.constprop.0+0xe0>
    5b10:	f9400260 	ldr	x0, [x19]
    5b14:	aa2003e0 	mvn	x0, x0
    5b18:	f8226860 	str	x0, [x3, x2]
    5b1c:	f10062df 	cmp	x22, #0x18
    5b20:	540000e9 	b.ls	5b3c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5b24:	d10066c2 	sub	x2, x22, #0x19
    5b28:	91006260 	add	x0, x19, #0x18
    5b2c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5b30:	52800001 	mov	w1, #0x0                   	// #0
    5b34:	91002042 	add	x2, x2, #0x8
    5b38:	97fff346 	bl	2850 <memset@plt>
    5b3c:	91174282 	add	x2, x20, #0x5d0
    5b40:	f94a1041 	ldr	x1, [x2, #5152]
    5b44:	ab160021 	adds	x1, x1, x22
    5b48:	540004c2 	b.cs	5be0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5b4c:	f94a1440 	ldr	x0, [x2, #5160]
    5b50:	f90a1041 	str	x1, [x2, #5152]
    5b54:	eb00003f 	cmp	x1, x0
    5b58:	54000049 	b.ls	5b60 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5b5c:	f90a1441 	str	x1, [x2, #5160]
    5b60:	91174294 	add	x20, x20, #0x5d0
    5b64:	1e6302e1 	ucvtf	d1, w23
    5b68:	fd4a1e80 	ldr	d0, [x20, #5176]
    5b6c:	1e612800 	fadd	d0, d0, d1
    5b70:	fd0a1e80 	str	d0, [x20, #5176]
    5b74:	52800041 	mov	w1, #0x2                   	// #2
    5b78:	29000678 	stp	w24, w1, [x19]
    5b7c:	aa1303e0 	mov	x0, x19
    5b80:	f94002a1 	ldr	x1, [x21]
    5b84:	f9000661 	str	x1, [x19, #8]
    5b88:	f94006a1 	ldr	x1, [x21, #8]
    5b8c:	f9000a61 	str	x1, [x19, #16]
    5b90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b98:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b9c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5ba0:	d65f03c0 	ret
    5ba4:	8b020063 	add	x3, x3, x2
    5ba8:	f9400473 	ldr	x19, [x3, #8]
    5bac:	b4000113 	cbz	x19, 5bcc <fwp_data.part.0.constprop.0+0x108>
    5bb0:	f9400860 	ldr	x0, [x3, #16]
    5bb4:	cb130000 	sub	x0, x0, x19
    5bb8:	eb0002df 	cmp	x22, x0
    5bbc:	54000088 	b.hi	5bcc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5bc0:	8b160260 	add	x0, x19, x22
    5bc4:	f9000460 	str	x0, [x3, #8]
    5bc8:	17ffffd5 	b	5b1c <fwp_data.part.0.constprop.0+0x58>
    5bcc:	52800001 	mov	w1, #0x0                   	// #0
    5bd0:	d2800300 	mov	x0, #0x18                  	// #24
    5bd4:	97fffcc7 	bl	4ef0 <fwp_heap_alloc>
    5bd8:	aa0003f3 	mov	x19, x0
    5bdc:	17ffffe6 	b	5b74 <fwp_data.part.0.constprop.0+0xb0>
    5be0:	97fff514 	bl	3030 <fwp_heap_oom>

0000000000005be4 <fwp_rc_share>:
    5be4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5be8:	91174042 	add	x2, x2, #0x5d0
    5bec:	f949d843 	ldr	x3, [x2, #5040]
    5bf0:	f949ec41 	ldr	x1, [x2, #5080]
    5bf4:	cb030000 	sub	x0, x0, x3
    5bf8:	eb01401f 	cmp	x0, x1, lsl #16
    5bfc:	540003a2 	b.cs	5c70 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c00:	d350fc01 	lsr	x1, x0, #16
    5c04:	f949fc44 	ldr	x4, [x2, #5112]
    5c08:	8b010821 	add	x1, x1, x1, lsl #2
    5c0c:	d37df021 	lsl	x1, x1, #3
    5c10:	8b010083 	add	x3, x4, x1
    5c14:	f9401062 	ldr	x2, [x3, #32]
    5c18:	b40002c2 	cbz	x2, 5c70 <fwp_rc_share+0x8c>
    5c1c:	38616881 	ldrb	w1, [x4, x1]
    5c20:	7100083f 	cmp	w1, #0x2
    5c24:	54000220 	b.eq	5c68 <fwp_rc_share+0x84>  // b.none
    5c28:	7100043f 	cmp	w1, #0x1
    5c2c:	54000221 	b.ne	5c70 <fwp_rc_share+0x8c>  // b.any
    5c30:	29430464 	ldp	w4, w1, [x3, #24]
    5c34:	92403c00 	and	x0, x0, #0xffff
    5c38:	9b047c00 	mul	x0, x0, x4
    5c3c:	d360fc00 	lsr	x0, x0, #32
    5c40:	eb01001f 	cmp	x0, x1
    5c44:	54000162 	b.cs	5c70 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c48:	8b000042 	add	x2, x2, x0
    5c4c:	39400040 	ldrb	w0, [x2]
    5c50:	34000100 	cbz	w0, 5c70 <fwp_rc_share+0x8c>
    5c54:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5c58:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5c5c:	91194000 	add	x0, x0, #0x650
    5c60:	910003fd 	mov	x29, sp
    5c64:	97fff92b 	bl	4110 <fwp_trap>
    5c68:	72003c1f 	tst	w0, #0xffff
    5c6c:	54ffff00 	b.eq	5c4c <fwp_rc_share+0x68>  // b.none
    5c70:	d65f03c0 	ret

0000000000005c74 <fwp_rc_free_arr>:
    5c74:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5c78:	91174063 	add	x3, x3, #0x5d0
    5c7c:	f949d861 	ldr	x1, [x3, #5040]
    5c80:	f949ec62 	ldr	x2, [x3, #5080]
    5c84:	cb010001 	sub	x1, x0, x1
    5c88:	eb02403f 	cmp	x1, x2, lsl #16
    5c8c:	54000342 	b.cs	5cf4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c90:	d350fc22 	lsr	x2, x1, #16
    5c94:	f949fc65 	ldr	x5, [x3, #5112]
    5c98:	8b020842 	add	x2, x2, x2, lsl #2
    5c9c:	d37df042 	lsl	x2, x2, #3
    5ca0:	8b0200a4 	add	x4, x5, x2
    5ca4:	f9401083 	ldr	x3, [x4, #32]
    5ca8:	b4000263 	cbz	x3, 5cf4 <fwp_rc_free_arr+0x80>
    5cac:	386268a2 	ldrb	w2, [x5, x2]
    5cb0:	7100085f 	cmp	w2, #0x2
    5cb4:	540001c0 	b.eq	5cec <fwp_rc_free_arr+0x78>  // b.none
    5cb8:	7100045f 	cmp	w2, #0x1
    5cbc:	540001c1 	b.ne	5cf4 <fwp_rc_free_arr+0x80>  // b.any
    5cc0:	29430885 	ldp	w5, w2, [x4, #24]
    5cc4:	92403c21 	and	x1, x1, #0xffff
    5cc8:	9b057c21 	mul	x1, x1, x5
    5ccc:	d360fc21 	lsr	x1, x1, #32
    5cd0:	eb02003f 	cmp	x1, x2
    5cd4:	54000102 	b.cs	5cf4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5cd8:	8b010063 	add	x3, x3, x1
    5cdc:	39400061 	ldrb	w1, [x3]
    5ce0:	7100043f 	cmp	w1, #0x1
    5ce4:	54000081 	b.ne	5cf4 <fwp_rc_free_arr+0x80>  // b.any
    5ce8:	17fff9c6 	b	4400 <fwp_mem_free>
    5cec:	72003c3f 	tst	w1, #0xffff
    5cf0:	54ffff60 	b.eq	5cdc <fwp_rc_free_arr+0x68>  // b.none
    5cf4:	d65f03c0 	ret
    5cf8:	d503201f 	nop
    5cfc:	d503201f 	nop

0000000000005d00 <fwp_rc_dup>:
    5d00:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5d04:	91174042 	add	x2, x2, #0x5d0
    5d08:	f949d841 	ldr	x1, [x2, #5040]
    5d0c:	f949ec43 	ldr	x3, [x2, #5080]
    5d10:	cb010001 	sub	x1, x0, x1
    5d14:	eb03403f 	cmp	x1, x3, lsl #16
    5d18:	54000342 	b.cs	5d80 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5d1c:	d350fc20 	lsr	x0, x1, #16
    5d20:	f949fc44 	ldr	x4, [x2, #5112]
    5d24:	8b000800 	add	x0, x0, x0, lsl #2
    5d28:	d37df002 	lsl	x2, x0, #3
    5d2c:	8b020083 	add	x3, x4, x2
    5d30:	f9401060 	ldr	x0, [x3, #32]
    5d34:	b4000260 	cbz	x0, 5d80 <fwp_rc_dup+0x80>
    5d38:	38626882 	ldrb	w2, [x4, x2]
    5d3c:	7100085f 	cmp	w2, #0x2
    5d40:	54000220 	b.eq	5d84 <fwp_rc_dup+0x84>  // b.none
    5d44:	7100045f 	cmp	w2, #0x1
    5d48:	540001c1 	b.ne	5d80 <fwp_rc_dup+0x80>  // b.any
    5d4c:	29430864 	ldp	w4, w2, [x3, #24]
    5d50:	92403c21 	and	x1, x1, #0xffff
    5d54:	9b047c21 	mul	x1, x1, x4
    5d58:	d360fc21 	lsr	x1, x1, #32
    5d5c:	eb02003f 	cmp	x1, x2
    5d60:	54000102 	b.cs	5d80 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5d64:	8b010000 	add	x0, x0, x1
    5d68:	39400001 	ldrb	w1, [x0]
    5d6c:	340000a1 	cbz	w1, 5d80 <fwp_rc_dup+0x80>
    5d70:	7103f43f 	cmp	w1, #0xfd
    5d74:	540000e8 	b.hi	5d90 <fwp_rc_dup+0x90>  // b.pmore
    5d78:	11000421 	add	w1, w1, #0x1
    5d7c:	39000001 	strb	w1, [x0]
    5d80:	d65f03c0 	ret
    5d84:	72003c3f 	tst	w1, #0xffff
    5d88:	54ffff00 	b.eq	5d68 <fwp_rc_dup+0x68>  // b.none
    5d8c:	d65f03c0 	ret
    5d90:	17fffa15 	b	45e4 <fwp_rc_wide_dup>

0000000000005d94 <fwp_drop0>:
    5d94:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d98:	910003fd 	mov	x29, sp
    5d9c:	a90153f3 	stp	x19, x20, [sp, #16]
    5da0:	f90013f5 	str	x21, [sp, #32]
    5da4:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5da8:	911742b4 	add	x20, x21, #0x5d0
    5dac:	f949da81 	ldr	x1, [x20, #5040]
    5db0:	f949ee82 	ldr	x2, [x20, #5080]
    5db4:	cb010001 	sub	x1, x0, x1
    5db8:	eb02403f 	cmp	x1, x2, lsl #16
    5dbc:	54000382 	b.cs	5e2c <fwp_drop0+0x98>  // b.hs, b.nlast
    5dc0:	d350fc22 	lsr	x2, x1, #16
    5dc4:	f949fe84 	ldr	x4, [x20, #5112]
    5dc8:	8b020842 	add	x2, x2, x2, lsl #2
    5dcc:	d37df042 	lsl	x2, x2, #3
    5dd0:	8b020083 	add	x3, x4, x2
    5dd4:	f9401073 	ldr	x19, [x3, #32]
    5dd8:	b40002b3 	cbz	x19, 5e2c <fwp_drop0+0x98>
    5ddc:	38626882 	ldrb	w2, [x4, x2]
    5de0:	7100085f 	cmp	w2, #0x2
    5de4:	540002c0 	b.eq	5e3c <fwp_drop0+0xa8>  // b.none
    5de8:	7100045f 	cmp	w2, #0x1
    5dec:	54000201 	b.ne	5e2c <fwp_drop0+0x98>  // b.any
    5df0:	29430864 	ldp	w4, w2, [x3, #24]
    5df4:	92403c21 	and	x1, x1, #0xffff
    5df8:	9b047c21 	mul	x1, x1, x4
    5dfc:	d360fc21 	lsr	x1, x1, #32
    5e00:	eb02003f 	cmp	x1, x2
    5e04:	54000142 	b.cs	5e2c <fwp_drop0+0x98>  // b.hs, b.nlast
    5e08:	8b010273 	add	x19, x19, x1
    5e0c:	39400261 	ldrb	w1, [x19]
    5e10:	340000e1 	cbz	w1, 5e2c <fwp_drop0+0x98>
    5e14:	7100043f 	cmp	w1, #0x1
    5e18:	540001e0 	b.eq	5e54 <fwp_drop0+0xc0>  // b.none
    5e1c:	7103fc3f 	cmp	w1, #0xff
    5e20:	540002e0 	b.eq	5e7c <fwp_drop0+0xe8>  // b.none
    5e24:	51000421 	sub	w1, w1, #0x1
    5e28:	39000261 	strb	w1, [x19]
    5e2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e30:	f94013f5 	ldr	x21, [sp, #32]
    5e34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e38:	d65f03c0 	ret
    5e3c:	72003c3f 	tst	w1, #0xffff
    5e40:	54fffe60 	b.eq	5e0c <fwp_drop0+0x78>  // b.none
    5e44:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e48:	f94013f5 	ldr	x21, [sp, #32]
    5e4c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e50:	d65f03c0 	ret
    5e54:	f9400813 	ldr	x19, [x0, #16]
    5e58:	97ffff87 	bl	5c74 <fwp_rc_free_arr>
    5e5c:	911742a0 	add	x0, x21, #0x5d0
    5e60:	f949d801 	ldr	x1, [x0, #5040]
    5e64:	f949ec00 	ldr	x0, [x0, #5080]
    5e68:	cb010261 	sub	x1, x19, x1
    5e6c:	eb00403f 	cmp	x1, x0, lsl #16
    5e70:	54fffde2 	b.cs	5e2c <fwp_drop0+0x98>  // b.hs, b.nlast
    5e74:	aa1303e0 	mov	x0, x19
    5e78:	17ffffd2 	b	5dc0 <fwp_drop0+0x2c>
    5e7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e80:	911742b5 	add	x21, x21, #0x5d0
    5e84:	ca402400 	eor	x0, x0, x0, lsr #9
    5e88:	92401c00 	and	x0, x0, #0xff
    5e8c:	910a2402 	add	x2, x0, #0x289
    5e90:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e94:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e98:	f94a2400 	ldr	x0, [x0, #5192]
    5e9c:	b50000a0 	cbnz	x0, 5eb0 <fwp_drop0+0x11c>
    5ea0:	14000013 	b	5eec <fwp_drop0+0x158>
    5ea4:	91004002 	add	x2, x0, #0x10
    5ea8:	f9400800 	ldr	x0, [x0, #16]
    5eac:	b4000200 	cbz	x0, 5eec <fwp_drop0+0x158>
    5eb0:	f9400001 	ldr	x1, [x0]
    5eb4:	eb13003f 	cmp	x1, x19
    5eb8:	54ffff61 	b.ne	5ea4 <fwp_drop0+0x110>  // b.any
    5ebc:	f9400041 	ldr	x1, [x2]
    5ec0:	f9400420 	ldr	x0, [x1, #8]
    5ec4:	d1000400 	sub	x0, x0, #0x1
    5ec8:	f9000420 	str	x0, [x1, #8]
    5ecc:	f103f81f 	cmp	x0, #0xfe
    5ed0:	54fffae1 	b.ne	5e2c <fwp_drop0+0x98>  // b.any
    5ed4:	39400260 	ldrb	w0, [x19]
    5ed8:	7103fc1f 	cmp	w0, #0xff
    5edc:	540000e0 	b.eq	5ef8 <fwp_drop0+0x164>  // b.none
    5ee0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ee4:	39000260 	strb	w0, [x19]
    5ee8:	17ffffd1 	b	5e2c <fwp_drop0+0x98>
    5eec:	d0000020 	adrp	x0, b000 <__modti3+0x1b0>
    5ef0:	910fa000 	add	x0, x0, #0x3e8
    5ef4:	97fff887 	bl	4110 <fwp_trap>
    5ef8:	aa1303e0 	mov	x0, x19
    5efc:	97fff8a5 	bl	4190 <fwp_rc_forget_slot.part.0>
    5f00:	17fffff8 	b	5ee0 <fwp_drop0+0x14c>

0000000000005f04 <fwp_arg_drop12>:
    5f04:	7100003f 	cmp	w1, #0x0
    5f08:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5f0c:	54000041 	b.ne	5f14 <fwp_arg_drop12+0x10>  // b.any
    5f10:	d65f03c0 	ret
    5f14:	f9400000 	ldr	x0, [x0]
    5f18:	17ffff9f 	b	5d94 <fwp_drop0>
    5f1c:	d503201f 	nop

0000000000005f20 <fwp_drop1>:
    5f20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f24:	910003fd 	mov	x29, sp
    5f28:	a90153f3 	stp	x19, x20, [sp, #16]
    5f2c:	f90013f5 	str	x21, [sp, #32]
    5f30:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5f34:	911742b4 	add	x20, x21, #0x5d0
    5f38:	f949da81 	ldr	x1, [x20, #5040]
    5f3c:	f949ee82 	ldr	x2, [x20, #5080]
    5f40:	cb010001 	sub	x1, x0, x1
    5f44:	eb02403f 	cmp	x1, x2, lsl #16
    5f48:	54000382 	b.cs	5fb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f4c:	d350fc22 	lsr	x2, x1, #16
    5f50:	f949fe84 	ldr	x4, [x20, #5112]
    5f54:	8b020842 	add	x2, x2, x2, lsl #2
    5f58:	d37df042 	lsl	x2, x2, #3
    5f5c:	8b020083 	add	x3, x4, x2
    5f60:	f9401073 	ldr	x19, [x3, #32]
    5f64:	b40002b3 	cbz	x19, 5fb8 <fwp_drop1+0x98>
    5f68:	38626882 	ldrb	w2, [x4, x2]
    5f6c:	7100085f 	cmp	w2, #0x2
    5f70:	540002c0 	b.eq	5fc8 <fwp_drop1+0xa8>  // b.none
    5f74:	7100045f 	cmp	w2, #0x1
    5f78:	54000201 	b.ne	5fb8 <fwp_drop1+0x98>  // b.any
    5f7c:	29430864 	ldp	w4, w2, [x3, #24]
    5f80:	92403c21 	and	x1, x1, #0xffff
    5f84:	9b047c21 	mul	x1, x1, x4
    5f88:	d360fc21 	lsr	x1, x1, #32
    5f8c:	eb02003f 	cmp	x1, x2
    5f90:	54000142 	b.cs	5fb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f94:	8b010273 	add	x19, x19, x1
    5f98:	39400261 	ldrb	w1, [x19]
    5f9c:	340000e1 	cbz	w1, 5fb8 <fwp_drop1+0x98>
    5fa0:	7100043f 	cmp	w1, #0x1
    5fa4:	540001e0 	b.eq	5fe0 <fwp_drop1+0xc0>  // b.none
    5fa8:	7103fc3f 	cmp	w1, #0xff
    5fac:	540002e0 	b.eq	6008 <fwp_drop1+0xe8>  // b.none
    5fb0:	51000421 	sub	w1, w1, #0x1
    5fb4:	39000261 	strb	w1, [x19]
    5fb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fbc:	f94013f5 	ldr	x21, [sp, #32]
    5fc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fc4:	d65f03c0 	ret
    5fc8:	72003c3f 	tst	w1, #0xffff
    5fcc:	54fffe60 	b.eq	5f98 <fwp_drop1+0x78>  // b.none
    5fd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fd4:	f94013f5 	ldr	x21, [sp, #32]
    5fd8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fdc:	d65f03c0 	ret
    5fe0:	f9400813 	ldr	x19, [x0, #16]
    5fe4:	97ffff24 	bl	5c74 <fwp_rc_free_arr>
    5fe8:	911742a0 	add	x0, x21, #0x5d0
    5fec:	f949d801 	ldr	x1, [x0, #5040]
    5ff0:	f949ec00 	ldr	x0, [x0, #5080]
    5ff4:	cb010261 	sub	x1, x19, x1
    5ff8:	eb00403f 	cmp	x1, x0, lsl #16
    5ffc:	54fffde2 	b.cs	5fb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6000:	aa1303e0 	mov	x0, x19
    6004:	17ffffd2 	b	5f4c <fwp_drop1+0x2c>
    6008:	ca534660 	eor	x0, x19, x19, lsr #17
    600c:	911742b5 	add	x21, x21, #0x5d0
    6010:	ca402400 	eor	x0, x0, x0, lsr #9
    6014:	92401c00 	and	x0, x0, #0xff
    6018:	910a2402 	add	x2, x0, #0x289
    601c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6020:	8b020ea2 	add	x2, x21, x2, lsl #3
    6024:	f94a2400 	ldr	x0, [x0, #5192]
    6028:	b50000a0 	cbnz	x0, 603c <fwp_drop1+0x11c>
    602c:	14000013 	b	6078 <fwp_drop1+0x158>
    6030:	91004002 	add	x2, x0, #0x10
    6034:	f9400800 	ldr	x0, [x0, #16]
    6038:	b4000200 	cbz	x0, 6078 <fwp_drop1+0x158>
    603c:	f9400001 	ldr	x1, [x0]
    6040:	eb13003f 	cmp	x1, x19
    6044:	54ffff61 	b.ne	6030 <fwp_drop1+0x110>  // b.any
    6048:	f9400041 	ldr	x1, [x2]
    604c:	f9400420 	ldr	x0, [x1, #8]
    6050:	d1000400 	sub	x0, x0, #0x1
    6054:	f9000420 	str	x0, [x1, #8]
    6058:	f103f81f 	cmp	x0, #0xfe
    605c:	54fffae1 	b.ne	5fb8 <fwp_drop1+0x98>  // b.any
    6060:	39400260 	ldrb	w0, [x19]
    6064:	7103fc1f 	cmp	w0, #0xff
    6068:	540000e0 	b.eq	6084 <fwp_drop1+0x164>  // b.none
    606c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6070:	39000260 	strb	w0, [x19]
    6074:	17ffffd1 	b	5fb8 <fwp_drop1+0x98>
    6078:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    607c:	910fa000 	add	x0, x0, #0x3e8
    6080:	97fff824 	bl	4110 <fwp_trap>
    6084:	aa1303e0 	mov	x0, x19
    6088:	97fff842 	bl	4190 <fwp_rc_forget_slot.part.0>
    608c:	17fffff8 	b	606c <fwp_drop1+0x14c>

0000000000006090 <fwp_closure_drop>:
    6090:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    6094:	911740a4 	add	x4, x5, #0x5d0
    6098:	aa0003e1 	mov	x1, x0
    609c:	f949d882 	ldr	x2, [x4, #5040]
    60a0:	f949ec80 	ldr	x0, [x4, #5080]
    60a4:	cb020022 	sub	x2, x1, x2
    60a8:	eb00405f 	cmp	x2, x0, lsl #16
    60ac:	54000662 	b.cs	6178 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    60b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60b4:	d350fc43 	lsr	x3, x2, #16
    60b8:	910003fd 	mov	x29, sp
    60bc:	8b030863 	add	x3, x3, x3, lsl #2
    60c0:	f949fc84 	ldr	x4, [x4, #5112]
    60c4:	d37df063 	lsl	x3, x3, #3
    60c8:	f9000bf3 	str	x19, [sp, #16]
    60cc:	8b030080 	add	x0, x4, x3
    60d0:	f9401013 	ldr	x19, [x0, #32]
    60d4:	b40002b3 	cbz	x19, 6128 <fwp_closure_drop+0x98>
    60d8:	38636883 	ldrb	w3, [x4, x3]
    60dc:	7100087f 	cmp	w3, #0x2
    60e0:	54000420 	b.eq	6164 <fwp_closure_drop+0xd4>  // b.none
    60e4:	7100047f 	cmp	w3, #0x1
    60e8:	54000201 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    60ec:	29430003 	ldp	w3, w0, [x0, #24]
    60f0:	92403c42 	and	x2, x2, #0xffff
    60f4:	9b037c42 	mul	x2, x2, x3
    60f8:	d360fc42 	lsr	x2, x2, #32
    60fc:	eb00005f 	cmp	x2, x0
    6100:	54000142 	b.cs	6128 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6104:	8b020273 	add	x19, x19, x2
    6108:	39400260 	ldrb	w0, [x19]
    610c:	340000e0 	cbz	w0, 6128 <fwp_closure_drop+0x98>
    6110:	7100041f 	cmp	w0, #0x1
    6114:	54000100 	b.eq	6134 <fwp_closure_drop+0xa4>  // b.none
    6118:	7103fc1f 	cmp	w0, #0xff
    611c:	54000300 	b.eq	617c <fwp_closure_drop+0xec>  // b.none
    6120:	51000400 	sub	w0, w0, #0x1
    6124:	39000260 	strb	w0, [x19]
    6128:	f9400bf3 	ldr	x19, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	d65f03c0 	ret
    6134:	d53bd040 	mrs	x0, tpidr_el0
    6138:	91400000 	add	x0, x0, #0x0, lsl #12
    613c:	91004000 	add	x0, x0, #0x10
    6140:	f9400000 	ldr	x0, [x0]
    6144:	b4000080 	cbz	x0, 6154 <fwp_closure_drop+0xc4>
    6148:	f9400bf3 	ldr	x19, [sp, #16]
    614c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6150:	17fff96c 	b	4700 <fwp_closure_drop_push>
    6154:	f9400bf3 	ldr	x19, [sp, #16]
    6158:	aa0103e0 	mov	x0, x1
    615c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6160:	17fff9ad 	b	4814 <fwp_closure_drop.part.0>
    6164:	72003c5f 	tst	w2, #0xffff
    6168:	54fffd00 	b.eq	6108 <fwp_closure_drop+0x78>  // b.none
    616c:	f9400bf3 	ldr	x19, [sp, #16]
    6170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6174:	d65f03c0 	ret
    6178:	d65f03c0 	ret
    617c:	ca534660 	eor	x0, x19, x19, lsr #17
    6180:	911740a5 	add	x5, x5, #0x5d0
    6184:	ca402400 	eor	x0, x0, x0, lsr #9
    6188:	92401c00 	and	x0, x0, #0xff
    618c:	910a2402 	add	x2, x0, #0x289
    6190:	8b000ca0 	add	x0, x5, x0, lsl #3
    6194:	8b020ca2 	add	x2, x5, x2, lsl #3
    6198:	f94a2400 	ldr	x0, [x0, #5192]
    619c:	b50000a0 	cbnz	x0, 61b0 <fwp_closure_drop+0x120>
    61a0:	14000013 	b	61ec <fwp_closure_drop+0x15c>
    61a4:	91004002 	add	x2, x0, #0x10
    61a8:	f9400800 	ldr	x0, [x0, #16]
    61ac:	b4000200 	cbz	x0, 61ec <fwp_closure_drop+0x15c>
    61b0:	f9400001 	ldr	x1, [x0]
    61b4:	eb13003f 	cmp	x1, x19
    61b8:	54ffff61 	b.ne	61a4 <fwp_closure_drop+0x114>  // b.any
    61bc:	f9400041 	ldr	x1, [x2]
    61c0:	f9400420 	ldr	x0, [x1, #8]
    61c4:	d1000400 	sub	x0, x0, #0x1
    61c8:	f9000420 	str	x0, [x1, #8]
    61cc:	f103f81f 	cmp	x0, #0xfe
    61d0:	54fffac1 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    61d4:	39400260 	ldrb	w0, [x19]
    61d8:	7103fc1f 	cmp	w0, #0xff
    61dc:	540000e0 	b.eq	61f8 <fwp_closure_drop+0x168>  // b.none
    61e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61e4:	39000260 	strb	w0, [x19]
    61e8:	17ffffd0 	b	6128 <fwp_closure_drop+0x98>
    61ec:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    61f0:	910fa000 	add	x0, x0, #0x3e8
    61f4:	97fff7c7 	bl	4110 <fwp_trap>
    61f8:	aa1303e0 	mov	x0, x19
    61fc:	97fff7e5 	bl	4190 <fwp_rc_forget_slot.part.0>
    6200:	17fffff8 	b	61e0 <fwp_closure_drop+0x150>

0000000000006204 <fwp_owned_tape_release>:
    6204:	b4000920 	cbz	x0, 6328 <fwp_owned_tape_release+0x124>
    6208:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    620c:	910003fd 	mov	x29, sp
    6210:	a90153f3 	stp	x19, x20, [sp, #16]
    6214:	aa0003f3 	mov	x19, x0
    6218:	f9400000 	ldr	x0, [x0]
    621c:	b4000060 	cbz	x0, 6228 <fwp_owned_tape_release+0x24>
    6220:	f9400661 	ldr	x1, [x19, #8]
    6224:	f9000401 	str	x1, [x0, #8]
    6228:	f9400661 	ldr	x1, [x19, #8]
    622c:	b4000041 	cbz	x1, 6234 <fwp_owned_tape_release+0x30>
    6230:	f9000020 	str	x0, [x1]
    6234:	f9400a60 	ldr	x0, [x19, #16]
    6238:	f9403401 	ldr	x1, [x0, #104]
    623c:	b40005a1 	cbz	x1, 62f0 <fwp_owned_tape_release+0xec>
    6240:	a9450a60 	ldp	x0, x2, [x19, #80]
    6244:	eb00005f 	cmp	x2, x0
    6248:	540002cd 	b.le	62a0 <fwp_owned_tape_release+0x9c>
    624c:	d2800014 	mov	x20, #0x0                   	// #0
    6250:	f90013f5 	str	x21, [sp, #32]
    6254:	d2800015 	mov	x21, #0x0                   	// #0
    6258:	f9402260 	ldr	x0, [x19, #64]
    625c:	910006b5 	add	x21, x21, #0x1
    6260:	f8746800 	ldr	x0, [x0, x20]
    6264:	d63f0020 	blr	x1
    6268:	f9402260 	ldr	x0, [x19, #64]
    626c:	f9400a61 	ldr	x1, [x19, #16]
    6270:	8b140000 	add	x0, x0, x20
    6274:	91004294 	add	x20, x20, #0x10
    6278:	f9400400 	ldr	x0, [x0, #8]
    627c:	f9403421 	ldr	x1, [x1, #104]
    6280:	d63f0020 	blr	x1
    6284:	a9450261 	ldp	x1, x0, [x19, #80]
    6288:	cb010000 	sub	x0, x0, x1
    628c:	eb15001f 	cmp	x0, x21
    6290:	f9400a60 	ldr	x0, [x19, #16]
    6294:	f9403401 	ldr	x1, [x0, #104]
    6298:	54fffe0c 	b.gt	6258 <fwp_owned_tape_release+0x54>
    629c:	f94013f5 	ldr	x21, [sp, #32]
    62a0:	f9403663 	ldr	x3, [x19, #104]
    62a4:	f9401262 	ldr	x2, [x19, #32]
    62a8:	f100007f 	cmp	x3, #0x0
    62ac:	540001ed 	b.le	62e8 <fwp_owned_tape_release+0xe4>
    62b0:	d2800014 	mov	x20, #0x0                   	// #0
    62b4:	d503201f 	nop
    62b8:	f9402660 	ldr	x0, [x19, #72]
    62bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    62c0:	eb02001f 	cmp	x0, x2
    62c4:	540000c0 	b.eq	62dc <fwp_owned_tape_release+0xd8>  // b.none
    62c8:	d63f0020 	blr	x1
    62cc:	f9400a60 	ldr	x0, [x19, #16]
    62d0:	f9401262 	ldr	x2, [x19, #32]
    62d4:	f9403663 	ldr	x3, [x19, #104]
    62d8:	f9403401 	ldr	x1, [x0, #104]
    62dc:	91000694 	add	x20, x20, #0x1
    62e0:	eb14007f 	cmp	x3, x20
    62e4:	54fffeac 	b.gt	62b8 <fwp_owned_tape_release+0xb4>
    62e8:	aa0203e0 	mov	x0, x2
    62ec:	d63f0020 	blr	x1
    62f0:	f9401660 	ldr	x0, [x19, #40]
    62f4:	97ffff67 	bl	6090 <fwp_closure_drop>
    62f8:	f9401a60 	ldr	x0, [x19, #48]
    62fc:	97ffff65 	bl	6090 <fwp_closure_drop>
    6300:	f9401e60 	ldr	x0, [x19, #56]
    6304:	97ffff63 	bl	6090 <fwp_closure_drop>
    6308:	f9402260 	ldr	x0, [x19, #64]
    630c:	97fff83d 	bl	4400 <fwp_mem_free>
    6310:	f9402660 	ldr	x0, [x19, #72]
    6314:	97fff83b 	bl	4400 <fwp_mem_free>
    6318:	aa1303e0 	mov	x0, x19
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6324:	17fff837 	b	4400 <fwp_mem_free>
    6328:	d65f03c0 	ret
    632c:	d503201f 	nop

0000000000006330 <fwp_tape_finish>:
    6330:	d10203ff 	sub	sp, sp, #0x80
    6334:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6338:	f947f421 	ldr	x1, [x1, #4072]
    633c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6340:	910103fd 	add	x29, sp, #0x40
    6344:	a90553f3 	stp	x19, x20, [sp, #80]
    6348:	a9065bf5 	stp	x21, x22, [sp, #96]
    634c:	a90763f7 	stp	x23, x24, [sp, #112]
    6350:	d00000d8 	adrp	x24, 20000 <__data_start>
    6354:	9101c316 	add	x22, x24, #0x70
    6358:	f9400022 	ldr	x2, [x1]
    635c:	f9001fe2 	str	x2, [sp, #56]
    6360:	d2800002 	mov	x2, #0x0                   	// #0
    6364:	910222c0 	add	x0, x22, #0x88
    6368:	97fff446 	bl	3480 <fwp_tape_buffers_dispose>
    636c:	f90062df 	str	xzr, [x22, #192]
    6370:	f9406ac0 	ldr	x0, [x22, #208]
    6374:	f100001f 	cmp	x0, #0x0
    6378:	5400030d 	b.le	63d8 <fwp_tape_finish+0xa8>
    637c:	910003f7 	mov	x23, sp
    6380:	d2800015 	mov	x21, #0x0                   	// #0
    6384:	d2800014 	mov	x20, #0x0                   	// #0
    6388:	f94002d3 	ldr	x19, [x22]
    638c:	91000694 	add	x20, x20, #0x1
    6390:	8b150273 	add	x19, x19, x21
    6394:	9101a2b5 	add	x21, x21, #0x68
    6398:	aa1303e0 	mov	x0, x19
    639c:	97fff2fd 	bl	2f90 <fwp_tape_unlink_scope>
    63a0:	aa1703e0 	mov	x0, x23
    63a4:	f9401261 	ldr	x1, [x19, #32]
    63a8:	f90003e1 	str	x1, [sp]
    63ac:	f9401a62 	ldr	x2, [x19, #48]
    63b0:	f9000be2 	str	x2, [sp, #16]
    63b4:	f9402261 	ldr	x1, [x19, #64]
    63b8:	f90013e1 	str	x1, [sp, #32]
    63bc:	97fff431 	bl	3480 <fwp_tape_buffers_dispose>
    63c0:	f9403260 	ldr	x0, [x19, #96]
    63c4:	97ffff90 	bl	6204 <fwp_owned_tape_release>
    63c8:	f900327f 	str	xzr, [x19, #96]
    63cc:	f9406ac0 	ldr	x0, [x22, #208]
    63d0:	eb14001f 	cmp	x0, x20
    63d4:	54fffdac 	b.gt	6388 <fwp_tape_finish+0x58>
    63d8:	f9403b00 	ldr	x0, [x24, #112]
    63dc:	9101c313 	add	x19, x24, #0x70
    63e0:	97fff158 	bl	2940 <free@plt>
    63e4:	f9003b1f 	str	xzr, [x24, #112]
    63e8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    63ec:	f947f400 	ldr	x0, [x0, #4072]
    63f0:	f9006a7f 	str	xzr, [x19, #208]
    63f4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    63f8:	f9401fe2 	ldr	x2, [sp, #56]
    63fc:	f9400001 	ldr	x1, [x0]
    6400:	eb010042 	subs	x2, x2, x1
    6404:	d2800001 	mov	x1, #0x0                   	// #0
    6408:	540000e1 	b.ne	6424 <fwp_tape_finish+0xf4>  // b.any
    640c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6410:	a94553f3 	ldp	x19, x20, [sp, #80]
    6414:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6418:	a94763f7 	ldp	x23, x24, [sp, #112]
    641c:	910203ff 	add	sp, sp, #0x80
    6420:	d65f03c0 	ret
    6424:	97fff117 	bl	2880 <__stack_chk_fail@plt>
    6428:	d503201f 	nop
    642c:	d503201f 	nop

0000000000006430 <fwp_tape_scope_release>:
    6430:	d10243ff 	sub	sp, sp, #0x90
    6434:	a9047bfd 	stp	x29, x30, [sp, #64]
    6438:	910103fd 	add	x29, sp, #0x40
    643c:	a90553f3 	stp	x19, x20, [sp, #80]
    6440:	aa0003f4 	mov	x20, x0
    6444:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6448:	f947f400 	ldr	x0, [x0, #4072]
    644c:	b9400285 	ldr	w5, [x20]
    6450:	f9400001 	ldr	x1, [x0]
    6454:	f9001fe1 	str	x1, [sp, #56]
    6458:	d2800001 	mov	x1, #0x0                   	// #0
    645c:	37f806c5 	tbnz	w5, #31, 6534 <fwp_tape_scope_release+0x104>
    6460:	a90763f7 	stp	x23, x24, [sp, #112]
    6464:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6468:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    646c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6470:	d00000d3 	adrp	x19, 20000 <__data_start>
    6474:	910003f7 	mov	x23, sp
    6478:	9101c273 	add	x19, x19, #0x70
    647c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6480:	a9065bf5 	stp	x21, x22, [sp, #96]
    6484:	52800d16 	mov	w22, #0x68                  	// #104
    6488:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    648c:	f90043f9 	str	x25, [sp, #128]
    6490:	14000006 	b	64a8 <fwp_tape_scope_release+0x78>
    6494:	97fff3fb 	bl	3480 <fwp_tape_buffers_dispose>
    6498:	aa1903e0 	mov	x0, x25
    649c:	97ffff5a 	bl	6204 <fwp_owned_tape_release>
    64a0:	b9400285 	ldr	w5, [x20]
    64a4:	37f80425 	tbnz	w5, #31, 6528 <fwp_tape_scope_release+0xf8>
    64a8:	f9400266 	ldr	x6, [x19]
    64ac:	9b367ca5 	smull	x5, w5, w22
    64b0:	8b0500c0 	add	x0, x6, x5
    64b4:	97fff2b7 	bl	2f90 <fwp_tape_unlink_scope>
    64b8:	ad410001 	ldp	q1, q0, [x0, #32]
    64bc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    64c0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    64c4:	f9400c03 	ldr	x3, [x0, #24]
    64c8:	ad0003e1 	stp	q1, q0, [sp]
    64cc:	b86568c1 	ldr	w1, [x6, x5]
    64d0:	a9440804 	ldp	x4, x2, [x0, #64]
    64d4:	b900041f 	str	wzr, [x0, #4]
    64d8:	f9403019 	ldr	x25, [x0, #96]
    64dc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    64e0:	f9000c1f 	str	xzr, [x0, #24]
    64e4:	a9020fe4 	stp	x4, x3, [sp, #32]
    64e8:	f9001be2 	str	x2, [sp, #48]
    64ec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    64f0:	f900301f 	str	xzr, [x0, #96]
    64f4:	6b15003f 	cmp	w1, w21
    64f8:	540000e8 	b.hi	6514 <fwp_tape_scope_release+0xe4>  // b.pmore
    64fc:	9343fca5 	asr	x5, x5, #3
    6500:	f9407660 	ldr	x0, [x19, #232]
    6504:	9b187ca5 	mul	x5, x5, x24
    6508:	eb0000bf 	cmp	x5, x0
    650c:	5400004a 	b.ge	6514 <fwp_tape_scope_release+0xe4>  // b.tcont
    6510:	f9007665 	str	x5, [x19, #232]
    6514:	aa1703e0 	mov	x0, x23
    6518:	b5fffbf9 	cbnz	x25, 6494 <fwp_tape_scope_release+0x64>
    651c:	97fff6b5 	bl	3ff0 <fwp_tape_buffers_release>
    6520:	b9400285 	ldr	w5, [x20]
    6524:	36fffc25 	tbz	w5, #31, 64a8 <fwp_tape_scope_release+0x78>
    6528:	a9465bf5 	ldp	x21, x22, [sp, #96]
    652c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6530:	f94043f9 	ldr	x25, [sp, #128]
    6534:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6538:	f947f400 	ldr	x0, [x0, #4072]
    653c:	f9401fe2 	ldr	x2, [sp, #56]
    6540:	f9400001 	ldr	x1, [x0]
    6544:	eb010042 	subs	x2, x2, x1
    6548:	d2800001 	mov	x1, #0x0                   	// #0
    654c:	540000a1 	b.ne	6560 <fwp_tape_scope_release+0x130>  // b.any
    6550:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6554:	a94553f3 	ldp	x19, x20, [sp, #80]
    6558:	910243ff 	add	sp, sp, #0x90
    655c:	d65f03c0 	ret
    6560:	a9065bf5 	stp	x21, x22, [sp, #96]
    6564:	a90763f7 	stp	x23, x24, [sp, #112]
    6568:	f90043f9 	str	x25, [sp, #128]
    656c:	97fff0c5 	bl	2880 <__stack_chk_fail@plt>

0000000000006570 <fwp_task_dispose>:
    6570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6574:	910003fd 	mov	x29, sp
    6578:	f9000bf3 	str	x19, [sp, #16]
    657c:	aa0003f3 	mov	x19, x0
    6580:	39414000 	ldrb	w0, [x0, #80]
    6584:	36000720 	tbz	w0, #0, 6668 <fwp_task_dispose+0xf8>
    6588:	f9400a60 	ldr	x0, [x19, #16]
    658c:	b50006e0 	cbnz	x0, 6668 <fwp_task_dispose+0xf8>
    6590:	a9478660 	ldp	x0, x1, [x19, #120]
    6594:	39014e7f 	strb	wzr, [x19, #83]
    6598:	f9003e7f 	str	xzr, [x19, #120]
    659c:	f100003f 	cmp	x1, #0x0
    65a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65a4:	54000040 	b.eq	65ac <fwp_task_dispose+0x3c>  // b.none
    65a8:	d63f0020 	blr	x1
    65ac:	f9405660 	ldr	x0, [x19, #168]
    65b0:	97fff794 	bl	4400 <fwp_mem_free>
    65b4:	f900567f 	str	xzr, [x19, #168]
    65b8:	b9405e60 	ldr	w0, [x19, #92]
    65bc:	7100041f 	cmp	w0, #0x1
    65c0:	54000420 	b.eq	6644 <fwp_task_dispose+0xd4>  // b.none
    65c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    65c8:	91174042 	add	x2, x2, #0x5d0
    65cc:	f949d840 	ldr	x0, [x2, #5040]
    65d0:	f949ec41 	ldr	x1, [x2, #5080]
    65d4:	cb000260 	sub	x0, x19, x0
    65d8:	eb01401f 	cmp	x0, x1, lsl #16
    65dc:	540002e2 	b.cs	6638 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65e0:	d350fc01 	lsr	x1, x0, #16
    65e4:	f949fc44 	ldr	x4, [x2, #5112]
    65e8:	8b010821 	add	x1, x1, x1, lsl #2
    65ec:	d37df021 	lsl	x1, x1, #3
    65f0:	8b010083 	add	x3, x4, x1
    65f4:	f9401062 	ldr	x2, [x3, #32]
    65f8:	b4000202 	cbz	x2, 6638 <fwp_task_dispose+0xc8>
    65fc:	38616881 	ldrb	w1, [x4, x1]
    6600:	7100083f 	cmp	w1, #0x2
    6604:	54000280 	b.eq	6654 <fwp_task_dispose+0xe4>  // b.none
    6608:	7100043f 	cmp	w1, #0x1
    660c:	54000161 	b.ne	6638 <fwp_task_dispose+0xc8>  // b.any
    6610:	29430464 	ldp	w4, w1, [x3, #24]
    6614:	92403c00 	and	x0, x0, #0xffff
    6618:	9b047c00 	mul	x0, x0, x4
    661c:	d360fc00 	lsr	x0, x0, #32
    6620:	eb01001f 	cmp	x0, x1
    6624:	540000a2 	b.cs	6638 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6628:	8b000042 	add	x2, x2, x0
    662c:	39400040 	ldrb	w0, [x2]
    6630:	7100041f 	cmp	w0, #0x1
    6634:	54000080 	b.eq	6644 <fwp_task_dispose+0xd4>  // b.none
    6638:	f9400bf3 	ldr	x19, [sp, #16]
    663c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6640:	d65f03c0 	ret
    6644:	aa1303e0 	mov	x0, x19
    6648:	f9400bf3 	ldr	x19, [sp, #16]
    664c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6650:	17fff76c 	b	4400 <fwp_mem_free>
    6654:	72003c1f 	tst	w0, #0xffff
    6658:	54fffea0 	b.eq	662c <fwp_task_dispose+0xbc>  // b.none
    665c:	f9400bf3 	ldr	x19, [sp, #16]
    6660:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6664:	d65f03c0 	ret
    6668:	97fff09a 	bl	28d0 <abort@plt>
    666c:	d503201f 	nop

0000000000006670 <fwp_free_zombie>:
    6670:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6674:	910003fd 	mov	x29, sp
    6678:	a90153f3 	stp	x19, x20, [sp, #16]
    667c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6680:	9101c281 	add	x1, x20, #0x70
    6684:	f9407833 	ldr	x19, [x1, #240]
    6688:	b4000333 	cbz	x19, 66ec <fwp_free_zombie+0x7c>
    668c:	f9400820 	ldr	x0, [x1, #16]
    6690:	eb00027f 	cmp	x19, x0
    6694:	540002c0 	b.eq	66ec <fwp_free_zombie+0x7c>  // b.none
    6698:	b940f822 	ldr	w2, [x1, #248]
    669c:	f9400a60 	ldr	x0, [x19, #16]
    66a0:	7100fc5f 	cmp	w2, #0x3f
    66a4:	5400078c 	b.gt	6794 <fwp_free_zombie+0x124>
    66a8:	91040023 	add	x3, x1, #0x100
    66ac:	11000444 	add	w4, w2, #0x1
    66b0:	b900f824 	str	w4, [x1, #248]
    66b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66bc:	a9530261 	ldp	x1, x0, [x19, #304]
    66c0:	b4000741 	cbz	x1, 67a8 <fwp_free_zombie+0x138>
    66c4:	f9009c20 	str	x0, [x1, #312]
    66c8:	b4000040 	cbz	x0, 66d0 <fwp_free_zombie+0x60>
    66cc:	f9009801 	str	x1, [x0, #304]
    66d0:	9101c294 	add	x20, x20, #0x70
    66d4:	b9405e60 	ldr	w0, [x19, #92]
    66d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    66dc:	f9007a9f 	str	xzr, [x20, #240]
    66e0:	34000140 	cbz	w0, 6708 <fwp_free_zombie+0x98>
    66e4:	7100041f 	cmp	w0, #0x1
    66e8:	54000080 	b.eq	66f8 <fwp_free_zombie+0x88>  // b.none
    66ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    66f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66f4:	d65f03c0 	ret
    66f8:	aa1303e0 	mov	x0, x19
    66fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6700:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6704:	17ffff9b 	b	6570 <fwp_task_dispose>
    6708:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    670c:	91174082 	add	x2, x4, #0x5d0
    6710:	f949d841 	ldr	x1, [x2, #5040]
    6714:	f949ec40 	ldr	x0, [x2, #5080]
    6718:	cb010261 	sub	x1, x19, x1
    671c:	eb00403f 	cmp	x1, x0, lsl #16
    6720:	54fffe62 	b.cs	66ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6724:	d350fc20 	lsr	x0, x1, #16
    6728:	f949fc43 	ldr	x3, [x2, #5112]
    672c:	8b000800 	add	x0, x0, x0, lsl #2
    6730:	d37df000 	lsl	x0, x0, #3
    6734:	8b000062 	add	x2, x3, x0
    6738:	f9401054 	ldr	x20, [x2, #32]
    673c:	b4fffd94 	cbz	x20, 66ec <fwp_free_zombie+0x7c>
    6740:	38606860 	ldrb	w0, [x3, x0]
    6744:	7100081f 	cmp	w0, #0x2
    6748:	54000360 	b.eq	67b4 <fwp_free_zombie+0x144>  // b.none
    674c:	7100041f 	cmp	w0, #0x1
    6750:	54fffce1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    6754:	29430043 	ldp	w3, w0, [x2, #24]
    6758:	92403c21 	and	x1, x1, #0xffff
    675c:	9b037c21 	mul	x1, x1, x3
    6760:	d360fc21 	lsr	x1, x1, #32
    6764:	eb00003f 	cmp	x1, x0
    6768:	54fffc22 	b.cs	66ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    676c:	8b010294 	add	x20, x20, x1
    6770:	39400280 	ldrb	w0, [x20]
    6774:	34fffbc0 	cbz	w0, 66ec <fwp_free_zombie+0x7c>
    6778:	7100041f 	cmp	w0, #0x1
    677c:	54fffbe0 	b.eq	66f8 <fwp_free_zombie+0x88>  // b.none
    6780:	7103fc1f 	cmp	w0, #0xff
    6784:	540001e0 	b.eq	67c0 <fwp_free_zombie+0x150>  // b.none
    6788:	51000400 	sub	w0, w0, #0x1
    678c:	39000280 	strb	w0, [x20]
    6790:	17ffffd7 	b	66ec <fwp_free_zombie+0x7c>
    6794:	f9400e61 	ldr	x1, [x19, #24]
    6798:	97fff082 	bl	29a0 <munmap@plt>
    679c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67a0:	a9530261 	ldp	x1, x0, [x19, #304]
    67a4:	b5fff901 	cbnz	x1, 66c4 <fwp_free_zombie+0x54>
    67a8:	9101c282 	add	x2, x20, #0x70
    67ac:	f9018040 	str	x0, [x2, #768]
    67b0:	17ffffc6 	b	66c8 <fwp_free_zombie+0x58>
    67b4:	72003c3f 	tst	w1, #0xffff
    67b8:	54fff9a1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    67bc:	17ffffed 	b	6770 <fwp_free_zombie+0x100>
    67c0:	ca544680 	eor	x0, x20, x20, lsr #17
    67c4:	91174084 	add	x4, x4, #0x5d0
    67c8:	ca402400 	eor	x0, x0, x0, lsr #9
    67cc:	92401c00 	and	x0, x0, #0xff
    67d0:	910a2402 	add	x2, x0, #0x289
    67d4:	8b000c80 	add	x0, x4, x0, lsl #3
    67d8:	8b020c82 	add	x2, x4, x2, lsl #3
    67dc:	f94a2400 	ldr	x0, [x0, #5192]
    67e0:	b50000a0 	cbnz	x0, 67f4 <fwp_free_zombie+0x184>
    67e4:	14000013 	b	6830 <fwp_free_zombie+0x1c0>
    67e8:	91004002 	add	x2, x0, #0x10
    67ec:	f9400800 	ldr	x0, [x0, #16]
    67f0:	b4000200 	cbz	x0, 6830 <fwp_free_zombie+0x1c0>
    67f4:	f9400001 	ldr	x1, [x0]
    67f8:	eb14003f 	cmp	x1, x20
    67fc:	54ffff61 	b.ne	67e8 <fwp_free_zombie+0x178>  // b.any
    6800:	f9400041 	ldr	x1, [x2]
    6804:	f9400420 	ldr	x0, [x1, #8]
    6808:	d1000400 	sub	x0, x0, #0x1
    680c:	f9000420 	str	x0, [x1, #8]
    6810:	f103f81f 	cmp	x0, #0xfe
    6814:	54fff6c1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    6818:	39400280 	ldrb	w0, [x20]
    681c:	7103fc1f 	cmp	w0, #0xff
    6820:	540000e0 	b.eq	683c <fwp_free_zombie+0x1cc>  // b.none
    6824:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6828:	39000280 	strb	w0, [x20]
    682c:	17ffffb0 	b	66ec <fwp_free_zombie+0x7c>
    6830:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    6834:	910fa000 	add	x0, x0, #0x3e8
    6838:	97fff636 	bl	4110 <fwp_trap>
    683c:	aa1403e0 	mov	x0, x20
    6840:	97fff654 	bl	4190 <fwp_rc_forget_slot.part.0>
    6844:	17fffff8 	b	6824 <fwp_free_zombie+0x1b4>
    6848:	d503201f 	nop
    684c:	d503201f 	nop

0000000000006850 <fwp_block>:
    6850:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6854:	910003fd 	mov	x29, sp
    6858:	a90153f3 	stp	x19, x20, [sp, #16]
    685c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6860:	9101c274 	add	x20, x19, #0x70
    6864:	f9404282 	ldr	x2, [x20, #128]
    6868:	b4000642 	cbz	x2, 6930 <fwp_block+0xe0>
    686c:	9101c261 	add	x1, x19, #0x70
    6870:	f9408040 	ldr	x0, [x2, #256]
    6874:	f9004020 	str	x0, [x1, #128]
    6878:	b40006a0 	cbz	x0, 694c <fwp_block+0xfc>
    687c:	d503201f 	nop
    6880:	9101c263 	add	x3, x19, #0x70
    6884:	3901505f 	strb	wzr, [x2, #84]
    6888:	f9400864 	ldr	x4, [x3, #16]
    688c:	eb02009f 	cmp	x4, x2
    6890:	54000440 	b.eq	6918 <fwp_block+0xc8>  // b.none
    6894:	f9418465 	ldr	x5, [x3, #776]
    6898:	f9000862 	str	x2, [x3, #16]
    689c:	f9400441 	ldr	x1, [x2, #8]
    68a0:	f9004885 	str	x5, [x4, #144]
    68a4:	f9418865 	ldr	x5, [x3, #784]
    68a8:	f9004c85 	str	x5, [x4, #152]
    68ac:	f9418c65 	ldr	x5, [x3, #792]
    68b0:	f9005085 	str	x5, [x4, #160]
    68b4:	f9419065 	ldr	x5, [x3, #800]
    68b8:	f9005485 	str	x5, [x4, #168]
    68bc:	f9419465 	ldr	x5, [x3, #808]
    68c0:	f9005885 	str	x5, [x4, #176]
    68c4:	f9419865 	ldr	x5, [x3, #816]
    68c8:	f9005c85 	str	x5, [x4, #184]
    68cc:	f9419c65 	ldr	x5, [x3, #824]
    68d0:	f9006085 	str	x5, [x4, #192]
    68d4:	f9400480 	ldr	x0, [x4, #8]
    68d8:	f9404844 	ldr	x4, [x2, #144]
    68dc:	f9018464 	str	x4, [x3, #776]
    68e0:	f9404c44 	ldr	x4, [x2, #152]
    68e4:	f9018864 	str	x4, [x3, #784]
    68e8:	f9405044 	ldr	x4, [x2, #160]
    68ec:	f9018c64 	str	x4, [x3, #792]
    68f0:	f9405444 	ldr	x4, [x2, #168]
    68f4:	f9019064 	str	x4, [x3, #800]
    68f8:	f9405844 	ldr	x4, [x2, #176]
    68fc:	f9019464 	str	x4, [x3, #808]
    6900:	a94b8844 	ldp	x4, x2, [x2, #184]
    6904:	f9019864 	str	x4, [x3, #816]
    6908:	f9019c62 	str	x2, [x3, #824]
    690c:	97ffeff5 	bl	28e0 <swapcontext@plt>
    6910:	97ffff58 	bl	6670 <fwp_free_zombie>
    6914:	d503201f 	nop
    6918:	9101c260 	add	x0, x19, #0x70
    691c:	b9434000 	ldr	w0, [x0, #832]
    6920:	340001a0 	cbz	w0, 6954 <fwp_block+0x104>
    6924:	a94153f3 	ldp	x19, x20, [sp, #16]
    6928:	a8c27bfd 	ldp	x29, x30, [sp], #32
    692c:	d65f03c0 	ret
    6930:	97fff840 	bl	4a30 <fwp_poll_events>
    6934:	f9404282 	ldr	x2, [x20, #128]
    6938:	b4ffffc2 	cbz	x2, 6930 <fwp_block+0xe0>
    693c:	9101c261 	add	x1, x19, #0x70
    6940:	f9408040 	ldr	x0, [x2, #256]
    6944:	f9004020 	str	x0, [x1, #128]
    6948:	b5fff9c0 	cbnz	x0, 6880 <fwp_block+0x30>
    694c:	f9003c3f 	str	xzr, [x1, #120]
    6950:	17ffffcc 	b	6880 <fwp_block+0x30>
    6954:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    6958:	911a0000 	add	x0, x0, #0x680
    695c:	97fff02d 	bl	2a10 <getenv@plt>
    6960:	5284e202 	mov	w2, #0x2710                	// #10000
    6964:	b4000060 	cbz	x0, 6970 <fwp_block+0x120>
    6968:	39400001 	ldrb	w1, [x0]
    696c:	350000c1 	cbnz	w1, 6984 <fwp_block+0x134>
    6970:	9101c273 	add	x19, x19, #0x70
    6974:	b9034262 	str	w2, [x19, #832]
    6978:	a94153f3 	ldp	x19, x20, [sp, #16]
    697c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6980:	d65f03c0 	ret
    6984:	52800142 	mov	w2, #0xa                   	// #10
    6988:	d2800001 	mov	x1, #0x0                   	// #0
    698c:	97ffef71 	bl	2750 <strtoll@plt>
    6990:	d1000403 	sub	x3, x0, #0x1
    6994:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6998:	eb02007f 	cmp	x3, x2
    699c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69a0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69a4:	17fffff3 	b	6970 <fwp_block+0x120>
    69a8:	d503201f 	nop
    69ac:	d503201f 	nop

00000000000069b0 <fwp_owned_entry161>:
    69b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    69b4:	910003fd 	mov	x29, sp
    69b8:	a90363f7 	stp	x23, x24, [sp, #48]
    69bc:	a9406002 	ldp	x2, x24, [x0]
    69c0:	a90153f3 	stp	x19, x20, [sp, #16]
    69c4:	f9400801 	ldr	x1, [x0, #16]
    69c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    69cc:	ab010055 	adds	x21, x2, x1
    69d0:	54000d06 	b.vs	6b70 <fwp_owned_entry161+0x1c0>
    69d4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    69d8:	91174281 	add	x1, x20, #0x5d0
    69dc:	b953a420 	ldr	w0, [x1, #5028]
    69e0:	34000a80 	cbz	w0, 6b30 <fwp_owned_entry161+0x180>
    69e4:	397e8820 	ldrb	w0, [x1, #4002]
    69e8:	910f0002 	add	x2, x0, #0x3c0
    69ec:	8b000400 	add	x0, x0, x0, lsl #1
    69f0:	d37df000 	lsl	x0, x0, #3
    69f4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    69f8:	2a1703f6 	mov	w22, w23
    69fc:	f8606833 	ldr	x19, [x1, x0]
    6a00:	b4000853 	cbz	x19, 6b08 <fwp_owned_entry161+0x158>
    6a04:	f9400262 	ldr	x2, [x19]
    6a08:	aa2203e2 	mvn	x2, x2
    6a0c:	f8206822 	str	x2, [x1, x0]
    6a10:	f10062df 	cmp	x22, #0x18
    6a14:	540000e9 	b.ls	6a30 <fwp_owned_entry161+0x80>  // b.plast
    6a18:	d10066c2 	sub	x2, x22, #0x19
    6a1c:	91006260 	add	x0, x19, #0x18
    6a20:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6a24:	52800001 	mov	w1, #0x0                   	// #0
    6a28:	91002042 	add	x2, x2, #0x8
    6a2c:	97ffef89 	bl	2850 <memset@plt>
    6a30:	91174281 	add	x1, x20, #0x5d0
    6a34:	f94a1020 	ldr	x0, [x1, #5152]
    6a38:	ab160000 	adds	x0, x0, x22
    6a3c:	540009c2 	b.cs	6b74 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6a40:	f94a1422 	ldr	x2, [x1, #5160]
    6a44:	f90a1020 	str	x0, [x1, #5152]
    6a48:	eb02001f 	cmp	x0, x2
    6a4c:	54000049 	b.ls	6a54 <fwp_owned_entry161+0xa4>  // b.plast
    6a50:	f90a1420 	str	x0, [x1, #5160]
    6a54:	91174280 	add	x0, x20, #0x5d0
    6a58:	1e6302e1 	ucvtf	d1, w23
    6a5c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6a60:	1e612800 	fadd	d0, d0, d1
    6a64:	fd0a1c00 	str	d0, [x0, #5176]
    6a68:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    6a6c:	91174294 	add	x20, x20, #0x5d0
    6a70:	a900d678 	stp	x24, x21, [x19, #8]
    6a74:	fd47f000 	ldr	d0, [x0, #4064]
    6a78:	fd000260 	str	d0, [x19]
    6a7c:	f949da81 	ldr	x1, [x20, #5040]
    6a80:	f949ee80 	ldr	x0, [x20, #5080]
    6a84:	cb010261 	sub	x1, x19, x1
    6a88:	eb00403f 	cmp	x1, x0, lsl #16
    6a8c:	54000322 	b.cs	6af0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6a90:	d350fc20 	lsr	x0, x1, #16
    6a94:	f949fe83 	ldr	x3, [x20, #5112]
    6a98:	8b000800 	add	x0, x0, x0, lsl #2
    6a9c:	d37df002 	lsl	x2, x0, #3
    6aa0:	8b020060 	add	x0, x3, x2
    6aa4:	f9401014 	ldr	x20, [x0, #32]
    6aa8:	b4000254 	cbz	x20, 6af0 <fwp_owned_entry161+0x140>
    6aac:	38626862 	ldrb	w2, [x3, x2]
    6ab0:	7100085f 	cmp	w2, #0x2
    6ab4:	54000480 	b.eq	6b44 <fwp_owned_entry161+0x194>  // b.none
    6ab8:	7100045f 	cmp	w2, #0x1
    6abc:	540001a1 	b.ne	6af0 <fwp_owned_entry161+0x140>  // b.any
    6ac0:	29430002 	ldp	w2, w0, [x0, #24]
    6ac4:	92403c21 	and	x1, x1, #0xffff
    6ac8:	9b027c21 	mul	x1, x1, x2
    6acc:	d360fc21 	lsr	x1, x1, #32
    6ad0:	eb00003f 	cmp	x1, x0
    6ad4:	540000e2 	b.cs	6af0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6ad8:	8b010294 	add	x20, x20, x1
    6adc:	39400280 	ldrb	w0, [x20]
    6ae0:	7103fc1f 	cmp	w0, #0xff
    6ae4:	54000400 	b.eq	6b64 <fwp_owned_entry161+0x1b4>  // b.none
    6ae8:	52800020 	mov	w0, #0x1                   	// #1
    6aec:	39000280 	strb	w0, [x20]
    6af0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6af4:	aa1303e0 	mov	x0, x19
    6af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6afc:	a94363f7 	ldp	x23, x24, [sp, #48]
    6b00:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6b04:	d65f03c0 	ret
    6b08:	8b000021 	add	x1, x1, x0
    6b0c:	f9400433 	ldr	x19, [x1, #8]
    6b10:	b4000113 	cbz	x19, 6b30 <fwp_owned_entry161+0x180>
    6b14:	f9400820 	ldr	x0, [x1, #16]
    6b18:	cb130000 	sub	x0, x0, x19
    6b1c:	eb0002df 	cmp	x22, x0
    6b20:	54000088 	b.hi	6b30 <fwp_owned_entry161+0x180>  // b.pmore
    6b24:	8b160260 	add	x0, x19, x22
    6b28:	f9000420 	str	x0, [x1, #8]
    6b2c:	17ffffb9 	b	6a10 <fwp_owned_entry161+0x60>
    6b30:	52800001 	mov	w1, #0x0                   	// #0
    6b34:	d2800300 	mov	x0, #0x18                  	// #24
    6b38:	97fff8ee 	bl	4ef0 <fwp_heap_alloc>
    6b3c:	aa0003f3 	mov	x19, x0
    6b40:	17ffffca 	b	6a68 <fwp_owned_entry161+0xb8>
    6b44:	72003c3f 	tst	w1, #0xffff
    6b48:	54fffca0 	b.eq	6adc <fwp_owned_entry161+0x12c>  // b.none
    6b4c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6b50:	aa1303e0 	mov	x0, x19
    6b54:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b58:	a94363f7 	ldp	x23, x24, [sp, #48]
    6b5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6b60:	d65f03c0 	ret
    6b64:	aa1403e0 	mov	x0, x20
    6b68:	97fff58a 	bl	4190 <fwp_rc_forget_slot.part.0>
    6b6c:	17ffffdf 	b	6ae8 <fwp_owned_entry161+0x138>
    6b70:	97ffefc4 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6b74:	97fff12f 	bl	3030 <fwp_heap_oom>
    6b78:	d503201f 	nop
    6b7c:	d503201f 	nop

0000000000006b80 <e161>:
    6b80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6b84:	910003fd 	mov	x29, sp
    6b88:	a90363f7 	stp	x23, x24, [sp, #48]
    6b8c:	a9406002 	ldp	x2, x24, [x0]
    6b90:	a90153f3 	stp	x19, x20, [sp, #16]
    6b94:	f9400801 	ldr	x1, [x0, #16]
    6b98:	a9025bf5 	stp	x21, x22, [sp, #32]
    6b9c:	ab010055 	adds	x21, x2, x1
    6ba0:	54000d86 	b.vs	6d50 <e161+0x1d0>
    6ba4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6ba8:	91174281 	add	x1, x20, #0x5d0
    6bac:	b953a420 	ldr	w0, [x1, #5028]
    6bb0:	34000ac0 	cbz	w0, 6d08 <e161+0x188>
    6bb4:	397e8820 	ldrb	w0, [x1, #4002]
    6bb8:	910f0002 	add	x2, x0, #0x3c0
    6bbc:	8b000400 	add	x0, x0, x0, lsl #1
    6bc0:	d37df000 	lsl	x0, x0, #3
    6bc4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6bc8:	2a1703f6 	mov	w22, w23
    6bcc:	f8606833 	ldr	x19, [x1, x0]
    6bd0:	b4000893 	cbz	x19, 6ce0 <e161+0x160>
    6bd4:	f9400262 	ldr	x2, [x19]
    6bd8:	aa2203e2 	mvn	x2, x2
    6bdc:	f8206822 	str	x2, [x1, x0]
    6be0:	f10062df 	cmp	x22, #0x18
    6be4:	540000e9 	b.ls	6c00 <e161+0x80>  // b.plast
    6be8:	d10066c2 	sub	x2, x22, #0x19
    6bec:	91006260 	add	x0, x19, #0x18
    6bf0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6bf4:	52800001 	mov	w1, #0x0                   	// #0
    6bf8:	91002042 	add	x2, x2, #0x8
    6bfc:	97ffef15 	bl	2850 <memset@plt>
    6c00:	91174281 	add	x1, x20, #0x5d0
    6c04:	f94a1020 	ldr	x0, [x1, #5152]
    6c08:	ab160000 	adds	x0, x0, x22
    6c0c:	54000a42 	b.cs	6d54 <e161+0x1d4>  // b.hs, b.nlast
    6c10:	f94a1422 	ldr	x2, [x1, #5160]
    6c14:	f90a1020 	str	x0, [x1, #5152]
    6c18:	eb02001f 	cmp	x0, x2
    6c1c:	54000049 	b.ls	6c24 <e161+0xa4>  // b.plast
    6c20:	f90a1420 	str	x0, [x1, #5160]
    6c24:	91174280 	add	x0, x20, #0x5d0
    6c28:	1e6302e1 	ucvtf	d1, w23
    6c2c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6c30:	1e612800 	fadd	d0, d0, d1
    6c34:	fd0a1c00 	str	d0, [x0, #5176]
    6c38:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    6c3c:	91174294 	add	x20, x20, #0x5d0
    6c40:	a900d678 	stp	x24, x21, [x19, #8]
    6c44:	fd47f000 	ldr	d0, [x0, #4064]
    6c48:	fd000260 	str	d0, [x19]
    6c4c:	f949da81 	ldr	x1, [x20, #5040]
    6c50:	f949ee80 	ldr	x0, [x20, #5080]
    6c54:	cb010261 	sub	x1, x19, x1
    6c58:	eb00403f 	cmp	x1, x0, lsl #16
    6c5c:	54000322 	b.cs	6cc0 <e161+0x140>  // b.hs, b.nlast
    6c60:	d350fc20 	lsr	x0, x1, #16
    6c64:	f949fe83 	ldr	x3, [x20, #5112]
    6c68:	8b000800 	add	x0, x0, x0, lsl #2
    6c6c:	d37df002 	lsl	x2, x0, #3
    6c70:	8b020060 	add	x0, x3, x2
    6c74:	f9401014 	ldr	x20, [x0, #32]
    6c78:	b4000254 	cbz	x20, 6cc0 <e161+0x140>
    6c7c:	38626862 	ldrb	w2, [x3, x2]
    6c80:	7100085f 	cmp	w2, #0x2
    6c84:	540004c0 	b.eq	6d1c <e161+0x19c>  // b.none
    6c88:	7100045f 	cmp	w2, #0x1
    6c8c:	540001a1 	b.ne	6cc0 <e161+0x140>  // b.any
    6c90:	29430002 	ldp	w2, w0, [x0, #24]
    6c94:	92403c21 	and	x1, x1, #0xffff
    6c98:	9b027c21 	mul	x1, x1, x2
    6c9c:	d360fc21 	lsr	x1, x1, #32
    6ca0:	eb00003f 	cmp	x1, x0
    6ca4:	540000e2 	b.cs	6cc0 <e161+0x140>  // b.hs, b.nlast
    6ca8:	8b010294 	add	x20, x20, x1
    6cac:	39400280 	ldrb	w0, [x20]
    6cb0:	7103fc1f 	cmp	w0, #0xff
    6cb4:	54000480 	b.eq	6d44 <e161+0x1c4>  // b.none
    6cb8:	52800020 	mov	w0, #0x1                   	// #1
    6cbc:	39000280 	strb	w0, [x20]
    6cc0:	aa1303e0 	mov	x0, x19
    6cc4:	97fffbc8 	bl	5be4 <fwp_rc_share>
    6cc8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ccc:	aa1303e0 	mov	x0, x19
    6cd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    6cd8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6cdc:	d65f03c0 	ret
    6ce0:	8b000021 	add	x1, x1, x0
    6ce4:	f9400433 	ldr	x19, [x1, #8]
    6ce8:	b4000113 	cbz	x19, 6d08 <e161+0x188>
    6cec:	f9400820 	ldr	x0, [x1, #16]
    6cf0:	cb130000 	sub	x0, x0, x19
    6cf4:	eb0002df 	cmp	x22, x0
    6cf8:	54000088 	b.hi	6d08 <e161+0x188>  // b.pmore
    6cfc:	8b160260 	add	x0, x19, x22
    6d00:	f9000420 	str	x0, [x1, #8]
    6d04:	17ffffb7 	b	6be0 <e161+0x60>
    6d08:	52800001 	mov	w1, #0x0                   	// #0
    6d0c:	d2800300 	mov	x0, #0x18                  	// #24
    6d10:	97fff878 	bl	4ef0 <fwp_heap_alloc>
    6d14:	aa0003f3 	mov	x19, x0
    6d18:	17ffffc8 	b	6c38 <e161+0xb8>
    6d1c:	72003c3f 	tst	w1, #0xffff
    6d20:	54fffc60 	b.eq	6cac <e161+0x12c>  // b.none
    6d24:	aa1303e0 	mov	x0, x19
    6d28:	97fffbaf 	bl	5be4 <fwp_rc_share>
    6d2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6d30:	aa1303e0 	mov	x0, x19
    6d34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d38:	a94363f7 	ldp	x23, x24, [sp, #48]
    6d3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6d40:	d65f03c0 	ret
    6d44:	aa1403e0 	mov	x0, x20
    6d48:	97fff512 	bl	4190 <fwp_rc_forget_slot.part.0>
    6d4c:	17ffffdb 	b	6cb8 <e161+0x138>
    6d50:	97ffef4c 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6d54:	97fff0b7 	bl	3030 <fwp_heap_oom>
    6d58:	d503201f 	nop
    6d5c:	d503201f 	nop

0000000000006d60 <fwp_drop4>:
    6d60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6d64:	910003fd 	mov	x29, sp
    6d68:	a90153f3 	stp	x19, x20, [sp, #16]
    6d6c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6d70:	f90013f5 	str	x21, [sp, #32]
    6d74:	91174275 	add	x21, x19, #0x5d0
    6d78:	f949daa1 	ldr	x1, [x21, #5040]
    6d7c:	f949eea2 	ldr	x2, [x21, #5080]
    6d80:	cb010001 	sub	x1, x0, x1
    6d84:	eb02403f 	cmp	x1, x2, lsl #16
    6d88:	54000382 	b.cs	6df8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d8c:	d350fc22 	lsr	x2, x1, #16
    6d90:	f949fea3 	ldr	x3, [x21, #5112]
    6d94:	8b020842 	add	x2, x2, x2, lsl #2
    6d98:	d37df042 	lsl	x2, x2, #3
    6d9c:	8b020064 	add	x4, x3, x2
    6da0:	f9401094 	ldr	x20, [x4, #32]
    6da4:	b40002b4 	cbz	x20, 6df8 <fwp_drop4+0x98>
    6da8:	38626862 	ldrb	w2, [x3, x2]
    6dac:	7100085f 	cmp	w2, #0x2
    6db0:	540007a0 	b.eq	6ea4 <fwp_drop4+0x144>  // b.none
    6db4:	7100045f 	cmp	w2, #0x1
    6db8:	54000201 	b.ne	6df8 <fwp_drop4+0x98>  // b.any
    6dbc:	29430885 	ldp	w5, w2, [x4, #24]
    6dc0:	92403c21 	and	x1, x1, #0xffff
    6dc4:	9b057c21 	mul	x1, x1, x5
    6dc8:	d360fc21 	lsr	x1, x1, #32
    6dcc:	eb02003f 	cmp	x1, x2
    6dd0:	54000142 	b.cs	6df8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6dd4:	8b010294 	add	x20, x20, x1
    6dd8:	39400281 	ldrb	w1, [x20]
    6ddc:	340000e1 	cbz	w1, 6df8 <fwp_drop4+0x98>
    6de0:	7100043f 	cmp	w1, #0x1
    6de4:	54000120 	b.eq	6e08 <fwp_drop4+0xa8>  // b.none
    6de8:	7103fc3f 	cmp	w1, #0xff
    6dec:	540007c0 	b.eq	6ee4 <fwp_drop4+0x184>  // b.none
    6df0:	51000421 	sub	w1, w1, #0x1
    6df4:	39000281 	strb	w1, [x20]
    6df8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6dfc:	f94013f5 	ldr	x21, [sp, #32]
    6e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e04:	d65f03c0 	ret
    6e08:	f9400001 	ldr	x1, [x0]
    6e0c:	b7f80581 	tbnz	x1, #63, 6ebc <fwp_drop4+0x15c>
    6e10:	91174273 	add	x19, x19, #0x5d0
    6e14:	f949da61 	ldr	x1, [x19, #5040]
    6e18:	f949ee62 	ldr	x2, [x19, #5080]
    6e1c:	cb010001 	sub	x1, x0, x1
    6e20:	eb02403f 	cmp	x1, x2, lsl #16
    6e24:	54fffea2 	b.cs	6df8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e28:	d350fc22 	lsr	x2, x1, #16
    6e2c:	8b020842 	add	x2, x2, x2, lsl #2
    6e30:	d37df042 	lsl	x2, x2, #3
    6e34:	8b020065 	add	x5, x3, x2
    6e38:	f94010a4 	ldr	x4, [x5, #32]
    6e3c:	b4fffde4 	cbz	x4, 6df8 <fwp_drop4+0x98>
    6e40:	38626862 	ldrb	w2, [x3, x2]
    6e44:	7100085f 	cmp	w2, #0x2
    6e48:	54000220 	b.eq	6e8c <fwp_drop4+0x12c>  // b.none
    6e4c:	7100045f 	cmp	w2, #0x1
    6e50:	54fffd41 	b.ne	6df8 <fwp_drop4+0x98>  // b.any
    6e54:	294308a3 	ldp	w3, w2, [x5, #24]
    6e58:	92403c21 	and	x1, x1, #0xffff
    6e5c:	9b037c21 	mul	x1, x1, x3
    6e60:	d360fc21 	lsr	x1, x1, #32
    6e64:	eb02003f 	cmp	x1, x2
    6e68:	54fffc82 	b.cs	6df8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e6c:	8b010084 	add	x4, x4, x1
    6e70:	39400081 	ldrb	w1, [x4]
    6e74:	7100043f 	cmp	w1, #0x1
    6e78:	54fffc01 	b.ne	6df8 <fwp_drop4+0x98>  // b.any
    6e7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e80:	f94013f5 	ldr	x21, [sp, #32]
    6e84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e88:	17fff55e 	b	4400 <fwp_mem_free>
    6e8c:	72003c3f 	tst	w1, #0xffff
    6e90:	54ffff00 	b.eq	6e70 <fwp_drop4+0x110>  // b.none
    6e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e98:	f94013f5 	ldr	x21, [sp, #32]
    6e9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ea0:	d65f03c0 	ret
    6ea4:	72003c3f 	tst	w1, #0xffff
    6ea8:	54fff980 	b.eq	6dd8 <fwp_drop4+0x78>  // b.none
    6eac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6eb0:	f94013f5 	ldr	x21, [sp, #32]
    6eb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6eb8:	d65f03c0 	ret
    6ebc:	f9400414 	ldr	x20, [x0, #8]
    6ec0:	97fffb6d 	bl	5c74 <fwp_rc_free_arr>
    6ec4:	91174260 	add	x0, x19, #0x5d0
    6ec8:	f949d801 	ldr	x1, [x0, #5040]
    6ecc:	f949ec00 	ldr	x0, [x0, #5080]
    6ed0:	cb010281 	sub	x1, x20, x1
    6ed4:	eb00403f 	cmp	x1, x0, lsl #16
    6ed8:	54fff902 	b.cs	6df8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6edc:	aa1403e0 	mov	x0, x20
    6ee0:	17ffffab 	b	6d8c <fwp_drop4+0x2c>
    6ee4:	ca544680 	eor	x0, x20, x20, lsr #17
    6ee8:	91174273 	add	x19, x19, #0x5d0
    6eec:	ca402400 	eor	x0, x0, x0, lsr #9
    6ef0:	92401c00 	and	x0, x0, #0xff
    6ef4:	910a2402 	add	x2, x0, #0x289
    6ef8:	8b000e60 	add	x0, x19, x0, lsl #3
    6efc:	8b020e62 	add	x2, x19, x2, lsl #3
    6f00:	f94a2400 	ldr	x0, [x0, #5192]
    6f04:	b50000a0 	cbnz	x0, 6f18 <fwp_drop4+0x1b8>
    6f08:	14000013 	b	6f54 <fwp_drop4+0x1f4>
    6f0c:	91004002 	add	x2, x0, #0x10
    6f10:	f9400800 	ldr	x0, [x0, #16]
    6f14:	b4000200 	cbz	x0, 6f54 <fwp_drop4+0x1f4>
    6f18:	f9400001 	ldr	x1, [x0]
    6f1c:	eb14003f 	cmp	x1, x20
    6f20:	54ffff61 	b.ne	6f0c <fwp_drop4+0x1ac>  // b.any
    6f24:	f9400041 	ldr	x1, [x2]
    6f28:	f9400420 	ldr	x0, [x1, #8]
    6f2c:	d1000400 	sub	x0, x0, #0x1
    6f30:	f9000420 	str	x0, [x1, #8]
    6f34:	f103f81f 	cmp	x0, #0xfe
    6f38:	54fff601 	b.ne	6df8 <fwp_drop4+0x98>  // b.any
    6f3c:	39400280 	ldrb	w0, [x20]
    6f40:	7103fc1f 	cmp	w0, #0xff
    6f44:	540000e0 	b.eq	6f60 <fwp_drop4+0x200>  // b.none
    6f48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f4c:	39000280 	strb	w0, [x20]
    6f50:	17ffffaa 	b	6df8 <fwp_drop4+0x98>
    6f54:	b0000020 	adrp	x0, b000 <__modti3+0x1b0>
    6f58:	910fa000 	add	x0, x0, #0x3e8
    6f5c:	97fff46d 	bl	4110 <fwp_trap>
    6f60:	aa1403e0 	mov	x0, x20
    6f64:	97fff48b 	bl	4190 <fwp_rc_forget_slot.part.0>
    6f68:	17fffff8 	b	6f48 <fwp_drop4+0x1e8>
    6f6c:	d503201f 	nop

0000000000006f70 <fwp_caps161>:
    6f70:	34000041 	cbz	w1, 6f78 <fwp_caps161+0x8>
    6f74:	d65f03c0 	ret
    6f78:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6f7c:	91174063 	add	x3, x3, #0x5d0
    6f80:	f949d861 	ldr	x1, [x3, #5040]
    6f84:	f949ec62 	ldr	x2, [x3, #5080]
    6f88:	cb010001 	sub	x1, x0, x1
    6f8c:	eb02403f 	cmp	x1, x2, lsl #16
    6f90:	54ffff22 	b.cs	6f74 <fwp_caps161+0x4>  // b.hs, b.nlast
    6f94:	d350fc22 	lsr	x2, x1, #16
    6f98:	f949fc65 	ldr	x5, [x3, #5112]
    6f9c:	8b020842 	add	x2, x2, x2, lsl #2
    6fa0:	d37df042 	lsl	x2, x2, #3
    6fa4:	8b0200a4 	add	x4, x5, x2
    6fa8:	f9401083 	ldr	x3, [x4, #32]
    6fac:	b4fffe43 	cbz	x3, 6f74 <fwp_caps161+0x4>
    6fb0:	386268a2 	ldrb	w2, [x5, x2]
    6fb4:	7100085f 	cmp	w2, #0x2
    6fb8:	540001c0 	b.eq	6ff0 <fwp_caps161+0x80>  // b.none
    6fbc:	7100045f 	cmp	w2, #0x1
    6fc0:	54fffda1 	b.ne	6f74 <fwp_caps161+0x4>  // b.any
    6fc4:	29430885 	ldp	w5, w2, [x4, #24]
    6fc8:	92403c21 	and	x1, x1, #0xffff
    6fcc:	9b057c21 	mul	x1, x1, x5
    6fd0:	d360fc21 	lsr	x1, x1, #32
    6fd4:	eb02003f 	cmp	x1, x2
    6fd8:	54fffce2 	b.cs	6f74 <fwp_caps161+0x4>  // b.hs, b.nlast
    6fdc:	8b010063 	add	x3, x3, x1
    6fe0:	39400061 	ldrb	w1, [x3]
    6fe4:	7100043f 	cmp	w1, #0x1
    6fe8:	54fffc61 	b.ne	6f74 <fwp_caps161+0x4>  // b.any
    6fec:	17fff505 	b	4400 <fwp_mem_free>
    6ff0:	72003c3f 	tst	w1, #0xffff
    6ff4:	54ffff60 	b.eq	6fe0 <fwp_caps161+0x70>  // b.none
    6ff8:	d65f03c0 	ret
    6ffc:	d503201f 	nop

0000000000007000 <f12>:
    7000:	d10483ff 	sub	sp, sp, #0x120
    7004:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7008:	f947f442 	ldr	x2, [x2, #4072]
    700c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    7010:	9102c3fd 	add	x29, sp, #0xb0
    7014:	a90d5bf5 	stp	x21, x22, [sp, #208]
    7018:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    701c:	911742a3 	add	x3, x21, #0x5d0
    7020:	a90c53f3 	stp	x19, x20, [sp, #192]
    7024:	b00000d4 	adrp	x20, 20000 <__data_start>
    7028:	9101c284 	add	x4, x20, #0x70
    702c:	f949d861 	ldr	x1, [x3, #5040]
    7030:	a90e63f7 	stp	x23, x24, [sp, #224]
    7034:	b00000d8 	adrp	x24, 20000 <__data_start>
    7038:	f949ec65 	ldr	x5, [x3, #5080]
    703c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    7040:	91004318 	add	x24, x24, #0x10
    7044:	a91073fb 	stp	x27, x28, [sp, #256]
    7048:	9100e318 	add	x24, x24, #0x38
    704c:	910103f7 	add	x23, sp, #0x40
    7050:	f9418886 	ldr	x6, [x4, #784]
    7054:	fd008be8 	str	d8, [sp, #272]
    7058:	f9400047 	ldr	x7, [x2]
    705c:	f90057e7 	str	x7, [sp, #168]
    7060:	d2800007 	mov	x7, #0x0                   	// #0
    7064:	9100e3f6 	add	x22, sp, #0x38
    7068:	f0fffff9 	adrp	x25, 6000 <fwp_drop1+0xe0>
    706c:	12800007 	mov	w7, #0xffffffff            	// #-1
    7070:	9110c322 	add	x2, x25, #0x430
    7074:	cb010301 	sub	x1, x24, x1
    7078:	b9003be7 	str	w7, [sp, #56]
    707c:	aa0003f3 	mov	x19, x0
    7080:	a9040be6 	stp	x6, x2, [sp, #64]
    7084:	f9002bf6 	str	x22, [sp, #80]
    7088:	f9018897 	str	x23, [x4, #784]
    708c:	eb05403f 	cmp	x1, x5, lsl #16
    7090:	54000342 	b.cs	70f8 <f12+0xf8>  // b.hs, b.nlast
    7094:	d350fc20 	lsr	x0, x1, #16
    7098:	f949fc64 	ldr	x4, [x3, #5112]
    709c:	8b000800 	add	x0, x0, x0, lsl #2
    70a0:	d37df002 	lsl	x2, x0, #3
    70a4:	8b020083 	add	x3, x4, x2
    70a8:	f9401060 	ldr	x0, [x3, #32]
    70ac:	b4000260 	cbz	x0, 70f8 <f12+0xf8>
    70b0:	38626882 	ldrb	w2, [x4, x2]
    70b4:	7100085f 	cmp	w2, #0x2
    70b8:	54000b20 	b.eq	721c <f12+0x21c>  // b.none
    70bc:	7100045f 	cmp	w2, #0x1
    70c0:	540001c1 	b.ne	70f8 <f12+0xf8>  // b.any
    70c4:	29430864 	ldp	w4, w2, [x3, #24]
    70c8:	92403c21 	and	x1, x1, #0xffff
    70cc:	9b047c21 	mul	x1, x1, x4
    70d0:	d360fc21 	lsr	x1, x1, #32
    70d4:	eb02003f 	cmp	x1, x2
    70d8:	54000102 	b.cs	70f8 <f12+0xf8>  // b.hs, b.nlast
    70dc:	8b010000 	add	x0, x0, x1
    70e0:	39400001 	ldrb	w1, [x0]
    70e4:	340000a1 	cbz	w1, 70f8 <f12+0xf8>
    70e8:	7103f43f 	cmp	w1, #0xfd
    70ec:	54002848 	b.hi	75f4 <f12+0x5f4>  // b.pmore
    70f0:	11000421 	add	w1, w1, #0x1
    70f4:	39000001 	strb	w1, [x0]
    70f8:	aa1803e0 	mov	x0, x24
    70fc:	97fffbe5 	bl	6090 <fwp_closure_drop>
    7100:	b40001f3 	cbz	x19, 713c <f12+0x13c>
    7104:	aa1303e0 	mov	x0, x19
    7108:	d2800018 	mov	x24, #0x0                   	// #0
    710c:	d503201f 	nop
    7110:	f9400800 	ldr	x0, [x0, #16]
    7114:	91000718 	add	x24, x24, #0x1
    7118:	b5ffffc0 	cbnz	x0, 7110 <f12+0x110>
    711c:	52800000 	mov	w0, #0x0                   	// #0
    7120:	97fff134 	bl	35f0 <descent_phase_step>
    7124:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7128:	eb00031f 	cmp	x24, x0
    712c:	540000e9 	b.ls	7148 <f12+0x148>  // b.plast
    7130:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7134:	911a4000 	add	x0, x0, #0x690
    7138:	97fff3f6 	bl	4110 <fwp_trap>
    713c:	d2800018 	mov	x24, #0x0                   	// #0
    7140:	52800000 	mov	w0, #0x0                   	// #0
    7144:	97fff12b 	bl	35f0 <descent_phase_step>
    7148:	9101c29a 	add	x26, x20, #0x70
    714c:	b9434740 	ldr	w0, [x26, #836]
    7150:	34001280 	cbz	w0, 73a0 <f12+0x3a0>
    7154:	9101c280 	add	x0, x20, #0x70
    7158:	f940681b 	ldr	x27, [x0, #208]
    715c:	f940741a 	ldr	x26, [x0, #232]
    7160:	eb1b035f 	cmp	x26, x27
    7164:	5400062a 	b.ge	7228 <f12+0x228>  // b.tcont
    7168:	f9403a81 	ldr	x1, [x20, #112]
    716c:	8b1a0740 	add	x0, x26, x26, lsl #1
    7170:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7174:	8b000b40 	add	x0, x26, x0, lsl #2
    7178:	8b000c20 	add	x0, x1, x0, lsl #3
    717c:	d503201f 	nop
    7180:	b9400401 	ldr	w1, [x0, #4]
    7184:	35000081 	cbnz	w1, 7194 <f12+0x194>
    7188:	b9400001 	ldr	w1, [x0]
    718c:	6b02003f 	cmp	w1, w2
    7190:	540004c9 	b.ls	7228 <f12+0x228>  // b.plast
    7194:	9100075a 	add	x26, x26, #0x1
    7198:	9101a000 	add	x0, x0, #0x68
    719c:	eb1b035f 	cmp	x26, x27
    71a0:	54ffff01 	b.ne	7180 <f12+0x180>  // b.any
    71a4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    71a8:	eb00037f 	cmp	x27, x0
    71ac:	54001dac 	b.gt	7560 <f12+0x560>
    71b0:	9101c280 	add	x0, x20, #0x70
    71b4:	f9403a83 	ldr	x3, [x20, #112]
    71b8:	f9407000 	ldr	x0, [x0, #224]
    71bc:	eb1b001f 	cmp	x0, x27
    71c0:	54000161 	b.ne	71ec <f12+0x1ec>  // b.any
    71c4:	b5001dbb 	cbnz	x27, 7578 <f12+0x578>
    71c8:	d2800d01 	mov	x1, #0x68                  	// #104
    71cc:	d280003c 	mov	x28, #0x1                   	// #1
    71d0:	aa0303e0 	mov	x0, x3
    71d4:	97ffeda7 	bl	2870 <realloc@plt>
    71d8:	aa0003e3 	mov	x3, x0
    71dc:	b4004a00 	cbz	x0, 7b1c <f12+0xb1c>
    71e0:	9101c280 	add	x0, x20, #0x70
    71e4:	f9003a83 	str	x3, [x20, #112]
    71e8:	f900701c 	str	x28, [x0, #224]
    71ec:	8b1b0761 	add	x1, x27, x27, lsl #1
    71f0:	9101c280 	add	x0, x20, #0x70
    71f4:	4f000400 	movi	v0.4s, #0x0
    71f8:	91000762 	add	x2, x27, #0x1
    71fc:	8b010b61 	add	x1, x27, x1, lsl #2
    7200:	f9006802 	str	x2, [x0, #208]
    7204:	8b010c61 	add	x1, x3, x1, lsl #3
    7208:	ad000020 	stp	q0, q0, [x1]
    720c:	ad010020 	stp	q0, q0, [x1, #32]
    7210:	ad020020 	stp	q0, q0, [x1, #64]
    7214:	f900303f 	str	xzr, [x1, #96]
    7218:	14000007 	b	7234 <f12+0x234>
    721c:	72003c3f 	tst	w1, #0xffff
    7220:	54fff6c1 	b.ne	70f8 <f12+0xf8>  // b.any
    7224:	17ffffaf 	b	70e0 <f12+0xe0>
    7228:	eb1b035f 	cmp	x26, x27
    722c:	54fffbc0 	b.eq	71a4 <f12+0x1a4>  // b.none
    7230:	f9403a83 	ldr	x3, [x20, #112]
    7234:	8b1a075b 	add	x27, x26, x26, lsl #1
    7238:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    723c:	910f0000 	add	x0, x0, #0x3c0
    7240:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7244:	f90003e3 	str	x3, [sp]
    7248:	8b1b0c7b 	add	x27, x3, x27, lsl #3
    724c:	f900337f 	str	xzr, [x27, #96]
    7250:	97ffedf0 	bl	2a10 <getenv@plt>
    7254:	f94003e3 	ldr	x3, [sp]
    7258:	b4000800 	cbz	x0, 7358 <f12+0x358>
    725c:	39400001 	ldrb	w1, [x0]
    7260:	7100c03f 	cmp	w1, #0x30
    7264:	540007a1 	b.ne	7358 <f12+0x358>  // b.any
    7268:	39400400 	ldrb	w0, [x0, #1]
    726c:	35000760 	cbnz	w0, 7358 <f12+0x358>
    7270:	9101c282 	add	x2, x20, #0x70
    7274:	2f000400 	mvni	v0.2s, #0x0
    7278:	b9400360 	ldr	w0, [x27]
    727c:	52800025 	mov	w5, #0x1                   	// #1
    7280:	91000744 	add	x4, x26, #0x1
    7284:	a900e378 	stp	x24, x24, [x27, #8]
    7288:	0b05001c 	add	w28, w0, w5
    728c:	f9418841 	ldr	x1, [x2, #784]
    7290:	2900177c 	stp	w28, w5, [x27]
    7294:	f9002b7f 	str	xzr, [x27, #80]
    7298:	f9007444 	str	x4, [x2, #232]
    729c:	fd002f60 	str	d0, [x27, #88]
    72a0:	b4001661 	cbz	x1, 756c <f12+0x56c>
    72a4:	9110c339 	add	x25, x25, #0x430
    72a8:	14000003 	b	72b4 <f12+0x2b4>
    72ac:	f9400021 	ldr	x1, [x1]
    72b0:	b40015e1 	cbz	x1, 756c <f12+0x56c>
    72b4:	f9400422 	ldr	x2, [x1, #8]
    72b8:	eb19005f 	cmp	x2, x25
    72bc:	54ffff81 	b.ne	72ac <f12+0x2ac>  // b.any
    72c0:	f9400820 	ldr	x0, [x1, #16]
    72c4:	2a1a03e2 	mov	w2, w26
    72c8:	b9400001 	ldr	w1, [x0]
    72cc:	f9002b60 	str	x0, [x27, #80]
    72d0:	b9005f61 	str	w1, [x27, #92]
    72d4:	37f80081 	tbnz	w1, #31, 72e4 <f12+0x2e4>
    72d8:	52800d05 	mov	w5, #0x68                  	// #104
    72dc:	9b250c21 	smaddl	x1, w1, w5, x3
    72e0:	b900583a 	str	w26, [x1, #88]
    72e4:	b9000002 	str	w2, [x0]
    72e8:	52800020 	mov	w0, #0x1                   	// #1
    72ec:	f90003e4 	str	x4, [sp]
    72f0:	97fff0c0 	bl	35f0 <descent_phase_step>
    72f4:	f94003e4 	ldr	x4, [sp]
    72f8:	aa1303e0 	mov	x0, x19
    72fc:	d2800002 	mov	x2, #0x0                   	// #0
    7300:	b40005f3 	cbz	x19, 73bc <f12+0x3bc>
    7304:	d503201f 	nop
    7308:	f9400800 	ldr	x0, [x0, #16]
    730c:	91000442 	add	x2, x2, #0x1
    7310:	b5ffffc0 	cbnz	x0, 7308 <f12+0x308>
    7314:	aa1303e1 	mov	x1, x19
    7318:	f9400821 	ldr	x1, [x1, #16]
    731c:	91000400 	add	x0, x0, #0x1
    7320:	b5ffffc1 	cbnz	x1, 7318 <f12+0x318>
    7324:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7328:	eb01001f 	cmp	x0, x1
    732c:	54000108 	b.hi	734c <f12+0x34c>  // b.pmore
    7330:	f100005f 	cmp	x2, #0x0
    7334:	5400044d 	b.le	73bc <f12+0x3bc>
    7338:	eb00005f 	cmp	x2, x0
    733c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7340:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7344:	eb01033f 	cmp	x25, x1
    7348:	54001289 	b.ls	7598 <f12+0x598>  // b.plast
    734c:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7350:	911c4000 	add	x0, x0, #0x710
    7354:	97fff36f 	bl	4110 <fwp_trap>
    7358:	9101c280 	add	x0, x20, #0x70
    735c:	f9406001 	ldr	x1, [x0, #192]
    7360:	b4fff881 	cbz	x1, 7270 <f12+0x270>
    7364:	3cc88002 	ldur	q2, [x0, #136]
    7368:	91022001 	add	x1, x0, #0x88
    736c:	3cc98001 	ldur	q1, [x0, #152]
    7370:	f900601f 	str	xzr, [x0, #192]
    7374:	4f000400 	movi	v0.4s, #0x0
    7378:	ad010762 	stp	q2, q1, [x27, #32]
    737c:	a94a8002 	ldp	x2, x0, [x0, #168]
    7380:	f9000f60 	str	x0, [x27, #24]
    7384:	f9401820 	ldr	x0, [x1, #48]
    7388:	f9002362 	str	x2, [x27, #64]
    738c:	f9002760 	str	x0, [x27, #72]
    7390:	ad000020 	stp	q0, q0, [x1]
    7394:	3d800820 	str	q0, [x1, #32]
    7398:	f900183f 	str	xzr, [x1, #48]
    739c:	17ffffb5 	b	7270 <f12+0x270>
    73a0:	f0ffffe0 	adrp	x0, 6000 <fwp_drop1+0xe0>
    73a4:	910cc000 	add	x0, x0, #0x330
    73a8:	94000f86 	bl	b1c0 <atexit>
    73ac:	35003b80 	cbnz	w0, 7b1c <f12+0xb1c>
    73b0:	52800020 	mov	w0, #0x1                   	// #1
    73b4:	b9034740 	str	w0, [x26, #836]
    73b8:	17ffff67 	b	7154 <f12+0x154>
    73bc:	d3707f80 	ubfiz	x0, x28, #16, #32
    73c0:	52800041 	mov	w1, #0x2                   	// #2
    73c4:	aa040018 	orr	x24, x0, x4
    73c8:	d2800100 	mov	x0, #0x8                   	// #8
    73cc:	97fff6c9 	bl	4ef0 <fwp_heap_alloc>
    73d0:	aa0003fa 	mov	x26, x0
    73d4:	911742a0 	add	x0, x21, #0x5d0
    73d8:	f900035f 	str	xzr, [x26]
    73dc:	f949d801 	ldr	x1, [x0, #5040]
    73e0:	f949ec00 	ldr	x0, [x0, #5080]
    73e4:	cb010341 	sub	x1, x26, x1
    73e8:	eb00403f 	cmp	x1, x0, lsl #16
    73ec:	54000f82 	b.cs	75dc <f12+0x5dc>  // b.hs, b.nlast
    73f0:	d2800019 	mov	x25, #0x0                   	// #0
    73f4:	911742a2 	add	x2, x21, #0x5d0
    73f8:	d350fc20 	lsr	x0, x1, #16
    73fc:	8b000800 	add	x0, x0, x0, lsl #2
    7400:	f949fc43 	ldr	x3, [x2, #5112]
    7404:	d37df002 	lsl	x2, x0, #3
    7408:	8b020060 	add	x0, x3, x2
    740c:	f940101b 	ldr	x27, [x0, #32]
    7410:	b400025b 	cbz	x27, 7458 <f12+0x458>
    7414:	38626862 	ldrb	w2, [x3, x2]
    7418:	7100085f 	cmp	w2, #0x2
    741c:	54000e60 	b.eq	75e8 <f12+0x5e8>  // b.none
    7420:	7100045f 	cmp	w2, #0x1
    7424:	540001a1 	b.ne	7458 <f12+0x458>  // b.any
    7428:	29430002 	ldp	w2, w0, [x0, #24]
    742c:	92403c21 	and	x1, x1, #0xffff
    7430:	9b027c21 	mul	x1, x1, x2
    7434:	d360fc21 	lsr	x1, x1, #32
    7438:	eb00003f 	cmp	x1, x0
    743c:	540000e2 	b.cs	7458 <f12+0x458>  // b.hs, b.nlast
    7440:	8b01037b 	add	x27, x27, x1
    7444:	39400360 	ldrb	w0, [x27]
    7448:	7103fc1f 	cmp	w0, #0xff
    744c:	540034c0 	b.eq	7ae4 <f12+0xae4>  // b.none
    7450:	52800020 	mov	w0, #0x1                   	// #1
    7454:	39000360 	strb	w0, [x27]
    7458:	b4000239 	cbz	x25, 749c <f12+0x49c>
    745c:	d3607f04 	lsl	x4, x24, #32
    7460:	aa1303e0 	mov	x0, x19
    7464:	f9400665 	ldr	x5, [x19, #8]
    7468:	aa0403e3 	mov	x3, x4
    746c:	91002342 	add	x2, x26, #0x8
    7470:	d2800001 	mov	x1, #0x0                   	// #0
    7474:	14000005 	b	7488 <f12+0x488>
    7478:	f9400405 	ldr	x5, [x0, #8]
    747c:	ab040023 	adds	x3, x1, x4
    7480:	91004042 	add	x2, x2, #0x10
    7484:	54006926 	b.vs	81a8 <f12+0x11a8>
    7488:	a9000c45 	stp	x5, x3, [x2]
    748c:	91000421 	add	x1, x1, #0x1
    7490:	f9400800 	ldr	x0, [x0, #16]
    7494:	eb01033f 	cmp	x25, x1
    7498:	54ffff08 	b.hi	7478 <f12+0x478>  // b.pmore
    749c:	f9400340 	ldr	x0, [x26]
    74a0:	f100041f 	cmp	x0, #0x1
    74a4:	540009c9 	b.ls	75dc <f12+0x5dc>  // b.plast
    74a8:	d341fc00 	lsr	x0, x0, #1
    74ac:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    74b0:	d100041c 	sub	x28, x0, #0x1
    74b4:	eb01039f 	cmp	x28, x1
    74b8:	54fff4a8 	b.hi	734c <f12+0x34c>  // b.pmore
    74bc:	b400091c 	cbz	x28, 75dc <f12+0x5dc>
    74c0:	d1002341 	sub	x1, x26, #0x8
    74c4:	91002359 	add	x25, x26, #0x8
    74c8:	8b00103b 	add	x27, x1, x0, lsl #4
    74cc:	d503201f 	nop
    74d0:	f9400720 	ldr	x0, [x25, #8]
    74d4:	f9400f21 	ldr	x1, [x25, #24]
    74d8:	fd400320 	ldr	d0, [x25]
    74dc:	fd400b21 	ldr	d1, [x25, #16]
    74e0:	97fff840 	bl	55e0 <w107>
    74e4:	a9000720 	stp	x0, x1, [x25]
    74e8:	91004339 	add	x25, x25, #0x10
    74ec:	eb1b033f 	cmp	x25, x27
    74f0:	54ffff01 	b.ne	74d0 <f12+0x4d0>  // b.any
    74f4:	aa1a03fb 	mov	x27, x26
    74f8:	d37ffb99 	lsl	x25, x28, #1
    74fc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7500:	d280001c 	mov	x28, #0x0                   	// #0
    7504:	f8010779 	str	x25, [x27], #16
    7508:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    750c:	aa0303e0 	mov	x0, x3
    7510:	91000b9c 	add	x28, x28, #0x2
    7514:	97fff7db 	bl	5480 <f128.constprop.0>
    7518:	aa0003e3 	mov	x3, x0
    751c:	eb19039f 	cmp	x28, x25
    7520:	54ffff43 	b.cc	7508 <f12+0x508>  // b.lo, b.ul, b.last
    7524:	aa1a03e0 	mov	x0, x26
    7528:	f90003e3 	str	x3, [sp]
    752c:	97fffe0d 	bl	6d60 <fwp_drop4>
    7530:	93407f18 	sxtw	x24, w24
    7534:	52800040 	mov	w0, #0x2                   	// #2
    7538:	97fff02e 	bl	35f0 <descent_phase_step>
    753c:	aa1803e0 	mov	x0, x24
    7540:	97fff4f8 	bl	4920 <fwp_tape_of>
    7544:	f940301b 	ldr	x27, [x0, #96]
    7548:	aa0003e5 	mov	x5, x0
    754c:	f94003e3 	ldr	x3, [sp]
    7550:	b400057b 	cbz	x27, 75fc <f12+0x5fc>
    7554:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7558:	91180000 	add	x0, x0, #0x600
    755c:	97fff2ed 	bl	4110 <fwp_trap>
    7560:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7564:	911ac000 	add	x0, x0, #0x6b0
    7568:	97fff2ea 	bl	4110 <fwp_trap>
    756c:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7570:	911b8000 	add	x0, x0, #0x6e0
    7574:	97fff2e7 	bl	4110 <fwp_trap>
    7578:	d37ffb7c 	lsl	x28, x27, #1
    757c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7580:	eb00039f 	cmp	x28, x0
    7584:	9a80d39c 	csel	x28, x28, x0, le
    7588:	8b1c0781 	add	x1, x28, x28, lsl #1
    758c:	8b010b81 	add	x1, x28, x1, lsl #2
    7590:	d37df021 	lsl	x1, x1, #3
    7594:	17ffff0f 	b	71d0 <f12+0x1d0>
    7598:	d37ffb3b 	lsl	x27, x25, #1
    759c:	d3707f9c 	ubfiz	x28, x28, #16, #32
    75a0:	91000760 	add	x0, x27, #0x1
    75a4:	52800041 	mov	w1, #0x2                   	// #2
    75a8:	aa040398 	orr	x24, x28, x4
    75ac:	d37df000 	lsl	x0, x0, #3
    75b0:	97fff650 	bl	4ef0 <fwp_heap_alloc>
    75b4:	aa0003fa 	mov	x26, x0
    75b8:	911742a1 	add	x1, x21, #0x5d0
    75bc:	aa0103e0 	mov	x0, x1
    75c0:	f900035b 	str	x27, [x26]
    75c4:	f949d821 	ldr	x1, [x1, #5040]
    75c8:	f949ec00 	ldr	x0, [x0, #5080]
    75cc:	cb010341 	sub	x1, x26, x1
    75d0:	eb00403f 	cmp	x1, x0, lsl #16
    75d4:	54fff103 	b.cc	73f4 <f12+0x3f4>  // b.lo, b.ul, b.last
    75d8:	b5fff439 	cbnz	x25, 745c <f12+0x45c>
    75dc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    75e0:	f900035f 	str	xzr, [x26]
    75e4:	17ffffd0 	b	7524 <f12+0x524>
    75e8:	72003c3f 	tst	w1, #0xffff
    75ec:	54fff361 	b.ne	7458 <f12+0x458>  // b.any
    75f0:	17ffff95 	b	7444 <f12+0x444>
    75f4:	97fff3fc 	bl	45e4 <fwp_rc_wide_dup>
    75f8:	17fffec0 	b	70f8 <f12+0xf8>
    75fc:	f9000be3 	str	x3, [sp, #16]
    7600:	97ffee64 	bl	2f90 <fwp_tape_unlink_scope>
    7604:	a94288bb 	ldp	x27, x2, [x5, #40]
    7608:	f90003e2 	str	x2, [sp]
    760c:	f9401ca2 	ldr	x2, [x5, #56]
    7610:	b90004bf 	str	wzr, [x5, #4]
    7614:	b94000a1 	ldr	w1, [x5]
    7618:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    761c:	f90007e2 	str	x2, [sp, #8]
    7620:	a940a4bc 	ldp	x28, x9, [x5, #8]
    7624:	6b00003f 	cmp	w1, w0
    7628:	f9400be3 	ldr	x3, [sp, #16]
    762c:	a941e8a7 	ldp	x7, x26, [x5, #24]
    7630:	f94020b9 	ldr	x25, [x5, #64]
    7634:	f94024a2 	ldr	x2, [x5, #72]
    7638:	54000108 	b.hi	7658 <f12+0x658>  // b.pmore
    763c:	9101c281 	add	x1, x20, #0x70
    7640:	92403f00 	and	x0, x24, #0xffff
    7644:	d1000400 	sub	x0, x0, #0x1
    7648:	f9407428 	ldr	x8, [x1, #232]
    764c:	eb08001f 	cmp	x0, x8
    7650:	5400004a 	b.ge	7658 <f12+0x658>  // b.tcont
    7654:	f9007420 	str	x0, [x1, #232]
    7658:	4f000400 	movi	v0.4s, #0x0
    765c:	9101c281 	add	x1, x20, #0x70
    7660:	90ffffe0 	adrp	x0, 3000 <fwp_flush+0x10>
    7664:	913fc000 	add	x0, x0, #0xff0
    7668:	f9000cbf 	str	xzr, [x5, #24]
    766c:	910163e4 	add	x4, sp, #0x58
    7670:	f9418828 	ldr	x8, [x1, #784]
    7674:	3c8080a0 	stur	q0, [x5, #8]
    7678:	9101c3e6 	add	x6, sp, #0x70
    767c:	a90583e8 	stp	x8, x0, [sp, #88]
    7680:	f94003e0 	ldr	x0, [sp]
    7684:	ad0100a0 	stp	q0, q0, [x5, #32]
    7688:	f90043e0 	str	x0, [sp, #128]
    768c:	f94007e0 	ldr	x0, [sp, #8]
    7690:	a90113e6 	stp	x6, x4, [sp, #16]
    7694:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    7698:	a906ebe6 	stp	x6, x26, [sp, #104]
    769c:	f9003ffb 	str	x27, [sp, #120]
    76a0:	f90047e0 	str	x0, [sp, #136]
    76a4:	a9091ff9 	stp	x25, x7, [sp, #144]
    76a8:	f90053e2 	str	x2, [sp, #160]
    76ac:	f9018824 	str	x4, [x1, #784]
    76b0:	b7f82163 	tbnz	x3, #63, 7adc <f12+0xadc>
    76b4:	eb83831f 	cmp	x24, x3, asr #32
    76b8:	54000080 	b.eq	76c8 <f12+0x6c8>  // b.none
    76bc:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    76c0:	9116e000 	add	x0, x0, #0x5b8
    76c4:	97fff293 	bl	4110 <fwp_trap>
    76c8:	92407c60 	and	x0, x3, #0xffffffff
    76cc:	eb00039f 	cmp	x28, x0
    76d0:	9a80c798 	csinc	x24, x28, x0, gt
    76d4:	eb23413f 	cmp	x9, w3, uxtw
    76d8:	540020cd 	b.le	7af0 <f12+0xaf0>
    76dc:	eb18005f 	cmp	x2, x24
    76e0:	540020ea 	b.ge	7afc <f12+0xafc>  // b.tcont
    76e4:	f100005f 	cmp	x2, #0x0
    76e8:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    76ec:	9a981042 	csel	x2, x2, x24, ne	// ne = any
    76f0:	14000004 	b	7700 <f12+0x700>
    76f4:	eb01005f 	cmp	x2, x1
    76f8:	d37ff842 	lsl	x2, x2, #1
    76fc:	9a98d042 	csel	x2, x2, x24, le
    7700:	eb18005f 	cmp	x2, x24
    7704:	54ffff8b 	b.lt	76f4 <f12+0x6f4>  // b.tstop
    7708:	f90017e3 	str	x3, [sp, #40]
    770c:	b4003d79 	cbz	x25, 7eb8 <f12+0xeb8>
    7710:	aa1903e0 	mov	x0, x25
    7714:	d37df041 	lsl	x1, x2, #3
    7718:	f90013e2 	str	x2, [sp, #32]
    771c:	97ffec55 	bl	2870 <realloc@plt>
    7720:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7724:	aa0003f9 	mov	x25, x0
    7728:	b4001eb9 	cbz	x25, 7afc <f12+0xafc>
    772c:	f9004bf9 	str	x25, [sp, #144]
    7730:	f90053e2 	str	x2, [sp, #160]
    7734:	b5001c78 	cbnz	x24, 7ac0 <f12+0xac0>
    7738:	b7f800c3 	tbnz	x3, #63, 7750 <f12+0x750>
    773c:	92407c63 	and	x3, x3, #0xffffffff
    7740:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7744:	fc637b20 	ldr	d0, [x25, x3, lsl #3]
    7748:	1e612800 	fadd	d0, d0, d1
    774c:	fc237b20 	str	d0, [x25, x3, lsl #3]
    7750:	9101c281 	add	x1, x20, #0x70
    7754:	cb1c0303 	sub	x3, x24, x28
    7758:	52800060 	mov	w0, #0x3                   	// #3
    775c:	a9428825 	ldp	x5, x2, [x1, #40]
    7760:	8b1c0042 	add	x2, x2, x28
    7764:	8b050063 	add	x3, x3, x5
    7768:	a9028823 	stp	x3, x2, [x1, #40]
    776c:	97ffefa1 	bl	35f0 <descent_phase_step>
    7770:	d1000700 	sub	x0, x24, #0x1
    7774:	d1000782 	sub	x2, x28, #0x1
    7778:	eb00039f 	cmp	x28, x0
    777c:	540003ec 	b.gt	77f8 <f12+0x7f8>
    7780:	fc607b20 	ldr	d0, [x25, x0, lsl #3]
    7784:	1e602008 	fcmp	d0, #0.0
    7788:	54000320 	b.eq	77ec <f12+0x7ec>  // b.none
    778c:	cb1c0be1 	neg	x1, x28, lsl #2
    7790:	cb1c03e5 	neg	x5, x28
    7794:	8b010343 	add	x3, x26, x1
    7798:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    779c:	37f80123 	tbnz	w3, #31, 77c0 <f12+0x7c0>
    77a0:	f94003e4 	ldr	x4, [sp]
    77a4:	93407c63 	sxtw	x3, w3
    77a8:	8b050c87 	add	x7, x4, x5, lsl #3
    77ac:	fc637b21 	ldr	d1, [x25, x3, lsl #3]
    77b0:	fc6078e2 	ldr	d2, [x7, x0, lsl #3]
    77b4:	1e620802 	fmul	d2, d0, d2
    77b8:	1e622821 	fadd	d1, d1, d2
    77bc:	fc237b21 	str	d1, [x25, x3, lsl #3]
    77c0:	8b010361 	add	x1, x27, x1
    77c4:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    77c8:	37f80121 	tbnz	w1, #31, 77ec <f12+0x7ec>
    77cc:	f94007e3 	ldr	x3, [sp, #8]
    77d0:	93407c21 	sxtw	x1, w1
    77d4:	8b050c65 	add	x5, x3, x5, lsl #3
    77d8:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    77dc:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    77e0:	1e620800 	fmul	d0, d0, d2
    77e4:	1e602820 	fadd	d0, d1, d0
    77e8:	fc217b20 	str	d0, [x25, x1, lsl #3]
    77ec:	d1000400 	sub	x0, x0, #0x1
    77f0:	eb00005f 	cmp	x2, x0
    77f4:	54fffc61 	b.ne	7780 <f12+0x780>  // b.any
    77f8:	52800080 	mov	w0, #0x4                   	// #4
    77fc:	97ffef7d 	bl	35f0 <descent_phase_step>
    7800:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7804:	eb00039f 	cmp	x28, x0
    7808:	54001a28 	b.hi	7b4c <f12+0xb4c>  // b.pmore
    780c:	91000780 	add	x0, x28, #0x1
    7810:	52800041 	mov	w1, #0x2                   	// #2
    7814:	d37df000 	lsl	x0, x0, #3
    7818:	97fff5b6 	bl	4ef0 <fwp_heap_alloc>
    781c:	aa0003f8 	mov	x24, x0
    7820:	f800841c 	str	x28, [x0], #8
    7824:	d2800001 	mov	x1, #0x0                   	// #0
    7828:	b40000dc 	cbz	x28, 7840 <f12+0x840>
    782c:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    7830:	f8217802 	str	x2, [x0, x1, lsl #3]
    7834:	91000421 	add	x1, x1, #0x1
    7838:	eb01039f 	cmp	x28, x1
    783c:	54ffff81 	b.ne	782c <f12+0x82c>  // b.any
    7840:	528000a0 	mov	w0, #0x5                   	// #5
    7844:	97ffef6b 	bl	35f0 <descent_phase_step>
    7848:	9101c281 	add	x1, x20, #0x70
    784c:	f9400fe2 	ldr	x2, [sp, #24]
    7850:	f9418820 	ldr	x0, [x1, #784]
    7854:	eb02001f 	cmp	x0, x2
    7858:	54004aa1 	b.ne	81ac <f12+0x11ac>  // b.any
    785c:	f9400be0 	ldr	x0, [sp, #16]
    7860:	f9402ffa 	ldr	x26, [sp, #88]
    7864:	f901883a 	str	x26, [x1, #784]
    7868:	97fff1e2 	bl	3ff0 <fwp_tape_buffers_release>
    786c:	528000c0 	mov	w0, #0x6                   	// #6
    7870:	97ffef60 	bl	35f0 <descent_phase_step>
    7874:	911742a2 	add	x2, x21, #0x5d0
    7878:	f949d841 	ldr	x1, [x2, #5040]
    787c:	f949ec40 	ldr	x0, [x2, #5080]
    7880:	cb010301 	sub	x1, x24, x1
    7884:	eb00403f 	cmp	x1, x0, lsl #16
    7888:	54000322 	b.cs	78ec <f12+0x8ec>  // b.hs, b.nlast
    788c:	d350fc20 	lsr	x0, x1, #16
    7890:	f949fc43 	ldr	x3, [x2, #5112]
    7894:	8b000800 	add	x0, x0, x0, lsl #2
    7898:	d37df002 	lsl	x2, x0, #3
    789c:	8b020060 	add	x0, x3, x2
    78a0:	f9401019 	ldr	x25, [x0, #32]
    78a4:	b4000259 	cbz	x25, 78ec <f12+0x8ec>
    78a8:	38626862 	ldrb	w2, [x3, x2]
    78ac:	7100085f 	cmp	w2, #0x2
    78b0:	54003180 	b.eq	7ee0 <f12+0xee0>  // b.none
    78b4:	7100045f 	cmp	w2, #0x1
    78b8:	540001a1 	b.ne	78ec <f12+0x8ec>  // b.any
    78bc:	29430002 	ldp	w2, w0, [x0, #24]
    78c0:	92403c21 	and	x1, x1, #0xffff
    78c4:	9b027c21 	mul	x1, x1, x2
    78c8:	d360fc21 	lsr	x1, x1, #32
    78cc:	eb00003f 	cmp	x1, x0
    78d0:	540000e2 	b.cs	78ec <f12+0x8ec>  // b.hs, b.nlast
    78d4:	8b010339 	add	x25, x25, x1
    78d8:	39400320 	ldrb	w0, [x25]
    78dc:	7103fc1f 	cmp	w0, #0xff
    78e0:	54003060 	b.eq	7eec <f12+0xeec>  // b.none
    78e4:	52800020 	mov	w0, #0x1                   	// #1
    78e8:	39000320 	strb	w0, [x25]
    78ec:	eb17035f 	cmp	x26, x23
    78f0:	540045e1 	b.ne	81ac <f12+0x11ac>  // b.any
    78f4:	f94023e1 	ldr	x1, [sp, #64]
    78f8:	9101c294 	add	x20, x20, #0x70
    78fc:	aa1603e0 	mov	x0, x22
    7900:	f9018a81 	str	x1, [x20, #784]
    7904:	97fffacb 	bl	6430 <fwp_tape_scope_release>
    7908:	f9400300 	ldr	x0, [x24]
    790c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7910:	b7f812c0 	tbnz	x0, #63, 7b68 <f12+0xb68>
    7914:	911742a2 	add	x2, x21, #0x5d0
    7918:	f949d840 	ldr	x0, [x2, #5040]
    791c:	f949ec41 	ldr	x1, [x2, #5080]
    7920:	cb000300 	sub	x0, x24, x0
    7924:	eb01401f 	cmp	x0, x1, lsl #16
    7928:	54001202 	b.cs	7b68 <f12+0xb68>  // b.hs, b.nlast
    792c:	d350fc01 	lsr	x1, x0, #16
    7930:	f949fc44 	ldr	x4, [x2, #5112]
    7934:	8b010821 	add	x1, x1, x1, lsl #2
    7938:	d37df021 	lsl	x1, x1, #3
    793c:	8b010083 	add	x3, x4, x1
    7940:	f9401062 	ldr	x2, [x3, #32]
    7944:	b4001122 	cbz	x2, 7b68 <f12+0xb68>
    7948:	38616881 	ldrb	w1, [x4, x1]
    794c:	7100083f 	cmp	w1, #0x2
    7950:	54001080 	b.eq	7b60 <f12+0xb60>  // b.none
    7954:	7100043f 	cmp	w1, #0x1
    7958:	54001081 	b.ne	7b68 <f12+0xb68>  // b.any
    795c:	29430464 	ldp	w4, w1, [x3, #24]
    7960:	92403c00 	and	x0, x0, #0xffff
    7964:	9b047c00 	mul	x0, x0, x4
    7968:	d360fc00 	lsr	x0, x0, #32
    796c:	eb01001f 	cmp	x0, x1
    7970:	54000fc2 	b.cs	7b68 <f12+0xb68>  // b.hs, b.nlast
    7974:	8b000042 	add	x2, x2, x0
    7978:	39400040 	ldrb	w0, [x2]
    797c:	7100041f 	cmp	w0, #0x1
    7980:	54000f41 	b.ne	7b68 <f12+0xb68>  // b.any
    7984:	aa1803f6 	mov	x22, x24
    7988:	d2800000 	mov	x0, #0x0                   	// #0
    798c:	910022c2 	add	x2, x22, #0x8
    7990:	d2800001 	mov	x1, #0x0                   	// #0
    7994:	b40001f7 	cbz	x23, 79d0 <f12+0x9d0>
    7998:	90000023 	adrp	x3, b000 <__modti3+0x1b0>
    799c:	91002304 	add	x4, x24, #0x8
    79a0:	fd47f461 	ldr	d1, [x3, #4072]
    79a4:	f9400305 	ldr	x5, [x24]
    79a8:	aa0403e3 	mov	x3, x4
    79ac:	b7f80d65 	tbnz	x5, #63, 7b58 <f12+0xb58>
    79b0:	f94002c5 	ldr	x5, [x22]
    79b4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    79b8:	b7f828e5 	tbnz	x5, #63, 7ed4 <f12+0xed4>
    79bc:	1e600820 	fmul	d0, d1, d0
    79c0:	91000421 	add	x1, x1, #0x1
    79c4:	fc008440 	str	d0, [x2], #8
    79c8:	eb0102ff 	cmp	x23, x1
    79cc:	54fffec1 	b.ne	79a4 <f12+0x9a4>  // b.any
    79d0:	97fffce4 	bl	6d60 <fwp_drop4>
    79d4:	b4002ed3 	cbz	x19, 7fac <f12+0xfac>
    79d8:	aa1303e0 	mov	x0, x19
    79dc:	d2800018 	mov	x24, #0x0                   	// #0
    79e0:	f9400800 	ldr	x0, [x0, #16]
    79e4:	91000718 	add	x24, x24, #0x1
    79e8:	b5ffffc0 	cbnz	x0, 79e0 <f12+0x9e0>
    79ec:	f94002c0 	ldr	x0, [x22]
    79f0:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    79f4:	b7f810c0 	tbnz	x0, #63, 7c0c <f12+0xc0c>
    79f8:	911742a1 	add	x1, x21, #0x5d0
    79fc:	f949d820 	ldr	x0, [x1, #5040]
    7a00:	f949ec22 	ldr	x2, [x1, #5080]
    7a04:	cb0002c0 	sub	x0, x22, x0
    7a08:	eb02401f 	cmp	x0, x2, lsl #16
    7a0c:	540027e2 	b.cs	7f08 <f12+0xf08>  // b.hs, b.nlast
    7a10:	d350fc02 	lsr	x2, x0, #16
    7a14:	d2800503 	mov	x3, #0x28                  	// #40
    7a18:	f949fc24 	ldr	x4, [x1, #5112]
    7a1c:	9b037c42 	mul	x2, x2, x3
    7a20:	8b020083 	add	x3, x4, x2
    7a24:	f9401061 	ldr	x1, [x3, #32]
    7a28:	b4002701 	cbz	x1, 7f08 <f12+0xf08>
    7a2c:	38626882 	ldrb	w2, [x4, x2]
    7a30:	7100085f 	cmp	w2, #0x2
    7a34:	54002660 	b.eq	7f00 <f12+0xf00>  // b.none
    7a38:	7100045f 	cmp	w2, #0x1
    7a3c:	54002661 	b.ne	7f08 <f12+0xf08>  // b.any
    7a40:	29430864 	ldp	w4, w2, [x3, #24]
    7a44:	92403c00 	and	x0, x0, #0xffff
    7a48:	9b047c00 	mul	x0, x0, x4
    7a4c:	d360fc00 	lsr	x0, x0, #32
    7a50:	eb02001f 	cmp	x0, x2
    7a54:	540025a2 	b.cs	7f08 <f12+0xf08>  // b.hs, b.nlast
    7a58:	8b000021 	add	x1, x1, x0
    7a5c:	39400037 	ldrb	w23, [x1]
    7a60:	710006ff 	cmp	w23, #0x1
    7a64:	54002521 	b.ne	7f08 <f12+0xf08>  // b.any
    7a68:	910022db 	add	x27, x22, #0x8
    7a6c:	eb18029f 	cmp	x20, x24
    7a70:	9a989294 	csel	x20, x20, x24, ls	// ls = plast
    7a74:	b4002574 	cbz	x20, 7f20 <f12+0xf20>
    7a78:	d37df284 	lsl	x4, x20, #3
    7a7c:	aa1303e1 	mov	x1, x19
    7a80:	910022c3 	add	x3, x22, #0x8
    7a84:	d2800000 	mov	x0, #0x0                   	// #0
    7a88:	14000009 	b	7aac <f12+0xaac>
    7a8c:	fc606841 	ldr	d1, [x2, x0]
    7a90:	fd400420 	ldr	d0, [x1, #8]
    7a94:	1e613800 	fsub	d0, d0, d1
    7a98:	fc206b60 	str	d0, [x27, x0]
    7a9c:	91002000 	add	x0, x0, #0x8
    7aa0:	f9400821 	ldr	x1, [x1, #16]
    7aa4:	eb04001f 	cmp	x0, x4
    7aa8:	54000de0 	b.eq	7c64 <f12+0xc64>  // b.none
    7aac:	f94002c5 	ldr	x5, [x22]
    7ab0:	aa0303e2 	mov	x2, x3
    7ab4:	b6fffec5 	tbz	x5, #63, 7a8c <f12+0xa8c>
    7ab8:	f9400ac2 	ldr	x2, [x22, #16]
    7abc:	17fffff4 	b	7a8c <f12+0xa8c>
    7ac0:	d37df302 	lsl	x2, x24, #3
    7ac4:	aa1903e0 	mov	x0, x25
    7ac8:	52800001 	mov	w1, #0x0                   	// #0
    7acc:	f90013e3 	str	x3, [sp, #32]
    7ad0:	97ffeb60 	bl	2850 <memset@plt>
    7ad4:	f94013e3 	ldr	x3, [sp, #32]
    7ad8:	17ffff18 	b	7738 <f12+0x738>
    7adc:	aa1c03f8 	mov	x24, x28
    7ae0:	17fffeff 	b	76dc <f12+0x6dc>
    7ae4:	aa1b03e0 	mov	x0, x27
    7ae8:	97fff1aa 	bl	4190 <fwp_rc_forget_slot.part.0>
    7aec:	17fffe59 	b	7450 <f12+0x450>
    7af0:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7af4:	9118c000 	add	x0, x0, #0x630
    7af8:	97fff186 	bl	4110 <fwp_trap>
    7afc:	f100031f 	cmp	x24, #0x0
    7b00:	fa401b20 	ccmp	x25, #0x0, #0x0, ne	// ne = any
    7b04:	54ffe181 	b.ne	7734 <f12+0x734>  // b.any
    7b08:	f9400be0 	ldr	x0, [sp, #16]
    7b0c:	9101c294 	add	x20, x20, #0x70
    7b10:	f9402fe1 	ldr	x1, [sp, #88]
    7b14:	f9018a81 	str	x1, [x20, #784]
    7b18:	97fff136 	bl	3ff0 <fwp_tape_buffers_release>
    7b1c:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7b20:	f947e863 	ldr	x3, [x3, #4048]
    7b24:	d2800262 	mov	x2, #0x13                  	// #19
    7b28:	d2800021 	mov	x1, #0x1                   	// #1
    7b2c:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7b30:	9107e000 	add	x0, x0, #0x1f8
    7b34:	f9400063 	ldr	x3, [x3]
    7b38:	97ffeb92 	bl	2980 <fwrite@plt>
    7b3c:	d2800000 	mov	x0, #0x0                   	// #0
    7b40:	97ffeb9c 	bl	29b0 <fflush@plt>
    7b44:	52800cc0 	mov	w0, #0x66                  	// #102
    7b48:	97ffebaa 	bl	29f0 <_Exit@plt>
    7b4c:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7b50:	911c8000 	add	x0, x0, #0x720
    7b54:	97fff16f 	bl	4110 <fwp_trap>
    7b58:	f9400b03 	ldr	x3, [x24, #16]
    7b5c:	17ffff95 	b	79b0 <f12+0x9b0>
    7b60:	72003c1f 	tst	w0, #0xffff
    7b64:	54fff0a0 	b.eq	7978 <f12+0x978>  // b.none
    7b68:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7b6c:	eb0002ff 	cmp	x23, x0
    7b70:	54fffee8 	b.hi	7b4c <f12+0xb4c>  // b.pmore
    7b74:	910006e0 	add	x0, x23, #0x1
    7b78:	52800021 	mov	w1, #0x1                   	// #1
    7b7c:	d37df000 	lsl	x0, x0, #3
    7b80:	97fff4dc 	bl	4ef0 <fwp_heap_alloc>
    7b84:	911742a2 	add	x2, x21, #0x5d0
    7b88:	f9000017 	str	x23, [x0]
    7b8c:	aa0003f6 	mov	x22, x0
    7b90:	f949d841 	ldr	x1, [x2, #5040]
    7b94:	f949ec40 	ldr	x0, [x2, #5080]
    7b98:	cb0102c1 	sub	x1, x22, x1
    7b9c:	eb00403f 	cmp	x1, x0, lsl #16
    7ba0:	54000322 	b.cs	7c04 <f12+0xc04>  // b.hs, b.nlast
    7ba4:	d350fc20 	lsr	x0, x1, #16
    7ba8:	d2800504 	mov	x4, #0x28                  	// #40
    7bac:	f949fc43 	ldr	x3, [x2, #5112]
    7bb0:	9b047c00 	mul	x0, x0, x4
    7bb4:	8b000062 	add	x2, x3, x0
    7bb8:	f9401054 	ldr	x20, [x2, #32]
    7bbc:	b4000254 	cbz	x20, 7c04 <f12+0xc04>
    7bc0:	38606860 	ldrb	w0, [x3, x0]
    7bc4:	7100081f 	cmp	w0, #0x2
    7bc8:	54001e60 	b.eq	7f94 <f12+0xf94>  // b.none
    7bcc:	7100041f 	cmp	w0, #0x1
    7bd0:	540001a1 	b.ne	7c04 <f12+0xc04>  // b.any
    7bd4:	29430043 	ldp	w3, w0, [x2, #24]
    7bd8:	92403c21 	and	x1, x1, #0xffff
    7bdc:	9b037c21 	mul	x1, x1, x3
    7be0:	d360fc21 	lsr	x1, x1, #32
    7be4:	eb00003f 	cmp	x1, x0
    7be8:	540000e2 	b.cs	7c04 <f12+0xc04>  // b.hs, b.nlast
    7bec:	8b010294 	add	x20, x20, x1
    7bf0:	39400280 	ldrb	w0, [x20]
    7bf4:	7103fc1f 	cmp	w0, #0xff
    7bf8:	54001c80 	b.eq	7f88 <f12+0xf88>  // b.none
    7bfc:	52800020 	mov	w0, #0x1                   	// #1
    7c00:	39000280 	strb	w0, [x20]
    7c04:	aa1803e0 	mov	x0, x24
    7c08:	17ffff61 	b	798c <f12+0x98c>
    7c0c:	aa1303f7 	mov	x23, x19
    7c10:	d2800018 	mov	x24, #0x0                   	// #0
    7c14:	f9400af7 	ldr	x23, [x23, #16]
    7c18:	aa1803e0 	mov	x0, x24
    7c1c:	91000718 	add	x24, x24, #0x1
    7c20:	b5ffffb7 	cbnz	x23, 7c14 <f12+0xc14>
    7c24:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7c28:	eb01031f 	cmp	x24, x1
    7c2c:	54ffb908 	b.hi	734c <f12+0x34c>  // b.pmore
    7c30:	91000800 	add	x0, x0, #0x2
    7c34:	52800041 	mov	w1, #0x2                   	// #2
    7c38:	d37df000 	lsl	x0, x0, #3
    7c3c:	97fff4ad 	bl	4ef0 <fwp_heap_alloc>
    7c40:	aa1303e1 	mov	x1, x19
    7c44:	aa0003fb 	mov	x27, x0
    7c48:	f9400420 	ldr	x0, [x1, #8]
    7c4c:	f8377b60 	str	x0, [x27, x23, lsl #3]
    7c50:	910006f7 	add	x23, x23, #0x1
    7c54:	f9400821 	ldr	x1, [x1, #16]
    7c58:	b5ffff81 	cbnz	x1, 7c48 <f12+0xc48>
    7c5c:	52800017 	mov	w23, #0x0                   	// #0
    7c60:	17ffff83 	b	7a6c <f12+0xa6c>
    7c64:	b4001a13 	cbz	x19, 7fa4 <f12+0xfa4>
    7c68:	911742a0 	add	x0, x21, #0x5d0
    7c6c:	aa1303e2 	mov	x2, x19
    7c70:	d2800019 	mov	x25, #0x0                   	// #0
    7c74:	f949ec05 	ldr	x5, [x0, #5080]
    7c78:	f949d808 	ldr	x8, [x0, #5040]
    7c7c:	f949fc07 	ldr	x7, [x0, #5112]
    7c80:	d370bca5 	lsl	x5, x5, #16
    7c84:	14000006 	b	7c9c <f12+0xc9c>
    7c88:	f9400842 	ldr	x2, [x2, #16]
    7c8c:	91000739 	add	x25, x25, #0x1
    7c90:	f100005f 	cmp	x2, #0x0
    7c94:	fa541322 	ccmp	x25, x20, #0x2, ne	// ne = any
    7c98:	54000322 	b.cs	7cfc <f12+0xcfc>  // b.hs, b.nlast
    7c9c:	cb080040 	sub	x0, x2, x8
    7ca0:	eb05001f 	cmp	x0, x5
    7ca4:	540002c2 	b.cs	7cfc <f12+0xcfc>  // b.hs, b.nlast
    7ca8:	d350fc01 	lsr	x1, x0, #16
    7cac:	8b010821 	add	x1, x1, x1, lsl #2
    7cb0:	d37df021 	lsl	x1, x1, #3
    7cb4:	8b0100e6 	add	x6, x7, x1
    7cb8:	f94010c4 	ldr	x4, [x6, #32]
    7cbc:	b4000204 	cbz	x4, 7cfc <f12+0xcfc>
    7cc0:	386168e1 	ldrb	w1, [x7, x1]
    7cc4:	7100083f 	cmp	w1, #0x2
    7cc8:	54000f20 	b.eq	7eac <f12+0xeac>  // b.none
    7ccc:	7100043f 	cmp	w1, #0x1
    7cd0:	54000161 	b.ne	7cfc <f12+0xcfc>  // b.any
    7cd4:	294304c9 	ldp	w9, w1, [x6, #24]
    7cd8:	92403c00 	and	x0, x0, #0xffff
    7cdc:	9b097c00 	mul	x0, x0, x9
    7ce0:	d360fc00 	lsr	x0, x0, #32
    7ce4:	eb01001f 	cmp	x0, x1
    7ce8:	540000a2 	b.cs	7cfc <f12+0xcfc>  // b.hs, b.nlast
    7cec:	8b000084 	add	x4, x4, x0
    7cf0:	39400080 	ldrb	w0, [x4]
    7cf4:	7100041f 	cmp	w0, #0x1
    7cf8:	54fffc80 	b.eq	7c88 <f12+0xc88>  // b.none
    7cfc:	d2800018 	mov	x24, #0x0                   	// #0
    7d00:	eb14033f 	cmp	x25, x20
    7d04:	54001602 	b.cs	7fc4 <f12+0xfc4>  // b.hs, b.nlast
    7d08:	d1002360 	sub	x0, x27, #0x8
    7d0c:	f90007e0 	str	x0, [sp, #8]
    7d10:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7d14:	911742bc 	add	x28, x21, #0x5d0
    7d18:	d2800018 	mov	x24, #0x0                   	// #0
    7d1c:	fd47d808 	ldr	d8, [x0, #4016]
    7d20:	14000043 	b	7e2c <f12+0xe2c>
    7d24:	f9400340 	ldr	x0, [x26]
    7d28:	aa2003e0 	mvn	x0, x0
    7d2c:	f8217b80 	str	x0, [x28, x1, lsl #3]
    7d30:	f10060bf 	cmp	x5, #0x18
    7d34:	54000169 	b.ls	7d60 <f12+0xd60>  // b.plast
    7d38:	d10064a2 	sub	x2, x5, #0x19
    7d3c:	91006340 	add	x0, x26, #0x18
    7d40:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7d44:	52800001 	mov	w1, #0x0                   	// #0
    7d48:	91002042 	add	x2, x2, #0x8
    7d4c:	f9000be5 	str	x5, [sp, #16]
    7d50:	b9001be6 	str	w6, [sp, #24]
    7d54:	97ffeabf 	bl	2850 <memset@plt>
    7d58:	f9400be5 	ldr	x5, [sp, #16]
    7d5c:	b9401be6 	ldr	w6, [sp, #24]
    7d60:	911742a1 	add	x1, x21, #0x5d0
    7d64:	f94a1020 	ldr	x0, [x1, #5152]
    7d68:	ab050000 	adds	x0, x0, x5
    7d6c:	540014c2 	b.cs	8004 <f12+0x1004>  // b.hs, b.nlast
    7d70:	f94a1422 	ldr	x2, [x1, #5160]
    7d74:	f90a1020 	str	x0, [x1, #5152]
    7d78:	eb02001f 	cmp	x0, x2
    7d7c:	54000049 	b.ls	7d84 <f12+0xd84>  // b.plast
    7d80:	f90a1420 	str	x0, [x1, #5160]
    7d84:	911742a0 	add	x0, x21, #0x5d0
    7d88:	1e6300c1 	ucvtf	d1, w6
    7d8c:	fd4a1c00 	ldr	d0, [x0, #5176]
    7d90:	1e612800 	fadd	d0, d0, d1
    7d94:	fd0a1c00 	str	d0, [x0, #5176]
    7d98:	f94003e0 	ldr	x0, [sp]
    7d9c:	a900e340 	stp	x0, x24, [x26, #8]
    7da0:	aa1a03f8 	mov	x24, x26
    7da4:	fd000348 	str	d8, [x26]
    7da8:	f949db81 	ldr	x1, [x28, #5040]
    7dac:	f949ef80 	ldr	x0, [x28, #5080]
    7db0:	cb010341 	sub	x1, x26, x1
    7db4:	eb00403f 	cmp	x1, x0, lsl #16
    7db8:	54000322 	b.cs	7e1c <f12+0xe1c>  // b.hs, b.nlast
    7dbc:	d350fc20 	lsr	x0, x1, #16
    7dc0:	f949ff85 	ldr	x5, [x28, #5112]
    7dc4:	8b000800 	add	x0, x0, x0, lsl #2
    7dc8:	d37df002 	lsl	x2, x0, #3
    7dcc:	8b0200a0 	add	x0, x5, x2
    7dd0:	f940101a 	ldr	x26, [x0, #32]
    7dd4:	b400025a 	cbz	x26, 7e1c <f12+0xe1c>
    7dd8:	386268a2 	ldrb	w2, [x5, x2]
    7ddc:	7100085f 	cmp	w2, #0x2
    7de0:	54000600 	b.eq	7ea0 <f12+0xea0>  // b.none
    7de4:	7100045f 	cmp	w2, #0x1
    7de8:	540001a1 	b.ne	7e1c <f12+0xe1c>  // b.any
    7dec:	29430002 	ldp	w2, w0, [x0, #24]
    7df0:	92403c21 	and	x1, x1, #0xffff
    7df4:	9b027c21 	mul	x1, x1, x2
    7df8:	d360fc21 	lsr	x1, x1, #32
    7dfc:	eb00003f 	cmp	x1, x0
    7e00:	540000e2 	b.cs	7e1c <f12+0xe1c>  // b.hs, b.nlast
    7e04:	8b01035a 	add	x26, x26, x1
    7e08:	39400340 	ldrb	w0, [x26]
    7e0c:	7103fc1f 	cmp	w0, #0xff
    7e10:	54000f40 	b.eq	7ff8 <f12+0xff8>  // b.none
    7e14:	52800020 	mov	w0, #0x1                   	// #1
    7e18:	39000340 	strb	w0, [x26]
    7e1c:	d1000680 	sub	x0, x20, #0x1
    7e20:	eb19001f 	cmp	x0, x25
    7e24:	54000f29 	b.ls	8008 <f12+0x1008>  // b.plast
    7e28:	aa0003f4 	mov	x20, x0
    7e2c:	f94007e1 	ldr	x1, [sp, #8]
    7e30:	b953a780 	ldr	w0, [x28, #5028]
    7e34:	f8747821 	ldr	x1, [x1, x20, lsl #3]
    7e38:	f90003e1 	str	x1, [sp]
    7e3c:	34000280 	cbz	w0, 7e8c <f12+0xe8c>
    7e40:	397e8b80 	ldrb	w0, [x28, #4002]
    7e44:	910f0002 	add	x2, x0, #0x3c0
    7e48:	8b000401 	add	x1, x0, x0, lsl #1
    7e4c:	b8627b86 	ldr	w6, [x28, x2, lsl #2]
    7e50:	8b010f82 	add	x2, x28, x1, lsl #3
    7e54:	f8617b9a 	ldr	x26, [x28, x1, lsl #3]
    7e58:	2a0603e5 	mov	w5, w6
    7e5c:	b5fff65a 	cbnz	x26, 7d24 <f12+0xd24>
    7e60:	f940045a 	ldr	x26, [x2, #8]
    7e64:	b400015a 	cbz	x26, 7e8c <f12+0xe8c>
    7e68:	f9400841 	ldr	x1, [x2, #16]
    7e6c:	cb1a0021 	sub	x1, x1, x26
    7e70:	eb0100bf 	cmp	x5, x1
    7e74:	540000c8 	b.hi	7e8c <f12+0xe8c>  // b.pmore
    7e78:	d2800302 	mov	x2, #0x18                  	// #24
    7e7c:	8b050341 	add	x1, x26, x5
    7e80:	9b027000 	madd	x0, x0, x2, x28
    7e84:	f9000401 	str	x1, [x0, #8]
    7e88:	17ffffaa 	b	7d30 <f12+0xd30>
    7e8c:	52800001 	mov	w1, #0x0                   	// #0
    7e90:	d2800300 	mov	x0, #0x18                  	// #24
    7e94:	97fff417 	bl	4ef0 <fwp_heap_alloc>
    7e98:	aa0003fa 	mov	x26, x0
    7e9c:	17ffffbf 	b	7d98 <f12+0xd98>
    7ea0:	72003c3f 	tst	w1, #0xffff
    7ea4:	54fffbc1 	b.ne	7e1c <f12+0xe1c>  // b.any
    7ea8:	17ffffd8 	b	7e08 <f12+0xe08>
    7eac:	72003c1f 	tst	w0, #0xffff
    7eb0:	54fff261 	b.ne	7cfc <f12+0xcfc>  // b.any
    7eb4:	17ffff8f 	b	7cf0 <f12+0xcf0>
    7eb8:	aa0203e0 	mov	x0, x2
    7ebc:	d2800101 	mov	x1, #0x8                   	// #8
    7ec0:	f90013e2 	str	x2, [sp, #32]
    7ec4:	97ffea67 	bl	2860 <calloc@plt>
    7ec8:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7ecc:	aa0003f9 	mov	x25, x0
    7ed0:	17fffe16 	b	7728 <f12+0x728>
    7ed4:	90000020 	adrp	x0, b000 <__modti3+0x1b0>
    7ed8:	911cc000 	add	x0, x0, #0x730
    7edc:	97fff08d 	bl	4110 <fwp_trap>
    7ee0:	72003c3f 	tst	w1, #0xffff
    7ee4:	54ffd041 	b.ne	78ec <f12+0x8ec>  // b.any
    7ee8:	17fffe7c 	b	78d8 <f12+0x8d8>
    7eec:	aa1903e0 	mov	x0, x25
    7ef0:	97fff0a8 	bl	4190 <fwp_rc_forget_slot.part.0>
    7ef4:	9101c280 	add	x0, x20, #0x70
    7ef8:	f941881a 	ldr	x26, [x0, #784]
    7efc:	17fffe7a 	b	78e4 <f12+0x8e4>
    7f00:	72003c1f 	tst	w0, #0xffff
    7f04:	54ffdac0 	b.eq	7a5c <f12+0xa5c>  // b.none
    7f08:	b5ffe833 	cbnz	x19, 7c0c <f12+0xc0c>
    7f0c:	52800041 	mov	w1, #0x2                   	// #2
    7f10:	d2800100 	mov	x0, #0x8                   	// #8
    7f14:	97fff3f7 	bl	4ef0 <fwp_heap_alloc>
    7f18:	aa0003fb 	mov	x27, x0
    7f1c:	52800017 	mov	w23, #0x0                   	// #0
    7f20:	d2800018 	mov	x24, #0x0                   	// #0
    7f24:	710002ff 	cmp	w23, #0x0
    7f28:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7f2c:	aa1b03e0 	mov	x0, x27
    7f30:	97fff134 	bl	4400 <fwp_mem_free>
    7f34:	aa1603e0 	mov	x0, x22
    7f38:	97fffb8a 	bl	6d60 <fwp_drop4>
    7f3c:	aa1303e0 	mov	x0, x19
    7f40:	97fff795 	bl	5d94 <fwp_drop0>
    7f44:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7f48:	f947f400 	ldr	x0, [x0, #4072]
    7f4c:	f94057e2 	ldr	x2, [sp, #168]
    7f50:	f9400001 	ldr	x1, [x0]
    7f54:	eb010042 	subs	x2, x2, x1
    7f58:	d2800001 	mov	x1, #0x0                   	// #0
    7f5c:	54000321 	b.ne	7fc0 <f12+0xfc0>  // b.any
    7f60:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7f64:	aa1803e0 	mov	x0, x24
    7f68:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7f6c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7f70:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7f74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7f78:	a95073fb 	ldp	x27, x28, [sp, #256]
    7f7c:	fd408be8 	ldr	d8, [sp, #272]
    7f80:	910483ff 	add	sp, sp, #0x120
    7f84:	d65f03c0 	ret
    7f88:	aa1403e0 	mov	x0, x20
    7f8c:	97fff081 	bl	4190 <fwp_rc_forget_slot.part.0>
    7f90:	17ffff1b 	b	7bfc <f12+0xbfc>
    7f94:	72003c3f 	tst	w1, #0xffff
    7f98:	54ffe2c0 	b.eq	7bf0 <f12+0xbf0>  // b.none
    7f9c:	aa1803e0 	mov	x0, x24
    7fa0:	17fffe7b 	b	798c <f12+0x98c>
    7fa4:	d2800019 	mov	x25, #0x0                   	// #0
    7fa8:	17ffff58 	b	7d08 <f12+0xd08>
    7fac:	f94002d4 	ldr	x20, [x22]
    7fb0:	b7fffaf4 	tbnz	x20, #63, 7f0c <f12+0xf0c>
    7fb4:	9240fa94 	and	x20, x20, #0x7fffffffffffffff
    7fb8:	d2800018 	mov	x24, #0x0                   	// #0
    7fbc:	17fffe8f 	b	79f8 <f12+0x9f8>
    7fc0:	97ffea30 	bl	2880 <__stack_chk_fail@plt>
    7fc4:	aa1303e0 	mov	x0, x19
    7fc8:	d2800001 	mov	x1, #0x0                   	// #0
    7fcc:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    7fd0:	91000421 	add	x1, x1, #0x1
    7fd4:	f9000402 	str	x2, [x0, #8]
    7fd8:	aa0003e2 	mov	x2, x0
    7fdc:	f9400800 	ldr	x0, [x0, #16]
    7fe0:	eb01033f 	cmp	x25, x1
    7fe4:	54ffff48 	b.hi	7fcc <f12+0xfcc>  // b.pmore
    7fe8:	f9000858 	str	x24, [x2, #16]
    7fec:	aa1303f8 	mov	x24, x19
    7ff0:	aa0003f3 	mov	x19, x0
    7ff4:	17ffffcc 	b	7f24 <f12+0xf24>
    7ff8:	aa1a03e0 	mov	x0, x26
    7ffc:	97fff065 	bl	4190 <fwp_rc_forget_slot.part.0>
    8000:	17ffff85 	b	7e14 <f12+0xe14>
    8004:	97ffec0b 	bl	3030 <fwp_heap_oom>
    8008:	b5fffdf9 	cbnz	x25, 7fc4 <f12+0xfc4>
    800c:	710002ff 	cmp	w23, #0x0
    8010:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    8014:	b4fff8c0 	cbz	x0, 7f2c <f12+0xf2c>
    8018:	f0000000 	adrp	x0, b000 <__modti3+0x1b0>
    801c:	d1000a94 	sub	x20, x20, #0x2
    8020:	911742b5 	add	x21, x21, #0x5d0
    8024:	d280031a 	mov	x26, #0x18                  	// #24
    8028:	fd47d808 	ldr	d8, [x0, #4016]
    802c:	52800039 	mov	w25, #0x1                   	// #1
    8030:	b953a6a0 	ldr	w0, [x21, #5028]
    8034:	f8747b7c 	ldr	x28, [x27, x20, lsl #3]
    8038:	34000a20 	cbz	w0, 817c <f12+0x117c>
    803c:	397e8aa0 	ldrb	w0, [x21, #4002]
    8040:	910f0002 	add	x2, x0, #0x3c0
    8044:	8b000401 	add	x1, x0, x0, lsl #1
    8048:	b8627aa4 	ldr	w4, [x21, x2, lsl #2]
    804c:	8b010ea2 	add	x2, x21, x1, lsl #3
    8050:	f8617ab7 	ldr	x23, [x21, x1, lsl #3]
    8054:	2a0403e3 	mov	w3, w4
    8058:	b40007f7 	cbz	x23, 8154 <f12+0x1154>
    805c:	f94002e0 	ldr	x0, [x23]
    8060:	aa2003e0 	mvn	x0, x0
    8064:	f8217aa0 	str	x0, [x21, x1, lsl #3]
    8068:	f100607f 	cmp	x3, #0x18
    806c:	54000169 	b.ls	8098 <f12+0x1098>  // b.plast
    8070:	d1006462 	sub	x2, x3, #0x19
    8074:	910062e0 	add	x0, x23, #0x18
    8078:	927df042 	and	x2, x2, #0xfffffffffffffff8
    807c:	52800001 	mov	w1, #0x0                   	// #0
    8080:	91002042 	add	x2, x2, #0x8
    8084:	f90003e3 	str	x3, [sp]
    8088:	b9000be4 	str	w4, [sp, #8]
    808c:	97ffe9f1 	bl	2850 <memset@plt>
    8090:	f94003e3 	ldr	x3, [sp]
    8094:	b9400be4 	ldr	w4, [sp, #8]
    8098:	f94a12a0 	ldr	x0, [x21, #5152]
    809c:	ab030000 	adds	x0, x0, x3
    80a0:	54fffb22 	b.cs	8004 <f12+0x1004>  // b.hs, b.nlast
    80a4:	f94a16a1 	ldr	x1, [x21, #5160]
    80a8:	f90a12a0 	str	x0, [x21, #5152]
    80ac:	eb01001f 	cmp	x0, x1
    80b0:	54000049 	b.ls	80b8 <f12+0x10b8>  // b.plast
    80b4:	f90a16a0 	str	x0, [x21, #5160]
    80b8:	1e630081 	ucvtf	d1, w4
    80bc:	fd4a1ea0 	ldr	d0, [x21, #5176]
    80c0:	1e612800 	fadd	d0, d0, d1
    80c4:	fd0a1ea0 	str	d0, [x21, #5176]
    80c8:	a900e2fc 	stp	x28, x24, [x23, #8]
    80cc:	aa1703f8 	mov	x24, x23
    80d0:	fd0002e8 	str	d8, [x23]
    80d4:	f949daa1 	ldr	x1, [x21, #5040]
    80d8:	f949eea0 	ldr	x0, [x21, #5080]
    80dc:	cb0102e1 	sub	x1, x23, x1
    80e0:	eb00403f 	cmp	x1, x0, lsl #16
    80e4:	54000302 	b.cs	8144 <f12+0x1144>  // b.hs, b.nlast
    80e8:	d350fc20 	lsr	x0, x1, #16
    80ec:	f949fea3 	ldr	x3, [x21, #5112]
    80f0:	8b000800 	add	x0, x0, x0, lsl #2
    80f4:	d37df002 	lsl	x2, x0, #3
    80f8:	8b020060 	add	x0, x3, x2
    80fc:	f9401017 	ldr	x23, [x0, #32]
    8100:	b4000237 	cbz	x23, 8144 <f12+0x1144>
    8104:	38626862 	ldrb	w2, [x3, x2]
    8108:	7100085f 	cmp	w2, #0x2
    810c:	54000420 	b.eq	8190 <f12+0x1190>  // b.none
    8110:	7100045f 	cmp	w2, #0x1
    8114:	54000181 	b.ne	8144 <f12+0x1144>  // b.any
    8118:	29430002 	ldp	w2, w0, [x0, #24]
    811c:	92403c21 	and	x1, x1, #0xffff
    8120:	9b027c21 	mul	x1, x1, x2
    8124:	d360fc21 	lsr	x1, x1, #32
    8128:	eb00003f 	cmp	x1, x0
    812c:	540000c2 	b.cs	8144 <f12+0x1144>  // b.hs, b.nlast
    8130:	8b0102f7 	add	x23, x23, x1
    8134:	394002e0 	ldrb	w0, [x23]
    8138:	7103fc1f 	cmp	w0, #0xff
    813c:	54000300 	b.eq	819c <f12+0x119c>  // b.none
    8140:	390002f9 	strb	w25, [x23]
    8144:	d1000694 	sub	x20, x20, #0x1
    8148:	b100069f 	cmn	x20, #0x1
    814c:	54fff721 	b.ne	8030 <f12+0x1030>  // b.any
    8150:	17ffff77 	b	7f2c <f12+0xf2c>
    8154:	f9400457 	ldr	x23, [x2, #8]
    8158:	b4000137 	cbz	x23, 817c <f12+0x117c>
    815c:	f9400841 	ldr	x1, [x2, #16]
    8160:	cb170021 	sub	x1, x1, x23
    8164:	eb01007f 	cmp	x3, x1
    8168:	540000a8 	b.hi	817c <f12+0x117c>  // b.pmore
    816c:	9b1a5400 	madd	x0, x0, x26, x21
    8170:	8b0302e1 	add	x1, x23, x3
    8174:	f9000401 	str	x1, [x0, #8]
    8178:	17ffffbc 	b	8068 <f12+0x1068>
    817c:	52800001 	mov	w1, #0x0                   	// #0
    8180:	d2800300 	mov	x0, #0x18                  	// #24
    8184:	97fff35b 	bl	4ef0 <fwp_heap_alloc>
    8188:	aa0003f7 	mov	x23, x0
    818c:	17ffffcf 	b	80c8 <f12+0x10c8>
    8190:	72003c3f 	tst	w1, #0xffff
    8194:	54fffd81 	b.ne	8144 <f12+0x1144>  // b.any
    8198:	17ffffe7 	b	8134 <f12+0x1134>
    819c:	aa1703e0 	mov	x0, x23
    81a0:	97ffeffc 	bl	4190 <fwp_rc_forget_slot.part.0>
    81a4:	17ffffe7 	b	8140 <f12+0x1140>
    81a8:	97ffea36 	bl	2a80 <fwp_trap_overflow.constprop.0>
    81ac:	97ffe9c9 	bl	28d0 <abort@plt>

00000000000081b0 <fwp_owned_entry12>:
    81b0:	f9400000 	ldr	x0, [x0]
    81b4:	17fffb93 	b	7000 <f12>
    81b8:	d503201f 	nop
    81bc:	d503201f 	nop

00000000000081c0 <e12>:
    81c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    81c4:	910003fd 	mov	x29, sp
    81c8:	f9000bf3 	str	x19, [sp, #16]
    81cc:	f9400013 	ldr	x19, [x0]
    81d0:	aa1303e0 	mov	x0, x19
    81d4:	97fff684 	bl	5be4 <fwp_rc_share>
    81d8:	aa1303e0 	mov	x0, x19
    81dc:	97fffb89 	bl	7000 <f12>
    81e0:	aa0003f3 	mov	x19, x0
    81e4:	97fff680 	bl	5be4 <fwp_rc_share>
    81e8:	aa1303e0 	mov	x0, x19
    81ec:	f9400bf3 	ldr	x19, [sp, #16]
    81f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    81f4:	d65f03c0 	ret
    81f8:	d503201f 	nop
    81fc:	d503201f 	nop

0000000000008200 <fwp_args12>:
    8200:	7100003f 	cmp	w1, #0x0
    8204:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8208:	54000041 	b.ne	8210 <fwp_args12+0x10>  // b.any
    820c:	d65f03c0 	ret
    8210:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8214:	91174042 	add	x2, x2, #0x5d0
    8218:	f9400001 	ldr	x1, [x0]
    821c:	f949d843 	ldr	x3, [x2, #5040]
    8220:	f949ec40 	ldr	x0, [x2, #5080]
    8224:	cb030021 	sub	x1, x1, x3
    8228:	eb00403f 	cmp	x1, x0, lsl #16
    822c:	54ffff02 	b.cs	820c <fwp_args12+0xc>  // b.hs, b.nlast
    8230:	d350fc20 	lsr	x0, x1, #16
    8234:	f949fc44 	ldr	x4, [x2, #5112]
    8238:	8b000800 	add	x0, x0, x0, lsl #2
    823c:	d37df002 	lsl	x2, x0, #3
    8240:	8b020083 	add	x3, x4, x2
    8244:	f9401060 	ldr	x0, [x3, #32]
    8248:	b4fffe20 	cbz	x0, 820c <fwp_args12+0xc>
    824c:	38626882 	ldrb	w2, [x4, x2]
    8250:	7100085f 	cmp	w2, #0x2
    8254:	54000220 	b.eq	8298 <fwp_args12+0x98>  // b.none
    8258:	7100045f 	cmp	w2, #0x1
    825c:	54fffd81 	b.ne	820c <fwp_args12+0xc>  // b.any
    8260:	29430864 	ldp	w4, w2, [x3, #24]
    8264:	92403c21 	and	x1, x1, #0xffff
    8268:	9b047c21 	mul	x1, x1, x4
    826c:	d360fc21 	lsr	x1, x1, #32
    8270:	eb02003f 	cmp	x1, x2
    8274:	54fffcc2 	b.cs	820c <fwp_args12+0xc>  // b.hs, b.nlast
    8278:	8b010000 	add	x0, x0, x1
    827c:	39400001 	ldrb	w1, [x0]
    8280:	34fffc61 	cbz	w1, 820c <fwp_args12+0xc>
    8284:	7103f43f 	cmp	w1, #0xfd
    8288:	540000e8 	b.hi	82a4 <fwp_args12+0xa4>  // b.pmore
    828c:	11000421 	add	w1, w1, #0x1
    8290:	39000001 	strb	w1, [x0]
    8294:	d65f03c0 	ret
    8298:	72003c3f 	tst	w1, #0xffff
    829c:	54ffff00 	b.eq	827c <fwp_args12+0x7c>  // b.none
    82a0:	d65f03c0 	ret
    82a4:	17fff0d0 	b	45e4 <fwp_rc_wide_dup>
    82a8:	d503201f 	nop
    82ac:	d503201f 	nop

00000000000082b0 <fwp_args23>:
    82b0:	7100003f 	cmp	w1, #0x0
    82b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    82b8:	54000041 	b.ne	82c0 <fwp_args23+0x10>  // b.any
    82bc:	d65f03c0 	ret
    82c0:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    82c4:	91174042 	add	x2, x2, #0x5d0
    82c8:	f9400001 	ldr	x1, [x0]
    82cc:	f949d843 	ldr	x3, [x2, #5040]
    82d0:	f949ec40 	ldr	x0, [x2, #5080]
    82d4:	cb030021 	sub	x1, x1, x3
    82d8:	eb00403f 	cmp	x1, x0, lsl #16
    82dc:	54ffff02 	b.cs	82bc <fwp_args23+0xc>  // b.hs, b.nlast
    82e0:	d350fc20 	lsr	x0, x1, #16
    82e4:	f949fc44 	ldr	x4, [x2, #5112]
    82e8:	8b000800 	add	x0, x0, x0, lsl #2
    82ec:	d37df002 	lsl	x2, x0, #3
    82f0:	8b020083 	add	x3, x4, x2
    82f4:	f9401060 	ldr	x0, [x3, #32]
    82f8:	b4fffe20 	cbz	x0, 82bc <fwp_args23+0xc>
    82fc:	38626882 	ldrb	w2, [x4, x2]
    8300:	7100085f 	cmp	w2, #0x2
    8304:	54000220 	b.eq	8348 <fwp_args23+0x98>  // b.none
    8308:	7100045f 	cmp	w2, #0x1
    830c:	54fffd81 	b.ne	82bc <fwp_args23+0xc>  // b.any
    8310:	29430864 	ldp	w4, w2, [x3, #24]
    8314:	92403c21 	and	x1, x1, #0xffff
    8318:	9b047c21 	mul	x1, x1, x4
    831c:	d360fc21 	lsr	x1, x1, #32
    8320:	eb02003f 	cmp	x1, x2
    8324:	54fffcc2 	b.cs	82bc <fwp_args23+0xc>  // b.hs, b.nlast
    8328:	8b010000 	add	x0, x0, x1
    832c:	39400001 	ldrb	w1, [x0]
    8330:	34fffc61 	cbz	w1, 82bc <fwp_args23+0xc>
    8334:	7103f43f 	cmp	w1, #0xfd
    8338:	540000e8 	b.hi	8354 <fwp_args23+0xa4>  // b.pmore
    833c:	11000421 	add	w1, w1, #0x1
    8340:	39000001 	strb	w1, [x0]
    8344:	d65f03c0 	ret
    8348:	72003c3f 	tst	w1, #0xffff
    834c:	54ffff00 	b.eq	832c <fwp_args23+0x7c>  // b.none
    8350:	d65f03c0 	ret
    8354:	17fff0a4 	b	45e4 <fwp_rc_wide_dup>
    8358:	d503201f 	nop
    835c:	d503201f 	nop

0000000000008360 <fwp_caps12>:
    8360:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8364:	910003fd 	mov	x29, sp
    8368:	f9000bf3 	str	x19, [sp, #16]
    836c:	aa0003f3 	mov	x19, x0
    8370:	b9400400 	ldr	w0, [x0, #4]
    8374:	340004a0 	cbz	w0, 8408 <fwp_caps12+0xa8>
    8378:	f9400660 	ldr	x0, [x19, #8]
    837c:	350004e1 	cbnz	w1, 8418 <fwp_caps12+0xb8>
    8380:	97fff685 	bl	5d94 <fwp_drop0>
    8384:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8388:	91174042 	add	x2, x2, #0x5d0
    838c:	f949d840 	ldr	x0, [x2, #5040]
    8390:	f949ec41 	ldr	x1, [x2, #5080]
    8394:	cb000260 	sub	x0, x19, x0
    8398:	eb01401f 	cmp	x0, x1, lsl #16
    839c:	54000382 	b.cs	840c <fwp_caps12+0xac>  // b.hs, b.nlast
    83a0:	d350fc01 	lsr	x1, x0, #16
    83a4:	f949fc44 	ldr	x4, [x2, #5112]
    83a8:	8b010821 	add	x1, x1, x1, lsl #2
    83ac:	d37df021 	lsl	x1, x1, #3
    83b0:	8b010083 	add	x3, x4, x1
    83b4:	f9401062 	ldr	x2, [x3, #32]
    83b8:	b40002a2 	cbz	x2, 840c <fwp_caps12+0xac>
    83bc:	38616881 	ldrb	w1, [x4, x1]
    83c0:	7100083f 	cmp	w1, #0x2
    83c4:	540006c0 	b.eq	849c <fwp_caps12+0x13c>  // b.none
    83c8:	7100043f 	cmp	w1, #0x1
    83cc:	54000201 	b.ne	840c <fwp_caps12+0xac>  // b.any
    83d0:	29430464 	ldp	w4, w1, [x3, #24]
    83d4:	92403c00 	and	x0, x0, #0xffff
    83d8:	9b047c00 	mul	x0, x0, x4
    83dc:	d360fc00 	lsr	x0, x0, #32
    83e0:	eb01001f 	cmp	x0, x1
    83e4:	54000142 	b.cs	840c <fwp_caps12+0xac>  // b.hs, b.nlast
    83e8:	8b000042 	add	x2, x2, x0
    83ec:	39400040 	ldrb	w0, [x2]
    83f0:	7100041f 	cmp	w0, #0x1
    83f4:	540000c1 	b.ne	840c <fwp_caps12+0xac>  // b.any
    83f8:	aa1303e0 	mov	x0, x19
    83fc:	f9400bf3 	ldr	x19, [sp, #16]
    8400:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8404:	17ffefff 	b	4400 <fwp_mem_free>
    8408:	34fffbe1 	cbz	w1, 8384 <fwp_caps12+0x24>
    840c:	f9400bf3 	ldr	x19, [sp, #16]
    8410:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8414:	d65f03c0 	ret
    8418:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    841c:	91174042 	add	x2, x2, #0x5d0
    8420:	f949d843 	ldr	x3, [x2, #5040]
    8424:	f949ec41 	ldr	x1, [x2, #5080]
    8428:	cb030000 	sub	x0, x0, x3
    842c:	eb01401f 	cmp	x0, x1, lsl #16
    8430:	54fffee2 	b.cs	840c <fwp_caps12+0xac>  // b.hs, b.nlast
    8434:	d350fc01 	lsr	x1, x0, #16
    8438:	f949fc44 	ldr	x4, [x2, #5112]
    843c:	8b010821 	add	x1, x1, x1, lsl #2
    8440:	d37df021 	lsl	x1, x1, #3
    8444:	8b010083 	add	x3, x4, x1
    8448:	f9401062 	ldr	x2, [x3, #32]
    844c:	b4fffe02 	cbz	x2, 840c <fwp_caps12+0xac>
    8450:	38616881 	ldrb	w1, [x4, x1]
    8454:	7100083f 	cmp	w1, #0x2
    8458:	54000280 	b.eq	84a8 <fwp_caps12+0x148>  // b.none
    845c:	7100043f 	cmp	w1, #0x1
    8460:	54fffd61 	b.ne	840c <fwp_caps12+0xac>  // b.any
    8464:	92403c01 	and	x1, x0, #0xffff
    8468:	29430064 	ldp	w4, w0, [x3, #24]
    846c:	9b047c21 	mul	x1, x1, x4
    8470:	d360fc21 	lsr	x1, x1, #32
    8474:	eb00003f 	cmp	x1, x0
    8478:	54fffca2 	b.cs	840c <fwp_caps12+0xac>  // b.hs, b.nlast
    847c:	8b010042 	add	x2, x2, x1
    8480:	39400040 	ldrb	w0, [x2]
    8484:	34fffc40 	cbz	w0, 840c <fwp_caps12+0xac>
    8488:	7103f41f 	cmp	w0, #0xfd
    848c:	54000148 	b.hi	84b4 <fwp_caps12+0x154>  // b.pmore
    8490:	11000400 	add	w0, w0, #0x1
    8494:	39000040 	strb	w0, [x2]
    8498:	17ffffdd 	b	840c <fwp_caps12+0xac>
    849c:	72003c1f 	tst	w0, #0xffff
    84a0:	54fffb61 	b.ne	840c <fwp_caps12+0xac>  // b.any
    84a4:	17ffffd2 	b	83ec <fwp_caps12+0x8c>
    84a8:	72003c1f 	tst	w0, #0xffff
    84ac:	54fffb01 	b.ne	840c <fwp_caps12+0xac>  // b.any
    84b0:	17fffff4 	b	8480 <fwp_caps12+0x120>
    84b4:	f9400bf3 	ldr	x19, [sp, #16]
    84b8:	aa0203e0 	mov	x0, x2
    84bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    84c0:	17fff049 	b	45e4 <fwp_rc_wide_dup>

00000000000084c4 <fwp_drop2>:
    84c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    84c8:	910003fd 	mov	x29, sp
    84cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    84d0:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    84d4:	911742d5 	add	x21, x22, #0x5d0
    84d8:	a90153f3 	stp	x19, x20, [sp, #16]
    84dc:	aa0003f3 	mov	x19, x0
    84e0:	f949daa1 	ldr	x1, [x21, #5040]
    84e4:	f949eea0 	ldr	x0, [x21, #5080]
    84e8:	cb010261 	sub	x1, x19, x1
    84ec:	eb00403f 	cmp	x1, x0, lsl #16
    84f0:	54000382 	b.cs	8560 <fwp_drop2+0x9c>  // b.hs, b.nlast
    84f4:	d350fc22 	lsr	x2, x1, #16
    84f8:	f949fea3 	ldr	x3, [x21, #5112]
    84fc:	8b020842 	add	x2, x2, x2, lsl #2
    8500:	d37df042 	lsl	x2, x2, #3
    8504:	8b020060 	add	x0, x3, x2
    8508:	f9401014 	ldr	x20, [x0, #32]
    850c:	b40002b4 	cbz	x20, 8560 <fwp_drop2+0x9c>
    8510:	38626862 	ldrb	w2, [x3, x2]
    8514:	7100085f 	cmp	w2, #0x2
    8518:	540002c0 	b.eq	8570 <fwp_drop2+0xac>  // b.none
    851c:	7100045f 	cmp	w2, #0x1
    8520:	54000201 	b.ne	8560 <fwp_drop2+0x9c>  // b.any
    8524:	29430002 	ldp	w2, w0, [x0, #24]
    8528:	92403c21 	and	x1, x1, #0xffff
    852c:	9b027c21 	mul	x1, x1, x2
    8530:	d360fc21 	lsr	x1, x1, #32
    8534:	eb00003f 	cmp	x1, x0
    8538:	54000142 	b.cs	8560 <fwp_drop2+0x9c>  // b.hs, b.nlast
    853c:	8b010294 	add	x20, x20, x1
    8540:	39400280 	ldrb	w0, [x20]
    8544:	340000e0 	cbz	w0, 8560 <fwp_drop2+0x9c>
    8548:	7100041f 	cmp	w0, #0x1
    854c:	540001e0 	b.eq	8588 <fwp_drop2+0xc4>  // b.none
    8550:	7103fc1f 	cmp	w0, #0xff
    8554:	540007e0 	b.eq	8650 <fwp_drop2+0x18c>  // b.none
    8558:	51000400 	sub	w0, w0, #0x1
    855c:	39000280 	strb	w0, [x20]
    8560:	a94153f3 	ldp	x19, x20, [sp, #16]
    8564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8568:	a8c37bfd 	ldp	x29, x30, [sp], #48
    856c:	d65f03c0 	ret
    8570:	72003c3f 	tst	w1, #0xffff
    8574:	54fffe60 	b.eq	8540 <fwp_drop2+0x7c>  // b.none
    8578:	a94153f3 	ldp	x19, x20, [sp, #16]
    857c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8580:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8584:	d65f03c0 	ret
    8588:	911742c2 	add	x2, x22, #0x5d0
    858c:	f9400660 	ldr	x0, [x19, #8]
    8590:	f949d841 	ldr	x1, [x2, #5040]
    8594:	f949ec42 	ldr	x2, [x2, #5080]
    8598:	cb010001 	sub	x1, x0, x1
    859c:	eb02403f 	cmp	x1, x2, lsl #16
    85a0:	54000382 	b.cs	8610 <fwp_drop2+0x14c>  // b.hs, b.nlast
    85a4:	d350fc22 	lsr	x2, x1, #16
    85a8:	8b020842 	add	x2, x2, x2, lsl #2
    85ac:	d37df042 	lsl	x2, x2, #3
    85b0:	8b020064 	add	x4, x3, x2
    85b4:	f9401094 	ldr	x20, [x4, #32]
    85b8:	b40002d4 	cbz	x20, 8610 <fwp_drop2+0x14c>
    85bc:	38626862 	ldrb	w2, [x3, x2]
    85c0:	7100085f 	cmp	w2, #0x2
    85c4:	54000400 	b.eq	8644 <fwp_drop2+0x180>  // b.none
    85c8:	7100045f 	cmp	w2, #0x1
    85cc:	54000221 	b.ne	8610 <fwp_drop2+0x14c>  // b.any
    85d0:	29430883 	ldp	w3, w2, [x4, #24]
    85d4:	92403c21 	and	x1, x1, #0xffff
    85d8:	9b037c21 	mul	x1, x1, x3
    85dc:	d360fc21 	lsr	x1, x1, #32
    85e0:	eb02003f 	cmp	x1, x2
    85e4:	54000162 	b.cs	8610 <fwp_drop2+0x14c>  // b.hs, b.nlast
    85e8:	8b010294 	add	x20, x20, x1
    85ec:	39400281 	ldrb	w1, [x20]
    85f0:	34000101 	cbz	w1, 8610 <fwp_drop2+0x14c>
    85f4:	7100043f 	cmp	w1, #0x1
    85f8:	54000220 	b.eq	863c <fwp_drop2+0x178>  // b.none
    85fc:	7103fc3f 	cmp	w1, #0xff
    8600:	54000660 	b.eq	86cc <fwp_drop2+0x208>  // b.none
    8604:	51000421 	sub	w1, w1, #0x1
    8608:	39000281 	strb	w1, [x20]
    860c:	d503201f 	nop
    8610:	f9400a74 	ldr	x20, [x19, #16]
    8614:	aa1303e0 	mov	x0, x19
    8618:	97fff597 	bl	5c74 <fwp_rc_free_arr>
    861c:	911742c0 	add	x0, x22, #0x5d0
    8620:	f949d801 	ldr	x1, [x0, #5040]
    8624:	f949ec00 	ldr	x0, [x0, #5080]
    8628:	cb010281 	sub	x1, x20, x1
    862c:	eb00403f 	cmp	x1, x0, lsl #16
    8630:	54fff982 	b.cs	8560 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8634:	aa1403f3 	mov	x19, x20
    8638:	17ffffaf 	b	84f4 <fwp_drop2+0x30>
    863c:	97fff58e 	bl	5c74 <fwp_rc_free_arr>
    8640:	17fffff4 	b	8610 <fwp_drop2+0x14c>
    8644:	72003c3f 	tst	w1, #0xffff
    8648:	54fffe41 	b.ne	8610 <fwp_drop2+0x14c>  // b.any
    864c:	17ffffe8 	b	85ec <fwp_drop2+0x128>
    8650:	ca544681 	eor	x1, x20, x20, lsr #17
    8654:	911742c0 	add	x0, x22, #0x5d0
    8658:	ca412421 	eor	x1, x1, x1, lsr #9
    865c:	92401c21 	and	x1, x1, #0xff
    8660:	910a2422 	add	x2, x1, #0x289
    8664:	8b010c01 	add	x1, x0, x1, lsl #3
    8668:	8b020c02 	add	x2, x0, x2, lsl #3
    866c:	f94a2420 	ldr	x0, [x1, #5192]
    8670:	b50000a0 	cbnz	x0, 8684 <fwp_drop2+0x1c0>
    8674:	14000013 	b	86c0 <fwp_drop2+0x1fc>
    8678:	91004002 	add	x2, x0, #0x10
    867c:	f9400800 	ldr	x0, [x0, #16]
    8680:	b4000200 	cbz	x0, 86c0 <fwp_drop2+0x1fc>
    8684:	f9400001 	ldr	x1, [x0]
    8688:	eb14003f 	cmp	x1, x20
    868c:	54ffff61 	b.ne	8678 <fwp_drop2+0x1b4>  // b.any
    8690:	f9400041 	ldr	x1, [x2]
    8694:	f9400420 	ldr	x0, [x1, #8]
    8698:	d1000400 	sub	x0, x0, #0x1
    869c:	f9000420 	str	x0, [x1, #8]
    86a0:	f103f81f 	cmp	x0, #0xfe
    86a4:	54fff5e1 	b.ne	8560 <fwp_drop2+0x9c>  // b.any
    86a8:	39400280 	ldrb	w0, [x20]
    86ac:	7103fc1f 	cmp	w0, #0xff
    86b0:	54000460 	b.eq	873c <fwp_drop2+0x278>  // b.none
    86b4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    86b8:	39000280 	strb	w0, [x20]
    86bc:	17ffffa9 	b	8560 <fwp_drop2+0x9c>
    86c0:	f0000000 	adrp	x0, b000 <__modti3+0x1b0>
    86c4:	910fa000 	add	x0, x0, #0x3e8
    86c8:	97ffee92 	bl	4110 <fwp_trap>
    86cc:	ca544680 	eor	x0, x20, x20, lsr #17
    86d0:	911742c1 	add	x1, x22, #0x5d0
    86d4:	ca402400 	eor	x0, x0, x0, lsr #9
    86d8:	92401c00 	and	x0, x0, #0xff
    86dc:	910a2402 	add	x2, x0, #0x289
    86e0:	8b000c20 	add	x0, x1, x0, lsl #3
    86e4:	8b020c22 	add	x2, x1, x2, lsl #3
    86e8:	f94a2400 	ldr	x0, [x0, #5192]
    86ec:	b50000a0 	cbnz	x0, 8700 <fwp_drop2+0x23c>
    86f0:	17fffff4 	b	86c0 <fwp_drop2+0x1fc>
    86f4:	91004002 	add	x2, x0, #0x10
    86f8:	f9400800 	ldr	x0, [x0, #16]
    86fc:	b4fffe20 	cbz	x0, 86c0 <fwp_drop2+0x1fc>
    8700:	f9400001 	ldr	x1, [x0]
    8704:	eb14003f 	cmp	x1, x20
    8708:	54ffff61 	b.ne	86f4 <fwp_drop2+0x230>  // b.any
    870c:	f9400041 	ldr	x1, [x2]
    8710:	f9400420 	ldr	x0, [x1, #8]
    8714:	d1000400 	sub	x0, x0, #0x1
    8718:	f9000420 	str	x0, [x1, #8]
    871c:	f103f81f 	cmp	x0, #0xfe
    8720:	54fff781 	b.ne	8610 <fwp_drop2+0x14c>  // b.any
    8724:	39400280 	ldrb	w0, [x20]
    8728:	7103fc1f 	cmp	w0, #0xff
    872c:	540000e0 	b.eq	8748 <fwp_drop2+0x284>  // b.none
    8730:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8734:	39000280 	strb	w0, [x20]
    8738:	17ffffb6 	b	8610 <fwp_drop2+0x14c>
    873c:	aa1403e0 	mov	x0, x20
    8740:	97ffee94 	bl	4190 <fwp_rc_forget_slot.part.0>
    8744:	17ffffdc 	b	86b4 <fwp_drop2+0x1f0>
    8748:	aa1403e0 	mov	x0, x20
    874c:	97ffee91 	bl	4190 <fwp_rc_forget_slot.part.0>
    8750:	17fffff8 	b	8730 <fwp_drop2+0x26c>

0000000000008754 <fwp_arg_drop23>:
    8754:	7100003f 	cmp	w1, #0x0
    8758:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    875c:	54000041 	b.ne	8764 <fwp_arg_drop23+0x10>  // b.any
    8760:	d65f03c0 	ret
    8764:	f9400000 	ldr	x0, [x0]
    8768:	17ffff57 	b	84c4 <fwp_drop2>
    876c:	d503201f 	nop

0000000000008770 <fwp_caps23>:
    8770:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8774:	910003fd 	mov	x29, sp
    8778:	f9000bf3 	str	x19, [sp, #16]
    877c:	aa0003f3 	mov	x19, x0
    8780:	b9400400 	ldr	w0, [x0, #4]
    8784:	340004a0 	cbz	w0, 8818 <fwp_caps23+0xa8>
    8788:	f9400660 	ldr	x0, [x19, #8]
    878c:	350004e1 	cbnz	w1, 8828 <fwp_caps23+0xb8>
    8790:	97ffff4d 	bl	84c4 <fwp_drop2>
    8794:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8798:	91174042 	add	x2, x2, #0x5d0
    879c:	f949d840 	ldr	x0, [x2, #5040]
    87a0:	f949ec41 	ldr	x1, [x2, #5080]
    87a4:	cb000260 	sub	x0, x19, x0
    87a8:	eb01401f 	cmp	x0, x1, lsl #16
    87ac:	54000382 	b.cs	881c <fwp_caps23+0xac>  // b.hs, b.nlast
    87b0:	d350fc01 	lsr	x1, x0, #16
    87b4:	f949fc44 	ldr	x4, [x2, #5112]
    87b8:	8b010821 	add	x1, x1, x1, lsl #2
    87bc:	d37df021 	lsl	x1, x1, #3
    87c0:	8b010083 	add	x3, x4, x1
    87c4:	f9401062 	ldr	x2, [x3, #32]
    87c8:	b40002a2 	cbz	x2, 881c <fwp_caps23+0xac>
    87cc:	38616881 	ldrb	w1, [x4, x1]
    87d0:	7100083f 	cmp	w1, #0x2
    87d4:	540006c0 	b.eq	88ac <fwp_caps23+0x13c>  // b.none
    87d8:	7100043f 	cmp	w1, #0x1
    87dc:	54000201 	b.ne	881c <fwp_caps23+0xac>  // b.any
    87e0:	29430464 	ldp	w4, w1, [x3, #24]
    87e4:	92403c00 	and	x0, x0, #0xffff
    87e8:	9b047c00 	mul	x0, x0, x4
    87ec:	d360fc00 	lsr	x0, x0, #32
    87f0:	eb01001f 	cmp	x0, x1
    87f4:	54000142 	b.cs	881c <fwp_caps23+0xac>  // b.hs, b.nlast
    87f8:	8b000042 	add	x2, x2, x0
    87fc:	39400040 	ldrb	w0, [x2]
    8800:	7100041f 	cmp	w0, #0x1
    8804:	540000c1 	b.ne	881c <fwp_caps23+0xac>  // b.any
    8808:	aa1303e0 	mov	x0, x19
    880c:	f9400bf3 	ldr	x19, [sp, #16]
    8810:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8814:	17ffeefb 	b	4400 <fwp_mem_free>
    8818:	34fffbe1 	cbz	w1, 8794 <fwp_caps23+0x24>
    881c:	f9400bf3 	ldr	x19, [sp, #16]
    8820:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8824:	d65f03c0 	ret
    8828:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    882c:	91174042 	add	x2, x2, #0x5d0
    8830:	f949d843 	ldr	x3, [x2, #5040]
    8834:	f949ec41 	ldr	x1, [x2, #5080]
    8838:	cb030000 	sub	x0, x0, x3
    883c:	eb01401f 	cmp	x0, x1, lsl #16
    8840:	54fffee2 	b.cs	881c <fwp_caps23+0xac>  // b.hs, b.nlast
    8844:	d350fc01 	lsr	x1, x0, #16
    8848:	f949fc44 	ldr	x4, [x2, #5112]
    884c:	8b010821 	add	x1, x1, x1, lsl #2
    8850:	d37df021 	lsl	x1, x1, #3
    8854:	8b010083 	add	x3, x4, x1
    8858:	f9401062 	ldr	x2, [x3, #32]
    885c:	b4fffe02 	cbz	x2, 881c <fwp_caps23+0xac>
    8860:	38616881 	ldrb	w1, [x4, x1]
    8864:	7100083f 	cmp	w1, #0x2
    8868:	54000280 	b.eq	88b8 <fwp_caps23+0x148>  // b.none
    886c:	7100043f 	cmp	w1, #0x1
    8870:	54fffd61 	b.ne	881c <fwp_caps23+0xac>  // b.any
    8874:	92403c01 	and	x1, x0, #0xffff
    8878:	29430064 	ldp	w4, w0, [x3, #24]
    887c:	9b047c21 	mul	x1, x1, x4
    8880:	d360fc21 	lsr	x1, x1, #32
    8884:	eb00003f 	cmp	x1, x0
    8888:	54fffca2 	b.cs	881c <fwp_caps23+0xac>  // b.hs, b.nlast
    888c:	8b010042 	add	x2, x2, x1
    8890:	39400040 	ldrb	w0, [x2]
    8894:	34fffc40 	cbz	w0, 881c <fwp_caps23+0xac>
    8898:	7103f41f 	cmp	w0, #0xfd
    889c:	54000148 	b.hi	88c4 <fwp_caps23+0x154>  // b.pmore
    88a0:	11000400 	add	w0, w0, #0x1
    88a4:	39000040 	strb	w0, [x2]
    88a8:	17ffffdd 	b	881c <fwp_caps23+0xac>
    88ac:	72003c1f 	tst	w0, #0xffff
    88b0:	54fffb61 	b.ne	881c <fwp_caps23+0xac>  // b.any
    88b4:	17ffffd2 	b	87fc <fwp_caps23+0x8c>
    88b8:	72003c1f 	tst	w0, #0xffff
    88bc:	54fffb01 	b.ne	881c <fwp_caps23+0xac>  // b.any
    88c0:	17fffff4 	b	8890 <fwp_caps23+0x120>
    88c4:	f9400bf3 	ldr	x19, [sp, #16]
    88c8:	aa0203e0 	mov	x0, x2
    88cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    88d0:	17ffef45 	b	45e4 <fwp_rc_wide_dup>

00000000000088d4 <f23>:
    88d4:	d10203ff 	sub	sp, sp, #0x80
    88d8:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    88dc:	f947f421 	ldr	x1, [x1, #4072]
    88e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    88e4:	910083fd 	add	x29, sp, #0x20
    88e8:	a9045bf5 	stp	x21, x22, [sp, #64]
    88ec:	b0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    88f0:	911742a3 	add	x3, x21, #0x5d0
    88f4:	a90353f3 	stp	x19, x20, [sp, #48]
    88f8:	aa0003f6 	mov	x22, x0
    88fc:	a90563f7 	stp	x23, x24, [sp, #80]
    8900:	a9066bf9 	stp	x25, x26, [sp, #96]
    8904:	f949ec62 	ldr	x2, [x3, #5080]
    8908:	f9400024 	ldr	x4, [x1]
    890c:	f9000fe4 	str	x4, [sp, #24]
    8910:	d2800004 	mov	x4, #0x0                   	// #0
    8914:	f949d861 	ldr	x1, [x3, #5040]
    8918:	d370bc42 	lsl	x2, x2, #16
    891c:	b4001800 	cbz	x0, 8c1c <f23+0x348>
    8920:	f9400817 	ldr	x23, [x0, #16]
    8924:	cb0102e1 	sub	x1, x23, x1
    8928:	eb02003f 	cmp	x1, x2
    892c:	54000362 	b.cs	8998 <f23+0xc4>  // b.hs, b.nlast
    8930:	f949fc60 	ldr	x0, [x3, #5112]
    8934:	d350fc22 	lsr	x2, x1, #16
    8938:	8b020842 	add	x2, x2, x2, lsl #2
    893c:	8b020c02 	add	x2, x0, x2, lsl #3
    8940:	f9401040 	ldr	x0, [x2, #32]
    8944:	b40002a0 	cbz	x0, 8998 <f23+0xc4>
    8948:	39400043 	ldrb	w3, [x2]
    894c:	7100087f 	cmp	w3, #0x2
    8950:	54001540 	b.eq	8bf8 <f23+0x324>  // b.none
    8954:	7100047f 	cmp	w3, #0x1
    8958:	540001c1 	b.ne	8990 <f23+0xbc>  // b.any
    895c:	29430843 	ldp	w3, w2, [x2, #24]
    8960:	92403c21 	and	x1, x1, #0xffff
    8964:	9b037c21 	mul	x1, x1, x3
    8968:	d360fc21 	lsr	x1, x1, #32
    896c:	eb02003f 	cmp	x1, x2
    8970:	54000102 	b.cs	8990 <f23+0xbc>  // b.hs, b.nlast
    8974:	8b010000 	add	x0, x0, x1
    8978:	39400001 	ldrb	w1, [x0]
    897c:	340000a1 	cbz	w1, 8990 <f23+0xbc>
    8980:	7103f43f 	cmp	w1, #0xfd
    8984:	540017e8 	b.hi	8c80 <f23+0x3ac>  // b.pmore
    8988:	11000421 	add	w1, w1, #0x1
    898c:	39000001 	strb	w1, [x0]
    8990:	d2800002 	mov	x2, #0x0                   	// #0
    8994:	b40000d6 	cbz	x22, 89ac <f23+0xd8>
    8998:	aa1603e1 	mov	x1, x22
    899c:	d2800002 	mov	x2, #0x0                   	// #0
    89a0:	f9400821 	ldr	x1, [x1, #16]
    89a4:	91000442 	add	x2, x2, #0x1
    89a8:	b5ffffc1 	cbnz	x1, 89a0 <f23+0xcc>
    89ac:	b40013f7 	cbz	x23, 8c28 <f23+0x354>
    89b0:	aa1703e1 	mov	x1, x23
    89b4:	d2800003 	mov	x3, #0x0                   	// #0
    89b8:	f9400821 	ldr	x1, [x1, #16]
    89bc:	91000463 	add	x3, x3, #0x1
    89c0:	b5ffffc1 	cbnz	x1, 89b8 <f23+0xe4>
    89c4:	eb02007f 	cmp	x3, x2
    89c8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    89cc:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    89d0:	eb00027f 	cmp	x19, x0
    89d4:	540010a8 	b.hi	8be8 <f23+0x314>  // b.pmore
    89d8:	d37ffa74 	lsl	x20, x19, #1
    89dc:	52800041 	mov	w1, #0x2                   	// #2
    89e0:	91000680 	add	x0, x20, #0x1
    89e4:	d37df000 	lsl	x0, x0, #3
    89e8:	97fff142 	bl	4ef0 <fwp_heap_alloc>
    89ec:	aa0003f8 	mov	x24, x0
    89f0:	911742a1 	add	x1, x21, #0x5d0
    89f4:	aa0103e0 	mov	x0, x1
    89f8:	f9000314 	str	x20, [x24]
    89fc:	f949d821 	ldr	x1, [x1, #5040]
    8a00:	f949ec00 	ldr	x0, [x0, #5080]
    8a04:	cb010301 	sub	x1, x24, x1
    8a08:	eb00403f 	cmp	x1, x0, lsl #16
    8a0c:	54000342 	b.cs	8a74 <f23+0x1a0>  // b.hs, b.nlast
    8a10:	911742a2 	add	x2, x21, #0x5d0
    8a14:	d350fc20 	lsr	x0, x1, #16
    8a18:	8b000800 	add	x0, x0, x0, lsl #2
    8a1c:	f949fc43 	ldr	x3, [x2, #5112]
    8a20:	d37df002 	lsl	x2, x0, #3
    8a24:	8b020060 	add	x0, x3, x2
    8a28:	f9401014 	ldr	x20, [x0, #32]
    8a2c:	b4000254 	cbz	x20, 8a74 <f23+0x1a0>
    8a30:	38626862 	ldrb	w2, [x3, x2]
    8a34:	7100085f 	cmp	w2, #0x2
    8a38:	54000ec0 	b.eq	8c10 <f23+0x33c>  // b.none
    8a3c:	7100045f 	cmp	w2, #0x1
    8a40:	540001a1 	b.ne	8a74 <f23+0x1a0>  // b.any
    8a44:	29430002 	ldp	w2, w0, [x0, #24]
    8a48:	92403c21 	and	x1, x1, #0xffff
    8a4c:	9b027c21 	mul	x1, x1, x2
    8a50:	d360fc21 	lsr	x1, x1, #32
    8a54:	eb00003f 	cmp	x1, x0
    8a58:	540000e2 	b.cs	8a74 <f23+0x1a0>  // b.hs, b.nlast
    8a5c:	8b010294 	add	x20, x20, x1
    8a60:	39400280 	ldrb	w0, [x20]
    8a64:	7103fc1f 	cmp	w0, #0xff
    8a68:	54001100 	b.eq	8c88 <f23+0x3b4>  // b.none
    8a6c:	52800020 	mov	w0, #0x1                   	// #1
    8a70:	39000280 	strb	w0, [x20]
    8a74:	b4000253 	cbz	x19, 8abc <f23+0x1e8>
    8a78:	8b131313 	add	x19, x24, x19, lsl #4
    8a7c:	aa1803f4 	mov	x20, x24
    8a80:	aa1603fa 	mov	x26, x22
    8a84:	aa1703f9 	mov	x25, x23
    8a88:	f9400723 	ldr	x3, [x25, #8]
    8a8c:	f9400742 	ldr	x2, [x26, #8]
    8a90:	f9400861 	ldr	x1, [x3, #16]
    8a94:	f9400840 	ldr	x0, [x2, #16]
    8a98:	fd400461 	ldr	d1, [x3, #8]
    8a9c:	fd400440 	ldr	d0, [x2, #8]
    8aa0:	97fff2d0 	bl	55e0 <w107>
    8aa4:	f9000680 	str	x0, [x20, #8]
    8aa8:	f8010e81 	str	x1, [x20, #16]!
    8aac:	f9400b39 	ldr	x25, [x25, #16]
    8ab0:	f9400b5a 	ldr	x26, [x26, #16]
    8ab4:	eb14027f 	cmp	x19, x20
    8ab8:	54fffe81 	b.ne	8a88 <f23+0x1b4>  // b.any
    8abc:	aa1703e0 	mov	x0, x23
    8ac0:	97fffe81 	bl	84c4 <fwp_drop2>
    8ac4:	aa1603e0 	mov	x0, x22
    8ac8:	97fffe7f 	bl	84c4 <fwp_drop2>
    8acc:	f9400316 	ldr	x22, [x24]
    8ad0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8ad4:	b4000236 	cbz	x22, 8b18 <f23+0x244>
    8ad8:	fd003be8 	str	d8, [sp, #112]
    8adc:	2f00e408 	movi	d8, #0x0
    8ae0:	91002319 	add	x25, x24, #0x8
    8ae4:	91004317 	add	x23, x24, #0x10
    8ae8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    8aec:	d2800013 	mov	x19, #0x0                   	// #0
    8af0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8af4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    8af8:	91000a73 	add	x19, x19, #0x2
    8afc:	1e602908 	fadd	d8, d8, d0
    8b00:	97fff260 	bl	5480 <f128.constprop.0>
    8b04:	aa0003f4 	mov	x20, x0
    8b08:	eb1302df 	cmp	x22, x19
    8b0c:	54ffff28 	b.hi	8af0 <f23+0x21c>  // b.pmore
    8b10:	9e660116 	fmov	x22, d8
    8b14:	fd403be8 	ldr	d8, [sp, #112]
    8b18:	911742b5 	add	x21, x21, #0x5d0
    8b1c:	aa1803e0 	mov	x0, x24
    8b20:	97fff890 	bl	6d60 <fwp_drop4>
    8b24:	a900d3f6 	stp	x22, x20, [sp, #8]
    8b28:	910023e1 	add	x1, sp, #0x8
    8b2c:	52800000 	mov	w0, #0x0                   	// #0
    8b30:	97fff3e5 	bl	5ac4 <fwp_data.part.0.constprop.0>
    8b34:	f949daa1 	ldr	x1, [x21, #5040]
    8b38:	aa0003f3 	mov	x19, x0
    8b3c:	f949eea0 	ldr	x0, [x21, #5080]
    8b40:	cb010261 	sub	x1, x19, x1
    8b44:	eb00403f 	cmp	x1, x0, lsl #16
    8b48:	54000322 	b.cs	8bac <f23+0x2d8>  // b.hs, b.nlast
    8b4c:	d350fc22 	lsr	x2, x1, #16
    8b50:	f949fea3 	ldr	x3, [x21, #5112]
    8b54:	8b020842 	add	x2, x2, x2, lsl #2
    8b58:	d37df042 	lsl	x2, x2, #3
    8b5c:	8b020060 	add	x0, x3, x2
    8b60:	f9401014 	ldr	x20, [x0, #32]
    8b64:	b4000254 	cbz	x20, 8bac <f23+0x2d8>
    8b68:	38626862 	ldrb	w2, [x3, x2]
    8b6c:	7100085f 	cmp	w2, #0x2
    8b70:	540004a0 	b.eq	8c04 <f23+0x330>  // b.none
    8b74:	7100045f 	cmp	w2, #0x1
    8b78:	540001a1 	b.ne	8bac <f23+0x2d8>  // b.any
    8b7c:	29430002 	ldp	w2, w0, [x0, #24]
    8b80:	92403c21 	and	x1, x1, #0xffff
    8b84:	9b027c21 	mul	x1, x1, x2
    8b88:	d360fc21 	lsr	x1, x1, #32
    8b8c:	eb00003f 	cmp	x1, x0
    8b90:	540000e2 	b.cs	8bac <f23+0x2d8>  // b.hs, b.nlast
    8b94:	8b010294 	add	x20, x20, x1
    8b98:	39400280 	ldrb	w0, [x20]
    8b9c:	7103fc1f 	cmp	w0, #0xff
    8ba0:	540007a0 	b.eq	8c94 <f23+0x3c0>  // b.none
    8ba4:	52800020 	mov	w0, #0x1                   	// #1
    8ba8:	39000280 	strb	w0, [x20]
    8bac:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8bb0:	f947f400 	ldr	x0, [x0, #4072]
    8bb4:	f9400fe2 	ldr	x2, [sp, #24]
    8bb8:	f9400001 	ldr	x1, [x0]
    8bbc:	eb010042 	subs	x2, x2, x1
    8bc0:	d2800001 	mov	x1, #0x0                   	// #0
    8bc4:	54000721 	b.ne	8ca8 <f23+0x3d4>  // b.any
    8bc8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8bcc:	aa1303e0 	mov	x0, x19
    8bd0:	a94353f3 	ldp	x19, x20, [sp, #48]
    8bd4:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8bd8:	a94563f7 	ldp	x23, x24, [sp, #80]
    8bdc:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8be0:	910203ff 	add	sp, sp, #0x80
    8be4:	d65f03c0 	ret
    8be8:	f0000000 	adrp	x0, b000 <__modti3+0x1b0>
    8bec:	911c4000 	add	x0, x0, #0x710
    8bf0:	fd003be8 	str	d8, [sp, #112]
    8bf4:	97ffed47 	bl	4110 <fwp_trap>
    8bf8:	72003c3f 	tst	w1, #0xffff
    8bfc:	54ffeca1 	b.ne	8990 <f23+0xbc>  // b.any
    8c00:	17ffff5e 	b	8978 <f23+0xa4>
    8c04:	72003c3f 	tst	w1, #0xffff
    8c08:	54fffd21 	b.ne	8bac <f23+0x2d8>  // b.any
    8c0c:	17ffffe3 	b	8b98 <f23+0x2c4>
    8c10:	72003c3f 	tst	w1, #0xffff
    8c14:	54fff301 	b.ne	8a74 <f23+0x1a0>  // b.any
    8c18:	17ffff92 	b	8a60 <f23+0x18c>
    8c1c:	cb0103e1 	neg	x1, x1
    8c20:	eb02003f 	cmp	x1, x2
    8c24:	540001e3 	b.cc	8c60 <f23+0x38c>  // b.lo, b.ul, b.last
    8c28:	52800041 	mov	w1, #0x2                   	// #2
    8c2c:	d2800100 	mov	x0, #0x8                   	// #8
    8c30:	97fff0b0 	bl	4ef0 <fwp_heap_alloc>
    8c34:	aa0003f8 	mov	x24, x0
    8c38:	911742a0 	add	x0, x21, #0x5d0
    8c3c:	f900031f 	str	xzr, [x24]
    8c40:	f949d801 	ldr	x1, [x0, #5040]
    8c44:	f949ec00 	ldr	x0, [x0, #5080]
    8c48:	cb010301 	sub	x1, x24, x1
    8c4c:	eb00403f 	cmp	x1, x0, lsl #16
    8c50:	54000282 	b.cs	8ca0 <f23+0x3cc>  // b.hs, b.nlast
    8c54:	d2800013 	mov	x19, #0x0                   	// #0
    8c58:	d2800017 	mov	x23, #0x0                   	// #0
    8c5c:	17ffff6d 	b	8a10 <f23+0x13c>
    8c60:	f949fc62 	ldr	x2, [x3, #5112]
    8c64:	d350fc20 	lsr	x0, x1, #16
    8c68:	8b000800 	add	x0, x0, x0, lsl #2
    8c6c:	8b000c42 	add	x2, x2, x0, lsl #3
    8c70:	f9401040 	ldr	x0, [x2, #32]
    8c74:	b4fffda0 	cbz	x0, 8c28 <f23+0x354>
    8c78:	d2800017 	mov	x23, #0x0                   	// #0
    8c7c:	17ffff33 	b	8948 <f23+0x74>
    8c80:	97ffee59 	bl	45e4 <fwp_rc_wide_dup>
    8c84:	17ffff43 	b	8990 <f23+0xbc>
    8c88:	aa1403e0 	mov	x0, x20
    8c8c:	97ffed41 	bl	4190 <fwp_rc_forget_slot.part.0>
    8c90:	17ffff77 	b	8a6c <f23+0x198>
    8c94:	aa1403e0 	mov	x0, x20
    8c98:	97ffed3e 	bl	4190 <fwp_rc_forget_slot.part.0>
    8c9c:	17ffffc2 	b	8ba4 <f23+0x2d0>
    8ca0:	d2800017 	mov	x23, #0x0                   	// #0
    8ca4:	17ffff86 	b	8abc <f23+0x1e8>
    8ca8:	fd003be8 	str	d8, [sp, #112]
    8cac:	97ffe6f5 	bl	2880 <__stack_chk_fail@plt>

0000000000008cb0 <fwp_owned_entry23>:
    8cb0:	f9400000 	ldr	x0, [x0]
    8cb4:	17ffff08 	b	88d4 <f23>
    8cb8:	d503201f 	nop
    8cbc:	d503201f 	nop

0000000000008cc0 <e23>:
    8cc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8cc4:	910003fd 	mov	x29, sp
    8cc8:	f9000bf3 	str	x19, [sp, #16]
    8ccc:	f9400013 	ldr	x19, [x0]
    8cd0:	aa1303e0 	mov	x0, x19
    8cd4:	97fff3c4 	bl	5be4 <fwp_rc_share>
    8cd8:	aa1303e0 	mov	x0, x19
    8cdc:	97fffefe 	bl	88d4 <f23>
    8ce0:	aa0003f3 	mov	x19, x0
    8ce4:	97fff3c0 	bl	5be4 <fwp_rc_share>
    8ce8:	aa1303e0 	mov	x0, x19
    8cec:	f9400bf3 	ldr	x19, [sp, #16]
    8cf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8cf4:	d65f03c0 	ret
    8cf8:	d503201f 	nop
    8cfc:	d503201f 	nop

0000000000008d00 <fwp_write>:
    8d00:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8d04:	910003fd 	mov	x29, sp
    8d08:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    8d0c:	f947f484 	ldr	x4, [x4, #4072]
    8d10:	a90153f3 	stp	x19, x20, [sp, #16]
    8d14:	d10943ff 	sub	sp, sp, #0x250
    8d18:	b9400045 	ldr	w5, [x2]
    8d1c:	aa0003f4 	mov	x20, x0
    8d20:	f9400080 	ldr	x0, [x4]
    8d24:	f90127e0 	str	x0, [sp, #584]
    8d28:	d2800000 	mov	x0, #0x0                   	// #0
    8d2c:	710064bf 	cmp	w5, #0x19
    8d30:	54000408 	b.hi	8db0 <fwp_write+0xb0>  // b.pmore
    8d34:	f0000000 	adrp	x0, b000 <__modti3+0x1b0>
    8d38:	aa0103f3 	mov	x19, x1
    8d3c:	913d0000 	add	x0, x0, #0xf40
    8d40:	f9013bf5 	str	x21, [sp, #624]
    8d44:	f9013ff6 	str	x22, [sp, #632]
    8d48:	f90153fb 	str	x27, [sp, #672]
    8d4c:	f90157fc 	str	x28, [sp, #680]
    8d50:	aa0203fc 	mov	x28, x2
    8d54:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8d58:	10000061 	adr	x1, 8d64 <fwp_write+0x64>
    8d5c:	8b20a820 	add	x0, x1, w0, sxth #2
    8d60:	d61f0000 	br	x0
    8d64:	910123e0 	add	x0, sp, #0x48
    8d68:	aa1303e5 	mov	x5, x19
    8d6c:	f0000004 	adrp	x4, b000 <__modti3+0x1b0>
    8d70:	aa0003f3 	mov	x19, x0
    8d74:	911e4084 	add	x4, x4, #0x790
    8d78:	d2804003 	mov	x3, #0x200                 	// #512
    8d7c:	aa0303e1 	mov	x1, x3
    8d80:	52800042 	mov	w2, #0x2                   	// #2
    8d84:	97ffe69b 	bl	27f0 <__snprintf_chk@plt>
    8d88:	aa1303e0 	mov	x0, x19
    8d8c:	97ffe661 	bl	2710 <strlen@plt>
    8d90:	aa1303e1 	mov	x1, x19
    8d94:	aa0003e2 	mov	x2, x0
    8d98:	aa1403e0 	mov	x0, x20
    8d9c:	97ffe9fd 	bl	3590 <buf_put>
    8da0:	f9413bf5 	ldr	x21, [sp, #624]
    8da4:	f9413ff6 	ldr	x22, [sp, #632]
    8da8:	f94153fb 	ldr	x27, [sp, #672]
    8dac:	f94157fc 	ldr	x28, [sp, #680]
    8db0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8db4:	f947f400 	ldr	x0, [x0, #4072]
    8db8:	f94127e2 	ldr	x2, [sp, #584]
    8dbc:	f9400001 	ldr	x1, [x0]
    8dc0:	eb010042 	subs	x2, x2, x1
    8dc4:	d2800001 	mov	x1, #0x0                   	// #0
    8dc8:	540077c1 	b.ne	9cc0 <fwp_write+0xfc0>  // b.any
    8dcc:	910943ff 	add	sp, sp, #0x250
    8dd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    8dd4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8dd8:	d65f03c0 	ret
    8ddc:	910123e0 	add	x0, sp, #0x48
    8de0:	aa1303e5 	mov	x5, x19
    8de4:	f0000004 	adrp	x4, b000 <__modti3+0x1b0>
    8de8:	aa0003f3 	mov	x19, x0
    8dec:	911e2084 	add	x4, x4, #0x788
    8df0:	d2804003 	mov	x3, #0x200                 	// #512
    8df4:	17ffffe2 	b	8d7c <fwp_write+0x7c>
    8df8:	71004cbf 	cmp	w5, #0x13
    8dfc:	f0000000 	adrp	x0, b000 <__modti3+0x1b0>
    8e00:	f0000001 	adrp	x1, b000 <__modti3+0x1b0>
    8e04:	911de000 	add	x0, x0, #0x778
    8e08:	911e0021 	add	x1, x1, #0x780
    8e0c:	d2800082 	mov	x2, #0x4                   	// #4
    8e10:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8e14:	aa1403e0 	mov	x0, x20
    8e18:	f90143f7 	str	x23, [sp, #640]
    8e1c:	d2800016 	mov	x22, #0x0                   	// #0
    8e20:	f90147f8 	str	x24, [sp, #648]
    8e24:	97ffe9db 	bl	3590 <buf_put>
    8e28:	f9400260 	ldr	x0, [x19]
    8e2c:	f0000017 	adrp	x23, b000 <__modti3+0x1b0>
    8e30:	d2800015 	mov	x21, #0x0                   	// #0
    8e34:	912002f7 	add	x23, x23, #0x800
    8e38:	b40047a0 	cbz	x0, 972c <fwp_write+0xa2c>
    8e3c:	b9400380 	ldr	w0, [x28]
    8e40:	52800003 	mov	w3, #0x0                   	// #0
    8e44:	f9401f82 	ldr	x2, [x28, #56]
    8e48:	71004c1f 	cmp	w0, #0x13
    8e4c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8e50:	aa1403e0 	mov	x0, x20
    8e54:	8b010e61 	add	x1, x19, x1, lsl #3
    8e58:	f9400421 	ldr	x1, [x1, #8]
    8e5c:	97ffffa9 	bl	8d00 <fwp_write>
    8e60:	b9400380 	ldr	w0, [x28]
    8e64:	7100481f 	cmp	w0, #0x12
    8e68:	54004b40 	b.eq	97d0 <fwp_write+0xad0>  // b.none
    8e6c:	f9400260 	ldr	x0, [x19]
    8e70:	910006b5 	add	x21, x21, #0x1
    8e74:	91000ad6 	add	x22, x22, #0x2
    8e78:	eb15001f 	cmp	x0, x21
    8e7c:	54004589 	b.ls	972c <fwp_write+0xa2c>  // b.plast
    8e80:	aa1703e1 	mov	x1, x23
    8e84:	aa1403e0 	mov	x0, x20
    8e88:	d2800042 	mov	x2, #0x2                   	// #2
    8e8c:	97ffe9c1 	bl	3590 <buf_put>
    8e90:	17ffffeb 	b	8e3c <fwp_write+0x13c>
    8e94:	f0000001 	adrp	x1, b000 <__modti3+0x1b0>
    8e98:	911ee021 	add	x1, x1, #0x7b8
    8e9c:	d28000c2 	mov	x2, #0x6                   	// #6
    8ea0:	aa1403e0 	mov	x0, x20
    8ea4:	91004273 	add	x19, x19, #0x10
    8ea8:	97ffe9ba 	bl	3590 <buf_put>
    8eac:	aa1303e0 	mov	x0, x19
    8eb0:	97ffe618 	bl	2710 <strlen@plt>
    8eb4:	aa1303e1 	mov	x1, x19
    8eb8:	aa0003e2 	mov	x2, x0
    8ebc:	aa1403e0 	mov	x0, x20
    8ec0:	97ffe9b4 	bl	3590 <buf_put>
    8ec4:	528007c3 	mov	w3, #0x3e                  	// #62
    8ec8:	aa1403e0 	mov	x0, x20
    8ecc:	91001fe1 	add	x1, sp, #0x7
    8ed0:	d2800022 	mov	x2, #0x1                   	// #1
    8ed4:	39001fe3 	strb	w3, [sp, #7]
    8ed8:	17ffffb1 	b	8d9c <fwp_write+0x9c>
    8edc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ee0:	f947f400 	ldr	x0, [x0, #4072]
    8ee4:	f94127e2 	ldr	x2, [sp, #584]
    8ee8:	f9400001 	ldr	x1, [x0]
    8eec:	eb010042 	subs	x2, x2, x1
    8ef0:	d2800001 	mov	x1, #0x0                   	// #0
    8ef4:	540034e1 	b.ne	9590 <fwp_write+0x890>  // b.any
    8ef8:	f9413bf5 	ldr	x21, [sp, #624]
    8efc:	f0000001 	adrp	x1, b000 <__modti3+0x1b0>
    8f00:	f9413ff6 	ldr	x22, [sp, #632]
    8f04:	aa1403e0 	mov	x0, x20
    8f08:	911e6021 	add	x1, x1, #0x798
    8f0c:	d2800142 	mov	x2, #0xa                   	// #10
    8f10:	f94153fb 	ldr	x27, [sp, #672]
    8f14:	f94157fc 	ldr	x28, [sp, #680]
    8f18:	910943ff 	add	sp, sp, #0x250
    8f1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8f20:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8f24:	17ffe99b 	b	3590 <buf_put>
    8f28:	f9400456 	ldr	x22, [x2, #8]
    8f2c:	f90143f7 	str	x23, [sp, #640]
    8f30:	f90147f8 	str	x24, [sp, #648]
    8f34:	b4005b16 	cbz	x22, 9a94 <fwp_write+0xd94>
    8f38:	aa1603e0 	mov	x0, x22
    8f3c:	f0000001 	adrp	x1, b000 <__modti3+0x1b0>
    8f40:	91206021 	add	x1, x1, #0x818
    8f44:	97ffe66f 	bl	2900 <strcmp@plt>
    8f48:	2a0003f5 	mov	w21, w0
    8f4c:	34005fe0 	cbz	w0, 9b48 <fwp_write+0xe48>
    8f50:	aa1603e0 	mov	x0, x22
    8f54:	97ffe5ef 	bl	2710 <strlen@plt>
    8f58:	aa1603e1 	mov	x1, x22
    8f5c:	aa0003e2 	mov	x2, x0
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	97ffe98b 	bl	3590 <buf_put>
    8f68:	52800403 	mov	w3, #0x20                  	// #32
    8f6c:	91001ff5 	add	x21, sp, #0x7
    8f70:	aa1503e1 	mov	x1, x21
    8f74:	aa1403e0 	mov	x0, x20
    8f78:	d2800022 	mov	x2, #0x1                   	// #1
    8f7c:	39001fe3 	strb	w3, [sp, #7]
    8f80:	97ffe984 	bl	3590 <buf_put>
    8f84:	52800f63 	mov	w3, #0x7b                  	// #123
    8f88:	aa1403e0 	mov	x0, x20
    8f8c:	aa1503e1 	mov	x1, x21
    8f90:	d2800022 	mov	x2, #0x1                   	// #1
    8f94:	39001fe3 	strb	w3, [sp, #7]
    8f98:	97ffe97e 	bl	3590 <buf_put>
    8f9c:	b9401380 	ldr	w0, [x28, #16]
    8fa0:	52800018 	mov	w24, #0x0                   	// #0
    8fa4:	7100001f 	cmp	w0, #0x0
    8fa8:	54003aad 	b.le	96fc <fwp_write+0x9fc>
    8fac:	f9014bf9 	str	x25, [sp, #656]
    8fb0:	f0000019 	adrp	x25, b000 <__modti3+0x1b0>
    8fb4:	91210339 	add	x25, x25, #0x840
    8fb8:	f9014ffa 	str	x26, [sp, #664]
    8fbc:	f000001a 	adrp	x26, b000 <__modti3+0x1b0>
    8fc0:	9120035a 	add	x26, x26, #0x800
    8fc4:	91002276 	add	x22, x19, #0x8
    8fc8:	d2800013 	mov	x19, #0x0                   	// #0
    8fcc:	b5003e93 	cbnz	x19, 979c <fwp_write+0xa9c>
    8fd0:	d37df277 	lsl	x23, x19, #3
    8fd4:	34003cb8 	cbz	w24, 9768 <fwp_write+0xa68>
    8fd8:	f9401382 	ldr	x2, [x28, #32]
    8fdc:	aa1403e0 	mov	x0, x20
    8fe0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8fe4:	52800003 	mov	w3, #0x0                   	// #0
    8fe8:	f8776842 	ldr	x2, [x2, x23]
    8fec:	91000673 	add	x19, x19, #0x1
    8ff0:	97ffff44 	bl	8d00 <fwp_write>
    8ff4:	b9401380 	ldr	w0, [x28, #16]
    8ff8:	6b13001f 	cmp	w0, w19
    8ffc:	54fffe8c 	b.gt	8fcc <fwp_write+0x2cc>
    9000:	f9414bf9 	ldr	x25, [sp, #656]
    9004:	f9414ffa 	ldr	x26, [sp, #664]
    9008:	340037b8 	cbz	w24, 96fc <fwp_write+0x9fc>
    900c:	52800523 	mov	w3, #0x29                  	// #41
    9010:	aa1503e1 	mov	x1, x21
    9014:	aa1403e0 	mov	x0, x20
    9018:	d2800022 	mov	x2, #0x1                   	// #1
    901c:	39001fe3 	strb	w3, [sp, #7]
    9020:	97ffe95c 	bl	3590 <buf_put>
    9024:	f9413bf5 	ldr	x21, [sp, #624]
    9028:	f9413ff6 	ldr	x22, [sp, #632]
    902c:	f94143f7 	ldr	x23, [sp, #640]
    9030:	f94147f8 	ldr	x24, [sp, #648]
    9034:	f94153fb 	ldr	x27, [sp, #672]
    9038:	f94157fc 	ldr	x28, [sp, #680]
    903c:	17ffff5d 	b	8db0 <fwp_write+0xb0>
    9040:	b9404855 	ldr	w21, [x2, #72]
    9044:	aa1403e0 	mov	x0, x20
    9048:	93407eb6 	sxtw	x22, w21
    904c:	91000ac1 	add	x1, x22, #0x2
    9050:	97ffe91d 	bl	34c4 <buf_grow>
    9054:	a9400281 	ldp	x1, x0, [x20]
    9058:	528e8603 	mov	w3, #0x7430                	// #29744
    905c:	78206823 	strh	w3, [x1, x0]
    9060:	8b000022 	add	x2, x1, x0
    9064:	710002bf 	cmp	w21, #0x0
    9068:	540036cd 	b.le	9740 <fwp_write+0xa40>
    906c:	110006a3 	add	w3, w21, #0x1
    9070:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    9074:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    9078:	91000449 	add	x9, x2, #0x1
    907c:	8b23c043 	add	x3, x2, w3, sxtw
    9080:	f28aaac6 	movk	x6, #0x5556
    9084:	f2955568 	movk	x8, #0xaaab
    9088:	1400000d 	b	90bc <fwp_write+0x3bc>
    908c:	d2800021 	mov	x1, #0x1                   	// #1
    9090:	528005a5 	mov	w5, #0x2d                  	// #45
    9094:	f100001f 	cmp	x0, #0x0
    9098:	9b467e60 	smulh	x0, x19, x6
    909c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    90a0:	381ff465 	strb	w5, [x3], #-1
    90a4:	cb040000 	sub	x0, x0, x4
    90a8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    90ac:	cb020000 	sub	x0, x0, x2
    90b0:	8b010013 	add	x19, x0, x1
    90b4:	eb03013f 	cmp	x9, x3
    90b8:	54003440 	b.eq	9740 <fwp_write+0xa40>  // b.none
    90bc:	9b467e60 	smulh	x0, x19, x6
    90c0:	937ffe64 	asr	x4, x19, #63
    90c4:	52800605 	mov	w5, #0x30                  	// #48
    90c8:	cb040000 	sub	x0, x0, x4
    90cc:	8b000400 	add	x0, x0, x0, lsl #1
    90d0:	cb000260 	sub	x0, x19, x0
    90d4:	91000c01 	add	x1, x0, #0x3
    90d8:	9bc87c22 	umulh	x2, x1, x8
    90dc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    90e0:	8b4204e2 	add	x2, x7, x2, lsr #1
    90e4:	eb020021 	subs	x1, x1, x2
    90e8:	54fffd60 	b.eq	9094 <fwp_write+0x394>  // b.none
    90ec:	f100043f 	cmp	x1, #0x1
    90f0:	54fffce1 	b.ne	908c <fwp_write+0x38c>  // b.any
    90f4:	d2800001 	mov	x1, #0x0                   	// #0
    90f8:	52800565 	mov	w5, #0x2b                  	// #43
    90fc:	17ffffe6 	b	9094 <fwp_write+0x394>
    9100:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9104:	f947f400 	ldr	x0, [x0, #4072]
    9108:	f94127e2 	ldr	x2, [sp, #584]
    910c:	f9400001 	ldr	x1, [x0]
    9110:	eb010042 	subs	x2, x2, x1
    9114:	d2800001 	mov	x1, #0x0                   	// #0
    9118:	540023c1 	b.ne	9590 <fwp_write+0x890>  // b.any
    911c:	f9413bf5 	ldr	x21, [sp, #624]
    9120:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9124:	f9413ff6 	ldr	x22, [sp, #632]
    9128:	aa1403e0 	mov	x0, x20
    912c:	911ea021 	add	x1, x1, #0x7a8
    9130:	d2800102 	mov	x2, #0x8                   	// #8
    9134:	17ffff77 	b	8f10 <fwp_write+0x210>
    9138:	aa1403e0 	mov	x0, x20
    913c:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9140:	d28000c2 	mov	x2, #0x6                   	// #6
    9144:	91202021 	add	x1, x1, #0x808
    9148:	97ffe912 	bl	3590 <buf_put>
    914c:	d2800015 	mov	x21, #0x0                   	// #0
    9150:	f9400263 	ldr	x3, [x19]
    9154:	f240f87f 	tst	x3, #0x7fffffffffffffff
    9158:	54002c60 	b.eq	96e4 <fwp_write+0x9e4>  // b.none
    915c:	f9401f82 	ldr	x2, [x28, #56]
    9160:	f90143f7 	str	x23, [sp, #640]
    9164:	f90147f8 	str	x24, [sp, #648]
    9168:	d2800857 	mov	x23, #0x42                  	// #66
    916c:	f9014bf9 	str	x25, [sp, #656]
    9170:	d0000016 	adrp	x22, b000 <__modti3+0x1b0>
    9174:	f9014ffa 	str	x26, [sp, #664]
    9178:	912002d6 	add	x22, x22, #0x800
    917c:	d2800038 	mov	x24, #0x1                   	// #1
    9180:	f2a18017 	movk	x23, #0xc00, lsl #16
    9184:	d2809099 	mov	x25, #0x484                 	// #1156
    9188:	b40004a2 	cbz	x2, 921c <fwp_write+0x51c>
    918c:	b9400040 	ldr	w0, [x2]
    9190:	7100701f 	cmp	w0, #0x1c
    9194:	540042c0 	b.eq	99ec <fwp_write+0xcec>  // b.none
    9198:	71006c1f 	cmp	w0, #0x1b
    919c:	54000408 	b.hi	921c <fwp_write+0x51c>  // b.pmore
    91a0:	9ac02301 	lsl	x1, x24, x0
    91a4:	ea17003f 	tst	x1, x23
    91a8:	540036a1 	b.ne	987c <fwp_write+0xb7c>  // b.any
    91ac:	ea19003f 	tst	x1, x25
    91b0:	54003521 	b.ne	9854 <fwp_write+0xb54>  // b.any
    91b4:	d2800424 	mov	x4, #0x21                  	// #33
    91b8:	ea04003f 	tst	x1, x4
    91bc:	54000300 	b.eq	921c <fwp_write+0x51c>  // b.none
    91c0:	b7f849c3 	tbnz	x3, #63, 9af8 <fwp_write+0xdf8>
    91c4:	91002261 	add	x1, x19, #0x8
    91c8:	8b150021 	add	x1, x1, x21
    91cc:	39400021 	ldrb	w1, [x1]
    91d0:	7100001f 	cmp	w0, #0x0
    91d4:	93401c23 	sxtb	x3, w1
    91d8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    91dc:	d503201f 	nop
    91e0:	aa1403e0 	mov	x0, x20
    91e4:	52800003 	mov	w3, #0x0                   	// #0
    91e8:	97fffec6 	bl	8d00 <fwp_write>
    91ec:	910006b5 	add	x21, x21, #0x1
    91f0:	f9400260 	ldr	x0, [x19]
    91f4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    91f8:	eb0002bf 	cmp	x21, x0
    91fc:	540026c2 	b.cs	96d4 <fwp_write+0x9d4>  // b.hs, b.nlast
    9200:	d2800042 	mov	x2, #0x2                   	// #2
    9204:	aa1603e1 	mov	x1, x22
    9208:	aa1403e0 	mov	x0, x20
    920c:	97ffe8e1 	bl	3590 <buf_put>
    9210:	f9401f82 	ldr	x2, [x28, #56]
    9214:	f9400263 	ldr	x3, [x19]
    9218:	b5fffba2 	cbnz	x2, 918c <fwp_write+0x48c>
    921c:	d37df2a0 	lsl	x0, x21, #3
    9220:	b7f83f03 	tbnz	x3, #63, 9a00 <fwp_write+0xd00>
    9224:	91002261 	add	x1, x19, #0x8
    9228:	8b000020 	add	x0, x1, x0
    922c:	f9400001 	ldr	x1, [x0]
    9230:	17ffffec 	b	91e0 <fwp_write+0x4e0>
    9234:	a9400e62 	ldp	x2, x3, [x19]
    9238:	b7f83ca3 	tbnz	x3, #63, 99cc <fwp_write+0xccc>
    923c:	910123f5 	add	x21, sp, #0x48
    9240:	aa1503e0 	mov	x0, x21
    9244:	97ffe6f7 	bl	2e20 <fwp_fmt_u128>
    9248:	aa1503e0 	mov	x0, x21
    924c:	97ffe531 	bl	2710 <strlen@plt>
    9250:	aa1503e1 	mov	x1, x21
    9254:	aa0003e2 	mov	x2, x0
    9258:	17fffed0 	b	8d98 <fwp_write+0x98>
    925c:	fd015be8 	str	d8, [sp, #688]
    9260:	1e270268 	fmov	s8, w19
    9264:	fd015fe9 	str	d9, [sp, #696]
    9268:	1e282100 	fcmp	s8, s8
    926c:	54004d26 	b.vs	9c10 <fwp_write+0xf10>
    9270:	1e20c101 	fabs	s1, s8
    9274:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    9278:	1e270000 	fmov	s0, w0
    927c:	1e202020 	fcmp	s1, s0
    9280:	54002c0d 	b.le	9800 <fwp_write+0xb00>
    9284:	1e202118 	fcmpe	s8, #0.0
    9288:	d0000002 	adrp	x2, b000 <__modti3+0x1b0>
    928c:	910b2042 	add	x2, x2, #0x2c8
    9290:	910123f5 	add	x21, sp, #0x48
    9294:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9298:	911d6021 	add	x1, x1, #0x758
    929c:	aa1503e0 	mov	x0, x21
    92a0:	9a81c041 	csel	x1, x2, x1, gt
    92a4:	97ffe5c7 	bl	29c0 <strcpy@plt>
    92a8:	aa1503e0 	mov	x0, x21
    92ac:	97ffe519 	bl	2710 <strlen@plt>
    92b0:	aa1503e1 	mov	x1, x21
    92b4:	aa0003e2 	mov	x2, x0
    92b8:	aa1403e0 	mov	x0, x20
    92bc:	97ffe8b5 	bl	3590 <buf_put>
    92c0:	f9413bf5 	ldr	x21, [sp, #624]
    92c4:	f9413ff6 	ldr	x22, [sp, #632]
    92c8:	f94153fb 	ldr	x27, [sp, #672]
    92cc:	f94157fc 	ldr	x28, [sp, #680]
    92d0:	fd415be8 	ldr	d8, [sp, #688]
    92d4:	fd415fe9 	ldr	d9, [sp, #696]
    92d8:	17fffeb6 	b	8db0 <fwp_write+0xb0>
    92dc:	f9400276 	ldr	x22, [x19]
    92e0:	34002e03 	cbz	w3, 98a0 <fwp_write+0xba0>
    92e4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    92e8:	f947f400 	ldr	x0, [x0, #4072]
    92ec:	f94127e2 	ldr	x2, [sp, #584]
    92f0:	f9400001 	ldr	x1, [x0]
    92f4:	eb010042 	subs	x2, x2, x1
    92f8:	d2800001 	mov	x1, #0x0                   	// #0
    92fc:	540014a1 	b.ne	9590 <fwp_write+0x890>  // b.any
    9300:	aa1603e2 	mov	x2, x22
    9304:	91002261 	add	x1, x19, #0x8
    9308:	f9413bf5 	ldr	x21, [sp, #624]
    930c:	aa1403e0 	mov	x0, x20
    9310:	f9413ff6 	ldr	x22, [sp, #632]
    9314:	17fffeff 	b	8f10 <fwp_write+0x210>
    9318:	fd015be8 	str	d8, [sp, #688]
    931c:	9e670268 	fmov	d8, x19
    9320:	fd015fe9 	str	d9, [sp, #696]
    9324:	1e682100 	fcmp	d8, d8
    9328:	54004746 	b.vs	9c10 <fwp_write+0xf10>
    932c:	1e60c101 	fabs	d1, d8
    9330:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    9334:	9e670000 	fmov	d0, x0
    9338:	910123f5 	add	x21, sp, #0x48
    933c:	52800033 	mov	w19, #0x1                   	// #1
    9340:	1e602020 	fcmp	d1, d0
    9344:	540001ad 	b.le	9378 <fwp_write+0x678>
    9348:	1e602118 	fcmpe	d8, #0.0
    934c:	d0000002 	adrp	x2, b000 <__modti3+0x1b0>
    9350:	910b2042 	add	x2, x2, #0x2c8
    9354:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9358:	911d6021 	add	x1, x1, #0x758
    935c:	aa1503e0 	mov	x0, x21
    9360:	9a81c041 	csel	x1, x2, x1, gt
    9364:	97ffe597 	bl	29c0 <strcpy@plt>
    9368:	17ffffd0 	b	92a8 <fwp_write+0x5a8>
    936c:	11000673 	add	w19, w19, #0x1
    9370:	71004a7f 	cmp	w19, #0x12
    9374:	54003860 	b.eq	9a80 <fwp_write+0xd80>  // b.none
    9378:	1e604100 	fmov	d0, d8
    937c:	2a1303e1 	mov	w1, w19
    9380:	aa1503e0 	mov	x0, x21
    9384:	97ffe91f 	bl	3800 <fwp_format_g.constprop.0>
    9388:	aa1503e0 	mov	x0, x21
    938c:	d2800001 	mov	x1, #0x0                   	// #0
    9390:	97ffe4f4 	bl	2760 <strtod@plt>
    9394:	1e602100 	fcmp	d8, d0
    9398:	54fffea1 	b.ne	936c <fwp_write+0x66c>  // b.any
    939c:	aa1503e0 	mov	x0, x21
    93a0:	97ffe8f5 	bl	3774 <fwp_finish_float>
    93a4:	17ffffc1 	b	92a8 <fwp_write+0x5a8>
    93a8:	a9400e62 	ldp	x2, x3, [x19]
    93ac:	910123f3 	add	x19, sp, #0x48
    93b0:	aa1303e0 	mov	x0, x19
    93b4:	97ffe69b 	bl	2e20 <fwp_fmt_u128>
    93b8:	17fffe74 	b	8d88 <fwp_write+0x88>
    93bc:	f90143f7 	str	x23, [sp, #640]
    93c0:	f90147f8 	str	x24, [sp, #648]
    93c4:	2a1303f8 	mov	w24, w19
    93c8:	f9014bf9 	str	x25, [sp, #656]
    93cc:	f9014ffa 	str	x26, [sp, #664]
    93d0:	f13ffe7f 	cmp	x19, #0xfff
    93d4:	54000049 	b.ls	93dc <fwp_write+0x6dc>  // b.plast
    93d8:	b9400278 	ldr	w24, [x19]
    93dc:	f9400f80 	ldr	x0, [x28, #24]
    93e0:	2a1803f5 	mov	w21, w24
    93e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    93e8:	d37ef6b9 	lsl	x25, x21, #2
    93ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    93f0:	aa1603e0 	mov	x0, x22
    93f4:	97ffe4c7 	bl	2710 <strlen@plt>
    93f8:	aa1603e1 	mov	x1, x22
    93fc:	aa0003e2 	mov	x2, x0
    9400:	aa1403e0 	mov	x0, x20
    9404:	97ffe863 	bl	3590 <buf_put>
    9408:	f9401780 	ldr	x0, [x28, #40]
    940c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9410:	7100001f 	cmp	w0, #0x0
    9414:	5400068d 	b.le	94e4 <fwp_write+0x7e4>
    9418:	91002276 	add	x22, x19, #0x8
    941c:	91001ff5 	add	x21, sp, #0x7
    9420:	d280001b 	mov	x27, #0x0                   	// #0
    9424:	5280041a 	mov	w26, #0x20                  	// #32
    9428:	f9401b80 	ldr	x0, [x28, #48]
    942c:	aa1503e1 	mov	x1, x21
    9430:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9434:	d2800022 	mov	x2, #0x1                   	// #1
    9438:	f8786803 	ldr	x3, [x0, x24]
    943c:	aa1403e0 	mov	x0, x20
    9440:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9444:	39001ffa 	strb	w26, [sp, #7]
    9448:	97ffe852 	bl	3590 <buf_put>
    944c:	f13ffeff 	cmp	x23, #0xfff
    9450:	b9400261 	ldr	w1, [x19]
    9454:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9458:	7100383f 	cmp	w1, #0xe
    945c:	54000160 	b.eq	9488 <fwp_write+0x788>  // b.none
    9460:	7100403f 	cmp	w1, #0x10
    9464:	54001a60 	b.eq	97b0 <fwp_write+0xab0>  // b.none
    9468:	7100283f 	cmp	w1, #0xa
    946c:	54002aa0 	b.eq	99c0 <fwp_write+0xcc0>  // b.none
    9470:	540014ac 	b.gt	9704 <fwp_write+0xa04>
    9474:	71000c3f 	cmp	w1, #0x3
    9478:	540029ac 	b.gt	99ac <fwp_write+0xcac>
    947c:	d37ffee0 	lsr	x0, x23, #63
    9480:	37f814a1 	tbnz	w1, #31, 9714 <fwp_write+0xa14>
    9484:	d503201f 	nop
    9488:	34001460 	cbz	w0, 9714 <fwp_write+0xa14>
    948c:	52800503 	mov	w3, #0x28                  	// #40
    9490:	aa1503e1 	mov	x1, x21
    9494:	aa1403e0 	mov	x0, x20
    9498:	d2800022 	mov	x2, #0x1                   	// #1
    949c:	39001fe3 	strb	w3, [sp, #7]
    94a0:	97ffe83c 	bl	3590 <buf_put>
    94a4:	aa1303e2 	mov	x2, x19
    94a8:	aa1703e1 	mov	x1, x23
    94ac:	aa1403e0 	mov	x0, x20
    94b0:	52800003 	mov	w3, #0x0                   	// #0
    94b4:	97fffe13 	bl	8d00 <fwp_write>
    94b8:	52800523 	mov	w3, #0x29                  	// #41
    94bc:	aa1503e1 	mov	x1, x21
    94c0:	aa1403e0 	mov	x0, x20
    94c4:	d2800022 	mov	x2, #0x1                   	// #1
    94c8:	39001fe3 	strb	w3, [sp, #7]
    94cc:	97ffe831 	bl	3590 <buf_put>
    94d0:	f9401780 	ldr	x0, [x28, #40]
    94d4:	9100077b 	add	x27, x27, #0x1
    94d8:	b8796800 	ldr	w0, [x0, x25]
    94dc:	6b1b001f 	cmp	w0, w27
    94e0:	54fffa4c 	b.gt	9428 <fwp_write+0x728>
    94e4:	f9413bf5 	ldr	x21, [sp, #624]
    94e8:	f9413ff6 	ldr	x22, [sp, #632]
    94ec:	f94143f7 	ldr	x23, [sp, #640]
    94f0:	f94147f8 	ldr	x24, [sp, #648]
    94f4:	f9414bf9 	ldr	x25, [sp, #656]
    94f8:	f9414ffa 	ldr	x26, [sp, #664]
    94fc:	f94153fb 	ldr	x27, [sp, #672]
    9500:	f94157fc 	ldr	x28, [sp, #680]
    9504:	17fffe2b 	b	8db0 <fwp_write+0xb0>
    9508:	52800783 	mov	w3, #0x3c                  	// #60
    950c:	91001ff3 	add	x19, sp, #0x7
    9510:	aa1303e1 	mov	x1, x19
    9514:	d2800022 	mov	x2, #0x1                   	// #1
    9518:	aa1403e0 	mov	x0, x20
    951c:	39001fe3 	strb	w3, [sp, #7]
    9520:	97ffe81c 	bl	3590 <buf_put>
    9524:	f9400795 	ldr	x21, [x28, #8]
    9528:	aa1503e0 	mov	x0, x21
    952c:	97ffe479 	bl	2710 <strlen@plt>
    9530:	aa1503e1 	mov	x1, x21
    9534:	aa0003e2 	mov	x2, x0
    9538:	aa1403e0 	mov	x0, x20
    953c:	97ffe815 	bl	3590 <buf_put>
    9540:	528007c3 	mov	w3, #0x3e                  	// #62
    9544:	aa1303e1 	mov	x1, x19
    9548:	aa1403e0 	mov	x0, x20
    954c:	d2800022 	mov	x2, #0x1                   	// #1
    9550:	39001fe3 	strb	w3, [sp, #7]
    9554:	17fffe12 	b	8d9c <fwp_write+0x9c>
    9558:	f100067f 	cmp	x19, #0x1
    955c:	540025a0 	b.eq	9a10 <fwp_write+0xd10>  // b.none
    9560:	b100067f 	cmn	x19, #0x1
    9564:	54002bc0 	b.eq	9adc <fwp_write+0xddc>  // b.none
    9568:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    956c:	911d8021 	add	x1, x1, #0x760
    9570:	d2800022 	mov	x2, #0x1                   	// #1
    9574:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9578:	f947f400 	ldr	x0, [x0, #4072]
    957c:	f94127e4 	ldr	x4, [sp, #584]
    9580:	f9400003 	ldr	x3, [x0]
    9584:	eb030084 	subs	x4, x4, x3
    9588:	d2800003 	mov	x3, #0x0                   	// #0
    958c:	54ffebe0 	b.eq	9308 <fwp_write+0x608>  // b.none
    9590:	f90143f7 	str	x23, [sp, #640]
    9594:	f90147f8 	str	x24, [sp, #648]
    9598:	f9014bf9 	str	x25, [sp, #656]
    959c:	f9014ffa 	str	x26, [sp, #664]
    95a0:	fd015be8 	str	d8, [sp, #688]
    95a4:	fd015fe9 	str	d9, [sp, #696]
    95a8:	97ffe4b6 	bl	2880 <__stack_chk_fail@plt>
    95ac:	52800b63 	mov	w3, #0x5b                  	// #91
    95b0:	91001ff5 	add	x21, sp, #0x7
    95b4:	aa1503e1 	mov	x1, x21
    95b8:	aa1403e0 	mov	x0, x20
    95bc:	d2800022 	mov	x2, #0x1                   	// #1
    95c0:	d0000016 	adrp	x22, b000 <__modti3+0x1b0>
    95c4:	912002d6 	add	x22, x22, #0x800
    95c8:	39001fe3 	strb	w3, [sp, #7]
    95cc:	97ffe7f1 	bl	3590 <buf_put>
    95d0:	b4000273 	cbz	x19, 961c <fwp_write+0x91c>
    95d4:	f9400661 	ldr	x1, [x19, #8]
    95d8:	aa1403e0 	mov	x0, x20
    95dc:	f9401f82 	ldr	x2, [x28, #56]
    95e0:	52800003 	mov	w3, #0x0                   	// #0
    95e4:	97fffdc7 	bl	8d00 <fwp_write>
    95e8:	f9400a73 	ldr	x19, [x19, #16]
    95ec:	b4000193 	cbz	x19, 961c <fwp_write+0x91c>
    95f0:	aa1603e1 	mov	x1, x22
    95f4:	aa1403e0 	mov	x0, x20
    95f8:	d2800042 	mov	x2, #0x2                   	// #2
    95fc:	97ffe7e5 	bl	3590 <buf_put>
    9600:	f9400661 	ldr	x1, [x19, #8]
    9604:	aa1403e0 	mov	x0, x20
    9608:	f9401f82 	ldr	x2, [x28, #56]
    960c:	52800003 	mov	w3, #0x0                   	// #0
    9610:	97fffdbc 	bl	8d00 <fwp_write>
    9614:	f9400a73 	ldr	x19, [x19, #16]
    9618:	b5fffed3 	cbnz	x19, 95f0 <fwp_write+0x8f0>
    961c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9620:	aa1503e1 	mov	x1, x21
    9624:	aa1403e0 	mov	x0, x20
    9628:	d2800022 	mov	x2, #0x1                   	// #1
    962c:	39001fe3 	strb	w3, [sp, #7]
    9630:	17fffddb 	b	8d9c <fwp_write+0x9c>
    9634:	aa1403e0 	mov	x0, x20
    9638:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    963c:	d28000c2 	mov	x2, #0x6                   	// #6
    9640:	911fc021 	add	x1, x1, #0x7f0
    9644:	97ffe7d3 	bl	3590 <buf_put>
    9648:	f9400260 	ldr	x0, [x19]
    964c:	b40004c0 	cbz	x0, 96e4 <fwp_write+0x9e4>
    9650:	910123f5 	add	x21, sp, #0x48
    9654:	91002276 	add	x22, x19, #0x8
    9658:	f90143f7 	str	x23, [sp, #640]
    965c:	d2800017 	mov	x23, #0x0                   	// #0
    9660:	f90147f8 	str	x24, [sp, #648]
    9664:	d0000018 	adrp	x24, b000 <__modti3+0x1b0>
    9668:	911fe318 	add	x24, x24, #0x7f8
    966c:	f9014bf9 	str	x25, [sp, #656]
    9670:	d0000019 	adrp	x25, b000 <__modti3+0x1b0>
    9674:	91200339 	add	x25, x25, #0x800
    9678:	f9014ffa 	str	x26, [sp, #664]
    967c:	14000005 	b	9690 <fwp_write+0x990>
    9680:	aa1903e1 	mov	x1, x25
    9684:	aa1403e0 	mov	x0, x20
    9688:	d2800042 	mov	x2, #0x2                   	// #2
    968c:	97ffe7c1 	bl	3590 <buf_put>
    9690:	38776ac5 	ldrb	w5, [x22, x23]
    9694:	d2804003 	mov	x3, #0x200                 	// #512
    9698:	aa1803e4 	mov	x4, x24
    969c:	aa0303e1 	mov	x1, x3
    96a0:	52800042 	mov	w2, #0x2                   	// #2
    96a4:	aa1503e0 	mov	x0, x21
    96a8:	910006f7 	add	x23, x23, #0x1
    96ac:	97ffe451 	bl	27f0 <__snprintf_chk@plt>
    96b0:	aa1503e0 	mov	x0, x21
    96b4:	97ffe417 	bl	2710 <strlen@plt>
    96b8:	aa1503e1 	mov	x1, x21
    96bc:	aa0003e2 	mov	x2, x0
    96c0:	aa1403e0 	mov	x0, x20
    96c4:	97ffe7b3 	bl	3590 <buf_put>
    96c8:	f9400260 	ldr	x0, [x19]
    96cc:	eb17001f 	cmp	x0, x23
    96d0:	54fffd88 	b.hi	9680 <fwp_write+0x980>  // b.pmore
    96d4:	f94143f7 	ldr	x23, [sp, #640]
    96d8:	f94147f8 	ldr	x24, [sp, #648]
    96dc:	f9414bf9 	ldr	x25, [sp, #656]
    96e0:	f9414ffa 	ldr	x26, [sp, #664]
    96e4:	52800ba3 	mov	w3, #0x5d                  	// #93
    96e8:	aa1403e0 	mov	x0, x20
    96ec:	91001fe1 	add	x1, sp, #0x7
    96f0:	d2800022 	mov	x2, #0x1                   	// #1
    96f4:	39001fe3 	strb	w3, [sp, #7]
    96f8:	17fffda9 	b	8d9c <fwp_write+0x9c>
    96fc:	52800fa3 	mov	w3, #0x7d                  	// #125
    9700:	17fffe44 	b	9010 <fwp_write+0x310>
    9704:	f10002ff 	cmp	x23, #0x0
    9708:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    970c:	71002c3f 	cmp	w1, #0xb
    9710:	54ffebc0 	b.eq	9488 <fwp_write+0x788>  // b.none
    9714:	aa1303e2 	mov	x2, x19
    9718:	aa1703e1 	mov	x1, x23
    971c:	aa1403e0 	mov	x0, x20
    9720:	52800003 	mov	w3, #0x0                   	// #0
    9724:	97fffd77 	bl	8d00 <fwp_write>
    9728:	17ffff6a 	b	94d0 <fwp_write+0x7d0>
    972c:	aa1403e0 	mov	x0, x20
    9730:	91001fe1 	add	x1, sp, #0x7
    9734:	52800fa3 	mov	w3, #0x7d                  	// #125
    9738:	d2800022 	mov	x2, #0x1                   	// #1
    973c:	17fffe38 	b	901c <fwp_write+0x31c>
    9740:	a9400281 	ldp	x1, x0, [x20]
    9744:	91000800 	add	x0, x0, #0x2
    9748:	8b160000 	add	x0, x0, x22
    974c:	f9000680 	str	x0, [x20, #8]
    9750:	3820683f 	strb	wzr, [x1, x0]
    9754:	f9413bf5 	ldr	x21, [sp, #624]
    9758:	f9413ff6 	ldr	x22, [sp, #632]
    975c:	f94153fb 	ldr	x27, [sp, #672]
    9760:	f94157fc 	ldr	x28, [sp, #680]
    9764:	17fffd93 	b	8db0 <fwp_write+0xb0>
    9768:	f9400f80 	ldr	x0, [x28, #24]
    976c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9770:	aa1b03e0 	mov	x0, x27
    9774:	97ffe3e7 	bl	2710 <strlen@plt>
    9778:	aa1b03e1 	mov	x1, x27
    977c:	aa0003e2 	mov	x2, x0
    9780:	aa1403e0 	mov	x0, x20
    9784:	97ffe783 	bl	3590 <buf_put>
    9788:	aa1903e1 	mov	x1, x25
    978c:	aa1403e0 	mov	x0, x20
    9790:	d2800062 	mov	x2, #0x3                   	// #3
    9794:	97ffe77f 	bl	3590 <buf_put>
    9798:	17fffe10 	b	8fd8 <fwp_write+0x2d8>
    979c:	aa1a03e1 	mov	x1, x26
    97a0:	aa1403e0 	mov	x0, x20
    97a4:	d2800042 	mov	x2, #0x2                   	// #2
    97a8:	97ffe77a 	bl	3590 <buf_put>
    97ac:	17fffe09 	b	8fd0 <fwp_write+0x2d0>
    97b0:	f9400660 	ldr	x0, [x19, #8]
    97b4:	b4fffb00 	cbz	x0, 9714 <fwp_write+0xa14>
    97b8:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    97bc:	91206021 	add	x1, x1, #0x818
    97c0:	97ffe450 	bl	2900 <strcmp@plt>
    97c4:	7100001f 	cmp	w0, #0x0
    97c8:	1a9f07e0 	cset	w0, ne	// ne = any
    97cc:	17ffff2f 	b	9488 <fwp_write+0x788>
    97d0:	aa1403e0 	mov	x0, x20
    97d4:	d2800042 	mov	x2, #0x2                   	// #2
    97d8:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    97dc:	91204021 	add	x1, x1, #0x810
    97e0:	97ffe76c 	bl	3590 <buf_put>
    97e4:	91004261 	add	x1, x19, #0x10
    97e8:	aa1403e0 	mov	x0, x20
    97ec:	f9402382 	ldr	x2, [x28, #64]
    97f0:	52800003 	mov	w3, #0x0                   	// #0
    97f4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    97f8:	97fffd42 	bl	8d00 <fwp_write>
    97fc:	17fffd9c 	b	8e6c <fwp_write+0x16c>
    9800:	1e22c109 	fcvt	d9, s8
    9804:	910123f5 	add	x21, sp, #0x48
    9808:	52800033 	mov	w19, #0x1                   	// #1
    980c:	d503201f 	nop
    9810:	1e604120 	fmov	d0, d9
    9814:	2a1303e1 	mov	w1, w19
    9818:	aa1503e0 	mov	x0, x21
    981c:	97ffe7f9 	bl	3800 <fwp_format_g.constprop.0>
    9820:	aa1503e0 	mov	x0, x21
    9824:	d2800001 	mov	x1, #0x0                   	// #0
    9828:	97ffe442 	bl	2930 <strtof@plt>
    982c:	1e202100 	fcmp	s8, s0
    9830:	54ffdb60 	b.eq	939c <fwp_write+0x69c>  // b.none
    9834:	11000673 	add	w19, w19, #0x1
    9838:	71002a7f 	cmp	w19, #0xa
    983c:	54fffea1 	b.ne	9810 <fwp_write+0xb10>  // b.any
    9840:	1e604120 	fmov	d0, d9
    9844:	aa1503e0 	mov	x0, x21
    9848:	52800121 	mov	w1, #0x9                   	// #9
    984c:	97ffe7ed 	bl	3800 <fwp_format_g.constprop.0>
    9850:	17fffed3 	b	939c <fwp_write+0x69c>
    9854:	d37ef6a1 	lsl	x1, x21, #2
    9858:	b7f81563 	tbnz	x3, #63, 9b04 <fwp_write+0xe04>
    985c:	91002263 	add	x3, x19, #0x8
    9860:	8b010061 	add	x1, x3, x1
    9864:	b9400023 	ldr	w3, [x1]
    9868:	7100081f 	cmp	w0, #0x2
    986c:	2a0303e1 	mov	w1, w3
    9870:	93407c63 	sxtw	x3, w3
    9874:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9878:	17fffe5a 	b	91e0 <fwp_write+0x4e0>
    987c:	d37ffaa1 	lsl	x1, x21, #1
    9880:	b7f81363 	tbnz	x3, #63, 9aec <fwp_write+0xdec>
    9884:	91002263 	add	x3, x19, #0x8
    9888:	8b010061 	add	x1, x3, x1
    988c:	79400021 	ldrh	w1, [x1]
    9890:	7100041f 	cmp	w0, #0x1
    9894:	93403c23 	sxth	x3, w1
    9898:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    989c:	17fffe51 	b	91e0 <fwp_write+0x4e0>
    98a0:	52800443 	mov	w3, #0x22                  	// #34
    98a4:	91001ff5 	add	x21, sp, #0x7
    98a8:	91002273 	add	x19, x19, #0x8
    98ac:	aa1503e1 	mov	x1, x21
    98b0:	aa1403e0 	mov	x0, x20
    98b4:	d2800022 	mov	x2, #0x1                   	// #1
    98b8:	39001fe3 	strb	w3, [sp, #7]
    98bc:	f90143f7 	str	x23, [sp, #640]
    98c0:	8b160277 	add	x23, x19, x22
    98c4:	f90147f8 	str	x24, [sp, #648]
    98c8:	97ffe732 	bl	3590 <buf_put>
    98cc:	b4000696 	cbz	x22, 999c <fwp_write+0xc9c>
    98d0:	d0000018 	adrp	x24, b000 <__modti3+0x1b0>
    98d4:	911f0318 	add	x24, x24, #0x7c0
    98d8:	f9014bf9 	str	x25, [sp, #656]
    98dc:	d0000019 	adrp	x25, b000 <__modti3+0x1b0>
    98e0:	911f8339 	add	x25, x25, #0x7e0
    98e4:	f9014ffa 	str	x26, [sp, #664]
    98e8:	1400000d 	b	991c <fwp_write+0xc1c>
    98ec:	710024bf 	cmp	w5, #0x9
    98f0:	54000460 	b.eq	997c <fwp_write+0xc7c>  // b.none
    98f4:	710028bf 	cmp	w5, #0xa
    98f8:	54000a61 	b.ne	9a44 <fwp_write+0xd44>  // b.any
    98fc:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9900:	aa1403e0 	mov	x0, x20
    9904:	911f4021 	add	x1, x1, #0x7d0
    9908:	d2800042 	mov	x2, #0x2                   	// #2
    990c:	97ffe721 	bl	3590 <buf_put>
    9910:	91000673 	add	x19, x19, #0x1
    9914:	eb17027f 	cmp	x19, x23
    9918:	540003e0 	b.eq	9994 <fwp_write+0xc94>  // b.none
    991c:	39400265 	ldrb	w5, [x19]
    9920:	710034bf 	cmp	w5, #0xd
    9924:	54000180 	b.eq	9954 <fwp_write+0xc54>  // b.none
    9928:	54fffe29 	b.ls	98ec <fwp_write+0xbec>  // b.plast
    992c:	710088bf 	cmp	w5, #0x22
    9930:	540001c0 	b.eq	9968 <fwp_write+0xc68>  // b.none
    9934:	710170bf 	cmp	w5, #0x5c
    9938:	54000741 	b.ne	9a20 <fwp_write+0xd20>  // b.any
    993c:	aa1403e0 	mov	x0, x20
    9940:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9944:	d2800042 	mov	x2, #0x2                   	// #2
    9948:	911f2021 	add	x1, x1, #0x7c8
    994c:	97ffe711 	bl	3590 <buf_put>
    9950:	17fffff0 	b	9910 <fwp_write+0xc10>
    9954:	aa1903e1 	mov	x1, x25
    9958:	aa1403e0 	mov	x0, x20
    995c:	d2800042 	mov	x2, #0x2                   	// #2
    9960:	97ffe70c 	bl	3590 <buf_put>
    9964:	17ffffeb 	b	9910 <fwp_write+0xc10>
    9968:	aa1803e1 	mov	x1, x24
    996c:	aa1403e0 	mov	x0, x20
    9970:	d2800042 	mov	x2, #0x2                   	// #2
    9974:	97ffe707 	bl	3590 <buf_put>
    9978:	17ffffe6 	b	9910 <fwp_write+0xc10>
    997c:	aa1403e0 	mov	x0, x20
    9980:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9984:	d2800042 	mov	x2, #0x2                   	// #2
    9988:	911f6021 	add	x1, x1, #0x7d8
    998c:	97ffe701 	bl	3590 <buf_put>
    9990:	17ffffe0 	b	9910 <fwp_write+0xc10>
    9994:	f9414bf9 	ldr	x25, [sp, #656]
    9998:	f9414ffa 	ldr	x26, [sp, #664]
    999c:	aa1503e1 	mov	x1, x21
    99a0:	aa1403e0 	mov	x0, x20
    99a4:	52800443 	mov	w3, #0x22                  	// #34
    99a8:	17fffd9c 	b	9018 <fwp_write+0x318>
    99ac:	7100103f 	cmp	w1, #0x4
    99b0:	54ffeb21 	b.ne	9714 <fwp_write+0xa14>  // b.any
    99b4:	f94006e0 	ldr	x0, [x23, #8]
    99b8:	d37ffc00 	lsr	x0, x0, #63
    99bc:	17fffeb3 	b	9488 <fwp_write+0x788>
    99c0:	710002ff 	cmp	w23, #0x0
    99c4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    99c8:	17fffeb0 	b	9488 <fwp_write+0x788>
    99cc:	528005a1 	mov	w1, #0x2d                  	// #45
    99d0:	eb0203e2 	negs	x2, x2
    99d4:	da0303e3 	ngc	x3, x3
    99d8:	910127e0 	add	x0, sp, #0x49
    99dc:	910123f5 	add	x21, sp, #0x48
    99e0:	390123e1 	strb	w1, [sp, #72]
    99e4:	97ffe50f 	bl	2e20 <fwp_fmt_u128>
    99e8:	17fffe18 	b	9248 <fwp_write+0x548>
    99ec:	d37ceea1 	lsl	x1, x21, #4
    99f0:	b7f810a3 	tbnz	x3, #63, 9c04 <fwp_write+0xf04>
    99f4:	91002260 	add	x0, x19, #0x8
    99f8:	8b010001 	add	x1, x0, x1
    99fc:	17fffdf9 	b	91e0 <fwp_write+0x4e0>
    9a00:	f9400a61 	ldr	x1, [x19, #16]
    9a04:	8b010000 	add	x0, x0, x1
    9a08:	f9400001 	ldr	x1, [x0]
    9a0c:	17fffdf5 	b	91e0 <fwp_write+0x4e0>
    9a10:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9a14:	d2800042 	mov	x2, #0x2                   	// #2
    9a18:	911da021 	add	x1, x1, #0x768
    9a1c:	17fffed6 	b	9574 <fwp_write+0x874>
    9a20:	7101fcbf 	cmp	w5, #0x7f
    9a24:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9a28:	540000e9 	b.ls	9a44 <fwp_write+0xd44>  // b.plast
    9a2c:	aa1503e1 	mov	x1, x21
    9a30:	aa1403e0 	mov	x0, x20
    9a34:	d2800022 	mov	x2, #0x1                   	// #1
    9a38:	39001fe5 	strb	w5, [sp, #7]
    9a3c:	97ffe6d5 	bl	3590 <buf_put>
    9a40:	17ffffb4 	b	9910 <fwp_write+0xc10>
    9a44:	d2800203 	mov	x3, #0x10                  	// #16
    9a48:	d0000004 	adrp	x4, b000 <__modti3+0x1b0>
    9a4c:	aa0303e1 	mov	x1, x3
    9a50:	911fa084 	add	x4, x4, #0x7e8
    9a54:	910123f6 	add	x22, sp, #0x48
    9a58:	52800042 	mov	w2, #0x2                   	// #2
    9a5c:	aa1603e0 	mov	x0, x22
    9a60:	97ffe364 	bl	27f0 <__snprintf_chk@plt>
    9a64:	aa1603e0 	mov	x0, x22
    9a68:	97ffe32a 	bl	2710 <strlen@plt>
    9a6c:	aa1603e1 	mov	x1, x22
    9a70:	aa0003e2 	mov	x2, x0
    9a74:	aa1403e0 	mov	x0, x20
    9a78:	97ffe6c6 	bl	3590 <buf_put>
    9a7c:	17ffffa5 	b	9910 <fwp_write+0xc10>
    9a80:	1e604100 	fmov	d0, d8
    9a84:	aa1503e0 	mov	x0, x21
    9a88:	52800221 	mov	w1, #0x11                  	// #17
    9a8c:	97ffe75d 	bl	3800 <fwp_format_g.constprop.0>
    9a90:	17fffe43 	b	939c <fwp_write+0x69c>
    9a94:	b9401040 	ldr	w0, [x2, #16]
    9a98:	350003c0 	cbnz	w0, 9b10 <fwp_write+0xe10>
    9a9c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9aa0:	f947f400 	ldr	x0, [x0, #4072]
    9aa4:	f94127e2 	ldr	x2, [sp, #584]
    9aa8:	f9400001 	ldr	x1, [x0]
    9aac:	eb010042 	subs	x2, x2, x1
    9ab0:	d2800001 	mov	x1, #0x0                   	// #0
    9ab4:	54ffd721 	b.ne	9598 <fwp_write+0x898>  // b.any
    9ab8:	f9413bf5 	ldr	x21, [sp, #624]
    9abc:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9ac0:	f9413ff6 	ldr	x22, [sp, #632]
    9ac4:	aa1403e0 	mov	x0, x20
    9ac8:	f94143f7 	ldr	x23, [sp, #640]
    9acc:	9120e021 	add	x1, x1, #0x838
    9ad0:	f94147f8 	ldr	x24, [sp, #648]
    9ad4:	d2800042 	mov	x2, #0x2                   	// #2
    9ad8:	17fffd0e 	b	8f10 <fwp_write+0x210>
    9adc:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9ae0:	d2800042 	mov	x2, #0x2                   	// #2
    9ae4:	911dc021 	add	x1, x1, #0x770
    9ae8:	17fffea3 	b	9574 <fwp_write+0x874>
    9aec:	f9400a63 	ldr	x3, [x19, #16]
    9af0:	8b030021 	add	x1, x1, x3
    9af4:	17ffff66 	b	988c <fwp_write+0xb8c>
    9af8:	f9400a61 	ldr	x1, [x19, #16]
    9afc:	8b0102a1 	add	x1, x21, x1
    9b00:	17fffdb3 	b	91cc <fwp_write+0x4cc>
    9b04:	f9400a63 	ldr	x3, [x19, #16]
    9b08:	8b030021 	add	x1, x1, x3
    9b0c:	17ffff56 	b	9864 <fwp_write+0xb64>
    9b10:	b9404840 	ldr	w0, [x2, #72]
    9b14:	91001ff5 	add	x21, sp, #0x7
    9b18:	34ffa360 	cbz	w0, 8f84 <fwp_write+0x284>
    9b1c:	52800503 	mov	w3, #0x28                  	// #40
    9b20:	aa1403e0 	mov	x0, x20
    9b24:	aa1503e1 	mov	x1, x21
    9b28:	d2800022 	mov	x2, #0x1                   	// #1
    9b2c:	39001fe3 	strb	w3, [sp, #7]
    9b30:	97ffe698 	bl	3590 <buf_put>
    9b34:	b9401380 	ldr	w0, [x28, #16]
    9b38:	52800038 	mov	w24, #0x1                   	// #1
    9b3c:	7100001f 	cmp	w0, #0x0
    9b40:	54ffa36c 	b.gt	8fac <fwp_write+0x2ac>
    9b44:	17fffd32 	b	900c <fwp_write+0x30c>
    9b48:	f9014bf9 	str	x25, [sp, #656]
    9b4c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10b60>
    9b50:	f9014ffa 	str	x26, [sp, #664]
    9b54:	f9400676 	ldr	x22, [x19, #8]
    9b58:	91102333 	add	x19, x25, #0x408
    9b5c:	91002273 	add	x19, x19, #0x8
    9b60:	937ffed8 	asr	x24, x22, #63
    9b64:	aa1802c0 	orr	x0, x22, x24
    9b68:	b5000320 	cbnz	x0, 9bcc <fwp_write+0xecc>
    9b6c:	110006b5 	add	w21, w21, #0x1
    9b70:	710016bf 	cmp	w21, #0x5
    9b74:	54ffffc1 	b.ne	9b6c <fwp_write+0xe6c>  // b.any
    9b78:	b7f80578 	tbnz	x24, #63, 9c24 <fwp_write+0xf24>
    9b7c:	910023f3 	add	x19, sp, #0x8
    9b80:	aa1603e2 	mov	x2, x22
    9b84:	aa1303e0 	mov	x0, x19
    9b88:	d2800003 	mov	x3, #0x0                   	// #0
    9b8c:	97ffe4a5 	bl	2e20 <fwp_fmt_u128>
    9b90:	910123f5 	add	x21, sp, #0x48
    9b94:	d0000003 	adrp	x3, b000 <__modti3+0x1b0>
    9b98:	aa1303e4 	mov	x4, x19
    9b9c:	aa1503e0 	mov	x0, x21
    9ba0:	9120c063 	add	x3, x3, #0x830
    9ba4:	d2804002 	mov	x2, #0x200                 	// #512
    9ba8:	52800041 	mov	w1, #0x2                   	// #2
    9bac:	97ffe2dd 	bl	2720 <__sprintf_chk@plt>
    9bb0:	aa1503e0 	mov	x0, x21
    9bb4:	97ffe2d7 	bl	2710 <strlen@plt>
    9bb8:	aa1503e1 	mov	x1, x21
    9bbc:	aa0003e2 	mov	x2, x0
    9bc0:	aa1403e0 	mov	x0, x20
    9bc4:	97ffe673 	bl	3590 <buf_put>
    9bc8:	17fffe47 	b	94e4 <fwp_write+0x7e4>
    9bcc:	f9400277 	ldr	x23, [x19]
    9bd0:	aa1603e0 	mov	x0, x22
    9bd4:	aa1803e1 	mov	x1, x24
    9bd8:	aa1703e2 	mov	x2, x23
    9bdc:	937ffefa 	asr	x26, x23, #63
    9be0:	aa1a03e3 	mov	x3, x26
    9be4:	9400049b 	bl	ae50 <__modti3>
    9be8:	aa010000 	orr	x0, x0, x1
    9bec:	b40002c0 	cbz	x0, 9c44 <fwp_write+0xf44>
    9bf0:	110006b5 	add	w21, w21, #0x1
    9bf4:	91004273 	add	x19, x19, #0x10
    9bf8:	710016bf 	cmp	w21, #0x5
    9bfc:	54fffe81 	b.ne	9bcc <fwp_write+0xecc>  // b.any
    9c00:	17ffffde 	b	9b78 <fwp_write+0xe78>
    9c04:	f9400a60 	ldr	x0, [x19, #16]
    9c08:	8b000021 	add	x1, x1, x0
    9c0c:	17fffd75 	b	91e0 <fwp_write+0x4e0>
    9c10:	528c29c0 	mov	w0, #0x614e                	// #24910
    9c14:	910123f5 	add	x21, sp, #0x48
    9c18:	72a009c0 	movk	w0, #0x4e, lsl #16
    9c1c:	b9004be0 	str	w0, [sp, #72]
    9c20:	17fffda2 	b	92a8 <fwp_write+0x5a8>
    9c24:	528005a1 	mov	w1, #0x2d                  	// #45
    9c28:	eb1603e2 	negs	x2, x22
    9c2c:	da1803e3 	ngc	x3, x24
    9c30:	910027e0 	add	x0, sp, #0x9
    9c34:	910023f3 	add	x19, sp, #0x8
    9c38:	390023e1 	strb	w1, [sp, #8]
    9c3c:	97ffe479 	bl	2e20 <fwp_fmt_u128>
    9c40:	17ffffd4 	b	9b90 <fwp_write+0xe90>
    9c44:	aa1703e2 	mov	x2, x23
    9c48:	aa1a03e3 	mov	x3, x26
    9c4c:	aa1603e0 	mov	x0, x22
    9c50:	aa1803e1 	mov	x1, x24
    9c54:	9400039f 	bl	aad0 <__divti3>
    9c58:	aa0003e2 	mov	x2, x0
    9c5c:	aa0103e3 	mov	x3, x1
    9c60:	b7f80201 	tbnz	x1, #63, 9ca0 <fwp_write+0xfa0>
    9c64:	910023f3 	add	x19, sp, #0x8
    9c68:	aa1303e0 	mov	x0, x19
    9c6c:	97ffe46d 	bl	2e20 <fwp_fmt_u128>
    9c70:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9c74:	91102339 	add	x25, x25, #0x408
    9c78:	910123f5 	add	x21, sp, #0x48
    9c7c:	aa1303e4 	mov	x4, x19
    9c80:	aa1503e0 	mov	x0, x21
    9c84:	d0000003 	adrp	x3, b000 <__modti3+0x1b0>
    9c88:	f8616b25 	ldr	x5, [x25, x1]
    9c8c:	9120a063 	add	x3, x3, #0x828
    9c90:	d2804002 	mov	x2, #0x200                 	// #512
    9c94:	52800041 	mov	w1, #0x2                   	// #2
    9c98:	97ffe2a2 	bl	2720 <__sprintf_chk@plt>
    9c9c:	17ffffc5 	b	9bb0 <fwp_write+0xeb0>
    9ca0:	528005a4 	mov	w4, #0x2d                  	// #45
    9ca4:	eb0003e2 	negs	x2, x0
    9ca8:	da0103e3 	ngc	x3, x1
    9cac:	910027e0 	add	x0, sp, #0x9
    9cb0:	910023f3 	add	x19, sp, #0x8
    9cb4:	390023e4 	strb	w4, [sp, #8]
    9cb8:	97ffe45a 	bl	2e20 <fwp_fmt_u128>
    9cbc:	17ffffed 	b	9c70 <fwp_write+0xf70>
    9cc0:	f9013bf5 	str	x21, [sp, #624]
    9cc4:	f9013ff6 	str	x22, [sp, #632]
    9cc8:	f90143f7 	str	x23, [sp, #640]
    9ccc:	f90147f8 	str	x24, [sp, #648]
    9cd0:	f9014bf9 	str	x25, [sp, #656]
    9cd4:	f9014ffa 	str	x26, [sp, #664]
    9cd8:	f90153fb 	str	x27, [sp, #672]
    9cdc:	f90157fc 	str	x28, [sp, #680]
    9ce0:	fd015be8 	str	d8, [sp, #688]
    9ce4:	fd015fe9 	str	d9, [sp, #696]
    9ce8:	97ffe2e6 	bl	2880 <__stack_chk_fail@plt>
    9cec:	d503201f 	nop

0000000000009cf0 <fwp_main_thread>:
    9cf0:	d10643ff 	sub	sp, sp, #0x190
    9cf4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9cf8:	f947f400 	ldr	x0, [x0, #4072]
    9cfc:	a9127bfd 	stp	x29, x30, [sp, #288]
    9d00:	910483fd 	add	x29, sp, #0x120
    9d04:	a91353f3 	stp	x19, x20, [sp, #304]
    9d08:	90000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    9d0c:	91174261 	add	x1, x19, #0x5d0
    9d10:	a9145bf5 	stp	x21, x22, [sp, #320]
    9d14:	a91563f7 	stp	x23, x24, [sp, #336]
    9d18:	b953a421 	ldr	w1, [x1, #5028]
    9d1c:	a9166bf9 	stp	x25, x26, [sp, #352]
    9d20:	f9400002 	ldr	x2, [x0]
    9d24:	f9008fe2 	str	x2, [sp, #280]
    9d28:	d2800002 	mov	x2, #0x0                   	// #0
    9d2c:	34000e61 	cbz	w1, 9ef8 <fwp_main_thread+0x208>
    9d30:	91174260 	add	x0, x19, #0x5d0
    9d34:	b953a800 	ldr	w0, [x0, #5032]
    9d38:	35000d80 	cbnz	w0, 9ee8 <fwp_main_thread+0x1f8>
    9d3c:	f00000b5 	adrp	x21, 20000 <__data_start>
    9d40:	f00000a2 	adrp	x2, 20000 <__data_start>
    9d44:	9101c2b4 	add	x20, x21, #0x70
    9d48:	910fc042 	add	x2, x2, #0x3f0
    9d4c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9d50:	d2a00024 	mov	x4, #0x10000               	// #65536
    9d54:	910103f7 	add	x23, sp, #0x40
    9d58:	9100a3f6 	add	x22, sp, #0x28
    9d5c:	aa1703e0 	mov	x0, x23
    9d60:	d2800001 	mov	x1, #0x0                   	// #0
    9d64:	a9018e96 	stp	x22, x3, [x20, #24]
    9d68:	f90023e2 	str	x2, [sp, #64]
    9d6c:	b9004bff 	str	wzr, [sp, #72]
    9d70:	f9002be4 	str	x4, [sp, #80]
    9d74:	97ffe25b 	bl	26e0 <sigaltstack@plt>
    9d78:	35000220 	cbnz	w0, 9dbc <fwp_main_thread+0xcc>
    9d7c:	4f000400 	movi	v0.4s, #0x0
    9d80:	910223e0 	add	x0, sp, #0x88
    9d84:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    9d88:	9101c021 	add	x1, x1, #0x70
    9d8c:	f90043e1 	str	x1, [sp, #128]
    9d90:	52800082 	mov	w2, #0x4                   	// #4
    9d94:	72a10002 	movk	w2, #0x800, lsl #16
    9d98:	910203f9 	add	x25, sp, #0x80
    9d9c:	3d802000 	str	q0, [x0, #128]
    9da0:	b9010be2 	str	w2, [sp, #264]
    9da4:	ad000000 	stp	q0, q0, [x0]
    9da8:	ad010000 	stp	q0, q0, [x0, #32]
    9dac:	ad020000 	stp	q0, q0, [x0, #64]
    9db0:	ad030000 	stp	q0, q0, [x0, #96]
    9db4:	97ffe2a3 	bl	2840 <sigemptyset@plt>
    9db8:	340000c0 	cbz	w0, 9dd0 <fwp_main_thread+0xe0>
    9dbc:	d0000000 	adrp	x0, b000 <__modti3+0x1b0>
    9dc0:	91212000 	add	x0, x0, #0x848
    9dc4:	a91773fb 	stp	x27, x28, [sp, #368]
    9dc8:	fd00c3e8 	str	d8, [sp, #384]
    9dcc:	97ffe8d1 	bl	4110 <fwp_trap>
    9dd0:	aa1903e1 	mov	x1, x25
    9dd4:	d2800002 	mov	x2, #0x0                   	// #0
    9dd8:	52800160 	mov	w0, #0xb                   	// #11
    9ddc:	97ffe2b1 	bl	28a0 <sigaction@plt>
    9de0:	35fffee0 	cbnz	w0, 9dbc <fwp_main_thread+0xcc>
    9de4:	aa1903e1 	mov	x1, x25
    9de8:	d2800002 	mov	x2, #0x0                   	// #0
    9dec:	528000e0 	mov	w0, #0x7                   	// #7
    9df0:	97ffe2ac 	bl	28a0 <sigaction@plt>
    9df4:	35fffe40 	cbnz	w0, 9dbc <fwp_main_thread+0xcc>
    9df8:	b9434a80 	ldr	w0, [x20, #840]
    9dfc:	34000820 	cbz	w0, 9f00 <fwp_main_thread+0x210>
    9e00:	9101c2a0 	add	x0, x21, #0x70
    9e04:	b9434c01 	ldr	w1, [x0, #844]
    9e08:	340008a1 	cbz	w1, 9f1c <fwp_main_thread+0x22c>
    9e0c:	9101c2b6 	add	x22, x21, #0x70
    9e10:	f9400ad4 	ldr	x20, [x22, #16]
    9e14:	b4001b54 	cbz	x20, a17c <fwp_main_thread+0x48c>
    9e18:	91010297 	add	x23, x20, #0x40
    9e1c:	39414a99 	ldrb	w25, [x20, #82]
    9e20:	52800038 	mov	w24, #0x1                   	// #1
    9e24:	39014a98 	strb	w24, [x20, #82]
    9e28:	f9401680 	ldr	x0, [x20, #40]
    9e2c:	b4001a60 	cbz	x0, a178 <fwp_main_thread+0x488>
    9e30:	f9403281 	ldr	x1, [x20, #96]
    9e34:	39414680 	ldrb	w0, [x20, #81]
    9e38:	b40015a1 	cbz	x1, a0ec <fwp_main_thread+0x3fc>
    9e3c:	36001460 	tbz	w0, #0, a0c8 <fwp_main_thread+0x3d8>
    9e40:	f9400ad3 	ldr	x19, [x22, #16]
    9e44:	f9402280 	ldr	x0, [x20, #64]
    9e48:	39414a61 	ldrb	w1, [x19, #82]
    9e4c:	37001861 	tbnz	w1, #0, a158 <fwp_main_thread+0x468>
    9e50:	f9403261 	ldr	x1, [x19, #96]
    9e54:	a911fe77 	stp	x23, xzr, [x19, #280]
    9e58:	f9009660 	str	x0, [x19, #296]
    9e5c:	b4000040 	cbz	x0, 9e64 <fwp_main_thread+0x174>
    9e60:	f9009013 	str	x19, [x0, #288]
    9e64:	f9002293 	str	x19, [x20, #64]
    9e68:	b4000101 	cbz	x1, 9e88 <fwp_main_thread+0x198>
    9e6c:	f9406ec0 	ldr	x0, [x22, #216]
    9e70:	39015678 	strb	w24, [x19, #85]
    9e74:	f9003661 	str	x1, [x19, #104]
    9e78:	a910827f 	stp	xzr, x0, [x19, #264]
    9e7c:	b4000040 	cbz	x0, 9e84 <fwp_main_thread+0x194>
    9e80:	f9008413 	str	x19, [x0, #264]
    9e84:	f9006ed3 	str	x19, [x22, #216]
    9e88:	39015a7f 	strb	wzr, [x19, #86]
    9e8c:	97fff271 	bl	6850 <fwp_block>
    9e90:	f9408e62 	ldr	x2, [x19, #280]
    9e94:	b4000142 	cbz	x2, 9ebc <fwp_main_thread+0x1cc>
    9e98:	a9520261 	ldp	x1, x0, [x19, #288]
    9e9c:	b40016a1 	cbz	x1, a170 <fwp_main_thread+0x480>
    9ea0:	f9009420 	str	x0, [x1, #296]
    9ea4:	f9409660 	ldr	x0, [x19, #296]
    9ea8:	b4000040 	cbz	x0, 9eb0 <fwp_main_thread+0x1c0>
    9eac:	f9009001 	str	x1, [x0, #288]
    9eb0:	91080260 	add	x0, x19, #0x200
    9eb4:	f900967f 	str	xzr, [x19, #296]
    9eb8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9ebc:	39415660 	ldrb	w0, [x19, #85]
    9ec0:	3607fb40 	tbz	w0, #0, 9e28 <fwp_main_thread+0x138>
    9ec4:	a9508261 	ldp	x1, x0, [x19, #264]
    9ec8:	b4002681 	cbz	x1, a398 <fwp_main_thread+0x6a8>
    9ecc:	f9008820 	str	x0, [x1, #272]
    9ed0:	b4000040 	cbz	x0, 9ed8 <fwp_main_thread+0x1e8>
    9ed4:	f9008401 	str	x1, [x0, #264]
    9ed8:	91080260 	add	x0, x19, #0x200
    9edc:	3901567f 	strb	wzr, [x19, #85]
    9ee0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9ee4:	17ffffd1 	b	9e28 <fwp_main_thread+0x138>
    9ee8:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9eec:	91301000 	add	x0, x0, #0xc04
    9ef0:	940004b4 	bl	b1c0 <atexit>
    9ef4:	17ffff92 	b	9d3c <fwp_main_thread+0x4c>
    9ef8:	97ffe79e 	bl	3d70 <fwp_heap_init>
    9efc:	17ffff8d 	b	9d30 <fwp_main_thread+0x40>
    9f00:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9f04:	91058000 	add	x0, x0, #0x160
    9f08:	940004ae 	bl	b1c0 <atexit>
    9f0c:	35005440 	cbnz	w0, a994 <fwp_main_thread+0xca4>
    9f10:	52800020 	mov	w0, #0x1                   	// #1
    9f14:	b9034a80 	str	w0, [x20, #840]
    9f18:	17ffffba 	b	9e00 <fwp_main_thread+0x110>
    9f1c:	d0000001 	adrp	x1, b000 <__modti3+0x1b0>
    9f20:	a91773fb 	stp	x27, x28, [sp, #368]
    9f24:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9f28:	f9418805 	ldr	x5, [x0, #784]
    9f2c:	fd00c3e8 	str	d8, [sp, #384]
    9f30:	913d4042 	add	x2, x2, #0xf50
    9f34:	fd47d828 	ldr	d8, [x1, #4016]
    9f38:	91174274 	add	x20, x19, #0x5d0
    9f3c:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    9f40:	d2800004 	mov	x4, #0x0                   	// #0
    9f44:	913c8021 	add	x1, x1, #0xf20
    9f48:	d290001c 	mov	x28, #0x8000                	// #32768
    9f4c:	d280001a 	mov	x26, #0x0                   	// #0
    9f50:	a9028be5 	stp	x5, x2, [sp, #40]
    9f54:	a903fff7 	stp	x23, xzr, [sp, #56]
    9f58:	f9002bff 	str	xzr, [sp, #80]
    9f5c:	f9002fe1 	str	x1, [sp, #88]
    9f60:	f9018816 	str	x22, [x0, #784]
    9f64:	14000041 	b	a068 <fwp_main_thread+0x378>
    9f68:	f9400301 	ldr	x1, [x24]
    9f6c:	aa2103e1 	mvn	x1, x1
    9f70:	f8207a81 	str	x1, [x20, x0, lsl #3]
    9f74:	f10060df 	cmp	x6, #0x18
    9f78:	540001a9 	b.ls	9fac <fwp_main_thread+0x2bc>  // b.plast
    9f7c:	d10064c2 	sub	x2, x6, #0x19
    9f80:	91006300 	add	x0, x24, #0x18
    9f84:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9f88:	52800001 	mov	w1, #0x0                   	// #0
    9f8c:	91002042 	add	x2, x2, #0x8
    9f90:	a90013e6 	stp	x6, x4, [sp]
    9f94:	b90013e7 	str	w7, [sp, #16]
    9f98:	f9000fe5 	str	x5, [sp, #24]
    9f9c:	97ffe22d 	bl	2850 <memset@plt>
    9fa0:	a94013e6 	ldp	x6, x4, [sp]
    9fa4:	f9400fe5 	ldr	x5, [sp, #24]
    9fa8:	b94013e7 	ldr	w7, [sp, #16]
    9fac:	f94a1280 	ldr	x0, [x20, #5152]
    9fb0:	ab060000 	adds	x0, x0, x6
    9fb4:	54005442 	b.cs	aa3c <fwp_main_thread+0xd4c>  // b.hs, b.nlast
    9fb8:	f94a1681 	ldr	x1, [x20, #5160]
    9fbc:	f90a1280 	str	x0, [x20, #5152]
    9fc0:	eb01001f 	cmp	x0, x1
    9fc4:	54000049 	b.ls	9fcc <fwp_main_thread+0x2dc>  // b.plast
    9fc8:	f90a1680 	str	x0, [x20, #5160]
    9fcc:	1e6300e1 	ucvtf	d1, w7
    9fd0:	fd4a1e80 	ldr	d0, [x20, #5176]
    9fd4:	1e612800 	fadd	d0, d0, d1
    9fd8:	fd0a1e80 	str	d0, [x20, #5176]
    9fdc:	a900931b 	stp	x27, x4, [x24, #8]
    9fe0:	aa1803e4 	mov	x4, x24
    9fe4:	fd000308 	str	d8, [x24]
    9fe8:	f949da81 	ldr	x1, [x20, #5040]
    9fec:	f949ee80 	ldr	x0, [x20, #5080]
    9ff0:	cb010301 	sub	x1, x24, x1
    9ff4:	eb00403f 	cmp	x1, x0, lsl #16
    9ff8:	54000322 	b.cs	a05c <fwp_main_thread+0x36c>  // b.hs, b.nlast
    9ffc:	d350fc20 	lsr	x0, x1, #16
    a000:	f949fe87 	ldr	x7, [x20, #5112]
    a004:	8b000800 	add	x0, x0, x0, lsl #2
    a008:	d37df002 	lsl	x2, x0, #3
    a00c:	8b0200e6 	add	x6, x7, x2
    a010:	f94010c0 	ldr	x0, [x6, #32]
    a014:	b4000240 	cbz	x0, a05c <fwp_main_thread+0x36c>
    a018:	386268e2 	ldrb	w2, [x7, x2]
    a01c:	7100085f 	cmp	w2, #0x2
    a020:	54001b60 	b.eq	a38c <fwp_main_thread+0x69c>  // b.none
    a024:	7100045f 	cmp	w2, #0x1
    a028:	540001a1 	b.ne	a05c <fwp_main_thread+0x36c>  // b.any
    a02c:	294308c7 	ldp	w7, w2, [x6, #24]
    a030:	92403c21 	and	x1, x1, #0xffff
    a034:	9b077c21 	mul	x1, x1, x7
    a038:	d360fc21 	lsr	x1, x1, #32
    a03c:	eb02003f 	cmp	x1, x2
    a040:	540000e2 	b.cs	a05c <fwp_main_thread+0x36c>  // b.hs, b.nlast
    a044:	8b010000 	add	x0, x0, x1
    a048:	39400001 	ldrb	w1, [x0]
    a04c:	7103fc3f 	cmp	w1, #0xff
    a050:	54004000 	b.eq	a850 <fwp_main_thread+0xb60>  // b.none
    a054:	52800021 	mov	w1, #0x1                   	// #1
    a058:	39000001 	strb	w1, [x0]
    a05c:	a9047ff8 	stp	x24, xzr, [sp, #64]
    a060:	aa05037b 	orr	x27, x27, x5
    a064:	b40019fb 	cbz	x27, a3a0 <fwp_main_thread+0x6b0>
    a068:	b953a680 	ldr	w0, [x20, #5028]
    a06c:	f100079b 	subs	x27, x28, #0x1
    a070:	f90027fb 	str	x27, [sp, #72]
    a074:	da1f0345 	sbc	x5, x26, xzr
    a078:	aa1b03fc 	mov	x28, x27
    a07c:	aa0503fa 	mov	x26, x5
    a080:	340005e0 	cbz	w0, a13c <fwp_main_thread+0x44c>
    a084:	397e8a80 	ldrb	w0, [x20, #4002]
    a088:	910f0001 	add	x1, x0, #0x3c0
    a08c:	8b000400 	add	x0, x0, x0, lsl #1
    a090:	b8617a87 	ldr	w7, [x20, x1, lsl #2]
    a094:	8b000e81 	add	x1, x20, x0, lsl #3
    a098:	f8607a98 	ldr	x24, [x20, x0, lsl #3]
    a09c:	2a0703e6 	mov	w6, w7
    a0a0:	b5fff658 	cbnz	x24, 9f68 <fwp_main_thread+0x278>
    a0a4:	f9400438 	ldr	x24, [x1, #8]
    a0a8:	b40004b8 	cbz	x24, a13c <fwp_main_thread+0x44c>
    a0ac:	f9400820 	ldr	x0, [x1, #16]
    a0b0:	cb180000 	sub	x0, x0, x24
    a0b4:	eb0000df 	cmp	x6, x0
    a0b8:	54000428 	b.hi	a13c <fwp_main_thread+0x44c>  // b.pmore
    a0bc:	8b060300 	add	x0, x24, x6
    a0c0:	f9000420 	str	x0, [x1, #8]
    a0c4:	17ffffac 	b	9f74 <fwp_main_thread+0x284>
    a0c8:	97ffea32 	bl	4990 <fwp_now_ns>
    a0cc:	f9403281 	ldr	x1, [x20, #96]
    a0d0:	eb01001f 	cmp	x0, x1
    a0d4:	540000ab 	b.lt	a0e8 <fwp_main_thread+0x3f8>  // b.tstop
    a0d8:	39414280 	ldrb	w0, [x20, #80]
    a0dc:	37000060 	tbnz	w0, #0, a0e8 <fwp_main_thread+0x3f8>
    a0e0:	aa1403e0 	mov	x0, x20
    a0e4:	97ffe583 	bl	36f0 <fwp_cancel_tree.part.0>
    a0e8:	39414680 	ldrb	w0, [x20, #81]
    a0ec:	f9400ad3 	ldr	x19, [x22, #16]
    a0f0:	39414a62 	ldrb	w2, [x19, #82]
    a0f4:	3707ea60 	tbnz	w0, #0, 9e40 <fwp_main_thread+0x150>
    a0f8:	f9403281 	ldr	x1, [x20, #96]
    a0fc:	370001c2 	tbnz	w2, #0, a134 <fwp_main_thread+0x444>
    a100:	f9403260 	ldr	x0, [x19, #96]
    a104:	b4000180 	cbz	x0, a134 <fwp_main_thread+0x444>
    a108:	b4000061 	cbz	x1, a114 <fwp_main_thread+0x424>
    a10c:	eb01001f 	cmp	x0, x1
    a110:	9a81d000 	csel	x0, x0, x1, le
    a114:	f9402281 	ldr	x1, [x20, #64]
    a118:	a911fe77 	stp	x23, xzr, [x19, #280]
    a11c:	f9009661 	str	x1, [x19, #296]
    a120:	b4003a41 	cbz	x1, a868 <fwp_main_thread+0xb78>
    a124:	f9009033 	str	x19, [x1, #288]
    a128:	aa0003e1 	mov	x1, x0
    a12c:	f9002293 	str	x19, [x20, #64]
    a130:	17ffff4f 	b	9e6c <fwp_main_thread+0x17c>
    a134:	f9402280 	ldr	x0, [x20, #64]
    a138:	17ffff47 	b	9e54 <fwp_main_thread+0x164>
    a13c:	52800001 	mov	w1, #0x0                   	// #0
    a140:	d2800300 	mov	x0, #0x18                  	// #24
    a144:	a90017e4 	stp	x4, x5, [sp]
    a148:	97ffeb6a 	bl	4ef0 <fwp_heap_alloc>
    a14c:	aa0003f8 	mov	x24, x0
    a150:	a94017e4 	ldp	x4, x5, [sp]
    a154:	17ffffa2 	b	9fdc <fwp_main_thread+0x2ec>
    a158:	a911fe77 	stp	x23, xzr, [x19, #280]
    a15c:	f9009660 	str	x0, [x19, #296]
    a160:	b4000040 	cbz	x0, a168 <fwp_main_thread+0x478>
    a164:	f9009013 	str	x19, [x0, #288]
    a168:	f9002293 	str	x19, [x20, #64]
    a16c:	17ffff47 	b	9e88 <fwp_main_thread+0x198>
    a170:	f9000040 	str	x0, [x2]
    a174:	17ffff4d 	b	9ea8 <fwp_main_thread+0x1b8>
    a178:	39014a99 	strb	w25, [x20, #82]
    a17c:	9101c2b3 	add	x19, x21, #0x70
    a180:	f9419660 	ldr	x0, [x19, #808]
    a184:	b5000060 	cbnz	x0, a190 <fwp_main_thread+0x4a0>
    a188:	f9419e60 	ldr	x0, [x19, #824]
    a18c:	b40038c0 	cbz	x0, a8a4 <fwp_main_thread+0xbb4>
    a190:	9101c2a0 	add	x0, x21, #0x70
    a194:	f9400800 	ldr	x0, [x0, #16]
    a198:	9101c2a1 	add	x1, x21, #0x70
    a19c:	f941b025 	ldr	x5, [x1, #864]
    a1a0:	b903583f 	str	wzr, [x1, #856]
    a1a4:	eb0000bf 	cmp	x5, x0
    a1a8:	540048e1 	b.ne	aac4 <fwp_main_thread+0xdd4>  // b.any
    a1ac:	b40003c0 	cbz	x0, a224 <fwp_main_thread+0x534>
    a1b0:	f9418026 	ldr	x6, [x1, #768]
    a1b4:	52800021 	mov	w1, #0x1                   	// #1
    a1b8:	39014801 	strb	w1, [x0, #82]
    a1bc:	b4000346 	cbz	x6, a224 <fwp_main_thread+0x534>
    a1c0:	394140c0 	ldrb	w0, [x6, #80]
    a1c4:	37000060 	tbnz	w0, #0, a1d0 <fwp_main_thread+0x4e0>
    a1c8:	aa0603e0 	mov	x0, x6
    a1cc:	97ffe549 	bl	36f0 <fwp_cancel_tree.part.0>
    a1d0:	f9409cc6 	ldr	x6, [x6, #312]
    a1d4:	b5ffff66 	cbnz	x6, a1c0 <fwp_main_thread+0x4d0>
    a1d8:	9101c2b3 	add	x19, x21, #0x70
    a1dc:	52800034 	mov	w20, #0x1                   	// #1
    a1e0:	f94028a0 	ldr	x0, [x5, #80]
    a1e4:	f2001c1f 	tst	x0, #0xff000000ff
    a1e8:	540000e1 	b.ne	a204 <fwp_main_thread+0x514>  // b.any
    a1ec:	f9403e60 	ldr	x0, [x19, #120]
    a1f0:	390150b4 	strb	w20, [x5, #84]
    a1f4:	f90080bf 	str	xzr, [x5, #256]
    a1f8:	b4000120 	cbz	x0, a21c <fwp_main_thread+0x52c>
    a1fc:	f9008005 	str	x5, [x0, #256]
    a200:	f9003e65 	str	x5, [x19, #120]
    a204:	97fff193 	bl	6850 <fwp_block>
    a208:	97fff11a 	bl	6670 <fwp_free_zombie>
    a20c:	f9418260 	ldr	x0, [x19, #768]
    a210:	b40000a0 	cbz	x0, a224 <fwp_main_thread+0x534>
    a214:	f941b265 	ldr	x5, [x19, #864]
    a218:	17fffff2 	b	a1e0 <fwp_main_thread+0x4f0>
    a21c:	f9004265 	str	x5, [x19, #128]
    a220:	17fffff8 	b	a200 <fwp_main_thread+0x510>
    a224:	9101c2b4 	add	x20, x21, #0x70
    a228:	97fff112 	bl	6670 <fwp_free_zombie>
    a22c:	f9404280 	ldr	x0, [x20, #128]
    a230:	b50044a0 	cbnz	x0, aac4 <fwp_main_thread+0xdd4>
    a234:	f9406e80 	ldr	x0, [x20, #216]
    a238:	b5004460 	cbnz	x0, aac4 <fwp_main_thread+0xdd4>
    a23c:	b940fa80 	ldr	w0, [x20, #248]
    a240:	340001e0 	cbz	w0, a27c <fwp_main_thread+0x58c>
    a244:	93407c16 	sxtw	x22, w0
    a248:	51000400 	sub	w0, w0, #0x1
    a24c:	d1000ad6 	sub	x22, x22, #0x2
    a250:	91040297 	add	x23, x20, #0x100
    a254:	cb2042d6 	sub	x22, x22, w0, uxtw
    a258:	93407c13 	sxtw	x19, w0
    a25c:	d503201f 	nop
    a260:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    a264:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a268:	b900fa93 	str	w19, [x20, #248]
    a26c:	d1000673 	sub	x19, x19, #0x1
    a270:	97ffe1cc 	bl	29a0 <munmap@plt>
    a274:	eb16027f 	cmp	x19, x22
    a278:	54ffff41 	b.ne	a260 <fwp_main_thread+0x570>  // b.any
    a27c:	d00000b3 	adrp	x19, 20000 <__data_start>
    a280:	91004260 	add	x0, x19, #0x10
    a284:	b9404000 	ldr	w0, [x0, #64]
    a288:	37f80040 	tbnz	w0, #31, a290 <fwp_main_thread+0x5a0>
    a28c:	97ffe181 	bl	2890 <close@plt>
    a290:	9101c2b4 	add	x20, x21, #0x70
    a294:	91004273 	add	x19, x19, #0x10
    a298:	12800001 	mov	w1, #0xffffffff            	// #-1
    a29c:	f941ba80 	ldr	x0, [x20, #880]
    a2a0:	b9004261 	str	w1, [x19, #64]
    a2a4:	f941b681 	ldr	x1, [x20, #872]
    a2a8:	b40001c0 	cbz	x0, a2e0 <fwp_main_thread+0x5f0>
    a2ac:	d2800013 	mov	x19, #0x0                   	// #0
    a2b0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    a2b4:	b40000e0 	cbz	x0, a2d0 <fwp_main_thread+0x5e0>
    a2b8:	f9400001 	ldr	x1, [x0]
    a2bc:	b5004041 	cbnz	x1, aac4 <fwp_main_thread+0xdd4>
    a2c0:	f9400401 	ldr	x1, [x0, #8]
    a2c4:	b5004001 	cbnz	x1, aac4 <fwp_main_thread+0xdd4>
    a2c8:	97ffe84e 	bl	4400 <fwp_mem_free>
    a2cc:	f941b681 	ldr	x1, [x20, #872]
    a2d0:	91000673 	add	x19, x19, #0x1
    a2d4:	f941ba80 	ldr	x0, [x20, #880]
    a2d8:	eb00027f 	cmp	x19, x0
    a2dc:	54fffea3 	b.cc	a2b0 <fwp_main_thread+0x5c0>  // b.lo, b.ul, b.last
    a2e0:	aa0103e0 	mov	x0, x1
    a2e4:	97ffe847 	bl	4400 <fwp_mem_free>
    a2e8:	9101c2a0 	add	x0, x21, #0x70
    a2ec:	f941b013 	ldr	x19, [x0, #864]
    a2f0:	f901b41f 	str	xzr, [x0, #872]
    a2f4:	f901b81f 	str	xzr, [x0, #880]
    a2f8:	b40001f3 	cbz	x19, a334 <fwp_main_thread+0x644>
    a2fc:	f9401661 	ldr	x1, [x19, #40]
    a300:	b5003e21 	cbnz	x1, aac4 <fwp_main_thread+0xdd4>
    a304:	f9405661 	ldr	x1, [x19, #168]
    a308:	b5003de1 	cbnz	x1, aac4 <fwp_main_thread+0xdd4>
    a30c:	f9419401 	ldr	x1, [x0, #808]
    a310:	b5003da1 	cbnz	x1, aac4 <fwp_main_thread+0xdd4>
    a314:	f9419c00 	ldr	x0, [x0, #824]
    a318:	b5003d60 	cbnz	x0, aac4 <fwp_main_thread+0xdd4>
    a31c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a320:	d0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    a324:	910fc000 	add	x0, x0, #0x3f0
    a328:	97ffe14a 	bl	2850 <memset@plt>
    a32c:	aa1303e0 	mov	x0, x19
    a330:	97ffe834 	bl	4400 <fwp_mem_free>
    a334:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a338:	f947ec00 	ldr	x0, [x0, #4056]
    a33c:	9101c2b5 	add	x21, x21, #0x70
    a340:	f9400000 	ldr	x0, [x0]
    a344:	f9000abf 	str	xzr, [x21, #16]
    a348:	f901b2bf 	str	xzr, [x21, #864]
    a34c:	97ffe199 	bl	29b0 <fflush@plt>
    a350:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a354:	f947f400 	ldr	x0, [x0, #4072]
    a358:	f9408fe2 	ldr	x2, [sp, #280]
    a35c:	f9400001 	ldr	x1, [x0]
    a360:	eb010042 	subs	x2, x2, x1
    a364:	d2800001 	mov	x1, #0x0                   	// #0
    a368:	540036c1 	b.ne	aa40 <fwp_main_thread+0xd50>  // b.any
    a36c:	a9527bfd 	ldp	x29, x30, [sp, #288]
    a370:	d2800000 	mov	x0, #0x0                   	// #0
    a374:	a95353f3 	ldp	x19, x20, [sp, #304]
    a378:	a9545bf5 	ldp	x21, x22, [sp, #320]
    a37c:	a95563f7 	ldp	x23, x24, [sp, #336]
    a380:	a9566bf9 	ldp	x25, x26, [sp, #352]
    a384:	910643ff 	add	sp, sp, #0x190
    a388:	d65f03c0 	ret
    a38c:	72003c3f 	tst	w1, #0xffff
    a390:	54ffe661 	b.ne	a05c <fwp_main_thread+0x36c>  // b.any
    a394:	17ffff2d 	b	a048 <fwp_main_thread+0x358>
    a398:	f9006ec0 	str	x0, [x22, #216]
    a39c:	17fffecd 	b	9ed0 <fwp_main_thread+0x1e0>
    a3a0:	9101c2a2 	add	x2, x21, #0x70
    a3a4:	f90023ff 	str	xzr, [sp, #64]
    a3a8:	f9418840 	ldr	x0, [x2, #784]
    a3ac:	eb16001f 	cmp	x0, x22
    a3b0:	540038e1 	b.ne	aacc <fwp_main_thread+0xddc>  // b.any
    a3b4:	b0000000 	adrp	x0, b000 <__modti3+0x1b0>
    a3b8:	910183e1 	add	x1, sp, #0x60
    a3bc:	f94017e3 	ldr	x3, [sp, #40]
    a3c0:	f9018843 	str	x3, [x2, #784]
    a3c4:	3dc3f400 	ldr	q0, [x0, #4048]
    a3c8:	52800020 	mov	w0, #0x1                   	// #1
    a3cc:	3d801be0 	str	q0, [sp, #96]
    a3d0:	97ffedbd 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a3d4:	91174263 	add	x3, x19, #0x5d0
    a3d8:	aa0003f4 	mov	x20, x0
    a3dc:	f949d861 	ldr	x1, [x3, #5040]
    a3e0:	f949ec60 	ldr	x0, [x3, #5080]
    a3e4:	cb010281 	sub	x1, x20, x1
    a3e8:	eb00403f 	cmp	x1, x0, lsl #16
    a3ec:	54000322 	b.cs	a450 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a3f0:	d350fc22 	lsr	x2, x1, #16
    a3f4:	f949fc63 	ldr	x3, [x3, #5112]
    a3f8:	8b020842 	add	x2, x2, x2, lsl #2
    a3fc:	d37df042 	lsl	x2, x2, #3
    a400:	8b020060 	add	x0, x3, x2
    a404:	f9401016 	ldr	x22, [x0, #32]
    a408:	b4000256 	cbz	x22, a450 <fwp_main_thread+0x760>
    a40c:	38626862 	ldrb	w2, [x3, x2]
    a410:	7100085f 	cmp	w2, #0x2
    a414:	540023c0 	b.eq	a88c <fwp_main_thread+0xb9c>  // b.none
    a418:	7100045f 	cmp	w2, #0x1
    a41c:	540001a1 	b.ne	a450 <fwp_main_thread+0x760>  // b.any
    a420:	29430002 	ldp	w2, w0, [x0, #24]
    a424:	92403c21 	and	x1, x1, #0xffff
    a428:	9b027c21 	mul	x1, x1, x2
    a42c:	d360fc21 	lsr	x1, x1, #32
    a430:	eb00003f 	cmp	x1, x0
    a434:	540000e2 	b.cs	a450 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a438:	8b0102d6 	add	x22, x22, x1
    a43c:	394002c0 	ldrb	w0, [x22]
    a440:	7103fc1f 	cmp	w0, #0xff
    a444:	54002580 	b.eq	a8f4 <fwp_main_thread+0xc04>  // b.none
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	390002c0 	strb	w0, [x22]
    a450:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a454:	aa1903e1 	mov	x1, x25
    a458:	52800020 	mov	w0, #0x1                   	// #1
    a45c:	a90853e2 	stp	x2, x20, [sp, #128]
    a460:	97ffed99 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a464:	91174263 	add	x3, x19, #0x5d0
    a468:	aa0003f4 	mov	x20, x0
    a46c:	f949d861 	ldr	x1, [x3, #5040]
    a470:	f949ec60 	ldr	x0, [x3, #5080]
    a474:	cb010281 	sub	x1, x20, x1
    a478:	eb00403f 	cmp	x1, x0, lsl #16
    a47c:	54000322 	b.cs	a4e0 <fwp_main_thread+0x7f0>  // b.hs, b.nlast
    a480:	d350fc22 	lsr	x2, x1, #16
    a484:	f949fc63 	ldr	x3, [x3, #5112]
    a488:	8b020842 	add	x2, x2, x2, lsl #2
    a48c:	d37df042 	lsl	x2, x2, #3
    a490:	8b020060 	add	x0, x3, x2
    a494:	f9401016 	ldr	x22, [x0, #32]
    a498:	b4000256 	cbz	x22, a4e0 <fwp_main_thread+0x7f0>
    a49c:	38626862 	ldrb	w2, [x3, x2]
    a4a0:	7100085f 	cmp	w2, #0x2
    a4a4:	54001e80 	b.eq	a874 <fwp_main_thread+0xb84>  // b.none
    a4a8:	7100045f 	cmp	w2, #0x1
    a4ac:	540001a1 	b.ne	a4e0 <fwp_main_thread+0x7f0>  // b.any
    a4b0:	29430002 	ldp	w2, w0, [x0, #24]
    a4b4:	92403c21 	and	x1, x1, #0xffff
    a4b8:	9b027c21 	mul	x1, x1, x2
    a4bc:	d360fc21 	lsr	x1, x1, #32
    a4c0:	eb00003f 	cmp	x1, x0
    a4c4:	540000e2 	b.cs	a4e0 <fwp_main_thread+0x7f0>  // b.hs, b.nlast
    a4c8:	8b0102d6 	add	x22, x22, x1
    a4cc:	394002c0 	ldrb	w0, [x22]
    a4d0:	7103fc1f 	cmp	w0, #0xff
    a4d4:	54002160 	b.eq	a900 <fwp_main_thread+0xc10>  // b.none
    a4d8:	52800020 	mov	w0, #0x1                   	// #1
    a4dc:	390002c0 	strb	w0, [x22]
    a4e0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4e4:	9101c3e1 	add	x1, sp, #0x70
    a4e8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4ec:	52800020 	mov	w0, #0x1                   	// #1
    a4f0:	a90753e2 	stp	x2, x20, [sp, #112]
    a4f4:	97ffed74 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a4f8:	91174264 	add	x4, x19, #0x5d0
    a4fc:	aa0003f4 	mov	x20, x0
    a500:	f949ec83 	ldr	x3, [x4, #5080]
    a504:	f949d881 	ldr	x1, [x4, #5040]
    a508:	d370bc63 	lsl	x3, x3, #16
    a50c:	cb010001 	sub	x1, x0, x1
    a510:	eb03003f 	cmp	x1, x3
    a514:	540003c2 	b.cs	a58c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    a518:	d350fc22 	lsr	x2, x1, #16
    a51c:	f949fc80 	ldr	x0, [x4, #5112]
    a520:	8b020842 	add	x2, x2, x2, lsl #2
    a524:	d37df042 	lsl	x2, x2, #3
    a528:	8b020004 	add	x4, x0, x2
    a52c:	f9401096 	ldr	x22, [x4, #32]
    a530:	b40002f6 	cbz	x22, a58c <fwp_main_thread+0x89c>
    a534:	38626800 	ldrb	w0, [x0, x2]
    a538:	7100081f 	cmp	w0, #0x2
    a53c:	54001a20 	b.eq	a880 <fwp_main_thread+0xb90>  // b.none
    a540:	7100041f 	cmp	w0, #0x1
    a544:	54000241 	b.ne	a58c <fwp_main_thread+0x89c>  // b.any
    a548:	29430885 	ldp	w5, w2, [x4, #24]
    a54c:	92403c20 	and	x0, x1, #0xffff
    a550:	9b057c00 	mul	x0, x0, x5
    a554:	d360fc00 	lsr	x0, x0, #32
    a558:	eb02001f 	cmp	x0, x2
    a55c:	54000182 	b.cs	a58c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    a560:	8b0002d6 	add	x22, x22, x0
    a564:	394002c0 	ldrb	w0, [x22]
    a568:	7103fc1f 	cmp	w0, #0xff
    a56c:	54001d00 	b.eq	a90c <fwp_main_thread+0xc1c>  // b.none
    a570:	91174260 	add	x0, x19, #0x5d0
    a574:	52800021 	mov	w1, #0x1                   	// #1
    a578:	390002c1 	strb	w1, [x22]
    a57c:	f949ec03 	ldr	x3, [x0, #5080]
    a580:	f949d801 	ldr	x1, [x0, #5040]
    a584:	d370bc63 	lsl	x3, x3, #16
    a588:	cb010281 	sub	x1, x20, x1
    a58c:	900000b6 	adrp	x22, 1e000 <__FRAME_END__+0x10b60>
    a590:	911022d6 	add	x22, x22, #0x408
    a594:	b0000019 	adrp	x25, b000 <__modti3+0x1b0>
    a598:	910142d6 	add	x22, x22, #0x50
    a59c:	aa1803fa 	mov	x26, x24
    a5a0:	91342339 	add	x25, x25, #0xd08
    a5a4:	eb03003f 	cmp	x1, x3
    a5a8:	54000362 	b.cs	a614 <fwp_main_thread+0x924>  // b.hs, b.nlast
    a5ac:	91174262 	add	x2, x19, #0x5d0
    a5b0:	d350fc20 	lsr	x0, x1, #16
    a5b4:	8b000800 	add	x0, x0, x0, lsl #2
    a5b8:	f949fc44 	ldr	x4, [x2, #5112]
    a5bc:	d37df002 	lsl	x2, x0, #3
    a5c0:	8b020083 	add	x3, x4, x2
    a5c4:	f9401060 	ldr	x0, [x3, #32]
    a5c8:	b4000260 	cbz	x0, a614 <fwp_main_thread+0x924>
    a5cc:	38626882 	ldrb	w2, [x4, x2]
    a5d0:	7100085f 	cmp	w2, #0x2
    a5d4:	54001620 	b.eq	a898 <fwp_main_thread+0xba8>  // b.none
    a5d8:	7100045f 	cmp	w2, #0x1
    a5dc:	540001c1 	b.ne	a614 <fwp_main_thread+0x924>  // b.any
    a5e0:	29430864 	ldp	w4, w2, [x3, #24]
    a5e4:	92403c21 	and	x1, x1, #0xffff
    a5e8:	9b047c21 	mul	x1, x1, x4
    a5ec:	d360fc21 	lsr	x1, x1, #32
    a5f0:	eb02003f 	cmp	x1, x2
    a5f4:	54000102 	b.cs	a614 <fwp_main_thread+0x924>  // b.hs, b.nlast
    a5f8:	8b010000 	add	x0, x0, x1
    a5fc:	39400001 	ldrb	w1, [x0]
    a600:	340000a1 	cbz	w1, a614 <fwp_main_thread+0x924>
    a604:	7103f43f 	cmp	w1, #0xfd
    a608:	54001888 	b.hi	a918 <fwp_main_thread+0xc28>  // b.pmore
    a60c:	11000421 	add	w1, w1, #0x1
    a610:	39000001 	strb	w1, [x0]
    a614:	aa1603e2 	mov	x2, x22
    a618:	aa1403e1 	mov	x1, x20
    a61c:	aa1703e0 	mov	x0, x23
    a620:	52800023 	mov	w3, #0x1                   	// #1
    a624:	a9047fff 	stp	xzr, xzr, [sp, #64]
    a628:	f9002bff 	str	xzr, [sp, #80]
    a62c:	97fff9b5 	bl	8d00 <fwp_write>
    a630:	a9440bfb 	ldp	x27, x2, [sp, #64]
    a634:	f100037f 	cmp	x27, #0x0
    a638:	9a9b033b 	csel	x27, x25, x27, eq	// eq = none
    a63c:	b100285f 	cmn	x2, #0xa
    a640:	54001708 	b.hi	a920 <fwp_main_thread+0xc30>  // b.pmore
    a644:	91002440 	add	x0, x2, #0x9
    a648:	52800021 	mov	w1, #0x1                   	// #1
    a64c:	f90003e2 	str	x2, [sp]
    a650:	97ffea28 	bl	4ef0 <fwp_heap_alloc>
    a654:	aa1b03e1 	mov	x1, x27
    a658:	aa0003fb 	mov	x27, x0
    a65c:	f94003e2 	ldr	x2, [sp]
    a660:	aa0003fc 	mov	x28, x0
    a664:	f8008762 	str	x2, [x27], #8
    a668:	aa1b03e0 	mov	x0, x27
    a66c:	97ffe019 	bl	26d0 <memcpy@plt>
    a670:	f94003e2 	ldr	x2, [sp]
    a674:	8b020382 	add	x2, x28, x2
    a678:	3900205f 	strb	wzr, [x2, #8]
    a67c:	f94023e0 	ldr	x0, [sp, #64]
    a680:	97ffe0b0 	bl	2940 <free@plt>
    a684:	91174260 	add	x0, x19, #0x5d0
    a688:	f949d801 	ldr	x1, [x0, #5040]
    a68c:	f949ec02 	ldr	x2, [x0, #5080]
    a690:	cb010381 	sub	x1, x28, x1
    a694:	eb02403f 	cmp	x1, x2, lsl #16
    a698:	54000322 	b.cs	a6fc <fwp_main_thread+0xa0c>  // b.hs, b.nlast
    a69c:	d350fc22 	lsr	x2, x1, #16
    a6a0:	d2800503 	mov	x3, #0x28                  	// #40
    a6a4:	f949fc04 	ldr	x4, [x0, #5112]
    a6a8:	9b037c42 	mul	x2, x2, x3
    a6ac:	8b020083 	add	x3, x4, x2
    a6b0:	f9401060 	ldr	x0, [x3, #32]
    a6b4:	b4000240 	cbz	x0, a6fc <fwp_main_thread+0xa0c>
    a6b8:	38626882 	ldrb	w2, [x4, x2]
    a6bc:	7100085f 	cmp	w2, #0x2
    a6c0:	54001480 	b.eq	a950 <fwp_main_thread+0xc60>  // b.none
    a6c4:	7100045f 	cmp	w2, #0x1
    a6c8:	540001a1 	b.ne	a6fc <fwp_main_thread+0xa0c>  // b.any
    a6cc:	29430864 	ldp	w4, w2, [x3, #24]
    a6d0:	92403c21 	and	x1, x1, #0xffff
    a6d4:	9b047c21 	mul	x1, x1, x4
    a6d8:	d360fc21 	lsr	x1, x1, #32
    a6dc:	eb02003f 	cmp	x1, x2
    a6e0:	540000e2 	b.cs	a6fc <fwp_main_thread+0xa0c>  // b.hs, b.nlast
    a6e4:	8b010000 	add	x0, x0, x1
    a6e8:	39400001 	ldrb	w1, [x0]
    a6ec:	7103fc3f 	cmp	w1, #0xff
    a6f0:	54001760 	b.eq	a9dc <fwp_main_thread+0xcec>  // b.none
    a6f4:	52800021 	mov	w1, #0x1                   	// #1
    a6f8:	39000001 	strb	w1, [x0]
    a6fc:	aa1403e0 	mov	x0, x20
    a700:	91174264 	add	x4, x19, #0x5d0
    a704:	f949d881 	ldr	x1, [x4, #5040]
    a708:	f949ec82 	ldr	x2, [x4, #5080]
    a70c:	cb010001 	sub	x1, x0, x1
    a710:	eb02403f 	cmp	x1, x2, lsl #16
    a714:	54000382 	b.cs	a784 <fwp_main_thread+0xa94>  // b.hs, b.nlast
    a718:	d350fc23 	lsr	x3, x1, #16
    a71c:	d2800502 	mov	x2, #0x28                  	// #40
    a720:	f949fc86 	ldr	x6, [x4, #5112]
    a724:	9b027c63 	mul	x3, x3, x2
    a728:	8b0300c5 	add	x5, x6, x3
    a72c:	f94010a2 	ldr	x2, [x5, #32]
    a730:	b40002a2 	cbz	x2, a784 <fwp_main_thread+0xa94>
    a734:	386368c3 	ldrb	w3, [x6, x3]
    a738:	7100087f 	cmp	w3, #0x2
    a73c:	54001040 	b.eq	a944 <fwp_main_thread+0xc54>  // b.none
    a740:	7100047f 	cmp	w3, #0x1
    a744:	54000201 	b.ne	a784 <fwp_main_thread+0xa94>  // b.any
    a748:	29430ca6 	ldp	w6, w3, [x5, #24]
    a74c:	92403c21 	and	x1, x1, #0xffff
    a750:	9b067c21 	mul	x1, x1, x6
    a754:	d360fc21 	lsr	x1, x1, #32
    a758:	eb03003f 	cmp	x1, x3
    a75c:	54000142 	b.cs	a784 <fwp_main_thread+0xa94>  // b.hs, b.nlast
    a760:	8b010042 	add	x2, x2, x1
    a764:	39400041 	ldrb	w1, [x2]
    a768:	340000e1 	cbz	w1, a784 <fwp_main_thread+0xa94>
    a76c:	7100043f 	cmp	w1, #0x1
    a770:	54000de0 	b.eq	a92c <fwp_main_thread+0xc3c>  // b.none
    a774:	7103fc3f 	cmp	w1, #0xff
    a778:	54001140 	b.eq	a9a0 <fwp_main_thread+0xcb0>  // b.none
    a77c:	51000421 	sub	w1, w1, #0x1
    a780:	39000041 	strb	w1, [x2]
    a784:	9101c2a3 	add	x3, x21, #0x70
    a788:	aa1b03e0 	mov	x0, x27
    a78c:	f9400382 	ldr	x2, [x28]
    a790:	aa0303fb 	mov	x27, x3
    a794:	f9400463 	ldr	x3, [x3, #8]
    a798:	d2800021 	mov	x1, #0x1                   	// #1
    a79c:	97ffe079 	bl	2980 <fwrite@plt>
    a7a0:	f9400761 	ldr	x1, [x27, #8]
    a7a4:	52800140 	mov	w0, #0xa                   	// #10
    a7a8:	97ffdffe 	bl	27a0 <fputc@plt>
    a7ac:	91174262 	add	x2, x19, #0x5d0
    a7b0:	f949d841 	ldr	x1, [x2, #5040]
    a7b4:	f949ec40 	ldr	x0, [x2, #5080]
    a7b8:	cb010381 	sub	x1, x28, x1
    a7bc:	eb00403f 	cmp	x1, x0, lsl #16
    a7c0:	54000382 	b.cs	a830 <fwp_main_thread+0xb40>  // b.hs, b.nlast
    a7c4:	d350fc20 	lsr	x0, x1, #16
    a7c8:	d2800504 	mov	x4, #0x28                  	// #40
    a7cc:	f949fc43 	ldr	x3, [x2, #5112]
    a7d0:	9b047c00 	mul	x0, x0, x4
    a7d4:	8b000062 	add	x2, x3, x0
    a7d8:	f940105b 	ldr	x27, [x2, #32]
    a7dc:	b40002bb 	cbz	x27, a830 <fwp_main_thread+0xb40>
    a7e0:	38606863 	ldrb	w3, [x3, x0]
    a7e4:	7100087f 	cmp	w3, #0x2
    a7e8:	54000cc0 	b.eq	a980 <fwp_main_thread+0xc90>  // b.none
    a7ec:	7100047f 	cmp	w3, #0x1
    a7f0:	54000201 	b.ne	a830 <fwp_main_thread+0xb40>  // b.any
    a7f4:	29431040 	ldp	w0, w4, [x2, #24]
    a7f8:	92403c21 	and	x1, x1, #0xffff
    a7fc:	9b007c20 	mul	x0, x1, x0
    a800:	d360fc00 	lsr	x0, x0, #32
    a804:	eb04001f 	cmp	x0, x4
    a808:	54000142 	b.cs	a830 <fwp_main_thread+0xb40>  // b.hs, b.nlast
    a80c:	8b00037b 	add	x27, x27, x0
    a810:	39400360 	ldrb	w0, [x27]
    a814:	340000e0 	cbz	w0, a830 <fwp_main_thread+0xb40>
    a818:	7100041f 	cmp	w0, #0x1
    a81c:	54000a00 	b.eq	a95c <fwp_main_thread+0xc6c>  // b.none
    a820:	7103fc1f 	cmp	w0, #0xff
    a824:	54001140 	b.eq	aa4c <fwp_main_thread+0xd5c>  // b.none
    a828:	51000400 	sub	w0, w0, #0x1
    a82c:	39000360 	strb	w0, [x27]
    a830:	f9400b5a 	ldr	x26, [x26, #16]
    a834:	b40004ba 	cbz	x26, a8c8 <fwp_main_thread+0xbd8>
    a838:	91174260 	add	x0, x19, #0x5d0
    a83c:	f949ec03 	ldr	x3, [x0, #5080]
    a840:	f949d801 	ldr	x1, [x0, #5040]
    a844:	d370bc63 	lsl	x3, x3, #16
    a848:	cb010281 	sub	x1, x20, x1
    a84c:	17ffff56 	b	a5a4 <fwp_main_thread+0x8b4>
    a850:	a90013e0 	stp	x0, x4, [sp]
    a854:	f9000be5 	str	x5, [sp, #16]
    a858:	97ffe64e 	bl	4190 <fwp_rc_forget_slot.part.0>
    a85c:	a94013e0 	ldp	x0, x4, [sp]
    a860:	f9400be5 	ldr	x5, [sp, #16]
    a864:	17fffdfc 	b	a054 <fwp_main_thread+0x364>
    a868:	aa0003e1 	mov	x1, x0
    a86c:	f9002293 	str	x19, [x20, #64]
    a870:	17fffd7f 	b	9e6c <fwp_main_thread+0x17c>
    a874:	72003c3f 	tst	w1, #0xffff
    a878:	54ffe341 	b.ne	a4e0 <fwp_main_thread+0x7f0>  // b.any
    a87c:	17ffff14 	b	a4cc <fwp_main_thread+0x7dc>
    a880:	72003c3f 	tst	w1, #0xffff
    a884:	54ffe841 	b.ne	a58c <fwp_main_thread+0x89c>  // b.any
    a888:	17ffff37 	b	a564 <fwp_main_thread+0x874>
    a88c:	72003c3f 	tst	w1, #0xffff
    a890:	54ffde01 	b.ne	a450 <fwp_main_thread+0x760>  // b.any
    a894:	17fffeea 	b	a43c <fwp_main_thread+0x74c>
    a898:	72003c3f 	tst	w1, #0xffff
    a89c:	54ffebc1 	b.ne	a614 <fwp_main_thread+0x924>  // b.any
    a8a0:	17ffff57 	b	a5fc <fwp_main_thread+0x90c>
    a8a4:	f9419260 	ldr	x0, [x19, #800]
    a8a8:	97ffe6d6 	bl	4400 <fwp_mem_free>
    a8ac:	f901927f 	str	xzr, [x19, #800]
    a8b0:	f9400a60 	ldr	x0, [x19, #16]
    a8b4:	f9019a7f 	str	xzr, [x19, #816]
    a8b8:	b4ffc700 	cbz	x0, a198 <fwp_main_thread+0x4a8>
    a8bc:	f900541f 	str	xzr, [x0, #168]
    a8c0:	f9005c1f 	str	xzr, [x0, #184]
    a8c4:	17fffe35 	b	a198 <fwp_main_thread+0x4a8>
    a8c8:	aa1403e0 	mov	x0, x20
    a8cc:	97ffed32 	bl	5d94 <fwp_drop0>
    a8d0:	aa1803e0 	mov	x0, x24
    a8d4:	97ffed30 	bl	5d94 <fwp_drop0>
    a8d8:	9101c2a0 	add	x0, x21, #0x70
    a8dc:	fd40c3e8 	ldr	d8, [sp, #384]
    a8e0:	a95773fb 	ldp	x27, x28, [sp, #368]
    a8e4:	52800021 	mov	w1, #0x1                   	// #1
    a8e8:	b9034c01 	str	w1, [x0, #844]
    a8ec:	f901a81f 	str	xzr, [x0, #848]
    a8f0:	17fffd47 	b	9e0c <fwp_main_thread+0x11c>
    a8f4:	aa1603e0 	mov	x0, x22
    a8f8:	97ffe626 	bl	4190 <fwp_rc_forget_slot.part.0>
    a8fc:	17fffed3 	b	a448 <fwp_main_thread+0x758>
    a900:	aa1603e0 	mov	x0, x22
    a904:	97ffe623 	bl	4190 <fwp_rc_forget_slot.part.0>
    a908:	17fffef4 	b	a4d8 <fwp_main_thread+0x7e8>
    a90c:	aa1603e0 	mov	x0, x22
    a910:	97ffe620 	bl	4190 <fwp_rc_forget_slot.part.0>
    a914:	17ffff17 	b	a570 <fwp_main_thread+0x880>
    a918:	97ffe733 	bl	45e4 <fwp_rc_wide_dup>
    a91c:	17ffff3e 	b	a614 <fwp_main_thread+0x924>
    a920:	b0000000 	adrp	x0, b000 <__modti3+0x1b0>
    a924:	9121c000 	add	x0, x0, #0x870
    a928:	97ffe5fa 	bl	4110 <fwp_trap>
    a92c:	f9400801 	ldr	x1, [x0, #16]
    a930:	a90013e1 	stp	x1, x4, [sp]
    a934:	97ffecd0 	bl	5c74 <fwp_rc_free_arr>
    a938:	a94013e1 	ldp	x1, x4, [sp]
    a93c:	aa0103e0 	mov	x0, x1
    a940:	17ffff71 	b	a704 <fwp_main_thread+0xa14>
    a944:	72003c3f 	tst	w1, #0xffff
    a948:	54fff1e1 	b.ne	a784 <fwp_main_thread+0xa94>  // b.any
    a94c:	17ffff86 	b	a764 <fwp_main_thread+0xa74>
    a950:	72003c3f 	tst	w1, #0xffff
    a954:	54ffed41 	b.ne	a6fc <fwp_main_thread+0xa0c>  // b.any
    a958:	17ffff64 	b	a6e8 <fwp_main_thread+0x9f8>
    a95c:	7100087f 	cmp	w3, #0x2
    a960:	54000160 	b.eq	a98c <fwp_main_thread+0xc9c>  // b.none
    a964:	29430043 	ldp	w3, w0, [x2, #24]
    a968:	9b037c21 	mul	x1, x1, x3
    a96c:	eb41801f 	cmp	x0, x1, lsr #32
    a970:	54fff609 	b.ls	a830 <fwp_main_thread+0xb40>  // b.plast
    a974:	aa1c03e0 	mov	x0, x28
    a978:	97ffe6a2 	bl	4400 <fwp_mem_free>
    a97c:	17ffffad 	b	a830 <fwp_main_thread+0xb40>
    a980:	f2403c21 	ands	x1, x1, #0xffff
    a984:	54fff561 	b.ne	a830 <fwp_main_thread+0xb40>  // b.any
    a988:	17ffffa2 	b	a810 <fwp_main_thread+0xb20>
    a98c:	b5fff521 	cbnz	x1, a830 <fwp_main_thread+0xb40>
    a990:	17fffff9 	b	a974 <fwp_main_thread+0xc84>
    a994:	a91773fb 	stp	x27, x28, [sp, #368]
    a998:	fd00c3e8 	str	d8, [sp, #384]
    a99c:	97ffe1e5 	bl	3130 <descent_phase_fail>
    a9a0:	ca424441 	eor	x1, x2, x2, lsr #17
    a9a4:	91174260 	add	x0, x19, #0x5d0
    a9a8:	ca412421 	eor	x1, x1, x1, lsr #9
    a9ac:	92401c21 	and	x1, x1, #0xff
    a9b0:	910a2423 	add	x3, x1, #0x289
    a9b4:	8b010c01 	add	x1, x0, x1, lsl #3
    a9b8:	8b030c03 	add	x3, x0, x3, lsl #3
    a9bc:	f94a2420 	ldr	x0, [x1, #5192]
    a9c0:	b40002e0 	cbz	x0, aa1c <fwp_main_thread+0xd2c>
    a9c4:	f9400001 	ldr	x1, [x0]
    a9c8:	eb01005f 	cmp	x2, x1
    a9cc:	54000100 	b.eq	a9ec <fwp_main_thread+0xcfc>  // b.none
    a9d0:	91004003 	add	x3, x0, #0x10
    a9d4:	f9400800 	ldr	x0, [x0, #16]
    a9d8:	17fffffa 	b	a9c0 <fwp_main_thread+0xcd0>
    a9dc:	f90003e0 	str	x0, [sp]
    a9e0:	97ffe5ec 	bl	4190 <fwp_rc_forget_slot.part.0>
    a9e4:	f94003e0 	ldr	x0, [sp]
    a9e8:	17ffff43 	b	a6f4 <fwp_main_thread+0xa04>
    a9ec:	f9400061 	ldr	x1, [x3]
    a9f0:	f9400420 	ldr	x0, [x1, #8]
    a9f4:	d1000400 	sub	x0, x0, #0x1
    a9f8:	f9000420 	str	x0, [x1, #8]
    a9fc:	f103f81f 	cmp	x0, #0xfe
    aa00:	54ffec21 	b.ne	a784 <fwp_main_thread+0xa94>  // b.any
    aa04:	39400040 	ldrb	w0, [x2]
    aa08:	7103fc1f 	cmp	w0, #0xff
    aa0c:	540000e0 	b.eq	aa28 <fwp_main_thread+0xd38>  // b.none
    aa10:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aa14:	39000040 	strb	w0, [x2]
    aa18:	17ffff5b 	b	a784 <fwp_main_thread+0xa94>
    aa1c:	b0000000 	adrp	x0, b000 <__modti3+0x1b0>
    aa20:	910fa000 	add	x0, x0, #0x3e8
    aa24:	97ffe5bb 	bl	4110 <fwp_trap>
    aa28:	aa0203e0 	mov	x0, x2
    aa2c:	f90003e2 	str	x2, [sp]
    aa30:	97ffe5d8 	bl	4190 <fwp_rc_forget_slot.part.0>
    aa34:	f94003e2 	ldr	x2, [sp]
    aa38:	17fffff6 	b	aa10 <fwp_main_thread+0xd20>
    aa3c:	97ffe17d 	bl	3030 <fwp_heap_oom>
    aa40:	a91773fb 	stp	x27, x28, [sp, #368]
    aa44:	fd00c3e8 	str	d8, [sp, #384]
    aa48:	97ffdf8e 	bl	2880 <__stack_chk_fail@plt>
    aa4c:	ca5b4761 	eor	x1, x27, x27, lsr #17
    aa50:	91174260 	add	x0, x19, #0x5d0
    aa54:	ca412421 	eor	x1, x1, x1, lsr #9
    aa58:	92401c21 	and	x1, x1, #0xff
    aa5c:	910a2422 	add	x2, x1, #0x289
    aa60:	8b010c01 	add	x1, x0, x1, lsl #3
    aa64:	8b020c02 	add	x2, x0, x2, lsl #3
    aa68:	f94a2420 	ldr	x0, [x1, #5192]
    aa6c:	b4fffd80 	cbz	x0, aa1c <fwp_main_thread+0xd2c>
    aa70:	f9400001 	ldr	x1, [x0]
    aa74:	eb01037f 	cmp	x27, x1
    aa78:	54000080 	b.eq	aa88 <fwp_main_thread+0xd98>  // b.none
    aa7c:	91004002 	add	x2, x0, #0x10
    aa80:	f9400800 	ldr	x0, [x0, #16]
    aa84:	17fffffa 	b	aa6c <fwp_main_thread+0xd7c>
    aa88:	f9400041 	ldr	x1, [x2]
    aa8c:	f9400420 	ldr	x0, [x1, #8]
    aa90:	d1000400 	sub	x0, x0, #0x1
    aa94:	f9000420 	str	x0, [x1, #8]
    aa98:	f103f81f 	cmp	x0, #0xfe
    aa9c:	54ffeca1 	b.ne	a830 <fwp_main_thread+0xb40>  // b.any
    aaa0:	39400360 	ldrb	w0, [x27]
    aaa4:	7103fc1f 	cmp	w0, #0xff
    aaa8:	54000080 	b.eq	aab8 <fwp_main_thread+0xdc8>  // b.none
    aaac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aab0:	39000360 	strb	w0, [x27]
    aab4:	17ffff5f 	b	a830 <fwp_main_thread+0xb40>
    aab8:	aa1b03e0 	mov	x0, x27
    aabc:	97ffe5b5 	bl	4190 <fwp_rc_forget_slot.part.0>
    aac0:	17fffffb 	b	aaac <fwp_main_thread+0xdbc>
    aac4:	a91773fb 	stp	x27, x28, [sp, #368]
    aac8:	fd00c3e8 	str	d8, [sp, #384]
    aacc:	97ffdf81 	bl	28d0 <abort@plt>

000000000000aad0 <__divti3>:
    aad0:	d503245f 	bti	c
    aad4:	d2800004 	mov	x4, #0x0                   	// #0
    aad8:	b7f80721 	tbnz	x1, #63, abbc <__divti3+0xec>
    aadc:	b6f80083 	tbz	x3, #63, aaec <__divti3+0x1c>
    aae0:	eb0203e2 	negs	x2, x2
    aae4:	aa2403e4 	mvn	x4, x4
    aae8:	da0303e3 	ngc	x3, x3
    aaec:	aa0203e6 	mov	x6, x2
    aaf0:	aa0003e7 	mov	x7, x0
    aaf4:	aa0103e5 	mov	x5, x1
    aaf8:	b5000583 	cbnz	x3, aba8 <__divti3+0xd8>
    aafc:	eb01005f 	cmp	x2, x1
    ab00:	54000e69 	b.ls	accc <__divti3+0x1fc>  // b.plast
    ab04:	dac01040 	clz	x0, x2
    ab08:	b40000e0 	cbz	x0, ab24 <__divti3+0x54>
    ab0c:	4b0003e1 	neg	w1, w0
    ab10:	9ac020a5 	lsl	x5, x5, x0
    ab14:	9ac02046 	lsl	x6, x2, x0
    ab18:	9ac124e1 	lsr	x1, x7, x1
    ab1c:	aa050025 	orr	x5, x1, x5
    ab20:	9ac020e7 	lsl	x7, x7, x0
    ab24:	d360fcc8 	lsr	x8, x6, #32
    ab28:	92407cc2 	and	x2, x6, #0xffffffff
    ab2c:	9ac808a3 	udiv	x3, x5, x8
    ab30:	9b089465 	msub	x5, x3, x8, x5
    ab34:	aa0303e0 	mov	x0, x3
    ab38:	9b037c41 	mul	x1, x2, x3
    ab3c:	93c780a5 	extr	x5, x5, x7, #32
    ab40:	eb05003f 	cmp	x1, x5
    ab44:	540000a9 	b.ls	ab58 <__divti3+0x88>  // b.plast
    ab48:	ab0500c5 	adds	x5, x6, x5
    ab4c:	d1000460 	sub	x0, x3, #0x1
    ab50:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ab54:	540015a8 	b.hi	ae08 <__divti3+0x338>  // b.pmore
    ab58:	cb0100a5 	sub	x5, x5, x1
    ab5c:	9ac808a3 	udiv	x3, x5, x8
    ab60:	9b089465 	msub	x5, x3, x8, x5
    ab64:	aa0303e1 	mov	x1, x3
    ab68:	9b037c42 	mul	x2, x2, x3
    ab6c:	aa0703e3 	mov	x3, x7
    ab70:	b3607ca3 	bfi	x3, x5, #32, #32
    ab74:	eb03005f 	cmp	x2, x3
    ab78:	540000c9 	b.ls	ab90 <__divti3+0xc0>  // b.plast
    ab7c:	ab0300c3 	adds	x3, x6, x3
    ab80:	d1000425 	sub	x5, x1, #0x1
    ab84:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ab88:	d1000821 	sub	x1, x1, #0x2
    ab8c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ab90:	aa008020 	orr	x0, x1, x0, lsl #32
    ab94:	d2800001 	mov	x1, #0x0                   	// #0
    ab98:	b4000064 	cbz	x4, aba4 <__divti3+0xd4>
    ab9c:	eb0003e0 	negs	x0, x0
    aba0:	da0103e1 	ngc	x1, x1
    aba4:	d65f03c0 	ret
    aba8:	eb01007f 	cmp	x3, x1
    abac:	54000109 	b.ls	abcc <__divti3+0xfc>  // b.plast
    abb0:	d2800001 	mov	x1, #0x0                   	// #0
    abb4:	d2800000 	mov	x0, #0x0                   	// #0
    abb8:	17fffff8 	b	ab98 <__divti3+0xc8>
    abbc:	eb0003e0 	negs	x0, x0
    abc0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    abc4:	da0103e1 	ngc	x1, x1
    abc8:	17ffffc5 	b	aadc <__divti3+0xc>
    abcc:	dac01067 	clz	x7, x3
    abd0:	b40010e7 	cbz	x7, adec <__divti3+0x31c>
    abd4:	d2800805 	mov	x5, #0x40                  	// #64
    abd8:	cb0700a5 	sub	x5, x5, x7
    abdc:	9ac72063 	lsl	x3, x3, x7
    abe0:	9ac52448 	lsr	x8, x2, x5
    abe4:	aa030108 	orr	x8, x8, x3
    abe8:	9ac52426 	lsr	x6, x1, x5
    abec:	92407d0a 	and	x10, x8, #0xffffffff
    abf0:	d360fd09 	lsr	x9, x8, #32
    abf4:	9ac52403 	lsr	x3, x0, x5
    abf8:	9ac72021 	lsl	x1, x1, x7
    abfc:	aa010063 	orr	x3, x3, x1
    ac00:	9ac72042 	lsl	x2, x2, x7
    ac04:	9ac908cb 	udiv	x11, x6, x9
    ac08:	9b099965 	msub	x5, x11, x9, x6
    ac0c:	aa0b03e1 	mov	x1, x11
    ac10:	9b0b7d46 	mul	x6, x10, x11
    ac14:	93c380a5 	extr	x5, x5, x3, #32
    ac18:	eb0500df 	cmp	x6, x5
    ac1c:	540000a9 	b.ls	ac30 <__divti3+0x160>  // b.plast
    ac20:	ab050105 	adds	x5, x8, x5
    ac24:	d1000561 	sub	x1, x11, #0x1
    ac28:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ac2c:	54000f48 	b.hi	ae14 <__divti3+0x344>  // b.pmore
    ac30:	cb0600a6 	sub	x6, x5, x6
    ac34:	9ac908cb 	udiv	x11, x6, x9
    ac38:	9b099969 	msub	x9, x11, x9, x6
    ac3c:	aa0b03e5 	mov	x5, x11
    ac40:	9b0b7d4a 	mul	x10, x10, x11
    ac44:	b3607d23 	bfi	x3, x9, #32, #32
    ac48:	eb03015f 	cmp	x10, x3
    ac4c:	540000a9 	b.ls	ac60 <__divti3+0x190>  // b.plast
    ac50:	ab030103 	adds	x3, x8, x3
    ac54:	d1000565 	sub	x5, x11, #0x1
    ac58:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ac5c:	54000e28 	b.hi	ae20 <__divti3+0x350>  // b.pmore
    ac60:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ac64:	92407c48 	and	x8, x2, #0xffffffff
    ac68:	2a0503e5 	mov	w5, w5
    ac6c:	d360fc42 	lsr	x2, x2, #32
    ac70:	d360fc26 	lsr	x6, x1, #32
    ac74:	cb0a0063 	sub	x3, x3, x10
    ac78:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ac7c:	9b087caa 	mul	x10, x5, x8
    ac80:	9b087cc8 	mul	x8, x6, x8
    ac84:	9b0220a5 	madd	x5, x5, x2, x8
    ac88:	9b027cc6 	mul	x6, x6, x2
    ac8c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ac90:	8b0900c5 	add	x5, x6, x9
    ac94:	eb02011f 	cmp	x8, x2
    ac98:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ac9c:	8b4280c6 	add	x6, x6, x2, lsr #32
    aca0:	eb06007f 	cmp	x3, x6
    aca4:	540000e3 	b.cc	acc0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    aca8:	92407d4a 	and	x10, x10, #0xffffffff
    acac:	9ac72000 	lsl	x0, x0, x7
    acb0:	8b028142 	add	x2, x10, x2, lsl #32
    acb4:	eb02001f 	cmp	x0, x2
    acb8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    acbc:	54000a01 	b.ne	adfc <__divti3+0x32c>  // b.any
    acc0:	d1000420 	sub	x0, x1, #0x1
    acc4:	d2800001 	mov	x1, #0x0                   	// #0
    acc8:	17ffffb4 	b	ab98 <__divti3+0xc8>
    accc:	b5000062 	cbnz	x2, acd8 <__divti3+0x208>
    acd0:	d2800022 	mov	x2, #0x1                   	// #1
    acd4:	9ac30846 	udiv	x6, x2, x3
    acd8:	dac010c8 	clz	x8, x6
    acdc:	b5000408 	cbnz	x8, ad5c <__divti3+0x28c>
    ace0:	d360fcc9 	lsr	x9, x6, #32
    ace4:	92407cc5 	and	x5, x6, #0xffffffff
    ace8:	cb060023 	sub	x3, x1, x6
    acec:	d2800021 	mov	x1, #0x1                   	// #1
    acf0:	9ac90868 	udiv	x8, x3, x9
    acf4:	9b098d03 	msub	x3, x8, x9, x3
    acf8:	aa0803e0 	mov	x0, x8
    acfc:	9b057d02 	mul	x2, x8, x5
    ad00:	93c78063 	extr	x3, x3, x7, #32
    ad04:	eb03005f 	cmp	x2, x3
    ad08:	540000a9 	b.ls	ad1c <__divti3+0x24c>  // b.plast
    ad0c:	ab0300c3 	adds	x3, x6, x3
    ad10:	d1000500 	sub	x0, x8, #0x1
    ad14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ad18:	54000968 	b.hi	ae44 <__divti3+0x374>  // b.pmore
    ad1c:	cb020063 	sub	x3, x3, x2
    ad20:	9ac90862 	udiv	x2, x3, x9
    ad24:	aa0203e8 	mov	x8, x2
    ad28:	9b098c42 	msub	x2, x2, x9, x3
    ad2c:	aa0703e3 	mov	x3, x7
    ad30:	9b057d05 	mul	x5, x8, x5
    ad34:	b3607c43 	bfi	x3, x2, #32, #32
    ad38:	eb0300bf 	cmp	x5, x3
    ad3c:	540000c9 	b.ls	ad54 <__divti3+0x284>  // b.plast
    ad40:	ab0300c2 	adds	x2, x6, x3
    ad44:	d1000503 	sub	x3, x8, #0x1
    ad48:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ad4c:	d1000908 	sub	x8, x8, #0x2
    ad50:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ad54:	aa008100 	orr	x0, x8, x0, lsl #32
    ad58:	17ffff90 	b	ab98 <__divti3+0xc8>
    ad5c:	9ac820c6 	lsl	x6, x6, x8
    ad60:	d2800803 	mov	x3, #0x40                  	// #64
    ad64:	cb080063 	sub	x3, x3, x8
    ad68:	d360fcc9 	lsr	x9, x6, #32
    ad6c:	9ac82027 	lsl	x7, x1, x8
    ad70:	92407cc5 	and	x5, x6, #0xffffffff
    ad74:	9ac32422 	lsr	x2, x1, x3
    ad78:	9ac32403 	lsr	x3, x0, x3
    ad7c:	aa070063 	orr	x3, x3, x7
    ad80:	9ac9084a 	udiv	x10, x2, x9
    ad84:	9ac82007 	lsl	x7, x0, x8
    ad88:	9b098940 	msub	x0, x10, x9, x2
    ad8c:	aa0a03e1 	mov	x1, x10
    ad90:	9b0a7ca2 	mul	x2, x5, x10
    ad94:	93c38000 	extr	x0, x0, x3, #32
    ad98:	eb00005f 	cmp	x2, x0
    ad9c:	540000a9 	b.ls	adb0 <__divti3+0x2e0>  // b.plast
    ada0:	ab0000c0 	adds	x0, x6, x0
    ada4:	d1000541 	sub	x1, x10, #0x1
    ada8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    adac:	54000468 	b.hi	ae38 <__divti3+0x368>  // b.pmore
    adb0:	cb020000 	sub	x0, x0, x2
    adb4:	9ac9080a 	udiv	x10, x0, x9
    adb8:	9b098140 	msub	x0, x10, x9, x0
    adbc:	aa0a03e2 	mov	x2, x10
    adc0:	9b0a7ca8 	mul	x8, x5, x10
    adc4:	b3607c03 	bfi	x3, x0, #32, #32
    adc8:	eb03011f 	cmp	x8, x3
    adcc:	540000a9 	b.ls	ade0 <__divti3+0x310>  // b.plast
    add0:	ab0300c3 	adds	x3, x6, x3
    add4:	d1000542 	sub	x2, x10, #0x1
    add8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    addc:	54000288 	b.hi	ae2c <__divti3+0x35c>  // b.pmore
    ade0:	cb080063 	sub	x3, x3, x8
    ade4:	aa018041 	orr	x1, x2, x1, lsl #32
    ade8:	17ffffc2 	b	acf0 <__divti3+0x220>
    adec:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    adf0:	d2800001 	mov	x1, #0x0                   	// #0
    adf4:	9a9f87e0 	cset	x0, ls	// ls = plast
    adf8:	17ffff68 	b	ab98 <__divti3+0xc8>
    adfc:	aa0103e0 	mov	x0, x1
    ae00:	d2800001 	mov	x1, #0x0                   	// #0
    ae04:	17ffff65 	b	ab98 <__divti3+0xc8>
    ae08:	d1000860 	sub	x0, x3, #0x2
    ae0c:	8b0600a5 	add	x5, x5, x6
    ae10:	17ffff52 	b	ab58 <__divti3+0x88>
    ae14:	d1000961 	sub	x1, x11, #0x2
    ae18:	8b0800a5 	add	x5, x5, x8
    ae1c:	17ffff85 	b	ac30 <__divti3+0x160>
    ae20:	d1000965 	sub	x5, x11, #0x2
    ae24:	8b080063 	add	x3, x3, x8
    ae28:	17ffff8e 	b	ac60 <__divti3+0x190>
    ae2c:	d1000942 	sub	x2, x10, #0x2
    ae30:	8b060063 	add	x3, x3, x6
    ae34:	17ffffeb 	b	ade0 <__divti3+0x310>
    ae38:	d1000941 	sub	x1, x10, #0x2
    ae3c:	8b060000 	add	x0, x0, x6
    ae40:	17ffffdc 	b	adb0 <__divti3+0x2e0>
    ae44:	d1000900 	sub	x0, x8, #0x2
    ae48:	8b060063 	add	x3, x3, x6
    ae4c:	17ffffb4 	b	ad1c <__divti3+0x24c>

000000000000ae50 <__modti3>:
    ae50:	d503245f 	bti	c
    ae54:	d2800004 	mov	x4, #0x0                   	// #0
    ae58:	b6f80081 	tbz	x1, #63, ae68 <__modti3+0x18>
    ae5c:	eb0003e0 	negs	x0, x0
    ae60:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ae64:	da0103e1 	ngc	x1, x1
    ae68:	f100007f 	cmp	x3, #0x0
    ae6c:	5400128b 	b.lt	b0bc <__modti3+0x26c>  // b.tstop
    ae70:	aa0003e7 	mov	x7, x0
    ae74:	aa0103e6 	mov	x6, x1
    ae78:	540004e1 	b.ne	af14 <__modti3+0xc4>  // b.any
    ae7c:	eb02003f 	cmp	x1, x2
    ae80:	54000dc2 	b.cs	b038 <__modti3+0x1e8>  // b.hs, b.nlast
    ae84:	dac01043 	clz	x3, x2
    ae88:	aa0303e5 	mov	x5, x3
    ae8c:	b40000e3 	cbz	x3, aea8 <__modti3+0x58>
    ae90:	4b0303e6 	neg	w6, w3
    ae94:	9ac32021 	lsl	x1, x1, x3
    ae98:	9ac32042 	lsl	x2, x2, x3
    ae9c:	9ac62406 	lsr	x6, x0, x6
    aea0:	aa0100c6 	orr	x6, x6, x1
    aea4:	9ac32007 	lsl	x7, x0, x3
    aea8:	d360fc40 	lsr	x0, x2, #32
    aeac:	92407c43 	and	x3, x2, #0xffffffff
    aeb0:	9ac008c1 	udiv	x1, x6, x0
    aeb4:	9b009826 	msub	x6, x1, x0, x6
    aeb8:	9b017c61 	mul	x1, x3, x1
    aebc:	93c780c6 	extr	x6, x6, x7, #32
    aec0:	eb06003f 	cmp	x1, x6
    aec4:	540000a9 	b.ls	aed8 <__modti3+0x88>  // b.plast
    aec8:	ab060046 	adds	x6, x2, x6
    aecc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    aed0:	8b0200c8 	add	x8, x6, x2
    aed4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    aed8:	cb0100c6 	sub	x6, x6, x1
    aedc:	9ac008c8 	udiv	x8, x6, x0
    aee0:	9b009901 	msub	x1, x8, x0, x6
    aee4:	aa0703e0 	mov	x0, x7
    aee8:	9b087c63 	mul	x3, x3, x8
    aeec:	b3607c20 	bfi	x0, x1, #32, #32
    aef0:	eb00007f 	cmp	x3, x0
    aef4:	54001088 	b.hi	b104 <__modti3+0x2b4>  // b.pmore
    aef8:	cb030000 	sub	x0, x0, x3
    aefc:	9ac52400 	lsr	x0, x0, x5
    af00:	d2800001 	mov	x1, #0x0                   	// #0
    af04:	b4000064 	cbz	x4, af10 <__modti3+0xc0>
    af08:	eb0003e0 	negs	x0, x0
    af0c:	da0103e1 	ngc	x1, x1
    af10:	d65f03c0 	ret
    af14:	dac01066 	clz	x6, x3
    af18:	eb03003f 	cmp	x1, x3
    af1c:	54ffff43 	b.cc	af04 <__modti3+0xb4>  // b.lo, b.ul, b.last
    af20:	93407cc5 	sxtw	x5, w6
    af24:	d2800808 	mov	x8, #0x40                  	// #64
    af28:	cb050108 	sub	x8, x8, x5
    af2c:	9ac62063 	lsl	x3, x3, x6
    af30:	9ac62025 	lsl	x5, x1, x6
    af34:	9ac82447 	lsr	x7, x2, x8
    af38:	aa0300e7 	orr	x7, x7, x3
    af3c:	9ac82423 	lsr	x3, x1, x8
    af40:	92407cec 	and	x12, x7, #0xffffffff
    af44:	d360fcea 	lsr	x10, x7, #32
    af48:	9ac82401 	lsr	x1, x0, x8
    af4c:	aa050021 	orr	x1, x1, x5
    af50:	9ac62042 	lsl	x2, x2, x6
    af54:	9ac62000 	lsl	x0, x0, x6
    af58:	9aca086b 	udiv	x11, x3, x10
    af5c:	9b0a8d63 	msub	x3, x11, x10, x3
    af60:	aa0b03e5 	mov	x5, x11
    af64:	9b0b7d89 	mul	x9, x12, x11
    af68:	93c18063 	extr	x3, x3, x1, #32
    af6c:	eb03013f 	cmp	x9, x3
    af70:	540000a9 	b.ls	af84 <__modti3+0x134>  // b.plast
    af74:	ab0300e3 	adds	x3, x7, x3
    af78:	d1000565 	sub	x5, x11, #0x1
    af7c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    af80:	54001168 	b.hi	b1ac <__modti3+0x35c>  // b.pmore
    af84:	cb090063 	sub	x3, x3, x9
    af88:	9aca086b 	udiv	x11, x3, x10
    af8c:	9b0a8d6a 	msub	x10, x11, x10, x3
    af90:	aa0b03e9 	mov	x9, x11
    af94:	9b0b7d8c 	mul	x12, x12, x11
    af98:	b3607d41 	bfi	x1, x10, #32, #32
    af9c:	eb01019f 	cmp	x12, x1
    afa0:	540000a9 	b.ls	afb4 <__modti3+0x164>  // b.plast
    afa4:	ab0100e1 	adds	x1, x7, x1
    afa8:	d1000569 	sub	x9, x11, #0x1
    afac:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    afb0:	54000f88 	b.hi	b1a0 <__modti3+0x350>  // b.pmore
    afb4:	aa058123 	orr	x3, x9, x5, lsl #32
    afb8:	92407c4b 	and	x11, x2, #0xffffffff
    afbc:	2a0903e9 	mov	w9, w9
    afc0:	d360fc4a 	lsr	x10, x2, #32
    afc4:	d360fc63 	lsr	x3, x3, #32
    afc8:	cb0c0021 	sub	x1, x1, x12
    afcc:	aa0a03ec 	mov	x12, x10
    afd0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    afd4:	9b0b7d25 	mul	x5, x9, x11
    afd8:	9b0b7c6b 	mul	x11, x3, x11
    afdc:	9b0a2d29 	madd	x9, x9, x10, x11
    afe0:	92407caa 	and	x10, x5, #0xffffffff
    afe4:	9b0c7c63 	mul	x3, x3, x12
    afe8:	8b458125 	add	x5, x9, x5, lsr #32
    afec:	8b0d0069 	add	x9, x3, x13
    aff0:	eb05017f 	cmp	x11, x5
    aff4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    aff8:	8b058149 	add	x9, x10, x5, lsl #32
    affc:	8b458063 	add	x3, x3, x5, lsr #32
    b000:	eb03003f 	cmp	x1, x3
    b004:	54000063 	b.cc	b010 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b008:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b00c:	54000082 	b.cs	b01c <__modti3+0x1cc>  // b.hs, b.nlast
    b010:	eb020129 	subs	x9, x9, x2
    b014:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b018:	cb070063 	sub	x3, x3, x7
    b01c:	eb090000 	subs	x0, x0, x9
    b020:	da030021 	sbc	x1, x1, x3
    b024:	9ac62400 	lsr	x0, x0, x6
    b028:	9ac82028 	lsl	x8, x1, x8
    b02c:	aa000100 	orr	x0, x8, x0
    b030:	9ac62421 	lsr	x1, x1, x6
    b034:	17ffffb4 	b	af04 <__modti3+0xb4>
    b038:	b5000062 	cbnz	x2, b044 <__modti3+0x1f4>
    b03c:	d2800023 	mov	x3, #0x1                   	// #1
    b040:	9ac20862 	udiv	x2, x3, x2
    b044:	dac01048 	clz	x8, x2
    b048:	aa0803e5 	mov	x5, x8
    b04c:	b5000668 	cbnz	x8, b118 <__modti3+0x2c8>
    b050:	cb020020 	sub	x0, x1, x2
    b054:	d360fc49 	lsr	x9, x2, #32
    b058:	92407c4a 	and	x10, x2, #0xffffffff
    b05c:	9ac90801 	udiv	x1, x0, x9
    b060:	9b098020 	msub	x0, x1, x9, x0
    b064:	9b0a7c21 	mul	x1, x1, x10
    b068:	93c78000 	extr	x0, x0, x7, #32
    b06c:	eb00003f 	cmp	x1, x0
    b070:	540000a9 	b.ls	b084 <__modti3+0x234>  // b.plast
    b074:	ab000040 	adds	x0, x2, x0
    b078:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b07c:	8b020003 	add	x3, x0, x2
    b080:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b084:	cb010001 	sub	x1, x0, x1
    b088:	9ac90820 	udiv	x0, x1, x9
    b08c:	9b098403 	msub	x3, x0, x9, x1
    b090:	aa0703e1 	mov	x1, x7
    b094:	9b0a7c00 	mul	x0, x0, x10
    b098:	b3607c61 	bfi	x1, x3, #32, #32
    b09c:	eb01001f 	cmp	x0, x1
    b0a0:	540000a9 	b.ls	b0b4 <__modti3+0x264>  // b.plast
    b0a4:	ab010041 	adds	x1, x2, x1
    b0a8:	8b020022 	add	x2, x1, x2
    b0ac:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b0b0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b0b4:	cb000020 	sub	x0, x1, x0
    b0b8:	17ffff91 	b	aefc <__modti3+0xac>
    b0bc:	eb0203e5 	negs	x5, x2
    b0c0:	aa0003e7 	mov	x7, x0
    b0c4:	da0303e8 	ngc	x8, x3
    b0c8:	aa0503e2 	mov	x2, x5
    b0cc:	aa0803e3 	mov	x3, x8
    b0d0:	aa0103e6 	mov	x6, x1
    b0d4:	b4ffed48 	cbz	x8, ae7c <__modti3+0x2c>
    b0d8:	eb01011f 	cmp	x8, x1
    b0dc:	54fff148 	b.hi	af04 <__modti3+0xb4>  // b.pmore
    b0e0:	dac01109 	clz	x9, x8
    b0e4:	2a0903e6 	mov	w6, w9
    b0e8:	b5fff1c9 	cbnz	x9, af20 <__modti3+0xd0>
    b0ec:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b0f0:	54000068 	b.hi	b0fc <__modti3+0x2ac>  // b.pmore
    b0f4:	eb050007 	subs	x7, x0, x5
    b0f8:	da080021 	sbc	x1, x1, x8
    b0fc:	aa0703e0 	mov	x0, x7
    b100:	17ffff81 	b	af04 <__modti3+0xb4>
    b104:	ab000040 	adds	x0, x2, x0
    b108:	8b020002 	add	x2, x0, x2
    b10c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b110:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b114:	17ffff79 	b	aef8 <__modti3+0xa8>
    b118:	9ac82042 	lsl	x2, x2, x8
    b11c:	d2800803 	mov	x3, #0x40                  	// #64
    b120:	cb080063 	sub	x3, x3, x8
    b124:	d360fc49 	lsr	x9, x2, #32
    b128:	9ac82027 	lsl	x7, x1, x8
    b12c:	92407c4a 	and	x10, x2, #0xffffffff
    b130:	9ac32426 	lsr	x6, x1, x3
    b134:	9ac32403 	lsr	x3, x0, x3
    b138:	aa070063 	orr	x3, x3, x7
    b13c:	9ac908c1 	udiv	x1, x6, x9
    b140:	9ac82007 	lsl	x7, x0, x8
    b144:	9b099820 	msub	x0, x1, x9, x6
    b148:	9b017d41 	mul	x1, x10, x1
    b14c:	93c38000 	extr	x0, x0, x3, #32
    b150:	eb00003f 	cmp	x1, x0
    b154:	540000a9 	b.ls	b168 <__modti3+0x318>  // b.plast
    b158:	ab000040 	adds	x0, x2, x0
    b15c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b160:	8b020006 	add	x6, x0, x2
    b164:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b168:	cb010000 	sub	x0, x0, x1
    b16c:	9ac90801 	udiv	x1, x0, x9
    b170:	9b098026 	msub	x6, x1, x9, x0
    b174:	aa0303e0 	mov	x0, x3
    b178:	9b017d41 	mul	x1, x10, x1
    b17c:	b3607cc0 	bfi	x0, x6, #32, #32
    b180:	eb00003f 	cmp	x1, x0
    b184:	540000a9 	b.ls	b198 <__modti3+0x348>  // b.plast
    b188:	ab000040 	adds	x0, x2, x0
    b18c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b190:	8b020003 	add	x3, x0, x2
    b194:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b198:	cb010000 	sub	x0, x0, x1
    b19c:	17ffffb0 	b	b05c <__modti3+0x20c>
    b1a0:	d1000969 	sub	x9, x11, #0x2
    b1a4:	8b070021 	add	x1, x1, x7
    b1a8:	17ffff83 	b	afb4 <__modti3+0x164>
    b1ac:	d1000965 	sub	x5, x11, #0x2
    b1b0:	8b070063 	add	x3, x3, x7
    b1b4:	17ffff74 	b	af84 <__modti3+0x134>
    b1b8:	d503201f 	nop
    b1bc:	d503201f 	nop

000000000000b1c0 <atexit>:
    b1c0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b1c4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b1c8:	d2800001 	mov	x1, #0x0                   	// #0
    b1cc:	910003fd 	mov	x29, sp
    b1d0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b1d4:	f9400442 	ldr	x2, [x2, #8]
    b1d8:	17ffdd6a 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b1dc <_fini>:
    b1dc:	d503201f 	nop
    b1e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b1e4:	910003fd 	mov	x29, sp
    b1e8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b1ec:	d65f03c0 	ret
