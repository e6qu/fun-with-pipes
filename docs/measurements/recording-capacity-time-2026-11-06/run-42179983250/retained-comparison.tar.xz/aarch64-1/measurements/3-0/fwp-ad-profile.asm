
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	90000045 	adrp	x5, a000 <_IO_stdin_used+0x410>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910340a5 	add	x5, x5, #0xd0
    2aa0:	90000044 	adrp	x4, a000 <_IO_stdin_used+0x410>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91036084 	add	x4, x4, #0xd8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000619 	bl	4334 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	910142a1 	add	x1, x21, #0x50
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x121e8>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9008c20 	str	x0, [x1, #280]
    2b2c:	94000821 	bl	4bb0 <fwp_now_ns>
    2b30:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2b34:	910f0000 	add	x0, x0, #0x3c0
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0x72c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91230042 	add	x2, x2, #0x8c0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	910142b5 	add	x21, x21, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943d2a0 	ldr	w0, [x21, #976]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2c4c:	910fc000 	add	x0, x0, #0x3f0
    2c50:	940005b9 	bl	4334 <fwp_trap>
    2c54:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2c58:	910f4000 	add	x0, x0, #0x3d0
    2c5c:	940005b6 	bl	4334 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff4a 	bl	2990 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeef 	bl	2850 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2ca0:	91112000 	add	x0, x0, #0x448
    2ca4:	940005a4 	bl	4334 <fwp_trap>
    2ca8:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2cac:	91106000 	add	x0, x0, #0x418
    2cb0:	940005a1 	bl	4334 <fwp_trap>
    2cb4:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x410>
    2cb8:	9111c000 	add	x0, x0, #0x470
    2cbc:	9400059e 	bl	4334 <fwp_trap>
    2cc0:	97fffef8 	bl	28a0 <__stack_chk_fail@plt>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	9100e000 	add	x0, x0, #0x38
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	9100e021 	add	x1, x1, #0x38
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	9100e000 	add	x0, x0, #0x38
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	9100e021 	add	x1, x1, #0x38
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x410>
    2eb4:	912b0021 	add	x1, x1, #0xac0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x410>
    3158:	912a8021 	add	x1, x1, #0xaa0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    3190:	912fe000 	add	x0, x0, #0xbf8
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    31c4:	911882a1 	add	x1, x21, #0x620
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    31d8:	912840a5 	add	x5, x5, #0xa10
    31dc:	911882a1 	add	x1, x21, #0x620
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911882b7 	add	x23, x21, #0x620
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911882b5 	add	x21, x21, #0x620
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911882b5 	add	x21, x21, #0x620
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3368:	912820a5 	add	x5, x5, #0xa08
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x740>
    339c:	91304042 	add	x2, x2, #0xc10
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x740>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	9131a042 	add	x2, x2, #0xc68
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000039 	adrp	x25, 9000 <fwp_main_thread+0x740>
    3428:	d000003a 	adrp	x26, 9000 <fwp_main_thread+0x740>
    342c:	91332339 	add	x25, x25, #0xcc8
    3430:	9130c35a 	add	x26, x26, #0xc30
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000003b 	adrp	x27, 9000 <fwp_main_thread+0x740>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	9130e377 	add	x23, x27, #0xc38
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	91342000 	add	x0, x0, #0xd08
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbc0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbc0>
    34fc:	d0000023 	adrp	x3, 9000 <fwp_main_thread+0x740>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000035 	adrp	x21, 9000 <fwp_main_thread+0x740>
    3508:	f9422024 	ldr	x4, [x1, #1088]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f94224a5 	ldr	x5, [x5, #1096]
    3514:	91110033 	add	x19, x1, #0x440
    3518:	f9422846 	ldr	x6, [x2, #1104]
    351c:	9130c063 	add	x3, x3, #0xc30
    3520:	913482b5 	add	x21, x21, #0xd20
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91358000 	add	x0, x0, #0xd60
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    35ac:	91310000 	add	x0, x0, #0xc40
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    366c:	912fe000 	add	x0, x0, #0xbf8
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9135a021 	add	x1, x1, #0xd68
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9135c021 	add	x1, x1, #0xd70
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    37e0:	9135e021 	add	x1, x1, #0xd78
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x740>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	91360084 	add	x4, x4, #0xd80
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbeb 	bl	2810 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc44 	bl	2980 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2f 	bl	2940 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbb0 	bl	27f0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffba1 	bl	27f0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb65 	bl	2730 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf5 	bl	2980 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x740>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	91366084 	add	x4, x4, #0xd98
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb76 	bl	2810 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb65 	bl	27f0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc5 	bl	2980 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x740>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	91362084 	add	x4, x4, #0xd88
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4e 	bl	2810 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb38 	bl	27f0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb0c 	bl	27f0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb28 	bl	28a0 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    3c0c:	91188042 	add	x2, x2, #0x620
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91368021 	add	x1, x1, #0xda0
    3c68:	9136a000 	add	x0, x0, #0xda8
    3c6c:	97fffaf1 	bl	2830 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb6d 	bl	2a50 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb1b 	bl	2940 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb5a 	bl	2a50 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffacb 	bl	2820 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x740>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	91372042 	add	x2, x2, #0xdc8
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaee 	b	2910 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97ffface 	bl	28a0 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9e0>
    3d78:	91148061 	add	x1, x3, #0x520
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    3d88:	91188262 	add	x2, x19, #0x620
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0x410>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9e0>
    3dbc:	91158021 	add	x1, x1, #0x560
    3dc0:	3dc2b443 	ldr	q3, [x2, #2768]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9e0>
    3dec:	91148063 	add	x3, x3, #0x520
    3df0:	91170084 	add	x4, x4, #0x5c0
    3df4:	91188266 	add	x6, x19, #0x620
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffab1 	bl	2930 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91188275 	add	x21, x19, #0x620
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa9b 	bl	2930 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    3ed8:	91394000 	add	x0, x0, #0xe50
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad4 	bl	2a30 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91188273 	add	x19, x19, #0x620
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc90 	bl	3170 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	91014122 	add	x2, x9, #0x50
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9406046 	ldr	x6, [x2, #192]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	91014120 	add	x0, x9, #0x50
    3fc4:	f900640b 	str	x11, [x0, #200]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	91014129 	add	x9, x9, #0x50
    3fd0:	f9006126 	str	x6, [x9, #192]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <ad_raw_free.part.0>:
    3ff0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbc0>
    3ff4:	d2800001 	mov	x1, #0x0                   	// #0
    3ff8:	91110082 	add	x2, x4, #0x440
    3ffc:	14000005 	b	4010 <ad_raw_free.part.0+0x20>
    4000:	91000421 	add	x1, x1, #0x1
    4004:	91006042 	add	x2, x2, #0x18
    4008:	f140043f 	cmp	x1, #0x1, lsl #12
    400c:	54000220 	b.eq	4050 <ad_raw_free.part.0+0x60>  // b.none
    4010:	f9400043 	ldr	x3, [x2]
    4014:	eb03001f 	cmp	x0, x3
    4018:	54ffff41 	b.ne	4000 <ad_raw_free.part.0+0x10>  // b.any
    401c:	8b010421 	add	x1, x1, x1, lsl #1
    4020:	91110084 	add	x4, x4, #0x440
    4024:	900000e2 	adrp	x2, 20000 <__data_start>
    4028:	91014042 	add	x2, x2, #0x50
    402c:	8b010c81 	add	x1, x4, x1, lsl #3
    4030:	b9401024 	ldr	w4, [x1, #16]
    4034:	f9400425 	ldr	x5, [x1, #8]
    4038:	a9007c3f 	stp	xzr, xzr, [x1]
    403c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4040:	f900083f 	str	xzr, [x1, #16]
    4044:	cb050061 	sub	x1, x3, x5
    4048:	f8247841 	str	x1, [x2, x4, lsl #3]
    404c:	17fffa45 	b	2960 <free@plt>
    4050:	f100001f 	cmp	x0, #0x0
    4054:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    4058:	9139e021 	add	x1, x1, #0xe78
    405c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4060:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4064:	91398000 	add	x0, x0, #0xe60
    4068:	910003fd 	mov	x29, sp
    406c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4070:	97fffcc4 	bl	3380 <ad_raw_fail>

0000000000004074 <fwp_tape_buffers_dispose>:
    4074:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4078:	910003fd 	mov	x29, sp
    407c:	f9000bf3 	str	x19, [sp, #16]
    4080:	aa0003f3 	mov	x19, x0
    4084:	f9400000 	ldr	x0, [x0]
    4088:	b4000040 	cbz	x0, 4090 <fwp_tape_buffers_dispose+0x1c>
    408c:	97ffffd9 	bl	3ff0 <ad_raw_free.part.0>
    4090:	f9400a60 	ldr	x0, [x19, #16]
    4094:	b4000040 	cbz	x0, 409c <fwp_tape_buffers_dispose+0x28>
    4098:	97ffffd6 	bl	3ff0 <ad_raw_free.part.0>
    409c:	f9401260 	ldr	x0, [x19, #32]
    40a0:	b4000040 	cbz	x0, 40a8 <fwp_tape_buffers_dispose+0x34>
    40a4:	97ffffd3 	bl	3ff0 <ad_raw_free.part.0>
    40a8:	4f000400 	movi	v0.4s, #0x0
    40ac:	f9001a7f 	str	xzr, [x19, #48]
    40b0:	ad000260 	stp	q0, q0, [x19]
    40b4:	3d800a60 	str	q0, [x19, #32]
    40b8:	f9400bf3 	ldr	x19, [sp, #16]
    40bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40c0:	d65f03c0 	ret

00000000000040c4 <ad_raw_realloc>:
    40c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	f90013f5 	str	x21, [sp, #32]
    40d4:	b40005a1 	cbz	x1, 4188 <ad_raw_realloc+0xc4>
    40d8:	aa0103f4 	mov	x20, x1
    40dc:	2a0203f5 	mov	w21, w2
    40e0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbc0>
    40e4:	d2800004 	mov	x4, #0x0                   	// #0
    40e8:	91110025 	add	x5, x1, #0x440
    40ec:	14000005 	b	4100 <ad_raw_realloc+0x3c>
    40f0:	91000484 	add	x4, x4, #0x1
    40f4:	910060a5 	add	x5, x5, #0x18
    40f8:	f140049f 	cmp	x4, #0x1, lsl #12
    40fc:	54000320 	b.eq	4160 <ad_raw_realloc+0x9c>  // b.none
    4100:	f94000a6 	ldr	x6, [x5]
    4104:	eb06001f 	cmp	x0, x6
    4108:	54ffff41 	b.ne	40f0 <ad_raw_realloc+0x2c>  // b.any
    410c:	8b040484 	add	x4, x4, x4, lsl #1
    4110:	91110021 	add	x1, x1, #0x440
    4114:	8b040c33 	add	x19, x1, x4, lsl #3
    4118:	b4000080 	cbz	x0, 4128 <ad_raw_realloc+0x64>
    411c:	b9401261 	ldr	w1, [x19, #16]
    4120:	6b15003f 	cmp	w1, w21
    4124:	540002c1 	b.ne	417c <ad_raw_realloc+0xb8>  // b.any
    4128:	aa1403e1 	mov	x1, x20
    412c:	97fff9d9 	bl	2890 <realloc@plt>
    4130:	aa0003ed 	mov	x13, x0
    4134:	b40000c0 	cbz	x0, 414c <ad_raw_realloc+0x88>
    4138:	2a1503e3 	mov	w3, w21
    413c:	aa1403e2 	mov	x2, x20
    4140:	aa1303e0 	mov	x0, x19
    4144:	aa0d03e1 	mov	x1, x13
    4148:	97fffb92 	bl	2f90 <ad_raw_record>
    414c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4150:	aa0d03e0 	mov	x0, x13
    4154:	f94013f5 	ldr	x21, [sp, #32]
    4158:	a8c37bfd 	ldp	x29, x30, [sp], #48
    415c:	d65f03c0 	ret
    4160:	f100001f 	cmp	x0, #0x0
    4164:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x740>
    4168:	9139e021 	add	x1, x1, #0xe78
    416c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4170:	91398000 	add	x0, x0, #0xe60
    4174:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4178:	97fffc82 	bl	3380 <ad_raw_fail>
    417c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4180:	913ae000 	add	x0, x0, #0xeb8
    4184:	97fffc7f 	bl	3380 <ad_raw_fail>
    4188:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    418c:	913a6000 	add	x0, x0, #0xe98
    4190:	97fffc7c 	bl	3380 <ad_raw_fail>

0000000000004194 <fwp_tape_buffers_release>:
    4194:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4198:	910003fd 	mov	x29, sp
    419c:	a90153f3 	stp	x19, x20, [sp, #16]
    41a0:	aa0003f4 	mov	x20, x0
    41a4:	f9401400 	ldr	x0, [x0, #40]
    41a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    41ac:	b7f80560 	tbnz	x0, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b0:	f9401a93 	ldr	x19, [x20, #48]
    41b4:	b7f80533 	tbnz	x19, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    41bc:	eb01001f 	cmp	x0, x1
    41c0:	540004c8 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41c4:	8b000400 	add	x0, x0, x0, lsl #1
    41c8:	d2a00101 	mov	x1, #0x80000               	// #524288
    41cc:	d37df000 	lsl	x0, x0, #3
    41d0:	cb000021 	sub	x1, x1, x0
    41d4:	eb410e7f 	cmp	x19, x1, lsr #3
    41d8:	54000408 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41dc:	8b130c13 	add	x19, x0, x19, lsl #3
    41e0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    41e4:	913b4000 	add	x0, x0, #0xed0
    41e8:	97fffa12 	bl	2a30 <getenv@plt>
    41ec:	b4000080 	cbz	x0, 41fc <fwp_tape_buffers_release+0x68>
    41f0:	39400001 	ldrb	w1, [x0]
    41f4:	7100c03f 	cmp	w1, #0x30
    41f8:	54000880 	b.eq	4308 <fwp_tape_buffers_release+0x174>  // b.none
    41fc:	d1000661 	sub	x1, x19, #0x1
    4200:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4204:	eb00003f 	cmp	x1, x0
    4208:	54000328 	b.hi	426c <fwp_tape_buffers_release+0xd8>  // b.pmore
    420c:	900000f5 	adrp	x21, 20000 <__data_start>
    4210:	f9001bf7 	str	x23, [sp, #48]
    4214:	910142b7 	add	x23, x21, #0x50
    4218:	910342f6 	add	x22, x23, #0xd0
    421c:	aa1603e0 	mov	x0, x22
    4220:	97ffff95 	bl	4074 <fwp_tape_buffers_dispose>
    4224:	ad400a81 	ldp	q1, q2, [x20]
    4228:	f90086f3 	str	x19, [x23, #264]
    422c:	4f000400 	movi	v0.4s, #0x0
    4230:	ad000ac1 	stp	q1, q2, [x22]
    4234:	3dc00a81 	ldr	q1, [x20, #32]
    4238:	3d800ac1 	str	q1, [x22, #32]
    423c:	f9401a80 	ldr	x0, [x20, #48]
    4240:	f9001ac0 	str	x0, [x22, #48]
    4244:	f9001a9f 	str	xzr, [x20, #48]
    4248:	ad000280 	stp	q0, q0, [x20]
    424c:	3d800a80 	str	q0, [x20, #32]
    4250:	f9401bf7 	ldr	x23, [sp, #48]
    4254:	1400000b 	b	4280 <fwp_tape_buffers_release+0xec>
    4258:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    425c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4260:	913b4000 	add	x0, x0, #0xed0
    4264:	97fff9f3 	bl	2a30 <getenv@plt>
    4268:	b5fffc40 	cbnz	x0, 41f0 <fwp_tape_buffers_release+0x5c>
    426c:	aa1403e0 	mov	x0, x20
    4270:	97ffff81 	bl	4074 <fwp_tape_buffers_dispose>
    4274:	900000f5 	adrp	x21, 20000 <__data_start>
    4278:	910142a0 	add	x0, x21, #0x50
    427c:	f9408413 	ldr	x19, [x0, #264]
    4280:	910142a2 	add	x2, x21, #0x50
    4284:	f9408844 	ldr	x4, [x2, #272]
    4288:	a9400c45 	ldp	x5, x3, [x2]
    428c:	8b040481 	add	x1, x4, x4, lsl #1
    4290:	f9400840 	ldr	x0, [x2, #16]
    4294:	8b010881 	add	x1, x4, x1, lsl #2
    4298:	f9400c44 	ldr	x4, [x2, #24]
    429c:	8b0300a3 	add	x3, x5, x3
    42a0:	d37df021 	lsl	x1, x1, #3
    42a4:	8b040000 	add	x0, x0, x4
    42a8:	8b030000 	add	x0, x0, x3
    42ac:	eb05003f 	cmp	x1, x5
    42b0:	54000321 	b.ne	4314 <fwp_tape_buffers_release+0x180>  // b.any
    42b4:	8b130023 	add	x3, x1, x19
    42b8:	eb00007f 	cmp	x3, x0
    42bc:	540002c8 	b.hi	4314 <fwp_tape_buffers_release+0x180>  // b.pmore
    42c0:	f9405c43 	ldr	x3, [x2, #184]
    42c4:	f140087f 	cmp	x3, #0x2, lsl #12
    42c8:	540002e0 	b.eq	4324 <fwp_tape_buffers_release+0x190>  // b.none
    42cc:	8b030464 	add	x4, x3, x3, lsl #1
    42d0:	90000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    42d4:	911100a5 	add	x5, x5, #0x440
    42d8:	cb010000 	sub	x0, x0, x1
    42dc:	d37df084 	lsl	x4, x4, #3
    42e0:	cb130000 	sub	x0, x0, x19
    42e4:	8b0400a6 	add	x6, x5, x4
    42e8:	91000463 	add	x3, x3, #0x1
    42ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42f0:	f82468a1 	str	x1, [x5, x4]
    42f4:	a90080d3 	stp	x19, x0, [x6, #8]
    42f8:	f9005c43 	str	x3, [x2, #184]
    42fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4300:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4304:	d65f03c0 	ret
    4308:	39400400 	ldrb	w0, [x0, #1]
    430c:	34fffb00 	cbz	w0, 426c <fwp_tape_buffers_release+0xd8>
    4310:	17ffffbb 	b	41fc <fwp_tape_buffers_release+0x68>
    4314:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4318:	913ba000 	add	x0, x0, #0xee8
    431c:	f9001bf7 	str	x23, [sp, #48]
    4320:	97fffc18 	bl	3380 <ad_raw_fail>
    4324:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4328:	913c6000 	add	x0, x0, #0xf18
    432c:	f9001bf7 	str	x23, [sp, #48]
    4330:	97fffc14 	bl	3380 <ad_raw_fail>

0000000000004334 <fwp_trap>:
    4334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4338:	900000e2 	adrp	x2, 20000 <__data_start>
    433c:	d53bd041 	mrs	x1, tpidr_el0
    4340:	910003fd 	mov	x29, sp
    4344:	f9407042 	ldr	x2, [x2, #224]
    4348:	91400021 	add	x1, x1, #0x0, lsl #12
    434c:	91004021 	add	x1, x1, #0x10
    4350:	a90153f3 	stp	x19, x20, [sp, #16]
    4354:	aa0003f3 	mov	x19, x0
    4358:	f9400034 	ldr	x20, [x1]
    435c:	b4000062 	cbz	x2, 4368 <fwp_trap+0x34>
    4360:	aa0203e0 	mov	x0, x2
    4364:	97fff99b 	bl	29d0 <fflush@plt>
    4368:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    436c:	f947ec00 	ldr	x0, [x0, #4056]
    4370:	f9400000 	ldr	x0, [x0]
    4374:	97fff997 	bl	29d0 <fflush@plt>
    4378:	aa1303e3 	mov	x3, x19
    437c:	b0000022 	adrp	x2, 9000 <fwp_main_thread+0x740>
    4380:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc90>
    4384:	f947ea73 	ldr	x19, [x19, #4048]
    4388:	913ce042 	add	x2, x2, #0xf38
    438c:	52800041 	mov	w1, #0x2                   	// #2
    4390:	f9400260 	ldr	x0, [x19]
    4394:	97fff95f 	bl	2910 <__fprintf_chk@plt>
    4398:	b40000b4 	cbz	x20, 43ac <fwp_trap+0x78>
    439c:	f9400260 	ldr	x0, [x19]
    43a0:	97fff98c 	bl	29d0 <fflush@plt>
    43a4:	52800ca0 	mov	w0, #0x65                  	// #101
    43a8:	97fff99a 	bl	2a10 <_Exit@plt>
    43ac:	52800ca0 	mov	w0, #0x65                  	// #101
    43b0:	97fff8e8 	bl	2750 <exit@plt>

00000000000043b4 <fwp_rc_forget_slot.part.0>:
    43b4:	ca404401 	eor	x1, x0, x0, lsr #17
    43b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43bc:	ca412421 	eor	x1, x1, x1, lsr #9
    43c0:	910003fd 	mov	x29, sp
    43c4:	92401c21 	and	x1, x1, #0xff
    43c8:	f9000bf3 	str	x19, [sp, #16]
    43cc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    43d0:	91188262 	add	x2, x19, #0x620
    43d4:	910a2423 	add	x3, x1, #0x289
    43d8:	8b010c41 	add	x1, x2, x1, lsl #3
    43dc:	8b030c43 	add	x3, x2, x3, lsl #3
    43e0:	f94a2421 	ldr	x1, [x1, #5192]
    43e4:	b50000a1 	cbnz	x1, 43f8 <fwp_rc_forget_slot.part.0+0x44>
    43e8:	14000012 	b	4430 <fwp_rc_forget_slot.part.0+0x7c>
    43ec:	91004023 	add	x3, x1, #0x10
    43f0:	f9400821 	ldr	x1, [x1, #16]
    43f4:	b40001e1 	cbz	x1, 4430 <fwp_rc_forget_slot.part.0+0x7c>
    43f8:	f9400022 	ldr	x2, [x1]
    43fc:	eb02001f 	cmp	x0, x2
    4400:	54ffff61 	b.ne	43ec <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4404:	f9400060 	ldr	x0, [x3]
    4408:	91188273 	add	x19, x19, #0x620
    440c:	f9400801 	ldr	x1, [x0, #16]
    4410:	f9000061 	str	x1, [x3]
    4414:	97fff953 	bl	2960 <free@plt>
    4418:	f94e2660 	ldr	x0, [x19, #7240]
    441c:	d1000400 	sub	x0, x0, #0x1
    4420:	f90e2660 	str	x0, [x19, #7240]
    4424:	f9400bf3 	ldr	x19, [sp, #16]
    4428:	a8c27bfd 	ldp	x29, x30, [sp], #32
    442c:	d65f03c0 	ret
    4430:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4434:	913d2000 	add	x0, x0, #0xf48
    4438:	97ffffbf 	bl	4334 <fwp_trap>
    443c:	d503201f 	nop

0000000000004440 <fwp_rc_prepare_chunk>:
    4440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4444:	910003fd 	mov	x29, sp
    4448:	a9025bf5 	stp	x21, x22, [sp, #32]
    444c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    4450:	911882c2 	add	x2, x22, #0x620
    4454:	b9401c03 	ldr	w3, [x0, #28]
    4458:	aa0103f5 	mov	x21, x1
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f4 	mov	x20, x0
    4464:	f94e2440 	ldr	x0, [x2, #7240]
    4468:	b4000440 	cbz	x0, 44f0 <fwp_rc_prepare_chunk+0xb0>
    446c:	d2800013 	mov	x19, #0x0                   	// #0
    4470:	35000203 	cbnz	w3, 44b0 <fwp_rc_prepare_chunk+0x70>
    4474:	b4000361 	cbz	x1, 44e0 <fwp_rc_prepare_chunk+0xa0>
    4478:	f9401280 	ldr	x0, [x20, #32]
    447c:	97fff939 	bl	2960 <free@plt>
    4480:	aa1503e0 	mov	x0, x21
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	97fff8fe 	bl	2880 <calloc@plt>
    448c:	f9001280 	str	x0, [x20, #32]
    4490:	b5000460 	cbnz	x0, 451c <fwp_rc_prepare_chunk+0xdc>
    4494:	97fffb37 	bl	3170 <fwp_heap_oom>
    4498:	97ffffc7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    449c:	91000673 	add	x19, x19, #0x1
    44a0:	b9401e83 	ldr	w3, [x20, #28]
    44a4:	eb13007f 	cmp	x3, x19
    44a8:	54000169 	b.ls	44d4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    44ac:	d503201f 	nop
    44b0:	f9401283 	ldr	x3, [x20, #32]
    44b4:	8b130060 	add	x0, x3, x19
    44b8:	38736863 	ldrb	w3, [x3, x19]
    44bc:	7103fc7f 	cmp	w3, #0xff
    44c0:	54fffec0 	b.eq	4498 <fwp_rc_prepare_chunk+0x58>  // b.none
    44c4:	b9401e83 	ldr	w3, [x20, #28]
    44c8:	91000673 	add	x19, x19, #0x1
    44cc:	eb13007f 	cmp	x3, x19
    44d0:	54ffff08 	b.hi	44b0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    44d4:	eb0302bf 	cmp	x21, x3
    44d8:	54000121 	b.ne	44fc <fwp_rc_prepare_chunk+0xbc>  // b.any
    44dc:	b5000335 	cbnz	x21, 4540 <fwp_rc_prepare_chunk+0x100>
    44e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	2a0303e3 	mov	w3, w3
    44f4:	eb0302bf 	cmp	x21, x3
    44f8:	54ffff20 	b.eq	44dc <fwp_rc_prepare_chunk+0x9c>  // b.none
    44fc:	911882c2 	add	x2, x22, #0x620
    4500:	f9401280 	ldr	x0, [x20, #32]
    4504:	f94e2841 	ldr	x1, [x2, #7248]
    4508:	cb030021 	sub	x1, x1, x3
    450c:	f90e2841 	str	x1, [x2, #7248]
    4510:	97fff914 	bl	2960 <free@plt>
    4514:	b5fffb75 	cbnz	x21, 4480 <fwp_rc_prepare_chunk+0x40>
    4518:	f900129f 	str	xzr, [x20, #32]
    451c:	911882d6 	add	x22, x22, #0x620
    4520:	f94e2ac0 	ldr	x0, [x22, #7248]
    4524:	b9001e95 	str	w21, [x20, #28]
    4528:	a94153f3 	ldp	x19, x20, [sp, #16]
    452c:	8b150000 	add	x0, x0, x21
    4530:	f90e2ac0 	str	x0, [x22, #7248]
    4534:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f9401280 	ldr	x0, [x20, #32]
    4544:	aa1503e2 	mov	x2, x21
    4548:	a94153f3 	ldp	x19, x20, [sp, #16]
    454c:	52800001 	mov	w1, #0x0                   	// #0
    4550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4558:	17fff8c6 	b	2870 <memset@plt>
    455c:	d503201f 	nop

0000000000004560 <fwp_heap_refill>:
    4560:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4564:	910003fd 	mov	x29, sp
    4568:	a9025bf5 	stp	x21, x22, [sp, #32]
    456c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4570:	911882b5 	add	x21, x21, #0x620
    4574:	aa0003f6 	mov	x22, x0
    4578:	d2800020 	mov	x0, #0x1                   	// #1
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	a90363f7 	stp	x23, x24, [sp, #48]
    4584:	2a0103f7 	mov	w23, w1
    4588:	2a0203f8 	mov	w24, w2
    458c:	97fffb09 	bl	31b0 <fwp_heap_chunks>
    4590:	aa0003f3 	mov	x19, x0
    4594:	f949fea2 	ldr	x2, [x21, #5112]
    4598:	8b000800 	add	x0, x0, x0, lsl #2
    459c:	2a1703e1 	mov	w1, w23
    45a0:	52800025 	mov	w5, #0x1                   	// #1
    45a4:	d37df000 	lsl	x0, x0, #3
    45a8:	910f0021 	add	x1, x1, #0x3c0
    45ac:	8b000054 	add	x20, x2, x0
    45b0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    45b4:	52a00024 	mov	w4, #0x10000               	// #65536
    45b8:	38206845 	strb	w5, [x2, x0]
    45bc:	aa1403e0 	mov	x0, x20
    45c0:	39000698 	strb	w24, [x20, #1]
    45c4:	39000a97 	strb	w23, [x20, #2]
    45c8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    45cc:	b9000681 	str	w1, [x20, #4]
    45d0:	2a0103e5 	mov	w5, w1
    45d4:	8b0300a2 	add	x2, x5, x3
    45d8:	1ac10881 	udiv	w1, w4, w1
    45dc:	9ac50842 	udiv	x2, x2, x5
    45e0:	b9000a81 	str	w1, [x20, #8]
    45e4:	92404021 	and	x1, x1, #0x1ffff
    45e8:	b9001a82 	str	w2, [x20, #24]
    45ec:	97ffff95 	bl	4440 <fwp_rc_prepare_chunk>
    45f0:	f949daa0 	ldr	x0, [x21, #5040]
    45f4:	29408a81 	ldp	w1, w2, [x20, #4]
    45f8:	8b134000 	add	x0, x0, x19, lsl #16
    45fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4600:	8b214003 	add	x3, x0, w1, uxtw
    4604:	9ba20021 	umaddl	x1, w1, w2, x0
    4608:	a94363f7 	ldp	x23, x24, [sp, #48]
    460c:	a90086c3 	stp	x3, x1, [x22, #8]
    4610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4614:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4618:	d65f03c0 	ret
    461c:	d503201f 	nop

0000000000004620 <fwp_mem_free>:
    4620:	b40003c0 	cbz	x0, 4698 <fwp_mem_free+0x78>
    4624:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4628:	910003fd 	mov	x29, sp
    462c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4630:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4634:	911882a1 	add	x1, x21, #0x620
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	aa0003f3 	mov	x19, x0
    4640:	f949d823 	ldr	x3, [x1, #5040]
    4644:	f949ec22 	ldr	x2, [x1, #5080]
    4648:	cb030000 	sub	x0, x0, x3
    464c:	eb02401f 	cmp	x0, x2, lsl #16
    4650:	540001c2 	b.cs	4688 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4654:	d350fc16 	lsr	x22, x0, #16
    4658:	a90363f7 	stp	x23, x24, [sp, #48]
    465c:	f949fc22 	ldr	x2, [x1, #5112]
    4660:	8b160ad4 	add	x20, x22, x22, lsl #2
    4664:	d37df294 	lsl	x20, x20, #3
    4668:	ab140057 	adds	x23, x2, x20
    466c:	540000c0 	b.eq	4684 <fwp_mem_free+0x64>  // b.none
    4670:	38746842 	ldrb	w2, [x2, x20]
    4674:	7100045f 	cmp	w2, #0x1
    4678:	54000120 	b.eq	469c <fwp_mem_free+0x7c>  // b.none
    467c:	7100085f 	cmp	w2, #0x2
    4680:	540005e0 	b.eq	473c <fwp_mem_free+0x11c>  // b.none
    4684:	a94363f7 	ldp	x23, x24, [sp, #48]
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4690:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4694:	d65f03c0 	ret
    4698:	d65f03c0 	ret
    469c:	f94012f8 	ldr	x24, [x23, #32]
    46a0:	b94006e1 	ldr	w1, [x23, #4]
    46a4:	f90023f9 	str	x25, [sp, #64]
    46a8:	2a0103e2 	mov	w2, w1
    46ac:	394006f9 	ldrb	w25, [x23, #1]
    46b0:	39400af4 	ldrb	w20, [x23, #2]
    46b4:	b4000158 	cbz	x24, 46dc <fwp_mem_free+0xbc>
    46b8:	92403e76 	and	x22, x19, #0xffff
    46bc:	9ac20ad6 	udiv	x22, x22, x2
    46c0:	38766b01 	ldrb	w1, [x24, x22]
    46c4:	8b160300 	add	x0, x24, x22
    46c8:	7103fc3f 	cmp	w1, #0xff
    46cc:	54000980 	b.eq	47fc <fwp_mem_free+0x1dc>  // b.none
    46d0:	38366b1f 	strb	wzr, [x24, x22]
    46d4:	b94006e1 	ldr	w1, [x23, #4]
    46d8:	2a0103e2 	mov	w2, w1
    46dc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    46e0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    46e4:	cb390000 	sub	x0, x0, w25, uxtb
    46e8:	8b340074 	add	x20, x3, w20, uxtb
    46ec:	911882b5 	add	x21, x21, #0x620
    46f0:	1e630021 	ucvtf	d1, w1
    46f4:	d37ae400 	lsl	x0, x0, #6
    46f8:	8b140c14 	add	x20, x0, x20, lsl #3
    46fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4700:	f8746aa0 	ldr	x0, [x21, x20]
    4704:	f94023f9 	ldr	x25, [sp, #64]
    4708:	aa2003e0 	mvn	x0, x0
    470c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4710:	f9000260 	str	x0, [x19]
    4714:	f8346ab3 	str	x19, [x21, x20]
    4718:	f94a12a0 	ldr	x0, [x21, #5152]
    471c:	1e612800 	fadd	d0, d0, d1
    4720:	a94153f3 	ldp	x19, x20, [sp, #16]
    4724:	cb020000 	sub	x0, x0, x2
    4728:	f90a12a0 	str	x0, [x21, #5152]
    472c:	fd0a22a0 	str	d0, [x21, #5184]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4738:	d65f03c0 	ret
    473c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4740:	8b000063 	add	x3, x3, x0
    4744:	eb03027f 	cmp	x19, x3
    4748:	54fff9e1 	b.ne	4684 <fwp_mem_free+0x64>  // b.any
    474c:	fd400ae1 	ldr	d1, [x23, #16]
    4750:	fd4a2020 	ldr	d0, [x1, #5184]
    4754:	f9400ae0 	ldr	x0, [x23, #16]
    4758:	7e61d821 	ucvtf	d1, d1
    475c:	f94a1022 	ldr	x2, [x1, #5152]
    4760:	f94012f3 	ldr	x19, [x23, #32]
    4764:	1e612800 	fadd	d0, d0, d1
    4768:	cb000042 	sub	x2, x2, x0
    476c:	f90a1022 	str	x2, [x1, #5152]
    4770:	fd0a2020 	str	d0, [x1, #5184]
    4774:	b40000b3 	cbz	x19, 4788 <fwp_mem_free+0x168>
    4778:	39400260 	ldrb	w0, [x19]
    477c:	7103fc1f 	cmp	w0, #0xff
    4780:	54000380 	b.eq	47f0 <fwp_mem_free+0x1d0>  // b.none
    4784:	3900027f 	strb	wzr, [x19]
    4788:	b9400ee2 	ldr	w2, [x23, #12]
    478c:	b4000142 	cbz	x2, 47b4 <fwp_mem_free+0x194>
    4790:	911882a1 	add	x1, x21, #0x620
    4794:	8b160040 	add	x0, x2, x22
    4798:	8b000800 	add	x0, x0, x0, lsl #2
    479c:	f949fc21 	ldr	x1, [x1, #5112]
    47a0:	8b140034 	add	x20, x1, x20
    47a4:	8b000c20 	add	x0, x1, x0, lsl #3
    47a8:	3802869f 	strb	wzr, [x20], #40
    47ac:	eb00029f 	cmp	x20, x0
    47b0:	54ffffc1 	b.ne	47a8 <fwp_mem_free+0x188>  // b.any
    47b4:	911882a0 	add	x0, x21, #0x620
    47b8:	f94a1801 	ldr	x1, [x0, #5168]
    47bc:	f949f803 	ldr	x3, [x0, #5104]
    47c0:	8b020021 	add	x1, x1, x2
    47c4:	f90a1801 	str	x1, [x0, #5168]
    47c8:	eb16007f 	cmp	x3, x22
    47cc:	54000049 	b.ls	47d4 <fwp_mem_free+0x1b4>  // b.plast
    47d0:	f909f816 	str	x22, [x0, #5104]
    47d4:	911882b5 	add	x21, x21, #0x620
    47d8:	f949f6a0 	ldr	x0, [x21, #5096]
    47dc:	eb16001f 	cmp	x0, x22
    47e0:	54fff529 	b.ls	4684 <fwp_mem_free+0x64>  // b.plast
    47e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47e8:	f909f6b6 	str	x22, [x21, #5096]
    47ec:	17ffffa7 	b	4688 <fwp_mem_free+0x68>
    47f0:	aa1303e0 	mov	x0, x19
    47f4:	97fffef0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    47f8:	17ffffe3 	b	4784 <fwp_mem_free+0x164>
    47fc:	97fffeee 	bl	43b4 <fwp_rc_forget_slot.part.0>
    4800:	17ffffb4 	b	46d0 <fwp_mem_free+0xb0>

0000000000004804 <fwp_rc_wide_dup>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	910003fd 	mov	x29, sp
    480c:	a90153f3 	stp	x19, x20, [sp, #16]
    4810:	aa0003f3 	mov	x19, x0
    4814:	ca404400 	eor	x0, x0, x0, lsr #17
    4818:	f90013f5 	str	x21, [sp, #32]
    481c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4820:	ca402400 	eor	x0, x0, x0, lsr #9
    4824:	911882a2 	add	x2, x21, #0x620
    4828:	92401c00 	and	x0, x0, #0xff
    482c:	910a2403 	add	x3, x0, #0x289
    4830:	8b000c40 	add	x0, x2, x0, lsl #3
    4834:	8b030c54 	add	x20, x2, x3, lsl #3
    4838:	f94a2401 	ldr	x1, [x0, #5192]
    483c:	b50000a1 	cbnz	x1, 4850 <fwp_rc_wide_dup+0x4c>
    4840:	14000033 	b	490c <fwp_rc_wide_dup+0x108>
    4844:	91004034 	add	x20, x1, #0x10
    4848:	f9400821 	ldr	x1, [x1, #16]
    484c:	b4000241 	cbz	x1, 4894 <fwp_rc_wide_dup+0x90>
    4850:	f9400022 	ldr	x2, [x1]
    4854:	eb02027f 	cmp	x19, x2
    4858:	54ffff61 	b.ne	4844 <fwp_rc_wide_dup+0x40>  // b.any
    485c:	f9400281 	ldr	x1, [x20]
    4860:	39400260 	ldrb	w0, [x19]
    4864:	7103f81f 	cmp	w0, #0xfe
    4868:	54000220 	b.eq	48ac <fwp_rc_wide_dup+0xa8>  // b.none
    486c:	b40001a1 	cbz	x1, 48a0 <fwp_rc_wide_dup+0x9c>
    4870:	f9400420 	ldr	x0, [x1, #8]
    4874:	b100041f 	cmn	x0, #0x1
    4878:	54000440 	b.eq	4900 <fwp_rc_wide_dup+0xfc>  // b.none
    487c:	91000400 	add	x0, x0, #0x1
    4880:	f9000420 	str	x0, [x1, #8]
    4884:	a94153f3 	ldp	x19, x20, [sp, #16]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	39400260 	ldrb	w0, [x19]
    4898:	7103f81f 	cmp	w0, #0xfe
    489c:	54000100 	b.eq	48bc <fwp_rc_wide_dup+0xb8>  // b.none
    48a0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    48a4:	913d2000 	add	x0, x0, #0xf48
    48a8:	97fffea3 	bl	4334 <fwp_trap>
    48ac:	b4000081 	cbz	x1, 48bc <fwp_rc_wide_dup+0xb8>
    48b0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    48b4:	913dc000 	add	x0, x0, #0xf70
    48b8:	97fffe9f 	bl	4334 <fwp_trap>
    48bc:	d2800300 	mov	x0, #0x18                  	// #24
    48c0:	97fff7e0 	bl	2840 <malloc@plt>
    48c4:	b4000280 	cbz	x0, 4914 <fwp_rc_wide_dup+0x110>
    48c8:	d2801fe1 	mov	x1, #0xff                  	// #255
    48cc:	a9000413 	stp	x19, x1, [x0]
    48d0:	911882b5 	add	x21, x21, #0x620
    48d4:	f900081f 	str	xzr, [x0, #16]
    48d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    48dc:	f9000280 	str	x0, [x20]
    48e0:	39000261 	strb	w1, [x19]
    48e4:	f94e26a0 	ldr	x0, [x21, #7240]
    48e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f90e26a0 	str	x0, [x21, #7240]
    48f4:	f94013f5 	ldr	x21, [sp, #32]
    48f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48fc:	d65f03c0 	ret
    4900:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4904:	913e6000 	add	x0, x0, #0xf98
    4908:	97fffe8b 	bl	4334 <fwp_trap>
    490c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4910:	17ffffd4 	b	4860 <fwp_rc_wide_dup+0x5c>
    4914:	97fffa17 	bl	3170 <fwp_heap_oom>
    4918:	d503201f 	nop
    491c:	d503201f 	nop

0000000000004920 <fwp_closure_drop_push>:
    4920:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4924:	910003fd 	mov	x29, sp
    4928:	a90153f3 	stp	x19, x20, [sp, #16]
    492c:	aa0003f3 	mov	x19, x0
    4930:	a9408014 	ldp	x20, x0, [x0, #8]
    4934:	a9025bf5 	stp	x21, x22, [sp, #32]
    4938:	aa0103f5 	mov	x21, x1
    493c:	a90363f7 	stp	x23, x24, [sp, #48]
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000160 	b.eq	4970 <fwp_closure_drop_push+0x50>  // b.none
    4948:	f9400276 	ldr	x22, [x19]
    494c:	d37df297 	lsl	x23, x20, #3
    4950:	91000694 	add	x20, x20, #0x1
    4954:	f9000674 	str	x20, [x19, #8]
    4958:	a94153f3 	ldp	x19, x20, [sp, #16]
    495c:	f8376ad5 	str	x21, [x22, x23]
    4960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4964:	a94363f7 	ldp	x23, x24, [sp, #48]
    4968:	a8c57bfd 	ldp	x29, x30, [sp], #80
    496c:	d65f03c0 	ret
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4978:	eb00029f 	cmp	x20, x0
    497c:	540003e8 	b.hi	49f8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4980:	d37cee99 	lsl	x25, x20, #4
    4984:	d37ffa9a 	lsl	x26, x20, #1
    4988:	aa1903e0 	mov	x0, x25
    498c:	97fff7ad 	bl	2840 <malloc@plt>
    4990:	aa0003f6 	mov	x22, x0
    4994:	b4000380 	cbz	x0, 4a04 <fwp_closure_drop_push+0xe4>
    4998:	aa1303f8 	mov	x24, x19
    499c:	aa1903e3 	mov	x3, x25
    49a0:	d37df297 	lsl	x23, x20, #3
    49a4:	aa1703e2 	mov	x2, x23
    49a8:	f8418719 	ldr	x25, [x24], #24
    49ac:	aa1903e1 	mov	x1, x25
    49b0:	97fff790 	bl	27f0 <__memcpy_chk@plt>
    49b4:	eb18033f 	cmp	x25, x24
    49b8:	540000a0 	b.eq	49cc <fwp_closure_drop_push+0xac>  // b.none
    49bc:	aa1903e0 	mov	x0, x25
    49c0:	97fff7e8 	bl	2960 <free@plt>
    49c4:	f9400674 	ldr	x20, [x19, #8]
    49c8:	d37df297 	lsl	x23, x20, #3
    49cc:	91000694 	add	x20, x20, #0x1
    49d0:	f9000276 	str	x22, [x19]
    49d4:	f9000a7a 	str	x26, [x19, #16]
    49d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    49dc:	f9000674 	str	x20, [x19, #8]
    49e0:	f8376ad5 	str	x21, [x22, x23]
    49e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    49f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49f4:	d65f03c0 	ret
    49f8:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    49fc:	913ee000 	add	x0, x0, #0xfb8
    4a00:	97fffe4d 	bl	4334 <fwp_trap>
    4a04:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a08:	f947e863 	ldr	x3, [x3, #4048]
    4a0c:	d2800262 	mov	x2, #0x13                  	// #19
    4a10:	d2800021 	mov	x1, #0x1                   	// #1
    4a14:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4a18:	912fe000 	add	x0, x0, #0xbf8
    4a1c:	f9400063 	ldr	x3, [x3]
    4a20:	97fff7e0 	bl	29a0 <fwrite@plt>
    4a24:	d2800000 	mov	x0, #0x0                   	// #0
    4a28:	97fff7ea 	bl	29d0 <fflush@plt>
    4a2c:	52800cc0 	mov	w0, #0x66                  	// #102
    4a30:	97fff7f8 	bl	2a10 <_Exit@plt>

0000000000004a34 <fwp_closure_drop.part.0>:
    4a34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a38:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0x410>
    4a3c:	910003fd 	mov	x29, sp
    4a40:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a44:	f947f463 	ldr	x3, [x3, #4072]
    4a48:	a90153f3 	stp	x19, x20, [sp, #16]
    4a4c:	d10883ff 	sub	sp, sp, #0x220
    4a50:	910003e2 	mov	x2, sp
    4a54:	d53bd053 	mrs	x19, tpidr_el0
    4a58:	910063f4 	add	x20, sp, #0x18
    4a5c:	3dc2b820 	ldr	q0, [x1, #2784]
    4a60:	91400264 	add	x4, x19, #0x0, lsl #12
    4a64:	91004084 	add	x4, x4, #0x10
    4a68:	aa0003e1 	mov	x1, x0
    4a6c:	aa0203e0 	mov	x0, x2
    4a70:	f9400062 	ldr	x2, [x3]
    4a74:	f9010fe2 	str	x2, [sp, #536]
    4a78:	d2800002 	mov	x2, #0x0                   	// #0
    4a7c:	f90003f4 	str	x20, [sp]
    4a80:	f9000080 	str	x0, [x4]
    4a84:	3c8083e0 	stur	q0, [sp, #8]
    4a88:	97ffffa6 	bl	4920 <fwp_closure_drop_push>
    4a8c:	f94007e0 	ldr	x0, [sp, #8]
    4a90:	b40002e0 	cbz	x0, 4aec <fwp_closure_drop.part.0+0xb8>
    4a94:	f90123f5 	str	x21, [sp, #576]
    4a98:	900000f5 	adrp	x21, 20000 <__data_start>
    4a9c:	910142b5 	add	x21, x21, #0x50
    4aa0:	14000006 	b	4ab8 <fwp_closure_drop.part.0+0x84>
    4aa4:	f9400422 	ldr	x2, [x1, #8]
    4aa8:	52800001 	mov	w1, #0x0                   	// #0
    4aac:	d63f0040 	blr	x2
    4ab0:	f94007e0 	ldr	x0, [sp, #8]
    4ab4:	b40001a0 	cbz	x0, 4ae8 <fwp_closure_drop.part.0+0xb4>
    4ab8:	f94003e1 	ldr	x1, [sp]
    4abc:	d1000400 	sub	x0, x0, #0x1
    4ac0:	f90007e0 	str	x0, [sp, #8]
    4ac4:	f9408ea2 	ldr	x2, [x21, #280]
    4ac8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4acc:	b9400001 	ldr	w1, [x0]
    4ad0:	8b011441 	add	x1, x2, x1, lsl #5
    4ad4:	f9400c21 	ldr	x1, [x1, #24]
    4ad8:	b5fffe61 	cbnz	x1, 4aa4 <fwp_closure_drop.part.0+0x70>
    4adc:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    4ae0:	913f6000 	add	x0, x0, #0xfd8
    4ae4:	97fffe14 	bl	4334 <fwp_trap>
    4ae8:	f94123f5 	ldr	x21, [sp, #576]
    4aec:	91400273 	add	x19, x19, #0x0, lsl #12
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	f94003e0 	ldr	x0, [sp]
    4af8:	f900027f 	str	xzr, [x19]
    4afc:	eb14001f 	cmp	x0, x20
    4b00:	54000040 	b.eq	4b08 <fwp_closure_drop.part.0+0xd4>  // b.none
    4b04:	97fff797 	bl	2960 <free@plt>
    4b08:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4b0c:	f947f400 	ldr	x0, [x0, #4072]
    4b10:	f9410fe2 	ldr	x2, [sp, #536]
    4b14:	f9400001 	ldr	x1, [x0]
    4b18:	eb010042 	subs	x2, x2, x1
    4b1c:	d2800001 	mov	x1, #0x0                   	// #0
    4b20:	540000a1 	b.ne	4b34 <fwp_closure_drop.part.0+0x100>  // b.any
    4b24:	910883ff 	add	sp, sp, #0x220
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b30:	d65f03c0 	ret
    4b34:	f90123f5 	str	x21, [sp, #576]
    4b38:	97fff75a 	bl	28a0 <__stack_chk_fail@plt>
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_tape_of>:
    4b40:	aa0003e1 	mov	x1, x0
    4b44:	92403c00 	and	x0, x0, #0xffff
    4b48:	b40000e0 	cbz	x0, 4b64 <fwp_tape_of+0x24>
    4b4c:	d1000402 	sub	x2, x0, #0x1
    4b50:	900000e0 	adrp	x0, 20000 <__data_start>
    4b54:	91014000 	add	x0, x0, #0x50
    4b58:	f9409003 	ldr	x3, [x0, #288]
    4b5c:	eb02007f 	cmp	x3, x2
    4b60:	540000cc 	b.gt	4b78 <fwp_tape_of+0x38>
    4b64:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b68:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    4b6c:	91002000 	add	x0, x0, #0x8
    4b70:	910003fd 	mov	x29, sp
    4b74:	97fffdf0 	bl	4334 <fwp_trap>
    4b78:	8b020443 	add	x3, x2, x2, lsl #1
    4b7c:	f9404404 	ldr	x4, [x0, #136]
    4b80:	8b030842 	add	x2, x2, x3, lsl #2
    4b84:	d37df042 	lsl	x2, x2, #3
    4b88:	8b020080 	add	x0, x4, x2
    4b8c:	b9400403 	ldr	w3, [x0, #4]
    4b90:	34fffea3 	cbz	w3, 4b64 <fwp_tape_of+0x24>
    4b94:	b8626882 	ldr	w2, [x4, x2]
    4b98:	9350fc21 	asr	x1, x1, #16
    4b9c:	6b01005f 	cmp	w2, w1
    4ba0:	54fffe21 	b.ne	4b64 <fwp_tape_of+0x24>  // b.any
    4ba4:	d65f03c0 	ret
    4ba8:	d503201f 	nop
    4bac:	d503201f 	nop

0000000000004bb0 <fwp_now_ns>:
    4bb0:	d100c3ff 	sub	sp, sp, #0x30
    4bb4:	52800020 	mov	w0, #0x1                   	// #1
    4bb8:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    4bbc:	f947f442 	ldr	x2, [x2, #4072]
    4bc0:	910023e1 	add	x1, sp, #0x8
    4bc4:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bc8:	910083fd 	add	x29, sp, #0x20
    4bcc:	f9400043 	ldr	x3, [x2]
    4bd0:	f9000fe3 	str	x3, [sp, #24]
    4bd4:	d2800003 	mov	x3, #0x0                   	// #0
    4bd8:	97fff6fe 	bl	27d0 <clock_gettime@plt>
    4bdc:	350002c0 	cbnz	w0, 4c34 <fwp_now_ns+0x84>
    4be0:	a9408be1 	ldp	x1, x2, [sp, #8]
    4be4:	d2994003 	mov	x3, #0xca00                	// #51712
    4be8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4bec:	9b037c20 	mul	x0, x1, x3
    4bf0:	9b437c21 	smulh	x1, x1, x3
    4bf4:	ab020000 	adds	x0, x0, x2
    4bf8:	937ffc42 	asr	x2, x2, #63
    4bfc:	9a020021 	adc	x1, x1, x2
    4c00:	f100001f 	cmp	x0, #0x0
    4c04:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4c08:	b50001c1 	cbnz	x1, 4c40 <fwp_now_ns+0x90>
    4c0c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    4c10:	f947f421 	ldr	x1, [x1, #4072]
    4c14:	f9400fe3 	ldr	x3, [sp, #24]
    4c18:	f9400022 	ldr	x2, [x1]
    4c1c:	eb020063 	subs	x3, x3, x2
    4c20:	d2800002 	mov	x2, #0x0                   	// #0
    4c24:	54000141 	b.ne	4c4c <fwp_now_ns+0x9c>  // b.any
    4c28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c2c:	9100c3ff 	add	sp, sp, #0x30
    4c30:	d65f03c0 	ret
    4c34:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    4c38:	91016000 	add	x0, x0, #0x58
    4c3c:	97fffdbe 	bl	4334 <fwp_trap>
    4c40:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    4c44:	9101e000 	add	x0, x0, #0x78
    4c48:	97fffdbb 	bl	4334 <fwp_trap>
    4c4c:	97fff715 	bl	28a0 <__stack_chk_fail@plt>

0000000000004c50 <fwp_poll_events>:
    4c50:	d10103ff 	sub	sp, sp, #0x40
    4c54:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4c58:	f947f400 	ldr	x0, [x0, #4072]
    4c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c60:	910083fd 	add	x29, sp, #0x20
    4c64:	f9001bf3 	str	x19, [sp, #48]
    4c68:	900000f3 	adrp	x19, 20000 <__data_start>
    4c6c:	f9400001 	ldr	x1, [x0]
    4c70:	f9000fe1 	str	x1, [sp, #24]
    4c74:	d2800001 	mov	x1, #0x0                   	// #0
    4c78:	97ffffce 	bl	4bb0 <fwp_now_ns>
    4c7c:	91014261 	add	x1, x19, #0x50
    4c80:	f9409421 	ldr	x1, [x1, #296]
    4c84:	b4000e01 	cbz	x1, 4e44 <fwp_poll_events+0x1f4>
    4c88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c8c:	14000005 	b	4ca0 <fwp_poll_events+0x50>
    4c90:	f9408821 	ldr	x1, [x1, #272]
    4c94:	eb03005f 	cmp	x2, x3
    4c98:	9a83d042 	csel	x2, x2, x3, le
    4c9c:	b40000c1 	cbz	x1, 4cb4 <fwp_poll_events+0x64>
    4ca0:	f9403423 	ldr	x3, [x1, #104]
    4ca4:	b6ffff62 	tbz	x2, #63, 4c90 <fwp_poll_events+0x40>
    4ca8:	f9408821 	ldr	x1, [x1, #272]
    4cac:	aa0303e2 	mov	x2, x3
    4cb0:	b5ffff81 	cbnz	x1, 4ca0 <fwp_poll_events+0x50>
    4cb4:	b7f80c82 	tbnz	x2, #63, 4e44 <fwp_poll_events+0x1f4>
    4cb8:	cb000042 	sub	x2, x2, x0
    4cbc:	f100005f 	cmp	x2, #0x0
    4cc0:	540003ad 	b.le	4d34 <fwp_poll_events+0xe4>
    4cc4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4cc8:	d2884804 	mov	x4, #0x4240                	// #16960
    4ccc:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4cd0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4cd4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4cd8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4cdc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ce0:	9b407c40 	smulh	x0, x2, x0
    4ce4:	9352fc00 	asr	x0, x0, #18
    4ce8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4cec:	9b048802 	msub	x2, x0, x4, x2
    4cf0:	f100005f 	cmp	x2, #0x0
    4cf4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4cf8:	eb01001f 	cmp	x0, x1
    4cfc:	5400098c 	b.gt	4e2c <fwp_poll_events+0x1dc>
    4d00:	340001a0 	cbz	w0, 4d34 <fwp_poll_events+0xe4>
    4d04:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4d08:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4d0c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4d10:	9ba17c01 	umull	x1, w0, w1
    4d14:	d366fc23 	lsr	x3, x1, #38
    4d18:	aa0303e2 	mov	x2, x3
    4d1c:	1b058063 	msub	w3, w3, w5, w0
    4d20:	9b247c63 	smull	x3, w3, w4
    4d24:	910023e0 	add	x0, sp, #0x8
    4d28:	d2800001 	mov	x1, #0x0                   	// #0
    4d2c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4d30:	97fff710 	bl	2970 <nanosleep@plt>
    4d34:	97ffff9f 	bl	4bb0 <fwp_now_ns>
    4d38:	91014268 	add	x8, x19, #0x50
    4d3c:	aa0003e7 	mov	x7, x0
    4d40:	4f000400 	movi	v0.4s, #0x0
    4d44:	52800029 	mov	w9, #0x1                   	// #1
    4d48:	f9409506 	ldr	x6, [x8, #296]
    4d4c:	d503201f 	nop
    4d50:	b40003e6 	cbz	x6, 4dcc <fwp_poll_events+0x17c>
    4d54:	f94034c1 	ldr	x1, [x6, #104]
    4d58:	aa0603e5 	mov	x5, x6
    4d5c:	f94088c6 	ldr	x6, [x6, #272]
    4d60:	eb07003f 	cmp	x1, x7
    4d64:	54ffff6c 	b.gt	4d50 <fwp_poll_events+0x100>
    4d68:	394154a0 	ldrb	w0, [x5, #85]
    4d6c:	36000120 	tbz	w0, #0, 4d90 <fwp_poll_events+0x140>
    4d70:	f94084a0 	ldr	x0, [x5, #264]
    4d74:	b4000560 	cbz	x0, 4e20 <fwp_poll_events+0x1d0>
    4d78:	f9008806 	str	x6, [x0, #272]
    4d7c:	b4000046 	cbz	x6, 4d84 <fwp_poll_events+0x134>
    4d80:	f90084c0 	str	x0, [x6, #264]
    4d84:	910800a0 	add	x0, x5, #0x200
    4d88:	390154bf 	strb	wzr, [x5, #85]
    4d8c:	3c908000 	stur	q0, [x0, #-248]
    4d90:	f94030a0 	ldr	x0, [x5, #96]
    4d94:	390158a9 	strb	w9, [x5, #86]
    4d98:	f100001f 	cmp	x0, #0x0
    4d9c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4da0:	540002cd 	b.le	4df8 <fwp_poll_events+0x1a8>
    4da4:	f94028a0 	ldr	x0, [x5, #80]
    4da8:	f2001c1f 	tst	x0, #0xff000000ff
    4dac:	54fffd21 	b.ne	4d50 <fwp_poll_events+0x100>  // b.any
    4db0:	f9406100 	ldr	x0, [x8, #192]
    4db4:	390150a9 	strb	w9, [x5, #84]
    4db8:	f90080bf 	str	xzr, [x5, #256]
    4dbc:	b40002c0 	cbz	x0, 4e14 <fwp_poll_events+0x1c4>
    4dc0:	f9006105 	str	x5, [x8, #192]
    4dc4:	f9008005 	str	x5, [x0, #256]
    4dc8:	b5fffc66 	cbnz	x6, 4d54 <fwp_poll_events+0x104>
    4dcc:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4dd0:	f947f400 	ldr	x0, [x0, #4072]
    4dd4:	f9400fe2 	ldr	x2, [sp, #24]
    4dd8:	f9400001 	ldr	x1, [x0]
    4ddc:	eb010042 	subs	x2, x2, x1
    4de0:	d2800001 	mov	x1, #0x0                   	// #0
    4de4:	540002e1 	b.ne	4e40 <fwp_poll_events+0x1f0>  // b.any
    4de8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4dec:	f9401bf3 	ldr	x19, [sp, #48]
    4df0:	910103ff 	add	sp, sp, #0x40
    4df4:	d65f03c0 	ret
    4df8:	394144a0 	ldrb	w0, [x5, #81]
    4dfc:	3707fd40 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e00:	394140a0 	ldrb	w0, [x5, #80]
    4e04:	3707fd00 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e08:	aa0503e0 	mov	x0, x5
    4e0c:	97fffa39 	bl	36f0 <fwp_cancel_tree.part.0>
    4e10:	17ffffe5 	b	4da4 <fwp_poll_events+0x154>
    4e14:	f9006105 	str	x5, [x8, #192]
    4e18:	f9006505 	str	x5, [x8, #200]
    4e1c:	17ffffeb 	b	4dc8 <fwp_poll_events+0x178>
    4e20:	91014261 	add	x1, x19, #0x50
    4e24:	f9009426 	str	x6, [x1, #296]
    4e28:	17ffffd5 	b	4d7c <fwp_poll_events+0x12c>
    4e2c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4e30:	d2989362 	mov	x2, #0xc49b                	// #50331
    4e34:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4e38:	f2a00402 	movk	x2, #0x20, lsl #16
    4e3c:	17ffffba 	b	4d24 <fwp_poll_events+0xd4>
    4e40:	97fff698 	bl	28a0 <__stack_chk_fail@plt>
    4e44:	97fff88c 	bl	3074 <fwp_flush>
    4e48:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4e4c:	f947e863 	ldr	x3, [x3, #4048]
    4e50:	d2800562 	mov	x2, #0x2b                  	// #43
    4e54:	d2800021 	mov	x1, #0x1                   	// #1
    4e58:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    4e5c:	91028000 	add	x0, x0, #0xa0
    4e60:	f9400063 	ldr	x3, [x3]
    4e64:	97fff6cf 	bl	29a0 <fwrite@plt>
    4e68:	52800ca0 	mov	w0, #0x65                  	// #101
    4e6c:	97fff639 	bl	2750 <exit@plt>

0000000000004e70 <fwp_heap_alloc_big>:
    4e70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	a90153f3 	stp	x19, x20, [sp, #16]
    4e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e80:	a90363f7 	stp	x23, x24, [sp, #48]
    4e84:	aa0003f7 	mov	x23, x0
    4e88:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e8c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e90:	eb0002ff 	cmp	x23, x0
    4e94:	540008a8 	b.hi	4fa8 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e9c:	8b0002f4 	add	x20, x23, x0
    4ea0:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbc0>
    4ea4:	91188359 	add	x25, x26, #0x620
    4ea8:	d350fe94 	lsr	x20, x20, #16
    4eac:	2a0103f5 	mov	w21, w1
    4eb0:	aa1403e0 	mov	x0, x20
    4eb4:	97fff8bf 	bl	31b0 <fwp_heap_chunks>
    4eb8:	f949ff22 	ldr	x2, [x25, #5112]
    4ebc:	8b000813 	add	x19, x0, x0, lsl #2
    4ec0:	aa0003f8 	mov	x24, x0
    4ec4:	52800043 	mov	w3, #0x2                   	// #2
    4ec8:	d37df273 	lsl	x19, x19, #3
    4ecc:	d2800021 	mov	x1, #0x1                   	// #1
    4ed0:	8b130040 	add	x0, x2, x19
    4ed4:	38336843 	strb	w3, [x2, x19]
    4ed8:	39000415 	strb	w21, [x0, #1]
    4edc:	b9000c14 	str	w20, [x0, #12]
    4ee0:	f9000817 	str	x23, [x0, #16]
    4ee4:	97fffd57 	bl	4440 <fwp_rc_prepare_chunk>
    4ee8:	f100069f 	cmp	x20, #0x1
    4eec:	54000289 	b.ls	4f3c <fwp_heap_alloc_big+0xcc>  // b.plast
    4ef0:	8b180294 	add	x20, x20, x24
    4ef4:	9100a273 	add	x19, x19, #0x28
    4ef8:	a90573fb 	stp	x27, x28, [sp, #80]
    4efc:	5280007b 	mov	w27, #0x3                   	// #3
    4f00:	8b140a94 	add	x20, x20, x20, lsl #2
    4f04:	2a1803fc 	mov	w28, w24
    4f08:	9adb2296 	lsl	x22, x20, x27
    4f0c:	d503201f 	nop
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffd48 	bl	4440 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0xa0>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	91188353 	add	x19, x26, #0x620
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x108>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118835a 	add	x26, x26, #0x620
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4fc0:	91188262 	add	x2, x19, #0x620
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	91188262 	add	x2, x19, #0x620
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	91188260 	add	x0, x19, #0x620
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	91188273 	add	x19, x19, #0x620
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffb37 	bl	3d70 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff6f 	b	4e70 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	91188260 	add	x0, x19, #0x620
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffd19 	bl	4560 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	540008a1 	b.ne	524c <fwp_heap_alloc+0x13c>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    5140:	911882f3 	add	x19, x23, #0x620
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	54000722 	b.cs	5298 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	911882e0 	add	x0, x23, #0x620
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	911882e1 	add	x1, x23, #0x620
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	5400030c 	b.gt	5260 <fwp_heap_alloc+0x150>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000249 	b.ls	527c <fwp_heap_alloc+0x16c>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	910142c1 	add	x1, x22, #0x50
    5244:	b9413038 	ldr	w24, [x1, #304]
    5248:	17ffffe6 	b	51e0 <fwp_heap_alloc+0xd0>
    524c:	a9538c44 	ldp	x4, x3, [x2, #312]
    5250:	91000484 	add	x4, x4, #0x1
    5254:	8b000063 	add	x3, x3, x0
    5258:	a9138c44 	stp	x4, x3, [x2, #312]
    525c:	17ffffb8 	b	513c <fwp_heap_alloc+0x2c>
    5260:	a94153f3 	ldp	x19, x20, [sp, #16]
    5264:	fd00a800 	str	d0, [x0, #336]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	aa0403e0 	mov	x0, x4
    5270:	a94363f7 	ldp	x23, x24, [sp, #48]
    5274:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5278:	d65f03c0 	ret
    527c:	7100043f 	cmp	w1, #0x1
    5280:	8b140085 	add	x5, x4, x20
    5284:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5288:	52800001 	mov	w1, #0x0                   	// #0
    528c:	aa0403e0 	mov	x0, x4
    5290:	f9000465 	str	x5, [x3, #8]
    5294:	17ffffc4 	b	51a4 <fwp_heap_alloc+0x94>
    5298:	97fff7b6 	bl	3170 <fwp_heap_oom>
    529c:	d503201f 	nop

00000000000052a0 <fwp_data.part.0.constprop.0>:
    52a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52a4:	910003fd 	mov	x29, sp
    52a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    52ac:	f00000d6 	adrp	x22, 20000 <__data_start>
    52b0:	910142c2 	add	x2, x22, #0x50
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	b9413059 	ldr	w25, [x2, #304]
    52bc:	a90153f3 	stp	x19, x20, [sp, #16]
    52c0:	aa0103f4 	mov	x20, x1
    52c4:	a90363f7 	stp	x23, x24, [sp, #48]
    52c8:	2a0003f7 	mov	w23, w0
    52cc:	340000b9 	cbz	w25, 52e0 <fwp_data.part.0.constprop.0+0x40>
    52d0:	a9538041 	ldp	x1, x0, [x2, #312]
    52d4:	91000421 	add	x1, x1, #0x1
    52d8:	91006000 	add	x0, x0, #0x18
    52dc:	a9138041 	stp	x1, x0, [x2, #312]
    52e0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    52e4:	911882a3 	add	x3, x21, #0x620
    52e8:	b953a460 	ldr	w0, [x3, #5028]
    52ec:	34000840 	cbz	w0, 53f4 <fwp_data.part.0.constprop.0+0x154>
    52f0:	397e8862 	ldrb	w2, [x3, #4002]
    52f4:	910f0040 	add	x0, x2, #0x3c0
    52f8:	8b020442 	add	x2, x2, x2, lsl #1
    52fc:	d37df042 	lsl	x2, x2, #3
    5300:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5304:	2a1a03f8 	mov	w24, w26
    5308:	f8626873 	ldr	x19, [x3, x2]
    530c:	b4000613 	cbz	x19, 53cc <fwp_data.part.0.constprop.0+0x12c>
    5310:	f9400260 	ldr	x0, [x19]
    5314:	aa2003e0 	mvn	x0, x0
    5318:	f8226860 	str	x0, [x3, x2]
    531c:	f100631f 	cmp	x24, #0x18
    5320:	540000e9 	b.ls	533c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5324:	d1006702 	sub	x2, x24, #0x19
    5328:	91006260 	add	x0, x19, #0x18
    532c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5330:	52800001 	mov	w1, #0x0                   	// #0
    5334:	91002042 	add	x2, x2, #0x8
    5338:	97fff54e 	bl	2870 <memset@plt>
    533c:	911882a0 	add	x0, x21, #0x620
    5340:	f94a1001 	ldr	x1, [x0, #5152]
    5344:	ab180021 	adds	x1, x1, x24
    5348:	54000682 	b.cs	5418 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    534c:	f94a1402 	ldr	x2, [x0, #5160]
    5350:	f90a1001 	str	x1, [x0, #5152]
    5354:	eb02003f 	cmp	x1, x2
    5358:	54000049 	b.ls	5360 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    535c:	f90a1401 	str	x1, [x0, #5160]
    5360:	911882a0 	add	x0, x21, #0x620
    5364:	1e630341 	ucvtf	d1, w26
    5368:	fd4a1c00 	ldr	d0, [x0, #5176]
    536c:	1e612800 	fadd	d0, d0, d1
    5370:	fd0a1c00 	str	d0, [x0, #5176]
    5374:	34000139 	cbz	w25, 5398 <fwp_data.part.0.constprop.0+0xf8>
    5378:	911882b5 	add	x21, x21, #0x620
    537c:	910142d6 	add	x22, x22, #0x50
    5380:	fd4a12a0 	ldr	d0, [x21, #5152]
    5384:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5388:	7e61d800 	ucvtf	d0, d0
    538c:	1e623800 	fsub	d0, d0, d2
    5390:	1e612010 	fcmpe	d0, d1
    5394:	540003ec 	b.gt	5410 <fwp_data.part.0.constprop.0+0x170>
    5398:	52800040 	mov	w0, #0x2                   	// #2
    539c:	29000277 	stp	w23, w0, [x19]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	f9400281 	ldr	x1, [x20]
    53a8:	f9000661 	str	x1, [x19, #8]
    53ac:	f9400681 	ldr	x1, [x20, #8]
    53b0:	f9000a61 	str	x1, [x19, #16]
    53b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    53c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53c8:	d65f03c0 	ret
    53cc:	8b020063 	add	x3, x3, x2
    53d0:	f9400473 	ldr	x19, [x3, #8]
    53d4:	b4000113 	cbz	x19, 53f4 <fwp_data.part.0.constprop.0+0x154>
    53d8:	f9400860 	ldr	x0, [x3, #16]
    53dc:	cb130000 	sub	x0, x0, x19
    53e0:	eb00031f 	cmp	x24, x0
    53e4:	54000088 	b.hi	53f4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53e8:	8b180260 	add	x0, x19, x24
    53ec:	f9000460 	str	x0, [x3, #8]
    53f0:	17ffffcb 	b	531c <fwp_data.part.0.constprop.0+0x7c>
    53f4:	52800001 	mov	w1, #0x0                   	// #0
    53f8:	d2800300 	mov	x0, #0x18                  	// #24
    53fc:	97ffff45 	bl	5110 <fwp_heap_alloc>
    5400:	aa0003f3 	mov	x19, x0
    5404:	910142c1 	add	x1, x22, #0x50
    5408:	b9413039 	ldr	w25, [x1, #304]
    540c:	17ffffda 	b	5374 <fwp_data.part.0.constprop.0+0xd4>
    5410:	fd00aac0 	str	d0, [x22, #336]
    5414:	17ffffe1 	b	5398 <fwp_data.part.0.constprop.0+0xf8>
    5418:	97fff756 	bl	3170 <fwp_heap_oom>
    541c:	d503201f 	nop

0000000000005420 <fwp_tape_grow.constprop.0>:
    5420:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5424:	d2800803 	mov	x3, #0x40                  	// #64
    5428:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    542c:	910003fd 	mov	x29, sp
    5430:	a90153f3 	stp	x19, x20, [sp, #16]
    5434:	f9400c13 	ldr	x19, [x0, #24]
    5438:	a90363f7 	stp	x23, x24, [sp, #48]
    543c:	aa0003f7 	mov	x23, x0
    5440:	f100027f 	cmp	x19, #0x0
    5444:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    5448:	eb13003f 	cmp	x1, x19
    544c:	540000ed 	b.le	5468 <fwp_tape_grow.constprop.0+0x48>
    5450:	eb02027f 	cmp	x19, x2
    5454:	5400078d 	b.le	5544 <fwp_tape_grow.constprop.0+0x124>
    5458:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    545c:	eb13003f 	cmp	x1, x19
    5460:	5400004d 	b.le	5468 <fwp_tape_grow.constprop.0+0x48>
    5464:	14000000 	b	5464 <fwp_tape_grow.constprop.0+0x44>
    5468:	a940d2e3 	ldp	x3, x20, [x23, #8]
    546c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5470:	d37df276 	lsl	x22, x19, #3
    5474:	f94012e0 	ldr	x0, [x23, #32]
    5478:	aa1603e1 	mov	x1, x22
    547c:	f94032f5 	ldr	x21, [x23, #96]
    5480:	cb030294 	sub	x20, x20, x3
    5484:	52800022 	mov	w2, #0x1                   	// #1
    5488:	97fffb0f 	bl	40c4 <ad_raw_realloc>
    548c:	b4000bc0 	cbz	x0, 5604 <fwp_tape_grow.constprop.0+0x1e4>
    5490:	f9400ee1 	ldr	x1, [x23, #24]
    5494:	8b010801 	add	x1, x0, x1, lsl #2
    5498:	a90206e0 	stp	x0, x1, [x23, #32]
    549c:	b4000835 	cbz	x21, 55a0 <fwp_tape_grow.constprop.0+0x180>
    54a0:	f94032b6 	ldr	x22, [x21, #96]
    54a4:	eb1302df 	cmp	x22, x19
    54a8:	540003aa 	b.ge	551c <fwp_tape_grow.constprop.0+0xfc>  // b.tcont
    54ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    54b4:	eb00027f 	cmp	x19, x0
    54b8:	54000a08 	b.hi	55f8 <fwp_tape_grow.constprop.0+0x1d8>  // b.pmore
    54bc:	f94022b9 	ldr	x25, [x21, #64]
    54c0:	d37cee7a 	lsl	x26, x19, #4
    54c4:	aa1a03e0 	mov	x0, x26
    54c8:	52800041 	mov	w1, #0x2                   	// #2
    54cc:	97ffff11 	bl	5110 <fwp_heap_alloc>
    54d0:	aa0003f8 	mov	x24, x0
    54d4:	b4000119 	cbz	x25, 54f4 <fwp_tape_grow.constprop.0+0xd4>
    54d8:	d37ceed6 	lsl	x22, x22, #4
    54dc:	aa1903e1 	mov	x1, x25
    54e0:	eb1a02df 	cmp	x22, x26
    54e4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    54e8:	97fff482 	bl	26f0 <memcpy@plt>
    54ec:	aa1903e0 	mov	x0, x25
    54f0:	97fffc4c 	bl	4620 <fwp_mem_free>
    54f4:	f94032a0 	ldr	x0, [x21, #96]
    54f8:	52800001 	mov	w1, #0x0                   	// #0
    54fc:	cb000262 	sub	x2, x19, x0
    5500:	8b001300 	add	x0, x24, x0, lsl #4
    5504:	d37cec42 	lsl	x2, x2, #4
    5508:	97fff4da 	bl	2870 <memset@plt>
    550c:	f94012e0 	ldr	x0, [x23, #32]
    5510:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5514:	f90022b8 	str	x24, [x21, #64]
    5518:	f90032b3 	str	x19, [x21, #96]
    551c:	d37ef675 	lsl	x21, x19, #2
    5520:	b5000254 	cbnz	x20, 5568 <fwp_tape_grow.constprop.0+0x148>
    5524:	8b150001 	add	x1, x0, x21
    5528:	a9425bf5 	ldp	x21, x22, [sp, #32]
    552c:	f9000ef3 	str	x19, [x23, #24]
    5530:	f90016e1 	str	x1, [x23, #40]
    5534:	a94153f3 	ldp	x19, x20, [sp, #16]
    5538:	a94363f7 	ldp	x23, x24, [sp, #48]
    553c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5540:	d65f03c0 	ret
    5544:	d37ffa73 	lsl	x19, x19, #1
    5548:	17ffffc0 	b	5448 <fwp_tape_grow.constprop.0+0x28>
    554c:	aa0303e0 	mov	x0, x3
    5550:	d37df282 	lsl	x2, x20, #3
    5554:	97fff46f 	bl	2710 <memmove@plt>
    5558:	f9401ae1 	ldr	x1, [x23, #48]
    555c:	f94012e0 	ldr	x0, [x23, #32]
    5560:	8b160021 	add	x1, x1, x22
    5564:	f9001ee1 	str	x1, [x23, #56]
    5568:	f94016e1 	ldr	x1, [x23, #40]
    556c:	d37ef675 	lsl	x21, x19, #2
    5570:	d37ef682 	lsl	x2, x20, #2
    5574:	8b150000 	add	x0, x0, x21
    5578:	97fff466 	bl	2710 <memmove@plt>
    557c:	f94012e0 	ldr	x0, [x23, #32]
    5580:	8b150001 	add	x1, x0, x21
    5584:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5588:	f9000ef3 	str	x19, [x23, #24]
    558c:	f90016e1 	str	x1, [x23, #40]
    5590:	a94153f3 	ldp	x19, x20, [sp, #16]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	a8c57bfd 	ldp	x29, x30, [sp], #80
    559c:	d65f03c0 	ret
    55a0:	f9401ae0 	ldr	x0, [x23, #48]
    55a4:	d37cee61 	lsl	x1, x19, #4
    55a8:	52800042 	mov	w2, #0x2                   	// #2
    55ac:	97fffac6 	bl	40c4 <ad_raw_realloc>
    55b0:	b40002a0 	cbz	x0, 5604 <fwp_tape_grow.constprop.0+0x1e4>
    55b4:	f9400ee2 	ldr	x2, [x23, #24]
    55b8:	f9001ae0 	str	x0, [x23, #48]
    55bc:	8b160003 	add	x3, x0, x22
    55c0:	8b020c01 	add	x1, x0, x2, lsl #3
    55c4:	f9001ee1 	str	x1, [x23, #56]
    55c8:	b5fffc34 	cbnz	x20, 554c <fwp_tape_grow.constprop.0+0x12c>
    55cc:	f94012e0 	ldr	x0, [x23, #32]
    55d0:	d37ef675 	lsl	x21, x19, #2
    55d4:	f9001ee3 	str	x3, [x23, #56]
    55d8:	8b150001 	add	x1, x0, x21
    55dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e0:	f9000ef3 	str	x19, [x23, #24]
    55e4:	f90016e1 	str	x1, [x23, #40]
    55e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    55fc:	9103e000 	add	x0, x0, #0xf8
    5600:	97fffb4d 	bl	4334 <fwp_trap>
    5604:	aa1703e0 	mov	x0, x23
    5608:	a9046bf9 	stp	x25, x26, [sp, #64]
    560c:	97fff682 	bl	3014 <fwp_tape_unlink_scope>
    5610:	f94012e0 	ldr	x0, [x23, #32]
    5614:	b4000040 	cbz	x0, 561c <fwp_tape_grow.constprop.0+0x1fc>
    5618:	97fffa76 	bl	3ff0 <ad_raw_free.part.0>
    561c:	f9401ae0 	ldr	x0, [x23, #48]
    5620:	b4000040 	cbz	x0, 5628 <fwp_tape_grow.constprop.0+0x208>
    5624:	97fffa73 	bl	3ff0 <ad_raw_free.part.0>
    5628:	f94022e0 	ldr	x0, [x23, #64]
    562c:	b4000040 	cbz	x0, 5634 <fwp_tape_grow.constprop.0+0x214>
    5630:	97fffa70 	bl	3ff0 <ad_raw_free.part.0>
    5634:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    5638:	f947e821 	ldr	x1, [x1, #4048]
    563c:	f9000eff 	str	xzr, [x23, #24]
    5640:	4f000400 	movi	v0.4s, #0x0
    5644:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5648:	d2800262 	mov	x2, #0x13                  	// #19
    564c:	f9400023 	ldr	x3, [x1]
    5650:	b90006ff 	str	wzr, [x23, #4]
    5654:	d2800021 	mov	x1, #0x1                   	// #1
    5658:	90000020 	adrp	x0, 9000 <fwp_main_thread+0x740>
    565c:	912fe000 	add	x0, x0, #0xbf8
    5660:	3c8082e0 	stur	q0, [x23, #8]
    5664:	ad0102e0 	stp	q0, q0, [x23, #32]
    5668:	97fff4ce 	bl	29a0 <fwrite@plt>
    566c:	d2800000 	mov	x0, #0x0                   	// #0
    5670:	97fff4d8 	bl	29d0 <fflush@plt>
    5674:	52800cc0 	mov	w0, #0x66                  	// #102
    5678:	97fff4e6 	bl	2a10 <_Exit@plt>
    567c:	d503201f 	nop

0000000000005680 <f141.constprop.0>:
    5680:	f100001f 	cmp	x0, #0x0
    5684:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5688:	54000a2b 	b.lt	57cc <f141.constprop.0+0x14c>  // b.tstop
    568c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5690:	aa0003e2 	mov	x2, x0
    5694:	910003fd 	mov	x29, sp
    5698:	a90153f3 	stp	x19, x20, [sp, #16]
    569c:	aa0003f4 	mov	x20, x0
    56a0:	aa010000 	orr	x0, x0, x1
    56a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56a8:	aa0103f6 	mov	x22, x1
    56ac:	f9001bf7 	str	x23, [sp, #48]
    56b0:	fd001fe8 	str	d8, [sp, #56]
    56b4:	b7f80180 	tbnz	x0, #63, 56e4 <f141.constprop.0+0x64>
    56b8:	9360fc20 	asr	x0, x1, #32
    56bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56c0:	eb82801f 	cmp	x0, x2, asr #32
    56c4:	54000881 	b.ne	57d4 <f141.constprop.0+0x154>  // b.any
    56c8:	97fffd1e 	bl	4b40 <fwp_tape_of>
    56cc:	aa0003f3 	mov	x19, x0
    56d0:	f9403000 	ldr	x0, [x0, #96]
    56d4:	b40001e0 	cbz	x0, 5710 <f141.constprop.0+0x90>
    56d8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    56dc:	91058000 	add	x0, x0, #0x160
    56e0:	97fffb15 	bl	4334 <fwp_trap>
    56e4:	9360fc40 	asr	x0, x2, #32
    56e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56ec:	b6fffee2 	tbz	x2, #63, 56c8 <f141.constprop.0+0x48>
    56f0:	2f00e408 	movi	d8, #0x0
    56f4:	9360fc20 	asr	x0, x1, #32
    56f8:	aa0103f4 	mov	x20, x1
    56fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5700:	97fffd10 	bl	4b40 <fwp_tape_of>
    5704:	aa0003f3 	mov	x19, x0
    5708:	f9403000 	ldr	x0, [x0, #96]
    570c:	b5fffe60 	cbnz	x0, 56d8 <f141.constprop.0+0x58>
    5710:	f9400a77 	ldr	x23, [x19, #16]
    5714:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5718:	eb0002ff 	cmp	x23, x0
    571c:	5400046c 	b.gt	57a8 <f141.constprop.0+0x128>
    5720:	eb3442ff 	cmp	x23, w20, uxtw
    5724:	540004ed 	b.le	57c0 <f141.constprop.0+0x140>
    5728:	b7f80076 	tbnz	x22, #63, 5734 <f141.constprop.0+0xb4>
    572c:	eb3642ff 	cmp	x23, w22, uxtw
    5730:	5400048d 	b.le	57c0 <f141.constprop.0+0x140>
    5734:	f9400675 	ldr	x21, [x19, #8]
    5738:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    573c:	cb1502f5 	sub	x21, x23, x21
    5740:	910006a1 	add	x1, x21, #0x1
    5744:	eb00003f 	cmp	x1, x0
    5748:	54000308 	b.hi	57a8 <f141.constprop.0+0x128>  // b.pmore
    574c:	f9400e60 	ldr	x0, [x19, #24]
    5750:	eb00003f 	cmp	x1, x0
    5754:	5400030c 	b.gt	57b4 <f141.constprop.0+0x134>
    5758:	a9420262 	ldp	x2, x0, [x19, #32]
    575c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5760:	f9401a61 	ldr	x1, [x19, #48]
    5764:	b8357854 	str	w20, [x2, x21, lsl #2]
    5768:	f9401e62 	ldr	x2, [x19, #56]
    576c:	f10002df 	cmp	x22, #0x0
    5770:	fc357820 	str	d0, [x1, x21, lsl #3]
    5774:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5778:	b8357816 	str	w22, [x0, x21, lsl #2]
    577c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5780:	910006e1 	add	x1, x23, #0x1
    5784:	aa170000 	orr	x0, x0, x23
    5788:	fc357848 	str	d8, [x2, x21, lsl #3]
    578c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5790:	f9401bf7 	ldr	x23, [sp, #48]
    5794:	fd401fe8 	ldr	d8, [sp, #56]
    5798:	f9000a61 	str	x1, [x19, #16]
    579c:	a94153f3 	ldp	x19, x20, [sp, #16]
    57a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57a4:	d65f03c0 	ret
    57a8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    57ac:	9103e000 	add	x0, x0, #0xf8
    57b0:	97fffae1 	bl	4334 <fwp_trap>
    57b4:	aa1303e0 	mov	x0, x19
    57b8:	97ffff1a 	bl	5420 <fwp_tape_grow.constprop.0>
    57bc:	17ffffe7 	b	5758 <f141.constprop.0+0xd8>
    57c0:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    57c4:	91064000 	add	x0, x0, #0x190
    57c8:	97fffadb 	bl	4334 <fwp_trap>
    57cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57d0:	d65f03c0 	ret
    57d4:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    57d8:	91046000 	add	x0, x0, #0x118
    57dc:	97fffad6 	bl	4334 <fwp_trap>

00000000000057e0 <w120>:
    57e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    57e4:	910003fd 	mov	x29, sp
    57e8:	a90153f3 	stp	x19, x20, [sp, #16]
    57ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    57f0:	a90363f7 	stp	x23, x24, [sp, #48]
    57f4:	aa0003f8 	mov	x24, x0
    57f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    57fc:	aa0103f9 	mov	x25, x1
    5800:	6d0527e8 	stp	d8, d9, [sp, #80]
    5804:	1e604008 	fmov	d8, d0
    5808:	1e604029 	fmov	d9, d1
    580c:	6d062fea 	stp	d10, d11, [sp, #96]
    5810:	1e60080a 	fmul	d10, d0, d0
    5814:	b7f821a0 	tbnz	x0, #63, 5c48 <w120+0x468>
    5818:	9360fc17 	asr	x23, x0, #32
    581c:	aa1703e0 	mov	x0, x23
    5820:	97fffcc8 	bl	4b40 <fwp_tape_of>
    5824:	f9403001 	ldr	x1, [x0, #96]
    5828:	aa0003f3 	mov	x19, x0
    582c:	b4000081 	cbz	x1, 583c <w120+0x5c>
    5830:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    5834:	91058000 	add	x0, x0, #0x160
    5838:	97fffabf 	bl	4334 <fwp_trap>
    583c:	f9400815 	ldr	x21, [x0, #16]
    5840:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5844:	eb0102bf 	cmp	x21, x1
    5848:	54001d8c 	b.gt	5bf8 <w120+0x418>
    584c:	eb3842bf 	cmp	x21, w24, uxtw
    5850:	54001ced 	b.le	5bec <w120+0x40c>
    5854:	f9400416 	ldr	x22, [x0, #8]
    5858:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    585c:	cb1602b6 	sub	x22, x21, x22
    5860:	910006c1 	add	x1, x22, #0x1
    5864:	eb02003f 	cmp	x1, x2
    5868:	54001c88 	b.hi	5bf8 <w120+0x418>  // b.pmore
    586c:	f9400c02 	ldr	x2, [x0, #24]
    5870:	eb02003f 	cmp	x1, x2
    5874:	54001c8c 	b.gt	5c04 <w120+0x424>
    5878:	a9420660 	ldp	x0, x1, [x19, #32]
    587c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5880:	f9401a62 	ldr	x2, [x19, #48]
    5884:	b8367818 	str	w24, [x0, x22, lsl #2]
    5888:	f9401e60 	ldr	x0, [x19, #56]
    588c:	aa150294 	orr	x20, x20, x21
    5890:	fc367848 	str	d8, [x2, x22, lsl #3]
    5894:	910006b5 	add	x21, x21, #0x1
    5898:	b8367838 	str	w24, [x1, x22, lsl #2]
    589c:	1e6a392a 	fsub	d10, d9, d10
    58a0:	9360fe9a 	asr	x26, x20, #32
    58a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    58a8:	f9000a75 	str	x21, [x19, #16]
    58ac:	b7f80079 	tbnz	x25, #63, 58b8 <w120+0xd8>
    58b0:	eb99835f 	cmp	x26, x25, asr #32
    58b4:	54001e21 	b.ne	5c78 <w120+0x498>  // b.any
    58b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    58c0:	eb1a02ff 	cmp	x23, x26
    58c4:	540000c0 	b.eq	58dc <w120+0xfc>  // b.none
    58c8:	aa1a03e0 	mov	x0, x26
    58cc:	97fffc9d 	bl	4b40 <fwp_tape_of>
    58d0:	aa0003f3 	mov	x19, x0
    58d4:	f9403000 	ldr	x0, [x0, #96]
    58d8:	b5fffac0 	cbnz	x0, 5830 <w120+0x50>
    58dc:	f9400a77 	ldr	x23, [x19, #16]
    58e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58e4:	eb0002ff 	cmp	x23, x0
    58e8:	5400188c 	b.gt	5bf8 <w120+0x418>
    58ec:	eb3442ff 	cmp	x23, w20, uxtw
    58f0:	540017ed 	b.le	5bec <w120+0x40c>
    58f4:	b7f80079 	tbnz	x25, #63, 5900 <w120+0x120>
    58f8:	eb3942ff 	cmp	x23, w25, uxtw
    58fc:	5400178d 	b.le	5bec <w120+0x40c>
    5900:	f9400675 	ldr	x21, [x19, #8]
    5904:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5908:	cb1502f5 	sub	x21, x23, x21
    590c:	910006a1 	add	x1, x21, #0x1
    5910:	eb00003f 	cmp	x1, x0
    5914:	54001728 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5918:	f9400e60 	ldr	x0, [x19, #24]
    591c:	eb00003f 	cmp	x1, x0
    5920:	540018ec 	b.gt	5c3c <w120+0x45c>
    5924:	a9420e62 	ldp	x2, x3, [x19, #32]
    5928:	f100033f 	cmp	x25, #0x0
    592c:	f9401a61 	ldr	x1, [x19, #48]
    5930:	b8357854 	str	w20, [x2, x21, lsl #2]
    5934:	f9401e62 	ldr	x2, [x19, #56]
    5938:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    593c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5940:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5944:	b8357861 	str	w1, [x3, x21, lsl #2]
    5948:	910006f6 	add	x22, x23, #0x1
    594c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5950:	92607e94 	and	x20, x20, #0xffffffff00000000
    5954:	fc357849 	str	d9, [x2, x21, lsl #3]
    5958:	aa170294 	orr	x20, x20, x23
    595c:	f9000a76 	str	x22, [x19, #16]
    5960:	1e68396b 	fsub	d11, d11, d8
    5964:	b7f81a78 	tbnz	x24, #63, 5cb0 <w120+0x4d0>
    5968:	9360ff17 	asr	x23, x24, #32
    596c:	eb1a02ff 	cmp	x23, x26
    5970:	540000e0 	b.eq	598c <w120+0x1ac>  // b.none
    5974:	aa1703e0 	mov	x0, x23
    5978:	97fffc72 	bl	4b40 <fwp_tape_of>
    597c:	aa0003f3 	mov	x19, x0
    5980:	f9403000 	ldr	x0, [x0, #96]
    5984:	b5fff560 	cbnz	x0, 5830 <w120+0x50>
    5988:	f9400a76 	ldr	x22, [x19, #16]
    598c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5990:	eb0002df 	cmp	x22, x0
    5994:	5400132c 	b.gt	5bf8 <w120+0x418>
    5998:	eb3842df 	cmp	x22, w24, uxtw
    599c:	5400128d 	b.le	5bec <w120+0x40c>
    59a0:	f9400675 	ldr	x21, [x19, #8]
    59a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59a8:	cb1502d5 	sub	x21, x22, x21
    59ac:	910006a1 	add	x1, x21, #0x1
    59b0:	eb00003f 	cmp	x1, x0
    59b4:	54001228 	b.hi	5bf8 <w120+0x418>  // b.pmore
    59b8:	f9400e60 	ldr	x0, [x19, #24]
    59bc:	eb00003f 	cmp	x1, x0
    59c0:	5400138c 	b.gt	5c30 <w120+0x450>
    59c4:	a9420262 	ldp	x2, x0, [x19, #32]
    59c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    59cc:	f9401a63 	ldr	x3, [x19, #48]
    59d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    59d4:	f9401e62 	ldr	x2, [x19, #56]
    59d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    59dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    59e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    59e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    59e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    59ec:	aa160018 	orr	x24, x0, x22
    59f0:	910006c1 	add	x1, x22, #0x1
    59f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    59f8:	f9000a61 	str	x1, [x19, #16]
    59fc:	9360fe99 	asr	x25, x20, #32
    5a00:	1e6a0949 	fmul	d9, d10, d10
    5a04:	eb17033f 	cmp	x25, x23
    5a08:	540000c0 	b.eq	5a20 <w120+0x240>  // b.none
    5a0c:	aa1903e0 	mov	x0, x25
    5a10:	97fffc4c 	bl	4b40 <fwp_tape_of>
    5a14:	aa0003f3 	mov	x19, x0
    5a18:	f9403000 	ldr	x0, [x0, #96]
    5a1c:	b5fff0a0 	cbnz	x0, 5830 <w120+0x50>
    5a20:	f9400a75 	ldr	x21, [x19, #16]
    5a24:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a28:	eb0002bf 	cmp	x21, x0
    5a2c:	54000e6c 	b.gt	5bf8 <w120+0x418>
    5a30:	eb3442bf 	cmp	x21, w20, uxtw
    5a34:	54000dcd 	b.le	5bec <w120+0x40c>
    5a38:	f9400676 	ldr	x22, [x19, #8]
    5a3c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a40:	cb1602b6 	sub	x22, x21, x22
    5a44:	910006c1 	add	x1, x22, #0x1
    5a48:	eb00003f 	cmp	x1, x0
    5a4c:	54000d68 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5a50:	f9400e60 	ldr	x0, [x19, #24]
    5a54:	eb00003f 	cmp	x1, x0
    5a58:	54000e6c 	b.gt	5c24 <w120+0x444>
    5a5c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5a60:	aa150017 	orr	x23, x0, x21
    5a64:	a9420261 	ldp	x1, x0, [x19, #32]
    5a68:	f9401a62 	ldr	x2, [x19, #48]
    5a6c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5a70:	f9401e61 	ldr	x1, [x19, #56]
    5a74:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5a78:	b8367814 	str	w20, [x0, x22, lsl #2]
    5a7c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a80:	9e670000 	fmov	d0, x0
    5a84:	910006b4 	add	x20, x21, #0x1
    5a88:	fc36782a 	str	d10, [x1, x22, lsl #3]
    5a8c:	9360fef6 	asr	x22, x23, #32
    5a90:	f9000a74 	str	x20, [x19, #16]
    5a94:	1e600929 	fmul	d9, d9, d0
    5a98:	eb1902df 	cmp	x22, x25
    5a9c:	540000e0 	b.eq	5ab8 <w120+0x2d8>  // b.none
    5aa0:	aa1603e0 	mov	x0, x22
    5aa4:	97fffc27 	bl	4b40 <fwp_tape_of>
    5aa8:	aa0003f3 	mov	x19, x0
    5aac:	f9403000 	ldr	x0, [x0, #96]
    5ab0:	b5ffec00 	cbnz	x0, 5830 <w120+0x50>
    5ab4:	f9400a74 	ldr	x20, [x19, #16]
    5ab8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5abc:	eb00029f 	cmp	x20, x0
    5ac0:	540009cc 	b.gt	5bf8 <w120+0x418>
    5ac4:	eb37429f 	cmp	x20, w23, uxtw
    5ac8:	5400092d 	b.le	5bec <w120+0x40c>
    5acc:	f9400675 	ldr	x21, [x19, #8]
    5ad0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5ad4:	cb150295 	sub	x21, x20, x21
    5ad8:	910006a1 	add	x1, x21, #0x1
    5adc:	eb00003f 	cmp	x1, x0
    5ae0:	540008c8 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5ae4:	f9400e60 	ldr	x0, [x19, #24]
    5ae8:	eb00003f 	cmp	x1, x0
    5aec:	5400096c 	b.gt	5c18 <w120+0x438>
    5af0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5af4:	9e670000 	fmov	d0, x0
    5af8:	a9420262 	ldp	x2, x0, [x19, #32]
    5afc:	1e6b0968 	fmul	d8, d11, d11
    5b00:	f9401a61 	ldr	x1, [x19, #48]
    5b04:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b08:	f9401e62 	ldr	x2, [x19, #56]
    5b0c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5b10:	12800001 	mov	w1, #0xffffffff            	// #-1
    5b14:	b8357801 	str	w1, [x0, x21, lsl #2]
    5b18:	91000681 	add	x1, x20, #0x1
    5b1c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5b20:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b24:	f9000a61 	str	x1, [x19, #16]
    5b28:	aa140014 	orr	x20, x0, x20
    5b2c:	b100071f 	cmn	x24, #0x1
    5b30:	54000c60 	b.eq	5cbc <w120+0x4dc>  // b.none
    5b34:	9360ff00 	asr	x0, x24, #32
    5b38:	eb16001f 	cmp	x0, x22
    5b3c:	540000a0 	b.eq	5b50 <w120+0x370>  // b.none
    5b40:	97fffc00 	bl	4b40 <fwp_tape_of>
    5b44:	aa0003f3 	mov	x19, x0
    5b48:	f9403000 	ldr	x0, [x0, #96]
    5b4c:	b5ffe720 	cbnz	x0, 5830 <w120+0x50>
    5b50:	f9400a75 	ldr	x21, [x19, #16]
    5b54:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b58:	eb0002bf 	cmp	x21, x0
    5b5c:	540004ec 	b.gt	5bf8 <w120+0x418>
    5b60:	eb3842bf 	cmp	x21, w24, uxtw
    5b64:	5400044d 	b.le	5bec <w120+0x40c>
    5b68:	f9400676 	ldr	x22, [x19, #8]
    5b6c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b70:	cb1602b6 	sub	x22, x21, x22
    5b74:	910006c1 	add	x1, x22, #0x1
    5b78:	eb00003f 	cmp	x1, x0
    5b7c:	540003e8 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5b80:	f9400e60 	ldr	x0, [x19, #24]
    5b84:	eb00003f 	cmp	x1, x0
    5b88:	5400042c 	b.gt	5c0c <w120+0x42c>
    5b8c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5b90:	92607f00 	and	x0, x24, #0xffffffff00000000
    5b94:	f9401a63 	ldr	x3, [x19, #48]
    5b98:	b8367838 	str	w24, [x1, x22, lsl #2]
    5b9c:	f9401e61 	ldr	x1, [x19, #56]
    5ba0:	aa150000 	orr	x0, x0, x21
    5ba4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5ba8:	910006b5 	add	x21, x21, #0x1
    5bac:	b8367858 	str	w24, [x2, x22, lsl #2]
    5bb0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5bb4:	f9000a75 	str	x21, [x19, #16]
    5bb8:	1e692908 	fadd	d8, d8, d9
    5bbc:	aa1403e1 	mov	x1, x20
    5bc0:	97fffeb0 	bl	5680 <f141.constprop.0>
    5bc4:	aa0003e1 	mov	x1, x0
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	9e660100 	fmov	x0, d8
    5bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5bd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bd8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5bdc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5be0:	6d462fea 	ldp	d10, d11, [sp, #96]
    5be4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5be8:	d65f03c0 	ret
    5bec:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    5bf0:	91064000 	add	x0, x0, #0x190
    5bf4:	97fff9d0 	bl	4334 <fwp_trap>
    5bf8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    5bfc:	9103e000 	add	x0, x0, #0xf8
    5c00:	97fff9cd 	bl	4334 <fwp_trap>
    5c04:	97fffe07 	bl	5420 <fwp_tape_grow.constprop.0>
    5c08:	17ffff1c 	b	5878 <w120+0x98>
    5c0c:	aa1303e0 	mov	x0, x19
    5c10:	97fffe04 	bl	5420 <fwp_tape_grow.constprop.0>
    5c14:	17ffffde 	b	5b8c <w120+0x3ac>
    5c18:	aa1303e0 	mov	x0, x19
    5c1c:	97fffe01 	bl	5420 <fwp_tape_grow.constprop.0>
    5c20:	17ffffb4 	b	5af0 <w120+0x310>
    5c24:	aa1303e0 	mov	x0, x19
    5c28:	97fffdfe 	bl	5420 <fwp_tape_grow.constprop.0>
    5c2c:	17ffff8c 	b	5a5c <w120+0x27c>
    5c30:	aa1303e0 	mov	x0, x19
    5c34:	97fffdfb 	bl	5420 <fwp_tape_grow.constprop.0>
    5c38:	17ffff63 	b	59c4 <w120+0x1e4>
    5c3c:	aa1303e0 	mov	x0, x19
    5c40:	97fffdf8 	bl	5420 <fwp_tape_grow.constprop.0>
    5c44:	17ffff38 	b	5924 <w120+0x144>
    5c48:	1e6a382a 	fsub	d10, d1, d10
    5c4c:	b6f801c1 	tbz	x1, #63, 5c84 <w120+0x4a4>
    5c50:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c54:	1e6a0949 	fmul	d9, d10, d10
    5c58:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c5c:	9e670001 	fmov	d1, x0
    5c60:	1e683808 	fsub	d8, d0, d8
    5c64:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5c68:	aa1403e0 	mov	x0, x20
    5c6c:	1e610929 	fmul	d9, d9, d1
    5c70:	1e680908 	fmul	d8, d8, d8
    5c74:	17ffffd1 	b	5bb8 <w120+0x3d8>
    5c78:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    5c7c:	91046000 	add	x0, x0, #0x118
    5c80:	97fff9ad 	bl	4334 <fwp_trap>
    5c84:	2f00e409 	movi	d9, #0x0
    5c88:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5c8c:	9360fc3a 	asr	x26, x1, #32
    5c90:	aa0103f4 	mov	x20, x1
    5c94:	aa1a03e0 	mov	x0, x26
    5c98:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5c9c:	97fffba9 	bl	4b40 <fwp_tape_of>
    5ca0:	aa0003f3 	mov	x19, x0
    5ca4:	f9403000 	ldr	x0, [x0, #96]
    5ca8:	b5ffdc40 	cbnz	x0, 5830 <w120+0x50>
    5cac:	17ffff0c 	b	58dc <w120+0xfc>
    5cb0:	aa1a03f7 	mov	x23, x26
    5cb4:	aa0003f8 	mov	x24, x0
    5cb8:	17ffff51 	b	59fc <w120+0x21c>
    5cbc:	aa1803e0 	mov	x0, x24
    5cc0:	17ffffbe 	b	5bb8 <w120+0x3d8>

0000000000005cc4 <fwp_rc_share>:
    5cc4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5cc8:	91188042 	add	x2, x2, #0x620
    5ccc:	f949d843 	ldr	x3, [x2, #5040]
    5cd0:	f949ec41 	ldr	x1, [x2, #5080]
    5cd4:	cb030000 	sub	x0, x0, x3
    5cd8:	eb01401f 	cmp	x0, x1, lsl #16
    5cdc:	540003a2 	b.cs	5d50 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ce0:	d350fc01 	lsr	x1, x0, #16
    5ce4:	f949fc44 	ldr	x4, [x2, #5112]
    5ce8:	8b010821 	add	x1, x1, x1, lsl #2
    5cec:	d37df021 	lsl	x1, x1, #3
    5cf0:	8b010083 	add	x3, x4, x1
    5cf4:	f9401062 	ldr	x2, [x3, #32]
    5cf8:	b40002c2 	cbz	x2, 5d50 <fwp_rc_share+0x8c>
    5cfc:	38616881 	ldrb	w1, [x4, x1]
    5d00:	7100083f 	cmp	w1, #0x2
    5d04:	54000220 	b.eq	5d48 <fwp_rc_share+0x84>  // b.none
    5d08:	7100043f 	cmp	w1, #0x1
    5d0c:	54000221 	b.ne	5d50 <fwp_rc_share+0x8c>  // b.any
    5d10:	29430464 	ldp	w4, w1, [x3, #24]
    5d14:	92403c00 	and	x0, x0, #0xffff
    5d18:	9b047c00 	mul	x0, x0, x4
    5d1c:	d360fc00 	lsr	x0, x0, #32
    5d20:	eb01001f 	cmp	x0, x1
    5d24:	54000162 	b.cs	5d50 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5d28:	8b000042 	add	x2, x2, x0
    5d2c:	39400040 	ldrb	w0, [x2]
    5d30:	34000100 	cbz	w0, 5d50 <fwp_rc_share+0x8c>
    5d34:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5d38:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    5d3c:	9106c000 	add	x0, x0, #0x1b0
    5d40:	910003fd 	mov	x29, sp
    5d44:	97fff97c 	bl	4334 <fwp_trap>
    5d48:	72003c1f 	tst	w0, #0xffff
    5d4c:	54ffff00 	b.eq	5d2c <fwp_rc_share+0x68>  // b.none
    5d50:	d65f03c0 	ret

0000000000005d54 <fwp_rc_free_arr>:
    5d54:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5d58:	91188063 	add	x3, x3, #0x620
    5d5c:	f949d861 	ldr	x1, [x3, #5040]
    5d60:	f949ec62 	ldr	x2, [x3, #5080]
    5d64:	cb010001 	sub	x1, x0, x1
    5d68:	eb02403f 	cmp	x1, x2, lsl #16
    5d6c:	54000342 	b.cs	5dd4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5d70:	d350fc22 	lsr	x2, x1, #16
    5d74:	f949fc65 	ldr	x5, [x3, #5112]
    5d78:	8b020842 	add	x2, x2, x2, lsl #2
    5d7c:	d37df042 	lsl	x2, x2, #3
    5d80:	8b0200a4 	add	x4, x5, x2
    5d84:	f9401083 	ldr	x3, [x4, #32]
    5d88:	b4000263 	cbz	x3, 5dd4 <fwp_rc_free_arr+0x80>
    5d8c:	386268a2 	ldrb	w2, [x5, x2]
    5d90:	7100085f 	cmp	w2, #0x2
    5d94:	540001c0 	b.eq	5dcc <fwp_rc_free_arr+0x78>  // b.none
    5d98:	7100045f 	cmp	w2, #0x1
    5d9c:	540001c1 	b.ne	5dd4 <fwp_rc_free_arr+0x80>  // b.any
    5da0:	29430885 	ldp	w5, w2, [x4, #24]
    5da4:	92403c21 	and	x1, x1, #0xffff
    5da8:	9b057c21 	mul	x1, x1, x5
    5dac:	d360fc21 	lsr	x1, x1, #32
    5db0:	eb02003f 	cmp	x1, x2
    5db4:	54000102 	b.cs	5dd4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5db8:	8b010063 	add	x3, x3, x1
    5dbc:	39400061 	ldrb	w1, [x3]
    5dc0:	7100043f 	cmp	w1, #0x1
    5dc4:	54000081 	b.ne	5dd4 <fwp_rc_free_arr+0x80>  // b.any
    5dc8:	17fffa16 	b	4620 <fwp_mem_free>
    5dcc:	72003c3f 	tst	w1, #0xffff
    5dd0:	54ffff60 	b.eq	5dbc <fwp_rc_free_arr+0x68>  // b.none
    5dd4:	d65f03c0 	ret
    5dd8:	d503201f 	nop
    5ddc:	d503201f 	nop

0000000000005de0 <fwp_rc_dup>:
    5de0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5de4:	91188042 	add	x2, x2, #0x620
    5de8:	f949d841 	ldr	x1, [x2, #5040]
    5dec:	f949ec43 	ldr	x3, [x2, #5080]
    5df0:	cb010001 	sub	x1, x0, x1
    5df4:	eb03403f 	cmp	x1, x3, lsl #16
    5df8:	540003c2 	b.cs	5e70 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5dfc:	d350fc20 	lsr	x0, x1, #16
    5e00:	f949fc44 	ldr	x4, [x2, #5112]
    5e04:	8b000800 	add	x0, x0, x0, lsl #2
    5e08:	d37df002 	lsl	x2, x0, #3
    5e0c:	8b020083 	add	x3, x4, x2
    5e10:	f9401060 	ldr	x0, [x3, #32]
    5e14:	b40002e0 	cbz	x0, 5e70 <fwp_rc_dup+0x90>
    5e18:	38626882 	ldrb	w2, [x4, x2]
    5e1c:	7100085f 	cmp	w2, #0x2
    5e20:	540002a0 	b.eq	5e74 <fwp_rc_dup+0x94>  // b.none
    5e24:	7100045f 	cmp	w2, #0x1
    5e28:	54000241 	b.ne	5e70 <fwp_rc_dup+0x90>  // b.any
    5e2c:	29430864 	ldp	w4, w2, [x3, #24]
    5e30:	92403c21 	and	x1, x1, #0xffff
    5e34:	9b047c21 	mul	x1, x1, x4
    5e38:	d360fc21 	lsr	x1, x1, #32
    5e3c:	eb02003f 	cmp	x1, x2
    5e40:	54000182 	b.cs	5e70 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5e44:	8b010000 	add	x0, x0, x1
    5e48:	39400001 	ldrb	w1, [x0]
    5e4c:	34000121 	cbz	w1, 5e70 <fwp_rc_dup+0x90>
    5e50:	f00000c2 	adrp	x2, 20000 <__data_start>
    5e54:	91014042 	add	x2, x2, #0x50
    5e58:	b9413043 	ldr	w3, [x2, #304]
    5e5c:	35000123 	cbnz	w3, 5e80 <fwp_rc_dup+0xa0>
    5e60:	7103f43f 	cmp	w1, #0xfd
    5e64:	54000168 	b.hi	5e90 <fwp_rc_dup+0xb0>  // b.pmore
    5e68:	11000421 	add	w1, w1, #0x1
    5e6c:	39000001 	strb	w1, [x0]
    5e70:	d65f03c0 	ret
    5e74:	72003c3f 	tst	w1, #0xffff
    5e78:	54fffe80 	b.eq	5e48 <fwp_rc_dup+0x68>  // b.none
    5e7c:	d65f03c0 	ret
    5e80:	f940ac43 	ldr	x3, [x2, #344]
    5e84:	91000463 	add	x3, x3, #0x1
    5e88:	f900ac43 	str	x3, [x2, #344]
    5e8c:	17fffff5 	b	5e60 <fwp_rc_dup+0x80>
    5e90:	17fffa5d 	b	4804 <fwp_rc_wide_dup>

0000000000005e94 <fwp_owned_entry173>:
    5e94:	d10103ff 	sub	sp, sp, #0x40
    5e98:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5e9c:	f947f442 	ldr	x2, [x2, #4072]
    5ea0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ea4:	910083fd 	add	x29, sp, #0x20
    5ea8:	a90353f3 	stp	x19, x20, [sp, #48]
    5eac:	f9400043 	ldr	x3, [x2]
    5eb0:	f9000fe3 	str	x3, [sp, #24]
    5eb4:	d2800003 	mov	x3, #0x0                   	// #0
    5eb8:	a9400c01 	ldp	x1, x3, [x0]
    5ebc:	f9400802 	ldr	x2, [x0, #16]
    5ec0:	ab020022 	adds	x2, x1, x2
    5ec4:	540006e6 	b.vs	5fa0 <fwp_owned_entry173+0x10c>
    5ec8:	910023e1 	add	x1, sp, #0x8
    5ecc:	52800000 	mov	w0, #0x0                   	// #0
    5ed0:	a9008be3 	stp	x3, x2, [sp, #8]
    5ed4:	97fffcf3 	bl	52a0 <fwp_data.part.0.constprop.0>
    5ed8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5edc:	91188063 	add	x3, x3, #0x620
    5ee0:	aa0003f3 	mov	x19, x0
    5ee4:	f949d861 	ldr	x1, [x3, #5040]
    5ee8:	f949ec60 	ldr	x0, [x3, #5080]
    5eec:	cb010261 	sub	x1, x19, x1
    5ef0:	eb00403f 	cmp	x1, x0, lsl #16
    5ef4:	54000322 	b.cs	5f58 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ef8:	d350fc22 	lsr	x2, x1, #16
    5efc:	f949fc63 	ldr	x3, [x3, #5112]
    5f00:	8b020842 	add	x2, x2, x2, lsl #2
    5f04:	d37df042 	lsl	x2, x2, #3
    5f08:	8b020060 	add	x0, x3, x2
    5f0c:	f9401014 	ldr	x20, [x0, #32]
    5f10:	b4000254 	cbz	x20, 5f58 <fwp_owned_entry173+0xc4>
    5f14:	38626862 	ldrb	w2, [x3, x2]
    5f18:	7100085f 	cmp	w2, #0x2
    5f1c:	54000360 	b.eq	5f88 <fwp_owned_entry173+0xf4>  // b.none
    5f20:	7100045f 	cmp	w2, #0x1
    5f24:	540001a1 	b.ne	5f58 <fwp_owned_entry173+0xc4>  // b.any
    5f28:	29430002 	ldp	w2, w0, [x0, #24]
    5f2c:	92403c21 	and	x1, x1, #0xffff
    5f30:	9b027c21 	mul	x1, x1, x2
    5f34:	d360fc21 	lsr	x1, x1, #32
    5f38:	eb00003f 	cmp	x1, x0
    5f3c:	540000e2 	b.cs	5f58 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5f40:	8b010294 	add	x20, x20, x1
    5f44:	39400280 	ldrb	w0, [x20]
    5f48:	7103fc1f 	cmp	w0, #0xff
    5f4c:	54000240 	b.eq	5f94 <fwp_owned_entry173+0x100>  // b.none
    5f50:	52800020 	mov	w0, #0x1                   	// #1
    5f54:	39000280 	strb	w0, [x20]
    5f58:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5f5c:	f947f400 	ldr	x0, [x0, #4072]
    5f60:	f9400fe2 	ldr	x2, [sp, #24]
    5f64:	f9400001 	ldr	x1, [x0]
    5f68:	eb010042 	subs	x2, x2, x1
    5f6c:	d2800001 	mov	x1, #0x0                   	// #0
    5f70:	540001a1 	b.ne	5fa4 <fwp_owned_entry173+0x110>  // b.any
    5f74:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f78:	aa1303e0 	mov	x0, x19
    5f7c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f80:	910103ff 	add	sp, sp, #0x40
    5f84:	d65f03c0 	ret
    5f88:	72003c3f 	tst	w1, #0xffff
    5f8c:	54fffe61 	b.ne	5f58 <fwp_owned_entry173+0xc4>  // b.any
    5f90:	17ffffed 	b	5f44 <fwp_owned_entry173+0xb0>
    5f94:	aa1403e0 	mov	x0, x20
    5f98:	97fff907 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5f9c:	17ffffed 	b	5f50 <fwp_owned_entry173+0xbc>
    5fa0:	97fff2b8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5fa4:	97fff23f 	bl	28a0 <__stack_chk_fail@plt>
    5fa8:	d503201f 	nop
    5fac:	d503201f 	nop

0000000000005fb0 <e173>:
    5fb0:	d10103ff 	sub	sp, sp, #0x40
    5fb4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5fb8:	f947f442 	ldr	x2, [x2, #4072]
    5fbc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5fc0:	910083fd 	add	x29, sp, #0x20
    5fc4:	a90353f3 	stp	x19, x20, [sp, #48]
    5fc8:	f9400043 	ldr	x3, [x2]
    5fcc:	f9000fe3 	str	x3, [sp, #24]
    5fd0:	d2800003 	mov	x3, #0x0                   	// #0
    5fd4:	a9400c01 	ldp	x1, x3, [x0]
    5fd8:	f9400802 	ldr	x2, [x0, #16]
    5fdc:	ab020022 	adds	x2, x1, x2
    5fe0:	54000726 	b.vs	60c4 <e173+0x114>
    5fe4:	910023e1 	add	x1, sp, #0x8
    5fe8:	52800000 	mov	w0, #0x0                   	// #0
    5fec:	a9008be3 	stp	x3, x2, [sp, #8]
    5ff0:	97fffcac 	bl	52a0 <fwp_data.part.0.constprop.0>
    5ff4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5ff8:	91188063 	add	x3, x3, #0x620
    5ffc:	aa0003f3 	mov	x19, x0
    6000:	f949d861 	ldr	x1, [x3, #5040]
    6004:	f949ec60 	ldr	x0, [x3, #5080]
    6008:	cb010261 	sub	x1, x19, x1
    600c:	eb00403f 	cmp	x1, x0, lsl #16
    6010:	54000322 	b.cs	6074 <e173+0xc4>  // b.hs, b.nlast
    6014:	d350fc22 	lsr	x2, x1, #16
    6018:	f949fc63 	ldr	x3, [x3, #5112]
    601c:	8b020842 	add	x2, x2, x2, lsl #2
    6020:	d37df042 	lsl	x2, x2, #3
    6024:	8b020060 	add	x0, x3, x2
    6028:	f9401014 	ldr	x20, [x0, #32]
    602c:	b4000254 	cbz	x20, 6074 <e173+0xc4>
    6030:	38626862 	ldrb	w2, [x3, x2]
    6034:	7100085f 	cmp	w2, #0x2
    6038:	540003a0 	b.eq	60ac <e173+0xfc>  // b.none
    603c:	7100045f 	cmp	w2, #0x1
    6040:	540001a1 	b.ne	6074 <e173+0xc4>  // b.any
    6044:	29430002 	ldp	w2, w0, [x0, #24]
    6048:	92403c21 	and	x1, x1, #0xffff
    604c:	9b027c21 	mul	x1, x1, x2
    6050:	d360fc21 	lsr	x1, x1, #32
    6054:	eb00003f 	cmp	x1, x0
    6058:	540000e2 	b.cs	6074 <e173+0xc4>  // b.hs, b.nlast
    605c:	8b010294 	add	x20, x20, x1
    6060:	39400280 	ldrb	w0, [x20]
    6064:	7103fc1f 	cmp	w0, #0xff
    6068:	54000280 	b.eq	60b8 <e173+0x108>  // b.none
    606c:	52800020 	mov	w0, #0x1                   	// #1
    6070:	39000280 	strb	w0, [x20]
    6074:	aa1303e0 	mov	x0, x19
    6078:	97ffff13 	bl	5cc4 <fwp_rc_share>
    607c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6080:	f947f400 	ldr	x0, [x0, #4072]
    6084:	f9400fe2 	ldr	x2, [sp, #24]
    6088:	f9400001 	ldr	x1, [x0]
    608c:	eb010042 	subs	x2, x2, x1
    6090:	d2800001 	mov	x1, #0x0                   	// #0
    6094:	540001a1 	b.ne	60c8 <e173+0x118>  // b.any
    6098:	a9427bfd 	ldp	x29, x30, [sp, #32]
    609c:	aa1303e0 	mov	x0, x19
    60a0:	a94353f3 	ldp	x19, x20, [sp, #48]
    60a4:	910103ff 	add	sp, sp, #0x40
    60a8:	d65f03c0 	ret
    60ac:	72003c3f 	tst	w1, #0xffff
    60b0:	54fffe21 	b.ne	6074 <e173+0xc4>  // b.any
    60b4:	17ffffeb 	b	6060 <e173+0xb0>
    60b8:	aa1403e0 	mov	x0, x20
    60bc:	97fff8be 	bl	43b4 <fwp_rc_forget_slot.part.0>
    60c0:	17ffffeb 	b	606c <e173+0xbc>
    60c4:	97fff26f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    60c8:	97fff1f6 	bl	28a0 <__stack_chk_fail@plt>
    60cc:	d503201f 	nop

00000000000060d0 <fwp_drop1>:
    60d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60d4:	910003fd 	mov	x29, sp
    60d8:	a90153f3 	stp	x19, x20, [sp, #16]
    60dc:	f90013f5 	str	x21, [sp, #32]
    60e0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    60e4:	911882b4 	add	x20, x21, #0x620
    60e8:	f949da81 	ldr	x1, [x20, #5040]
    60ec:	f949ee82 	ldr	x2, [x20, #5080]
    60f0:	cb010001 	sub	x1, x0, x1
    60f4:	eb02403f 	cmp	x1, x2, lsl #16
    60f8:	54000382 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    60fc:	d350fc22 	lsr	x2, x1, #16
    6100:	f949fe84 	ldr	x4, [x20, #5112]
    6104:	8b020842 	add	x2, x2, x2, lsl #2
    6108:	d37df042 	lsl	x2, x2, #3
    610c:	8b020083 	add	x3, x4, x2
    6110:	f9401073 	ldr	x19, [x3, #32]
    6114:	b40002b3 	cbz	x19, 6168 <fwp_drop1+0x98>
    6118:	38626882 	ldrb	w2, [x4, x2]
    611c:	7100085f 	cmp	w2, #0x2
    6120:	540002c0 	b.eq	6178 <fwp_drop1+0xa8>  // b.none
    6124:	7100045f 	cmp	w2, #0x1
    6128:	54000201 	b.ne	6168 <fwp_drop1+0x98>  // b.any
    612c:	29430864 	ldp	w4, w2, [x3, #24]
    6130:	92403c21 	and	x1, x1, #0xffff
    6134:	9b047c21 	mul	x1, x1, x4
    6138:	d360fc21 	lsr	x1, x1, #32
    613c:	eb02003f 	cmp	x1, x2
    6140:	54000142 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    6144:	8b010273 	add	x19, x19, x1
    6148:	39400261 	ldrb	w1, [x19]
    614c:	340000e1 	cbz	w1, 6168 <fwp_drop1+0x98>
    6150:	7100043f 	cmp	w1, #0x1
    6154:	540001e0 	b.eq	6190 <fwp_drop1+0xc0>  // b.none
    6158:	7103fc3f 	cmp	w1, #0xff
    615c:	540002e0 	b.eq	61b8 <fwp_drop1+0xe8>  // b.none
    6160:	51000421 	sub	w1, w1, #0x1
    6164:	39000261 	strb	w1, [x19]
    6168:	a94153f3 	ldp	x19, x20, [sp, #16]
    616c:	f94013f5 	ldr	x21, [sp, #32]
    6170:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6174:	d65f03c0 	ret
    6178:	72003c3f 	tst	w1, #0xffff
    617c:	54fffe60 	b.eq	6148 <fwp_drop1+0x78>  // b.none
    6180:	a94153f3 	ldp	x19, x20, [sp, #16]
    6184:	f94013f5 	ldr	x21, [sp, #32]
    6188:	a8c37bfd 	ldp	x29, x30, [sp], #48
    618c:	d65f03c0 	ret
    6190:	f9400813 	ldr	x19, [x0, #16]
    6194:	97fffef0 	bl	5d54 <fwp_rc_free_arr>
    6198:	911882a0 	add	x0, x21, #0x620
    619c:	f949d801 	ldr	x1, [x0, #5040]
    61a0:	f949ec00 	ldr	x0, [x0, #5080]
    61a4:	cb010261 	sub	x1, x19, x1
    61a8:	eb00403f 	cmp	x1, x0, lsl #16
    61ac:	54fffde2 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    61b0:	aa1303e0 	mov	x0, x19
    61b4:	17ffffd2 	b	60fc <fwp_drop1+0x2c>
    61b8:	ca534660 	eor	x0, x19, x19, lsr #17
    61bc:	911882b5 	add	x21, x21, #0x620
    61c0:	ca402400 	eor	x0, x0, x0, lsr #9
    61c4:	92401c00 	and	x0, x0, #0xff
    61c8:	910a2402 	add	x2, x0, #0x289
    61cc:	8b000ea0 	add	x0, x21, x0, lsl #3
    61d0:	8b020ea2 	add	x2, x21, x2, lsl #3
    61d4:	f94a2400 	ldr	x0, [x0, #5192]
    61d8:	b50000a0 	cbnz	x0, 61ec <fwp_drop1+0x11c>
    61dc:	14000013 	b	6228 <fwp_drop1+0x158>
    61e0:	91004002 	add	x2, x0, #0x10
    61e4:	f9400800 	ldr	x0, [x0, #16]
    61e8:	b4000200 	cbz	x0, 6228 <fwp_drop1+0x158>
    61ec:	f9400001 	ldr	x1, [x0]
    61f0:	eb13003f 	cmp	x1, x19
    61f4:	54ffff61 	b.ne	61e0 <fwp_drop1+0x110>  // b.any
    61f8:	f9400041 	ldr	x1, [x2]
    61fc:	f9400420 	ldr	x0, [x1, #8]
    6200:	d1000400 	sub	x0, x0, #0x1
    6204:	f9000420 	str	x0, [x1, #8]
    6208:	f103f81f 	cmp	x0, #0xfe
    620c:	54fffae1 	b.ne	6168 <fwp_drop1+0x98>  // b.any
    6210:	39400260 	ldrb	w0, [x19]
    6214:	7103fc1f 	cmp	w0, #0xff
    6218:	540000e0 	b.eq	6234 <fwp_drop1+0x164>  // b.none
    621c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6220:	39000260 	strb	w0, [x19]
    6224:	17ffffd1 	b	6168 <fwp_drop1+0x98>
    6228:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    622c:	913d2000 	add	x0, x0, #0xf48
    6230:	97fff841 	bl	4334 <fwp_trap>
    6234:	aa1303e0 	mov	x0, x19
    6238:	97fff85f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    623c:	17fffff8 	b	621c <fwp_drop1+0x14c>

0000000000006240 <fwp_drop0>:
    6240:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6244:	910003fd 	mov	x29, sp
    6248:	a90153f3 	stp	x19, x20, [sp, #16]
    624c:	f90013f5 	str	x21, [sp, #32]
    6250:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    6254:	911882b4 	add	x20, x21, #0x620
    6258:	f949da81 	ldr	x1, [x20, #5040]
    625c:	f949ee82 	ldr	x2, [x20, #5080]
    6260:	cb010001 	sub	x1, x0, x1
    6264:	eb02403f 	cmp	x1, x2, lsl #16
    6268:	54000382 	b.cs	62d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    626c:	d350fc22 	lsr	x2, x1, #16
    6270:	f949fe84 	ldr	x4, [x20, #5112]
    6274:	8b020842 	add	x2, x2, x2, lsl #2
    6278:	d37df042 	lsl	x2, x2, #3
    627c:	8b020083 	add	x3, x4, x2
    6280:	f9401073 	ldr	x19, [x3, #32]
    6284:	b40002b3 	cbz	x19, 62d8 <fwp_drop0+0x98>
    6288:	38626882 	ldrb	w2, [x4, x2]
    628c:	7100085f 	cmp	w2, #0x2
    6290:	540002c0 	b.eq	62e8 <fwp_drop0+0xa8>  // b.none
    6294:	7100045f 	cmp	w2, #0x1
    6298:	54000201 	b.ne	62d8 <fwp_drop0+0x98>  // b.any
    629c:	29430864 	ldp	w4, w2, [x3, #24]
    62a0:	92403c21 	and	x1, x1, #0xffff
    62a4:	9b047c21 	mul	x1, x1, x4
    62a8:	d360fc21 	lsr	x1, x1, #32
    62ac:	eb02003f 	cmp	x1, x2
    62b0:	54000142 	b.cs	62d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    62b4:	8b010273 	add	x19, x19, x1
    62b8:	39400261 	ldrb	w1, [x19]
    62bc:	340000e1 	cbz	w1, 62d8 <fwp_drop0+0x98>
    62c0:	7100043f 	cmp	w1, #0x1
    62c4:	540001e0 	b.eq	6300 <fwp_drop0+0xc0>  // b.none
    62c8:	7103fc3f 	cmp	w1, #0xff
    62cc:	540002e0 	b.eq	6328 <fwp_drop0+0xe8>  // b.none
    62d0:	51000421 	sub	w1, w1, #0x1
    62d4:	39000261 	strb	w1, [x19]
    62d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62dc:	f94013f5 	ldr	x21, [sp, #32]
    62e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62e4:	d65f03c0 	ret
    62e8:	72003c3f 	tst	w1, #0xffff
    62ec:	54fffe60 	b.eq	62b8 <fwp_drop0+0x78>  // b.none
    62f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    62f4:	f94013f5 	ldr	x21, [sp, #32]
    62f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62fc:	d65f03c0 	ret
    6300:	f9400813 	ldr	x19, [x0, #16]
    6304:	97fffe94 	bl	5d54 <fwp_rc_free_arr>
    6308:	911882a0 	add	x0, x21, #0x620
    630c:	f949d801 	ldr	x1, [x0, #5040]
    6310:	f949ec00 	ldr	x0, [x0, #5080]
    6314:	cb010261 	sub	x1, x19, x1
    6318:	eb00403f 	cmp	x1, x0, lsl #16
    631c:	54fffde2 	b.cs	62d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6320:	aa1303e0 	mov	x0, x19
    6324:	17ffffd2 	b	626c <fwp_drop0+0x2c>
    6328:	ca534660 	eor	x0, x19, x19, lsr #17
    632c:	911882b5 	add	x21, x21, #0x620
    6330:	ca402400 	eor	x0, x0, x0, lsr #9
    6334:	92401c00 	and	x0, x0, #0xff
    6338:	910a2402 	add	x2, x0, #0x289
    633c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6340:	8b020ea2 	add	x2, x21, x2, lsl #3
    6344:	f94a2400 	ldr	x0, [x0, #5192]
    6348:	b50000a0 	cbnz	x0, 635c <fwp_drop0+0x11c>
    634c:	14000013 	b	6398 <fwp_drop0+0x158>
    6350:	91004002 	add	x2, x0, #0x10
    6354:	f9400800 	ldr	x0, [x0, #16]
    6358:	b4000200 	cbz	x0, 6398 <fwp_drop0+0x158>
    635c:	f9400001 	ldr	x1, [x0]
    6360:	eb13003f 	cmp	x1, x19
    6364:	54ffff61 	b.ne	6350 <fwp_drop0+0x110>  // b.any
    6368:	f9400041 	ldr	x1, [x2]
    636c:	f9400420 	ldr	x0, [x1, #8]
    6370:	d1000400 	sub	x0, x0, #0x1
    6374:	f9000420 	str	x0, [x1, #8]
    6378:	f103f81f 	cmp	x0, #0xfe
    637c:	54fffae1 	b.ne	62d8 <fwp_drop0+0x98>  // b.any
    6380:	39400260 	ldrb	w0, [x19]
    6384:	7103fc1f 	cmp	w0, #0xff
    6388:	540000e0 	b.eq	63a4 <fwp_drop0+0x164>  // b.none
    638c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6390:	39000260 	strb	w0, [x19]
    6394:	17ffffd1 	b	62d8 <fwp_drop0+0x98>
    6398:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    639c:	913d2000 	add	x0, x0, #0xf48
    63a0:	97fff7e5 	bl	4334 <fwp_trap>
    63a4:	aa1303e0 	mov	x0, x19
    63a8:	97fff803 	bl	43b4 <fwp_rc_forget_slot.part.0>
    63ac:	17fffff8 	b	638c <fwp_drop0+0x14c>

00000000000063b0 <fwp_closure_drop>:
    63b0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbc0>
    63b4:	911880a4 	add	x4, x5, #0x620
    63b8:	aa0003e1 	mov	x1, x0
    63bc:	f949d882 	ldr	x2, [x4, #5040]
    63c0:	f949ec80 	ldr	x0, [x4, #5080]
    63c4:	cb020022 	sub	x2, x1, x2
    63c8:	eb00405f 	cmp	x2, x0, lsl #16
    63cc:	54000662 	b.cs	6498 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    63d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63d4:	d350fc43 	lsr	x3, x2, #16
    63d8:	910003fd 	mov	x29, sp
    63dc:	8b030863 	add	x3, x3, x3, lsl #2
    63e0:	f949fc84 	ldr	x4, [x4, #5112]
    63e4:	d37df063 	lsl	x3, x3, #3
    63e8:	f9000bf3 	str	x19, [sp, #16]
    63ec:	8b030080 	add	x0, x4, x3
    63f0:	f9401013 	ldr	x19, [x0, #32]
    63f4:	b40002b3 	cbz	x19, 6448 <fwp_closure_drop+0x98>
    63f8:	38636883 	ldrb	w3, [x4, x3]
    63fc:	7100087f 	cmp	w3, #0x2
    6400:	54000420 	b.eq	6484 <fwp_closure_drop+0xd4>  // b.none
    6404:	7100047f 	cmp	w3, #0x1
    6408:	54000201 	b.ne	6448 <fwp_closure_drop+0x98>  // b.any
    640c:	29430003 	ldp	w3, w0, [x0, #24]
    6410:	92403c42 	and	x2, x2, #0xffff
    6414:	9b037c42 	mul	x2, x2, x3
    6418:	d360fc42 	lsr	x2, x2, #32
    641c:	eb00005f 	cmp	x2, x0
    6420:	54000142 	b.cs	6448 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6424:	8b020273 	add	x19, x19, x2
    6428:	39400260 	ldrb	w0, [x19]
    642c:	340000e0 	cbz	w0, 6448 <fwp_closure_drop+0x98>
    6430:	7100041f 	cmp	w0, #0x1
    6434:	54000100 	b.eq	6454 <fwp_closure_drop+0xa4>  // b.none
    6438:	7103fc1f 	cmp	w0, #0xff
    643c:	54000300 	b.eq	649c <fwp_closure_drop+0xec>  // b.none
    6440:	51000400 	sub	w0, w0, #0x1
    6444:	39000260 	strb	w0, [x19]
    6448:	f9400bf3 	ldr	x19, [sp, #16]
    644c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6450:	d65f03c0 	ret
    6454:	d53bd040 	mrs	x0, tpidr_el0
    6458:	91400000 	add	x0, x0, #0x0, lsl #12
    645c:	91004000 	add	x0, x0, #0x10
    6460:	f9400000 	ldr	x0, [x0]
    6464:	b4000080 	cbz	x0, 6474 <fwp_closure_drop+0xc4>
    6468:	f9400bf3 	ldr	x19, [sp, #16]
    646c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6470:	17fff92c 	b	4920 <fwp_closure_drop_push>
    6474:	f9400bf3 	ldr	x19, [sp, #16]
    6478:	aa0103e0 	mov	x0, x1
    647c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6480:	17fff96d 	b	4a34 <fwp_closure_drop.part.0>
    6484:	72003c5f 	tst	w2, #0xffff
    6488:	54fffd00 	b.eq	6428 <fwp_closure_drop+0x78>  // b.none
    648c:	f9400bf3 	ldr	x19, [sp, #16]
    6490:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6494:	d65f03c0 	ret
    6498:	d65f03c0 	ret
    649c:	ca534660 	eor	x0, x19, x19, lsr #17
    64a0:	911880a5 	add	x5, x5, #0x620
    64a4:	ca402400 	eor	x0, x0, x0, lsr #9
    64a8:	92401c00 	and	x0, x0, #0xff
    64ac:	910a2402 	add	x2, x0, #0x289
    64b0:	8b000ca0 	add	x0, x5, x0, lsl #3
    64b4:	8b020ca2 	add	x2, x5, x2, lsl #3
    64b8:	f94a2400 	ldr	x0, [x0, #5192]
    64bc:	b50000a0 	cbnz	x0, 64d0 <fwp_closure_drop+0x120>
    64c0:	14000013 	b	650c <fwp_closure_drop+0x15c>
    64c4:	91004002 	add	x2, x0, #0x10
    64c8:	f9400800 	ldr	x0, [x0, #16]
    64cc:	b4000200 	cbz	x0, 650c <fwp_closure_drop+0x15c>
    64d0:	f9400001 	ldr	x1, [x0]
    64d4:	eb13003f 	cmp	x1, x19
    64d8:	54ffff61 	b.ne	64c4 <fwp_closure_drop+0x114>  // b.any
    64dc:	f9400041 	ldr	x1, [x2]
    64e0:	f9400420 	ldr	x0, [x1, #8]
    64e4:	d1000400 	sub	x0, x0, #0x1
    64e8:	f9000420 	str	x0, [x1, #8]
    64ec:	f103f81f 	cmp	x0, #0xfe
    64f0:	54fffac1 	b.ne	6448 <fwp_closure_drop+0x98>  // b.any
    64f4:	39400260 	ldrb	w0, [x19]
    64f8:	7103fc1f 	cmp	w0, #0xff
    64fc:	540000e0 	b.eq	6518 <fwp_closure_drop+0x168>  // b.none
    6500:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6504:	39000260 	strb	w0, [x19]
    6508:	17ffffd0 	b	6448 <fwp_closure_drop+0x98>
    650c:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    6510:	913d2000 	add	x0, x0, #0xf48
    6514:	97fff788 	bl	4334 <fwp_trap>
    6518:	aa1303e0 	mov	x0, x19
    651c:	97fff7a6 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6520:	17fffff8 	b	6500 <fwp_closure_drop+0x150>

0000000000006524 <fwp_owned_tape_release>:
    6524:	b4000920 	cbz	x0, 6648 <fwp_owned_tape_release+0x124>
    6528:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    652c:	910003fd 	mov	x29, sp
    6530:	a90153f3 	stp	x19, x20, [sp, #16]
    6534:	aa0003f3 	mov	x19, x0
    6538:	f9400000 	ldr	x0, [x0]
    653c:	b4000060 	cbz	x0, 6548 <fwp_owned_tape_release+0x24>
    6540:	f9400661 	ldr	x1, [x19, #8]
    6544:	f9000401 	str	x1, [x0, #8]
    6548:	f9400661 	ldr	x1, [x19, #8]
    654c:	b4000041 	cbz	x1, 6554 <fwp_owned_tape_release+0x30>
    6550:	f9000020 	str	x0, [x1]
    6554:	f9400a60 	ldr	x0, [x19, #16]
    6558:	f9403401 	ldr	x1, [x0, #104]
    655c:	b40005a1 	cbz	x1, 6610 <fwp_owned_tape_release+0xec>
    6560:	a9450a60 	ldp	x0, x2, [x19, #80]
    6564:	eb00005f 	cmp	x2, x0
    6568:	540002cd 	b.le	65c0 <fwp_owned_tape_release+0x9c>
    656c:	d2800014 	mov	x20, #0x0                   	// #0
    6570:	f90013f5 	str	x21, [sp, #32]
    6574:	d2800015 	mov	x21, #0x0                   	// #0
    6578:	f9402260 	ldr	x0, [x19, #64]
    657c:	910006b5 	add	x21, x21, #0x1
    6580:	f8746800 	ldr	x0, [x0, x20]
    6584:	d63f0020 	blr	x1
    6588:	f9402260 	ldr	x0, [x19, #64]
    658c:	f9400a61 	ldr	x1, [x19, #16]
    6590:	8b140000 	add	x0, x0, x20
    6594:	91004294 	add	x20, x20, #0x10
    6598:	f9400400 	ldr	x0, [x0, #8]
    659c:	f9403421 	ldr	x1, [x1, #104]
    65a0:	d63f0020 	blr	x1
    65a4:	a9450261 	ldp	x1, x0, [x19, #80]
    65a8:	cb010000 	sub	x0, x0, x1
    65ac:	eb15001f 	cmp	x0, x21
    65b0:	f9400a60 	ldr	x0, [x19, #16]
    65b4:	f9403401 	ldr	x1, [x0, #104]
    65b8:	54fffe0c 	b.gt	6578 <fwp_owned_tape_release+0x54>
    65bc:	f94013f5 	ldr	x21, [sp, #32]
    65c0:	f9403663 	ldr	x3, [x19, #104]
    65c4:	f9401262 	ldr	x2, [x19, #32]
    65c8:	f100007f 	cmp	x3, #0x0
    65cc:	540001ed 	b.le	6608 <fwp_owned_tape_release+0xe4>
    65d0:	d2800014 	mov	x20, #0x0                   	// #0
    65d4:	d503201f 	nop
    65d8:	f9402660 	ldr	x0, [x19, #72]
    65dc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    65e0:	eb02001f 	cmp	x0, x2
    65e4:	540000c0 	b.eq	65fc <fwp_owned_tape_release+0xd8>  // b.none
    65e8:	d63f0020 	blr	x1
    65ec:	f9400a60 	ldr	x0, [x19, #16]
    65f0:	f9401262 	ldr	x2, [x19, #32]
    65f4:	f9403663 	ldr	x3, [x19, #104]
    65f8:	f9403401 	ldr	x1, [x0, #104]
    65fc:	91000694 	add	x20, x20, #0x1
    6600:	eb14007f 	cmp	x3, x20
    6604:	54fffeac 	b.gt	65d8 <fwp_owned_tape_release+0xb4>
    6608:	aa0203e0 	mov	x0, x2
    660c:	d63f0020 	blr	x1
    6610:	f9401660 	ldr	x0, [x19, #40]
    6614:	97ffff67 	bl	63b0 <fwp_closure_drop>
    6618:	f9401a60 	ldr	x0, [x19, #48]
    661c:	97ffff65 	bl	63b0 <fwp_closure_drop>
    6620:	f9401e60 	ldr	x0, [x19, #56]
    6624:	97ffff63 	bl	63b0 <fwp_closure_drop>
    6628:	f9402260 	ldr	x0, [x19, #64]
    662c:	97fff7fd 	bl	4620 <fwp_mem_free>
    6630:	f9402660 	ldr	x0, [x19, #72]
    6634:	97fff7fb 	bl	4620 <fwp_mem_free>
    6638:	aa1303e0 	mov	x0, x19
    663c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6640:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6644:	17fff7f7 	b	4620 <fwp_mem_free>
    6648:	d65f03c0 	ret
    664c:	d503201f 	nop

0000000000006650 <fwp_tape_finish>:
    6650:	d10203ff 	sub	sp, sp, #0x80
    6654:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6658:	f947f421 	ldr	x1, [x1, #4072]
    665c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6660:	910103fd 	add	x29, sp, #0x40
    6664:	a9065bf5 	stp	x21, x22, [sp, #96]
    6668:	a90763f7 	stp	x23, x24, [sp, #112]
    666c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6670:	910142f6 	add	x22, x23, #0x50
    6674:	f9400022 	ldr	x2, [x1]
    6678:	f9001fe2 	str	x2, [sp, #56]
    667c:	d2800002 	mov	x2, #0x0                   	// #0
    6680:	910342c0 	add	x0, x22, #0xd0
    6684:	97fff67c 	bl	4074 <fwp_tape_buffers_dispose>
    6688:	f90086df 	str	xzr, [x22, #264]
    668c:	f94092c0 	ldr	x0, [x22, #288]
    6690:	f100001f 	cmp	x0, #0x0
    6694:	5400034d 	b.le	66fc <fwp_tape_finish+0xac>
    6698:	910003f8 	mov	x24, sp
    669c:	d2800015 	mov	x21, #0x0                   	// #0
    66a0:	a90553f3 	stp	x19, x20, [sp, #80]
    66a4:	d2800014 	mov	x20, #0x0                   	// #0
    66a8:	91000694 	add	x20, x20, #0x1
    66ac:	f94046d3 	ldr	x19, [x22, #136]
    66b0:	8b150273 	add	x19, x19, x21
    66b4:	9101a2b5 	add	x21, x21, #0x68
    66b8:	aa1303e0 	mov	x0, x19
    66bc:	97fff256 	bl	3014 <fwp_tape_unlink_scope>
    66c0:	aa1803e0 	mov	x0, x24
    66c4:	a9440663 	ldp	x3, x1, [x19, #64]
    66c8:	f9001be1 	str	x1, [sp, #48]
    66cc:	f9400e62 	ldr	x2, [x19, #24]
    66d0:	a9020be3 	stp	x3, x2, [sp, #32]
    66d4:	ad410261 	ldp	q1, q0, [x19, #32]
    66d8:	ad0003e1 	stp	q1, q0, [sp]
    66dc:	97fff666 	bl	4074 <fwp_tape_buffers_dispose>
    66e0:	f9403260 	ldr	x0, [x19, #96]
    66e4:	97ffff90 	bl	6524 <fwp_owned_tape_release>
    66e8:	f900327f 	str	xzr, [x19, #96]
    66ec:	f94092c0 	ldr	x0, [x22, #288]
    66f0:	eb14001f 	cmp	x0, x20
    66f4:	54fffdac 	b.gt	66a8 <fwp_tape_finish+0x58>
    66f8:	a94553f3 	ldp	x19, x20, [sp, #80]
    66fc:	910142e0 	add	x0, x23, #0x50
    6700:	f9404400 	ldr	x0, [x0, #136]
    6704:	b4000040 	cbz	x0, 670c <fwp_tape_finish+0xbc>
    6708:	97fff63a 	bl	3ff0 <ad_raw_free.part.0>
    670c:	910142f7 	add	x23, x23, #0x50
    6710:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6714:	f947f400 	ldr	x0, [x0, #4072]
    6718:	f90046ff 	str	xzr, [x23, #136]
    671c:	f9008aff 	str	xzr, [x23, #272]
    6720:	f90092ff 	str	xzr, [x23, #288]
    6724:	f900b2ff 	str	xzr, [x23, #352]
    6728:	f9401fe2 	ldr	x2, [sp, #56]
    672c:	f9400001 	ldr	x1, [x0]
    6730:	eb010042 	subs	x2, x2, x1
    6734:	d2800001 	mov	x1, #0x0                   	// #0
    6738:	540000c1 	b.ne	6750 <fwp_tape_finish+0x100>  // b.any
    673c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6740:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6744:	a94763f7 	ldp	x23, x24, [sp, #112]
    6748:	910203ff 	add	sp, sp, #0x80
    674c:	d65f03c0 	ret
    6750:	a90553f3 	stp	x19, x20, [sp, #80]
    6754:	97fff053 	bl	28a0 <__stack_chk_fail@plt>
    6758:	d503201f 	nop
    675c:	d503201f 	nop

0000000000006760 <fwp_tape_scope_release>:
    6760:	d10243ff 	sub	sp, sp, #0x90
    6764:	a9047bfd 	stp	x29, x30, [sp, #64]
    6768:	910103fd 	add	x29, sp, #0x40
    676c:	a90553f3 	stp	x19, x20, [sp, #80]
    6770:	aa0003f4 	mov	x20, x0
    6774:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6778:	f947f400 	ldr	x0, [x0, #4072]
    677c:	b9400285 	ldr	w5, [x20]
    6780:	f9400001 	ldr	x1, [x0]
    6784:	f9001fe1 	str	x1, [sp, #56]
    6788:	d2800001 	mov	x1, #0x0                   	// #0
    678c:	37f806c5 	tbnz	w5, #31, 6864 <fwp_tape_scope_release+0x104>
    6790:	a90763f7 	stp	x23, x24, [sp, #112]
    6794:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6798:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    679c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    67a0:	d00000d3 	adrp	x19, 20000 <__data_start>
    67a4:	910003f7 	mov	x23, sp
    67a8:	91014273 	add	x19, x19, #0x50
    67ac:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    67b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    67b4:	52800d16 	mov	w22, #0x68                  	// #104
    67b8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    67bc:	f90043f9 	str	x25, [sp, #128]
    67c0:	14000006 	b	67d8 <fwp_tape_scope_release+0x78>
    67c4:	97fff62c 	bl	4074 <fwp_tape_buffers_dispose>
    67c8:	aa1903e0 	mov	x0, x25
    67cc:	97ffff56 	bl	6524 <fwp_owned_tape_release>
    67d0:	b9400285 	ldr	w5, [x20]
    67d4:	37f80425 	tbnz	w5, #31, 6858 <fwp_tape_scope_release+0xf8>
    67d8:	f9404666 	ldr	x6, [x19, #136]
    67dc:	9b367ca5 	smull	x5, w5, w22
    67e0:	8b0500c0 	add	x0, x6, x5
    67e4:	97fff20c 	bl	3014 <fwp_tape_unlink_scope>
    67e8:	ad410001 	ldp	q1, q0, [x0, #32]
    67ec:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    67f0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    67f4:	f9400c03 	ldr	x3, [x0, #24]
    67f8:	ad0003e1 	stp	q1, q0, [sp]
    67fc:	b86568c1 	ldr	w1, [x6, x5]
    6800:	a9440804 	ldp	x4, x2, [x0, #64]
    6804:	b900041f 	str	wzr, [x0, #4]
    6808:	f9403019 	ldr	x25, [x0, #96]
    680c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6810:	f9000c1f 	str	xzr, [x0, #24]
    6814:	a9020fe4 	stp	x4, x3, [sp, #32]
    6818:	f9001be2 	str	x2, [sp, #48]
    681c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6820:	f900301f 	str	xzr, [x0, #96]
    6824:	6b15003f 	cmp	w1, w21
    6828:	540000e8 	b.hi	6844 <fwp_tape_scope_release+0xe4>  // b.pmore
    682c:	9343fca5 	asr	x5, x5, #3
    6830:	f940b260 	ldr	x0, [x19, #352]
    6834:	9b187ca5 	mul	x5, x5, x24
    6838:	eb0000bf 	cmp	x5, x0
    683c:	5400004a 	b.ge	6844 <fwp_tape_scope_release+0xe4>  // b.tcont
    6840:	f900b265 	str	x5, [x19, #352]
    6844:	aa1703e0 	mov	x0, x23
    6848:	b5fffbf9 	cbnz	x25, 67c4 <fwp_tape_scope_release+0x64>
    684c:	97fff652 	bl	4194 <fwp_tape_buffers_release>
    6850:	b9400285 	ldr	w5, [x20]
    6854:	36fffc25 	tbz	w5, #31, 67d8 <fwp_tape_scope_release+0x78>
    6858:	a9465bf5 	ldp	x21, x22, [sp, #96]
    685c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6860:	f94043f9 	ldr	x25, [sp, #128]
    6864:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6868:	f947f400 	ldr	x0, [x0, #4072]
    686c:	f9401fe2 	ldr	x2, [sp, #56]
    6870:	f9400001 	ldr	x1, [x0]
    6874:	eb010042 	subs	x2, x2, x1
    6878:	d2800001 	mov	x1, #0x0                   	// #0
    687c:	540000a1 	b.ne	6890 <fwp_tape_scope_release+0x130>  // b.any
    6880:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6884:	a94553f3 	ldp	x19, x20, [sp, #80]
    6888:	910243ff 	add	sp, sp, #0x90
    688c:	d65f03c0 	ret
    6890:	a9065bf5 	stp	x21, x22, [sp, #96]
    6894:	a90763f7 	stp	x23, x24, [sp, #112]
    6898:	f90043f9 	str	x25, [sp, #128]
    689c:	97fff001 	bl	28a0 <__stack_chk_fail@plt>

00000000000068a0 <fwp_drop4>:
    68a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    68a4:	910003fd 	mov	x29, sp
    68a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    68ac:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    68b0:	911882d5 	add	x21, x22, #0x620
    68b4:	a90153f3 	stp	x19, x20, [sp, #16]
    68b8:	aa0003f3 	mov	x19, x0
    68bc:	f949daa1 	ldr	x1, [x21, #5040]
    68c0:	f949eea0 	ldr	x0, [x21, #5080]
    68c4:	cb010261 	sub	x1, x19, x1
    68c8:	eb00403f 	cmp	x1, x0, lsl #16
    68cc:	54000382 	b.cs	693c <fwp_drop4+0x9c>  // b.hs, b.nlast
    68d0:	d350fc22 	lsr	x2, x1, #16
    68d4:	f949fea3 	ldr	x3, [x21, #5112]
    68d8:	8b020842 	add	x2, x2, x2, lsl #2
    68dc:	d37df042 	lsl	x2, x2, #3
    68e0:	8b020060 	add	x0, x3, x2
    68e4:	f9401014 	ldr	x20, [x0, #32]
    68e8:	b40002b4 	cbz	x20, 693c <fwp_drop4+0x9c>
    68ec:	38626862 	ldrb	w2, [x3, x2]
    68f0:	7100085f 	cmp	w2, #0x2
    68f4:	540002c0 	b.eq	694c <fwp_drop4+0xac>  // b.none
    68f8:	7100045f 	cmp	w2, #0x1
    68fc:	54000201 	b.ne	693c <fwp_drop4+0x9c>  // b.any
    6900:	29430002 	ldp	w2, w0, [x0, #24]
    6904:	92403c21 	and	x1, x1, #0xffff
    6908:	9b027c21 	mul	x1, x1, x2
    690c:	d360fc21 	lsr	x1, x1, #32
    6910:	eb00003f 	cmp	x1, x0
    6914:	54000142 	b.cs	693c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6918:	8b010294 	add	x20, x20, x1
    691c:	39400280 	ldrb	w0, [x20]
    6920:	340000e0 	cbz	w0, 693c <fwp_drop4+0x9c>
    6924:	7100041f 	cmp	w0, #0x1
    6928:	540001e0 	b.eq	6964 <fwp_drop4+0xc4>  // b.none
    692c:	7103fc1f 	cmp	w0, #0xff
    6930:	540007c0 	b.eq	6a28 <fwp_drop4+0x188>  // b.none
    6934:	51000400 	sub	w0, w0, #0x1
    6938:	39000280 	strb	w0, [x20]
    693c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6940:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6944:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6948:	d65f03c0 	ret
    694c:	72003c3f 	tst	w1, #0xffff
    6950:	54fffe60 	b.eq	691c <fwp_drop4+0x7c>  // b.none
    6954:	a94153f3 	ldp	x19, x20, [sp, #16]
    6958:	a9425bf5 	ldp	x21, x22, [sp, #32]
    695c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6960:	d65f03c0 	ret
    6964:	911882c2 	add	x2, x22, #0x620
    6968:	f9400660 	ldr	x0, [x19, #8]
    696c:	f949d841 	ldr	x1, [x2, #5040]
    6970:	f949ec42 	ldr	x2, [x2, #5080]
    6974:	cb010001 	sub	x1, x0, x1
    6978:	eb02403f 	cmp	x1, x2, lsl #16
    697c:	54000362 	b.cs	69e8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6980:	d350fc22 	lsr	x2, x1, #16
    6984:	8b020842 	add	x2, x2, x2, lsl #2
    6988:	d37df042 	lsl	x2, x2, #3
    698c:	8b020064 	add	x4, x3, x2
    6990:	f9401094 	ldr	x20, [x4, #32]
    6994:	b40002b4 	cbz	x20, 69e8 <fwp_drop4+0x148>
    6998:	38626862 	ldrb	w2, [x3, x2]
    699c:	7100085f 	cmp	w2, #0x2
    69a0:	540003e0 	b.eq	6a1c <fwp_drop4+0x17c>  // b.none
    69a4:	7100045f 	cmp	w2, #0x1
    69a8:	54000201 	b.ne	69e8 <fwp_drop4+0x148>  // b.any
    69ac:	29430883 	ldp	w3, w2, [x4, #24]
    69b0:	92403c21 	and	x1, x1, #0xffff
    69b4:	9b037c21 	mul	x1, x1, x3
    69b8:	d360fc21 	lsr	x1, x1, #32
    69bc:	eb02003f 	cmp	x1, x2
    69c0:	54000142 	b.cs	69e8 <fwp_drop4+0x148>  // b.hs, b.nlast
    69c4:	8b010294 	add	x20, x20, x1
    69c8:	39400281 	ldrb	w1, [x20]
    69cc:	340000e1 	cbz	w1, 69e8 <fwp_drop4+0x148>
    69d0:	7100043f 	cmp	w1, #0x1
    69d4:	54000200 	b.eq	6a14 <fwp_drop4+0x174>  // b.none
    69d8:	7103fc3f 	cmp	w1, #0xff
    69dc:	54000640 	b.eq	6aa4 <fwp_drop4+0x204>  // b.none
    69e0:	51000421 	sub	w1, w1, #0x1
    69e4:	39000281 	strb	w1, [x20]
    69e8:	f9400a74 	ldr	x20, [x19, #16]
    69ec:	aa1303e0 	mov	x0, x19
    69f0:	97fffcd9 	bl	5d54 <fwp_rc_free_arr>
    69f4:	911882c0 	add	x0, x22, #0x620
    69f8:	f949d801 	ldr	x1, [x0, #5040]
    69fc:	f949ec00 	ldr	x0, [x0, #5080]
    6a00:	cb010281 	sub	x1, x20, x1
    6a04:	eb00403f 	cmp	x1, x0, lsl #16
    6a08:	54fff9a2 	b.cs	693c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6a0c:	aa1403f3 	mov	x19, x20
    6a10:	17ffffb0 	b	68d0 <fwp_drop4+0x30>
    6a14:	97fffcd0 	bl	5d54 <fwp_rc_free_arr>
    6a18:	17fffff4 	b	69e8 <fwp_drop4+0x148>
    6a1c:	72003c3f 	tst	w1, #0xffff
    6a20:	54fffe41 	b.ne	69e8 <fwp_drop4+0x148>  // b.any
    6a24:	17ffffe9 	b	69c8 <fwp_drop4+0x128>
    6a28:	ca544681 	eor	x1, x20, x20, lsr #17
    6a2c:	911882c0 	add	x0, x22, #0x620
    6a30:	ca412421 	eor	x1, x1, x1, lsr #9
    6a34:	92401c21 	and	x1, x1, #0xff
    6a38:	910a2422 	add	x2, x1, #0x289
    6a3c:	8b010c01 	add	x1, x0, x1, lsl #3
    6a40:	8b020c02 	add	x2, x0, x2, lsl #3
    6a44:	f94a2420 	ldr	x0, [x1, #5192]
    6a48:	b50000a0 	cbnz	x0, 6a5c <fwp_drop4+0x1bc>
    6a4c:	14000013 	b	6a98 <fwp_drop4+0x1f8>
    6a50:	91004002 	add	x2, x0, #0x10
    6a54:	f9400800 	ldr	x0, [x0, #16]
    6a58:	b4000200 	cbz	x0, 6a98 <fwp_drop4+0x1f8>
    6a5c:	f9400001 	ldr	x1, [x0]
    6a60:	eb14003f 	cmp	x1, x20
    6a64:	54ffff61 	b.ne	6a50 <fwp_drop4+0x1b0>  // b.any
    6a68:	f9400041 	ldr	x1, [x2]
    6a6c:	f9400420 	ldr	x0, [x1, #8]
    6a70:	d1000400 	sub	x0, x0, #0x1
    6a74:	f9000420 	str	x0, [x1, #8]
    6a78:	f103f81f 	cmp	x0, #0xfe
    6a7c:	54fff601 	b.ne	693c <fwp_drop4+0x9c>  // b.any
    6a80:	39400280 	ldrb	w0, [x20]
    6a84:	7103fc1f 	cmp	w0, #0xff
    6a88:	54000460 	b.eq	6b14 <fwp_drop4+0x274>  // b.none
    6a8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a90:	39000280 	strb	w0, [x20]
    6a94:	17ffffaa 	b	693c <fwp_drop4+0x9c>
    6a98:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    6a9c:	913d2000 	add	x0, x0, #0xf48
    6aa0:	97fff625 	bl	4334 <fwp_trap>
    6aa4:	ca544680 	eor	x0, x20, x20, lsr #17
    6aa8:	911882c1 	add	x1, x22, #0x620
    6aac:	ca402400 	eor	x0, x0, x0, lsr #9
    6ab0:	92401c00 	and	x0, x0, #0xff
    6ab4:	910a2402 	add	x2, x0, #0x289
    6ab8:	8b000c20 	add	x0, x1, x0, lsl #3
    6abc:	8b020c22 	add	x2, x1, x2, lsl #3
    6ac0:	f94a2400 	ldr	x0, [x0, #5192]
    6ac4:	b50000a0 	cbnz	x0, 6ad8 <fwp_drop4+0x238>
    6ac8:	17fffff4 	b	6a98 <fwp_drop4+0x1f8>
    6acc:	91004002 	add	x2, x0, #0x10
    6ad0:	f9400800 	ldr	x0, [x0, #16]
    6ad4:	b4fffe20 	cbz	x0, 6a98 <fwp_drop4+0x1f8>
    6ad8:	f9400001 	ldr	x1, [x0]
    6adc:	eb14003f 	cmp	x1, x20
    6ae0:	54ffff61 	b.ne	6acc <fwp_drop4+0x22c>  // b.any
    6ae4:	f9400041 	ldr	x1, [x2]
    6ae8:	f9400420 	ldr	x0, [x1, #8]
    6aec:	d1000400 	sub	x0, x0, #0x1
    6af0:	f9000420 	str	x0, [x1, #8]
    6af4:	f103f81f 	cmp	x0, #0xfe
    6af8:	54fff781 	b.ne	69e8 <fwp_drop4+0x148>  // b.any
    6afc:	39400280 	ldrb	w0, [x20]
    6b00:	7103fc1f 	cmp	w0, #0xff
    6b04:	540000e0 	b.eq	6b20 <fwp_drop4+0x280>  // b.none
    6b08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b0c:	39000280 	strb	w0, [x20]
    6b10:	17ffffb6 	b	69e8 <fwp_drop4+0x148>
    6b14:	aa1403e0 	mov	x0, x20
    6b18:	97fff627 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6b1c:	17ffffdc 	b	6a8c <fwp_drop4+0x1ec>
    6b20:	aa1403e0 	mov	x0, x20
    6b24:	97fff624 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6b28:	17fffff8 	b	6b08 <fwp_drop4+0x268>
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_arg_drop37>:
    6b30:	7100003f 	cmp	w1, #0x0
    6b34:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b38:	54000041 	b.ne	6b40 <fwp_arg_drop37+0x10>  // b.any
    6b3c:	d65f03c0 	ret
    6b40:	f9400000 	ldr	x0, [x0]
    6b44:	17ffff57 	b	68a0 <fwp_drop4>
    6b48:	d503201f 	nop
    6b4c:	d503201f 	nop

0000000000006b50 <fwp_task_dispose>:
    6b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b54:	910003fd 	mov	x29, sp
    6b58:	f9000bf3 	str	x19, [sp, #16]
    6b5c:	aa0003f3 	mov	x19, x0
    6b60:	39414000 	ldrb	w0, [x0, #80]
    6b64:	36000720 	tbz	w0, #0, 6c48 <fwp_task_dispose+0xf8>
    6b68:	f9400a60 	ldr	x0, [x19, #16]
    6b6c:	b50006e0 	cbnz	x0, 6c48 <fwp_task_dispose+0xf8>
    6b70:	a9478660 	ldp	x0, x1, [x19, #120]
    6b74:	39014e7f 	strb	wzr, [x19, #83]
    6b78:	f9003e7f 	str	xzr, [x19, #120]
    6b7c:	f100003f 	cmp	x1, #0x0
    6b80:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6b84:	54000040 	b.eq	6b8c <fwp_task_dispose+0x3c>  // b.none
    6b88:	d63f0020 	blr	x1
    6b8c:	f9405660 	ldr	x0, [x19, #168]
    6b90:	97fff6a4 	bl	4620 <fwp_mem_free>
    6b94:	f900567f 	str	xzr, [x19, #168]
    6b98:	b9405e60 	ldr	w0, [x19, #92]
    6b9c:	7100041f 	cmp	w0, #0x1
    6ba0:	54000420 	b.eq	6c24 <fwp_task_dispose+0xd4>  // b.none
    6ba4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    6ba8:	91188042 	add	x2, x2, #0x620
    6bac:	f949d840 	ldr	x0, [x2, #5040]
    6bb0:	f949ec41 	ldr	x1, [x2, #5080]
    6bb4:	cb000260 	sub	x0, x19, x0
    6bb8:	eb01401f 	cmp	x0, x1, lsl #16
    6bbc:	540002e2 	b.cs	6c18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6bc0:	d350fc01 	lsr	x1, x0, #16
    6bc4:	f949fc44 	ldr	x4, [x2, #5112]
    6bc8:	8b010821 	add	x1, x1, x1, lsl #2
    6bcc:	d37df021 	lsl	x1, x1, #3
    6bd0:	8b010083 	add	x3, x4, x1
    6bd4:	f9401062 	ldr	x2, [x3, #32]
    6bd8:	b4000202 	cbz	x2, 6c18 <fwp_task_dispose+0xc8>
    6bdc:	38616881 	ldrb	w1, [x4, x1]
    6be0:	7100083f 	cmp	w1, #0x2
    6be4:	54000280 	b.eq	6c34 <fwp_task_dispose+0xe4>  // b.none
    6be8:	7100043f 	cmp	w1, #0x1
    6bec:	54000161 	b.ne	6c18 <fwp_task_dispose+0xc8>  // b.any
    6bf0:	29430464 	ldp	w4, w1, [x3, #24]
    6bf4:	92403c00 	and	x0, x0, #0xffff
    6bf8:	9b047c00 	mul	x0, x0, x4
    6bfc:	d360fc00 	lsr	x0, x0, #32
    6c00:	eb01001f 	cmp	x0, x1
    6c04:	540000a2 	b.cs	6c18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6c08:	8b000042 	add	x2, x2, x0
    6c0c:	39400040 	ldrb	w0, [x2]
    6c10:	7100041f 	cmp	w0, #0x1
    6c14:	54000080 	b.eq	6c24 <fwp_task_dispose+0xd4>  // b.none
    6c18:	f9400bf3 	ldr	x19, [sp, #16]
    6c1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c20:	d65f03c0 	ret
    6c24:	aa1303e0 	mov	x0, x19
    6c28:	f9400bf3 	ldr	x19, [sp, #16]
    6c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c30:	17fff67c 	b	4620 <fwp_mem_free>
    6c34:	72003c1f 	tst	w0, #0xffff
    6c38:	54fffea0 	b.eq	6c0c <fwp_task_dispose+0xbc>  // b.none
    6c3c:	f9400bf3 	ldr	x19, [sp, #16]
    6c40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c44:	d65f03c0 	ret
    6c48:	97ffef2a 	bl	28f0 <abort@plt>
    6c4c:	d503201f 	nop

0000000000006c50 <fwp_free_zombie>:
    6c50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c54:	910003fd 	mov	x29, sp
    6c58:	a90153f3 	stp	x19, x20, [sp, #16]
    6c5c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6c60:	91014281 	add	x1, x20, #0x50
    6c64:	f940b433 	ldr	x19, [x1, #360]
    6c68:	b4000333 	cbz	x19, 6ccc <fwp_free_zombie+0x7c>
    6c6c:	f9404c20 	ldr	x0, [x1, #152]
    6c70:	eb00027f 	cmp	x19, x0
    6c74:	540002c0 	b.eq	6ccc <fwp_free_zombie+0x7c>  // b.none
    6c78:	b9417022 	ldr	w2, [x1, #368]
    6c7c:	f9400a60 	ldr	x0, [x19, #16]
    6c80:	7100fc5f 	cmp	w2, #0x3f
    6c84:	5400078c 	b.gt	6d74 <fwp_free_zombie+0x124>
    6c88:	91060023 	add	x3, x1, #0x180
    6c8c:	11000444 	add	w4, w2, #0x1
    6c90:	b9017024 	str	w4, [x1, #368]
    6c94:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6c98:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6c9c:	a9530261 	ldp	x1, x0, [x19, #304]
    6ca0:	b4000741 	cbz	x1, 6d88 <fwp_free_zombie+0x138>
    6ca4:	f9009c20 	str	x0, [x1, #312]
    6ca8:	b4000040 	cbz	x0, 6cb0 <fwp_free_zombie+0x60>
    6cac:	f9009801 	str	x1, [x0, #304]
    6cb0:	91014294 	add	x20, x20, #0x50
    6cb4:	b9405e60 	ldr	w0, [x19, #92]
    6cb8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6cbc:	f900b69f 	str	xzr, [x20, #360]
    6cc0:	34000140 	cbz	w0, 6ce8 <fwp_free_zombie+0x98>
    6cc4:	7100041f 	cmp	w0, #0x1
    6cc8:	54000080 	b.eq	6cd8 <fwp_free_zombie+0x88>  // b.none
    6ccc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cd4:	d65f03c0 	ret
    6cd8:	aa1303e0 	mov	x0, x19
    6cdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ce0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ce4:	17ffff9b 	b	6b50 <fwp_task_dispose>
    6ce8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbc0>
    6cec:	91188082 	add	x2, x4, #0x620
    6cf0:	f949d841 	ldr	x1, [x2, #5040]
    6cf4:	f949ec40 	ldr	x0, [x2, #5080]
    6cf8:	cb010261 	sub	x1, x19, x1
    6cfc:	eb00403f 	cmp	x1, x0, lsl #16
    6d00:	54fffe62 	b.cs	6ccc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6d04:	d350fc20 	lsr	x0, x1, #16
    6d08:	f949fc43 	ldr	x3, [x2, #5112]
    6d0c:	8b000800 	add	x0, x0, x0, lsl #2
    6d10:	d37df000 	lsl	x0, x0, #3
    6d14:	8b000062 	add	x2, x3, x0
    6d18:	f9401054 	ldr	x20, [x2, #32]
    6d1c:	b4fffd94 	cbz	x20, 6ccc <fwp_free_zombie+0x7c>
    6d20:	38606860 	ldrb	w0, [x3, x0]
    6d24:	7100081f 	cmp	w0, #0x2
    6d28:	54000360 	b.eq	6d94 <fwp_free_zombie+0x144>  // b.none
    6d2c:	7100041f 	cmp	w0, #0x1
    6d30:	54fffce1 	b.ne	6ccc <fwp_free_zombie+0x7c>  // b.any
    6d34:	29430043 	ldp	w3, w0, [x2, #24]
    6d38:	92403c21 	and	x1, x1, #0xffff
    6d3c:	9b037c21 	mul	x1, x1, x3
    6d40:	d360fc21 	lsr	x1, x1, #32
    6d44:	eb00003f 	cmp	x1, x0
    6d48:	54fffc22 	b.cs	6ccc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6d4c:	8b010294 	add	x20, x20, x1
    6d50:	39400280 	ldrb	w0, [x20]
    6d54:	34fffbc0 	cbz	w0, 6ccc <fwp_free_zombie+0x7c>
    6d58:	7100041f 	cmp	w0, #0x1
    6d5c:	54fffbe0 	b.eq	6cd8 <fwp_free_zombie+0x88>  // b.none
    6d60:	7103fc1f 	cmp	w0, #0xff
    6d64:	540001e0 	b.eq	6da0 <fwp_free_zombie+0x150>  // b.none
    6d68:	51000400 	sub	w0, w0, #0x1
    6d6c:	39000280 	strb	w0, [x20]
    6d70:	17ffffd7 	b	6ccc <fwp_free_zombie+0x7c>
    6d74:	f9400e61 	ldr	x1, [x19, #24]
    6d78:	97ffef12 	bl	29c0 <munmap@plt>
    6d7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6d80:	a9530261 	ldp	x1, x0, [x19, #304]
    6d84:	b5fff901 	cbnz	x1, 6ca4 <fwp_free_zombie+0x54>
    6d88:	91014282 	add	x2, x20, #0x50
    6d8c:	f901c040 	str	x0, [x2, #896]
    6d90:	17ffffc6 	b	6ca8 <fwp_free_zombie+0x58>
    6d94:	72003c3f 	tst	w1, #0xffff
    6d98:	54fff9a1 	b.ne	6ccc <fwp_free_zombie+0x7c>  // b.any
    6d9c:	17ffffed 	b	6d50 <fwp_free_zombie+0x100>
    6da0:	ca544680 	eor	x0, x20, x20, lsr #17
    6da4:	91188084 	add	x4, x4, #0x620
    6da8:	ca402400 	eor	x0, x0, x0, lsr #9
    6dac:	92401c00 	and	x0, x0, #0xff
    6db0:	910a2402 	add	x2, x0, #0x289
    6db4:	8b000c80 	add	x0, x4, x0, lsl #3
    6db8:	8b020c82 	add	x2, x4, x2, lsl #3
    6dbc:	f94a2400 	ldr	x0, [x0, #5192]
    6dc0:	b50000a0 	cbnz	x0, 6dd4 <fwp_free_zombie+0x184>
    6dc4:	14000013 	b	6e10 <fwp_free_zombie+0x1c0>
    6dc8:	91004002 	add	x2, x0, #0x10
    6dcc:	f9400800 	ldr	x0, [x0, #16]
    6dd0:	b4000200 	cbz	x0, 6e10 <fwp_free_zombie+0x1c0>
    6dd4:	f9400001 	ldr	x1, [x0]
    6dd8:	eb14003f 	cmp	x1, x20
    6ddc:	54ffff61 	b.ne	6dc8 <fwp_free_zombie+0x178>  // b.any
    6de0:	f9400041 	ldr	x1, [x2]
    6de4:	f9400420 	ldr	x0, [x1, #8]
    6de8:	d1000400 	sub	x0, x0, #0x1
    6dec:	f9000420 	str	x0, [x1, #8]
    6df0:	f103f81f 	cmp	x0, #0xfe
    6df4:	54fff6c1 	b.ne	6ccc <fwp_free_zombie+0x7c>  // b.any
    6df8:	39400280 	ldrb	w0, [x20]
    6dfc:	7103fc1f 	cmp	w0, #0xff
    6e00:	540000e0 	b.eq	6e1c <fwp_free_zombie+0x1cc>  // b.none
    6e04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e08:	39000280 	strb	w0, [x20]
    6e0c:	17ffffb0 	b	6ccc <fwp_free_zombie+0x7c>
    6e10:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    6e14:	913d2000 	add	x0, x0, #0xf48
    6e18:	97fff547 	bl	4334 <fwp_trap>
    6e1c:	aa1403e0 	mov	x0, x20
    6e20:	97fff565 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6e24:	17fffff8 	b	6e04 <fwp_free_zombie+0x1b4>
    6e28:	d503201f 	nop
    6e2c:	d503201f 	nop

0000000000006e30 <fwp_block>:
    6e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e34:	910003fd 	mov	x29, sp
    6e38:	a90153f3 	stp	x19, x20, [sp, #16]
    6e3c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6e40:	91014274 	add	x20, x19, #0x50
    6e44:	f9406682 	ldr	x2, [x20, #200]
    6e48:	b4000642 	cbz	x2, 6f10 <fwp_block+0xe0>
    6e4c:	91014261 	add	x1, x19, #0x50
    6e50:	f9408040 	ldr	x0, [x2, #256]
    6e54:	f9006420 	str	x0, [x1, #200]
    6e58:	b40006a0 	cbz	x0, 6f2c <fwp_block+0xfc>
    6e5c:	d503201f 	nop
    6e60:	91014263 	add	x3, x19, #0x50
    6e64:	3901505f 	strb	wzr, [x2, #84]
    6e68:	f9404c64 	ldr	x4, [x3, #152]
    6e6c:	eb02009f 	cmp	x4, x2
    6e70:	54000440 	b.eq	6ef8 <fwp_block+0xc8>  // b.none
    6e74:	f941c465 	ldr	x5, [x3, #904]
    6e78:	f9004c62 	str	x2, [x3, #152]
    6e7c:	f9400441 	ldr	x1, [x2, #8]
    6e80:	f9004885 	str	x5, [x4, #144]
    6e84:	f941c865 	ldr	x5, [x3, #912]
    6e88:	f9004c85 	str	x5, [x4, #152]
    6e8c:	f941cc65 	ldr	x5, [x3, #920]
    6e90:	f9005085 	str	x5, [x4, #160]
    6e94:	f941d065 	ldr	x5, [x3, #928]
    6e98:	f9005485 	str	x5, [x4, #168]
    6e9c:	f941d465 	ldr	x5, [x3, #936]
    6ea0:	f9005885 	str	x5, [x4, #176]
    6ea4:	f941d865 	ldr	x5, [x3, #944]
    6ea8:	f9005c85 	str	x5, [x4, #184]
    6eac:	f941dc65 	ldr	x5, [x3, #952]
    6eb0:	f9006085 	str	x5, [x4, #192]
    6eb4:	f9400480 	ldr	x0, [x4, #8]
    6eb8:	f9404844 	ldr	x4, [x2, #144]
    6ebc:	f901c464 	str	x4, [x3, #904]
    6ec0:	f9404c44 	ldr	x4, [x2, #152]
    6ec4:	f901c864 	str	x4, [x3, #912]
    6ec8:	f9405044 	ldr	x4, [x2, #160]
    6ecc:	f901cc64 	str	x4, [x3, #920]
    6ed0:	f9405444 	ldr	x4, [x2, #168]
    6ed4:	f901d064 	str	x4, [x3, #928]
    6ed8:	f9405844 	ldr	x4, [x2, #176]
    6edc:	f901d464 	str	x4, [x3, #936]
    6ee0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6ee4:	f901d864 	str	x4, [x3, #944]
    6ee8:	f901dc62 	str	x2, [x3, #952]
    6eec:	97ffee85 	bl	2900 <swapcontext@plt>
    6ef0:	97ffff58 	bl	6c50 <fwp_free_zombie>
    6ef4:	d503201f 	nop
    6ef8:	91014260 	add	x0, x19, #0x50
    6efc:	b943c000 	ldr	w0, [x0, #960]
    6f00:	340001a0 	cbz	w0, 6f34 <fwp_block+0x104>
    6f04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f0c:	d65f03c0 	ret
    6f10:	97fff750 	bl	4c50 <fwp_poll_events>
    6f14:	f9406682 	ldr	x2, [x20, #200]
    6f18:	b4ffffc2 	cbz	x2, 6f10 <fwp_block+0xe0>
    6f1c:	91014261 	add	x1, x19, #0x50
    6f20:	f9408040 	ldr	x0, [x2, #256]
    6f24:	f9006420 	str	x0, [x1, #200]
    6f28:	b5fff9c0 	cbnz	x0, 6e60 <fwp_block+0x30>
    6f2c:	f900603f 	str	xzr, [x1, #192]
    6f30:	17ffffcc 	b	6e60 <fwp_block+0x30>
    6f34:	90000020 	adrp	x0, a000 <_IO_stdin_used+0x410>
    6f38:	91078000 	add	x0, x0, #0x1e0
    6f3c:	97ffeebd 	bl	2a30 <getenv@plt>
    6f40:	5284e202 	mov	w2, #0x2710                	// #10000
    6f44:	b4000060 	cbz	x0, 6f50 <fwp_block+0x120>
    6f48:	39400001 	ldrb	w1, [x0]
    6f4c:	350000c1 	cbnz	w1, 6f64 <fwp_block+0x134>
    6f50:	91014273 	add	x19, x19, #0x50
    6f54:	b903c262 	str	w2, [x19, #960]
    6f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f60:	d65f03c0 	ret
    6f64:	52800142 	mov	w2, #0xa                   	// #10
    6f68:	d2800001 	mov	x1, #0x0                   	// #0
    6f6c:	97ffee01 	bl	2770 <strtoll@plt>
    6f70:	d1000403 	sub	x3, x0, #0x1
    6f74:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6f78:	eb02007f 	cmp	x3, x2
    6f7c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6f80:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6f84:	17fffff3 	b	6f50 <fwp_block+0x120>
    6f88:	d503201f 	nop
    6f8c:	d503201f 	nop

0000000000006f90 <fwp_drop10>:
    6f90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6f94:	910003fd 	mov	x29, sp
    6f98:	a90153f3 	stp	x19, x20, [sp, #16]
    6f9c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    6fa0:	f90013f5 	str	x21, [sp, #32]
    6fa4:	91188275 	add	x21, x19, #0x620
    6fa8:	f949daa1 	ldr	x1, [x21, #5040]
    6fac:	f949eea2 	ldr	x2, [x21, #5080]
    6fb0:	cb010001 	sub	x1, x0, x1
    6fb4:	eb02403f 	cmp	x1, x2, lsl #16
    6fb8:	54000382 	b.cs	7028 <fwp_drop10+0x98>  // b.hs, b.nlast
    6fbc:	d350fc22 	lsr	x2, x1, #16
    6fc0:	f949fea3 	ldr	x3, [x21, #5112]
    6fc4:	8b020842 	add	x2, x2, x2, lsl #2
    6fc8:	d37df042 	lsl	x2, x2, #3
    6fcc:	8b020064 	add	x4, x3, x2
    6fd0:	f9401094 	ldr	x20, [x4, #32]
    6fd4:	b40002b4 	cbz	x20, 7028 <fwp_drop10+0x98>
    6fd8:	38626862 	ldrb	w2, [x3, x2]
    6fdc:	7100085f 	cmp	w2, #0x2
    6fe0:	540007a0 	b.eq	70d4 <fwp_drop10+0x144>  // b.none
    6fe4:	7100045f 	cmp	w2, #0x1
    6fe8:	54000201 	b.ne	7028 <fwp_drop10+0x98>  // b.any
    6fec:	29430885 	ldp	w5, w2, [x4, #24]
    6ff0:	92403c21 	and	x1, x1, #0xffff
    6ff4:	9b057c21 	mul	x1, x1, x5
    6ff8:	d360fc21 	lsr	x1, x1, #32
    6ffc:	eb02003f 	cmp	x1, x2
    7000:	54000142 	b.cs	7028 <fwp_drop10+0x98>  // b.hs, b.nlast
    7004:	8b010294 	add	x20, x20, x1
    7008:	39400281 	ldrb	w1, [x20]
    700c:	340000e1 	cbz	w1, 7028 <fwp_drop10+0x98>
    7010:	7100043f 	cmp	w1, #0x1
    7014:	54000120 	b.eq	7038 <fwp_drop10+0xa8>  // b.none
    7018:	7103fc3f 	cmp	w1, #0xff
    701c:	540007c0 	b.eq	7114 <fwp_drop10+0x184>  // b.none
    7020:	51000421 	sub	w1, w1, #0x1
    7024:	39000281 	strb	w1, [x20]
    7028:	a94153f3 	ldp	x19, x20, [sp, #16]
    702c:	f94013f5 	ldr	x21, [sp, #32]
    7030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7034:	d65f03c0 	ret
    7038:	f9400001 	ldr	x1, [x0]
    703c:	b7f80581 	tbnz	x1, #63, 70ec <fwp_drop10+0x15c>
    7040:	91188273 	add	x19, x19, #0x620
    7044:	f949da61 	ldr	x1, [x19, #5040]
    7048:	f949ee62 	ldr	x2, [x19, #5080]
    704c:	cb010001 	sub	x1, x0, x1
    7050:	eb02403f 	cmp	x1, x2, lsl #16
    7054:	54fffea2 	b.cs	7028 <fwp_drop10+0x98>  // b.hs, b.nlast
    7058:	d350fc22 	lsr	x2, x1, #16
    705c:	8b020842 	add	x2, x2, x2, lsl #2
    7060:	d37df042 	lsl	x2, x2, #3
    7064:	8b020065 	add	x5, x3, x2
    7068:	f94010a4 	ldr	x4, [x5, #32]
    706c:	b4fffde4 	cbz	x4, 7028 <fwp_drop10+0x98>
    7070:	38626862 	ldrb	w2, [x3, x2]
    7074:	7100085f 	cmp	w2, #0x2
    7078:	54000220 	b.eq	70bc <fwp_drop10+0x12c>  // b.none
    707c:	7100045f 	cmp	w2, #0x1
    7080:	54fffd41 	b.ne	7028 <fwp_drop10+0x98>  // b.any
    7084:	294308a3 	ldp	w3, w2, [x5, #24]
    7088:	92403c21 	and	x1, x1, #0xffff
    708c:	9b037c21 	mul	x1, x1, x3
    7090:	d360fc21 	lsr	x1, x1, #32
    7094:	eb02003f 	cmp	x1, x2
    7098:	54fffc82 	b.cs	7028 <fwp_drop10+0x98>  // b.hs, b.nlast
    709c:	8b010084 	add	x4, x4, x1
    70a0:	39400081 	ldrb	w1, [x4]
    70a4:	7100043f 	cmp	w1, #0x1
    70a8:	54fffc01 	b.ne	7028 <fwp_drop10+0x98>  // b.any
    70ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    70b0:	f94013f5 	ldr	x21, [sp, #32]
    70b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70b8:	17fff55a 	b	4620 <fwp_mem_free>
    70bc:	72003c3f 	tst	w1, #0xffff
    70c0:	54ffff00 	b.eq	70a0 <fwp_drop10+0x110>  // b.none
    70c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    70c8:	f94013f5 	ldr	x21, [sp, #32]
    70cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70d0:	d65f03c0 	ret
    70d4:	72003c3f 	tst	w1, #0xffff
    70d8:	54fff980 	b.eq	7008 <fwp_drop10+0x78>  // b.none
    70dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    70e0:	f94013f5 	ldr	x21, [sp, #32]
    70e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70e8:	d65f03c0 	ret
    70ec:	f9400414 	ldr	x20, [x0, #8]
    70f0:	97fffb19 	bl	5d54 <fwp_rc_free_arr>
    70f4:	91188260 	add	x0, x19, #0x620
    70f8:	f949d801 	ldr	x1, [x0, #5040]
    70fc:	f949ec00 	ldr	x0, [x0, #5080]
    7100:	cb010281 	sub	x1, x20, x1
    7104:	eb00403f 	cmp	x1, x0, lsl #16
    7108:	54fff902 	b.cs	7028 <fwp_drop10+0x98>  // b.hs, b.nlast
    710c:	aa1403e0 	mov	x0, x20
    7110:	17ffffab 	b	6fbc <fwp_drop10+0x2c>
    7114:	ca544680 	eor	x0, x20, x20, lsr #17
    7118:	91188273 	add	x19, x19, #0x620
    711c:	ca402400 	eor	x0, x0, x0, lsr #9
    7120:	92401c00 	and	x0, x0, #0xff
    7124:	910a2402 	add	x2, x0, #0x289
    7128:	8b000e60 	add	x0, x19, x0, lsl #3
    712c:	8b020e62 	add	x2, x19, x2, lsl #3
    7130:	f94a2400 	ldr	x0, [x0, #5192]
    7134:	b50000a0 	cbnz	x0, 7148 <fwp_drop10+0x1b8>
    7138:	14000013 	b	7184 <fwp_drop10+0x1f4>
    713c:	91004002 	add	x2, x0, #0x10
    7140:	f9400800 	ldr	x0, [x0, #16]
    7144:	b4000200 	cbz	x0, 7184 <fwp_drop10+0x1f4>
    7148:	f9400001 	ldr	x1, [x0]
    714c:	eb14003f 	cmp	x1, x20
    7150:	54ffff61 	b.ne	713c <fwp_drop10+0x1ac>  // b.any
    7154:	f9400041 	ldr	x1, [x2]
    7158:	f9400420 	ldr	x0, [x1, #8]
    715c:	d1000400 	sub	x0, x0, #0x1
    7160:	f9000420 	str	x0, [x1, #8]
    7164:	f103f81f 	cmp	x0, #0xfe
    7168:	54fff601 	b.ne	7028 <fwp_drop10+0x98>  // b.any
    716c:	39400280 	ldrb	w0, [x20]
    7170:	7103fc1f 	cmp	w0, #0xff
    7174:	540000e0 	b.eq	7190 <fwp_drop10+0x200>  // b.none
    7178:	12800020 	mov	w0, #0xfffffffe            	// #-2
    717c:	39000280 	strb	w0, [x20]
    7180:	17ffffaa 	b	7028 <fwp_drop10+0x98>
    7184:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    7188:	913d2000 	add	x0, x0, #0xf48
    718c:	97fff46a 	bl	4334 <fwp_trap>
    7190:	aa1403e0 	mov	x0, x20
    7194:	97fff488 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7198:	17fffff8 	b	7178 <fwp_drop10+0x1e8>
    719c:	d503201f 	nop

00000000000071a0 <fwp_caps173>:
    71a0:	34000041 	cbz	w1, 71a8 <fwp_caps173+0x8>
    71a4:	d65f03c0 	ret
    71a8:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    71ac:	91188063 	add	x3, x3, #0x620
    71b0:	f949d861 	ldr	x1, [x3, #5040]
    71b4:	f949ec62 	ldr	x2, [x3, #5080]
    71b8:	cb010001 	sub	x1, x0, x1
    71bc:	eb02403f 	cmp	x1, x2, lsl #16
    71c0:	54ffff22 	b.cs	71a4 <fwp_caps173+0x4>  // b.hs, b.nlast
    71c4:	d350fc22 	lsr	x2, x1, #16
    71c8:	f949fc65 	ldr	x5, [x3, #5112]
    71cc:	8b020842 	add	x2, x2, x2, lsl #2
    71d0:	d37df042 	lsl	x2, x2, #3
    71d4:	8b0200a4 	add	x4, x5, x2
    71d8:	f9401083 	ldr	x3, [x4, #32]
    71dc:	b4fffe43 	cbz	x3, 71a4 <fwp_caps173+0x4>
    71e0:	386268a2 	ldrb	w2, [x5, x2]
    71e4:	7100085f 	cmp	w2, #0x2
    71e8:	540001c0 	b.eq	7220 <fwp_caps173+0x80>  // b.none
    71ec:	7100045f 	cmp	w2, #0x1
    71f0:	54fffda1 	b.ne	71a4 <fwp_caps173+0x4>  // b.any
    71f4:	29430885 	ldp	w5, w2, [x4, #24]
    71f8:	92403c21 	and	x1, x1, #0xffff
    71fc:	9b057c21 	mul	x1, x1, x5
    7200:	d360fc21 	lsr	x1, x1, #32
    7204:	eb02003f 	cmp	x1, x2
    7208:	54fffce2 	b.cs	71a4 <fwp_caps173+0x4>  // b.hs, b.nlast
    720c:	8b010063 	add	x3, x3, x1
    7210:	39400061 	ldrb	w1, [x3]
    7214:	7100043f 	cmp	w1, #0x1
    7218:	54fffc61 	b.ne	71a4 <fwp_caps173+0x4>  // b.any
    721c:	17fff501 	b	4620 <fwp_mem_free>
    7220:	72003c3f 	tst	w1, #0xffff
    7224:	54ffff60 	b.eq	7210 <fwp_caps173+0x70>  // b.none
    7228:	d65f03c0 	ret
    722c:	d503201f 	nop

0000000000007230 <f37>:
    7230:	d10203ff 	sub	sp, sp, #0x80
    7234:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    7238:	f947f421 	ldr	x1, [x1, #4072]
    723c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7240:	910083fd 	add	x29, sp, #0x20
    7244:	a9045bf5 	stp	x21, x22, [sp, #64]
    7248:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    724c:	911882a3 	add	x3, x21, #0x620
    7250:	a90353f3 	stp	x19, x20, [sp, #48]
    7254:	aa0003f6 	mov	x22, x0
    7258:	a90563f7 	stp	x23, x24, [sp, #80]
    725c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7260:	f949ec62 	ldr	x2, [x3, #5080]
    7264:	f9400024 	ldr	x4, [x1]
    7268:	f9000fe4 	str	x4, [sp, #24]
    726c:	d2800004 	mov	x4, #0x0                   	// #0
    7270:	f949d861 	ldr	x1, [x3, #5040]
    7274:	d370bc42 	lsl	x2, x2, #16
    7278:	b4001920 	cbz	x0, 759c <f37+0x36c>
    727c:	f9400817 	ldr	x23, [x0, #16]
    7280:	cb0102e1 	sub	x1, x23, x1
    7284:	eb02003f 	cmp	x1, x2
    7288:	540003e2 	b.cs	7304 <f37+0xd4>  // b.hs, b.nlast
    728c:	f949fc60 	ldr	x0, [x3, #5112]
    7290:	d350fc22 	lsr	x2, x1, #16
    7294:	8b020842 	add	x2, x2, x2, lsl #2
    7298:	8b020c02 	add	x2, x0, x2, lsl #3
    729c:	f9401040 	ldr	x0, [x2, #32]
    72a0:	b4000320 	cbz	x0, 7304 <f37+0xd4>
    72a4:	39400043 	ldrb	w3, [x2]
    72a8:	7100087f 	cmp	w3, #0x2
    72ac:	540015e0 	b.eq	7568 <f37+0x338>  // b.none
    72b0:	7100047f 	cmp	w3, #0x1
    72b4:	54000241 	b.ne	72fc <f37+0xcc>  // b.any
    72b8:	29430843 	ldp	w3, w2, [x2, #24]
    72bc:	92403c21 	and	x1, x1, #0xffff
    72c0:	9b037c21 	mul	x1, x1, x3
    72c4:	d360fc21 	lsr	x1, x1, #32
    72c8:	eb02003f 	cmp	x1, x2
    72cc:	54000182 	b.cs	72fc <f37+0xcc>  // b.hs, b.nlast
    72d0:	8b010000 	add	x0, x0, x1
    72d4:	39400001 	ldrb	w1, [x0]
    72d8:	34000121 	cbz	w1, 72fc <f37+0xcc>
    72dc:	b00000c2 	adrp	x2, 20000 <__data_start>
    72e0:	91014042 	add	x2, x2, #0x50
    72e4:	b9413043 	ldr	w3, [x2, #304]
    72e8:	35001463 	cbnz	w3, 7574 <f37+0x344>
    72ec:	7103f43f 	cmp	w1, #0xfd
    72f0:	54001888 	b.hi	7600 <f37+0x3d0>  // b.pmore
    72f4:	11000421 	add	w1, w1, #0x1
    72f8:	39000001 	strb	w1, [x0]
    72fc:	d2800002 	mov	x2, #0x0                   	// #0
    7300:	b40000f6 	cbz	x22, 731c <f37+0xec>
    7304:	aa1603e1 	mov	x1, x22
    7308:	d2800002 	mov	x2, #0x0                   	// #0
    730c:	d503201f 	nop
    7310:	f9400821 	ldr	x1, [x1, #16]
    7314:	91000442 	add	x2, x2, #0x1
    7318:	b5ffffc1 	cbnz	x1, 7310 <f37+0xe0>
    731c:	b4001477 	cbz	x23, 75a8 <f37+0x378>
    7320:	aa1703e1 	mov	x1, x23
    7324:	d2800003 	mov	x3, #0x0                   	// #0
    7328:	f9400821 	ldr	x1, [x1, #16]
    732c:	91000463 	add	x3, x3, #0x1
    7330:	b5ffffc1 	cbnz	x1, 7328 <f37+0xf8>
    7334:	eb02007f 	cmp	x3, x2
    7338:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    733c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7340:	eb00027f 	cmp	x19, x0
    7344:	540010a8 	b.hi	7558 <f37+0x328>  // b.pmore
    7348:	d37ffa74 	lsl	x20, x19, #1
    734c:	52800041 	mov	w1, #0x2                   	// #2
    7350:	91000680 	add	x0, x20, #0x1
    7354:	d37df000 	lsl	x0, x0, #3
    7358:	97fff76e 	bl	5110 <fwp_heap_alloc>
    735c:	aa0003f8 	mov	x24, x0
    7360:	911882a1 	add	x1, x21, #0x620
    7364:	aa0103e0 	mov	x0, x1
    7368:	f9000314 	str	x20, [x24]
    736c:	f949d821 	ldr	x1, [x1, #5040]
    7370:	f949ec00 	ldr	x0, [x0, #5080]
    7374:	cb010301 	sub	x1, x24, x1
    7378:	eb00403f 	cmp	x1, x0, lsl #16
    737c:	54000342 	b.cs	73e4 <f37+0x1b4>  // b.hs, b.nlast
    7380:	911882a2 	add	x2, x21, #0x620
    7384:	d350fc20 	lsr	x0, x1, #16
    7388:	8b000800 	add	x0, x0, x0, lsl #2
    738c:	f949fc43 	ldr	x3, [x2, #5112]
    7390:	d37df002 	lsl	x2, x0, #3
    7394:	8b020060 	add	x0, x3, x2
    7398:	f9401014 	ldr	x20, [x0, #32]
    739c:	b4000254 	cbz	x20, 73e4 <f37+0x1b4>
    73a0:	38626862 	ldrb	w2, [x3, x2]
    73a4:	7100085f 	cmp	w2, #0x2
    73a8:	54000ee0 	b.eq	7584 <f37+0x354>  // b.none
    73ac:	7100045f 	cmp	w2, #0x1
    73b0:	540001a1 	b.ne	73e4 <f37+0x1b4>  // b.any
    73b4:	29430002 	ldp	w2, w0, [x0, #24]
    73b8:	92403c21 	and	x1, x1, #0xffff
    73bc:	9b027c21 	mul	x1, x1, x2
    73c0:	d360fc21 	lsr	x1, x1, #32
    73c4:	eb00003f 	cmp	x1, x0
    73c8:	540000e2 	b.cs	73e4 <f37+0x1b4>  // b.hs, b.nlast
    73cc:	8b010294 	add	x20, x20, x1
    73d0:	39400280 	ldrb	w0, [x20]
    73d4:	7103fc1f 	cmp	w0, #0xff
    73d8:	54001180 	b.eq	7608 <f37+0x3d8>  // b.none
    73dc:	52800020 	mov	w0, #0x1                   	// #1
    73e0:	39000280 	strb	w0, [x20]
    73e4:	b4000253 	cbz	x19, 742c <f37+0x1fc>
    73e8:	8b131313 	add	x19, x24, x19, lsl #4
    73ec:	aa1803f4 	mov	x20, x24
    73f0:	aa1603fa 	mov	x26, x22
    73f4:	aa1703f9 	mov	x25, x23
    73f8:	f9400723 	ldr	x3, [x25, #8]
    73fc:	f9400742 	ldr	x2, [x26, #8]
    7400:	f9400861 	ldr	x1, [x3, #16]
    7404:	f9400840 	ldr	x0, [x2, #16]
    7408:	fd400461 	ldr	d1, [x3, #8]
    740c:	fd400440 	ldr	d0, [x2, #8]
    7410:	97fff8f4 	bl	57e0 <w120>
    7414:	f9000680 	str	x0, [x20, #8]
    7418:	f8010e81 	str	x1, [x20, #16]!
    741c:	f9400b39 	ldr	x25, [x25, #16]
    7420:	f9400b5a 	ldr	x26, [x26, #16]
    7424:	eb14027f 	cmp	x19, x20
    7428:	54fffe81 	b.ne	73f8 <f37+0x1c8>  // b.any
    742c:	aa1703e0 	mov	x0, x23
    7430:	97fffd1c 	bl	68a0 <fwp_drop4>
    7434:	aa1603e0 	mov	x0, x22
    7438:	97fffd1a 	bl	68a0 <fwp_drop4>
    743c:	f9400316 	ldr	x22, [x24]
    7440:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7444:	b4000236 	cbz	x22, 7488 <f37+0x258>
    7448:	fd003be8 	str	d8, [sp, #112]
    744c:	2f00e408 	movi	d8, #0x0
    7450:	91002319 	add	x25, x24, #0x8
    7454:	91004317 	add	x23, x24, #0x10
    7458:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    745c:	d2800013 	mov	x19, #0x0                   	// #0
    7460:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7464:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7468:	91000a73 	add	x19, x19, #0x2
    746c:	1e602908 	fadd	d8, d8, d0
    7470:	97fff884 	bl	5680 <f141.constprop.0>
    7474:	aa0003f4 	mov	x20, x0
    7478:	eb1302df 	cmp	x22, x19
    747c:	54ffff28 	b.hi	7460 <f37+0x230>  // b.pmore
    7480:	9e660116 	fmov	x22, d8
    7484:	fd403be8 	ldr	d8, [sp, #112]
    7488:	911882b5 	add	x21, x21, #0x620
    748c:	aa1803e0 	mov	x0, x24
    7490:	97fffec0 	bl	6f90 <fwp_drop10>
    7494:	a900d3f6 	stp	x22, x20, [sp, #8]
    7498:	910023e1 	add	x1, sp, #0x8
    749c:	52800000 	mov	w0, #0x0                   	// #0
    74a0:	97fff780 	bl	52a0 <fwp_data.part.0.constprop.0>
    74a4:	f949daa1 	ldr	x1, [x21, #5040]
    74a8:	aa0003f3 	mov	x19, x0
    74ac:	f949eea0 	ldr	x0, [x21, #5080]
    74b0:	cb010261 	sub	x1, x19, x1
    74b4:	eb00403f 	cmp	x1, x0, lsl #16
    74b8:	54000322 	b.cs	751c <f37+0x2ec>  // b.hs, b.nlast
    74bc:	d350fc22 	lsr	x2, x1, #16
    74c0:	f949fea3 	ldr	x3, [x21, #5112]
    74c4:	8b020842 	add	x2, x2, x2, lsl #2
    74c8:	d37df042 	lsl	x2, x2, #3
    74cc:	8b020060 	add	x0, x3, x2
    74d0:	f9401014 	ldr	x20, [x0, #32]
    74d4:	b4000254 	cbz	x20, 751c <f37+0x2ec>
    74d8:	38626862 	ldrb	w2, [x3, x2]
    74dc:	7100085f 	cmp	w2, #0x2
    74e0:	54000580 	b.eq	7590 <f37+0x360>  // b.none
    74e4:	7100045f 	cmp	w2, #0x1
    74e8:	540001a1 	b.ne	751c <f37+0x2ec>  // b.any
    74ec:	29430002 	ldp	w2, w0, [x0, #24]
    74f0:	92403c21 	and	x1, x1, #0xffff
    74f4:	9b027c21 	mul	x1, x1, x2
    74f8:	d360fc21 	lsr	x1, x1, #32
    74fc:	eb00003f 	cmp	x1, x0
    7500:	540000e2 	b.cs	751c <f37+0x2ec>  // b.hs, b.nlast
    7504:	8b010294 	add	x20, x20, x1
    7508:	39400280 	ldrb	w0, [x20]
    750c:	7103fc1f 	cmp	w0, #0xff
    7510:	54000820 	b.eq	7614 <f37+0x3e4>  // b.none
    7514:	52800020 	mov	w0, #0x1                   	// #1
    7518:	39000280 	strb	w0, [x20]
    751c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7520:	f947f400 	ldr	x0, [x0, #4072]
    7524:	f9400fe2 	ldr	x2, [sp, #24]
    7528:	f9400001 	ldr	x1, [x0]
    752c:	eb010042 	subs	x2, x2, x1
    7530:	d2800001 	mov	x1, #0x0                   	// #0
    7534:	540007a1 	b.ne	7628 <f37+0x3f8>  // b.any
    7538:	a9427bfd 	ldp	x29, x30, [sp, #32]
    753c:	aa1303e0 	mov	x0, x19
    7540:	a94353f3 	ldp	x19, x20, [sp, #48]
    7544:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7548:	a94563f7 	ldp	x23, x24, [sp, #80]
    754c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7550:	910203ff 	add	sp, sp, #0x80
    7554:	d65f03c0 	ret
    7558:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    755c:	9107c000 	add	x0, x0, #0x1f0
    7560:	fd003be8 	str	d8, [sp, #112]
    7564:	97fff374 	bl	4334 <fwp_trap>
    7568:	72003c3f 	tst	w1, #0xffff
    756c:	54ffec81 	b.ne	72fc <f37+0xcc>  // b.any
    7570:	17ffff59 	b	72d4 <f37+0xa4>
    7574:	f940ac43 	ldr	x3, [x2, #344]
    7578:	91000463 	add	x3, x3, #0x1
    757c:	f900ac43 	str	x3, [x2, #344]
    7580:	17ffff5b 	b	72ec <f37+0xbc>
    7584:	72003c3f 	tst	w1, #0xffff
    7588:	54fff2e1 	b.ne	73e4 <f37+0x1b4>  // b.any
    758c:	17ffff91 	b	73d0 <f37+0x1a0>
    7590:	72003c3f 	tst	w1, #0xffff
    7594:	54fffc41 	b.ne	751c <f37+0x2ec>  // b.any
    7598:	17ffffdc 	b	7508 <f37+0x2d8>
    759c:	cb0103e1 	neg	x1, x1
    75a0:	eb02003f 	cmp	x1, x2
    75a4:	540001e3 	b.cc	75e0 <f37+0x3b0>  // b.lo, b.ul, b.last
    75a8:	52800041 	mov	w1, #0x2                   	// #2
    75ac:	d2800100 	mov	x0, #0x8                   	// #8
    75b0:	97fff6d8 	bl	5110 <fwp_heap_alloc>
    75b4:	aa0003f8 	mov	x24, x0
    75b8:	911882a0 	add	x0, x21, #0x620
    75bc:	f900031f 	str	xzr, [x24]
    75c0:	f949d801 	ldr	x1, [x0, #5040]
    75c4:	f949ec00 	ldr	x0, [x0, #5080]
    75c8:	cb010301 	sub	x1, x24, x1
    75cc:	eb00403f 	cmp	x1, x0, lsl #16
    75d0:	54000282 	b.cs	7620 <f37+0x3f0>  // b.hs, b.nlast
    75d4:	d2800013 	mov	x19, #0x0                   	// #0
    75d8:	d2800017 	mov	x23, #0x0                   	// #0
    75dc:	17ffff69 	b	7380 <f37+0x150>
    75e0:	f949fc62 	ldr	x2, [x3, #5112]
    75e4:	d350fc20 	lsr	x0, x1, #16
    75e8:	8b000800 	add	x0, x0, x0, lsl #2
    75ec:	8b000c42 	add	x2, x2, x0, lsl #3
    75f0:	f9401040 	ldr	x0, [x2, #32]
    75f4:	b4fffda0 	cbz	x0, 75a8 <f37+0x378>
    75f8:	d2800017 	mov	x23, #0x0                   	// #0
    75fc:	17ffff2a 	b	72a4 <f37+0x74>
    7600:	97fff481 	bl	4804 <fwp_rc_wide_dup>
    7604:	17ffff3e 	b	72fc <f37+0xcc>
    7608:	aa1403e0 	mov	x0, x20
    760c:	97fff36a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7610:	17ffff73 	b	73dc <f37+0x1ac>
    7614:	aa1403e0 	mov	x0, x20
    7618:	97fff367 	bl	43b4 <fwp_rc_forget_slot.part.0>
    761c:	17ffffbe 	b	7514 <f37+0x2e4>
    7620:	d2800017 	mov	x23, #0x0                   	// #0
    7624:	17ffff82 	b	742c <f37+0x1fc>
    7628:	fd003be8 	str	d8, [sp, #112]
    762c:	97ffec9d 	bl	28a0 <__stack_chk_fail@plt>

0000000000007630 <fwp_owned_entry37>:
    7630:	f9400000 	ldr	x0, [x0]
    7634:	17fffeff 	b	7230 <f37>
    7638:	d503201f 	nop
    763c:	d503201f 	nop

0000000000007640 <e37>:
    7640:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7644:	910003fd 	mov	x29, sp
    7648:	f9000bf3 	str	x19, [sp, #16]
    764c:	f9400013 	ldr	x19, [x0]
    7650:	aa1303e0 	mov	x0, x19
    7654:	97fff99c 	bl	5cc4 <fwp_rc_share>
    7658:	aa1303e0 	mov	x0, x19
    765c:	97fffef5 	bl	7230 <f37>
    7660:	aa0003f3 	mov	x19, x0
    7664:	97fff998 	bl	5cc4 <fwp_rc_share>
    7668:	aa1303e0 	mov	x0, x19
    766c:	f9400bf3 	ldr	x19, [sp, #16]
    7670:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7674:	d65f03c0 	ret
    7678:	d503201f 	nop
    767c:	d503201f 	nop

0000000000007680 <fwp_args37>:
    7680:	7100003f 	cmp	w1, #0x0
    7684:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7688:	54000041 	b.ne	7690 <fwp_args37+0x10>  // b.any
    768c:	d65f03c0 	ret
    7690:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7694:	91188042 	add	x2, x2, #0x620
    7698:	f9400001 	ldr	x1, [x0]
    769c:	f949d843 	ldr	x3, [x2, #5040]
    76a0:	f949ec40 	ldr	x0, [x2, #5080]
    76a4:	cb030021 	sub	x1, x1, x3
    76a8:	eb00403f 	cmp	x1, x0, lsl #16
    76ac:	54ffff02 	b.cs	768c <fwp_args37+0xc>  // b.hs, b.nlast
    76b0:	d350fc20 	lsr	x0, x1, #16
    76b4:	f949fc44 	ldr	x4, [x2, #5112]
    76b8:	8b000800 	add	x0, x0, x0, lsl #2
    76bc:	d37df002 	lsl	x2, x0, #3
    76c0:	8b020083 	add	x3, x4, x2
    76c4:	f9401060 	ldr	x0, [x3, #32]
    76c8:	b4fffe20 	cbz	x0, 768c <fwp_args37+0xc>
    76cc:	38626882 	ldrb	w2, [x4, x2]
    76d0:	7100085f 	cmp	w2, #0x2
    76d4:	54000320 	b.eq	7738 <fwp_args37+0xb8>  // b.none
    76d8:	7100045f 	cmp	w2, #0x1
    76dc:	54fffd81 	b.ne	768c <fwp_args37+0xc>  // b.any
    76e0:	29430864 	ldp	w4, w2, [x3, #24]
    76e4:	92403c21 	and	x1, x1, #0xffff
    76e8:	9b047c21 	mul	x1, x1, x4
    76ec:	d360fc21 	lsr	x1, x1, #32
    76f0:	eb02003f 	cmp	x1, x2
    76f4:	54fffcc2 	b.cs	768c <fwp_args37+0xc>  // b.hs, b.nlast
    76f8:	8b010000 	add	x0, x0, x1
    76fc:	39400001 	ldrb	w1, [x0]
    7700:	34fffc61 	cbz	w1, 768c <fwp_args37+0xc>
    7704:	b00000c2 	adrp	x2, 20000 <__data_start>
    7708:	91014042 	add	x2, x2, #0x50
    770c:	b9413043 	ldr	w3, [x2, #304]
    7710:	350000c3 	cbnz	w3, 7728 <fwp_args37+0xa8>
    7714:	7103f43f 	cmp	w1, #0xfd
    7718:	54000168 	b.hi	7744 <fwp_args37+0xc4>  // b.pmore
    771c:	11000421 	add	w1, w1, #0x1
    7720:	39000001 	strb	w1, [x0]
    7724:	d65f03c0 	ret
    7728:	f940ac43 	ldr	x3, [x2, #344]
    772c:	91000463 	add	x3, x3, #0x1
    7730:	f900ac43 	str	x3, [x2, #344]
    7734:	17fffff8 	b	7714 <fwp_args37+0x94>
    7738:	72003c3f 	tst	w1, #0xffff
    773c:	54fffe00 	b.eq	76fc <fwp_args37+0x7c>  // b.none
    7740:	d65f03c0 	ret
    7744:	17fff430 	b	4804 <fwp_rc_wide_dup>
    7748:	d503201f 	nop
    774c:	d503201f 	nop

0000000000007750 <fwp_caps37>:
    7750:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7754:	910003fd 	mov	x29, sp
    7758:	f9000bf3 	str	x19, [sp, #16]
    775c:	aa0003f3 	mov	x19, x0
    7760:	b9400400 	ldr	w0, [x0, #4]
    7764:	340004a0 	cbz	w0, 77f8 <fwp_caps37+0xa8>
    7768:	f9400660 	ldr	x0, [x19, #8]
    776c:	350004e1 	cbnz	w1, 7808 <fwp_caps37+0xb8>
    7770:	97fffc4c 	bl	68a0 <fwp_drop4>
    7774:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7778:	91188042 	add	x2, x2, #0x620
    777c:	f949d840 	ldr	x0, [x2, #5040]
    7780:	f949ec41 	ldr	x1, [x2, #5080]
    7784:	cb000260 	sub	x0, x19, x0
    7788:	eb01401f 	cmp	x0, x1, lsl #16
    778c:	54000382 	b.cs	77fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7790:	d350fc01 	lsr	x1, x0, #16
    7794:	f949fc44 	ldr	x4, [x2, #5112]
    7798:	8b010821 	add	x1, x1, x1, lsl #2
    779c:	d37df021 	lsl	x1, x1, #3
    77a0:	8b010083 	add	x3, x4, x1
    77a4:	f9401062 	ldr	x2, [x3, #32]
    77a8:	b40002a2 	cbz	x2, 77fc <fwp_caps37+0xac>
    77ac:	38616881 	ldrb	w1, [x4, x1]
    77b0:	7100083f 	cmp	w1, #0x2
    77b4:	54000740 	b.eq	789c <fwp_caps37+0x14c>  // b.none
    77b8:	7100043f 	cmp	w1, #0x1
    77bc:	54000201 	b.ne	77fc <fwp_caps37+0xac>  // b.any
    77c0:	29430464 	ldp	w4, w1, [x3, #24]
    77c4:	92403c00 	and	x0, x0, #0xffff
    77c8:	9b047c00 	mul	x0, x0, x4
    77cc:	d360fc00 	lsr	x0, x0, #32
    77d0:	eb01001f 	cmp	x0, x1
    77d4:	54000142 	b.cs	77fc <fwp_caps37+0xac>  // b.hs, b.nlast
    77d8:	8b000042 	add	x2, x2, x0
    77dc:	39400040 	ldrb	w0, [x2]
    77e0:	7100041f 	cmp	w0, #0x1
    77e4:	540000c1 	b.ne	77fc <fwp_caps37+0xac>  // b.any
    77e8:	aa1303e0 	mov	x0, x19
    77ec:	f9400bf3 	ldr	x19, [sp, #16]
    77f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77f4:	17fff38b 	b	4620 <fwp_mem_free>
    77f8:	34fffbe1 	cbz	w1, 7774 <fwp_caps37+0x24>
    77fc:	f9400bf3 	ldr	x19, [sp, #16]
    7800:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7804:	d65f03c0 	ret
    7808:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    780c:	91188042 	add	x2, x2, #0x620
    7810:	f949d843 	ldr	x3, [x2, #5040]
    7814:	f949ec41 	ldr	x1, [x2, #5080]
    7818:	cb030000 	sub	x0, x0, x3
    781c:	eb01401f 	cmp	x0, x1, lsl #16
    7820:	54fffee2 	b.cs	77fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7824:	d350fc01 	lsr	x1, x0, #16
    7828:	f949fc44 	ldr	x4, [x2, #5112]
    782c:	8b010821 	add	x1, x1, x1, lsl #2
    7830:	d37df021 	lsl	x1, x1, #3
    7834:	8b010083 	add	x3, x4, x1
    7838:	f9401062 	ldr	x2, [x3, #32]
    783c:	b4fffe02 	cbz	x2, 77fc <fwp_caps37+0xac>
    7840:	38616881 	ldrb	w1, [x4, x1]
    7844:	7100083f 	cmp	w1, #0x2
    7848:	54000300 	b.eq	78a8 <fwp_caps37+0x158>  // b.none
    784c:	7100043f 	cmp	w1, #0x1
    7850:	54fffd61 	b.ne	77fc <fwp_caps37+0xac>  // b.any
    7854:	92403c01 	and	x1, x0, #0xffff
    7858:	29430064 	ldp	w4, w0, [x3, #24]
    785c:	9b047c21 	mul	x1, x1, x4
    7860:	d360fc21 	lsr	x1, x1, #32
    7864:	eb00003f 	cmp	x1, x0
    7868:	54fffca2 	b.cs	77fc <fwp_caps37+0xac>  // b.hs, b.nlast
    786c:	8b010042 	add	x2, x2, x1
    7870:	39400040 	ldrb	w0, [x2]
    7874:	34fffc40 	cbz	w0, 77fc <fwp_caps37+0xac>
    7878:	b00000c1 	adrp	x1, 20000 <__data_start>
    787c:	91014021 	add	x1, x1, #0x50
    7880:	b9413023 	ldr	w3, [x1, #304]
    7884:	35000183 	cbnz	w3, 78b4 <fwp_caps37+0x164>
    7888:	7103f41f 	cmp	w0, #0xfd
    788c:	540001c8 	b.hi	78c4 <fwp_caps37+0x174>  // b.pmore
    7890:	11000400 	add	w0, w0, #0x1
    7894:	39000040 	strb	w0, [x2]
    7898:	17ffffd9 	b	77fc <fwp_caps37+0xac>
    789c:	72003c1f 	tst	w0, #0xffff
    78a0:	54fffae1 	b.ne	77fc <fwp_caps37+0xac>  // b.any
    78a4:	17ffffce 	b	77dc <fwp_caps37+0x8c>
    78a8:	72003c1f 	tst	w0, #0xffff
    78ac:	54fffa81 	b.ne	77fc <fwp_caps37+0xac>  // b.any
    78b0:	17fffff0 	b	7870 <fwp_caps37+0x120>
    78b4:	f940ac23 	ldr	x3, [x1, #344]
    78b8:	91000463 	add	x3, x3, #0x1
    78bc:	f900ac23 	str	x3, [x1, #344]
    78c0:	17fffff2 	b	7888 <fwp_caps37+0x138>
    78c4:	f9400bf3 	ldr	x19, [sp, #16]
    78c8:	aa0203e0 	mov	x0, x2
    78cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    78d0:	17fff3cd 	b	4804 <fwp_rc_wide_dup>

00000000000078d4 <fwp_write>:
    78d4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    78d8:	910003fd 	mov	x29, sp
    78dc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    78e0:	f947f484 	ldr	x4, [x4, #4072]
    78e4:	a90153f3 	stp	x19, x20, [sp, #16]
    78e8:	d10943ff 	sub	sp, sp, #0x250
    78ec:	b9400045 	ldr	w5, [x2]
    78f0:	aa0003f4 	mov	x20, x0
    78f4:	f9400080 	ldr	x0, [x4]
    78f8:	f90127e0 	str	x0, [sp, #584]
    78fc:	d2800000 	mov	x0, #0x0                   	// #0
    7900:	710064bf 	cmp	w5, #0x19
    7904:	54000408 	b.hi	7984 <fwp_write+0xb0>  // b.pmore
    7908:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    790c:	aa0103f3 	mov	x19, x1
    7910:	91298000 	add	x0, x0, #0xa60
    7914:	f9013bf5 	str	x21, [sp, #624]
    7918:	f9013ff6 	str	x22, [sp, #632]
    791c:	f90153fb 	str	x27, [sp, #672]
    7920:	f90157fc 	str	x28, [sp, #680]
    7924:	aa0203fc 	mov	x28, x2
    7928:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    792c:	10000061 	adr	x1, 7938 <fwp_write+0x64>
    7930:	8b20a820 	add	x0, x1, w0, sxth #2
    7934:	d61f0000 	br	x0
    7938:	910123e0 	add	x0, sp, #0x48
    793c:	aa1303e5 	mov	x5, x19
    7940:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x410>
    7944:	aa0003f3 	mov	x19, x0
    7948:	9108e084 	add	x4, x4, #0x238
    794c:	d2804003 	mov	x3, #0x200                 	// #512
    7950:	aa0303e1 	mov	x1, x3
    7954:	52800042 	mov	w2, #0x2                   	// #2
    7958:	97ffebae 	bl	2810 <__snprintf_chk@plt>
    795c:	aa1303e0 	mov	x0, x19
    7960:	97ffeb74 	bl	2730 <strlen@plt>
    7964:	aa1303e1 	mov	x1, x19
    7968:	aa0003e2 	mov	x2, x0
    796c:	aa1403e0 	mov	x0, x20
    7970:	97ffef48 	bl	3690 <buf_put>
    7974:	f9413bf5 	ldr	x21, [sp, #624]
    7978:	f9413ff6 	ldr	x22, [sp, #632]
    797c:	f94153fb 	ldr	x27, [sp, #672]
    7980:	f94157fc 	ldr	x28, [sp, #680]
    7984:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7988:	f947f400 	ldr	x0, [x0, #4072]
    798c:	f94127e2 	ldr	x2, [sp, #584]
    7990:	f9400001 	ldr	x1, [x0]
    7994:	eb010042 	subs	x2, x2, x1
    7998:	d2800001 	mov	x1, #0x0                   	// #0
    799c:	540077a1 	b.ne	8890 <fwp_write+0xfbc>  // b.any
    79a0:	910943ff 	add	sp, sp, #0x250
    79a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    79a8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    79ac:	d65f03c0 	ret
    79b0:	910123e0 	add	x0, sp, #0x48
    79b4:	aa1303e5 	mov	x5, x19
    79b8:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x410>
    79bc:	aa0003f3 	mov	x19, x0
    79c0:	9108c084 	add	x4, x4, #0x230
    79c4:	d2804003 	mov	x3, #0x200                 	// #512
    79c8:	17ffffe2 	b	7950 <fwp_write+0x7c>
    79cc:	71004cbf 	cmp	w5, #0x13
    79d0:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    79d4:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    79d8:	91088000 	add	x0, x0, #0x220
    79dc:	9108a021 	add	x1, x1, #0x228
    79e0:	d2800082 	mov	x2, #0x4                   	// #4
    79e4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    79e8:	aa1403e0 	mov	x0, x20
    79ec:	f90143f7 	str	x23, [sp, #640]
    79f0:	d2800016 	mov	x22, #0x0                   	// #0
    79f4:	f90147f8 	str	x24, [sp, #648]
    79f8:	97ffef26 	bl	3690 <buf_put>
    79fc:	f9400260 	ldr	x0, [x19]
    7a00:	f0000017 	adrp	x23, a000 <_IO_stdin_used+0x410>
    7a04:	d2800015 	mov	x21, #0x0                   	// #0
    7a08:	910aa2f7 	add	x23, x23, #0x2a8
    7a0c:	b4004780 	cbz	x0, 82fc <fwp_write+0xa28>
    7a10:	b9400380 	ldr	w0, [x28]
    7a14:	52800003 	mov	w3, #0x0                   	// #0
    7a18:	f9401f82 	ldr	x2, [x28, #56]
    7a1c:	71004c1f 	cmp	w0, #0x13
    7a20:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7a24:	aa1403e0 	mov	x0, x20
    7a28:	8b010e61 	add	x1, x19, x1, lsl #3
    7a2c:	f9400421 	ldr	x1, [x1, #8]
    7a30:	97ffffa9 	bl	78d4 <fwp_write>
    7a34:	b9400380 	ldr	w0, [x28]
    7a38:	7100481f 	cmp	w0, #0x12
    7a3c:	54004b20 	b.eq	83a0 <fwp_write+0xacc>  // b.none
    7a40:	f9400260 	ldr	x0, [x19]
    7a44:	910006b5 	add	x21, x21, #0x1
    7a48:	91000ad6 	add	x22, x22, #0x2
    7a4c:	eb15001f 	cmp	x0, x21
    7a50:	54004569 	b.ls	82fc <fwp_write+0xa28>  // b.plast
    7a54:	aa1703e1 	mov	x1, x23
    7a58:	aa1403e0 	mov	x0, x20
    7a5c:	d2800042 	mov	x2, #0x2                   	// #2
    7a60:	97ffef0c 	bl	3690 <buf_put>
    7a64:	17ffffeb 	b	7a10 <fwp_write+0x13c>
    7a68:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7a6c:	91098021 	add	x1, x1, #0x260
    7a70:	d28000c2 	mov	x2, #0x6                   	// #6
    7a74:	aa1403e0 	mov	x0, x20
    7a78:	91004273 	add	x19, x19, #0x10
    7a7c:	97ffef05 	bl	3690 <buf_put>
    7a80:	aa1303e0 	mov	x0, x19
    7a84:	97ffeb2b 	bl	2730 <strlen@plt>
    7a88:	aa1303e1 	mov	x1, x19
    7a8c:	aa0003e2 	mov	x2, x0
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	97ffeeff 	bl	3690 <buf_put>
    7a98:	528007c3 	mov	w3, #0x3e                  	// #62
    7a9c:	aa1403e0 	mov	x0, x20
    7aa0:	91001fe1 	add	x1, sp, #0x7
    7aa4:	d2800022 	mov	x2, #0x1                   	// #1
    7aa8:	39001fe3 	strb	w3, [sp, #7]
    7aac:	17ffffb1 	b	7970 <fwp_write+0x9c>
    7ab0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7ab4:	f947f400 	ldr	x0, [x0, #4072]
    7ab8:	f94127e2 	ldr	x2, [sp, #584]
    7abc:	f9400001 	ldr	x1, [x0]
    7ac0:	eb010042 	subs	x2, x2, x1
    7ac4:	d2800001 	mov	x1, #0x0                   	// #0
    7ac8:	540034c1 	b.ne	8160 <fwp_write+0x88c>  // b.any
    7acc:	f9413bf5 	ldr	x21, [sp, #624]
    7ad0:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7ad4:	f9413ff6 	ldr	x22, [sp, #632]
    7ad8:	aa1403e0 	mov	x0, x20
    7adc:	91090021 	add	x1, x1, #0x240
    7ae0:	d2800142 	mov	x2, #0xa                   	// #10
    7ae4:	f94153fb 	ldr	x27, [sp, #672]
    7ae8:	f94157fc 	ldr	x28, [sp, #680]
    7aec:	910943ff 	add	sp, sp, #0x250
    7af0:	a94153f3 	ldp	x19, x20, [sp, #16]
    7af4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7af8:	17ffeee6 	b	3690 <buf_put>
    7afc:	f9400456 	ldr	x22, [x2, #8]
    7b00:	f90143f7 	str	x23, [sp, #640]
    7b04:	f90147f8 	str	x24, [sp, #648]
    7b08:	b4005af6 	cbz	x22, 8664 <fwp_write+0xd90>
    7b0c:	aa1603e0 	mov	x0, x22
    7b10:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7b14:	910b0021 	add	x1, x1, #0x2c0
    7b18:	97ffeb82 	bl	2920 <strcmp@plt>
    7b1c:	2a0003f5 	mov	w21, w0
    7b20:	34005fc0 	cbz	w0, 8718 <fwp_write+0xe44>
    7b24:	aa1603e0 	mov	x0, x22
    7b28:	97ffeb02 	bl	2730 <strlen@plt>
    7b2c:	aa1603e1 	mov	x1, x22
    7b30:	aa0003e2 	mov	x2, x0
    7b34:	aa1403e0 	mov	x0, x20
    7b38:	97ffeed6 	bl	3690 <buf_put>
    7b3c:	52800403 	mov	w3, #0x20                  	// #32
    7b40:	91001ff5 	add	x21, sp, #0x7
    7b44:	aa1503e1 	mov	x1, x21
    7b48:	aa1403e0 	mov	x0, x20
    7b4c:	d2800022 	mov	x2, #0x1                   	// #1
    7b50:	39001fe3 	strb	w3, [sp, #7]
    7b54:	97ffeecf 	bl	3690 <buf_put>
    7b58:	52800f63 	mov	w3, #0x7b                  	// #123
    7b5c:	aa1403e0 	mov	x0, x20
    7b60:	aa1503e1 	mov	x1, x21
    7b64:	d2800022 	mov	x2, #0x1                   	// #1
    7b68:	39001fe3 	strb	w3, [sp, #7]
    7b6c:	97ffeec9 	bl	3690 <buf_put>
    7b70:	b9401380 	ldr	w0, [x28, #16]
    7b74:	52800018 	mov	w24, #0x0                   	// #0
    7b78:	7100001f 	cmp	w0, #0x0
    7b7c:	54003a8d 	b.le	82cc <fwp_write+0x9f8>
    7b80:	f9014bf9 	str	x25, [sp, #656]
    7b84:	f0000019 	adrp	x25, a000 <_IO_stdin_used+0x410>
    7b88:	910ba339 	add	x25, x25, #0x2e8
    7b8c:	f9014ffa 	str	x26, [sp, #664]
    7b90:	f000001a 	adrp	x26, a000 <_IO_stdin_used+0x410>
    7b94:	910aa35a 	add	x26, x26, #0x2a8
    7b98:	91002276 	add	x22, x19, #0x8
    7b9c:	d2800013 	mov	x19, #0x0                   	// #0
    7ba0:	b5003e73 	cbnz	x19, 836c <fwp_write+0xa98>
    7ba4:	d37df277 	lsl	x23, x19, #3
    7ba8:	34003c98 	cbz	w24, 8338 <fwp_write+0xa64>
    7bac:	f9401382 	ldr	x2, [x28, #32]
    7bb0:	aa1403e0 	mov	x0, x20
    7bb4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7bb8:	52800003 	mov	w3, #0x0                   	// #0
    7bbc:	f8776842 	ldr	x2, [x2, x23]
    7bc0:	91000673 	add	x19, x19, #0x1
    7bc4:	97ffff44 	bl	78d4 <fwp_write>
    7bc8:	b9401380 	ldr	w0, [x28, #16]
    7bcc:	6b13001f 	cmp	w0, w19
    7bd0:	54fffe8c 	b.gt	7ba0 <fwp_write+0x2cc>
    7bd4:	f9414bf9 	ldr	x25, [sp, #656]
    7bd8:	f9414ffa 	ldr	x26, [sp, #664]
    7bdc:	34003798 	cbz	w24, 82cc <fwp_write+0x9f8>
    7be0:	52800523 	mov	w3, #0x29                  	// #41
    7be4:	aa1503e1 	mov	x1, x21
    7be8:	aa1403e0 	mov	x0, x20
    7bec:	d2800022 	mov	x2, #0x1                   	// #1
    7bf0:	39001fe3 	strb	w3, [sp, #7]
    7bf4:	97ffeea7 	bl	3690 <buf_put>
    7bf8:	f9413bf5 	ldr	x21, [sp, #624]
    7bfc:	f9413ff6 	ldr	x22, [sp, #632]
    7c00:	f94143f7 	ldr	x23, [sp, #640]
    7c04:	f94147f8 	ldr	x24, [sp, #648]
    7c08:	f94153fb 	ldr	x27, [sp, #672]
    7c0c:	f94157fc 	ldr	x28, [sp, #680]
    7c10:	17ffff5d 	b	7984 <fwp_write+0xb0>
    7c14:	b9404855 	ldr	w21, [x2, #72]
    7c18:	aa1403e0 	mov	x0, x20
    7c1c:	93407eb6 	sxtw	x22, w21
    7c20:	91000ac1 	add	x1, x22, #0x2
    7c24:	97ffee67 	bl	35c0 <buf_grow>
    7c28:	a9400281 	ldp	x1, x0, [x20]
    7c2c:	528e8603 	mov	w3, #0x7430                	// #29744
    7c30:	78206823 	strh	w3, [x1, x0]
    7c34:	8b000022 	add	x2, x1, x0
    7c38:	710002bf 	cmp	w21, #0x0
    7c3c:	540036ad 	b.le	8310 <fwp_write+0xa3c>
    7c40:	110006a3 	add	w3, w21, #0x1
    7c44:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7c48:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7c4c:	91000449 	add	x9, x2, #0x1
    7c50:	8b23c043 	add	x3, x2, w3, sxtw
    7c54:	f28aaac6 	movk	x6, #0x5556
    7c58:	f2955568 	movk	x8, #0xaaab
    7c5c:	1400000d 	b	7c90 <fwp_write+0x3bc>
    7c60:	d2800021 	mov	x1, #0x1                   	// #1
    7c64:	528005a5 	mov	w5, #0x2d                  	// #45
    7c68:	f100001f 	cmp	x0, #0x0
    7c6c:	9b467e60 	smulh	x0, x19, x6
    7c70:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7c74:	381ff465 	strb	w5, [x3], #-1
    7c78:	cb040000 	sub	x0, x0, x4
    7c7c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7c80:	cb020000 	sub	x0, x0, x2
    7c84:	8b010013 	add	x19, x0, x1
    7c88:	eb03013f 	cmp	x9, x3
    7c8c:	54003420 	b.eq	8310 <fwp_write+0xa3c>  // b.none
    7c90:	9b467e60 	smulh	x0, x19, x6
    7c94:	937ffe64 	asr	x4, x19, #63
    7c98:	52800605 	mov	w5, #0x30                  	// #48
    7c9c:	cb040000 	sub	x0, x0, x4
    7ca0:	8b000400 	add	x0, x0, x0, lsl #1
    7ca4:	cb000260 	sub	x0, x19, x0
    7ca8:	91000c01 	add	x1, x0, #0x3
    7cac:	9bc87c22 	umulh	x2, x1, x8
    7cb0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7cb4:	8b4204e2 	add	x2, x7, x2, lsr #1
    7cb8:	eb020021 	subs	x1, x1, x2
    7cbc:	54fffd60 	b.eq	7c68 <fwp_write+0x394>  // b.none
    7cc0:	f100043f 	cmp	x1, #0x1
    7cc4:	54fffce1 	b.ne	7c60 <fwp_write+0x38c>  // b.any
    7cc8:	d2800001 	mov	x1, #0x0                   	// #0
    7ccc:	52800565 	mov	w5, #0x2b                  	// #43
    7cd0:	17ffffe6 	b	7c68 <fwp_write+0x394>
    7cd4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7cd8:	f947f400 	ldr	x0, [x0, #4072]
    7cdc:	f94127e2 	ldr	x2, [sp, #584]
    7ce0:	f9400001 	ldr	x1, [x0]
    7ce4:	eb010042 	subs	x2, x2, x1
    7ce8:	d2800001 	mov	x1, #0x0                   	// #0
    7cec:	540023a1 	b.ne	8160 <fwp_write+0x88c>  // b.any
    7cf0:	f9413bf5 	ldr	x21, [sp, #624]
    7cf4:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7cf8:	f9413ff6 	ldr	x22, [sp, #632]
    7cfc:	aa1403e0 	mov	x0, x20
    7d00:	91094021 	add	x1, x1, #0x250
    7d04:	d2800102 	mov	x2, #0x8                   	// #8
    7d08:	17ffff77 	b	7ae4 <fwp_write+0x210>
    7d0c:	aa1403e0 	mov	x0, x20
    7d10:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7d14:	d28000c2 	mov	x2, #0x6                   	// #6
    7d18:	910ac021 	add	x1, x1, #0x2b0
    7d1c:	97ffee5d 	bl	3690 <buf_put>
    7d20:	d2800015 	mov	x21, #0x0                   	// #0
    7d24:	f9400263 	ldr	x3, [x19]
    7d28:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7d2c:	54002c40 	b.eq	82b4 <fwp_write+0x9e0>  // b.none
    7d30:	f9401f82 	ldr	x2, [x28, #56]
    7d34:	f90143f7 	str	x23, [sp, #640]
    7d38:	f90147f8 	str	x24, [sp, #648]
    7d3c:	d2800857 	mov	x23, #0x42                  	// #66
    7d40:	f9014bf9 	str	x25, [sp, #656]
    7d44:	f0000016 	adrp	x22, a000 <_IO_stdin_used+0x410>
    7d48:	f9014ffa 	str	x26, [sp, #664]
    7d4c:	910aa2d6 	add	x22, x22, #0x2a8
    7d50:	d2800038 	mov	x24, #0x1                   	// #1
    7d54:	f2a18017 	movk	x23, #0xc00, lsl #16
    7d58:	d2809099 	mov	x25, #0x484                 	// #1156
    7d5c:	b4000482 	cbz	x2, 7dec <fwp_write+0x518>
    7d60:	b9400040 	ldr	w0, [x2]
    7d64:	7100701f 	cmp	w0, #0x1c
    7d68:	540042a0 	b.eq	85bc <fwp_write+0xce8>  // b.none
    7d6c:	71006c1f 	cmp	w0, #0x1b
    7d70:	540003e8 	b.hi	7dec <fwp_write+0x518>  // b.pmore
    7d74:	9ac02301 	lsl	x1, x24, x0
    7d78:	ea17003f 	tst	x1, x23
    7d7c:	54003681 	b.ne	844c <fwp_write+0xb78>  // b.any
    7d80:	ea19003f 	tst	x1, x25
    7d84:	54003501 	b.ne	8424 <fwp_write+0xb50>  // b.any
    7d88:	d2800424 	mov	x4, #0x21                  	// #33
    7d8c:	ea04003f 	tst	x1, x4
    7d90:	540002e0 	b.eq	7dec <fwp_write+0x518>  // b.none
    7d94:	b7f849a3 	tbnz	x3, #63, 86c8 <fwp_write+0xdf4>
    7d98:	91002261 	add	x1, x19, #0x8
    7d9c:	8b150021 	add	x1, x1, x21
    7da0:	39400021 	ldrb	w1, [x1]
    7da4:	7100001f 	cmp	w0, #0x0
    7da8:	93401c23 	sxtb	x3, w1
    7dac:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7db0:	aa1403e0 	mov	x0, x20
    7db4:	52800003 	mov	w3, #0x0                   	// #0
    7db8:	97fffec7 	bl	78d4 <fwp_write>
    7dbc:	910006b5 	add	x21, x21, #0x1
    7dc0:	f9400260 	ldr	x0, [x19]
    7dc4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7dc8:	eb0002bf 	cmp	x21, x0
    7dcc:	540026c2 	b.cs	82a4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7dd0:	d2800042 	mov	x2, #0x2                   	// #2
    7dd4:	aa1603e1 	mov	x1, x22
    7dd8:	aa1403e0 	mov	x0, x20
    7ddc:	97ffee2d 	bl	3690 <buf_put>
    7de0:	f9401f82 	ldr	x2, [x28, #56]
    7de4:	f9400263 	ldr	x3, [x19]
    7de8:	b5fffbc2 	cbnz	x2, 7d60 <fwp_write+0x48c>
    7dec:	d37df2a0 	lsl	x0, x21, #3
    7df0:	b7f83f03 	tbnz	x3, #63, 85d0 <fwp_write+0xcfc>
    7df4:	91002261 	add	x1, x19, #0x8
    7df8:	8b000020 	add	x0, x1, x0
    7dfc:	f9400001 	ldr	x1, [x0]
    7e00:	17ffffec 	b	7db0 <fwp_write+0x4dc>
    7e04:	a9400e62 	ldp	x2, x3, [x19]
    7e08:	b7f83ca3 	tbnz	x3, #63, 859c <fwp_write+0xcc8>
    7e0c:	910123f5 	add	x21, sp, #0x48
    7e10:	aa1503e0 	mov	x0, x21
    7e14:	97ffec03 	bl	2e20 <fwp_fmt_u128>
    7e18:	aa1503e0 	mov	x0, x21
    7e1c:	97ffea45 	bl	2730 <strlen@plt>
    7e20:	aa1503e1 	mov	x1, x21
    7e24:	aa0003e2 	mov	x2, x0
    7e28:	17fffed1 	b	796c <fwp_write+0x98>
    7e2c:	fd015be8 	str	d8, [sp, #688]
    7e30:	1e270268 	fmov	s8, w19
    7e34:	fd015fe9 	str	d9, [sp, #696]
    7e38:	1e282100 	fcmp	s8, s8
    7e3c:	54004d26 	b.vs	87e0 <fwp_write+0xf0c>
    7e40:	1e20c101 	fabs	s1, s8
    7e44:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7e48:	1e270000 	fmov	s0, w0
    7e4c:	1e202020 	fcmp	s1, s0
    7e50:	54002c0d 	b.le	83d0 <fwp_write+0xafc>
    7e54:	1e202118 	fcmpe	s8, #0.0
    7e58:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x740>
    7e5c:	9135a042 	add	x2, x2, #0xd68
    7e60:	910123f5 	add	x21, sp, #0x48
    7e64:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7e68:	91080021 	add	x1, x1, #0x200
    7e6c:	aa1503e0 	mov	x0, x21
    7e70:	9a81c041 	csel	x1, x2, x1, gt
    7e74:	97ffeadb 	bl	29e0 <strcpy@plt>
    7e78:	aa1503e0 	mov	x0, x21
    7e7c:	97ffea2d 	bl	2730 <strlen@plt>
    7e80:	aa1503e1 	mov	x1, x21
    7e84:	aa0003e2 	mov	x2, x0
    7e88:	aa1403e0 	mov	x0, x20
    7e8c:	97ffee01 	bl	3690 <buf_put>
    7e90:	f9413bf5 	ldr	x21, [sp, #624]
    7e94:	f9413ff6 	ldr	x22, [sp, #632]
    7e98:	f94153fb 	ldr	x27, [sp, #672]
    7e9c:	f94157fc 	ldr	x28, [sp, #680]
    7ea0:	fd415be8 	ldr	d8, [sp, #688]
    7ea4:	fd415fe9 	ldr	d9, [sp, #696]
    7ea8:	17fffeb7 	b	7984 <fwp_write+0xb0>
    7eac:	f9400276 	ldr	x22, [x19]
    7eb0:	34002e03 	cbz	w3, 8470 <fwp_write+0xb9c>
    7eb4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7eb8:	f947f400 	ldr	x0, [x0, #4072]
    7ebc:	f94127e2 	ldr	x2, [sp, #584]
    7ec0:	f9400001 	ldr	x1, [x0]
    7ec4:	eb010042 	subs	x2, x2, x1
    7ec8:	d2800001 	mov	x1, #0x0                   	// #0
    7ecc:	540014a1 	b.ne	8160 <fwp_write+0x88c>  // b.any
    7ed0:	aa1603e2 	mov	x2, x22
    7ed4:	91002261 	add	x1, x19, #0x8
    7ed8:	f9413bf5 	ldr	x21, [sp, #624]
    7edc:	aa1403e0 	mov	x0, x20
    7ee0:	f9413ff6 	ldr	x22, [sp, #632]
    7ee4:	17ffff00 	b	7ae4 <fwp_write+0x210>
    7ee8:	fd015be8 	str	d8, [sp, #688]
    7eec:	9e670268 	fmov	d8, x19
    7ef0:	fd015fe9 	str	d9, [sp, #696]
    7ef4:	1e682100 	fcmp	d8, d8
    7ef8:	54004746 	b.vs	87e0 <fwp_write+0xf0c>
    7efc:	1e60c101 	fabs	d1, d8
    7f00:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7f04:	9e670000 	fmov	d0, x0
    7f08:	910123f5 	add	x21, sp, #0x48
    7f0c:	52800033 	mov	w19, #0x1                   	// #1
    7f10:	1e602020 	fcmp	d1, d0
    7f14:	540001ad 	b.le	7f48 <fwp_write+0x674>
    7f18:	1e602118 	fcmpe	d8, #0.0
    7f1c:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x740>
    7f20:	9135a042 	add	x2, x2, #0xd68
    7f24:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    7f28:	91080021 	add	x1, x1, #0x200
    7f2c:	aa1503e0 	mov	x0, x21
    7f30:	9a81c041 	csel	x1, x2, x1, gt
    7f34:	97ffeaab 	bl	29e0 <strcpy@plt>
    7f38:	17ffffd0 	b	7e78 <fwp_write+0x5a4>
    7f3c:	11000673 	add	w19, w19, #0x1
    7f40:	71004a7f 	cmp	w19, #0x12
    7f44:	54003860 	b.eq	8650 <fwp_write+0xd7c>  // b.none
    7f48:	1e604100 	fmov	d0, d8
    7f4c:	2a1303e1 	mov	w1, w19
    7f50:	aa1503e0 	mov	x0, x21
    7f54:	97ffee2b 	bl	3800 <fwp_format_g.constprop.0>
    7f58:	aa1503e0 	mov	x0, x21
    7f5c:	d2800001 	mov	x1, #0x0                   	// #0
    7f60:	97ffea08 	bl	2780 <strtod@plt>
    7f64:	1e602100 	fcmp	d8, d0
    7f68:	54fffea1 	b.ne	7f3c <fwp_write+0x668>  // b.any
    7f6c:	aa1503e0 	mov	x0, x21
    7f70:	97ffee01 	bl	3774 <fwp_finish_float>
    7f74:	17ffffc1 	b	7e78 <fwp_write+0x5a4>
    7f78:	a9400e62 	ldp	x2, x3, [x19]
    7f7c:	910123f3 	add	x19, sp, #0x48
    7f80:	aa1303e0 	mov	x0, x19
    7f84:	97ffeba7 	bl	2e20 <fwp_fmt_u128>
    7f88:	17fffe75 	b	795c <fwp_write+0x88>
    7f8c:	f90143f7 	str	x23, [sp, #640]
    7f90:	f90147f8 	str	x24, [sp, #648]
    7f94:	2a1303f8 	mov	w24, w19
    7f98:	f9014bf9 	str	x25, [sp, #656]
    7f9c:	f9014ffa 	str	x26, [sp, #664]
    7fa0:	f13ffe7f 	cmp	x19, #0xfff
    7fa4:	54000049 	b.ls	7fac <fwp_write+0x6d8>  // b.plast
    7fa8:	b9400278 	ldr	w24, [x19]
    7fac:	f9400f80 	ldr	x0, [x28, #24]
    7fb0:	2a1803f5 	mov	w21, w24
    7fb4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7fb8:	d37ef6b9 	lsl	x25, x21, #2
    7fbc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7fc0:	aa1603e0 	mov	x0, x22
    7fc4:	97ffe9db 	bl	2730 <strlen@plt>
    7fc8:	aa1603e1 	mov	x1, x22
    7fcc:	aa0003e2 	mov	x2, x0
    7fd0:	aa1403e0 	mov	x0, x20
    7fd4:	97ffedaf 	bl	3690 <buf_put>
    7fd8:	f9401780 	ldr	x0, [x28, #40]
    7fdc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7fe0:	7100001f 	cmp	w0, #0x0
    7fe4:	5400068d 	b.le	80b4 <fwp_write+0x7e0>
    7fe8:	91002276 	add	x22, x19, #0x8
    7fec:	91001ff5 	add	x21, sp, #0x7
    7ff0:	d280001b 	mov	x27, #0x0                   	// #0
    7ff4:	5280041a 	mov	w26, #0x20                  	// #32
    7ff8:	f9401b80 	ldr	x0, [x28, #48]
    7ffc:	aa1503e1 	mov	x1, x21
    8000:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8004:	d2800022 	mov	x2, #0x1                   	// #1
    8008:	f8786803 	ldr	x3, [x0, x24]
    800c:	aa1403e0 	mov	x0, x20
    8010:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8014:	39001ffa 	strb	w26, [sp, #7]
    8018:	97ffed9e 	bl	3690 <buf_put>
    801c:	f13ffeff 	cmp	x23, #0xfff
    8020:	b9400261 	ldr	w1, [x19]
    8024:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8028:	7100383f 	cmp	w1, #0xe
    802c:	54000160 	b.eq	8058 <fwp_write+0x784>  // b.none
    8030:	7100403f 	cmp	w1, #0x10
    8034:	54001a60 	b.eq	8380 <fwp_write+0xaac>  // b.none
    8038:	7100283f 	cmp	w1, #0xa
    803c:	54002aa0 	b.eq	8590 <fwp_write+0xcbc>  // b.none
    8040:	540014ac 	b.gt	82d4 <fwp_write+0xa00>
    8044:	71000c3f 	cmp	w1, #0x3
    8048:	540029ac 	b.gt	857c <fwp_write+0xca8>
    804c:	d37ffee0 	lsr	x0, x23, #63
    8050:	37f814a1 	tbnz	w1, #31, 82e4 <fwp_write+0xa10>
    8054:	d503201f 	nop
    8058:	34001460 	cbz	w0, 82e4 <fwp_write+0xa10>
    805c:	52800503 	mov	w3, #0x28                  	// #40
    8060:	aa1503e1 	mov	x1, x21
    8064:	aa1403e0 	mov	x0, x20
    8068:	d2800022 	mov	x2, #0x1                   	// #1
    806c:	39001fe3 	strb	w3, [sp, #7]
    8070:	97ffed88 	bl	3690 <buf_put>
    8074:	aa1303e2 	mov	x2, x19
    8078:	aa1703e1 	mov	x1, x23
    807c:	aa1403e0 	mov	x0, x20
    8080:	52800003 	mov	w3, #0x0                   	// #0
    8084:	97fffe14 	bl	78d4 <fwp_write>
    8088:	52800523 	mov	w3, #0x29                  	// #41
    808c:	aa1503e1 	mov	x1, x21
    8090:	aa1403e0 	mov	x0, x20
    8094:	d2800022 	mov	x2, #0x1                   	// #1
    8098:	39001fe3 	strb	w3, [sp, #7]
    809c:	97ffed7d 	bl	3690 <buf_put>
    80a0:	f9401780 	ldr	x0, [x28, #40]
    80a4:	9100077b 	add	x27, x27, #0x1
    80a8:	b8796800 	ldr	w0, [x0, x25]
    80ac:	6b1b001f 	cmp	w0, w27
    80b0:	54fffa4c 	b.gt	7ff8 <fwp_write+0x724>
    80b4:	f9413bf5 	ldr	x21, [sp, #624]
    80b8:	f9413ff6 	ldr	x22, [sp, #632]
    80bc:	f94143f7 	ldr	x23, [sp, #640]
    80c0:	f94147f8 	ldr	x24, [sp, #648]
    80c4:	f9414bf9 	ldr	x25, [sp, #656]
    80c8:	f9414ffa 	ldr	x26, [sp, #664]
    80cc:	f94153fb 	ldr	x27, [sp, #672]
    80d0:	f94157fc 	ldr	x28, [sp, #680]
    80d4:	17fffe2c 	b	7984 <fwp_write+0xb0>
    80d8:	52800783 	mov	w3, #0x3c                  	// #60
    80dc:	91001ff3 	add	x19, sp, #0x7
    80e0:	aa1303e1 	mov	x1, x19
    80e4:	d2800022 	mov	x2, #0x1                   	// #1
    80e8:	aa1403e0 	mov	x0, x20
    80ec:	39001fe3 	strb	w3, [sp, #7]
    80f0:	97ffed68 	bl	3690 <buf_put>
    80f4:	f9400795 	ldr	x21, [x28, #8]
    80f8:	aa1503e0 	mov	x0, x21
    80fc:	97ffe98d 	bl	2730 <strlen@plt>
    8100:	aa1503e1 	mov	x1, x21
    8104:	aa0003e2 	mov	x2, x0
    8108:	aa1403e0 	mov	x0, x20
    810c:	97ffed61 	bl	3690 <buf_put>
    8110:	528007c3 	mov	w3, #0x3e                  	// #62
    8114:	aa1303e1 	mov	x1, x19
    8118:	aa1403e0 	mov	x0, x20
    811c:	d2800022 	mov	x2, #0x1                   	// #1
    8120:	39001fe3 	strb	w3, [sp, #7]
    8124:	17fffe13 	b	7970 <fwp_write+0x9c>
    8128:	f100067f 	cmp	x19, #0x1
    812c:	540025a0 	b.eq	85e0 <fwp_write+0xd0c>  // b.none
    8130:	b100067f 	cmn	x19, #0x1
    8134:	54002bc0 	b.eq	86ac <fwp_write+0xdd8>  // b.none
    8138:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    813c:	91082021 	add	x1, x1, #0x208
    8140:	d2800022 	mov	x2, #0x1                   	// #1
    8144:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8148:	f947f400 	ldr	x0, [x0, #4072]
    814c:	f94127e4 	ldr	x4, [sp, #584]
    8150:	f9400003 	ldr	x3, [x0]
    8154:	eb030084 	subs	x4, x4, x3
    8158:	d2800003 	mov	x3, #0x0                   	// #0
    815c:	54ffebe0 	b.eq	7ed8 <fwp_write+0x604>  // b.none
    8160:	f90143f7 	str	x23, [sp, #640]
    8164:	f90147f8 	str	x24, [sp, #648]
    8168:	f9014bf9 	str	x25, [sp, #656]
    816c:	f9014ffa 	str	x26, [sp, #664]
    8170:	fd015be8 	str	d8, [sp, #688]
    8174:	fd015fe9 	str	d9, [sp, #696]
    8178:	97ffe9ca 	bl	28a0 <__stack_chk_fail@plt>
    817c:	52800b63 	mov	w3, #0x5b                  	// #91
    8180:	91001ff5 	add	x21, sp, #0x7
    8184:	aa1503e1 	mov	x1, x21
    8188:	aa1403e0 	mov	x0, x20
    818c:	d2800022 	mov	x2, #0x1                   	// #1
    8190:	d0000016 	adrp	x22, a000 <_IO_stdin_used+0x410>
    8194:	910aa2d6 	add	x22, x22, #0x2a8
    8198:	39001fe3 	strb	w3, [sp, #7]
    819c:	97ffed3d 	bl	3690 <buf_put>
    81a0:	b4000273 	cbz	x19, 81ec <fwp_write+0x918>
    81a4:	f9400661 	ldr	x1, [x19, #8]
    81a8:	aa1403e0 	mov	x0, x20
    81ac:	f9401f82 	ldr	x2, [x28, #56]
    81b0:	52800003 	mov	w3, #0x0                   	// #0
    81b4:	97fffdc8 	bl	78d4 <fwp_write>
    81b8:	f9400a73 	ldr	x19, [x19, #16]
    81bc:	b4000193 	cbz	x19, 81ec <fwp_write+0x918>
    81c0:	aa1603e1 	mov	x1, x22
    81c4:	aa1403e0 	mov	x0, x20
    81c8:	d2800042 	mov	x2, #0x2                   	// #2
    81cc:	97ffed31 	bl	3690 <buf_put>
    81d0:	f9400661 	ldr	x1, [x19, #8]
    81d4:	aa1403e0 	mov	x0, x20
    81d8:	f9401f82 	ldr	x2, [x28, #56]
    81dc:	52800003 	mov	w3, #0x0                   	// #0
    81e0:	97fffdbd 	bl	78d4 <fwp_write>
    81e4:	f9400a73 	ldr	x19, [x19, #16]
    81e8:	b5fffed3 	cbnz	x19, 81c0 <fwp_write+0x8ec>
    81ec:	52800ba3 	mov	w3, #0x5d                  	// #93
    81f0:	aa1503e1 	mov	x1, x21
    81f4:	aa1403e0 	mov	x0, x20
    81f8:	d2800022 	mov	x2, #0x1                   	// #1
    81fc:	39001fe3 	strb	w3, [sp, #7]
    8200:	17fffddc 	b	7970 <fwp_write+0x9c>
    8204:	aa1403e0 	mov	x0, x20
    8208:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    820c:	d28000c2 	mov	x2, #0x6                   	// #6
    8210:	910a6021 	add	x1, x1, #0x298
    8214:	97ffed1f 	bl	3690 <buf_put>
    8218:	f9400260 	ldr	x0, [x19]
    821c:	b40004c0 	cbz	x0, 82b4 <fwp_write+0x9e0>
    8220:	910123f5 	add	x21, sp, #0x48
    8224:	91002276 	add	x22, x19, #0x8
    8228:	f90143f7 	str	x23, [sp, #640]
    822c:	d2800017 	mov	x23, #0x0                   	// #0
    8230:	f90147f8 	str	x24, [sp, #648]
    8234:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x410>
    8238:	910a8318 	add	x24, x24, #0x2a0
    823c:	f9014bf9 	str	x25, [sp, #656]
    8240:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x410>
    8244:	910aa339 	add	x25, x25, #0x2a8
    8248:	f9014ffa 	str	x26, [sp, #664]
    824c:	14000005 	b	8260 <fwp_write+0x98c>
    8250:	aa1903e1 	mov	x1, x25
    8254:	aa1403e0 	mov	x0, x20
    8258:	d2800042 	mov	x2, #0x2                   	// #2
    825c:	97ffed0d 	bl	3690 <buf_put>
    8260:	38776ac5 	ldrb	w5, [x22, x23]
    8264:	d2804003 	mov	x3, #0x200                 	// #512
    8268:	aa1803e4 	mov	x4, x24
    826c:	aa0303e1 	mov	x1, x3
    8270:	52800042 	mov	w2, #0x2                   	// #2
    8274:	aa1503e0 	mov	x0, x21
    8278:	910006f7 	add	x23, x23, #0x1
    827c:	97ffe965 	bl	2810 <__snprintf_chk@plt>
    8280:	aa1503e0 	mov	x0, x21
    8284:	97ffe92b 	bl	2730 <strlen@plt>
    8288:	aa1503e1 	mov	x1, x21
    828c:	aa0003e2 	mov	x2, x0
    8290:	aa1403e0 	mov	x0, x20
    8294:	97ffecff 	bl	3690 <buf_put>
    8298:	f9400260 	ldr	x0, [x19]
    829c:	eb17001f 	cmp	x0, x23
    82a0:	54fffd88 	b.hi	8250 <fwp_write+0x97c>  // b.pmore
    82a4:	f94143f7 	ldr	x23, [sp, #640]
    82a8:	f94147f8 	ldr	x24, [sp, #648]
    82ac:	f9414bf9 	ldr	x25, [sp, #656]
    82b0:	f9414ffa 	ldr	x26, [sp, #664]
    82b4:	52800ba3 	mov	w3, #0x5d                  	// #93
    82b8:	aa1403e0 	mov	x0, x20
    82bc:	91001fe1 	add	x1, sp, #0x7
    82c0:	d2800022 	mov	x2, #0x1                   	// #1
    82c4:	39001fe3 	strb	w3, [sp, #7]
    82c8:	17fffdaa 	b	7970 <fwp_write+0x9c>
    82cc:	52800fa3 	mov	w3, #0x7d                  	// #125
    82d0:	17fffe45 	b	7be4 <fwp_write+0x310>
    82d4:	f10002ff 	cmp	x23, #0x0
    82d8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    82dc:	71002c3f 	cmp	w1, #0xb
    82e0:	54ffebc0 	b.eq	8058 <fwp_write+0x784>  // b.none
    82e4:	aa1303e2 	mov	x2, x19
    82e8:	aa1703e1 	mov	x1, x23
    82ec:	aa1403e0 	mov	x0, x20
    82f0:	52800003 	mov	w3, #0x0                   	// #0
    82f4:	97fffd78 	bl	78d4 <fwp_write>
    82f8:	17ffff6a 	b	80a0 <fwp_write+0x7cc>
    82fc:	aa1403e0 	mov	x0, x20
    8300:	91001fe1 	add	x1, sp, #0x7
    8304:	52800fa3 	mov	w3, #0x7d                  	// #125
    8308:	d2800022 	mov	x2, #0x1                   	// #1
    830c:	17fffe39 	b	7bf0 <fwp_write+0x31c>
    8310:	a9400281 	ldp	x1, x0, [x20]
    8314:	91000800 	add	x0, x0, #0x2
    8318:	8b160000 	add	x0, x0, x22
    831c:	f9000680 	str	x0, [x20, #8]
    8320:	3820683f 	strb	wzr, [x1, x0]
    8324:	f9413bf5 	ldr	x21, [sp, #624]
    8328:	f9413ff6 	ldr	x22, [sp, #632]
    832c:	f94153fb 	ldr	x27, [sp, #672]
    8330:	f94157fc 	ldr	x28, [sp, #680]
    8334:	17fffd94 	b	7984 <fwp_write+0xb0>
    8338:	f9400f80 	ldr	x0, [x28, #24]
    833c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8340:	aa1b03e0 	mov	x0, x27
    8344:	97ffe8fb 	bl	2730 <strlen@plt>
    8348:	aa1b03e1 	mov	x1, x27
    834c:	aa0003e2 	mov	x2, x0
    8350:	aa1403e0 	mov	x0, x20
    8354:	97ffeccf 	bl	3690 <buf_put>
    8358:	aa1903e1 	mov	x1, x25
    835c:	aa1403e0 	mov	x0, x20
    8360:	d2800062 	mov	x2, #0x3                   	// #3
    8364:	97ffeccb 	bl	3690 <buf_put>
    8368:	17fffe11 	b	7bac <fwp_write+0x2d8>
    836c:	aa1a03e1 	mov	x1, x26
    8370:	aa1403e0 	mov	x0, x20
    8374:	d2800042 	mov	x2, #0x2                   	// #2
    8378:	97ffecc6 	bl	3690 <buf_put>
    837c:	17fffe0a 	b	7ba4 <fwp_write+0x2d0>
    8380:	f9400660 	ldr	x0, [x19, #8]
    8384:	b4fffb00 	cbz	x0, 82e4 <fwp_write+0xa10>
    8388:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    838c:	910b0021 	add	x1, x1, #0x2c0
    8390:	97ffe964 	bl	2920 <strcmp@plt>
    8394:	7100001f 	cmp	w0, #0x0
    8398:	1a9f07e0 	cset	w0, ne	// ne = any
    839c:	17ffff2f 	b	8058 <fwp_write+0x784>
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	d2800042 	mov	x2, #0x2                   	// #2
    83a8:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    83ac:	910ae021 	add	x1, x1, #0x2b8
    83b0:	97ffecb8 	bl	3690 <buf_put>
    83b4:	91004261 	add	x1, x19, #0x10
    83b8:	aa1403e0 	mov	x0, x20
    83bc:	f9402382 	ldr	x2, [x28, #64]
    83c0:	52800003 	mov	w3, #0x0                   	// #0
    83c4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    83c8:	97fffd43 	bl	78d4 <fwp_write>
    83cc:	17fffd9d 	b	7a40 <fwp_write+0x16c>
    83d0:	1e22c109 	fcvt	d9, s8
    83d4:	910123f5 	add	x21, sp, #0x48
    83d8:	52800033 	mov	w19, #0x1                   	// #1
    83dc:	d503201f 	nop
    83e0:	1e604120 	fmov	d0, d9
    83e4:	2a1303e1 	mov	w1, w19
    83e8:	aa1503e0 	mov	x0, x21
    83ec:	97ffed05 	bl	3800 <fwp_format_g.constprop.0>
    83f0:	aa1503e0 	mov	x0, x21
    83f4:	d2800001 	mov	x1, #0x0                   	// #0
    83f8:	97ffe956 	bl	2950 <strtof@plt>
    83fc:	1e202100 	fcmp	s8, s0
    8400:	54ffdb60 	b.eq	7f6c <fwp_write+0x698>  // b.none
    8404:	11000673 	add	w19, w19, #0x1
    8408:	71002a7f 	cmp	w19, #0xa
    840c:	54fffea1 	b.ne	83e0 <fwp_write+0xb0c>  // b.any
    8410:	1e604120 	fmov	d0, d9
    8414:	aa1503e0 	mov	x0, x21
    8418:	52800121 	mov	w1, #0x9                   	// #9
    841c:	97ffecf9 	bl	3800 <fwp_format_g.constprop.0>
    8420:	17fffed3 	b	7f6c <fwp_write+0x698>
    8424:	d37ef6a1 	lsl	x1, x21, #2
    8428:	b7f81563 	tbnz	x3, #63, 86d4 <fwp_write+0xe00>
    842c:	91002263 	add	x3, x19, #0x8
    8430:	8b010061 	add	x1, x3, x1
    8434:	b9400023 	ldr	w3, [x1]
    8438:	7100081f 	cmp	w0, #0x2
    843c:	2a0303e1 	mov	w1, w3
    8440:	93407c63 	sxtw	x3, w3
    8444:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8448:	17fffe5a 	b	7db0 <fwp_write+0x4dc>
    844c:	d37ffaa1 	lsl	x1, x21, #1
    8450:	b7f81363 	tbnz	x3, #63, 86bc <fwp_write+0xde8>
    8454:	91002263 	add	x3, x19, #0x8
    8458:	8b010061 	add	x1, x3, x1
    845c:	79400021 	ldrh	w1, [x1]
    8460:	7100041f 	cmp	w0, #0x1
    8464:	93403c23 	sxth	x3, w1
    8468:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    846c:	17fffe51 	b	7db0 <fwp_write+0x4dc>
    8470:	52800443 	mov	w3, #0x22                  	// #34
    8474:	91001ff5 	add	x21, sp, #0x7
    8478:	91002273 	add	x19, x19, #0x8
    847c:	aa1503e1 	mov	x1, x21
    8480:	aa1403e0 	mov	x0, x20
    8484:	d2800022 	mov	x2, #0x1                   	// #1
    8488:	39001fe3 	strb	w3, [sp, #7]
    848c:	f90143f7 	str	x23, [sp, #640]
    8490:	8b160277 	add	x23, x19, x22
    8494:	f90147f8 	str	x24, [sp, #648]
    8498:	97ffec7e 	bl	3690 <buf_put>
    849c:	b4000696 	cbz	x22, 856c <fwp_write+0xc98>
    84a0:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x410>
    84a4:	9109a318 	add	x24, x24, #0x268
    84a8:	f9014bf9 	str	x25, [sp, #656]
    84ac:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x410>
    84b0:	910a2339 	add	x25, x25, #0x288
    84b4:	f9014ffa 	str	x26, [sp, #664]
    84b8:	1400000d 	b	84ec <fwp_write+0xc18>
    84bc:	710024bf 	cmp	w5, #0x9
    84c0:	54000460 	b.eq	854c <fwp_write+0xc78>  // b.none
    84c4:	710028bf 	cmp	w5, #0xa
    84c8:	54000a61 	b.ne	8614 <fwp_write+0xd40>  // b.any
    84cc:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    84d0:	aa1403e0 	mov	x0, x20
    84d4:	9109e021 	add	x1, x1, #0x278
    84d8:	d2800042 	mov	x2, #0x2                   	// #2
    84dc:	97ffec6d 	bl	3690 <buf_put>
    84e0:	91000673 	add	x19, x19, #0x1
    84e4:	eb17027f 	cmp	x19, x23
    84e8:	540003e0 	b.eq	8564 <fwp_write+0xc90>  // b.none
    84ec:	39400265 	ldrb	w5, [x19]
    84f0:	710034bf 	cmp	w5, #0xd
    84f4:	54000180 	b.eq	8524 <fwp_write+0xc50>  // b.none
    84f8:	54fffe29 	b.ls	84bc <fwp_write+0xbe8>  // b.plast
    84fc:	710088bf 	cmp	w5, #0x22
    8500:	540001c0 	b.eq	8538 <fwp_write+0xc64>  // b.none
    8504:	710170bf 	cmp	w5, #0x5c
    8508:	54000741 	b.ne	85f0 <fwp_write+0xd1c>  // b.any
    850c:	aa1403e0 	mov	x0, x20
    8510:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    8514:	d2800042 	mov	x2, #0x2                   	// #2
    8518:	9109c021 	add	x1, x1, #0x270
    851c:	97ffec5d 	bl	3690 <buf_put>
    8520:	17fffff0 	b	84e0 <fwp_write+0xc0c>
    8524:	aa1903e1 	mov	x1, x25
    8528:	aa1403e0 	mov	x0, x20
    852c:	d2800042 	mov	x2, #0x2                   	// #2
    8530:	97ffec58 	bl	3690 <buf_put>
    8534:	17ffffeb 	b	84e0 <fwp_write+0xc0c>
    8538:	aa1803e1 	mov	x1, x24
    853c:	aa1403e0 	mov	x0, x20
    8540:	d2800042 	mov	x2, #0x2                   	// #2
    8544:	97ffec53 	bl	3690 <buf_put>
    8548:	17ffffe6 	b	84e0 <fwp_write+0xc0c>
    854c:	aa1403e0 	mov	x0, x20
    8550:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    8554:	d2800042 	mov	x2, #0x2                   	// #2
    8558:	910a0021 	add	x1, x1, #0x280
    855c:	97ffec4d 	bl	3690 <buf_put>
    8560:	17ffffe0 	b	84e0 <fwp_write+0xc0c>
    8564:	f9414bf9 	ldr	x25, [sp, #656]
    8568:	f9414ffa 	ldr	x26, [sp, #664]
    856c:	aa1503e1 	mov	x1, x21
    8570:	aa1403e0 	mov	x0, x20
    8574:	52800443 	mov	w3, #0x22                  	// #34
    8578:	17fffd9d 	b	7bec <fwp_write+0x318>
    857c:	7100103f 	cmp	w1, #0x4
    8580:	54ffeb21 	b.ne	82e4 <fwp_write+0xa10>  // b.any
    8584:	f94006e0 	ldr	x0, [x23, #8]
    8588:	d37ffc00 	lsr	x0, x0, #63
    858c:	17fffeb3 	b	8058 <fwp_write+0x784>
    8590:	710002ff 	cmp	w23, #0x0
    8594:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8598:	17fffeb0 	b	8058 <fwp_write+0x784>
    859c:	528005a1 	mov	w1, #0x2d                  	// #45
    85a0:	eb0203e2 	negs	x2, x2
    85a4:	da0303e3 	ngc	x3, x3
    85a8:	910127e0 	add	x0, sp, #0x49
    85ac:	910123f5 	add	x21, sp, #0x48
    85b0:	390123e1 	strb	w1, [sp, #72]
    85b4:	97ffea1b 	bl	2e20 <fwp_fmt_u128>
    85b8:	17fffe18 	b	7e18 <fwp_write+0x544>
    85bc:	d37ceea1 	lsl	x1, x21, #4
    85c0:	b7f810a3 	tbnz	x3, #63, 87d4 <fwp_write+0xf00>
    85c4:	91002260 	add	x0, x19, #0x8
    85c8:	8b010001 	add	x1, x0, x1
    85cc:	17fffdf9 	b	7db0 <fwp_write+0x4dc>
    85d0:	f9400a61 	ldr	x1, [x19, #16]
    85d4:	8b010000 	add	x0, x0, x1
    85d8:	f9400001 	ldr	x1, [x0]
    85dc:	17fffdf5 	b	7db0 <fwp_write+0x4dc>
    85e0:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    85e4:	d2800042 	mov	x2, #0x2                   	// #2
    85e8:	91084021 	add	x1, x1, #0x210
    85ec:	17fffed6 	b	8144 <fwp_write+0x870>
    85f0:	7101fcbf 	cmp	w5, #0x7f
    85f4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    85f8:	540000e9 	b.ls	8614 <fwp_write+0xd40>  // b.plast
    85fc:	aa1503e1 	mov	x1, x21
    8600:	aa1403e0 	mov	x0, x20
    8604:	d2800022 	mov	x2, #0x1                   	// #1
    8608:	39001fe5 	strb	w5, [sp, #7]
    860c:	97ffec21 	bl	3690 <buf_put>
    8610:	17ffffb4 	b	84e0 <fwp_write+0xc0c>
    8614:	d2800203 	mov	x3, #0x10                  	// #16
    8618:	d0000004 	adrp	x4, a000 <_IO_stdin_used+0x410>
    861c:	aa0303e1 	mov	x1, x3
    8620:	910a4084 	add	x4, x4, #0x290
    8624:	910123f6 	add	x22, sp, #0x48
    8628:	52800042 	mov	w2, #0x2                   	// #2
    862c:	aa1603e0 	mov	x0, x22
    8630:	97ffe878 	bl	2810 <__snprintf_chk@plt>
    8634:	aa1603e0 	mov	x0, x22
    8638:	97ffe83e 	bl	2730 <strlen@plt>
    863c:	aa1603e1 	mov	x1, x22
    8640:	aa0003e2 	mov	x2, x0
    8644:	aa1403e0 	mov	x0, x20
    8648:	97ffec12 	bl	3690 <buf_put>
    864c:	17ffffa5 	b	84e0 <fwp_write+0xc0c>
    8650:	1e604100 	fmov	d0, d8
    8654:	aa1503e0 	mov	x0, x21
    8658:	52800221 	mov	w1, #0x11                  	// #17
    865c:	97ffec69 	bl	3800 <fwp_format_g.constprop.0>
    8660:	17fffe43 	b	7f6c <fwp_write+0x698>
    8664:	b9401040 	ldr	w0, [x2, #16]
    8668:	350003c0 	cbnz	w0, 86e0 <fwp_write+0xe0c>
    866c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8670:	f947f400 	ldr	x0, [x0, #4072]
    8674:	f94127e2 	ldr	x2, [sp, #584]
    8678:	f9400001 	ldr	x1, [x0]
    867c:	eb010042 	subs	x2, x2, x1
    8680:	d2800001 	mov	x1, #0x0                   	// #0
    8684:	54ffd721 	b.ne	8168 <fwp_write+0x894>  // b.any
    8688:	f9413bf5 	ldr	x21, [sp, #624]
    868c:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    8690:	f9413ff6 	ldr	x22, [sp, #632]
    8694:	aa1403e0 	mov	x0, x20
    8698:	f94143f7 	ldr	x23, [sp, #640]
    869c:	910b8021 	add	x1, x1, #0x2e0
    86a0:	f94147f8 	ldr	x24, [sp, #648]
    86a4:	d2800042 	mov	x2, #0x2                   	// #2
    86a8:	17fffd0f 	b	7ae4 <fwp_write+0x210>
    86ac:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x410>
    86b0:	d2800042 	mov	x2, #0x2                   	// #2
    86b4:	91086021 	add	x1, x1, #0x218
    86b8:	17fffea3 	b	8144 <fwp_write+0x870>
    86bc:	f9400a63 	ldr	x3, [x19, #16]
    86c0:	8b030021 	add	x1, x1, x3
    86c4:	17ffff66 	b	845c <fwp_write+0xb88>
    86c8:	f9400a61 	ldr	x1, [x19, #16]
    86cc:	8b0102a1 	add	x1, x21, x1
    86d0:	17fffdb4 	b	7da0 <fwp_write+0x4cc>
    86d4:	f9400a63 	ldr	x3, [x19, #16]
    86d8:	8b030021 	add	x1, x1, x3
    86dc:	17ffff56 	b	8434 <fwp_write+0xb60>
    86e0:	b9404840 	ldr	w0, [x2, #72]
    86e4:	91001ff5 	add	x21, sp, #0x7
    86e8:	34ffa380 	cbz	w0, 7b58 <fwp_write+0x284>
    86ec:	52800503 	mov	w3, #0x28                  	// #40
    86f0:	aa1403e0 	mov	x0, x20
    86f4:	aa1503e1 	mov	x1, x21
    86f8:	d2800022 	mov	x2, #0x1                   	// #1
    86fc:	39001fe3 	strb	w3, [sp, #7]
    8700:	97ffebe4 	bl	3690 <buf_put>
    8704:	b9401380 	ldr	w0, [x28, #16]
    8708:	52800038 	mov	w24, #0x1                   	// #1
    870c:	7100001f 	cmp	w0, #0x0
    8710:	54ffa38c 	b.gt	7b80 <fwp_write+0x2ac>
    8714:	17fffd33 	b	7be0 <fwp_write+0x30c>
    8718:	f9014bf9 	str	x25, [sp, #656]
    871c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x121e8>
    8720:	f9014ffa 	str	x26, [sp, #664]
    8724:	f9400676 	ldr	x22, [x19, #8]
    8728:	910ac333 	add	x19, x25, #0x2b0
    872c:	91002273 	add	x19, x19, #0x8
    8730:	937ffed8 	asr	x24, x22, #63
    8734:	aa1802c0 	orr	x0, x22, x24
    8738:	b5000320 	cbnz	x0, 879c <fwp_write+0xec8>
    873c:	110006b5 	add	w21, w21, #0x1
    8740:	710016bf 	cmp	w21, #0x5
    8744:	54ffffc1 	b.ne	873c <fwp_write+0xe68>  // b.any
    8748:	b7f80578 	tbnz	x24, #63, 87f4 <fwp_write+0xf20>
    874c:	910023f3 	add	x19, sp, #0x8
    8750:	aa1603e2 	mov	x2, x22
    8754:	aa1303e0 	mov	x0, x19
    8758:	d2800003 	mov	x3, #0x0                   	// #0
    875c:	97ffe9b1 	bl	2e20 <fwp_fmt_u128>
    8760:	910123f5 	add	x21, sp, #0x48
    8764:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x410>
    8768:	aa1303e4 	mov	x4, x19
    876c:	aa1503e0 	mov	x0, x21
    8770:	910b6063 	add	x3, x3, #0x2d8
    8774:	d2804002 	mov	x2, #0x200                 	// #512
    8778:	52800041 	mov	w1, #0x2                   	// #2
    877c:	97ffe7f1 	bl	2740 <__sprintf_chk@plt>
    8780:	aa1503e0 	mov	x0, x21
    8784:	97ffe7eb 	bl	2730 <strlen@plt>
    8788:	aa1503e1 	mov	x1, x21
    878c:	aa0003e2 	mov	x2, x0
    8790:	aa1403e0 	mov	x0, x20
    8794:	97ffebbf 	bl	3690 <buf_put>
    8798:	17fffe47 	b	80b4 <fwp_write+0x7e0>
    879c:	f9400277 	ldr	x23, [x19]
    87a0:	aa1603e0 	mov	x0, x22
    87a4:	aa1803e1 	mov	x1, x24
    87a8:	aa1703e2 	mov	x2, x23
    87ac:	937ffefa 	asr	x26, x23, #63
    87b0:	aa1a03e3 	mov	x3, x26
    87b4:	94000427 	bl	9850 <__modti3>
    87b8:	aa010000 	orr	x0, x0, x1
    87bc:	b40002c0 	cbz	x0, 8814 <fwp_write+0xf40>
    87c0:	110006b5 	add	w21, w21, #0x1
    87c4:	91004273 	add	x19, x19, #0x10
    87c8:	710016bf 	cmp	w21, #0x5
    87cc:	54fffe81 	b.ne	879c <fwp_write+0xec8>  // b.any
    87d0:	17ffffde 	b	8748 <fwp_write+0xe74>
    87d4:	f9400a60 	ldr	x0, [x19, #16]
    87d8:	8b000021 	add	x1, x1, x0
    87dc:	17fffd75 	b	7db0 <fwp_write+0x4dc>
    87e0:	528c29c0 	mov	w0, #0x614e                	// #24910
    87e4:	910123f5 	add	x21, sp, #0x48
    87e8:	72a009c0 	movk	w0, #0x4e, lsl #16
    87ec:	b9004be0 	str	w0, [sp, #72]
    87f0:	17fffda2 	b	7e78 <fwp_write+0x5a4>
    87f4:	528005a1 	mov	w1, #0x2d                  	// #45
    87f8:	eb1603e2 	negs	x2, x22
    87fc:	da1803e3 	ngc	x3, x24
    8800:	910027e0 	add	x0, sp, #0x9
    8804:	910023f3 	add	x19, sp, #0x8
    8808:	390023e1 	strb	w1, [sp, #8]
    880c:	97ffe985 	bl	2e20 <fwp_fmt_u128>
    8810:	17ffffd4 	b	8760 <fwp_write+0xe8c>
    8814:	aa1703e2 	mov	x2, x23
    8818:	aa1a03e3 	mov	x3, x26
    881c:	aa1603e0 	mov	x0, x22
    8820:	aa1803e1 	mov	x1, x24
    8824:	9400032b 	bl	94d0 <__divti3>
    8828:	aa0003e2 	mov	x2, x0
    882c:	aa0103e3 	mov	x3, x1
    8830:	b7f80201 	tbnz	x1, #63, 8870 <fwp_write+0xf9c>
    8834:	910023f3 	add	x19, sp, #0x8
    8838:	aa1303e0 	mov	x0, x19
    883c:	97ffe979 	bl	2e20 <fwp_fmt_u128>
    8840:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8844:	910ac339 	add	x25, x25, #0x2b0
    8848:	910123f5 	add	x21, sp, #0x48
    884c:	aa1303e4 	mov	x4, x19
    8850:	aa1503e0 	mov	x0, x21
    8854:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x410>
    8858:	f8616b25 	ldr	x5, [x25, x1]
    885c:	910b4063 	add	x3, x3, #0x2d0
    8860:	d2804002 	mov	x2, #0x200                 	// #512
    8864:	52800041 	mov	w1, #0x2                   	// #2
    8868:	97ffe7b6 	bl	2740 <__sprintf_chk@plt>
    886c:	17ffffc5 	b	8780 <fwp_write+0xeac>
    8870:	528005a4 	mov	w4, #0x2d                  	// #45
    8874:	eb0003e2 	negs	x2, x0
    8878:	da0103e3 	ngc	x3, x1
    887c:	910027e0 	add	x0, sp, #0x9
    8880:	910023f3 	add	x19, sp, #0x8
    8884:	390023e4 	strb	w4, [sp, #8]
    8888:	97ffe966 	bl	2e20 <fwp_fmt_u128>
    888c:	17ffffed 	b	8840 <fwp_write+0xf6c>
    8890:	f9013bf5 	str	x21, [sp, #624]
    8894:	f9013ff6 	str	x22, [sp, #632]
    8898:	f90143f7 	str	x23, [sp, #640]
    889c:	f90147f8 	str	x24, [sp, #648]
    88a0:	f9014bf9 	str	x25, [sp, #656]
    88a4:	f9014ffa 	str	x26, [sp, #664]
    88a8:	f90153fb 	str	x27, [sp, #672]
    88ac:	f90157fc 	str	x28, [sp, #680]
    88b0:	fd015be8 	str	d8, [sp, #688]
    88b4:	fd015fe9 	str	d9, [sp, #696]
    88b8:	97ffe7fa 	bl	28a0 <__stack_chk_fail@plt>
    88bc:	d503201f 	nop

00000000000088c0 <fwp_main_thread>:
    88c0:	d10603ff 	sub	sp, sp, #0x180
    88c4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    88c8:	f947f400 	ldr	x0, [x0, #4072]
    88cc:	a9127bfd 	stp	x29, x30, [sp, #288]
    88d0:	910483fd 	add	x29, sp, #0x120
    88d4:	a91353f3 	stp	x19, x20, [sp, #304]
    88d8:	b0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    88dc:	91188261 	add	x1, x19, #0x620
    88e0:	a9145bf5 	stp	x21, x22, [sp, #320]
    88e4:	a91563f7 	stp	x23, x24, [sp, #336]
    88e8:	b953a421 	ldr	w1, [x1, #5028]
    88ec:	f9400002 	ldr	x2, [x0]
    88f0:	f9008fe2 	str	x2, [sp, #280]
    88f4:	d2800002 	mov	x2, #0x0                   	// #0
    88f8:	34000f81 	cbz	w1, 8ae8 <fwp_main_thread+0x228>
    88fc:	91188260 	add	x0, x19, #0x620
    8900:	b953a800 	ldr	w0, [x0, #5032]
    8904:	35000ea0 	cbnz	w0, 8ad8 <fwp_main_thread+0x218>
    8908:	900000d5 	adrp	x21, 20000 <__data_start>
    890c:	900000c2 	adrp	x2, 20000 <__data_start>
    8910:	910142b4 	add	x20, x21, #0x50
    8914:	91110042 	add	x2, x2, #0x440
    8918:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    891c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8920:	910103f7 	add	x23, sp, #0x40
    8924:	9100a3f6 	add	x22, sp, #0x28
    8928:	aa1703e0 	mov	x0, x23
    892c:	d2800001 	mov	x1, #0x0                   	// #0
    8930:	f90023e2 	str	x2, [sp, #64]
    8934:	b9004bff 	str	wzr, [sp, #72]
    8938:	f9002be4 	str	x4, [sp, #80]
    893c:	a90a0e96 	stp	x22, x3, [x20, #160]
    8940:	97ffe770 	bl	2700 <sigaltstack@plt>
    8944:	35000220 	cbnz	w0, 8988 <fwp_main_thread+0xc8>
    8948:	4f000400 	movi	v0.4s, #0x0
    894c:	910223e0 	add	x0, sp, #0x88
    8950:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    8954:	9102c021 	add	x1, x1, #0xb0
    8958:	f90043e1 	str	x1, [sp, #128]
    895c:	52800082 	mov	w2, #0x4                   	// #4
    8960:	72a10002 	movk	w2, #0x800, lsl #16
    8964:	910203f8 	add	x24, sp, #0x80
    8968:	3d802000 	str	q0, [x0, #128]
    896c:	b9010be2 	str	w2, [sp, #264]
    8970:	ad000000 	stp	q0, q0, [x0]
    8974:	ad010000 	stp	q0, q0, [x0, #32]
    8978:	ad020000 	stp	q0, q0, [x0, #64]
    897c:	ad030000 	stp	q0, q0, [x0, #96]
    8980:	97ffe7b8 	bl	2860 <sigemptyset@plt>
    8984:	340000c0 	cbz	w0, 899c <fwp_main_thread+0xdc>
    8988:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    898c:	910bc000 	add	x0, x0, #0x2f0
    8990:	a9166bf9 	stp	x25, x26, [sp, #352]
    8994:	a91773fb 	stp	x27, x28, [sp, #368]
    8998:	97ffee67 	bl	4334 <fwp_trap>
    899c:	aa1803e1 	mov	x1, x24
    89a0:	d2800002 	mov	x2, #0x0                   	// #0
    89a4:	52800160 	mov	w0, #0xb                   	// #11
    89a8:	97ffe7c6 	bl	28c0 <sigaction@plt>
    89ac:	35fffee0 	cbnz	w0, 8988 <fwp_main_thread+0xc8>
    89b0:	aa1803e1 	mov	x1, x24
    89b4:	d2800002 	mov	x2, #0x0                   	// #0
    89b8:	528000e0 	mov	w0, #0x7                   	// #7
    89bc:	97ffe7c1 	bl	28c0 <sigaction@plt>
    89c0:	35fffe40 	cbnz	w0, 8988 <fwp_main_thread+0xc8>
    89c4:	a9166bf9 	stp	x25, x26, [sp, #352]
    89c8:	9118827a 	add	x26, x19, #0x620
    89cc:	52800039 	mov	w25, #0x1                   	// #1
    89d0:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    89d4:	910ec000 	add	x0, x0, #0x3b0
    89d8:	fd4a1340 	ldr	d0, [x26, #5152]
    89dc:	b9013299 	str	w25, [x20, #304]
    89e0:	7e61d800 	ucvtf	d0, d0
    89e4:	fd00a680 	str	d0, [x20, #328]
    89e8:	94000476 	bl	9bc0 <atexit>
    89ec:	35005120 	cbnz	w0, 9410 <fwp_main_thread+0xb50>
    89f0:	b943c680 	ldr	w0, [x20, #964]
    89f4:	340007e0 	cbz	w0, 8af0 <fwp_main_thread+0x230>
    89f8:	910142ba 	add	x26, x21, #0x50
    89fc:	f9404f56 	ldr	x22, [x26, #152]
    8a00:	b40013f6 	cbz	x22, 8c7c <fwp_main_thread+0x3bc>
    8a04:	910102d7 	add	x23, x22, #0x40
    8a08:	39414ad9 	ldrb	w25, [x22, #82]
    8a0c:	52800038 	mov	w24, #0x1                   	// #1
    8a10:	39014ad8 	strb	w24, [x22, #82]
    8a14:	d503201f 	nop
    8a18:	f94016c0 	ldr	x0, [x22, #40]
    8a1c:	b40012e0 	cbz	x0, 8c78 <fwp_main_thread+0x3b8>
    8a20:	f94032c1 	ldr	x1, [x22, #96]
    8a24:	394146c0 	ldrb	w0, [x22, #81]
    8a28:	b4000f01 	cbz	x1, 8c08 <fwp_main_thread+0x348>
    8a2c:	36000dc0 	tbz	w0, #0, 8be4 <fwp_main_thread+0x324>
    8a30:	f9404f54 	ldr	x20, [x26, #152]
    8a34:	f94022c0 	ldr	x0, [x22, #64]
    8a38:	39414a81 	ldrb	w1, [x20, #82]
    8a3c:	370010e1 	tbnz	w1, #0, 8c58 <fwp_main_thread+0x398>
    8a40:	f9403281 	ldr	x1, [x20, #96]
    8a44:	a911fe97 	stp	x23, xzr, [x20, #280]
    8a48:	f9009680 	str	x0, [x20, #296]
    8a4c:	b4000040 	cbz	x0, 8a54 <fwp_main_thread+0x194>
    8a50:	f9009014 	str	x20, [x0, #288]
    8a54:	f90022d4 	str	x20, [x22, #64]
    8a58:	b4000101 	cbz	x1, 8a78 <fwp_main_thread+0x1b8>
    8a5c:	f9409740 	ldr	x0, [x26, #296]
    8a60:	39015698 	strb	w24, [x20, #85]
    8a64:	f9003681 	str	x1, [x20, #104]
    8a68:	a910829f 	stp	xzr, x0, [x20, #264]
    8a6c:	b4000040 	cbz	x0, 8a74 <fwp_main_thread+0x1b4>
    8a70:	f9008414 	str	x20, [x0, #264]
    8a74:	f9009754 	str	x20, [x26, #296]
    8a78:	39015a9f 	strb	wzr, [x20, #86]
    8a7c:	97fff8ed 	bl	6e30 <fwp_block>
    8a80:	f9408e82 	ldr	x2, [x20, #280]
    8a84:	b4000142 	cbz	x2, 8aac <fwp_main_thread+0x1ec>
    8a88:	a9520281 	ldp	x1, x0, [x20, #288]
    8a8c:	b4000f21 	cbz	x1, 8c70 <fwp_main_thread+0x3b0>
    8a90:	f9009420 	str	x0, [x1, #296]
    8a94:	f9409680 	ldr	x0, [x20, #296]
    8a98:	b4000040 	cbz	x0, 8aa0 <fwp_main_thread+0x1e0>
    8a9c:	f9009001 	str	x1, [x0, #288]
    8aa0:	91080280 	add	x0, x20, #0x200
    8aa4:	f900969f 	str	xzr, [x20, #296]
    8aa8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8aac:	39415680 	ldrb	w0, [x20, #85]
    8ab0:	3607fb40 	tbz	w0, #0, 8a18 <fwp_main_thread+0x158>
    8ab4:	a9508281 	ldp	x1, x0, [x20, #264]
    8ab8:	b4002141 	cbz	x1, 8ee0 <fwp_main_thread+0x620>
    8abc:	f9008820 	str	x0, [x1, #272]
    8ac0:	b4000040 	cbz	x0, 8ac8 <fwp_main_thread+0x208>
    8ac4:	f9008401 	str	x1, [x0, #264]
    8ac8:	91080280 	add	x0, x20, #0x200
    8acc:	3901569f 	strb	wzr, [x20, #85]
    8ad0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8ad4:	17ffffd1 	b	8a18 <fwp_main_thread+0x158>
    8ad8:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8adc:	91301000 	add	x0, x0, #0xc04
    8ae0:	94000438 	bl	9bc0 <atexit>
    8ae4:	17ffff89 	b	8908 <fwp_main_thread+0x48>
    8ae8:	97ffeca2 	bl	3d70 <fwp_heap_init>
    8aec:	17ffff84 	b	88fc <fwp_main_thread+0x3c>
    8af0:	f941ca82 	ldr	x2, [x20, #912]
    8af4:	a91773fb 	stp	x27, x28, [sp, #368]
    8af8:	d0ffffe0 	adrp	x0, 6000 <e173+0x50>
    8afc:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8b00:	91034000 	add	x0, x0, #0xd0
    8b04:	913d4021 	add	x1, x1, #0xf50
    8b08:	d280001b 	mov	x27, #0x0                   	// #0
    8b0c:	d290001c 	mov	x28, #0x8000                	// #32768
    8b10:	f90007ff 	str	xzr, [sp, #8]
    8b14:	390043f9 	strb	w25, [sp, #16]
    8b18:	a90287e2 	stp	x2, x1, [sp, #40]
    8b1c:	a903fff7 	stp	x23, xzr, [sp, #56]
    8b20:	a90503ff 	stp	xzr, x0, [sp, #80]
    8b24:	f901ca96 	str	x22, [x20, #912]
    8b28:	14000012 	b	8b70 <fwp_main_thread+0x2b0>
    8b2c:	7100045f 	cmp	w2, #0x1
    8b30:	540001a1 	b.ne	8b64 <fwp_main_thread+0x2a4>  // b.any
    8b34:	294308a6 	ldp	w6, w2, [x5, #24]
    8b38:	92403c21 	and	x1, x1, #0xffff
    8b3c:	9b067c21 	mul	x1, x1, x6
    8b40:	d360fc21 	lsr	x1, x1, #32
    8b44:	eb02003f 	cmp	x1, x2
    8b48:	540000e2 	b.cs	8b64 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8b4c:	8b010000 	add	x0, x0, x1
    8b50:	39400001 	ldrb	w1, [x0]
    8b54:	7103fc3f 	cmp	w1, #0xff
    8b58:	54003f60 	b.eq	9344 <fwp_main_thread+0xa84>  // b.none
    8b5c:	394043e1 	ldrb	w1, [sp, #16]
    8b60:	39000001 	strb	w1, [x0]
    8b64:	a9047ffb 	stp	x27, xzr, [sp, #64]
    8b68:	aa190294 	orr	x20, x20, x25
    8b6c:	b4001bf4 	cbz	x20, 8ee8 <fwp_main_thread+0x628>
    8b70:	f94007e0 	ldr	x0, [sp, #8]
    8b74:	f1000794 	subs	x20, x28, #0x1
    8b78:	aa1803e1 	mov	x1, x24
    8b7c:	f90027f4 	str	x20, [sp, #72]
    8b80:	da1f0019 	sbc	x25, x0, xzr
    8b84:	52800020 	mov	w0, #0x1                   	// #1
    8b88:	f90007f9 	str	x25, [sp, #8]
    8b8c:	aa1403fc 	mov	x28, x20
    8b90:	a9086ff4 	stp	x20, x27, [sp, #128]
    8b94:	97fff1c3 	bl	52a0 <fwp_data.part.0.constprop.0>
    8b98:	aa0003fb 	mov	x27, x0
    8b9c:	f949db41 	ldr	x1, [x26, #5040]
    8ba0:	f949ef40 	ldr	x0, [x26, #5080]
    8ba4:	cb010361 	sub	x1, x27, x1
    8ba8:	eb00403f 	cmp	x1, x0, lsl #16
    8bac:	54fffdc2 	b.cs	8b64 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8bb0:	d350fc22 	lsr	x2, x1, #16
    8bb4:	f949ff46 	ldr	x6, [x26, #5112]
    8bb8:	8b020842 	add	x2, x2, x2, lsl #2
    8bbc:	d37df042 	lsl	x2, x2, #3
    8bc0:	8b0200c5 	add	x5, x6, x2
    8bc4:	f94010a0 	ldr	x0, [x5, #32]
    8bc8:	b4fffce0 	cbz	x0, 8b64 <fwp_main_thread+0x2a4>
    8bcc:	386268c2 	ldrb	w2, [x6, x2]
    8bd0:	7100085f 	cmp	w2, #0x2
    8bd4:	54fffac1 	b.ne	8b2c <fwp_main_thread+0x26c>  // b.any
    8bd8:	72003c3f 	tst	w1, #0xffff
    8bdc:	54fffc41 	b.ne	8b64 <fwp_main_thread+0x2a4>  // b.any
    8be0:	17ffffdc 	b	8b50 <fwp_main_thread+0x290>
    8be4:	97ffeff3 	bl	4bb0 <fwp_now_ns>
    8be8:	f94032c1 	ldr	x1, [x22, #96]
    8bec:	eb01001f 	cmp	x0, x1
    8bf0:	540000ab 	b.lt	8c04 <fwp_main_thread+0x344>  // b.tstop
    8bf4:	394142c0 	ldrb	w0, [x22, #80]
    8bf8:	37000060 	tbnz	w0, #0, 8c04 <fwp_main_thread+0x344>
    8bfc:	aa1603e0 	mov	x0, x22
    8c00:	97ffeabc 	bl	36f0 <fwp_cancel_tree.part.0>
    8c04:	394146c0 	ldrb	w0, [x22, #81]
    8c08:	f9404f54 	ldr	x20, [x26, #152]
    8c0c:	39414a82 	ldrb	w2, [x20, #82]
    8c10:	3707f100 	tbnz	w0, #0, 8a30 <fwp_main_thread+0x170>
    8c14:	f94032c1 	ldr	x1, [x22, #96]
    8c18:	370001c2 	tbnz	w2, #0, 8c50 <fwp_main_thread+0x390>
    8c1c:	f9403280 	ldr	x0, [x20, #96]
    8c20:	b4000180 	cbz	x0, 8c50 <fwp_main_thread+0x390>
    8c24:	b4000061 	cbz	x1, 8c30 <fwp_main_thread+0x370>
    8c28:	eb01001f 	cmp	x0, x1
    8c2c:	9a81d000 	csel	x0, x0, x1, le
    8c30:	f94022c1 	ldr	x1, [x22, #64]
    8c34:	a911fe97 	stp	x23, xzr, [x20, #280]
    8c38:	f9009681 	str	x1, [x20, #296]
    8c3c:	b40038c1 	cbz	x1, 9354 <fwp_main_thread+0xa94>
    8c40:	f9009034 	str	x20, [x1, #288]
    8c44:	aa0003e1 	mov	x1, x0
    8c48:	f90022d4 	str	x20, [x22, #64]
    8c4c:	17ffff84 	b	8a5c <fwp_main_thread+0x19c>
    8c50:	f94022c0 	ldr	x0, [x22, #64]
    8c54:	17ffff7c 	b	8a44 <fwp_main_thread+0x184>
    8c58:	a911fe97 	stp	x23, xzr, [x20, #280]
    8c5c:	f9009680 	str	x0, [x20, #296]
    8c60:	b4000040 	cbz	x0, 8c68 <fwp_main_thread+0x3a8>
    8c64:	f9009014 	str	x20, [x0, #288]
    8c68:	f90022d4 	str	x20, [x22, #64]
    8c6c:	17ffff83 	b	8a78 <fwp_main_thread+0x1b8>
    8c70:	f9000040 	str	x0, [x2]
    8c74:	17ffff89 	b	8a98 <fwp_main_thread+0x1d8>
    8c78:	39014ad9 	strb	w25, [x22, #82]
    8c7c:	910142b4 	add	x20, x21, #0x50
    8c80:	f941d680 	ldr	x0, [x20, #936]
    8c84:	b5000060 	cbnz	x0, 8c90 <fwp_main_thread+0x3d0>
    8c88:	f941de80 	ldr	x0, [x20, #952]
    8c8c:	b4003820 	cbz	x0, 9390 <fwp_main_thread+0xad0>
    8c90:	910142a0 	add	x0, x21, #0x50
    8c94:	f9404c00 	ldr	x0, [x0, #152]
    8c98:	910142a1 	add	x1, x21, #0x50
    8c9c:	f941ec26 	ldr	x6, [x1, #984]
    8ca0:	b903d03f 	str	wzr, [x1, #976]
    8ca4:	eb0000df 	cmp	x6, x0
    8ca8:	540040a1 	b.ne	94bc <fwp_main_thread+0xbfc>  // b.any
    8cac:	b40003c0 	cbz	x0, 8d24 <fwp_main_thread+0x464>
    8cb0:	f941c025 	ldr	x5, [x1, #896]
    8cb4:	52800021 	mov	w1, #0x1                   	// #1
    8cb8:	39014801 	strb	w1, [x0, #82]
    8cbc:	b4000345 	cbz	x5, 8d24 <fwp_main_thread+0x464>
    8cc0:	394140a0 	ldrb	w0, [x5, #80]
    8cc4:	37000060 	tbnz	w0, #0, 8cd0 <fwp_main_thread+0x410>
    8cc8:	aa0503e0 	mov	x0, x5
    8ccc:	97ffea89 	bl	36f0 <fwp_cancel_tree.part.0>
    8cd0:	f9409ca5 	ldr	x5, [x5, #312]
    8cd4:	b5ffff65 	cbnz	x5, 8cc0 <fwp_main_thread+0x400>
    8cd8:	910142b4 	add	x20, x21, #0x50
    8cdc:	52800036 	mov	w22, #0x1                   	// #1
    8ce0:	f94028c0 	ldr	x0, [x6, #80]
    8ce4:	f2001c1f 	tst	x0, #0xff000000ff
    8ce8:	540000e1 	b.ne	8d04 <fwp_main_thread+0x444>  // b.any
    8cec:	f9406280 	ldr	x0, [x20, #192]
    8cf0:	390150d6 	strb	w22, [x6, #84]
    8cf4:	f90080df 	str	xzr, [x6, #256]
    8cf8:	b4000120 	cbz	x0, 8d1c <fwp_main_thread+0x45c>
    8cfc:	f9008006 	str	x6, [x0, #256]
    8d00:	f9006286 	str	x6, [x20, #192]
    8d04:	97fff84b 	bl	6e30 <fwp_block>
    8d08:	97fff7d2 	bl	6c50 <fwp_free_zombie>
    8d0c:	f941c280 	ldr	x0, [x20, #896]
    8d10:	b40000a0 	cbz	x0, 8d24 <fwp_main_thread+0x464>
    8d14:	f941ee86 	ldr	x6, [x20, #984]
    8d18:	17fffff2 	b	8ce0 <fwp_main_thread+0x420>
    8d1c:	f9006686 	str	x6, [x20, #200]
    8d20:	17fffff8 	b	8d00 <fwp_main_thread+0x440>
    8d24:	910142b6 	add	x22, x21, #0x50
    8d28:	97fff7ca 	bl	6c50 <fwp_free_zombie>
    8d2c:	f94066c0 	ldr	x0, [x22, #200]
    8d30:	b5003c60 	cbnz	x0, 94bc <fwp_main_thread+0xbfc>
    8d34:	f94096c0 	ldr	x0, [x22, #296]
    8d38:	b5003c20 	cbnz	x0, 94bc <fwp_main_thread+0xbfc>
    8d3c:	b94172d4 	ldr	w20, [x22, #368]
    8d40:	340001f4 	cbz	w20, 8d7c <fwp_main_thread+0x4bc>
    8d44:	93407e97 	sxtw	x23, w20
    8d48:	51000694 	sub	w20, w20, #0x1
    8d4c:	d1000af7 	sub	x23, x23, #0x2
    8d50:	910602d8 	add	x24, x22, #0x180
    8d54:	cb3442f7 	sub	x23, x23, w20, uxtw
    8d58:	93407e94 	sxtw	x20, w20
    8d5c:	d503201f 	nop
    8d60:	f8747b00 	ldr	x0, [x24, x20, lsl #3]
    8d64:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8d68:	b90172d4 	str	w20, [x22, #368]
    8d6c:	d1000694 	sub	x20, x20, #0x1
    8d70:	97ffe714 	bl	29c0 <munmap@plt>
    8d74:	eb17029f 	cmp	x20, x23
    8d78:	54ffff41 	b.ne	8d60 <fwp_main_thread+0x4a0>  // b.any
    8d7c:	900000d4 	adrp	x20, 20000 <__data_start>
    8d80:	91004280 	add	x0, x20, #0x10
    8d84:	b9402000 	ldr	w0, [x0, #32]
    8d88:	37f80040 	tbnz	w0, #31, 8d90 <fwp_main_thread+0x4d0>
    8d8c:	97ffe6c9 	bl	28b0 <close@plt>
    8d90:	910142b6 	add	x22, x21, #0x50
    8d94:	91004294 	add	x20, x20, #0x10
    8d98:	12800001 	mov	w1, #0xffffffff            	// #-1
    8d9c:	f941f6c0 	ldr	x0, [x22, #1000]
    8da0:	b9002281 	str	w1, [x20, #32]
    8da4:	f941f2c1 	ldr	x1, [x22, #992]
    8da8:	b40001c0 	cbz	x0, 8de0 <fwp_main_thread+0x520>
    8dac:	d2800014 	mov	x20, #0x0                   	// #0
    8db0:	f8747820 	ldr	x0, [x1, x20, lsl #3]
    8db4:	b40000e0 	cbz	x0, 8dd0 <fwp_main_thread+0x510>
    8db8:	f9400001 	ldr	x1, [x0]
    8dbc:	b5003801 	cbnz	x1, 94bc <fwp_main_thread+0xbfc>
    8dc0:	f9400401 	ldr	x1, [x0, #8]
    8dc4:	b50037c1 	cbnz	x1, 94bc <fwp_main_thread+0xbfc>
    8dc8:	97ffee16 	bl	4620 <fwp_mem_free>
    8dcc:	f941f2c1 	ldr	x1, [x22, #992]
    8dd0:	91000694 	add	x20, x20, #0x1
    8dd4:	f941f6c0 	ldr	x0, [x22, #1000]
    8dd8:	eb00029f 	cmp	x20, x0
    8ddc:	54fffea3 	b.cc	8db0 <fwp_main_thread+0x4f0>  // b.lo, b.ul, b.last
    8de0:	aa0103e0 	mov	x0, x1
    8de4:	97ffee0f 	bl	4620 <fwp_mem_free>
    8de8:	910142a0 	add	x0, x21, #0x50
    8dec:	f941ec14 	ldr	x20, [x0, #984]
    8df0:	f901f01f 	str	xzr, [x0, #992]
    8df4:	f901f41f 	str	xzr, [x0, #1000]
    8df8:	b40001f4 	cbz	x20, 8e34 <fwp_main_thread+0x574>
    8dfc:	f9401681 	ldr	x1, [x20, #40]
    8e00:	b50035e1 	cbnz	x1, 94bc <fwp_main_thread+0xbfc>
    8e04:	f9405681 	ldr	x1, [x20, #168]
    8e08:	b50035a1 	cbnz	x1, 94bc <fwp_main_thread+0xbfc>
    8e0c:	f941d401 	ldr	x1, [x0, #936]
    8e10:	b5003561 	cbnz	x1, 94bc <fwp_main_thread+0xbfc>
    8e14:	f941dc00 	ldr	x0, [x0, #952]
    8e18:	b5003520 	cbnz	x0, 94bc <fwp_main_thread+0xbfc>
    8e1c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8e20:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bc0>
    8e24:	91110000 	add	x0, x0, #0x440
    8e28:	97ffe692 	bl	2870 <memset@plt>
    8e2c:	aa1403e0 	mov	x0, x20
    8e30:	97ffedfc 	bl	4620 <fwp_mem_free>
    8e34:	910142a6 	add	x6, x21, #0x50
    8e38:	91188273 	add	x19, x19, #0x620
    8e3c:	3dc016a1 	ldr	q1, [x21, #80]
    8e40:	52800041 	mov	w1, #0x2                   	// #2
    8e44:	3dc004c2 	ldr	q2, [x6, #16]
    8e48:	d0000002 	adrp	x2, a000 <_IO_stdin_used+0x410>
    8e4c:	fd4a1260 	ldr	d0, [x19, #5152]
    8e50:	910d4042 	add	x2, x2, #0x350
    8e54:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8e58:	fd40a4c1 	ldr	d1, [x6, #328]
    8e5c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8e60:	f947e800 	ldr	x0, [x0, #4048]
    8e64:	7e61d800 	ucvtf	d0, d0
    8e68:	a95390c3 	ldp	x3, x4, [x6, #312]
    8e6c:	f9004cdf 	str	xzr, [x6, #152]
    8e70:	f9400000 	ldr	x0, [x0]
    8e74:	1e613801 	fsub	d1, d0, d1
    8e78:	f940acc5 	ldr	x5, [x6, #344]
    8e7c:	b90130df 	str	wzr, [x6, #304]
    8e80:	5ef1b842 	addp	d2, v2.2d
    8e84:	fd40a8c0 	ldr	d0, [x6, #336]
    8e88:	f901ecdf 	str	xzr, [x6, #984]
    8e8c:	fd0058c2 	str	d2, [x6, #176]
    8e90:	97ffe6a0 	bl	2910 <__fprintf_chk@plt>
    8e94:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8e98:	f947ec00 	ldr	x0, [x0, #4056]
    8e9c:	f9400000 	ldr	x0, [x0]
    8ea0:	97ffe6cc 	bl	29d0 <fflush@plt>
    8ea4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8ea8:	f947f400 	ldr	x0, [x0, #4072]
    8eac:	f9408fe2 	ldr	x2, [sp, #280]
    8eb0:	f9400001 	ldr	x1, [x0]
    8eb4:	eb010042 	subs	x2, x2, x1
    8eb8:	d2800001 	mov	x1, #0x0                   	// #0
    8ebc:	54002b21 	b.ne	9420 <fwp_main_thread+0xb60>  // b.any
    8ec0:	a9527bfd 	ldp	x29, x30, [sp, #288]
    8ec4:	d2800000 	mov	x0, #0x0                   	// #0
    8ec8:	a95353f3 	ldp	x19, x20, [sp, #304]
    8ecc:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8ed0:	a95563f7 	ldp	x23, x24, [sp, #336]
    8ed4:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8ed8:	910603ff 	add	sp, sp, #0x180
    8edc:	d65f03c0 	ret
    8ee0:	f9009740 	str	x0, [x26, #296]
    8ee4:	17fffef7 	b	8ac0 <fwp_main_thread+0x200>
    8ee8:	910142a2 	add	x2, x21, #0x50
    8eec:	f90023ff 	str	xzr, [sp, #64]
    8ef0:	f941c840 	ldr	x0, [x2, #912]
    8ef4:	eb16001f 	cmp	x0, x22
    8ef8:	54002e41 	b.ne	94c0 <fwp_main_thread+0xc00>  // b.any
    8efc:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    8f00:	910183e1 	add	x1, sp, #0x60
    8f04:	f94017e3 	ldr	x3, [sp, #40]
    8f08:	f901c843 	str	x3, [x2, #912]
    8f0c:	3dc2bc00 	ldr	q0, [x0, #2800]
    8f10:	52800020 	mov	w0, #0x1                   	// #1
    8f14:	3d801be0 	str	q0, [sp, #96]
    8f18:	97fff0e2 	bl	52a0 <fwp_data.part.0.constprop.0>
    8f1c:	91188263 	add	x3, x19, #0x620
    8f20:	aa0003f4 	mov	x20, x0
    8f24:	f949d861 	ldr	x1, [x3, #5040]
    8f28:	f949ec60 	ldr	x0, [x3, #5080]
    8f2c:	cb010281 	sub	x1, x20, x1
    8f30:	eb00403f 	cmp	x1, x0, lsl #16
    8f34:	54000322 	b.cs	8f98 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8f38:	d350fc22 	lsr	x2, x1, #16
    8f3c:	f949fc63 	ldr	x3, [x3, #5112]
    8f40:	8b020842 	add	x2, x2, x2, lsl #2
    8f44:	d37df042 	lsl	x2, x2, #3
    8f48:	8b020060 	add	x0, x3, x2
    8f4c:	f9401016 	ldr	x22, [x0, #32]
    8f50:	b4000256 	cbz	x22, 8f98 <fwp_main_thread+0x6d8>
    8f54:	38626862 	ldrb	w2, [x3, x2]
    8f58:	7100085f 	cmp	w2, #0x2
    8f5c:	54002020 	b.eq	9360 <fwp_main_thread+0xaa0>  // b.none
    8f60:	7100045f 	cmp	w2, #0x1
    8f64:	540001a1 	b.ne	8f98 <fwp_main_thread+0x6d8>  // b.any
    8f68:	29430002 	ldp	w2, w0, [x0, #24]
    8f6c:	92403c21 	and	x1, x1, #0xffff
    8f70:	9b027c21 	mul	x1, x1, x2
    8f74:	d360fc21 	lsr	x1, x1, #32
    8f78:	eb00003f 	cmp	x1, x0
    8f7c:	540000e2 	b.cs	8f98 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8f80:	8b0102d6 	add	x22, x22, x1
    8f84:	394002c0 	ldrb	w0, [x22]
    8f88:	7103fc1f 	cmp	w0, #0xff
    8f8c:	54002200 	b.eq	93cc <fwp_main_thread+0xb0c>  // b.none
    8f90:	52800020 	mov	w0, #0x1                   	// #1
    8f94:	390002c0 	strb	w0, [x22]
    8f98:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8f9c:	aa1803e1 	mov	x1, x24
    8fa0:	52800020 	mov	w0, #0x1                   	// #1
    8fa4:	a90853e2 	stp	x2, x20, [sp, #128]
    8fa8:	97fff0be 	bl	52a0 <fwp_data.part.0.constprop.0>
    8fac:	91188263 	add	x3, x19, #0x620
    8fb0:	aa0003f4 	mov	x20, x0
    8fb4:	f949d861 	ldr	x1, [x3, #5040]
    8fb8:	f949ec60 	ldr	x0, [x3, #5080]
    8fbc:	cb010281 	sub	x1, x20, x1
    8fc0:	eb00403f 	cmp	x1, x0, lsl #16
    8fc4:	54000322 	b.cs	9028 <fwp_main_thread+0x768>  // b.hs, b.nlast
    8fc8:	d350fc22 	lsr	x2, x1, #16
    8fcc:	f949fc63 	ldr	x3, [x3, #5112]
    8fd0:	8b020842 	add	x2, x2, x2, lsl #2
    8fd4:	d37df042 	lsl	x2, x2, #3
    8fd8:	8b020060 	add	x0, x3, x2
    8fdc:	f9401016 	ldr	x22, [x0, #32]
    8fe0:	b4000256 	cbz	x22, 9028 <fwp_main_thread+0x768>
    8fe4:	38626862 	ldrb	w2, [x3, x2]
    8fe8:	7100085f 	cmp	w2, #0x2
    8fec:	54001c00 	b.eq	936c <fwp_main_thread+0xaac>  // b.none
    8ff0:	7100045f 	cmp	w2, #0x1
    8ff4:	540001a1 	b.ne	9028 <fwp_main_thread+0x768>  // b.any
    8ff8:	29430002 	ldp	w2, w0, [x0, #24]
    8ffc:	92403c21 	and	x1, x1, #0xffff
    9000:	9b027c21 	mul	x1, x1, x2
    9004:	d360fc21 	lsr	x1, x1, #32
    9008:	eb00003f 	cmp	x1, x0
    900c:	540000e2 	b.cs	9028 <fwp_main_thread+0x768>  // b.hs, b.nlast
    9010:	8b0102d6 	add	x22, x22, x1
    9014:	394002c0 	ldrb	w0, [x22]
    9018:	7103fc1f 	cmp	w0, #0xff
    901c:	54001cc0 	b.eq	93b4 <fwp_main_thread+0xaf4>  // b.none
    9020:	52800020 	mov	w0, #0x1                   	// #1
    9024:	390002c0 	strb	w0, [x22]
    9028:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    902c:	9101c3e1 	add	x1, sp, #0x70
    9030:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9034:	52800020 	mov	w0, #0x1                   	// #1
    9038:	a90753e2 	stp	x2, x20, [sp, #112]
    903c:	97fff099 	bl	52a0 <fwp_data.part.0.constprop.0>
    9040:	91188263 	add	x3, x19, #0x620
    9044:	aa0003f9 	mov	x25, x0
    9048:	f949d861 	ldr	x1, [x3, #5040]
    904c:	f949ec60 	ldr	x0, [x3, #5080]
    9050:	cb010321 	sub	x1, x25, x1
    9054:	eb00403f 	cmp	x1, x0, lsl #16
    9058:	54000322 	b.cs	90bc <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    905c:	d350fc22 	lsr	x2, x1, #16
    9060:	f949fc63 	ldr	x3, [x3, #5112]
    9064:	8b020842 	add	x2, x2, x2, lsl #2
    9068:	d37df042 	lsl	x2, x2, #3
    906c:	8b020060 	add	x0, x3, x2
    9070:	f9401014 	ldr	x20, [x0, #32]
    9074:	b4000254 	cbz	x20, 90bc <fwp_main_thread+0x7fc>
    9078:	38626862 	ldrb	w2, [x3, x2]
    907c:	7100085f 	cmp	w2, #0x2
    9080:	540017c0 	b.eq	9378 <fwp_main_thread+0xab8>  // b.none
    9084:	7100045f 	cmp	w2, #0x1
    9088:	540001a1 	b.ne	90bc <fwp_main_thread+0x7fc>  // b.any
    908c:	29430002 	ldp	w2, w0, [x0, #24]
    9090:	92403c21 	and	x1, x1, #0xffff
    9094:	9b027c21 	mul	x1, x1, x2
    9098:	d360fc21 	lsr	x1, x1, #32
    909c:	eb00003f 	cmp	x1, x0
    90a0:	540000e2 	b.cs	90bc <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    90a4:	8b010294 	add	x20, x20, x1
    90a8:	39400280 	ldrb	w0, [x20]
    90ac:	7103fc1f 	cmp	w0, #0xff
    90b0:	54001880 	b.eq	93c0 <fwp_main_thread+0xb00>  // b.none
    90b4:	52800020 	mov	w0, #0x1                   	// #1
    90b8:	39000280 	strb	w0, [x20]
    90bc:	aa1b03f8 	mov	x24, x27
    90c0:	b00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x121e8>
    90c4:	b40012db 	cbz	x27, 931c <fwp_main_thread+0xa5c>
    90c8:	910ac000 	add	x0, x0, #0x2b0
    90cc:	90000016 	adrp	x22, 9000 <fwp_main_thread+0x740>
    90d0:	91014014 	add	x20, x0, #0x50
    90d4:	9130c2d6 	add	x22, x22, #0xc30
    90d8:	9118827a 	add	x26, x19, #0x620
    90dc:	f949db41 	ldr	x1, [x26, #5040]
    90e0:	f949ef40 	ldr	x0, [x26, #5080]
    90e4:	cb010321 	sub	x1, x25, x1
    90e8:	eb00403f 	cmp	x1, x0, lsl #16
    90ec:	54000402 	b.cs	916c <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    90f0:	d350fc22 	lsr	x2, x1, #16
    90f4:	f949ff45 	ldr	x5, [x26, #5112]
    90f8:	8b020842 	add	x2, x2, x2, lsl #2
    90fc:	d37df042 	lsl	x2, x2, #3
    9100:	8b0200a3 	add	x3, x5, x2
    9104:	f9401060 	ldr	x0, [x3, #32]
    9108:	b4000320 	cbz	x0, 916c <fwp_main_thread+0x8ac>
    910c:	386268a2 	ldrb	w2, [x5, x2]
    9110:	7100085f 	cmp	w2, #0x2
    9114:	54001380 	b.eq	9384 <fwp_main_thread+0xac4>  // b.none
    9118:	7100045f 	cmp	w2, #0x1
    911c:	54000281 	b.ne	916c <fwp_main_thread+0x8ac>  // b.any
    9120:	29430865 	ldp	w5, w2, [x3, #24]
    9124:	92403c21 	and	x1, x1, #0xffff
    9128:	9b057c21 	mul	x1, x1, x5
    912c:	d360fc21 	lsr	x1, x1, #32
    9130:	eb02003f 	cmp	x1, x2
    9134:	540001c2 	b.cs	916c <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    9138:	8b010000 	add	x0, x0, x1
    913c:	39400001 	ldrb	w1, [x0]
    9140:	34000161 	cbz	w1, 916c <fwp_main_thread+0x8ac>
    9144:	910142a2 	add	x2, x21, #0x50
    9148:	b9413043 	ldr	w3, [x2, #304]
    914c:	34000083 	cbz	w3, 915c <fwp_main_thread+0x89c>
    9150:	f940ac43 	ldr	x3, [x2, #344]
    9154:	91000463 	add	x3, x3, #0x1
    9158:	f900ac43 	str	x3, [x2, #344]
    915c:	7103f43f 	cmp	w1, #0xfd
    9160:	540013c8 	b.hi	93d8 <fwp_main_thread+0xb18>  // b.pmore
    9164:	11000421 	add	w1, w1, #0x1
    9168:	39000001 	strb	w1, [x0]
    916c:	aa1403e2 	mov	x2, x20
    9170:	aa1903e1 	mov	x1, x25
    9174:	aa1703e0 	mov	x0, x23
    9178:	52800023 	mov	w3, #0x1                   	// #1
    917c:	a9047fff 	stp	xzr, xzr, [sp, #64]
    9180:	f9002bff 	str	xzr, [sp, #80]
    9184:	97fff9d4 	bl	78d4 <fwp_write>
    9188:	a9440bfc 	ldp	x28, x2, [sp, #64]
    918c:	f100039f 	cmp	x28, #0x0
    9190:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    9194:	b100285f 	cmn	x2, #0xa
    9198:	54001248 	b.hi	93e0 <fwp_main_thread+0xb20>  // b.pmore
    919c:	91002440 	add	x0, x2, #0x9
    91a0:	52800021 	mov	w1, #0x1                   	// #1
    91a4:	f9000be2 	str	x2, [sp, #16]
    91a8:	97ffefda 	bl	5110 <fwp_heap_alloc>
    91ac:	aa1c03e1 	mov	x1, x28
    91b0:	aa0003fc 	mov	x28, x0
    91b4:	f9400be2 	ldr	x2, [sp, #16]
    91b8:	f90007e0 	str	x0, [sp, #8]
    91bc:	f8008782 	str	x2, [x28], #8
    91c0:	aa1c03e0 	mov	x0, x28
    91c4:	97ffe54b 	bl	26f0 <memcpy@plt>
    91c8:	a9408be0 	ldp	x0, x2, [sp, #8]
    91cc:	8b020002 	add	x2, x0, x2
    91d0:	3900205f 	strb	wzr, [x2, #8]
    91d4:	f94023e0 	ldr	x0, [sp, #64]
    91d8:	97ffe5e2 	bl	2960 <free@plt>
    91dc:	91188260 	add	x0, x19, #0x620
    91e0:	f94007e3 	ldr	x3, [sp, #8]
    91e4:	f949d801 	ldr	x1, [x0, #5040]
    91e8:	f949ec02 	ldr	x2, [x0, #5080]
    91ec:	cb010061 	sub	x1, x3, x1
    91f0:	eb02403f 	cmp	x1, x2, lsl #16
    91f4:	54000322 	b.cs	9258 <fwp_main_thread+0x998>  // b.hs, b.nlast
    91f8:	d350fc22 	lsr	x2, x1, #16
    91fc:	d2800503 	mov	x3, #0x28                  	// #40
    9200:	f949fc05 	ldr	x5, [x0, #5112]
    9204:	9b037c42 	mul	x2, x2, x3
    9208:	8b0200a3 	add	x3, x5, x2
    920c:	f9401060 	ldr	x0, [x3, #32]
    9210:	b4000240 	cbz	x0, 9258 <fwp_main_thread+0x998>
    9214:	386268a2 	ldrb	w2, [x5, x2]
    9218:	7100085f 	cmp	w2, #0x2
    921c:	54000f40 	b.eq	9404 <fwp_main_thread+0xb44>  // b.none
    9220:	7100045f 	cmp	w2, #0x1
    9224:	540001a1 	b.ne	9258 <fwp_main_thread+0x998>  // b.any
    9228:	29430865 	ldp	w5, w2, [x3, #24]
    922c:	92403c21 	and	x1, x1, #0xffff
    9230:	9b057c21 	mul	x1, x1, x5
    9234:	d360fc21 	lsr	x1, x1, #32
    9238:	eb02003f 	cmp	x1, x2
    923c:	540000e2 	b.cs	9258 <fwp_main_thread+0x998>  // b.hs, b.nlast
    9240:	8b010000 	add	x0, x0, x1
    9244:	39400001 	ldrb	w1, [x0]
    9248:	7103fc3f 	cmp	w1, #0xff
    924c:	540010c0 	b.eq	9464 <fwp_main_thread+0xba4>  // b.none
    9250:	52800021 	mov	w1, #0x1                   	// #1
    9254:	39000001 	strb	w1, [x0]
    9258:	aa1903e0 	mov	x0, x25
    925c:	97fff3f9 	bl	6240 <fwp_drop0>
    9260:	f94007e1 	ldr	x1, [sp, #8]
    9264:	910142a3 	add	x3, x21, #0x50
    9268:	aa1c03e0 	mov	x0, x28
    926c:	aa0303fc 	mov	x28, x3
    9270:	f9400022 	ldr	x2, [x1]
    9274:	d2800021 	mov	x1, #0x1                   	// #1
    9278:	f9404863 	ldr	x3, [x3, #144]
    927c:	97ffe5c9 	bl	29a0 <fwrite@plt>
    9280:	f9404b81 	ldr	x1, [x28, #144]
    9284:	52800140 	mov	w0, #0xa                   	// #10
    9288:	97ffe54e 	bl	27c0 <fputc@plt>
    928c:	91188262 	add	x2, x19, #0x620
    9290:	f94007e3 	ldr	x3, [sp, #8]
    9294:	f949d841 	ldr	x1, [x2, #5040]
    9298:	f949ec40 	ldr	x0, [x2, #5080]
    929c:	cb010061 	sub	x1, x3, x1
    92a0:	eb00403f 	cmp	x1, x0, lsl #16
    92a4:	54000382 	b.cs	9314 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    92a8:	d350fc20 	lsr	x0, x1, #16
    92ac:	d2800505 	mov	x5, #0x28                  	// #40
    92b0:	f949fc43 	ldr	x3, [x2, #5112]
    92b4:	9b057c00 	mul	x0, x0, x5
    92b8:	8b000062 	add	x2, x3, x0
    92bc:	f940105c 	ldr	x28, [x2, #32]
    92c0:	b40002bc 	cbz	x28, 9314 <fwp_main_thread+0xa54>
    92c4:	38606860 	ldrb	w0, [x3, x0]
    92c8:	7100081f 	cmp	w0, #0x2
    92cc:	54000960 	b.eq	93f8 <fwp_main_thread+0xb38>  // b.none
    92d0:	7100041f 	cmp	w0, #0x1
    92d4:	54000201 	b.ne	9314 <fwp_main_thread+0xa54>  // b.any
    92d8:	29430043 	ldp	w3, w0, [x2, #24]
    92dc:	92403c21 	and	x1, x1, #0xffff
    92e0:	9b037c21 	mul	x1, x1, x3
    92e4:	d360fc21 	lsr	x1, x1, #32
    92e8:	eb00003f 	cmp	x1, x0
    92ec:	54000142 	b.cs	9314 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    92f0:	8b01039c 	add	x28, x28, x1
    92f4:	39400380 	ldrb	w0, [x28]
    92f8:	340000e0 	cbz	w0, 9314 <fwp_main_thread+0xa54>
    92fc:	7100041f 	cmp	w0, #0x1
    9300:	54000760 	b.eq	93ec <fwp_main_thread+0xb2c>  // b.none
    9304:	7103fc1f 	cmp	w0, #0xff
    9308:	54000900 	b.eq	9428 <fwp_main_thread+0xb68>  // b.none
    930c:	51000400 	sub	w0, w0, #0x1
    9310:	39000380 	strb	w0, [x28]
    9314:	f9400b18 	ldr	x24, [x24, #16]
    9318:	b5ffee38 	cbnz	x24, 90dc <fwp_main_thread+0x81c>
    931c:	aa1903e0 	mov	x0, x25
    9320:	97fff3c8 	bl	6240 <fwp_drop0>
    9324:	aa1b03e0 	mov	x0, x27
    9328:	97fff3c6 	bl	6240 <fwp_drop0>
    932c:	910142a0 	add	x0, x21, #0x50
    9330:	52800021 	mov	w1, #0x1                   	// #1
    9334:	a95773fb 	ldp	x27, x28, [sp, #368]
    9338:	b903c401 	str	w1, [x0, #964]
    933c:	f901e41f 	str	xzr, [x0, #968]
    9340:	17fffdae 	b	89f8 <fwp_main_thread+0x138>
    9344:	f9000fe0 	str	x0, [sp, #24]
    9348:	97ffec1b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    934c:	f9400fe0 	ldr	x0, [sp, #24]
    9350:	17fffe03 	b	8b5c <fwp_main_thread+0x29c>
    9354:	aa0003e1 	mov	x1, x0
    9358:	f90022d4 	str	x20, [x22, #64]
    935c:	17fffdc0 	b	8a5c <fwp_main_thread+0x19c>
    9360:	72003c3f 	tst	w1, #0xffff
    9364:	54ffe1a1 	b.ne	8f98 <fwp_main_thread+0x6d8>  // b.any
    9368:	17ffff07 	b	8f84 <fwp_main_thread+0x6c4>
    936c:	72003c3f 	tst	w1, #0xffff
    9370:	54ffe5c1 	b.ne	9028 <fwp_main_thread+0x768>  // b.any
    9374:	17ffff28 	b	9014 <fwp_main_thread+0x754>
    9378:	72003c3f 	tst	w1, #0xffff
    937c:	54ffea01 	b.ne	90bc <fwp_main_thread+0x7fc>  // b.any
    9380:	17ffff4a 	b	90a8 <fwp_main_thread+0x7e8>
    9384:	72003c3f 	tst	w1, #0xffff
    9388:	54ffef21 	b.ne	916c <fwp_main_thread+0x8ac>  // b.any
    938c:	17ffff6c 	b	913c <fwp_main_thread+0x87c>
    9390:	f941d280 	ldr	x0, [x20, #928]
    9394:	97ffeca3 	bl	4620 <fwp_mem_free>
    9398:	f901d29f 	str	xzr, [x20, #928]
    939c:	f9404e80 	ldr	x0, [x20, #152]
    93a0:	f901da9f 	str	xzr, [x20, #944]
    93a4:	b4ffc7a0 	cbz	x0, 8c98 <fwp_main_thread+0x3d8>
    93a8:	f900541f 	str	xzr, [x0, #168]
    93ac:	f9005c1f 	str	xzr, [x0, #184]
    93b0:	17fffe3a 	b	8c98 <fwp_main_thread+0x3d8>
    93b4:	aa1603e0 	mov	x0, x22
    93b8:	97ffebff 	bl	43b4 <fwp_rc_forget_slot.part.0>
    93bc:	17ffff19 	b	9020 <fwp_main_thread+0x760>
    93c0:	aa1403e0 	mov	x0, x20
    93c4:	97ffebfc 	bl	43b4 <fwp_rc_forget_slot.part.0>
    93c8:	17ffff3b 	b	90b4 <fwp_main_thread+0x7f4>
    93cc:	aa1603e0 	mov	x0, x22
    93d0:	97ffebf9 	bl	43b4 <fwp_rc_forget_slot.part.0>
    93d4:	17fffeef 	b	8f90 <fwp_main_thread+0x6d0>
    93d8:	97ffed0b 	bl	4804 <fwp_rc_wide_dup>
    93dc:	17ffff64 	b	916c <fwp_main_thread+0x8ac>
    93e0:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    93e4:	910ce000 	add	x0, x0, #0x338
    93e8:	97ffebd3 	bl	4334 <fwp_trap>
    93ec:	f94007e0 	ldr	x0, [sp, #8]
    93f0:	97fff259 	bl	5d54 <fwp_rc_free_arr>
    93f4:	17ffffc8 	b	9314 <fwp_main_thread+0xa54>
    93f8:	72003c3f 	tst	w1, #0xffff
    93fc:	54fff8c1 	b.ne	9314 <fwp_main_thread+0xa54>  // b.any
    9400:	17ffffbd 	b	92f4 <fwp_main_thread+0xa34>
    9404:	72003c3f 	tst	w1, #0xffff
    9408:	54fff281 	b.ne	9258 <fwp_main_thread+0x998>  // b.any
    940c:	17ffff8e 	b	9244 <fwp_main_thread+0x984>
    9410:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x410>
    9414:	910c6000 	add	x0, x0, #0x318
    9418:	a91773fb 	stp	x27, x28, [sp, #368]
    941c:	97ffe7d9 	bl	3380 <ad_raw_fail>
    9420:	a91773fb 	stp	x27, x28, [sp, #368]
    9424:	97ffe51f 	bl	28a0 <__stack_chk_fail@plt>
    9428:	ca5c4780 	eor	x0, x28, x28, lsr #17
    942c:	91188262 	add	x2, x19, #0x620
    9430:	ca402400 	eor	x0, x0, x0, lsr #9
    9434:	92401c00 	and	x0, x0, #0xff
    9438:	910a2401 	add	x1, x0, #0x289
    943c:	8b000c40 	add	x0, x2, x0, lsl #3
    9440:	8b010c41 	add	x1, x2, x1, lsl #3
    9444:	f94a2400 	ldr	x0, [x0, #5192]
    9448:	b40002e0 	cbz	x0, 94a4 <fwp_main_thread+0xbe4>
    944c:	f9400002 	ldr	x2, [x0]
    9450:	eb02039f 	cmp	x28, x2
    9454:	54000100 	b.eq	9474 <fwp_main_thread+0xbb4>  // b.none
    9458:	91004001 	add	x1, x0, #0x10
    945c:	f9400800 	ldr	x0, [x0, #16]
    9460:	17fffffa 	b	9448 <fwp_main_thread+0xb88>
    9464:	f9000be0 	str	x0, [sp, #16]
    9468:	97ffebd3 	bl	43b4 <fwp_rc_forget_slot.part.0>
    946c:	f9400be0 	ldr	x0, [sp, #16]
    9470:	17ffff78 	b	9250 <fwp_main_thread+0x990>
    9474:	f9400021 	ldr	x1, [x1]
    9478:	f9400420 	ldr	x0, [x1, #8]
    947c:	d1000400 	sub	x0, x0, #0x1
    9480:	f9000420 	str	x0, [x1, #8]
    9484:	f103f81f 	cmp	x0, #0xfe
    9488:	54fff461 	b.ne	9314 <fwp_main_thread+0xa54>  // b.any
    948c:	39400380 	ldrb	w0, [x28]
    9490:	7103fc1f 	cmp	w0, #0xff
    9494:	540000e0 	b.eq	94b0 <fwp_main_thread+0xbf0>  // b.none
    9498:	12800020 	mov	w0, #0xfffffffe            	// #-2
    949c:	39000380 	strb	w0, [x28]
    94a0:	17ffff9d 	b	9314 <fwp_main_thread+0xa54>
    94a4:	90000000 	adrp	x0, 9000 <fwp_main_thread+0x740>
    94a8:	913d2000 	add	x0, x0, #0xf48
    94ac:	97ffeba2 	bl	4334 <fwp_trap>
    94b0:	aa1c03e0 	mov	x0, x28
    94b4:	97ffebc0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    94b8:	17fffff8 	b	9498 <fwp_main_thread+0xbd8>
    94bc:	a91773fb 	stp	x27, x28, [sp, #368]
    94c0:	97ffe50c 	bl	28f0 <abort@plt>
    94c4:	d503201f 	nop
    94c8:	d503201f 	nop
    94cc:	d503201f 	nop

00000000000094d0 <__divti3>:
    94d0:	d503245f 	bti	c
    94d4:	d2800004 	mov	x4, #0x0                   	// #0
    94d8:	b7f80721 	tbnz	x1, #63, 95bc <__divti3+0xec>
    94dc:	b6f80083 	tbz	x3, #63, 94ec <__divti3+0x1c>
    94e0:	eb0203e2 	negs	x2, x2
    94e4:	aa2403e4 	mvn	x4, x4
    94e8:	da0303e3 	ngc	x3, x3
    94ec:	aa0203e6 	mov	x6, x2
    94f0:	aa0003e7 	mov	x7, x0
    94f4:	aa0103e5 	mov	x5, x1
    94f8:	b5000583 	cbnz	x3, 95a8 <__divti3+0xd8>
    94fc:	eb01005f 	cmp	x2, x1
    9500:	54000e69 	b.ls	96cc <__divti3+0x1fc>  // b.plast
    9504:	dac01040 	clz	x0, x2
    9508:	b40000e0 	cbz	x0, 9524 <__divti3+0x54>
    950c:	4b0003e1 	neg	w1, w0
    9510:	9ac020a5 	lsl	x5, x5, x0
    9514:	9ac02046 	lsl	x6, x2, x0
    9518:	9ac124e1 	lsr	x1, x7, x1
    951c:	aa050025 	orr	x5, x1, x5
    9520:	9ac020e7 	lsl	x7, x7, x0
    9524:	d360fcc8 	lsr	x8, x6, #32
    9528:	92407cc2 	and	x2, x6, #0xffffffff
    952c:	9ac808a3 	udiv	x3, x5, x8
    9530:	9b089465 	msub	x5, x3, x8, x5
    9534:	aa0303e0 	mov	x0, x3
    9538:	9b037c41 	mul	x1, x2, x3
    953c:	93c780a5 	extr	x5, x5, x7, #32
    9540:	eb05003f 	cmp	x1, x5
    9544:	540000a9 	b.ls	9558 <__divti3+0x88>  // b.plast
    9548:	ab0500c5 	adds	x5, x6, x5
    954c:	d1000460 	sub	x0, x3, #0x1
    9550:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9554:	540015a8 	b.hi	9808 <__divti3+0x338>  // b.pmore
    9558:	cb0100a5 	sub	x5, x5, x1
    955c:	9ac808a3 	udiv	x3, x5, x8
    9560:	9b089465 	msub	x5, x3, x8, x5
    9564:	aa0303e1 	mov	x1, x3
    9568:	9b037c42 	mul	x2, x2, x3
    956c:	aa0703e3 	mov	x3, x7
    9570:	b3607ca3 	bfi	x3, x5, #32, #32
    9574:	eb03005f 	cmp	x2, x3
    9578:	540000c9 	b.ls	9590 <__divti3+0xc0>  // b.plast
    957c:	ab0300c3 	adds	x3, x6, x3
    9580:	d1000425 	sub	x5, x1, #0x1
    9584:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9588:	d1000821 	sub	x1, x1, #0x2
    958c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9590:	aa008020 	orr	x0, x1, x0, lsl #32
    9594:	d2800001 	mov	x1, #0x0                   	// #0
    9598:	b4000064 	cbz	x4, 95a4 <__divti3+0xd4>
    959c:	eb0003e0 	negs	x0, x0
    95a0:	da0103e1 	ngc	x1, x1
    95a4:	d65f03c0 	ret
    95a8:	eb01007f 	cmp	x3, x1
    95ac:	54000109 	b.ls	95cc <__divti3+0xfc>  // b.plast
    95b0:	d2800001 	mov	x1, #0x0                   	// #0
    95b4:	d2800000 	mov	x0, #0x0                   	// #0
    95b8:	17fffff8 	b	9598 <__divti3+0xc8>
    95bc:	eb0003e0 	negs	x0, x0
    95c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    95c4:	da0103e1 	ngc	x1, x1
    95c8:	17ffffc5 	b	94dc <__divti3+0xc>
    95cc:	dac01067 	clz	x7, x3
    95d0:	b40010e7 	cbz	x7, 97ec <__divti3+0x31c>
    95d4:	d2800805 	mov	x5, #0x40                  	// #64
    95d8:	cb0700a5 	sub	x5, x5, x7
    95dc:	9ac72063 	lsl	x3, x3, x7
    95e0:	9ac52448 	lsr	x8, x2, x5
    95e4:	aa030108 	orr	x8, x8, x3
    95e8:	9ac52426 	lsr	x6, x1, x5
    95ec:	92407d0a 	and	x10, x8, #0xffffffff
    95f0:	d360fd09 	lsr	x9, x8, #32
    95f4:	9ac52403 	lsr	x3, x0, x5
    95f8:	9ac72021 	lsl	x1, x1, x7
    95fc:	aa010063 	orr	x3, x3, x1
    9600:	9ac72042 	lsl	x2, x2, x7
    9604:	9ac908cb 	udiv	x11, x6, x9
    9608:	9b099965 	msub	x5, x11, x9, x6
    960c:	aa0b03e1 	mov	x1, x11
    9610:	9b0b7d46 	mul	x6, x10, x11
    9614:	93c380a5 	extr	x5, x5, x3, #32
    9618:	eb0500df 	cmp	x6, x5
    961c:	540000a9 	b.ls	9630 <__divti3+0x160>  // b.plast
    9620:	ab050105 	adds	x5, x8, x5
    9624:	d1000561 	sub	x1, x11, #0x1
    9628:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    962c:	54000f48 	b.hi	9814 <__divti3+0x344>  // b.pmore
    9630:	cb0600a6 	sub	x6, x5, x6
    9634:	9ac908cb 	udiv	x11, x6, x9
    9638:	9b099969 	msub	x9, x11, x9, x6
    963c:	aa0b03e5 	mov	x5, x11
    9640:	9b0b7d4a 	mul	x10, x10, x11
    9644:	b3607d23 	bfi	x3, x9, #32, #32
    9648:	eb03015f 	cmp	x10, x3
    964c:	540000a9 	b.ls	9660 <__divti3+0x190>  // b.plast
    9650:	ab030103 	adds	x3, x8, x3
    9654:	d1000565 	sub	x5, x11, #0x1
    9658:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    965c:	54000e28 	b.hi	9820 <__divti3+0x350>  // b.pmore
    9660:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9664:	92407c48 	and	x8, x2, #0xffffffff
    9668:	2a0503e5 	mov	w5, w5
    966c:	d360fc42 	lsr	x2, x2, #32
    9670:	d360fc26 	lsr	x6, x1, #32
    9674:	cb0a0063 	sub	x3, x3, x10
    9678:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    967c:	9b087caa 	mul	x10, x5, x8
    9680:	9b087cc8 	mul	x8, x6, x8
    9684:	9b0220a5 	madd	x5, x5, x2, x8
    9688:	9b027cc6 	mul	x6, x6, x2
    968c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9690:	8b0900c5 	add	x5, x6, x9
    9694:	eb02011f 	cmp	x8, x2
    9698:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    969c:	8b4280c6 	add	x6, x6, x2, lsr #32
    96a0:	eb06007f 	cmp	x3, x6
    96a4:	540000e3 	b.cc	96c0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    96a8:	92407d4a 	and	x10, x10, #0xffffffff
    96ac:	9ac72000 	lsl	x0, x0, x7
    96b0:	8b028142 	add	x2, x10, x2, lsl #32
    96b4:	eb02001f 	cmp	x0, x2
    96b8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    96bc:	54000a01 	b.ne	97fc <__divti3+0x32c>  // b.any
    96c0:	d1000420 	sub	x0, x1, #0x1
    96c4:	d2800001 	mov	x1, #0x0                   	// #0
    96c8:	17ffffb4 	b	9598 <__divti3+0xc8>
    96cc:	b5000062 	cbnz	x2, 96d8 <__divti3+0x208>
    96d0:	d2800022 	mov	x2, #0x1                   	// #1
    96d4:	9ac30846 	udiv	x6, x2, x3
    96d8:	dac010c8 	clz	x8, x6
    96dc:	b5000408 	cbnz	x8, 975c <__divti3+0x28c>
    96e0:	d360fcc9 	lsr	x9, x6, #32
    96e4:	92407cc5 	and	x5, x6, #0xffffffff
    96e8:	cb060023 	sub	x3, x1, x6
    96ec:	d2800021 	mov	x1, #0x1                   	// #1
    96f0:	9ac90868 	udiv	x8, x3, x9
    96f4:	9b098d03 	msub	x3, x8, x9, x3
    96f8:	aa0803e0 	mov	x0, x8
    96fc:	9b057d02 	mul	x2, x8, x5
    9700:	93c78063 	extr	x3, x3, x7, #32
    9704:	eb03005f 	cmp	x2, x3
    9708:	540000a9 	b.ls	971c <__divti3+0x24c>  // b.plast
    970c:	ab0300c3 	adds	x3, x6, x3
    9710:	d1000500 	sub	x0, x8, #0x1
    9714:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9718:	54000968 	b.hi	9844 <__divti3+0x374>  // b.pmore
    971c:	cb020063 	sub	x3, x3, x2
    9720:	9ac90862 	udiv	x2, x3, x9
    9724:	aa0203e8 	mov	x8, x2
    9728:	9b098c42 	msub	x2, x2, x9, x3
    972c:	aa0703e3 	mov	x3, x7
    9730:	9b057d05 	mul	x5, x8, x5
    9734:	b3607c43 	bfi	x3, x2, #32, #32
    9738:	eb0300bf 	cmp	x5, x3
    973c:	540000c9 	b.ls	9754 <__divti3+0x284>  // b.plast
    9740:	ab0300c2 	adds	x2, x6, x3
    9744:	d1000503 	sub	x3, x8, #0x1
    9748:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    974c:	d1000908 	sub	x8, x8, #0x2
    9750:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9754:	aa008100 	orr	x0, x8, x0, lsl #32
    9758:	17ffff90 	b	9598 <__divti3+0xc8>
    975c:	9ac820c6 	lsl	x6, x6, x8
    9760:	d2800803 	mov	x3, #0x40                  	// #64
    9764:	cb080063 	sub	x3, x3, x8
    9768:	d360fcc9 	lsr	x9, x6, #32
    976c:	9ac82027 	lsl	x7, x1, x8
    9770:	92407cc5 	and	x5, x6, #0xffffffff
    9774:	9ac32422 	lsr	x2, x1, x3
    9778:	9ac32403 	lsr	x3, x0, x3
    977c:	aa070063 	orr	x3, x3, x7
    9780:	9ac9084a 	udiv	x10, x2, x9
    9784:	9ac82007 	lsl	x7, x0, x8
    9788:	9b098940 	msub	x0, x10, x9, x2
    978c:	aa0a03e1 	mov	x1, x10
    9790:	9b0a7ca2 	mul	x2, x5, x10
    9794:	93c38000 	extr	x0, x0, x3, #32
    9798:	eb00005f 	cmp	x2, x0
    979c:	540000a9 	b.ls	97b0 <__divti3+0x2e0>  // b.plast
    97a0:	ab0000c0 	adds	x0, x6, x0
    97a4:	d1000541 	sub	x1, x10, #0x1
    97a8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    97ac:	54000468 	b.hi	9838 <__divti3+0x368>  // b.pmore
    97b0:	cb020000 	sub	x0, x0, x2
    97b4:	9ac9080a 	udiv	x10, x0, x9
    97b8:	9b098140 	msub	x0, x10, x9, x0
    97bc:	aa0a03e2 	mov	x2, x10
    97c0:	9b0a7ca8 	mul	x8, x5, x10
    97c4:	b3607c03 	bfi	x3, x0, #32, #32
    97c8:	eb03011f 	cmp	x8, x3
    97cc:	540000a9 	b.ls	97e0 <__divti3+0x310>  // b.plast
    97d0:	ab0300c3 	adds	x3, x6, x3
    97d4:	d1000542 	sub	x2, x10, #0x1
    97d8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    97dc:	54000288 	b.hi	982c <__divti3+0x35c>  // b.pmore
    97e0:	cb080063 	sub	x3, x3, x8
    97e4:	aa018041 	orr	x1, x2, x1, lsl #32
    97e8:	17ffffc2 	b	96f0 <__divti3+0x220>
    97ec:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    97f0:	d2800001 	mov	x1, #0x0                   	// #0
    97f4:	9a9f87e0 	cset	x0, ls	// ls = plast
    97f8:	17ffff68 	b	9598 <__divti3+0xc8>
    97fc:	aa0103e0 	mov	x0, x1
    9800:	d2800001 	mov	x1, #0x0                   	// #0
    9804:	17ffff65 	b	9598 <__divti3+0xc8>
    9808:	d1000860 	sub	x0, x3, #0x2
    980c:	8b0600a5 	add	x5, x5, x6
    9810:	17ffff52 	b	9558 <__divti3+0x88>
    9814:	d1000961 	sub	x1, x11, #0x2
    9818:	8b0800a5 	add	x5, x5, x8
    981c:	17ffff85 	b	9630 <__divti3+0x160>
    9820:	d1000965 	sub	x5, x11, #0x2
    9824:	8b080063 	add	x3, x3, x8
    9828:	17ffff8e 	b	9660 <__divti3+0x190>
    982c:	d1000942 	sub	x2, x10, #0x2
    9830:	8b060063 	add	x3, x3, x6
    9834:	17ffffeb 	b	97e0 <__divti3+0x310>
    9838:	d1000941 	sub	x1, x10, #0x2
    983c:	8b060000 	add	x0, x0, x6
    9840:	17ffffdc 	b	97b0 <__divti3+0x2e0>
    9844:	d1000900 	sub	x0, x8, #0x2
    9848:	8b060063 	add	x3, x3, x6
    984c:	17ffffb4 	b	971c <__divti3+0x24c>

0000000000009850 <__modti3>:
    9850:	d503245f 	bti	c
    9854:	d2800004 	mov	x4, #0x0                   	// #0
    9858:	b6f80081 	tbz	x1, #63, 9868 <__modti3+0x18>
    985c:	eb0003e0 	negs	x0, x0
    9860:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9864:	da0103e1 	ngc	x1, x1
    9868:	f100007f 	cmp	x3, #0x0
    986c:	5400128b 	b.lt	9abc <__modti3+0x26c>  // b.tstop
    9870:	aa0003e7 	mov	x7, x0
    9874:	aa0103e6 	mov	x6, x1
    9878:	540004e1 	b.ne	9914 <__modti3+0xc4>  // b.any
    987c:	eb02003f 	cmp	x1, x2
    9880:	54000dc2 	b.cs	9a38 <__modti3+0x1e8>  // b.hs, b.nlast
    9884:	dac01043 	clz	x3, x2
    9888:	aa0303e5 	mov	x5, x3
    988c:	b40000e3 	cbz	x3, 98a8 <__modti3+0x58>
    9890:	4b0303e6 	neg	w6, w3
    9894:	9ac32021 	lsl	x1, x1, x3
    9898:	9ac32042 	lsl	x2, x2, x3
    989c:	9ac62406 	lsr	x6, x0, x6
    98a0:	aa0100c6 	orr	x6, x6, x1
    98a4:	9ac32007 	lsl	x7, x0, x3
    98a8:	d360fc40 	lsr	x0, x2, #32
    98ac:	92407c43 	and	x3, x2, #0xffffffff
    98b0:	9ac008c1 	udiv	x1, x6, x0
    98b4:	9b009826 	msub	x6, x1, x0, x6
    98b8:	9b017c61 	mul	x1, x3, x1
    98bc:	93c780c6 	extr	x6, x6, x7, #32
    98c0:	eb06003f 	cmp	x1, x6
    98c4:	540000a9 	b.ls	98d8 <__modti3+0x88>  // b.plast
    98c8:	ab060046 	adds	x6, x2, x6
    98cc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    98d0:	8b0200c8 	add	x8, x6, x2
    98d4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    98d8:	cb0100c6 	sub	x6, x6, x1
    98dc:	9ac008c8 	udiv	x8, x6, x0
    98e0:	9b009901 	msub	x1, x8, x0, x6
    98e4:	aa0703e0 	mov	x0, x7
    98e8:	9b087c63 	mul	x3, x3, x8
    98ec:	b3607c20 	bfi	x0, x1, #32, #32
    98f0:	eb00007f 	cmp	x3, x0
    98f4:	54001088 	b.hi	9b04 <__modti3+0x2b4>  // b.pmore
    98f8:	cb030000 	sub	x0, x0, x3
    98fc:	9ac52400 	lsr	x0, x0, x5
    9900:	d2800001 	mov	x1, #0x0                   	// #0
    9904:	b4000064 	cbz	x4, 9910 <__modti3+0xc0>
    9908:	eb0003e0 	negs	x0, x0
    990c:	da0103e1 	ngc	x1, x1
    9910:	d65f03c0 	ret
    9914:	dac01066 	clz	x6, x3
    9918:	eb03003f 	cmp	x1, x3
    991c:	54ffff43 	b.cc	9904 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9920:	93407cc5 	sxtw	x5, w6
    9924:	d2800808 	mov	x8, #0x40                  	// #64
    9928:	cb050108 	sub	x8, x8, x5
    992c:	9ac62063 	lsl	x3, x3, x6
    9930:	9ac62025 	lsl	x5, x1, x6
    9934:	9ac82447 	lsr	x7, x2, x8
    9938:	aa0300e7 	orr	x7, x7, x3
    993c:	9ac82423 	lsr	x3, x1, x8
    9940:	92407cec 	and	x12, x7, #0xffffffff
    9944:	d360fcea 	lsr	x10, x7, #32
    9948:	9ac82401 	lsr	x1, x0, x8
    994c:	aa050021 	orr	x1, x1, x5
    9950:	9ac62042 	lsl	x2, x2, x6
    9954:	9ac62000 	lsl	x0, x0, x6
    9958:	9aca086b 	udiv	x11, x3, x10
    995c:	9b0a8d63 	msub	x3, x11, x10, x3
    9960:	aa0b03e5 	mov	x5, x11
    9964:	9b0b7d89 	mul	x9, x12, x11
    9968:	93c18063 	extr	x3, x3, x1, #32
    996c:	eb03013f 	cmp	x9, x3
    9970:	540000a9 	b.ls	9984 <__modti3+0x134>  // b.plast
    9974:	ab0300e3 	adds	x3, x7, x3
    9978:	d1000565 	sub	x5, x11, #0x1
    997c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9980:	54001168 	b.hi	9bac <__modti3+0x35c>  // b.pmore
    9984:	cb090063 	sub	x3, x3, x9
    9988:	9aca086b 	udiv	x11, x3, x10
    998c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9990:	aa0b03e9 	mov	x9, x11
    9994:	9b0b7d8c 	mul	x12, x12, x11
    9998:	b3607d41 	bfi	x1, x10, #32, #32
    999c:	eb01019f 	cmp	x12, x1
    99a0:	540000a9 	b.ls	99b4 <__modti3+0x164>  // b.plast
    99a4:	ab0100e1 	adds	x1, x7, x1
    99a8:	d1000569 	sub	x9, x11, #0x1
    99ac:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    99b0:	54000f88 	b.hi	9ba0 <__modti3+0x350>  // b.pmore
    99b4:	aa058123 	orr	x3, x9, x5, lsl #32
    99b8:	92407c4b 	and	x11, x2, #0xffffffff
    99bc:	2a0903e9 	mov	w9, w9
    99c0:	d360fc4a 	lsr	x10, x2, #32
    99c4:	d360fc63 	lsr	x3, x3, #32
    99c8:	cb0c0021 	sub	x1, x1, x12
    99cc:	aa0a03ec 	mov	x12, x10
    99d0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    99d4:	9b0b7d25 	mul	x5, x9, x11
    99d8:	9b0b7c6b 	mul	x11, x3, x11
    99dc:	9b0a2d29 	madd	x9, x9, x10, x11
    99e0:	92407caa 	and	x10, x5, #0xffffffff
    99e4:	9b0c7c63 	mul	x3, x3, x12
    99e8:	8b458125 	add	x5, x9, x5, lsr #32
    99ec:	8b0d0069 	add	x9, x3, x13
    99f0:	eb05017f 	cmp	x11, x5
    99f4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    99f8:	8b058149 	add	x9, x10, x5, lsl #32
    99fc:	8b458063 	add	x3, x3, x5, lsr #32
    9a00:	eb03003f 	cmp	x1, x3
    9a04:	54000063 	b.cc	9a10 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9a08:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    9a0c:	54000082 	b.cs	9a1c <__modti3+0x1cc>  // b.hs, b.nlast
    9a10:	eb020129 	subs	x9, x9, x2
    9a14:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9a18:	cb070063 	sub	x3, x3, x7
    9a1c:	eb090000 	subs	x0, x0, x9
    9a20:	da030021 	sbc	x1, x1, x3
    9a24:	9ac62400 	lsr	x0, x0, x6
    9a28:	9ac82028 	lsl	x8, x1, x8
    9a2c:	aa000100 	orr	x0, x8, x0
    9a30:	9ac62421 	lsr	x1, x1, x6
    9a34:	17ffffb4 	b	9904 <__modti3+0xb4>
    9a38:	b5000062 	cbnz	x2, 9a44 <__modti3+0x1f4>
    9a3c:	d2800023 	mov	x3, #0x1                   	// #1
    9a40:	9ac20862 	udiv	x2, x3, x2
    9a44:	dac01048 	clz	x8, x2
    9a48:	aa0803e5 	mov	x5, x8
    9a4c:	b5000668 	cbnz	x8, 9b18 <__modti3+0x2c8>
    9a50:	cb020020 	sub	x0, x1, x2
    9a54:	d360fc49 	lsr	x9, x2, #32
    9a58:	92407c4a 	and	x10, x2, #0xffffffff
    9a5c:	9ac90801 	udiv	x1, x0, x9
    9a60:	9b098020 	msub	x0, x1, x9, x0
    9a64:	9b0a7c21 	mul	x1, x1, x10
    9a68:	93c78000 	extr	x0, x0, x7, #32
    9a6c:	eb00003f 	cmp	x1, x0
    9a70:	540000a9 	b.ls	9a84 <__modti3+0x234>  // b.plast
    9a74:	ab000040 	adds	x0, x2, x0
    9a78:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9a7c:	8b020003 	add	x3, x0, x2
    9a80:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9a84:	cb010001 	sub	x1, x0, x1
    9a88:	9ac90820 	udiv	x0, x1, x9
    9a8c:	9b098403 	msub	x3, x0, x9, x1
    9a90:	aa0703e1 	mov	x1, x7
    9a94:	9b0a7c00 	mul	x0, x0, x10
    9a98:	b3607c61 	bfi	x1, x3, #32, #32
    9a9c:	eb01001f 	cmp	x0, x1
    9aa0:	540000a9 	b.ls	9ab4 <__modti3+0x264>  // b.plast
    9aa4:	ab010041 	adds	x1, x2, x1
    9aa8:	8b020022 	add	x2, x1, x2
    9aac:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9ab0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9ab4:	cb000020 	sub	x0, x1, x0
    9ab8:	17ffff91 	b	98fc <__modti3+0xac>
    9abc:	eb0203e5 	negs	x5, x2
    9ac0:	aa0003e7 	mov	x7, x0
    9ac4:	da0303e8 	ngc	x8, x3
    9ac8:	aa0503e2 	mov	x2, x5
    9acc:	aa0803e3 	mov	x3, x8
    9ad0:	aa0103e6 	mov	x6, x1
    9ad4:	b4ffed48 	cbz	x8, 987c <__modti3+0x2c>
    9ad8:	eb01011f 	cmp	x8, x1
    9adc:	54fff148 	b.hi	9904 <__modti3+0xb4>  // b.pmore
    9ae0:	dac01109 	clz	x9, x8
    9ae4:	2a0903e6 	mov	w6, w9
    9ae8:	b5fff1c9 	cbnz	x9, 9920 <__modti3+0xd0>
    9aec:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9af0:	54000068 	b.hi	9afc <__modti3+0x2ac>  // b.pmore
    9af4:	eb050007 	subs	x7, x0, x5
    9af8:	da080021 	sbc	x1, x1, x8
    9afc:	aa0703e0 	mov	x0, x7
    9b00:	17ffff81 	b	9904 <__modti3+0xb4>
    9b04:	ab000040 	adds	x0, x2, x0
    9b08:	8b020002 	add	x2, x0, x2
    9b0c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9b10:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9b14:	17ffff79 	b	98f8 <__modti3+0xa8>
    9b18:	9ac82042 	lsl	x2, x2, x8
    9b1c:	d2800803 	mov	x3, #0x40                  	// #64
    9b20:	cb080063 	sub	x3, x3, x8
    9b24:	d360fc49 	lsr	x9, x2, #32
    9b28:	9ac82027 	lsl	x7, x1, x8
    9b2c:	92407c4a 	and	x10, x2, #0xffffffff
    9b30:	9ac32426 	lsr	x6, x1, x3
    9b34:	9ac32403 	lsr	x3, x0, x3
    9b38:	aa070063 	orr	x3, x3, x7
    9b3c:	9ac908c1 	udiv	x1, x6, x9
    9b40:	9ac82007 	lsl	x7, x0, x8
    9b44:	9b099820 	msub	x0, x1, x9, x6
    9b48:	9b017d41 	mul	x1, x10, x1
    9b4c:	93c38000 	extr	x0, x0, x3, #32
    9b50:	eb00003f 	cmp	x1, x0
    9b54:	540000a9 	b.ls	9b68 <__modti3+0x318>  // b.plast
    9b58:	ab000040 	adds	x0, x2, x0
    9b5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9b60:	8b020006 	add	x6, x0, x2
    9b64:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9b68:	cb010000 	sub	x0, x0, x1
    9b6c:	9ac90801 	udiv	x1, x0, x9
    9b70:	9b098026 	msub	x6, x1, x9, x0
    9b74:	aa0303e0 	mov	x0, x3
    9b78:	9b017d41 	mul	x1, x10, x1
    9b7c:	b3607cc0 	bfi	x0, x6, #32, #32
    9b80:	eb00003f 	cmp	x1, x0
    9b84:	540000a9 	b.ls	9b98 <__modti3+0x348>  // b.plast
    9b88:	ab000040 	adds	x0, x2, x0
    9b8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9b90:	8b020003 	add	x3, x0, x2
    9b94:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9b98:	cb010000 	sub	x0, x0, x1
    9b9c:	17ffffb0 	b	9a5c <__modti3+0x20c>
    9ba0:	d1000969 	sub	x9, x11, #0x2
    9ba4:	8b070021 	add	x1, x1, x7
    9ba8:	17ffff83 	b	99b4 <__modti3+0x164>
    9bac:	d1000965 	sub	x5, x11, #0x2
    9bb0:	8b070063 	add	x3, x3, x7
    9bb4:	17ffff74 	b	9984 <__modti3+0x134>
    9bb8:	d503201f 	nop
    9bbc:	d503201f 	nop

0000000000009bc0 <atexit>:
    9bc0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9bc4:	f00000a2 	adrp	x2, 20000 <__data_start>
    9bc8:	d2800001 	mov	x1, #0x0                   	// #0
    9bcc:	910003fd 	mov	x29, sp
    9bd0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9bd4:	f9400442 	ldr	x2, [x2, #8]
    9bd8:	17ffe2f2 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009bdc <_fini>:
    9bdc:	d503201f 	nop
    9be0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9be4:	910003fd 	mov	x29, sp
    9be8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9bec:	d65f03c0 	ret
