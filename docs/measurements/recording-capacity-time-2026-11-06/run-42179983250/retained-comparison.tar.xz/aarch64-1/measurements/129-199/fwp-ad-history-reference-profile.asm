
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	90000065 	adrp	x5, e000 <_IO_stdin_used+0x110>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910f40a5 	add	x5, x5, #0x3d0
    2a20:	90000064 	adrp	x4, e000 <_IO_stdin_used+0x110>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910f6084 	add	x4, x4, #0x3d8
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	94000619 	bl	42b4 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b0000174 	adrp	x20, 2f000 <fwp_fn_table+0xb30>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d0000175 	adrp	x21, 30000 <__data_start>
    2a8c:	910182a1 	add	x1, x21, #0x60
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	90000160 	adrp	x0, 2e000 <__FRAME_END__+0x1dc50>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9008c20 	str	x0, [x1, #280]
    2aac:	94000821 	bl	4b30 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2ab4:	911e6000 	add	x0, x0, #0x798
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000042 	adrp	x2, d000 <f0+0x2460>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91090042 	add	x2, x2, #0x240
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910182b5 	add	x21, x21, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943daa0 	ldr	w0, [x21, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2bcc:	911f2000 	add	x0, x0, #0x7c8
    2bd0:	940005b9 	bl	42b4 <fwp_trap>
    2bd4:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2bd8:	911ea000 	add	x0, x0, #0x7a8
    2bdc:	940005b6 	bl	42b4 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff46 	bl	2900 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffeeb 	bl	27c0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2c20:	91208000 	add	x0, x0, #0x820
    2c24:	940005a4 	bl	42b4 <fwp_trap>
    2c28:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2c2c:	911fc000 	add	x0, x0, #0x7f0
    2c30:	940005a1 	bl	42b4 <fwp_trap>
    2c34:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x110>
    2c38:	91212000 	add	x0, x0, #0x848
    2c3c:	9400059e 	bl	42b4 <fwp_trap>
    2c40:	97fffef4 	bl	2810 <__stack_chk_fail@plt>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d0000160 	adrp	x0, 30000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d0000161 	adrp	x1, 30000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d0000160 	adrp	x0, 30000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d0000161 	adrp	x1, 30000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b0000162 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d0000173 	adrp	x19, 30000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d0000160 	adrp	x0, 30000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x110>
    2e34:	913a0021 	add	x1, x1, #0xe80
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d0000167 	adrp	x7, 30000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d0000164 	adrp	x4, 30000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d0000163 	adrp	x3, 30000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d0000160 	adrp	x0, 30000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b0000162 	adrp	x2, 30000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    30d8:	91398021 	add	x1, x1, #0xe60
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <f0+0x2460>
    3110:	913be000 	add	x0, x0, #0xef8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	90000164 	adrp	x4, 2f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <f0+0x2460>
    331c:	913c4042 	add	x2, x2, #0xf10
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b0000178 	adrp	x24, 30000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	90000176 	adrp	x22, 2f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	d0000042 	adrp	x2, d000 <f0+0x2460>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	913da042 	add	x2, x2, #0xf68
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	d0000059 	adrp	x25, d000 <f0+0x2460>
    33a8:	d000005a 	adrp	x26, d000 <f0+0x2460>
    33ac:	913f2339 	add	x25, x25, #0xfc8
    33b0:	913cc35a 	add	x26, x26, #0xf30
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b0000160 	adrp	x0, 30000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <f0+0x2460>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	913ce377 	add	x23, x27, #0xf38
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	91002000 	add	x0, x0, #0x8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b00001e1 	adrp	x1, 40000 <alt.5+0xfba0>
    3474:	b00001e5 	adrp	x5, 40000 <alt.5+0xfba0>
    3478:	b00001e2 	adrp	x2, 40000 <alt.5+0xfba0>
    347c:	d0000043 	adrp	x3, d000 <f0+0x2460>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	f0000055 	adrp	x21, e000 <_IO_stdin_used+0x110>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	913cc063 	add	x3, x3, #0xf30
    34a0:	910082b5 	add	x21, x21, #0x20
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91018000 	add	x0, x0, #0x60
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <f0+0x2460>
    352c:	913d0000 	add	x0, x0, #0xf40
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <f0+0x2460>
    35ec:	913be000 	add	x0, x0, #0xef8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b0000161 	adrp	x1, 30000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    3730:	aa1303e0 	mov	x0, x19
    3734:	9101a021 	add	x1, x1, #0x68
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    3744:	aa1303e0 	mov	x0, x19
    3748:	9101c021 	add	x1, x1, #0x70
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    3760:	9101e021 	add	x1, x1, #0x78
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_format_g.constprop.0>:
    3780:	d10483ff 	sub	sp, sp, #0x120
    3784:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x110>
    3788:	90000162 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    378c:	f947f442 	ldr	x2, [x2, #4072]
    3790:	91020084 	add	x4, x4, #0x80
    3794:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3798:	9102c3fd 	add	x29, sp, #0xb0
    379c:	d2800803 	mov	x3, #0x40                  	// #64
    37a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37a4:	93407c38 	sxtw	x24, w1
    37a8:	aa0303e1 	mov	x1, x3
    37ac:	fd008be8 	str	d8, [sp, #272]
    37b0:	1e604008 	fmov	d8, d0
    37b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37b8:	910083f4 	add	x20, sp, #0x20
    37bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    37c0:	aa0003f5 	mov	x21, x0
    37c4:	a91073fb 	stp	x27, x28, [sp, #256]
    37c8:	5100071c 	sub	w28, w24, #0x1
    37cc:	2a1c03e5 	mov	w5, w28
    37d0:	f9400040 	ldr	x0, [x2]
    37d4:	f90057e0 	str	x0, [sp, #168]
    37d8:	d2800000 	mov	x0, #0x0                   	// #0
    37dc:	52800042 	mov	w2, #0x2                   	// #2
    37e0:	aa1403e0 	mov	x0, x20
    37e4:	97fffbe7 	bl	2780 <__snprintf_chk@plt>
    37e8:	52800ca1 	mov	w1, #0x65                  	// #101
    37ec:	aa1403e0 	mov	x0, x20
    37f0:	97fffc40 	bl	28f0 <strchr@plt>
    37f4:	aa0003f3 	mov	x19, x0
    37f8:	52800142 	mov	w2, #0xa                   	// #10
    37fc:	91000400 	add	x0, x0, #0x1
    3800:	d2800001 	mov	x1, #0x0                   	// #0
    3804:	97fffc2b 	bl	28b0 <strtol@plt>
    3808:	aa0003f7 	mov	x23, x0
    380c:	11001400 	add	w0, w0, #0x5
    3810:	7100541f 	cmp	w0, #0x15
    3814:	54000d68 	b.hi	39c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3818:	4b170385 	sub	w5, w28, w23
    381c:	710000bf 	cmp	w5, #0x0
    3820:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3824:	54000b80 	b.eq	3994 <fwp_format_g.constprop.0+0x214>  // b.none
    3828:	394083e0 	ldrb	w0, [sp, #32]
    382c:	cb180273 	sub	x19, x19, x24
    3830:	91000673 	add	x19, x19, #0x1
    3834:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3838:	7100b41f 	cmp	w0, #0x2d
    383c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3840:	1a9f17e4 	cset	w4, eq	// eq = none
    3844:	cb010266 	sub	x6, x19, x1
    3848:	d10004da 	sub	x26, x6, #0x1
    384c:	540018a0 	b.eq	3b60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3850:	910183f9 	add	x25, sp, #0x60
    3854:	d280091b 	mov	x27, #0x48                  	// #72
    3858:	aa1903e7 	mov	x7, x25
    385c:	91000423 	add	x3, x1, #0x1
    3860:	91011cc6 	add	x6, x6, #0x47
    3864:	910004f6 	add	x22, x7, #0x1
    3868:	37f80ff7 	tbnz	w23, #31, 3a64 <fwp_format_g.constprop.0+0x2e4>
    386c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3870:	93407ef7 	sxtw	x23, w23
    3874:	390000e4 	strb	w4, [x7]
    3878:	aa1303e1 	mov	x1, x19
    387c:	aa1703e2 	mov	x2, x23
    3880:	aa1603e0 	mov	x0, x22
    3884:	b9000be5 	str	w5, [sp, #8]
    3888:	cb170374 	sub	x20, x27, x23
    388c:	a9011be3 	stp	x3, x6, [sp, #16]
    3890:	97fffb74 	bl	2660 <memcpy@plt>
    3894:	d1000694 	sub	x20, x20, #0x1
    3898:	f9400be3 	ldr	x3, [sp, #16]
    389c:	8b1702d6 	add	x22, x22, x23
    38a0:	aa1603e0 	mov	x0, x22
    38a4:	aa1a03e2 	mov	x2, x26
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	aa1403e3 	mov	x3, x20
    38b0:	97fffbac 	bl	2760 <__memcpy_chk@plt>
    38b4:	8b1a02d6 	add	x22, x22, x26
    38b8:	f9400fe6 	ldr	x6, [sp, #24]
    38bc:	d2800900 	mov	x0, #0x48                  	// #72
    38c0:	b9400be5 	ldr	w5, [sp, #8]
    38c4:	8b170261 	add	x1, x19, x23
    38c8:	cb1400c3 	sub	x3, x6, x20
    38cc:	cb060294 	sub	x20, x20, x6
    38d0:	f101207f 	cmp	x3, #0x48
    38d4:	93407cb8 	sxtw	x24, w5
    38d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38dc:	aa1803e2 	mov	x2, x24
    38e0:	8b1802d3 	add	x19, x22, x24
    38e4:	8b140063 	add	x3, x3, x20
    38e8:	aa1603e0 	mov	x0, x22
    38ec:	97fffb9d 	bl	2760 <__memcpy_chk@plt>
    38f0:	cb190273 	sub	x19, x19, x25
    38f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    38f8:	eb00027f 	cmp	x19, x0
    38fc:	aa1903e1 	mov	x1, x25
    3900:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3904:	aa1503e0 	mov	x0, x21
    3908:	aa1303e2 	mov	x2, x19
    390c:	97fffb55 	bl	2660 <memcpy@plt>
    3910:	38336abf 	strb	wzr, [x21, x19]
    3914:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3918:	aa1503e0 	mov	x0, x21
    391c:	97fffb61 	bl	26a0 <strlen@plt>
    3920:	aa0003f3 	mov	x19, x0
    3924:	528005c1 	mov	w1, #0x2e                  	// #46
    3928:	aa1503e0 	mov	x0, x21
    392c:	97fffbf1 	bl	28f0 <strchr@plt>
    3930:	b4000140 	cbz	x0, 3958 <fwp_format_g.constprop.0+0x1d8>
    3934:	b4000133 	cbz	x19, 3958 <fwp_format_g.constprop.0+0x1d8>
    3938:	aa1303e1 	mov	x1, x19
    393c:	d1000673 	sub	x19, x19, #0x1
    3940:	38736aa0 	ldrb	w0, [x21, x19]
    3944:	7100c01f 	cmp	w0, #0x30
    3948:	54001001 	b.ne	3b48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    394c:	38336abf 	strb	wzr, [x21, x19]
    3950:	b5ffff53 	cbnz	x19, 3938 <fwp_format_g.constprop.0+0x1b8>
    3954:	d503201f 	nop
    3958:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    395c:	f947f400 	ldr	x0, [x0, #4072]
    3960:	f94057e2 	ldr	x2, [sp, #168]
    3964:	f9400001 	ldr	x1, [x0]
    3968:	eb010042 	subs	x2, x2, x1
    396c:	d2800001 	mov	x1, #0x0                   	// #0
    3970:	54001061 	b.ne	3b7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3974:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3978:	a94c53f3 	ldp	x19, x20, [sp, #192]
    397c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3980:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3984:	a95073fb 	ldp	x27, x28, [sp, #256]
    3988:	fd408be8 	ldr	d8, [sp, #272]
    398c:	910483ff 	add	sp, sp, #0x120
    3990:	d65f03c0 	ret
    3994:	1e604100 	fmov	d0, d8
    3998:	710000bf 	cmp	w5, #0x0
    399c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39a0:	aa1503e0 	mov	x0, x21
    39a4:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x110>
    39a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ac:	91026084 	add	x4, x4, #0x98
    39b0:	52800042 	mov	w2, #0x2                   	// #2
    39b4:	d2803201 	mov	x1, #0x190                 	// #400
    39b8:	97fffb72 	bl	2780 <__snprintf_chk@plt>
    39bc:	17ffffd7 	b	3918 <fwp_format_g.constprop.0+0x198>
    39c0:	cb140273 	sub	x19, x19, x20
    39c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39c8:	910183f9 	add	x25, sp, #0x60
    39cc:	aa1303e2 	mov	x2, x19
    39d0:	aa1403e1 	mov	x1, x20
    39d4:	aa1903e0 	mov	x0, x25
    39d8:	d2800803 	mov	x3, #0x40                  	// #64
    39dc:	97fffb61 	bl	2760 <__memcpy_chk@plt>
    39e0:	38336b3f 	strb	wzr, [x25, x19]
    39e4:	aa1903e0 	mov	x0, x25
    39e8:	528005c1 	mov	w1, #0x2e                  	// #46
    39ec:	97fffbc1 	bl	28f0 <strchr@plt>
    39f0:	b40001c0 	cbz	x0, 3a28 <fwp_format_g.constprop.0+0x2a8>
    39f4:	b50000b3 	cbnz	x19, 3a08 <fwp_format_g.constprop.0+0x288>
    39f8:	1400000c 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    39fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3a00:	f1000673 	subs	x19, x19, #0x1
    3a04:	54000120 	b.eq	3a28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a08:	8b130320 	add	x0, x25, x19
    3a0c:	385ff001 	ldurb	w1, [x0, #-1]
    3a10:	7100c03f 	cmp	w1, #0x30
    3a14:	54ffff40 	b.eq	39fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3a18:	d1000673 	sub	x19, x19, #0x1
    3a1c:	38736b20 	ldrb	w0, [x25, x19]
    3a20:	7100b81f 	cmp	w0, #0x2e
    3a24:	54000a80 	b.eq	3b74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a28:	710002ff 	cmp	w23, #0x0
    3a2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a30:	aa1903e5 	mov	x5, x25
    3a34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a38:	aa1503e0 	mov	x0, x21
    3a3c:	52800566 	mov	w6, #0x2b                  	// #43
    3a40:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x110>
    3a44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a48:	91022084 	add	x4, x4, #0x88
    3a4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a50:	52800042 	mov	w2, #0x2                   	// #2
    3a54:	d2803201 	mov	x1, #0x190                 	// #400
    3a58:	97fffb4a 	bl	2780 <__snprintf_chk@plt>
    3a5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a60:	17ffffbe 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3a64:	52800605 	mov	w5, #0x30                  	// #48
    3a68:	390000e5 	strb	w5, [x7]
    3a6c:	d100077b 	sub	x27, x27, #0x1
    3a70:	aa0303e1 	mov	x1, x3
    3a74:	aa1603e0 	mov	x0, x22
    3a78:	aa1b03e3 	mov	x3, x27
    3a7c:	aa1a03e2 	mov	x2, x26
    3a80:	f90007e6 	str	x6, [sp, #8]
    3a84:	b90013e4 	str	w4, [sp, #16]
    3a88:	8b1a02d6 	add	x22, x22, x26
    3a8c:	b9001be5 	str	w5, [sp, #24]
    3a90:	97fffb34 	bl	2760 <__memcpy_chk@plt>
    3a94:	f94007e6 	ldr	x6, [sp, #8]
    3a98:	2a3703e7 	mvn	w7, w23
    3a9c:	b94013e4 	ldr	w4, [sp, #16]
    3aa0:	cb1b00c1 	sub	x1, x6, x27
    3aa4:	cb06037b 	sub	x27, x27, x6
    3aa8:	f101203f 	cmp	x1, #0x48
    3aac:	d2800906 	mov	x6, #0x48                  	// #72
    3ab0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ab4:	8b1b0023 	add	x3, x1, x27
    3ab8:	310006ff 	cmn	w23, #0x1
    3abc:	54000220 	b.eq	3b00 <fwp_format_g.constprop.0+0x380>  // b.none
    3ac0:	b9401be5 	ldr	w5, [sp, #24]
    3ac4:	d2800001 	mov	x1, #0x0                   	// #0
    3ac8:	f101207f 	cmp	x3, #0x48
    3acc:	d1000462 	sub	x2, x3, #0x1
    3ad0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3ad4:	38216ac5 	strb	w5, [x22, x1]
    3ad8:	cb030003 	sub	x3, x0, x3
    3adc:	91000421 	add	x1, x1, #0x1
    3ae0:	91000463 	add	x3, x3, #0x1
    3ae4:	eb00007f 	cmp	x3, x0
    3ae8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3aec:	cb000063 	sub	x3, x3, x0
    3af0:	8b020063 	add	x3, x3, x2
    3af4:	6b0100ff 	cmp	w7, w1
    3af8:	54fffe8c 	b.gt	3ac8 <fwp_format_g.constprop.0+0x348>
    3afc:	8b2742d6 	add	x22, x22, w7, uxtw
    3b00:	f101207f 	cmp	x3, #0x48
    3b04:	d2800905 	mov	x5, #0x48                  	// #72
    3b08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b0c:	aa1603e0 	mov	x0, x22
    3b10:	cb0300a1 	sub	x1, x5, x3
    3b14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b18:	91000421 	add	x1, x1, #0x1
    3b1c:	d1000463 	sub	x3, x3, #0x1
    3b20:	eb05003f 	cmp	x1, x5
    3b24:	38001402 	strb	w2, [x0], #1
    3b28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b2c:	93407f82 	sxtw	x2, w28
    3b30:	cb050025 	sub	x5, x1, x5
    3b34:	aa1303e1 	mov	x1, x19
    3b38:	8b0300a3 	add	x3, x5, x3
    3b3c:	8b1802d3 	add	x19, x22, x24
    3b40:	97fffb08 	bl	2760 <__memcpy_chk@plt>
    3b44:	17ffff6b 	b	38f0 <fwp_format_g.constprop.0+0x170>
    3b48:	d1000421 	sub	x1, x1, #0x1
    3b4c:	38616aa0 	ldrb	w0, [x21, x1]
    3b50:	7100b81f 	cmp	w0, #0x2e
    3b54:	54fff021 	b.ne	3958 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b58:	38216abf 	strb	wzr, [x21, x1]
    3b5c:	17ffff7f 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3b60:	910187e7 	add	x7, sp, #0x61
    3b64:	910183f9 	add	x25, sp, #0x60
    3b68:	d28008fb 	mov	x27, #0x47                  	// #71
    3b6c:	390183e0 	strb	w0, [sp, #96]
    3b70:	17ffff3b 	b	385c <fwp_format_g.constprop.0+0xdc>
    3b74:	38336b3f 	strb	wzr, [x25, x19]
    3b78:	17ffffac 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    3b7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b80:	97fffb24 	bl	2810 <__stack_chk_fail@plt>

0000000000003b84 <fwp_heap_report>:
    3b84:	d105c3ff 	sub	sp, sp, #0x170
    3b88:	d0000422 	adrp	x2, 89000 <fwp_root_context+0xba0>
    3b8c:	91190042 	add	x2, x2, #0x640
    3b90:	90000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    3b94:	f947e821 	ldr	x1, [x1, #4048]
    3b98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3b9c:	910443fd 	add	x29, sp, #0x110
    3ba0:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3ba4:	f947f400 	ldr	x0, [x0, #4072]
    3ba8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bac:	a91463f7 	stp	x23, x24, [sp, #320]
    3bb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3bc0:	f9400036 	ldr	x22, [x1]
    3bc4:	f9400001 	ldr	x1, [x0]
    3bc8:	f90087e1 	str	x1, [sp, #264]
    3bcc:	d2800001 	mov	x1, #0x0                   	// #0
    3bd0:	f949e459 	ldr	x25, [x2, #5064]
    3bd4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    3bd8:	f94a1057 	ldr	x23, [x2, #5152]
    3bdc:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    3be0:	f94a1458 	ldr	x24, [x2, #5160]
    3be4:	91028021 	add	x1, x1, #0xa0
    3be8:	9102a000 	add	x0, x0, #0xa8
    3bec:	97fffaed 	bl	27a0 <fopen@plt>
    3bf0:	b4000760 	cbz	x0, 3cdc <fwp_heap_report+0x158>
    3bf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3bf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3bfc:	aa0003f4 	mov	x20, x0
    3c00:	910023f3 	add	x19, sp, #0x8
    3c04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c08:	72aae915 	movk	w21, #0x5748, lsl #16
    3c0c:	d503201f 	nop
    3c10:	aa1403e2 	mov	x2, x20
    3c14:	aa1303e0 	mov	x0, x19
    3c18:	52802001 	mov	w1, #0x100                 	// #256
    3c1c:	97fffb69 	bl	29c0 <fgets@plt>
    3c20:	b4000280 	cbz	x0, 3c70 <fwp_heap_report+0xec>
    3c24:	b9400261 	ldr	w1, [x19]
    3c28:	6b15003f 	cmp	w1, w21
    3c2c:	54ffff21 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c30:	39401260 	ldrb	w0, [x19, #4]
    3c34:	7101341f 	cmp	w0, #0x4d
    3c38:	54fffec1 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c3c:	394037e0 	ldrb	w0, [sp, #13]
    3c40:	7100e81f 	cmp	w0, #0x3a
    3c44:	54fffe61 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c48:	52800142 	mov	w2, #0xa                   	// #10
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	91003be0 	add	x0, sp, #0xe
    3c54:	97fffb17 	bl	28b0 <strtol@plt>
    3c58:	aa1403e2 	mov	x2, x20
    3c5c:	aa0003fa 	mov	x26, x0
    3c60:	52802001 	mov	w1, #0x100                 	// #256
    3c64:	aa1303e0 	mov	x0, x19
    3c68:	97fffb56 	bl	29c0 <fgets@plt>
    3c6c:	b5fffdc0 	cbnz	x0, 3c24 <fwp_heap_report+0xa0>
    3c70:	aa1403e0 	mov	x0, x20
    3c74:	97fffac7 	bl	2790 <fclose@plt>
    3c78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3c7c:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3c80:	f947f400 	ldr	x0, [x0, #4072]
    3c84:	f94087e2 	ldr	x2, [sp, #264]
    3c88:	f9400001 	ldr	x1, [x0]
    3c8c:	eb010042 	subs	x2, x2, x1
    3c90:	d2800001 	mov	x1, #0x0                   	// #0
    3c94:	54000281 	b.ne	3ce4 <fwp_heap_report+0x160>  // b.any
    3c98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3c9c:	aa1a03e6 	mov	x6, x26
    3ca0:	aa1903e5 	mov	x5, x25
    3ca4:	aa1803e4 	mov	x4, x24
    3ca8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cac:	aa1703e3 	mov	x3, x23
    3cb0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cbc:	1e604121 	fmov	d1, d9
    3cc0:	1e604100 	fmov	d0, d8
    3cc4:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x110>
    3cc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3ccc:	91032042 	add	x2, x2, #0xc8
    3cd0:	9105c3ff 	add	sp, sp, #0x170
    3cd4:	52800041 	mov	w1, #0x2                   	// #2
    3cd8:	17fffaea 	b	2880 <__fprintf_chk@plt>
    3cdc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ce0:	17ffffe7 	b	3c7c <fwp_heap_report+0xf8>
    3ce4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ce8:	97fffaca 	bl	2810 <__stack_chk_fail@plt>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_heap_init>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	f0000423 	adrp	x3, 8a000 <fwp_heap+0x9c0>
    3cf8:	91150061 	add	x1, x3, #0x540
    3cfc:	910003fd 	mov	x29, sp
    3d00:	a90153f3 	stp	x19, x20, [sp, #16]
    3d04:	d0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    3d08:	91190262 	add	x2, x19, #0x640
    3d0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d10:	52800024 	mov	w4, #0x1                   	// #1
    3d14:	52800200 	mov	w0, #0x10                  	// #16
    3d18:	b913a444 	str	w4, [x2, #5028]
    3d1c:	d503201f 	nop
    3d20:	b8004420 	str	w0, [x1], #4
    3d24:	11004000 	add	w0, w0, #0x10
    3d28:	7104401f 	cmp	w0, #0x110
    3d2c:	54ffffa1 	b.ne	3d20 <fwp_heap_init+0x30>  // b.any
    3d30:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x110>
    3d34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d38:	f0000421 	adrp	x1, 8a000 <fwp_heap+0x9c0>
    3d3c:	91160021 	add	x1, x1, #0x580
    3d40:	3dc3a443 	ldr	q3, [x2, #3728]
    3d44:	d2800000 	mov	x0, #0x0                   	// #0
    3d48:	4e040401 	dup	v1.4s, v0.s[0]
    3d4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d50:	0f215400 	shl	v0.2s, v0.2s, #1
    3d54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d58:	3ca06821 	str	q1, [x1, x0]
    3d5c:	91004000 	add	x0, x0, #0x10
    3d60:	f101801f 	cmp	x0, #0x60
    3d64:	54ffff21 	b.ne	3d48 <fwp_heap_init+0x58>  // b.any
    3d68:	f0000424 	adrp	x4, 8a000 <fwp_heap+0x9c0>
    3d6c:	91150063 	add	x3, x3, #0x540
    3d70:	91178084 	add	x4, x4, #0x5e0
    3d74:	91190266 	add	x6, x19, #0x640
    3d78:	d2800002 	mov	x2, #0x0                   	// #0
    3d7c:	d2800000 	mov	x0, #0x0                   	// #0
    3d80:	d2880205 	mov	x5, #0x4010                	// #16400
    3d84:	d503201f 	nop
    3d88:	910f0001 	add	x1, x0, #0x3c0
    3d8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3d90:	eb02003f 	cmp	x1, x2
    3d94:	540000a2 	b.cs	3da8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3d98:	91000400 	add	x0, x0, #0x1
    3d9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3da0:	eb02003f 	cmp	x1, x2
    3da4:	54ffffa3 	b.cc	3d98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3da8:	91004042 	add	x2, x2, #0x10
    3dac:	38001480 	strb	w0, [x4], #1
    3db0:	eb05005f 	cmp	x2, x5
    3db4:	54fffea1 	b.ne	3d88 <fwp_heap_init+0x98>  // b.any
    3db8:	528000b5 	mov	w21, #0x5                   	// #5
    3dbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3dc0:	14000004 	b	3dd0 <fwp_heap_init+0xe0>
    3dc4:	d342fe94 	lsr	x20, x20, #2
    3dc8:	710006b5 	subs	w21, w21, #0x1
    3dcc:	54000720 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3dd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3dd4:	d2800005 	mov	x5, #0x0                   	// #0
    3dd8:	aa1603e1 	mov	x1, x22
    3ddc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3de0:	52880443 	mov	w3, #0x4022                	// #16418
    3de4:	52800002 	mov	w2, #0x0                   	// #0
    3de8:	d2800000 	mov	x0, #0x0                   	// #0
    3dec:	97fffaad 	bl	28a0 <mmap@plt>
    3df0:	aa0003e6 	mov	x6, x0
    3df4:	b100041f 	cmn	x0, #0x1
    3df8:	54fffe60 	b.eq	3dc4 <fwp_heap_init+0xd4>  // b.none
    3dfc:	b40005a0 	cbz	x0, 3eb0 <fwp_heap_init+0x1c0>
    3e00:	d350fe94 	lsr	x20, x20, #16
    3e04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e08:	8b0000c7 	add	x7, x6, x0
    3e0c:	91190275 	add	x21, x19, #0x640
    3e10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e14:	8b140a81 	add	x1, x20, x20, lsl #2
    3e18:	d2800005 	mov	x5, #0x0                   	// #0
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	d37df021 	lsl	x1, x1, #3
    3e24:	52880443 	mov	w3, #0x4022                	// #16418
    3e28:	52800002 	mov	w2, #0x0                   	// #0
    3e2c:	d2800000 	mov	x0, #0x0                   	// #0
    3e30:	f909daa7 	str	x7, [x21, #5040]
    3e34:	f909dea6 	str	x6, [x21, #5048]
    3e38:	f909e2b6 	str	x22, [x21, #5056]
    3e3c:	f909eab4 	str	x20, [x21, #5072]
    3e40:	f90a02a1 	str	x1, [x21, #5120]
    3e44:	97fffa97 	bl	28a0 <mmap@plt>
    3e48:	aa0003e1 	mov	x1, x0
    3e4c:	b100041f 	cmn	x0, #0x1
    3e50:	54000300 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3e54:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    3e58:	91054000 	add	x0, x0, #0x150
    3e5c:	f909fea1 	str	x1, [x21, #5112]
    3e60:	97fffad0 	bl	29a0 <getenv@plt>
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	aa0003e1 	mov	x1, x0
    3e6c:	b40000e0 	cbz	x0, 3e88 <fwp_heap_init+0x198>
    3e70:	39400000 	ldrb	w0, [x0]
    3e74:	340000a0 	cbz	w0, 3e88 <fwp_heap_init+0x198>
    3e78:	7100c000 	subs	w0, w0, #0x30
    3e7c:	54000120 	b.eq	3ea0 <fwp_heap_init+0x1b0>  // b.none
    3e80:	7100001f 	cmp	w0, #0x0
    3e84:	1a9f07e2 	cset	w2, ne	// ne = any
    3e88:	91190273 	add	x19, x19, #0x640
    3e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e90:	b913aa62 	str	w2, [x19, #5032]
    3e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e9c:	d65f03c0 	ret
    3ea0:	39400420 	ldrb	w0, [x1, #1]
    3ea4:	7100001f 	cmp	w0, #0x0
    3ea8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eac:	17fffff7 	b	3e88 <fwp_heap_init+0x198>
    3eb0:	97fffc90 	bl	30f0 <fwp_heap_oom>

0000000000003eb4 <fwp_wake_io>:
    3eb4:	b0000169 	adrp	x9, 30000 <__data_start>
    3eb8:	91018122 	add	x2, x9, #0x60
    3ebc:	f9400001 	ldr	x1, [x0]
    3ec0:	5280000a 	mov	w10, #0x0                   	// #0
    3ec4:	f9406046 	ldr	x6, [x2, #192]
    3ec8:	52800008 	mov	w8, #0x0                   	// #0
    3ecc:	4f000400 	movi	v0.4s, #0x0
    3ed0:	52800027 	mov	w7, #0x1                   	// #1
    3ed4:	aa0103e2 	mov	x2, x1
    3ed8:	b4000321 	cbz	x1, 3f3c <fwp_wake_io+0x88>
    3edc:	f9408c25 	ldr	x5, [x1, #280]
    3ee0:	39015c27 	strb	w7, [x1, #87]
    3ee4:	b4000165 	cbz	x5, 3f10 <fwp_wake_io+0x5c>
    3ee8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3eec:	b4000364 	cbz	x4, 3f58 <fwp_wake_io+0xa4>
    3ef0:	f9009483 	str	x3, [x4, #296]
    3ef4:	f9409423 	ldr	x3, [x1, #296]
    3ef8:	b4000043 	cbz	x3, 3f00 <fwp_wake_io+0x4c>
    3efc:	f9009064 	str	x4, [x3, #288]
    3f00:	91080023 	add	x3, x1, #0x200
    3f04:	f900943f 	str	xzr, [x1, #296]
    3f08:	3c918060 	stur	q0, [x3, #-232]
    3f0c:	f9400001 	ldr	x1, [x0]
    3f10:	f9402843 	ldr	x3, [x2, #80]
    3f14:	f2001c7f 	tst	x3, #0xff000000ff
    3f18:	54fffde1 	b.ne	3ed4 <fwp_wake_io+0x20>  // b.any
    3f1c:	39015047 	strb	w7, [x2, #84]
    3f20:	f900805f 	str	xzr, [x2, #256]
    3f24:	b40001e6 	cbz	x6, 3f60 <fwp_wake_io+0xac>
    3f28:	f90080c2 	str	x2, [x6, #256]
    3f2c:	aa0203e6 	mov	x6, x2
    3f30:	52800028 	mov	w8, #0x1                   	// #1
    3f34:	aa0103e2 	mov	x2, x1
    3f38:	b5fffd21 	cbnz	x1, 3edc <fwp_wake_io+0x28>
    3f3c:	3400006a 	cbz	w10, 3f48 <fwp_wake_io+0x94>
    3f40:	91018120 	add	x0, x9, #0x60
    3f44:	f900640b 	str	x11, [x0, #200]
    3f48:	34000068 	cbz	w8, 3f54 <fwp_wake_io+0xa0>
    3f4c:	91018129 	add	x9, x9, #0x60
    3f50:	f9006126 	str	x6, [x9, #192]
    3f54:	d65f03c0 	ret
    3f58:	f90000a3 	str	x3, [x5]
    3f5c:	17ffffe7 	b	3ef8 <fwp_wake_io+0x44>
    3f60:	aa0203eb 	mov	x11, x2
    3f64:	5280002a 	mov	w10, #0x1                   	// #1
    3f68:	17fffff1 	b	3f2c <fwp_wake_io+0x78>
    3f6c:	d503201f 	nop

0000000000003f70 <ad_raw_free.part.0>:
    3f70:	b0000364 	adrp	x4, 70000 <ad_raw_checkpoints+0x2fba0>
    3f74:	d2800001 	mov	x1, #0x0                   	// #0
    3f78:	91118082 	add	x2, x4, #0x460
    3f7c:	14000005 	b	3f90 <ad_raw_free.part.0+0x20>
    3f80:	91000421 	add	x1, x1, #0x1
    3f84:	91006042 	add	x2, x2, #0x18
    3f88:	f140043f 	cmp	x1, #0x1, lsl #12
    3f8c:	54000220 	b.eq	3fd0 <ad_raw_free.part.0+0x60>  // b.none
    3f90:	f9400043 	ldr	x3, [x2]
    3f94:	eb03001f 	cmp	x0, x3
    3f98:	54ffff41 	b.ne	3f80 <ad_raw_free.part.0+0x10>  // b.any
    3f9c:	8b010421 	add	x1, x1, x1, lsl #1
    3fa0:	91118084 	add	x4, x4, #0x460
    3fa4:	b0000162 	adrp	x2, 30000 <__data_start>
    3fa8:	91018042 	add	x2, x2, #0x60
    3fac:	8b010c81 	add	x1, x4, x1, lsl #3
    3fb0:	b9401024 	ldr	w4, [x1, #16]
    3fb4:	f9400425 	ldr	x5, [x1, #8]
    3fb8:	a9007c3f 	stp	xzr, xzr, [x1]
    3fbc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    3fc0:	f900083f 	str	xzr, [x1, #16]
    3fc4:	cb050061 	sub	x1, x3, x5
    3fc8:	f8247841 	str	x1, [x2, x4, lsl #3]
    3fcc:	17fffa41 	b	28d0 <free@plt>
    3fd0:	f100001f 	cmp	x0, #0x0
    3fd4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    3fd8:	9105e021 	add	x1, x1, #0x178
    3fdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3fe0:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    3fe4:	91058000 	add	x0, x0, #0x160
    3fe8:	910003fd 	mov	x29, sp
    3fec:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    3ff0:	97fffcc4 	bl	3300 <ad_raw_fail>

0000000000003ff4 <fwp_tape_buffers_dispose>:
    3ff4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ff8:	910003fd 	mov	x29, sp
    3ffc:	f9000bf3 	str	x19, [sp, #16]
    4000:	aa0003f3 	mov	x19, x0
    4004:	f9400000 	ldr	x0, [x0]
    4008:	b4000040 	cbz	x0, 4010 <fwp_tape_buffers_dispose+0x1c>
    400c:	97ffffd9 	bl	3f70 <ad_raw_free.part.0>
    4010:	f9400a60 	ldr	x0, [x19, #16]
    4014:	b4000040 	cbz	x0, 401c <fwp_tape_buffers_dispose+0x28>
    4018:	97ffffd6 	bl	3f70 <ad_raw_free.part.0>
    401c:	f9401260 	ldr	x0, [x19, #32]
    4020:	b4000040 	cbz	x0, 4028 <fwp_tape_buffers_dispose+0x34>
    4024:	97ffffd3 	bl	3f70 <ad_raw_free.part.0>
    4028:	4f000400 	movi	v0.4s, #0x0
    402c:	f9001a7f 	str	xzr, [x19, #48]
    4030:	ad000260 	stp	q0, q0, [x19]
    4034:	3d800a60 	str	q0, [x19, #32]
    4038:	f9400bf3 	ldr	x19, [sp, #16]
    403c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4040:	d65f03c0 	ret

0000000000004044 <ad_raw_realloc>:
    4044:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4048:	910003fd 	mov	x29, sp
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	f90013f5 	str	x21, [sp, #32]
    4054:	b40005a1 	cbz	x1, 4108 <ad_raw_realloc+0xc4>
    4058:	aa0103f4 	mov	x20, x1
    405c:	2a0203f5 	mov	w21, w2
    4060:	90000361 	adrp	x1, 70000 <ad_raw_checkpoints+0x2fba0>
    4064:	d2800004 	mov	x4, #0x0                   	// #0
    4068:	91118025 	add	x5, x1, #0x460
    406c:	14000005 	b	4080 <ad_raw_realloc+0x3c>
    4070:	91000484 	add	x4, x4, #0x1
    4074:	910060a5 	add	x5, x5, #0x18
    4078:	f140049f 	cmp	x4, #0x1, lsl #12
    407c:	54000320 	b.eq	40e0 <ad_raw_realloc+0x9c>  // b.none
    4080:	f94000a6 	ldr	x6, [x5]
    4084:	eb06001f 	cmp	x0, x6
    4088:	54ffff41 	b.ne	4070 <ad_raw_realloc+0x2c>  // b.any
    408c:	8b040484 	add	x4, x4, x4, lsl #1
    4090:	91118021 	add	x1, x1, #0x460
    4094:	8b040c33 	add	x19, x1, x4, lsl #3
    4098:	b4000080 	cbz	x0, 40a8 <ad_raw_realloc+0x64>
    409c:	b9401261 	ldr	w1, [x19, #16]
    40a0:	6b15003f 	cmp	w1, w21
    40a4:	540002c1 	b.ne	40fc <ad_raw_realloc+0xb8>  // b.any
    40a8:	aa1403e1 	mov	x1, x20
    40ac:	97fff9d5 	bl	2800 <realloc@plt>
    40b0:	aa0003ed 	mov	x13, x0
    40b4:	b40000c0 	cbz	x0, 40cc <ad_raw_realloc+0x88>
    40b8:	2a1503e3 	mov	w3, w21
    40bc:	aa1403e2 	mov	x2, x20
    40c0:	aa1303e0 	mov	x0, x19
    40c4:	aa0d03e1 	mov	x1, x13
    40c8:	97fffb92 	bl	2f10 <ad_raw_record>
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	aa0d03e0 	mov	x0, x13
    40d4:	f94013f5 	ldr	x21, [sp, #32]
    40d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40dc:	d65f03c0 	ret
    40e0:	f100001f 	cmp	x0, #0x0
    40e4:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    40e8:	9105e021 	add	x1, x1, #0x178
    40ec:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    40f0:	91058000 	add	x0, x0, #0x160
    40f4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    40f8:	97fffc82 	bl	3300 <ad_raw_fail>
    40fc:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4100:	9106e000 	add	x0, x0, #0x1b8
    4104:	97fffc7f 	bl	3300 <ad_raw_fail>
    4108:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    410c:	91066000 	add	x0, x0, #0x198
    4110:	97fffc7c 	bl	3300 <ad_raw_fail>

0000000000004114 <fwp_tape_buffers_release>:
    4114:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4118:	910003fd 	mov	x29, sp
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f4 	mov	x20, x0
    4124:	f9401400 	ldr	x0, [x0, #40]
    4128:	a9025bf5 	stp	x21, x22, [sp, #32]
    412c:	b7f80560 	tbnz	x0, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4130:	f9401a93 	ldr	x19, [x20, #48]
    4134:	b7f80533 	tbnz	x19, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4138:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    413c:	eb01001f 	cmp	x0, x1
    4140:	540004c8 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4144:	8b000400 	add	x0, x0, x0, lsl #1
    4148:	d2a00101 	mov	x1, #0x80000               	// #524288
    414c:	d37df000 	lsl	x0, x0, #3
    4150:	cb000021 	sub	x1, x1, x0
    4154:	eb410e7f 	cmp	x19, x1, lsr #3
    4158:	54000408 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    415c:	8b130c13 	add	x19, x0, x19, lsl #3
    4160:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4164:	91074000 	add	x0, x0, #0x1d0
    4168:	97fffa0e 	bl	29a0 <getenv@plt>
    416c:	b4000080 	cbz	x0, 417c <fwp_tape_buffers_release+0x68>
    4170:	39400001 	ldrb	w1, [x0]
    4174:	7100c03f 	cmp	w1, #0x30
    4178:	54000880 	b.eq	4288 <fwp_tape_buffers_release+0x174>  // b.none
    417c:	d1000661 	sub	x1, x19, #0x1
    4180:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4184:	eb00003f 	cmp	x1, x0
    4188:	54000328 	b.hi	41ec <fwp_tape_buffers_release+0xd8>  // b.pmore
    418c:	90000175 	adrp	x21, 30000 <__data_start>
    4190:	f9001bf7 	str	x23, [sp, #48]
    4194:	910182b7 	add	x23, x21, #0x60
    4198:	910342f6 	add	x22, x23, #0xd0
    419c:	aa1603e0 	mov	x0, x22
    41a0:	97ffff95 	bl	3ff4 <fwp_tape_buffers_dispose>
    41a4:	ad400a81 	ldp	q1, q2, [x20]
    41a8:	f90086f3 	str	x19, [x23, #264]
    41ac:	4f000400 	movi	v0.4s, #0x0
    41b0:	ad000ac1 	stp	q1, q2, [x22]
    41b4:	3dc00a81 	ldr	q1, [x20, #32]
    41b8:	3d800ac1 	str	q1, [x22, #32]
    41bc:	f9401a80 	ldr	x0, [x20, #48]
    41c0:	f9001ac0 	str	x0, [x22, #48]
    41c4:	f9001a9f 	str	xzr, [x20, #48]
    41c8:	ad000280 	stp	q0, q0, [x20]
    41cc:	3d800a80 	str	q0, [x20, #32]
    41d0:	f9401bf7 	ldr	x23, [sp, #48]
    41d4:	1400000b 	b	4200 <fwp_tape_buffers_release+0xec>
    41d8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    41dc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    41e0:	91074000 	add	x0, x0, #0x1d0
    41e4:	97fff9ef 	bl	29a0 <getenv@plt>
    41e8:	b5fffc40 	cbnz	x0, 4170 <fwp_tape_buffers_release+0x5c>
    41ec:	aa1403e0 	mov	x0, x20
    41f0:	97ffff81 	bl	3ff4 <fwp_tape_buffers_dispose>
    41f4:	90000175 	adrp	x21, 30000 <__data_start>
    41f8:	910182a0 	add	x0, x21, #0x60
    41fc:	f9408413 	ldr	x19, [x0, #264]
    4200:	910182a2 	add	x2, x21, #0x60
    4204:	f9408844 	ldr	x4, [x2, #272]
    4208:	a9400c45 	ldp	x5, x3, [x2]
    420c:	8b040481 	add	x1, x4, x4, lsl #1
    4210:	f9400840 	ldr	x0, [x2, #16]
    4214:	8b010881 	add	x1, x4, x1, lsl #2
    4218:	f9400c44 	ldr	x4, [x2, #24]
    421c:	8b0300a3 	add	x3, x5, x3
    4220:	d37df021 	lsl	x1, x1, #3
    4224:	8b040000 	add	x0, x0, x4
    4228:	8b030000 	add	x0, x0, x3
    422c:	eb05003f 	cmp	x1, x5
    4230:	54000321 	b.ne	4294 <fwp_tape_buffers_release+0x180>  // b.any
    4234:	8b130023 	add	x3, x1, x19
    4238:	eb00007f 	cmp	x3, x0
    423c:	540002c8 	b.hi	4294 <fwp_tape_buffers_release+0x180>  // b.pmore
    4240:	f9405c43 	ldr	x3, [x2, #184]
    4244:	f140087f 	cmp	x3, #0x2, lsl #12
    4248:	540002e0 	b.eq	42a4 <fwp_tape_buffers_release+0x190>  // b.none
    424c:	8b030464 	add	x4, x3, x3, lsl #1
    4250:	900001e5 	adrp	x5, 40000 <alt.5+0xfba0>
    4254:	911180a5 	add	x5, x5, #0x460
    4258:	cb010000 	sub	x0, x0, x1
    425c:	d37df084 	lsl	x4, x4, #3
    4260:	cb130000 	sub	x0, x0, x19
    4264:	8b0400a6 	add	x6, x5, x4
    4268:	91000463 	add	x3, x3, #0x1
    426c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4270:	f82468a1 	str	x1, [x5, x4]
    4274:	a90080d3 	stp	x19, x0, [x6, #8]
    4278:	f9005c43 	str	x3, [x2, #184]
    427c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4280:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4284:	d65f03c0 	ret
    4288:	39400400 	ldrb	w0, [x0, #1]
    428c:	34fffb00 	cbz	w0, 41ec <fwp_tape_buffers_release+0xd8>
    4290:	17ffffbb 	b	417c <fwp_tape_buffers_release+0x68>
    4294:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4298:	9107a000 	add	x0, x0, #0x1e8
    429c:	f9001bf7 	str	x23, [sp, #48]
    42a0:	97fffc18 	bl	3300 <ad_raw_fail>
    42a4:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    42a8:	91086000 	add	x0, x0, #0x218
    42ac:	f9001bf7 	str	x23, [sp, #48]
    42b0:	97fffc14 	bl	3300 <ad_raw_fail>

00000000000042b4 <fwp_trap>:
    42b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42b8:	90000162 	adrp	x2, 30000 <__data_start>
    42bc:	d53bd041 	mrs	x1, tpidr_el0
    42c0:	910003fd 	mov	x29, sp
    42c4:	f9407842 	ldr	x2, [x2, #240]
    42c8:	91400021 	add	x1, x1, #0x0, lsl #12
    42cc:	91004021 	add	x1, x1, #0x10
    42d0:	a90153f3 	stp	x19, x20, [sp, #16]
    42d4:	aa0003f3 	mov	x19, x0
    42d8:	f9400034 	ldr	x20, [x1]
    42dc:	b4000062 	cbz	x2, 42e8 <fwp_trap+0x34>
    42e0:	aa0203e0 	mov	x0, x2
    42e4:	97fff997 	bl	2940 <fflush@plt>
    42e8:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    42ec:	f947ec00 	ldr	x0, [x0, #4056]
    42f0:	f9400000 	ldr	x0, [x0]
    42f4:	97fff993 	bl	2940 <fflush@plt>
    42f8:	aa1303e3 	mov	x3, x19
    42fc:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x110>
    4300:	f0000153 	adrp	x19, 2f000 <fwp_fn_table+0xb30>
    4304:	f947ea73 	ldr	x19, [x19, #4048]
    4308:	9108e042 	add	x2, x2, #0x238
    430c:	52800041 	mov	w1, #0x2                   	// #2
    4310:	f9400260 	ldr	x0, [x19]
    4314:	97fff95b 	bl	2880 <__fprintf_chk@plt>
    4318:	b40000b4 	cbz	x20, 432c <fwp_trap+0x78>
    431c:	f9400260 	ldr	x0, [x19]
    4320:	97fff988 	bl	2940 <fflush@plt>
    4324:	52800ca0 	mov	w0, #0x65                  	// #101
    4328:	97fff996 	bl	2980 <_Exit@plt>
    432c:	52800ca0 	mov	w0, #0x65                  	// #101
    4330:	97fff8e4 	bl	26c0 <exit@plt>

0000000000004334 <fwp_rc_forget_slot.part.0>:
    4334:	ca404401 	eor	x1, x0, x0, lsr #17
    4338:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    433c:	ca412421 	eor	x1, x1, x1, lsr #9
    4340:	910003fd 	mov	x29, sp
    4344:	92401c21 	and	x1, x1, #0xff
    4348:	f9000bf3 	str	x19, [sp, #16]
    434c:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    4350:	91190262 	add	x2, x19, #0x640
    4354:	910a2423 	add	x3, x1, #0x289
    4358:	8b010c41 	add	x1, x2, x1, lsl #3
    435c:	8b030c43 	add	x3, x2, x3, lsl #3
    4360:	f94a2421 	ldr	x1, [x1, #5192]
    4364:	b50000a1 	cbnz	x1, 4378 <fwp_rc_forget_slot.part.0+0x44>
    4368:	14000012 	b	43b0 <fwp_rc_forget_slot.part.0+0x7c>
    436c:	91004023 	add	x3, x1, #0x10
    4370:	f9400821 	ldr	x1, [x1, #16]
    4374:	b40001e1 	cbz	x1, 43b0 <fwp_rc_forget_slot.part.0+0x7c>
    4378:	f9400022 	ldr	x2, [x1]
    437c:	eb02001f 	cmp	x0, x2
    4380:	54ffff61 	b.ne	436c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4384:	f9400060 	ldr	x0, [x3]
    4388:	91190273 	add	x19, x19, #0x640
    438c:	f9400801 	ldr	x1, [x0, #16]
    4390:	f9000061 	str	x1, [x3]
    4394:	97fff94f 	bl	28d0 <free@plt>
    4398:	f94e2660 	ldr	x0, [x19, #7240]
    439c:	d1000400 	sub	x0, x0, #0x1
    43a0:	f90e2660 	str	x0, [x19, #7240]
    43a4:	f9400bf3 	ldr	x19, [sp, #16]
    43a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43ac:	d65f03c0 	ret
    43b0:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    43b4:	91092000 	add	x0, x0, #0x248
    43b8:	97ffffbf 	bl	42b4 <fwp_trap>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_rc_prepare_chunk>:
    43c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000436 	adrp	x22, 89000 <fwp_root_context+0xba0>
    43d0:	911902c2 	add	x2, x22, #0x640
    43d4:	b9401c03 	ldr	w3, [x0, #28]
    43d8:	aa0103f5 	mov	x21, x1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f4 	mov	x20, x0
    43e4:	f94e2440 	ldr	x0, [x2, #7240]
    43e8:	b4000440 	cbz	x0, 4470 <fwp_rc_prepare_chunk+0xb0>
    43ec:	d2800013 	mov	x19, #0x0                   	// #0
    43f0:	35000203 	cbnz	w3, 4430 <fwp_rc_prepare_chunk+0x70>
    43f4:	b4000361 	cbz	x1, 4460 <fwp_rc_prepare_chunk+0xa0>
    43f8:	f9401280 	ldr	x0, [x20, #32]
    43fc:	97fff935 	bl	28d0 <free@plt>
    4400:	aa1503e0 	mov	x0, x21
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	97fff8fa 	bl	27f0 <calloc@plt>
    440c:	f9001280 	str	x0, [x20, #32]
    4410:	b5000460 	cbnz	x0, 449c <fwp_rc_prepare_chunk+0xdc>
    4414:	97fffb37 	bl	30f0 <fwp_heap_oom>
    4418:	97ffffc7 	bl	4334 <fwp_rc_forget_slot.part.0>
    441c:	91000673 	add	x19, x19, #0x1
    4420:	b9401e83 	ldr	w3, [x20, #28]
    4424:	eb13007f 	cmp	x3, x19
    4428:	54000169 	b.ls	4454 <fwp_rc_prepare_chunk+0x94>  // b.plast
    442c:	d503201f 	nop
    4430:	f9401283 	ldr	x3, [x20, #32]
    4434:	8b130060 	add	x0, x3, x19
    4438:	38736863 	ldrb	w3, [x3, x19]
    443c:	7103fc7f 	cmp	w3, #0xff
    4440:	54fffec0 	b.eq	4418 <fwp_rc_prepare_chunk+0x58>  // b.none
    4444:	b9401e83 	ldr	w3, [x20, #28]
    4448:	91000673 	add	x19, x19, #0x1
    444c:	eb13007f 	cmp	x3, x19
    4450:	54ffff08 	b.hi	4430 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4454:	eb0302bf 	cmp	x21, x3
    4458:	54000121 	b.ne	447c <fwp_rc_prepare_chunk+0xbc>  // b.any
    445c:	b5000335 	cbnz	x21, 44c0 <fwp_rc_prepare_chunk+0x100>
    4460:	a94153f3 	ldp	x19, x20, [sp, #16]
    4464:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	2a0303e3 	mov	w3, w3
    4474:	eb0302bf 	cmp	x21, x3
    4478:	54ffff20 	b.eq	445c <fwp_rc_prepare_chunk+0x9c>  // b.none
    447c:	911902c2 	add	x2, x22, #0x640
    4480:	f9401280 	ldr	x0, [x20, #32]
    4484:	f94e2841 	ldr	x1, [x2, #7248]
    4488:	cb030021 	sub	x1, x1, x3
    448c:	f90e2841 	str	x1, [x2, #7248]
    4490:	97fff910 	bl	28d0 <free@plt>
    4494:	b5fffb75 	cbnz	x21, 4400 <fwp_rc_prepare_chunk+0x40>
    4498:	f900129f 	str	xzr, [x20, #32]
    449c:	911902d6 	add	x22, x22, #0x640
    44a0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44a4:	b9001e95 	str	w21, [x20, #28]
    44a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ac:	8b150000 	add	x0, x0, x21
    44b0:	f90e2ac0 	str	x0, [x22, #7248]
    44b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f9401280 	ldr	x0, [x20, #32]
    44c4:	aa1503e2 	mov	x2, x21
    44c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44cc:	52800001 	mov	w1, #0x0                   	// #0
    44d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44d8:	17fff8c2 	b	27e0 <memset@plt>
    44dc:	d503201f 	nop

00000000000044e0 <fwp_heap_refill>:
    44e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44e4:	910003fd 	mov	x29, sp
    44e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44ec:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    44f0:	911902b5 	add	x21, x21, #0x640
    44f4:	aa0003f6 	mov	x22, x0
    44f8:	d2800020 	mov	x0, #0x1                   	// #1
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	a90363f7 	stp	x23, x24, [sp, #48]
    4504:	2a0103f7 	mov	w23, w1
    4508:	2a0203f8 	mov	w24, w2
    450c:	97fffb09 	bl	3130 <fwp_heap_chunks>
    4510:	aa0003f3 	mov	x19, x0
    4514:	f949fea2 	ldr	x2, [x21, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	2a1703e1 	mov	w1, w23
    4520:	52800025 	mov	w5, #0x1                   	// #1
    4524:	d37df000 	lsl	x0, x0, #3
    4528:	910f0021 	add	x1, x1, #0x3c0
    452c:	8b000054 	add	x20, x2, x0
    4530:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4534:	52a00024 	mov	w4, #0x10000               	// #65536
    4538:	38206845 	strb	w5, [x2, x0]
    453c:	aa1403e0 	mov	x0, x20
    4540:	39000698 	strb	w24, [x20, #1]
    4544:	39000a97 	strb	w23, [x20, #2]
    4548:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    454c:	b9000681 	str	w1, [x20, #4]
    4550:	2a0103e5 	mov	w5, w1
    4554:	8b0300a2 	add	x2, x5, x3
    4558:	1ac10881 	udiv	w1, w4, w1
    455c:	9ac50842 	udiv	x2, x2, x5
    4560:	b9000a81 	str	w1, [x20, #8]
    4564:	92404021 	and	x1, x1, #0x1ffff
    4568:	b9001a82 	str	w2, [x20, #24]
    456c:	97ffff95 	bl	43c0 <fwp_rc_prepare_chunk>
    4570:	f949daa0 	ldr	x0, [x21, #5040]
    4574:	29408a81 	ldp	w1, w2, [x20, #4]
    4578:	8b134000 	add	x0, x0, x19, lsl #16
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	8b214003 	add	x3, x0, w1, uxtw
    4584:	9ba20021 	umaddl	x1, w1, w2, x0
    4588:	a94363f7 	ldp	x23, x24, [sp, #48]
    458c:	a90086c3 	stp	x3, x1, [x22, #8]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4598:	d65f03c0 	ret
    459c:	d503201f 	nop

00000000000045a0 <fwp_mem_free>:
    45a0:	b40003c0 	cbz	x0, 4618 <fwp_mem_free+0x78>
    45a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45a8:	910003fd 	mov	x29, sp
    45ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    45b0:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    45b4:	911902a1 	add	x1, x21, #0x640
    45b8:	a90153f3 	stp	x19, x20, [sp, #16]
    45bc:	aa0003f3 	mov	x19, x0
    45c0:	f949d823 	ldr	x3, [x1, #5040]
    45c4:	f949ec22 	ldr	x2, [x1, #5080]
    45c8:	cb030000 	sub	x0, x0, x3
    45cc:	eb02401f 	cmp	x0, x2, lsl #16
    45d0:	540001c2 	b.cs	4608 <fwp_mem_free+0x68>  // b.hs, b.nlast
    45d4:	d350fc16 	lsr	x22, x0, #16
    45d8:	a90363f7 	stp	x23, x24, [sp, #48]
    45dc:	f949fc22 	ldr	x2, [x1, #5112]
    45e0:	8b160ad4 	add	x20, x22, x22, lsl #2
    45e4:	d37df294 	lsl	x20, x20, #3
    45e8:	ab140057 	adds	x23, x2, x20
    45ec:	540000c0 	b.eq	4604 <fwp_mem_free+0x64>  // b.none
    45f0:	38746842 	ldrb	w2, [x2, x20]
    45f4:	7100045f 	cmp	w2, #0x1
    45f8:	54000120 	b.eq	461c <fwp_mem_free+0x7c>  // b.none
    45fc:	7100085f 	cmp	w2, #0x2
    4600:	540005e0 	b.eq	46bc <fwp_mem_free+0x11c>  // b.none
    4604:	a94363f7 	ldp	x23, x24, [sp, #48]
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4614:	d65f03c0 	ret
    4618:	d65f03c0 	ret
    461c:	f94012f8 	ldr	x24, [x23, #32]
    4620:	b94006e1 	ldr	w1, [x23, #4]
    4624:	f90023f9 	str	x25, [sp, #64]
    4628:	2a0103e2 	mov	w2, w1
    462c:	394006f9 	ldrb	w25, [x23, #1]
    4630:	39400af4 	ldrb	w20, [x23, #2]
    4634:	b4000158 	cbz	x24, 465c <fwp_mem_free+0xbc>
    4638:	92403e76 	and	x22, x19, #0xffff
    463c:	9ac20ad6 	udiv	x22, x22, x2
    4640:	38766b01 	ldrb	w1, [x24, x22]
    4644:	8b160300 	add	x0, x24, x22
    4648:	7103fc3f 	cmp	w1, #0xff
    464c:	54000980 	b.eq	477c <fwp_mem_free+0x1dc>  // b.none
    4650:	38366b1f 	strb	wzr, [x24, x22]
    4654:	b94006e1 	ldr	w1, [x23, #4]
    4658:	2a0103e2 	mov	w2, w1
    465c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4660:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4664:	cb390000 	sub	x0, x0, w25, uxtb
    4668:	8b340074 	add	x20, x3, w20, uxtb
    466c:	911902b5 	add	x21, x21, #0x640
    4670:	1e630021 	ucvtf	d1, w1
    4674:	d37ae400 	lsl	x0, x0, #6
    4678:	8b140c14 	add	x20, x0, x20, lsl #3
    467c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4680:	f8746aa0 	ldr	x0, [x21, x20]
    4684:	f94023f9 	ldr	x25, [sp, #64]
    4688:	aa2003e0 	mvn	x0, x0
    468c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4690:	f9000260 	str	x0, [x19]
    4694:	f8346ab3 	str	x19, [x21, x20]
    4698:	f94a12a0 	ldr	x0, [x21, #5152]
    469c:	1e612800 	fadd	d0, d0, d1
    46a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46a4:	cb020000 	sub	x0, x0, x2
    46a8:	f90a12a0 	str	x0, [x21, #5152]
    46ac:	fd0a22a0 	str	d0, [x21, #5184]
    46b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46b8:	d65f03c0 	ret
    46bc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46c0:	8b000063 	add	x3, x3, x0
    46c4:	eb03027f 	cmp	x19, x3
    46c8:	54fff9e1 	b.ne	4604 <fwp_mem_free+0x64>  // b.any
    46cc:	fd400ae1 	ldr	d1, [x23, #16]
    46d0:	fd4a2020 	ldr	d0, [x1, #5184]
    46d4:	f9400ae0 	ldr	x0, [x23, #16]
    46d8:	7e61d821 	ucvtf	d1, d1
    46dc:	f94a1022 	ldr	x2, [x1, #5152]
    46e0:	f94012f3 	ldr	x19, [x23, #32]
    46e4:	1e612800 	fadd	d0, d0, d1
    46e8:	cb000042 	sub	x2, x2, x0
    46ec:	f90a1022 	str	x2, [x1, #5152]
    46f0:	fd0a2020 	str	d0, [x1, #5184]
    46f4:	b40000b3 	cbz	x19, 4708 <fwp_mem_free+0x168>
    46f8:	39400260 	ldrb	w0, [x19]
    46fc:	7103fc1f 	cmp	w0, #0xff
    4700:	54000380 	b.eq	4770 <fwp_mem_free+0x1d0>  // b.none
    4704:	3900027f 	strb	wzr, [x19]
    4708:	b9400ee2 	ldr	w2, [x23, #12]
    470c:	b4000142 	cbz	x2, 4734 <fwp_mem_free+0x194>
    4710:	911902a1 	add	x1, x21, #0x640
    4714:	8b160040 	add	x0, x2, x22
    4718:	8b000800 	add	x0, x0, x0, lsl #2
    471c:	f949fc21 	ldr	x1, [x1, #5112]
    4720:	8b140034 	add	x20, x1, x20
    4724:	8b000c20 	add	x0, x1, x0, lsl #3
    4728:	3802869f 	strb	wzr, [x20], #40
    472c:	eb00029f 	cmp	x20, x0
    4730:	54ffffc1 	b.ne	4728 <fwp_mem_free+0x188>  // b.any
    4734:	911902a0 	add	x0, x21, #0x640
    4738:	f94a1801 	ldr	x1, [x0, #5168]
    473c:	f949f803 	ldr	x3, [x0, #5104]
    4740:	8b020021 	add	x1, x1, x2
    4744:	f90a1801 	str	x1, [x0, #5168]
    4748:	eb16007f 	cmp	x3, x22
    474c:	54000049 	b.ls	4754 <fwp_mem_free+0x1b4>  // b.plast
    4750:	f909f816 	str	x22, [x0, #5104]
    4754:	911902b5 	add	x21, x21, #0x640
    4758:	f949f6a0 	ldr	x0, [x21, #5096]
    475c:	eb16001f 	cmp	x0, x22
    4760:	54fff529 	b.ls	4604 <fwp_mem_free+0x64>  // b.plast
    4764:	a94363f7 	ldp	x23, x24, [sp, #48]
    4768:	f909f6b6 	str	x22, [x21, #5096]
    476c:	17ffffa7 	b	4608 <fwp_mem_free+0x68>
    4770:	aa1303e0 	mov	x0, x19
    4774:	97fffef0 	bl	4334 <fwp_rc_forget_slot.part.0>
    4778:	17ffffe3 	b	4704 <fwp_mem_free+0x164>
    477c:	97fffeee 	bl	4334 <fwp_rc_forget_slot.part.0>
    4780:	17ffffb4 	b	4650 <fwp_mem_free+0xb0>

0000000000004784 <fwp_rc_wide_dup>:
    4784:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4788:	910003fd 	mov	x29, sp
    478c:	a90153f3 	stp	x19, x20, [sp, #16]
    4790:	aa0003f3 	mov	x19, x0
    4794:	ca404400 	eor	x0, x0, x0, lsr #17
    4798:	f90013f5 	str	x21, [sp, #32]
    479c:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    47a0:	ca402400 	eor	x0, x0, x0, lsr #9
    47a4:	911902a2 	add	x2, x21, #0x640
    47a8:	92401c00 	and	x0, x0, #0xff
    47ac:	910a2403 	add	x3, x0, #0x289
    47b0:	8b000c40 	add	x0, x2, x0, lsl #3
    47b4:	8b030c54 	add	x20, x2, x3, lsl #3
    47b8:	f94a2401 	ldr	x1, [x0, #5192]
    47bc:	b50000a1 	cbnz	x1, 47d0 <fwp_rc_wide_dup+0x4c>
    47c0:	14000033 	b	488c <fwp_rc_wide_dup+0x108>
    47c4:	91004034 	add	x20, x1, #0x10
    47c8:	f9400821 	ldr	x1, [x1, #16]
    47cc:	b4000241 	cbz	x1, 4814 <fwp_rc_wide_dup+0x90>
    47d0:	f9400022 	ldr	x2, [x1]
    47d4:	eb02027f 	cmp	x19, x2
    47d8:	54ffff61 	b.ne	47c4 <fwp_rc_wide_dup+0x40>  // b.any
    47dc:	f9400281 	ldr	x1, [x20]
    47e0:	39400260 	ldrb	w0, [x19]
    47e4:	7103f81f 	cmp	w0, #0xfe
    47e8:	54000220 	b.eq	482c <fwp_rc_wide_dup+0xa8>  // b.none
    47ec:	b40001a1 	cbz	x1, 4820 <fwp_rc_wide_dup+0x9c>
    47f0:	f9400420 	ldr	x0, [x1, #8]
    47f4:	b100041f 	cmn	x0, #0x1
    47f8:	54000440 	b.eq	4880 <fwp_rc_wide_dup+0xfc>  // b.none
    47fc:	91000400 	add	x0, x0, #0x1
    4800:	f9000420 	str	x0, [x1, #8]
    4804:	a94153f3 	ldp	x19, x20, [sp, #16]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	39400260 	ldrb	w0, [x19]
    4818:	7103f81f 	cmp	w0, #0xfe
    481c:	54000100 	b.eq	483c <fwp_rc_wide_dup+0xb8>  // b.none
    4820:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4824:	91092000 	add	x0, x0, #0x248
    4828:	97fffea3 	bl	42b4 <fwp_trap>
    482c:	b4000081 	cbz	x1, 483c <fwp_rc_wide_dup+0xb8>
    4830:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4834:	9109c000 	add	x0, x0, #0x270
    4838:	97fffe9f 	bl	42b4 <fwp_trap>
    483c:	d2800300 	mov	x0, #0x18                  	// #24
    4840:	97fff7dc 	bl	27b0 <malloc@plt>
    4844:	b4000280 	cbz	x0, 4894 <fwp_rc_wide_dup+0x110>
    4848:	d2801fe1 	mov	x1, #0xff                  	// #255
    484c:	a9000413 	stp	x19, x1, [x0]
    4850:	911902b5 	add	x21, x21, #0x640
    4854:	f900081f 	str	xzr, [x0, #16]
    4858:	12800001 	mov	w1, #0xffffffff            	// #-1
    485c:	f9000280 	str	x0, [x20]
    4860:	39000261 	strb	w1, [x19]
    4864:	f94e26a0 	ldr	x0, [x21, #7240]
    4868:	a94153f3 	ldp	x19, x20, [sp, #16]
    486c:	91000400 	add	x0, x0, #0x1
    4870:	f90e26a0 	str	x0, [x21, #7240]
    4874:	f94013f5 	ldr	x21, [sp, #32]
    4878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    487c:	d65f03c0 	ret
    4880:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4884:	910a6000 	add	x0, x0, #0x298
    4888:	97fffe8b 	bl	42b4 <fwp_trap>
    488c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4890:	17ffffd4 	b	47e0 <fwp_rc_wide_dup+0x5c>
    4894:	97fffa17 	bl	30f0 <fwp_heap_oom>
    4898:	d503201f 	nop
    489c:	d503201f 	nop

00000000000048a0 <fwp_closure_drop_push>:
    48a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48a4:	910003fd 	mov	x29, sp
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	aa0003f3 	mov	x19, x0
    48b0:	a9408014 	ldp	x20, x0, [x0, #8]
    48b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48b8:	aa0103f5 	mov	x21, x1
    48bc:	a90363f7 	stp	x23, x24, [sp, #48]
    48c0:	eb00029f 	cmp	x20, x0
    48c4:	54000160 	b.eq	48f0 <fwp_closure_drop_push+0x50>  // b.none
    48c8:	f9400276 	ldr	x22, [x19]
    48cc:	d37df297 	lsl	x23, x20, #3
    48d0:	91000694 	add	x20, x20, #0x1
    48d4:	f9000674 	str	x20, [x19, #8]
    48d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48dc:	f8376ad5 	str	x21, [x22, x23]
    48e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48e8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48ec:	d65f03c0 	ret
    48f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    48f4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    48f8:	eb00029f 	cmp	x20, x0
    48fc:	540003e8 	b.hi	4978 <fwp_closure_drop_push+0xd8>  // b.pmore
    4900:	d37cee99 	lsl	x25, x20, #4
    4904:	d37ffa9a 	lsl	x26, x20, #1
    4908:	aa1903e0 	mov	x0, x25
    490c:	97fff7a9 	bl	27b0 <malloc@plt>
    4910:	aa0003f6 	mov	x22, x0
    4914:	b4000380 	cbz	x0, 4984 <fwp_closure_drop_push+0xe4>
    4918:	aa1303f8 	mov	x24, x19
    491c:	aa1903e3 	mov	x3, x25
    4920:	d37df297 	lsl	x23, x20, #3
    4924:	aa1703e2 	mov	x2, x23
    4928:	f8418719 	ldr	x25, [x24], #24
    492c:	aa1903e1 	mov	x1, x25
    4930:	97fff78c 	bl	2760 <__memcpy_chk@plt>
    4934:	eb18033f 	cmp	x25, x24
    4938:	540000a0 	b.eq	494c <fwp_closure_drop_push+0xac>  // b.none
    493c:	aa1903e0 	mov	x0, x25
    4940:	97fff7e4 	bl	28d0 <free@plt>
    4944:	f9400674 	ldr	x20, [x19, #8]
    4948:	d37df297 	lsl	x23, x20, #3
    494c:	91000694 	add	x20, x20, #0x1
    4950:	f9000276 	str	x22, [x19]
    4954:	f9000a7a 	str	x26, [x19, #16]
    4958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    495c:	f9000674 	str	x20, [x19, #8]
    4960:	f8376ad5 	str	x21, [x22, x23]
    4964:	a94153f3 	ldp	x19, x20, [sp, #16]
    4968:	a9425bf5 	ldp	x21, x22, [sp, #32]
    496c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4970:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4974:	d65f03c0 	ret
    4978:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    497c:	910ae000 	add	x0, x0, #0x2b8
    4980:	97fffe4d 	bl	42b4 <fwp_trap>
    4984:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    4988:	f947e863 	ldr	x3, [x3, #4048]
    498c:	d2800262 	mov	x2, #0x13                  	// #19
    4990:	d2800021 	mov	x1, #0x1                   	// #1
    4994:	b0000040 	adrp	x0, d000 <f0+0x2460>
    4998:	913be000 	add	x0, x0, #0xef8
    499c:	f9400063 	ldr	x3, [x3]
    49a0:	97fff7dc 	bl	2910 <fwrite@plt>
    49a4:	d2800000 	mov	x0, #0x0                   	// #0
    49a8:	97fff7e6 	bl	2940 <fflush@plt>
    49ac:	52800cc0 	mov	w0, #0x66                  	// #102
    49b0:	97fff7f4 	bl	2980 <_Exit@plt>

00000000000049b4 <fwp_closure_drop.part.0>:
    49b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49b8:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x110>
    49bc:	910003fd 	mov	x29, sp
    49c0:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    49c4:	f947f463 	ldr	x3, [x3, #4072]
    49c8:	a90153f3 	stp	x19, x20, [sp, #16]
    49cc:	d10883ff 	sub	sp, sp, #0x220
    49d0:	910003e2 	mov	x2, sp
    49d4:	d53bd053 	mrs	x19, tpidr_el0
    49d8:	910063f4 	add	x20, sp, #0x18
    49dc:	3dc3a820 	ldr	q0, [x1, #3744]
    49e0:	91400264 	add	x4, x19, #0x0, lsl #12
    49e4:	91004084 	add	x4, x4, #0x10
    49e8:	aa0003e1 	mov	x1, x0
    49ec:	aa0203e0 	mov	x0, x2
    49f0:	f9400062 	ldr	x2, [x3]
    49f4:	f9010fe2 	str	x2, [sp, #536]
    49f8:	d2800002 	mov	x2, #0x0                   	// #0
    49fc:	f90003f4 	str	x20, [sp]
    4a00:	f9000080 	str	x0, [x4]
    4a04:	3c8083e0 	stur	q0, [sp, #8]
    4a08:	97ffffa6 	bl	48a0 <fwp_closure_drop_push>
    4a0c:	f94007e0 	ldr	x0, [sp, #8]
    4a10:	b40002e0 	cbz	x0, 4a6c <fwp_closure_drop.part.0+0xb8>
    4a14:	f90123f5 	str	x21, [sp, #576]
    4a18:	90000175 	adrp	x21, 30000 <__data_start>
    4a1c:	910182b5 	add	x21, x21, #0x60
    4a20:	14000006 	b	4a38 <fwp_closure_drop.part.0+0x84>
    4a24:	f9400422 	ldr	x2, [x1, #8]
    4a28:	52800001 	mov	w1, #0x0                   	// #0
    4a2c:	d63f0040 	blr	x2
    4a30:	f94007e0 	ldr	x0, [sp, #8]
    4a34:	b40001a0 	cbz	x0, 4a68 <fwp_closure_drop.part.0+0xb4>
    4a38:	f94003e1 	ldr	x1, [sp]
    4a3c:	d1000400 	sub	x0, x0, #0x1
    4a40:	f90007e0 	str	x0, [sp, #8]
    4a44:	f9408ea2 	ldr	x2, [x21, #280]
    4a48:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a4c:	b9400001 	ldr	w1, [x0]
    4a50:	8b011441 	add	x1, x2, x1, lsl #5
    4a54:	f9400c21 	ldr	x1, [x1, #24]
    4a58:	b5fffe61 	cbnz	x1, 4a24 <fwp_closure_drop.part.0+0x70>
    4a5c:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4a60:	910b6000 	add	x0, x0, #0x2d8
    4a64:	97fffe14 	bl	42b4 <fwp_trap>
    4a68:	f94123f5 	ldr	x21, [sp, #576]
    4a6c:	91400273 	add	x19, x19, #0x0, lsl #12
    4a70:	91004273 	add	x19, x19, #0x10
    4a74:	f94003e0 	ldr	x0, [sp]
    4a78:	f900027f 	str	xzr, [x19]
    4a7c:	eb14001f 	cmp	x0, x20
    4a80:	54000040 	b.eq	4a88 <fwp_closure_drop.part.0+0xd4>  // b.none
    4a84:	97fff793 	bl	28d0 <free@plt>
    4a88:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4a8c:	f947f400 	ldr	x0, [x0, #4072]
    4a90:	f9410fe2 	ldr	x2, [sp, #536]
    4a94:	f9400001 	ldr	x1, [x0]
    4a98:	eb010042 	subs	x2, x2, x1
    4a9c:	d2800001 	mov	x1, #0x0                   	// #0
    4aa0:	540000a1 	b.ne	4ab4 <fwp_closure_drop.part.0+0x100>  // b.any
    4aa4:	910883ff 	add	sp, sp, #0x220
    4aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ab0:	d65f03c0 	ret
    4ab4:	f90123f5 	str	x21, [sp, #576]
    4ab8:	97fff756 	bl	2810 <__stack_chk_fail@plt>
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_tape_of>:
    4ac0:	aa0003e1 	mov	x1, x0
    4ac4:	92403c00 	and	x0, x0, #0xffff
    4ac8:	b40000e0 	cbz	x0, 4ae4 <fwp_tape_of+0x24>
    4acc:	d1000402 	sub	x2, x0, #0x1
    4ad0:	90000160 	adrp	x0, 30000 <__data_start>
    4ad4:	91018000 	add	x0, x0, #0x60
    4ad8:	f9409003 	ldr	x3, [x0, #288]
    4adc:	eb02007f 	cmp	x3, x2
    4ae0:	540000cc 	b.gt	4af8 <fwp_tape_of+0x38>
    4ae4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4ae8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4aec:	910c2000 	add	x0, x0, #0x308
    4af0:	910003fd 	mov	x29, sp
    4af4:	97fffdf0 	bl	42b4 <fwp_trap>
    4af8:	8b020443 	add	x3, x2, x2, lsl #1
    4afc:	f9404404 	ldr	x4, [x0, #136]
    4b00:	8b030842 	add	x2, x2, x3, lsl #2
    4b04:	d37df042 	lsl	x2, x2, #3
    4b08:	8b020080 	add	x0, x4, x2
    4b0c:	b9400403 	ldr	w3, [x0, #4]
    4b10:	34fffea3 	cbz	w3, 4ae4 <fwp_tape_of+0x24>
    4b14:	b8626882 	ldr	w2, [x4, x2]
    4b18:	9350fc21 	asr	x1, x1, #16
    4b1c:	6b01005f 	cmp	w2, w1
    4b20:	54fffe21 	b.ne	4ae4 <fwp_tape_of+0x24>  // b.any
    4b24:	d65f03c0 	ret
    4b28:	d503201f 	nop
    4b2c:	d503201f 	nop

0000000000004b30 <fwp_now_ns>:
    4b30:	d100c3ff 	sub	sp, sp, #0x30
    4b34:	52800020 	mov	w0, #0x1                   	// #1
    4b38:	f0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    4b3c:	f947f442 	ldr	x2, [x2, #4072]
    4b40:	910023e1 	add	x1, sp, #0x8
    4b44:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b48:	910083fd 	add	x29, sp, #0x20
    4b4c:	f9400043 	ldr	x3, [x2]
    4b50:	f9000fe3 	str	x3, [sp, #24]
    4b54:	d2800003 	mov	x3, #0x0                   	// #0
    4b58:	97fff6fa 	bl	2740 <clock_gettime@plt>
    4b5c:	350002c0 	cbnz	w0, 4bb4 <fwp_now_ns+0x84>
    4b60:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b64:	d2994003 	mov	x3, #0xca00                	// #51712
    4b68:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b6c:	9b037c20 	mul	x0, x1, x3
    4b70:	9b437c21 	smulh	x1, x1, x3
    4b74:	ab020000 	adds	x0, x0, x2
    4b78:	937ffc42 	asr	x2, x2, #63
    4b7c:	9a020021 	adc	x1, x1, x2
    4b80:	f100001f 	cmp	x0, #0x0
    4b84:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4b88:	b50001c1 	cbnz	x1, 4bc0 <fwp_now_ns+0x90>
    4b8c:	f0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    4b90:	f947f421 	ldr	x1, [x1, #4072]
    4b94:	f9400fe3 	ldr	x3, [sp, #24]
    4b98:	f9400022 	ldr	x2, [x1]
    4b9c:	eb020063 	subs	x3, x3, x2
    4ba0:	d2800002 	mov	x2, #0x0                   	// #0
    4ba4:	54000141 	b.ne	4bcc <fwp_now_ns+0x9c>  // b.any
    4ba8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bac:	9100c3ff 	add	sp, sp, #0x30
    4bb0:	d65f03c0 	ret
    4bb4:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4bb8:	910d6000 	add	x0, x0, #0x358
    4bbc:	97fffdbe 	bl	42b4 <fwp_trap>
    4bc0:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4bc4:	910de000 	add	x0, x0, #0x378
    4bc8:	97fffdbb 	bl	42b4 <fwp_trap>
    4bcc:	97fff711 	bl	2810 <__stack_chk_fail@plt>

0000000000004bd0 <fwp_poll_events>:
    4bd0:	d10103ff 	sub	sp, sp, #0x40
    4bd4:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4bd8:	f947f400 	ldr	x0, [x0, #4072]
    4bdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4be0:	910083fd 	add	x29, sp, #0x20
    4be4:	f9001bf3 	str	x19, [sp, #48]
    4be8:	90000173 	adrp	x19, 30000 <__data_start>
    4bec:	f9400001 	ldr	x1, [x0]
    4bf0:	f9000fe1 	str	x1, [sp, #24]
    4bf4:	d2800001 	mov	x1, #0x0                   	// #0
    4bf8:	97ffffce 	bl	4b30 <fwp_now_ns>
    4bfc:	91018261 	add	x1, x19, #0x60
    4c00:	f9409421 	ldr	x1, [x1, #296]
    4c04:	b4000e01 	cbz	x1, 4dc4 <fwp_poll_events+0x1f4>
    4c08:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c0c:	14000005 	b	4c20 <fwp_poll_events+0x50>
    4c10:	f9408821 	ldr	x1, [x1, #272]
    4c14:	eb03005f 	cmp	x2, x3
    4c18:	9a83d042 	csel	x2, x2, x3, le
    4c1c:	b40000c1 	cbz	x1, 4c34 <fwp_poll_events+0x64>
    4c20:	f9403423 	ldr	x3, [x1, #104]
    4c24:	b6ffff62 	tbz	x2, #63, 4c10 <fwp_poll_events+0x40>
    4c28:	f9408821 	ldr	x1, [x1, #272]
    4c2c:	aa0303e2 	mov	x2, x3
    4c30:	b5ffff81 	cbnz	x1, 4c20 <fwp_poll_events+0x50>
    4c34:	b7f80c82 	tbnz	x2, #63, 4dc4 <fwp_poll_events+0x1f4>
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f100005f 	cmp	x2, #0x0
    4c40:	540003ad 	b.le	4cb4 <fwp_poll_events+0xe4>
    4c44:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c48:	d2884804 	mov	x4, #0x4240                	// #16960
    4c4c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c50:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c54:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c58:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c5c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c60:	9b407c40 	smulh	x0, x2, x0
    4c64:	9352fc00 	asr	x0, x0, #18
    4c68:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c6c:	9b048802 	msub	x2, x0, x4, x2
    4c70:	f100005f 	cmp	x2, #0x0
    4c74:	9a800400 	cinc	x0, x0, ne	// ne = any
    4c78:	eb01001f 	cmp	x0, x1
    4c7c:	5400098c 	b.gt	4dac <fwp_poll_events+0x1dc>
    4c80:	340001a0 	cbz	w0, 4cb4 <fwp_poll_events+0xe4>
    4c84:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4c88:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4c8c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4c90:	9ba17c01 	umull	x1, w0, w1
    4c94:	d366fc23 	lsr	x3, x1, #38
    4c98:	aa0303e2 	mov	x2, x3
    4c9c:	1b058063 	msub	w3, w3, w5, w0
    4ca0:	9b247c63 	smull	x3, w3, w4
    4ca4:	910023e0 	add	x0, sp, #0x8
    4ca8:	d2800001 	mov	x1, #0x0                   	// #0
    4cac:	a9008fe2 	stp	x2, x3, [sp, #8]
    4cb0:	97fff70c 	bl	28e0 <nanosleep@plt>
    4cb4:	97ffff9f 	bl	4b30 <fwp_now_ns>
    4cb8:	91018268 	add	x8, x19, #0x60
    4cbc:	aa0003e7 	mov	x7, x0
    4cc0:	4f000400 	movi	v0.4s, #0x0
    4cc4:	52800029 	mov	w9, #0x1                   	// #1
    4cc8:	f9409506 	ldr	x6, [x8, #296]
    4ccc:	d503201f 	nop
    4cd0:	b40003e6 	cbz	x6, 4d4c <fwp_poll_events+0x17c>
    4cd4:	f94034c1 	ldr	x1, [x6, #104]
    4cd8:	aa0603e5 	mov	x5, x6
    4cdc:	f94088c6 	ldr	x6, [x6, #272]
    4ce0:	eb07003f 	cmp	x1, x7
    4ce4:	54ffff6c 	b.gt	4cd0 <fwp_poll_events+0x100>
    4ce8:	394154a0 	ldrb	w0, [x5, #85]
    4cec:	36000120 	tbz	w0, #0, 4d10 <fwp_poll_events+0x140>
    4cf0:	f94084a0 	ldr	x0, [x5, #264]
    4cf4:	b4000560 	cbz	x0, 4da0 <fwp_poll_events+0x1d0>
    4cf8:	f9008806 	str	x6, [x0, #272]
    4cfc:	b4000046 	cbz	x6, 4d04 <fwp_poll_events+0x134>
    4d00:	f90084c0 	str	x0, [x6, #264]
    4d04:	910800a0 	add	x0, x5, #0x200
    4d08:	390154bf 	strb	wzr, [x5, #85]
    4d0c:	3c908000 	stur	q0, [x0, #-248]
    4d10:	f94030a0 	ldr	x0, [x5, #96]
    4d14:	390158a9 	strb	w9, [x5, #86]
    4d18:	f100001f 	cmp	x0, #0x0
    4d1c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d20:	540002cd 	b.le	4d78 <fwp_poll_events+0x1a8>
    4d24:	f94028a0 	ldr	x0, [x5, #80]
    4d28:	f2001c1f 	tst	x0, #0xff000000ff
    4d2c:	54fffd21 	b.ne	4cd0 <fwp_poll_events+0x100>  // b.any
    4d30:	f9406100 	ldr	x0, [x8, #192]
    4d34:	390150a9 	strb	w9, [x5, #84]
    4d38:	f90080bf 	str	xzr, [x5, #256]
    4d3c:	b40002c0 	cbz	x0, 4d94 <fwp_poll_events+0x1c4>
    4d40:	f9006105 	str	x5, [x8, #192]
    4d44:	f9008005 	str	x5, [x0, #256]
    4d48:	b5fffc66 	cbnz	x6, 4cd4 <fwp_poll_events+0x104>
    4d4c:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4d50:	f947f400 	ldr	x0, [x0, #4072]
    4d54:	f9400fe2 	ldr	x2, [sp, #24]
    4d58:	f9400001 	ldr	x1, [x0]
    4d5c:	eb010042 	subs	x2, x2, x1
    4d60:	d2800001 	mov	x1, #0x0                   	// #0
    4d64:	540002e1 	b.ne	4dc0 <fwp_poll_events+0x1f0>  // b.any
    4d68:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d6c:	f9401bf3 	ldr	x19, [sp, #48]
    4d70:	910103ff 	add	sp, sp, #0x40
    4d74:	d65f03c0 	ret
    4d78:	394144a0 	ldrb	w0, [x5, #81]
    4d7c:	3707fd40 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d80:	394140a0 	ldrb	w0, [x5, #80]
    4d84:	3707fd00 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d88:	aa0503e0 	mov	x0, x5
    4d8c:	97fffa39 	bl	3670 <fwp_cancel_tree.part.0>
    4d90:	17ffffe5 	b	4d24 <fwp_poll_events+0x154>
    4d94:	f9006105 	str	x5, [x8, #192]
    4d98:	f9006505 	str	x5, [x8, #200]
    4d9c:	17ffffeb 	b	4d48 <fwp_poll_events+0x178>
    4da0:	91018261 	add	x1, x19, #0x60
    4da4:	f9009426 	str	x6, [x1, #296]
    4da8:	17ffffd5 	b	4cfc <fwp_poll_events+0x12c>
    4dac:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4db0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4db4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4db8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dbc:	17ffffba 	b	4ca4 <fwp_poll_events+0xd4>
    4dc0:	97fff694 	bl	2810 <__stack_chk_fail@plt>
    4dc4:	97fff88c 	bl	2ff4 <fwp_flush>
    4dc8:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    4dcc:	f947e863 	ldr	x3, [x3, #4048]
    4dd0:	d2800562 	mov	x2, #0x2b                  	// #43
    4dd4:	d2800021 	mov	x1, #0x1                   	// #1
    4dd8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    4ddc:	910e8000 	add	x0, x0, #0x3a0
    4de0:	f9400063 	ldr	x3, [x3]
    4de4:	97fff6cb 	bl	2910 <fwrite@plt>
    4de8:	52800ca0 	mov	w0, #0x65                  	// #101
    4dec:	97fff635 	bl	26c0 <exit@plt>

0000000000004df0 <fwp_heap_alloc_big>:
    4df0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df4:	910003fd 	mov	x29, sp
    4df8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e00:	a90363f7 	stp	x23, x24, [sp, #48]
    4e04:	aa0003f7 	mov	x23, x0
    4e08:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e0c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e10:	eb0002ff 	cmp	x23, x0
    4e14:	540008a8 	b.hi	4f28 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e18:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e1c:	8b0002f4 	add	x20, x23, x0
    4e20:	b000043a 	adrp	x26, 89000 <fwp_root_context+0xba0>
    4e24:	91190359 	add	x25, x26, #0x640
    4e28:	d350fe94 	lsr	x20, x20, #16
    4e2c:	2a0103f5 	mov	w21, w1
    4e30:	aa1403e0 	mov	x0, x20
    4e34:	97fff8bf 	bl	3130 <fwp_heap_chunks>
    4e38:	f949ff22 	ldr	x2, [x25, #5112]
    4e3c:	8b000813 	add	x19, x0, x0, lsl #2
    4e40:	aa0003f8 	mov	x24, x0
    4e44:	52800043 	mov	w3, #0x2                   	// #2
    4e48:	d37df273 	lsl	x19, x19, #3
    4e4c:	d2800021 	mov	x1, #0x1                   	// #1
    4e50:	8b130040 	add	x0, x2, x19
    4e54:	38336843 	strb	w3, [x2, x19]
    4e58:	39000415 	strb	w21, [x0, #1]
    4e5c:	b9000c14 	str	w20, [x0, #12]
    4e60:	f9000817 	str	x23, [x0, #16]
    4e64:	97fffd57 	bl	43c0 <fwp_rc_prepare_chunk>
    4e68:	f100069f 	cmp	x20, #0x1
    4e6c:	54000289 	b.ls	4ebc <fwp_heap_alloc_big+0xcc>  // b.plast
    4e70:	8b180294 	add	x20, x20, x24
    4e74:	9100a273 	add	x19, x19, #0x28
    4e78:	a90573fb 	stp	x27, x28, [sp, #80]
    4e7c:	5280007b 	mov	w27, #0x3                   	// #3
    4e80:	8b140a94 	add	x20, x20, x20, lsl #2
    4e84:	2a1803fc 	mov	w28, w24
    4e88:	9adb2296 	lsl	x22, x20, x27
    4e8c:	d503201f 	nop
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffd48 	bl	43c0 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0xa0>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffb37 	bl	3cf0 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff6f 	b	4df0 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffd19 	bl	44e0 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f0000156 	adrp	x22, 30000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	540008a1 	b.ne	51cc <fwp_heap_alloc+0x13c>  // b.any
    50bc:	90000437 	adrp	x23, 89000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	54000722 	b.cs	5218 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	5400030c 	b.gt	51e0 <fwp_heap_alloc+0x150>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000249 	b.ls	51fc <fwp_heap_alloc+0x16c>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	910182c1 	add	x1, x22, #0x60
    51c4:	b9413038 	ldr	w24, [x1, #304]
    51c8:	17ffffe6 	b	5160 <fwp_heap_alloc+0xd0>
    51cc:	a9538c44 	ldp	x4, x3, [x2, #312]
    51d0:	91000484 	add	x4, x4, #0x1
    51d4:	8b000063 	add	x3, x3, x0
    51d8:	a9138c44 	stp	x4, x3, [x2, #312]
    51dc:	17ffffb8 	b	50bc <fwp_heap_alloc+0x2c>
    51e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51e4:	fd00a800 	str	d0, [x0, #336]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	aa0403e0 	mov	x0, x4
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f8:	d65f03c0 	ret
    51fc:	7100043f 	cmp	w1, #0x1
    5200:	8b140085 	add	x5, x4, x20
    5204:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5208:	52800001 	mov	w1, #0x0                   	// #0
    520c:	aa0403e0 	mov	x0, x4
    5210:	f9000465 	str	x5, [x3, #8]
    5214:	17ffffc4 	b	5124 <fwp_heap_alloc+0x94>
    5218:	97fff7b6 	bl	30f0 <fwp_heap_oom>
    521c:	d503201f 	nop

0000000000005220 <fwp_apply>:
    5220:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5224:	aa0003e6 	mov	x6, x0
    5228:	910003fd 	mov	x29, sp
    522c:	d0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    5230:	f947f463 	ldr	x3, [x3, #4072]
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	aa0203f4 	mov	x20, x2
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	2a0103f5 	mov	w21, w1
    5244:	52800033 	mov	w19, #0x1                   	// #1
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	f0000157 	adrp	x23, 30000 <__data_start>
    5250:	910182f7 	add	x23, x23, #0x60
    5254:	a9046bf9 	stp	x25, x26, [sp, #64]
    5258:	d100c3ff 	sub	sp, sp, #0x30
    525c:	f9400060 	ldr	x0, [x3]
    5260:	f81f83a0 	stur	x0, [x29, #-8]
    5264:	d2800000 	mov	x0, #0x0                   	// #0
    5268:	294058c3 	ldp	w3, w22, [x6]
    526c:	910003f8 	mov	x24, sp
    5270:	f9408ee0 	ldr	x0, [x23, #280]
    5274:	710002df 	cmp	w22, #0x0
    5278:	d37be863 	lsl	x3, x3, #5
    527c:	8b030007 	add	x7, x0, x3
    5280:	b8636819 	ldr	w25, [x0, x3]
    5284:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    5288:	54000163 	b.cc	52b4 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    528c:	f94004e3 	ldr	x3, [x7, #8]
    5290:	34000bb9 	cbz	w25, 5404 <fwp_apply+0x1e4>
    5294:	aa1403e0 	mov	x0, x20
    5298:	d63f0060 	blr	x3
    529c:	aa0003e6 	mov	x6, x0
    52a0:	6b1902bf 	cmp	w21, w25
    52a4:	54000920 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    52a8:	8b394e94 	add	x20, x20, w25, uxtw #3
    52ac:	4b1902b5 	sub	w21, w21, w25
    52b0:	17ffffee 	b	5268 <fwp_apply+0x48>
    52b4:	0b1602ba 	add	w26, w21, w22
    52b8:	6b19035f 	cmp	w26, w25
    52bc:	54000523 	b.cc	5360 <fwp_apply+0x140>  // b.lo, b.ul, b.last
    52c0:	7100033f 	cmp	w25, #0x0
    52c4:	4b16033a 	sub	w26, w25, w22
    52c8:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52cc:	d37df000 	lsl	x0, x0, #3
    52d0:	91003c00 	add	x0, x0, #0xf
    52d4:	92704c01 	and	x1, x0, #0xfffff0000
    52d8:	927c7c00 	and	x0, x0, #0xffffffff0
    52dc:	cb2163e1 	sub	x1, sp, x1
    52e0:	eb2163ff 	cmp	sp, x1
    52e4:	540000a0 	b.eq	52f8 <fwp_apply+0xd8>  // b.none
    52e8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52ec:	f90203ff 	str	xzr, [sp, #1024]
    52f0:	eb2163ff 	cmp	sp, x1
    52f4:	54ffffa1 	b.ne	52e8 <fwp_apply+0xc8>  // b.any
    52f8:	92403c00 	and	x0, x0, #0xffff
    52fc:	cb2063ff 	sub	sp, sp, x0
    5300:	f90003ff 	str	xzr, [sp]
    5304:	f110001f 	cmp	x0, #0x400
    5308:	54000942 	b.cs	5430 <fwp_apply+0x210>  // b.hs, b.nlast
    530c:	910020c6 	add	x6, x6, #0x8
    5310:	910043e0 	add	x0, sp, #0x10
    5314:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    5318:	d2800003 	mov	x3, #0x0                   	// #0
    531c:	340000d6 	cbz	w22, 5334 <fwp_apply+0x114>
    5320:	f86368c4 	ldr	x4, [x6, x3]
    5324:	f8236804 	str	x4, [x0, x3]
    5328:	91002063 	add	x3, x3, #0x8
    532c:	eb0300bf 	cmp	x5, x3
    5330:	54ffff81 	b.ne	5320 <fwp_apply+0x100>  // b.any
    5334:	3400013a 	cbz	w26, 5358 <fwp_apply+0x138>
    5338:	2a1a03e6 	mov	w6, w26
    533c:	d2800003 	mov	x3, #0x0                   	// #0
    5340:	0b0302c4 	add	w4, w22, w3
    5344:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5348:	91000463 	add	x3, x3, #0x1
    534c:	f8247805 	str	x5, [x0, x4, lsl #3]
    5350:	eb0300df 	cmp	x6, x3
    5354:	54ffff61 	b.ne	5340 <fwp_apply+0x120>  // b.any
    5358:	f94004e3 	ldr	x3, [x7, #8]
    535c:	1400002c 	b	540c <fwp_apply+0x1ec>
    5360:	11000740 	add	w0, w26, #0x1
    5364:	52800041 	mov	w1, #0x2                   	// #2
    5368:	f81e83a6 	stur	x6, [x29, #-24]
    536c:	d37df000 	lsl	x0, x0, #3
    5370:	97ffff48 	bl	5090 <fwp_heap_alloc>
    5374:	f85e83a6 	ldur	x6, [x29, #-24]
    5378:	aa0003f3 	mov	x19, x0
    537c:	b94000c1 	ldr	w1, [x6]
    5380:	29006801 	stp	w1, w26, [x0]
    5384:	340000b6 	cbz	w22, 5398 <fwp_apply+0x178>
    5388:	910020c1 	add	x1, x6, #0x8
    538c:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5390:	91002000 	add	x0, x0, #0x8
    5394:	97fff4bb 	bl	2680 <memmove@plt>
    5398:	2a1503e3 	mov	w3, w21
    539c:	d2800000 	mov	x0, #0x0                   	// #0
    53a0:	34000135 	cbz	w21, 53c4 <fwp_apply+0x1a4>
    53a4:	d503201f 	nop
    53a8:	0b0002c1 	add	w1, w22, w0
    53ac:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53b0:	8b010e61 	add	x1, x19, x1, lsl #3
    53b4:	91000400 	add	x0, x0, #0x1
    53b8:	f9000422 	str	x2, [x1, #8]
    53bc:	eb00007f 	cmp	x3, x0
    53c0:	54ffff41 	b.ne	53a8 <fwp_apply+0x188>  // b.any
    53c4:	aa1303e6 	mov	x6, x19
    53c8:	d0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    53cc:	f947f400 	ldr	x0, [x0, #4072]
    53d0:	f85f83a2 	ldur	x2, [x29, #-8]
    53d4:	f9400001 	ldr	x1, [x0]
    53d8:	eb010042 	subs	x2, x2, x1
    53dc:	d2800001 	mov	x1, #0x0                   	// #0
    53e0:	540002c1 	b.ne	5438 <fwp_apply+0x218>  // b.any
    53e4:	910003bf 	mov	sp, x29
    53e8:	aa0603e0 	mov	x0, x6
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	d10043a0 	sub	x0, x29, #0x10
    5408:	5280001a 	mov	w26, #0x0                   	// #0
    540c:	d63f0060 	blr	x3
    5410:	aa0003e6 	mov	x6, x0
    5414:	6b1a02bf 	cmp	w21, w26
    5418:	54fffd80 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    541c:	0b1602b6 	add	w22, w21, w22
    5420:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    5424:	4b1902d5 	sub	w21, w22, w25
    5428:	9100031f 	mov	sp, x24
    542c:	17ffff8f 	b	5268 <fwp_apply+0x48>
    5430:	f90203ff 	str	xzr, [sp, #1024]
    5434:	17ffffb6 	b	530c <fwp_apply+0xec>
    5438:	97fff4f6 	bl	2810 <__stack_chk_fail@plt>
    543c:	d503201f 	nop

0000000000005440 <fwp_tape_reserve>:
    5440:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	aa0003f3 	mov	x19, x0
    5450:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5454:	eb00003f 	cmp	x1, x0
    5458:	54000888 	b.hi	5568 <fwp_tape_reserve+0x128>  // b.pmore
    545c:	f9400e74 	ldr	x20, [x19, #24]
    5460:	eb01029f 	cmp	x20, x1
    5464:	5400078a 	b.ge	5554 <fwp_tape_reserve+0x114>  // b.tcont
    5468:	f100029f 	cmp	x20, #0x0
    546c:	d2800802 	mov	x2, #0x40                  	// #64
    5470:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5474:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    5478:	a9025bf5 	stp	x21, x22, [sp, #32]
    547c:	a90363f7 	stp	x23, x24, [sp, #48]
    5480:	eb01029f 	cmp	x20, x1
    5484:	5400008a 	b.ge	5494 <fwp_tape_reserve+0x54>  // b.tcont
    5488:	eb00029f 	cmp	x20, x0
    548c:	540006ad 	b.le	5560 <fwp_tape_reserve+0x120>
    5490:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5494:	a940d663 	ldp	x3, x21, [x19, #8]
    5498:	d37df297 	lsl	x23, x20, #3
    549c:	f9401260 	ldr	x0, [x19, #32]
    54a0:	aa1703e1 	mov	x1, x23
    54a4:	f9403276 	ldr	x22, [x19, #96]
    54a8:	52800022 	mov	w2, #0x1                   	// #1
    54ac:	cb0302b5 	sub	x21, x21, x3
    54b0:	97fffae5 	bl	4044 <ad_raw_realloc>
    54b4:	b4000aa0 	cbz	x0, 5608 <fwp_tape_reserve+0x1c8>
    54b8:	f9400e61 	ldr	x1, [x19, #24]
    54bc:	8b010801 	add	x1, x0, x1, lsl #2
    54c0:	a9020660 	stp	x0, x1, [x19, #32]
    54c4:	b4000856 	cbz	x22, 55cc <fwp_tape_reserve+0x18c>
    54c8:	f94032d7 	ldr	x23, [x22, #96]
    54cc:	eb17029f 	cmp	x20, x23
    54d0:	5400034d 	b.le	5538 <fwp_tape_reserve+0xf8>
    54d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54d8:	d37cee9a 	lsl	x26, x20, #4
    54dc:	aa1a03e0 	mov	x0, x26
    54e0:	f94022d9 	ldr	x25, [x22, #64]
    54e4:	52800041 	mov	w1, #0x2                   	// #2
    54e8:	97fffeea 	bl	5090 <fwp_heap_alloc>
    54ec:	aa0003f8 	mov	x24, x0
    54f0:	b4000119 	cbz	x25, 5510 <fwp_tape_reserve+0xd0>
    54f4:	d37ceef7 	lsl	x23, x23, #4
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	eb1a02ff 	cmp	x23, x26
    5500:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    5504:	97fff457 	bl	2660 <memcpy@plt>
    5508:	aa1903e0 	mov	x0, x25
    550c:	97fffc25 	bl	45a0 <fwp_mem_free>
    5510:	f94032c0 	ldr	x0, [x22, #96]
    5514:	52800001 	mov	w1, #0x0                   	// #0
    5518:	cb000282 	sub	x2, x20, x0
    551c:	8b001300 	add	x0, x24, x0, lsl #4
    5520:	d37cec42 	lsl	x2, x2, #4
    5524:	97fff4af 	bl	27e0 <memset@plt>
    5528:	f9401260 	ldr	x0, [x19, #32]
    552c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5530:	f90022d8 	str	x24, [x22, #64]
    5534:	f90032d4 	str	x20, [x22, #96]
    5538:	d37ef696 	lsl	x22, x20, #2
    553c:	b5000315 	cbnz	x21, 559c <fwp_tape_reserve+0x15c>
    5540:	a94363f7 	ldp	x23, x24, [sp, #48]
    5544:	8b160000 	add	x0, x0, x22
    5548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    554c:	f9000e74 	str	x20, [x19, #24]
    5550:	f9001660 	str	x0, [x19, #40]
    5554:	a94153f3 	ldp	x19, x20, [sp, #16]
    5558:	a8c57bfd 	ldp	x29, x30, [sp], #80
    555c:	d65f03c0 	ret
    5560:	d37ffa94 	lsl	x20, x20, #1
    5564:	17ffffc7 	b	5480 <fwp_tape_reserve+0x40>
    5568:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    556c:	910fe000 	add	x0, x0, #0x3f8
    5570:	a9025bf5 	stp	x21, x22, [sp, #32]
    5574:	a90363f7 	stp	x23, x24, [sp, #48]
    5578:	a9046bf9 	stp	x25, x26, [sp, #64]
    557c:	97fffb4e 	bl	42b4 <fwp_trap>
    5580:	aa0303e0 	mov	x0, x3
    5584:	d37df2a2 	lsl	x2, x21, #3
    5588:	97fff43e 	bl	2680 <memmove@plt>
    558c:	f9401a61 	ldr	x1, [x19, #48]
    5590:	f9401260 	ldr	x0, [x19, #32]
    5594:	8b170021 	add	x1, x1, x23
    5598:	f9001e61 	str	x1, [x19, #56]
    559c:	f9401661 	ldr	x1, [x19, #40]
    55a0:	d37ef696 	lsl	x22, x20, #2
    55a4:	d37ef6a2 	lsl	x2, x21, #2
    55a8:	8b160000 	add	x0, x0, x22
    55ac:	97fff435 	bl	2680 <memmove@plt>
    55b0:	f9401260 	ldr	x0, [x19, #32]
    55b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    55b8:	8b160000 	add	x0, x0, x22
    55bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55c0:	f9000e74 	str	x20, [x19, #24]
    55c4:	f9001660 	str	x0, [x19, #40]
    55c8:	17ffffe3 	b	5554 <fwp_tape_reserve+0x114>
    55cc:	f9401a60 	ldr	x0, [x19, #48]
    55d0:	d37cee81 	lsl	x1, x20, #4
    55d4:	52800042 	mov	w2, #0x2                   	// #2
    55d8:	97fffa9b 	bl	4044 <ad_raw_realloc>
    55dc:	b4000160 	cbz	x0, 5608 <fwp_tape_reserve+0x1c8>
    55e0:	f9400e62 	ldr	x2, [x19, #24]
    55e4:	f9001a60 	str	x0, [x19, #48]
    55e8:	8b170003 	add	x3, x0, x23
    55ec:	8b020c01 	add	x1, x0, x2, lsl #3
    55f0:	f9001e61 	str	x1, [x19, #56]
    55f4:	b5fffc75 	cbnz	x21, 5580 <fwp_tape_reserve+0x140>
    55f8:	f9401260 	ldr	x0, [x19, #32]
    55fc:	d37ef696 	lsl	x22, x20, #2
    5600:	f9001e63 	str	x3, [x19, #56]
    5604:	17ffffcf 	b	5540 <fwp_tape_reserve+0x100>
    5608:	aa1303e0 	mov	x0, x19
    560c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5610:	97fff661 	bl	2f94 <fwp_tape_unlink_scope>
    5614:	f9401260 	ldr	x0, [x19, #32]
    5618:	b4000040 	cbz	x0, 5620 <fwp_tape_reserve+0x1e0>
    561c:	97fffa55 	bl	3f70 <ad_raw_free.part.0>
    5620:	f9401a60 	ldr	x0, [x19, #48]
    5624:	b4000040 	cbz	x0, 562c <fwp_tape_reserve+0x1ec>
    5628:	97fffa52 	bl	3f70 <ad_raw_free.part.0>
    562c:	f9402260 	ldr	x0, [x19, #64]
    5630:	b4000040 	cbz	x0, 5638 <fwp_tape_reserve+0x1f8>
    5634:	97fffa4f 	bl	3f70 <ad_raw_free.part.0>
    5638:	d0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    563c:	f947e821 	ldr	x1, [x1, #4048]
    5640:	f9000e7f 	str	xzr, [x19, #24]
    5644:	4f000400 	movi	v0.4s, #0x0
    5648:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    564c:	d2800262 	mov	x2, #0x13                  	// #19
    5650:	f9400023 	ldr	x3, [x1]
    5654:	b900067f 	str	wzr, [x19, #4]
    5658:	d2800021 	mov	x1, #0x1                   	// #1
    565c:	90000040 	adrp	x0, d000 <f0+0x2460>
    5660:	913be000 	add	x0, x0, #0xef8
    5664:	3c808260 	stur	q0, [x19, #8]
    5668:	ad010260 	stp	q0, q0, [x19, #32]
    566c:	97fff4a9 	bl	2910 <fwrite@plt>
    5670:	d2800000 	mov	x0, #0x0                   	// #0
    5674:	97fff4b3 	bl	2940 <fflush@plt>
    5678:	52800cc0 	mov	w0, #0x66                  	// #102
    567c:	97fff4c1 	bl	2980 <_Exit@plt>

0000000000005680 <f128.constprop.0>:
    5680:	f100001f 	cmp	x0, #0x0
    5684:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5688:	5400094b 	b.lt	57b0 <f128.constprop.0+0x130>  // b.tstop
    568c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5690:	aa0003e2 	mov	x2, x0
    5694:	910003fd 	mov	x29, sp
    5698:	a90153f3 	stp	x19, x20, [sp, #16]
    569c:	aa0003f4 	mov	x20, x0
    56a0:	aa010000 	orr	x0, x0, x1
    56a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56a8:	aa0103f6 	mov	x22, x1
    56ac:	f9001bf7 	str	x23, [sp, #48]
    56b0:	fd001fe8 	str	d8, [sp, #56]
    56b4:	b7f80180 	tbnz	x0, #63, 56e4 <f128.constprop.0+0x64>
    56b8:	9360fc20 	asr	x0, x1, #32
    56bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56c0:	eb82801f 	cmp	x0, x2, asr #32
    56c4:	540007a1 	b.ne	57b8 <f128.constprop.0+0x138>  // b.any
    56c8:	97fffcfe 	bl	4ac0 <fwp_tape_of>
    56cc:	aa0003f3 	mov	x19, x0
    56d0:	f9403000 	ldr	x0, [x0, #96]
    56d4:	b40001e0 	cbz	x0, 5710 <f128.constprop.0+0x90>
    56d8:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    56dc:	91118000 	add	x0, x0, #0x460
    56e0:	97fffaf5 	bl	42b4 <fwp_trap>
    56e4:	9360fc40 	asr	x0, x2, #32
    56e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56ec:	b6fffee2 	tbz	x2, #63, 56c8 <f128.constprop.0+0x48>
    56f0:	2f00e408 	movi	d8, #0x0
    56f4:	9360fc20 	asr	x0, x1, #32
    56f8:	aa0103f4 	mov	x20, x1
    56fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5700:	97fffcf0 	bl	4ac0 <fwp_tape_of>
    5704:	aa0003f3 	mov	x19, x0
    5708:	f9403000 	ldr	x0, [x0, #96]
    570c:	b5fffe60 	cbnz	x0, 56d8 <f128.constprop.0+0x58>
    5710:	f9400a77 	ldr	x23, [x19, #16]
    5714:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5718:	eb0002ff 	cmp	x23, x0
    571c:	5400044c 	b.gt	57a4 <f128.constprop.0+0x124>
    5720:	eb3442ff 	cmp	x23, w20, uxtw
    5724:	5400008d 	b.le	5734 <f128.constprop.0+0xb4>
    5728:	b7f800d6 	tbnz	x22, #63, 5740 <f128.constprop.0+0xc0>
    572c:	eb3642ff 	cmp	x23, w22, uxtw
    5730:	5400008c 	b.gt	5740 <f128.constprop.0+0xc0>
    5734:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    5738:	91124000 	add	x0, x0, #0x490
    573c:	97fffade 	bl	42b4 <fwp_trap>
    5740:	f9400675 	ldr	x21, [x19, #8]
    5744:	aa1303e0 	mov	x0, x19
    5748:	cb1502f5 	sub	x21, x23, x21
    574c:	910006a1 	add	x1, x21, #0x1
    5750:	97ffff3c 	bl	5440 <fwp_tape_reserve>
    5754:	a9420262 	ldp	x2, x0, [x19, #32]
    5758:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    575c:	f9401a61 	ldr	x1, [x19, #48]
    5760:	b8357854 	str	w20, [x2, x21, lsl #2]
    5764:	f9401e62 	ldr	x2, [x19, #56]
    5768:	f10002df 	cmp	x22, #0x0
    576c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5770:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5774:	b8357816 	str	w22, [x0, x21, lsl #2]
    5778:	92607e80 	and	x0, x20, #0xffffffff00000000
    577c:	910006e1 	add	x1, x23, #0x1
    5780:	aa170000 	orr	x0, x0, x23
    5784:	fc357848 	str	d8, [x2, x21, lsl #3]
    5788:	a9425bf5 	ldp	x21, x22, [sp, #32]
    578c:	f9401bf7 	ldr	x23, [sp, #48]
    5790:	fd401fe8 	ldr	d8, [sp, #56]
    5794:	f9000a61 	str	x1, [x19, #16]
    5798:	a94153f3 	ldp	x19, x20, [sp, #16]
    579c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57a0:	d65f03c0 	ret
    57a4:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    57a8:	910fe000 	add	x0, x0, #0x3f8
    57ac:	97fffac2 	bl	42b4 <fwp_trap>
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	d65f03c0 	ret
    57b8:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    57bc:	91106000 	add	x0, x0, #0x418
    57c0:	97fffabd 	bl	42b4 <fwp_trap>

00000000000057c4 <w107>:
    57c4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    57d4:	aa0003f5 	mov	x21, x0
    57d8:	a90363f7 	stp	x23, x24, [sp, #48]
    57dc:	aa0103f7 	mov	x23, x1
    57e0:	a9046bf9 	stp	x25, x26, [sp, #64]
    57e4:	f9002bfb 	str	x27, [sp, #80]
    57e8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57ec:	1e604028 	fmov	d8, d1
    57f0:	1e600809 	fmul	d9, d0, d0
    57f4:	6d072fea 	stp	d10, d11, [sp, #112]
    57f8:	1e60400b 	fmov	d11, d0
    57fc:	b7f81c80 	tbnz	x0, #63, 5b8c <w107+0x3c8>
    5800:	9360fc19 	asr	x25, x0, #32
    5804:	aa1903e0 	mov	x0, x25
    5808:	97fffcae 	bl	4ac0 <fwp_tape_of>
    580c:	f9403001 	ldr	x1, [x0, #96]
    5810:	aa0003f3 	mov	x19, x0
    5814:	b4000081 	cbz	x1, 5824 <w107+0x60>
    5818:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    581c:	91118000 	add	x0, x0, #0x460
    5820:	97fffaa5 	bl	42b4 <fwp_trap>
    5824:	f9400818 	ldr	x24, [x0, #16]
    5828:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    582c:	eb01031f 	cmp	x24, x1
    5830:	54001a8c 	b.gt	5b80 <w107+0x3bc>
    5834:	eb35431f 	cmp	x24, w21, uxtw
    5838:	540019ed 	b.le	5b74 <w107+0x3b0>
    583c:	f9400416 	ldr	x22, [x0, #8]
    5840:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5844:	aa180294 	orr	x20, x20, x24
    5848:	cb160316 	sub	x22, x24, x22
    584c:	910006c1 	add	x1, x22, #0x1
    5850:	97fffefc 	bl	5440 <fwp_tape_reserve>
    5854:	a9420a61 	ldp	x1, x2, [x19, #32]
    5858:	91000700 	add	x0, x24, #0x1
    585c:	f9401a63 	ldr	x3, [x19, #48]
    5860:	b8367835 	str	w21, [x1, x22, lsl #2]
    5864:	f9401e61 	ldr	x1, [x19, #56]
    5868:	1e693908 	fsub	d8, d8, d9
    586c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5870:	9360fe9a 	asr	x26, x20, #32
    5874:	b8367855 	str	w21, [x2, x22, lsl #2]
    5878:	fc36782b 	str	d11, [x1, x22, lsl #3]
    587c:	f9000a60 	str	x0, [x19, #16]
    5880:	b7f80077 	tbnz	x23, #63, 588c <w107+0xc8>
    5884:	eb97835f 	cmp	x26, x23, asr #32
    5888:	540019a1 	b.ne	5bbc <w107+0x3f8>  // b.any
    588c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5890:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5894:	eb19035f 	cmp	x26, x25
    5898:	540000c0 	b.eq	58b0 <w107+0xec>  // b.none
    589c:	aa1a03e0 	mov	x0, x26
    58a0:	97fffc88 	bl	4ac0 <fwp_tape_of>
    58a4:	aa0003f3 	mov	x19, x0
    58a8:	f9403000 	ldr	x0, [x0, #96]
    58ac:	b5fffb60 	cbnz	x0, 5818 <w107+0x54>
    58b0:	f9400a79 	ldr	x25, [x19, #16]
    58b4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58b8:	eb00033f 	cmp	x25, x0
    58bc:	5400162c 	b.gt	5b80 <w107+0x3bc>
    58c0:	eb34433f 	cmp	x25, w20, uxtw
    58c4:	5400158d 	b.le	5b74 <w107+0x3b0>
    58c8:	b7f80077 	tbnz	x23, #63, 58d4 <w107+0x110>
    58cc:	eb37433f 	cmp	x25, w23, uxtw
    58d0:	5400152d 	b.le	5b74 <w107+0x3b0>
    58d4:	f9400676 	ldr	x22, [x19, #8]
    58d8:	aa1303e0 	mov	x0, x19
    58dc:	cb160336 	sub	x22, x25, x22
    58e0:	910006c1 	add	x1, x22, #0x1
    58e4:	97fffed7 	bl	5440 <fwp_tape_reserve>
    58e8:	a9420e62 	ldp	x2, x3, [x19, #32]
    58ec:	f10002ff 	cmp	x23, #0x0
    58f0:	f9401a61 	ldr	x1, [x19, #48]
    58f4:	b8367854 	str	w20, [x2, x22, lsl #2]
    58f8:	f9401e62 	ldr	x2, [x19, #56]
    58fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5900:	fc367829 	str	d9, [x1, x22, lsl #3]
    5904:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5908:	b8367861 	str	w1, [x3, x22, lsl #2]
    590c:	91000737 	add	x23, x25, #0x1
    5910:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5914:	92607e94 	and	x20, x20, #0xffffffff00000000
    5918:	fc36784a 	str	d10, [x2, x22, lsl #3]
    591c:	aa190294 	orr	x20, x20, x25
    5920:	f9000a77 	str	x23, [x19, #16]
    5924:	1e6b3929 	fsub	d9, d9, d11
    5928:	b7f81675 	tbnz	x21, #63, 5bf4 <w107+0x430>
    592c:	9360febb 	asr	x27, x21, #32
    5930:	eb1a037f 	cmp	x27, x26
    5934:	540000e0 	b.eq	5950 <w107+0x18c>  // b.none
    5938:	aa1b03e0 	mov	x0, x27
    593c:	97fffc61 	bl	4ac0 <fwp_tape_of>
    5940:	aa0003f3 	mov	x19, x0
    5944:	f9403000 	ldr	x0, [x0, #96]
    5948:	b5fff680 	cbnz	x0, 5818 <w107+0x54>
    594c:	f9400a77 	ldr	x23, [x19, #16]
    5950:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5954:	eb0002ff 	cmp	x23, x0
    5958:	5400114c 	b.gt	5b80 <w107+0x3bc>
    595c:	eb3542ff 	cmp	x23, w21, uxtw
    5960:	540010ad 	b.le	5b74 <w107+0x3b0>
    5964:	f9400676 	ldr	x22, [x19, #8]
    5968:	aa1303e0 	mov	x0, x19
    596c:	cb1602f6 	sub	x22, x23, x22
    5970:	910006c1 	add	x1, x22, #0x1
    5974:	97fffeb3 	bl	5440 <fwp_tape_reserve>
    5978:	a9420261 	ldp	x1, x0, [x19, #32]
    597c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5980:	f9401a63 	ldr	x3, [x19, #48]
    5984:	b8367835 	str	w21, [x1, x22, lsl #2]
    5988:	f9401e61 	ldr	x1, [x19, #56]
    598c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5990:	fc367860 	str	d0, [x3, x22, lsl #3]
    5994:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5998:	b8367802 	str	w2, [x0, x22, lsl #2]
    599c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    59a0:	910006e0 	add	x0, x23, #0x1
    59a4:	aa1702b7 	orr	x23, x21, x23
    59a8:	fc367820 	str	d0, [x1, x22, lsl #3]
    59ac:	f9000a60 	str	x0, [x19, #16]
    59b0:	9360fe99 	asr	x25, x20, #32
    59b4:	1e68090a 	fmul	d10, d8, d8
    59b8:	eb1b033f 	cmp	x25, x27
    59bc:	540000c0 	b.eq	59d4 <w107+0x210>  // b.none
    59c0:	aa1903e0 	mov	x0, x25
    59c4:	97fffc3f 	bl	4ac0 <fwp_tape_of>
    59c8:	aa0003f3 	mov	x19, x0
    59cc:	f9403000 	ldr	x0, [x0, #96]
    59d0:	b5fff240 	cbnz	x0, 5818 <w107+0x54>
    59d4:	f9400a75 	ldr	x21, [x19, #16]
    59d8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59dc:	eb0002bf 	cmp	x21, x0
    59e0:	54000d0c 	b.gt	5b80 <w107+0x3bc>
    59e4:	eb3442bf 	cmp	x21, w20, uxtw
    59e8:	54000c6d 	b.le	5b74 <w107+0x3b0>
    59ec:	f9400678 	ldr	x24, [x19, #8]
    59f0:	aa1303e0 	mov	x0, x19
    59f4:	92607e96 	and	x22, x20, #0xffffffff00000000
    59f8:	cb1802b8 	sub	x24, x21, x24
    59fc:	aa1502d6 	orr	x22, x22, x21
    5a00:	91000701 	add	x1, x24, #0x1
    5a04:	97fffe8f 	bl	5440 <fwp_tape_reserve>
    5a08:	a9420261 	ldp	x1, x0, [x19, #32]
    5a0c:	f9401a62 	ldr	x2, [x19, #48]
    5a10:	b8387834 	str	w20, [x1, x24, lsl #2]
    5a14:	f9401e61 	ldr	x1, [x19, #56]
    5a18:	fc387848 	str	d8, [x2, x24, lsl #3]
    5a1c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5a20:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a24:	9e670000 	fmov	d0, x0
    5a28:	910006b4 	add	x20, x21, #0x1
    5a2c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5a30:	9360fed8 	asr	x24, x22, #32
    5a34:	f9000a74 	str	x20, [x19, #16]
    5a38:	1e60094a 	fmul	d10, d10, d0
    5a3c:	eb19031f 	cmp	x24, x25
    5a40:	540000e0 	b.eq	5a5c <w107+0x298>  // b.none
    5a44:	aa1803e0 	mov	x0, x24
    5a48:	97fffc1e 	bl	4ac0 <fwp_tape_of>
    5a4c:	aa0003f3 	mov	x19, x0
    5a50:	f9403000 	ldr	x0, [x0, #96]
    5a54:	b5ffee20 	cbnz	x0, 5818 <w107+0x54>
    5a58:	f9400a74 	ldr	x20, [x19, #16]
    5a5c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a60:	eb00029f 	cmp	x20, x0
    5a64:	540008ec 	b.gt	5b80 <w107+0x3bc>
    5a68:	eb36429f 	cmp	x20, w22, uxtw
    5a6c:	5400084d 	b.le	5b74 <w107+0x3b0>
    5a70:	f9400675 	ldr	x21, [x19, #8]
    5a74:	aa1303e0 	mov	x0, x19
    5a78:	cb150295 	sub	x21, x20, x21
    5a7c:	910006a1 	add	x1, x21, #0x1
    5a80:	97fffe70 	bl	5440 <fwp_tape_reserve>
    5a84:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a88:	9e670000 	fmov	d0, x0
    5a8c:	a9420261 	ldp	x1, x0, [x19, #32]
    5a90:	1e690928 	fmul	d8, d9, d9
    5a94:	f9401a62 	ldr	x2, [x19, #48]
    5a98:	b8357836 	str	w22, [x1, x21, lsl #2]
    5a9c:	f9401e61 	ldr	x1, [x19, #56]
    5aa0:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5aa4:	fc357840 	str	d0, [x2, x21, lsl #3]
    5aa8:	12800002 	mov	w2, #0xffffffff            	// #-1
    5aac:	b8357802 	str	w2, [x0, x21, lsl #2]
    5ab0:	91000680 	add	x0, x20, #0x1
    5ab4:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5ab8:	aa1402d6 	orr	x22, x22, x20
    5abc:	f9000a60 	str	x0, [x19, #16]
    5ac0:	b10006ff 	cmn	x23, #0x1
    5ac4:	540009e0 	b.eq	5c00 <w107+0x43c>  // b.none
    5ac8:	9360fee0 	asr	x0, x23, #32
    5acc:	eb18001f 	cmp	x0, x24
    5ad0:	540000a0 	b.eq	5ae4 <w107+0x320>  // b.none
    5ad4:	97fffbfb 	bl	4ac0 <fwp_tape_of>
    5ad8:	aa0003f3 	mov	x19, x0
    5adc:	f9403000 	ldr	x0, [x0, #96]
    5ae0:	b5ffe9c0 	cbnz	x0, 5818 <w107+0x54>
    5ae4:	f9400a74 	ldr	x20, [x19, #16]
    5ae8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5aec:	eb00029f 	cmp	x20, x0
    5af0:	5400048c 	b.gt	5b80 <w107+0x3bc>
    5af4:	eb37429f 	cmp	x20, w23, uxtw
    5af8:	540003ed 	b.le	5b74 <w107+0x3b0>
    5afc:	f9400675 	ldr	x21, [x19, #8]
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	cb150295 	sub	x21, x20, x21
    5b08:	910006a1 	add	x1, x21, #0x1
    5b0c:	97fffe4d 	bl	5440 <fwp_tape_reserve>
    5b10:	a9420a61 	ldp	x1, x2, [x19, #32]
    5b14:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b18:	f9401a63 	ldr	x3, [x19, #48]
    5b1c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5b20:	f9401e61 	ldr	x1, [x19, #56]
    5b24:	aa140000 	orr	x0, x0, x20
    5b28:	fc357869 	str	d9, [x3, x21, lsl #3]
    5b2c:	91000694 	add	x20, x20, #0x1
    5b30:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b34:	fc357829 	str	d9, [x1, x21, lsl #3]
    5b38:	f9000a74 	str	x20, [x19, #16]
    5b3c:	1e6a2908 	fadd	d8, d8, d10
    5b40:	aa1603e1 	mov	x1, x22
    5b44:	97fffecf 	bl	5680 <f128.constprop.0>
    5b48:	aa0003e1 	mov	x1, x0
    5b4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b50:	9e660100 	fmov	x0, d8
    5b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b58:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b5c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5b60:	f9402bfb 	ldr	x27, [sp, #80]
    5b64:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5b68:	6d472fea 	ldp	d10, d11, [sp, #112]
    5b6c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5b70:	d65f03c0 	ret
    5b74:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    5b78:	91124000 	add	x0, x0, #0x490
    5b7c:	97fff9ce 	bl	42b4 <fwp_trap>
    5b80:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    5b84:	910fe000 	add	x0, x0, #0x3f8
    5b88:	97fff9cb 	bl	42b4 <fwp_trap>
    5b8c:	1e693828 	fsub	d8, d1, d9
    5b90:	b6f801c1 	tbz	x1, #63, 5bc8 <w107+0x404>
    5b94:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5b98:	1e68090a 	fmul	d10, d8, d8
    5b9c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5ba0:	9e670000 	fmov	d0, x0
    5ba4:	1e6b3828 	fsub	d8, d1, d11
    5ba8:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5bac:	aa1603e0 	mov	x0, x22
    5bb0:	1e60094a 	fmul	d10, d10, d0
    5bb4:	1e680908 	fmul	d8, d8, d8
    5bb8:	17ffffe1 	b	5b3c <w107+0x378>
    5bbc:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    5bc0:	91106000 	add	x0, x0, #0x418
    5bc4:	97fff9bc 	bl	42b4 <fwp_trap>
    5bc8:	2f00e40a 	movi	d10, #0x0
    5bcc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5bd0:	9360fc3a 	asr	x26, x1, #32
    5bd4:	aa0103f4 	mov	x20, x1
    5bd8:	aa1a03e0 	mov	x0, x26
    5bdc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5be0:	97fffbb8 	bl	4ac0 <fwp_tape_of>
    5be4:	aa0003f3 	mov	x19, x0
    5be8:	f9403000 	ldr	x0, [x0, #96]
    5bec:	b5ffe160 	cbnz	x0, 5818 <w107+0x54>
    5bf0:	17ffff30 	b	58b0 <w107+0xec>
    5bf4:	aa1a03fb 	mov	x27, x26
    5bf8:	aa0003f7 	mov	x23, x0
    5bfc:	17ffff6d 	b	59b0 <w107+0x1ec>
    5c00:	aa1703e0 	mov	x0, x23
    5c04:	17ffffce 	b	5b3c <w107+0x378>
    5c08:	d503201f 	nop
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_data.part.0.constprop.0>:
    5c10:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5c14:	910003fd 	mov	x29, sp
    5c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    5c1c:	f0000156 	adrp	x22, 30000 <__data_start>
    5c20:	910182c2 	add	x2, x22, #0x60
    5c24:	a9046bf9 	stp	x25, x26, [sp, #64]
    5c28:	b9413059 	ldr	w25, [x2, #304]
    5c2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5c30:	aa0103f4 	mov	x20, x1
    5c34:	a90363f7 	stp	x23, x24, [sp, #48]
    5c38:	2a0003f7 	mov	w23, w0
    5c3c:	340000b9 	cbz	w25, 5c50 <fwp_data.part.0.constprop.0+0x40>
    5c40:	a9538041 	ldp	x1, x0, [x2, #312]
    5c44:	91000421 	add	x1, x1, #0x1
    5c48:	91006000 	add	x0, x0, #0x18
    5c4c:	a9138041 	stp	x1, x0, [x2, #312]
    5c50:	90000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    5c54:	911902a3 	add	x3, x21, #0x640
    5c58:	b953a460 	ldr	w0, [x3, #5028]
    5c5c:	34000840 	cbz	w0, 5d64 <fwp_data.part.0.constprop.0+0x154>
    5c60:	397e8862 	ldrb	w2, [x3, #4002]
    5c64:	910f0040 	add	x0, x2, #0x3c0
    5c68:	8b020442 	add	x2, x2, x2, lsl #1
    5c6c:	d37df042 	lsl	x2, x2, #3
    5c70:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5c74:	2a1a03f8 	mov	w24, w26
    5c78:	f8626873 	ldr	x19, [x3, x2]
    5c7c:	b4000613 	cbz	x19, 5d3c <fwp_data.part.0.constprop.0+0x12c>
    5c80:	f9400260 	ldr	x0, [x19]
    5c84:	aa2003e0 	mvn	x0, x0
    5c88:	f8226860 	str	x0, [x3, x2]
    5c8c:	f100631f 	cmp	x24, #0x18
    5c90:	540000e9 	b.ls	5cac <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5c94:	d1006702 	sub	x2, x24, #0x19
    5c98:	91006260 	add	x0, x19, #0x18
    5c9c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5ca0:	52800001 	mov	w1, #0x0                   	// #0
    5ca4:	91002042 	add	x2, x2, #0x8
    5ca8:	97fff2ce 	bl	27e0 <memset@plt>
    5cac:	911902a0 	add	x0, x21, #0x640
    5cb0:	f94a1001 	ldr	x1, [x0, #5152]
    5cb4:	ab180021 	adds	x1, x1, x24
    5cb8:	54000682 	b.cs	5d88 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    5cbc:	f94a1402 	ldr	x2, [x0, #5160]
    5cc0:	f90a1001 	str	x1, [x0, #5152]
    5cc4:	eb02003f 	cmp	x1, x2
    5cc8:	54000049 	b.ls	5cd0 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5ccc:	f90a1401 	str	x1, [x0, #5160]
    5cd0:	911902a0 	add	x0, x21, #0x640
    5cd4:	1e630341 	ucvtf	d1, w26
    5cd8:	fd4a1c00 	ldr	d0, [x0, #5176]
    5cdc:	1e612800 	fadd	d0, d0, d1
    5ce0:	fd0a1c00 	str	d0, [x0, #5176]
    5ce4:	34000139 	cbz	w25, 5d08 <fwp_data.part.0.constprop.0+0xf8>
    5ce8:	911902b5 	add	x21, x21, #0x640
    5cec:	910182d6 	add	x22, x22, #0x60
    5cf0:	fd4a12a0 	ldr	d0, [x21, #5152]
    5cf4:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5cf8:	7e61d800 	ucvtf	d0, d0
    5cfc:	1e623800 	fsub	d0, d0, d2
    5d00:	1e612010 	fcmpe	d0, d1
    5d04:	540003ec 	b.gt	5d80 <fwp_data.part.0.constprop.0+0x170>
    5d08:	52800040 	mov	w0, #0x2                   	// #2
    5d0c:	29000277 	stp	w23, w0, [x19]
    5d10:	aa1303e0 	mov	x0, x19
    5d14:	f9400281 	ldr	x1, [x20]
    5d18:	f9000661 	str	x1, [x19, #8]
    5d1c:	f9400681 	ldr	x1, [x20, #8]
    5d20:	f9000a61 	str	x1, [x19, #16]
    5d24:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5d2c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5d30:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5d34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5d38:	d65f03c0 	ret
    5d3c:	8b020063 	add	x3, x3, x2
    5d40:	f9400473 	ldr	x19, [x3, #8]
    5d44:	b4000113 	cbz	x19, 5d64 <fwp_data.part.0.constprop.0+0x154>
    5d48:	f9400860 	ldr	x0, [x3, #16]
    5d4c:	cb130000 	sub	x0, x0, x19
    5d50:	eb00031f 	cmp	x24, x0
    5d54:	54000088 	b.hi	5d64 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5d58:	8b180260 	add	x0, x19, x24
    5d5c:	f9000460 	str	x0, [x3, #8]
    5d60:	17ffffcb 	b	5c8c <fwp_data.part.0.constprop.0+0x7c>
    5d64:	52800001 	mov	w1, #0x0                   	// #0
    5d68:	d2800300 	mov	x0, #0x18                  	// #24
    5d6c:	97fffcc9 	bl	5090 <fwp_heap_alloc>
    5d70:	aa0003f3 	mov	x19, x0
    5d74:	910182c1 	add	x1, x22, #0x60
    5d78:	b9413039 	ldr	w25, [x1, #304]
    5d7c:	17ffffda 	b	5ce4 <fwp_data.part.0.constprop.0+0xd4>
    5d80:	fd00aac0 	str	d0, [x22, #336]
    5d84:	17ffffe1 	b	5d08 <fwp_data.part.0.constprop.0+0xf8>
    5d88:	97fff4da 	bl	30f0 <fwp_heap_oom>
    5d8c:	d503201f 	nop

0000000000005d90 <fwp_rc_share>:
    5d90:	90000422 	adrp	x2, 89000 <fwp_root_context+0xba0>
    5d94:	91190042 	add	x2, x2, #0x640
    5d98:	f949d843 	ldr	x3, [x2, #5040]
    5d9c:	f949ec41 	ldr	x1, [x2, #5080]
    5da0:	cb030000 	sub	x0, x0, x3
    5da4:	eb01401f 	cmp	x0, x1, lsl #16
    5da8:	540003a2 	b.cs	5e1c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5dac:	d350fc01 	lsr	x1, x0, #16
    5db0:	f949fc44 	ldr	x4, [x2, #5112]
    5db4:	8b010821 	add	x1, x1, x1, lsl #2
    5db8:	d37df021 	lsl	x1, x1, #3
    5dbc:	8b010083 	add	x3, x4, x1
    5dc0:	f9401062 	ldr	x2, [x3, #32]
    5dc4:	b40002c2 	cbz	x2, 5e1c <fwp_rc_share+0x8c>
    5dc8:	38616881 	ldrb	w1, [x4, x1]
    5dcc:	7100083f 	cmp	w1, #0x2
    5dd0:	54000220 	b.eq	5e14 <fwp_rc_share+0x84>  // b.none
    5dd4:	7100043f 	cmp	w1, #0x1
    5dd8:	54000221 	b.ne	5e1c <fwp_rc_share+0x8c>  // b.any
    5ddc:	29430464 	ldp	w4, w1, [x3, #24]
    5de0:	92403c00 	and	x0, x0, #0xffff
    5de4:	9b047c00 	mul	x0, x0, x4
    5de8:	d360fc00 	lsr	x0, x0, #32
    5dec:	eb01001f 	cmp	x0, x1
    5df0:	54000162 	b.cs	5e1c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5df4:	8b000042 	add	x2, x2, x0
    5df8:	39400040 	ldrb	w0, [x2]
    5dfc:	34000100 	cbz	w0, 5e1c <fwp_rc_share+0x8c>
    5e00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5e04:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    5e08:	9112c000 	add	x0, x0, #0x4b0
    5e0c:	910003fd 	mov	x29, sp
    5e10:	97fff929 	bl	42b4 <fwp_trap>
    5e14:	72003c1f 	tst	w0, #0xffff
    5e18:	54ffff00 	b.eq	5df8 <fwp_rc_share+0x68>  // b.none
    5e1c:	d65f03c0 	ret

0000000000005e20 <fwp_rc_fresh>:
    5e20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e24:	90000423 	adrp	x3, 89000 <fwp_root_context+0xba0>
    5e28:	91190063 	add	x3, x3, #0x640
    5e2c:	910003fd 	mov	x29, sp
    5e30:	a90153f3 	stp	x19, x20, [sp, #16]
    5e34:	aa0003f3 	mov	x19, x0
    5e38:	f949d861 	ldr	x1, [x3, #5040]
    5e3c:	f949ec60 	ldr	x0, [x3, #5080]
    5e40:	cb010261 	sub	x1, x19, x1
    5e44:	eb00403f 	cmp	x1, x0, lsl #16
    5e48:	54000322 	b.cs	5eac <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5e4c:	d350fc22 	lsr	x2, x1, #16
    5e50:	f949fc63 	ldr	x3, [x3, #5112]
    5e54:	8b020842 	add	x2, x2, x2, lsl #2
    5e58:	d37df042 	lsl	x2, x2, #3
    5e5c:	8b020060 	add	x0, x3, x2
    5e60:	f9401014 	ldr	x20, [x0, #32]
    5e64:	b4000254 	cbz	x20, 5eac <fwp_rc_fresh+0x8c>
    5e68:	38626862 	ldrb	w2, [x3, x2]
    5e6c:	7100085f 	cmp	w2, #0x2
    5e70:	54000260 	b.eq	5ebc <fwp_rc_fresh+0x9c>  // b.none
    5e74:	7100045f 	cmp	w2, #0x1
    5e78:	540001a1 	b.ne	5eac <fwp_rc_fresh+0x8c>  // b.any
    5e7c:	29430002 	ldp	w2, w0, [x0, #24]
    5e80:	92403c21 	and	x1, x1, #0xffff
    5e84:	9b027c21 	mul	x1, x1, x2
    5e88:	d360fc21 	lsr	x1, x1, #32
    5e8c:	eb00003f 	cmp	x1, x0
    5e90:	540000e2 	b.cs	5eac <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5e94:	8b010294 	add	x20, x20, x1
    5e98:	39400280 	ldrb	w0, [x20]
    5e9c:	7103fc1f 	cmp	w0, #0xff
    5ea0:	540001a0 	b.eq	5ed4 <fwp_rc_fresh+0xb4>  // b.none
    5ea4:	52800020 	mov	w0, #0x1                   	// #1
    5ea8:	39000280 	strb	w0, [x20]
    5eac:	aa1303e0 	mov	x0, x19
    5eb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5eb4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb8:	d65f03c0 	ret
    5ebc:	72003c3f 	tst	w1, #0xffff
    5ec0:	54fffec0 	b.eq	5e98 <fwp_rc_fresh+0x78>  // b.none
    5ec4:	aa1303e0 	mov	x0, x19
    5ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	d65f03c0 	ret
    5ed4:	aa1403e0 	mov	x0, x20
    5ed8:	97fff917 	bl	4334 <fwp_rc_forget_slot.part.0>
    5edc:	17fffff2 	b	5ea4 <fwp_rc_fresh+0x84>

0000000000005ee0 <fwp_rc_free_arr>:
    5ee0:	90000423 	adrp	x3, 89000 <fwp_root_context+0xba0>
    5ee4:	91190063 	add	x3, x3, #0x640
    5ee8:	f949d861 	ldr	x1, [x3, #5040]
    5eec:	f949ec62 	ldr	x2, [x3, #5080]
    5ef0:	cb010001 	sub	x1, x0, x1
    5ef4:	eb02403f 	cmp	x1, x2, lsl #16
    5ef8:	54000342 	b.cs	5f60 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5efc:	d350fc22 	lsr	x2, x1, #16
    5f00:	f949fc65 	ldr	x5, [x3, #5112]
    5f04:	8b020842 	add	x2, x2, x2, lsl #2
    5f08:	d37df042 	lsl	x2, x2, #3
    5f0c:	8b0200a4 	add	x4, x5, x2
    5f10:	f9401083 	ldr	x3, [x4, #32]
    5f14:	b4000263 	cbz	x3, 5f60 <fwp_rc_free_arr+0x80>
    5f18:	386268a2 	ldrb	w2, [x5, x2]
    5f1c:	7100085f 	cmp	w2, #0x2
    5f20:	540001c0 	b.eq	5f58 <fwp_rc_free_arr+0x78>  // b.none
    5f24:	7100045f 	cmp	w2, #0x1
    5f28:	540001c1 	b.ne	5f60 <fwp_rc_free_arr+0x80>  // b.any
    5f2c:	29430885 	ldp	w5, w2, [x4, #24]
    5f30:	92403c21 	and	x1, x1, #0xffff
    5f34:	9b057c21 	mul	x1, x1, x5
    5f38:	d360fc21 	lsr	x1, x1, #32
    5f3c:	eb02003f 	cmp	x1, x2
    5f40:	54000102 	b.cs	5f60 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5f44:	8b010063 	add	x3, x3, x1
    5f48:	39400061 	ldrb	w1, [x3]
    5f4c:	7100043f 	cmp	w1, #0x1
    5f50:	54000081 	b.ne	5f60 <fwp_rc_free_arr+0x80>  // b.any
    5f54:	17fff993 	b	45a0 <fwp_mem_free>
    5f58:	72003c3f 	tst	w1, #0xffff
    5f5c:	54ffff60 	b.eq	5f48 <fwp_rc_free_arr+0x68>  // b.none
    5f60:	d65f03c0 	ret

0000000000005f64 <fwp_rc_dup>:
    5f64:	90000422 	adrp	x2, 89000 <fwp_root_context+0xba0>
    5f68:	91190042 	add	x2, x2, #0x640
    5f6c:	f949d841 	ldr	x1, [x2, #5040]
    5f70:	f949ec43 	ldr	x3, [x2, #5080]
    5f74:	cb010001 	sub	x1, x0, x1
    5f78:	eb03403f 	cmp	x1, x3, lsl #16
    5f7c:	540003c2 	b.cs	5ff4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f80:	d350fc20 	lsr	x0, x1, #16
    5f84:	f949fc44 	ldr	x4, [x2, #5112]
    5f88:	8b000800 	add	x0, x0, x0, lsl #2
    5f8c:	d37df002 	lsl	x2, x0, #3
    5f90:	8b020083 	add	x3, x4, x2
    5f94:	f9401060 	ldr	x0, [x3, #32]
    5f98:	b40002e0 	cbz	x0, 5ff4 <fwp_rc_dup+0x90>
    5f9c:	38626882 	ldrb	w2, [x4, x2]
    5fa0:	7100085f 	cmp	w2, #0x2
    5fa4:	540002a0 	b.eq	5ff8 <fwp_rc_dup+0x94>  // b.none
    5fa8:	7100045f 	cmp	w2, #0x1
    5fac:	54000241 	b.ne	5ff4 <fwp_rc_dup+0x90>  // b.any
    5fb0:	29430864 	ldp	w4, w2, [x3, #24]
    5fb4:	92403c21 	and	x1, x1, #0xffff
    5fb8:	9b047c21 	mul	x1, x1, x4
    5fbc:	d360fc21 	lsr	x1, x1, #32
    5fc0:	eb02003f 	cmp	x1, x2
    5fc4:	54000182 	b.cs	5ff4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5fc8:	8b010000 	add	x0, x0, x1
    5fcc:	39400001 	ldrb	w1, [x0]
    5fd0:	34000121 	cbz	w1, 5ff4 <fwp_rc_dup+0x90>
    5fd4:	f0000142 	adrp	x2, 30000 <__data_start>
    5fd8:	91018042 	add	x2, x2, #0x60
    5fdc:	b9413043 	ldr	w3, [x2, #304]
    5fe0:	35000123 	cbnz	w3, 6004 <fwp_rc_dup+0xa0>
    5fe4:	7103f43f 	cmp	w1, #0xfd
    5fe8:	54000168 	b.hi	6014 <fwp_rc_dup+0xb0>  // b.pmore
    5fec:	11000421 	add	w1, w1, #0x1
    5ff0:	39000001 	strb	w1, [x0]
    5ff4:	d65f03c0 	ret
    5ff8:	72003c3f 	tst	w1, #0xffff
    5ffc:	54fffe80 	b.eq	5fcc <fwp_rc_dup+0x68>  // b.none
    6000:	d65f03c0 	ret
    6004:	f940ac43 	ldr	x3, [x2, #344]
    6008:	91000463 	add	x3, x3, #0x1
    600c:	f900ac43 	str	x3, [x2, #344]
    6010:	17fffff5 	b	5fe4 <fwp_rc_dup+0x80>
    6014:	17fff9dc 	b	4784 <fwp_rc_wide_dup>
    6018:	d503201f 	nop
    601c:	d503201f 	nop

0000000000006020 <fwp_owned_entry161>:
    6020:	d10103ff 	sub	sp, sp, #0x40
    6024:	b0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    6028:	f947f442 	ldr	x2, [x2, #4072]
    602c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6030:	910083fd 	add	x29, sp, #0x20
    6034:	a90353f3 	stp	x19, x20, [sp, #48]
    6038:	f9400043 	ldr	x3, [x2]
    603c:	f9000fe3 	str	x3, [sp, #24]
    6040:	d2800003 	mov	x3, #0x0                   	// #0
    6044:	a9400c01 	ldp	x1, x3, [x0]
    6048:	f9400802 	ldr	x2, [x0, #16]
    604c:	ab020022 	adds	x2, x1, x2
    6050:	540006e6 	b.vs	612c <fwp_owned_entry161+0x10c>
    6054:	910023e1 	add	x1, sp, #0x8
    6058:	52800000 	mov	w0, #0x0                   	// #0
    605c:	a9008be3 	stp	x3, x2, [sp, #8]
    6060:	97fffeec 	bl	5c10 <fwp_data.part.0.constprop.0>
    6064:	f0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    6068:	91190063 	add	x3, x3, #0x640
    606c:	aa0003f3 	mov	x19, x0
    6070:	f949d861 	ldr	x1, [x3, #5040]
    6074:	f949ec60 	ldr	x0, [x3, #5080]
    6078:	cb010261 	sub	x1, x19, x1
    607c:	eb00403f 	cmp	x1, x0, lsl #16
    6080:	54000322 	b.cs	60e4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    6084:	d350fc22 	lsr	x2, x1, #16
    6088:	f949fc63 	ldr	x3, [x3, #5112]
    608c:	8b020842 	add	x2, x2, x2, lsl #2
    6090:	d37df042 	lsl	x2, x2, #3
    6094:	8b020060 	add	x0, x3, x2
    6098:	f9401014 	ldr	x20, [x0, #32]
    609c:	b4000254 	cbz	x20, 60e4 <fwp_owned_entry161+0xc4>
    60a0:	38626862 	ldrb	w2, [x3, x2]
    60a4:	7100085f 	cmp	w2, #0x2
    60a8:	54000360 	b.eq	6114 <fwp_owned_entry161+0xf4>  // b.none
    60ac:	7100045f 	cmp	w2, #0x1
    60b0:	540001a1 	b.ne	60e4 <fwp_owned_entry161+0xc4>  // b.any
    60b4:	29430002 	ldp	w2, w0, [x0, #24]
    60b8:	92403c21 	and	x1, x1, #0xffff
    60bc:	9b027c21 	mul	x1, x1, x2
    60c0:	d360fc21 	lsr	x1, x1, #32
    60c4:	eb00003f 	cmp	x1, x0
    60c8:	540000e2 	b.cs	60e4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    60cc:	8b010294 	add	x20, x20, x1
    60d0:	39400280 	ldrb	w0, [x20]
    60d4:	7103fc1f 	cmp	w0, #0xff
    60d8:	54000240 	b.eq	6120 <fwp_owned_entry161+0x100>  // b.none
    60dc:	52800020 	mov	w0, #0x1                   	// #1
    60e0:	39000280 	strb	w0, [x20]
    60e4:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    60e8:	f947f400 	ldr	x0, [x0, #4072]
    60ec:	f9400fe2 	ldr	x2, [sp, #24]
    60f0:	f9400001 	ldr	x1, [x0]
    60f4:	eb010042 	subs	x2, x2, x1
    60f8:	d2800001 	mov	x1, #0x0                   	// #0
    60fc:	540001a1 	b.ne	6130 <fwp_owned_entry161+0x110>  // b.any
    6100:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6104:	aa1303e0 	mov	x0, x19
    6108:	a94353f3 	ldp	x19, x20, [sp, #48]
    610c:	910103ff 	add	sp, sp, #0x40
    6110:	d65f03c0 	ret
    6114:	72003c3f 	tst	w1, #0xffff
    6118:	54fffe61 	b.ne	60e4 <fwp_owned_entry161+0xc4>  // b.any
    611c:	17ffffed 	b	60d0 <fwp_owned_entry161+0xb0>
    6120:	aa1403e0 	mov	x0, x20
    6124:	97fff884 	bl	4334 <fwp_rc_forget_slot.part.0>
    6128:	17ffffed 	b	60dc <fwp_owned_entry161+0xbc>
    612c:	97fff235 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6130:	97fff1b8 	bl	2810 <__stack_chk_fail@plt>

0000000000006134 <e161>:
    6134:	d10103ff 	sub	sp, sp, #0x40
    6138:	b0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    613c:	f947f442 	ldr	x2, [x2, #4072]
    6140:	a9027bfd 	stp	x29, x30, [sp, #32]
    6144:	910083fd 	add	x29, sp, #0x20
    6148:	a90353f3 	stp	x19, x20, [sp, #48]
    614c:	f9400043 	ldr	x3, [x2]
    6150:	f9000fe3 	str	x3, [sp, #24]
    6154:	d2800003 	mov	x3, #0x0                   	// #0
    6158:	a9400c01 	ldp	x1, x3, [x0]
    615c:	f9400802 	ldr	x2, [x0, #16]
    6160:	ab020022 	adds	x2, x1, x2
    6164:	54000726 	b.vs	6248 <e161+0x114>
    6168:	910023e1 	add	x1, sp, #0x8
    616c:	52800000 	mov	w0, #0x0                   	// #0
    6170:	a9008be3 	stp	x3, x2, [sp, #8]
    6174:	97fffea7 	bl	5c10 <fwp_data.part.0.constprop.0>
    6178:	f0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    617c:	91190063 	add	x3, x3, #0x640
    6180:	aa0003f3 	mov	x19, x0
    6184:	f949d861 	ldr	x1, [x3, #5040]
    6188:	f949ec60 	ldr	x0, [x3, #5080]
    618c:	cb010261 	sub	x1, x19, x1
    6190:	eb00403f 	cmp	x1, x0, lsl #16
    6194:	54000322 	b.cs	61f8 <e161+0xc4>  // b.hs, b.nlast
    6198:	d350fc22 	lsr	x2, x1, #16
    619c:	f949fc63 	ldr	x3, [x3, #5112]
    61a0:	8b020842 	add	x2, x2, x2, lsl #2
    61a4:	d37df042 	lsl	x2, x2, #3
    61a8:	8b020060 	add	x0, x3, x2
    61ac:	f9401014 	ldr	x20, [x0, #32]
    61b0:	b4000254 	cbz	x20, 61f8 <e161+0xc4>
    61b4:	38626862 	ldrb	w2, [x3, x2]
    61b8:	7100085f 	cmp	w2, #0x2
    61bc:	540003a0 	b.eq	6230 <e161+0xfc>  // b.none
    61c0:	7100045f 	cmp	w2, #0x1
    61c4:	540001a1 	b.ne	61f8 <e161+0xc4>  // b.any
    61c8:	29430002 	ldp	w2, w0, [x0, #24]
    61cc:	92403c21 	and	x1, x1, #0xffff
    61d0:	9b027c21 	mul	x1, x1, x2
    61d4:	d360fc21 	lsr	x1, x1, #32
    61d8:	eb00003f 	cmp	x1, x0
    61dc:	540000e2 	b.cs	61f8 <e161+0xc4>  // b.hs, b.nlast
    61e0:	8b010294 	add	x20, x20, x1
    61e4:	39400280 	ldrb	w0, [x20]
    61e8:	7103fc1f 	cmp	w0, #0xff
    61ec:	54000280 	b.eq	623c <e161+0x108>  // b.none
    61f0:	52800020 	mov	w0, #0x1                   	// #1
    61f4:	39000280 	strb	w0, [x20]
    61f8:	aa1303e0 	mov	x0, x19
    61fc:	97fffee5 	bl	5d90 <fwp_rc_share>
    6200:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    6204:	f947f400 	ldr	x0, [x0, #4072]
    6208:	f9400fe2 	ldr	x2, [sp, #24]
    620c:	f9400001 	ldr	x1, [x0]
    6210:	eb010042 	subs	x2, x2, x1
    6214:	d2800001 	mov	x1, #0x0                   	// #0
    6218:	540001a1 	b.ne	624c <e161+0x118>  // b.any
    621c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6220:	aa1303e0 	mov	x0, x19
    6224:	a94353f3 	ldp	x19, x20, [sp, #48]
    6228:	910103ff 	add	sp, sp, #0x40
    622c:	d65f03c0 	ret
    6230:	72003c3f 	tst	w1, #0xffff
    6234:	54fffe21 	b.ne	61f8 <e161+0xc4>  // b.any
    6238:	17ffffeb 	b	61e4 <e161+0xb0>
    623c:	aa1403e0 	mov	x0, x20
    6240:	97fff83d 	bl	4334 <fwp_rc_forget_slot.part.0>
    6244:	17ffffeb 	b	61f0 <e161+0xbc>
    6248:	97fff1ee 	bl	2a00 <fwp_trap_overflow.constprop.0>
    624c:	97fff171 	bl	2810 <__stack_chk_fail@plt>

0000000000006250 <fwp_drop0>:
    6250:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6254:	910003fd 	mov	x29, sp
    6258:	a90153f3 	stp	x19, x20, [sp, #16]
    625c:	f90013f5 	str	x21, [sp, #32]
    6260:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    6264:	911902b4 	add	x20, x21, #0x640
    6268:	f949da81 	ldr	x1, [x20, #5040]
    626c:	f949ee82 	ldr	x2, [x20, #5080]
    6270:	cb010001 	sub	x1, x0, x1
    6274:	eb02403f 	cmp	x1, x2, lsl #16
    6278:	54000382 	b.cs	62e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    627c:	d350fc22 	lsr	x2, x1, #16
    6280:	f949fe84 	ldr	x4, [x20, #5112]
    6284:	8b020842 	add	x2, x2, x2, lsl #2
    6288:	d37df042 	lsl	x2, x2, #3
    628c:	8b020083 	add	x3, x4, x2
    6290:	f9401073 	ldr	x19, [x3, #32]
    6294:	b40002b3 	cbz	x19, 62e8 <fwp_drop0+0x98>
    6298:	38626882 	ldrb	w2, [x4, x2]
    629c:	7100085f 	cmp	w2, #0x2
    62a0:	540002c0 	b.eq	62f8 <fwp_drop0+0xa8>  // b.none
    62a4:	7100045f 	cmp	w2, #0x1
    62a8:	54000201 	b.ne	62e8 <fwp_drop0+0x98>  // b.any
    62ac:	29430864 	ldp	w4, w2, [x3, #24]
    62b0:	92403c21 	and	x1, x1, #0xffff
    62b4:	9b047c21 	mul	x1, x1, x4
    62b8:	d360fc21 	lsr	x1, x1, #32
    62bc:	eb02003f 	cmp	x1, x2
    62c0:	54000142 	b.cs	62e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    62c4:	8b010273 	add	x19, x19, x1
    62c8:	39400261 	ldrb	w1, [x19]
    62cc:	340000e1 	cbz	w1, 62e8 <fwp_drop0+0x98>
    62d0:	7100043f 	cmp	w1, #0x1
    62d4:	540001e0 	b.eq	6310 <fwp_drop0+0xc0>  // b.none
    62d8:	7103fc3f 	cmp	w1, #0xff
    62dc:	540002e0 	b.eq	6338 <fwp_drop0+0xe8>  // b.none
    62e0:	51000421 	sub	w1, w1, #0x1
    62e4:	39000261 	strb	w1, [x19]
    62e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62ec:	f94013f5 	ldr	x21, [sp, #32]
    62f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62f4:	d65f03c0 	ret
    62f8:	72003c3f 	tst	w1, #0xffff
    62fc:	54fffe60 	b.eq	62c8 <fwp_drop0+0x78>  // b.none
    6300:	a94153f3 	ldp	x19, x20, [sp, #16]
    6304:	f94013f5 	ldr	x21, [sp, #32]
    6308:	a8c37bfd 	ldp	x29, x30, [sp], #48
    630c:	d65f03c0 	ret
    6310:	f9400813 	ldr	x19, [x0, #16]
    6314:	97fffef3 	bl	5ee0 <fwp_rc_free_arr>
    6318:	911902a0 	add	x0, x21, #0x640
    631c:	f949d801 	ldr	x1, [x0, #5040]
    6320:	f949ec00 	ldr	x0, [x0, #5080]
    6324:	cb010261 	sub	x1, x19, x1
    6328:	eb00403f 	cmp	x1, x0, lsl #16
    632c:	54fffde2 	b.cs	62e8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6330:	aa1303e0 	mov	x0, x19
    6334:	17ffffd2 	b	627c <fwp_drop0+0x2c>
    6338:	ca534660 	eor	x0, x19, x19, lsr #17
    633c:	911902b5 	add	x21, x21, #0x640
    6340:	ca402400 	eor	x0, x0, x0, lsr #9
    6344:	92401c00 	and	x0, x0, #0xff
    6348:	910a2402 	add	x2, x0, #0x289
    634c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6350:	8b020ea2 	add	x2, x21, x2, lsl #3
    6354:	f94a2400 	ldr	x0, [x0, #5192]
    6358:	b50000a0 	cbnz	x0, 636c <fwp_drop0+0x11c>
    635c:	14000013 	b	63a8 <fwp_drop0+0x158>
    6360:	91004002 	add	x2, x0, #0x10
    6364:	f9400800 	ldr	x0, [x0, #16]
    6368:	b4000200 	cbz	x0, 63a8 <fwp_drop0+0x158>
    636c:	f9400001 	ldr	x1, [x0]
    6370:	eb13003f 	cmp	x1, x19
    6374:	54ffff61 	b.ne	6360 <fwp_drop0+0x110>  // b.any
    6378:	f9400041 	ldr	x1, [x2]
    637c:	f9400420 	ldr	x0, [x1, #8]
    6380:	d1000400 	sub	x0, x0, #0x1
    6384:	f9000420 	str	x0, [x1, #8]
    6388:	f103f81f 	cmp	x0, #0xfe
    638c:	54fffae1 	b.ne	62e8 <fwp_drop0+0x98>  // b.any
    6390:	39400260 	ldrb	w0, [x19]
    6394:	7103fc1f 	cmp	w0, #0xff
    6398:	540000e0 	b.eq	63b4 <fwp_drop0+0x164>  // b.none
    639c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63a0:	39000260 	strb	w0, [x19]
    63a4:	17ffffd1 	b	62e8 <fwp_drop0+0x98>
    63a8:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    63ac:	91092000 	add	x0, x0, #0x248
    63b0:	97fff7c1 	bl	42b4 <fwp_trap>
    63b4:	aa1303e0 	mov	x0, x19
    63b8:	97fff7df 	bl	4334 <fwp_rc_forget_slot.part.0>
    63bc:	17fffff8 	b	639c <fwp_drop0+0x14c>

00000000000063c0 <fwp_arg_drop12>:
    63c0:	7100003f 	cmp	w1, #0x0
    63c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    63c8:	54000041 	b.ne	63d0 <fwp_arg_drop12+0x10>  // b.any
    63cc:	d65f03c0 	ret
    63d0:	f9400000 	ldr	x0, [x0]
    63d4:	17ffff9f 	b	6250 <fwp_drop0>
    63d8:	d503201f 	nop
    63dc:	d503201f 	nop

00000000000063e0 <fwp_drop1>:
    63e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    63e4:	910003fd 	mov	x29, sp
    63e8:	a90153f3 	stp	x19, x20, [sp, #16]
    63ec:	f90013f5 	str	x21, [sp, #32]
    63f0:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    63f4:	911902b4 	add	x20, x21, #0x640
    63f8:	f949da81 	ldr	x1, [x20, #5040]
    63fc:	f949ee82 	ldr	x2, [x20, #5080]
    6400:	cb010001 	sub	x1, x0, x1
    6404:	eb02403f 	cmp	x1, x2, lsl #16
    6408:	54000382 	b.cs	6478 <fwp_drop1+0x98>  // b.hs, b.nlast
    640c:	d350fc22 	lsr	x2, x1, #16
    6410:	f949fe84 	ldr	x4, [x20, #5112]
    6414:	8b020842 	add	x2, x2, x2, lsl #2
    6418:	d37df042 	lsl	x2, x2, #3
    641c:	8b020083 	add	x3, x4, x2
    6420:	f9401073 	ldr	x19, [x3, #32]
    6424:	b40002b3 	cbz	x19, 6478 <fwp_drop1+0x98>
    6428:	38626882 	ldrb	w2, [x4, x2]
    642c:	7100085f 	cmp	w2, #0x2
    6430:	540002c0 	b.eq	6488 <fwp_drop1+0xa8>  // b.none
    6434:	7100045f 	cmp	w2, #0x1
    6438:	54000201 	b.ne	6478 <fwp_drop1+0x98>  // b.any
    643c:	29430864 	ldp	w4, w2, [x3, #24]
    6440:	92403c21 	and	x1, x1, #0xffff
    6444:	9b047c21 	mul	x1, x1, x4
    6448:	d360fc21 	lsr	x1, x1, #32
    644c:	eb02003f 	cmp	x1, x2
    6450:	54000142 	b.cs	6478 <fwp_drop1+0x98>  // b.hs, b.nlast
    6454:	8b010273 	add	x19, x19, x1
    6458:	39400261 	ldrb	w1, [x19]
    645c:	340000e1 	cbz	w1, 6478 <fwp_drop1+0x98>
    6460:	7100043f 	cmp	w1, #0x1
    6464:	540001e0 	b.eq	64a0 <fwp_drop1+0xc0>  // b.none
    6468:	7103fc3f 	cmp	w1, #0xff
    646c:	540002e0 	b.eq	64c8 <fwp_drop1+0xe8>  // b.none
    6470:	51000421 	sub	w1, w1, #0x1
    6474:	39000261 	strb	w1, [x19]
    6478:	a94153f3 	ldp	x19, x20, [sp, #16]
    647c:	f94013f5 	ldr	x21, [sp, #32]
    6480:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6484:	d65f03c0 	ret
    6488:	72003c3f 	tst	w1, #0xffff
    648c:	54fffe60 	b.eq	6458 <fwp_drop1+0x78>  // b.none
    6490:	a94153f3 	ldp	x19, x20, [sp, #16]
    6494:	f94013f5 	ldr	x21, [sp, #32]
    6498:	a8c37bfd 	ldp	x29, x30, [sp], #48
    649c:	d65f03c0 	ret
    64a0:	f9400813 	ldr	x19, [x0, #16]
    64a4:	97fffe8f 	bl	5ee0 <fwp_rc_free_arr>
    64a8:	911902a0 	add	x0, x21, #0x640
    64ac:	f949d801 	ldr	x1, [x0, #5040]
    64b0:	f949ec00 	ldr	x0, [x0, #5080]
    64b4:	cb010261 	sub	x1, x19, x1
    64b8:	eb00403f 	cmp	x1, x0, lsl #16
    64bc:	54fffde2 	b.cs	6478 <fwp_drop1+0x98>  // b.hs, b.nlast
    64c0:	aa1303e0 	mov	x0, x19
    64c4:	17ffffd2 	b	640c <fwp_drop1+0x2c>
    64c8:	ca534660 	eor	x0, x19, x19, lsr #17
    64cc:	911902b5 	add	x21, x21, #0x640
    64d0:	ca402400 	eor	x0, x0, x0, lsr #9
    64d4:	92401c00 	and	x0, x0, #0xff
    64d8:	910a2402 	add	x2, x0, #0x289
    64dc:	8b000ea0 	add	x0, x21, x0, lsl #3
    64e0:	8b020ea2 	add	x2, x21, x2, lsl #3
    64e4:	f94a2400 	ldr	x0, [x0, #5192]
    64e8:	b50000a0 	cbnz	x0, 64fc <fwp_drop1+0x11c>
    64ec:	14000013 	b	6538 <fwp_drop1+0x158>
    64f0:	91004002 	add	x2, x0, #0x10
    64f4:	f9400800 	ldr	x0, [x0, #16]
    64f8:	b4000200 	cbz	x0, 6538 <fwp_drop1+0x158>
    64fc:	f9400001 	ldr	x1, [x0]
    6500:	eb13003f 	cmp	x1, x19
    6504:	54ffff61 	b.ne	64f0 <fwp_drop1+0x110>  // b.any
    6508:	f9400041 	ldr	x1, [x2]
    650c:	f9400420 	ldr	x0, [x1, #8]
    6510:	d1000400 	sub	x0, x0, #0x1
    6514:	f9000420 	str	x0, [x1, #8]
    6518:	f103f81f 	cmp	x0, #0xfe
    651c:	54fffae1 	b.ne	6478 <fwp_drop1+0x98>  // b.any
    6520:	39400260 	ldrb	w0, [x19]
    6524:	7103fc1f 	cmp	w0, #0xff
    6528:	540000e0 	b.eq	6544 <fwp_drop1+0x164>  // b.none
    652c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6530:	39000260 	strb	w0, [x19]
    6534:	17ffffd1 	b	6478 <fwp_drop1+0x98>
    6538:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    653c:	91092000 	add	x0, x0, #0x248
    6540:	97fff75d 	bl	42b4 <fwp_trap>
    6544:	aa1303e0 	mov	x0, x19
    6548:	97fff77b 	bl	4334 <fwp_rc_forget_slot.part.0>
    654c:	17fffff8 	b	652c <fwp_drop1+0x14c>

0000000000006550 <fwp_closure_drop>:
    6550:	f0000405 	adrp	x5, 89000 <fwp_root_context+0xba0>
    6554:	911900a4 	add	x4, x5, #0x640
    6558:	aa0003e1 	mov	x1, x0
    655c:	f949d882 	ldr	x2, [x4, #5040]
    6560:	f949ec80 	ldr	x0, [x4, #5080]
    6564:	cb020022 	sub	x2, x1, x2
    6568:	eb00405f 	cmp	x2, x0, lsl #16
    656c:	54000662 	b.cs	6638 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6574:	d350fc43 	lsr	x3, x2, #16
    6578:	910003fd 	mov	x29, sp
    657c:	8b030863 	add	x3, x3, x3, lsl #2
    6580:	f949fc84 	ldr	x4, [x4, #5112]
    6584:	d37df063 	lsl	x3, x3, #3
    6588:	f9000bf3 	str	x19, [sp, #16]
    658c:	8b030080 	add	x0, x4, x3
    6590:	f9401013 	ldr	x19, [x0, #32]
    6594:	b40002b3 	cbz	x19, 65e8 <fwp_closure_drop+0x98>
    6598:	38636883 	ldrb	w3, [x4, x3]
    659c:	7100087f 	cmp	w3, #0x2
    65a0:	54000420 	b.eq	6624 <fwp_closure_drop+0xd4>  // b.none
    65a4:	7100047f 	cmp	w3, #0x1
    65a8:	54000201 	b.ne	65e8 <fwp_closure_drop+0x98>  // b.any
    65ac:	29430003 	ldp	w3, w0, [x0, #24]
    65b0:	92403c42 	and	x2, x2, #0xffff
    65b4:	9b037c42 	mul	x2, x2, x3
    65b8:	d360fc42 	lsr	x2, x2, #32
    65bc:	eb00005f 	cmp	x2, x0
    65c0:	54000142 	b.cs	65e8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    65c4:	8b020273 	add	x19, x19, x2
    65c8:	39400260 	ldrb	w0, [x19]
    65cc:	340000e0 	cbz	w0, 65e8 <fwp_closure_drop+0x98>
    65d0:	7100041f 	cmp	w0, #0x1
    65d4:	54000100 	b.eq	65f4 <fwp_closure_drop+0xa4>  // b.none
    65d8:	7103fc1f 	cmp	w0, #0xff
    65dc:	54000300 	b.eq	663c <fwp_closure_drop+0xec>  // b.none
    65e0:	51000400 	sub	w0, w0, #0x1
    65e4:	39000260 	strb	w0, [x19]
    65e8:	f9400bf3 	ldr	x19, [sp, #16]
    65ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f0:	d65f03c0 	ret
    65f4:	d53bd040 	mrs	x0, tpidr_el0
    65f8:	91400000 	add	x0, x0, #0x0, lsl #12
    65fc:	91004000 	add	x0, x0, #0x10
    6600:	f9400000 	ldr	x0, [x0]
    6604:	b4000080 	cbz	x0, 6614 <fwp_closure_drop+0xc4>
    6608:	f9400bf3 	ldr	x19, [sp, #16]
    660c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6610:	17fff8a4 	b	48a0 <fwp_closure_drop_push>
    6614:	f9400bf3 	ldr	x19, [sp, #16]
    6618:	aa0103e0 	mov	x0, x1
    661c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6620:	17fff8e5 	b	49b4 <fwp_closure_drop.part.0>
    6624:	72003c5f 	tst	w2, #0xffff
    6628:	54fffd00 	b.eq	65c8 <fwp_closure_drop+0x78>  // b.none
    662c:	f9400bf3 	ldr	x19, [sp, #16]
    6630:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6634:	d65f03c0 	ret
    6638:	d65f03c0 	ret
    663c:	ca534660 	eor	x0, x19, x19, lsr #17
    6640:	911900a5 	add	x5, x5, #0x640
    6644:	ca402400 	eor	x0, x0, x0, lsr #9
    6648:	92401c00 	and	x0, x0, #0xff
    664c:	910a2402 	add	x2, x0, #0x289
    6650:	8b000ca0 	add	x0, x5, x0, lsl #3
    6654:	8b020ca2 	add	x2, x5, x2, lsl #3
    6658:	f94a2400 	ldr	x0, [x0, #5192]
    665c:	b50000a0 	cbnz	x0, 6670 <fwp_closure_drop+0x120>
    6660:	14000013 	b	66ac <fwp_closure_drop+0x15c>
    6664:	91004002 	add	x2, x0, #0x10
    6668:	f9400800 	ldr	x0, [x0, #16]
    666c:	b4000200 	cbz	x0, 66ac <fwp_closure_drop+0x15c>
    6670:	f9400001 	ldr	x1, [x0]
    6674:	eb13003f 	cmp	x1, x19
    6678:	54ffff61 	b.ne	6664 <fwp_closure_drop+0x114>  // b.any
    667c:	f9400041 	ldr	x1, [x2]
    6680:	f9400420 	ldr	x0, [x1, #8]
    6684:	d1000400 	sub	x0, x0, #0x1
    6688:	f9000420 	str	x0, [x1, #8]
    668c:	f103f81f 	cmp	x0, #0xfe
    6690:	54fffac1 	b.ne	65e8 <fwp_closure_drop+0x98>  // b.any
    6694:	39400260 	ldrb	w0, [x19]
    6698:	7103fc1f 	cmp	w0, #0xff
    669c:	540000e0 	b.eq	66b8 <fwp_closure_drop+0x168>  // b.none
    66a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66a4:	39000260 	strb	w0, [x19]
    66a8:	17ffffd0 	b	65e8 <fwp_closure_drop+0x98>
    66ac:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    66b0:	91092000 	add	x0, x0, #0x248
    66b4:	97fff700 	bl	42b4 <fwp_trap>
    66b8:	aa1303e0 	mov	x0, x19
    66bc:	97fff71e 	bl	4334 <fwp_rc_forget_slot.part.0>
    66c0:	17fffff8 	b	66a0 <fwp_closure_drop+0x150>

00000000000066c4 <fwp_owned_tape_release>:
    66c4:	b4000920 	cbz	x0, 67e8 <fwp_owned_tape_release+0x124>
    66c8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66cc:	910003fd 	mov	x29, sp
    66d0:	a90153f3 	stp	x19, x20, [sp, #16]
    66d4:	aa0003f3 	mov	x19, x0
    66d8:	f9400000 	ldr	x0, [x0]
    66dc:	b4000060 	cbz	x0, 66e8 <fwp_owned_tape_release+0x24>
    66e0:	f9400661 	ldr	x1, [x19, #8]
    66e4:	f9000401 	str	x1, [x0, #8]
    66e8:	f9400661 	ldr	x1, [x19, #8]
    66ec:	b4000041 	cbz	x1, 66f4 <fwp_owned_tape_release+0x30>
    66f0:	f9000020 	str	x0, [x1]
    66f4:	f9400a60 	ldr	x0, [x19, #16]
    66f8:	f9403401 	ldr	x1, [x0, #104]
    66fc:	b40005a1 	cbz	x1, 67b0 <fwp_owned_tape_release+0xec>
    6700:	a9450a60 	ldp	x0, x2, [x19, #80]
    6704:	eb00005f 	cmp	x2, x0
    6708:	540002cd 	b.le	6760 <fwp_owned_tape_release+0x9c>
    670c:	d2800014 	mov	x20, #0x0                   	// #0
    6710:	f90013f5 	str	x21, [sp, #32]
    6714:	d2800015 	mov	x21, #0x0                   	// #0
    6718:	f9402260 	ldr	x0, [x19, #64]
    671c:	910006b5 	add	x21, x21, #0x1
    6720:	f8746800 	ldr	x0, [x0, x20]
    6724:	d63f0020 	blr	x1
    6728:	f9402260 	ldr	x0, [x19, #64]
    672c:	f9400a61 	ldr	x1, [x19, #16]
    6730:	8b140000 	add	x0, x0, x20
    6734:	91004294 	add	x20, x20, #0x10
    6738:	f9400400 	ldr	x0, [x0, #8]
    673c:	f9403421 	ldr	x1, [x1, #104]
    6740:	d63f0020 	blr	x1
    6744:	a9450261 	ldp	x1, x0, [x19, #80]
    6748:	cb010000 	sub	x0, x0, x1
    674c:	eb15001f 	cmp	x0, x21
    6750:	f9400a60 	ldr	x0, [x19, #16]
    6754:	f9403401 	ldr	x1, [x0, #104]
    6758:	54fffe0c 	b.gt	6718 <fwp_owned_tape_release+0x54>
    675c:	f94013f5 	ldr	x21, [sp, #32]
    6760:	f9403663 	ldr	x3, [x19, #104]
    6764:	f9401262 	ldr	x2, [x19, #32]
    6768:	f100007f 	cmp	x3, #0x0
    676c:	540001ed 	b.le	67a8 <fwp_owned_tape_release+0xe4>
    6770:	d2800014 	mov	x20, #0x0                   	// #0
    6774:	d503201f 	nop
    6778:	f9402660 	ldr	x0, [x19, #72]
    677c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6780:	eb02001f 	cmp	x0, x2
    6784:	540000c0 	b.eq	679c <fwp_owned_tape_release+0xd8>  // b.none
    6788:	d63f0020 	blr	x1
    678c:	f9400a60 	ldr	x0, [x19, #16]
    6790:	f9401262 	ldr	x2, [x19, #32]
    6794:	f9403663 	ldr	x3, [x19, #104]
    6798:	f9403401 	ldr	x1, [x0, #104]
    679c:	91000694 	add	x20, x20, #0x1
    67a0:	eb14007f 	cmp	x3, x20
    67a4:	54fffeac 	b.gt	6778 <fwp_owned_tape_release+0xb4>
    67a8:	aa0203e0 	mov	x0, x2
    67ac:	d63f0020 	blr	x1
    67b0:	f9401660 	ldr	x0, [x19, #40]
    67b4:	97ffff67 	bl	6550 <fwp_closure_drop>
    67b8:	f9401a60 	ldr	x0, [x19, #48]
    67bc:	97ffff65 	bl	6550 <fwp_closure_drop>
    67c0:	f9401e60 	ldr	x0, [x19, #56]
    67c4:	97ffff63 	bl	6550 <fwp_closure_drop>
    67c8:	f9402260 	ldr	x0, [x19, #64]
    67cc:	97fff775 	bl	45a0 <fwp_mem_free>
    67d0:	f9402660 	ldr	x0, [x19, #72]
    67d4:	97fff773 	bl	45a0 <fwp_mem_free>
    67d8:	aa1303e0 	mov	x0, x19
    67dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67e4:	17fff76f 	b	45a0 <fwp_mem_free>
    67e8:	d65f03c0 	ret
    67ec:	d503201f 	nop

00000000000067f0 <fwp_tape_finish>:
    67f0:	d10203ff 	sub	sp, sp, #0x80
    67f4:	b0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    67f8:	f947f421 	ldr	x1, [x1, #4072]
    67fc:	a9047bfd 	stp	x29, x30, [sp, #64]
    6800:	910103fd 	add	x29, sp, #0x40
    6804:	a9065bf5 	stp	x21, x22, [sp, #96]
    6808:	a90763f7 	stp	x23, x24, [sp, #112]
    680c:	d0000157 	adrp	x23, 30000 <__data_start>
    6810:	910182f6 	add	x22, x23, #0x60
    6814:	f9400022 	ldr	x2, [x1]
    6818:	f9001fe2 	str	x2, [sp, #56]
    681c:	d2800002 	mov	x2, #0x0                   	// #0
    6820:	910342c0 	add	x0, x22, #0xd0
    6824:	97fff5f4 	bl	3ff4 <fwp_tape_buffers_dispose>
    6828:	f90086df 	str	xzr, [x22, #264]
    682c:	f94092c0 	ldr	x0, [x22, #288]
    6830:	f100001f 	cmp	x0, #0x0
    6834:	5400034d 	b.le	689c <fwp_tape_finish+0xac>
    6838:	910003f8 	mov	x24, sp
    683c:	d2800015 	mov	x21, #0x0                   	// #0
    6840:	a90553f3 	stp	x19, x20, [sp, #80]
    6844:	d2800014 	mov	x20, #0x0                   	// #0
    6848:	91000694 	add	x20, x20, #0x1
    684c:	f94046d3 	ldr	x19, [x22, #136]
    6850:	8b150273 	add	x19, x19, x21
    6854:	9101a2b5 	add	x21, x21, #0x68
    6858:	aa1303e0 	mov	x0, x19
    685c:	97fff1ce 	bl	2f94 <fwp_tape_unlink_scope>
    6860:	aa1803e0 	mov	x0, x24
    6864:	a9440663 	ldp	x3, x1, [x19, #64]
    6868:	f9001be1 	str	x1, [sp, #48]
    686c:	f9400e62 	ldr	x2, [x19, #24]
    6870:	a9020be3 	stp	x3, x2, [sp, #32]
    6874:	ad410261 	ldp	q1, q0, [x19, #32]
    6878:	ad0003e1 	stp	q1, q0, [sp]
    687c:	97fff5de 	bl	3ff4 <fwp_tape_buffers_dispose>
    6880:	f9403260 	ldr	x0, [x19, #96]
    6884:	97ffff90 	bl	66c4 <fwp_owned_tape_release>
    6888:	f900327f 	str	xzr, [x19, #96]
    688c:	f94092c0 	ldr	x0, [x22, #288]
    6890:	eb14001f 	cmp	x0, x20
    6894:	54fffdac 	b.gt	6848 <fwp_tape_finish+0x58>
    6898:	a94553f3 	ldp	x19, x20, [sp, #80]
    689c:	910182e0 	add	x0, x23, #0x60
    68a0:	f9404400 	ldr	x0, [x0, #136]
    68a4:	b4000040 	cbz	x0, 68ac <fwp_tape_finish+0xbc>
    68a8:	97fff5b2 	bl	3f70 <ad_raw_free.part.0>
    68ac:	910182f7 	add	x23, x23, #0x60
    68b0:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    68b4:	f947f400 	ldr	x0, [x0, #4072]
    68b8:	f90046ff 	str	xzr, [x23, #136]
    68bc:	f9008aff 	str	xzr, [x23, #272]
    68c0:	f90092ff 	str	xzr, [x23, #288]
    68c4:	f900b2ff 	str	xzr, [x23, #352]
    68c8:	f9401fe2 	ldr	x2, [sp, #56]
    68cc:	f9400001 	ldr	x1, [x0]
    68d0:	eb010042 	subs	x2, x2, x1
    68d4:	d2800001 	mov	x1, #0x0                   	// #0
    68d8:	540000c1 	b.ne	68f0 <fwp_tape_finish+0x100>  // b.any
    68dc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    68e0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    68e4:	a94763f7 	ldp	x23, x24, [sp, #112]
    68e8:	910203ff 	add	sp, sp, #0x80
    68ec:	d65f03c0 	ret
    68f0:	a90553f3 	stp	x19, x20, [sp, #80]
    68f4:	97ffefc7 	bl	2810 <__stack_chk_fail@plt>
    68f8:	d503201f 	nop
    68fc:	d503201f 	nop

0000000000006900 <fwp_tape_scope_release>:
    6900:	d10243ff 	sub	sp, sp, #0x90
    6904:	a9047bfd 	stp	x29, x30, [sp, #64]
    6908:	910103fd 	add	x29, sp, #0x40
    690c:	a90553f3 	stp	x19, x20, [sp, #80]
    6910:	aa0003f4 	mov	x20, x0
    6914:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    6918:	f947f400 	ldr	x0, [x0, #4072]
    691c:	b9400285 	ldr	w5, [x20]
    6920:	f9400001 	ldr	x1, [x0]
    6924:	f9001fe1 	str	x1, [sp, #56]
    6928:	d2800001 	mov	x1, #0x0                   	// #0
    692c:	37f806c5 	tbnz	w5, #31, 6a04 <fwp_tape_scope_release+0x104>
    6930:	a90763f7 	stp	x23, x24, [sp, #112]
    6934:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6938:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    693c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6940:	d0000153 	adrp	x19, 30000 <__data_start>
    6944:	910003f7 	mov	x23, sp
    6948:	91018273 	add	x19, x19, #0x60
    694c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6950:	a9065bf5 	stp	x21, x22, [sp, #96]
    6954:	52800d16 	mov	w22, #0x68                  	// #104
    6958:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    695c:	f90043f9 	str	x25, [sp, #128]
    6960:	14000006 	b	6978 <fwp_tape_scope_release+0x78>
    6964:	97fff5a4 	bl	3ff4 <fwp_tape_buffers_dispose>
    6968:	aa1903e0 	mov	x0, x25
    696c:	97ffff56 	bl	66c4 <fwp_owned_tape_release>
    6970:	b9400285 	ldr	w5, [x20]
    6974:	37f80425 	tbnz	w5, #31, 69f8 <fwp_tape_scope_release+0xf8>
    6978:	f9404666 	ldr	x6, [x19, #136]
    697c:	9b367ca5 	smull	x5, w5, w22
    6980:	8b0500c0 	add	x0, x6, x5
    6984:	97fff184 	bl	2f94 <fwp_tape_unlink_scope>
    6988:	ad410001 	ldp	q1, q0, [x0, #32]
    698c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6990:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6994:	f9400c03 	ldr	x3, [x0, #24]
    6998:	ad0003e1 	stp	q1, q0, [sp]
    699c:	b86568c1 	ldr	w1, [x6, x5]
    69a0:	a9440804 	ldp	x4, x2, [x0, #64]
    69a4:	b900041f 	str	wzr, [x0, #4]
    69a8:	f9403019 	ldr	x25, [x0, #96]
    69ac:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    69b0:	f9000c1f 	str	xzr, [x0, #24]
    69b4:	a9020fe4 	stp	x4, x3, [sp, #32]
    69b8:	f9001be2 	str	x2, [sp, #48]
    69bc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    69c0:	f900301f 	str	xzr, [x0, #96]
    69c4:	6b15003f 	cmp	w1, w21
    69c8:	540000e8 	b.hi	69e4 <fwp_tape_scope_release+0xe4>  // b.pmore
    69cc:	9343fca5 	asr	x5, x5, #3
    69d0:	f940b260 	ldr	x0, [x19, #352]
    69d4:	9b187ca5 	mul	x5, x5, x24
    69d8:	eb0000bf 	cmp	x5, x0
    69dc:	5400004a 	b.ge	69e4 <fwp_tape_scope_release+0xe4>  // b.tcont
    69e0:	f900b265 	str	x5, [x19, #352]
    69e4:	aa1703e0 	mov	x0, x23
    69e8:	b5fffbf9 	cbnz	x25, 6964 <fwp_tape_scope_release+0x64>
    69ec:	97fff5ca 	bl	4114 <fwp_tape_buffers_release>
    69f0:	b9400285 	ldr	w5, [x20]
    69f4:	36fffc25 	tbz	w5, #31, 6978 <fwp_tape_scope_release+0x78>
    69f8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    69fc:	a94763f7 	ldp	x23, x24, [sp, #112]
    6a00:	f94043f9 	ldr	x25, [sp, #128]
    6a04:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    6a08:	f947f400 	ldr	x0, [x0, #4072]
    6a0c:	f9401fe2 	ldr	x2, [sp, #56]
    6a10:	f9400001 	ldr	x1, [x0]
    6a14:	eb010042 	subs	x2, x2, x1
    6a18:	d2800001 	mov	x1, #0x0                   	// #0
    6a1c:	540000a1 	b.ne	6a30 <fwp_tape_scope_release+0x130>  // b.any
    6a20:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6a24:	a94553f3 	ldp	x19, x20, [sp, #80]
    6a28:	910243ff 	add	sp, sp, #0x90
    6a2c:	d65f03c0 	ret
    6a30:	a9065bf5 	stp	x21, x22, [sp, #96]
    6a34:	a90763f7 	stp	x23, x24, [sp, #112]
    6a38:	f90043f9 	str	x25, [sp, #128]
    6a3c:	97ffef75 	bl	2810 <__stack_chk_fail@plt>

0000000000006a40 <fwp_task_dispose>:
    6a40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a44:	910003fd 	mov	x29, sp
    6a48:	f9000bf3 	str	x19, [sp, #16]
    6a4c:	aa0003f3 	mov	x19, x0
    6a50:	39414000 	ldrb	w0, [x0, #80]
    6a54:	36000720 	tbz	w0, #0, 6b38 <fwp_task_dispose+0xf8>
    6a58:	f9400a60 	ldr	x0, [x19, #16]
    6a5c:	b50006e0 	cbnz	x0, 6b38 <fwp_task_dispose+0xf8>
    6a60:	a9478660 	ldp	x0, x1, [x19, #120]
    6a64:	39014e7f 	strb	wzr, [x19, #83]
    6a68:	f9003e7f 	str	xzr, [x19, #120]
    6a6c:	f100003f 	cmp	x1, #0x0
    6a70:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6a74:	54000040 	b.eq	6a7c <fwp_task_dispose+0x3c>  // b.none
    6a78:	d63f0020 	blr	x1
    6a7c:	f9405660 	ldr	x0, [x19, #168]
    6a80:	97fff6c8 	bl	45a0 <fwp_mem_free>
    6a84:	f900567f 	str	xzr, [x19, #168]
    6a88:	b9405e60 	ldr	w0, [x19, #92]
    6a8c:	7100041f 	cmp	w0, #0x1
    6a90:	54000420 	b.eq	6b14 <fwp_task_dispose+0xd4>  // b.none
    6a94:	f0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    6a98:	91190042 	add	x2, x2, #0x640
    6a9c:	f949d840 	ldr	x0, [x2, #5040]
    6aa0:	f949ec41 	ldr	x1, [x2, #5080]
    6aa4:	cb000260 	sub	x0, x19, x0
    6aa8:	eb01401f 	cmp	x0, x1, lsl #16
    6aac:	540002e2 	b.cs	6b08 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6ab0:	d350fc01 	lsr	x1, x0, #16
    6ab4:	f949fc44 	ldr	x4, [x2, #5112]
    6ab8:	8b010821 	add	x1, x1, x1, lsl #2
    6abc:	d37df021 	lsl	x1, x1, #3
    6ac0:	8b010083 	add	x3, x4, x1
    6ac4:	f9401062 	ldr	x2, [x3, #32]
    6ac8:	b4000202 	cbz	x2, 6b08 <fwp_task_dispose+0xc8>
    6acc:	38616881 	ldrb	w1, [x4, x1]
    6ad0:	7100083f 	cmp	w1, #0x2
    6ad4:	54000280 	b.eq	6b24 <fwp_task_dispose+0xe4>  // b.none
    6ad8:	7100043f 	cmp	w1, #0x1
    6adc:	54000161 	b.ne	6b08 <fwp_task_dispose+0xc8>  // b.any
    6ae0:	29430464 	ldp	w4, w1, [x3, #24]
    6ae4:	92403c00 	and	x0, x0, #0xffff
    6ae8:	9b047c00 	mul	x0, x0, x4
    6aec:	d360fc00 	lsr	x0, x0, #32
    6af0:	eb01001f 	cmp	x0, x1
    6af4:	540000a2 	b.cs	6b08 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6af8:	8b000042 	add	x2, x2, x0
    6afc:	39400040 	ldrb	w0, [x2]
    6b00:	7100041f 	cmp	w0, #0x1
    6b04:	54000080 	b.eq	6b14 <fwp_task_dispose+0xd4>  // b.none
    6b08:	f9400bf3 	ldr	x19, [sp, #16]
    6b0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b10:	d65f03c0 	ret
    6b14:	aa1303e0 	mov	x0, x19
    6b18:	f9400bf3 	ldr	x19, [sp, #16]
    6b1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b20:	17fff6a0 	b	45a0 <fwp_mem_free>
    6b24:	72003c1f 	tst	w0, #0xffff
    6b28:	54fffea0 	b.eq	6afc <fwp_task_dispose+0xbc>  // b.none
    6b2c:	f9400bf3 	ldr	x19, [sp, #16]
    6b30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b34:	d65f03c0 	ret
    6b38:	97ffef4a 	bl	2860 <abort@plt>
    6b3c:	d503201f 	nop

0000000000006b40 <fwp_free_zombie>:
    6b40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b44:	910003fd 	mov	x29, sp
    6b48:	a90153f3 	stp	x19, x20, [sp, #16]
    6b4c:	d0000154 	adrp	x20, 30000 <__data_start>
    6b50:	91018281 	add	x1, x20, #0x60
    6b54:	f940b433 	ldr	x19, [x1, #360]
    6b58:	b4000333 	cbz	x19, 6bbc <fwp_free_zombie+0x7c>
    6b5c:	f9404c20 	ldr	x0, [x1, #152]
    6b60:	eb00027f 	cmp	x19, x0
    6b64:	540002c0 	b.eq	6bbc <fwp_free_zombie+0x7c>  // b.none
    6b68:	b9417022 	ldr	w2, [x1, #368]
    6b6c:	f9400a60 	ldr	x0, [x19, #16]
    6b70:	7100fc5f 	cmp	w2, #0x3f
    6b74:	5400078c 	b.gt	6c64 <fwp_free_zombie+0x124>
    6b78:	91060023 	add	x3, x1, #0x180
    6b7c:	11000444 	add	w4, w2, #0x1
    6b80:	b9017024 	str	w4, [x1, #368]
    6b84:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6b88:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6b8c:	a9530261 	ldp	x1, x0, [x19, #304]
    6b90:	b4000741 	cbz	x1, 6c78 <fwp_free_zombie+0x138>
    6b94:	f9009c20 	str	x0, [x1, #312]
    6b98:	b4000040 	cbz	x0, 6ba0 <fwp_free_zombie+0x60>
    6b9c:	f9009801 	str	x1, [x0, #304]
    6ba0:	91018294 	add	x20, x20, #0x60
    6ba4:	b9405e60 	ldr	w0, [x19, #92]
    6ba8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6bac:	f900b69f 	str	xzr, [x20, #360]
    6bb0:	34000140 	cbz	w0, 6bd8 <fwp_free_zombie+0x98>
    6bb4:	7100041f 	cmp	w0, #0x1
    6bb8:	54000080 	b.eq	6bc8 <fwp_free_zombie+0x88>  // b.none
    6bbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bc4:	d65f03c0 	ret
    6bc8:	aa1303e0 	mov	x0, x19
    6bcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bd4:	17ffff9b 	b	6a40 <fwp_task_dispose>
    6bd8:	f0000404 	adrp	x4, 89000 <fwp_root_context+0xba0>
    6bdc:	91190082 	add	x2, x4, #0x640
    6be0:	f949d841 	ldr	x1, [x2, #5040]
    6be4:	f949ec40 	ldr	x0, [x2, #5080]
    6be8:	cb010261 	sub	x1, x19, x1
    6bec:	eb00403f 	cmp	x1, x0, lsl #16
    6bf0:	54fffe62 	b.cs	6bbc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6bf4:	d350fc20 	lsr	x0, x1, #16
    6bf8:	f949fc43 	ldr	x3, [x2, #5112]
    6bfc:	8b000800 	add	x0, x0, x0, lsl #2
    6c00:	d37df000 	lsl	x0, x0, #3
    6c04:	8b000062 	add	x2, x3, x0
    6c08:	f9401054 	ldr	x20, [x2, #32]
    6c0c:	b4fffd94 	cbz	x20, 6bbc <fwp_free_zombie+0x7c>
    6c10:	38606860 	ldrb	w0, [x3, x0]
    6c14:	7100081f 	cmp	w0, #0x2
    6c18:	54000360 	b.eq	6c84 <fwp_free_zombie+0x144>  // b.none
    6c1c:	7100041f 	cmp	w0, #0x1
    6c20:	54fffce1 	b.ne	6bbc <fwp_free_zombie+0x7c>  // b.any
    6c24:	29430043 	ldp	w3, w0, [x2, #24]
    6c28:	92403c21 	and	x1, x1, #0xffff
    6c2c:	9b037c21 	mul	x1, x1, x3
    6c30:	d360fc21 	lsr	x1, x1, #32
    6c34:	eb00003f 	cmp	x1, x0
    6c38:	54fffc22 	b.cs	6bbc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c3c:	8b010294 	add	x20, x20, x1
    6c40:	39400280 	ldrb	w0, [x20]
    6c44:	34fffbc0 	cbz	w0, 6bbc <fwp_free_zombie+0x7c>
    6c48:	7100041f 	cmp	w0, #0x1
    6c4c:	54fffbe0 	b.eq	6bc8 <fwp_free_zombie+0x88>  // b.none
    6c50:	7103fc1f 	cmp	w0, #0xff
    6c54:	540001e0 	b.eq	6c90 <fwp_free_zombie+0x150>  // b.none
    6c58:	51000400 	sub	w0, w0, #0x1
    6c5c:	39000280 	strb	w0, [x20]
    6c60:	17ffffd7 	b	6bbc <fwp_free_zombie+0x7c>
    6c64:	f9400e61 	ldr	x1, [x19, #24]
    6c68:	97ffef32 	bl	2930 <munmap@plt>
    6c6c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6c70:	a9530261 	ldp	x1, x0, [x19, #304]
    6c74:	b5fff901 	cbnz	x1, 6b94 <fwp_free_zombie+0x54>
    6c78:	91018282 	add	x2, x20, #0x60
    6c7c:	f901c040 	str	x0, [x2, #896]
    6c80:	17ffffc6 	b	6b98 <fwp_free_zombie+0x58>
    6c84:	72003c3f 	tst	w1, #0xffff
    6c88:	54fff9a1 	b.ne	6bbc <fwp_free_zombie+0x7c>  // b.any
    6c8c:	17ffffed 	b	6c40 <fwp_free_zombie+0x100>
    6c90:	ca544680 	eor	x0, x20, x20, lsr #17
    6c94:	91190084 	add	x4, x4, #0x640
    6c98:	ca402400 	eor	x0, x0, x0, lsr #9
    6c9c:	92401c00 	and	x0, x0, #0xff
    6ca0:	910a2402 	add	x2, x0, #0x289
    6ca4:	8b000c80 	add	x0, x4, x0, lsl #3
    6ca8:	8b020c82 	add	x2, x4, x2, lsl #3
    6cac:	f94a2400 	ldr	x0, [x0, #5192]
    6cb0:	b50000a0 	cbnz	x0, 6cc4 <fwp_free_zombie+0x184>
    6cb4:	14000013 	b	6d00 <fwp_free_zombie+0x1c0>
    6cb8:	91004002 	add	x2, x0, #0x10
    6cbc:	f9400800 	ldr	x0, [x0, #16]
    6cc0:	b4000200 	cbz	x0, 6d00 <fwp_free_zombie+0x1c0>
    6cc4:	f9400001 	ldr	x1, [x0]
    6cc8:	eb14003f 	cmp	x1, x20
    6ccc:	54ffff61 	b.ne	6cb8 <fwp_free_zombie+0x178>  // b.any
    6cd0:	f9400041 	ldr	x1, [x2]
    6cd4:	f9400420 	ldr	x0, [x1, #8]
    6cd8:	d1000400 	sub	x0, x0, #0x1
    6cdc:	f9000420 	str	x0, [x1, #8]
    6ce0:	f103f81f 	cmp	x0, #0xfe
    6ce4:	54fff6c1 	b.ne	6bbc <fwp_free_zombie+0x7c>  // b.any
    6ce8:	39400280 	ldrb	w0, [x20]
    6cec:	7103fc1f 	cmp	w0, #0xff
    6cf0:	540000e0 	b.eq	6d0c <fwp_free_zombie+0x1cc>  // b.none
    6cf4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6cf8:	39000280 	strb	w0, [x20]
    6cfc:	17ffffb0 	b	6bbc <fwp_free_zombie+0x7c>
    6d00:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    6d04:	91092000 	add	x0, x0, #0x248
    6d08:	97fff56b 	bl	42b4 <fwp_trap>
    6d0c:	aa1403e0 	mov	x0, x20
    6d10:	97fff589 	bl	4334 <fwp_rc_forget_slot.part.0>
    6d14:	17fffff8 	b	6cf4 <fwp_free_zombie+0x1b4>
    6d18:	d503201f 	nop
    6d1c:	d503201f 	nop

0000000000006d20 <fwp_block>:
    6d20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d24:	910003fd 	mov	x29, sp
    6d28:	a90153f3 	stp	x19, x20, [sp, #16]
    6d2c:	d0000153 	adrp	x19, 30000 <__data_start>
    6d30:	91018274 	add	x20, x19, #0x60
    6d34:	f9406682 	ldr	x2, [x20, #200]
    6d38:	b4000642 	cbz	x2, 6e00 <fwp_block+0xe0>
    6d3c:	91018261 	add	x1, x19, #0x60
    6d40:	f9408040 	ldr	x0, [x2, #256]
    6d44:	f9006420 	str	x0, [x1, #200]
    6d48:	b40006a0 	cbz	x0, 6e1c <fwp_block+0xfc>
    6d4c:	d503201f 	nop
    6d50:	91018263 	add	x3, x19, #0x60
    6d54:	3901505f 	strb	wzr, [x2, #84]
    6d58:	f9404c64 	ldr	x4, [x3, #152]
    6d5c:	eb02009f 	cmp	x4, x2
    6d60:	54000440 	b.eq	6de8 <fwp_block+0xc8>  // b.none
    6d64:	f941c465 	ldr	x5, [x3, #904]
    6d68:	f9004c62 	str	x2, [x3, #152]
    6d6c:	f9400441 	ldr	x1, [x2, #8]
    6d70:	f9004885 	str	x5, [x4, #144]
    6d74:	f941c865 	ldr	x5, [x3, #912]
    6d78:	f9004c85 	str	x5, [x4, #152]
    6d7c:	f941cc65 	ldr	x5, [x3, #920]
    6d80:	f9005085 	str	x5, [x4, #160]
    6d84:	f941d065 	ldr	x5, [x3, #928]
    6d88:	f9005485 	str	x5, [x4, #168]
    6d8c:	f941d465 	ldr	x5, [x3, #936]
    6d90:	f9005885 	str	x5, [x4, #176]
    6d94:	f941d865 	ldr	x5, [x3, #944]
    6d98:	f9005c85 	str	x5, [x4, #184]
    6d9c:	f941dc65 	ldr	x5, [x3, #952]
    6da0:	f9006085 	str	x5, [x4, #192]
    6da4:	f9400480 	ldr	x0, [x4, #8]
    6da8:	f9404844 	ldr	x4, [x2, #144]
    6dac:	f901c464 	str	x4, [x3, #904]
    6db0:	f9404c44 	ldr	x4, [x2, #152]
    6db4:	f901c864 	str	x4, [x3, #912]
    6db8:	f9405044 	ldr	x4, [x2, #160]
    6dbc:	f901cc64 	str	x4, [x3, #920]
    6dc0:	f9405444 	ldr	x4, [x2, #168]
    6dc4:	f901d064 	str	x4, [x3, #928]
    6dc8:	f9405844 	ldr	x4, [x2, #176]
    6dcc:	f901d464 	str	x4, [x3, #936]
    6dd0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6dd4:	f901d864 	str	x4, [x3, #944]
    6dd8:	f901dc62 	str	x2, [x3, #952]
    6ddc:	97ffeea5 	bl	2870 <swapcontext@plt>
    6de0:	97ffff58 	bl	6b40 <fwp_free_zombie>
    6de4:	d503201f 	nop
    6de8:	91018260 	add	x0, x19, #0x60
    6dec:	b943c000 	ldr	w0, [x0, #960]
    6df0:	340001a0 	cbz	w0, 6e24 <fwp_block+0x104>
    6df4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6df8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dfc:	d65f03c0 	ret
    6e00:	97fff774 	bl	4bd0 <fwp_poll_events>
    6e04:	f9406682 	ldr	x2, [x20, #200]
    6e08:	b4ffffc2 	cbz	x2, 6e00 <fwp_block+0xe0>
    6e0c:	91018261 	add	x1, x19, #0x60
    6e10:	f9408040 	ldr	x0, [x2, #256]
    6e14:	f9006420 	str	x0, [x1, #200]
    6e18:	b5fff9c0 	cbnz	x0, 6d50 <fwp_block+0x30>
    6e1c:	f900603f 	str	xzr, [x1, #192]
    6e20:	17ffffcc 	b	6d50 <fwp_block+0x30>
    6e24:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x110>
    6e28:	91138000 	add	x0, x0, #0x4e0
    6e2c:	97ffeedd 	bl	29a0 <getenv@plt>
    6e30:	5284e202 	mov	w2, #0x2710                	// #10000
    6e34:	b4000060 	cbz	x0, 6e40 <fwp_block+0x120>
    6e38:	39400001 	ldrb	w1, [x0]
    6e3c:	350000c1 	cbnz	w1, 6e54 <fwp_block+0x134>
    6e40:	91018273 	add	x19, x19, #0x60
    6e44:	b903c262 	str	w2, [x19, #960]
    6e48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e50:	d65f03c0 	ret
    6e54:	52800142 	mov	w2, #0xa                   	// #10
    6e58:	d2800001 	mov	x1, #0x0                   	// #0
    6e5c:	97ffee21 	bl	26e0 <strtoll@plt>
    6e60:	d1000403 	sub	x3, x0, #0x1
    6e64:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6e68:	eb02007f 	cmp	x3, x2
    6e6c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6e70:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6e74:	17fffff3 	b	6e40 <fwp_block+0x120>
    6e78:	d503201f 	nop
    6e7c:	d503201f 	nop

0000000000006e80 <fwp_drop4>:
    6e80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6e84:	910003fd 	mov	x29, sp
    6e88:	a90153f3 	stp	x19, x20, [sp, #16]
    6e8c:	f0000413 	adrp	x19, 89000 <fwp_root_context+0xba0>
    6e90:	f90013f5 	str	x21, [sp, #32]
    6e94:	91190275 	add	x21, x19, #0x640
    6e98:	f949daa1 	ldr	x1, [x21, #5040]
    6e9c:	f949eea2 	ldr	x2, [x21, #5080]
    6ea0:	cb010001 	sub	x1, x0, x1
    6ea4:	eb02403f 	cmp	x1, x2, lsl #16
    6ea8:	54000382 	b.cs	6f18 <fwp_drop4+0x98>  // b.hs, b.nlast
    6eac:	d350fc22 	lsr	x2, x1, #16
    6eb0:	f949fea3 	ldr	x3, [x21, #5112]
    6eb4:	8b020842 	add	x2, x2, x2, lsl #2
    6eb8:	d37df042 	lsl	x2, x2, #3
    6ebc:	8b020064 	add	x4, x3, x2
    6ec0:	f9401094 	ldr	x20, [x4, #32]
    6ec4:	b40002b4 	cbz	x20, 6f18 <fwp_drop4+0x98>
    6ec8:	38626862 	ldrb	w2, [x3, x2]
    6ecc:	7100085f 	cmp	w2, #0x2
    6ed0:	540007a0 	b.eq	6fc4 <fwp_drop4+0x144>  // b.none
    6ed4:	7100045f 	cmp	w2, #0x1
    6ed8:	54000201 	b.ne	6f18 <fwp_drop4+0x98>  // b.any
    6edc:	29430885 	ldp	w5, w2, [x4, #24]
    6ee0:	92403c21 	and	x1, x1, #0xffff
    6ee4:	9b057c21 	mul	x1, x1, x5
    6ee8:	d360fc21 	lsr	x1, x1, #32
    6eec:	eb02003f 	cmp	x1, x2
    6ef0:	54000142 	b.cs	6f18 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ef4:	8b010294 	add	x20, x20, x1
    6ef8:	39400281 	ldrb	w1, [x20]
    6efc:	340000e1 	cbz	w1, 6f18 <fwp_drop4+0x98>
    6f00:	7100043f 	cmp	w1, #0x1
    6f04:	54000120 	b.eq	6f28 <fwp_drop4+0xa8>  // b.none
    6f08:	7103fc3f 	cmp	w1, #0xff
    6f0c:	540007c0 	b.eq	7004 <fwp_drop4+0x184>  // b.none
    6f10:	51000421 	sub	w1, w1, #0x1
    6f14:	39000281 	strb	w1, [x20]
    6f18:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f1c:	f94013f5 	ldr	x21, [sp, #32]
    6f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f24:	d65f03c0 	ret
    6f28:	f9400001 	ldr	x1, [x0]
    6f2c:	b7f80581 	tbnz	x1, #63, 6fdc <fwp_drop4+0x15c>
    6f30:	91190273 	add	x19, x19, #0x640
    6f34:	f949da61 	ldr	x1, [x19, #5040]
    6f38:	f949ee62 	ldr	x2, [x19, #5080]
    6f3c:	cb010001 	sub	x1, x0, x1
    6f40:	eb02403f 	cmp	x1, x2, lsl #16
    6f44:	54fffea2 	b.cs	6f18 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f48:	d350fc22 	lsr	x2, x1, #16
    6f4c:	8b020842 	add	x2, x2, x2, lsl #2
    6f50:	d37df042 	lsl	x2, x2, #3
    6f54:	8b020065 	add	x5, x3, x2
    6f58:	f94010a4 	ldr	x4, [x5, #32]
    6f5c:	b4fffde4 	cbz	x4, 6f18 <fwp_drop4+0x98>
    6f60:	38626862 	ldrb	w2, [x3, x2]
    6f64:	7100085f 	cmp	w2, #0x2
    6f68:	54000220 	b.eq	6fac <fwp_drop4+0x12c>  // b.none
    6f6c:	7100045f 	cmp	w2, #0x1
    6f70:	54fffd41 	b.ne	6f18 <fwp_drop4+0x98>  // b.any
    6f74:	294308a3 	ldp	w3, w2, [x5, #24]
    6f78:	92403c21 	and	x1, x1, #0xffff
    6f7c:	9b037c21 	mul	x1, x1, x3
    6f80:	d360fc21 	lsr	x1, x1, #32
    6f84:	eb02003f 	cmp	x1, x2
    6f88:	54fffc82 	b.cs	6f18 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f8c:	8b010084 	add	x4, x4, x1
    6f90:	39400081 	ldrb	w1, [x4]
    6f94:	7100043f 	cmp	w1, #0x1
    6f98:	54fffc01 	b.ne	6f18 <fwp_drop4+0x98>  // b.any
    6f9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fa0:	f94013f5 	ldr	x21, [sp, #32]
    6fa4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fa8:	17fff57e 	b	45a0 <fwp_mem_free>
    6fac:	72003c3f 	tst	w1, #0xffff
    6fb0:	54ffff00 	b.eq	6f90 <fwp_drop4+0x110>  // b.none
    6fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fb8:	f94013f5 	ldr	x21, [sp, #32]
    6fbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fc0:	d65f03c0 	ret
    6fc4:	72003c3f 	tst	w1, #0xffff
    6fc8:	54fff980 	b.eq	6ef8 <fwp_drop4+0x78>  // b.none
    6fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fd0:	f94013f5 	ldr	x21, [sp, #32]
    6fd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fd8:	d65f03c0 	ret
    6fdc:	f9400414 	ldr	x20, [x0, #8]
    6fe0:	97fffbc0 	bl	5ee0 <fwp_rc_free_arr>
    6fe4:	91190260 	add	x0, x19, #0x640
    6fe8:	f949d801 	ldr	x1, [x0, #5040]
    6fec:	f949ec00 	ldr	x0, [x0, #5080]
    6ff0:	cb010281 	sub	x1, x20, x1
    6ff4:	eb00403f 	cmp	x1, x0, lsl #16
    6ff8:	54fff902 	b.cs	6f18 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ffc:	aa1403e0 	mov	x0, x20
    7000:	17ffffab 	b	6eac <fwp_drop4+0x2c>
    7004:	ca544680 	eor	x0, x20, x20, lsr #17
    7008:	91190273 	add	x19, x19, #0x640
    700c:	ca402400 	eor	x0, x0, x0, lsr #9
    7010:	92401c00 	and	x0, x0, #0xff
    7014:	910a2402 	add	x2, x0, #0x289
    7018:	8b000e60 	add	x0, x19, x0, lsl #3
    701c:	8b020e62 	add	x2, x19, x2, lsl #3
    7020:	f94a2400 	ldr	x0, [x0, #5192]
    7024:	b50000a0 	cbnz	x0, 7038 <fwp_drop4+0x1b8>
    7028:	14000013 	b	7074 <fwp_drop4+0x1f4>
    702c:	91004002 	add	x2, x0, #0x10
    7030:	f9400800 	ldr	x0, [x0, #16]
    7034:	b4000200 	cbz	x0, 7074 <fwp_drop4+0x1f4>
    7038:	f9400001 	ldr	x1, [x0]
    703c:	eb14003f 	cmp	x1, x20
    7040:	54ffff61 	b.ne	702c <fwp_drop4+0x1ac>  // b.any
    7044:	f9400041 	ldr	x1, [x2]
    7048:	f9400420 	ldr	x0, [x1, #8]
    704c:	d1000400 	sub	x0, x0, #0x1
    7050:	f9000420 	str	x0, [x1, #8]
    7054:	f103f81f 	cmp	x0, #0xfe
    7058:	54fff601 	b.ne	6f18 <fwp_drop4+0x98>  // b.any
    705c:	39400280 	ldrb	w0, [x20]
    7060:	7103fc1f 	cmp	w0, #0xff
    7064:	540000e0 	b.eq	7080 <fwp_drop4+0x200>  // b.none
    7068:	12800020 	mov	w0, #0xfffffffe            	// #-2
    706c:	39000280 	strb	w0, [x20]
    7070:	17ffffaa 	b	6f18 <fwp_drop4+0x98>
    7074:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    7078:	91092000 	add	x0, x0, #0x248
    707c:	97fff48e 	bl	42b4 <fwp_trap>
    7080:	aa1403e0 	mov	x0, x20
    7084:	97fff4ac 	bl	4334 <fwp_rc_forget_slot.part.0>
    7088:	17fffff8 	b	7068 <fwp_drop4+0x1e8>
    708c:	d503201f 	nop

0000000000007090 <fwp_caps161>:
    7090:	34000041 	cbz	w1, 7098 <fwp_caps161+0x8>
    7094:	d65f03c0 	ret
    7098:	d0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    709c:	91190063 	add	x3, x3, #0x640
    70a0:	f949d861 	ldr	x1, [x3, #5040]
    70a4:	f949ec62 	ldr	x2, [x3, #5080]
    70a8:	cb010001 	sub	x1, x0, x1
    70ac:	eb02403f 	cmp	x1, x2, lsl #16
    70b0:	54ffff22 	b.cs	7094 <fwp_caps161+0x4>  // b.hs, b.nlast
    70b4:	d350fc22 	lsr	x2, x1, #16
    70b8:	f949fc65 	ldr	x5, [x3, #5112]
    70bc:	8b020842 	add	x2, x2, x2, lsl #2
    70c0:	d37df042 	lsl	x2, x2, #3
    70c4:	8b0200a4 	add	x4, x5, x2
    70c8:	f9401083 	ldr	x3, [x4, #32]
    70cc:	b4fffe43 	cbz	x3, 7094 <fwp_caps161+0x4>
    70d0:	386268a2 	ldrb	w2, [x5, x2]
    70d4:	7100085f 	cmp	w2, #0x2
    70d8:	540001c0 	b.eq	7110 <fwp_caps161+0x80>  // b.none
    70dc:	7100045f 	cmp	w2, #0x1
    70e0:	54fffda1 	b.ne	7094 <fwp_caps161+0x4>  // b.any
    70e4:	29430885 	ldp	w5, w2, [x4, #24]
    70e8:	92403c21 	and	x1, x1, #0xffff
    70ec:	9b057c21 	mul	x1, x1, x5
    70f0:	d360fc21 	lsr	x1, x1, #32
    70f4:	eb02003f 	cmp	x1, x2
    70f8:	54fffce2 	b.cs	7094 <fwp_caps161+0x4>  // b.hs, b.nlast
    70fc:	8b010063 	add	x3, x3, x1
    7100:	39400061 	ldrb	w1, [x3]
    7104:	7100043f 	cmp	w1, #0x1
    7108:	54fffc61 	b.ne	7094 <fwp_caps161+0x4>  // b.any
    710c:	17fff525 	b	45a0 <fwp_mem_free>
    7110:	72003c3f 	tst	w1, #0xffff
    7114:	54ffff60 	b.eq	7100 <fwp_caps161+0x70>  // b.none
    7118:	d65f03c0 	ret
    711c:	d503201f 	nop

0000000000007120 <fwp_args23>:
    7120:	7100003f 	cmp	w1, #0x0
    7124:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7128:	54000041 	b.ne	7130 <fwp_args23+0x10>  // b.any
    712c:	d65f03c0 	ret
    7130:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7134:	91190042 	add	x2, x2, #0x640
    7138:	f9400001 	ldr	x1, [x0]
    713c:	f949d843 	ldr	x3, [x2, #5040]
    7140:	f949ec40 	ldr	x0, [x2, #5080]
    7144:	cb030021 	sub	x1, x1, x3
    7148:	eb00403f 	cmp	x1, x0, lsl #16
    714c:	54ffff02 	b.cs	712c <fwp_args23+0xc>  // b.hs, b.nlast
    7150:	d350fc20 	lsr	x0, x1, #16
    7154:	f949fc44 	ldr	x4, [x2, #5112]
    7158:	8b000800 	add	x0, x0, x0, lsl #2
    715c:	d37df002 	lsl	x2, x0, #3
    7160:	8b020083 	add	x3, x4, x2
    7164:	f9401060 	ldr	x0, [x3, #32]
    7168:	b4fffe20 	cbz	x0, 712c <fwp_args23+0xc>
    716c:	38626882 	ldrb	w2, [x4, x2]
    7170:	7100085f 	cmp	w2, #0x2
    7174:	54000320 	b.eq	71d8 <fwp_args23+0xb8>  // b.none
    7178:	7100045f 	cmp	w2, #0x1
    717c:	54fffd81 	b.ne	712c <fwp_args23+0xc>  // b.any
    7180:	29430864 	ldp	w4, w2, [x3, #24]
    7184:	92403c21 	and	x1, x1, #0xffff
    7188:	9b047c21 	mul	x1, x1, x4
    718c:	d360fc21 	lsr	x1, x1, #32
    7190:	eb02003f 	cmp	x1, x2
    7194:	54fffcc2 	b.cs	712c <fwp_args23+0xc>  // b.hs, b.nlast
    7198:	8b010000 	add	x0, x0, x1
    719c:	39400001 	ldrb	w1, [x0]
    71a0:	34fffc61 	cbz	w1, 712c <fwp_args23+0xc>
    71a4:	b0000142 	adrp	x2, 30000 <__data_start>
    71a8:	91018042 	add	x2, x2, #0x60
    71ac:	b9413043 	ldr	w3, [x2, #304]
    71b0:	350000c3 	cbnz	w3, 71c8 <fwp_args23+0xa8>
    71b4:	7103f43f 	cmp	w1, #0xfd
    71b8:	54000168 	b.hi	71e4 <fwp_args23+0xc4>  // b.pmore
    71bc:	11000421 	add	w1, w1, #0x1
    71c0:	39000001 	strb	w1, [x0]
    71c4:	d65f03c0 	ret
    71c8:	f940ac43 	ldr	x3, [x2, #344]
    71cc:	91000463 	add	x3, x3, #0x1
    71d0:	f900ac43 	str	x3, [x2, #344]
    71d4:	17fffff8 	b	71b4 <fwp_args23+0x94>
    71d8:	72003c3f 	tst	w1, #0xffff
    71dc:	54fffe00 	b.eq	719c <fwp_args23+0x7c>  // b.none
    71e0:	d65f03c0 	ret
    71e4:	17fff568 	b	4784 <fwp_rc_wide_dup>
    71e8:	d503201f 	nop
    71ec:	d503201f 	nop

00000000000071f0 <fwp_args12>:
    71f0:	7100003f 	cmp	w1, #0x0
    71f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    71f8:	54000041 	b.ne	7200 <fwp_args12+0x10>  // b.any
    71fc:	d65f03c0 	ret
    7200:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7204:	91190042 	add	x2, x2, #0x640
    7208:	f9400001 	ldr	x1, [x0]
    720c:	f949d843 	ldr	x3, [x2, #5040]
    7210:	f949ec40 	ldr	x0, [x2, #5080]
    7214:	cb030021 	sub	x1, x1, x3
    7218:	eb00403f 	cmp	x1, x0, lsl #16
    721c:	54ffff02 	b.cs	71fc <fwp_args12+0xc>  // b.hs, b.nlast
    7220:	d350fc20 	lsr	x0, x1, #16
    7224:	f949fc44 	ldr	x4, [x2, #5112]
    7228:	8b000800 	add	x0, x0, x0, lsl #2
    722c:	d37df002 	lsl	x2, x0, #3
    7230:	8b020083 	add	x3, x4, x2
    7234:	f9401060 	ldr	x0, [x3, #32]
    7238:	b4fffe20 	cbz	x0, 71fc <fwp_args12+0xc>
    723c:	38626882 	ldrb	w2, [x4, x2]
    7240:	7100085f 	cmp	w2, #0x2
    7244:	54000320 	b.eq	72a8 <fwp_args12+0xb8>  // b.none
    7248:	7100045f 	cmp	w2, #0x1
    724c:	54fffd81 	b.ne	71fc <fwp_args12+0xc>  // b.any
    7250:	29430864 	ldp	w4, w2, [x3, #24]
    7254:	92403c21 	and	x1, x1, #0xffff
    7258:	9b047c21 	mul	x1, x1, x4
    725c:	d360fc21 	lsr	x1, x1, #32
    7260:	eb02003f 	cmp	x1, x2
    7264:	54fffcc2 	b.cs	71fc <fwp_args12+0xc>  // b.hs, b.nlast
    7268:	8b010000 	add	x0, x0, x1
    726c:	39400001 	ldrb	w1, [x0]
    7270:	34fffc61 	cbz	w1, 71fc <fwp_args12+0xc>
    7274:	b0000142 	adrp	x2, 30000 <__data_start>
    7278:	91018042 	add	x2, x2, #0x60
    727c:	b9413043 	ldr	w3, [x2, #304]
    7280:	350000c3 	cbnz	w3, 7298 <fwp_args12+0xa8>
    7284:	7103f43f 	cmp	w1, #0xfd
    7288:	54000168 	b.hi	72b4 <fwp_args12+0xc4>  // b.pmore
    728c:	11000421 	add	w1, w1, #0x1
    7290:	39000001 	strb	w1, [x0]
    7294:	d65f03c0 	ret
    7298:	f940ac43 	ldr	x3, [x2, #344]
    729c:	91000463 	add	x3, x3, #0x1
    72a0:	f900ac43 	str	x3, [x2, #344]
    72a4:	17fffff8 	b	7284 <fwp_args12+0x94>
    72a8:	72003c3f 	tst	w1, #0xffff
    72ac:	54fffe00 	b.eq	726c <fwp_args12+0x7c>  // b.none
    72b0:	d65f03c0 	ret
    72b4:	17fff534 	b	4784 <fwp_rc_wide_dup>
    72b8:	d503201f 	nop
    72bc:	d503201f 	nop

00000000000072c0 <fwp_drop2>:
    72c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    72c4:	910003fd 	mov	x29, sp
    72c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    72cc:	d0000416 	adrp	x22, 89000 <fwp_root_context+0xba0>
    72d0:	911902d5 	add	x21, x22, #0x640
    72d4:	a90153f3 	stp	x19, x20, [sp, #16]
    72d8:	aa0003f3 	mov	x19, x0
    72dc:	f949daa1 	ldr	x1, [x21, #5040]
    72e0:	f949eea0 	ldr	x0, [x21, #5080]
    72e4:	cb010261 	sub	x1, x19, x1
    72e8:	eb00403f 	cmp	x1, x0, lsl #16
    72ec:	54000382 	b.cs	735c <fwp_drop2+0x9c>  // b.hs, b.nlast
    72f0:	d350fc22 	lsr	x2, x1, #16
    72f4:	f949fea3 	ldr	x3, [x21, #5112]
    72f8:	8b020842 	add	x2, x2, x2, lsl #2
    72fc:	d37df042 	lsl	x2, x2, #3
    7300:	8b020060 	add	x0, x3, x2
    7304:	f9401014 	ldr	x20, [x0, #32]
    7308:	b40002b4 	cbz	x20, 735c <fwp_drop2+0x9c>
    730c:	38626862 	ldrb	w2, [x3, x2]
    7310:	7100085f 	cmp	w2, #0x2
    7314:	540002c0 	b.eq	736c <fwp_drop2+0xac>  // b.none
    7318:	7100045f 	cmp	w2, #0x1
    731c:	54000201 	b.ne	735c <fwp_drop2+0x9c>  // b.any
    7320:	29430002 	ldp	w2, w0, [x0, #24]
    7324:	92403c21 	and	x1, x1, #0xffff
    7328:	9b027c21 	mul	x1, x1, x2
    732c:	d360fc21 	lsr	x1, x1, #32
    7330:	eb00003f 	cmp	x1, x0
    7334:	54000142 	b.cs	735c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7338:	8b010294 	add	x20, x20, x1
    733c:	39400280 	ldrb	w0, [x20]
    7340:	340000e0 	cbz	w0, 735c <fwp_drop2+0x9c>
    7344:	7100041f 	cmp	w0, #0x1
    7348:	540001e0 	b.eq	7384 <fwp_drop2+0xc4>  // b.none
    734c:	7103fc1f 	cmp	w0, #0xff
    7350:	540007c0 	b.eq	7448 <fwp_drop2+0x188>  // b.none
    7354:	51000400 	sub	w0, w0, #0x1
    7358:	39000280 	strb	w0, [x20]
    735c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7360:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7364:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7368:	d65f03c0 	ret
    736c:	72003c3f 	tst	w1, #0xffff
    7370:	54fffe60 	b.eq	733c <fwp_drop2+0x7c>  // b.none
    7374:	a94153f3 	ldp	x19, x20, [sp, #16]
    7378:	a9425bf5 	ldp	x21, x22, [sp, #32]
    737c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7380:	d65f03c0 	ret
    7384:	911902c2 	add	x2, x22, #0x640
    7388:	f9400660 	ldr	x0, [x19, #8]
    738c:	f949d841 	ldr	x1, [x2, #5040]
    7390:	f949ec42 	ldr	x2, [x2, #5080]
    7394:	cb010001 	sub	x1, x0, x1
    7398:	eb02403f 	cmp	x1, x2, lsl #16
    739c:	54000362 	b.cs	7408 <fwp_drop2+0x148>  // b.hs, b.nlast
    73a0:	d350fc22 	lsr	x2, x1, #16
    73a4:	8b020842 	add	x2, x2, x2, lsl #2
    73a8:	d37df042 	lsl	x2, x2, #3
    73ac:	8b020064 	add	x4, x3, x2
    73b0:	f9401094 	ldr	x20, [x4, #32]
    73b4:	b40002b4 	cbz	x20, 7408 <fwp_drop2+0x148>
    73b8:	38626862 	ldrb	w2, [x3, x2]
    73bc:	7100085f 	cmp	w2, #0x2
    73c0:	540003e0 	b.eq	743c <fwp_drop2+0x17c>  // b.none
    73c4:	7100045f 	cmp	w2, #0x1
    73c8:	54000201 	b.ne	7408 <fwp_drop2+0x148>  // b.any
    73cc:	29430883 	ldp	w3, w2, [x4, #24]
    73d0:	92403c21 	and	x1, x1, #0xffff
    73d4:	9b037c21 	mul	x1, x1, x3
    73d8:	d360fc21 	lsr	x1, x1, #32
    73dc:	eb02003f 	cmp	x1, x2
    73e0:	54000142 	b.cs	7408 <fwp_drop2+0x148>  // b.hs, b.nlast
    73e4:	8b010294 	add	x20, x20, x1
    73e8:	39400281 	ldrb	w1, [x20]
    73ec:	340000e1 	cbz	w1, 7408 <fwp_drop2+0x148>
    73f0:	7100043f 	cmp	w1, #0x1
    73f4:	54000200 	b.eq	7434 <fwp_drop2+0x174>  // b.none
    73f8:	7103fc3f 	cmp	w1, #0xff
    73fc:	54000640 	b.eq	74c4 <fwp_drop2+0x204>  // b.none
    7400:	51000421 	sub	w1, w1, #0x1
    7404:	39000281 	strb	w1, [x20]
    7408:	f9400a74 	ldr	x20, [x19, #16]
    740c:	aa1303e0 	mov	x0, x19
    7410:	97fffab4 	bl	5ee0 <fwp_rc_free_arr>
    7414:	911902c0 	add	x0, x22, #0x640
    7418:	f949d801 	ldr	x1, [x0, #5040]
    741c:	f949ec00 	ldr	x0, [x0, #5080]
    7420:	cb010281 	sub	x1, x20, x1
    7424:	eb00403f 	cmp	x1, x0, lsl #16
    7428:	54fff9a2 	b.cs	735c <fwp_drop2+0x9c>  // b.hs, b.nlast
    742c:	aa1403f3 	mov	x19, x20
    7430:	17ffffb0 	b	72f0 <fwp_drop2+0x30>
    7434:	97fffaab 	bl	5ee0 <fwp_rc_free_arr>
    7438:	17fffff4 	b	7408 <fwp_drop2+0x148>
    743c:	72003c3f 	tst	w1, #0xffff
    7440:	54fffe41 	b.ne	7408 <fwp_drop2+0x148>  // b.any
    7444:	17ffffe9 	b	73e8 <fwp_drop2+0x128>
    7448:	ca544681 	eor	x1, x20, x20, lsr #17
    744c:	911902c0 	add	x0, x22, #0x640
    7450:	ca412421 	eor	x1, x1, x1, lsr #9
    7454:	92401c21 	and	x1, x1, #0xff
    7458:	910a2422 	add	x2, x1, #0x289
    745c:	8b010c01 	add	x1, x0, x1, lsl #3
    7460:	8b020c02 	add	x2, x0, x2, lsl #3
    7464:	f94a2420 	ldr	x0, [x1, #5192]
    7468:	b50000a0 	cbnz	x0, 747c <fwp_drop2+0x1bc>
    746c:	14000013 	b	74b8 <fwp_drop2+0x1f8>
    7470:	91004002 	add	x2, x0, #0x10
    7474:	f9400800 	ldr	x0, [x0, #16]
    7478:	b4000200 	cbz	x0, 74b8 <fwp_drop2+0x1f8>
    747c:	f9400001 	ldr	x1, [x0]
    7480:	eb14003f 	cmp	x1, x20
    7484:	54ffff61 	b.ne	7470 <fwp_drop2+0x1b0>  // b.any
    7488:	f9400041 	ldr	x1, [x2]
    748c:	f9400420 	ldr	x0, [x1, #8]
    7490:	d1000400 	sub	x0, x0, #0x1
    7494:	f9000420 	str	x0, [x1, #8]
    7498:	f103f81f 	cmp	x0, #0xfe
    749c:	54fff601 	b.ne	735c <fwp_drop2+0x9c>  // b.any
    74a0:	39400280 	ldrb	w0, [x20]
    74a4:	7103fc1f 	cmp	w0, #0xff
    74a8:	54000460 	b.eq	7534 <fwp_drop2+0x274>  // b.none
    74ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    74b0:	39000280 	strb	w0, [x20]
    74b4:	17ffffaa 	b	735c <fwp_drop2+0x9c>
    74b8:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    74bc:	91092000 	add	x0, x0, #0x248
    74c0:	97fff37d 	bl	42b4 <fwp_trap>
    74c4:	ca544680 	eor	x0, x20, x20, lsr #17
    74c8:	911902c1 	add	x1, x22, #0x640
    74cc:	ca402400 	eor	x0, x0, x0, lsr #9
    74d0:	92401c00 	and	x0, x0, #0xff
    74d4:	910a2402 	add	x2, x0, #0x289
    74d8:	8b000c20 	add	x0, x1, x0, lsl #3
    74dc:	8b020c22 	add	x2, x1, x2, lsl #3
    74e0:	f94a2400 	ldr	x0, [x0, #5192]
    74e4:	b50000a0 	cbnz	x0, 74f8 <fwp_drop2+0x238>
    74e8:	17fffff4 	b	74b8 <fwp_drop2+0x1f8>
    74ec:	91004002 	add	x2, x0, #0x10
    74f0:	f9400800 	ldr	x0, [x0, #16]
    74f4:	b4fffe20 	cbz	x0, 74b8 <fwp_drop2+0x1f8>
    74f8:	f9400001 	ldr	x1, [x0]
    74fc:	eb14003f 	cmp	x1, x20
    7500:	54ffff61 	b.ne	74ec <fwp_drop2+0x22c>  // b.any
    7504:	f9400041 	ldr	x1, [x2]
    7508:	f9400420 	ldr	x0, [x1, #8]
    750c:	d1000400 	sub	x0, x0, #0x1
    7510:	f9000420 	str	x0, [x1, #8]
    7514:	f103f81f 	cmp	x0, #0xfe
    7518:	54fff781 	b.ne	7408 <fwp_drop2+0x148>  // b.any
    751c:	39400280 	ldrb	w0, [x20]
    7520:	7103fc1f 	cmp	w0, #0xff
    7524:	540000e0 	b.eq	7540 <fwp_drop2+0x280>  // b.none
    7528:	12800020 	mov	w0, #0xfffffffe            	// #-2
    752c:	39000280 	strb	w0, [x20]
    7530:	17ffffb6 	b	7408 <fwp_drop2+0x148>
    7534:	aa1403e0 	mov	x0, x20
    7538:	97fff37f 	bl	4334 <fwp_rc_forget_slot.part.0>
    753c:	17ffffdc 	b	74ac <fwp_drop2+0x1ec>
    7540:	aa1403e0 	mov	x0, x20
    7544:	97fff37c 	bl	4334 <fwp_rc_forget_slot.part.0>
    7548:	17fffff8 	b	7528 <fwp_drop2+0x268>
    754c:	d503201f 	nop

0000000000007550 <fwp_arg_drop23>:
    7550:	7100003f 	cmp	w1, #0x0
    7554:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7558:	54000041 	b.ne	7560 <fwp_arg_drop23+0x10>  // b.any
    755c:	d65f03c0 	ret
    7560:	f9400000 	ldr	x0, [x0]
    7564:	17ffff57 	b	72c0 <fwp_drop2>
    7568:	d503201f 	nop
    756c:	d503201f 	nop

0000000000007570 <fwp_caps12>:
    7570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7574:	910003fd 	mov	x29, sp
    7578:	f9000bf3 	str	x19, [sp, #16]
    757c:	aa0003f3 	mov	x19, x0
    7580:	b9400400 	ldr	w0, [x0, #4]
    7584:	340004a0 	cbz	w0, 7618 <fwp_caps12+0xa8>
    7588:	f9400660 	ldr	x0, [x19, #8]
    758c:	350004e1 	cbnz	w1, 7628 <fwp_caps12+0xb8>
    7590:	97fffb30 	bl	6250 <fwp_drop0>
    7594:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7598:	91190042 	add	x2, x2, #0x640
    759c:	f949d840 	ldr	x0, [x2, #5040]
    75a0:	f949ec41 	ldr	x1, [x2, #5080]
    75a4:	cb000260 	sub	x0, x19, x0
    75a8:	eb01401f 	cmp	x0, x1, lsl #16
    75ac:	54000382 	b.cs	761c <fwp_caps12+0xac>  // b.hs, b.nlast
    75b0:	d350fc01 	lsr	x1, x0, #16
    75b4:	f949fc44 	ldr	x4, [x2, #5112]
    75b8:	8b010821 	add	x1, x1, x1, lsl #2
    75bc:	d37df021 	lsl	x1, x1, #3
    75c0:	8b010083 	add	x3, x4, x1
    75c4:	f9401062 	ldr	x2, [x3, #32]
    75c8:	b40002a2 	cbz	x2, 761c <fwp_caps12+0xac>
    75cc:	38616881 	ldrb	w1, [x4, x1]
    75d0:	7100083f 	cmp	w1, #0x2
    75d4:	54000740 	b.eq	76bc <fwp_caps12+0x14c>  // b.none
    75d8:	7100043f 	cmp	w1, #0x1
    75dc:	54000201 	b.ne	761c <fwp_caps12+0xac>  // b.any
    75e0:	29430464 	ldp	w4, w1, [x3, #24]
    75e4:	92403c00 	and	x0, x0, #0xffff
    75e8:	9b047c00 	mul	x0, x0, x4
    75ec:	d360fc00 	lsr	x0, x0, #32
    75f0:	eb01001f 	cmp	x0, x1
    75f4:	54000142 	b.cs	761c <fwp_caps12+0xac>  // b.hs, b.nlast
    75f8:	8b000042 	add	x2, x2, x0
    75fc:	39400040 	ldrb	w0, [x2]
    7600:	7100041f 	cmp	w0, #0x1
    7604:	540000c1 	b.ne	761c <fwp_caps12+0xac>  // b.any
    7608:	aa1303e0 	mov	x0, x19
    760c:	f9400bf3 	ldr	x19, [sp, #16]
    7610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7614:	17fff3e3 	b	45a0 <fwp_mem_free>
    7618:	34fffbe1 	cbz	w1, 7594 <fwp_caps12+0x24>
    761c:	f9400bf3 	ldr	x19, [sp, #16]
    7620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7624:	d65f03c0 	ret
    7628:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    762c:	91190042 	add	x2, x2, #0x640
    7630:	f949d843 	ldr	x3, [x2, #5040]
    7634:	f949ec41 	ldr	x1, [x2, #5080]
    7638:	cb030000 	sub	x0, x0, x3
    763c:	eb01401f 	cmp	x0, x1, lsl #16
    7640:	54fffee2 	b.cs	761c <fwp_caps12+0xac>  // b.hs, b.nlast
    7644:	d350fc01 	lsr	x1, x0, #16
    7648:	f949fc44 	ldr	x4, [x2, #5112]
    764c:	8b010821 	add	x1, x1, x1, lsl #2
    7650:	d37df021 	lsl	x1, x1, #3
    7654:	8b010083 	add	x3, x4, x1
    7658:	f9401062 	ldr	x2, [x3, #32]
    765c:	b4fffe02 	cbz	x2, 761c <fwp_caps12+0xac>
    7660:	38616881 	ldrb	w1, [x4, x1]
    7664:	7100083f 	cmp	w1, #0x2
    7668:	54000300 	b.eq	76c8 <fwp_caps12+0x158>  // b.none
    766c:	7100043f 	cmp	w1, #0x1
    7670:	54fffd61 	b.ne	761c <fwp_caps12+0xac>  // b.any
    7674:	92403c01 	and	x1, x0, #0xffff
    7678:	29430064 	ldp	w4, w0, [x3, #24]
    767c:	9b047c21 	mul	x1, x1, x4
    7680:	d360fc21 	lsr	x1, x1, #32
    7684:	eb00003f 	cmp	x1, x0
    7688:	54fffca2 	b.cs	761c <fwp_caps12+0xac>  // b.hs, b.nlast
    768c:	8b010042 	add	x2, x2, x1
    7690:	39400040 	ldrb	w0, [x2]
    7694:	34fffc40 	cbz	w0, 761c <fwp_caps12+0xac>
    7698:	b0000141 	adrp	x1, 30000 <__data_start>
    769c:	91018021 	add	x1, x1, #0x60
    76a0:	b9413023 	ldr	w3, [x1, #304]
    76a4:	35000183 	cbnz	w3, 76d4 <fwp_caps12+0x164>
    76a8:	7103f41f 	cmp	w0, #0xfd
    76ac:	540001c8 	b.hi	76e4 <fwp_caps12+0x174>  // b.pmore
    76b0:	11000400 	add	w0, w0, #0x1
    76b4:	39000040 	strb	w0, [x2]
    76b8:	17ffffd9 	b	761c <fwp_caps12+0xac>
    76bc:	72003c1f 	tst	w0, #0xffff
    76c0:	54fffae1 	b.ne	761c <fwp_caps12+0xac>  // b.any
    76c4:	17ffffce 	b	75fc <fwp_caps12+0x8c>
    76c8:	72003c1f 	tst	w0, #0xffff
    76cc:	54fffa81 	b.ne	761c <fwp_caps12+0xac>  // b.any
    76d0:	17fffff0 	b	7690 <fwp_caps12+0x120>
    76d4:	f940ac23 	ldr	x3, [x1, #344]
    76d8:	91000463 	add	x3, x3, #0x1
    76dc:	f900ac23 	str	x3, [x1, #344]
    76e0:	17fffff2 	b	76a8 <fwp_caps12+0x138>
    76e4:	f9400bf3 	ldr	x19, [sp, #16]
    76e8:	aa0203e0 	mov	x0, x2
    76ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    76f0:	17fff425 	b	4784 <fwp_rc_wide_dup>

00000000000076f4 <fwp_caps23>:
    76f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    76f8:	910003fd 	mov	x29, sp
    76fc:	f9000bf3 	str	x19, [sp, #16]
    7700:	aa0003f3 	mov	x19, x0
    7704:	b9400400 	ldr	w0, [x0, #4]
    7708:	340004a0 	cbz	w0, 779c <fwp_caps23+0xa8>
    770c:	f9400660 	ldr	x0, [x19, #8]
    7710:	350004e1 	cbnz	w1, 77ac <fwp_caps23+0xb8>
    7714:	97fffeeb 	bl	72c0 <fwp_drop2>
    7718:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    771c:	91190042 	add	x2, x2, #0x640
    7720:	f949d840 	ldr	x0, [x2, #5040]
    7724:	f949ec41 	ldr	x1, [x2, #5080]
    7728:	cb000260 	sub	x0, x19, x0
    772c:	eb01401f 	cmp	x0, x1, lsl #16
    7730:	54000382 	b.cs	77a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    7734:	d350fc01 	lsr	x1, x0, #16
    7738:	f949fc44 	ldr	x4, [x2, #5112]
    773c:	8b010821 	add	x1, x1, x1, lsl #2
    7740:	d37df021 	lsl	x1, x1, #3
    7744:	8b010083 	add	x3, x4, x1
    7748:	f9401062 	ldr	x2, [x3, #32]
    774c:	b40002a2 	cbz	x2, 77a0 <fwp_caps23+0xac>
    7750:	38616881 	ldrb	w1, [x4, x1]
    7754:	7100083f 	cmp	w1, #0x2
    7758:	54000740 	b.eq	7840 <fwp_caps23+0x14c>  // b.none
    775c:	7100043f 	cmp	w1, #0x1
    7760:	54000201 	b.ne	77a0 <fwp_caps23+0xac>  // b.any
    7764:	29430464 	ldp	w4, w1, [x3, #24]
    7768:	92403c00 	and	x0, x0, #0xffff
    776c:	9b047c00 	mul	x0, x0, x4
    7770:	d360fc00 	lsr	x0, x0, #32
    7774:	eb01001f 	cmp	x0, x1
    7778:	54000142 	b.cs	77a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    777c:	8b000042 	add	x2, x2, x0
    7780:	39400040 	ldrb	w0, [x2]
    7784:	7100041f 	cmp	w0, #0x1
    7788:	540000c1 	b.ne	77a0 <fwp_caps23+0xac>  // b.any
    778c:	aa1303e0 	mov	x0, x19
    7790:	f9400bf3 	ldr	x19, [sp, #16]
    7794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7798:	17fff382 	b	45a0 <fwp_mem_free>
    779c:	34fffbe1 	cbz	w1, 7718 <fwp_caps23+0x24>
    77a0:	f9400bf3 	ldr	x19, [sp, #16]
    77a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77a8:	d65f03c0 	ret
    77ac:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    77b0:	91190042 	add	x2, x2, #0x640
    77b4:	f949d843 	ldr	x3, [x2, #5040]
    77b8:	f949ec41 	ldr	x1, [x2, #5080]
    77bc:	cb030000 	sub	x0, x0, x3
    77c0:	eb01401f 	cmp	x0, x1, lsl #16
    77c4:	54fffee2 	b.cs	77a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    77c8:	d350fc01 	lsr	x1, x0, #16
    77cc:	f949fc44 	ldr	x4, [x2, #5112]
    77d0:	8b010821 	add	x1, x1, x1, lsl #2
    77d4:	d37df021 	lsl	x1, x1, #3
    77d8:	8b010083 	add	x3, x4, x1
    77dc:	f9401062 	ldr	x2, [x3, #32]
    77e0:	b4fffe02 	cbz	x2, 77a0 <fwp_caps23+0xac>
    77e4:	38616881 	ldrb	w1, [x4, x1]
    77e8:	7100083f 	cmp	w1, #0x2
    77ec:	54000300 	b.eq	784c <fwp_caps23+0x158>  // b.none
    77f0:	7100043f 	cmp	w1, #0x1
    77f4:	54fffd61 	b.ne	77a0 <fwp_caps23+0xac>  // b.any
    77f8:	92403c01 	and	x1, x0, #0xffff
    77fc:	29430064 	ldp	w4, w0, [x3, #24]
    7800:	9b047c21 	mul	x1, x1, x4
    7804:	d360fc21 	lsr	x1, x1, #32
    7808:	eb00003f 	cmp	x1, x0
    780c:	54fffca2 	b.cs	77a0 <fwp_caps23+0xac>  // b.hs, b.nlast
    7810:	8b010042 	add	x2, x2, x1
    7814:	39400040 	ldrb	w0, [x2]
    7818:	34fffc40 	cbz	w0, 77a0 <fwp_caps23+0xac>
    781c:	b0000141 	adrp	x1, 30000 <__data_start>
    7820:	91018021 	add	x1, x1, #0x60
    7824:	b9413023 	ldr	w3, [x1, #304]
    7828:	35000183 	cbnz	w3, 7858 <fwp_caps23+0x164>
    782c:	7103f41f 	cmp	w0, #0xfd
    7830:	540001c8 	b.hi	7868 <fwp_caps23+0x174>  // b.pmore
    7834:	11000400 	add	w0, w0, #0x1
    7838:	39000040 	strb	w0, [x2]
    783c:	17ffffd9 	b	77a0 <fwp_caps23+0xac>
    7840:	72003c1f 	tst	w0, #0xffff
    7844:	54fffae1 	b.ne	77a0 <fwp_caps23+0xac>  // b.any
    7848:	17ffffce 	b	7780 <fwp_caps23+0x8c>
    784c:	72003c1f 	tst	w0, #0xffff
    7850:	54fffa81 	b.ne	77a0 <fwp_caps23+0xac>  // b.any
    7854:	17fffff0 	b	7814 <fwp_caps23+0x120>
    7858:	f940ac23 	ldr	x3, [x1, #344]
    785c:	91000463 	add	x3, x3, #0x1
    7860:	f900ac23 	str	x3, [x1, #344]
    7864:	17fffff2 	b	782c <fwp_caps23+0x138>
    7868:	f9400bf3 	ldr	x19, [sp, #16]
    786c:	aa0203e0 	mov	x0, x2
    7870:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7874:	17fff3c4 	b	4784 <fwp_rc_wide_dup>
    7878:	d503201f 	nop
    787c:	d503201f 	nop

0000000000007880 <f23>:
    7880:	d10203ff 	sub	sp, sp, #0x80
    7884:	90000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    7888:	f947f421 	ldr	x1, [x1, #4072]
    788c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7890:	910083fd 	add	x29, sp, #0x20
    7894:	a9045bf5 	stp	x21, x22, [sp, #64]
    7898:	d0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    789c:	911902a3 	add	x3, x21, #0x640
    78a0:	a90353f3 	stp	x19, x20, [sp, #48]
    78a4:	aa0003f6 	mov	x22, x0
    78a8:	a90563f7 	stp	x23, x24, [sp, #80]
    78ac:	a9066bf9 	stp	x25, x26, [sp, #96]
    78b0:	f949ec62 	ldr	x2, [x3, #5080]
    78b4:	f9400024 	ldr	x4, [x1]
    78b8:	f9000fe4 	str	x4, [sp, #24]
    78bc:	d2800004 	mov	x4, #0x0                   	// #0
    78c0:	f949d861 	ldr	x1, [x3, #5040]
    78c4:	d370bc42 	lsl	x2, x2, #16
    78c8:	b4001920 	cbz	x0, 7bec <f23+0x36c>
    78cc:	f9400817 	ldr	x23, [x0, #16]
    78d0:	cb0102e1 	sub	x1, x23, x1
    78d4:	eb02003f 	cmp	x1, x2
    78d8:	540003e2 	b.cs	7954 <f23+0xd4>  // b.hs, b.nlast
    78dc:	f949fc60 	ldr	x0, [x3, #5112]
    78e0:	d350fc22 	lsr	x2, x1, #16
    78e4:	8b020842 	add	x2, x2, x2, lsl #2
    78e8:	8b020c02 	add	x2, x0, x2, lsl #3
    78ec:	f9401040 	ldr	x0, [x2, #32]
    78f0:	b4000320 	cbz	x0, 7954 <f23+0xd4>
    78f4:	39400043 	ldrb	w3, [x2]
    78f8:	7100087f 	cmp	w3, #0x2
    78fc:	540015e0 	b.eq	7bb8 <f23+0x338>  // b.none
    7900:	7100047f 	cmp	w3, #0x1
    7904:	54000241 	b.ne	794c <f23+0xcc>  // b.any
    7908:	29430843 	ldp	w3, w2, [x2, #24]
    790c:	92403c21 	and	x1, x1, #0xffff
    7910:	9b037c21 	mul	x1, x1, x3
    7914:	d360fc21 	lsr	x1, x1, #32
    7918:	eb02003f 	cmp	x1, x2
    791c:	54000182 	b.cs	794c <f23+0xcc>  // b.hs, b.nlast
    7920:	8b010000 	add	x0, x0, x1
    7924:	39400001 	ldrb	w1, [x0]
    7928:	34000121 	cbz	w1, 794c <f23+0xcc>
    792c:	b0000142 	adrp	x2, 30000 <__data_start>
    7930:	91018042 	add	x2, x2, #0x60
    7934:	b9413043 	ldr	w3, [x2, #304]
    7938:	35001463 	cbnz	w3, 7bc4 <f23+0x344>
    793c:	7103f43f 	cmp	w1, #0xfd
    7940:	54001888 	b.hi	7c50 <f23+0x3d0>  // b.pmore
    7944:	11000421 	add	w1, w1, #0x1
    7948:	39000001 	strb	w1, [x0]
    794c:	d2800002 	mov	x2, #0x0                   	// #0
    7950:	b40000f6 	cbz	x22, 796c <f23+0xec>
    7954:	aa1603e1 	mov	x1, x22
    7958:	d2800002 	mov	x2, #0x0                   	// #0
    795c:	d503201f 	nop
    7960:	f9400821 	ldr	x1, [x1, #16]
    7964:	91000442 	add	x2, x2, #0x1
    7968:	b5ffffc1 	cbnz	x1, 7960 <f23+0xe0>
    796c:	b4001477 	cbz	x23, 7bf8 <f23+0x378>
    7970:	aa1703e1 	mov	x1, x23
    7974:	d2800003 	mov	x3, #0x0                   	// #0
    7978:	f9400821 	ldr	x1, [x1, #16]
    797c:	91000463 	add	x3, x3, #0x1
    7980:	b5ffffc1 	cbnz	x1, 7978 <f23+0xf8>
    7984:	eb02007f 	cmp	x3, x2
    7988:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    798c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7990:	eb00027f 	cmp	x19, x0
    7994:	540010a8 	b.hi	7ba8 <f23+0x328>  // b.pmore
    7998:	d37ffa74 	lsl	x20, x19, #1
    799c:	52800041 	mov	w1, #0x2                   	// #2
    79a0:	91000680 	add	x0, x20, #0x1
    79a4:	d37df000 	lsl	x0, x0, #3
    79a8:	97fff5ba 	bl	5090 <fwp_heap_alloc>
    79ac:	aa0003f8 	mov	x24, x0
    79b0:	911902a1 	add	x1, x21, #0x640
    79b4:	aa0103e0 	mov	x0, x1
    79b8:	f9000314 	str	x20, [x24]
    79bc:	f949d821 	ldr	x1, [x1, #5040]
    79c0:	f949ec00 	ldr	x0, [x0, #5080]
    79c4:	cb010301 	sub	x1, x24, x1
    79c8:	eb00403f 	cmp	x1, x0, lsl #16
    79cc:	54000342 	b.cs	7a34 <f23+0x1b4>  // b.hs, b.nlast
    79d0:	911902a2 	add	x2, x21, #0x640
    79d4:	d350fc20 	lsr	x0, x1, #16
    79d8:	8b000800 	add	x0, x0, x0, lsl #2
    79dc:	f949fc43 	ldr	x3, [x2, #5112]
    79e0:	d37df002 	lsl	x2, x0, #3
    79e4:	8b020060 	add	x0, x3, x2
    79e8:	f9401014 	ldr	x20, [x0, #32]
    79ec:	b4000254 	cbz	x20, 7a34 <f23+0x1b4>
    79f0:	38626862 	ldrb	w2, [x3, x2]
    79f4:	7100085f 	cmp	w2, #0x2
    79f8:	54000ee0 	b.eq	7bd4 <f23+0x354>  // b.none
    79fc:	7100045f 	cmp	w2, #0x1
    7a00:	540001a1 	b.ne	7a34 <f23+0x1b4>  // b.any
    7a04:	29430002 	ldp	w2, w0, [x0, #24]
    7a08:	92403c21 	and	x1, x1, #0xffff
    7a0c:	9b027c21 	mul	x1, x1, x2
    7a10:	d360fc21 	lsr	x1, x1, #32
    7a14:	eb00003f 	cmp	x1, x0
    7a18:	540000e2 	b.cs	7a34 <f23+0x1b4>  // b.hs, b.nlast
    7a1c:	8b010294 	add	x20, x20, x1
    7a20:	39400280 	ldrb	w0, [x20]
    7a24:	7103fc1f 	cmp	w0, #0xff
    7a28:	54001180 	b.eq	7c58 <f23+0x3d8>  // b.none
    7a2c:	52800020 	mov	w0, #0x1                   	// #1
    7a30:	39000280 	strb	w0, [x20]
    7a34:	b4000253 	cbz	x19, 7a7c <f23+0x1fc>
    7a38:	8b131313 	add	x19, x24, x19, lsl #4
    7a3c:	aa1803f4 	mov	x20, x24
    7a40:	aa1603fa 	mov	x26, x22
    7a44:	aa1703f9 	mov	x25, x23
    7a48:	f9400723 	ldr	x3, [x25, #8]
    7a4c:	f9400742 	ldr	x2, [x26, #8]
    7a50:	f9400861 	ldr	x1, [x3, #16]
    7a54:	f9400840 	ldr	x0, [x2, #16]
    7a58:	fd400461 	ldr	d1, [x3, #8]
    7a5c:	fd400440 	ldr	d0, [x2, #8]
    7a60:	97fff759 	bl	57c4 <w107>
    7a64:	f9000680 	str	x0, [x20, #8]
    7a68:	f8010e81 	str	x1, [x20, #16]!
    7a6c:	f9400b39 	ldr	x25, [x25, #16]
    7a70:	f9400b5a 	ldr	x26, [x26, #16]
    7a74:	eb14027f 	cmp	x19, x20
    7a78:	54fffe81 	b.ne	7a48 <f23+0x1c8>  // b.any
    7a7c:	aa1703e0 	mov	x0, x23
    7a80:	97fffe10 	bl	72c0 <fwp_drop2>
    7a84:	aa1603e0 	mov	x0, x22
    7a88:	97fffe0e 	bl	72c0 <fwp_drop2>
    7a8c:	f9400316 	ldr	x22, [x24]
    7a90:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7a94:	b4000236 	cbz	x22, 7ad8 <f23+0x258>
    7a98:	fd003be8 	str	d8, [sp, #112]
    7a9c:	2f00e408 	movi	d8, #0x0
    7aa0:	91002319 	add	x25, x24, #0x8
    7aa4:	91004317 	add	x23, x24, #0x10
    7aa8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    7aac:	d2800013 	mov	x19, #0x0                   	// #0
    7ab0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7ab4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7ab8:	91000a73 	add	x19, x19, #0x2
    7abc:	1e602908 	fadd	d8, d8, d0
    7ac0:	97fff6f0 	bl	5680 <f128.constprop.0>
    7ac4:	aa0003f4 	mov	x20, x0
    7ac8:	eb1302df 	cmp	x22, x19
    7acc:	54ffff28 	b.hi	7ab0 <f23+0x230>  // b.pmore
    7ad0:	9e660116 	fmov	x22, d8
    7ad4:	fd403be8 	ldr	d8, [sp, #112]
    7ad8:	911902b5 	add	x21, x21, #0x640
    7adc:	aa1803e0 	mov	x0, x24
    7ae0:	97fffce8 	bl	6e80 <fwp_drop4>
    7ae4:	a900d3f6 	stp	x22, x20, [sp, #8]
    7ae8:	910023e1 	add	x1, sp, #0x8
    7aec:	52800000 	mov	w0, #0x0                   	// #0
    7af0:	97fff848 	bl	5c10 <fwp_data.part.0.constprop.0>
    7af4:	f949daa1 	ldr	x1, [x21, #5040]
    7af8:	aa0003f3 	mov	x19, x0
    7afc:	f949eea0 	ldr	x0, [x21, #5080]
    7b00:	cb010261 	sub	x1, x19, x1
    7b04:	eb00403f 	cmp	x1, x0, lsl #16
    7b08:	54000322 	b.cs	7b6c <f23+0x2ec>  // b.hs, b.nlast
    7b0c:	d350fc22 	lsr	x2, x1, #16
    7b10:	f949fea3 	ldr	x3, [x21, #5112]
    7b14:	8b020842 	add	x2, x2, x2, lsl #2
    7b18:	d37df042 	lsl	x2, x2, #3
    7b1c:	8b020060 	add	x0, x3, x2
    7b20:	f9401014 	ldr	x20, [x0, #32]
    7b24:	b4000254 	cbz	x20, 7b6c <f23+0x2ec>
    7b28:	38626862 	ldrb	w2, [x3, x2]
    7b2c:	7100085f 	cmp	w2, #0x2
    7b30:	54000580 	b.eq	7be0 <f23+0x360>  // b.none
    7b34:	7100045f 	cmp	w2, #0x1
    7b38:	540001a1 	b.ne	7b6c <f23+0x2ec>  // b.any
    7b3c:	29430002 	ldp	w2, w0, [x0, #24]
    7b40:	92403c21 	and	x1, x1, #0xffff
    7b44:	9b027c21 	mul	x1, x1, x2
    7b48:	d360fc21 	lsr	x1, x1, #32
    7b4c:	eb00003f 	cmp	x1, x0
    7b50:	540000e2 	b.cs	7b6c <f23+0x2ec>  // b.hs, b.nlast
    7b54:	8b010294 	add	x20, x20, x1
    7b58:	39400280 	ldrb	w0, [x20]
    7b5c:	7103fc1f 	cmp	w0, #0xff
    7b60:	54000820 	b.eq	7c64 <f23+0x3e4>  // b.none
    7b64:	52800020 	mov	w0, #0x1                   	// #1
    7b68:	39000280 	strb	w0, [x20]
    7b6c:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    7b70:	f947f400 	ldr	x0, [x0, #4072]
    7b74:	f9400fe2 	ldr	x2, [sp, #24]
    7b78:	f9400001 	ldr	x1, [x0]
    7b7c:	eb010042 	subs	x2, x2, x1
    7b80:	d2800001 	mov	x1, #0x0                   	// #0
    7b84:	540007a1 	b.ne	7c78 <f23+0x3f8>  // b.any
    7b88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7b8c:	aa1303e0 	mov	x0, x19
    7b90:	a94353f3 	ldp	x19, x20, [sp, #48]
    7b94:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7b98:	a94563f7 	ldp	x23, x24, [sp, #80]
    7b9c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7ba0:	910203ff 	add	sp, sp, #0x80
    7ba4:	d65f03c0 	ret
    7ba8:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    7bac:	9113c000 	add	x0, x0, #0x4f0
    7bb0:	fd003be8 	str	d8, [sp, #112]
    7bb4:	97fff1c0 	bl	42b4 <fwp_trap>
    7bb8:	72003c3f 	tst	w1, #0xffff
    7bbc:	54ffec81 	b.ne	794c <f23+0xcc>  // b.any
    7bc0:	17ffff59 	b	7924 <f23+0xa4>
    7bc4:	f940ac43 	ldr	x3, [x2, #344]
    7bc8:	91000463 	add	x3, x3, #0x1
    7bcc:	f900ac43 	str	x3, [x2, #344]
    7bd0:	17ffff5b 	b	793c <f23+0xbc>
    7bd4:	72003c3f 	tst	w1, #0xffff
    7bd8:	54fff2e1 	b.ne	7a34 <f23+0x1b4>  // b.any
    7bdc:	17ffff91 	b	7a20 <f23+0x1a0>
    7be0:	72003c3f 	tst	w1, #0xffff
    7be4:	54fffc41 	b.ne	7b6c <f23+0x2ec>  // b.any
    7be8:	17ffffdc 	b	7b58 <f23+0x2d8>
    7bec:	cb0103e1 	neg	x1, x1
    7bf0:	eb02003f 	cmp	x1, x2
    7bf4:	540001e3 	b.cc	7c30 <f23+0x3b0>  // b.lo, b.ul, b.last
    7bf8:	52800041 	mov	w1, #0x2                   	// #2
    7bfc:	d2800100 	mov	x0, #0x8                   	// #8
    7c00:	97fff524 	bl	5090 <fwp_heap_alloc>
    7c04:	aa0003f8 	mov	x24, x0
    7c08:	911902a0 	add	x0, x21, #0x640
    7c0c:	f900031f 	str	xzr, [x24]
    7c10:	f949d801 	ldr	x1, [x0, #5040]
    7c14:	f949ec00 	ldr	x0, [x0, #5080]
    7c18:	cb010301 	sub	x1, x24, x1
    7c1c:	eb00403f 	cmp	x1, x0, lsl #16
    7c20:	54000282 	b.cs	7c70 <f23+0x3f0>  // b.hs, b.nlast
    7c24:	d2800013 	mov	x19, #0x0                   	// #0
    7c28:	d2800017 	mov	x23, #0x0                   	// #0
    7c2c:	17ffff69 	b	79d0 <f23+0x150>
    7c30:	f949fc62 	ldr	x2, [x3, #5112]
    7c34:	d350fc20 	lsr	x0, x1, #16
    7c38:	8b000800 	add	x0, x0, x0, lsl #2
    7c3c:	8b000c42 	add	x2, x2, x0, lsl #3
    7c40:	f9401040 	ldr	x0, [x2, #32]
    7c44:	b4fffda0 	cbz	x0, 7bf8 <f23+0x378>
    7c48:	d2800017 	mov	x23, #0x0                   	// #0
    7c4c:	17ffff2a 	b	78f4 <f23+0x74>
    7c50:	97fff2cd 	bl	4784 <fwp_rc_wide_dup>
    7c54:	17ffff3e 	b	794c <f23+0xcc>
    7c58:	aa1403e0 	mov	x0, x20
    7c5c:	97fff1b6 	bl	4334 <fwp_rc_forget_slot.part.0>
    7c60:	17ffff73 	b	7a2c <f23+0x1ac>
    7c64:	aa1403e0 	mov	x0, x20
    7c68:	97fff1b3 	bl	4334 <fwp_rc_forget_slot.part.0>
    7c6c:	17ffffbe 	b	7b64 <f23+0x2e4>
    7c70:	d2800017 	mov	x23, #0x0                   	// #0
    7c74:	17ffff82 	b	7a7c <f23+0x1fc>
    7c78:	fd003be8 	str	d8, [sp, #112]
    7c7c:	97ffeae5 	bl	2810 <__stack_chk_fail@plt>

0000000000007c80 <fwp_owned_entry23>:
    7c80:	f9400000 	ldr	x0, [x0]
    7c84:	17fffeff 	b	7880 <f23>
    7c88:	d503201f 	nop
    7c8c:	d503201f 	nop

0000000000007c90 <e23>:
    7c90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7c94:	910003fd 	mov	x29, sp
    7c98:	f9000bf3 	str	x19, [sp, #16]
    7c9c:	f9400013 	ldr	x19, [x0]
    7ca0:	aa1303e0 	mov	x0, x19
    7ca4:	97fff83b 	bl	5d90 <fwp_rc_share>
    7ca8:	aa1303e0 	mov	x0, x19
    7cac:	97fffef5 	bl	7880 <f23>
    7cb0:	aa0003f3 	mov	x19, x0
    7cb4:	97fff837 	bl	5d90 <fwp_rc_share>
    7cb8:	aa1303e0 	mov	x0, x19
    7cbc:	f9400bf3 	ldr	x19, [sp, #16]
    7cc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7cc4:	d65f03c0 	ret
    7cc8:	d503201f 	nop
    7ccc:	d503201f 	nop

0000000000007cd0 <f12>:
    7cd0:	d104c3ff 	sub	sp, sp, #0x130
    7cd4:	90000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    7cd8:	f947f442 	ldr	x2, [x2, #4072]
    7cdc:	a90d7bfd 	stp	x29, x30, [sp, #208]
    7ce0:	910343fd 	add	x29, sp, #0xd0
    7ce4:	a90f5bf5 	stp	x21, x22, [sp, #240]
    7ce8:	d0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    7cec:	911902a3 	add	x3, x21, #0x640
    7cf0:	a90e53f3 	stp	x19, x20, [sp, #224]
    7cf4:	b0000154 	adrp	x20, 30000 <__data_start>
    7cf8:	91018284 	add	x4, x20, #0x60
    7cfc:	f949d861 	ldr	x1, [x3, #5040]
    7d00:	a91063f7 	stp	x23, x24, [sp, #256]
    7d04:	b0000158 	adrp	x24, 30000 <__data_start>
    7d08:	f949ec65 	ldr	x5, [x3, #5080]
    7d0c:	a9116bf9 	stp	x25, x26, [sp, #272]
    7d10:	91004318 	add	x24, x24, #0x10
    7d14:	a91273fb 	stp	x27, x28, [sp, #288]
    7d18:	91008318 	add	x24, x24, #0x20
    7d1c:	910143f7 	add	x23, sp, #0x50
    7d20:	f941c886 	ldr	x6, [x4, #912]
    7d24:	f9400047 	ldr	x7, [x2]
    7d28:	f90067e7 	str	x7, [sp, #200]
    7d2c:	d2800007 	mov	x7, #0x0                   	// #0
    7d30:	910123f6 	add	x22, sp, #0x48
    7d34:	f0fffff9 	adrp	x25, 6000 <fwp_rc_dup+0x9c>
    7d38:	12800007 	mov	w7, #0xffffffff            	// #-1
    7d3c:	91240322 	add	x2, x25, #0x900
    7d40:	cb010301 	sub	x1, x24, x1
    7d44:	b9004be7 	str	w7, [sp, #72]
    7d48:	a9050be6 	stp	x6, x2, [sp, #80]
    7d4c:	aa0003f3 	mov	x19, x0
    7d50:	f90033f6 	str	x22, [sp, #96]
    7d54:	f901c897 	str	x23, [x4, #912]
    7d58:	eb05403f 	cmp	x1, x5, lsl #16
    7d5c:	540003a2 	b.cs	7dd0 <f12+0x100>  // b.hs, b.nlast
    7d60:	d350fc20 	lsr	x0, x1, #16
    7d64:	f949fc64 	ldr	x4, [x3, #5112]
    7d68:	8b000800 	add	x0, x0, x0, lsl #2
    7d6c:	d37df002 	lsl	x2, x0, #3
    7d70:	8b020083 	add	x3, x4, x2
    7d74:	f9401060 	ldr	x0, [x3, #32]
    7d78:	b40002c0 	cbz	x0, 7dd0 <f12+0x100>
    7d7c:	38626882 	ldrb	w2, [x4, x2]
    7d80:	7100085f 	cmp	w2, #0x2
    7d84:	54000c00 	b.eq	7f04 <f12+0x234>  // b.none
    7d88:	7100045f 	cmp	w2, #0x1
    7d8c:	54000221 	b.ne	7dd0 <f12+0x100>  // b.any
    7d90:	29430864 	ldp	w4, w2, [x3, #24]
    7d94:	92403c21 	and	x1, x1, #0xffff
    7d98:	9b047c21 	mul	x1, x1, x4
    7d9c:	d360fc21 	lsr	x1, x1, #32
    7da0:	eb02003f 	cmp	x1, x2
    7da4:	54000162 	b.cs	7dd0 <f12+0x100>  // b.hs, b.nlast
    7da8:	8b010000 	add	x0, x0, x1
    7dac:	39400001 	ldrb	w1, [x0]
    7db0:	34000101 	cbz	w1, 7dd0 <f12+0x100>
    7db4:	91018282 	add	x2, x20, #0x60
    7db8:	b9413043 	ldr	w3, [x2, #304]
    7dbc:	350013a3 	cbnz	w3, 8030 <f12+0x360>
    7dc0:	7103f43f 	cmp	w1, #0xfd
    7dc4:	54002748 	b.hi	82ac <f12+0x5dc>  // b.pmore
    7dc8:	11000421 	add	w1, w1, #0x1
    7dcc:	39000001 	strb	w1, [x0]
    7dd0:	aa1803e0 	mov	x0, x24
    7dd4:	97fff9df 	bl	6550 <fwp_closure_drop>
    7dd8:	b40001d3 	cbz	x19, 7e10 <f12+0x140>
    7ddc:	aa1303e0 	mov	x0, x19
    7de0:	d2800001 	mov	x1, #0x0                   	// #0
    7de4:	d503201f 	nop
    7de8:	f9400800 	ldr	x0, [x0, #16]
    7dec:	91000421 	add	x1, x1, #0x1
    7df0:	b5ffffc0 	cbnz	x0, 7de8 <f12+0x118>
    7df4:	aa0103f8 	mov	x24, x1
    7df8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7dfc:	eb00003f 	cmp	x1, x0
    7e00:	540000a9 	b.ls	7e14 <f12+0x144>  // b.plast
    7e04:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    7e08:	91140000 	add	x0, x0, #0x500
    7e0c:	97fff12a 	bl	42b4 <fwp_trap>
    7e10:	d2800018 	mov	x24, #0x0                   	// #0
    7e14:	9101829a 	add	x26, x20, #0x60
    7e18:	b943c740 	ldr	w0, [x26, #964]
    7e1c:	34001340 	cbz	w0, 8084 <f12+0x3b4>
    7e20:	91018280 	add	x0, x20, #0x60
    7e24:	f940901b 	ldr	x27, [x0, #288]
    7e28:	f940b01a 	ldr	x26, [x0, #352]
    7e2c:	eb1b035f 	cmp	x26, x27
    7e30:	5400070a 	b.ge	7f10 <f12+0x240>  // b.tcont
    7e34:	f9404401 	ldr	x1, [x0, #136]
    7e38:	8b1a0740 	add	x0, x26, x26, lsl #1
    7e3c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7e40:	8b000b40 	add	x0, x26, x0, lsl #2
    7e44:	8b000c20 	add	x0, x1, x0, lsl #3
    7e48:	b9400401 	ldr	w1, [x0, #4]
    7e4c:	35000081 	cbnz	w1, 7e5c <f12+0x18c>
    7e50:	b9400001 	ldr	w1, [x0]
    7e54:	6b02003f 	cmp	w1, w2
    7e58:	540005c9 	b.ls	7f10 <f12+0x240>  // b.plast
    7e5c:	9100075a 	add	x26, x26, #0x1
    7e60:	9101a000 	add	x0, x0, #0x68
    7e64:	eb1b035f 	cmp	x26, x27
    7e68:	54ffff01 	b.ne	7e48 <f12+0x178>  // b.any
    7e6c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7e70:	eb00037f 	cmp	x27, x0
    7e74:	54001eec 	b.gt	8250 <f12+0x580>
    7e78:	91018280 	add	x0, x20, #0x60
    7e7c:	f9408801 	ldr	x1, [x0, #272]
    7e80:	f940441c 	ldr	x28, [x0, #136]
    7e84:	eb1b003f 	cmp	x1, x27
    7e88:	54000261 	b.ne	7ed4 <f12+0x204>  // b.any
    7e8c:	b40027bb 	cbz	x27, 8380 <f12+0x6b0>
    7e90:	d37ffb63 	lsl	x3, x27, #1
    7e94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7e98:	eb00007f 	cmp	x3, x0
    7e9c:	9a80d063 	csel	x3, x3, x0, le
    7ea0:	8b030461 	add	x1, x3, x3, lsl #1
    7ea4:	8b010861 	add	x1, x3, x1, lsl #2
    7ea8:	d37df021 	lsl	x1, x1, #3
    7eac:	aa1c03e0 	mov	x0, x28
    7eb0:	52800002 	mov	w2, #0x0                   	// #0
    7eb4:	f90007e3 	str	x3, [sp, #8]
    7eb8:	97fff063 	bl	4044 <ad_raw_realloc>
    7ebc:	f94007e3 	ldr	x3, [sp, #8]
    7ec0:	aa0003fc 	mov	x28, x0
    7ec4:	b4004760 	cbz	x0, 87b0 <f12+0xae0>
    7ec8:	91018280 	add	x0, x20, #0x60
    7ecc:	f900441c 	str	x28, [x0, #136]
    7ed0:	f9008803 	str	x3, [x0, #272]
    7ed4:	8b1b0760 	add	x0, x27, x27, lsl #1
    7ed8:	91018281 	add	x1, x20, #0x60
    7edc:	4f000400 	movi	v0.4s, #0x0
    7ee0:	91000762 	add	x2, x27, #0x1
    7ee4:	8b000b60 	add	x0, x27, x0, lsl #2
    7ee8:	f9009022 	str	x2, [x1, #288]
    7eec:	8b000f80 	add	x0, x28, x0, lsl #3
    7ef0:	ad000000 	stp	q0, q0, [x0]
    7ef4:	ad010000 	stp	q0, q0, [x0, #32]
    7ef8:	ad020000 	stp	q0, q0, [x0, #64]
    7efc:	f900301f 	str	xzr, [x0, #96]
    7f00:	14000008 	b	7f20 <f12+0x250>
    7f04:	72003c3f 	tst	w1, #0xffff
    7f08:	54fff641 	b.ne	7dd0 <f12+0x100>  // b.any
    7f0c:	17ffffa8 	b	7dac <f12+0xdc>
    7f10:	eb1b035f 	cmp	x26, x27
    7f14:	54fffac0 	b.eq	7e6c <f12+0x19c>  // b.none
    7f18:	91018280 	add	x0, x20, #0x60
    7f1c:	f940441c 	ldr	x28, [x0, #136]
    7f20:	8b1a075b 	add	x27, x26, x26, lsl #1
    7f24:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    7f28:	91074000 	add	x0, x0, #0x1d0
    7f2c:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7f30:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7f34:	f900337f 	str	xzr, [x27, #96]
    7f38:	97ffea9a 	bl	29a0 <getenv@plt>
    7f3c:	b4000080 	cbz	x0, 7f4c <f12+0x27c>
    7f40:	39400001 	ldrb	w1, [x0]
    7f44:	7100c03f 	cmp	w1, #0x30
    7f48:	540007c0 	b.eq	8040 <f12+0x370>  // b.none
    7f4c:	91018280 	add	x0, x20, #0x60
    7f50:	f9408401 	ldr	x1, [x0, #264]
    7f54:	b50007c1 	cbnz	x1, 804c <f12+0x37c>
    7f58:	91018282 	add	x2, x20, #0x60
    7f5c:	2f000400 	mvni	v0.2s, #0x0
    7f60:	b9400363 	ldr	w3, [x27]
    7f64:	52800020 	mov	w0, #0x1                   	// #1
    7f68:	91000744 	add	x4, x26, #0x1
    7f6c:	a900e378 	stp	x24, x24, [x27, #8]
    7f70:	0b000063 	add	w3, w3, w0
    7f74:	f941c841 	ldr	x1, [x2, #912]
    7f78:	29000363 	stp	w3, w0, [x27]
    7f7c:	f9002b7f 	str	xzr, [x27, #80]
    7f80:	f900b044 	str	x4, [x2, #352]
    7f84:	fd002f60 	str	d0, [x27, #88]
    7f88:	b4001581 	cbz	x1, 8238 <f12+0x568>
    7f8c:	91240339 	add	x25, x25, #0x900
    7f90:	14000003 	b	7f9c <f12+0x2cc>
    7f94:	f9400021 	ldr	x1, [x1]
    7f98:	b4001501 	cbz	x1, 8238 <f12+0x568>
    7f9c:	f9400422 	ldr	x2, [x1, #8]
    7fa0:	eb19005f 	cmp	x2, x25
    7fa4:	54ffff81 	b.ne	7f94 <f12+0x2c4>  // b.any
    7fa8:	f9400820 	ldr	x0, [x1, #16]
    7fac:	2a1a03e2 	mov	w2, w26
    7fb0:	b9400001 	ldr	w1, [x0]
    7fb4:	f9002b60 	str	x0, [x27, #80]
    7fb8:	b9005f61 	str	w1, [x27, #92]
    7fbc:	37f80081 	tbnz	w1, #31, 7fcc <f12+0x2fc>
    7fc0:	52800d05 	mov	w5, #0x68                  	// #104
    7fc4:	9b257021 	smaddl	x1, w1, w5, x28
    7fc8:	b900583a 	str	w26, [x1, #88]
    7fcc:	b9000002 	str	w2, [x0]
    7fd0:	aa1303e0 	mov	x0, x19
    7fd4:	d2800002 	mov	x2, #0x0                   	// #0
    7fd8:	b4000653 	cbz	x19, 80a0 <f12+0x3d0>
    7fdc:	d503201f 	nop
    7fe0:	f9400800 	ldr	x0, [x0, #16]
    7fe4:	91000442 	add	x2, x2, #0x1
    7fe8:	b5ffffc0 	cbnz	x0, 7fe0 <f12+0x310>
    7fec:	aa1303e1 	mov	x1, x19
    7ff0:	f9400821 	ldr	x1, [x1, #16]
    7ff4:	91000400 	add	x0, x0, #0x1
    7ff8:	b5ffffc1 	cbnz	x1, 7ff0 <f12+0x320>
    7ffc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8000:	eb01001f 	cmp	x0, x1
    8004:	54000108 	b.hi	8024 <f12+0x354>  // b.pmore
    8008:	f100005f 	cmp	x2, #0x0
    800c:	540004ad 	b.le	80a0 <f12+0x3d0>
    8010:	eb00005f 	cmp	x2, x0
    8014:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8018:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    801c:	eb01033f 	cmp	x25, x1
    8020:	540011e9 	b.ls	825c <f12+0x58c>  // b.plast
    8024:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8028:	9113c000 	add	x0, x0, #0x4f0
    802c:	97fff0a2 	bl	42b4 <fwp_trap>
    8030:	f940ac43 	ldr	x3, [x2, #344]
    8034:	91000463 	add	x3, x3, #0x1
    8038:	f900ac43 	str	x3, [x2, #344]
    803c:	17ffff61 	b	7dc0 <f12+0xf0>
    8040:	39400400 	ldrb	w0, [x0, #1]
    8044:	34fff8a0 	cbz	w0, 7f58 <f12+0x288>
    8048:	17ffffc1 	b	7f4c <f12+0x27c>
    804c:	ad468402 	ldp	q2, q1, [x0, #208]
    8050:	91034001 	add	x1, x0, #0xd0
    8054:	4f000400 	movi	v0.4s, #0x0
    8058:	f900841f 	str	xzr, [x0, #264]
    805c:	ad010762 	stp	q2, q1, [x27, #32]
    8060:	a94f0002 	ldp	x2, x0, [x0, #240]
    8064:	f9000f60 	str	x0, [x27, #24]
    8068:	f9401820 	ldr	x0, [x1, #48]
    806c:	f9002362 	str	x2, [x27, #64]
    8070:	f9002760 	str	x0, [x27, #72]
    8074:	ad000020 	stp	q0, q0, [x1]
    8078:	3d800820 	str	q0, [x1, #32]
    807c:	f900183f 	str	xzr, [x1, #48]
    8080:	17ffffb6 	b	7f58 <f12+0x288>
    8084:	d0ffffe0 	adrp	x0, 6000 <fwp_rc_dup+0x9c>
    8088:	911fc000 	add	x0, x0, #0x7f0
    808c:	9400178d 	bl	dec0 <atexit>
    8090:	35003900 	cbnz	w0, 87b0 <f12+0xae0>
    8094:	52800020 	mov	w0, #0x1                   	// #1
    8098:	b903c740 	str	w0, [x26, #964]
    809c:	17ffff61 	b	7e20 <f12+0x150>
    80a0:	d3707c63 	ubfiz	x3, x3, #16, #32
    80a4:	52800041 	mov	w1, #0x2                   	// #2
    80a8:	aa040078 	orr	x24, x3, x4
    80ac:	d2800100 	mov	x0, #0x8                   	// #8
    80b0:	97fff3f8 	bl	5090 <fwp_heap_alloc>
    80b4:	aa0003fa 	mov	x26, x0
    80b8:	911902a0 	add	x0, x21, #0x640
    80bc:	f900035f 	str	xzr, [x26]
    80c0:	f949d801 	ldr	x1, [x0, #5040]
    80c4:	f949ec00 	ldr	x0, [x0, #5080]
    80c8:	cb010341 	sub	x1, x26, x1
    80cc:	eb00403f 	cmp	x1, x0, lsl #16
    80d0:	54000e82 	b.cs	82a0 <f12+0x5d0>  // b.hs, b.nlast
    80d4:	d2800019 	mov	x25, #0x0                   	// #0
    80d8:	911902a2 	add	x2, x21, #0x640
    80dc:	d350fc20 	lsr	x0, x1, #16
    80e0:	8b000800 	add	x0, x0, x0, lsl #2
    80e4:	f949fc43 	ldr	x3, [x2, #5112]
    80e8:	d37df002 	lsl	x2, x0, #3
    80ec:	8b020060 	add	x0, x3, x2
    80f0:	f940101b 	ldr	x27, [x0, #32]
    80f4:	b400025b 	cbz	x27, 813c <f12+0x46c>
    80f8:	38626862 	ldrb	w2, [x3, x2]
    80fc:	7100085f 	cmp	w2, #0x2
    8100:	54000a20 	b.eq	8244 <f12+0x574>  // b.none
    8104:	7100045f 	cmp	w2, #0x1
    8108:	540001a1 	b.ne	813c <f12+0x46c>  // b.any
    810c:	29430002 	ldp	w2, w0, [x0, #24]
    8110:	92403c21 	and	x1, x1, #0xffff
    8114:	9b027c21 	mul	x1, x1, x2
    8118:	d360fc21 	lsr	x1, x1, #32
    811c:	eb00003f 	cmp	x1, x0
    8120:	540000e2 	b.cs	813c <f12+0x46c>  // b.hs, b.nlast
    8124:	8b01037b 	add	x27, x27, x1
    8128:	39400360 	ldrb	w0, [x27]
    812c:	7103fc1f 	cmp	w0, #0xff
    8130:	54003220 	b.eq	8774 <f12+0xaa4>  // b.none
    8134:	52800020 	mov	w0, #0x1                   	// #1
    8138:	39000360 	strb	w0, [x27]
    813c:	b4000239 	cbz	x25, 8180 <f12+0x4b0>
    8140:	d3607f04 	lsl	x4, x24, #32
    8144:	aa1303e0 	mov	x0, x19
    8148:	f9400665 	ldr	x5, [x19, #8]
    814c:	aa0403e3 	mov	x3, x4
    8150:	91002342 	add	x2, x26, #0x8
    8154:	d2800001 	mov	x1, #0x0                   	// #0
    8158:	14000005 	b	816c <f12+0x49c>
    815c:	f9400405 	ldr	x5, [x0, #8]
    8160:	ab040023 	adds	x3, x1, x4
    8164:	91004042 	add	x2, x2, #0x10
    8168:	54005da6 	b.vs	8d1c <f12+0x104c>
    816c:	a9000c45 	stp	x5, x3, [x2]
    8170:	91000421 	add	x1, x1, #0x1
    8174:	f9400800 	ldr	x0, [x0, #16]
    8178:	eb19003f 	cmp	x1, x25
    817c:	54ffff03 	b.cc	815c <f12+0x48c>  // b.lo, b.ul, b.last
    8180:	f9400340 	ldr	x0, [x26]
    8184:	f100041f 	cmp	x0, #0x1
    8188:	540008c9 	b.ls	82a0 <f12+0x5d0>  // b.plast
    818c:	d341fc00 	lsr	x0, x0, #1
    8190:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8194:	d100041c 	sub	x28, x0, #0x1
    8198:	eb01039f 	cmp	x28, x1
    819c:	54fff448 	b.hi	8024 <f12+0x354>  // b.pmore
    81a0:	b400081c 	cbz	x28, 82a0 <f12+0x5d0>
    81a4:	d1002341 	sub	x1, x26, #0x8
    81a8:	91002359 	add	x25, x26, #0x8
    81ac:	8b00103b 	add	x27, x1, x0, lsl #4
    81b0:	f9400720 	ldr	x0, [x25, #8]
    81b4:	f9400f21 	ldr	x1, [x25, #24]
    81b8:	fd400320 	ldr	d0, [x25]
    81bc:	fd400b21 	ldr	d1, [x25, #16]
    81c0:	97fff581 	bl	57c4 <w107>
    81c4:	a9000720 	stp	x0, x1, [x25]
    81c8:	91004339 	add	x25, x25, #0x10
    81cc:	eb1b033f 	cmp	x25, x27
    81d0:	54ffff01 	b.ne	81b0 <f12+0x4e0>  // b.any
    81d4:	aa1a03fb 	mov	x27, x26
    81d8:	d37ffb99 	lsl	x25, x28, #1
    81dc:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    81e0:	d280001c 	mov	x28, #0x0                   	// #0
    81e4:	f8010779 	str	x25, [x27], #16
    81e8:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    81ec:	aa0403e0 	mov	x0, x4
    81f0:	91000b9c 	add	x28, x28, #0x2
    81f4:	97fff523 	bl	5680 <f128.constprop.0>
    81f8:	aa0003e4 	mov	x4, x0
    81fc:	eb19039f 	cmp	x28, x25
    8200:	54ffff43 	b.cc	81e8 <f12+0x518>  // b.lo, b.ul, b.last
    8204:	aa1a03e0 	mov	x0, x26
    8208:	93407f18 	sxtw	x24, w24
    820c:	f90007e4 	str	x4, [sp, #8]
    8210:	97fffb1c 	bl	6e80 <fwp_drop4>
    8214:	aa1803e0 	mov	x0, x24
    8218:	97fff22a 	bl	4ac0 <fwp_tape_of>
    821c:	f9403019 	ldr	x25, [x0, #96]
    8220:	aa0003e5 	mov	x5, x0
    8224:	f94007e4 	ldr	x4, [sp, #8]
    8228:	b4000479 	cbz	x25, 82b4 <f12+0x5e4>
    822c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8230:	91118000 	add	x0, x0, #0x460
    8234:	97fff020 	bl	42b4 <fwp_trap>
    8238:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    823c:	91154000 	add	x0, x0, #0x550
    8240:	97fff01d 	bl	42b4 <fwp_trap>
    8244:	72003c3f 	tst	w1, #0xffff
    8248:	54fff7a1 	b.ne	813c <f12+0x46c>  // b.any
    824c:	17ffffb7 	b	8128 <f12+0x458>
    8250:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8254:	91148000 	add	x0, x0, #0x520
    8258:	97fff017 	bl	42b4 <fwp_trap>
    825c:	d37ffb3b 	lsl	x27, x25, #1
    8260:	d3707c63 	ubfiz	x3, x3, #16, #32
    8264:	91000760 	add	x0, x27, #0x1
    8268:	52800041 	mov	w1, #0x2                   	// #2
    826c:	aa040078 	orr	x24, x3, x4
    8270:	d37df000 	lsl	x0, x0, #3
    8274:	97fff387 	bl	5090 <fwp_heap_alloc>
    8278:	aa0003fa 	mov	x26, x0
    827c:	911902a1 	add	x1, x21, #0x640
    8280:	aa0103e0 	mov	x0, x1
    8284:	f900035b 	str	x27, [x26]
    8288:	f949d821 	ldr	x1, [x1, #5040]
    828c:	f949ec00 	ldr	x0, [x0, #5080]
    8290:	cb010341 	sub	x1, x26, x1
    8294:	eb00403f 	cmp	x1, x0, lsl #16
    8298:	54fff203 	b.cc	80d8 <f12+0x408>  // b.lo, b.ul, b.last
    829c:	b5fff539 	cbnz	x25, 8140 <f12+0x470>
    82a0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    82a4:	f900035f 	str	xzr, [x26]
    82a8:	17ffffd7 	b	8204 <f12+0x534>
    82ac:	97fff136 	bl	4784 <fwp_rc_wide_dup>
    82b0:	17fffec8 	b	7dd0 <f12+0x100>
    82b4:	f9000fe4 	str	x4, [sp, #24]
    82b8:	97ffeb37 	bl	2f94 <fwp_tape_unlink_scope>
    82bc:	a9428cba 	ldp	x26, x3, [x5, #40]
    82c0:	f90007e3 	str	x3, [sp, #8]
    82c4:	f9401ca3 	ldr	x3, [x5, #56]
    82c8:	b90004bf 	str	wzr, [x5, #4]
    82cc:	b94000a1 	ldr	w1, [x5]
    82d0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    82d4:	f9000be3 	str	x3, [sp, #16]
    82d8:	a940a4bc 	ldp	x28, x9, [x5, #8]
    82dc:	6b00003f 	cmp	w1, w0
    82e0:	a941e4a2 	ldp	x2, x25, [x5, #24]
    82e4:	f9400fe4 	ldr	x4, [sp, #24]
    82e8:	a94418bb 	ldp	x27, x6, [x5, #64]
    82ec:	54000108 	b.hi	830c <f12+0x63c>  // b.pmore
    82f0:	91018281 	add	x1, x20, #0x60
    82f4:	92403f00 	and	x0, x24, #0xffff
    82f8:	d1000400 	sub	x0, x0, #0x1
    82fc:	f940b023 	ldr	x3, [x1, #352]
    8300:	eb03001f 	cmp	x0, x3
    8304:	5400004a 	b.ge	830c <f12+0x63c>  // b.tcont
    8308:	f900b020 	str	x0, [x1, #352]
    830c:	4f000400 	movi	v0.4s, #0x0
    8310:	91018281 	add	x1, x20, #0x60
    8314:	90ffffe0 	adrp	x0, 4000 <fwp_tape_buffers_dispose+0xc>
    8318:	91045000 	add	x0, x0, #0x114
    831c:	f9000cbf 	str	xzr, [x5, #24]
    8320:	9101a3e7 	add	x7, sp, #0x68
    8324:	f941c823 	ldr	x3, [x1, #912]
    8328:	3c8080a0 	stur	q0, [x5, #8]
    832c:	a90683e3 	stp	x3, x0, [sp, #104]
    8330:	910203e3 	add	x3, sp, #0x80
    8334:	f94007e0 	ldr	x0, [sp, #8]
    8338:	ad0100a0 	stp	q0, q0, [x5, #32]
    833c:	f9004be0 	str	x0, [sp, #144]
    8340:	f9400be0 	ldr	x0, [sp, #16]
    8344:	f9000fe3 	str	x3, [sp, #24]
    8348:	f90013e7 	str	x7, [sp, #32]
    834c:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    8350:	f9003fe3 	str	x3, [sp, #120]
    8354:	a9086bf9 	stp	x25, x26, [sp, #128]
    8358:	f9004fe0 	str	x0, [sp, #152]
    835c:	a90a0bfb 	stp	x27, x2, [sp, #160]
    8360:	f9005be6 	str	x6, [sp, #176]
    8364:	f901c827 	str	x7, [x1, #912]
    8368:	b7f82024 	tbnz	x4, #63, 876c <f12+0xa9c>
    836c:	eb84831f 	cmp	x24, x4, asr #32
    8370:	540000e0 	b.eq	838c <f12+0x6bc>  // b.none
    8374:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8378:	91106000 	add	x0, x0, #0x418
    837c:	97ffefce 	bl	42b4 <fwp_trap>
    8380:	d2800d01 	mov	x1, #0x68                  	// #104
    8384:	d2800023 	mov	x3, #0x1                   	// #1
    8388:	17fffec9 	b	7eac <f12+0x1dc>
    838c:	92407c80 	and	x0, x4, #0xffffffff
    8390:	eb00039f 	cmp	x28, x0
    8394:	9a80c798 	csinc	x24, x28, x0, gt
    8398:	eb24413f 	cmp	x9, w4, uxtw
    839c:	54001f2d 	b.le	8780 <f12+0xab0>
    83a0:	eb1800df 	cmp	x6, x24
    83a4:	54001f6a 	b.ge	8790 <f12+0xac0>  // b.tcont
    83a8:	f10000df 	cmp	x6, #0x0
    83ac:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    83b0:	9a9810c6 	csel	x6, x6, x24, ne	// ne = any
    83b4:	14000004 	b	83c4 <f12+0x6f4>
    83b8:	eb0100df 	cmp	x6, x1
    83bc:	d37ff8c6 	lsl	x6, x6, #1
    83c0:	9a98d0c6 	csel	x6, x6, x24, le
    83c4:	eb1800df 	cmp	x6, x24
    83c8:	54ffff8b 	b.lt	83b8 <f12+0x6e8>  // b.tstop
    83cc:	b400365b 	cbz	x27, 8a94 <f12+0xdc4>
    83d0:	aa1b03e0 	mov	x0, x27
    83d4:	d37df0c1 	lsl	x1, x6, #3
    83d8:	52800062 	mov	w2, #0x3                   	// #3
    83dc:	a90293e6 	stp	x6, x4, [sp, #40]
    83e0:	97ffef19 	bl	4044 <ad_raw_realloc>
    83e4:	a94293e6 	ldp	x6, x4, [sp, #40]
    83e8:	aa0003fb 	mov	x27, x0
    83ec:	b4001d00 	cbz	x0, 878c <f12+0xabc>
    83f0:	f90053fb 	str	x27, [sp, #160]
    83f4:	f9005be6 	str	x6, [sp, #176]
    83f8:	b5001ad8 	cbnz	x24, 8750 <f12+0xa80>
    83fc:	b7f800c4 	tbnz	x4, #63, 8414 <f12+0x744>
    8400:	92407c84 	and	x4, x4, #0xffffffff
    8404:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8408:	fc647b60 	ldr	d0, [x27, x4, lsl #3]
    840c:	1e612800 	fadd	d0, d0, d1
    8410:	fc247b60 	str	d0, [x27, x4, lsl #3]
    8414:	d1000700 	sub	x0, x24, #0x1
    8418:	d1000783 	sub	x3, x28, #0x1
    841c:	eb00039f 	cmp	x28, x0
    8420:	540003ec 	b.gt	849c <f12+0x7cc>
    8424:	fc607b60 	ldr	d0, [x27, x0, lsl #3]
    8428:	1e602008 	fcmp	d0, #0.0
    842c:	54000320 	b.eq	8490 <f12+0x7c0>  // b.none
    8430:	cb1c0be1 	neg	x1, x28, lsl #2
    8434:	cb1c03e4 	neg	x4, x28
    8438:	8b010322 	add	x2, x25, x1
    843c:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    8440:	37f80122 	tbnz	w2, #31, 8464 <f12+0x794>
    8444:	f94007e5 	ldr	x5, [sp, #8]
    8448:	93407c42 	sxtw	x2, w2
    844c:	8b040ca5 	add	x5, x5, x4, lsl #3
    8450:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    8454:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    8458:	1e620802 	fmul	d2, d0, d2
    845c:	1e622821 	fadd	d1, d1, d2
    8460:	fc227b61 	str	d1, [x27, x2, lsl #3]
    8464:	8b010341 	add	x1, x26, x1
    8468:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    846c:	37f80121 	tbnz	w1, #31, 8490 <f12+0x7c0>
    8470:	f9400be2 	ldr	x2, [sp, #16]
    8474:	93407c21 	sxtw	x1, w1
    8478:	8b040c44 	add	x4, x2, x4, lsl #3
    847c:	fc617b61 	ldr	d1, [x27, x1, lsl #3]
    8480:	fc607882 	ldr	d2, [x4, x0, lsl #3]
    8484:	1e620800 	fmul	d0, d0, d2
    8488:	1e602820 	fadd	d0, d1, d0
    848c:	fc217b60 	str	d0, [x27, x1, lsl #3]
    8490:	d1000400 	sub	x0, x0, #0x1
    8494:	eb00007f 	cmp	x3, x0
    8498:	54fffc61 	b.ne	8424 <f12+0x754>  // b.any
    849c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    84a0:	eb00039f 	cmp	x28, x0
    84a4:	540019e8 	b.hi	87e0 <f12+0xb10>  // b.pmore
    84a8:	91000780 	add	x0, x28, #0x1
    84ac:	52800041 	mov	w1, #0x2                   	// #2
    84b0:	d37df000 	lsl	x0, x0, #3
    84b4:	97fff2f7 	bl	5090 <fwp_heap_alloc>
    84b8:	aa0003f8 	mov	x24, x0
    84bc:	f800841c 	str	x28, [x0], #8
    84c0:	d2800001 	mov	x1, #0x0                   	// #0
    84c4:	b40000dc 	cbz	x28, 84dc <f12+0x80c>
    84c8:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    84cc:	f8217802 	str	x2, [x0, x1, lsl #3]
    84d0:	91000421 	add	x1, x1, #0x1
    84d4:	eb01039f 	cmp	x28, x1
    84d8:	54ffff81 	b.ne	84c8 <f12+0x7f8>  // b.any
    84dc:	91018281 	add	x1, x20, #0x60
    84e0:	f94013e2 	ldr	x2, [sp, #32]
    84e4:	f941c820 	ldr	x0, [x1, #912]
    84e8:	eb02001f 	cmp	x0, x2
    84ec:	540041a1 	b.ne	8d20 <f12+0x1050>  // b.any
    84f0:	f9400fe0 	ldr	x0, [sp, #24]
    84f4:	f94037fa 	ldr	x26, [sp, #104]
    84f8:	f901c83a 	str	x26, [x1, #912]
    84fc:	97ffef06 	bl	4114 <fwp_tape_buffers_release>
    8500:	911902a2 	add	x2, x21, #0x640
    8504:	f949d841 	ldr	x1, [x2, #5040]
    8508:	f949ec40 	ldr	x0, [x2, #5080]
    850c:	cb010301 	sub	x1, x24, x1
    8510:	eb00403f 	cmp	x1, x0, lsl #16
    8514:	54000322 	b.cs	8578 <f12+0x8a8>  // b.hs, b.nlast
    8518:	d350fc20 	lsr	x0, x1, #16
    851c:	f949fc43 	ldr	x3, [x2, #5112]
    8520:	8b000800 	add	x0, x0, x0, lsl #2
    8524:	d37df002 	lsl	x2, x0, #3
    8528:	8b020060 	add	x0, x3, x2
    852c:	f9401019 	ldr	x25, [x0, #32]
    8530:	b4000259 	cbz	x25, 8578 <f12+0x8a8>
    8534:	38626862 	ldrb	w2, [x3, x2]
    8538:	7100085f 	cmp	w2, #0x2
    853c:	54002a00 	b.eq	8a7c <f12+0xdac>  // b.none
    8540:	7100045f 	cmp	w2, #0x1
    8544:	540001a1 	b.ne	8578 <f12+0x8a8>  // b.any
    8548:	29430002 	ldp	w2, w0, [x0, #24]
    854c:	92403c21 	and	x1, x1, #0xffff
    8550:	9b027c21 	mul	x1, x1, x2
    8554:	d360fc21 	lsr	x1, x1, #32
    8558:	eb00003f 	cmp	x1, x0
    855c:	540000e2 	b.cs	8578 <f12+0x8a8>  // b.hs, b.nlast
    8560:	8b010339 	add	x25, x25, x1
    8564:	39400320 	ldrb	w0, [x25]
    8568:	7103fc1f 	cmp	w0, #0xff
    856c:	54003a80 	b.eq	8cbc <f12+0xfec>  // b.none
    8570:	52800020 	mov	w0, #0x1                   	// #1
    8574:	39000320 	strb	w0, [x25]
    8578:	eb17035f 	cmp	x26, x23
    857c:	54003d21 	b.ne	8d20 <f12+0x1050>  // b.any
    8580:	f9402be1 	ldr	x1, [sp, #80]
    8584:	91018294 	add	x20, x20, #0x60
    8588:	aa1603e0 	mov	x0, x22
    858c:	f901ca81 	str	x1, [x20, #912]
    8590:	97fff8dc 	bl	6900 <fwp_tape_scope_release>
    8594:	f9400300 	ldr	x0, [x24]
    8598:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    859c:	b7f81360 	tbnz	x0, #63, 8808 <f12+0xb38>
    85a0:	911902a2 	add	x2, x21, #0x640
    85a4:	f949d840 	ldr	x0, [x2, #5040]
    85a8:	f949ec41 	ldr	x1, [x2, #5080]
    85ac:	cb000300 	sub	x0, x24, x0
    85b0:	eb01401f 	cmp	x0, x1, lsl #16
    85b4:	540012a2 	b.cs	8808 <f12+0xb38>  // b.hs, b.nlast
    85b8:	d350fc01 	lsr	x1, x0, #16
    85bc:	f949fc44 	ldr	x4, [x2, #5112]
    85c0:	8b010821 	add	x1, x1, x1, lsl #2
    85c4:	d37df021 	lsl	x1, x1, #3
    85c8:	8b010083 	add	x3, x4, x1
    85cc:	f9401062 	ldr	x2, [x3, #32]
    85d0:	b40011c2 	cbz	x2, 8808 <f12+0xb38>
    85d4:	38616881 	ldrb	w1, [x4, x1]
    85d8:	7100083f 	cmp	w1, #0x2
    85dc:	54001120 	b.eq	8800 <f12+0xb30>  // b.none
    85e0:	7100043f 	cmp	w1, #0x1
    85e4:	54001121 	b.ne	8808 <f12+0xb38>  // b.any
    85e8:	29430464 	ldp	w4, w1, [x3, #24]
    85ec:	92403c00 	and	x0, x0, #0xffff
    85f0:	9b047c00 	mul	x0, x0, x4
    85f4:	d360fc00 	lsr	x0, x0, #32
    85f8:	eb01001f 	cmp	x0, x1
    85fc:	54001062 	b.cs	8808 <f12+0xb38>  // b.hs, b.nlast
    8600:	8b000042 	add	x2, x2, x0
    8604:	39400040 	ldrb	w0, [x2]
    8608:	7100041f 	cmp	w0, #0x1
    860c:	54000fe1 	b.ne	8808 <f12+0xb38>  // b.any
    8610:	aa1803f7 	mov	x23, x24
    8614:	aa1803f6 	mov	x22, x24
    8618:	d2800000 	mov	x0, #0x0                   	// #0
    861c:	910022c2 	add	x2, x22, #0x8
    8620:	d2800001 	mov	x1, #0x0                   	// #0
    8624:	b40001f9 	cbz	x25, 8660 <f12+0x990>
    8628:	d0000023 	adrp	x3, e000 <_IO_stdin_used+0x110>
    862c:	91002304 	add	x4, x24, #0x8
    8630:	fd476061 	ldr	d1, [x3, #3776]
    8634:	f9400305 	ldr	x5, [x24]
    8638:	aa0403e3 	mov	x3, x4
    863c:	b7f80de5 	tbnz	x5, #63, 87f8 <f12+0xb28>
    8640:	f94002e5 	ldr	x5, [x23]
    8644:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    8648:	b7f80d25 	tbnz	x5, #63, 87ec <f12+0xb1c>
    864c:	1e600820 	fmul	d0, d1, d0
    8650:	91000421 	add	x1, x1, #0x1
    8654:	fc008440 	str	d0, [x2], #8
    8658:	eb01033f 	cmp	x25, x1
    865c:	54fffec1 	b.ne	8634 <f12+0x964>  // b.any
    8660:	97fffa08 	bl	6e80 <fwp_drop4>
    8664:	b4002a53 	cbz	x19, 8bac <f12+0xedc>
    8668:	aa1303e0 	mov	x0, x19
    866c:	d2800014 	mov	x20, #0x0                   	// #0
    8670:	f9400800 	ldr	x0, [x0, #16]
    8674:	91000694 	add	x20, x20, #0x1
    8678:	b5ffffc0 	cbnz	x0, 8670 <f12+0x9a0>
    867c:	f94002e0 	ldr	x0, [x23]
    8680:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8684:	b7f811c0 	tbnz	x0, #63, 88bc <f12+0xbec>
    8688:	911902a1 	add	x1, x21, #0x640
    868c:	f949d820 	ldr	x0, [x1, #5040]
    8690:	f949ec22 	ldr	x2, [x1, #5080]
    8694:	cb0002c0 	sub	x0, x22, x0
    8698:	eb02401f 	cmp	x0, x2, lsl #16
    869c:	540010e2 	b.cs	88b8 <f12+0xbe8>  // b.hs, b.nlast
    86a0:	d350fc02 	lsr	x2, x0, #16
    86a4:	d2800503 	mov	x3, #0x28                  	// #40
    86a8:	f949fc24 	ldr	x4, [x1, #5112]
    86ac:	9b037c42 	mul	x2, x2, x3
    86b0:	8b020083 	add	x3, x4, x2
    86b4:	f9401061 	ldr	x1, [x3, #32]
    86b8:	b4001001 	cbz	x1, 88b8 <f12+0xbe8>
    86bc:	38626882 	ldrb	w2, [x4, x2]
    86c0:	7100085f 	cmp	w2, #0x2
    86c4:	54000f60 	b.eq	88b0 <f12+0xbe0>  // b.none
    86c8:	7100045f 	cmp	w2, #0x1
    86cc:	54000f61 	b.ne	88b8 <f12+0xbe8>  // b.any
    86d0:	29430864 	ldp	w4, w2, [x3, #24]
    86d4:	92403c00 	and	x0, x0, #0xffff
    86d8:	9b047c00 	mul	x0, x0, x4
    86dc:	d360fc00 	lsr	x0, x0, #32
    86e0:	eb02001f 	cmp	x0, x2
    86e4:	54000ea2 	b.cs	88b8 <f12+0xbe8>  // b.hs, b.nlast
    86e8:	8b000021 	add	x1, x1, x0
    86ec:	3940003c 	ldrb	w28, [x1]
    86f0:	7100079f 	cmp	w28, #0x1
    86f4:	54000e21 	b.ne	88b8 <f12+0xbe8>  // b.any
    86f8:	910022f9 	add	x25, x23, #0x8
    86fc:	eb14031f 	cmp	x24, x20
    8700:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    8704:	b4002218 	cbz	x24, 8b44 <f12+0xe74>
    8708:	d37df304 	lsl	x4, x24, #3
    870c:	aa1303e1 	mov	x1, x19
    8710:	910022c3 	add	x3, x22, #0x8
    8714:	d2800000 	mov	x0, #0x0                   	// #0
    8718:	14000009 	b	873c <f12+0xa6c>
    871c:	fc606841 	ldr	d1, [x2, x0]
    8720:	fd400420 	ldr	d0, [x1, #8]
    8724:	1e613800 	fsub	d0, d0, d1
    8728:	fc206b20 	str	d0, [x25, x0]
    872c:	91002000 	add	x0, x0, #0x8
    8730:	f9400821 	ldr	x1, [x1, #16]
    8734:	eb00009f 	cmp	x4, x0
    8738:	54000ee0 	b.eq	8914 <f12+0xc44>  // b.none
    873c:	f94002e5 	ldr	x5, [x23]
    8740:	aa0303e2 	mov	x2, x3
    8744:	b6fffec5 	tbz	x5, #63, 871c <f12+0xa4c>
    8748:	f9400ac2 	ldr	x2, [x22, #16]
    874c:	17fffff4 	b	871c <f12+0xa4c>
    8750:	d37df302 	lsl	x2, x24, #3
    8754:	aa1b03e0 	mov	x0, x27
    8758:	52800001 	mov	w1, #0x0                   	// #0
    875c:	f90017e4 	str	x4, [sp, #40]
    8760:	97ffe820 	bl	27e0 <memset@plt>
    8764:	f94017e4 	ldr	x4, [sp, #40]
    8768:	17ffff25 	b	83fc <f12+0x72c>
    876c:	aa1c03f8 	mov	x24, x28
    8770:	17ffff0c 	b	83a0 <f12+0x6d0>
    8774:	aa1b03e0 	mov	x0, x27
    8778:	97ffeeef 	bl	4334 <fwp_rc_forget_slot.part.0>
    877c:	17fffe6e 	b	8134 <f12+0x464>
    8780:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8784:	91124000 	add	x0, x0, #0x490
    8788:	97ffeecb 	bl	42b4 <fwp_trap>
    878c:	d280001b 	mov	x27, #0x0                   	// #0
    8790:	f100031f 	cmp	x24, #0x0
    8794:	fa401b60 	ccmp	x27, #0x0, #0x0, ne	// ne = any
    8798:	54ffe301 	b.ne	83f8 <f12+0x728>  // b.any
    879c:	f9400fe0 	ldr	x0, [sp, #24]
    87a0:	91018294 	add	x20, x20, #0x60
    87a4:	f94037e1 	ldr	x1, [sp, #104]
    87a8:	f901ca81 	str	x1, [x20, #912]
    87ac:	97ffee5a 	bl	4114 <fwp_tape_buffers_release>
    87b0:	f0000123 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    87b4:	f947e863 	ldr	x3, [x3, #4048]
    87b8:	d2800262 	mov	x2, #0x13                  	// #19
    87bc:	d2800021 	mov	x1, #0x1                   	// #1
    87c0:	b0000020 	adrp	x0, d000 <f0+0x2460>
    87c4:	913be000 	add	x0, x0, #0xef8
    87c8:	f9400063 	ldr	x3, [x3]
    87cc:	97ffe851 	bl	2910 <fwrite@plt>
    87d0:	d2800000 	mov	x0, #0x0                   	// #0
    87d4:	97ffe85b 	bl	2940 <fflush@plt>
    87d8:	52800cc0 	mov	w0, #0x66                  	// #102
    87dc:	97ffe869 	bl	2980 <_Exit@plt>
    87e0:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    87e4:	91168000 	add	x0, x0, #0x5a0
    87e8:	97ffeeb3 	bl	42b4 <fwp_trap>
    87ec:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    87f0:	9116c000 	add	x0, x0, #0x5b0
    87f4:	97ffeeb0 	bl	42b4 <fwp_trap>
    87f8:	f9400b03 	ldr	x3, [x24, #16]
    87fc:	17ffff91 	b	8640 <f12+0x970>
    8800:	72003c1f 	tst	w0, #0xffff
    8804:	54fff000 	b.eq	8604 <f12+0x934>  // b.none
    8808:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    880c:	eb00033f 	cmp	x25, x0
    8810:	54fffe88 	b.hi	87e0 <f12+0xb10>  // b.pmore
    8814:	91000720 	add	x0, x25, #0x1
    8818:	52800021 	mov	w1, #0x1                   	// #1
    881c:	d37df000 	lsl	x0, x0, #3
    8820:	97fff21c 	bl	5090 <fwp_heap_alloc>
    8824:	911902a2 	add	x2, x21, #0x640
    8828:	f9000019 	str	x25, [x0]
    882c:	aa0003f7 	mov	x23, x0
    8830:	aa0003f6 	mov	x22, x0
    8834:	f949d841 	ldr	x1, [x2, #5040]
    8838:	f949ec40 	ldr	x0, [x2, #5080]
    883c:	cb0102e1 	sub	x1, x23, x1
    8840:	eb00403f 	cmp	x1, x0, lsl #16
    8844:	54000322 	b.cs	88a8 <f12+0xbd8>  // b.hs, b.nlast
    8848:	d350fc20 	lsr	x0, x1, #16
    884c:	d2800504 	mov	x4, #0x28                  	// #40
    8850:	f949fc43 	ldr	x3, [x2, #5112]
    8854:	9b047c00 	mul	x0, x0, x4
    8858:	8b000062 	add	x2, x3, x0
    885c:	f9401054 	ldr	x20, [x2, #32]
    8860:	b4000254 	cbz	x20, 88a8 <f12+0xbd8>
    8864:	38606860 	ldrb	w0, [x3, x0]
    8868:	7100081f 	cmp	w0, #0x2
    886c:	54002200 	b.eq	8cac <f12+0xfdc>  // b.none
    8870:	7100041f 	cmp	w0, #0x1
    8874:	540001a1 	b.ne	88a8 <f12+0xbd8>  // b.any
    8878:	29430043 	ldp	w3, w0, [x2, #24]
    887c:	92403c21 	and	x1, x1, #0xffff
    8880:	9b037c21 	mul	x1, x1, x3
    8884:	d360fc21 	lsr	x1, x1, #32
    8888:	eb00003f 	cmp	x1, x0
    888c:	540000e2 	b.cs	88a8 <f12+0xbd8>  // b.hs, b.nlast
    8890:	8b010294 	add	x20, x20, x1
    8894:	39400280 	ldrb	w0, [x20]
    8898:	7103fc1f 	cmp	w0, #0xff
    889c:	54002020 	b.eq	8ca0 <f12+0xfd0>  // b.none
    88a0:	52800020 	mov	w0, #0x1                   	// #1
    88a4:	39000280 	strb	w0, [x20]
    88a8:	aa1803e0 	mov	x0, x24
    88ac:	17ffff5c 	b	861c <f12+0x94c>
    88b0:	72003c1f 	tst	w0, #0xffff
    88b4:	54fff1c0 	b.eq	86ec <f12+0xa1c>  // b.none
    88b8:	b40013d3 	cbz	x19, 8b30 <f12+0xe60>
    88bc:	aa1303fa 	mov	x26, x19
    88c0:	d2800014 	mov	x20, #0x0                   	// #0
    88c4:	f9400b5a 	ldr	x26, [x26, #16]
    88c8:	aa1403e0 	mov	x0, x20
    88cc:	91000694 	add	x20, x20, #0x1
    88d0:	b5ffffba 	cbnz	x26, 88c4 <f12+0xbf4>
    88d4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    88d8:	eb01029f 	cmp	x20, x1
    88dc:	54ffba48 	b.hi	8024 <f12+0x354>  // b.pmore
    88e0:	91000800 	add	x0, x0, #0x2
    88e4:	52800041 	mov	w1, #0x2                   	// #2
    88e8:	d37df000 	lsl	x0, x0, #3
    88ec:	97fff1e9 	bl	5090 <fwp_heap_alloc>
    88f0:	aa1303e1 	mov	x1, x19
    88f4:	aa0003f9 	mov	x25, x0
    88f8:	f9400420 	ldr	x0, [x1, #8]
    88fc:	f83a7b20 	str	x0, [x25, x26, lsl #3]
    8900:	9100075a 	add	x26, x26, #0x1
    8904:	f9400821 	ldr	x1, [x1, #16]
    8908:	b5ffff81 	cbnz	x1, 88f8 <f12+0xc28>
    890c:	5280001c 	mov	w28, #0x0                   	// #0
    8910:	17ffff7b 	b	86fc <f12+0xa2c>
    8914:	b4001f93 	cbz	x19, 8d04 <f12+0x1034>
    8918:	911902a0 	add	x0, x21, #0x640
    891c:	aa1303e2 	mov	x2, x19
    8920:	d280001b 	mov	x27, #0x0                   	// #0
    8924:	f949ec04 	ldr	x4, [x0, #5080]
    8928:	f949d807 	ldr	x7, [x0, #5040]
    892c:	f949fc06 	ldr	x6, [x0, #5112]
    8930:	d370bc84 	lsl	x4, x4, #16
    8934:	14000006 	b	894c <f12+0xc7c>
    8938:	f9400842 	ldr	x2, [x2, #16]
    893c:	9100077b 	add	x27, x27, #0x1
    8940:	f100005f 	cmp	x2, #0x0
    8944:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    8948:	54000322 	b.cs	89ac <f12+0xcdc>  // b.hs, b.nlast
    894c:	cb070040 	sub	x0, x2, x7
    8950:	eb04001f 	cmp	x0, x4
    8954:	540002c2 	b.cs	89ac <f12+0xcdc>  // b.hs, b.nlast
    8958:	d350fc01 	lsr	x1, x0, #16
    895c:	8b010821 	add	x1, x1, x1, lsl #2
    8960:	d37df021 	lsl	x1, x1, #3
    8964:	8b0100c5 	add	x5, x6, x1
    8968:	f94010a3 	ldr	x3, [x5, #32]
    896c:	b4000203 	cbz	x3, 89ac <f12+0xcdc>
    8970:	386168c1 	ldrb	w1, [x6, x1]
    8974:	7100083f 	cmp	w1, #0x2
    8978:	54000880 	b.eq	8a88 <f12+0xdb8>  // b.none
    897c:	7100043f 	cmp	w1, #0x1
    8980:	54000161 	b.ne	89ac <f12+0xcdc>  // b.any
    8984:	294304a8 	ldp	w8, w1, [x5, #24]
    8988:	92403c00 	and	x0, x0, #0xffff
    898c:	9b087c00 	mul	x0, x0, x8
    8990:	d360fc00 	lsr	x0, x0, #32
    8994:	eb01001f 	cmp	x0, x1
    8998:	540000a2 	b.cs	89ac <f12+0xcdc>  // b.hs, b.nlast
    899c:	8b000063 	add	x3, x3, x0
    89a0:	39400060 	ldrb	w0, [x3]
    89a4:	7100041f 	cmp	w0, #0x1
    89a8:	54fffc80 	b.eq	8938 <f12+0xc68>  // b.none
    89ac:	d280001a 	mov	x26, #0x0                   	// #0
    89b0:	eb1b031f 	cmp	x24, x27
    89b4:	540018e9 	b.ls	8cd0 <f12+0x1000>  // b.plast
    89b8:	d1002320 	sub	x0, x25, #0x8
    89bc:	aa1803f4 	mov	x20, x24
    89c0:	911902b7 	add	x23, x21, #0x640
    89c4:	d280001a 	mov	x26, #0x0                   	// #0
    89c8:	f9000be0 	str	x0, [sp, #16]
    89cc:	9102e3e0 	add	x0, sp, #0xb8
    89d0:	f90007e0 	str	x0, [sp, #8]
    89d4:	14000012 	b	8a1c <f12+0xd4c>
    89d8:	7100045f 	cmp	w2, #0x1
    89dc:	540001a1 	b.ne	8a10 <f12+0xd40>  // b.any
    89e0:	294308a6 	ldp	w6, w2, [x5, #24]
    89e4:	92403c21 	and	x1, x1, #0xffff
    89e8:	9b067c21 	mul	x1, x1, x6
    89ec:	d360fc21 	lsr	x1, x1, #32
    89f0:	eb02003f 	cmp	x1, x2
    89f4:	540000e2 	b.cs	8a10 <f12+0xd40>  // b.hs, b.nlast
    89f8:	8b010000 	add	x0, x0, x1
    89fc:	39400001 	ldrb	w1, [x0]
    8a00:	7103fc3f 	cmp	w1, #0xff
    8a04:	54001840 	b.eq	8d0c <f12+0x103c>  // b.none
    8a08:	52800021 	mov	w1, #0x1                   	// #1
    8a0c:	39000001 	strb	w1, [x0]
    8a10:	d1000694 	sub	x20, x20, #0x1
    8a14:	eb14037f 	cmp	x27, x20
    8a18:	54000d42 	b.cs	8bc0 <f12+0xef0>  // b.hs, b.nlast
    8a1c:	a94083e1 	ldp	x1, x0, [sp, #8]
    8a20:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    8a24:	52800020 	mov	w0, #0x1                   	// #1
    8a28:	a90bebe2 	stp	x2, x26, [sp, #184]
    8a2c:	97fff479 	bl	5c10 <fwp_data.part.0.constprop.0>
    8a30:	aa0003fa 	mov	x26, x0
    8a34:	f949dae1 	ldr	x1, [x23, #5040]
    8a38:	f949eee0 	ldr	x0, [x23, #5080]
    8a3c:	cb010341 	sub	x1, x26, x1
    8a40:	eb00403f 	cmp	x1, x0, lsl #16
    8a44:	54fffe62 	b.cs	8a10 <f12+0xd40>  // b.hs, b.nlast
    8a48:	d350fc20 	lsr	x0, x1, #16
    8a4c:	f949fee6 	ldr	x6, [x23, #5112]
    8a50:	8b000800 	add	x0, x0, x0, lsl #2
    8a54:	d37df002 	lsl	x2, x0, #3
    8a58:	8b0200c5 	add	x5, x6, x2
    8a5c:	f94010a0 	ldr	x0, [x5, #32]
    8a60:	b4fffd80 	cbz	x0, 8a10 <f12+0xd40>
    8a64:	386268c2 	ldrb	w2, [x6, x2]
    8a68:	7100085f 	cmp	w2, #0x2
    8a6c:	54fffb61 	b.ne	89d8 <f12+0xd08>  // b.any
    8a70:	72003c3f 	tst	w1, #0xffff
    8a74:	54fffce1 	b.ne	8a10 <f12+0xd40>  // b.any
    8a78:	17ffffe1 	b	89fc <f12+0xd2c>
    8a7c:	72003c3f 	tst	w1, #0xffff
    8a80:	54ffd7c1 	b.ne	8578 <f12+0x8a8>  // b.any
    8a84:	17fffeb8 	b	8564 <f12+0x894>
    8a88:	72003c1f 	tst	w0, #0xffff
    8a8c:	54fff901 	b.ne	89ac <f12+0xcdc>  // b.any
    8a90:	17ffffc4 	b	89a0 <f12+0xcd0>
    8a94:	d10004c1 	sub	x1, x6, #0x1
    8a98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8a9c:	eb00003f 	cmp	x1, x0
    8aa0:	540003c8 	b.hi	8b18 <f12+0xe48>  // b.pmore
    8aa4:	90000340 	adrp	x0, 70000 <ad_raw_checkpoints+0x2fba0>
    8aa8:	d2800003 	mov	x3, #0x0                   	// #0
    8aac:	91118001 	add	x1, x0, #0x460
    8ab0:	14000005 	b	8ac4 <f12+0xdf4>
    8ab4:	91000463 	add	x3, x3, #0x1
    8ab8:	91006021 	add	x1, x1, #0x18
    8abc:	f140047f 	cmp	x3, #0x1, lsl #12
    8ac0:	54000320 	b.eq	8b24 <f12+0xe54>  // b.none
    8ac4:	f9400022 	ldr	x2, [x1]
    8ac8:	b5ffff62 	cbnz	x2, 8ab4 <f12+0xde4>
    8acc:	91118002 	add	x2, x0, #0x460
    8ad0:	d2800307 	mov	x7, #0x18                  	// #24
    8ad4:	aa0603e0 	mov	x0, x6
    8ad8:	d2800101 	mov	x1, #0x8                   	// #8
    8adc:	f9001fe4 	str	x4, [sp, #56]
    8ae0:	9b070862 	madd	x2, x3, x7, x2
    8ae4:	a9029be2 	stp	x2, x6, [sp, #40]
    8ae8:	97ffe742 	bl	27f0 <calloc@plt>
    8aec:	aa0003fb 	mov	x27, x0
    8af0:	a94313e6 	ldp	x6, x4, [sp, #48]
    8af4:	b4ffe4c0 	cbz	x0, 878c <f12+0xabc>
    8af8:	aa0003e1 	mov	x1, x0
    8afc:	d37df0c2 	lsl	x2, x6, #3
    8b00:	f94017e0 	ldr	x0, [sp, #40]
    8b04:	52800063 	mov	w3, #0x3                   	// #3
    8b08:	a90293e6 	stp	x6, x4, [sp, #40]
    8b0c:	97ffe901 	bl	2f10 <ad_raw_record>
    8b10:	a94293e6 	ldp	x6, x4, [sp, #40]
    8b14:	17fffe37 	b	83f0 <f12+0x720>
    8b18:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8b1c:	91160000 	add	x0, x0, #0x580
    8b20:	97ffe9f8 	bl	3300 <ad_raw_fail>
    8b24:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8b28:	9105e000 	add	x0, x0, #0x178
    8b2c:	97ffe9f5 	bl	3300 <ad_raw_fail>
    8b30:	52800041 	mov	w1, #0x2                   	// #2
    8b34:	d2800100 	mov	x0, #0x8                   	// #8
    8b38:	97fff156 	bl	5090 <fwp_heap_alloc>
    8b3c:	aa0003f9 	mov	x25, x0
    8b40:	5280001c 	mov	w28, #0x0                   	// #0
    8b44:	d280001a 	mov	x26, #0x0                   	// #0
    8b48:	7100039f 	cmp	w28, #0x0
    8b4c:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8b50:	aa1903e0 	mov	x0, x25
    8b54:	97ffee93 	bl	45a0 <fwp_mem_free>
    8b58:	aa1603e0 	mov	x0, x22
    8b5c:	97fff8c9 	bl	6e80 <fwp_drop4>
    8b60:	aa1303e0 	mov	x0, x19
    8b64:	97fff5bb 	bl	6250 <fwp_drop0>
    8b68:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    8b6c:	f947f400 	ldr	x0, [x0, #4072]
    8b70:	f94067e2 	ldr	x2, [sp, #200]
    8b74:	f9400001 	ldr	x1, [x0]
    8b78:	eb010042 	subs	x2, x2, x1
    8b7c:	d2800001 	mov	x1, #0x0                   	// #0
    8b80:	54000141 	b.ne	8ba8 <f12+0xed8>  // b.any
    8b84:	a94d7bfd 	ldp	x29, x30, [sp, #208]
    8b88:	aa1a03e0 	mov	x0, x26
    8b8c:	a94e53f3 	ldp	x19, x20, [sp, #224]
    8b90:	a94f5bf5 	ldp	x21, x22, [sp, #240]
    8b94:	a95063f7 	ldp	x23, x24, [sp, #256]
    8b98:	a9516bf9 	ldp	x25, x26, [sp, #272]
    8b9c:	a95273fb 	ldp	x27, x28, [sp, #288]
    8ba0:	9104c3ff 	add	sp, sp, #0x130
    8ba4:	d65f03c0 	ret
    8ba8:	97ffe71a 	bl	2810 <__stack_chk_fail@plt>
    8bac:	f94002f8 	ldr	x24, [x23]
    8bb0:	b7fffc18 	tbnz	x24, #63, 8b30 <f12+0xe60>
    8bb4:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    8bb8:	d2800014 	mov	x20, #0x0                   	// #0
    8bbc:	17fffeb3 	b	8688 <f12+0x9b8>
    8bc0:	d1000701 	sub	x1, x24, #0x1
    8bc4:	cb180360 	sub	x0, x27, x24
    8bc8:	eb01037f 	cmp	x27, x1
    8bcc:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8bd0:	8b010000 	add	x0, x0, x1
    8bd4:	b50007fb 	cbnz	x27, 8cd0 <f12+0x1000>
    8bd8:	7100039f 	cmp	w28, #0x0
    8bdc:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8be0:	b4fffb80 	cbz	x0, 8b50 <f12+0xe80>
    8be4:	d1000414 	sub	x20, x0, #0x1
    8be8:	911902b5 	add	x21, x21, #0x640
    8bec:	52800038 	mov	w24, #0x1                   	// #1
    8bf0:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    8bf4:	52800020 	mov	w0, #0x1                   	// #1
    8bf8:	f94007e1 	ldr	x1, [sp, #8]
    8bfc:	a90bebe2 	stp	x2, x26, [sp, #184]
    8c00:	97fff404 	bl	5c10 <fwp_data.part.0.constprop.0>
    8c04:	aa0003fa 	mov	x26, x0
    8c08:	f949daa1 	ldr	x1, [x21, #5040]
    8c0c:	f949eea0 	ldr	x0, [x21, #5080]
    8c10:	cb010341 	sub	x1, x26, x1
    8c14:	eb00403f 	cmp	x1, x0, lsl #16
    8c18:	54000302 	b.cs	8c78 <f12+0xfa8>  // b.hs, b.nlast
    8c1c:	d350fc20 	lsr	x0, x1, #16
    8c20:	f949fea3 	ldr	x3, [x21, #5112]
    8c24:	8b000800 	add	x0, x0, x0, lsl #2
    8c28:	d37df002 	lsl	x2, x0, #3
    8c2c:	8b020060 	add	x0, x3, x2
    8c30:	f940101b 	ldr	x27, [x0, #32]
    8c34:	b400023b 	cbz	x27, 8c78 <f12+0xfa8>
    8c38:	38626862 	ldrb	w2, [x3, x2]
    8c3c:	7100085f 	cmp	w2, #0x2
    8c40:	54000240 	b.eq	8c88 <f12+0xfb8>  // b.none
    8c44:	7100045f 	cmp	w2, #0x1
    8c48:	54000181 	b.ne	8c78 <f12+0xfa8>  // b.any
    8c4c:	29430002 	ldp	w2, w0, [x0, #24]
    8c50:	92403c21 	and	x1, x1, #0xffff
    8c54:	9b027c21 	mul	x1, x1, x2
    8c58:	d360fc21 	lsr	x1, x1, #32
    8c5c:	eb00003f 	cmp	x1, x0
    8c60:	540000c2 	b.cs	8c78 <f12+0xfa8>  // b.hs, b.nlast
    8c64:	8b01037b 	add	x27, x27, x1
    8c68:	39400360 	ldrb	w0, [x27]
    8c6c:	7103fc1f 	cmp	w0, #0xff
    8c70:	54000120 	b.eq	8c94 <f12+0xfc4>  // b.none
    8c74:	39000378 	strb	w24, [x27]
    8c78:	d1000694 	sub	x20, x20, #0x1
    8c7c:	b100069f 	cmn	x20, #0x1
    8c80:	54fffb81 	b.ne	8bf0 <f12+0xf20>  // b.any
    8c84:	17ffffb3 	b	8b50 <f12+0xe80>
    8c88:	72003c3f 	tst	w1, #0xffff
    8c8c:	54ffff61 	b.ne	8c78 <f12+0xfa8>  // b.any
    8c90:	17fffff6 	b	8c68 <f12+0xf98>
    8c94:	aa1b03e0 	mov	x0, x27
    8c98:	97ffeda7 	bl	4334 <fwp_rc_forget_slot.part.0>
    8c9c:	17fffff6 	b	8c74 <f12+0xfa4>
    8ca0:	aa1403e0 	mov	x0, x20
    8ca4:	97ffeda4 	bl	4334 <fwp_rc_forget_slot.part.0>
    8ca8:	17fffefe 	b	88a0 <f12+0xbd0>
    8cac:	72003c3f 	tst	w1, #0xffff
    8cb0:	54ffdf20 	b.eq	8894 <f12+0xbc4>  // b.none
    8cb4:	aa1803e0 	mov	x0, x24
    8cb8:	17fffe59 	b	861c <f12+0x94c>
    8cbc:	aa1903e0 	mov	x0, x25
    8cc0:	97ffed9d 	bl	4334 <fwp_rc_forget_slot.part.0>
    8cc4:	91018280 	add	x0, x20, #0x60
    8cc8:	f941c81a 	ldr	x26, [x0, #912]
    8ccc:	17fffe29 	b	8570 <f12+0x8a0>
    8cd0:	aa1303e0 	mov	x0, x19
    8cd4:	d2800001 	mov	x1, #0x0                   	// #0
    8cd8:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    8cdc:	91000421 	add	x1, x1, #0x1
    8ce0:	f9000402 	str	x2, [x0, #8]
    8ce4:	aa0003e2 	mov	x2, x0
    8ce8:	f9400800 	ldr	x0, [x0, #16]
    8cec:	eb1b003f 	cmp	x1, x27
    8cf0:	54ffff43 	b.cc	8cd8 <f12+0x1008>  // b.lo, b.ul, b.last
    8cf4:	f900085a 	str	x26, [x2, #16]
    8cf8:	aa1303fa 	mov	x26, x19
    8cfc:	aa0003f3 	mov	x19, x0
    8d00:	17ffff92 	b	8b48 <f12+0xe78>
    8d04:	d280001b 	mov	x27, #0x0                   	// #0
    8d08:	17ffff2c 	b	89b8 <f12+0xce8>
    8d0c:	f9000fe0 	str	x0, [sp, #24]
    8d10:	97ffed89 	bl	4334 <fwp_rc_forget_slot.part.0>
    8d14:	f9400fe0 	ldr	x0, [sp, #24]
    8d18:	17ffff3c 	b	8a08 <f12+0xd38>
    8d1c:	97ffe739 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8d20:	97ffe6d0 	bl	2860 <abort@plt>

0000000000008d24 <fwp_owned_entry12>:
    8d24:	f9400000 	ldr	x0, [x0]
    8d28:	17fffbea 	b	7cd0 <f12>
    8d2c:	d503201f 	nop

0000000000008d30 <e12>:
    8d30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8d34:	910003fd 	mov	x29, sp
    8d38:	f9000bf3 	str	x19, [sp, #16]
    8d3c:	f9400013 	ldr	x19, [x0]
    8d40:	aa1303e0 	mov	x0, x19
    8d44:	97fff413 	bl	5d90 <fwp_rc_share>
    8d48:	aa1303e0 	mov	x0, x19
    8d4c:	97fffbe1 	bl	7cd0 <f12>
    8d50:	aa0003f3 	mov	x19, x0
    8d54:	97fff40f 	bl	5d90 <fwp_rc_share>
    8d58:	aa1303e0 	mov	x0, x19
    8d5c:	f9400bf3 	ldr	x19, [sp, #16]
    8d60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8d64:	d65f03c0 	ret
    8d68:	d503201f 	nop
    8d6c:	d503201f 	nop

0000000000008d70 <fwp_write>:
    8d70:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8d74:	910003fd 	mov	x29, sp
    8d78:	f0000124 	adrp	x4, 2f000 <fwp_fn_table+0xb30>
    8d7c:	f947f484 	ldr	x4, [x4, #4072]
    8d80:	a90153f3 	stp	x19, x20, [sp, #16]
    8d84:	d10943ff 	sub	sp, sp, #0x250
    8d88:	b9400045 	ldr	w5, [x2]
    8d8c:	aa0003f4 	mov	x20, x0
    8d90:	f9400080 	ldr	x0, [x4]
    8d94:	f90127e0 	str	x0, [sp, #584]
    8d98:	d2800000 	mov	x0, #0x0                   	// #0
    8d9c:	710064bf 	cmp	w5, #0x19
    8da0:	54000408 	b.hi	8e20 <fwp_write+0xb0>  // b.pmore
    8da4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8da8:	aa0103f3 	mov	x19, x1
    8dac:	91388000 	add	x0, x0, #0xe20
    8db0:	f9013bf5 	str	x21, [sp, #624]
    8db4:	f9013ff6 	str	x22, [sp, #632]
    8db8:	f90153fb 	str	x27, [sp, #672]
    8dbc:	f90157fc 	str	x28, [sp, #680]
    8dc0:	aa0203fc 	mov	x28, x2
    8dc4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8dc8:	10000061 	adr	x1, 8dd4 <fwp_write+0x64>
    8dcc:	8b20a820 	add	x0, x1, w0, sxth #2
    8dd0:	d61f0000 	br	x0
    8dd4:	910123e0 	add	x0, sp, #0x48
    8dd8:	aa1303e5 	mov	x5, x19
    8ddc:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x110>
    8de0:	aa0003f3 	mov	x19, x0
    8de4:	91184084 	add	x4, x4, #0x610
    8de8:	d2804003 	mov	x3, #0x200                 	// #512
    8dec:	aa0303e1 	mov	x1, x3
    8df0:	52800042 	mov	w2, #0x2                   	// #2
    8df4:	97ffe663 	bl	2780 <__snprintf_chk@plt>
    8df8:	aa1303e0 	mov	x0, x19
    8dfc:	97ffe629 	bl	26a0 <strlen@plt>
    8e00:	aa1303e1 	mov	x1, x19
    8e04:	aa0003e2 	mov	x2, x0
    8e08:	aa1403e0 	mov	x0, x20
    8e0c:	97ffea01 	bl	3610 <buf_put>
    8e10:	f9413bf5 	ldr	x21, [sp, #624]
    8e14:	f9413ff6 	ldr	x22, [sp, #632]
    8e18:	f94153fb 	ldr	x27, [sp, #672]
    8e1c:	f94157fc 	ldr	x28, [sp, #680]
    8e20:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    8e24:	f947f400 	ldr	x0, [x0, #4072]
    8e28:	f94127e2 	ldr	x2, [sp, #584]
    8e2c:	f9400001 	ldr	x1, [x0]
    8e30:	eb010042 	subs	x2, x2, x1
    8e34:	d2800001 	mov	x1, #0x0                   	// #0
    8e38:	540077c1 	b.ne	9d30 <fwp_write+0xfc0>  // b.any
    8e3c:	910943ff 	add	sp, sp, #0x250
    8e40:	a94153f3 	ldp	x19, x20, [sp, #16]
    8e44:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8e48:	d65f03c0 	ret
    8e4c:	910123e0 	add	x0, sp, #0x48
    8e50:	aa1303e5 	mov	x5, x19
    8e54:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x110>
    8e58:	aa0003f3 	mov	x19, x0
    8e5c:	91182084 	add	x4, x4, #0x608
    8e60:	d2804003 	mov	x3, #0x200                 	// #512
    8e64:	17ffffe2 	b	8dec <fwp_write+0x7c>
    8e68:	71004cbf 	cmp	w5, #0x13
    8e6c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    8e70:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    8e74:	9117e000 	add	x0, x0, #0x5f8
    8e78:	91180021 	add	x1, x1, #0x600
    8e7c:	d2800082 	mov	x2, #0x4                   	// #4
    8e80:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8e84:	aa1403e0 	mov	x0, x20
    8e88:	f90143f7 	str	x23, [sp, #640]
    8e8c:	d2800016 	mov	x22, #0x0                   	// #0
    8e90:	f90147f8 	str	x24, [sp, #648]
    8e94:	97ffe9df 	bl	3610 <buf_put>
    8e98:	f9400260 	ldr	x0, [x19]
    8e9c:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x110>
    8ea0:	d2800015 	mov	x21, #0x0                   	// #0
    8ea4:	911a02f7 	add	x23, x23, #0x680
    8ea8:	b40047a0 	cbz	x0, 979c <fwp_write+0xa2c>
    8eac:	b9400380 	ldr	w0, [x28]
    8eb0:	52800003 	mov	w3, #0x0                   	// #0
    8eb4:	f9401f82 	ldr	x2, [x28, #56]
    8eb8:	71004c1f 	cmp	w0, #0x13
    8ebc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8ec0:	aa1403e0 	mov	x0, x20
    8ec4:	8b010e61 	add	x1, x19, x1, lsl #3
    8ec8:	f9400421 	ldr	x1, [x1, #8]
    8ecc:	97ffffa9 	bl	8d70 <fwp_write>
    8ed0:	b9400380 	ldr	w0, [x28]
    8ed4:	7100481f 	cmp	w0, #0x12
    8ed8:	54004b40 	b.eq	9840 <fwp_write+0xad0>  // b.none
    8edc:	f9400260 	ldr	x0, [x19]
    8ee0:	910006b5 	add	x21, x21, #0x1
    8ee4:	91000ad6 	add	x22, x22, #0x2
    8ee8:	eb15001f 	cmp	x0, x21
    8eec:	54004589 	b.ls	979c <fwp_write+0xa2c>  // b.plast
    8ef0:	aa1703e1 	mov	x1, x23
    8ef4:	aa1403e0 	mov	x0, x20
    8ef8:	d2800042 	mov	x2, #0x2                   	// #2
    8efc:	97ffe9c5 	bl	3610 <buf_put>
    8f00:	17ffffeb 	b	8eac <fwp_write+0x13c>
    8f04:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    8f08:	9118e021 	add	x1, x1, #0x638
    8f0c:	d28000c2 	mov	x2, #0x6                   	// #6
    8f10:	aa1403e0 	mov	x0, x20
    8f14:	91004273 	add	x19, x19, #0x10
    8f18:	97ffe9be 	bl	3610 <buf_put>
    8f1c:	aa1303e0 	mov	x0, x19
    8f20:	97ffe5e0 	bl	26a0 <strlen@plt>
    8f24:	aa1303e1 	mov	x1, x19
    8f28:	aa0003e2 	mov	x2, x0
    8f2c:	aa1403e0 	mov	x0, x20
    8f30:	97ffe9b8 	bl	3610 <buf_put>
    8f34:	528007c3 	mov	w3, #0x3e                  	// #62
    8f38:	aa1403e0 	mov	x0, x20
    8f3c:	91001fe1 	add	x1, sp, #0x7
    8f40:	d2800022 	mov	x2, #0x1                   	// #1
    8f44:	39001fe3 	strb	w3, [sp, #7]
    8f48:	17ffffb1 	b	8e0c <fwp_write+0x9c>
    8f4c:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    8f50:	f947f400 	ldr	x0, [x0, #4072]
    8f54:	f94127e2 	ldr	x2, [sp, #584]
    8f58:	f9400001 	ldr	x1, [x0]
    8f5c:	eb010042 	subs	x2, x2, x1
    8f60:	d2800001 	mov	x1, #0x0                   	// #0
    8f64:	540034e1 	b.ne	9600 <fwp_write+0x890>  // b.any
    8f68:	f9413bf5 	ldr	x21, [sp, #624]
    8f6c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    8f70:	f9413ff6 	ldr	x22, [sp, #632]
    8f74:	aa1403e0 	mov	x0, x20
    8f78:	91186021 	add	x1, x1, #0x618
    8f7c:	d2800142 	mov	x2, #0xa                   	// #10
    8f80:	f94153fb 	ldr	x27, [sp, #672]
    8f84:	f94157fc 	ldr	x28, [sp, #680]
    8f88:	910943ff 	add	sp, sp, #0x250
    8f8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8f90:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8f94:	17ffe99f 	b	3610 <buf_put>
    8f98:	f9400456 	ldr	x22, [x2, #8]
    8f9c:	f90143f7 	str	x23, [sp, #640]
    8fa0:	f90147f8 	str	x24, [sp, #648]
    8fa4:	b4005b16 	cbz	x22, 9b04 <fwp_write+0xd94>
    8fa8:	aa1603e0 	mov	x0, x22
    8fac:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    8fb0:	911a6021 	add	x1, x1, #0x698
    8fb4:	97ffe637 	bl	2890 <strcmp@plt>
    8fb8:	2a0003f5 	mov	w21, w0
    8fbc:	34005fe0 	cbz	w0, 9bb8 <fwp_write+0xe48>
    8fc0:	aa1603e0 	mov	x0, x22
    8fc4:	97ffe5b7 	bl	26a0 <strlen@plt>
    8fc8:	aa1603e1 	mov	x1, x22
    8fcc:	aa0003e2 	mov	x2, x0
    8fd0:	aa1403e0 	mov	x0, x20
    8fd4:	97ffe98f 	bl	3610 <buf_put>
    8fd8:	52800403 	mov	w3, #0x20                  	// #32
    8fdc:	91001ff5 	add	x21, sp, #0x7
    8fe0:	aa1503e1 	mov	x1, x21
    8fe4:	aa1403e0 	mov	x0, x20
    8fe8:	d2800022 	mov	x2, #0x1                   	// #1
    8fec:	39001fe3 	strb	w3, [sp, #7]
    8ff0:	97ffe988 	bl	3610 <buf_put>
    8ff4:	52800f63 	mov	w3, #0x7b                  	// #123
    8ff8:	aa1403e0 	mov	x0, x20
    8ffc:	aa1503e1 	mov	x1, x21
    9000:	d2800022 	mov	x2, #0x1                   	// #1
    9004:	39001fe3 	strb	w3, [sp, #7]
    9008:	97ffe982 	bl	3610 <buf_put>
    900c:	b9401380 	ldr	w0, [x28, #16]
    9010:	52800018 	mov	w24, #0x0                   	// #0
    9014:	7100001f 	cmp	w0, #0x0
    9018:	54003aad 	b.le	976c <fwp_write+0x9fc>
    901c:	f9014bf9 	str	x25, [sp, #656]
    9020:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x110>
    9024:	911b0339 	add	x25, x25, #0x6c0
    9028:	f9014ffa 	str	x26, [sp, #664]
    902c:	b000003a 	adrp	x26, e000 <_IO_stdin_used+0x110>
    9030:	911a035a 	add	x26, x26, #0x680
    9034:	91002276 	add	x22, x19, #0x8
    9038:	d2800013 	mov	x19, #0x0                   	// #0
    903c:	b5003e93 	cbnz	x19, 980c <fwp_write+0xa9c>
    9040:	d37df277 	lsl	x23, x19, #3
    9044:	34003cb8 	cbz	w24, 97d8 <fwp_write+0xa68>
    9048:	f9401382 	ldr	x2, [x28, #32]
    904c:	aa1403e0 	mov	x0, x20
    9050:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    9054:	52800003 	mov	w3, #0x0                   	// #0
    9058:	f8776842 	ldr	x2, [x2, x23]
    905c:	91000673 	add	x19, x19, #0x1
    9060:	97ffff44 	bl	8d70 <fwp_write>
    9064:	b9401380 	ldr	w0, [x28, #16]
    9068:	6b13001f 	cmp	w0, w19
    906c:	54fffe8c 	b.gt	903c <fwp_write+0x2cc>
    9070:	f9414bf9 	ldr	x25, [sp, #656]
    9074:	f9414ffa 	ldr	x26, [sp, #664]
    9078:	340037b8 	cbz	w24, 976c <fwp_write+0x9fc>
    907c:	52800523 	mov	w3, #0x29                  	// #41
    9080:	aa1503e1 	mov	x1, x21
    9084:	aa1403e0 	mov	x0, x20
    9088:	d2800022 	mov	x2, #0x1                   	// #1
    908c:	39001fe3 	strb	w3, [sp, #7]
    9090:	97ffe960 	bl	3610 <buf_put>
    9094:	f9413bf5 	ldr	x21, [sp, #624]
    9098:	f9413ff6 	ldr	x22, [sp, #632]
    909c:	f94143f7 	ldr	x23, [sp, #640]
    90a0:	f94147f8 	ldr	x24, [sp, #648]
    90a4:	f94153fb 	ldr	x27, [sp, #672]
    90a8:	f94157fc 	ldr	x28, [sp, #680]
    90ac:	17ffff5d 	b	8e20 <fwp_write+0xb0>
    90b0:	b9404855 	ldr	w21, [x2, #72]
    90b4:	aa1403e0 	mov	x0, x20
    90b8:	93407eb6 	sxtw	x22, w21
    90bc:	91000ac1 	add	x1, x22, #0x2
    90c0:	97ffe920 	bl	3540 <buf_grow>
    90c4:	a9400281 	ldp	x1, x0, [x20]
    90c8:	528e8603 	mov	w3, #0x7430                	// #29744
    90cc:	78206823 	strh	w3, [x1, x0]
    90d0:	8b000022 	add	x2, x1, x0
    90d4:	710002bf 	cmp	w21, #0x0
    90d8:	540036cd 	b.le	97b0 <fwp_write+0xa40>
    90dc:	110006a3 	add	w3, w21, #0x1
    90e0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    90e4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    90e8:	91000449 	add	x9, x2, #0x1
    90ec:	8b23c043 	add	x3, x2, w3, sxtw
    90f0:	f28aaac6 	movk	x6, #0x5556
    90f4:	f2955568 	movk	x8, #0xaaab
    90f8:	1400000d 	b	912c <fwp_write+0x3bc>
    90fc:	d2800021 	mov	x1, #0x1                   	// #1
    9100:	528005a5 	mov	w5, #0x2d                  	// #45
    9104:	f100001f 	cmp	x0, #0x0
    9108:	9b467e60 	smulh	x0, x19, x6
    910c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    9110:	381ff465 	strb	w5, [x3], #-1
    9114:	cb040000 	sub	x0, x0, x4
    9118:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    911c:	cb020000 	sub	x0, x0, x2
    9120:	8b010013 	add	x19, x0, x1
    9124:	eb03013f 	cmp	x9, x3
    9128:	54003440 	b.eq	97b0 <fwp_write+0xa40>  // b.none
    912c:	9b467e60 	smulh	x0, x19, x6
    9130:	937ffe64 	asr	x4, x19, #63
    9134:	52800605 	mov	w5, #0x30                  	// #48
    9138:	cb040000 	sub	x0, x0, x4
    913c:	8b000400 	add	x0, x0, x0, lsl #1
    9140:	cb000260 	sub	x0, x19, x0
    9144:	91000c01 	add	x1, x0, #0x3
    9148:	9bc87c22 	umulh	x2, x1, x8
    914c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    9150:	8b4204e2 	add	x2, x7, x2, lsr #1
    9154:	eb020021 	subs	x1, x1, x2
    9158:	54fffd60 	b.eq	9104 <fwp_write+0x394>  // b.none
    915c:	f100043f 	cmp	x1, #0x1
    9160:	54fffce1 	b.ne	90fc <fwp_write+0x38c>  // b.any
    9164:	d2800001 	mov	x1, #0x0                   	// #0
    9168:	52800565 	mov	w5, #0x2b                  	// #43
    916c:	17ffffe6 	b	9104 <fwp_write+0x394>
    9170:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9174:	f947f400 	ldr	x0, [x0, #4072]
    9178:	f94127e2 	ldr	x2, [sp, #584]
    917c:	f9400001 	ldr	x1, [x0]
    9180:	eb010042 	subs	x2, x2, x1
    9184:	d2800001 	mov	x1, #0x0                   	// #0
    9188:	540023c1 	b.ne	9600 <fwp_write+0x890>  // b.any
    918c:	f9413bf5 	ldr	x21, [sp, #624]
    9190:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9194:	f9413ff6 	ldr	x22, [sp, #632]
    9198:	aa1403e0 	mov	x0, x20
    919c:	9118a021 	add	x1, x1, #0x628
    91a0:	d2800102 	mov	x2, #0x8                   	// #8
    91a4:	17ffff77 	b	8f80 <fwp_write+0x210>
    91a8:	aa1403e0 	mov	x0, x20
    91ac:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    91b0:	d28000c2 	mov	x2, #0x6                   	// #6
    91b4:	911a2021 	add	x1, x1, #0x688
    91b8:	97ffe916 	bl	3610 <buf_put>
    91bc:	d2800015 	mov	x21, #0x0                   	// #0
    91c0:	f9400263 	ldr	x3, [x19]
    91c4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    91c8:	54002c60 	b.eq	9754 <fwp_write+0x9e4>  // b.none
    91cc:	f9401f82 	ldr	x2, [x28, #56]
    91d0:	f90143f7 	str	x23, [sp, #640]
    91d4:	f90147f8 	str	x24, [sp, #648]
    91d8:	d2800857 	mov	x23, #0x42                  	// #66
    91dc:	f9014bf9 	str	x25, [sp, #656]
    91e0:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x110>
    91e4:	f9014ffa 	str	x26, [sp, #664]
    91e8:	911a02d6 	add	x22, x22, #0x680
    91ec:	d2800038 	mov	x24, #0x1                   	// #1
    91f0:	f2a18017 	movk	x23, #0xc00, lsl #16
    91f4:	d2809099 	mov	x25, #0x484                 	// #1156
    91f8:	b40004a2 	cbz	x2, 928c <fwp_write+0x51c>
    91fc:	b9400040 	ldr	w0, [x2]
    9200:	7100701f 	cmp	w0, #0x1c
    9204:	540042c0 	b.eq	9a5c <fwp_write+0xcec>  // b.none
    9208:	71006c1f 	cmp	w0, #0x1b
    920c:	54000408 	b.hi	928c <fwp_write+0x51c>  // b.pmore
    9210:	9ac02301 	lsl	x1, x24, x0
    9214:	ea17003f 	tst	x1, x23
    9218:	540036a1 	b.ne	98ec <fwp_write+0xb7c>  // b.any
    921c:	ea19003f 	tst	x1, x25
    9220:	54003521 	b.ne	98c4 <fwp_write+0xb54>  // b.any
    9224:	d2800424 	mov	x4, #0x21                  	// #33
    9228:	ea04003f 	tst	x1, x4
    922c:	54000300 	b.eq	928c <fwp_write+0x51c>  // b.none
    9230:	b7f849c3 	tbnz	x3, #63, 9b68 <fwp_write+0xdf8>
    9234:	91002261 	add	x1, x19, #0x8
    9238:	8b150021 	add	x1, x1, x21
    923c:	39400021 	ldrb	w1, [x1]
    9240:	7100001f 	cmp	w0, #0x0
    9244:	93401c23 	sxtb	x3, w1
    9248:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    924c:	d503201f 	nop
    9250:	aa1403e0 	mov	x0, x20
    9254:	52800003 	mov	w3, #0x0                   	// #0
    9258:	97fffec6 	bl	8d70 <fwp_write>
    925c:	910006b5 	add	x21, x21, #0x1
    9260:	f9400260 	ldr	x0, [x19]
    9264:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    9268:	eb0002bf 	cmp	x21, x0
    926c:	540026c2 	b.cs	9744 <fwp_write+0x9d4>  // b.hs, b.nlast
    9270:	d2800042 	mov	x2, #0x2                   	// #2
    9274:	aa1603e1 	mov	x1, x22
    9278:	aa1403e0 	mov	x0, x20
    927c:	97ffe8e5 	bl	3610 <buf_put>
    9280:	f9401f82 	ldr	x2, [x28, #56]
    9284:	f9400263 	ldr	x3, [x19]
    9288:	b5fffba2 	cbnz	x2, 91fc <fwp_write+0x48c>
    928c:	d37df2a0 	lsl	x0, x21, #3
    9290:	b7f83f03 	tbnz	x3, #63, 9a70 <fwp_write+0xd00>
    9294:	91002261 	add	x1, x19, #0x8
    9298:	8b000020 	add	x0, x1, x0
    929c:	f9400001 	ldr	x1, [x0]
    92a0:	17ffffec 	b	9250 <fwp_write+0x4e0>
    92a4:	a9400e62 	ldp	x2, x3, [x19]
    92a8:	b7f83ca3 	tbnz	x3, #63, 9a3c <fwp_write+0xccc>
    92ac:	910123f5 	add	x21, sp, #0x48
    92b0:	aa1503e0 	mov	x0, x21
    92b4:	97ffe6bb 	bl	2da0 <fwp_fmt_u128>
    92b8:	aa1503e0 	mov	x0, x21
    92bc:	97ffe4f9 	bl	26a0 <strlen@plt>
    92c0:	aa1503e1 	mov	x1, x21
    92c4:	aa0003e2 	mov	x2, x0
    92c8:	17fffed0 	b	8e08 <fwp_write+0x98>
    92cc:	fd015be8 	str	d8, [sp, #688]
    92d0:	1e270268 	fmov	s8, w19
    92d4:	fd015fe9 	str	d9, [sp, #696]
    92d8:	1e282100 	fcmp	s8, s8
    92dc:	54004d26 	b.vs	9c80 <fwp_write+0xf10>
    92e0:	1e20c101 	fabs	s1, s8
    92e4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    92e8:	1e270000 	fmov	s0, w0
    92ec:	1e202020 	fcmp	s1, s0
    92f0:	54002c0d 	b.le	9870 <fwp_write+0xb00>
    92f4:	1e202118 	fcmpe	s8, #0.0
    92f8:	b0000022 	adrp	x2, e000 <_IO_stdin_used+0x110>
    92fc:	9101a042 	add	x2, x2, #0x68
    9300:	910123f5 	add	x21, sp, #0x48
    9304:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9308:	91176021 	add	x1, x1, #0x5d8
    930c:	aa1503e0 	mov	x0, x21
    9310:	9a81c041 	csel	x1, x2, x1, gt
    9314:	97ffe58f 	bl	2950 <strcpy@plt>
    9318:	aa1503e0 	mov	x0, x21
    931c:	97ffe4e1 	bl	26a0 <strlen@plt>
    9320:	aa1503e1 	mov	x1, x21
    9324:	aa0003e2 	mov	x2, x0
    9328:	aa1403e0 	mov	x0, x20
    932c:	97ffe8b9 	bl	3610 <buf_put>
    9330:	f9413bf5 	ldr	x21, [sp, #624]
    9334:	f9413ff6 	ldr	x22, [sp, #632]
    9338:	f94153fb 	ldr	x27, [sp, #672]
    933c:	f94157fc 	ldr	x28, [sp, #680]
    9340:	fd415be8 	ldr	d8, [sp, #688]
    9344:	fd415fe9 	ldr	d9, [sp, #696]
    9348:	17fffeb6 	b	8e20 <fwp_write+0xb0>
    934c:	f9400276 	ldr	x22, [x19]
    9350:	34002e03 	cbz	w3, 9910 <fwp_write+0xba0>
    9354:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9358:	f947f400 	ldr	x0, [x0, #4072]
    935c:	f94127e2 	ldr	x2, [sp, #584]
    9360:	f9400001 	ldr	x1, [x0]
    9364:	eb010042 	subs	x2, x2, x1
    9368:	d2800001 	mov	x1, #0x0                   	// #0
    936c:	540014a1 	b.ne	9600 <fwp_write+0x890>  // b.any
    9370:	aa1603e2 	mov	x2, x22
    9374:	91002261 	add	x1, x19, #0x8
    9378:	f9413bf5 	ldr	x21, [sp, #624]
    937c:	aa1403e0 	mov	x0, x20
    9380:	f9413ff6 	ldr	x22, [sp, #632]
    9384:	17fffeff 	b	8f80 <fwp_write+0x210>
    9388:	fd015be8 	str	d8, [sp, #688]
    938c:	9e670268 	fmov	d8, x19
    9390:	fd015fe9 	str	d9, [sp, #696]
    9394:	1e682100 	fcmp	d8, d8
    9398:	54004746 	b.vs	9c80 <fwp_write+0xf10>
    939c:	1e60c101 	fabs	d1, d8
    93a0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    93a4:	9e670000 	fmov	d0, x0
    93a8:	910123f5 	add	x21, sp, #0x48
    93ac:	52800033 	mov	w19, #0x1                   	// #1
    93b0:	1e602020 	fcmp	d1, d0
    93b4:	540001ad 	b.le	93e8 <fwp_write+0x678>
    93b8:	1e602118 	fcmpe	d8, #0.0
    93bc:	b0000022 	adrp	x2, e000 <_IO_stdin_used+0x110>
    93c0:	9101a042 	add	x2, x2, #0x68
    93c4:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    93c8:	91176021 	add	x1, x1, #0x5d8
    93cc:	aa1503e0 	mov	x0, x21
    93d0:	9a81c041 	csel	x1, x2, x1, gt
    93d4:	97ffe55f 	bl	2950 <strcpy@plt>
    93d8:	17ffffd0 	b	9318 <fwp_write+0x5a8>
    93dc:	11000673 	add	w19, w19, #0x1
    93e0:	71004a7f 	cmp	w19, #0x12
    93e4:	54003860 	b.eq	9af0 <fwp_write+0xd80>  // b.none
    93e8:	1e604100 	fmov	d0, d8
    93ec:	2a1303e1 	mov	w1, w19
    93f0:	aa1503e0 	mov	x0, x21
    93f4:	97ffe8e3 	bl	3780 <fwp_format_g.constprop.0>
    93f8:	aa1503e0 	mov	x0, x21
    93fc:	d2800001 	mov	x1, #0x0                   	// #0
    9400:	97ffe4bc 	bl	26f0 <strtod@plt>
    9404:	1e602100 	fcmp	d8, d0
    9408:	54fffea1 	b.ne	93dc <fwp_write+0x66c>  // b.any
    940c:	aa1503e0 	mov	x0, x21
    9410:	97ffe8b9 	bl	36f4 <fwp_finish_float>
    9414:	17ffffc1 	b	9318 <fwp_write+0x5a8>
    9418:	a9400e62 	ldp	x2, x3, [x19]
    941c:	910123f3 	add	x19, sp, #0x48
    9420:	aa1303e0 	mov	x0, x19
    9424:	97ffe65f 	bl	2da0 <fwp_fmt_u128>
    9428:	17fffe74 	b	8df8 <fwp_write+0x88>
    942c:	f90143f7 	str	x23, [sp, #640]
    9430:	f90147f8 	str	x24, [sp, #648]
    9434:	2a1303f8 	mov	w24, w19
    9438:	f9014bf9 	str	x25, [sp, #656]
    943c:	f9014ffa 	str	x26, [sp, #664]
    9440:	f13ffe7f 	cmp	x19, #0xfff
    9444:	54000049 	b.ls	944c <fwp_write+0x6dc>  // b.plast
    9448:	b9400278 	ldr	w24, [x19]
    944c:	f9400f80 	ldr	x0, [x28, #24]
    9450:	2a1803f5 	mov	w21, w24
    9454:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9458:	d37ef6b9 	lsl	x25, x21, #2
    945c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9460:	aa1603e0 	mov	x0, x22
    9464:	97ffe48f 	bl	26a0 <strlen@plt>
    9468:	aa1603e1 	mov	x1, x22
    946c:	aa0003e2 	mov	x2, x0
    9470:	aa1403e0 	mov	x0, x20
    9474:	97ffe867 	bl	3610 <buf_put>
    9478:	f9401780 	ldr	x0, [x28, #40]
    947c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9480:	7100001f 	cmp	w0, #0x0
    9484:	5400068d 	b.le	9554 <fwp_write+0x7e4>
    9488:	91002276 	add	x22, x19, #0x8
    948c:	91001ff5 	add	x21, sp, #0x7
    9490:	d280001b 	mov	x27, #0x0                   	// #0
    9494:	5280041a 	mov	w26, #0x20                  	// #32
    9498:	f9401b80 	ldr	x0, [x28, #48]
    949c:	aa1503e1 	mov	x1, x21
    94a0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    94a4:	d2800022 	mov	x2, #0x1                   	// #1
    94a8:	f8786803 	ldr	x3, [x0, x24]
    94ac:	aa1403e0 	mov	x0, x20
    94b0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    94b4:	39001ffa 	strb	w26, [sp, #7]
    94b8:	97ffe856 	bl	3610 <buf_put>
    94bc:	f13ffeff 	cmp	x23, #0xfff
    94c0:	b9400261 	ldr	w1, [x19]
    94c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    94c8:	7100383f 	cmp	w1, #0xe
    94cc:	54000160 	b.eq	94f8 <fwp_write+0x788>  // b.none
    94d0:	7100403f 	cmp	w1, #0x10
    94d4:	54001a60 	b.eq	9820 <fwp_write+0xab0>  // b.none
    94d8:	7100283f 	cmp	w1, #0xa
    94dc:	54002aa0 	b.eq	9a30 <fwp_write+0xcc0>  // b.none
    94e0:	540014ac 	b.gt	9774 <fwp_write+0xa04>
    94e4:	71000c3f 	cmp	w1, #0x3
    94e8:	540029ac 	b.gt	9a1c <fwp_write+0xcac>
    94ec:	d37ffee0 	lsr	x0, x23, #63
    94f0:	37f814a1 	tbnz	w1, #31, 9784 <fwp_write+0xa14>
    94f4:	d503201f 	nop
    94f8:	34001460 	cbz	w0, 9784 <fwp_write+0xa14>
    94fc:	52800503 	mov	w3, #0x28                  	// #40
    9500:	aa1503e1 	mov	x1, x21
    9504:	aa1403e0 	mov	x0, x20
    9508:	d2800022 	mov	x2, #0x1                   	// #1
    950c:	39001fe3 	strb	w3, [sp, #7]
    9510:	97ffe840 	bl	3610 <buf_put>
    9514:	aa1303e2 	mov	x2, x19
    9518:	aa1703e1 	mov	x1, x23
    951c:	aa1403e0 	mov	x0, x20
    9520:	52800003 	mov	w3, #0x0                   	// #0
    9524:	97fffe13 	bl	8d70 <fwp_write>
    9528:	52800523 	mov	w3, #0x29                  	// #41
    952c:	aa1503e1 	mov	x1, x21
    9530:	aa1403e0 	mov	x0, x20
    9534:	d2800022 	mov	x2, #0x1                   	// #1
    9538:	39001fe3 	strb	w3, [sp, #7]
    953c:	97ffe835 	bl	3610 <buf_put>
    9540:	f9401780 	ldr	x0, [x28, #40]
    9544:	9100077b 	add	x27, x27, #0x1
    9548:	b8796800 	ldr	w0, [x0, x25]
    954c:	6b1b001f 	cmp	w0, w27
    9550:	54fffa4c 	b.gt	9498 <fwp_write+0x728>
    9554:	f9413bf5 	ldr	x21, [sp, #624]
    9558:	f9413ff6 	ldr	x22, [sp, #632]
    955c:	f94143f7 	ldr	x23, [sp, #640]
    9560:	f94147f8 	ldr	x24, [sp, #648]
    9564:	f9414bf9 	ldr	x25, [sp, #656]
    9568:	f9414ffa 	ldr	x26, [sp, #664]
    956c:	f94153fb 	ldr	x27, [sp, #672]
    9570:	f94157fc 	ldr	x28, [sp, #680]
    9574:	17fffe2b 	b	8e20 <fwp_write+0xb0>
    9578:	52800783 	mov	w3, #0x3c                  	// #60
    957c:	91001ff3 	add	x19, sp, #0x7
    9580:	aa1303e1 	mov	x1, x19
    9584:	d2800022 	mov	x2, #0x1                   	// #1
    9588:	aa1403e0 	mov	x0, x20
    958c:	39001fe3 	strb	w3, [sp, #7]
    9590:	97ffe820 	bl	3610 <buf_put>
    9594:	f9400795 	ldr	x21, [x28, #8]
    9598:	aa1503e0 	mov	x0, x21
    959c:	97ffe441 	bl	26a0 <strlen@plt>
    95a0:	aa1503e1 	mov	x1, x21
    95a4:	aa0003e2 	mov	x2, x0
    95a8:	aa1403e0 	mov	x0, x20
    95ac:	97ffe819 	bl	3610 <buf_put>
    95b0:	528007c3 	mov	w3, #0x3e                  	// #62
    95b4:	aa1303e1 	mov	x1, x19
    95b8:	aa1403e0 	mov	x0, x20
    95bc:	d2800022 	mov	x2, #0x1                   	// #1
    95c0:	39001fe3 	strb	w3, [sp, #7]
    95c4:	17fffe12 	b	8e0c <fwp_write+0x9c>
    95c8:	f100067f 	cmp	x19, #0x1
    95cc:	540025a0 	b.eq	9a80 <fwp_write+0xd10>  // b.none
    95d0:	b100067f 	cmn	x19, #0x1
    95d4:	54002bc0 	b.eq	9b4c <fwp_write+0xddc>  // b.none
    95d8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    95dc:	91178021 	add	x1, x1, #0x5e0
    95e0:	d2800022 	mov	x2, #0x1                   	// #1
    95e4:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    95e8:	f947f400 	ldr	x0, [x0, #4072]
    95ec:	f94127e4 	ldr	x4, [sp, #584]
    95f0:	f9400003 	ldr	x3, [x0]
    95f4:	eb030084 	subs	x4, x4, x3
    95f8:	d2800003 	mov	x3, #0x0                   	// #0
    95fc:	54ffebe0 	b.eq	9378 <fwp_write+0x608>  // b.none
    9600:	f90143f7 	str	x23, [sp, #640]
    9604:	f90147f8 	str	x24, [sp, #648]
    9608:	f9014bf9 	str	x25, [sp, #656]
    960c:	f9014ffa 	str	x26, [sp, #664]
    9610:	fd015be8 	str	d8, [sp, #688]
    9614:	fd015fe9 	str	d9, [sp, #696]
    9618:	97ffe47e 	bl	2810 <__stack_chk_fail@plt>
    961c:	52800b63 	mov	w3, #0x5b                  	// #91
    9620:	91001ff5 	add	x21, sp, #0x7
    9624:	aa1503e1 	mov	x1, x21
    9628:	aa1403e0 	mov	x0, x20
    962c:	d2800022 	mov	x2, #0x1                   	// #1
    9630:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x110>
    9634:	911a02d6 	add	x22, x22, #0x680
    9638:	39001fe3 	strb	w3, [sp, #7]
    963c:	97ffe7f5 	bl	3610 <buf_put>
    9640:	b4000273 	cbz	x19, 968c <fwp_write+0x91c>
    9644:	f9400661 	ldr	x1, [x19, #8]
    9648:	aa1403e0 	mov	x0, x20
    964c:	f9401f82 	ldr	x2, [x28, #56]
    9650:	52800003 	mov	w3, #0x0                   	// #0
    9654:	97fffdc7 	bl	8d70 <fwp_write>
    9658:	f9400a73 	ldr	x19, [x19, #16]
    965c:	b4000193 	cbz	x19, 968c <fwp_write+0x91c>
    9660:	aa1603e1 	mov	x1, x22
    9664:	aa1403e0 	mov	x0, x20
    9668:	d2800042 	mov	x2, #0x2                   	// #2
    966c:	97ffe7e9 	bl	3610 <buf_put>
    9670:	f9400661 	ldr	x1, [x19, #8]
    9674:	aa1403e0 	mov	x0, x20
    9678:	f9401f82 	ldr	x2, [x28, #56]
    967c:	52800003 	mov	w3, #0x0                   	// #0
    9680:	97fffdbc 	bl	8d70 <fwp_write>
    9684:	f9400a73 	ldr	x19, [x19, #16]
    9688:	b5fffed3 	cbnz	x19, 9660 <fwp_write+0x8f0>
    968c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9690:	aa1503e1 	mov	x1, x21
    9694:	aa1403e0 	mov	x0, x20
    9698:	d2800022 	mov	x2, #0x1                   	// #1
    969c:	39001fe3 	strb	w3, [sp, #7]
    96a0:	17fffddb 	b	8e0c <fwp_write+0x9c>
    96a4:	aa1403e0 	mov	x0, x20
    96a8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    96ac:	d28000c2 	mov	x2, #0x6                   	// #6
    96b0:	9119c021 	add	x1, x1, #0x670
    96b4:	97ffe7d7 	bl	3610 <buf_put>
    96b8:	f9400260 	ldr	x0, [x19]
    96bc:	b40004c0 	cbz	x0, 9754 <fwp_write+0x9e4>
    96c0:	910123f5 	add	x21, sp, #0x48
    96c4:	91002276 	add	x22, x19, #0x8
    96c8:	f90143f7 	str	x23, [sp, #640]
    96cc:	d2800017 	mov	x23, #0x0                   	// #0
    96d0:	f90147f8 	str	x24, [sp, #648]
    96d4:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x110>
    96d8:	9119e318 	add	x24, x24, #0x678
    96dc:	f9014bf9 	str	x25, [sp, #656]
    96e0:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x110>
    96e4:	911a0339 	add	x25, x25, #0x680
    96e8:	f9014ffa 	str	x26, [sp, #664]
    96ec:	14000005 	b	9700 <fwp_write+0x990>
    96f0:	aa1903e1 	mov	x1, x25
    96f4:	aa1403e0 	mov	x0, x20
    96f8:	d2800042 	mov	x2, #0x2                   	// #2
    96fc:	97ffe7c5 	bl	3610 <buf_put>
    9700:	38776ac5 	ldrb	w5, [x22, x23]
    9704:	d2804003 	mov	x3, #0x200                 	// #512
    9708:	aa1803e4 	mov	x4, x24
    970c:	aa0303e1 	mov	x1, x3
    9710:	52800042 	mov	w2, #0x2                   	// #2
    9714:	aa1503e0 	mov	x0, x21
    9718:	910006f7 	add	x23, x23, #0x1
    971c:	97ffe419 	bl	2780 <__snprintf_chk@plt>
    9720:	aa1503e0 	mov	x0, x21
    9724:	97ffe3df 	bl	26a0 <strlen@plt>
    9728:	aa1503e1 	mov	x1, x21
    972c:	aa0003e2 	mov	x2, x0
    9730:	aa1403e0 	mov	x0, x20
    9734:	97ffe7b7 	bl	3610 <buf_put>
    9738:	f9400260 	ldr	x0, [x19]
    973c:	eb17001f 	cmp	x0, x23
    9740:	54fffd88 	b.hi	96f0 <fwp_write+0x980>  // b.pmore
    9744:	f94143f7 	ldr	x23, [sp, #640]
    9748:	f94147f8 	ldr	x24, [sp, #648]
    974c:	f9414bf9 	ldr	x25, [sp, #656]
    9750:	f9414ffa 	ldr	x26, [sp, #664]
    9754:	52800ba3 	mov	w3, #0x5d                  	// #93
    9758:	aa1403e0 	mov	x0, x20
    975c:	91001fe1 	add	x1, sp, #0x7
    9760:	d2800022 	mov	x2, #0x1                   	// #1
    9764:	39001fe3 	strb	w3, [sp, #7]
    9768:	17fffda9 	b	8e0c <fwp_write+0x9c>
    976c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9770:	17fffe44 	b	9080 <fwp_write+0x310>
    9774:	f10002ff 	cmp	x23, #0x0
    9778:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    977c:	71002c3f 	cmp	w1, #0xb
    9780:	54ffebc0 	b.eq	94f8 <fwp_write+0x788>  // b.none
    9784:	aa1303e2 	mov	x2, x19
    9788:	aa1703e1 	mov	x1, x23
    978c:	aa1403e0 	mov	x0, x20
    9790:	52800003 	mov	w3, #0x0                   	// #0
    9794:	97fffd77 	bl	8d70 <fwp_write>
    9798:	17ffff6a 	b	9540 <fwp_write+0x7d0>
    979c:	aa1403e0 	mov	x0, x20
    97a0:	91001fe1 	add	x1, sp, #0x7
    97a4:	52800fa3 	mov	w3, #0x7d                  	// #125
    97a8:	d2800022 	mov	x2, #0x1                   	// #1
    97ac:	17fffe38 	b	908c <fwp_write+0x31c>
    97b0:	a9400281 	ldp	x1, x0, [x20]
    97b4:	91000800 	add	x0, x0, #0x2
    97b8:	8b160000 	add	x0, x0, x22
    97bc:	f9000680 	str	x0, [x20, #8]
    97c0:	3820683f 	strb	wzr, [x1, x0]
    97c4:	f9413bf5 	ldr	x21, [sp, #624]
    97c8:	f9413ff6 	ldr	x22, [sp, #632]
    97cc:	f94153fb 	ldr	x27, [sp, #672]
    97d0:	f94157fc 	ldr	x28, [sp, #680]
    97d4:	17fffd93 	b	8e20 <fwp_write+0xb0>
    97d8:	f9400f80 	ldr	x0, [x28, #24]
    97dc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    97e0:	aa1b03e0 	mov	x0, x27
    97e4:	97ffe3af 	bl	26a0 <strlen@plt>
    97e8:	aa1b03e1 	mov	x1, x27
    97ec:	aa0003e2 	mov	x2, x0
    97f0:	aa1403e0 	mov	x0, x20
    97f4:	97ffe787 	bl	3610 <buf_put>
    97f8:	aa1903e1 	mov	x1, x25
    97fc:	aa1403e0 	mov	x0, x20
    9800:	d2800062 	mov	x2, #0x3                   	// #3
    9804:	97ffe783 	bl	3610 <buf_put>
    9808:	17fffe10 	b	9048 <fwp_write+0x2d8>
    980c:	aa1a03e1 	mov	x1, x26
    9810:	aa1403e0 	mov	x0, x20
    9814:	d2800042 	mov	x2, #0x2                   	// #2
    9818:	97ffe77e 	bl	3610 <buf_put>
    981c:	17fffe09 	b	9040 <fwp_write+0x2d0>
    9820:	f9400660 	ldr	x0, [x19, #8]
    9824:	b4fffb00 	cbz	x0, 9784 <fwp_write+0xa14>
    9828:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    982c:	911a6021 	add	x1, x1, #0x698
    9830:	97ffe418 	bl	2890 <strcmp@plt>
    9834:	7100001f 	cmp	w0, #0x0
    9838:	1a9f07e0 	cset	w0, ne	// ne = any
    983c:	17ffff2f 	b	94f8 <fwp_write+0x788>
    9840:	aa1403e0 	mov	x0, x20
    9844:	d2800042 	mov	x2, #0x2                   	// #2
    9848:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    984c:	911a4021 	add	x1, x1, #0x690
    9850:	97ffe770 	bl	3610 <buf_put>
    9854:	91004261 	add	x1, x19, #0x10
    9858:	aa1403e0 	mov	x0, x20
    985c:	f9402382 	ldr	x2, [x28, #64]
    9860:	52800003 	mov	w3, #0x0                   	// #0
    9864:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9868:	97fffd42 	bl	8d70 <fwp_write>
    986c:	17fffd9c 	b	8edc <fwp_write+0x16c>
    9870:	1e22c109 	fcvt	d9, s8
    9874:	910123f5 	add	x21, sp, #0x48
    9878:	52800033 	mov	w19, #0x1                   	// #1
    987c:	d503201f 	nop
    9880:	1e604120 	fmov	d0, d9
    9884:	2a1303e1 	mov	w1, w19
    9888:	aa1503e0 	mov	x0, x21
    988c:	97ffe7bd 	bl	3780 <fwp_format_g.constprop.0>
    9890:	aa1503e0 	mov	x0, x21
    9894:	d2800001 	mov	x1, #0x0                   	// #0
    9898:	97ffe40a 	bl	28c0 <strtof@plt>
    989c:	1e202100 	fcmp	s8, s0
    98a0:	54ffdb60 	b.eq	940c <fwp_write+0x69c>  // b.none
    98a4:	11000673 	add	w19, w19, #0x1
    98a8:	71002a7f 	cmp	w19, #0xa
    98ac:	54fffea1 	b.ne	9880 <fwp_write+0xb10>  // b.any
    98b0:	1e604120 	fmov	d0, d9
    98b4:	aa1503e0 	mov	x0, x21
    98b8:	52800121 	mov	w1, #0x9                   	// #9
    98bc:	97ffe7b1 	bl	3780 <fwp_format_g.constprop.0>
    98c0:	17fffed3 	b	940c <fwp_write+0x69c>
    98c4:	d37ef6a1 	lsl	x1, x21, #2
    98c8:	b7f81563 	tbnz	x3, #63, 9b74 <fwp_write+0xe04>
    98cc:	91002263 	add	x3, x19, #0x8
    98d0:	8b010061 	add	x1, x3, x1
    98d4:	b9400023 	ldr	w3, [x1]
    98d8:	7100081f 	cmp	w0, #0x2
    98dc:	2a0303e1 	mov	w1, w3
    98e0:	93407c63 	sxtw	x3, w3
    98e4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    98e8:	17fffe5a 	b	9250 <fwp_write+0x4e0>
    98ec:	d37ffaa1 	lsl	x1, x21, #1
    98f0:	b7f81363 	tbnz	x3, #63, 9b5c <fwp_write+0xdec>
    98f4:	91002263 	add	x3, x19, #0x8
    98f8:	8b010061 	add	x1, x3, x1
    98fc:	79400021 	ldrh	w1, [x1]
    9900:	7100041f 	cmp	w0, #0x1
    9904:	93403c23 	sxth	x3, w1
    9908:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    990c:	17fffe51 	b	9250 <fwp_write+0x4e0>
    9910:	52800443 	mov	w3, #0x22                  	// #34
    9914:	91001ff5 	add	x21, sp, #0x7
    9918:	91002273 	add	x19, x19, #0x8
    991c:	aa1503e1 	mov	x1, x21
    9920:	aa1403e0 	mov	x0, x20
    9924:	d2800022 	mov	x2, #0x1                   	// #1
    9928:	39001fe3 	strb	w3, [sp, #7]
    992c:	f90143f7 	str	x23, [sp, #640]
    9930:	8b160277 	add	x23, x19, x22
    9934:	f90147f8 	str	x24, [sp, #648]
    9938:	97ffe736 	bl	3610 <buf_put>
    993c:	b4000696 	cbz	x22, 9a0c <fwp_write+0xc9c>
    9940:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x110>
    9944:	91190318 	add	x24, x24, #0x640
    9948:	f9014bf9 	str	x25, [sp, #656]
    994c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x110>
    9950:	91198339 	add	x25, x25, #0x660
    9954:	f9014ffa 	str	x26, [sp, #664]
    9958:	1400000d 	b	998c <fwp_write+0xc1c>
    995c:	710024bf 	cmp	w5, #0x9
    9960:	54000460 	b.eq	99ec <fwp_write+0xc7c>  // b.none
    9964:	710028bf 	cmp	w5, #0xa
    9968:	54000a61 	b.ne	9ab4 <fwp_write+0xd44>  // b.any
    996c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9970:	aa1403e0 	mov	x0, x20
    9974:	91194021 	add	x1, x1, #0x650
    9978:	d2800042 	mov	x2, #0x2                   	// #2
    997c:	97ffe725 	bl	3610 <buf_put>
    9980:	91000673 	add	x19, x19, #0x1
    9984:	eb17027f 	cmp	x19, x23
    9988:	540003e0 	b.eq	9a04 <fwp_write+0xc94>  // b.none
    998c:	39400265 	ldrb	w5, [x19]
    9990:	710034bf 	cmp	w5, #0xd
    9994:	54000180 	b.eq	99c4 <fwp_write+0xc54>  // b.none
    9998:	54fffe29 	b.ls	995c <fwp_write+0xbec>  // b.plast
    999c:	710088bf 	cmp	w5, #0x22
    99a0:	540001c0 	b.eq	99d8 <fwp_write+0xc68>  // b.none
    99a4:	710170bf 	cmp	w5, #0x5c
    99a8:	54000741 	b.ne	9a90 <fwp_write+0xd20>  // b.any
    99ac:	aa1403e0 	mov	x0, x20
    99b0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    99b4:	d2800042 	mov	x2, #0x2                   	// #2
    99b8:	91192021 	add	x1, x1, #0x648
    99bc:	97ffe715 	bl	3610 <buf_put>
    99c0:	17fffff0 	b	9980 <fwp_write+0xc10>
    99c4:	aa1903e1 	mov	x1, x25
    99c8:	aa1403e0 	mov	x0, x20
    99cc:	d2800042 	mov	x2, #0x2                   	// #2
    99d0:	97ffe710 	bl	3610 <buf_put>
    99d4:	17ffffeb 	b	9980 <fwp_write+0xc10>
    99d8:	aa1803e1 	mov	x1, x24
    99dc:	aa1403e0 	mov	x0, x20
    99e0:	d2800042 	mov	x2, #0x2                   	// #2
    99e4:	97ffe70b 	bl	3610 <buf_put>
    99e8:	17ffffe6 	b	9980 <fwp_write+0xc10>
    99ec:	aa1403e0 	mov	x0, x20
    99f0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    99f4:	d2800042 	mov	x2, #0x2                   	// #2
    99f8:	91196021 	add	x1, x1, #0x658
    99fc:	97ffe705 	bl	3610 <buf_put>
    9a00:	17ffffe0 	b	9980 <fwp_write+0xc10>
    9a04:	f9414bf9 	ldr	x25, [sp, #656]
    9a08:	f9414ffa 	ldr	x26, [sp, #664]
    9a0c:	aa1503e1 	mov	x1, x21
    9a10:	aa1403e0 	mov	x0, x20
    9a14:	52800443 	mov	w3, #0x22                  	// #34
    9a18:	17fffd9c 	b	9088 <fwp_write+0x318>
    9a1c:	7100103f 	cmp	w1, #0x4
    9a20:	54ffeb21 	b.ne	9784 <fwp_write+0xa14>  // b.any
    9a24:	f94006e0 	ldr	x0, [x23, #8]
    9a28:	d37ffc00 	lsr	x0, x0, #63
    9a2c:	17fffeb3 	b	94f8 <fwp_write+0x788>
    9a30:	710002ff 	cmp	w23, #0x0
    9a34:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9a38:	17fffeb0 	b	94f8 <fwp_write+0x788>
    9a3c:	528005a1 	mov	w1, #0x2d                  	// #45
    9a40:	eb0203e2 	negs	x2, x2
    9a44:	da0303e3 	ngc	x3, x3
    9a48:	910127e0 	add	x0, sp, #0x49
    9a4c:	910123f5 	add	x21, sp, #0x48
    9a50:	390123e1 	strb	w1, [sp, #72]
    9a54:	97ffe4d3 	bl	2da0 <fwp_fmt_u128>
    9a58:	17fffe18 	b	92b8 <fwp_write+0x548>
    9a5c:	d37ceea1 	lsl	x1, x21, #4
    9a60:	b7f810a3 	tbnz	x3, #63, 9c74 <fwp_write+0xf04>
    9a64:	91002260 	add	x0, x19, #0x8
    9a68:	8b010001 	add	x1, x0, x1
    9a6c:	17fffdf9 	b	9250 <fwp_write+0x4e0>
    9a70:	f9400a61 	ldr	x1, [x19, #16]
    9a74:	8b010000 	add	x0, x0, x1
    9a78:	f9400001 	ldr	x1, [x0]
    9a7c:	17fffdf5 	b	9250 <fwp_write+0x4e0>
    9a80:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9a84:	d2800042 	mov	x2, #0x2                   	// #2
    9a88:	9117a021 	add	x1, x1, #0x5e8
    9a8c:	17fffed6 	b	95e4 <fwp_write+0x874>
    9a90:	7101fcbf 	cmp	w5, #0x7f
    9a94:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9a98:	540000e9 	b.ls	9ab4 <fwp_write+0xd44>  // b.plast
    9a9c:	aa1503e1 	mov	x1, x21
    9aa0:	aa1403e0 	mov	x0, x20
    9aa4:	d2800022 	mov	x2, #0x1                   	// #1
    9aa8:	39001fe5 	strb	w5, [sp, #7]
    9aac:	97ffe6d9 	bl	3610 <buf_put>
    9ab0:	17ffffb4 	b	9980 <fwp_write+0xc10>
    9ab4:	d2800203 	mov	x3, #0x10                  	// #16
    9ab8:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x110>
    9abc:	aa0303e1 	mov	x1, x3
    9ac0:	9119a084 	add	x4, x4, #0x668
    9ac4:	910123f6 	add	x22, sp, #0x48
    9ac8:	52800042 	mov	w2, #0x2                   	// #2
    9acc:	aa1603e0 	mov	x0, x22
    9ad0:	97ffe32c 	bl	2780 <__snprintf_chk@plt>
    9ad4:	aa1603e0 	mov	x0, x22
    9ad8:	97ffe2f2 	bl	26a0 <strlen@plt>
    9adc:	aa1603e1 	mov	x1, x22
    9ae0:	aa0003e2 	mov	x2, x0
    9ae4:	aa1403e0 	mov	x0, x20
    9ae8:	97ffe6ca 	bl	3610 <buf_put>
    9aec:	17ffffa5 	b	9980 <fwp_write+0xc10>
    9af0:	1e604100 	fmov	d0, d8
    9af4:	aa1503e0 	mov	x0, x21
    9af8:	52800221 	mov	w1, #0x11                  	// #17
    9afc:	97ffe721 	bl	3780 <fwp_format_g.constprop.0>
    9b00:	17fffe43 	b	940c <fwp_write+0x69c>
    9b04:	b9401040 	ldr	w0, [x2, #16]
    9b08:	350003c0 	cbnz	w0, 9b80 <fwp_write+0xe10>
    9b0c:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9b10:	f947f400 	ldr	x0, [x0, #4072]
    9b14:	f94127e2 	ldr	x2, [sp, #584]
    9b18:	f9400001 	ldr	x1, [x0]
    9b1c:	eb010042 	subs	x2, x2, x1
    9b20:	d2800001 	mov	x1, #0x0                   	// #0
    9b24:	54ffd721 	b.ne	9608 <fwp_write+0x898>  // b.any
    9b28:	f9413bf5 	ldr	x21, [sp, #624]
    9b2c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9b30:	f9413ff6 	ldr	x22, [sp, #632]
    9b34:	aa1403e0 	mov	x0, x20
    9b38:	f94143f7 	ldr	x23, [sp, #640]
    9b3c:	911ae021 	add	x1, x1, #0x6b8
    9b40:	f94147f8 	ldr	x24, [sp, #648]
    9b44:	d2800042 	mov	x2, #0x2                   	// #2
    9b48:	17fffd0e 	b	8f80 <fwp_write+0x210>
    9b4c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x110>
    9b50:	d2800042 	mov	x2, #0x2                   	// #2
    9b54:	9117c021 	add	x1, x1, #0x5f0
    9b58:	17fffea3 	b	95e4 <fwp_write+0x874>
    9b5c:	f9400a63 	ldr	x3, [x19, #16]
    9b60:	8b030021 	add	x1, x1, x3
    9b64:	17ffff66 	b	98fc <fwp_write+0xb8c>
    9b68:	f9400a61 	ldr	x1, [x19, #16]
    9b6c:	8b0102a1 	add	x1, x21, x1
    9b70:	17fffdb3 	b	923c <fwp_write+0x4cc>
    9b74:	f9400a63 	ldr	x3, [x19, #16]
    9b78:	8b030021 	add	x1, x1, x3
    9b7c:	17ffff56 	b	98d4 <fwp_write+0xb64>
    9b80:	b9404840 	ldr	w0, [x2, #72]
    9b84:	91001ff5 	add	x21, sp, #0x7
    9b88:	34ffa360 	cbz	w0, 8ff4 <fwp_write+0x284>
    9b8c:	52800503 	mov	w3, #0x28                  	// #40
    9b90:	aa1403e0 	mov	x0, x20
    9b94:	aa1503e1 	mov	x1, x21
    9b98:	d2800022 	mov	x2, #0x1                   	// #1
    9b9c:	39001fe3 	strb	w3, [sp, #7]
    9ba0:	97ffe69c 	bl	3610 <buf_put>
    9ba4:	b9401380 	ldr	w0, [x28, #16]
    9ba8:	52800038 	mov	w24, #0x1                   	// #1
    9bac:	7100001f 	cmp	w0, #0x0
    9bb0:	54ffa36c 	b.gt	901c <fwp_write+0x2ac>
    9bb4:	17fffd32 	b	907c <fwp_write+0x30c>
    9bb8:	f9014bf9 	str	x25, [sp, #656]
    9bbc:	b0000139 	adrp	x25, 2e000 <__FRAME_END__+0x1dc50>
    9bc0:	f9014ffa 	str	x26, [sp, #664]
    9bc4:	f9400676 	ldr	x22, [x19, #8]
    9bc8:	91104333 	add	x19, x25, #0x410
    9bcc:	91002273 	add	x19, x19, #0x8
    9bd0:	937ffed8 	asr	x24, x22, #63
    9bd4:	aa1802c0 	orr	x0, x22, x24
    9bd8:	b5000320 	cbnz	x0, 9c3c <fwp_write+0xecc>
    9bdc:	110006b5 	add	w21, w21, #0x1
    9be0:	710016bf 	cmp	w21, #0x5
    9be4:	54ffffc1 	b.ne	9bdc <fwp_write+0xe6c>  // b.any
    9be8:	b7f80578 	tbnz	x24, #63, 9c94 <fwp_write+0xf24>
    9bec:	910023f3 	add	x19, sp, #0x8
    9bf0:	aa1603e2 	mov	x2, x22
    9bf4:	aa1303e0 	mov	x0, x19
    9bf8:	d2800003 	mov	x3, #0x0                   	// #0
    9bfc:	97ffe469 	bl	2da0 <fwp_fmt_u128>
    9c00:	910123f5 	add	x21, sp, #0x48
    9c04:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x110>
    9c08:	aa1303e4 	mov	x4, x19
    9c0c:	aa1503e0 	mov	x0, x21
    9c10:	911ac063 	add	x3, x3, #0x6b0
    9c14:	d2804002 	mov	x2, #0x200                 	// #512
    9c18:	52800041 	mov	w1, #0x2                   	// #2
    9c1c:	97ffe2a5 	bl	26b0 <__sprintf_chk@plt>
    9c20:	aa1503e0 	mov	x0, x21
    9c24:	97ffe29f 	bl	26a0 <strlen@plt>
    9c28:	aa1503e1 	mov	x1, x21
    9c2c:	aa0003e2 	mov	x2, x0
    9c30:	aa1403e0 	mov	x0, x20
    9c34:	97ffe677 	bl	3610 <buf_put>
    9c38:	17fffe47 	b	9554 <fwp_write+0x7e4>
    9c3c:	f9400277 	ldr	x23, [x19]
    9c40:	aa1603e0 	mov	x0, x22
    9c44:	aa1803e1 	mov	x1, x24
    9c48:	aa1703e2 	mov	x2, x23
    9c4c:	937ffefa 	asr	x26, x23, #63
    9c50:	aa1a03e3 	mov	x3, x26
    9c54:	94000fbf 	bl	db50 <__modti3>
    9c58:	aa010000 	orr	x0, x0, x1
    9c5c:	b40002c0 	cbz	x0, 9cb4 <fwp_write+0xf44>
    9c60:	110006b5 	add	w21, w21, #0x1
    9c64:	91004273 	add	x19, x19, #0x10
    9c68:	710016bf 	cmp	w21, #0x5
    9c6c:	54fffe81 	b.ne	9c3c <fwp_write+0xecc>  // b.any
    9c70:	17ffffde 	b	9be8 <fwp_write+0xe78>
    9c74:	f9400a60 	ldr	x0, [x19, #16]
    9c78:	8b000021 	add	x1, x1, x0
    9c7c:	17fffd75 	b	9250 <fwp_write+0x4e0>
    9c80:	528c29c0 	mov	w0, #0x614e                	// #24910
    9c84:	910123f5 	add	x21, sp, #0x48
    9c88:	72a009c0 	movk	w0, #0x4e, lsl #16
    9c8c:	b9004be0 	str	w0, [sp, #72]
    9c90:	17fffda2 	b	9318 <fwp_write+0x5a8>
    9c94:	528005a1 	mov	w1, #0x2d                  	// #45
    9c98:	eb1603e2 	negs	x2, x22
    9c9c:	da1803e3 	ngc	x3, x24
    9ca0:	910027e0 	add	x0, sp, #0x9
    9ca4:	910023f3 	add	x19, sp, #0x8
    9ca8:	390023e1 	strb	w1, [sp, #8]
    9cac:	97ffe43d 	bl	2da0 <fwp_fmt_u128>
    9cb0:	17ffffd4 	b	9c00 <fwp_write+0xe90>
    9cb4:	aa1703e2 	mov	x2, x23
    9cb8:	aa1a03e3 	mov	x3, x26
    9cbc:	aa1603e0 	mov	x0, x22
    9cc0:	aa1803e1 	mov	x1, x24
    9cc4:	94000ec3 	bl	d7d0 <__divti3>
    9cc8:	aa0003e2 	mov	x2, x0
    9ccc:	aa0103e3 	mov	x3, x1
    9cd0:	b7f80201 	tbnz	x1, #63, 9d10 <fwp_write+0xfa0>
    9cd4:	910023f3 	add	x19, sp, #0x8
    9cd8:	aa1303e0 	mov	x0, x19
    9cdc:	97ffe431 	bl	2da0 <fwp_fmt_u128>
    9ce0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9ce4:	91104339 	add	x25, x25, #0x410
    9ce8:	910123f5 	add	x21, sp, #0x48
    9cec:	aa1303e4 	mov	x4, x19
    9cf0:	aa1503e0 	mov	x0, x21
    9cf4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x110>
    9cf8:	f8616b25 	ldr	x5, [x25, x1]
    9cfc:	911aa063 	add	x3, x3, #0x6a8
    9d00:	d2804002 	mov	x2, #0x200                 	// #512
    9d04:	52800041 	mov	w1, #0x2                   	// #2
    9d08:	97ffe26a 	bl	26b0 <__sprintf_chk@plt>
    9d0c:	17ffffc5 	b	9c20 <fwp_write+0xeb0>
    9d10:	528005a4 	mov	w4, #0x2d                  	// #45
    9d14:	eb0003e2 	negs	x2, x0
    9d18:	da0103e3 	ngc	x3, x1
    9d1c:	910027e0 	add	x0, sp, #0x9
    9d20:	910023f3 	add	x19, sp, #0x8
    9d24:	390023e4 	strb	w4, [sp, #8]
    9d28:	97ffe41e 	bl	2da0 <fwp_fmt_u128>
    9d2c:	17ffffed 	b	9ce0 <fwp_write+0xf70>
    9d30:	f9013bf5 	str	x21, [sp, #624]
    9d34:	f9013ff6 	str	x22, [sp, #632]
    9d38:	f90143f7 	str	x23, [sp, #640]
    9d3c:	f90147f8 	str	x24, [sp, #648]
    9d40:	f9014bf9 	str	x25, [sp, #656]
    9d44:	f9014ffa 	str	x26, [sp, #664]
    9d48:	f90153fb 	str	x27, [sp, #672]
    9d4c:	f90157fc 	str	x28, [sp, #680]
    9d50:	fd015be8 	str	d8, [sp, #688]
    9d54:	fd015fe9 	str	d9, [sp, #696]
    9d58:	97ffe2ae 	bl	2810 <__stack_chk_fail@plt>
    9d5c:	d503201f 	nop

0000000000009d60 <fwp_hof0.constprop.0>:
    9d60:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9d64:	d0000122 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    9d68:	f947f442 	ldr	x2, [x2, #4072]
    9d6c:	910003fd 	mov	x29, sp
    9d70:	a90153f3 	stp	x19, x20, [sp, #16]
    9d74:	a9025bf5 	stp	x21, x22, [sp, #32]
    9d78:	a90363f7 	stp	x23, x24, [sp, #48]
    9d7c:	aa0003f7 	mov	x23, x0
    9d80:	a9046bf9 	stp	x25, x26, [sp, #64]
    9d84:	a90573fb 	stp	x27, x28, [sp, #80]
    9d88:	d10203ff 	sub	sp, sp, #0x80
    9d8c:	f9400040 	ldr	x0, [x2]
    9d90:	f81f83a0 	stur	x0, [x29, #-8]
    9d94:	d2800000 	mov	x0, #0x0                   	// #0
    9d98:	b4003aa1 	cbz	x1, a4ec <fwp_hof0.constprop.0+0x78c>
    9d9c:	f0000120 	adrp	x0, 30000 <__data_start>
    9da0:	9100401c 	add	x28, x0, #0x10
    9da4:	aa1703fa 	mov	x26, x23
    9da8:	f0000120 	adrp	x0, 30000 <__data_start>
    9dac:	9100a39c 	add	x28, x28, #0x28
    9db0:	d10083b4 	sub	x20, x29, #0x20
    9db4:	91018015 	add	x21, x0, #0x60
    9db8:	aa0103f7 	mov	x23, x1
    9dbc:	90000400 	adrp	x0, 89000 <fwp_root_context+0xba0>
    9dc0:	91190001 	add	x1, x0, #0x640
    9dc4:	f949d822 	ldr	x2, [x1, #5040]
    9dc8:	f949ec20 	ldr	x0, [x1, #5080]
    9dcc:	cb020342 	sub	x2, x26, x2
    9dd0:	eb00405f 	cmp	x2, x0, lsl #16
    9dd4:	540003c2 	b.cs	9e4c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9dd8:	d350fc40 	lsr	x0, x2, #16
    9ddc:	f949fc24 	ldr	x4, [x1, #5112]
    9de0:	8b000800 	add	x0, x0, x0, lsl #2
    9de4:	d37df001 	lsl	x1, x0, #3
    9de8:	8b010083 	add	x3, x4, x1
    9dec:	f9401060 	ldr	x0, [x3, #32]
    9df0:	b40002e0 	cbz	x0, 9e4c <fwp_hof0.constprop.0+0xec>
    9df4:	38616881 	ldrb	w1, [x4, x1]
    9df8:	7100083f 	cmp	w1, #0x2
    9dfc:	54005920 	b.eq	a920 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9e00:	7100043f 	cmp	w1, #0x1
    9e04:	54000241 	b.ne	9e4c <fwp_hof0.constprop.0+0xec>  // b.any
    9e08:	92403c41 	and	x1, x2, #0xffff
    9e0c:	29430864 	ldp	w4, w2, [x3, #24]
    9e10:	9b047c21 	mul	x1, x1, x4
    9e14:	d360fc21 	lsr	x1, x1, #32
    9e18:	eb02003f 	cmp	x1, x2
    9e1c:	54000182 	b.cs	9e4c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9e20:	8b010000 	add	x0, x0, x1
    9e24:	39400001 	ldrb	w1, [x0]
    9e28:	34000121 	cbz	w1, 9e4c <fwp_hof0.constprop.0+0xec>
    9e2c:	f0000122 	adrp	x2, 30000 <__data_start>
    9e30:	91018042 	add	x2, x2, #0x60
    9e34:	b9413043 	ldr	w3, [x2, #304]
    9e38:	350057a3 	cbnz	w3, a92c <fwp_hof0.constprop.0+0xbcc>
    9e3c:	7103f43f 	cmp	w1, #0xfd
    9e40:	54005a28 	b.hi	a984 <fwp_hof0.constprop.0+0xc24>  // b.pmore
    9e44:	11000421 	add	w1, w1, #0x1
    9e48:	39000001 	strb	w1, [x0]
    9e4c:	aa1a03f8 	mov	x24, x26
    9e50:	aa1c03f9 	mov	x25, x28
    9e54:	d28018f3 	mov	x19, #0xc7                  	// #199
    9e58:	a9396bb7 	stp	x23, x26, [x29, #-112]
    9e5c:	f81a03b3 	stur	x19, [x29, #-96]
    9e60:	f0000120 	adrp	x0, 30000 <__data_start>
    9e64:	91004000 	add	x0, x0, #0x10
    9e68:	f9408ea3 	ldr	x3, [x21, #280]
    9e6c:	9100a006 	add	x6, x0, #0x28
    9e70:	b9402802 	ldr	w2, [x0, #40]
    9e74:	d37be842 	lsl	x2, x2, #5
    9e78:	8b020064 	add	x4, x3, x2
    9e7c:	f9400c81 	ldr	x1, [x4, #24]
    9e80:	f81e03b8 	stur	x24, [x29, #-32]
    9e84:	b4005641 	cbz	x1, a94c <fwp_hof0.constprop.0+0xbec>
    9e88:	f9400c20 	ldr	x0, [x1, #24]
    9e8c:	b4004920 	cbz	x0, a7b0 <fwp_hof0.constprop.0+0xa50>
    9e90:	90000400 	adrp	x0, 89000 <fwp_root_context+0xba0>
    9e94:	91190002 	add	x2, x0, #0x640
    9e98:	f949d841 	ldr	x1, [x2, #5040]
    9e9c:	f949ec40 	ldr	x0, [x2, #5080]
    9ea0:	cb010321 	sub	x1, x25, x1
    9ea4:	eb00403f 	cmp	x1, x0, lsl #16
    9ea8:	540003e2 	b.cs	9f24 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9eac:	d350fc20 	lsr	x0, x1, #16
    9eb0:	f949fc45 	ldr	x5, [x2, #5112]
    9eb4:	8b000800 	add	x0, x0, x0, lsl #2
    9eb8:	d37df002 	lsl	x2, x0, #3
    9ebc:	8b0200a3 	add	x3, x5, x2
    9ec0:	f9401060 	ldr	x0, [x3, #32]
    9ec4:	b4000300 	cbz	x0, 9f24 <fwp_hof0.constprop.0+0x1c4>
    9ec8:	386268a2 	ldrb	w2, [x5, x2]
    9ecc:	7100085f 	cmp	w2, #0x2
    9ed0:	54004dc0 	b.eq	a888 <fwp_hof0.constprop.0+0xb28>  // b.none
    9ed4:	7100045f 	cmp	w2, #0x1
    9ed8:	54000261 	b.ne	9f24 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9edc:	29430865 	ldp	w5, w2, [x3, #24]
    9ee0:	92403c21 	and	x1, x1, #0xffff
    9ee4:	9b057c21 	mul	x1, x1, x5
    9ee8:	d360fc21 	lsr	x1, x1, #32
    9eec:	eb02003f 	cmp	x1, x2
    9ef0:	540001a2 	b.cs	9f24 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9ef4:	8b010000 	add	x0, x0, x1
    9ef8:	39400001 	ldrb	w1, [x0]
    9efc:	34000141 	cbz	w1, 9f24 <fwp_hof0.constprop.0+0x1c4>
    9f00:	b94132a2 	ldr	w2, [x21, #304]
    9f04:	34000082 	cbz	w2, 9f14 <fwp_hof0.constprop.0+0x1b4>
    9f08:	f940aea2 	ldr	x2, [x21, #344]
    9f0c:	91000442 	add	x2, x2, #0x1
    9f10:	f900aea2 	str	x2, [x21, #344]
    9f14:	7103f43f 	cmp	w1, #0xfd
    9f18:	54005128 	b.hi	a93c <fwp_hof0.constprop.0+0xbdc>  // b.pmore
    9f1c:	11000421 	add	w1, w1, #0x1
    9f20:	39000001 	strb	w1, [x0]
    9f24:	90000401 	adrp	x1, 89000 <fwp_root_context+0xba0>
    9f28:	aa1903f8 	mov	x24, x25
    9f2c:	aa1903e0 	mov	x0, x25
    9f30:	91190036 	add	x22, x1, #0x640
    9f34:	52800037 	mov	w23, #0x1                   	// #1
    9f38:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    9f3c:	b81cc3b7 	stur	w23, [x29, #-52]
    9f40:	f81d03b4 	stur	x20, [x29, #-48]
    9f44:	b9400401 	ldr	w1, [x0, #4]
    9f48:	b9400099 	ldr	w25, [x4]
    9f4c:	b85cc3a0 	ldur	w0, [x29, #-52]
    9f50:	4b010339 	sub	w25, w25, w1
    9f54:	6b17033f 	cmp	w25, w23
    9f58:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    9f5c:	6b0000df 	cmp	w6, w0
    9f60:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    9f64:	b81c83a0 	stur	w0, [x29, #-56]
    9f68:	6b0000c2 	subs	w2, w6, w0
    9f6c:	54000120 	b.eq	9f90 <fwp_hof0.constprop.0+0x230>  // b.none
    9f70:	f9400c83 	ldr	x3, [x4, #24]
    9f74:	0b000021 	add	w1, w1, w0
    9f78:	f85d03a4 	ldur	x4, [x29, #-48]
    9f7c:	b81d83a6 	stur	w6, [x29, #-40]
    9f80:	f9400863 	ldr	x3, [x3, #16]
    9f84:	8b204c80 	add	x0, x4, w0, uxtw #3
    9f88:	d63f0060 	blr	x3
    9f8c:	b85d83a6 	ldur	w6, [x29, #-40]
    9f90:	f9408ea0 	ldr	x0, [x21, #280]
    9f94:	aa1803e9 	mov	x9, x24
    9f98:	b9400304 	ldr	w4, [x24]
    9f9c:	2a0603f4 	mov	w20, w6
    9fa0:	f85d03bb 	ldur	x27, [x29, #-48]
    9fa4:	aa1803fa 	mov	x26, x24
    9fa8:	8b041404 	add	x4, x0, x4, lsl #5
    9fac:	f9400c8a 	ldr	x10, [x4, #24]
    9fb0:	b400104a 	cbz	x10, a1b8 <fwp_hof0.constprop.0+0x458>
    9fb4:	29371bb7 	stp	w23, w6, [x29, #-72]
    9fb8:	aa0403f7 	mov	x23, x4
    9fbc:	b81c03b9 	stur	w25, [x29, #-64]
    9fc0:	aa1b03f9 	mov	x25, x27
    9fc4:	14000012 	b	a00c <fwp_hof0.constprop.0+0x2ac>
    9fc8:	f9400141 	ldr	x1, [x10]
    9fcc:	aa1903e0 	mov	x0, x25
    9fd0:	d63f0020 	blr	x1
    9fd4:	aa0003fb 	mov	x27, x0
    9fd8:	aa1803e0 	mov	x0, x24
    9fdc:	97fff15d 	bl	6550 <fwp_closure_drop>
    9fe0:	6b14027f 	cmp	w19, w20
    9fe4:	54000ca0 	b.eq	a178 <fwp_hof0.constprop.0+0x418>  // b.none
    9fe8:	f9408ea0 	ldr	x0, [x21, #280]
    9fec:	8b334f39 	add	x25, x25, w19, uxtw #3
    9ff0:	b9400364 	ldr	w4, [x27]
    9ff4:	4b1a0394 	sub	w20, w28, w26
    9ff8:	aa1b03e9 	mov	x9, x27
    9ffc:	8b041417 	add	x23, x0, x4, lsl #5
    a000:	f9400eea 	ldr	x10, [x23, #24]
    a004:	b4000d2a 	cbz	x10, a1a8 <fwp_hof0.constprop.0+0x448>
    a008:	aa1b03f8 	mov	x24, x27
    a00c:	b9400521 	ldr	w1, [x9, #4]
    a010:	b94002fa 	ldr	w26, [x23]
    a014:	0b14003c 	add	w28, w1, w20
    a018:	6b1c035f 	cmp	w26, w28
    a01c:	54002888 	b.hi	a52c <fwp_hof0.constprop.0+0x7cc>  // b.pmore
    a020:	7100003f 	cmp	w1, #0x0
    a024:	4b010353 	sub	w19, w26, w1
    a028:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    a02c:	54fffce1 	b.ne	9fc8 <fwp_hof0.constprop.0+0x268>  // b.any
    a030:	910003e0 	mov	x0, sp
    a034:	7100035f 	cmp	w26, #0x0
    a038:	f81d83a0 	stur	x0, [x29, #-40]
    a03c:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    a040:	d37df000 	lsl	x0, x0, #3
    a044:	91003c00 	add	x0, x0, #0xf
    a048:	92704c05 	and	x5, x0, #0xfffff0000
    a04c:	927c7c00 	and	x0, x0, #0xffffffff0
    a050:	cb2563e5 	sub	x5, sp, x5
    a054:	eb2563ff 	cmp	sp, x5
    a058:	540000a0 	b.eq	a06c <fwp_hof0.constprop.0+0x30c>  // b.none
    a05c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a060:	f90203ff 	str	xzr, [sp, #1024]
    a064:	eb2563ff 	cmp	sp, x5
    a068:	54ffffa1 	b.ne	a05c <fwp_hof0.constprop.0+0x2fc>  // b.any
    a06c:	92403c00 	and	x0, x0, #0xffff
    a070:	cb2063ff 	sub	sp, sp, x0
    a074:	f90003ff 	str	xzr, [sp]
    a078:	f110001f 	cmp	x0, #0x400
    a07c:	54000043 	b.cc	a084 <fwp_hof0.constprop.0+0x324>  // b.lo, b.ul, b.last
    a080:	f90203ff 	str	xzr, [sp, #1024]
    a084:	910043fb 	add	x27, sp, #0x10
    a088:	d37d7c28 	ubfiz	x8, x1, #3, #32
    a08c:	91002127 	add	x7, x9, #0x8
    a090:	d2800000 	mov	x0, #0x0                   	// #0
    a094:	340000c1 	cbz	w1, a0ac <fwp_hof0.constprop.0+0x34c>
    a098:	f86068e2 	ldr	x2, [x7, x0]
    a09c:	f8206b62 	str	x2, [x27, x0]
    a0a0:	91002000 	add	x0, x0, #0x8
    a0a4:	eb00011f 	cmp	x8, x0
    a0a8:	54ffff81 	b.ne	a098 <fwp_hof0.constprop.0+0x338>  // b.any
    a0ac:	2a1303e8 	mov	w8, w19
    a0b0:	d2800000 	mov	x0, #0x0                   	// #0
    a0b4:	340000f3 	cbz	w19, a0d0 <fwp_hof0.constprop.0+0x370>
    a0b8:	0b000022 	add	w2, w1, w0
    a0bc:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    a0c0:	91000400 	add	x0, x0, #0x1
    a0c4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a0c8:	eb00011f 	cmp	x8, x0
    a0cc:	54ffff61 	b.ne	a0b8 <fwp_hof0.constprop.0+0x358>  // b.any
    a0d0:	f949dac0 	ldr	x0, [x22, #5040]
    a0d4:	f949eec1 	ldr	x1, [x22, #5080]
    a0d8:	cb000300 	sub	x0, x24, x0
    a0dc:	eb01401f 	cmp	x0, x1, lsl #16
    a0e0:	540002e2 	b.cs	a13c <fwp_hof0.constprop.0+0x3dc>  // b.hs, b.nlast
    a0e4:	d350fc01 	lsr	x1, x0, #16
    a0e8:	f949fec8 	ldr	x8, [x22, #5112]
    a0ec:	8b010821 	add	x1, x1, x1, lsl #2
    a0f0:	d37df021 	lsl	x1, x1, #3
    a0f4:	8b010107 	add	x7, x8, x1
    a0f8:	f94010e6 	ldr	x6, [x7, #32]
    a0fc:	b4000206 	cbz	x6, a13c <fwp_hof0.constprop.0+0x3dc>
    a100:	38616901 	ldrb	w1, [x8, x1]
    a104:	7100083f 	cmp	w1, #0x2
    a108:	540004a0 	b.eq	a19c <fwp_hof0.constprop.0+0x43c>  // b.none
    a10c:	7100043f 	cmp	w1, #0x1
    a110:	54000161 	b.ne	a13c <fwp_hof0.constprop.0+0x3dc>  // b.any
    a114:	294304e8 	ldp	w8, w1, [x7, #24]
    a118:	92403c00 	and	x0, x0, #0xffff
    a11c:	9b087c00 	mul	x0, x0, x8
    a120:	d360fc00 	lsr	x0, x0, #32
    a124:	eb01001f 	cmp	x0, x1
    a128:	540000a2 	b.cs	a13c <fwp_hof0.constprop.0+0x3dc>  // b.hs, b.nlast
    a12c:	8b0000c6 	add	x6, x6, x0
    a130:	394000c0 	ldrb	w0, [x6]
    a134:	7100041f 	cmp	w0, #0x1
    a138:	540002e0 	b.eq	a194 <fwp_hof0.constprop.0+0x434>  // b.none
    a13c:	f9400546 	ldr	x6, [x10, #8]
    a140:	aa1803e0 	mov	x0, x24
    a144:	52800021 	mov	w1, #0x1                   	// #1
    a148:	d63f00c0 	blr	x6
    a14c:	f9400ee1 	ldr	x1, [x23, #24]
    a150:	aa1b03e0 	mov	x0, x27
    a154:	f9400021 	ldr	x1, [x1]
    a158:	d63f0020 	blr	x1
    a15c:	aa0003fb 	mov	x27, x0
    a160:	f85d83a0 	ldur	x0, [x29, #-40]
    a164:	9100001f 	mov	sp, x0
    a168:	aa1803e0 	mov	x0, x24
    a16c:	97fff0f9 	bl	6550 <fwp_closure_drop>
    a170:	6b14027f 	cmp	w19, w20
    a174:	54fff3a1 	b.ne	9fe8 <fwp_hof0.constprop.0+0x288>  // b.any
    a178:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a17c:	aa1b03f8 	mov	x24, x27
    a180:	b85c03b9 	ldur	w25, [x29, #-64]
    a184:	6b17033f 	cmp	w25, w23
    a188:	54000443 	b.cc	a210 <fwp_hof0.constprop.0+0x4b0>  // b.lo, b.ul, b.last
    a18c:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    a190:	1400003e 	b	a288 <fwp_hof0.constprop.0+0x528>
    a194:	b900053f 	str	wzr, [x9, #4]
    a198:	17ffffed 	b	a14c <fwp_hof0.constprop.0+0x3ec>
    a19c:	72003c1f 	tst	w0, #0xffff
    a1a0:	54fffce1 	b.ne	a13c <fwp_hof0.constprop.0+0x3dc>  // b.any
    a1a4:	17ffffe3 	b	a130 <fwp_hof0.constprop.0+0x3d0>
    a1a8:	aa1b03fa 	mov	x26, x27
    a1ac:	aa1903fb 	mov	x27, x25
    a1b0:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a1b4:	b85c03b9 	ldur	w25, [x29, #-64]
    a1b8:	aa1a03e0 	mov	x0, x26
    a1bc:	b81d83a6 	stur	w6, [x29, #-40]
    a1c0:	97ffeef4 	bl	5d90 <fwp_rc_share>
    a1c4:	b85d83a6 	ldur	w6, [x29, #-40]
    a1c8:	34000134 	cbz	w20, a1ec <fwp_hof0.constprop.0+0x48c>
    a1cc:	aa1b03f8 	mov	x24, x27
    a1d0:	8b344f73 	add	x19, x27, w20, uxtw #3
    a1d4:	2a0603fc 	mov	w28, w6
    a1d8:	f8408700 	ldr	x0, [x24], #8
    a1dc:	97ffeeed 	bl	5d90 <fwp_rc_share>
    a1e0:	eb18027f 	cmp	x19, x24
    a1e4:	54ffffa1 	b.ne	a1d8 <fwp_hof0.constprop.0+0x478>  // b.any
    a1e8:	2a1c03e6 	mov	w6, w28
    a1ec:	aa1b03e2 	mov	x2, x27
    a1f0:	2a1403e1 	mov	w1, w20
    a1f4:	aa1a03e0 	mov	x0, x26
    a1f8:	b81d83a6 	stur	w6, [x29, #-40]
    a1fc:	97ffec09 	bl	5220 <fwp_apply>
    a200:	aa0003f8 	mov	x24, x0
    a204:	b85d83a6 	ldur	w6, [x29, #-40]
    a208:	6b17033f 	cmp	w25, w23
    a20c:	54fffc02 	b.cs	a18c <fwp_hof0.constprop.0+0x42c>  // b.hs, b.nlast
    a210:	f9408ea1 	ldr	x1, [x21, #280]
    a214:	4b0602f7 	sub	w23, w23, w6
    a218:	b9400304 	ldr	w4, [x24]
    a21c:	f85d03a0 	ldur	x0, [x29, #-48]
    a220:	8b041424 	add	x4, x1, x4, lsl #5
    a224:	b85c83a2 	ldur	w2, [x29, #-56]
    a228:	8b264c00 	add	x0, x0, w6, uxtw #3
    a22c:	f81d03a0 	stur	x0, [x29, #-48]
    a230:	f9400c81 	ldr	x1, [x4, #24]
    a234:	b85cc3a0 	ldur	w0, [x29, #-52]
    a238:	4b020000 	sub	w0, w0, w2
    a23c:	b81cc3a0 	stur	w0, [x29, #-52]
    a240:	aa1803e0 	mov	x0, x24
    a244:	b5ffe801 	cbnz	x1, 9f44 <fwp_hof0.constprop.0+0x1e4>
    a248:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    a24c:	aa1803e0 	mov	x0, x24
    a250:	97ffeed0 	bl	5d90 <fwp_rc_share>
    a254:	34000117 	cbz	w23, a274 <fwp_hof0.constprop.0+0x514>
    a258:	f85d03ba 	ldur	x26, [x29, #-48]
    a25c:	d2800016 	mov	x22, #0x0                   	// #0
    a260:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    a264:	910006d6 	add	x22, x22, #0x1
    a268:	97ffeeca 	bl	5d90 <fwp_rc_share>
    a26c:	6b1602ff 	cmp	w23, w22
    a270:	54ffff88 	b.hi	a260 <fwp_hof0.constprop.0+0x500>  // b.pmore
    a274:	f85d03a2 	ldur	x2, [x29, #-48]
    a278:	aa1803e0 	mov	x0, x24
    a27c:	2a1703e1 	mov	w1, w23
    a280:	97ffebe8 	bl	5220 <fwp_apply>
    a284:	aa0003f8 	mov	x24, x0
    a288:	f85a03a0 	ldur	x0, [x29, #-96]
    a28c:	f1000400 	subs	x0, x0, #0x1
    a290:	f81a03a0 	stur	x0, [x29, #-96]
    a294:	54ffde61 	b.ne	9e60 <fwp_hof0.constprop.0+0x100>  // b.any
    a298:	90000122 	adrp	x2, 2e000 <__FRAME_END__+0x1dc50>
    a29c:	91104042 	add	x2, x2, #0x410
    a2a0:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    a2a4:	aa1803e1 	mov	x1, x24
    a2a8:	aa1403e0 	mov	x0, x20
    a2ac:	aa1803fb 	mov	x27, x24
    a2b0:	91014042 	add	x2, x2, #0x50
    a2b4:	52800023 	mov	w3, #0x1                   	// #1
    a2b8:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    a2bc:	aa1903fc 	mov	x28, x25
    a2c0:	f81f03bf 	stur	xzr, [x29, #-16]
    a2c4:	97fffaab 	bl	8d70 <fwp_write>
    a2c8:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    a2cc:	f0000000 	adrp	x0, d000 <f0+0x2460>
    a2d0:	913cc000 	add	x0, x0, #0xf30
    a2d4:	f10002df 	cmp	x22, #0x0
    a2d8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    a2dc:	b1002b1f 	cmn	x24, #0xa
    a2e0:	54003568 	b.hi	a98c <fwp_hof0.constprop.0+0xc2c>  // b.pmore
    a2e4:	91002700 	add	x0, x24, #0x9
    a2e8:	52800021 	mov	w1, #0x1                   	// #1
    a2ec:	97ffeb69 	bl	5090 <fwp_heap_alloc>
    a2f0:	aa0003f3 	mov	x19, x0
    a2f4:	aa1603e1 	mov	x1, x22
    a2f8:	aa0003f6 	mov	x22, x0
    a2fc:	aa1803e2 	mov	x2, x24
    a300:	f80086d8 	str	x24, [x22], #8
    a304:	8b180278 	add	x24, x19, x24
    a308:	aa1603e0 	mov	x0, x22
    a30c:	97ffe0d5 	bl	2660 <memcpy@plt>
    a310:	3900231f 	strb	wzr, [x24, #8]
    a314:	f85e03a0 	ldur	x0, [x29, #-32]
    a318:	97ffe16e 	bl	28d0 <free@plt>
    a31c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a320:	91190003 	add	x3, x0, #0x640
    a324:	f949ec64 	ldr	x4, [x3, #5080]
    a328:	f949d861 	ldr	x1, [x3, #5040]
    a32c:	d370bc84 	lsl	x4, x4, #16
    a330:	cb010262 	sub	x2, x19, x1
    a334:	eb04005f 	cmp	x2, x4
    a338:	540003c2 	b.cs	a3b0 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    a33c:	d350fc40 	lsr	x0, x2, #16
    a340:	f949fc66 	ldr	x6, [x3, #5112]
    a344:	8b000800 	add	x0, x0, x0, lsl #2
    a348:	d37df003 	lsl	x3, x0, #3
    a34c:	8b0300c0 	add	x0, x6, x3
    a350:	f9401018 	ldr	x24, [x0, #32]
    a354:	b40002f8 	cbz	x24, a3b0 <fwp_hof0.constprop.0+0x650>
    a358:	386368c3 	ldrb	w3, [x6, x3]
    a35c:	7100087f 	cmp	w3, #0x2
    a360:	540031c0 	b.eq	a998 <fwp_hof0.constprop.0+0xc38>  // b.none
    a364:	7100047f 	cmp	w3, #0x1
    a368:	54000241 	b.ne	a3b0 <fwp_hof0.constprop.0+0x650>  // b.any
    a36c:	29430003 	ldp	w3, w0, [x0, #24]
    a370:	92403c42 	and	x2, x2, #0xffff
    a374:	9b037c42 	mul	x2, x2, x3
    a378:	d360fc42 	lsr	x2, x2, #32
    a37c:	eb00005f 	cmp	x2, x0
    a380:	54000182 	b.cs	a3b0 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    a384:	8b020318 	add	x24, x24, x2
    a388:	39400300 	ldrb	w0, [x24]
    a38c:	7103fc1f 	cmp	w0, #0xff
    a390:	54003fa0 	b.eq	ab84 <fwp_hof0.constprop.0+0xe24>  // b.none
    a394:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a398:	91190000 	add	x0, x0, #0x640
    a39c:	52800021 	mov	w1, #0x1                   	// #1
    a3a0:	39000301 	strb	w1, [x24]
    a3a4:	f949ec04 	ldr	x4, [x0, #5080]
    a3a8:	f949d801 	ldr	x1, [x0, #5040]
    a3ac:	d370bc84 	lsl	x4, x4, #16
    a3b0:	cb010361 	sub	x1, x27, x1
    a3b4:	eb01009f 	cmp	x4, x1
    a3b8:	540003c9 	b.ls	a430 <fwp_hof0.constprop.0+0x6d0>  // b.plast
    a3bc:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a3c0:	91190019 	add	x25, x0, #0x640
    a3c4:	d350fc22 	lsr	x2, x1, #16
    a3c8:	f949ff26 	ldr	x6, [x25, #5112]
    a3cc:	8b020842 	add	x2, x2, x2, lsl #2
    a3d0:	d37df042 	lsl	x2, x2, #3
    a3d4:	8b0200c0 	add	x0, x6, x2
    a3d8:	f9401018 	ldr	x24, [x0, #32]
    a3dc:	b40002b8 	cbz	x24, a430 <fwp_hof0.constprop.0+0x6d0>
    a3e0:	386268c2 	ldrb	w2, [x6, x2]
    a3e4:	7100085f 	cmp	w2, #0x2
    a3e8:	54003380 	b.eq	aa58 <fwp_hof0.constprop.0+0xcf8>  // b.none
    a3ec:	7100045f 	cmp	w2, #0x1
    a3f0:	54000201 	b.ne	a430 <fwp_hof0.constprop.0+0x6d0>  // b.any
    a3f4:	29430002 	ldp	w2, w0, [x0, #24]
    a3f8:	92403c21 	and	x1, x1, #0xffff
    a3fc:	9b027c21 	mul	x1, x1, x2
    a400:	d360fc21 	lsr	x1, x1, #32
    a404:	eb00003f 	cmp	x1, x0
    a408:	54000142 	b.cs	a430 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    a40c:	8b010318 	add	x24, x24, x1
    a410:	39400300 	ldrb	w0, [x24]
    a414:	340000e0 	cbz	w0, a430 <fwp_hof0.constprop.0+0x6d0>
    a418:	7100041f 	cmp	w0, #0x1
    a41c:	54002ca0 	b.eq	a9b0 <fwp_hof0.constprop.0+0xc50>  // b.none
    a420:	7103fc1f 	cmp	w0, #0xff
    a424:	54003280 	b.eq	aa74 <fwp_hof0.constprop.0+0xd14>  // b.none
    a428:	51000400 	sub	w0, w0, #0x1
    a42c:	39000300 	strb	w0, [x24]
    a430:	d0000120 	adrp	x0, 30000 <__data_start>
    a434:	91018003 	add	x3, x0, #0x60
    a438:	f9400262 	ldr	x2, [x19]
    a43c:	aa1603e0 	mov	x0, x22
    a440:	aa0303f6 	mov	x22, x3
    a444:	d2800021 	mov	x1, #0x1                   	// #1
    a448:	f9404863 	ldr	x3, [x3, #144]
    a44c:	97ffe131 	bl	2910 <fwrite@plt>
    a450:	f9404ac1 	ldr	x1, [x22, #144]
    a454:	52800140 	mov	w0, #0xa                   	// #10
    a458:	97ffe0b6 	bl	2730 <fputc@plt>
    a45c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a460:	91190002 	add	x2, x0, #0x640
    a464:	f949d841 	ldr	x1, [x2, #5040]
    a468:	f949ec40 	ldr	x0, [x2, #5080]
    a46c:	cb010261 	sub	x1, x19, x1
    a470:	eb00403f 	cmp	x1, x0, lsl #16
    a474:	54000382 	b.cs	a4e4 <fwp_hof0.constprop.0+0x784>  // b.hs, b.nlast
    a478:	d350fc20 	lsr	x0, x1, #16
    a47c:	f949fc43 	ldr	x3, [x2, #5112]
    a480:	8b000800 	add	x0, x0, x0, lsl #2
    a484:	d37df000 	lsl	x0, x0, #3
    a488:	8b000062 	add	x2, x3, x0
    a48c:	f9401056 	ldr	x22, [x2, #32]
    a490:	b40002b6 	cbz	x22, a4e4 <fwp_hof0.constprop.0+0x784>
    a494:	38606860 	ldrb	w0, [x3, x0]
    a498:	7100081f 	cmp	w0, #0x2
    a49c:	54002840 	b.eq	a9a4 <fwp_hof0.constprop.0+0xc44>  // b.none
    a4a0:	7100041f 	cmp	w0, #0x1
    a4a4:	54000201 	b.ne	a4e4 <fwp_hof0.constprop.0+0x784>  // b.any
    a4a8:	29430043 	ldp	w3, w0, [x2, #24]
    a4ac:	92403c21 	and	x1, x1, #0xffff
    a4b0:	9b037c21 	mul	x1, x1, x3
    a4b4:	d360fc21 	lsr	x1, x1, #32
    a4b8:	eb00003f 	cmp	x1, x0
    a4bc:	54000142 	b.cs	a4e4 <fwp_hof0.constprop.0+0x784>  // b.hs, b.nlast
    a4c0:	8b0102d6 	add	x22, x22, x1
    a4c4:	394002c0 	ldrb	w0, [x22]
    a4c8:	340000e0 	cbz	w0, a4e4 <fwp_hof0.constprop.0+0x784>
    a4cc:	7100041f 	cmp	w0, #0x1
    a4d0:	540030c0 	b.eq	aae8 <fwp_hof0.constprop.0+0xd88>  // b.none
    a4d4:	7103fc1f 	cmp	w0, #0xff
    a4d8:	540030e0 	b.eq	aaf4 <fwp_hof0.constprop.0+0xd94>  // b.none
    a4dc:	51000400 	sub	w0, w0, #0x1
    a4e0:	390002c0 	strb	w0, [x22]
    a4e4:	f9400af7 	ldr	x23, [x23, #16]
    a4e8:	b5ffc6b7 	cbnz	x23, 9dbc <fwp_hof0.constprop.0+0x5c>
    a4ec:	b0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    a4f0:	f947f400 	ldr	x0, [x0, #4072]
    a4f4:	f85f83a2 	ldur	x2, [x29, #-8]
    a4f8:	f9400001 	ldr	x1, [x0]
    a4fc:	eb010042 	subs	x2, x2, x1
    a500:	d2800001 	mov	x1, #0x0                   	// #0
    a504:	54002b01 	b.ne	aa64 <fwp_hof0.constprop.0+0xd04>  // b.any
    a508:	910003bf 	mov	sp, x29
    a50c:	d2800000 	mov	x0, #0x0                   	// #0
    a510:	a94153f3 	ldp	x19, x20, [sp, #16]
    a514:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a518:	a94363f7 	ldp	x23, x24, [sp, #48]
    a51c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a520:	a94573fb 	ldp	x27, x28, [sp, #80]
    a524:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a528:	d65f03c0 	ret
    a52c:	b94132ab 	ldr	w11, [x21, #304]
    a530:	11000780 	add	w0, w28, #0x1
    a534:	aa1703e4 	mov	x4, x23
    a538:	aa1903fb 	mov	x27, x25
    a53c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a540:	2a0103fa 	mov	w26, w1
    a544:	b85c03b9 	ldur	w25, [x29, #-64]
    a548:	d37df000 	lsl	x0, x0, #3
    a54c:	340000ab 	cbz	w11, a560 <fwp_hof0.constprop.0+0x800>
    a550:	a95386a2 	ldp	x2, x1, [x21, #312]
    a554:	91000442 	add	x2, x2, #0x1
    a558:	8b000021 	add	x1, x1, x0
    a55c:	a91386a2 	stp	x2, x1, [x21, #312]
    a560:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    a564:	9119002a 	add	x10, x1, #0x640
    a568:	f140101f 	cmp	x0, #0x4, lsl #12
    a56c:	b953a541 	ldr	w1, [x10, #5028]
    a570:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a574:	54001a20 	b.eq	a8b8 <fwp_hof0.constprop.0+0xb58>  // b.none
    a578:	91003c01 	add	x1, x0, #0xf
    a57c:	8b411141 	add	x1, x10, x1, lsr #4
    a580:	397e8021 	ldrb	w1, [x1, #4000]
    a584:	910f002c 	add	x12, x1, #0x3c0
    a588:	8b010422 	add	x2, x1, x1, lsl #1
    a58c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a590:	8b020d4d 	add	x13, x10, x2, lsl #3
    a594:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    a598:	2a0c03e1 	mov	w1, w12
    a59c:	b40017d3 	cbz	x19, a894 <fwp_hof0.constprop.0+0xb34>
    a5a0:	f940026d 	ldr	x13, [x19]
    a5a4:	aa2d03ed 	mvn	x13, x13
    a5a8:	f822794d 	str	x13, [x10, x2, lsl #3]
    a5ac:	eb01001f 	cmp	x0, x1
    a5b0:	540000c2 	b.cs	a5c8 <fwp_hof0.constprop.0+0x868>  // b.hs, b.nlast
    a5b4:	d503201f 	nop
    a5b8:	f8206a7f 	str	xzr, [x19, x0]
    a5bc:	91002000 	add	x0, x0, #0x8
    a5c0:	eb00003f 	cmp	x1, x0
    a5c4:	54ffffa8 	b.hi	a5b8 <fwp_hof0.constprop.0+0x858>  // b.pmore
    a5c8:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a5cc:	91190002 	add	x2, x0, #0x640
    a5d0:	f94a1040 	ldr	x0, [x2, #5152]
    a5d4:	ab010000 	adds	x0, x0, x1
    a5d8:	54002c82 	b.cs	ab68 <fwp_hof0.constprop.0+0xe08>  // b.hs, b.nlast
    a5dc:	f94a1441 	ldr	x1, [x2, #5160]
    a5e0:	f90a1040 	str	x0, [x2, #5152]
    a5e4:	eb01001f 	cmp	x0, x1
    a5e8:	54000049 	b.ls	a5f0 <fwp_hof0.constprop.0+0x890>  // b.plast
    a5ec:	f90a1440 	str	x0, [x2, #5160]
    a5f0:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a5f4:	91190000 	add	x0, x0, #0x640
    a5f8:	1e630181 	ucvtf	d1, w12
    a5fc:	fd4a1c00 	ldr	d0, [x0, #5176]
    a600:	1e612800 	fadd	d0, d0, d1
    a604:	fd0a1c00 	str	d0, [x0, #5176]
    a608:	3400012b 	cbz	w11, a62c <fwp_hof0.constprop.0+0x8cc>
    a60c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a610:	91190000 	add	x0, x0, #0x640
    a614:	6d5486a2 	ldp	d2, d1, [x21, #328]
    a618:	fd4a1000 	ldr	d0, [x0, #5152]
    a61c:	7e61d800 	ucvtf	d0, d0
    a620:	1e623800 	fsub	d0, d0, d2
    a624:	1e612010 	fcmpe	d0, d1
    a628:	5400178c 	b.gt	a918 <fwp_hof0.constprop.0+0xbb8>
    a62c:	b9400120 	ldr	w0, [x9]
    a630:	29007260 	stp	w0, w28, [x19]
    a634:	3400017a 	cbz	w26, a660 <fwp_hof0.constprop.0+0x900>
    a638:	91002121 	add	x1, x9, #0x8
    a63c:	d37d7f42 	ubfiz	x2, x26, #3, #32
    a640:	91002260 	add	x0, x19, #0x8
    a644:	b81bc3a6 	stur	w6, [x29, #-68]
    a648:	f81c03a4 	stur	x4, [x29, #-64]
    a64c:	f81d83a9 	stur	x9, [x29, #-40]
    a650:	97ffe00c 	bl	2680 <memmove@plt>
    a654:	f85c03a4 	ldur	x4, [x29, #-64]
    a658:	f85d83a9 	ldur	x9, [x29, #-40]
    a65c:	b85bc3a6 	ldur	w6, [x29, #-68]
    a660:	2a1403e8 	mov	w8, w20
    a664:	d2800001 	mov	x1, #0x0                   	// #0
    a668:	34000134 	cbz	w20, a68c <fwp_hof0.constprop.0+0x92c>
    a66c:	d503201f 	nop
    a670:	0b010340 	add	w0, w26, w1
    a674:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a678:	8b000e60 	add	x0, x19, x0, lsl #3
    a67c:	91000421 	add	x1, x1, #0x1
    a680:	f9000402 	str	x2, [x0, #8]
    a684:	eb01011f 	cmp	x8, x1
    a688:	54ffff41 	b.ne	a670 <fwp_hof0.constprop.0+0x910>  // b.any
    a68c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a690:	91190002 	add	x2, x0, #0x640
    a694:	f949d840 	ldr	x0, [x2, #5040]
    a698:	f949ec41 	ldr	x1, [x2, #5080]
    a69c:	cb000300 	sub	x0, x24, x0
    a6a0:	eb01401f 	cmp	x0, x1, lsl #16
    a6a4:	540002e2 	b.cs	a700 <fwp_hof0.constprop.0+0x9a0>  // b.hs, b.nlast
    a6a8:	d350fc01 	lsr	x1, x0, #16
    a6ac:	f949fc45 	ldr	x5, [x2, #5112]
    a6b0:	8b010821 	add	x1, x1, x1, lsl #2
    a6b4:	d37df021 	lsl	x1, x1, #3
    a6b8:	8b0100a3 	add	x3, x5, x1
    a6bc:	f9401062 	ldr	x2, [x3, #32]
    a6c0:	b4000202 	cbz	x2, a700 <fwp_hof0.constprop.0+0x9a0>
    a6c4:	386168a1 	ldrb	w1, [x5, x1]
    a6c8:	7100083f 	cmp	w1, #0x2
    a6cc:	540010c0 	b.eq	a8e4 <fwp_hof0.constprop.0+0xb84>  // b.none
    a6d0:	7100043f 	cmp	w1, #0x1
    a6d4:	54000161 	b.ne	a700 <fwp_hof0.constprop.0+0x9a0>  // b.any
    a6d8:	29430465 	ldp	w5, w1, [x3, #24]
    a6dc:	92403c00 	and	x0, x0, #0xffff
    a6e0:	9b057c00 	mul	x0, x0, x5
    a6e4:	d360fc00 	lsr	x0, x0, #32
    a6e8:	eb01001f 	cmp	x0, x1
    a6ec:	540000a2 	b.cs	a700 <fwp_hof0.constprop.0+0x9a0>  // b.hs, b.nlast
    a6f0:	8b000042 	add	x2, x2, x0
    a6f4:	39400040 	ldrb	w0, [x2]
    a6f8:	7100041f 	cmp	w0, #0x1
    a6fc:	54000c20 	b.eq	a880 <fwp_hof0.constprop.0+0xb20>  // b.none
    a700:	f9400c82 	ldr	x2, [x4, #24]
    a704:	aa1803e0 	mov	x0, x24
    a708:	52800021 	mov	w1, #0x1                   	// #1
    a70c:	b81d83a6 	stur	w6, [x29, #-40]
    a710:	f9400442 	ldr	x2, [x2, #8]
    a714:	d63f0040 	blr	x2
    a718:	b85d83a6 	ldur	w6, [x29, #-40]
    a71c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a720:	91190002 	add	x2, x0, #0x640
    a724:	f949d841 	ldr	x1, [x2, #5040]
    a728:	f949ec40 	ldr	x0, [x2, #5080]
    a72c:	cb010261 	sub	x1, x19, x1
    a730:	eb00403f 	cmp	x1, x0, lsl #16
    a734:	54000322 	b.cs	a798 <fwp_hof0.constprop.0+0xa38>  // b.hs, b.nlast
    a738:	d350fc20 	lsr	x0, x1, #16
    a73c:	f949fc43 	ldr	x3, [x2, #5112]
    a740:	8b000800 	add	x0, x0, x0, lsl #2
    a744:	d37df002 	lsl	x2, x0, #3
    a748:	8b020060 	add	x0, x3, x2
    a74c:	f9401014 	ldr	x20, [x0, #32]
    a750:	b4000254 	cbz	x20, a798 <fwp_hof0.constprop.0+0xa38>
    a754:	38626862 	ldrb	w2, [x3, x2]
    a758:	7100085f 	cmp	w2, #0x2
    a75c:	54000ca0 	b.eq	a8f0 <fwp_hof0.constprop.0+0xb90>  // b.none
    a760:	7100045f 	cmp	w2, #0x1
    a764:	540001a1 	b.ne	a798 <fwp_hof0.constprop.0+0xa38>  // b.any
    a768:	29430002 	ldp	w2, w0, [x0, #24]
    a76c:	92403c21 	and	x1, x1, #0xffff
    a770:	9b027c21 	mul	x1, x1, x2
    a774:	d360fc21 	lsr	x1, x1, #32
    a778:	eb00003f 	cmp	x1, x0
    a77c:	540000e2 	b.cs	a798 <fwp_hof0.constprop.0+0xa38>  // b.hs, b.nlast
    a780:	8b010294 	add	x20, x20, x1
    a784:	39400280 	ldrb	w0, [x20]
    a788:	7103fc1f 	cmp	w0, #0xff
    a78c:	54000bc0 	b.eq	a904 <fwp_hof0.constprop.0+0xba4>  // b.none
    a790:	52800020 	mov	w0, #0x1                   	// #1
    a794:	39000280 	strb	w0, [x20]
    a798:	aa1803e0 	mov	x0, x24
    a79c:	b81d83a6 	stur	w6, [x29, #-40]
    a7a0:	97ffef6c 	bl	6550 <fwp_closure_drop>
    a7a4:	aa1303f8 	mov	x24, x19
    a7a8:	b85d83a6 	ldur	w6, [x29, #-40]
    a7ac:	17fffe97 	b	a208 <fwp_hof0.constprop.0+0x4a8>
    a7b0:	b8626860 	ldr	w0, [x3, x2]
    a7b4:	b94004c2 	ldr	w2, [x6, #4]
    a7b8:	4b020003 	sub	w3, w0, w2
    a7bc:	7100047f 	cmp	w3, #0x1
    a7c0:	54ffb681 	b.ne	9e90 <fwp_hof0.constprop.0+0x130>  // b.any
    a7c4:	910003f6 	mov	x22, sp
    a7c8:	34000d22 	cbz	w2, a96c <fwp_hof0.constprop.0+0xc0c>
    a7cc:	7100001f 	cmp	w0, #0x0
    a7d0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a7d4:	d2800101 	mov	x1, #0x8                   	// #8
    a7d8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a7dc:	91003ee0 	add	x0, x23, #0xf
    a7e0:	92704c01 	and	x1, x0, #0xfffff0000
    a7e4:	927c7c00 	and	x0, x0, #0xffffffff0
    a7e8:	cb2163e1 	sub	x1, sp, x1
    a7ec:	eb2163ff 	cmp	sp, x1
    a7f0:	540000a0 	b.eq	a804 <fwp_hof0.constprop.0+0xaa4>  // b.none
    a7f4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a7f8:	f90203ff 	str	xzr, [sp, #1024]
    a7fc:	eb2163ff 	cmp	sp, x1
    a800:	54ffffa1 	b.ne	a7f4 <fwp_hof0.constprop.0+0xa94>  // b.any
    a804:	92403c00 	and	x0, x0, #0xffff
    a808:	cb2063ff 	sub	sp, sp, x0
    a80c:	f90003ff 	str	xzr, [sp]
    a810:	f110001f 	cmp	x0, #0x400
    a814:	54000043 	b.cc	a81c <fwp_hof0.constprop.0+0xabc>  // b.lo, b.ul, b.last
    a818:	f90203ff 	str	xzr, [sp, #1024]
    a81c:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a820:	910043fa 	add	x26, sp, #0x10
    a824:	d0000120 	adrp	x0, 30000 <__data_start>
    a828:	91004001 	add	x1, x0, #0x10
    a82c:	aa1b03e2 	mov	x2, x27
    a830:	9100c021 	add	x1, x1, #0x30
    a834:	aa1703e3 	mov	x3, x23
    a838:	aa1a03e0 	mov	x0, x26
    a83c:	f81d83a4 	stur	x4, [x29, #-40]
    a840:	97ffdfc8 	bl	2760 <__memcpy_chk@plt>
    a844:	eb1b02ff 	cmp	x23, x27
    a848:	aa1403e1 	mov	x1, x20
    a84c:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a850:	d2800102 	mov	x2, #0x8                   	// #8
    a854:	cb1b0063 	sub	x3, x3, x27
    a858:	8b1b0340 	add	x0, x26, x27
    a85c:	97ffdfc1 	bl	2760 <__memcpy_chk@plt>
    a860:	f85d83a4 	ldur	x4, [x29, #-40]
    a864:	aa1a03e0 	mov	x0, x26
    a868:	f9400c81 	ldr	x1, [x4, #24]
    a86c:	f9400021 	ldr	x1, [x1]
    a870:	d63f0020 	blr	x1
    a874:	aa0003f8 	mov	x24, x0
    a878:	910002df 	mov	sp, x22
    a87c:	17fffe83 	b	a288 <fwp_hof0.constprop.0+0x528>
    a880:	b900053f 	str	wzr, [x9, #4]
    a884:	17ffffa6 	b	a71c <fwp_hof0.constprop.0+0x9bc>
    a888:	72003c3f 	tst	w1, #0xffff
    a88c:	54ffb4c1 	b.ne	9f24 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a890:	17fffd9a 	b	9ef8 <fwp_hof0.constprop.0+0x198>
    a894:	f94005b3 	ldr	x19, [x13, #8]
    a898:	b4000113 	cbz	x19, a8b8 <fwp_hof0.constprop.0+0xb58>
    a89c:	f94009a2 	ldr	x2, [x13, #16]
    a8a0:	cb130042 	sub	x2, x2, x19
    a8a4:	eb02003f 	cmp	x1, x2
    a8a8:	54000088 	b.hi	a8b8 <fwp_hof0.constprop.0+0xb58>  // b.pmore
    a8ac:	8b010262 	add	x2, x19, x1
    a8b0:	f90005a2 	str	x2, [x13, #8]
    a8b4:	17ffff3e 	b	a5ac <fwp_hof0.constprop.0+0x84c>
    a8b8:	52800001 	mov	w1, #0x0                   	// #0
    a8bc:	b81bc3a6 	stur	w6, [x29, #-68]
    a8c0:	f81c03a4 	stur	x4, [x29, #-64]
    a8c4:	f81d83a9 	stur	x9, [x29, #-40]
    a8c8:	97ffe9f2 	bl	5090 <fwp_heap_alloc>
    a8cc:	f85c03a4 	ldur	x4, [x29, #-64]
    a8d0:	aa0003f3 	mov	x19, x0
    a8d4:	f85d83a9 	ldur	x9, [x29, #-40]
    a8d8:	b94132ab 	ldr	w11, [x21, #304]
    a8dc:	b85bc3a6 	ldur	w6, [x29, #-68]
    a8e0:	17ffff4a 	b	a608 <fwp_hof0.constprop.0+0x8a8>
    a8e4:	72003c1f 	tst	w0, #0xffff
    a8e8:	54fff0c1 	b.ne	a700 <fwp_hof0.constprop.0+0x9a0>  // b.any
    a8ec:	17ffff82 	b	a6f4 <fwp_hof0.constprop.0+0x994>
    a8f0:	72003c3f 	tst	w1, #0xffff
    a8f4:	54fff521 	b.ne	a798 <fwp_hof0.constprop.0+0xa38>  // b.any
    a8f8:	39400280 	ldrb	w0, [x20]
    a8fc:	7103fc1f 	cmp	w0, #0xff
    a900:	54fff481 	b.ne	a790 <fwp_hof0.constprop.0+0xa30>  // b.any
    a904:	aa1403e0 	mov	x0, x20
    a908:	b81d83a6 	stur	w6, [x29, #-40]
    a90c:	97ffe68a 	bl	4334 <fwp_rc_forget_slot.part.0>
    a910:	b85d83a6 	ldur	w6, [x29, #-40]
    a914:	17ffff9f 	b	a790 <fwp_hof0.constprop.0+0xa30>
    a918:	fd00aaa0 	str	d0, [x21, #336]
    a91c:	17ffff44 	b	a62c <fwp_hof0.constprop.0+0x8cc>
    a920:	72003c5f 	tst	w2, #0xffff
    a924:	54ffa941 	b.ne	9e4c <fwp_hof0.constprop.0+0xec>  // b.any
    a928:	17fffd3f 	b	9e24 <fwp_hof0.constprop.0+0xc4>
    a92c:	f940ac43 	ldr	x3, [x2, #344]
    a930:	91000463 	add	x3, x3, #0x1
    a934:	f900ac43 	str	x3, [x2, #344]
    a938:	17fffd41 	b	9e3c <fwp_hof0.constprop.0+0xdc>
    a93c:	f81d83a4 	stur	x4, [x29, #-40]
    a940:	97ffe791 	bl	4784 <fwp_rc_wide_dup>
    a944:	f85d83a4 	ldur	x4, [x29, #-40]
    a948:	17fffd77 	b	9f24 <fwp_hof0.constprop.0+0x1c4>
    a94c:	aa1903e0 	mov	x0, x25
    a950:	97ffed10 	bl	5d90 <fwp_rc_share>
    a954:	aa1803e0 	mov	x0, x24
    a958:	52800037 	mov	w23, #0x1                   	// #1
    a95c:	97ffed0d 	bl	5d90 <fwp_rc_share>
    a960:	aa1903f8 	mov	x24, x25
    a964:	f81d03b4 	stur	x20, [x29, #-48]
    a968:	17fffe43 	b	a274 <fwp_hof0.constprop.0+0x514>
    a96c:	f9400021 	ldr	x1, [x1]
    a970:	aa1403e0 	mov	x0, x20
    a974:	d63f0020 	blr	x1
    a978:	aa0003f8 	mov	x24, x0
    a97c:	910002df 	mov	sp, x22
    a980:	17fffe42 	b	a288 <fwp_hof0.constprop.0+0x528>
    a984:	97ffe780 	bl	4784 <fwp_rc_wide_dup>
    a988:	17fffd31 	b	9e4c <fwp_hof0.constprop.0+0xec>
    a98c:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    a990:	911b2000 	add	x0, x0, #0x6c8
    a994:	97ffe648 	bl	42b4 <fwp_trap>
    a998:	72003c5f 	tst	w2, #0xffff
    a99c:	54ffd0a1 	b.ne	a3b0 <fwp_hof0.constprop.0+0x650>  // b.any
    a9a0:	17fffe7a 	b	a388 <fwp_hof0.constprop.0+0x628>
    a9a4:	72003c3f 	tst	w1, #0xffff
    a9a8:	54ffd9e1 	b.ne	a4e4 <fwp_hof0.constprop.0+0x784>  // b.any
    a9ac:	17fffec6 	b	a4c4 <fwp_hof0.constprop.0+0x764>
    a9b0:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a9b4:	91190000 	add	x0, x0, #0x640
    a9b8:	f9400b78 	ldr	x24, [x27, #16]
    a9bc:	f949ec03 	ldr	x3, [x0, #5080]
    a9c0:	f949d801 	ldr	x1, [x0, #5040]
    a9c4:	d370bc63 	lsl	x3, x3, #16
    a9c8:	cb010362 	sub	x2, x27, x1
    a9cc:	eb03005f 	cmp	x2, x3
    a9d0:	540003a2 	b.cs	aa44 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    a9d4:	d350fc44 	lsr	x4, x2, #16
    a9d8:	8b040884 	add	x4, x4, x4, lsl #2
    a9dc:	d37df084 	lsl	x4, x4, #3
    a9e0:	8b0400c0 	add	x0, x6, x4
    a9e4:	f9401005 	ldr	x5, [x0, #32]
    a9e8:	b40002e5 	cbz	x5, aa44 <fwp_hof0.constprop.0+0xce4>
    a9ec:	386468c4 	ldrb	w4, [x6, x4]
    a9f0:	7100089f 	cmp	w4, #0x2
    a9f4:	540003a0 	b.eq	aa68 <fwp_hof0.constprop.0+0xd08>  // b.none
    a9f8:	7100049f 	cmp	w4, #0x1
    a9fc:	54000241 	b.ne	aa44 <fwp_hof0.constprop.0+0xce4>  // b.any
    aa00:	29430004 	ldp	w4, w0, [x0, #24]
    aa04:	92403c42 	and	x2, x2, #0xffff
    aa08:	9b047c42 	mul	x2, x2, x4
    aa0c:	d360fc42 	lsr	x2, x2, #32
    aa10:	eb00005f 	cmp	x2, x0
    aa14:	54000182 	b.cs	aa44 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    aa18:	8b0200a5 	add	x5, x5, x2
    aa1c:	394000a0 	ldrb	w0, [x5]
    aa20:	7100041f 	cmp	w0, #0x1
    aa24:	54000101 	b.ne	aa44 <fwp_hof0.constprop.0+0xce4>  // b.any
    aa28:	aa1b03e0 	mov	x0, x27
    aa2c:	97ffe6dd 	bl	45a0 <fwp_mem_free>
    aa30:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    aa34:	91190000 	add	x0, x0, #0x640
    aa38:	f949ec03 	ldr	x3, [x0, #5080]
    aa3c:	f949d801 	ldr	x1, [x0, #5040]
    aa40:	d370bc63 	lsl	x3, x3, #16
    aa44:	cb010301 	sub	x1, x24, x1
    aa48:	eb03003f 	cmp	x1, x3
    aa4c:	54ffcf22 	b.cs	a430 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    aa50:	aa1803fb 	mov	x27, x24
    aa54:	17fffe5c 	b	a3c4 <fwp_hof0.constprop.0+0x664>
    aa58:	72003c3f 	tst	w1, #0xffff
    aa5c:	54ffcea1 	b.ne	a430 <fwp_hof0.constprop.0+0x6d0>  // b.any
    aa60:	17fffe6c 	b	a410 <fwp_hof0.constprop.0+0x6b0>
    aa64:	97ffdf6b 	bl	2810 <__stack_chk_fail@plt>
    aa68:	72003c5f 	tst	w2, #0xffff
    aa6c:	54fffec1 	b.ne	aa44 <fwp_hof0.constprop.0+0xce4>  // b.any
    aa70:	17ffffeb 	b	aa1c <fwp_hof0.constprop.0+0xcbc>
    aa74:	ca584700 	eor	x0, x24, x24, lsr #17
    aa78:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    aa7c:	91190022 	add	x2, x1, #0x640
    aa80:	ca402400 	eor	x0, x0, x0, lsr #9
    aa84:	92401c00 	and	x0, x0, #0xff
    aa88:	910a2401 	add	x1, x0, #0x289
    aa8c:	8b000c40 	add	x0, x2, x0, lsl #3
    aa90:	8b010c41 	add	x1, x2, x1, lsl #3
    aa94:	f94a2400 	ldr	x0, [x0, #5192]
    aa98:	b50000a0 	cbnz	x0, aaac <fwp_hof0.constprop.0+0xd4c>
    aa9c:	14000034 	b	ab6c <fwp_hof0.constprop.0+0xe0c>
    aaa0:	91004001 	add	x1, x0, #0x10
    aaa4:	f9400800 	ldr	x0, [x0, #16]
    aaa8:	b4000620 	cbz	x0, ab6c <fwp_hof0.constprop.0+0xe0c>
    aaac:	f9400002 	ldr	x2, [x0]
    aab0:	eb02031f 	cmp	x24, x2
    aab4:	54ffff61 	b.ne	aaa0 <fwp_hof0.constprop.0+0xd40>  // b.any
    aab8:	f9400021 	ldr	x1, [x1]
    aabc:	f9400420 	ldr	x0, [x1, #8]
    aac0:	d1000400 	sub	x0, x0, #0x1
    aac4:	f9000420 	str	x0, [x1, #8]
    aac8:	f103f81f 	cmp	x0, #0xfe
    aacc:	54ffcb21 	b.ne	a430 <fwp_hof0.constprop.0+0x6d0>  // b.any
    aad0:	39400300 	ldrb	w0, [x24]
    aad4:	7103fc1f 	cmp	w0, #0xff
    aad8:	54000500 	b.eq	ab78 <fwp_hof0.constprop.0+0xe18>  // b.none
    aadc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aae0:	39000300 	strb	w0, [x24]
    aae4:	17fffe53 	b	a430 <fwp_hof0.constprop.0+0x6d0>
    aae8:	aa1303e0 	mov	x0, x19
    aaec:	97ffe6ad 	bl	45a0 <fwp_mem_free>
    aaf0:	17fffe7d 	b	a4e4 <fwp_hof0.constprop.0+0x784>
    aaf4:	ca5646c0 	eor	x0, x22, x22, lsr #17
    aaf8:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    aafc:	91190022 	add	x2, x1, #0x640
    ab00:	ca402400 	eor	x0, x0, x0, lsr #9
    ab04:	92401c00 	and	x0, x0, #0xff
    ab08:	910a2401 	add	x1, x0, #0x289
    ab0c:	8b000c40 	add	x0, x2, x0, lsl #3
    ab10:	8b010c41 	add	x1, x2, x1, lsl #3
    ab14:	f94a2400 	ldr	x0, [x0, #5192]
    ab18:	b50000a0 	cbnz	x0, ab2c <fwp_hof0.constprop.0+0xdcc>
    ab1c:	14000014 	b	ab6c <fwp_hof0.constprop.0+0xe0c>
    ab20:	91004001 	add	x1, x0, #0x10
    ab24:	f9400800 	ldr	x0, [x0, #16]
    ab28:	b4000220 	cbz	x0, ab6c <fwp_hof0.constprop.0+0xe0c>
    ab2c:	f9400002 	ldr	x2, [x0]
    ab30:	eb0202df 	cmp	x22, x2
    ab34:	54ffff61 	b.ne	ab20 <fwp_hof0.constprop.0+0xdc0>  // b.any
    ab38:	f9400021 	ldr	x1, [x1]
    ab3c:	f9400420 	ldr	x0, [x1, #8]
    ab40:	d1000400 	sub	x0, x0, #0x1
    ab44:	f9000420 	str	x0, [x1, #8]
    ab48:	f103f81f 	cmp	x0, #0xfe
    ab4c:	54ffccc1 	b.ne	a4e4 <fwp_hof0.constprop.0+0x784>  // b.any
    ab50:	394002c0 	ldrb	w0, [x22]
    ab54:	7103fc1f 	cmp	w0, #0xff
    ab58:	540001c0 	b.eq	ab90 <fwp_hof0.constprop.0+0xe30>  // b.none
    ab5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ab60:	390002c0 	strb	w0, [x22]
    ab64:	17fffe60 	b	a4e4 <fwp_hof0.constprop.0+0x784>
    ab68:	97ffe162 	bl	30f0 <fwp_heap_oom>
    ab6c:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x110>
    ab70:	91092000 	add	x0, x0, #0x248
    ab74:	97ffe5d0 	bl	42b4 <fwp_trap>
    ab78:	aa1803e0 	mov	x0, x24
    ab7c:	97ffe5ee 	bl	4334 <fwp_rc_forget_slot.part.0>
    ab80:	17ffffd7 	b	aadc <fwp_hof0.constprop.0+0xd7c>
    ab84:	aa1803e0 	mov	x0, x24
    ab88:	97ffe5eb 	bl	4334 <fwp_rc_forget_slot.part.0>
    ab8c:	17fffe02 	b	a394 <fwp_hof0.constprop.0+0x634>
    ab90:	aa1603e0 	mov	x0, x22
    ab94:	97ffe5e8 	bl	4334 <fwp_rc_forget_slot.part.0>
    ab98:	17fffff1 	b	ab5c <fwp_hof0.constprop.0+0xdfc>
    ab9c:	d503201f 	nop

000000000000aba0 <f0>:
    aba0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    aba4:	910003fd 	mov	x29, sp
    aba8:	a90153f3 	stp	x19, x20, [sp, #16]
    abac:	a9025bf5 	stp	x21, x22, [sp, #32]
    abb0:	a90363f7 	stp	x23, x24, [sp, #48]
    abb4:	a9046bf9 	stp	x25, x26, [sp, #64]
    abb8:	a90573fb 	stp	x27, x28, [sp, #80]
    abbc:	d121c3ff 	sub	sp, sp, #0x870
    abc0:	f90203ff 	str	xzr, [sp, #1024]
    abc4:	d0000120 	adrp	x0, 30000 <__data_start>
    abc8:	91018003 	add	x3, x0, #0x60
    abcc:	b0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    abd0:	f947f400 	ldr	x0, [x0, #4072]
    abd4:	f00003f4 	adrp	x20, 89000 <fwp_root_context+0xba0>
    abd8:	f941c865 	ldr	x5, [x3, #912]
    abdc:	f9400001 	ldr	x1, [x0]
    abe0:	f90437e1 	str	x1, [sp, #2152]
    abe4:	d2800001 	mov	x1, #0x0                   	// #0
    abe8:	91190299 	add	x25, x20, #0x640
    abec:	912163f6 	add	x22, sp, #0x858
    abf0:	910063e4 	add	x4, sp, #0x18
    abf4:	9100c3e1 	add	x1, sp, #0x30
    abf8:	90ffffe0 	adrp	x0, 6000 <fwp_rc_dup+0x9c>
    abfc:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    ac00:	910f8000 	add	x0, x0, #0x3e0
    ac04:	913b4042 	add	x2, x2, #0xed0
    ac08:	d2800013 	mov	x19, #0x0                   	// #0
    ac0c:	d280011a 	mov	x26, #0x8                   	// #8
    ac10:	d2800015 	mov	x21, #0x0                   	// #0
    ac14:	52800037 	mov	w23, #0x1                   	// #1
    ac18:	f90007e4 	str	x4, [sp, #8]
    ac1c:	a9018be5 	stp	x5, x2, [sp, #24]
    ac20:	a902ffe1 	stp	x1, xzr, [sp, #40]
    ac24:	a90403ff 	stp	xzr, x0, [sp, #64]
    ac28:	f901c864 	str	x4, [x3, #912]
    ac2c:	d503201f 	nop
    ac30:	f100075b 	subs	x27, x26, #0x1
    ac34:	aa1603e1 	mov	x1, x22
    ac38:	da1f02b8 	sbc	x24, x21, xzr
    ac3c:	52800020 	mov	w0, #0x1                   	// #1
    ac40:	f9001ffb 	str	x27, [sp, #56]
    ac44:	aa1b03fa 	mov	x26, x27
    ac48:	f9042ffb 	str	x27, [sp, #2136]
    ac4c:	aa1803f5 	mov	x21, x24
    ac50:	f90433f3 	str	x19, [sp, #2144]
    ac54:	97ffebef 	bl	5c10 <fwp_data.part.0.constprop.0>
    ac58:	f949db22 	ldr	x2, [x25, #5040]
    ac5c:	aa0003f3 	mov	x19, x0
    ac60:	f949ef20 	ldr	x0, [x25, #5080]
    ac64:	cb020262 	sub	x2, x19, x2
    ac68:	eb00405f 	cmp	x2, x0, lsl #16
    ac6c:	54000302 	b.cs	accc <f0+0x12c>  // b.hs, b.nlast
    ac70:	d350fc40 	lsr	x0, x2, #16
    ac74:	f949ff25 	ldr	x5, [x25, #5112]
    ac78:	8b000800 	add	x0, x0, x0, lsl #2
    ac7c:	d37df001 	lsl	x1, x0, #3
    ac80:	8b0100a0 	add	x0, x5, x1
    ac84:	f940101c 	ldr	x28, [x0, #32]
    ac88:	b400023c 	cbz	x28, accc <f0+0x12c>
    ac8c:	386168a1 	ldrb	w1, [x5, x1]
    ac90:	7100083f 	cmp	w1, #0x2
    ac94:	54010f60 	b.eq	ce80 <f0+0x22e0>  // b.none
    ac98:	7100043f 	cmp	w1, #0x1
    ac9c:	54000181 	b.ne	accc <f0+0x12c>  // b.any
    aca0:	29430001 	ldp	w1, w0, [x0, #24]
    aca4:	92403c42 	and	x2, x2, #0xffff
    aca8:	9b017c42 	mul	x2, x2, x1
    acac:	d360fc42 	lsr	x2, x2, #32
    acb0:	eb00005f 	cmp	x2, x0
    acb4:	540000c2 	b.cs	accc <f0+0x12c>  // b.hs, b.nlast
    acb8:	8b02039c 	add	x28, x28, x2
    acbc:	39400380 	ldrb	w0, [x28]
    acc0:	7103fc1f 	cmp	w0, #0xff
    acc4:	54010d80 	b.eq	ce74 <f0+0x22d4>  // b.none
    acc8:	39000397 	strb	w23, [x28]
    accc:	a9037ff3 	stp	x19, xzr, [sp, #48]
    acd0:	aa18037b 	orr	x27, x27, x24
    acd4:	b5fffafb 	cbnz	x27, ac30 <f0+0x90>
    acd8:	d0000120 	adrp	x0, 30000 <__data_start>
    acdc:	91018018 	add	x24, x0, #0x60
    ace0:	f94007e1 	ldr	x1, [sp, #8]
    ace4:	f9001bff 	str	xzr, [sp, #48]
    ace8:	f941cb00 	ldr	x0, [x24, #912]
    acec:	eb01001f 	cmp	x0, x1
    acf0:	54012a41 	b.ne	d238 <f0+0x2698>  // b.any
    acf4:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x110>
    acf8:	910143e1 	add	x1, sp, #0x50
    acfc:	f9400fe2 	ldr	x2, [sp, #24]
    ad00:	52800020 	mov	w0, #0x1                   	// #1
    ad04:	3dc3ac60 	ldr	q0, [x3, #3760]
    ad08:	f901cb02 	str	x2, [x24, #912]
    ad0c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ad10:	3d8017e0 	str	q0, [sp, #80]
    ad14:	97ffebbf 	bl	5c10 <fwp_data.part.0.constprop.0>
    ad18:	97ffec42 	bl	5e20 <fwp_rc_fresh>
    ad1c:	9101a3e1 	add	x1, sp, #0x68
    ad20:	aa0003e2 	mov	x2, x0
    ad24:	52800020 	mov	w0, #0x1                   	// #1
    ad28:	a9068bf5 	stp	x21, x2, [sp, #104]
    ad2c:	97ffebb9 	bl	5c10 <fwp_data.part.0.constprop.0>
    ad30:	97ffec3c 	bl	5e20 <fwp_rc_fresh>
    ad34:	aa0003e2 	mov	x2, x0
    ad38:	9101e3e1 	add	x1, sp, #0x78
    ad3c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad40:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad44:	52800020 	mov	w0, #0x1                   	// #1
    ad48:	a9078be3 	stp	x3, x2, [sp, #120]
    ad4c:	97ffebb1 	bl	5c10 <fwp_data.part.0.constprop.0>
    ad50:	97ffec34 	bl	5e20 <fwp_rc_fresh>
    ad54:	aa0003e2 	mov	x2, x0
    ad58:	910223e1 	add	x1, sp, #0x88
    ad5c:	52800020 	mov	w0, #0x1                   	// #1
    ad60:	a9088bf5 	stp	x21, x2, [sp, #136]
    ad64:	97ffebab 	bl	5c10 <fwp_data.part.0.constprop.0>
    ad68:	97ffec2e 	bl	5e20 <fwp_rc_fresh>
    ad6c:	aa0003e2 	mov	x2, x0
    ad70:	910263e1 	add	x1, sp, #0x98
    ad74:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad78:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	a9098be3 	stp	x3, x2, [sp, #152]
    ad84:	97ffeba3 	bl	5c10 <fwp_data.part.0.constprop.0>
    ad88:	97ffec26 	bl	5e20 <fwp_rc_fresh>
    ad8c:	aa0003e2 	mov	x2, x0
    ad90:	9102a3e1 	add	x1, sp, #0xa8
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	a90a8bf5 	stp	x21, x2, [sp, #168]
    ad9c:	97ffeb9d 	bl	5c10 <fwp_data.part.0.constprop.0>
    ada0:	97ffec20 	bl	5e20 <fwp_rc_fresh>
    ada4:	aa0003e2 	mov	x2, x0
    ada8:	9102e3e1 	add	x1, sp, #0xb8
    adac:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    adb0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adb4:	52800020 	mov	w0, #0x1                   	// #1
    adb8:	a90b8be3 	stp	x3, x2, [sp, #184]
    adbc:	97ffeb95 	bl	5c10 <fwp_data.part.0.constprop.0>
    adc0:	97ffec18 	bl	5e20 <fwp_rc_fresh>
    adc4:	aa0003e2 	mov	x2, x0
    adc8:	910323e1 	add	x1, sp, #0xc8
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	a90c8bf5 	stp	x21, x2, [sp, #200]
    add4:	97ffeb8f 	bl	5c10 <fwp_data.part.0.constprop.0>
    add8:	97ffec12 	bl	5e20 <fwp_rc_fresh>
    addc:	aa0003e2 	mov	x2, x0
    ade0:	910363e1 	add	x1, sp, #0xd8
    ade4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ade8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adec:	52800020 	mov	w0, #0x1                   	// #1
    adf0:	a90d8be3 	stp	x3, x2, [sp, #216]
    adf4:	97ffeb87 	bl	5c10 <fwp_data.part.0.constprop.0>
    adf8:	97ffec0a 	bl	5e20 <fwp_rc_fresh>
    adfc:	aa0003e2 	mov	x2, x0
    ae00:	9103a3e1 	add	x1, sp, #0xe8
    ae04:	52800020 	mov	w0, #0x1                   	// #1
    ae08:	a90e8bf5 	stp	x21, x2, [sp, #232]
    ae0c:	97ffeb81 	bl	5c10 <fwp_data.part.0.constprop.0>
    ae10:	97ffec04 	bl	5e20 <fwp_rc_fresh>
    ae14:	aa0003e2 	mov	x2, x0
    ae18:	9103e3e1 	add	x1, sp, #0xf8
    ae1c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae20:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae24:	52800020 	mov	w0, #0x1                   	// #1
    ae28:	a90f8be3 	stp	x3, x2, [sp, #248]
    ae2c:	97ffeb79 	bl	5c10 <fwp_data.part.0.constprop.0>
    ae30:	97ffebfc 	bl	5e20 <fwp_rc_fresh>
    ae34:	aa0003e2 	mov	x2, x0
    ae38:	910423e1 	add	x1, sp, #0x108
    ae3c:	52800020 	mov	w0, #0x1                   	// #1
    ae40:	a9108bf5 	stp	x21, x2, [sp, #264]
    ae44:	97ffeb73 	bl	5c10 <fwp_data.part.0.constprop.0>
    ae48:	97ffebf6 	bl	5e20 <fwp_rc_fresh>
    ae4c:	aa0003e2 	mov	x2, x0
    ae50:	910463e1 	add	x1, sp, #0x118
    ae54:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae58:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	a9118be3 	stp	x3, x2, [sp, #280]
    ae64:	97ffeb6b 	bl	5c10 <fwp_data.part.0.constprop.0>
    ae68:	97ffebee 	bl	5e20 <fwp_rc_fresh>
    ae6c:	aa0003e2 	mov	x2, x0
    ae70:	9104a3e1 	add	x1, sp, #0x128
    ae74:	52800020 	mov	w0, #0x1                   	// #1
    ae78:	a9128bf5 	stp	x21, x2, [sp, #296]
    ae7c:	97ffeb65 	bl	5c10 <fwp_data.part.0.constprop.0>
    ae80:	97ffebe8 	bl	5e20 <fwp_rc_fresh>
    ae84:	aa0003e2 	mov	x2, x0
    ae88:	9104e3e1 	add	x1, sp, #0x138
    ae8c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae90:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae94:	52800020 	mov	w0, #0x1                   	// #1
    ae98:	a9138be3 	stp	x3, x2, [sp, #312]
    ae9c:	97ffeb5d 	bl	5c10 <fwp_data.part.0.constprop.0>
    aea0:	97ffebe0 	bl	5e20 <fwp_rc_fresh>
    aea4:	aa0003e2 	mov	x2, x0
    aea8:	910523e1 	add	x1, sp, #0x148
    aeac:	52800020 	mov	w0, #0x1                   	// #1
    aeb0:	a9148bf5 	stp	x21, x2, [sp, #328]
    aeb4:	97ffeb57 	bl	5c10 <fwp_data.part.0.constprop.0>
    aeb8:	97ffebda 	bl	5e20 <fwp_rc_fresh>
    aebc:	aa0003e2 	mov	x2, x0
    aec0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aec4:	910563e1 	add	x1, sp, #0x158
    aec8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aecc:	52800020 	mov	w0, #0x1                   	// #1
    aed0:	a9158be3 	stp	x3, x2, [sp, #344]
    aed4:	97ffeb4f 	bl	5c10 <fwp_data.part.0.constprop.0>
    aed8:	97ffebd2 	bl	5e20 <fwp_rc_fresh>
    aedc:	aa0003e2 	mov	x2, x0
    aee0:	9105a3e1 	add	x1, sp, #0x168
    aee4:	52800020 	mov	w0, #0x1                   	// #1
    aee8:	a9168bf5 	stp	x21, x2, [sp, #360]
    aeec:	97ffeb49 	bl	5c10 <fwp_data.part.0.constprop.0>
    aef0:	91190283 	add	x3, x20, #0x640
    aef4:	aa0003f5 	mov	x21, x0
    aef8:	f949d861 	ldr	x1, [x3, #5040]
    aefc:	f949ec60 	ldr	x0, [x3, #5080]
    af00:	cb0102a1 	sub	x1, x21, x1
    af04:	eb00403f 	cmp	x1, x0, lsl #16
    af08:	54000322 	b.cs	af6c <f0+0x3cc>  // b.hs, b.nlast
    af0c:	d350fc22 	lsr	x2, x1, #16
    af10:	f949fc63 	ldr	x3, [x3, #5112]
    af14:	8b020842 	add	x2, x2, x2, lsl #2
    af18:	d37df042 	lsl	x2, x2, #3
    af1c:	8b020060 	add	x0, x3, x2
    af20:	f9401017 	ldr	x23, [x0, #32]
    af24:	b4000257 	cbz	x23, af6c <f0+0x3cc>
    af28:	38626862 	ldrb	w2, [x3, x2]
    af2c:	7100085f 	cmp	w2, #0x2
    af30:	5400fae0 	b.eq	ce8c <f0+0x22ec>  // b.none
    af34:	7100045f 	cmp	w2, #0x1
    af38:	540001a1 	b.ne	af6c <f0+0x3cc>  // b.any
    af3c:	29430002 	ldp	w2, w0, [x0, #24]
    af40:	92403c21 	and	x1, x1, #0xffff
    af44:	9b027c21 	mul	x1, x1, x2
    af48:	d360fc21 	lsr	x1, x1, #32
    af4c:	eb00003f 	cmp	x1, x0
    af50:	540000e2 	b.cs	af6c <f0+0x3cc>  // b.hs, b.nlast
    af54:	8b0102f7 	add	x23, x23, x1
    af58:	394002e0 	ldrb	w0, [x23]
    af5c:	7103fc1f 	cmp	w0, #0xff
    af60:	54010860 	b.eq	d06c <f0+0x24cc>  // b.none
    af64:	52800020 	mov	w0, #0x1                   	// #1
    af68:	390002e0 	strb	w0, [x23]
    af6c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af70:	9105e3e1 	add	x1, sp, #0x178
    af74:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af78:	52800020 	mov	w0, #0x1                   	// #1
    af7c:	a917d7e2 	stp	x2, x21, [sp, #376]
    af80:	97ffeb24 	bl	5c10 <fwp_data.part.0.constprop.0>
    af84:	91190283 	add	x3, x20, #0x640
    af88:	aa0003f5 	mov	x21, x0
    af8c:	f949d861 	ldr	x1, [x3, #5040]
    af90:	f949ec60 	ldr	x0, [x3, #5080]
    af94:	cb0102a1 	sub	x1, x21, x1
    af98:	eb00403f 	cmp	x1, x0, lsl #16
    af9c:	54000322 	b.cs	b000 <f0+0x460>  // b.hs, b.nlast
    afa0:	d350fc22 	lsr	x2, x1, #16
    afa4:	f949fc63 	ldr	x3, [x3, #5112]
    afa8:	8b020842 	add	x2, x2, x2, lsl #2
    afac:	d37df042 	lsl	x2, x2, #3
    afb0:	8b020060 	add	x0, x3, x2
    afb4:	f9401017 	ldr	x23, [x0, #32]
    afb8:	b4000257 	cbz	x23, b000 <f0+0x460>
    afbc:	38626862 	ldrb	w2, [x3, x2]
    afc0:	7100085f 	cmp	w2, #0x2
    afc4:	5400f700 	b.eq	cea4 <f0+0x2304>  // b.none
    afc8:	7100045f 	cmp	w2, #0x1
    afcc:	540001a1 	b.ne	b000 <f0+0x460>  // b.any
    afd0:	29430002 	ldp	w2, w0, [x0, #24]
    afd4:	92403c21 	and	x1, x1, #0xffff
    afd8:	9b027c21 	mul	x1, x1, x2
    afdc:	d360fc21 	lsr	x1, x1, #32
    afe0:	eb00003f 	cmp	x1, x0
    afe4:	540000e2 	b.cs	b000 <f0+0x460>  // b.hs, b.nlast
    afe8:	8b0102f7 	add	x23, x23, x1
    afec:	394002e0 	ldrb	w0, [x23]
    aff0:	7103fc1f 	cmp	w0, #0xff
    aff4:	54010420 	b.eq	d078 <f0+0x24d8>  // b.none
    aff8:	52800020 	mov	w0, #0x1                   	// #1
    affc:	390002e0 	strb	w0, [x23]
    b000:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b004:	910623e1 	add	x1, sp, #0x188
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	a918d7e2 	stp	x2, x21, [sp, #392]
    b010:	97ffeb00 	bl	5c10 <fwp_data.part.0.constprop.0>
    b014:	91190283 	add	x3, x20, #0x640
    b018:	aa0003f5 	mov	x21, x0
    b01c:	f949d861 	ldr	x1, [x3, #5040]
    b020:	f949ec60 	ldr	x0, [x3, #5080]
    b024:	cb0102a1 	sub	x1, x21, x1
    b028:	eb00403f 	cmp	x1, x0, lsl #16
    b02c:	54000322 	b.cs	b090 <f0+0x4f0>  // b.hs, b.nlast
    b030:	d350fc22 	lsr	x2, x1, #16
    b034:	f949fc63 	ldr	x3, [x3, #5112]
    b038:	8b020842 	add	x2, x2, x2, lsl #2
    b03c:	d37df042 	lsl	x2, x2, #3
    b040:	8b020060 	add	x0, x3, x2
    b044:	f9401017 	ldr	x23, [x0, #32]
    b048:	b4000257 	cbz	x23, b090 <f0+0x4f0>
    b04c:	38626862 	ldrb	w2, [x3, x2]
    b050:	7100085f 	cmp	w2, #0x2
    b054:	5400f220 	b.eq	ce98 <f0+0x22f8>  // b.none
    b058:	7100045f 	cmp	w2, #0x1
    b05c:	540001a1 	b.ne	b090 <f0+0x4f0>  // b.any
    b060:	29430002 	ldp	w2, w0, [x0, #24]
    b064:	92403c21 	and	x1, x1, #0xffff
    b068:	9b027c21 	mul	x1, x1, x2
    b06c:	d360fc21 	lsr	x1, x1, #32
    b070:	eb00003f 	cmp	x1, x0
    b074:	540000e2 	b.cs	b090 <f0+0x4f0>  // b.hs, b.nlast
    b078:	8b0102f7 	add	x23, x23, x1
    b07c:	394002e0 	ldrb	w0, [x23]
    b080:	7103fc1f 	cmp	w0, #0xff
    b084:	54010000 	b.eq	d084 <f0+0x24e4>  // b.none
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	390002e0 	strb	w0, [x23]
    b090:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b094:	910663e1 	add	x1, sp, #0x198
    b098:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b09c:	52800020 	mov	w0, #0x1                   	// #1
    b0a0:	a919d7e2 	stp	x2, x21, [sp, #408]
    b0a4:	97ffeadb 	bl	5c10 <fwp_data.part.0.constprop.0>
    b0a8:	97ffeb5e 	bl	5e20 <fwp_rc_fresh>
    b0ac:	aa0003e2 	mov	x2, x0
    b0b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0b4:	9106a3e1 	add	x1, sp, #0x1a8
    b0b8:	52800020 	mov	w0, #0x1                   	// #1
    b0bc:	a91a8be3 	stp	x3, x2, [sp, #424]
    b0c0:	97ffead4 	bl	5c10 <fwp_data.part.0.constprop.0>
    b0c4:	91190283 	add	x3, x20, #0x640
    b0c8:	aa0003f5 	mov	x21, x0
    b0cc:	f949d861 	ldr	x1, [x3, #5040]
    b0d0:	f949ec60 	ldr	x0, [x3, #5080]
    b0d4:	cb0102a1 	sub	x1, x21, x1
    b0d8:	eb00403f 	cmp	x1, x0, lsl #16
    b0dc:	54000322 	b.cs	b140 <f0+0x5a0>  // b.hs, b.nlast
    b0e0:	d350fc22 	lsr	x2, x1, #16
    b0e4:	f949fc63 	ldr	x3, [x3, #5112]
    b0e8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ec:	d37df042 	lsl	x2, x2, #3
    b0f0:	8b020060 	add	x0, x3, x2
    b0f4:	f9401017 	ldr	x23, [x0, #32]
    b0f8:	b4000257 	cbz	x23, b140 <f0+0x5a0>
    b0fc:	38626862 	ldrb	w2, [x3, x2]
    b100:	7100085f 	cmp	w2, #0x2
    b104:	5400edc0 	b.eq	cebc <f0+0x231c>  // b.none
    b108:	7100045f 	cmp	w2, #0x1
    b10c:	540001a1 	b.ne	b140 <f0+0x5a0>  // b.any
    b110:	29430002 	ldp	w2, w0, [x0, #24]
    b114:	92403c21 	and	x1, x1, #0xffff
    b118:	9b027c21 	mul	x1, x1, x2
    b11c:	d360fc21 	lsr	x1, x1, #32
    b120:	eb00003f 	cmp	x1, x0
    b124:	540000e2 	b.cs	b140 <f0+0x5a0>  // b.hs, b.nlast
    b128:	8b0102f7 	add	x23, x23, x1
    b12c:	394002e0 	ldrb	w0, [x23]
    b130:	7103fc1f 	cmp	w0, #0xff
    b134:	5400fae0 	b.eq	d090 <f0+0x24f0>  // b.none
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	390002e0 	strb	w0, [x23]
    b140:	9106e3e1 	add	x1, sp, #0x1b8
    b144:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b148:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b14c:	52800020 	mov	w0, #0x1                   	// #1
    b150:	a91bd7f7 	stp	x23, x21, [sp, #440]
    b154:	97ffeaaf 	bl	5c10 <fwp_data.part.0.constprop.0>
    b158:	97ffeb32 	bl	5e20 <fwp_rc_fresh>
    b15c:	aa0003e2 	mov	x2, x0
    b160:	910723e1 	add	x1, sp, #0x1c8
    b164:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b168:	52800020 	mov	w0, #0x1                   	// #1
    b16c:	a91c8bf5 	stp	x21, x2, [sp, #456]
    b170:	97ffeaa8 	bl	5c10 <fwp_data.part.0.constprop.0>
    b174:	97ffeb2b 	bl	5e20 <fwp_rc_fresh>
    b178:	aa0003e2 	mov	x2, x0
    b17c:	910763e1 	add	x1, sp, #0x1d8
    b180:	52800020 	mov	w0, #0x1                   	// #1
    b184:	a91d8bf7 	stp	x23, x2, [sp, #472]
    b188:	97ffeaa2 	bl	5c10 <fwp_data.part.0.constprop.0>
    b18c:	97ffeb25 	bl	5e20 <fwp_rc_fresh>
    b190:	aa0003e2 	mov	x2, x0
    b194:	9107a3e1 	add	x1, sp, #0x1e8
    b198:	52800020 	mov	w0, #0x1                   	// #1
    b19c:	a91e8bf5 	stp	x21, x2, [sp, #488]
    b1a0:	97ffea9c 	bl	5c10 <fwp_data.part.0.constprop.0>
    b1a4:	91190283 	add	x3, x20, #0x640
    b1a8:	aa0003f5 	mov	x21, x0
    b1ac:	f949d861 	ldr	x1, [x3, #5040]
    b1b0:	f949ec60 	ldr	x0, [x3, #5080]
    b1b4:	cb0102a1 	sub	x1, x21, x1
    b1b8:	eb00403f 	cmp	x1, x0, lsl #16
    b1bc:	54000322 	b.cs	b220 <f0+0x680>  // b.hs, b.nlast
    b1c0:	d350fc22 	lsr	x2, x1, #16
    b1c4:	f949fc63 	ldr	x3, [x3, #5112]
    b1c8:	8b020842 	add	x2, x2, x2, lsl #2
    b1cc:	d37df042 	lsl	x2, x2, #3
    b1d0:	8b020060 	add	x0, x3, x2
    b1d4:	f9401017 	ldr	x23, [x0, #32]
    b1d8:	b4000257 	cbz	x23, b220 <f0+0x680>
    b1dc:	38626862 	ldrb	w2, [x3, x2]
    b1e0:	7100085f 	cmp	w2, #0x2
    b1e4:	5400e660 	b.eq	ceb0 <f0+0x2310>  // b.none
    b1e8:	7100045f 	cmp	w2, #0x1
    b1ec:	540001a1 	b.ne	b220 <f0+0x680>  // b.any
    b1f0:	29430002 	ldp	w2, w0, [x0, #24]
    b1f4:	92403c21 	and	x1, x1, #0xffff
    b1f8:	9b027c21 	mul	x1, x1, x2
    b1fc:	d360fc21 	lsr	x1, x1, #32
    b200:	eb00003f 	cmp	x1, x0
    b204:	540000e2 	b.cs	b220 <f0+0x680>  // b.hs, b.nlast
    b208:	8b0102f7 	add	x23, x23, x1
    b20c:	394002e0 	ldrb	w0, [x23]
    b210:	7103fc1f 	cmp	w0, #0xff
    b214:	5400f440 	b.eq	d09c <f0+0x24fc>  // b.none
    b218:	52800020 	mov	w0, #0x1                   	// #1
    b21c:	390002e0 	strb	w0, [x23]
    b220:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b224:	9107e3e1 	add	x1, sp, #0x1f8
    b228:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b22c:	52800020 	mov	w0, #0x1                   	// #1
    b230:	a91fd7e2 	stp	x2, x21, [sp, #504]
    b234:	97ffea77 	bl	5c10 <fwp_data.part.0.constprop.0>
    b238:	91190283 	add	x3, x20, #0x640
    b23c:	aa0003f5 	mov	x21, x0
    b240:	f949d861 	ldr	x1, [x3, #5040]
    b244:	f949ec60 	ldr	x0, [x3, #5080]
    b248:	cb0102a1 	sub	x1, x21, x1
    b24c:	eb00403f 	cmp	x1, x0, lsl #16
    b250:	54000322 	b.cs	b2b4 <f0+0x714>  // b.hs, b.nlast
    b254:	d350fc22 	lsr	x2, x1, #16
    b258:	f949fc63 	ldr	x3, [x3, #5112]
    b25c:	8b020842 	add	x2, x2, x2, lsl #2
    b260:	d37df042 	lsl	x2, x2, #3
    b264:	8b020060 	add	x0, x3, x2
    b268:	f9401017 	ldr	x23, [x0, #32]
    b26c:	b4000257 	cbz	x23, b2b4 <f0+0x714>
    b270:	38626862 	ldrb	w2, [x3, x2]
    b274:	7100085f 	cmp	w2, #0x2
    b278:	5400e2e0 	b.eq	ced4 <f0+0x2334>  // b.none
    b27c:	7100045f 	cmp	w2, #0x1
    b280:	540001a1 	b.ne	b2b4 <f0+0x714>  // b.any
    b284:	29430002 	ldp	w2, w0, [x0, #24]
    b288:	92403c21 	and	x1, x1, #0xffff
    b28c:	9b027c21 	mul	x1, x1, x2
    b290:	d360fc21 	lsr	x1, x1, #32
    b294:	eb00003f 	cmp	x1, x0
    b298:	540000e2 	b.cs	b2b4 <f0+0x714>  // b.hs, b.nlast
    b29c:	8b0102f7 	add	x23, x23, x1
    b2a0:	394002e0 	ldrb	w0, [x23]
    b2a4:	7103fc1f 	cmp	w0, #0xff
    b2a8:	5400f000 	b.eq	d0a8 <f0+0x2508>  // b.none
    b2ac:	52800020 	mov	w0, #0x1                   	// #1
    b2b0:	390002e0 	strb	w0, [x23]
    b2b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2b8:	910823e1 	add	x1, sp, #0x208
    b2bc:	52800020 	mov	w0, #0x1                   	// #1
    b2c0:	f90107e2 	str	x2, [sp, #520]
    b2c4:	f9010bf5 	str	x21, [sp, #528]
    b2c8:	97ffea52 	bl	5c10 <fwp_data.part.0.constprop.0>
    b2cc:	91190283 	add	x3, x20, #0x640
    b2d0:	aa0003f7 	mov	x23, x0
    b2d4:	f949d861 	ldr	x1, [x3, #5040]
    b2d8:	f949ec60 	ldr	x0, [x3, #5080]
    b2dc:	cb0102e1 	sub	x1, x23, x1
    b2e0:	eb00403f 	cmp	x1, x0, lsl #16
    b2e4:	54000322 	b.cs	b348 <f0+0x7a8>  // b.hs, b.nlast
    b2e8:	d350fc22 	lsr	x2, x1, #16
    b2ec:	f949fc63 	ldr	x3, [x3, #5112]
    b2f0:	8b020842 	add	x2, x2, x2, lsl #2
    b2f4:	d37df042 	lsl	x2, x2, #3
    b2f8:	8b020060 	add	x0, x3, x2
    b2fc:	f9401015 	ldr	x21, [x0, #32]
    b300:	b4000255 	cbz	x21, b348 <f0+0x7a8>
    b304:	38626862 	ldrb	w2, [x3, x2]
    b308:	7100085f 	cmp	w2, #0x2
    b30c:	5400dde0 	b.eq	cec8 <f0+0x2328>  // b.none
    b310:	7100045f 	cmp	w2, #0x1
    b314:	540001a1 	b.ne	b348 <f0+0x7a8>  // b.any
    b318:	29430002 	ldp	w2, w0, [x0, #24]
    b31c:	92403c21 	and	x1, x1, #0xffff
    b320:	9b027c21 	mul	x1, x1, x2
    b324:	d360fc21 	lsr	x1, x1, #32
    b328:	eb00003f 	cmp	x1, x0
    b32c:	540000e2 	b.cs	b348 <f0+0x7a8>  // b.hs, b.nlast
    b330:	8b0102b5 	add	x21, x21, x1
    b334:	394002a0 	ldrb	w0, [x21]
    b338:	7103fc1f 	cmp	w0, #0xff
    b33c:	5400ebc0 	b.eq	d0b4 <f0+0x2514>  // b.none
    b340:	52800020 	mov	w0, #0x1                   	// #1
    b344:	390002a0 	strb	w0, [x21]
    b348:	910863e1 	add	x1, sp, #0x218
    b34c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b350:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b354:	52800020 	mov	w0, #0x1                   	// #1
    b358:	f9010ff5 	str	x21, [sp, #536]
    b35c:	f90113f7 	str	x23, [sp, #544]
    b360:	97ffea2c 	bl	5c10 <fwp_data.part.0.constprop.0>
    b364:	97ffeaaf 	bl	5e20 <fwp_rc_fresh>
    b368:	aa0003e2 	mov	x2, x0
    b36c:	9108a3e1 	add	x1, sp, #0x228
    b370:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b374:	52800020 	mov	w0, #0x1                   	// #1
    b378:	f90117f7 	str	x23, [sp, #552]
    b37c:	f9011be2 	str	x2, [sp, #560]
    b380:	97ffea24 	bl	5c10 <fwp_data.part.0.constprop.0>
    b384:	97ffeaa7 	bl	5e20 <fwp_rc_fresh>
    b388:	aa0003e2 	mov	x2, x0
    b38c:	9108e3e1 	add	x1, sp, #0x238
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f9011ff5 	str	x21, [sp, #568]
    b398:	f90123e2 	str	x2, [sp, #576]
    b39c:	97ffea1d 	bl	5c10 <fwp_data.part.0.constprop.0>
    b3a0:	97ffeaa0 	bl	5e20 <fwp_rc_fresh>
    b3a4:	aa0003e2 	mov	x2, x0
    b3a8:	910923e1 	add	x1, sp, #0x248
    b3ac:	52800020 	mov	w0, #0x1                   	// #1
    b3b0:	f90127f7 	str	x23, [sp, #584]
    b3b4:	f9012be2 	str	x2, [sp, #592]
    b3b8:	97ffea16 	bl	5c10 <fwp_data.part.0.constprop.0>
    b3bc:	97ffea99 	bl	5e20 <fwp_rc_fresh>
    b3c0:	aa0003e2 	mov	x2, x0
    b3c4:	910963e1 	add	x1, sp, #0x258
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	f9012ff5 	str	x21, [sp, #600]
    b3d0:	f90133e2 	str	x2, [sp, #608]
    b3d4:	97ffea0f 	bl	5c10 <fwp_data.part.0.constprop.0>
    b3d8:	97ffea92 	bl	5e20 <fwp_rc_fresh>
    b3dc:	aa0003e2 	mov	x2, x0
    b3e0:	9109a3e1 	add	x1, sp, #0x268
    b3e4:	52800020 	mov	w0, #0x1                   	// #1
    b3e8:	f90137f7 	str	x23, [sp, #616]
    b3ec:	f9013be2 	str	x2, [sp, #624]
    b3f0:	97ffea08 	bl	5c10 <fwp_data.part.0.constprop.0>
    b3f4:	97ffea8b 	bl	5e20 <fwp_rc_fresh>
    b3f8:	aa0003e2 	mov	x2, x0
    b3fc:	9109e3e1 	add	x1, sp, #0x278
    b400:	52800020 	mov	w0, #0x1                   	// #1
    b404:	f9013ff5 	str	x21, [sp, #632]
    b408:	f90143e2 	str	x2, [sp, #640]
    b40c:	97ffea01 	bl	5c10 <fwp_data.part.0.constprop.0>
    b410:	91190283 	add	x3, x20, #0x640
    b414:	aa0003f5 	mov	x21, x0
    b418:	f949d861 	ldr	x1, [x3, #5040]
    b41c:	f949ec60 	ldr	x0, [x3, #5080]
    b420:	cb0102a1 	sub	x1, x21, x1
    b424:	eb00403f 	cmp	x1, x0, lsl #16
    b428:	54000322 	b.cs	b48c <f0+0x8ec>  // b.hs, b.nlast
    b42c:	d350fc22 	lsr	x2, x1, #16
    b430:	f949fc63 	ldr	x3, [x3, #5112]
    b434:	8b020842 	add	x2, x2, x2, lsl #2
    b438:	d37df042 	lsl	x2, x2, #3
    b43c:	8b020060 	add	x0, x3, x2
    b440:	f9401017 	ldr	x23, [x0, #32]
    b444:	b4000257 	cbz	x23, b48c <f0+0x8ec>
    b448:	38626862 	ldrb	w2, [x3, x2]
    b44c:	7100085f 	cmp	w2, #0x2
    b450:	5400dae0 	b.eq	cfac <f0+0x240c>  // b.none
    b454:	7100045f 	cmp	w2, #0x1
    b458:	540001a1 	b.ne	b48c <f0+0x8ec>  // b.any
    b45c:	29430002 	ldp	w2, w0, [x0, #24]
    b460:	92403c21 	and	x1, x1, #0xffff
    b464:	9b027c21 	mul	x1, x1, x2
    b468:	d360fc21 	lsr	x1, x1, #32
    b46c:	eb00003f 	cmp	x1, x0
    b470:	540000e2 	b.cs	b48c <f0+0x8ec>  // b.hs, b.nlast
    b474:	8b0102f7 	add	x23, x23, x1
    b478:	394002e0 	ldrb	w0, [x23]
    b47c:	7103fc1f 	cmp	w0, #0xff
    b480:	5400e200 	b.eq	d0c0 <f0+0x2520>  // b.none
    b484:	52800020 	mov	w0, #0x1                   	// #1
    b488:	390002e0 	strb	w0, [x23]
    b48c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b490:	910a23e1 	add	x1, sp, #0x288
    b494:	52800020 	mov	w0, #0x1                   	// #1
    b498:	f90147e2 	str	x2, [sp, #648]
    b49c:	f9014bf5 	str	x21, [sp, #656]
    b4a0:	97ffe9dc 	bl	5c10 <fwp_data.part.0.constprop.0>
    b4a4:	91190283 	add	x3, x20, #0x640
    b4a8:	aa0003f5 	mov	x21, x0
    b4ac:	f949d861 	ldr	x1, [x3, #5040]
    b4b0:	f949ec60 	ldr	x0, [x3, #5080]
    b4b4:	cb0102a1 	sub	x1, x21, x1
    b4b8:	eb00403f 	cmp	x1, x0, lsl #16
    b4bc:	54000322 	b.cs	b520 <f0+0x980>  // b.hs, b.nlast
    b4c0:	d350fc22 	lsr	x2, x1, #16
    b4c4:	f949fc63 	ldr	x3, [x3, #5112]
    b4c8:	8b020842 	add	x2, x2, x2, lsl #2
    b4cc:	d37df042 	lsl	x2, x2, #3
    b4d0:	8b020060 	add	x0, x3, x2
    b4d4:	f9401017 	ldr	x23, [x0, #32]
    b4d8:	b4000257 	cbz	x23, b520 <f0+0x980>
    b4dc:	38626862 	ldrb	w2, [x3, x2]
    b4e0:	7100085f 	cmp	w2, #0x2
    b4e4:	5400d5e0 	b.eq	cfa0 <f0+0x2400>  // b.none
    b4e8:	7100045f 	cmp	w2, #0x1
    b4ec:	540001a1 	b.ne	b520 <f0+0x980>  // b.any
    b4f0:	29430002 	ldp	w2, w0, [x0, #24]
    b4f4:	92403c21 	and	x1, x1, #0xffff
    b4f8:	9b027c21 	mul	x1, x1, x2
    b4fc:	d360fc21 	lsr	x1, x1, #32
    b500:	eb00003f 	cmp	x1, x0
    b504:	540000e2 	b.cs	b520 <f0+0x980>  // b.hs, b.nlast
    b508:	8b0102f7 	add	x23, x23, x1
    b50c:	394002e0 	ldrb	w0, [x23]
    b510:	7103fc1f 	cmp	w0, #0xff
    b514:	5400ddc0 	b.eq	d0cc <f0+0x252c>  // b.none
    b518:	52800020 	mov	w0, #0x1                   	// #1
    b51c:	390002e0 	strb	w0, [x23]
    b520:	910a63e1 	add	x1, sp, #0x298
    b524:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b528:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b52c:	52800020 	mov	w0, #0x1                   	// #1
    b530:	f9014ff7 	str	x23, [sp, #664]
    b534:	f90153f5 	str	x21, [sp, #672]
    b538:	97ffe9b6 	bl	5c10 <fwp_data.part.0.constprop.0>
    b53c:	97ffea39 	bl	5e20 <fwp_rc_fresh>
    b540:	aa0003e2 	mov	x2, x0
    b544:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b548:	910aa3e1 	add	x1, sp, #0x2a8
    b54c:	52800020 	mov	w0, #0x1                   	// #1
    b550:	f90157e3 	str	x3, [sp, #680]
    b554:	f9015be2 	str	x2, [sp, #688]
    b558:	97ffe9ae 	bl	5c10 <fwp_data.part.0.constprop.0>
    b55c:	97ffea31 	bl	5e20 <fwp_rc_fresh>
    b560:	aa0003e2 	mov	x2, x0
    b564:	910ae3e1 	add	x1, sp, #0x2b8
    b568:	52800020 	mov	w0, #0x1                   	// #1
    b56c:	f9015ff7 	str	x23, [sp, #696]
    b570:	f90163e2 	str	x2, [sp, #704]
    b574:	97ffe9a7 	bl	5c10 <fwp_data.part.0.constprop.0>
    b578:	91190283 	add	x3, x20, #0x640
    b57c:	aa0003f5 	mov	x21, x0
    b580:	f949d861 	ldr	x1, [x3, #5040]
    b584:	f949ec60 	ldr	x0, [x3, #5080]
    b588:	cb0102a1 	sub	x1, x21, x1
    b58c:	eb00403f 	cmp	x1, x0, lsl #16
    b590:	54000322 	b.cs	b5f4 <f0+0xa54>  // b.hs, b.nlast
    b594:	d350fc22 	lsr	x2, x1, #16
    b598:	f949fc63 	ldr	x3, [x3, #5112]
    b59c:	8b020842 	add	x2, x2, x2, lsl #2
    b5a0:	d37df042 	lsl	x2, x2, #3
    b5a4:	8b020060 	add	x0, x3, x2
    b5a8:	f9401017 	ldr	x23, [x0, #32]
    b5ac:	b4000257 	cbz	x23, b5f4 <f0+0xa54>
    b5b0:	38626862 	ldrb	w2, [x3, x2]
    b5b4:	7100085f 	cmp	w2, #0x2
    b5b8:	5400d060 	b.eq	cfc4 <f0+0x2424>  // b.none
    b5bc:	7100045f 	cmp	w2, #0x1
    b5c0:	540001a1 	b.ne	b5f4 <f0+0xa54>  // b.any
    b5c4:	29430002 	ldp	w2, w0, [x0, #24]
    b5c8:	92403c21 	and	x1, x1, #0xffff
    b5cc:	9b027c21 	mul	x1, x1, x2
    b5d0:	d360fc21 	lsr	x1, x1, #32
    b5d4:	eb00003f 	cmp	x1, x0
    b5d8:	540000e2 	b.cs	b5f4 <f0+0xa54>  // b.hs, b.nlast
    b5dc:	8b0102f7 	add	x23, x23, x1
    b5e0:	394002e0 	ldrb	w0, [x23]
    b5e4:	7103fc1f 	cmp	w0, #0xff
    b5e8:	5400d780 	b.eq	d0d8 <f0+0x2538>  // b.none
    b5ec:	52800020 	mov	w0, #0x1                   	// #1
    b5f0:	390002e0 	strb	w0, [x23]
    b5f4:	910b23e1 	add	x1, sp, #0x2c8
    b5f8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b5fc:	52800020 	mov	w0, #0x1                   	// #1
    b600:	f90167f7 	str	x23, [sp, #712]
    b604:	f9016bf5 	str	x21, [sp, #720]
    b608:	97ffe982 	bl	5c10 <fwp_data.part.0.constprop.0>
    b60c:	97ffea05 	bl	5e20 <fwp_rc_fresh>
    b610:	aa0003e2 	mov	x2, x0
    b614:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b618:	910b63e1 	add	x1, sp, #0x2d8
    b61c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b620:	52800020 	mov	w0, #0x1                   	// #1
    b624:	f9016fe3 	str	x3, [sp, #728]
    b628:	f90173e2 	str	x2, [sp, #736]
    b62c:	97ffe979 	bl	5c10 <fwp_data.part.0.constprop.0>
    b630:	97ffe9fc 	bl	5e20 <fwp_rc_fresh>
    b634:	aa0003e2 	mov	x2, x0
    b638:	910ba3e1 	add	x1, sp, #0x2e8
    b63c:	52800020 	mov	w0, #0x1                   	// #1
    b640:	f90177f7 	str	x23, [sp, #744]
    b644:	f9017be2 	str	x2, [sp, #752]
    b648:	97ffe972 	bl	5c10 <fwp_data.part.0.constprop.0>
    b64c:	91190283 	add	x3, x20, #0x640
    b650:	aa0003f5 	mov	x21, x0
    b654:	f949d861 	ldr	x1, [x3, #5040]
    b658:	f949ec60 	ldr	x0, [x3, #5080]
    b65c:	cb0102a1 	sub	x1, x21, x1
    b660:	eb00403f 	cmp	x1, x0, lsl #16
    b664:	54000322 	b.cs	b6c8 <f0+0xb28>  // b.hs, b.nlast
    b668:	d350fc22 	lsr	x2, x1, #16
    b66c:	f949fc63 	ldr	x3, [x3, #5112]
    b670:	8b020842 	add	x2, x2, x2, lsl #2
    b674:	d37df042 	lsl	x2, x2, #3
    b678:	8b020060 	add	x0, x3, x2
    b67c:	f9401017 	ldr	x23, [x0, #32]
    b680:	b4000257 	cbz	x23, b6c8 <f0+0xb28>
    b684:	38626862 	ldrb	w2, [x3, x2]
    b688:	7100085f 	cmp	w2, #0x2
    b68c:	5400c960 	b.eq	cfb8 <f0+0x2418>  // b.none
    b690:	7100045f 	cmp	w2, #0x1
    b694:	540001a1 	b.ne	b6c8 <f0+0xb28>  // b.any
    b698:	29430002 	ldp	w2, w0, [x0, #24]
    b69c:	92403c21 	and	x1, x1, #0xffff
    b6a0:	9b027c21 	mul	x1, x1, x2
    b6a4:	d360fc21 	lsr	x1, x1, #32
    b6a8:	eb00003f 	cmp	x1, x0
    b6ac:	540000e2 	b.cs	b6c8 <f0+0xb28>  // b.hs, b.nlast
    b6b0:	8b0102f7 	add	x23, x23, x1
    b6b4:	394002e0 	ldrb	w0, [x23]
    b6b8:	7103fc1f 	cmp	w0, #0xff
    b6bc:	5400d140 	b.eq	d0e4 <f0+0x2544>  // b.none
    b6c0:	52800020 	mov	w0, #0x1                   	// #1
    b6c4:	390002e0 	strb	w0, [x23]
    b6c8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6cc:	910be3e1 	add	x1, sp, #0x2f8
    b6d0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6d4:	52800020 	mov	w0, #0x1                   	// #1
    b6d8:	f9017fe2 	str	x2, [sp, #760]
    b6dc:	f90183f5 	str	x21, [sp, #768]
    b6e0:	97ffe94c 	bl	5c10 <fwp_data.part.0.constprop.0>
    b6e4:	91190283 	add	x3, x20, #0x640
    b6e8:	aa0003f5 	mov	x21, x0
    b6ec:	f949d861 	ldr	x1, [x3, #5040]
    b6f0:	f949ec60 	ldr	x0, [x3, #5080]
    b6f4:	cb0102a1 	sub	x1, x21, x1
    b6f8:	eb00403f 	cmp	x1, x0, lsl #16
    b6fc:	54000322 	b.cs	b760 <f0+0xbc0>  // b.hs, b.nlast
    b700:	d350fc22 	lsr	x2, x1, #16
    b704:	f949fc63 	ldr	x3, [x3, #5112]
    b708:	8b020842 	add	x2, x2, x2, lsl #2
    b70c:	d37df042 	lsl	x2, x2, #3
    b710:	8b020060 	add	x0, x3, x2
    b714:	f9401017 	ldr	x23, [x0, #32]
    b718:	b4000257 	cbz	x23, b760 <f0+0xbc0>
    b71c:	38626862 	ldrb	w2, [x3, x2]
    b720:	7100085f 	cmp	w2, #0x2
    b724:	5400c5c0 	b.eq	cfdc <f0+0x243c>  // b.none
    b728:	7100045f 	cmp	w2, #0x1
    b72c:	540001a1 	b.ne	b760 <f0+0xbc0>  // b.any
    b730:	29430002 	ldp	w2, w0, [x0, #24]
    b734:	92403c21 	and	x1, x1, #0xffff
    b738:	9b027c21 	mul	x1, x1, x2
    b73c:	d360fc21 	lsr	x1, x1, #32
    b740:	eb00003f 	cmp	x1, x0
    b744:	540000e2 	b.cs	b760 <f0+0xbc0>  // b.hs, b.nlast
    b748:	8b0102f7 	add	x23, x23, x1
    b74c:	394002e0 	ldrb	w0, [x23]
    b750:	7103fc1f 	cmp	w0, #0xff
    b754:	5400cce0 	b.eq	d0f0 <f0+0x2550>  // b.none
    b758:	52800020 	mov	w0, #0x1                   	// #1
    b75c:	390002e0 	strb	w0, [x23]
    b760:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b764:	910c23e1 	add	x1, sp, #0x308
    b768:	52800020 	mov	w0, #0x1                   	// #1
    b76c:	f90187e2 	str	x2, [sp, #776]
    b770:	f9018bf5 	str	x21, [sp, #784]
    b774:	97ffe927 	bl	5c10 <fwp_data.part.0.constprop.0>
    b778:	91190283 	add	x3, x20, #0x640
    b77c:	aa0003f5 	mov	x21, x0
    b780:	f949d861 	ldr	x1, [x3, #5040]
    b784:	f949ec60 	ldr	x0, [x3, #5080]
    b788:	cb0102a1 	sub	x1, x21, x1
    b78c:	eb00403f 	cmp	x1, x0, lsl #16
    b790:	54000322 	b.cs	b7f4 <f0+0xc54>  // b.hs, b.nlast
    b794:	d350fc22 	lsr	x2, x1, #16
    b798:	f949fc63 	ldr	x3, [x3, #5112]
    b79c:	8b020842 	add	x2, x2, x2, lsl #2
    b7a0:	d37df042 	lsl	x2, x2, #3
    b7a4:	8b020060 	add	x0, x3, x2
    b7a8:	f9401017 	ldr	x23, [x0, #32]
    b7ac:	b4000257 	cbz	x23, b7f4 <f0+0xc54>
    b7b0:	38626862 	ldrb	w2, [x3, x2]
    b7b4:	7100085f 	cmp	w2, #0x2
    b7b8:	5400c0c0 	b.eq	cfd0 <f0+0x2430>  // b.none
    b7bc:	7100045f 	cmp	w2, #0x1
    b7c0:	540001a1 	b.ne	b7f4 <f0+0xc54>  // b.any
    b7c4:	29430002 	ldp	w2, w0, [x0, #24]
    b7c8:	92403c21 	and	x1, x1, #0xffff
    b7cc:	9b027c21 	mul	x1, x1, x2
    b7d0:	d360fc21 	lsr	x1, x1, #32
    b7d4:	eb00003f 	cmp	x1, x0
    b7d8:	540000e2 	b.cs	b7f4 <f0+0xc54>  // b.hs, b.nlast
    b7dc:	8b0102f7 	add	x23, x23, x1
    b7e0:	394002e0 	ldrb	w0, [x23]
    b7e4:	7103fc1f 	cmp	w0, #0xff
    b7e8:	5400c8a0 	b.eq	d0fc <f0+0x255c>  // b.none
    b7ec:	52800020 	mov	w0, #0x1                   	// #1
    b7f0:	390002e0 	strb	w0, [x23]
    b7f4:	910c63e1 	add	x1, sp, #0x318
    b7f8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b7fc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b800:	52800020 	mov	w0, #0x1                   	// #1
    b804:	f9018ff7 	str	x23, [sp, #792]
    b808:	f90193f5 	str	x21, [sp, #800]
    b80c:	97ffe901 	bl	5c10 <fwp_data.part.0.constprop.0>
    b810:	97ffe984 	bl	5e20 <fwp_rc_fresh>
    b814:	aa0003e2 	mov	x2, x0
    b818:	910ca3e1 	add	x1, sp, #0x328
    b81c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b820:	52800020 	mov	w0, #0x1                   	// #1
    b824:	f90197f5 	str	x21, [sp, #808]
    b828:	f9019be2 	str	x2, [sp, #816]
    b82c:	97ffe8f9 	bl	5c10 <fwp_data.part.0.constprop.0>
    b830:	97ffe97c 	bl	5e20 <fwp_rc_fresh>
    b834:	aa0003e2 	mov	x2, x0
    b838:	910ce3e1 	add	x1, sp, #0x338
    b83c:	52800020 	mov	w0, #0x1                   	// #1
    b840:	f9019ff7 	str	x23, [sp, #824]
    b844:	f901a3e2 	str	x2, [sp, #832]
    b848:	97ffe8f2 	bl	5c10 <fwp_data.part.0.constprop.0>
    b84c:	97ffe975 	bl	5e20 <fwp_rc_fresh>
    b850:	aa0003e2 	mov	x2, x0
    b854:	910d23e1 	add	x1, sp, #0x348
    b858:	52800020 	mov	w0, #0x1                   	// #1
    b85c:	f901a7f5 	str	x21, [sp, #840]
    b860:	f901abe2 	str	x2, [sp, #848]
    b864:	97ffe8eb 	bl	5c10 <fwp_data.part.0.constprop.0>
    b868:	91190283 	add	x3, x20, #0x640
    b86c:	aa0003f5 	mov	x21, x0
    b870:	f949d861 	ldr	x1, [x3, #5040]
    b874:	f949ec60 	ldr	x0, [x3, #5080]
    b878:	cb0102a1 	sub	x1, x21, x1
    b87c:	eb00403f 	cmp	x1, x0, lsl #16
    b880:	54000322 	b.cs	b8e4 <f0+0xd44>  // b.hs, b.nlast
    b884:	d350fc22 	lsr	x2, x1, #16
    b888:	f949fc63 	ldr	x3, [x3, #5112]
    b88c:	8b020842 	add	x2, x2, x2, lsl #2
    b890:	d37df042 	lsl	x2, x2, #3
    b894:	8b020060 	add	x0, x3, x2
    b898:	f9401017 	ldr	x23, [x0, #32]
    b89c:	b4000257 	cbz	x23, b8e4 <f0+0xd44>
    b8a0:	38626862 	ldrb	w2, [x3, x2]
    b8a4:	7100085f 	cmp	w2, #0x2
    b8a8:	5400ba60 	b.eq	cff4 <f0+0x2454>  // b.none
    b8ac:	7100045f 	cmp	w2, #0x1
    b8b0:	540001a1 	b.ne	b8e4 <f0+0xd44>  // b.any
    b8b4:	29430002 	ldp	w2, w0, [x0, #24]
    b8b8:	92403c21 	and	x1, x1, #0xffff
    b8bc:	9b027c21 	mul	x1, x1, x2
    b8c0:	d360fc21 	lsr	x1, x1, #32
    b8c4:	eb00003f 	cmp	x1, x0
    b8c8:	540000e2 	b.cs	b8e4 <f0+0xd44>  // b.hs, b.nlast
    b8cc:	8b0102f7 	add	x23, x23, x1
    b8d0:	394002e0 	ldrb	w0, [x23]
    b8d4:	7103fc1f 	cmp	w0, #0xff
    b8d8:	5400c180 	b.eq	d108 <f0+0x2568>  // b.none
    b8dc:	52800020 	mov	w0, #0x1                   	// #1
    b8e0:	390002e0 	strb	w0, [x23]
    b8e4:	910d63e1 	add	x1, sp, #0x358
    b8e8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b8ec:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b8f0:	52800020 	mov	w0, #0x1                   	// #1
    b8f4:	f901aff7 	str	x23, [sp, #856]
    b8f8:	f901b3f5 	str	x21, [sp, #864]
    b8fc:	97ffe8c5 	bl	5c10 <fwp_data.part.0.constprop.0>
    b900:	97ffe948 	bl	5e20 <fwp_rc_fresh>
    b904:	aa0003e2 	mov	x2, x0
    b908:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b90c:	910da3e1 	add	x1, sp, #0x368
    b910:	52800020 	mov	w0, #0x1                   	// #1
    b914:	f901b7e3 	str	x3, [sp, #872]
    b918:	f901bbe2 	str	x2, [sp, #880]
    b91c:	97ffe8bd 	bl	5c10 <fwp_data.part.0.constprop.0>
    b920:	97ffe940 	bl	5e20 <fwp_rc_fresh>
    b924:	aa0003e2 	mov	x2, x0
    b928:	910de3e1 	add	x1, sp, #0x378
    b92c:	52800020 	mov	w0, #0x1                   	// #1
    b930:	f901bff7 	str	x23, [sp, #888]
    b934:	f901c3e2 	str	x2, [sp, #896]
    b938:	97ffe8b6 	bl	5c10 <fwp_data.part.0.constprop.0>
    b93c:	91190283 	add	x3, x20, #0x640
    b940:	aa0003f5 	mov	x21, x0
    b944:	f949d861 	ldr	x1, [x3, #5040]
    b948:	f949ec60 	ldr	x0, [x3, #5080]
    b94c:	cb0102a1 	sub	x1, x21, x1
    b950:	eb00403f 	cmp	x1, x0, lsl #16
    b954:	54000322 	b.cs	b9b8 <f0+0xe18>  // b.hs, b.nlast
    b958:	d350fc22 	lsr	x2, x1, #16
    b95c:	f949fc63 	ldr	x3, [x3, #5112]
    b960:	8b020842 	add	x2, x2, x2, lsl #2
    b964:	d37df042 	lsl	x2, x2, #3
    b968:	8b020060 	add	x0, x3, x2
    b96c:	f9401017 	ldr	x23, [x0, #32]
    b970:	b4000257 	cbz	x23, b9b8 <f0+0xe18>
    b974:	38626862 	ldrb	w2, [x3, x2]
    b978:	7100085f 	cmp	w2, #0x2
    b97c:	5400b360 	b.eq	cfe8 <f0+0x2448>  // b.none
    b980:	7100045f 	cmp	w2, #0x1
    b984:	540001a1 	b.ne	b9b8 <f0+0xe18>  // b.any
    b988:	29430002 	ldp	w2, w0, [x0, #24]
    b98c:	92403c21 	and	x1, x1, #0xffff
    b990:	9b027c21 	mul	x1, x1, x2
    b994:	d360fc21 	lsr	x1, x1, #32
    b998:	eb00003f 	cmp	x1, x0
    b99c:	540000e2 	b.cs	b9b8 <f0+0xe18>  // b.hs, b.nlast
    b9a0:	8b0102f7 	add	x23, x23, x1
    b9a4:	394002e0 	ldrb	w0, [x23]
    b9a8:	7103fc1f 	cmp	w0, #0xff
    b9ac:	5400bb40 	b.eq	d114 <f0+0x2574>  // b.none
    b9b0:	52800020 	mov	w0, #0x1                   	// #1
    b9b4:	390002e0 	strb	w0, [x23]
    b9b8:	910e23e1 	add	x1, sp, #0x388
    b9bc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b9c0:	52800020 	mov	w0, #0x1                   	// #1
    b9c4:	f901c7f7 	str	x23, [sp, #904]
    b9c8:	f901cbf5 	str	x21, [sp, #912]
    b9cc:	97ffe891 	bl	5c10 <fwp_data.part.0.constprop.0>
    b9d0:	97ffe914 	bl	5e20 <fwp_rc_fresh>
    b9d4:	aa0003e2 	mov	x2, x0
    b9d8:	910e63e1 	add	x1, sp, #0x398
    b9dc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b9e0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b9e4:	52800020 	mov	w0, #0x1                   	// #1
    b9e8:	f901cff5 	str	x21, [sp, #920]
    b9ec:	f901d3e2 	str	x2, [sp, #928]
    b9f0:	97ffe888 	bl	5c10 <fwp_data.part.0.constprop.0>
    b9f4:	97ffe90b 	bl	5e20 <fwp_rc_fresh>
    b9f8:	aa0003e2 	mov	x2, x0
    b9fc:	910ea3e1 	add	x1, sp, #0x3a8
    ba00:	52800020 	mov	w0, #0x1                   	// #1
    ba04:	f901d7f7 	str	x23, [sp, #936]
    ba08:	f901dbe2 	str	x2, [sp, #944]
    ba0c:	97ffe881 	bl	5c10 <fwp_data.part.0.constprop.0>
    ba10:	97ffe904 	bl	5e20 <fwp_rc_fresh>
    ba14:	aa0003e2 	mov	x2, x0
    ba18:	910ee3e1 	add	x1, sp, #0x3b8
    ba1c:	52800020 	mov	w0, #0x1                   	// #1
    ba20:	f901dff5 	str	x21, [sp, #952]
    ba24:	f901e3e2 	str	x2, [sp, #960]
    ba28:	97ffe87a 	bl	5c10 <fwp_data.part.0.constprop.0>
    ba2c:	97ffe8fd 	bl	5e20 <fwp_rc_fresh>
    ba30:	aa0003e2 	mov	x2, x0
    ba34:	910f23e1 	add	x1, sp, #0x3c8
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	f901e7f7 	str	x23, [sp, #968]
    ba40:	f901ebe2 	str	x2, [sp, #976]
    ba44:	97ffe873 	bl	5c10 <fwp_data.part.0.constprop.0>
    ba48:	91190283 	add	x3, x20, #0x640
    ba4c:	aa0003f5 	mov	x21, x0
    ba50:	f949d861 	ldr	x1, [x3, #5040]
    ba54:	f949ec60 	ldr	x0, [x3, #5080]
    ba58:	cb0102a1 	sub	x1, x21, x1
    ba5c:	eb00403f 	cmp	x1, x0, lsl #16
    ba60:	54000322 	b.cs	bac4 <f0+0xf24>  // b.hs, b.nlast
    ba64:	d350fc22 	lsr	x2, x1, #16
    ba68:	f949fc63 	ldr	x3, [x3, #5112]
    ba6c:	8b020842 	add	x2, x2, x2, lsl #2
    ba70:	d37df042 	lsl	x2, x2, #3
    ba74:	8b020060 	add	x0, x3, x2
    ba78:	f9401017 	ldr	x23, [x0, #32]
    ba7c:	b4000257 	cbz	x23, bac4 <f0+0xf24>
    ba80:	38626862 	ldrb	w2, [x3, x2]
    ba84:	7100085f 	cmp	w2, #0x2
    ba88:	5400ac20 	b.eq	d00c <f0+0x246c>  // b.none
    ba8c:	7100045f 	cmp	w2, #0x1
    ba90:	540001a1 	b.ne	bac4 <f0+0xf24>  // b.any
    ba94:	29430002 	ldp	w2, w0, [x0, #24]
    ba98:	92403c21 	and	x1, x1, #0xffff
    ba9c:	9b027c21 	mul	x1, x1, x2
    baa0:	d360fc21 	lsr	x1, x1, #32
    baa4:	eb00003f 	cmp	x1, x0
    baa8:	540000e2 	b.cs	bac4 <f0+0xf24>  // b.hs, b.nlast
    baac:	8b0102f7 	add	x23, x23, x1
    bab0:	394002e0 	ldrb	w0, [x23]
    bab4:	7103fc1f 	cmp	w0, #0xff
    bab8:	5400b340 	b.eq	d120 <f0+0x2580>  // b.none
    babc:	52800020 	mov	w0, #0x1                   	// #1
    bac0:	390002e0 	strb	w0, [x23]
    bac4:	910f63e1 	add	x1, sp, #0x3d8
    bac8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bacc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bad0:	52800020 	mov	w0, #0x1                   	// #1
    bad4:	f901eff7 	str	x23, [sp, #984]
    bad8:	f901f3f5 	str	x21, [sp, #992]
    badc:	97ffe84d 	bl	5c10 <fwp_data.part.0.constprop.0>
    bae0:	97ffe8d0 	bl	5e20 <fwp_rc_fresh>
    bae4:	aa0003e2 	mov	x2, x0
    bae8:	910fa3e1 	add	x1, sp, #0x3e8
    baec:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    baf0:	52800020 	mov	w0, #0x1                   	// #1
    baf4:	f901f7f5 	str	x21, [sp, #1000]
    baf8:	f901fbe2 	str	x2, [sp, #1008]
    bafc:	97ffe845 	bl	5c10 <fwp_data.part.0.constprop.0>
    bb00:	97ffe8c8 	bl	5e20 <fwp_rc_fresh>
    bb04:	aa0003e2 	mov	x2, x0
    bb08:	910fe3e1 	add	x1, sp, #0x3f8
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	f901fff7 	str	x23, [sp, #1016]
    bb14:	f90203e2 	str	x2, [sp, #1024]
    bb18:	97ffe83e 	bl	5c10 <fwp_data.part.0.constprop.0>
    bb1c:	97ffe8c1 	bl	5e20 <fwp_rc_fresh>
    bb20:	aa0003e2 	mov	x2, x0
    bb24:	911023e1 	add	x1, sp, #0x408
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	f90207f5 	str	x21, [sp, #1032]
    bb30:	f9020be2 	str	x2, [sp, #1040]
    bb34:	97ffe837 	bl	5c10 <fwp_data.part.0.constprop.0>
    bb38:	91190283 	add	x3, x20, #0x640
    bb3c:	aa0003f7 	mov	x23, x0
    bb40:	f949d861 	ldr	x1, [x3, #5040]
    bb44:	f949ec60 	ldr	x0, [x3, #5080]
    bb48:	cb0102e1 	sub	x1, x23, x1
    bb4c:	eb00403f 	cmp	x1, x0, lsl #16
    bb50:	54000322 	b.cs	bbb4 <f0+0x1014>  // b.hs, b.nlast
    bb54:	d350fc22 	lsr	x2, x1, #16
    bb58:	f949fc63 	ldr	x3, [x3, #5112]
    bb5c:	8b020842 	add	x2, x2, x2, lsl #2
    bb60:	d37df042 	lsl	x2, x2, #3
    bb64:	8b020060 	add	x0, x3, x2
    bb68:	f9401015 	ldr	x21, [x0, #32]
    bb6c:	b4000255 	cbz	x21, bbb4 <f0+0x1014>
    bb70:	38626862 	ldrb	w2, [x3, x2]
    bb74:	7100085f 	cmp	w2, #0x2
    bb78:	5400a440 	b.eq	d000 <f0+0x2460>  // b.none
    bb7c:	7100045f 	cmp	w2, #0x1
    bb80:	540001a1 	b.ne	bbb4 <f0+0x1014>  // b.any
    bb84:	29430002 	ldp	w2, w0, [x0, #24]
    bb88:	92403c21 	and	x1, x1, #0xffff
    bb8c:	9b027c21 	mul	x1, x1, x2
    bb90:	d360fc21 	lsr	x1, x1, #32
    bb94:	eb00003f 	cmp	x1, x0
    bb98:	540000e2 	b.cs	bbb4 <f0+0x1014>  // b.hs, b.nlast
    bb9c:	8b0102b5 	add	x21, x21, x1
    bba0:	394002a0 	ldrb	w0, [x21]
    bba4:	7103fc1f 	cmp	w0, #0xff
    bba8:	5400ac20 	b.eq	d12c <f0+0x258c>  // b.none
    bbac:	52800020 	mov	w0, #0x1                   	// #1
    bbb0:	390002a0 	strb	w0, [x21]
    bbb4:	911063e1 	add	x1, sp, #0x418
    bbb8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bbbc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f9020ff5 	str	x21, [sp, #1048]
    bbc8:	f90213f7 	str	x23, [sp, #1056]
    bbcc:	97ffe811 	bl	5c10 <fwp_data.part.0.constprop.0>
    bbd0:	97ffe894 	bl	5e20 <fwp_rc_fresh>
    bbd4:	aa0003e2 	mov	x2, x0
    bbd8:	9110a3e1 	add	x1, sp, #0x428
    bbdc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f90217f7 	str	x23, [sp, #1064]
    bbe8:	f9021be2 	str	x2, [sp, #1072]
    bbec:	97ffe809 	bl	5c10 <fwp_data.part.0.constprop.0>
    bbf0:	97ffe88c 	bl	5e20 <fwp_rc_fresh>
    bbf4:	aa0003e2 	mov	x2, x0
    bbf8:	9110e3e1 	add	x1, sp, #0x438
    bbfc:	52800020 	mov	w0, #0x1                   	// #1
    bc00:	f9021ff5 	str	x21, [sp, #1080]
    bc04:	f90223e2 	str	x2, [sp, #1088]
    bc08:	97ffe802 	bl	5c10 <fwp_data.part.0.constprop.0>
    bc0c:	97ffe885 	bl	5e20 <fwp_rc_fresh>
    bc10:	aa0003e2 	mov	x2, x0
    bc14:	911123e1 	add	x1, sp, #0x448
    bc18:	52800020 	mov	w0, #0x1                   	// #1
    bc1c:	f90227f7 	str	x23, [sp, #1096]
    bc20:	f9022be2 	str	x2, [sp, #1104]
    bc24:	97ffe7fb 	bl	5c10 <fwp_data.part.0.constprop.0>
    bc28:	97ffe87e 	bl	5e20 <fwp_rc_fresh>
    bc2c:	aa0003e2 	mov	x2, x0
    bc30:	911163e1 	add	x1, sp, #0x458
    bc34:	52800020 	mov	w0, #0x1                   	// #1
    bc38:	f9022ff5 	str	x21, [sp, #1112]
    bc3c:	f90233e2 	str	x2, [sp, #1120]
    bc40:	97ffe7f4 	bl	5c10 <fwp_data.part.0.constprop.0>
    bc44:	97ffe877 	bl	5e20 <fwp_rc_fresh>
    bc48:	aa0003e2 	mov	x2, x0
    bc4c:	9111a3e1 	add	x1, sp, #0x468
    bc50:	52800020 	mov	w0, #0x1                   	// #1
    bc54:	f90237f7 	str	x23, [sp, #1128]
    bc58:	f9023be2 	str	x2, [sp, #1136]
    bc5c:	97ffe7ed 	bl	5c10 <fwp_data.part.0.constprop.0>
    bc60:	97ffe870 	bl	5e20 <fwp_rc_fresh>
    bc64:	aa0003e2 	mov	x2, x0
    bc68:	9111e3e1 	add	x1, sp, #0x478
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	f9023ff5 	str	x21, [sp, #1144]
    bc74:	f90243e2 	str	x2, [sp, #1152]
    bc78:	97ffe7e6 	bl	5c10 <fwp_data.part.0.constprop.0>
    bc7c:	91190283 	add	x3, x20, #0x640
    bc80:	aa0003f5 	mov	x21, x0
    bc84:	f949d861 	ldr	x1, [x3, #5040]
    bc88:	f949ec60 	ldr	x0, [x3, #5080]
    bc8c:	cb0102a1 	sub	x1, x21, x1
    bc90:	eb00403f 	cmp	x1, x0, lsl #16
    bc94:	54000322 	b.cs	bcf8 <f0+0x1158>  // b.hs, b.nlast
    bc98:	d350fc22 	lsr	x2, x1, #16
    bc9c:	f949fc63 	ldr	x3, [x3, #5112]
    bca0:	8b020842 	add	x2, x2, x2, lsl #2
    bca4:	d37df042 	lsl	x2, x2, #3
    bca8:	8b020060 	add	x0, x3, x2
    bcac:	f9401017 	ldr	x23, [x0, #32]
    bcb0:	b4000257 	cbz	x23, bcf8 <f0+0x1158>
    bcb4:	38626862 	ldrb	w2, [x3, x2]
    bcb8:	7100085f 	cmp	w2, #0x2
    bcbc:	54009b40 	b.eq	d024 <f0+0x2484>  // b.none
    bcc0:	7100045f 	cmp	w2, #0x1
    bcc4:	540001a1 	b.ne	bcf8 <f0+0x1158>  // b.any
    bcc8:	29430002 	ldp	w2, w0, [x0, #24]
    bccc:	92403c21 	and	x1, x1, #0xffff
    bcd0:	9b027c21 	mul	x1, x1, x2
    bcd4:	d360fc21 	lsr	x1, x1, #32
    bcd8:	eb00003f 	cmp	x1, x0
    bcdc:	540000e2 	b.cs	bcf8 <f0+0x1158>  // b.hs, b.nlast
    bce0:	8b0102f7 	add	x23, x23, x1
    bce4:	394002e0 	ldrb	w0, [x23]
    bce8:	7103fc1f 	cmp	w0, #0xff
    bcec:	5400a260 	b.eq	d138 <f0+0x2598>  // b.none
    bcf0:	52800020 	mov	w0, #0x1                   	// #1
    bcf4:	390002e0 	strb	w0, [x23]
    bcf8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bcfc:	911223e1 	add	x1, sp, #0x488
    bd00:	52800020 	mov	w0, #0x1                   	// #1
    bd04:	f90247e2 	str	x2, [sp, #1160]
    bd08:	f9024bf5 	str	x21, [sp, #1168]
    bd0c:	97ffe7c1 	bl	5c10 <fwp_data.part.0.constprop.0>
    bd10:	91190283 	add	x3, x20, #0x640
    bd14:	aa0003f5 	mov	x21, x0
    bd18:	f949d861 	ldr	x1, [x3, #5040]
    bd1c:	f949ec60 	ldr	x0, [x3, #5080]
    bd20:	cb0102a1 	sub	x1, x21, x1
    bd24:	eb00403f 	cmp	x1, x0, lsl #16
    bd28:	54000322 	b.cs	bd8c <f0+0x11ec>  // b.hs, b.nlast
    bd2c:	d350fc22 	lsr	x2, x1, #16
    bd30:	f949fc63 	ldr	x3, [x3, #5112]
    bd34:	8b020842 	add	x2, x2, x2, lsl #2
    bd38:	d37df042 	lsl	x2, x2, #3
    bd3c:	8b020060 	add	x0, x3, x2
    bd40:	f9401017 	ldr	x23, [x0, #32]
    bd44:	b4000257 	cbz	x23, bd8c <f0+0x11ec>
    bd48:	38626862 	ldrb	w2, [x3, x2]
    bd4c:	7100085f 	cmp	w2, #0x2
    bd50:	54009640 	b.eq	d018 <f0+0x2478>  // b.none
    bd54:	7100045f 	cmp	w2, #0x1
    bd58:	540001a1 	b.ne	bd8c <f0+0x11ec>  // b.any
    bd5c:	29430002 	ldp	w2, w0, [x0, #24]
    bd60:	92403c21 	and	x1, x1, #0xffff
    bd64:	9b027c21 	mul	x1, x1, x2
    bd68:	d360fc21 	lsr	x1, x1, #32
    bd6c:	eb00003f 	cmp	x1, x0
    bd70:	540000e2 	b.cs	bd8c <f0+0x11ec>  // b.hs, b.nlast
    bd74:	8b0102f7 	add	x23, x23, x1
    bd78:	394002e0 	ldrb	w0, [x23]
    bd7c:	7103fc1f 	cmp	w0, #0xff
    bd80:	54009e20 	b.eq	d144 <f0+0x25a4>  // b.none
    bd84:	52800020 	mov	w0, #0x1                   	// #1
    bd88:	390002e0 	strb	w0, [x23]
    bd8c:	911263e1 	add	x1, sp, #0x498
    bd90:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd98:	52800020 	mov	w0, #0x1                   	// #1
    bd9c:	f9024ff7 	str	x23, [sp, #1176]
    bda0:	f90253f5 	str	x21, [sp, #1184]
    bda4:	97ffe79b 	bl	5c10 <fwp_data.part.0.constprop.0>
    bda8:	97ffe81e 	bl	5e20 <fwp_rc_fresh>
    bdac:	aa0003e2 	mov	x2, x0
    bdb0:	9112a3e1 	add	x1, sp, #0x4a8
    bdb4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bdb8:	52800020 	mov	w0, #0x1                   	// #1
    bdbc:	f90257f5 	str	x21, [sp, #1192]
    bdc0:	f9025be2 	str	x2, [sp, #1200]
    bdc4:	97ffe793 	bl	5c10 <fwp_data.part.0.constprop.0>
    bdc8:	97ffe816 	bl	5e20 <fwp_rc_fresh>
    bdcc:	aa0003e2 	mov	x2, x0
    bdd0:	9112e3e1 	add	x1, sp, #0x4b8
    bdd4:	52800020 	mov	w0, #0x1                   	// #1
    bdd8:	f9025ff7 	str	x23, [sp, #1208]
    bddc:	f90263e2 	str	x2, [sp, #1216]
    bde0:	97ffe78c 	bl	5c10 <fwp_data.part.0.constprop.0>
    bde4:	97ffe80f 	bl	5e20 <fwp_rc_fresh>
    bde8:	aa0003e2 	mov	x2, x0
    bdec:	911323e1 	add	x1, sp, #0x4c8
    bdf0:	52800020 	mov	w0, #0x1                   	// #1
    bdf4:	f90267f5 	str	x21, [sp, #1224]
    bdf8:	f9026be2 	str	x2, [sp, #1232]
    bdfc:	97ffe785 	bl	5c10 <fwp_data.part.0.constprop.0>
    be00:	91190283 	add	x3, x20, #0x640
    be04:	aa0003f5 	mov	x21, x0
    be08:	f949d861 	ldr	x1, [x3, #5040]
    be0c:	f949ec60 	ldr	x0, [x3, #5080]
    be10:	cb0102a1 	sub	x1, x21, x1
    be14:	eb00403f 	cmp	x1, x0, lsl #16
    be18:	54000322 	b.cs	be7c <f0+0x12dc>  // b.hs, b.nlast
    be1c:	d350fc22 	lsr	x2, x1, #16
    be20:	f949fc63 	ldr	x3, [x3, #5112]
    be24:	8b020842 	add	x2, x2, x2, lsl #2
    be28:	d37df042 	lsl	x2, x2, #3
    be2c:	8b020060 	add	x0, x3, x2
    be30:	f9401017 	ldr	x23, [x0, #32]
    be34:	b4000257 	cbz	x23, be7c <f0+0x12dc>
    be38:	38626862 	ldrb	w2, [x3, x2]
    be3c:	7100085f 	cmp	w2, #0x2
    be40:	54008fe0 	b.eq	d03c <f0+0x249c>  // b.none
    be44:	7100045f 	cmp	w2, #0x1
    be48:	540001a1 	b.ne	be7c <f0+0x12dc>  // b.any
    be4c:	29430002 	ldp	w2, w0, [x0, #24]
    be50:	92403c21 	and	x1, x1, #0xffff
    be54:	9b027c21 	mul	x1, x1, x2
    be58:	d360fc21 	lsr	x1, x1, #32
    be5c:	eb00003f 	cmp	x1, x0
    be60:	540000e2 	b.cs	be7c <f0+0x12dc>  // b.hs, b.nlast
    be64:	8b0102f7 	add	x23, x23, x1
    be68:	394002e0 	ldrb	w0, [x23]
    be6c:	7103fc1f 	cmp	w0, #0xff
    be70:	54009700 	b.eq	d150 <f0+0x25b0>  // b.none
    be74:	52800020 	mov	w0, #0x1                   	// #1
    be78:	390002e0 	strb	w0, [x23]
    be7c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be80:	911363e1 	add	x1, sp, #0x4d8
    be84:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be88:	52800020 	mov	w0, #0x1                   	// #1
    be8c:	f9026fe2 	str	x2, [sp, #1240]
    be90:	f90273f5 	str	x21, [sp, #1248]
    be94:	97ffe75f 	bl	5c10 <fwp_data.part.0.constprop.0>
    be98:	97ffe7e2 	bl	5e20 <fwp_rc_fresh>
    be9c:	aa0003e2 	mov	x2, x0
    bea0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bea4:	9113a3e1 	add	x1, sp, #0x4e8
    bea8:	52800020 	mov	w0, #0x1                   	// #1
    beac:	f90277e3 	str	x3, [sp, #1256]
    beb0:	f9027be2 	str	x2, [sp, #1264]
    beb4:	97ffe757 	bl	5c10 <fwp_data.part.0.constprop.0>
    beb8:	91190283 	add	x3, x20, #0x640
    bebc:	aa0003f5 	mov	x21, x0
    bec0:	f949d861 	ldr	x1, [x3, #5040]
    bec4:	f949ec60 	ldr	x0, [x3, #5080]
    bec8:	cb0102a1 	sub	x1, x21, x1
    becc:	eb00403f 	cmp	x1, x0, lsl #16
    bed0:	54000322 	b.cs	bf34 <f0+0x1394>  // b.hs, b.nlast
    bed4:	d350fc22 	lsr	x2, x1, #16
    bed8:	f949fc63 	ldr	x3, [x3, #5112]
    bedc:	8b020842 	add	x2, x2, x2, lsl #2
    bee0:	d37df042 	lsl	x2, x2, #3
    bee4:	8b020060 	add	x0, x3, x2
    bee8:	f9401017 	ldr	x23, [x0, #32]
    beec:	b4000257 	cbz	x23, bf34 <f0+0x1394>
    bef0:	38626862 	ldrb	w2, [x3, x2]
    bef4:	7100085f 	cmp	w2, #0x2
    bef8:	540089c0 	b.eq	d030 <f0+0x2490>  // b.none
    befc:	7100045f 	cmp	w2, #0x1
    bf00:	540001a1 	b.ne	bf34 <f0+0x1394>  // b.any
    bf04:	29430002 	ldp	w2, w0, [x0, #24]
    bf08:	92403c21 	and	x1, x1, #0xffff
    bf0c:	9b027c21 	mul	x1, x1, x2
    bf10:	d360fc21 	lsr	x1, x1, #32
    bf14:	eb00003f 	cmp	x1, x0
    bf18:	540000e2 	b.cs	bf34 <f0+0x1394>  // b.hs, b.nlast
    bf1c:	8b0102f7 	add	x23, x23, x1
    bf20:	394002e0 	ldrb	w0, [x23]
    bf24:	7103fc1f 	cmp	w0, #0xff
    bf28:	540091a0 	b.eq	d15c <f0+0x25bc>  // b.none
    bf2c:	52800020 	mov	w0, #0x1                   	// #1
    bf30:	390002e0 	strb	w0, [x23]
    bf34:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf38:	9113e3e1 	add	x1, sp, #0x4f8
    bf3c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf40:	52800020 	mov	w0, #0x1                   	// #1
    bf44:	f9027fe2 	str	x2, [sp, #1272]
    bf48:	f90283f5 	str	x21, [sp, #1280]
    bf4c:	97ffe731 	bl	5c10 <fwp_data.part.0.constprop.0>
    bf50:	91190283 	add	x3, x20, #0x640
    bf54:	aa0003f5 	mov	x21, x0
    bf58:	f949d861 	ldr	x1, [x3, #5040]
    bf5c:	f949ec60 	ldr	x0, [x3, #5080]
    bf60:	cb0102a1 	sub	x1, x21, x1
    bf64:	eb00403f 	cmp	x1, x0, lsl #16
    bf68:	54000322 	b.cs	bfcc <f0+0x142c>  // b.hs, b.nlast
    bf6c:	d350fc22 	lsr	x2, x1, #16
    bf70:	f949fc63 	ldr	x3, [x3, #5112]
    bf74:	8b020842 	add	x2, x2, x2, lsl #2
    bf78:	d37df042 	lsl	x2, x2, #3
    bf7c:	8b020060 	add	x0, x3, x2
    bf80:	f9401017 	ldr	x23, [x0, #32]
    bf84:	b4000257 	cbz	x23, bfcc <f0+0x142c>
    bf88:	38626862 	ldrb	w2, [x3, x2]
    bf8c:	7100085f 	cmp	w2, #0x2
    bf90:	54008620 	b.eq	d054 <f0+0x24b4>  // b.none
    bf94:	7100045f 	cmp	w2, #0x1
    bf98:	540001a1 	b.ne	bfcc <f0+0x142c>  // b.any
    bf9c:	29430002 	ldp	w2, w0, [x0, #24]
    bfa0:	92403c21 	and	x1, x1, #0xffff
    bfa4:	9b027c21 	mul	x1, x1, x2
    bfa8:	d360fc21 	lsr	x1, x1, #32
    bfac:	eb00003f 	cmp	x1, x0
    bfb0:	540000e2 	b.cs	bfcc <f0+0x142c>  // b.hs, b.nlast
    bfb4:	8b0102f7 	add	x23, x23, x1
    bfb8:	394002e0 	ldrb	w0, [x23]
    bfbc:	7103fc1f 	cmp	w0, #0xff
    bfc0:	54008d40 	b.eq	d168 <f0+0x25c8>  // b.none
    bfc4:	52800020 	mov	w0, #0x1                   	// #1
    bfc8:	390002e0 	strb	w0, [x23]
    bfcc:	911423e1 	add	x1, sp, #0x508
    bfd0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	f90287f7 	str	x23, [sp, #1288]
    bfdc:	f9028bf5 	str	x21, [sp, #1296]
    bfe0:	97ffe70c 	bl	5c10 <fwp_data.part.0.constprop.0>
    bfe4:	97ffe78f 	bl	5e20 <fwp_rc_fresh>
    bfe8:	aa0003e2 	mov	x2, x0
    bfec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bff0:	911463e1 	add	x1, sp, #0x518
    bff4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bff8:	52800020 	mov	w0, #0x1                   	// #1
    bffc:	f9028fe3 	str	x3, [sp, #1304]
    c000:	f90293e2 	str	x2, [sp, #1312]
    c004:	97ffe703 	bl	5c10 <fwp_data.part.0.constprop.0>
    c008:	97ffe786 	bl	5e20 <fwp_rc_fresh>
    c00c:	aa0003e2 	mov	x2, x0
    c010:	9114a3e1 	add	x1, sp, #0x528
    c014:	52800020 	mov	w0, #0x1                   	// #1
    c018:	f90297f7 	str	x23, [sp, #1320]
    c01c:	f9029be2 	str	x2, [sp, #1328]
    c020:	97ffe6fc 	bl	5c10 <fwp_data.part.0.constprop.0>
    c024:	91190283 	add	x3, x20, #0x640
    c028:	aa0003f5 	mov	x21, x0
    c02c:	f949d861 	ldr	x1, [x3, #5040]
    c030:	f949ec60 	ldr	x0, [x3, #5080]
    c034:	cb0102a1 	sub	x1, x21, x1
    c038:	eb00403f 	cmp	x1, x0, lsl #16
    c03c:	54000322 	b.cs	c0a0 <f0+0x1500>  // b.hs, b.nlast
    c040:	d350fc22 	lsr	x2, x1, #16
    c044:	f949fc63 	ldr	x3, [x3, #5112]
    c048:	8b020842 	add	x2, x2, x2, lsl #2
    c04c:	d37df042 	lsl	x2, x2, #3
    c050:	8b020060 	add	x0, x3, x2
    c054:	f9401017 	ldr	x23, [x0, #32]
    c058:	b4000257 	cbz	x23, c0a0 <f0+0x1500>
    c05c:	38626862 	ldrb	w2, [x3, x2]
    c060:	7100085f 	cmp	w2, #0x2
    c064:	54007f20 	b.eq	d048 <f0+0x24a8>  // b.none
    c068:	7100045f 	cmp	w2, #0x1
    c06c:	540001a1 	b.ne	c0a0 <f0+0x1500>  // b.any
    c070:	29430002 	ldp	w2, w0, [x0, #24]
    c074:	92403c21 	and	x1, x1, #0xffff
    c078:	9b027c21 	mul	x1, x1, x2
    c07c:	d360fc21 	lsr	x1, x1, #32
    c080:	eb00003f 	cmp	x1, x0
    c084:	540000e2 	b.cs	c0a0 <f0+0x1500>  // b.hs, b.nlast
    c088:	8b0102f7 	add	x23, x23, x1
    c08c:	394002e0 	ldrb	w0, [x23]
    c090:	7103fc1f 	cmp	w0, #0xff
    c094:	54008700 	b.eq	d174 <f0+0x25d4>  // b.none
    c098:	52800020 	mov	w0, #0x1                   	// #1
    c09c:	390002e0 	strb	w0, [x23]
    c0a0:	9114e3e1 	add	x1, sp, #0x538
    c0a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c0a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c0ac:	52800020 	mov	w0, #0x1                   	// #1
    c0b0:	f9029ff7 	str	x23, [sp, #1336]
    c0b4:	f902a3f5 	str	x21, [sp, #1344]
    c0b8:	97ffe6d6 	bl	5c10 <fwp_data.part.0.constprop.0>
    c0bc:	97ffe759 	bl	5e20 <fwp_rc_fresh>
    c0c0:	aa0003e2 	mov	x2, x0
    c0c4:	911523e1 	add	x1, sp, #0x548
    c0c8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c0cc:	52800020 	mov	w0, #0x1                   	// #1
    c0d0:	f902a7f5 	str	x21, [sp, #1352]
    c0d4:	f902abe2 	str	x2, [sp, #1360]
    c0d8:	97ffe6ce 	bl	5c10 <fwp_data.part.0.constprop.0>
    c0dc:	97ffe751 	bl	5e20 <fwp_rc_fresh>
    c0e0:	aa0003e2 	mov	x2, x0
    c0e4:	911563e1 	add	x1, sp, #0x558
    c0e8:	52800020 	mov	w0, #0x1                   	// #1
    c0ec:	f902aff7 	str	x23, [sp, #1368]
    c0f0:	f902b3e2 	str	x2, [sp, #1376]
    c0f4:	97ffe6c7 	bl	5c10 <fwp_data.part.0.constprop.0>
    c0f8:	97ffe74a 	bl	5e20 <fwp_rc_fresh>
    c0fc:	aa0003e2 	mov	x2, x0
    c100:	9115a3e1 	add	x1, sp, #0x568
    c104:	52800020 	mov	w0, #0x1                   	// #1
    c108:	f902b7f5 	str	x21, [sp, #1384]
    c10c:	f902bbe2 	str	x2, [sp, #1392]
    c110:	97ffe6c0 	bl	5c10 <fwp_data.part.0.constprop.0>
    c114:	91190283 	add	x3, x20, #0x640
    c118:	aa0003f5 	mov	x21, x0
    c11c:	f949d861 	ldr	x1, [x3, #5040]
    c120:	f949ec60 	ldr	x0, [x3, #5080]
    c124:	cb0102a1 	sub	x1, x21, x1
    c128:	eb00403f 	cmp	x1, x0, lsl #16
    c12c:	54000322 	b.cs	c190 <f0+0x15f0>  // b.hs, b.nlast
    c130:	d350fc22 	lsr	x2, x1, #16
    c134:	f949fc63 	ldr	x3, [x3, #5112]
    c138:	8b020842 	add	x2, x2, x2, lsl #2
    c13c:	d37df042 	lsl	x2, x2, #3
    c140:	8b020060 	add	x0, x3, x2
    c144:	f9401017 	ldr	x23, [x0, #32]
    c148:	b4000257 	cbz	x23, c190 <f0+0x15f0>
    c14c:	38626862 	ldrb	w2, [x3, x2]
    c150:	7100085f 	cmp	w2, #0x2
    c154:	54006cc0 	b.eq	ceec <f0+0x234c>  // b.none
    c158:	7100045f 	cmp	w2, #0x1
    c15c:	540001a1 	b.ne	c190 <f0+0x15f0>  // b.any
    c160:	29430002 	ldp	w2, w0, [x0, #24]
    c164:	92403c21 	and	x1, x1, #0xffff
    c168:	9b027c21 	mul	x1, x1, x2
    c16c:	d360fc21 	lsr	x1, x1, #32
    c170:	eb00003f 	cmp	x1, x0
    c174:	540000e2 	b.cs	c190 <f0+0x15f0>  // b.hs, b.nlast
    c178:	8b0102f7 	add	x23, x23, x1
    c17c:	394002e0 	ldrb	w0, [x23]
    c180:	7103fc1f 	cmp	w0, #0xff
    c184:	54007fe0 	b.eq	d180 <f0+0x25e0>  // b.none
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	390002e0 	strb	w0, [x23]
    c190:	9115e3e1 	add	x1, sp, #0x578
    c194:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c198:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c19c:	52800020 	mov	w0, #0x1                   	// #1
    c1a0:	f902bff7 	str	x23, [sp, #1400]
    c1a4:	f902c3f5 	str	x21, [sp, #1408]
    c1a8:	97ffe69a 	bl	5c10 <fwp_data.part.0.constprop.0>
    c1ac:	97ffe71d 	bl	5e20 <fwp_rc_fresh>
    c1b0:	aa0003e2 	mov	x2, x0
    c1b4:	911623e1 	add	x1, sp, #0x588
    c1b8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c1bc:	52800020 	mov	w0, #0x1                   	// #1
    c1c0:	f902c7f5 	str	x21, [sp, #1416]
    c1c4:	f902cbe2 	str	x2, [sp, #1424]
    c1c8:	97ffe692 	bl	5c10 <fwp_data.part.0.constprop.0>
    c1cc:	97ffe715 	bl	5e20 <fwp_rc_fresh>
    c1d0:	aa0003e2 	mov	x2, x0
    c1d4:	911663e1 	add	x1, sp, #0x598
    c1d8:	52800020 	mov	w0, #0x1                   	// #1
    c1dc:	f902cff7 	str	x23, [sp, #1432]
    c1e0:	f902d3e2 	str	x2, [sp, #1440]
    c1e4:	97ffe68b 	bl	5c10 <fwp_data.part.0.constprop.0>
    c1e8:	97ffe70e 	bl	5e20 <fwp_rc_fresh>
    c1ec:	aa0003e2 	mov	x2, x0
    c1f0:	9116a3e1 	add	x1, sp, #0x5a8
    c1f4:	52800020 	mov	w0, #0x1                   	// #1
    c1f8:	f902d7f5 	str	x21, [sp, #1448]
    c1fc:	f902dbe2 	str	x2, [sp, #1456]
    c200:	97ffe684 	bl	5c10 <fwp_data.part.0.constprop.0>
    c204:	97ffe707 	bl	5e20 <fwp_rc_fresh>
    c208:	aa0003e2 	mov	x2, x0
    c20c:	9116e3e1 	add	x1, sp, #0x5b8
    c210:	52800020 	mov	w0, #0x1                   	// #1
    c214:	f902dff7 	str	x23, [sp, #1464]
    c218:	f902e3e2 	str	x2, [sp, #1472]
    c21c:	97ffe67d 	bl	5c10 <fwp_data.part.0.constprop.0>
    c220:	97ffe700 	bl	5e20 <fwp_rc_fresh>
    c224:	aa0003e2 	mov	x2, x0
    c228:	911723e1 	add	x1, sp, #0x5c8
    c22c:	52800020 	mov	w0, #0x1                   	// #1
    c230:	f902e7f5 	str	x21, [sp, #1480]
    c234:	f902ebe2 	str	x2, [sp, #1488]
    c238:	97ffe676 	bl	5c10 <fwp_data.part.0.constprop.0>
    c23c:	91190283 	add	x3, x20, #0x640
    c240:	aa0003f5 	mov	x21, x0
    c244:	f949d861 	ldr	x1, [x3, #5040]
    c248:	f949ec60 	ldr	x0, [x3, #5080]
    c24c:	cb0102a1 	sub	x1, x21, x1
    c250:	eb00403f 	cmp	x1, x0, lsl #16
    c254:	54000322 	b.cs	c2b8 <f0+0x1718>  // b.hs, b.nlast
    c258:	d350fc22 	lsr	x2, x1, #16
    c25c:	f949fc63 	ldr	x3, [x3, #5112]
    c260:	8b020842 	add	x2, x2, x2, lsl #2
    c264:	d37df042 	lsl	x2, x2, #3
    c268:	8b020060 	add	x0, x3, x2
    c26c:	f9401017 	ldr	x23, [x0, #32]
    c270:	b4000257 	cbz	x23, c2b8 <f0+0x1718>
    c274:	38626862 	ldrb	w2, [x3, x2]
    c278:	7100085f 	cmp	w2, #0x2
    c27c:	54006320 	b.eq	cee0 <f0+0x2340>  // b.none
    c280:	7100045f 	cmp	w2, #0x1
    c284:	540001a1 	b.ne	c2b8 <f0+0x1718>  // b.any
    c288:	29430002 	ldp	w2, w0, [x0, #24]
    c28c:	92403c21 	and	x1, x1, #0xffff
    c290:	9b027c21 	mul	x1, x1, x2
    c294:	d360fc21 	lsr	x1, x1, #32
    c298:	eb00003f 	cmp	x1, x0
    c29c:	540000e2 	b.cs	c2b8 <f0+0x1718>  // b.hs, b.nlast
    c2a0:	8b0102f7 	add	x23, x23, x1
    c2a4:	394002e0 	ldrb	w0, [x23]
    c2a8:	7103fc1f 	cmp	w0, #0xff
    c2ac:	54007700 	b.eq	d18c <f0+0x25ec>  // b.none
    c2b0:	52800020 	mov	w0, #0x1                   	// #1
    c2b4:	390002e0 	strb	w0, [x23]
    c2b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c2bc:	911763e1 	add	x1, sp, #0x5d8
    c2c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c2c4:	52800020 	mov	w0, #0x1                   	// #1
    c2c8:	f902efe2 	str	x2, [sp, #1496]
    c2cc:	f902f3f5 	str	x21, [sp, #1504]
    c2d0:	97ffe650 	bl	5c10 <fwp_data.part.0.constprop.0>
    c2d4:	97ffe6d3 	bl	5e20 <fwp_rc_fresh>
    c2d8:	aa0003e2 	mov	x2, x0
    c2dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c2e0:	9117a3e1 	add	x1, sp, #0x5e8
    c2e4:	52800020 	mov	w0, #0x1                   	// #1
    c2e8:	f902f7e3 	str	x3, [sp, #1512]
    c2ec:	f902fbe2 	str	x2, [sp, #1520]
    c2f0:	97ffe648 	bl	5c10 <fwp_data.part.0.constprop.0>
    c2f4:	91190283 	add	x3, x20, #0x640
    c2f8:	aa0003f5 	mov	x21, x0
    c2fc:	f949d861 	ldr	x1, [x3, #5040]
    c300:	f949ec60 	ldr	x0, [x3, #5080]
    c304:	cb0102a1 	sub	x1, x21, x1
    c308:	eb00403f 	cmp	x1, x0, lsl #16
    c30c:	54000322 	b.cs	c370 <f0+0x17d0>  // b.hs, b.nlast
    c310:	d350fc22 	lsr	x2, x1, #16
    c314:	f949fc63 	ldr	x3, [x3, #5112]
    c318:	8b020842 	add	x2, x2, x2, lsl #2
    c31c:	d37df042 	lsl	x2, x2, #3
    c320:	8b020060 	add	x0, x3, x2
    c324:	f9401017 	ldr	x23, [x0, #32]
    c328:	b4000257 	cbz	x23, c370 <f0+0x17d0>
    c32c:	38626862 	ldrb	w2, [x3, x2]
    c330:	7100085f 	cmp	w2, #0x2
    c334:	54005e80 	b.eq	cf04 <f0+0x2364>  // b.none
    c338:	7100045f 	cmp	w2, #0x1
    c33c:	540001a1 	b.ne	c370 <f0+0x17d0>  // b.any
    c340:	29430002 	ldp	w2, w0, [x0, #24]
    c344:	92403c21 	and	x1, x1, #0xffff
    c348:	9b027c21 	mul	x1, x1, x2
    c34c:	d360fc21 	lsr	x1, x1, #32
    c350:	eb00003f 	cmp	x1, x0
    c354:	540000e2 	b.cs	c370 <f0+0x17d0>  // b.hs, b.nlast
    c358:	8b0102f7 	add	x23, x23, x1
    c35c:	394002e0 	ldrb	w0, [x23]
    c360:	7103fc1f 	cmp	w0, #0xff
    c364:	540071a0 	b.eq	d198 <f0+0x25f8>  // b.none
    c368:	52800020 	mov	w0, #0x1                   	// #1
    c36c:	390002e0 	strb	w0, [x23]
    c370:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c374:	9117e3e1 	add	x1, sp, #0x5f8
    c378:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c37c:	52800020 	mov	w0, #0x1                   	// #1
    c380:	f902ffe2 	str	x2, [sp, #1528]
    c384:	f90303f5 	str	x21, [sp, #1536]
    c388:	97ffe622 	bl	5c10 <fwp_data.part.0.constprop.0>
    c38c:	91190283 	add	x3, x20, #0x640
    c390:	aa0003f5 	mov	x21, x0
    c394:	f949d861 	ldr	x1, [x3, #5040]
    c398:	f949ec60 	ldr	x0, [x3, #5080]
    c39c:	cb0102a1 	sub	x1, x21, x1
    c3a0:	eb00403f 	cmp	x1, x0, lsl #16
    c3a4:	54000322 	b.cs	c408 <f0+0x1868>  // b.hs, b.nlast
    c3a8:	d350fc22 	lsr	x2, x1, #16
    c3ac:	f949fc63 	ldr	x3, [x3, #5112]
    c3b0:	8b020842 	add	x2, x2, x2, lsl #2
    c3b4:	d37df042 	lsl	x2, x2, #3
    c3b8:	8b020060 	add	x0, x3, x2
    c3bc:	f9401017 	ldr	x23, [x0, #32]
    c3c0:	b4000257 	cbz	x23, c408 <f0+0x1868>
    c3c4:	38626862 	ldrb	w2, [x3, x2]
    c3c8:	7100085f 	cmp	w2, #0x2
    c3cc:	54005960 	b.eq	cef8 <f0+0x2358>  // b.none
    c3d0:	7100045f 	cmp	w2, #0x1
    c3d4:	540001a1 	b.ne	c408 <f0+0x1868>  // b.any
    c3d8:	29430002 	ldp	w2, w0, [x0, #24]
    c3dc:	92403c21 	and	x1, x1, #0xffff
    c3e0:	9b027c21 	mul	x1, x1, x2
    c3e4:	d360fc21 	lsr	x1, x1, #32
    c3e8:	eb00003f 	cmp	x1, x0
    c3ec:	540000e2 	b.cs	c408 <f0+0x1868>  // b.hs, b.nlast
    c3f0:	8b0102f7 	add	x23, x23, x1
    c3f4:	394002e0 	ldrb	w0, [x23]
    c3f8:	7103fc1f 	cmp	w0, #0xff
    c3fc:	54006d40 	b.eq	d1a4 <f0+0x2604>  // b.none
    c400:	52800020 	mov	w0, #0x1                   	// #1
    c404:	390002e0 	strb	w0, [x23]
    c408:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c40c:	911823e1 	add	x1, sp, #0x608
    c410:	52800020 	mov	w0, #0x1                   	// #1
    c414:	f90307e2 	str	x2, [sp, #1544]
    c418:	f9030bf5 	str	x21, [sp, #1552]
    c41c:	97ffe5fd 	bl	5c10 <fwp_data.part.0.constprop.0>
    c420:	91190283 	add	x3, x20, #0x640
    c424:	aa0003f7 	mov	x23, x0
    c428:	f949d861 	ldr	x1, [x3, #5040]
    c42c:	f949ec60 	ldr	x0, [x3, #5080]
    c430:	cb0102e1 	sub	x1, x23, x1
    c434:	eb00403f 	cmp	x1, x0, lsl #16
    c438:	54000322 	b.cs	c49c <f0+0x18fc>  // b.hs, b.nlast
    c43c:	d350fc22 	lsr	x2, x1, #16
    c440:	f949fc63 	ldr	x3, [x3, #5112]
    c444:	8b020842 	add	x2, x2, x2, lsl #2
    c448:	d37df042 	lsl	x2, x2, #3
    c44c:	8b020060 	add	x0, x3, x2
    c450:	f9401015 	ldr	x21, [x0, #32]
    c454:	b4000255 	cbz	x21, c49c <f0+0x18fc>
    c458:	38626862 	ldrb	w2, [x3, x2]
    c45c:	7100085f 	cmp	w2, #0x2
    c460:	540055e0 	b.eq	cf1c <f0+0x237c>  // b.none
    c464:	7100045f 	cmp	w2, #0x1
    c468:	540001a1 	b.ne	c49c <f0+0x18fc>  // b.any
    c46c:	29430002 	ldp	w2, w0, [x0, #24]
    c470:	92403c21 	and	x1, x1, #0xffff
    c474:	9b027c21 	mul	x1, x1, x2
    c478:	d360fc21 	lsr	x1, x1, #32
    c47c:	eb00003f 	cmp	x1, x0
    c480:	540000e2 	b.cs	c49c <f0+0x18fc>  // b.hs, b.nlast
    c484:	8b0102b5 	add	x21, x21, x1
    c488:	394002a0 	ldrb	w0, [x21]
    c48c:	7103fc1f 	cmp	w0, #0xff
    c490:	54006900 	b.eq	d1b0 <f0+0x2610>  // b.none
    c494:	52800020 	mov	w0, #0x1                   	// #1
    c498:	390002a0 	strb	w0, [x21]
    c49c:	911863e1 	add	x1, sp, #0x618
    c4a0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c4a4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c4a8:	52800020 	mov	w0, #0x1                   	// #1
    c4ac:	f9030ff5 	str	x21, [sp, #1560]
    c4b0:	f90313f7 	str	x23, [sp, #1568]
    c4b4:	97ffe5d7 	bl	5c10 <fwp_data.part.0.constprop.0>
    c4b8:	97ffe65a 	bl	5e20 <fwp_rc_fresh>
    c4bc:	aa0003e2 	mov	x2, x0
    c4c0:	9118a3e1 	add	x1, sp, #0x628
    c4c4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c4c8:	52800020 	mov	w0, #0x1                   	// #1
    c4cc:	f90317f7 	str	x23, [sp, #1576]
    c4d0:	f9031be2 	str	x2, [sp, #1584]
    c4d4:	97ffe5cf 	bl	5c10 <fwp_data.part.0.constprop.0>
    c4d8:	97ffe652 	bl	5e20 <fwp_rc_fresh>
    c4dc:	aa0003e2 	mov	x2, x0
    c4e0:	9118e3e1 	add	x1, sp, #0x638
    c4e4:	52800020 	mov	w0, #0x1                   	// #1
    c4e8:	f9031ff5 	str	x21, [sp, #1592]
    c4ec:	f90323e2 	str	x2, [sp, #1600]
    c4f0:	97ffe5c8 	bl	5c10 <fwp_data.part.0.constprop.0>
    c4f4:	97ffe64b 	bl	5e20 <fwp_rc_fresh>
    c4f8:	aa0003e2 	mov	x2, x0
    c4fc:	911923e1 	add	x1, sp, #0x648
    c500:	52800020 	mov	w0, #0x1                   	// #1
    c504:	f90327f7 	str	x23, [sp, #1608]
    c508:	f9032be2 	str	x2, [sp, #1616]
    c50c:	97ffe5c1 	bl	5c10 <fwp_data.part.0.constprop.0>
    c510:	97ffe644 	bl	5e20 <fwp_rc_fresh>
    c514:	aa0003e2 	mov	x2, x0
    c518:	911963e1 	add	x1, sp, #0x658
    c51c:	52800020 	mov	w0, #0x1                   	// #1
    c520:	f9032ff5 	str	x21, [sp, #1624]
    c524:	f90333e2 	str	x2, [sp, #1632]
    c528:	97ffe5ba 	bl	5c10 <fwp_data.part.0.constprop.0>
    c52c:	97ffe63d 	bl	5e20 <fwp_rc_fresh>
    c530:	aa0003e2 	mov	x2, x0
    c534:	9119a3e1 	add	x1, sp, #0x668
    c538:	52800020 	mov	w0, #0x1                   	// #1
    c53c:	f90337f7 	str	x23, [sp, #1640]
    c540:	f9033be2 	str	x2, [sp, #1648]
    c544:	97ffe5b3 	bl	5c10 <fwp_data.part.0.constprop.0>
    c548:	97ffe636 	bl	5e20 <fwp_rc_fresh>
    c54c:	aa0003e2 	mov	x2, x0
    c550:	9119e3e1 	add	x1, sp, #0x678
    c554:	52800020 	mov	w0, #0x1                   	// #1
    c558:	f9033ff5 	str	x21, [sp, #1656]
    c55c:	f90343e2 	str	x2, [sp, #1664]
    c560:	97ffe5ac 	bl	5c10 <fwp_data.part.0.constprop.0>
    c564:	91190283 	add	x3, x20, #0x640
    c568:	aa0003f5 	mov	x21, x0
    c56c:	f949d861 	ldr	x1, [x3, #5040]
    c570:	f949ec60 	ldr	x0, [x3, #5080]
    c574:	cb0102a1 	sub	x1, x21, x1
    c578:	eb00403f 	cmp	x1, x0, lsl #16
    c57c:	54000322 	b.cs	c5e0 <f0+0x1a40>  // b.hs, b.nlast
    c580:	d350fc22 	lsr	x2, x1, #16
    c584:	f949fc63 	ldr	x3, [x3, #5112]
    c588:	8b020842 	add	x2, x2, x2, lsl #2
    c58c:	d37df042 	lsl	x2, x2, #3
    c590:	8b020060 	add	x0, x3, x2
    c594:	f9401017 	ldr	x23, [x0, #32]
    c598:	b4000257 	cbz	x23, c5e0 <f0+0x1a40>
    c59c:	38626862 	ldrb	w2, [x3, x2]
    c5a0:	7100085f 	cmp	w2, #0x2
    c5a4:	54004b60 	b.eq	cf10 <f0+0x2370>  // b.none
    c5a8:	7100045f 	cmp	w2, #0x1
    c5ac:	540001a1 	b.ne	c5e0 <f0+0x1a40>  // b.any
    c5b0:	29430002 	ldp	w2, w0, [x0, #24]
    c5b4:	92403c21 	and	x1, x1, #0xffff
    c5b8:	9b027c21 	mul	x1, x1, x2
    c5bc:	d360fc21 	lsr	x1, x1, #32
    c5c0:	eb00003f 	cmp	x1, x0
    c5c4:	540000e2 	b.cs	c5e0 <f0+0x1a40>  // b.hs, b.nlast
    c5c8:	8b0102f7 	add	x23, x23, x1
    c5cc:	394002e0 	ldrb	w0, [x23]
    c5d0:	7103fc1f 	cmp	w0, #0xff
    c5d4:	54005f40 	b.eq	d1bc <f0+0x261c>  // b.none
    c5d8:	52800020 	mov	w0, #0x1                   	// #1
    c5dc:	390002e0 	strb	w0, [x23]
    c5e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c5e4:	911a23e1 	add	x1, sp, #0x688
    c5e8:	52800020 	mov	w0, #0x1                   	// #1
    c5ec:	f90347e2 	str	x2, [sp, #1672]
    c5f0:	f9034bf5 	str	x21, [sp, #1680]
    c5f4:	97ffe587 	bl	5c10 <fwp_data.part.0.constprop.0>
    c5f8:	91190283 	add	x3, x20, #0x640
    c5fc:	aa0003f5 	mov	x21, x0
    c600:	f949d861 	ldr	x1, [x3, #5040]
    c604:	f949ec60 	ldr	x0, [x3, #5080]
    c608:	cb0102a1 	sub	x1, x21, x1
    c60c:	eb00403f 	cmp	x1, x0, lsl #16
    c610:	54000322 	b.cs	c674 <f0+0x1ad4>  // b.hs, b.nlast
    c614:	d350fc22 	lsr	x2, x1, #16
    c618:	f949fc63 	ldr	x3, [x3, #5112]
    c61c:	8b020842 	add	x2, x2, x2, lsl #2
    c620:	d37df042 	lsl	x2, x2, #3
    c624:	8b020060 	add	x0, x3, x2
    c628:	f9401017 	ldr	x23, [x0, #32]
    c62c:	b4000257 	cbz	x23, c674 <f0+0x1ad4>
    c630:	38626862 	ldrb	w2, [x3, x2]
    c634:	7100085f 	cmp	w2, #0x2
    c638:	540047e0 	b.eq	cf34 <f0+0x2394>  // b.none
    c63c:	7100045f 	cmp	w2, #0x1
    c640:	540001a1 	b.ne	c674 <f0+0x1ad4>  // b.any
    c644:	29430002 	ldp	w2, w0, [x0, #24]
    c648:	92403c21 	and	x1, x1, #0xffff
    c64c:	9b027c21 	mul	x1, x1, x2
    c650:	d360fc21 	lsr	x1, x1, #32
    c654:	eb00003f 	cmp	x1, x0
    c658:	540000e2 	b.cs	c674 <f0+0x1ad4>  // b.hs, b.nlast
    c65c:	8b0102f7 	add	x23, x23, x1
    c660:	394002e0 	ldrb	w0, [x23]
    c664:	7103fc1f 	cmp	w0, #0xff
    c668:	54005b00 	b.eq	d1c8 <f0+0x2628>  // b.none
    c66c:	52800020 	mov	w0, #0x1                   	// #1
    c670:	390002e0 	strb	w0, [x23]
    c674:	911a63e1 	add	x1, sp, #0x698
    c678:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c67c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c680:	52800020 	mov	w0, #0x1                   	// #1
    c684:	f9034ff7 	str	x23, [sp, #1688]
    c688:	f90353f5 	str	x21, [sp, #1696]
    c68c:	97ffe561 	bl	5c10 <fwp_data.part.0.constprop.0>
    c690:	97ffe5e4 	bl	5e20 <fwp_rc_fresh>
    c694:	aa0003e2 	mov	x2, x0
    c698:	911aa3e1 	add	x1, sp, #0x6a8
    c69c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c6a0:	52800020 	mov	w0, #0x1                   	// #1
    c6a4:	f90357f5 	str	x21, [sp, #1704]
    c6a8:	f9035be2 	str	x2, [sp, #1712]
    c6ac:	97ffe559 	bl	5c10 <fwp_data.part.0.constprop.0>
    c6b0:	97ffe5dc 	bl	5e20 <fwp_rc_fresh>
    c6b4:	aa0003e2 	mov	x2, x0
    c6b8:	911ae3e1 	add	x1, sp, #0x6b8
    c6bc:	52800020 	mov	w0, #0x1                   	// #1
    c6c0:	f9035ff7 	str	x23, [sp, #1720]
    c6c4:	f90363e2 	str	x2, [sp, #1728]
    c6c8:	97ffe552 	bl	5c10 <fwp_data.part.0.constprop.0>
    c6cc:	97ffe5d5 	bl	5e20 <fwp_rc_fresh>
    c6d0:	aa0003e2 	mov	x2, x0
    c6d4:	911b23e1 	add	x1, sp, #0x6c8
    c6d8:	52800020 	mov	w0, #0x1                   	// #1
    c6dc:	f90367f5 	str	x21, [sp, #1736]
    c6e0:	f9036be2 	str	x2, [sp, #1744]
    c6e4:	97ffe54b 	bl	5c10 <fwp_data.part.0.constprop.0>
    c6e8:	91190283 	add	x3, x20, #0x640
    c6ec:	aa0003f5 	mov	x21, x0
    c6f0:	f949d861 	ldr	x1, [x3, #5040]
    c6f4:	f949ec60 	ldr	x0, [x3, #5080]
    c6f8:	cb0102a1 	sub	x1, x21, x1
    c6fc:	eb00403f 	cmp	x1, x0, lsl #16
    c700:	54000322 	b.cs	c764 <f0+0x1bc4>  // b.hs, b.nlast
    c704:	d350fc22 	lsr	x2, x1, #16
    c708:	f949fc63 	ldr	x3, [x3, #5112]
    c70c:	8b020842 	add	x2, x2, x2, lsl #2
    c710:	d37df042 	lsl	x2, x2, #3
    c714:	8b020060 	add	x0, x3, x2
    c718:	f9401017 	ldr	x23, [x0, #32]
    c71c:	b4000257 	cbz	x23, c764 <f0+0x1bc4>
    c720:	38626862 	ldrb	w2, [x3, x2]
    c724:	7100085f 	cmp	w2, #0x2
    c728:	54004000 	b.eq	cf28 <f0+0x2388>  // b.none
    c72c:	7100045f 	cmp	w2, #0x1
    c730:	540001a1 	b.ne	c764 <f0+0x1bc4>  // b.any
    c734:	29430002 	ldp	w2, w0, [x0, #24]
    c738:	92403c21 	and	x1, x1, #0xffff
    c73c:	9b027c21 	mul	x1, x1, x2
    c740:	d360fc21 	lsr	x1, x1, #32
    c744:	eb00003f 	cmp	x1, x0
    c748:	540000e2 	b.cs	c764 <f0+0x1bc4>  // b.hs, b.nlast
    c74c:	8b0102f7 	add	x23, x23, x1
    c750:	394002e0 	ldrb	w0, [x23]
    c754:	7103fc1f 	cmp	w0, #0xff
    c758:	540053e0 	b.eq	d1d4 <f0+0x2634>  // b.none
    c75c:	52800020 	mov	w0, #0x1                   	// #1
    c760:	390002e0 	strb	w0, [x23]
    c764:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c768:	911b63e1 	add	x1, sp, #0x6d8
    c76c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c770:	52800020 	mov	w0, #0x1                   	// #1
    c774:	f9036fe2 	str	x2, [sp, #1752]
    c778:	f90373f5 	str	x21, [sp, #1760]
    c77c:	97ffe525 	bl	5c10 <fwp_data.part.0.constprop.0>
    c780:	97ffe5a8 	bl	5e20 <fwp_rc_fresh>
    c784:	aa0003e2 	mov	x2, x0
    c788:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c78c:	911ba3e1 	add	x1, sp, #0x6e8
    c790:	52800020 	mov	w0, #0x1                   	// #1
    c794:	f90377e3 	str	x3, [sp, #1768]
    c798:	f9037be2 	str	x2, [sp, #1776]
    c79c:	97ffe51d 	bl	5c10 <fwp_data.part.0.constprop.0>
    c7a0:	91190283 	add	x3, x20, #0x640
    c7a4:	aa0003f5 	mov	x21, x0
    c7a8:	f949d861 	ldr	x1, [x3, #5040]
    c7ac:	f949ec60 	ldr	x0, [x3, #5080]
    c7b0:	cb0102a1 	sub	x1, x21, x1
    c7b4:	eb00403f 	cmp	x1, x0, lsl #16
    c7b8:	54000322 	b.cs	c81c <f0+0x1c7c>  // b.hs, b.nlast
    c7bc:	d350fc22 	lsr	x2, x1, #16
    c7c0:	f949fc63 	ldr	x3, [x3, #5112]
    c7c4:	8b020842 	add	x2, x2, x2, lsl #2
    c7c8:	d37df042 	lsl	x2, x2, #3
    c7cc:	8b020060 	add	x0, x3, x2
    c7d0:	f9401017 	ldr	x23, [x0, #32]
    c7d4:	b4000257 	cbz	x23, c81c <f0+0x1c7c>
    c7d8:	38626862 	ldrb	w2, [x3, x2]
    c7dc:	7100085f 	cmp	w2, #0x2
    c7e0:	54003b60 	b.eq	cf4c <f0+0x23ac>  // b.none
    c7e4:	7100045f 	cmp	w2, #0x1
    c7e8:	540001a1 	b.ne	c81c <f0+0x1c7c>  // b.any
    c7ec:	29430002 	ldp	w2, w0, [x0, #24]
    c7f0:	92403c21 	and	x1, x1, #0xffff
    c7f4:	9b027c21 	mul	x1, x1, x2
    c7f8:	d360fc21 	lsr	x1, x1, #32
    c7fc:	eb00003f 	cmp	x1, x0
    c800:	540000e2 	b.cs	c81c <f0+0x1c7c>  // b.hs, b.nlast
    c804:	8b0102f7 	add	x23, x23, x1
    c808:	394002e0 	ldrb	w0, [x23]
    c80c:	7103fc1f 	cmp	w0, #0xff
    c810:	54004e80 	b.eq	d1e0 <f0+0x2640>  // b.none
    c814:	52800020 	mov	w0, #0x1                   	// #1
    c818:	390002e0 	strb	w0, [x23]
    c81c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c820:	911be3e1 	add	x1, sp, #0x6f8
    c824:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c828:	52800020 	mov	w0, #0x1                   	// #1
    c82c:	f9037fe2 	str	x2, [sp, #1784]
    c830:	f90383f5 	str	x21, [sp, #1792]
    c834:	97ffe4f7 	bl	5c10 <fwp_data.part.0.constprop.0>
    c838:	91190283 	add	x3, x20, #0x640
    c83c:	aa0003f5 	mov	x21, x0
    c840:	f949d861 	ldr	x1, [x3, #5040]
    c844:	f949ec60 	ldr	x0, [x3, #5080]
    c848:	cb0102a1 	sub	x1, x21, x1
    c84c:	eb00403f 	cmp	x1, x0, lsl #16
    c850:	54000322 	b.cs	c8b4 <f0+0x1d14>  // b.hs, b.nlast
    c854:	d350fc22 	lsr	x2, x1, #16
    c858:	f949fc63 	ldr	x3, [x3, #5112]
    c85c:	8b020842 	add	x2, x2, x2, lsl #2
    c860:	d37df042 	lsl	x2, x2, #3
    c864:	8b020060 	add	x0, x3, x2
    c868:	f9401017 	ldr	x23, [x0, #32]
    c86c:	b4000257 	cbz	x23, c8b4 <f0+0x1d14>
    c870:	38626862 	ldrb	w2, [x3, x2]
    c874:	7100085f 	cmp	w2, #0x2
    c878:	54003640 	b.eq	cf40 <f0+0x23a0>  // b.none
    c87c:	7100045f 	cmp	w2, #0x1
    c880:	540001a1 	b.ne	c8b4 <f0+0x1d14>  // b.any
    c884:	29430002 	ldp	w2, w0, [x0, #24]
    c888:	92403c21 	and	x1, x1, #0xffff
    c88c:	9b027c21 	mul	x1, x1, x2
    c890:	d360fc21 	lsr	x1, x1, #32
    c894:	eb00003f 	cmp	x1, x0
    c898:	540000e2 	b.cs	c8b4 <f0+0x1d14>  // b.hs, b.nlast
    c89c:	8b0102f7 	add	x23, x23, x1
    c8a0:	394002e0 	ldrb	w0, [x23]
    c8a4:	7103fc1f 	cmp	w0, #0xff
    c8a8:	54004a20 	b.eq	d1ec <f0+0x264c>  // b.none
    c8ac:	52800020 	mov	w0, #0x1                   	// #1
    c8b0:	390002e0 	strb	w0, [x23]
    c8b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c8b8:	911c23e1 	add	x1, sp, #0x708
    c8bc:	52800020 	mov	w0, #0x1                   	// #1
    c8c0:	f90387e2 	str	x2, [sp, #1800]
    c8c4:	f9038bf5 	str	x21, [sp, #1808]
    c8c8:	97ffe4d2 	bl	5c10 <fwp_data.part.0.constprop.0>
    c8cc:	91190283 	add	x3, x20, #0x640
    c8d0:	aa0003f5 	mov	x21, x0
    c8d4:	f949d861 	ldr	x1, [x3, #5040]
    c8d8:	f949ec60 	ldr	x0, [x3, #5080]
    c8dc:	cb0102a1 	sub	x1, x21, x1
    c8e0:	eb00403f 	cmp	x1, x0, lsl #16
    c8e4:	54000322 	b.cs	c948 <f0+0x1da8>  // b.hs, b.nlast
    c8e8:	d350fc22 	lsr	x2, x1, #16
    c8ec:	f949fc63 	ldr	x3, [x3, #5112]
    c8f0:	8b020842 	add	x2, x2, x2, lsl #2
    c8f4:	d37df042 	lsl	x2, x2, #3
    c8f8:	8b020060 	add	x0, x3, x2
    c8fc:	f9401017 	ldr	x23, [x0, #32]
    c900:	b4000257 	cbz	x23, c948 <f0+0x1da8>
    c904:	38626862 	ldrb	w2, [x3, x2]
    c908:	7100085f 	cmp	w2, #0x2
    c90c:	540032c0 	b.eq	cf64 <f0+0x23c4>  // b.none
    c910:	7100045f 	cmp	w2, #0x1
    c914:	540001a1 	b.ne	c948 <f0+0x1da8>  // b.any
    c918:	29430002 	ldp	w2, w0, [x0, #24]
    c91c:	92403c21 	and	x1, x1, #0xffff
    c920:	9b027c21 	mul	x1, x1, x2
    c924:	d360fc21 	lsr	x1, x1, #32
    c928:	eb00003f 	cmp	x1, x0
    c92c:	540000e2 	b.cs	c948 <f0+0x1da8>  // b.hs, b.nlast
    c930:	8b0102f7 	add	x23, x23, x1
    c934:	394002e0 	ldrb	w0, [x23]
    c938:	7103fc1f 	cmp	w0, #0xff
    c93c:	540045e0 	b.eq	d1f8 <f0+0x2658>  // b.none
    c940:	52800020 	mov	w0, #0x1                   	// #1
    c944:	390002e0 	strb	w0, [x23]
    c948:	911c63e1 	add	x1, sp, #0x718
    c94c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c950:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c954:	52800020 	mov	w0, #0x1                   	// #1
    c958:	f9038ff7 	str	x23, [sp, #1816]
    c95c:	f90393f5 	str	x21, [sp, #1824]
    c960:	97ffe4ac 	bl	5c10 <fwp_data.part.0.constprop.0>
    c964:	97ffe52f 	bl	5e20 <fwp_rc_fresh>
    c968:	aa0003e2 	mov	x2, x0
    c96c:	911ca3e1 	add	x1, sp, #0x728
    c970:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c974:	52800020 	mov	w0, #0x1                   	// #1
    c978:	f90397f5 	str	x21, [sp, #1832]
    c97c:	f9039be2 	str	x2, [sp, #1840]
    c980:	97ffe4a4 	bl	5c10 <fwp_data.part.0.constprop.0>
    c984:	97ffe527 	bl	5e20 <fwp_rc_fresh>
    c988:	aa0003e2 	mov	x2, x0
    c98c:	911ce3e1 	add	x1, sp, #0x738
    c990:	52800020 	mov	w0, #0x1                   	// #1
    c994:	f9039ff7 	str	x23, [sp, #1848]
    c998:	f903a3e2 	str	x2, [sp, #1856]
    c99c:	97ffe49d 	bl	5c10 <fwp_data.part.0.constprop.0>
    c9a0:	97ffe520 	bl	5e20 <fwp_rc_fresh>
    c9a4:	aa0003e2 	mov	x2, x0
    c9a8:	911d23e1 	add	x1, sp, #0x748
    c9ac:	52800020 	mov	w0, #0x1                   	// #1
    c9b0:	f903a7f5 	str	x21, [sp, #1864]
    c9b4:	f903abe2 	str	x2, [sp, #1872]
    c9b8:	97ffe496 	bl	5c10 <fwp_data.part.0.constprop.0>
    c9bc:	97ffe519 	bl	5e20 <fwp_rc_fresh>
    c9c0:	aa0003e2 	mov	x2, x0
    c9c4:	911d63e1 	add	x1, sp, #0x758
    c9c8:	52800020 	mov	w0, #0x1                   	// #1
    c9cc:	f903aff7 	str	x23, [sp, #1880]
    c9d0:	f903b3e2 	str	x2, [sp, #1888]
    c9d4:	97ffe48f 	bl	5c10 <fwp_data.part.0.constprop.0>
    c9d8:	97ffe512 	bl	5e20 <fwp_rc_fresh>
    c9dc:	aa0003e2 	mov	x2, x0
    c9e0:	911da3e1 	add	x1, sp, #0x768
    c9e4:	52800020 	mov	w0, #0x1                   	// #1
    c9e8:	f903b7f5 	str	x21, [sp, #1896]
    c9ec:	f903bbe2 	str	x2, [sp, #1904]
    c9f0:	97ffe488 	bl	5c10 <fwp_data.part.0.constprop.0>
    c9f4:	97ffe50b 	bl	5e20 <fwp_rc_fresh>
    c9f8:	aa0003e2 	mov	x2, x0
    c9fc:	911de3e1 	add	x1, sp, #0x778
    ca00:	52800020 	mov	w0, #0x1                   	// #1
    ca04:	f903bff7 	str	x23, [sp, #1912]
    ca08:	f903c3e2 	str	x2, [sp, #1920]
    ca0c:	97ffe481 	bl	5c10 <fwp_data.part.0.constprop.0>
    ca10:	97ffe504 	bl	5e20 <fwp_rc_fresh>
    ca14:	aa0003e2 	mov	x2, x0
    ca18:	911e23e1 	add	x1, sp, #0x788
    ca1c:	52800020 	mov	w0, #0x1                   	// #1
    ca20:	f903c7f5 	str	x21, [sp, #1928]
    ca24:	f903cbe2 	str	x2, [sp, #1936]
    ca28:	97ffe47a 	bl	5c10 <fwp_data.part.0.constprop.0>
    ca2c:	91190283 	add	x3, x20, #0x640
    ca30:	aa0003f5 	mov	x21, x0
    ca34:	f949d861 	ldr	x1, [x3, #5040]
    ca38:	f949ec60 	ldr	x0, [x3, #5080]
    ca3c:	cb0102a1 	sub	x1, x21, x1
    ca40:	eb00403f 	cmp	x1, x0, lsl #16
    ca44:	54000322 	b.cs	caa8 <f0+0x1f08>  // b.hs, b.nlast
    ca48:	d350fc22 	lsr	x2, x1, #16
    ca4c:	f949fc63 	ldr	x3, [x3, #5112]
    ca50:	8b020842 	add	x2, x2, x2, lsl #2
    ca54:	d37df042 	lsl	x2, x2, #3
    ca58:	8b020060 	add	x0, x3, x2
    ca5c:	f9401017 	ldr	x23, [x0, #32]
    ca60:	b4000257 	cbz	x23, caa8 <f0+0x1f08>
    ca64:	38626862 	ldrb	w2, [x3, x2]
    ca68:	7100085f 	cmp	w2, #0x2
    ca6c:	54002760 	b.eq	cf58 <f0+0x23b8>  // b.none
    ca70:	7100045f 	cmp	w2, #0x1
    ca74:	540001a1 	b.ne	caa8 <f0+0x1f08>  // b.any
    ca78:	29430002 	ldp	w2, w0, [x0, #24]
    ca7c:	92403c21 	and	x1, x1, #0xffff
    ca80:	9b027c21 	mul	x1, x1, x2
    ca84:	d360fc21 	lsr	x1, x1, #32
    ca88:	eb00003f 	cmp	x1, x0
    ca8c:	540000e2 	b.cs	caa8 <f0+0x1f08>  // b.hs, b.nlast
    ca90:	8b0102f7 	add	x23, x23, x1
    ca94:	394002e0 	ldrb	w0, [x23]
    ca98:	7103fc1f 	cmp	w0, #0xff
    ca9c:	54003b40 	b.eq	d204 <f0+0x2664>  // b.none
    caa0:	52800020 	mov	w0, #0x1                   	// #1
    caa4:	390002e0 	strb	w0, [x23]
    caa8:	911e63e1 	add	x1, sp, #0x798
    caac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    cab0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    cab4:	52800020 	mov	w0, #0x1                   	// #1
    cab8:	f903cff7 	str	x23, [sp, #1944]
    cabc:	f903d3f5 	str	x21, [sp, #1952]
    cac0:	97ffe454 	bl	5c10 <fwp_data.part.0.constprop.0>
    cac4:	97ffe4d7 	bl	5e20 <fwp_rc_fresh>
    cac8:	aa0003e2 	mov	x2, x0
    cacc:	911ea3e1 	add	x1, sp, #0x7a8
    cad0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    cad4:	52800020 	mov	w0, #0x1                   	// #1
    cad8:	f903d7f5 	str	x21, [sp, #1960]
    cadc:	f903dbe2 	str	x2, [sp, #1968]
    cae0:	97ffe44c 	bl	5c10 <fwp_data.part.0.constprop.0>
    cae4:	97ffe4cf 	bl	5e20 <fwp_rc_fresh>
    cae8:	aa0003e2 	mov	x2, x0
    caec:	911ee3e1 	add	x1, sp, #0x7b8
    caf0:	52800020 	mov	w0, #0x1                   	// #1
    caf4:	f903dff7 	str	x23, [sp, #1976]
    caf8:	f903e3e2 	str	x2, [sp, #1984]
    cafc:	97ffe445 	bl	5c10 <fwp_data.part.0.constprop.0>
    cb00:	97ffe4c8 	bl	5e20 <fwp_rc_fresh>
    cb04:	aa0003e2 	mov	x2, x0
    cb08:	911f23e1 	add	x1, sp, #0x7c8
    cb0c:	52800020 	mov	w0, #0x1                   	// #1
    cb10:	f903e7f5 	str	x21, [sp, #1992]
    cb14:	f903ebe2 	str	x2, [sp, #2000]
    cb18:	97ffe43e 	bl	5c10 <fwp_data.part.0.constprop.0>
    cb1c:	91190283 	add	x3, x20, #0x640
    cb20:	aa0003f5 	mov	x21, x0
    cb24:	f949d861 	ldr	x1, [x3, #5040]
    cb28:	f949ec60 	ldr	x0, [x3, #5080]
    cb2c:	cb0102a1 	sub	x1, x21, x1
    cb30:	eb00403f 	cmp	x1, x0, lsl #16
    cb34:	54000322 	b.cs	cb98 <f0+0x1ff8>  // b.hs, b.nlast
    cb38:	d350fc22 	lsr	x2, x1, #16
    cb3c:	f949fc63 	ldr	x3, [x3, #5112]
    cb40:	8b020842 	add	x2, x2, x2, lsl #2
    cb44:	d37df042 	lsl	x2, x2, #3
    cb48:	8b020060 	add	x0, x3, x2
    cb4c:	f9401017 	ldr	x23, [x0, #32]
    cb50:	b4000257 	cbz	x23, cb98 <f0+0x1ff8>
    cb54:	38626862 	ldrb	w2, [x3, x2]
    cb58:	7100085f 	cmp	w2, #0x2
    cb5c:	54002100 	b.eq	cf7c <f0+0x23dc>  // b.none
    cb60:	7100045f 	cmp	w2, #0x1
    cb64:	540001a1 	b.ne	cb98 <f0+0x1ff8>  // b.any
    cb68:	29430002 	ldp	w2, w0, [x0, #24]
    cb6c:	92403c21 	and	x1, x1, #0xffff
    cb70:	9b027c21 	mul	x1, x1, x2
    cb74:	d360fc21 	lsr	x1, x1, #32
    cb78:	eb00003f 	cmp	x1, x0
    cb7c:	540000e2 	b.cs	cb98 <f0+0x1ff8>  // b.hs, b.nlast
    cb80:	8b0102f7 	add	x23, x23, x1
    cb84:	394002e0 	ldrb	w0, [x23]
    cb88:	7103fc1f 	cmp	w0, #0xff
    cb8c:	54003420 	b.eq	d210 <f0+0x2670>  // b.none
    cb90:	52800020 	mov	w0, #0x1                   	// #1
    cb94:	390002e0 	strb	w0, [x23]
    cb98:	911f63e1 	add	x1, sp, #0x7d8
    cb9c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    cba0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    cba4:	52800020 	mov	w0, #0x1                   	// #1
    cba8:	f903eff7 	str	x23, [sp, #2008]
    cbac:	f903f3f5 	str	x21, [sp, #2016]
    cbb0:	97ffe418 	bl	5c10 <fwp_data.part.0.constprop.0>
    cbb4:	97ffe49b 	bl	5e20 <fwp_rc_fresh>
    cbb8:	aa0003e2 	mov	x2, x0
    cbbc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    cbc0:	911fa3e1 	add	x1, sp, #0x7e8
    cbc4:	52800020 	mov	w0, #0x1                   	// #1
    cbc8:	f903f7e3 	str	x3, [sp, #2024]
    cbcc:	f903fbe2 	str	x2, [sp, #2032]
    cbd0:	97ffe410 	bl	5c10 <fwp_data.part.0.constprop.0>
    cbd4:	97ffe493 	bl	5e20 <fwp_rc_fresh>
    cbd8:	aa0003e2 	mov	x2, x0
    cbdc:	911fe3e1 	add	x1, sp, #0x7f8
    cbe0:	52800020 	mov	w0, #0x1                   	// #1
    cbe4:	f903fff7 	str	x23, [sp, #2040]
    cbe8:	f90403e2 	str	x2, [sp, #2048]
    cbec:	97ffe409 	bl	5c10 <fwp_data.part.0.constprop.0>
    cbf0:	91190283 	add	x3, x20, #0x640
    cbf4:	aa0003f5 	mov	x21, x0
    cbf8:	f949d861 	ldr	x1, [x3, #5040]
    cbfc:	f949ec60 	ldr	x0, [x3, #5080]
    cc00:	cb0102a1 	sub	x1, x21, x1
    cc04:	eb00403f 	cmp	x1, x0, lsl #16
    cc08:	54000322 	b.cs	cc6c <f0+0x20cc>  // b.hs, b.nlast
    cc0c:	d350fc22 	lsr	x2, x1, #16
    cc10:	f949fc63 	ldr	x3, [x3, #5112]
    cc14:	8b020842 	add	x2, x2, x2, lsl #2
    cc18:	d37df042 	lsl	x2, x2, #3
    cc1c:	8b020060 	add	x0, x3, x2
    cc20:	f9401017 	ldr	x23, [x0, #32]
    cc24:	b4000257 	cbz	x23, cc6c <f0+0x20cc>
    cc28:	38626862 	ldrb	w2, [x3, x2]
    cc2c:	7100085f 	cmp	w2, #0x2
    cc30:	54001a00 	b.eq	cf70 <f0+0x23d0>  // b.none
    cc34:	7100045f 	cmp	w2, #0x1
    cc38:	540001a1 	b.ne	cc6c <f0+0x20cc>  // b.any
    cc3c:	29430002 	ldp	w2, w0, [x0, #24]
    cc40:	92403c21 	and	x1, x1, #0xffff
    cc44:	9b027c21 	mul	x1, x1, x2
    cc48:	d360fc21 	lsr	x1, x1, #32
    cc4c:	eb00003f 	cmp	x1, x0
    cc50:	540000e2 	b.cs	cc6c <f0+0x20cc>  // b.hs, b.nlast
    cc54:	8b0102f7 	add	x23, x23, x1
    cc58:	394002e0 	ldrb	w0, [x23]
    cc5c:	7103fc1f 	cmp	w0, #0xff
    cc60:	54002de0 	b.eq	d21c <f0+0x267c>  // b.none
    cc64:	52800020 	mov	w0, #0x1                   	// #1
    cc68:	390002e0 	strb	w0, [x23]
    cc6c:	912023e1 	add	x1, sp, #0x808
    cc70:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    cc74:	52800020 	mov	w0, #0x1                   	// #1
    cc78:	f90407e2 	str	x2, [sp, #2056]
    cc7c:	f9040bf5 	str	x21, [sp, #2064]
    cc80:	97ffe3e4 	bl	5c10 <fwp_data.part.0.constprop.0>
    cc84:	97ffe467 	bl	5e20 <fwp_rc_fresh>
    cc88:	aa0003e2 	mov	x2, x0
    cc8c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    cc90:	912063e1 	add	x1, sp, #0x818
    cc94:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    cc98:	52800020 	mov	w0, #0x1                   	// #1
    cc9c:	f9040fe3 	str	x3, [sp, #2072]
    cca0:	f90413e2 	str	x2, [sp, #2080]
    cca4:	97ffe3db 	bl	5c10 <fwp_data.part.0.constprop.0>
    cca8:	91190283 	add	x3, x20, #0x640
    ccac:	aa0003f5 	mov	x21, x0
    ccb0:	f949d861 	ldr	x1, [x3, #5040]
    ccb4:	f949ec60 	ldr	x0, [x3, #5080]
    ccb8:	cb0102a1 	sub	x1, x21, x1
    ccbc:	eb00403f 	cmp	x1, x0, lsl #16
    ccc0:	54000322 	b.cs	cd24 <f0+0x2184>  // b.hs, b.nlast
    ccc4:	d350fc22 	lsr	x2, x1, #16
    ccc8:	f949fc63 	ldr	x3, [x3, #5112]
    cccc:	8b020842 	add	x2, x2, x2, lsl #2
    ccd0:	d37df042 	lsl	x2, x2, #3
    ccd4:	8b020060 	add	x0, x3, x2
    ccd8:	f9401017 	ldr	x23, [x0, #32]
    ccdc:	b4000257 	cbz	x23, cd24 <f0+0x2184>
    cce0:	38626862 	ldrb	w2, [x3, x2]
    cce4:	7100085f 	cmp	w2, #0x2
    cce8:	54001560 	b.eq	cf94 <f0+0x23f4>  // b.none
    ccec:	7100045f 	cmp	w2, #0x1
    ccf0:	540001a1 	b.ne	cd24 <f0+0x2184>  // b.any
    ccf4:	29430002 	ldp	w2, w0, [x0, #24]
    ccf8:	92403c21 	and	x1, x1, #0xffff
    ccfc:	9b027c21 	mul	x1, x1, x2
    cd00:	d360fc21 	lsr	x1, x1, #32
    cd04:	eb00003f 	cmp	x1, x0
    cd08:	540000e2 	b.cs	cd24 <f0+0x2184>  // b.hs, b.nlast
    cd0c:	8b0102f7 	add	x23, x23, x1
    cd10:	394002e0 	ldrb	w0, [x23]
    cd14:	7103fc1f 	cmp	w0, #0xff
    cd18:	54002880 	b.eq	d228 <f0+0x2688>  // b.none
    cd1c:	52800020 	mov	w0, #0x1                   	// #1
    cd20:	390002e0 	strb	w0, [x23]
    cd24:	91190294 	add	x20, x20, #0x640
    cd28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    cd2c:	9120a3e1 	add	x1, sp, #0x828
    cd30:	52800020 	mov	w0, #0x1                   	// #1
    cd34:	f90417e2 	str	x2, [sp, #2088]
    cd38:	f9041bf5 	str	x21, [sp, #2096]
    cd3c:	97ffe3b5 	bl	5c10 <fwp_data.part.0.constprop.0>
    cd40:	f949da81 	ldr	x1, [x20, #5040]
    cd44:	aa0003f5 	mov	x21, x0
    cd48:	f949ee80 	ldr	x0, [x20, #5080]
    cd4c:	cb0102a1 	sub	x1, x21, x1
    cd50:	eb00403f 	cmp	x1, x0, lsl #16
    cd54:	54000322 	b.cs	cdb8 <f0+0x2218>  // b.hs, b.nlast
    cd58:	d350fc22 	lsr	x2, x1, #16
    cd5c:	f949fe83 	ldr	x3, [x20, #5112]
    cd60:	8b020842 	add	x2, x2, x2, lsl #2
    cd64:	d37df042 	lsl	x2, x2, #3
    cd68:	8b020060 	add	x0, x3, x2
    cd6c:	f9401014 	ldr	x20, [x0, #32]
    cd70:	b4000254 	cbz	x20, cdb8 <f0+0x2218>
    cd74:	38626862 	ldrb	w2, [x3, x2]
    cd78:	7100085f 	cmp	w2, #0x2
    cd7c:	54001060 	b.eq	cf88 <f0+0x23e8>  // b.none
    cd80:	7100045f 	cmp	w2, #0x1
    cd84:	540001a1 	b.ne	cdb8 <f0+0x2218>  // b.any
    cd88:	29430002 	ldp	w2, w0, [x0, #24]
    cd8c:	92403c21 	and	x1, x1, #0xffff
    cd90:	9b027c21 	mul	x1, x1, x2
    cd94:	d360fc21 	lsr	x1, x1, #32
    cd98:	eb00003f 	cmp	x1, x0
    cd9c:	540000e2 	b.cs	cdb8 <f0+0x2218>  // b.hs, b.nlast
    cda0:	8b010294 	add	x20, x20, x1
    cda4:	39400280 	ldrb	w0, [x20]
    cda8:	7103fc1f 	cmp	w0, #0xff
    cdac:	540015a0 	b.eq	d060 <f0+0x24c0>  // b.none
    cdb0:	52800020 	mov	w0, #0x1                   	// #1
    cdb4:	39000280 	strb	w0, [x20]
    cdb8:	9120e3e1 	add	x1, sp, #0x838
    cdbc:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    cdc0:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    cdc4:	52800020 	mov	w0, #0x1                   	// #1
    cdc8:	f9041ff4 	str	x20, [sp, #2104]
    cdcc:	f90423f5 	str	x21, [sp, #2112]
    cdd0:	97ffe390 	bl	5c10 <fwp_data.part.0.constprop.0>
    cdd4:	97ffe413 	bl	5e20 <fwp_rc_fresh>
    cdd8:	aa0003e2 	mov	x2, x0
    cddc:	912123e1 	add	x1, sp, #0x848
    cde0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    cde4:	52800020 	mov	w0, #0x1                   	// #1
    cde8:	f90427e3 	str	x3, [sp, #2120]
    cdec:	f9042be2 	str	x2, [sp, #2128]
    cdf0:	97ffe388 	bl	5c10 <fwp_data.part.0.constprop.0>
    cdf4:	97ffe40b 	bl	5e20 <fwp_rc_fresh>
    cdf8:	aa0003e2 	mov	x2, x0
    cdfc:	aa1603e1 	mov	x1, x22
    ce00:	52800020 	mov	w0, #0x1                   	// #1
    ce04:	f9042ff4 	str	x20, [sp, #2136]
    ce08:	f90433e2 	str	x2, [sp, #2144]
    ce0c:	97ffe381 	bl	5c10 <fwp_data.part.0.constprop.0>
    ce10:	97ffe404 	bl	5e20 <fwp_rc_fresh>
    ce14:	aa0003f5 	mov	x21, x0
    ce18:	aa1303e1 	mov	x1, x19
    ce1c:	97fff3d1 	bl	9d60 <fwp_hof0.constprop.0>
    ce20:	aa0003f4 	mov	x20, x0
    ce24:	aa1503e0 	mov	x0, x21
    ce28:	97ffe50a 	bl	6250 <fwp_drop0>
    ce2c:	aa1303e0 	mov	x0, x19
    ce30:	97ffe508 	bl	6250 <fwp_drop0>
    ce34:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    ce38:	f947f400 	ldr	x0, [x0, #4072]
    ce3c:	f94437e2 	ldr	x2, [sp, #2152]
    ce40:	f9400001 	ldr	x1, [x0]
    ce44:	eb010042 	subs	x2, x2, x1
    ce48:	d2800001 	mov	x1, #0x0                   	// #0
    ce4c:	54001f41 	b.ne	d234 <f0+0x2694>  // b.any
    ce50:	9121c3ff 	add	sp, sp, #0x870
    ce54:	aa1403e0 	mov	x0, x20
    ce58:	a94153f3 	ldp	x19, x20, [sp, #16]
    ce5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    ce60:	a94363f7 	ldp	x23, x24, [sp, #48]
    ce64:	a9446bf9 	ldp	x25, x26, [sp, #64]
    ce68:	a94573fb 	ldp	x27, x28, [sp, #80]
    ce6c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    ce70:	d65f03c0 	ret
    ce74:	aa1c03e0 	mov	x0, x28
    ce78:	97ffdd2f 	bl	4334 <fwp_rc_forget_slot.part.0>
    ce7c:	17fff793 	b	acc8 <f0+0x128>
    ce80:	72003c5f 	tst	w2, #0xffff
    ce84:	54fef241 	b.ne	accc <f0+0x12c>  // b.any
    ce88:	17fff78d 	b	acbc <f0+0x11c>
    ce8c:	72003c3f 	tst	w1, #0xffff
    ce90:	54ff06e1 	b.ne	af6c <f0+0x3cc>  // b.any
    ce94:	17fff831 	b	af58 <f0+0x3b8>
    ce98:	72003c3f 	tst	w1, #0xffff
    ce9c:	54ff0fa1 	b.ne	b090 <f0+0x4f0>  // b.any
    cea0:	17fff877 	b	b07c <f0+0x4dc>
    cea4:	72003c3f 	tst	w1, #0xffff
    cea8:	54ff0ac1 	b.ne	b000 <f0+0x460>  // b.any
    ceac:	17fff850 	b	afec <f0+0x44c>
    ceb0:	72003c3f 	tst	w1, #0xffff
    ceb4:	54ff1b61 	b.ne	b220 <f0+0x680>  // b.any
    ceb8:	17fff8d5 	b	b20c <f0+0x66c>
    cebc:	72003c3f 	tst	w1, #0xffff
    cec0:	54ff1401 	b.ne	b140 <f0+0x5a0>  // b.any
    cec4:	17fff89a 	b	b12c <f0+0x58c>
    cec8:	72003c3f 	tst	w1, #0xffff
    cecc:	54ff23e1 	b.ne	b348 <f0+0x7a8>  // b.any
    ced0:	17fff919 	b	b334 <f0+0x794>
    ced4:	72003c3f 	tst	w1, #0xffff
    ced8:	54ff1ee1 	b.ne	b2b4 <f0+0x714>  // b.any
    cedc:	17fff8f1 	b	b2a0 <f0+0x700>
    cee0:	72003c3f 	tst	w1, #0xffff
    cee4:	54ff9ea1 	b.ne	c2b8 <f0+0x1718>  // b.any
    cee8:	17fffcef 	b	c2a4 <f0+0x1704>
    ceec:	72003c3f 	tst	w1, #0xffff
    cef0:	54ff9501 	b.ne	c190 <f0+0x15f0>  // b.any
    cef4:	17fffca2 	b	c17c <f0+0x15dc>
    cef8:	72003c3f 	tst	w1, #0xffff
    cefc:	54ffa861 	b.ne	c408 <f0+0x1868>  // b.any
    cf00:	17fffd3d 	b	c3f4 <f0+0x1854>
    cf04:	72003c3f 	tst	w1, #0xffff
    cf08:	54ffa341 	b.ne	c370 <f0+0x17d0>  // b.any
    cf0c:	17fffd14 	b	c35c <f0+0x17bc>
    cf10:	72003c3f 	tst	w1, #0xffff
    cf14:	54ffb661 	b.ne	c5e0 <f0+0x1a40>  // b.any
    cf18:	17fffdad 	b	c5cc <f0+0x1a2c>
    cf1c:	72003c3f 	tst	w1, #0xffff
    cf20:	54ffabe1 	b.ne	c49c <f0+0x18fc>  // b.any
    cf24:	17fffd59 	b	c488 <f0+0x18e8>
    cf28:	72003c3f 	tst	w1, #0xffff
    cf2c:	54ffc1c1 	b.ne	c764 <f0+0x1bc4>  // b.any
    cf30:	17fffe08 	b	c750 <f0+0x1bb0>
    cf34:	72003c3f 	tst	w1, #0xffff
    cf38:	54ffb9e1 	b.ne	c674 <f0+0x1ad4>  // b.any
    cf3c:	17fffdc9 	b	c660 <f0+0x1ac0>
    cf40:	72003c3f 	tst	w1, #0xffff
    cf44:	54ffcb81 	b.ne	c8b4 <f0+0x1d14>  // b.any
    cf48:	17fffe56 	b	c8a0 <f0+0x1d00>
    cf4c:	72003c3f 	tst	w1, #0xffff
    cf50:	54ffc661 	b.ne	c81c <f0+0x1c7c>  // b.any
    cf54:	17fffe2d 	b	c808 <f0+0x1c68>
    cf58:	72003c3f 	tst	w1, #0xffff
    cf5c:	54ffda61 	b.ne	caa8 <f0+0x1f08>  // b.any
    cf60:	17fffecd 	b	ca94 <f0+0x1ef4>
    cf64:	72003c3f 	tst	w1, #0xffff
    cf68:	54ffcf01 	b.ne	c948 <f0+0x1da8>  // b.any
    cf6c:	17fffe72 	b	c934 <f0+0x1d94>
    cf70:	72003c3f 	tst	w1, #0xffff
    cf74:	54ffe7c1 	b.ne	cc6c <f0+0x20cc>  // b.any
    cf78:	17ffff38 	b	cc58 <f0+0x20b8>
    cf7c:	72003c3f 	tst	w1, #0xffff
    cf80:	54ffe0c1 	b.ne	cb98 <f0+0x1ff8>  // b.any
    cf84:	17ffff00 	b	cb84 <f0+0x1fe4>
    cf88:	72003c3f 	tst	w1, #0xffff
    cf8c:	54fff161 	b.ne	cdb8 <f0+0x2218>  // b.any
    cf90:	17ffff85 	b	cda4 <f0+0x2204>
    cf94:	72003c3f 	tst	w1, #0xffff
    cf98:	54ffec61 	b.ne	cd24 <f0+0x2184>  // b.any
    cf9c:	17ffff5d 	b	cd10 <f0+0x2170>
    cfa0:	72003c3f 	tst	w1, #0xffff
    cfa4:	54ff2be1 	b.ne	b520 <f0+0x980>  // b.any
    cfa8:	17fff959 	b	b50c <f0+0x96c>
    cfac:	72003c3f 	tst	w1, #0xffff
    cfb0:	54ff26e1 	b.ne	b48c <f0+0x8ec>  // b.any
    cfb4:	17fff931 	b	b478 <f0+0x8d8>
    cfb8:	72003c3f 	tst	w1, #0xffff
    cfbc:	54ff3861 	b.ne	b6c8 <f0+0xb28>  // b.any
    cfc0:	17fff9bd 	b	b6b4 <f0+0xb14>
    cfc4:	72003c3f 	tst	w1, #0xffff
    cfc8:	54ff3161 	b.ne	b5f4 <f0+0xa54>  // b.any
    cfcc:	17fff985 	b	b5e0 <f0+0xa40>
    cfd0:	72003c3f 	tst	w1, #0xffff
    cfd4:	54ff4101 	b.ne	b7f4 <f0+0xc54>  // b.any
    cfd8:	17fffa02 	b	b7e0 <f0+0xc40>
    cfdc:	72003c3f 	tst	w1, #0xffff
    cfe0:	54ff3c01 	b.ne	b760 <f0+0xbc0>  // b.any
    cfe4:	17fff9da 	b	b74c <f0+0xbac>
    cfe8:	72003c3f 	tst	w1, #0xffff
    cfec:	54ff4e61 	b.ne	b9b8 <f0+0xe18>  // b.any
    cff0:	17fffa6d 	b	b9a4 <f0+0xe04>
    cff4:	72003c3f 	tst	w1, #0xffff
    cff8:	54ff4761 	b.ne	b8e4 <f0+0xd44>  // b.any
    cffc:	17fffa35 	b	b8d0 <f0+0xd30>
    d000:	72003c3f 	tst	w1, #0xffff
    d004:	54ff5d81 	b.ne	bbb4 <f0+0x1014>  // b.any
    d008:	17fffae6 	b	bba0 <f0+0x1000>
    d00c:	72003c3f 	tst	w1, #0xffff
    d010:	54ff55a1 	b.ne	bac4 <f0+0xf24>  // b.any
    d014:	17fffaa7 	b	bab0 <f0+0xf10>
    d018:	72003c3f 	tst	w1, #0xffff
    d01c:	54ff6b81 	b.ne	bd8c <f0+0x11ec>  // b.any
    d020:	17fffb56 	b	bd78 <f0+0x11d8>
    d024:	72003c3f 	tst	w1, #0xffff
    d028:	54ff6681 	b.ne	bcf8 <f0+0x1158>  // b.any
    d02c:	17fffb2e 	b	bce4 <f0+0x1144>
    d030:	72003c3f 	tst	w1, #0xffff
    d034:	54ff7801 	b.ne	bf34 <f0+0x1394>  // b.any
    d038:	17fffbba 	b	bf20 <f0+0x1380>
    d03c:	72003c3f 	tst	w1, #0xffff
    d040:	54ff71e1 	b.ne	be7c <f0+0x12dc>  // b.any
    d044:	17fffb89 	b	be68 <f0+0x12c8>
    d048:	72003c3f 	tst	w1, #0xffff
    d04c:	54ff82a1 	b.ne	c0a0 <f0+0x1500>  // b.any
    d050:	17fffc0f 	b	c08c <f0+0x14ec>
    d054:	72003c3f 	tst	w1, #0xffff
    d058:	54ff7ba1 	b.ne	bfcc <f0+0x142c>  // b.any
    d05c:	17fffbd7 	b	bfb8 <f0+0x1418>
    d060:	aa1403e0 	mov	x0, x20
    d064:	97ffdcb4 	bl	4334 <fwp_rc_forget_slot.part.0>
    d068:	17ffff52 	b	cdb0 <f0+0x2210>
    d06c:	aa1703e0 	mov	x0, x23
    d070:	97ffdcb1 	bl	4334 <fwp_rc_forget_slot.part.0>
    d074:	17fff7bc 	b	af64 <f0+0x3c4>
    d078:	aa1703e0 	mov	x0, x23
    d07c:	97ffdcae 	bl	4334 <fwp_rc_forget_slot.part.0>
    d080:	17fff7de 	b	aff8 <f0+0x458>
    d084:	aa1703e0 	mov	x0, x23
    d088:	97ffdcab 	bl	4334 <fwp_rc_forget_slot.part.0>
    d08c:	17fff7ff 	b	b088 <f0+0x4e8>
    d090:	aa1703e0 	mov	x0, x23
    d094:	97ffdca8 	bl	4334 <fwp_rc_forget_slot.part.0>
    d098:	17fff828 	b	b138 <f0+0x598>
    d09c:	aa1703e0 	mov	x0, x23
    d0a0:	97ffdca5 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0a4:	17fff85d 	b	b218 <f0+0x678>
    d0a8:	aa1703e0 	mov	x0, x23
    d0ac:	97ffdca2 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0b0:	17fff87f 	b	b2ac <f0+0x70c>
    d0b4:	aa1503e0 	mov	x0, x21
    d0b8:	97ffdc9f 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0bc:	17fff8a1 	b	b340 <f0+0x7a0>
    d0c0:	aa1703e0 	mov	x0, x23
    d0c4:	97ffdc9c 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0c8:	17fff8ef 	b	b484 <f0+0x8e4>
    d0cc:	aa1703e0 	mov	x0, x23
    d0d0:	97ffdc99 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0d4:	17fff911 	b	b518 <f0+0x978>
    d0d8:	aa1703e0 	mov	x0, x23
    d0dc:	97ffdc96 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0e0:	17fff943 	b	b5ec <f0+0xa4c>
    d0e4:	aa1703e0 	mov	x0, x23
    d0e8:	97ffdc93 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0ec:	17fff975 	b	b6c0 <f0+0xb20>
    d0f0:	aa1703e0 	mov	x0, x23
    d0f4:	97ffdc90 	bl	4334 <fwp_rc_forget_slot.part.0>
    d0f8:	17fff998 	b	b758 <f0+0xbb8>
    d0fc:	aa1703e0 	mov	x0, x23
    d100:	97ffdc8d 	bl	4334 <fwp_rc_forget_slot.part.0>
    d104:	17fff9ba 	b	b7ec <f0+0xc4c>
    d108:	aa1703e0 	mov	x0, x23
    d10c:	97ffdc8a 	bl	4334 <fwp_rc_forget_slot.part.0>
    d110:	17fff9f3 	b	b8dc <f0+0xd3c>
    d114:	aa1703e0 	mov	x0, x23
    d118:	97ffdc87 	bl	4334 <fwp_rc_forget_slot.part.0>
    d11c:	17fffa25 	b	b9b0 <f0+0xe10>
    d120:	aa1703e0 	mov	x0, x23
    d124:	97ffdc84 	bl	4334 <fwp_rc_forget_slot.part.0>
    d128:	17fffa65 	b	babc <f0+0xf1c>
    d12c:	aa1503e0 	mov	x0, x21
    d130:	97ffdc81 	bl	4334 <fwp_rc_forget_slot.part.0>
    d134:	17fffa9e 	b	bbac <f0+0x100c>
    d138:	aa1703e0 	mov	x0, x23
    d13c:	97ffdc7e 	bl	4334 <fwp_rc_forget_slot.part.0>
    d140:	17fffaec 	b	bcf0 <f0+0x1150>
    d144:	aa1703e0 	mov	x0, x23
    d148:	97ffdc7b 	bl	4334 <fwp_rc_forget_slot.part.0>
    d14c:	17fffb0e 	b	bd84 <f0+0x11e4>
    d150:	aa1703e0 	mov	x0, x23
    d154:	97ffdc78 	bl	4334 <fwp_rc_forget_slot.part.0>
    d158:	17fffb47 	b	be74 <f0+0x12d4>
    d15c:	aa1703e0 	mov	x0, x23
    d160:	97ffdc75 	bl	4334 <fwp_rc_forget_slot.part.0>
    d164:	17fffb72 	b	bf2c <f0+0x138c>
    d168:	aa1703e0 	mov	x0, x23
    d16c:	97ffdc72 	bl	4334 <fwp_rc_forget_slot.part.0>
    d170:	17fffb95 	b	bfc4 <f0+0x1424>
    d174:	aa1703e0 	mov	x0, x23
    d178:	97ffdc6f 	bl	4334 <fwp_rc_forget_slot.part.0>
    d17c:	17fffbc7 	b	c098 <f0+0x14f8>
    d180:	aa1703e0 	mov	x0, x23
    d184:	97ffdc6c 	bl	4334 <fwp_rc_forget_slot.part.0>
    d188:	17fffc00 	b	c188 <f0+0x15e8>
    d18c:	aa1703e0 	mov	x0, x23
    d190:	97ffdc69 	bl	4334 <fwp_rc_forget_slot.part.0>
    d194:	17fffc47 	b	c2b0 <f0+0x1710>
    d198:	aa1703e0 	mov	x0, x23
    d19c:	97ffdc66 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1a0:	17fffc72 	b	c368 <f0+0x17c8>
    d1a4:	aa1703e0 	mov	x0, x23
    d1a8:	97ffdc63 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1ac:	17fffc95 	b	c400 <f0+0x1860>
    d1b0:	aa1503e0 	mov	x0, x21
    d1b4:	97ffdc60 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1b8:	17fffcb7 	b	c494 <f0+0x18f4>
    d1bc:	aa1703e0 	mov	x0, x23
    d1c0:	97ffdc5d 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1c4:	17fffd05 	b	c5d8 <f0+0x1a38>
    d1c8:	aa1703e0 	mov	x0, x23
    d1cc:	97ffdc5a 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1d0:	17fffd27 	b	c66c <f0+0x1acc>
    d1d4:	aa1703e0 	mov	x0, x23
    d1d8:	97ffdc57 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1dc:	17fffd60 	b	c75c <f0+0x1bbc>
    d1e0:	aa1703e0 	mov	x0, x23
    d1e4:	97ffdc54 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1e8:	17fffd8b 	b	c814 <f0+0x1c74>
    d1ec:	aa1703e0 	mov	x0, x23
    d1f0:	97ffdc51 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1f4:	17fffdae 	b	c8ac <f0+0x1d0c>
    d1f8:	aa1703e0 	mov	x0, x23
    d1fc:	97ffdc4e 	bl	4334 <fwp_rc_forget_slot.part.0>
    d200:	17fffdd0 	b	c940 <f0+0x1da0>
    d204:	aa1703e0 	mov	x0, x23
    d208:	97ffdc4b 	bl	4334 <fwp_rc_forget_slot.part.0>
    d20c:	17fffe25 	b	caa0 <f0+0x1f00>
    d210:	aa1703e0 	mov	x0, x23
    d214:	97ffdc48 	bl	4334 <fwp_rc_forget_slot.part.0>
    d218:	17fffe5e 	b	cb90 <f0+0x1ff0>
    d21c:	aa1703e0 	mov	x0, x23
    d220:	97ffdc45 	bl	4334 <fwp_rc_forget_slot.part.0>
    d224:	17fffe90 	b	cc64 <f0+0x20c4>
    d228:	aa1703e0 	mov	x0, x23
    d22c:	97ffdc42 	bl	4334 <fwp_rc_forget_slot.part.0>
    d230:	17fffebb 	b	cd1c <f0+0x217c>
    d234:	97ffd577 	bl	2810 <__stack_chk_fail@plt>
    d238:	97ffd58a 	bl	2860 <abort@plt>
    d23c:	d503201f 	nop

000000000000d240 <fwp_main_thread>:
    d240:	d10443ff 	sub	sp, sp, #0x110
    d244:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d248:	f947f400 	ldr	x0, [x0, #4072]
    d24c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    d250:	910303fd 	add	x29, sp, #0xc0
    d254:	a90d53f3 	stp	x19, x20, [sp, #208]
    d258:	900003f4 	adrp	x20, 89000 <fwp_root_context+0xba0>
    d25c:	91190281 	add	x1, x20, #0x640
    d260:	a90e5bf5 	stp	x21, x22, [sp, #224]
    d264:	a90f63f7 	stp	x23, x24, [sp, #240]
    d268:	b953a421 	ldr	w1, [x1, #5028]
    d26c:	a9106bf9 	stp	x25, x26, [sp, #256]
    d270:	f9400002 	ldr	x2, [x0]
    d274:	f9005fe2 	str	x2, [sp, #184]
    d278:	d2800002 	mov	x2, #0x0                   	// #0
    d27c:	34000ee1 	cbz	w1, d458 <fwp_main_thread+0x218>
    d280:	91190280 	add	x0, x20, #0x640
    d284:	b953a800 	ldr	w0, [x0, #5032]
    d288:	35000e00 	cbnz	w0, d448 <fwp_main_thread+0x208>
    d28c:	91001fe2 	add	x2, sp, #0x7
    d290:	f0000115 	adrp	x21, 30000 <__data_start>
    d294:	f0000103 	adrp	x3, 30000 <__data_start>
    d298:	910182b3 	add	x19, x21, #0x60
    d29c:	91118063 	add	x3, x3, #0x460
    d2a0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    d2a4:	d2a00025 	mov	x5, #0x10000               	// #65536
    d2a8:	910023e0 	add	x0, sp, #0x8
    d2ac:	d2800001 	mov	x1, #0x0                   	// #0
    d2b0:	f90007e3 	str	x3, [sp, #8]
    d2b4:	b90013ff 	str	wzr, [sp, #16]
    d2b8:	f9000fe5 	str	x5, [sp, #24]
    d2bc:	a90a1262 	stp	x2, x4, [x19, #160]
    d2c0:	97ffd4ec 	bl	2670 <sigaltstack@plt>
    d2c4:	35000220 	cbnz	w0, d308 <fwp_main_thread+0xc8>
    d2c8:	4f000400 	movi	v0.4s, #0x0
    d2cc:	9100a3e0 	add	x0, sp, #0x28
    d2d0:	d0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    d2d4:	52800082 	mov	w2, #0x4                   	// #4
    d2d8:	9100c021 	add	x1, x1, #0x30
    d2dc:	72a10002 	movk	w2, #0x800, lsl #16
    d2e0:	910083f6 	add	x22, sp, #0x20
    d2e4:	f90013e1 	str	x1, [sp, #32]
    d2e8:	3d802000 	str	q0, [x0, #128]
    d2ec:	b900abe2 	str	w2, [sp, #168]
    d2f0:	ad000000 	stp	q0, q0, [x0]
    d2f4:	ad010000 	stp	q0, q0, [x0, #32]
    d2f8:	ad020000 	stp	q0, q0, [x0, #64]
    d2fc:	ad030000 	stp	q0, q0, [x0, #96]
    d300:	97ffd534 	bl	27d0 <sigemptyset@plt>
    d304:	34000080 	cbz	w0, d314 <fwp_main_thread+0xd4>
    d308:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x110>
    d30c:	911b8000 	add	x0, x0, #0x6e0
    d310:	97ffdbe9 	bl	42b4 <fwp_trap>
    d314:	aa1603e1 	mov	x1, x22
    d318:	d2800002 	mov	x2, #0x0                   	// #0
    d31c:	52800160 	mov	w0, #0xb                   	// #11
    d320:	97ffd544 	bl	2830 <sigaction@plt>
    d324:	35ffff20 	cbnz	w0, d308 <fwp_main_thread+0xc8>
    d328:	aa1603e1 	mov	x1, x22
    d32c:	d2800002 	mov	x2, #0x0                   	// #0
    d330:	528000e0 	mov	w0, #0x7                   	// #7
    d334:	97ffd53f 	bl	2830 <sigaction@plt>
    d338:	35fffe80 	cbnz	w0, d308 <fwp_main_thread+0xc8>
    d33c:	91190281 	add	x1, x20, #0x640
    d340:	52800036 	mov	w22, #0x1                   	// #1
    d344:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d348:	910cc000 	add	x0, x0, #0x330
    d34c:	b9013276 	str	w22, [x19, #304]
    d350:	fd4a1020 	ldr	d0, [x1, #5152]
    d354:	7e61d800 	ucvtf	d0, d0
    d358:	fd00a660 	str	d0, [x19, #328]
    d35c:	940002d9 	bl	dec0 <atexit>
    d360:	350022a0 	cbnz	w0, d7b4 <fwp_main_thread+0x574>
    d364:	b943ca60 	ldr	w0, [x19, #968]
    d368:	34001c40 	cbz	w0, d6f0 <fwp_main_thread+0x4b0>
    d36c:	910182ba 	add	x26, x21, #0x60
    d370:	f9404f56 	ldr	x22, [x26, #152]
    d374:	b4000796 	cbz	x22, d464 <fwp_main_thread+0x224>
    d378:	910102d7 	add	x23, x22, #0x40
    d37c:	39414ad9 	ldrb	w25, [x22, #82]
    d380:	52800038 	mov	w24, #0x1                   	// #1
    d384:	39014ad8 	strb	w24, [x22, #82]
    d388:	f94016c0 	ldr	x0, [x22, #40]
    d38c:	b40006a0 	cbz	x0, d460 <fwp_main_thread+0x220>
    d390:	f94032c1 	ldr	x1, [x22, #96]
    d394:	394146c0 	ldrb	w0, [x22, #81]
    d398:	b4001c61 	cbz	x1, d724 <fwp_main_thread+0x4e4>
    d39c:	36001b20 	tbz	w0, #0, d700 <fwp_main_thread+0x4c0>
    d3a0:	f9404f53 	ldr	x19, [x26, #152]
    d3a4:	f94022c0 	ldr	x0, [x22, #64]
    d3a8:	39414a61 	ldrb	w1, [x19, #82]
    d3ac:	37001e81 	tbnz	w1, #0, d77c <fwp_main_thread+0x53c>
    d3b0:	f9403261 	ldr	x1, [x19, #96]
    d3b4:	a911fe77 	stp	x23, xzr, [x19, #280]
    d3b8:	f9009660 	str	x0, [x19, #296]
    d3bc:	b4000040 	cbz	x0, d3c4 <fwp_main_thread+0x184>
    d3c0:	f9009013 	str	x19, [x0, #288]
    d3c4:	f90022d3 	str	x19, [x22, #64]
    d3c8:	b4000101 	cbz	x1, d3e8 <fwp_main_thread+0x1a8>
    d3cc:	f9409740 	ldr	x0, [x26, #296]
    d3d0:	39015678 	strb	w24, [x19, #85]
    d3d4:	f9003661 	str	x1, [x19, #104]
    d3d8:	a910827f 	stp	xzr, x0, [x19, #264]
    d3dc:	b4000040 	cbz	x0, d3e4 <fwp_main_thread+0x1a4>
    d3e0:	f9008413 	str	x19, [x0, #264]
    d3e4:	f9009753 	str	x19, [x26, #296]
    d3e8:	39015a7f 	strb	wzr, [x19, #86]
    d3ec:	97ffe64d 	bl	6d20 <fwp_block>
    d3f0:	f9408e62 	ldr	x2, [x19, #280]
    d3f4:	b4000142 	cbz	x2, d41c <fwp_main_thread+0x1dc>
    d3f8:	a9520261 	ldp	x1, x0, [x19, #288]
    d3fc:	b4001cc1 	cbz	x1, d794 <fwp_main_thread+0x554>
    d400:	f9009420 	str	x0, [x1, #296]
    d404:	f9409660 	ldr	x0, [x19, #296]
    d408:	b4000040 	cbz	x0, d410 <fwp_main_thread+0x1d0>
    d40c:	f9009001 	str	x1, [x0, #288]
    d410:	91080260 	add	x0, x19, #0x200
    d414:	f900967f 	str	xzr, [x19, #296]
    d418:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    d41c:	39415660 	ldrb	w0, [x19, #85]
    d420:	3607fb40 	tbz	w0, #0, d388 <fwp_main_thread+0x148>
    d424:	a9508261 	ldp	x1, x0, [x19, #264]
    d428:	b4001ba1 	cbz	x1, d79c <fwp_main_thread+0x55c>
    d42c:	f9008820 	str	x0, [x1, #272]
    d430:	b4000040 	cbz	x0, d438 <fwp_main_thread+0x1f8>
    d434:	f9008401 	str	x1, [x0, #264]
    d438:	91080260 	add	x0, x19, #0x200
    d43c:	3901567f 	strb	wzr, [x19, #85]
    d440:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    d444:	17ffffd1 	b	d388 <fwp_main_thread+0x148>
    d448:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d44c:	912e1000 	add	x0, x0, #0xb84
    d450:	9400029c 	bl	dec0 <atexit>
    d454:	17ffff8e 	b	d28c <fwp_main_thread+0x4c>
    d458:	97ffda26 	bl	3cf0 <fwp_heap_init>
    d45c:	17ffff89 	b	d280 <fwp_main_thread+0x40>
    d460:	39014ad9 	strb	w25, [x22, #82]
    d464:	910182b3 	add	x19, x21, #0x60
    d468:	f941d660 	ldr	x0, [x19, #936]
    d46c:	b5000180 	cbnz	x0, d49c <fwp_main_thread+0x25c>
    d470:	f941de60 	ldr	x0, [x19, #952]
    d474:	b5000140 	cbnz	x0, d49c <fwp_main_thread+0x25c>
    d478:	f941d260 	ldr	x0, [x19, #928]
    d47c:	97ffdc49 	bl	45a0 <fwp_mem_free>
    d480:	f901d27f 	str	xzr, [x19, #928]
    d484:	f9404e60 	ldr	x0, [x19, #152]
    d488:	f901da7f 	str	xzr, [x19, #944]
    d48c:	b40000c0 	cbz	x0, d4a4 <fwp_main_thread+0x264>
    d490:	f900541f 	str	xzr, [x0, #168]
    d494:	f9005c1f 	str	xzr, [x0, #184]
    d498:	14000003 	b	d4a4 <fwp_main_thread+0x264>
    d49c:	910182a0 	add	x0, x21, #0x60
    d4a0:	f9404c00 	ldr	x0, [x0, #152]
    d4a4:	910182a1 	add	x1, x21, #0x60
    d4a8:	f941f026 	ldr	x6, [x1, #992]
    d4ac:	b903d83f 	str	wzr, [x1, #984]
    d4b0:	eb0000df 	cmp	x6, x0
    d4b4:	54001861 	b.ne	d7c0 <fwp_main_thread+0x580>  // b.any
    d4b8:	b40003a0 	cbz	x0, d52c <fwp_main_thread+0x2ec>
    d4bc:	f941c025 	ldr	x5, [x1, #896]
    d4c0:	52800021 	mov	w1, #0x1                   	// #1
    d4c4:	39014801 	strb	w1, [x0, #82]
    d4c8:	b4000325 	cbz	x5, d52c <fwp_main_thread+0x2ec>
    d4cc:	d503201f 	nop
    d4d0:	394140a0 	ldrb	w0, [x5, #80]
    d4d4:	37000060 	tbnz	w0, #0, d4e0 <fwp_main_thread+0x2a0>
    d4d8:	aa0503e0 	mov	x0, x5
    d4dc:	97ffd865 	bl	3670 <fwp_cancel_tree.part.0>
    d4e0:	f9409ca5 	ldr	x5, [x5, #312]
    d4e4:	b5ffff65 	cbnz	x5, d4d0 <fwp_main_thread+0x290>
    d4e8:	910182b3 	add	x19, x21, #0x60
    d4ec:	52800036 	mov	w22, #0x1                   	// #1
    d4f0:	f94028c0 	ldr	x0, [x6, #80]
    d4f4:	f2001c1f 	tst	x0, #0xff000000ff
    d4f8:	540000e1 	b.ne	d514 <fwp_main_thread+0x2d4>  // b.any
    d4fc:	f9406260 	ldr	x0, [x19, #192]
    d500:	390150d6 	strb	w22, [x6, #84]
    d504:	f90080df 	str	xzr, [x6, #256]
    d508:	b4001360 	cbz	x0, d774 <fwp_main_thread+0x534>
    d50c:	f9008006 	str	x6, [x0, #256]
    d510:	f9006266 	str	x6, [x19, #192]
    d514:	97ffe603 	bl	6d20 <fwp_block>
    d518:	97ffe58a 	bl	6b40 <fwp_free_zombie>
    d51c:	f941c260 	ldr	x0, [x19, #896]
    d520:	b4000060 	cbz	x0, d52c <fwp_main_thread+0x2ec>
    d524:	f941f266 	ldr	x6, [x19, #992]
    d528:	17fffff2 	b	d4f0 <fwp_main_thread+0x2b0>
    d52c:	910182b6 	add	x22, x21, #0x60
    d530:	97ffe584 	bl	6b40 <fwp_free_zombie>
    d534:	f94066c0 	ldr	x0, [x22, #200]
    d538:	b5001440 	cbnz	x0, d7c0 <fwp_main_thread+0x580>
    d53c:	f94096c0 	ldr	x0, [x22, #296]
    d540:	b5001400 	cbnz	x0, d7c0 <fwp_main_thread+0x580>
    d544:	b94172d3 	ldr	w19, [x22, #368]
    d548:	340001f3 	cbz	w19, d584 <fwp_main_thread+0x344>
    d54c:	93407e77 	sxtw	x23, w19
    d550:	51000673 	sub	w19, w19, #0x1
    d554:	d1000af7 	sub	x23, x23, #0x2
    d558:	910602d8 	add	x24, x22, #0x180
    d55c:	cb3342f7 	sub	x23, x23, w19, uxtw
    d560:	93407e73 	sxtw	x19, w19
    d564:	d503201f 	nop
    d568:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    d56c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d570:	b90172d3 	str	w19, [x22, #368]
    d574:	d1000673 	sub	x19, x19, #0x1
    d578:	97ffd4ee 	bl	2930 <munmap@plt>
    d57c:	eb1302ff 	cmp	x23, x19
    d580:	54ffff41 	b.ne	d568 <fwp_main_thread+0x328>  // b.any
    d584:	f0000113 	adrp	x19, 30000 <__data_start>
    d588:	91004260 	add	x0, x19, #0x10
    d58c:	b9403000 	ldr	w0, [x0, #48]
    d590:	36f80ac0 	tbz	w0, #31, d6e8 <fwp_main_thread+0x4a8>
    d594:	910182b6 	add	x22, x21, #0x60
    d598:	91004273 	add	x19, x19, #0x10
    d59c:	12800001 	mov	w1, #0xffffffff            	// #-1
    d5a0:	f941fac0 	ldr	x0, [x22, #1008]
    d5a4:	b9003261 	str	w1, [x19, #48]
    d5a8:	f941f6c1 	ldr	x1, [x22, #1000]
    d5ac:	b40001e0 	cbz	x0, d5e8 <fwp_main_thread+0x3a8>
    d5b0:	d2800013 	mov	x19, #0x0                   	// #0
    d5b4:	d503201f 	nop
    d5b8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    d5bc:	b40000e0 	cbz	x0, d5d8 <fwp_main_thread+0x398>
    d5c0:	f9400001 	ldr	x1, [x0]
    d5c4:	b5000fe1 	cbnz	x1, d7c0 <fwp_main_thread+0x580>
    d5c8:	f9400401 	ldr	x1, [x0, #8]
    d5cc:	b5000fa1 	cbnz	x1, d7c0 <fwp_main_thread+0x580>
    d5d0:	97ffdbf4 	bl	45a0 <fwp_mem_free>
    d5d4:	f941f6c1 	ldr	x1, [x22, #1000]
    d5d8:	91000673 	add	x19, x19, #0x1
    d5dc:	f941fac0 	ldr	x0, [x22, #1008]
    d5e0:	eb00027f 	cmp	x19, x0
    d5e4:	54fffea3 	b.cc	d5b8 <fwp_main_thread+0x378>  // b.lo, b.ul, b.last
    d5e8:	aa0103e0 	mov	x0, x1
    d5ec:	97ffdbed 	bl	45a0 <fwp_mem_free>
    d5f0:	910182a0 	add	x0, x21, #0x60
    d5f4:	f941f013 	ldr	x19, [x0, #992]
    d5f8:	f901f41f 	str	xzr, [x0, #1000]
    d5fc:	f901f81f 	str	xzr, [x0, #1008]
    d600:	b40001f3 	cbz	x19, d63c <fwp_main_thread+0x3fc>
    d604:	f9401661 	ldr	x1, [x19, #40]
    d608:	b5000dc1 	cbnz	x1, d7c0 <fwp_main_thread+0x580>
    d60c:	f9405661 	ldr	x1, [x19, #168]
    d610:	b5000d81 	cbnz	x1, d7c0 <fwp_main_thread+0x580>
    d614:	f941d401 	ldr	x1, [x0, #936]
    d618:	b5000d41 	cbnz	x1, d7c0 <fwp_main_thread+0x580>
    d61c:	f941dc00 	ldr	x0, [x0, #952]
    d620:	b5000d00 	cbnz	x0, d7c0 <fwp_main_thread+0x580>
    d624:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d628:	f00003c0 	adrp	x0, 88000 <ad_raw_blocks+0x17ba0>
    d62c:	91118000 	add	x0, x0, #0x460
    d630:	97ffd46c 	bl	27e0 <memset@plt>
    d634:	aa1303e0 	mov	x0, x19
    d638:	97ffdbda 	bl	45a0 <fwp_mem_free>
    d63c:	910182a6 	add	x6, x21, #0x60
    d640:	91190294 	add	x20, x20, #0x640
    d644:	3dc01aa1 	ldr	q1, [x21, #96]
    d648:	52800041 	mov	w1, #0x2                   	// #2
    d64c:	3dc004c2 	ldr	q2, [x6, #16]
    d650:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x110>
    d654:	fd4a1280 	ldr	d0, [x20, #5152]
    d658:	911ca042 	add	x2, x2, #0x728
    d65c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d660:	fd40a4c1 	ldr	d1, [x6, #328]
    d664:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d668:	f947e800 	ldr	x0, [x0, #4048]
    d66c:	7e61d800 	ucvtf	d0, d0
    d670:	a95390c3 	ldp	x3, x4, [x6, #312]
    d674:	f9004cdf 	str	xzr, [x6, #152]
    d678:	f9400000 	ldr	x0, [x0]
    d67c:	1e613801 	fsub	d1, d0, d1
    d680:	f940acc5 	ldr	x5, [x6, #344]
    d684:	b90130df 	str	wzr, [x6, #304]
    d688:	5ef1b842 	addp	d2, v2.2d
    d68c:	fd40a8c0 	ldr	d0, [x6, #336]
    d690:	f901f0df 	str	xzr, [x6, #992]
    d694:	fd0058c2 	str	d2, [x6, #176]
    d698:	97ffd47a 	bl	2880 <__fprintf_chk@plt>
    d69c:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d6a0:	f947ec00 	ldr	x0, [x0, #4056]
    d6a4:	f9400000 	ldr	x0, [x0]
    d6a8:	97ffd4a6 	bl	2940 <fflush@plt>
    d6ac:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d6b0:	f947f400 	ldr	x0, [x0, #4072]
    d6b4:	f9405fe2 	ldr	x2, [sp, #184]
    d6b8:	f9400001 	ldr	x1, [x0]
    d6bc:	eb010042 	subs	x2, x2, x1
    d6c0:	d2800001 	mov	x1, #0x0                   	// #0
    d6c4:	54000761 	b.ne	d7b0 <fwp_main_thread+0x570>  // b.any
    d6c8:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d6cc:	d2800000 	mov	x0, #0x0                   	// #0
    d6d0:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d6d4:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d6d8:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d6dc:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d6e0:	910443ff 	add	sp, sp, #0x110
    d6e4:	d65f03c0 	ret
    d6e8:	97ffd44e 	bl	2820 <close@plt>
    d6ec:	17ffffaa 	b	d594 <fwp_main_thread+0x354>
    d6f0:	97fff52c 	bl	aba0 <f0>
    d6f4:	b903ca76 	str	w22, [x19, #968]
    d6f8:	f901ea60 	str	x0, [x19, #976]
    d6fc:	17ffff1c 	b	d36c <fwp_main_thread+0x12c>
    d700:	97ffdd0c 	bl	4b30 <fwp_now_ns>
    d704:	f94032c1 	ldr	x1, [x22, #96]
    d708:	eb01001f 	cmp	x0, x1
    d70c:	540000ab 	b.lt	d720 <fwp_main_thread+0x4e0>  // b.tstop
    d710:	394142c0 	ldrb	w0, [x22, #80]
    d714:	37000060 	tbnz	w0, #0, d720 <fwp_main_thread+0x4e0>
    d718:	aa1603e0 	mov	x0, x22
    d71c:	97ffd7d5 	bl	3670 <fwp_cancel_tree.part.0>
    d720:	394146c0 	ldrb	w0, [x22, #81]
    d724:	f9404f53 	ldr	x19, [x26, #152]
    d728:	39414a62 	ldrb	w2, [x19, #82]
    d72c:	3707e3a0 	tbnz	w0, #0, d3a0 <fwp_main_thread+0x160>
    d730:	f94032c1 	ldr	x1, [x22, #96]
    d734:	370001c2 	tbnz	w2, #0, d76c <fwp_main_thread+0x52c>
    d738:	f9403260 	ldr	x0, [x19, #96]
    d73c:	b4000180 	cbz	x0, d76c <fwp_main_thread+0x52c>
    d740:	b4000061 	cbz	x1, d74c <fwp_main_thread+0x50c>
    d744:	eb01001f 	cmp	x0, x1
    d748:	9a81d000 	csel	x0, x0, x1, le
    d74c:	f94022c1 	ldr	x1, [x22, #64]
    d750:	a911fe77 	stp	x23, xzr, [x19, #280]
    d754:	f9009661 	str	x1, [x19, #296]
    d758:	b4000261 	cbz	x1, d7a4 <fwp_main_thread+0x564>
    d75c:	f9009033 	str	x19, [x1, #288]
    d760:	aa0003e1 	mov	x1, x0
    d764:	f90022d3 	str	x19, [x22, #64]
    d768:	17ffff19 	b	d3cc <fwp_main_thread+0x18c>
    d76c:	f94022c0 	ldr	x0, [x22, #64]
    d770:	17ffff11 	b	d3b4 <fwp_main_thread+0x174>
    d774:	f9006666 	str	x6, [x19, #200]
    d778:	17ffff66 	b	d510 <fwp_main_thread+0x2d0>
    d77c:	a911fe77 	stp	x23, xzr, [x19, #280]
    d780:	f9009660 	str	x0, [x19, #296]
    d784:	b4000040 	cbz	x0, d78c <fwp_main_thread+0x54c>
    d788:	f9009013 	str	x19, [x0, #288]
    d78c:	f90022d3 	str	x19, [x22, #64]
    d790:	17ffff16 	b	d3e8 <fwp_main_thread+0x1a8>
    d794:	f9000040 	str	x0, [x2]
    d798:	17ffff1c 	b	d408 <fwp_main_thread+0x1c8>
    d79c:	f9009740 	str	x0, [x26, #296]
    d7a0:	17ffff24 	b	d430 <fwp_main_thread+0x1f0>
    d7a4:	aa0003e1 	mov	x1, x0
    d7a8:	f90022d3 	str	x19, [x22, #64]
    d7ac:	17ffff08 	b	d3cc <fwp_main_thread+0x18c>
    d7b0:	97ffd418 	bl	2810 <__stack_chk_fail@plt>
    d7b4:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x110>
    d7b8:	911c2000 	add	x0, x0, #0x708
    d7bc:	97ffd6d1 	bl	3300 <ad_raw_fail>
    d7c0:	97ffd428 	bl	2860 <abort@plt>
    d7c4:	d503201f 	nop
    d7c8:	d503201f 	nop
    d7cc:	d503201f 	nop

000000000000d7d0 <__divti3>:
    d7d0:	d503245f 	bti	c
    d7d4:	d2800004 	mov	x4, #0x0                   	// #0
    d7d8:	b7f80721 	tbnz	x1, #63, d8bc <__divti3+0xec>
    d7dc:	b6f80083 	tbz	x3, #63, d7ec <__divti3+0x1c>
    d7e0:	eb0203e2 	negs	x2, x2
    d7e4:	aa2403e4 	mvn	x4, x4
    d7e8:	da0303e3 	ngc	x3, x3
    d7ec:	aa0203e6 	mov	x6, x2
    d7f0:	aa0003e7 	mov	x7, x0
    d7f4:	aa0103e5 	mov	x5, x1
    d7f8:	b5000583 	cbnz	x3, d8a8 <__divti3+0xd8>
    d7fc:	eb01005f 	cmp	x2, x1
    d800:	54000e69 	b.ls	d9cc <__divti3+0x1fc>  // b.plast
    d804:	dac01040 	clz	x0, x2
    d808:	b40000e0 	cbz	x0, d824 <__divti3+0x54>
    d80c:	4b0003e1 	neg	w1, w0
    d810:	9ac020a5 	lsl	x5, x5, x0
    d814:	9ac02046 	lsl	x6, x2, x0
    d818:	9ac124e1 	lsr	x1, x7, x1
    d81c:	aa050025 	orr	x5, x1, x5
    d820:	9ac020e7 	lsl	x7, x7, x0
    d824:	d360fcc8 	lsr	x8, x6, #32
    d828:	92407cc2 	and	x2, x6, #0xffffffff
    d82c:	9ac808a3 	udiv	x3, x5, x8
    d830:	9b089465 	msub	x5, x3, x8, x5
    d834:	aa0303e0 	mov	x0, x3
    d838:	9b037c41 	mul	x1, x2, x3
    d83c:	93c780a5 	extr	x5, x5, x7, #32
    d840:	eb05003f 	cmp	x1, x5
    d844:	540000a9 	b.ls	d858 <__divti3+0x88>  // b.plast
    d848:	ab0500c5 	adds	x5, x6, x5
    d84c:	d1000460 	sub	x0, x3, #0x1
    d850:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d854:	540015a8 	b.hi	db08 <__divti3+0x338>  // b.pmore
    d858:	cb0100a5 	sub	x5, x5, x1
    d85c:	9ac808a3 	udiv	x3, x5, x8
    d860:	9b089465 	msub	x5, x3, x8, x5
    d864:	aa0303e1 	mov	x1, x3
    d868:	9b037c42 	mul	x2, x2, x3
    d86c:	aa0703e3 	mov	x3, x7
    d870:	b3607ca3 	bfi	x3, x5, #32, #32
    d874:	eb03005f 	cmp	x2, x3
    d878:	540000c9 	b.ls	d890 <__divti3+0xc0>  // b.plast
    d87c:	ab0300c3 	adds	x3, x6, x3
    d880:	d1000425 	sub	x5, x1, #0x1
    d884:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d888:	d1000821 	sub	x1, x1, #0x2
    d88c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d890:	aa008020 	orr	x0, x1, x0, lsl #32
    d894:	d2800001 	mov	x1, #0x0                   	// #0
    d898:	b4000064 	cbz	x4, d8a4 <__divti3+0xd4>
    d89c:	eb0003e0 	negs	x0, x0
    d8a0:	da0103e1 	ngc	x1, x1
    d8a4:	d65f03c0 	ret
    d8a8:	eb01007f 	cmp	x3, x1
    d8ac:	54000109 	b.ls	d8cc <__divti3+0xfc>  // b.plast
    d8b0:	d2800001 	mov	x1, #0x0                   	// #0
    d8b4:	d2800000 	mov	x0, #0x0                   	// #0
    d8b8:	17fffff8 	b	d898 <__divti3+0xc8>
    d8bc:	eb0003e0 	negs	x0, x0
    d8c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d8c4:	da0103e1 	ngc	x1, x1
    d8c8:	17ffffc5 	b	d7dc <__divti3+0xc>
    d8cc:	dac01067 	clz	x7, x3
    d8d0:	b40010e7 	cbz	x7, daec <__divti3+0x31c>
    d8d4:	d2800805 	mov	x5, #0x40                  	// #64
    d8d8:	cb0700a5 	sub	x5, x5, x7
    d8dc:	9ac72063 	lsl	x3, x3, x7
    d8e0:	9ac52448 	lsr	x8, x2, x5
    d8e4:	aa030108 	orr	x8, x8, x3
    d8e8:	9ac52426 	lsr	x6, x1, x5
    d8ec:	92407d0a 	and	x10, x8, #0xffffffff
    d8f0:	d360fd09 	lsr	x9, x8, #32
    d8f4:	9ac52403 	lsr	x3, x0, x5
    d8f8:	9ac72021 	lsl	x1, x1, x7
    d8fc:	aa010063 	orr	x3, x3, x1
    d900:	9ac72042 	lsl	x2, x2, x7
    d904:	9ac908cb 	udiv	x11, x6, x9
    d908:	9b099965 	msub	x5, x11, x9, x6
    d90c:	aa0b03e1 	mov	x1, x11
    d910:	9b0b7d46 	mul	x6, x10, x11
    d914:	93c380a5 	extr	x5, x5, x3, #32
    d918:	eb0500df 	cmp	x6, x5
    d91c:	540000a9 	b.ls	d930 <__divti3+0x160>  // b.plast
    d920:	ab050105 	adds	x5, x8, x5
    d924:	d1000561 	sub	x1, x11, #0x1
    d928:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d92c:	54000f48 	b.hi	db14 <__divti3+0x344>  // b.pmore
    d930:	cb0600a6 	sub	x6, x5, x6
    d934:	9ac908cb 	udiv	x11, x6, x9
    d938:	9b099969 	msub	x9, x11, x9, x6
    d93c:	aa0b03e5 	mov	x5, x11
    d940:	9b0b7d4a 	mul	x10, x10, x11
    d944:	b3607d23 	bfi	x3, x9, #32, #32
    d948:	eb03015f 	cmp	x10, x3
    d94c:	540000a9 	b.ls	d960 <__divti3+0x190>  // b.plast
    d950:	ab030103 	adds	x3, x8, x3
    d954:	d1000565 	sub	x5, x11, #0x1
    d958:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d95c:	54000e28 	b.hi	db20 <__divti3+0x350>  // b.pmore
    d960:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d964:	92407c48 	and	x8, x2, #0xffffffff
    d968:	2a0503e5 	mov	w5, w5
    d96c:	d360fc42 	lsr	x2, x2, #32
    d970:	d360fc26 	lsr	x6, x1, #32
    d974:	cb0a0063 	sub	x3, x3, x10
    d978:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d97c:	9b087caa 	mul	x10, x5, x8
    d980:	9b087cc8 	mul	x8, x6, x8
    d984:	9b0220a5 	madd	x5, x5, x2, x8
    d988:	9b027cc6 	mul	x6, x6, x2
    d98c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d990:	8b0900c5 	add	x5, x6, x9
    d994:	eb02011f 	cmp	x8, x2
    d998:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d99c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d9a0:	eb06007f 	cmp	x3, x6
    d9a4:	540000e3 	b.cc	d9c0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d9a8:	92407d4a 	and	x10, x10, #0xffffffff
    d9ac:	9ac72000 	lsl	x0, x0, x7
    d9b0:	8b028142 	add	x2, x10, x2, lsl #32
    d9b4:	eb02001f 	cmp	x0, x2
    d9b8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d9bc:	54000a01 	b.ne	dafc <__divti3+0x32c>  // b.any
    d9c0:	d1000420 	sub	x0, x1, #0x1
    d9c4:	d2800001 	mov	x1, #0x0                   	// #0
    d9c8:	17ffffb4 	b	d898 <__divti3+0xc8>
    d9cc:	b5000062 	cbnz	x2, d9d8 <__divti3+0x208>
    d9d0:	d2800022 	mov	x2, #0x1                   	// #1
    d9d4:	9ac30846 	udiv	x6, x2, x3
    d9d8:	dac010c8 	clz	x8, x6
    d9dc:	b5000408 	cbnz	x8, da5c <__divti3+0x28c>
    d9e0:	d360fcc9 	lsr	x9, x6, #32
    d9e4:	92407cc5 	and	x5, x6, #0xffffffff
    d9e8:	cb060023 	sub	x3, x1, x6
    d9ec:	d2800021 	mov	x1, #0x1                   	// #1
    d9f0:	9ac90868 	udiv	x8, x3, x9
    d9f4:	9b098d03 	msub	x3, x8, x9, x3
    d9f8:	aa0803e0 	mov	x0, x8
    d9fc:	9b057d02 	mul	x2, x8, x5
    da00:	93c78063 	extr	x3, x3, x7, #32
    da04:	eb03005f 	cmp	x2, x3
    da08:	540000a9 	b.ls	da1c <__divti3+0x24c>  // b.plast
    da0c:	ab0300c3 	adds	x3, x6, x3
    da10:	d1000500 	sub	x0, x8, #0x1
    da14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    da18:	54000968 	b.hi	db44 <__divti3+0x374>  // b.pmore
    da1c:	cb020063 	sub	x3, x3, x2
    da20:	9ac90862 	udiv	x2, x3, x9
    da24:	aa0203e8 	mov	x8, x2
    da28:	9b098c42 	msub	x2, x2, x9, x3
    da2c:	aa0703e3 	mov	x3, x7
    da30:	9b057d05 	mul	x5, x8, x5
    da34:	b3607c43 	bfi	x3, x2, #32, #32
    da38:	eb0300bf 	cmp	x5, x3
    da3c:	540000c9 	b.ls	da54 <__divti3+0x284>  // b.plast
    da40:	ab0300c2 	adds	x2, x6, x3
    da44:	d1000503 	sub	x3, x8, #0x1
    da48:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    da4c:	d1000908 	sub	x8, x8, #0x2
    da50:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    da54:	aa008100 	orr	x0, x8, x0, lsl #32
    da58:	17ffff90 	b	d898 <__divti3+0xc8>
    da5c:	9ac820c6 	lsl	x6, x6, x8
    da60:	d2800803 	mov	x3, #0x40                  	// #64
    da64:	cb080063 	sub	x3, x3, x8
    da68:	d360fcc9 	lsr	x9, x6, #32
    da6c:	9ac82027 	lsl	x7, x1, x8
    da70:	92407cc5 	and	x5, x6, #0xffffffff
    da74:	9ac32422 	lsr	x2, x1, x3
    da78:	9ac32403 	lsr	x3, x0, x3
    da7c:	aa070063 	orr	x3, x3, x7
    da80:	9ac9084a 	udiv	x10, x2, x9
    da84:	9ac82007 	lsl	x7, x0, x8
    da88:	9b098940 	msub	x0, x10, x9, x2
    da8c:	aa0a03e1 	mov	x1, x10
    da90:	9b0a7ca2 	mul	x2, x5, x10
    da94:	93c38000 	extr	x0, x0, x3, #32
    da98:	eb00005f 	cmp	x2, x0
    da9c:	540000a9 	b.ls	dab0 <__divti3+0x2e0>  // b.plast
    daa0:	ab0000c0 	adds	x0, x6, x0
    daa4:	d1000541 	sub	x1, x10, #0x1
    daa8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    daac:	54000468 	b.hi	db38 <__divti3+0x368>  // b.pmore
    dab0:	cb020000 	sub	x0, x0, x2
    dab4:	9ac9080a 	udiv	x10, x0, x9
    dab8:	9b098140 	msub	x0, x10, x9, x0
    dabc:	aa0a03e2 	mov	x2, x10
    dac0:	9b0a7ca8 	mul	x8, x5, x10
    dac4:	b3607c03 	bfi	x3, x0, #32, #32
    dac8:	eb03011f 	cmp	x8, x3
    dacc:	540000a9 	b.ls	dae0 <__divti3+0x310>  // b.plast
    dad0:	ab0300c3 	adds	x3, x6, x3
    dad4:	d1000542 	sub	x2, x10, #0x1
    dad8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    dadc:	54000288 	b.hi	db2c <__divti3+0x35c>  // b.pmore
    dae0:	cb080063 	sub	x3, x3, x8
    dae4:	aa018041 	orr	x1, x2, x1, lsl #32
    dae8:	17ffffc2 	b	d9f0 <__divti3+0x220>
    daec:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    daf0:	d2800001 	mov	x1, #0x0                   	// #0
    daf4:	9a9f87e0 	cset	x0, ls	// ls = plast
    daf8:	17ffff68 	b	d898 <__divti3+0xc8>
    dafc:	aa0103e0 	mov	x0, x1
    db00:	d2800001 	mov	x1, #0x0                   	// #0
    db04:	17ffff65 	b	d898 <__divti3+0xc8>
    db08:	d1000860 	sub	x0, x3, #0x2
    db0c:	8b0600a5 	add	x5, x5, x6
    db10:	17ffff52 	b	d858 <__divti3+0x88>
    db14:	d1000961 	sub	x1, x11, #0x2
    db18:	8b0800a5 	add	x5, x5, x8
    db1c:	17ffff85 	b	d930 <__divti3+0x160>
    db20:	d1000965 	sub	x5, x11, #0x2
    db24:	8b080063 	add	x3, x3, x8
    db28:	17ffff8e 	b	d960 <__divti3+0x190>
    db2c:	d1000942 	sub	x2, x10, #0x2
    db30:	8b060063 	add	x3, x3, x6
    db34:	17ffffeb 	b	dae0 <__divti3+0x310>
    db38:	d1000941 	sub	x1, x10, #0x2
    db3c:	8b060000 	add	x0, x0, x6
    db40:	17ffffdc 	b	dab0 <__divti3+0x2e0>
    db44:	d1000900 	sub	x0, x8, #0x2
    db48:	8b060063 	add	x3, x3, x6
    db4c:	17ffffb4 	b	da1c <__divti3+0x24c>

000000000000db50 <__modti3>:
    db50:	d503245f 	bti	c
    db54:	d2800004 	mov	x4, #0x0                   	// #0
    db58:	b6f80081 	tbz	x1, #63, db68 <__modti3+0x18>
    db5c:	eb0003e0 	negs	x0, x0
    db60:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    db64:	da0103e1 	ngc	x1, x1
    db68:	f100007f 	cmp	x3, #0x0
    db6c:	5400128b 	b.lt	ddbc <__modti3+0x26c>  // b.tstop
    db70:	aa0003e7 	mov	x7, x0
    db74:	aa0103e6 	mov	x6, x1
    db78:	540004e1 	b.ne	dc14 <__modti3+0xc4>  // b.any
    db7c:	eb02003f 	cmp	x1, x2
    db80:	54000dc2 	b.cs	dd38 <__modti3+0x1e8>  // b.hs, b.nlast
    db84:	dac01043 	clz	x3, x2
    db88:	aa0303e5 	mov	x5, x3
    db8c:	b40000e3 	cbz	x3, dba8 <__modti3+0x58>
    db90:	4b0303e6 	neg	w6, w3
    db94:	9ac32021 	lsl	x1, x1, x3
    db98:	9ac32042 	lsl	x2, x2, x3
    db9c:	9ac62406 	lsr	x6, x0, x6
    dba0:	aa0100c6 	orr	x6, x6, x1
    dba4:	9ac32007 	lsl	x7, x0, x3
    dba8:	d360fc40 	lsr	x0, x2, #32
    dbac:	92407c43 	and	x3, x2, #0xffffffff
    dbb0:	9ac008c1 	udiv	x1, x6, x0
    dbb4:	9b009826 	msub	x6, x1, x0, x6
    dbb8:	9b017c61 	mul	x1, x3, x1
    dbbc:	93c780c6 	extr	x6, x6, x7, #32
    dbc0:	eb06003f 	cmp	x1, x6
    dbc4:	540000a9 	b.ls	dbd8 <__modti3+0x88>  // b.plast
    dbc8:	ab060046 	adds	x6, x2, x6
    dbcc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    dbd0:	8b0200c8 	add	x8, x6, x2
    dbd4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    dbd8:	cb0100c6 	sub	x6, x6, x1
    dbdc:	9ac008c8 	udiv	x8, x6, x0
    dbe0:	9b009901 	msub	x1, x8, x0, x6
    dbe4:	aa0703e0 	mov	x0, x7
    dbe8:	9b087c63 	mul	x3, x3, x8
    dbec:	b3607c20 	bfi	x0, x1, #32, #32
    dbf0:	eb00007f 	cmp	x3, x0
    dbf4:	54001088 	b.hi	de04 <__modti3+0x2b4>  // b.pmore
    dbf8:	cb030000 	sub	x0, x0, x3
    dbfc:	9ac52400 	lsr	x0, x0, x5
    dc00:	d2800001 	mov	x1, #0x0                   	// #0
    dc04:	b4000064 	cbz	x4, dc10 <__modti3+0xc0>
    dc08:	eb0003e0 	negs	x0, x0
    dc0c:	da0103e1 	ngc	x1, x1
    dc10:	d65f03c0 	ret
    dc14:	dac01066 	clz	x6, x3
    dc18:	eb03003f 	cmp	x1, x3
    dc1c:	54ffff43 	b.cc	dc04 <__modti3+0xb4>  // b.lo, b.ul, b.last
    dc20:	93407cc5 	sxtw	x5, w6
    dc24:	d2800808 	mov	x8, #0x40                  	// #64
    dc28:	cb050108 	sub	x8, x8, x5
    dc2c:	9ac62063 	lsl	x3, x3, x6
    dc30:	9ac62025 	lsl	x5, x1, x6
    dc34:	9ac82447 	lsr	x7, x2, x8
    dc38:	aa0300e7 	orr	x7, x7, x3
    dc3c:	9ac82423 	lsr	x3, x1, x8
    dc40:	92407cec 	and	x12, x7, #0xffffffff
    dc44:	d360fcea 	lsr	x10, x7, #32
    dc48:	9ac82401 	lsr	x1, x0, x8
    dc4c:	aa050021 	orr	x1, x1, x5
    dc50:	9ac62042 	lsl	x2, x2, x6
    dc54:	9ac62000 	lsl	x0, x0, x6
    dc58:	9aca086b 	udiv	x11, x3, x10
    dc5c:	9b0a8d63 	msub	x3, x11, x10, x3
    dc60:	aa0b03e5 	mov	x5, x11
    dc64:	9b0b7d89 	mul	x9, x12, x11
    dc68:	93c18063 	extr	x3, x3, x1, #32
    dc6c:	eb03013f 	cmp	x9, x3
    dc70:	540000a9 	b.ls	dc84 <__modti3+0x134>  // b.plast
    dc74:	ab0300e3 	adds	x3, x7, x3
    dc78:	d1000565 	sub	x5, x11, #0x1
    dc7c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    dc80:	54001168 	b.hi	deac <__modti3+0x35c>  // b.pmore
    dc84:	cb090063 	sub	x3, x3, x9
    dc88:	9aca086b 	udiv	x11, x3, x10
    dc8c:	9b0a8d6a 	msub	x10, x11, x10, x3
    dc90:	aa0b03e9 	mov	x9, x11
    dc94:	9b0b7d8c 	mul	x12, x12, x11
    dc98:	b3607d41 	bfi	x1, x10, #32, #32
    dc9c:	eb01019f 	cmp	x12, x1
    dca0:	540000a9 	b.ls	dcb4 <__modti3+0x164>  // b.plast
    dca4:	ab0100e1 	adds	x1, x7, x1
    dca8:	d1000569 	sub	x9, x11, #0x1
    dcac:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    dcb0:	54000f88 	b.hi	dea0 <__modti3+0x350>  // b.pmore
    dcb4:	aa058123 	orr	x3, x9, x5, lsl #32
    dcb8:	92407c4b 	and	x11, x2, #0xffffffff
    dcbc:	2a0903e9 	mov	w9, w9
    dcc0:	d360fc4a 	lsr	x10, x2, #32
    dcc4:	d360fc63 	lsr	x3, x3, #32
    dcc8:	cb0c0021 	sub	x1, x1, x12
    dccc:	aa0a03ec 	mov	x12, x10
    dcd0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    dcd4:	9b0b7d25 	mul	x5, x9, x11
    dcd8:	9b0b7c6b 	mul	x11, x3, x11
    dcdc:	9b0a2d29 	madd	x9, x9, x10, x11
    dce0:	92407caa 	and	x10, x5, #0xffffffff
    dce4:	9b0c7c63 	mul	x3, x3, x12
    dce8:	8b458125 	add	x5, x9, x5, lsr #32
    dcec:	8b0d0069 	add	x9, x3, x13
    dcf0:	eb05017f 	cmp	x11, x5
    dcf4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    dcf8:	8b058149 	add	x9, x10, x5, lsl #32
    dcfc:	8b458063 	add	x3, x3, x5, lsr #32
    dd00:	eb03003f 	cmp	x1, x3
    dd04:	54000063 	b.cc	dd10 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    dd08:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    dd0c:	54000082 	b.cs	dd1c <__modti3+0x1cc>  // b.hs, b.nlast
    dd10:	eb020129 	subs	x9, x9, x2
    dd14:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    dd18:	cb070063 	sub	x3, x3, x7
    dd1c:	eb090000 	subs	x0, x0, x9
    dd20:	da030021 	sbc	x1, x1, x3
    dd24:	9ac62400 	lsr	x0, x0, x6
    dd28:	9ac82028 	lsl	x8, x1, x8
    dd2c:	aa000100 	orr	x0, x8, x0
    dd30:	9ac62421 	lsr	x1, x1, x6
    dd34:	17ffffb4 	b	dc04 <__modti3+0xb4>
    dd38:	b5000062 	cbnz	x2, dd44 <__modti3+0x1f4>
    dd3c:	d2800023 	mov	x3, #0x1                   	// #1
    dd40:	9ac20862 	udiv	x2, x3, x2
    dd44:	dac01048 	clz	x8, x2
    dd48:	aa0803e5 	mov	x5, x8
    dd4c:	b5000668 	cbnz	x8, de18 <__modti3+0x2c8>
    dd50:	cb020020 	sub	x0, x1, x2
    dd54:	d360fc49 	lsr	x9, x2, #32
    dd58:	92407c4a 	and	x10, x2, #0xffffffff
    dd5c:	9ac90801 	udiv	x1, x0, x9
    dd60:	9b098020 	msub	x0, x1, x9, x0
    dd64:	9b0a7c21 	mul	x1, x1, x10
    dd68:	93c78000 	extr	x0, x0, x7, #32
    dd6c:	eb00003f 	cmp	x1, x0
    dd70:	540000a9 	b.ls	dd84 <__modti3+0x234>  // b.plast
    dd74:	ab000040 	adds	x0, x2, x0
    dd78:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    dd7c:	8b020003 	add	x3, x0, x2
    dd80:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    dd84:	cb010001 	sub	x1, x0, x1
    dd88:	9ac90820 	udiv	x0, x1, x9
    dd8c:	9b098403 	msub	x3, x0, x9, x1
    dd90:	aa0703e1 	mov	x1, x7
    dd94:	9b0a7c00 	mul	x0, x0, x10
    dd98:	b3607c61 	bfi	x1, x3, #32, #32
    dd9c:	eb01001f 	cmp	x0, x1
    dda0:	540000a9 	b.ls	ddb4 <__modti3+0x264>  // b.plast
    dda4:	ab010041 	adds	x1, x2, x1
    dda8:	8b020022 	add	x2, x1, x2
    ddac:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ddb0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ddb4:	cb000020 	sub	x0, x1, x0
    ddb8:	17ffff91 	b	dbfc <__modti3+0xac>
    ddbc:	eb0203e5 	negs	x5, x2
    ddc0:	aa0003e7 	mov	x7, x0
    ddc4:	da0303e8 	ngc	x8, x3
    ddc8:	aa0503e2 	mov	x2, x5
    ddcc:	aa0803e3 	mov	x3, x8
    ddd0:	aa0103e6 	mov	x6, x1
    ddd4:	b4ffed48 	cbz	x8, db7c <__modti3+0x2c>
    ddd8:	eb01011f 	cmp	x8, x1
    dddc:	54fff148 	b.hi	dc04 <__modti3+0xb4>  // b.pmore
    dde0:	dac01109 	clz	x9, x8
    dde4:	2a0903e6 	mov	w6, w9
    dde8:	b5fff1c9 	cbnz	x9, dc20 <__modti3+0xd0>
    ddec:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ddf0:	54000068 	b.hi	ddfc <__modti3+0x2ac>  // b.pmore
    ddf4:	eb050007 	subs	x7, x0, x5
    ddf8:	da080021 	sbc	x1, x1, x8
    ddfc:	aa0703e0 	mov	x0, x7
    de00:	17ffff81 	b	dc04 <__modti3+0xb4>
    de04:	ab000040 	adds	x0, x2, x0
    de08:	8b020002 	add	x2, x0, x2
    de0c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    de10:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    de14:	17ffff79 	b	dbf8 <__modti3+0xa8>
    de18:	9ac82042 	lsl	x2, x2, x8
    de1c:	d2800803 	mov	x3, #0x40                  	// #64
    de20:	cb080063 	sub	x3, x3, x8
    de24:	d360fc49 	lsr	x9, x2, #32
    de28:	9ac82027 	lsl	x7, x1, x8
    de2c:	92407c4a 	and	x10, x2, #0xffffffff
    de30:	9ac32426 	lsr	x6, x1, x3
    de34:	9ac32403 	lsr	x3, x0, x3
    de38:	aa070063 	orr	x3, x3, x7
    de3c:	9ac908c1 	udiv	x1, x6, x9
    de40:	9ac82007 	lsl	x7, x0, x8
    de44:	9b099820 	msub	x0, x1, x9, x6
    de48:	9b017d41 	mul	x1, x10, x1
    de4c:	93c38000 	extr	x0, x0, x3, #32
    de50:	eb00003f 	cmp	x1, x0
    de54:	540000a9 	b.ls	de68 <__modti3+0x318>  // b.plast
    de58:	ab000040 	adds	x0, x2, x0
    de5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    de60:	8b020006 	add	x6, x0, x2
    de64:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    de68:	cb010000 	sub	x0, x0, x1
    de6c:	9ac90801 	udiv	x1, x0, x9
    de70:	9b098026 	msub	x6, x1, x9, x0
    de74:	aa0303e0 	mov	x0, x3
    de78:	9b017d41 	mul	x1, x10, x1
    de7c:	b3607cc0 	bfi	x0, x6, #32, #32
    de80:	eb00003f 	cmp	x1, x0
    de84:	540000a9 	b.ls	de98 <__modti3+0x348>  // b.plast
    de88:	ab000040 	adds	x0, x2, x0
    de8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    de90:	8b020003 	add	x3, x0, x2
    de94:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    de98:	cb010000 	sub	x0, x0, x1
    de9c:	17ffffb0 	b	dd5c <__modti3+0x20c>
    dea0:	d1000969 	sub	x9, x11, #0x2
    dea4:	8b070021 	add	x1, x1, x7
    dea8:	17ffff83 	b	dcb4 <__modti3+0x164>
    deac:	d1000965 	sub	x5, x11, #0x2
    deb0:	8b070063 	add	x3, x3, x7
    deb4:	17ffff74 	b	dc84 <__modti3+0x134>
    deb8:	d503201f 	nop
    debc:	d503201f 	nop

000000000000dec0 <atexit>:
    dec0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    dec4:	f0000102 	adrp	x2, 30000 <__data_start>
    dec8:	d2800001 	mov	x1, #0x0                   	// #0
    decc:	910003fd 	mov	x29, sp
    ded0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ded4:	f9400442 	ldr	x2, [x2, #8]
    ded8:	17ffd20e 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000dedc <_fini>:
    dedc:	d503201f 	nop
    dee0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    dee4:	910003fd 	mov	x29, sp
    dee8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    deec:	d65f03c0 	ret
