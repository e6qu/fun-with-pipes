
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__modti3+0x2a0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910f20a5 	add	x5, x5, #0x3c8
    2aa0:	f0000044 	adrp	x4, d000 <__modti3+0x2a0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	910f4084 	add	x4, x4, #0x3d0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940004f0 	bl	3e90 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9100c2a1 	add	x1, x21, #0x30
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xeee0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9003c20 	str	x0, [x1, #120]
    2b2c:	940006f9 	bl	4710 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2b34:	911b8000 	add	x0, x0, #0x6e0
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x21d0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91134042 	add	x2, x2, #0x4d0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c2b5 	add	x21, x21, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430aa0 	ldr	w0, [x21, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2c4c:	911c4000 	add	x0, x0, #0x710
    2c50:	94000490 	bl	3e90 <fwp_trap>
    2c54:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2c58:	911bc000 	add	x0, x0, #0x6f0
    2c5c:	9400048d 	bl	3e90 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2ca0:	911da000 	add	x0, x0, #0x768
    2ca4:	9400047b 	bl	3e90 <fwp_trap>
    2ca8:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2cac:	911ce000 	add	x0, x0, #0x738
    2cb0:	94000478 	bl	3e90 <fwp_trap>
    2cb4:	f0000040 	adrp	x0, d000 <__modti3+0x2a0>
    2cb8:	911e4000 	add	x0, x0, #0x790
    2cbc:	94000475 	bl	3e90 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000041 	adrp	x1, d000 <__modti3+0x2a0>
    2eb4:	9136c021 	add	x1, x1, #0xdb0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3050:	91042000 	add	x0, x0, #0x108
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000041 	adrp	x1, d000 <__modti3+0x2a0>
    3118:	91364021 	add	x1, x1, #0xd90
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    33f0:	91042000 	add	x0, x0, #0x108
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000041 	adrp	x1, d000 <__modti3+0x2a0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91048021 	add	x1, x1, #0x120
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000041 	adrp	x1, d000 <__modti3+0x2a0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	9104a021 	add	x1, x1, #0x128
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000041 	adrp	x1, d000 <__modti3+0x2a0>
    3560:	9104c021 	add	x1, x1, #0x130
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_format_g.constprop.0>:
    3580:	d10483ff 	sub	sp, sp, #0x120
    3584:	d0000044 	adrp	x4, d000 <__modti3+0x2a0>
    3588:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    358c:	f947f442 	ldr	x2, [x2, #4072]
    3590:	9104e084 	add	x4, x4, #0x138
    3594:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3598:	9102c3fd 	add	x29, sp, #0xb0
    359c:	d2800803 	mov	x3, #0x40                  	// #64
    35a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    35a4:	93407c38 	sxtw	x24, w1
    35a8:	aa0303e1 	mov	x1, x3
    35ac:	fd008be8 	str	d8, [sp, #272]
    35b0:	1e604008 	fmov	d8, d0
    35b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    35b8:	910083f4 	add	x20, sp, #0x20
    35bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    35c0:	aa0003f5 	mov	x21, x0
    35c4:	a91073fb 	stp	x27, x28, [sp, #256]
    35c8:	5100071c 	sub	w28, w24, #0x1
    35cc:	2a1c03e5 	mov	w5, w28
    35d0:	f9400040 	ldr	x0, [x2]
    35d4:	f90057e0 	str	x0, [sp, #168]
    35d8:	d2800000 	mov	x0, #0x0                   	// #0
    35dc:	52800042 	mov	w2, #0x2                   	// #2
    35e0:	aa1403e0 	mov	x0, x20
    35e4:	97fffc83 	bl	27f0 <__snprintf_chk@plt>
    35e8:	52800ca1 	mov	w1, #0x65                  	// #101
    35ec:	aa1403e0 	mov	x0, x20
    35f0:	97fffcdc 	bl	2960 <strchr@plt>
    35f4:	aa0003f3 	mov	x19, x0
    35f8:	52800142 	mov	w2, #0xa                   	// #10
    35fc:	91000400 	add	x0, x0, #0x1
    3600:	d2800001 	mov	x1, #0x0                   	// #0
    3604:	97fffcc7 	bl	2920 <strtol@plt>
    3608:	aa0003f7 	mov	x23, x0
    360c:	11001400 	add	w0, w0, #0x5
    3610:	7100541f 	cmp	w0, #0x15
    3614:	54000d68 	b.hi	37c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3618:	4b170385 	sub	w5, w28, w23
    361c:	710000bf 	cmp	w5, #0x0
    3620:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3624:	54000b80 	b.eq	3794 <fwp_format_g.constprop.0+0x214>  // b.none
    3628:	394083e0 	ldrb	w0, [sp, #32]
    362c:	cb180273 	sub	x19, x19, x24
    3630:	91000673 	add	x19, x19, #0x1
    3634:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3638:	7100b41f 	cmp	w0, #0x2d
    363c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3640:	1a9f17e4 	cset	w4, eq	// eq = none
    3644:	cb010266 	sub	x6, x19, x1
    3648:	d10004da 	sub	x26, x6, #0x1
    364c:	540018a0 	b.eq	3960 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3650:	910183f9 	add	x25, sp, #0x60
    3654:	d280091b 	mov	x27, #0x48                  	// #72
    3658:	aa1903e7 	mov	x7, x25
    365c:	91000423 	add	x3, x1, #0x1
    3660:	91011cc6 	add	x6, x6, #0x47
    3664:	910004f6 	add	x22, x7, #0x1
    3668:	37f80ff7 	tbnz	w23, #31, 3864 <fwp_format_g.constprop.0+0x2e4>
    366c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3670:	93407ef7 	sxtw	x23, w23
    3674:	390000e4 	strb	w4, [x7]
    3678:	aa1303e1 	mov	x1, x19
    367c:	aa1703e2 	mov	x2, x23
    3680:	aa1603e0 	mov	x0, x22
    3684:	b9000be5 	str	w5, [sp, #8]
    3688:	cb170374 	sub	x20, x27, x23
    368c:	a9011be3 	stp	x3, x6, [sp, #16]
    3690:	97fffc10 	bl	26d0 <memcpy@plt>
    3694:	d1000694 	sub	x20, x20, #0x1
    3698:	f9400be3 	ldr	x3, [sp, #16]
    369c:	8b1702d6 	add	x22, x22, x23
    36a0:	aa1603e0 	mov	x0, x22
    36a4:	aa1a03e2 	mov	x2, x26
    36a8:	aa0303e1 	mov	x1, x3
    36ac:	aa1403e3 	mov	x3, x20
    36b0:	97fffc48 	bl	27d0 <__memcpy_chk@plt>
    36b4:	8b1a02d6 	add	x22, x22, x26
    36b8:	f9400fe6 	ldr	x6, [sp, #24]
    36bc:	d2800900 	mov	x0, #0x48                  	// #72
    36c0:	b9400be5 	ldr	w5, [sp, #8]
    36c4:	8b170261 	add	x1, x19, x23
    36c8:	cb1400c3 	sub	x3, x6, x20
    36cc:	cb060294 	sub	x20, x20, x6
    36d0:	f101207f 	cmp	x3, #0x48
    36d4:	93407cb8 	sxtw	x24, w5
    36d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    36dc:	aa1803e2 	mov	x2, x24
    36e0:	8b1802d3 	add	x19, x22, x24
    36e4:	8b140063 	add	x3, x3, x20
    36e8:	aa1603e0 	mov	x0, x22
    36ec:	97fffc39 	bl	27d0 <__memcpy_chk@plt>
    36f0:	cb190273 	sub	x19, x19, x25
    36f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    36f8:	eb00027f 	cmp	x19, x0
    36fc:	aa1903e1 	mov	x1, x25
    3700:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3704:	aa1503e0 	mov	x0, x21
    3708:	aa1303e2 	mov	x2, x19
    370c:	97fffbf1 	bl	26d0 <memcpy@plt>
    3710:	38336abf 	strb	wzr, [x21, x19]
    3714:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3718:	aa1503e0 	mov	x0, x21
    371c:	97fffbfd 	bl	2710 <strlen@plt>
    3720:	aa0003f3 	mov	x19, x0
    3724:	528005c1 	mov	w1, #0x2e                  	// #46
    3728:	aa1503e0 	mov	x0, x21
    372c:	97fffc8d 	bl	2960 <strchr@plt>
    3730:	b4000140 	cbz	x0, 3758 <fwp_format_g.constprop.0+0x1d8>
    3734:	b4000133 	cbz	x19, 3758 <fwp_format_g.constprop.0+0x1d8>
    3738:	aa1303e1 	mov	x1, x19
    373c:	d1000673 	sub	x19, x19, #0x1
    3740:	38736aa0 	ldrb	w0, [x21, x19]
    3744:	7100c01f 	cmp	w0, #0x30
    3748:	54001001 	b.ne	3948 <fwp_format_g.constprop.0+0x3c8>  // b.any
    374c:	38336abf 	strb	wzr, [x21, x19]
    3750:	b5ffff53 	cbnz	x19, 3738 <fwp_format_g.constprop.0+0x1b8>
    3754:	d503201f 	nop
    3758:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    375c:	f947f400 	ldr	x0, [x0, #4072]
    3760:	f94057e2 	ldr	x2, [sp, #168]
    3764:	f9400001 	ldr	x1, [x0]
    3768:	eb010042 	subs	x2, x2, x1
    376c:	d2800001 	mov	x1, #0x0                   	// #0
    3770:	54001061 	b.ne	397c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3774:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3778:	a94c53f3 	ldp	x19, x20, [sp, #192]
    377c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3780:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3784:	a95073fb 	ldp	x27, x28, [sp, #256]
    3788:	fd408be8 	ldr	d8, [sp, #272]
    378c:	910483ff 	add	sp, sp, #0x120
    3790:	d65f03c0 	ret
    3794:	1e604100 	fmov	d0, d8
    3798:	710000bf 	cmp	w5, #0x0
    379c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    37a0:	aa1503e0 	mov	x0, x21
    37a4:	d0000044 	adrp	x4, d000 <__modti3+0x2a0>
    37a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37ac:	91054084 	add	x4, x4, #0x150
    37b0:	52800042 	mov	w2, #0x2                   	// #2
    37b4:	d2803201 	mov	x1, #0x190                 	// #400
    37b8:	97fffc0e 	bl	27f0 <__snprintf_chk@plt>
    37bc:	17ffffd7 	b	3718 <fwp_format_g.constprop.0+0x198>
    37c0:	cb140273 	sub	x19, x19, x20
    37c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    37c8:	910183f9 	add	x25, sp, #0x60
    37cc:	aa1303e2 	mov	x2, x19
    37d0:	aa1403e1 	mov	x1, x20
    37d4:	aa1903e0 	mov	x0, x25
    37d8:	d2800803 	mov	x3, #0x40                  	// #64
    37dc:	97fffbfd 	bl	27d0 <__memcpy_chk@plt>
    37e0:	38336b3f 	strb	wzr, [x25, x19]
    37e4:	aa1903e0 	mov	x0, x25
    37e8:	528005c1 	mov	w1, #0x2e                  	// #46
    37ec:	97fffc5d 	bl	2960 <strchr@plt>
    37f0:	b40001c0 	cbz	x0, 3828 <fwp_format_g.constprop.0+0x2a8>
    37f4:	b50000b3 	cbnz	x19, 3808 <fwp_format_g.constprop.0+0x288>
    37f8:	1400000c 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    37fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3800:	f1000673 	subs	x19, x19, #0x1
    3804:	54000120 	b.eq	3828 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3808:	8b130320 	add	x0, x25, x19
    380c:	385ff001 	ldurb	w1, [x0, #-1]
    3810:	7100c03f 	cmp	w1, #0x30
    3814:	54ffff40 	b.eq	37fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3818:	d1000673 	sub	x19, x19, #0x1
    381c:	38736b20 	ldrb	w0, [x25, x19]
    3820:	7100b81f 	cmp	w0, #0x2e
    3824:	54000a80 	b.eq	3974 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3828:	710002ff 	cmp	w23, #0x0
    382c:	528005a1 	mov	w1, #0x2d                  	// #45
    3830:	aa1903e5 	mov	x5, x25
    3834:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3838:	aa1503e0 	mov	x0, x21
    383c:	52800566 	mov	w6, #0x2b                  	// #43
    3840:	d0000044 	adrp	x4, d000 <__modti3+0x2a0>
    3844:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3848:	91050084 	add	x4, x4, #0x140
    384c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3850:	52800042 	mov	w2, #0x2                   	// #2
    3854:	d2803201 	mov	x1, #0x190                 	// #400
    3858:	97fffbe6 	bl	27f0 <__snprintf_chk@plt>
    385c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3860:	17ffffbe 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3864:	52800605 	mov	w5, #0x30                  	// #48
    3868:	390000e5 	strb	w5, [x7]
    386c:	d100077b 	sub	x27, x27, #0x1
    3870:	aa0303e1 	mov	x1, x3
    3874:	aa1603e0 	mov	x0, x22
    3878:	aa1b03e3 	mov	x3, x27
    387c:	aa1a03e2 	mov	x2, x26
    3880:	f90007e6 	str	x6, [sp, #8]
    3884:	b90013e4 	str	w4, [sp, #16]
    3888:	8b1a02d6 	add	x22, x22, x26
    388c:	b9001be5 	str	w5, [sp, #24]
    3890:	97fffbd0 	bl	27d0 <__memcpy_chk@plt>
    3894:	f94007e6 	ldr	x6, [sp, #8]
    3898:	2a3703e7 	mvn	w7, w23
    389c:	b94013e4 	ldr	w4, [sp, #16]
    38a0:	cb1b00c1 	sub	x1, x6, x27
    38a4:	cb06037b 	sub	x27, x27, x6
    38a8:	f101203f 	cmp	x1, #0x48
    38ac:	d2800906 	mov	x6, #0x48                  	// #72
    38b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    38b4:	8b1b0023 	add	x3, x1, x27
    38b8:	310006ff 	cmn	w23, #0x1
    38bc:	54000220 	b.eq	3900 <fwp_format_g.constprop.0+0x380>  // b.none
    38c0:	b9401be5 	ldr	w5, [sp, #24]
    38c4:	d2800001 	mov	x1, #0x0                   	// #0
    38c8:	f101207f 	cmp	x3, #0x48
    38cc:	d1000462 	sub	x2, x3, #0x1
    38d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    38d4:	38216ac5 	strb	w5, [x22, x1]
    38d8:	cb030003 	sub	x3, x0, x3
    38dc:	91000421 	add	x1, x1, #0x1
    38e0:	91000463 	add	x3, x3, #0x1
    38e4:	eb00007f 	cmp	x3, x0
    38e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38ec:	cb000063 	sub	x3, x3, x0
    38f0:	8b020063 	add	x3, x3, x2
    38f4:	6b0100ff 	cmp	w7, w1
    38f8:	54fffe8c 	b.gt	38c8 <fwp_format_g.constprop.0+0x348>
    38fc:	8b2742d6 	add	x22, x22, w7, uxtw
    3900:	f101207f 	cmp	x3, #0x48
    3904:	d2800905 	mov	x5, #0x48                  	// #72
    3908:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    390c:	aa1603e0 	mov	x0, x22
    3910:	cb0300a1 	sub	x1, x5, x3
    3914:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3918:	91000421 	add	x1, x1, #0x1
    391c:	d1000463 	sub	x3, x3, #0x1
    3920:	eb05003f 	cmp	x1, x5
    3924:	38001402 	strb	w2, [x0], #1
    3928:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    392c:	93407f82 	sxtw	x2, w28
    3930:	cb050025 	sub	x5, x1, x5
    3934:	aa1303e1 	mov	x1, x19
    3938:	8b0300a3 	add	x3, x5, x3
    393c:	8b1802d3 	add	x19, x22, x24
    3940:	97fffba4 	bl	27d0 <__memcpy_chk@plt>
    3944:	17ffff6b 	b	36f0 <fwp_format_g.constprop.0+0x170>
    3948:	d1000421 	sub	x1, x1, #0x1
    394c:	38616aa0 	ldrb	w0, [x21, x1]
    3950:	7100b81f 	cmp	w0, #0x2e
    3954:	54fff021 	b.ne	3758 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3958:	38216abf 	strb	wzr, [x21, x1]
    395c:	17ffff7f 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3960:	910187e7 	add	x7, sp, #0x61
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d28008fb 	mov	x27, #0x47                  	// #71
    396c:	390183e0 	strb	w0, [sp, #96]
    3970:	17ffff3b 	b	365c <fwp_format_g.constprop.0+0xdc>
    3974:	38336b3f 	strb	wzr, [x25, x19]
    3978:	17ffffac 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    397c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3980:	97fffbc0 	bl	2880 <__stack_chk_fail@plt>

0000000000003984 <fwp_heap_report>:
    3984:	d105c3ff 	sub	sp, sp, #0x170
    3988:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    398c:	91150042 	add	x2, x2, #0x540
    3990:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3994:	f947e821 	ldr	x1, [x1, #4048]
    3998:	a9117bfd 	stp	x29, x30, [sp, #272]
    399c:	910443fd 	add	x29, sp, #0x110
    39a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    39a4:	f947f400 	ldr	x0, [x0, #4072]
    39a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    39ac:	a91463f7 	stp	x23, x24, [sp, #320]
    39b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    39b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    39b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    39bc:	fd4a2049 	ldr	d9, [x2, #5184]
    39c0:	f9400036 	ldr	x22, [x1]
    39c4:	f9400001 	ldr	x1, [x0]
    39c8:	f90087e1 	str	x1, [sp, #264]
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	f949e459 	ldr	x25, [x2, #5064]
    39d4:	d0000041 	adrp	x1, d000 <__modti3+0x2a0>
    39d8:	f94a1057 	ldr	x23, [x2, #5152]
    39dc:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    39e0:	f94a1458 	ldr	x24, [x2, #5160]
    39e4:	91056021 	add	x1, x1, #0x158
    39e8:	91058000 	add	x0, x0, #0x160
    39ec:	97fffb89 	bl	2810 <fopen@plt>
    39f0:	b4000760 	cbz	x0, 3adc <fwp_heap_report+0x158>
    39f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    39f8:	a91253f3 	stp	x19, x20, [sp, #288]
    39fc:	aa0003f4 	mov	x20, x0
    3a00:	910023f3 	add	x19, sp, #0x8
    3a04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a08:	72aae915 	movk	w21, #0x5748, lsl #16
    3a0c:	d503201f 	nop
    3a10:	aa1403e2 	mov	x2, x20
    3a14:	aa1303e0 	mov	x0, x19
    3a18:	52802001 	mov	w1, #0x100                 	// #256
    3a1c:	97fffc09 	bl	2a40 <fgets@plt>
    3a20:	b4000280 	cbz	x0, 3a70 <fwp_heap_report+0xec>
    3a24:	b9400261 	ldr	w1, [x19]
    3a28:	6b15003f 	cmp	w1, w21
    3a2c:	54ffff21 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a30:	39401260 	ldrb	w0, [x19, #4]
    3a34:	7101341f 	cmp	w0, #0x4d
    3a38:	54fffec1 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a3c:	394037e0 	ldrb	w0, [sp, #13]
    3a40:	7100e81f 	cmp	w0, #0x3a
    3a44:	54fffe61 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a48:	52800142 	mov	w2, #0xa                   	// #10
    3a4c:	d2800001 	mov	x1, #0x0                   	// #0
    3a50:	91003be0 	add	x0, sp, #0xe
    3a54:	97fffbb3 	bl	2920 <strtol@plt>
    3a58:	aa1403e2 	mov	x2, x20
    3a5c:	aa0003fa 	mov	x26, x0
    3a60:	52802001 	mov	w1, #0x100                 	// #256
    3a64:	aa1303e0 	mov	x0, x19
    3a68:	97fffbf6 	bl	2a40 <fgets@plt>
    3a6c:	b5fffdc0 	cbnz	x0, 3a24 <fwp_heap_report+0xa0>
    3a70:	aa1403e0 	mov	x0, x20
    3a74:	97fffb63 	bl	2800 <fclose@plt>
    3a78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3a7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a80:	f947f400 	ldr	x0, [x0, #4072]
    3a84:	f94087e2 	ldr	x2, [sp, #264]
    3a88:	f9400001 	ldr	x1, [x0]
    3a8c:	eb010042 	subs	x2, x2, x1
    3a90:	d2800001 	mov	x1, #0x0                   	// #0
    3a94:	54000281 	b.ne	3ae4 <fwp_heap_report+0x160>  // b.any
    3a98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a9c:	aa1a03e6 	mov	x6, x26
    3aa0:	aa1903e5 	mov	x5, x25
    3aa4:	aa1803e4 	mov	x4, x24
    3aa8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3aac:	aa1703e3 	mov	x3, x23
    3ab0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3abc:	1e604121 	fmov	d1, d9
    3ac0:	1e604100 	fmov	d0, d8
    3ac4:	d0000042 	adrp	x2, d000 <__modti3+0x2a0>
    3ac8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3acc:	91060042 	add	x2, x2, #0x180
    3ad0:	9105c3ff 	add	sp, sp, #0x170
    3ad4:	52800041 	mov	w1, #0x2                   	// #2
    3ad8:	17fffb86 	b	28f0 <__fprintf_chk@plt>
    3adc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ae0:	17ffffe7 	b	3a7c <fwp_heap_report+0xf8>
    3ae4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ae8:	97fffb66 	bl	2880 <__stack_chk_fail@plt>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_heap_init>:
    3af0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3af4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3af8:	91110061 	add	x1, x3, #0x440
    3afc:	910003fd 	mov	x29, sp
    3b00:	a90153f3 	stp	x19, x20, [sp, #16]
    3b04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3b08:	91150262 	add	x2, x19, #0x540
    3b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b10:	52800024 	mov	w4, #0x1                   	// #1
    3b14:	52800200 	mov	w0, #0x10                  	// #16
    3b18:	b913a444 	str	w4, [x2, #5028]
    3b1c:	d503201f 	nop
    3b20:	b8004420 	str	w0, [x1], #4
    3b24:	11004000 	add	w0, w0, #0x10
    3b28:	7104401f 	cmp	w0, #0x110
    3b2c:	54ffffa1 	b.ne	3b20 <fwp_heap_init+0x30>  // b.any
    3b30:	d0000042 	adrp	x2, d000 <__modti3+0x2a0>
    3b34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3b38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3b3c:	91120021 	add	x1, x1, #0x480
    3b40:	3dc37043 	ldr	q3, [x2, #3520]
    3b44:	d2800000 	mov	x0, #0x0                   	// #0
    3b48:	4e040401 	dup	v1.4s, v0.s[0]
    3b4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3b50:	0f215400 	shl	v0.2s, v0.2s, #1
    3b54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3b58:	3ca06821 	str	q1, [x1, x0]
    3b5c:	91004000 	add	x0, x0, #0x10
    3b60:	f101801f 	cmp	x0, #0x60
    3b64:	54ffff21 	b.ne	3b48 <fwp_heap_init+0x58>  // b.any
    3b68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3b6c:	91110063 	add	x3, x3, #0x440
    3b70:	91138084 	add	x4, x4, #0x4e0
    3b74:	91150266 	add	x6, x19, #0x540
    3b78:	d2800002 	mov	x2, #0x0                   	// #0
    3b7c:	d2800000 	mov	x0, #0x0                   	// #0
    3b80:	d2880205 	mov	x5, #0x4010                	// #16400
    3b84:	d503201f 	nop
    3b88:	910f0001 	add	x1, x0, #0x3c0
    3b8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b90:	eb02003f 	cmp	x1, x2
    3b94:	540000a2 	b.cs	3ba8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b98:	91000400 	add	x0, x0, #0x1
    3b9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ba0:	eb02003f 	cmp	x1, x2
    3ba4:	54ffffa3 	b.cc	3b98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ba8:	91004042 	add	x2, x2, #0x10
    3bac:	38001480 	strb	w0, [x4], #1
    3bb0:	eb05005f 	cmp	x2, x5
    3bb4:	54fffea1 	b.ne	3b88 <fwp_heap_init+0x98>  // b.any
    3bb8:	528000b5 	mov	w21, #0x5                   	// #5
    3bbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3bc0:	14000004 	b	3bd0 <fwp_heap_init+0xe0>
    3bc4:	d342fe94 	lsr	x20, x20, #2
    3bc8:	710006b5 	subs	w21, w21, #0x1
    3bcc:	54000720 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3bd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3bd4:	d2800005 	mov	x5, #0x0                   	// #0
    3bd8:	aa1603e1 	mov	x1, x22
    3bdc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3be0:	52880443 	mov	w3, #0x4022                	// #16418
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	d2800000 	mov	x0, #0x0                   	// #0
    3bec:	97fffb49 	bl	2910 <mmap@plt>
    3bf0:	aa0003e6 	mov	x6, x0
    3bf4:	b100041f 	cmn	x0, #0x1
    3bf8:	54fffe60 	b.eq	3bc4 <fwp_heap_init+0xd4>  // b.none
    3bfc:	b40005a0 	cbz	x0, 3cb0 <fwp_heap_init+0x1c0>
    3c00:	d350fe94 	lsr	x20, x20, #16
    3c04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3c08:	8b0000c7 	add	x7, x6, x0
    3c0c:	91150275 	add	x21, x19, #0x540
    3c10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3c14:	8b140a81 	add	x1, x20, x20, lsl #2
    3c18:	d2800005 	mov	x5, #0x0                   	// #0
    3c1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3c20:	d37df021 	lsl	x1, x1, #3
    3c24:	52880443 	mov	w3, #0x4022                	// #16418
    3c28:	52800002 	mov	w2, #0x0                   	// #0
    3c2c:	d2800000 	mov	x0, #0x0                   	// #0
    3c30:	f909daa7 	str	x7, [x21, #5040]
    3c34:	f909dea6 	str	x6, [x21, #5048]
    3c38:	f909e2b6 	str	x22, [x21, #5056]
    3c3c:	f909eab4 	str	x20, [x21, #5072]
    3c40:	f90a02a1 	str	x1, [x21, #5120]
    3c44:	97fffb33 	bl	2910 <mmap@plt>
    3c48:	aa0003e1 	mov	x1, x0
    3c4c:	b100041f 	cmn	x0, #0x1
    3c50:	54000300 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3c54:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3c58:	91082000 	add	x0, x0, #0x208
    3c5c:	f909fea1 	str	x1, [x21, #5112]
    3c60:	97fffb6c 	bl	2a10 <getenv@plt>
    3c64:	52800002 	mov	w2, #0x0                   	// #0
    3c68:	aa0003e1 	mov	x1, x0
    3c6c:	b40000e0 	cbz	x0, 3c88 <fwp_heap_init+0x198>
    3c70:	39400000 	ldrb	w0, [x0]
    3c74:	340000a0 	cbz	w0, 3c88 <fwp_heap_init+0x198>
    3c78:	7100c000 	subs	w0, w0, #0x30
    3c7c:	54000120 	b.eq	3ca0 <fwp_heap_init+0x1b0>  // b.none
    3c80:	7100001f 	cmp	w0, #0x0
    3c84:	1a9f07e2 	cset	w2, ne	// ne = any
    3c88:	91150273 	add	x19, x19, #0x540
    3c8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c90:	b913aa62 	str	w2, [x19, #5032]
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c9c:	d65f03c0 	ret
    3ca0:	39400420 	ldrb	w0, [x1, #1]
    3ca4:	7100001f 	cmp	w0, #0x0
    3ca8:	1a9f07e2 	cset	w2, ne	// ne = any
    3cac:	17fffff7 	b	3c88 <fwp_heap_init+0x198>
    3cb0:	97fffce0 	bl	3030 <fwp_heap_oom>

0000000000003cb4 <fwp_wake_io>:
    3cb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3cb8:	9100c122 	add	x2, x9, #0x30
    3cbc:	f9400001 	ldr	x1, [x0]
    3cc0:	5280000a 	mov	w10, #0x0                   	// #0
    3cc4:	f9401446 	ldr	x6, [x2, #40]
    3cc8:	52800008 	mov	w8, #0x0                   	// #0
    3ccc:	4f000400 	movi	v0.4s, #0x0
    3cd0:	52800027 	mov	w7, #0x1                   	// #1
    3cd4:	aa0103e2 	mov	x2, x1
    3cd8:	b4000321 	cbz	x1, 3d3c <fwp_wake_io+0x88>
    3cdc:	f9408c25 	ldr	x5, [x1, #280]
    3ce0:	39015c27 	strb	w7, [x1, #87]
    3ce4:	b4000165 	cbz	x5, 3d10 <fwp_wake_io+0x5c>
    3ce8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3cec:	b4000364 	cbz	x4, 3d58 <fwp_wake_io+0xa4>
    3cf0:	f9009483 	str	x3, [x4, #296]
    3cf4:	f9409423 	ldr	x3, [x1, #296]
    3cf8:	b4000043 	cbz	x3, 3d00 <fwp_wake_io+0x4c>
    3cfc:	f9009064 	str	x4, [x3, #288]
    3d00:	91080023 	add	x3, x1, #0x200
    3d04:	f900943f 	str	xzr, [x1, #296]
    3d08:	3c918060 	stur	q0, [x3, #-232]
    3d0c:	f9400001 	ldr	x1, [x0]
    3d10:	f9402843 	ldr	x3, [x2, #80]
    3d14:	f2001c7f 	tst	x3, #0xff000000ff
    3d18:	54fffde1 	b.ne	3cd4 <fwp_wake_io+0x20>  // b.any
    3d1c:	39015047 	strb	w7, [x2, #84]
    3d20:	f900805f 	str	xzr, [x2, #256]
    3d24:	b40001e6 	cbz	x6, 3d60 <fwp_wake_io+0xac>
    3d28:	f90080c2 	str	x2, [x6, #256]
    3d2c:	aa0203e6 	mov	x6, x2
    3d30:	52800028 	mov	w8, #0x1                   	// #1
    3d34:	aa0103e2 	mov	x2, x1
    3d38:	b5fffd21 	cbnz	x1, 3cdc <fwp_wake_io+0x28>
    3d3c:	3400006a 	cbz	w10, 3d48 <fwp_wake_io+0x94>
    3d40:	9100c120 	add	x0, x9, #0x30
    3d44:	f900180b 	str	x11, [x0, #48]
    3d48:	34000068 	cbz	w8, 3d54 <fwp_wake_io+0xa0>
    3d4c:	9100c129 	add	x9, x9, #0x30
    3d50:	f9001526 	str	x6, [x9, #40]
    3d54:	d65f03c0 	ret
    3d58:	f90000a3 	str	x3, [x5]
    3d5c:	17ffffe7 	b	3cf8 <fwp_wake_io+0x44>
    3d60:	aa0203eb 	mov	x11, x2
    3d64:	5280002a 	mov	w10, #0x1                   	// #1
    3d68:	17fffff1 	b	3d2c <fwp_wake_io+0x78>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_tape_buffers_release>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	910003fd 	mov	x29, sp
    3d78:	a90153f3 	stp	x19, x20, [sp, #16]
    3d7c:	aa0003f3 	mov	x19, x0
    3d80:	f9401400 	ldr	x0, [x0, #40]
    3d84:	b7f80760 	tbnz	x0, #63, 3e70 <fwp_tape_buffers_release+0x100>
    3d88:	f9401a61 	ldr	x1, [x19, #48]
    3d8c:	b7f80301 	tbnz	x1, #63, 3dec <fwp_tape_buffers_release+0x7c>
    3d90:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d94:	eb02001f 	cmp	x0, x2
    3d98:	540002a8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d9c:	8b000400 	add	x0, x0, x0, lsl #1
    3da0:	d2a00102 	mov	x2, #0x80000               	// #524288
    3da4:	d37df000 	lsl	x0, x0, #3
    3da8:	cb000042 	sub	x2, x2, x0
    3dac:	eb420c3f 	cmp	x1, x2, lsr #3
    3db0:	540001e8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3db4:	8b010c14 	add	x20, x0, x1, lsl #3
    3db8:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3dbc:	91086000 	add	x0, x0, #0x218
    3dc0:	97fffb14 	bl	2a10 <getenv@plt>
    3dc4:	b4000240 	cbz	x0, 3e0c <fwp_tape_buffers_release+0x9c>
    3dc8:	39400001 	ldrb	w1, [x0]
    3dcc:	7100c03f 	cmp	w1, #0x30
    3dd0:	540001e1 	b.ne	3e0c <fwp_tape_buffers_release+0x9c>  // b.any
    3dd4:	39400400 	ldrb	w0, [x0, #1]
    3dd8:	350001a0 	cbnz	w0, 3e0c <fwp_tape_buffers_release+0x9c>
    3ddc:	aa1303e0 	mov	x0, x19
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de8:	17fffd46 	b	3300 <fwp_tape_buffers_dispose>
    3dec:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3df0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df4:	91086000 	add	x0, x0, #0x218
    3df8:	97fffb06 	bl	2a10 <getenv@plt>
    3dfc:	b4ffff00 	cbz	x0, 3ddc <fwp_tape_buffers_release+0x6c>
    3e00:	39400001 	ldrb	w1, [x0]
    3e04:	7100c03f 	cmp	w1, #0x30
    3e08:	54fffe60 	b.eq	3dd4 <fwp_tape_buffers_release+0x64>  // b.none
    3e0c:	d1000681 	sub	x1, x20, #0x1
    3e10:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3e14:	eb00003f 	cmp	x1, x0
    3e18:	54fffe28 	b.hi	3ddc <fwp_tape_buffers_release+0x6c>  // b.pmore
    3e1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e20:	b00000f6 	adrp	x22, 20000 <__data_start>
    3e24:	9100c2d6 	add	x22, x22, #0x30
    3e28:	9100e2d5 	add	x21, x22, #0x38
    3e2c:	aa1503e0 	mov	x0, x21
    3e30:	97fffd34 	bl	3300 <fwp_tape_buffers_dispose>
    3e34:	ad400a61 	ldp	q1, q2, [x19]
    3e38:	f9003ad4 	str	x20, [x22, #112]
    3e3c:	4f000400 	movi	v0.4s, #0x0
    3e40:	ad000aa1 	stp	q1, q2, [x21]
    3e44:	3dc00a61 	ldr	q1, [x19, #32]
    3e48:	3d800aa1 	str	q1, [x21, #32]
    3e4c:	f9401a60 	ldr	x0, [x19, #48]
    3e50:	f9001aa0 	str	x0, [x21, #48]
    3e54:	f9001a7f 	str	xzr, [x19, #48]
    3e58:	ad000260 	stp	q0, q0, [x19]
    3e5c:	3d800a60 	str	q0, [x19, #32]
    3e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e6c:	d65f03c0 	ret
    3e70:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3e74:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3e78:	91086000 	add	x0, x0, #0x218
    3e7c:	97fffae5 	bl	2a10 <getenv@plt>
    3e80:	b5fffa40 	cbnz	x0, 3dc8 <fwp_tape_buffers_release+0x58>
    3e84:	17ffffd6 	b	3ddc <fwp_tape_buffers_release+0x6c>
    3e88:	d503201f 	nop
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_trap>:
    3e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e94:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e98:	d53bd041 	mrs	x1, tpidr_el0
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	f9401c42 	ldr	x2, [x2, #56]
    3ea4:	91400021 	add	x1, x1, #0x0, lsl #12
    3ea8:	91004021 	add	x1, x1, #0x10
    3eac:	a90153f3 	stp	x19, x20, [sp, #16]
    3eb0:	aa0003f3 	mov	x19, x0
    3eb4:	f9400034 	ldr	x20, [x1]
    3eb8:	b4000062 	cbz	x2, 3ec4 <fwp_trap+0x34>
    3ebc:	aa0203e0 	mov	x0, x2
    3ec0:	97fffabc 	bl	29b0 <fflush@plt>
    3ec4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ec8:	f947ec00 	ldr	x0, [x0, #4056]
    3ecc:	f9400000 	ldr	x0, [x0]
    3ed0:	97fffab8 	bl	29b0 <fflush@plt>
    3ed4:	aa1303e3 	mov	x3, x19
    3ed8:	d0000042 	adrp	x2, d000 <__modti3+0x2a0>
    3edc:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    3ee0:	f947ea73 	ldr	x19, [x19, #4048]
    3ee4:	9108c042 	add	x2, x2, #0x230
    3ee8:	52800041 	mov	w1, #0x2                   	// #2
    3eec:	f9400260 	ldr	x0, [x19]
    3ef0:	97fffa80 	bl	28f0 <__fprintf_chk@plt>
    3ef4:	b40000b4 	cbz	x20, 3f08 <fwp_trap+0x78>
    3ef8:	f9400260 	ldr	x0, [x19]
    3efc:	97fffaad 	bl	29b0 <fflush@plt>
    3f00:	52800ca0 	mov	w0, #0x65                  	// #101
    3f04:	97fffabb 	bl	29f0 <_Exit@plt>
    3f08:	52800ca0 	mov	w0, #0x65                  	// #101
    3f0c:	97fffa09 	bl	2730 <exit@plt>

0000000000003f10 <fwp_rc_forget_slot.part.0>:
    3f10:	ca404401 	eor	x1, x0, x0, lsr #17
    3f14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3f18:	ca412421 	eor	x1, x1, x1, lsr #9
    3f1c:	910003fd 	mov	x29, sp
    3f20:	92401c21 	and	x1, x1, #0xff
    3f24:	f9000bf3 	str	x19, [sp, #16]
    3f28:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3f2c:	91150262 	add	x2, x19, #0x540
    3f30:	910a2423 	add	x3, x1, #0x289
    3f34:	8b010c41 	add	x1, x2, x1, lsl #3
    3f38:	8b030c43 	add	x3, x2, x3, lsl #3
    3f3c:	f94a2421 	ldr	x1, [x1, #5192]
    3f40:	b50000a1 	cbnz	x1, 3f54 <fwp_rc_forget_slot.part.0+0x44>
    3f44:	14000012 	b	3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f48:	91004023 	add	x3, x1, #0x10
    3f4c:	f9400821 	ldr	x1, [x1, #16]
    3f50:	b40001e1 	cbz	x1, 3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f54:	f9400022 	ldr	x2, [x1]
    3f58:	eb02001f 	cmp	x0, x2
    3f5c:	54ffff61 	b.ne	3f48 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3f60:	f9400060 	ldr	x0, [x3]
    3f64:	91150273 	add	x19, x19, #0x540
    3f68:	f9400801 	ldr	x1, [x0, #16]
    3f6c:	f9000061 	str	x1, [x3]
    3f70:	97fffa74 	bl	2940 <free@plt>
    3f74:	f94e2660 	ldr	x0, [x19, #7240]
    3f78:	d1000400 	sub	x0, x0, #0x1
    3f7c:	f90e2660 	str	x0, [x19, #7240]
    3f80:	f9400bf3 	ldr	x19, [sp, #16]
    3f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f88:	d65f03c0 	ret
    3f8c:	d0000040 	adrp	x0, d000 <__modti3+0x2a0>
    3f90:	91090000 	add	x0, x0, #0x240
    3f94:	97ffffbf 	bl	3e90 <fwp_trap>
    3f98:	d503201f 	nop
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_rc_prepare_chunk>:
    3fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3fa4:	910003fd 	mov	x29, sp
    3fa8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fac:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    3fb0:	911502c2 	add	x2, x22, #0x540
    3fb4:	b9401c03 	ldr	w3, [x0, #28]
    3fb8:	aa0103f5 	mov	x21, x1
    3fbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fc0:	aa0003f4 	mov	x20, x0
    3fc4:	f94e2440 	ldr	x0, [x2, #7240]
    3fc8:	b4000440 	cbz	x0, 4050 <fwp_rc_prepare_chunk+0xb0>
    3fcc:	d2800013 	mov	x19, #0x0                   	// #0
    3fd0:	35000203 	cbnz	w3, 4010 <fwp_rc_prepare_chunk+0x70>
    3fd4:	b4000361 	cbz	x1, 4040 <fwp_rc_prepare_chunk+0xa0>
    3fd8:	f9401280 	ldr	x0, [x20, #32]
    3fdc:	97fffa59 	bl	2940 <free@plt>
    3fe0:	aa1503e0 	mov	x0, x21
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	97fffa1e 	bl	2860 <calloc@plt>
    3fec:	f9001280 	str	x0, [x20, #32]
    3ff0:	b5000460 	cbnz	x0, 407c <fwp_rc_prepare_chunk+0xdc>
    3ff4:	97fffc0f 	bl	3030 <fwp_heap_oom>
    3ff8:	97ffffc6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    3ffc:	91000673 	add	x19, x19, #0x1
    4000:	b9401e83 	ldr	w3, [x20, #28]
    4004:	eb13007f 	cmp	x3, x19
    4008:	54000169 	b.ls	4034 <fwp_rc_prepare_chunk+0x94>  // b.plast
    400c:	d503201f 	nop
    4010:	f9401283 	ldr	x3, [x20, #32]
    4014:	8b130060 	add	x0, x3, x19
    4018:	38736863 	ldrb	w3, [x3, x19]
    401c:	7103fc7f 	cmp	w3, #0xff
    4020:	54fffec0 	b.eq	3ff8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4024:	b9401e83 	ldr	w3, [x20, #28]
    4028:	91000673 	add	x19, x19, #0x1
    402c:	eb13007f 	cmp	x3, x19
    4030:	54ffff08 	b.hi	4010 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4034:	eb0302bf 	cmp	x21, x3
    4038:	54000121 	b.ne	405c <fwp_rc_prepare_chunk+0xbc>  // b.any
    403c:	b5000335 	cbnz	x21, 40a0 <fwp_rc_prepare_chunk+0x100>
    4040:	a94153f3 	ldp	x19, x20, [sp, #16]
    4044:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    404c:	d65f03c0 	ret
    4050:	2a0303e3 	mov	w3, w3
    4054:	eb0302bf 	cmp	x21, x3
    4058:	54ffff20 	b.eq	403c <fwp_rc_prepare_chunk+0x9c>  // b.none
    405c:	911502c2 	add	x2, x22, #0x540
    4060:	f9401280 	ldr	x0, [x20, #32]
    4064:	f94e2841 	ldr	x1, [x2, #7248]
    4068:	cb030021 	sub	x1, x1, x3
    406c:	f90e2841 	str	x1, [x2, #7248]
    4070:	97fffa34 	bl	2940 <free@plt>
    4074:	b5fffb75 	cbnz	x21, 3fe0 <fwp_rc_prepare_chunk+0x40>
    4078:	f900129f 	str	xzr, [x20, #32]
    407c:	911502d6 	add	x22, x22, #0x540
    4080:	f94e2ac0 	ldr	x0, [x22, #7248]
    4084:	b9001e95 	str	w21, [x20, #28]
    4088:	a94153f3 	ldp	x19, x20, [sp, #16]
    408c:	8b150000 	add	x0, x0, x21
    4090:	f90e2ac0 	str	x0, [x22, #7248]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    409c:	d65f03c0 	ret
    40a0:	f9401280 	ldr	x0, [x20, #32]
    40a4:	aa1503e2 	mov	x2, x21
    40a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    40ac:	52800001 	mov	w1, #0x0                   	// #0
    40b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40b8:	17fff9e6 	b	2850 <memset@plt>
    40bc:	d503201f 	nop

00000000000040c0 <fwp_heap_refill>:
    40c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    40c4:	910003fd 	mov	x29, sp
    40c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    40cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    40d0:	911502b5 	add	x21, x21, #0x540
    40d4:	aa0003f6 	mov	x22, x0
    40d8:	d2800020 	mov	x0, #0x1                   	// #1
    40dc:	a90153f3 	stp	x19, x20, [sp, #16]
    40e0:	a90363f7 	stp	x23, x24, [sp, #48]
    40e4:	2a0103f7 	mov	w23, w1
    40e8:	2a0203f8 	mov	w24, w2
    40ec:	97fffc11 	bl	3130 <fwp_heap_chunks>
    40f0:	aa0003f3 	mov	x19, x0
    40f4:	f949fea2 	ldr	x2, [x21, #5112]
    40f8:	8b000800 	add	x0, x0, x0, lsl #2
    40fc:	2a1703e1 	mov	w1, w23
    4100:	52800025 	mov	w5, #0x1                   	// #1
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	910f0021 	add	x1, x1, #0x3c0
    410c:	8b000054 	add	x20, x2, x0
    4110:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4114:	52a00024 	mov	w4, #0x10000               	// #65536
    4118:	38206845 	strb	w5, [x2, x0]
    411c:	aa1403e0 	mov	x0, x20
    4120:	39000698 	strb	w24, [x20, #1]
    4124:	39000a97 	strb	w23, [x20, #2]
    4128:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    412c:	b9000681 	str	w1, [x20, #4]
    4130:	2a0103e5 	mov	w5, w1
    4134:	8b0300a2 	add	x2, x5, x3
    4138:	1ac10881 	udiv	w1, w4, w1
    413c:	9ac50842 	udiv	x2, x2, x5
    4140:	b9000a81 	str	w1, [x20, #8]
    4144:	92404021 	and	x1, x1, #0x1ffff
    4148:	b9001a82 	str	w2, [x20, #24]
    414c:	97ffff95 	bl	3fa0 <fwp_rc_prepare_chunk>
    4150:	f949daa0 	ldr	x0, [x21, #5040]
    4154:	29408a81 	ldp	w1, w2, [x20, #4]
    4158:	8b134000 	add	x0, x0, x19, lsl #16
    415c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4160:	8b214003 	add	x3, x0, w1, uxtw
    4164:	9ba20021 	umaddl	x1, w1, w2, x0
    4168:	a94363f7 	ldp	x23, x24, [sp, #48]
    416c:	a90086c3 	stp	x3, x1, [x22, #8]
    4170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4174:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4178:	d65f03c0 	ret
    417c:	d503201f 	nop

0000000000004180 <fwp_mem_free>:
    4180:	b40003c0 	cbz	x0, 41f8 <fwp_mem_free+0x78>
    4184:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4188:	910003fd 	mov	x29, sp
    418c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4190:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4194:	911502a1 	add	x1, x21, #0x540
    4198:	a90153f3 	stp	x19, x20, [sp, #16]
    419c:	aa0003f3 	mov	x19, x0
    41a0:	f949d823 	ldr	x3, [x1, #5040]
    41a4:	f949ec22 	ldr	x2, [x1, #5080]
    41a8:	cb030000 	sub	x0, x0, x3
    41ac:	eb02401f 	cmp	x0, x2, lsl #16
    41b0:	540001c2 	b.cs	41e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    41b4:	d350fc16 	lsr	x22, x0, #16
    41b8:	a90363f7 	stp	x23, x24, [sp, #48]
    41bc:	f949fc22 	ldr	x2, [x1, #5112]
    41c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    41c4:	d37df294 	lsl	x20, x20, #3
    41c8:	ab140057 	adds	x23, x2, x20
    41cc:	540000c0 	b.eq	41e4 <fwp_mem_free+0x64>  // b.none
    41d0:	38746842 	ldrb	w2, [x2, x20]
    41d4:	7100045f 	cmp	w2, #0x1
    41d8:	54000120 	b.eq	41fc <fwp_mem_free+0x7c>  // b.none
    41dc:	7100085f 	cmp	w2, #0x2
    41e0:	540005e0 	b.eq	429c <fwp_mem_free+0x11c>  // b.none
    41e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    41f4:	d65f03c0 	ret
    41f8:	d65f03c0 	ret
    41fc:	f94012f8 	ldr	x24, [x23, #32]
    4200:	b94006e1 	ldr	w1, [x23, #4]
    4204:	f90023f9 	str	x25, [sp, #64]
    4208:	2a0103e2 	mov	w2, w1
    420c:	394006f9 	ldrb	w25, [x23, #1]
    4210:	39400af4 	ldrb	w20, [x23, #2]
    4214:	b4000158 	cbz	x24, 423c <fwp_mem_free+0xbc>
    4218:	92403e76 	and	x22, x19, #0xffff
    421c:	9ac20ad6 	udiv	x22, x22, x2
    4220:	38766b01 	ldrb	w1, [x24, x22]
    4224:	8b160300 	add	x0, x24, x22
    4228:	7103fc3f 	cmp	w1, #0xff
    422c:	54000980 	b.eq	435c <fwp_mem_free+0x1dc>  // b.none
    4230:	38366b1f 	strb	wzr, [x24, x22]
    4234:	b94006e1 	ldr	w1, [x23, #4]
    4238:	2a0103e2 	mov	w2, w1
    423c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4240:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4244:	cb390000 	sub	x0, x0, w25, uxtb
    4248:	8b340074 	add	x20, x3, w20, uxtb
    424c:	911502b5 	add	x21, x21, #0x540
    4250:	1e630021 	ucvtf	d1, w1
    4254:	d37ae400 	lsl	x0, x0, #6
    4258:	8b140c14 	add	x20, x0, x20, lsl #3
    425c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4260:	f8746aa0 	ldr	x0, [x21, x20]
    4264:	f94023f9 	ldr	x25, [sp, #64]
    4268:	aa2003e0 	mvn	x0, x0
    426c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4270:	f9000260 	str	x0, [x19]
    4274:	f8346ab3 	str	x19, [x21, x20]
    4278:	f94a12a0 	ldr	x0, [x21, #5152]
    427c:	1e612800 	fadd	d0, d0, d1
    4280:	a94153f3 	ldp	x19, x20, [sp, #16]
    4284:	cb020000 	sub	x0, x0, x2
    4288:	f90a12a0 	str	x0, [x21, #5152]
    428c:	fd0a22a0 	str	d0, [x21, #5184]
    4290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4294:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4298:	d65f03c0 	ret
    429c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    42a0:	8b000063 	add	x3, x3, x0
    42a4:	eb03027f 	cmp	x19, x3
    42a8:	54fff9e1 	b.ne	41e4 <fwp_mem_free+0x64>  // b.any
    42ac:	fd400ae1 	ldr	d1, [x23, #16]
    42b0:	fd4a2020 	ldr	d0, [x1, #5184]
    42b4:	f9400ae0 	ldr	x0, [x23, #16]
    42b8:	7e61d821 	ucvtf	d1, d1
    42bc:	f94a1022 	ldr	x2, [x1, #5152]
    42c0:	f94012f3 	ldr	x19, [x23, #32]
    42c4:	1e612800 	fadd	d0, d0, d1
    42c8:	cb000042 	sub	x2, x2, x0
    42cc:	f90a1022 	str	x2, [x1, #5152]
    42d0:	fd0a2020 	str	d0, [x1, #5184]
    42d4:	b40000b3 	cbz	x19, 42e8 <fwp_mem_free+0x168>
    42d8:	39400260 	ldrb	w0, [x19]
    42dc:	7103fc1f 	cmp	w0, #0xff
    42e0:	54000380 	b.eq	4350 <fwp_mem_free+0x1d0>  // b.none
    42e4:	3900027f 	strb	wzr, [x19]
    42e8:	b9400ee2 	ldr	w2, [x23, #12]
    42ec:	b4000142 	cbz	x2, 4314 <fwp_mem_free+0x194>
    42f0:	911502a1 	add	x1, x21, #0x540
    42f4:	8b160040 	add	x0, x2, x22
    42f8:	8b000800 	add	x0, x0, x0, lsl #2
    42fc:	f949fc21 	ldr	x1, [x1, #5112]
    4300:	8b140034 	add	x20, x1, x20
    4304:	8b000c20 	add	x0, x1, x0, lsl #3
    4308:	3802869f 	strb	wzr, [x20], #40
    430c:	eb00029f 	cmp	x20, x0
    4310:	54ffffc1 	b.ne	4308 <fwp_mem_free+0x188>  // b.any
    4314:	911502a0 	add	x0, x21, #0x540
    4318:	f94a1801 	ldr	x1, [x0, #5168]
    431c:	f949f803 	ldr	x3, [x0, #5104]
    4320:	8b020021 	add	x1, x1, x2
    4324:	f90a1801 	str	x1, [x0, #5168]
    4328:	eb16007f 	cmp	x3, x22
    432c:	54000049 	b.ls	4334 <fwp_mem_free+0x1b4>  // b.plast
    4330:	f909f816 	str	x22, [x0, #5104]
    4334:	911502b5 	add	x21, x21, #0x540
    4338:	f949f6a0 	ldr	x0, [x21, #5096]
    433c:	eb16001f 	cmp	x0, x22
    4340:	54fff529 	b.ls	41e4 <fwp_mem_free+0x64>  // b.plast
    4344:	a94363f7 	ldp	x23, x24, [sp, #48]
    4348:	f909f6b6 	str	x22, [x21, #5096]
    434c:	17ffffa7 	b	41e8 <fwp_mem_free+0x68>
    4350:	aa1303e0 	mov	x0, x19
    4354:	97fffeef 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4358:	17ffffe3 	b	42e4 <fwp_mem_free+0x164>
    435c:	97fffeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4360:	17ffffb4 	b	4230 <fwp_mem_free+0xb0>

0000000000004364 <fwp_rc_wide_dup>:
    4364:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4368:	910003fd 	mov	x29, sp
    436c:	a90153f3 	stp	x19, x20, [sp, #16]
    4370:	aa0003f3 	mov	x19, x0
    4374:	ca404400 	eor	x0, x0, x0, lsr #17
    4378:	f90013f5 	str	x21, [sp, #32]
    437c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4380:	ca402400 	eor	x0, x0, x0, lsr #9
    4384:	911502a2 	add	x2, x21, #0x540
    4388:	92401c00 	and	x0, x0, #0xff
    438c:	910a2403 	add	x3, x0, #0x289
    4390:	8b000c40 	add	x0, x2, x0, lsl #3
    4394:	8b030c54 	add	x20, x2, x3, lsl #3
    4398:	f94a2401 	ldr	x1, [x0, #5192]
    439c:	b50000a1 	cbnz	x1, 43b0 <fwp_rc_wide_dup+0x4c>
    43a0:	14000033 	b	446c <fwp_rc_wide_dup+0x108>
    43a4:	91004034 	add	x20, x1, #0x10
    43a8:	f9400821 	ldr	x1, [x1, #16]
    43ac:	b4000241 	cbz	x1, 43f4 <fwp_rc_wide_dup+0x90>
    43b0:	f9400022 	ldr	x2, [x1]
    43b4:	eb02027f 	cmp	x19, x2
    43b8:	54ffff61 	b.ne	43a4 <fwp_rc_wide_dup+0x40>  // b.any
    43bc:	f9400281 	ldr	x1, [x20]
    43c0:	39400260 	ldrb	w0, [x19]
    43c4:	7103f81f 	cmp	w0, #0xfe
    43c8:	54000220 	b.eq	440c <fwp_rc_wide_dup+0xa8>  // b.none
    43cc:	b40001a1 	cbz	x1, 4400 <fwp_rc_wide_dup+0x9c>
    43d0:	f9400420 	ldr	x0, [x1, #8]
    43d4:	b100041f 	cmn	x0, #0x1
    43d8:	54000440 	b.eq	4460 <fwp_rc_wide_dup+0xfc>  // b.none
    43dc:	91000400 	add	x0, x0, #0x1
    43e0:	f9000420 	str	x0, [x1, #8]
    43e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e8:	f94013f5 	ldr	x21, [sp, #32]
    43ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f0:	d65f03c0 	ret
    43f4:	39400260 	ldrb	w0, [x19]
    43f8:	7103f81f 	cmp	w0, #0xfe
    43fc:	54000100 	b.eq	441c <fwp_rc_wide_dup+0xb8>  // b.none
    4400:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4404:	91090000 	add	x0, x0, #0x240
    4408:	97fffea2 	bl	3e90 <fwp_trap>
    440c:	b4000081 	cbz	x1, 441c <fwp_rc_wide_dup+0xb8>
    4410:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4414:	9109a000 	add	x0, x0, #0x268
    4418:	97fffe9e 	bl	3e90 <fwp_trap>
    441c:	d2800300 	mov	x0, #0x18                  	// #24
    4420:	97fff900 	bl	2820 <malloc@plt>
    4424:	b4000280 	cbz	x0, 4474 <fwp_rc_wide_dup+0x110>
    4428:	d2801fe1 	mov	x1, #0xff                  	// #255
    442c:	a9000413 	stp	x19, x1, [x0]
    4430:	911502b5 	add	x21, x21, #0x540
    4434:	f900081f 	str	xzr, [x0, #16]
    4438:	12800001 	mov	w1, #0xffffffff            	// #-1
    443c:	f9000280 	str	x0, [x20]
    4440:	39000261 	strb	w1, [x19]
    4444:	f94e26a0 	ldr	x0, [x21, #7240]
    4448:	a94153f3 	ldp	x19, x20, [sp, #16]
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f90e26a0 	str	x0, [x21, #7240]
    4454:	f94013f5 	ldr	x21, [sp, #32]
    4458:	a8c37bfd 	ldp	x29, x30, [sp], #48
    445c:	d65f03c0 	ret
    4460:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4464:	910a4000 	add	x0, x0, #0x290
    4468:	97fffe8a 	bl	3e90 <fwp_trap>
    446c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4470:	17ffffd4 	b	43c0 <fwp_rc_wide_dup+0x5c>
    4474:	97fffaef 	bl	3030 <fwp_heap_oom>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_closure_drop_push>:
    4480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4484:	910003fd 	mov	x29, sp
    4488:	a90153f3 	stp	x19, x20, [sp, #16]
    448c:	aa0003f3 	mov	x19, x0
    4490:	a9408014 	ldp	x20, x0, [x0, #8]
    4494:	a9025bf5 	stp	x21, x22, [sp, #32]
    4498:	aa0103f5 	mov	x21, x1
    449c:	a90363f7 	stp	x23, x24, [sp, #48]
    44a0:	eb00029f 	cmp	x20, x0
    44a4:	54000160 	b.eq	44d0 <fwp_closure_drop_push+0x50>  // b.none
    44a8:	f9400276 	ldr	x22, [x19]
    44ac:	d37df297 	lsl	x23, x20, #3
    44b0:	91000694 	add	x20, x20, #0x1
    44b4:	f9000674 	str	x20, [x19, #8]
    44b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44bc:	f8376ad5 	str	x21, [x22, x23]
    44c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44cc:	d65f03c0 	ret
    44d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    44d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    44d8:	eb00029f 	cmp	x20, x0
    44dc:	540003e8 	b.hi	4558 <fwp_closure_drop_push+0xd8>  // b.pmore
    44e0:	d37cee99 	lsl	x25, x20, #4
    44e4:	d37ffa9a 	lsl	x26, x20, #1
    44e8:	aa1903e0 	mov	x0, x25
    44ec:	97fff8cd 	bl	2820 <malloc@plt>
    44f0:	aa0003f6 	mov	x22, x0
    44f4:	b4000380 	cbz	x0, 4564 <fwp_closure_drop_push+0xe4>
    44f8:	aa1303f8 	mov	x24, x19
    44fc:	aa1903e3 	mov	x3, x25
    4500:	d37df297 	lsl	x23, x20, #3
    4504:	aa1703e2 	mov	x2, x23
    4508:	f8418719 	ldr	x25, [x24], #24
    450c:	aa1903e1 	mov	x1, x25
    4510:	97fff8b0 	bl	27d0 <__memcpy_chk@plt>
    4514:	eb18033f 	cmp	x25, x24
    4518:	540000a0 	b.eq	452c <fwp_closure_drop_push+0xac>  // b.none
    451c:	aa1903e0 	mov	x0, x25
    4520:	97fff908 	bl	2940 <free@plt>
    4524:	f9400674 	ldr	x20, [x19, #8]
    4528:	d37df297 	lsl	x23, x20, #3
    452c:	91000694 	add	x20, x20, #0x1
    4530:	f9000276 	str	x22, [x19]
    4534:	f9000a7a 	str	x26, [x19, #16]
    4538:	a9446bf9 	ldp	x25, x26, [sp, #64]
    453c:	f9000674 	str	x20, [x19, #8]
    4540:	f8376ad5 	str	x21, [x22, x23]
    4544:	a94153f3 	ldp	x19, x20, [sp, #16]
    4548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    454c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4550:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4554:	d65f03c0 	ret
    4558:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    455c:	910ac000 	add	x0, x0, #0x2b0
    4560:	97fffe4c 	bl	3e90 <fwp_trap>
    4564:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4568:	f947e863 	ldr	x3, [x3, #4048]
    456c:	d2800262 	mov	x2, #0x13                  	// #19
    4570:	d2800021 	mov	x1, #0x1                   	// #1
    4574:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4578:	91042000 	add	x0, x0, #0x108
    457c:	f9400063 	ldr	x3, [x3]
    4580:	97fff900 	bl	2980 <fwrite@plt>
    4584:	d2800000 	mov	x0, #0x0                   	// #0
    4588:	97fff90a 	bl	29b0 <fflush@plt>
    458c:	52800cc0 	mov	w0, #0x66                  	// #102
    4590:	97fff918 	bl	29f0 <_Exit@plt>

0000000000004594 <fwp_closure_drop.part.0>:
    4594:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4598:	b0000041 	adrp	x1, d000 <__modti3+0x2a0>
    459c:	910003fd 	mov	x29, sp
    45a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    45a4:	f947f463 	ldr	x3, [x3, #4072]
    45a8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ac:	d10883ff 	sub	sp, sp, #0x220
    45b0:	910003e2 	mov	x2, sp
    45b4:	d53bd053 	mrs	x19, tpidr_el0
    45b8:	910063f4 	add	x20, sp, #0x18
    45bc:	3dc37420 	ldr	q0, [x1, #3536]
    45c0:	91400264 	add	x4, x19, #0x0, lsl #12
    45c4:	91004084 	add	x4, x4, #0x10
    45c8:	aa0003e1 	mov	x1, x0
    45cc:	aa0203e0 	mov	x0, x2
    45d0:	f9400062 	ldr	x2, [x3]
    45d4:	f9010fe2 	str	x2, [sp, #536]
    45d8:	d2800002 	mov	x2, #0x0                   	// #0
    45dc:	f90003f4 	str	x20, [sp]
    45e0:	f9000080 	str	x0, [x4]
    45e4:	3c8083e0 	stur	q0, [sp, #8]
    45e8:	97ffffa6 	bl	4480 <fwp_closure_drop_push>
    45ec:	f94007e0 	ldr	x0, [sp, #8]
    45f0:	b40002e0 	cbz	x0, 464c <fwp_closure_drop.part.0+0xb8>
    45f4:	f90123f5 	str	x21, [sp, #576]
    45f8:	900000f5 	adrp	x21, 20000 <__data_start>
    45fc:	9100c2b5 	add	x21, x21, #0x30
    4600:	14000006 	b	4618 <fwp_closure_drop.part.0+0x84>
    4604:	f9400422 	ldr	x2, [x1, #8]
    4608:	52800001 	mov	w1, #0x0                   	// #0
    460c:	d63f0040 	blr	x2
    4610:	f94007e0 	ldr	x0, [sp, #8]
    4614:	b40001a0 	cbz	x0, 4648 <fwp_closure_drop.part.0+0xb4>
    4618:	f94003e1 	ldr	x1, [sp]
    461c:	d1000400 	sub	x0, x0, #0x1
    4620:	f90007e0 	str	x0, [sp, #8]
    4624:	f9403ea2 	ldr	x2, [x21, #120]
    4628:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    462c:	b9400001 	ldr	w1, [x0]
    4630:	8b011441 	add	x1, x2, x1, lsl #5
    4634:	f9400c21 	ldr	x1, [x1, #24]
    4638:	b5fffe61 	cbnz	x1, 4604 <fwp_closure_drop.part.0+0x70>
    463c:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4640:	910b4000 	add	x0, x0, #0x2d0
    4644:	97fffe13 	bl	3e90 <fwp_trap>
    4648:	f94123f5 	ldr	x21, [sp, #576]
    464c:	91400273 	add	x19, x19, #0x0, lsl #12
    4650:	91004273 	add	x19, x19, #0x10
    4654:	f94003e0 	ldr	x0, [sp]
    4658:	f900027f 	str	xzr, [x19]
    465c:	eb14001f 	cmp	x0, x20
    4660:	54000040 	b.eq	4668 <fwp_closure_drop.part.0+0xd4>  // b.none
    4664:	97fff8b7 	bl	2940 <free@plt>
    4668:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    466c:	f947f400 	ldr	x0, [x0, #4072]
    4670:	f9410fe2 	ldr	x2, [sp, #536]
    4674:	f9400001 	ldr	x1, [x0]
    4678:	eb010042 	subs	x2, x2, x1
    467c:	d2800001 	mov	x1, #0x0                   	// #0
    4680:	540000a1 	b.ne	4694 <fwp_closure_drop.part.0+0x100>  // b.any
    4684:	910883ff 	add	sp, sp, #0x220
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4690:	d65f03c0 	ret
    4694:	f90123f5 	str	x21, [sp, #576]
    4698:	97fff87a 	bl	2880 <__stack_chk_fail@plt>
    469c:	d503201f 	nop

00000000000046a0 <fwp_tape_of>:
    46a0:	aa0003e1 	mov	x1, x0
    46a4:	92403c00 	and	x0, x0, #0xffff
    46a8:	b40000e0 	cbz	x0, 46c4 <fwp_tape_of+0x24>
    46ac:	d1000402 	sub	x2, x0, #0x1
    46b0:	900000e3 	adrp	x3, 20000 <__data_start>
    46b4:	9100c060 	add	x0, x3, #0x30
    46b8:	f9404000 	ldr	x0, [x0, #128]
    46bc:	eb02001f 	cmp	x0, x2
    46c0:	540000cc 	b.gt	46d8 <fwp_tape_of+0x38>
    46c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    46c8:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    46cc:	910c0000 	add	x0, x0, #0x300
    46d0:	910003fd 	mov	x29, sp
    46d4:	97fffdef 	bl	3e90 <fwp_trap>
    46d8:	8b020440 	add	x0, x2, x2, lsl #1
    46dc:	f9401863 	ldr	x3, [x3, #48]
    46e0:	8b000842 	add	x2, x2, x0, lsl #2
    46e4:	d37df042 	lsl	x2, x2, #3
    46e8:	8b020060 	add	x0, x3, x2
    46ec:	b9400404 	ldr	w4, [x0, #4]
    46f0:	34fffea4 	cbz	w4, 46c4 <fwp_tape_of+0x24>
    46f4:	b8626862 	ldr	w2, [x3, x2]
    46f8:	9350fc21 	asr	x1, x1, #16
    46fc:	6b01005f 	cmp	w2, w1
    4700:	54fffe21 	b.ne	46c4 <fwp_tape_of+0x24>  // b.any
    4704:	d65f03c0 	ret
    4708:	d503201f 	nop
    470c:	d503201f 	nop

0000000000004710 <fwp_now_ns>:
    4710:	d100c3ff 	sub	sp, sp, #0x30
    4714:	52800020 	mov	w0, #0x1                   	// #1
    4718:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    471c:	f947f442 	ldr	x2, [x2, #4072]
    4720:	910023e1 	add	x1, sp, #0x8
    4724:	a9027bfd 	stp	x29, x30, [sp, #32]
    4728:	910083fd 	add	x29, sp, #0x20
    472c:	f9400043 	ldr	x3, [x2]
    4730:	f9000fe3 	str	x3, [sp, #24]
    4734:	d2800003 	mov	x3, #0x0                   	// #0
    4738:	97fff81e 	bl	27b0 <clock_gettime@plt>
    473c:	350002c0 	cbnz	w0, 4794 <fwp_now_ns+0x84>
    4740:	a9408be1 	ldp	x1, x2, [sp, #8]
    4744:	d2994003 	mov	x3, #0xca00                	// #51712
    4748:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    474c:	9b037c20 	mul	x0, x1, x3
    4750:	9b437c21 	smulh	x1, x1, x3
    4754:	ab020000 	adds	x0, x0, x2
    4758:	937ffc42 	asr	x2, x2, #63
    475c:	9a020021 	adc	x1, x1, x2
    4760:	f100001f 	cmp	x0, #0x0
    4764:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4768:	b50001c1 	cbnz	x1, 47a0 <fwp_now_ns+0x90>
    476c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4770:	f947f421 	ldr	x1, [x1, #4072]
    4774:	f9400fe3 	ldr	x3, [sp, #24]
    4778:	f9400022 	ldr	x2, [x1]
    477c:	eb020063 	subs	x3, x3, x2
    4780:	d2800002 	mov	x2, #0x0                   	// #0
    4784:	54000141 	b.ne	47ac <fwp_now_ns+0x9c>  // b.any
    4788:	a9427bfd 	ldp	x29, x30, [sp, #32]
    478c:	9100c3ff 	add	sp, sp, #0x30
    4790:	d65f03c0 	ret
    4794:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    4798:	910d4000 	add	x0, x0, #0x350
    479c:	97fffdbd 	bl	3e90 <fwp_trap>
    47a0:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    47a4:	910dc000 	add	x0, x0, #0x370
    47a8:	97fffdba 	bl	3e90 <fwp_trap>
    47ac:	97fff835 	bl	2880 <__stack_chk_fail@plt>

00000000000047b0 <fwp_poll_events>:
    47b0:	d10103ff 	sub	sp, sp, #0x40
    47b4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    47b8:	f947f400 	ldr	x0, [x0, #4072]
    47bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    47c0:	910083fd 	add	x29, sp, #0x20
    47c4:	f9001bf3 	str	x19, [sp, #48]
    47c8:	900000f3 	adrp	x19, 20000 <__data_start>
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	f9000fe1 	str	x1, [sp, #24]
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	97ffffce 	bl	4710 <fwp_now_ns>
    47dc:	9100c261 	add	x1, x19, #0x30
    47e0:	f9404421 	ldr	x1, [x1, #136]
    47e4:	b4000e01 	cbz	x1, 49a4 <fwp_poll_events+0x1f4>
    47e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    47ec:	14000005 	b	4800 <fwp_poll_events+0x50>
    47f0:	f9408821 	ldr	x1, [x1, #272]
    47f4:	eb03005f 	cmp	x2, x3
    47f8:	9a83d042 	csel	x2, x2, x3, le
    47fc:	b40000c1 	cbz	x1, 4814 <fwp_poll_events+0x64>
    4800:	f9403423 	ldr	x3, [x1, #104]
    4804:	b6ffff62 	tbz	x2, #63, 47f0 <fwp_poll_events+0x40>
    4808:	f9408821 	ldr	x1, [x1, #272]
    480c:	aa0303e2 	mov	x2, x3
    4810:	b5ffff81 	cbnz	x1, 4800 <fwp_poll_events+0x50>
    4814:	b7f80c82 	tbnz	x2, #63, 49a4 <fwp_poll_events+0x1f4>
    4818:	cb000042 	sub	x2, x2, x0
    481c:	f100005f 	cmp	x2, #0x0
    4820:	540003ad 	b.le	4894 <fwp_poll_events+0xe4>
    4824:	d2869b60 	mov	x0, #0x34db                	// #13531
    4828:	d2884804 	mov	x4, #0x4240                	// #16960
    482c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4830:	f2a001e4 	movk	x4, #0xf, lsl #16
    4834:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4838:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    483c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4840:	9b407c40 	smulh	x0, x2, x0
    4844:	9352fc00 	asr	x0, x0, #18
    4848:	cb82fc00 	sub	x0, x0, x2, asr #63
    484c:	9b048802 	msub	x2, x0, x4, x2
    4850:	f100005f 	cmp	x2, #0x0
    4854:	9a800400 	cinc	x0, x0, ne	// ne = any
    4858:	eb01001f 	cmp	x0, x1
    485c:	5400098c 	b.gt	498c <fwp_poll_events+0x1dc>
    4860:	340001a0 	cbz	w0, 4894 <fwp_poll_events+0xe4>
    4864:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4868:	52807d05 	mov	w5, #0x3e8                 	// #1000
    486c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4870:	9ba17c01 	umull	x1, w0, w1
    4874:	d366fc23 	lsr	x3, x1, #38
    4878:	aa0303e2 	mov	x2, x3
    487c:	1b058063 	msub	w3, w3, w5, w0
    4880:	9b247c63 	smull	x3, w3, w4
    4884:	910023e0 	add	x0, sp, #0x8
    4888:	d2800001 	mov	x1, #0x0                   	// #0
    488c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4890:	97fff830 	bl	2950 <nanosleep@plt>
    4894:	97ffff9f 	bl	4710 <fwp_now_ns>
    4898:	9100c268 	add	x8, x19, #0x30
    489c:	aa0003e7 	mov	x7, x0
    48a0:	4f000400 	movi	v0.4s, #0x0
    48a4:	52800029 	mov	w9, #0x1                   	// #1
    48a8:	f9404506 	ldr	x6, [x8, #136]
    48ac:	d503201f 	nop
    48b0:	b40003e6 	cbz	x6, 492c <fwp_poll_events+0x17c>
    48b4:	f94034c1 	ldr	x1, [x6, #104]
    48b8:	aa0603e5 	mov	x5, x6
    48bc:	f94088c6 	ldr	x6, [x6, #272]
    48c0:	eb07003f 	cmp	x1, x7
    48c4:	54ffff6c 	b.gt	48b0 <fwp_poll_events+0x100>
    48c8:	394154a0 	ldrb	w0, [x5, #85]
    48cc:	36000120 	tbz	w0, #0, 48f0 <fwp_poll_events+0x140>
    48d0:	f94084a0 	ldr	x0, [x5, #264]
    48d4:	b4000560 	cbz	x0, 4980 <fwp_poll_events+0x1d0>
    48d8:	f9008806 	str	x6, [x0, #272]
    48dc:	b4000046 	cbz	x6, 48e4 <fwp_poll_events+0x134>
    48e0:	f90084c0 	str	x0, [x6, #264]
    48e4:	910800a0 	add	x0, x5, #0x200
    48e8:	390154bf 	strb	wzr, [x5, #85]
    48ec:	3c908000 	stur	q0, [x0, #-248]
    48f0:	f94030a0 	ldr	x0, [x5, #96]
    48f4:	390158a9 	strb	w9, [x5, #86]
    48f8:	f100001f 	cmp	x0, #0x0
    48fc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4900:	540002cd 	b.le	4958 <fwp_poll_events+0x1a8>
    4904:	f94028a0 	ldr	x0, [x5, #80]
    4908:	f2001c1f 	tst	x0, #0xff000000ff
    490c:	54fffd21 	b.ne	48b0 <fwp_poll_events+0x100>  // b.any
    4910:	f9401500 	ldr	x0, [x8, #40]
    4914:	390150a9 	strb	w9, [x5, #84]
    4918:	f90080bf 	str	xzr, [x5, #256]
    491c:	b40002c0 	cbz	x0, 4974 <fwp_poll_events+0x1c4>
    4920:	f9001505 	str	x5, [x8, #40]
    4924:	f9008005 	str	x5, [x0, #256]
    4928:	b5fffc66 	cbnz	x6, 48b4 <fwp_poll_events+0x104>
    492c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4930:	f947f400 	ldr	x0, [x0, #4072]
    4934:	f9400fe2 	ldr	x2, [sp, #24]
    4938:	f9400001 	ldr	x1, [x0]
    493c:	eb010042 	subs	x2, x2, x1
    4940:	d2800001 	mov	x1, #0x0                   	// #0
    4944:	540002e1 	b.ne	49a0 <fwp_poll_events+0x1f0>  // b.any
    4948:	a9427bfd 	ldp	x29, x30, [sp, #32]
    494c:	f9401bf3 	ldr	x19, [sp, #48]
    4950:	910103ff 	add	sp, sp, #0x40
    4954:	d65f03c0 	ret
    4958:	394144a0 	ldrb	w0, [x5, #81]
    495c:	3707fd40 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4960:	394140a0 	ldrb	w0, [x5, #80]
    4964:	3707fd00 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4968:	aa0503e0 	mov	x0, x5
    496c:	97fffac1 	bl	3470 <fwp_cancel_tree.part.0>
    4970:	17ffffe5 	b	4904 <fwp_poll_events+0x154>
    4974:	f9001505 	str	x5, [x8, #40]
    4978:	f9001905 	str	x5, [x8, #48]
    497c:	17ffffeb 	b	4928 <fwp_poll_events+0x178>
    4980:	9100c261 	add	x1, x19, #0x30
    4984:	f9004426 	str	x6, [x1, #136]
    4988:	17ffffd5 	b	48dc <fwp_poll_events+0x12c>
    498c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4990:	d2989362 	mov	x2, #0xc49b                	// #50331
    4994:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4998:	f2a00402 	movk	x2, #0x20, lsl #16
    499c:	17ffffba 	b	4884 <fwp_poll_events+0xd4>
    49a0:	97fff7b8 	bl	2880 <__stack_chk_fail@plt>
    49a4:	97fff993 	bl	2ff0 <fwp_flush>
    49a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    49ac:	f947e863 	ldr	x3, [x3, #4048]
    49b0:	d2800562 	mov	x2, #0x2b                  	// #43
    49b4:	d2800021 	mov	x1, #0x1                   	// #1
    49b8:	b0000040 	adrp	x0, d000 <__modti3+0x2a0>
    49bc:	910e6000 	add	x0, x0, #0x398
    49c0:	f9400063 	ldr	x3, [x3]
    49c4:	97fff7ef 	bl	2980 <fwrite@plt>
    49c8:	52800ca0 	mov	w0, #0x65                  	// #101
    49cc:	97fff759 	bl	2730 <exit@plt>

00000000000049d0 <fwp_heap_alloc_big>:
    49d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d4:	910003fd 	mov	x29, sp
    49d8:	a90153f3 	stp	x19, x20, [sp, #16]
    49dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e0:	a90363f7 	stp	x23, x24, [sp, #48]
    49e4:	aa0003f7 	mov	x23, x0
    49e8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f0:	eb0002ff 	cmp	x23, x0
    49f4:	540008a8 	b.hi	4b08 <fwp_heap_alloc_big+0x138>  // b.pmore
    49f8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49fc:	8b0002f4 	add	x20, x23, x0
    4a00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a04:	91150359 	add	x25, x26, #0x540
    4a08:	d350fe94 	lsr	x20, x20, #16
    4a0c:	2a0103f5 	mov	w21, w1
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	97fff9c7 	bl	3130 <fwp_heap_chunks>
    4a18:	f949ff22 	ldr	x2, [x25, #5112]
    4a1c:	8b000813 	add	x19, x0, x0, lsl #2
    4a20:	aa0003f8 	mov	x24, x0
    4a24:	52800043 	mov	w3, #0x2                   	// #2
    4a28:	d37df273 	lsl	x19, x19, #3
    4a2c:	d2800021 	mov	x1, #0x1                   	// #1
    4a30:	8b130040 	add	x0, x2, x19
    4a34:	38336843 	strb	w3, [x2, x19]
    4a38:	39000415 	strb	w21, [x0, #1]
    4a3c:	b9000c14 	str	w20, [x0, #12]
    4a40:	f9000817 	str	x23, [x0, #16]
    4a44:	97fffd57 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a48:	f100069f 	cmp	x20, #0x1
    4a4c:	54000289 	b.ls	4a9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4a50:	8b180294 	add	x20, x20, x24
    4a54:	9100a273 	add	x19, x19, #0x28
    4a58:	a90573fb 	stp	x27, x28, [sp, #80]
    4a5c:	5280007b 	mov	w27, #0x3                   	// #3
    4a60:	8b140a94 	add	x20, x20, x20, lsl #2
    4a64:	2a1803fc 	mov	w28, w24
    4a68:	9adb2296 	lsl	x22, x20, x27
    4a6c:	d503201f 	nop
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffd48 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0xa0>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffbbf 	bl	3af0 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff6f 	b	49d0 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffd19 	bl	40c0 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_tape_grow.constprop.0>:
    4ea4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ea8:	d2800803 	mov	x3, #0x40                  	// #64
    4eac:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4eb0:	910003fd 	mov	x29, sp
    4eb4:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb8:	f9400c13 	ldr	x19, [x0, #24]
    4ebc:	a90363f7 	stp	x23, x24, [sp, #48]
    4ec0:	aa0003f7 	mov	x23, x0
    4ec4:	f100027f 	cmp	x19, #0x0
    4ec8:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    4ecc:	eb13003f 	cmp	x1, x19
    4ed0:	540000ed 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ed4:	eb02027f 	cmp	x19, x2
    4ed8:	5400076d 	b.le	4fc4 <fwp_tape_grow.constprop.0+0x120>
    4edc:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4ee0:	eb13003f 	cmp	x1, x19
    4ee4:	5400004d 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ee8:	14000000 	b	4ee8 <fwp_tape_grow.constprop.0+0x44>
    4eec:	a940d2e2 	ldp	x2, x20, [x23, #8]
    4ef0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ef4:	d37df276 	lsl	x22, x19, #3
    4ef8:	f94012e0 	ldr	x0, [x23, #32]
    4efc:	aa1603e1 	mov	x1, x22
    4f00:	f94032f5 	ldr	x21, [x23, #96]
    4f04:	cb020294 	sub	x20, x20, x2
    4f08:	97fff65a 	bl	2870 <realloc@plt>
    4f0c:	b4000c20 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    4f10:	f9400ee1 	ldr	x1, [x23, #24]
    4f14:	8b010801 	add	x1, x0, x1, lsl #2
    4f18:	a90206e0 	stp	x0, x1, [x23, #32]
    4f1c:	b4000895 	cbz	x21, 502c <fwp_tape_grow.constprop.0+0x188>
    4f20:	f94032b6 	ldr	x22, [x21, #96]
    4f24:	eb1302df 	cmp	x22, x19
    4f28:	540003aa 	b.ge	4f9c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    4f2c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f30:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4f34:	eb00027f 	cmp	x19, x0
    4f38:	54000a68 	b.hi	5084 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    4f3c:	f94022b9 	ldr	x25, [x21, #64]
    4f40:	d37cee7a 	lsl	x26, x19, #4
    4f44:	aa1a03e0 	mov	x0, x26
    4f48:	52800041 	mov	w1, #0x2                   	// #2
    4f4c:	97ffff49 	bl	4c70 <fwp_heap_alloc>
    4f50:	aa0003f8 	mov	x24, x0
    4f54:	b4000119 	cbz	x25, 4f74 <fwp_tape_grow.constprop.0+0xd0>
    4f58:	d37ceed6 	lsl	x22, x22, #4
    4f5c:	aa1903e1 	mov	x1, x25
    4f60:	eb1a02df 	cmp	x22, x26
    4f64:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    4f68:	97fff5da 	bl	26d0 <memcpy@plt>
    4f6c:	aa1903e0 	mov	x0, x25
    4f70:	97fffc84 	bl	4180 <fwp_mem_free>
    4f74:	f94032a0 	ldr	x0, [x21, #96]
    4f78:	52800001 	mov	w1, #0x0                   	// #0
    4f7c:	cb000262 	sub	x2, x19, x0
    4f80:	8b001300 	add	x0, x24, x0, lsl #4
    4f84:	d37cec42 	lsl	x2, x2, #4
    4f88:	97fff632 	bl	2850 <memset@plt>
    4f8c:	f94012e0 	ldr	x0, [x23, #32]
    4f90:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f94:	f90022b8 	str	x24, [x21, #64]
    4f98:	f90032b3 	str	x19, [x21, #96]
    4f9c:	d37ef675 	lsl	x21, x19, #2
    4fa0:	b50002b4 	cbnz	x20, 4ff4 <fwp_tape_grow.constprop.0+0x150>
    4fa4:	8b150001 	add	x1, x0, x21
    4fa8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fac:	f9000ef3 	str	x19, [x23, #24]
    4fb0:	f90016e1 	str	x1, [x23, #40]
    4fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fbc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4fc0:	d65f03c0 	ret
    4fc4:	d37ffa73 	lsl	x19, x19, #1
    4fc8:	17ffffc1 	b	4ecc <fwp_tape_grow.constprop.0+0x28>
    4fcc:	eb1502df 	cmp	x22, x21
    4fd0:	aa0403e0 	mov	x0, x4
    4fd4:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    4fd8:	d37df282 	lsl	x2, x20, #3
    4fdc:	cb160063 	sub	x3, x3, x22
    4fe0:	97fff690 	bl	2a20 <__memmove_chk@plt>
    4fe4:	f9401ae1 	ldr	x1, [x23, #48]
    4fe8:	f94012e0 	ldr	x0, [x23, #32]
    4fec:	8b160021 	add	x1, x1, x22
    4ff0:	f9001ee1 	str	x1, [x23, #56]
    4ff4:	f94016e1 	ldr	x1, [x23, #40]
    4ff8:	d37ef675 	lsl	x21, x19, #2
    4ffc:	d37ef682 	lsl	x2, x20, #2
    5000:	8b150000 	add	x0, x0, x21
    5004:	97fff5bb 	bl	26f0 <memmove@plt>
    5008:	f94012e0 	ldr	x0, [x23, #32]
    500c:	8b150001 	add	x1, x0, x21
    5010:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5014:	f9000ef3 	str	x19, [x23, #24]
    5018:	f90016e1 	str	x1, [x23, #40]
    501c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5028:	d65f03c0 	ret
    502c:	f9401ae0 	ldr	x0, [x23, #48]
    5030:	d37cee75 	lsl	x21, x19, #4
    5034:	aa1503e1 	mov	x1, x21
    5038:	97fff60e 	bl	2870 <realloc@plt>
    503c:	b40002a0 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    5040:	f9400ee2 	ldr	x2, [x23, #24]
    5044:	f9001ae0 	str	x0, [x23, #48]
    5048:	8b160004 	add	x4, x0, x22
    504c:	8b020c01 	add	x1, x0, x2, lsl #3
    5050:	f9001ee1 	str	x1, [x23, #56]
    5054:	b5fffbd4 	cbnz	x20, 4fcc <fwp_tape_grow.constprop.0+0x128>
    5058:	f94012e0 	ldr	x0, [x23, #32]
    505c:	d37ef675 	lsl	x21, x19, #2
    5060:	f9001ee4 	str	x4, [x23, #56]
    5064:	8b150001 	add	x1, x0, x21
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	f9000ef3 	str	x19, [x23, #24]
    5070:	f90016e1 	str	x1, [x23, #40]
    5074:	a94153f3 	ldp	x19, x20, [sp, #16]
    5078:	a94363f7 	ldp	x23, x24, [sp, #48]
    507c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5080:	d65f03c0 	ret
    5084:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5088:	910fc000 	add	x0, x0, #0x3f0
    508c:	97fffb81 	bl	3e90 <fwp_trap>
    5090:	aa1703e0 	mov	x0, x23
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	97fff7be 	bl	2f90 <fwp_tape_unlink_scope>
    509c:	f94012e0 	ldr	x0, [x23, #32]
    50a0:	97fff628 	bl	2940 <free@plt>
    50a4:	f9401ae0 	ldr	x0, [x23, #48]
    50a8:	97fff626 	bl	2940 <free@plt>
    50ac:	f94022e0 	ldr	x0, [x23, #64]
    50b0:	97fff624 	bl	2940 <free@plt>
    50b4:	f9000eff 	str	xzr, [x23, #24]
    50b8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    50bc:	f947e821 	ldr	x1, [x1, #4048]
    50c0:	a9047eff 	stp	xzr, xzr, [x23, #64]
    50c4:	d2800262 	mov	x2, #0x13                  	// #19
    50c8:	4f000400 	movi	v0.4s, #0x0
    50cc:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    50d0:	f9400023 	ldr	x3, [x1]
    50d4:	b90006ff 	str	wzr, [x23, #4]
    50d8:	d2800021 	mov	x1, #0x1                   	// #1
    50dc:	91042000 	add	x0, x0, #0x108
    50e0:	3c8082e0 	stur	q0, [x23, #8]
    50e4:	ad0102e0 	stp	q0, q0, [x23, #32]
    50e8:	97fff626 	bl	2980 <fwrite@plt>
    50ec:	d2800000 	mov	x0, #0x0                   	// #0
    50f0:	97fff630 	bl	29b0 <fflush@plt>
    50f4:	52800cc0 	mov	w0, #0x66                  	// #102
    50f8:	97fff63e 	bl	29f0 <_Exit@plt>
    50fc:	d503201f 	nop

0000000000005100 <f141.constprop.0>:
    5100:	f100001f 	cmp	x0, #0x0
    5104:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5108:	54000a2b 	b.lt	524c <f141.constprop.0+0x14c>  // b.tstop
    510c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5110:	aa0003e2 	mov	x2, x0
    5114:	910003fd 	mov	x29, sp
    5118:	a90153f3 	stp	x19, x20, [sp, #16]
    511c:	aa0003f4 	mov	x20, x0
    5120:	aa010000 	orr	x0, x0, x1
    5124:	a9025bf5 	stp	x21, x22, [sp, #32]
    5128:	aa0103f6 	mov	x22, x1
    512c:	f9001bf7 	str	x23, [sp, #48]
    5130:	fd001fe8 	str	d8, [sp, #56]
    5134:	b7f80180 	tbnz	x0, #63, 5164 <f141.constprop.0+0x64>
    5138:	9360fc20 	asr	x0, x1, #32
    513c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5140:	eb82801f 	cmp	x0, x2, asr #32
    5144:	54000881 	b.ne	5254 <f141.constprop.0+0x154>  // b.any
    5148:	97fffd56 	bl	46a0 <fwp_tape_of>
    514c:	aa0003f3 	mov	x19, x0
    5150:	f9403000 	ldr	x0, [x0, #96]
    5154:	b40001e0 	cbz	x0, 5190 <f141.constprop.0+0x90>
    5158:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    515c:	91116000 	add	x0, x0, #0x458
    5160:	97fffb4c 	bl	3e90 <fwp_trap>
    5164:	9360fc40 	asr	x0, x2, #32
    5168:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    516c:	b6fffee2 	tbz	x2, #63, 5148 <f141.constprop.0+0x48>
    5170:	2f00e408 	movi	d8, #0x0
    5174:	9360fc20 	asr	x0, x1, #32
    5178:	aa0103f4 	mov	x20, x1
    517c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5180:	97fffd48 	bl	46a0 <fwp_tape_of>
    5184:	aa0003f3 	mov	x19, x0
    5188:	f9403000 	ldr	x0, [x0, #96]
    518c:	b5fffe60 	cbnz	x0, 5158 <f141.constprop.0+0x58>
    5190:	f9400a77 	ldr	x23, [x19, #16]
    5194:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5198:	eb0002ff 	cmp	x23, x0
    519c:	5400046c 	b.gt	5228 <f141.constprop.0+0x128>
    51a0:	eb3442ff 	cmp	x23, w20, uxtw
    51a4:	540004ed 	b.le	5240 <f141.constprop.0+0x140>
    51a8:	b7f80076 	tbnz	x22, #63, 51b4 <f141.constprop.0+0xb4>
    51ac:	eb3642ff 	cmp	x23, w22, uxtw
    51b0:	5400048d 	b.le	5240 <f141.constprop.0+0x140>
    51b4:	f9400675 	ldr	x21, [x19, #8]
    51b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51bc:	cb1502f5 	sub	x21, x23, x21
    51c0:	910006a1 	add	x1, x21, #0x1
    51c4:	eb00003f 	cmp	x1, x0
    51c8:	54000308 	b.hi	5228 <f141.constprop.0+0x128>  // b.pmore
    51cc:	f9400e60 	ldr	x0, [x19, #24]
    51d0:	eb00003f 	cmp	x1, x0
    51d4:	5400030c 	b.gt	5234 <f141.constprop.0+0x134>
    51d8:	a9420262 	ldp	x2, x0, [x19, #32]
    51dc:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    51e0:	f9401a61 	ldr	x1, [x19, #48]
    51e4:	b8357854 	str	w20, [x2, x21, lsl #2]
    51e8:	f9401e62 	ldr	x2, [x19, #56]
    51ec:	f10002df 	cmp	x22, #0x0
    51f0:	fc357820 	str	d0, [x1, x21, lsl #3]
    51f4:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    51f8:	b8357816 	str	w22, [x0, x21, lsl #2]
    51fc:	92607e80 	and	x0, x20, #0xffffffff00000000
    5200:	910006e1 	add	x1, x23, #0x1
    5204:	aa170000 	orr	x0, x0, x23
    5208:	fc357848 	str	d8, [x2, x21, lsl #3]
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	f9401bf7 	ldr	x23, [sp, #48]
    5214:	fd401fe8 	ldr	d8, [sp, #56]
    5218:	f9000a61 	str	x1, [x19, #16]
    521c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5220:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5224:	d65f03c0 	ret
    5228:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    522c:	910fc000 	add	x0, x0, #0x3f0
    5230:	97fffb18 	bl	3e90 <fwp_trap>
    5234:	aa1303e0 	mov	x0, x19
    5238:	97ffff1b 	bl	4ea4 <fwp_tape_grow.constprop.0>
    523c:	17ffffe7 	b	51d8 <f141.constprop.0+0xd8>
    5240:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5244:	91122000 	add	x0, x0, #0x488
    5248:	97fffb12 	bl	3e90 <fwp_trap>
    524c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5250:	d65f03c0 	ret
    5254:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5258:	91104000 	add	x0, x0, #0x410
    525c:	97fffb0d 	bl	3e90 <fwp_trap>

0000000000005260 <w120>:
    5260:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5264:	910003fd 	mov	x29, sp
    5268:	a90153f3 	stp	x19, x20, [sp, #16]
    526c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5270:	a90363f7 	stp	x23, x24, [sp, #48]
    5274:	aa0003f8 	mov	x24, x0
    5278:	a9046bf9 	stp	x25, x26, [sp, #64]
    527c:	aa0103f9 	mov	x25, x1
    5280:	6d0527e8 	stp	d8, d9, [sp, #80]
    5284:	1e604008 	fmov	d8, d0
    5288:	1e604029 	fmov	d9, d1
    528c:	6d062fea 	stp	d10, d11, [sp, #96]
    5290:	1e60080a 	fmul	d10, d0, d0
    5294:	b7f821a0 	tbnz	x0, #63, 56c8 <w120+0x468>
    5298:	9360fc17 	asr	x23, x0, #32
    529c:	aa1703e0 	mov	x0, x23
    52a0:	97fffd00 	bl	46a0 <fwp_tape_of>
    52a4:	f9403001 	ldr	x1, [x0, #96]
    52a8:	aa0003f3 	mov	x19, x0
    52ac:	b4000081 	cbz	x1, 52bc <w120+0x5c>
    52b0:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    52b4:	91116000 	add	x0, x0, #0x458
    52b8:	97fffaf6 	bl	3e90 <fwp_trap>
    52bc:	f9400815 	ldr	x21, [x0, #16]
    52c0:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    52c4:	eb0102bf 	cmp	x21, x1
    52c8:	54001d8c 	b.gt	5678 <w120+0x418>
    52cc:	eb3842bf 	cmp	x21, w24, uxtw
    52d0:	54001ced 	b.le	566c <w120+0x40c>
    52d4:	f9400416 	ldr	x22, [x0, #8]
    52d8:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    52dc:	cb1602b6 	sub	x22, x21, x22
    52e0:	910006c1 	add	x1, x22, #0x1
    52e4:	eb02003f 	cmp	x1, x2
    52e8:	54001c88 	b.hi	5678 <w120+0x418>  // b.pmore
    52ec:	f9400c02 	ldr	x2, [x0, #24]
    52f0:	eb02003f 	cmp	x1, x2
    52f4:	54001c8c 	b.gt	5684 <w120+0x424>
    52f8:	a9420660 	ldp	x0, x1, [x19, #32]
    52fc:	92607f14 	and	x20, x24, #0xffffffff00000000
    5300:	f9401a62 	ldr	x2, [x19, #48]
    5304:	b8367818 	str	w24, [x0, x22, lsl #2]
    5308:	f9401e60 	ldr	x0, [x19, #56]
    530c:	aa150294 	orr	x20, x20, x21
    5310:	fc367848 	str	d8, [x2, x22, lsl #3]
    5314:	910006b5 	add	x21, x21, #0x1
    5318:	b8367838 	str	w24, [x1, x22, lsl #2]
    531c:	1e6a392a 	fsub	d10, d9, d10
    5320:	9360fe9a 	asr	x26, x20, #32
    5324:	fc367808 	str	d8, [x0, x22, lsl #3]
    5328:	f9000a75 	str	x21, [x19, #16]
    532c:	b7f80079 	tbnz	x25, #63, 5338 <w120+0xd8>
    5330:	eb99835f 	cmp	x26, x25, asr #32
    5334:	54001e21 	b.ne	56f8 <w120+0x498>  // b.any
    5338:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    533c:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    5340:	eb1a02ff 	cmp	x23, x26
    5344:	540000c0 	b.eq	535c <w120+0xfc>  // b.none
    5348:	aa1a03e0 	mov	x0, x26
    534c:	97fffcd5 	bl	46a0 <fwp_tape_of>
    5350:	aa0003f3 	mov	x19, x0
    5354:	f9403000 	ldr	x0, [x0, #96]
    5358:	b5fffac0 	cbnz	x0, 52b0 <w120+0x50>
    535c:	f9400a77 	ldr	x23, [x19, #16]
    5360:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5364:	eb0002ff 	cmp	x23, x0
    5368:	5400188c 	b.gt	5678 <w120+0x418>
    536c:	eb3442ff 	cmp	x23, w20, uxtw
    5370:	540017ed 	b.le	566c <w120+0x40c>
    5374:	b7f80079 	tbnz	x25, #63, 5380 <w120+0x120>
    5378:	eb3942ff 	cmp	x23, w25, uxtw
    537c:	5400178d 	b.le	566c <w120+0x40c>
    5380:	f9400675 	ldr	x21, [x19, #8]
    5384:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5388:	cb1502f5 	sub	x21, x23, x21
    538c:	910006a1 	add	x1, x21, #0x1
    5390:	eb00003f 	cmp	x1, x0
    5394:	54001728 	b.hi	5678 <w120+0x418>  // b.pmore
    5398:	f9400e60 	ldr	x0, [x19, #24]
    539c:	eb00003f 	cmp	x1, x0
    53a0:	540018ec 	b.gt	56bc <w120+0x45c>
    53a4:	a9420e62 	ldp	x2, x3, [x19, #32]
    53a8:	f100033f 	cmp	x25, #0x0
    53ac:	f9401a61 	ldr	x1, [x19, #48]
    53b0:	b8357854 	str	w20, [x2, x21, lsl #2]
    53b4:	f9401e62 	ldr	x2, [x19, #56]
    53b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53bc:	fc35782b 	str	d11, [x1, x21, lsl #3]
    53c0:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    53c4:	b8357861 	str	w1, [x3, x21, lsl #2]
    53c8:	910006f6 	add	x22, x23, #0x1
    53cc:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    53d0:	92607e94 	and	x20, x20, #0xffffffff00000000
    53d4:	fc357849 	str	d9, [x2, x21, lsl #3]
    53d8:	aa170294 	orr	x20, x20, x23
    53dc:	f9000a76 	str	x22, [x19, #16]
    53e0:	1e68396b 	fsub	d11, d11, d8
    53e4:	b7f81a78 	tbnz	x24, #63, 5730 <w120+0x4d0>
    53e8:	9360ff17 	asr	x23, x24, #32
    53ec:	eb1a02ff 	cmp	x23, x26
    53f0:	540000e0 	b.eq	540c <w120+0x1ac>  // b.none
    53f4:	aa1703e0 	mov	x0, x23
    53f8:	97fffcaa 	bl	46a0 <fwp_tape_of>
    53fc:	aa0003f3 	mov	x19, x0
    5400:	f9403000 	ldr	x0, [x0, #96]
    5404:	b5fff560 	cbnz	x0, 52b0 <w120+0x50>
    5408:	f9400a76 	ldr	x22, [x19, #16]
    540c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5410:	eb0002df 	cmp	x22, x0
    5414:	5400132c 	b.gt	5678 <w120+0x418>
    5418:	eb3842df 	cmp	x22, w24, uxtw
    541c:	5400128d 	b.le	566c <w120+0x40c>
    5420:	f9400675 	ldr	x21, [x19, #8]
    5424:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5428:	cb1502d5 	sub	x21, x22, x21
    542c:	910006a1 	add	x1, x21, #0x1
    5430:	eb00003f 	cmp	x1, x0
    5434:	54001228 	b.hi	5678 <w120+0x418>  // b.pmore
    5438:	f9400e60 	ldr	x0, [x19, #24]
    543c:	eb00003f 	cmp	x1, x0
    5440:	5400138c 	b.gt	56b0 <w120+0x450>
    5444:	a9420262 	ldp	x2, x0, [x19, #32]
    5448:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    544c:	f9401a63 	ldr	x3, [x19, #48]
    5450:	b8357858 	str	w24, [x2, x21, lsl #2]
    5454:	f9401e62 	ldr	x2, [x19, #56]
    5458:	12800001 	mov	w1, #0xffffffff            	// #-1
    545c:	fc357860 	str	d0, [x3, x21, lsl #3]
    5460:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5464:	b8357801 	str	w1, [x0, x21, lsl #2]
    5468:	92607f00 	and	x0, x24, #0xffffffff00000000
    546c:	aa160018 	orr	x24, x0, x22
    5470:	910006c1 	add	x1, x22, #0x1
    5474:	fc357840 	str	d0, [x2, x21, lsl #3]
    5478:	f9000a61 	str	x1, [x19, #16]
    547c:	9360fe99 	asr	x25, x20, #32
    5480:	1e6a0949 	fmul	d9, d10, d10
    5484:	eb17033f 	cmp	x25, x23
    5488:	540000c0 	b.eq	54a0 <w120+0x240>  // b.none
    548c:	aa1903e0 	mov	x0, x25
    5490:	97fffc84 	bl	46a0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5fff0a0 	cbnz	x0, 52b0 <w120+0x50>
    54a0:	f9400a75 	ldr	x21, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002bf 	cmp	x21, x0
    54ac:	54000e6c 	b.gt	5678 <w120+0x418>
    54b0:	eb3442bf 	cmp	x21, w20, uxtw
    54b4:	54000dcd 	b.le	566c <w120+0x40c>
    54b8:	f9400676 	ldr	x22, [x19, #8]
    54bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54c0:	cb1602b6 	sub	x22, x21, x22
    54c4:	910006c1 	add	x1, x22, #0x1
    54c8:	eb00003f 	cmp	x1, x0
    54cc:	54000d68 	b.hi	5678 <w120+0x418>  // b.pmore
    54d0:	f9400e60 	ldr	x0, [x19, #24]
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000e6c 	b.gt	56a4 <w120+0x444>
    54dc:	92607e80 	and	x0, x20, #0xffffffff00000000
    54e0:	aa150017 	orr	x23, x0, x21
    54e4:	a9420261 	ldp	x1, x0, [x19, #32]
    54e8:	f9401a62 	ldr	x2, [x19, #48]
    54ec:	b8367834 	str	w20, [x1, x22, lsl #2]
    54f0:	f9401e61 	ldr	x1, [x19, #56]
    54f4:	fc36784a 	str	d10, [x2, x22, lsl #3]
    54f8:	b8367814 	str	w20, [x0, x22, lsl #2]
    54fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5500:	9e670000 	fmov	d0, x0
    5504:	910006b4 	add	x20, x21, #0x1
    5508:	fc36782a 	str	d10, [x1, x22, lsl #3]
    550c:	9360fef6 	asr	x22, x23, #32
    5510:	f9000a74 	str	x20, [x19, #16]
    5514:	1e600929 	fmul	d9, d9, d0
    5518:	eb1902df 	cmp	x22, x25
    551c:	540000e0 	b.eq	5538 <w120+0x2d8>  // b.none
    5520:	aa1603e0 	mov	x0, x22
    5524:	97fffc5f 	bl	46a0 <fwp_tape_of>
    5528:	aa0003f3 	mov	x19, x0
    552c:	f9403000 	ldr	x0, [x0, #96]
    5530:	b5ffec00 	cbnz	x0, 52b0 <w120+0x50>
    5534:	f9400a74 	ldr	x20, [x19, #16]
    5538:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    553c:	eb00029f 	cmp	x20, x0
    5540:	540009cc 	b.gt	5678 <w120+0x418>
    5544:	eb37429f 	cmp	x20, w23, uxtw
    5548:	5400092d 	b.le	566c <w120+0x40c>
    554c:	f9400675 	ldr	x21, [x19, #8]
    5550:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5554:	cb150295 	sub	x21, x20, x21
    5558:	910006a1 	add	x1, x21, #0x1
    555c:	eb00003f 	cmp	x1, x0
    5560:	540008c8 	b.hi	5678 <w120+0x418>  // b.pmore
    5564:	f9400e60 	ldr	x0, [x19, #24]
    5568:	eb00003f 	cmp	x1, x0
    556c:	5400096c 	b.gt	5698 <w120+0x438>
    5570:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5574:	9e670000 	fmov	d0, x0
    5578:	a9420262 	ldp	x2, x0, [x19, #32]
    557c:	1e6b0968 	fmul	d8, d11, d11
    5580:	f9401a61 	ldr	x1, [x19, #48]
    5584:	b8357857 	str	w23, [x2, x21, lsl #2]
    5588:	f9401e62 	ldr	x2, [x19, #56]
    558c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5590:	12800001 	mov	w1, #0xffffffff            	// #-1
    5594:	b8357801 	str	w1, [x0, x21, lsl #2]
    5598:	91000681 	add	x1, x20, #0x1
    559c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    55a0:	92607ee0 	and	x0, x23, #0xffffffff00000000
    55a4:	f9000a61 	str	x1, [x19, #16]
    55a8:	aa140014 	orr	x20, x0, x20
    55ac:	b100071f 	cmn	x24, #0x1
    55b0:	54000c60 	b.eq	573c <w120+0x4dc>  // b.none
    55b4:	9360ff00 	asr	x0, x24, #32
    55b8:	eb16001f 	cmp	x0, x22
    55bc:	540000a0 	b.eq	55d0 <w120+0x370>  // b.none
    55c0:	97fffc38 	bl	46a0 <fwp_tape_of>
    55c4:	aa0003f3 	mov	x19, x0
    55c8:	f9403000 	ldr	x0, [x0, #96]
    55cc:	b5ffe720 	cbnz	x0, 52b0 <w120+0x50>
    55d0:	f9400a75 	ldr	x21, [x19, #16]
    55d4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55d8:	eb0002bf 	cmp	x21, x0
    55dc:	540004ec 	b.gt	5678 <w120+0x418>
    55e0:	eb3842bf 	cmp	x21, w24, uxtw
    55e4:	5400044d 	b.le	566c <w120+0x40c>
    55e8:	f9400676 	ldr	x22, [x19, #8]
    55ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55f0:	cb1602b6 	sub	x22, x21, x22
    55f4:	910006c1 	add	x1, x22, #0x1
    55f8:	eb00003f 	cmp	x1, x0
    55fc:	540003e8 	b.hi	5678 <w120+0x418>  // b.pmore
    5600:	f9400e60 	ldr	x0, [x19, #24]
    5604:	eb00003f 	cmp	x1, x0
    5608:	5400042c 	b.gt	568c <w120+0x42c>
    560c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5610:	92607f00 	and	x0, x24, #0xffffffff00000000
    5614:	f9401a63 	ldr	x3, [x19, #48]
    5618:	b8367838 	str	w24, [x1, x22, lsl #2]
    561c:	f9401e61 	ldr	x1, [x19, #56]
    5620:	aa150000 	orr	x0, x0, x21
    5624:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5628:	910006b5 	add	x21, x21, #0x1
    562c:	b8367858 	str	w24, [x2, x22, lsl #2]
    5630:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5634:	f9000a75 	str	x21, [x19, #16]
    5638:	1e692908 	fadd	d8, d8, d9
    563c:	aa1403e1 	mov	x1, x20
    5640:	97fffeb0 	bl	5100 <f141.constprop.0>
    5644:	aa0003e1 	mov	x1, x0
    5648:	a94153f3 	ldp	x19, x20, [sp, #16]
    564c:	9e660100 	fmov	x0, d8
    5650:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5654:	a94363f7 	ldp	x23, x24, [sp, #48]
    5658:	a9446bf9 	ldp	x25, x26, [sp, #64]
    565c:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5660:	6d462fea 	ldp	d10, d11, [sp, #96]
    5664:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5668:	d65f03c0 	ret
    566c:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5670:	91122000 	add	x0, x0, #0x488
    5674:	97fffa07 	bl	3e90 <fwp_trap>
    5678:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    567c:	910fc000 	add	x0, x0, #0x3f0
    5680:	97fffa04 	bl	3e90 <fwp_trap>
    5684:	97fffe08 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5688:	17ffff1c 	b	52f8 <w120+0x98>
    568c:	aa1303e0 	mov	x0, x19
    5690:	97fffe05 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5694:	17ffffde 	b	560c <w120+0x3ac>
    5698:	aa1303e0 	mov	x0, x19
    569c:	97fffe02 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56a0:	17ffffb4 	b	5570 <w120+0x310>
    56a4:	aa1303e0 	mov	x0, x19
    56a8:	97fffdff 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56ac:	17ffff8c 	b	54dc <w120+0x27c>
    56b0:	aa1303e0 	mov	x0, x19
    56b4:	97fffdfc 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56b8:	17ffff63 	b	5444 <w120+0x1e4>
    56bc:	aa1303e0 	mov	x0, x19
    56c0:	97fffdf9 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56c4:	17ffff38 	b	53a4 <w120+0x144>
    56c8:	1e6a382a 	fsub	d10, d1, d10
    56cc:	b6f801c1 	tbz	x1, #63, 5704 <w120+0x4a4>
    56d0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56d4:	1e6a0949 	fmul	d9, d10, d10
    56d8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    56dc:	9e670001 	fmov	d1, x0
    56e0:	1e683808 	fsub	d8, d0, d8
    56e4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    56e8:	aa1403e0 	mov	x0, x20
    56ec:	1e610929 	fmul	d9, d9, d1
    56f0:	1e680908 	fmul	d8, d8, d8
    56f4:	17ffffd1 	b	5638 <w120+0x3d8>
    56f8:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    56fc:	91104000 	add	x0, x0, #0x410
    5700:	97fff9e4 	bl	3e90 <fwp_trap>
    5704:	2f00e409 	movi	d9, #0x0
    5708:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    570c:	9360fc3a 	asr	x26, x1, #32
    5710:	aa0103f4 	mov	x20, x1
    5714:	aa1a03e0 	mov	x0, x26
    5718:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    571c:	97fffbe1 	bl	46a0 <fwp_tape_of>
    5720:	aa0003f3 	mov	x19, x0
    5724:	f9403000 	ldr	x0, [x0, #96]
    5728:	b5ffdc40 	cbnz	x0, 52b0 <w120+0x50>
    572c:	17ffff0c 	b	535c <w120+0xfc>
    5730:	aa1a03f7 	mov	x23, x26
    5734:	aa0003f8 	mov	x24, x0
    5738:	17ffff51 	b	547c <w120+0x21c>
    573c:	aa1803e0 	mov	x0, x24
    5740:	17ffffbe 	b	5638 <w120+0x3d8>

0000000000005744 <fwp_rc_share>:
    5744:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5748:	91150042 	add	x2, x2, #0x540
    574c:	f949d843 	ldr	x3, [x2, #5040]
    5750:	f949ec41 	ldr	x1, [x2, #5080]
    5754:	cb030000 	sub	x0, x0, x3
    5758:	eb01401f 	cmp	x0, x1, lsl #16
    575c:	540003a2 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5760:	d350fc01 	lsr	x1, x0, #16
    5764:	f949fc44 	ldr	x4, [x2, #5112]
    5768:	8b010821 	add	x1, x1, x1, lsl #2
    576c:	d37df021 	lsl	x1, x1, #3
    5770:	8b010083 	add	x3, x4, x1
    5774:	f9401062 	ldr	x2, [x3, #32]
    5778:	b40002c2 	cbz	x2, 57d0 <fwp_rc_share+0x8c>
    577c:	38616881 	ldrb	w1, [x4, x1]
    5780:	7100083f 	cmp	w1, #0x2
    5784:	54000220 	b.eq	57c8 <fwp_rc_share+0x84>  // b.none
    5788:	7100043f 	cmp	w1, #0x1
    578c:	54000221 	b.ne	57d0 <fwp_rc_share+0x8c>  // b.any
    5790:	29430464 	ldp	w4, w1, [x3, #24]
    5794:	92403c00 	and	x0, x0, #0xffff
    5798:	9b047c00 	mul	x0, x0, x4
    579c:	d360fc00 	lsr	x0, x0, #32
    57a0:	eb01001f 	cmp	x0, x1
    57a4:	54000162 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    57a8:	8b000042 	add	x2, x2, x0
    57ac:	39400040 	ldrb	w0, [x2]
    57b0:	34000100 	cbz	w0, 57d0 <fwp_rc_share+0x8c>
    57b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57b8:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    57bc:	9112a000 	add	x0, x0, #0x4a8
    57c0:	910003fd 	mov	x29, sp
    57c4:	97fff9b3 	bl	3e90 <fwp_trap>
    57c8:	72003c1f 	tst	w0, #0xffff
    57cc:	54ffff00 	b.eq	57ac <fwp_rc_share+0x68>  // b.none
    57d0:	d65f03c0 	ret

00000000000057d4 <fwp_rc_fresh>:
    57d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    57d8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    57dc:	91150063 	add	x3, x3, #0x540
    57e0:	910003fd 	mov	x29, sp
    57e4:	a90153f3 	stp	x19, x20, [sp, #16]
    57e8:	aa0003f3 	mov	x19, x0
    57ec:	f949d861 	ldr	x1, [x3, #5040]
    57f0:	f949ec60 	ldr	x0, [x3, #5080]
    57f4:	cb010261 	sub	x1, x19, x1
    57f8:	eb00403f 	cmp	x1, x0, lsl #16
    57fc:	54000322 	b.cs	5860 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5800:	d350fc22 	lsr	x2, x1, #16
    5804:	f949fc63 	ldr	x3, [x3, #5112]
    5808:	8b020842 	add	x2, x2, x2, lsl #2
    580c:	d37df042 	lsl	x2, x2, #3
    5810:	8b020060 	add	x0, x3, x2
    5814:	f9401014 	ldr	x20, [x0, #32]
    5818:	b4000254 	cbz	x20, 5860 <fwp_rc_fresh+0x8c>
    581c:	38626862 	ldrb	w2, [x3, x2]
    5820:	7100085f 	cmp	w2, #0x2
    5824:	54000260 	b.eq	5870 <fwp_rc_fresh+0x9c>  // b.none
    5828:	7100045f 	cmp	w2, #0x1
    582c:	540001a1 	b.ne	5860 <fwp_rc_fresh+0x8c>  // b.any
    5830:	29430002 	ldp	w2, w0, [x0, #24]
    5834:	92403c21 	and	x1, x1, #0xffff
    5838:	9b027c21 	mul	x1, x1, x2
    583c:	d360fc21 	lsr	x1, x1, #32
    5840:	eb00003f 	cmp	x1, x0
    5844:	540000e2 	b.cs	5860 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5848:	8b010294 	add	x20, x20, x1
    584c:	39400280 	ldrb	w0, [x20]
    5850:	7103fc1f 	cmp	w0, #0xff
    5854:	540001a0 	b.eq	5888 <fwp_rc_fresh+0xb4>  // b.none
    5858:	52800020 	mov	w0, #0x1                   	// #1
    585c:	39000280 	strb	w0, [x20]
    5860:	aa1303e0 	mov	x0, x19
    5864:	a94153f3 	ldp	x19, x20, [sp, #16]
    5868:	a8c27bfd 	ldp	x29, x30, [sp], #32
    586c:	d65f03c0 	ret
    5870:	72003c3f 	tst	w1, #0xffff
    5874:	54fffec0 	b.eq	584c <fwp_rc_fresh+0x78>  // b.none
    5878:	aa1303e0 	mov	x0, x19
    587c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5884:	d65f03c0 	ret
    5888:	aa1403e0 	mov	x0, x20
    588c:	97fff9a1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5890:	17fffff2 	b	5858 <fwp_rc_fresh+0x84>

0000000000005894 <fwp_rc_free_arr>:
    5894:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5898:	91150063 	add	x3, x3, #0x540
    589c:	f949d861 	ldr	x1, [x3, #5040]
    58a0:	f949ec62 	ldr	x2, [x3, #5080]
    58a4:	cb010001 	sub	x1, x0, x1
    58a8:	eb02403f 	cmp	x1, x2, lsl #16
    58ac:	54000342 	b.cs	5914 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58b0:	d350fc22 	lsr	x2, x1, #16
    58b4:	f949fc65 	ldr	x5, [x3, #5112]
    58b8:	8b020842 	add	x2, x2, x2, lsl #2
    58bc:	d37df042 	lsl	x2, x2, #3
    58c0:	8b0200a4 	add	x4, x5, x2
    58c4:	f9401083 	ldr	x3, [x4, #32]
    58c8:	b4000263 	cbz	x3, 5914 <fwp_rc_free_arr+0x80>
    58cc:	386268a2 	ldrb	w2, [x5, x2]
    58d0:	7100085f 	cmp	w2, #0x2
    58d4:	540001c0 	b.eq	590c <fwp_rc_free_arr+0x78>  // b.none
    58d8:	7100045f 	cmp	w2, #0x1
    58dc:	540001c1 	b.ne	5914 <fwp_rc_free_arr+0x80>  // b.any
    58e0:	29430885 	ldp	w5, w2, [x4, #24]
    58e4:	92403c21 	and	x1, x1, #0xffff
    58e8:	9b057c21 	mul	x1, x1, x5
    58ec:	d360fc21 	lsr	x1, x1, #32
    58f0:	eb02003f 	cmp	x1, x2
    58f4:	54000102 	b.cs	5914 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58f8:	8b010063 	add	x3, x3, x1
    58fc:	39400061 	ldrb	w1, [x3]
    5900:	7100043f 	cmp	w1, #0x1
    5904:	54000081 	b.ne	5914 <fwp_rc_free_arr+0x80>  // b.any
    5908:	17fffa1e 	b	4180 <fwp_mem_free>
    590c:	72003c3f 	tst	w1, #0xffff
    5910:	54ffff60 	b.eq	58fc <fwp_rc_free_arr+0x68>  // b.none
    5914:	d65f03c0 	ret
    5918:	d503201f 	nop
    591c:	d503201f 	nop

0000000000005920 <fwp_rc_dup>:
    5920:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5924:	91150042 	add	x2, x2, #0x540
    5928:	f949d841 	ldr	x1, [x2, #5040]
    592c:	f949ec43 	ldr	x3, [x2, #5080]
    5930:	cb010001 	sub	x1, x0, x1
    5934:	eb03403f 	cmp	x1, x3, lsl #16
    5938:	54000342 	b.cs	59a0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    593c:	d350fc20 	lsr	x0, x1, #16
    5940:	f949fc44 	ldr	x4, [x2, #5112]
    5944:	8b000800 	add	x0, x0, x0, lsl #2
    5948:	d37df002 	lsl	x2, x0, #3
    594c:	8b020083 	add	x3, x4, x2
    5950:	f9401060 	ldr	x0, [x3, #32]
    5954:	b4000260 	cbz	x0, 59a0 <fwp_rc_dup+0x80>
    5958:	38626882 	ldrb	w2, [x4, x2]
    595c:	7100085f 	cmp	w2, #0x2
    5960:	54000220 	b.eq	59a4 <fwp_rc_dup+0x84>  // b.none
    5964:	7100045f 	cmp	w2, #0x1
    5968:	540001c1 	b.ne	59a0 <fwp_rc_dup+0x80>  // b.any
    596c:	29430864 	ldp	w4, w2, [x3, #24]
    5970:	92403c21 	and	x1, x1, #0xffff
    5974:	9b047c21 	mul	x1, x1, x4
    5978:	d360fc21 	lsr	x1, x1, #32
    597c:	eb02003f 	cmp	x1, x2
    5980:	54000102 	b.cs	59a0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5984:	8b010000 	add	x0, x0, x1
    5988:	39400001 	ldrb	w1, [x0]
    598c:	340000a1 	cbz	w1, 59a0 <fwp_rc_dup+0x80>
    5990:	7103f43f 	cmp	w1, #0xfd
    5994:	540000e8 	b.hi	59b0 <fwp_rc_dup+0x90>  // b.pmore
    5998:	11000421 	add	w1, w1, #0x1
    599c:	39000001 	strb	w1, [x0]
    59a0:	d65f03c0 	ret
    59a4:	72003c3f 	tst	w1, #0xffff
    59a8:	54ffff00 	b.eq	5988 <fwp_rc_dup+0x68>  // b.none
    59ac:	d65f03c0 	ret
    59b0:	17fffa6d 	b	4364 <fwp_rc_wide_dup>

00000000000059b4 <fwp_owned_entry173>:
    59b4:	d10103ff 	sub	sp, sp, #0x40
    59b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    59bc:	f947f442 	ldr	x2, [x2, #4072]
    59c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    59c4:	910083fd 	add	x29, sp, #0x20
    59c8:	a90353f3 	stp	x19, x20, [sp, #48]
    59cc:	f9400043 	ldr	x3, [x2]
    59d0:	f9000fe3 	str	x3, [sp, #24]
    59d4:	d2800003 	mov	x3, #0x0                   	// #0
    59d8:	a9400c01 	ldp	x1, x3, [x0]
    59dc:	f9400802 	ldr	x2, [x0, #16]
    59e0:	ab020022 	adds	x2, x1, x2
    59e4:	540006e6 	b.vs	5ac0 <fwp_owned_entry173+0x10c>
    59e8:	910023e1 	add	x1, sp, #0x8
    59ec:	52800000 	mov	w0, #0x0                   	// #0
    59f0:	a9008be3 	stp	x3, x2, [sp, #8]
    59f4:	97fffce4 	bl	4d84 <fwp_data.part.0.constprop.0>
    59f8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    59fc:	91150063 	add	x3, x3, #0x540
    5a00:	aa0003f3 	mov	x19, x0
    5a04:	f949d861 	ldr	x1, [x3, #5040]
    5a08:	f949ec60 	ldr	x0, [x3, #5080]
    5a0c:	cb010261 	sub	x1, x19, x1
    5a10:	eb00403f 	cmp	x1, x0, lsl #16
    5a14:	54000322 	b.cs	5a78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a18:	d350fc22 	lsr	x2, x1, #16
    5a1c:	f949fc63 	ldr	x3, [x3, #5112]
    5a20:	8b020842 	add	x2, x2, x2, lsl #2
    5a24:	d37df042 	lsl	x2, x2, #3
    5a28:	8b020060 	add	x0, x3, x2
    5a2c:	f9401014 	ldr	x20, [x0, #32]
    5a30:	b4000254 	cbz	x20, 5a78 <fwp_owned_entry173+0xc4>
    5a34:	38626862 	ldrb	w2, [x3, x2]
    5a38:	7100085f 	cmp	w2, #0x2
    5a3c:	54000360 	b.eq	5aa8 <fwp_owned_entry173+0xf4>  // b.none
    5a40:	7100045f 	cmp	w2, #0x1
    5a44:	540001a1 	b.ne	5a78 <fwp_owned_entry173+0xc4>  // b.any
    5a48:	29430002 	ldp	w2, w0, [x0, #24]
    5a4c:	92403c21 	and	x1, x1, #0xffff
    5a50:	9b027c21 	mul	x1, x1, x2
    5a54:	d360fc21 	lsr	x1, x1, #32
    5a58:	eb00003f 	cmp	x1, x0
    5a5c:	540000e2 	b.cs	5a78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a60:	8b010294 	add	x20, x20, x1
    5a64:	39400280 	ldrb	w0, [x20]
    5a68:	7103fc1f 	cmp	w0, #0xff
    5a6c:	54000240 	b.eq	5ab4 <fwp_owned_entry173+0x100>  // b.none
    5a70:	52800020 	mov	w0, #0x1                   	// #1
    5a74:	39000280 	strb	w0, [x20]
    5a78:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a7c:	f947f400 	ldr	x0, [x0, #4072]
    5a80:	f9400fe2 	ldr	x2, [sp, #24]
    5a84:	f9400001 	ldr	x1, [x0]
    5a88:	eb010042 	subs	x2, x2, x1
    5a8c:	d2800001 	mov	x1, #0x0                   	// #0
    5a90:	540001a1 	b.ne	5ac4 <fwp_owned_entry173+0x110>  // b.any
    5a94:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a98:	aa1303e0 	mov	x0, x19
    5a9c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5aa0:	910103ff 	add	sp, sp, #0x40
    5aa4:	d65f03c0 	ret
    5aa8:	72003c3f 	tst	w1, #0xffff
    5aac:	54fffe61 	b.ne	5a78 <fwp_owned_entry173+0xc4>  // b.any
    5ab0:	17ffffed 	b	5a64 <fwp_owned_entry173+0xb0>
    5ab4:	aa1403e0 	mov	x0, x20
    5ab8:	97fff916 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5abc:	17ffffed 	b	5a70 <fwp_owned_entry173+0xbc>
    5ac0:	97fff3f0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ac4:	97fff36f 	bl	2880 <__stack_chk_fail@plt>
    5ac8:	d503201f 	nop
    5acc:	d503201f 	nop

0000000000005ad0 <e173>:
    5ad0:	d10103ff 	sub	sp, sp, #0x40
    5ad4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5ad8:	f947f442 	ldr	x2, [x2, #4072]
    5adc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ae0:	910083fd 	add	x29, sp, #0x20
    5ae4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ae8:	f9400043 	ldr	x3, [x2]
    5aec:	f9000fe3 	str	x3, [sp, #24]
    5af0:	d2800003 	mov	x3, #0x0                   	// #0
    5af4:	a9400c01 	ldp	x1, x3, [x0]
    5af8:	f9400802 	ldr	x2, [x0, #16]
    5afc:	ab020022 	adds	x2, x1, x2
    5b00:	54000726 	b.vs	5be4 <e173+0x114>
    5b04:	910023e1 	add	x1, sp, #0x8
    5b08:	52800000 	mov	w0, #0x0                   	// #0
    5b0c:	a9008be3 	stp	x3, x2, [sp, #8]
    5b10:	97fffc9d 	bl	4d84 <fwp_data.part.0.constprop.0>
    5b14:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5b18:	91150063 	add	x3, x3, #0x540
    5b1c:	aa0003f3 	mov	x19, x0
    5b20:	f949d861 	ldr	x1, [x3, #5040]
    5b24:	f949ec60 	ldr	x0, [x3, #5080]
    5b28:	cb010261 	sub	x1, x19, x1
    5b2c:	eb00403f 	cmp	x1, x0, lsl #16
    5b30:	54000322 	b.cs	5b94 <e173+0xc4>  // b.hs, b.nlast
    5b34:	d350fc22 	lsr	x2, x1, #16
    5b38:	f949fc63 	ldr	x3, [x3, #5112]
    5b3c:	8b020842 	add	x2, x2, x2, lsl #2
    5b40:	d37df042 	lsl	x2, x2, #3
    5b44:	8b020060 	add	x0, x3, x2
    5b48:	f9401014 	ldr	x20, [x0, #32]
    5b4c:	b4000254 	cbz	x20, 5b94 <e173+0xc4>
    5b50:	38626862 	ldrb	w2, [x3, x2]
    5b54:	7100085f 	cmp	w2, #0x2
    5b58:	540003a0 	b.eq	5bcc <e173+0xfc>  // b.none
    5b5c:	7100045f 	cmp	w2, #0x1
    5b60:	540001a1 	b.ne	5b94 <e173+0xc4>  // b.any
    5b64:	29430002 	ldp	w2, w0, [x0, #24]
    5b68:	92403c21 	and	x1, x1, #0xffff
    5b6c:	9b027c21 	mul	x1, x1, x2
    5b70:	d360fc21 	lsr	x1, x1, #32
    5b74:	eb00003f 	cmp	x1, x0
    5b78:	540000e2 	b.cs	5b94 <e173+0xc4>  // b.hs, b.nlast
    5b7c:	8b010294 	add	x20, x20, x1
    5b80:	39400280 	ldrb	w0, [x20]
    5b84:	7103fc1f 	cmp	w0, #0xff
    5b88:	54000280 	b.eq	5bd8 <e173+0x108>  // b.none
    5b8c:	52800020 	mov	w0, #0x1                   	// #1
    5b90:	39000280 	strb	w0, [x20]
    5b94:	aa1303e0 	mov	x0, x19
    5b98:	97fffeeb 	bl	5744 <fwp_rc_share>
    5b9c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ba0:	f947f400 	ldr	x0, [x0, #4072]
    5ba4:	f9400fe2 	ldr	x2, [sp, #24]
    5ba8:	f9400001 	ldr	x1, [x0]
    5bac:	eb010042 	subs	x2, x2, x1
    5bb0:	d2800001 	mov	x1, #0x0                   	// #0
    5bb4:	540001a1 	b.ne	5be8 <e173+0x118>  // b.any
    5bb8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bbc:	aa1303e0 	mov	x0, x19
    5bc0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5bc4:	910103ff 	add	sp, sp, #0x40
    5bc8:	d65f03c0 	ret
    5bcc:	72003c3f 	tst	w1, #0xffff
    5bd0:	54fffe21 	b.ne	5b94 <e173+0xc4>  // b.any
    5bd4:	17ffffeb 	b	5b80 <e173+0xb0>
    5bd8:	aa1403e0 	mov	x0, x20
    5bdc:	97fff8cd 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5be0:	17ffffeb 	b	5b8c <e173+0xbc>
    5be4:	97fff3a7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5be8:	97fff326 	bl	2880 <__stack_chk_fail@plt>
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_drop1>:
    5bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bf4:	910003fd 	mov	x29, sp
    5bf8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bfc:	f90013f5 	str	x21, [sp, #32]
    5c00:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5c04:	911502b4 	add	x20, x21, #0x540
    5c08:	f949da81 	ldr	x1, [x20, #5040]
    5c0c:	f949ee82 	ldr	x2, [x20, #5080]
    5c10:	cb010001 	sub	x1, x0, x1
    5c14:	eb02403f 	cmp	x1, x2, lsl #16
    5c18:	54000382 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c1c:	d350fc22 	lsr	x2, x1, #16
    5c20:	f949fe84 	ldr	x4, [x20, #5112]
    5c24:	8b020842 	add	x2, x2, x2, lsl #2
    5c28:	d37df042 	lsl	x2, x2, #3
    5c2c:	8b020083 	add	x3, x4, x2
    5c30:	f9401073 	ldr	x19, [x3, #32]
    5c34:	b40002b3 	cbz	x19, 5c88 <fwp_drop1+0x98>
    5c38:	38626882 	ldrb	w2, [x4, x2]
    5c3c:	7100085f 	cmp	w2, #0x2
    5c40:	540002c0 	b.eq	5c98 <fwp_drop1+0xa8>  // b.none
    5c44:	7100045f 	cmp	w2, #0x1
    5c48:	54000201 	b.ne	5c88 <fwp_drop1+0x98>  // b.any
    5c4c:	29430864 	ldp	w4, w2, [x3, #24]
    5c50:	92403c21 	and	x1, x1, #0xffff
    5c54:	9b047c21 	mul	x1, x1, x4
    5c58:	d360fc21 	lsr	x1, x1, #32
    5c5c:	eb02003f 	cmp	x1, x2
    5c60:	54000142 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c64:	8b010273 	add	x19, x19, x1
    5c68:	39400261 	ldrb	w1, [x19]
    5c6c:	340000e1 	cbz	w1, 5c88 <fwp_drop1+0x98>
    5c70:	7100043f 	cmp	w1, #0x1
    5c74:	540001e0 	b.eq	5cb0 <fwp_drop1+0xc0>  // b.none
    5c78:	7103fc3f 	cmp	w1, #0xff
    5c7c:	540002e0 	b.eq	5cd8 <fwp_drop1+0xe8>  // b.none
    5c80:	51000421 	sub	w1, w1, #0x1
    5c84:	39000261 	strb	w1, [x19]
    5c88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c8c:	f94013f5 	ldr	x21, [sp, #32]
    5c90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c94:	d65f03c0 	ret
    5c98:	72003c3f 	tst	w1, #0xffff
    5c9c:	54fffe60 	b.eq	5c68 <fwp_drop1+0x78>  // b.none
    5ca0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ca4:	f94013f5 	ldr	x21, [sp, #32]
    5ca8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cac:	d65f03c0 	ret
    5cb0:	f9400813 	ldr	x19, [x0, #16]
    5cb4:	97fffef8 	bl	5894 <fwp_rc_free_arr>
    5cb8:	911502a0 	add	x0, x21, #0x540
    5cbc:	f949d801 	ldr	x1, [x0, #5040]
    5cc0:	f949ec00 	ldr	x0, [x0, #5080]
    5cc4:	cb010261 	sub	x1, x19, x1
    5cc8:	eb00403f 	cmp	x1, x0, lsl #16
    5ccc:	54fffde2 	b.cs	5c88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cd0:	aa1303e0 	mov	x0, x19
    5cd4:	17ffffd2 	b	5c1c <fwp_drop1+0x2c>
    5cd8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cdc:	911502b5 	add	x21, x21, #0x540
    5ce0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ce4:	92401c00 	and	x0, x0, #0xff
    5ce8:	910a2402 	add	x2, x0, #0x289
    5cec:	8b000ea0 	add	x0, x21, x0, lsl #3
    5cf0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5cf4:	f94a2400 	ldr	x0, [x0, #5192]
    5cf8:	b50000a0 	cbnz	x0, 5d0c <fwp_drop1+0x11c>
    5cfc:	14000013 	b	5d48 <fwp_drop1+0x158>
    5d00:	91004002 	add	x2, x0, #0x10
    5d04:	f9400800 	ldr	x0, [x0, #16]
    5d08:	b4000200 	cbz	x0, 5d48 <fwp_drop1+0x158>
    5d0c:	f9400001 	ldr	x1, [x0]
    5d10:	eb13003f 	cmp	x1, x19
    5d14:	54ffff61 	b.ne	5d00 <fwp_drop1+0x110>  // b.any
    5d18:	f9400041 	ldr	x1, [x2]
    5d1c:	f9400420 	ldr	x0, [x1, #8]
    5d20:	d1000400 	sub	x0, x0, #0x1
    5d24:	f9000420 	str	x0, [x1, #8]
    5d28:	f103f81f 	cmp	x0, #0xfe
    5d2c:	54fffae1 	b.ne	5c88 <fwp_drop1+0x98>  // b.any
    5d30:	39400260 	ldrb	w0, [x19]
    5d34:	7103fc1f 	cmp	w0, #0xff
    5d38:	540000e0 	b.eq	5d54 <fwp_drop1+0x164>  // b.none
    5d3c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d40:	39000260 	strb	w0, [x19]
    5d44:	17ffffd1 	b	5c88 <fwp_drop1+0x98>
    5d48:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5d4c:	91090000 	add	x0, x0, #0x240
    5d50:	97fff850 	bl	3e90 <fwp_trap>
    5d54:	aa1303e0 	mov	x0, x19
    5d58:	97fff86e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5d5c:	17fffff8 	b	5d3c <fwp_drop1+0x14c>

0000000000005d60 <fwp_drop0>:
    5d60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d64:	910003fd 	mov	x29, sp
    5d68:	a90153f3 	stp	x19, x20, [sp, #16]
    5d6c:	f90013f5 	str	x21, [sp, #32]
    5d70:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5d74:	911502b4 	add	x20, x21, #0x540
    5d78:	f949da81 	ldr	x1, [x20, #5040]
    5d7c:	f949ee82 	ldr	x2, [x20, #5080]
    5d80:	cb010001 	sub	x1, x0, x1
    5d84:	eb02403f 	cmp	x1, x2, lsl #16
    5d88:	54000382 	b.cs	5df8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d8c:	d350fc22 	lsr	x2, x1, #16
    5d90:	f949fe84 	ldr	x4, [x20, #5112]
    5d94:	8b020842 	add	x2, x2, x2, lsl #2
    5d98:	d37df042 	lsl	x2, x2, #3
    5d9c:	8b020083 	add	x3, x4, x2
    5da0:	f9401073 	ldr	x19, [x3, #32]
    5da4:	b40002b3 	cbz	x19, 5df8 <fwp_drop0+0x98>
    5da8:	38626882 	ldrb	w2, [x4, x2]
    5dac:	7100085f 	cmp	w2, #0x2
    5db0:	540002c0 	b.eq	5e08 <fwp_drop0+0xa8>  // b.none
    5db4:	7100045f 	cmp	w2, #0x1
    5db8:	54000201 	b.ne	5df8 <fwp_drop0+0x98>  // b.any
    5dbc:	29430864 	ldp	w4, w2, [x3, #24]
    5dc0:	92403c21 	and	x1, x1, #0xffff
    5dc4:	9b047c21 	mul	x1, x1, x4
    5dc8:	d360fc21 	lsr	x1, x1, #32
    5dcc:	eb02003f 	cmp	x1, x2
    5dd0:	54000142 	b.cs	5df8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5dd4:	8b010273 	add	x19, x19, x1
    5dd8:	39400261 	ldrb	w1, [x19]
    5ddc:	340000e1 	cbz	w1, 5df8 <fwp_drop0+0x98>
    5de0:	7100043f 	cmp	w1, #0x1
    5de4:	540001e0 	b.eq	5e20 <fwp_drop0+0xc0>  // b.none
    5de8:	7103fc3f 	cmp	w1, #0xff
    5dec:	540002e0 	b.eq	5e48 <fwp_drop0+0xe8>  // b.none
    5df0:	51000421 	sub	w1, w1, #0x1
    5df4:	39000261 	strb	w1, [x19]
    5df8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dfc:	f94013f5 	ldr	x21, [sp, #32]
    5e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e04:	d65f03c0 	ret
    5e08:	72003c3f 	tst	w1, #0xffff
    5e0c:	54fffe60 	b.eq	5dd8 <fwp_drop0+0x78>  // b.none
    5e10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e14:	f94013f5 	ldr	x21, [sp, #32]
    5e18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e1c:	d65f03c0 	ret
    5e20:	f9400813 	ldr	x19, [x0, #16]
    5e24:	97fffe9c 	bl	5894 <fwp_rc_free_arr>
    5e28:	911502a0 	add	x0, x21, #0x540
    5e2c:	f949d801 	ldr	x1, [x0, #5040]
    5e30:	f949ec00 	ldr	x0, [x0, #5080]
    5e34:	cb010261 	sub	x1, x19, x1
    5e38:	eb00403f 	cmp	x1, x0, lsl #16
    5e3c:	54fffde2 	b.cs	5df8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e40:	aa1303e0 	mov	x0, x19
    5e44:	17ffffd2 	b	5d8c <fwp_drop0+0x2c>
    5e48:	ca534660 	eor	x0, x19, x19, lsr #17
    5e4c:	911502b5 	add	x21, x21, #0x540
    5e50:	ca402400 	eor	x0, x0, x0, lsr #9
    5e54:	92401c00 	and	x0, x0, #0xff
    5e58:	910a2402 	add	x2, x0, #0x289
    5e5c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e60:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e64:	f94a2400 	ldr	x0, [x0, #5192]
    5e68:	b50000a0 	cbnz	x0, 5e7c <fwp_drop0+0x11c>
    5e6c:	14000013 	b	5eb8 <fwp_drop0+0x158>
    5e70:	91004002 	add	x2, x0, #0x10
    5e74:	f9400800 	ldr	x0, [x0, #16]
    5e78:	b4000200 	cbz	x0, 5eb8 <fwp_drop0+0x158>
    5e7c:	f9400001 	ldr	x1, [x0]
    5e80:	eb13003f 	cmp	x1, x19
    5e84:	54ffff61 	b.ne	5e70 <fwp_drop0+0x110>  // b.any
    5e88:	f9400041 	ldr	x1, [x2]
    5e8c:	f9400420 	ldr	x0, [x1, #8]
    5e90:	d1000400 	sub	x0, x0, #0x1
    5e94:	f9000420 	str	x0, [x1, #8]
    5e98:	f103f81f 	cmp	x0, #0xfe
    5e9c:	54fffae1 	b.ne	5df8 <fwp_drop0+0x98>  // b.any
    5ea0:	39400260 	ldrb	w0, [x19]
    5ea4:	7103fc1f 	cmp	w0, #0xff
    5ea8:	540000e0 	b.eq	5ec4 <fwp_drop0+0x164>  // b.none
    5eac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5eb0:	39000260 	strb	w0, [x19]
    5eb4:	17ffffd1 	b	5df8 <fwp_drop0+0x98>
    5eb8:	90000040 	adrp	x0, d000 <__modti3+0x2a0>
    5ebc:	91090000 	add	x0, x0, #0x240
    5ec0:	97fff7f4 	bl	3e90 <fwp_trap>
    5ec4:	aa1303e0 	mov	x0, x19
    5ec8:	97fff812 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5ecc:	17fffff8 	b	5eac <fwp_drop0+0x14c>

0000000000005ed0 <fwp_closure_drop>:
    5ed0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5ed4:	911500a4 	add	x4, x5, #0x540
    5ed8:	aa0003e1 	mov	x1, x0
    5edc:	f949d882 	ldr	x2, [x4, #5040]
    5ee0:	f949ec80 	ldr	x0, [x4, #5080]
    5ee4:	cb020022 	sub	x2, x1, x2
    5ee8:	eb00405f 	cmp	x2, x0, lsl #16
    5eec:	54000662 	b.cs	5fb8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5ef0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ef4:	d350fc43 	lsr	x3, x2, #16
    5ef8:	910003fd 	mov	x29, sp
    5efc:	8b030863 	add	x3, x3, x3, lsl #2
    5f00:	f949fc84 	ldr	x4, [x4, #5112]
    5f04:	d37df063 	lsl	x3, x3, #3
    5f08:	f9000bf3 	str	x19, [sp, #16]
    5f0c:	8b030080 	add	x0, x4, x3
    5f10:	f9401013 	ldr	x19, [x0, #32]
    5f14:	b40002b3 	cbz	x19, 5f68 <fwp_closure_drop+0x98>
    5f18:	38636883 	ldrb	w3, [x4, x3]
    5f1c:	7100087f 	cmp	w3, #0x2
    5f20:	54000420 	b.eq	5fa4 <fwp_closure_drop+0xd4>  // b.none
    5f24:	7100047f 	cmp	w3, #0x1
    5f28:	54000201 	b.ne	5f68 <fwp_closure_drop+0x98>  // b.any
    5f2c:	29430003 	ldp	w3, w0, [x0, #24]
    5f30:	92403c42 	and	x2, x2, #0xffff
    5f34:	9b037c42 	mul	x2, x2, x3
    5f38:	d360fc42 	lsr	x2, x2, #32
    5f3c:	eb00005f 	cmp	x2, x0
    5f40:	54000142 	b.cs	5f68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5f44:	8b020273 	add	x19, x19, x2
    5f48:	39400260 	ldrb	w0, [x19]
    5f4c:	340000e0 	cbz	w0, 5f68 <fwp_closure_drop+0x98>
    5f50:	7100041f 	cmp	w0, #0x1
    5f54:	54000100 	b.eq	5f74 <fwp_closure_drop+0xa4>  // b.none
    5f58:	7103fc1f 	cmp	w0, #0xff
    5f5c:	54000300 	b.eq	5fbc <fwp_closure_drop+0xec>  // b.none
    5f60:	51000400 	sub	w0, w0, #0x1
    5f64:	39000260 	strb	w0, [x19]
    5f68:	f9400bf3 	ldr	x19, [sp, #16]
    5f6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f70:	d65f03c0 	ret
    5f74:	d53bd040 	mrs	x0, tpidr_el0
    5f78:	91400000 	add	x0, x0, #0x0, lsl #12
    5f7c:	91004000 	add	x0, x0, #0x10
    5f80:	f9400000 	ldr	x0, [x0]
    5f84:	b4000080 	cbz	x0, 5f94 <fwp_closure_drop+0xc4>
    5f88:	f9400bf3 	ldr	x19, [sp, #16]
    5f8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f90:	17fff93c 	b	4480 <fwp_closure_drop_push>
    5f94:	f9400bf3 	ldr	x19, [sp, #16]
    5f98:	aa0103e0 	mov	x0, x1
    5f9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fa0:	17fff97d 	b	4594 <fwp_closure_drop.part.0>
    5fa4:	72003c5f 	tst	w2, #0xffff
    5fa8:	54fffd00 	b.eq	5f48 <fwp_closure_drop+0x78>  // b.none
    5fac:	f9400bf3 	ldr	x19, [sp, #16]
    5fb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fb4:	d65f03c0 	ret
    5fb8:	d65f03c0 	ret
    5fbc:	ca534660 	eor	x0, x19, x19, lsr #17
    5fc0:	911500a5 	add	x5, x5, #0x540
    5fc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5fc8:	92401c00 	and	x0, x0, #0xff
    5fcc:	910a2402 	add	x2, x0, #0x289
    5fd0:	8b000ca0 	add	x0, x5, x0, lsl #3
    5fd4:	8b020ca2 	add	x2, x5, x2, lsl #3
    5fd8:	f94a2400 	ldr	x0, [x0, #5192]
    5fdc:	b50000a0 	cbnz	x0, 5ff0 <fwp_closure_drop+0x120>
    5fe0:	14000013 	b	602c <fwp_closure_drop+0x15c>
    5fe4:	91004002 	add	x2, x0, #0x10
    5fe8:	f9400800 	ldr	x0, [x0, #16]
    5fec:	b4000200 	cbz	x0, 602c <fwp_closure_drop+0x15c>
    5ff0:	f9400001 	ldr	x1, [x0]
    5ff4:	eb13003f 	cmp	x1, x19
    5ff8:	54ffff61 	b.ne	5fe4 <fwp_closure_drop+0x114>  // b.any
    5ffc:	f9400041 	ldr	x1, [x2]
    6000:	f9400420 	ldr	x0, [x1, #8]
    6004:	d1000400 	sub	x0, x0, #0x1
    6008:	f9000420 	str	x0, [x1, #8]
    600c:	f103f81f 	cmp	x0, #0xfe
    6010:	54fffac1 	b.ne	5f68 <fwp_closure_drop+0x98>  // b.any
    6014:	39400260 	ldrb	w0, [x19]
    6018:	7103fc1f 	cmp	w0, #0xff
    601c:	540000e0 	b.eq	6038 <fwp_closure_drop+0x168>  // b.none
    6020:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6024:	39000260 	strb	w0, [x19]
    6028:	17ffffd0 	b	5f68 <fwp_closure_drop+0x98>
    602c:	f0000020 	adrp	x0, d000 <__modti3+0x2a0>
    6030:	91090000 	add	x0, x0, #0x240
    6034:	97fff797 	bl	3e90 <fwp_trap>
    6038:	aa1303e0 	mov	x0, x19
    603c:	97fff7b5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6040:	17fffff8 	b	6020 <fwp_closure_drop+0x150>

0000000000006044 <fwp_owned_tape_release>:
    6044:	b4000920 	cbz	x0, 6168 <fwp_owned_tape_release+0x124>
    6048:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    604c:	910003fd 	mov	x29, sp
    6050:	a90153f3 	stp	x19, x20, [sp, #16]
    6054:	aa0003f3 	mov	x19, x0
    6058:	f9400000 	ldr	x0, [x0]
    605c:	b4000060 	cbz	x0, 6068 <fwp_owned_tape_release+0x24>
    6060:	f9400661 	ldr	x1, [x19, #8]
    6064:	f9000401 	str	x1, [x0, #8]
    6068:	f9400661 	ldr	x1, [x19, #8]
    606c:	b4000041 	cbz	x1, 6074 <fwp_owned_tape_release+0x30>
    6070:	f9000020 	str	x0, [x1]
    6074:	f9400a60 	ldr	x0, [x19, #16]
    6078:	f9403401 	ldr	x1, [x0, #104]
    607c:	b40005a1 	cbz	x1, 6130 <fwp_owned_tape_release+0xec>
    6080:	a9450a60 	ldp	x0, x2, [x19, #80]
    6084:	eb00005f 	cmp	x2, x0
    6088:	540002cd 	b.le	60e0 <fwp_owned_tape_release+0x9c>
    608c:	d2800014 	mov	x20, #0x0                   	// #0
    6090:	f90013f5 	str	x21, [sp, #32]
    6094:	d2800015 	mov	x21, #0x0                   	// #0
    6098:	f9402260 	ldr	x0, [x19, #64]
    609c:	910006b5 	add	x21, x21, #0x1
    60a0:	f8746800 	ldr	x0, [x0, x20]
    60a4:	d63f0020 	blr	x1
    60a8:	f9402260 	ldr	x0, [x19, #64]
    60ac:	f9400a61 	ldr	x1, [x19, #16]
    60b0:	8b140000 	add	x0, x0, x20
    60b4:	91004294 	add	x20, x20, #0x10
    60b8:	f9400400 	ldr	x0, [x0, #8]
    60bc:	f9403421 	ldr	x1, [x1, #104]
    60c0:	d63f0020 	blr	x1
    60c4:	a9450261 	ldp	x1, x0, [x19, #80]
    60c8:	cb010000 	sub	x0, x0, x1
    60cc:	eb15001f 	cmp	x0, x21
    60d0:	f9400a60 	ldr	x0, [x19, #16]
    60d4:	f9403401 	ldr	x1, [x0, #104]
    60d8:	54fffe0c 	b.gt	6098 <fwp_owned_tape_release+0x54>
    60dc:	f94013f5 	ldr	x21, [sp, #32]
    60e0:	f9403663 	ldr	x3, [x19, #104]
    60e4:	f9401262 	ldr	x2, [x19, #32]
    60e8:	f100007f 	cmp	x3, #0x0
    60ec:	540001ed 	b.le	6128 <fwp_owned_tape_release+0xe4>
    60f0:	d2800014 	mov	x20, #0x0                   	// #0
    60f4:	d503201f 	nop
    60f8:	f9402660 	ldr	x0, [x19, #72]
    60fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6100:	eb02001f 	cmp	x0, x2
    6104:	540000c0 	b.eq	611c <fwp_owned_tape_release+0xd8>  // b.none
    6108:	d63f0020 	blr	x1
    610c:	f9400a60 	ldr	x0, [x19, #16]
    6110:	f9401262 	ldr	x2, [x19, #32]
    6114:	f9403663 	ldr	x3, [x19, #104]
    6118:	f9403401 	ldr	x1, [x0, #104]
    611c:	91000694 	add	x20, x20, #0x1
    6120:	eb14007f 	cmp	x3, x20
    6124:	54fffeac 	b.gt	60f8 <fwp_owned_tape_release+0xb4>
    6128:	aa0203e0 	mov	x0, x2
    612c:	d63f0020 	blr	x1
    6130:	f9401660 	ldr	x0, [x19, #40]
    6134:	97ffff67 	bl	5ed0 <fwp_closure_drop>
    6138:	f9401a60 	ldr	x0, [x19, #48]
    613c:	97ffff65 	bl	5ed0 <fwp_closure_drop>
    6140:	f9401e60 	ldr	x0, [x19, #56]
    6144:	97ffff63 	bl	5ed0 <fwp_closure_drop>
    6148:	f9402260 	ldr	x0, [x19, #64]
    614c:	97fff80d 	bl	4180 <fwp_mem_free>
    6150:	f9402660 	ldr	x0, [x19, #72]
    6154:	97fff80b 	bl	4180 <fwp_mem_free>
    6158:	aa1303e0 	mov	x0, x19
    615c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6164:	17fff807 	b	4180 <fwp_mem_free>
    6168:	d65f03c0 	ret
    616c:	d503201f 	nop

0000000000006170 <fwp_tape_finish>:
    6170:	d10203ff 	sub	sp, sp, #0x80
    6174:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6178:	f947f421 	ldr	x1, [x1, #4072]
    617c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6180:	910103fd 	add	x29, sp, #0x40
    6184:	a90553f3 	stp	x19, x20, [sp, #80]
    6188:	a9065bf5 	stp	x21, x22, [sp, #96]
    618c:	a90763f7 	stp	x23, x24, [sp, #112]
    6190:	d00000d8 	adrp	x24, 20000 <__data_start>
    6194:	9100c316 	add	x22, x24, #0x30
    6198:	f9400022 	ldr	x2, [x1]
    619c:	f9001fe2 	str	x2, [sp, #56]
    61a0:	d2800002 	mov	x2, #0x0                   	// #0
    61a4:	9100e2c0 	add	x0, x22, #0x38
    61a8:	97fff456 	bl	3300 <fwp_tape_buffers_dispose>
    61ac:	f9003adf 	str	xzr, [x22, #112]
    61b0:	f94042c0 	ldr	x0, [x22, #128]
    61b4:	f100001f 	cmp	x0, #0x0
    61b8:	5400030d 	b.le	6218 <fwp_tape_finish+0xa8>
    61bc:	910003f7 	mov	x23, sp
    61c0:	d2800015 	mov	x21, #0x0                   	// #0
    61c4:	d2800014 	mov	x20, #0x0                   	// #0
    61c8:	f94002d3 	ldr	x19, [x22]
    61cc:	91000694 	add	x20, x20, #0x1
    61d0:	8b150273 	add	x19, x19, x21
    61d4:	9101a2b5 	add	x21, x21, #0x68
    61d8:	aa1303e0 	mov	x0, x19
    61dc:	97fff36d 	bl	2f90 <fwp_tape_unlink_scope>
    61e0:	aa1703e0 	mov	x0, x23
    61e4:	f9401261 	ldr	x1, [x19, #32]
    61e8:	f90003e1 	str	x1, [sp]
    61ec:	f9401a62 	ldr	x2, [x19, #48]
    61f0:	f9000be2 	str	x2, [sp, #16]
    61f4:	f9402261 	ldr	x1, [x19, #64]
    61f8:	f90013e1 	str	x1, [sp, #32]
    61fc:	97fff441 	bl	3300 <fwp_tape_buffers_dispose>
    6200:	f9403260 	ldr	x0, [x19, #96]
    6204:	97ffff90 	bl	6044 <fwp_owned_tape_release>
    6208:	f900327f 	str	xzr, [x19, #96]
    620c:	f94042c0 	ldr	x0, [x22, #128]
    6210:	eb14001f 	cmp	x0, x20
    6214:	54fffdac 	b.gt	61c8 <fwp_tape_finish+0x58>
    6218:	f9401b00 	ldr	x0, [x24, #48]
    621c:	9100c313 	add	x19, x24, #0x30
    6220:	97fff1c8 	bl	2940 <free@plt>
    6224:	f9001b1f 	str	xzr, [x24, #48]
    6228:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    622c:	f947f400 	ldr	x0, [x0, #4072]
    6230:	f900427f 	str	xzr, [x19, #128]
    6234:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6238:	f9401fe2 	ldr	x2, [sp, #56]
    623c:	f9400001 	ldr	x1, [x0]
    6240:	eb010042 	subs	x2, x2, x1
    6244:	d2800001 	mov	x1, #0x0                   	// #0
    6248:	540000e1 	b.ne	6264 <fwp_tape_finish+0xf4>  // b.any
    624c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6250:	a94553f3 	ldp	x19, x20, [sp, #80]
    6254:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6258:	a94763f7 	ldp	x23, x24, [sp, #112]
    625c:	910203ff 	add	sp, sp, #0x80
    6260:	d65f03c0 	ret
    6264:	97fff187 	bl	2880 <__stack_chk_fail@plt>
    6268:	d503201f 	nop
    626c:	d503201f 	nop

0000000000006270 <fwp_tape_scope_release>:
    6270:	d10243ff 	sub	sp, sp, #0x90
    6274:	a9047bfd 	stp	x29, x30, [sp, #64]
    6278:	910103fd 	add	x29, sp, #0x40
    627c:	a90553f3 	stp	x19, x20, [sp, #80]
    6280:	aa0003f4 	mov	x20, x0
    6284:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6288:	f947f400 	ldr	x0, [x0, #4072]
    628c:	b9400285 	ldr	w5, [x20]
    6290:	f9400001 	ldr	x1, [x0]
    6294:	f9001fe1 	str	x1, [sp, #56]
    6298:	d2800001 	mov	x1, #0x0                   	// #0
    629c:	37f806c5 	tbnz	w5, #31, 6374 <fwp_tape_scope_release+0x104>
    62a0:	a90763f7 	stp	x23, x24, [sp, #112]
    62a4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    62a8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    62ac:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    62b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    62b4:	910003f7 	mov	x23, sp
    62b8:	9100c273 	add	x19, x19, #0x30
    62bc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    62c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    62c4:	52800d16 	mov	w22, #0x68                  	// #104
    62c8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    62cc:	f90043f9 	str	x25, [sp, #128]
    62d0:	14000006 	b	62e8 <fwp_tape_scope_release+0x78>
    62d4:	97fff40b 	bl	3300 <fwp_tape_buffers_dispose>
    62d8:	aa1903e0 	mov	x0, x25
    62dc:	97ffff5a 	bl	6044 <fwp_owned_tape_release>
    62e0:	b9400285 	ldr	w5, [x20]
    62e4:	37f80425 	tbnz	w5, #31, 6368 <fwp_tape_scope_release+0xf8>
    62e8:	f9400266 	ldr	x6, [x19]
    62ec:	9b367ca5 	smull	x5, w5, w22
    62f0:	8b0500c0 	add	x0, x6, x5
    62f4:	97fff327 	bl	2f90 <fwp_tape_unlink_scope>
    62f8:	ad410001 	ldp	q1, q0, [x0, #32]
    62fc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6300:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6304:	f9400c03 	ldr	x3, [x0, #24]
    6308:	ad0003e1 	stp	q1, q0, [sp]
    630c:	b86568c1 	ldr	w1, [x6, x5]
    6310:	a9440804 	ldp	x4, x2, [x0, #64]
    6314:	b900041f 	str	wzr, [x0, #4]
    6318:	f9403019 	ldr	x25, [x0, #96]
    631c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6320:	f9000c1f 	str	xzr, [x0, #24]
    6324:	a9020fe4 	stp	x4, x3, [sp, #32]
    6328:	f9001be2 	str	x2, [sp, #48]
    632c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6330:	f900301f 	str	xzr, [x0, #96]
    6334:	6b15003f 	cmp	w1, w21
    6338:	540000e8 	b.hi	6354 <fwp_tape_scope_release+0xe4>  // b.pmore
    633c:	9343fca5 	asr	x5, x5, #3
    6340:	f9404e60 	ldr	x0, [x19, #152]
    6344:	9b187ca5 	mul	x5, x5, x24
    6348:	eb0000bf 	cmp	x5, x0
    634c:	5400004a 	b.ge	6354 <fwp_tape_scope_release+0xe4>  // b.tcont
    6350:	f9004e65 	str	x5, [x19, #152]
    6354:	aa1703e0 	mov	x0, x23
    6358:	b5fffbf9 	cbnz	x25, 62d4 <fwp_tape_scope_release+0x64>
    635c:	97fff685 	bl	3d70 <fwp_tape_buffers_release>
    6360:	b9400285 	ldr	w5, [x20]
    6364:	36fffc25 	tbz	w5, #31, 62e8 <fwp_tape_scope_release+0x78>
    6368:	a9465bf5 	ldp	x21, x22, [sp, #96]
    636c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6370:	f94043f9 	ldr	x25, [sp, #128]
    6374:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6378:	f947f400 	ldr	x0, [x0, #4072]
    637c:	f9401fe2 	ldr	x2, [sp, #56]
    6380:	f9400001 	ldr	x1, [x0]
    6384:	eb010042 	subs	x2, x2, x1
    6388:	d2800001 	mov	x1, #0x0                   	// #0
    638c:	540000a1 	b.ne	63a0 <fwp_tape_scope_release+0x130>  // b.any
    6390:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6394:	a94553f3 	ldp	x19, x20, [sp, #80]
    6398:	910243ff 	add	sp, sp, #0x90
    639c:	d65f03c0 	ret
    63a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63a4:	a90763f7 	stp	x23, x24, [sp, #112]
    63a8:	f90043f9 	str	x25, [sp, #128]
    63ac:	97fff135 	bl	2880 <__stack_chk_fail@plt>

00000000000063b0 <fwp_drop4>:
    63b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    63b4:	910003fd 	mov	x29, sp
    63b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    63bc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    63c0:	911502d5 	add	x21, x22, #0x540
    63c4:	a90153f3 	stp	x19, x20, [sp, #16]
    63c8:	aa0003f3 	mov	x19, x0
    63cc:	f949daa1 	ldr	x1, [x21, #5040]
    63d0:	f949eea0 	ldr	x0, [x21, #5080]
    63d4:	cb010261 	sub	x1, x19, x1
    63d8:	eb00403f 	cmp	x1, x0, lsl #16
    63dc:	54000382 	b.cs	644c <fwp_drop4+0x9c>  // b.hs, b.nlast
    63e0:	d350fc22 	lsr	x2, x1, #16
    63e4:	f949fea3 	ldr	x3, [x21, #5112]
    63e8:	8b020842 	add	x2, x2, x2, lsl #2
    63ec:	d37df042 	lsl	x2, x2, #3
    63f0:	8b020060 	add	x0, x3, x2
    63f4:	f9401014 	ldr	x20, [x0, #32]
    63f8:	b40002b4 	cbz	x20, 644c <fwp_drop4+0x9c>
    63fc:	38626862 	ldrb	w2, [x3, x2]
    6400:	7100085f 	cmp	w2, #0x2
    6404:	540002c0 	b.eq	645c <fwp_drop4+0xac>  // b.none
    6408:	7100045f 	cmp	w2, #0x1
    640c:	54000201 	b.ne	644c <fwp_drop4+0x9c>  // b.any
    6410:	29430002 	ldp	w2, w0, [x0, #24]
    6414:	92403c21 	and	x1, x1, #0xffff
    6418:	9b027c21 	mul	x1, x1, x2
    641c:	d360fc21 	lsr	x1, x1, #32
    6420:	eb00003f 	cmp	x1, x0
    6424:	54000142 	b.cs	644c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6428:	8b010294 	add	x20, x20, x1
    642c:	39400280 	ldrb	w0, [x20]
    6430:	340000e0 	cbz	w0, 644c <fwp_drop4+0x9c>
    6434:	7100041f 	cmp	w0, #0x1
    6438:	540001e0 	b.eq	6474 <fwp_drop4+0xc4>  // b.none
    643c:	7103fc1f 	cmp	w0, #0xff
    6440:	540007c0 	b.eq	6538 <fwp_drop4+0x188>  // b.none
    6444:	51000400 	sub	w0, w0, #0x1
    6448:	39000280 	strb	w0, [x20]
    644c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6450:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6454:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6458:	d65f03c0 	ret
    645c:	72003c3f 	tst	w1, #0xffff
    6460:	54fffe60 	b.eq	642c <fwp_drop4+0x7c>  // b.none
    6464:	a94153f3 	ldp	x19, x20, [sp, #16]
    6468:	a9425bf5 	ldp	x21, x22, [sp, #32]
    646c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6470:	d65f03c0 	ret
    6474:	911502c2 	add	x2, x22, #0x540
    6478:	f9400660 	ldr	x0, [x19, #8]
    647c:	f949d841 	ldr	x1, [x2, #5040]
    6480:	f949ec42 	ldr	x2, [x2, #5080]
    6484:	cb010001 	sub	x1, x0, x1
    6488:	eb02403f 	cmp	x1, x2, lsl #16
    648c:	54000362 	b.cs	64f8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6490:	d350fc22 	lsr	x2, x1, #16
    6494:	8b020842 	add	x2, x2, x2, lsl #2
    6498:	d37df042 	lsl	x2, x2, #3
    649c:	8b020064 	add	x4, x3, x2
    64a0:	f9401094 	ldr	x20, [x4, #32]
    64a4:	b40002b4 	cbz	x20, 64f8 <fwp_drop4+0x148>
    64a8:	38626862 	ldrb	w2, [x3, x2]
    64ac:	7100085f 	cmp	w2, #0x2
    64b0:	540003e0 	b.eq	652c <fwp_drop4+0x17c>  // b.none
    64b4:	7100045f 	cmp	w2, #0x1
    64b8:	54000201 	b.ne	64f8 <fwp_drop4+0x148>  // b.any
    64bc:	29430883 	ldp	w3, w2, [x4, #24]
    64c0:	92403c21 	and	x1, x1, #0xffff
    64c4:	9b037c21 	mul	x1, x1, x3
    64c8:	d360fc21 	lsr	x1, x1, #32
    64cc:	eb02003f 	cmp	x1, x2
    64d0:	54000142 	b.cs	64f8 <fwp_drop4+0x148>  // b.hs, b.nlast
    64d4:	8b010294 	add	x20, x20, x1
    64d8:	39400281 	ldrb	w1, [x20]
    64dc:	340000e1 	cbz	w1, 64f8 <fwp_drop4+0x148>
    64e0:	7100043f 	cmp	w1, #0x1
    64e4:	54000200 	b.eq	6524 <fwp_drop4+0x174>  // b.none
    64e8:	7103fc3f 	cmp	w1, #0xff
    64ec:	54000640 	b.eq	65b4 <fwp_drop4+0x204>  // b.none
    64f0:	51000421 	sub	w1, w1, #0x1
    64f4:	39000281 	strb	w1, [x20]
    64f8:	f9400a74 	ldr	x20, [x19, #16]
    64fc:	aa1303e0 	mov	x0, x19
    6500:	97fffce5 	bl	5894 <fwp_rc_free_arr>
    6504:	911502c0 	add	x0, x22, #0x540
    6508:	f949d801 	ldr	x1, [x0, #5040]
    650c:	f949ec00 	ldr	x0, [x0, #5080]
    6510:	cb010281 	sub	x1, x20, x1
    6514:	eb00403f 	cmp	x1, x0, lsl #16
    6518:	54fff9a2 	b.cs	644c <fwp_drop4+0x9c>  // b.hs, b.nlast
    651c:	aa1403f3 	mov	x19, x20
    6520:	17ffffb0 	b	63e0 <fwp_drop4+0x30>
    6524:	97fffcdc 	bl	5894 <fwp_rc_free_arr>
    6528:	17fffff4 	b	64f8 <fwp_drop4+0x148>
    652c:	72003c3f 	tst	w1, #0xffff
    6530:	54fffe41 	b.ne	64f8 <fwp_drop4+0x148>  // b.any
    6534:	17ffffe9 	b	64d8 <fwp_drop4+0x128>
    6538:	ca544681 	eor	x1, x20, x20, lsr #17
    653c:	911502c0 	add	x0, x22, #0x540
    6540:	ca412421 	eor	x1, x1, x1, lsr #9
    6544:	92401c21 	and	x1, x1, #0xff
    6548:	910a2422 	add	x2, x1, #0x289
    654c:	8b010c01 	add	x1, x0, x1, lsl #3
    6550:	8b020c02 	add	x2, x0, x2, lsl #3
    6554:	f94a2420 	ldr	x0, [x1, #5192]
    6558:	b50000a0 	cbnz	x0, 656c <fwp_drop4+0x1bc>
    655c:	14000013 	b	65a8 <fwp_drop4+0x1f8>
    6560:	91004002 	add	x2, x0, #0x10
    6564:	f9400800 	ldr	x0, [x0, #16]
    6568:	b4000200 	cbz	x0, 65a8 <fwp_drop4+0x1f8>
    656c:	f9400001 	ldr	x1, [x0]
    6570:	eb14003f 	cmp	x1, x20
    6574:	54ffff61 	b.ne	6560 <fwp_drop4+0x1b0>  // b.any
    6578:	f9400041 	ldr	x1, [x2]
    657c:	f9400420 	ldr	x0, [x1, #8]
    6580:	d1000400 	sub	x0, x0, #0x1
    6584:	f9000420 	str	x0, [x1, #8]
    6588:	f103f81f 	cmp	x0, #0xfe
    658c:	54fff601 	b.ne	644c <fwp_drop4+0x9c>  // b.any
    6590:	39400280 	ldrb	w0, [x20]
    6594:	7103fc1f 	cmp	w0, #0xff
    6598:	54000460 	b.eq	6624 <fwp_drop4+0x274>  // b.none
    659c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65a0:	39000280 	strb	w0, [x20]
    65a4:	17ffffaa 	b	644c <fwp_drop4+0x9c>
    65a8:	f0000020 	adrp	x0, d000 <__modti3+0x2a0>
    65ac:	91090000 	add	x0, x0, #0x240
    65b0:	97fff638 	bl	3e90 <fwp_trap>
    65b4:	ca544680 	eor	x0, x20, x20, lsr #17
    65b8:	911502c1 	add	x1, x22, #0x540
    65bc:	ca402400 	eor	x0, x0, x0, lsr #9
    65c0:	92401c00 	and	x0, x0, #0xff
    65c4:	910a2402 	add	x2, x0, #0x289
    65c8:	8b000c20 	add	x0, x1, x0, lsl #3
    65cc:	8b020c22 	add	x2, x1, x2, lsl #3
    65d0:	f94a2400 	ldr	x0, [x0, #5192]
    65d4:	b50000a0 	cbnz	x0, 65e8 <fwp_drop4+0x238>
    65d8:	17fffff4 	b	65a8 <fwp_drop4+0x1f8>
    65dc:	91004002 	add	x2, x0, #0x10
    65e0:	f9400800 	ldr	x0, [x0, #16]
    65e4:	b4fffe20 	cbz	x0, 65a8 <fwp_drop4+0x1f8>
    65e8:	f9400001 	ldr	x1, [x0]
    65ec:	eb14003f 	cmp	x1, x20
    65f0:	54ffff61 	b.ne	65dc <fwp_drop4+0x22c>  // b.any
    65f4:	f9400041 	ldr	x1, [x2]
    65f8:	f9400420 	ldr	x0, [x1, #8]
    65fc:	d1000400 	sub	x0, x0, #0x1
    6600:	f9000420 	str	x0, [x1, #8]
    6604:	f103f81f 	cmp	x0, #0xfe
    6608:	54fff781 	b.ne	64f8 <fwp_drop4+0x148>  // b.any
    660c:	39400280 	ldrb	w0, [x20]
    6610:	7103fc1f 	cmp	w0, #0xff
    6614:	540000e0 	b.eq	6630 <fwp_drop4+0x280>  // b.none
    6618:	12800020 	mov	w0, #0xfffffffe            	// #-2
    661c:	39000280 	strb	w0, [x20]
    6620:	17ffffb6 	b	64f8 <fwp_drop4+0x148>
    6624:	aa1403e0 	mov	x0, x20
    6628:	97fff63a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    662c:	17ffffdc 	b	659c <fwp_drop4+0x1ec>
    6630:	aa1403e0 	mov	x0, x20
    6634:	97fff637 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6638:	17fffff8 	b	6618 <fwp_drop4+0x268>
    663c:	d503201f 	nop

0000000000006640 <fwp_arg_drop37>:
    6640:	7100003f 	cmp	w1, #0x0
    6644:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6648:	54000041 	b.ne	6650 <fwp_arg_drop37+0x10>  // b.any
    664c:	d65f03c0 	ret
    6650:	f9400000 	ldr	x0, [x0]
    6654:	17ffff57 	b	63b0 <fwp_drop4>
    6658:	d503201f 	nop
    665c:	d503201f 	nop

0000000000006660 <fwp_task_dispose>:
    6660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6664:	910003fd 	mov	x29, sp
    6668:	f9000bf3 	str	x19, [sp, #16]
    666c:	aa0003f3 	mov	x19, x0
    6670:	39414000 	ldrb	w0, [x0, #80]
    6674:	36000720 	tbz	w0, #0, 6758 <fwp_task_dispose+0xf8>
    6678:	f9400a60 	ldr	x0, [x19, #16]
    667c:	b50006e0 	cbnz	x0, 6758 <fwp_task_dispose+0xf8>
    6680:	a9478660 	ldp	x0, x1, [x19, #120]
    6684:	39014e7f 	strb	wzr, [x19, #83]
    6688:	f9003e7f 	str	xzr, [x19, #120]
    668c:	f100003f 	cmp	x1, #0x0
    6690:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6694:	54000040 	b.eq	669c <fwp_task_dispose+0x3c>  // b.none
    6698:	d63f0020 	blr	x1
    669c:	f9405660 	ldr	x0, [x19, #168]
    66a0:	97fff6b8 	bl	4180 <fwp_mem_free>
    66a4:	f900567f 	str	xzr, [x19, #168]
    66a8:	b9405e60 	ldr	w0, [x19, #92]
    66ac:	7100041f 	cmp	w0, #0x1
    66b0:	54000420 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    66b4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    66b8:	91150042 	add	x2, x2, #0x540
    66bc:	f949d840 	ldr	x0, [x2, #5040]
    66c0:	f949ec41 	ldr	x1, [x2, #5080]
    66c4:	cb000260 	sub	x0, x19, x0
    66c8:	eb01401f 	cmp	x0, x1, lsl #16
    66cc:	540002e2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66d0:	d350fc01 	lsr	x1, x0, #16
    66d4:	f949fc44 	ldr	x4, [x2, #5112]
    66d8:	8b010821 	add	x1, x1, x1, lsl #2
    66dc:	d37df021 	lsl	x1, x1, #3
    66e0:	8b010083 	add	x3, x4, x1
    66e4:	f9401062 	ldr	x2, [x3, #32]
    66e8:	b4000202 	cbz	x2, 6728 <fwp_task_dispose+0xc8>
    66ec:	38616881 	ldrb	w1, [x4, x1]
    66f0:	7100083f 	cmp	w1, #0x2
    66f4:	54000280 	b.eq	6744 <fwp_task_dispose+0xe4>  // b.none
    66f8:	7100043f 	cmp	w1, #0x1
    66fc:	54000161 	b.ne	6728 <fwp_task_dispose+0xc8>  // b.any
    6700:	29430464 	ldp	w4, w1, [x3, #24]
    6704:	92403c00 	and	x0, x0, #0xffff
    6708:	9b047c00 	mul	x0, x0, x4
    670c:	d360fc00 	lsr	x0, x0, #32
    6710:	eb01001f 	cmp	x0, x1
    6714:	540000a2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6718:	8b000042 	add	x2, x2, x0
    671c:	39400040 	ldrb	w0, [x2]
    6720:	7100041f 	cmp	w0, #0x1
    6724:	54000080 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    6728:	f9400bf3 	ldr	x19, [sp, #16]
    672c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6730:	d65f03c0 	ret
    6734:	aa1303e0 	mov	x0, x19
    6738:	f9400bf3 	ldr	x19, [sp, #16]
    673c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6740:	17fff690 	b	4180 <fwp_mem_free>
    6744:	72003c1f 	tst	w0, #0xffff
    6748:	54fffea0 	b.eq	671c <fwp_task_dispose+0xbc>  // b.none
    674c:	f9400bf3 	ldr	x19, [sp, #16]
    6750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6754:	d65f03c0 	ret
    6758:	97fff05e 	bl	28d0 <abort@plt>
    675c:	d503201f 	nop

0000000000006760 <fwp_free_zombie>:
    6760:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6764:	910003fd 	mov	x29, sp
    6768:	a90153f3 	stp	x19, x20, [sp, #16]
    676c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6770:	9100c281 	add	x1, x20, #0x30
    6774:	f9405033 	ldr	x19, [x1, #160]
    6778:	b4000333 	cbz	x19, 67dc <fwp_free_zombie+0x7c>
    677c:	f9400820 	ldr	x0, [x1, #16]
    6780:	eb00027f 	cmp	x19, x0
    6784:	540002c0 	b.eq	67dc <fwp_free_zombie+0x7c>  // b.none
    6788:	b940a822 	ldr	w2, [x1, #168]
    678c:	f9400a60 	ldr	x0, [x19, #16]
    6790:	7100fc5f 	cmp	w2, #0x3f
    6794:	5400078c 	b.gt	6884 <fwp_free_zombie+0x124>
    6798:	9102c023 	add	x3, x1, #0xb0
    679c:	11000444 	add	w4, w2, #0x1
    67a0:	b900a824 	str	w4, [x1, #168]
    67a4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67a8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67ac:	a9530261 	ldp	x1, x0, [x19, #304]
    67b0:	b4000741 	cbz	x1, 6898 <fwp_free_zombie+0x138>
    67b4:	f9009c20 	str	x0, [x1, #312]
    67b8:	b4000040 	cbz	x0, 67c0 <fwp_free_zombie+0x60>
    67bc:	f9009801 	str	x1, [x0, #304]
    67c0:	9100c294 	add	x20, x20, #0x30
    67c4:	b9405e60 	ldr	w0, [x19, #92]
    67c8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67cc:	f900529f 	str	xzr, [x20, #160]
    67d0:	34000140 	cbz	w0, 67f8 <fwp_free_zombie+0x98>
    67d4:	7100041f 	cmp	w0, #0x1
    67d8:	54000080 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    67dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67e4:	d65f03c0 	ret
    67e8:	aa1303e0 	mov	x0, x19
    67ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f4:	17ffff9b 	b	6660 <fwp_task_dispose>
    67f8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    67fc:	91150082 	add	x2, x4, #0x540
    6800:	f949d841 	ldr	x1, [x2, #5040]
    6804:	f949ec40 	ldr	x0, [x2, #5080]
    6808:	cb010261 	sub	x1, x19, x1
    680c:	eb00403f 	cmp	x1, x0, lsl #16
    6810:	54fffe62 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6814:	d350fc20 	lsr	x0, x1, #16
    6818:	f949fc43 	ldr	x3, [x2, #5112]
    681c:	8b000800 	add	x0, x0, x0, lsl #2
    6820:	d37df000 	lsl	x0, x0, #3
    6824:	8b000062 	add	x2, x3, x0
    6828:	f9401054 	ldr	x20, [x2, #32]
    682c:	b4fffd94 	cbz	x20, 67dc <fwp_free_zombie+0x7c>
    6830:	38606860 	ldrb	w0, [x3, x0]
    6834:	7100081f 	cmp	w0, #0x2
    6838:	54000360 	b.eq	68a4 <fwp_free_zombie+0x144>  // b.none
    683c:	7100041f 	cmp	w0, #0x1
    6840:	54fffce1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    6844:	29430043 	ldp	w3, w0, [x2, #24]
    6848:	92403c21 	and	x1, x1, #0xffff
    684c:	9b037c21 	mul	x1, x1, x3
    6850:	d360fc21 	lsr	x1, x1, #32
    6854:	eb00003f 	cmp	x1, x0
    6858:	54fffc22 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    685c:	8b010294 	add	x20, x20, x1
    6860:	39400280 	ldrb	w0, [x20]
    6864:	34fffbc0 	cbz	w0, 67dc <fwp_free_zombie+0x7c>
    6868:	7100041f 	cmp	w0, #0x1
    686c:	54fffbe0 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    6870:	7103fc1f 	cmp	w0, #0xff
    6874:	540001e0 	b.eq	68b0 <fwp_free_zombie+0x150>  // b.none
    6878:	51000400 	sub	w0, w0, #0x1
    687c:	39000280 	strb	w0, [x20]
    6880:	17ffffd7 	b	67dc <fwp_free_zombie+0x7c>
    6884:	f9400e61 	ldr	x1, [x19, #24]
    6888:	97fff046 	bl	29a0 <munmap@plt>
    688c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6890:	a9530261 	ldp	x1, x0, [x19, #304]
    6894:	b5fff901 	cbnz	x1, 67b4 <fwp_free_zombie+0x54>
    6898:	9100c282 	add	x2, x20, #0x30
    689c:	f9015840 	str	x0, [x2, #688]
    68a0:	17ffffc6 	b	67b8 <fwp_free_zombie+0x58>
    68a4:	72003c3f 	tst	w1, #0xffff
    68a8:	54fff9a1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    68ac:	17ffffed 	b	6860 <fwp_free_zombie+0x100>
    68b0:	ca544680 	eor	x0, x20, x20, lsr #17
    68b4:	91150084 	add	x4, x4, #0x540
    68b8:	ca402400 	eor	x0, x0, x0, lsr #9
    68bc:	92401c00 	and	x0, x0, #0xff
    68c0:	910a2402 	add	x2, x0, #0x289
    68c4:	8b000c80 	add	x0, x4, x0, lsl #3
    68c8:	8b020c82 	add	x2, x4, x2, lsl #3
    68cc:	f94a2400 	ldr	x0, [x0, #5192]
    68d0:	b50000a0 	cbnz	x0, 68e4 <fwp_free_zombie+0x184>
    68d4:	14000013 	b	6920 <fwp_free_zombie+0x1c0>
    68d8:	91004002 	add	x2, x0, #0x10
    68dc:	f9400800 	ldr	x0, [x0, #16]
    68e0:	b4000200 	cbz	x0, 6920 <fwp_free_zombie+0x1c0>
    68e4:	f9400001 	ldr	x1, [x0]
    68e8:	eb14003f 	cmp	x1, x20
    68ec:	54ffff61 	b.ne	68d8 <fwp_free_zombie+0x178>  // b.any
    68f0:	f9400041 	ldr	x1, [x2]
    68f4:	f9400420 	ldr	x0, [x1, #8]
    68f8:	d1000400 	sub	x0, x0, #0x1
    68fc:	f9000420 	str	x0, [x1, #8]
    6900:	f103f81f 	cmp	x0, #0xfe
    6904:	54fff6c1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    6908:	39400280 	ldrb	w0, [x20]
    690c:	7103fc1f 	cmp	w0, #0xff
    6910:	540000e0 	b.eq	692c <fwp_free_zombie+0x1cc>  // b.none
    6914:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6918:	39000280 	strb	w0, [x20]
    691c:	17ffffb0 	b	67dc <fwp_free_zombie+0x7c>
    6920:	f0000020 	adrp	x0, d000 <__modti3+0x2a0>
    6924:	91090000 	add	x0, x0, #0x240
    6928:	97fff55a 	bl	3e90 <fwp_trap>
    692c:	aa1403e0 	mov	x0, x20
    6930:	97fff578 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6934:	17fffff8 	b	6914 <fwp_free_zombie+0x1b4>
    6938:	d503201f 	nop
    693c:	d503201f 	nop

0000000000006940 <fwp_block>:
    6940:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6944:	910003fd 	mov	x29, sp
    6948:	a90153f3 	stp	x19, x20, [sp, #16]
    694c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6950:	9100c274 	add	x20, x19, #0x30
    6954:	f9401a82 	ldr	x2, [x20, #48]
    6958:	b4000642 	cbz	x2, 6a20 <fwp_block+0xe0>
    695c:	9100c261 	add	x1, x19, #0x30
    6960:	f9408040 	ldr	x0, [x2, #256]
    6964:	f9001820 	str	x0, [x1, #48]
    6968:	b40006a0 	cbz	x0, 6a3c <fwp_block+0xfc>
    696c:	d503201f 	nop
    6970:	9100c263 	add	x3, x19, #0x30
    6974:	3901505f 	strb	wzr, [x2, #84]
    6978:	f9400864 	ldr	x4, [x3, #16]
    697c:	eb02009f 	cmp	x4, x2
    6980:	54000440 	b.eq	6a08 <fwp_block+0xc8>  // b.none
    6984:	f9415c65 	ldr	x5, [x3, #696]
    6988:	f9000862 	str	x2, [x3, #16]
    698c:	f9400441 	ldr	x1, [x2, #8]
    6990:	f9004885 	str	x5, [x4, #144]
    6994:	f9416065 	ldr	x5, [x3, #704]
    6998:	f9004c85 	str	x5, [x4, #152]
    699c:	f9416465 	ldr	x5, [x3, #712]
    69a0:	f9005085 	str	x5, [x4, #160]
    69a4:	f9416865 	ldr	x5, [x3, #720]
    69a8:	f9005485 	str	x5, [x4, #168]
    69ac:	f9416c65 	ldr	x5, [x3, #728]
    69b0:	f9005885 	str	x5, [x4, #176]
    69b4:	f9417065 	ldr	x5, [x3, #736]
    69b8:	f9005c85 	str	x5, [x4, #184]
    69bc:	f9417465 	ldr	x5, [x3, #744]
    69c0:	f9006085 	str	x5, [x4, #192]
    69c4:	f9400480 	ldr	x0, [x4, #8]
    69c8:	f9404844 	ldr	x4, [x2, #144]
    69cc:	f9015c64 	str	x4, [x3, #696]
    69d0:	f9404c44 	ldr	x4, [x2, #152]
    69d4:	f9016064 	str	x4, [x3, #704]
    69d8:	f9405044 	ldr	x4, [x2, #160]
    69dc:	f9016464 	str	x4, [x3, #712]
    69e0:	f9405444 	ldr	x4, [x2, #168]
    69e4:	f9016864 	str	x4, [x3, #720]
    69e8:	f9405844 	ldr	x4, [x2, #176]
    69ec:	f9016c64 	str	x4, [x3, #728]
    69f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    69f4:	f9017064 	str	x4, [x3, #736]
    69f8:	f9017462 	str	x2, [x3, #744]
    69fc:	97ffefb9 	bl	28e0 <swapcontext@plt>
    6a00:	97ffff58 	bl	6760 <fwp_free_zombie>
    6a04:	d503201f 	nop
    6a08:	9100c260 	add	x0, x19, #0x30
    6a0c:	b942f000 	ldr	w0, [x0, #752]
    6a10:	340001a0 	cbz	w0, 6a44 <fwp_block+0x104>
    6a14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a18:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a1c:	d65f03c0 	ret
    6a20:	97fff764 	bl	47b0 <fwp_poll_events>
    6a24:	f9401a82 	ldr	x2, [x20, #48]
    6a28:	b4ffffc2 	cbz	x2, 6a20 <fwp_block+0xe0>
    6a2c:	9100c261 	add	x1, x19, #0x30
    6a30:	f9408040 	ldr	x0, [x2, #256]
    6a34:	f9001820 	str	x0, [x1, #48]
    6a38:	b5fff9c0 	cbnz	x0, 6970 <fwp_block+0x30>
    6a3c:	f900143f 	str	xzr, [x1, #40]
    6a40:	17ffffcc 	b	6970 <fwp_block+0x30>
    6a44:	f0000020 	adrp	x0, d000 <__modti3+0x2a0>
    6a48:	91136000 	add	x0, x0, #0x4d8
    6a4c:	97ffeff1 	bl	2a10 <getenv@plt>
    6a50:	5284e202 	mov	w2, #0x2710                	// #10000
    6a54:	b4000060 	cbz	x0, 6a60 <fwp_block+0x120>
    6a58:	39400001 	ldrb	w1, [x0]
    6a5c:	350000c1 	cbnz	w1, 6a74 <fwp_block+0x134>
    6a60:	9100c273 	add	x19, x19, #0x30
    6a64:	b902f262 	str	w2, [x19, #752]
    6a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a70:	d65f03c0 	ret
    6a74:	52800142 	mov	w2, #0xa                   	// #10
    6a78:	d2800001 	mov	x1, #0x0                   	// #0
    6a7c:	97ffef35 	bl	2750 <strtoll@plt>
    6a80:	d1000403 	sub	x3, x0, #0x1
    6a84:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a88:	eb02007f 	cmp	x3, x2
    6a8c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6a90:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6a94:	17fffff3 	b	6a60 <fwp_block+0x120>
    6a98:	d503201f 	nop
    6a9c:	d503201f 	nop

0000000000006aa0 <fwp_drop10>:
    6aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6aa4:	910003fd 	mov	x29, sp
    6aa8:	a90153f3 	stp	x19, x20, [sp, #16]
    6aac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    6ab0:	f90013f5 	str	x21, [sp, #32]
    6ab4:	91150275 	add	x21, x19, #0x540
    6ab8:	f949daa1 	ldr	x1, [x21, #5040]
    6abc:	f949eea2 	ldr	x2, [x21, #5080]
    6ac0:	cb010001 	sub	x1, x0, x1
    6ac4:	eb02403f 	cmp	x1, x2, lsl #16
    6ac8:	54000382 	b.cs	6b38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6acc:	d350fc22 	lsr	x2, x1, #16
    6ad0:	f949fea3 	ldr	x3, [x21, #5112]
    6ad4:	8b020842 	add	x2, x2, x2, lsl #2
    6ad8:	d37df042 	lsl	x2, x2, #3
    6adc:	8b020064 	add	x4, x3, x2
    6ae0:	f9401094 	ldr	x20, [x4, #32]
    6ae4:	b40002b4 	cbz	x20, 6b38 <fwp_drop10+0x98>
    6ae8:	38626862 	ldrb	w2, [x3, x2]
    6aec:	7100085f 	cmp	w2, #0x2
    6af0:	540007a0 	b.eq	6be4 <fwp_drop10+0x144>  // b.none
    6af4:	7100045f 	cmp	w2, #0x1
    6af8:	54000201 	b.ne	6b38 <fwp_drop10+0x98>  // b.any
    6afc:	29430885 	ldp	w5, w2, [x4, #24]
    6b00:	92403c21 	and	x1, x1, #0xffff
    6b04:	9b057c21 	mul	x1, x1, x5
    6b08:	d360fc21 	lsr	x1, x1, #32
    6b0c:	eb02003f 	cmp	x1, x2
    6b10:	54000142 	b.cs	6b38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b14:	8b010294 	add	x20, x20, x1
    6b18:	39400281 	ldrb	w1, [x20]
    6b1c:	340000e1 	cbz	w1, 6b38 <fwp_drop10+0x98>
    6b20:	7100043f 	cmp	w1, #0x1
    6b24:	54000120 	b.eq	6b48 <fwp_drop10+0xa8>  // b.none
    6b28:	7103fc3f 	cmp	w1, #0xff
    6b2c:	540007c0 	b.eq	6c24 <fwp_drop10+0x184>  // b.none
    6b30:	51000421 	sub	w1, w1, #0x1
    6b34:	39000281 	strb	w1, [x20]
    6b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b3c:	f94013f5 	ldr	x21, [sp, #32]
    6b40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b44:	d65f03c0 	ret
    6b48:	f9400001 	ldr	x1, [x0]
    6b4c:	b7f80581 	tbnz	x1, #63, 6bfc <fwp_drop10+0x15c>
    6b50:	91150273 	add	x19, x19, #0x540
    6b54:	f949da61 	ldr	x1, [x19, #5040]
    6b58:	f949ee62 	ldr	x2, [x19, #5080]
    6b5c:	cb010001 	sub	x1, x0, x1
    6b60:	eb02403f 	cmp	x1, x2, lsl #16
    6b64:	54fffea2 	b.cs	6b38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b68:	d350fc22 	lsr	x2, x1, #16
    6b6c:	8b020842 	add	x2, x2, x2, lsl #2
    6b70:	d37df042 	lsl	x2, x2, #3
    6b74:	8b020065 	add	x5, x3, x2
    6b78:	f94010a4 	ldr	x4, [x5, #32]
    6b7c:	b4fffde4 	cbz	x4, 6b38 <fwp_drop10+0x98>
    6b80:	38626862 	ldrb	w2, [x3, x2]
    6b84:	7100085f 	cmp	w2, #0x2
    6b88:	54000220 	b.eq	6bcc <fwp_drop10+0x12c>  // b.none
    6b8c:	7100045f 	cmp	w2, #0x1
    6b90:	54fffd41 	b.ne	6b38 <fwp_drop10+0x98>  // b.any
    6b94:	294308a3 	ldp	w3, w2, [x5, #24]
    6b98:	92403c21 	and	x1, x1, #0xffff
    6b9c:	9b037c21 	mul	x1, x1, x3
    6ba0:	d360fc21 	lsr	x1, x1, #32
    6ba4:	eb02003f 	cmp	x1, x2
    6ba8:	54fffc82 	b.cs	6b38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bac:	8b010084 	add	x4, x4, x1
    6bb0:	39400081 	ldrb	w1, [x4]
    6bb4:	7100043f 	cmp	w1, #0x1
    6bb8:	54fffc01 	b.ne	6b38 <fwp_drop10+0x98>  // b.any
    6bbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc0:	f94013f5 	ldr	x21, [sp, #32]
    6bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bc8:	17fff56e 	b	4180 <fwp_mem_free>
    6bcc:	72003c3f 	tst	w1, #0xffff
    6bd0:	54ffff00 	b.eq	6bb0 <fwp_drop10+0x110>  // b.none
    6bd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bd8:	f94013f5 	ldr	x21, [sp, #32]
    6bdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6be0:	d65f03c0 	ret
    6be4:	72003c3f 	tst	w1, #0xffff
    6be8:	54fff980 	b.eq	6b18 <fwp_drop10+0x78>  // b.none
    6bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bf0:	f94013f5 	ldr	x21, [sp, #32]
    6bf4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bf8:	d65f03c0 	ret
    6bfc:	f9400414 	ldr	x20, [x0, #8]
    6c00:	97fffb25 	bl	5894 <fwp_rc_free_arr>
    6c04:	91150260 	add	x0, x19, #0x540
    6c08:	f949d801 	ldr	x1, [x0, #5040]
    6c0c:	f949ec00 	ldr	x0, [x0, #5080]
    6c10:	cb010281 	sub	x1, x20, x1
    6c14:	eb00403f 	cmp	x1, x0, lsl #16
    6c18:	54fff902 	b.cs	6b38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c1c:	aa1403e0 	mov	x0, x20
    6c20:	17ffffab 	b	6acc <fwp_drop10+0x2c>
    6c24:	ca544680 	eor	x0, x20, x20, lsr #17
    6c28:	91150273 	add	x19, x19, #0x540
    6c2c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c30:	92401c00 	and	x0, x0, #0xff
    6c34:	910a2402 	add	x2, x0, #0x289
    6c38:	8b000e60 	add	x0, x19, x0, lsl #3
    6c3c:	8b020e62 	add	x2, x19, x2, lsl #3
    6c40:	f94a2400 	ldr	x0, [x0, #5192]
    6c44:	b50000a0 	cbnz	x0, 6c58 <fwp_drop10+0x1b8>
    6c48:	14000013 	b	6c94 <fwp_drop10+0x1f4>
    6c4c:	91004002 	add	x2, x0, #0x10
    6c50:	f9400800 	ldr	x0, [x0, #16]
    6c54:	b4000200 	cbz	x0, 6c94 <fwp_drop10+0x1f4>
    6c58:	f9400001 	ldr	x1, [x0]
    6c5c:	eb14003f 	cmp	x1, x20
    6c60:	54ffff61 	b.ne	6c4c <fwp_drop10+0x1ac>  // b.any
    6c64:	f9400041 	ldr	x1, [x2]
    6c68:	f9400420 	ldr	x0, [x1, #8]
    6c6c:	d1000400 	sub	x0, x0, #0x1
    6c70:	f9000420 	str	x0, [x1, #8]
    6c74:	f103f81f 	cmp	x0, #0xfe
    6c78:	54fff601 	b.ne	6b38 <fwp_drop10+0x98>  // b.any
    6c7c:	39400280 	ldrb	w0, [x20]
    6c80:	7103fc1f 	cmp	w0, #0xff
    6c84:	540000e0 	b.eq	6ca0 <fwp_drop10+0x200>  // b.none
    6c88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c8c:	39000280 	strb	w0, [x20]
    6c90:	17ffffaa 	b	6b38 <fwp_drop10+0x98>
    6c94:	f0000020 	adrp	x0, d000 <__modti3+0x2a0>
    6c98:	91090000 	add	x0, x0, #0x240
    6c9c:	97fff47d 	bl	3e90 <fwp_trap>
    6ca0:	aa1403e0 	mov	x0, x20
    6ca4:	97fff49b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6ca8:	17fffff8 	b	6c88 <fwp_drop10+0x1e8>
    6cac:	d503201f 	nop

0000000000006cb0 <fwp_caps173>:
    6cb0:	34000041 	cbz	w1, 6cb8 <fwp_caps173+0x8>
    6cb4:	d65f03c0 	ret
    6cb8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    6cbc:	91150063 	add	x3, x3, #0x540
    6cc0:	f949d861 	ldr	x1, [x3, #5040]
    6cc4:	f949ec62 	ldr	x2, [x3, #5080]
    6cc8:	cb010001 	sub	x1, x0, x1
    6ccc:	eb02403f 	cmp	x1, x2, lsl #16
    6cd0:	54ffff22 	b.cs	6cb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6cd4:	d350fc22 	lsr	x2, x1, #16
    6cd8:	f949fc65 	ldr	x5, [x3, #5112]
    6cdc:	8b020842 	add	x2, x2, x2, lsl #2
    6ce0:	d37df042 	lsl	x2, x2, #3
    6ce4:	8b0200a4 	add	x4, x5, x2
    6ce8:	f9401083 	ldr	x3, [x4, #32]
    6cec:	b4fffe43 	cbz	x3, 6cb4 <fwp_caps173+0x4>
    6cf0:	386268a2 	ldrb	w2, [x5, x2]
    6cf4:	7100085f 	cmp	w2, #0x2
    6cf8:	540001c0 	b.eq	6d30 <fwp_caps173+0x80>  // b.none
    6cfc:	7100045f 	cmp	w2, #0x1
    6d00:	54fffda1 	b.ne	6cb4 <fwp_caps173+0x4>  // b.any
    6d04:	29430885 	ldp	w5, w2, [x4, #24]
    6d08:	92403c21 	and	x1, x1, #0xffff
    6d0c:	9b057c21 	mul	x1, x1, x5
    6d10:	d360fc21 	lsr	x1, x1, #32
    6d14:	eb02003f 	cmp	x1, x2
    6d18:	54fffce2 	b.cs	6cb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d1c:	8b010063 	add	x3, x3, x1
    6d20:	39400061 	ldrb	w1, [x3]
    6d24:	7100043f 	cmp	w1, #0x1
    6d28:	54fffc61 	b.ne	6cb4 <fwp_caps173+0x4>  // b.any
    6d2c:	17fff515 	b	4180 <fwp_mem_free>
    6d30:	72003c3f 	tst	w1, #0xffff
    6d34:	54ffff60 	b.eq	6d20 <fwp_caps173+0x70>  // b.none
    6d38:	d65f03c0 	ret
    6d3c:	d503201f 	nop

0000000000006d40 <fwp_args37>:
    6d40:	7100003f 	cmp	w1, #0x0
    6d44:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6d48:	54000041 	b.ne	6d50 <fwp_args37+0x10>  // b.any
    6d4c:	d65f03c0 	ret
    6d50:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6d54:	91150042 	add	x2, x2, #0x540
    6d58:	f9400001 	ldr	x1, [x0]
    6d5c:	f949d843 	ldr	x3, [x2, #5040]
    6d60:	f949ec40 	ldr	x0, [x2, #5080]
    6d64:	cb030021 	sub	x1, x1, x3
    6d68:	eb00403f 	cmp	x1, x0, lsl #16
    6d6c:	54ffff02 	b.cs	6d4c <fwp_args37+0xc>  // b.hs, b.nlast
    6d70:	d350fc20 	lsr	x0, x1, #16
    6d74:	f949fc44 	ldr	x4, [x2, #5112]
    6d78:	8b000800 	add	x0, x0, x0, lsl #2
    6d7c:	d37df002 	lsl	x2, x0, #3
    6d80:	8b020083 	add	x3, x4, x2
    6d84:	f9401060 	ldr	x0, [x3, #32]
    6d88:	b4fffe20 	cbz	x0, 6d4c <fwp_args37+0xc>
    6d8c:	38626882 	ldrb	w2, [x4, x2]
    6d90:	7100085f 	cmp	w2, #0x2
    6d94:	54000220 	b.eq	6dd8 <fwp_args37+0x98>  // b.none
    6d98:	7100045f 	cmp	w2, #0x1
    6d9c:	54fffd81 	b.ne	6d4c <fwp_args37+0xc>  // b.any
    6da0:	29430864 	ldp	w4, w2, [x3, #24]
    6da4:	92403c21 	and	x1, x1, #0xffff
    6da8:	9b047c21 	mul	x1, x1, x4
    6dac:	d360fc21 	lsr	x1, x1, #32
    6db0:	eb02003f 	cmp	x1, x2
    6db4:	54fffcc2 	b.cs	6d4c <fwp_args37+0xc>  // b.hs, b.nlast
    6db8:	8b010000 	add	x0, x0, x1
    6dbc:	39400001 	ldrb	w1, [x0]
    6dc0:	34fffc61 	cbz	w1, 6d4c <fwp_args37+0xc>
    6dc4:	7103f43f 	cmp	w1, #0xfd
    6dc8:	540000e8 	b.hi	6de4 <fwp_args37+0xa4>  // b.pmore
    6dcc:	11000421 	add	w1, w1, #0x1
    6dd0:	39000001 	strb	w1, [x0]
    6dd4:	d65f03c0 	ret
    6dd8:	72003c3f 	tst	w1, #0xffff
    6ddc:	54ffff00 	b.eq	6dbc <fwp_args37+0x7c>  // b.none
    6de0:	d65f03c0 	ret
    6de4:	17fff560 	b	4364 <fwp_rc_wide_dup>
    6de8:	d503201f 	nop
    6dec:	d503201f 	nop

0000000000006df0 <fwp_caps37>:
    6df0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6df4:	910003fd 	mov	x29, sp
    6df8:	f9000bf3 	str	x19, [sp, #16]
    6dfc:	aa0003f3 	mov	x19, x0
    6e00:	b9400400 	ldr	w0, [x0, #4]
    6e04:	340004a0 	cbz	w0, 6e98 <fwp_caps37+0xa8>
    6e08:	f9400660 	ldr	x0, [x19, #8]
    6e0c:	350004e1 	cbnz	w1, 6ea8 <fwp_caps37+0xb8>
    6e10:	97fffd68 	bl	63b0 <fwp_drop4>
    6e14:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6e18:	91150042 	add	x2, x2, #0x540
    6e1c:	f949d840 	ldr	x0, [x2, #5040]
    6e20:	f949ec41 	ldr	x1, [x2, #5080]
    6e24:	cb000260 	sub	x0, x19, x0
    6e28:	eb01401f 	cmp	x0, x1, lsl #16
    6e2c:	54000382 	b.cs	6e9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6e30:	d350fc01 	lsr	x1, x0, #16
    6e34:	f949fc44 	ldr	x4, [x2, #5112]
    6e38:	8b010821 	add	x1, x1, x1, lsl #2
    6e3c:	d37df021 	lsl	x1, x1, #3
    6e40:	8b010083 	add	x3, x4, x1
    6e44:	f9401062 	ldr	x2, [x3, #32]
    6e48:	b40002a2 	cbz	x2, 6e9c <fwp_caps37+0xac>
    6e4c:	38616881 	ldrb	w1, [x4, x1]
    6e50:	7100083f 	cmp	w1, #0x2
    6e54:	540006c0 	b.eq	6f2c <fwp_caps37+0x13c>  // b.none
    6e58:	7100043f 	cmp	w1, #0x1
    6e5c:	54000201 	b.ne	6e9c <fwp_caps37+0xac>  // b.any
    6e60:	29430464 	ldp	w4, w1, [x3, #24]
    6e64:	92403c00 	and	x0, x0, #0xffff
    6e68:	9b047c00 	mul	x0, x0, x4
    6e6c:	d360fc00 	lsr	x0, x0, #32
    6e70:	eb01001f 	cmp	x0, x1
    6e74:	54000142 	b.cs	6e9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6e78:	8b000042 	add	x2, x2, x0
    6e7c:	39400040 	ldrb	w0, [x2]
    6e80:	7100041f 	cmp	w0, #0x1
    6e84:	540000c1 	b.ne	6e9c <fwp_caps37+0xac>  // b.any
    6e88:	aa1303e0 	mov	x0, x19
    6e8c:	f9400bf3 	ldr	x19, [sp, #16]
    6e90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e94:	17fff4bb 	b	4180 <fwp_mem_free>
    6e98:	34fffbe1 	cbz	w1, 6e14 <fwp_caps37+0x24>
    6e9c:	f9400bf3 	ldr	x19, [sp, #16]
    6ea0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ea4:	d65f03c0 	ret
    6ea8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6eac:	91150042 	add	x2, x2, #0x540
    6eb0:	f949d843 	ldr	x3, [x2, #5040]
    6eb4:	f949ec41 	ldr	x1, [x2, #5080]
    6eb8:	cb030000 	sub	x0, x0, x3
    6ebc:	eb01401f 	cmp	x0, x1, lsl #16
    6ec0:	54fffee2 	b.cs	6e9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ec4:	d350fc01 	lsr	x1, x0, #16
    6ec8:	f949fc44 	ldr	x4, [x2, #5112]
    6ecc:	8b010821 	add	x1, x1, x1, lsl #2
    6ed0:	d37df021 	lsl	x1, x1, #3
    6ed4:	8b010083 	add	x3, x4, x1
    6ed8:	f9401062 	ldr	x2, [x3, #32]
    6edc:	b4fffe02 	cbz	x2, 6e9c <fwp_caps37+0xac>
    6ee0:	38616881 	ldrb	w1, [x4, x1]
    6ee4:	7100083f 	cmp	w1, #0x2
    6ee8:	54000280 	b.eq	6f38 <fwp_caps37+0x148>  // b.none
    6eec:	7100043f 	cmp	w1, #0x1
    6ef0:	54fffd61 	b.ne	6e9c <fwp_caps37+0xac>  // b.any
    6ef4:	92403c01 	and	x1, x0, #0xffff
    6ef8:	29430064 	ldp	w4, w0, [x3, #24]
    6efc:	9b047c21 	mul	x1, x1, x4
    6f00:	d360fc21 	lsr	x1, x1, #32
    6f04:	eb00003f 	cmp	x1, x0
    6f08:	54fffca2 	b.cs	6e9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f0c:	8b010042 	add	x2, x2, x1
    6f10:	39400040 	ldrb	w0, [x2]
    6f14:	34fffc40 	cbz	w0, 6e9c <fwp_caps37+0xac>
    6f18:	7103f41f 	cmp	w0, #0xfd
    6f1c:	54000148 	b.hi	6f44 <fwp_caps37+0x154>  // b.pmore
    6f20:	11000400 	add	w0, w0, #0x1
    6f24:	39000040 	strb	w0, [x2]
    6f28:	17ffffdd 	b	6e9c <fwp_caps37+0xac>
    6f2c:	72003c1f 	tst	w0, #0xffff
    6f30:	54fffb61 	b.ne	6e9c <fwp_caps37+0xac>  // b.any
    6f34:	17ffffd2 	b	6e7c <fwp_caps37+0x8c>
    6f38:	72003c1f 	tst	w0, #0xffff
    6f3c:	54fffb01 	b.ne	6e9c <fwp_caps37+0xac>  // b.any
    6f40:	17fffff4 	b	6f10 <fwp_caps37+0x120>
    6f44:	f9400bf3 	ldr	x19, [sp, #16]
    6f48:	aa0203e0 	mov	x0, x2
    6f4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f50:	17fff505 	b	4364 <fwp_rc_wide_dup>

0000000000006f54 <f37>:
    6f54:	d10203ff 	sub	sp, sp, #0x80
    6f58:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6f5c:	f947f421 	ldr	x1, [x1, #4072]
    6f60:	a9027bfd 	stp	x29, x30, [sp, #32]
    6f64:	910083fd 	add	x29, sp, #0x20
    6f68:	a9045bf5 	stp	x21, x22, [sp, #64]
    6f6c:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xca0>
    6f70:	911502a3 	add	x3, x21, #0x540
    6f74:	a90353f3 	stp	x19, x20, [sp, #48]
    6f78:	aa0003f6 	mov	x22, x0
    6f7c:	a90563f7 	stp	x23, x24, [sp, #80]
    6f80:	a9066bf9 	stp	x25, x26, [sp, #96]
    6f84:	f949ec62 	ldr	x2, [x3, #5080]
    6f88:	f9400024 	ldr	x4, [x1]
    6f8c:	f9000fe4 	str	x4, [sp, #24]
    6f90:	d2800004 	mov	x4, #0x0                   	// #0
    6f94:	f949d861 	ldr	x1, [x3, #5040]
    6f98:	d370bc42 	lsl	x2, x2, #16
    6f9c:	b4001800 	cbz	x0, 729c <f37+0x348>
    6fa0:	f9400817 	ldr	x23, [x0, #16]
    6fa4:	cb0102e1 	sub	x1, x23, x1
    6fa8:	eb02003f 	cmp	x1, x2
    6fac:	54000362 	b.cs	7018 <f37+0xc4>  // b.hs, b.nlast
    6fb0:	f949fc60 	ldr	x0, [x3, #5112]
    6fb4:	d350fc22 	lsr	x2, x1, #16
    6fb8:	8b020842 	add	x2, x2, x2, lsl #2
    6fbc:	8b020c02 	add	x2, x0, x2, lsl #3
    6fc0:	f9401040 	ldr	x0, [x2, #32]
    6fc4:	b40002a0 	cbz	x0, 7018 <f37+0xc4>
    6fc8:	39400043 	ldrb	w3, [x2]
    6fcc:	7100087f 	cmp	w3, #0x2
    6fd0:	54001540 	b.eq	7278 <f37+0x324>  // b.none
    6fd4:	7100047f 	cmp	w3, #0x1
    6fd8:	540001c1 	b.ne	7010 <f37+0xbc>  // b.any
    6fdc:	29430843 	ldp	w3, w2, [x2, #24]
    6fe0:	92403c21 	and	x1, x1, #0xffff
    6fe4:	9b037c21 	mul	x1, x1, x3
    6fe8:	d360fc21 	lsr	x1, x1, #32
    6fec:	eb02003f 	cmp	x1, x2
    6ff0:	54000102 	b.cs	7010 <f37+0xbc>  // b.hs, b.nlast
    6ff4:	8b010000 	add	x0, x0, x1
    6ff8:	39400001 	ldrb	w1, [x0]
    6ffc:	340000a1 	cbz	w1, 7010 <f37+0xbc>
    7000:	7103f43f 	cmp	w1, #0xfd
    7004:	540017e8 	b.hi	7300 <f37+0x3ac>  // b.pmore
    7008:	11000421 	add	w1, w1, #0x1
    700c:	39000001 	strb	w1, [x0]
    7010:	d2800002 	mov	x2, #0x0                   	// #0
    7014:	b40000d6 	cbz	x22, 702c <f37+0xd8>
    7018:	aa1603e1 	mov	x1, x22
    701c:	d2800002 	mov	x2, #0x0                   	// #0
    7020:	f9400821 	ldr	x1, [x1, #16]
    7024:	91000442 	add	x2, x2, #0x1
    7028:	b5ffffc1 	cbnz	x1, 7020 <f37+0xcc>
    702c:	b40013f7 	cbz	x23, 72a8 <f37+0x354>
    7030:	aa1703e1 	mov	x1, x23
    7034:	d2800003 	mov	x3, #0x0                   	// #0
    7038:	f9400821 	ldr	x1, [x1, #16]
    703c:	91000463 	add	x3, x3, #0x1
    7040:	b5ffffc1 	cbnz	x1, 7038 <f37+0xe4>
    7044:	eb02007f 	cmp	x3, x2
    7048:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    704c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7050:	eb00027f 	cmp	x19, x0
    7054:	540010a8 	b.hi	7268 <f37+0x314>  // b.pmore
    7058:	d37ffa74 	lsl	x20, x19, #1
    705c:	52800041 	mov	w1, #0x2                   	// #2
    7060:	91000680 	add	x0, x20, #0x1
    7064:	d37df000 	lsl	x0, x0, #3
    7068:	97fff702 	bl	4c70 <fwp_heap_alloc>
    706c:	aa0003f8 	mov	x24, x0
    7070:	911502a1 	add	x1, x21, #0x540
    7074:	aa0103e0 	mov	x0, x1
    7078:	f9000314 	str	x20, [x24]
    707c:	f949d821 	ldr	x1, [x1, #5040]
    7080:	f949ec00 	ldr	x0, [x0, #5080]
    7084:	cb010301 	sub	x1, x24, x1
    7088:	eb00403f 	cmp	x1, x0, lsl #16
    708c:	54000342 	b.cs	70f4 <f37+0x1a0>  // b.hs, b.nlast
    7090:	911502a2 	add	x2, x21, #0x540
    7094:	d350fc20 	lsr	x0, x1, #16
    7098:	8b000800 	add	x0, x0, x0, lsl #2
    709c:	f949fc43 	ldr	x3, [x2, #5112]
    70a0:	d37df002 	lsl	x2, x0, #3
    70a4:	8b020060 	add	x0, x3, x2
    70a8:	f9401014 	ldr	x20, [x0, #32]
    70ac:	b4000254 	cbz	x20, 70f4 <f37+0x1a0>
    70b0:	38626862 	ldrb	w2, [x3, x2]
    70b4:	7100085f 	cmp	w2, #0x2
    70b8:	54000ec0 	b.eq	7290 <f37+0x33c>  // b.none
    70bc:	7100045f 	cmp	w2, #0x1
    70c0:	540001a1 	b.ne	70f4 <f37+0x1a0>  // b.any
    70c4:	29430002 	ldp	w2, w0, [x0, #24]
    70c8:	92403c21 	and	x1, x1, #0xffff
    70cc:	9b027c21 	mul	x1, x1, x2
    70d0:	d360fc21 	lsr	x1, x1, #32
    70d4:	eb00003f 	cmp	x1, x0
    70d8:	540000e2 	b.cs	70f4 <f37+0x1a0>  // b.hs, b.nlast
    70dc:	8b010294 	add	x20, x20, x1
    70e0:	39400280 	ldrb	w0, [x20]
    70e4:	7103fc1f 	cmp	w0, #0xff
    70e8:	54001100 	b.eq	7308 <f37+0x3b4>  // b.none
    70ec:	52800020 	mov	w0, #0x1                   	// #1
    70f0:	39000280 	strb	w0, [x20]
    70f4:	b4000253 	cbz	x19, 713c <f37+0x1e8>
    70f8:	8b131313 	add	x19, x24, x19, lsl #4
    70fc:	aa1803f4 	mov	x20, x24
    7100:	aa1603fa 	mov	x26, x22
    7104:	aa1703f9 	mov	x25, x23
    7108:	f9400723 	ldr	x3, [x25, #8]
    710c:	f9400742 	ldr	x2, [x26, #8]
    7110:	f9400861 	ldr	x1, [x3, #16]
    7114:	f9400840 	ldr	x0, [x2, #16]
    7118:	fd400461 	ldr	d1, [x3, #8]
    711c:	fd400440 	ldr	d0, [x2, #8]
    7120:	97fff850 	bl	5260 <w120>
    7124:	f9000680 	str	x0, [x20, #8]
    7128:	f8010e81 	str	x1, [x20, #16]!
    712c:	f9400b39 	ldr	x25, [x25, #16]
    7130:	f9400b5a 	ldr	x26, [x26, #16]
    7134:	eb14027f 	cmp	x19, x20
    7138:	54fffe81 	b.ne	7108 <f37+0x1b4>  // b.any
    713c:	aa1703e0 	mov	x0, x23
    7140:	97fffc9c 	bl	63b0 <fwp_drop4>
    7144:	aa1603e0 	mov	x0, x22
    7148:	97fffc9a 	bl	63b0 <fwp_drop4>
    714c:	f9400316 	ldr	x22, [x24]
    7150:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7154:	b4000236 	cbz	x22, 7198 <f37+0x244>
    7158:	fd003be8 	str	d8, [sp, #112]
    715c:	2f00e408 	movi	d8, #0x0
    7160:	91002319 	add	x25, x24, #0x8
    7164:	91004317 	add	x23, x24, #0x10
    7168:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    716c:	d2800013 	mov	x19, #0x0                   	// #0
    7170:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7174:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7178:	91000a73 	add	x19, x19, #0x2
    717c:	1e602908 	fadd	d8, d8, d0
    7180:	97fff7e0 	bl	5100 <f141.constprop.0>
    7184:	aa0003f4 	mov	x20, x0
    7188:	eb1302df 	cmp	x22, x19
    718c:	54ffff28 	b.hi	7170 <f37+0x21c>  // b.pmore
    7190:	9e660116 	fmov	x22, d8
    7194:	fd403be8 	ldr	d8, [sp, #112]
    7198:	911502b5 	add	x21, x21, #0x540
    719c:	aa1803e0 	mov	x0, x24
    71a0:	97fffe40 	bl	6aa0 <fwp_drop10>
    71a4:	a900d3f6 	stp	x22, x20, [sp, #8]
    71a8:	910023e1 	add	x1, sp, #0x8
    71ac:	52800000 	mov	w0, #0x0                   	// #0
    71b0:	97fff6f5 	bl	4d84 <fwp_data.part.0.constprop.0>
    71b4:	f949daa1 	ldr	x1, [x21, #5040]
    71b8:	aa0003f3 	mov	x19, x0
    71bc:	f949eea0 	ldr	x0, [x21, #5080]
    71c0:	cb010261 	sub	x1, x19, x1
    71c4:	eb00403f 	cmp	x1, x0, lsl #16
    71c8:	54000322 	b.cs	722c <f37+0x2d8>  // b.hs, b.nlast
    71cc:	d350fc22 	lsr	x2, x1, #16
    71d0:	f949fea3 	ldr	x3, [x21, #5112]
    71d4:	8b020842 	add	x2, x2, x2, lsl #2
    71d8:	d37df042 	lsl	x2, x2, #3
    71dc:	8b020060 	add	x0, x3, x2
    71e0:	f9401014 	ldr	x20, [x0, #32]
    71e4:	b4000254 	cbz	x20, 722c <f37+0x2d8>
    71e8:	38626862 	ldrb	w2, [x3, x2]
    71ec:	7100085f 	cmp	w2, #0x2
    71f0:	540004a0 	b.eq	7284 <f37+0x330>  // b.none
    71f4:	7100045f 	cmp	w2, #0x1
    71f8:	540001a1 	b.ne	722c <f37+0x2d8>  // b.any
    71fc:	29430002 	ldp	w2, w0, [x0, #24]
    7200:	92403c21 	and	x1, x1, #0xffff
    7204:	9b027c21 	mul	x1, x1, x2
    7208:	d360fc21 	lsr	x1, x1, #32
    720c:	eb00003f 	cmp	x1, x0
    7210:	540000e2 	b.cs	722c <f37+0x2d8>  // b.hs, b.nlast
    7214:	8b010294 	add	x20, x20, x1
    7218:	39400280 	ldrb	w0, [x20]
    721c:	7103fc1f 	cmp	w0, #0xff
    7220:	540007a0 	b.eq	7314 <f37+0x3c0>  // b.none
    7224:	52800020 	mov	w0, #0x1                   	// #1
    7228:	39000280 	strb	w0, [x20]
    722c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7230:	f947f400 	ldr	x0, [x0, #4072]
    7234:	f9400fe2 	ldr	x2, [sp, #24]
    7238:	f9400001 	ldr	x1, [x0]
    723c:	eb010042 	subs	x2, x2, x1
    7240:	d2800001 	mov	x1, #0x0                   	// #0
    7244:	54000721 	b.ne	7328 <f37+0x3d4>  // b.any
    7248:	a9427bfd 	ldp	x29, x30, [sp, #32]
    724c:	aa1303e0 	mov	x0, x19
    7250:	a94353f3 	ldp	x19, x20, [sp, #48]
    7254:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7258:	a94563f7 	ldp	x23, x24, [sp, #80]
    725c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7260:	910203ff 	add	sp, sp, #0x80
    7264:	d65f03c0 	ret
    7268:	d0000020 	adrp	x0, d000 <__modti3+0x2a0>
    726c:	9113a000 	add	x0, x0, #0x4e8
    7270:	fd003be8 	str	d8, [sp, #112]
    7274:	97fff307 	bl	3e90 <fwp_trap>
    7278:	72003c3f 	tst	w1, #0xffff
    727c:	54ffeca1 	b.ne	7010 <f37+0xbc>  // b.any
    7280:	17ffff5e 	b	6ff8 <f37+0xa4>
    7284:	72003c3f 	tst	w1, #0xffff
    7288:	54fffd21 	b.ne	722c <f37+0x2d8>  // b.any
    728c:	17ffffe3 	b	7218 <f37+0x2c4>
    7290:	72003c3f 	tst	w1, #0xffff
    7294:	54fff301 	b.ne	70f4 <f37+0x1a0>  // b.any
    7298:	17ffff92 	b	70e0 <f37+0x18c>
    729c:	cb0103e1 	neg	x1, x1
    72a0:	eb02003f 	cmp	x1, x2
    72a4:	540001e3 	b.cc	72e0 <f37+0x38c>  // b.lo, b.ul, b.last
    72a8:	52800041 	mov	w1, #0x2                   	// #2
    72ac:	d2800100 	mov	x0, #0x8                   	// #8
    72b0:	97fff670 	bl	4c70 <fwp_heap_alloc>
    72b4:	aa0003f8 	mov	x24, x0
    72b8:	911502a0 	add	x0, x21, #0x540
    72bc:	f900031f 	str	xzr, [x24]
    72c0:	f949d801 	ldr	x1, [x0, #5040]
    72c4:	f949ec00 	ldr	x0, [x0, #5080]
    72c8:	cb010301 	sub	x1, x24, x1
    72cc:	eb00403f 	cmp	x1, x0, lsl #16
    72d0:	54000282 	b.cs	7320 <f37+0x3cc>  // b.hs, b.nlast
    72d4:	d2800013 	mov	x19, #0x0                   	// #0
    72d8:	d2800017 	mov	x23, #0x0                   	// #0
    72dc:	17ffff6d 	b	7090 <f37+0x13c>
    72e0:	f949fc62 	ldr	x2, [x3, #5112]
    72e4:	d350fc20 	lsr	x0, x1, #16
    72e8:	8b000800 	add	x0, x0, x0, lsl #2
    72ec:	8b000c42 	add	x2, x2, x0, lsl #3
    72f0:	f9401040 	ldr	x0, [x2, #32]
    72f4:	b4fffda0 	cbz	x0, 72a8 <f37+0x354>
    72f8:	d2800017 	mov	x23, #0x0                   	// #0
    72fc:	17ffff33 	b	6fc8 <f37+0x74>
    7300:	97fff419 	bl	4364 <fwp_rc_wide_dup>
    7304:	17ffff43 	b	7010 <f37+0xbc>
    7308:	aa1403e0 	mov	x0, x20
    730c:	97fff301 	bl	3f10 <fwp_rc_forget_slot.part.0>
    7310:	17ffff77 	b	70ec <f37+0x198>
    7314:	aa1403e0 	mov	x0, x20
    7318:	97fff2fe 	bl	3f10 <fwp_rc_forget_slot.part.0>
    731c:	17ffffc2 	b	7224 <f37+0x2d0>
    7320:	d2800017 	mov	x23, #0x0                   	// #0
    7324:	17ffff86 	b	713c <f37+0x1e8>
    7328:	fd003be8 	str	d8, [sp, #112]
    732c:	97ffed55 	bl	2880 <__stack_chk_fail@plt>

0000000000007330 <fwp_owned_entry37>:
    7330:	f9400000 	ldr	x0, [x0]
    7334:	17ffff08 	b	6f54 <f37>
    7338:	d503201f 	nop
    733c:	d503201f 	nop

0000000000007340 <e37>:
    7340:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7344:	910003fd 	mov	x29, sp
    7348:	f9000bf3 	str	x19, [sp, #16]
    734c:	f9400013 	ldr	x19, [x0]
    7350:	aa1303e0 	mov	x0, x19
    7354:	97fff8fc 	bl	5744 <fwp_rc_share>
    7358:	aa1303e0 	mov	x0, x19
    735c:	97fffefe 	bl	6f54 <f37>
    7360:	aa0003f3 	mov	x19, x0
    7364:	97fff8f8 	bl	5744 <fwp_rc_share>
    7368:	aa1303e0 	mov	x0, x19
    736c:	f9400bf3 	ldr	x19, [sp, #16]
    7370:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7374:	d65f03c0 	ret
    7378:	d503201f 	nop
    737c:	d503201f 	nop

0000000000007380 <fwp_write>:
    7380:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7384:	910003fd 	mov	x29, sp
    7388:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    738c:	f947f484 	ldr	x4, [x4, #4072]
    7390:	a90153f3 	stp	x19, x20, [sp, #16]
    7394:	d10943ff 	sub	sp, sp, #0x250
    7398:	b9400045 	ldr	w5, [x2]
    739c:	aa0003f4 	mov	x20, x0
    73a0:	f9400080 	ldr	x0, [x4]
    73a4:	f90127e0 	str	x0, [sp, #584]
    73a8:	d2800000 	mov	x0, #0x0                   	// #0
    73ac:	710064bf 	cmp	w5, #0x19
    73b0:	54000408 	b.hi	7430 <fwp_write+0xb0>  // b.pmore
    73b4:	d0000020 	adrp	x0, d000 <__modti3+0x2a0>
    73b8:	aa0103f3 	mov	x19, x1
    73bc:	91354000 	add	x0, x0, #0xd50
    73c0:	f9013bf5 	str	x21, [sp, #624]
    73c4:	f9013ff6 	str	x22, [sp, #632]
    73c8:	f90153fb 	str	x27, [sp, #672]
    73cc:	f90157fc 	str	x28, [sp, #680]
    73d0:	aa0203fc 	mov	x28, x2
    73d4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    73d8:	10000061 	adr	x1, 73e4 <fwp_write+0x64>
    73dc:	8b20a820 	add	x0, x1, w0, sxth #2
    73e0:	d61f0000 	br	x0
    73e4:	910123e0 	add	x0, sp, #0x48
    73e8:	aa1303e5 	mov	x5, x19
    73ec:	d0000024 	adrp	x4, d000 <__modti3+0x2a0>
    73f0:	aa0003f3 	mov	x19, x0
    73f4:	9114c084 	add	x4, x4, #0x530
    73f8:	d2804003 	mov	x3, #0x200                 	// #512
    73fc:	aa0303e1 	mov	x1, x3
    7400:	52800042 	mov	w2, #0x2                   	// #2
    7404:	97ffecfb 	bl	27f0 <__snprintf_chk@plt>
    7408:	aa1303e0 	mov	x0, x19
    740c:	97ffecc1 	bl	2710 <strlen@plt>
    7410:	aa1303e1 	mov	x1, x19
    7414:	aa0003e2 	mov	x2, x0
    7418:	aa1403e0 	mov	x0, x20
    741c:	97ffeffd 	bl	3410 <buf_put>
    7420:	f9413bf5 	ldr	x21, [sp, #624]
    7424:	f9413ff6 	ldr	x22, [sp, #632]
    7428:	f94153fb 	ldr	x27, [sp, #672]
    742c:	f94157fc 	ldr	x28, [sp, #680]
    7430:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7434:	f947f400 	ldr	x0, [x0, #4072]
    7438:	f94127e2 	ldr	x2, [sp, #584]
    743c:	f9400001 	ldr	x1, [x0]
    7440:	eb010042 	subs	x2, x2, x1
    7444:	d2800001 	mov	x1, #0x0                   	// #0
    7448:	540077c1 	b.ne	8340 <fwp_write+0xfc0>  // b.any
    744c:	910943ff 	add	sp, sp, #0x250
    7450:	a94153f3 	ldp	x19, x20, [sp, #16]
    7454:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7458:	d65f03c0 	ret
    745c:	910123e0 	add	x0, sp, #0x48
    7460:	aa1303e5 	mov	x5, x19
    7464:	d0000024 	adrp	x4, d000 <__modti3+0x2a0>
    7468:	aa0003f3 	mov	x19, x0
    746c:	9114a084 	add	x4, x4, #0x528
    7470:	d2804003 	mov	x3, #0x200                 	// #512
    7474:	17ffffe2 	b	73fc <fwp_write+0x7c>
    7478:	71004cbf 	cmp	w5, #0x13
    747c:	d0000020 	adrp	x0, d000 <__modti3+0x2a0>
    7480:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7484:	91146000 	add	x0, x0, #0x518
    7488:	91148021 	add	x1, x1, #0x520
    748c:	d2800082 	mov	x2, #0x4                   	// #4
    7490:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7494:	aa1403e0 	mov	x0, x20
    7498:	f90143f7 	str	x23, [sp, #640]
    749c:	d2800016 	mov	x22, #0x0                   	// #0
    74a0:	f90147f8 	str	x24, [sp, #648]
    74a4:	97ffefdb 	bl	3410 <buf_put>
    74a8:	f9400260 	ldr	x0, [x19]
    74ac:	d0000037 	adrp	x23, d000 <__modti3+0x2a0>
    74b0:	d2800015 	mov	x21, #0x0                   	// #0
    74b4:	911682f7 	add	x23, x23, #0x5a0
    74b8:	b40047a0 	cbz	x0, 7dac <fwp_write+0xa2c>
    74bc:	b9400380 	ldr	w0, [x28]
    74c0:	52800003 	mov	w3, #0x0                   	// #0
    74c4:	f9401f82 	ldr	x2, [x28, #56]
    74c8:	71004c1f 	cmp	w0, #0x13
    74cc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    74d0:	aa1403e0 	mov	x0, x20
    74d4:	8b010e61 	add	x1, x19, x1, lsl #3
    74d8:	f9400421 	ldr	x1, [x1, #8]
    74dc:	97ffffa9 	bl	7380 <fwp_write>
    74e0:	b9400380 	ldr	w0, [x28]
    74e4:	7100481f 	cmp	w0, #0x12
    74e8:	54004b40 	b.eq	7e50 <fwp_write+0xad0>  // b.none
    74ec:	f9400260 	ldr	x0, [x19]
    74f0:	910006b5 	add	x21, x21, #0x1
    74f4:	91000ad6 	add	x22, x22, #0x2
    74f8:	eb15001f 	cmp	x0, x21
    74fc:	54004589 	b.ls	7dac <fwp_write+0xa2c>  // b.plast
    7500:	aa1703e1 	mov	x1, x23
    7504:	aa1403e0 	mov	x0, x20
    7508:	d2800042 	mov	x2, #0x2                   	// #2
    750c:	97ffefc1 	bl	3410 <buf_put>
    7510:	17ffffeb 	b	74bc <fwp_write+0x13c>
    7514:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7518:	91156021 	add	x1, x1, #0x558
    751c:	d28000c2 	mov	x2, #0x6                   	// #6
    7520:	aa1403e0 	mov	x0, x20
    7524:	91004273 	add	x19, x19, #0x10
    7528:	97ffefba 	bl	3410 <buf_put>
    752c:	aa1303e0 	mov	x0, x19
    7530:	97ffec78 	bl	2710 <strlen@plt>
    7534:	aa1303e1 	mov	x1, x19
    7538:	aa0003e2 	mov	x2, x0
    753c:	aa1403e0 	mov	x0, x20
    7540:	97ffefb4 	bl	3410 <buf_put>
    7544:	528007c3 	mov	w3, #0x3e                  	// #62
    7548:	aa1403e0 	mov	x0, x20
    754c:	91001fe1 	add	x1, sp, #0x7
    7550:	d2800022 	mov	x2, #0x1                   	// #1
    7554:	39001fe3 	strb	w3, [sp, #7]
    7558:	17ffffb1 	b	741c <fwp_write+0x9c>
    755c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7560:	f947f400 	ldr	x0, [x0, #4072]
    7564:	f94127e2 	ldr	x2, [sp, #584]
    7568:	f9400001 	ldr	x1, [x0]
    756c:	eb010042 	subs	x2, x2, x1
    7570:	d2800001 	mov	x1, #0x0                   	// #0
    7574:	540034e1 	b.ne	7c10 <fwp_write+0x890>  // b.any
    7578:	f9413bf5 	ldr	x21, [sp, #624]
    757c:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7580:	f9413ff6 	ldr	x22, [sp, #632]
    7584:	aa1403e0 	mov	x0, x20
    7588:	9114e021 	add	x1, x1, #0x538
    758c:	d2800142 	mov	x2, #0xa                   	// #10
    7590:	f94153fb 	ldr	x27, [sp, #672]
    7594:	f94157fc 	ldr	x28, [sp, #680]
    7598:	910943ff 	add	sp, sp, #0x250
    759c:	a94153f3 	ldp	x19, x20, [sp, #16]
    75a0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    75a4:	17ffef9b 	b	3410 <buf_put>
    75a8:	f9400456 	ldr	x22, [x2, #8]
    75ac:	f90143f7 	str	x23, [sp, #640]
    75b0:	f90147f8 	str	x24, [sp, #648]
    75b4:	b4005b16 	cbz	x22, 8114 <fwp_write+0xd94>
    75b8:	aa1603e0 	mov	x0, x22
    75bc:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    75c0:	9116e021 	add	x1, x1, #0x5b8
    75c4:	97ffeccf 	bl	2900 <strcmp@plt>
    75c8:	2a0003f5 	mov	w21, w0
    75cc:	34005fe0 	cbz	w0, 81c8 <fwp_write+0xe48>
    75d0:	aa1603e0 	mov	x0, x22
    75d4:	97ffec4f 	bl	2710 <strlen@plt>
    75d8:	aa1603e1 	mov	x1, x22
    75dc:	aa0003e2 	mov	x2, x0
    75e0:	aa1403e0 	mov	x0, x20
    75e4:	97ffef8b 	bl	3410 <buf_put>
    75e8:	52800403 	mov	w3, #0x20                  	// #32
    75ec:	91001ff5 	add	x21, sp, #0x7
    75f0:	aa1503e1 	mov	x1, x21
    75f4:	aa1403e0 	mov	x0, x20
    75f8:	d2800022 	mov	x2, #0x1                   	// #1
    75fc:	39001fe3 	strb	w3, [sp, #7]
    7600:	97ffef84 	bl	3410 <buf_put>
    7604:	52800f63 	mov	w3, #0x7b                  	// #123
    7608:	aa1403e0 	mov	x0, x20
    760c:	aa1503e1 	mov	x1, x21
    7610:	d2800022 	mov	x2, #0x1                   	// #1
    7614:	39001fe3 	strb	w3, [sp, #7]
    7618:	97ffef7e 	bl	3410 <buf_put>
    761c:	b9401380 	ldr	w0, [x28, #16]
    7620:	52800018 	mov	w24, #0x0                   	// #0
    7624:	7100001f 	cmp	w0, #0x0
    7628:	54003aad 	b.le	7d7c <fwp_write+0x9fc>
    762c:	f9014bf9 	str	x25, [sp, #656]
    7630:	d0000039 	adrp	x25, d000 <__modti3+0x2a0>
    7634:	91178339 	add	x25, x25, #0x5e0
    7638:	f9014ffa 	str	x26, [sp, #664]
    763c:	d000003a 	adrp	x26, d000 <__modti3+0x2a0>
    7640:	9116835a 	add	x26, x26, #0x5a0
    7644:	91002276 	add	x22, x19, #0x8
    7648:	d2800013 	mov	x19, #0x0                   	// #0
    764c:	b5003e93 	cbnz	x19, 7e1c <fwp_write+0xa9c>
    7650:	d37df277 	lsl	x23, x19, #3
    7654:	34003cb8 	cbz	w24, 7de8 <fwp_write+0xa68>
    7658:	f9401382 	ldr	x2, [x28, #32]
    765c:	aa1403e0 	mov	x0, x20
    7660:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7664:	52800003 	mov	w3, #0x0                   	// #0
    7668:	f8776842 	ldr	x2, [x2, x23]
    766c:	91000673 	add	x19, x19, #0x1
    7670:	97ffff44 	bl	7380 <fwp_write>
    7674:	b9401380 	ldr	w0, [x28, #16]
    7678:	6b13001f 	cmp	w0, w19
    767c:	54fffe8c 	b.gt	764c <fwp_write+0x2cc>
    7680:	f9414bf9 	ldr	x25, [sp, #656]
    7684:	f9414ffa 	ldr	x26, [sp, #664]
    7688:	340037b8 	cbz	w24, 7d7c <fwp_write+0x9fc>
    768c:	52800523 	mov	w3, #0x29                  	// #41
    7690:	aa1503e1 	mov	x1, x21
    7694:	aa1403e0 	mov	x0, x20
    7698:	d2800022 	mov	x2, #0x1                   	// #1
    769c:	39001fe3 	strb	w3, [sp, #7]
    76a0:	97ffef5c 	bl	3410 <buf_put>
    76a4:	f9413bf5 	ldr	x21, [sp, #624]
    76a8:	f9413ff6 	ldr	x22, [sp, #632]
    76ac:	f94143f7 	ldr	x23, [sp, #640]
    76b0:	f94147f8 	ldr	x24, [sp, #648]
    76b4:	f94153fb 	ldr	x27, [sp, #672]
    76b8:	f94157fc 	ldr	x28, [sp, #680]
    76bc:	17ffff5d 	b	7430 <fwp_write+0xb0>
    76c0:	b9404855 	ldr	w21, [x2, #72]
    76c4:	aa1403e0 	mov	x0, x20
    76c8:	93407eb6 	sxtw	x22, w21
    76cc:	91000ac1 	add	x1, x22, #0x2
    76d0:	97ffef1d 	bl	3344 <buf_grow>
    76d4:	a9400281 	ldp	x1, x0, [x20]
    76d8:	528e8603 	mov	w3, #0x7430                	// #29744
    76dc:	78206823 	strh	w3, [x1, x0]
    76e0:	8b000022 	add	x2, x1, x0
    76e4:	710002bf 	cmp	w21, #0x0
    76e8:	540036cd 	b.le	7dc0 <fwp_write+0xa40>
    76ec:	110006a3 	add	w3, w21, #0x1
    76f0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    76f4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    76f8:	91000449 	add	x9, x2, #0x1
    76fc:	8b23c043 	add	x3, x2, w3, sxtw
    7700:	f28aaac6 	movk	x6, #0x5556
    7704:	f2955568 	movk	x8, #0xaaab
    7708:	1400000d 	b	773c <fwp_write+0x3bc>
    770c:	d2800021 	mov	x1, #0x1                   	// #1
    7710:	528005a5 	mov	w5, #0x2d                  	// #45
    7714:	f100001f 	cmp	x0, #0x0
    7718:	9b467e60 	smulh	x0, x19, x6
    771c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7720:	381ff465 	strb	w5, [x3], #-1
    7724:	cb040000 	sub	x0, x0, x4
    7728:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    772c:	cb020000 	sub	x0, x0, x2
    7730:	8b010013 	add	x19, x0, x1
    7734:	eb03013f 	cmp	x9, x3
    7738:	54003440 	b.eq	7dc0 <fwp_write+0xa40>  // b.none
    773c:	9b467e60 	smulh	x0, x19, x6
    7740:	937ffe64 	asr	x4, x19, #63
    7744:	52800605 	mov	w5, #0x30                  	// #48
    7748:	cb040000 	sub	x0, x0, x4
    774c:	8b000400 	add	x0, x0, x0, lsl #1
    7750:	cb000260 	sub	x0, x19, x0
    7754:	91000c01 	add	x1, x0, #0x3
    7758:	9bc87c22 	umulh	x2, x1, x8
    775c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7760:	8b4204e2 	add	x2, x7, x2, lsr #1
    7764:	eb020021 	subs	x1, x1, x2
    7768:	54fffd60 	b.eq	7714 <fwp_write+0x394>  // b.none
    776c:	f100043f 	cmp	x1, #0x1
    7770:	54fffce1 	b.ne	770c <fwp_write+0x38c>  // b.any
    7774:	d2800001 	mov	x1, #0x0                   	// #0
    7778:	52800565 	mov	w5, #0x2b                  	// #43
    777c:	17ffffe6 	b	7714 <fwp_write+0x394>
    7780:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7784:	f947f400 	ldr	x0, [x0, #4072]
    7788:	f94127e2 	ldr	x2, [sp, #584]
    778c:	f9400001 	ldr	x1, [x0]
    7790:	eb010042 	subs	x2, x2, x1
    7794:	d2800001 	mov	x1, #0x0                   	// #0
    7798:	540023c1 	b.ne	7c10 <fwp_write+0x890>  // b.any
    779c:	f9413bf5 	ldr	x21, [sp, #624]
    77a0:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    77a4:	f9413ff6 	ldr	x22, [sp, #632]
    77a8:	aa1403e0 	mov	x0, x20
    77ac:	91152021 	add	x1, x1, #0x548
    77b0:	d2800102 	mov	x2, #0x8                   	// #8
    77b4:	17ffff77 	b	7590 <fwp_write+0x210>
    77b8:	aa1403e0 	mov	x0, x20
    77bc:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    77c0:	d28000c2 	mov	x2, #0x6                   	// #6
    77c4:	9116a021 	add	x1, x1, #0x5a8
    77c8:	97ffef12 	bl	3410 <buf_put>
    77cc:	d2800015 	mov	x21, #0x0                   	// #0
    77d0:	f9400263 	ldr	x3, [x19]
    77d4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    77d8:	54002c60 	b.eq	7d64 <fwp_write+0x9e4>  // b.none
    77dc:	f9401f82 	ldr	x2, [x28, #56]
    77e0:	f90143f7 	str	x23, [sp, #640]
    77e4:	f90147f8 	str	x24, [sp, #648]
    77e8:	d2800857 	mov	x23, #0x42                  	// #66
    77ec:	f9014bf9 	str	x25, [sp, #656]
    77f0:	d0000036 	adrp	x22, d000 <__modti3+0x2a0>
    77f4:	f9014ffa 	str	x26, [sp, #664]
    77f8:	911682d6 	add	x22, x22, #0x5a0
    77fc:	d2800038 	mov	x24, #0x1                   	// #1
    7800:	f2a18017 	movk	x23, #0xc00, lsl #16
    7804:	d2809099 	mov	x25, #0x484                 	// #1156
    7808:	b40004a2 	cbz	x2, 789c <fwp_write+0x51c>
    780c:	b9400040 	ldr	w0, [x2]
    7810:	7100701f 	cmp	w0, #0x1c
    7814:	540042c0 	b.eq	806c <fwp_write+0xcec>  // b.none
    7818:	71006c1f 	cmp	w0, #0x1b
    781c:	54000408 	b.hi	789c <fwp_write+0x51c>  // b.pmore
    7820:	9ac02301 	lsl	x1, x24, x0
    7824:	ea17003f 	tst	x1, x23
    7828:	540036a1 	b.ne	7efc <fwp_write+0xb7c>  // b.any
    782c:	ea19003f 	tst	x1, x25
    7830:	54003521 	b.ne	7ed4 <fwp_write+0xb54>  // b.any
    7834:	d2800424 	mov	x4, #0x21                  	// #33
    7838:	ea04003f 	tst	x1, x4
    783c:	54000300 	b.eq	789c <fwp_write+0x51c>  // b.none
    7840:	b7f849c3 	tbnz	x3, #63, 8178 <fwp_write+0xdf8>
    7844:	91002261 	add	x1, x19, #0x8
    7848:	8b150021 	add	x1, x1, x21
    784c:	39400021 	ldrb	w1, [x1]
    7850:	7100001f 	cmp	w0, #0x0
    7854:	93401c23 	sxtb	x3, w1
    7858:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    785c:	d503201f 	nop
    7860:	aa1403e0 	mov	x0, x20
    7864:	52800003 	mov	w3, #0x0                   	// #0
    7868:	97fffec6 	bl	7380 <fwp_write>
    786c:	910006b5 	add	x21, x21, #0x1
    7870:	f9400260 	ldr	x0, [x19]
    7874:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7878:	eb0002bf 	cmp	x21, x0
    787c:	540026c2 	b.cs	7d54 <fwp_write+0x9d4>  // b.hs, b.nlast
    7880:	d2800042 	mov	x2, #0x2                   	// #2
    7884:	aa1603e1 	mov	x1, x22
    7888:	aa1403e0 	mov	x0, x20
    788c:	97ffeee1 	bl	3410 <buf_put>
    7890:	f9401f82 	ldr	x2, [x28, #56]
    7894:	f9400263 	ldr	x3, [x19]
    7898:	b5fffba2 	cbnz	x2, 780c <fwp_write+0x48c>
    789c:	d37df2a0 	lsl	x0, x21, #3
    78a0:	b7f83f03 	tbnz	x3, #63, 8080 <fwp_write+0xd00>
    78a4:	91002261 	add	x1, x19, #0x8
    78a8:	8b000020 	add	x0, x1, x0
    78ac:	f9400001 	ldr	x1, [x0]
    78b0:	17ffffec 	b	7860 <fwp_write+0x4e0>
    78b4:	a9400e62 	ldp	x2, x3, [x19]
    78b8:	b7f83ca3 	tbnz	x3, #63, 804c <fwp_write+0xccc>
    78bc:	910123f5 	add	x21, sp, #0x48
    78c0:	aa1503e0 	mov	x0, x21
    78c4:	97ffed57 	bl	2e20 <fwp_fmt_u128>
    78c8:	aa1503e0 	mov	x0, x21
    78cc:	97ffeb91 	bl	2710 <strlen@plt>
    78d0:	aa1503e1 	mov	x1, x21
    78d4:	aa0003e2 	mov	x2, x0
    78d8:	17fffed0 	b	7418 <fwp_write+0x98>
    78dc:	fd015be8 	str	d8, [sp, #688]
    78e0:	1e270268 	fmov	s8, w19
    78e4:	fd015fe9 	str	d9, [sp, #696]
    78e8:	1e282100 	fcmp	s8, s8
    78ec:	54004d26 	b.vs	8290 <fwp_write+0xf10>
    78f0:	1e20c101 	fabs	s1, s8
    78f4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    78f8:	1e270000 	fmov	s0, w0
    78fc:	1e202020 	fcmp	s1, s0
    7900:	54002c0d 	b.le	7e80 <fwp_write+0xb00>
    7904:	1e202118 	fcmpe	s8, #0.0
    7908:	d0000022 	adrp	x2, d000 <__modti3+0x2a0>
    790c:	91048042 	add	x2, x2, #0x120
    7910:	910123f5 	add	x21, sp, #0x48
    7914:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7918:	9113e021 	add	x1, x1, #0x4f8
    791c:	aa1503e0 	mov	x0, x21
    7920:	9a81c041 	csel	x1, x2, x1, gt
    7924:	97ffec27 	bl	29c0 <strcpy@plt>
    7928:	aa1503e0 	mov	x0, x21
    792c:	97ffeb79 	bl	2710 <strlen@plt>
    7930:	aa1503e1 	mov	x1, x21
    7934:	aa0003e2 	mov	x2, x0
    7938:	aa1403e0 	mov	x0, x20
    793c:	97ffeeb5 	bl	3410 <buf_put>
    7940:	f9413bf5 	ldr	x21, [sp, #624]
    7944:	f9413ff6 	ldr	x22, [sp, #632]
    7948:	f94153fb 	ldr	x27, [sp, #672]
    794c:	f94157fc 	ldr	x28, [sp, #680]
    7950:	fd415be8 	ldr	d8, [sp, #688]
    7954:	fd415fe9 	ldr	d9, [sp, #696]
    7958:	17fffeb6 	b	7430 <fwp_write+0xb0>
    795c:	f9400276 	ldr	x22, [x19]
    7960:	34002e03 	cbz	w3, 7f20 <fwp_write+0xba0>
    7964:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7968:	f947f400 	ldr	x0, [x0, #4072]
    796c:	f94127e2 	ldr	x2, [sp, #584]
    7970:	f9400001 	ldr	x1, [x0]
    7974:	eb010042 	subs	x2, x2, x1
    7978:	d2800001 	mov	x1, #0x0                   	// #0
    797c:	540014a1 	b.ne	7c10 <fwp_write+0x890>  // b.any
    7980:	aa1603e2 	mov	x2, x22
    7984:	91002261 	add	x1, x19, #0x8
    7988:	f9413bf5 	ldr	x21, [sp, #624]
    798c:	aa1403e0 	mov	x0, x20
    7990:	f9413ff6 	ldr	x22, [sp, #632]
    7994:	17fffeff 	b	7590 <fwp_write+0x210>
    7998:	fd015be8 	str	d8, [sp, #688]
    799c:	9e670268 	fmov	d8, x19
    79a0:	fd015fe9 	str	d9, [sp, #696]
    79a4:	1e682100 	fcmp	d8, d8
    79a8:	54004746 	b.vs	8290 <fwp_write+0xf10>
    79ac:	1e60c101 	fabs	d1, d8
    79b0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    79b4:	9e670000 	fmov	d0, x0
    79b8:	910123f5 	add	x21, sp, #0x48
    79bc:	52800033 	mov	w19, #0x1                   	// #1
    79c0:	1e602020 	fcmp	d1, d0
    79c4:	540001ad 	b.le	79f8 <fwp_write+0x678>
    79c8:	1e602118 	fcmpe	d8, #0.0
    79cc:	d0000022 	adrp	x2, d000 <__modti3+0x2a0>
    79d0:	91048042 	add	x2, x2, #0x120
    79d4:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    79d8:	9113e021 	add	x1, x1, #0x4f8
    79dc:	aa1503e0 	mov	x0, x21
    79e0:	9a81c041 	csel	x1, x2, x1, gt
    79e4:	97ffebf7 	bl	29c0 <strcpy@plt>
    79e8:	17ffffd0 	b	7928 <fwp_write+0x5a8>
    79ec:	11000673 	add	w19, w19, #0x1
    79f0:	71004a7f 	cmp	w19, #0x12
    79f4:	54003860 	b.eq	8100 <fwp_write+0xd80>  // b.none
    79f8:	1e604100 	fmov	d0, d8
    79fc:	2a1303e1 	mov	w1, w19
    7a00:	aa1503e0 	mov	x0, x21
    7a04:	97ffeedf 	bl	3580 <fwp_format_g.constprop.0>
    7a08:	aa1503e0 	mov	x0, x21
    7a0c:	d2800001 	mov	x1, #0x0                   	// #0
    7a10:	97ffeb54 	bl	2760 <strtod@plt>
    7a14:	1e602100 	fcmp	d8, d0
    7a18:	54fffea1 	b.ne	79ec <fwp_write+0x66c>  // b.any
    7a1c:	aa1503e0 	mov	x0, x21
    7a20:	97ffeeb5 	bl	34f4 <fwp_finish_float>
    7a24:	17ffffc1 	b	7928 <fwp_write+0x5a8>
    7a28:	a9400e62 	ldp	x2, x3, [x19]
    7a2c:	910123f3 	add	x19, sp, #0x48
    7a30:	aa1303e0 	mov	x0, x19
    7a34:	97ffecfb 	bl	2e20 <fwp_fmt_u128>
    7a38:	17fffe74 	b	7408 <fwp_write+0x88>
    7a3c:	f90143f7 	str	x23, [sp, #640]
    7a40:	f90147f8 	str	x24, [sp, #648]
    7a44:	2a1303f8 	mov	w24, w19
    7a48:	f9014bf9 	str	x25, [sp, #656]
    7a4c:	f9014ffa 	str	x26, [sp, #664]
    7a50:	f13ffe7f 	cmp	x19, #0xfff
    7a54:	54000049 	b.ls	7a5c <fwp_write+0x6dc>  // b.plast
    7a58:	b9400278 	ldr	w24, [x19]
    7a5c:	f9400f80 	ldr	x0, [x28, #24]
    7a60:	2a1803f5 	mov	w21, w24
    7a64:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7a68:	d37ef6b9 	lsl	x25, x21, #2
    7a6c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7a70:	aa1603e0 	mov	x0, x22
    7a74:	97ffeb27 	bl	2710 <strlen@plt>
    7a78:	aa1603e1 	mov	x1, x22
    7a7c:	aa0003e2 	mov	x2, x0
    7a80:	aa1403e0 	mov	x0, x20
    7a84:	97ffee63 	bl	3410 <buf_put>
    7a88:	f9401780 	ldr	x0, [x28, #40]
    7a8c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7a90:	7100001f 	cmp	w0, #0x0
    7a94:	5400068d 	b.le	7b64 <fwp_write+0x7e4>
    7a98:	91002276 	add	x22, x19, #0x8
    7a9c:	91001ff5 	add	x21, sp, #0x7
    7aa0:	d280001b 	mov	x27, #0x0                   	// #0
    7aa4:	5280041a 	mov	w26, #0x20                  	// #32
    7aa8:	f9401b80 	ldr	x0, [x28, #48]
    7aac:	aa1503e1 	mov	x1, x21
    7ab0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7ab4:	d2800022 	mov	x2, #0x1                   	// #1
    7ab8:	f8786803 	ldr	x3, [x0, x24]
    7abc:	aa1403e0 	mov	x0, x20
    7ac0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7ac4:	39001ffa 	strb	w26, [sp, #7]
    7ac8:	97ffee52 	bl	3410 <buf_put>
    7acc:	f13ffeff 	cmp	x23, #0xfff
    7ad0:	b9400261 	ldr	w1, [x19]
    7ad4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7ad8:	7100383f 	cmp	w1, #0xe
    7adc:	54000160 	b.eq	7b08 <fwp_write+0x788>  // b.none
    7ae0:	7100403f 	cmp	w1, #0x10
    7ae4:	54001a60 	b.eq	7e30 <fwp_write+0xab0>  // b.none
    7ae8:	7100283f 	cmp	w1, #0xa
    7aec:	54002aa0 	b.eq	8040 <fwp_write+0xcc0>  // b.none
    7af0:	540014ac 	b.gt	7d84 <fwp_write+0xa04>
    7af4:	71000c3f 	cmp	w1, #0x3
    7af8:	540029ac 	b.gt	802c <fwp_write+0xcac>
    7afc:	d37ffee0 	lsr	x0, x23, #63
    7b00:	37f814a1 	tbnz	w1, #31, 7d94 <fwp_write+0xa14>
    7b04:	d503201f 	nop
    7b08:	34001460 	cbz	w0, 7d94 <fwp_write+0xa14>
    7b0c:	52800503 	mov	w3, #0x28                  	// #40
    7b10:	aa1503e1 	mov	x1, x21
    7b14:	aa1403e0 	mov	x0, x20
    7b18:	d2800022 	mov	x2, #0x1                   	// #1
    7b1c:	39001fe3 	strb	w3, [sp, #7]
    7b20:	97ffee3c 	bl	3410 <buf_put>
    7b24:	aa1303e2 	mov	x2, x19
    7b28:	aa1703e1 	mov	x1, x23
    7b2c:	aa1403e0 	mov	x0, x20
    7b30:	52800003 	mov	w3, #0x0                   	// #0
    7b34:	97fffe13 	bl	7380 <fwp_write>
    7b38:	52800523 	mov	w3, #0x29                  	// #41
    7b3c:	aa1503e1 	mov	x1, x21
    7b40:	aa1403e0 	mov	x0, x20
    7b44:	d2800022 	mov	x2, #0x1                   	// #1
    7b48:	39001fe3 	strb	w3, [sp, #7]
    7b4c:	97ffee31 	bl	3410 <buf_put>
    7b50:	f9401780 	ldr	x0, [x28, #40]
    7b54:	9100077b 	add	x27, x27, #0x1
    7b58:	b8796800 	ldr	w0, [x0, x25]
    7b5c:	6b1b001f 	cmp	w0, w27
    7b60:	54fffa4c 	b.gt	7aa8 <fwp_write+0x728>
    7b64:	f9413bf5 	ldr	x21, [sp, #624]
    7b68:	f9413ff6 	ldr	x22, [sp, #632]
    7b6c:	f94143f7 	ldr	x23, [sp, #640]
    7b70:	f94147f8 	ldr	x24, [sp, #648]
    7b74:	f9414bf9 	ldr	x25, [sp, #656]
    7b78:	f9414ffa 	ldr	x26, [sp, #664]
    7b7c:	f94153fb 	ldr	x27, [sp, #672]
    7b80:	f94157fc 	ldr	x28, [sp, #680]
    7b84:	17fffe2b 	b	7430 <fwp_write+0xb0>
    7b88:	52800783 	mov	w3, #0x3c                  	// #60
    7b8c:	91001ff3 	add	x19, sp, #0x7
    7b90:	aa1303e1 	mov	x1, x19
    7b94:	d2800022 	mov	x2, #0x1                   	// #1
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	39001fe3 	strb	w3, [sp, #7]
    7ba0:	97ffee1c 	bl	3410 <buf_put>
    7ba4:	f9400795 	ldr	x21, [x28, #8]
    7ba8:	aa1503e0 	mov	x0, x21
    7bac:	97ffead9 	bl	2710 <strlen@plt>
    7bb0:	aa1503e1 	mov	x1, x21
    7bb4:	aa0003e2 	mov	x2, x0
    7bb8:	aa1403e0 	mov	x0, x20
    7bbc:	97ffee15 	bl	3410 <buf_put>
    7bc0:	528007c3 	mov	w3, #0x3e                  	// #62
    7bc4:	aa1303e1 	mov	x1, x19
    7bc8:	aa1403e0 	mov	x0, x20
    7bcc:	d2800022 	mov	x2, #0x1                   	// #1
    7bd0:	39001fe3 	strb	w3, [sp, #7]
    7bd4:	17fffe12 	b	741c <fwp_write+0x9c>
    7bd8:	f100067f 	cmp	x19, #0x1
    7bdc:	540025a0 	b.eq	8090 <fwp_write+0xd10>  // b.none
    7be0:	b100067f 	cmn	x19, #0x1
    7be4:	54002bc0 	b.eq	815c <fwp_write+0xddc>  // b.none
    7be8:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7bec:	91140021 	add	x1, x1, #0x500
    7bf0:	d2800022 	mov	x2, #0x1                   	// #1
    7bf4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7bf8:	f947f400 	ldr	x0, [x0, #4072]
    7bfc:	f94127e4 	ldr	x4, [sp, #584]
    7c00:	f9400003 	ldr	x3, [x0]
    7c04:	eb030084 	subs	x4, x4, x3
    7c08:	d2800003 	mov	x3, #0x0                   	// #0
    7c0c:	54ffebe0 	b.eq	7988 <fwp_write+0x608>  // b.none
    7c10:	f90143f7 	str	x23, [sp, #640]
    7c14:	f90147f8 	str	x24, [sp, #648]
    7c18:	f9014bf9 	str	x25, [sp, #656]
    7c1c:	f9014ffa 	str	x26, [sp, #664]
    7c20:	fd015be8 	str	d8, [sp, #688]
    7c24:	fd015fe9 	str	d9, [sp, #696]
    7c28:	97ffeb16 	bl	2880 <__stack_chk_fail@plt>
    7c2c:	52800b63 	mov	w3, #0x5b                  	// #91
    7c30:	91001ff5 	add	x21, sp, #0x7
    7c34:	aa1503e1 	mov	x1, x21
    7c38:	aa1403e0 	mov	x0, x20
    7c3c:	d2800022 	mov	x2, #0x1                   	// #1
    7c40:	d0000036 	adrp	x22, d000 <__modti3+0x2a0>
    7c44:	911682d6 	add	x22, x22, #0x5a0
    7c48:	39001fe3 	strb	w3, [sp, #7]
    7c4c:	97ffedf1 	bl	3410 <buf_put>
    7c50:	b4000273 	cbz	x19, 7c9c <fwp_write+0x91c>
    7c54:	f9400661 	ldr	x1, [x19, #8]
    7c58:	aa1403e0 	mov	x0, x20
    7c5c:	f9401f82 	ldr	x2, [x28, #56]
    7c60:	52800003 	mov	w3, #0x0                   	// #0
    7c64:	97fffdc7 	bl	7380 <fwp_write>
    7c68:	f9400a73 	ldr	x19, [x19, #16]
    7c6c:	b4000193 	cbz	x19, 7c9c <fwp_write+0x91c>
    7c70:	aa1603e1 	mov	x1, x22
    7c74:	aa1403e0 	mov	x0, x20
    7c78:	d2800042 	mov	x2, #0x2                   	// #2
    7c7c:	97ffede5 	bl	3410 <buf_put>
    7c80:	f9400661 	ldr	x1, [x19, #8]
    7c84:	aa1403e0 	mov	x0, x20
    7c88:	f9401f82 	ldr	x2, [x28, #56]
    7c8c:	52800003 	mov	w3, #0x0                   	// #0
    7c90:	97fffdbc 	bl	7380 <fwp_write>
    7c94:	f9400a73 	ldr	x19, [x19, #16]
    7c98:	b5fffed3 	cbnz	x19, 7c70 <fwp_write+0x8f0>
    7c9c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ca0:	aa1503e1 	mov	x1, x21
    7ca4:	aa1403e0 	mov	x0, x20
    7ca8:	d2800022 	mov	x2, #0x1                   	// #1
    7cac:	39001fe3 	strb	w3, [sp, #7]
    7cb0:	17fffddb 	b	741c <fwp_write+0x9c>
    7cb4:	aa1403e0 	mov	x0, x20
    7cb8:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7cbc:	d28000c2 	mov	x2, #0x6                   	// #6
    7cc0:	91164021 	add	x1, x1, #0x590
    7cc4:	97ffedd3 	bl	3410 <buf_put>
    7cc8:	f9400260 	ldr	x0, [x19]
    7ccc:	b40004c0 	cbz	x0, 7d64 <fwp_write+0x9e4>
    7cd0:	910123f5 	add	x21, sp, #0x48
    7cd4:	91002276 	add	x22, x19, #0x8
    7cd8:	f90143f7 	str	x23, [sp, #640]
    7cdc:	d2800017 	mov	x23, #0x0                   	// #0
    7ce0:	f90147f8 	str	x24, [sp, #648]
    7ce4:	d0000038 	adrp	x24, d000 <__modti3+0x2a0>
    7ce8:	91166318 	add	x24, x24, #0x598
    7cec:	f9014bf9 	str	x25, [sp, #656]
    7cf0:	d0000039 	adrp	x25, d000 <__modti3+0x2a0>
    7cf4:	91168339 	add	x25, x25, #0x5a0
    7cf8:	f9014ffa 	str	x26, [sp, #664]
    7cfc:	14000005 	b	7d10 <fwp_write+0x990>
    7d00:	aa1903e1 	mov	x1, x25
    7d04:	aa1403e0 	mov	x0, x20
    7d08:	d2800042 	mov	x2, #0x2                   	// #2
    7d0c:	97ffedc1 	bl	3410 <buf_put>
    7d10:	38776ac5 	ldrb	w5, [x22, x23]
    7d14:	d2804003 	mov	x3, #0x200                 	// #512
    7d18:	aa1803e4 	mov	x4, x24
    7d1c:	aa0303e1 	mov	x1, x3
    7d20:	52800042 	mov	w2, #0x2                   	// #2
    7d24:	aa1503e0 	mov	x0, x21
    7d28:	910006f7 	add	x23, x23, #0x1
    7d2c:	97ffeab1 	bl	27f0 <__snprintf_chk@plt>
    7d30:	aa1503e0 	mov	x0, x21
    7d34:	97ffea77 	bl	2710 <strlen@plt>
    7d38:	aa1503e1 	mov	x1, x21
    7d3c:	aa0003e2 	mov	x2, x0
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	97ffedb3 	bl	3410 <buf_put>
    7d48:	f9400260 	ldr	x0, [x19]
    7d4c:	eb17001f 	cmp	x0, x23
    7d50:	54fffd88 	b.hi	7d00 <fwp_write+0x980>  // b.pmore
    7d54:	f94143f7 	ldr	x23, [sp, #640]
    7d58:	f94147f8 	ldr	x24, [sp, #648]
    7d5c:	f9414bf9 	ldr	x25, [sp, #656]
    7d60:	f9414ffa 	ldr	x26, [sp, #664]
    7d64:	52800ba3 	mov	w3, #0x5d                  	// #93
    7d68:	aa1403e0 	mov	x0, x20
    7d6c:	91001fe1 	add	x1, sp, #0x7
    7d70:	d2800022 	mov	x2, #0x1                   	// #1
    7d74:	39001fe3 	strb	w3, [sp, #7]
    7d78:	17fffda9 	b	741c <fwp_write+0x9c>
    7d7c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d80:	17fffe44 	b	7690 <fwp_write+0x310>
    7d84:	f10002ff 	cmp	x23, #0x0
    7d88:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d8c:	71002c3f 	cmp	w1, #0xb
    7d90:	54ffebc0 	b.eq	7b08 <fwp_write+0x788>  // b.none
    7d94:	aa1303e2 	mov	x2, x19
    7d98:	aa1703e1 	mov	x1, x23
    7d9c:	aa1403e0 	mov	x0, x20
    7da0:	52800003 	mov	w3, #0x0                   	// #0
    7da4:	97fffd77 	bl	7380 <fwp_write>
    7da8:	17ffff6a 	b	7b50 <fwp_write+0x7d0>
    7dac:	aa1403e0 	mov	x0, x20
    7db0:	91001fe1 	add	x1, sp, #0x7
    7db4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7db8:	d2800022 	mov	x2, #0x1                   	// #1
    7dbc:	17fffe38 	b	769c <fwp_write+0x31c>
    7dc0:	a9400281 	ldp	x1, x0, [x20]
    7dc4:	91000800 	add	x0, x0, #0x2
    7dc8:	8b160000 	add	x0, x0, x22
    7dcc:	f9000680 	str	x0, [x20, #8]
    7dd0:	3820683f 	strb	wzr, [x1, x0]
    7dd4:	f9413bf5 	ldr	x21, [sp, #624]
    7dd8:	f9413ff6 	ldr	x22, [sp, #632]
    7ddc:	f94153fb 	ldr	x27, [sp, #672]
    7de0:	f94157fc 	ldr	x28, [sp, #680]
    7de4:	17fffd93 	b	7430 <fwp_write+0xb0>
    7de8:	f9400f80 	ldr	x0, [x28, #24]
    7dec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7df0:	aa1b03e0 	mov	x0, x27
    7df4:	97ffea47 	bl	2710 <strlen@plt>
    7df8:	aa1b03e1 	mov	x1, x27
    7dfc:	aa0003e2 	mov	x2, x0
    7e00:	aa1403e0 	mov	x0, x20
    7e04:	97ffed83 	bl	3410 <buf_put>
    7e08:	aa1903e1 	mov	x1, x25
    7e0c:	aa1403e0 	mov	x0, x20
    7e10:	d2800062 	mov	x2, #0x3                   	// #3
    7e14:	97ffed7f 	bl	3410 <buf_put>
    7e18:	17fffe10 	b	7658 <fwp_write+0x2d8>
    7e1c:	aa1a03e1 	mov	x1, x26
    7e20:	aa1403e0 	mov	x0, x20
    7e24:	d2800042 	mov	x2, #0x2                   	// #2
    7e28:	97ffed7a 	bl	3410 <buf_put>
    7e2c:	17fffe09 	b	7650 <fwp_write+0x2d0>
    7e30:	f9400660 	ldr	x0, [x19, #8]
    7e34:	b4fffb00 	cbz	x0, 7d94 <fwp_write+0xa14>
    7e38:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7e3c:	9116e021 	add	x1, x1, #0x5b8
    7e40:	97ffeab0 	bl	2900 <strcmp@plt>
    7e44:	7100001f 	cmp	w0, #0x0
    7e48:	1a9f07e0 	cset	w0, ne	// ne = any
    7e4c:	17ffff2f 	b	7b08 <fwp_write+0x788>
    7e50:	aa1403e0 	mov	x0, x20
    7e54:	d2800042 	mov	x2, #0x2                   	// #2
    7e58:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7e5c:	9116c021 	add	x1, x1, #0x5b0
    7e60:	97ffed6c 	bl	3410 <buf_put>
    7e64:	91004261 	add	x1, x19, #0x10
    7e68:	aa1403e0 	mov	x0, x20
    7e6c:	f9402382 	ldr	x2, [x28, #64]
    7e70:	52800003 	mov	w3, #0x0                   	// #0
    7e74:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7e78:	97fffd42 	bl	7380 <fwp_write>
    7e7c:	17fffd9c 	b	74ec <fwp_write+0x16c>
    7e80:	1e22c109 	fcvt	d9, s8
    7e84:	910123f5 	add	x21, sp, #0x48
    7e88:	52800033 	mov	w19, #0x1                   	// #1
    7e8c:	d503201f 	nop
    7e90:	1e604120 	fmov	d0, d9
    7e94:	2a1303e1 	mov	w1, w19
    7e98:	aa1503e0 	mov	x0, x21
    7e9c:	97ffedb9 	bl	3580 <fwp_format_g.constprop.0>
    7ea0:	aa1503e0 	mov	x0, x21
    7ea4:	d2800001 	mov	x1, #0x0                   	// #0
    7ea8:	97ffeaa2 	bl	2930 <strtof@plt>
    7eac:	1e202100 	fcmp	s8, s0
    7eb0:	54ffdb60 	b.eq	7a1c <fwp_write+0x69c>  // b.none
    7eb4:	11000673 	add	w19, w19, #0x1
    7eb8:	71002a7f 	cmp	w19, #0xa
    7ebc:	54fffea1 	b.ne	7e90 <fwp_write+0xb10>  // b.any
    7ec0:	1e604120 	fmov	d0, d9
    7ec4:	aa1503e0 	mov	x0, x21
    7ec8:	52800121 	mov	w1, #0x9                   	// #9
    7ecc:	97ffedad 	bl	3580 <fwp_format_g.constprop.0>
    7ed0:	17fffed3 	b	7a1c <fwp_write+0x69c>
    7ed4:	d37ef6a1 	lsl	x1, x21, #2
    7ed8:	b7f81563 	tbnz	x3, #63, 8184 <fwp_write+0xe04>
    7edc:	91002263 	add	x3, x19, #0x8
    7ee0:	8b010061 	add	x1, x3, x1
    7ee4:	b9400023 	ldr	w3, [x1]
    7ee8:	7100081f 	cmp	w0, #0x2
    7eec:	2a0303e1 	mov	w1, w3
    7ef0:	93407c63 	sxtw	x3, w3
    7ef4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ef8:	17fffe5a 	b	7860 <fwp_write+0x4e0>
    7efc:	d37ffaa1 	lsl	x1, x21, #1
    7f00:	b7f81363 	tbnz	x3, #63, 816c <fwp_write+0xdec>
    7f04:	91002263 	add	x3, x19, #0x8
    7f08:	8b010061 	add	x1, x3, x1
    7f0c:	79400021 	ldrh	w1, [x1]
    7f10:	7100041f 	cmp	w0, #0x1
    7f14:	93403c23 	sxth	x3, w1
    7f18:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f1c:	17fffe51 	b	7860 <fwp_write+0x4e0>
    7f20:	52800443 	mov	w3, #0x22                  	// #34
    7f24:	91001ff5 	add	x21, sp, #0x7
    7f28:	91002273 	add	x19, x19, #0x8
    7f2c:	aa1503e1 	mov	x1, x21
    7f30:	aa1403e0 	mov	x0, x20
    7f34:	d2800022 	mov	x2, #0x1                   	// #1
    7f38:	39001fe3 	strb	w3, [sp, #7]
    7f3c:	f90143f7 	str	x23, [sp, #640]
    7f40:	8b160277 	add	x23, x19, x22
    7f44:	f90147f8 	str	x24, [sp, #648]
    7f48:	97ffed32 	bl	3410 <buf_put>
    7f4c:	b4000696 	cbz	x22, 801c <fwp_write+0xc9c>
    7f50:	d0000038 	adrp	x24, d000 <__modti3+0x2a0>
    7f54:	91158318 	add	x24, x24, #0x560
    7f58:	f9014bf9 	str	x25, [sp, #656]
    7f5c:	d0000039 	adrp	x25, d000 <__modti3+0x2a0>
    7f60:	91160339 	add	x25, x25, #0x580
    7f64:	f9014ffa 	str	x26, [sp, #664]
    7f68:	1400000d 	b	7f9c <fwp_write+0xc1c>
    7f6c:	710024bf 	cmp	w5, #0x9
    7f70:	54000460 	b.eq	7ffc <fwp_write+0xc7c>  // b.none
    7f74:	710028bf 	cmp	w5, #0xa
    7f78:	54000a61 	b.ne	80c4 <fwp_write+0xd44>  // b.any
    7f7c:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7f80:	aa1403e0 	mov	x0, x20
    7f84:	9115c021 	add	x1, x1, #0x570
    7f88:	d2800042 	mov	x2, #0x2                   	// #2
    7f8c:	97ffed21 	bl	3410 <buf_put>
    7f90:	91000673 	add	x19, x19, #0x1
    7f94:	eb17027f 	cmp	x19, x23
    7f98:	540003e0 	b.eq	8014 <fwp_write+0xc94>  // b.none
    7f9c:	39400265 	ldrb	w5, [x19]
    7fa0:	710034bf 	cmp	w5, #0xd
    7fa4:	54000180 	b.eq	7fd4 <fwp_write+0xc54>  // b.none
    7fa8:	54fffe29 	b.ls	7f6c <fwp_write+0xbec>  // b.plast
    7fac:	710088bf 	cmp	w5, #0x22
    7fb0:	540001c0 	b.eq	7fe8 <fwp_write+0xc68>  // b.none
    7fb4:	710170bf 	cmp	w5, #0x5c
    7fb8:	54000741 	b.ne	80a0 <fwp_write+0xd20>  // b.any
    7fbc:	aa1403e0 	mov	x0, x20
    7fc0:	d0000021 	adrp	x1, d000 <__modti3+0x2a0>
    7fc4:	d2800042 	mov	x2, #0x2                   	// #2
    7fc8:	9115a021 	add	x1, x1, #0x568
    7fcc:	97ffed11 	bl	3410 <buf_put>
    7fd0:	17fffff0 	b	7f90 <fwp_write+0xc10>
    7fd4:	aa1903e1 	mov	x1, x25
    7fd8:	aa1403e0 	mov	x0, x20
    7fdc:	d2800042 	mov	x2, #0x2                   	// #2
    7fe0:	97ffed0c 	bl	3410 <buf_put>
    7fe4:	17ffffeb 	b	7f90 <fwp_write+0xc10>
    7fe8:	aa1803e1 	mov	x1, x24
    7fec:	aa1403e0 	mov	x0, x20
    7ff0:	d2800042 	mov	x2, #0x2                   	// #2
    7ff4:	97ffed07 	bl	3410 <buf_put>
    7ff8:	17ffffe6 	b	7f90 <fwp_write+0xc10>
    7ffc:	aa1403e0 	mov	x0, x20
    8000:	b0000021 	adrp	x1, d000 <__modti3+0x2a0>
    8004:	d2800042 	mov	x2, #0x2                   	// #2
    8008:	9115e021 	add	x1, x1, #0x578
    800c:	97ffed01 	bl	3410 <buf_put>
    8010:	17ffffe0 	b	7f90 <fwp_write+0xc10>
    8014:	f9414bf9 	ldr	x25, [sp, #656]
    8018:	f9414ffa 	ldr	x26, [sp, #664]
    801c:	aa1503e1 	mov	x1, x21
    8020:	aa1403e0 	mov	x0, x20
    8024:	52800443 	mov	w3, #0x22                  	// #34
    8028:	17fffd9c 	b	7698 <fwp_write+0x318>
    802c:	7100103f 	cmp	w1, #0x4
    8030:	54ffeb21 	b.ne	7d94 <fwp_write+0xa14>  // b.any
    8034:	f94006e0 	ldr	x0, [x23, #8]
    8038:	d37ffc00 	lsr	x0, x0, #63
    803c:	17fffeb3 	b	7b08 <fwp_write+0x788>
    8040:	710002ff 	cmp	w23, #0x0
    8044:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8048:	17fffeb0 	b	7b08 <fwp_write+0x788>
    804c:	528005a1 	mov	w1, #0x2d                  	// #45
    8050:	eb0203e2 	negs	x2, x2
    8054:	da0303e3 	ngc	x3, x3
    8058:	910127e0 	add	x0, sp, #0x49
    805c:	910123f5 	add	x21, sp, #0x48
    8060:	390123e1 	strb	w1, [sp, #72]
    8064:	97ffeb6f 	bl	2e20 <fwp_fmt_u128>
    8068:	17fffe18 	b	78c8 <fwp_write+0x548>
    806c:	d37ceea1 	lsl	x1, x21, #4
    8070:	b7f810a3 	tbnz	x3, #63, 8284 <fwp_write+0xf04>
    8074:	91002260 	add	x0, x19, #0x8
    8078:	8b010001 	add	x1, x0, x1
    807c:	17fffdf9 	b	7860 <fwp_write+0x4e0>
    8080:	f9400a61 	ldr	x1, [x19, #16]
    8084:	8b010000 	add	x0, x0, x1
    8088:	f9400001 	ldr	x1, [x0]
    808c:	17fffdf5 	b	7860 <fwp_write+0x4e0>
    8090:	b0000021 	adrp	x1, d000 <__modti3+0x2a0>
    8094:	d2800042 	mov	x2, #0x2                   	// #2
    8098:	91142021 	add	x1, x1, #0x508
    809c:	17fffed6 	b	7bf4 <fwp_write+0x874>
    80a0:	7101fcbf 	cmp	w5, #0x7f
    80a4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    80a8:	540000e9 	b.ls	80c4 <fwp_write+0xd44>  // b.plast
    80ac:	aa1503e1 	mov	x1, x21
    80b0:	aa1403e0 	mov	x0, x20
    80b4:	d2800022 	mov	x2, #0x1                   	// #1
    80b8:	39001fe5 	strb	w5, [sp, #7]
    80bc:	97ffecd5 	bl	3410 <buf_put>
    80c0:	17ffffb4 	b	7f90 <fwp_write+0xc10>
    80c4:	d2800203 	mov	x3, #0x10                  	// #16
    80c8:	b0000024 	adrp	x4, d000 <__modti3+0x2a0>
    80cc:	aa0303e1 	mov	x1, x3
    80d0:	91162084 	add	x4, x4, #0x588
    80d4:	910123f6 	add	x22, sp, #0x48
    80d8:	52800042 	mov	w2, #0x2                   	// #2
    80dc:	aa1603e0 	mov	x0, x22
    80e0:	97ffe9c4 	bl	27f0 <__snprintf_chk@plt>
    80e4:	aa1603e0 	mov	x0, x22
    80e8:	97ffe98a 	bl	2710 <strlen@plt>
    80ec:	aa1603e1 	mov	x1, x22
    80f0:	aa0003e2 	mov	x2, x0
    80f4:	aa1403e0 	mov	x0, x20
    80f8:	97ffecc6 	bl	3410 <buf_put>
    80fc:	17ffffa5 	b	7f90 <fwp_write+0xc10>
    8100:	1e604100 	fmov	d0, d8
    8104:	aa1503e0 	mov	x0, x21
    8108:	52800221 	mov	w1, #0x11                  	// #17
    810c:	97ffed1d 	bl	3580 <fwp_format_g.constprop.0>
    8110:	17fffe43 	b	7a1c <fwp_write+0x69c>
    8114:	b9401040 	ldr	w0, [x2, #16]
    8118:	350003c0 	cbnz	w0, 8190 <fwp_write+0xe10>
    811c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8120:	f947f400 	ldr	x0, [x0, #4072]
    8124:	f94127e2 	ldr	x2, [sp, #584]
    8128:	f9400001 	ldr	x1, [x0]
    812c:	eb010042 	subs	x2, x2, x1
    8130:	d2800001 	mov	x1, #0x0                   	// #0
    8134:	54ffd721 	b.ne	7c18 <fwp_write+0x898>  // b.any
    8138:	f9413bf5 	ldr	x21, [sp, #624]
    813c:	b0000021 	adrp	x1, d000 <__modti3+0x2a0>
    8140:	f9413ff6 	ldr	x22, [sp, #632]
    8144:	aa1403e0 	mov	x0, x20
    8148:	f94143f7 	ldr	x23, [sp, #640]
    814c:	91176021 	add	x1, x1, #0x5d8
    8150:	f94147f8 	ldr	x24, [sp, #648]
    8154:	d2800042 	mov	x2, #0x2                   	// #2
    8158:	17fffd0e 	b	7590 <fwp_write+0x210>
    815c:	b0000021 	adrp	x1, d000 <__modti3+0x2a0>
    8160:	d2800042 	mov	x2, #0x2                   	// #2
    8164:	91144021 	add	x1, x1, #0x510
    8168:	17fffea3 	b	7bf4 <fwp_write+0x874>
    816c:	f9400a63 	ldr	x3, [x19, #16]
    8170:	8b030021 	add	x1, x1, x3
    8174:	17ffff66 	b	7f0c <fwp_write+0xb8c>
    8178:	f9400a61 	ldr	x1, [x19, #16]
    817c:	8b0102a1 	add	x1, x21, x1
    8180:	17fffdb3 	b	784c <fwp_write+0x4cc>
    8184:	f9400a63 	ldr	x3, [x19, #16]
    8188:	8b030021 	add	x1, x1, x3
    818c:	17ffff56 	b	7ee4 <fwp_write+0xb64>
    8190:	b9404840 	ldr	w0, [x2, #72]
    8194:	91001ff5 	add	x21, sp, #0x7
    8198:	34ffa360 	cbz	w0, 7604 <fwp_write+0x284>
    819c:	52800503 	mov	w3, #0x28                  	// #40
    81a0:	aa1403e0 	mov	x0, x20
    81a4:	aa1503e1 	mov	x1, x21
    81a8:	d2800022 	mov	x2, #0x1                   	// #1
    81ac:	39001fe3 	strb	w3, [sp, #7]
    81b0:	97ffec98 	bl	3410 <buf_put>
    81b4:	b9401380 	ldr	w0, [x28, #16]
    81b8:	52800038 	mov	w24, #0x1                   	// #1
    81bc:	7100001f 	cmp	w0, #0x0
    81c0:	54ffa36c 	b.gt	762c <fwp_write+0x2ac>
    81c4:	17fffd32 	b	768c <fwp_write+0x30c>
    81c8:	f9014bf9 	str	x25, [sp, #656]
    81cc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xeee0>
    81d0:	f9014ffa 	str	x26, [sp, #664]
    81d4:	f9400676 	ldr	x22, [x19, #8]
    81d8:	910aa333 	add	x19, x25, #0x2a8
    81dc:	91002273 	add	x19, x19, #0x8
    81e0:	937ffed8 	asr	x24, x22, #63
    81e4:	aa1802c0 	orr	x0, x22, x24
    81e8:	b5000320 	cbnz	x0, 824c <fwp_write+0xecc>
    81ec:	110006b5 	add	w21, w21, #0x1
    81f0:	710016bf 	cmp	w21, #0x5
    81f4:	54ffffc1 	b.ne	81ec <fwp_write+0xe6c>  // b.any
    81f8:	b7f80578 	tbnz	x24, #63, 82a4 <fwp_write+0xf24>
    81fc:	910023f3 	add	x19, sp, #0x8
    8200:	aa1603e2 	mov	x2, x22
    8204:	aa1303e0 	mov	x0, x19
    8208:	d2800003 	mov	x3, #0x0                   	// #0
    820c:	97ffeb05 	bl	2e20 <fwp_fmt_u128>
    8210:	910123f5 	add	x21, sp, #0x48
    8214:	b0000023 	adrp	x3, d000 <__modti3+0x2a0>
    8218:	aa1303e4 	mov	x4, x19
    821c:	aa1503e0 	mov	x0, x21
    8220:	91174063 	add	x3, x3, #0x5d0
    8224:	d2804002 	mov	x2, #0x200                 	// #512
    8228:	52800041 	mov	w1, #0x2                   	// #2
    822c:	97ffe93d 	bl	2720 <__sprintf_chk@plt>
    8230:	aa1503e0 	mov	x0, x21
    8234:	97ffe937 	bl	2710 <strlen@plt>
    8238:	aa1503e1 	mov	x1, x21
    823c:	aa0003e2 	mov	x2, x0
    8240:	aa1403e0 	mov	x0, x20
    8244:	97ffec73 	bl	3410 <buf_put>
    8248:	17fffe47 	b	7b64 <fwp_write+0x7e4>
    824c:	f9400277 	ldr	x23, [x19]
    8250:	aa1603e0 	mov	x0, x22
    8254:	aa1803e1 	mov	x1, x24
    8258:	aa1703e2 	mov	x2, x23
    825c:	937ffefa 	asr	x26, x23, #63
    8260:	aa1a03e3 	mov	x3, x26
    8264:	940012bf 	bl	cd60 <__modti3>
    8268:	aa010000 	orr	x0, x0, x1
    826c:	b40002c0 	cbz	x0, 82c4 <fwp_write+0xf44>
    8270:	110006b5 	add	w21, w21, #0x1
    8274:	91004273 	add	x19, x19, #0x10
    8278:	710016bf 	cmp	w21, #0x5
    827c:	54fffe81 	b.ne	824c <fwp_write+0xecc>  // b.any
    8280:	17ffffde 	b	81f8 <fwp_write+0xe78>
    8284:	f9400a60 	ldr	x0, [x19, #16]
    8288:	8b000021 	add	x1, x1, x0
    828c:	17fffd75 	b	7860 <fwp_write+0x4e0>
    8290:	528c29c0 	mov	w0, #0x614e                	// #24910
    8294:	910123f5 	add	x21, sp, #0x48
    8298:	72a009c0 	movk	w0, #0x4e, lsl #16
    829c:	b9004be0 	str	w0, [sp, #72]
    82a0:	17fffda2 	b	7928 <fwp_write+0x5a8>
    82a4:	528005a1 	mov	w1, #0x2d                  	// #45
    82a8:	eb1603e2 	negs	x2, x22
    82ac:	da1803e3 	ngc	x3, x24
    82b0:	910027e0 	add	x0, sp, #0x9
    82b4:	910023f3 	add	x19, sp, #0x8
    82b8:	390023e1 	strb	w1, [sp, #8]
    82bc:	97ffead9 	bl	2e20 <fwp_fmt_u128>
    82c0:	17ffffd4 	b	8210 <fwp_write+0xe90>
    82c4:	aa1703e2 	mov	x2, x23
    82c8:	aa1a03e3 	mov	x3, x26
    82cc:	aa1603e0 	mov	x0, x22
    82d0:	aa1803e1 	mov	x1, x24
    82d4:	940011c3 	bl	c9e0 <__divti3>
    82d8:	aa0003e2 	mov	x2, x0
    82dc:	aa0103e3 	mov	x3, x1
    82e0:	b7f80201 	tbnz	x1, #63, 8320 <fwp_write+0xfa0>
    82e4:	910023f3 	add	x19, sp, #0x8
    82e8:	aa1303e0 	mov	x0, x19
    82ec:	97ffeacd 	bl	2e20 <fwp_fmt_u128>
    82f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    82f4:	910aa339 	add	x25, x25, #0x2a8
    82f8:	910123f5 	add	x21, sp, #0x48
    82fc:	aa1303e4 	mov	x4, x19
    8300:	aa1503e0 	mov	x0, x21
    8304:	b0000023 	adrp	x3, d000 <__modti3+0x2a0>
    8308:	f8616b25 	ldr	x5, [x25, x1]
    830c:	91172063 	add	x3, x3, #0x5c8
    8310:	d2804002 	mov	x2, #0x200                 	// #512
    8314:	52800041 	mov	w1, #0x2                   	// #2
    8318:	97ffe902 	bl	2720 <__sprintf_chk@plt>
    831c:	17ffffc5 	b	8230 <fwp_write+0xeb0>
    8320:	528005a4 	mov	w4, #0x2d                  	// #45
    8324:	eb0003e2 	negs	x2, x0
    8328:	da0103e3 	ngc	x3, x1
    832c:	910027e0 	add	x0, sp, #0x9
    8330:	910023f3 	add	x19, sp, #0x8
    8334:	390023e4 	strb	w4, [sp, #8]
    8338:	97ffeaba 	bl	2e20 <fwp_fmt_u128>
    833c:	17ffffed 	b	82f0 <fwp_write+0xf70>
    8340:	f9013bf5 	str	x21, [sp, #624]
    8344:	f9013ff6 	str	x22, [sp, #632]
    8348:	f90143f7 	str	x23, [sp, #640]
    834c:	f90147f8 	str	x24, [sp, #648]
    8350:	f9014bf9 	str	x25, [sp, #656]
    8354:	f9014ffa 	str	x26, [sp, #664]
    8358:	f90153fb 	str	x27, [sp, #672]
    835c:	f90157fc 	str	x28, [sp, #680]
    8360:	fd015be8 	str	d8, [sp, #688]
    8364:	fd015fe9 	str	d9, [sp, #696]
    8368:	97ffe946 	bl	2880 <__stack_chk_fail@plt>
    836c:	d503201f 	nop

0000000000008370 <fwp_hof0.constprop.0>:
    8370:	d105c3ff 	sub	sp, sp, #0x170
    8374:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8378:	f947f442 	ldr	x2, [x2, #4072]
    837c:	a9117bfd 	stp	x29, x30, [sp, #272]
    8380:	910443fd 	add	x29, sp, #0x110
    8384:	a91673fb 	stp	x27, x28, [sp, #352]
    8388:	aa0003fc 	mov	x28, x0
    838c:	f9400040 	ldr	x0, [x2]
    8390:	f90087e0 	str	x0, [sp, #264]
    8394:	d2800000 	mov	x0, #0x0                   	// #0
    8398:	b4003501 	cbz	x1, 8a38 <fwp_hof0.constprop.0+0x6c8>
    839c:	910223e0 	add	x0, sp, #0x88
    83a0:	aa1c03fb 	mov	x27, x28
    83a4:	a91253f3 	stp	x19, x20, [sp, #288]
    83a8:	900000d3 	adrp	x19, 20000 <__data_start>
    83ac:	91004273 	add	x19, x19, #0x10
    83b0:	a9135bf5 	stp	x21, x22, [sp, #304]
    83b4:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    83b8:	900000d5 	adrp	x21, 20000 <__data_start>
    83bc:	a91463f7 	stp	x23, x24, [sp, #320]
    83c0:	9100c2b7 	add	x23, x21, #0x30
    83c4:	d0fffff8 	adrp	x24, 6000 <fwp_closure_drop+0x130>
    83c8:	a9156bf9 	stp	x25, x26, [sp, #336]
    83cc:	911502d9 	add	x25, x22, #0x540
    83d0:	f90003e0 	str	x0, [sp]
    83d4:	910243e0 	add	x0, sp, #0x90
    83d8:	f90007e0 	str	x0, [sp, #8]
    83dc:	f9000fe1 	str	x1, [sp, #24]
    83e0:	f949ef24 	ldr	x4, [x25, #5080]
    83e4:	f949db21 	ldr	x1, [x25, #5040]
    83e8:	d370bc84 	lsl	x4, x4, #16
    83ec:	cb010363 	sub	x3, x27, x1
    83f0:	eb04007f 	cmp	x3, x4
    83f4:	540003e2 	b.cs	8470 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    83f8:	d350fc60 	lsr	x0, x3, #16
    83fc:	f949ff26 	ldr	x6, [x25, #5112]
    8400:	8b000800 	add	x0, x0, x0, lsl #2
    8404:	d37df002 	lsl	x2, x0, #3
    8408:	8b0200c5 	add	x5, x6, x2
    840c:	f94010a0 	ldr	x0, [x5, #32]
    8410:	b4000300 	cbz	x0, 8470 <fwp_hof0.constprop.0+0x100>
    8414:	386268c2 	ldrb	w2, [x6, x2]
    8418:	7100085f 	cmp	w2, #0x2
    841c:	54000da0 	b.eq	85d0 <fwp_hof0.constprop.0+0x260>  // b.none
    8420:	7100045f 	cmp	w2, #0x1
    8424:	54000261 	b.ne	8470 <fwp_hof0.constprop.0+0x100>  // b.any
    8428:	92403c62 	and	x2, x3, #0xffff
    842c:	29430ca6 	ldp	w6, w3, [x5, #24]
    8430:	9b067c42 	mul	x2, x2, x6
    8434:	d360fc42 	lsr	x2, x2, #32
    8438:	eb03005f 	cmp	x2, x3
    843c:	540001a2 	b.cs	8470 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    8440:	8b020000 	add	x0, x0, x2
    8444:	39400002 	ldrb	w2, [x0]
    8448:	34000142 	cbz	w2, 8470 <fwp_hof0.constprop.0+0x100>
    844c:	7103f45f 	cmp	w2, #0xfd
    8450:	54004ec8 	b.hi	8e28 <fwp_hof0.constprop.0+0xab8>  // b.pmore
    8454:	911502c1 	add	x1, x22, #0x540
    8458:	11000442 	add	w2, w2, #0x1
    845c:	39000002 	strb	w2, [x0]
    8460:	aa0103e0 	mov	x0, x1
    8464:	f949d821 	ldr	x1, [x1, #5040]
    8468:	f949ec04 	ldr	x4, [x0, #5080]
    846c:	d370bc84 	lsl	x4, x4, #16
    8470:	9109c31a 	add	x26, x24, #0x270
    8474:	a90267fb 	stp	x27, x25, [sp, #32]
    8478:	aa1b03f9 	mov	x25, x27
    847c:	aa1703fb 	mov	x27, x23
    8480:	d28018c0 	mov	x0, #0xc6                  	// #198
    8484:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    8488:	f9000be0 	str	x0, [sp, #16]
    848c:	f9416360 	ldr	x0, [x27, #704]
    8490:	a9096be0 	stp	x0, x26, [sp, #144]
    8494:	12800002 	mov	w2, #0xffffffff            	// #-1
    8498:	f94003e0 	ldr	x0, [sp]
    849c:	f90053e0 	str	x0, [sp, #160]
    84a0:	f94007e0 	ldr	x0, [sp, #8]
    84a4:	cb010261 	sub	x1, x19, x1
    84a8:	b9008be2 	str	w2, [sp, #136]
    84ac:	f9016360 	str	x0, [x27, #704]
    84b0:	eb04003f 	cmp	x1, x4
    84b4:	54000762 	b.cs	85a0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    84b8:	911502c2 	add	x2, x22, #0x540
    84bc:	d350fc20 	lsr	x0, x1, #16
    84c0:	8b000800 	add	x0, x0, x0, lsl #2
    84c4:	f949fc44 	ldr	x4, [x2, #5112]
    84c8:	d37df000 	lsl	x0, x0, #3
    84cc:	8b000082 	add	x2, x4, x0
    84d0:	f9401054 	ldr	x20, [x2, #32]
    84d4:	b4000674 	cbz	x20, 85a0 <fwp_hof0.constprop.0+0x230>
    84d8:	38606880 	ldrb	w0, [x4, x0]
    84dc:	7100081f 	cmp	w0, #0x2
    84e0:	540007e0 	b.eq	85dc <fwp_hof0.constprop.0+0x26c>  // b.none
    84e4:	7100041f 	cmp	w0, #0x1
    84e8:	540005c1 	b.ne	85a0 <fwp_hof0.constprop.0+0x230>  // b.any
    84ec:	29431046 	ldp	w6, w4, [x2, #24]
    84f0:	92403c20 	and	x0, x1, #0xffff
    84f4:	9b067c00 	mul	x0, x0, x6
    84f8:	d360fc00 	lsr	x0, x0, #32
    84fc:	eb04001f 	cmp	x0, x4
    8500:	54000282 	b.cs	8550 <fwp_hof0.constprop.0+0x1e0>  // b.hs, b.nlast
    8504:	8b000280 	add	x0, x20, x0
    8508:	39400004 	ldrb	w4, [x0]
    850c:	34000224 	cbz	w4, 8550 <fwp_hof0.constprop.0+0x1e0>
    8510:	7103f49f 	cmp	w4, #0xfd
    8514:	54004968 	b.hi	8e40 <fwp_hof0.constprop.0+0xad0>  // b.pmore
    8518:	11000484 	add	w4, w4, #0x1
    851c:	39000004 	strb	w4, [x0]
    8520:	911502c0 	add	x0, x22, #0x540
    8524:	f949d801 	ldr	x1, [x0, #5040]
    8528:	f949ec02 	ldr	x2, [x0, #5080]
    852c:	cb010261 	sub	x1, x19, x1
    8530:	eb02403f 	cmp	x1, x2, lsl #16
    8534:	54000362 	b.cs	85a0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    8538:	f949fc00 	ldr	x0, [x0, #5112]
    853c:	d350fc22 	lsr	x2, x1, #16
    8540:	8b020842 	add	x2, x2, x2, lsl #2
    8544:	8b020c02 	add	x2, x0, x2, lsl #3
    8548:	f9401054 	ldr	x20, [x2, #32]
    854c:	b40002b4 	cbz	x20, 85a0 <fwp_hof0.constprop.0+0x230>
    8550:	39400040 	ldrb	w0, [x2]
    8554:	7100081f 	cmp	w0, #0x2
    8558:	54000600 	b.eq	8618 <fwp_hof0.constprop.0+0x2a8>  // b.none
    855c:	7100041f 	cmp	w0, #0x1
    8560:	54000201 	b.ne	85a0 <fwp_hof0.constprop.0+0x230>  // b.any
    8564:	29430044 	ldp	w4, w0, [x2, #24]
    8568:	92403c21 	and	x1, x1, #0xffff
    856c:	9b047c21 	mul	x1, x1, x4
    8570:	d360fc21 	lsr	x1, x1, #32
    8574:	eb00003f 	cmp	x1, x0
    8578:	54000142 	b.cs	85a0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    857c:	8b010294 	add	x20, x20, x1
    8580:	39400280 	ldrb	w0, [x20]
    8584:	340000e0 	cbz	w0, 85a0 <fwp_hof0.constprop.0+0x230>
    8588:	7100041f 	cmp	w0, #0x1
    858c:	54000300 	b.eq	85ec <fwp_hof0.constprop.0+0x27c>  // b.none
    8590:	7103fc1f 	cmp	w0, #0xff
    8594:	540045a0 	b.eq	8e48 <fwp_hof0.constprop.0+0xad8>  // b.none
    8598:	51000400 	sub	w0, w0, #0x1
    859c:	39000280 	strb	w0, [x20]
    85a0:	b40039f9 	cbz	x25, 8cdc <fwp_hof0.constprop.0+0x96c>
    85a4:	aa1903e0 	mov	x0, x25
    85a8:	d2800001 	mov	x1, #0x0                   	// #0
    85ac:	d503201f 	nop
    85b0:	f9400800 	ldr	x0, [x0, #16]
    85b4:	91000421 	add	x1, x1, #0x1
    85b8:	b5ffffc0 	cbnz	x0, 85b0 <fwp_hof0.constprop.0+0x240>
    85bc:	eb1c003f 	cmp	x1, x28
    85c0:	54000329 	b.ls	8624 <fwp_hof0.constprop.0+0x2b4>  // b.plast
    85c4:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    85c8:	9117a000 	add	x0, x0, #0x5e8
    85cc:	97ffee31 	bl	3e90 <fwp_trap>
    85d0:	72003c7f 	tst	w3, #0xffff
    85d4:	54fff4e1 	b.ne	8470 <fwp_hof0.constprop.0+0x100>  // b.any
    85d8:	17ffff9b 	b	8444 <fwp_hof0.constprop.0+0xd4>
    85dc:	72003c3f 	tst	w1, #0xffff
    85e0:	54fffb81 	b.ne	8550 <fwp_hof0.constprop.0+0x1e0>  // b.any
    85e4:	aa1403e0 	mov	x0, x20
    85e8:	17ffffc8 	b	8508 <fwp_hof0.constprop.0+0x198>
    85ec:	d53bd040 	mrs	x0, tpidr_el0
    85f0:	91400000 	add	x0, x0, #0x0, lsl #12
    85f4:	91004000 	add	x0, x0, #0x10
    85f8:	f9400000 	ldr	x0, [x0]
    85fc:	b4000080 	cbz	x0, 860c <fwp_hof0.constprop.0+0x29c>
    8600:	aa1303e1 	mov	x1, x19
    8604:	97ffef9f 	bl	4480 <fwp_closure_drop_push>
    8608:	17ffffe6 	b	85a0 <fwp_hof0.constprop.0+0x230>
    860c:	aa1303e0 	mov	x0, x19
    8610:	97ffefe1 	bl	4594 <fwp_closure_drop.part.0>
    8614:	17ffffe3 	b	85a0 <fwp_hof0.constprop.0+0x230>
    8618:	72003c3f 	tst	w1, #0xffff
    861c:	54fffc21 	b.ne	85a0 <fwp_hof0.constprop.0+0x230>  // b.any
    8620:	17ffffd8 	b	8580 <fwp_hof0.constprop.0+0x210>
    8624:	aa0103f7 	mov	x23, x1
    8628:	9100c2b4 	add	x20, x21, #0x30
    862c:	b942f680 	ldr	w0, [x20, #756]
    8630:	340021c0 	cbz	w0, 8a68 <fwp_hof0.constprop.0+0x6f8>
    8634:	9100c2a0 	add	x0, x21, #0x30
    8638:	f9404002 	ldr	x2, [x0, #128]
    863c:	f9404c14 	ldr	x20, [x0, #152]
    8640:	eb02029f 	cmp	x20, x2
    8644:	540006aa 	b.ge	8718 <fwp_hof0.constprop.0+0x3a8>  // b.tcont
    8648:	f9401aa1 	ldr	x1, [x21, #48]
    864c:	8b140680 	add	x0, x20, x20, lsl #1
    8650:	528fffc4 	mov	w4, #0x7ffe                	// #32766
    8654:	8b000a80 	add	x0, x20, x0, lsl #2
    8658:	8b000c20 	add	x0, x1, x0, lsl #3
    865c:	d503201f 	nop
    8660:	b9400401 	ldr	w1, [x0, #4]
    8664:	35000081 	cbnz	w1, 8674 <fwp_hof0.constprop.0+0x304>
    8668:	b9400001 	ldr	w1, [x0]
    866c:	6b04003f 	cmp	w1, w4
    8670:	54000549 	b.ls	8718 <fwp_hof0.constprop.0+0x3a8>  // b.plast
    8674:	91000694 	add	x20, x20, #0x1
    8678:	9101a000 	add	x0, x0, #0x68
    867c:	eb02029f 	cmp	x20, x2
    8680:	54ffff01 	b.ne	8660 <fwp_hof0.constprop.0+0x2f0>  // b.any
    8684:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8688:	eb00005f 	cmp	x2, x0
    868c:	54003c8c 	b.gt	8e1c <fwp_hof0.constprop.0+0xaac>
    8690:	9100c2a0 	add	x0, x21, #0x30
    8694:	f9401aa8 	ldr	x8, [x21, #48]
    8698:	f9404800 	ldr	x0, [x0, #144]
    869c:	eb02001f 	cmp	x0, x2
    86a0:	54000241 	b.ne	86e8 <fwp_hof0.constprop.0+0x378>  // b.any
    86a4:	b4004702 	cbz	x2, 8f84 <fwp_hof0.constprop.0+0xc14>
    86a8:	d37ff844 	lsl	x4, x2, #1
    86ac:	d29fffe0 	mov	x0, #0xffff                	// #65535
    86b0:	eb00009f 	cmp	x4, x0
    86b4:	9a80d084 	csel	x4, x4, x0, le
    86b8:	8b040481 	add	x1, x4, x4, lsl #1
    86bc:	8b010881 	add	x1, x4, x1, lsl #2
    86c0:	d37df021 	lsl	x1, x1, #3
    86c4:	aa0803e0 	mov	x0, x8
    86c8:	a9030be4 	stp	x4, x2, [sp, #48]
    86cc:	97ffe869 	bl	2870 <realloc@plt>
    86d0:	a9430be4 	ldp	x4, x2, [sp, #48]
    86d4:	aa0003e8 	mov	x8, x0
    86d8:	b40071c0 	cbz	x0, 9510 <fwp_hof0.constprop.0+0x11a0>
    86dc:	9100c2a0 	add	x0, x21, #0x30
    86e0:	f9001aa8 	str	x8, [x21, #48]
    86e4:	f9004804 	str	x4, [x0, #144]
    86e8:	8b020440 	add	x0, x2, x2, lsl #1
    86ec:	9100c2a1 	add	x1, x21, #0x30
    86f0:	4f000400 	movi	v0.4s, #0x0
    86f4:	91000444 	add	x4, x2, #0x1
    86f8:	8b000840 	add	x0, x2, x0, lsl #2
    86fc:	f9004024 	str	x4, [x1, #128]
    8700:	8b000d00 	add	x0, x8, x0, lsl #3
    8704:	ad000000 	stp	q0, q0, [x0]
    8708:	ad010000 	stp	q0, q0, [x0, #32]
    870c:	ad020000 	stp	q0, q0, [x0, #64]
    8710:	f900301f 	str	xzr, [x0, #96]
    8714:	14000004 	b	8724 <fwp_hof0.constprop.0+0x3b4>
    8718:	eb02029f 	cmp	x20, x2
    871c:	54fffb40 	b.eq	8684 <fwp_hof0.constprop.0+0x314>  // b.none
    8720:	f9401aa8 	ldr	x8, [x21, #48]
    8724:	8b140684 	add	x4, x20, x20, lsl #1
    8728:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    872c:	91086000 	add	x0, x0, #0x218
    8730:	8b040a84 	add	x4, x20, x4, lsl #2
    8734:	8b040d04 	add	x4, x8, x4, lsl #3
    8738:	a90323e4 	stp	x4, x8, [sp, #48]
    873c:	f900309f 	str	xzr, [x4, #96]
    8740:	97ffe8b4 	bl	2a10 <getenv@plt>
    8744:	a94323e4 	ldp	x4, x8, [sp, #48]
    8748:	b4000080 	cbz	x0, 8758 <fwp_hof0.constprop.0+0x3e8>
    874c:	39400001 	ldrb	w1, [x0]
    8750:	7100c03f 	cmp	w1, #0x30
    8754:	54000720 	b.eq	8838 <fwp_hof0.constprop.0+0x4c8>  // b.none
    8758:	9100c2a0 	add	x0, x21, #0x30
    875c:	f9403801 	ldr	x1, [x0, #112]
    8760:	b50033e1 	cbnz	x1, 8ddc <fwp_hof0.constprop.0+0xa6c>
    8764:	9100c2a0 	add	x0, x21, #0x30
    8768:	2f000400 	mvni	v0.2s, #0x0
    876c:	b9400087 	ldr	w7, [x4]
    8770:	91000689 	add	x9, x20, #0x1
    8774:	52800022 	mov	w2, #0x1                   	// #1
    8778:	a900dc97 	stp	x23, x23, [x4, #8]
    877c:	110004e7 	add	w7, w7, #0x1
    8780:	f9416001 	ldr	x1, [x0, #704]
    8784:	29000887 	stp	w7, w2, [x4]
    8788:	f900289f 	str	xzr, [x4, #80]
    878c:	f9004c09 	str	x9, [x0, #152]
    8790:	fd002c80 	str	d0, [x4, #88]
    8794:	b40031e1 	cbz	x1, 8dd0 <fwp_hof0.constprop.0+0xa60>
    8798:	9109c306 	add	x6, x24, #0x270
    879c:	14000003 	b	87a8 <fwp_hof0.constprop.0+0x438>
    87a0:	f9400021 	ldr	x1, [x1]
    87a4:	b4003161 	cbz	x1, 8dd0 <fwp_hof0.constprop.0+0xa60>
    87a8:	f9400420 	ldr	x0, [x1, #8]
    87ac:	eb06001f 	cmp	x0, x6
    87b0:	54ffff81 	b.ne	87a0 <fwp_hof0.constprop.0+0x430>  // b.any
    87b4:	f9400820 	ldr	x0, [x1, #16]
    87b8:	2a1403e2 	mov	w2, w20
    87bc:	b9400001 	ldr	w1, [x0]
    87c0:	f9002880 	str	x0, [x4, #80]
    87c4:	b9005c81 	str	w1, [x4, #92]
    87c8:	37f80081 	tbnz	w1, #31, 87d8 <fwp_hof0.constprop.0+0x468>
    87cc:	52800d04 	mov	w4, #0x68                  	// #104
    87d0:	9b242021 	smaddl	x1, w1, w4, x8
    87d4:	b9005834 	str	w20, [x1, #88]
    87d8:	b9000002 	str	w2, [x0]
    87dc:	aa1903e0 	mov	x0, x25
    87e0:	d2800002 	mov	x2, #0x0                   	// #0
    87e4:	b4001519 	cbz	x25, 8a84 <fwp_hof0.constprop.0+0x714>
    87e8:	f9400800 	ldr	x0, [x0, #16]
    87ec:	91000442 	add	x2, x2, #0x1
    87f0:	b5ffffc0 	cbnz	x0, 87e8 <fwp_hof0.constprop.0+0x478>
    87f4:	aa1903e1 	mov	x1, x25
    87f8:	f9400821 	ldr	x1, [x1, #16]
    87fc:	91000400 	add	x0, x0, #0x1
    8800:	b5ffffc1 	cbnz	x1, 87f8 <fwp_hof0.constprop.0+0x488>
    8804:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8808:	eb01001f 	cmp	x0, x1
    880c:	54000108 	b.hi	882c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    8810:	f100005f 	cmp	x2, #0x0
    8814:	5400138d 	b.le	8a84 <fwp_hof0.constprop.0+0x714>
    8818:	eb00005f 	cmp	x2, x0
    881c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8820:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8824:	eb0102ff 	cmp	x23, x1
    8828:	540025e9 	b.ls	8ce4 <fwp_hof0.constprop.0+0x974>  // b.plast
    882c:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    8830:	9113a000 	add	x0, x0, #0x4e8
    8834:	97ffed97 	bl	3e90 <fwp_trap>
    8838:	39400400 	ldrb	w0, [x0, #1]
    883c:	34fff940 	cbz	w0, 8764 <fwp_hof0.constprop.0+0x3f4>
    8840:	17ffffc6 	b	8758 <fwp_hof0.constprop.0+0x3e8>
    8844:	f9401be0 	ldr	x0, [sp, #48]
    8848:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xeee0>
    884c:	910aa042 	add	x2, x2, #0x2a8
    8850:	aa1903e1 	mov	x1, x25
    8854:	91014042 	add	x2, x2, #0x50
    8858:	52800023 	mov	w3, #0x1                   	// #1
    885c:	aa1903f4 	mov	x20, x25
    8860:	aa1b03f7 	mov	x23, x27
    8864:	a94267fb 	ldp	x27, x25, [sp, #32]
    8868:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    886c:	f9006bff 	str	xzr, [sp, #208]
    8870:	97fffac4 	bl	7380 <fwp_write>
    8874:	a94c0be3 	ldp	x3, x2, [sp, #192]
    8878:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    887c:	912cc000 	add	x0, x0, #0xb30
    8880:	f100007f 	cmp	x3, #0x0
    8884:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    8888:	b100285f 	cmn	x2, #0xa
    888c:	54008fe8 	b.hi	9a88 <fwp_hof0.constprop.0+0x1718>  // b.pmore
    8890:	91002440 	add	x0, x2, #0x9
    8894:	52800021 	mov	w1, #0x1                   	// #1
    8898:	f9000be2 	str	x2, [sp, #16]
    889c:	f90013e3 	str	x3, [sp, #32]
    88a0:	97fff0f4 	bl	4c70 <fwp_heap_alloc>
    88a4:	f94013e3 	ldr	x3, [sp, #32]
    88a8:	aa0003fa 	mov	x26, x0
    88ac:	f9400be2 	ldr	x2, [sp, #16]
    88b0:	aa0303e1 	mov	x1, x3
    88b4:	aa0003e3 	mov	x3, x0
    88b8:	f90013e2 	str	x2, [sp, #32]
    88bc:	f8008462 	str	x2, [x3], #8
    88c0:	aa0303e0 	mov	x0, x3
    88c4:	f9000be3 	str	x3, [sp, #16]
    88c8:	97ffe782 	bl	26d0 <memcpy@plt>
    88cc:	f94013e2 	ldr	x2, [sp, #32]
    88d0:	8b020342 	add	x2, x26, x2
    88d4:	3900205f 	strb	wzr, [x2, #8]
    88d8:	f94063e0 	ldr	x0, [sp, #192]
    88dc:	97ffe819 	bl	2940 <free@plt>
    88e0:	911502c2 	add	x2, x22, #0x540
    88e4:	f9400be3 	ldr	x3, [sp, #16]
    88e8:	f949d841 	ldr	x1, [x2, #5040]
    88ec:	f949ec40 	ldr	x0, [x2, #5080]
    88f0:	cb010341 	sub	x1, x26, x1
    88f4:	eb00403f 	cmp	x1, x0, lsl #16
    88f8:	54000322 	b.cs	895c <fwp_hof0.constprop.0+0x5ec>  // b.hs, b.nlast
    88fc:	d350fc20 	lsr	x0, x1, #16
    8900:	f949fc45 	ldr	x5, [x2, #5112]
    8904:	8b000800 	add	x0, x0, x0, lsl #2
    8908:	d37df002 	lsl	x2, x0, #3
    890c:	8b0200a4 	add	x4, x5, x2
    8910:	f9401080 	ldr	x0, [x4, #32]
    8914:	b4000240 	cbz	x0, 895c <fwp_hof0.constprop.0+0x5ec>
    8918:	386268a2 	ldrb	w2, [x5, x2]
    891c:	7100085f 	cmp	w2, #0x2
    8920:	54008c60 	b.eq	9aac <fwp_hof0.constprop.0+0x173c>  // b.none
    8924:	7100045f 	cmp	w2, #0x1
    8928:	540001a1 	b.ne	895c <fwp_hof0.constprop.0+0x5ec>  // b.any
    892c:	29430885 	ldp	w5, w2, [x4, #24]
    8930:	92403c21 	and	x1, x1, #0xffff
    8934:	9b057c21 	mul	x1, x1, x5
    8938:	d360fc21 	lsr	x1, x1, #32
    893c:	eb02003f 	cmp	x1, x2
    8940:	540000e2 	b.cs	895c <fwp_hof0.constprop.0+0x5ec>  // b.hs, b.nlast
    8944:	8b010000 	add	x0, x0, x1
    8948:	39400001 	ldrb	w1, [x0]
    894c:	7103fc3f 	cmp	w1, #0xff
    8950:	54008b40 	b.eq	9ab8 <fwp_hof0.constprop.0+0x1748>  // b.none
    8954:	52800021 	mov	w1, #0x1                   	// #1
    8958:	39000001 	strb	w1, [x0]
    895c:	aa1403e0 	mov	x0, x20
    8960:	f9000be3 	str	x3, [sp, #16]
    8964:	97fff4ff 	bl	5d60 <fwp_drop0>
    8968:	9100c2b4 	add	x20, x21, #0x30
    896c:	f9400be3 	ldr	x3, [sp, #16]
    8970:	d2800021 	mov	x1, #0x1                   	// #1
    8974:	f9400342 	ldr	x2, [x26]
    8978:	aa0303e0 	mov	x0, x3
    897c:	f9400683 	ldr	x3, [x20, #8]
    8980:	97ffe800 	bl	2980 <fwrite@plt>
    8984:	f9400681 	ldr	x1, [x20, #8]
    8988:	52800140 	mov	w0, #0xa                   	// #10
    898c:	97ffe785 	bl	27a0 <fputc@plt>
    8990:	911502c2 	add	x2, x22, #0x540
    8994:	f949d841 	ldr	x1, [x2, #5040]
    8998:	f949ec40 	ldr	x0, [x2, #5080]
    899c:	cb010341 	sub	x1, x26, x1
    89a0:	eb00403f 	cmp	x1, x0, lsl #16
    89a4:	54000382 	b.cs	8a14 <fwp_hof0.constprop.0+0x6a4>  // b.hs, b.nlast
    89a8:	d350fc20 	lsr	x0, x1, #16
    89ac:	f949fc44 	ldr	x4, [x2, #5112]
    89b0:	8b000800 	add	x0, x0, x0, lsl #2
    89b4:	d37df002 	lsl	x2, x0, #3
    89b8:	8b020083 	add	x3, x4, x2
    89bc:	f9401074 	ldr	x20, [x3, #32]
    89c0:	b40002b4 	cbz	x20, 8a14 <fwp_hof0.constprop.0+0x6a4>
    89c4:	38626882 	ldrb	w2, [x4, x2]
    89c8:	7100085f 	cmp	w2, #0x2
    89cc:	540086a0 	b.eq	9aa0 <fwp_hof0.constprop.0+0x1730>  // b.none
    89d0:	7100045f 	cmp	w2, #0x1
    89d4:	54000201 	b.ne	8a14 <fwp_hof0.constprop.0+0x6a4>  // b.any
    89d8:	29430062 	ldp	w2, w0, [x3, #24]
    89dc:	92403c21 	and	x1, x1, #0xffff
    89e0:	9b027c21 	mul	x1, x1, x2
    89e4:	d360fc21 	lsr	x1, x1, #32
    89e8:	eb00003f 	cmp	x1, x0
    89ec:	54000142 	b.cs	8a14 <fwp_hof0.constprop.0+0x6a4>  // b.hs, b.nlast
    89f0:	8b010294 	add	x20, x20, x1
    89f4:	39400281 	ldrb	w1, [x20]
    89f8:	340000e1 	cbz	w1, 8a14 <fwp_hof0.constprop.0+0x6a4>
    89fc:	7100043f 	cmp	w1, #0x1
    8a00:	540084a0 	b.eq	9a94 <fwp_hof0.constprop.0+0x1724>  // b.none
    8a04:	7103fc3f 	cmp	w1, #0xff
    8a08:	54008640 	b.eq	9ad0 <fwp_hof0.constprop.0+0x1760>  // b.none
    8a0c:	51000421 	sub	w1, w1, #0x1
    8a10:	39000281 	strb	w1, [x20]
    8a14:	f9400fe0 	ldr	x0, [sp, #24]
    8a18:	f9400800 	ldr	x0, [x0, #16]
    8a1c:	f9000fe0 	str	x0, [sp, #24]
    8a20:	b5ffce00 	cbnz	x0, 83e0 <fwp_hof0.constprop.0+0x70>
    8a24:	a95253f3 	ldp	x19, x20, [sp, #288]
    8a28:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8a2c:	a95463f7 	ldp	x23, x24, [sp, #320]
    8a30:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8a34:	d503201f 	nop
    8a38:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8a3c:	f947f400 	ldr	x0, [x0, #4072]
    8a40:	f94087e2 	ldr	x2, [sp, #264]
    8a44:	f9400001 	ldr	x1, [x0]
    8a48:	eb010042 	subs	x2, x2, x1
    8a4c:	d2800001 	mov	x1, #0x0                   	// #0
    8a50:	54009b01 	b.ne	9db0 <fwp_hof0.constprop.0+0x1a40>  // b.any
    8a54:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8a58:	d2800000 	mov	x0, #0x0                   	// #0
    8a5c:	a95673fb 	ldp	x27, x28, [sp, #352]
    8a60:	9105c3ff 	add	sp, sp, #0x170
    8a64:	d65f03c0 	ret
    8a68:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x130>
    8a6c:	9105c000 	add	x0, x0, #0x170
    8a70:	94001198 	bl	d0d0 <atexit>
    8a74:	350054e0 	cbnz	w0, 9510 <fwp_hof0.constprop.0+0x11a0>
    8a78:	52800020 	mov	w0, #0x1                   	// #1
    8a7c:	b902f680 	str	w0, [x20, #756]
    8a80:	17fffeed 	b	8634 <fwp_hof0.constprop.0+0x2c4>
    8a84:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8a88:	52800041 	mov	w1, #0x2                   	// #2
    8a8c:	aa0900e0 	orr	x0, x7, x9
    8a90:	f9001be0 	str	x0, [sp, #48]
    8a94:	d2800100 	mov	x0, #0x8                   	// #8
    8a98:	97fff076 	bl	4c70 <fwp_heap_alloc>
    8a9c:	aa0003e9 	mov	x9, x0
    8aa0:	911502c0 	add	x0, x22, #0x540
    8aa4:	aa0903ea 	mov	x10, x9
    8aa8:	f900013f 	str	xzr, [x9]
    8aac:	f949d801 	ldr	x1, [x0, #5040]
    8ab0:	f949ec00 	ldr	x0, [x0, #5080]
    8ab4:	cb010121 	sub	x1, x9, x1
    8ab8:	eb00403f 	cmp	x1, x0, lsl #16
    8abc:	540013c2 	b.cs	8d34 <fwp_hof0.constprop.0+0x9c4>  // b.hs, b.nlast
    8ac0:	d2800017 	mov	x23, #0x0                   	// #0
    8ac4:	911502c2 	add	x2, x22, #0x540
    8ac8:	d350fc20 	lsr	x0, x1, #16
    8acc:	8b000800 	add	x0, x0, x0, lsl #2
    8ad0:	f949fc46 	ldr	x6, [x2, #5112]
    8ad4:	d37df002 	lsl	x2, x0, #3
    8ad8:	8b0200c4 	add	x4, x6, x2
    8adc:	f9401094 	ldr	x20, [x4, #32]
    8ae0:	b4000254 	cbz	x20, 8b28 <fwp_hof0.constprop.0+0x7b8>
    8ae4:	386268c2 	ldrb	w2, [x6, x2]
    8ae8:	7100085f 	cmp	w2, #0x2
    8aec:	540012a0 	b.eq	8d40 <fwp_hof0.constprop.0+0x9d0>  // b.none
    8af0:	7100045f 	cmp	w2, #0x1
    8af4:	540001a1 	b.ne	8b28 <fwp_hof0.constprop.0+0x7b8>  // b.any
    8af8:	29430886 	ldp	w6, w2, [x4, #24]
    8afc:	92403c21 	and	x1, x1, #0xffff
    8b00:	9b067c21 	mul	x1, x1, x6
    8b04:	d360fc21 	lsr	x1, x1, #32
    8b08:	eb02003f 	cmp	x1, x2
    8b0c:	540000e2 	b.cs	8b28 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    8b10:	8b010294 	add	x20, x20, x1
    8b14:	39400281 	ldrb	w1, [x20]
    8b18:	7103fc3f 	cmp	w1, #0xff
    8b1c:	540049c0 	b.eq	9454 <fwp_hof0.constprop.0+0x10e4>  // b.none
    8b20:	52800021 	mov	w1, #0x1                   	// #1
    8b24:	39000281 	strb	w1, [x20]
    8b28:	b4000257 	cbz	x23, 8b70 <fwp_hof0.constprop.0+0x800>
    8b2c:	f9401be0 	ldr	x0, [sp, #48]
    8b30:	aa1903e2 	mov	x2, x25
    8b34:	f9400728 	ldr	x8, [x25, #8]
    8b38:	91002124 	add	x4, x9, #0x8
    8b3c:	d3607c07 	lsl	x7, x0, #32
    8b40:	d2800001 	mov	x1, #0x0                   	// #0
    8b44:	aa0703e6 	mov	x6, x7
    8b48:	14000005 	b	8b5c <fwp_hof0.constprop.0+0x7ec>
    8b4c:	f9400448 	ldr	x8, [x2, #8]
    8b50:	ab0100e6 	adds	x6, x7, x1
    8b54:	91004084 	add	x4, x4, #0x10
    8b58:	54009686 	b.vs	9e28 <fwp_hof0.constprop.0+0x1ab8>
    8b5c:	a9001888 	stp	x8, x6, [x4]
    8b60:	91000421 	add	x1, x1, #0x1
    8b64:	f9400842 	ldr	x2, [x2, #16]
    8b68:	eb17003f 	cmp	x1, x23
    8b6c:	54ffff03 	b.cc	8b4c <fwp_hof0.constprop.0+0x7dc>  // b.lo, b.ul, b.last
    8b70:	f9400120 	ldr	x0, [x9]
    8b74:	f100041f 	cmp	x0, #0x1
    8b78:	54000de9 	b.ls	8d34 <fwp_hof0.constprop.0+0x9c4>  // b.plast
    8b7c:	d341fc17 	lsr	x23, x0, #1
    8b80:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8b84:	d10006e0 	sub	x0, x23, #0x1
    8b88:	eb01001f 	cmp	x0, x1
    8b8c:	54ffe508 	b.hi	882c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    8b90:	b4000d20 	cbz	x0, 8d34 <fwp_hof0.constprop.0+0x9c4>
    8b94:	91002134 	add	x20, x9, #0x8
    8b98:	d1002121 	sub	x1, x9, #0x8
    8b9c:	8b171037 	add	x23, x1, x23, lsl #4
    8ba0:	a903cfea 	stp	x10, x19, [sp, #56]
    8ba4:	aa1403f3 	mov	x19, x20
    8ba8:	aa0003f4 	mov	x20, x0
    8bac:	f90027e9 	str	x9, [sp, #72]
    8bb0:	f9400660 	ldr	x0, [x19, #8]
    8bb4:	f9400e61 	ldr	x1, [x19, #24]
    8bb8:	fd400260 	ldr	d0, [x19]
    8bbc:	fd400a61 	ldr	d1, [x19, #16]
    8bc0:	97fff1a8 	bl	5260 <w120>
    8bc4:	a9000660 	stp	x0, x1, [x19]
    8bc8:	91004273 	add	x19, x19, #0x10
    8bcc:	eb17027f 	cmp	x19, x23
    8bd0:	54ffff01 	b.ne	8bb0 <fwp_hof0.constprop.0+0x840>  // b.any
    8bd4:	a94427f3 	ldp	x19, x9, [sp, #64]
    8bd8:	d37ffa81 	lsl	x1, x20, #1
    8bdc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    8be0:	d2800014 	mov	x20, #0x0                   	// #0
    8be4:	aa1703e0 	mov	x0, x23
    8be8:	aa1403f7 	mov	x23, x20
    8bec:	aa0103f4 	mov	x20, x1
    8bf0:	a9046be9 	stp	x9, x26, [sp, #64]
    8bf4:	aa0903e2 	mov	x2, x9
    8bf8:	aa1303fa 	mov	x26, x19
    8bfc:	f8010441 	str	x1, [x2], #16
    8c00:	aa0203f3 	mov	x19, x2
    8c04:	d503201f 	nop
    8c08:	f8777a61 	ldr	x1, [x19, x23, lsl #3]
    8c0c:	91000af7 	add	x23, x23, #0x2
    8c10:	97fff13c 	bl	5100 <f141.constprop.0>
    8c14:	eb1402ff 	cmp	x23, x20
    8c18:	54ffff83 	b.cc	8c08 <fwp_hof0.constprop.0+0x898>  // b.lo, b.ul, b.last
    8c1c:	a943a7ea 	ldp	x10, x9, [sp, #56]
    8c20:	aa1a03f3 	mov	x19, x26
    8c24:	f94027fa 	ldr	x26, [sp, #72]
    8c28:	aa0003f7 	mov	x23, x0
    8c2c:	911502c4 	add	x4, x22, #0x540
    8c30:	aa0403f4 	mov	x20, x4
    8c34:	f949d881 	ldr	x1, [x4, #5040]
    8c38:	f949ec80 	ldr	x0, [x4, #5080]
    8c3c:	cb010121 	sub	x1, x9, x1
    8c40:	eb00403f 	cmp	x1, x0, lsl #16
    8c44:	540003a2 	b.cs	8cb8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8c48:	d350fc20 	lsr	x0, x1, #16
    8c4c:	f949fe86 	ldr	x6, [x20, #5112]
    8c50:	8b000800 	add	x0, x0, x0, lsl #2
    8c54:	d37df002 	lsl	x2, x0, #3
    8c58:	8b0200c3 	add	x3, x6, x2
    8c5c:	f9401060 	ldr	x0, [x3, #32]
    8c60:	b40002c0 	cbz	x0, 8cb8 <fwp_hof0.constprop.0+0x948>
    8c64:	386268c2 	ldrb	w2, [x6, x2]
    8c68:	7100085f 	cmp	w2, #0x2
    8c6c:	54001920 	b.eq	8f90 <fwp_hof0.constprop.0+0xc20>  // b.none
    8c70:	7100045f 	cmp	w2, #0x1
    8c74:	54000221 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    8c78:	29430864 	ldp	w4, w2, [x3, #24]
    8c7c:	92403c21 	and	x1, x1, #0xffff
    8c80:	9b047c21 	mul	x1, x1, x4
    8c84:	d360fc21 	lsr	x1, x1, #32
    8c88:	eb02003f 	cmp	x1, x2
    8c8c:	54000162 	b.cs	8cb8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8c90:	8b010000 	add	x0, x0, x1
    8c94:	39400001 	ldrb	w1, [x0]
    8c98:	34000101 	cbz	w1, 8cb8 <fwp_hof0.constprop.0+0x948>
    8c9c:	7100043f 	cmp	w1, #0x1
    8ca0:	54000560 	b.eq	8d4c <fwp_hof0.constprop.0+0x9dc>  // b.none
    8ca4:	7103fc3f 	cmp	w1, #0xff
    8ca8:	54003ec0 	b.eq	9480 <fwp_hof0.constprop.0+0x1110>  // b.none
    8cac:	51000421 	sub	w1, w1, #0x1
    8cb0:	39000001 	strb	w1, [x0]
    8cb4:	d503201f 	nop
    8cb8:	b98033f4 	ldrsw	x20, [sp, #48]
    8cbc:	aa1403e0 	mov	x0, x20
    8cc0:	97ffee78 	bl	46a0 <fwp_tape_of>
    8cc4:	f9403002 	ldr	x2, [x0, #96]
    8cc8:	aa0003e6 	mov	x6, x0
    8ccc:	b4000f62 	cbz	x2, 8eb8 <fwp_hof0.constprop.0+0xb48>
    8cd0:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    8cd4:	91116000 	add	x0, x0, #0x458
    8cd8:	97ffec6e 	bl	3e90 <fwp_trap>
    8cdc:	d2800017 	mov	x23, #0x0                   	// #0
    8ce0:	17fffe52 	b	8628 <fwp_hof0.constprop.0+0x2b8>
    8ce4:	d37ffae2 	lsl	x2, x23, #1
    8ce8:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8cec:	91000440 	add	x0, x2, #0x1
    8cf0:	aa0900e1 	orr	x1, x7, x9
    8cf4:	aa0203f4 	mov	x20, x2
    8cf8:	f9001be1 	str	x1, [sp, #48]
    8cfc:	d37df000 	lsl	x0, x0, #3
    8d00:	52800041 	mov	w1, #0x2                   	// #2
    8d04:	97ffefdb 	bl	4c70 <fwp_heap_alloc>
    8d08:	aa0003e9 	mov	x9, x0
    8d0c:	911502c1 	add	x1, x22, #0x540
    8d10:	aa0003ea 	mov	x10, x0
    8d14:	aa0103e0 	mov	x0, x1
    8d18:	f9000134 	str	x20, [x9]
    8d1c:	f949d821 	ldr	x1, [x1, #5040]
    8d20:	f949ec00 	ldr	x0, [x0, #5080]
    8d24:	cb010121 	sub	x1, x9, x1
    8d28:	eb00403f 	cmp	x1, x0, lsl #16
    8d2c:	54ffecc3 	b.cc	8ac4 <fwp_hof0.constprop.0+0x754>  // b.lo, b.ul, b.last
    8d30:	b5ffeff7 	cbnz	x23, 8b2c <fwp_hof0.constprop.0+0x7bc>
    8d34:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    8d38:	f900013f 	str	xzr, [x9]
    8d3c:	17ffffbc 	b	8c2c <fwp_hof0.constprop.0+0x8bc>
    8d40:	72003c3f 	tst	w1, #0xffff
    8d44:	54ffef21 	b.ne	8b28 <fwp_hof0.constprop.0+0x7b8>  // b.any
    8d48:	17ffff73 	b	8b14 <fwp_hof0.constprop.0+0x7a4>
    8d4c:	f9400143 	ldr	x3, [x10]
    8d50:	aa0a03e4 	mov	x4, x10
    8d54:	f949ee82 	ldr	x2, [x20, #5080]
    8d58:	f949da81 	ldr	x1, [x20, #5040]
    8d5c:	d370bc47 	lsl	x7, x2, #16
    8d60:	cb010140 	sub	x0, x10, x1
    8d64:	b7f811c3 	tbnz	x3, #63, 8f9c <fwp_hof0.constprop.0+0xc2c>
    8d68:	eb07001f 	cmp	x0, x7
    8d6c:	54fffa62 	b.cs	8cb8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8d70:	d350fc01 	lsr	x1, x0, #16
    8d74:	8b010821 	add	x1, x1, x1, lsl #2
    8d78:	d37df021 	lsl	x1, x1, #3
    8d7c:	8b0100c4 	add	x4, x6, x1
    8d80:	f9401082 	ldr	x2, [x4, #32]
    8d84:	b4fff9a2 	cbz	x2, 8cb8 <fwp_hof0.constprop.0+0x948>
    8d88:	386168c1 	ldrb	w1, [x6, x1]
    8d8c:	7100083f 	cmp	w1, #0x2
    8d90:	540034c0 	b.eq	9428 <fwp_hof0.constprop.0+0x10b8>  // b.none
    8d94:	7100043f 	cmp	w1, #0x1
    8d98:	54fff901 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    8d9c:	29430486 	ldp	w6, w1, [x4, #24]
    8da0:	92403c00 	and	x0, x0, #0xffff
    8da4:	9b067c00 	mul	x0, x0, x6
    8da8:	d360fc00 	lsr	x0, x0, #32
    8dac:	eb01001f 	cmp	x0, x1
    8db0:	54fff842 	b.cs	8cb8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8db4:	8b000042 	add	x2, x2, x0
    8db8:	39400040 	ldrb	w0, [x2]
    8dbc:	7100041f 	cmp	w0, #0x1
    8dc0:	54fff7c1 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    8dc4:	aa0a03e0 	mov	x0, x10
    8dc8:	97ffecee 	bl	4180 <fwp_mem_free>
    8dcc:	17ffffbb 	b	8cb8 <fwp_hof0.constprop.0+0x948>
    8dd0:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    8dd4:	911a2000 	add	x0, x0, #0x688
    8dd8:	97ffec2e 	bl	3e90 <fwp_trap>
    8ddc:	3cc38002 	ldur	q2, [x0, #56]
    8de0:	9100e001 	add	x1, x0, #0x38
    8de4:	3cc48001 	ldur	q1, [x0, #72]
    8de8:	f900381f 	str	xzr, [x0, #112]
    8dec:	4f000400 	movi	v0.4s, #0x0
    8df0:	ad010482 	stp	q2, q1, [x4, #32]
    8df4:	f9403400 	ldr	x0, [x0, #104]
    8df8:	f9002480 	str	x0, [x4, #72]
    8dfc:	f9401020 	ldr	x0, [x1, #32]
    8e00:	f9002080 	str	x0, [x4, #64]
    8e04:	f9401420 	ldr	x0, [x1, #40]
    8e08:	f9000c80 	str	x0, [x4, #24]
    8e0c:	f900183f 	str	xzr, [x1, #48]
    8e10:	ad000020 	stp	q0, q0, [x1]
    8e14:	3d800820 	str	q0, [x1, #32]
    8e18:	17fffe53 	b	8764 <fwp_hof0.constprop.0+0x3f4>
    8e1c:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    8e20:	91182000 	add	x0, x0, #0x608
    8e24:	97ffec1b 	bl	3e90 <fwp_trap>
    8e28:	97ffed4f 	bl	4364 <fwp_rc_wide_dup>
    8e2c:	911502c0 	add	x0, x22, #0x540
    8e30:	f949ec04 	ldr	x4, [x0, #5080]
    8e34:	f949d801 	ldr	x1, [x0, #5040]
    8e38:	d370bc84 	lsl	x4, x4, #16
    8e3c:	17fffd8d 	b	8470 <fwp_hof0.constprop.0+0x100>
    8e40:	97ffed49 	bl	4364 <fwp_rc_wide_dup>
    8e44:	17fffdb7 	b	8520 <fwp_hof0.constprop.0+0x1b0>
    8e48:	ca544680 	eor	x0, x20, x20, lsr #17
    8e4c:	911502c1 	add	x1, x22, #0x540
    8e50:	ca402400 	eor	x0, x0, x0, lsr #9
    8e54:	92401c00 	and	x0, x0, #0xff
    8e58:	910a2402 	add	x2, x0, #0x289
    8e5c:	8b000c20 	add	x0, x1, x0, lsl #3
    8e60:	8b020c22 	add	x2, x1, x2, lsl #3
    8e64:	f94a2400 	ldr	x0, [x0, #5192]
    8e68:	b50000a0 	cbnz	x0, 8e7c <fwp_hof0.constprop.0+0xb0c>
    8e6c:	14000172 	b	9434 <fwp_hof0.constprop.0+0x10c4>
    8e70:	91004002 	add	x2, x0, #0x10
    8e74:	f9400800 	ldr	x0, [x0, #16]
    8e78:	b4002de0 	cbz	x0, 9434 <fwp_hof0.constprop.0+0x10c4>
    8e7c:	f9400001 	ldr	x1, [x0]
    8e80:	eb14003f 	cmp	x1, x20
    8e84:	54ffff61 	b.ne	8e70 <fwp_hof0.constprop.0+0xb00>  // b.any
    8e88:	f9400041 	ldr	x1, [x2]
    8e8c:	f9400420 	ldr	x0, [x1, #8]
    8e90:	d1000400 	sub	x0, x0, #0x1
    8e94:	f9000420 	str	x0, [x1, #8]
    8e98:	f103f81f 	cmp	x0, #0xfe
    8e9c:	54ffb821 	b.ne	85a0 <fwp_hof0.constprop.0+0x230>  // b.any
    8ea0:	39400280 	ldrb	w0, [x20]
    8ea4:	7103fc1f 	cmp	w0, #0xff
    8ea8:	54002e60 	b.eq	9474 <fwp_hof0.constprop.0+0x1104>  // b.none
    8eac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8eb0:	39000280 	strb	w0, [x20]
    8eb4:	17fffdbb 	b	85a0 <fwp_hof0.constprop.0+0x230>
    8eb8:	97ffe836 	bl	2f90 <fwp_tape_unlink_scope>
    8ebc:	b90004df 	str	wzr, [x6, #4]
    8ec0:	a94288c9 	ldp	x9, x2, [x6, #40]
    8ec4:	f9001fe2 	str	x2, [sp, #56]
    8ec8:	f9401cc2 	ldr	x2, [x6, #56]
    8ecc:	f90023e2 	str	x2, [sp, #64]
    8ed0:	b94000c1 	ldr	w1, [x6]
    8ed4:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8ed8:	a940acc7 	ldp	x7, x11, [x6, #8]
    8edc:	a941a0ca 	ldp	x10, x8, [x6, #24]
    8ee0:	f94020c4 	ldr	x4, [x6, #64]
    8ee4:	f94024c2 	ldr	x2, [x6, #72]
    8ee8:	6b00003f 	cmp	w1, w0
    8eec:	54000108 	b.hi	8f0c <fwp_hof0.constprop.0+0xb9c>  // b.pmore
    8ef0:	9100c2a1 	add	x1, x21, #0x30
    8ef4:	92403e80 	and	x0, x20, #0xffff
    8ef8:	d1000400 	sub	x0, x0, #0x1
    8efc:	f9404c2c 	ldr	x12, [x1, #152]
    8f00:	eb0c001f 	cmp	x0, x12
    8f04:	5400004a 	b.ge	8f0c <fwp_hof0.constprop.0+0xb9c>  // b.tcont
    8f08:	f9004c20 	str	x0, [x1, #152]
    8f0c:	4f000400 	movi	v0.4s, #0x0
    8f10:	9100c2a1 	add	x1, x21, #0x30
    8f14:	f9401fe0 	ldr	x0, [sp, #56]
    8f18:	f9000cdf 	str	xzr, [x6, #24]
    8f1c:	a9047cdf 	stp	xzr, xzr, [x6, #64]
    8f20:	9102a3e3 	add	x3, sp, #0xa8
    8f24:	3c8080c0 	stur	q0, [x6, #8]
    8f28:	ad0100c0 	stp	q0, q0, [x6, #32]
    8f2c:	f9006be0 	str	x0, [sp, #208]
    8f30:	f94023e0 	ldr	x0, [sp, #64]
    8f34:	f9006fe0 	str	x0, [sp, #216]
    8f38:	f9416020 	ldr	x0, [x1, #704]
    8f3c:	f90057e0 	str	x0, [sp, #168]
    8f40:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    8f44:	9135c000 	add	x0, x0, #0xd70
    8f48:	f90027e3 	str	x3, [sp, #72]
    8f4c:	f9005be0 	str	x0, [sp, #176]
    8f50:	910303e0 	add	x0, sp, #0xc0
    8f54:	f9001be0 	str	x0, [sp, #48]
    8f58:	f9005fe0 	str	x0, [sp, #184]
    8f5c:	a90c27e8 	stp	x8, x9, [sp, #192]
    8f60:	a90e2be4 	stp	x4, x10, [sp, #224]
    8f64:	f9007be2 	str	x2, [sp, #240]
    8f68:	f9016023 	str	x3, [x1, #704]
    8f6c:	b7f826b7 	tbnz	x23, #63, 9440 <fwp_hof0.constprop.0+0x10d0>
    8f70:	eb97829f 	cmp	x20, x23, asr #32
    8f74:	540005c0 	b.eq	902c <fwp_hof0.constprop.0+0xcbc>  // b.none
    8f78:	b0000020 	adrp	x0, d000 <__modti3+0x2a0>
    8f7c:	91104000 	add	x0, x0, #0x410
    8f80:	97ffebc4 	bl	3e90 <fwp_trap>
    8f84:	d2800d01 	mov	x1, #0x68                  	// #104
    8f88:	d2800024 	mov	x4, #0x1                   	// #1
    8f8c:	17fffdce 	b	86c4 <fwp_hof0.constprop.0+0x354>
    8f90:	72003c3f 	tst	w1, #0xffff
    8f94:	54ffe921 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    8f98:	17ffff3f 	b	8c94 <fwp_hof0.constprop.0+0x924>
    8f9c:	f940054a 	ldr	x10, [x10, #8]
    8fa0:	eb07001f 	cmp	x0, x7
    8fa4:	540003c2 	b.cs	901c <fwp_hof0.constprop.0+0xcac>  // b.hs, b.nlast
    8fa8:	d350fc02 	lsr	x2, x0, #16
    8fac:	8b020842 	add	x2, x2, x2, lsl #2
    8fb0:	d37df042 	lsl	x2, x2, #3
    8fb4:	8b0200c5 	add	x5, x6, x2
    8fb8:	f94010a3 	ldr	x3, [x5, #32]
    8fbc:	b4000303 	cbz	x3, 901c <fwp_hof0.constprop.0+0xcac>
    8fc0:	386268c2 	ldrb	w2, [x6, x2]
    8fc4:	7100085f 	cmp	w2, #0x2
    8fc8:	54002500 	b.eq	9468 <fwp_hof0.constprop.0+0x10f8>  // b.none
    8fcc:	7100045f 	cmp	w2, #0x1
    8fd0:	54000261 	b.ne	901c <fwp_hof0.constprop.0+0xcac>  // b.any
    8fd4:	92403c02 	and	x2, x0, #0xffff
    8fd8:	294300a6 	ldp	w6, w0, [x5, #24]
    8fdc:	9b067c42 	mul	x2, x2, x6
    8fe0:	d360fc42 	lsr	x2, x2, #32
    8fe4:	eb00005f 	cmp	x2, x0
    8fe8:	540001a2 	b.cs	901c <fwp_hof0.constprop.0+0xcac>  // b.hs, b.nlast
    8fec:	8b020063 	add	x3, x3, x2
    8ff0:	39400060 	ldrb	w0, [x3]
    8ff4:	7100041f 	cmp	w0, #0x1
    8ff8:	54000121 	b.ne	901c <fwp_hof0.constprop.0+0xcac>  // b.any
    8ffc:	aa0403e0 	mov	x0, x4
    9000:	f9001fea 	str	x10, [sp, #56]
    9004:	97ffec5f 	bl	4180 <fwp_mem_free>
    9008:	911502c0 	add	x0, x22, #0x540
    900c:	f9401fea 	ldr	x10, [sp, #56]
    9010:	f949ec02 	ldr	x2, [x0, #5080]
    9014:	f949d801 	ldr	x1, [x0, #5040]
    9018:	d370bc47 	lsl	x7, x2, #16
    901c:	cb010141 	sub	x1, x10, x1
    9020:	eb0100ff 	cmp	x7, x1
    9024:	54ffe128 	b.hi	8c48 <fwp_hof0.constprop.0+0x8d8>  // b.pmore
    9028:	17ffff24 	b	8cb8 <fwp_hof0.constprop.0+0x948>
    902c:	92407ee0 	and	x0, x23, #0xffffffff
    9030:	eb37417f 	cmp	x11, w23, uxtw
    9034:	540020ad 	b.le	9448 <fwp_hof0.constprop.0+0x10d8>
    9038:	eb0000ff 	cmp	x7, x0
    903c:	9a80c4f4 	csinc	x20, x7, x0, gt
    9040:	eb14005f 	cmp	x2, x20
    9044:	5400256a 	b.ge	94f0 <fwp_hof0.constprop.0+0x1180>  // b.tcont
    9048:	f100005f 	cmp	x2, #0x0
    904c:	b24077e6 	mov	x6, #0x3fffffff            	// #1073741823
    9050:	9a941042 	csel	x2, x2, x20, ne	// ne = any
    9054:	14000004 	b	9064 <fwp_hof0.constprop.0+0xcf4>
    9058:	eb06005f 	cmp	x2, x6
    905c:	d37ff842 	lsl	x2, x2, #1
    9060:	9a94d042 	csel	x2, x2, x20, le
    9064:	eb14005f 	cmp	x2, x20
    9068:	54ffff8b 	b.lt	9058 <fwp_hof0.constprop.0+0xce8>  // b.tstop
    906c:	a905a3e7 	stp	x7, x8, [sp, #88]
    9070:	f90037e9 	str	x9, [sp, #104]
    9074:	b4002d04 	cbz	x4, 9614 <fwp_hof0.constprop.0+0x12a4>
    9078:	aa0403e0 	mov	x0, x4
    907c:	d37df041 	lsl	x1, x2, #3
    9080:	f9002be2 	str	x2, [sp, #80]
    9084:	97ffe5fb 	bl	2870 <realloc@plt>
    9088:	a9451fe2 	ldp	x2, x7, [sp, #80]
    908c:	aa0003e4 	mov	x4, x0
    9090:	a94627e8 	ldp	x8, x9, [sp, #96]
    9094:	b40022e4 	cbz	x4, 94f0 <fwp_hof0.constprop.0+0x1180>
    9098:	f90073e4 	str	x4, [sp, #224]
    909c:	f9007be2 	str	x2, [sp, #240]
    90a0:	b5001b14 	cbnz	x20, 9400 <fwp_hof0.constprop.0+0x1090>
    90a4:	b7f800d7 	tbnz	x23, #63, 90bc <fwp_hof0.constprop.0+0xd4c>
    90a8:	92407ef7 	and	x23, x23, #0xffffffff
    90ac:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    90b0:	fc777880 	ldr	d0, [x4, x23, lsl #3]
    90b4:	1e612800 	fadd	d0, d0, d1
    90b8:	fc377880 	str	d0, [x4, x23, lsl #3]
    90bc:	d1000680 	sub	x0, x20, #0x1
    90c0:	d10004e6 	sub	x6, x7, #0x1
    90c4:	eb0000ff 	cmp	x7, x0
    90c8:	540003ec 	b.gt	9144 <fwp_hof0.constprop.0+0xdd4>
    90cc:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    90d0:	1e602008 	fcmp	d0, #0.0
    90d4:	54000320 	b.eq	9138 <fwp_hof0.constprop.0+0xdc8>  // b.none
    90d8:	cb070be1 	neg	x1, x7, lsl #2
    90dc:	cb0703e3 	neg	x3, x7
    90e0:	8b010102 	add	x2, x8, x1
    90e4:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    90e8:	37f80122 	tbnz	w2, #31, 910c <fwp_hof0.constprop.0+0xd9c>
    90ec:	f9401fe5 	ldr	x5, [sp, #56]
    90f0:	93407c42 	sxtw	x2, w2
    90f4:	8b030ca5 	add	x5, x5, x3, lsl #3
    90f8:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    90fc:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    9100:	1e620802 	fmul	d2, d0, d2
    9104:	1e622821 	fadd	d1, d1, d2
    9108:	fc227881 	str	d1, [x4, x2, lsl #3]
    910c:	8b010121 	add	x1, x9, x1
    9110:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9114:	37f80121 	tbnz	w1, #31, 9138 <fwp_hof0.constprop.0+0xdc8>
    9118:	f94023e2 	ldr	x2, [sp, #64]
    911c:	93407c21 	sxtw	x1, w1
    9120:	8b030c43 	add	x3, x2, x3, lsl #3
    9124:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    9128:	fc607862 	ldr	d2, [x3, x0, lsl #3]
    912c:	1e620800 	fmul	d0, d0, d2
    9130:	1e602820 	fadd	d0, d1, d0
    9134:	fc217880 	str	d0, [x4, x1, lsl #3]
    9138:	d1000400 	sub	x0, x0, #0x1
    913c:	eb06001f 	cmp	x0, x6
    9140:	54fffc61 	b.ne	90cc <fwp_hof0.constprop.0+0xd5c>  // b.any
    9144:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9148:	eb0000ff 	cmp	x7, x0
    914c:	54001fa8 	b.hi	9540 <fwp_hof0.constprop.0+0x11d0>  // b.pmore
    9150:	910004e0 	add	x0, x7, #0x1
    9154:	52800041 	mov	w1, #0x2                   	// #2
    9158:	a90393e7 	stp	x7, x4, [sp, #56]
    915c:	d37df000 	lsl	x0, x0, #3
    9160:	97ffeec4 	bl	4c70 <fwp_heap_alloc>
    9164:	aa0003f7 	mov	x23, x0
    9168:	a94393e7 	ldp	x7, x4, [sp, #56]
    916c:	f8008407 	str	x7, [x0], #8
    9170:	d2800001 	mov	x1, #0x0                   	// #0
    9174:	b40000c7 	cbz	x7, 918c <fwp_hof0.constprop.0+0xe1c>
    9178:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    917c:	f8217802 	str	x2, [x0, x1, lsl #3]
    9180:	91000421 	add	x1, x1, #0x1
    9184:	eb0100ff 	cmp	x7, x1
    9188:	54ffff81 	b.ne	9178 <fwp_hof0.constprop.0+0xe08>  // b.any
    918c:	9100c2a1 	add	x1, x21, #0x30
    9190:	f94027e2 	ldr	x2, [sp, #72]
    9194:	f9416020 	ldr	x0, [x1, #704]
    9198:	eb02001f 	cmp	x0, x2
    919c:	54006441 	b.ne	9e24 <fwp_hof0.constprop.0+0x1ab4>  // b.any
    91a0:	f9401be0 	ldr	x0, [sp, #48]
    91a4:	f94057f4 	ldr	x20, [sp, #168]
    91a8:	f9016034 	str	x20, [x1, #704]
    91ac:	97ffeaf1 	bl	3d70 <fwp_tape_buffers_release>
    91b0:	911502c2 	add	x2, x22, #0x540
    91b4:	f949d841 	ldr	x1, [x2, #5040]
    91b8:	f949ec40 	ldr	x0, [x2, #5080]
    91bc:	cb0102e1 	sub	x1, x23, x1
    91c0:	eb00403f 	cmp	x1, x0, lsl #16
    91c4:	54000322 	b.cs	9228 <fwp_hof0.constprop.0+0xeb8>  // b.hs, b.nlast
    91c8:	d350fc20 	lsr	x0, x1, #16
    91cc:	f949fc46 	ldr	x6, [x2, #5112]
    91d0:	8b000800 	add	x0, x0, x0, lsl #2
    91d4:	d37df002 	lsl	x2, x0, #3
    91d8:	8b0200c4 	add	x4, x6, x2
    91dc:	f9401080 	ldr	x0, [x4, #32]
    91e0:	b4000240 	cbz	x0, 9228 <fwp_hof0.constprop.0+0xeb8>
    91e4:	386268c2 	ldrb	w2, [x6, x2]
    91e8:	7100085f 	cmp	w2, #0x2
    91ec:	54004da0 	b.eq	9ba0 <fwp_hof0.constprop.0+0x1830>  // b.none
    91f0:	7100045f 	cmp	w2, #0x1
    91f4:	540001a1 	b.ne	9228 <fwp_hof0.constprop.0+0xeb8>  // b.any
    91f8:	29430886 	ldp	w6, w2, [x4, #24]
    91fc:	92403c21 	and	x1, x1, #0xffff
    9200:	9b067c21 	mul	x1, x1, x6
    9204:	d360fc21 	lsr	x1, x1, #32
    9208:	eb02003f 	cmp	x1, x2
    920c:	540000e2 	b.cs	9228 <fwp_hof0.constprop.0+0xeb8>  // b.hs, b.nlast
    9210:	8b010000 	add	x0, x0, x1
    9214:	39400001 	ldrb	w1, [x0]
    9218:	7103fc3f 	cmp	w1, #0xff
    921c:	54005be0 	b.eq	9d98 <fwp_hof0.constprop.0+0x1a28>  // b.none
    9220:	52800021 	mov	w1, #0x1                   	// #1
    9224:	39000001 	strb	w1, [x0]
    9228:	f94007e0 	ldr	x0, [sp, #8]
    922c:	eb00029f 	cmp	x20, x0
    9230:	54005fa1 	b.ne	9e24 <fwp_hof0.constprop.0+0x1ab4>  // b.any
    9234:	f94003e0 	ldr	x0, [sp]
    9238:	9100c2a1 	add	x1, x21, #0x30
    923c:	f9404be2 	ldr	x2, [sp, #144]
    9240:	f9016022 	str	x2, [x1, #704]
    9244:	97fff40b 	bl	6270 <fwp_tape_scope_release>
    9248:	f94002e0 	ldr	x0, [x23]
    924c:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9250:	b7f818c0 	tbnz	x0, #63, 9568 <fwp_hof0.constprop.0+0x11f8>
    9254:	911502c4 	add	x4, x22, #0x540
    9258:	f949d880 	ldr	x0, [x4, #5040]
    925c:	f949ec81 	ldr	x1, [x4, #5080]
    9260:	cb0002e0 	sub	x0, x23, x0
    9264:	eb01401f 	cmp	x0, x1, lsl #16
    9268:	54001802 	b.cs	9568 <fwp_hof0.constprop.0+0x11f8>  // b.hs, b.nlast
    926c:	d350fc01 	lsr	x1, x0, #16
    9270:	f949fc87 	ldr	x7, [x4, #5112]
    9274:	8b010821 	add	x1, x1, x1, lsl #2
    9278:	d37df021 	lsl	x1, x1, #3
    927c:	8b0100e6 	add	x6, x7, x1
    9280:	f94010c4 	ldr	x4, [x6, #32]
    9284:	b4001724 	cbz	x4, 9568 <fwp_hof0.constprop.0+0x11f8>
    9288:	386168e1 	ldrb	w1, [x7, x1]
    928c:	7100083f 	cmp	w1, #0x2
    9290:	54001680 	b.eq	9560 <fwp_hof0.constprop.0+0x11f0>  // b.none
    9294:	7100043f 	cmp	w1, #0x1
    9298:	54001681 	b.ne	9568 <fwp_hof0.constprop.0+0x11f8>  // b.any
    929c:	294304c7 	ldp	w7, w1, [x6, #24]
    92a0:	92403c00 	and	x0, x0, #0xffff
    92a4:	9b077c00 	mul	x0, x0, x7
    92a8:	d360fc00 	lsr	x0, x0, #32
    92ac:	eb01001f 	cmp	x0, x1
    92b0:	540015c2 	b.cs	9568 <fwp_hof0.constprop.0+0x11f8>  // b.hs, b.nlast
    92b4:	8b000084 	add	x4, x4, x0
    92b8:	39400080 	ldrb	w0, [x4]
    92bc:	7100041f 	cmp	w0, #0x1
    92c0:	54001541 	b.ne	9568 <fwp_hof0.constprop.0+0x11f8>  // b.any
    92c4:	aa1703f4 	mov	x20, x23
    92c8:	d2800000 	mov	x0, #0x0                   	// #0
    92cc:	91002284 	add	x4, x20, #0x8
    92d0:	d2800001 	mov	x1, #0x0                   	// #0
    92d4:	b40001e2 	cbz	x2, 9310 <fwp_hof0.constprop.0+0xfa0>
    92d8:	90000023 	adrp	x3, d000 <__modti3+0x2a0>
    92dc:	910022e7 	add	x7, x23, #0x8
    92e0:	fd46f861 	ldr	d1, [x3, #3568]
    92e4:	f94002e5 	ldr	x5, [x23]
    92e8:	aa0703e3 	mov	x3, x7
    92ec:	b7f81365 	tbnz	x5, #63, 9558 <fwp_hof0.constprop.0+0x11e8>
    92f0:	f9400285 	ldr	x5, [x20]
    92f4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    92f8:	b7f812a5 	tbnz	x5, #63, 954c <fwp_hof0.constprop.0+0x11dc>
    92fc:	1e600820 	fmul	d0, d1, d0
    9300:	91000421 	add	x1, x1, #0x1
    9304:	fc008480 	str	d0, [x4], #8
    9308:	eb01005f 	cmp	x2, x1
    930c:	54fffec1 	b.ne	92e4 <fwp_hof0.constprop.0+0xf74>  // b.any
    9310:	97fff5e4 	bl	6aa0 <fwp_drop10>
    9314:	b4004679 	cbz	x25, 9be0 <fwp_hof0.constprop.0+0x1870>
    9318:	aa1903e0 	mov	x0, x25
    931c:	d2800017 	mov	x23, #0x0                   	// #0
    9320:	f9400800 	ldr	x0, [x0, #16]
    9324:	910006f7 	add	x23, x23, #0x1
    9328:	b5ffffc0 	cbnz	x0, 9320 <fwp_hof0.constprop.0+0xfb0>
    932c:	f9400280 	ldr	x0, [x20]
    9330:	9240f804 	and	x4, x0, #0x7fffffffffffffff
    9334:	b7f81860 	tbnz	x0, #63, 9640 <fwp_hof0.constprop.0+0x12d0>
    9338:	911502c1 	add	x1, x22, #0x540
    933c:	f949d820 	ldr	x0, [x1, #5040]
    9340:	f949ec22 	ldr	x2, [x1, #5080]
    9344:	cb000280 	sub	x0, x20, x0
    9348:	eb02401f 	cmp	x0, x2, lsl #16
    934c:	54001782 	b.cs	963c <fwp_hof0.constprop.0+0x12cc>  // b.hs, b.nlast
    9350:	d350fc02 	lsr	x2, x0, #16
    9354:	d2800506 	mov	x6, #0x28                  	// #40
    9358:	f949fc27 	ldr	x7, [x1, #5112]
    935c:	9b067c42 	mul	x2, x2, x6
    9360:	8b0200e6 	add	x6, x7, x2
    9364:	f94010c1 	ldr	x1, [x6, #32]
    9368:	b40016a1 	cbz	x1, 963c <fwp_hof0.constprop.0+0x12cc>
    936c:	386268e2 	ldrb	w2, [x7, x2]
    9370:	7100085f 	cmp	w2, #0x2
    9374:	54001600 	b.eq	9634 <fwp_hof0.constprop.0+0x12c4>  // b.none
    9378:	7100045f 	cmp	w2, #0x1
    937c:	54001601 	b.ne	963c <fwp_hof0.constprop.0+0x12cc>  // b.any
    9380:	294308c7 	ldp	w7, w2, [x6, #24]
    9384:	92403c00 	and	x0, x0, #0xffff
    9388:	9b077c00 	mul	x0, x0, x7
    938c:	d360fc00 	lsr	x0, x0, #32
    9390:	eb02001f 	cmp	x0, x2
    9394:	54001542 	b.cs	963c <fwp_hof0.constprop.0+0x12cc>  // b.hs, b.nlast
    9398:	8b000021 	add	x1, x1, x0
    939c:	39400028 	ldrb	w8, [x1]
    93a0:	7100051f 	cmp	w8, #0x1
    93a4:	540014c1 	b.ne	963c <fwp_hof0.constprop.0+0x12cc>  // b.any
    93a8:	91002282 	add	x2, x20, #0x8
    93ac:	eb17009f 	cmp	x4, x23
    93b0:	9a979097 	csel	x23, x4, x23, ls	// ls = plast
    93b4:	b40040d7 	cbz	x23, 9bcc <fwp_hof0.constprop.0+0x185c>
    93b8:	d37df2e7 	lsl	x7, x23, #3
    93bc:	aa1903e1 	mov	x1, x25
    93c0:	91002286 	add	x6, x20, #0x8
    93c4:	d2800000 	mov	x0, #0x0                   	// #0
    93c8:	14000009 	b	93ec <fwp_hof0.constprop.0+0x107c>
    93cc:	fc606861 	ldr	d1, [x3, x0]
    93d0:	fd400420 	ldr	d0, [x1, #8]
    93d4:	1e613800 	fsub	d0, d0, d1
    93d8:	fc206840 	str	d0, [x2, x0]
    93dc:	91002000 	add	x0, x0, #0x8
    93e0:	f9400821 	ldr	x1, [x1, #16]
    93e4:	eb07001f 	cmp	x0, x7
    93e8:	540015a0 	b.eq	969c <fwp_hof0.constprop.0+0x132c>  // b.none
    93ec:	f9400284 	ldr	x4, [x20]
    93f0:	aa0603e3 	mov	x3, x6
    93f4:	b6fffec4 	tbz	x4, #63, 93cc <fwp_hof0.constprop.0+0x105c>
    93f8:	f9400a83 	ldr	x3, [x20, #16]
    93fc:	17fffff4 	b	93cc <fwp_hof0.constprop.0+0x105c>
    9400:	aa0403e0 	mov	x0, x4
    9404:	d37df282 	lsl	x2, x20, #3
    9408:	52800001 	mov	w1, #0x0                   	// #0
    940c:	a90523e7 	stp	x7, x8, [sp, #80]
    9410:	f90033e9 	str	x9, [sp, #96]
    9414:	97ffe50f 	bl	2850 <memset@plt>
    9418:	a94523e7 	ldp	x7, x8, [sp, #80]
    941c:	aa0003e4 	mov	x4, x0
    9420:	f94033e9 	ldr	x9, [sp, #96]
    9424:	17ffff20 	b	90a4 <fwp_hof0.constprop.0+0xd34>
    9428:	72003c1f 	tst	w0, #0xffff
    942c:	54ffc461 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    9430:	17fffe62 	b	8db8 <fwp_hof0.constprop.0+0xa48>
    9434:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9438:	91090000 	add	x0, x0, #0x240
    943c:	97ffea95 	bl	3e90 <fwp_trap>
    9440:	aa0703f4 	mov	x20, x7
    9444:	17fffeff 	b	9040 <fwp_hof0.constprop.0+0xcd0>
    9448:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    944c:	91122000 	add	x0, x0, #0x488
    9450:	97ffea90 	bl	3e90 <fwp_trap>
    9454:	aa1403e0 	mov	x0, x20
    9458:	a903a7ea 	stp	x10, x9, [sp, #56]
    945c:	97ffeaad 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9460:	a943a7ea 	ldp	x10, x9, [sp, #56]
    9464:	17fffdaf 	b	8b20 <fwp_hof0.constprop.0+0x7b0>
    9468:	72003c1f 	tst	w0, #0xffff
    946c:	54ffdd81 	b.ne	901c <fwp_hof0.constprop.0+0xcac>  // b.any
    9470:	17fffee0 	b	8ff0 <fwp_hof0.constprop.0+0xc80>
    9474:	aa1403e0 	mov	x0, x20
    9478:	97ffeaa6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    947c:	17fffe8c 	b	8eac <fwp_hof0.constprop.0+0xb3c>
    9480:	ca404401 	eor	x1, x0, x0, lsr #17
    9484:	911502c4 	add	x4, x22, #0x540
    9488:	ca412421 	eor	x1, x1, x1, lsr #9
    948c:	92401c21 	and	x1, x1, #0xff
    9490:	910a2422 	add	x2, x1, #0x289
    9494:	8b010c81 	add	x1, x4, x1, lsl #3
    9498:	8b020c82 	add	x2, x4, x2, lsl #3
    949c:	f94a2421 	ldr	x1, [x1, #5192]
    94a0:	b50000a1 	cbnz	x1, 94b4 <fwp_hof0.constprop.0+0x1144>
    94a4:	17ffffe4 	b	9434 <fwp_hof0.constprop.0+0x10c4>
    94a8:	91004022 	add	x2, x1, #0x10
    94ac:	f9400821 	ldr	x1, [x1, #16]
    94b0:	b4fffc21 	cbz	x1, 9434 <fwp_hof0.constprop.0+0x10c4>
    94b4:	f9400023 	ldr	x3, [x1]
    94b8:	eb00007f 	cmp	x3, x0
    94bc:	54ffff61 	b.ne	94a8 <fwp_hof0.constprop.0+0x1138>  // b.any
    94c0:	f9400042 	ldr	x2, [x2]
    94c4:	f9400441 	ldr	x1, [x2, #8]
    94c8:	d1000421 	sub	x1, x1, #0x1
    94cc:	f9000441 	str	x1, [x2, #8]
    94d0:	f103f83f 	cmp	x1, #0xfe
    94d4:	54ffbf21 	b.ne	8cb8 <fwp_hof0.constprop.0+0x948>  // b.any
    94d8:	39400001 	ldrb	w1, [x0]
    94dc:	7103fc3f 	cmp	w1, #0xff
    94e0:	54004720 	b.eq	9dc4 <fwp_hof0.constprop.0+0x1a54>  // b.none
    94e4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    94e8:	39000001 	strb	w1, [x0]
    94ec:	17fffdf3 	b	8cb8 <fwp_hof0.constprop.0+0x948>
    94f0:	f100029f 	cmp	x20, #0x0
    94f4:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    94f8:	54ffdd41 	b.ne	90a0 <fwp_hof0.constprop.0+0xd30>  // b.any
    94fc:	f9401be0 	ldr	x0, [sp, #48]
    9500:	9100c2b5 	add	x21, x21, #0x30
    9504:	f94057e1 	ldr	x1, [sp, #168]
    9508:	f90162a1 	str	x1, [x21, #704]
    950c:	97ffea19 	bl	3d70 <fwp_tape_buffers_release>
    9510:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9514:	f947e863 	ldr	x3, [x3, #4048]
    9518:	d2800262 	mov	x2, #0x13                  	// #19
    951c:	d2800021 	mov	x1, #0x1                   	// #1
    9520:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9524:	91042000 	add	x0, x0, #0x108
    9528:	f9400063 	ldr	x3, [x3]
    952c:	97ffe515 	bl	2980 <fwrite@plt>
    9530:	d2800000 	mov	x0, #0x0                   	// #0
    9534:	97ffe51f 	bl	29b0 <fflush@plt>
    9538:	52800cc0 	mov	w0, #0x66                  	// #102
    953c:	97ffe52d 	bl	29f0 <_Exit@plt>
    9540:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9544:	9118e000 	add	x0, x0, #0x638
    9548:	97ffea52 	bl	3e90 <fwp_trap>
    954c:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9550:	91192000 	add	x0, x0, #0x648
    9554:	97ffea4f 	bl	3e90 <fwp_trap>
    9558:	f9400ae3 	ldr	x3, [x23, #16]
    955c:	17ffff65 	b	92f0 <fwp_hof0.constprop.0+0xf80>
    9560:	72003c1f 	tst	w0, #0xffff
    9564:	54ffeaa0 	b.eq	92b8 <fwp_hof0.constprop.0+0xf48>  // b.none
    9568:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    956c:	eb00005f 	cmp	x2, x0
    9570:	54fffe88 	b.hi	9540 <fwp_hof0.constprop.0+0x11d0>  // b.pmore
    9574:	91000440 	add	x0, x2, #0x1
    9578:	52800021 	mov	w1, #0x1                   	// #1
    957c:	f9001fe2 	str	x2, [sp, #56]
    9580:	d37df000 	lsl	x0, x0, #3
    9584:	97ffedbb 	bl	4c70 <fwp_heap_alloc>
    9588:	f9401fe2 	ldr	x2, [sp, #56]
    958c:	911502c6 	add	x6, x22, #0x540
    9590:	f9000002 	str	x2, [x0]
    9594:	aa0003f4 	mov	x20, x0
    9598:	f949d8c1 	ldr	x1, [x6, #5040]
    959c:	f949ecc0 	ldr	x0, [x6, #5080]
    95a0:	cb010281 	sub	x1, x20, x1
    95a4:	eb00403f 	cmp	x1, x0, lsl #16
    95a8:	54000322 	b.cs	960c <fwp_hof0.constprop.0+0x129c>  // b.hs, b.nlast
    95ac:	d350fc24 	lsr	x4, x1, #16
    95b0:	d2800500 	mov	x0, #0x28                  	// #40
    95b4:	f949fcc7 	ldr	x7, [x6, #5112]
    95b8:	9b007c84 	mul	x4, x4, x0
    95bc:	8b0400e6 	add	x6, x7, x4
    95c0:	f94010c0 	ldr	x0, [x6, #32]
    95c4:	b4000240 	cbz	x0, 960c <fwp_hof0.constprop.0+0x129c>
    95c8:	386468e4 	ldrb	w4, [x7, x4]
    95cc:	7100089f 	cmp	w4, #0x2
    95d0:	54004020 	b.eq	9dd4 <fwp_hof0.constprop.0+0x1a64>  // b.none
    95d4:	7100049f 	cmp	w4, #0x1
    95d8:	540001a1 	b.ne	960c <fwp_hof0.constprop.0+0x129c>  // b.any
    95dc:	294310c7 	ldp	w7, w4, [x6, #24]
    95e0:	92403c21 	and	x1, x1, #0xffff
    95e4:	9b077c21 	mul	x1, x1, x7
    95e8:	d360fc21 	lsr	x1, x1, #32
    95ec:	eb04003f 	cmp	x1, x4
    95f0:	540000e2 	b.cs	960c <fwp_hof0.constprop.0+0x129c>  // b.hs, b.nlast
    95f4:	8b010000 	add	x0, x0, x1
    95f8:	39400001 	ldrb	w1, [x0]
    95fc:	7103fc3f 	cmp	w1, #0xff
    9600:	54003ba0 	b.eq	9d74 <fwp_hof0.constprop.0+0x1a04>  // b.none
    9604:	52800021 	mov	w1, #0x1                   	// #1
    9608:	39000001 	strb	w1, [x0]
    960c:	aa1703e0 	mov	x0, x23
    9610:	17ffff2f 	b	92cc <fwp_hof0.constprop.0+0xf5c>
    9614:	aa0203e0 	mov	x0, x2
    9618:	d2800101 	mov	x1, #0x8                   	// #8
    961c:	f9002be2 	str	x2, [sp, #80]
    9620:	97ffe490 	bl	2860 <calloc@plt>
    9624:	a9451fe2 	ldp	x2, x7, [sp, #80]
    9628:	aa0003e4 	mov	x4, x0
    962c:	a94627e8 	ldp	x8, x9, [sp, #96]
    9630:	17fffe99 	b	9094 <fwp_hof0.constprop.0+0xd24>
    9634:	72003c1f 	tst	w0, #0xffff
    9638:	54ffeb20 	b.eq	939c <fwp_hof0.constprop.0+0x102c>  // b.none
    963c:	b4002bf9 	cbz	x25, 9bb8 <fwp_hof0.constprop.0+0x1848>
    9640:	aa1903e1 	mov	x1, x25
    9644:	d2800017 	mov	x23, #0x0                   	// #0
    9648:	f9400821 	ldr	x1, [x1, #16]
    964c:	aa1703e0 	mov	x0, x23
    9650:	910006f7 	add	x23, x23, #0x1
    9654:	b5ffffa1 	cbnz	x1, 9648 <fwp_hof0.constprop.0+0x12d8>
    9658:	f9001fe4 	str	x4, [sp, #56]
    965c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9660:	eb0102ff 	cmp	x23, x1
    9664:	54ff8e48 	b.hi	882c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    9668:	91000800 	add	x0, x0, #0x2
    966c:	52800041 	mov	w1, #0x2                   	// #2
    9670:	d37df000 	lsl	x0, x0, #3
    9674:	97ffed7f 	bl	4c70 <fwp_heap_alloc>
    9678:	f9401fe4 	ldr	x4, [sp, #56]
    967c:	aa1903e1 	mov	x1, x25
    9680:	aa0003e2 	mov	x2, x0
    9684:	f9400423 	ldr	x3, [x1, #8]
    9688:	f8008403 	str	x3, [x0], #8
    968c:	f9400821 	ldr	x1, [x1, #16]
    9690:	b5ffffa1 	cbnz	x1, 9684 <fwp_hof0.constprop.0+0x1314>
    9694:	52800008 	mov	w8, #0x0                   	// #0
    9698:	17ffff45 	b	93ac <fwp_hof0.constprop.0+0x103c>
    969c:	b4003219 	cbz	x25, 9cdc <fwp_hof0.constprop.0+0x196c>
    96a0:	911502c0 	add	x0, x22, #0x540
    96a4:	aa1903e9 	mov	x9, x25
    96a8:	d2800006 	mov	x6, #0x0                   	// #0
    96ac:	f949ec0a 	ldr	x10, [x0, #5080]
    96b0:	f949d80b 	ldr	x11, [x0, #5040]
    96b4:	f949fc0c 	ldr	x12, [x0, #5112]
    96b8:	d370bd4a 	lsl	x10, x10, #16
    96bc:	14000006 	b	96d4 <fwp_hof0.constprop.0+0x1364>
    96c0:	f9400929 	ldr	x9, [x9, #16]
    96c4:	910004c6 	add	x6, x6, #0x1
    96c8:	f100013f 	cmp	x9, #0x0
    96cc:	fa4612e0 	ccmp	x23, x6, #0x0, ne	// ne = any
    96d0:	54000329 	b.ls	9734 <fwp_hof0.constprop.0+0x13c4>  // b.plast
    96d4:	cb0b0120 	sub	x0, x9, x11
    96d8:	eb0a001f 	cmp	x0, x10
    96dc:	540002c2 	b.cs	9734 <fwp_hof0.constprop.0+0x13c4>  // b.hs, b.nlast
    96e0:	d350fc01 	lsr	x1, x0, #16
    96e4:	8b010821 	add	x1, x1, x1, lsl #2
    96e8:	d37df021 	lsl	x1, x1, #3
    96ec:	8b010184 	add	x4, x12, x1
    96f0:	f9401083 	ldr	x3, [x4, #32]
    96f4:	b4000203 	cbz	x3, 9734 <fwp_hof0.constprop.0+0x13c4>
    96f8:	38616981 	ldrb	w1, [x12, x1]
    96fc:	7100083f 	cmp	w1, #0x2
    9700:	54002560 	b.eq	9bac <fwp_hof0.constprop.0+0x183c>  // b.none
    9704:	7100043f 	cmp	w1, #0x1
    9708:	54000161 	b.ne	9734 <fwp_hof0.constprop.0+0x13c4>  // b.any
    970c:	29430485 	ldp	w5, w1, [x4, #24]
    9710:	92403c00 	and	x0, x0, #0xffff
    9714:	9b057c00 	mul	x0, x0, x5
    9718:	d360fc00 	lsr	x0, x0, #32
    971c:	eb01001f 	cmp	x0, x1
    9720:	540000a2 	b.cs	9734 <fwp_hof0.constprop.0+0x13c4>  // b.hs, b.nlast
    9724:	8b000063 	add	x3, x3, x0
    9728:	39400060 	ldrb	w0, [x3]
    972c:	7100041f 	cmp	w0, #0x1
    9730:	54fffc80 	b.eq	96c0 <fwp_hof0.constprop.0+0x1350>  // b.none
    9734:	d2800004 	mov	x4, #0x0                   	// #0
    9738:	eb0602ff 	cmp	x23, x6
    973c:	54002ba9 	b.ls	9cb0 <fwp_hof0.constprop.0+0x1940>  // b.plast
    9740:	d1002040 	sub	x0, x2, #0x8
    9744:	911502ca 	add	x10, x22, #0x540
    9748:	d2800004 	mov	x4, #0x0                   	// #0
    974c:	a90467e0 	stp	x0, x25, [sp, #64]
    9750:	9103e3e0 	add	x0, sp, #0xf8
    9754:	aa0603f9 	mov	x25, x6
    9758:	f9001fe0 	str	x0, [sp, #56]
    975c:	f9002be2 	str	x2, [sp, #80]
    9760:	b9005be8 	str	w8, [sp, #88]
    9764:	a9064ff4 	stp	x20, x19, [sp, #96]
    9768:	aa1703f3 	mov	x19, x23
    976c:	aa0a03f4 	mov	x20, x10
    9770:	14000012 	b	97b8 <fwp_hof0.constprop.0+0x1448>
    9774:	7100045f 	cmp	w2, #0x1
    9778:	540001a1 	b.ne	97ac <fwp_hof0.constprop.0+0x143c>  // b.any
    977c:	29430865 	ldp	w5, w2, [x3, #24]
    9780:	92403c21 	and	x1, x1, #0xffff
    9784:	9b057c21 	mul	x1, x1, x5
    9788:	d360fc21 	lsr	x1, x1, #32
    978c:	eb02003f 	cmp	x1, x2
    9790:	540000e2 	b.cs	97ac <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    9794:	8b010000 	add	x0, x0, x1
    9798:	39400001 	ldrb	w1, [x0]
    979c:	7103fc3f 	cmp	w1, #0xff
    97a0:	54002a20 	b.eq	9ce4 <fwp_hof0.constprop.0+0x1974>  // b.none
    97a4:	52800021 	mov	w1, #0x1                   	// #1
    97a8:	39000001 	strb	w1, [x0]
    97ac:	d1000673 	sub	x19, x19, #0x1
    97b0:	eb19027f 	cmp	x19, x25
    97b4:	54000329 	b.ls	9818 <fwp_hof0.constprop.0+0x14a8>  // b.plast
    97b8:	a94383e1 	ldp	x1, x0, [sp, #56]
    97bc:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    97c0:	a90f93e0 	stp	x0, x4, [sp, #248]
    97c4:	52800020 	mov	w0, #0x1                   	// #1
    97c8:	97ffed6f 	bl	4d84 <fwp_data.part.0.constprop.0>
    97cc:	aa0003e4 	mov	x4, x0
    97d0:	f949da81 	ldr	x1, [x20, #5040]
    97d4:	f949ee80 	ldr	x0, [x20, #5080]
    97d8:	cb010081 	sub	x1, x4, x1
    97dc:	eb00403f 	cmp	x1, x0, lsl #16
    97e0:	54fffe62 	b.cs	97ac <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    97e4:	d350fc20 	lsr	x0, x1, #16
    97e8:	f949fe85 	ldr	x5, [x20, #5112]
    97ec:	8b000800 	add	x0, x0, x0, lsl #2
    97f0:	d37df002 	lsl	x2, x0, #3
    97f4:	8b0200a3 	add	x3, x5, x2
    97f8:	f9401060 	ldr	x0, [x3, #32]
    97fc:	b4fffd80 	cbz	x0, 97ac <fwp_hof0.constprop.0+0x143c>
    9800:	386268a2 	ldrb	w2, [x5, x2]
    9804:	7100085f 	cmp	w2, #0x2
    9808:	54fffb61 	b.ne	9774 <fwp_hof0.constprop.0+0x1404>  // b.any
    980c:	72003c3f 	tst	w1, #0xffff
    9810:	54fffce1 	b.ne	97ac <fwp_hof0.constprop.0+0x143c>  // b.any
    9814:	17ffffe1 	b	9798 <fwp_hof0.constprop.0+0x1428>
    9818:	d10006e1 	sub	x1, x23, #0x1
    981c:	cb170320 	sub	x0, x25, x23
    9820:	eb19003f 	cmp	x1, x25
    9824:	aa1903e6 	mov	x6, x25
    9828:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    982c:	b9405be8 	ldr	w8, [sp, #88]
    9830:	a9448bf9 	ldp	x25, x2, [sp, #72]
    9834:	8b010000 	add	x0, x0, x1
    9838:	a9464ff4 	ldp	x20, x19, [sp, #96]
    983c:	b50023a6 	cbnz	x6, 9cb0 <fwp_hof0.constprop.0+0x1940>
    9840:	7100011f 	cmp	w8, #0x0
    9844:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9848:	b4001d60 	cbz	x0, 9bf4 <fwp_hof0.constprop.0+0x1884>
    984c:	d1000417 	sub	x23, x0, #0x1
    9850:	911502c7 	add	x7, x22, #0x540
    9854:	a90453f9 	stp	x25, x20, [sp, #64]
    9858:	aa1703f4 	mov	x20, x23
    985c:	aa0703f9 	mov	x25, x7
    9860:	f9002bf3 	str	x19, [sp, #80]
    9864:	aa0203f3 	mov	x19, x2
    9868:	14000012 	b	98b0 <fwp_hof0.constprop.0+0x1540>
    986c:	7100047f 	cmp	w3, #0x1
    9870:	540001a1 	b.ne	98a4 <fwp_hof0.constprop.0+0x1534>  // b.any
    9874:	29430003 	ldp	w3, w0, [x0, #24]
    9878:	92403c21 	and	x1, x1, #0xffff
    987c:	9b037c21 	mul	x1, x1, x3
    9880:	d360fc21 	lsr	x1, x1, #32
    9884:	eb00003f 	cmp	x1, x0
    9888:	540000e2 	b.cs	98a4 <fwp_hof0.constprop.0+0x1534>  // b.hs, b.nlast
    988c:	8b0102f7 	add	x23, x23, x1
    9890:	394002e0 	ldrb	w0, [x23]
    9894:	7103fc1f 	cmp	w0, #0xff
    9898:	54002760 	b.eq	9d84 <fwp_hof0.constprop.0+0x1a14>  // b.none
    989c:	52800020 	mov	w0, #0x1                   	// #1
    98a0:	390002e0 	strb	w0, [x23]
    98a4:	d1000694 	sub	x20, x20, #0x1
    98a8:	b100069f 	cmn	x20, #0x1
    98ac:	54000320 	b.eq	9910 <fwp_hof0.constprop.0+0x15a0>  // b.none
    98b0:	f9401fe1 	ldr	x1, [sp, #56]
    98b4:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    98b8:	a90f93e0 	stp	x0, x4, [sp, #248]
    98bc:	52800020 	mov	w0, #0x1                   	// #1
    98c0:	97ffed31 	bl	4d84 <fwp_data.part.0.constprop.0>
    98c4:	aa0003e4 	mov	x4, x0
    98c8:	f949db21 	ldr	x1, [x25, #5040]
    98cc:	f949ef20 	ldr	x0, [x25, #5080]
    98d0:	cb010081 	sub	x1, x4, x1
    98d4:	eb00403f 	cmp	x1, x0, lsl #16
    98d8:	54fffe62 	b.cs	98a4 <fwp_hof0.constprop.0+0x1534>  // b.hs, b.nlast
    98dc:	d350fc20 	lsr	x0, x1, #16
    98e0:	f949ff26 	ldr	x6, [x25, #5112]
    98e4:	8b000800 	add	x0, x0, x0, lsl #2
    98e8:	d37df003 	lsl	x3, x0, #3
    98ec:	8b0300c0 	add	x0, x6, x3
    98f0:	f9401017 	ldr	x23, [x0, #32]
    98f4:	b4fffd97 	cbz	x23, 98a4 <fwp_hof0.constprop.0+0x1534>
    98f8:	386368c3 	ldrb	w3, [x6, x3]
    98fc:	7100087f 	cmp	w3, #0x2
    9900:	54fffb61 	b.ne	986c <fwp_hof0.constprop.0+0x14fc>  // b.any
    9904:	72003c3f 	tst	w1, #0xffff
    9908:	54fffce1 	b.ne	98a4 <fwp_hof0.constprop.0+0x1534>  // b.any
    990c:	17ffffe1 	b	9890 <fwp_hof0.constprop.0+0x1520>
    9910:	a94453f9 	ldp	x25, x20, [sp, #64]
    9914:	aa1303e2 	mov	x2, x19
    9918:	f9402bf3 	ldr	x19, [sp, #80]
    991c:	aa1903f7 	mov	x23, x25
    9920:	aa0403f9 	mov	x25, x4
    9924:	aa0203e0 	mov	x0, x2
    9928:	97ffea16 	bl	4180 <fwp_mem_free>
    992c:	911502c6 	add	x6, x22, #0x540
    9930:	f9001ffa 	str	x26, [sp, #56]
    9934:	aa1303fa 	mov	x26, x19
    9938:	aa0603f3 	mov	x19, x6
    993c:	d2800507 	mov	x7, #0x28                  	// #40
    9940:	f949da61 	ldr	x1, [x19, #5040]
    9944:	f949ee60 	ldr	x0, [x19, #5080]
    9948:	cb010281 	sub	x1, x20, x1
    994c:	eb00403f 	cmp	x1, x0, lsl #16
    9950:	54001222 	b.cs	9b94 <fwp_hof0.constprop.0+0x1824>  // b.hs, b.nlast
    9954:	d350fc22 	lsr	x2, x1, #16
    9958:	f949fe63 	ldr	x3, [x19, #5112]
    995c:	9b077c42 	mul	x2, x2, x7
    9960:	8b020068 	add	x8, x3, x2
    9964:	f9401100 	ldr	x0, [x8, #32]
    9968:	b4001160 	cbz	x0, 9b94 <fwp_hof0.constprop.0+0x1824>
    996c:	38626864 	ldrb	w4, [x3, x2]
    9970:	7100089f 	cmp	w4, #0x2
    9974:	540010c0 	b.eq	9b8c <fwp_hof0.constprop.0+0x181c>  // b.none
    9978:	7100049f 	cmp	w4, #0x1
    997c:	540010c1 	b.ne	9b94 <fwp_hof0.constprop.0+0x1824>  // b.any
    9980:	29430d02 	ldp	w2, w3, [x8, #24]
    9984:	92403c21 	and	x1, x1, #0xffff
    9988:	9b027c22 	mul	x2, x1, x2
    998c:	d360fc42 	lsr	x2, x2, #32
    9990:	eb03005f 	cmp	x2, x3
    9994:	54001002 	b.cs	9b94 <fwp_hof0.constprop.0+0x1824>  // b.hs, b.nlast
    9998:	8b020000 	add	x0, x0, x2
    999c:	39400002 	ldrb	w2, [x0]
    99a0:	34000fa2 	cbz	w2, 9b94 <fwp_hof0.constprop.0+0x1824>
    99a4:	7100045f 	cmp	w2, #0x1
    99a8:	54000d60 	b.eq	9b54 <fwp_hof0.constprop.0+0x17e4>  // b.none
    99ac:	aa1a03f3 	mov	x19, x26
    99b0:	f9401ffa 	ldr	x26, [sp, #56]
    99b4:	7103fc5f 	cmp	w2, #0xff
    99b8:	54001ba0 	b.eq	9d2c <fwp_hof0.constprop.0+0x19bc>  // b.none
    99bc:	51000442 	sub	w2, w2, #0x1
    99c0:	39000002 	strb	w2, [x0]
    99c4:	911502c6 	add	x6, x22, #0x540
    99c8:	f9001ffa 	str	x26, [sp, #56]
    99cc:	aa1303fa 	mov	x26, x19
    99d0:	aa0603f3 	mov	x19, x6
    99d4:	d2800507 	mov	x7, #0x28                  	// #40
    99d8:	f949da60 	ldr	x0, [x19, #5040]
    99dc:	f949ee61 	ldr	x1, [x19, #5080]
    99e0:	cb0002e0 	sub	x0, x23, x0
    99e4:	eb01401f 	cmp	x0, x1, lsl #16
    99e8:	54000b02 	b.cs	9b48 <fwp_hof0.constprop.0+0x17d8>  // b.hs, b.nlast
    99ec:	d350fc01 	lsr	x1, x0, #16
    99f0:	f949fe62 	ldr	x2, [x19, #5112]
    99f4:	9b077c21 	mul	x1, x1, x7
    99f8:	8b010043 	add	x3, x2, x1
    99fc:	f9401074 	ldr	x20, [x3, #32]
    9a00:	b4000a54 	cbz	x20, 9b48 <fwp_hof0.constprop.0+0x17d8>
    9a04:	38616844 	ldrb	w4, [x2, x1]
    9a08:	7100089f 	cmp	w4, #0x2
    9a0c:	540009a0 	b.eq	9b40 <fwp_hof0.constprop.0+0x17d0>  // b.none
    9a10:	7100049f 	cmp	w4, #0x1
    9a14:	540009a1 	b.ne	9b48 <fwp_hof0.constprop.0+0x17d8>  // b.any
    9a18:	29430861 	ldp	w1, w2, [x3, #24]
    9a1c:	92403c00 	and	x0, x0, #0xffff
    9a20:	9b017c01 	mul	x1, x0, x1
    9a24:	d360fc21 	lsr	x1, x1, #32
    9a28:	eb02003f 	cmp	x1, x2
    9a2c:	540008e2 	b.cs	9b48 <fwp_hof0.constprop.0+0x17d8>  // b.hs, b.nlast
    9a30:	8b010294 	add	x20, x20, x1
    9a34:	39400282 	ldrb	w2, [x20]
    9a38:	34000882 	cbz	w2, 9b48 <fwp_hof0.constprop.0+0x17d8>
    9a3c:	7100045f 	cmp	w2, #0x1
    9a40:	540015a0 	b.eq	9cf4 <fwp_hof0.constprop.0+0x1984>  // b.none
    9a44:	aa1a03f3 	mov	x19, x26
    9a48:	f9401ffa 	ldr	x26, [sp, #56]
    9a4c:	7103fc5f 	cmp	w2, #0xff
    9a50:	54000d80 	b.eq	9c00 <fwp_hof0.constprop.0+0x1890>  // b.none
    9a54:	51000442 	sub	w2, w2, #0x1
    9a58:	39000282 	strb	w2, [x20]
    9a5c:	f9400be0 	ldr	x0, [sp, #16]
    9a60:	b4ff6f20 	cbz	x0, 8844 <fwp_hof0.constprop.0+0x4d4>
    9a64:	f9400be0 	ldr	x0, [sp, #16]
    9a68:	f1000400 	subs	x0, x0, #0x1
    9a6c:	f9000be0 	str	x0, [sp, #16]
    9a70:	54001dc6 	b.vs	9e28 <fwp_hof0.constprop.0+0x1ab8>
    9a74:	911502c0 	add	x0, x22, #0x540
    9a78:	f949ec04 	ldr	x4, [x0, #5080]
    9a7c:	f949d801 	ldr	x1, [x0, #5040]
    9a80:	d370bc84 	lsl	x4, x4, #16
    9a84:	17fffa82 	b	848c <fwp_hof0.constprop.0+0x11c>
    9a88:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9a8c:	9119c000 	add	x0, x0, #0x670
    9a90:	97ffe900 	bl	3e90 <fwp_trap>
    9a94:	aa1a03e0 	mov	x0, x26
    9a98:	97ffef7f 	bl	5894 <fwp_rc_free_arr>
    9a9c:	17fffbde 	b	8a14 <fwp_hof0.constprop.0+0x6a4>
    9aa0:	72003c3f 	tst	w1, #0xffff
    9aa4:	54ff7b81 	b.ne	8a14 <fwp_hof0.constprop.0+0x6a4>  // b.any
    9aa8:	17fffbd3 	b	89f4 <fwp_hof0.constprop.0+0x684>
    9aac:	72003c3f 	tst	w1, #0xffff
    9ab0:	54ff7561 	b.ne	895c <fwp_hof0.constprop.0+0x5ec>  // b.any
    9ab4:	17fffba5 	b	8948 <fwp_hof0.constprop.0+0x5d8>
    9ab8:	f9000be0 	str	x0, [sp, #16]
    9abc:	f90013e3 	str	x3, [sp, #32]
    9ac0:	97ffe914 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9ac4:	f9400be0 	ldr	x0, [sp, #16]
    9ac8:	f94013e3 	ldr	x3, [sp, #32]
    9acc:	17fffba2 	b	8954 <fwp_hof0.constprop.0+0x5e4>
    9ad0:	ca544681 	eor	x1, x20, x20, lsr #17
    9ad4:	911502c2 	add	x2, x22, #0x540
    9ad8:	ca412421 	eor	x1, x1, x1, lsr #9
    9adc:	92401c21 	and	x1, x1, #0xff
    9ae0:	910a2420 	add	x0, x1, #0x289
    9ae4:	8b010c41 	add	x1, x2, x1, lsl #3
    9ae8:	8b000c40 	add	x0, x2, x0, lsl #3
    9aec:	f94a2421 	ldr	x1, [x1, #5192]
    9af0:	b50000a1 	cbnz	x1, 9b04 <fwp_hof0.constprop.0+0x1794>
    9af4:	17fffe50 	b	9434 <fwp_hof0.constprop.0+0x10c4>
    9af8:	91004020 	add	x0, x1, #0x10
    9afc:	f9400821 	ldr	x1, [x1, #16]
    9b00:	b4ffc9a1 	cbz	x1, 9434 <fwp_hof0.constprop.0+0x10c4>
    9b04:	f9400022 	ldr	x2, [x1]
    9b08:	eb14005f 	cmp	x2, x20
    9b0c:	54ffff61 	b.ne	9af8 <fwp_hof0.constprop.0+0x1788>  // b.any
    9b10:	f9400001 	ldr	x1, [x0]
    9b14:	f9400420 	ldr	x0, [x1, #8]
    9b18:	d1000400 	sub	x0, x0, #0x1
    9b1c:	f9000420 	str	x0, [x1, #8]
    9b20:	f103f81f 	cmp	x0, #0xfe
    9b24:	54ff7781 	b.ne	8a14 <fwp_hof0.constprop.0+0x6a4>  // b.any
    9b28:	39400280 	ldrb	w0, [x20]
    9b2c:	7103fc1f 	cmp	w0, #0xff
    9b30:	540011c0 	b.eq	9d68 <fwp_hof0.constprop.0+0x19f8>  // b.none
    9b34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b38:	39000280 	strb	w0, [x20]
    9b3c:	17fffbb6 	b	8a14 <fwp_hof0.constprop.0+0x6a4>
    9b40:	f2403c00 	ands	x0, x0, #0xffff
    9b44:	54fff780 	b.eq	9a34 <fwp_hof0.constprop.0+0x16c4>  // b.none
    9b48:	aa1a03f3 	mov	x19, x26
    9b4c:	f9401ffa 	ldr	x26, [sp, #56]
    9b50:	17ffffc3 	b	9a5c <fwp_hof0.constprop.0+0x16ec>
    9b54:	f9400282 	ldr	x2, [x20]
    9b58:	aa1403e0 	mov	x0, x20
    9b5c:	b7f80742 	tbnz	x2, #63, 9c44 <fwp_hof0.constprop.0+0x18d4>
    9b60:	aa1a03f3 	mov	x19, x26
    9b64:	f9401ffa 	ldr	x26, [sp, #56]
    9b68:	7100089f 	cmp	w4, #0x2
    9b6c:	54000680 	b.eq	9c3c <fwp_hof0.constprop.0+0x18cc>  // b.none
    9b70:	29430102 	ldp	w2, w0, [x8, #24]
    9b74:	9b027c21 	mul	x1, x1, x2
    9b78:	eb41801f 	cmp	x0, x1, lsr #32
    9b7c:	54fff249 	b.ls	99c4 <fwp_hof0.constprop.0+0x1654>  // b.plast
    9b80:	aa1403e0 	mov	x0, x20
    9b84:	97ffe97f 	bl	4180 <fwp_mem_free>
    9b88:	17ffff8f 	b	99c4 <fwp_hof0.constprop.0+0x1654>
    9b8c:	f2403c21 	ands	x1, x1, #0xffff
    9b90:	54fff060 	b.eq	999c <fwp_hof0.constprop.0+0x162c>  // b.none
    9b94:	aa1a03f3 	mov	x19, x26
    9b98:	f9401ffa 	ldr	x26, [sp, #56]
    9b9c:	17ffff8a 	b	99c4 <fwp_hof0.constprop.0+0x1654>
    9ba0:	72003c3f 	tst	w1, #0xffff
    9ba4:	54ffb421 	b.ne	9228 <fwp_hof0.constprop.0+0xeb8>  // b.any
    9ba8:	17fffd9b 	b	9214 <fwp_hof0.constprop.0+0xea4>
    9bac:	72003c1f 	tst	w0, #0xffff
    9bb0:	54ffdc21 	b.ne	9734 <fwp_hof0.constprop.0+0x13c4>  // b.any
    9bb4:	17fffedd 	b	9728 <fwp_hof0.constprop.0+0x13b8>
    9bb8:	52800041 	mov	w1, #0x2                   	// #2
    9bbc:	d2800100 	mov	x0, #0x8                   	// #8
    9bc0:	97ffec2c 	bl	4c70 <fwp_heap_alloc>
    9bc4:	aa0003e2 	mov	x2, x0
    9bc8:	52800008 	mov	w8, #0x0                   	// #0
    9bcc:	aa1903f7 	mov	x23, x25
    9bd0:	d2800019 	mov	x25, #0x0                   	// #0
    9bd4:	7100011f 	cmp	w8, #0x0
    9bd8:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9bdc:	17ffff52 	b	9924 <fwp_hof0.constprop.0+0x15b4>
    9be0:	f9400284 	ldr	x4, [x20]
    9be4:	b7fffea4 	tbnz	x4, #63, 9bb8 <fwp_hof0.constprop.0+0x1848>
    9be8:	9240f884 	and	x4, x4, #0x7fffffffffffffff
    9bec:	d2800017 	mov	x23, #0x0                   	// #0
    9bf0:	17fffdd2 	b	9338 <fwp_hof0.constprop.0+0xfc8>
    9bf4:	aa1903f7 	mov	x23, x25
    9bf8:	aa0403f9 	mov	x25, x4
    9bfc:	17ffff4a 	b	9924 <fwp_hof0.constprop.0+0x15b4>
    9c00:	ca544681 	eor	x1, x20, x20, lsr #17
    9c04:	911502c0 	add	x0, x22, #0x540
    9c08:	ca412421 	eor	x1, x1, x1, lsr #9
    9c0c:	92401c21 	and	x1, x1, #0xff
    9c10:	910a2422 	add	x2, x1, #0x289
    9c14:	8b010c01 	add	x1, x0, x1, lsl #3
    9c18:	8b020c02 	add	x2, x0, x2, lsl #3
    9c1c:	f94a2420 	ldr	x0, [x1, #5192]
    9c20:	b4ffc0a0 	cbz	x0, 9434 <fwp_hof0.constprop.0+0x10c4>
    9c24:	f9400001 	ldr	x1, [x0]
    9c28:	eb01029f 	cmp	x20, x1
    9c2c:	54000200 	b.eq	9c6c <fwp_hof0.constprop.0+0x18fc>  // b.none
    9c30:	91004002 	add	x2, x0, #0x10
    9c34:	f9400800 	ldr	x0, [x0, #16]
    9c38:	17fffffa 	b	9c20 <fwp_hof0.constprop.0+0x18b0>
    9c3c:	b5ffec41 	cbnz	x1, 99c4 <fwp_hof0.constprop.0+0x1654>
    9c40:	17ffffd0 	b	9b80 <fwp_hof0.constprop.0+0x1810>
    9c44:	f9400694 	ldr	x20, [x20, #8]
    9c48:	7100089f 	cmp	w4, #0x2
    9c4c:	54000280 	b.eq	9c9c <fwp_hof0.constprop.0+0x192c>  // b.none
    9c50:	29430903 	ldp	w3, w2, [x8, #24]
    9c54:	9b037c21 	mul	x1, x1, x3
    9c58:	eb41805f 	cmp	x2, x1, lsr #32
    9c5c:	54ffe729 	b.ls	9940 <fwp_hof0.constprop.0+0x15d0>  // b.plast
    9c60:	97ffe948 	bl	4180 <fwp_mem_free>
    9c64:	d2800507 	mov	x7, #0x28                  	// #40
    9c68:	17ffff36 	b	9940 <fwp_hof0.constprop.0+0x15d0>
    9c6c:	f9400041 	ldr	x1, [x2]
    9c70:	f9400420 	ldr	x0, [x1, #8]
    9c74:	d1000400 	sub	x0, x0, #0x1
    9c78:	f9000420 	str	x0, [x1, #8]
    9c7c:	f103f81f 	cmp	x0, #0xfe
    9c80:	54ffeee1 	b.ne	9a5c <fwp_hof0.constprop.0+0x16ec>  // b.any
    9c84:	39400280 	ldrb	w0, [x20]
    9c88:	7103fc1f 	cmp	w0, #0xff
    9c8c:	540000c0 	b.eq	9ca4 <fwp_hof0.constprop.0+0x1934>  // b.none
    9c90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9c94:	39000280 	strb	w0, [x20]
    9c98:	17ffff71 	b	9a5c <fwp_hof0.constprop.0+0x16ec>
    9c9c:	b5ffe521 	cbnz	x1, 9940 <fwp_hof0.constprop.0+0x15d0>
    9ca0:	17fffff0 	b	9c60 <fwp_hof0.constprop.0+0x18f0>
    9ca4:	aa1403e0 	mov	x0, x20
    9ca8:	97ffe89a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9cac:	17fffff9 	b	9c90 <fwp_hof0.constprop.0+0x1920>
    9cb0:	aa1903f7 	mov	x23, x25
    9cb4:	d2800000 	mov	x0, #0x0                   	// #0
    9cb8:	f8607841 	ldr	x1, [x2, x0, lsl #3]
    9cbc:	91000400 	add	x0, x0, #0x1
    9cc0:	f90006e1 	str	x1, [x23, #8]
    9cc4:	aa1703e1 	mov	x1, x23
    9cc8:	f9400af7 	ldr	x23, [x23, #16]
    9ccc:	eb0000df 	cmp	x6, x0
    9cd0:	54ffff48 	b.hi	9cb8 <fwp_hof0.constprop.0+0x1948>  // b.pmore
    9cd4:	f9000824 	str	x4, [x1, #16]
    9cd8:	17ffffbf 	b	9bd4 <fwp_hof0.constprop.0+0x1864>
    9cdc:	d2800006 	mov	x6, #0x0                   	// #0
    9ce0:	17fffe98 	b	9740 <fwp_hof0.constprop.0+0x13d0>
    9ce4:	a90713e0 	stp	x0, x4, [sp, #112]
    9ce8:	97ffe88a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9cec:	a94713e0 	ldp	x0, x4, [sp, #112]
    9cf0:	17fffead 	b	97a4 <fwp_hof0.constprop.0+0x1434>
    9cf4:	aa1703e1 	mov	x1, x23
    9cf8:	f9400af7 	ldr	x23, [x23, #16]
    9cfc:	7100089f 	cmp	w4, #0x2
    9d00:	54000120 	b.eq	9d24 <fwp_hof0.constprop.0+0x19b4>  // b.none
    9d04:	29430864 	ldp	w4, w2, [x3, #24]
    9d08:	9b047c00 	mul	x0, x0, x4
    9d0c:	eb40805f 	cmp	x2, x0, lsr #32
    9d10:	54ffe649 	b.ls	99d8 <fwp_hof0.constprop.0+0x1668>  // b.plast
    9d14:	aa0103e0 	mov	x0, x1
    9d18:	97ffe91a 	bl	4180 <fwp_mem_free>
    9d1c:	d2800507 	mov	x7, #0x28                  	// #40
    9d20:	17ffff2e 	b	99d8 <fwp_hof0.constprop.0+0x1668>
    9d24:	b5ffe5a0 	cbnz	x0, 99d8 <fwp_hof0.constprop.0+0x1668>
    9d28:	17fffffb 	b	9d14 <fwp_hof0.constprop.0+0x19a4>
    9d2c:	ca404401 	eor	x1, x0, x0, lsr #17
    9d30:	911502c4 	add	x4, x22, #0x540
    9d34:	ca412421 	eor	x1, x1, x1, lsr #9
    9d38:	92401c21 	and	x1, x1, #0xff
    9d3c:	910a2422 	add	x2, x1, #0x289
    9d40:	8b010c81 	add	x1, x4, x1, lsl #3
    9d44:	8b020c82 	add	x2, x4, x2, lsl #3
    9d48:	f94a2421 	ldr	x1, [x1, #5192]
    9d4c:	b4ffb741 	cbz	x1, 9434 <fwp_hof0.constprop.0+0x10c4>
    9d50:	f9400023 	ldr	x3, [x1]
    9d54:	eb03001f 	cmp	x0, x3
    9d58:	54000460 	b.eq	9de4 <fwp_hof0.constprop.0+0x1a74>  // b.none
    9d5c:	91004022 	add	x2, x1, #0x10
    9d60:	f9400821 	ldr	x1, [x1, #16]
    9d64:	17fffffa 	b	9d4c <fwp_hof0.constprop.0+0x19dc>
    9d68:	aa1403e0 	mov	x0, x20
    9d6c:	97ffe869 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9d70:	17ffff71 	b	9b34 <fwp_hof0.constprop.0+0x17c4>
    9d74:	a9038be0 	stp	x0, x2, [sp, #56]
    9d78:	97ffe866 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9d7c:	a9438be0 	ldp	x0, x2, [sp, #56]
    9d80:	17fffe21 	b	9604 <fwp_hof0.constprop.0+0x1294>
    9d84:	aa1703e0 	mov	x0, x23
    9d88:	f9002fe4 	str	x4, [sp, #88]
    9d8c:	97ffe861 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9d90:	f9402fe4 	ldr	x4, [sp, #88]
    9d94:	17fffec2 	b	989c <fwp_hof0.constprop.0+0x152c>
    9d98:	f9001fe0 	str	x0, [sp, #56]
    9d9c:	97ffe85d 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9da0:	9100c2a1 	add	x1, x21, #0x30
    9da4:	f9401fe0 	ldr	x0, [sp, #56]
    9da8:	f9416034 	ldr	x20, [x1, #704]
    9dac:	17fffd1d 	b	9220 <fwp_hof0.constprop.0+0xeb0>
    9db0:	a91253f3 	stp	x19, x20, [sp, #288]
    9db4:	a9135bf5 	stp	x21, x22, [sp, #304]
    9db8:	a91463f7 	stp	x23, x24, [sp, #320]
    9dbc:	a9156bf9 	stp	x25, x26, [sp, #336]
    9dc0:	97ffe2b0 	bl	2880 <__stack_chk_fail@plt>
    9dc4:	f9001fe0 	str	x0, [sp, #56]
    9dc8:	97ffe852 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9dcc:	f9401fe0 	ldr	x0, [sp, #56]
    9dd0:	17fffdc5 	b	94e4 <fwp_hof0.constprop.0+0x1174>
    9dd4:	72003c3f 	tst	w1, #0xffff
    9dd8:	54ffc100 	b.eq	95f8 <fwp_hof0.constprop.0+0x1288>  // b.none
    9ddc:	aa1703e0 	mov	x0, x23
    9de0:	17fffd3b 	b	92cc <fwp_hof0.constprop.0+0xf5c>
    9de4:	f9400042 	ldr	x2, [x2]
    9de8:	f9400441 	ldr	x1, [x2, #8]
    9dec:	d1000421 	sub	x1, x1, #0x1
    9df0:	f9000441 	str	x1, [x2, #8]
    9df4:	f103f83f 	cmp	x1, #0xfe
    9df8:	54ffde61 	b.ne	99c4 <fwp_hof0.constprop.0+0x1654>  // b.any
    9dfc:	39400001 	ldrb	w1, [x0]
    9e00:	7103fc3f 	cmp	w1, #0xff
    9e04:	54000080 	b.eq	9e14 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    9e08:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9e0c:	39000001 	strb	w1, [x0]
    9e10:	17fffeed 	b	99c4 <fwp_hof0.constprop.0+0x1654>
    9e14:	f9001fe0 	str	x0, [sp, #56]
    9e18:	97ffe83e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9e1c:	f9401fe0 	ldr	x0, [sp, #56]
    9e20:	17fffffa 	b	9e08 <fwp_hof0.constprop.0+0x1a98>
    9e24:	97ffe2ab 	bl	28d0 <abort@plt>
    9e28:	97ffe316 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9e2c:	d503201f 	nop

0000000000009e30 <f0>:
    9e30:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9e34:	910003fd 	mov	x29, sp
    9e38:	a90153f3 	stp	x19, x20, [sp, #16]
    9e3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9e40:	a90363f7 	stp	x23, x24, [sp, #48]
    9e44:	a9046bf9 	stp	x25, x26, [sp, #64]
    9e48:	a90573fb 	stp	x27, x28, [sp, #80]
    9e4c:	d121c3ff 	sub	sp, sp, #0x870
    9e50:	f90203ff 	str	xzr, [sp, #1024]
    9e54:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e58:	9100c003 	add	x3, x0, #0x30
    9e5c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9e60:	f947f400 	ldr	x0, [x0, #4072]
    9e64:	90000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    9e68:	f9416065 	ldr	x5, [x3, #704]
    9e6c:	f9400001 	ldr	x1, [x0]
    9e70:	f90437e1 	str	x1, [sp, #2152]
    9e74:	d2800001 	mov	x1, #0x0                   	// #0
    9e78:	91150299 	add	x25, x20, #0x540
    9e7c:	912163f6 	add	x22, sp, #0x858
    9e80:	910063e4 	add	x4, sp, #0x18
    9e84:	9100c3e1 	add	x1, sp, #0x30
    9e88:	90ffffe0 	adrp	x0, 5000 <fwp_tape_grow.constprop.0+0x15c>
    9e8c:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9e90:	912fc000 	add	x0, x0, #0xbf0
    9e94:	913d4042 	add	x2, x2, #0xf50
    9e98:	d2800013 	mov	x19, #0x0                   	// #0
    9e9c:	d280011a 	mov	x26, #0x8                   	// #8
    9ea0:	d2800015 	mov	x21, #0x0                   	// #0
    9ea4:	52800037 	mov	w23, #0x1                   	// #1
    9ea8:	f90007e4 	str	x4, [sp, #8]
    9eac:	a9018be5 	stp	x5, x2, [sp, #24]
    9eb0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    9eb4:	a90403ff 	stp	xzr, x0, [sp, #64]
    9eb8:	f9016064 	str	x4, [x3, #704]
    9ebc:	d503201f 	nop
    9ec0:	f100075b 	subs	x27, x26, #0x1
    9ec4:	aa1603e1 	mov	x1, x22
    9ec8:	da1f02b8 	sbc	x24, x21, xzr
    9ecc:	52800020 	mov	w0, #0x1                   	// #1
    9ed0:	f9001ffb 	str	x27, [sp, #56]
    9ed4:	aa1b03fa 	mov	x26, x27
    9ed8:	f9042ffb 	str	x27, [sp, #2136]
    9edc:	aa1803f5 	mov	x21, x24
    9ee0:	f90433f3 	str	x19, [sp, #2144]
    9ee4:	97ffeba8 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ee8:	f949db22 	ldr	x2, [x25, #5040]
    9eec:	aa0003f3 	mov	x19, x0
    9ef0:	f949ef20 	ldr	x0, [x25, #5080]
    9ef4:	cb020262 	sub	x2, x19, x2
    9ef8:	eb00405f 	cmp	x2, x0, lsl #16
    9efc:	54000302 	b.cs	9f5c <f0+0x12c>  // b.hs, b.nlast
    9f00:	d350fc40 	lsr	x0, x2, #16
    9f04:	f949ff25 	ldr	x5, [x25, #5112]
    9f08:	8b000800 	add	x0, x0, x0, lsl #2
    9f0c:	d37df001 	lsl	x1, x0, #3
    9f10:	8b0100a0 	add	x0, x5, x1
    9f14:	f940101c 	ldr	x28, [x0, #32]
    9f18:	b400023c 	cbz	x28, 9f5c <f0+0x12c>
    9f1c:	386168a1 	ldrb	w1, [x5, x1]
    9f20:	7100083f 	cmp	w1, #0x2
    9f24:	54010f40 	b.eq	c10c <f0+0x22dc>  // b.none
    9f28:	7100043f 	cmp	w1, #0x1
    9f2c:	54000181 	b.ne	9f5c <f0+0x12c>  // b.any
    9f30:	29430001 	ldp	w1, w0, [x0, #24]
    9f34:	92403c42 	and	x2, x2, #0xffff
    9f38:	9b017c42 	mul	x2, x2, x1
    9f3c:	d360fc42 	lsr	x2, x2, #32
    9f40:	eb00005f 	cmp	x2, x0
    9f44:	540000c2 	b.cs	9f5c <f0+0x12c>  // b.hs, b.nlast
    9f48:	8b02039c 	add	x28, x28, x2
    9f4c:	39400380 	ldrb	w0, [x28]
    9f50:	7103fc1f 	cmp	w0, #0xff
    9f54:	54010d60 	b.eq	c100 <f0+0x22d0>  // b.none
    9f58:	39000397 	strb	w23, [x28]
    9f5c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    9f60:	aa18037b 	orr	x27, x27, x24
    9f64:	b5fffafb 	cbnz	x27, 9ec0 <f0+0x90>
    9f68:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f6c:	9100c018 	add	x24, x0, #0x30
    9f70:	f94007e1 	ldr	x1, [sp, #8]
    9f74:	f9001bff 	str	xzr, [sp, #48]
    9f78:	f9416300 	ldr	x0, [x24, #704]
    9f7c:	eb01001f 	cmp	x0, x1
    9f80:	54012a21 	b.ne	c4c4 <f0+0x2694>  // b.any
    9f84:	90000020 	adrp	x0, d000 <__modti3+0x2a0>
    9f88:	910143e1 	add	x1, sp, #0x50
    9f8c:	f9400fe2 	ldr	x2, [sp, #24]
    9f90:	f9016302 	str	x2, [x24, #704]
    9f94:	3dc37800 	ldr	q0, [x0, #3552]
    9f98:	52800020 	mov	w0, #0x1                   	// #1
    9f9c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9fa0:	3d8017e0 	str	q0, [sp, #80]
    9fa4:	97ffeb78 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fa8:	97ffee0b 	bl	57d4 <fwp_rc_fresh>
    9fac:	9101a3e1 	add	x1, sp, #0x68
    9fb0:	aa0003e2 	mov	x2, x0
    9fb4:	52800020 	mov	w0, #0x1                   	// #1
    9fb8:	a9068bf5 	stp	x21, x2, [sp, #104]
    9fbc:	97ffeb72 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fc0:	97ffee05 	bl	57d4 <fwp_rc_fresh>
    9fc4:	aa0003e2 	mov	x2, x0
    9fc8:	90000023 	adrp	x3, d000 <__modti3+0x2a0>
    9fcc:	9101e3e1 	add	x1, sp, #0x78
    9fd0:	52800020 	mov	w0, #0x1                   	// #1
    9fd4:	f90043e2 	str	x2, [sp, #128]
    9fd8:	3dc37860 	ldr	q0, [x3, #3552]
    9fdc:	fd003fe0 	str	d0, [sp, #120]
    9fe0:	97ffeb69 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fe4:	97ffedfc 	bl	57d4 <fwp_rc_fresh>
    9fe8:	aa0003e2 	mov	x2, x0
    9fec:	910223e1 	add	x1, sp, #0x88
    9ff0:	52800020 	mov	w0, #0x1                   	// #1
    9ff4:	a9088bf5 	stp	x21, x2, [sp, #136]
    9ff8:	97ffeb63 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ffc:	97ffedf6 	bl	57d4 <fwp_rc_fresh>
    a000:	aa0003e2 	mov	x2, x0
    a004:	f0000003 	adrp	x3, d000 <__modti3+0x2a0>
    a008:	910263e1 	add	x1, sp, #0x98
    a00c:	52800020 	mov	w0, #0x1                   	// #1
    a010:	f90053e2 	str	x2, [sp, #160]
    a014:	3dc37860 	ldr	q0, [x3, #3552]
    a018:	fd004fe0 	str	d0, [sp, #152]
    a01c:	97ffeb5a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a020:	97ffeded 	bl	57d4 <fwp_rc_fresh>
    a024:	aa0003e2 	mov	x2, x0
    a028:	9102a3e1 	add	x1, sp, #0xa8
    a02c:	52800020 	mov	w0, #0x1                   	// #1
    a030:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a034:	97ffeb54 	bl	4d84 <fwp_data.part.0.constprop.0>
    a038:	91150283 	add	x3, x20, #0x540
    a03c:	aa0003f5 	mov	x21, x0
    a040:	f949d861 	ldr	x1, [x3, #5040]
    a044:	f949ec60 	ldr	x0, [x3, #5080]
    a048:	cb0102a1 	sub	x1, x21, x1
    a04c:	eb00403f 	cmp	x1, x0, lsl #16
    a050:	54000322 	b.cs	a0b4 <f0+0x284>  // b.hs, b.nlast
    a054:	d350fc22 	lsr	x2, x1, #16
    a058:	f949fc63 	ldr	x3, [x3, #5112]
    a05c:	8b020842 	add	x2, x2, x2, lsl #2
    a060:	d37df042 	lsl	x2, x2, #3
    a064:	8b020060 	add	x0, x3, x2
    a068:	f9401017 	ldr	x23, [x0, #32]
    a06c:	b4000257 	cbz	x23, a0b4 <f0+0x284>
    a070:	38626862 	ldrb	w2, [x3, x2]
    a074:	7100085f 	cmp	w2, #0x2
    a078:	54010500 	b.eq	c118 <f0+0x22e8>  // b.none
    a07c:	7100045f 	cmp	w2, #0x1
    a080:	540001a1 	b.ne	a0b4 <f0+0x284>  // b.any
    a084:	29430002 	ldp	w2, w0, [x0, #24]
    a088:	92403c21 	and	x1, x1, #0xffff
    a08c:	9b027c21 	mul	x1, x1, x2
    a090:	d360fc21 	lsr	x1, x1, #32
    a094:	eb00003f 	cmp	x1, x0
    a098:	540000e2 	b.cs	a0b4 <f0+0x284>  // b.hs, b.nlast
    a09c:	8b0102f7 	add	x23, x23, x1
    a0a0:	394002e0 	ldrb	w0, [x23]
    a0a4:	7103fc1f 	cmp	w0, #0xff
    a0a8:	54011280 	b.eq	c2f8 <f0+0x24c8>  // b.none
    a0ac:	52800020 	mov	w0, #0x1                   	// #1
    a0b0:	390002e0 	strb	w0, [x23]
    a0b4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a0b8:	9102e3e1 	add	x1, sp, #0xb8
    a0bc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a0c0:	52800020 	mov	w0, #0x1                   	// #1
    a0c4:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a0c8:	97ffeb2f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0cc:	97ffedc2 	bl	57d4 <fwp_rc_fresh>
    a0d0:	aa0003e2 	mov	x2, x0
    a0d4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a0d8:	910323e1 	add	x1, sp, #0xc8
    a0dc:	52800020 	mov	w0, #0x1                   	// #1
    a0e0:	a90c8be3 	stp	x3, x2, [sp, #200]
    a0e4:	97ffeb28 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0e8:	91150283 	add	x3, x20, #0x540
    a0ec:	aa0003f5 	mov	x21, x0
    a0f0:	f949d861 	ldr	x1, [x3, #5040]
    a0f4:	f949ec60 	ldr	x0, [x3, #5080]
    a0f8:	cb0102a1 	sub	x1, x21, x1
    a0fc:	eb00403f 	cmp	x1, x0, lsl #16
    a100:	54000322 	b.cs	a164 <f0+0x334>  // b.hs, b.nlast
    a104:	d350fc22 	lsr	x2, x1, #16
    a108:	f949fc63 	ldr	x3, [x3, #5112]
    a10c:	8b020842 	add	x2, x2, x2, lsl #2
    a110:	d37df042 	lsl	x2, x2, #3
    a114:	8b020060 	add	x0, x3, x2
    a118:	f9401017 	ldr	x23, [x0, #32]
    a11c:	b4000257 	cbz	x23, a164 <f0+0x334>
    a120:	38626862 	ldrb	w2, [x3, x2]
    a124:	7100085f 	cmp	w2, #0x2
    a128:	54010040 	b.eq	c130 <f0+0x2300>  // b.none
    a12c:	7100045f 	cmp	w2, #0x1
    a130:	540001a1 	b.ne	a164 <f0+0x334>  // b.any
    a134:	29430002 	ldp	w2, w0, [x0, #24]
    a138:	92403c21 	and	x1, x1, #0xffff
    a13c:	9b027c21 	mul	x1, x1, x2
    a140:	d360fc21 	lsr	x1, x1, #32
    a144:	eb00003f 	cmp	x1, x0
    a148:	540000e2 	b.cs	a164 <f0+0x334>  // b.hs, b.nlast
    a14c:	8b0102f7 	add	x23, x23, x1
    a150:	394002e0 	ldrb	w0, [x23]
    a154:	7103fc1f 	cmp	w0, #0xff
    a158:	54010d60 	b.eq	c304 <f0+0x24d4>  // b.none
    a15c:	52800020 	mov	w0, #0x1                   	// #1
    a160:	390002e0 	strb	w0, [x23]
    a164:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a168:	910363e1 	add	x1, sp, #0xd8
    a16c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a170:	52800020 	mov	w0, #0x1                   	// #1
    a174:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a178:	97ffeb03 	bl	4d84 <fwp_data.part.0.constprop.0>
    a17c:	97ffed96 	bl	57d4 <fwp_rc_fresh>
    a180:	aa0003e2 	mov	x2, x0
    a184:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a188:	9103a3e1 	add	x1, sp, #0xe8
    a18c:	52800020 	mov	w0, #0x1                   	// #1
    a190:	a90e8be3 	stp	x3, x2, [sp, #232]
    a194:	97ffeafc 	bl	4d84 <fwp_data.part.0.constprop.0>
    a198:	91150283 	add	x3, x20, #0x540
    a19c:	aa0003f5 	mov	x21, x0
    a1a0:	f949d861 	ldr	x1, [x3, #5040]
    a1a4:	f949ec60 	ldr	x0, [x3, #5080]
    a1a8:	cb0102a1 	sub	x1, x21, x1
    a1ac:	eb00403f 	cmp	x1, x0, lsl #16
    a1b0:	54000322 	b.cs	a214 <f0+0x3e4>  // b.hs, b.nlast
    a1b4:	d350fc22 	lsr	x2, x1, #16
    a1b8:	f949fc63 	ldr	x3, [x3, #5112]
    a1bc:	8b020842 	add	x2, x2, x2, lsl #2
    a1c0:	d37df042 	lsl	x2, x2, #3
    a1c4:	8b020060 	add	x0, x3, x2
    a1c8:	f9401017 	ldr	x23, [x0, #32]
    a1cc:	b4000257 	cbz	x23, a214 <f0+0x3e4>
    a1d0:	38626862 	ldrb	w2, [x3, x2]
    a1d4:	7100085f 	cmp	w2, #0x2
    a1d8:	5400fa60 	b.eq	c124 <f0+0x22f4>  // b.none
    a1dc:	7100045f 	cmp	w2, #0x1
    a1e0:	540001a1 	b.ne	a214 <f0+0x3e4>  // b.any
    a1e4:	29430002 	ldp	w2, w0, [x0, #24]
    a1e8:	92403c21 	and	x1, x1, #0xffff
    a1ec:	9b027c21 	mul	x1, x1, x2
    a1f0:	d360fc21 	lsr	x1, x1, #32
    a1f4:	eb00003f 	cmp	x1, x0
    a1f8:	540000e2 	b.cs	a214 <f0+0x3e4>  // b.hs, b.nlast
    a1fc:	8b0102f7 	add	x23, x23, x1
    a200:	394002e0 	ldrb	w0, [x23]
    a204:	7103fc1f 	cmp	w0, #0xff
    a208:	54010840 	b.eq	c310 <f0+0x24e0>  // b.none
    a20c:	52800020 	mov	w0, #0x1                   	// #1
    a210:	390002e0 	strb	w0, [x23]
    a214:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a218:	9103e3e1 	add	x1, sp, #0xf8
    a21c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a220:	52800020 	mov	w0, #0x1                   	// #1
    a224:	a90fd7e2 	stp	x2, x21, [sp, #248]
    a228:	97ffead7 	bl	4d84 <fwp_data.part.0.constprop.0>
    a22c:	97ffed6a 	bl	57d4 <fwp_rc_fresh>
    a230:	aa0003e2 	mov	x2, x0
    a234:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a238:	910423e1 	add	x1, sp, #0x108
    a23c:	52800020 	mov	w0, #0x1                   	// #1
    a240:	a9108be3 	stp	x3, x2, [sp, #264]
    a244:	97ffead0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a248:	91150283 	add	x3, x20, #0x540
    a24c:	aa0003f5 	mov	x21, x0
    a250:	f949d861 	ldr	x1, [x3, #5040]
    a254:	f949ec60 	ldr	x0, [x3, #5080]
    a258:	cb0102a1 	sub	x1, x21, x1
    a25c:	eb00403f 	cmp	x1, x0, lsl #16
    a260:	54000322 	b.cs	a2c4 <f0+0x494>  // b.hs, b.nlast
    a264:	d350fc22 	lsr	x2, x1, #16
    a268:	f949fc63 	ldr	x3, [x3, #5112]
    a26c:	8b020842 	add	x2, x2, x2, lsl #2
    a270:	d37df042 	lsl	x2, x2, #3
    a274:	8b020060 	add	x0, x3, x2
    a278:	f9401017 	ldr	x23, [x0, #32]
    a27c:	b4000257 	cbz	x23, a2c4 <f0+0x494>
    a280:	38626862 	ldrb	w2, [x3, x2]
    a284:	7100085f 	cmp	w2, #0x2
    a288:	5400f600 	b.eq	c148 <f0+0x2318>  // b.none
    a28c:	7100045f 	cmp	w2, #0x1
    a290:	540001a1 	b.ne	a2c4 <f0+0x494>  // b.any
    a294:	29430002 	ldp	w2, w0, [x0, #24]
    a298:	92403c21 	and	x1, x1, #0xffff
    a29c:	9b027c21 	mul	x1, x1, x2
    a2a0:	d360fc21 	lsr	x1, x1, #32
    a2a4:	eb00003f 	cmp	x1, x0
    a2a8:	540000e2 	b.cs	a2c4 <f0+0x494>  // b.hs, b.nlast
    a2ac:	8b0102f7 	add	x23, x23, x1
    a2b0:	394002e0 	ldrb	w0, [x23]
    a2b4:	7103fc1f 	cmp	w0, #0xff
    a2b8:	54010320 	b.eq	c31c <f0+0x24ec>  // b.none
    a2bc:	52800020 	mov	w0, #0x1                   	// #1
    a2c0:	390002e0 	strb	w0, [x23]
    a2c4:	910463e1 	add	x1, sp, #0x118
    a2c8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a2cc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	a911d7f7 	stp	x23, x21, [sp, #280]
    a2d8:	97ffeaab 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2dc:	97ffed3e 	bl	57d4 <fwp_rc_fresh>
    a2e0:	aa0003e2 	mov	x2, x0
    a2e4:	9104a3e1 	add	x1, sp, #0x128
    a2e8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a2ec:	52800020 	mov	w0, #0x1                   	// #1
    a2f0:	a9128bf5 	stp	x21, x2, [sp, #296]
    a2f4:	97ffeaa4 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2f8:	97ffed37 	bl	57d4 <fwp_rc_fresh>
    a2fc:	aa0003e2 	mov	x2, x0
    a300:	9104e3e1 	add	x1, sp, #0x138
    a304:	52800020 	mov	w0, #0x1                   	// #1
    a308:	a9138bf7 	stp	x23, x2, [sp, #312]
    a30c:	97ffea9e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a310:	97ffed31 	bl	57d4 <fwp_rc_fresh>
    a314:	aa0003e2 	mov	x2, x0
    a318:	910523e1 	add	x1, sp, #0x148
    a31c:	52800020 	mov	w0, #0x1                   	// #1
    a320:	a9148bf5 	stp	x21, x2, [sp, #328]
    a324:	97ffea98 	bl	4d84 <fwp_data.part.0.constprop.0>
    a328:	91150283 	add	x3, x20, #0x540
    a32c:	aa0003f5 	mov	x21, x0
    a330:	f949d861 	ldr	x1, [x3, #5040]
    a334:	f949ec60 	ldr	x0, [x3, #5080]
    a338:	cb0102a1 	sub	x1, x21, x1
    a33c:	eb00403f 	cmp	x1, x0, lsl #16
    a340:	54000322 	b.cs	a3a4 <f0+0x574>  // b.hs, b.nlast
    a344:	d350fc22 	lsr	x2, x1, #16
    a348:	f949fc63 	ldr	x3, [x3, #5112]
    a34c:	8b020842 	add	x2, x2, x2, lsl #2
    a350:	d37df042 	lsl	x2, x2, #3
    a354:	8b020060 	add	x0, x3, x2
    a358:	f9401017 	ldr	x23, [x0, #32]
    a35c:	b4000257 	cbz	x23, a3a4 <f0+0x574>
    a360:	38626862 	ldrb	w2, [x3, x2]
    a364:	7100085f 	cmp	w2, #0x2
    a368:	5400eea0 	b.eq	c13c <f0+0x230c>  // b.none
    a36c:	7100045f 	cmp	w2, #0x1
    a370:	540001a1 	b.ne	a3a4 <f0+0x574>  // b.any
    a374:	29430002 	ldp	w2, w0, [x0, #24]
    a378:	92403c21 	and	x1, x1, #0xffff
    a37c:	9b027c21 	mul	x1, x1, x2
    a380:	d360fc21 	lsr	x1, x1, #32
    a384:	eb00003f 	cmp	x1, x0
    a388:	540000e2 	b.cs	a3a4 <f0+0x574>  // b.hs, b.nlast
    a38c:	8b0102f7 	add	x23, x23, x1
    a390:	394002e0 	ldrb	w0, [x23]
    a394:	7103fc1f 	cmp	w0, #0xff
    a398:	5400fc80 	b.eq	c328 <f0+0x24f8>  // b.none
    a39c:	52800020 	mov	w0, #0x1                   	// #1
    a3a0:	390002e0 	strb	w0, [x23]
    a3a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a3a8:	910563e1 	add	x1, sp, #0x158
    a3ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a3b0:	52800020 	mov	w0, #0x1                   	// #1
    a3b4:	a915d7e2 	stp	x2, x21, [sp, #344]
    a3b8:	97ffea73 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3bc:	91150283 	add	x3, x20, #0x540
    a3c0:	aa0003f5 	mov	x21, x0
    a3c4:	f949d861 	ldr	x1, [x3, #5040]
    a3c8:	f949ec60 	ldr	x0, [x3, #5080]
    a3cc:	cb0102a1 	sub	x1, x21, x1
    a3d0:	eb00403f 	cmp	x1, x0, lsl #16
    a3d4:	54000322 	b.cs	a438 <f0+0x608>  // b.hs, b.nlast
    a3d8:	d350fc22 	lsr	x2, x1, #16
    a3dc:	f949fc63 	ldr	x3, [x3, #5112]
    a3e0:	8b020842 	add	x2, x2, x2, lsl #2
    a3e4:	d37df042 	lsl	x2, x2, #3
    a3e8:	8b020060 	add	x0, x3, x2
    a3ec:	f9401017 	ldr	x23, [x0, #32]
    a3f0:	b4000257 	cbz	x23, a438 <f0+0x608>
    a3f4:	38626862 	ldrb	w2, [x3, x2]
    a3f8:	7100085f 	cmp	w2, #0x2
    a3fc:	5400eb20 	b.eq	c160 <f0+0x2330>  // b.none
    a400:	7100045f 	cmp	w2, #0x1
    a404:	540001a1 	b.ne	a438 <f0+0x608>  // b.any
    a408:	29430002 	ldp	w2, w0, [x0, #24]
    a40c:	92403c21 	and	x1, x1, #0xffff
    a410:	9b027c21 	mul	x1, x1, x2
    a414:	d360fc21 	lsr	x1, x1, #32
    a418:	eb00003f 	cmp	x1, x0
    a41c:	540000e2 	b.cs	a438 <f0+0x608>  // b.hs, b.nlast
    a420:	8b0102f7 	add	x23, x23, x1
    a424:	394002e0 	ldrb	w0, [x23]
    a428:	7103fc1f 	cmp	w0, #0xff
    a42c:	5400f840 	b.eq	c334 <f0+0x2504>  // b.none
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	390002e0 	strb	w0, [x23]
    a438:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a43c:	9105a3e1 	add	x1, sp, #0x168
    a440:	52800020 	mov	w0, #0x1                   	// #1
    a444:	a916d7e2 	stp	x2, x21, [sp, #360]
    a448:	97ffea4f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a44c:	91150283 	add	x3, x20, #0x540
    a450:	aa0003f5 	mov	x21, x0
    a454:	f949d861 	ldr	x1, [x3, #5040]
    a458:	f949ec60 	ldr	x0, [x3, #5080]
    a45c:	cb0102a1 	sub	x1, x21, x1
    a460:	eb00403f 	cmp	x1, x0, lsl #16
    a464:	54000322 	b.cs	a4c8 <f0+0x698>  // b.hs, b.nlast
    a468:	d350fc22 	lsr	x2, x1, #16
    a46c:	f949fc63 	ldr	x3, [x3, #5112]
    a470:	8b020842 	add	x2, x2, x2, lsl #2
    a474:	d37df042 	lsl	x2, x2, #3
    a478:	8b020060 	add	x0, x3, x2
    a47c:	f9401017 	ldr	x23, [x0, #32]
    a480:	b4000257 	cbz	x23, a4c8 <f0+0x698>
    a484:	38626862 	ldrb	w2, [x3, x2]
    a488:	7100085f 	cmp	w2, #0x2
    a48c:	5400e640 	b.eq	c154 <f0+0x2324>  // b.none
    a490:	7100045f 	cmp	w2, #0x1
    a494:	540001a1 	b.ne	a4c8 <f0+0x698>  // b.any
    a498:	29430002 	ldp	w2, w0, [x0, #24]
    a49c:	92403c21 	and	x1, x1, #0xffff
    a4a0:	9b027c21 	mul	x1, x1, x2
    a4a4:	d360fc21 	lsr	x1, x1, #32
    a4a8:	eb00003f 	cmp	x1, x0
    a4ac:	540000e2 	b.cs	a4c8 <f0+0x698>  // b.hs, b.nlast
    a4b0:	8b0102f7 	add	x23, x23, x1
    a4b4:	394002e0 	ldrb	w0, [x23]
    a4b8:	7103fc1f 	cmp	w0, #0xff
    a4bc:	5400f420 	b.eq	c340 <f0+0x2510>  // b.none
    a4c0:	52800020 	mov	w0, #0x1                   	// #1
    a4c4:	390002e0 	strb	w0, [x23]
    a4c8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4cc:	9105e3e1 	add	x1, sp, #0x178
    a4d0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4d4:	52800020 	mov	w0, #0x1                   	// #1
    a4d8:	a917d7e2 	stp	x2, x21, [sp, #376]
    a4dc:	97ffea2a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a4e0:	97ffecbd 	bl	57d4 <fwp_rc_fresh>
    a4e4:	aa0003e2 	mov	x2, x0
    a4e8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a4ec:	910623e1 	add	x1, sp, #0x188
    a4f0:	52800020 	mov	w0, #0x1                   	// #1
    a4f4:	a9188be3 	stp	x3, x2, [sp, #392]
    a4f8:	97ffea23 	bl	4d84 <fwp_data.part.0.constprop.0>
    a4fc:	91150283 	add	x3, x20, #0x540
    a500:	aa0003f5 	mov	x21, x0
    a504:	f949d861 	ldr	x1, [x3, #5040]
    a508:	f949ec60 	ldr	x0, [x3, #5080]
    a50c:	cb0102a1 	sub	x1, x21, x1
    a510:	eb00403f 	cmp	x1, x0, lsl #16
    a514:	54000322 	b.cs	a578 <f0+0x748>  // b.hs, b.nlast
    a518:	d350fc22 	lsr	x2, x1, #16
    a51c:	f949fc63 	ldr	x3, [x3, #5112]
    a520:	8b020842 	add	x2, x2, x2, lsl #2
    a524:	d37df042 	lsl	x2, x2, #3
    a528:	8b020060 	add	x0, x3, x2
    a52c:	f9401017 	ldr	x23, [x0, #32]
    a530:	b4000257 	cbz	x23, a578 <f0+0x748>
    a534:	38626862 	ldrb	w2, [x3, x2]
    a538:	7100085f 	cmp	w2, #0x2
    a53c:	5400e7e0 	b.eq	c238 <f0+0x2408>  // b.none
    a540:	7100045f 	cmp	w2, #0x1
    a544:	540001a1 	b.ne	a578 <f0+0x748>  // b.any
    a548:	29430002 	ldp	w2, w0, [x0, #24]
    a54c:	92403c21 	and	x1, x1, #0xffff
    a550:	9b027c21 	mul	x1, x1, x2
    a554:	d360fc21 	lsr	x1, x1, #32
    a558:	eb00003f 	cmp	x1, x0
    a55c:	540000e2 	b.cs	a578 <f0+0x748>  // b.hs, b.nlast
    a560:	8b0102f7 	add	x23, x23, x1
    a564:	394002e0 	ldrb	w0, [x23]
    a568:	7103fc1f 	cmp	w0, #0xff
    a56c:	5400ef00 	b.eq	c34c <f0+0x251c>  // b.none
    a570:	52800020 	mov	w0, #0x1                   	// #1
    a574:	390002e0 	strb	w0, [x23]
    a578:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a57c:	910663e1 	add	x1, sp, #0x198
    a580:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a584:	52800020 	mov	w0, #0x1                   	// #1
    a588:	a919d7e2 	stp	x2, x21, [sp, #408]
    a58c:	97ffe9fe 	bl	4d84 <fwp_data.part.0.constprop.0>
    a590:	97ffec91 	bl	57d4 <fwp_rc_fresh>
    a594:	aa0003e2 	mov	x2, x0
    a598:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a59c:	9106a3e1 	add	x1, sp, #0x1a8
    a5a0:	52800020 	mov	w0, #0x1                   	// #1
    a5a4:	a91a8be3 	stp	x3, x2, [sp, #424]
    a5a8:	97ffe9f7 	bl	4d84 <fwp_data.part.0.constprop.0>
    a5ac:	91150283 	add	x3, x20, #0x540
    a5b0:	aa0003f5 	mov	x21, x0
    a5b4:	f949d861 	ldr	x1, [x3, #5040]
    a5b8:	f949ec60 	ldr	x0, [x3, #5080]
    a5bc:	cb0102a1 	sub	x1, x21, x1
    a5c0:	eb00403f 	cmp	x1, x0, lsl #16
    a5c4:	54000322 	b.cs	a628 <f0+0x7f8>  // b.hs, b.nlast
    a5c8:	d350fc22 	lsr	x2, x1, #16
    a5cc:	f949fc63 	ldr	x3, [x3, #5112]
    a5d0:	8b020842 	add	x2, x2, x2, lsl #2
    a5d4:	d37df042 	lsl	x2, x2, #3
    a5d8:	8b020060 	add	x0, x3, x2
    a5dc:	f9401017 	ldr	x23, [x0, #32]
    a5e0:	b4000257 	cbz	x23, a628 <f0+0x7f8>
    a5e4:	38626862 	ldrb	w2, [x3, x2]
    a5e8:	7100085f 	cmp	w2, #0x2
    a5ec:	5400e200 	b.eq	c22c <f0+0x23fc>  // b.none
    a5f0:	7100045f 	cmp	w2, #0x1
    a5f4:	540001a1 	b.ne	a628 <f0+0x7f8>  // b.any
    a5f8:	29430002 	ldp	w2, w0, [x0, #24]
    a5fc:	92403c21 	and	x1, x1, #0xffff
    a600:	9b027c21 	mul	x1, x1, x2
    a604:	d360fc21 	lsr	x1, x1, #32
    a608:	eb00003f 	cmp	x1, x0
    a60c:	540000e2 	b.cs	a628 <f0+0x7f8>  // b.hs, b.nlast
    a610:	8b0102f7 	add	x23, x23, x1
    a614:	394002e0 	ldrb	w0, [x23]
    a618:	7103fc1f 	cmp	w0, #0xff
    a61c:	5400e9e0 	b.eq	c358 <f0+0x2528>  // b.none
    a620:	52800020 	mov	w0, #0x1                   	// #1
    a624:	390002e0 	strb	w0, [x23]
    a628:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a62c:	9106e3e1 	add	x1, sp, #0x1b8
    a630:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a634:	52800020 	mov	w0, #0x1                   	// #1
    a638:	a91bd7e2 	stp	x2, x21, [sp, #440]
    a63c:	97ffe9d2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a640:	97ffec65 	bl	57d4 <fwp_rc_fresh>
    a644:	aa0003e2 	mov	x2, x0
    a648:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a64c:	910723e1 	add	x1, sp, #0x1c8
    a650:	52800020 	mov	w0, #0x1                   	// #1
    a654:	a91c8be3 	stp	x3, x2, [sp, #456]
    a658:	97ffe9cb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a65c:	91150283 	add	x3, x20, #0x540
    a660:	aa0003f5 	mov	x21, x0
    a664:	f949d861 	ldr	x1, [x3, #5040]
    a668:	f949ec60 	ldr	x0, [x3, #5080]
    a66c:	cb0102a1 	sub	x1, x21, x1
    a670:	eb00403f 	cmp	x1, x0, lsl #16
    a674:	54000322 	b.cs	a6d8 <f0+0x8a8>  // b.hs, b.nlast
    a678:	d350fc22 	lsr	x2, x1, #16
    a67c:	f949fc63 	ldr	x3, [x3, #5112]
    a680:	8b020842 	add	x2, x2, x2, lsl #2
    a684:	d37df042 	lsl	x2, x2, #3
    a688:	8b020060 	add	x0, x3, x2
    a68c:	f9401017 	ldr	x23, [x0, #32]
    a690:	b4000257 	cbz	x23, a6d8 <f0+0x8a8>
    a694:	38626862 	ldrb	w2, [x3, x2]
    a698:	7100085f 	cmp	w2, #0x2
    a69c:	5400dda0 	b.eq	c250 <f0+0x2420>  // b.none
    a6a0:	7100045f 	cmp	w2, #0x1
    a6a4:	540001a1 	b.ne	a6d8 <f0+0x8a8>  // b.any
    a6a8:	29430002 	ldp	w2, w0, [x0, #24]
    a6ac:	92403c21 	and	x1, x1, #0xffff
    a6b0:	9b027c21 	mul	x1, x1, x2
    a6b4:	d360fc21 	lsr	x1, x1, #32
    a6b8:	eb00003f 	cmp	x1, x0
    a6bc:	540000e2 	b.cs	a6d8 <f0+0x8a8>  // b.hs, b.nlast
    a6c0:	8b0102f7 	add	x23, x23, x1
    a6c4:	394002e0 	ldrb	w0, [x23]
    a6c8:	7103fc1f 	cmp	w0, #0xff
    a6cc:	5400e4c0 	b.eq	c364 <f0+0x2534>  // b.none
    a6d0:	52800020 	mov	w0, #0x1                   	// #1
    a6d4:	390002e0 	strb	w0, [x23]
    a6d8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a6dc:	910763e1 	add	x1, sp, #0x1d8
    a6e0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a6e4:	52800020 	mov	w0, #0x1                   	// #1
    a6e8:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a6ec:	97ffe9a6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6f0:	97ffec39 	bl	57d4 <fwp_rc_fresh>
    a6f4:	aa0003e2 	mov	x2, x0
    a6f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a6fc:	9107a3e1 	add	x1, sp, #0x1e8
    a700:	52800020 	mov	w0, #0x1                   	// #1
    a704:	a91e8be3 	stp	x3, x2, [sp, #488]
    a708:	97ffe99f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a70c:	91150283 	add	x3, x20, #0x540
    a710:	aa0003f5 	mov	x21, x0
    a714:	f949d861 	ldr	x1, [x3, #5040]
    a718:	f949ec60 	ldr	x0, [x3, #5080]
    a71c:	cb0102a1 	sub	x1, x21, x1
    a720:	eb00403f 	cmp	x1, x0, lsl #16
    a724:	54000322 	b.cs	a788 <f0+0x958>  // b.hs, b.nlast
    a728:	d350fc22 	lsr	x2, x1, #16
    a72c:	f949fc63 	ldr	x3, [x3, #5112]
    a730:	8b020842 	add	x2, x2, x2, lsl #2
    a734:	d37df042 	lsl	x2, x2, #3
    a738:	8b020060 	add	x0, x3, x2
    a73c:	f9401017 	ldr	x23, [x0, #32]
    a740:	b4000257 	cbz	x23, a788 <f0+0x958>
    a744:	38626862 	ldrb	w2, [x3, x2]
    a748:	7100085f 	cmp	w2, #0x2
    a74c:	5400d7c0 	b.eq	c244 <f0+0x2414>  // b.none
    a750:	7100045f 	cmp	w2, #0x1
    a754:	540001a1 	b.ne	a788 <f0+0x958>  // b.any
    a758:	29430002 	ldp	w2, w0, [x0, #24]
    a75c:	92403c21 	and	x1, x1, #0xffff
    a760:	9b027c21 	mul	x1, x1, x2
    a764:	d360fc21 	lsr	x1, x1, #32
    a768:	eb00003f 	cmp	x1, x0
    a76c:	540000e2 	b.cs	a788 <f0+0x958>  // b.hs, b.nlast
    a770:	8b0102f7 	add	x23, x23, x1
    a774:	394002e0 	ldrb	w0, [x23]
    a778:	7103fc1f 	cmp	w0, #0xff
    a77c:	5400dfa0 	b.eq	c370 <f0+0x2540>  // b.none
    a780:	52800020 	mov	w0, #0x1                   	// #1
    a784:	390002e0 	strb	w0, [x23]
    a788:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a78c:	9107e3e1 	add	x1, sp, #0x1f8
    a790:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a794:	52800020 	mov	w0, #0x1                   	// #1
    a798:	a91fd7e2 	stp	x2, x21, [sp, #504]
    a79c:	97ffe97a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7a0:	97ffec0d 	bl	57d4 <fwp_rc_fresh>
    a7a4:	aa0003e2 	mov	x2, x0
    a7a8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7ac:	910823e1 	add	x1, sp, #0x208
    a7b0:	52800020 	mov	w0, #0x1                   	// #1
    a7b4:	f90107e3 	str	x3, [sp, #520]
    a7b8:	f9010be2 	str	x2, [sp, #528]
    a7bc:	97ffe972 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7c0:	91150283 	add	x3, x20, #0x540
    a7c4:	aa0003f5 	mov	x21, x0
    a7c8:	f949d861 	ldr	x1, [x3, #5040]
    a7cc:	f949ec60 	ldr	x0, [x3, #5080]
    a7d0:	cb0102a1 	sub	x1, x21, x1
    a7d4:	eb00403f 	cmp	x1, x0, lsl #16
    a7d8:	54000322 	b.cs	a83c <f0+0xa0c>  // b.hs, b.nlast
    a7dc:	d350fc22 	lsr	x2, x1, #16
    a7e0:	f949fc63 	ldr	x3, [x3, #5112]
    a7e4:	8b020842 	add	x2, x2, x2, lsl #2
    a7e8:	d37df042 	lsl	x2, x2, #3
    a7ec:	8b020060 	add	x0, x3, x2
    a7f0:	f9401017 	ldr	x23, [x0, #32]
    a7f4:	b4000257 	cbz	x23, a83c <f0+0xa0c>
    a7f8:	38626862 	ldrb	w2, [x3, x2]
    a7fc:	7100085f 	cmp	w2, #0x2
    a800:	5400d340 	b.eq	c268 <f0+0x2438>  // b.none
    a804:	7100045f 	cmp	w2, #0x1
    a808:	540001a1 	b.ne	a83c <f0+0xa0c>  // b.any
    a80c:	29430002 	ldp	w2, w0, [x0, #24]
    a810:	92403c21 	and	x1, x1, #0xffff
    a814:	9b027c21 	mul	x1, x1, x2
    a818:	d360fc21 	lsr	x1, x1, #32
    a81c:	eb00003f 	cmp	x1, x0
    a820:	540000e2 	b.cs	a83c <f0+0xa0c>  // b.hs, b.nlast
    a824:	8b0102f7 	add	x23, x23, x1
    a828:	394002e0 	ldrb	w0, [x23]
    a82c:	7103fc1f 	cmp	w0, #0xff
    a830:	5400da60 	b.eq	c37c <f0+0x254c>  // b.none
    a834:	52800020 	mov	w0, #0x1                   	// #1
    a838:	390002e0 	strb	w0, [x23]
    a83c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a840:	910863e1 	add	x1, sp, #0x218
    a844:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a848:	52800020 	mov	w0, #0x1                   	// #1
    a84c:	f9010fe2 	str	x2, [sp, #536]
    a850:	f90113f5 	str	x21, [sp, #544]
    a854:	97ffe94c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a858:	97ffebdf 	bl	57d4 <fwp_rc_fresh>
    a85c:	aa0003e2 	mov	x2, x0
    a860:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a864:	9108a3e1 	add	x1, sp, #0x228
    a868:	52800020 	mov	w0, #0x1                   	// #1
    a86c:	f90117e3 	str	x3, [sp, #552]
    a870:	f9011be2 	str	x2, [sp, #560]
    a874:	97ffe944 	bl	4d84 <fwp_data.part.0.constprop.0>
    a878:	91150283 	add	x3, x20, #0x540
    a87c:	aa0003f5 	mov	x21, x0
    a880:	f949d861 	ldr	x1, [x3, #5040]
    a884:	f949ec60 	ldr	x0, [x3, #5080]
    a888:	cb0102a1 	sub	x1, x21, x1
    a88c:	eb00403f 	cmp	x1, x0, lsl #16
    a890:	54000322 	b.cs	a8f4 <f0+0xac4>  // b.hs, b.nlast
    a894:	d350fc22 	lsr	x2, x1, #16
    a898:	f949fc63 	ldr	x3, [x3, #5112]
    a89c:	8b020842 	add	x2, x2, x2, lsl #2
    a8a0:	d37df042 	lsl	x2, x2, #3
    a8a4:	8b020060 	add	x0, x3, x2
    a8a8:	f9401017 	ldr	x23, [x0, #32]
    a8ac:	b4000257 	cbz	x23, a8f4 <f0+0xac4>
    a8b0:	38626862 	ldrb	w2, [x3, x2]
    a8b4:	7100085f 	cmp	w2, #0x2
    a8b8:	5400cd20 	b.eq	c25c <f0+0x242c>  // b.none
    a8bc:	7100045f 	cmp	w2, #0x1
    a8c0:	540001a1 	b.ne	a8f4 <f0+0xac4>  // b.any
    a8c4:	29430002 	ldp	w2, w0, [x0, #24]
    a8c8:	92403c21 	and	x1, x1, #0xffff
    a8cc:	9b027c21 	mul	x1, x1, x2
    a8d0:	d360fc21 	lsr	x1, x1, #32
    a8d4:	eb00003f 	cmp	x1, x0
    a8d8:	540000e2 	b.cs	a8f4 <f0+0xac4>  // b.hs, b.nlast
    a8dc:	8b0102f7 	add	x23, x23, x1
    a8e0:	394002e0 	ldrb	w0, [x23]
    a8e4:	7103fc1f 	cmp	w0, #0xff
    a8e8:	5400d500 	b.eq	c388 <f0+0x2558>  // b.none
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	390002e0 	strb	w0, [x23]
    a8f4:	9108e3e1 	add	x1, sp, #0x238
    a8f8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a8fc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	f9011ff7 	str	x23, [sp, #568]
    a908:	f90123f5 	str	x21, [sp, #576]
    a90c:	97ffe91e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a910:	97ffebb1 	bl	57d4 <fwp_rc_fresh>
    a914:	aa0003e2 	mov	x2, x0
    a918:	910923e1 	add	x1, sp, #0x248
    a91c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a920:	52800020 	mov	w0, #0x1                   	// #1
    a924:	f90127f5 	str	x21, [sp, #584]
    a928:	f9012be2 	str	x2, [sp, #592]
    a92c:	97ffe916 	bl	4d84 <fwp_data.part.0.constprop.0>
    a930:	97ffeba9 	bl	57d4 <fwp_rc_fresh>
    a934:	aa0003e2 	mov	x2, x0
    a938:	910963e1 	add	x1, sp, #0x258
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	f9012ff7 	str	x23, [sp, #600]
    a944:	f90133e2 	str	x2, [sp, #608]
    a948:	97ffe90f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a94c:	97ffeba2 	bl	57d4 <fwp_rc_fresh>
    a950:	aa0003e2 	mov	x2, x0
    a954:	9109a3e1 	add	x1, sp, #0x268
    a958:	52800020 	mov	w0, #0x1                   	// #1
    a95c:	f90137f5 	str	x21, [sp, #616]
    a960:	f9013be2 	str	x2, [sp, #624]
    a964:	97ffe908 	bl	4d84 <fwp_data.part.0.constprop.0>
    a968:	91150283 	add	x3, x20, #0x540
    a96c:	aa0003f5 	mov	x21, x0
    a970:	f949d861 	ldr	x1, [x3, #5040]
    a974:	f949ec60 	ldr	x0, [x3, #5080]
    a978:	cb0102a1 	sub	x1, x21, x1
    a97c:	eb00403f 	cmp	x1, x0, lsl #16
    a980:	54000322 	b.cs	a9e4 <f0+0xbb4>  // b.hs, b.nlast
    a984:	d350fc22 	lsr	x2, x1, #16
    a988:	f949fc63 	ldr	x3, [x3, #5112]
    a98c:	8b020842 	add	x2, x2, x2, lsl #2
    a990:	d37df042 	lsl	x2, x2, #3
    a994:	8b020060 	add	x0, x3, x2
    a998:	f9401017 	ldr	x23, [x0, #32]
    a99c:	b4000257 	cbz	x23, a9e4 <f0+0xbb4>
    a9a0:	38626862 	ldrb	w2, [x3, x2]
    a9a4:	7100085f 	cmp	w2, #0x2
    a9a8:	5400c6c0 	b.eq	c280 <f0+0x2450>  // b.none
    a9ac:	7100045f 	cmp	w2, #0x1
    a9b0:	540001a1 	b.ne	a9e4 <f0+0xbb4>  // b.any
    a9b4:	29430002 	ldp	w2, w0, [x0, #24]
    a9b8:	92403c21 	and	x1, x1, #0xffff
    a9bc:	9b027c21 	mul	x1, x1, x2
    a9c0:	d360fc21 	lsr	x1, x1, #32
    a9c4:	eb00003f 	cmp	x1, x0
    a9c8:	540000e2 	b.cs	a9e4 <f0+0xbb4>  // b.hs, b.nlast
    a9cc:	8b0102f7 	add	x23, x23, x1
    a9d0:	394002e0 	ldrb	w0, [x23]
    a9d4:	7103fc1f 	cmp	w0, #0xff
    a9d8:	5400cde0 	b.eq	c394 <f0+0x2564>  // b.none
    a9dc:	52800020 	mov	w0, #0x1                   	// #1
    a9e0:	390002e0 	strb	w0, [x23]
    a9e4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a9e8:	9109e3e1 	add	x1, sp, #0x278
    a9ec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	f9013fe2 	str	x2, [sp, #632]
    a9f8:	f90143f5 	str	x21, [sp, #640]
    a9fc:	97ffe8e2 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa00:	97ffeb75 	bl	57d4 <fwp_rc_fresh>
    aa04:	aa0003e2 	mov	x2, x0
    aa08:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa0c:	910a23e1 	add	x1, sp, #0x288
    aa10:	52800020 	mov	w0, #0x1                   	// #1
    aa14:	f90147e3 	str	x3, [sp, #648]
    aa18:	f9014be2 	str	x2, [sp, #656]
    aa1c:	97ffe8da 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa20:	91150283 	add	x3, x20, #0x540
    aa24:	aa0003f5 	mov	x21, x0
    aa28:	f949d861 	ldr	x1, [x3, #5040]
    aa2c:	f949ec60 	ldr	x0, [x3, #5080]
    aa30:	cb0102a1 	sub	x1, x21, x1
    aa34:	eb00403f 	cmp	x1, x0, lsl #16
    aa38:	54000322 	b.cs	aa9c <f0+0xc6c>  // b.hs, b.nlast
    aa3c:	d350fc22 	lsr	x2, x1, #16
    aa40:	f949fc63 	ldr	x3, [x3, #5112]
    aa44:	8b020842 	add	x2, x2, x2, lsl #2
    aa48:	d37df042 	lsl	x2, x2, #3
    aa4c:	8b020060 	add	x0, x3, x2
    aa50:	f9401017 	ldr	x23, [x0, #32]
    aa54:	b4000257 	cbz	x23, aa9c <f0+0xc6c>
    aa58:	38626862 	ldrb	w2, [x3, x2]
    aa5c:	7100085f 	cmp	w2, #0x2
    aa60:	5400c0a0 	b.eq	c274 <f0+0x2444>  // b.none
    aa64:	7100045f 	cmp	w2, #0x1
    aa68:	540001a1 	b.ne	aa9c <f0+0xc6c>  // b.any
    aa6c:	29430002 	ldp	w2, w0, [x0, #24]
    aa70:	92403c21 	and	x1, x1, #0xffff
    aa74:	9b027c21 	mul	x1, x1, x2
    aa78:	d360fc21 	lsr	x1, x1, #32
    aa7c:	eb00003f 	cmp	x1, x0
    aa80:	540000e2 	b.cs	aa9c <f0+0xc6c>  // b.hs, b.nlast
    aa84:	8b0102f7 	add	x23, x23, x1
    aa88:	394002e0 	ldrb	w0, [x23]
    aa8c:	7103fc1f 	cmp	w0, #0xff
    aa90:	5400c880 	b.eq	c3a0 <f0+0x2570>  // b.none
    aa94:	52800020 	mov	w0, #0x1                   	// #1
    aa98:	390002e0 	strb	w0, [x23]
    aa9c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aaa0:	910a63e1 	add	x1, sp, #0x298
    aaa4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	f9014fe2 	str	x2, [sp, #664]
    aab0:	f90153f5 	str	x21, [sp, #672]
    aab4:	97ffe8b4 	bl	4d84 <fwp_data.part.0.constprop.0>
    aab8:	91150283 	add	x3, x20, #0x540
    aabc:	aa0003f5 	mov	x21, x0
    aac0:	f949d861 	ldr	x1, [x3, #5040]
    aac4:	f949ec60 	ldr	x0, [x3, #5080]
    aac8:	cb0102a1 	sub	x1, x21, x1
    aacc:	eb00403f 	cmp	x1, x0, lsl #16
    aad0:	54000322 	b.cs	ab34 <f0+0xd04>  // b.hs, b.nlast
    aad4:	d350fc22 	lsr	x2, x1, #16
    aad8:	f949fc63 	ldr	x3, [x3, #5112]
    aadc:	8b020842 	add	x2, x2, x2, lsl #2
    aae0:	d37df042 	lsl	x2, x2, #3
    aae4:	8b020060 	add	x0, x3, x2
    aae8:	f9401017 	ldr	x23, [x0, #32]
    aaec:	b4000257 	cbz	x23, ab34 <f0+0xd04>
    aaf0:	38626862 	ldrb	w2, [x3, x2]
    aaf4:	7100085f 	cmp	w2, #0x2
    aaf8:	5400bd00 	b.eq	c298 <f0+0x2468>  // b.none
    aafc:	7100045f 	cmp	w2, #0x1
    ab00:	540001a1 	b.ne	ab34 <f0+0xd04>  // b.any
    ab04:	29430002 	ldp	w2, w0, [x0, #24]
    ab08:	92403c21 	and	x1, x1, #0xffff
    ab0c:	9b027c21 	mul	x1, x1, x2
    ab10:	d360fc21 	lsr	x1, x1, #32
    ab14:	eb00003f 	cmp	x1, x0
    ab18:	540000e2 	b.cs	ab34 <f0+0xd04>  // b.hs, b.nlast
    ab1c:	8b0102f7 	add	x23, x23, x1
    ab20:	394002e0 	ldrb	w0, [x23]
    ab24:	7103fc1f 	cmp	w0, #0xff
    ab28:	5400c420 	b.eq	c3ac <f0+0x257c>  // b.none
    ab2c:	52800020 	mov	w0, #0x1                   	// #1
    ab30:	390002e0 	strb	w0, [x23]
    ab34:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab38:	910aa3e1 	add	x1, sp, #0x2a8
    ab3c:	52800020 	mov	w0, #0x1                   	// #1
    ab40:	f90157e2 	str	x2, [sp, #680]
    ab44:	f9015bf5 	str	x21, [sp, #688]
    ab48:	97ffe88f 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab4c:	91150283 	add	x3, x20, #0x540
    ab50:	aa0003f5 	mov	x21, x0
    ab54:	f949d861 	ldr	x1, [x3, #5040]
    ab58:	f949ec60 	ldr	x0, [x3, #5080]
    ab5c:	cb0102a1 	sub	x1, x21, x1
    ab60:	eb00403f 	cmp	x1, x0, lsl #16
    ab64:	54000322 	b.cs	abc8 <f0+0xd98>  // b.hs, b.nlast
    ab68:	d350fc22 	lsr	x2, x1, #16
    ab6c:	f949fc63 	ldr	x3, [x3, #5112]
    ab70:	8b020842 	add	x2, x2, x2, lsl #2
    ab74:	d37df042 	lsl	x2, x2, #3
    ab78:	8b020060 	add	x0, x3, x2
    ab7c:	f9401017 	ldr	x23, [x0, #32]
    ab80:	b4000257 	cbz	x23, abc8 <f0+0xd98>
    ab84:	38626862 	ldrb	w2, [x3, x2]
    ab88:	7100085f 	cmp	w2, #0x2
    ab8c:	5400b800 	b.eq	c28c <f0+0x245c>  // b.none
    ab90:	7100045f 	cmp	w2, #0x1
    ab94:	540001a1 	b.ne	abc8 <f0+0xd98>  // b.any
    ab98:	29430002 	ldp	w2, w0, [x0, #24]
    ab9c:	92403c21 	and	x1, x1, #0xffff
    aba0:	9b027c21 	mul	x1, x1, x2
    aba4:	d360fc21 	lsr	x1, x1, #32
    aba8:	eb00003f 	cmp	x1, x0
    abac:	540000e2 	b.cs	abc8 <f0+0xd98>  // b.hs, b.nlast
    abb0:	8b0102f7 	add	x23, x23, x1
    abb4:	394002e0 	ldrb	w0, [x23]
    abb8:	7103fc1f 	cmp	w0, #0xff
    abbc:	5400bfe0 	b.eq	c3b8 <f0+0x2588>  // b.none
    abc0:	52800020 	mov	w0, #0x1                   	// #1
    abc4:	390002e0 	strb	w0, [x23]
    abc8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    abcc:	910ae3e1 	add	x1, sp, #0x2b8
    abd0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abd4:	52800020 	mov	w0, #0x1                   	// #1
    abd8:	f9015fe2 	str	x2, [sp, #696]
    abdc:	f90163f5 	str	x21, [sp, #704]
    abe0:	97ffe869 	bl	4d84 <fwp_data.part.0.constprop.0>
    abe4:	91150283 	add	x3, x20, #0x540
    abe8:	aa0003f5 	mov	x21, x0
    abec:	f949d861 	ldr	x1, [x3, #5040]
    abf0:	f949ec60 	ldr	x0, [x3, #5080]
    abf4:	cb0102a1 	sub	x1, x21, x1
    abf8:	eb00403f 	cmp	x1, x0, lsl #16
    abfc:	54000322 	b.cs	ac60 <f0+0xe30>  // b.hs, b.nlast
    ac00:	d350fc22 	lsr	x2, x1, #16
    ac04:	f949fc63 	ldr	x3, [x3, #5112]
    ac08:	8b020842 	add	x2, x2, x2, lsl #2
    ac0c:	d37df042 	lsl	x2, x2, #3
    ac10:	8b020060 	add	x0, x3, x2
    ac14:	f9401017 	ldr	x23, [x0, #32]
    ac18:	b4000257 	cbz	x23, ac60 <f0+0xe30>
    ac1c:	38626862 	ldrb	w2, [x3, x2]
    ac20:	7100085f 	cmp	w2, #0x2
    ac24:	5400b460 	b.eq	c2b0 <f0+0x2480>  // b.none
    ac28:	7100045f 	cmp	w2, #0x1
    ac2c:	540001a1 	b.ne	ac60 <f0+0xe30>  // b.any
    ac30:	29430002 	ldp	w2, w0, [x0, #24]
    ac34:	92403c21 	and	x1, x1, #0xffff
    ac38:	9b027c21 	mul	x1, x1, x2
    ac3c:	d360fc21 	lsr	x1, x1, #32
    ac40:	eb00003f 	cmp	x1, x0
    ac44:	540000e2 	b.cs	ac60 <f0+0xe30>  // b.hs, b.nlast
    ac48:	8b0102f7 	add	x23, x23, x1
    ac4c:	394002e0 	ldrb	w0, [x23]
    ac50:	7103fc1f 	cmp	w0, #0xff
    ac54:	5400bb80 	b.eq	c3c4 <f0+0x2594>  // b.none
    ac58:	52800020 	mov	w0, #0x1                   	// #1
    ac5c:	390002e0 	strb	w0, [x23]
    ac60:	910b23e1 	add	x1, sp, #0x2c8
    ac64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac68:	52800020 	mov	w0, #0x1                   	// #1
    ac6c:	f90167e2 	str	x2, [sp, #712]
    ac70:	f9016bf5 	str	x21, [sp, #720]
    ac74:	97ffe844 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac78:	97ffead7 	bl	57d4 <fwp_rc_fresh>
    ac7c:	aa0003e2 	mov	x2, x0
    ac80:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac84:	910b63e1 	add	x1, sp, #0x2d8
    ac88:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac8c:	52800020 	mov	w0, #0x1                   	// #1
    ac90:	f9016fe3 	str	x3, [sp, #728]
    ac94:	f90173e2 	str	x2, [sp, #736]
    ac98:	97ffe83b 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac9c:	91150283 	add	x3, x20, #0x540
    aca0:	aa0003f5 	mov	x21, x0
    aca4:	f949d861 	ldr	x1, [x3, #5040]
    aca8:	f949ec60 	ldr	x0, [x3, #5080]
    acac:	cb0102a1 	sub	x1, x21, x1
    acb0:	eb00403f 	cmp	x1, x0, lsl #16
    acb4:	54000322 	b.cs	ad18 <f0+0xee8>  // b.hs, b.nlast
    acb8:	d350fc22 	lsr	x2, x1, #16
    acbc:	f949fc63 	ldr	x3, [x3, #5112]
    acc0:	8b020842 	add	x2, x2, x2, lsl #2
    acc4:	d37df042 	lsl	x2, x2, #3
    acc8:	8b020060 	add	x0, x3, x2
    accc:	f9401017 	ldr	x23, [x0, #32]
    acd0:	b4000257 	cbz	x23, ad18 <f0+0xee8>
    acd4:	38626862 	ldrb	w2, [x3, x2]
    acd8:	7100085f 	cmp	w2, #0x2
    acdc:	5400ae40 	b.eq	c2a4 <f0+0x2474>  // b.none
    ace0:	7100045f 	cmp	w2, #0x1
    ace4:	540001a1 	b.ne	ad18 <f0+0xee8>  // b.any
    ace8:	29430002 	ldp	w2, w0, [x0, #24]
    acec:	92403c21 	and	x1, x1, #0xffff
    acf0:	9b027c21 	mul	x1, x1, x2
    acf4:	d360fc21 	lsr	x1, x1, #32
    acf8:	eb00003f 	cmp	x1, x0
    acfc:	540000e2 	b.cs	ad18 <f0+0xee8>  // b.hs, b.nlast
    ad00:	8b0102f7 	add	x23, x23, x1
    ad04:	394002e0 	ldrb	w0, [x23]
    ad08:	7103fc1f 	cmp	w0, #0xff
    ad0c:	5400b620 	b.eq	c3d0 <f0+0x25a0>  // b.none
    ad10:	52800020 	mov	w0, #0x1                   	// #1
    ad14:	390002e0 	strb	w0, [x23]
    ad18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad1c:	910ba3e1 	add	x1, sp, #0x2e8
    ad20:	52800020 	mov	w0, #0x1                   	// #1
    ad24:	f90177e2 	str	x2, [sp, #744]
    ad28:	f9017bf5 	str	x21, [sp, #752]
    ad2c:	97ffe816 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad30:	91150283 	add	x3, x20, #0x540
    ad34:	aa0003f5 	mov	x21, x0
    ad38:	f949d861 	ldr	x1, [x3, #5040]
    ad3c:	f949ec60 	ldr	x0, [x3, #5080]
    ad40:	cb0102a1 	sub	x1, x21, x1
    ad44:	eb00403f 	cmp	x1, x0, lsl #16
    ad48:	54000322 	b.cs	adac <f0+0xf7c>  // b.hs, b.nlast
    ad4c:	d350fc22 	lsr	x2, x1, #16
    ad50:	f949fc63 	ldr	x3, [x3, #5112]
    ad54:	8b020842 	add	x2, x2, x2, lsl #2
    ad58:	d37df042 	lsl	x2, x2, #3
    ad5c:	8b020060 	add	x0, x3, x2
    ad60:	f9401017 	ldr	x23, [x0, #32]
    ad64:	b4000257 	cbz	x23, adac <f0+0xf7c>
    ad68:	38626862 	ldrb	w2, [x3, x2]
    ad6c:	7100085f 	cmp	w2, #0x2
    ad70:	5400aac0 	b.eq	c2c8 <f0+0x2498>  // b.none
    ad74:	7100045f 	cmp	w2, #0x1
    ad78:	540001a1 	b.ne	adac <f0+0xf7c>  // b.any
    ad7c:	29430002 	ldp	w2, w0, [x0, #24]
    ad80:	92403c21 	and	x1, x1, #0xffff
    ad84:	9b027c21 	mul	x1, x1, x2
    ad88:	d360fc21 	lsr	x1, x1, #32
    ad8c:	eb00003f 	cmp	x1, x0
    ad90:	540000e2 	b.cs	adac <f0+0xf7c>  // b.hs, b.nlast
    ad94:	8b0102f7 	add	x23, x23, x1
    ad98:	394002e0 	ldrb	w0, [x23]
    ad9c:	7103fc1f 	cmp	w0, #0xff
    ada0:	5400b1e0 	b.eq	c3dc <f0+0x25ac>  // b.none
    ada4:	52800020 	mov	w0, #0x1                   	// #1
    ada8:	390002e0 	strb	w0, [x23]
    adac:	910be3e1 	add	x1, sp, #0x2f8
    adb0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    adb4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    adb8:	52800020 	mov	w0, #0x1                   	// #1
    adbc:	f9017ff7 	str	x23, [sp, #760]
    adc0:	f90183f5 	str	x21, [sp, #768]
    adc4:	97ffe7f0 	bl	4d84 <fwp_data.part.0.constprop.0>
    adc8:	97ffea83 	bl	57d4 <fwp_rc_fresh>
    adcc:	aa0003e2 	mov	x2, x0
    add0:	910c23e1 	add	x1, sp, #0x308
    add4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	f90187f5 	str	x21, [sp, #776]
    ade0:	f9018be2 	str	x2, [sp, #784]
    ade4:	97ffe7e8 	bl	4d84 <fwp_data.part.0.constprop.0>
    ade8:	97ffea7b 	bl	57d4 <fwp_rc_fresh>
    adec:	aa0003e2 	mov	x2, x0
    adf0:	910c63e1 	add	x1, sp, #0x318
    adf4:	52800020 	mov	w0, #0x1                   	// #1
    adf8:	f9018ff7 	str	x23, [sp, #792]
    adfc:	f90193e2 	str	x2, [sp, #800]
    ae00:	97ffe7e1 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae04:	97ffea74 	bl	57d4 <fwp_rc_fresh>
    ae08:	aa0003e2 	mov	x2, x0
    ae0c:	910ca3e1 	add	x1, sp, #0x328
    ae10:	52800020 	mov	w0, #0x1                   	// #1
    ae14:	f90197f5 	str	x21, [sp, #808]
    ae18:	f9019be2 	str	x2, [sp, #816]
    ae1c:	97ffe7da 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae20:	91150283 	add	x3, x20, #0x540
    ae24:	aa0003f5 	mov	x21, x0
    ae28:	f949d861 	ldr	x1, [x3, #5040]
    ae2c:	f949ec60 	ldr	x0, [x3, #5080]
    ae30:	cb0102a1 	sub	x1, x21, x1
    ae34:	eb00403f 	cmp	x1, x0, lsl #16
    ae38:	54000322 	b.cs	ae9c <f0+0x106c>  // b.hs, b.nlast
    ae3c:	d350fc22 	lsr	x2, x1, #16
    ae40:	f949fc63 	ldr	x3, [x3, #5112]
    ae44:	8b020842 	add	x2, x2, x2, lsl #2
    ae48:	d37df042 	lsl	x2, x2, #3
    ae4c:	8b020060 	add	x0, x3, x2
    ae50:	f9401017 	ldr	x23, [x0, #32]
    ae54:	b4000257 	cbz	x23, ae9c <f0+0x106c>
    ae58:	38626862 	ldrb	w2, [x3, x2]
    ae5c:	7100085f 	cmp	w2, #0x2
    ae60:	5400a2e0 	b.eq	c2bc <f0+0x248c>  // b.none
    ae64:	7100045f 	cmp	w2, #0x1
    ae68:	540001a1 	b.ne	ae9c <f0+0x106c>  // b.any
    ae6c:	29430002 	ldp	w2, w0, [x0, #24]
    ae70:	92403c21 	and	x1, x1, #0xffff
    ae74:	9b027c21 	mul	x1, x1, x2
    ae78:	d360fc21 	lsr	x1, x1, #32
    ae7c:	eb00003f 	cmp	x1, x0
    ae80:	540000e2 	b.cs	ae9c <f0+0x106c>  // b.hs, b.nlast
    ae84:	8b0102f7 	add	x23, x23, x1
    ae88:	394002e0 	ldrb	w0, [x23]
    ae8c:	7103fc1f 	cmp	w0, #0xff
    ae90:	5400aac0 	b.eq	c3e8 <f0+0x25b8>  // b.none
    ae94:	52800020 	mov	w0, #0x1                   	// #1
    ae98:	390002e0 	strb	w0, [x23]
    ae9c:	910ce3e1 	add	x1, sp, #0x338
    aea0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aea4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aea8:	52800020 	mov	w0, #0x1                   	// #1
    aeac:	f9019ff7 	str	x23, [sp, #824]
    aeb0:	f901a3f5 	str	x21, [sp, #832]
    aeb4:	97ffe7b4 	bl	4d84 <fwp_data.part.0.constprop.0>
    aeb8:	97ffea47 	bl	57d4 <fwp_rc_fresh>
    aebc:	aa0003e2 	mov	x2, x0
    aec0:	910d23e1 	add	x1, sp, #0x348
    aec4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	f901a7f5 	str	x21, [sp, #840]
    aed0:	f901abe2 	str	x2, [sp, #848]
    aed4:	97ffe7ac 	bl	4d84 <fwp_data.part.0.constprop.0>
    aed8:	97ffea3f 	bl	57d4 <fwp_rc_fresh>
    aedc:	aa0003e2 	mov	x2, x0
    aee0:	910d63e1 	add	x1, sp, #0x358
    aee4:	52800020 	mov	w0, #0x1                   	// #1
    aee8:	f901aff7 	str	x23, [sp, #856]
    aeec:	f901b3e2 	str	x2, [sp, #864]
    aef0:	97ffe7a5 	bl	4d84 <fwp_data.part.0.constprop.0>
    aef4:	97ffea38 	bl	57d4 <fwp_rc_fresh>
    aef8:	aa0003e2 	mov	x2, x0
    aefc:	910da3e1 	add	x1, sp, #0x368
    af00:	52800020 	mov	w0, #0x1                   	// #1
    af04:	f901b7f5 	str	x21, [sp, #872]
    af08:	f901bbe2 	str	x2, [sp, #880]
    af0c:	97ffe79e 	bl	4d84 <fwp_data.part.0.constprop.0>
    af10:	97ffea31 	bl	57d4 <fwp_rc_fresh>
    af14:	aa0003e2 	mov	x2, x0
    af18:	910de3e1 	add	x1, sp, #0x378
    af1c:	52800020 	mov	w0, #0x1                   	// #1
    af20:	f901bff7 	str	x23, [sp, #888]
    af24:	f901c3e2 	str	x2, [sp, #896]
    af28:	97ffe797 	bl	4d84 <fwp_data.part.0.constprop.0>
    af2c:	91150283 	add	x3, x20, #0x540
    af30:	aa0003f5 	mov	x21, x0
    af34:	f949d861 	ldr	x1, [x3, #5040]
    af38:	f949ec60 	ldr	x0, [x3, #5080]
    af3c:	cb0102a1 	sub	x1, x21, x1
    af40:	eb00403f 	cmp	x1, x0, lsl #16
    af44:	54000322 	b.cs	afa8 <f0+0x1178>  // b.hs, b.nlast
    af48:	d350fc22 	lsr	x2, x1, #16
    af4c:	f949fc63 	ldr	x3, [x3, #5112]
    af50:	8b020842 	add	x2, x2, x2, lsl #2
    af54:	d37df042 	lsl	x2, x2, #3
    af58:	8b020060 	add	x0, x3, x2
    af5c:	f9401017 	ldr	x23, [x0, #32]
    af60:	b4000257 	cbz	x23, afa8 <f0+0x1178>
    af64:	38626862 	ldrb	w2, [x3, x2]
    af68:	7100085f 	cmp	w2, #0x2
    af6c:	54009ba0 	b.eq	c2e0 <f0+0x24b0>  // b.none
    af70:	7100045f 	cmp	w2, #0x1
    af74:	540001a1 	b.ne	afa8 <f0+0x1178>  // b.any
    af78:	29430002 	ldp	w2, w0, [x0, #24]
    af7c:	92403c21 	and	x1, x1, #0xffff
    af80:	9b027c21 	mul	x1, x1, x2
    af84:	d360fc21 	lsr	x1, x1, #32
    af88:	eb00003f 	cmp	x1, x0
    af8c:	540000e2 	b.cs	afa8 <f0+0x1178>  // b.hs, b.nlast
    af90:	8b0102f7 	add	x23, x23, x1
    af94:	394002e0 	ldrb	w0, [x23]
    af98:	7103fc1f 	cmp	w0, #0xff
    af9c:	5400a2c0 	b.eq	c3f4 <f0+0x25c4>  // b.none
    afa0:	52800020 	mov	w0, #0x1                   	// #1
    afa4:	390002e0 	strb	w0, [x23]
    afa8:	910e23e1 	add	x1, sp, #0x388
    afac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afb0:	52800020 	mov	w0, #0x1                   	// #1
    afb4:	f901c7f7 	str	x23, [sp, #904]
    afb8:	f901cbf5 	str	x21, [sp, #912]
    afbc:	97ffe772 	bl	4d84 <fwp_data.part.0.constprop.0>
    afc0:	97ffea05 	bl	57d4 <fwp_rc_fresh>
    afc4:	aa0003e2 	mov	x2, x0
    afc8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afcc:	910e63e1 	add	x1, sp, #0x398
    afd0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afd4:	52800020 	mov	w0, #0x1                   	// #1
    afd8:	f901cfe3 	str	x3, [sp, #920]
    afdc:	f901d3e2 	str	x2, [sp, #928]
    afe0:	97ffe769 	bl	4d84 <fwp_data.part.0.constprop.0>
    afe4:	97ffe9fc 	bl	57d4 <fwp_rc_fresh>
    afe8:	aa0003e2 	mov	x2, x0
    afec:	910ea3e1 	add	x1, sp, #0x3a8
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f901d7f7 	str	x23, [sp, #936]
    aff8:	f901dbe2 	str	x2, [sp, #944]
    affc:	97ffe762 	bl	4d84 <fwp_data.part.0.constprop.0>
    b000:	91150283 	add	x3, x20, #0x540
    b004:	aa0003f5 	mov	x21, x0
    b008:	f949d861 	ldr	x1, [x3, #5040]
    b00c:	f949ec60 	ldr	x0, [x3, #5080]
    b010:	cb0102a1 	sub	x1, x21, x1
    b014:	eb00403f 	cmp	x1, x0, lsl #16
    b018:	54000322 	b.cs	b07c <f0+0x124c>  // b.hs, b.nlast
    b01c:	d350fc22 	lsr	x2, x1, #16
    b020:	f949fc63 	ldr	x3, [x3, #5112]
    b024:	8b020842 	add	x2, x2, x2, lsl #2
    b028:	d37df042 	lsl	x2, x2, #3
    b02c:	8b020060 	add	x0, x3, x2
    b030:	f9401017 	ldr	x23, [x0, #32]
    b034:	b4000257 	cbz	x23, b07c <f0+0x124c>
    b038:	38626862 	ldrb	w2, [x3, x2]
    b03c:	7100085f 	cmp	w2, #0x2
    b040:	540094a0 	b.eq	c2d4 <f0+0x24a4>  // b.none
    b044:	7100045f 	cmp	w2, #0x1
    b048:	540001a1 	b.ne	b07c <f0+0x124c>  // b.any
    b04c:	29430002 	ldp	w2, w0, [x0, #24]
    b050:	92403c21 	and	x1, x1, #0xffff
    b054:	9b027c21 	mul	x1, x1, x2
    b058:	d360fc21 	lsr	x1, x1, #32
    b05c:	eb00003f 	cmp	x1, x0
    b060:	540000e2 	b.cs	b07c <f0+0x124c>  // b.hs, b.nlast
    b064:	8b0102f7 	add	x23, x23, x1
    b068:	394002e0 	ldrb	w0, [x23]
    b06c:	7103fc1f 	cmp	w0, #0xff
    b070:	54009c80 	b.eq	c400 <f0+0x25d0>  // b.none
    b074:	52800020 	mov	w0, #0x1                   	// #1
    b078:	390002e0 	strb	w0, [x23]
    b07c:	910ee3e1 	add	x1, sp, #0x3b8
    b080:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b084:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	f901dff7 	str	x23, [sp, #952]
    b090:	f901e3f5 	str	x21, [sp, #960]
    b094:	97ffe73c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b098:	97ffe9cf 	bl	57d4 <fwp_rc_fresh>
    b09c:	aa0003e2 	mov	x2, x0
    b0a0:	910f23e1 	add	x1, sp, #0x3c8
    b0a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0a8:	52800020 	mov	w0, #0x1                   	// #1
    b0ac:	f901e7f5 	str	x21, [sp, #968]
    b0b0:	f901ebe2 	str	x2, [sp, #976]
    b0b4:	97ffe734 	bl	4d84 <fwp_data.part.0.constprop.0>
    b0b8:	97ffe9c7 	bl	57d4 <fwp_rc_fresh>
    b0bc:	aa0003e2 	mov	x2, x0
    b0c0:	910f63e1 	add	x1, sp, #0x3d8
    b0c4:	52800020 	mov	w0, #0x1                   	// #1
    b0c8:	f901eff7 	str	x23, [sp, #984]
    b0cc:	f901f3e2 	str	x2, [sp, #992]
    b0d0:	97ffe72d 	bl	4d84 <fwp_data.part.0.constprop.0>
    b0d4:	97ffe9c0 	bl	57d4 <fwp_rc_fresh>
    b0d8:	aa0003e2 	mov	x2, x0
    b0dc:	910fa3e1 	add	x1, sp, #0x3e8
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	f901f7f5 	str	x21, [sp, #1000]
    b0e8:	f901fbe2 	str	x2, [sp, #1008]
    b0ec:	97ffe726 	bl	4d84 <fwp_data.part.0.constprop.0>
    b0f0:	91150283 	add	x3, x20, #0x540
    b0f4:	aa0003f7 	mov	x23, x0
    b0f8:	f949d861 	ldr	x1, [x3, #5040]
    b0fc:	f949ec60 	ldr	x0, [x3, #5080]
    b100:	cb0102e1 	sub	x1, x23, x1
    b104:	eb00403f 	cmp	x1, x0, lsl #16
    b108:	54000322 	b.cs	b16c <f0+0x133c>  // b.hs, b.nlast
    b10c:	d350fc22 	lsr	x2, x1, #16
    b110:	f949fc63 	ldr	x3, [x3, #5112]
    b114:	8b020842 	add	x2, x2, x2, lsl #2
    b118:	d37df042 	lsl	x2, x2, #3
    b11c:	8b020060 	add	x0, x3, x2
    b120:	f9401015 	ldr	x21, [x0, #32]
    b124:	b4000255 	cbz	x21, b16c <f0+0x133c>
    b128:	38626862 	ldrb	w2, [x3, x2]
    b12c:	7100085f 	cmp	w2, #0x2
    b130:	54008240 	b.eq	c178 <f0+0x2348>  // b.none
    b134:	7100045f 	cmp	w2, #0x1
    b138:	540001a1 	b.ne	b16c <f0+0x133c>  // b.any
    b13c:	29430002 	ldp	w2, w0, [x0, #24]
    b140:	92403c21 	and	x1, x1, #0xffff
    b144:	9b027c21 	mul	x1, x1, x2
    b148:	d360fc21 	lsr	x1, x1, #32
    b14c:	eb00003f 	cmp	x1, x0
    b150:	540000e2 	b.cs	b16c <f0+0x133c>  // b.hs, b.nlast
    b154:	8b0102b5 	add	x21, x21, x1
    b158:	394002a0 	ldrb	w0, [x21]
    b15c:	7103fc1f 	cmp	w0, #0xff
    b160:	54009560 	b.eq	c40c <f0+0x25dc>  // b.none
    b164:	52800020 	mov	w0, #0x1                   	// #1
    b168:	390002a0 	strb	w0, [x21]
    b16c:	910fe3e1 	add	x1, sp, #0x3f8
    b170:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b174:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b178:	52800020 	mov	w0, #0x1                   	// #1
    b17c:	f901fff5 	str	x21, [sp, #1016]
    b180:	f90203f7 	str	x23, [sp, #1024]
    b184:	97ffe700 	bl	4d84 <fwp_data.part.0.constprop.0>
    b188:	97ffe993 	bl	57d4 <fwp_rc_fresh>
    b18c:	aa0003e2 	mov	x2, x0
    b190:	911023e1 	add	x1, sp, #0x408
    b194:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b198:	52800020 	mov	w0, #0x1                   	// #1
    b19c:	f90207f7 	str	x23, [sp, #1032]
    b1a0:	f9020be2 	str	x2, [sp, #1040]
    b1a4:	97ffe6f8 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1a8:	97ffe98b 	bl	57d4 <fwp_rc_fresh>
    b1ac:	aa0003e2 	mov	x2, x0
    b1b0:	911063e1 	add	x1, sp, #0x418
    b1b4:	52800020 	mov	w0, #0x1                   	// #1
    b1b8:	f9020ff5 	str	x21, [sp, #1048]
    b1bc:	f90213e2 	str	x2, [sp, #1056]
    b1c0:	97ffe6f1 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1c4:	97ffe984 	bl	57d4 <fwp_rc_fresh>
    b1c8:	aa0003e2 	mov	x2, x0
    b1cc:	9110a3e1 	add	x1, sp, #0x428
    b1d0:	52800020 	mov	w0, #0x1                   	// #1
    b1d4:	f90217f7 	str	x23, [sp, #1064]
    b1d8:	f9021be2 	str	x2, [sp, #1072]
    b1dc:	97ffe6ea 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1e0:	97ffe97d 	bl	57d4 <fwp_rc_fresh>
    b1e4:	aa0003e2 	mov	x2, x0
    b1e8:	9110e3e1 	add	x1, sp, #0x438
    b1ec:	52800020 	mov	w0, #0x1                   	// #1
    b1f0:	f9021ff5 	str	x21, [sp, #1080]
    b1f4:	f90223e2 	str	x2, [sp, #1088]
    b1f8:	97ffe6e3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1fc:	97ffe976 	bl	57d4 <fwp_rc_fresh>
    b200:	aa0003e2 	mov	x2, x0
    b204:	911123e1 	add	x1, sp, #0x448
    b208:	52800020 	mov	w0, #0x1                   	// #1
    b20c:	f90227f7 	str	x23, [sp, #1096]
    b210:	f9022be2 	str	x2, [sp, #1104]
    b214:	97ffe6dc 	bl	4d84 <fwp_data.part.0.constprop.0>
    b218:	97ffe96f 	bl	57d4 <fwp_rc_fresh>
    b21c:	aa0003e2 	mov	x2, x0
    b220:	911163e1 	add	x1, sp, #0x458
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	f9022ff5 	str	x21, [sp, #1112]
    b22c:	f90233e2 	str	x2, [sp, #1120]
    b230:	97ffe6d5 	bl	4d84 <fwp_data.part.0.constprop.0>
    b234:	91150283 	add	x3, x20, #0x540
    b238:	aa0003f5 	mov	x21, x0
    b23c:	f949d861 	ldr	x1, [x3, #5040]
    b240:	f949ec60 	ldr	x0, [x3, #5080]
    b244:	cb0102a1 	sub	x1, x21, x1
    b248:	eb00403f 	cmp	x1, x0, lsl #16
    b24c:	54000322 	b.cs	b2b0 <f0+0x1480>  // b.hs, b.nlast
    b250:	d350fc22 	lsr	x2, x1, #16
    b254:	f949fc63 	ldr	x3, [x3, #5112]
    b258:	8b020842 	add	x2, x2, x2, lsl #2
    b25c:	d37df042 	lsl	x2, x2, #3
    b260:	8b020060 	add	x0, x3, x2
    b264:	f9401017 	ldr	x23, [x0, #32]
    b268:	b4000257 	cbz	x23, b2b0 <f0+0x1480>
    b26c:	38626862 	ldrb	w2, [x3, x2]
    b270:	7100085f 	cmp	w2, #0x2
    b274:	540077c0 	b.eq	c16c <f0+0x233c>  // b.none
    b278:	7100045f 	cmp	w2, #0x1
    b27c:	540001a1 	b.ne	b2b0 <f0+0x1480>  // b.any
    b280:	29430002 	ldp	w2, w0, [x0, #24]
    b284:	92403c21 	and	x1, x1, #0xffff
    b288:	9b027c21 	mul	x1, x1, x2
    b28c:	d360fc21 	lsr	x1, x1, #32
    b290:	eb00003f 	cmp	x1, x0
    b294:	540000e2 	b.cs	b2b0 <f0+0x1480>  // b.hs, b.nlast
    b298:	8b0102f7 	add	x23, x23, x1
    b29c:	394002e0 	ldrb	w0, [x23]
    b2a0:	7103fc1f 	cmp	w0, #0xff
    b2a4:	54008ba0 	b.eq	c418 <f0+0x25e8>  // b.none
    b2a8:	52800020 	mov	w0, #0x1                   	// #1
    b2ac:	390002e0 	strb	w0, [x23]
    b2b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2b4:	9111a3e1 	add	x1, sp, #0x468
    b2b8:	52800020 	mov	w0, #0x1                   	// #1
    b2bc:	f90237e2 	str	x2, [sp, #1128]
    b2c0:	f9023bf5 	str	x21, [sp, #1136]
    b2c4:	97ffe6b0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2c8:	91150283 	add	x3, x20, #0x540
    b2cc:	aa0003f5 	mov	x21, x0
    b2d0:	f949d861 	ldr	x1, [x3, #5040]
    b2d4:	f949ec60 	ldr	x0, [x3, #5080]
    b2d8:	cb0102a1 	sub	x1, x21, x1
    b2dc:	eb00403f 	cmp	x1, x0, lsl #16
    b2e0:	54000322 	b.cs	b344 <f0+0x1514>  // b.hs, b.nlast
    b2e4:	d350fc22 	lsr	x2, x1, #16
    b2e8:	f949fc63 	ldr	x3, [x3, #5112]
    b2ec:	8b020842 	add	x2, x2, x2, lsl #2
    b2f0:	d37df042 	lsl	x2, x2, #3
    b2f4:	8b020060 	add	x0, x3, x2
    b2f8:	f9401017 	ldr	x23, [x0, #32]
    b2fc:	b4000257 	cbz	x23, b344 <f0+0x1514>
    b300:	38626862 	ldrb	w2, [x3, x2]
    b304:	7100085f 	cmp	w2, #0x2
    b308:	54007440 	b.eq	c190 <f0+0x2360>  // b.none
    b30c:	7100045f 	cmp	w2, #0x1
    b310:	540001a1 	b.ne	b344 <f0+0x1514>  // b.any
    b314:	29430002 	ldp	w2, w0, [x0, #24]
    b318:	92403c21 	and	x1, x1, #0xffff
    b31c:	9b027c21 	mul	x1, x1, x2
    b320:	d360fc21 	lsr	x1, x1, #32
    b324:	eb00003f 	cmp	x1, x0
    b328:	540000e2 	b.cs	b344 <f0+0x1514>  // b.hs, b.nlast
    b32c:	8b0102f7 	add	x23, x23, x1
    b330:	394002e0 	ldrb	w0, [x23]
    b334:	7103fc1f 	cmp	w0, #0xff
    b338:	54008760 	b.eq	c424 <f0+0x25f4>  // b.none
    b33c:	52800020 	mov	w0, #0x1                   	// #1
    b340:	390002e0 	strb	w0, [x23]
    b344:	9111e3e1 	add	x1, sp, #0x478
    b348:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b34c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b350:	52800020 	mov	w0, #0x1                   	// #1
    b354:	f9023ff7 	str	x23, [sp, #1144]
    b358:	f90243f5 	str	x21, [sp, #1152]
    b35c:	97ffe68a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b360:	97ffe91d 	bl	57d4 <fwp_rc_fresh>
    b364:	aa0003e2 	mov	x2, x0
    b368:	911223e1 	add	x1, sp, #0x488
    b36c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b370:	52800020 	mov	w0, #0x1                   	// #1
    b374:	f90247f5 	str	x21, [sp, #1160]
    b378:	f9024be2 	str	x2, [sp, #1168]
    b37c:	97ffe682 	bl	4d84 <fwp_data.part.0.constprop.0>
    b380:	97ffe915 	bl	57d4 <fwp_rc_fresh>
    b384:	aa0003e2 	mov	x2, x0
    b388:	911263e1 	add	x1, sp, #0x498
    b38c:	52800020 	mov	w0, #0x1                   	// #1
    b390:	f9024ff7 	str	x23, [sp, #1176]
    b394:	f90253e2 	str	x2, [sp, #1184]
    b398:	97ffe67b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b39c:	97ffe90e 	bl	57d4 <fwp_rc_fresh>
    b3a0:	aa0003e2 	mov	x2, x0
    b3a4:	9112a3e1 	add	x1, sp, #0x4a8
    b3a8:	52800020 	mov	w0, #0x1                   	// #1
    b3ac:	f90257f5 	str	x21, [sp, #1192]
    b3b0:	f9025be2 	str	x2, [sp, #1200]
    b3b4:	97ffe674 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3b8:	91150283 	add	x3, x20, #0x540
    b3bc:	aa0003f5 	mov	x21, x0
    b3c0:	f949d861 	ldr	x1, [x3, #5040]
    b3c4:	f949ec60 	ldr	x0, [x3, #5080]
    b3c8:	cb0102a1 	sub	x1, x21, x1
    b3cc:	eb00403f 	cmp	x1, x0, lsl #16
    b3d0:	54000322 	b.cs	b434 <f0+0x1604>  // b.hs, b.nlast
    b3d4:	d350fc22 	lsr	x2, x1, #16
    b3d8:	f949fc63 	ldr	x3, [x3, #5112]
    b3dc:	8b020842 	add	x2, x2, x2, lsl #2
    b3e0:	d37df042 	lsl	x2, x2, #3
    b3e4:	8b020060 	add	x0, x3, x2
    b3e8:	f9401017 	ldr	x23, [x0, #32]
    b3ec:	b4000257 	cbz	x23, b434 <f0+0x1604>
    b3f0:	38626862 	ldrb	w2, [x3, x2]
    b3f4:	7100085f 	cmp	w2, #0x2
    b3f8:	54006c60 	b.eq	c184 <f0+0x2354>  // b.none
    b3fc:	7100045f 	cmp	w2, #0x1
    b400:	540001a1 	b.ne	b434 <f0+0x1604>  // b.any
    b404:	29430002 	ldp	w2, w0, [x0, #24]
    b408:	92403c21 	and	x1, x1, #0xffff
    b40c:	9b027c21 	mul	x1, x1, x2
    b410:	d360fc21 	lsr	x1, x1, #32
    b414:	eb00003f 	cmp	x1, x0
    b418:	540000e2 	b.cs	b434 <f0+0x1604>  // b.hs, b.nlast
    b41c:	8b0102f7 	add	x23, x23, x1
    b420:	394002e0 	ldrb	w0, [x23]
    b424:	7103fc1f 	cmp	w0, #0xff
    b428:	54008040 	b.eq	c430 <f0+0x2600>  // b.none
    b42c:	52800020 	mov	w0, #0x1                   	// #1
    b430:	390002e0 	strb	w0, [x23]
    b434:	9112e3e1 	add	x1, sp, #0x4b8
    b438:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b43c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b440:	52800020 	mov	w0, #0x1                   	// #1
    b444:	f9025ff7 	str	x23, [sp, #1208]
    b448:	f90263f5 	str	x21, [sp, #1216]
    b44c:	97ffe64e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b450:	97ffe8e1 	bl	57d4 <fwp_rc_fresh>
    b454:	aa0003e2 	mov	x2, x0
    b458:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b45c:	911323e1 	add	x1, sp, #0x4c8
    b460:	52800020 	mov	w0, #0x1                   	// #1
    b464:	f90267e3 	str	x3, [sp, #1224]
    b468:	f9026be2 	str	x2, [sp, #1232]
    b46c:	97ffe646 	bl	4d84 <fwp_data.part.0.constprop.0>
    b470:	97ffe8d9 	bl	57d4 <fwp_rc_fresh>
    b474:	aa0003e2 	mov	x2, x0
    b478:	911363e1 	add	x1, sp, #0x4d8
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	f9026ff7 	str	x23, [sp, #1240]
    b484:	f90273e2 	str	x2, [sp, #1248]
    b488:	97ffe63f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b48c:	91150283 	add	x3, x20, #0x540
    b490:	aa0003f5 	mov	x21, x0
    b494:	f949d861 	ldr	x1, [x3, #5040]
    b498:	f949ec60 	ldr	x0, [x3, #5080]
    b49c:	cb0102a1 	sub	x1, x21, x1
    b4a0:	eb00403f 	cmp	x1, x0, lsl #16
    b4a4:	54000322 	b.cs	b508 <f0+0x16d8>  // b.hs, b.nlast
    b4a8:	d350fc22 	lsr	x2, x1, #16
    b4ac:	f949fc63 	ldr	x3, [x3, #5112]
    b4b0:	8b020842 	add	x2, x2, x2, lsl #2
    b4b4:	d37df042 	lsl	x2, x2, #3
    b4b8:	8b020060 	add	x0, x3, x2
    b4bc:	f9401017 	ldr	x23, [x0, #32]
    b4c0:	b4000257 	cbz	x23, b508 <f0+0x16d8>
    b4c4:	38626862 	ldrb	w2, [x3, x2]
    b4c8:	7100085f 	cmp	w2, #0x2
    b4cc:	540066e0 	b.eq	c1a8 <f0+0x2378>  // b.none
    b4d0:	7100045f 	cmp	w2, #0x1
    b4d4:	540001a1 	b.ne	b508 <f0+0x16d8>  // b.any
    b4d8:	29430002 	ldp	w2, w0, [x0, #24]
    b4dc:	92403c21 	and	x1, x1, #0xffff
    b4e0:	9b027c21 	mul	x1, x1, x2
    b4e4:	d360fc21 	lsr	x1, x1, #32
    b4e8:	eb00003f 	cmp	x1, x0
    b4ec:	540000e2 	b.cs	b508 <f0+0x16d8>  // b.hs, b.nlast
    b4f0:	8b0102f7 	add	x23, x23, x1
    b4f4:	394002e0 	ldrb	w0, [x23]
    b4f8:	7103fc1f 	cmp	w0, #0xff
    b4fc:	54007a00 	b.eq	c43c <f0+0x260c>  // b.none
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	390002e0 	strb	w0, [x23]
    b508:	9113a3e1 	add	x1, sp, #0x4e8
    b50c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b510:	52800020 	mov	w0, #0x1                   	// #1
    b514:	f90277f7 	str	x23, [sp, #1256]
    b518:	f9027bf5 	str	x21, [sp, #1264]
    b51c:	97ffe61a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b520:	97ffe8ad 	bl	57d4 <fwp_rc_fresh>
    b524:	aa0003e2 	mov	x2, x0
    b528:	9113e3e1 	add	x1, sp, #0x4f8
    b52c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b530:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	f9027ff5 	str	x21, [sp, #1272]
    b53c:	f90283e2 	str	x2, [sp, #1280]
    b540:	97ffe611 	bl	4d84 <fwp_data.part.0.constprop.0>
    b544:	97ffe8a4 	bl	57d4 <fwp_rc_fresh>
    b548:	aa0003e2 	mov	x2, x0
    b54c:	911423e1 	add	x1, sp, #0x508
    b550:	52800020 	mov	w0, #0x1                   	// #1
    b554:	f90287f7 	str	x23, [sp, #1288]
    b558:	f9028be2 	str	x2, [sp, #1296]
    b55c:	97ffe60a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b560:	97ffe89d 	bl	57d4 <fwp_rc_fresh>
    b564:	aa0003e2 	mov	x2, x0
    b568:	911463e1 	add	x1, sp, #0x518
    b56c:	52800020 	mov	w0, #0x1                   	// #1
    b570:	f9028ff5 	str	x21, [sp, #1304]
    b574:	f90293e2 	str	x2, [sp, #1312]
    b578:	97ffe603 	bl	4d84 <fwp_data.part.0.constprop.0>
    b57c:	97ffe896 	bl	57d4 <fwp_rc_fresh>
    b580:	aa0003e2 	mov	x2, x0
    b584:	9114a3e1 	add	x1, sp, #0x528
    b588:	52800020 	mov	w0, #0x1                   	// #1
    b58c:	f90297f7 	str	x23, [sp, #1320]
    b590:	f9029be2 	str	x2, [sp, #1328]
    b594:	97ffe5fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    b598:	91150283 	add	x3, x20, #0x540
    b59c:	aa0003f5 	mov	x21, x0
    b5a0:	f949d861 	ldr	x1, [x3, #5040]
    b5a4:	f949ec60 	ldr	x0, [x3, #5080]
    b5a8:	cb0102a1 	sub	x1, x21, x1
    b5ac:	eb00403f 	cmp	x1, x0, lsl #16
    b5b0:	54000322 	b.cs	b614 <f0+0x17e4>  // b.hs, b.nlast
    b5b4:	d350fc22 	lsr	x2, x1, #16
    b5b8:	f949fc63 	ldr	x3, [x3, #5112]
    b5bc:	8b020842 	add	x2, x2, x2, lsl #2
    b5c0:	d37df042 	lsl	x2, x2, #3
    b5c4:	8b020060 	add	x0, x3, x2
    b5c8:	f9401017 	ldr	x23, [x0, #32]
    b5cc:	b4000257 	cbz	x23, b614 <f0+0x17e4>
    b5d0:	38626862 	ldrb	w2, [x3, x2]
    b5d4:	7100085f 	cmp	w2, #0x2
    b5d8:	54005e20 	b.eq	c19c <f0+0x236c>  // b.none
    b5dc:	7100045f 	cmp	w2, #0x1
    b5e0:	540001a1 	b.ne	b614 <f0+0x17e4>  // b.any
    b5e4:	29430002 	ldp	w2, w0, [x0, #24]
    b5e8:	92403c21 	and	x1, x1, #0xffff
    b5ec:	9b027c21 	mul	x1, x1, x2
    b5f0:	d360fc21 	lsr	x1, x1, #32
    b5f4:	eb00003f 	cmp	x1, x0
    b5f8:	540000e2 	b.cs	b614 <f0+0x17e4>  // b.hs, b.nlast
    b5fc:	8b0102f7 	add	x23, x23, x1
    b600:	394002e0 	ldrb	w0, [x23]
    b604:	7103fc1f 	cmp	w0, #0xff
    b608:	54007200 	b.eq	c448 <f0+0x2618>  // b.none
    b60c:	52800020 	mov	w0, #0x1                   	// #1
    b610:	390002e0 	strb	w0, [x23]
    b614:	9114e3e1 	add	x1, sp, #0x538
    b618:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b61c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b620:	52800020 	mov	w0, #0x1                   	// #1
    b624:	f9029ff7 	str	x23, [sp, #1336]
    b628:	f902a3f5 	str	x21, [sp, #1344]
    b62c:	97ffe5d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    b630:	97ffe869 	bl	57d4 <fwp_rc_fresh>
    b634:	aa0003e2 	mov	x2, x0
    b638:	911523e1 	add	x1, sp, #0x548
    b63c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b640:	52800020 	mov	w0, #0x1                   	// #1
    b644:	f902a7f5 	str	x21, [sp, #1352]
    b648:	f902abe2 	str	x2, [sp, #1360]
    b64c:	97ffe5ce 	bl	4d84 <fwp_data.part.0.constprop.0>
    b650:	97ffe861 	bl	57d4 <fwp_rc_fresh>
    b654:	aa0003e2 	mov	x2, x0
    b658:	911563e1 	add	x1, sp, #0x558
    b65c:	52800020 	mov	w0, #0x1                   	// #1
    b660:	f902aff7 	str	x23, [sp, #1368]
    b664:	f902b3e2 	str	x2, [sp, #1376]
    b668:	97ffe5c7 	bl	4d84 <fwp_data.part.0.constprop.0>
    b66c:	97ffe85a 	bl	57d4 <fwp_rc_fresh>
    b670:	aa0003e2 	mov	x2, x0
    b674:	9115a3e1 	add	x1, sp, #0x568
    b678:	52800020 	mov	w0, #0x1                   	// #1
    b67c:	f902b7f5 	str	x21, [sp, #1384]
    b680:	f902bbe2 	str	x2, [sp, #1392]
    b684:	97ffe5c0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b688:	97ffe853 	bl	57d4 <fwp_rc_fresh>
    b68c:	aa0003e2 	mov	x2, x0
    b690:	9115e3e1 	add	x1, sp, #0x578
    b694:	52800020 	mov	w0, #0x1                   	// #1
    b698:	f902bff7 	str	x23, [sp, #1400]
    b69c:	f902c3e2 	str	x2, [sp, #1408]
    b6a0:	97ffe5b9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6a4:	97ffe84c 	bl	57d4 <fwp_rc_fresh>
    b6a8:	aa0003e2 	mov	x2, x0
    b6ac:	911623e1 	add	x1, sp, #0x588
    b6b0:	52800020 	mov	w0, #0x1                   	// #1
    b6b4:	f902c7f5 	str	x21, [sp, #1416]
    b6b8:	f902cbe2 	str	x2, [sp, #1424]
    b6bc:	97ffe5b2 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6c0:	97ffe845 	bl	57d4 <fwp_rc_fresh>
    b6c4:	aa0003e2 	mov	x2, x0
    b6c8:	911663e1 	add	x1, sp, #0x598
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	f902cff7 	str	x23, [sp, #1432]
    b6d4:	f902d3e2 	str	x2, [sp, #1440]
    b6d8:	97ffe5ab 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6dc:	97ffe83e 	bl	57d4 <fwp_rc_fresh>
    b6e0:	aa0003e2 	mov	x2, x0
    b6e4:	9116a3e1 	add	x1, sp, #0x5a8
    b6e8:	52800020 	mov	w0, #0x1                   	// #1
    b6ec:	f902d7f5 	str	x21, [sp, #1448]
    b6f0:	f902dbe2 	str	x2, [sp, #1456]
    b6f4:	97ffe5a4 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6f8:	91150283 	add	x3, x20, #0x540
    b6fc:	aa0003f5 	mov	x21, x0
    b700:	f949d861 	ldr	x1, [x3, #5040]
    b704:	f949ec60 	ldr	x0, [x3, #5080]
    b708:	cb0102a1 	sub	x1, x21, x1
    b70c:	eb00403f 	cmp	x1, x0, lsl #16
    b710:	54000322 	b.cs	b774 <f0+0x1944>  // b.hs, b.nlast
    b714:	d350fc22 	lsr	x2, x1, #16
    b718:	f949fc63 	ldr	x3, [x3, #5112]
    b71c:	8b020842 	add	x2, x2, x2, lsl #2
    b720:	d37df042 	lsl	x2, x2, #3
    b724:	8b020060 	add	x0, x3, x2
    b728:	f9401017 	ldr	x23, [x0, #32]
    b72c:	b4000257 	cbz	x23, b774 <f0+0x1944>
    b730:	38626862 	ldrb	w2, [x3, x2]
    b734:	7100085f 	cmp	w2, #0x2
    b738:	54005440 	b.eq	c1c0 <f0+0x2390>  // b.none
    b73c:	7100045f 	cmp	w2, #0x1
    b740:	540001a1 	b.ne	b774 <f0+0x1944>  // b.any
    b744:	29430002 	ldp	w2, w0, [x0, #24]
    b748:	92403c21 	and	x1, x1, #0xffff
    b74c:	9b027c21 	mul	x1, x1, x2
    b750:	d360fc21 	lsr	x1, x1, #32
    b754:	eb00003f 	cmp	x1, x0
    b758:	540000e2 	b.cs	b774 <f0+0x1944>  // b.hs, b.nlast
    b75c:	8b0102f7 	add	x23, x23, x1
    b760:	394002e0 	ldrb	w0, [x23]
    b764:	7103fc1f 	cmp	w0, #0xff
    b768:	54006760 	b.eq	c454 <f0+0x2624>  // b.none
    b76c:	52800020 	mov	w0, #0x1                   	// #1
    b770:	390002e0 	strb	w0, [x23]
    b774:	9116e3e1 	add	x1, sp, #0x5b8
    b778:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b77c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b780:	52800020 	mov	w0, #0x1                   	// #1
    b784:	f902dff7 	str	x23, [sp, #1464]
    b788:	f902e3f5 	str	x21, [sp, #1472]
    b78c:	97ffe57e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b790:	97ffe811 	bl	57d4 <fwp_rc_fresh>
    b794:	aa0003e2 	mov	x2, x0
    b798:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b79c:	911723e1 	add	x1, sp, #0x5c8
    b7a0:	52800020 	mov	w0, #0x1                   	// #1
    b7a4:	f902e7e3 	str	x3, [sp, #1480]
    b7a8:	f902ebe2 	str	x2, [sp, #1488]
    b7ac:	97ffe576 	bl	4d84 <fwp_data.part.0.constprop.0>
    b7b0:	97ffe809 	bl	57d4 <fwp_rc_fresh>
    b7b4:	aa0003e2 	mov	x2, x0
    b7b8:	911763e1 	add	x1, sp, #0x5d8
    b7bc:	52800020 	mov	w0, #0x1                   	// #1
    b7c0:	f902eff7 	str	x23, [sp, #1496]
    b7c4:	f902f3e2 	str	x2, [sp, #1504]
    b7c8:	97ffe56f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b7cc:	91150283 	add	x3, x20, #0x540
    b7d0:	aa0003f5 	mov	x21, x0
    b7d4:	f949d861 	ldr	x1, [x3, #5040]
    b7d8:	f949ec60 	ldr	x0, [x3, #5080]
    b7dc:	cb0102a1 	sub	x1, x21, x1
    b7e0:	eb00403f 	cmp	x1, x0, lsl #16
    b7e4:	54000322 	b.cs	b848 <f0+0x1a18>  // b.hs, b.nlast
    b7e8:	d350fc22 	lsr	x2, x1, #16
    b7ec:	f949fc63 	ldr	x3, [x3, #5112]
    b7f0:	8b020842 	add	x2, x2, x2, lsl #2
    b7f4:	d37df042 	lsl	x2, x2, #3
    b7f8:	8b020060 	add	x0, x3, x2
    b7fc:	f9401017 	ldr	x23, [x0, #32]
    b800:	b4000257 	cbz	x23, b848 <f0+0x1a18>
    b804:	38626862 	ldrb	w2, [x3, x2]
    b808:	7100085f 	cmp	w2, #0x2
    b80c:	54004d40 	b.eq	c1b4 <f0+0x2384>  // b.none
    b810:	7100045f 	cmp	w2, #0x1
    b814:	540001a1 	b.ne	b848 <f0+0x1a18>  // b.any
    b818:	29430002 	ldp	w2, w0, [x0, #24]
    b81c:	92403c21 	and	x1, x1, #0xffff
    b820:	9b027c21 	mul	x1, x1, x2
    b824:	d360fc21 	lsr	x1, x1, #32
    b828:	eb00003f 	cmp	x1, x0
    b82c:	540000e2 	b.cs	b848 <f0+0x1a18>  // b.hs, b.nlast
    b830:	8b0102f7 	add	x23, x23, x1
    b834:	394002e0 	ldrb	w0, [x23]
    b838:	7103fc1f 	cmp	w0, #0xff
    b83c:	54006120 	b.eq	c460 <f0+0x2630>  // b.none
    b840:	52800020 	mov	w0, #0x1                   	// #1
    b844:	390002e0 	strb	w0, [x23]
    b848:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b84c:	9117a3e1 	add	x1, sp, #0x5e8
    b850:	52800020 	mov	w0, #0x1                   	// #1
    b854:	f902f7e2 	str	x2, [sp, #1512]
    b858:	f902fbf5 	str	x21, [sp, #1520]
    b85c:	97ffe54a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b860:	91150283 	add	x3, x20, #0x540
    b864:	aa0003f7 	mov	x23, x0
    b868:	f949d861 	ldr	x1, [x3, #5040]
    b86c:	f949ec60 	ldr	x0, [x3, #5080]
    b870:	cb0102e1 	sub	x1, x23, x1
    b874:	eb00403f 	cmp	x1, x0, lsl #16
    b878:	54000322 	b.cs	b8dc <f0+0x1aac>  // b.hs, b.nlast
    b87c:	d350fc22 	lsr	x2, x1, #16
    b880:	f949fc63 	ldr	x3, [x3, #5112]
    b884:	8b020842 	add	x2, x2, x2, lsl #2
    b888:	d37df042 	lsl	x2, x2, #3
    b88c:	8b020060 	add	x0, x3, x2
    b890:	f9401015 	ldr	x21, [x0, #32]
    b894:	b4000255 	cbz	x21, b8dc <f0+0x1aac>
    b898:	38626862 	ldrb	w2, [x3, x2]
    b89c:	7100085f 	cmp	w2, #0x2
    b8a0:	540049c0 	b.eq	c1d8 <f0+0x23a8>  // b.none
    b8a4:	7100045f 	cmp	w2, #0x1
    b8a8:	540001a1 	b.ne	b8dc <f0+0x1aac>  // b.any
    b8ac:	29430002 	ldp	w2, w0, [x0, #24]
    b8b0:	92403c21 	and	x1, x1, #0xffff
    b8b4:	9b027c21 	mul	x1, x1, x2
    b8b8:	d360fc21 	lsr	x1, x1, #32
    b8bc:	eb00003f 	cmp	x1, x0
    b8c0:	540000e2 	b.cs	b8dc <f0+0x1aac>  // b.hs, b.nlast
    b8c4:	8b0102b5 	add	x21, x21, x1
    b8c8:	394002a0 	ldrb	w0, [x21]
    b8cc:	7103fc1f 	cmp	w0, #0xff
    b8d0:	54005ce0 	b.eq	c46c <f0+0x263c>  // b.none
    b8d4:	52800020 	mov	w0, #0x1                   	// #1
    b8d8:	390002a0 	strb	w0, [x21]
    b8dc:	9117e3e1 	add	x1, sp, #0x5f8
    b8e0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b8e4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f902fff5 	str	x21, [sp, #1528]
    b8f0:	f90303f7 	str	x23, [sp, #1536]
    b8f4:	97ffe524 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe7b7 	bl	57d4 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	911823e1 	add	x1, sp, #0x608
    b904:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b908:	52800020 	mov	w0, #0x1                   	// #1
    b90c:	f90307f7 	str	x23, [sp, #1544]
    b910:	f9030be2 	str	x2, [sp, #1552]
    b914:	97ffe51c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b918:	97ffe7af 	bl	57d4 <fwp_rc_fresh>
    b91c:	aa0003e2 	mov	x2, x0
    b920:	911863e1 	add	x1, sp, #0x618
    b924:	52800020 	mov	w0, #0x1                   	// #1
    b928:	f9030ff5 	str	x21, [sp, #1560]
    b92c:	f90313e2 	str	x2, [sp, #1568]
    b930:	97ffe515 	bl	4d84 <fwp_data.part.0.constprop.0>
    b934:	97ffe7a8 	bl	57d4 <fwp_rc_fresh>
    b938:	aa0003e2 	mov	x2, x0
    b93c:	9118a3e1 	add	x1, sp, #0x628
    b940:	52800020 	mov	w0, #0x1                   	// #1
    b944:	f90317f7 	str	x23, [sp, #1576]
    b948:	f9031be2 	str	x2, [sp, #1584]
    b94c:	97ffe50e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b950:	97ffe7a1 	bl	57d4 <fwp_rc_fresh>
    b954:	aa0003e2 	mov	x2, x0
    b958:	9118e3e1 	add	x1, sp, #0x638
    b95c:	52800020 	mov	w0, #0x1                   	// #1
    b960:	f9031ff5 	str	x21, [sp, #1592]
    b964:	f90323e2 	str	x2, [sp, #1600]
    b968:	97ffe507 	bl	4d84 <fwp_data.part.0.constprop.0>
    b96c:	97ffe79a 	bl	57d4 <fwp_rc_fresh>
    b970:	aa0003e2 	mov	x2, x0
    b974:	911923e1 	add	x1, sp, #0x648
    b978:	52800020 	mov	w0, #0x1                   	// #1
    b97c:	f90327f7 	str	x23, [sp, #1608]
    b980:	f9032be2 	str	x2, [sp, #1616]
    b984:	97ffe500 	bl	4d84 <fwp_data.part.0.constprop.0>
    b988:	97ffe793 	bl	57d4 <fwp_rc_fresh>
    b98c:	aa0003e2 	mov	x2, x0
    b990:	911963e1 	add	x1, sp, #0x658
    b994:	52800020 	mov	w0, #0x1                   	// #1
    b998:	f9032ff5 	str	x21, [sp, #1624]
    b99c:	f90333e2 	str	x2, [sp, #1632]
    b9a0:	97ffe4f9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9a4:	91150283 	add	x3, x20, #0x540
    b9a8:	aa0003f5 	mov	x21, x0
    b9ac:	f949d861 	ldr	x1, [x3, #5040]
    b9b0:	f949ec60 	ldr	x0, [x3, #5080]
    b9b4:	cb0102a1 	sub	x1, x21, x1
    b9b8:	eb00403f 	cmp	x1, x0, lsl #16
    b9bc:	54000322 	b.cs	ba20 <f0+0x1bf0>  // b.hs, b.nlast
    b9c0:	d350fc22 	lsr	x2, x1, #16
    b9c4:	f949fc63 	ldr	x3, [x3, #5112]
    b9c8:	8b020842 	add	x2, x2, x2, lsl #2
    b9cc:	d37df042 	lsl	x2, x2, #3
    b9d0:	8b020060 	add	x0, x3, x2
    b9d4:	f9401017 	ldr	x23, [x0, #32]
    b9d8:	b4000257 	cbz	x23, ba20 <f0+0x1bf0>
    b9dc:	38626862 	ldrb	w2, [x3, x2]
    b9e0:	7100085f 	cmp	w2, #0x2
    b9e4:	54003f40 	b.eq	c1cc <f0+0x239c>  // b.none
    b9e8:	7100045f 	cmp	w2, #0x1
    b9ec:	540001a1 	b.ne	ba20 <f0+0x1bf0>  // b.any
    b9f0:	29430002 	ldp	w2, w0, [x0, #24]
    b9f4:	92403c21 	and	x1, x1, #0xffff
    b9f8:	9b027c21 	mul	x1, x1, x2
    b9fc:	d360fc21 	lsr	x1, x1, #32
    ba00:	eb00003f 	cmp	x1, x0
    ba04:	540000e2 	b.cs	ba20 <f0+0x1bf0>  // b.hs, b.nlast
    ba08:	8b0102f7 	add	x23, x23, x1
    ba0c:	394002e0 	ldrb	w0, [x23]
    ba10:	7103fc1f 	cmp	w0, #0xff
    ba14:	54005320 	b.eq	c478 <f0+0x2648>  // b.none
    ba18:	52800020 	mov	w0, #0x1                   	// #1
    ba1c:	390002e0 	strb	w0, [x23]
    ba20:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba24:	9119a3e1 	add	x1, sp, #0x668
    ba28:	52800020 	mov	w0, #0x1                   	// #1
    ba2c:	f90337e2 	str	x2, [sp, #1640]
    ba30:	f9033bf5 	str	x21, [sp, #1648]
    ba34:	97ffe4d4 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba38:	91150283 	add	x3, x20, #0x540
    ba3c:	aa0003f5 	mov	x21, x0
    ba40:	f949d861 	ldr	x1, [x3, #5040]
    ba44:	f949ec60 	ldr	x0, [x3, #5080]
    ba48:	cb0102a1 	sub	x1, x21, x1
    ba4c:	eb00403f 	cmp	x1, x0, lsl #16
    ba50:	54000322 	b.cs	bab4 <f0+0x1c84>  // b.hs, b.nlast
    ba54:	d350fc22 	lsr	x2, x1, #16
    ba58:	f949fc63 	ldr	x3, [x3, #5112]
    ba5c:	8b020842 	add	x2, x2, x2, lsl #2
    ba60:	d37df042 	lsl	x2, x2, #3
    ba64:	8b020060 	add	x0, x3, x2
    ba68:	f9401017 	ldr	x23, [x0, #32]
    ba6c:	b4000257 	cbz	x23, bab4 <f0+0x1c84>
    ba70:	38626862 	ldrb	w2, [x3, x2]
    ba74:	7100085f 	cmp	w2, #0x2
    ba78:	54003bc0 	b.eq	c1f0 <f0+0x23c0>  // b.none
    ba7c:	7100045f 	cmp	w2, #0x1
    ba80:	540001a1 	b.ne	bab4 <f0+0x1c84>  // b.any
    ba84:	29430002 	ldp	w2, w0, [x0, #24]
    ba88:	92403c21 	and	x1, x1, #0xffff
    ba8c:	9b027c21 	mul	x1, x1, x2
    ba90:	d360fc21 	lsr	x1, x1, #32
    ba94:	eb00003f 	cmp	x1, x0
    ba98:	540000e2 	b.cs	bab4 <f0+0x1c84>  // b.hs, b.nlast
    ba9c:	8b0102f7 	add	x23, x23, x1
    baa0:	394002e0 	ldrb	w0, [x23]
    baa4:	7103fc1f 	cmp	w0, #0xff
    baa8:	54004ee0 	b.eq	c484 <f0+0x2654>  // b.none
    baac:	52800020 	mov	w0, #0x1                   	// #1
    bab0:	390002e0 	strb	w0, [x23]
    bab4:	9119e3e1 	add	x1, sp, #0x678
    bab8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    babc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bac0:	52800020 	mov	w0, #0x1                   	// #1
    bac4:	f9033ff7 	str	x23, [sp, #1656]
    bac8:	f90343f5 	str	x21, [sp, #1664]
    bacc:	97ffe4ae 	bl	4d84 <fwp_data.part.0.constprop.0>
    bad0:	97ffe741 	bl	57d4 <fwp_rc_fresh>
    bad4:	aa0003e2 	mov	x2, x0
    bad8:	911a23e1 	add	x1, sp, #0x688
    badc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bae0:	52800020 	mov	w0, #0x1                   	// #1
    bae4:	f90347f5 	str	x21, [sp, #1672]
    bae8:	f9034be2 	str	x2, [sp, #1680]
    baec:	97ffe4a6 	bl	4d84 <fwp_data.part.0.constprop.0>
    baf0:	97ffe739 	bl	57d4 <fwp_rc_fresh>
    baf4:	aa0003e2 	mov	x2, x0
    baf8:	911a63e1 	add	x1, sp, #0x698
    bafc:	52800020 	mov	w0, #0x1                   	// #1
    bb00:	f9034ff7 	str	x23, [sp, #1688]
    bb04:	f90353e2 	str	x2, [sp, #1696]
    bb08:	97ffe49f 	bl	4d84 <fwp_data.part.0.constprop.0>
    bb0c:	97ffe732 	bl	57d4 <fwp_rc_fresh>
    bb10:	aa0003e2 	mov	x2, x0
    bb14:	911aa3e1 	add	x1, sp, #0x6a8
    bb18:	52800020 	mov	w0, #0x1                   	// #1
    bb1c:	f90357f5 	str	x21, [sp, #1704]
    bb20:	f9035be2 	str	x2, [sp, #1712]
    bb24:	97ffe498 	bl	4d84 <fwp_data.part.0.constprop.0>
    bb28:	91150283 	add	x3, x20, #0x540
    bb2c:	aa0003f5 	mov	x21, x0
    bb30:	f949d861 	ldr	x1, [x3, #5040]
    bb34:	f949ec60 	ldr	x0, [x3, #5080]
    bb38:	cb0102a1 	sub	x1, x21, x1
    bb3c:	eb00403f 	cmp	x1, x0, lsl #16
    bb40:	54000322 	b.cs	bba4 <f0+0x1d74>  // b.hs, b.nlast
    bb44:	d350fc22 	lsr	x2, x1, #16
    bb48:	f949fc63 	ldr	x3, [x3, #5112]
    bb4c:	8b020842 	add	x2, x2, x2, lsl #2
    bb50:	d37df042 	lsl	x2, x2, #3
    bb54:	8b020060 	add	x0, x3, x2
    bb58:	f9401017 	ldr	x23, [x0, #32]
    bb5c:	b4000257 	cbz	x23, bba4 <f0+0x1d74>
    bb60:	38626862 	ldrb	w2, [x3, x2]
    bb64:	7100085f 	cmp	w2, #0x2
    bb68:	540033e0 	b.eq	c1e4 <f0+0x23b4>  // b.none
    bb6c:	7100045f 	cmp	w2, #0x1
    bb70:	540001a1 	b.ne	bba4 <f0+0x1d74>  // b.any
    bb74:	29430002 	ldp	w2, w0, [x0, #24]
    bb78:	92403c21 	and	x1, x1, #0xffff
    bb7c:	9b027c21 	mul	x1, x1, x2
    bb80:	d360fc21 	lsr	x1, x1, #32
    bb84:	eb00003f 	cmp	x1, x0
    bb88:	540000e2 	b.cs	bba4 <f0+0x1d74>  // b.hs, b.nlast
    bb8c:	8b0102f7 	add	x23, x23, x1
    bb90:	394002e0 	ldrb	w0, [x23]
    bb94:	7103fc1f 	cmp	w0, #0xff
    bb98:	540047c0 	b.eq	c490 <f0+0x2660>  // b.none
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	390002e0 	strb	w0, [x23]
    bba4:	911ae3e1 	add	x1, sp, #0x6b8
    bba8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bbac:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bbb0:	52800020 	mov	w0, #0x1                   	// #1
    bbb4:	f9035ff7 	str	x23, [sp, #1720]
    bbb8:	f90363f5 	str	x21, [sp, #1728]
    bbbc:	97ffe472 	bl	4d84 <fwp_data.part.0.constprop.0>
    bbc0:	97ffe705 	bl	57d4 <fwp_rc_fresh>
    bbc4:	aa0003e2 	mov	x2, x0
    bbc8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bbcc:	911b23e1 	add	x1, sp, #0x6c8
    bbd0:	52800020 	mov	w0, #0x1                   	// #1
    bbd4:	f90367e3 	str	x3, [sp, #1736]
    bbd8:	f9036be2 	str	x2, [sp, #1744]
    bbdc:	97ffe46a 	bl	4d84 <fwp_data.part.0.constprop.0>
    bbe0:	97ffe6fd 	bl	57d4 <fwp_rc_fresh>
    bbe4:	aa0003e2 	mov	x2, x0
    bbe8:	911b63e1 	add	x1, sp, #0x6d8
    bbec:	52800020 	mov	w0, #0x1                   	// #1
    bbf0:	f9036ff7 	str	x23, [sp, #1752]
    bbf4:	f90373e2 	str	x2, [sp, #1760]
    bbf8:	97ffe463 	bl	4d84 <fwp_data.part.0.constprop.0>
    bbfc:	91150283 	add	x3, x20, #0x540
    bc00:	aa0003f5 	mov	x21, x0
    bc04:	f949d861 	ldr	x1, [x3, #5040]
    bc08:	f949ec60 	ldr	x0, [x3, #5080]
    bc0c:	cb0102a1 	sub	x1, x21, x1
    bc10:	eb00403f 	cmp	x1, x0, lsl #16
    bc14:	54000322 	b.cs	bc78 <f0+0x1e48>  // b.hs, b.nlast
    bc18:	d350fc22 	lsr	x2, x1, #16
    bc1c:	f949fc63 	ldr	x3, [x3, #5112]
    bc20:	8b020842 	add	x2, x2, x2, lsl #2
    bc24:	d37df042 	lsl	x2, x2, #3
    bc28:	8b020060 	add	x0, x3, x2
    bc2c:	f9401017 	ldr	x23, [x0, #32]
    bc30:	b4000257 	cbz	x23, bc78 <f0+0x1e48>
    bc34:	38626862 	ldrb	w2, [x3, x2]
    bc38:	7100085f 	cmp	w2, #0x2
    bc3c:	54002e60 	b.eq	c208 <f0+0x23d8>  // b.none
    bc40:	7100045f 	cmp	w2, #0x1
    bc44:	540001a1 	b.ne	bc78 <f0+0x1e48>  // b.any
    bc48:	29430002 	ldp	w2, w0, [x0, #24]
    bc4c:	92403c21 	and	x1, x1, #0xffff
    bc50:	9b027c21 	mul	x1, x1, x2
    bc54:	d360fc21 	lsr	x1, x1, #32
    bc58:	eb00003f 	cmp	x1, x0
    bc5c:	540000e2 	b.cs	bc78 <f0+0x1e48>  // b.hs, b.nlast
    bc60:	8b0102f7 	add	x23, x23, x1
    bc64:	394002e0 	ldrb	w0, [x23]
    bc68:	7103fc1f 	cmp	w0, #0xff
    bc6c:	54004180 	b.eq	c49c <f0+0x266c>  // b.none
    bc70:	52800020 	mov	w0, #0x1                   	// #1
    bc74:	390002e0 	strb	w0, [x23]
    bc78:	911ba3e1 	add	x1, sp, #0x6e8
    bc7c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc80:	52800020 	mov	w0, #0x1                   	// #1
    bc84:	f90377e2 	str	x2, [sp, #1768]
    bc88:	f9037bf5 	str	x21, [sp, #1776]
    bc8c:	97ffe43e 	bl	4d84 <fwp_data.part.0.constprop.0>
    bc90:	97ffe6d1 	bl	57d4 <fwp_rc_fresh>
    bc94:	aa0003e2 	mov	x2, x0
    bc98:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bc9c:	911be3e1 	add	x1, sp, #0x6f8
    bca0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bca4:	52800020 	mov	w0, #0x1                   	// #1
    bca8:	f9037fe3 	str	x3, [sp, #1784]
    bcac:	f90383e2 	str	x2, [sp, #1792]
    bcb0:	97ffe435 	bl	4d84 <fwp_data.part.0.constprop.0>
    bcb4:	91150283 	add	x3, x20, #0x540
    bcb8:	aa0003f5 	mov	x21, x0
    bcbc:	f949d861 	ldr	x1, [x3, #5040]
    bcc0:	f949ec60 	ldr	x0, [x3, #5080]
    bcc4:	cb0102a1 	sub	x1, x21, x1
    bcc8:	eb00403f 	cmp	x1, x0, lsl #16
    bccc:	54000322 	b.cs	bd30 <f0+0x1f00>  // b.hs, b.nlast
    bcd0:	d350fc22 	lsr	x2, x1, #16
    bcd4:	f949fc63 	ldr	x3, [x3, #5112]
    bcd8:	8b020842 	add	x2, x2, x2, lsl #2
    bcdc:	d37df042 	lsl	x2, x2, #3
    bce0:	8b020060 	add	x0, x3, x2
    bce4:	f9401017 	ldr	x23, [x0, #32]
    bce8:	b4000257 	cbz	x23, bd30 <f0+0x1f00>
    bcec:	38626862 	ldrb	w2, [x3, x2]
    bcf0:	7100085f 	cmp	w2, #0x2
    bcf4:	54002840 	b.eq	c1fc <f0+0x23cc>  // b.none
    bcf8:	7100045f 	cmp	w2, #0x1
    bcfc:	540001a1 	b.ne	bd30 <f0+0x1f00>  // b.any
    bd00:	29430002 	ldp	w2, w0, [x0, #24]
    bd04:	92403c21 	and	x1, x1, #0xffff
    bd08:	9b027c21 	mul	x1, x1, x2
    bd0c:	d360fc21 	lsr	x1, x1, #32
    bd10:	eb00003f 	cmp	x1, x0
    bd14:	540000e2 	b.cs	bd30 <f0+0x1f00>  // b.hs, b.nlast
    bd18:	8b0102f7 	add	x23, x23, x1
    bd1c:	394002e0 	ldrb	w0, [x23]
    bd20:	7103fc1f 	cmp	w0, #0xff
    bd24:	54003c20 	b.eq	c4a8 <f0+0x2678>  // b.none
    bd28:	52800020 	mov	w0, #0x1                   	// #1
    bd2c:	390002e0 	strb	w0, [x23]
    bd30:	911c23e1 	add	x1, sp, #0x708
    bd34:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd38:	52800020 	mov	w0, #0x1                   	// #1
    bd3c:	f90387f7 	str	x23, [sp, #1800]
    bd40:	f9038bf5 	str	x21, [sp, #1808]
    bd44:	97ffe410 	bl	4d84 <fwp_data.part.0.constprop.0>
    bd48:	97ffe6a3 	bl	57d4 <fwp_rc_fresh>
    bd4c:	aa0003e2 	mov	x2, x0
    bd50:	911c63e1 	add	x1, sp, #0x718
    bd54:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bd58:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bd5c:	52800020 	mov	w0, #0x1                   	// #1
    bd60:	f9038ff5 	str	x21, [sp, #1816]
    bd64:	f90393e2 	str	x2, [sp, #1824]
    bd68:	97ffe407 	bl	4d84 <fwp_data.part.0.constprop.0>
    bd6c:	97ffe69a 	bl	57d4 <fwp_rc_fresh>
    bd70:	aa0003e2 	mov	x2, x0
    bd74:	911ca3e1 	add	x1, sp, #0x728
    bd78:	52800020 	mov	w0, #0x1                   	// #1
    bd7c:	f90397f7 	str	x23, [sp, #1832]
    bd80:	f9039be2 	str	x2, [sp, #1840]
    bd84:	97ffe400 	bl	4d84 <fwp_data.part.0.constprop.0>
    bd88:	97ffe693 	bl	57d4 <fwp_rc_fresh>
    bd8c:	aa0003e2 	mov	x2, x0
    bd90:	911ce3e1 	add	x1, sp, #0x738
    bd94:	52800020 	mov	w0, #0x1                   	// #1
    bd98:	f9039ff5 	str	x21, [sp, #1848]
    bd9c:	f903a3e2 	str	x2, [sp, #1856]
    bda0:	97ffe3f9 	bl	4d84 <fwp_data.part.0.constprop.0>
    bda4:	97ffe68c 	bl	57d4 <fwp_rc_fresh>
    bda8:	aa0003e2 	mov	x2, x0
    bdac:	911d23e1 	add	x1, sp, #0x748
    bdb0:	52800020 	mov	w0, #0x1                   	// #1
    bdb4:	f903a7f7 	str	x23, [sp, #1864]
    bdb8:	f903abe2 	str	x2, [sp, #1872]
    bdbc:	97ffe3f2 	bl	4d84 <fwp_data.part.0.constprop.0>
    bdc0:	97ffe685 	bl	57d4 <fwp_rc_fresh>
    bdc4:	aa0003e2 	mov	x2, x0
    bdc8:	911d63e1 	add	x1, sp, #0x758
    bdcc:	52800020 	mov	w0, #0x1                   	// #1
    bdd0:	f903aff5 	str	x21, [sp, #1880]
    bdd4:	f903b3e2 	str	x2, [sp, #1888]
    bdd8:	97ffe3eb 	bl	4d84 <fwp_data.part.0.constprop.0>
    bddc:	97ffe67e 	bl	57d4 <fwp_rc_fresh>
    bde0:	aa0003e2 	mov	x2, x0
    bde4:	911da3e1 	add	x1, sp, #0x768
    bde8:	52800020 	mov	w0, #0x1                   	// #1
    bdec:	f903b7f7 	str	x23, [sp, #1896]
    bdf0:	f903bbe2 	str	x2, [sp, #1904]
    bdf4:	97ffe3e4 	bl	4d84 <fwp_data.part.0.constprop.0>
    bdf8:	97ffe677 	bl	57d4 <fwp_rc_fresh>
    bdfc:	aa0003e2 	mov	x2, x0
    be00:	911de3e1 	add	x1, sp, #0x778
    be04:	52800020 	mov	w0, #0x1                   	// #1
    be08:	f903bff5 	str	x21, [sp, #1912]
    be0c:	f903c3e2 	str	x2, [sp, #1920]
    be10:	97ffe3dd 	bl	4d84 <fwp_data.part.0.constprop.0>
    be14:	97ffe670 	bl	57d4 <fwp_rc_fresh>
    be18:	aa0003e2 	mov	x2, x0
    be1c:	911e23e1 	add	x1, sp, #0x788
    be20:	52800020 	mov	w0, #0x1                   	// #1
    be24:	f903c7f7 	str	x23, [sp, #1928]
    be28:	f903cbe2 	str	x2, [sp, #1936]
    be2c:	97ffe3d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    be30:	97ffe669 	bl	57d4 <fwp_rc_fresh>
    be34:	aa0003e2 	mov	x2, x0
    be38:	911e63e1 	add	x1, sp, #0x798
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	f903cff5 	str	x21, [sp, #1944]
    be44:	f903d3e2 	str	x2, [sp, #1952]
    be48:	97ffe3cf 	bl	4d84 <fwp_data.part.0.constprop.0>
    be4c:	91150283 	add	x3, x20, #0x540
    be50:	aa0003f7 	mov	x23, x0
    be54:	f949d861 	ldr	x1, [x3, #5040]
    be58:	f949ec60 	ldr	x0, [x3, #5080]
    be5c:	cb0102e1 	sub	x1, x23, x1
    be60:	eb00403f 	cmp	x1, x0, lsl #16
    be64:	54000322 	b.cs	bec8 <f0+0x2098>  // b.hs, b.nlast
    be68:	d350fc22 	lsr	x2, x1, #16
    be6c:	f949fc63 	ldr	x3, [x3, #5112]
    be70:	8b020842 	add	x2, x2, x2, lsl #2
    be74:	d37df042 	lsl	x2, x2, #3
    be78:	8b020060 	add	x0, x3, x2
    be7c:	f9401015 	ldr	x21, [x0, #32]
    be80:	b4000255 	cbz	x21, bec8 <f0+0x2098>
    be84:	38626862 	ldrb	w2, [x3, x2]
    be88:	7100085f 	cmp	w2, #0x2
    be8c:	54001ca0 	b.eq	c220 <f0+0x23f0>  // b.none
    be90:	7100045f 	cmp	w2, #0x1
    be94:	540001a1 	b.ne	bec8 <f0+0x2098>  // b.any
    be98:	29430002 	ldp	w2, w0, [x0, #24]
    be9c:	92403c21 	and	x1, x1, #0xffff
    bea0:	9b027c21 	mul	x1, x1, x2
    bea4:	d360fc21 	lsr	x1, x1, #32
    bea8:	eb00003f 	cmp	x1, x0
    beac:	540000e2 	b.cs	bec8 <f0+0x2098>  // b.hs, b.nlast
    beb0:	8b0102b5 	add	x21, x21, x1
    beb4:	394002a0 	ldrb	w0, [x21]
    beb8:	7103fc1f 	cmp	w0, #0xff
    bebc:	54002fc0 	b.eq	c4b4 <f0+0x2684>  // b.none
    bec0:	52800020 	mov	w0, #0x1                   	// #1
    bec4:	390002a0 	strb	w0, [x21]
    bec8:	911ea3e1 	add	x1, sp, #0x7a8
    becc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bed0:	52800020 	mov	w0, #0x1                   	// #1
    bed4:	f903d7f5 	str	x21, [sp, #1960]
    bed8:	f903dbf7 	str	x23, [sp, #1968]
    bedc:	97ffe3aa 	bl	4d84 <fwp_data.part.0.constprop.0>
    bee0:	97ffe63d 	bl	57d4 <fwp_rc_fresh>
    bee4:	aa0003e2 	mov	x2, x0
    bee8:	911ee3e1 	add	x1, sp, #0x7b8
    beec:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bef0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bef4:	52800020 	mov	w0, #0x1                   	// #1
    bef8:	f903dff7 	str	x23, [sp, #1976]
    befc:	91150294 	add	x20, x20, #0x540
    bf00:	f903e3e2 	str	x2, [sp, #1984]
    bf04:	97ffe3a0 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf08:	97ffe633 	bl	57d4 <fwp_rc_fresh>
    bf0c:	aa0003e2 	mov	x2, x0
    bf10:	911f23e1 	add	x1, sp, #0x7c8
    bf14:	52800020 	mov	w0, #0x1                   	// #1
    bf18:	f903e7f5 	str	x21, [sp, #1992]
    bf1c:	f903ebe2 	str	x2, [sp, #2000]
    bf20:	97ffe399 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf24:	97ffe62c 	bl	57d4 <fwp_rc_fresh>
    bf28:	aa0003e2 	mov	x2, x0
    bf2c:	911f63e1 	add	x1, sp, #0x7d8
    bf30:	52800020 	mov	w0, #0x1                   	// #1
    bf34:	f903eff7 	str	x23, [sp, #2008]
    bf38:	f903f3e2 	str	x2, [sp, #2016]
    bf3c:	97ffe392 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf40:	97ffe625 	bl	57d4 <fwp_rc_fresh>
    bf44:	aa0003e2 	mov	x2, x0
    bf48:	911fa3e1 	add	x1, sp, #0x7e8
    bf4c:	52800020 	mov	w0, #0x1                   	// #1
    bf50:	f903f7f5 	str	x21, [sp, #2024]
    bf54:	f903fbe2 	str	x2, [sp, #2032]
    bf58:	97ffe38b 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf5c:	97ffe61e 	bl	57d4 <fwp_rc_fresh>
    bf60:	aa0003e2 	mov	x2, x0
    bf64:	911fe3e1 	add	x1, sp, #0x7f8
    bf68:	52800020 	mov	w0, #0x1                   	// #1
    bf6c:	f903fff7 	str	x23, [sp, #2040]
    bf70:	f90403e2 	str	x2, [sp, #2048]
    bf74:	97ffe384 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf78:	97ffe617 	bl	57d4 <fwp_rc_fresh>
    bf7c:	aa0003e2 	mov	x2, x0
    bf80:	912023e1 	add	x1, sp, #0x808
    bf84:	52800020 	mov	w0, #0x1                   	// #1
    bf88:	f90407f5 	str	x21, [sp, #2056]
    bf8c:	f9040be2 	str	x2, [sp, #2064]
    bf90:	97ffe37d 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf94:	97ffe610 	bl	57d4 <fwp_rc_fresh>
    bf98:	aa0003e2 	mov	x2, x0
    bf9c:	912063e1 	add	x1, sp, #0x818
    bfa0:	52800020 	mov	w0, #0x1                   	// #1
    bfa4:	f9040ff7 	str	x23, [sp, #2072]
    bfa8:	f90413e2 	str	x2, [sp, #2080]
    bfac:	97ffe376 	bl	4d84 <fwp_data.part.0.constprop.0>
    bfb0:	97ffe609 	bl	57d4 <fwp_rc_fresh>
    bfb4:	aa0003e2 	mov	x2, x0
    bfb8:	9120a3e1 	add	x1, sp, #0x828
    bfbc:	52800020 	mov	w0, #0x1                   	// #1
    bfc0:	f90417f5 	str	x21, [sp, #2088]
    bfc4:	f9041be2 	str	x2, [sp, #2096]
    bfc8:	97ffe36f 	bl	4d84 <fwp_data.part.0.constprop.0>
    bfcc:	f949da81 	ldr	x1, [x20, #5040]
    bfd0:	aa0003f5 	mov	x21, x0
    bfd4:	f949ee80 	ldr	x0, [x20, #5080]
    bfd8:	cb0102a1 	sub	x1, x21, x1
    bfdc:	eb00403f 	cmp	x1, x0, lsl #16
    bfe0:	54000322 	b.cs	c044 <f0+0x2214>  // b.hs, b.nlast
    bfe4:	d350fc22 	lsr	x2, x1, #16
    bfe8:	f949fe83 	ldr	x3, [x20, #5112]
    bfec:	8b020842 	add	x2, x2, x2, lsl #2
    bff0:	d37df042 	lsl	x2, x2, #3
    bff4:	8b020060 	add	x0, x3, x2
    bff8:	f9401014 	ldr	x20, [x0, #32]
    bffc:	b4000254 	cbz	x20, c044 <f0+0x2214>
    c000:	38626862 	ldrb	w2, [x3, x2]
    c004:	7100085f 	cmp	w2, #0x2
    c008:	54001060 	b.eq	c214 <f0+0x23e4>  // b.none
    c00c:	7100045f 	cmp	w2, #0x1
    c010:	540001a1 	b.ne	c044 <f0+0x2214>  // b.any
    c014:	29430002 	ldp	w2, w0, [x0, #24]
    c018:	92403c21 	and	x1, x1, #0xffff
    c01c:	9b027c21 	mul	x1, x1, x2
    c020:	d360fc21 	lsr	x1, x1, #32
    c024:	eb00003f 	cmp	x1, x0
    c028:	540000e2 	b.cs	c044 <f0+0x2214>  // b.hs, b.nlast
    c02c:	8b010294 	add	x20, x20, x1
    c030:	39400280 	ldrb	w0, [x20]
    c034:	7103fc1f 	cmp	w0, #0xff
    c038:	540015a0 	b.eq	c2ec <f0+0x24bc>  // b.none
    c03c:	52800020 	mov	w0, #0x1                   	// #1
    c040:	39000280 	strb	w0, [x20]
    c044:	9120e3e1 	add	x1, sp, #0x838
    c048:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c04c:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c050:	52800020 	mov	w0, #0x1                   	// #1
    c054:	f9041ff4 	str	x20, [sp, #2104]
    c058:	f90423f5 	str	x21, [sp, #2112]
    c05c:	97ffe34a 	bl	4d84 <fwp_data.part.0.constprop.0>
    c060:	97ffe5dd 	bl	57d4 <fwp_rc_fresh>
    c064:	aa0003e2 	mov	x2, x0
    c068:	912123e1 	add	x1, sp, #0x848
    c06c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c070:	52800020 	mov	w0, #0x1                   	// #1
    c074:	f90427e3 	str	x3, [sp, #2120]
    c078:	f9042be2 	str	x2, [sp, #2128]
    c07c:	97ffe342 	bl	4d84 <fwp_data.part.0.constprop.0>
    c080:	97ffe5d5 	bl	57d4 <fwp_rc_fresh>
    c084:	aa0003e2 	mov	x2, x0
    c088:	aa1603e1 	mov	x1, x22
    c08c:	52800020 	mov	w0, #0x1                   	// #1
    c090:	f9042ff4 	str	x20, [sp, #2136]
    c094:	f90433e2 	str	x2, [sp, #2144]
    c098:	97ffe33b 	bl	4d84 <fwp_data.part.0.constprop.0>
    c09c:	97ffe5ce 	bl	57d4 <fwp_rc_fresh>
    c0a0:	aa0003f5 	mov	x21, x0
    c0a4:	aa1303e1 	mov	x1, x19
    c0a8:	97fff0b2 	bl	8370 <fwp_hof0.constprop.0>
    c0ac:	aa0003f4 	mov	x20, x0
    c0b0:	aa1503e0 	mov	x0, x21
    c0b4:	97ffe72b 	bl	5d60 <fwp_drop0>
    c0b8:	aa1303e0 	mov	x0, x19
    c0bc:	97ffe729 	bl	5d60 <fwp_drop0>
    c0c0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c0c4:	f947f400 	ldr	x0, [x0, #4072]
    c0c8:	f94437e2 	ldr	x2, [sp, #2152]
    c0cc:	f9400001 	ldr	x1, [x0]
    c0d0:	eb010042 	subs	x2, x2, x1
    c0d4:	d2800001 	mov	x1, #0x0                   	// #0
    c0d8:	54001f41 	b.ne	c4c0 <f0+0x2690>  // b.any
    c0dc:	9121c3ff 	add	sp, sp, #0x870
    c0e0:	aa1403e0 	mov	x0, x20
    c0e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c0e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c0ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    c0f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c0f4:	a94573fb 	ldp	x27, x28, [sp, #80]
    c0f8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c0fc:	d65f03c0 	ret
    c100:	aa1c03e0 	mov	x0, x28
    c104:	97ffdf83 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c108:	17fff794 	b	9f58 <f0+0x128>
    c10c:	72003c5f 	tst	w2, #0xffff
    c110:	54fef261 	b.ne	9f5c <f0+0x12c>  // b.any
    c114:	17fff78e 	b	9f4c <f0+0x11c>
    c118:	72003c3f 	tst	w1, #0xffff
    c11c:	54fefcc1 	b.ne	a0b4 <f0+0x284>  // b.any
    c120:	17fff7e0 	b	a0a0 <f0+0x270>
    c124:	72003c3f 	tst	w1, #0xffff
    c128:	54ff0761 	b.ne	a214 <f0+0x3e4>  // b.any
    c12c:	17fff835 	b	a200 <f0+0x3d0>
    c130:	72003c3f 	tst	w1, #0xffff
    c134:	54ff0181 	b.ne	a164 <f0+0x334>  // b.any
    c138:	17fff806 	b	a150 <f0+0x320>
    c13c:	72003c3f 	tst	w1, #0xffff
    c140:	54ff1321 	b.ne	a3a4 <f0+0x574>  // b.any
    c144:	17fff893 	b	a390 <f0+0x560>
    c148:	72003c3f 	tst	w1, #0xffff
    c14c:	54ff0bc1 	b.ne	a2c4 <f0+0x494>  // b.any
    c150:	17fff858 	b	a2b0 <f0+0x480>
    c154:	72003c3f 	tst	w1, #0xffff
    c158:	54ff1b81 	b.ne	a4c8 <f0+0x698>  // b.any
    c15c:	17fff8d6 	b	a4b4 <f0+0x684>
    c160:	72003c3f 	tst	w1, #0xffff
    c164:	54ff16a1 	b.ne	a438 <f0+0x608>  // b.any
    c168:	17fff8af 	b	a424 <f0+0x5f4>
    c16c:	72003c3f 	tst	w1, #0xffff
    c170:	54ff8a01 	b.ne	b2b0 <f0+0x1480>  // b.any
    c174:	17fffc4a 	b	b29c <f0+0x146c>
    c178:	72003c3f 	tst	w1, #0xffff
    c17c:	54ff7f81 	b.ne	b16c <f0+0x133c>  // b.any
    c180:	17fffbf6 	b	b158 <f0+0x1328>
    c184:	72003c3f 	tst	w1, #0xffff
    c188:	54ff9561 	b.ne	b434 <f0+0x1604>  // b.any
    c18c:	17fffca5 	b	b420 <f0+0x15f0>
    c190:	72003c3f 	tst	w1, #0xffff
    c194:	54ff8d81 	b.ne	b344 <f0+0x1514>  // b.any
    c198:	17fffc66 	b	b330 <f0+0x1500>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ffa3a1 	b.ne	b614 <f0+0x17e4>  // b.any
    c1a4:	17fffd17 	b	b600 <f0+0x17d0>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ff9ae1 	b.ne	b508 <f0+0x16d8>  // b.any
    c1b0:	17fffcd1 	b	b4f4 <f0+0x16c4>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ffb481 	b.ne	b848 <f0+0x1a18>  // b.any
    c1bc:	17fffd9e 	b	b834 <f0+0x1a04>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ffad81 	b.ne	b774 <f0+0x1944>  // b.any
    c1c8:	17fffd66 	b	b760 <f0+0x1930>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ffc281 	b.ne	ba20 <f0+0x1bf0>  // b.any
    c1d4:	17fffe0e 	b	ba0c <f0+0x1bdc>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ffb801 	b.ne	b8dc <f0+0x1aac>  // b.any
    c1e0:	17fffdba 	b	b8c8 <f0+0x1a98>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ffcde1 	b.ne	bba4 <f0+0x1d74>  // b.any
    c1ec:	17fffe69 	b	bb90 <f0+0x1d60>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54ffc601 	b.ne	bab4 <f0+0x1c84>  // b.any
    c1f8:	17fffe2a 	b	baa0 <f0+0x1c70>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ffd981 	b.ne	bd30 <f0+0x1f00>  // b.any
    c204:	17fffec6 	b	bd1c <f0+0x1eec>
    c208:	72003c3f 	tst	w1, #0xffff
    c20c:	54ffd361 	b.ne	bc78 <f0+0x1e48>  // b.any
    c210:	17fffe95 	b	bc64 <f0+0x1e34>
    c214:	72003c3f 	tst	w1, #0xffff
    c218:	54fff161 	b.ne	c044 <f0+0x2214>  // b.any
    c21c:	17ffff85 	b	c030 <f0+0x2200>
    c220:	72003c3f 	tst	w1, #0xffff
    c224:	54ffe521 	b.ne	bec8 <f0+0x2098>  // b.any
    c228:	17ffff23 	b	beb4 <f0+0x2084>
    c22c:	72003c3f 	tst	w1, #0xffff
    c230:	54ff1fc1 	b.ne	a628 <f0+0x7f8>  // b.any
    c234:	17fff8f8 	b	a614 <f0+0x7e4>
    c238:	72003c3f 	tst	w1, #0xffff
    c23c:	54ff19e1 	b.ne	a578 <f0+0x748>  // b.any
    c240:	17fff8c9 	b	a564 <f0+0x734>
    c244:	72003c3f 	tst	w1, #0xffff
    c248:	54ff2a01 	b.ne	a788 <f0+0x958>  // b.any
    c24c:	17fff94a 	b	a774 <f0+0x944>
    c250:	72003c3f 	tst	w1, #0xffff
    c254:	54ff2421 	b.ne	a6d8 <f0+0x8a8>  // b.any
    c258:	17fff91b 	b	a6c4 <f0+0x894>
    c25c:	72003c3f 	tst	w1, #0xffff
    c260:	54ff34a1 	b.ne	a8f4 <f0+0xac4>  // b.any
    c264:	17fff99f 	b	a8e0 <f0+0xab0>
    c268:	72003c3f 	tst	w1, #0xffff
    c26c:	54ff2e81 	b.ne	a83c <f0+0xa0c>  // b.any
    c270:	17fff96e 	b	a828 <f0+0x9f8>
    c274:	72003c3f 	tst	w1, #0xffff
    c278:	54ff4121 	b.ne	aa9c <f0+0xc6c>  // b.any
    c27c:	17fffa03 	b	aa88 <f0+0xc58>
    c280:	72003c3f 	tst	w1, #0xffff
    c284:	54ff3b01 	b.ne	a9e4 <f0+0xbb4>  // b.any
    c288:	17fff9d2 	b	a9d0 <f0+0xba0>
    c28c:	72003c3f 	tst	w1, #0xffff
    c290:	54ff49c1 	b.ne	abc8 <f0+0xd98>  // b.any
    c294:	17fffa48 	b	abb4 <f0+0xd84>
    c298:	72003c3f 	tst	w1, #0xffff
    c29c:	54ff44c1 	b.ne	ab34 <f0+0xd04>  // b.any
    c2a0:	17fffa20 	b	ab20 <f0+0xcf0>
    c2a4:	72003c3f 	tst	w1, #0xffff
    c2a8:	54ff5381 	b.ne	ad18 <f0+0xee8>  // b.any
    c2ac:	17fffa96 	b	ad04 <f0+0xed4>
    c2b0:	72003c3f 	tst	w1, #0xffff
    c2b4:	54ff4d61 	b.ne	ac60 <f0+0xe30>  // b.any
    c2b8:	17fffa65 	b	ac4c <f0+0xe1c>
    c2bc:	72003c3f 	tst	w1, #0xffff
    c2c0:	54ff5ee1 	b.ne	ae9c <f0+0x106c>  // b.any
    c2c4:	17fffaf1 	b	ae88 <f0+0x1058>
    c2c8:	72003c3f 	tst	w1, #0xffff
    c2cc:	54ff5701 	b.ne	adac <f0+0xf7c>  // b.any
    c2d0:	17fffab2 	b	ad98 <f0+0xf68>
    c2d4:	72003c3f 	tst	w1, #0xffff
    c2d8:	54ff6d21 	b.ne	b07c <f0+0x124c>  // b.any
    c2dc:	17fffb63 	b	b068 <f0+0x1238>
    c2e0:	72003c3f 	tst	w1, #0xffff
    c2e4:	54ff6621 	b.ne	afa8 <f0+0x1178>  // b.any
    c2e8:	17fffb2b 	b	af94 <f0+0x1164>
    c2ec:	aa1403e0 	mov	x0, x20
    c2f0:	97ffdf08 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2f4:	17ffff52 	b	c03c <f0+0x220c>
    c2f8:	aa1703e0 	mov	x0, x23
    c2fc:	97ffdf05 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c300:	17fff76b 	b	a0ac <f0+0x27c>
    c304:	aa1703e0 	mov	x0, x23
    c308:	97ffdf02 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c30c:	17fff794 	b	a15c <f0+0x32c>
    c310:	aa1703e0 	mov	x0, x23
    c314:	97ffdeff 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c318:	17fff7bd 	b	a20c <f0+0x3dc>
    c31c:	aa1703e0 	mov	x0, x23
    c320:	97ffdefc 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c324:	17fff7e6 	b	a2bc <f0+0x48c>
    c328:	aa1703e0 	mov	x0, x23
    c32c:	97ffdef9 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c330:	17fff81b 	b	a39c <f0+0x56c>
    c334:	aa1703e0 	mov	x0, x23
    c338:	97ffdef6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c33c:	17fff83d 	b	a430 <f0+0x600>
    c340:	aa1703e0 	mov	x0, x23
    c344:	97ffdef3 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c348:	17fff85e 	b	a4c0 <f0+0x690>
    c34c:	aa1703e0 	mov	x0, x23
    c350:	97ffdef0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c354:	17fff887 	b	a570 <f0+0x740>
    c358:	aa1703e0 	mov	x0, x23
    c35c:	97ffdeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c360:	17fff8b0 	b	a620 <f0+0x7f0>
    c364:	aa1703e0 	mov	x0, x23
    c368:	97ffdeea 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c36c:	17fff8d9 	b	a6d0 <f0+0x8a0>
    c370:	aa1703e0 	mov	x0, x23
    c374:	97ffdee7 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c378:	17fff902 	b	a780 <f0+0x950>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffdee4 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c384:	17fff92c 	b	a834 <f0+0xa04>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffdee1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c390:	17fff957 	b	a8ec <f0+0xabc>
    c394:	aa1703e0 	mov	x0, x23
    c398:	97ffdede 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c39c:	17fff990 	b	a9dc <f0+0xbac>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffdedb 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3a8:	17fff9bb 	b	aa94 <f0+0xc64>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffded8 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3b4:	17fff9de 	b	ab2c <f0+0xcfc>
    c3b8:	aa1703e0 	mov	x0, x23
    c3bc:	97ffded5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3c0:	17fffa00 	b	abc0 <f0+0xd90>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffded2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3cc:	17fffa23 	b	ac58 <f0+0xe28>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffdecf 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3d8:	17fffa4e 	b	ad10 <f0+0xee0>
    c3dc:	aa1703e0 	mov	x0, x23
    c3e0:	97ffdecc 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3e4:	17fffa70 	b	ada4 <f0+0xf74>
    c3e8:	aa1703e0 	mov	x0, x23
    c3ec:	97ffdec9 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3f0:	17fffaa9 	b	ae94 <f0+0x1064>
    c3f4:	aa1703e0 	mov	x0, x23
    c3f8:	97ffdec6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3fc:	17fffae9 	b	afa0 <f0+0x1170>
    c400:	aa1703e0 	mov	x0, x23
    c404:	97ffdec3 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c408:	17fffb1b 	b	b074 <f0+0x1244>
    c40c:	aa1503e0 	mov	x0, x21
    c410:	97ffdec0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c414:	17fffb54 	b	b164 <f0+0x1334>
    c418:	aa1703e0 	mov	x0, x23
    c41c:	97ffdebd 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c420:	17fffba2 	b	b2a8 <f0+0x1478>
    c424:	aa1703e0 	mov	x0, x23
    c428:	97ffdeba 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c42c:	17fffbc4 	b	b33c <f0+0x150c>
    c430:	aa1703e0 	mov	x0, x23
    c434:	97ffdeb7 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c438:	17fffbfd 	b	b42c <f0+0x15fc>
    c43c:	aa1703e0 	mov	x0, x23
    c440:	97ffdeb4 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c444:	17fffc2f 	b	b500 <f0+0x16d0>
    c448:	aa1703e0 	mov	x0, x23
    c44c:	97ffdeb1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c450:	17fffc6f 	b	b60c <f0+0x17dc>
    c454:	aa1703e0 	mov	x0, x23
    c458:	97ffdeae 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c45c:	17fffcc4 	b	b76c <f0+0x193c>
    c460:	aa1703e0 	mov	x0, x23
    c464:	97ffdeab 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c468:	17fffcf6 	b	b840 <f0+0x1a10>
    c46c:	aa1503e0 	mov	x0, x21
    c470:	97ffdea8 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c474:	17fffd18 	b	b8d4 <f0+0x1aa4>
    c478:	aa1703e0 	mov	x0, x23
    c47c:	97ffdea5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c480:	17fffd66 	b	ba18 <f0+0x1be8>
    c484:	aa1703e0 	mov	x0, x23
    c488:	97ffdea2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c48c:	17fffd88 	b	baac <f0+0x1c7c>
    c490:	aa1703e0 	mov	x0, x23
    c494:	97ffde9f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c498:	17fffdc1 	b	bb9c <f0+0x1d6c>
    c49c:	aa1703e0 	mov	x0, x23
    c4a0:	97ffde9c 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c4a4:	17fffdf3 	b	bc70 <f0+0x1e40>
    c4a8:	aa1703e0 	mov	x0, x23
    c4ac:	97ffde99 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c4b0:	17fffe1e 	b	bd28 <f0+0x1ef8>
    c4b4:	aa1503e0 	mov	x0, x21
    c4b8:	97ffde96 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c4bc:	17fffe81 	b	bec0 <f0+0x2090>
    c4c0:	97ffd8f0 	bl	2880 <__stack_chk_fail@plt>
    c4c4:	97ffd903 	bl	28d0 <abort@plt>
    c4c8:	d503201f 	nop
    c4cc:	d503201f 	nop

000000000000c4d0 <fwp_main_thread>:
    c4d0:	d10443ff 	sub	sp, sp, #0x110
    c4d4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c4d8:	f947f400 	ldr	x0, [x0, #4072]
    c4dc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c4e0:	910303fd 	add	x29, sp, #0xc0
    c4e4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c4e8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xca0>
    c4ec:	91150261 	add	x1, x19, #0x540
    c4f0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c4f4:	b953a421 	ldr	w1, [x1, #5028]
    c4f8:	f9400002 	ldr	x2, [x0]
    c4fc:	f9005fe2 	str	x2, [sp, #184]
    c500:	d2800002 	mov	x2, #0x0                   	// #0
    c504:	34000e21 	cbz	w1, c6c8 <fwp_main_thread+0x1f8>
    c508:	91150273 	add	x19, x19, #0x540
    c50c:	b953aa60 	ldr	w0, [x19, #5032]
    c510:	35000d40 	cbnz	w0, c6b8 <fwp_main_thread+0x1e8>
    c514:	91001fe2 	add	x2, sp, #0x7
    c518:	900000b4 	adrp	x20, 20000 <__data_start>
    c51c:	900000a3 	adrp	x3, 20000 <__data_start>
    c520:	9100c293 	add	x19, x20, #0x30
    c524:	910d8063 	add	x3, x3, #0x360
    c528:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c52c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c530:	910023e0 	add	x0, sp, #0x8
    c534:	d2800001 	mov	x1, #0x0                   	// #0
    c538:	f90007e3 	str	x3, [sp, #8]
    c53c:	b90013ff 	str	wzr, [sp, #16]
    c540:	a9019262 	stp	x2, x4, [x19, #24]
    c544:	f9000fe5 	str	x5, [sp, #24]
    c548:	97ffd866 	bl	26e0 <sigaltstack@plt>
    c54c:	35000220 	cbnz	w0, c590 <fwp_main_thread+0xc0>
    c550:	4f000400 	movi	v0.4s, #0x0
    c554:	9100a3e0 	add	x0, sp, #0x28
    c558:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c55c:	52800082 	mov	w2, #0x4                   	// #4
    c560:	9101c021 	add	x1, x1, #0x70
    c564:	72a10002 	movk	w2, #0x800, lsl #16
    c568:	910083f5 	add	x21, sp, #0x20
    c56c:	f90013e1 	str	x1, [sp, #32]
    c570:	3d802000 	str	q0, [x0, #128]
    c574:	b900abe2 	str	w2, [sp, #168]
    c578:	ad000000 	stp	q0, q0, [x0]
    c57c:	ad010000 	stp	q0, q0, [x0, #32]
    c580:	ad020000 	stp	q0, q0, [x0, #64]
    c584:	ad030000 	stp	q0, q0, [x0, #96]
    c588:	97ffd8ae 	bl	2840 <sigemptyset@plt>
    c58c:	340000c0 	cbz	w0, c5a4 <fwp_main_thread+0xd4>
    c590:	b0000000 	adrp	x0, d000 <__modti3+0x2a0>
    c594:	911ae000 	add	x0, x0, #0x6b8
    c598:	a90f63f7 	stp	x23, x24, [sp, #240]
    c59c:	f90083f9 	str	x25, [sp, #256]
    c5a0:	97ffde3c 	bl	3e90 <fwp_trap>
    c5a4:	aa1503e1 	mov	x1, x21
    c5a8:	d2800002 	mov	x2, #0x0                   	// #0
    c5ac:	52800160 	mov	w0, #0xb                   	// #11
    c5b0:	97ffd8bc 	bl	28a0 <sigaction@plt>
    c5b4:	35fffee0 	cbnz	w0, c590 <fwp_main_thread+0xc0>
    c5b8:	aa1503e1 	mov	x1, x21
    c5bc:	d2800002 	mov	x2, #0x0                   	// #0
    c5c0:	528000e0 	mov	w0, #0x7                   	// #7
    c5c4:	97ffd8b7 	bl	28a0 <sigaction@plt>
    c5c8:	35fffe40 	cbnz	w0, c590 <fwp_main_thread+0xc0>
    c5cc:	b942fa60 	ldr	w0, [x19, #760]
    c5d0:	a90f63f7 	stp	x23, x24, [sp, #240]
    c5d4:	340019a0 	cbz	w0, c908 <fwp_main_thread+0x438>
    c5d8:	9100c296 	add	x22, x20, #0x30
    c5dc:	f9400ad5 	ldr	x21, [x22, #16]
    c5e0:	b40007d5 	cbz	x21, c6d8 <fwp_main_thread+0x208>
    c5e4:	910102b7 	add	x23, x21, #0x40
    c5e8:	f90083f9 	str	x25, [sp, #256]
    c5ec:	52800038 	mov	w24, #0x1                   	// #1
    c5f0:	39414ab9 	ldrb	w25, [x21, #82]
    c5f4:	39014ab8 	strb	w24, [x21, #82]
    c5f8:	f94016a0 	ldr	x0, [x21, #40]
    c5fc:	b40006a0 	cbz	x0, c6d0 <fwp_main_thread+0x200>
    c600:	f94032a1 	ldr	x1, [x21, #96]
    c604:	394146a0 	ldrb	w0, [x21, #81]
    c608:	b40019c1 	cbz	x1, c940 <fwp_main_thread+0x470>
    c60c:	36001880 	tbz	w0, #0, c91c <fwp_main_thread+0x44c>
    c610:	f9400ad3 	ldr	x19, [x22, #16]
    c614:	f94022a0 	ldr	x0, [x21, #64]
    c618:	39414a61 	ldrb	w1, [x19, #82]
    c61c:	37001be1 	tbnz	w1, #0, c998 <fwp_main_thread+0x4c8>
    c620:	f9403261 	ldr	x1, [x19, #96]
    c624:	a911fe77 	stp	x23, xzr, [x19, #280]
    c628:	f9009660 	str	x0, [x19, #296]
    c62c:	b4000040 	cbz	x0, c634 <fwp_main_thread+0x164>
    c630:	f9009013 	str	x19, [x0, #288]
    c634:	f90022b3 	str	x19, [x21, #64]
    c638:	b4000101 	cbz	x1, c658 <fwp_main_thread+0x188>
    c63c:	f94046c0 	ldr	x0, [x22, #136]
    c640:	39015678 	strb	w24, [x19, #85]
    c644:	f9003661 	str	x1, [x19, #104]
    c648:	a910827f 	stp	xzr, x0, [x19, #264]
    c64c:	b4000040 	cbz	x0, c654 <fwp_main_thread+0x184>
    c650:	f9008413 	str	x19, [x0, #264]
    c654:	f90046d3 	str	x19, [x22, #136]
    c658:	39015a7f 	strb	wzr, [x19, #86]
    c65c:	97ffe8b9 	bl	6940 <fwp_block>
    c660:	f9408e62 	ldr	x2, [x19, #280]
    c664:	b4000142 	cbz	x2, c68c <fwp_main_thread+0x1bc>
    c668:	a9520261 	ldp	x1, x0, [x19, #288]
    c66c:	b4001a21 	cbz	x1, c9b0 <fwp_main_thread+0x4e0>
    c670:	f9009420 	str	x0, [x1, #296]
    c674:	f9409660 	ldr	x0, [x19, #296]
    c678:	b4000040 	cbz	x0, c680 <fwp_main_thread+0x1b0>
    c67c:	f9009001 	str	x1, [x0, #288]
    c680:	91080260 	add	x0, x19, #0x200
    c684:	f900967f 	str	xzr, [x19, #296]
    c688:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c68c:	39415660 	ldrb	w0, [x19, #85]
    c690:	3607fb40 	tbz	w0, #0, c5f8 <fwp_main_thread+0x128>
    c694:	a9508261 	ldp	x1, x0, [x19, #264]
    c698:	b4001901 	cbz	x1, c9b8 <fwp_main_thread+0x4e8>
    c69c:	f9008820 	str	x0, [x1, #272]
    c6a0:	b4000040 	cbz	x0, c6a8 <fwp_main_thread+0x1d8>
    c6a4:	f9008401 	str	x1, [x0, #264]
    c6a8:	91080260 	add	x0, x19, #0x200
    c6ac:	3901567f 	strb	wzr, [x19, #85]
    c6b0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c6b4:	17ffffd1 	b	c5f8 <fwp_main_thread+0x128>
    c6b8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c6bc:	91261000 	add	x0, x0, #0x984
    c6c0:	94000284 	bl	d0d0 <atexit>
    c6c4:	17ffff94 	b	c514 <fwp_main_thread+0x44>
    c6c8:	97ffdd0a 	bl	3af0 <fwp_heap_init>
    c6cc:	17ffff8f 	b	c508 <fwp_main_thread+0x38>
    c6d0:	39014ab9 	strb	w25, [x21, #82]
    c6d4:	f94083f9 	ldr	x25, [sp, #256]
    c6d8:	9100c293 	add	x19, x20, #0x30
    c6dc:	f9416e60 	ldr	x0, [x19, #728]
    c6e0:	b5000180 	cbnz	x0, c710 <fwp_main_thread+0x240>
    c6e4:	f9417660 	ldr	x0, [x19, #744]
    c6e8:	b5000140 	cbnz	x0, c710 <fwp_main_thread+0x240>
    c6ec:	f9416a60 	ldr	x0, [x19, #720]
    c6f0:	97ffdea4 	bl	4180 <fwp_mem_free>
    c6f4:	f9016a7f 	str	xzr, [x19, #720]
    c6f8:	f9400a60 	ldr	x0, [x19, #16]
    c6fc:	f901727f 	str	xzr, [x19, #736]
    c700:	b40000c0 	cbz	x0, c718 <fwp_main_thread+0x248>
    c704:	f900541f 	str	xzr, [x0, #168]
    c708:	f9005c1f 	str	xzr, [x0, #184]
    c70c:	14000003 	b	c718 <fwp_main_thread+0x248>
    c710:	9100c280 	add	x0, x20, #0x30
    c714:	f9400800 	ldr	x0, [x0, #16]
    c718:	9100c281 	add	x1, x20, #0x30
    c71c:	f9418826 	ldr	x6, [x1, #784]
    c720:	b903083f 	str	wzr, [x1, #776]
    c724:	eb0000df 	cmp	x6, x0
    c728:	54001561 	b.ne	c9d4 <fwp_main_thread+0x504>  // b.any
    c72c:	b4000380 	cbz	x0, c79c <fwp_main_thread+0x2cc>
    c730:	f9415825 	ldr	x5, [x1, #688]
    c734:	52800021 	mov	w1, #0x1                   	// #1
    c738:	39014801 	strb	w1, [x0, #82]
    c73c:	b4000305 	cbz	x5, c79c <fwp_main_thread+0x2cc>
    c740:	394140a0 	ldrb	w0, [x5, #80]
    c744:	37000060 	tbnz	w0, #0, c750 <fwp_main_thread+0x280>
    c748:	aa0503e0 	mov	x0, x5
    c74c:	97ffdb49 	bl	3470 <fwp_cancel_tree.part.0>
    c750:	f9409ca5 	ldr	x5, [x5, #312]
    c754:	b5ffff65 	cbnz	x5, c740 <fwp_main_thread+0x270>
    c758:	9100c293 	add	x19, x20, #0x30
    c75c:	52800035 	mov	w21, #0x1                   	// #1
    c760:	f94028c0 	ldr	x0, [x6, #80]
    c764:	f2001c1f 	tst	x0, #0xff000000ff
    c768:	540000e1 	b.ne	c784 <fwp_main_thread+0x2b4>  // b.any
    c76c:	f9401660 	ldr	x0, [x19, #40]
    c770:	390150d5 	strb	w21, [x6, #84]
    c774:	f90080df 	str	xzr, [x6, #256]
    c778:	b40010c0 	cbz	x0, c990 <fwp_main_thread+0x4c0>
    c77c:	f9008006 	str	x6, [x0, #256]
    c780:	f9001666 	str	x6, [x19, #40]
    c784:	97ffe86f 	bl	6940 <fwp_block>
    c788:	97ffe7f6 	bl	6760 <fwp_free_zombie>
    c78c:	f9415a60 	ldr	x0, [x19, #688]
    c790:	b4000060 	cbz	x0, c79c <fwp_main_thread+0x2cc>
    c794:	f9418a66 	ldr	x6, [x19, #784]
    c798:	17fffff2 	b	c760 <fwp_main_thread+0x290>
    c79c:	9100c295 	add	x21, x20, #0x30
    c7a0:	97ffe7f0 	bl	6760 <fwp_free_zombie>
    c7a4:	f9401aa0 	ldr	x0, [x21, #48]
    c7a8:	b5001160 	cbnz	x0, c9d4 <fwp_main_thread+0x504>
    c7ac:	f94046a0 	ldr	x0, [x21, #136]
    c7b0:	b5001120 	cbnz	x0, c9d4 <fwp_main_thread+0x504>
    c7b4:	b940aab3 	ldr	w19, [x21, #168]
    c7b8:	340001f3 	cbz	w19, c7f4 <fwp_main_thread+0x324>
    c7bc:	93407e76 	sxtw	x22, w19
    c7c0:	51000673 	sub	w19, w19, #0x1
    c7c4:	d1000ad6 	sub	x22, x22, #0x2
    c7c8:	9102c2b7 	add	x23, x21, #0xb0
    c7cc:	cb3342d6 	sub	x22, x22, w19, uxtw
    c7d0:	93407e73 	sxtw	x19, w19
    c7d4:	d503201f 	nop
    c7d8:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c7dc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c7e0:	b900aab3 	str	w19, [x21, #168]
    c7e4:	d1000673 	sub	x19, x19, #0x1
    c7e8:	97ffd86e 	bl	29a0 <munmap@plt>
    c7ec:	eb1302df 	cmp	x22, x19
    c7f0:	54ffff41 	b.ne	c7d8 <fwp_main_thread+0x308>  // b.any
    c7f4:	900000b3 	adrp	x19, 20000 <__data_start>
    c7f8:	91004260 	add	x0, x19, #0x10
    c7fc:	b9400800 	ldr	w0, [x0, #8]
    c800:	36f80800 	tbz	w0, #31, c900 <fwp_main_thread+0x430>
    c804:	9100c295 	add	x21, x20, #0x30
    c808:	91004273 	add	x19, x19, #0x10
    c80c:	12800001 	mov	w1, #0xffffffff            	// #-1
    c810:	f94192a0 	ldr	x0, [x21, #800]
    c814:	b9000a61 	str	w1, [x19, #8]
    c818:	f9418ea1 	ldr	x1, [x21, #792]
    c81c:	b40001e0 	cbz	x0, c858 <fwp_main_thread+0x388>
    c820:	d2800013 	mov	x19, #0x0                   	// #0
    c824:	d503201f 	nop
    c828:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    c82c:	b40000e0 	cbz	x0, c848 <fwp_main_thread+0x378>
    c830:	f9400001 	ldr	x1, [x0]
    c834:	b5000d01 	cbnz	x1, c9d4 <fwp_main_thread+0x504>
    c838:	f9400401 	ldr	x1, [x0, #8]
    c83c:	b5000cc1 	cbnz	x1, c9d4 <fwp_main_thread+0x504>
    c840:	97ffde50 	bl	4180 <fwp_mem_free>
    c844:	f9418ea1 	ldr	x1, [x21, #792]
    c848:	91000673 	add	x19, x19, #0x1
    c84c:	f94192a0 	ldr	x0, [x21, #800]
    c850:	eb00027f 	cmp	x19, x0
    c854:	54fffea3 	b.cc	c828 <fwp_main_thread+0x358>  // b.lo, b.ul, b.last
    c858:	aa0103e0 	mov	x0, x1
    c85c:	97ffde49 	bl	4180 <fwp_mem_free>
    c860:	9100c280 	add	x0, x20, #0x30
    c864:	f9418813 	ldr	x19, [x0, #784]
    c868:	f9018c1f 	str	xzr, [x0, #792]
    c86c:	f901901f 	str	xzr, [x0, #800]
    c870:	b40001f3 	cbz	x19, c8ac <fwp_main_thread+0x3dc>
    c874:	f9401661 	ldr	x1, [x19, #40]
    c878:	b5000ae1 	cbnz	x1, c9d4 <fwp_main_thread+0x504>
    c87c:	f9405661 	ldr	x1, [x19, #168]
    c880:	b5000aa1 	cbnz	x1, c9d4 <fwp_main_thread+0x504>
    c884:	f9416c01 	ldr	x1, [x0, #728]
    c888:	b5000a61 	cbnz	x1, c9d4 <fwp_main_thread+0x504>
    c88c:	f9417400 	ldr	x0, [x0, #744]
    c890:	b5000a20 	cbnz	x0, c9d4 <fwp_main_thread+0x504>
    c894:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c898:	90000120 	adrp	x0, 30000 <alt.5+0xfca0>
    c89c:	910d8000 	add	x0, x0, #0x360
    c8a0:	97ffd7ec 	bl	2850 <memset@plt>
    c8a4:	aa1303e0 	mov	x0, x19
    c8a8:	97ffde36 	bl	4180 <fwp_mem_free>
    c8ac:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c8b0:	f947ec00 	ldr	x0, [x0, #4056]
    c8b4:	9100c294 	add	x20, x20, #0x30
    c8b8:	f9400000 	ldr	x0, [x0]
    c8bc:	f9000a9f 	str	xzr, [x20, #16]
    c8c0:	f9018a9f 	str	xzr, [x20, #784]
    c8c4:	97ffd83b 	bl	29b0 <fflush@plt>
    c8c8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c8cc:	f947f400 	ldr	x0, [x0, #4072]
    c8d0:	f9405fe2 	ldr	x2, [sp, #184]
    c8d4:	f9400001 	ldr	x1, [x0]
    c8d8:	eb010042 	subs	x2, x2, x1
    c8dc:	d2800001 	mov	x1, #0x0                   	// #0
    c8e0:	54000761 	b.ne	c9cc <fwp_main_thread+0x4fc>  // b.any
    c8e4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c8e8:	d2800000 	mov	x0, #0x0                   	// #0
    c8ec:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c8f0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c8f4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c8f8:	910443ff 	add	sp, sp, #0x110
    c8fc:	d65f03c0 	ret
    c900:	97ffd7e4 	bl	2890 <close@plt>
    c904:	17ffffc0 	b	c804 <fwp_main_thread+0x334>
    c908:	97fff54a 	bl	9e30 <f0>
    c90c:	f9018260 	str	x0, [x19, #768]
    c910:	52800021 	mov	w1, #0x1                   	// #1
    c914:	b902fa61 	str	w1, [x19, #760]
    c918:	17ffff30 	b	c5d8 <fwp_main_thread+0x108>
    c91c:	97ffdf7d 	bl	4710 <fwp_now_ns>
    c920:	f94032a1 	ldr	x1, [x21, #96]
    c924:	eb01001f 	cmp	x0, x1
    c928:	540000ab 	b.lt	c93c <fwp_main_thread+0x46c>  // b.tstop
    c92c:	394142a0 	ldrb	w0, [x21, #80]
    c930:	37000060 	tbnz	w0, #0, c93c <fwp_main_thread+0x46c>
    c934:	aa1503e0 	mov	x0, x21
    c938:	97ffdace 	bl	3470 <fwp_cancel_tree.part.0>
    c93c:	394146a0 	ldrb	w0, [x21, #81]
    c940:	f9400ad3 	ldr	x19, [x22, #16]
    c944:	39414a62 	ldrb	w2, [x19, #82]
    c948:	3707e640 	tbnz	w0, #0, c610 <fwp_main_thread+0x140>
    c94c:	f94032a1 	ldr	x1, [x21, #96]
    c950:	370001c2 	tbnz	w2, #0, c988 <fwp_main_thread+0x4b8>
    c954:	f9403260 	ldr	x0, [x19, #96]
    c958:	b4000180 	cbz	x0, c988 <fwp_main_thread+0x4b8>
    c95c:	b4000061 	cbz	x1, c968 <fwp_main_thread+0x498>
    c960:	eb01001f 	cmp	x0, x1
    c964:	9a81d000 	csel	x0, x0, x1, le
    c968:	f94022a1 	ldr	x1, [x21, #64]
    c96c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c970:	f9009661 	str	x1, [x19, #296]
    c974:	b4000261 	cbz	x1, c9c0 <fwp_main_thread+0x4f0>
    c978:	f9009033 	str	x19, [x1, #288]
    c97c:	aa0003e1 	mov	x1, x0
    c980:	f90022b3 	str	x19, [x21, #64]
    c984:	17ffff2e 	b	c63c <fwp_main_thread+0x16c>
    c988:	f94022a0 	ldr	x0, [x21, #64]
    c98c:	17ffff26 	b	c624 <fwp_main_thread+0x154>
    c990:	f9001a66 	str	x6, [x19, #48]
    c994:	17ffff7b 	b	c780 <fwp_main_thread+0x2b0>
    c998:	a911fe77 	stp	x23, xzr, [x19, #280]
    c99c:	f9009660 	str	x0, [x19, #296]
    c9a0:	b4000040 	cbz	x0, c9a8 <fwp_main_thread+0x4d8>
    c9a4:	f9009013 	str	x19, [x0, #288]
    c9a8:	f90022b3 	str	x19, [x21, #64]
    c9ac:	17ffff2b 	b	c658 <fwp_main_thread+0x188>
    c9b0:	f9000040 	str	x0, [x2]
    c9b4:	17ffff31 	b	c678 <fwp_main_thread+0x1a8>
    c9b8:	f90046c0 	str	x0, [x22, #136]
    c9bc:	17ffff39 	b	c6a0 <fwp_main_thread+0x1d0>
    c9c0:	aa0003e1 	mov	x1, x0
    c9c4:	f90022b3 	str	x19, [x21, #64]
    c9c8:	17ffff1d 	b	c63c <fwp_main_thread+0x16c>
    c9cc:	f90083f9 	str	x25, [sp, #256]
    c9d0:	97ffd7ac 	bl	2880 <__stack_chk_fail@plt>
    c9d4:	f90083f9 	str	x25, [sp, #256]
    c9d8:	97ffd7be 	bl	28d0 <abort@plt>
    c9dc:	d503201f 	nop

000000000000c9e0 <__divti3>:
    c9e0:	d503245f 	bti	c
    c9e4:	d2800004 	mov	x4, #0x0                   	// #0
    c9e8:	b7f80721 	tbnz	x1, #63, cacc <__divti3+0xec>
    c9ec:	b6f80083 	tbz	x3, #63, c9fc <__divti3+0x1c>
    c9f0:	eb0203e2 	negs	x2, x2
    c9f4:	aa2403e4 	mvn	x4, x4
    c9f8:	da0303e3 	ngc	x3, x3
    c9fc:	aa0203e6 	mov	x6, x2
    ca00:	aa0003e7 	mov	x7, x0
    ca04:	aa0103e5 	mov	x5, x1
    ca08:	b5000583 	cbnz	x3, cab8 <__divti3+0xd8>
    ca0c:	eb01005f 	cmp	x2, x1
    ca10:	54000e69 	b.ls	cbdc <__divti3+0x1fc>  // b.plast
    ca14:	dac01040 	clz	x0, x2
    ca18:	b40000e0 	cbz	x0, ca34 <__divti3+0x54>
    ca1c:	4b0003e1 	neg	w1, w0
    ca20:	9ac020a5 	lsl	x5, x5, x0
    ca24:	9ac02046 	lsl	x6, x2, x0
    ca28:	9ac124e1 	lsr	x1, x7, x1
    ca2c:	aa050025 	orr	x5, x1, x5
    ca30:	9ac020e7 	lsl	x7, x7, x0
    ca34:	d360fcc8 	lsr	x8, x6, #32
    ca38:	92407cc2 	and	x2, x6, #0xffffffff
    ca3c:	9ac808a3 	udiv	x3, x5, x8
    ca40:	9b089465 	msub	x5, x3, x8, x5
    ca44:	aa0303e0 	mov	x0, x3
    ca48:	9b037c41 	mul	x1, x2, x3
    ca4c:	93c780a5 	extr	x5, x5, x7, #32
    ca50:	eb05003f 	cmp	x1, x5
    ca54:	540000a9 	b.ls	ca68 <__divti3+0x88>  // b.plast
    ca58:	ab0500c5 	adds	x5, x6, x5
    ca5c:	d1000460 	sub	x0, x3, #0x1
    ca60:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ca64:	540015a8 	b.hi	cd18 <__divti3+0x338>  // b.pmore
    ca68:	cb0100a5 	sub	x5, x5, x1
    ca6c:	9ac808a3 	udiv	x3, x5, x8
    ca70:	9b089465 	msub	x5, x3, x8, x5
    ca74:	aa0303e1 	mov	x1, x3
    ca78:	9b037c42 	mul	x2, x2, x3
    ca7c:	aa0703e3 	mov	x3, x7
    ca80:	b3607ca3 	bfi	x3, x5, #32, #32
    ca84:	eb03005f 	cmp	x2, x3
    ca88:	540000c9 	b.ls	caa0 <__divti3+0xc0>  // b.plast
    ca8c:	ab0300c3 	adds	x3, x6, x3
    ca90:	d1000425 	sub	x5, x1, #0x1
    ca94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca98:	d1000821 	sub	x1, x1, #0x2
    ca9c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    caa0:	aa008020 	orr	x0, x1, x0, lsl #32
    caa4:	d2800001 	mov	x1, #0x0                   	// #0
    caa8:	b4000064 	cbz	x4, cab4 <__divti3+0xd4>
    caac:	eb0003e0 	negs	x0, x0
    cab0:	da0103e1 	ngc	x1, x1
    cab4:	d65f03c0 	ret
    cab8:	eb01007f 	cmp	x3, x1
    cabc:	54000109 	b.ls	cadc <__divti3+0xfc>  // b.plast
    cac0:	d2800001 	mov	x1, #0x0                   	// #0
    cac4:	d2800000 	mov	x0, #0x0                   	// #0
    cac8:	17fffff8 	b	caa8 <__divti3+0xc8>
    cacc:	eb0003e0 	negs	x0, x0
    cad0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cad4:	da0103e1 	ngc	x1, x1
    cad8:	17ffffc5 	b	c9ec <__divti3+0xc>
    cadc:	dac01067 	clz	x7, x3
    cae0:	b40010e7 	cbz	x7, ccfc <__divti3+0x31c>
    cae4:	d2800805 	mov	x5, #0x40                  	// #64
    cae8:	cb0700a5 	sub	x5, x5, x7
    caec:	9ac72063 	lsl	x3, x3, x7
    caf0:	9ac52448 	lsr	x8, x2, x5
    caf4:	aa030108 	orr	x8, x8, x3
    caf8:	9ac52426 	lsr	x6, x1, x5
    cafc:	92407d0a 	and	x10, x8, #0xffffffff
    cb00:	d360fd09 	lsr	x9, x8, #32
    cb04:	9ac52403 	lsr	x3, x0, x5
    cb08:	9ac72021 	lsl	x1, x1, x7
    cb0c:	aa010063 	orr	x3, x3, x1
    cb10:	9ac72042 	lsl	x2, x2, x7
    cb14:	9ac908cb 	udiv	x11, x6, x9
    cb18:	9b099965 	msub	x5, x11, x9, x6
    cb1c:	aa0b03e1 	mov	x1, x11
    cb20:	9b0b7d46 	mul	x6, x10, x11
    cb24:	93c380a5 	extr	x5, x5, x3, #32
    cb28:	eb0500df 	cmp	x6, x5
    cb2c:	540000a9 	b.ls	cb40 <__divti3+0x160>  // b.plast
    cb30:	ab050105 	adds	x5, x8, x5
    cb34:	d1000561 	sub	x1, x11, #0x1
    cb38:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cb3c:	54000f48 	b.hi	cd24 <__divti3+0x344>  // b.pmore
    cb40:	cb0600a6 	sub	x6, x5, x6
    cb44:	9ac908cb 	udiv	x11, x6, x9
    cb48:	9b099969 	msub	x9, x11, x9, x6
    cb4c:	aa0b03e5 	mov	x5, x11
    cb50:	9b0b7d4a 	mul	x10, x10, x11
    cb54:	b3607d23 	bfi	x3, x9, #32, #32
    cb58:	eb03015f 	cmp	x10, x3
    cb5c:	540000a9 	b.ls	cb70 <__divti3+0x190>  // b.plast
    cb60:	ab030103 	adds	x3, x8, x3
    cb64:	d1000565 	sub	x5, x11, #0x1
    cb68:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cb6c:	54000e28 	b.hi	cd30 <__divti3+0x350>  // b.pmore
    cb70:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cb74:	92407c48 	and	x8, x2, #0xffffffff
    cb78:	2a0503e5 	mov	w5, w5
    cb7c:	d360fc42 	lsr	x2, x2, #32
    cb80:	d360fc26 	lsr	x6, x1, #32
    cb84:	cb0a0063 	sub	x3, x3, x10
    cb88:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cb8c:	9b087caa 	mul	x10, x5, x8
    cb90:	9b087cc8 	mul	x8, x6, x8
    cb94:	9b0220a5 	madd	x5, x5, x2, x8
    cb98:	9b027cc6 	mul	x6, x6, x2
    cb9c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cba0:	8b0900c5 	add	x5, x6, x9
    cba4:	eb02011f 	cmp	x8, x2
    cba8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cbac:	8b4280c6 	add	x6, x6, x2, lsr #32
    cbb0:	eb06007f 	cmp	x3, x6
    cbb4:	540000e3 	b.cc	cbd0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cbb8:	92407d4a 	and	x10, x10, #0xffffffff
    cbbc:	9ac72000 	lsl	x0, x0, x7
    cbc0:	8b028142 	add	x2, x10, x2, lsl #32
    cbc4:	eb02001f 	cmp	x0, x2
    cbc8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cbcc:	54000a01 	b.ne	cd0c <__divti3+0x32c>  // b.any
    cbd0:	d1000420 	sub	x0, x1, #0x1
    cbd4:	d2800001 	mov	x1, #0x0                   	// #0
    cbd8:	17ffffb4 	b	caa8 <__divti3+0xc8>
    cbdc:	b5000062 	cbnz	x2, cbe8 <__divti3+0x208>
    cbe0:	d2800022 	mov	x2, #0x1                   	// #1
    cbe4:	9ac30846 	udiv	x6, x2, x3
    cbe8:	dac010c8 	clz	x8, x6
    cbec:	b5000408 	cbnz	x8, cc6c <__divti3+0x28c>
    cbf0:	d360fcc9 	lsr	x9, x6, #32
    cbf4:	92407cc5 	and	x5, x6, #0xffffffff
    cbf8:	cb060023 	sub	x3, x1, x6
    cbfc:	d2800021 	mov	x1, #0x1                   	// #1
    cc00:	9ac90868 	udiv	x8, x3, x9
    cc04:	9b098d03 	msub	x3, x8, x9, x3
    cc08:	aa0803e0 	mov	x0, x8
    cc0c:	9b057d02 	mul	x2, x8, x5
    cc10:	93c78063 	extr	x3, x3, x7, #32
    cc14:	eb03005f 	cmp	x2, x3
    cc18:	540000a9 	b.ls	cc2c <__divti3+0x24c>  // b.plast
    cc1c:	ab0300c3 	adds	x3, x6, x3
    cc20:	d1000500 	sub	x0, x8, #0x1
    cc24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cc28:	54000968 	b.hi	cd54 <__divti3+0x374>  // b.pmore
    cc2c:	cb020063 	sub	x3, x3, x2
    cc30:	9ac90862 	udiv	x2, x3, x9
    cc34:	aa0203e8 	mov	x8, x2
    cc38:	9b098c42 	msub	x2, x2, x9, x3
    cc3c:	aa0703e3 	mov	x3, x7
    cc40:	9b057d05 	mul	x5, x8, x5
    cc44:	b3607c43 	bfi	x3, x2, #32, #32
    cc48:	eb0300bf 	cmp	x5, x3
    cc4c:	540000c9 	b.ls	cc64 <__divti3+0x284>  // b.plast
    cc50:	ab0300c2 	adds	x2, x6, x3
    cc54:	d1000503 	sub	x3, x8, #0x1
    cc58:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cc5c:	d1000908 	sub	x8, x8, #0x2
    cc60:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cc64:	aa008100 	orr	x0, x8, x0, lsl #32
    cc68:	17ffff90 	b	caa8 <__divti3+0xc8>
    cc6c:	9ac820c6 	lsl	x6, x6, x8
    cc70:	d2800803 	mov	x3, #0x40                  	// #64
    cc74:	cb080063 	sub	x3, x3, x8
    cc78:	d360fcc9 	lsr	x9, x6, #32
    cc7c:	9ac82027 	lsl	x7, x1, x8
    cc80:	92407cc5 	and	x5, x6, #0xffffffff
    cc84:	9ac32422 	lsr	x2, x1, x3
    cc88:	9ac32403 	lsr	x3, x0, x3
    cc8c:	aa070063 	orr	x3, x3, x7
    cc90:	9ac9084a 	udiv	x10, x2, x9
    cc94:	9ac82007 	lsl	x7, x0, x8
    cc98:	9b098940 	msub	x0, x10, x9, x2
    cc9c:	aa0a03e1 	mov	x1, x10
    cca0:	9b0a7ca2 	mul	x2, x5, x10
    cca4:	93c38000 	extr	x0, x0, x3, #32
    cca8:	eb00005f 	cmp	x2, x0
    ccac:	540000a9 	b.ls	ccc0 <__divti3+0x2e0>  // b.plast
    ccb0:	ab0000c0 	adds	x0, x6, x0
    ccb4:	d1000541 	sub	x1, x10, #0x1
    ccb8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    ccbc:	54000468 	b.hi	cd48 <__divti3+0x368>  // b.pmore
    ccc0:	cb020000 	sub	x0, x0, x2
    ccc4:	9ac9080a 	udiv	x10, x0, x9
    ccc8:	9b098140 	msub	x0, x10, x9, x0
    cccc:	aa0a03e2 	mov	x2, x10
    ccd0:	9b0a7ca8 	mul	x8, x5, x10
    ccd4:	b3607c03 	bfi	x3, x0, #32, #32
    ccd8:	eb03011f 	cmp	x8, x3
    ccdc:	540000a9 	b.ls	ccf0 <__divti3+0x310>  // b.plast
    cce0:	ab0300c3 	adds	x3, x6, x3
    cce4:	d1000542 	sub	x2, x10, #0x1
    cce8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    ccec:	54000288 	b.hi	cd3c <__divti3+0x35c>  // b.pmore
    ccf0:	cb080063 	sub	x3, x3, x8
    ccf4:	aa018041 	orr	x1, x2, x1, lsl #32
    ccf8:	17ffffc2 	b	cc00 <__divti3+0x220>
    ccfc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cd00:	d2800001 	mov	x1, #0x0                   	// #0
    cd04:	9a9f87e0 	cset	x0, ls	// ls = plast
    cd08:	17ffff68 	b	caa8 <__divti3+0xc8>
    cd0c:	aa0103e0 	mov	x0, x1
    cd10:	d2800001 	mov	x1, #0x0                   	// #0
    cd14:	17ffff65 	b	caa8 <__divti3+0xc8>
    cd18:	d1000860 	sub	x0, x3, #0x2
    cd1c:	8b0600a5 	add	x5, x5, x6
    cd20:	17ffff52 	b	ca68 <__divti3+0x88>
    cd24:	d1000961 	sub	x1, x11, #0x2
    cd28:	8b0800a5 	add	x5, x5, x8
    cd2c:	17ffff85 	b	cb40 <__divti3+0x160>
    cd30:	d1000965 	sub	x5, x11, #0x2
    cd34:	8b080063 	add	x3, x3, x8
    cd38:	17ffff8e 	b	cb70 <__divti3+0x190>
    cd3c:	d1000942 	sub	x2, x10, #0x2
    cd40:	8b060063 	add	x3, x3, x6
    cd44:	17ffffeb 	b	ccf0 <__divti3+0x310>
    cd48:	d1000941 	sub	x1, x10, #0x2
    cd4c:	8b060000 	add	x0, x0, x6
    cd50:	17ffffdc 	b	ccc0 <__divti3+0x2e0>
    cd54:	d1000900 	sub	x0, x8, #0x2
    cd58:	8b060063 	add	x3, x3, x6
    cd5c:	17ffffb4 	b	cc2c <__divti3+0x24c>

000000000000cd60 <__modti3>:
    cd60:	d503245f 	bti	c
    cd64:	d2800004 	mov	x4, #0x0                   	// #0
    cd68:	b6f80081 	tbz	x1, #63, cd78 <__modti3+0x18>
    cd6c:	eb0003e0 	negs	x0, x0
    cd70:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cd74:	da0103e1 	ngc	x1, x1
    cd78:	f100007f 	cmp	x3, #0x0
    cd7c:	5400128b 	b.lt	cfcc <__modti3+0x26c>  // b.tstop
    cd80:	aa0003e7 	mov	x7, x0
    cd84:	aa0103e6 	mov	x6, x1
    cd88:	540004e1 	b.ne	ce24 <__modti3+0xc4>  // b.any
    cd8c:	eb02003f 	cmp	x1, x2
    cd90:	54000dc2 	b.cs	cf48 <__modti3+0x1e8>  // b.hs, b.nlast
    cd94:	dac01043 	clz	x3, x2
    cd98:	aa0303e5 	mov	x5, x3
    cd9c:	b40000e3 	cbz	x3, cdb8 <__modti3+0x58>
    cda0:	4b0303e6 	neg	w6, w3
    cda4:	9ac32021 	lsl	x1, x1, x3
    cda8:	9ac32042 	lsl	x2, x2, x3
    cdac:	9ac62406 	lsr	x6, x0, x6
    cdb0:	aa0100c6 	orr	x6, x6, x1
    cdb4:	9ac32007 	lsl	x7, x0, x3
    cdb8:	d360fc40 	lsr	x0, x2, #32
    cdbc:	92407c43 	and	x3, x2, #0xffffffff
    cdc0:	9ac008c1 	udiv	x1, x6, x0
    cdc4:	9b009826 	msub	x6, x1, x0, x6
    cdc8:	9b017c61 	mul	x1, x3, x1
    cdcc:	93c780c6 	extr	x6, x6, x7, #32
    cdd0:	eb06003f 	cmp	x1, x6
    cdd4:	540000a9 	b.ls	cde8 <__modti3+0x88>  // b.plast
    cdd8:	ab060046 	adds	x6, x2, x6
    cddc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cde0:	8b0200c8 	add	x8, x6, x2
    cde4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cde8:	cb0100c6 	sub	x6, x6, x1
    cdec:	9ac008c8 	udiv	x8, x6, x0
    cdf0:	9b009901 	msub	x1, x8, x0, x6
    cdf4:	aa0703e0 	mov	x0, x7
    cdf8:	9b087c63 	mul	x3, x3, x8
    cdfc:	b3607c20 	bfi	x0, x1, #32, #32
    ce00:	eb00007f 	cmp	x3, x0
    ce04:	54001088 	b.hi	d014 <__modti3+0x2b4>  // b.pmore
    ce08:	cb030000 	sub	x0, x0, x3
    ce0c:	9ac52400 	lsr	x0, x0, x5
    ce10:	d2800001 	mov	x1, #0x0                   	// #0
    ce14:	b4000064 	cbz	x4, ce20 <__modti3+0xc0>
    ce18:	eb0003e0 	negs	x0, x0
    ce1c:	da0103e1 	ngc	x1, x1
    ce20:	d65f03c0 	ret
    ce24:	dac01066 	clz	x6, x3
    ce28:	eb03003f 	cmp	x1, x3
    ce2c:	54ffff43 	b.cc	ce14 <__modti3+0xb4>  // b.lo, b.ul, b.last
    ce30:	93407cc5 	sxtw	x5, w6
    ce34:	d2800808 	mov	x8, #0x40                  	// #64
    ce38:	cb050108 	sub	x8, x8, x5
    ce3c:	9ac62063 	lsl	x3, x3, x6
    ce40:	9ac62025 	lsl	x5, x1, x6
    ce44:	9ac82447 	lsr	x7, x2, x8
    ce48:	aa0300e7 	orr	x7, x7, x3
    ce4c:	9ac82423 	lsr	x3, x1, x8
    ce50:	92407cec 	and	x12, x7, #0xffffffff
    ce54:	d360fcea 	lsr	x10, x7, #32
    ce58:	9ac82401 	lsr	x1, x0, x8
    ce5c:	aa050021 	orr	x1, x1, x5
    ce60:	9ac62042 	lsl	x2, x2, x6
    ce64:	9ac62000 	lsl	x0, x0, x6
    ce68:	9aca086b 	udiv	x11, x3, x10
    ce6c:	9b0a8d63 	msub	x3, x11, x10, x3
    ce70:	aa0b03e5 	mov	x5, x11
    ce74:	9b0b7d89 	mul	x9, x12, x11
    ce78:	93c18063 	extr	x3, x3, x1, #32
    ce7c:	eb03013f 	cmp	x9, x3
    ce80:	540000a9 	b.ls	ce94 <__modti3+0x134>  // b.plast
    ce84:	ab0300e3 	adds	x3, x7, x3
    ce88:	d1000565 	sub	x5, x11, #0x1
    ce8c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ce90:	54001168 	b.hi	d0bc <__modti3+0x35c>  // b.pmore
    ce94:	cb090063 	sub	x3, x3, x9
    ce98:	9aca086b 	udiv	x11, x3, x10
    ce9c:	9b0a8d6a 	msub	x10, x11, x10, x3
    cea0:	aa0b03e9 	mov	x9, x11
    cea4:	9b0b7d8c 	mul	x12, x12, x11
    cea8:	b3607d41 	bfi	x1, x10, #32, #32
    ceac:	eb01019f 	cmp	x12, x1
    ceb0:	540000a9 	b.ls	cec4 <__modti3+0x164>  // b.plast
    ceb4:	ab0100e1 	adds	x1, x7, x1
    ceb8:	d1000569 	sub	x9, x11, #0x1
    cebc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cec0:	54000f88 	b.hi	d0b0 <__modti3+0x350>  // b.pmore
    cec4:	aa058123 	orr	x3, x9, x5, lsl #32
    cec8:	92407c4b 	and	x11, x2, #0xffffffff
    cecc:	2a0903e9 	mov	w9, w9
    ced0:	d360fc4a 	lsr	x10, x2, #32
    ced4:	d360fc63 	lsr	x3, x3, #32
    ced8:	cb0c0021 	sub	x1, x1, x12
    cedc:	aa0a03ec 	mov	x12, x10
    cee0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cee4:	9b0b7d25 	mul	x5, x9, x11
    cee8:	9b0b7c6b 	mul	x11, x3, x11
    ceec:	9b0a2d29 	madd	x9, x9, x10, x11
    cef0:	92407caa 	and	x10, x5, #0xffffffff
    cef4:	9b0c7c63 	mul	x3, x3, x12
    cef8:	8b458125 	add	x5, x9, x5, lsr #32
    cefc:	8b0d0069 	add	x9, x3, x13
    cf00:	eb05017f 	cmp	x11, x5
    cf04:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cf08:	8b058149 	add	x9, x10, x5, lsl #32
    cf0c:	8b458063 	add	x3, x3, x5, lsr #32
    cf10:	eb03003f 	cmp	x1, x3
    cf14:	54000063 	b.cc	cf20 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cf18:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cf1c:	54000082 	b.cs	cf2c <__modti3+0x1cc>  // b.hs, b.nlast
    cf20:	eb020129 	subs	x9, x9, x2
    cf24:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cf28:	cb070063 	sub	x3, x3, x7
    cf2c:	eb090000 	subs	x0, x0, x9
    cf30:	da030021 	sbc	x1, x1, x3
    cf34:	9ac62400 	lsr	x0, x0, x6
    cf38:	9ac82028 	lsl	x8, x1, x8
    cf3c:	aa000100 	orr	x0, x8, x0
    cf40:	9ac62421 	lsr	x1, x1, x6
    cf44:	17ffffb4 	b	ce14 <__modti3+0xb4>
    cf48:	b5000062 	cbnz	x2, cf54 <__modti3+0x1f4>
    cf4c:	d2800023 	mov	x3, #0x1                   	// #1
    cf50:	9ac20862 	udiv	x2, x3, x2
    cf54:	dac01048 	clz	x8, x2
    cf58:	aa0803e5 	mov	x5, x8
    cf5c:	b5000668 	cbnz	x8, d028 <__modti3+0x2c8>
    cf60:	cb020020 	sub	x0, x1, x2
    cf64:	d360fc49 	lsr	x9, x2, #32
    cf68:	92407c4a 	and	x10, x2, #0xffffffff
    cf6c:	9ac90801 	udiv	x1, x0, x9
    cf70:	9b098020 	msub	x0, x1, x9, x0
    cf74:	9b0a7c21 	mul	x1, x1, x10
    cf78:	93c78000 	extr	x0, x0, x7, #32
    cf7c:	eb00003f 	cmp	x1, x0
    cf80:	540000a9 	b.ls	cf94 <__modti3+0x234>  // b.plast
    cf84:	ab000040 	adds	x0, x2, x0
    cf88:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf8c:	8b020003 	add	x3, x0, x2
    cf90:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf94:	cb010001 	sub	x1, x0, x1
    cf98:	9ac90820 	udiv	x0, x1, x9
    cf9c:	9b098403 	msub	x3, x0, x9, x1
    cfa0:	aa0703e1 	mov	x1, x7
    cfa4:	9b0a7c00 	mul	x0, x0, x10
    cfa8:	b3607c61 	bfi	x1, x3, #32, #32
    cfac:	eb01001f 	cmp	x0, x1
    cfb0:	540000a9 	b.ls	cfc4 <__modti3+0x264>  // b.plast
    cfb4:	ab010041 	adds	x1, x2, x1
    cfb8:	8b020022 	add	x2, x1, x2
    cfbc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cfc0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cfc4:	cb000020 	sub	x0, x1, x0
    cfc8:	17ffff91 	b	ce0c <__modti3+0xac>
    cfcc:	eb0203e5 	negs	x5, x2
    cfd0:	aa0003e7 	mov	x7, x0
    cfd4:	da0303e8 	ngc	x8, x3
    cfd8:	aa0503e2 	mov	x2, x5
    cfdc:	aa0803e3 	mov	x3, x8
    cfe0:	aa0103e6 	mov	x6, x1
    cfe4:	b4ffed48 	cbz	x8, cd8c <__modti3+0x2c>
    cfe8:	eb01011f 	cmp	x8, x1
    cfec:	54fff148 	b.hi	ce14 <__modti3+0xb4>  // b.pmore
    cff0:	dac01109 	clz	x9, x8
    cff4:	2a0903e6 	mov	w6, w9
    cff8:	b5fff1c9 	cbnz	x9, ce30 <__modti3+0xd0>
    cffc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d000:	54000068 	b.hi	d00c <__modti3+0x2ac>  // b.pmore
    d004:	eb050007 	subs	x7, x0, x5
    d008:	da080021 	sbc	x1, x1, x8
    d00c:	aa0703e0 	mov	x0, x7
    d010:	17ffff81 	b	ce14 <__modti3+0xb4>
    d014:	ab000040 	adds	x0, x2, x0
    d018:	8b020002 	add	x2, x0, x2
    d01c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d020:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d024:	17ffff79 	b	ce08 <__modti3+0xa8>
    d028:	9ac82042 	lsl	x2, x2, x8
    d02c:	d2800803 	mov	x3, #0x40                  	// #64
    d030:	cb080063 	sub	x3, x3, x8
    d034:	d360fc49 	lsr	x9, x2, #32
    d038:	9ac82027 	lsl	x7, x1, x8
    d03c:	92407c4a 	and	x10, x2, #0xffffffff
    d040:	9ac32426 	lsr	x6, x1, x3
    d044:	9ac32403 	lsr	x3, x0, x3
    d048:	aa070063 	orr	x3, x3, x7
    d04c:	9ac908c1 	udiv	x1, x6, x9
    d050:	9ac82007 	lsl	x7, x0, x8
    d054:	9b099820 	msub	x0, x1, x9, x6
    d058:	9b017d41 	mul	x1, x10, x1
    d05c:	93c38000 	extr	x0, x0, x3, #32
    d060:	eb00003f 	cmp	x1, x0
    d064:	540000a9 	b.ls	d078 <__modti3+0x318>  // b.plast
    d068:	ab000040 	adds	x0, x2, x0
    d06c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d070:	8b020006 	add	x6, x0, x2
    d074:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d078:	cb010000 	sub	x0, x0, x1
    d07c:	9ac90801 	udiv	x1, x0, x9
    d080:	9b098026 	msub	x6, x1, x9, x0
    d084:	aa0303e0 	mov	x0, x3
    d088:	9b017d41 	mul	x1, x10, x1
    d08c:	b3607cc0 	bfi	x0, x6, #32, #32
    d090:	eb00003f 	cmp	x1, x0
    d094:	540000a9 	b.ls	d0a8 <__modti3+0x348>  // b.plast
    d098:	ab000040 	adds	x0, x2, x0
    d09c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d0a0:	8b020003 	add	x3, x0, x2
    d0a4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d0a8:	cb010000 	sub	x0, x0, x1
    d0ac:	17ffffb0 	b	cf6c <__modti3+0x20c>
    d0b0:	d1000969 	sub	x9, x11, #0x2
    d0b4:	8b070021 	add	x1, x1, x7
    d0b8:	17ffff83 	b	cec4 <__modti3+0x164>
    d0bc:	d1000965 	sub	x5, x11, #0x2
    d0c0:	8b070063 	add	x3, x3, x7
    d0c4:	17ffff74 	b	ce94 <__modti3+0x134>
    d0c8:	d503201f 	nop
    d0cc:	d503201f 	nop

000000000000d0d0 <atexit>:
    d0d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d0d4:	f0000082 	adrp	x2, 20000 <__data_start>
    d0d8:	d2800001 	mov	x1, #0x0                   	// #0
    d0dc:	910003fd 	mov	x29, sp
    d0e0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d0e4:	f9400442 	ldr	x2, [x2, #8]
    d0e8:	17ffd5a6 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d0ec <_fini>:
    d0ec:	d503201f 	nop
    d0f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d0f4:	910003fd 	mov	x29, sp
    d0f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d0fc:	d65f03c0 	ret
