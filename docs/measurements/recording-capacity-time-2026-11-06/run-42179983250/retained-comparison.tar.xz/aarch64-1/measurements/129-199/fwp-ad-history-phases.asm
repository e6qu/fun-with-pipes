
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x120>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913b00a5 	add	x5, x5, #0xec0
    2aa0:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x120>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	913b2084 	add	x4, x4, #0xec8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000590 	bl	4110 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe1d8>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9006420 	str	x0, [x1, #200]
    2b2c:	94000799 	bl	4990 <fwp_now_ns>
    2b30:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2b34:	91076000 	add	x0, x0, #0x1d8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x17b0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	913b8042 	add	x2, x2, #0xee0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435aa0 	ldr	w0, [x21, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2c4c:	91082000 	add	x0, x0, #0x208
    2c50:	94000530 	bl	4110 <fwp_trap>
    2c54:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2c58:	9107a000 	add	x0, x0, #0x1e8
    2c5c:	9400052d 	bl	4110 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2ca0:	91098000 	add	x0, x0, #0x260
    2ca4:	9400051b 	bl	4110 <fwp_trap>
    2ca8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2cac:	9108c000 	add	x0, x0, #0x230
    2cb0:	94000518 	bl	4110 <fwp_trap>
    2cb4:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    2cb8:	910a2000 	add	x0, x0, #0x288
    2cbc:	94000515 	bl	4110 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    2eb4:	9123c021 	add	x1, x1, #0x8f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3050:	912d2000 	add	x0, x0, #0xb48
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    3118:	91234021 	add	x1, x1, #0x8d0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3150:	912d8000 	add	x0, x0, #0xb60
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x120>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <fwp_main_thread+0x120>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	f0000058 	adrp	x24, e000 <_IO_stdin_used+0x4c0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	912ea042 	add	x2, x2, #0xba8
    31e0:	913002d6 	add	x22, x22, #0xc00
    31e4:	91196318 	add	x24, x24, #0x658
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x120>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	912fe323 	add	x3, x25, #0xbf8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91304000 	add	x0, x0, #0xc10
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3570:	912d2000 	add	x0, x0, #0xb48
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x120>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91306021 	add	x1, x1, #0xc18
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x120>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91308021 	add	x1, x1, #0xc20
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x120>
    37e0:	9130a021 	add	x1, x1, #0xc28
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x120>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	9130c084 	add	x4, x4, #0xc30
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe3 	bl	27f0 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc3c 	bl	2960 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc27 	bl	2920 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb70 	bl	26d0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffba8 	bl	27d0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb99 	bl	27d0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb51 	bl	26d0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb5d 	bl	2710 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbed 	bl	2960 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x120>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	91312084 	add	x4, x4, #0xc48
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb6e 	bl	27f0 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb5d 	bl	27d0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbbd 	bl	2960 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x120>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	9130e084 	add	x4, x4, #0xc38
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb46 	bl	27f0 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb30 	bl	27d0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb04 	bl	27d0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb20 	bl	2880 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c0c:	91174042 	add	x2, x2, #0x5d0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x120>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91314021 	add	x1, x1, #0xc50
    3c68:	91316000 	add	x0, x0, #0xc58
    3c6c:	97fffae9 	bl	2810 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb13 	bl	2920 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac3 	bl	2800 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x120>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9131e042 	add	x2, x2, #0xc78
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffae6 	b	28f0 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffac6 	bl	2880 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3d78:	91134061 	add	x1, x3, #0x4d0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3d88:	91174262 	add	x2, x19, #0x5d0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x4c0>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3dbc:	91144021 	add	x1, x1, #0x510
    3dc0:	3dc24043 	ldr	q3, [x2, #2304]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3dec:	91134063 	add	x3, x3, #0x4d0
    3df0:	9115c084 	add	x4, x4, #0x570
    3df4:	91174266 	add	x6, x19, #0x5d0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaa9 	bl	2910 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91174275 	add	x21, x19, #0x5d0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa93 	bl	2910 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    3ed8:	91340000 	add	x0, x0, #0xd00
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffacc 	bl	2a10 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91174273 	add	x19, x19, #0x5d0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9401400 	ldr	x0, [x0, #40]
    4004:	b7f80760 	tbnz	x0, #63, 40f0 <fwp_tape_buffers_release+0x100>
    4008:	f9401a61 	ldr	x1, [x19, #48]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    403c:	91344000 	add	x0, x0, #0xd10
    4040:	97fffa74 	bl	2a10 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	91344000 	add	x0, x0, #0xd10
    4078:	97fffa66 	bl	2a10 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400a61 	ldp	q1, q2, [x19]
    40b8:	f90062d4 	str	x20, [x22, #192]
    40bc:	4f000400 	movi	v0.4s, #0x0
    40c0:	ad000aa1 	stp	q1, q2, [x21]
    40c4:	3dc00a61 	ldr	q1, [x19, #32]
    40c8:	3d800aa1 	str	q1, [x21, #32]
    40cc:	f9401a60 	ldr	x0, [x19, #48]
    40d0:	f9001aa0 	str	x0, [x21, #48]
    40d4:	f9001a7f 	str	xzr, [x19, #48]
    40d8:	ad000260 	stp	q0, q0, [x19]
    40dc:	3d800a60 	str	q0, [x19, #32]
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40ec:	d65f03c0 	ret
    40f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    40f4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f8:	91344000 	add	x0, x0, #0xd10
    40fc:	97fffa45 	bl	2a10 <getenv@plt>
    4100:	b5fffa40 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    4104:	17ffffd6 	b	405c <fwp_tape_buffers_release+0x6c>
    4108:	d503201f 	nop
    410c:	d503201f 	nop

0000000000004110 <fwp_trap>:
    4110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4114:	900000e2 	adrp	x2, 20000 <__data_start>
    4118:	d53bd041 	mrs	x1, tpidr_el0
    411c:	910003fd 	mov	x29, sp
    4120:	f9403c42 	ldr	x2, [x2, #120]
    4124:	91400021 	add	x1, x1, #0x0, lsl #12
    4128:	91004021 	add	x1, x1, #0x10
    412c:	a90153f3 	stp	x19, x20, [sp, #16]
    4130:	aa0003f3 	mov	x19, x0
    4134:	f9400034 	ldr	x20, [x1]
    4138:	b4000062 	cbz	x2, 4144 <fwp_trap+0x34>
    413c:	aa0203e0 	mov	x0, x2
    4140:	97fffa1c 	bl	29b0 <fflush@plt>
    4144:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4148:	f947ec00 	ldr	x0, [x0, #4056]
    414c:	f9400000 	ldr	x0, [x0]
    4150:	97fffa18 	bl	29b0 <fflush@plt>
    4154:	aa1303e3 	mov	x3, x19
    4158:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x120>
    415c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    4160:	f947ea73 	ldr	x19, [x19, #4048]
    4164:	9134a042 	add	x2, x2, #0xd28
    4168:	52800041 	mov	w1, #0x2                   	// #2
    416c:	f9400260 	ldr	x0, [x19]
    4170:	97fff9e0 	bl	28f0 <__fprintf_chk@plt>
    4174:	b40000b4 	cbz	x20, 4188 <fwp_trap+0x78>
    4178:	f9400260 	ldr	x0, [x19]
    417c:	97fffa0d 	bl	29b0 <fflush@plt>
    4180:	52800ca0 	mov	w0, #0x65                  	// #101
    4184:	97fffa1b 	bl	29f0 <_Exit@plt>
    4188:	52800ca0 	mov	w0, #0x65                  	// #101
    418c:	97fff969 	bl	2730 <exit@plt>

0000000000004190 <fwp_rc_forget_slot.part.0>:
    4190:	ca404401 	eor	x1, x0, x0, lsr #17
    4194:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4198:	ca412421 	eor	x1, x1, x1, lsr #9
    419c:	910003fd 	mov	x29, sp
    41a0:	92401c21 	and	x1, x1, #0xff
    41a4:	f9000bf3 	str	x19, [sp, #16]
    41a8:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    41ac:	91174262 	add	x2, x19, #0x5d0
    41b0:	910a2423 	add	x3, x1, #0x289
    41b4:	8b010c41 	add	x1, x2, x1, lsl #3
    41b8:	8b030c43 	add	x3, x2, x3, lsl #3
    41bc:	f94a2421 	ldr	x1, [x1, #5192]
    41c0:	b50000a1 	cbnz	x1, 41d4 <fwp_rc_forget_slot.part.0+0x44>
    41c4:	14000012 	b	420c <fwp_rc_forget_slot.part.0+0x7c>
    41c8:	91004023 	add	x3, x1, #0x10
    41cc:	f9400821 	ldr	x1, [x1, #16]
    41d0:	b40001e1 	cbz	x1, 420c <fwp_rc_forget_slot.part.0+0x7c>
    41d4:	f9400022 	ldr	x2, [x1]
    41d8:	eb02001f 	cmp	x0, x2
    41dc:	54ffff61 	b.ne	41c8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41e0:	f9400060 	ldr	x0, [x3]
    41e4:	91174273 	add	x19, x19, #0x5d0
    41e8:	f9400801 	ldr	x1, [x0, #16]
    41ec:	f9000061 	str	x1, [x3]
    41f0:	97fff9d4 	bl	2940 <free@plt>
    41f4:	f94e2660 	ldr	x0, [x19, #7240]
    41f8:	d1000400 	sub	x0, x0, #0x1
    41fc:	f90e2660 	str	x0, [x19, #7240]
    4200:	f9400bf3 	ldr	x19, [sp, #16]
    4204:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4208:	d65f03c0 	ret
    420c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4210:	9134e000 	add	x0, x0, #0xd38
    4214:	97ffffbf 	bl	4110 <fwp_trap>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_rc_prepare_chunk>:
    4220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4224:	910003fd 	mov	x29, sp
    4228:	a9025bf5 	stp	x21, x22, [sp, #32]
    422c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4230:	911742c2 	add	x2, x22, #0x5d0
    4234:	b9401c03 	ldr	w3, [x0, #28]
    4238:	aa0103f5 	mov	x21, x1
    423c:	a90153f3 	stp	x19, x20, [sp, #16]
    4240:	aa0003f4 	mov	x20, x0
    4244:	f94e2440 	ldr	x0, [x2, #7240]
    4248:	b4000440 	cbz	x0, 42d0 <fwp_rc_prepare_chunk+0xb0>
    424c:	d2800013 	mov	x19, #0x0                   	// #0
    4250:	35000203 	cbnz	w3, 4290 <fwp_rc_prepare_chunk+0x70>
    4254:	b4000361 	cbz	x1, 42c0 <fwp_rc_prepare_chunk+0xa0>
    4258:	f9401280 	ldr	x0, [x20, #32]
    425c:	97fff9b9 	bl	2940 <free@plt>
    4260:	aa1503e0 	mov	x0, x21
    4264:	d2800021 	mov	x1, #0x1                   	// #1
    4268:	97fff97e 	bl	2860 <calloc@plt>
    426c:	f9001280 	str	x0, [x20, #32]
    4270:	b5000460 	cbnz	x0, 42fc <fwp_rc_prepare_chunk+0xdc>
    4274:	97fffb6f 	bl	3030 <fwp_heap_oom>
    4278:	97ffffc6 	bl	4190 <fwp_rc_forget_slot.part.0>
    427c:	91000673 	add	x19, x19, #0x1
    4280:	b9401e83 	ldr	w3, [x20, #28]
    4284:	eb13007f 	cmp	x3, x19
    4288:	54000169 	b.ls	42b4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    428c:	d503201f 	nop
    4290:	f9401283 	ldr	x3, [x20, #32]
    4294:	8b130060 	add	x0, x3, x19
    4298:	38736863 	ldrb	w3, [x3, x19]
    429c:	7103fc7f 	cmp	w3, #0xff
    42a0:	54fffec0 	b.eq	4278 <fwp_rc_prepare_chunk+0x58>  // b.none
    42a4:	b9401e83 	ldr	w3, [x20, #28]
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb13007f 	cmp	x3, x19
    42b0:	54ffff08 	b.hi	4290 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42b4:	eb0302bf 	cmp	x21, x3
    42b8:	54000121 	b.ne	42dc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42bc:	b5000335 	cbnz	x21, 4320 <fwp_rc_prepare_chunk+0x100>
    42c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42cc:	d65f03c0 	ret
    42d0:	2a0303e3 	mov	w3, w3
    42d4:	eb0302bf 	cmp	x21, x3
    42d8:	54ffff20 	b.eq	42bc <fwp_rc_prepare_chunk+0x9c>  // b.none
    42dc:	911742c2 	add	x2, x22, #0x5d0
    42e0:	f9401280 	ldr	x0, [x20, #32]
    42e4:	f94e2841 	ldr	x1, [x2, #7248]
    42e8:	cb030021 	sub	x1, x1, x3
    42ec:	f90e2841 	str	x1, [x2, #7248]
    42f0:	97fff994 	bl	2940 <free@plt>
    42f4:	b5fffb75 	cbnz	x21, 4260 <fwp_rc_prepare_chunk+0x40>
    42f8:	f900129f 	str	xzr, [x20, #32]
    42fc:	911742d6 	add	x22, x22, #0x5d0
    4300:	f94e2ac0 	ldr	x0, [x22, #7248]
    4304:	b9001e95 	str	w21, [x20, #28]
    4308:	a94153f3 	ldp	x19, x20, [sp, #16]
    430c:	8b150000 	add	x0, x0, x21
    4310:	f90e2ac0 	str	x0, [x22, #7248]
    4314:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4318:	a8c37bfd 	ldp	x29, x30, [sp], #48
    431c:	d65f03c0 	ret
    4320:	f9401280 	ldr	x0, [x20, #32]
    4324:	aa1503e2 	mov	x2, x21
    4328:	a94153f3 	ldp	x19, x20, [sp, #16]
    432c:	52800001 	mov	w1, #0x0                   	// #0
    4330:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4334:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4338:	17fff946 	b	2850 <memset@plt>
    433c:	d503201f 	nop

0000000000004340 <fwp_heap_refill>:
    4340:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4344:	910003fd 	mov	x29, sp
    4348:	a9025bf5 	stp	x21, x22, [sp, #32]
    434c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4350:	911742b5 	add	x21, x21, #0x5d0
    4354:	aa0003f6 	mov	x22, x0
    4358:	d2800020 	mov	x0, #0x1                   	// #1
    435c:	a90153f3 	stp	x19, x20, [sp, #16]
    4360:	a90363f7 	stp	x23, x24, [sp, #48]
    4364:	2a0103f7 	mov	w23, w1
    4368:	2a0203f8 	mov	w24, w2
    436c:	97fffbd1 	bl	32b0 <fwp_heap_chunks>
    4370:	aa0003f3 	mov	x19, x0
    4374:	f949fea2 	ldr	x2, [x21, #5112]
    4378:	8b000800 	add	x0, x0, x0, lsl #2
    437c:	2a1703e1 	mov	w1, w23
    4380:	52800025 	mov	w5, #0x1                   	// #1
    4384:	d37df000 	lsl	x0, x0, #3
    4388:	910f0021 	add	x1, x1, #0x3c0
    438c:	8b000054 	add	x20, x2, x0
    4390:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4394:	52a00024 	mov	w4, #0x10000               	// #65536
    4398:	38206845 	strb	w5, [x2, x0]
    439c:	aa1403e0 	mov	x0, x20
    43a0:	39000698 	strb	w24, [x20, #1]
    43a4:	39000a97 	strb	w23, [x20, #2]
    43a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    43ac:	b9000681 	str	w1, [x20, #4]
    43b0:	2a0103e5 	mov	w5, w1
    43b4:	8b0300a2 	add	x2, x5, x3
    43b8:	1ac10881 	udiv	w1, w4, w1
    43bc:	9ac50842 	udiv	x2, x2, x5
    43c0:	b9000a81 	str	w1, [x20, #8]
    43c4:	92404021 	and	x1, x1, #0x1ffff
    43c8:	b9001a82 	str	w2, [x20, #24]
    43cc:	97ffff95 	bl	4220 <fwp_rc_prepare_chunk>
    43d0:	f949daa0 	ldr	x0, [x21, #5040]
    43d4:	29408a81 	ldp	w1, w2, [x20, #4]
    43d8:	8b134000 	add	x0, x0, x19, lsl #16
    43dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e0:	8b214003 	add	x3, x0, w1, uxtw
    43e4:	9ba20021 	umaddl	x1, w1, w2, x0
    43e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43ec:	a90086c3 	stp	x3, x1, [x22, #8]
    43f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43f8:	d65f03c0 	ret
    43fc:	d503201f 	nop

0000000000004400 <fwp_mem_free>:
    4400:	b40003c0 	cbz	x0, 4478 <fwp_mem_free+0x78>
    4404:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4408:	910003fd 	mov	x29, sp
    440c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4410:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4414:	911742a1 	add	x1, x21, #0x5d0
    4418:	a90153f3 	stp	x19, x20, [sp, #16]
    441c:	aa0003f3 	mov	x19, x0
    4420:	f949d823 	ldr	x3, [x1, #5040]
    4424:	f949ec22 	ldr	x2, [x1, #5080]
    4428:	cb030000 	sub	x0, x0, x3
    442c:	eb02401f 	cmp	x0, x2, lsl #16
    4430:	540001c2 	b.cs	4468 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4434:	d350fc16 	lsr	x22, x0, #16
    4438:	a90363f7 	stp	x23, x24, [sp, #48]
    443c:	f949fc22 	ldr	x2, [x1, #5112]
    4440:	8b160ad4 	add	x20, x22, x22, lsl #2
    4444:	d37df294 	lsl	x20, x20, #3
    4448:	ab140057 	adds	x23, x2, x20
    444c:	540000c0 	b.eq	4464 <fwp_mem_free+0x64>  // b.none
    4450:	38746842 	ldrb	w2, [x2, x20]
    4454:	7100045f 	cmp	w2, #0x1
    4458:	54000120 	b.eq	447c <fwp_mem_free+0x7c>  // b.none
    445c:	7100085f 	cmp	w2, #0x2
    4460:	540005e0 	b.eq	451c <fwp_mem_free+0x11c>  // b.none
    4464:	a94363f7 	ldp	x23, x24, [sp, #48]
    4468:	a94153f3 	ldp	x19, x20, [sp, #16]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4474:	d65f03c0 	ret
    4478:	d65f03c0 	ret
    447c:	f94012f8 	ldr	x24, [x23, #32]
    4480:	b94006e1 	ldr	w1, [x23, #4]
    4484:	f90023f9 	str	x25, [sp, #64]
    4488:	2a0103e2 	mov	w2, w1
    448c:	394006f9 	ldrb	w25, [x23, #1]
    4490:	39400af4 	ldrb	w20, [x23, #2]
    4494:	b4000158 	cbz	x24, 44bc <fwp_mem_free+0xbc>
    4498:	92403e76 	and	x22, x19, #0xffff
    449c:	9ac20ad6 	udiv	x22, x22, x2
    44a0:	38766b01 	ldrb	w1, [x24, x22]
    44a4:	8b160300 	add	x0, x24, x22
    44a8:	7103fc3f 	cmp	w1, #0xff
    44ac:	54000980 	b.eq	45dc <fwp_mem_free+0x1dc>  // b.none
    44b0:	38366b1f 	strb	wzr, [x24, x22]
    44b4:	b94006e1 	ldr	w1, [x23, #4]
    44b8:	2a0103e2 	mov	w2, w1
    44bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44c4:	cb390000 	sub	x0, x0, w25, uxtb
    44c8:	8b340074 	add	x20, x3, w20, uxtb
    44cc:	911742b5 	add	x21, x21, #0x5d0
    44d0:	1e630021 	ucvtf	d1, w1
    44d4:	d37ae400 	lsl	x0, x0, #6
    44d8:	8b140c14 	add	x20, x0, x20, lsl #3
    44dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e0:	f8746aa0 	ldr	x0, [x21, x20]
    44e4:	f94023f9 	ldr	x25, [sp, #64]
    44e8:	aa2003e0 	mvn	x0, x0
    44ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    44f0:	f9000260 	str	x0, [x19]
    44f4:	f8346ab3 	str	x19, [x21, x20]
    44f8:	f94a12a0 	ldr	x0, [x21, #5152]
    44fc:	1e612800 	fadd	d0, d0, d1
    4500:	a94153f3 	ldp	x19, x20, [sp, #16]
    4504:	cb020000 	sub	x0, x0, x2
    4508:	f90a12a0 	str	x0, [x21, #5152]
    450c:	fd0a22a0 	str	d0, [x21, #5184]
    4510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4514:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4518:	d65f03c0 	ret
    451c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4520:	8b000063 	add	x3, x3, x0
    4524:	eb03027f 	cmp	x19, x3
    4528:	54fff9e1 	b.ne	4464 <fwp_mem_free+0x64>  // b.any
    452c:	fd400ae1 	ldr	d1, [x23, #16]
    4530:	fd4a2020 	ldr	d0, [x1, #5184]
    4534:	f9400ae0 	ldr	x0, [x23, #16]
    4538:	7e61d821 	ucvtf	d1, d1
    453c:	f94a1022 	ldr	x2, [x1, #5152]
    4540:	f94012f3 	ldr	x19, [x23, #32]
    4544:	1e612800 	fadd	d0, d0, d1
    4548:	cb000042 	sub	x2, x2, x0
    454c:	f90a1022 	str	x2, [x1, #5152]
    4550:	fd0a2020 	str	d0, [x1, #5184]
    4554:	b40000b3 	cbz	x19, 4568 <fwp_mem_free+0x168>
    4558:	39400260 	ldrb	w0, [x19]
    455c:	7103fc1f 	cmp	w0, #0xff
    4560:	54000380 	b.eq	45d0 <fwp_mem_free+0x1d0>  // b.none
    4564:	3900027f 	strb	wzr, [x19]
    4568:	b9400ee2 	ldr	w2, [x23, #12]
    456c:	b4000142 	cbz	x2, 4594 <fwp_mem_free+0x194>
    4570:	911742a1 	add	x1, x21, #0x5d0
    4574:	8b160040 	add	x0, x2, x22
    4578:	8b000800 	add	x0, x0, x0, lsl #2
    457c:	f949fc21 	ldr	x1, [x1, #5112]
    4580:	8b140034 	add	x20, x1, x20
    4584:	8b000c20 	add	x0, x1, x0, lsl #3
    4588:	3802869f 	strb	wzr, [x20], #40
    458c:	eb00029f 	cmp	x20, x0
    4590:	54ffffc1 	b.ne	4588 <fwp_mem_free+0x188>  // b.any
    4594:	911742a0 	add	x0, x21, #0x5d0
    4598:	f94a1801 	ldr	x1, [x0, #5168]
    459c:	f949f803 	ldr	x3, [x0, #5104]
    45a0:	8b020021 	add	x1, x1, x2
    45a4:	f90a1801 	str	x1, [x0, #5168]
    45a8:	eb16007f 	cmp	x3, x22
    45ac:	54000049 	b.ls	45b4 <fwp_mem_free+0x1b4>  // b.plast
    45b0:	f909f816 	str	x22, [x0, #5104]
    45b4:	911742b5 	add	x21, x21, #0x5d0
    45b8:	f949f6a0 	ldr	x0, [x21, #5096]
    45bc:	eb16001f 	cmp	x0, x22
    45c0:	54fff529 	b.ls	4464 <fwp_mem_free+0x64>  // b.plast
    45c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45c8:	f909f6b6 	str	x22, [x21, #5096]
    45cc:	17ffffa7 	b	4468 <fwp_mem_free+0x68>
    45d0:	aa1303e0 	mov	x0, x19
    45d4:	97fffeef 	bl	4190 <fwp_rc_forget_slot.part.0>
    45d8:	17ffffe3 	b	4564 <fwp_mem_free+0x164>
    45dc:	97fffeed 	bl	4190 <fwp_rc_forget_slot.part.0>
    45e0:	17ffffb4 	b	44b0 <fwp_mem_free+0xb0>

00000000000045e4 <fwp_rc_wide_dup>:
    45e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e8:	910003fd 	mov	x29, sp
    45ec:	a90153f3 	stp	x19, x20, [sp, #16]
    45f0:	aa0003f3 	mov	x19, x0
    45f4:	ca404400 	eor	x0, x0, x0, lsr #17
    45f8:	f90013f5 	str	x21, [sp, #32]
    45fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4600:	ca402400 	eor	x0, x0, x0, lsr #9
    4604:	911742a2 	add	x2, x21, #0x5d0
    4608:	92401c00 	and	x0, x0, #0xff
    460c:	910a2403 	add	x3, x0, #0x289
    4610:	8b000c40 	add	x0, x2, x0, lsl #3
    4614:	8b030c54 	add	x20, x2, x3, lsl #3
    4618:	f94a2401 	ldr	x1, [x0, #5192]
    461c:	b50000a1 	cbnz	x1, 4630 <fwp_rc_wide_dup+0x4c>
    4620:	14000033 	b	46ec <fwp_rc_wide_dup+0x108>
    4624:	91004034 	add	x20, x1, #0x10
    4628:	f9400821 	ldr	x1, [x1, #16]
    462c:	b4000241 	cbz	x1, 4674 <fwp_rc_wide_dup+0x90>
    4630:	f9400022 	ldr	x2, [x1]
    4634:	eb02027f 	cmp	x19, x2
    4638:	54ffff61 	b.ne	4624 <fwp_rc_wide_dup+0x40>  // b.any
    463c:	f9400281 	ldr	x1, [x20]
    4640:	39400260 	ldrb	w0, [x19]
    4644:	7103f81f 	cmp	w0, #0xfe
    4648:	54000220 	b.eq	468c <fwp_rc_wide_dup+0xa8>  // b.none
    464c:	b40001a1 	cbz	x1, 4680 <fwp_rc_wide_dup+0x9c>
    4650:	f9400420 	ldr	x0, [x1, #8]
    4654:	b100041f 	cmn	x0, #0x1
    4658:	54000440 	b.eq	46e0 <fwp_rc_wide_dup+0xfc>  // b.none
    465c:	91000400 	add	x0, x0, #0x1
    4660:	f9000420 	str	x0, [x1, #8]
    4664:	a94153f3 	ldp	x19, x20, [sp, #16]
    4668:	f94013f5 	ldr	x21, [sp, #32]
    466c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4670:	d65f03c0 	ret
    4674:	39400260 	ldrb	w0, [x19]
    4678:	7103f81f 	cmp	w0, #0xfe
    467c:	54000100 	b.eq	469c <fwp_rc_wide_dup+0xb8>  // b.none
    4680:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4684:	9134e000 	add	x0, x0, #0xd38
    4688:	97fffea2 	bl	4110 <fwp_trap>
    468c:	b4000081 	cbz	x1, 469c <fwp_rc_wide_dup+0xb8>
    4690:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4694:	91358000 	add	x0, x0, #0xd60
    4698:	97fffe9e 	bl	4110 <fwp_trap>
    469c:	d2800300 	mov	x0, #0x18                  	// #24
    46a0:	97fff860 	bl	2820 <malloc@plt>
    46a4:	b4000280 	cbz	x0, 46f4 <fwp_rc_wide_dup+0x110>
    46a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    46ac:	a9000413 	stp	x19, x1, [x0]
    46b0:	911742b5 	add	x21, x21, #0x5d0
    46b4:	f900081f 	str	xzr, [x0, #16]
    46b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46bc:	f9000280 	str	x0, [x20]
    46c0:	39000261 	strb	w1, [x19]
    46c4:	f94e26a0 	ldr	x0, [x21, #7240]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	91000400 	add	x0, x0, #0x1
    46d0:	f90e26a0 	str	x0, [x21, #7240]
    46d4:	f94013f5 	ldr	x21, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    46e4:	91362000 	add	x0, x0, #0xd88
    46e8:	97fffe8a 	bl	4110 <fwp_trap>
    46ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46f0:	17ffffd4 	b	4640 <fwp_rc_wide_dup+0x5c>
    46f4:	97fffa4f 	bl	3030 <fwp_heap_oom>
    46f8:	d503201f 	nop
    46fc:	d503201f 	nop

0000000000004700 <fwp_closure_drop_push>:
    4700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4704:	910003fd 	mov	x29, sp
    4708:	a90153f3 	stp	x19, x20, [sp, #16]
    470c:	aa0003f3 	mov	x19, x0
    4710:	a9408014 	ldp	x20, x0, [x0, #8]
    4714:	a9025bf5 	stp	x21, x22, [sp, #32]
    4718:	aa0103f5 	mov	x21, x1
    471c:	a90363f7 	stp	x23, x24, [sp, #48]
    4720:	eb00029f 	cmp	x20, x0
    4724:	54000160 	b.eq	4750 <fwp_closure_drop_push+0x50>  // b.none
    4728:	f9400276 	ldr	x22, [x19]
    472c:	d37df297 	lsl	x23, x20, #3
    4730:	91000694 	add	x20, x20, #0x1
    4734:	f9000674 	str	x20, [x19, #8]
    4738:	a94153f3 	ldp	x19, x20, [sp, #16]
    473c:	f8376ad5 	str	x21, [x22, x23]
    4740:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4744:	a94363f7 	ldp	x23, x24, [sp, #48]
    4748:	a8c57bfd 	ldp	x29, x30, [sp], #80
    474c:	d65f03c0 	ret
    4750:	a9046bf9 	stp	x25, x26, [sp, #64]
    4754:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4758:	eb00029f 	cmp	x20, x0
    475c:	540003e8 	b.hi	47d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4760:	d37cee99 	lsl	x25, x20, #4
    4764:	d37ffa9a 	lsl	x26, x20, #1
    4768:	aa1903e0 	mov	x0, x25
    476c:	97fff82d 	bl	2820 <malloc@plt>
    4770:	aa0003f6 	mov	x22, x0
    4774:	b4000380 	cbz	x0, 47e4 <fwp_closure_drop_push+0xe4>
    4778:	aa1303f8 	mov	x24, x19
    477c:	aa1903e3 	mov	x3, x25
    4780:	d37df297 	lsl	x23, x20, #3
    4784:	aa1703e2 	mov	x2, x23
    4788:	f8418719 	ldr	x25, [x24], #24
    478c:	aa1903e1 	mov	x1, x25
    4790:	97fff810 	bl	27d0 <__memcpy_chk@plt>
    4794:	eb18033f 	cmp	x25, x24
    4798:	540000a0 	b.eq	47ac <fwp_closure_drop_push+0xac>  // b.none
    479c:	aa1903e0 	mov	x0, x25
    47a0:	97fff868 	bl	2940 <free@plt>
    47a4:	f9400674 	ldr	x20, [x19, #8]
    47a8:	d37df297 	lsl	x23, x20, #3
    47ac:	91000694 	add	x20, x20, #0x1
    47b0:	f9000276 	str	x22, [x19]
    47b4:	f9000a7a 	str	x26, [x19, #16]
    47b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47bc:	f9000674 	str	x20, [x19, #8]
    47c0:	f8376ad5 	str	x21, [x22, x23]
    47c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47d4:	d65f03c0 	ret
    47d8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    47dc:	9136a000 	add	x0, x0, #0xda8
    47e0:	97fffe4c 	bl	4110 <fwp_trap>
    47e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    47e8:	f947e863 	ldr	x3, [x3, #4048]
    47ec:	d2800262 	mov	x2, #0x13                  	// #19
    47f0:	d2800021 	mov	x1, #0x1                   	// #1
    47f4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    47f8:	912d2000 	add	x0, x0, #0xb48
    47fc:	f9400063 	ldr	x3, [x3]
    4800:	97fff860 	bl	2980 <fwrite@plt>
    4804:	d2800000 	mov	x0, #0x0                   	// #0
    4808:	97fff86a 	bl	29b0 <fflush@plt>
    480c:	52800cc0 	mov	w0, #0x66                  	// #102
    4810:	97fff878 	bl	29f0 <_Exit@plt>

0000000000004814 <fwp_closure_drop.part.0>:
    4814:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4818:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    481c:	910003fd 	mov	x29, sp
    4820:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4824:	f947f463 	ldr	x3, [x3, #4072]
    4828:	a90153f3 	stp	x19, x20, [sp, #16]
    482c:	d10883ff 	sub	sp, sp, #0x220
    4830:	910003e2 	mov	x2, sp
    4834:	d53bd053 	mrs	x19, tpidr_el0
    4838:	910063f4 	add	x20, sp, #0x18
    483c:	3dc24420 	ldr	q0, [x1, #2320]
    4840:	91400264 	add	x4, x19, #0x0, lsl #12
    4844:	91004084 	add	x4, x4, #0x10
    4848:	aa0003e1 	mov	x1, x0
    484c:	aa0203e0 	mov	x0, x2
    4850:	f9400062 	ldr	x2, [x3]
    4854:	f9010fe2 	str	x2, [sp, #536]
    4858:	d2800002 	mov	x2, #0x0                   	// #0
    485c:	f90003f4 	str	x20, [sp]
    4860:	f9000080 	str	x0, [x4]
    4864:	3c8083e0 	stur	q0, [sp, #8]
    4868:	97ffffa6 	bl	4700 <fwp_closure_drop_push>
    486c:	f94007e0 	ldr	x0, [sp, #8]
    4870:	b40002e0 	cbz	x0, 48cc <fwp_closure_drop.part.0+0xb8>
    4874:	f90123f5 	str	x21, [sp, #576]
    4878:	900000f5 	adrp	x21, 20000 <__data_start>
    487c:	9101c2b5 	add	x21, x21, #0x70
    4880:	14000006 	b	4898 <fwp_closure_drop.part.0+0x84>
    4884:	f9400422 	ldr	x2, [x1, #8]
    4888:	52800001 	mov	w1, #0x0                   	// #0
    488c:	d63f0040 	blr	x2
    4890:	f94007e0 	ldr	x0, [sp, #8]
    4894:	b40001a0 	cbz	x0, 48c8 <fwp_closure_drop.part.0+0xb4>
    4898:	f94003e1 	ldr	x1, [sp]
    489c:	d1000400 	sub	x0, x0, #0x1
    48a0:	f90007e0 	str	x0, [sp, #8]
    48a4:	f94066a2 	ldr	x2, [x21, #200]
    48a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    48ac:	b9400001 	ldr	w1, [x0]
    48b0:	8b011441 	add	x1, x2, x1, lsl #5
    48b4:	f9400c21 	ldr	x1, [x1, #24]
    48b8:	b5fffe61 	cbnz	x1, 4884 <fwp_closure_drop.part.0+0x70>
    48bc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    48c0:	91372000 	add	x0, x0, #0xdc8
    48c4:	97fffe13 	bl	4110 <fwp_trap>
    48c8:	f94123f5 	ldr	x21, [sp, #576]
    48cc:	91400273 	add	x19, x19, #0x0, lsl #12
    48d0:	91004273 	add	x19, x19, #0x10
    48d4:	f94003e0 	ldr	x0, [sp]
    48d8:	f900027f 	str	xzr, [x19]
    48dc:	eb14001f 	cmp	x0, x20
    48e0:	54000040 	b.eq	48e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48e4:	97fff817 	bl	2940 <free@plt>
    48e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48ec:	f947f400 	ldr	x0, [x0, #4072]
    48f0:	f9410fe2 	ldr	x2, [sp, #536]
    48f4:	f9400001 	ldr	x1, [x0]
    48f8:	eb010042 	subs	x2, x2, x1
    48fc:	d2800001 	mov	x1, #0x0                   	// #0
    4900:	540000a1 	b.ne	4914 <fwp_closure_drop.part.0+0x100>  // b.any
    4904:	910883ff 	add	sp, sp, #0x220
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4910:	d65f03c0 	ret
    4914:	f90123f5 	str	x21, [sp, #576]
    4918:	97fff7da 	bl	2880 <__stack_chk_fail@plt>
    491c:	d503201f 	nop

0000000000004920 <fwp_tape_of>:
    4920:	aa0003e1 	mov	x1, x0
    4924:	92403c00 	and	x0, x0, #0xffff
    4928:	b40000e0 	cbz	x0, 4944 <fwp_tape_of+0x24>
    492c:	d1000402 	sub	x2, x0, #0x1
    4930:	900000e3 	adrp	x3, 20000 <__data_start>
    4934:	9101c060 	add	x0, x3, #0x70
    4938:	f9406800 	ldr	x0, [x0, #208]
    493c:	eb02001f 	cmp	x0, x2
    4940:	540000cc 	b.gt	4958 <fwp_tape_of+0x38>
    4944:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4948:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    494c:	9137e000 	add	x0, x0, #0xdf8
    4950:	910003fd 	mov	x29, sp
    4954:	97fffdef 	bl	4110 <fwp_trap>
    4958:	8b020440 	add	x0, x2, x2, lsl #1
    495c:	f9403863 	ldr	x3, [x3, #112]
    4960:	8b000842 	add	x2, x2, x0, lsl #2
    4964:	d37df042 	lsl	x2, x2, #3
    4968:	8b020060 	add	x0, x3, x2
    496c:	b9400404 	ldr	w4, [x0, #4]
    4970:	34fffea4 	cbz	w4, 4944 <fwp_tape_of+0x24>
    4974:	b8626862 	ldr	w2, [x3, x2]
    4978:	9350fc21 	asr	x1, x1, #16
    497c:	6b01005f 	cmp	w2, w1
    4980:	54fffe21 	b.ne	4944 <fwp_tape_of+0x24>  // b.any
    4984:	d65f03c0 	ret
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_now_ns>:
    4990:	d100c3ff 	sub	sp, sp, #0x30
    4994:	52800020 	mov	w0, #0x1                   	// #1
    4998:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    499c:	f947f442 	ldr	x2, [x2, #4072]
    49a0:	910023e1 	add	x1, sp, #0x8
    49a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    49a8:	910083fd 	add	x29, sp, #0x20
    49ac:	f9400043 	ldr	x3, [x2]
    49b0:	f9000fe3 	str	x3, [sp, #24]
    49b4:	d2800003 	mov	x3, #0x0                   	// #0
    49b8:	97fff77e 	bl	27b0 <clock_gettime@plt>
    49bc:	350002c0 	cbnz	w0, 4a14 <fwp_now_ns+0x84>
    49c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49c4:	d2994003 	mov	x3, #0xca00                	// #51712
    49c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49cc:	9b037c20 	mul	x0, x1, x3
    49d0:	9b437c21 	smulh	x1, x1, x3
    49d4:	ab020000 	adds	x0, x0, x2
    49d8:	937ffc42 	asr	x2, x2, #63
    49dc:	9a020021 	adc	x1, x1, x2
    49e0:	f100001f 	cmp	x0, #0x0
    49e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49e8:	b50001c1 	cbnz	x1, 4a20 <fwp_now_ns+0x90>
    49ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    49f0:	f947f421 	ldr	x1, [x1, #4072]
    49f4:	f9400fe3 	ldr	x3, [sp, #24]
    49f8:	f9400022 	ldr	x2, [x1]
    49fc:	eb020063 	subs	x3, x3, x2
    4a00:	d2800002 	mov	x2, #0x0                   	// #0
    4a04:	54000141 	b.ne	4a2c <fwp_now_ns+0x9c>  // b.any
    4a08:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a0c:	9100c3ff 	add	sp, sp, #0x30
    4a10:	d65f03c0 	ret
    4a14:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4a18:	91392000 	add	x0, x0, #0xe48
    4a1c:	97fffdbd 	bl	4110 <fwp_trap>
    4a20:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4a24:	9139a000 	add	x0, x0, #0xe68
    4a28:	97fffdba 	bl	4110 <fwp_trap>
    4a2c:	97fff795 	bl	2880 <__stack_chk_fail@plt>

0000000000004a30 <fwp_poll_events>:
    4a30:	d10103ff 	sub	sp, sp, #0x40
    4a34:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4a38:	f947f400 	ldr	x0, [x0, #4072]
    4a3c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a40:	910083fd 	add	x29, sp, #0x20
    4a44:	f9001bf3 	str	x19, [sp, #48]
    4a48:	900000f3 	adrp	x19, 20000 <__data_start>
    4a4c:	f9400001 	ldr	x1, [x0]
    4a50:	f9000fe1 	str	x1, [sp, #24]
    4a54:	d2800001 	mov	x1, #0x0                   	// #0
    4a58:	97ffffce 	bl	4990 <fwp_now_ns>
    4a5c:	9101c261 	add	x1, x19, #0x70
    4a60:	f9406c21 	ldr	x1, [x1, #216]
    4a64:	b4000e01 	cbz	x1, 4c24 <fwp_poll_events+0x1f4>
    4a68:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a6c:	14000005 	b	4a80 <fwp_poll_events+0x50>
    4a70:	f9408821 	ldr	x1, [x1, #272]
    4a74:	eb03005f 	cmp	x2, x3
    4a78:	9a83d042 	csel	x2, x2, x3, le
    4a7c:	b40000c1 	cbz	x1, 4a94 <fwp_poll_events+0x64>
    4a80:	f9403423 	ldr	x3, [x1, #104]
    4a84:	b6ffff62 	tbz	x2, #63, 4a70 <fwp_poll_events+0x40>
    4a88:	f9408821 	ldr	x1, [x1, #272]
    4a8c:	aa0303e2 	mov	x2, x3
    4a90:	b5ffff81 	cbnz	x1, 4a80 <fwp_poll_events+0x50>
    4a94:	b7f80c82 	tbnz	x2, #63, 4c24 <fwp_poll_events+0x1f4>
    4a98:	cb000042 	sub	x2, x2, x0
    4a9c:	f100005f 	cmp	x2, #0x0
    4aa0:	540003ad 	b.le	4b14 <fwp_poll_events+0xe4>
    4aa4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4aa8:	d2884804 	mov	x4, #0x4240                	// #16960
    4aac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4ab0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4ab4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4ab8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4abc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ac0:	9b407c40 	smulh	x0, x2, x0
    4ac4:	9352fc00 	asr	x0, x0, #18
    4ac8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4acc:	9b048802 	msub	x2, x0, x4, x2
    4ad0:	f100005f 	cmp	x2, #0x0
    4ad4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ad8:	eb01001f 	cmp	x0, x1
    4adc:	5400098c 	b.gt	4c0c <fwp_poll_events+0x1dc>
    4ae0:	340001a0 	cbz	w0, 4b14 <fwp_poll_events+0xe4>
    4ae4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ae8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4aec:	72a20c41 	movk	w1, #0x1062, lsl #16
    4af0:	9ba17c01 	umull	x1, w0, w1
    4af4:	d366fc23 	lsr	x3, x1, #38
    4af8:	aa0303e2 	mov	x2, x3
    4afc:	1b058063 	msub	w3, w3, w5, w0
    4b00:	9b247c63 	smull	x3, w3, w4
    4b04:	910023e0 	add	x0, sp, #0x8
    4b08:	d2800001 	mov	x1, #0x0                   	// #0
    4b0c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b10:	97fff790 	bl	2950 <nanosleep@plt>
    4b14:	97ffff9f 	bl	4990 <fwp_now_ns>
    4b18:	9101c268 	add	x8, x19, #0x70
    4b1c:	aa0003e7 	mov	x7, x0
    4b20:	4f000400 	movi	v0.4s, #0x0
    4b24:	52800029 	mov	w9, #0x1                   	// #1
    4b28:	f9406d06 	ldr	x6, [x8, #216]
    4b2c:	d503201f 	nop
    4b30:	b40003e6 	cbz	x6, 4bac <fwp_poll_events+0x17c>
    4b34:	f94034c1 	ldr	x1, [x6, #104]
    4b38:	aa0603e5 	mov	x5, x6
    4b3c:	f94088c6 	ldr	x6, [x6, #272]
    4b40:	eb07003f 	cmp	x1, x7
    4b44:	54ffff6c 	b.gt	4b30 <fwp_poll_events+0x100>
    4b48:	394154a0 	ldrb	w0, [x5, #85]
    4b4c:	36000120 	tbz	w0, #0, 4b70 <fwp_poll_events+0x140>
    4b50:	f94084a0 	ldr	x0, [x5, #264]
    4b54:	b4000560 	cbz	x0, 4c00 <fwp_poll_events+0x1d0>
    4b58:	f9008806 	str	x6, [x0, #272]
    4b5c:	b4000046 	cbz	x6, 4b64 <fwp_poll_events+0x134>
    4b60:	f90084c0 	str	x0, [x6, #264]
    4b64:	910800a0 	add	x0, x5, #0x200
    4b68:	390154bf 	strb	wzr, [x5, #85]
    4b6c:	3c908000 	stur	q0, [x0, #-248]
    4b70:	f94030a0 	ldr	x0, [x5, #96]
    4b74:	390158a9 	strb	w9, [x5, #86]
    4b78:	f100001f 	cmp	x0, #0x0
    4b7c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b80:	540002cd 	b.le	4bd8 <fwp_poll_events+0x1a8>
    4b84:	f94028a0 	ldr	x0, [x5, #80]
    4b88:	f2001c1f 	tst	x0, #0xff000000ff
    4b8c:	54fffd21 	b.ne	4b30 <fwp_poll_events+0x100>  // b.any
    4b90:	f9403d00 	ldr	x0, [x8, #120]
    4b94:	390150a9 	strb	w9, [x5, #84]
    4b98:	f90080bf 	str	xzr, [x5, #256]
    4b9c:	b40002c0 	cbz	x0, 4bf4 <fwp_poll_events+0x1c4>
    4ba0:	f9003d05 	str	x5, [x8, #120]
    4ba4:	f9008005 	str	x5, [x0, #256]
    4ba8:	b5fffc66 	cbnz	x6, 4b34 <fwp_poll_events+0x104>
    4bac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4bb0:	f947f400 	ldr	x0, [x0, #4072]
    4bb4:	f9400fe2 	ldr	x2, [sp, #24]
    4bb8:	f9400001 	ldr	x1, [x0]
    4bbc:	eb010042 	subs	x2, x2, x1
    4bc0:	d2800001 	mov	x1, #0x0                   	// #0
    4bc4:	540002e1 	b.ne	4c20 <fwp_poll_events+0x1f0>  // b.any
    4bc8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bcc:	f9401bf3 	ldr	x19, [sp, #48]
    4bd0:	910103ff 	add	sp, sp, #0x40
    4bd4:	d65f03c0 	ret
    4bd8:	394144a0 	ldrb	w0, [x5, #81]
    4bdc:	3707fd40 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be0:	394140a0 	ldrb	w0, [x5, #80]
    4be4:	3707fd00 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be8:	aa0503e0 	mov	x0, x5
    4bec:	97fffac1 	bl	36f0 <fwp_cancel_tree.part.0>
    4bf0:	17ffffe5 	b	4b84 <fwp_poll_events+0x154>
    4bf4:	f9003d05 	str	x5, [x8, #120]
    4bf8:	f9004105 	str	x5, [x8, #128]
    4bfc:	17ffffeb 	b	4ba8 <fwp_poll_events+0x178>
    4c00:	9101c261 	add	x1, x19, #0x70
    4c04:	f9006c26 	str	x6, [x1, #216]
    4c08:	17ffffd5 	b	4b5c <fwp_poll_events+0x12c>
    4c0c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c10:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c14:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c18:	f2a00402 	movk	x2, #0x20, lsl #16
    4c1c:	17ffffba 	b	4b04 <fwp_poll_events+0xd4>
    4c20:	97fff718 	bl	2880 <__stack_chk_fail@plt>
    4c24:	97fff8f3 	bl	2ff0 <fwp_flush>
    4c28:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4c2c:	f947e863 	ldr	x3, [x3, #4048]
    4c30:	d2800562 	mov	x2, #0x2b                  	// #43
    4c34:	d2800021 	mov	x1, #0x1                   	// #1
    4c38:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    4c3c:	913a4000 	add	x0, x0, #0xe90
    4c40:	f9400063 	ldr	x3, [x3]
    4c44:	97fff74f 	bl	2980 <fwrite@plt>
    4c48:	52800ca0 	mov	w0, #0x65                  	// #101
    4c4c:	97fff6b9 	bl	2730 <exit@plt>

0000000000004c50 <fwp_heap_alloc_big>:
    4c50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c54:	910003fd 	mov	x29, sp
    4c58:	a90153f3 	stp	x19, x20, [sp, #16]
    4c5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c60:	a90363f7 	stp	x23, x24, [sp, #48]
    4c64:	aa0003f7 	mov	x23, x0
    4c68:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c70:	eb0002ff 	cmp	x23, x0
    4c74:	540008a8 	b.hi	4d88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c78:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c7c:	8b0002f4 	add	x20, x23, x0
    4c80:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c84:	91174359 	add	x25, x26, #0x5d0
    4c88:	d350fe94 	lsr	x20, x20, #16
    4c8c:	2a0103f5 	mov	w21, w1
    4c90:	aa1403e0 	mov	x0, x20
    4c94:	97fff987 	bl	32b0 <fwp_heap_chunks>
    4c98:	f949ff22 	ldr	x2, [x25, #5112]
    4c9c:	8b000813 	add	x19, x0, x0, lsl #2
    4ca0:	aa0003f8 	mov	x24, x0
    4ca4:	52800043 	mov	w3, #0x2                   	// #2
    4ca8:	d37df273 	lsl	x19, x19, #3
    4cac:	d2800021 	mov	x1, #0x1                   	// #1
    4cb0:	8b130040 	add	x0, x2, x19
    4cb4:	38336843 	strb	w3, [x2, x19]
    4cb8:	39000415 	strb	w21, [x0, #1]
    4cbc:	b9000c14 	str	w20, [x0, #12]
    4cc0:	f9000817 	str	x23, [x0, #16]
    4cc4:	97fffd57 	bl	4220 <fwp_rc_prepare_chunk>
    4cc8:	f100069f 	cmp	x20, #0x1
    4ccc:	54000289 	b.ls	4d1c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cd0:	8b180294 	add	x20, x20, x24
    4cd4:	9100a273 	add	x19, x19, #0x28
    4cd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4cdc:	5280007b 	mov	w27, #0x3                   	// #3
    4ce0:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce4:	2a1803fc 	mov	w28, w24
    4ce8:	9adb2296 	lsl	x22, x20, x27
    4cec:	d503201f 	nop
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffd48 	bl	4220 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x108>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffbbf 	bl	3d70 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff6f 	b	4c50 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffd19 	bl	4340 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94066e0 	ldr	x0, [x23, #200]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_tape_grow.constprop.0>:
    5224:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5228:	d2800803 	mov	x3, #0x40                  	// #64
    522c:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5230:	910003fd 	mov	x29, sp
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	f9400c13 	ldr	x19, [x0, #24]
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	aa0003f7 	mov	x23, x0
    5244:	f100027f 	cmp	x19, #0x0
    5248:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    524c:	eb13003f 	cmp	x1, x19
    5250:	540000ed 	b.le	526c <fwp_tape_grow.constprop.0+0x48>
    5254:	eb02027f 	cmp	x19, x2
    5258:	5400076d 	b.le	5344 <fwp_tape_grow.constprop.0+0x120>
    525c:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    5260:	eb13003f 	cmp	x1, x19
    5264:	5400004d 	b.le	526c <fwp_tape_grow.constprop.0+0x48>
    5268:	14000000 	b	5268 <fwp_tape_grow.constprop.0+0x44>
    526c:	a940d2e2 	ldp	x2, x20, [x23, #8]
    5270:	a9025bf5 	stp	x21, x22, [sp, #32]
    5274:	d37df276 	lsl	x22, x19, #3
    5278:	f94012e0 	ldr	x0, [x23, #32]
    527c:	aa1603e1 	mov	x1, x22
    5280:	f94032f5 	ldr	x21, [x23, #96]
    5284:	cb020294 	sub	x20, x20, x2
    5288:	97fff57a 	bl	2870 <realloc@plt>
    528c:	b4000c20 	cbz	x0, 5410 <fwp_tape_grow.constprop.0+0x1ec>
    5290:	f9400ee1 	ldr	x1, [x23, #24]
    5294:	8b010801 	add	x1, x0, x1, lsl #2
    5298:	a90206e0 	stp	x0, x1, [x23, #32]
    529c:	b4000895 	cbz	x21, 53ac <fwp_tape_grow.constprop.0+0x188>
    52a0:	f94032b6 	ldr	x22, [x21, #96]
    52a4:	eb1302df 	cmp	x22, x19
    52a8:	540003aa 	b.ge	531c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    52ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    52b4:	eb00027f 	cmp	x19, x0
    52b8:	54000a68 	b.hi	5404 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    52bc:	f94022b9 	ldr	x25, [x21, #64]
    52c0:	d37cee7a 	lsl	x26, x19, #4
    52c4:	aa1a03e0 	mov	x0, x26
    52c8:	52800041 	mov	w1, #0x2                   	// #2
    52cc:	97ffff09 	bl	4ef0 <fwp_heap_alloc>
    52d0:	aa0003f8 	mov	x24, x0
    52d4:	b4000119 	cbz	x25, 52f4 <fwp_tape_grow.constprop.0+0xd0>
    52d8:	d37ceed6 	lsl	x22, x22, #4
    52dc:	aa1903e1 	mov	x1, x25
    52e0:	eb1a02df 	cmp	x22, x26
    52e4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    52e8:	97fff4fa 	bl	26d0 <memcpy@plt>
    52ec:	aa1903e0 	mov	x0, x25
    52f0:	97fffc44 	bl	4400 <fwp_mem_free>
    52f4:	f94032a0 	ldr	x0, [x21, #96]
    52f8:	52800001 	mov	w1, #0x0                   	// #0
    52fc:	cb000262 	sub	x2, x19, x0
    5300:	8b001300 	add	x0, x24, x0, lsl #4
    5304:	d37cec42 	lsl	x2, x2, #4
    5308:	97fff552 	bl	2850 <memset@plt>
    530c:	f94012e0 	ldr	x0, [x23, #32]
    5310:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5314:	f90022b8 	str	x24, [x21, #64]
    5318:	f90032b3 	str	x19, [x21, #96]
    531c:	d37ef675 	lsl	x21, x19, #2
    5320:	b50002b4 	cbnz	x20, 5374 <fwp_tape_grow.constprop.0+0x150>
    5324:	8b150001 	add	x1, x0, x21
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000ef3 	str	x19, [x23, #24]
    5330:	f90016e1 	str	x1, [x23, #40]
    5334:	a94153f3 	ldp	x19, x20, [sp, #16]
    5338:	a94363f7 	ldp	x23, x24, [sp, #48]
    533c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5340:	d65f03c0 	ret
    5344:	d37ffa73 	lsl	x19, x19, #1
    5348:	17ffffc1 	b	524c <fwp_tape_grow.constprop.0+0x28>
    534c:	eb1502df 	cmp	x22, x21
    5350:	aa0403e0 	mov	x0, x4
    5354:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    5358:	d37df282 	lsl	x2, x20, #3
    535c:	cb160063 	sub	x3, x3, x22
    5360:	97fff5b0 	bl	2a20 <__memmove_chk@plt>
    5364:	f9401ae1 	ldr	x1, [x23, #48]
    5368:	f94012e0 	ldr	x0, [x23, #32]
    536c:	8b160021 	add	x1, x1, x22
    5370:	f9001ee1 	str	x1, [x23, #56]
    5374:	f94016e1 	ldr	x1, [x23, #40]
    5378:	d37ef675 	lsl	x21, x19, #2
    537c:	d37ef682 	lsl	x2, x20, #2
    5380:	8b150000 	add	x0, x0, x21
    5384:	97fff4db 	bl	26f0 <memmove@plt>
    5388:	f94012e0 	ldr	x0, [x23, #32]
    538c:	8b150001 	add	x1, x0, x21
    5390:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5394:	f9000ef3 	str	x19, [x23, #24]
    5398:	f90016e1 	str	x1, [x23, #40]
    539c:	a94153f3 	ldp	x19, x20, [sp, #16]
    53a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53a4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53a8:	d65f03c0 	ret
    53ac:	f9401ae0 	ldr	x0, [x23, #48]
    53b0:	d37cee75 	lsl	x21, x19, #4
    53b4:	aa1503e1 	mov	x1, x21
    53b8:	97fff52e 	bl	2870 <realloc@plt>
    53bc:	b40002a0 	cbz	x0, 5410 <fwp_tape_grow.constprop.0+0x1ec>
    53c0:	f9400ee2 	ldr	x2, [x23, #24]
    53c4:	f9001ae0 	str	x0, [x23, #48]
    53c8:	8b160004 	add	x4, x0, x22
    53cc:	8b020c01 	add	x1, x0, x2, lsl #3
    53d0:	f9001ee1 	str	x1, [x23, #56]
    53d4:	b5fffbd4 	cbnz	x20, 534c <fwp_tape_grow.constprop.0+0x128>
    53d8:	f94012e0 	ldr	x0, [x23, #32]
    53dc:	d37ef675 	lsl	x21, x19, #2
    53e0:	f9001ee4 	str	x4, [x23, #56]
    53e4:	8b150001 	add	x1, x0, x21
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	f9000ef3 	str	x19, [x23, #24]
    53f0:	f90016e1 	str	x1, [x23, #40]
    53f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    5408:	913ba000 	add	x0, x0, #0xee8
    540c:	97fffb41 	bl	4110 <fwp_trap>
    5410:	aa1703e0 	mov	x0, x23
    5414:	a9046bf9 	stp	x25, x26, [sp, #64]
    5418:	97fff6de 	bl	2f90 <fwp_tape_unlink_scope>
    541c:	f94012e0 	ldr	x0, [x23, #32]
    5420:	97fff548 	bl	2940 <free@plt>
    5424:	f9401ae0 	ldr	x0, [x23, #48]
    5428:	97fff546 	bl	2940 <free@plt>
    542c:	f94022e0 	ldr	x0, [x23, #64]
    5430:	97fff544 	bl	2940 <free@plt>
    5434:	f9000eff 	str	xzr, [x23, #24]
    5438:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    543c:	f947e821 	ldr	x1, [x1, #4048]
    5440:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5444:	d2800262 	mov	x2, #0x13                  	// #19
    5448:	4f000400 	movi	v0.4s, #0x0
    544c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    5450:	f9400023 	ldr	x3, [x1]
    5454:	b90006ff 	str	wzr, [x23, #4]
    5458:	d2800021 	mov	x1, #0x1                   	// #1
    545c:	912d2000 	add	x0, x0, #0xb48
    5460:	3c8082e0 	stur	q0, [x23, #8]
    5464:	ad0102e0 	stp	q0, q0, [x23, #32]
    5468:	97fff546 	bl	2980 <fwrite@plt>
    546c:	d2800000 	mov	x0, #0x0                   	// #0
    5470:	97fff550 	bl	29b0 <fflush@plt>
    5474:	52800cc0 	mov	w0, #0x66                  	// #102
    5478:	97fff55e 	bl	29f0 <_Exit@plt>
    547c:	d503201f 	nop

0000000000005480 <f128.constprop.0>:
    5480:	f100001f 	cmp	x0, #0x0
    5484:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5488:	54000a2b 	b.lt	55cc <f128.constprop.0+0x14c>  // b.tstop
    548c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5490:	aa0003e2 	mov	x2, x0
    5494:	910003fd 	mov	x29, sp
    5498:	a90153f3 	stp	x19, x20, [sp, #16]
    549c:	aa0003f4 	mov	x20, x0
    54a0:	aa010000 	orr	x0, x0, x1
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	aa0103f6 	mov	x22, x1
    54ac:	f9001bf7 	str	x23, [sp, #48]
    54b0:	fd001fe8 	str	d8, [sp, #56]
    54b4:	b7f80180 	tbnz	x0, #63, 54e4 <f128.constprop.0+0x64>
    54b8:	9360fc20 	asr	x0, x1, #32
    54bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54c0:	eb82801f 	cmp	x0, x2, asr #32
    54c4:	54000881 	b.ne	55d4 <f128.constprop.0+0x154>  // b.any
    54c8:	97fffd16 	bl	4920 <fwp_tape_of>
    54cc:	aa0003f3 	mov	x19, x0
    54d0:	f9403000 	ldr	x0, [x0, #96]
    54d4:	b40001e0 	cbz	x0, 5510 <f128.constprop.0+0x90>
    54d8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    54dc:	913d4000 	add	x0, x0, #0xf50
    54e0:	97fffb0c 	bl	4110 <fwp_trap>
    54e4:	9360fc40 	asr	x0, x2, #32
    54e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54ec:	b6fffee2 	tbz	x2, #63, 54c8 <f128.constprop.0+0x48>
    54f0:	2f00e408 	movi	d8, #0x0
    54f4:	9360fc20 	asr	x0, x1, #32
    54f8:	aa0103f4 	mov	x20, x1
    54fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5500:	97fffd08 	bl	4920 <fwp_tape_of>
    5504:	aa0003f3 	mov	x19, x0
    5508:	f9403000 	ldr	x0, [x0, #96]
    550c:	b5fffe60 	cbnz	x0, 54d8 <f128.constprop.0+0x58>
    5510:	f9400a77 	ldr	x23, [x19, #16]
    5514:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5518:	eb0002ff 	cmp	x23, x0
    551c:	5400046c 	b.gt	55a8 <f128.constprop.0+0x128>
    5520:	eb3442ff 	cmp	x23, w20, uxtw
    5524:	540004ed 	b.le	55c0 <f128.constprop.0+0x140>
    5528:	b7f80076 	tbnz	x22, #63, 5534 <f128.constprop.0+0xb4>
    552c:	eb3642ff 	cmp	x23, w22, uxtw
    5530:	5400048d 	b.le	55c0 <f128.constprop.0+0x140>
    5534:	f9400675 	ldr	x21, [x19, #8]
    5538:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    553c:	cb1502f5 	sub	x21, x23, x21
    5540:	910006a1 	add	x1, x21, #0x1
    5544:	eb00003f 	cmp	x1, x0
    5548:	54000308 	b.hi	55a8 <f128.constprop.0+0x128>  // b.pmore
    554c:	f9400e60 	ldr	x0, [x19, #24]
    5550:	eb00003f 	cmp	x1, x0
    5554:	5400030c 	b.gt	55b4 <f128.constprop.0+0x134>
    5558:	a9420262 	ldp	x2, x0, [x19, #32]
    555c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5560:	f9401a61 	ldr	x1, [x19, #48]
    5564:	b8357854 	str	w20, [x2, x21, lsl #2]
    5568:	f9401e62 	ldr	x2, [x19, #56]
    556c:	f10002df 	cmp	x22, #0x0
    5570:	fc357820 	str	d0, [x1, x21, lsl #3]
    5574:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5578:	b8357816 	str	w22, [x0, x21, lsl #2]
    557c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5580:	910006e1 	add	x1, x23, #0x1
    5584:	aa170000 	orr	x0, x0, x23
    5588:	fc357848 	str	d8, [x2, x21, lsl #3]
    558c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5590:	f9401bf7 	ldr	x23, [sp, #48]
    5594:	fd401fe8 	ldr	d8, [sp, #56]
    5598:	f9000a61 	str	x1, [x19, #16]
    559c:	a94153f3 	ldp	x19, x20, [sp, #16]
    55a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55a4:	d65f03c0 	ret
    55a8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    55ac:	913ba000 	add	x0, x0, #0xee8
    55b0:	97fffad8 	bl	4110 <fwp_trap>
    55b4:	aa1303e0 	mov	x0, x19
    55b8:	97ffff1b 	bl	5224 <fwp_tape_grow.constprop.0>
    55bc:	17ffffe7 	b	5558 <f128.constprop.0+0xd8>
    55c0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    55c4:	913e0000 	add	x0, x0, #0xf80
    55c8:	97fffad2 	bl	4110 <fwp_trap>
    55cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55d0:	d65f03c0 	ret
    55d4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    55d8:	913c2000 	add	x0, x0, #0xf08
    55dc:	97fffacd 	bl	4110 <fwp_trap>

00000000000055e0 <w107>:
    55e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    55e4:	910003fd 	mov	x29, sp
    55e8:	a90153f3 	stp	x19, x20, [sp, #16]
    55ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    55f0:	a90363f7 	stp	x23, x24, [sp, #48]
    55f4:	aa0003f8 	mov	x24, x0
    55f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55fc:	aa0103f9 	mov	x25, x1
    5600:	6d0527e8 	stp	d8, d9, [sp, #80]
    5604:	1e604008 	fmov	d8, d0
    5608:	1e604029 	fmov	d9, d1
    560c:	6d062fea 	stp	d10, d11, [sp, #96]
    5610:	1e60080a 	fmul	d10, d0, d0
    5614:	b7f821a0 	tbnz	x0, #63, 5a48 <w107+0x468>
    5618:	9360fc17 	asr	x23, x0, #32
    561c:	aa1703e0 	mov	x0, x23
    5620:	97fffcc0 	bl	4920 <fwp_tape_of>
    5624:	f9403001 	ldr	x1, [x0, #96]
    5628:	aa0003f3 	mov	x19, x0
    562c:	b4000081 	cbz	x1, 563c <w107+0x5c>
    5630:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    5634:	913d4000 	add	x0, x0, #0xf50
    5638:	97fffab6 	bl	4110 <fwp_trap>
    563c:	f9400815 	ldr	x21, [x0, #16]
    5640:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5644:	eb0102bf 	cmp	x21, x1
    5648:	54001d8c 	b.gt	59f8 <w107+0x418>
    564c:	eb3842bf 	cmp	x21, w24, uxtw
    5650:	54001ced 	b.le	59ec <w107+0x40c>
    5654:	f9400416 	ldr	x22, [x0, #8]
    5658:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    565c:	cb1602b6 	sub	x22, x21, x22
    5660:	910006c1 	add	x1, x22, #0x1
    5664:	eb02003f 	cmp	x1, x2
    5668:	54001c88 	b.hi	59f8 <w107+0x418>  // b.pmore
    566c:	f9400c02 	ldr	x2, [x0, #24]
    5670:	eb02003f 	cmp	x1, x2
    5674:	54001c8c 	b.gt	5a04 <w107+0x424>
    5678:	a9420660 	ldp	x0, x1, [x19, #32]
    567c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5680:	f9401a62 	ldr	x2, [x19, #48]
    5684:	b8367818 	str	w24, [x0, x22, lsl #2]
    5688:	f9401e60 	ldr	x0, [x19, #56]
    568c:	aa150294 	orr	x20, x20, x21
    5690:	fc367848 	str	d8, [x2, x22, lsl #3]
    5694:	910006b5 	add	x21, x21, #0x1
    5698:	b8367838 	str	w24, [x1, x22, lsl #2]
    569c:	1e6a392a 	fsub	d10, d9, d10
    56a0:	9360fe9a 	asr	x26, x20, #32
    56a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    56a8:	f9000a75 	str	x21, [x19, #16]
    56ac:	b7f80079 	tbnz	x25, #63, 56b8 <w107+0xd8>
    56b0:	eb99835f 	cmp	x26, x25, asr #32
    56b4:	54001e21 	b.ne	5a78 <w107+0x498>  // b.any
    56b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    56c0:	eb1a02ff 	cmp	x23, x26
    56c4:	540000c0 	b.eq	56dc <w107+0xfc>  // b.none
    56c8:	aa1a03e0 	mov	x0, x26
    56cc:	97fffc95 	bl	4920 <fwp_tape_of>
    56d0:	aa0003f3 	mov	x19, x0
    56d4:	f9403000 	ldr	x0, [x0, #96]
    56d8:	b5fffac0 	cbnz	x0, 5630 <w107+0x50>
    56dc:	f9400a77 	ldr	x23, [x19, #16]
    56e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56e4:	eb0002ff 	cmp	x23, x0
    56e8:	5400188c 	b.gt	59f8 <w107+0x418>
    56ec:	eb3442ff 	cmp	x23, w20, uxtw
    56f0:	540017ed 	b.le	59ec <w107+0x40c>
    56f4:	b7f80079 	tbnz	x25, #63, 5700 <w107+0x120>
    56f8:	eb3942ff 	cmp	x23, w25, uxtw
    56fc:	5400178d 	b.le	59ec <w107+0x40c>
    5700:	f9400675 	ldr	x21, [x19, #8]
    5704:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5708:	cb1502f5 	sub	x21, x23, x21
    570c:	910006a1 	add	x1, x21, #0x1
    5710:	eb00003f 	cmp	x1, x0
    5714:	54001728 	b.hi	59f8 <w107+0x418>  // b.pmore
    5718:	f9400e60 	ldr	x0, [x19, #24]
    571c:	eb00003f 	cmp	x1, x0
    5720:	540018ec 	b.gt	5a3c <w107+0x45c>
    5724:	a9420e62 	ldp	x2, x3, [x19, #32]
    5728:	f100033f 	cmp	x25, #0x0
    572c:	f9401a61 	ldr	x1, [x19, #48]
    5730:	b8357854 	str	w20, [x2, x21, lsl #2]
    5734:	f9401e62 	ldr	x2, [x19, #56]
    5738:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    573c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5740:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5744:	b8357861 	str	w1, [x3, x21, lsl #2]
    5748:	910006f6 	add	x22, x23, #0x1
    574c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5750:	92607e94 	and	x20, x20, #0xffffffff00000000
    5754:	fc357849 	str	d9, [x2, x21, lsl #3]
    5758:	aa170294 	orr	x20, x20, x23
    575c:	f9000a76 	str	x22, [x19, #16]
    5760:	1e68396b 	fsub	d11, d11, d8
    5764:	b7f81a78 	tbnz	x24, #63, 5ab0 <w107+0x4d0>
    5768:	9360ff17 	asr	x23, x24, #32
    576c:	eb1a02ff 	cmp	x23, x26
    5770:	540000e0 	b.eq	578c <w107+0x1ac>  // b.none
    5774:	aa1703e0 	mov	x0, x23
    5778:	97fffc6a 	bl	4920 <fwp_tape_of>
    577c:	aa0003f3 	mov	x19, x0
    5780:	f9403000 	ldr	x0, [x0, #96]
    5784:	b5fff560 	cbnz	x0, 5630 <w107+0x50>
    5788:	f9400a76 	ldr	x22, [x19, #16]
    578c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5790:	eb0002df 	cmp	x22, x0
    5794:	5400132c 	b.gt	59f8 <w107+0x418>
    5798:	eb3842df 	cmp	x22, w24, uxtw
    579c:	5400128d 	b.le	59ec <w107+0x40c>
    57a0:	f9400675 	ldr	x21, [x19, #8]
    57a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57a8:	cb1502d5 	sub	x21, x22, x21
    57ac:	910006a1 	add	x1, x21, #0x1
    57b0:	eb00003f 	cmp	x1, x0
    57b4:	54001228 	b.hi	59f8 <w107+0x418>  // b.pmore
    57b8:	f9400e60 	ldr	x0, [x19, #24]
    57bc:	eb00003f 	cmp	x1, x0
    57c0:	5400138c 	b.gt	5a30 <w107+0x450>
    57c4:	a9420262 	ldp	x2, x0, [x19, #32]
    57c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    57cc:	f9401a63 	ldr	x3, [x19, #48]
    57d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    57d4:	f9401e62 	ldr	x2, [x19, #56]
    57d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    57dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    57e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    57e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    57e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    57ec:	aa160018 	orr	x24, x0, x22
    57f0:	910006c1 	add	x1, x22, #0x1
    57f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    57f8:	f9000a61 	str	x1, [x19, #16]
    57fc:	9360fe99 	asr	x25, x20, #32
    5800:	1e6a0949 	fmul	d9, d10, d10
    5804:	eb17033f 	cmp	x25, x23
    5808:	540000c0 	b.eq	5820 <w107+0x240>  // b.none
    580c:	aa1903e0 	mov	x0, x25
    5810:	97fffc44 	bl	4920 <fwp_tape_of>
    5814:	aa0003f3 	mov	x19, x0
    5818:	f9403000 	ldr	x0, [x0, #96]
    581c:	b5fff0a0 	cbnz	x0, 5630 <w107+0x50>
    5820:	f9400a75 	ldr	x21, [x19, #16]
    5824:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5828:	eb0002bf 	cmp	x21, x0
    582c:	54000e6c 	b.gt	59f8 <w107+0x418>
    5830:	eb3442bf 	cmp	x21, w20, uxtw
    5834:	54000dcd 	b.le	59ec <w107+0x40c>
    5838:	f9400676 	ldr	x22, [x19, #8]
    583c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5840:	cb1602b6 	sub	x22, x21, x22
    5844:	910006c1 	add	x1, x22, #0x1
    5848:	eb00003f 	cmp	x1, x0
    584c:	54000d68 	b.hi	59f8 <w107+0x418>  // b.pmore
    5850:	f9400e60 	ldr	x0, [x19, #24]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000e6c 	b.gt	5a24 <w107+0x444>
    585c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5860:	aa150017 	orr	x23, x0, x21
    5864:	a9420261 	ldp	x1, x0, [x19, #32]
    5868:	f9401a62 	ldr	x2, [x19, #48]
    586c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5870:	f9401e61 	ldr	x1, [x19, #56]
    5874:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5878:	b8367814 	str	w20, [x0, x22, lsl #2]
    587c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5880:	9e670000 	fmov	d0, x0
    5884:	910006b4 	add	x20, x21, #0x1
    5888:	fc36782a 	str	d10, [x1, x22, lsl #3]
    588c:	9360fef6 	asr	x22, x23, #32
    5890:	f9000a74 	str	x20, [x19, #16]
    5894:	1e600929 	fmul	d9, d9, d0
    5898:	eb1902df 	cmp	x22, x25
    589c:	540000e0 	b.eq	58b8 <w107+0x2d8>  // b.none
    58a0:	aa1603e0 	mov	x0, x22
    58a4:	97fffc1f 	bl	4920 <fwp_tape_of>
    58a8:	aa0003f3 	mov	x19, x0
    58ac:	f9403000 	ldr	x0, [x0, #96]
    58b0:	b5ffec00 	cbnz	x0, 5630 <w107+0x50>
    58b4:	f9400a74 	ldr	x20, [x19, #16]
    58b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58bc:	eb00029f 	cmp	x20, x0
    58c0:	540009cc 	b.gt	59f8 <w107+0x418>
    58c4:	eb37429f 	cmp	x20, w23, uxtw
    58c8:	5400092d 	b.le	59ec <w107+0x40c>
    58cc:	f9400675 	ldr	x21, [x19, #8]
    58d0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    58d4:	cb150295 	sub	x21, x20, x21
    58d8:	910006a1 	add	x1, x21, #0x1
    58dc:	eb00003f 	cmp	x1, x0
    58e0:	540008c8 	b.hi	59f8 <w107+0x418>  // b.pmore
    58e4:	f9400e60 	ldr	x0, [x19, #24]
    58e8:	eb00003f 	cmp	x1, x0
    58ec:	5400096c 	b.gt	5a18 <w107+0x438>
    58f0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    58f4:	9e670000 	fmov	d0, x0
    58f8:	a9420262 	ldp	x2, x0, [x19, #32]
    58fc:	1e6b0968 	fmul	d8, d11, d11
    5900:	f9401a61 	ldr	x1, [x19, #48]
    5904:	b8357857 	str	w23, [x2, x21, lsl #2]
    5908:	f9401e62 	ldr	x2, [x19, #56]
    590c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5910:	12800001 	mov	w1, #0xffffffff            	// #-1
    5914:	b8357801 	str	w1, [x0, x21, lsl #2]
    5918:	91000681 	add	x1, x20, #0x1
    591c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5920:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5924:	f9000a61 	str	x1, [x19, #16]
    5928:	aa140014 	orr	x20, x0, x20
    592c:	b100071f 	cmn	x24, #0x1
    5930:	54000c60 	b.eq	5abc <w107+0x4dc>  // b.none
    5934:	9360ff00 	asr	x0, x24, #32
    5938:	eb16001f 	cmp	x0, x22
    593c:	540000a0 	b.eq	5950 <w107+0x370>  // b.none
    5940:	97fffbf8 	bl	4920 <fwp_tape_of>
    5944:	aa0003f3 	mov	x19, x0
    5948:	f9403000 	ldr	x0, [x0, #96]
    594c:	b5ffe720 	cbnz	x0, 5630 <w107+0x50>
    5950:	f9400a75 	ldr	x21, [x19, #16]
    5954:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5958:	eb0002bf 	cmp	x21, x0
    595c:	540004ec 	b.gt	59f8 <w107+0x418>
    5960:	eb3842bf 	cmp	x21, w24, uxtw
    5964:	5400044d 	b.le	59ec <w107+0x40c>
    5968:	f9400676 	ldr	x22, [x19, #8]
    596c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5970:	cb1602b6 	sub	x22, x21, x22
    5974:	910006c1 	add	x1, x22, #0x1
    5978:	eb00003f 	cmp	x1, x0
    597c:	540003e8 	b.hi	59f8 <w107+0x418>  // b.pmore
    5980:	f9400e60 	ldr	x0, [x19, #24]
    5984:	eb00003f 	cmp	x1, x0
    5988:	5400042c 	b.gt	5a0c <w107+0x42c>
    598c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5990:	92607f00 	and	x0, x24, #0xffffffff00000000
    5994:	f9401a63 	ldr	x3, [x19, #48]
    5998:	b8367838 	str	w24, [x1, x22, lsl #2]
    599c:	f9401e61 	ldr	x1, [x19, #56]
    59a0:	aa150000 	orr	x0, x0, x21
    59a4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    59a8:	910006b5 	add	x21, x21, #0x1
    59ac:	b8367858 	str	w24, [x2, x22, lsl #2]
    59b0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    59b4:	f9000a75 	str	x21, [x19, #16]
    59b8:	1e692908 	fadd	d8, d8, d9
    59bc:	aa1403e1 	mov	x1, x20
    59c0:	97fffeb0 	bl	5480 <f128.constprop.0>
    59c4:	aa0003e1 	mov	x1, x0
    59c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    59cc:	9e660100 	fmov	x0, d8
    59d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    59d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    59dc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    59e0:	6d462fea 	ldp	d10, d11, [sp, #96]
    59e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    59e8:	d65f03c0 	ret
    59ec:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    59f0:	913e0000 	add	x0, x0, #0xf80
    59f4:	97fff9c7 	bl	4110 <fwp_trap>
    59f8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    59fc:	913ba000 	add	x0, x0, #0xee8
    5a00:	97fff9c4 	bl	4110 <fwp_trap>
    5a04:	97fffe08 	bl	5224 <fwp_tape_grow.constprop.0>
    5a08:	17ffff1c 	b	5678 <w107+0x98>
    5a0c:	aa1303e0 	mov	x0, x19
    5a10:	97fffe05 	bl	5224 <fwp_tape_grow.constprop.0>
    5a14:	17ffffde 	b	598c <w107+0x3ac>
    5a18:	aa1303e0 	mov	x0, x19
    5a1c:	97fffe02 	bl	5224 <fwp_tape_grow.constprop.0>
    5a20:	17ffffb4 	b	58f0 <w107+0x310>
    5a24:	aa1303e0 	mov	x0, x19
    5a28:	97fffdff 	bl	5224 <fwp_tape_grow.constprop.0>
    5a2c:	17ffff8c 	b	585c <w107+0x27c>
    5a30:	aa1303e0 	mov	x0, x19
    5a34:	97fffdfc 	bl	5224 <fwp_tape_grow.constprop.0>
    5a38:	17ffff63 	b	57c4 <w107+0x1e4>
    5a3c:	aa1303e0 	mov	x0, x19
    5a40:	97fffdf9 	bl	5224 <fwp_tape_grow.constprop.0>
    5a44:	17ffff38 	b	5724 <w107+0x144>
    5a48:	1e6a382a 	fsub	d10, d1, d10
    5a4c:	b6f801c1 	tbz	x1, #63, 5a84 <w107+0x4a4>
    5a50:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5a54:	1e6a0949 	fmul	d9, d10, d10
    5a58:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a5c:	9e670001 	fmov	d1, x0
    5a60:	1e683808 	fsub	d8, d0, d8
    5a64:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5a68:	aa1403e0 	mov	x0, x20
    5a6c:	1e610929 	fmul	d9, d9, d1
    5a70:	1e680908 	fmul	d8, d8, d8
    5a74:	17ffffd1 	b	59b8 <w107+0x3d8>
    5a78:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    5a7c:	913c2000 	add	x0, x0, #0xf08
    5a80:	97fff9a4 	bl	4110 <fwp_trap>
    5a84:	2f00e409 	movi	d9, #0x0
    5a88:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5a8c:	9360fc3a 	asr	x26, x1, #32
    5a90:	aa0103f4 	mov	x20, x1
    5a94:	aa1a03e0 	mov	x0, x26
    5a98:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5a9c:	97fffba1 	bl	4920 <fwp_tape_of>
    5aa0:	aa0003f3 	mov	x19, x0
    5aa4:	f9403000 	ldr	x0, [x0, #96]
    5aa8:	b5ffdc40 	cbnz	x0, 5630 <w107+0x50>
    5aac:	17ffff0c 	b	56dc <w107+0xfc>
    5ab0:	aa1a03f7 	mov	x23, x26
    5ab4:	aa0003f8 	mov	x24, x0
    5ab8:	17ffff51 	b	57fc <w107+0x21c>
    5abc:	aa1803e0 	mov	x0, x24
    5ac0:	17ffffbe 	b	59b8 <w107+0x3d8>

0000000000005ac4 <fwp_data.part.0.constprop.0>:
    5ac4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5ac8:	910003fd 	mov	x29, sp
    5acc:	a90153f3 	stp	x19, x20, [sp, #16]
    5ad0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5ad4:	91174283 	add	x3, x20, #0x5d0
    5ad8:	a9025bf5 	stp	x21, x22, [sp, #32]
    5adc:	aa0103f5 	mov	x21, x1
    5ae0:	b953a461 	ldr	w1, [x3, #5028]
    5ae4:	a90363f7 	stp	x23, x24, [sp, #48]
    5ae8:	2a0003f8 	mov	w24, w0
    5aec:	34000701 	cbz	w1, 5bcc <fwp_data.part.0.constprop.0+0x108>
    5af0:	397e8862 	ldrb	w2, [x3, #4002]
    5af4:	910f0040 	add	x0, x2, #0x3c0
    5af8:	8b020442 	add	x2, x2, x2, lsl #1
    5afc:	d37df042 	lsl	x2, x2, #3
    5b00:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5b04:	2a1703f6 	mov	w22, w23
    5b08:	f8626873 	ldr	x19, [x3, x2]
    5b0c:	b40004d3 	cbz	x19, 5ba4 <fwp_data.part.0.constprop.0+0xe0>
    5b10:	f9400260 	ldr	x0, [x19]
    5b14:	aa2003e0 	mvn	x0, x0
    5b18:	f8226860 	str	x0, [x3, x2]
    5b1c:	f10062df 	cmp	x22, #0x18
    5b20:	540000e9 	b.ls	5b3c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5b24:	d10066c2 	sub	x2, x22, #0x19
    5b28:	91006260 	add	x0, x19, #0x18
    5b2c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5b30:	52800001 	mov	w1, #0x0                   	// #0
    5b34:	91002042 	add	x2, x2, #0x8
    5b38:	97fff346 	bl	2850 <memset@plt>
    5b3c:	91174282 	add	x2, x20, #0x5d0
    5b40:	f94a1041 	ldr	x1, [x2, #5152]
    5b44:	ab160021 	adds	x1, x1, x22
    5b48:	540004c2 	b.cs	5be0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5b4c:	f94a1440 	ldr	x0, [x2, #5160]
    5b50:	f90a1041 	str	x1, [x2, #5152]
    5b54:	eb00003f 	cmp	x1, x0
    5b58:	54000049 	b.ls	5b60 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5b5c:	f90a1441 	str	x1, [x2, #5160]
    5b60:	91174294 	add	x20, x20, #0x5d0
    5b64:	1e6302e1 	ucvtf	d1, w23
    5b68:	fd4a1e80 	ldr	d0, [x20, #5176]
    5b6c:	1e612800 	fadd	d0, d0, d1
    5b70:	fd0a1e80 	str	d0, [x20, #5176]
    5b74:	52800041 	mov	w1, #0x2                   	// #2
    5b78:	29000678 	stp	w24, w1, [x19]
    5b7c:	aa1303e0 	mov	x0, x19
    5b80:	f94002a1 	ldr	x1, [x21]
    5b84:	f9000661 	str	x1, [x19, #8]
    5b88:	f94006a1 	ldr	x1, [x21, #8]
    5b8c:	f9000a61 	str	x1, [x19, #16]
    5b90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b98:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b9c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5ba0:	d65f03c0 	ret
    5ba4:	8b020063 	add	x3, x3, x2
    5ba8:	f9400473 	ldr	x19, [x3, #8]
    5bac:	b4000113 	cbz	x19, 5bcc <fwp_data.part.0.constprop.0+0x108>
    5bb0:	f9400860 	ldr	x0, [x3, #16]
    5bb4:	cb130000 	sub	x0, x0, x19
    5bb8:	eb0002df 	cmp	x22, x0
    5bbc:	54000088 	b.hi	5bcc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5bc0:	8b160260 	add	x0, x19, x22
    5bc4:	f9000460 	str	x0, [x3, #8]
    5bc8:	17ffffd5 	b	5b1c <fwp_data.part.0.constprop.0+0x58>
    5bcc:	52800001 	mov	w1, #0x0                   	// #0
    5bd0:	d2800300 	mov	x0, #0x18                  	// #24
    5bd4:	97fffcc7 	bl	4ef0 <fwp_heap_alloc>
    5bd8:	aa0003f3 	mov	x19, x0
    5bdc:	17ffffe6 	b	5b74 <fwp_data.part.0.constprop.0+0xb0>
    5be0:	97fff514 	bl	3030 <fwp_heap_oom>

0000000000005be4 <fwp_rc_share>:
    5be4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5be8:	91174042 	add	x2, x2, #0x5d0
    5bec:	f949d843 	ldr	x3, [x2, #5040]
    5bf0:	f949ec41 	ldr	x1, [x2, #5080]
    5bf4:	cb030000 	sub	x0, x0, x3
    5bf8:	eb01401f 	cmp	x0, x1, lsl #16
    5bfc:	540003a2 	b.cs	5c70 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c00:	d350fc01 	lsr	x1, x0, #16
    5c04:	f949fc44 	ldr	x4, [x2, #5112]
    5c08:	8b010821 	add	x1, x1, x1, lsl #2
    5c0c:	d37df021 	lsl	x1, x1, #3
    5c10:	8b010083 	add	x3, x4, x1
    5c14:	f9401062 	ldr	x2, [x3, #32]
    5c18:	b40002c2 	cbz	x2, 5c70 <fwp_rc_share+0x8c>
    5c1c:	38616881 	ldrb	w1, [x4, x1]
    5c20:	7100083f 	cmp	w1, #0x2
    5c24:	54000220 	b.eq	5c68 <fwp_rc_share+0x84>  // b.none
    5c28:	7100043f 	cmp	w1, #0x1
    5c2c:	54000221 	b.ne	5c70 <fwp_rc_share+0x8c>  // b.any
    5c30:	29430464 	ldp	w4, w1, [x3, #24]
    5c34:	92403c00 	and	x0, x0, #0xffff
    5c38:	9b047c00 	mul	x0, x0, x4
    5c3c:	d360fc00 	lsr	x0, x0, #32
    5c40:	eb01001f 	cmp	x0, x1
    5c44:	54000162 	b.cs	5c70 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c48:	8b000042 	add	x2, x2, x0
    5c4c:	39400040 	ldrb	w0, [x2]
    5c50:	34000100 	cbz	w0, 5c70 <fwp_rc_share+0x8c>
    5c54:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5c58:	90000040 	adrp	x0, d000 <fwp_main_thread+0x120>
    5c5c:	913e8000 	add	x0, x0, #0xfa0
    5c60:	910003fd 	mov	x29, sp
    5c64:	97fff92b 	bl	4110 <fwp_trap>
    5c68:	72003c1f 	tst	w0, #0xffff
    5c6c:	54ffff00 	b.eq	5c4c <fwp_rc_share+0x68>  // b.none
    5c70:	d65f03c0 	ret

0000000000005c74 <fwp_rc_fresh>:
    5c74:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5c7c:	91174063 	add	x3, x3, #0x5d0
    5c80:	910003fd 	mov	x29, sp
    5c84:	a90153f3 	stp	x19, x20, [sp, #16]
    5c88:	aa0003f3 	mov	x19, x0
    5c8c:	f949d861 	ldr	x1, [x3, #5040]
    5c90:	f949ec60 	ldr	x0, [x3, #5080]
    5c94:	cb010261 	sub	x1, x19, x1
    5c98:	eb00403f 	cmp	x1, x0, lsl #16
    5c9c:	54000322 	b.cs	5d00 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5ca0:	d350fc22 	lsr	x2, x1, #16
    5ca4:	f949fc63 	ldr	x3, [x3, #5112]
    5ca8:	8b020842 	add	x2, x2, x2, lsl #2
    5cac:	d37df042 	lsl	x2, x2, #3
    5cb0:	8b020060 	add	x0, x3, x2
    5cb4:	f9401014 	ldr	x20, [x0, #32]
    5cb8:	b4000254 	cbz	x20, 5d00 <fwp_rc_fresh+0x8c>
    5cbc:	38626862 	ldrb	w2, [x3, x2]
    5cc0:	7100085f 	cmp	w2, #0x2
    5cc4:	54000260 	b.eq	5d10 <fwp_rc_fresh+0x9c>  // b.none
    5cc8:	7100045f 	cmp	w2, #0x1
    5ccc:	540001a1 	b.ne	5d00 <fwp_rc_fresh+0x8c>  // b.any
    5cd0:	29430002 	ldp	w2, w0, [x0, #24]
    5cd4:	92403c21 	and	x1, x1, #0xffff
    5cd8:	9b027c21 	mul	x1, x1, x2
    5cdc:	d360fc21 	lsr	x1, x1, #32
    5ce0:	eb00003f 	cmp	x1, x0
    5ce4:	540000e2 	b.cs	5d00 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5ce8:	8b010294 	add	x20, x20, x1
    5cec:	39400280 	ldrb	w0, [x20]
    5cf0:	7103fc1f 	cmp	w0, #0xff
    5cf4:	540001a0 	b.eq	5d28 <fwp_rc_fresh+0xb4>  // b.none
    5cf8:	52800020 	mov	w0, #0x1                   	// #1
    5cfc:	39000280 	strb	w0, [x20]
    5d00:	aa1303e0 	mov	x0, x19
    5d04:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d0c:	d65f03c0 	ret
    5d10:	72003c3f 	tst	w1, #0xffff
    5d14:	54fffec0 	b.eq	5cec <fwp_rc_fresh+0x78>  // b.none
    5d18:	aa1303e0 	mov	x0, x19
    5d1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d24:	d65f03c0 	ret
    5d28:	aa1403e0 	mov	x0, x20
    5d2c:	97fff919 	bl	4190 <fwp_rc_forget_slot.part.0>
    5d30:	17fffff2 	b	5cf8 <fwp_rc_fresh+0x84>

0000000000005d34 <fwp_rc_free_arr>:
    5d34:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5d38:	91174063 	add	x3, x3, #0x5d0
    5d3c:	f949d861 	ldr	x1, [x3, #5040]
    5d40:	f949ec62 	ldr	x2, [x3, #5080]
    5d44:	cb010001 	sub	x1, x0, x1
    5d48:	eb02403f 	cmp	x1, x2, lsl #16
    5d4c:	54000342 	b.cs	5db4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5d50:	d350fc22 	lsr	x2, x1, #16
    5d54:	f949fc65 	ldr	x5, [x3, #5112]
    5d58:	8b020842 	add	x2, x2, x2, lsl #2
    5d5c:	d37df042 	lsl	x2, x2, #3
    5d60:	8b0200a4 	add	x4, x5, x2
    5d64:	f9401083 	ldr	x3, [x4, #32]
    5d68:	b4000263 	cbz	x3, 5db4 <fwp_rc_free_arr+0x80>
    5d6c:	386268a2 	ldrb	w2, [x5, x2]
    5d70:	7100085f 	cmp	w2, #0x2
    5d74:	540001c0 	b.eq	5dac <fwp_rc_free_arr+0x78>  // b.none
    5d78:	7100045f 	cmp	w2, #0x1
    5d7c:	540001c1 	b.ne	5db4 <fwp_rc_free_arr+0x80>  // b.any
    5d80:	29430885 	ldp	w5, w2, [x4, #24]
    5d84:	92403c21 	and	x1, x1, #0xffff
    5d88:	9b057c21 	mul	x1, x1, x5
    5d8c:	d360fc21 	lsr	x1, x1, #32
    5d90:	eb02003f 	cmp	x1, x2
    5d94:	54000102 	b.cs	5db4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5d98:	8b010063 	add	x3, x3, x1
    5d9c:	39400061 	ldrb	w1, [x3]
    5da0:	7100043f 	cmp	w1, #0x1
    5da4:	54000081 	b.ne	5db4 <fwp_rc_free_arr+0x80>  // b.any
    5da8:	17fff996 	b	4400 <fwp_mem_free>
    5dac:	72003c3f 	tst	w1, #0xffff
    5db0:	54ffff60 	b.eq	5d9c <fwp_rc_free_arr+0x68>  // b.none
    5db4:	d65f03c0 	ret
    5db8:	d503201f 	nop
    5dbc:	d503201f 	nop

0000000000005dc0 <fwp_rc_dup>:
    5dc0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5dc4:	91174042 	add	x2, x2, #0x5d0
    5dc8:	f949d841 	ldr	x1, [x2, #5040]
    5dcc:	f949ec43 	ldr	x3, [x2, #5080]
    5dd0:	cb010001 	sub	x1, x0, x1
    5dd4:	eb03403f 	cmp	x1, x3, lsl #16
    5dd8:	54000342 	b.cs	5e40 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ddc:	d350fc20 	lsr	x0, x1, #16
    5de0:	f949fc44 	ldr	x4, [x2, #5112]
    5de4:	8b000800 	add	x0, x0, x0, lsl #2
    5de8:	d37df002 	lsl	x2, x0, #3
    5dec:	8b020083 	add	x3, x4, x2
    5df0:	f9401060 	ldr	x0, [x3, #32]
    5df4:	b4000260 	cbz	x0, 5e40 <fwp_rc_dup+0x80>
    5df8:	38626882 	ldrb	w2, [x4, x2]
    5dfc:	7100085f 	cmp	w2, #0x2
    5e00:	54000220 	b.eq	5e44 <fwp_rc_dup+0x84>  // b.none
    5e04:	7100045f 	cmp	w2, #0x1
    5e08:	540001c1 	b.ne	5e40 <fwp_rc_dup+0x80>  // b.any
    5e0c:	29430864 	ldp	w4, w2, [x3, #24]
    5e10:	92403c21 	and	x1, x1, #0xffff
    5e14:	9b047c21 	mul	x1, x1, x4
    5e18:	d360fc21 	lsr	x1, x1, #32
    5e1c:	eb02003f 	cmp	x1, x2
    5e20:	54000102 	b.cs	5e40 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5e24:	8b010000 	add	x0, x0, x1
    5e28:	39400001 	ldrb	w1, [x0]
    5e2c:	340000a1 	cbz	w1, 5e40 <fwp_rc_dup+0x80>
    5e30:	7103f43f 	cmp	w1, #0xfd
    5e34:	540000e8 	b.hi	5e50 <fwp_rc_dup+0x90>  // b.pmore
    5e38:	11000421 	add	w1, w1, #0x1
    5e3c:	39000001 	strb	w1, [x0]
    5e40:	d65f03c0 	ret
    5e44:	72003c3f 	tst	w1, #0xffff
    5e48:	54ffff00 	b.eq	5e28 <fwp_rc_dup+0x68>  // b.none
    5e4c:	d65f03c0 	ret
    5e50:	17fff9e5 	b	45e4 <fwp_rc_wide_dup>

0000000000005e54 <fwp_owned_entry161>:
    5e54:	d10103ff 	sub	sp, sp, #0x40
    5e58:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5e5c:	f947f442 	ldr	x2, [x2, #4072]
    5e60:	a9027bfd 	stp	x29, x30, [sp, #32]
    5e64:	910083fd 	add	x29, sp, #0x20
    5e68:	a90353f3 	stp	x19, x20, [sp, #48]
    5e6c:	f9400043 	ldr	x3, [x2]
    5e70:	f9000fe3 	str	x3, [sp, #24]
    5e74:	d2800003 	mov	x3, #0x0                   	// #0
    5e78:	a9400c01 	ldp	x1, x3, [x0]
    5e7c:	f9400802 	ldr	x2, [x0, #16]
    5e80:	ab020022 	adds	x2, x1, x2
    5e84:	540006e6 	b.vs	5f60 <fwp_owned_entry161+0x10c>
    5e88:	910023e1 	add	x1, sp, #0x8
    5e8c:	52800000 	mov	w0, #0x0                   	// #0
    5e90:	a9008be3 	stp	x3, x2, [sp, #8]
    5e94:	97ffff0c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    5e98:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5e9c:	91174063 	add	x3, x3, #0x5d0
    5ea0:	aa0003f3 	mov	x19, x0
    5ea4:	f949d861 	ldr	x1, [x3, #5040]
    5ea8:	f949ec60 	ldr	x0, [x3, #5080]
    5eac:	cb010261 	sub	x1, x19, x1
    5eb0:	eb00403f 	cmp	x1, x0, lsl #16
    5eb4:	54000322 	b.cs	5f18 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5eb8:	d350fc22 	lsr	x2, x1, #16
    5ebc:	f949fc63 	ldr	x3, [x3, #5112]
    5ec0:	8b020842 	add	x2, x2, x2, lsl #2
    5ec4:	d37df042 	lsl	x2, x2, #3
    5ec8:	8b020060 	add	x0, x3, x2
    5ecc:	f9401014 	ldr	x20, [x0, #32]
    5ed0:	b4000254 	cbz	x20, 5f18 <fwp_owned_entry161+0xc4>
    5ed4:	38626862 	ldrb	w2, [x3, x2]
    5ed8:	7100085f 	cmp	w2, #0x2
    5edc:	54000360 	b.eq	5f48 <fwp_owned_entry161+0xf4>  // b.none
    5ee0:	7100045f 	cmp	w2, #0x1
    5ee4:	540001a1 	b.ne	5f18 <fwp_owned_entry161+0xc4>  // b.any
    5ee8:	29430002 	ldp	w2, w0, [x0, #24]
    5eec:	92403c21 	and	x1, x1, #0xffff
    5ef0:	9b027c21 	mul	x1, x1, x2
    5ef4:	d360fc21 	lsr	x1, x1, #32
    5ef8:	eb00003f 	cmp	x1, x0
    5efc:	540000e2 	b.cs	5f18 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5f00:	8b010294 	add	x20, x20, x1
    5f04:	39400280 	ldrb	w0, [x20]
    5f08:	7103fc1f 	cmp	w0, #0xff
    5f0c:	54000240 	b.eq	5f54 <fwp_owned_entry161+0x100>  // b.none
    5f10:	52800020 	mov	w0, #0x1                   	// #1
    5f14:	39000280 	strb	w0, [x20]
    5f18:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f1c:	f947f400 	ldr	x0, [x0, #4072]
    5f20:	f9400fe2 	ldr	x2, [sp, #24]
    5f24:	f9400001 	ldr	x1, [x0]
    5f28:	eb010042 	subs	x2, x2, x1
    5f2c:	d2800001 	mov	x1, #0x0                   	// #0
    5f30:	540001a1 	b.ne	5f64 <fwp_owned_entry161+0x110>  // b.any
    5f34:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f38:	aa1303e0 	mov	x0, x19
    5f3c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f40:	910103ff 	add	sp, sp, #0x40
    5f44:	d65f03c0 	ret
    5f48:	72003c3f 	tst	w1, #0xffff
    5f4c:	54fffe61 	b.ne	5f18 <fwp_owned_entry161+0xc4>  // b.any
    5f50:	17ffffed 	b	5f04 <fwp_owned_entry161+0xb0>
    5f54:	aa1403e0 	mov	x0, x20
    5f58:	97fff88e 	bl	4190 <fwp_rc_forget_slot.part.0>
    5f5c:	17ffffed 	b	5f10 <fwp_owned_entry161+0xbc>
    5f60:	97fff2c8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5f64:	97fff247 	bl	2880 <__stack_chk_fail@plt>
    5f68:	d503201f 	nop
    5f6c:	d503201f 	nop

0000000000005f70 <e161>:
    5f70:	d10103ff 	sub	sp, sp, #0x40
    5f74:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5f78:	f947f442 	ldr	x2, [x2, #4072]
    5f7c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5f80:	910083fd 	add	x29, sp, #0x20
    5f84:	a90353f3 	stp	x19, x20, [sp, #48]
    5f88:	f9400043 	ldr	x3, [x2]
    5f8c:	f9000fe3 	str	x3, [sp, #24]
    5f90:	d2800003 	mov	x3, #0x0                   	// #0
    5f94:	a9400c01 	ldp	x1, x3, [x0]
    5f98:	f9400802 	ldr	x2, [x0, #16]
    5f9c:	ab020022 	adds	x2, x1, x2
    5fa0:	54000726 	b.vs	6084 <e161+0x114>
    5fa4:	910023e1 	add	x1, sp, #0x8
    5fa8:	52800000 	mov	w0, #0x0                   	// #0
    5fac:	a9008be3 	stp	x3, x2, [sp, #8]
    5fb0:	97fffec5 	bl	5ac4 <fwp_data.part.0.constprop.0>
    5fb4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5fb8:	91174063 	add	x3, x3, #0x5d0
    5fbc:	aa0003f3 	mov	x19, x0
    5fc0:	f949d861 	ldr	x1, [x3, #5040]
    5fc4:	f949ec60 	ldr	x0, [x3, #5080]
    5fc8:	cb010261 	sub	x1, x19, x1
    5fcc:	eb00403f 	cmp	x1, x0, lsl #16
    5fd0:	54000322 	b.cs	6034 <e161+0xc4>  // b.hs, b.nlast
    5fd4:	d350fc22 	lsr	x2, x1, #16
    5fd8:	f949fc63 	ldr	x3, [x3, #5112]
    5fdc:	8b020842 	add	x2, x2, x2, lsl #2
    5fe0:	d37df042 	lsl	x2, x2, #3
    5fe4:	8b020060 	add	x0, x3, x2
    5fe8:	f9401014 	ldr	x20, [x0, #32]
    5fec:	b4000254 	cbz	x20, 6034 <e161+0xc4>
    5ff0:	38626862 	ldrb	w2, [x3, x2]
    5ff4:	7100085f 	cmp	w2, #0x2
    5ff8:	540003a0 	b.eq	606c <e161+0xfc>  // b.none
    5ffc:	7100045f 	cmp	w2, #0x1
    6000:	540001a1 	b.ne	6034 <e161+0xc4>  // b.any
    6004:	29430002 	ldp	w2, w0, [x0, #24]
    6008:	92403c21 	and	x1, x1, #0xffff
    600c:	9b027c21 	mul	x1, x1, x2
    6010:	d360fc21 	lsr	x1, x1, #32
    6014:	eb00003f 	cmp	x1, x0
    6018:	540000e2 	b.cs	6034 <e161+0xc4>  // b.hs, b.nlast
    601c:	8b010294 	add	x20, x20, x1
    6020:	39400280 	ldrb	w0, [x20]
    6024:	7103fc1f 	cmp	w0, #0xff
    6028:	54000280 	b.eq	6078 <e161+0x108>  // b.none
    602c:	52800020 	mov	w0, #0x1                   	// #1
    6030:	39000280 	strb	w0, [x20]
    6034:	aa1303e0 	mov	x0, x19
    6038:	97fffeeb 	bl	5be4 <fwp_rc_share>
    603c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6040:	f947f400 	ldr	x0, [x0, #4072]
    6044:	f9400fe2 	ldr	x2, [sp, #24]
    6048:	f9400001 	ldr	x1, [x0]
    604c:	eb010042 	subs	x2, x2, x1
    6050:	d2800001 	mov	x1, #0x0                   	// #0
    6054:	540001a1 	b.ne	6088 <e161+0x118>  // b.any
    6058:	a9427bfd 	ldp	x29, x30, [sp, #32]
    605c:	aa1303e0 	mov	x0, x19
    6060:	a94353f3 	ldp	x19, x20, [sp, #48]
    6064:	910103ff 	add	sp, sp, #0x40
    6068:	d65f03c0 	ret
    606c:	72003c3f 	tst	w1, #0xffff
    6070:	54fffe21 	b.ne	6034 <e161+0xc4>  // b.any
    6074:	17ffffeb 	b	6020 <e161+0xb0>
    6078:	aa1403e0 	mov	x0, x20
    607c:	97fff845 	bl	4190 <fwp_rc_forget_slot.part.0>
    6080:	17ffffeb 	b	602c <e161+0xbc>
    6084:	97fff27f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6088:	97fff1fe 	bl	2880 <__stack_chk_fail@plt>
    608c:	d503201f 	nop

0000000000006090 <fwp_drop0>:
    6090:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6094:	910003fd 	mov	x29, sp
    6098:	a90153f3 	stp	x19, x20, [sp, #16]
    609c:	f90013f5 	str	x21, [sp, #32]
    60a0:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    60a4:	911742b4 	add	x20, x21, #0x5d0
    60a8:	f949da81 	ldr	x1, [x20, #5040]
    60ac:	f949ee82 	ldr	x2, [x20, #5080]
    60b0:	cb010001 	sub	x1, x0, x1
    60b4:	eb02403f 	cmp	x1, x2, lsl #16
    60b8:	54000382 	b.cs	6128 <fwp_drop0+0x98>  // b.hs, b.nlast
    60bc:	d350fc22 	lsr	x2, x1, #16
    60c0:	f949fe84 	ldr	x4, [x20, #5112]
    60c4:	8b020842 	add	x2, x2, x2, lsl #2
    60c8:	d37df042 	lsl	x2, x2, #3
    60cc:	8b020083 	add	x3, x4, x2
    60d0:	f9401073 	ldr	x19, [x3, #32]
    60d4:	b40002b3 	cbz	x19, 6128 <fwp_drop0+0x98>
    60d8:	38626882 	ldrb	w2, [x4, x2]
    60dc:	7100085f 	cmp	w2, #0x2
    60e0:	540002c0 	b.eq	6138 <fwp_drop0+0xa8>  // b.none
    60e4:	7100045f 	cmp	w2, #0x1
    60e8:	54000201 	b.ne	6128 <fwp_drop0+0x98>  // b.any
    60ec:	29430864 	ldp	w4, w2, [x3, #24]
    60f0:	92403c21 	and	x1, x1, #0xffff
    60f4:	9b047c21 	mul	x1, x1, x4
    60f8:	d360fc21 	lsr	x1, x1, #32
    60fc:	eb02003f 	cmp	x1, x2
    6100:	54000142 	b.cs	6128 <fwp_drop0+0x98>  // b.hs, b.nlast
    6104:	8b010273 	add	x19, x19, x1
    6108:	39400261 	ldrb	w1, [x19]
    610c:	340000e1 	cbz	w1, 6128 <fwp_drop0+0x98>
    6110:	7100043f 	cmp	w1, #0x1
    6114:	540001e0 	b.eq	6150 <fwp_drop0+0xc0>  // b.none
    6118:	7103fc3f 	cmp	w1, #0xff
    611c:	540002e0 	b.eq	6178 <fwp_drop0+0xe8>  // b.none
    6120:	51000421 	sub	w1, w1, #0x1
    6124:	39000261 	strb	w1, [x19]
    6128:	a94153f3 	ldp	x19, x20, [sp, #16]
    612c:	f94013f5 	ldr	x21, [sp, #32]
    6130:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6134:	d65f03c0 	ret
    6138:	72003c3f 	tst	w1, #0xffff
    613c:	54fffe60 	b.eq	6108 <fwp_drop0+0x78>  // b.none
    6140:	a94153f3 	ldp	x19, x20, [sp, #16]
    6144:	f94013f5 	ldr	x21, [sp, #32]
    6148:	a8c37bfd 	ldp	x29, x30, [sp], #48
    614c:	d65f03c0 	ret
    6150:	f9400813 	ldr	x19, [x0, #16]
    6154:	97fffef8 	bl	5d34 <fwp_rc_free_arr>
    6158:	911742a0 	add	x0, x21, #0x5d0
    615c:	f949d801 	ldr	x1, [x0, #5040]
    6160:	f949ec00 	ldr	x0, [x0, #5080]
    6164:	cb010261 	sub	x1, x19, x1
    6168:	eb00403f 	cmp	x1, x0, lsl #16
    616c:	54fffde2 	b.cs	6128 <fwp_drop0+0x98>  // b.hs, b.nlast
    6170:	aa1303e0 	mov	x0, x19
    6174:	17ffffd2 	b	60bc <fwp_drop0+0x2c>
    6178:	ca534660 	eor	x0, x19, x19, lsr #17
    617c:	911742b5 	add	x21, x21, #0x5d0
    6180:	ca402400 	eor	x0, x0, x0, lsr #9
    6184:	92401c00 	and	x0, x0, #0xff
    6188:	910a2402 	add	x2, x0, #0x289
    618c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6190:	8b020ea2 	add	x2, x21, x2, lsl #3
    6194:	f94a2400 	ldr	x0, [x0, #5192]
    6198:	b50000a0 	cbnz	x0, 61ac <fwp_drop0+0x11c>
    619c:	14000013 	b	61e8 <fwp_drop0+0x158>
    61a0:	91004002 	add	x2, x0, #0x10
    61a4:	f9400800 	ldr	x0, [x0, #16]
    61a8:	b4000200 	cbz	x0, 61e8 <fwp_drop0+0x158>
    61ac:	f9400001 	ldr	x1, [x0]
    61b0:	eb13003f 	cmp	x1, x19
    61b4:	54ffff61 	b.ne	61a0 <fwp_drop0+0x110>  // b.any
    61b8:	f9400041 	ldr	x1, [x2]
    61bc:	f9400420 	ldr	x0, [x1, #8]
    61c0:	d1000400 	sub	x0, x0, #0x1
    61c4:	f9000420 	str	x0, [x1, #8]
    61c8:	f103f81f 	cmp	x0, #0xfe
    61cc:	54fffae1 	b.ne	6128 <fwp_drop0+0x98>  // b.any
    61d0:	39400260 	ldrb	w0, [x19]
    61d4:	7103fc1f 	cmp	w0, #0xff
    61d8:	540000e0 	b.eq	61f4 <fwp_drop0+0x164>  // b.none
    61dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61e0:	39000260 	strb	w0, [x19]
    61e4:	17ffffd1 	b	6128 <fwp_drop0+0x98>
    61e8:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    61ec:	9134e000 	add	x0, x0, #0xd38
    61f0:	97fff7c8 	bl	4110 <fwp_trap>
    61f4:	aa1303e0 	mov	x0, x19
    61f8:	97fff7e6 	bl	4190 <fwp_rc_forget_slot.part.0>
    61fc:	17fffff8 	b	61dc <fwp_drop0+0x14c>

0000000000006200 <fwp_arg_drop12>:
    6200:	7100003f 	cmp	w1, #0x0
    6204:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6208:	54000041 	b.ne	6210 <fwp_arg_drop12+0x10>  // b.any
    620c:	d65f03c0 	ret
    6210:	f9400000 	ldr	x0, [x0]
    6214:	17ffff9f 	b	6090 <fwp_drop0>
    6218:	d503201f 	nop
    621c:	d503201f 	nop

0000000000006220 <fwp_drop1>:
    6220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6224:	910003fd 	mov	x29, sp
    6228:	a90153f3 	stp	x19, x20, [sp, #16]
    622c:	f90013f5 	str	x21, [sp, #32]
    6230:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    6234:	911742b4 	add	x20, x21, #0x5d0
    6238:	f949da81 	ldr	x1, [x20, #5040]
    623c:	f949ee82 	ldr	x2, [x20, #5080]
    6240:	cb010001 	sub	x1, x0, x1
    6244:	eb02403f 	cmp	x1, x2, lsl #16
    6248:	54000382 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    624c:	d350fc22 	lsr	x2, x1, #16
    6250:	f949fe84 	ldr	x4, [x20, #5112]
    6254:	8b020842 	add	x2, x2, x2, lsl #2
    6258:	d37df042 	lsl	x2, x2, #3
    625c:	8b020083 	add	x3, x4, x2
    6260:	f9401073 	ldr	x19, [x3, #32]
    6264:	b40002b3 	cbz	x19, 62b8 <fwp_drop1+0x98>
    6268:	38626882 	ldrb	w2, [x4, x2]
    626c:	7100085f 	cmp	w2, #0x2
    6270:	540002c0 	b.eq	62c8 <fwp_drop1+0xa8>  // b.none
    6274:	7100045f 	cmp	w2, #0x1
    6278:	54000201 	b.ne	62b8 <fwp_drop1+0x98>  // b.any
    627c:	29430864 	ldp	w4, w2, [x3, #24]
    6280:	92403c21 	and	x1, x1, #0xffff
    6284:	9b047c21 	mul	x1, x1, x4
    6288:	d360fc21 	lsr	x1, x1, #32
    628c:	eb02003f 	cmp	x1, x2
    6290:	54000142 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6294:	8b010273 	add	x19, x19, x1
    6298:	39400261 	ldrb	w1, [x19]
    629c:	340000e1 	cbz	w1, 62b8 <fwp_drop1+0x98>
    62a0:	7100043f 	cmp	w1, #0x1
    62a4:	540001e0 	b.eq	62e0 <fwp_drop1+0xc0>  // b.none
    62a8:	7103fc3f 	cmp	w1, #0xff
    62ac:	540002e0 	b.eq	6308 <fwp_drop1+0xe8>  // b.none
    62b0:	51000421 	sub	w1, w1, #0x1
    62b4:	39000261 	strb	w1, [x19]
    62b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62bc:	f94013f5 	ldr	x21, [sp, #32]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	d65f03c0 	ret
    62c8:	72003c3f 	tst	w1, #0xffff
    62cc:	54fffe60 	b.eq	6298 <fwp_drop1+0x78>  // b.none
    62d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    62d4:	f94013f5 	ldr	x21, [sp, #32]
    62d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62dc:	d65f03c0 	ret
    62e0:	f9400813 	ldr	x19, [x0, #16]
    62e4:	97fffe94 	bl	5d34 <fwp_rc_free_arr>
    62e8:	911742a0 	add	x0, x21, #0x5d0
    62ec:	f949d801 	ldr	x1, [x0, #5040]
    62f0:	f949ec00 	ldr	x0, [x0, #5080]
    62f4:	cb010261 	sub	x1, x19, x1
    62f8:	eb00403f 	cmp	x1, x0, lsl #16
    62fc:	54fffde2 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6300:	aa1303e0 	mov	x0, x19
    6304:	17ffffd2 	b	624c <fwp_drop1+0x2c>
    6308:	ca534660 	eor	x0, x19, x19, lsr #17
    630c:	911742b5 	add	x21, x21, #0x5d0
    6310:	ca402400 	eor	x0, x0, x0, lsr #9
    6314:	92401c00 	and	x0, x0, #0xff
    6318:	910a2402 	add	x2, x0, #0x289
    631c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6320:	8b020ea2 	add	x2, x21, x2, lsl #3
    6324:	f94a2400 	ldr	x0, [x0, #5192]
    6328:	b50000a0 	cbnz	x0, 633c <fwp_drop1+0x11c>
    632c:	14000013 	b	6378 <fwp_drop1+0x158>
    6330:	91004002 	add	x2, x0, #0x10
    6334:	f9400800 	ldr	x0, [x0, #16]
    6338:	b4000200 	cbz	x0, 6378 <fwp_drop1+0x158>
    633c:	f9400001 	ldr	x1, [x0]
    6340:	eb13003f 	cmp	x1, x19
    6344:	54ffff61 	b.ne	6330 <fwp_drop1+0x110>  // b.any
    6348:	f9400041 	ldr	x1, [x2]
    634c:	f9400420 	ldr	x0, [x1, #8]
    6350:	d1000400 	sub	x0, x0, #0x1
    6354:	f9000420 	str	x0, [x1, #8]
    6358:	f103f81f 	cmp	x0, #0xfe
    635c:	54fffae1 	b.ne	62b8 <fwp_drop1+0x98>  // b.any
    6360:	39400260 	ldrb	w0, [x19]
    6364:	7103fc1f 	cmp	w0, #0xff
    6368:	540000e0 	b.eq	6384 <fwp_drop1+0x164>  // b.none
    636c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6370:	39000260 	strb	w0, [x19]
    6374:	17ffffd1 	b	62b8 <fwp_drop1+0x98>
    6378:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    637c:	9134e000 	add	x0, x0, #0xd38
    6380:	97fff764 	bl	4110 <fwp_trap>
    6384:	aa1303e0 	mov	x0, x19
    6388:	97fff782 	bl	4190 <fwp_rc_forget_slot.part.0>
    638c:	17fffff8 	b	636c <fwp_drop1+0x14c>

0000000000006390 <fwp_closure_drop>:
    6390:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    6394:	911740a4 	add	x4, x5, #0x5d0
    6398:	aa0003e1 	mov	x1, x0
    639c:	f949d882 	ldr	x2, [x4, #5040]
    63a0:	f949ec80 	ldr	x0, [x4, #5080]
    63a4:	cb020022 	sub	x2, x1, x2
    63a8:	eb00405f 	cmp	x2, x0, lsl #16
    63ac:	54000662 	b.cs	6478 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    63b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63b4:	d350fc43 	lsr	x3, x2, #16
    63b8:	910003fd 	mov	x29, sp
    63bc:	8b030863 	add	x3, x3, x3, lsl #2
    63c0:	f949fc84 	ldr	x4, [x4, #5112]
    63c4:	d37df063 	lsl	x3, x3, #3
    63c8:	f9000bf3 	str	x19, [sp, #16]
    63cc:	8b030080 	add	x0, x4, x3
    63d0:	f9401013 	ldr	x19, [x0, #32]
    63d4:	b40002b3 	cbz	x19, 6428 <fwp_closure_drop+0x98>
    63d8:	38636883 	ldrb	w3, [x4, x3]
    63dc:	7100087f 	cmp	w3, #0x2
    63e0:	54000420 	b.eq	6464 <fwp_closure_drop+0xd4>  // b.none
    63e4:	7100047f 	cmp	w3, #0x1
    63e8:	54000201 	b.ne	6428 <fwp_closure_drop+0x98>  // b.any
    63ec:	29430003 	ldp	w3, w0, [x0, #24]
    63f0:	92403c42 	and	x2, x2, #0xffff
    63f4:	9b037c42 	mul	x2, x2, x3
    63f8:	d360fc42 	lsr	x2, x2, #32
    63fc:	eb00005f 	cmp	x2, x0
    6400:	54000142 	b.cs	6428 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6404:	8b020273 	add	x19, x19, x2
    6408:	39400260 	ldrb	w0, [x19]
    640c:	340000e0 	cbz	w0, 6428 <fwp_closure_drop+0x98>
    6410:	7100041f 	cmp	w0, #0x1
    6414:	54000100 	b.eq	6434 <fwp_closure_drop+0xa4>  // b.none
    6418:	7103fc1f 	cmp	w0, #0xff
    641c:	54000300 	b.eq	647c <fwp_closure_drop+0xec>  // b.none
    6420:	51000400 	sub	w0, w0, #0x1
    6424:	39000260 	strb	w0, [x19]
    6428:	f9400bf3 	ldr	x19, [sp, #16]
    642c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6430:	d65f03c0 	ret
    6434:	d53bd040 	mrs	x0, tpidr_el0
    6438:	91400000 	add	x0, x0, #0x0, lsl #12
    643c:	91004000 	add	x0, x0, #0x10
    6440:	f9400000 	ldr	x0, [x0]
    6444:	b4000080 	cbz	x0, 6454 <fwp_closure_drop+0xc4>
    6448:	f9400bf3 	ldr	x19, [sp, #16]
    644c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6450:	17fff8ac 	b	4700 <fwp_closure_drop_push>
    6454:	f9400bf3 	ldr	x19, [sp, #16]
    6458:	aa0103e0 	mov	x0, x1
    645c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6460:	17fff8ed 	b	4814 <fwp_closure_drop.part.0>
    6464:	72003c5f 	tst	w2, #0xffff
    6468:	54fffd00 	b.eq	6408 <fwp_closure_drop+0x78>  // b.none
    646c:	f9400bf3 	ldr	x19, [sp, #16]
    6470:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6474:	d65f03c0 	ret
    6478:	d65f03c0 	ret
    647c:	ca534660 	eor	x0, x19, x19, lsr #17
    6480:	911740a5 	add	x5, x5, #0x5d0
    6484:	ca402400 	eor	x0, x0, x0, lsr #9
    6488:	92401c00 	and	x0, x0, #0xff
    648c:	910a2402 	add	x2, x0, #0x289
    6490:	8b000ca0 	add	x0, x5, x0, lsl #3
    6494:	8b020ca2 	add	x2, x5, x2, lsl #3
    6498:	f94a2400 	ldr	x0, [x0, #5192]
    649c:	b50000a0 	cbnz	x0, 64b0 <fwp_closure_drop+0x120>
    64a0:	14000013 	b	64ec <fwp_closure_drop+0x15c>
    64a4:	91004002 	add	x2, x0, #0x10
    64a8:	f9400800 	ldr	x0, [x0, #16]
    64ac:	b4000200 	cbz	x0, 64ec <fwp_closure_drop+0x15c>
    64b0:	f9400001 	ldr	x1, [x0]
    64b4:	eb13003f 	cmp	x1, x19
    64b8:	54ffff61 	b.ne	64a4 <fwp_closure_drop+0x114>  // b.any
    64bc:	f9400041 	ldr	x1, [x2]
    64c0:	f9400420 	ldr	x0, [x1, #8]
    64c4:	d1000400 	sub	x0, x0, #0x1
    64c8:	f9000420 	str	x0, [x1, #8]
    64cc:	f103f81f 	cmp	x0, #0xfe
    64d0:	54fffac1 	b.ne	6428 <fwp_closure_drop+0x98>  // b.any
    64d4:	39400260 	ldrb	w0, [x19]
    64d8:	7103fc1f 	cmp	w0, #0xff
    64dc:	540000e0 	b.eq	64f8 <fwp_closure_drop+0x168>  // b.none
    64e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64e4:	39000260 	strb	w0, [x19]
    64e8:	17ffffd0 	b	6428 <fwp_closure_drop+0x98>
    64ec:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    64f0:	9134e000 	add	x0, x0, #0xd38
    64f4:	97fff707 	bl	4110 <fwp_trap>
    64f8:	aa1303e0 	mov	x0, x19
    64fc:	97fff725 	bl	4190 <fwp_rc_forget_slot.part.0>
    6500:	17fffff8 	b	64e0 <fwp_closure_drop+0x150>

0000000000006504 <fwp_owned_tape_release>:
    6504:	b4000920 	cbz	x0, 6628 <fwp_owned_tape_release+0x124>
    6508:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    650c:	910003fd 	mov	x29, sp
    6510:	a90153f3 	stp	x19, x20, [sp, #16]
    6514:	aa0003f3 	mov	x19, x0
    6518:	f9400000 	ldr	x0, [x0]
    651c:	b4000060 	cbz	x0, 6528 <fwp_owned_tape_release+0x24>
    6520:	f9400661 	ldr	x1, [x19, #8]
    6524:	f9000401 	str	x1, [x0, #8]
    6528:	f9400661 	ldr	x1, [x19, #8]
    652c:	b4000041 	cbz	x1, 6534 <fwp_owned_tape_release+0x30>
    6530:	f9000020 	str	x0, [x1]
    6534:	f9400a60 	ldr	x0, [x19, #16]
    6538:	f9403401 	ldr	x1, [x0, #104]
    653c:	b40005a1 	cbz	x1, 65f0 <fwp_owned_tape_release+0xec>
    6540:	a9450a60 	ldp	x0, x2, [x19, #80]
    6544:	eb00005f 	cmp	x2, x0
    6548:	540002cd 	b.le	65a0 <fwp_owned_tape_release+0x9c>
    654c:	d2800014 	mov	x20, #0x0                   	// #0
    6550:	f90013f5 	str	x21, [sp, #32]
    6554:	d2800015 	mov	x21, #0x0                   	// #0
    6558:	f9402260 	ldr	x0, [x19, #64]
    655c:	910006b5 	add	x21, x21, #0x1
    6560:	f8746800 	ldr	x0, [x0, x20]
    6564:	d63f0020 	blr	x1
    6568:	f9402260 	ldr	x0, [x19, #64]
    656c:	f9400a61 	ldr	x1, [x19, #16]
    6570:	8b140000 	add	x0, x0, x20
    6574:	91004294 	add	x20, x20, #0x10
    6578:	f9400400 	ldr	x0, [x0, #8]
    657c:	f9403421 	ldr	x1, [x1, #104]
    6580:	d63f0020 	blr	x1
    6584:	a9450261 	ldp	x1, x0, [x19, #80]
    6588:	cb010000 	sub	x0, x0, x1
    658c:	eb15001f 	cmp	x0, x21
    6590:	f9400a60 	ldr	x0, [x19, #16]
    6594:	f9403401 	ldr	x1, [x0, #104]
    6598:	54fffe0c 	b.gt	6558 <fwp_owned_tape_release+0x54>
    659c:	f94013f5 	ldr	x21, [sp, #32]
    65a0:	f9403663 	ldr	x3, [x19, #104]
    65a4:	f9401262 	ldr	x2, [x19, #32]
    65a8:	f100007f 	cmp	x3, #0x0
    65ac:	540001ed 	b.le	65e8 <fwp_owned_tape_release+0xe4>
    65b0:	d2800014 	mov	x20, #0x0                   	// #0
    65b4:	d503201f 	nop
    65b8:	f9402660 	ldr	x0, [x19, #72]
    65bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    65c0:	eb02001f 	cmp	x0, x2
    65c4:	540000c0 	b.eq	65dc <fwp_owned_tape_release+0xd8>  // b.none
    65c8:	d63f0020 	blr	x1
    65cc:	f9400a60 	ldr	x0, [x19, #16]
    65d0:	f9401262 	ldr	x2, [x19, #32]
    65d4:	f9403663 	ldr	x3, [x19, #104]
    65d8:	f9403401 	ldr	x1, [x0, #104]
    65dc:	91000694 	add	x20, x20, #0x1
    65e0:	eb14007f 	cmp	x3, x20
    65e4:	54fffeac 	b.gt	65b8 <fwp_owned_tape_release+0xb4>
    65e8:	aa0203e0 	mov	x0, x2
    65ec:	d63f0020 	blr	x1
    65f0:	f9401660 	ldr	x0, [x19, #40]
    65f4:	97ffff67 	bl	6390 <fwp_closure_drop>
    65f8:	f9401a60 	ldr	x0, [x19, #48]
    65fc:	97ffff65 	bl	6390 <fwp_closure_drop>
    6600:	f9401e60 	ldr	x0, [x19, #56]
    6604:	97ffff63 	bl	6390 <fwp_closure_drop>
    6608:	f9402260 	ldr	x0, [x19, #64]
    660c:	97fff77d 	bl	4400 <fwp_mem_free>
    6610:	f9402660 	ldr	x0, [x19, #72]
    6614:	97fff77b 	bl	4400 <fwp_mem_free>
    6618:	aa1303e0 	mov	x0, x19
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6624:	17fff777 	b	4400 <fwp_mem_free>
    6628:	d65f03c0 	ret
    662c:	d503201f 	nop

0000000000006630 <fwp_tape_finish>:
    6630:	d10203ff 	sub	sp, sp, #0x80
    6634:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6638:	f947f421 	ldr	x1, [x1, #4072]
    663c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6640:	910103fd 	add	x29, sp, #0x40
    6644:	a90553f3 	stp	x19, x20, [sp, #80]
    6648:	a9065bf5 	stp	x21, x22, [sp, #96]
    664c:	a90763f7 	stp	x23, x24, [sp, #112]
    6650:	d00000d8 	adrp	x24, 20000 <__data_start>
    6654:	9101c316 	add	x22, x24, #0x70
    6658:	f9400022 	ldr	x2, [x1]
    665c:	f9001fe2 	str	x2, [sp, #56]
    6660:	d2800002 	mov	x2, #0x0                   	// #0
    6664:	910222c0 	add	x0, x22, #0x88
    6668:	97fff386 	bl	3480 <fwp_tape_buffers_dispose>
    666c:	f90062df 	str	xzr, [x22, #192]
    6670:	f9406ac0 	ldr	x0, [x22, #208]
    6674:	f100001f 	cmp	x0, #0x0
    6678:	5400030d 	b.le	66d8 <fwp_tape_finish+0xa8>
    667c:	910003f7 	mov	x23, sp
    6680:	d2800015 	mov	x21, #0x0                   	// #0
    6684:	d2800014 	mov	x20, #0x0                   	// #0
    6688:	f94002d3 	ldr	x19, [x22]
    668c:	91000694 	add	x20, x20, #0x1
    6690:	8b150273 	add	x19, x19, x21
    6694:	9101a2b5 	add	x21, x21, #0x68
    6698:	aa1303e0 	mov	x0, x19
    669c:	97fff23d 	bl	2f90 <fwp_tape_unlink_scope>
    66a0:	aa1703e0 	mov	x0, x23
    66a4:	f9401261 	ldr	x1, [x19, #32]
    66a8:	f90003e1 	str	x1, [sp]
    66ac:	f9401a62 	ldr	x2, [x19, #48]
    66b0:	f9000be2 	str	x2, [sp, #16]
    66b4:	f9402261 	ldr	x1, [x19, #64]
    66b8:	f90013e1 	str	x1, [sp, #32]
    66bc:	97fff371 	bl	3480 <fwp_tape_buffers_dispose>
    66c0:	f9403260 	ldr	x0, [x19, #96]
    66c4:	97ffff90 	bl	6504 <fwp_owned_tape_release>
    66c8:	f900327f 	str	xzr, [x19, #96]
    66cc:	f9406ac0 	ldr	x0, [x22, #208]
    66d0:	eb14001f 	cmp	x0, x20
    66d4:	54fffdac 	b.gt	6688 <fwp_tape_finish+0x58>
    66d8:	f9403b00 	ldr	x0, [x24, #112]
    66dc:	9101c313 	add	x19, x24, #0x70
    66e0:	97fff098 	bl	2940 <free@plt>
    66e4:	f9003b1f 	str	xzr, [x24, #112]
    66e8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    66ec:	f947f400 	ldr	x0, [x0, #4072]
    66f0:	f9006a7f 	str	xzr, [x19, #208]
    66f4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    66f8:	f9401fe2 	ldr	x2, [sp, #56]
    66fc:	f9400001 	ldr	x1, [x0]
    6700:	eb010042 	subs	x2, x2, x1
    6704:	d2800001 	mov	x1, #0x0                   	// #0
    6708:	540000e1 	b.ne	6724 <fwp_tape_finish+0xf4>  // b.any
    670c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6710:	a94553f3 	ldp	x19, x20, [sp, #80]
    6714:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6718:	a94763f7 	ldp	x23, x24, [sp, #112]
    671c:	910203ff 	add	sp, sp, #0x80
    6720:	d65f03c0 	ret
    6724:	97fff057 	bl	2880 <__stack_chk_fail@plt>
    6728:	d503201f 	nop
    672c:	d503201f 	nop

0000000000006730 <fwp_tape_scope_release>:
    6730:	d10243ff 	sub	sp, sp, #0x90
    6734:	a9047bfd 	stp	x29, x30, [sp, #64]
    6738:	910103fd 	add	x29, sp, #0x40
    673c:	a90553f3 	stp	x19, x20, [sp, #80]
    6740:	aa0003f4 	mov	x20, x0
    6744:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6748:	f947f400 	ldr	x0, [x0, #4072]
    674c:	b9400285 	ldr	w5, [x20]
    6750:	f9400001 	ldr	x1, [x0]
    6754:	f9001fe1 	str	x1, [sp, #56]
    6758:	d2800001 	mov	x1, #0x0                   	// #0
    675c:	37f806c5 	tbnz	w5, #31, 6834 <fwp_tape_scope_release+0x104>
    6760:	a90763f7 	stp	x23, x24, [sp, #112]
    6764:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6768:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    676c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6770:	d00000d3 	adrp	x19, 20000 <__data_start>
    6774:	910003f7 	mov	x23, sp
    6778:	9101c273 	add	x19, x19, #0x70
    677c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6780:	a9065bf5 	stp	x21, x22, [sp, #96]
    6784:	52800d16 	mov	w22, #0x68                  	// #104
    6788:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    678c:	f90043f9 	str	x25, [sp, #128]
    6790:	14000006 	b	67a8 <fwp_tape_scope_release+0x78>
    6794:	97fff33b 	bl	3480 <fwp_tape_buffers_dispose>
    6798:	aa1903e0 	mov	x0, x25
    679c:	97ffff5a 	bl	6504 <fwp_owned_tape_release>
    67a0:	b9400285 	ldr	w5, [x20]
    67a4:	37f80425 	tbnz	w5, #31, 6828 <fwp_tape_scope_release+0xf8>
    67a8:	f9400266 	ldr	x6, [x19]
    67ac:	9b367ca5 	smull	x5, w5, w22
    67b0:	8b0500c0 	add	x0, x6, x5
    67b4:	97fff1f7 	bl	2f90 <fwp_tape_unlink_scope>
    67b8:	ad410001 	ldp	q1, q0, [x0, #32]
    67bc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    67c0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    67c4:	f9400c03 	ldr	x3, [x0, #24]
    67c8:	ad0003e1 	stp	q1, q0, [sp]
    67cc:	b86568c1 	ldr	w1, [x6, x5]
    67d0:	a9440804 	ldp	x4, x2, [x0, #64]
    67d4:	b900041f 	str	wzr, [x0, #4]
    67d8:	f9403019 	ldr	x25, [x0, #96]
    67dc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    67e0:	f9000c1f 	str	xzr, [x0, #24]
    67e4:	a9020fe4 	stp	x4, x3, [sp, #32]
    67e8:	f9001be2 	str	x2, [sp, #48]
    67ec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    67f0:	f900301f 	str	xzr, [x0, #96]
    67f4:	6b15003f 	cmp	w1, w21
    67f8:	540000e8 	b.hi	6814 <fwp_tape_scope_release+0xe4>  // b.pmore
    67fc:	9343fca5 	asr	x5, x5, #3
    6800:	f9407660 	ldr	x0, [x19, #232]
    6804:	9b187ca5 	mul	x5, x5, x24
    6808:	eb0000bf 	cmp	x5, x0
    680c:	5400004a 	b.ge	6814 <fwp_tape_scope_release+0xe4>  // b.tcont
    6810:	f9007665 	str	x5, [x19, #232]
    6814:	aa1703e0 	mov	x0, x23
    6818:	b5fffbf9 	cbnz	x25, 6794 <fwp_tape_scope_release+0x64>
    681c:	97fff5f5 	bl	3ff0 <fwp_tape_buffers_release>
    6820:	b9400285 	ldr	w5, [x20]
    6824:	36fffc25 	tbz	w5, #31, 67a8 <fwp_tape_scope_release+0x78>
    6828:	a9465bf5 	ldp	x21, x22, [sp, #96]
    682c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6830:	f94043f9 	ldr	x25, [sp, #128]
    6834:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6838:	f947f400 	ldr	x0, [x0, #4072]
    683c:	f9401fe2 	ldr	x2, [sp, #56]
    6840:	f9400001 	ldr	x1, [x0]
    6844:	eb010042 	subs	x2, x2, x1
    6848:	d2800001 	mov	x1, #0x0                   	// #0
    684c:	540000a1 	b.ne	6860 <fwp_tape_scope_release+0x130>  // b.any
    6850:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6854:	a94553f3 	ldp	x19, x20, [sp, #80]
    6858:	910243ff 	add	sp, sp, #0x90
    685c:	d65f03c0 	ret
    6860:	a9065bf5 	stp	x21, x22, [sp, #96]
    6864:	a90763f7 	stp	x23, x24, [sp, #112]
    6868:	f90043f9 	str	x25, [sp, #128]
    686c:	97fff005 	bl	2880 <__stack_chk_fail@plt>

0000000000006870 <fwp_task_dispose>:
    6870:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6874:	910003fd 	mov	x29, sp
    6878:	f9000bf3 	str	x19, [sp, #16]
    687c:	aa0003f3 	mov	x19, x0
    6880:	39414000 	ldrb	w0, [x0, #80]
    6884:	36000720 	tbz	w0, #0, 6968 <fwp_task_dispose+0xf8>
    6888:	f9400a60 	ldr	x0, [x19, #16]
    688c:	b50006e0 	cbnz	x0, 6968 <fwp_task_dispose+0xf8>
    6890:	a9478660 	ldp	x0, x1, [x19, #120]
    6894:	39014e7f 	strb	wzr, [x19, #83]
    6898:	f9003e7f 	str	xzr, [x19, #120]
    689c:	f100003f 	cmp	x1, #0x0
    68a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    68a4:	54000040 	b.eq	68ac <fwp_task_dispose+0x3c>  // b.none
    68a8:	d63f0020 	blr	x1
    68ac:	f9405660 	ldr	x0, [x19, #168]
    68b0:	97fff6d4 	bl	4400 <fwp_mem_free>
    68b4:	f900567f 	str	xzr, [x19, #168]
    68b8:	b9405e60 	ldr	w0, [x19, #92]
    68bc:	7100041f 	cmp	w0, #0x1
    68c0:	54000420 	b.eq	6944 <fwp_task_dispose+0xd4>  // b.none
    68c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    68c8:	91174042 	add	x2, x2, #0x5d0
    68cc:	f949d840 	ldr	x0, [x2, #5040]
    68d0:	f949ec41 	ldr	x1, [x2, #5080]
    68d4:	cb000260 	sub	x0, x19, x0
    68d8:	eb01401f 	cmp	x0, x1, lsl #16
    68dc:	540002e2 	b.cs	6938 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    68e0:	d350fc01 	lsr	x1, x0, #16
    68e4:	f949fc44 	ldr	x4, [x2, #5112]
    68e8:	8b010821 	add	x1, x1, x1, lsl #2
    68ec:	d37df021 	lsl	x1, x1, #3
    68f0:	8b010083 	add	x3, x4, x1
    68f4:	f9401062 	ldr	x2, [x3, #32]
    68f8:	b4000202 	cbz	x2, 6938 <fwp_task_dispose+0xc8>
    68fc:	38616881 	ldrb	w1, [x4, x1]
    6900:	7100083f 	cmp	w1, #0x2
    6904:	54000280 	b.eq	6954 <fwp_task_dispose+0xe4>  // b.none
    6908:	7100043f 	cmp	w1, #0x1
    690c:	54000161 	b.ne	6938 <fwp_task_dispose+0xc8>  // b.any
    6910:	29430464 	ldp	w4, w1, [x3, #24]
    6914:	92403c00 	and	x0, x0, #0xffff
    6918:	9b047c00 	mul	x0, x0, x4
    691c:	d360fc00 	lsr	x0, x0, #32
    6920:	eb01001f 	cmp	x0, x1
    6924:	540000a2 	b.cs	6938 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6928:	8b000042 	add	x2, x2, x0
    692c:	39400040 	ldrb	w0, [x2]
    6930:	7100041f 	cmp	w0, #0x1
    6934:	54000080 	b.eq	6944 <fwp_task_dispose+0xd4>  // b.none
    6938:	f9400bf3 	ldr	x19, [sp, #16]
    693c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6940:	d65f03c0 	ret
    6944:	aa1303e0 	mov	x0, x19
    6948:	f9400bf3 	ldr	x19, [sp, #16]
    694c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6950:	17fff6ac 	b	4400 <fwp_mem_free>
    6954:	72003c1f 	tst	w0, #0xffff
    6958:	54fffea0 	b.eq	692c <fwp_task_dispose+0xbc>  // b.none
    695c:	f9400bf3 	ldr	x19, [sp, #16]
    6960:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6964:	d65f03c0 	ret
    6968:	97ffefda 	bl	28d0 <abort@plt>
    696c:	d503201f 	nop

0000000000006970 <fwp_free_zombie>:
    6970:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6974:	910003fd 	mov	x29, sp
    6978:	a90153f3 	stp	x19, x20, [sp, #16]
    697c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6980:	9101c281 	add	x1, x20, #0x70
    6984:	f9407833 	ldr	x19, [x1, #240]
    6988:	b4000333 	cbz	x19, 69ec <fwp_free_zombie+0x7c>
    698c:	f9400820 	ldr	x0, [x1, #16]
    6990:	eb00027f 	cmp	x19, x0
    6994:	540002c0 	b.eq	69ec <fwp_free_zombie+0x7c>  // b.none
    6998:	b940f822 	ldr	w2, [x1, #248]
    699c:	f9400a60 	ldr	x0, [x19, #16]
    69a0:	7100fc5f 	cmp	w2, #0x3f
    69a4:	5400078c 	b.gt	6a94 <fwp_free_zombie+0x124>
    69a8:	91040023 	add	x3, x1, #0x100
    69ac:	11000444 	add	w4, w2, #0x1
    69b0:	b900f824 	str	w4, [x1, #248]
    69b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    69bc:	a9530261 	ldp	x1, x0, [x19, #304]
    69c0:	b4000741 	cbz	x1, 6aa8 <fwp_free_zombie+0x138>
    69c4:	f9009c20 	str	x0, [x1, #312]
    69c8:	b4000040 	cbz	x0, 69d0 <fwp_free_zombie+0x60>
    69cc:	f9009801 	str	x1, [x0, #304]
    69d0:	9101c294 	add	x20, x20, #0x70
    69d4:	b9405e60 	ldr	w0, [x19, #92]
    69d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    69dc:	f9007a9f 	str	xzr, [x20, #240]
    69e0:	34000140 	cbz	w0, 6a08 <fwp_free_zombie+0x98>
    69e4:	7100041f 	cmp	w0, #0x1
    69e8:	54000080 	b.eq	69f8 <fwp_free_zombie+0x88>  // b.none
    69ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    69f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69f4:	d65f03c0 	ret
    69f8:	aa1303e0 	mov	x0, x19
    69fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a04:	17ffff9b 	b	6870 <fwp_task_dispose>
    6a08:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    6a0c:	91174082 	add	x2, x4, #0x5d0
    6a10:	f949d841 	ldr	x1, [x2, #5040]
    6a14:	f949ec40 	ldr	x0, [x2, #5080]
    6a18:	cb010261 	sub	x1, x19, x1
    6a1c:	eb00403f 	cmp	x1, x0, lsl #16
    6a20:	54fffe62 	b.cs	69ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a24:	d350fc20 	lsr	x0, x1, #16
    6a28:	f949fc43 	ldr	x3, [x2, #5112]
    6a2c:	8b000800 	add	x0, x0, x0, lsl #2
    6a30:	d37df000 	lsl	x0, x0, #3
    6a34:	8b000062 	add	x2, x3, x0
    6a38:	f9401054 	ldr	x20, [x2, #32]
    6a3c:	b4fffd94 	cbz	x20, 69ec <fwp_free_zombie+0x7c>
    6a40:	38606860 	ldrb	w0, [x3, x0]
    6a44:	7100081f 	cmp	w0, #0x2
    6a48:	54000360 	b.eq	6ab4 <fwp_free_zombie+0x144>  // b.none
    6a4c:	7100041f 	cmp	w0, #0x1
    6a50:	54fffce1 	b.ne	69ec <fwp_free_zombie+0x7c>  // b.any
    6a54:	29430043 	ldp	w3, w0, [x2, #24]
    6a58:	92403c21 	and	x1, x1, #0xffff
    6a5c:	9b037c21 	mul	x1, x1, x3
    6a60:	d360fc21 	lsr	x1, x1, #32
    6a64:	eb00003f 	cmp	x1, x0
    6a68:	54fffc22 	b.cs	69ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a6c:	8b010294 	add	x20, x20, x1
    6a70:	39400280 	ldrb	w0, [x20]
    6a74:	34fffbc0 	cbz	w0, 69ec <fwp_free_zombie+0x7c>
    6a78:	7100041f 	cmp	w0, #0x1
    6a7c:	54fffbe0 	b.eq	69f8 <fwp_free_zombie+0x88>  // b.none
    6a80:	7103fc1f 	cmp	w0, #0xff
    6a84:	540001e0 	b.eq	6ac0 <fwp_free_zombie+0x150>  // b.none
    6a88:	51000400 	sub	w0, w0, #0x1
    6a8c:	39000280 	strb	w0, [x20]
    6a90:	17ffffd7 	b	69ec <fwp_free_zombie+0x7c>
    6a94:	f9400e61 	ldr	x1, [x19, #24]
    6a98:	97ffefc2 	bl	29a0 <munmap@plt>
    6a9c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6aa0:	a9530261 	ldp	x1, x0, [x19, #304]
    6aa4:	b5fff901 	cbnz	x1, 69c4 <fwp_free_zombie+0x54>
    6aa8:	9101c282 	add	x2, x20, #0x70
    6aac:	f9018040 	str	x0, [x2, #768]
    6ab0:	17ffffc6 	b	69c8 <fwp_free_zombie+0x58>
    6ab4:	72003c3f 	tst	w1, #0xffff
    6ab8:	54fff9a1 	b.ne	69ec <fwp_free_zombie+0x7c>  // b.any
    6abc:	17ffffed 	b	6a70 <fwp_free_zombie+0x100>
    6ac0:	ca544680 	eor	x0, x20, x20, lsr #17
    6ac4:	91174084 	add	x4, x4, #0x5d0
    6ac8:	ca402400 	eor	x0, x0, x0, lsr #9
    6acc:	92401c00 	and	x0, x0, #0xff
    6ad0:	910a2402 	add	x2, x0, #0x289
    6ad4:	8b000c80 	add	x0, x4, x0, lsl #3
    6ad8:	8b020c82 	add	x2, x4, x2, lsl #3
    6adc:	f94a2400 	ldr	x0, [x0, #5192]
    6ae0:	b50000a0 	cbnz	x0, 6af4 <fwp_free_zombie+0x184>
    6ae4:	14000013 	b	6b30 <fwp_free_zombie+0x1c0>
    6ae8:	91004002 	add	x2, x0, #0x10
    6aec:	f9400800 	ldr	x0, [x0, #16]
    6af0:	b4000200 	cbz	x0, 6b30 <fwp_free_zombie+0x1c0>
    6af4:	f9400001 	ldr	x1, [x0]
    6af8:	eb14003f 	cmp	x1, x20
    6afc:	54ffff61 	b.ne	6ae8 <fwp_free_zombie+0x178>  // b.any
    6b00:	f9400041 	ldr	x1, [x2]
    6b04:	f9400420 	ldr	x0, [x1, #8]
    6b08:	d1000400 	sub	x0, x0, #0x1
    6b0c:	f9000420 	str	x0, [x1, #8]
    6b10:	f103f81f 	cmp	x0, #0xfe
    6b14:	54fff6c1 	b.ne	69ec <fwp_free_zombie+0x7c>  // b.any
    6b18:	39400280 	ldrb	w0, [x20]
    6b1c:	7103fc1f 	cmp	w0, #0xff
    6b20:	540000e0 	b.eq	6b3c <fwp_free_zombie+0x1cc>  // b.none
    6b24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b28:	39000280 	strb	w0, [x20]
    6b2c:	17ffffb0 	b	69ec <fwp_free_zombie+0x7c>
    6b30:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    6b34:	9134e000 	add	x0, x0, #0xd38
    6b38:	97fff576 	bl	4110 <fwp_trap>
    6b3c:	aa1403e0 	mov	x0, x20
    6b40:	97fff594 	bl	4190 <fwp_rc_forget_slot.part.0>
    6b44:	17fffff8 	b	6b24 <fwp_free_zombie+0x1b4>
    6b48:	d503201f 	nop
    6b4c:	d503201f 	nop

0000000000006b50 <fwp_block>:
    6b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b54:	910003fd 	mov	x29, sp
    6b58:	a90153f3 	stp	x19, x20, [sp, #16]
    6b5c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6b60:	9101c274 	add	x20, x19, #0x70
    6b64:	f9404282 	ldr	x2, [x20, #128]
    6b68:	b4000642 	cbz	x2, 6c30 <fwp_block+0xe0>
    6b6c:	9101c261 	add	x1, x19, #0x70
    6b70:	f9408040 	ldr	x0, [x2, #256]
    6b74:	f9004020 	str	x0, [x1, #128]
    6b78:	b40006a0 	cbz	x0, 6c4c <fwp_block+0xfc>
    6b7c:	d503201f 	nop
    6b80:	9101c263 	add	x3, x19, #0x70
    6b84:	3901505f 	strb	wzr, [x2, #84]
    6b88:	f9400864 	ldr	x4, [x3, #16]
    6b8c:	eb02009f 	cmp	x4, x2
    6b90:	54000440 	b.eq	6c18 <fwp_block+0xc8>  // b.none
    6b94:	f9418465 	ldr	x5, [x3, #776]
    6b98:	f9000862 	str	x2, [x3, #16]
    6b9c:	f9400441 	ldr	x1, [x2, #8]
    6ba0:	f9004885 	str	x5, [x4, #144]
    6ba4:	f9418865 	ldr	x5, [x3, #784]
    6ba8:	f9004c85 	str	x5, [x4, #152]
    6bac:	f9418c65 	ldr	x5, [x3, #792]
    6bb0:	f9005085 	str	x5, [x4, #160]
    6bb4:	f9419065 	ldr	x5, [x3, #800]
    6bb8:	f9005485 	str	x5, [x4, #168]
    6bbc:	f9419465 	ldr	x5, [x3, #808]
    6bc0:	f9005885 	str	x5, [x4, #176]
    6bc4:	f9419865 	ldr	x5, [x3, #816]
    6bc8:	f9005c85 	str	x5, [x4, #184]
    6bcc:	f9419c65 	ldr	x5, [x3, #824]
    6bd0:	f9006085 	str	x5, [x4, #192]
    6bd4:	f9400480 	ldr	x0, [x4, #8]
    6bd8:	f9404844 	ldr	x4, [x2, #144]
    6bdc:	f9018464 	str	x4, [x3, #776]
    6be0:	f9404c44 	ldr	x4, [x2, #152]
    6be4:	f9018864 	str	x4, [x3, #784]
    6be8:	f9405044 	ldr	x4, [x2, #160]
    6bec:	f9018c64 	str	x4, [x3, #792]
    6bf0:	f9405444 	ldr	x4, [x2, #168]
    6bf4:	f9019064 	str	x4, [x3, #800]
    6bf8:	f9405844 	ldr	x4, [x2, #176]
    6bfc:	f9019464 	str	x4, [x3, #808]
    6c00:	a94b8844 	ldp	x4, x2, [x2, #184]
    6c04:	f9019864 	str	x4, [x3, #816]
    6c08:	f9019c62 	str	x2, [x3, #824]
    6c0c:	97ffef35 	bl	28e0 <swapcontext@plt>
    6c10:	97ffff58 	bl	6970 <fwp_free_zombie>
    6c14:	d503201f 	nop
    6c18:	9101c260 	add	x0, x19, #0x70
    6c1c:	b9434000 	ldr	w0, [x0, #832]
    6c20:	340001a0 	cbz	w0, 6c54 <fwp_block+0x104>
    6c24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c2c:	d65f03c0 	ret
    6c30:	97fff780 	bl	4a30 <fwp_poll_events>
    6c34:	f9404282 	ldr	x2, [x20, #128]
    6c38:	b4ffffc2 	cbz	x2, 6c30 <fwp_block+0xe0>
    6c3c:	9101c261 	add	x1, x19, #0x70
    6c40:	f9408040 	ldr	x0, [x2, #256]
    6c44:	f9004020 	str	x0, [x1, #128]
    6c48:	b5fff9c0 	cbnz	x0, 6b80 <fwp_block+0x30>
    6c4c:	f9003c3f 	str	xzr, [x1, #120]
    6c50:	17ffffcc 	b	6b80 <fwp_block+0x30>
    6c54:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    6c58:	913f4000 	add	x0, x0, #0xfd0
    6c5c:	97ffef6d 	bl	2a10 <getenv@plt>
    6c60:	5284e202 	mov	w2, #0x2710                	// #10000
    6c64:	b4000060 	cbz	x0, 6c70 <fwp_block+0x120>
    6c68:	39400001 	ldrb	w1, [x0]
    6c6c:	350000c1 	cbnz	w1, 6c84 <fwp_block+0x134>
    6c70:	9101c273 	add	x19, x19, #0x70
    6c74:	b9034262 	str	w2, [x19, #832]
    6c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c80:	d65f03c0 	ret
    6c84:	52800142 	mov	w2, #0xa                   	// #10
    6c88:	d2800001 	mov	x1, #0x0                   	// #0
    6c8c:	97ffeeb1 	bl	2750 <strtoll@plt>
    6c90:	d1000403 	sub	x3, x0, #0x1
    6c94:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6c98:	eb02007f 	cmp	x3, x2
    6c9c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6ca0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6ca4:	17fffff3 	b	6c70 <fwp_block+0x120>
    6ca8:	d503201f 	nop
    6cac:	d503201f 	nop

0000000000006cb0 <fwp_drop4>:
    6cb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6cb4:	910003fd 	mov	x29, sp
    6cb8:	a90153f3 	stp	x19, x20, [sp, #16]
    6cbc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6cc0:	f90013f5 	str	x21, [sp, #32]
    6cc4:	91174275 	add	x21, x19, #0x5d0
    6cc8:	f949daa1 	ldr	x1, [x21, #5040]
    6ccc:	f949eea2 	ldr	x2, [x21, #5080]
    6cd0:	cb010001 	sub	x1, x0, x1
    6cd4:	eb02403f 	cmp	x1, x2, lsl #16
    6cd8:	54000382 	b.cs	6d48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6cdc:	d350fc22 	lsr	x2, x1, #16
    6ce0:	f949fea3 	ldr	x3, [x21, #5112]
    6ce4:	8b020842 	add	x2, x2, x2, lsl #2
    6ce8:	d37df042 	lsl	x2, x2, #3
    6cec:	8b020064 	add	x4, x3, x2
    6cf0:	f9401094 	ldr	x20, [x4, #32]
    6cf4:	b40002b4 	cbz	x20, 6d48 <fwp_drop4+0x98>
    6cf8:	38626862 	ldrb	w2, [x3, x2]
    6cfc:	7100085f 	cmp	w2, #0x2
    6d00:	540007a0 	b.eq	6df4 <fwp_drop4+0x144>  // b.none
    6d04:	7100045f 	cmp	w2, #0x1
    6d08:	54000201 	b.ne	6d48 <fwp_drop4+0x98>  // b.any
    6d0c:	29430885 	ldp	w5, w2, [x4, #24]
    6d10:	92403c21 	and	x1, x1, #0xffff
    6d14:	9b057c21 	mul	x1, x1, x5
    6d18:	d360fc21 	lsr	x1, x1, #32
    6d1c:	eb02003f 	cmp	x1, x2
    6d20:	54000142 	b.cs	6d48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d24:	8b010294 	add	x20, x20, x1
    6d28:	39400281 	ldrb	w1, [x20]
    6d2c:	340000e1 	cbz	w1, 6d48 <fwp_drop4+0x98>
    6d30:	7100043f 	cmp	w1, #0x1
    6d34:	54000120 	b.eq	6d58 <fwp_drop4+0xa8>  // b.none
    6d38:	7103fc3f 	cmp	w1, #0xff
    6d3c:	540007c0 	b.eq	6e34 <fwp_drop4+0x184>  // b.none
    6d40:	51000421 	sub	w1, w1, #0x1
    6d44:	39000281 	strb	w1, [x20]
    6d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d4c:	f94013f5 	ldr	x21, [sp, #32]
    6d50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d54:	d65f03c0 	ret
    6d58:	f9400001 	ldr	x1, [x0]
    6d5c:	b7f80581 	tbnz	x1, #63, 6e0c <fwp_drop4+0x15c>
    6d60:	91174273 	add	x19, x19, #0x5d0
    6d64:	f949da61 	ldr	x1, [x19, #5040]
    6d68:	f949ee62 	ldr	x2, [x19, #5080]
    6d6c:	cb010001 	sub	x1, x0, x1
    6d70:	eb02403f 	cmp	x1, x2, lsl #16
    6d74:	54fffea2 	b.cs	6d48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d78:	d350fc22 	lsr	x2, x1, #16
    6d7c:	8b020842 	add	x2, x2, x2, lsl #2
    6d80:	d37df042 	lsl	x2, x2, #3
    6d84:	8b020065 	add	x5, x3, x2
    6d88:	f94010a4 	ldr	x4, [x5, #32]
    6d8c:	b4fffde4 	cbz	x4, 6d48 <fwp_drop4+0x98>
    6d90:	38626862 	ldrb	w2, [x3, x2]
    6d94:	7100085f 	cmp	w2, #0x2
    6d98:	54000220 	b.eq	6ddc <fwp_drop4+0x12c>  // b.none
    6d9c:	7100045f 	cmp	w2, #0x1
    6da0:	54fffd41 	b.ne	6d48 <fwp_drop4+0x98>  // b.any
    6da4:	294308a3 	ldp	w3, w2, [x5, #24]
    6da8:	92403c21 	and	x1, x1, #0xffff
    6dac:	9b037c21 	mul	x1, x1, x3
    6db0:	d360fc21 	lsr	x1, x1, #32
    6db4:	eb02003f 	cmp	x1, x2
    6db8:	54fffc82 	b.cs	6d48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6dbc:	8b010084 	add	x4, x4, x1
    6dc0:	39400081 	ldrb	w1, [x4]
    6dc4:	7100043f 	cmp	w1, #0x1
    6dc8:	54fffc01 	b.ne	6d48 <fwp_drop4+0x98>  // b.any
    6dcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6dd0:	f94013f5 	ldr	x21, [sp, #32]
    6dd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6dd8:	17fff58a 	b	4400 <fwp_mem_free>
    6ddc:	72003c3f 	tst	w1, #0xffff
    6de0:	54ffff00 	b.eq	6dc0 <fwp_drop4+0x110>  // b.none
    6de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6de8:	f94013f5 	ldr	x21, [sp, #32]
    6dec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6df0:	d65f03c0 	ret
    6df4:	72003c3f 	tst	w1, #0xffff
    6df8:	54fff980 	b.eq	6d28 <fwp_drop4+0x78>  // b.none
    6dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e00:	f94013f5 	ldr	x21, [sp, #32]
    6e04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e08:	d65f03c0 	ret
    6e0c:	f9400414 	ldr	x20, [x0, #8]
    6e10:	97fffbc9 	bl	5d34 <fwp_rc_free_arr>
    6e14:	91174260 	add	x0, x19, #0x5d0
    6e18:	f949d801 	ldr	x1, [x0, #5040]
    6e1c:	f949ec00 	ldr	x0, [x0, #5080]
    6e20:	cb010281 	sub	x1, x20, x1
    6e24:	eb00403f 	cmp	x1, x0, lsl #16
    6e28:	54fff902 	b.cs	6d48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e2c:	aa1403e0 	mov	x0, x20
    6e30:	17ffffab 	b	6cdc <fwp_drop4+0x2c>
    6e34:	ca544680 	eor	x0, x20, x20, lsr #17
    6e38:	91174273 	add	x19, x19, #0x5d0
    6e3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6e40:	92401c00 	and	x0, x0, #0xff
    6e44:	910a2402 	add	x2, x0, #0x289
    6e48:	8b000e60 	add	x0, x19, x0, lsl #3
    6e4c:	8b020e62 	add	x2, x19, x2, lsl #3
    6e50:	f94a2400 	ldr	x0, [x0, #5192]
    6e54:	b50000a0 	cbnz	x0, 6e68 <fwp_drop4+0x1b8>
    6e58:	14000013 	b	6ea4 <fwp_drop4+0x1f4>
    6e5c:	91004002 	add	x2, x0, #0x10
    6e60:	f9400800 	ldr	x0, [x0, #16]
    6e64:	b4000200 	cbz	x0, 6ea4 <fwp_drop4+0x1f4>
    6e68:	f9400001 	ldr	x1, [x0]
    6e6c:	eb14003f 	cmp	x1, x20
    6e70:	54ffff61 	b.ne	6e5c <fwp_drop4+0x1ac>  // b.any
    6e74:	f9400041 	ldr	x1, [x2]
    6e78:	f9400420 	ldr	x0, [x1, #8]
    6e7c:	d1000400 	sub	x0, x0, #0x1
    6e80:	f9000420 	str	x0, [x1, #8]
    6e84:	f103f81f 	cmp	x0, #0xfe
    6e88:	54fff601 	b.ne	6d48 <fwp_drop4+0x98>  // b.any
    6e8c:	39400280 	ldrb	w0, [x20]
    6e90:	7103fc1f 	cmp	w0, #0xff
    6e94:	540000e0 	b.eq	6eb0 <fwp_drop4+0x200>  // b.none
    6e98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e9c:	39000280 	strb	w0, [x20]
    6ea0:	17ffffaa 	b	6d48 <fwp_drop4+0x98>
    6ea4:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    6ea8:	9134e000 	add	x0, x0, #0xd38
    6eac:	97fff499 	bl	4110 <fwp_trap>
    6eb0:	aa1403e0 	mov	x0, x20
    6eb4:	97fff4b7 	bl	4190 <fwp_rc_forget_slot.part.0>
    6eb8:	17fffff8 	b	6e98 <fwp_drop4+0x1e8>
    6ebc:	d503201f 	nop

0000000000006ec0 <fwp_caps161>:
    6ec0:	34000041 	cbz	w1, 6ec8 <fwp_caps161+0x8>
    6ec4:	d65f03c0 	ret
    6ec8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6ecc:	91174063 	add	x3, x3, #0x5d0
    6ed0:	f949d861 	ldr	x1, [x3, #5040]
    6ed4:	f949ec62 	ldr	x2, [x3, #5080]
    6ed8:	cb010001 	sub	x1, x0, x1
    6edc:	eb02403f 	cmp	x1, x2, lsl #16
    6ee0:	54ffff22 	b.cs	6ec4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ee4:	d350fc22 	lsr	x2, x1, #16
    6ee8:	f949fc65 	ldr	x5, [x3, #5112]
    6eec:	8b020842 	add	x2, x2, x2, lsl #2
    6ef0:	d37df042 	lsl	x2, x2, #3
    6ef4:	8b0200a4 	add	x4, x5, x2
    6ef8:	f9401083 	ldr	x3, [x4, #32]
    6efc:	b4fffe43 	cbz	x3, 6ec4 <fwp_caps161+0x4>
    6f00:	386268a2 	ldrb	w2, [x5, x2]
    6f04:	7100085f 	cmp	w2, #0x2
    6f08:	540001c0 	b.eq	6f40 <fwp_caps161+0x80>  // b.none
    6f0c:	7100045f 	cmp	w2, #0x1
    6f10:	54fffda1 	b.ne	6ec4 <fwp_caps161+0x4>  // b.any
    6f14:	29430885 	ldp	w5, w2, [x4, #24]
    6f18:	92403c21 	and	x1, x1, #0xffff
    6f1c:	9b057c21 	mul	x1, x1, x5
    6f20:	d360fc21 	lsr	x1, x1, #32
    6f24:	eb02003f 	cmp	x1, x2
    6f28:	54fffce2 	b.cs	6ec4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6f2c:	8b010063 	add	x3, x3, x1
    6f30:	39400061 	ldrb	w1, [x3]
    6f34:	7100043f 	cmp	w1, #0x1
    6f38:	54fffc61 	b.ne	6ec4 <fwp_caps161+0x4>  // b.any
    6f3c:	17fff531 	b	4400 <fwp_mem_free>
    6f40:	72003c3f 	tst	w1, #0xffff
    6f44:	54ffff60 	b.eq	6f30 <fwp_caps161+0x70>  // b.none
    6f48:	d65f03c0 	ret
    6f4c:	d503201f 	nop

0000000000006f50 <fwp_args12>:
    6f50:	7100003f 	cmp	w1, #0x0
    6f54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f58:	54000041 	b.ne	6f60 <fwp_args12+0x10>  // b.any
    6f5c:	d65f03c0 	ret
    6f60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f64:	91174042 	add	x2, x2, #0x5d0
    6f68:	f9400001 	ldr	x1, [x0]
    6f6c:	f949d843 	ldr	x3, [x2, #5040]
    6f70:	f949ec40 	ldr	x0, [x2, #5080]
    6f74:	cb030021 	sub	x1, x1, x3
    6f78:	eb00403f 	cmp	x1, x0, lsl #16
    6f7c:	54ffff02 	b.cs	6f5c <fwp_args12+0xc>  // b.hs, b.nlast
    6f80:	d350fc20 	lsr	x0, x1, #16
    6f84:	f949fc44 	ldr	x4, [x2, #5112]
    6f88:	8b000800 	add	x0, x0, x0, lsl #2
    6f8c:	d37df002 	lsl	x2, x0, #3
    6f90:	8b020083 	add	x3, x4, x2
    6f94:	f9401060 	ldr	x0, [x3, #32]
    6f98:	b4fffe20 	cbz	x0, 6f5c <fwp_args12+0xc>
    6f9c:	38626882 	ldrb	w2, [x4, x2]
    6fa0:	7100085f 	cmp	w2, #0x2
    6fa4:	54000220 	b.eq	6fe8 <fwp_args12+0x98>  // b.none
    6fa8:	7100045f 	cmp	w2, #0x1
    6fac:	54fffd81 	b.ne	6f5c <fwp_args12+0xc>  // b.any
    6fb0:	29430864 	ldp	w4, w2, [x3, #24]
    6fb4:	92403c21 	and	x1, x1, #0xffff
    6fb8:	9b047c21 	mul	x1, x1, x4
    6fbc:	d360fc21 	lsr	x1, x1, #32
    6fc0:	eb02003f 	cmp	x1, x2
    6fc4:	54fffcc2 	b.cs	6f5c <fwp_args12+0xc>  // b.hs, b.nlast
    6fc8:	8b010000 	add	x0, x0, x1
    6fcc:	39400001 	ldrb	w1, [x0]
    6fd0:	34fffc61 	cbz	w1, 6f5c <fwp_args12+0xc>
    6fd4:	7103f43f 	cmp	w1, #0xfd
    6fd8:	540000e8 	b.hi	6ff4 <fwp_args12+0xa4>  // b.pmore
    6fdc:	11000421 	add	w1, w1, #0x1
    6fe0:	39000001 	strb	w1, [x0]
    6fe4:	d65f03c0 	ret
    6fe8:	72003c3f 	tst	w1, #0xffff
    6fec:	54ffff00 	b.eq	6fcc <fwp_args12+0x7c>  // b.none
    6ff0:	d65f03c0 	ret
    6ff4:	17fff57c 	b	45e4 <fwp_rc_wide_dup>
    6ff8:	d503201f 	nop
    6ffc:	d503201f 	nop

0000000000007000 <fwp_args23>:
    7000:	7100003f 	cmp	w1, #0x0
    7004:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7008:	54000041 	b.ne	7010 <fwp_args23+0x10>  // b.any
    700c:	d65f03c0 	ret
    7010:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7014:	91174042 	add	x2, x2, #0x5d0
    7018:	f9400001 	ldr	x1, [x0]
    701c:	f949d843 	ldr	x3, [x2, #5040]
    7020:	f949ec40 	ldr	x0, [x2, #5080]
    7024:	cb030021 	sub	x1, x1, x3
    7028:	eb00403f 	cmp	x1, x0, lsl #16
    702c:	54ffff02 	b.cs	700c <fwp_args23+0xc>  // b.hs, b.nlast
    7030:	d350fc20 	lsr	x0, x1, #16
    7034:	f949fc44 	ldr	x4, [x2, #5112]
    7038:	8b000800 	add	x0, x0, x0, lsl #2
    703c:	d37df002 	lsl	x2, x0, #3
    7040:	8b020083 	add	x3, x4, x2
    7044:	f9401060 	ldr	x0, [x3, #32]
    7048:	b4fffe20 	cbz	x0, 700c <fwp_args23+0xc>
    704c:	38626882 	ldrb	w2, [x4, x2]
    7050:	7100085f 	cmp	w2, #0x2
    7054:	54000220 	b.eq	7098 <fwp_args23+0x98>  // b.none
    7058:	7100045f 	cmp	w2, #0x1
    705c:	54fffd81 	b.ne	700c <fwp_args23+0xc>  // b.any
    7060:	29430864 	ldp	w4, w2, [x3, #24]
    7064:	92403c21 	and	x1, x1, #0xffff
    7068:	9b047c21 	mul	x1, x1, x4
    706c:	d360fc21 	lsr	x1, x1, #32
    7070:	eb02003f 	cmp	x1, x2
    7074:	54fffcc2 	b.cs	700c <fwp_args23+0xc>  // b.hs, b.nlast
    7078:	8b010000 	add	x0, x0, x1
    707c:	39400001 	ldrb	w1, [x0]
    7080:	34fffc61 	cbz	w1, 700c <fwp_args23+0xc>
    7084:	7103f43f 	cmp	w1, #0xfd
    7088:	540000e8 	b.hi	70a4 <fwp_args23+0xa4>  // b.pmore
    708c:	11000421 	add	w1, w1, #0x1
    7090:	39000001 	strb	w1, [x0]
    7094:	d65f03c0 	ret
    7098:	72003c3f 	tst	w1, #0xffff
    709c:	54ffff00 	b.eq	707c <fwp_args23+0x7c>  // b.none
    70a0:	d65f03c0 	ret
    70a4:	17fff550 	b	45e4 <fwp_rc_wide_dup>
    70a8:	d503201f 	nop
    70ac:	d503201f 	nop

00000000000070b0 <fwp_caps12>:
    70b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70b4:	910003fd 	mov	x29, sp
    70b8:	f9000bf3 	str	x19, [sp, #16]
    70bc:	aa0003f3 	mov	x19, x0
    70c0:	b9400400 	ldr	w0, [x0, #4]
    70c4:	340004a0 	cbz	w0, 7158 <fwp_caps12+0xa8>
    70c8:	f9400660 	ldr	x0, [x19, #8]
    70cc:	350004e1 	cbnz	w1, 7168 <fwp_caps12+0xb8>
    70d0:	97fffbf0 	bl	6090 <fwp_drop0>
    70d4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    70d8:	91174042 	add	x2, x2, #0x5d0
    70dc:	f949d840 	ldr	x0, [x2, #5040]
    70e0:	f949ec41 	ldr	x1, [x2, #5080]
    70e4:	cb000260 	sub	x0, x19, x0
    70e8:	eb01401f 	cmp	x0, x1, lsl #16
    70ec:	54000382 	b.cs	715c <fwp_caps12+0xac>  // b.hs, b.nlast
    70f0:	d350fc01 	lsr	x1, x0, #16
    70f4:	f949fc44 	ldr	x4, [x2, #5112]
    70f8:	8b010821 	add	x1, x1, x1, lsl #2
    70fc:	d37df021 	lsl	x1, x1, #3
    7100:	8b010083 	add	x3, x4, x1
    7104:	f9401062 	ldr	x2, [x3, #32]
    7108:	b40002a2 	cbz	x2, 715c <fwp_caps12+0xac>
    710c:	38616881 	ldrb	w1, [x4, x1]
    7110:	7100083f 	cmp	w1, #0x2
    7114:	540006c0 	b.eq	71ec <fwp_caps12+0x13c>  // b.none
    7118:	7100043f 	cmp	w1, #0x1
    711c:	54000201 	b.ne	715c <fwp_caps12+0xac>  // b.any
    7120:	29430464 	ldp	w4, w1, [x3, #24]
    7124:	92403c00 	and	x0, x0, #0xffff
    7128:	9b047c00 	mul	x0, x0, x4
    712c:	d360fc00 	lsr	x0, x0, #32
    7130:	eb01001f 	cmp	x0, x1
    7134:	54000142 	b.cs	715c <fwp_caps12+0xac>  // b.hs, b.nlast
    7138:	8b000042 	add	x2, x2, x0
    713c:	39400040 	ldrb	w0, [x2]
    7140:	7100041f 	cmp	w0, #0x1
    7144:	540000c1 	b.ne	715c <fwp_caps12+0xac>  // b.any
    7148:	aa1303e0 	mov	x0, x19
    714c:	f9400bf3 	ldr	x19, [sp, #16]
    7150:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7154:	17fff4ab 	b	4400 <fwp_mem_free>
    7158:	34fffbe1 	cbz	w1, 70d4 <fwp_caps12+0x24>
    715c:	f9400bf3 	ldr	x19, [sp, #16]
    7160:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7164:	d65f03c0 	ret
    7168:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    716c:	91174042 	add	x2, x2, #0x5d0
    7170:	f949d843 	ldr	x3, [x2, #5040]
    7174:	f949ec41 	ldr	x1, [x2, #5080]
    7178:	cb030000 	sub	x0, x0, x3
    717c:	eb01401f 	cmp	x0, x1, lsl #16
    7180:	54fffee2 	b.cs	715c <fwp_caps12+0xac>  // b.hs, b.nlast
    7184:	d350fc01 	lsr	x1, x0, #16
    7188:	f949fc44 	ldr	x4, [x2, #5112]
    718c:	8b010821 	add	x1, x1, x1, lsl #2
    7190:	d37df021 	lsl	x1, x1, #3
    7194:	8b010083 	add	x3, x4, x1
    7198:	f9401062 	ldr	x2, [x3, #32]
    719c:	b4fffe02 	cbz	x2, 715c <fwp_caps12+0xac>
    71a0:	38616881 	ldrb	w1, [x4, x1]
    71a4:	7100083f 	cmp	w1, #0x2
    71a8:	54000280 	b.eq	71f8 <fwp_caps12+0x148>  // b.none
    71ac:	7100043f 	cmp	w1, #0x1
    71b0:	54fffd61 	b.ne	715c <fwp_caps12+0xac>  // b.any
    71b4:	92403c01 	and	x1, x0, #0xffff
    71b8:	29430064 	ldp	w4, w0, [x3, #24]
    71bc:	9b047c21 	mul	x1, x1, x4
    71c0:	d360fc21 	lsr	x1, x1, #32
    71c4:	eb00003f 	cmp	x1, x0
    71c8:	54fffca2 	b.cs	715c <fwp_caps12+0xac>  // b.hs, b.nlast
    71cc:	8b010042 	add	x2, x2, x1
    71d0:	39400040 	ldrb	w0, [x2]
    71d4:	34fffc40 	cbz	w0, 715c <fwp_caps12+0xac>
    71d8:	7103f41f 	cmp	w0, #0xfd
    71dc:	54000148 	b.hi	7204 <fwp_caps12+0x154>  // b.pmore
    71e0:	11000400 	add	w0, w0, #0x1
    71e4:	39000040 	strb	w0, [x2]
    71e8:	17ffffdd 	b	715c <fwp_caps12+0xac>
    71ec:	72003c1f 	tst	w0, #0xffff
    71f0:	54fffb61 	b.ne	715c <fwp_caps12+0xac>  // b.any
    71f4:	17ffffd2 	b	713c <fwp_caps12+0x8c>
    71f8:	72003c1f 	tst	w0, #0xffff
    71fc:	54fffb01 	b.ne	715c <fwp_caps12+0xac>  // b.any
    7200:	17fffff4 	b	71d0 <fwp_caps12+0x120>
    7204:	f9400bf3 	ldr	x19, [sp, #16]
    7208:	aa0203e0 	mov	x0, x2
    720c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7210:	17fff4f5 	b	45e4 <fwp_rc_wide_dup>

0000000000007214 <fwp_drop2>:
    7214:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7218:	910003fd 	mov	x29, sp
    721c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7220:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    7224:	911742d5 	add	x21, x22, #0x5d0
    7228:	a90153f3 	stp	x19, x20, [sp, #16]
    722c:	aa0003f3 	mov	x19, x0
    7230:	f949daa1 	ldr	x1, [x21, #5040]
    7234:	f949eea0 	ldr	x0, [x21, #5080]
    7238:	cb010261 	sub	x1, x19, x1
    723c:	eb00403f 	cmp	x1, x0, lsl #16
    7240:	54000382 	b.cs	72b0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7244:	d350fc22 	lsr	x2, x1, #16
    7248:	f949fea3 	ldr	x3, [x21, #5112]
    724c:	8b020842 	add	x2, x2, x2, lsl #2
    7250:	d37df042 	lsl	x2, x2, #3
    7254:	8b020060 	add	x0, x3, x2
    7258:	f9401014 	ldr	x20, [x0, #32]
    725c:	b40002b4 	cbz	x20, 72b0 <fwp_drop2+0x9c>
    7260:	38626862 	ldrb	w2, [x3, x2]
    7264:	7100085f 	cmp	w2, #0x2
    7268:	540002c0 	b.eq	72c0 <fwp_drop2+0xac>  // b.none
    726c:	7100045f 	cmp	w2, #0x1
    7270:	54000201 	b.ne	72b0 <fwp_drop2+0x9c>  // b.any
    7274:	29430002 	ldp	w2, w0, [x0, #24]
    7278:	92403c21 	and	x1, x1, #0xffff
    727c:	9b027c21 	mul	x1, x1, x2
    7280:	d360fc21 	lsr	x1, x1, #32
    7284:	eb00003f 	cmp	x1, x0
    7288:	54000142 	b.cs	72b0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    728c:	8b010294 	add	x20, x20, x1
    7290:	39400280 	ldrb	w0, [x20]
    7294:	340000e0 	cbz	w0, 72b0 <fwp_drop2+0x9c>
    7298:	7100041f 	cmp	w0, #0x1
    729c:	540001e0 	b.eq	72d8 <fwp_drop2+0xc4>  // b.none
    72a0:	7103fc1f 	cmp	w0, #0xff
    72a4:	540007e0 	b.eq	73a0 <fwp_drop2+0x18c>  // b.none
    72a8:	51000400 	sub	w0, w0, #0x1
    72ac:	39000280 	strb	w0, [x20]
    72b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    72b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    72b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    72bc:	d65f03c0 	ret
    72c0:	72003c3f 	tst	w1, #0xffff
    72c4:	54fffe60 	b.eq	7290 <fwp_drop2+0x7c>  // b.none
    72c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    72cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    72d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    72d4:	d65f03c0 	ret
    72d8:	911742c2 	add	x2, x22, #0x5d0
    72dc:	f9400660 	ldr	x0, [x19, #8]
    72e0:	f949d841 	ldr	x1, [x2, #5040]
    72e4:	f949ec42 	ldr	x2, [x2, #5080]
    72e8:	cb010001 	sub	x1, x0, x1
    72ec:	eb02403f 	cmp	x1, x2, lsl #16
    72f0:	54000382 	b.cs	7360 <fwp_drop2+0x14c>  // b.hs, b.nlast
    72f4:	d350fc22 	lsr	x2, x1, #16
    72f8:	8b020842 	add	x2, x2, x2, lsl #2
    72fc:	d37df042 	lsl	x2, x2, #3
    7300:	8b020064 	add	x4, x3, x2
    7304:	f9401094 	ldr	x20, [x4, #32]
    7308:	b40002d4 	cbz	x20, 7360 <fwp_drop2+0x14c>
    730c:	38626862 	ldrb	w2, [x3, x2]
    7310:	7100085f 	cmp	w2, #0x2
    7314:	54000400 	b.eq	7394 <fwp_drop2+0x180>  // b.none
    7318:	7100045f 	cmp	w2, #0x1
    731c:	54000221 	b.ne	7360 <fwp_drop2+0x14c>  // b.any
    7320:	29430883 	ldp	w3, w2, [x4, #24]
    7324:	92403c21 	and	x1, x1, #0xffff
    7328:	9b037c21 	mul	x1, x1, x3
    732c:	d360fc21 	lsr	x1, x1, #32
    7330:	eb02003f 	cmp	x1, x2
    7334:	54000162 	b.cs	7360 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7338:	8b010294 	add	x20, x20, x1
    733c:	39400281 	ldrb	w1, [x20]
    7340:	34000101 	cbz	w1, 7360 <fwp_drop2+0x14c>
    7344:	7100043f 	cmp	w1, #0x1
    7348:	54000220 	b.eq	738c <fwp_drop2+0x178>  // b.none
    734c:	7103fc3f 	cmp	w1, #0xff
    7350:	54000660 	b.eq	741c <fwp_drop2+0x208>  // b.none
    7354:	51000421 	sub	w1, w1, #0x1
    7358:	39000281 	strb	w1, [x20]
    735c:	d503201f 	nop
    7360:	f9400a74 	ldr	x20, [x19, #16]
    7364:	aa1303e0 	mov	x0, x19
    7368:	97fffa73 	bl	5d34 <fwp_rc_free_arr>
    736c:	911742c0 	add	x0, x22, #0x5d0
    7370:	f949d801 	ldr	x1, [x0, #5040]
    7374:	f949ec00 	ldr	x0, [x0, #5080]
    7378:	cb010281 	sub	x1, x20, x1
    737c:	eb00403f 	cmp	x1, x0, lsl #16
    7380:	54fff982 	b.cs	72b0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7384:	aa1403f3 	mov	x19, x20
    7388:	17ffffaf 	b	7244 <fwp_drop2+0x30>
    738c:	97fffa6a 	bl	5d34 <fwp_rc_free_arr>
    7390:	17fffff4 	b	7360 <fwp_drop2+0x14c>
    7394:	72003c3f 	tst	w1, #0xffff
    7398:	54fffe41 	b.ne	7360 <fwp_drop2+0x14c>  // b.any
    739c:	17ffffe8 	b	733c <fwp_drop2+0x128>
    73a0:	ca544681 	eor	x1, x20, x20, lsr #17
    73a4:	911742c0 	add	x0, x22, #0x5d0
    73a8:	ca412421 	eor	x1, x1, x1, lsr #9
    73ac:	92401c21 	and	x1, x1, #0xff
    73b0:	910a2422 	add	x2, x1, #0x289
    73b4:	8b010c01 	add	x1, x0, x1, lsl #3
    73b8:	8b020c02 	add	x2, x0, x2, lsl #3
    73bc:	f94a2420 	ldr	x0, [x1, #5192]
    73c0:	b50000a0 	cbnz	x0, 73d4 <fwp_drop2+0x1c0>
    73c4:	14000013 	b	7410 <fwp_drop2+0x1fc>
    73c8:	91004002 	add	x2, x0, #0x10
    73cc:	f9400800 	ldr	x0, [x0, #16]
    73d0:	b4000200 	cbz	x0, 7410 <fwp_drop2+0x1fc>
    73d4:	f9400001 	ldr	x1, [x0]
    73d8:	eb14003f 	cmp	x1, x20
    73dc:	54ffff61 	b.ne	73c8 <fwp_drop2+0x1b4>  // b.any
    73e0:	f9400041 	ldr	x1, [x2]
    73e4:	f9400420 	ldr	x0, [x1, #8]
    73e8:	d1000400 	sub	x0, x0, #0x1
    73ec:	f9000420 	str	x0, [x1, #8]
    73f0:	f103f81f 	cmp	x0, #0xfe
    73f4:	54fff5e1 	b.ne	72b0 <fwp_drop2+0x9c>  // b.any
    73f8:	39400280 	ldrb	w0, [x20]
    73fc:	7103fc1f 	cmp	w0, #0xff
    7400:	54000460 	b.eq	748c <fwp_drop2+0x278>  // b.none
    7404:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7408:	39000280 	strb	w0, [x20]
    740c:	17ffffa9 	b	72b0 <fwp_drop2+0x9c>
    7410:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    7414:	9134e000 	add	x0, x0, #0xd38
    7418:	97fff33e 	bl	4110 <fwp_trap>
    741c:	ca544680 	eor	x0, x20, x20, lsr #17
    7420:	911742c1 	add	x1, x22, #0x5d0
    7424:	ca402400 	eor	x0, x0, x0, lsr #9
    7428:	92401c00 	and	x0, x0, #0xff
    742c:	910a2402 	add	x2, x0, #0x289
    7430:	8b000c20 	add	x0, x1, x0, lsl #3
    7434:	8b020c22 	add	x2, x1, x2, lsl #3
    7438:	f94a2400 	ldr	x0, [x0, #5192]
    743c:	b50000a0 	cbnz	x0, 7450 <fwp_drop2+0x23c>
    7440:	17fffff4 	b	7410 <fwp_drop2+0x1fc>
    7444:	91004002 	add	x2, x0, #0x10
    7448:	f9400800 	ldr	x0, [x0, #16]
    744c:	b4fffe20 	cbz	x0, 7410 <fwp_drop2+0x1fc>
    7450:	f9400001 	ldr	x1, [x0]
    7454:	eb14003f 	cmp	x1, x20
    7458:	54ffff61 	b.ne	7444 <fwp_drop2+0x230>  // b.any
    745c:	f9400041 	ldr	x1, [x2]
    7460:	f9400420 	ldr	x0, [x1, #8]
    7464:	d1000400 	sub	x0, x0, #0x1
    7468:	f9000420 	str	x0, [x1, #8]
    746c:	f103f81f 	cmp	x0, #0xfe
    7470:	54fff781 	b.ne	7360 <fwp_drop2+0x14c>  // b.any
    7474:	39400280 	ldrb	w0, [x20]
    7478:	7103fc1f 	cmp	w0, #0xff
    747c:	540000e0 	b.eq	7498 <fwp_drop2+0x284>  // b.none
    7480:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7484:	39000280 	strb	w0, [x20]
    7488:	17ffffb6 	b	7360 <fwp_drop2+0x14c>
    748c:	aa1403e0 	mov	x0, x20
    7490:	97fff340 	bl	4190 <fwp_rc_forget_slot.part.0>
    7494:	17ffffdc 	b	7404 <fwp_drop2+0x1f0>
    7498:	aa1403e0 	mov	x0, x20
    749c:	97fff33d 	bl	4190 <fwp_rc_forget_slot.part.0>
    74a0:	17fffff8 	b	7480 <fwp_drop2+0x26c>

00000000000074a4 <fwp_arg_drop23>:
    74a4:	7100003f 	cmp	w1, #0x0
    74a8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    74ac:	54000041 	b.ne	74b4 <fwp_arg_drop23+0x10>  // b.any
    74b0:	d65f03c0 	ret
    74b4:	f9400000 	ldr	x0, [x0]
    74b8:	17ffff57 	b	7214 <fwp_drop2>
    74bc:	d503201f 	nop

00000000000074c0 <fwp_caps23>:
    74c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    74c4:	910003fd 	mov	x29, sp
    74c8:	f9000bf3 	str	x19, [sp, #16]
    74cc:	aa0003f3 	mov	x19, x0
    74d0:	b9400400 	ldr	w0, [x0, #4]
    74d4:	340004a0 	cbz	w0, 7568 <fwp_caps23+0xa8>
    74d8:	f9400660 	ldr	x0, [x19, #8]
    74dc:	350004e1 	cbnz	w1, 7578 <fwp_caps23+0xb8>
    74e0:	97ffff4d 	bl	7214 <fwp_drop2>
    74e4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    74e8:	91174042 	add	x2, x2, #0x5d0
    74ec:	f949d840 	ldr	x0, [x2, #5040]
    74f0:	f949ec41 	ldr	x1, [x2, #5080]
    74f4:	cb000260 	sub	x0, x19, x0
    74f8:	eb01401f 	cmp	x0, x1, lsl #16
    74fc:	54000382 	b.cs	756c <fwp_caps23+0xac>  // b.hs, b.nlast
    7500:	d350fc01 	lsr	x1, x0, #16
    7504:	f949fc44 	ldr	x4, [x2, #5112]
    7508:	8b010821 	add	x1, x1, x1, lsl #2
    750c:	d37df021 	lsl	x1, x1, #3
    7510:	8b010083 	add	x3, x4, x1
    7514:	f9401062 	ldr	x2, [x3, #32]
    7518:	b40002a2 	cbz	x2, 756c <fwp_caps23+0xac>
    751c:	38616881 	ldrb	w1, [x4, x1]
    7520:	7100083f 	cmp	w1, #0x2
    7524:	540006c0 	b.eq	75fc <fwp_caps23+0x13c>  // b.none
    7528:	7100043f 	cmp	w1, #0x1
    752c:	54000201 	b.ne	756c <fwp_caps23+0xac>  // b.any
    7530:	29430464 	ldp	w4, w1, [x3, #24]
    7534:	92403c00 	and	x0, x0, #0xffff
    7538:	9b047c00 	mul	x0, x0, x4
    753c:	d360fc00 	lsr	x0, x0, #32
    7540:	eb01001f 	cmp	x0, x1
    7544:	54000142 	b.cs	756c <fwp_caps23+0xac>  // b.hs, b.nlast
    7548:	8b000042 	add	x2, x2, x0
    754c:	39400040 	ldrb	w0, [x2]
    7550:	7100041f 	cmp	w0, #0x1
    7554:	540000c1 	b.ne	756c <fwp_caps23+0xac>  // b.any
    7558:	aa1303e0 	mov	x0, x19
    755c:	f9400bf3 	ldr	x19, [sp, #16]
    7560:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7564:	17fff3a7 	b	4400 <fwp_mem_free>
    7568:	34fffbe1 	cbz	w1, 74e4 <fwp_caps23+0x24>
    756c:	f9400bf3 	ldr	x19, [sp, #16]
    7570:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7574:	d65f03c0 	ret
    7578:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    757c:	91174042 	add	x2, x2, #0x5d0
    7580:	f949d843 	ldr	x3, [x2, #5040]
    7584:	f949ec41 	ldr	x1, [x2, #5080]
    7588:	cb030000 	sub	x0, x0, x3
    758c:	eb01401f 	cmp	x0, x1, lsl #16
    7590:	54fffee2 	b.cs	756c <fwp_caps23+0xac>  // b.hs, b.nlast
    7594:	d350fc01 	lsr	x1, x0, #16
    7598:	f949fc44 	ldr	x4, [x2, #5112]
    759c:	8b010821 	add	x1, x1, x1, lsl #2
    75a0:	d37df021 	lsl	x1, x1, #3
    75a4:	8b010083 	add	x3, x4, x1
    75a8:	f9401062 	ldr	x2, [x3, #32]
    75ac:	b4fffe02 	cbz	x2, 756c <fwp_caps23+0xac>
    75b0:	38616881 	ldrb	w1, [x4, x1]
    75b4:	7100083f 	cmp	w1, #0x2
    75b8:	54000280 	b.eq	7608 <fwp_caps23+0x148>  // b.none
    75bc:	7100043f 	cmp	w1, #0x1
    75c0:	54fffd61 	b.ne	756c <fwp_caps23+0xac>  // b.any
    75c4:	92403c01 	and	x1, x0, #0xffff
    75c8:	29430064 	ldp	w4, w0, [x3, #24]
    75cc:	9b047c21 	mul	x1, x1, x4
    75d0:	d360fc21 	lsr	x1, x1, #32
    75d4:	eb00003f 	cmp	x1, x0
    75d8:	54fffca2 	b.cs	756c <fwp_caps23+0xac>  // b.hs, b.nlast
    75dc:	8b010042 	add	x2, x2, x1
    75e0:	39400040 	ldrb	w0, [x2]
    75e4:	34fffc40 	cbz	w0, 756c <fwp_caps23+0xac>
    75e8:	7103f41f 	cmp	w0, #0xfd
    75ec:	54000148 	b.hi	7614 <fwp_caps23+0x154>  // b.pmore
    75f0:	11000400 	add	w0, w0, #0x1
    75f4:	39000040 	strb	w0, [x2]
    75f8:	17ffffdd 	b	756c <fwp_caps23+0xac>
    75fc:	72003c1f 	tst	w0, #0xffff
    7600:	54fffb61 	b.ne	756c <fwp_caps23+0xac>  // b.any
    7604:	17ffffd2 	b	754c <fwp_caps23+0x8c>
    7608:	72003c1f 	tst	w0, #0xffff
    760c:	54fffb01 	b.ne	756c <fwp_caps23+0xac>  // b.any
    7610:	17fffff4 	b	75e0 <fwp_caps23+0x120>
    7614:	f9400bf3 	ldr	x19, [sp, #16]
    7618:	aa0203e0 	mov	x0, x2
    761c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7620:	17fff3f1 	b	45e4 <fwp_rc_wide_dup>

0000000000007624 <f23>:
    7624:	d10203ff 	sub	sp, sp, #0x80
    7628:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    762c:	f947f421 	ldr	x1, [x1, #4072]
    7630:	a9027bfd 	stp	x29, x30, [sp, #32]
    7634:	910083fd 	add	x29, sp, #0x20
    7638:	a9045bf5 	stp	x21, x22, [sp, #64]
    763c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    7640:	911742a3 	add	x3, x21, #0x5d0
    7644:	a90353f3 	stp	x19, x20, [sp, #48]
    7648:	aa0003f6 	mov	x22, x0
    764c:	a90563f7 	stp	x23, x24, [sp, #80]
    7650:	a9066bf9 	stp	x25, x26, [sp, #96]
    7654:	f949ec62 	ldr	x2, [x3, #5080]
    7658:	f9400024 	ldr	x4, [x1]
    765c:	f9000fe4 	str	x4, [sp, #24]
    7660:	d2800004 	mov	x4, #0x0                   	// #0
    7664:	f949d861 	ldr	x1, [x3, #5040]
    7668:	d370bc42 	lsl	x2, x2, #16
    766c:	b4001800 	cbz	x0, 796c <f23+0x348>
    7670:	f9400817 	ldr	x23, [x0, #16]
    7674:	cb0102e1 	sub	x1, x23, x1
    7678:	eb02003f 	cmp	x1, x2
    767c:	54000362 	b.cs	76e8 <f23+0xc4>  // b.hs, b.nlast
    7680:	f949fc60 	ldr	x0, [x3, #5112]
    7684:	d350fc22 	lsr	x2, x1, #16
    7688:	8b020842 	add	x2, x2, x2, lsl #2
    768c:	8b020c02 	add	x2, x0, x2, lsl #3
    7690:	f9401040 	ldr	x0, [x2, #32]
    7694:	b40002a0 	cbz	x0, 76e8 <f23+0xc4>
    7698:	39400043 	ldrb	w3, [x2]
    769c:	7100087f 	cmp	w3, #0x2
    76a0:	54001540 	b.eq	7948 <f23+0x324>  // b.none
    76a4:	7100047f 	cmp	w3, #0x1
    76a8:	540001c1 	b.ne	76e0 <f23+0xbc>  // b.any
    76ac:	29430843 	ldp	w3, w2, [x2, #24]
    76b0:	92403c21 	and	x1, x1, #0xffff
    76b4:	9b037c21 	mul	x1, x1, x3
    76b8:	d360fc21 	lsr	x1, x1, #32
    76bc:	eb02003f 	cmp	x1, x2
    76c0:	54000102 	b.cs	76e0 <f23+0xbc>  // b.hs, b.nlast
    76c4:	8b010000 	add	x0, x0, x1
    76c8:	39400001 	ldrb	w1, [x0]
    76cc:	340000a1 	cbz	w1, 76e0 <f23+0xbc>
    76d0:	7103f43f 	cmp	w1, #0xfd
    76d4:	540017e8 	b.hi	79d0 <f23+0x3ac>  // b.pmore
    76d8:	11000421 	add	w1, w1, #0x1
    76dc:	39000001 	strb	w1, [x0]
    76e0:	d2800002 	mov	x2, #0x0                   	// #0
    76e4:	b40000d6 	cbz	x22, 76fc <f23+0xd8>
    76e8:	aa1603e1 	mov	x1, x22
    76ec:	d2800002 	mov	x2, #0x0                   	// #0
    76f0:	f9400821 	ldr	x1, [x1, #16]
    76f4:	91000442 	add	x2, x2, #0x1
    76f8:	b5ffffc1 	cbnz	x1, 76f0 <f23+0xcc>
    76fc:	b40013f7 	cbz	x23, 7978 <f23+0x354>
    7700:	aa1703e1 	mov	x1, x23
    7704:	d2800003 	mov	x3, #0x0                   	// #0
    7708:	f9400821 	ldr	x1, [x1, #16]
    770c:	91000463 	add	x3, x3, #0x1
    7710:	b5ffffc1 	cbnz	x1, 7708 <f23+0xe4>
    7714:	eb02007f 	cmp	x3, x2
    7718:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    771c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7720:	eb00027f 	cmp	x19, x0
    7724:	540010a8 	b.hi	7938 <f23+0x314>  // b.pmore
    7728:	d37ffa74 	lsl	x20, x19, #1
    772c:	52800041 	mov	w1, #0x2                   	// #2
    7730:	91000680 	add	x0, x20, #0x1
    7734:	d37df000 	lsl	x0, x0, #3
    7738:	97fff5ee 	bl	4ef0 <fwp_heap_alloc>
    773c:	aa0003f8 	mov	x24, x0
    7740:	911742a1 	add	x1, x21, #0x5d0
    7744:	aa0103e0 	mov	x0, x1
    7748:	f9000314 	str	x20, [x24]
    774c:	f949d821 	ldr	x1, [x1, #5040]
    7750:	f949ec00 	ldr	x0, [x0, #5080]
    7754:	cb010301 	sub	x1, x24, x1
    7758:	eb00403f 	cmp	x1, x0, lsl #16
    775c:	54000342 	b.cs	77c4 <f23+0x1a0>  // b.hs, b.nlast
    7760:	911742a2 	add	x2, x21, #0x5d0
    7764:	d350fc20 	lsr	x0, x1, #16
    7768:	8b000800 	add	x0, x0, x0, lsl #2
    776c:	f949fc43 	ldr	x3, [x2, #5112]
    7770:	d37df002 	lsl	x2, x0, #3
    7774:	8b020060 	add	x0, x3, x2
    7778:	f9401014 	ldr	x20, [x0, #32]
    777c:	b4000254 	cbz	x20, 77c4 <f23+0x1a0>
    7780:	38626862 	ldrb	w2, [x3, x2]
    7784:	7100085f 	cmp	w2, #0x2
    7788:	54000ec0 	b.eq	7960 <f23+0x33c>  // b.none
    778c:	7100045f 	cmp	w2, #0x1
    7790:	540001a1 	b.ne	77c4 <f23+0x1a0>  // b.any
    7794:	29430002 	ldp	w2, w0, [x0, #24]
    7798:	92403c21 	and	x1, x1, #0xffff
    779c:	9b027c21 	mul	x1, x1, x2
    77a0:	d360fc21 	lsr	x1, x1, #32
    77a4:	eb00003f 	cmp	x1, x0
    77a8:	540000e2 	b.cs	77c4 <f23+0x1a0>  // b.hs, b.nlast
    77ac:	8b010294 	add	x20, x20, x1
    77b0:	39400280 	ldrb	w0, [x20]
    77b4:	7103fc1f 	cmp	w0, #0xff
    77b8:	54001100 	b.eq	79d8 <f23+0x3b4>  // b.none
    77bc:	52800020 	mov	w0, #0x1                   	// #1
    77c0:	39000280 	strb	w0, [x20]
    77c4:	b4000253 	cbz	x19, 780c <f23+0x1e8>
    77c8:	8b131313 	add	x19, x24, x19, lsl #4
    77cc:	aa1803f4 	mov	x20, x24
    77d0:	aa1603fa 	mov	x26, x22
    77d4:	aa1703f9 	mov	x25, x23
    77d8:	f9400723 	ldr	x3, [x25, #8]
    77dc:	f9400742 	ldr	x2, [x26, #8]
    77e0:	f9400861 	ldr	x1, [x3, #16]
    77e4:	f9400840 	ldr	x0, [x2, #16]
    77e8:	fd400461 	ldr	d1, [x3, #8]
    77ec:	fd400440 	ldr	d0, [x2, #8]
    77f0:	97fff77c 	bl	55e0 <w107>
    77f4:	f9000680 	str	x0, [x20, #8]
    77f8:	f8010e81 	str	x1, [x20, #16]!
    77fc:	f9400b39 	ldr	x25, [x25, #16]
    7800:	f9400b5a 	ldr	x26, [x26, #16]
    7804:	eb14027f 	cmp	x19, x20
    7808:	54fffe81 	b.ne	77d8 <f23+0x1b4>  // b.any
    780c:	aa1703e0 	mov	x0, x23
    7810:	97fffe81 	bl	7214 <fwp_drop2>
    7814:	aa1603e0 	mov	x0, x22
    7818:	97fffe7f 	bl	7214 <fwp_drop2>
    781c:	f9400316 	ldr	x22, [x24]
    7820:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7824:	b4000236 	cbz	x22, 7868 <f23+0x244>
    7828:	fd003be8 	str	d8, [sp, #112]
    782c:	2f00e408 	movi	d8, #0x0
    7830:	91002319 	add	x25, x24, #0x8
    7834:	91004317 	add	x23, x24, #0x10
    7838:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    783c:	d2800013 	mov	x19, #0x0                   	// #0
    7840:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7844:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7848:	91000a73 	add	x19, x19, #0x2
    784c:	1e602908 	fadd	d8, d8, d0
    7850:	97fff70c 	bl	5480 <f128.constprop.0>
    7854:	aa0003f4 	mov	x20, x0
    7858:	eb1302df 	cmp	x22, x19
    785c:	54ffff28 	b.hi	7840 <f23+0x21c>  // b.pmore
    7860:	9e660116 	fmov	x22, d8
    7864:	fd403be8 	ldr	d8, [sp, #112]
    7868:	911742b5 	add	x21, x21, #0x5d0
    786c:	aa1803e0 	mov	x0, x24
    7870:	97fffd10 	bl	6cb0 <fwp_drop4>
    7874:	a900d3f6 	stp	x22, x20, [sp, #8]
    7878:	910023e1 	add	x1, sp, #0x8
    787c:	52800000 	mov	w0, #0x0                   	// #0
    7880:	97fff891 	bl	5ac4 <fwp_data.part.0.constprop.0>
    7884:	f949daa1 	ldr	x1, [x21, #5040]
    7888:	aa0003f3 	mov	x19, x0
    788c:	f949eea0 	ldr	x0, [x21, #5080]
    7890:	cb010261 	sub	x1, x19, x1
    7894:	eb00403f 	cmp	x1, x0, lsl #16
    7898:	54000322 	b.cs	78fc <f23+0x2d8>  // b.hs, b.nlast
    789c:	d350fc22 	lsr	x2, x1, #16
    78a0:	f949fea3 	ldr	x3, [x21, #5112]
    78a4:	8b020842 	add	x2, x2, x2, lsl #2
    78a8:	d37df042 	lsl	x2, x2, #3
    78ac:	8b020060 	add	x0, x3, x2
    78b0:	f9401014 	ldr	x20, [x0, #32]
    78b4:	b4000254 	cbz	x20, 78fc <f23+0x2d8>
    78b8:	38626862 	ldrb	w2, [x3, x2]
    78bc:	7100085f 	cmp	w2, #0x2
    78c0:	540004a0 	b.eq	7954 <f23+0x330>  // b.none
    78c4:	7100045f 	cmp	w2, #0x1
    78c8:	540001a1 	b.ne	78fc <f23+0x2d8>  // b.any
    78cc:	29430002 	ldp	w2, w0, [x0, #24]
    78d0:	92403c21 	and	x1, x1, #0xffff
    78d4:	9b027c21 	mul	x1, x1, x2
    78d8:	d360fc21 	lsr	x1, x1, #32
    78dc:	eb00003f 	cmp	x1, x0
    78e0:	540000e2 	b.cs	78fc <f23+0x2d8>  // b.hs, b.nlast
    78e4:	8b010294 	add	x20, x20, x1
    78e8:	39400280 	ldrb	w0, [x20]
    78ec:	7103fc1f 	cmp	w0, #0xff
    78f0:	540007a0 	b.eq	79e4 <f23+0x3c0>  // b.none
    78f4:	52800020 	mov	w0, #0x1                   	// #1
    78f8:	39000280 	strb	w0, [x20]
    78fc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7900:	f947f400 	ldr	x0, [x0, #4072]
    7904:	f9400fe2 	ldr	x2, [sp, #24]
    7908:	f9400001 	ldr	x1, [x0]
    790c:	eb010042 	subs	x2, x2, x1
    7910:	d2800001 	mov	x1, #0x0                   	// #0
    7914:	54000721 	b.ne	79f8 <f23+0x3d4>  // b.any
    7918:	a9427bfd 	ldp	x29, x30, [sp, #32]
    791c:	aa1303e0 	mov	x0, x19
    7920:	a94353f3 	ldp	x19, x20, [sp, #48]
    7924:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7928:	a94563f7 	ldp	x23, x24, [sp, #80]
    792c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7930:	910203ff 	add	sp, sp, #0x80
    7934:	d65f03c0 	ret
    7938:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    793c:	913f8000 	add	x0, x0, #0xfe0
    7940:	fd003be8 	str	d8, [sp, #112]
    7944:	97fff1f3 	bl	4110 <fwp_trap>
    7948:	72003c3f 	tst	w1, #0xffff
    794c:	54ffeca1 	b.ne	76e0 <f23+0xbc>  // b.any
    7950:	17ffff5e 	b	76c8 <f23+0xa4>
    7954:	72003c3f 	tst	w1, #0xffff
    7958:	54fffd21 	b.ne	78fc <f23+0x2d8>  // b.any
    795c:	17ffffe3 	b	78e8 <f23+0x2c4>
    7960:	72003c3f 	tst	w1, #0xffff
    7964:	54fff301 	b.ne	77c4 <f23+0x1a0>  // b.any
    7968:	17ffff92 	b	77b0 <f23+0x18c>
    796c:	cb0103e1 	neg	x1, x1
    7970:	eb02003f 	cmp	x1, x2
    7974:	540001e3 	b.cc	79b0 <f23+0x38c>  // b.lo, b.ul, b.last
    7978:	52800041 	mov	w1, #0x2                   	// #2
    797c:	d2800100 	mov	x0, #0x8                   	// #8
    7980:	97fff55c 	bl	4ef0 <fwp_heap_alloc>
    7984:	aa0003f8 	mov	x24, x0
    7988:	911742a0 	add	x0, x21, #0x5d0
    798c:	f900031f 	str	xzr, [x24]
    7990:	f949d801 	ldr	x1, [x0, #5040]
    7994:	f949ec00 	ldr	x0, [x0, #5080]
    7998:	cb010301 	sub	x1, x24, x1
    799c:	eb00403f 	cmp	x1, x0, lsl #16
    79a0:	54000282 	b.cs	79f0 <f23+0x3cc>  // b.hs, b.nlast
    79a4:	d2800013 	mov	x19, #0x0                   	// #0
    79a8:	d2800017 	mov	x23, #0x0                   	// #0
    79ac:	17ffff6d 	b	7760 <f23+0x13c>
    79b0:	f949fc62 	ldr	x2, [x3, #5112]
    79b4:	d350fc20 	lsr	x0, x1, #16
    79b8:	8b000800 	add	x0, x0, x0, lsl #2
    79bc:	8b000c42 	add	x2, x2, x0, lsl #3
    79c0:	f9401040 	ldr	x0, [x2, #32]
    79c4:	b4fffda0 	cbz	x0, 7978 <f23+0x354>
    79c8:	d2800017 	mov	x23, #0x0                   	// #0
    79cc:	17ffff33 	b	7698 <f23+0x74>
    79d0:	97fff305 	bl	45e4 <fwp_rc_wide_dup>
    79d4:	17ffff43 	b	76e0 <f23+0xbc>
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	97fff1ed 	bl	4190 <fwp_rc_forget_slot.part.0>
    79e0:	17ffff77 	b	77bc <f23+0x198>
    79e4:	aa1403e0 	mov	x0, x20
    79e8:	97fff1ea 	bl	4190 <fwp_rc_forget_slot.part.0>
    79ec:	17ffffc2 	b	78f4 <f23+0x2d0>
    79f0:	d2800017 	mov	x23, #0x0                   	// #0
    79f4:	17ffff86 	b	780c <f23+0x1e8>
    79f8:	fd003be8 	str	d8, [sp, #112]
    79fc:	97ffeba1 	bl	2880 <__stack_chk_fail@plt>

0000000000007a00 <fwp_owned_entry23>:
    7a00:	f9400000 	ldr	x0, [x0]
    7a04:	17ffff08 	b	7624 <f23>
    7a08:	d503201f 	nop
    7a0c:	d503201f 	nop

0000000000007a10 <e23>:
    7a10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7a14:	910003fd 	mov	x29, sp
    7a18:	f9000bf3 	str	x19, [sp, #16]
    7a1c:	f9400013 	ldr	x19, [x0]
    7a20:	aa1303e0 	mov	x0, x19
    7a24:	97fff870 	bl	5be4 <fwp_rc_share>
    7a28:	aa1303e0 	mov	x0, x19
    7a2c:	97fffefe 	bl	7624 <f23>
    7a30:	aa0003f3 	mov	x19, x0
    7a34:	97fff86c 	bl	5be4 <fwp_rc_share>
    7a38:	aa1303e0 	mov	x0, x19
    7a3c:	f9400bf3 	ldr	x19, [sp, #16]
    7a40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7a44:	d65f03c0 	ret
    7a48:	d503201f 	nop
    7a4c:	d503201f 	nop

0000000000007a50 <f12>:
    7a50:	d10483ff 	sub	sp, sp, #0x120
    7a54:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7a58:	f947f442 	ldr	x2, [x2, #4072]
    7a5c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7a60:	910303fd 	add	x29, sp, #0xc0
    7a64:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7a68:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    7a6c:	911742a3 	add	x3, x21, #0x5d0
    7a70:	a90d53f3 	stp	x19, x20, [sp, #208]
    7a74:	b00000d4 	adrp	x20, 20000 <__data_start>
    7a78:	9101c284 	add	x4, x20, #0x70
    7a7c:	f949d861 	ldr	x1, [x3, #5040]
    7a80:	a90f63f7 	stp	x23, x24, [sp, #240]
    7a84:	b00000d8 	adrp	x24, 20000 <__data_start>
    7a88:	f949ec65 	ldr	x5, [x3, #5080]
    7a8c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7a90:	91004318 	add	x24, x24, #0x10
    7a94:	a91173fb 	stp	x27, x28, [sp, #272]
    7a98:	9100e318 	add	x24, x24, #0x38
    7a9c:	910103f7 	add	x23, sp, #0x40
    7aa0:	f9418886 	ldr	x6, [x4, #784]
    7aa4:	f9400047 	ldr	x7, [x2]
    7aa8:	f9005fe7 	str	x7, [sp, #184]
    7aac:	d2800007 	mov	x7, #0x0                   	// #0
    7ab0:	9100e3f6 	add	x22, sp, #0x38
    7ab4:	f0fffff9 	adrp	x25, 6000 <e161+0x90>
    7ab8:	12800007 	mov	w7, #0xffffffff            	// #-1
    7abc:	911cc322 	add	x2, x25, #0x730
    7ac0:	cb010301 	sub	x1, x24, x1
    7ac4:	b9003be7 	str	w7, [sp, #56]
    7ac8:	a9040be6 	stp	x6, x2, [sp, #64]
    7acc:	aa0003f3 	mov	x19, x0
    7ad0:	f9002bf6 	str	x22, [sp, #80]
    7ad4:	f9018897 	str	x23, [x4, #784]
    7ad8:	eb05403f 	cmp	x1, x5, lsl #16
    7adc:	54000342 	b.cs	7b44 <f12+0xf4>  // b.hs, b.nlast
    7ae0:	d350fc20 	lsr	x0, x1, #16
    7ae4:	f949fc64 	ldr	x4, [x3, #5112]
    7ae8:	8b000800 	add	x0, x0, x0, lsl #2
    7aec:	d37df002 	lsl	x2, x0, #3
    7af0:	8b020083 	add	x3, x4, x2
    7af4:	f9401060 	ldr	x0, [x3, #32]
    7af8:	b4000260 	cbz	x0, 7b44 <f12+0xf4>
    7afc:	38626882 	ldrb	w2, [x4, x2]
    7b00:	7100085f 	cmp	w2, #0x2
    7b04:	54000b20 	b.eq	7c68 <f12+0x218>  // b.none
    7b08:	7100045f 	cmp	w2, #0x1
    7b0c:	540001c1 	b.ne	7b44 <f12+0xf4>  // b.any
    7b10:	29430864 	ldp	w4, w2, [x3, #24]
    7b14:	92403c21 	and	x1, x1, #0xffff
    7b18:	9b047c21 	mul	x1, x1, x4
    7b1c:	d360fc21 	lsr	x1, x1, #32
    7b20:	eb02003f 	cmp	x1, x2
    7b24:	54000102 	b.cs	7b44 <f12+0xf4>  // b.hs, b.nlast
    7b28:	8b010000 	add	x0, x0, x1
    7b2c:	39400001 	ldrb	w1, [x0]
    7b30:	340000a1 	cbz	w1, 7b44 <f12+0xf4>
    7b34:	7103f43f 	cmp	w1, #0xfd
    7b38:	54002828 	b.hi	803c <f12+0x5ec>  // b.pmore
    7b3c:	11000421 	add	w1, w1, #0x1
    7b40:	39000001 	strb	w1, [x0]
    7b44:	aa1803e0 	mov	x0, x24
    7b48:	97fffa12 	bl	6390 <fwp_closure_drop>
    7b4c:	b40001d3 	cbz	x19, 7b84 <f12+0x134>
    7b50:	aa1303e0 	mov	x0, x19
    7b54:	d2800018 	mov	x24, #0x0                   	// #0
    7b58:	f9400800 	ldr	x0, [x0, #16]
    7b5c:	91000718 	add	x24, x24, #0x1
    7b60:	b5ffffc0 	cbnz	x0, 7b58 <f12+0x108>
    7b64:	52800000 	mov	w0, #0x0                   	// #0
    7b68:	97ffeea2 	bl	35f0 <descent_phase_step>
    7b6c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7b70:	eb00031f 	cmp	x24, x0
    7b74:	540000e9 	b.ls	7b90 <f12+0x140>  // b.plast
    7b78:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    7b7c:	913fc000 	add	x0, x0, #0xff0
    7b80:	97fff164 	bl	4110 <fwp_trap>
    7b84:	d2800018 	mov	x24, #0x0                   	// #0
    7b88:	52800000 	mov	w0, #0x0                   	// #0
    7b8c:	97ffee99 	bl	35f0 <descent_phase_step>
    7b90:	9101c29a 	add	x26, x20, #0x70
    7b94:	b9434740 	ldr	w0, [x26, #836]
    7b98:	34001280 	cbz	w0, 7de8 <f12+0x398>
    7b9c:	9101c280 	add	x0, x20, #0x70
    7ba0:	f940681b 	ldr	x27, [x0, #208]
    7ba4:	f940741a 	ldr	x26, [x0, #232]
    7ba8:	eb1b035f 	cmp	x26, x27
    7bac:	5400064a 	b.ge	7c74 <f12+0x224>  // b.tcont
    7bb0:	f9403a81 	ldr	x1, [x20, #112]
    7bb4:	8b1a0740 	add	x0, x26, x26, lsl #1
    7bb8:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7bbc:	8b000b40 	add	x0, x26, x0, lsl #2
    7bc0:	8b000c20 	add	x0, x1, x0, lsl #3
    7bc4:	d503201f 	nop
    7bc8:	b9400401 	ldr	w1, [x0, #4]
    7bcc:	35000081 	cbnz	w1, 7bdc <f12+0x18c>
    7bd0:	b9400001 	ldr	w1, [x0]
    7bd4:	6b02003f 	cmp	w1, w2
    7bd8:	540004e9 	b.ls	7c74 <f12+0x224>  // b.plast
    7bdc:	9100075a 	add	x26, x26, #0x1
    7be0:	9101a000 	add	x0, x0, #0x68
    7be4:	eb1b035f 	cmp	x26, x27
    7be8:	54ffff01 	b.ne	7bc8 <f12+0x178>  // b.any
    7bec:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7bf0:	eb00037f 	cmp	x27, x0
    7bf4:	54001dac 	b.gt	7fa8 <f12+0x558>
    7bf8:	9101c280 	add	x0, x20, #0x70
    7bfc:	f9403a9c 	ldr	x28, [x20, #112]
    7c00:	f9407000 	ldr	x0, [x0, #224]
    7c04:	eb1b001f 	cmp	x0, x27
    7c08:	54000161 	b.ne	7c34 <f12+0x1e4>  // b.any
    7c0c:	b5001dbb 	cbnz	x27, 7fc0 <f12+0x570>
    7c10:	d2800d01 	mov	x1, #0x68                  	// #104
    7c14:	d280003a 	mov	x26, #0x1                   	// #1
    7c18:	aa1c03e0 	mov	x0, x28
    7c1c:	97ffeb15 	bl	2870 <realloc@plt>
    7c20:	aa0003fc 	mov	x28, x0
    7c24:	b4004a00 	cbz	x0, 8564 <f12+0xb14>
    7c28:	9101c280 	add	x0, x20, #0x70
    7c2c:	f9003a9c 	str	x28, [x20, #112]
    7c30:	f900701a 	str	x26, [x0, #224]
    7c34:	8b1b0761 	add	x1, x27, x27, lsl #1
    7c38:	9101c280 	add	x0, x20, #0x70
    7c3c:	4f000400 	movi	v0.4s, #0x0
    7c40:	aa1b03fa 	mov	x26, x27
    7c44:	8b010b61 	add	x1, x27, x1, lsl #2
    7c48:	9100077b 	add	x27, x27, #0x1
    7c4c:	f900681b 	str	x27, [x0, #208]
    7c50:	8b010f81 	add	x1, x28, x1, lsl #3
    7c54:	ad000020 	stp	q0, q0, [x1]
    7c58:	ad010020 	stp	q0, q0, [x1, #32]
    7c5c:	ad020020 	stp	q0, q0, [x1, #64]
    7c60:	f900303f 	str	xzr, [x1, #96]
    7c64:	14000007 	b	7c80 <f12+0x230>
    7c68:	72003c3f 	tst	w1, #0xffff
    7c6c:	54fff6c1 	b.ne	7b44 <f12+0xf4>  // b.any
    7c70:	17ffffaf 	b	7b2c <f12+0xdc>
    7c74:	eb1a037f 	cmp	x27, x26
    7c78:	54fffba0 	b.eq	7bec <f12+0x19c>  // b.none
    7c7c:	f9403a9c 	ldr	x28, [x20, #112]
    7c80:	8b1a075b 	add	x27, x26, x26, lsl #1
    7c84:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    7c88:	91344000 	add	x0, x0, #0xd10
    7c8c:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7c90:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7c94:	f900337f 	str	xzr, [x27, #96]
    7c98:	97ffeb5e 	bl	2a10 <getenv@plt>
    7c9c:	b4000820 	cbz	x0, 7da0 <f12+0x350>
    7ca0:	39400001 	ldrb	w1, [x0]
    7ca4:	7100c03f 	cmp	w1, #0x30
    7ca8:	540007c1 	b.ne	7da0 <f12+0x350>  // b.any
    7cac:	39400400 	ldrb	w0, [x0, #1]
    7cb0:	35000780 	cbnz	w0, 7da0 <f12+0x350>
    7cb4:	9101c282 	add	x2, x20, #0x70
    7cb8:	2f000400 	mvni	v0.2s, #0x0
    7cbc:	b9400360 	ldr	w0, [x27]
    7cc0:	52800025 	mov	w5, #0x1                   	// #1
    7cc4:	91000744 	add	x4, x26, #0x1
    7cc8:	a900e378 	stp	x24, x24, [x27, #8]
    7ccc:	0b050003 	add	w3, w0, w5
    7cd0:	f9418841 	ldr	x1, [x2, #784]
    7cd4:	29001763 	stp	w3, w5, [x27]
    7cd8:	f9002b7f 	str	xzr, [x27, #80]
    7cdc:	f9007444 	str	x4, [x2, #232]
    7ce0:	fd002f60 	str	d0, [x27, #88]
    7ce4:	b4001681 	cbz	x1, 7fb4 <f12+0x564>
    7ce8:	911cc339 	add	x25, x25, #0x730
    7cec:	14000003 	b	7cf8 <f12+0x2a8>
    7cf0:	f9400021 	ldr	x1, [x1]
    7cf4:	b4001601 	cbz	x1, 7fb4 <f12+0x564>
    7cf8:	f9400422 	ldr	x2, [x1, #8]
    7cfc:	eb19005f 	cmp	x2, x25
    7d00:	54ffff81 	b.ne	7cf0 <f12+0x2a0>  // b.any
    7d04:	f9400820 	ldr	x0, [x1, #16]
    7d08:	2a1a03e2 	mov	w2, w26
    7d0c:	b9400001 	ldr	w1, [x0]
    7d10:	f9002b60 	str	x0, [x27, #80]
    7d14:	b9005f61 	str	w1, [x27, #92]
    7d18:	37f80081 	tbnz	w1, #31, 7d28 <f12+0x2d8>
    7d1c:	52800d05 	mov	w5, #0x68                  	// #104
    7d20:	9b257021 	smaddl	x1, w1, w5, x28
    7d24:	b900583a 	str	w26, [x1, #88]
    7d28:	b9000002 	str	w2, [x0]
    7d2c:	52800020 	mov	w0, #0x1                   	// #1
    7d30:	b90003e3 	str	w3, [sp]
    7d34:	f90007e4 	str	x4, [sp, #8]
    7d38:	97ffee2e 	bl	35f0 <descent_phase_step>
    7d3c:	f94007e4 	ldr	x4, [sp, #8]
    7d40:	aa1303e0 	mov	x0, x19
    7d44:	b94003e3 	ldr	w3, [sp]
    7d48:	d2800002 	mov	x2, #0x0                   	// #0
    7d4c:	b40005d3 	cbz	x19, 7e04 <f12+0x3b4>
    7d50:	f9400800 	ldr	x0, [x0, #16]
    7d54:	91000442 	add	x2, x2, #0x1
    7d58:	b5ffffc0 	cbnz	x0, 7d50 <f12+0x300>
    7d5c:	aa1303e1 	mov	x1, x19
    7d60:	f9400821 	ldr	x1, [x1, #16]
    7d64:	91000400 	add	x0, x0, #0x1
    7d68:	b5ffffc1 	cbnz	x1, 7d60 <f12+0x310>
    7d6c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7d70:	eb01001f 	cmp	x0, x1
    7d74:	54000108 	b.hi	7d94 <f12+0x344>  // b.pmore
    7d78:	f100005f 	cmp	x2, #0x0
    7d7c:	5400044d 	b.le	7e04 <f12+0x3b4>
    7d80:	eb00005f 	cmp	x2, x0
    7d84:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7d88:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7d8c:	eb01033f 	cmp	x25, x1
    7d90:	54001289 	b.ls	7fe0 <f12+0x590>  // b.plast
    7d94:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    7d98:	913f8000 	add	x0, x0, #0xfe0
    7d9c:	97fff0dd 	bl	4110 <fwp_trap>
    7da0:	9101c280 	add	x0, x20, #0x70
    7da4:	f9406001 	ldr	x1, [x0, #192]
    7da8:	b4fff861 	cbz	x1, 7cb4 <f12+0x264>
    7dac:	3cc88002 	ldur	q2, [x0, #136]
    7db0:	91022001 	add	x1, x0, #0x88
    7db4:	3cc98001 	ldur	q1, [x0, #152]
    7db8:	f900601f 	str	xzr, [x0, #192]
    7dbc:	4f000400 	movi	v0.4s, #0x0
    7dc0:	ad010762 	stp	q2, q1, [x27, #32]
    7dc4:	a94a8002 	ldp	x2, x0, [x0, #168]
    7dc8:	f9000f60 	str	x0, [x27, #24]
    7dcc:	f9401820 	ldr	x0, [x1, #48]
    7dd0:	f9002362 	str	x2, [x27, #64]
    7dd4:	f9002760 	str	x0, [x27, #72]
    7dd8:	ad000020 	stp	q0, q0, [x1]
    7ddc:	3d800820 	str	q0, [x1, #32]
    7de0:	f900183f 	str	xzr, [x1, #48]
    7de4:	17ffffb4 	b	7cb4 <f12+0x264>
    7de8:	f0ffffe0 	adrp	x0, 6000 <e161+0x90>
    7dec:	9118c000 	add	x0, x0, #0x630
    7df0:	94001748 	bl	db10 <atexit>
    7df4:	35003b80 	cbnz	w0, 8564 <f12+0xb14>
    7df8:	52800020 	mov	w0, #0x1                   	// #1
    7dfc:	b9034740 	str	w0, [x26, #836]
    7e00:	17ffff67 	b	7b9c <f12+0x14c>
    7e04:	d3707c60 	ubfiz	x0, x3, #16, #32
    7e08:	52800041 	mov	w1, #0x2                   	// #2
    7e0c:	aa040018 	orr	x24, x0, x4
    7e10:	d2800100 	mov	x0, #0x8                   	// #8
    7e14:	97fff437 	bl	4ef0 <fwp_heap_alloc>
    7e18:	aa0003fa 	mov	x26, x0
    7e1c:	911742a0 	add	x0, x21, #0x5d0
    7e20:	f900035f 	str	xzr, [x26]
    7e24:	f949d801 	ldr	x1, [x0, #5040]
    7e28:	f949ec00 	ldr	x0, [x0, #5080]
    7e2c:	cb010341 	sub	x1, x26, x1
    7e30:	eb00403f 	cmp	x1, x0, lsl #16
    7e34:	54000f82 	b.cs	8024 <f12+0x5d4>  // b.hs, b.nlast
    7e38:	d2800019 	mov	x25, #0x0                   	// #0
    7e3c:	911742a2 	add	x2, x21, #0x5d0
    7e40:	d350fc20 	lsr	x0, x1, #16
    7e44:	8b000800 	add	x0, x0, x0, lsl #2
    7e48:	f949fc43 	ldr	x3, [x2, #5112]
    7e4c:	d37df002 	lsl	x2, x0, #3
    7e50:	8b020060 	add	x0, x3, x2
    7e54:	f940101b 	ldr	x27, [x0, #32]
    7e58:	b400025b 	cbz	x27, 7ea0 <f12+0x450>
    7e5c:	38626862 	ldrb	w2, [x3, x2]
    7e60:	7100085f 	cmp	w2, #0x2
    7e64:	54000e60 	b.eq	8030 <f12+0x5e0>  // b.none
    7e68:	7100045f 	cmp	w2, #0x1
    7e6c:	540001a1 	b.ne	7ea0 <f12+0x450>  // b.any
    7e70:	29430002 	ldp	w2, w0, [x0, #24]
    7e74:	92403c21 	and	x1, x1, #0xffff
    7e78:	9b027c21 	mul	x1, x1, x2
    7e7c:	d360fc21 	lsr	x1, x1, #32
    7e80:	eb00003f 	cmp	x1, x0
    7e84:	540000e2 	b.cs	7ea0 <f12+0x450>  // b.hs, b.nlast
    7e88:	8b01037b 	add	x27, x27, x1
    7e8c:	39400360 	ldrb	w0, [x27]
    7e90:	7103fc1f 	cmp	w0, #0xff
    7e94:	540034c0 	b.eq	852c <f12+0xadc>  // b.none
    7e98:	52800020 	mov	w0, #0x1                   	// #1
    7e9c:	39000360 	strb	w0, [x27]
    7ea0:	b4000239 	cbz	x25, 7ee4 <f12+0x494>
    7ea4:	d3607f04 	lsl	x4, x24, #32
    7ea8:	aa1303e0 	mov	x0, x19
    7eac:	f9400665 	ldr	x5, [x19, #8]
    7eb0:	aa0403e3 	mov	x3, x4
    7eb4:	91002342 	add	x2, x26, #0x8
    7eb8:	d2800001 	mov	x1, #0x0                   	// #0
    7ebc:	14000005 	b	7ed0 <f12+0x480>
    7ec0:	f9400405 	ldr	x5, [x0, #8]
    7ec4:	ab010083 	adds	x3, x4, x1
    7ec8:	91004042 	add	x2, x2, #0x10
    7ecc:	54005c06 	b.vs	8a4c <f12+0xffc>
    7ed0:	a9000c45 	stp	x5, x3, [x2]
    7ed4:	91000421 	add	x1, x1, #0x1
    7ed8:	f9400800 	ldr	x0, [x0, #16]
    7edc:	eb19003f 	cmp	x1, x25
    7ee0:	54ffff03 	b.cc	7ec0 <f12+0x470>  // b.lo, b.ul, b.last
    7ee4:	f9400340 	ldr	x0, [x26]
    7ee8:	f100041f 	cmp	x0, #0x1
    7eec:	540009c9 	b.ls	8024 <f12+0x5d4>  // b.plast
    7ef0:	d341fc00 	lsr	x0, x0, #1
    7ef4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7ef8:	d100041c 	sub	x28, x0, #0x1
    7efc:	eb01039f 	cmp	x28, x1
    7f00:	54fff4a8 	b.hi	7d94 <f12+0x344>  // b.pmore
    7f04:	b400091c 	cbz	x28, 8024 <f12+0x5d4>
    7f08:	d1002341 	sub	x1, x26, #0x8
    7f0c:	91002359 	add	x25, x26, #0x8
    7f10:	8b00103b 	add	x27, x1, x0, lsl #4
    7f14:	d503201f 	nop
    7f18:	f9400720 	ldr	x0, [x25, #8]
    7f1c:	f9400f21 	ldr	x1, [x25, #24]
    7f20:	fd400320 	ldr	d0, [x25]
    7f24:	fd400b21 	ldr	d1, [x25, #16]
    7f28:	97fff5ae 	bl	55e0 <w107>
    7f2c:	a9000720 	stp	x0, x1, [x25]
    7f30:	91004339 	add	x25, x25, #0x10
    7f34:	eb1b033f 	cmp	x25, x27
    7f38:	54ffff01 	b.ne	7f18 <f12+0x4c8>  // b.any
    7f3c:	aa1a03fb 	mov	x27, x26
    7f40:	d37ffb99 	lsl	x25, x28, #1
    7f44:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7f48:	d280001c 	mov	x28, #0x0                   	// #0
    7f4c:	f8010779 	str	x25, [x27], #16
    7f50:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    7f54:	aa0303e0 	mov	x0, x3
    7f58:	91000b9c 	add	x28, x28, #0x2
    7f5c:	97fff549 	bl	5480 <f128.constprop.0>
    7f60:	aa0003e3 	mov	x3, x0
    7f64:	eb19039f 	cmp	x28, x25
    7f68:	54ffff43 	b.cc	7f50 <f12+0x500>  // b.lo, b.ul, b.last
    7f6c:	aa1a03e0 	mov	x0, x26
    7f70:	f90003e3 	str	x3, [sp]
    7f74:	97fffb4f 	bl	6cb0 <fwp_drop4>
    7f78:	93407f18 	sxtw	x24, w24
    7f7c:	52800040 	mov	w0, #0x2                   	// #2
    7f80:	97ffed9c 	bl	35f0 <descent_phase_step>
    7f84:	aa1803e0 	mov	x0, x24
    7f88:	97fff266 	bl	4920 <fwp_tape_of>
    7f8c:	f9403019 	ldr	x25, [x0, #96]
    7f90:	aa0003e5 	mov	x5, x0
    7f94:	f94003e3 	ldr	x3, [sp]
    7f98:	b4000579 	cbz	x25, 8044 <f12+0x5f4>
    7f9c:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    7fa0:	913d4000 	add	x0, x0, #0xf50
    7fa4:	97fff05b 	bl	4110 <fwp_trap>
    7fa8:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    7fac:	91004000 	add	x0, x0, #0x10
    7fb0:	97fff058 	bl	4110 <fwp_trap>
    7fb4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    7fb8:	91010000 	add	x0, x0, #0x40
    7fbc:	97fff055 	bl	4110 <fwp_trap>
    7fc0:	d37ffb7a 	lsl	x26, x27, #1
    7fc4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7fc8:	eb00035f 	cmp	x26, x0
    7fcc:	9a80d35a 	csel	x26, x26, x0, le
    7fd0:	8b1a0741 	add	x1, x26, x26, lsl #1
    7fd4:	8b010b41 	add	x1, x26, x1, lsl #2
    7fd8:	d37df021 	lsl	x1, x1, #3
    7fdc:	17ffff0f 	b	7c18 <f12+0x1c8>
    7fe0:	d37ffb3b 	lsl	x27, x25, #1
    7fe4:	d3707c63 	ubfiz	x3, x3, #16, #32
    7fe8:	91000760 	add	x0, x27, #0x1
    7fec:	52800041 	mov	w1, #0x2                   	// #2
    7ff0:	aa040078 	orr	x24, x3, x4
    7ff4:	d37df000 	lsl	x0, x0, #3
    7ff8:	97fff3be 	bl	4ef0 <fwp_heap_alloc>
    7ffc:	aa0003fa 	mov	x26, x0
    8000:	911742a1 	add	x1, x21, #0x5d0
    8004:	aa0103e0 	mov	x0, x1
    8008:	f900035b 	str	x27, [x26]
    800c:	f949d821 	ldr	x1, [x1, #5040]
    8010:	f949ec00 	ldr	x0, [x0, #5080]
    8014:	cb010341 	sub	x1, x26, x1
    8018:	eb00403f 	cmp	x1, x0, lsl #16
    801c:	54fff103 	b.cc	7e3c <f12+0x3ec>  // b.lo, b.ul, b.last
    8020:	b5fff439 	cbnz	x25, 7ea4 <f12+0x454>
    8024:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    8028:	f900035f 	str	xzr, [x26]
    802c:	17ffffd0 	b	7f6c <f12+0x51c>
    8030:	72003c3f 	tst	w1, #0xffff
    8034:	54fff361 	b.ne	7ea0 <f12+0x450>  // b.any
    8038:	17ffff95 	b	7e8c <f12+0x43c>
    803c:	97fff16a 	bl	45e4 <fwp_rc_wide_dup>
    8040:	17fffec1 	b	7b44 <f12+0xf4>
    8044:	f9000be3 	str	x3, [sp, #16]
    8048:	97ffebd2 	bl	2f90 <fwp_tape_unlink_scope>
    804c:	a94288bb 	ldp	x27, x2, [x5, #40]
    8050:	f90003e2 	str	x2, [sp]
    8054:	f9401ca2 	ldr	x2, [x5, #56]
    8058:	b90004bf 	str	wzr, [x5, #4]
    805c:	b94000a1 	ldr	w1, [x5]
    8060:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8064:	f90007e2 	str	x2, [sp, #8]
    8068:	a940a4bc 	ldp	x28, x9, [x5, #8]
    806c:	6b00003f 	cmp	w1, w0
    8070:	f9400be3 	ldr	x3, [sp, #16]
    8074:	a941e8a7 	ldp	x7, x26, [x5, #24]
    8078:	f94020b9 	ldr	x25, [x5, #64]
    807c:	f94024a2 	ldr	x2, [x5, #72]
    8080:	54000108 	b.hi	80a0 <f12+0x650>  // b.pmore
    8084:	9101c281 	add	x1, x20, #0x70
    8088:	92403f00 	and	x0, x24, #0xffff
    808c:	d1000400 	sub	x0, x0, #0x1
    8090:	f9407428 	ldr	x8, [x1, #232]
    8094:	eb08001f 	cmp	x0, x8
    8098:	5400004a 	b.ge	80a0 <f12+0x650>  // b.tcont
    809c:	f9007420 	str	x0, [x1, #232]
    80a0:	4f000400 	movi	v0.4s, #0x0
    80a4:	9101c281 	add	x1, x20, #0x70
    80a8:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    80ac:	913fc000 	add	x0, x0, #0xff0
    80b0:	f9000cbf 	str	xzr, [x5, #24]
    80b4:	910163e4 	add	x4, sp, #0x58
    80b8:	f9418828 	ldr	x8, [x1, #784]
    80bc:	3c8080a0 	stur	q0, [x5, #8]
    80c0:	9101c3e6 	add	x6, sp, #0x70
    80c4:	a90583e8 	stp	x8, x0, [sp, #88]
    80c8:	f94003e0 	ldr	x0, [sp]
    80cc:	ad0100a0 	stp	q0, q0, [x5, #32]
    80d0:	f90043e0 	str	x0, [sp, #128]
    80d4:	f94007e0 	ldr	x0, [sp, #8]
    80d8:	a90113e6 	stp	x6, x4, [sp, #16]
    80dc:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    80e0:	a906ebe6 	stp	x6, x26, [sp, #104]
    80e4:	f9003ffb 	str	x27, [sp, #120]
    80e8:	f90047e0 	str	x0, [sp, #136]
    80ec:	a9091ff9 	stp	x25, x7, [sp, #144]
    80f0:	f90053e2 	str	x2, [sp, #160]
    80f4:	f9018824 	str	x4, [x1, #784]
    80f8:	b7f82163 	tbnz	x3, #63, 8524 <f12+0xad4>
    80fc:	eb83831f 	cmp	x24, x3, asr #32
    8100:	54000080 	b.eq	8110 <f12+0x6c0>  // b.none
    8104:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    8108:	913c2000 	add	x0, x0, #0xf08
    810c:	97fff001 	bl	4110 <fwp_trap>
    8110:	92407c60 	and	x0, x3, #0xffffffff
    8114:	eb00039f 	cmp	x28, x0
    8118:	9a80c798 	csinc	x24, x28, x0, gt
    811c:	eb23413f 	cmp	x9, w3, uxtw
    8120:	540020cd 	b.le	8538 <f12+0xae8>
    8124:	eb18005f 	cmp	x2, x24
    8128:	540020ea 	b.ge	8544 <f12+0xaf4>  // b.tcont
    812c:	f100005f 	cmp	x2, #0x0
    8130:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    8134:	9a981042 	csel	x2, x2, x24, ne	// ne = any
    8138:	14000004 	b	8148 <f12+0x6f8>
    813c:	eb01005f 	cmp	x2, x1
    8140:	d37ff842 	lsl	x2, x2, #1
    8144:	9a98d042 	csel	x2, x2, x24, le
    8148:	eb18005f 	cmp	x2, x24
    814c:	54ffff8b 	b.lt	813c <f12+0x6ec>  // b.tstop
    8150:	f90017e3 	str	x3, [sp, #40]
    8154:	b40036d9 	cbz	x25, 882c <f12+0xddc>
    8158:	aa1903e0 	mov	x0, x25
    815c:	d37df041 	lsl	x1, x2, #3
    8160:	f90013e2 	str	x2, [sp, #32]
    8164:	97ffe9c3 	bl	2870 <realloc@plt>
    8168:	a9420fe2 	ldp	x2, x3, [sp, #32]
    816c:	aa0003f9 	mov	x25, x0
    8170:	b4001eb9 	cbz	x25, 8544 <f12+0xaf4>
    8174:	f9004bf9 	str	x25, [sp, #144]
    8178:	f90053e2 	str	x2, [sp, #160]
    817c:	b5001c78 	cbnz	x24, 8508 <f12+0xab8>
    8180:	b7f800c3 	tbnz	x3, #63, 8198 <f12+0x748>
    8184:	92407c63 	and	x3, x3, #0xffffffff
    8188:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    818c:	fc637b20 	ldr	d0, [x25, x3, lsl #3]
    8190:	1e612800 	fadd	d0, d0, d1
    8194:	fc237b20 	str	d0, [x25, x3, lsl #3]
    8198:	9101c281 	add	x1, x20, #0x70
    819c:	cb1c0303 	sub	x3, x24, x28
    81a0:	52800060 	mov	w0, #0x3                   	// #3
    81a4:	a9428825 	ldp	x5, x2, [x1, #40]
    81a8:	8b1c0042 	add	x2, x2, x28
    81ac:	8b050063 	add	x3, x3, x5
    81b0:	a9028823 	stp	x3, x2, [x1, #40]
    81b4:	97ffed0f 	bl	35f0 <descent_phase_step>
    81b8:	d1000700 	sub	x0, x24, #0x1
    81bc:	d1000782 	sub	x2, x28, #0x1
    81c0:	eb00039f 	cmp	x28, x0
    81c4:	540003ec 	b.gt	8240 <f12+0x7f0>
    81c8:	fc607b20 	ldr	d0, [x25, x0, lsl #3]
    81cc:	1e602008 	fcmp	d0, #0.0
    81d0:	54000320 	b.eq	8234 <f12+0x7e4>  // b.none
    81d4:	cb1c0be1 	neg	x1, x28, lsl #2
    81d8:	cb1c03e5 	neg	x5, x28
    81dc:	8b010343 	add	x3, x26, x1
    81e0:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    81e4:	37f80123 	tbnz	w3, #31, 8208 <f12+0x7b8>
    81e8:	f94003e4 	ldr	x4, [sp]
    81ec:	93407c63 	sxtw	x3, w3
    81f0:	8b050c87 	add	x7, x4, x5, lsl #3
    81f4:	fc637b21 	ldr	d1, [x25, x3, lsl #3]
    81f8:	fc6078e2 	ldr	d2, [x7, x0, lsl #3]
    81fc:	1e620802 	fmul	d2, d0, d2
    8200:	1e622821 	fadd	d1, d1, d2
    8204:	fc237b21 	str	d1, [x25, x3, lsl #3]
    8208:	8b010361 	add	x1, x27, x1
    820c:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    8210:	37f80121 	tbnz	w1, #31, 8234 <f12+0x7e4>
    8214:	f94007e3 	ldr	x3, [sp, #8]
    8218:	93407c21 	sxtw	x1, w1
    821c:	8b050c65 	add	x5, x3, x5, lsl #3
    8220:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    8224:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    8228:	1e620800 	fmul	d0, d0, d2
    822c:	1e602820 	fadd	d0, d1, d0
    8230:	fc217b20 	str	d0, [x25, x1, lsl #3]
    8234:	d1000400 	sub	x0, x0, #0x1
    8238:	eb00005f 	cmp	x2, x0
    823c:	54fffc61 	b.ne	81c8 <f12+0x778>  // b.any
    8240:	52800080 	mov	w0, #0x4                   	// #4
    8244:	97ffeceb 	bl	35f0 <descent_phase_step>
    8248:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    824c:	eb00039f 	cmp	x28, x0
    8250:	54001a28 	b.hi	8594 <f12+0xb44>  // b.pmore
    8254:	91000780 	add	x0, x28, #0x1
    8258:	52800041 	mov	w1, #0x2                   	// #2
    825c:	d37df000 	lsl	x0, x0, #3
    8260:	97fff324 	bl	4ef0 <fwp_heap_alloc>
    8264:	aa0003f8 	mov	x24, x0
    8268:	f800841c 	str	x28, [x0], #8
    826c:	d2800001 	mov	x1, #0x0                   	// #0
    8270:	b40000dc 	cbz	x28, 8288 <f12+0x838>
    8274:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    8278:	f8217802 	str	x2, [x0, x1, lsl #3]
    827c:	91000421 	add	x1, x1, #0x1
    8280:	eb01039f 	cmp	x28, x1
    8284:	54ffff81 	b.ne	8274 <f12+0x824>  // b.any
    8288:	528000a0 	mov	w0, #0x5                   	// #5
    828c:	97ffecd9 	bl	35f0 <descent_phase_step>
    8290:	9101c281 	add	x1, x20, #0x70
    8294:	f9400fe2 	ldr	x2, [sp, #24]
    8298:	f9418820 	ldr	x0, [x1, #784]
    829c:	eb02001f 	cmp	x0, x2
    82a0:	54003d81 	b.ne	8a50 <f12+0x1000>  // b.any
    82a4:	f9400be0 	ldr	x0, [sp, #16]
    82a8:	f9402ffa 	ldr	x26, [sp, #88]
    82ac:	f901883a 	str	x26, [x1, #784]
    82b0:	97ffef50 	bl	3ff0 <fwp_tape_buffers_release>
    82b4:	528000c0 	mov	w0, #0x6                   	// #6
    82b8:	97ffecce 	bl	35f0 <descent_phase_step>
    82bc:	911742a2 	add	x2, x21, #0x5d0
    82c0:	f949d841 	ldr	x1, [x2, #5040]
    82c4:	f949ec40 	ldr	x0, [x2, #5080]
    82c8:	cb010301 	sub	x1, x24, x1
    82cc:	eb00403f 	cmp	x1, x0, lsl #16
    82d0:	54000322 	b.cs	8334 <f12+0x8e4>  // b.hs, b.nlast
    82d4:	d350fc20 	lsr	x0, x1, #16
    82d8:	f949fc43 	ldr	x3, [x2, #5112]
    82dc:	8b000800 	add	x0, x0, x0, lsl #2
    82e0:	d37df002 	lsl	x2, x0, #3
    82e4:	8b020060 	add	x0, x3, x2
    82e8:	f9401019 	ldr	x25, [x0, #32]
    82ec:	b4000259 	cbz	x25, 8334 <f12+0x8e4>
    82f0:	38626862 	ldrb	w2, [x3, x2]
    82f4:	7100085f 	cmp	w2, #0x2
    82f8:	54002ae0 	b.eq	8854 <f12+0xe04>  // b.none
    82fc:	7100045f 	cmp	w2, #0x1
    8300:	540001a1 	b.ne	8334 <f12+0x8e4>  // b.any
    8304:	29430002 	ldp	w2, w0, [x0, #24]
    8308:	92403c21 	and	x1, x1, #0xffff
    830c:	9b027c21 	mul	x1, x1, x2
    8310:	d360fc21 	lsr	x1, x1, #32
    8314:	eb00003f 	cmp	x1, x0
    8318:	540000e2 	b.cs	8334 <f12+0x8e4>  // b.hs, b.nlast
    831c:	8b010339 	add	x25, x25, x1
    8320:	39400320 	ldrb	w0, [x25]
    8324:	7103fc1f 	cmp	w0, #0xff
    8328:	54002b40 	b.eq	8890 <f12+0xe40>  // b.none
    832c:	52800020 	mov	w0, #0x1                   	// #1
    8330:	39000320 	strb	w0, [x25]
    8334:	eb17035f 	cmp	x26, x23
    8338:	540038c1 	b.ne	8a50 <f12+0x1000>  // b.any
    833c:	f94023e1 	ldr	x1, [sp, #64]
    8340:	9101c294 	add	x20, x20, #0x70
    8344:	aa1603e0 	mov	x0, x22
    8348:	f9018a81 	str	x1, [x20, #784]
    834c:	97fff8f9 	bl	6730 <fwp_tape_scope_release>
    8350:	f9400300 	ldr	x0, [x24]
    8354:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8358:	b7f812c0 	tbnz	x0, #63, 85b0 <f12+0xb60>
    835c:	911742a2 	add	x2, x21, #0x5d0
    8360:	f949d840 	ldr	x0, [x2, #5040]
    8364:	f949ec41 	ldr	x1, [x2, #5080]
    8368:	cb000300 	sub	x0, x24, x0
    836c:	eb01401f 	cmp	x0, x1, lsl #16
    8370:	54001202 	b.cs	85b0 <f12+0xb60>  // b.hs, b.nlast
    8374:	d350fc01 	lsr	x1, x0, #16
    8378:	f949fc44 	ldr	x4, [x2, #5112]
    837c:	8b010821 	add	x1, x1, x1, lsl #2
    8380:	d37df021 	lsl	x1, x1, #3
    8384:	8b010083 	add	x3, x4, x1
    8388:	f9401062 	ldr	x2, [x3, #32]
    838c:	b4001122 	cbz	x2, 85b0 <f12+0xb60>
    8390:	38616881 	ldrb	w1, [x4, x1]
    8394:	7100083f 	cmp	w1, #0x2
    8398:	54001080 	b.eq	85a8 <f12+0xb58>  // b.none
    839c:	7100043f 	cmp	w1, #0x1
    83a0:	54001081 	b.ne	85b0 <f12+0xb60>  // b.any
    83a4:	29430464 	ldp	w4, w1, [x3, #24]
    83a8:	92403c00 	and	x0, x0, #0xffff
    83ac:	9b047c00 	mul	x0, x0, x4
    83b0:	d360fc00 	lsr	x0, x0, #32
    83b4:	eb01001f 	cmp	x0, x1
    83b8:	54000fc2 	b.cs	85b0 <f12+0xb60>  // b.hs, b.nlast
    83bc:	8b000042 	add	x2, x2, x0
    83c0:	39400040 	ldrb	w0, [x2]
    83c4:	7100041f 	cmp	w0, #0x1
    83c8:	54000f41 	b.ne	85b0 <f12+0xb60>  // b.any
    83cc:	aa1803f6 	mov	x22, x24
    83d0:	d2800000 	mov	x0, #0x0                   	// #0
    83d4:	910022c2 	add	x2, x22, #0x8
    83d8:	d2800001 	mov	x1, #0x0                   	// #0
    83dc:	b40001f7 	cbz	x23, 8418 <f12+0x9c8>
    83e0:	d0000023 	adrp	x3, e000 <_IO_stdin_used+0x4c0>
    83e4:	91002304 	add	x4, x24, #0x8
    83e8:	fd449861 	ldr	d1, [x3, #2352]
    83ec:	f9400305 	ldr	x5, [x24]
    83f0:	aa0403e3 	mov	x3, x4
    83f4:	b7f80d65 	tbnz	x5, #63, 85a0 <f12+0xb50>
    83f8:	f94002c5 	ldr	x5, [x22]
    83fc:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    8400:	b7f82245 	tbnz	x5, #63, 8848 <f12+0xdf8>
    8404:	1e600820 	fmul	d0, d1, d0
    8408:	91000421 	add	x1, x1, #0x1
    840c:	fc008440 	str	d0, [x2], #8
    8410:	eb0102ff 	cmp	x23, x1
    8414:	54fffec1 	b.ne	83ec <f12+0x99c>  // b.any
    8418:	97fffa26 	bl	6cb0 <fwp_drop4>
    841c:	b4002313 	cbz	x19, 887c <f12+0xe2c>
    8420:	aa1303e0 	mov	x0, x19
    8424:	d2800014 	mov	x20, #0x0                   	// #0
    8428:	f9400800 	ldr	x0, [x0, #16]
    842c:	91000694 	add	x20, x20, #0x1
    8430:	b5ffffc0 	cbnz	x0, 8428 <f12+0x9d8>
    8434:	f94002c0 	ldr	x0, [x22]
    8438:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    843c:	b7f81120 	tbnz	x0, #63, 8660 <f12+0xc10>
    8440:	911742a1 	add	x1, x21, #0x5d0
    8444:	f949d820 	ldr	x0, [x1, #5040]
    8448:	f949ec22 	ldr	x2, [x1, #5080]
    844c:	cb0002c0 	sub	x0, x22, x0
    8450:	eb02401f 	cmp	x0, x2, lsl #16
    8454:	54001042 	b.cs	865c <f12+0xc0c>  // b.hs, b.nlast
    8458:	d350fc02 	lsr	x2, x0, #16
    845c:	d2800503 	mov	x3, #0x28                  	// #40
    8460:	f949fc24 	ldr	x4, [x1, #5112]
    8464:	9b037c42 	mul	x2, x2, x3
    8468:	8b020083 	add	x3, x4, x2
    846c:	f9401061 	ldr	x1, [x3, #32]
    8470:	b4000f61 	cbz	x1, 865c <f12+0xc0c>
    8474:	38626882 	ldrb	w2, [x4, x2]
    8478:	7100085f 	cmp	w2, #0x2
    847c:	54000ec0 	b.eq	8654 <f12+0xc04>  // b.none
    8480:	7100045f 	cmp	w2, #0x1
    8484:	54000ec1 	b.ne	865c <f12+0xc0c>  // b.any
    8488:	29430864 	ldp	w4, w2, [x3, #24]
    848c:	92403c00 	and	x0, x0, #0xffff
    8490:	9b047c00 	mul	x0, x0, x4
    8494:	d360fc00 	lsr	x0, x0, #32
    8498:	eb02001f 	cmp	x0, x2
    849c:	54000e02 	b.cs	865c <f12+0xc0c>  // b.hs, b.nlast
    84a0:	8b000021 	add	x1, x1, x0
    84a4:	3940003c 	ldrb	w28, [x1]
    84a8:	7100079f 	cmp	w28, #0x1
    84ac:	54000d81 	b.ne	865c <f12+0xc0c>  // b.any
    84b0:	910022d9 	add	x25, x22, #0x8
    84b4:	eb14031f 	cmp	x24, x20
    84b8:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    84bc:	b4001ff8 	cbz	x24, 88b8 <f12+0xe68>
    84c0:	d37df304 	lsl	x4, x24, #3
    84c4:	aa1303e1 	mov	x1, x19
    84c8:	910022c3 	add	x3, x22, #0x8
    84cc:	d2800000 	mov	x0, #0x0                   	// #0
    84d0:	14000009 	b	84f4 <f12+0xaa4>
    84d4:	fc606841 	ldr	d1, [x2, x0]
    84d8:	fd400420 	ldr	d0, [x1, #8]
    84dc:	1e613800 	fsub	d0, d0, d1
    84e0:	fc206b20 	str	d0, [x25, x0]
    84e4:	91002000 	add	x0, x0, #0x8
    84e8:	f9400821 	ldr	x1, [x1, #16]
    84ec:	eb04001f 	cmp	x0, x4
    84f0:	54000e40 	b.eq	86b8 <f12+0xc68>  // b.none
    84f4:	f94002c5 	ldr	x5, [x22]
    84f8:	aa0303e2 	mov	x2, x3
    84fc:	b6fffec5 	tbz	x5, #63, 84d4 <f12+0xa84>
    8500:	f9400ac2 	ldr	x2, [x22, #16]
    8504:	17fffff4 	b	84d4 <f12+0xa84>
    8508:	d37df302 	lsl	x2, x24, #3
    850c:	aa1903e0 	mov	x0, x25
    8510:	52800001 	mov	w1, #0x0                   	// #0
    8514:	f90013e3 	str	x3, [sp, #32]
    8518:	97ffe8ce 	bl	2850 <memset@plt>
    851c:	f94013e3 	ldr	x3, [sp, #32]
    8520:	17ffff18 	b	8180 <f12+0x730>
    8524:	aa1c03f8 	mov	x24, x28
    8528:	17fffeff 	b	8124 <f12+0x6d4>
    852c:	aa1b03e0 	mov	x0, x27
    8530:	97ffef18 	bl	4190 <fwp_rc_forget_slot.part.0>
    8534:	17fffe59 	b	7e98 <f12+0x448>
    8538:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    853c:	913e0000 	add	x0, x0, #0xf80
    8540:	97ffeef4 	bl	4110 <fwp_trap>
    8544:	f100031f 	cmp	x24, #0x0
    8548:	fa401b20 	ccmp	x25, #0x0, #0x0, ne	// ne = any
    854c:	54ffe181 	b.ne	817c <f12+0x72c>  // b.any
    8550:	f9400be0 	ldr	x0, [sp, #16]
    8554:	9101c294 	add	x20, x20, #0x70
    8558:	f9402fe1 	ldr	x1, [sp, #88]
    855c:	f9018a81 	str	x1, [x20, #784]
    8560:	97ffeea4 	bl	3ff0 <fwp_tape_buffers_release>
    8564:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8568:	f947e863 	ldr	x3, [x3, #4048]
    856c:	d2800262 	mov	x2, #0x13                  	// #19
    8570:	d2800021 	mov	x1, #0x1                   	// #1
    8574:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x120>
    8578:	912d2000 	add	x0, x0, #0xb48
    857c:	f9400063 	ldr	x3, [x3]
    8580:	97ffe900 	bl	2980 <fwrite@plt>
    8584:	d2800000 	mov	x0, #0x0                   	// #0
    8588:	97ffe90a 	bl	29b0 <fflush@plt>
    858c:	52800cc0 	mov	w0, #0x66                  	// #102
    8590:	97ffe918 	bl	29f0 <_Exit@plt>
    8594:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    8598:	9101c000 	add	x0, x0, #0x70
    859c:	97ffeedd 	bl	4110 <fwp_trap>
    85a0:	f9400b03 	ldr	x3, [x24, #16]
    85a4:	17ffff95 	b	83f8 <f12+0x9a8>
    85a8:	72003c1f 	tst	w0, #0xffff
    85ac:	54fff0a0 	b.eq	83c0 <f12+0x970>  // b.none
    85b0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    85b4:	eb0002ff 	cmp	x23, x0
    85b8:	54fffee8 	b.hi	8594 <f12+0xb44>  // b.pmore
    85bc:	910006e0 	add	x0, x23, #0x1
    85c0:	52800021 	mov	w1, #0x1                   	// #1
    85c4:	d37df000 	lsl	x0, x0, #3
    85c8:	97fff24a 	bl	4ef0 <fwp_heap_alloc>
    85cc:	911742a2 	add	x2, x21, #0x5d0
    85d0:	f9000017 	str	x23, [x0]
    85d4:	aa0003f6 	mov	x22, x0
    85d8:	f949d841 	ldr	x1, [x2, #5040]
    85dc:	f949ec40 	ldr	x0, [x2, #5080]
    85e0:	cb0102c1 	sub	x1, x22, x1
    85e4:	eb00403f 	cmp	x1, x0, lsl #16
    85e8:	54000322 	b.cs	864c <f12+0xbfc>  // b.hs, b.nlast
    85ec:	d350fc20 	lsr	x0, x1, #16
    85f0:	d2800504 	mov	x4, #0x28                  	// #40
    85f4:	f949fc43 	ldr	x3, [x2, #5112]
    85f8:	9b047c00 	mul	x0, x0, x4
    85fc:	8b000062 	add	x2, x3, x0
    8600:	f9401054 	ldr	x20, [x2, #32]
    8604:	b4000254 	cbz	x20, 864c <f12+0xbfc>
    8608:	38606860 	ldrb	w0, [x3, x0]
    860c:	7100081f 	cmp	w0, #0x2
    8610:	540012e0 	b.eq	886c <f12+0xe1c>  // b.none
    8614:	7100041f 	cmp	w0, #0x1
    8618:	540001a1 	b.ne	864c <f12+0xbfc>  // b.any
    861c:	29430043 	ldp	w3, w0, [x2, #24]
    8620:	92403c21 	and	x1, x1, #0xffff
    8624:	9b037c21 	mul	x1, x1, x3
    8628:	d360fc21 	lsr	x1, x1, #32
    862c:	eb00003f 	cmp	x1, x0
    8630:	540000e2 	b.cs	864c <f12+0xbfc>  // b.hs, b.nlast
    8634:	8b010294 	add	x20, x20, x1
    8638:	39400280 	ldrb	w0, [x20]
    863c:	7103fc1f 	cmp	w0, #0xff
    8640:	54001100 	b.eq	8860 <f12+0xe10>  // b.none
    8644:	52800020 	mov	w0, #0x1                   	// #1
    8648:	39000280 	strb	w0, [x20]
    864c:	aa1803e0 	mov	x0, x24
    8650:	17ffff61 	b	83d4 <f12+0x984>
    8654:	72003c1f 	tst	w0, #0xffff
    8658:	54fff260 	b.eq	84a4 <f12+0xa54>  // b.none
    865c:	b4001253 	cbz	x19, 88a4 <f12+0xe54>
    8660:	aa1303f7 	mov	x23, x19
    8664:	d2800014 	mov	x20, #0x0                   	// #0
    8668:	f9400af7 	ldr	x23, [x23, #16]
    866c:	aa1403e0 	mov	x0, x20
    8670:	91000694 	add	x20, x20, #0x1
    8674:	b5ffffb7 	cbnz	x23, 8668 <f12+0xc18>
    8678:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    867c:	eb01029f 	cmp	x20, x1
    8680:	54ffb8a8 	b.hi	7d94 <f12+0x344>  // b.pmore
    8684:	91000800 	add	x0, x0, #0x2
    8688:	52800041 	mov	w1, #0x2                   	// #2
    868c:	d37df000 	lsl	x0, x0, #3
    8690:	97fff218 	bl	4ef0 <fwp_heap_alloc>
    8694:	aa1303e1 	mov	x1, x19
    8698:	aa0003f9 	mov	x25, x0
    869c:	f9400420 	ldr	x0, [x1, #8]
    86a0:	f8377b20 	str	x0, [x25, x23, lsl #3]
    86a4:	910006f7 	add	x23, x23, #0x1
    86a8:	f9400821 	ldr	x1, [x1, #16]
    86ac:	b5ffff81 	cbnz	x1, 869c <f12+0xc4c>
    86b0:	5280001c 	mov	w28, #0x0                   	// #0
    86b4:	17ffff80 	b	84b4 <f12+0xa64>
    86b8:	b4001c73 	cbz	x19, 8a44 <f12+0xff4>
    86bc:	911742a0 	add	x0, x21, #0x5d0
    86c0:	aa1303e2 	mov	x2, x19
    86c4:	d280001b 	mov	x27, #0x0                   	// #0
    86c8:	f949ec04 	ldr	x4, [x0, #5080]
    86cc:	f949d807 	ldr	x7, [x0, #5040]
    86d0:	f949fc06 	ldr	x6, [x0, #5112]
    86d4:	d370bc84 	lsl	x4, x4, #16
    86d8:	14000006 	b	86f0 <f12+0xca0>
    86dc:	f9400842 	ldr	x2, [x2, #16]
    86e0:	9100077b 	add	x27, x27, #0x1
    86e4:	f100005f 	cmp	x2, #0x0
    86e8:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    86ec:	54000322 	b.cs	8750 <f12+0xd00>  // b.hs, b.nlast
    86f0:	cb070040 	sub	x0, x2, x7
    86f4:	eb04001f 	cmp	x0, x4
    86f8:	540002c2 	b.cs	8750 <f12+0xd00>  // b.hs, b.nlast
    86fc:	d350fc01 	lsr	x1, x0, #16
    8700:	8b010821 	add	x1, x1, x1, lsl #2
    8704:	d37df021 	lsl	x1, x1, #3
    8708:	8b0100c5 	add	x5, x6, x1
    870c:	f94010a3 	ldr	x3, [x5, #32]
    8710:	b4000203 	cbz	x3, 8750 <f12+0xd00>
    8714:	386168c1 	ldrb	w1, [x6, x1]
    8718:	7100083f 	cmp	w1, #0x2
    871c:	54000820 	b.eq	8820 <f12+0xdd0>  // b.none
    8720:	7100043f 	cmp	w1, #0x1
    8724:	54000161 	b.ne	8750 <f12+0xd00>  // b.any
    8728:	294304a8 	ldp	w8, w1, [x5, #24]
    872c:	92403c00 	and	x0, x0, #0xffff
    8730:	9b087c00 	mul	x0, x0, x8
    8734:	d360fc00 	lsr	x0, x0, #32
    8738:	eb01001f 	cmp	x0, x1
    873c:	540000a2 	b.cs	8750 <f12+0xd00>  // b.hs, b.nlast
    8740:	8b000063 	add	x3, x3, x0
    8744:	39400060 	ldrb	w0, [x3]
    8748:	7100041f 	cmp	w0, #0x1
    874c:	54fffc80 	b.eq	86dc <f12+0xc8c>  // b.none
    8750:	d280001a 	mov	x26, #0x0                   	// #0
    8754:	eb18037f 	cmp	x27, x24
    8758:	540015c2 	b.cs	8a10 <f12+0xfc0>  // b.hs, b.nlast
    875c:	d1002320 	sub	x0, x25, #0x8
    8760:	aa1803f4 	mov	x20, x24
    8764:	911742b7 	add	x23, x21, #0x5d0
    8768:	d280001a 	mov	x26, #0x0                   	// #0
    876c:	f90007e0 	str	x0, [sp, #8]
    8770:	9102a3e0 	add	x0, sp, #0xa8
    8774:	f90003e0 	str	x0, [sp]
    8778:	14000012 	b	87c0 <f12+0xd70>
    877c:	7100045f 	cmp	w2, #0x1
    8780:	540001a1 	b.ne	87b4 <f12+0xd64>  // b.any
    8784:	294308a6 	ldp	w6, w2, [x5, #24]
    8788:	92403c21 	and	x1, x1, #0xffff
    878c:	9b067c21 	mul	x1, x1, x6
    8790:	d360fc21 	lsr	x1, x1, #32
    8794:	eb02003f 	cmp	x1, x2
    8798:	540000e2 	b.cs	87b4 <f12+0xd64>  // b.hs, b.nlast
    879c:	8b010000 	add	x0, x0, x1
    87a0:	39400001 	ldrb	w1, [x0]
    87a4:	7103fc3f 	cmp	w1, #0xff
    87a8:	54000900 	b.eq	88c8 <f12+0xe78>  // b.none
    87ac:	52800021 	mov	w1, #0x1                   	// #1
    87b0:	39000001 	strb	w1, [x0]
    87b4:	d1000694 	sub	x20, x20, #0x1
    87b8:	eb14037f 	cmp	x27, x20
    87bc:	540008e2 	b.cs	88d8 <f12+0xe88>  // b.hs, b.nlast
    87c0:	a94003e1 	ldp	x1, x0, [sp]
    87c4:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    87c8:	52800020 	mov	w0, #0x1                   	// #1
    87cc:	a90aebe2 	stp	x2, x26, [sp, #168]
    87d0:	97fff4bd 	bl	5ac4 <fwp_data.part.0.constprop.0>
    87d4:	aa0003fa 	mov	x26, x0
    87d8:	f949dae1 	ldr	x1, [x23, #5040]
    87dc:	f949eee0 	ldr	x0, [x23, #5080]
    87e0:	cb010341 	sub	x1, x26, x1
    87e4:	eb00403f 	cmp	x1, x0, lsl #16
    87e8:	54fffe62 	b.cs	87b4 <f12+0xd64>  // b.hs, b.nlast
    87ec:	d350fc20 	lsr	x0, x1, #16
    87f0:	f949fee6 	ldr	x6, [x23, #5112]
    87f4:	8b000800 	add	x0, x0, x0, lsl #2
    87f8:	d37df002 	lsl	x2, x0, #3
    87fc:	8b0200c5 	add	x5, x6, x2
    8800:	f94010a0 	ldr	x0, [x5, #32]
    8804:	b4fffd80 	cbz	x0, 87b4 <f12+0xd64>
    8808:	386268c2 	ldrb	w2, [x6, x2]
    880c:	7100085f 	cmp	w2, #0x2
    8810:	54fffb61 	b.ne	877c <f12+0xd2c>  // b.any
    8814:	72003c3f 	tst	w1, #0xffff
    8818:	54fffce1 	b.ne	87b4 <f12+0xd64>  // b.any
    881c:	17ffffe1 	b	87a0 <f12+0xd50>
    8820:	72003c1f 	tst	w0, #0xffff
    8824:	54fff961 	b.ne	8750 <f12+0xd00>  // b.any
    8828:	17ffffc7 	b	8744 <f12+0xcf4>
    882c:	aa0203e0 	mov	x0, x2
    8830:	d2800101 	mov	x1, #0x8                   	// #8
    8834:	f90013e2 	str	x2, [sp, #32]
    8838:	97ffe80a 	bl	2860 <calloc@plt>
    883c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    8840:	aa0003f9 	mov	x25, x0
    8844:	17fffe4b 	b	8170 <f12+0x720>
    8848:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    884c:	91020000 	add	x0, x0, #0x80
    8850:	97ffee30 	bl	4110 <fwp_trap>
    8854:	72003c3f 	tst	w1, #0xffff
    8858:	54ffd6e1 	b.ne	8334 <f12+0x8e4>  // b.any
    885c:	17fffeb1 	b	8320 <f12+0x8d0>
    8860:	aa1403e0 	mov	x0, x20
    8864:	97ffee4b 	bl	4190 <fwp_rc_forget_slot.part.0>
    8868:	17ffff77 	b	8644 <f12+0xbf4>
    886c:	72003c3f 	tst	w1, #0xffff
    8870:	54ffee40 	b.eq	8638 <f12+0xbe8>  // b.none
    8874:	aa1803e0 	mov	x0, x24
    8878:	17fffed7 	b	83d4 <f12+0x984>
    887c:	f94002d8 	ldr	x24, [x22]
    8880:	b7f80138 	tbnz	x24, #63, 88a4 <f12+0xe54>
    8884:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    8888:	d2800014 	mov	x20, #0x0                   	// #0
    888c:	17fffeed 	b	8440 <f12+0x9f0>
    8890:	aa1903e0 	mov	x0, x25
    8894:	97ffee3f 	bl	4190 <fwp_rc_forget_slot.part.0>
    8898:	9101c280 	add	x0, x20, #0x70
    889c:	f941881a 	ldr	x26, [x0, #784]
    88a0:	17fffea3 	b	832c <f12+0x8dc>
    88a4:	52800041 	mov	w1, #0x2                   	// #2
    88a8:	d2800100 	mov	x0, #0x8                   	// #8
    88ac:	97fff191 	bl	4ef0 <fwp_heap_alloc>
    88b0:	aa0003f9 	mov	x25, x0
    88b4:	5280001c 	mov	w28, #0x0                   	// #0
    88b8:	d280001a 	mov	x26, #0x0                   	// #0
    88bc:	7100039f 	cmp	w28, #0x0
    88c0:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    88c4:	14000036 	b	899c <f12+0xf4c>
    88c8:	f9000be0 	str	x0, [sp, #16]
    88cc:	97ffee31 	bl	4190 <fwp_rc_forget_slot.part.0>
    88d0:	f9400be0 	ldr	x0, [sp, #16]
    88d4:	17ffffb6 	b	87ac <f12+0xd5c>
    88d8:	d1000701 	sub	x1, x24, #0x1
    88dc:	cb180360 	sub	x0, x27, x24
    88e0:	eb01037f 	cmp	x27, x1
    88e4:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    88e8:	8b010000 	add	x0, x0, x1
    88ec:	b500093b 	cbnz	x27, 8a10 <f12+0xfc0>
    88f0:	7100039f 	cmp	w28, #0x0
    88f4:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    88f8:	b4000520 	cbz	x0, 899c <f12+0xf4c>
    88fc:	d1000414 	sub	x20, x0, #0x1
    8900:	911742b5 	add	x21, x21, #0x5d0
    8904:	52800038 	mov	w24, #0x1                   	// #1
    8908:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    890c:	52800020 	mov	w0, #0x1                   	// #1
    8910:	f94003e1 	ldr	x1, [sp]
    8914:	a90aebe2 	stp	x2, x26, [sp, #168]
    8918:	97fff46b 	bl	5ac4 <fwp_data.part.0.constprop.0>
    891c:	aa0003fa 	mov	x26, x0
    8920:	f949daa1 	ldr	x1, [x21, #5040]
    8924:	f949eea0 	ldr	x0, [x21, #5080]
    8928:	cb010341 	sub	x1, x26, x1
    892c:	eb00403f 	cmp	x1, x0, lsl #16
    8930:	54000302 	b.cs	8990 <f12+0xf40>  // b.hs, b.nlast
    8934:	d350fc20 	lsr	x0, x1, #16
    8938:	f949fea3 	ldr	x3, [x21, #5112]
    893c:	8b000800 	add	x0, x0, x0, lsl #2
    8940:	d37df002 	lsl	x2, x0, #3
    8944:	8b020060 	add	x0, x3, x2
    8948:	f940101b 	ldr	x27, [x0, #32]
    894c:	b400023b 	cbz	x27, 8990 <f12+0xf40>
    8950:	38626862 	ldrb	w2, [x3, x2]
    8954:	7100085f 	cmp	w2, #0x2
    8958:	540004e0 	b.eq	89f4 <f12+0xfa4>  // b.none
    895c:	7100045f 	cmp	w2, #0x1
    8960:	54000181 	b.ne	8990 <f12+0xf40>  // b.any
    8964:	29430002 	ldp	w2, w0, [x0, #24]
    8968:	92403c21 	and	x1, x1, #0xffff
    896c:	9b027c21 	mul	x1, x1, x2
    8970:	d360fc21 	lsr	x1, x1, #32
    8974:	eb00003f 	cmp	x1, x0
    8978:	540000c2 	b.cs	8990 <f12+0xf40>  // b.hs, b.nlast
    897c:	8b01037b 	add	x27, x27, x1
    8980:	39400360 	ldrb	w0, [x27]
    8984:	7103fc1f 	cmp	w0, #0xff
    8988:	540003c0 	b.eq	8a00 <f12+0xfb0>  // b.none
    898c:	39000378 	strb	w24, [x27]
    8990:	d1000694 	sub	x20, x20, #0x1
    8994:	b100069f 	cmn	x20, #0x1
    8998:	54fffb81 	b.ne	8908 <f12+0xeb8>  // b.any
    899c:	aa1903e0 	mov	x0, x25
    89a0:	97ffee98 	bl	4400 <fwp_mem_free>
    89a4:	aa1603e0 	mov	x0, x22
    89a8:	97fff8c2 	bl	6cb0 <fwp_drop4>
    89ac:	aa1303e0 	mov	x0, x19
    89b0:	97fff5b8 	bl	6090 <fwp_drop0>
    89b4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    89b8:	f947f400 	ldr	x0, [x0, #4072]
    89bc:	f9405fe2 	ldr	x2, [sp, #184]
    89c0:	f9400001 	ldr	x1, [x0]
    89c4:	eb010042 	subs	x2, x2, x1
    89c8:	d2800001 	mov	x1, #0x0                   	// #0
    89cc:	54000201 	b.ne	8a0c <f12+0xfbc>  // b.any
    89d0:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    89d4:	aa1a03e0 	mov	x0, x26
    89d8:	a94d53f3 	ldp	x19, x20, [sp, #208]
    89dc:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    89e0:	a94f63f7 	ldp	x23, x24, [sp, #240]
    89e4:	a9506bf9 	ldp	x25, x26, [sp, #256]
    89e8:	a95173fb 	ldp	x27, x28, [sp, #272]
    89ec:	910483ff 	add	sp, sp, #0x120
    89f0:	d65f03c0 	ret
    89f4:	72003c3f 	tst	w1, #0xffff
    89f8:	54fffcc1 	b.ne	8990 <f12+0xf40>  // b.any
    89fc:	17ffffe1 	b	8980 <f12+0xf30>
    8a00:	aa1b03e0 	mov	x0, x27
    8a04:	97ffede3 	bl	4190 <fwp_rc_forget_slot.part.0>
    8a08:	17ffffe1 	b	898c <f12+0xf3c>
    8a0c:	97ffe79d 	bl	2880 <__stack_chk_fail@plt>
    8a10:	aa1303e0 	mov	x0, x19
    8a14:	d2800001 	mov	x1, #0x0                   	// #0
    8a18:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    8a1c:	91000421 	add	x1, x1, #0x1
    8a20:	f9000402 	str	x2, [x0, #8]
    8a24:	aa0003e2 	mov	x2, x0
    8a28:	f9400800 	ldr	x0, [x0, #16]
    8a2c:	eb01037f 	cmp	x27, x1
    8a30:	54ffff48 	b.hi	8a18 <f12+0xfc8>  // b.pmore
    8a34:	f900085a 	str	x26, [x2, #16]
    8a38:	aa1303fa 	mov	x26, x19
    8a3c:	aa0003f3 	mov	x19, x0
    8a40:	17ffff9f 	b	88bc <f12+0xe6c>
    8a44:	d280001b 	mov	x27, #0x0                   	// #0
    8a48:	17ffff45 	b	875c <f12+0xd0c>
    8a4c:	97ffe80d 	bl	2a80 <fwp_trap_overflow.constprop.0>
    8a50:	97ffe7a0 	bl	28d0 <abort@plt>

0000000000008a54 <fwp_owned_entry12>:
    8a54:	f9400000 	ldr	x0, [x0]
    8a58:	17fffbfe 	b	7a50 <f12>
    8a5c:	d503201f 	nop

0000000000008a60 <e12>:
    8a60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8a64:	910003fd 	mov	x29, sp
    8a68:	f9000bf3 	str	x19, [sp, #16]
    8a6c:	f9400013 	ldr	x19, [x0]
    8a70:	aa1303e0 	mov	x0, x19
    8a74:	97fff45c 	bl	5be4 <fwp_rc_share>
    8a78:	aa1303e0 	mov	x0, x19
    8a7c:	97fffbf5 	bl	7a50 <f12>
    8a80:	aa0003f3 	mov	x19, x0
    8a84:	97fff458 	bl	5be4 <fwp_rc_share>
    8a88:	aa1303e0 	mov	x0, x19
    8a8c:	f9400bf3 	ldr	x19, [sp, #16]
    8a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8a94:	d65f03c0 	ret
    8a98:	d503201f 	nop
    8a9c:	d503201f 	nop

0000000000008aa0 <fwp_write>:
    8aa0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8aa4:	910003fd 	mov	x29, sp
    8aa8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    8aac:	f947f484 	ldr	x4, [x4, #4072]
    8ab0:	a90153f3 	stp	x19, x20, [sp, #16]
    8ab4:	d10943ff 	sub	sp, sp, #0x250
    8ab8:	b9400045 	ldr	w5, [x2]
    8abc:	aa0003f4 	mov	x20, x0
    8ac0:	f9400080 	ldr	x0, [x4]
    8ac4:	f90127e0 	str	x0, [sp, #584]
    8ac8:	d2800000 	mov	x0, #0x0                   	// #0
    8acc:	710064bf 	cmp	w5, #0x19
    8ad0:	54000408 	b.hi	8b50 <fwp_write+0xb0>  // b.pmore
    8ad4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    8ad8:	aa0103f3 	mov	x19, x1
    8adc:	91224000 	add	x0, x0, #0x890
    8ae0:	f9013bf5 	str	x21, [sp, #624]
    8ae4:	f9013ff6 	str	x22, [sp, #632]
    8ae8:	f90153fb 	str	x27, [sp, #672]
    8aec:	f90157fc 	str	x28, [sp, #680]
    8af0:	aa0203fc 	mov	x28, x2
    8af4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8af8:	10000061 	adr	x1, 8b04 <fwp_write+0x64>
    8afc:	8b20a820 	add	x0, x1, w0, sxth #2
    8b00:	d61f0000 	br	x0
    8b04:	910123e0 	add	x0, sp, #0x48
    8b08:	aa1303e5 	mov	x5, x19
    8b0c:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x4c0>
    8b10:	aa0003f3 	mov	x19, x0
    8b14:	91038084 	add	x4, x4, #0xe0
    8b18:	d2804003 	mov	x3, #0x200                 	// #512
    8b1c:	aa0303e1 	mov	x1, x3
    8b20:	52800042 	mov	w2, #0x2                   	// #2
    8b24:	97ffe733 	bl	27f0 <__snprintf_chk@plt>
    8b28:	aa1303e0 	mov	x0, x19
    8b2c:	97ffe6f9 	bl	2710 <strlen@plt>
    8b30:	aa1303e1 	mov	x1, x19
    8b34:	aa0003e2 	mov	x2, x0
    8b38:	aa1403e0 	mov	x0, x20
    8b3c:	97ffea95 	bl	3590 <buf_put>
    8b40:	f9413bf5 	ldr	x21, [sp, #624]
    8b44:	f9413ff6 	ldr	x22, [sp, #632]
    8b48:	f94153fb 	ldr	x27, [sp, #672]
    8b4c:	f94157fc 	ldr	x28, [sp, #680]
    8b50:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b54:	f947f400 	ldr	x0, [x0, #4072]
    8b58:	f94127e2 	ldr	x2, [sp, #584]
    8b5c:	f9400001 	ldr	x1, [x0]
    8b60:	eb010042 	subs	x2, x2, x1
    8b64:	d2800001 	mov	x1, #0x0                   	// #0
    8b68:	540077c1 	b.ne	9a60 <fwp_write+0xfc0>  // b.any
    8b6c:	910943ff 	add	sp, sp, #0x250
    8b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b74:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b78:	d65f03c0 	ret
    8b7c:	910123e0 	add	x0, sp, #0x48
    8b80:	aa1303e5 	mov	x5, x19
    8b84:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x4c0>
    8b88:	aa0003f3 	mov	x19, x0
    8b8c:	91036084 	add	x4, x4, #0xd8
    8b90:	d2804003 	mov	x3, #0x200                 	// #512
    8b94:	17ffffe2 	b	8b1c <fwp_write+0x7c>
    8b98:	71004cbf 	cmp	w5, #0x13
    8b9c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    8ba0:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8ba4:	91032000 	add	x0, x0, #0xc8
    8ba8:	91034021 	add	x1, x1, #0xd0
    8bac:	d2800082 	mov	x2, #0x4                   	// #4
    8bb0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8bb4:	aa1403e0 	mov	x0, x20
    8bb8:	f90143f7 	str	x23, [sp, #640]
    8bbc:	d2800016 	mov	x22, #0x0                   	// #0
    8bc0:	f90147f8 	str	x24, [sp, #648]
    8bc4:	97ffea73 	bl	3590 <buf_put>
    8bc8:	f9400260 	ldr	x0, [x19]
    8bcc:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x4c0>
    8bd0:	d2800015 	mov	x21, #0x0                   	// #0
    8bd4:	910542f7 	add	x23, x23, #0x150
    8bd8:	b40047a0 	cbz	x0, 94cc <fwp_write+0xa2c>
    8bdc:	b9400380 	ldr	w0, [x28]
    8be0:	52800003 	mov	w3, #0x0                   	// #0
    8be4:	f9401f82 	ldr	x2, [x28, #56]
    8be8:	71004c1f 	cmp	w0, #0x13
    8bec:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8bf0:	aa1403e0 	mov	x0, x20
    8bf4:	8b010e61 	add	x1, x19, x1, lsl #3
    8bf8:	f9400421 	ldr	x1, [x1, #8]
    8bfc:	97ffffa9 	bl	8aa0 <fwp_write>
    8c00:	b9400380 	ldr	w0, [x28]
    8c04:	7100481f 	cmp	w0, #0x12
    8c08:	54004b40 	b.eq	9570 <fwp_write+0xad0>  // b.none
    8c0c:	f9400260 	ldr	x0, [x19]
    8c10:	910006b5 	add	x21, x21, #0x1
    8c14:	91000ad6 	add	x22, x22, #0x2
    8c18:	eb15001f 	cmp	x0, x21
    8c1c:	54004589 	b.ls	94cc <fwp_write+0xa2c>  // b.plast
    8c20:	aa1703e1 	mov	x1, x23
    8c24:	aa1403e0 	mov	x0, x20
    8c28:	d2800042 	mov	x2, #0x2                   	// #2
    8c2c:	97ffea59 	bl	3590 <buf_put>
    8c30:	17ffffeb 	b	8bdc <fwp_write+0x13c>
    8c34:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8c38:	91042021 	add	x1, x1, #0x108
    8c3c:	d28000c2 	mov	x2, #0x6                   	// #6
    8c40:	aa1403e0 	mov	x0, x20
    8c44:	91004273 	add	x19, x19, #0x10
    8c48:	97ffea52 	bl	3590 <buf_put>
    8c4c:	aa1303e0 	mov	x0, x19
    8c50:	97ffe6b0 	bl	2710 <strlen@plt>
    8c54:	aa1303e1 	mov	x1, x19
    8c58:	aa0003e2 	mov	x2, x0
    8c5c:	aa1403e0 	mov	x0, x20
    8c60:	97ffea4c 	bl	3590 <buf_put>
    8c64:	528007c3 	mov	w3, #0x3e                  	// #62
    8c68:	aa1403e0 	mov	x0, x20
    8c6c:	91001fe1 	add	x1, sp, #0x7
    8c70:	d2800022 	mov	x2, #0x1                   	// #1
    8c74:	39001fe3 	strb	w3, [sp, #7]
    8c78:	17ffffb1 	b	8b3c <fwp_write+0x9c>
    8c7c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8c80:	f947f400 	ldr	x0, [x0, #4072]
    8c84:	f94127e2 	ldr	x2, [sp, #584]
    8c88:	f9400001 	ldr	x1, [x0]
    8c8c:	eb010042 	subs	x2, x2, x1
    8c90:	d2800001 	mov	x1, #0x0                   	// #0
    8c94:	540034e1 	b.ne	9330 <fwp_write+0x890>  // b.any
    8c98:	f9413bf5 	ldr	x21, [sp, #624]
    8c9c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8ca0:	f9413ff6 	ldr	x22, [sp, #632]
    8ca4:	aa1403e0 	mov	x0, x20
    8ca8:	9103a021 	add	x1, x1, #0xe8
    8cac:	d2800142 	mov	x2, #0xa                   	// #10
    8cb0:	f94153fb 	ldr	x27, [sp, #672]
    8cb4:	f94157fc 	ldr	x28, [sp, #680]
    8cb8:	910943ff 	add	sp, sp, #0x250
    8cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8cc0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8cc4:	17ffea33 	b	3590 <buf_put>
    8cc8:	f9400456 	ldr	x22, [x2, #8]
    8ccc:	f90143f7 	str	x23, [sp, #640]
    8cd0:	f90147f8 	str	x24, [sp, #648]
    8cd4:	b4005b16 	cbz	x22, 9834 <fwp_write+0xd94>
    8cd8:	aa1603e0 	mov	x0, x22
    8cdc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8ce0:	9105a021 	add	x1, x1, #0x168
    8ce4:	97ffe707 	bl	2900 <strcmp@plt>
    8ce8:	2a0003f5 	mov	w21, w0
    8cec:	34005fe0 	cbz	w0, 98e8 <fwp_write+0xe48>
    8cf0:	aa1603e0 	mov	x0, x22
    8cf4:	97ffe687 	bl	2710 <strlen@plt>
    8cf8:	aa1603e1 	mov	x1, x22
    8cfc:	aa0003e2 	mov	x2, x0
    8d00:	aa1403e0 	mov	x0, x20
    8d04:	97ffea23 	bl	3590 <buf_put>
    8d08:	52800403 	mov	w3, #0x20                  	// #32
    8d0c:	91001ff5 	add	x21, sp, #0x7
    8d10:	aa1503e1 	mov	x1, x21
    8d14:	aa1403e0 	mov	x0, x20
    8d18:	d2800022 	mov	x2, #0x1                   	// #1
    8d1c:	39001fe3 	strb	w3, [sp, #7]
    8d20:	97ffea1c 	bl	3590 <buf_put>
    8d24:	52800f63 	mov	w3, #0x7b                  	// #123
    8d28:	aa1403e0 	mov	x0, x20
    8d2c:	aa1503e1 	mov	x1, x21
    8d30:	d2800022 	mov	x2, #0x1                   	// #1
    8d34:	39001fe3 	strb	w3, [sp, #7]
    8d38:	97ffea16 	bl	3590 <buf_put>
    8d3c:	b9401380 	ldr	w0, [x28, #16]
    8d40:	52800018 	mov	w24, #0x0                   	// #0
    8d44:	7100001f 	cmp	w0, #0x0
    8d48:	54003aad 	b.le	949c <fwp_write+0x9fc>
    8d4c:	f9014bf9 	str	x25, [sp, #656]
    8d50:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x4c0>
    8d54:	91064339 	add	x25, x25, #0x190
    8d58:	f9014ffa 	str	x26, [sp, #664]
    8d5c:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x4c0>
    8d60:	9105435a 	add	x26, x26, #0x150
    8d64:	91002276 	add	x22, x19, #0x8
    8d68:	d2800013 	mov	x19, #0x0                   	// #0
    8d6c:	b5003e93 	cbnz	x19, 953c <fwp_write+0xa9c>
    8d70:	d37df277 	lsl	x23, x19, #3
    8d74:	34003cb8 	cbz	w24, 9508 <fwp_write+0xa68>
    8d78:	f9401382 	ldr	x2, [x28, #32]
    8d7c:	aa1403e0 	mov	x0, x20
    8d80:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8d84:	52800003 	mov	w3, #0x0                   	// #0
    8d88:	f8776842 	ldr	x2, [x2, x23]
    8d8c:	91000673 	add	x19, x19, #0x1
    8d90:	97ffff44 	bl	8aa0 <fwp_write>
    8d94:	b9401380 	ldr	w0, [x28, #16]
    8d98:	6b13001f 	cmp	w0, w19
    8d9c:	54fffe8c 	b.gt	8d6c <fwp_write+0x2cc>
    8da0:	f9414bf9 	ldr	x25, [sp, #656]
    8da4:	f9414ffa 	ldr	x26, [sp, #664]
    8da8:	340037b8 	cbz	w24, 949c <fwp_write+0x9fc>
    8dac:	52800523 	mov	w3, #0x29                  	// #41
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa1403e0 	mov	x0, x20
    8db8:	d2800022 	mov	x2, #0x1                   	// #1
    8dbc:	39001fe3 	strb	w3, [sp, #7]
    8dc0:	97ffe9f4 	bl	3590 <buf_put>
    8dc4:	f9413bf5 	ldr	x21, [sp, #624]
    8dc8:	f9413ff6 	ldr	x22, [sp, #632]
    8dcc:	f94143f7 	ldr	x23, [sp, #640]
    8dd0:	f94147f8 	ldr	x24, [sp, #648]
    8dd4:	f94153fb 	ldr	x27, [sp, #672]
    8dd8:	f94157fc 	ldr	x28, [sp, #680]
    8ddc:	17ffff5d 	b	8b50 <fwp_write+0xb0>
    8de0:	b9404855 	ldr	w21, [x2, #72]
    8de4:	aa1403e0 	mov	x0, x20
    8de8:	93407eb6 	sxtw	x22, w21
    8dec:	91000ac1 	add	x1, x22, #0x2
    8df0:	97ffe9b5 	bl	34c4 <buf_grow>
    8df4:	a9400281 	ldp	x1, x0, [x20]
    8df8:	528e8603 	mov	w3, #0x7430                	// #29744
    8dfc:	78206823 	strh	w3, [x1, x0]
    8e00:	8b000022 	add	x2, x1, x0
    8e04:	710002bf 	cmp	w21, #0x0
    8e08:	540036cd 	b.le	94e0 <fwp_write+0xa40>
    8e0c:	110006a3 	add	w3, w21, #0x1
    8e10:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8e14:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8e18:	91000449 	add	x9, x2, #0x1
    8e1c:	8b23c043 	add	x3, x2, w3, sxtw
    8e20:	f28aaac6 	movk	x6, #0x5556
    8e24:	f2955568 	movk	x8, #0xaaab
    8e28:	1400000d 	b	8e5c <fwp_write+0x3bc>
    8e2c:	d2800021 	mov	x1, #0x1                   	// #1
    8e30:	528005a5 	mov	w5, #0x2d                  	// #45
    8e34:	f100001f 	cmp	x0, #0x0
    8e38:	9b467e60 	smulh	x0, x19, x6
    8e3c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8e40:	381ff465 	strb	w5, [x3], #-1
    8e44:	cb040000 	sub	x0, x0, x4
    8e48:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8e4c:	cb020000 	sub	x0, x0, x2
    8e50:	8b010013 	add	x19, x0, x1
    8e54:	eb03013f 	cmp	x9, x3
    8e58:	54003440 	b.eq	94e0 <fwp_write+0xa40>  // b.none
    8e5c:	9b467e60 	smulh	x0, x19, x6
    8e60:	937ffe64 	asr	x4, x19, #63
    8e64:	52800605 	mov	w5, #0x30                  	// #48
    8e68:	cb040000 	sub	x0, x0, x4
    8e6c:	8b000400 	add	x0, x0, x0, lsl #1
    8e70:	cb000260 	sub	x0, x19, x0
    8e74:	91000c01 	add	x1, x0, #0x3
    8e78:	9bc87c22 	umulh	x2, x1, x8
    8e7c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8e80:	8b4204e2 	add	x2, x7, x2, lsr #1
    8e84:	eb020021 	subs	x1, x1, x2
    8e88:	54fffd60 	b.eq	8e34 <fwp_write+0x394>  // b.none
    8e8c:	f100043f 	cmp	x1, #0x1
    8e90:	54fffce1 	b.ne	8e2c <fwp_write+0x38c>  // b.any
    8e94:	d2800001 	mov	x1, #0x0                   	// #0
    8e98:	52800565 	mov	w5, #0x2b                  	// #43
    8e9c:	17ffffe6 	b	8e34 <fwp_write+0x394>
    8ea0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ea4:	f947f400 	ldr	x0, [x0, #4072]
    8ea8:	f94127e2 	ldr	x2, [sp, #584]
    8eac:	f9400001 	ldr	x1, [x0]
    8eb0:	eb010042 	subs	x2, x2, x1
    8eb4:	d2800001 	mov	x1, #0x0                   	// #0
    8eb8:	540023c1 	b.ne	9330 <fwp_write+0x890>  // b.any
    8ebc:	f9413bf5 	ldr	x21, [sp, #624]
    8ec0:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8ec4:	f9413ff6 	ldr	x22, [sp, #632]
    8ec8:	aa1403e0 	mov	x0, x20
    8ecc:	9103e021 	add	x1, x1, #0xf8
    8ed0:	d2800102 	mov	x2, #0x8                   	// #8
    8ed4:	17ffff77 	b	8cb0 <fwp_write+0x210>
    8ed8:	aa1403e0 	mov	x0, x20
    8edc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    8ee0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ee4:	91056021 	add	x1, x1, #0x158
    8ee8:	97ffe9aa 	bl	3590 <buf_put>
    8eec:	d2800015 	mov	x21, #0x0                   	// #0
    8ef0:	f9400263 	ldr	x3, [x19]
    8ef4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8ef8:	54002c60 	b.eq	9484 <fwp_write+0x9e4>  // b.none
    8efc:	f9401f82 	ldr	x2, [x28, #56]
    8f00:	f90143f7 	str	x23, [sp, #640]
    8f04:	f90147f8 	str	x24, [sp, #648]
    8f08:	d2800857 	mov	x23, #0x42                  	// #66
    8f0c:	f9014bf9 	str	x25, [sp, #656]
    8f10:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x4c0>
    8f14:	f9014ffa 	str	x26, [sp, #664]
    8f18:	910542d6 	add	x22, x22, #0x150
    8f1c:	d2800038 	mov	x24, #0x1                   	// #1
    8f20:	f2a18017 	movk	x23, #0xc00, lsl #16
    8f24:	d2809099 	mov	x25, #0x484                 	// #1156
    8f28:	b40004a2 	cbz	x2, 8fbc <fwp_write+0x51c>
    8f2c:	b9400040 	ldr	w0, [x2]
    8f30:	7100701f 	cmp	w0, #0x1c
    8f34:	540042c0 	b.eq	978c <fwp_write+0xcec>  // b.none
    8f38:	71006c1f 	cmp	w0, #0x1b
    8f3c:	54000408 	b.hi	8fbc <fwp_write+0x51c>  // b.pmore
    8f40:	9ac02301 	lsl	x1, x24, x0
    8f44:	ea17003f 	tst	x1, x23
    8f48:	540036a1 	b.ne	961c <fwp_write+0xb7c>  // b.any
    8f4c:	ea19003f 	tst	x1, x25
    8f50:	54003521 	b.ne	95f4 <fwp_write+0xb54>  // b.any
    8f54:	d2800424 	mov	x4, #0x21                  	// #33
    8f58:	ea04003f 	tst	x1, x4
    8f5c:	54000300 	b.eq	8fbc <fwp_write+0x51c>  // b.none
    8f60:	b7f849c3 	tbnz	x3, #63, 9898 <fwp_write+0xdf8>
    8f64:	91002261 	add	x1, x19, #0x8
    8f68:	8b150021 	add	x1, x1, x21
    8f6c:	39400021 	ldrb	w1, [x1]
    8f70:	7100001f 	cmp	w0, #0x0
    8f74:	93401c23 	sxtb	x3, w1
    8f78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8f7c:	d503201f 	nop
    8f80:	aa1403e0 	mov	x0, x20
    8f84:	52800003 	mov	w3, #0x0                   	// #0
    8f88:	97fffec6 	bl	8aa0 <fwp_write>
    8f8c:	910006b5 	add	x21, x21, #0x1
    8f90:	f9400260 	ldr	x0, [x19]
    8f94:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8f98:	eb0002bf 	cmp	x21, x0
    8f9c:	540026c2 	b.cs	9474 <fwp_write+0x9d4>  // b.hs, b.nlast
    8fa0:	d2800042 	mov	x2, #0x2                   	// #2
    8fa4:	aa1603e1 	mov	x1, x22
    8fa8:	aa1403e0 	mov	x0, x20
    8fac:	97ffe979 	bl	3590 <buf_put>
    8fb0:	f9401f82 	ldr	x2, [x28, #56]
    8fb4:	f9400263 	ldr	x3, [x19]
    8fb8:	b5fffba2 	cbnz	x2, 8f2c <fwp_write+0x48c>
    8fbc:	d37df2a0 	lsl	x0, x21, #3
    8fc0:	b7f83f03 	tbnz	x3, #63, 97a0 <fwp_write+0xd00>
    8fc4:	91002261 	add	x1, x19, #0x8
    8fc8:	8b000020 	add	x0, x1, x0
    8fcc:	f9400001 	ldr	x1, [x0]
    8fd0:	17ffffec 	b	8f80 <fwp_write+0x4e0>
    8fd4:	a9400e62 	ldp	x2, x3, [x19]
    8fd8:	b7f83ca3 	tbnz	x3, #63, 976c <fwp_write+0xccc>
    8fdc:	910123f5 	add	x21, sp, #0x48
    8fe0:	aa1503e0 	mov	x0, x21
    8fe4:	97ffe78f 	bl	2e20 <fwp_fmt_u128>
    8fe8:	aa1503e0 	mov	x0, x21
    8fec:	97ffe5c9 	bl	2710 <strlen@plt>
    8ff0:	aa1503e1 	mov	x1, x21
    8ff4:	aa0003e2 	mov	x2, x0
    8ff8:	17fffed0 	b	8b38 <fwp_write+0x98>
    8ffc:	fd015be8 	str	d8, [sp, #688]
    9000:	1e270268 	fmov	s8, w19
    9004:	fd015fe9 	str	d9, [sp, #696]
    9008:	1e282100 	fcmp	s8, s8
    900c:	54004d26 	b.vs	99b0 <fwp_write+0xf10>
    9010:	1e20c101 	fabs	s1, s8
    9014:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    9018:	1e270000 	fmov	s0, w0
    901c:	1e202020 	fcmp	s1, s0
    9020:	54002c0d 	b.le	95a0 <fwp_write+0xb00>
    9024:	1e202118 	fcmpe	s8, #0.0
    9028:	90000022 	adrp	x2, d000 <fwp_main_thread+0x120>
    902c:	91306042 	add	x2, x2, #0xc18
    9030:	910123f5 	add	x21, sp, #0x48
    9034:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    9038:	9102a021 	add	x1, x1, #0xa8
    903c:	aa1503e0 	mov	x0, x21
    9040:	9a81c041 	csel	x1, x2, x1, gt
    9044:	97ffe65f 	bl	29c0 <strcpy@plt>
    9048:	aa1503e0 	mov	x0, x21
    904c:	97ffe5b1 	bl	2710 <strlen@plt>
    9050:	aa1503e1 	mov	x1, x21
    9054:	aa0003e2 	mov	x2, x0
    9058:	aa1403e0 	mov	x0, x20
    905c:	97ffe94d 	bl	3590 <buf_put>
    9060:	f9413bf5 	ldr	x21, [sp, #624]
    9064:	f9413ff6 	ldr	x22, [sp, #632]
    9068:	f94153fb 	ldr	x27, [sp, #672]
    906c:	f94157fc 	ldr	x28, [sp, #680]
    9070:	fd415be8 	ldr	d8, [sp, #688]
    9074:	fd415fe9 	ldr	d9, [sp, #696]
    9078:	17fffeb6 	b	8b50 <fwp_write+0xb0>
    907c:	f9400276 	ldr	x22, [x19]
    9080:	34002e03 	cbz	w3, 9640 <fwp_write+0xba0>
    9084:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9088:	f947f400 	ldr	x0, [x0, #4072]
    908c:	f94127e2 	ldr	x2, [sp, #584]
    9090:	f9400001 	ldr	x1, [x0]
    9094:	eb010042 	subs	x2, x2, x1
    9098:	d2800001 	mov	x1, #0x0                   	// #0
    909c:	540014a1 	b.ne	9330 <fwp_write+0x890>  // b.any
    90a0:	aa1603e2 	mov	x2, x22
    90a4:	91002261 	add	x1, x19, #0x8
    90a8:	f9413bf5 	ldr	x21, [sp, #624]
    90ac:	aa1403e0 	mov	x0, x20
    90b0:	f9413ff6 	ldr	x22, [sp, #632]
    90b4:	17fffeff 	b	8cb0 <fwp_write+0x210>
    90b8:	fd015be8 	str	d8, [sp, #688]
    90bc:	9e670268 	fmov	d8, x19
    90c0:	fd015fe9 	str	d9, [sp, #696]
    90c4:	1e682100 	fcmp	d8, d8
    90c8:	54004746 	b.vs	99b0 <fwp_write+0xf10>
    90cc:	1e60c101 	fabs	d1, d8
    90d0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    90d4:	9e670000 	fmov	d0, x0
    90d8:	910123f5 	add	x21, sp, #0x48
    90dc:	52800033 	mov	w19, #0x1                   	// #1
    90e0:	1e602020 	fcmp	d1, d0
    90e4:	540001ad 	b.le	9118 <fwp_write+0x678>
    90e8:	1e602118 	fcmpe	d8, #0.0
    90ec:	90000022 	adrp	x2, d000 <fwp_main_thread+0x120>
    90f0:	91306042 	add	x2, x2, #0xc18
    90f4:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    90f8:	9102a021 	add	x1, x1, #0xa8
    90fc:	aa1503e0 	mov	x0, x21
    9100:	9a81c041 	csel	x1, x2, x1, gt
    9104:	97ffe62f 	bl	29c0 <strcpy@plt>
    9108:	17ffffd0 	b	9048 <fwp_write+0x5a8>
    910c:	11000673 	add	w19, w19, #0x1
    9110:	71004a7f 	cmp	w19, #0x12
    9114:	54003860 	b.eq	9820 <fwp_write+0xd80>  // b.none
    9118:	1e604100 	fmov	d0, d8
    911c:	2a1303e1 	mov	w1, w19
    9120:	aa1503e0 	mov	x0, x21
    9124:	97ffe9b7 	bl	3800 <fwp_format_g.constprop.0>
    9128:	aa1503e0 	mov	x0, x21
    912c:	d2800001 	mov	x1, #0x0                   	// #0
    9130:	97ffe58c 	bl	2760 <strtod@plt>
    9134:	1e602100 	fcmp	d8, d0
    9138:	54fffea1 	b.ne	910c <fwp_write+0x66c>  // b.any
    913c:	aa1503e0 	mov	x0, x21
    9140:	97ffe98d 	bl	3774 <fwp_finish_float>
    9144:	17ffffc1 	b	9048 <fwp_write+0x5a8>
    9148:	a9400e62 	ldp	x2, x3, [x19]
    914c:	910123f3 	add	x19, sp, #0x48
    9150:	aa1303e0 	mov	x0, x19
    9154:	97ffe733 	bl	2e20 <fwp_fmt_u128>
    9158:	17fffe74 	b	8b28 <fwp_write+0x88>
    915c:	f90143f7 	str	x23, [sp, #640]
    9160:	f90147f8 	str	x24, [sp, #648]
    9164:	2a1303f8 	mov	w24, w19
    9168:	f9014bf9 	str	x25, [sp, #656]
    916c:	f9014ffa 	str	x26, [sp, #664]
    9170:	f13ffe7f 	cmp	x19, #0xfff
    9174:	54000049 	b.ls	917c <fwp_write+0x6dc>  // b.plast
    9178:	b9400278 	ldr	w24, [x19]
    917c:	f9400f80 	ldr	x0, [x28, #24]
    9180:	2a1803f5 	mov	w21, w24
    9184:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9188:	d37ef6b9 	lsl	x25, x21, #2
    918c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9190:	aa1603e0 	mov	x0, x22
    9194:	97ffe55f 	bl	2710 <strlen@plt>
    9198:	aa1603e1 	mov	x1, x22
    919c:	aa0003e2 	mov	x2, x0
    91a0:	aa1403e0 	mov	x0, x20
    91a4:	97ffe8fb 	bl	3590 <buf_put>
    91a8:	f9401780 	ldr	x0, [x28, #40]
    91ac:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    91b0:	7100001f 	cmp	w0, #0x0
    91b4:	5400068d 	b.le	9284 <fwp_write+0x7e4>
    91b8:	91002276 	add	x22, x19, #0x8
    91bc:	91001ff5 	add	x21, sp, #0x7
    91c0:	d280001b 	mov	x27, #0x0                   	// #0
    91c4:	5280041a 	mov	w26, #0x20                  	// #32
    91c8:	f9401b80 	ldr	x0, [x28, #48]
    91cc:	aa1503e1 	mov	x1, x21
    91d0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    91d4:	d2800022 	mov	x2, #0x1                   	// #1
    91d8:	f8786803 	ldr	x3, [x0, x24]
    91dc:	aa1403e0 	mov	x0, x20
    91e0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    91e4:	39001ffa 	strb	w26, [sp, #7]
    91e8:	97ffe8ea 	bl	3590 <buf_put>
    91ec:	f13ffeff 	cmp	x23, #0xfff
    91f0:	b9400261 	ldr	w1, [x19]
    91f4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    91f8:	7100383f 	cmp	w1, #0xe
    91fc:	54000160 	b.eq	9228 <fwp_write+0x788>  // b.none
    9200:	7100403f 	cmp	w1, #0x10
    9204:	54001a60 	b.eq	9550 <fwp_write+0xab0>  // b.none
    9208:	7100283f 	cmp	w1, #0xa
    920c:	54002aa0 	b.eq	9760 <fwp_write+0xcc0>  // b.none
    9210:	540014ac 	b.gt	94a4 <fwp_write+0xa04>
    9214:	71000c3f 	cmp	w1, #0x3
    9218:	540029ac 	b.gt	974c <fwp_write+0xcac>
    921c:	d37ffee0 	lsr	x0, x23, #63
    9220:	37f814a1 	tbnz	w1, #31, 94b4 <fwp_write+0xa14>
    9224:	d503201f 	nop
    9228:	34001460 	cbz	w0, 94b4 <fwp_write+0xa14>
    922c:	52800503 	mov	w3, #0x28                  	// #40
    9230:	aa1503e1 	mov	x1, x21
    9234:	aa1403e0 	mov	x0, x20
    9238:	d2800022 	mov	x2, #0x1                   	// #1
    923c:	39001fe3 	strb	w3, [sp, #7]
    9240:	97ffe8d4 	bl	3590 <buf_put>
    9244:	aa1303e2 	mov	x2, x19
    9248:	aa1703e1 	mov	x1, x23
    924c:	aa1403e0 	mov	x0, x20
    9250:	52800003 	mov	w3, #0x0                   	// #0
    9254:	97fffe13 	bl	8aa0 <fwp_write>
    9258:	52800523 	mov	w3, #0x29                  	// #41
    925c:	aa1503e1 	mov	x1, x21
    9260:	aa1403e0 	mov	x0, x20
    9264:	d2800022 	mov	x2, #0x1                   	// #1
    9268:	39001fe3 	strb	w3, [sp, #7]
    926c:	97ffe8c9 	bl	3590 <buf_put>
    9270:	f9401780 	ldr	x0, [x28, #40]
    9274:	9100077b 	add	x27, x27, #0x1
    9278:	b8796800 	ldr	w0, [x0, x25]
    927c:	6b1b001f 	cmp	w0, w27
    9280:	54fffa4c 	b.gt	91c8 <fwp_write+0x728>
    9284:	f9413bf5 	ldr	x21, [sp, #624]
    9288:	f9413ff6 	ldr	x22, [sp, #632]
    928c:	f94143f7 	ldr	x23, [sp, #640]
    9290:	f94147f8 	ldr	x24, [sp, #648]
    9294:	f9414bf9 	ldr	x25, [sp, #656]
    9298:	f9414ffa 	ldr	x26, [sp, #664]
    929c:	f94153fb 	ldr	x27, [sp, #672]
    92a0:	f94157fc 	ldr	x28, [sp, #680]
    92a4:	17fffe2b 	b	8b50 <fwp_write+0xb0>
    92a8:	52800783 	mov	w3, #0x3c                  	// #60
    92ac:	91001ff3 	add	x19, sp, #0x7
    92b0:	aa1303e1 	mov	x1, x19
    92b4:	d2800022 	mov	x2, #0x1                   	// #1
    92b8:	aa1403e0 	mov	x0, x20
    92bc:	39001fe3 	strb	w3, [sp, #7]
    92c0:	97ffe8b4 	bl	3590 <buf_put>
    92c4:	f9400795 	ldr	x21, [x28, #8]
    92c8:	aa1503e0 	mov	x0, x21
    92cc:	97ffe511 	bl	2710 <strlen@plt>
    92d0:	aa1503e1 	mov	x1, x21
    92d4:	aa0003e2 	mov	x2, x0
    92d8:	aa1403e0 	mov	x0, x20
    92dc:	97ffe8ad 	bl	3590 <buf_put>
    92e0:	528007c3 	mov	w3, #0x3e                  	// #62
    92e4:	aa1303e1 	mov	x1, x19
    92e8:	aa1403e0 	mov	x0, x20
    92ec:	d2800022 	mov	x2, #0x1                   	// #1
    92f0:	39001fe3 	strb	w3, [sp, #7]
    92f4:	17fffe12 	b	8b3c <fwp_write+0x9c>
    92f8:	f100067f 	cmp	x19, #0x1
    92fc:	540025a0 	b.eq	97b0 <fwp_write+0xd10>  // b.none
    9300:	b100067f 	cmn	x19, #0x1
    9304:	54002bc0 	b.eq	987c <fwp_write+0xddc>  // b.none
    9308:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    930c:	9102c021 	add	x1, x1, #0xb0
    9310:	d2800022 	mov	x2, #0x1                   	// #1
    9314:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9318:	f947f400 	ldr	x0, [x0, #4072]
    931c:	f94127e4 	ldr	x4, [sp, #584]
    9320:	f9400003 	ldr	x3, [x0]
    9324:	eb030084 	subs	x4, x4, x3
    9328:	d2800003 	mov	x3, #0x0                   	// #0
    932c:	54ffebe0 	b.eq	90a8 <fwp_write+0x608>  // b.none
    9330:	f90143f7 	str	x23, [sp, #640]
    9334:	f90147f8 	str	x24, [sp, #648]
    9338:	f9014bf9 	str	x25, [sp, #656]
    933c:	f9014ffa 	str	x26, [sp, #664]
    9340:	fd015be8 	str	d8, [sp, #688]
    9344:	fd015fe9 	str	d9, [sp, #696]
    9348:	97ffe54e 	bl	2880 <__stack_chk_fail@plt>
    934c:	52800b63 	mov	w3, #0x5b                  	// #91
    9350:	91001ff5 	add	x21, sp, #0x7
    9354:	aa1503e1 	mov	x1, x21
    9358:	aa1403e0 	mov	x0, x20
    935c:	d2800022 	mov	x2, #0x1                   	// #1
    9360:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x4c0>
    9364:	910542d6 	add	x22, x22, #0x150
    9368:	39001fe3 	strb	w3, [sp, #7]
    936c:	97ffe889 	bl	3590 <buf_put>
    9370:	b4000273 	cbz	x19, 93bc <fwp_write+0x91c>
    9374:	f9400661 	ldr	x1, [x19, #8]
    9378:	aa1403e0 	mov	x0, x20
    937c:	f9401f82 	ldr	x2, [x28, #56]
    9380:	52800003 	mov	w3, #0x0                   	// #0
    9384:	97fffdc7 	bl	8aa0 <fwp_write>
    9388:	f9400a73 	ldr	x19, [x19, #16]
    938c:	b4000193 	cbz	x19, 93bc <fwp_write+0x91c>
    9390:	aa1603e1 	mov	x1, x22
    9394:	aa1403e0 	mov	x0, x20
    9398:	d2800042 	mov	x2, #0x2                   	// #2
    939c:	97ffe87d 	bl	3590 <buf_put>
    93a0:	f9400661 	ldr	x1, [x19, #8]
    93a4:	aa1403e0 	mov	x0, x20
    93a8:	f9401f82 	ldr	x2, [x28, #56]
    93ac:	52800003 	mov	w3, #0x0                   	// #0
    93b0:	97fffdbc 	bl	8aa0 <fwp_write>
    93b4:	f9400a73 	ldr	x19, [x19, #16]
    93b8:	b5fffed3 	cbnz	x19, 9390 <fwp_write+0x8f0>
    93bc:	52800ba3 	mov	w3, #0x5d                  	// #93
    93c0:	aa1503e1 	mov	x1, x21
    93c4:	aa1403e0 	mov	x0, x20
    93c8:	d2800022 	mov	x2, #0x1                   	// #1
    93cc:	39001fe3 	strb	w3, [sp, #7]
    93d0:	17fffddb 	b	8b3c <fwp_write+0x9c>
    93d4:	aa1403e0 	mov	x0, x20
    93d8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    93dc:	d28000c2 	mov	x2, #0x6                   	// #6
    93e0:	91050021 	add	x1, x1, #0x140
    93e4:	97ffe86b 	bl	3590 <buf_put>
    93e8:	f9400260 	ldr	x0, [x19]
    93ec:	b40004c0 	cbz	x0, 9484 <fwp_write+0x9e4>
    93f0:	910123f5 	add	x21, sp, #0x48
    93f4:	91002276 	add	x22, x19, #0x8
    93f8:	f90143f7 	str	x23, [sp, #640]
    93fc:	d2800017 	mov	x23, #0x0                   	// #0
    9400:	f90147f8 	str	x24, [sp, #648]
    9404:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x4c0>
    9408:	91052318 	add	x24, x24, #0x148
    940c:	f9014bf9 	str	x25, [sp, #656]
    9410:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x4c0>
    9414:	91054339 	add	x25, x25, #0x150
    9418:	f9014ffa 	str	x26, [sp, #664]
    941c:	14000005 	b	9430 <fwp_write+0x990>
    9420:	aa1903e1 	mov	x1, x25
    9424:	aa1403e0 	mov	x0, x20
    9428:	d2800042 	mov	x2, #0x2                   	// #2
    942c:	97ffe859 	bl	3590 <buf_put>
    9430:	38776ac5 	ldrb	w5, [x22, x23]
    9434:	d2804003 	mov	x3, #0x200                 	// #512
    9438:	aa1803e4 	mov	x4, x24
    943c:	aa0303e1 	mov	x1, x3
    9440:	52800042 	mov	w2, #0x2                   	// #2
    9444:	aa1503e0 	mov	x0, x21
    9448:	910006f7 	add	x23, x23, #0x1
    944c:	97ffe4e9 	bl	27f0 <__snprintf_chk@plt>
    9450:	aa1503e0 	mov	x0, x21
    9454:	97ffe4af 	bl	2710 <strlen@plt>
    9458:	aa1503e1 	mov	x1, x21
    945c:	aa0003e2 	mov	x2, x0
    9460:	aa1403e0 	mov	x0, x20
    9464:	97ffe84b 	bl	3590 <buf_put>
    9468:	f9400260 	ldr	x0, [x19]
    946c:	eb17001f 	cmp	x0, x23
    9470:	54fffd88 	b.hi	9420 <fwp_write+0x980>  // b.pmore
    9474:	f94143f7 	ldr	x23, [sp, #640]
    9478:	f94147f8 	ldr	x24, [sp, #648]
    947c:	f9414bf9 	ldr	x25, [sp, #656]
    9480:	f9414ffa 	ldr	x26, [sp, #664]
    9484:	52800ba3 	mov	w3, #0x5d                  	// #93
    9488:	aa1403e0 	mov	x0, x20
    948c:	91001fe1 	add	x1, sp, #0x7
    9490:	d2800022 	mov	x2, #0x1                   	// #1
    9494:	39001fe3 	strb	w3, [sp, #7]
    9498:	17fffda9 	b	8b3c <fwp_write+0x9c>
    949c:	52800fa3 	mov	w3, #0x7d                  	// #125
    94a0:	17fffe44 	b	8db0 <fwp_write+0x310>
    94a4:	f10002ff 	cmp	x23, #0x0
    94a8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    94ac:	71002c3f 	cmp	w1, #0xb
    94b0:	54ffebc0 	b.eq	9228 <fwp_write+0x788>  // b.none
    94b4:	aa1303e2 	mov	x2, x19
    94b8:	aa1703e1 	mov	x1, x23
    94bc:	aa1403e0 	mov	x0, x20
    94c0:	52800003 	mov	w3, #0x0                   	// #0
    94c4:	97fffd77 	bl	8aa0 <fwp_write>
    94c8:	17ffff6a 	b	9270 <fwp_write+0x7d0>
    94cc:	aa1403e0 	mov	x0, x20
    94d0:	91001fe1 	add	x1, sp, #0x7
    94d4:	52800fa3 	mov	w3, #0x7d                  	// #125
    94d8:	d2800022 	mov	x2, #0x1                   	// #1
    94dc:	17fffe38 	b	8dbc <fwp_write+0x31c>
    94e0:	a9400281 	ldp	x1, x0, [x20]
    94e4:	91000800 	add	x0, x0, #0x2
    94e8:	8b160000 	add	x0, x0, x22
    94ec:	f9000680 	str	x0, [x20, #8]
    94f0:	3820683f 	strb	wzr, [x1, x0]
    94f4:	f9413bf5 	ldr	x21, [sp, #624]
    94f8:	f9413ff6 	ldr	x22, [sp, #632]
    94fc:	f94153fb 	ldr	x27, [sp, #672]
    9500:	f94157fc 	ldr	x28, [sp, #680]
    9504:	17fffd93 	b	8b50 <fwp_write+0xb0>
    9508:	f9400f80 	ldr	x0, [x28, #24]
    950c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9510:	aa1b03e0 	mov	x0, x27
    9514:	97ffe47f 	bl	2710 <strlen@plt>
    9518:	aa1b03e1 	mov	x1, x27
    951c:	aa0003e2 	mov	x2, x0
    9520:	aa1403e0 	mov	x0, x20
    9524:	97ffe81b 	bl	3590 <buf_put>
    9528:	aa1903e1 	mov	x1, x25
    952c:	aa1403e0 	mov	x0, x20
    9530:	d2800062 	mov	x2, #0x3                   	// #3
    9534:	97ffe817 	bl	3590 <buf_put>
    9538:	17fffe10 	b	8d78 <fwp_write+0x2d8>
    953c:	aa1a03e1 	mov	x1, x26
    9540:	aa1403e0 	mov	x0, x20
    9544:	d2800042 	mov	x2, #0x2                   	// #2
    9548:	97ffe812 	bl	3590 <buf_put>
    954c:	17fffe09 	b	8d70 <fwp_write+0x2d0>
    9550:	f9400660 	ldr	x0, [x19, #8]
    9554:	b4fffb00 	cbz	x0, 94b4 <fwp_write+0xa14>
    9558:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    955c:	9105a021 	add	x1, x1, #0x168
    9560:	97ffe4e8 	bl	2900 <strcmp@plt>
    9564:	7100001f 	cmp	w0, #0x0
    9568:	1a9f07e0 	cset	w0, ne	// ne = any
    956c:	17ffff2f 	b	9228 <fwp_write+0x788>
    9570:	aa1403e0 	mov	x0, x20
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    957c:	91058021 	add	x1, x1, #0x160
    9580:	97ffe804 	bl	3590 <buf_put>
    9584:	91004261 	add	x1, x19, #0x10
    9588:	aa1403e0 	mov	x0, x20
    958c:	f9402382 	ldr	x2, [x28, #64]
    9590:	52800003 	mov	w3, #0x0                   	// #0
    9594:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9598:	97fffd42 	bl	8aa0 <fwp_write>
    959c:	17fffd9c 	b	8c0c <fwp_write+0x16c>
    95a0:	1e22c109 	fcvt	d9, s8
    95a4:	910123f5 	add	x21, sp, #0x48
    95a8:	52800033 	mov	w19, #0x1                   	// #1
    95ac:	d503201f 	nop
    95b0:	1e604120 	fmov	d0, d9
    95b4:	2a1303e1 	mov	w1, w19
    95b8:	aa1503e0 	mov	x0, x21
    95bc:	97ffe891 	bl	3800 <fwp_format_g.constprop.0>
    95c0:	aa1503e0 	mov	x0, x21
    95c4:	d2800001 	mov	x1, #0x0                   	// #0
    95c8:	97ffe4da 	bl	2930 <strtof@plt>
    95cc:	1e202100 	fcmp	s8, s0
    95d0:	54ffdb60 	b.eq	913c <fwp_write+0x69c>  // b.none
    95d4:	11000673 	add	w19, w19, #0x1
    95d8:	71002a7f 	cmp	w19, #0xa
    95dc:	54fffea1 	b.ne	95b0 <fwp_write+0xb10>  // b.any
    95e0:	1e604120 	fmov	d0, d9
    95e4:	aa1503e0 	mov	x0, x21
    95e8:	52800121 	mov	w1, #0x9                   	// #9
    95ec:	97ffe885 	bl	3800 <fwp_format_g.constprop.0>
    95f0:	17fffed3 	b	913c <fwp_write+0x69c>
    95f4:	d37ef6a1 	lsl	x1, x21, #2
    95f8:	b7f81563 	tbnz	x3, #63, 98a4 <fwp_write+0xe04>
    95fc:	91002263 	add	x3, x19, #0x8
    9600:	8b010061 	add	x1, x3, x1
    9604:	b9400023 	ldr	w3, [x1]
    9608:	7100081f 	cmp	w0, #0x2
    960c:	2a0303e1 	mov	w1, w3
    9610:	93407c63 	sxtw	x3, w3
    9614:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9618:	17fffe5a 	b	8f80 <fwp_write+0x4e0>
    961c:	d37ffaa1 	lsl	x1, x21, #1
    9620:	b7f81363 	tbnz	x3, #63, 988c <fwp_write+0xdec>
    9624:	91002263 	add	x3, x19, #0x8
    9628:	8b010061 	add	x1, x3, x1
    962c:	79400021 	ldrh	w1, [x1]
    9630:	7100041f 	cmp	w0, #0x1
    9634:	93403c23 	sxth	x3, w1
    9638:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    963c:	17fffe51 	b	8f80 <fwp_write+0x4e0>
    9640:	52800443 	mov	w3, #0x22                  	// #34
    9644:	91001ff5 	add	x21, sp, #0x7
    9648:	91002273 	add	x19, x19, #0x8
    964c:	aa1503e1 	mov	x1, x21
    9650:	aa1403e0 	mov	x0, x20
    9654:	d2800022 	mov	x2, #0x1                   	// #1
    9658:	39001fe3 	strb	w3, [sp, #7]
    965c:	f90143f7 	str	x23, [sp, #640]
    9660:	8b160277 	add	x23, x19, x22
    9664:	f90147f8 	str	x24, [sp, #648]
    9668:	97ffe7ca 	bl	3590 <buf_put>
    966c:	b4000696 	cbz	x22, 973c <fwp_write+0xc9c>
    9670:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x4c0>
    9674:	91044318 	add	x24, x24, #0x110
    9678:	f9014bf9 	str	x25, [sp, #656]
    967c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x4c0>
    9680:	9104c339 	add	x25, x25, #0x130
    9684:	f9014ffa 	str	x26, [sp, #664]
    9688:	1400000d 	b	96bc <fwp_write+0xc1c>
    968c:	710024bf 	cmp	w5, #0x9
    9690:	54000460 	b.eq	971c <fwp_write+0xc7c>  // b.none
    9694:	710028bf 	cmp	w5, #0xa
    9698:	54000a61 	b.ne	97e4 <fwp_write+0xd44>  // b.any
    969c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    96a0:	aa1403e0 	mov	x0, x20
    96a4:	91048021 	add	x1, x1, #0x120
    96a8:	d2800042 	mov	x2, #0x2                   	// #2
    96ac:	97ffe7b9 	bl	3590 <buf_put>
    96b0:	91000673 	add	x19, x19, #0x1
    96b4:	eb17027f 	cmp	x19, x23
    96b8:	540003e0 	b.eq	9734 <fwp_write+0xc94>  // b.none
    96bc:	39400265 	ldrb	w5, [x19]
    96c0:	710034bf 	cmp	w5, #0xd
    96c4:	54000180 	b.eq	96f4 <fwp_write+0xc54>  // b.none
    96c8:	54fffe29 	b.ls	968c <fwp_write+0xbec>  // b.plast
    96cc:	710088bf 	cmp	w5, #0x22
    96d0:	540001c0 	b.eq	9708 <fwp_write+0xc68>  // b.none
    96d4:	710170bf 	cmp	w5, #0x5c
    96d8:	54000741 	b.ne	97c0 <fwp_write+0xd20>  // b.any
    96dc:	aa1403e0 	mov	x0, x20
    96e0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    96e4:	d2800042 	mov	x2, #0x2                   	// #2
    96e8:	91046021 	add	x1, x1, #0x118
    96ec:	97ffe7a9 	bl	3590 <buf_put>
    96f0:	17fffff0 	b	96b0 <fwp_write+0xc10>
    96f4:	aa1903e1 	mov	x1, x25
    96f8:	aa1403e0 	mov	x0, x20
    96fc:	d2800042 	mov	x2, #0x2                   	// #2
    9700:	97ffe7a4 	bl	3590 <buf_put>
    9704:	17ffffeb 	b	96b0 <fwp_write+0xc10>
    9708:	aa1803e1 	mov	x1, x24
    970c:	aa1403e0 	mov	x0, x20
    9710:	d2800042 	mov	x2, #0x2                   	// #2
    9714:	97ffe79f 	bl	3590 <buf_put>
    9718:	17ffffe6 	b	96b0 <fwp_write+0xc10>
    971c:	aa1403e0 	mov	x0, x20
    9720:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    9724:	d2800042 	mov	x2, #0x2                   	// #2
    9728:	9104a021 	add	x1, x1, #0x128
    972c:	97ffe799 	bl	3590 <buf_put>
    9730:	17ffffe0 	b	96b0 <fwp_write+0xc10>
    9734:	f9414bf9 	ldr	x25, [sp, #656]
    9738:	f9414ffa 	ldr	x26, [sp, #664]
    973c:	aa1503e1 	mov	x1, x21
    9740:	aa1403e0 	mov	x0, x20
    9744:	52800443 	mov	w3, #0x22                  	// #34
    9748:	17fffd9c 	b	8db8 <fwp_write+0x318>
    974c:	7100103f 	cmp	w1, #0x4
    9750:	54ffeb21 	b.ne	94b4 <fwp_write+0xa14>  // b.any
    9754:	f94006e0 	ldr	x0, [x23, #8]
    9758:	d37ffc00 	lsr	x0, x0, #63
    975c:	17fffeb3 	b	9228 <fwp_write+0x788>
    9760:	710002ff 	cmp	w23, #0x0
    9764:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9768:	17fffeb0 	b	9228 <fwp_write+0x788>
    976c:	528005a1 	mov	w1, #0x2d                  	// #45
    9770:	eb0203e2 	negs	x2, x2
    9774:	da0303e3 	ngc	x3, x3
    9778:	910127e0 	add	x0, sp, #0x49
    977c:	910123f5 	add	x21, sp, #0x48
    9780:	390123e1 	strb	w1, [sp, #72]
    9784:	97ffe5a7 	bl	2e20 <fwp_fmt_u128>
    9788:	17fffe18 	b	8fe8 <fwp_write+0x548>
    978c:	d37ceea1 	lsl	x1, x21, #4
    9790:	b7f810a3 	tbnz	x3, #63, 99a4 <fwp_write+0xf04>
    9794:	91002260 	add	x0, x19, #0x8
    9798:	8b010001 	add	x1, x0, x1
    979c:	17fffdf9 	b	8f80 <fwp_write+0x4e0>
    97a0:	f9400a61 	ldr	x1, [x19, #16]
    97a4:	8b010000 	add	x0, x0, x1
    97a8:	f9400001 	ldr	x1, [x0]
    97ac:	17fffdf5 	b	8f80 <fwp_write+0x4e0>
    97b0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    97b4:	d2800042 	mov	x2, #0x2                   	// #2
    97b8:	9102e021 	add	x1, x1, #0xb8
    97bc:	17fffed6 	b	9314 <fwp_write+0x874>
    97c0:	7101fcbf 	cmp	w5, #0x7f
    97c4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    97c8:	540000e9 	b.ls	97e4 <fwp_write+0xd44>  // b.plast
    97cc:	aa1503e1 	mov	x1, x21
    97d0:	aa1403e0 	mov	x0, x20
    97d4:	d2800022 	mov	x2, #0x1                   	// #1
    97d8:	39001fe5 	strb	w5, [sp, #7]
    97dc:	97ffe76d 	bl	3590 <buf_put>
    97e0:	17ffffb4 	b	96b0 <fwp_write+0xc10>
    97e4:	d2800203 	mov	x3, #0x10                  	// #16
    97e8:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x4c0>
    97ec:	aa0303e1 	mov	x1, x3
    97f0:	9104e084 	add	x4, x4, #0x138
    97f4:	910123f6 	add	x22, sp, #0x48
    97f8:	52800042 	mov	w2, #0x2                   	// #2
    97fc:	aa1603e0 	mov	x0, x22
    9800:	97ffe3fc 	bl	27f0 <__snprintf_chk@plt>
    9804:	aa1603e0 	mov	x0, x22
    9808:	97ffe3c2 	bl	2710 <strlen@plt>
    980c:	aa1603e1 	mov	x1, x22
    9810:	aa0003e2 	mov	x2, x0
    9814:	aa1403e0 	mov	x0, x20
    9818:	97ffe75e 	bl	3590 <buf_put>
    981c:	17ffffa5 	b	96b0 <fwp_write+0xc10>
    9820:	1e604100 	fmov	d0, d8
    9824:	aa1503e0 	mov	x0, x21
    9828:	52800221 	mov	w1, #0x11                  	// #17
    982c:	97ffe7f5 	bl	3800 <fwp_format_g.constprop.0>
    9830:	17fffe43 	b	913c <fwp_write+0x69c>
    9834:	b9401040 	ldr	w0, [x2, #16]
    9838:	350003c0 	cbnz	w0, 98b0 <fwp_write+0xe10>
    983c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9840:	f947f400 	ldr	x0, [x0, #4072]
    9844:	f94127e2 	ldr	x2, [sp, #584]
    9848:	f9400001 	ldr	x1, [x0]
    984c:	eb010042 	subs	x2, x2, x1
    9850:	d2800001 	mov	x1, #0x0                   	// #0
    9854:	54ffd721 	b.ne	9338 <fwp_write+0x898>  // b.any
    9858:	f9413bf5 	ldr	x21, [sp, #624]
    985c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    9860:	f9413ff6 	ldr	x22, [sp, #632]
    9864:	aa1403e0 	mov	x0, x20
    9868:	f94143f7 	ldr	x23, [sp, #640]
    986c:	91062021 	add	x1, x1, #0x188
    9870:	f94147f8 	ldr	x24, [sp, #648]
    9874:	d2800042 	mov	x2, #0x2                   	// #2
    9878:	17fffd0e 	b	8cb0 <fwp_write+0x210>
    987c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x4c0>
    9880:	d2800042 	mov	x2, #0x2                   	// #2
    9884:	91030021 	add	x1, x1, #0xc0
    9888:	17fffea3 	b	9314 <fwp_write+0x874>
    988c:	f9400a63 	ldr	x3, [x19, #16]
    9890:	8b030021 	add	x1, x1, x3
    9894:	17ffff66 	b	962c <fwp_write+0xb8c>
    9898:	f9400a61 	ldr	x1, [x19, #16]
    989c:	8b0102a1 	add	x1, x21, x1
    98a0:	17fffdb3 	b	8f6c <fwp_write+0x4cc>
    98a4:	f9400a63 	ldr	x3, [x19, #16]
    98a8:	8b030021 	add	x1, x1, x3
    98ac:	17ffff56 	b	9604 <fwp_write+0xb64>
    98b0:	b9404840 	ldr	w0, [x2, #72]
    98b4:	91001ff5 	add	x21, sp, #0x7
    98b8:	34ffa360 	cbz	w0, 8d24 <fwp_write+0x284>
    98bc:	52800503 	mov	w3, #0x28                  	// #40
    98c0:	aa1403e0 	mov	x0, x20
    98c4:	aa1503e1 	mov	x1, x21
    98c8:	d2800022 	mov	x2, #0x1                   	// #1
    98cc:	39001fe3 	strb	w3, [sp, #7]
    98d0:	97ffe730 	bl	3590 <buf_put>
    98d4:	b9401380 	ldr	w0, [x28, #16]
    98d8:	52800038 	mov	w24, #0x1                   	// #1
    98dc:	7100001f 	cmp	w0, #0x0
    98e0:	54ffa36c 	b.gt	8d4c <fwp_write+0x2ac>
    98e4:	17fffd32 	b	8dac <fwp_write+0x30c>
    98e8:	f9014bf9 	str	x25, [sp, #656]
    98ec:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe1d8>
    98f0:	f9014ffa 	str	x26, [sp, #664]
    98f4:	f9400676 	ldr	x22, [x19, #8]
    98f8:	91102333 	add	x19, x25, #0x408
    98fc:	91002273 	add	x19, x19, #0x8
    9900:	937ffed8 	asr	x24, x22, #63
    9904:	aa1802c0 	orr	x0, x22, x24
    9908:	b5000320 	cbnz	x0, 996c <fwp_write+0xecc>
    990c:	110006b5 	add	w21, w21, #0x1
    9910:	710016bf 	cmp	w21, #0x5
    9914:	54ffffc1 	b.ne	990c <fwp_write+0xe6c>  // b.any
    9918:	b7f80578 	tbnz	x24, #63, 99c4 <fwp_write+0xf24>
    991c:	910023f3 	add	x19, sp, #0x8
    9920:	aa1603e2 	mov	x2, x22
    9924:	aa1303e0 	mov	x0, x19
    9928:	d2800003 	mov	x3, #0x0                   	// #0
    992c:	97ffe53d 	bl	2e20 <fwp_fmt_u128>
    9930:	910123f5 	add	x21, sp, #0x48
    9934:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x4c0>
    9938:	aa1303e4 	mov	x4, x19
    993c:	aa1503e0 	mov	x0, x21
    9940:	91060063 	add	x3, x3, #0x180
    9944:	d2804002 	mov	x2, #0x200                 	// #512
    9948:	52800041 	mov	w1, #0x2                   	// #2
    994c:	97ffe375 	bl	2720 <__sprintf_chk@plt>
    9950:	aa1503e0 	mov	x0, x21
    9954:	97ffe36f 	bl	2710 <strlen@plt>
    9958:	aa1503e1 	mov	x1, x21
    995c:	aa0003e2 	mov	x2, x0
    9960:	aa1403e0 	mov	x0, x20
    9964:	97ffe70b 	bl	3590 <buf_put>
    9968:	17fffe47 	b	9284 <fwp_write+0x7e4>
    996c:	f9400277 	ldr	x23, [x19]
    9970:	aa1603e0 	mov	x0, x22
    9974:	aa1803e1 	mov	x1, x24
    9978:	aa1703e2 	mov	x2, x23
    997c:	937ffefa 	asr	x26, x23, #63
    9980:	aa1a03e3 	mov	x3, x26
    9984:	94000f87 	bl	d7a0 <__modti3>
    9988:	aa010000 	orr	x0, x0, x1
    998c:	b40002c0 	cbz	x0, 99e4 <fwp_write+0xf44>
    9990:	110006b5 	add	w21, w21, #0x1
    9994:	91004273 	add	x19, x19, #0x10
    9998:	710016bf 	cmp	w21, #0x5
    999c:	54fffe81 	b.ne	996c <fwp_write+0xecc>  // b.any
    99a0:	17ffffde 	b	9918 <fwp_write+0xe78>
    99a4:	f9400a60 	ldr	x0, [x19, #16]
    99a8:	8b000021 	add	x1, x1, x0
    99ac:	17fffd75 	b	8f80 <fwp_write+0x4e0>
    99b0:	528c29c0 	mov	w0, #0x614e                	// #24910
    99b4:	910123f5 	add	x21, sp, #0x48
    99b8:	72a009c0 	movk	w0, #0x4e, lsl #16
    99bc:	b9004be0 	str	w0, [sp, #72]
    99c0:	17fffda2 	b	9048 <fwp_write+0x5a8>
    99c4:	528005a1 	mov	w1, #0x2d                  	// #45
    99c8:	eb1603e2 	negs	x2, x22
    99cc:	da1803e3 	ngc	x3, x24
    99d0:	910027e0 	add	x0, sp, #0x9
    99d4:	910023f3 	add	x19, sp, #0x8
    99d8:	390023e1 	strb	w1, [sp, #8]
    99dc:	97ffe511 	bl	2e20 <fwp_fmt_u128>
    99e0:	17ffffd4 	b	9930 <fwp_write+0xe90>
    99e4:	aa1703e2 	mov	x2, x23
    99e8:	aa1a03e3 	mov	x3, x26
    99ec:	aa1603e0 	mov	x0, x22
    99f0:	aa1803e1 	mov	x1, x24
    99f4:	94000e8b 	bl	d420 <__divti3>
    99f8:	aa0003e2 	mov	x2, x0
    99fc:	aa0103e3 	mov	x3, x1
    9a00:	b7f80201 	tbnz	x1, #63, 9a40 <fwp_write+0xfa0>
    9a04:	910023f3 	add	x19, sp, #0x8
    9a08:	aa1303e0 	mov	x0, x19
    9a0c:	97ffe505 	bl	2e20 <fwp_fmt_u128>
    9a10:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9a14:	91102339 	add	x25, x25, #0x408
    9a18:	910123f5 	add	x21, sp, #0x48
    9a1c:	aa1303e4 	mov	x4, x19
    9a20:	aa1503e0 	mov	x0, x21
    9a24:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x4c0>
    9a28:	f8616b25 	ldr	x5, [x25, x1]
    9a2c:	9105e063 	add	x3, x3, #0x178
    9a30:	d2804002 	mov	x2, #0x200                 	// #512
    9a34:	52800041 	mov	w1, #0x2                   	// #2
    9a38:	97ffe33a 	bl	2720 <__sprintf_chk@plt>
    9a3c:	17ffffc5 	b	9950 <fwp_write+0xeb0>
    9a40:	528005a4 	mov	w4, #0x2d                  	// #45
    9a44:	eb0003e2 	negs	x2, x0
    9a48:	da0103e3 	ngc	x3, x1
    9a4c:	910027e0 	add	x0, sp, #0x9
    9a50:	910023f3 	add	x19, sp, #0x8
    9a54:	390023e4 	strb	w4, [sp, #8]
    9a58:	97ffe4f2 	bl	2e20 <fwp_fmt_u128>
    9a5c:	17ffffed 	b	9a10 <fwp_write+0xf70>
    9a60:	f9013bf5 	str	x21, [sp, #624]
    9a64:	f9013ff6 	str	x22, [sp, #632]
    9a68:	f90143f7 	str	x23, [sp, #640]
    9a6c:	f90147f8 	str	x24, [sp, #648]
    9a70:	f9014bf9 	str	x25, [sp, #656]
    9a74:	f9014ffa 	str	x26, [sp, #664]
    9a78:	f90153fb 	str	x27, [sp, #672]
    9a7c:	f90157fc 	str	x28, [sp, #680]
    9a80:	fd015be8 	str	d8, [sp, #688]
    9a84:	fd015fe9 	str	d9, [sp, #696]
    9a88:	97ffe37e 	bl	2880 <__stack_chk_fail@plt>
    9a8c:	d503201f 	nop

0000000000009a90 <fwp_hof0.constprop.0>:
    9a90:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9a94:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9a98:	f947f442 	ldr	x2, [x2, #4072]
    9a9c:	910003fd 	mov	x29, sp
    9aa0:	a90153f3 	stp	x19, x20, [sp, #16]
    9aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    9aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    9aac:	aa0003f7 	mov	x23, x0
    9ab0:	a9046bf9 	stp	x25, x26, [sp, #64]
    9ab4:	a90573fb 	stp	x27, x28, [sp, #80]
    9ab8:	d10203ff 	sub	sp, sp, #0x80
    9abc:	f9400040 	ldr	x0, [x2]
    9ac0:	f81f83a0 	stur	x0, [x29, #-8]
    9ac4:	d2800000 	mov	x0, #0x0                   	// #0
    9ac8:	b40039a1 	cbz	x1, a1fc <fwp_hof0.constprop.0+0x76c>
    9acc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ad0:	9100401c 	add	x28, x0, #0x10
    9ad4:	aa1703fa 	mov	x26, x23
    9ad8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9adc:	9101039c 	add	x28, x28, #0x40
    9ae0:	d10083b4 	sub	x20, x29, #0x20
    9ae4:	9101c015 	add	x21, x0, #0x70
    9ae8:	aa0103f7 	mov	x23, x1
    9aec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9af0:	91174001 	add	x1, x0, #0x5d0
    9af4:	f949d822 	ldr	x2, [x1, #5040]
    9af8:	f949ec20 	ldr	x0, [x1, #5080]
    9afc:	cb020342 	sub	x2, x26, x2
    9b00:	eb00405f 	cmp	x2, x0, lsl #16
    9b04:	54000342 	b.cs	9b6c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9b08:	d350fc40 	lsr	x0, x2, #16
    9b0c:	f949fc24 	ldr	x4, [x1, #5112]
    9b10:	8b000800 	add	x0, x0, x0, lsl #2
    9b14:	d37df001 	lsl	x1, x0, #3
    9b18:	8b010083 	add	x3, x4, x1
    9b1c:	f9401060 	ldr	x0, [x3, #32]
    9b20:	b4000260 	cbz	x0, 9b6c <fwp_hof0.constprop.0+0xdc>
    9b24:	38616881 	ldrb	w1, [x4, x1]
    9b28:	7100083f 	cmp	w1, #0x2
    9b2c:	540055c0 	b.eq	a5e4 <fwp_hof0.constprop.0+0xb54>  // b.none
    9b30:	7100043f 	cmp	w1, #0x1
    9b34:	540001c1 	b.ne	9b6c <fwp_hof0.constprop.0+0xdc>  // b.any
    9b38:	92403c41 	and	x1, x2, #0xffff
    9b3c:	29430864 	ldp	w4, w2, [x3, #24]
    9b40:	9b047c21 	mul	x1, x1, x4
    9b44:	d360fc21 	lsr	x1, x1, #32
    9b48:	eb02003f 	cmp	x1, x2
    9b4c:	54000102 	b.cs	9b6c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9b50:	8b010000 	add	x0, x0, x1
    9b54:	39400001 	ldrb	w1, [x0]
    9b58:	340000a1 	cbz	w1, 9b6c <fwp_hof0.constprop.0+0xdc>
    9b5c:	7103f43f 	cmp	w1, #0xfd
    9b60:	540056c8 	b.hi	a638 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9b64:	11000421 	add	w1, w1, #0x1
    9b68:	39000001 	strb	w1, [x0]
    9b6c:	aa1a03f8 	mov	x24, x26
    9b70:	aa1c03f9 	mov	x25, x28
    9b74:	d28018f3 	mov	x19, #0xc7                  	// #199
    9b78:	a9396bb7 	stp	x23, x26, [x29, #-112]
    9b7c:	f81a03b3 	stur	x19, [x29, #-96]
    9b80:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b84:	91004000 	add	x0, x0, #0x10
    9b88:	f94066a3 	ldr	x3, [x21, #200]
    9b8c:	91010006 	add	x6, x0, #0x40
    9b90:	b9404002 	ldr	w2, [x0, #64]
    9b94:	d37be842 	lsl	x2, x2, #5
    9b98:	8b020064 	add	x4, x3, x2
    9b9c:	f9400c81 	ldr	x1, [x4, #24]
    9ba0:	f81e03b8 	stur	x24, [x29, #-32]
    9ba4:	b40052e1 	cbz	x1, a600 <fwp_hof0.constprop.0+0xb70>
    9ba8:	f9400c20 	ldr	x0, [x1, #24]
    9bac:	b40046a0 	cbz	x0, a480 <fwp_hof0.constprop.0+0x9f0>
    9bb0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9bb4:	91174002 	add	x2, x0, #0x5d0
    9bb8:	f949d841 	ldr	x1, [x2, #5040]
    9bbc:	f949ec40 	ldr	x0, [x2, #5080]
    9bc0:	cb010321 	sub	x1, x25, x1
    9bc4:	eb00403f 	cmp	x1, x0, lsl #16
    9bc8:	54000342 	b.cs	9c30 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9bcc:	d350fc20 	lsr	x0, x1, #16
    9bd0:	f949fc45 	ldr	x5, [x2, #5112]
    9bd4:	8b000800 	add	x0, x0, x0, lsl #2
    9bd8:	d37df002 	lsl	x2, x0, #3
    9bdc:	8b0200a3 	add	x3, x5, x2
    9be0:	f9401060 	ldr	x0, [x3, #32]
    9be4:	b4000260 	cbz	x0, 9c30 <fwp_hof0.constprop.0+0x1a0>
    9be8:	386268a2 	ldrb	w2, [x5, x2]
    9bec:	7100085f 	cmp	w2, #0x2
    9bf0:	54004b40 	b.eq	a558 <fwp_hof0.constprop.0+0xac8>  // b.none
    9bf4:	7100045f 	cmp	w2, #0x1
    9bf8:	540001c1 	b.ne	9c30 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9bfc:	29430865 	ldp	w5, w2, [x3, #24]
    9c00:	92403c21 	and	x1, x1, #0xffff
    9c04:	9b057c21 	mul	x1, x1, x5
    9c08:	d360fc21 	lsr	x1, x1, #32
    9c0c:	eb02003f 	cmp	x1, x2
    9c10:	54000102 	b.cs	9c30 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9c14:	8b010000 	add	x0, x0, x1
    9c18:	39400001 	ldrb	w1, [x0]
    9c1c:	340000a1 	cbz	w1, 9c30 <fwp_hof0.constprop.0+0x1a0>
    9c20:	7103f43f 	cmp	w1, #0xfd
    9c24:	54004e68 	b.hi	a5f0 <fwp_hof0.constprop.0+0xb60>  // b.pmore
    9c28:	11000421 	add	w1, w1, #0x1
    9c2c:	39000001 	strb	w1, [x0]
    9c30:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9c34:	aa1903f8 	mov	x24, x25
    9c38:	aa1903e0 	mov	x0, x25
    9c3c:	91174036 	add	x22, x1, #0x5d0
    9c40:	52800037 	mov	w23, #0x1                   	// #1
    9c44:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    9c48:	b81cc3b7 	stur	w23, [x29, #-52]
    9c4c:	f81d03b4 	stur	x20, [x29, #-48]
    9c50:	b9400401 	ldr	w1, [x0, #4]
    9c54:	b9400099 	ldr	w25, [x4]
    9c58:	b85cc3a0 	ldur	w0, [x29, #-52]
    9c5c:	4b010339 	sub	w25, w25, w1
    9c60:	6b17033f 	cmp	w25, w23
    9c64:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    9c68:	6b0000df 	cmp	w6, w0
    9c6c:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    9c70:	b81c83a0 	stur	w0, [x29, #-56]
    9c74:	6b0000c2 	subs	w2, w6, w0
    9c78:	54000120 	b.eq	9c9c <fwp_hof0.constprop.0+0x20c>  // b.none
    9c7c:	f9400c83 	ldr	x3, [x4, #24]
    9c80:	0b000021 	add	w1, w1, w0
    9c84:	f85d03a4 	ldur	x4, [x29, #-48]
    9c88:	b81d83a6 	stur	w6, [x29, #-40]
    9c8c:	f9400863 	ldr	x3, [x3, #16]
    9c90:	8b204c80 	add	x0, x4, w0, uxtw #3
    9c94:	d63f0060 	blr	x3
    9c98:	b85d83a6 	ldur	w6, [x29, #-40]
    9c9c:	f94066a0 	ldr	x0, [x21, #200]
    9ca0:	aa1803e9 	mov	x9, x24
    9ca4:	b9400304 	ldr	w4, [x24]
    9ca8:	2a0603f4 	mov	w20, w6
    9cac:	f85d03bb 	ldur	x27, [x29, #-48]
    9cb0:	aa1803fa 	mov	x26, x24
    9cb4:	8b041404 	add	x4, x0, x4, lsl #5
    9cb8:	f9400c8a 	ldr	x10, [x4, #24]
    9cbc:	b400106a 	cbz	x10, 9ec8 <fwp_hof0.constprop.0+0x438>
    9cc0:	29371bb7 	stp	w23, w6, [x29, #-72]
    9cc4:	aa0403f7 	mov	x23, x4
    9cc8:	b81c03b9 	stur	w25, [x29, #-64]
    9ccc:	aa1b03f9 	mov	x25, x27
    9cd0:	14000012 	b	9d18 <fwp_hof0.constprop.0+0x288>
    9cd4:	f9400141 	ldr	x1, [x10]
    9cd8:	aa1903e0 	mov	x0, x25
    9cdc:	d63f0020 	blr	x1
    9ce0:	aa0003fb 	mov	x27, x0
    9ce4:	aa1803e0 	mov	x0, x24
    9ce8:	97fff1aa 	bl	6390 <fwp_closure_drop>
    9cec:	6b14027f 	cmp	w19, w20
    9cf0:	54000cc0 	b.eq	9e88 <fwp_hof0.constprop.0+0x3f8>  // b.none
    9cf4:	f94066a0 	ldr	x0, [x21, #200]
    9cf8:	8b334f39 	add	x25, x25, w19, uxtw #3
    9cfc:	b9400364 	ldr	w4, [x27]
    9d00:	4b1a0394 	sub	w20, w28, w26
    9d04:	aa1b03e9 	mov	x9, x27
    9d08:	8b041417 	add	x23, x0, x4, lsl #5
    9d0c:	f9400eea 	ldr	x10, [x23, #24]
    9d10:	b4000d4a 	cbz	x10, 9eb8 <fwp_hof0.constprop.0+0x428>
    9d14:	aa1b03f8 	mov	x24, x27
    9d18:	b9400521 	ldr	w1, [x9, #4]
    9d1c:	b94002fa 	ldr	w26, [x23]
    9d20:	0b14003c 	add	w28, w1, w20
    9d24:	6b1c035f 	cmp	w26, w28
    9d28:	540028a8 	b.hi	a23c <fwp_hof0.constprop.0+0x7ac>  // b.pmore
    9d2c:	7100003f 	cmp	w1, #0x0
    9d30:	4b010353 	sub	w19, w26, w1
    9d34:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9d38:	54fffce1 	b.ne	9cd4 <fwp_hof0.constprop.0+0x244>  // b.any
    9d3c:	910003e0 	mov	x0, sp
    9d40:	7100035f 	cmp	w26, #0x0
    9d44:	f81d83a0 	stur	x0, [x29, #-40]
    9d48:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    9d4c:	d37df000 	lsl	x0, x0, #3
    9d50:	91003c00 	add	x0, x0, #0xf
    9d54:	92704c05 	and	x5, x0, #0xfffff0000
    9d58:	927c7c00 	and	x0, x0, #0xffffffff0
    9d5c:	cb2563e5 	sub	x5, sp, x5
    9d60:	eb2563ff 	cmp	sp, x5
    9d64:	540000a0 	b.eq	9d78 <fwp_hof0.constprop.0+0x2e8>  // b.none
    9d68:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9d6c:	f90203ff 	str	xzr, [sp, #1024]
    9d70:	eb2563ff 	cmp	sp, x5
    9d74:	54ffffa1 	b.ne	9d68 <fwp_hof0.constprop.0+0x2d8>  // b.any
    9d78:	92403c00 	and	x0, x0, #0xffff
    9d7c:	cb2063ff 	sub	sp, sp, x0
    9d80:	f90003ff 	str	xzr, [sp]
    9d84:	f110001f 	cmp	x0, #0x400
    9d88:	54000043 	b.cc	9d90 <fwp_hof0.constprop.0+0x300>  // b.lo, b.ul, b.last
    9d8c:	f90203ff 	str	xzr, [sp, #1024]
    9d90:	910043fb 	add	x27, sp, #0x10
    9d94:	d37d7c28 	ubfiz	x8, x1, #3, #32
    9d98:	91002127 	add	x7, x9, #0x8
    9d9c:	d2800000 	mov	x0, #0x0                   	// #0
    9da0:	340000e1 	cbz	w1, 9dbc <fwp_hof0.constprop.0+0x32c>
    9da4:	d503201f 	nop
    9da8:	f86068e2 	ldr	x2, [x7, x0]
    9dac:	f8206b62 	str	x2, [x27, x0]
    9db0:	91002000 	add	x0, x0, #0x8
    9db4:	eb00011f 	cmp	x8, x0
    9db8:	54ffff81 	b.ne	9da8 <fwp_hof0.constprop.0+0x318>  // b.any
    9dbc:	2a1303e8 	mov	w8, w19
    9dc0:	d2800000 	mov	x0, #0x0                   	// #0
    9dc4:	340000f3 	cbz	w19, 9de0 <fwp_hof0.constprop.0+0x350>
    9dc8:	0b000022 	add	w2, w1, w0
    9dcc:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    9dd0:	91000400 	add	x0, x0, #0x1
    9dd4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9dd8:	eb00011f 	cmp	x8, x0
    9ddc:	54ffff61 	b.ne	9dc8 <fwp_hof0.constprop.0+0x338>  // b.any
    9de0:	f949dac0 	ldr	x0, [x22, #5040]
    9de4:	f949eec1 	ldr	x1, [x22, #5080]
    9de8:	cb000300 	sub	x0, x24, x0
    9dec:	eb01401f 	cmp	x0, x1, lsl #16
    9df0:	540002e2 	b.cs	9e4c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9df4:	d350fc01 	lsr	x1, x0, #16
    9df8:	f949fec8 	ldr	x8, [x22, #5112]
    9dfc:	8b010821 	add	x1, x1, x1, lsl #2
    9e00:	d37df021 	lsl	x1, x1, #3
    9e04:	8b010107 	add	x7, x8, x1
    9e08:	f94010e6 	ldr	x6, [x7, #32]
    9e0c:	b4000206 	cbz	x6, 9e4c <fwp_hof0.constprop.0+0x3bc>
    9e10:	38616901 	ldrb	w1, [x8, x1]
    9e14:	7100083f 	cmp	w1, #0x2
    9e18:	540004a0 	b.eq	9eac <fwp_hof0.constprop.0+0x41c>  // b.none
    9e1c:	7100043f 	cmp	w1, #0x1
    9e20:	54000161 	b.ne	9e4c <fwp_hof0.constprop.0+0x3bc>  // b.any
    9e24:	294304e8 	ldp	w8, w1, [x7, #24]
    9e28:	92403c00 	and	x0, x0, #0xffff
    9e2c:	9b087c00 	mul	x0, x0, x8
    9e30:	d360fc00 	lsr	x0, x0, #32
    9e34:	eb01001f 	cmp	x0, x1
    9e38:	540000a2 	b.cs	9e4c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9e3c:	8b0000c6 	add	x6, x6, x0
    9e40:	394000c0 	ldrb	w0, [x6]
    9e44:	7100041f 	cmp	w0, #0x1
    9e48:	540002e0 	b.eq	9ea4 <fwp_hof0.constprop.0+0x414>  // b.none
    9e4c:	f9400546 	ldr	x6, [x10, #8]
    9e50:	aa1803e0 	mov	x0, x24
    9e54:	52800021 	mov	w1, #0x1                   	// #1
    9e58:	d63f00c0 	blr	x6
    9e5c:	f9400ee1 	ldr	x1, [x23, #24]
    9e60:	aa1b03e0 	mov	x0, x27
    9e64:	f9400021 	ldr	x1, [x1]
    9e68:	d63f0020 	blr	x1
    9e6c:	aa0003fb 	mov	x27, x0
    9e70:	f85d83a0 	ldur	x0, [x29, #-40]
    9e74:	9100001f 	mov	sp, x0
    9e78:	aa1803e0 	mov	x0, x24
    9e7c:	97fff145 	bl	6390 <fwp_closure_drop>
    9e80:	6b14027f 	cmp	w19, w20
    9e84:	54fff381 	b.ne	9cf4 <fwp_hof0.constprop.0+0x264>  // b.any
    9e88:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9e8c:	aa1b03f8 	mov	x24, x27
    9e90:	b85c03b9 	ldur	w25, [x29, #-64]
    9e94:	6b17033f 	cmp	w25, w23
    9e98:	54000443 	b.cc	9f20 <fwp_hof0.constprop.0+0x490>  // b.lo, b.ul, b.last
    9e9c:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9ea0:	1400003e 	b	9f98 <fwp_hof0.constprop.0+0x508>
    9ea4:	b900053f 	str	wzr, [x9, #4]
    9ea8:	17ffffed 	b	9e5c <fwp_hof0.constprop.0+0x3cc>
    9eac:	72003c1f 	tst	w0, #0xffff
    9eb0:	54fffce1 	b.ne	9e4c <fwp_hof0.constprop.0+0x3bc>  // b.any
    9eb4:	17ffffe3 	b	9e40 <fwp_hof0.constprop.0+0x3b0>
    9eb8:	aa1b03fa 	mov	x26, x27
    9ebc:	aa1903fb 	mov	x27, x25
    9ec0:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9ec4:	b85c03b9 	ldur	w25, [x29, #-64]
    9ec8:	aa1a03e0 	mov	x0, x26
    9ecc:	b81d83a6 	stur	w6, [x29, #-40]
    9ed0:	97ffef45 	bl	5be4 <fwp_rc_share>
    9ed4:	b85d83a6 	ldur	w6, [x29, #-40]
    9ed8:	34000134 	cbz	w20, 9efc <fwp_hof0.constprop.0+0x46c>
    9edc:	aa1b03f8 	mov	x24, x27
    9ee0:	8b344f73 	add	x19, x27, w20, uxtw #3
    9ee4:	2a0603fc 	mov	w28, w6
    9ee8:	f8408700 	ldr	x0, [x24], #8
    9eec:	97ffef3e 	bl	5be4 <fwp_rc_share>
    9ef0:	eb18027f 	cmp	x19, x24
    9ef4:	54ffffa1 	b.ne	9ee8 <fwp_hof0.constprop.0+0x458>  // b.any
    9ef8:	2a1c03e6 	mov	w6, w28
    9efc:	aa1b03e2 	mov	x2, x27
    9f00:	2a1403e1 	mov	w1, w20
    9f04:	aa1a03e0 	mov	x0, x26
    9f08:	b81d83a6 	stur	w6, [x29, #-40]
    9f0c:	97ffec3e 	bl	5004 <fwp_apply>
    9f10:	aa0003f8 	mov	x24, x0
    9f14:	b85d83a6 	ldur	w6, [x29, #-40]
    9f18:	6b17033f 	cmp	w25, w23
    9f1c:	54fffc02 	b.cs	9e9c <fwp_hof0.constprop.0+0x40c>  // b.hs, b.nlast
    9f20:	f94066a1 	ldr	x1, [x21, #200]
    9f24:	4b0602f7 	sub	w23, w23, w6
    9f28:	b9400304 	ldr	w4, [x24]
    9f2c:	f85d03a0 	ldur	x0, [x29, #-48]
    9f30:	8b041424 	add	x4, x1, x4, lsl #5
    9f34:	b85c83a2 	ldur	w2, [x29, #-56]
    9f38:	8b264c00 	add	x0, x0, w6, uxtw #3
    9f3c:	f81d03a0 	stur	x0, [x29, #-48]
    9f40:	f9400c81 	ldr	x1, [x4, #24]
    9f44:	b85cc3a0 	ldur	w0, [x29, #-52]
    9f48:	4b020000 	sub	w0, w0, w2
    9f4c:	b81cc3a0 	stur	w0, [x29, #-52]
    9f50:	aa1803e0 	mov	x0, x24
    9f54:	b5ffe7e1 	cbnz	x1, 9c50 <fwp_hof0.constprop.0+0x1c0>
    9f58:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9f5c:	aa1803e0 	mov	x0, x24
    9f60:	97ffef21 	bl	5be4 <fwp_rc_share>
    9f64:	34000117 	cbz	w23, 9f84 <fwp_hof0.constprop.0+0x4f4>
    9f68:	f85d03ba 	ldur	x26, [x29, #-48]
    9f6c:	d2800016 	mov	x22, #0x0                   	// #0
    9f70:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    9f74:	910006d6 	add	x22, x22, #0x1
    9f78:	97ffef1b 	bl	5be4 <fwp_rc_share>
    9f7c:	6b1602ff 	cmp	w23, w22
    9f80:	54ffff88 	b.hi	9f70 <fwp_hof0.constprop.0+0x4e0>  // b.pmore
    9f84:	f85d03a2 	ldur	x2, [x29, #-48]
    9f88:	aa1803e0 	mov	x0, x24
    9f8c:	2a1703e1 	mov	w1, w23
    9f90:	97ffec1d 	bl	5004 <fwp_apply>
    9f94:	aa0003f8 	mov	x24, x0
    9f98:	f85a03a0 	ldur	x0, [x29, #-96]
    9f9c:	f1000400 	subs	x0, x0, #0x1
    9fa0:	f81a03a0 	stur	x0, [x29, #-96]
    9fa4:	54ffdee1 	b.ne	9b80 <fwp_hof0.constprop.0+0xf0>  // b.any
    9fa8:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe1d8>
    9fac:	91102042 	add	x2, x2, #0x408
    9fb0:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    9fb4:	aa1803e1 	mov	x1, x24
    9fb8:	aa1403e0 	mov	x0, x20
    9fbc:	aa1803fb 	mov	x27, x24
    9fc0:	91014042 	add	x2, x2, #0x50
    9fc4:	52800023 	mov	w3, #0x1                   	// #1
    9fc8:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9fcc:	aa1903fc 	mov	x28, x25
    9fd0:	f81f03bf 	stur	xzr, [x29, #-16]
    9fd4:	97fffab3 	bl	8aa0 <fwp_write>
    9fd8:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    9fdc:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    9fe0:	91196000 	add	x0, x0, #0x658
    9fe4:	f10002df 	cmp	x22, #0x0
    9fe8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9fec:	b1002b1f 	cmn	x24, #0xa
    9ff0:	54003288 	b.hi	a640 <fwp_hof0.constprop.0+0xbb0>  // b.pmore
    9ff4:	91002700 	add	x0, x24, #0x9
    9ff8:	52800021 	mov	w1, #0x1                   	// #1
    9ffc:	97ffebbd 	bl	4ef0 <fwp_heap_alloc>
    a000:	aa0003f3 	mov	x19, x0
    a004:	aa1603e1 	mov	x1, x22
    a008:	aa0003f6 	mov	x22, x0
    a00c:	aa1803e2 	mov	x2, x24
    a010:	f80086d8 	str	x24, [x22], #8
    a014:	8b180278 	add	x24, x19, x24
    a018:	aa1603e0 	mov	x0, x22
    a01c:	97ffe1ad 	bl	26d0 <memcpy@plt>
    a020:	3900231f 	strb	wzr, [x24, #8]
    a024:	f85e03a0 	ldur	x0, [x29, #-32]
    a028:	97ffe246 	bl	2940 <free@plt>
    a02c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a030:	91174003 	add	x3, x0, #0x5d0
    a034:	f949ec64 	ldr	x4, [x3, #5080]
    a038:	f949d861 	ldr	x1, [x3, #5040]
    a03c:	d370bc84 	lsl	x4, x4, #16
    a040:	cb010262 	sub	x2, x19, x1
    a044:	eb04005f 	cmp	x2, x4
    a048:	540003c2 	b.cs	a0c0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    a04c:	d350fc40 	lsr	x0, x2, #16
    a050:	f949fc66 	ldr	x6, [x3, #5112]
    a054:	8b000800 	add	x0, x0, x0, lsl #2
    a058:	d37df003 	lsl	x3, x0, #3
    a05c:	8b0300c0 	add	x0, x6, x3
    a060:	f9401018 	ldr	x24, [x0, #32]
    a064:	b40002f8 	cbz	x24, a0c0 <fwp_hof0.constprop.0+0x630>
    a068:	386368c3 	ldrb	w3, [x6, x3]
    a06c:	7100087f 	cmp	w3, #0x2
    a070:	54002ee0 	b.eq	a64c <fwp_hof0.constprop.0+0xbbc>  // b.none
    a074:	7100047f 	cmp	w3, #0x1
    a078:	54000241 	b.ne	a0c0 <fwp_hof0.constprop.0+0x630>  // b.any
    a07c:	29430003 	ldp	w3, w0, [x0, #24]
    a080:	92403c42 	and	x2, x2, #0xffff
    a084:	9b037c42 	mul	x2, x2, x3
    a088:	d360fc42 	lsr	x2, x2, #32
    a08c:	eb00005f 	cmp	x2, x0
    a090:	54000182 	b.cs	a0c0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    a094:	8b020318 	add	x24, x24, x2
    a098:	39400300 	ldrb	w0, [x24]
    a09c:	7103fc1f 	cmp	w0, #0xff
    a0a0:	54003cc0 	b.eq	a838 <fwp_hof0.constprop.0+0xda8>  // b.none
    a0a4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a0a8:	91174000 	add	x0, x0, #0x5d0
    a0ac:	52800021 	mov	w1, #0x1                   	// #1
    a0b0:	39000301 	strb	w1, [x24]
    a0b4:	f949ec04 	ldr	x4, [x0, #5080]
    a0b8:	f949d801 	ldr	x1, [x0, #5040]
    a0bc:	d370bc84 	lsl	x4, x4, #16
    a0c0:	cb010361 	sub	x1, x27, x1
    a0c4:	eb01009f 	cmp	x4, x1
    a0c8:	540003c9 	b.ls	a140 <fwp_hof0.constprop.0+0x6b0>  // b.plast
    a0cc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a0d0:	91174019 	add	x25, x0, #0x5d0
    a0d4:	d350fc22 	lsr	x2, x1, #16
    a0d8:	f949ff26 	ldr	x6, [x25, #5112]
    a0dc:	8b020842 	add	x2, x2, x2, lsl #2
    a0e0:	d37df042 	lsl	x2, x2, #3
    a0e4:	8b0200c0 	add	x0, x6, x2
    a0e8:	f9401018 	ldr	x24, [x0, #32]
    a0ec:	b40002b8 	cbz	x24, a140 <fwp_hof0.constprop.0+0x6b0>
    a0f0:	386268c2 	ldrb	w2, [x6, x2]
    a0f4:	7100085f 	cmp	w2, #0x2
    a0f8:	540030a0 	b.eq	a70c <fwp_hof0.constprop.0+0xc7c>  // b.none
    a0fc:	7100045f 	cmp	w2, #0x1
    a100:	54000201 	b.ne	a140 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a104:	29430002 	ldp	w2, w0, [x0, #24]
    a108:	92403c21 	and	x1, x1, #0xffff
    a10c:	9b027c21 	mul	x1, x1, x2
    a110:	d360fc21 	lsr	x1, x1, #32
    a114:	eb00003f 	cmp	x1, x0
    a118:	54000142 	b.cs	a140 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a11c:	8b010318 	add	x24, x24, x1
    a120:	39400300 	ldrb	w0, [x24]
    a124:	340000e0 	cbz	w0, a140 <fwp_hof0.constprop.0+0x6b0>
    a128:	7100041f 	cmp	w0, #0x1
    a12c:	540029c0 	b.eq	a664 <fwp_hof0.constprop.0+0xbd4>  // b.none
    a130:	7103fc1f 	cmp	w0, #0xff
    a134:	54002fa0 	b.eq	a728 <fwp_hof0.constprop.0+0xc98>  // b.none
    a138:	51000400 	sub	w0, w0, #0x1
    a13c:	39000300 	strb	w0, [x24]
    a140:	d00000a0 	adrp	x0, 20000 <__data_start>
    a144:	9101c003 	add	x3, x0, #0x70
    a148:	f9400262 	ldr	x2, [x19]
    a14c:	aa1603e0 	mov	x0, x22
    a150:	aa0303f6 	mov	x22, x3
    a154:	d2800021 	mov	x1, #0x1                   	// #1
    a158:	f9400463 	ldr	x3, [x3, #8]
    a15c:	97ffe209 	bl	2980 <fwrite@plt>
    a160:	f94006c1 	ldr	x1, [x22, #8]
    a164:	52800140 	mov	w0, #0xa                   	// #10
    a168:	97ffe18e 	bl	27a0 <fputc@plt>
    a16c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a170:	91174002 	add	x2, x0, #0x5d0
    a174:	f949d841 	ldr	x1, [x2, #5040]
    a178:	f949ec40 	ldr	x0, [x2, #5080]
    a17c:	cb010261 	sub	x1, x19, x1
    a180:	eb00403f 	cmp	x1, x0, lsl #16
    a184:	54000382 	b.cs	a1f4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    a188:	d350fc20 	lsr	x0, x1, #16
    a18c:	f949fc43 	ldr	x3, [x2, #5112]
    a190:	8b000800 	add	x0, x0, x0, lsl #2
    a194:	d37df000 	lsl	x0, x0, #3
    a198:	8b000062 	add	x2, x3, x0
    a19c:	f9401056 	ldr	x22, [x2, #32]
    a1a0:	b40002b6 	cbz	x22, a1f4 <fwp_hof0.constprop.0+0x764>
    a1a4:	38606860 	ldrb	w0, [x3, x0]
    a1a8:	7100081f 	cmp	w0, #0x2
    a1ac:	54002560 	b.eq	a658 <fwp_hof0.constprop.0+0xbc8>  // b.none
    a1b0:	7100041f 	cmp	w0, #0x1
    a1b4:	54000201 	b.ne	a1f4 <fwp_hof0.constprop.0+0x764>  // b.any
    a1b8:	29430043 	ldp	w3, w0, [x2, #24]
    a1bc:	92403c21 	and	x1, x1, #0xffff
    a1c0:	9b037c21 	mul	x1, x1, x3
    a1c4:	d360fc21 	lsr	x1, x1, #32
    a1c8:	eb00003f 	cmp	x1, x0
    a1cc:	54000142 	b.cs	a1f4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    a1d0:	8b0102d6 	add	x22, x22, x1
    a1d4:	394002c0 	ldrb	w0, [x22]
    a1d8:	340000e0 	cbz	w0, a1f4 <fwp_hof0.constprop.0+0x764>
    a1dc:	7100041f 	cmp	w0, #0x1
    a1e0:	54002de0 	b.eq	a79c <fwp_hof0.constprop.0+0xd0c>  // b.none
    a1e4:	7103fc1f 	cmp	w0, #0xff
    a1e8:	54002e00 	b.eq	a7a8 <fwp_hof0.constprop.0+0xd18>  // b.none
    a1ec:	51000400 	sub	w0, w0, #0x1
    a1f0:	390002c0 	strb	w0, [x22]
    a1f4:	f9400af7 	ldr	x23, [x23, #16]
    a1f8:	b5ffc7b7 	cbnz	x23, 9aec <fwp_hof0.constprop.0+0x5c>
    a1fc:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a200:	f947f400 	ldr	x0, [x0, #4072]
    a204:	f85f83a2 	ldur	x2, [x29, #-8]
    a208:	f9400001 	ldr	x1, [x0]
    a20c:	eb010042 	subs	x2, x2, x1
    a210:	d2800001 	mov	x1, #0x0                   	// #0
    a214:	54002821 	b.ne	a718 <fwp_hof0.constprop.0+0xc88>  // b.any
    a218:	910003bf 	mov	sp, x29
    a21c:	d2800000 	mov	x0, #0x0                   	// #0
    a220:	a94153f3 	ldp	x19, x20, [sp, #16]
    a224:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a228:	a94363f7 	ldp	x23, x24, [sp, #48]
    a22c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a230:	a94573fb 	ldp	x27, x28, [sp, #80]
    a234:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a238:	d65f03c0 	ret
    a23c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a240:	9117400a 	add	x10, x0, #0x5d0
    a244:	2a0103fa 	mov	w26, w1
    a248:	11000780 	add	w0, w28, #0x1
    a24c:	f120001f 	cmp	x0, #0x800
    a250:	aa1703e4 	mov	x4, x23
    a254:	b953a541 	ldr	w1, [x10, #5028]
    a258:	aa1903fb 	mov	x27, x25
    a25c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a260:	d37df000 	lsl	x0, x0, #3
    a264:	b85c03b9 	ldur	w25, [x29, #-64]
    a268:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a26c:	540018e0 	b.eq	a588 <fwp_hof0.constprop.0+0xaf8>  // b.none
    a270:	91003c01 	add	x1, x0, #0xf
    a274:	8b411141 	add	x1, x10, x1, lsr #4
    a278:	397e8021 	ldrb	w1, [x1, #4000]
    a27c:	910f002b 	add	x11, x1, #0x3c0
    a280:	8b010422 	add	x2, x1, x1, lsl #1
    a284:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a288:	8b020d4c 	add	x12, x10, x2, lsl #3
    a28c:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    a290:	2a0b03e1 	mov	w1, w11
    a294:	b4001693 	cbz	x19, a564 <fwp_hof0.constprop.0+0xad4>
    a298:	f940026c 	ldr	x12, [x19]
    a29c:	aa2c03ec 	mvn	x12, x12
    a2a0:	f822794c 	str	x12, [x10, x2, lsl #3]
    a2a4:	eb01001f 	cmp	x0, x1
    a2a8:	540000c2 	b.cs	a2c0 <fwp_hof0.constprop.0+0x830>  // b.hs, b.nlast
    a2ac:	d503201f 	nop
    a2b0:	f8206a7f 	str	xzr, [x19, x0]
    a2b4:	91002000 	add	x0, x0, #0x8
    a2b8:	eb00003f 	cmp	x1, x0
    a2bc:	54ffffa8 	b.hi	a2b0 <fwp_hof0.constprop.0+0x820>  // b.pmore
    a2c0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a2c4:	91174002 	add	x2, x0, #0x5d0
    a2c8:	f94a1040 	ldr	x0, [x2, #5152]
    a2cc:	ab010000 	adds	x0, x0, x1
    a2d0:	54002a62 	b.cs	a81c <fwp_hof0.constprop.0+0xd8c>  // b.hs, b.nlast
    a2d4:	f94a1441 	ldr	x1, [x2, #5160]
    a2d8:	f90a1040 	str	x0, [x2, #5152]
    a2dc:	eb01001f 	cmp	x0, x1
    a2e0:	54000049 	b.ls	a2e8 <fwp_hof0.constprop.0+0x858>  // b.plast
    a2e4:	f90a1440 	str	x0, [x2, #5160]
    a2e8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a2ec:	91174000 	add	x0, x0, #0x5d0
    a2f0:	1e630161 	ucvtf	d1, w11
    a2f4:	fd4a1c00 	ldr	d0, [x0, #5176]
    a2f8:	1e612800 	fadd	d0, d0, d1
    a2fc:	fd0a1c00 	str	d0, [x0, #5176]
    a300:	b9400120 	ldr	w0, [x9]
    a304:	29007260 	stp	w0, w28, [x19]
    a308:	3400017a 	cbz	w26, a334 <fwp_hof0.constprop.0+0x8a4>
    a30c:	91002121 	add	x1, x9, #0x8
    a310:	d37d7f42 	ubfiz	x2, x26, #3, #32
    a314:	91002260 	add	x0, x19, #0x8
    a318:	b81bc3a6 	stur	w6, [x29, #-68]
    a31c:	f81c03a4 	stur	x4, [x29, #-64]
    a320:	f81d83a9 	stur	x9, [x29, #-40]
    a324:	97ffe0f3 	bl	26f0 <memmove@plt>
    a328:	f85c03a4 	ldur	x4, [x29, #-64]
    a32c:	f85d83a9 	ldur	x9, [x29, #-40]
    a330:	b85bc3a6 	ldur	w6, [x29, #-68]
    a334:	2a1403e8 	mov	w8, w20
    a338:	d2800001 	mov	x1, #0x0                   	// #0
    a33c:	34000114 	cbz	w20, a35c <fwp_hof0.constprop.0+0x8cc>
    a340:	0b010340 	add	w0, w26, w1
    a344:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a348:	8b000e60 	add	x0, x19, x0, lsl #3
    a34c:	91000421 	add	x1, x1, #0x1
    a350:	f9000402 	str	x2, [x0, #8]
    a354:	eb01011f 	cmp	x8, x1
    a358:	54ffff41 	b.ne	a340 <fwp_hof0.constprop.0+0x8b0>  // b.any
    a35c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a360:	91174002 	add	x2, x0, #0x5d0
    a364:	f949d840 	ldr	x0, [x2, #5040]
    a368:	f949ec41 	ldr	x1, [x2, #5080]
    a36c:	cb000300 	sub	x0, x24, x0
    a370:	eb01401f 	cmp	x0, x1, lsl #16
    a374:	540002e2 	b.cs	a3d0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a378:	d350fc01 	lsr	x1, x0, #16
    a37c:	f949fc45 	ldr	x5, [x2, #5112]
    a380:	8b010821 	add	x1, x1, x1, lsl #2
    a384:	d37df021 	lsl	x1, x1, #3
    a388:	8b0100a3 	add	x3, x5, x1
    a38c:	f9401062 	ldr	x2, [x3, #32]
    a390:	b4000202 	cbz	x2, a3d0 <fwp_hof0.constprop.0+0x940>
    a394:	386168a1 	ldrb	w1, [x5, x1]
    a398:	7100083f 	cmp	w1, #0x2
    a39c:	540010a0 	b.eq	a5b0 <fwp_hof0.constprop.0+0xb20>  // b.none
    a3a0:	7100043f 	cmp	w1, #0x1
    a3a4:	54000161 	b.ne	a3d0 <fwp_hof0.constprop.0+0x940>  // b.any
    a3a8:	29430465 	ldp	w5, w1, [x3, #24]
    a3ac:	92403c00 	and	x0, x0, #0xffff
    a3b0:	9b057c00 	mul	x0, x0, x5
    a3b4:	d360fc00 	lsr	x0, x0, #32
    a3b8:	eb01001f 	cmp	x0, x1
    a3bc:	540000a2 	b.cs	a3d0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a3c0:	8b000042 	add	x2, x2, x0
    a3c4:	39400040 	ldrb	w0, [x2]
    a3c8:	7100041f 	cmp	w0, #0x1
    a3cc:	54000c20 	b.eq	a550 <fwp_hof0.constprop.0+0xac0>  // b.none
    a3d0:	f9400c82 	ldr	x2, [x4, #24]
    a3d4:	aa1803e0 	mov	x0, x24
    a3d8:	52800021 	mov	w1, #0x1                   	// #1
    a3dc:	b81d83a6 	stur	w6, [x29, #-40]
    a3e0:	f9400442 	ldr	x2, [x2, #8]
    a3e4:	d63f0040 	blr	x2
    a3e8:	b85d83a6 	ldur	w6, [x29, #-40]
    a3ec:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a3f0:	91174002 	add	x2, x0, #0x5d0
    a3f4:	f949d841 	ldr	x1, [x2, #5040]
    a3f8:	f949ec40 	ldr	x0, [x2, #5080]
    a3fc:	cb010261 	sub	x1, x19, x1
    a400:	eb00403f 	cmp	x1, x0, lsl #16
    a404:	54000322 	b.cs	a468 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a408:	d350fc20 	lsr	x0, x1, #16
    a40c:	f949fc43 	ldr	x3, [x2, #5112]
    a410:	8b000800 	add	x0, x0, x0, lsl #2
    a414:	d37df002 	lsl	x2, x0, #3
    a418:	8b020060 	add	x0, x3, x2
    a41c:	f9401014 	ldr	x20, [x0, #32]
    a420:	b4000254 	cbz	x20, a468 <fwp_hof0.constprop.0+0x9d8>
    a424:	38626862 	ldrb	w2, [x3, x2]
    a428:	7100085f 	cmp	w2, #0x2
    a42c:	54000c80 	b.eq	a5bc <fwp_hof0.constprop.0+0xb2c>  // b.none
    a430:	7100045f 	cmp	w2, #0x1
    a434:	540001a1 	b.ne	a468 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a438:	29430002 	ldp	w2, w0, [x0, #24]
    a43c:	92403c21 	and	x1, x1, #0xffff
    a440:	9b027c21 	mul	x1, x1, x2
    a444:	d360fc21 	lsr	x1, x1, #32
    a448:	eb00003f 	cmp	x1, x0
    a44c:	540000e2 	b.cs	a468 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a450:	8b010294 	add	x20, x20, x1
    a454:	39400280 	ldrb	w0, [x20]
    a458:	7103fc1f 	cmp	w0, #0xff
    a45c:	54000ba0 	b.eq	a5d0 <fwp_hof0.constprop.0+0xb40>  // b.none
    a460:	52800020 	mov	w0, #0x1                   	// #1
    a464:	39000280 	strb	w0, [x20]
    a468:	aa1803e0 	mov	x0, x24
    a46c:	b81d83a6 	stur	w6, [x29, #-40]
    a470:	97ffefc8 	bl	6390 <fwp_closure_drop>
    a474:	aa1303f8 	mov	x24, x19
    a478:	b85d83a6 	ldur	w6, [x29, #-40]
    a47c:	17fffea7 	b	9f18 <fwp_hof0.constprop.0+0x488>
    a480:	b8626860 	ldr	w0, [x3, x2]
    a484:	b94004c2 	ldr	w2, [x6, #4]
    a488:	4b020003 	sub	w3, w0, w2
    a48c:	7100047f 	cmp	w3, #0x1
    a490:	54ffb901 	b.ne	9bb0 <fwp_hof0.constprop.0+0x120>  // b.any
    a494:	910003f6 	mov	x22, sp
    a498:	34000c42 	cbz	w2, a620 <fwp_hof0.constprop.0+0xb90>
    a49c:	7100001f 	cmp	w0, #0x0
    a4a0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a4a4:	d2800101 	mov	x1, #0x8                   	// #8
    a4a8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a4ac:	91003ee0 	add	x0, x23, #0xf
    a4b0:	92704c01 	and	x1, x0, #0xfffff0000
    a4b4:	927c7c00 	and	x0, x0, #0xffffffff0
    a4b8:	cb2163e1 	sub	x1, sp, x1
    a4bc:	eb2163ff 	cmp	sp, x1
    a4c0:	540000a0 	b.eq	a4d4 <fwp_hof0.constprop.0+0xa44>  // b.none
    a4c4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a4c8:	f90203ff 	str	xzr, [sp, #1024]
    a4cc:	eb2163ff 	cmp	sp, x1
    a4d0:	54ffffa1 	b.ne	a4c4 <fwp_hof0.constprop.0+0xa34>  // b.any
    a4d4:	92403c00 	and	x0, x0, #0xffff
    a4d8:	cb2063ff 	sub	sp, sp, x0
    a4dc:	f90003ff 	str	xzr, [sp]
    a4e0:	f110001f 	cmp	x0, #0x400
    a4e4:	54000043 	b.cc	a4ec <fwp_hof0.constprop.0+0xa5c>  // b.lo, b.ul, b.last
    a4e8:	f90203ff 	str	xzr, [sp, #1024]
    a4ec:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a4f0:	910043fa 	add	x26, sp, #0x10
    a4f4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a4f8:	91004001 	add	x1, x0, #0x10
    a4fc:	aa1b03e2 	mov	x2, x27
    a500:	91012021 	add	x1, x1, #0x48
    a504:	aa1703e3 	mov	x3, x23
    a508:	aa1a03e0 	mov	x0, x26
    a50c:	f81d83a4 	stur	x4, [x29, #-40]
    a510:	97ffe0b0 	bl	27d0 <__memcpy_chk@plt>
    a514:	eb1b02ff 	cmp	x23, x27
    a518:	aa1403e1 	mov	x1, x20
    a51c:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a520:	d2800102 	mov	x2, #0x8                   	// #8
    a524:	cb1b0063 	sub	x3, x3, x27
    a528:	8b1b0340 	add	x0, x26, x27
    a52c:	97ffe0a9 	bl	27d0 <__memcpy_chk@plt>
    a530:	f85d83a4 	ldur	x4, [x29, #-40]
    a534:	aa1a03e0 	mov	x0, x26
    a538:	f9400c81 	ldr	x1, [x4, #24]
    a53c:	f9400021 	ldr	x1, [x1]
    a540:	d63f0020 	blr	x1
    a544:	aa0003f8 	mov	x24, x0
    a548:	910002df 	mov	sp, x22
    a54c:	17fffe93 	b	9f98 <fwp_hof0.constprop.0+0x508>
    a550:	b900053f 	str	wzr, [x9, #4]
    a554:	17ffffa6 	b	a3ec <fwp_hof0.constprop.0+0x95c>
    a558:	72003c3f 	tst	w1, #0xffff
    a55c:	54ffb6a1 	b.ne	9c30 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a560:	17fffdae 	b	9c18 <fwp_hof0.constprop.0+0x188>
    a564:	f9400593 	ldr	x19, [x12, #8]
    a568:	b4000113 	cbz	x19, a588 <fwp_hof0.constprop.0+0xaf8>
    a56c:	f9400982 	ldr	x2, [x12, #16]
    a570:	cb130042 	sub	x2, x2, x19
    a574:	eb02003f 	cmp	x1, x2
    a578:	54000088 	b.hi	a588 <fwp_hof0.constprop.0+0xaf8>  // b.pmore
    a57c:	8b010262 	add	x2, x19, x1
    a580:	f9000582 	str	x2, [x12, #8]
    a584:	17ffff48 	b	a2a4 <fwp_hof0.constprop.0+0x814>
    a588:	52800001 	mov	w1, #0x0                   	// #0
    a58c:	b81bc3a6 	stur	w6, [x29, #-68]
    a590:	f81c03a4 	stur	x4, [x29, #-64]
    a594:	f81d83a9 	stur	x9, [x29, #-40]
    a598:	97ffea56 	bl	4ef0 <fwp_heap_alloc>
    a59c:	f85c03a4 	ldur	x4, [x29, #-64]
    a5a0:	aa0003f3 	mov	x19, x0
    a5a4:	f85d83a9 	ldur	x9, [x29, #-40]
    a5a8:	b85bc3a6 	ldur	w6, [x29, #-68]
    a5ac:	17ffff55 	b	a300 <fwp_hof0.constprop.0+0x870>
    a5b0:	72003c1f 	tst	w0, #0xffff
    a5b4:	54fff0e1 	b.ne	a3d0 <fwp_hof0.constprop.0+0x940>  // b.any
    a5b8:	17ffff83 	b	a3c4 <fwp_hof0.constprop.0+0x934>
    a5bc:	72003c3f 	tst	w1, #0xffff
    a5c0:	54fff541 	b.ne	a468 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a5c4:	39400280 	ldrb	w0, [x20]
    a5c8:	7103fc1f 	cmp	w0, #0xff
    a5cc:	54fff4a1 	b.ne	a460 <fwp_hof0.constprop.0+0x9d0>  // b.any
    a5d0:	aa1403e0 	mov	x0, x20
    a5d4:	b81d83a6 	stur	w6, [x29, #-40]
    a5d8:	97ffe6ee 	bl	4190 <fwp_rc_forget_slot.part.0>
    a5dc:	b85d83a6 	ldur	w6, [x29, #-40]
    a5e0:	17ffffa0 	b	a460 <fwp_hof0.constprop.0+0x9d0>
    a5e4:	72003c5f 	tst	w2, #0xffff
    a5e8:	54ffac21 	b.ne	9b6c <fwp_hof0.constprop.0+0xdc>  // b.any
    a5ec:	17fffd5a 	b	9b54 <fwp_hof0.constprop.0+0xc4>
    a5f0:	f81d83a4 	stur	x4, [x29, #-40]
    a5f4:	97ffe7fc 	bl	45e4 <fwp_rc_wide_dup>
    a5f8:	f85d83a4 	ldur	x4, [x29, #-40]
    a5fc:	17fffd8d 	b	9c30 <fwp_hof0.constprop.0+0x1a0>
    a600:	aa1903e0 	mov	x0, x25
    a604:	97ffed78 	bl	5be4 <fwp_rc_share>
    a608:	aa1803e0 	mov	x0, x24
    a60c:	52800037 	mov	w23, #0x1                   	// #1
    a610:	97ffed75 	bl	5be4 <fwp_rc_share>
    a614:	aa1903f8 	mov	x24, x25
    a618:	f81d03b4 	stur	x20, [x29, #-48]
    a61c:	17fffe5a 	b	9f84 <fwp_hof0.constprop.0+0x4f4>
    a620:	f9400021 	ldr	x1, [x1]
    a624:	aa1403e0 	mov	x0, x20
    a628:	d63f0020 	blr	x1
    a62c:	aa0003f8 	mov	x24, x0
    a630:	910002df 	mov	sp, x22
    a634:	17fffe59 	b	9f98 <fwp_hof0.constprop.0+0x508>
    a638:	97ffe7eb 	bl	45e4 <fwp_rc_wide_dup>
    a63c:	17fffd4c 	b	9b6c <fwp_hof0.constprop.0+0xdc>
    a640:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    a644:	91066000 	add	x0, x0, #0x198
    a648:	97ffe6b2 	bl	4110 <fwp_trap>
    a64c:	72003c5f 	tst	w2, #0xffff
    a650:	54ffd381 	b.ne	a0c0 <fwp_hof0.constprop.0+0x630>  // b.any
    a654:	17fffe91 	b	a098 <fwp_hof0.constprop.0+0x608>
    a658:	72003c3f 	tst	w1, #0xffff
    a65c:	54ffdcc1 	b.ne	a1f4 <fwp_hof0.constprop.0+0x764>  // b.any
    a660:	17fffedd 	b	a1d4 <fwp_hof0.constprop.0+0x744>
    a664:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a668:	91174000 	add	x0, x0, #0x5d0
    a66c:	f9400b78 	ldr	x24, [x27, #16]
    a670:	f949ec03 	ldr	x3, [x0, #5080]
    a674:	f949d801 	ldr	x1, [x0, #5040]
    a678:	d370bc63 	lsl	x3, x3, #16
    a67c:	cb010362 	sub	x2, x27, x1
    a680:	eb03005f 	cmp	x2, x3
    a684:	540003a2 	b.cs	a6f8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a688:	d350fc44 	lsr	x4, x2, #16
    a68c:	8b040884 	add	x4, x4, x4, lsl #2
    a690:	d37df084 	lsl	x4, x4, #3
    a694:	8b0400c0 	add	x0, x6, x4
    a698:	f9401005 	ldr	x5, [x0, #32]
    a69c:	b40002e5 	cbz	x5, a6f8 <fwp_hof0.constprop.0+0xc68>
    a6a0:	386468c4 	ldrb	w4, [x6, x4]
    a6a4:	7100089f 	cmp	w4, #0x2
    a6a8:	540003a0 	b.eq	a71c <fwp_hof0.constprop.0+0xc8c>  // b.none
    a6ac:	7100049f 	cmp	w4, #0x1
    a6b0:	54000241 	b.ne	a6f8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a6b4:	29430004 	ldp	w4, w0, [x0, #24]
    a6b8:	92403c42 	and	x2, x2, #0xffff
    a6bc:	9b047c42 	mul	x2, x2, x4
    a6c0:	d360fc42 	lsr	x2, x2, #32
    a6c4:	eb00005f 	cmp	x2, x0
    a6c8:	54000182 	b.cs	a6f8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a6cc:	8b0200a5 	add	x5, x5, x2
    a6d0:	394000a0 	ldrb	w0, [x5]
    a6d4:	7100041f 	cmp	w0, #0x1
    a6d8:	54000101 	b.ne	a6f8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a6dc:	aa1b03e0 	mov	x0, x27
    a6e0:	97ffe748 	bl	4400 <fwp_mem_free>
    a6e4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a6e8:	91174000 	add	x0, x0, #0x5d0
    a6ec:	f949ec03 	ldr	x3, [x0, #5080]
    a6f0:	f949d801 	ldr	x1, [x0, #5040]
    a6f4:	d370bc63 	lsl	x3, x3, #16
    a6f8:	cb010301 	sub	x1, x24, x1
    a6fc:	eb03003f 	cmp	x1, x3
    a700:	54ffd202 	b.cs	a140 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a704:	aa1803fb 	mov	x27, x24
    a708:	17fffe73 	b	a0d4 <fwp_hof0.constprop.0+0x644>
    a70c:	72003c3f 	tst	w1, #0xffff
    a710:	54ffd181 	b.ne	a140 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a714:	17fffe83 	b	a120 <fwp_hof0.constprop.0+0x690>
    a718:	97ffe05a 	bl	2880 <__stack_chk_fail@plt>
    a71c:	72003c5f 	tst	w2, #0xffff
    a720:	54fffec1 	b.ne	a6f8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a724:	17ffffeb 	b	a6d0 <fwp_hof0.constprop.0+0xc40>
    a728:	ca584700 	eor	x0, x24, x24, lsr #17
    a72c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a730:	91174022 	add	x2, x1, #0x5d0
    a734:	ca402400 	eor	x0, x0, x0, lsr #9
    a738:	92401c00 	and	x0, x0, #0xff
    a73c:	910a2401 	add	x1, x0, #0x289
    a740:	8b000c40 	add	x0, x2, x0, lsl #3
    a744:	8b010c41 	add	x1, x2, x1, lsl #3
    a748:	f94a2400 	ldr	x0, [x0, #5192]
    a74c:	b50000a0 	cbnz	x0, a760 <fwp_hof0.constprop.0+0xcd0>
    a750:	14000034 	b	a820 <fwp_hof0.constprop.0+0xd90>
    a754:	91004001 	add	x1, x0, #0x10
    a758:	f9400800 	ldr	x0, [x0, #16]
    a75c:	b4000620 	cbz	x0, a820 <fwp_hof0.constprop.0+0xd90>
    a760:	f9400002 	ldr	x2, [x0]
    a764:	eb02031f 	cmp	x24, x2
    a768:	54ffff61 	b.ne	a754 <fwp_hof0.constprop.0+0xcc4>  // b.any
    a76c:	f9400021 	ldr	x1, [x1]
    a770:	f9400420 	ldr	x0, [x1, #8]
    a774:	d1000400 	sub	x0, x0, #0x1
    a778:	f9000420 	str	x0, [x1, #8]
    a77c:	f103f81f 	cmp	x0, #0xfe
    a780:	54ffce01 	b.ne	a140 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a784:	39400300 	ldrb	w0, [x24]
    a788:	7103fc1f 	cmp	w0, #0xff
    a78c:	54000500 	b.eq	a82c <fwp_hof0.constprop.0+0xd9c>  // b.none
    a790:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a794:	39000300 	strb	w0, [x24]
    a798:	17fffe6a 	b	a140 <fwp_hof0.constprop.0+0x6b0>
    a79c:	aa1303e0 	mov	x0, x19
    a7a0:	97ffe718 	bl	4400 <fwp_mem_free>
    a7a4:	17fffe94 	b	a1f4 <fwp_hof0.constprop.0+0x764>
    a7a8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a7ac:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a7b0:	91174022 	add	x2, x1, #0x5d0
    a7b4:	ca402400 	eor	x0, x0, x0, lsr #9
    a7b8:	92401c00 	and	x0, x0, #0xff
    a7bc:	910a2401 	add	x1, x0, #0x289
    a7c0:	8b000c40 	add	x0, x2, x0, lsl #3
    a7c4:	8b010c41 	add	x1, x2, x1, lsl #3
    a7c8:	f94a2400 	ldr	x0, [x0, #5192]
    a7cc:	b50000a0 	cbnz	x0, a7e0 <fwp_hof0.constprop.0+0xd50>
    a7d0:	14000014 	b	a820 <fwp_hof0.constprop.0+0xd90>
    a7d4:	91004001 	add	x1, x0, #0x10
    a7d8:	f9400800 	ldr	x0, [x0, #16]
    a7dc:	b4000220 	cbz	x0, a820 <fwp_hof0.constprop.0+0xd90>
    a7e0:	f9400002 	ldr	x2, [x0]
    a7e4:	eb16005f 	cmp	x2, x22
    a7e8:	54ffff61 	b.ne	a7d4 <fwp_hof0.constprop.0+0xd44>  // b.any
    a7ec:	f9400021 	ldr	x1, [x1]
    a7f0:	f9400420 	ldr	x0, [x1, #8]
    a7f4:	d1000400 	sub	x0, x0, #0x1
    a7f8:	f9000420 	str	x0, [x1, #8]
    a7fc:	f103f81f 	cmp	x0, #0xfe
    a800:	54ffcfa1 	b.ne	a1f4 <fwp_hof0.constprop.0+0x764>  // b.any
    a804:	394002c0 	ldrb	w0, [x22]
    a808:	7103fc1f 	cmp	w0, #0xff
    a80c:	540001c0 	b.eq	a844 <fwp_hof0.constprop.0+0xdb4>  // b.none
    a810:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a814:	390002c0 	strb	w0, [x22]
    a818:	17fffe77 	b	a1f4 <fwp_hof0.constprop.0+0x764>
    a81c:	97ffe205 	bl	3030 <fwp_heap_oom>
    a820:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x120>
    a824:	9134e000 	add	x0, x0, #0xd38
    a828:	97ffe63a 	bl	4110 <fwp_trap>
    a82c:	aa1803e0 	mov	x0, x24
    a830:	97ffe658 	bl	4190 <fwp_rc_forget_slot.part.0>
    a834:	17ffffd7 	b	a790 <fwp_hof0.constprop.0+0xd00>
    a838:	aa1803e0 	mov	x0, x24
    a83c:	97ffe655 	bl	4190 <fwp_rc_forget_slot.part.0>
    a840:	17fffe19 	b	a0a4 <fwp_hof0.constprop.0+0x614>
    a844:	aa1603e0 	mov	x0, x22
    a848:	97ffe652 	bl	4190 <fwp_rc_forget_slot.part.0>
    a84c:	17fffff1 	b	a810 <fwp_hof0.constprop.0+0xd80>

000000000000a850 <f0>:
    a850:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a854:	910003fd 	mov	x29, sp
    a858:	a90153f3 	stp	x19, x20, [sp, #16]
    a85c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a860:	a90363f7 	stp	x23, x24, [sp, #48]
    a864:	a9046bf9 	stp	x25, x26, [sp, #64]
    a868:	a90573fb 	stp	x27, x28, [sp, #80]
    a86c:	d121c3ff 	sub	sp, sp, #0x870
    a870:	f90203ff 	str	xzr, [sp, #1024]
    a874:	d00000a0 	adrp	x0, 20000 <__data_start>
    a878:	9101c003 	add	x3, x0, #0x70
    a87c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a880:	f947f400 	ldr	x0, [x0, #4072]
    a884:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a888:	f9418865 	ldr	x5, [x3, #784]
    a88c:	f9400001 	ldr	x1, [x0]
    a890:	f90437e1 	str	x1, [sp, #2152]
    a894:	d2800001 	mov	x1, #0x0                   	// #0
    a898:	91174299 	add	x25, x20, #0x5d0
    a89c:	912163f6 	add	x22, sp, #0x858
    a8a0:	910063e4 	add	x4, sp, #0x18
    a8a4:	9100c3e1 	add	x1, sp, #0x30
    a8a8:	90ffffe0 	adrp	x0, 6000 <e161+0x90>
    a8ac:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a8b0:	91088000 	add	x0, x0, #0x220
    a8b4:	913d4042 	add	x2, x2, #0xf50
    a8b8:	d2800013 	mov	x19, #0x0                   	// #0
    a8bc:	d280011a 	mov	x26, #0x8                   	// #8
    a8c0:	d2800015 	mov	x21, #0x0                   	// #0
    a8c4:	52800037 	mov	w23, #0x1                   	// #1
    a8c8:	f90007e4 	str	x4, [sp, #8]
    a8cc:	a9018be5 	stp	x5, x2, [sp, #24]
    a8d0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a8d4:	a90403ff 	stp	xzr, x0, [sp, #64]
    a8d8:	f9018864 	str	x4, [x3, #784]
    a8dc:	d503201f 	nop
    a8e0:	f100075b 	subs	x27, x26, #0x1
    a8e4:	aa1603e1 	mov	x1, x22
    a8e8:	da1f02b8 	sbc	x24, x21, xzr
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	f9001ffb 	str	x27, [sp, #56]
    a8f4:	aa1b03fa 	mov	x26, x27
    a8f8:	f9042ffb 	str	x27, [sp, #2136]
    a8fc:	aa1803f5 	mov	x21, x24
    a900:	f90433f3 	str	x19, [sp, #2144]
    a904:	97ffec70 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a908:	f949db22 	ldr	x2, [x25, #5040]
    a90c:	aa0003f3 	mov	x19, x0
    a910:	f949ef20 	ldr	x0, [x25, #5080]
    a914:	cb020262 	sub	x2, x19, x2
    a918:	eb00405f 	cmp	x2, x0, lsl #16
    a91c:	54000302 	b.cs	a97c <f0+0x12c>  // b.hs, b.nlast
    a920:	d350fc40 	lsr	x0, x2, #16
    a924:	f949ff25 	ldr	x5, [x25, #5112]
    a928:	8b000800 	add	x0, x0, x0, lsl #2
    a92c:	d37df001 	lsl	x1, x0, #3
    a930:	8b0100a0 	add	x0, x5, x1
    a934:	f940101c 	ldr	x28, [x0, #32]
    a938:	b400023c 	cbz	x28, a97c <f0+0x12c>
    a93c:	386168a1 	ldrb	w1, [x5, x1]
    a940:	7100083f 	cmp	w1, #0x2
    a944:	54010f00 	b.eq	cb24 <f0+0x22d4>  // b.none
    a948:	7100043f 	cmp	w1, #0x1
    a94c:	54000181 	b.ne	a97c <f0+0x12c>  // b.any
    a950:	29430001 	ldp	w1, w0, [x0, #24]
    a954:	92403c42 	and	x2, x2, #0xffff
    a958:	9b017c42 	mul	x2, x2, x1
    a95c:	d360fc42 	lsr	x2, x2, #32
    a960:	eb00005f 	cmp	x2, x0
    a964:	540000c2 	b.cs	a97c <f0+0x12c>  // b.hs, b.nlast
    a968:	8b02039c 	add	x28, x28, x2
    a96c:	39400380 	ldrb	w0, [x28]
    a970:	7103fc1f 	cmp	w0, #0xff
    a974:	54010d20 	b.eq	cb18 <f0+0x22c8>  // b.none
    a978:	39000397 	strb	w23, [x28]
    a97c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a980:	aa18037b 	orr	x27, x27, x24
    a984:	b5fffafb 	cbnz	x27, a8e0 <f0+0x90>
    a988:	d00000a0 	adrp	x0, 20000 <__data_start>
    a98c:	9101c018 	add	x24, x0, #0x70
    a990:	f94007e1 	ldr	x1, [sp, #8]
    a994:	f9001bff 	str	xzr, [sp, #48]
    a998:	f9418b00 	ldr	x0, [x24, #784]
    a99c:	eb01001f 	cmp	x0, x1
    a9a0:	540129e1 	b.ne	cedc <f0+0x268c>  // b.any
    a9a4:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    a9a8:	910143e1 	add	x1, sp, #0x50
    a9ac:	f9400fe2 	ldr	x2, [sp, #24]
    a9b0:	f9018b02 	str	x2, [x24, #784]
    a9b4:	3dc24800 	ldr	q0, [x0, #2336]
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	3d8017e0 	str	q0, [sp, #80]
    a9c0:	97ffec41 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a9c4:	97ffecac 	bl	5c74 <fwp_rc_fresh>
    a9c8:	9101a3e1 	add	x1, sp, #0x68
    a9cc:	aa0003e2 	mov	x2, x0
    a9d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a9d4:	52800020 	mov	w0, #0x1                   	// #1
    a9d8:	a9068be3 	stp	x3, x2, [sp, #104]
    a9dc:	97ffec3a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    a9e0:	97ffeca5 	bl	5c74 <fwp_rc_fresh>
    a9e4:	aa0003e2 	mov	x2, x0
    a9e8:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x4c0>
    a9ec:	9101e3e1 	add	x1, sp, #0x78
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	f90043e2 	str	x2, [sp, #128]
    a9f8:	3dc24860 	ldr	q0, [x3, #2336]
    a9fc:	fd003fe0 	str	d0, [sp, #120]
    aa00:	97ffec31 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aa04:	91174283 	add	x3, x20, #0x5d0
    aa08:	aa0003f7 	mov	x23, x0
    aa0c:	f949d861 	ldr	x1, [x3, #5040]
    aa10:	f949ec60 	ldr	x0, [x3, #5080]
    aa14:	cb0102e1 	sub	x1, x23, x1
    aa18:	eb00403f 	cmp	x1, x0, lsl #16
    aa1c:	54000322 	b.cs	aa80 <f0+0x230>  // b.hs, b.nlast
    aa20:	d350fc22 	lsr	x2, x1, #16
    aa24:	f949fc63 	ldr	x3, [x3, #5112]
    aa28:	8b020842 	add	x2, x2, x2, lsl #2
    aa2c:	d37df042 	lsl	x2, x2, #3
    aa30:	8b020060 	add	x0, x3, x2
    aa34:	f9401015 	ldr	x21, [x0, #32]
    aa38:	b4000255 	cbz	x21, aa80 <f0+0x230>
    aa3c:	38626862 	ldrb	w2, [x3, x2]
    aa40:	7100085f 	cmp	w2, #0x2
    aa44:	54010760 	b.eq	cb30 <f0+0x22e0>  // b.none
    aa48:	7100045f 	cmp	w2, #0x1
    aa4c:	540001a1 	b.ne	aa80 <f0+0x230>  // b.any
    aa50:	29430002 	ldp	w2, w0, [x0, #24]
    aa54:	92403c21 	and	x1, x1, #0xffff
    aa58:	9b027c21 	mul	x1, x1, x2
    aa5c:	d360fc21 	lsr	x1, x1, #32
    aa60:	eb00003f 	cmp	x1, x0
    aa64:	540000e2 	b.cs	aa80 <f0+0x230>  // b.hs, b.nlast
    aa68:	8b0102b5 	add	x21, x21, x1
    aa6c:	394002a0 	ldrb	w0, [x21]
    aa70:	7103fc1f 	cmp	w0, #0xff
    aa74:	540114e0 	b.eq	cd10 <f0+0x24c0>  // b.none
    aa78:	52800020 	mov	w0, #0x1                   	// #1
    aa7c:	390002a0 	strb	w0, [x21]
    aa80:	910223e1 	add	x1, sp, #0x88
    aa84:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aa88:	52800020 	mov	w0, #0x1                   	// #1
    aa8c:	a908dff5 	stp	x21, x23, [sp, #136]
    aa90:	97ffec0d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aa94:	97ffec78 	bl	5c74 <fwp_rc_fresh>
    aa98:	aa0003e2 	mov	x2, x0
    aa9c:	910263e1 	add	x1, sp, #0x98
    aaa0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aaa4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	a9098bf7 	stp	x23, x2, [sp, #152]
    aab0:	97ffec05 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aab4:	97ffec70 	bl	5c74 <fwp_rc_fresh>
    aab8:	aa0003e2 	mov	x2, x0
    aabc:	9102a3e1 	add	x1, sp, #0xa8
    aac0:	52800020 	mov	w0, #0x1                   	// #1
    aac4:	a90a8bf5 	stp	x21, x2, [sp, #168]
    aac8:	97ffebff 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aacc:	97ffec6a 	bl	5c74 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	9102e3e1 	add	x1, sp, #0xb8
    aad8:	52800020 	mov	w0, #0x1                   	// #1
    aadc:	a90b8bf7 	stp	x23, x2, [sp, #184]
    aae0:	97ffebf9 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aae4:	97ffec64 	bl	5c74 <fwp_rc_fresh>
    aae8:	aa0003e2 	mov	x2, x0
    aaec:	910323e1 	add	x1, sp, #0xc8
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	a90c8bf5 	stp	x21, x2, [sp, #200]
    aaf8:	97ffebf3 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aafc:	97ffec5e 	bl	5c74 <fwp_rc_fresh>
    ab00:	aa0003e2 	mov	x2, x0
    ab04:	910363e1 	add	x1, sp, #0xd8
    ab08:	52800020 	mov	w0, #0x1                   	// #1
    ab0c:	a90d8bf7 	stp	x23, x2, [sp, #216]
    ab10:	97ffebed 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab14:	97ffec58 	bl	5c74 <fwp_rc_fresh>
    ab18:	aa0003e2 	mov	x2, x0
    ab1c:	9103a3e1 	add	x1, sp, #0xe8
    ab20:	52800020 	mov	w0, #0x1                   	// #1
    ab24:	a90e8bf5 	stp	x21, x2, [sp, #232]
    ab28:	97ffebe7 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab2c:	97ffec52 	bl	5c74 <fwp_rc_fresh>
    ab30:	aa0003e2 	mov	x2, x0
    ab34:	9103e3e1 	add	x1, sp, #0xf8
    ab38:	52800020 	mov	w0, #0x1                   	// #1
    ab3c:	a90f8bf7 	stp	x23, x2, [sp, #248]
    ab40:	97ffebe1 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab44:	97ffec4c 	bl	5c74 <fwp_rc_fresh>
    ab48:	aa0003e2 	mov	x2, x0
    ab4c:	910423e1 	add	x1, sp, #0x108
    ab50:	52800020 	mov	w0, #0x1                   	// #1
    ab54:	a9108bf5 	stp	x21, x2, [sp, #264]
    ab58:	97ffebdb 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab5c:	97ffec46 	bl	5c74 <fwp_rc_fresh>
    ab60:	aa0003e2 	mov	x2, x0
    ab64:	910463e1 	add	x1, sp, #0x118
    ab68:	52800020 	mov	w0, #0x1                   	// #1
    ab6c:	a9118bf7 	stp	x23, x2, [sp, #280]
    ab70:	97ffebd5 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab74:	97ffec40 	bl	5c74 <fwp_rc_fresh>
    ab78:	aa0003e2 	mov	x2, x0
    ab7c:	9104a3e1 	add	x1, sp, #0x128
    ab80:	52800020 	mov	w0, #0x1                   	// #1
    ab84:	a9128bf5 	stp	x21, x2, [sp, #296]
    ab88:	97ffebcf 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ab8c:	97ffec3a 	bl	5c74 <fwp_rc_fresh>
    ab90:	aa0003e2 	mov	x2, x0
    ab94:	9104e3e1 	add	x1, sp, #0x138
    ab98:	52800020 	mov	w0, #0x1                   	// #1
    ab9c:	a9138bf7 	stp	x23, x2, [sp, #312]
    aba0:	97ffebc9 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aba4:	97ffec34 	bl	5c74 <fwp_rc_fresh>
    aba8:	aa0003e2 	mov	x2, x0
    abac:	910523e1 	add	x1, sp, #0x148
    abb0:	52800020 	mov	w0, #0x1                   	// #1
    abb4:	a9148bf5 	stp	x21, x2, [sp, #328]
    abb8:	97ffebc3 	bl	5ac4 <fwp_data.part.0.constprop.0>
    abbc:	97ffec2e 	bl	5c74 <fwp_rc_fresh>
    abc0:	aa0003e2 	mov	x2, x0
    abc4:	910563e1 	add	x1, sp, #0x158
    abc8:	52800020 	mov	w0, #0x1                   	// #1
    abcc:	a9158bf7 	stp	x23, x2, [sp, #344]
    abd0:	97ffebbd 	bl	5ac4 <fwp_data.part.0.constprop.0>
    abd4:	97ffec28 	bl	5c74 <fwp_rc_fresh>
    abd8:	aa0003e2 	mov	x2, x0
    abdc:	9105a3e1 	add	x1, sp, #0x168
    abe0:	52800020 	mov	w0, #0x1                   	// #1
    abe4:	a9168bf5 	stp	x21, x2, [sp, #360]
    abe8:	97ffebb7 	bl	5ac4 <fwp_data.part.0.constprop.0>
    abec:	97ffec22 	bl	5c74 <fwp_rc_fresh>
    abf0:	aa0003e2 	mov	x2, x0
    abf4:	9105e3e1 	add	x1, sp, #0x178
    abf8:	52800020 	mov	w0, #0x1                   	// #1
    abfc:	a9178bf7 	stp	x23, x2, [sp, #376]
    ac00:	97ffebb1 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac04:	97ffec1c 	bl	5c74 <fwp_rc_fresh>
    ac08:	aa0003e2 	mov	x2, x0
    ac0c:	910623e1 	add	x1, sp, #0x188
    ac10:	52800020 	mov	w0, #0x1                   	// #1
    ac14:	a9188bf5 	stp	x21, x2, [sp, #392]
    ac18:	97ffebab 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac1c:	97ffec16 	bl	5c74 <fwp_rc_fresh>
    ac20:	aa0003e2 	mov	x2, x0
    ac24:	910663e1 	add	x1, sp, #0x198
    ac28:	52800020 	mov	w0, #0x1                   	// #1
    ac2c:	a9198bf7 	stp	x23, x2, [sp, #408]
    ac30:	97ffeba5 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac34:	97ffec10 	bl	5c74 <fwp_rc_fresh>
    ac38:	aa0003e2 	mov	x2, x0
    ac3c:	9106a3e1 	add	x1, sp, #0x1a8
    ac40:	52800020 	mov	w0, #0x1                   	// #1
    ac44:	a91a8bf5 	stp	x21, x2, [sp, #424]
    ac48:	97ffeb9f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac4c:	97ffec0a 	bl	5c74 <fwp_rc_fresh>
    ac50:	aa0003e2 	mov	x2, x0
    ac54:	9106e3e1 	add	x1, sp, #0x1b8
    ac58:	52800020 	mov	w0, #0x1                   	// #1
    ac5c:	a91b8bf7 	stp	x23, x2, [sp, #440]
    ac60:	97ffeb99 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac64:	97ffec04 	bl	5c74 <fwp_rc_fresh>
    ac68:	aa0003e2 	mov	x2, x0
    ac6c:	910723e1 	add	x1, sp, #0x1c8
    ac70:	52800020 	mov	w0, #0x1                   	// #1
    ac74:	a91c8bf5 	stp	x21, x2, [sp, #456]
    ac78:	97ffeb93 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac7c:	97ffebfe 	bl	5c74 <fwp_rc_fresh>
    ac80:	aa0003e2 	mov	x2, x0
    ac84:	910763e1 	add	x1, sp, #0x1d8
    ac88:	52800020 	mov	w0, #0x1                   	// #1
    ac8c:	a91d8bf7 	stp	x23, x2, [sp, #472]
    ac90:	97ffeb8d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ac94:	97ffebf8 	bl	5c74 <fwp_rc_fresh>
    ac98:	aa0003e2 	mov	x2, x0
    ac9c:	9107a3e1 	add	x1, sp, #0x1e8
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	a91e8bf5 	stp	x21, x2, [sp, #488]
    aca8:	97ffeb87 	bl	5ac4 <fwp_data.part.0.constprop.0>
    acac:	97ffebf2 	bl	5c74 <fwp_rc_fresh>
    acb0:	aa0003e2 	mov	x2, x0
    acb4:	9107e3e1 	add	x1, sp, #0x1f8
    acb8:	52800020 	mov	w0, #0x1                   	// #1
    acbc:	a91f8bf7 	stp	x23, x2, [sp, #504]
    acc0:	97ffeb81 	bl	5ac4 <fwp_data.part.0.constprop.0>
    acc4:	97ffebec 	bl	5c74 <fwp_rc_fresh>
    acc8:	aa0003e2 	mov	x2, x0
    accc:	910823e1 	add	x1, sp, #0x208
    acd0:	52800020 	mov	w0, #0x1                   	// #1
    acd4:	f90107f5 	str	x21, [sp, #520]
    acd8:	f9010be2 	str	x2, [sp, #528]
    acdc:	97ffeb7a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ace0:	97ffebe5 	bl	5c74 <fwp_rc_fresh>
    ace4:	aa0003e2 	mov	x2, x0
    ace8:	910863e1 	add	x1, sp, #0x218
    acec:	52800020 	mov	w0, #0x1                   	// #1
    acf0:	f9010ff7 	str	x23, [sp, #536]
    acf4:	f90113e2 	str	x2, [sp, #544]
    acf8:	97ffeb73 	bl	5ac4 <fwp_data.part.0.constprop.0>
    acfc:	97ffebde 	bl	5c74 <fwp_rc_fresh>
    ad00:	aa0003e2 	mov	x2, x0
    ad04:	9108a3e1 	add	x1, sp, #0x228
    ad08:	52800020 	mov	w0, #0x1                   	// #1
    ad0c:	f90117f5 	str	x21, [sp, #552]
    ad10:	f9011be2 	str	x2, [sp, #560]
    ad14:	97ffeb6c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ad18:	97ffebd7 	bl	5c74 <fwp_rc_fresh>
    ad1c:	aa0003e2 	mov	x2, x0
    ad20:	9108e3e1 	add	x1, sp, #0x238
    ad24:	52800020 	mov	w0, #0x1                   	// #1
    ad28:	f9011ff7 	str	x23, [sp, #568]
    ad2c:	f90123e2 	str	x2, [sp, #576]
    ad30:	97ffeb65 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ad34:	97ffebd0 	bl	5c74 <fwp_rc_fresh>
    ad38:	aa0003e2 	mov	x2, x0
    ad3c:	910923e1 	add	x1, sp, #0x248
    ad40:	52800020 	mov	w0, #0x1                   	// #1
    ad44:	f90127f5 	str	x21, [sp, #584]
    ad48:	f9012be2 	str	x2, [sp, #592]
    ad4c:	97ffeb5e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ad50:	97ffebc9 	bl	5c74 <fwp_rc_fresh>
    ad54:	aa0003e2 	mov	x2, x0
    ad58:	910963e1 	add	x1, sp, #0x258
    ad5c:	52800020 	mov	w0, #0x1                   	// #1
    ad60:	f9012ff7 	str	x23, [sp, #600]
    ad64:	f90133e2 	str	x2, [sp, #608]
    ad68:	97ffeb57 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ad6c:	97ffebc2 	bl	5c74 <fwp_rc_fresh>
    ad70:	aa0003e2 	mov	x2, x0
    ad74:	9109a3e1 	add	x1, sp, #0x268
    ad78:	52800020 	mov	w0, #0x1                   	// #1
    ad7c:	f90137f5 	str	x21, [sp, #616]
    ad80:	f9013be2 	str	x2, [sp, #624]
    ad84:	97ffeb50 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ad88:	97ffebbb 	bl	5c74 <fwp_rc_fresh>
    ad8c:	aa0003e2 	mov	x2, x0
    ad90:	9109e3e1 	add	x1, sp, #0x278
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	f9013ff7 	str	x23, [sp, #632]
    ad9c:	f90143e2 	str	x2, [sp, #640]
    ada0:	97ffeb49 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ada4:	97ffebb4 	bl	5c74 <fwp_rc_fresh>
    ada8:	aa0003e2 	mov	x2, x0
    adac:	910a23e1 	add	x1, sp, #0x288
    adb0:	52800020 	mov	w0, #0x1                   	// #1
    adb4:	f90147f5 	str	x21, [sp, #648]
    adb8:	f9014be2 	str	x2, [sp, #656]
    adbc:	97ffeb42 	bl	5ac4 <fwp_data.part.0.constprop.0>
    adc0:	97ffebad 	bl	5c74 <fwp_rc_fresh>
    adc4:	aa0003e2 	mov	x2, x0
    adc8:	910a63e1 	add	x1, sp, #0x298
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	f9014ff7 	str	x23, [sp, #664]
    add4:	f90153e2 	str	x2, [sp, #672]
    add8:	97ffeb3b 	bl	5ac4 <fwp_data.part.0.constprop.0>
    addc:	97ffeba6 	bl	5c74 <fwp_rc_fresh>
    ade0:	aa0003e2 	mov	x2, x0
    ade4:	910aa3e1 	add	x1, sp, #0x2a8
    ade8:	52800020 	mov	w0, #0x1                   	// #1
    adec:	f90157f5 	str	x21, [sp, #680]
    adf0:	f9015be2 	str	x2, [sp, #688]
    adf4:	97ffeb34 	bl	5ac4 <fwp_data.part.0.constprop.0>
    adf8:	91174283 	add	x3, x20, #0x5d0
    adfc:	aa0003f5 	mov	x21, x0
    ae00:	f949d861 	ldr	x1, [x3, #5040]
    ae04:	f949ec60 	ldr	x0, [x3, #5080]
    ae08:	cb0102a1 	sub	x1, x21, x1
    ae0c:	eb00403f 	cmp	x1, x0, lsl #16
    ae10:	54000322 	b.cs	ae74 <f0+0x624>  // b.hs, b.nlast
    ae14:	d350fc22 	lsr	x2, x1, #16
    ae18:	f949fc63 	ldr	x3, [x3, #5112]
    ae1c:	8b020842 	add	x2, x2, x2, lsl #2
    ae20:	d37df042 	lsl	x2, x2, #3
    ae24:	8b020060 	add	x0, x3, x2
    ae28:	f9401017 	ldr	x23, [x0, #32]
    ae2c:	b4000257 	cbz	x23, ae74 <f0+0x624>
    ae30:	38626862 	ldrb	w2, [x3, x2]
    ae34:	7100085f 	cmp	w2, #0x2
    ae38:	5400e880 	b.eq	cb48 <f0+0x22f8>  // b.none
    ae3c:	7100045f 	cmp	w2, #0x1
    ae40:	540001a1 	b.ne	ae74 <f0+0x624>  // b.any
    ae44:	29430002 	ldp	w2, w0, [x0, #24]
    ae48:	92403c21 	and	x1, x1, #0xffff
    ae4c:	9b027c21 	mul	x1, x1, x2
    ae50:	d360fc21 	lsr	x1, x1, #32
    ae54:	eb00003f 	cmp	x1, x0
    ae58:	540000e2 	b.cs	ae74 <f0+0x624>  // b.hs, b.nlast
    ae5c:	8b0102f7 	add	x23, x23, x1
    ae60:	394002e0 	ldrb	w0, [x23]
    ae64:	7103fc1f 	cmp	w0, #0xff
    ae68:	5400f5a0 	b.eq	cd1c <f0+0x24cc>  // b.none
    ae6c:	52800020 	mov	w0, #0x1                   	// #1
    ae70:	390002e0 	strb	w0, [x23]
    ae74:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae78:	910ae3e1 	add	x1, sp, #0x2b8
    ae7c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae80:	52800020 	mov	w0, #0x1                   	// #1
    ae84:	f9015fe2 	str	x2, [sp, #696]
    ae88:	f90163f5 	str	x21, [sp, #704]
    ae8c:	97ffeb0e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ae90:	97ffeb79 	bl	5c74 <fwp_rc_fresh>
    ae94:	aa0003e2 	mov	x2, x0
    ae98:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae9c:	910b23e1 	add	x1, sp, #0x2c8
    aea0:	52800020 	mov	w0, #0x1                   	// #1
    aea4:	f90167e3 	str	x3, [sp, #712]
    aea8:	f9016be2 	str	x2, [sp, #720]
    aeac:	97ffeb06 	bl	5ac4 <fwp_data.part.0.constprop.0>
    aeb0:	91174283 	add	x3, x20, #0x5d0
    aeb4:	aa0003f5 	mov	x21, x0
    aeb8:	f949d861 	ldr	x1, [x3, #5040]
    aebc:	f949ec60 	ldr	x0, [x3, #5080]
    aec0:	cb0102a1 	sub	x1, x21, x1
    aec4:	eb00403f 	cmp	x1, x0, lsl #16
    aec8:	54000322 	b.cs	af2c <f0+0x6dc>  // b.hs, b.nlast
    aecc:	d350fc22 	lsr	x2, x1, #16
    aed0:	f949fc63 	ldr	x3, [x3, #5112]
    aed4:	8b020842 	add	x2, x2, x2, lsl #2
    aed8:	d37df042 	lsl	x2, x2, #3
    aedc:	8b020060 	add	x0, x3, x2
    aee0:	f9401017 	ldr	x23, [x0, #32]
    aee4:	b4000257 	cbz	x23, af2c <f0+0x6dc>
    aee8:	38626862 	ldrb	w2, [x3, x2]
    aeec:	7100085f 	cmp	w2, #0x2
    aef0:	5400e260 	b.eq	cb3c <f0+0x22ec>  // b.none
    aef4:	7100045f 	cmp	w2, #0x1
    aef8:	540001a1 	b.ne	af2c <f0+0x6dc>  // b.any
    aefc:	29430002 	ldp	w2, w0, [x0, #24]
    af00:	92403c21 	and	x1, x1, #0xffff
    af04:	9b027c21 	mul	x1, x1, x2
    af08:	d360fc21 	lsr	x1, x1, #32
    af0c:	eb00003f 	cmp	x1, x0
    af10:	540000e2 	b.cs	af2c <f0+0x6dc>  // b.hs, b.nlast
    af14:	8b0102f7 	add	x23, x23, x1
    af18:	394002e0 	ldrb	w0, [x23]
    af1c:	7103fc1f 	cmp	w0, #0xff
    af20:	5400f040 	b.eq	cd28 <f0+0x24d8>  // b.none
    af24:	52800020 	mov	w0, #0x1                   	// #1
    af28:	390002e0 	strb	w0, [x23]
    af2c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af30:	910b63e1 	add	x1, sp, #0x2d8
    af34:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f9016fe2 	str	x2, [sp, #728]
    af40:	f90173f5 	str	x21, [sp, #736]
    af44:	97ffeae0 	bl	5ac4 <fwp_data.part.0.constprop.0>
    af48:	91174283 	add	x3, x20, #0x5d0
    af4c:	aa0003f5 	mov	x21, x0
    af50:	f949d861 	ldr	x1, [x3, #5040]
    af54:	f949ec60 	ldr	x0, [x3, #5080]
    af58:	cb0102a1 	sub	x1, x21, x1
    af5c:	eb00403f 	cmp	x1, x0, lsl #16
    af60:	54000322 	b.cs	afc4 <f0+0x774>  // b.hs, b.nlast
    af64:	d350fc22 	lsr	x2, x1, #16
    af68:	f949fc63 	ldr	x3, [x3, #5112]
    af6c:	8b020842 	add	x2, x2, x2, lsl #2
    af70:	d37df042 	lsl	x2, x2, #3
    af74:	8b020060 	add	x0, x3, x2
    af78:	f9401017 	ldr	x23, [x0, #32]
    af7c:	b4000257 	cbz	x23, afc4 <f0+0x774>
    af80:	38626862 	ldrb	w2, [x3, x2]
    af84:	7100085f 	cmp	w2, #0x2
    af88:	5400dec0 	b.eq	cb60 <f0+0x2310>  // b.none
    af8c:	7100045f 	cmp	w2, #0x1
    af90:	540001a1 	b.ne	afc4 <f0+0x774>  // b.any
    af94:	29430002 	ldp	w2, w0, [x0, #24]
    af98:	92403c21 	and	x1, x1, #0xffff
    af9c:	9b027c21 	mul	x1, x1, x2
    afa0:	d360fc21 	lsr	x1, x1, #32
    afa4:	eb00003f 	cmp	x1, x0
    afa8:	540000e2 	b.cs	afc4 <f0+0x774>  // b.hs, b.nlast
    afac:	8b0102f7 	add	x23, x23, x1
    afb0:	394002e0 	ldrb	w0, [x23]
    afb4:	7103fc1f 	cmp	w0, #0xff
    afb8:	5400ebe0 	b.eq	cd34 <f0+0x24e4>  // b.none
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	390002e0 	strb	w0, [x23]
    afc4:	910ba3e1 	add	x1, sp, #0x2e8
    afc8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f90177f7 	str	x23, [sp, #744]
    afd4:	f9017bf5 	str	x21, [sp, #752]
    afd8:	97ffeabb 	bl	5ac4 <fwp_data.part.0.constprop.0>
    afdc:	97ffeb26 	bl	5c74 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	910be3e1 	add	x1, sp, #0x2f8
    afe8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    afec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f9017ff5 	str	x21, [sp, #760]
    aff8:	f90183e2 	str	x2, [sp, #768]
    affc:	97ffeab2 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b000:	97ffeb1d 	bl	5c74 <fwp_rc_fresh>
    b004:	aa0003e2 	mov	x2, x0
    b008:	910c23e1 	add	x1, sp, #0x308
    b00c:	52800020 	mov	w0, #0x1                   	// #1
    b010:	f90187f7 	str	x23, [sp, #776]
    b014:	f9018be2 	str	x2, [sp, #784]
    b018:	97ffeaab 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b01c:	97ffeb16 	bl	5c74 <fwp_rc_fresh>
    b020:	aa0003e2 	mov	x2, x0
    b024:	910c63e1 	add	x1, sp, #0x318
    b028:	52800020 	mov	w0, #0x1                   	// #1
    b02c:	f9018ff5 	str	x21, [sp, #792]
    b030:	f90193e2 	str	x2, [sp, #800]
    b034:	97ffeaa4 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b038:	91174283 	add	x3, x20, #0x5d0
    b03c:	aa0003f5 	mov	x21, x0
    b040:	f949d861 	ldr	x1, [x3, #5040]
    b044:	f949ec60 	ldr	x0, [x3, #5080]
    b048:	cb0102a1 	sub	x1, x21, x1
    b04c:	eb00403f 	cmp	x1, x0, lsl #16
    b050:	54000322 	b.cs	b0b4 <f0+0x864>  // b.hs, b.nlast
    b054:	d350fc22 	lsr	x2, x1, #16
    b058:	f949fc63 	ldr	x3, [x3, #5112]
    b05c:	8b020842 	add	x2, x2, x2, lsl #2
    b060:	d37df042 	lsl	x2, x2, #3
    b064:	8b020060 	add	x0, x3, x2
    b068:	f9401017 	ldr	x23, [x0, #32]
    b06c:	b4000257 	cbz	x23, b0b4 <f0+0x864>
    b070:	38626862 	ldrb	w2, [x3, x2]
    b074:	7100085f 	cmp	w2, #0x2
    b078:	5400d6e0 	b.eq	cb54 <f0+0x2304>  // b.none
    b07c:	7100045f 	cmp	w2, #0x1
    b080:	540001a1 	b.ne	b0b4 <f0+0x864>  // b.any
    b084:	29430002 	ldp	w2, w0, [x0, #24]
    b088:	92403c21 	and	x1, x1, #0xffff
    b08c:	9b027c21 	mul	x1, x1, x2
    b090:	d360fc21 	lsr	x1, x1, #32
    b094:	eb00003f 	cmp	x1, x0
    b098:	540000e2 	b.cs	b0b4 <f0+0x864>  // b.hs, b.nlast
    b09c:	8b0102f7 	add	x23, x23, x1
    b0a0:	394002e0 	ldrb	w0, [x23]
    b0a4:	7103fc1f 	cmp	w0, #0xff
    b0a8:	5400e4c0 	b.eq	cd40 <f0+0x24f0>  // b.none
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	390002e0 	strb	w0, [x23]
    b0b4:	910ca3e1 	add	x1, sp, #0x328
    b0b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b0bc:	52800020 	mov	w0, #0x1                   	// #1
    b0c0:	f90197f7 	str	x23, [sp, #808]
    b0c4:	f9019bf5 	str	x21, [sp, #816]
    b0c8:	97ffea7f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b0cc:	97ffeaea 	bl	5c74 <fwp_rc_fresh>
    b0d0:	aa0003e2 	mov	x2, x0
    b0d4:	910ce3e1 	add	x1, sp, #0x338
    b0d8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b0dc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	f9019ff5 	str	x21, [sp, #824]
    b0e8:	f901a3e2 	str	x2, [sp, #832]
    b0ec:	97ffea76 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b0f0:	97ffeae1 	bl	5c74 <fwp_rc_fresh>
    b0f4:	aa0003e2 	mov	x2, x0
    b0f8:	910d23e1 	add	x1, sp, #0x348
    b0fc:	52800020 	mov	w0, #0x1                   	// #1
    b100:	f901a7f7 	str	x23, [sp, #840]
    b104:	f901abe2 	str	x2, [sp, #848]
    b108:	97ffea6f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b10c:	97ffeada 	bl	5c74 <fwp_rc_fresh>
    b110:	aa0003e2 	mov	x2, x0
    b114:	910d63e1 	add	x1, sp, #0x358
    b118:	52800020 	mov	w0, #0x1                   	// #1
    b11c:	f901aff5 	str	x21, [sp, #856]
    b120:	f901b3e2 	str	x2, [sp, #864]
    b124:	97ffea68 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b128:	97ffead3 	bl	5c74 <fwp_rc_fresh>
    b12c:	aa0003e2 	mov	x2, x0
    b130:	910da3e1 	add	x1, sp, #0x368
    b134:	52800020 	mov	w0, #0x1                   	// #1
    b138:	f901b7f7 	str	x23, [sp, #872]
    b13c:	f901bbe2 	str	x2, [sp, #880]
    b140:	97ffea61 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b144:	97ffeacc 	bl	5c74 <fwp_rc_fresh>
    b148:	aa0003e2 	mov	x2, x0
    b14c:	910de3e1 	add	x1, sp, #0x378
    b150:	52800020 	mov	w0, #0x1                   	// #1
    b154:	f901bff5 	str	x21, [sp, #888]
    b158:	f901c3e2 	str	x2, [sp, #896]
    b15c:	97ffea5a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b160:	97ffeac5 	bl	5c74 <fwp_rc_fresh>
    b164:	aa0003e2 	mov	x2, x0
    b168:	910e23e1 	add	x1, sp, #0x388
    b16c:	52800020 	mov	w0, #0x1                   	// #1
    b170:	f901c7f7 	str	x23, [sp, #904]
    b174:	f901cbe2 	str	x2, [sp, #912]
    b178:	97ffea53 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b17c:	97ffeabe 	bl	5c74 <fwp_rc_fresh>
    b180:	aa0003e2 	mov	x2, x0
    b184:	910e63e1 	add	x1, sp, #0x398
    b188:	52800020 	mov	w0, #0x1                   	// #1
    b18c:	f901cff5 	str	x21, [sp, #920]
    b190:	f901d3e2 	str	x2, [sp, #928]
    b194:	97ffea4c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b198:	91174283 	add	x3, x20, #0x5d0
    b19c:	aa0003f5 	mov	x21, x0
    b1a0:	f949d861 	ldr	x1, [x3, #5040]
    b1a4:	f949ec60 	ldr	x0, [x3, #5080]
    b1a8:	cb0102a1 	sub	x1, x21, x1
    b1ac:	eb00403f 	cmp	x1, x0, lsl #16
    b1b0:	54000322 	b.cs	b214 <f0+0x9c4>  // b.hs, b.nlast
    b1b4:	d350fc22 	lsr	x2, x1, #16
    b1b8:	f949fc63 	ldr	x3, [x3, #5112]
    b1bc:	8b020842 	add	x2, x2, x2, lsl #2
    b1c0:	d37df042 	lsl	x2, x2, #3
    b1c4:	8b020060 	add	x0, x3, x2
    b1c8:	f9401017 	ldr	x23, [x0, #32]
    b1cc:	b4000257 	cbz	x23, b214 <f0+0x9c4>
    b1d0:	38626862 	ldrb	w2, [x3, x2]
    b1d4:	7100085f 	cmp	w2, #0x2
    b1d8:	5400cd00 	b.eq	cb78 <f0+0x2328>  // b.none
    b1dc:	7100045f 	cmp	w2, #0x1
    b1e0:	540001a1 	b.ne	b214 <f0+0x9c4>  // b.any
    b1e4:	29430002 	ldp	w2, w0, [x0, #24]
    b1e8:	92403c21 	and	x1, x1, #0xffff
    b1ec:	9b027c21 	mul	x1, x1, x2
    b1f0:	d360fc21 	lsr	x1, x1, #32
    b1f4:	eb00003f 	cmp	x1, x0
    b1f8:	540000e2 	b.cs	b214 <f0+0x9c4>  // b.hs, b.nlast
    b1fc:	8b0102f7 	add	x23, x23, x1
    b200:	394002e0 	ldrb	w0, [x23]
    b204:	7103fc1f 	cmp	w0, #0xff
    b208:	5400da20 	b.eq	cd4c <f0+0x24fc>  // b.none
    b20c:	52800020 	mov	w0, #0x1                   	// #1
    b210:	390002e0 	strb	w0, [x23]
    b214:	910ea3e1 	add	x1, sp, #0x3a8
    b218:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b21c:	52800020 	mov	w0, #0x1                   	// #1
    b220:	f901d7e2 	str	x2, [sp, #936]
    b224:	f901dbf5 	str	x21, [sp, #944]
    b228:	97ffea27 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b22c:	97ffea92 	bl	5c74 <fwp_rc_fresh>
    b230:	aa0003e2 	mov	x2, x0
    b234:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b238:	910ee3e1 	add	x1, sp, #0x3b8
    b23c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b240:	52800020 	mov	w0, #0x1                   	// #1
    b244:	f901dfe3 	str	x3, [sp, #952]
    b248:	f901e3e2 	str	x2, [sp, #960]
    b24c:	97ffea1e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b250:	91174283 	add	x3, x20, #0x5d0
    b254:	aa0003f5 	mov	x21, x0
    b258:	f949d861 	ldr	x1, [x3, #5040]
    b25c:	f949ec60 	ldr	x0, [x3, #5080]
    b260:	cb0102a1 	sub	x1, x21, x1
    b264:	eb00403f 	cmp	x1, x0, lsl #16
    b268:	54000322 	b.cs	b2cc <f0+0xa7c>  // b.hs, b.nlast
    b26c:	d350fc22 	lsr	x2, x1, #16
    b270:	f949fc63 	ldr	x3, [x3, #5112]
    b274:	8b020842 	add	x2, x2, x2, lsl #2
    b278:	d37df042 	lsl	x2, x2, #3
    b27c:	8b020060 	add	x0, x3, x2
    b280:	f9401017 	ldr	x23, [x0, #32]
    b284:	b4000257 	cbz	x23, b2cc <f0+0xa7c>
    b288:	38626862 	ldrb	w2, [x3, x2]
    b28c:	7100085f 	cmp	w2, #0x2
    b290:	5400c6e0 	b.eq	cb6c <f0+0x231c>  // b.none
    b294:	7100045f 	cmp	w2, #0x1
    b298:	540001a1 	b.ne	b2cc <f0+0xa7c>  // b.any
    b29c:	29430002 	ldp	w2, w0, [x0, #24]
    b2a0:	92403c21 	and	x1, x1, #0xffff
    b2a4:	9b027c21 	mul	x1, x1, x2
    b2a8:	d360fc21 	lsr	x1, x1, #32
    b2ac:	eb00003f 	cmp	x1, x0
    b2b0:	540000e2 	b.cs	b2cc <f0+0xa7c>  // b.hs, b.nlast
    b2b4:	8b0102f7 	add	x23, x23, x1
    b2b8:	394002e0 	ldrb	w0, [x23]
    b2bc:	7103fc1f 	cmp	w0, #0xff
    b2c0:	5400d4c0 	b.eq	cd58 <f0+0x2508>  // b.none
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	390002e0 	strb	w0, [x23]
    b2cc:	910f23e1 	add	x1, sp, #0x3c8
    b2d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2d4:	52800020 	mov	w0, #0x1                   	// #1
    b2d8:	f901e7e2 	str	x2, [sp, #968]
    b2dc:	f901ebf5 	str	x21, [sp, #976]
    b2e0:	97ffe9f9 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b2e4:	97ffea64 	bl	5c74 <fwp_rc_fresh>
    b2e8:	aa0003e2 	mov	x2, x0
    b2ec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b2f0:	910f63e1 	add	x1, sp, #0x3d8
    b2f4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b2f8:	52800020 	mov	w0, #0x1                   	// #1
    b2fc:	f901efe3 	str	x3, [sp, #984]
    b300:	f901f3e2 	str	x2, [sp, #992]
    b304:	97ffe9f0 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b308:	91174283 	add	x3, x20, #0x5d0
    b30c:	aa0003f5 	mov	x21, x0
    b310:	f949d861 	ldr	x1, [x3, #5040]
    b314:	f949ec60 	ldr	x0, [x3, #5080]
    b318:	cb0102a1 	sub	x1, x21, x1
    b31c:	eb00403f 	cmp	x1, x0, lsl #16
    b320:	54000322 	b.cs	b384 <f0+0xb34>  // b.hs, b.nlast
    b324:	d350fc22 	lsr	x2, x1, #16
    b328:	f949fc63 	ldr	x3, [x3, #5112]
    b32c:	8b020842 	add	x2, x2, x2, lsl #2
    b330:	d37df042 	lsl	x2, x2, #3
    b334:	8b020060 	add	x0, x3, x2
    b338:	f9401017 	ldr	x23, [x0, #32]
    b33c:	b4000257 	cbz	x23, b384 <f0+0xb34>
    b340:	38626862 	ldrb	w2, [x3, x2]
    b344:	7100085f 	cmp	w2, #0x2
    b348:	5400c840 	b.eq	cc50 <f0+0x2400>  // b.none
    b34c:	7100045f 	cmp	w2, #0x1
    b350:	540001a1 	b.ne	b384 <f0+0xb34>  // b.any
    b354:	29430002 	ldp	w2, w0, [x0, #24]
    b358:	92403c21 	and	x1, x1, #0xffff
    b35c:	9b027c21 	mul	x1, x1, x2
    b360:	d360fc21 	lsr	x1, x1, #32
    b364:	eb00003f 	cmp	x1, x0
    b368:	540000e2 	b.cs	b384 <f0+0xb34>  // b.hs, b.nlast
    b36c:	8b0102f7 	add	x23, x23, x1
    b370:	394002e0 	ldrb	w0, [x23]
    b374:	7103fc1f 	cmp	w0, #0xff
    b378:	5400cf60 	b.eq	cd64 <f0+0x2514>  // b.none
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	390002e0 	strb	w0, [x23]
    b384:	910fa3e1 	add	x1, sp, #0x3e8
    b388:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b38c:	52800020 	mov	w0, #0x1                   	// #1
    b390:	f901f7e2 	str	x2, [sp, #1000]
    b394:	f901fbf5 	str	x21, [sp, #1008]
    b398:	97ffe9cb 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b39c:	97ffea36 	bl	5c74 <fwp_rc_fresh>
    b3a0:	aa0003e2 	mov	x2, x0
    b3a4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b3a8:	910fe3e1 	add	x1, sp, #0x3f8
    b3ac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b3b0:	52800020 	mov	w0, #0x1                   	// #1
    b3b4:	f901ffe3 	str	x3, [sp, #1016]
    b3b8:	f90203e2 	str	x2, [sp, #1024]
    b3bc:	97ffe9c2 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b3c0:	91174283 	add	x3, x20, #0x5d0
    b3c4:	aa0003f7 	mov	x23, x0
    b3c8:	f949d861 	ldr	x1, [x3, #5040]
    b3cc:	f949ec60 	ldr	x0, [x3, #5080]
    b3d0:	cb0102e1 	sub	x1, x23, x1
    b3d4:	eb00403f 	cmp	x1, x0, lsl #16
    b3d8:	54000322 	b.cs	b43c <f0+0xbec>  // b.hs, b.nlast
    b3dc:	d350fc22 	lsr	x2, x1, #16
    b3e0:	f949fc63 	ldr	x3, [x3, #5112]
    b3e4:	8b020842 	add	x2, x2, x2, lsl #2
    b3e8:	d37df042 	lsl	x2, x2, #3
    b3ec:	8b020060 	add	x0, x3, x2
    b3f0:	f9401015 	ldr	x21, [x0, #32]
    b3f4:	b4000255 	cbz	x21, b43c <f0+0xbec>
    b3f8:	38626862 	ldrb	w2, [x3, x2]
    b3fc:	7100085f 	cmp	w2, #0x2
    b400:	5400c220 	b.eq	cc44 <f0+0x23f4>  // b.none
    b404:	7100045f 	cmp	w2, #0x1
    b408:	540001a1 	b.ne	b43c <f0+0xbec>  // b.any
    b40c:	29430002 	ldp	w2, w0, [x0, #24]
    b410:	92403c21 	and	x1, x1, #0xffff
    b414:	9b027c21 	mul	x1, x1, x2
    b418:	d360fc21 	lsr	x1, x1, #32
    b41c:	eb00003f 	cmp	x1, x0
    b420:	540000e2 	b.cs	b43c <f0+0xbec>  // b.hs, b.nlast
    b424:	8b0102b5 	add	x21, x21, x1
    b428:	394002a0 	ldrb	w0, [x21]
    b42c:	7103fc1f 	cmp	w0, #0xff
    b430:	5400ca00 	b.eq	cd70 <f0+0x2520>  // b.none
    b434:	52800020 	mov	w0, #0x1                   	// #1
    b438:	390002a0 	strb	w0, [x21]
    b43c:	911023e1 	add	x1, sp, #0x408
    b440:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	f90207f5 	str	x21, [sp, #1032]
    b44c:	f9020bf7 	str	x23, [sp, #1040]
    b450:	97ffe99d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b454:	97ffea08 	bl	5c74 <fwp_rc_fresh>
    b458:	aa0003e2 	mov	x2, x0
    b45c:	911063e1 	add	x1, sp, #0x418
    b460:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b464:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b468:	52800020 	mov	w0, #0x1                   	// #1
    b46c:	f9020ff7 	str	x23, [sp, #1048]
    b470:	f90213e2 	str	x2, [sp, #1056]
    b474:	97ffe994 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b478:	97ffe9ff 	bl	5c74 <fwp_rc_fresh>
    b47c:	aa0003e2 	mov	x2, x0
    b480:	9110a3e1 	add	x1, sp, #0x428
    b484:	52800020 	mov	w0, #0x1                   	// #1
    b488:	f90217f5 	str	x21, [sp, #1064]
    b48c:	f9021be2 	str	x2, [sp, #1072]
    b490:	97ffe98d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b494:	97ffe9f8 	bl	5c74 <fwp_rc_fresh>
    b498:	aa0003e2 	mov	x2, x0
    b49c:	9110e3e1 	add	x1, sp, #0x438
    b4a0:	52800020 	mov	w0, #0x1                   	// #1
    b4a4:	f9021ff7 	str	x23, [sp, #1080]
    b4a8:	f90223e2 	str	x2, [sp, #1088]
    b4ac:	97ffe986 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b4b0:	97ffe9f1 	bl	5c74 <fwp_rc_fresh>
    b4b4:	aa0003e2 	mov	x2, x0
    b4b8:	911123e1 	add	x1, sp, #0x448
    b4bc:	52800020 	mov	w0, #0x1                   	// #1
    b4c0:	f90227f5 	str	x21, [sp, #1096]
    b4c4:	f9022be2 	str	x2, [sp, #1104]
    b4c8:	97ffe97f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b4cc:	97ffe9ea 	bl	5c74 <fwp_rc_fresh>
    b4d0:	aa0003e2 	mov	x2, x0
    b4d4:	911163e1 	add	x1, sp, #0x458
    b4d8:	52800020 	mov	w0, #0x1                   	// #1
    b4dc:	f9022ff7 	str	x23, [sp, #1112]
    b4e0:	f90233e2 	str	x2, [sp, #1120]
    b4e4:	97ffe978 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b4e8:	97ffe9e3 	bl	5c74 <fwp_rc_fresh>
    b4ec:	aa0003e2 	mov	x2, x0
    b4f0:	9111a3e1 	add	x1, sp, #0x468
    b4f4:	52800020 	mov	w0, #0x1                   	// #1
    b4f8:	f90237f5 	str	x21, [sp, #1128]
    b4fc:	f9023be2 	str	x2, [sp, #1136]
    b500:	97ffe971 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b504:	91174283 	add	x3, x20, #0x5d0
    b508:	aa0003f5 	mov	x21, x0
    b50c:	f949d861 	ldr	x1, [x3, #5040]
    b510:	f949ec60 	ldr	x0, [x3, #5080]
    b514:	cb0102a1 	sub	x1, x21, x1
    b518:	eb00403f 	cmp	x1, x0, lsl #16
    b51c:	54000322 	b.cs	b580 <f0+0xd30>  // b.hs, b.nlast
    b520:	d350fc22 	lsr	x2, x1, #16
    b524:	f949fc63 	ldr	x3, [x3, #5112]
    b528:	8b020842 	add	x2, x2, x2, lsl #2
    b52c:	d37df042 	lsl	x2, x2, #3
    b530:	8b020060 	add	x0, x3, x2
    b534:	f9401017 	ldr	x23, [x0, #32]
    b538:	b4000257 	cbz	x23, b580 <f0+0xd30>
    b53c:	38626862 	ldrb	w2, [x3, x2]
    b540:	7100085f 	cmp	w2, #0x2
    b544:	5400b920 	b.eq	cc68 <f0+0x2418>  // b.none
    b548:	7100045f 	cmp	w2, #0x1
    b54c:	540001a1 	b.ne	b580 <f0+0xd30>  // b.any
    b550:	29430002 	ldp	w2, w0, [x0, #24]
    b554:	92403c21 	and	x1, x1, #0xffff
    b558:	9b027c21 	mul	x1, x1, x2
    b55c:	d360fc21 	lsr	x1, x1, #32
    b560:	eb00003f 	cmp	x1, x0
    b564:	540000e2 	b.cs	b580 <f0+0xd30>  // b.hs, b.nlast
    b568:	8b0102f7 	add	x23, x23, x1
    b56c:	394002e0 	ldrb	w0, [x23]
    b570:	7103fc1f 	cmp	w0, #0xff
    b574:	5400c040 	b.eq	cd7c <f0+0x252c>  // b.none
    b578:	52800020 	mov	w0, #0x1                   	// #1
    b57c:	390002e0 	strb	w0, [x23]
    b580:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b584:	9111e3e1 	add	x1, sp, #0x478
    b588:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b58c:	52800020 	mov	w0, #0x1                   	// #1
    b590:	f9023fe2 	str	x2, [sp, #1144]
    b594:	f90243f5 	str	x21, [sp, #1152]
    b598:	97ffe94b 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b59c:	91174283 	add	x3, x20, #0x5d0
    b5a0:	aa0003f5 	mov	x21, x0
    b5a4:	f949d861 	ldr	x1, [x3, #5040]
    b5a8:	f949ec60 	ldr	x0, [x3, #5080]
    b5ac:	cb0102a1 	sub	x1, x21, x1
    b5b0:	eb00403f 	cmp	x1, x0, lsl #16
    b5b4:	54000322 	b.cs	b618 <f0+0xdc8>  // b.hs, b.nlast
    b5b8:	d350fc22 	lsr	x2, x1, #16
    b5bc:	f949fc63 	ldr	x3, [x3, #5112]
    b5c0:	8b020842 	add	x2, x2, x2, lsl #2
    b5c4:	d37df042 	lsl	x2, x2, #3
    b5c8:	8b020060 	add	x0, x3, x2
    b5cc:	f9401017 	ldr	x23, [x0, #32]
    b5d0:	b4000257 	cbz	x23, b618 <f0+0xdc8>
    b5d4:	38626862 	ldrb	w2, [x3, x2]
    b5d8:	7100085f 	cmp	w2, #0x2
    b5dc:	5400b400 	b.eq	cc5c <f0+0x240c>  // b.none
    b5e0:	7100045f 	cmp	w2, #0x1
    b5e4:	540001a1 	b.ne	b618 <f0+0xdc8>  // b.any
    b5e8:	29430002 	ldp	w2, w0, [x0, #24]
    b5ec:	92403c21 	and	x1, x1, #0xffff
    b5f0:	9b027c21 	mul	x1, x1, x2
    b5f4:	d360fc21 	lsr	x1, x1, #32
    b5f8:	eb00003f 	cmp	x1, x0
    b5fc:	540000e2 	b.cs	b618 <f0+0xdc8>  // b.hs, b.nlast
    b600:	8b0102f7 	add	x23, x23, x1
    b604:	394002e0 	ldrb	w0, [x23]
    b608:	7103fc1f 	cmp	w0, #0xff
    b60c:	5400bbe0 	b.eq	cd88 <f0+0x2538>  // b.none
    b610:	52800020 	mov	w0, #0x1                   	// #1
    b614:	390002e0 	strb	w0, [x23]
    b618:	911223e1 	add	x1, sp, #0x488
    b61c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b620:	52800020 	mov	w0, #0x1                   	// #1
    b624:	f90247e2 	str	x2, [sp, #1160]
    b628:	f9024bf5 	str	x21, [sp, #1168]
    b62c:	97ffe926 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b630:	97ffe991 	bl	5c74 <fwp_rc_fresh>
    b634:	aa0003e2 	mov	x2, x0
    b638:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b63c:	911263e1 	add	x1, sp, #0x498
    b640:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b644:	52800020 	mov	w0, #0x1                   	// #1
    b648:	f9024fe3 	str	x3, [sp, #1176]
    b64c:	f90253e2 	str	x2, [sp, #1184]
    b650:	97ffe91d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b654:	91174283 	add	x3, x20, #0x5d0
    b658:	aa0003f5 	mov	x21, x0
    b65c:	f949d861 	ldr	x1, [x3, #5040]
    b660:	f949ec60 	ldr	x0, [x3, #5080]
    b664:	cb0102a1 	sub	x1, x21, x1
    b668:	eb00403f 	cmp	x1, x0, lsl #16
    b66c:	54000322 	b.cs	b6d0 <f0+0xe80>  // b.hs, b.nlast
    b670:	d350fc22 	lsr	x2, x1, #16
    b674:	f949fc63 	ldr	x3, [x3, #5112]
    b678:	8b020842 	add	x2, x2, x2, lsl #2
    b67c:	d37df042 	lsl	x2, x2, #3
    b680:	8b020060 	add	x0, x3, x2
    b684:	f9401017 	ldr	x23, [x0, #32]
    b688:	b4000257 	cbz	x23, b6d0 <f0+0xe80>
    b68c:	38626862 	ldrb	w2, [x3, x2]
    b690:	7100085f 	cmp	w2, #0x2
    b694:	5400af60 	b.eq	cc80 <f0+0x2430>  // b.none
    b698:	7100045f 	cmp	w2, #0x1
    b69c:	540001a1 	b.ne	b6d0 <f0+0xe80>  // b.any
    b6a0:	29430002 	ldp	w2, w0, [x0, #24]
    b6a4:	92403c21 	and	x1, x1, #0xffff
    b6a8:	9b027c21 	mul	x1, x1, x2
    b6ac:	d360fc21 	lsr	x1, x1, #32
    b6b0:	eb00003f 	cmp	x1, x0
    b6b4:	540000e2 	b.cs	b6d0 <f0+0xe80>  // b.hs, b.nlast
    b6b8:	8b0102f7 	add	x23, x23, x1
    b6bc:	394002e0 	ldrb	w0, [x23]
    b6c0:	7103fc1f 	cmp	w0, #0xff
    b6c4:	5400b680 	b.eq	cd94 <f0+0x2544>  // b.none
    b6c8:	52800020 	mov	w0, #0x1                   	// #1
    b6cc:	390002e0 	strb	w0, [x23]
    b6d0:	9112a3e1 	add	x1, sp, #0x4a8
    b6d4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6d8:	52800020 	mov	w0, #0x1                   	// #1
    b6dc:	f90257e2 	str	x2, [sp, #1192]
    b6e0:	f9025bf5 	str	x21, [sp, #1200]
    b6e4:	97ffe8f8 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b6e8:	97ffe963 	bl	5c74 <fwp_rc_fresh>
    b6ec:	aa0003e2 	mov	x2, x0
    b6f0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b6f4:	9112e3e1 	add	x1, sp, #0x4b8
    b6f8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b6fc:	52800020 	mov	w0, #0x1                   	// #1
    b700:	f9025fe3 	str	x3, [sp, #1208]
    b704:	f90263e2 	str	x2, [sp, #1216]
    b708:	97ffe8ef 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b70c:	91174283 	add	x3, x20, #0x5d0
    b710:	aa0003f5 	mov	x21, x0
    b714:	f949d861 	ldr	x1, [x3, #5040]
    b718:	f949ec60 	ldr	x0, [x3, #5080]
    b71c:	cb0102a1 	sub	x1, x21, x1
    b720:	eb00403f 	cmp	x1, x0, lsl #16
    b724:	54000322 	b.cs	b788 <f0+0xf38>  // b.hs, b.nlast
    b728:	d350fc22 	lsr	x2, x1, #16
    b72c:	f949fc63 	ldr	x3, [x3, #5112]
    b730:	8b020842 	add	x2, x2, x2, lsl #2
    b734:	d37df042 	lsl	x2, x2, #3
    b738:	8b020060 	add	x0, x3, x2
    b73c:	f9401017 	ldr	x23, [x0, #32]
    b740:	b4000257 	cbz	x23, b788 <f0+0xf38>
    b744:	38626862 	ldrb	w2, [x3, x2]
    b748:	7100085f 	cmp	w2, #0x2
    b74c:	5400a940 	b.eq	cc74 <f0+0x2424>  // b.none
    b750:	7100045f 	cmp	w2, #0x1
    b754:	540001a1 	b.ne	b788 <f0+0xf38>  // b.any
    b758:	29430002 	ldp	w2, w0, [x0, #24]
    b75c:	92403c21 	and	x1, x1, #0xffff
    b760:	9b027c21 	mul	x1, x1, x2
    b764:	d360fc21 	lsr	x1, x1, #32
    b768:	eb00003f 	cmp	x1, x0
    b76c:	540000e2 	b.cs	b788 <f0+0xf38>  // b.hs, b.nlast
    b770:	8b0102f7 	add	x23, x23, x1
    b774:	394002e0 	ldrb	w0, [x23]
    b778:	7103fc1f 	cmp	w0, #0xff
    b77c:	5400b120 	b.eq	cda0 <f0+0x2550>  // b.none
    b780:	52800020 	mov	w0, #0x1                   	// #1
    b784:	390002e0 	strb	w0, [x23]
    b788:	911323e1 	add	x1, sp, #0x4c8
    b78c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	f90267f7 	str	x23, [sp, #1224]
    b798:	f9026bf5 	str	x21, [sp, #1232]
    b79c:	97ffe8ca 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b7a0:	97ffe935 	bl	5c74 <fwp_rc_fresh>
    b7a4:	aa0003e2 	mov	x2, x0
    b7a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b7ac:	911363e1 	add	x1, sp, #0x4d8
    b7b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	f9026fe3 	str	x3, [sp, #1240]
    b7bc:	f90273e2 	str	x2, [sp, #1248]
    b7c0:	97ffe8c1 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b7c4:	97ffe92c 	bl	5c74 <fwp_rc_fresh>
    b7c8:	aa0003e2 	mov	x2, x0
    b7cc:	9113a3e1 	add	x1, sp, #0x4e8
    b7d0:	52800020 	mov	w0, #0x1                   	// #1
    b7d4:	f90277f7 	str	x23, [sp, #1256]
    b7d8:	f9027be2 	str	x2, [sp, #1264]
    b7dc:	97ffe8ba 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b7e0:	91174283 	add	x3, x20, #0x5d0
    b7e4:	aa0003f5 	mov	x21, x0
    b7e8:	f949d861 	ldr	x1, [x3, #5040]
    b7ec:	f949ec60 	ldr	x0, [x3, #5080]
    b7f0:	cb0102a1 	sub	x1, x21, x1
    b7f4:	eb00403f 	cmp	x1, x0, lsl #16
    b7f8:	54000322 	b.cs	b85c <f0+0x100c>  // b.hs, b.nlast
    b7fc:	d350fc22 	lsr	x2, x1, #16
    b800:	f949fc63 	ldr	x3, [x3, #5112]
    b804:	8b020842 	add	x2, x2, x2, lsl #2
    b808:	d37df042 	lsl	x2, x2, #3
    b80c:	8b020060 	add	x0, x3, x2
    b810:	f9401017 	ldr	x23, [x0, #32]
    b814:	b4000257 	cbz	x23, b85c <f0+0x100c>
    b818:	38626862 	ldrb	w2, [x3, x2]
    b81c:	7100085f 	cmp	w2, #0x2
    b820:	5400a3c0 	b.eq	cc98 <f0+0x2448>  // b.none
    b824:	7100045f 	cmp	w2, #0x1
    b828:	540001a1 	b.ne	b85c <f0+0x100c>  // b.any
    b82c:	29430002 	ldp	w2, w0, [x0, #24]
    b830:	92403c21 	and	x1, x1, #0xffff
    b834:	9b027c21 	mul	x1, x1, x2
    b838:	d360fc21 	lsr	x1, x1, #32
    b83c:	eb00003f 	cmp	x1, x0
    b840:	540000e2 	b.cs	b85c <f0+0x100c>  // b.hs, b.nlast
    b844:	8b0102f7 	add	x23, x23, x1
    b848:	394002e0 	ldrb	w0, [x23]
    b84c:	7103fc1f 	cmp	w0, #0xff
    b850:	5400aae0 	b.eq	cdac <f0+0x255c>  // b.none
    b854:	52800020 	mov	w0, #0x1                   	// #1
    b858:	390002e0 	strb	w0, [x23]
    b85c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b860:	9113e3e1 	add	x1, sp, #0x4f8
    b864:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b868:	52800020 	mov	w0, #0x1                   	// #1
    b86c:	f9027fe2 	str	x2, [sp, #1272]
    b870:	f90283f5 	str	x21, [sp, #1280]
    b874:	97ffe894 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b878:	91174283 	add	x3, x20, #0x5d0
    b87c:	aa0003f5 	mov	x21, x0
    b880:	f949d861 	ldr	x1, [x3, #5040]
    b884:	f949ec60 	ldr	x0, [x3, #5080]
    b888:	cb0102a1 	sub	x1, x21, x1
    b88c:	eb00403f 	cmp	x1, x0, lsl #16
    b890:	54000322 	b.cs	b8f4 <f0+0x10a4>  // b.hs, b.nlast
    b894:	d350fc22 	lsr	x2, x1, #16
    b898:	f949fc63 	ldr	x3, [x3, #5112]
    b89c:	8b020842 	add	x2, x2, x2, lsl #2
    b8a0:	d37df042 	lsl	x2, x2, #3
    b8a4:	8b020060 	add	x0, x3, x2
    b8a8:	f9401017 	ldr	x23, [x0, #32]
    b8ac:	b4000257 	cbz	x23, b8f4 <f0+0x10a4>
    b8b0:	38626862 	ldrb	w2, [x3, x2]
    b8b4:	7100085f 	cmp	w2, #0x2
    b8b8:	54009ea0 	b.eq	cc8c <f0+0x243c>  // b.none
    b8bc:	7100045f 	cmp	w2, #0x1
    b8c0:	540001a1 	b.ne	b8f4 <f0+0x10a4>  // b.any
    b8c4:	29430002 	ldp	w2, w0, [x0, #24]
    b8c8:	92403c21 	and	x1, x1, #0xffff
    b8cc:	9b027c21 	mul	x1, x1, x2
    b8d0:	d360fc21 	lsr	x1, x1, #32
    b8d4:	eb00003f 	cmp	x1, x0
    b8d8:	540000e2 	b.cs	b8f4 <f0+0x10a4>  // b.hs, b.nlast
    b8dc:	8b0102f7 	add	x23, x23, x1
    b8e0:	394002e0 	ldrb	w0, [x23]
    b8e4:	7103fc1f 	cmp	w0, #0xff
    b8e8:	5400a680 	b.eq	cdb8 <f0+0x2568>  // b.none
    b8ec:	52800020 	mov	w0, #0x1                   	// #1
    b8f0:	390002e0 	strb	w0, [x23]
    b8f4:	911423e1 	add	x1, sp, #0x508
    b8f8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b8fc:	52800020 	mov	w0, #0x1                   	// #1
    b900:	f90287e2 	str	x2, [sp, #1288]
    b904:	f9028bf5 	str	x21, [sp, #1296]
    b908:	97ffe86f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b90c:	97ffe8da 	bl	5c74 <fwp_rc_fresh>
    b910:	aa0003e2 	mov	x2, x0
    b914:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b918:	911463e1 	add	x1, sp, #0x518
    b91c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	f9028fe3 	str	x3, [sp, #1304]
    b928:	f90293e2 	str	x2, [sp, #1312]
    b92c:	97ffe866 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b930:	91174283 	add	x3, x20, #0x5d0
    b934:	aa0003f5 	mov	x21, x0
    b938:	f949d861 	ldr	x1, [x3, #5040]
    b93c:	f949ec60 	ldr	x0, [x3, #5080]
    b940:	cb0102a1 	sub	x1, x21, x1
    b944:	eb00403f 	cmp	x1, x0, lsl #16
    b948:	54000322 	b.cs	b9ac <f0+0x115c>  // b.hs, b.nlast
    b94c:	d350fc22 	lsr	x2, x1, #16
    b950:	f949fc63 	ldr	x3, [x3, #5112]
    b954:	8b020842 	add	x2, x2, x2, lsl #2
    b958:	d37df042 	lsl	x2, x2, #3
    b95c:	8b020060 	add	x0, x3, x2
    b960:	f9401017 	ldr	x23, [x0, #32]
    b964:	b4000257 	cbz	x23, b9ac <f0+0x115c>
    b968:	38626862 	ldrb	w2, [x3, x2]
    b96c:	7100085f 	cmp	w2, #0x2
    b970:	54009a00 	b.eq	ccb0 <f0+0x2460>  // b.none
    b974:	7100045f 	cmp	w2, #0x1
    b978:	540001a1 	b.ne	b9ac <f0+0x115c>  // b.any
    b97c:	29430002 	ldp	w2, w0, [x0, #24]
    b980:	92403c21 	and	x1, x1, #0xffff
    b984:	9b027c21 	mul	x1, x1, x2
    b988:	d360fc21 	lsr	x1, x1, #32
    b98c:	eb00003f 	cmp	x1, x0
    b990:	540000e2 	b.cs	b9ac <f0+0x115c>  // b.hs, b.nlast
    b994:	8b0102f7 	add	x23, x23, x1
    b998:	394002e0 	ldrb	w0, [x23]
    b99c:	7103fc1f 	cmp	w0, #0xff
    b9a0:	5400a120 	b.eq	cdc4 <f0+0x2574>  // b.none
    b9a4:	52800020 	mov	w0, #0x1                   	// #1
    b9a8:	390002e0 	strb	w0, [x23]
    b9ac:	9114a3e1 	add	x1, sp, #0x528
    b9b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b9b4:	52800020 	mov	w0, #0x1                   	// #1
    b9b8:	f90297e2 	str	x2, [sp, #1320]
    b9bc:	f9029bf5 	str	x21, [sp, #1328]
    b9c0:	97ffe841 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b9c4:	97ffe8ac 	bl	5c74 <fwp_rc_fresh>
    b9c8:	aa0003e2 	mov	x2, x0
    b9cc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b9d0:	9114e3e1 	add	x1, sp, #0x538
    b9d4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b9d8:	52800020 	mov	w0, #0x1                   	// #1
    b9dc:	f9029fe3 	str	x3, [sp, #1336]
    b9e0:	f902a3e2 	str	x2, [sp, #1344]
    b9e4:	97ffe838 	bl	5ac4 <fwp_data.part.0.constprop.0>
    b9e8:	91174283 	add	x3, x20, #0x5d0
    b9ec:	aa0003f5 	mov	x21, x0
    b9f0:	f949d861 	ldr	x1, [x3, #5040]
    b9f4:	f949ec60 	ldr	x0, [x3, #5080]
    b9f8:	cb0102a1 	sub	x1, x21, x1
    b9fc:	eb00403f 	cmp	x1, x0, lsl #16
    ba00:	54000322 	b.cs	ba64 <f0+0x1214>  // b.hs, b.nlast
    ba04:	d350fc22 	lsr	x2, x1, #16
    ba08:	f949fc63 	ldr	x3, [x3, #5112]
    ba0c:	8b020842 	add	x2, x2, x2, lsl #2
    ba10:	d37df042 	lsl	x2, x2, #3
    ba14:	8b020060 	add	x0, x3, x2
    ba18:	f9401017 	ldr	x23, [x0, #32]
    ba1c:	b4000257 	cbz	x23, ba64 <f0+0x1214>
    ba20:	38626862 	ldrb	w2, [x3, x2]
    ba24:	7100085f 	cmp	w2, #0x2
    ba28:	540093e0 	b.eq	cca4 <f0+0x2454>  // b.none
    ba2c:	7100045f 	cmp	w2, #0x1
    ba30:	540001a1 	b.ne	ba64 <f0+0x1214>  // b.any
    ba34:	29430002 	ldp	w2, w0, [x0, #24]
    ba38:	92403c21 	and	x1, x1, #0xffff
    ba3c:	9b027c21 	mul	x1, x1, x2
    ba40:	d360fc21 	lsr	x1, x1, #32
    ba44:	eb00003f 	cmp	x1, x0
    ba48:	540000e2 	b.cs	ba64 <f0+0x1214>  // b.hs, b.nlast
    ba4c:	8b0102f7 	add	x23, x23, x1
    ba50:	394002e0 	ldrb	w0, [x23]
    ba54:	7103fc1f 	cmp	w0, #0xff
    ba58:	54009bc0 	b.eq	cdd0 <f0+0x2580>  // b.none
    ba5c:	52800020 	mov	w0, #0x1                   	// #1
    ba60:	390002e0 	strb	w0, [x23]
    ba64:	911523e1 	add	x1, sp, #0x548
    ba68:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba6c:	52800020 	mov	w0, #0x1                   	// #1
    ba70:	f902a7f7 	str	x23, [sp, #1352]
    ba74:	f902abf5 	str	x21, [sp, #1360]
    ba78:	97ffe813 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ba7c:	97ffe87e 	bl	5c74 <fwp_rc_fresh>
    ba80:	aa0003e2 	mov	x2, x0
    ba84:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba88:	911563e1 	add	x1, sp, #0x558
    ba8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba90:	52800020 	mov	w0, #0x1                   	// #1
    ba94:	f902afe3 	str	x3, [sp, #1368]
    ba98:	f902b3e2 	str	x2, [sp, #1376]
    ba9c:	97ffe80a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    baa0:	97ffe875 	bl	5c74 <fwp_rc_fresh>
    baa4:	aa0003e2 	mov	x2, x0
    baa8:	9115a3e1 	add	x1, sp, #0x568
    baac:	52800020 	mov	w0, #0x1                   	// #1
    bab0:	f902b7f7 	str	x23, [sp, #1384]
    bab4:	f902bbe2 	str	x2, [sp, #1392]
    bab8:	97ffe803 	bl	5ac4 <fwp_data.part.0.constprop.0>
    babc:	91174283 	add	x3, x20, #0x5d0
    bac0:	aa0003f5 	mov	x21, x0
    bac4:	f949d861 	ldr	x1, [x3, #5040]
    bac8:	f949ec60 	ldr	x0, [x3, #5080]
    bacc:	cb0102a1 	sub	x1, x21, x1
    bad0:	eb00403f 	cmp	x1, x0, lsl #16
    bad4:	54000322 	b.cs	bb38 <f0+0x12e8>  // b.hs, b.nlast
    bad8:	d350fc22 	lsr	x2, x1, #16
    badc:	f949fc63 	ldr	x3, [x3, #5112]
    bae0:	8b020842 	add	x2, x2, x2, lsl #2
    bae4:	d37df042 	lsl	x2, x2, #3
    bae8:	8b020060 	add	x0, x3, x2
    baec:	f9401017 	ldr	x23, [x0, #32]
    baf0:	b4000257 	cbz	x23, bb38 <f0+0x12e8>
    baf4:	38626862 	ldrb	w2, [x3, x2]
    baf8:	7100085f 	cmp	w2, #0x2
    bafc:	54008e60 	b.eq	ccc8 <f0+0x2478>  // b.none
    bb00:	7100045f 	cmp	w2, #0x1
    bb04:	540001a1 	b.ne	bb38 <f0+0x12e8>  // b.any
    bb08:	29430002 	ldp	w2, w0, [x0, #24]
    bb0c:	92403c21 	and	x1, x1, #0xffff
    bb10:	9b027c21 	mul	x1, x1, x2
    bb14:	d360fc21 	lsr	x1, x1, #32
    bb18:	eb00003f 	cmp	x1, x0
    bb1c:	540000e2 	b.cs	bb38 <f0+0x12e8>  // b.hs, b.nlast
    bb20:	8b0102f7 	add	x23, x23, x1
    bb24:	394002e0 	ldrb	w0, [x23]
    bb28:	7103fc1f 	cmp	w0, #0xff
    bb2c:	54009580 	b.eq	cddc <f0+0x258c>  // b.none
    bb30:	52800020 	mov	w0, #0x1                   	// #1
    bb34:	390002e0 	strb	w0, [x23]
    bb38:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bb3c:	9115e3e1 	add	x1, sp, #0x578
    bb40:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bb44:	52800020 	mov	w0, #0x1                   	// #1
    bb48:	f902bfe2 	str	x2, [sp, #1400]
    bb4c:	f902c3f5 	str	x21, [sp, #1408]
    bb50:	97ffe7dd 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bb54:	91174283 	add	x3, x20, #0x5d0
    bb58:	aa0003f5 	mov	x21, x0
    bb5c:	f949d861 	ldr	x1, [x3, #5040]
    bb60:	f949ec60 	ldr	x0, [x3, #5080]
    bb64:	cb0102a1 	sub	x1, x21, x1
    bb68:	eb00403f 	cmp	x1, x0, lsl #16
    bb6c:	54000322 	b.cs	bbd0 <f0+0x1380>  // b.hs, b.nlast
    bb70:	d350fc22 	lsr	x2, x1, #16
    bb74:	f949fc63 	ldr	x3, [x3, #5112]
    bb78:	8b020842 	add	x2, x2, x2, lsl #2
    bb7c:	d37df042 	lsl	x2, x2, #3
    bb80:	8b020060 	add	x0, x3, x2
    bb84:	f9401017 	ldr	x23, [x0, #32]
    bb88:	b4000257 	cbz	x23, bbd0 <f0+0x1380>
    bb8c:	38626862 	ldrb	w2, [x3, x2]
    bb90:	7100085f 	cmp	w2, #0x2
    bb94:	54008940 	b.eq	ccbc <f0+0x246c>  // b.none
    bb98:	7100045f 	cmp	w2, #0x1
    bb9c:	540001a1 	b.ne	bbd0 <f0+0x1380>  // b.any
    bba0:	29430002 	ldp	w2, w0, [x0, #24]
    bba4:	92403c21 	and	x1, x1, #0xffff
    bba8:	9b027c21 	mul	x1, x1, x2
    bbac:	d360fc21 	lsr	x1, x1, #32
    bbb0:	eb00003f 	cmp	x1, x0
    bbb4:	540000e2 	b.cs	bbd0 <f0+0x1380>  // b.hs, b.nlast
    bbb8:	8b0102f7 	add	x23, x23, x1
    bbbc:	394002e0 	ldrb	w0, [x23]
    bbc0:	7103fc1f 	cmp	w0, #0xff
    bbc4:	54009120 	b.eq	cde8 <f0+0x2598>  // b.none
    bbc8:	52800020 	mov	w0, #0x1                   	// #1
    bbcc:	390002e0 	strb	w0, [x23]
    bbd0:	911623e1 	add	x1, sp, #0x588
    bbd4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	f902c7e2 	str	x2, [sp, #1416]
    bbe0:	f902cbf5 	str	x21, [sp, #1424]
    bbe4:	97ffe7b8 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bbe8:	97ffe823 	bl	5c74 <fwp_rc_fresh>
    bbec:	aa0003e2 	mov	x2, x0
    bbf0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bbf4:	911663e1 	add	x1, sp, #0x598
    bbf8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bbfc:	52800020 	mov	w0, #0x1                   	// #1
    bc00:	f902cfe3 	str	x3, [sp, #1432]
    bc04:	f902d3e2 	str	x2, [sp, #1440]
    bc08:	97ffe7af 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bc0c:	91174283 	add	x3, x20, #0x5d0
    bc10:	aa0003f5 	mov	x21, x0
    bc14:	f949d861 	ldr	x1, [x3, #5040]
    bc18:	f949ec60 	ldr	x0, [x3, #5080]
    bc1c:	cb0102a1 	sub	x1, x21, x1
    bc20:	eb00403f 	cmp	x1, x0, lsl #16
    bc24:	54000322 	b.cs	bc88 <f0+0x1438>  // b.hs, b.nlast
    bc28:	d350fc22 	lsr	x2, x1, #16
    bc2c:	f949fc63 	ldr	x3, [x3, #5112]
    bc30:	8b020842 	add	x2, x2, x2, lsl #2
    bc34:	d37df042 	lsl	x2, x2, #3
    bc38:	8b020060 	add	x0, x3, x2
    bc3c:	f9401017 	ldr	x23, [x0, #32]
    bc40:	b4000257 	cbz	x23, bc88 <f0+0x1438>
    bc44:	38626862 	ldrb	w2, [x3, x2]
    bc48:	7100085f 	cmp	w2, #0x2
    bc4c:	540084a0 	b.eq	cce0 <f0+0x2490>  // b.none
    bc50:	7100045f 	cmp	w2, #0x1
    bc54:	540001a1 	b.ne	bc88 <f0+0x1438>  // b.any
    bc58:	29430002 	ldp	w2, w0, [x0, #24]
    bc5c:	92403c21 	and	x1, x1, #0xffff
    bc60:	9b027c21 	mul	x1, x1, x2
    bc64:	d360fc21 	lsr	x1, x1, #32
    bc68:	eb00003f 	cmp	x1, x0
    bc6c:	540000e2 	b.cs	bc88 <f0+0x1438>  // b.hs, b.nlast
    bc70:	8b0102f7 	add	x23, x23, x1
    bc74:	394002e0 	ldrb	w0, [x23]
    bc78:	7103fc1f 	cmp	w0, #0xff
    bc7c:	54008bc0 	b.eq	cdf4 <f0+0x25a4>  // b.none
    bc80:	52800020 	mov	w0, #0x1                   	// #1
    bc84:	390002e0 	strb	w0, [x23]
    bc88:	9116a3e1 	add	x1, sp, #0x5a8
    bc8c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc90:	52800020 	mov	w0, #0x1                   	// #1
    bc94:	f902d7e2 	str	x2, [sp, #1448]
    bc98:	f902dbf5 	str	x21, [sp, #1456]
    bc9c:	97ffe78a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bca0:	97ffe7f5 	bl	5c74 <fwp_rc_fresh>
    bca4:	aa0003e2 	mov	x2, x0
    bca8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bcac:	9116e3e1 	add	x1, sp, #0x5b8
    bcb0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bcb4:	52800020 	mov	w0, #0x1                   	// #1
    bcb8:	f902dfe3 	str	x3, [sp, #1464]
    bcbc:	f902e3e2 	str	x2, [sp, #1472]
    bcc0:	97ffe781 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bcc4:	91174283 	add	x3, x20, #0x5d0
    bcc8:	aa0003f5 	mov	x21, x0
    bccc:	f949d861 	ldr	x1, [x3, #5040]
    bcd0:	f949ec60 	ldr	x0, [x3, #5080]
    bcd4:	cb0102a1 	sub	x1, x21, x1
    bcd8:	eb00403f 	cmp	x1, x0, lsl #16
    bcdc:	54000322 	b.cs	bd40 <f0+0x14f0>  // b.hs, b.nlast
    bce0:	d350fc22 	lsr	x2, x1, #16
    bce4:	f949fc63 	ldr	x3, [x3, #5112]
    bce8:	8b020842 	add	x2, x2, x2, lsl #2
    bcec:	d37df042 	lsl	x2, x2, #3
    bcf0:	8b020060 	add	x0, x3, x2
    bcf4:	f9401017 	ldr	x23, [x0, #32]
    bcf8:	b4000257 	cbz	x23, bd40 <f0+0x14f0>
    bcfc:	38626862 	ldrb	w2, [x3, x2]
    bd00:	7100085f 	cmp	w2, #0x2
    bd04:	54007e80 	b.eq	ccd4 <f0+0x2484>  // b.none
    bd08:	7100045f 	cmp	w2, #0x1
    bd0c:	540001a1 	b.ne	bd40 <f0+0x14f0>  // b.any
    bd10:	29430002 	ldp	w2, w0, [x0, #24]
    bd14:	92403c21 	and	x1, x1, #0xffff
    bd18:	9b027c21 	mul	x1, x1, x2
    bd1c:	d360fc21 	lsr	x1, x1, #32
    bd20:	eb00003f 	cmp	x1, x0
    bd24:	540000e2 	b.cs	bd40 <f0+0x14f0>  // b.hs, b.nlast
    bd28:	8b0102f7 	add	x23, x23, x1
    bd2c:	394002e0 	ldrb	w0, [x23]
    bd30:	7103fc1f 	cmp	w0, #0xff
    bd34:	54008660 	b.eq	ce00 <f0+0x25b0>  // b.none
    bd38:	52800020 	mov	w0, #0x1                   	// #1
    bd3c:	390002e0 	strb	w0, [x23]
    bd40:	911723e1 	add	x1, sp, #0x5c8
    bd44:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd48:	52800020 	mov	w0, #0x1                   	// #1
    bd4c:	f902e7f7 	str	x23, [sp, #1480]
    bd50:	f902ebf5 	str	x21, [sp, #1488]
    bd54:	97ffe75c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bd58:	97ffe7c7 	bl	5c74 <fwp_rc_fresh>
    bd5c:	aa0003e2 	mov	x2, x0
    bd60:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bd64:	911763e1 	add	x1, sp, #0x5d8
    bd68:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bd6c:	52800020 	mov	w0, #0x1                   	// #1
    bd70:	f902efe3 	str	x3, [sp, #1496]
    bd74:	f902f3e2 	str	x2, [sp, #1504]
    bd78:	97ffe753 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bd7c:	97ffe7be 	bl	5c74 <fwp_rc_fresh>
    bd80:	aa0003e2 	mov	x2, x0
    bd84:	9117a3e1 	add	x1, sp, #0x5e8
    bd88:	52800020 	mov	w0, #0x1                   	// #1
    bd8c:	f902f7f7 	str	x23, [sp, #1512]
    bd90:	f902fbe2 	str	x2, [sp, #1520]
    bd94:	97ffe74c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bd98:	91174283 	add	x3, x20, #0x5d0
    bd9c:	aa0003f5 	mov	x21, x0
    bda0:	f949d861 	ldr	x1, [x3, #5040]
    bda4:	f949ec60 	ldr	x0, [x3, #5080]
    bda8:	cb0102a1 	sub	x1, x21, x1
    bdac:	eb00403f 	cmp	x1, x0, lsl #16
    bdb0:	54000322 	b.cs	be14 <f0+0x15c4>  // b.hs, b.nlast
    bdb4:	d350fc22 	lsr	x2, x1, #16
    bdb8:	f949fc63 	ldr	x3, [x3, #5112]
    bdbc:	8b020842 	add	x2, x2, x2, lsl #2
    bdc0:	d37df042 	lsl	x2, x2, #3
    bdc4:	8b020060 	add	x0, x3, x2
    bdc8:	f9401017 	ldr	x23, [x0, #32]
    bdcc:	b4000257 	cbz	x23, be14 <f0+0x15c4>
    bdd0:	38626862 	ldrb	w2, [x3, x2]
    bdd4:	7100085f 	cmp	w2, #0x2
    bdd8:	54007900 	b.eq	ccf8 <f0+0x24a8>  // b.none
    bddc:	7100045f 	cmp	w2, #0x1
    bde0:	540001a1 	b.ne	be14 <f0+0x15c4>  // b.any
    bde4:	29430002 	ldp	w2, w0, [x0, #24]
    bde8:	92403c21 	and	x1, x1, #0xffff
    bdec:	9b027c21 	mul	x1, x1, x2
    bdf0:	d360fc21 	lsr	x1, x1, #32
    bdf4:	eb00003f 	cmp	x1, x0
    bdf8:	540000e2 	b.cs	be14 <f0+0x15c4>  // b.hs, b.nlast
    bdfc:	8b0102f7 	add	x23, x23, x1
    be00:	394002e0 	ldrb	w0, [x23]
    be04:	7103fc1f 	cmp	w0, #0xff
    be08:	54008020 	b.eq	ce0c <f0+0x25bc>  // b.none
    be0c:	52800020 	mov	w0, #0x1                   	// #1
    be10:	390002e0 	strb	w0, [x23]
    be14:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be18:	9117e3e1 	add	x1, sp, #0x5f8
    be1c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be20:	52800020 	mov	w0, #0x1                   	// #1
    be24:	f902ffe2 	str	x2, [sp, #1528]
    be28:	f90303f5 	str	x21, [sp, #1536]
    be2c:	97ffe726 	bl	5ac4 <fwp_data.part.0.constprop.0>
    be30:	91174283 	add	x3, x20, #0x5d0
    be34:	aa0003f5 	mov	x21, x0
    be38:	f949d861 	ldr	x1, [x3, #5040]
    be3c:	f949ec60 	ldr	x0, [x3, #5080]
    be40:	cb0102a1 	sub	x1, x21, x1
    be44:	eb00403f 	cmp	x1, x0, lsl #16
    be48:	54000322 	b.cs	beac <f0+0x165c>  // b.hs, b.nlast
    be4c:	d350fc22 	lsr	x2, x1, #16
    be50:	f949fc63 	ldr	x3, [x3, #5112]
    be54:	8b020842 	add	x2, x2, x2, lsl #2
    be58:	d37df042 	lsl	x2, x2, #3
    be5c:	8b020060 	add	x0, x3, x2
    be60:	f9401017 	ldr	x23, [x0, #32]
    be64:	b4000257 	cbz	x23, beac <f0+0x165c>
    be68:	38626862 	ldrb	w2, [x3, x2]
    be6c:	7100085f 	cmp	w2, #0x2
    be70:	540073e0 	b.eq	ccec <f0+0x249c>  // b.none
    be74:	7100045f 	cmp	w2, #0x1
    be78:	540001a1 	b.ne	beac <f0+0x165c>  // b.any
    be7c:	29430002 	ldp	w2, w0, [x0, #24]
    be80:	92403c21 	and	x1, x1, #0xffff
    be84:	9b027c21 	mul	x1, x1, x2
    be88:	d360fc21 	lsr	x1, x1, #32
    be8c:	eb00003f 	cmp	x1, x0
    be90:	540000e2 	b.cs	beac <f0+0x165c>  // b.hs, b.nlast
    be94:	8b0102f7 	add	x23, x23, x1
    be98:	394002e0 	ldrb	w0, [x23]
    be9c:	7103fc1f 	cmp	w0, #0xff
    bea0:	54007bc0 	b.eq	ce18 <f0+0x25c8>  // b.none
    bea4:	52800020 	mov	w0, #0x1                   	// #1
    bea8:	390002e0 	strb	w0, [x23]
    beac:	911823e1 	add	x1, sp, #0x608
    beb0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    beb4:	52800020 	mov	w0, #0x1                   	// #1
    beb8:	f90307e2 	str	x2, [sp, #1544]
    bebc:	f9030bf5 	str	x21, [sp, #1552]
    bec0:	97ffe701 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bec4:	97ffe76c 	bl	5c74 <fwp_rc_fresh>
    bec8:	aa0003e2 	mov	x2, x0
    becc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bed0:	911863e1 	add	x1, sp, #0x618
    bed4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bed8:	52800020 	mov	w0, #0x1                   	// #1
    bedc:	f9030fe3 	str	x3, [sp, #1560]
    bee0:	f90313e2 	str	x2, [sp, #1568]
    bee4:	97ffe6f8 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bee8:	91174283 	add	x3, x20, #0x5d0
    beec:	aa0003f5 	mov	x21, x0
    bef0:	f949d861 	ldr	x1, [x3, #5040]
    bef4:	f949ec60 	ldr	x0, [x3, #5080]
    bef8:	cb0102a1 	sub	x1, x21, x1
    befc:	eb00403f 	cmp	x1, x0, lsl #16
    bf00:	54000322 	b.cs	bf64 <f0+0x1714>  // b.hs, b.nlast
    bf04:	d350fc22 	lsr	x2, x1, #16
    bf08:	f949fc63 	ldr	x3, [x3, #5112]
    bf0c:	8b020842 	add	x2, x2, x2, lsl #2
    bf10:	d37df042 	lsl	x2, x2, #3
    bf14:	8b020060 	add	x0, x3, x2
    bf18:	f9401017 	ldr	x23, [x0, #32]
    bf1c:	b4000257 	cbz	x23, bf64 <f0+0x1714>
    bf20:	38626862 	ldrb	w2, [x3, x2]
    bf24:	7100085f 	cmp	w2, #0x2
    bf28:	54006340 	b.eq	cb90 <f0+0x2340>  // b.none
    bf2c:	7100045f 	cmp	w2, #0x1
    bf30:	540001a1 	b.ne	bf64 <f0+0x1714>  // b.any
    bf34:	29430002 	ldp	w2, w0, [x0, #24]
    bf38:	92403c21 	and	x1, x1, #0xffff
    bf3c:	9b027c21 	mul	x1, x1, x2
    bf40:	d360fc21 	lsr	x1, x1, #32
    bf44:	eb00003f 	cmp	x1, x0
    bf48:	540000e2 	b.cs	bf64 <f0+0x1714>  // b.hs, b.nlast
    bf4c:	8b0102f7 	add	x23, x23, x1
    bf50:	394002e0 	ldrb	w0, [x23]
    bf54:	7103fc1f 	cmp	w0, #0xff
    bf58:	54007660 	b.eq	ce24 <f0+0x25d4>  // b.none
    bf5c:	52800020 	mov	w0, #0x1                   	// #1
    bf60:	390002e0 	strb	w0, [x23]
    bf64:	9118a3e1 	add	x1, sp, #0x628
    bf68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf6c:	52800020 	mov	w0, #0x1                   	// #1
    bf70:	f90317e2 	str	x2, [sp, #1576]
    bf74:	f9031bf5 	str	x21, [sp, #1584]
    bf78:	97ffe6d3 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bf7c:	97ffe73e 	bl	5c74 <fwp_rc_fresh>
    bf80:	aa0003e2 	mov	x2, x0
    bf84:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bf88:	9118e3e1 	add	x1, sp, #0x638
    bf8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bf90:	52800020 	mov	w0, #0x1                   	// #1
    bf94:	f9031fe3 	str	x3, [sp, #1592]
    bf98:	f90323e2 	str	x2, [sp, #1600]
    bf9c:	97ffe6ca 	bl	5ac4 <fwp_data.part.0.constprop.0>
    bfa0:	91174283 	add	x3, x20, #0x5d0
    bfa4:	aa0003f5 	mov	x21, x0
    bfa8:	f949d861 	ldr	x1, [x3, #5040]
    bfac:	f949ec60 	ldr	x0, [x3, #5080]
    bfb0:	cb0102a1 	sub	x1, x21, x1
    bfb4:	eb00403f 	cmp	x1, x0, lsl #16
    bfb8:	54000322 	b.cs	c01c <f0+0x17cc>  // b.hs, b.nlast
    bfbc:	d350fc22 	lsr	x2, x1, #16
    bfc0:	f949fc63 	ldr	x3, [x3, #5112]
    bfc4:	8b020842 	add	x2, x2, x2, lsl #2
    bfc8:	d37df042 	lsl	x2, x2, #3
    bfcc:	8b020060 	add	x0, x3, x2
    bfd0:	f9401017 	ldr	x23, [x0, #32]
    bfd4:	b4000257 	cbz	x23, c01c <f0+0x17cc>
    bfd8:	38626862 	ldrb	w2, [x3, x2]
    bfdc:	7100085f 	cmp	w2, #0x2
    bfe0:	54005d20 	b.eq	cb84 <f0+0x2334>  // b.none
    bfe4:	7100045f 	cmp	w2, #0x1
    bfe8:	540001a1 	b.ne	c01c <f0+0x17cc>  // b.any
    bfec:	29430002 	ldp	w2, w0, [x0, #24]
    bff0:	92403c21 	and	x1, x1, #0xffff
    bff4:	9b027c21 	mul	x1, x1, x2
    bff8:	d360fc21 	lsr	x1, x1, #32
    bffc:	eb00003f 	cmp	x1, x0
    c000:	540000e2 	b.cs	c01c <f0+0x17cc>  // b.hs, b.nlast
    c004:	8b0102f7 	add	x23, x23, x1
    c008:	394002e0 	ldrb	w0, [x23]
    c00c:	7103fc1f 	cmp	w0, #0xff
    c010:	54007100 	b.eq	ce30 <f0+0x25e0>  // b.none
    c014:	52800020 	mov	w0, #0x1                   	// #1
    c018:	390002e0 	strb	w0, [x23]
    c01c:	911923e1 	add	x1, sp, #0x648
    c020:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c024:	52800020 	mov	w0, #0x1                   	// #1
    c028:	f90327f7 	str	x23, [sp, #1608]
    c02c:	f9032bf5 	str	x21, [sp, #1616]
    c030:	97ffe6a5 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c034:	97ffe710 	bl	5c74 <fwp_rc_fresh>
    c038:	aa0003e2 	mov	x2, x0
    c03c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c040:	911963e1 	add	x1, sp, #0x658
    c044:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c048:	52800020 	mov	w0, #0x1                   	// #1
    c04c:	f9032fe3 	str	x3, [sp, #1624]
    c050:	f90333e2 	str	x2, [sp, #1632]
    c054:	97ffe69c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c058:	97ffe707 	bl	5c74 <fwp_rc_fresh>
    c05c:	aa0003e2 	mov	x2, x0
    c060:	9119a3e1 	add	x1, sp, #0x668
    c064:	52800020 	mov	w0, #0x1                   	// #1
    c068:	f90337f7 	str	x23, [sp, #1640]
    c06c:	f9033be2 	str	x2, [sp, #1648]
    c070:	97ffe695 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c074:	91174283 	add	x3, x20, #0x5d0
    c078:	aa0003f5 	mov	x21, x0
    c07c:	f949d861 	ldr	x1, [x3, #5040]
    c080:	f949ec60 	ldr	x0, [x3, #5080]
    c084:	cb0102a1 	sub	x1, x21, x1
    c088:	eb00403f 	cmp	x1, x0, lsl #16
    c08c:	54000322 	b.cs	c0f0 <f0+0x18a0>  // b.hs, b.nlast
    c090:	d350fc22 	lsr	x2, x1, #16
    c094:	f949fc63 	ldr	x3, [x3, #5112]
    c098:	8b020842 	add	x2, x2, x2, lsl #2
    c09c:	d37df042 	lsl	x2, x2, #3
    c0a0:	8b020060 	add	x0, x3, x2
    c0a4:	f9401017 	ldr	x23, [x0, #32]
    c0a8:	b4000257 	cbz	x23, c0f0 <f0+0x18a0>
    c0ac:	38626862 	ldrb	w2, [x3, x2]
    c0b0:	7100085f 	cmp	w2, #0x2
    c0b4:	540057a0 	b.eq	cba8 <f0+0x2358>  // b.none
    c0b8:	7100045f 	cmp	w2, #0x1
    c0bc:	540001a1 	b.ne	c0f0 <f0+0x18a0>  // b.any
    c0c0:	29430002 	ldp	w2, w0, [x0, #24]
    c0c4:	92403c21 	and	x1, x1, #0xffff
    c0c8:	9b027c21 	mul	x1, x1, x2
    c0cc:	d360fc21 	lsr	x1, x1, #32
    c0d0:	eb00003f 	cmp	x1, x0
    c0d4:	540000e2 	b.cs	c0f0 <f0+0x18a0>  // b.hs, b.nlast
    c0d8:	8b0102f7 	add	x23, x23, x1
    c0dc:	394002e0 	ldrb	w0, [x23]
    c0e0:	7103fc1f 	cmp	w0, #0xff
    c0e4:	54006ac0 	b.eq	ce3c <f0+0x25ec>  // b.none
    c0e8:	52800020 	mov	w0, #0x1                   	// #1
    c0ec:	390002e0 	strb	w0, [x23]
    c0f0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c0f4:	9119e3e1 	add	x1, sp, #0x678
    c0f8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c0fc:	52800020 	mov	w0, #0x1                   	// #1
    c100:	f9033fe2 	str	x2, [sp, #1656]
    c104:	f90343f5 	str	x21, [sp, #1664]
    c108:	97ffe66f 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c10c:	91174283 	add	x3, x20, #0x5d0
    c110:	aa0003f5 	mov	x21, x0
    c114:	f949d861 	ldr	x1, [x3, #5040]
    c118:	f949ec60 	ldr	x0, [x3, #5080]
    c11c:	cb0102a1 	sub	x1, x21, x1
    c120:	eb00403f 	cmp	x1, x0, lsl #16
    c124:	54000322 	b.cs	c188 <f0+0x1938>  // b.hs, b.nlast
    c128:	d350fc22 	lsr	x2, x1, #16
    c12c:	f949fc63 	ldr	x3, [x3, #5112]
    c130:	8b020842 	add	x2, x2, x2, lsl #2
    c134:	d37df042 	lsl	x2, x2, #3
    c138:	8b020060 	add	x0, x3, x2
    c13c:	f9401017 	ldr	x23, [x0, #32]
    c140:	b4000257 	cbz	x23, c188 <f0+0x1938>
    c144:	38626862 	ldrb	w2, [x3, x2]
    c148:	7100085f 	cmp	w2, #0x2
    c14c:	54005280 	b.eq	cb9c <f0+0x234c>  // b.none
    c150:	7100045f 	cmp	w2, #0x1
    c154:	540001a1 	b.ne	c188 <f0+0x1938>  // b.any
    c158:	29430002 	ldp	w2, w0, [x0, #24]
    c15c:	92403c21 	and	x1, x1, #0xffff
    c160:	9b027c21 	mul	x1, x1, x2
    c164:	d360fc21 	lsr	x1, x1, #32
    c168:	eb00003f 	cmp	x1, x0
    c16c:	540000e2 	b.cs	c188 <f0+0x1938>  // b.hs, b.nlast
    c170:	8b0102f7 	add	x23, x23, x1
    c174:	394002e0 	ldrb	w0, [x23]
    c178:	7103fc1f 	cmp	w0, #0xff
    c17c:	54006660 	b.eq	ce48 <f0+0x25f8>  // b.none
    c180:	52800020 	mov	w0, #0x1                   	// #1
    c184:	390002e0 	strb	w0, [x23]
    c188:	911a23e1 	add	x1, sp, #0x688
    c18c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c190:	52800020 	mov	w0, #0x1                   	// #1
    c194:	f90347f7 	str	x23, [sp, #1672]
    c198:	f9034bf5 	str	x21, [sp, #1680]
    c19c:	97ffe64a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c1a0:	97ffe6b5 	bl	5c74 <fwp_rc_fresh>
    c1a4:	aa0003e2 	mov	x2, x0
    c1a8:	911a63e1 	add	x1, sp, #0x698
    c1ac:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c1b0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c1b4:	52800020 	mov	w0, #0x1                   	// #1
    c1b8:	f9034ff5 	str	x21, [sp, #1688]
    c1bc:	f90353e2 	str	x2, [sp, #1696]
    c1c0:	97ffe641 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c1c4:	97ffe6ac 	bl	5c74 <fwp_rc_fresh>
    c1c8:	aa0003e2 	mov	x2, x0
    c1cc:	911aa3e1 	add	x1, sp, #0x6a8
    c1d0:	52800020 	mov	w0, #0x1                   	// #1
    c1d4:	f90357f7 	str	x23, [sp, #1704]
    c1d8:	f9035be2 	str	x2, [sp, #1712]
    c1dc:	97ffe63a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c1e0:	97ffe6a5 	bl	5c74 <fwp_rc_fresh>
    c1e4:	aa0003e2 	mov	x2, x0
    c1e8:	911ae3e1 	add	x1, sp, #0x6b8
    c1ec:	52800020 	mov	w0, #0x1                   	// #1
    c1f0:	f9035ff5 	str	x21, [sp, #1720]
    c1f4:	f90363e2 	str	x2, [sp, #1728]
    c1f8:	97ffe633 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c1fc:	91174283 	add	x3, x20, #0x5d0
    c200:	aa0003f5 	mov	x21, x0
    c204:	f949d861 	ldr	x1, [x3, #5040]
    c208:	f949ec60 	ldr	x0, [x3, #5080]
    c20c:	cb0102a1 	sub	x1, x21, x1
    c210:	eb00403f 	cmp	x1, x0, lsl #16
    c214:	54000322 	b.cs	c278 <f0+0x1a28>  // b.hs, b.nlast
    c218:	d350fc22 	lsr	x2, x1, #16
    c21c:	f949fc63 	ldr	x3, [x3, #5112]
    c220:	8b020842 	add	x2, x2, x2, lsl #2
    c224:	d37df042 	lsl	x2, x2, #3
    c228:	8b020060 	add	x0, x3, x2
    c22c:	f9401017 	ldr	x23, [x0, #32]
    c230:	b4000257 	cbz	x23, c278 <f0+0x1a28>
    c234:	38626862 	ldrb	w2, [x3, x2]
    c238:	7100085f 	cmp	w2, #0x2
    c23c:	54004c20 	b.eq	cbc0 <f0+0x2370>  // b.none
    c240:	7100045f 	cmp	w2, #0x1
    c244:	540001a1 	b.ne	c278 <f0+0x1a28>  // b.any
    c248:	29430002 	ldp	w2, w0, [x0, #24]
    c24c:	92403c21 	and	x1, x1, #0xffff
    c250:	9b027c21 	mul	x1, x1, x2
    c254:	d360fc21 	lsr	x1, x1, #32
    c258:	eb00003f 	cmp	x1, x0
    c25c:	540000e2 	b.cs	c278 <f0+0x1a28>  // b.hs, b.nlast
    c260:	8b0102f7 	add	x23, x23, x1
    c264:	394002e0 	ldrb	w0, [x23]
    c268:	7103fc1f 	cmp	w0, #0xff
    c26c:	54005f40 	b.eq	ce54 <f0+0x2604>  // b.none
    c270:	52800020 	mov	w0, #0x1                   	// #1
    c274:	390002e0 	strb	w0, [x23]
    c278:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c27c:	911b23e1 	add	x1, sp, #0x6c8
    c280:	52800020 	mov	w0, #0x1                   	// #1
    c284:	f90367e2 	str	x2, [sp, #1736]
    c288:	f9036bf5 	str	x21, [sp, #1744]
    c28c:	97ffe60e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c290:	91174283 	add	x3, x20, #0x5d0
    c294:	aa0003f5 	mov	x21, x0
    c298:	f949d861 	ldr	x1, [x3, #5040]
    c29c:	f949ec60 	ldr	x0, [x3, #5080]
    c2a0:	cb0102a1 	sub	x1, x21, x1
    c2a4:	eb00403f 	cmp	x1, x0, lsl #16
    c2a8:	54000322 	b.cs	c30c <f0+0x1abc>  // b.hs, b.nlast
    c2ac:	d350fc22 	lsr	x2, x1, #16
    c2b0:	f949fc63 	ldr	x3, [x3, #5112]
    c2b4:	8b020842 	add	x2, x2, x2, lsl #2
    c2b8:	d37df042 	lsl	x2, x2, #3
    c2bc:	8b020060 	add	x0, x3, x2
    c2c0:	f9401017 	ldr	x23, [x0, #32]
    c2c4:	b4000257 	cbz	x23, c30c <f0+0x1abc>
    c2c8:	38626862 	ldrb	w2, [x3, x2]
    c2cc:	7100085f 	cmp	w2, #0x2
    c2d0:	54004720 	b.eq	cbb4 <f0+0x2364>  // b.none
    c2d4:	7100045f 	cmp	w2, #0x1
    c2d8:	540001a1 	b.ne	c30c <f0+0x1abc>  // b.any
    c2dc:	29430002 	ldp	w2, w0, [x0, #24]
    c2e0:	92403c21 	and	x1, x1, #0xffff
    c2e4:	9b027c21 	mul	x1, x1, x2
    c2e8:	d360fc21 	lsr	x1, x1, #32
    c2ec:	eb00003f 	cmp	x1, x0
    c2f0:	540000e2 	b.cs	c30c <f0+0x1abc>  // b.hs, b.nlast
    c2f4:	8b0102f7 	add	x23, x23, x1
    c2f8:	394002e0 	ldrb	w0, [x23]
    c2fc:	7103fc1f 	cmp	w0, #0xff
    c300:	54005b00 	b.eq	ce60 <f0+0x2610>  // b.none
    c304:	52800020 	mov	w0, #0x1                   	// #1
    c308:	390002e0 	strb	w0, [x23]
    c30c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c310:	911b63e1 	add	x1, sp, #0x6d8
    c314:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c318:	52800020 	mov	w0, #0x1                   	// #1
    c31c:	f9036fe2 	str	x2, [sp, #1752]
    c320:	f90373f5 	str	x21, [sp, #1760]
    c324:	97ffe5e8 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c328:	91174283 	add	x3, x20, #0x5d0
    c32c:	aa0003f5 	mov	x21, x0
    c330:	f949d861 	ldr	x1, [x3, #5040]
    c334:	f949ec60 	ldr	x0, [x3, #5080]
    c338:	cb0102a1 	sub	x1, x21, x1
    c33c:	eb00403f 	cmp	x1, x0, lsl #16
    c340:	54000322 	b.cs	c3a4 <f0+0x1b54>  // b.hs, b.nlast
    c344:	d350fc22 	lsr	x2, x1, #16
    c348:	f949fc63 	ldr	x3, [x3, #5112]
    c34c:	8b020842 	add	x2, x2, x2, lsl #2
    c350:	d37df042 	lsl	x2, x2, #3
    c354:	8b020060 	add	x0, x3, x2
    c358:	f9401017 	ldr	x23, [x0, #32]
    c35c:	b4000257 	cbz	x23, c3a4 <f0+0x1b54>
    c360:	38626862 	ldrb	w2, [x3, x2]
    c364:	7100085f 	cmp	w2, #0x2
    c368:	54004380 	b.eq	cbd8 <f0+0x2388>  // b.none
    c36c:	7100045f 	cmp	w2, #0x1
    c370:	540001a1 	b.ne	c3a4 <f0+0x1b54>  // b.any
    c374:	29430002 	ldp	w2, w0, [x0, #24]
    c378:	92403c21 	and	x1, x1, #0xffff
    c37c:	9b027c21 	mul	x1, x1, x2
    c380:	d360fc21 	lsr	x1, x1, #32
    c384:	eb00003f 	cmp	x1, x0
    c388:	540000e2 	b.cs	c3a4 <f0+0x1b54>  // b.hs, b.nlast
    c38c:	8b0102f7 	add	x23, x23, x1
    c390:	394002e0 	ldrb	w0, [x23]
    c394:	7103fc1f 	cmp	w0, #0xff
    c398:	540056a0 	b.eq	ce6c <f0+0x261c>  // b.none
    c39c:	52800020 	mov	w0, #0x1                   	// #1
    c3a0:	390002e0 	strb	w0, [x23]
    c3a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c3a8:	911ba3e1 	add	x1, sp, #0x6e8
    c3ac:	52800020 	mov	w0, #0x1                   	// #1
    c3b0:	f90377e2 	str	x2, [sp, #1768]
    c3b4:	f9037bf5 	str	x21, [sp, #1776]
    c3b8:	97ffe5c3 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c3bc:	91174283 	add	x3, x20, #0x5d0
    c3c0:	aa0003f5 	mov	x21, x0
    c3c4:	f949d861 	ldr	x1, [x3, #5040]
    c3c8:	f949ec60 	ldr	x0, [x3, #5080]
    c3cc:	cb0102a1 	sub	x1, x21, x1
    c3d0:	eb00403f 	cmp	x1, x0, lsl #16
    c3d4:	54000322 	b.cs	c438 <f0+0x1be8>  // b.hs, b.nlast
    c3d8:	d350fc22 	lsr	x2, x1, #16
    c3dc:	f949fc63 	ldr	x3, [x3, #5112]
    c3e0:	8b020842 	add	x2, x2, x2, lsl #2
    c3e4:	d37df042 	lsl	x2, x2, #3
    c3e8:	8b020060 	add	x0, x3, x2
    c3ec:	f9401017 	ldr	x23, [x0, #32]
    c3f0:	b4000257 	cbz	x23, c438 <f0+0x1be8>
    c3f4:	38626862 	ldrb	w2, [x3, x2]
    c3f8:	7100085f 	cmp	w2, #0x2
    c3fc:	54003e80 	b.eq	cbcc <f0+0x237c>  // b.none
    c400:	7100045f 	cmp	w2, #0x1
    c404:	540001a1 	b.ne	c438 <f0+0x1be8>  // b.any
    c408:	29430002 	ldp	w2, w0, [x0, #24]
    c40c:	92403c21 	and	x1, x1, #0xffff
    c410:	9b027c21 	mul	x1, x1, x2
    c414:	d360fc21 	lsr	x1, x1, #32
    c418:	eb00003f 	cmp	x1, x0
    c41c:	540000e2 	b.cs	c438 <f0+0x1be8>  // b.hs, b.nlast
    c420:	8b0102f7 	add	x23, x23, x1
    c424:	394002e0 	ldrb	w0, [x23]
    c428:	7103fc1f 	cmp	w0, #0xff
    c42c:	54005260 	b.eq	ce78 <f0+0x2628>  // b.none
    c430:	52800020 	mov	w0, #0x1                   	// #1
    c434:	390002e0 	strb	w0, [x23]
    c438:	911be3e1 	add	x1, sp, #0x6f8
    c43c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c440:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c444:	52800020 	mov	w0, #0x1                   	// #1
    c448:	f9037ff7 	str	x23, [sp, #1784]
    c44c:	f90383f5 	str	x21, [sp, #1792]
    c450:	97ffe59d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c454:	97ffe608 	bl	5c74 <fwp_rc_fresh>
    c458:	aa0003e2 	mov	x2, x0
    c45c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c460:	911c23e1 	add	x1, sp, #0x708
    c464:	52800020 	mov	w0, #0x1                   	// #1
    c468:	f90387e3 	str	x3, [sp, #1800]
    c46c:	f9038be2 	str	x2, [sp, #1808]
    c470:	97ffe595 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c474:	97ffe600 	bl	5c74 <fwp_rc_fresh>
    c478:	aa0003e2 	mov	x2, x0
    c47c:	911c63e1 	add	x1, sp, #0x718
    c480:	52800020 	mov	w0, #0x1                   	// #1
    c484:	f9038ff7 	str	x23, [sp, #1816]
    c488:	f90393e2 	str	x2, [sp, #1824]
    c48c:	97ffe58e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c490:	91174283 	add	x3, x20, #0x5d0
    c494:	aa0003f5 	mov	x21, x0
    c498:	f949d861 	ldr	x1, [x3, #5040]
    c49c:	f949ec60 	ldr	x0, [x3, #5080]
    c4a0:	cb0102a1 	sub	x1, x21, x1
    c4a4:	eb00403f 	cmp	x1, x0, lsl #16
    c4a8:	54000322 	b.cs	c50c <f0+0x1cbc>  // b.hs, b.nlast
    c4ac:	d350fc22 	lsr	x2, x1, #16
    c4b0:	f949fc63 	ldr	x3, [x3, #5112]
    c4b4:	8b020842 	add	x2, x2, x2, lsl #2
    c4b8:	d37df042 	lsl	x2, x2, #3
    c4bc:	8b020060 	add	x0, x3, x2
    c4c0:	f9401017 	ldr	x23, [x0, #32]
    c4c4:	b4000257 	cbz	x23, c50c <f0+0x1cbc>
    c4c8:	38626862 	ldrb	w2, [x3, x2]
    c4cc:	7100085f 	cmp	w2, #0x2
    c4d0:	54003900 	b.eq	cbf0 <f0+0x23a0>  // b.none
    c4d4:	7100045f 	cmp	w2, #0x1
    c4d8:	540001a1 	b.ne	c50c <f0+0x1cbc>  // b.any
    c4dc:	29430002 	ldp	w2, w0, [x0, #24]
    c4e0:	92403c21 	and	x1, x1, #0xffff
    c4e4:	9b027c21 	mul	x1, x1, x2
    c4e8:	d360fc21 	lsr	x1, x1, #32
    c4ec:	eb00003f 	cmp	x1, x0
    c4f0:	540000e2 	b.cs	c50c <f0+0x1cbc>  // b.hs, b.nlast
    c4f4:	8b0102f7 	add	x23, x23, x1
    c4f8:	394002e0 	ldrb	w0, [x23]
    c4fc:	7103fc1f 	cmp	w0, #0xff
    c500:	54004c20 	b.eq	ce84 <f0+0x2634>  // b.none
    c504:	52800020 	mov	w0, #0x1                   	// #1
    c508:	390002e0 	strb	w0, [x23]
    c50c:	911ca3e1 	add	x1, sp, #0x728
    c510:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c514:	52800020 	mov	w0, #0x1                   	// #1
    c518:	f90397e2 	str	x2, [sp, #1832]
    c51c:	f9039bf5 	str	x21, [sp, #1840]
    c520:	97ffe569 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c524:	97ffe5d4 	bl	5c74 <fwp_rc_fresh>
    c528:	aa0003e2 	mov	x2, x0
    c52c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c530:	911ce3e1 	add	x1, sp, #0x738
    c534:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c538:	52800020 	mov	w0, #0x1                   	// #1
    c53c:	f9039fe3 	str	x3, [sp, #1848]
    c540:	f903a3e2 	str	x2, [sp, #1856]
    c544:	97ffe560 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c548:	91174283 	add	x3, x20, #0x5d0
    c54c:	aa0003f5 	mov	x21, x0
    c550:	f949d861 	ldr	x1, [x3, #5040]
    c554:	f949ec60 	ldr	x0, [x3, #5080]
    c558:	cb0102a1 	sub	x1, x21, x1
    c55c:	eb00403f 	cmp	x1, x0, lsl #16
    c560:	54000322 	b.cs	c5c4 <f0+0x1d74>  // b.hs, b.nlast
    c564:	d350fc22 	lsr	x2, x1, #16
    c568:	f949fc63 	ldr	x3, [x3, #5112]
    c56c:	8b020842 	add	x2, x2, x2, lsl #2
    c570:	d37df042 	lsl	x2, x2, #3
    c574:	8b020060 	add	x0, x3, x2
    c578:	f9401017 	ldr	x23, [x0, #32]
    c57c:	b4000257 	cbz	x23, c5c4 <f0+0x1d74>
    c580:	38626862 	ldrb	w2, [x3, x2]
    c584:	7100085f 	cmp	w2, #0x2
    c588:	540032e0 	b.eq	cbe4 <f0+0x2394>  // b.none
    c58c:	7100045f 	cmp	w2, #0x1
    c590:	540001a1 	b.ne	c5c4 <f0+0x1d74>  // b.any
    c594:	29430002 	ldp	w2, w0, [x0, #24]
    c598:	92403c21 	and	x1, x1, #0xffff
    c59c:	9b027c21 	mul	x1, x1, x2
    c5a0:	d360fc21 	lsr	x1, x1, #32
    c5a4:	eb00003f 	cmp	x1, x0
    c5a8:	540000e2 	b.cs	c5c4 <f0+0x1d74>  // b.hs, b.nlast
    c5ac:	8b0102f7 	add	x23, x23, x1
    c5b0:	394002e0 	ldrb	w0, [x23]
    c5b4:	7103fc1f 	cmp	w0, #0xff
    c5b8:	540046c0 	b.eq	ce90 <f0+0x2640>  // b.none
    c5bc:	52800020 	mov	w0, #0x1                   	// #1
    c5c0:	390002e0 	strb	w0, [x23]
    c5c4:	911d23e1 	add	x1, sp, #0x748
    c5c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c5cc:	52800020 	mov	w0, #0x1                   	// #1
    c5d0:	f903a7f7 	str	x23, [sp, #1864]
    c5d4:	f903abf5 	str	x21, [sp, #1872]
    c5d8:	97ffe53b 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c5dc:	97ffe5a6 	bl	5c74 <fwp_rc_fresh>
    c5e0:	aa0003e2 	mov	x2, x0
    c5e4:	911d63e1 	add	x1, sp, #0x758
    c5e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c5ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c5f0:	52800020 	mov	w0, #0x1                   	// #1
    c5f4:	f903aff5 	str	x21, [sp, #1880]
    c5f8:	f903b3e2 	str	x2, [sp, #1888]
    c5fc:	97ffe532 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c600:	97ffe59d 	bl	5c74 <fwp_rc_fresh>
    c604:	aa0003e2 	mov	x2, x0
    c608:	911da3e1 	add	x1, sp, #0x768
    c60c:	52800020 	mov	w0, #0x1                   	// #1
    c610:	f903b7f7 	str	x23, [sp, #1896]
    c614:	f903bbe2 	str	x2, [sp, #1904]
    c618:	97ffe52b 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c61c:	97ffe596 	bl	5c74 <fwp_rc_fresh>
    c620:	aa0003e2 	mov	x2, x0
    c624:	911de3e1 	add	x1, sp, #0x778
    c628:	52800020 	mov	w0, #0x1                   	// #1
    c62c:	f903bff5 	str	x21, [sp, #1912]
    c630:	f903c3e2 	str	x2, [sp, #1920]
    c634:	97ffe524 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c638:	91174283 	add	x3, x20, #0x5d0
    c63c:	aa0003f5 	mov	x21, x0
    c640:	f949d861 	ldr	x1, [x3, #5040]
    c644:	f949ec60 	ldr	x0, [x3, #5080]
    c648:	cb0102a1 	sub	x1, x21, x1
    c64c:	eb00403f 	cmp	x1, x0, lsl #16
    c650:	54000322 	b.cs	c6b4 <f0+0x1e64>  // b.hs, b.nlast
    c654:	d350fc22 	lsr	x2, x1, #16
    c658:	f949fc63 	ldr	x3, [x3, #5112]
    c65c:	8b020842 	add	x2, x2, x2, lsl #2
    c660:	d37df042 	lsl	x2, x2, #3
    c664:	8b020060 	add	x0, x3, x2
    c668:	f9401017 	ldr	x23, [x0, #32]
    c66c:	b4000257 	cbz	x23, c6b4 <f0+0x1e64>
    c670:	38626862 	ldrb	w2, [x3, x2]
    c674:	7100085f 	cmp	w2, #0x2
    c678:	54002c80 	b.eq	cc08 <f0+0x23b8>  // b.none
    c67c:	7100045f 	cmp	w2, #0x1
    c680:	540001a1 	b.ne	c6b4 <f0+0x1e64>  // b.any
    c684:	29430002 	ldp	w2, w0, [x0, #24]
    c688:	92403c21 	and	x1, x1, #0xffff
    c68c:	9b027c21 	mul	x1, x1, x2
    c690:	d360fc21 	lsr	x1, x1, #32
    c694:	eb00003f 	cmp	x1, x0
    c698:	540000e2 	b.cs	c6b4 <f0+0x1e64>  // b.hs, b.nlast
    c69c:	8b0102f7 	add	x23, x23, x1
    c6a0:	394002e0 	ldrb	w0, [x23]
    c6a4:	7103fc1f 	cmp	w0, #0xff
    c6a8:	54003fa0 	b.eq	ce9c <f0+0x264c>  // b.none
    c6ac:	52800020 	mov	w0, #0x1                   	// #1
    c6b0:	390002e0 	strb	w0, [x23]
    c6b4:	911e23e1 	add	x1, sp, #0x788
    c6b8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c6bc:	52800020 	mov	w0, #0x1                   	// #1
    c6c0:	f903c7e2 	str	x2, [sp, #1928]
    c6c4:	f903cbf5 	str	x21, [sp, #1936]
    c6c8:	97ffe4ff 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c6cc:	97ffe56a 	bl	5c74 <fwp_rc_fresh>
    c6d0:	aa0003e2 	mov	x2, x0
    c6d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c6d8:	911e63e1 	add	x1, sp, #0x798
    c6dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c6e0:	52800020 	mov	w0, #0x1                   	// #1
    c6e4:	f903cfe3 	str	x3, [sp, #1944]
    c6e8:	f903d3e2 	str	x2, [sp, #1952]
    c6ec:	97ffe4f6 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c6f0:	91174283 	add	x3, x20, #0x5d0
    c6f4:	aa0003f5 	mov	x21, x0
    c6f8:	f949d861 	ldr	x1, [x3, #5040]
    c6fc:	f949ec60 	ldr	x0, [x3, #5080]
    c700:	cb0102a1 	sub	x1, x21, x1
    c704:	eb00403f 	cmp	x1, x0, lsl #16
    c708:	54000322 	b.cs	c76c <f0+0x1f1c>  // b.hs, b.nlast
    c70c:	d350fc22 	lsr	x2, x1, #16
    c710:	f949fc63 	ldr	x3, [x3, #5112]
    c714:	8b020842 	add	x2, x2, x2, lsl #2
    c718:	d37df042 	lsl	x2, x2, #3
    c71c:	8b020060 	add	x0, x3, x2
    c720:	f9401017 	ldr	x23, [x0, #32]
    c724:	b4000257 	cbz	x23, c76c <f0+0x1f1c>
    c728:	38626862 	ldrb	w2, [x3, x2]
    c72c:	7100085f 	cmp	w2, #0x2
    c730:	54002660 	b.eq	cbfc <f0+0x23ac>  // b.none
    c734:	7100045f 	cmp	w2, #0x1
    c738:	540001a1 	b.ne	c76c <f0+0x1f1c>  // b.any
    c73c:	29430002 	ldp	w2, w0, [x0, #24]
    c740:	92403c21 	and	x1, x1, #0xffff
    c744:	9b027c21 	mul	x1, x1, x2
    c748:	d360fc21 	lsr	x1, x1, #32
    c74c:	eb00003f 	cmp	x1, x0
    c750:	540000e2 	b.cs	c76c <f0+0x1f1c>  // b.hs, b.nlast
    c754:	8b0102f7 	add	x23, x23, x1
    c758:	394002e0 	ldrb	w0, [x23]
    c75c:	7103fc1f 	cmp	w0, #0xff
    c760:	54003a40 	b.eq	cea8 <f0+0x2658>  // b.none
    c764:	52800020 	mov	w0, #0x1                   	// #1
    c768:	390002e0 	strb	w0, [x23]
    c76c:	911ea3e1 	add	x1, sp, #0x7a8
    c770:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c774:	52800020 	mov	w0, #0x1                   	// #1
    c778:	f903d7e2 	str	x2, [sp, #1960]
    c77c:	f903dbf5 	str	x21, [sp, #1968]
    c780:	97ffe4d1 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c784:	97ffe53c 	bl	5c74 <fwp_rc_fresh>
    c788:	aa0003e2 	mov	x2, x0
    c78c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c790:	911ee3e1 	add	x1, sp, #0x7b8
    c794:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c798:	52800020 	mov	w0, #0x1                   	// #1
    c79c:	f903dfe3 	str	x3, [sp, #1976]
    c7a0:	f903e3e2 	str	x2, [sp, #1984]
    c7a4:	97ffe4c8 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c7a8:	91174283 	add	x3, x20, #0x5d0
    c7ac:	aa0003f5 	mov	x21, x0
    c7b0:	f949d861 	ldr	x1, [x3, #5040]
    c7b4:	f949ec60 	ldr	x0, [x3, #5080]
    c7b8:	cb0102a1 	sub	x1, x21, x1
    c7bc:	eb00403f 	cmp	x1, x0, lsl #16
    c7c0:	54000322 	b.cs	c824 <f0+0x1fd4>  // b.hs, b.nlast
    c7c4:	d350fc22 	lsr	x2, x1, #16
    c7c8:	f949fc63 	ldr	x3, [x3, #5112]
    c7cc:	8b020842 	add	x2, x2, x2, lsl #2
    c7d0:	d37df042 	lsl	x2, x2, #3
    c7d4:	8b020060 	add	x0, x3, x2
    c7d8:	f9401017 	ldr	x23, [x0, #32]
    c7dc:	b4000257 	cbz	x23, c824 <f0+0x1fd4>
    c7e0:	38626862 	ldrb	w2, [x3, x2]
    c7e4:	7100085f 	cmp	w2, #0x2
    c7e8:	540021c0 	b.eq	cc20 <f0+0x23d0>  // b.none
    c7ec:	7100045f 	cmp	w2, #0x1
    c7f0:	540001a1 	b.ne	c824 <f0+0x1fd4>  // b.any
    c7f4:	29430002 	ldp	w2, w0, [x0, #24]
    c7f8:	92403c21 	and	x1, x1, #0xffff
    c7fc:	9b027c21 	mul	x1, x1, x2
    c800:	d360fc21 	lsr	x1, x1, #32
    c804:	eb00003f 	cmp	x1, x0
    c808:	540000e2 	b.cs	c824 <f0+0x1fd4>  // b.hs, b.nlast
    c80c:	8b0102f7 	add	x23, x23, x1
    c810:	394002e0 	ldrb	w0, [x23]
    c814:	7103fc1f 	cmp	w0, #0xff
    c818:	540034e0 	b.eq	ceb4 <f0+0x2664>  // b.none
    c81c:	52800020 	mov	w0, #0x1                   	// #1
    c820:	390002e0 	strb	w0, [x23]
    c824:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c828:	911f23e1 	add	x1, sp, #0x7c8
    c82c:	52800020 	mov	w0, #0x1                   	// #1
    c830:	f903e7e2 	str	x2, [sp, #1992]
    c834:	f903ebf5 	str	x21, [sp, #2000]
    c838:	97ffe4a3 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c83c:	91174283 	add	x3, x20, #0x5d0
    c840:	aa0003f5 	mov	x21, x0
    c844:	f949d861 	ldr	x1, [x3, #5040]
    c848:	f949ec60 	ldr	x0, [x3, #5080]
    c84c:	cb0102a1 	sub	x1, x21, x1
    c850:	eb00403f 	cmp	x1, x0, lsl #16
    c854:	54000322 	b.cs	c8b8 <f0+0x2068>  // b.hs, b.nlast
    c858:	d350fc22 	lsr	x2, x1, #16
    c85c:	f949fc63 	ldr	x3, [x3, #5112]
    c860:	8b020842 	add	x2, x2, x2, lsl #2
    c864:	d37df042 	lsl	x2, x2, #3
    c868:	8b020060 	add	x0, x3, x2
    c86c:	f9401017 	ldr	x23, [x0, #32]
    c870:	b4000257 	cbz	x23, c8b8 <f0+0x2068>
    c874:	38626862 	ldrb	w2, [x3, x2]
    c878:	7100085f 	cmp	w2, #0x2
    c87c:	54001cc0 	b.eq	cc14 <f0+0x23c4>  // b.none
    c880:	7100045f 	cmp	w2, #0x1
    c884:	540001a1 	b.ne	c8b8 <f0+0x2068>  // b.any
    c888:	29430002 	ldp	w2, w0, [x0, #24]
    c88c:	92403c21 	and	x1, x1, #0xffff
    c890:	9b027c21 	mul	x1, x1, x2
    c894:	d360fc21 	lsr	x1, x1, #32
    c898:	eb00003f 	cmp	x1, x0
    c89c:	540000e2 	b.cs	c8b8 <f0+0x2068>  // b.hs, b.nlast
    c8a0:	8b0102f7 	add	x23, x23, x1
    c8a4:	394002e0 	ldrb	w0, [x23]
    c8a8:	7103fc1f 	cmp	w0, #0xff
    c8ac:	540030a0 	b.eq	cec0 <f0+0x2670>  // b.none
    c8b0:	52800020 	mov	w0, #0x1                   	// #1
    c8b4:	390002e0 	strb	w0, [x23]
    c8b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c8bc:	911f63e1 	add	x1, sp, #0x7d8
    c8c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c8c4:	52800020 	mov	w0, #0x1                   	// #1
    c8c8:	f903efe2 	str	x2, [sp, #2008]
    c8cc:	f903f3f5 	str	x21, [sp, #2016]
    c8d0:	97ffe47d 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c8d4:	91174283 	add	x3, x20, #0x5d0
    c8d8:	aa0003f5 	mov	x21, x0
    c8dc:	f949d861 	ldr	x1, [x3, #5040]
    c8e0:	f949ec60 	ldr	x0, [x3, #5080]
    c8e4:	cb0102a1 	sub	x1, x21, x1
    c8e8:	eb00403f 	cmp	x1, x0, lsl #16
    c8ec:	54000322 	b.cs	c950 <f0+0x2100>  // b.hs, b.nlast
    c8f0:	d350fc22 	lsr	x2, x1, #16
    c8f4:	f949fc63 	ldr	x3, [x3, #5112]
    c8f8:	8b020842 	add	x2, x2, x2, lsl #2
    c8fc:	d37df042 	lsl	x2, x2, #3
    c900:	8b020060 	add	x0, x3, x2
    c904:	f9401017 	ldr	x23, [x0, #32]
    c908:	b4000257 	cbz	x23, c950 <f0+0x2100>
    c90c:	38626862 	ldrb	w2, [x3, x2]
    c910:	7100085f 	cmp	w2, #0x2
    c914:	54001920 	b.eq	cc38 <f0+0x23e8>  // b.none
    c918:	7100045f 	cmp	w2, #0x1
    c91c:	540001a1 	b.ne	c950 <f0+0x2100>  // b.any
    c920:	29430002 	ldp	w2, w0, [x0, #24]
    c924:	92403c21 	and	x1, x1, #0xffff
    c928:	9b027c21 	mul	x1, x1, x2
    c92c:	d360fc21 	lsr	x1, x1, #32
    c930:	eb00003f 	cmp	x1, x0
    c934:	540000e2 	b.cs	c950 <f0+0x2100>  // b.hs, b.nlast
    c938:	8b0102f7 	add	x23, x23, x1
    c93c:	394002e0 	ldrb	w0, [x23]
    c940:	7103fc1f 	cmp	w0, #0xff
    c944:	54002c40 	b.eq	cecc <f0+0x267c>  // b.none
    c948:	52800020 	mov	w0, #0x1                   	// #1
    c94c:	390002e0 	strb	w0, [x23]
    c950:	911fa3e1 	add	x1, sp, #0x7e8
    c954:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c958:	52800020 	mov	w0, #0x1                   	// #1
    c95c:	f903f7e2 	str	x2, [sp, #2024]
    c960:	f903fbf5 	str	x21, [sp, #2032]
    c964:	97ffe458 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c968:	97ffe4c3 	bl	5c74 <fwp_rc_fresh>
    c96c:	aa0003e2 	mov	x2, x0
    c970:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c974:	91174294 	add	x20, x20, #0x5d0
    c978:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c97c:	911fe3e1 	add	x1, sp, #0x7f8
    c980:	52800020 	mov	w0, #0x1                   	// #1
    c984:	f903ffe3 	str	x3, [sp, #2040]
    c988:	f90403e2 	str	x2, [sp, #2048]
    c98c:	97ffe44e 	bl	5ac4 <fwp_data.part.0.constprop.0>
    c990:	f949da81 	ldr	x1, [x20, #5040]
    c994:	aa0003f5 	mov	x21, x0
    c998:	f949ee80 	ldr	x0, [x20, #5080]
    c99c:	cb0102a1 	sub	x1, x21, x1
    c9a0:	eb00403f 	cmp	x1, x0, lsl #16
    c9a4:	54000322 	b.cs	ca08 <f0+0x21b8>  // b.hs, b.nlast
    c9a8:	d350fc22 	lsr	x2, x1, #16
    c9ac:	f949fe83 	ldr	x3, [x20, #5112]
    c9b0:	8b020842 	add	x2, x2, x2, lsl #2
    c9b4:	d37df042 	lsl	x2, x2, #3
    c9b8:	8b020060 	add	x0, x3, x2
    c9bc:	f9401014 	ldr	x20, [x0, #32]
    c9c0:	b4000254 	cbz	x20, ca08 <f0+0x21b8>
    c9c4:	38626862 	ldrb	w2, [x3, x2]
    c9c8:	7100085f 	cmp	w2, #0x2
    c9cc:	54001300 	b.eq	cc2c <f0+0x23dc>  // b.none
    c9d0:	7100045f 	cmp	w2, #0x1
    c9d4:	540001a1 	b.ne	ca08 <f0+0x21b8>  // b.any
    c9d8:	29430002 	ldp	w2, w0, [x0, #24]
    c9dc:	92403c21 	and	x1, x1, #0xffff
    c9e0:	9b027c21 	mul	x1, x1, x2
    c9e4:	d360fc21 	lsr	x1, x1, #32
    c9e8:	eb00003f 	cmp	x1, x0
    c9ec:	540000e2 	b.cs	ca08 <f0+0x21b8>  // b.hs, b.nlast
    c9f0:	8b010294 	add	x20, x20, x1
    c9f4:	39400280 	ldrb	w0, [x20]
    c9f8:	7103fc1f 	cmp	w0, #0xff
    c9fc:	54001840 	b.eq	cd04 <f0+0x24b4>  // b.none
    ca00:	52800020 	mov	w0, #0x1                   	// #1
    ca04:	39000280 	strb	w0, [x20]
    ca08:	912023e1 	add	x1, sp, #0x808
    ca0c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ca10:	52800020 	mov	w0, #0x1                   	// #1
    ca14:	f90407f7 	str	x23, [sp, #2056]
    ca18:	f9040bf5 	str	x21, [sp, #2064]
    ca1c:	97ffe42a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ca20:	97ffe495 	bl	5c74 <fwp_rc_fresh>
    ca24:	aa0003e2 	mov	x2, x0
    ca28:	912063e1 	add	x1, sp, #0x818
    ca2c:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    ca30:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    ca34:	52800020 	mov	w0, #0x1                   	// #1
    ca38:	f9040ff4 	str	x20, [sp, #2072]
    ca3c:	f90413e2 	str	x2, [sp, #2080]
    ca40:	97ffe421 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ca44:	97ffe48c 	bl	5c74 <fwp_rc_fresh>
    ca48:	aa0003e2 	mov	x2, x0
    ca4c:	9120a3e1 	add	x1, sp, #0x828
    ca50:	52800020 	mov	w0, #0x1                   	// #1
    ca54:	f90417f7 	str	x23, [sp, #2088]
    ca58:	f9041be2 	str	x2, [sp, #2096]
    ca5c:	97ffe41a 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ca60:	97ffe485 	bl	5c74 <fwp_rc_fresh>
    ca64:	aa0003e2 	mov	x2, x0
    ca68:	9120e3e1 	add	x1, sp, #0x838
    ca6c:	52800020 	mov	w0, #0x1                   	// #1
    ca70:	f9041ff4 	str	x20, [sp, #2104]
    ca74:	f90423e2 	str	x2, [sp, #2112]
    ca78:	97ffe413 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ca7c:	97ffe47e 	bl	5c74 <fwp_rc_fresh>
    ca80:	aa0003e2 	mov	x2, x0
    ca84:	912123e1 	add	x1, sp, #0x848
    ca88:	52800020 	mov	w0, #0x1                   	// #1
    ca8c:	f90427f7 	str	x23, [sp, #2120]
    ca90:	f9042be2 	str	x2, [sp, #2128]
    ca94:	97ffe40c 	bl	5ac4 <fwp_data.part.0.constprop.0>
    ca98:	97ffe477 	bl	5c74 <fwp_rc_fresh>
    ca9c:	aa0003e2 	mov	x2, x0
    caa0:	aa1603e1 	mov	x1, x22
    caa4:	52800020 	mov	w0, #0x1                   	// #1
    caa8:	f9042ff4 	str	x20, [sp, #2136]
    caac:	f90433e2 	str	x2, [sp, #2144]
    cab0:	97ffe405 	bl	5ac4 <fwp_data.part.0.constprop.0>
    cab4:	97ffe470 	bl	5c74 <fwp_rc_fresh>
    cab8:	aa0003f5 	mov	x21, x0
    cabc:	aa1303e1 	mov	x1, x19
    cac0:	97fff3f4 	bl	9a90 <fwp_hof0.constprop.0>
    cac4:	aa0003f4 	mov	x20, x0
    cac8:	aa1503e0 	mov	x0, x21
    cacc:	97ffe571 	bl	6090 <fwp_drop0>
    cad0:	aa1303e0 	mov	x0, x19
    cad4:	97ffe56f 	bl	6090 <fwp_drop0>
    cad8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cadc:	f947f400 	ldr	x0, [x0, #4072]
    cae0:	f94437e2 	ldr	x2, [sp, #2152]
    cae4:	f9400001 	ldr	x1, [x0]
    cae8:	eb010042 	subs	x2, x2, x1
    caec:	d2800001 	mov	x1, #0x0                   	// #0
    caf0:	54001f41 	b.ne	ced8 <f0+0x2688>  // b.any
    caf4:	9121c3ff 	add	sp, sp, #0x870
    caf8:	aa1403e0 	mov	x0, x20
    cafc:	a94153f3 	ldp	x19, x20, [sp, #16]
    cb00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    cb04:	a94363f7 	ldp	x23, x24, [sp, #48]
    cb08:	a9446bf9 	ldp	x25, x26, [sp, #64]
    cb0c:	a94573fb 	ldp	x27, x28, [sp, #80]
    cb10:	a8c67bfd 	ldp	x29, x30, [sp], #96
    cb14:	d65f03c0 	ret
    cb18:	aa1c03e0 	mov	x0, x28
    cb1c:	97ffdd9d 	bl	4190 <fwp_rc_forget_slot.part.0>
    cb20:	17fff796 	b	a978 <f0+0x128>
    cb24:	72003c5f 	tst	w2, #0xffff
    cb28:	54fef2a1 	b.ne	a97c <f0+0x12c>  // b.any
    cb2c:	17fff790 	b	a96c <f0+0x11c>
    cb30:	72003c3f 	tst	w1, #0xffff
    cb34:	54fefa61 	b.ne	aa80 <f0+0x230>  // b.any
    cb38:	17fff7cd 	b	aa6c <f0+0x21c>
    cb3c:	72003c3f 	tst	w1, #0xffff
    cb40:	54ff1f61 	b.ne	af2c <f0+0x6dc>  // b.any
    cb44:	17fff8f5 	b	af18 <f0+0x6c8>
    cb48:	72003c3f 	tst	w1, #0xffff
    cb4c:	54ff1941 	b.ne	ae74 <f0+0x624>  // b.any
    cb50:	17fff8c4 	b	ae60 <f0+0x610>
    cb54:	72003c3f 	tst	w1, #0xffff
    cb58:	54ff2ae1 	b.ne	b0b4 <f0+0x864>  // b.any
    cb5c:	17fff951 	b	b0a0 <f0+0x850>
    cb60:	72003c3f 	tst	w1, #0xffff
    cb64:	54ff2301 	b.ne	afc4 <f0+0x774>  // b.any
    cb68:	17fff912 	b	afb0 <f0+0x760>
    cb6c:	72003c3f 	tst	w1, #0xffff
    cb70:	54ff3ae1 	b.ne	b2cc <f0+0xa7c>  // b.any
    cb74:	17fff9d1 	b	b2b8 <f0+0xa68>
    cb78:	72003c3f 	tst	w1, #0xffff
    cb7c:	54ff34c1 	b.ne	b214 <f0+0x9c4>  // b.any
    cb80:	17fff9a0 	b	b200 <f0+0x9b0>
    cb84:	72003c3f 	tst	w1, #0xffff
    cb88:	54ffa4a1 	b.ne	c01c <f0+0x17cc>  // b.any
    cb8c:	17fffd1f 	b	c008 <f0+0x17b8>
    cb90:	72003c3f 	tst	w1, #0xffff
    cb94:	54ff9e81 	b.ne	bf64 <f0+0x1714>  // b.any
    cb98:	17fffcee 	b	bf50 <f0+0x1700>
    cb9c:	72003c3f 	tst	w1, #0xffff
    cba0:	54ffaf41 	b.ne	c188 <f0+0x1938>  // b.any
    cba4:	17fffd74 	b	c174 <f0+0x1924>
    cba8:	72003c3f 	tst	w1, #0xffff
    cbac:	54ffaa21 	b.ne	c0f0 <f0+0x18a0>  // b.any
    cbb0:	17fffd4b 	b	c0dc <f0+0x188c>
    cbb4:	72003c3f 	tst	w1, #0xffff
    cbb8:	54ffbaa1 	b.ne	c30c <f0+0x1abc>  // b.any
    cbbc:	17fffdcf 	b	c2f8 <f0+0x1aa8>
    cbc0:	72003c3f 	tst	w1, #0xffff
    cbc4:	54ffb5a1 	b.ne	c278 <f0+0x1a28>  // b.any
    cbc8:	17fffda7 	b	c264 <f0+0x1a14>
    cbcc:	72003c3f 	tst	w1, #0xffff
    cbd0:	54ffc341 	b.ne	c438 <f0+0x1be8>  // b.any
    cbd4:	17fffe14 	b	c424 <f0+0x1bd4>
    cbd8:	72003c3f 	tst	w1, #0xffff
    cbdc:	54ffbe41 	b.ne	c3a4 <f0+0x1b54>  // b.any
    cbe0:	17fffdec 	b	c390 <f0+0x1b40>
    cbe4:	72003c3f 	tst	w1, #0xffff
    cbe8:	54ffcee1 	b.ne	c5c4 <f0+0x1d74>  // b.any
    cbec:	17fffe71 	b	c5b0 <f0+0x1d60>
    cbf0:	72003c3f 	tst	w1, #0xffff
    cbf4:	54ffc8c1 	b.ne	c50c <f0+0x1cbc>  // b.any
    cbf8:	17fffe40 	b	c4f8 <f0+0x1ca8>
    cbfc:	72003c3f 	tst	w1, #0xffff
    cc00:	54ffdb61 	b.ne	c76c <f0+0x1f1c>  // b.any
    cc04:	17fffed5 	b	c758 <f0+0x1f08>
    cc08:	72003c3f 	tst	w1, #0xffff
    cc0c:	54ffd541 	b.ne	c6b4 <f0+0x1e64>  // b.any
    cc10:	17fffea4 	b	c6a0 <f0+0x1e50>
    cc14:	72003c3f 	tst	w1, #0xffff
    cc18:	54ffe501 	b.ne	c8b8 <f0+0x2068>  // b.any
    cc1c:	17ffff22 	b	c8a4 <f0+0x2054>
    cc20:	72003c3f 	tst	w1, #0xffff
    cc24:	54ffe001 	b.ne	c824 <f0+0x1fd4>  // b.any
    cc28:	17fffefa 	b	c810 <f0+0x1fc0>
    cc2c:	72003c3f 	tst	w1, #0xffff
    cc30:	54ffeec1 	b.ne	ca08 <f0+0x21b8>  // b.any
    cc34:	17ffff70 	b	c9f4 <f0+0x21a4>
    cc38:	72003c3f 	tst	w1, #0xffff
    cc3c:	54ffe8a1 	b.ne	c950 <f0+0x2100>  // b.any
    cc40:	17ffff3f 	b	c93c <f0+0x20ec>
    cc44:	72003c3f 	tst	w1, #0xffff
    cc48:	54ff3fa1 	b.ne	b43c <f0+0xbec>  // b.any
    cc4c:	17fff9f7 	b	b428 <f0+0xbd8>
    cc50:	72003c3f 	tst	w1, #0xffff
    cc54:	54ff3981 	b.ne	b384 <f0+0xb34>  // b.any
    cc58:	17fff9c6 	b	b370 <f0+0xb20>
    cc5c:	72003c3f 	tst	w1, #0xffff
    cc60:	54ff4dc1 	b.ne	b618 <f0+0xdc8>  // b.any
    cc64:	17fffa68 	b	b604 <f0+0xdb4>
    cc68:	72003c3f 	tst	w1, #0xffff
    cc6c:	54ff48a1 	b.ne	b580 <f0+0xd30>  // b.any
    cc70:	17fffa3f 	b	b56c <f0+0xd1c>
    cc74:	72003c3f 	tst	w1, #0xffff
    cc78:	54ff5881 	b.ne	b788 <f0+0xf38>  // b.any
    cc7c:	17fffabe 	b	b774 <f0+0xf24>
    cc80:	72003c3f 	tst	w1, #0xffff
    cc84:	54ff5261 	b.ne	b6d0 <f0+0xe80>  // b.any
    cc88:	17fffa8d 	b	b6bc <f0+0xe6c>
    cc8c:	72003c3f 	tst	w1, #0xffff
    cc90:	54ff6321 	b.ne	b8f4 <f0+0x10a4>  // b.any
    cc94:	17fffb13 	b	b8e0 <f0+0x1090>
    cc98:	72003c3f 	tst	w1, #0xffff
    cc9c:	54ff5e01 	b.ne	b85c <f0+0x100c>  // b.any
    cca0:	17fffaea 	b	b848 <f0+0xff8>
    cca4:	72003c3f 	tst	w1, #0xffff
    cca8:	54ff6de1 	b.ne	ba64 <f0+0x1214>  // b.any
    ccac:	17fffb69 	b	ba50 <f0+0x1200>
    ccb0:	72003c3f 	tst	w1, #0xffff
    ccb4:	54ff67c1 	b.ne	b9ac <f0+0x115c>  // b.any
    ccb8:	17fffb38 	b	b998 <f0+0x1148>
    ccbc:	72003c3f 	tst	w1, #0xffff
    ccc0:	54ff7881 	b.ne	bbd0 <f0+0x1380>  // b.any
    ccc4:	17fffbbe 	b	bbbc <f0+0x136c>
    ccc8:	72003c3f 	tst	w1, #0xffff
    cccc:	54ff7361 	b.ne	bb38 <f0+0x12e8>  // b.any
    ccd0:	17fffb95 	b	bb24 <f0+0x12d4>
    ccd4:	72003c3f 	tst	w1, #0xffff
    ccd8:	54ff8341 	b.ne	bd40 <f0+0x14f0>  // b.any
    ccdc:	17fffc14 	b	bd2c <f0+0x14dc>
    cce0:	72003c3f 	tst	w1, #0xffff
    cce4:	54ff7d21 	b.ne	bc88 <f0+0x1438>  // b.any
    cce8:	17fffbe3 	b	bc74 <f0+0x1424>
    ccec:	72003c3f 	tst	w1, #0xffff
    ccf0:	54ff8de1 	b.ne	beac <f0+0x165c>  // b.any
    ccf4:	17fffc69 	b	be98 <f0+0x1648>
    ccf8:	72003c3f 	tst	w1, #0xffff
    ccfc:	54ff88c1 	b.ne	be14 <f0+0x15c4>  // b.any
    cd00:	17fffc40 	b	be00 <f0+0x15b0>
    cd04:	aa1403e0 	mov	x0, x20
    cd08:	97ffdd22 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd0c:	17ffff3d 	b	ca00 <f0+0x21b0>
    cd10:	aa1503e0 	mov	x0, x21
    cd14:	97ffdd1f 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd18:	17fff758 	b	aa78 <f0+0x228>
    cd1c:	aa1703e0 	mov	x0, x23
    cd20:	97ffdd1c 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd24:	17fff852 	b	ae6c <f0+0x61c>
    cd28:	aa1703e0 	mov	x0, x23
    cd2c:	97ffdd19 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd30:	17fff87d 	b	af24 <f0+0x6d4>
    cd34:	aa1703e0 	mov	x0, x23
    cd38:	97ffdd16 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd3c:	17fff8a0 	b	afbc <f0+0x76c>
    cd40:	aa1703e0 	mov	x0, x23
    cd44:	97ffdd13 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd48:	17fff8d9 	b	b0ac <f0+0x85c>
    cd4c:	aa1703e0 	mov	x0, x23
    cd50:	97ffdd10 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd54:	17fff92e 	b	b20c <f0+0x9bc>
    cd58:	aa1703e0 	mov	x0, x23
    cd5c:	97ffdd0d 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd60:	17fff959 	b	b2c4 <f0+0xa74>
    cd64:	aa1703e0 	mov	x0, x23
    cd68:	97ffdd0a 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd6c:	17fff984 	b	b37c <f0+0xb2c>
    cd70:	aa1503e0 	mov	x0, x21
    cd74:	97ffdd07 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd78:	17fff9af 	b	b434 <f0+0xbe4>
    cd7c:	aa1703e0 	mov	x0, x23
    cd80:	97ffdd04 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd84:	17fff9fd 	b	b578 <f0+0xd28>
    cd88:	aa1703e0 	mov	x0, x23
    cd8c:	97ffdd01 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd90:	17fffa20 	b	b610 <f0+0xdc0>
    cd94:	aa1703e0 	mov	x0, x23
    cd98:	97ffdcfe 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd9c:	17fffa4b 	b	b6c8 <f0+0xe78>
    cda0:	aa1703e0 	mov	x0, x23
    cda4:	97ffdcfb 	bl	4190 <fwp_rc_forget_slot.part.0>
    cda8:	17fffa76 	b	b780 <f0+0xf30>
    cdac:	aa1703e0 	mov	x0, x23
    cdb0:	97ffdcf8 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdb4:	17fffaa8 	b	b854 <f0+0x1004>
    cdb8:	aa1703e0 	mov	x0, x23
    cdbc:	97ffdcf5 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdc0:	17fffacb 	b	b8ec <f0+0x109c>
    cdc4:	aa1703e0 	mov	x0, x23
    cdc8:	97ffdcf2 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdcc:	17fffaf6 	b	b9a4 <f0+0x1154>
    cdd0:	aa1703e0 	mov	x0, x23
    cdd4:	97ffdcef 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdd8:	17fffb21 	b	ba5c <f0+0x120c>
    cddc:	aa1703e0 	mov	x0, x23
    cde0:	97ffdcec 	bl	4190 <fwp_rc_forget_slot.part.0>
    cde4:	17fffb53 	b	bb30 <f0+0x12e0>
    cde8:	aa1703e0 	mov	x0, x23
    cdec:	97ffdce9 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdf0:	17fffb76 	b	bbc8 <f0+0x1378>
    cdf4:	aa1703e0 	mov	x0, x23
    cdf8:	97ffdce6 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdfc:	17fffba1 	b	bc80 <f0+0x1430>
    ce00:	aa1703e0 	mov	x0, x23
    ce04:	97ffdce3 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce08:	17fffbcc 	b	bd38 <f0+0x14e8>
    ce0c:	aa1703e0 	mov	x0, x23
    ce10:	97ffdce0 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce14:	17fffbfe 	b	be0c <f0+0x15bc>
    ce18:	aa1703e0 	mov	x0, x23
    ce1c:	97ffdcdd 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce20:	17fffc21 	b	bea4 <f0+0x1654>
    ce24:	aa1703e0 	mov	x0, x23
    ce28:	97ffdcda 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce2c:	17fffc4c 	b	bf5c <f0+0x170c>
    ce30:	aa1703e0 	mov	x0, x23
    ce34:	97ffdcd7 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce38:	17fffc77 	b	c014 <f0+0x17c4>
    ce3c:	aa1703e0 	mov	x0, x23
    ce40:	97ffdcd4 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce44:	17fffca9 	b	c0e8 <f0+0x1898>
    ce48:	aa1703e0 	mov	x0, x23
    ce4c:	97ffdcd1 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce50:	17fffccc 	b	c180 <f0+0x1930>
    ce54:	aa1703e0 	mov	x0, x23
    ce58:	97ffdcce 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce5c:	17fffd05 	b	c270 <f0+0x1a20>
    ce60:	aa1703e0 	mov	x0, x23
    ce64:	97ffdccb 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce68:	17fffd27 	b	c304 <f0+0x1ab4>
    ce6c:	aa1703e0 	mov	x0, x23
    ce70:	97ffdcc8 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce74:	17fffd4a 	b	c39c <f0+0x1b4c>
    ce78:	aa1703e0 	mov	x0, x23
    ce7c:	97ffdcc5 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce80:	17fffd6c 	b	c430 <f0+0x1be0>
    ce84:	aa1703e0 	mov	x0, x23
    ce88:	97ffdcc2 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce8c:	17fffd9e 	b	c504 <f0+0x1cb4>
    ce90:	aa1703e0 	mov	x0, x23
    ce94:	97ffdcbf 	bl	4190 <fwp_rc_forget_slot.part.0>
    ce98:	17fffdc9 	b	c5bc <f0+0x1d6c>
    ce9c:	aa1703e0 	mov	x0, x23
    cea0:	97ffdcbc 	bl	4190 <fwp_rc_forget_slot.part.0>
    cea4:	17fffe02 	b	c6ac <f0+0x1e5c>
    cea8:	aa1703e0 	mov	x0, x23
    ceac:	97ffdcb9 	bl	4190 <fwp_rc_forget_slot.part.0>
    ceb0:	17fffe2d 	b	c764 <f0+0x1f14>
    ceb4:	aa1703e0 	mov	x0, x23
    ceb8:	97ffdcb6 	bl	4190 <fwp_rc_forget_slot.part.0>
    cebc:	17fffe58 	b	c81c <f0+0x1fcc>
    cec0:	aa1703e0 	mov	x0, x23
    cec4:	97ffdcb3 	bl	4190 <fwp_rc_forget_slot.part.0>
    cec8:	17fffe7a 	b	c8b0 <f0+0x2060>
    cecc:	aa1703e0 	mov	x0, x23
    ced0:	97ffdcb0 	bl	4190 <fwp_rc_forget_slot.part.0>
    ced4:	17fffe9d 	b	c948 <f0+0x20f8>
    ced8:	97ffd66a 	bl	2880 <__stack_chk_fail@plt>
    cedc:	97ffd67d 	bl	28d0 <abort@plt>

000000000000cee0 <fwp_main_thread>:
    cee0:	d10443ff 	sub	sp, sp, #0x110
    cee4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cee8:	f947f400 	ldr	x0, [x0, #4072]
    ceec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cef0:	910303fd 	add	x29, sp, #0xc0
    cef4:	a90d53f3 	stp	x19, x20, [sp, #208]
    cef8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    cefc:	91174261 	add	x1, x19, #0x5d0
    cf00:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cf04:	b953a421 	ldr	w1, [x1, #5028]
    cf08:	f9400002 	ldr	x2, [x0]
    cf0c:	f9005fe2 	str	x2, [sp, #184]
    cf10:	d2800002 	mov	x2, #0x0                   	// #0
    cf14:	34000ea1 	cbz	w1, d0e8 <fwp_main_thread+0x208>
    cf18:	91174273 	add	x19, x19, #0x5d0
    cf1c:	b953aa60 	ldr	w0, [x19, #5032]
    cf20:	35000dc0 	cbnz	w0, d0d8 <fwp_main_thread+0x1f8>
    cf24:	91001fe2 	add	x2, sp, #0x7
    cf28:	900000b4 	adrp	x20, 20000 <__data_start>
    cf2c:	900000a3 	adrp	x3, 20000 <__data_start>
    cf30:	9101c293 	add	x19, x20, #0x70
    cf34:	910fc063 	add	x3, x3, #0x3f0
    cf38:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cf3c:	d2a00025 	mov	x5, #0x10000               	// #65536
    cf40:	910023e0 	add	x0, sp, #0x8
    cf44:	d2800001 	mov	x1, #0x0                   	// #0
    cf48:	f90007e3 	str	x3, [sp, #8]
    cf4c:	b90013ff 	str	wzr, [sp, #16]
    cf50:	a9019262 	stp	x2, x4, [x19, #24]
    cf54:	f9000fe5 	str	x5, [sp, #24]
    cf58:	97ffd5e2 	bl	26e0 <sigaltstack@plt>
    cf5c:	35000220 	cbnz	w0, cfa0 <fwp_main_thread+0xc0>
    cf60:	4f000400 	movi	v0.4s, #0x0
    cf64:	9100a3e0 	add	x0, sp, #0x28
    cf68:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    cf6c:	52800082 	mov	w2, #0x4                   	// #4
    cf70:	9101c021 	add	x1, x1, #0x70
    cf74:	72a10002 	movk	w2, #0x800, lsl #16
    cf78:	910083f5 	add	x21, sp, #0x20
    cf7c:	f90013e1 	str	x1, [sp, #32]
    cf80:	3d802000 	str	q0, [x0, #128]
    cf84:	b900abe2 	str	w2, [sp, #168]
    cf88:	ad000000 	stp	q0, q0, [x0]
    cf8c:	ad010000 	stp	q0, q0, [x0, #32]
    cf90:	ad020000 	stp	q0, q0, [x0, #64]
    cf94:	ad030000 	stp	q0, q0, [x0, #96]
    cf98:	97ffd62a 	bl	2840 <sigemptyset@plt>
    cf9c:	340000c0 	cbz	w0, cfb4 <fwp_main_thread+0xd4>
    cfa0:	d0000000 	adrp	x0, e000 <_IO_stdin_used+0x4c0>
    cfa4:	9106c000 	add	x0, x0, #0x1b0
    cfa8:	a90f63f7 	stp	x23, x24, [sp, #240]
    cfac:	f90083f9 	str	x25, [sp, #256]
    cfb0:	97ffdc58 	bl	4110 <fwp_trap>
    cfb4:	aa1503e1 	mov	x1, x21
    cfb8:	d2800002 	mov	x2, #0x0                   	// #0
    cfbc:	52800160 	mov	w0, #0xb                   	// #11
    cfc0:	97ffd638 	bl	28a0 <sigaction@plt>
    cfc4:	35fffee0 	cbnz	w0, cfa0 <fwp_main_thread+0xc0>
    cfc8:	aa1503e1 	mov	x1, x21
    cfcc:	d2800002 	mov	x2, #0x0                   	// #0
    cfd0:	528000e0 	mov	w0, #0x7                   	// #7
    cfd4:	97ffd633 	bl	28a0 <sigaction@plt>
    cfd8:	35fffe40 	cbnz	w0, cfa0 <fwp_main_thread+0xc0>
    cfdc:	b9434a60 	ldr	w0, [x19, #840]
    cfe0:	34000880 	cbz	w0, d0f0 <fwp_main_thread+0x210>
    cfe4:	a90f63f7 	stp	x23, x24, [sp, #240]
    cfe8:	9101c293 	add	x19, x20, #0x70
    cfec:	b9434e60 	ldr	w0, [x19, #844]
    cff0:	34001e80 	cbz	w0, d3c0 <fwp_main_thread+0x4e0>
    cff4:	9101c296 	add	x22, x20, #0x70
    cff8:	f9400ad5 	ldr	x21, [x22, #16]
    cffc:	b4000d95 	cbz	x21, d1ac <fwp_main_thread+0x2cc>
    d000:	910102b7 	add	x23, x21, #0x40
    d004:	f90083f9 	str	x25, [sp, #256]
    d008:	52800038 	mov	w24, #0x1                   	// #1
    d00c:	39414ab9 	ldrb	w25, [x21, #82]
    d010:	39014ab8 	strb	w24, [x21, #82]
    d014:	d503201f 	nop
    d018:	f94016a0 	ldr	x0, [x21, #40]
    d01c:	b4000c40 	cbz	x0, d1a4 <fwp_main_thread+0x2c4>
    d020:	f94032a1 	ldr	x1, [x21, #96]
    d024:	394146a0 	ldrb	w0, [x21, #81]
    d028:	b4000861 	cbz	x1, d134 <fwp_main_thread+0x254>
    d02c:	36000720 	tbz	w0, #0, d110 <fwp_main_thread+0x230>
    d030:	f9400ad3 	ldr	x19, [x22, #16]
    d034:	f94022a0 	ldr	x0, [x21, #64]
    d038:	39414a61 	ldrb	w1, [x19, #82]
    d03c:	37000a41 	tbnz	w1, #0, d184 <fwp_main_thread+0x2a4>
    d040:	f9403261 	ldr	x1, [x19, #96]
    d044:	a911fe77 	stp	x23, xzr, [x19, #280]
    d048:	f9009660 	str	x0, [x19, #296]
    d04c:	b4000040 	cbz	x0, d054 <fwp_main_thread+0x174>
    d050:	f9009013 	str	x19, [x0, #288]
    d054:	f90022b3 	str	x19, [x21, #64]
    d058:	b4000101 	cbz	x1, d078 <fwp_main_thread+0x198>
    d05c:	f9406ec0 	ldr	x0, [x22, #216]
    d060:	39015678 	strb	w24, [x19, #85]
    d064:	f9003661 	str	x1, [x19, #104]
    d068:	a910827f 	stp	xzr, x0, [x19, #264]
    d06c:	b4000040 	cbz	x0, d074 <fwp_main_thread+0x194>
    d070:	f9008413 	str	x19, [x0, #264]
    d074:	f9006ed3 	str	x19, [x22, #216]
    d078:	39015a7f 	strb	wzr, [x19, #86]
    d07c:	97ffe6b5 	bl	6b50 <fwp_block>
    d080:	f9408e62 	ldr	x2, [x19, #280]
    d084:	b4000142 	cbz	x2, d0ac <fwp_main_thread+0x1cc>
    d088:	a9520261 	ldp	x1, x0, [x19, #288]
    d08c:	b4000881 	cbz	x1, d19c <fwp_main_thread+0x2bc>
    d090:	f9009420 	str	x0, [x1, #296]
    d094:	f9409660 	ldr	x0, [x19, #296]
    d098:	b4000040 	cbz	x0, d0a0 <fwp_main_thread+0x1c0>
    d09c:	f9009001 	str	x1, [x0, #288]
    d0a0:	91080260 	add	x0, x19, #0x200
    d0a4:	f900967f 	str	xzr, [x19, #296]
    d0a8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    d0ac:	39415660 	ldrb	w0, [x19, #85]
    d0b0:	3607fb40 	tbz	w0, #0, d018 <fwp_main_thread+0x138>
    d0b4:	a9508261 	ldp	x1, x0, [x19, #264]
    d0b8:	b4001801 	cbz	x1, d3b8 <fwp_main_thread+0x4d8>
    d0bc:	f9008820 	str	x0, [x1, #272]
    d0c0:	b4000040 	cbz	x0, d0c8 <fwp_main_thread+0x1e8>
    d0c4:	f9008401 	str	x1, [x0, #264]
    d0c8:	91080260 	add	x0, x19, #0x200
    d0cc:	3901567f 	strb	wzr, [x19, #85]
    d0d0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    d0d4:	17ffffd1 	b	d018 <fwp_main_thread+0x138>
    d0d8:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    d0dc:	91301000 	add	x0, x0, #0xc04
    d0e0:	9400028c 	bl	db10 <atexit>
    d0e4:	17ffff90 	b	cf24 <fwp_main_thread+0x44>
    d0e8:	97ffdb22 	bl	3d70 <fwp_heap_init>
    d0ec:	17ffff8b 	b	cf18 <fwp_main_thread+0x38>
    d0f0:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    d0f4:	91058000 	add	x0, x0, #0x160
    d0f8:	94000286 	bl	db10 <atexit>
    d0fc:	a90f63f7 	stp	x23, x24, [sp, #240]
    d100:	35001860 	cbnz	w0, d40c <fwp_main_thread+0x52c>
    d104:	52800020 	mov	w0, #0x1                   	// #1
    d108:	b9034a60 	str	w0, [x19, #840]
    d10c:	17ffffb7 	b	cfe8 <fwp_main_thread+0x108>
    d110:	97ffde20 	bl	4990 <fwp_now_ns>
    d114:	f94032a1 	ldr	x1, [x21, #96]
    d118:	eb01001f 	cmp	x0, x1
    d11c:	540000ab 	b.lt	d130 <fwp_main_thread+0x250>  // b.tstop
    d120:	394142a0 	ldrb	w0, [x21, #80]
    d124:	37000060 	tbnz	w0, #0, d130 <fwp_main_thread+0x250>
    d128:	aa1503e0 	mov	x0, x21
    d12c:	97ffd971 	bl	36f0 <fwp_cancel_tree.part.0>
    d130:	394146a0 	ldrb	w0, [x21, #81]
    d134:	f9400ad3 	ldr	x19, [x22, #16]
    d138:	39414a62 	ldrb	w2, [x19, #82]
    d13c:	3707f7a0 	tbnz	w0, #0, d030 <fwp_main_thread+0x150>
    d140:	f94032a1 	ldr	x1, [x21, #96]
    d144:	370001c2 	tbnz	w2, #0, d17c <fwp_main_thread+0x29c>
    d148:	f9403260 	ldr	x0, [x19, #96]
    d14c:	b4000180 	cbz	x0, d17c <fwp_main_thread+0x29c>
    d150:	b4000061 	cbz	x1, d15c <fwp_main_thread+0x27c>
    d154:	eb01001f 	cmp	x0, x1
    d158:	9a81d000 	csel	x0, x0, x1, le
    d15c:	f94022a1 	ldr	x1, [x21, #64]
    d160:	a911fe77 	stp	x23, xzr, [x19, #280]
    d164:	f9009661 	str	x1, [x19, #296]
    d168:	b4001361 	cbz	x1, d3d4 <fwp_main_thread+0x4f4>
    d16c:	f9009033 	str	x19, [x1, #288]
    d170:	aa0003e1 	mov	x1, x0
    d174:	f90022b3 	str	x19, [x21, #64]
    d178:	17ffffb9 	b	d05c <fwp_main_thread+0x17c>
    d17c:	f94022a0 	ldr	x0, [x21, #64]
    d180:	17ffffb1 	b	d044 <fwp_main_thread+0x164>
    d184:	a911fe77 	stp	x23, xzr, [x19, #280]
    d188:	f9009660 	str	x0, [x19, #296]
    d18c:	b4000040 	cbz	x0, d194 <fwp_main_thread+0x2b4>
    d190:	f9009013 	str	x19, [x0, #288]
    d194:	f90022b3 	str	x19, [x21, #64]
    d198:	17ffffb8 	b	d078 <fwp_main_thread+0x198>
    d19c:	f9000040 	str	x0, [x2]
    d1a0:	17ffffbe 	b	d098 <fwp_main_thread+0x1b8>
    d1a4:	39014ab9 	strb	w25, [x21, #82]
    d1a8:	f94083f9 	ldr	x25, [sp, #256]
    d1ac:	9101c293 	add	x19, x20, #0x70
    d1b0:	f9419660 	ldr	x0, [x19, #808]
    d1b4:	b5000060 	cbnz	x0, d1c0 <fwp_main_thread+0x2e0>
    d1b8:	f9419e60 	ldr	x0, [x19, #824]
    d1bc:	b4001120 	cbz	x0, d3e0 <fwp_main_thread+0x500>
    d1c0:	9101c280 	add	x0, x20, #0x70
    d1c4:	f9400800 	ldr	x0, [x0, #16]
    d1c8:	9101c281 	add	x1, x20, #0x70
    d1cc:	f941b026 	ldr	x6, [x1, #864]
    d1d0:	b903583f 	str	wzr, [x1, #856]
    d1d4:	eb0000df 	cmp	x6, x0
    d1d8:	540011e1 	b.ne	d414 <fwp_main_thread+0x534>  // b.any
    d1dc:	b40003c0 	cbz	x0, d254 <fwp_main_thread+0x374>
    d1e0:	f9418025 	ldr	x5, [x1, #768]
    d1e4:	52800021 	mov	w1, #0x1                   	// #1
    d1e8:	39014801 	strb	w1, [x0, #82]
    d1ec:	b4000345 	cbz	x5, d254 <fwp_main_thread+0x374>
    d1f0:	394140a0 	ldrb	w0, [x5, #80]
    d1f4:	37000060 	tbnz	w0, #0, d200 <fwp_main_thread+0x320>
    d1f8:	aa0503e0 	mov	x0, x5
    d1fc:	97ffd93d 	bl	36f0 <fwp_cancel_tree.part.0>
    d200:	f9409ca5 	ldr	x5, [x5, #312]
    d204:	b5ffff65 	cbnz	x5, d1f0 <fwp_main_thread+0x310>
    d208:	9101c293 	add	x19, x20, #0x70
    d20c:	52800035 	mov	w21, #0x1                   	// #1
    d210:	f94028c0 	ldr	x0, [x6, #80]
    d214:	f2001c1f 	tst	x0, #0xff000000ff
    d218:	540000e1 	b.ne	d234 <fwp_main_thread+0x354>  // b.any
    d21c:	f9403e60 	ldr	x0, [x19, #120]
    d220:	390150d5 	strb	w21, [x6, #84]
    d224:	f90080df 	str	xzr, [x6, #256]
    d228:	b4000120 	cbz	x0, d24c <fwp_main_thread+0x36c>
    d22c:	f9008006 	str	x6, [x0, #256]
    d230:	f9003e66 	str	x6, [x19, #120]
    d234:	97ffe647 	bl	6b50 <fwp_block>
    d238:	97ffe5ce 	bl	6970 <fwp_free_zombie>
    d23c:	f9418260 	ldr	x0, [x19, #768]
    d240:	b40000a0 	cbz	x0, d254 <fwp_main_thread+0x374>
    d244:	f941b266 	ldr	x6, [x19, #864]
    d248:	17fffff2 	b	d210 <fwp_main_thread+0x330>
    d24c:	f9004266 	str	x6, [x19, #128]
    d250:	17fffff8 	b	d230 <fwp_main_thread+0x350>
    d254:	9101c295 	add	x21, x20, #0x70
    d258:	97ffe5c6 	bl	6970 <fwp_free_zombie>
    d25c:	f94042a0 	ldr	x0, [x21, #128]
    d260:	b5000da0 	cbnz	x0, d414 <fwp_main_thread+0x534>
    d264:	f9406ea0 	ldr	x0, [x21, #216]
    d268:	b5000d60 	cbnz	x0, d414 <fwp_main_thread+0x534>
    d26c:	b940fab3 	ldr	w19, [x21, #248]
    d270:	340001f3 	cbz	w19, d2ac <fwp_main_thread+0x3cc>
    d274:	93407e76 	sxtw	x22, w19
    d278:	51000673 	sub	w19, w19, #0x1
    d27c:	d1000ad6 	sub	x22, x22, #0x2
    d280:	910402b7 	add	x23, x21, #0x100
    d284:	cb3342d6 	sub	x22, x22, w19, uxtw
    d288:	93407e73 	sxtw	x19, w19
    d28c:	d503201f 	nop
    d290:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    d294:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d298:	b900fab3 	str	w19, [x21, #248]
    d29c:	d1000673 	sub	x19, x19, #0x1
    d2a0:	97ffd5c0 	bl	29a0 <munmap@plt>
    d2a4:	eb1302df 	cmp	x22, x19
    d2a8:	54ffff41 	b.ne	d290 <fwp_main_thread+0x3b0>  // b.any
    d2ac:	f0000093 	adrp	x19, 20000 <__data_start>
    d2b0:	91004260 	add	x0, x19, #0x10
    d2b4:	b9404800 	ldr	w0, [x0, #72]
    d2b8:	37f80040 	tbnz	w0, #31, d2c0 <fwp_main_thread+0x3e0>
    d2bc:	97ffd575 	bl	2890 <close@plt>
    d2c0:	9101c295 	add	x21, x20, #0x70
    d2c4:	91004273 	add	x19, x19, #0x10
    d2c8:	12800001 	mov	w1, #0xffffffff            	// #-1
    d2cc:	f941baa0 	ldr	x0, [x21, #880]
    d2d0:	b9004a61 	str	w1, [x19, #72]
    d2d4:	f941b6a1 	ldr	x1, [x21, #872]
    d2d8:	b40001c0 	cbz	x0, d310 <fwp_main_thread+0x430>
    d2dc:	d2800013 	mov	x19, #0x0                   	// #0
    d2e0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    d2e4:	b40000e0 	cbz	x0, d300 <fwp_main_thread+0x420>
    d2e8:	f9400001 	ldr	x1, [x0]
    d2ec:	b5000941 	cbnz	x1, d414 <fwp_main_thread+0x534>
    d2f0:	f9400401 	ldr	x1, [x0, #8]
    d2f4:	b5000901 	cbnz	x1, d414 <fwp_main_thread+0x534>
    d2f8:	97ffdc42 	bl	4400 <fwp_mem_free>
    d2fc:	f941b6a1 	ldr	x1, [x21, #872]
    d300:	91000673 	add	x19, x19, #0x1
    d304:	f941baa0 	ldr	x0, [x21, #880]
    d308:	eb00027f 	cmp	x19, x0
    d30c:	54fffea3 	b.cc	d2e0 <fwp_main_thread+0x400>  // b.lo, b.ul, b.last
    d310:	aa0103e0 	mov	x0, x1
    d314:	97ffdc3b 	bl	4400 <fwp_mem_free>
    d318:	9101c280 	add	x0, x20, #0x70
    d31c:	f941b013 	ldr	x19, [x0, #864]
    d320:	f901b41f 	str	xzr, [x0, #872]
    d324:	f901b81f 	str	xzr, [x0, #880]
    d328:	b40001f3 	cbz	x19, d364 <fwp_main_thread+0x484>
    d32c:	f9401661 	ldr	x1, [x19, #40]
    d330:	b5000721 	cbnz	x1, d414 <fwp_main_thread+0x534>
    d334:	f9405661 	ldr	x1, [x19, #168]
    d338:	b50006e1 	cbnz	x1, d414 <fwp_main_thread+0x534>
    d33c:	f9419401 	ldr	x1, [x0, #808]
    d340:	b50006a1 	cbnz	x1, d414 <fwp_main_thread+0x534>
    d344:	f9419c00 	ldr	x0, [x0, #824]
    d348:	b5000660 	cbnz	x0, d414 <fwp_main_thread+0x534>
    d34c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d350:	f0000100 	adrp	x0, 30000 <alt.5+0xfc10>
    d354:	910fc000 	add	x0, x0, #0x3f0
    d358:	97ffd53e 	bl	2850 <memset@plt>
    d35c:	aa1303e0 	mov	x0, x19
    d360:	97ffdc28 	bl	4400 <fwp_mem_free>
    d364:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    d368:	f947ec00 	ldr	x0, [x0, #4056]
    d36c:	9101c294 	add	x20, x20, #0x70
    d370:	f9400000 	ldr	x0, [x0]
    d374:	f9000a9f 	str	xzr, [x20, #16]
    d378:	f901b29f 	str	xzr, [x20, #864]
    d37c:	97ffd58d 	bl	29b0 <fflush@plt>
    d380:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    d384:	f947f400 	ldr	x0, [x0, #4072]
    d388:	f9405fe2 	ldr	x2, [sp, #184]
    d38c:	f9400001 	ldr	x1, [x0]
    d390:	eb010042 	subs	x2, x2, x1
    d394:	d2800001 	mov	x1, #0x0                   	// #0
    d398:	54000361 	b.ne	d404 <fwp_main_thread+0x524>  // b.any
    d39c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d3a0:	d2800000 	mov	x0, #0x0                   	// #0
    d3a4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d3a8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d3ac:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d3b0:	910443ff 	add	sp, sp, #0x110
    d3b4:	d65f03c0 	ret
    d3b8:	f9006ec0 	str	x0, [x22, #216]
    d3bc:	17ffff41 	b	d0c0 <fwp_main_thread+0x1e0>
    d3c0:	97fff524 	bl	a850 <f0>
    d3c4:	f901aa60 	str	x0, [x19, #848]
    d3c8:	52800021 	mov	w1, #0x1                   	// #1
    d3cc:	b9034e61 	str	w1, [x19, #844]
    d3d0:	17ffff09 	b	cff4 <fwp_main_thread+0x114>
    d3d4:	aa0003e1 	mov	x1, x0
    d3d8:	f90022b3 	str	x19, [x21, #64]
    d3dc:	17ffff20 	b	d05c <fwp_main_thread+0x17c>
    d3e0:	f9419260 	ldr	x0, [x19, #800]
    d3e4:	97ffdc07 	bl	4400 <fwp_mem_free>
    d3e8:	f901927f 	str	xzr, [x19, #800]
    d3ec:	f9400a60 	ldr	x0, [x19, #16]
    d3f0:	f9019a7f 	str	xzr, [x19, #816]
    d3f4:	b4ffeea0 	cbz	x0, d1c8 <fwp_main_thread+0x2e8>
    d3f8:	f900541f 	str	xzr, [x0, #168]
    d3fc:	f9005c1f 	str	xzr, [x0, #184]
    d400:	17ffff72 	b	d1c8 <fwp_main_thread+0x2e8>
    d404:	f90083f9 	str	x25, [sp, #256]
    d408:	97ffd51e 	bl	2880 <__stack_chk_fail@plt>
    d40c:	f90083f9 	str	x25, [sp, #256]
    d410:	97ffd748 	bl	3130 <descent_phase_fail>
    d414:	f90083f9 	str	x25, [sp, #256]
    d418:	97ffd52e 	bl	28d0 <abort@plt>
    d41c:	d503201f 	nop

000000000000d420 <__divti3>:
    d420:	d503245f 	bti	c
    d424:	d2800004 	mov	x4, #0x0                   	// #0
    d428:	b7f80721 	tbnz	x1, #63, d50c <__divti3+0xec>
    d42c:	b6f80083 	tbz	x3, #63, d43c <__divti3+0x1c>
    d430:	eb0203e2 	negs	x2, x2
    d434:	aa2403e4 	mvn	x4, x4
    d438:	da0303e3 	ngc	x3, x3
    d43c:	aa0203e6 	mov	x6, x2
    d440:	aa0003e7 	mov	x7, x0
    d444:	aa0103e5 	mov	x5, x1
    d448:	b5000583 	cbnz	x3, d4f8 <__divti3+0xd8>
    d44c:	eb01005f 	cmp	x2, x1
    d450:	54000e69 	b.ls	d61c <__divti3+0x1fc>  // b.plast
    d454:	dac01040 	clz	x0, x2
    d458:	b40000e0 	cbz	x0, d474 <__divti3+0x54>
    d45c:	4b0003e1 	neg	w1, w0
    d460:	9ac020a5 	lsl	x5, x5, x0
    d464:	9ac02046 	lsl	x6, x2, x0
    d468:	9ac124e1 	lsr	x1, x7, x1
    d46c:	aa050025 	orr	x5, x1, x5
    d470:	9ac020e7 	lsl	x7, x7, x0
    d474:	d360fcc8 	lsr	x8, x6, #32
    d478:	92407cc2 	and	x2, x6, #0xffffffff
    d47c:	9ac808a3 	udiv	x3, x5, x8
    d480:	9b089465 	msub	x5, x3, x8, x5
    d484:	aa0303e0 	mov	x0, x3
    d488:	9b037c41 	mul	x1, x2, x3
    d48c:	93c780a5 	extr	x5, x5, x7, #32
    d490:	eb05003f 	cmp	x1, x5
    d494:	540000a9 	b.ls	d4a8 <__divti3+0x88>  // b.plast
    d498:	ab0500c5 	adds	x5, x6, x5
    d49c:	d1000460 	sub	x0, x3, #0x1
    d4a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d4a4:	540015a8 	b.hi	d758 <__divti3+0x338>  // b.pmore
    d4a8:	cb0100a5 	sub	x5, x5, x1
    d4ac:	9ac808a3 	udiv	x3, x5, x8
    d4b0:	9b089465 	msub	x5, x3, x8, x5
    d4b4:	aa0303e1 	mov	x1, x3
    d4b8:	9b037c42 	mul	x2, x2, x3
    d4bc:	aa0703e3 	mov	x3, x7
    d4c0:	b3607ca3 	bfi	x3, x5, #32, #32
    d4c4:	eb03005f 	cmp	x2, x3
    d4c8:	540000c9 	b.ls	d4e0 <__divti3+0xc0>  // b.plast
    d4cc:	ab0300c3 	adds	x3, x6, x3
    d4d0:	d1000425 	sub	x5, x1, #0x1
    d4d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d4d8:	d1000821 	sub	x1, x1, #0x2
    d4dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d4e0:	aa008020 	orr	x0, x1, x0, lsl #32
    d4e4:	d2800001 	mov	x1, #0x0                   	// #0
    d4e8:	b4000064 	cbz	x4, d4f4 <__divti3+0xd4>
    d4ec:	eb0003e0 	negs	x0, x0
    d4f0:	da0103e1 	ngc	x1, x1
    d4f4:	d65f03c0 	ret
    d4f8:	eb01007f 	cmp	x3, x1
    d4fc:	54000109 	b.ls	d51c <__divti3+0xfc>  // b.plast
    d500:	d2800001 	mov	x1, #0x0                   	// #0
    d504:	d2800000 	mov	x0, #0x0                   	// #0
    d508:	17fffff8 	b	d4e8 <__divti3+0xc8>
    d50c:	eb0003e0 	negs	x0, x0
    d510:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d514:	da0103e1 	ngc	x1, x1
    d518:	17ffffc5 	b	d42c <__divti3+0xc>
    d51c:	dac01067 	clz	x7, x3
    d520:	b40010e7 	cbz	x7, d73c <__divti3+0x31c>
    d524:	d2800805 	mov	x5, #0x40                  	// #64
    d528:	cb0700a5 	sub	x5, x5, x7
    d52c:	9ac72063 	lsl	x3, x3, x7
    d530:	9ac52448 	lsr	x8, x2, x5
    d534:	aa030108 	orr	x8, x8, x3
    d538:	9ac52426 	lsr	x6, x1, x5
    d53c:	92407d0a 	and	x10, x8, #0xffffffff
    d540:	d360fd09 	lsr	x9, x8, #32
    d544:	9ac52403 	lsr	x3, x0, x5
    d548:	9ac72021 	lsl	x1, x1, x7
    d54c:	aa010063 	orr	x3, x3, x1
    d550:	9ac72042 	lsl	x2, x2, x7
    d554:	9ac908cb 	udiv	x11, x6, x9
    d558:	9b099965 	msub	x5, x11, x9, x6
    d55c:	aa0b03e1 	mov	x1, x11
    d560:	9b0b7d46 	mul	x6, x10, x11
    d564:	93c380a5 	extr	x5, x5, x3, #32
    d568:	eb0500df 	cmp	x6, x5
    d56c:	540000a9 	b.ls	d580 <__divti3+0x160>  // b.plast
    d570:	ab050105 	adds	x5, x8, x5
    d574:	d1000561 	sub	x1, x11, #0x1
    d578:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d57c:	54000f48 	b.hi	d764 <__divti3+0x344>  // b.pmore
    d580:	cb0600a6 	sub	x6, x5, x6
    d584:	9ac908cb 	udiv	x11, x6, x9
    d588:	9b099969 	msub	x9, x11, x9, x6
    d58c:	aa0b03e5 	mov	x5, x11
    d590:	9b0b7d4a 	mul	x10, x10, x11
    d594:	b3607d23 	bfi	x3, x9, #32, #32
    d598:	eb03015f 	cmp	x10, x3
    d59c:	540000a9 	b.ls	d5b0 <__divti3+0x190>  // b.plast
    d5a0:	ab030103 	adds	x3, x8, x3
    d5a4:	d1000565 	sub	x5, x11, #0x1
    d5a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d5ac:	54000e28 	b.hi	d770 <__divti3+0x350>  // b.pmore
    d5b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d5b4:	92407c48 	and	x8, x2, #0xffffffff
    d5b8:	2a0503e5 	mov	w5, w5
    d5bc:	d360fc42 	lsr	x2, x2, #32
    d5c0:	d360fc26 	lsr	x6, x1, #32
    d5c4:	cb0a0063 	sub	x3, x3, x10
    d5c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d5cc:	9b087caa 	mul	x10, x5, x8
    d5d0:	9b087cc8 	mul	x8, x6, x8
    d5d4:	9b0220a5 	madd	x5, x5, x2, x8
    d5d8:	9b027cc6 	mul	x6, x6, x2
    d5dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d5e0:	8b0900c5 	add	x5, x6, x9
    d5e4:	eb02011f 	cmp	x8, x2
    d5e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d5ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    d5f0:	eb06007f 	cmp	x3, x6
    d5f4:	540000e3 	b.cc	d610 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d5f8:	92407d4a 	and	x10, x10, #0xffffffff
    d5fc:	9ac72000 	lsl	x0, x0, x7
    d600:	8b028142 	add	x2, x10, x2, lsl #32
    d604:	eb02001f 	cmp	x0, x2
    d608:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d60c:	54000a01 	b.ne	d74c <__divti3+0x32c>  // b.any
    d610:	d1000420 	sub	x0, x1, #0x1
    d614:	d2800001 	mov	x1, #0x0                   	// #0
    d618:	17ffffb4 	b	d4e8 <__divti3+0xc8>
    d61c:	b5000062 	cbnz	x2, d628 <__divti3+0x208>
    d620:	d2800022 	mov	x2, #0x1                   	// #1
    d624:	9ac30846 	udiv	x6, x2, x3
    d628:	dac010c8 	clz	x8, x6
    d62c:	b5000408 	cbnz	x8, d6ac <__divti3+0x28c>
    d630:	d360fcc9 	lsr	x9, x6, #32
    d634:	92407cc5 	and	x5, x6, #0xffffffff
    d638:	cb060023 	sub	x3, x1, x6
    d63c:	d2800021 	mov	x1, #0x1                   	// #1
    d640:	9ac90868 	udiv	x8, x3, x9
    d644:	9b098d03 	msub	x3, x8, x9, x3
    d648:	aa0803e0 	mov	x0, x8
    d64c:	9b057d02 	mul	x2, x8, x5
    d650:	93c78063 	extr	x3, x3, x7, #32
    d654:	eb03005f 	cmp	x2, x3
    d658:	540000a9 	b.ls	d66c <__divti3+0x24c>  // b.plast
    d65c:	ab0300c3 	adds	x3, x6, x3
    d660:	d1000500 	sub	x0, x8, #0x1
    d664:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d668:	54000968 	b.hi	d794 <__divti3+0x374>  // b.pmore
    d66c:	cb020063 	sub	x3, x3, x2
    d670:	9ac90862 	udiv	x2, x3, x9
    d674:	aa0203e8 	mov	x8, x2
    d678:	9b098c42 	msub	x2, x2, x9, x3
    d67c:	aa0703e3 	mov	x3, x7
    d680:	9b057d05 	mul	x5, x8, x5
    d684:	b3607c43 	bfi	x3, x2, #32, #32
    d688:	eb0300bf 	cmp	x5, x3
    d68c:	540000c9 	b.ls	d6a4 <__divti3+0x284>  // b.plast
    d690:	ab0300c2 	adds	x2, x6, x3
    d694:	d1000503 	sub	x3, x8, #0x1
    d698:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d69c:	d1000908 	sub	x8, x8, #0x2
    d6a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d6a4:	aa008100 	orr	x0, x8, x0, lsl #32
    d6a8:	17ffff90 	b	d4e8 <__divti3+0xc8>
    d6ac:	9ac820c6 	lsl	x6, x6, x8
    d6b0:	d2800803 	mov	x3, #0x40                  	// #64
    d6b4:	cb080063 	sub	x3, x3, x8
    d6b8:	d360fcc9 	lsr	x9, x6, #32
    d6bc:	9ac82027 	lsl	x7, x1, x8
    d6c0:	92407cc5 	and	x5, x6, #0xffffffff
    d6c4:	9ac32422 	lsr	x2, x1, x3
    d6c8:	9ac32403 	lsr	x3, x0, x3
    d6cc:	aa070063 	orr	x3, x3, x7
    d6d0:	9ac9084a 	udiv	x10, x2, x9
    d6d4:	9ac82007 	lsl	x7, x0, x8
    d6d8:	9b098940 	msub	x0, x10, x9, x2
    d6dc:	aa0a03e1 	mov	x1, x10
    d6e0:	9b0a7ca2 	mul	x2, x5, x10
    d6e4:	93c38000 	extr	x0, x0, x3, #32
    d6e8:	eb00005f 	cmp	x2, x0
    d6ec:	540000a9 	b.ls	d700 <__divti3+0x2e0>  // b.plast
    d6f0:	ab0000c0 	adds	x0, x6, x0
    d6f4:	d1000541 	sub	x1, x10, #0x1
    d6f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d6fc:	54000468 	b.hi	d788 <__divti3+0x368>  // b.pmore
    d700:	cb020000 	sub	x0, x0, x2
    d704:	9ac9080a 	udiv	x10, x0, x9
    d708:	9b098140 	msub	x0, x10, x9, x0
    d70c:	aa0a03e2 	mov	x2, x10
    d710:	9b0a7ca8 	mul	x8, x5, x10
    d714:	b3607c03 	bfi	x3, x0, #32, #32
    d718:	eb03011f 	cmp	x8, x3
    d71c:	540000a9 	b.ls	d730 <__divti3+0x310>  // b.plast
    d720:	ab0300c3 	adds	x3, x6, x3
    d724:	d1000542 	sub	x2, x10, #0x1
    d728:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d72c:	54000288 	b.hi	d77c <__divti3+0x35c>  // b.pmore
    d730:	cb080063 	sub	x3, x3, x8
    d734:	aa018041 	orr	x1, x2, x1, lsl #32
    d738:	17ffffc2 	b	d640 <__divti3+0x220>
    d73c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d740:	d2800001 	mov	x1, #0x0                   	// #0
    d744:	9a9f87e0 	cset	x0, ls	// ls = plast
    d748:	17ffff68 	b	d4e8 <__divti3+0xc8>
    d74c:	aa0103e0 	mov	x0, x1
    d750:	d2800001 	mov	x1, #0x0                   	// #0
    d754:	17ffff65 	b	d4e8 <__divti3+0xc8>
    d758:	d1000860 	sub	x0, x3, #0x2
    d75c:	8b0600a5 	add	x5, x5, x6
    d760:	17ffff52 	b	d4a8 <__divti3+0x88>
    d764:	d1000961 	sub	x1, x11, #0x2
    d768:	8b0800a5 	add	x5, x5, x8
    d76c:	17ffff85 	b	d580 <__divti3+0x160>
    d770:	d1000965 	sub	x5, x11, #0x2
    d774:	8b080063 	add	x3, x3, x8
    d778:	17ffff8e 	b	d5b0 <__divti3+0x190>
    d77c:	d1000942 	sub	x2, x10, #0x2
    d780:	8b060063 	add	x3, x3, x6
    d784:	17ffffeb 	b	d730 <__divti3+0x310>
    d788:	d1000941 	sub	x1, x10, #0x2
    d78c:	8b060000 	add	x0, x0, x6
    d790:	17ffffdc 	b	d700 <__divti3+0x2e0>
    d794:	d1000900 	sub	x0, x8, #0x2
    d798:	8b060063 	add	x3, x3, x6
    d79c:	17ffffb4 	b	d66c <__divti3+0x24c>

000000000000d7a0 <__modti3>:
    d7a0:	d503245f 	bti	c
    d7a4:	d2800004 	mov	x4, #0x0                   	// #0
    d7a8:	b6f80081 	tbz	x1, #63, d7b8 <__modti3+0x18>
    d7ac:	eb0003e0 	negs	x0, x0
    d7b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d7b4:	da0103e1 	ngc	x1, x1
    d7b8:	f100007f 	cmp	x3, #0x0
    d7bc:	5400128b 	b.lt	da0c <__modti3+0x26c>  // b.tstop
    d7c0:	aa0003e7 	mov	x7, x0
    d7c4:	aa0103e6 	mov	x6, x1
    d7c8:	540004e1 	b.ne	d864 <__modti3+0xc4>  // b.any
    d7cc:	eb02003f 	cmp	x1, x2
    d7d0:	54000dc2 	b.cs	d988 <__modti3+0x1e8>  // b.hs, b.nlast
    d7d4:	dac01043 	clz	x3, x2
    d7d8:	aa0303e5 	mov	x5, x3
    d7dc:	b40000e3 	cbz	x3, d7f8 <__modti3+0x58>
    d7e0:	4b0303e6 	neg	w6, w3
    d7e4:	9ac32021 	lsl	x1, x1, x3
    d7e8:	9ac32042 	lsl	x2, x2, x3
    d7ec:	9ac62406 	lsr	x6, x0, x6
    d7f0:	aa0100c6 	orr	x6, x6, x1
    d7f4:	9ac32007 	lsl	x7, x0, x3
    d7f8:	d360fc40 	lsr	x0, x2, #32
    d7fc:	92407c43 	and	x3, x2, #0xffffffff
    d800:	9ac008c1 	udiv	x1, x6, x0
    d804:	9b009826 	msub	x6, x1, x0, x6
    d808:	9b017c61 	mul	x1, x3, x1
    d80c:	93c780c6 	extr	x6, x6, x7, #32
    d810:	eb06003f 	cmp	x1, x6
    d814:	540000a9 	b.ls	d828 <__modti3+0x88>  // b.plast
    d818:	ab060046 	adds	x6, x2, x6
    d81c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d820:	8b0200c8 	add	x8, x6, x2
    d824:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d828:	cb0100c6 	sub	x6, x6, x1
    d82c:	9ac008c8 	udiv	x8, x6, x0
    d830:	9b009901 	msub	x1, x8, x0, x6
    d834:	aa0703e0 	mov	x0, x7
    d838:	9b087c63 	mul	x3, x3, x8
    d83c:	b3607c20 	bfi	x0, x1, #32, #32
    d840:	eb00007f 	cmp	x3, x0
    d844:	54001088 	b.hi	da54 <__modti3+0x2b4>  // b.pmore
    d848:	cb030000 	sub	x0, x0, x3
    d84c:	9ac52400 	lsr	x0, x0, x5
    d850:	d2800001 	mov	x1, #0x0                   	// #0
    d854:	b4000064 	cbz	x4, d860 <__modti3+0xc0>
    d858:	eb0003e0 	negs	x0, x0
    d85c:	da0103e1 	ngc	x1, x1
    d860:	d65f03c0 	ret
    d864:	dac01066 	clz	x6, x3
    d868:	eb03003f 	cmp	x1, x3
    d86c:	54ffff43 	b.cc	d854 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d870:	93407cc5 	sxtw	x5, w6
    d874:	d2800808 	mov	x8, #0x40                  	// #64
    d878:	cb050108 	sub	x8, x8, x5
    d87c:	9ac62063 	lsl	x3, x3, x6
    d880:	9ac62025 	lsl	x5, x1, x6
    d884:	9ac82447 	lsr	x7, x2, x8
    d888:	aa0300e7 	orr	x7, x7, x3
    d88c:	9ac82423 	lsr	x3, x1, x8
    d890:	92407cec 	and	x12, x7, #0xffffffff
    d894:	d360fcea 	lsr	x10, x7, #32
    d898:	9ac82401 	lsr	x1, x0, x8
    d89c:	aa050021 	orr	x1, x1, x5
    d8a0:	9ac62042 	lsl	x2, x2, x6
    d8a4:	9ac62000 	lsl	x0, x0, x6
    d8a8:	9aca086b 	udiv	x11, x3, x10
    d8ac:	9b0a8d63 	msub	x3, x11, x10, x3
    d8b0:	aa0b03e5 	mov	x5, x11
    d8b4:	9b0b7d89 	mul	x9, x12, x11
    d8b8:	93c18063 	extr	x3, x3, x1, #32
    d8bc:	eb03013f 	cmp	x9, x3
    d8c0:	540000a9 	b.ls	d8d4 <__modti3+0x134>  // b.plast
    d8c4:	ab0300e3 	adds	x3, x7, x3
    d8c8:	d1000565 	sub	x5, x11, #0x1
    d8cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d8d0:	54001168 	b.hi	dafc <__modti3+0x35c>  // b.pmore
    d8d4:	cb090063 	sub	x3, x3, x9
    d8d8:	9aca086b 	udiv	x11, x3, x10
    d8dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    d8e0:	aa0b03e9 	mov	x9, x11
    d8e4:	9b0b7d8c 	mul	x12, x12, x11
    d8e8:	b3607d41 	bfi	x1, x10, #32, #32
    d8ec:	eb01019f 	cmp	x12, x1
    d8f0:	540000a9 	b.ls	d904 <__modti3+0x164>  // b.plast
    d8f4:	ab0100e1 	adds	x1, x7, x1
    d8f8:	d1000569 	sub	x9, x11, #0x1
    d8fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d900:	54000f88 	b.hi	daf0 <__modti3+0x350>  // b.pmore
    d904:	aa058123 	orr	x3, x9, x5, lsl #32
    d908:	92407c4b 	and	x11, x2, #0xffffffff
    d90c:	2a0903e9 	mov	w9, w9
    d910:	d360fc4a 	lsr	x10, x2, #32
    d914:	d360fc63 	lsr	x3, x3, #32
    d918:	cb0c0021 	sub	x1, x1, x12
    d91c:	aa0a03ec 	mov	x12, x10
    d920:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d924:	9b0b7d25 	mul	x5, x9, x11
    d928:	9b0b7c6b 	mul	x11, x3, x11
    d92c:	9b0a2d29 	madd	x9, x9, x10, x11
    d930:	92407caa 	and	x10, x5, #0xffffffff
    d934:	9b0c7c63 	mul	x3, x3, x12
    d938:	8b458125 	add	x5, x9, x5, lsr #32
    d93c:	8b0d0069 	add	x9, x3, x13
    d940:	eb05017f 	cmp	x11, x5
    d944:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d948:	8b058149 	add	x9, x10, x5, lsl #32
    d94c:	8b458063 	add	x3, x3, x5, lsr #32
    d950:	eb03003f 	cmp	x1, x3
    d954:	54000063 	b.cc	d960 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d958:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d95c:	54000082 	b.cs	d96c <__modti3+0x1cc>  // b.hs, b.nlast
    d960:	eb020129 	subs	x9, x9, x2
    d964:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d968:	cb070063 	sub	x3, x3, x7
    d96c:	eb090000 	subs	x0, x0, x9
    d970:	da030021 	sbc	x1, x1, x3
    d974:	9ac62400 	lsr	x0, x0, x6
    d978:	9ac82028 	lsl	x8, x1, x8
    d97c:	aa000100 	orr	x0, x8, x0
    d980:	9ac62421 	lsr	x1, x1, x6
    d984:	17ffffb4 	b	d854 <__modti3+0xb4>
    d988:	b5000062 	cbnz	x2, d994 <__modti3+0x1f4>
    d98c:	d2800023 	mov	x3, #0x1                   	// #1
    d990:	9ac20862 	udiv	x2, x3, x2
    d994:	dac01048 	clz	x8, x2
    d998:	aa0803e5 	mov	x5, x8
    d99c:	b5000668 	cbnz	x8, da68 <__modti3+0x2c8>
    d9a0:	cb020020 	sub	x0, x1, x2
    d9a4:	d360fc49 	lsr	x9, x2, #32
    d9a8:	92407c4a 	and	x10, x2, #0xffffffff
    d9ac:	9ac90801 	udiv	x1, x0, x9
    d9b0:	9b098020 	msub	x0, x1, x9, x0
    d9b4:	9b0a7c21 	mul	x1, x1, x10
    d9b8:	93c78000 	extr	x0, x0, x7, #32
    d9bc:	eb00003f 	cmp	x1, x0
    d9c0:	540000a9 	b.ls	d9d4 <__modti3+0x234>  // b.plast
    d9c4:	ab000040 	adds	x0, x2, x0
    d9c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d9cc:	8b020003 	add	x3, x0, x2
    d9d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d9d4:	cb010001 	sub	x1, x0, x1
    d9d8:	9ac90820 	udiv	x0, x1, x9
    d9dc:	9b098403 	msub	x3, x0, x9, x1
    d9e0:	aa0703e1 	mov	x1, x7
    d9e4:	9b0a7c00 	mul	x0, x0, x10
    d9e8:	b3607c61 	bfi	x1, x3, #32, #32
    d9ec:	eb01001f 	cmp	x0, x1
    d9f0:	540000a9 	b.ls	da04 <__modti3+0x264>  // b.plast
    d9f4:	ab010041 	adds	x1, x2, x1
    d9f8:	8b020022 	add	x2, x1, x2
    d9fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    da00:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    da04:	cb000020 	sub	x0, x1, x0
    da08:	17ffff91 	b	d84c <__modti3+0xac>
    da0c:	eb0203e5 	negs	x5, x2
    da10:	aa0003e7 	mov	x7, x0
    da14:	da0303e8 	ngc	x8, x3
    da18:	aa0503e2 	mov	x2, x5
    da1c:	aa0803e3 	mov	x3, x8
    da20:	aa0103e6 	mov	x6, x1
    da24:	b4ffed48 	cbz	x8, d7cc <__modti3+0x2c>
    da28:	eb01011f 	cmp	x8, x1
    da2c:	54fff148 	b.hi	d854 <__modti3+0xb4>  // b.pmore
    da30:	dac01109 	clz	x9, x8
    da34:	2a0903e6 	mov	w6, w9
    da38:	b5fff1c9 	cbnz	x9, d870 <__modti3+0xd0>
    da3c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    da40:	54000068 	b.hi	da4c <__modti3+0x2ac>  // b.pmore
    da44:	eb050007 	subs	x7, x0, x5
    da48:	da080021 	sbc	x1, x1, x8
    da4c:	aa0703e0 	mov	x0, x7
    da50:	17ffff81 	b	d854 <__modti3+0xb4>
    da54:	ab000040 	adds	x0, x2, x0
    da58:	8b020002 	add	x2, x0, x2
    da5c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    da60:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    da64:	17ffff79 	b	d848 <__modti3+0xa8>
    da68:	9ac82042 	lsl	x2, x2, x8
    da6c:	d2800803 	mov	x3, #0x40                  	// #64
    da70:	cb080063 	sub	x3, x3, x8
    da74:	d360fc49 	lsr	x9, x2, #32
    da78:	9ac82027 	lsl	x7, x1, x8
    da7c:	92407c4a 	and	x10, x2, #0xffffffff
    da80:	9ac32426 	lsr	x6, x1, x3
    da84:	9ac32403 	lsr	x3, x0, x3
    da88:	aa070063 	orr	x3, x3, x7
    da8c:	9ac908c1 	udiv	x1, x6, x9
    da90:	9ac82007 	lsl	x7, x0, x8
    da94:	9b099820 	msub	x0, x1, x9, x6
    da98:	9b017d41 	mul	x1, x10, x1
    da9c:	93c38000 	extr	x0, x0, x3, #32
    daa0:	eb00003f 	cmp	x1, x0
    daa4:	540000a9 	b.ls	dab8 <__modti3+0x318>  // b.plast
    daa8:	ab000040 	adds	x0, x2, x0
    daac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    dab0:	8b020006 	add	x6, x0, x2
    dab4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    dab8:	cb010000 	sub	x0, x0, x1
    dabc:	9ac90801 	udiv	x1, x0, x9
    dac0:	9b098026 	msub	x6, x1, x9, x0
    dac4:	aa0303e0 	mov	x0, x3
    dac8:	9b017d41 	mul	x1, x10, x1
    dacc:	b3607cc0 	bfi	x0, x6, #32, #32
    dad0:	eb00003f 	cmp	x1, x0
    dad4:	540000a9 	b.ls	dae8 <__modti3+0x348>  // b.plast
    dad8:	ab000040 	adds	x0, x2, x0
    dadc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    dae0:	8b020003 	add	x3, x0, x2
    dae4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    dae8:	cb010000 	sub	x0, x0, x1
    daec:	17ffffb0 	b	d9ac <__modti3+0x20c>
    daf0:	d1000969 	sub	x9, x11, #0x2
    daf4:	8b070021 	add	x1, x1, x7
    daf8:	17ffff83 	b	d904 <__modti3+0x164>
    dafc:	d1000965 	sub	x5, x11, #0x2
    db00:	8b070063 	add	x3, x3, x7
    db04:	17ffff74 	b	d8d4 <__modti3+0x134>
    db08:	d503201f 	nop
    db0c:	d503201f 	nop

000000000000db10 <atexit>:
    db10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    db14:	f0000082 	adrp	x2, 20000 <__data_start>
    db18:	d2800001 	mov	x1, #0x0                   	// #0
    db1c:	910003fd 	mov	x29, sp
    db20:	a8c17bfd 	ldp	x29, x30, [sp], #16
    db24:	f9400442 	ldr	x2, [x2, #8]
    db28:	17ffd316 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000db2c <_fini>:
    db2c:	d503201f 	nop
    db30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    db34:	910003fd 	mov	x29, sp
    db38:	a8c17bfd 	ldp	x29, x30, [sp], #16
    db3c:	d65f03c0 	ret
