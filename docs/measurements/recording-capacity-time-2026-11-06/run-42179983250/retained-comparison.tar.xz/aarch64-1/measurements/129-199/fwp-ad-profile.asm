
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	90000065 	adrp	x5, e000 <fwp_main_thread+0x1470>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913480a5 	add	x5, x5, #0xd20
    2aa0:	90000064 	adrp	x4, e000 <fwp_main_thread+0x1470>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9134a084 	add	x4, x4, #0xd28
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000619 	bl	4334 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b0000174 	adrp	x20, 2f000 <fwp_fn_table+0xc90>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d0000175 	adrp	x21, 30000 <__data_start>
    2b0c:	910142a1 	add	x1, x21, #0x50
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	90000160 	adrp	x0, 2e000 <__FRAME_END__+0x1d3e8>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9008c20 	str	x0, [x1, #280]
    2b2c:	94000821 	bl	4bb0 <fwp_now_ns>
    2b30:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2b34:	9103a000 	add	x0, x0, #0xe8
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1aec>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	912e4042 	add	x2, x2, #0xb90
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	910142b5 	add	x21, x21, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943daa0 	ldr	w0, [x21, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2c4c:	91046000 	add	x0, x0, #0x118
    2c50:	940005b9 	bl	4334 <fwp_trap>
    2c54:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2c58:	9103e000 	add	x0, x0, #0xf8
    2c5c:	940005b6 	bl	4334 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff4a 	bl	2990 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeef 	bl	2850 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2ca0:	9105c000 	add	x0, x0, #0x170
    2ca4:	940005a4 	bl	4334 <fwp_trap>
    2ca8:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2cac:	91050000 	add	x0, x0, #0x140
    2cb0:	940005a1 	bl	4334 <fwp_trap>
    2cb4:	b0000060 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    2cb8:	91066000 	add	x0, x0, #0x198
    2cbc:	9400059e 	bl	4334 <fwp_trap>
    2cc0:	97fffef8 	bl	28a0 <__stack_chk_fail@plt>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d0000160 	adrp	x0, 30000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d0000161 	adrp	x1, 30000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d0000160 	adrp	x0, 30000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d0000161 	adrp	x1, 30000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b0000162 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d0000173 	adrp	x19, 30000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d0000160 	adrp	x0, 30000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000061 	adrp	x1, f000 <_IO_stdin_used+0x7c0>
    2eb4:	911fc021 	add	x1, x1, #0x7f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d0000167 	adrp	x7, 30000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b0000164 	adrp	x4, 30000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b0000163 	adrp	x3, 30000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b0000160 	adrp	x0, 30000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b0000162 	adrp	x2, 30000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	90000061 	adrp	x1, f000 <_IO_stdin_used+0x7c0>
    3158:	911f4021 	add	x1, x1, #0x7d0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    3190:	91212000 	add	x0, x0, #0x848
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d0000435 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	90000164 	adrp	x4, 2f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	f0000042 	adrp	x2, e000 <fwp_main_thread+0x1470>
    339c:	91218042 	add	x2, x2, #0x860
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b0000178 	adrp	x24, 30000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	90000176 	adrp	x22, 2f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	f0000042 	adrp	x2, e000 <fwp_main_thread+0x1470>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	9122e042 	add	x2, x2, #0x8b8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	f0000059 	adrp	x25, e000 <fwp_main_thread+0x1470>
    3428:	f000005a 	adrp	x26, e000 <fwp_main_thread+0x1470>
    342c:	91246339 	add	x25, x25, #0x918
    3430:	9122035a 	add	x26, x26, #0x880
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b0000160 	adrp	x0, 30000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	f000005b 	adrp	x27, e000 <fwp_main_thread+0x1470>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	91222377 	add	x23, x27, #0x888
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	91256000 	add	x0, x0, #0x958
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b00001e1 	adrp	x1, 40000 <alt.5+0xfbb0>
    34f4:	b00001e5 	adrp	x5, 40000 <alt.5+0xfbb0>
    34f8:	b00001e2 	adrp	x2, 40000 <alt.5+0xfbb0>
    34fc:	f0000043 	adrp	x3, e000 <fwp_main_thread+0x1470>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	f0000055 	adrp	x21, e000 <fwp_main_thread+0x1470>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	91220063 	add	x3, x3, #0x880
    3520:	9125c2b5 	add	x21, x21, #0x970
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	9126c000 	add	x0, x0, #0x9b0
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    35ac:	91224000 	add	x0, x0, #0x890
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    366c:	91212000 	add	x0, x0, #0x848
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b0000161 	adrp	x1, 30000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	f0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9126e021 	add	x1, x1, #0x9b8
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	f0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91270021 	add	x1, x1, #0x9c0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	f0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    37e0:	91272021 	add	x1, x1, #0x9c8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	f0000044 	adrp	x4, e000 <fwp_main_thread+0x1470>
    3808:	90000162 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	91274084 	add	x4, x4, #0x9d0
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbeb 	bl	2810 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc44 	bl	2980 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2f 	bl	2940 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbb0 	bl	27f0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffba1 	bl	27f0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb65 	bl	2730 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf5 	bl	2980 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	f0000044 	adrp	x4, e000 <fwp_main_thread+0x1470>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	9127a084 	add	x4, x4, #0x9e8
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb76 	bl	2810 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb65 	bl	27f0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc5 	bl	2980 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	f0000044 	adrp	x4, e000 <fwp_main_thread+0x1470>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	91276084 	add	x4, x4, #0x9d8
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4e 	bl	2810 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb38 	bl	27f0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb0c 	bl	27f0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb28 	bl	28a0 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000422 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    3c0c:	9118c042 	add	x2, x2, #0x630
    3c10:	90000161 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	f0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	9127c021 	add	x1, x1, #0x9f0
    3c68:	9127e000 	add	x0, x0, #0x9f8
    3c6c:	97fffaf1 	bl	2830 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb6d 	bl	2a50 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb1b 	bl	2940 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb5a 	bl	2a50 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffacb 	bl	2820 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	f0000042 	adrp	x2, e000 <fwp_main_thread+0x1470>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	91286042 	add	x2, x2, #0xa18
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaee 	b	2910 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97ffface 	bl	28a0 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000423 	adrp	x3, 8a000 <fwp_heap+0x9d0>
    3d78:	9114c061 	add	x1, x3, #0x530
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000433 	adrp	x19, 89000 <fwp_root_context+0xbb0>
    3d88:	9118c262 	add	x2, x19, #0x630
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	90000062 	adrp	x2, f000 <_IO_stdin_used+0x7c0>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000421 	adrp	x1, 8a000 <fwp_heap+0x9d0>
    3dbc:	9115c021 	add	x1, x1, #0x570
    3dc0:	3dc20043 	ldr	q3, [x2, #2048]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000424 	adrp	x4, 8a000 <fwp_heap+0x9d0>
    3dec:	9114c063 	add	x3, x3, #0x530
    3df0:	91174084 	add	x4, x4, #0x5d0
    3df4:	9118c266 	add	x6, x19, #0x630
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffab1 	bl	2930 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	9118c275 	add	x21, x19, #0x630
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa9b 	bl	2930 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	f0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    3ed8:	912a8000 	add	x0, x0, #0xaa0
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad4 	bl	2a30 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	9118c273 	add	x19, x19, #0x630
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc90 	bl	3170 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b0000169 	adrp	x9, 30000 <__data_start>
    3f38:	91014122 	add	x2, x9, #0x50
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9406046 	ldr	x6, [x2, #192]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	91014120 	add	x0, x9, #0x50
    3fc4:	f900640b 	str	x11, [x0, #200]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	91014129 	add	x9, x9, #0x50
    3fd0:	f9006126 	str	x6, [x9, #192]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <ad_raw_free.part.0>:
    3ff0:	b0000364 	adrp	x4, 70000 <ad_raw_checkpoints+0x2fbb0>
    3ff4:	d2800001 	mov	x1, #0x0                   	// #0
    3ff8:	91114082 	add	x2, x4, #0x450
    3ffc:	14000005 	b	4010 <ad_raw_free.part.0+0x20>
    4000:	91000421 	add	x1, x1, #0x1
    4004:	91006042 	add	x2, x2, #0x18
    4008:	f140043f 	cmp	x1, #0x1, lsl #12
    400c:	54000220 	b.eq	4050 <ad_raw_free.part.0+0x60>  // b.none
    4010:	f9400043 	ldr	x3, [x2]
    4014:	eb03001f 	cmp	x0, x3
    4018:	54ffff41 	b.ne	4000 <ad_raw_free.part.0+0x10>  // b.any
    401c:	8b010421 	add	x1, x1, x1, lsl #1
    4020:	91114084 	add	x4, x4, #0x450
    4024:	90000162 	adrp	x2, 30000 <__data_start>
    4028:	91014042 	add	x2, x2, #0x50
    402c:	8b010c81 	add	x1, x4, x1, lsl #3
    4030:	b9401024 	ldr	w4, [x1, #16]
    4034:	f9400425 	ldr	x5, [x1, #8]
    4038:	a9007c3f 	stp	xzr, xzr, [x1]
    403c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4040:	f900083f 	str	xzr, [x1, #16]
    4044:	cb050061 	sub	x1, x3, x5
    4048:	f8247841 	str	x1, [x2, x4, lsl #3]
    404c:	17fffa45 	b	2960 <free@plt>
    4050:	f100001f 	cmp	x0, #0x0
    4054:	d0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    4058:	912b2021 	add	x1, x1, #0xac8
    405c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4060:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4064:	912ac000 	add	x0, x0, #0xab0
    4068:	910003fd 	mov	x29, sp
    406c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4070:	97fffcc4 	bl	3380 <ad_raw_fail>

0000000000004074 <fwp_tape_buffers_dispose>:
    4074:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4078:	910003fd 	mov	x29, sp
    407c:	f9000bf3 	str	x19, [sp, #16]
    4080:	aa0003f3 	mov	x19, x0
    4084:	f9400000 	ldr	x0, [x0]
    4088:	b4000040 	cbz	x0, 4090 <fwp_tape_buffers_dispose+0x1c>
    408c:	97ffffd9 	bl	3ff0 <ad_raw_free.part.0>
    4090:	f9400a60 	ldr	x0, [x19, #16]
    4094:	b4000040 	cbz	x0, 409c <fwp_tape_buffers_dispose+0x28>
    4098:	97ffffd6 	bl	3ff0 <ad_raw_free.part.0>
    409c:	f9401260 	ldr	x0, [x19, #32]
    40a0:	b4000040 	cbz	x0, 40a8 <fwp_tape_buffers_dispose+0x34>
    40a4:	97ffffd3 	bl	3ff0 <ad_raw_free.part.0>
    40a8:	4f000400 	movi	v0.4s, #0x0
    40ac:	f9001a7f 	str	xzr, [x19, #48]
    40b0:	ad000260 	stp	q0, q0, [x19]
    40b4:	3d800a60 	str	q0, [x19, #32]
    40b8:	f9400bf3 	ldr	x19, [sp, #16]
    40bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40c0:	d65f03c0 	ret

00000000000040c4 <ad_raw_realloc>:
    40c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	f90013f5 	str	x21, [sp, #32]
    40d4:	b40005a1 	cbz	x1, 4188 <ad_raw_realloc+0xc4>
    40d8:	aa0103f4 	mov	x20, x1
    40dc:	2a0203f5 	mov	w21, w2
    40e0:	90000361 	adrp	x1, 70000 <ad_raw_checkpoints+0x2fbb0>
    40e4:	d2800004 	mov	x4, #0x0                   	// #0
    40e8:	91114025 	add	x5, x1, #0x450
    40ec:	14000005 	b	4100 <ad_raw_realloc+0x3c>
    40f0:	91000484 	add	x4, x4, #0x1
    40f4:	910060a5 	add	x5, x5, #0x18
    40f8:	f140049f 	cmp	x4, #0x1, lsl #12
    40fc:	54000320 	b.eq	4160 <ad_raw_realloc+0x9c>  // b.none
    4100:	f94000a6 	ldr	x6, [x5]
    4104:	eb06001f 	cmp	x0, x6
    4108:	54ffff41 	b.ne	40f0 <ad_raw_realloc+0x2c>  // b.any
    410c:	8b040484 	add	x4, x4, x4, lsl #1
    4110:	91114021 	add	x1, x1, #0x450
    4114:	8b040c33 	add	x19, x1, x4, lsl #3
    4118:	b4000080 	cbz	x0, 4128 <ad_raw_realloc+0x64>
    411c:	b9401261 	ldr	w1, [x19, #16]
    4120:	6b15003f 	cmp	w1, w21
    4124:	540002c1 	b.ne	417c <ad_raw_realloc+0xb8>  // b.any
    4128:	aa1403e1 	mov	x1, x20
    412c:	97fff9d9 	bl	2890 <realloc@plt>
    4130:	aa0003ed 	mov	x13, x0
    4134:	b40000c0 	cbz	x0, 414c <ad_raw_realloc+0x88>
    4138:	2a1503e3 	mov	w3, w21
    413c:	aa1403e2 	mov	x2, x20
    4140:	aa1303e0 	mov	x0, x19
    4144:	aa0d03e1 	mov	x1, x13
    4148:	97fffb92 	bl	2f90 <ad_raw_record>
    414c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4150:	aa0d03e0 	mov	x0, x13
    4154:	f94013f5 	ldr	x21, [sp, #32]
    4158:	a8c37bfd 	ldp	x29, x30, [sp], #48
    415c:	d65f03c0 	ret
    4160:	f100001f 	cmp	x0, #0x0
    4164:	d0000041 	adrp	x1, e000 <fwp_main_thread+0x1470>
    4168:	912b2021 	add	x1, x1, #0xac8
    416c:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4170:	912ac000 	add	x0, x0, #0xab0
    4174:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4178:	97fffc82 	bl	3380 <ad_raw_fail>
    417c:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4180:	912c2000 	add	x0, x0, #0xb08
    4184:	97fffc7f 	bl	3380 <ad_raw_fail>
    4188:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    418c:	912ba000 	add	x0, x0, #0xae8
    4190:	97fffc7c 	bl	3380 <ad_raw_fail>

0000000000004194 <fwp_tape_buffers_release>:
    4194:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4198:	910003fd 	mov	x29, sp
    419c:	a90153f3 	stp	x19, x20, [sp, #16]
    41a0:	aa0003f4 	mov	x20, x0
    41a4:	f9401400 	ldr	x0, [x0, #40]
    41a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    41ac:	b7f80560 	tbnz	x0, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b0:	f9401a93 	ldr	x19, [x20, #48]
    41b4:	b7f80533 	tbnz	x19, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    41bc:	eb01001f 	cmp	x0, x1
    41c0:	540004c8 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41c4:	8b000400 	add	x0, x0, x0, lsl #1
    41c8:	d2a00101 	mov	x1, #0x80000               	// #524288
    41cc:	d37df000 	lsl	x0, x0, #3
    41d0:	cb000021 	sub	x1, x1, x0
    41d4:	eb410e7f 	cmp	x19, x1, lsr #3
    41d8:	54000408 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41dc:	8b130c13 	add	x19, x0, x19, lsl #3
    41e0:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    41e4:	912c8000 	add	x0, x0, #0xb20
    41e8:	97fffa12 	bl	2a30 <getenv@plt>
    41ec:	b4000080 	cbz	x0, 41fc <fwp_tape_buffers_release+0x68>
    41f0:	39400001 	ldrb	w1, [x0]
    41f4:	7100c03f 	cmp	w1, #0x30
    41f8:	54000880 	b.eq	4308 <fwp_tape_buffers_release+0x174>  // b.none
    41fc:	d1000661 	sub	x1, x19, #0x1
    4200:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4204:	eb00003f 	cmp	x1, x0
    4208:	54000328 	b.hi	426c <fwp_tape_buffers_release+0xd8>  // b.pmore
    420c:	90000175 	adrp	x21, 30000 <__data_start>
    4210:	f9001bf7 	str	x23, [sp, #48]
    4214:	910142b7 	add	x23, x21, #0x50
    4218:	910342f6 	add	x22, x23, #0xd0
    421c:	aa1603e0 	mov	x0, x22
    4220:	97ffff95 	bl	4074 <fwp_tape_buffers_dispose>
    4224:	ad400a81 	ldp	q1, q2, [x20]
    4228:	f90086f3 	str	x19, [x23, #264]
    422c:	4f000400 	movi	v0.4s, #0x0
    4230:	ad000ac1 	stp	q1, q2, [x22]
    4234:	3dc00a81 	ldr	q1, [x20, #32]
    4238:	3d800ac1 	str	q1, [x22, #32]
    423c:	f9401a80 	ldr	x0, [x20, #48]
    4240:	f9001ac0 	str	x0, [x22, #48]
    4244:	f9001a9f 	str	xzr, [x20, #48]
    4248:	ad000280 	stp	q0, q0, [x20]
    424c:	3d800a80 	str	q0, [x20, #32]
    4250:	f9401bf7 	ldr	x23, [sp, #48]
    4254:	1400000b 	b	4280 <fwp_tape_buffers_release+0xec>
    4258:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    425c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4260:	912c8000 	add	x0, x0, #0xb20
    4264:	97fff9f3 	bl	2a30 <getenv@plt>
    4268:	b5fffc40 	cbnz	x0, 41f0 <fwp_tape_buffers_release+0x5c>
    426c:	aa1403e0 	mov	x0, x20
    4270:	97ffff81 	bl	4074 <fwp_tape_buffers_dispose>
    4274:	90000175 	adrp	x21, 30000 <__data_start>
    4278:	910142a0 	add	x0, x21, #0x50
    427c:	f9408413 	ldr	x19, [x0, #264]
    4280:	910142a2 	add	x2, x21, #0x50
    4284:	f9408844 	ldr	x4, [x2, #272]
    4288:	a9400c45 	ldp	x5, x3, [x2]
    428c:	8b040481 	add	x1, x4, x4, lsl #1
    4290:	f9400840 	ldr	x0, [x2, #16]
    4294:	8b010881 	add	x1, x4, x1, lsl #2
    4298:	f9400c44 	ldr	x4, [x2, #24]
    429c:	8b0300a3 	add	x3, x5, x3
    42a0:	d37df021 	lsl	x1, x1, #3
    42a4:	8b040000 	add	x0, x0, x4
    42a8:	8b030000 	add	x0, x0, x3
    42ac:	eb05003f 	cmp	x1, x5
    42b0:	54000321 	b.ne	4314 <fwp_tape_buffers_release+0x180>  // b.any
    42b4:	8b130023 	add	x3, x1, x19
    42b8:	eb00007f 	cmp	x3, x0
    42bc:	540002c8 	b.hi	4314 <fwp_tape_buffers_release+0x180>  // b.pmore
    42c0:	f9405c43 	ldr	x3, [x2, #184]
    42c4:	f140087f 	cmp	x3, #0x2, lsl #12
    42c8:	540002e0 	b.eq	4324 <fwp_tape_buffers_release+0x190>  // b.none
    42cc:	8b030464 	add	x4, x3, x3, lsl #1
    42d0:	900001e5 	adrp	x5, 40000 <alt.5+0xfbb0>
    42d4:	911140a5 	add	x5, x5, #0x450
    42d8:	cb010000 	sub	x0, x0, x1
    42dc:	d37df084 	lsl	x4, x4, #3
    42e0:	cb130000 	sub	x0, x0, x19
    42e4:	8b0400a6 	add	x6, x5, x4
    42e8:	91000463 	add	x3, x3, #0x1
    42ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42f0:	f82468a1 	str	x1, [x5, x4]
    42f4:	a90080d3 	stp	x19, x0, [x6, #8]
    42f8:	f9005c43 	str	x3, [x2, #184]
    42fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4300:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4304:	d65f03c0 	ret
    4308:	39400400 	ldrb	w0, [x0, #1]
    430c:	34fffb00 	cbz	w0, 426c <fwp_tape_buffers_release+0xd8>
    4310:	17ffffbb 	b	41fc <fwp_tape_buffers_release+0x68>
    4314:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4318:	912ce000 	add	x0, x0, #0xb38
    431c:	f9001bf7 	str	x23, [sp, #48]
    4320:	97fffc18 	bl	3380 <ad_raw_fail>
    4324:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4328:	912da000 	add	x0, x0, #0xb68
    432c:	f9001bf7 	str	x23, [sp, #48]
    4330:	97fffc14 	bl	3380 <ad_raw_fail>

0000000000004334 <fwp_trap>:
    4334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4338:	90000162 	adrp	x2, 30000 <__data_start>
    433c:	d53bd041 	mrs	x1, tpidr_el0
    4340:	910003fd 	mov	x29, sp
    4344:	f9407042 	ldr	x2, [x2, #224]
    4348:	91400021 	add	x1, x1, #0x0, lsl #12
    434c:	91004021 	add	x1, x1, #0x10
    4350:	a90153f3 	stp	x19, x20, [sp, #16]
    4354:	aa0003f3 	mov	x19, x0
    4358:	f9400034 	ldr	x20, [x1]
    435c:	b4000062 	cbz	x2, 4368 <fwp_trap+0x34>
    4360:	aa0203e0 	mov	x0, x2
    4364:	97fff99b 	bl	29d0 <fflush@plt>
    4368:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    436c:	f947ec00 	ldr	x0, [x0, #4056]
    4370:	f9400000 	ldr	x0, [x0]
    4374:	97fff997 	bl	29d0 <fflush@plt>
    4378:	aa1303e3 	mov	x3, x19
    437c:	d0000042 	adrp	x2, e000 <fwp_main_thread+0x1470>
    4380:	f0000153 	adrp	x19, 2f000 <fwp_fn_table+0xc90>
    4384:	f947ea73 	ldr	x19, [x19, #4048]
    4388:	912e2042 	add	x2, x2, #0xb88
    438c:	52800041 	mov	w1, #0x2                   	// #2
    4390:	f9400260 	ldr	x0, [x19]
    4394:	97fff95f 	bl	2910 <__fprintf_chk@plt>
    4398:	b40000b4 	cbz	x20, 43ac <fwp_trap+0x78>
    439c:	f9400260 	ldr	x0, [x19]
    43a0:	97fff98c 	bl	29d0 <fflush@plt>
    43a4:	52800ca0 	mov	w0, #0x65                  	// #101
    43a8:	97fff99a 	bl	2a10 <_Exit@plt>
    43ac:	52800ca0 	mov	w0, #0x65                  	// #101
    43b0:	97fff8e8 	bl	2750 <exit@plt>

00000000000043b4 <fwp_rc_forget_slot.part.0>:
    43b4:	ca404401 	eor	x1, x0, x0, lsr #17
    43b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43bc:	ca412421 	eor	x1, x1, x1, lsr #9
    43c0:	910003fd 	mov	x29, sp
    43c4:	92401c21 	and	x1, x1, #0xff
    43c8:	f9000bf3 	str	x19, [sp, #16]
    43cc:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xbb0>
    43d0:	9118c262 	add	x2, x19, #0x630
    43d4:	910a2423 	add	x3, x1, #0x289
    43d8:	8b010c41 	add	x1, x2, x1, lsl #3
    43dc:	8b030c43 	add	x3, x2, x3, lsl #3
    43e0:	f94a2421 	ldr	x1, [x1, #5192]
    43e4:	b50000a1 	cbnz	x1, 43f8 <fwp_rc_forget_slot.part.0+0x44>
    43e8:	14000012 	b	4430 <fwp_rc_forget_slot.part.0+0x7c>
    43ec:	91004023 	add	x3, x1, #0x10
    43f0:	f9400821 	ldr	x1, [x1, #16]
    43f4:	b40001e1 	cbz	x1, 4430 <fwp_rc_forget_slot.part.0+0x7c>
    43f8:	f9400022 	ldr	x2, [x1]
    43fc:	eb02001f 	cmp	x0, x2
    4400:	54ffff61 	b.ne	43ec <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4404:	f9400060 	ldr	x0, [x3]
    4408:	9118c273 	add	x19, x19, #0x630
    440c:	f9400801 	ldr	x1, [x0, #16]
    4410:	f9000061 	str	x1, [x3]
    4414:	97fff953 	bl	2960 <free@plt>
    4418:	f94e2660 	ldr	x0, [x19, #7240]
    441c:	d1000400 	sub	x0, x0, #0x1
    4420:	f90e2660 	str	x0, [x19, #7240]
    4424:	f9400bf3 	ldr	x19, [sp, #16]
    4428:	a8c27bfd 	ldp	x29, x30, [sp], #32
    442c:	d65f03c0 	ret
    4430:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4434:	912e6000 	add	x0, x0, #0xb98
    4438:	97ffffbf 	bl	4334 <fwp_trap>
    443c:	d503201f 	nop

0000000000004440 <fwp_rc_prepare_chunk>:
    4440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4444:	910003fd 	mov	x29, sp
    4448:	a9025bf5 	stp	x21, x22, [sp, #32]
    444c:	b0000436 	adrp	x22, 89000 <fwp_root_context+0xbb0>
    4450:	9118c2c2 	add	x2, x22, #0x630
    4454:	b9401c03 	ldr	w3, [x0, #28]
    4458:	aa0103f5 	mov	x21, x1
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f4 	mov	x20, x0
    4464:	f94e2440 	ldr	x0, [x2, #7240]
    4468:	b4000440 	cbz	x0, 44f0 <fwp_rc_prepare_chunk+0xb0>
    446c:	d2800013 	mov	x19, #0x0                   	// #0
    4470:	35000203 	cbnz	w3, 44b0 <fwp_rc_prepare_chunk+0x70>
    4474:	b4000361 	cbz	x1, 44e0 <fwp_rc_prepare_chunk+0xa0>
    4478:	f9401280 	ldr	x0, [x20, #32]
    447c:	97fff939 	bl	2960 <free@plt>
    4480:	aa1503e0 	mov	x0, x21
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	97fff8fe 	bl	2880 <calloc@plt>
    448c:	f9001280 	str	x0, [x20, #32]
    4490:	b5000460 	cbnz	x0, 451c <fwp_rc_prepare_chunk+0xdc>
    4494:	97fffb37 	bl	3170 <fwp_heap_oom>
    4498:	97ffffc7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    449c:	91000673 	add	x19, x19, #0x1
    44a0:	b9401e83 	ldr	w3, [x20, #28]
    44a4:	eb13007f 	cmp	x3, x19
    44a8:	54000169 	b.ls	44d4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    44ac:	d503201f 	nop
    44b0:	f9401283 	ldr	x3, [x20, #32]
    44b4:	8b130060 	add	x0, x3, x19
    44b8:	38736863 	ldrb	w3, [x3, x19]
    44bc:	7103fc7f 	cmp	w3, #0xff
    44c0:	54fffec0 	b.eq	4498 <fwp_rc_prepare_chunk+0x58>  // b.none
    44c4:	b9401e83 	ldr	w3, [x20, #28]
    44c8:	91000673 	add	x19, x19, #0x1
    44cc:	eb13007f 	cmp	x3, x19
    44d0:	54ffff08 	b.hi	44b0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    44d4:	eb0302bf 	cmp	x21, x3
    44d8:	54000121 	b.ne	44fc <fwp_rc_prepare_chunk+0xbc>  // b.any
    44dc:	b5000335 	cbnz	x21, 4540 <fwp_rc_prepare_chunk+0x100>
    44e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	2a0303e3 	mov	w3, w3
    44f4:	eb0302bf 	cmp	x21, x3
    44f8:	54ffff20 	b.eq	44dc <fwp_rc_prepare_chunk+0x9c>  // b.none
    44fc:	9118c2c2 	add	x2, x22, #0x630
    4500:	f9401280 	ldr	x0, [x20, #32]
    4504:	f94e2841 	ldr	x1, [x2, #7248]
    4508:	cb030021 	sub	x1, x1, x3
    450c:	f90e2841 	str	x1, [x2, #7248]
    4510:	97fff914 	bl	2960 <free@plt>
    4514:	b5fffb75 	cbnz	x21, 4480 <fwp_rc_prepare_chunk+0x40>
    4518:	f900129f 	str	xzr, [x20, #32]
    451c:	9118c2d6 	add	x22, x22, #0x630
    4520:	f94e2ac0 	ldr	x0, [x22, #7248]
    4524:	b9001e95 	str	w21, [x20, #28]
    4528:	a94153f3 	ldp	x19, x20, [sp, #16]
    452c:	8b150000 	add	x0, x0, x21
    4530:	f90e2ac0 	str	x0, [x22, #7248]
    4534:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f9401280 	ldr	x0, [x20, #32]
    4544:	aa1503e2 	mov	x2, x21
    4548:	a94153f3 	ldp	x19, x20, [sp, #16]
    454c:	52800001 	mov	w1, #0x0                   	// #0
    4550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4558:	17fff8c6 	b	2870 <memset@plt>
    455c:	d503201f 	nop

0000000000004560 <fwp_heap_refill>:
    4560:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4564:	910003fd 	mov	x29, sp
    4568:	a9025bf5 	stp	x21, x22, [sp, #32]
    456c:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    4570:	9118c2b5 	add	x21, x21, #0x630
    4574:	aa0003f6 	mov	x22, x0
    4578:	d2800020 	mov	x0, #0x1                   	// #1
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	a90363f7 	stp	x23, x24, [sp, #48]
    4584:	2a0103f7 	mov	w23, w1
    4588:	2a0203f8 	mov	w24, w2
    458c:	97fffb09 	bl	31b0 <fwp_heap_chunks>
    4590:	aa0003f3 	mov	x19, x0
    4594:	f949fea2 	ldr	x2, [x21, #5112]
    4598:	8b000800 	add	x0, x0, x0, lsl #2
    459c:	2a1703e1 	mov	w1, w23
    45a0:	52800025 	mov	w5, #0x1                   	// #1
    45a4:	d37df000 	lsl	x0, x0, #3
    45a8:	910f0021 	add	x1, x1, #0x3c0
    45ac:	8b000054 	add	x20, x2, x0
    45b0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    45b4:	52a00024 	mov	w4, #0x10000               	// #65536
    45b8:	38206845 	strb	w5, [x2, x0]
    45bc:	aa1403e0 	mov	x0, x20
    45c0:	39000698 	strb	w24, [x20, #1]
    45c4:	39000a97 	strb	w23, [x20, #2]
    45c8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    45cc:	b9000681 	str	w1, [x20, #4]
    45d0:	2a0103e5 	mov	w5, w1
    45d4:	8b0300a2 	add	x2, x5, x3
    45d8:	1ac10881 	udiv	w1, w4, w1
    45dc:	9ac50842 	udiv	x2, x2, x5
    45e0:	b9000a81 	str	w1, [x20, #8]
    45e4:	92404021 	and	x1, x1, #0x1ffff
    45e8:	b9001a82 	str	w2, [x20, #24]
    45ec:	97ffff95 	bl	4440 <fwp_rc_prepare_chunk>
    45f0:	f949daa0 	ldr	x0, [x21, #5040]
    45f4:	29408a81 	ldp	w1, w2, [x20, #4]
    45f8:	8b134000 	add	x0, x0, x19, lsl #16
    45fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4600:	8b214003 	add	x3, x0, w1, uxtw
    4604:	9ba20021 	umaddl	x1, w1, w2, x0
    4608:	a94363f7 	ldp	x23, x24, [sp, #48]
    460c:	a90086c3 	stp	x3, x1, [x22, #8]
    4610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4614:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4618:	d65f03c0 	ret
    461c:	d503201f 	nop

0000000000004620 <fwp_mem_free>:
    4620:	b40003c0 	cbz	x0, 4698 <fwp_mem_free+0x78>
    4624:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4628:	910003fd 	mov	x29, sp
    462c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4630:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    4634:	9118c2a1 	add	x1, x21, #0x630
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	aa0003f3 	mov	x19, x0
    4640:	f949d823 	ldr	x3, [x1, #5040]
    4644:	f949ec22 	ldr	x2, [x1, #5080]
    4648:	cb030000 	sub	x0, x0, x3
    464c:	eb02401f 	cmp	x0, x2, lsl #16
    4650:	540001c2 	b.cs	4688 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4654:	d350fc16 	lsr	x22, x0, #16
    4658:	a90363f7 	stp	x23, x24, [sp, #48]
    465c:	f949fc22 	ldr	x2, [x1, #5112]
    4660:	8b160ad4 	add	x20, x22, x22, lsl #2
    4664:	d37df294 	lsl	x20, x20, #3
    4668:	ab140057 	adds	x23, x2, x20
    466c:	540000c0 	b.eq	4684 <fwp_mem_free+0x64>  // b.none
    4670:	38746842 	ldrb	w2, [x2, x20]
    4674:	7100045f 	cmp	w2, #0x1
    4678:	54000120 	b.eq	469c <fwp_mem_free+0x7c>  // b.none
    467c:	7100085f 	cmp	w2, #0x2
    4680:	540005e0 	b.eq	473c <fwp_mem_free+0x11c>  // b.none
    4684:	a94363f7 	ldp	x23, x24, [sp, #48]
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4690:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4694:	d65f03c0 	ret
    4698:	d65f03c0 	ret
    469c:	f94012f8 	ldr	x24, [x23, #32]
    46a0:	b94006e1 	ldr	w1, [x23, #4]
    46a4:	f90023f9 	str	x25, [sp, #64]
    46a8:	2a0103e2 	mov	w2, w1
    46ac:	394006f9 	ldrb	w25, [x23, #1]
    46b0:	39400af4 	ldrb	w20, [x23, #2]
    46b4:	b4000158 	cbz	x24, 46dc <fwp_mem_free+0xbc>
    46b8:	92403e76 	and	x22, x19, #0xffff
    46bc:	9ac20ad6 	udiv	x22, x22, x2
    46c0:	38766b01 	ldrb	w1, [x24, x22]
    46c4:	8b160300 	add	x0, x24, x22
    46c8:	7103fc3f 	cmp	w1, #0xff
    46cc:	54000980 	b.eq	47fc <fwp_mem_free+0x1dc>  // b.none
    46d0:	38366b1f 	strb	wzr, [x24, x22]
    46d4:	b94006e1 	ldr	w1, [x23, #4]
    46d8:	2a0103e2 	mov	w2, w1
    46dc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    46e0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    46e4:	cb390000 	sub	x0, x0, w25, uxtb
    46e8:	8b340074 	add	x20, x3, w20, uxtb
    46ec:	9118c2b5 	add	x21, x21, #0x630
    46f0:	1e630021 	ucvtf	d1, w1
    46f4:	d37ae400 	lsl	x0, x0, #6
    46f8:	8b140c14 	add	x20, x0, x20, lsl #3
    46fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4700:	f8746aa0 	ldr	x0, [x21, x20]
    4704:	f94023f9 	ldr	x25, [sp, #64]
    4708:	aa2003e0 	mvn	x0, x0
    470c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4710:	f9000260 	str	x0, [x19]
    4714:	f8346ab3 	str	x19, [x21, x20]
    4718:	f94a12a0 	ldr	x0, [x21, #5152]
    471c:	1e612800 	fadd	d0, d0, d1
    4720:	a94153f3 	ldp	x19, x20, [sp, #16]
    4724:	cb020000 	sub	x0, x0, x2
    4728:	f90a12a0 	str	x0, [x21, #5152]
    472c:	fd0a22a0 	str	d0, [x21, #5184]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4738:	d65f03c0 	ret
    473c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4740:	8b000063 	add	x3, x3, x0
    4744:	eb03027f 	cmp	x19, x3
    4748:	54fff9e1 	b.ne	4684 <fwp_mem_free+0x64>  // b.any
    474c:	fd400ae1 	ldr	d1, [x23, #16]
    4750:	fd4a2020 	ldr	d0, [x1, #5184]
    4754:	f9400ae0 	ldr	x0, [x23, #16]
    4758:	7e61d821 	ucvtf	d1, d1
    475c:	f94a1022 	ldr	x2, [x1, #5152]
    4760:	f94012f3 	ldr	x19, [x23, #32]
    4764:	1e612800 	fadd	d0, d0, d1
    4768:	cb000042 	sub	x2, x2, x0
    476c:	f90a1022 	str	x2, [x1, #5152]
    4770:	fd0a2020 	str	d0, [x1, #5184]
    4774:	b40000b3 	cbz	x19, 4788 <fwp_mem_free+0x168>
    4778:	39400260 	ldrb	w0, [x19]
    477c:	7103fc1f 	cmp	w0, #0xff
    4780:	54000380 	b.eq	47f0 <fwp_mem_free+0x1d0>  // b.none
    4784:	3900027f 	strb	wzr, [x19]
    4788:	b9400ee2 	ldr	w2, [x23, #12]
    478c:	b4000142 	cbz	x2, 47b4 <fwp_mem_free+0x194>
    4790:	9118c2a1 	add	x1, x21, #0x630
    4794:	8b160040 	add	x0, x2, x22
    4798:	8b000800 	add	x0, x0, x0, lsl #2
    479c:	f949fc21 	ldr	x1, [x1, #5112]
    47a0:	8b140034 	add	x20, x1, x20
    47a4:	8b000c20 	add	x0, x1, x0, lsl #3
    47a8:	3802869f 	strb	wzr, [x20], #40
    47ac:	eb00029f 	cmp	x20, x0
    47b0:	54ffffc1 	b.ne	47a8 <fwp_mem_free+0x188>  // b.any
    47b4:	9118c2a0 	add	x0, x21, #0x630
    47b8:	f94a1801 	ldr	x1, [x0, #5168]
    47bc:	f949f803 	ldr	x3, [x0, #5104]
    47c0:	8b020021 	add	x1, x1, x2
    47c4:	f90a1801 	str	x1, [x0, #5168]
    47c8:	eb16007f 	cmp	x3, x22
    47cc:	54000049 	b.ls	47d4 <fwp_mem_free+0x1b4>  // b.plast
    47d0:	f909f816 	str	x22, [x0, #5104]
    47d4:	9118c2b5 	add	x21, x21, #0x630
    47d8:	f949f6a0 	ldr	x0, [x21, #5096]
    47dc:	eb16001f 	cmp	x0, x22
    47e0:	54fff529 	b.ls	4684 <fwp_mem_free+0x64>  // b.plast
    47e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47e8:	f909f6b6 	str	x22, [x21, #5096]
    47ec:	17ffffa7 	b	4688 <fwp_mem_free+0x68>
    47f0:	aa1303e0 	mov	x0, x19
    47f4:	97fffef0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    47f8:	17ffffe3 	b	4784 <fwp_mem_free+0x164>
    47fc:	97fffeee 	bl	43b4 <fwp_rc_forget_slot.part.0>
    4800:	17ffffb4 	b	46d0 <fwp_mem_free+0xb0>

0000000000004804 <fwp_rc_wide_dup>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	910003fd 	mov	x29, sp
    480c:	a90153f3 	stp	x19, x20, [sp, #16]
    4810:	aa0003f3 	mov	x19, x0
    4814:	ca404400 	eor	x0, x0, x0, lsr #17
    4818:	f90013f5 	str	x21, [sp, #32]
    481c:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    4820:	ca402400 	eor	x0, x0, x0, lsr #9
    4824:	9118c2a2 	add	x2, x21, #0x630
    4828:	92401c00 	and	x0, x0, #0xff
    482c:	910a2403 	add	x3, x0, #0x289
    4830:	8b000c40 	add	x0, x2, x0, lsl #3
    4834:	8b030c54 	add	x20, x2, x3, lsl #3
    4838:	f94a2401 	ldr	x1, [x0, #5192]
    483c:	b50000a1 	cbnz	x1, 4850 <fwp_rc_wide_dup+0x4c>
    4840:	14000033 	b	490c <fwp_rc_wide_dup+0x108>
    4844:	91004034 	add	x20, x1, #0x10
    4848:	f9400821 	ldr	x1, [x1, #16]
    484c:	b4000241 	cbz	x1, 4894 <fwp_rc_wide_dup+0x90>
    4850:	f9400022 	ldr	x2, [x1]
    4854:	eb02027f 	cmp	x19, x2
    4858:	54ffff61 	b.ne	4844 <fwp_rc_wide_dup+0x40>  // b.any
    485c:	f9400281 	ldr	x1, [x20]
    4860:	39400260 	ldrb	w0, [x19]
    4864:	7103f81f 	cmp	w0, #0xfe
    4868:	54000220 	b.eq	48ac <fwp_rc_wide_dup+0xa8>  // b.none
    486c:	b40001a1 	cbz	x1, 48a0 <fwp_rc_wide_dup+0x9c>
    4870:	f9400420 	ldr	x0, [x1, #8]
    4874:	b100041f 	cmn	x0, #0x1
    4878:	54000440 	b.eq	4900 <fwp_rc_wide_dup+0xfc>  // b.none
    487c:	91000400 	add	x0, x0, #0x1
    4880:	f9000420 	str	x0, [x1, #8]
    4884:	a94153f3 	ldp	x19, x20, [sp, #16]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	39400260 	ldrb	w0, [x19]
    4898:	7103f81f 	cmp	w0, #0xfe
    489c:	54000100 	b.eq	48bc <fwp_rc_wide_dup+0xb8>  // b.none
    48a0:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    48a4:	912e6000 	add	x0, x0, #0xb98
    48a8:	97fffea3 	bl	4334 <fwp_trap>
    48ac:	b4000081 	cbz	x1, 48bc <fwp_rc_wide_dup+0xb8>
    48b0:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    48b4:	912f0000 	add	x0, x0, #0xbc0
    48b8:	97fffe9f 	bl	4334 <fwp_trap>
    48bc:	d2800300 	mov	x0, #0x18                  	// #24
    48c0:	97fff7e0 	bl	2840 <malloc@plt>
    48c4:	b4000280 	cbz	x0, 4914 <fwp_rc_wide_dup+0x110>
    48c8:	d2801fe1 	mov	x1, #0xff                  	// #255
    48cc:	a9000413 	stp	x19, x1, [x0]
    48d0:	9118c2b5 	add	x21, x21, #0x630
    48d4:	f900081f 	str	xzr, [x0, #16]
    48d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    48dc:	f9000280 	str	x0, [x20]
    48e0:	39000261 	strb	w1, [x19]
    48e4:	f94e26a0 	ldr	x0, [x21, #7240]
    48e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f90e26a0 	str	x0, [x21, #7240]
    48f4:	f94013f5 	ldr	x21, [sp, #32]
    48f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48fc:	d65f03c0 	ret
    4900:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4904:	912fa000 	add	x0, x0, #0xbe8
    4908:	97fffe8b 	bl	4334 <fwp_trap>
    490c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4910:	17ffffd4 	b	4860 <fwp_rc_wide_dup+0x5c>
    4914:	97fffa17 	bl	3170 <fwp_heap_oom>
    4918:	d503201f 	nop
    491c:	d503201f 	nop

0000000000004920 <fwp_closure_drop_push>:
    4920:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4924:	910003fd 	mov	x29, sp
    4928:	a90153f3 	stp	x19, x20, [sp, #16]
    492c:	aa0003f3 	mov	x19, x0
    4930:	a9408014 	ldp	x20, x0, [x0, #8]
    4934:	a9025bf5 	stp	x21, x22, [sp, #32]
    4938:	aa0103f5 	mov	x21, x1
    493c:	a90363f7 	stp	x23, x24, [sp, #48]
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000160 	b.eq	4970 <fwp_closure_drop_push+0x50>  // b.none
    4948:	f9400276 	ldr	x22, [x19]
    494c:	d37df297 	lsl	x23, x20, #3
    4950:	91000694 	add	x20, x20, #0x1
    4954:	f9000674 	str	x20, [x19, #8]
    4958:	a94153f3 	ldp	x19, x20, [sp, #16]
    495c:	f8376ad5 	str	x21, [x22, x23]
    4960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4964:	a94363f7 	ldp	x23, x24, [sp, #48]
    4968:	a8c57bfd 	ldp	x29, x30, [sp], #80
    496c:	d65f03c0 	ret
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4978:	eb00029f 	cmp	x20, x0
    497c:	540003e8 	b.hi	49f8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4980:	d37cee99 	lsl	x25, x20, #4
    4984:	d37ffa9a 	lsl	x26, x20, #1
    4988:	aa1903e0 	mov	x0, x25
    498c:	97fff7ad 	bl	2840 <malloc@plt>
    4990:	aa0003f6 	mov	x22, x0
    4994:	b4000380 	cbz	x0, 4a04 <fwp_closure_drop_push+0xe4>
    4998:	aa1303f8 	mov	x24, x19
    499c:	aa1903e3 	mov	x3, x25
    49a0:	d37df297 	lsl	x23, x20, #3
    49a4:	aa1703e2 	mov	x2, x23
    49a8:	f8418719 	ldr	x25, [x24], #24
    49ac:	aa1903e1 	mov	x1, x25
    49b0:	97fff790 	bl	27f0 <__memcpy_chk@plt>
    49b4:	eb18033f 	cmp	x25, x24
    49b8:	540000a0 	b.eq	49cc <fwp_closure_drop_push+0xac>  // b.none
    49bc:	aa1903e0 	mov	x0, x25
    49c0:	97fff7e8 	bl	2960 <free@plt>
    49c4:	f9400674 	ldr	x20, [x19, #8]
    49c8:	d37df297 	lsl	x23, x20, #3
    49cc:	91000694 	add	x20, x20, #0x1
    49d0:	f9000276 	str	x22, [x19]
    49d4:	f9000a7a 	str	x26, [x19, #16]
    49d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    49dc:	f9000674 	str	x20, [x19, #8]
    49e0:	f8376ad5 	str	x21, [x22, x23]
    49e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    49f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49f4:	d65f03c0 	ret
    49f8:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    49fc:	91302000 	add	x0, x0, #0xc08
    4a00:	97fffe4d 	bl	4334 <fwp_trap>
    4a04:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    4a08:	f947e863 	ldr	x3, [x3, #4048]
    4a0c:	d2800262 	mov	x2, #0x13                  	// #19
    4a10:	d2800021 	mov	x1, #0x1                   	// #1
    4a14:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4a18:	91212000 	add	x0, x0, #0x848
    4a1c:	f9400063 	ldr	x3, [x3]
    4a20:	97fff7e0 	bl	29a0 <fwrite@plt>
    4a24:	d2800000 	mov	x0, #0x0                   	// #0
    4a28:	97fff7ea 	bl	29d0 <fflush@plt>
    4a2c:	52800cc0 	mov	w0, #0x66                  	// #102
    4a30:	97fff7f8 	bl	2a10 <_Exit@plt>

0000000000004a34 <fwp_closure_drop.part.0>:
    4a34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a38:	f0000041 	adrp	x1, f000 <_IO_stdin_used+0x7c0>
    4a3c:	910003fd 	mov	x29, sp
    4a40:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    4a44:	f947f463 	ldr	x3, [x3, #4072]
    4a48:	a90153f3 	stp	x19, x20, [sp, #16]
    4a4c:	d10883ff 	sub	sp, sp, #0x220
    4a50:	910003e2 	mov	x2, sp
    4a54:	d53bd053 	mrs	x19, tpidr_el0
    4a58:	910063f4 	add	x20, sp, #0x18
    4a5c:	3dc20420 	ldr	q0, [x1, #2064]
    4a60:	91400264 	add	x4, x19, #0x0, lsl #12
    4a64:	91004084 	add	x4, x4, #0x10
    4a68:	aa0003e1 	mov	x1, x0
    4a6c:	aa0203e0 	mov	x0, x2
    4a70:	f9400062 	ldr	x2, [x3]
    4a74:	f9010fe2 	str	x2, [sp, #536]
    4a78:	d2800002 	mov	x2, #0x0                   	// #0
    4a7c:	f90003f4 	str	x20, [sp]
    4a80:	f9000080 	str	x0, [x4]
    4a84:	3c8083e0 	stur	q0, [sp, #8]
    4a88:	97ffffa6 	bl	4920 <fwp_closure_drop_push>
    4a8c:	f94007e0 	ldr	x0, [sp, #8]
    4a90:	b40002e0 	cbz	x0, 4aec <fwp_closure_drop.part.0+0xb8>
    4a94:	f90123f5 	str	x21, [sp, #576]
    4a98:	90000175 	adrp	x21, 30000 <__data_start>
    4a9c:	910142b5 	add	x21, x21, #0x50
    4aa0:	14000006 	b	4ab8 <fwp_closure_drop.part.0+0x84>
    4aa4:	f9400422 	ldr	x2, [x1, #8]
    4aa8:	52800001 	mov	w1, #0x0                   	// #0
    4aac:	d63f0040 	blr	x2
    4ab0:	f94007e0 	ldr	x0, [sp, #8]
    4ab4:	b40001a0 	cbz	x0, 4ae8 <fwp_closure_drop.part.0+0xb4>
    4ab8:	f94003e1 	ldr	x1, [sp]
    4abc:	d1000400 	sub	x0, x0, #0x1
    4ac0:	f90007e0 	str	x0, [sp, #8]
    4ac4:	f9408ea2 	ldr	x2, [x21, #280]
    4ac8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4acc:	b9400001 	ldr	w1, [x0]
    4ad0:	8b011441 	add	x1, x2, x1, lsl #5
    4ad4:	f9400c21 	ldr	x1, [x1, #24]
    4ad8:	b5fffe61 	cbnz	x1, 4aa4 <fwp_closure_drop.part.0+0x70>
    4adc:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4ae0:	9130a000 	add	x0, x0, #0xc28
    4ae4:	97fffe14 	bl	4334 <fwp_trap>
    4ae8:	f94123f5 	ldr	x21, [sp, #576]
    4aec:	91400273 	add	x19, x19, #0x0, lsl #12
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	f94003e0 	ldr	x0, [sp]
    4af8:	f900027f 	str	xzr, [x19]
    4afc:	eb14001f 	cmp	x0, x20
    4b00:	54000040 	b.eq	4b08 <fwp_closure_drop.part.0+0xd4>  // b.none
    4b04:	97fff797 	bl	2960 <free@plt>
    4b08:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    4b0c:	f947f400 	ldr	x0, [x0, #4072]
    4b10:	f9410fe2 	ldr	x2, [sp, #536]
    4b14:	f9400001 	ldr	x1, [x0]
    4b18:	eb010042 	subs	x2, x2, x1
    4b1c:	d2800001 	mov	x1, #0x0                   	// #0
    4b20:	540000a1 	b.ne	4b34 <fwp_closure_drop.part.0+0x100>  // b.any
    4b24:	910883ff 	add	sp, sp, #0x220
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b30:	d65f03c0 	ret
    4b34:	f90123f5 	str	x21, [sp, #576]
    4b38:	97fff75a 	bl	28a0 <__stack_chk_fail@plt>
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_tape_of>:
    4b40:	aa0003e1 	mov	x1, x0
    4b44:	92403c00 	and	x0, x0, #0xffff
    4b48:	b40000e0 	cbz	x0, 4b64 <fwp_tape_of+0x24>
    4b4c:	d1000402 	sub	x2, x0, #0x1
    4b50:	90000160 	adrp	x0, 30000 <__data_start>
    4b54:	91014000 	add	x0, x0, #0x50
    4b58:	f9409003 	ldr	x3, [x0, #288]
    4b5c:	eb02007f 	cmp	x3, x2
    4b60:	540000cc 	b.gt	4b78 <fwp_tape_of+0x38>
    4b64:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b68:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4b6c:	91316000 	add	x0, x0, #0xc58
    4b70:	910003fd 	mov	x29, sp
    4b74:	97fffdf0 	bl	4334 <fwp_trap>
    4b78:	8b020443 	add	x3, x2, x2, lsl #1
    4b7c:	f9404404 	ldr	x4, [x0, #136]
    4b80:	8b030842 	add	x2, x2, x3, lsl #2
    4b84:	d37df042 	lsl	x2, x2, #3
    4b88:	8b020080 	add	x0, x4, x2
    4b8c:	b9400403 	ldr	w3, [x0, #4]
    4b90:	34fffea3 	cbz	w3, 4b64 <fwp_tape_of+0x24>
    4b94:	b8626882 	ldr	w2, [x4, x2]
    4b98:	9350fc21 	asr	x1, x1, #16
    4b9c:	6b01005f 	cmp	w2, w1
    4ba0:	54fffe21 	b.ne	4b64 <fwp_tape_of+0x24>  // b.any
    4ba4:	d65f03c0 	ret
    4ba8:	d503201f 	nop
    4bac:	d503201f 	nop

0000000000004bb0 <fwp_now_ns>:
    4bb0:	d100c3ff 	sub	sp, sp, #0x30
    4bb4:	52800020 	mov	w0, #0x1                   	// #1
    4bb8:	f0000142 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    4bbc:	f947f442 	ldr	x2, [x2, #4072]
    4bc0:	910023e1 	add	x1, sp, #0x8
    4bc4:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bc8:	910083fd 	add	x29, sp, #0x20
    4bcc:	f9400043 	ldr	x3, [x2]
    4bd0:	f9000fe3 	str	x3, [sp, #24]
    4bd4:	d2800003 	mov	x3, #0x0                   	// #0
    4bd8:	97fff6fe 	bl	27d0 <clock_gettime@plt>
    4bdc:	350002c0 	cbnz	w0, 4c34 <fwp_now_ns+0x84>
    4be0:	a9408be1 	ldp	x1, x2, [sp, #8]
    4be4:	d2994003 	mov	x3, #0xca00                	// #51712
    4be8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4bec:	9b037c20 	mul	x0, x1, x3
    4bf0:	9b437c21 	smulh	x1, x1, x3
    4bf4:	ab020000 	adds	x0, x0, x2
    4bf8:	937ffc42 	asr	x2, x2, #63
    4bfc:	9a020021 	adc	x1, x1, x2
    4c00:	f100001f 	cmp	x0, #0x0
    4c04:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4c08:	b50001c1 	cbnz	x1, 4c40 <fwp_now_ns+0x90>
    4c0c:	f0000141 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    4c10:	f947f421 	ldr	x1, [x1, #4072]
    4c14:	f9400fe3 	ldr	x3, [sp, #24]
    4c18:	f9400022 	ldr	x2, [x1]
    4c1c:	eb020063 	subs	x3, x3, x2
    4c20:	d2800002 	mov	x2, #0x0                   	// #0
    4c24:	54000141 	b.ne	4c4c <fwp_now_ns+0x9c>  // b.any
    4c28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c2c:	9100c3ff 	add	sp, sp, #0x30
    4c30:	d65f03c0 	ret
    4c34:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4c38:	9132a000 	add	x0, x0, #0xca8
    4c3c:	97fffdbe 	bl	4334 <fwp_trap>
    4c40:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4c44:	91332000 	add	x0, x0, #0xcc8
    4c48:	97fffdbb 	bl	4334 <fwp_trap>
    4c4c:	97fff715 	bl	28a0 <__stack_chk_fail@plt>

0000000000004c50 <fwp_poll_events>:
    4c50:	d10103ff 	sub	sp, sp, #0x40
    4c54:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    4c58:	f947f400 	ldr	x0, [x0, #4072]
    4c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c60:	910083fd 	add	x29, sp, #0x20
    4c64:	f9001bf3 	str	x19, [sp, #48]
    4c68:	90000173 	adrp	x19, 30000 <__data_start>
    4c6c:	f9400001 	ldr	x1, [x0]
    4c70:	f9000fe1 	str	x1, [sp, #24]
    4c74:	d2800001 	mov	x1, #0x0                   	// #0
    4c78:	97ffffce 	bl	4bb0 <fwp_now_ns>
    4c7c:	91014261 	add	x1, x19, #0x50
    4c80:	f9409421 	ldr	x1, [x1, #296]
    4c84:	b4000e01 	cbz	x1, 4e44 <fwp_poll_events+0x1f4>
    4c88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c8c:	14000005 	b	4ca0 <fwp_poll_events+0x50>
    4c90:	f9408821 	ldr	x1, [x1, #272]
    4c94:	eb03005f 	cmp	x2, x3
    4c98:	9a83d042 	csel	x2, x2, x3, le
    4c9c:	b40000c1 	cbz	x1, 4cb4 <fwp_poll_events+0x64>
    4ca0:	f9403423 	ldr	x3, [x1, #104]
    4ca4:	b6ffff62 	tbz	x2, #63, 4c90 <fwp_poll_events+0x40>
    4ca8:	f9408821 	ldr	x1, [x1, #272]
    4cac:	aa0303e2 	mov	x2, x3
    4cb0:	b5ffff81 	cbnz	x1, 4ca0 <fwp_poll_events+0x50>
    4cb4:	b7f80c82 	tbnz	x2, #63, 4e44 <fwp_poll_events+0x1f4>
    4cb8:	cb000042 	sub	x2, x2, x0
    4cbc:	f100005f 	cmp	x2, #0x0
    4cc0:	540003ad 	b.le	4d34 <fwp_poll_events+0xe4>
    4cc4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4cc8:	d2884804 	mov	x4, #0x4240                	// #16960
    4ccc:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4cd0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4cd4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4cd8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4cdc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ce0:	9b407c40 	smulh	x0, x2, x0
    4ce4:	9352fc00 	asr	x0, x0, #18
    4ce8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4cec:	9b048802 	msub	x2, x0, x4, x2
    4cf0:	f100005f 	cmp	x2, #0x0
    4cf4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4cf8:	eb01001f 	cmp	x0, x1
    4cfc:	5400098c 	b.gt	4e2c <fwp_poll_events+0x1dc>
    4d00:	340001a0 	cbz	w0, 4d34 <fwp_poll_events+0xe4>
    4d04:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4d08:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4d0c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4d10:	9ba17c01 	umull	x1, w0, w1
    4d14:	d366fc23 	lsr	x3, x1, #38
    4d18:	aa0303e2 	mov	x2, x3
    4d1c:	1b058063 	msub	w3, w3, w5, w0
    4d20:	9b247c63 	smull	x3, w3, w4
    4d24:	910023e0 	add	x0, sp, #0x8
    4d28:	d2800001 	mov	x1, #0x0                   	// #0
    4d2c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4d30:	97fff710 	bl	2970 <nanosleep@plt>
    4d34:	97ffff9f 	bl	4bb0 <fwp_now_ns>
    4d38:	91014268 	add	x8, x19, #0x50
    4d3c:	aa0003e7 	mov	x7, x0
    4d40:	4f000400 	movi	v0.4s, #0x0
    4d44:	52800029 	mov	w9, #0x1                   	// #1
    4d48:	f9409506 	ldr	x6, [x8, #296]
    4d4c:	d503201f 	nop
    4d50:	b40003e6 	cbz	x6, 4dcc <fwp_poll_events+0x17c>
    4d54:	f94034c1 	ldr	x1, [x6, #104]
    4d58:	aa0603e5 	mov	x5, x6
    4d5c:	f94088c6 	ldr	x6, [x6, #272]
    4d60:	eb07003f 	cmp	x1, x7
    4d64:	54ffff6c 	b.gt	4d50 <fwp_poll_events+0x100>
    4d68:	394154a0 	ldrb	w0, [x5, #85]
    4d6c:	36000120 	tbz	w0, #0, 4d90 <fwp_poll_events+0x140>
    4d70:	f94084a0 	ldr	x0, [x5, #264]
    4d74:	b4000560 	cbz	x0, 4e20 <fwp_poll_events+0x1d0>
    4d78:	f9008806 	str	x6, [x0, #272]
    4d7c:	b4000046 	cbz	x6, 4d84 <fwp_poll_events+0x134>
    4d80:	f90084c0 	str	x0, [x6, #264]
    4d84:	910800a0 	add	x0, x5, #0x200
    4d88:	390154bf 	strb	wzr, [x5, #85]
    4d8c:	3c908000 	stur	q0, [x0, #-248]
    4d90:	f94030a0 	ldr	x0, [x5, #96]
    4d94:	390158a9 	strb	w9, [x5, #86]
    4d98:	f100001f 	cmp	x0, #0x0
    4d9c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4da0:	540002cd 	b.le	4df8 <fwp_poll_events+0x1a8>
    4da4:	f94028a0 	ldr	x0, [x5, #80]
    4da8:	f2001c1f 	tst	x0, #0xff000000ff
    4dac:	54fffd21 	b.ne	4d50 <fwp_poll_events+0x100>  // b.any
    4db0:	f9406100 	ldr	x0, [x8, #192]
    4db4:	390150a9 	strb	w9, [x5, #84]
    4db8:	f90080bf 	str	xzr, [x5, #256]
    4dbc:	b40002c0 	cbz	x0, 4e14 <fwp_poll_events+0x1c4>
    4dc0:	f9006105 	str	x5, [x8, #192]
    4dc4:	f9008005 	str	x5, [x0, #256]
    4dc8:	b5fffc66 	cbnz	x6, 4d54 <fwp_poll_events+0x104>
    4dcc:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    4dd0:	f947f400 	ldr	x0, [x0, #4072]
    4dd4:	f9400fe2 	ldr	x2, [sp, #24]
    4dd8:	f9400001 	ldr	x1, [x0]
    4ddc:	eb010042 	subs	x2, x2, x1
    4de0:	d2800001 	mov	x1, #0x0                   	// #0
    4de4:	540002e1 	b.ne	4e40 <fwp_poll_events+0x1f0>  // b.any
    4de8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4dec:	f9401bf3 	ldr	x19, [sp, #48]
    4df0:	910103ff 	add	sp, sp, #0x40
    4df4:	d65f03c0 	ret
    4df8:	394144a0 	ldrb	w0, [x5, #81]
    4dfc:	3707fd40 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e00:	394140a0 	ldrb	w0, [x5, #80]
    4e04:	3707fd00 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e08:	aa0503e0 	mov	x0, x5
    4e0c:	97fffa39 	bl	36f0 <fwp_cancel_tree.part.0>
    4e10:	17ffffe5 	b	4da4 <fwp_poll_events+0x154>
    4e14:	f9006105 	str	x5, [x8, #192]
    4e18:	f9006505 	str	x5, [x8, #200]
    4e1c:	17ffffeb 	b	4dc8 <fwp_poll_events+0x178>
    4e20:	91014261 	add	x1, x19, #0x50
    4e24:	f9009426 	str	x6, [x1, #296]
    4e28:	17ffffd5 	b	4d7c <fwp_poll_events+0x12c>
    4e2c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4e30:	d2989362 	mov	x2, #0xc49b                	// #50331
    4e34:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4e38:	f2a00402 	movk	x2, #0x20, lsl #16
    4e3c:	17ffffba 	b	4d24 <fwp_poll_events+0xd4>
    4e40:	97fff698 	bl	28a0 <__stack_chk_fail@plt>
    4e44:	97fff88c 	bl	3074 <fwp_flush>
    4e48:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    4e4c:	f947e863 	ldr	x3, [x3, #4048]
    4e50:	d2800562 	mov	x2, #0x2b                  	// #43
    4e54:	d2800021 	mov	x1, #0x1                   	// #1
    4e58:	d0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    4e5c:	9133c000 	add	x0, x0, #0xcf0
    4e60:	f9400063 	ldr	x3, [x3]
    4e64:	97fff6cf 	bl	29a0 <fwrite@plt>
    4e68:	52800ca0 	mov	w0, #0x65                  	// #101
    4e6c:	97fff639 	bl	2750 <exit@plt>

0000000000004e70 <fwp_heap_alloc_big>:
    4e70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	a90153f3 	stp	x19, x20, [sp, #16]
    4e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e80:	a90363f7 	stp	x23, x24, [sp, #48]
    4e84:	aa0003f7 	mov	x23, x0
    4e88:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e8c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e90:	eb0002ff 	cmp	x23, x0
    4e94:	540008a8 	b.hi	4fa8 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e9c:	8b0002f4 	add	x20, x23, x0
    4ea0:	b000043a 	adrp	x26, 89000 <fwp_root_context+0xbb0>
    4ea4:	9118c359 	add	x25, x26, #0x630
    4ea8:	d350fe94 	lsr	x20, x20, #16
    4eac:	2a0103f5 	mov	w21, w1
    4eb0:	aa1403e0 	mov	x0, x20
    4eb4:	97fff8bf 	bl	31b0 <fwp_heap_chunks>
    4eb8:	f949ff22 	ldr	x2, [x25, #5112]
    4ebc:	8b000813 	add	x19, x0, x0, lsl #2
    4ec0:	aa0003f8 	mov	x24, x0
    4ec4:	52800043 	mov	w3, #0x2                   	// #2
    4ec8:	d37df273 	lsl	x19, x19, #3
    4ecc:	d2800021 	mov	x1, #0x1                   	// #1
    4ed0:	8b130040 	add	x0, x2, x19
    4ed4:	38336843 	strb	w3, [x2, x19]
    4ed8:	39000415 	strb	w21, [x0, #1]
    4edc:	b9000c14 	str	w20, [x0, #12]
    4ee0:	f9000817 	str	x23, [x0, #16]
    4ee4:	97fffd57 	bl	4440 <fwp_rc_prepare_chunk>
    4ee8:	f100069f 	cmp	x20, #0x1
    4eec:	54000289 	b.ls	4f3c <fwp_heap_alloc_big+0xcc>  // b.plast
    4ef0:	8b180294 	add	x20, x20, x24
    4ef4:	9100a273 	add	x19, x19, #0x28
    4ef8:	a90573fb 	stp	x27, x28, [sp, #80]
    4efc:	5280007b 	mov	w27, #0x3                   	// #3
    4f00:	8b140a94 	add	x20, x20, x20, lsl #2
    4f04:	2a1803fc 	mov	w28, w24
    4f08:	9adb2296 	lsl	x22, x20, x27
    4f0c:	d503201f 	nop
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffd48 	bl	4440 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0xa0>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x108>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffb37 	bl	3d70 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff6f 	b	4e70 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffd19 	bl	4560 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f0000156 	adrp	x22, 30000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	540008a1 	b.ne	524c <fwp_heap_alloc+0x13c>  // b.any
    513c:	90000437 	adrp	x23, 89000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	54000722 	b.cs	5298 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	5400030c 	b.gt	5260 <fwp_heap_alloc+0x150>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000249 	b.ls	527c <fwp_heap_alloc+0x16c>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	910142c1 	add	x1, x22, #0x50
    5244:	b9413038 	ldr	w24, [x1, #304]
    5248:	17ffffe6 	b	51e0 <fwp_heap_alloc+0xd0>
    524c:	a9538c44 	ldp	x4, x3, [x2, #312]
    5250:	91000484 	add	x4, x4, #0x1
    5254:	8b000063 	add	x3, x3, x0
    5258:	a9138c44 	stp	x4, x3, [x2, #312]
    525c:	17ffffb8 	b	513c <fwp_heap_alloc+0x2c>
    5260:	a94153f3 	ldp	x19, x20, [sp, #16]
    5264:	fd00a800 	str	d0, [x0, #336]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	aa0403e0 	mov	x0, x4
    5270:	a94363f7 	ldp	x23, x24, [sp, #48]
    5274:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5278:	d65f03c0 	ret
    527c:	7100043f 	cmp	w1, #0x1
    5280:	8b140085 	add	x5, x4, x20
    5284:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5288:	52800001 	mov	w1, #0x0                   	// #0
    528c:	aa0403e0 	mov	x0, x4
    5290:	f9000465 	str	x5, [x3, #8]
    5294:	17ffffc4 	b	51a4 <fwp_heap_alloc+0x94>
    5298:	97fff7b6 	bl	3170 <fwp_heap_oom>
    529c:	d503201f 	nop

00000000000052a0 <fwp_data.part.0.constprop.0>:
    52a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52a4:	910003fd 	mov	x29, sp
    52a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    52ac:	f0000156 	adrp	x22, 30000 <__data_start>
    52b0:	910142c2 	add	x2, x22, #0x50
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	b9413059 	ldr	w25, [x2, #304]
    52bc:	a90153f3 	stp	x19, x20, [sp, #16]
    52c0:	aa0103f4 	mov	x20, x1
    52c4:	a90363f7 	stp	x23, x24, [sp, #48]
    52c8:	2a0003f7 	mov	w23, w0
    52cc:	340000b9 	cbz	w25, 52e0 <fwp_data.part.0.constprop.0+0x40>
    52d0:	a9538041 	ldp	x1, x0, [x2, #312]
    52d4:	91000421 	add	x1, x1, #0x1
    52d8:	91006000 	add	x0, x0, #0x18
    52dc:	a9138041 	stp	x1, x0, [x2, #312]
    52e0:	90000435 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    52e4:	9118c2a3 	add	x3, x21, #0x630
    52e8:	b953a460 	ldr	w0, [x3, #5028]
    52ec:	34000840 	cbz	w0, 53f4 <fwp_data.part.0.constprop.0+0x154>
    52f0:	397e8862 	ldrb	w2, [x3, #4002]
    52f4:	910f0040 	add	x0, x2, #0x3c0
    52f8:	8b020442 	add	x2, x2, x2, lsl #1
    52fc:	d37df042 	lsl	x2, x2, #3
    5300:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5304:	2a1a03f8 	mov	w24, w26
    5308:	f8626873 	ldr	x19, [x3, x2]
    530c:	b4000613 	cbz	x19, 53cc <fwp_data.part.0.constprop.0+0x12c>
    5310:	f9400260 	ldr	x0, [x19]
    5314:	aa2003e0 	mvn	x0, x0
    5318:	f8226860 	str	x0, [x3, x2]
    531c:	f100631f 	cmp	x24, #0x18
    5320:	540000e9 	b.ls	533c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5324:	d1006702 	sub	x2, x24, #0x19
    5328:	91006260 	add	x0, x19, #0x18
    532c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5330:	52800001 	mov	w1, #0x0                   	// #0
    5334:	91002042 	add	x2, x2, #0x8
    5338:	97fff54e 	bl	2870 <memset@plt>
    533c:	9118c2a0 	add	x0, x21, #0x630
    5340:	f94a1001 	ldr	x1, [x0, #5152]
    5344:	ab180021 	adds	x1, x1, x24
    5348:	54000682 	b.cs	5418 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    534c:	f94a1402 	ldr	x2, [x0, #5160]
    5350:	f90a1001 	str	x1, [x0, #5152]
    5354:	eb02003f 	cmp	x1, x2
    5358:	54000049 	b.ls	5360 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    535c:	f90a1401 	str	x1, [x0, #5160]
    5360:	9118c2a0 	add	x0, x21, #0x630
    5364:	1e630341 	ucvtf	d1, w26
    5368:	fd4a1c00 	ldr	d0, [x0, #5176]
    536c:	1e612800 	fadd	d0, d0, d1
    5370:	fd0a1c00 	str	d0, [x0, #5176]
    5374:	34000139 	cbz	w25, 5398 <fwp_data.part.0.constprop.0+0xf8>
    5378:	9118c2b5 	add	x21, x21, #0x630
    537c:	910142d6 	add	x22, x22, #0x50
    5380:	fd4a12a0 	ldr	d0, [x21, #5152]
    5384:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5388:	7e61d800 	ucvtf	d0, d0
    538c:	1e623800 	fsub	d0, d0, d2
    5390:	1e612010 	fcmpe	d0, d1
    5394:	540003ec 	b.gt	5410 <fwp_data.part.0.constprop.0+0x170>
    5398:	52800040 	mov	w0, #0x2                   	// #2
    539c:	29000277 	stp	w23, w0, [x19]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	f9400281 	ldr	x1, [x20]
    53a8:	f9000661 	str	x1, [x19, #8]
    53ac:	f9400681 	ldr	x1, [x20, #8]
    53b0:	f9000a61 	str	x1, [x19, #16]
    53b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    53c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53c8:	d65f03c0 	ret
    53cc:	8b020063 	add	x3, x3, x2
    53d0:	f9400473 	ldr	x19, [x3, #8]
    53d4:	b4000113 	cbz	x19, 53f4 <fwp_data.part.0.constprop.0+0x154>
    53d8:	f9400860 	ldr	x0, [x3, #16]
    53dc:	cb130000 	sub	x0, x0, x19
    53e0:	eb00031f 	cmp	x24, x0
    53e4:	54000088 	b.hi	53f4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53e8:	8b180260 	add	x0, x19, x24
    53ec:	f9000460 	str	x0, [x3, #8]
    53f0:	17ffffcb 	b	531c <fwp_data.part.0.constprop.0+0x7c>
    53f4:	52800001 	mov	w1, #0x0                   	// #0
    53f8:	d2800300 	mov	x0, #0x18                  	// #24
    53fc:	97ffff45 	bl	5110 <fwp_heap_alloc>
    5400:	aa0003f3 	mov	x19, x0
    5404:	910142c1 	add	x1, x22, #0x50
    5408:	b9413039 	ldr	w25, [x1, #304]
    540c:	17ffffda 	b	5374 <fwp_data.part.0.constprop.0+0xd4>
    5410:	fd00aac0 	str	d0, [x22, #336]
    5414:	17ffffe1 	b	5398 <fwp_data.part.0.constprop.0+0xf8>
    5418:	97fff756 	bl	3170 <fwp_heap_oom>
    541c:	d503201f 	nop

0000000000005420 <fwp_tape_grow.constprop.0>:
    5420:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5424:	d2800803 	mov	x3, #0x40                  	// #64
    5428:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    542c:	910003fd 	mov	x29, sp
    5430:	a90153f3 	stp	x19, x20, [sp, #16]
    5434:	f9400c13 	ldr	x19, [x0, #24]
    5438:	a90363f7 	stp	x23, x24, [sp, #48]
    543c:	aa0003f7 	mov	x23, x0
    5440:	f100027f 	cmp	x19, #0x0
    5444:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    5448:	eb13003f 	cmp	x1, x19
    544c:	540000ed 	b.le	5468 <fwp_tape_grow.constprop.0+0x48>
    5450:	eb02027f 	cmp	x19, x2
    5454:	5400078d 	b.le	5544 <fwp_tape_grow.constprop.0+0x124>
    5458:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    545c:	eb13003f 	cmp	x1, x19
    5460:	5400004d 	b.le	5468 <fwp_tape_grow.constprop.0+0x48>
    5464:	14000000 	b	5464 <fwp_tape_grow.constprop.0+0x44>
    5468:	a940d2e3 	ldp	x3, x20, [x23, #8]
    546c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5470:	d37df276 	lsl	x22, x19, #3
    5474:	f94012e0 	ldr	x0, [x23, #32]
    5478:	aa1603e1 	mov	x1, x22
    547c:	f94032f5 	ldr	x21, [x23, #96]
    5480:	cb030294 	sub	x20, x20, x3
    5484:	52800022 	mov	w2, #0x1                   	// #1
    5488:	97fffb0f 	bl	40c4 <ad_raw_realloc>
    548c:	b4000bc0 	cbz	x0, 5604 <fwp_tape_grow.constprop.0+0x1e4>
    5490:	f9400ee1 	ldr	x1, [x23, #24]
    5494:	8b010801 	add	x1, x0, x1, lsl #2
    5498:	a90206e0 	stp	x0, x1, [x23, #32]
    549c:	b4000835 	cbz	x21, 55a0 <fwp_tape_grow.constprop.0+0x180>
    54a0:	f94032b6 	ldr	x22, [x21, #96]
    54a4:	eb1302df 	cmp	x22, x19
    54a8:	540003aa 	b.ge	551c <fwp_tape_grow.constprop.0+0xfc>  // b.tcont
    54ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    54b4:	eb00027f 	cmp	x19, x0
    54b8:	54000a08 	b.hi	55f8 <fwp_tape_grow.constprop.0+0x1d8>  // b.pmore
    54bc:	f94022b9 	ldr	x25, [x21, #64]
    54c0:	d37cee7a 	lsl	x26, x19, #4
    54c4:	aa1a03e0 	mov	x0, x26
    54c8:	52800041 	mov	w1, #0x2                   	// #2
    54cc:	97ffff11 	bl	5110 <fwp_heap_alloc>
    54d0:	aa0003f8 	mov	x24, x0
    54d4:	b4000119 	cbz	x25, 54f4 <fwp_tape_grow.constprop.0+0xd4>
    54d8:	d37ceed6 	lsl	x22, x22, #4
    54dc:	aa1903e1 	mov	x1, x25
    54e0:	eb1a02df 	cmp	x22, x26
    54e4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    54e8:	97fff482 	bl	26f0 <memcpy@plt>
    54ec:	aa1903e0 	mov	x0, x25
    54f0:	97fffc4c 	bl	4620 <fwp_mem_free>
    54f4:	f94032a0 	ldr	x0, [x21, #96]
    54f8:	52800001 	mov	w1, #0x0                   	// #0
    54fc:	cb000262 	sub	x2, x19, x0
    5500:	8b001300 	add	x0, x24, x0, lsl #4
    5504:	d37cec42 	lsl	x2, x2, #4
    5508:	97fff4da 	bl	2870 <memset@plt>
    550c:	f94012e0 	ldr	x0, [x23, #32]
    5510:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5514:	f90022b8 	str	x24, [x21, #64]
    5518:	f90032b3 	str	x19, [x21, #96]
    551c:	d37ef675 	lsl	x21, x19, #2
    5520:	b5000254 	cbnz	x20, 5568 <fwp_tape_grow.constprop.0+0x148>
    5524:	8b150001 	add	x1, x0, x21
    5528:	a9425bf5 	ldp	x21, x22, [sp, #32]
    552c:	f9000ef3 	str	x19, [x23, #24]
    5530:	f90016e1 	str	x1, [x23, #40]
    5534:	a94153f3 	ldp	x19, x20, [sp, #16]
    5538:	a94363f7 	ldp	x23, x24, [sp, #48]
    553c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5540:	d65f03c0 	ret
    5544:	d37ffa73 	lsl	x19, x19, #1
    5548:	17ffffc0 	b	5448 <fwp_tape_grow.constprop.0+0x28>
    554c:	aa0303e0 	mov	x0, x3
    5550:	d37df282 	lsl	x2, x20, #3
    5554:	97fff46f 	bl	2710 <memmove@plt>
    5558:	f9401ae1 	ldr	x1, [x23, #48]
    555c:	f94012e0 	ldr	x0, [x23, #32]
    5560:	8b160021 	add	x1, x1, x22
    5564:	f9001ee1 	str	x1, [x23, #56]
    5568:	f94016e1 	ldr	x1, [x23, #40]
    556c:	d37ef675 	lsl	x21, x19, #2
    5570:	d37ef682 	lsl	x2, x20, #2
    5574:	8b150000 	add	x0, x0, x21
    5578:	97fff466 	bl	2710 <memmove@plt>
    557c:	f94012e0 	ldr	x0, [x23, #32]
    5580:	8b150001 	add	x1, x0, x21
    5584:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5588:	f9000ef3 	str	x19, [x23, #24]
    558c:	f90016e1 	str	x1, [x23, #40]
    5590:	a94153f3 	ldp	x19, x20, [sp, #16]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	a8c57bfd 	ldp	x29, x30, [sp], #80
    559c:	d65f03c0 	ret
    55a0:	f9401ae0 	ldr	x0, [x23, #48]
    55a4:	d37cee61 	lsl	x1, x19, #4
    55a8:	52800042 	mov	w2, #0x2                   	// #2
    55ac:	97fffac6 	bl	40c4 <ad_raw_realloc>
    55b0:	b40002a0 	cbz	x0, 5604 <fwp_tape_grow.constprop.0+0x1e4>
    55b4:	f9400ee2 	ldr	x2, [x23, #24]
    55b8:	f9001ae0 	str	x0, [x23, #48]
    55bc:	8b160003 	add	x3, x0, x22
    55c0:	8b020c01 	add	x1, x0, x2, lsl #3
    55c4:	f9001ee1 	str	x1, [x23, #56]
    55c8:	b5fffc34 	cbnz	x20, 554c <fwp_tape_grow.constprop.0+0x12c>
    55cc:	f94012e0 	ldr	x0, [x23, #32]
    55d0:	d37ef675 	lsl	x21, x19, #2
    55d4:	f9001ee3 	str	x3, [x23, #56]
    55d8:	8b150001 	add	x1, x0, x21
    55dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e0:	f9000ef3 	str	x19, [x23, #24]
    55e4:	f90016e1 	str	x1, [x23, #40]
    55e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    55fc:	91352000 	add	x0, x0, #0xd48
    5600:	97fffb4d 	bl	4334 <fwp_trap>
    5604:	aa1703e0 	mov	x0, x23
    5608:	a9046bf9 	stp	x25, x26, [sp, #64]
    560c:	97fff682 	bl	3014 <fwp_tape_unlink_scope>
    5610:	f94012e0 	ldr	x0, [x23, #32]
    5614:	b4000040 	cbz	x0, 561c <fwp_tape_grow.constprop.0+0x1fc>
    5618:	97fffa76 	bl	3ff0 <ad_raw_free.part.0>
    561c:	f9401ae0 	ldr	x0, [x23, #48]
    5620:	b4000040 	cbz	x0, 5628 <fwp_tape_grow.constprop.0+0x208>
    5624:	97fffa73 	bl	3ff0 <ad_raw_free.part.0>
    5628:	f94022e0 	ldr	x0, [x23, #64]
    562c:	b4000040 	cbz	x0, 5634 <fwp_tape_grow.constprop.0+0x214>
    5630:	97fffa70 	bl	3ff0 <ad_raw_free.part.0>
    5634:	d0000141 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    5638:	f947e821 	ldr	x1, [x1, #4048]
    563c:	f9000eff 	str	xzr, [x23, #24]
    5640:	4f000400 	movi	v0.4s, #0x0
    5644:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5648:	d2800262 	mov	x2, #0x13                  	// #19
    564c:	f9400023 	ldr	x3, [x1]
    5650:	b90006ff 	str	wzr, [x23, #4]
    5654:	d2800021 	mov	x1, #0x1                   	// #1
    5658:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    565c:	91212000 	add	x0, x0, #0x848
    5660:	3c8082e0 	stur	q0, [x23, #8]
    5664:	ad0102e0 	stp	q0, q0, [x23, #32]
    5668:	97fff4ce 	bl	29a0 <fwrite@plt>
    566c:	d2800000 	mov	x0, #0x0                   	// #0
    5670:	97fff4d8 	bl	29d0 <fflush@plt>
    5674:	52800cc0 	mov	w0, #0x66                  	// #102
    5678:	97fff4e6 	bl	2a10 <_Exit@plt>
    567c:	d503201f 	nop

0000000000005680 <f141.constprop.0>:
    5680:	f100001f 	cmp	x0, #0x0
    5684:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5688:	54000a2b 	b.lt	57cc <f141.constprop.0+0x14c>  // b.tstop
    568c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5690:	aa0003e2 	mov	x2, x0
    5694:	910003fd 	mov	x29, sp
    5698:	a90153f3 	stp	x19, x20, [sp, #16]
    569c:	aa0003f4 	mov	x20, x0
    56a0:	aa010000 	orr	x0, x0, x1
    56a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56a8:	aa0103f6 	mov	x22, x1
    56ac:	f9001bf7 	str	x23, [sp, #48]
    56b0:	fd001fe8 	str	d8, [sp, #56]
    56b4:	b7f80180 	tbnz	x0, #63, 56e4 <f141.constprop.0+0x64>
    56b8:	9360fc20 	asr	x0, x1, #32
    56bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56c0:	eb82801f 	cmp	x0, x2, asr #32
    56c4:	54000881 	b.ne	57d4 <f141.constprop.0+0x154>  // b.any
    56c8:	97fffd1e 	bl	4b40 <fwp_tape_of>
    56cc:	aa0003f3 	mov	x19, x0
    56d0:	f9403000 	ldr	x0, [x0, #96]
    56d4:	b40001e0 	cbz	x0, 5710 <f141.constprop.0+0x90>
    56d8:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    56dc:	9136c000 	add	x0, x0, #0xdb0
    56e0:	97fffb15 	bl	4334 <fwp_trap>
    56e4:	9360fc40 	asr	x0, x2, #32
    56e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56ec:	b6fffee2 	tbz	x2, #63, 56c8 <f141.constprop.0+0x48>
    56f0:	2f00e408 	movi	d8, #0x0
    56f4:	9360fc20 	asr	x0, x1, #32
    56f8:	aa0103f4 	mov	x20, x1
    56fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5700:	97fffd10 	bl	4b40 <fwp_tape_of>
    5704:	aa0003f3 	mov	x19, x0
    5708:	f9403000 	ldr	x0, [x0, #96]
    570c:	b5fffe60 	cbnz	x0, 56d8 <f141.constprop.0+0x58>
    5710:	f9400a77 	ldr	x23, [x19, #16]
    5714:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5718:	eb0002ff 	cmp	x23, x0
    571c:	5400046c 	b.gt	57a8 <f141.constprop.0+0x128>
    5720:	eb3442ff 	cmp	x23, w20, uxtw
    5724:	540004ed 	b.le	57c0 <f141.constprop.0+0x140>
    5728:	b7f80076 	tbnz	x22, #63, 5734 <f141.constprop.0+0xb4>
    572c:	eb3642ff 	cmp	x23, w22, uxtw
    5730:	5400048d 	b.le	57c0 <f141.constprop.0+0x140>
    5734:	f9400675 	ldr	x21, [x19, #8]
    5738:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    573c:	cb1502f5 	sub	x21, x23, x21
    5740:	910006a1 	add	x1, x21, #0x1
    5744:	eb00003f 	cmp	x1, x0
    5748:	54000308 	b.hi	57a8 <f141.constprop.0+0x128>  // b.pmore
    574c:	f9400e60 	ldr	x0, [x19, #24]
    5750:	eb00003f 	cmp	x1, x0
    5754:	5400030c 	b.gt	57b4 <f141.constprop.0+0x134>
    5758:	a9420262 	ldp	x2, x0, [x19, #32]
    575c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5760:	f9401a61 	ldr	x1, [x19, #48]
    5764:	b8357854 	str	w20, [x2, x21, lsl #2]
    5768:	f9401e62 	ldr	x2, [x19, #56]
    576c:	f10002df 	cmp	x22, #0x0
    5770:	fc357820 	str	d0, [x1, x21, lsl #3]
    5774:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5778:	b8357816 	str	w22, [x0, x21, lsl #2]
    577c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5780:	910006e1 	add	x1, x23, #0x1
    5784:	aa170000 	orr	x0, x0, x23
    5788:	fc357848 	str	d8, [x2, x21, lsl #3]
    578c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5790:	f9401bf7 	ldr	x23, [sp, #48]
    5794:	fd401fe8 	ldr	d8, [sp, #56]
    5798:	f9000a61 	str	x1, [x19, #16]
    579c:	a94153f3 	ldp	x19, x20, [sp, #16]
    57a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57a4:	d65f03c0 	ret
    57a8:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    57ac:	91352000 	add	x0, x0, #0xd48
    57b0:	97fffae1 	bl	4334 <fwp_trap>
    57b4:	aa1303e0 	mov	x0, x19
    57b8:	97ffff1a 	bl	5420 <fwp_tape_grow.constprop.0>
    57bc:	17ffffe7 	b	5758 <f141.constprop.0+0xd8>
    57c0:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    57c4:	91378000 	add	x0, x0, #0xde0
    57c8:	97fffadb 	bl	4334 <fwp_trap>
    57cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57d0:	d65f03c0 	ret
    57d4:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    57d8:	9135a000 	add	x0, x0, #0xd68
    57dc:	97fffad6 	bl	4334 <fwp_trap>

00000000000057e0 <w120>:
    57e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    57e4:	910003fd 	mov	x29, sp
    57e8:	a90153f3 	stp	x19, x20, [sp, #16]
    57ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    57f0:	a90363f7 	stp	x23, x24, [sp, #48]
    57f4:	aa0003f8 	mov	x24, x0
    57f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    57fc:	aa0103f9 	mov	x25, x1
    5800:	6d0527e8 	stp	d8, d9, [sp, #80]
    5804:	1e604008 	fmov	d8, d0
    5808:	1e604029 	fmov	d9, d1
    580c:	6d062fea 	stp	d10, d11, [sp, #96]
    5810:	1e60080a 	fmul	d10, d0, d0
    5814:	b7f821a0 	tbnz	x0, #63, 5c48 <w120+0x468>
    5818:	9360fc17 	asr	x23, x0, #32
    581c:	aa1703e0 	mov	x0, x23
    5820:	97fffcc8 	bl	4b40 <fwp_tape_of>
    5824:	f9403001 	ldr	x1, [x0, #96]
    5828:	aa0003f3 	mov	x19, x0
    582c:	b4000081 	cbz	x1, 583c <w120+0x5c>
    5830:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    5834:	9136c000 	add	x0, x0, #0xdb0
    5838:	97fffabf 	bl	4334 <fwp_trap>
    583c:	f9400815 	ldr	x21, [x0, #16]
    5840:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5844:	eb0102bf 	cmp	x21, x1
    5848:	54001d8c 	b.gt	5bf8 <w120+0x418>
    584c:	eb3842bf 	cmp	x21, w24, uxtw
    5850:	54001ced 	b.le	5bec <w120+0x40c>
    5854:	f9400416 	ldr	x22, [x0, #8]
    5858:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    585c:	cb1602b6 	sub	x22, x21, x22
    5860:	910006c1 	add	x1, x22, #0x1
    5864:	eb02003f 	cmp	x1, x2
    5868:	54001c88 	b.hi	5bf8 <w120+0x418>  // b.pmore
    586c:	f9400c02 	ldr	x2, [x0, #24]
    5870:	eb02003f 	cmp	x1, x2
    5874:	54001c8c 	b.gt	5c04 <w120+0x424>
    5878:	a9420660 	ldp	x0, x1, [x19, #32]
    587c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5880:	f9401a62 	ldr	x2, [x19, #48]
    5884:	b8367818 	str	w24, [x0, x22, lsl #2]
    5888:	f9401e60 	ldr	x0, [x19, #56]
    588c:	aa150294 	orr	x20, x20, x21
    5890:	fc367848 	str	d8, [x2, x22, lsl #3]
    5894:	910006b5 	add	x21, x21, #0x1
    5898:	b8367838 	str	w24, [x1, x22, lsl #2]
    589c:	1e6a392a 	fsub	d10, d9, d10
    58a0:	9360fe9a 	asr	x26, x20, #32
    58a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    58a8:	f9000a75 	str	x21, [x19, #16]
    58ac:	b7f80079 	tbnz	x25, #63, 58b8 <w120+0xd8>
    58b0:	eb99835f 	cmp	x26, x25, asr #32
    58b4:	54001e21 	b.ne	5c78 <w120+0x498>  // b.any
    58b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    58c0:	eb1a02ff 	cmp	x23, x26
    58c4:	540000c0 	b.eq	58dc <w120+0xfc>  // b.none
    58c8:	aa1a03e0 	mov	x0, x26
    58cc:	97fffc9d 	bl	4b40 <fwp_tape_of>
    58d0:	aa0003f3 	mov	x19, x0
    58d4:	f9403000 	ldr	x0, [x0, #96]
    58d8:	b5fffac0 	cbnz	x0, 5830 <w120+0x50>
    58dc:	f9400a77 	ldr	x23, [x19, #16]
    58e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58e4:	eb0002ff 	cmp	x23, x0
    58e8:	5400188c 	b.gt	5bf8 <w120+0x418>
    58ec:	eb3442ff 	cmp	x23, w20, uxtw
    58f0:	540017ed 	b.le	5bec <w120+0x40c>
    58f4:	b7f80079 	tbnz	x25, #63, 5900 <w120+0x120>
    58f8:	eb3942ff 	cmp	x23, w25, uxtw
    58fc:	5400178d 	b.le	5bec <w120+0x40c>
    5900:	f9400675 	ldr	x21, [x19, #8]
    5904:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5908:	cb1502f5 	sub	x21, x23, x21
    590c:	910006a1 	add	x1, x21, #0x1
    5910:	eb00003f 	cmp	x1, x0
    5914:	54001728 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5918:	f9400e60 	ldr	x0, [x19, #24]
    591c:	eb00003f 	cmp	x1, x0
    5920:	540018ec 	b.gt	5c3c <w120+0x45c>
    5924:	a9420e62 	ldp	x2, x3, [x19, #32]
    5928:	f100033f 	cmp	x25, #0x0
    592c:	f9401a61 	ldr	x1, [x19, #48]
    5930:	b8357854 	str	w20, [x2, x21, lsl #2]
    5934:	f9401e62 	ldr	x2, [x19, #56]
    5938:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    593c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5940:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5944:	b8357861 	str	w1, [x3, x21, lsl #2]
    5948:	910006f6 	add	x22, x23, #0x1
    594c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5950:	92607e94 	and	x20, x20, #0xffffffff00000000
    5954:	fc357849 	str	d9, [x2, x21, lsl #3]
    5958:	aa170294 	orr	x20, x20, x23
    595c:	f9000a76 	str	x22, [x19, #16]
    5960:	1e68396b 	fsub	d11, d11, d8
    5964:	b7f81a78 	tbnz	x24, #63, 5cb0 <w120+0x4d0>
    5968:	9360ff17 	asr	x23, x24, #32
    596c:	eb1a02ff 	cmp	x23, x26
    5970:	540000e0 	b.eq	598c <w120+0x1ac>  // b.none
    5974:	aa1703e0 	mov	x0, x23
    5978:	97fffc72 	bl	4b40 <fwp_tape_of>
    597c:	aa0003f3 	mov	x19, x0
    5980:	f9403000 	ldr	x0, [x0, #96]
    5984:	b5fff560 	cbnz	x0, 5830 <w120+0x50>
    5988:	f9400a76 	ldr	x22, [x19, #16]
    598c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5990:	eb0002df 	cmp	x22, x0
    5994:	5400132c 	b.gt	5bf8 <w120+0x418>
    5998:	eb3842df 	cmp	x22, w24, uxtw
    599c:	5400128d 	b.le	5bec <w120+0x40c>
    59a0:	f9400675 	ldr	x21, [x19, #8]
    59a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59a8:	cb1502d5 	sub	x21, x22, x21
    59ac:	910006a1 	add	x1, x21, #0x1
    59b0:	eb00003f 	cmp	x1, x0
    59b4:	54001228 	b.hi	5bf8 <w120+0x418>  // b.pmore
    59b8:	f9400e60 	ldr	x0, [x19, #24]
    59bc:	eb00003f 	cmp	x1, x0
    59c0:	5400138c 	b.gt	5c30 <w120+0x450>
    59c4:	a9420262 	ldp	x2, x0, [x19, #32]
    59c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    59cc:	f9401a63 	ldr	x3, [x19, #48]
    59d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    59d4:	f9401e62 	ldr	x2, [x19, #56]
    59d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    59dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    59e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    59e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    59e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    59ec:	aa160018 	orr	x24, x0, x22
    59f0:	910006c1 	add	x1, x22, #0x1
    59f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    59f8:	f9000a61 	str	x1, [x19, #16]
    59fc:	9360fe99 	asr	x25, x20, #32
    5a00:	1e6a0949 	fmul	d9, d10, d10
    5a04:	eb17033f 	cmp	x25, x23
    5a08:	540000c0 	b.eq	5a20 <w120+0x240>  // b.none
    5a0c:	aa1903e0 	mov	x0, x25
    5a10:	97fffc4c 	bl	4b40 <fwp_tape_of>
    5a14:	aa0003f3 	mov	x19, x0
    5a18:	f9403000 	ldr	x0, [x0, #96]
    5a1c:	b5fff0a0 	cbnz	x0, 5830 <w120+0x50>
    5a20:	f9400a75 	ldr	x21, [x19, #16]
    5a24:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a28:	eb0002bf 	cmp	x21, x0
    5a2c:	54000e6c 	b.gt	5bf8 <w120+0x418>
    5a30:	eb3442bf 	cmp	x21, w20, uxtw
    5a34:	54000dcd 	b.le	5bec <w120+0x40c>
    5a38:	f9400676 	ldr	x22, [x19, #8]
    5a3c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a40:	cb1602b6 	sub	x22, x21, x22
    5a44:	910006c1 	add	x1, x22, #0x1
    5a48:	eb00003f 	cmp	x1, x0
    5a4c:	54000d68 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5a50:	f9400e60 	ldr	x0, [x19, #24]
    5a54:	eb00003f 	cmp	x1, x0
    5a58:	54000e6c 	b.gt	5c24 <w120+0x444>
    5a5c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5a60:	aa150017 	orr	x23, x0, x21
    5a64:	a9420261 	ldp	x1, x0, [x19, #32]
    5a68:	f9401a62 	ldr	x2, [x19, #48]
    5a6c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5a70:	f9401e61 	ldr	x1, [x19, #56]
    5a74:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5a78:	b8367814 	str	w20, [x0, x22, lsl #2]
    5a7c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a80:	9e670000 	fmov	d0, x0
    5a84:	910006b4 	add	x20, x21, #0x1
    5a88:	fc36782a 	str	d10, [x1, x22, lsl #3]
    5a8c:	9360fef6 	asr	x22, x23, #32
    5a90:	f9000a74 	str	x20, [x19, #16]
    5a94:	1e600929 	fmul	d9, d9, d0
    5a98:	eb1902df 	cmp	x22, x25
    5a9c:	540000e0 	b.eq	5ab8 <w120+0x2d8>  // b.none
    5aa0:	aa1603e0 	mov	x0, x22
    5aa4:	97fffc27 	bl	4b40 <fwp_tape_of>
    5aa8:	aa0003f3 	mov	x19, x0
    5aac:	f9403000 	ldr	x0, [x0, #96]
    5ab0:	b5ffec00 	cbnz	x0, 5830 <w120+0x50>
    5ab4:	f9400a74 	ldr	x20, [x19, #16]
    5ab8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5abc:	eb00029f 	cmp	x20, x0
    5ac0:	540009cc 	b.gt	5bf8 <w120+0x418>
    5ac4:	eb37429f 	cmp	x20, w23, uxtw
    5ac8:	5400092d 	b.le	5bec <w120+0x40c>
    5acc:	f9400675 	ldr	x21, [x19, #8]
    5ad0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5ad4:	cb150295 	sub	x21, x20, x21
    5ad8:	910006a1 	add	x1, x21, #0x1
    5adc:	eb00003f 	cmp	x1, x0
    5ae0:	540008c8 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5ae4:	f9400e60 	ldr	x0, [x19, #24]
    5ae8:	eb00003f 	cmp	x1, x0
    5aec:	5400096c 	b.gt	5c18 <w120+0x438>
    5af0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5af4:	9e670000 	fmov	d0, x0
    5af8:	a9420262 	ldp	x2, x0, [x19, #32]
    5afc:	1e6b0968 	fmul	d8, d11, d11
    5b00:	f9401a61 	ldr	x1, [x19, #48]
    5b04:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b08:	f9401e62 	ldr	x2, [x19, #56]
    5b0c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5b10:	12800001 	mov	w1, #0xffffffff            	// #-1
    5b14:	b8357801 	str	w1, [x0, x21, lsl #2]
    5b18:	91000681 	add	x1, x20, #0x1
    5b1c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5b20:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b24:	f9000a61 	str	x1, [x19, #16]
    5b28:	aa140014 	orr	x20, x0, x20
    5b2c:	b100071f 	cmn	x24, #0x1
    5b30:	54000c60 	b.eq	5cbc <w120+0x4dc>  // b.none
    5b34:	9360ff00 	asr	x0, x24, #32
    5b38:	eb16001f 	cmp	x0, x22
    5b3c:	540000a0 	b.eq	5b50 <w120+0x370>  // b.none
    5b40:	97fffc00 	bl	4b40 <fwp_tape_of>
    5b44:	aa0003f3 	mov	x19, x0
    5b48:	f9403000 	ldr	x0, [x0, #96]
    5b4c:	b5ffe720 	cbnz	x0, 5830 <w120+0x50>
    5b50:	f9400a75 	ldr	x21, [x19, #16]
    5b54:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b58:	eb0002bf 	cmp	x21, x0
    5b5c:	540004ec 	b.gt	5bf8 <w120+0x418>
    5b60:	eb3842bf 	cmp	x21, w24, uxtw
    5b64:	5400044d 	b.le	5bec <w120+0x40c>
    5b68:	f9400676 	ldr	x22, [x19, #8]
    5b6c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b70:	cb1602b6 	sub	x22, x21, x22
    5b74:	910006c1 	add	x1, x22, #0x1
    5b78:	eb00003f 	cmp	x1, x0
    5b7c:	540003e8 	b.hi	5bf8 <w120+0x418>  // b.pmore
    5b80:	f9400e60 	ldr	x0, [x19, #24]
    5b84:	eb00003f 	cmp	x1, x0
    5b88:	5400042c 	b.gt	5c0c <w120+0x42c>
    5b8c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5b90:	92607f00 	and	x0, x24, #0xffffffff00000000
    5b94:	f9401a63 	ldr	x3, [x19, #48]
    5b98:	b8367838 	str	w24, [x1, x22, lsl #2]
    5b9c:	f9401e61 	ldr	x1, [x19, #56]
    5ba0:	aa150000 	orr	x0, x0, x21
    5ba4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5ba8:	910006b5 	add	x21, x21, #0x1
    5bac:	b8367858 	str	w24, [x2, x22, lsl #2]
    5bb0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5bb4:	f9000a75 	str	x21, [x19, #16]
    5bb8:	1e692908 	fadd	d8, d8, d9
    5bbc:	aa1403e1 	mov	x1, x20
    5bc0:	97fffeb0 	bl	5680 <f141.constprop.0>
    5bc4:	aa0003e1 	mov	x1, x0
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	9e660100 	fmov	x0, d8
    5bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5bd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bd8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5bdc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5be0:	6d462fea 	ldp	d10, d11, [sp, #96]
    5be4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5be8:	d65f03c0 	ret
    5bec:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    5bf0:	91378000 	add	x0, x0, #0xde0
    5bf4:	97fff9d0 	bl	4334 <fwp_trap>
    5bf8:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    5bfc:	91352000 	add	x0, x0, #0xd48
    5c00:	97fff9cd 	bl	4334 <fwp_trap>
    5c04:	97fffe07 	bl	5420 <fwp_tape_grow.constprop.0>
    5c08:	17ffff1c 	b	5878 <w120+0x98>
    5c0c:	aa1303e0 	mov	x0, x19
    5c10:	97fffe04 	bl	5420 <fwp_tape_grow.constprop.0>
    5c14:	17ffffde 	b	5b8c <w120+0x3ac>
    5c18:	aa1303e0 	mov	x0, x19
    5c1c:	97fffe01 	bl	5420 <fwp_tape_grow.constprop.0>
    5c20:	17ffffb4 	b	5af0 <w120+0x310>
    5c24:	aa1303e0 	mov	x0, x19
    5c28:	97fffdfe 	bl	5420 <fwp_tape_grow.constprop.0>
    5c2c:	17ffff8c 	b	5a5c <w120+0x27c>
    5c30:	aa1303e0 	mov	x0, x19
    5c34:	97fffdfb 	bl	5420 <fwp_tape_grow.constprop.0>
    5c38:	17ffff63 	b	59c4 <w120+0x1e4>
    5c3c:	aa1303e0 	mov	x0, x19
    5c40:	97fffdf8 	bl	5420 <fwp_tape_grow.constprop.0>
    5c44:	17ffff38 	b	5924 <w120+0x144>
    5c48:	1e6a382a 	fsub	d10, d1, d10
    5c4c:	b6f801c1 	tbz	x1, #63, 5c84 <w120+0x4a4>
    5c50:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c54:	1e6a0949 	fmul	d9, d10, d10
    5c58:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c5c:	9e670001 	fmov	d1, x0
    5c60:	1e683808 	fsub	d8, d0, d8
    5c64:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5c68:	aa1403e0 	mov	x0, x20
    5c6c:	1e610929 	fmul	d9, d9, d1
    5c70:	1e680908 	fmul	d8, d8, d8
    5c74:	17ffffd1 	b	5bb8 <w120+0x3d8>
    5c78:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    5c7c:	9135a000 	add	x0, x0, #0xd68
    5c80:	97fff9ad 	bl	4334 <fwp_trap>
    5c84:	2f00e409 	movi	d9, #0x0
    5c88:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5c8c:	9360fc3a 	asr	x26, x1, #32
    5c90:	aa0103f4 	mov	x20, x1
    5c94:	aa1a03e0 	mov	x0, x26
    5c98:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5c9c:	97fffba9 	bl	4b40 <fwp_tape_of>
    5ca0:	aa0003f3 	mov	x19, x0
    5ca4:	f9403000 	ldr	x0, [x0, #96]
    5ca8:	b5ffdc40 	cbnz	x0, 5830 <w120+0x50>
    5cac:	17ffff0c 	b	58dc <w120+0xfc>
    5cb0:	aa1a03f7 	mov	x23, x26
    5cb4:	aa0003f8 	mov	x24, x0
    5cb8:	17ffff51 	b	59fc <w120+0x21c>
    5cbc:	aa1803e0 	mov	x0, x24
    5cc0:	17ffffbe 	b	5bb8 <w120+0x3d8>

0000000000005cc4 <fwp_rc_share>:
    5cc4:	90000422 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    5cc8:	9118c042 	add	x2, x2, #0x630
    5ccc:	f949d843 	ldr	x3, [x2, #5040]
    5cd0:	f949ec41 	ldr	x1, [x2, #5080]
    5cd4:	cb030000 	sub	x0, x0, x3
    5cd8:	eb01401f 	cmp	x0, x1, lsl #16
    5cdc:	540003a2 	b.cs	5d50 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ce0:	d350fc01 	lsr	x1, x0, #16
    5ce4:	f949fc44 	ldr	x4, [x2, #5112]
    5ce8:	8b010821 	add	x1, x1, x1, lsl #2
    5cec:	d37df021 	lsl	x1, x1, #3
    5cf0:	8b010083 	add	x3, x4, x1
    5cf4:	f9401062 	ldr	x2, [x3, #32]
    5cf8:	b40002c2 	cbz	x2, 5d50 <fwp_rc_share+0x8c>
    5cfc:	38616881 	ldrb	w1, [x4, x1]
    5d00:	7100083f 	cmp	w1, #0x2
    5d04:	54000220 	b.eq	5d48 <fwp_rc_share+0x84>  // b.none
    5d08:	7100043f 	cmp	w1, #0x1
    5d0c:	54000221 	b.ne	5d50 <fwp_rc_share+0x8c>  // b.any
    5d10:	29430464 	ldp	w4, w1, [x3, #24]
    5d14:	92403c00 	and	x0, x0, #0xffff
    5d18:	9b047c00 	mul	x0, x0, x4
    5d1c:	d360fc00 	lsr	x0, x0, #32
    5d20:	eb01001f 	cmp	x0, x1
    5d24:	54000162 	b.cs	5d50 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5d28:	8b000042 	add	x2, x2, x0
    5d2c:	39400040 	ldrb	w0, [x2]
    5d30:	34000100 	cbz	w0, 5d50 <fwp_rc_share+0x8c>
    5d34:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5d38:	b0000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    5d3c:	91380000 	add	x0, x0, #0xe00
    5d40:	910003fd 	mov	x29, sp
    5d44:	97fff97c 	bl	4334 <fwp_trap>
    5d48:	72003c1f 	tst	w0, #0xffff
    5d4c:	54ffff00 	b.eq	5d2c <fwp_rc_share+0x68>  // b.none
    5d50:	d65f03c0 	ret

0000000000005d54 <fwp_rc_fresh>:
    5d54:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d58:	90000423 	adrp	x3, 89000 <fwp_root_context+0xbb0>
    5d5c:	9118c063 	add	x3, x3, #0x630
    5d60:	910003fd 	mov	x29, sp
    5d64:	a90153f3 	stp	x19, x20, [sp, #16]
    5d68:	aa0003f3 	mov	x19, x0
    5d6c:	f949d861 	ldr	x1, [x3, #5040]
    5d70:	f949ec60 	ldr	x0, [x3, #5080]
    5d74:	cb010261 	sub	x1, x19, x1
    5d78:	eb00403f 	cmp	x1, x0, lsl #16
    5d7c:	54000322 	b.cs	5de0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5d80:	d350fc22 	lsr	x2, x1, #16
    5d84:	f949fc63 	ldr	x3, [x3, #5112]
    5d88:	8b020842 	add	x2, x2, x2, lsl #2
    5d8c:	d37df042 	lsl	x2, x2, #3
    5d90:	8b020060 	add	x0, x3, x2
    5d94:	f9401014 	ldr	x20, [x0, #32]
    5d98:	b4000254 	cbz	x20, 5de0 <fwp_rc_fresh+0x8c>
    5d9c:	38626862 	ldrb	w2, [x3, x2]
    5da0:	7100085f 	cmp	w2, #0x2
    5da4:	54000260 	b.eq	5df0 <fwp_rc_fresh+0x9c>  // b.none
    5da8:	7100045f 	cmp	w2, #0x1
    5dac:	540001a1 	b.ne	5de0 <fwp_rc_fresh+0x8c>  // b.any
    5db0:	29430002 	ldp	w2, w0, [x0, #24]
    5db4:	92403c21 	and	x1, x1, #0xffff
    5db8:	9b027c21 	mul	x1, x1, x2
    5dbc:	d360fc21 	lsr	x1, x1, #32
    5dc0:	eb00003f 	cmp	x1, x0
    5dc4:	540000e2 	b.cs	5de0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5dc8:	8b010294 	add	x20, x20, x1
    5dcc:	39400280 	ldrb	w0, [x20]
    5dd0:	7103fc1f 	cmp	w0, #0xff
    5dd4:	540001a0 	b.eq	5e08 <fwp_rc_fresh+0xb4>  // b.none
    5dd8:	52800020 	mov	w0, #0x1                   	// #1
    5ddc:	39000280 	strb	w0, [x20]
    5de0:	aa1303e0 	mov	x0, x19
    5de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    5de8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5dec:	d65f03c0 	ret
    5df0:	72003c3f 	tst	w1, #0xffff
    5df4:	54fffec0 	b.eq	5dcc <fwp_rc_fresh+0x78>  // b.none
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e04:	d65f03c0 	ret
    5e08:	aa1403e0 	mov	x0, x20
    5e0c:	97fff96a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5e10:	17fffff2 	b	5dd8 <fwp_rc_fresh+0x84>

0000000000005e14 <fwp_rc_free_arr>:
    5e14:	90000423 	adrp	x3, 89000 <fwp_root_context+0xbb0>
    5e18:	9118c063 	add	x3, x3, #0x630
    5e1c:	f949d861 	ldr	x1, [x3, #5040]
    5e20:	f949ec62 	ldr	x2, [x3, #5080]
    5e24:	cb010001 	sub	x1, x0, x1
    5e28:	eb02403f 	cmp	x1, x2, lsl #16
    5e2c:	54000342 	b.cs	5e94 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5e30:	d350fc22 	lsr	x2, x1, #16
    5e34:	f949fc65 	ldr	x5, [x3, #5112]
    5e38:	8b020842 	add	x2, x2, x2, lsl #2
    5e3c:	d37df042 	lsl	x2, x2, #3
    5e40:	8b0200a4 	add	x4, x5, x2
    5e44:	f9401083 	ldr	x3, [x4, #32]
    5e48:	b4000263 	cbz	x3, 5e94 <fwp_rc_free_arr+0x80>
    5e4c:	386268a2 	ldrb	w2, [x5, x2]
    5e50:	7100085f 	cmp	w2, #0x2
    5e54:	540001c0 	b.eq	5e8c <fwp_rc_free_arr+0x78>  // b.none
    5e58:	7100045f 	cmp	w2, #0x1
    5e5c:	540001c1 	b.ne	5e94 <fwp_rc_free_arr+0x80>  // b.any
    5e60:	29430885 	ldp	w5, w2, [x4, #24]
    5e64:	92403c21 	and	x1, x1, #0xffff
    5e68:	9b057c21 	mul	x1, x1, x5
    5e6c:	d360fc21 	lsr	x1, x1, #32
    5e70:	eb02003f 	cmp	x1, x2
    5e74:	54000102 	b.cs	5e94 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5e78:	8b010063 	add	x3, x3, x1
    5e7c:	39400061 	ldrb	w1, [x3]
    5e80:	7100043f 	cmp	w1, #0x1
    5e84:	54000081 	b.ne	5e94 <fwp_rc_free_arr+0x80>  // b.any
    5e88:	17fff9e6 	b	4620 <fwp_mem_free>
    5e8c:	72003c3f 	tst	w1, #0xffff
    5e90:	54ffff60 	b.eq	5e7c <fwp_rc_free_arr+0x68>  // b.none
    5e94:	d65f03c0 	ret
    5e98:	d503201f 	nop
    5e9c:	d503201f 	nop

0000000000005ea0 <fwp_rc_dup>:
    5ea0:	90000422 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    5ea4:	9118c042 	add	x2, x2, #0x630
    5ea8:	f949d841 	ldr	x1, [x2, #5040]
    5eac:	f949ec43 	ldr	x3, [x2, #5080]
    5eb0:	cb010001 	sub	x1, x0, x1
    5eb4:	eb03403f 	cmp	x1, x3, lsl #16
    5eb8:	540003c2 	b.cs	5f30 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5ebc:	d350fc20 	lsr	x0, x1, #16
    5ec0:	f949fc44 	ldr	x4, [x2, #5112]
    5ec4:	8b000800 	add	x0, x0, x0, lsl #2
    5ec8:	d37df002 	lsl	x2, x0, #3
    5ecc:	8b020083 	add	x3, x4, x2
    5ed0:	f9401060 	ldr	x0, [x3, #32]
    5ed4:	b40002e0 	cbz	x0, 5f30 <fwp_rc_dup+0x90>
    5ed8:	38626882 	ldrb	w2, [x4, x2]
    5edc:	7100085f 	cmp	w2, #0x2
    5ee0:	540002a0 	b.eq	5f34 <fwp_rc_dup+0x94>  // b.none
    5ee4:	7100045f 	cmp	w2, #0x1
    5ee8:	54000241 	b.ne	5f30 <fwp_rc_dup+0x90>  // b.any
    5eec:	29430864 	ldp	w4, w2, [x3, #24]
    5ef0:	92403c21 	and	x1, x1, #0xffff
    5ef4:	9b047c21 	mul	x1, x1, x4
    5ef8:	d360fc21 	lsr	x1, x1, #32
    5efc:	eb02003f 	cmp	x1, x2
    5f00:	54000182 	b.cs	5f30 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f04:	8b010000 	add	x0, x0, x1
    5f08:	39400001 	ldrb	w1, [x0]
    5f0c:	34000121 	cbz	w1, 5f30 <fwp_rc_dup+0x90>
    5f10:	f0000142 	adrp	x2, 30000 <__data_start>
    5f14:	91014042 	add	x2, x2, #0x50
    5f18:	b9413043 	ldr	w3, [x2, #304]
    5f1c:	35000123 	cbnz	w3, 5f40 <fwp_rc_dup+0xa0>
    5f20:	7103f43f 	cmp	w1, #0xfd
    5f24:	54000168 	b.hi	5f50 <fwp_rc_dup+0xb0>  // b.pmore
    5f28:	11000421 	add	w1, w1, #0x1
    5f2c:	39000001 	strb	w1, [x0]
    5f30:	d65f03c0 	ret
    5f34:	72003c3f 	tst	w1, #0xffff
    5f38:	54fffe80 	b.eq	5f08 <fwp_rc_dup+0x68>  // b.none
    5f3c:	d65f03c0 	ret
    5f40:	f940ac43 	ldr	x3, [x2, #344]
    5f44:	91000463 	add	x3, x3, #0x1
    5f48:	f900ac43 	str	x3, [x2, #344]
    5f4c:	17fffff5 	b	5f20 <fwp_rc_dup+0x80>
    5f50:	17fffa2d 	b	4804 <fwp_rc_wide_dup>

0000000000005f54 <fwp_owned_entry173>:
    5f54:	d10103ff 	sub	sp, sp, #0x40
    5f58:	d0000142 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    5f5c:	f947f442 	ldr	x2, [x2, #4072]
    5f60:	a9027bfd 	stp	x29, x30, [sp, #32]
    5f64:	910083fd 	add	x29, sp, #0x20
    5f68:	a90353f3 	stp	x19, x20, [sp, #48]
    5f6c:	f9400043 	ldr	x3, [x2]
    5f70:	f9000fe3 	str	x3, [sp, #24]
    5f74:	d2800003 	mov	x3, #0x0                   	// #0
    5f78:	a9400c01 	ldp	x1, x3, [x0]
    5f7c:	f9400802 	ldr	x2, [x0, #16]
    5f80:	ab020022 	adds	x2, x1, x2
    5f84:	540006e6 	b.vs	6060 <fwp_owned_entry173+0x10c>
    5f88:	910023e1 	add	x1, sp, #0x8
    5f8c:	52800000 	mov	w0, #0x0                   	// #0
    5f90:	a9008be3 	stp	x3, x2, [sp, #8]
    5f94:	97fffcc3 	bl	52a0 <fwp_data.part.0.constprop.0>
    5f98:	90000423 	adrp	x3, 89000 <fwp_root_context+0xbb0>
    5f9c:	9118c063 	add	x3, x3, #0x630
    5fa0:	aa0003f3 	mov	x19, x0
    5fa4:	f949d861 	ldr	x1, [x3, #5040]
    5fa8:	f949ec60 	ldr	x0, [x3, #5080]
    5fac:	cb010261 	sub	x1, x19, x1
    5fb0:	eb00403f 	cmp	x1, x0, lsl #16
    5fb4:	54000322 	b.cs	6018 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5fb8:	d350fc22 	lsr	x2, x1, #16
    5fbc:	f949fc63 	ldr	x3, [x3, #5112]
    5fc0:	8b020842 	add	x2, x2, x2, lsl #2
    5fc4:	d37df042 	lsl	x2, x2, #3
    5fc8:	8b020060 	add	x0, x3, x2
    5fcc:	f9401014 	ldr	x20, [x0, #32]
    5fd0:	b4000254 	cbz	x20, 6018 <fwp_owned_entry173+0xc4>
    5fd4:	38626862 	ldrb	w2, [x3, x2]
    5fd8:	7100085f 	cmp	w2, #0x2
    5fdc:	54000360 	b.eq	6048 <fwp_owned_entry173+0xf4>  // b.none
    5fe0:	7100045f 	cmp	w2, #0x1
    5fe4:	540001a1 	b.ne	6018 <fwp_owned_entry173+0xc4>  // b.any
    5fe8:	29430002 	ldp	w2, w0, [x0, #24]
    5fec:	92403c21 	and	x1, x1, #0xffff
    5ff0:	9b027c21 	mul	x1, x1, x2
    5ff4:	d360fc21 	lsr	x1, x1, #32
    5ff8:	eb00003f 	cmp	x1, x0
    5ffc:	540000e2 	b.cs	6018 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    6000:	8b010294 	add	x20, x20, x1
    6004:	39400280 	ldrb	w0, [x20]
    6008:	7103fc1f 	cmp	w0, #0xff
    600c:	54000240 	b.eq	6054 <fwp_owned_entry173+0x100>  // b.none
    6010:	52800020 	mov	w0, #0x1                   	// #1
    6014:	39000280 	strb	w0, [x20]
    6018:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    601c:	f947f400 	ldr	x0, [x0, #4072]
    6020:	f9400fe2 	ldr	x2, [sp, #24]
    6024:	f9400001 	ldr	x1, [x0]
    6028:	eb010042 	subs	x2, x2, x1
    602c:	d2800001 	mov	x1, #0x0                   	// #0
    6030:	540001a1 	b.ne	6064 <fwp_owned_entry173+0x110>  // b.any
    6034:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6038:	aa1303e0 	mov	x0, x19
    603c:	a94353f3 	ldp	x19, x20, [sp, #48]
    6040:	910103ff 	add	sp, sp, #0x40
    6044:	d65f03c0 	ret
    6048:	72003c3f 	tst	w1, #0xffff
    604c:	54fffe61 	b.ne	6018 <fwp_owned_entry173+0xc4>  // b.any
    6050:	17ffffed 	b	6004 <fwp_owned_entry173+0xb0>
    6054:	aa1403e0 	mov	x0, x20
    6058:	97fff8d7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    605c:	17ffffed 	b	6010 <fwp_owned_entry173+0xbc>
    6060:	97fff288 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6064:	97fff20f 	bl	28a0 <__stack_chk_fail@plt>
    6068:	d503201f 	nop
    606c:	d503201f 	nop

0000000000006070 <e173>:
    6070:	d10103ff 	sub	sp, sp, #0x40
    6074:	b0000142 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    6078:	f947f442 	ldr	x2, [x2, #4072]
    607c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6080:	910083fd 	add	x29, sp, #0x20
    6084:	a90353f3 	stp	x19, x20, [sp, #48]
    6088:	f9400043 	ldr	x3, [x2]
    608c:	f9000fe3 	str	x3, [sp, #24]
    6090:	d2800003 	mov	x3, #0x0                   	// #0
    6094:	a9400c01 	ldp	x1, x3, [x0]
    6098:	f9400802 	ldr	x2, [x0, #16]
    609c:	ab020022 	adds	x2, x1, x2
    60a0:	54000726 	b.vs	6184 <e173+0x114>
    60a4:	910023e1 	add	x1, sp, #0x8
    60a8:	52800000 	mov	w0, #0x0                   	// #0
    60ac:	a9008be3 	stp	x3, x2, [sp, #8]
    60b0:	97fffc7c 	bl	52a0 <fwp_data.part.0.constprop.0>
    60b4:	f0000403 	adrp	x3, 89000 <fwp_root_context+0xbb0>
    60b8:	9118c063 	add	x3, x3, #0x630
    60bc:	aa0003f3 	mov	x19, x0
    60c0:	f949d861 	ldr	x1, [x3, #5040]
    60c4:	f949ec60 	ldr	x0, [x3, #5080]
    60c8:	cb010261 	sub	x1, x19, x1
    60cc:	eb00403f 	cmp	x1, x0, lsl #16
    60d0:	54000322 	b.cs	6134 <e173+0xc4>  // b.hs, b.nlast
    60d4:	d350fc22 	lsr	x2, x1, #16
    60d8:	f949fc63 	ldr	x3, [x3, #5112]
    60dc:	8b020842 	add	x2, x2, x2, lsl #2
    60e0:	d37df042 	lsl	x2, x2, #3
    60e4:	8b020060 	add	x0, x3, x2
    60e8:	f9401014 	ldr	x20, [x0, #32]
    60ec:	b4000254 	cbz	x20, 6134 <e173+0xc4>
    60f0:	38626862 	ldrb	w2, [x3, x2]
    60f4:	7100085f 	cmp	w2, #0x2
    60f8:	540003a0 	b.eq	616c <e173+0xfc>  // b.none
    60fc:	7100045f 	cmp	w2, #0x1
    6100:	540001a1 	b.ne	6134 <e173+0xc4>  // b.any
    6104:	29430002 	ldp	w2, w0, [x0, #24]
    6108:	92403c21 	and	x1, x1, #0xffff
    610c:	9b027c21 	mul	x1, x1, x2
    6110:	d360fc21 	lsr	x1, x1, #32
    6114:	eb00003f 	cmp	x1, x0
    6118:	540000e2 	b.cs	6134 <e173+0xc4>  // b.hs, b.nlast
    611c:	8b010294 	add	x20, x20, x1
    6120:	39400280 	ldrb	w0, [x20]
    6124:	7103fc1f 	cmp	w0, #0xff
    6128:	54000280 	b.eq	6178 <e173+0x108>  // b.none
    612c:	52800020 	mov	w0, #0x1                   	// #1
    6130:	39000280 	strb	w0, [x20]
    6134:	aa1303e0 	mov	x0, x19
    6138:	97fffee3 	bl	5cc4 <fwp_rc_share>
    613c:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    6140:	f947f400 	ldr	x0, [x0, #4072]
    6144:	f9400fe2 	ldr	x2, [sp, #24]
    6148:	f9400001 	ldr	x1, [x0]
    614c:	eb010042 	subs	x2, x2, x1
    6150:	d2800001 	mov	x1, #0x0                   	// #0
    6154:	540001a1 	b.ne	6188 <e173+0x118>  // b.any
    6158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    615c:	aa1303e0 	mov	x0, x19
    6160:	a94353f3 	ldp	x19, x20, [sp, #48]
    6164:	910103ff 	add	sp, sp, #0x40
    6168:	d65f03c0 	ret
    616c:	72003c3f 	tst	w1, #0xffff
    6170:	54fffe21 	b.ne	6134 <e173+0xc4>  // b.any
    6174:	17ffffeb 	b	6120 <e173+0xb0>
    6178:	aa1403e0 	mov	x0, x20
    617c:	97fff88e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6180:	17ffffeb 	b	612c <e173+0xbc>
    6184:	97fff23f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6188:	97fff1c6 	bl	28a0 <__stack_chk_fail@plt>
    618c:	d503201f 	nop

0000000000006190 <fwp_drop1>:
    6190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6194:	910003fd 	mov	x29, sp
    6198:	a90153f3 	stp	x19, x20, [sp, #16]
    619c:	f90013f5 	str	x21, [sp, #32]
    61a0:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    61a4:	9118c2b4 	add	x20, x21, #0x630
    61a8:	f949da81 	ldr	x1, [x20, #5040]
    61ac:	f949ee82 	ldr	x2, [x20, #5080]
    61b0:	cb010001 	sub	x1, x0, x1
    61b4:	eb02403f 	cmp	x1, x2, lsl #16
    61b8:	54000382 	b.cs	6228 <fwp_drop1+0x98>  // b.hs, b.nlast
    61bc:	d350fc22 	lsr	x2, x1, #16
    61c0:	f949fe84 	ldr	x4, [x20, #5112]
    61c4:	8b020842 	add	x2, x2, x2, lsl #2
    61c8:	d37df042 	lsl	x2, x2, #3
    61cc:	8b020083 	add	x3, x4, x2
    61d0:	f9401073 	ldr	x19, [x3, #32]
    61d4:	b40002b3 	cbz	x19, 6228 <fwp_drop1+0x98>
    61d8:	38626882 	ldrb	w2, [x4, x2]
    61dc:	7100085f 	cmp	w2, #0x2
    61e0:	540002c0 	b.eq	6238 <fwp_drop1+0xa8>  // b.none
    61e4:	7100045f 	cmp	w2, #0x1
    61e8:	54000201 	b.ne	6228 <fwp_drop1+0x98>  // b.any
    61ec:	29430864 	ldp	w4, w2, [x3, #24]
    61f0:	92403c21 	and	x1, x1, #0xffff
    61f4:	9b047c21 	mul	x1, x1, x4
    61f8:	d360fc21 	lsr	x1, x1, #32
    61fc:	eb02003f 	cmp	x1, x2
    6200:	54000142 	b.cs	6228 <fwp_drop1+0x98>  // b.hs, b.nlast
    6204:	8b010273 	add	x19, x19, x1
    6208:	39400261 	ldrb	w1, [x19]
    620c:	340000e1 	cbz	w1, 6228 <fwp_drop1+0x98>
    6210:	7100043f 	cmp	w1, #0x1
    6214:	540001e0 	b.eq	6250 <fwp_drop1+0xc0>  // b.none
    6218:	7103fc3f 	cmp	w1, #0xff
    621c:	540002e0 	b.eq	6278 <fwp_drop1+0xe8>  // b.none
    6220:	51000421 	sub	w1, w1, #0x1
    6224:	39000261 	strb	w1, [x19]
    6228:	a94153f3 	ldp	x19, x20, [sp, #16]
    622c:	f94013f5 	ldr	x21, [sp, #32]
    6230:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6234:	d65f03c0 	ret
    6238:	72003c3f 	tst	w1, #0xffff
    623c:	54fffe60 	b.eq	6208 <fwp_drop1+0x78>  // b.none
    6240:	a94153f3 	ldp	x19, x20, [sp, #16]
    6244:	f94013f5 	ldr	x21, [sp, #32]
    6248:	a8c37bfd 	ldp	x29, x30, [sp], #48
    624c:	d65f03c0 	ret
    6250:	f9400813 	ldr	x19, [x0, #16]
    6254:	97fffef0 	bl	5e14 <fwp_rc_free_arr>
    6258:	9118c2a0 	add	x0, x21, #0x630
    625c:	f949d801 	ldr	x1, [x0, #5040]
    6260:	f949ec00 	ldr	x0, [x0, #5080]
    6264:	cb010261 	sub	x1, x19, x1
    6268:	eb00403f 	cmp	x1, x0, lsl #16
    626c:	54fffde2 	b.cs	6228 <fwp_drop1+0x98>  // b.hs, b.nlast
    6270:	aa1303e0 	mov	x0, x19
    6274:	17ffffd2 	b	61bc <fwp_drop1+0x2c>
    6278:	ca534660 	eor	x0, x19, x19, lsr #17
    627c:	9118c2b5 	add	x21, x21, #0x630
    6280:	ca402400 	eor	x0, x0, x0, lsr #9
    6284:	92401c00 	and	x0, x0, #0xff
    6288:	910a2402 	add	x2, x0, #0x289
    628c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6290:	8b020ea2 	add	x2, x21, x2, lsl #3
    6294:	f94a2400 	ldr	x0, [x0, #5192]
    6298:	b50000a0 	cbnz	x0, 62ac <fwp_drop1+0x11c>
    629c:	14000013 	b	62e8 <fwp_drop1+0x158>
    62a0:	91004002 	add	x2, x0, #0x10
    62a4:	f9400800 	ldr	x0, [x0, #16]
    62a8:	b4000200 	cbz	x0, 62e8 <fwp_drop1+0x158>
    62ac:	f9400001 	ldr	x1, [x0]
    62b0:	eb13003f 	cmp	x1, x19
    62b4:	54ffff61 	b.ne	62a0 <fwp_drop1+0x110>  // b.any
    62b8:	f9400041 	ldr	x1, [x2]
    62bc:	f9400420 	ldr	x0, [x1, #8]
    62c0:	d1000400 	sub	x0, x0, #0x1
    62c4:	f9000420 	str	x0, [x1, #8]
    62c8:	f103f81f 	cmp	x0, #0xfe
    62cc:	54fffae1 	b.ne	6228 <fwp_drop1+0x98>  // b.any
    62d0:	39400260 	ldrb	w0, [x19]
    62d4:	7103fc1f 	cmp	w0, #0xff
    62d8:	540000e0 	b.eq	62f4 <fwp_drop1+0x164>  // b.none
    62dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62e0:	39000260 	strb	w0, [x19]
    62e4:	17ffffd1 	b	6228 <fwp_drop1+0x98>
    62e8:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    62ec:	912e6000 	add	x0, x0, #0xb98
    62f0:	97fff811 	bl	4334 <fwp_trap>
    62f4:	aa1303e0 	mov	x0, x19
    62f8:	97fff82f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    62fc:	17fffff8 	b	62dc <fwp_drop1+0x14c>

0000000000006300 <fwp_drop0>:
    6300:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6304:	910003fd 	mov	x29, sp
    6308:	a90153f3 	stp	x19, x20, [sp, #16]
    630c:	f90013f5 	str	x21, [sp, #32]
    6310:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    6314:	9118c2b4 	add	x20, x21, #0x630
    6318:	f949da81 	ldr	x1, [x20, #5040]
    631c:	f949ee82 	ldr	x2, [x20, #5080]
    6320:	cb010001 	sub	x1, x0, x1
    6324:	eb02403f 	cmp	x1, x2, lsl #16
    6328:	54000382 	b.cs	6398 <fwp_drop0+0x98>  // b.hs, b.nlast
    632c:	d350fc22 	lsr	x2, x1, #16
    6330:	f949fe84 	ldr	x4, [x20, #5112]
    6334:	8b020842 	add	x2, x2, x2, lsl #2
    6338:	d37df042 	lsl	x2, x2, #3
    633c:	8b020083 	add	x3, x4, x2
    6340:	f9401073 	ldr	x19, [x3, #32]
    6344:	b40002b3 	cbz	x19, 6398 <fwp_drop0+0x98>
    6348:	38626882 	ldrb	w2, [x4, x2]
    634c:	7100085f 	cmp	w2, #0x2
    6350:	540002c0 	b.eq	63a8 <fwp_drop0+0xa8>  // b.none
    6354:	7100045f 	cmp	w2, #0x1
    6358:	54000201 	b.ne	6398 <fwp_drop0+0x98>  // b.any
    635c:	29430864 	ldp	w4, w2, [x3, #24]
    6360:	92403c21 	and	x1, x1, #0xffff
    6364:	9b047c21 	mul	x1, x1, x4
    6368:	d360fc21 	lsr	x1, x1, #32
    636c:	eb02003f 	cmp	x1, x2
    6370:	54000142 	b.cs	6398 <fwp_drop0+0x98>  // b.hs, b.nlast
    6374:	8b010273 	add	x19, x19, x1
    6378:	39400261 	ldrb	w1, [x19]
    637c:	340000e1 	cbz	w1, 6398 <fwp_drop0+0x98>
    6380:	7100043f 	cmp	w1, #0x1
    6384:	540001e0 	b.eq	63c0 <fwp_drop0+0xc0>  // b.none
    6388:	7103fc3f 	cmp	w1, #0xff
    638c:	540002e0 	b.eq	63e8 <fwp_drop0+0xe8>  // b.none
    6390:	51000421 	sub	w1, w1, #0x1
    6394:	39000261 	strb	w1, [x19]
    6398:	a94153f3 	ldp	x19, x20, [sp, #16]
    639c:	f94013f5 	ldr	x21, [sp, #32]
    63a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63a4:	d65f03c0 	ret
    63a8:	72003c3f 	tst	w1, #0xffff
    63ac:	54fffe60 	b.eq	6378 <fwp_drop0+0x78>  // b.none
    63b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    63b4:	f94013f5 	ldr	x21, [sp, #32]
    63b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63bc:	d65f03c0 	ret
    63c0:	f9400813 	ldr	x19, [x0, #16]
    63c4:	97fffe94 	bl	5e14 <fwp_rc_free_arr>
    63c8:	9118c2a0 	add	x0, x21, #0x630
    63cc:	f949d801 	ldr	x1, [x0, #5040]
    63d0:	f949ec00 	ldr	x0, [x0, #5080]
    63d4:	cb010261 	sub	x1, x19, x1
    63d8:	eb00403f 	cmp	x1, x0, lsl #16
    63dc:	54fffde2 	b.cs	6398 <fwp_drop0+0x98>  // b.hs, b.nlast
    63e0:	aa1303e0 	mov	x0, x19
    63e4:	17ffffd2 	b	632c <fwp_drop0+0x2c>
    63e8:	ca534660 	eor	x0, x19, x19, lsr #17
    63ec:	9118c2b5 	add	x21, x21, #0x630
    63f0:	ca402400 	eor	x0, x0, x0, lsr #9
    63f4:	92401c00 	and	x0, x0, #0xff
    63f8:	910a2402 	add	x2, x0, #0x289
    63fc:	8b000ea0 	add	x0, x21, x0, lsl #3
    6400:	8b020ea2 	add	x2, x21, x2, lsl #3
    6404:	f94a2400 	ldr	x0, [x0, #5192]
    6408:	b50000a0 	cbnz	x0, 641c <fwp_drop0+0x11c>
    640c:	14000013 	b	6458 <fwp_drop0+0x158>
    6410:	91004002 	add	x2, x0, #0x10
    6414:	f9400800 	ldr	x0, [x0, #16]
    6418:	b4000200 	cbz	x0, 6458 <fwp_drop0+0x158>
    641c:	f9400001 	ldr	x1, [x0]
    6420:	eb13003f 	cmp	x1, x19
    6424:	54ffff61 	b.ne	6410 <fwp_drop0+0x110>  // b.any
    6428:	f9400041 	ldr	x1, [x2]
    642c:	f9400420 	ldr	x0, [x1, #8]
    6430:	d1000400 	sub	x0, x0, #0x1
    6434:	f9000420 	str	x0, [x1, #8]
    6438:	f103f81f 	cmp	x0, #0xfe
    643c:	54fffae1 	b.ne	6398 <fwp_drop0+0x98>  // b.any
    6440:	39400260 	ldrb	w0, [x19]
    6444:	7103fc1f 	cmp	w0, #0xff
    6448:	540000e0 	b.eq	6464 <fwp_drop0+0x164>  // b.none
    644c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6450:	39000260 	strb	w0, [x19]
    6454:	17ffffd1 	b	6398 <fwp_drop0+0x98>
    6458:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    645c:	912e6000 	add	x0, x0, #0xb98
    6460:	97fff7b5 	bl	4334 <fwp_trap>
    6464:	aa1303e0 	mov	x0, x19
    6468:	97fff7d3 	bl	43b4 <fwp_rc_forget_slot.part.0>
    646c:	17fffff8 	b	644c <fwp_drop0+0x14c>

0000000000006470 <fwp_closure_drop>:
    6470:	f0000405 	adrp	x5, 89000 <fwp_root_context+0xbb0>
    6474:	9118c0a4 	add	x4, x5, #0x630
    6478:	aa0003e1 	mov	x1, x0
    647c:	f949d882 	ldr	x2, [x4, #5040]
    6480:	f949ec80 	ldr	x0, [x4, #5080]
    6484:	cb020022 	sub	x2, x1, x2
    6488:	eb00405f 	cmp	x2, x0, lsl #16
    648c:	54000662 	b.cs	6558 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6490:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6494:	d350fc43 	lsr	x3, x2, #16
    6498:	910003fd 	mov	x29, sp
    649c:	8b030863 	add	x3, x3, x3, lsl #2
    64a0:	f949fc84 	ldr	x4, [x4, #5112]
    64a4:	d37df063 	lsl	x3, x3, #3
    64a8:	f9000bf3 	str	x19, [sp, #16]
    64ac:	8b030080 	add	x0, x4, x3
    64b0:	f9401013 	ldr	x19, [x0, #32]
    64b4:	b40002b3 	cbz	x19, 6508 <fwp_closure_drop+0x98>
    64b8:	38636883 	ldrb	w3, [x4, x3]
    64bc:	7100087f 	cmp	w3, #0x2
    64c0:	54000420 	b.eq	6544 <fwp_closure_drop+0xd4>  // b.none
    64c4:	7100047f 	cmp	w3, #0x1
    64c8:	54000201 	b.ne	6508 <fwp_closure_drop+0x98>  // b.any
    64cc:	29430003 	ldp	w3, w0, [x0, #24]
    64d0:	92403c42 	and	x2, x2, #0xffff
    64d4:	9b037c42 	mul	x2, x2, x3
    64d8:	d360fc42 	lsr	x2, x2, #32
    64dc:	eb00005f 	cmp	x2, x0
    64e0:	54000142 	b.cs	6508 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    64e4:	8b020273 	add	x19, x19, x2
    64e8:	39400260 	ldrb	w0, [x19]
    64ec:	340000e0 	cbz	w0, 6508 <fwp_closure_drop+0x98>
    64f0:	7100041f 	cmp	w0, #0x1
    64f4:	54000100 	b.eq	6514 <fwp_closure_drop+0xa4>  // b.none
    64f8:	7103fc1f 	cmp	w0, #0xff
    64fc:	54000300 	b.eq	655c <fwp_closure_drop+0xec>  // b.none
    6500:	51000400 	sub	w0, w0, #0x1
    6504:	39000260 	strb	w0, [x19]
    6508:	f9400bf3 	ldr	x19, [sp, #16]
    650c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6510:	d65f03c0 	ret
    6514:	d53bd040 	mrs	x0, tpidr_el0
    6518:	91400000 	add	x0, x0, #0x0, lsl #12
    651c:	91004000 	add	x0, x0, #0x10
    6520:	f9400000 	ldr	x0, [x0]
    6524:	b4000080 	cbz	x0, 6534 <fwp_closure_drop+0xc4>
    6528:	f9400bf3 	ldr	x19, [sp, #16]
    652c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6530:	17fff8fc 	b	4920 <fwp_closure_drop_push>
    6534:	f9400bf3 	ldr	x19, [sp, #16]
    6538:	aa0103e0 	mov	x0, x1
    653c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6540:	17fff93d 	b	4a34 <fwp_closure_drop.part.0>
    6544:	72003c5f 	tst	w2, #0xffff
    6548:	54fffd00 	b.eq	64e8 <fwp_closure_drop+0x78>  // b.none
    654c:	f9400bf3 	ldr	x19, [sp, #16]
    6550:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6554:	d65f03c0 	ret
    6558:	d65f03c0 	ret
    655c:	ca534660 	eor	x0, x19, x19, lsr #17
    6560:	9118c0a5 	add	x5, x5, #0x630
    6564:	ca402400 	eor	x0, x0, x0, lsr #9
    6568:	92401c00 	and	x0, x0, #0xff
    656c:	910a2402 	add	x2, x0, #0x289
    6570:	8b000ca0 	add	x0, x5, x0, lsl #3
    6574:	8b020ca2 	add	x2, x5, x2, lsl #3
    6578:	f94a2400 	ldr	x0, [x0, #5192]
    657c:	b50000a0 	cbnz	x0, 6590 <fwp_closure_drop+0x120>
    6580:	14000013 	b	65cc <fwp_closure_drop+0x15c>
    6584:	91004002 	add	x2, x0, #0x10
    6588:	f9400800 	ldr	x0, [x0, #16]
    658c:	b4000200 	cbz	x0, 65cc <fwp_closure_drop+0x15c>
    6590:	f9400001 	ldr	x1, [x0]
    6594:	eb13003f 	cmp	x1, x19
    6598:	54ffff61 	b.ne	6584 <fwp_closure_drop+0x114>  // b.any
    659c:	f9400041 	ldr	x1, [x2]
    65a0:	f9400420 	ldr	x0, [x1, #8]
    65a4:	d1000400 	sub	x0, x0, #0x1
    65a8:	f9000420 	str	x0, [x1, #8]
    65ac:	f103f81f 	cmp	x0, #0xfe
    65b0:	54fffac1 	b.ne	6508 <fwp_closure_drop+0x98>  // b.any
    65b4:	39400260 	ldrb	w0, [x19]
    65b8:	7103fc1f 	cmp	w0, #0xff
    65bc:	540000e0 	b.eq	65d8 <fwp_closure_drop+0x168>  // b.none
    65c0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65c4:	39000260 	strb	w0, [x19]
    65c8:	17ffffd0 	b	6508 <fwp_closure_drop+0x98>
    65cc:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    65d0:	912e6000 	add	x0, x0, #0xb98
    65d4:	97fff758 	bl	4334 <fwp_trap>
    65d8:	aa1303e0 	mov	x0, x19
    65dc:	97fff776 	bl	43b4 <fwp_rc_forget_slot.part.0>
    65e0:	17fffff8 	b	65c0 <fwp_closure_drop+0x150>

00000000000065e4 <fwp_owned_tape_release>:
    65e4:	b4000920 	cbz	x0, 6708 <fwp_owned_tape_release+0x124>
    65e8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65ec:	910003fd 	mov	x29, sp
    65f0:	a90153f3 	stp	x19, x20, [sp, #16]
    65f4:	aa0003f3 	mov	x19, x0
    65f8:	f9400000 	ldr	x0, [x0]
    65fc:	b4000060 	cbz	x0, 6608 <fwp_owned_tape_release+0x24>
    6600:	f9400661 	ldr	x1, [x19, #8]
    6604:	f9000401 	str	x1, [x0, #8]
    6608:	f9400661 	ldr	x1, [x19, #8]
    660c:	b4000041 	cbz	x1, 6614 <fwp_owned_tape_release+0x30>
    6610:	f9000020 	str	x0, [x1]
    6614:	f9400a60 	ldr	x0, [x19, #16]
    6618:	f9403401 	ldr	x1, [x0, #104]
    661c:	b40005a1 	cbz	x1, 66d0 <fwp_owned_tape_release+0xec>
    6620:	a9450a60 	ldp	x0, x2, [x19, #80]
    6624:	eb00005f 	cmp	x2, x0
    6628:	540002cd 	b.le	6680 <fwp_owned_tape_release+0x9c>
    662c:	d2800014 	mov	x20, #0x0                   	// #0
    6630:	f90013f5 	str	x21, [sp, #32]
    6634:	d2800015 	mov	x21, #0x0                   	// #0
    6638:	f9402260 	ldr	x0, [x19, #64]
    663c:	910006b5 	add	x21, x21, #0x1
    6640:	f8746800 	ldr	x0, [x0, x20]
    6644:	d63f0020 	blr	x1
    6648:	f9402260 	ldr	x0, [x19, #64]
    664c:	f9400a61 	ldr	x1, [x19, #16]
    6650:	8b140000 	add	x0, x0, x20
    6654:	91004294 	add	x20, x20, #0x10
    6658:	f9400400 	ldr	x0, [x0, #8]
    665c:	f9403421 	ldr	x1, [x1, #104]
    6660:	d63f0020 	blr	x1
    6664:	a9450261 	ldp	x1, x0, [x19, #80]
    6668:	cb010000 	sub	x0, x0, x1
    666c:	eb15001f 	cmp	x0, x21
    6670:	f9400a60 	ldr	x0, [x19, #16]
    6674:	f9403401 	ldr	x1, [x0, #104]
    6678:	54fffe0c 	b.gt	6638 <fwp_owned_tape_release+0x54>
    667c:	f94013f5 	ldr	x21, [sp, #32]
    6680:	f9403663 	ldr	x3, [x19, #104]
    6684:	f9401262 	ldr	x2, [x19, #32]
    6688:	f100007f 	cmp	x3, #0x0
    668c:	540001ed 	b.le	66c8 <fwp_owned_tape_release+0xe4>
    6690:	d2800014 	mov	x20, #0x0                   	// #0
    6694:	d503201f 	nop
    6698:	f9402660 	ldr	x0, [x19, #72]
    669c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    66a0:	eb02001f 	cmp	x0, x2
    66a4:	540000c0 	b.eq	66bc <fwp_owned_tape_release+0xd8>  // b.none
    66a8:	d63f0020 	blr	x1
    66ac:	f9400a60 	ldr	x0, [x19, #16]
    66b0:	f9401262 	ldr	x2, [x19, #32]
    66b4:	f9403663 	ldr	x3, [x19, #104]
    66b8:	f9403401 	ldr	x1, [x0, #104]
    66bc:	91000694 	add	x20, x20, #0x1
    66c0:	eb14007f 	cmp	x3, x20
    66c4:	54fffeac 	b.gt	6698 <fwp_owned_tape_release+0xb4>
    66c8:	aa0203e0 	mov	x0, x2
    66cc:	d63f0020 	blr	x1
    66d0:	f9401660 	ldr	x0, [x19, #40]
    66d4:	97ffff67 	bl	6470 <fwp_closure_drop>
    66d8:	f9401a60 	ldr	x0, [x19, #48]
    66dc:	97ffff65 	bl	6470 <fwp_closure_drop>
    66e0:	f9401e60 	ldr	x0, [x19, #56]
    66e4:	97ffff63 	bl	6470 <fwp_closure_drop>
    66e8:	f9402260 	ldr	x0, [x19, #64]
    66ec:	97fff7cd 	bl	4620 <fwp_mem_free>
    66f0:	f9402660 	ldr	x0, [x19, #72]
    66f4:	97fff7cb 	bl	4620 <fwp_mem_free>
    66f8:	aa1303e0 	mov	x0, x19
    66fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6700:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6704:	17fff7c7 	b	4620 <fwp_mem_free>
    6708:	d65f03c0 	ret
    670c:	d503201f 	nop

0000000000006710 <fwp_tape_finish>:
    6710:	d10203ff 	sub	sp, sp, #0x80
    6714:	b0000141 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    6718:	f947f421 	ldr	x1, [x1, #4072]
    671c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6720:	910103fd 	add	x29, sp, #0x40
    6724:	a9065bf5 	stp	x21, x22, [sp, #96]
    6728:	a90763f7 	stp	x23, x24, [sp, #112]
    672c:	d0000157 	adrp	x23, 30000 <__data_start>
    6730:	910142f6 	add	x22, x23, #0x50
    6734:	f9400022 	ldr	x2, [x1]
    6738:	f9001fe2 	str	x2, [sp, #56]
    673c:	d2800002 	mov	x2, #0x0                   	// #0
    6740:	910342c0 	add	x0, x22, #0xd0
    6744:	97fff64c 	bl	4074 <fwp_tape_buffers_dispose>
    6748:	f90086df 	str	xzr, [x22, #264]
    674c:	f94092c0 	ldr	x0, [x22, #288]
    6750:	f100001f 	cmp	x0, #0x0
    6754:	5400034d 	b.le	67bc <fwp_tape_finish+0xac>
    6758:	910003f8 	mov	x24, sp
    675c:	d2800015 	mov	x21, #0x0                   	// #0
    6760:	a90553f3 	stp	x19, x20, [sp, #80]
    6764:	d2800014 	mov	x20, #0x0                   	// #0
    6768:	91000694 	add	x20, x20, #0x1
    676c:	f94046d3 	ldr	x19, [x22, #136]
    6770:	8b150273 	add	x19, x19, x21
    6774:	9101a2b5 	add	x21, x21, #0x68
    6778:	aa1303e0 	mov	x0, x19
    677c:	97fff226 	bl	3014 <fwp_tape_unlink_scope>
    6780:	aa1803e0 	mov	x0, x24
    6784:	a9440663 	ldp	x3, x1, [x19, #64]
    6788:	f9001be1 	str	x1, [sp, #48]
    678c:	f9400e62 	ldr	x2, [x19, #24]
    6790:	a9020be3 	stp	x3, x2, [sp, #32]
    6794:	ad410261 	ldp	q1, q0, [x19, #32]
    6798:	ad0003e1 	stp	q1, q0, [sp]
    679c:	97fff636 	bl	4074 <fwp_tape_buffers_dispose>
    67a0:	f9403260 	ldr	x0, [x19, #96]
    67a4:	97ffff90 	bl	65e4 <fwp_owned_tape_release>
    67a8:	f900327f 	str	xzr, [x19, #96]
    67ac:	f94092c0 	ldr	x0, [x22, #288]
    67b0:	eb14001f 	cmp	x0, x20
    67b4:	54fffdac 	b.gt	6768 <fwp_tape_finish+0x58>
    67b8:	a94553f3 	ldp	x19, x20, [sp, #80]
    67bc:	910142e0 	add	x0, x23, #0x50
    67c0:	f9404400 	ldr	x0, [x0, #136]
    67c4:	b4000040 	cbz	x0, 67cc <fwp_tape_finish+0xbc>
    67c8:	97fff60a 	bl	3ff0 <ad_raw_free.part.0>
    67cc:	910142f7 	add	x23, x23, #0x50
    67d0:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    67d4:	f947f400 	ldr	x0, [x0, #4072]
    67d8:	f90046ff 	str	xzr, [x23, #136]
    67dc:	f9008aff 	str	xzr, [x23, #272]
    67e0:	f90092ff 	str	xzr, [x23, #288]
    67e4:	f900b2ff 	str	xzr, [x23, #352]
    67e8:	f9401fe2 	ldr	x2, [sp, #56]
    67ec:	f9400001 	ldr	x1, [x0]
    67f0:	eb010042 	subs	x2, x2, x1
    67f4:	d2800001 	mov	x1, #0x0                   	// #0
    67f8:	540000c1 	b.ne	6810 <fwp_tape_finish+0x100>  // b.any
    67fc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6800:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6804:	a94763f7 	ldp	x23, x24, [sp, #112]
    6808:	910203ff 	add	sp, sp, #0x80
    680c:	d65f03c0 	ret
    6810:	a90553f3 	stp	x19, x20, [sp, #80]
    6814:	97fff023 	bl	28a0 <__stack_chk_fail@plt>
    6818:	d503201f 	nop
    681c:	d503201f 	nop

0000000000006820 <fwp_tape_scope_release>:
    6820:	d10243ff 	sub	sp, sp, #0x90
    6824:	a9047bfd 	stp	x29, x30, [sp, #64]
    6828:	910103fd 	add	x29, sp, #0x40
    682c:	a90553f3 	stp	x19, x20, [sp, #80]
    6830:	aa0003f4 	mov	x20, x0
    6834:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    6838:	f947f400 	ldr	x0, [x0, #4072]
    683c:	b9400285 	ldr	w5, [x20]
    6840:	f9400001 	ldr	x1, [x0]
    6844:	f9001fe1 	str	x1, [sp, #56]
    6848:	d2800001 	mov	x1, #0x0                   	// #0
    684c:	37f806c5 	tbnz	w5, #31, 6924 <fwp_tape_scope_release+0x104>
    6850:	a90763f7 	stp	x23, x24, [sp, #112]
    6854:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6858:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    685c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6860:	d0000153 	adrp	x19, 30000 <__data_start>
    6864:	910003f7 	mov	x23, sp
    6868:	91014273 	add	x19, x19, #0x50
    686c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6870:	a9065bf5 	stp	x21, x22, [sp, #96]
    6874:	52800d16 	mov	w22, #0x68                  	// #104
    6878:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    687c:	f90043f9 	str	x25, [sp, #128]
    6880:	14000006 	b	6898 <fwp_tape_scope_release+0x78>
    6884:	97fff5fc 	bl	4074 <fwp_tape_buffers_dispose>
    6888:	aa1903e0 	mov	x0, x25
    688c:	97ffff56 	bl	65e4 <fwp_owned_tape_release>
    6890:	b9400285 	ldr	w5, [x20]
    6894:	37f80425 	tbnz	w5, #31, 6918 <fwp_tape_scope_release+0xf8>
    6898:	f9404666 	ldr	x6, [x19, #136]
    689c:	9b367ca5 	smull	x5, w5, w22
    68a0:	8b0500c0 	add	x0, x6, x5
    68a4:	97fff1dc 	bl	3014 <fwp_tape_unlink_scope>
    68a8:	ad410001 	ldp	q1, q0, [x0, #32]
    68ac:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    68b0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    68b4:	f9400c03 	ldr	x3, [x0, #24]
    68b8:	ad0003e1 	stp	q1, q0, [sp]
    68bc:	b86568c1 	ldr	w1, [x6, x5]
    68c0:	a9440804 	ldp	x4, x2, [x0, #64]
    68c4:	b900041f 	str	wzr, [x0, #4]
    68c8:	f9403019 	ldr	x25, [x0, #96]
    68cc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    68d0:	f9000c1f 	str	xzr, [x0, #24]
    68d4:	a9020fe4 	stp	x4, x3, [sp, #32]
    68d8:	f9001be2 	str	x2, [sp, #48]
    68dc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    68e0:	f900301f 	str	xzr, [x0, #96]
    68e4:	6b15003f 	cmp	w1, w21
    68e8:	540000e8 	b.hi	6904 <fwp_tape_scope_release+0xe4>  // b.pmore
    68ec:	9343fca5 	asr	x5, x5, #3
    68f0:	f940b260 	ldr	x0, [x19, #352]
    68f4:	9b187ca5 	mul	x5, x5, x24
    68f8:	eb0000bf 	cmp	x5, x0
    68fc:	5400004a 	b.ge	6904 <fwp_tape_scope_release+0xe4>  // b.tcont
    6900:	f900b265 	str	x5, [x19, #352]
    6904:	aa1703e0 	mov	x0, x23
    6908:	b5fffbf9 	cbnz	x25, 6884 <fwp_tape_scope_release+0x64>
    690c:	97fff622 	bl	4194 <fwp_tape_buffers_release>
    6910:	b9400285 	ldr	w5, [x20]
    6914:	36fffc25 	tbz	w5, #31, 6898 <fwp_tape_scope_release+0x78>
    6918:	a9465bf5 	ldp	x21, x22, [sp, #96]
    691c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6920:	f94043f9 	ldr	x25, [sp, #128]
    6924:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    6928:	f947f400 	ldr	x0, [x0, #4072]
    692c:	f9401fe2 	ldr	x2, [sp, #56]
    6930:	f9400001 	ldr	x1, [x0]
    6934:	eb010042 	subs	x2, x2, x1
    6938:	d2800001 	mov	x1, #0x0                   	// #0
    693c:	540000a1 	b.ne	6950 <fwp_tape_scope_release+0x130>  // b.any
    6940:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6944:	a94553f3 	ldp	x19, x20, [sp, #80]
    6948:	910243ff 	add	sp, sp, #0x90
    694c:	d65f03c0 	ret
    6950:	a9065bf5 	stp	x21, x22, [sp, #96]
    6954:	a90763f7 	stp	x23, x24, [sp, #112]
    6958:	f90043f9 	str	x25, [sp, #128]
    695c:	97ffefd1 	bl	28a0 <__stack_chk_fail@plt>

0000000000006960 <fwp_drop4>:
    6960:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6964:	910003fd 	mov	x29, sp
    6968:	a9025bf5 	stp	x21, x22, [sp, #32]
    696c:	f0000416 	adrp	x22, 89000 <fwp_root_context+0xbb0>
    6970:	9118c2d5 	add	x21, x22, #0x630
    6974:	a90153f3 	stp	x19, x20, [sp, #16]
    6978:	aa0003f3 	mov	x19, x0
    697c:	f949daa1 	ldr	x1, [x21, #5040]
    6980:	f949eea0 	ldr	x0, [x21, #5080]
    6984:	cb010261 	sub	x1, x19, x1
    6988:	eb00403f 	cmp	x1, x0, lsl #16
    698c:	54000382 	b.cs	69fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6990:	d350fc22 	lsr	x2, x1, #16
    6994:	f949fea3 	ldr	x3, [x21, #5112]
    6998:	8b020842 	add	x2, x2, x2, lsl #2
    699c:	d37df042 	lsl	x2, x2, #3
    69a0:	8b020060 	add	x0, x3, x2
    69a4:	f9401014 	ldr	x20, [x0, #32]
    69a8:	b40002b4 	cbz	x20, 69fc <fwp_drop4+0x9c>
    69ac:	38626862 	ldrb	w2, [x3, x2]
    69b0:	7100085f 	cmp	w2, #0x2
    69b4:	540002c0 	b.eq	6a0c <fwp_drop4+0xac>  // b.none
    69b8:	7100045f 	cmp	w2, #0x1
    69bc:	54000201 	b.ne	69fc <fwp_drop4+0x9c>  // b.any
    69c0:	29430002 	ldp	w2, w0, [x0, #24]
    69c4:	92403c21 	and	x1, x1, #0xffff
    69c8:	9b027c21 	mul	x1, x1, x2
    69cc:	d360fc21 	lsr	x1, x1, #32
    69d0:	eb00003f 	cmp	x1, x0
    69d4:	54000142 	b.cs	69fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    69d8:	8b010294 	add	x20, x20, x1
    69dc:	39400280 	ldrb	w0, [x20]
    69e0:	340000e0 	cbz	w0, 69fc <fwp_drop4+0x9c>
    69e4:	7100041f 	cmp	w0, #0x1
    69e8:	540001e0 	b.eq	6a24 <fwp_drop4+0xc4>  // b.none
    69ec:	7103fc1f 	cmp	w0, #0xff
    69f0:	540007c0 	b.eq	6ae8 <fwp_drop4+0x188>  // b.none
    69f4:	51000400 	sub	w0, w0, #0x1
    69f8:	39000280 	strb	w0, [x20]
    69fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a08:	d65f03c0 	ret
    6a0c:	72003c3f 	tst	w1, #0xffff
    6a10:	54fffe60 	b.eq	69dc <fwp_drop4+0x7c>  // b.none
    6a14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a20:	d65f03c0 	ret
    6a24:	9118c2c2 	add	x2, x22, #0x630
    6a28:	f9400660 	ldr	x0, [x19, #8]
    6a2c:	f949d841 	ldr	x1, [x2, #5040]
    6a30:	f949ec42 	ldr	x2, [x2, #5080]
    6a34:	cb010001 	sub	x1, x0, x1
    6a38:	eb02403f 	cmp	x1, x2, lsl #16
    6a3c:	54000362 	b.cs	6aa8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6a40:	d350fc22 	lsr	x2, x1, #16
    6a44:	8b020842 	add	x2, x2, x2, lsl #2
    6a48:	d37df042 	lsl	x2, x2, #3
    6a4c:	8b020064 	add	x4, x3, x2
    6a50:	f9401094 	ldr	x20, [x4, #32]
    6a54:	b40002b4 	cbz	x20, 6aa8 <fwp_drop4+0x148>
    6a58:	38626862 	ldrb	w2, [x3, x2]
    6a5c:	7100085f 	cmp	w2, #0x2
    6a60:	540003e0 	b.eq	6adc <fwp_drop4+0x17c>  // b.none
    6a64:	7100045f 	cmp	w2, #0x1
    6a68:	54000201 	b.ne	6aa8 <fwp_drop4+0x148>  // b.any
    6a6c:	29430883 	ldp	w3, w2, [x4, #24]
    6a70:	92403c21 	and	x1, x1, #0xffff
    6a74:	9b037c21 	mul	x1, x1, x3
    6a78:	d360fc21 	lsr	x1, x1, #32
    6a7c:	eb02003f 	cmp	x1, x2
    6a80:	54000142 	b.cs	6aa8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6a84:	8b010294 	add	x20, x20, x1
    6a88:	39400281 	ldrb	w1, [x20]
    6a8c:	340000e1 	cbz	w1, 6aa8 <fwp_drop4+0x148>
    6a90:	7100043f 	cmp	w1, #0x1
    6a94:	54000200 	b.eq	6ad4 <fwp_drop4+0x174>  // b.none
    6a98:	7103fc3f 	cmp	w1, #0xff
    6a9c:	54000640 	b.eq	6b64 <fwp_drop4+0x204>  // b.none
    6aa0:	51000421 	sub	w1, w1, #0x1
    6aa4:	39000281 	strb	w1, [x20]
    6aa8:	f9400a74 	ldr	x20, [x19, #16]
    6aac:	aa1303e0 	mov	x0, x19
    6ab0:	97fffcd9 	bl	5e14 <fwp_rc_free_arr>
    6ab4:	9118c2c0 	add	x0, x22, #0x630
    6ab8:	f949d801 	ldr	x1, [x0, #5040]
    6abc:	f949ec00 	ldr	x0, [x0, #5080]
    6ac0:	cb010281 	sub	x1, x20, x1
    6ac4:	eb00403f 	cmp	x1, x0, lsl #16
    6ac8:	54fff9a2 	b.cs	69fc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6acc:	aa1403f3 	mov	x19, x20
    6ad0:	17ffffb0 	b	6990 <fwp_drop4+0x30>
    6ad4:	97fffcd0 	bl	5e14 <fwp_rc_free_arr>
    6ad8:	17fffff4 	b	6aa8 <fwp_drop4+0x148>
    6adc:	72003c3f 	tst	w1, #0xffff
    6ae0:	54fffe41 	b.ne	6aa8 <fwp_drop4+0x148>  // b.any
    6ae4:	17ffffe9 	b	6a88 <fwp_drop4+0x128>
    6ae8:	ca544681 	eor	x1, x20, x20, lsr #17
    6aec:	9118c2c0 	add	x0, x22, #0x630
    6af0:	ca412421 	eor	x1, x1, x1, lsr #9
    6af4:	92401c21 	and	x1, x1, #0xff
    6af8:	910a2422 	add	x2, x1, #0x289
    6afc:	8b010c01 	add	x1, x0, x1, lsl #3
    6b00:	8b020c02 	add	x2, x0, x2, lsl #3
    6b04:	f94a2420 	ldr	x0, [x1, #5192]
    6b08:	b50000a0 	cbnz	x0, 6b1c <fwp_drop4+0x1bc>
    6b0c:	14000013 	b	6b58 <fwp_drop4+0x1f8>
    6b10:	91004002 	add	x2, x0, #0x10
    6b14:	f9400800 	ldr	x0, [x0, #16]
    6b18:	b4000200 	cbz	x0, 6b58 <fwp_drop4+0x1f8>
    6b1c:	f9400001 	ldr	x1, [x0]
    6b20:	eb14003f 	cmp	x1, x20
    6b24:	54ffff61 	b.ne	6b10 <fwp_drop4+0x1b0>  // b.any
    6b28:	f9400041 	ldr	x1, [x2]
    6b2c:	f9400420 	ldr	x0, [x1, #8]
    6b30:	d1000400 	sub	x0, x0, #0x1
    6b34:	f9000420 	str	x0, [x1, #8]
    6b38:	f103f81f 	cmp	x0, #0xfe
    6b3c:	54fff601 	b.ne	69fc <fwp_drop4+0x9c>  // b.any
    6b40:	39400280 	ldrb	w0, [x20]
    6b44:	7103fc1f 	cmp	w0, #0xff
    6b48:	54000460 	b.eq	6bd4 <fwp_drop4+0x274>  // b.none
    6b4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b50:	39000280 	strb	w0, [x20]
    6b54:	17ffffaa 	b	69fc <fwp_drop4+0x9c>
    6b58:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    6b5c:	912e6000 	add	x0, x0, #0xb98
    6b60:	97fff5f5 	bl	4334 <fwp_trap>
    6b64:	ca544680 	eor	x0, x20, x20, lsr #17
    6b68:	9118c2c1 	add	x1, x22, #0x630
    6b6c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b70:	92401c00 	and	x0, x0, #0xff
    6b74:	910a2402 	add	x2, x0, #0x289
    6b78:	8b000c20 	add	x0, x1, x0, lsl #3
    6b7c:	8b020c22 	add	x2, x1, x2, lsl #3
    6b80:	f94a2400 	ldr	x0, [x0, #5192]
    6b84:	b50000a0 	cbnz	x0, 6b98 <fwp_drop4+0x238>
    6b88:	17fffff4 	b	6b58 <fwp_drop4+0x1f8>
    6b8c:	91004002 	add	x2, x0, #0x10
    6b90:	f9400800 	ldr	x0, [x0, #16]
    6b94:	b4fffe20 	cbz	x0, 6b58 <fwp_drop4+0x1f8>
    6b98:	f9400001 	ldr	x1, [x0]
    6b9c:	eb14003f 	cmp	x1, x20
    6ba0:	54ffff61 	b.ne	6b8c <fwp_drop4+0x22c>  // b.any
    6ba4:	f9400041 	ldr	x1, [x2]
    6ba8:	f9400420 	ldr	x0, [x1, #8]
    6bac:	d1000400 	sub	x0, x0, #0x1
    6bb0:	f9000420 	str	x0, [x1, #8]
    6bb4:	f103f81f 	cmp	x0, #0xfe
    6bb8:	54fff781 	b.ne	6aa8 <fwp_drop4+0x148>  // b.any
    6bbc:	39400280 	ldrb	w0, [x20]
    6bc0:	7103fc1f 	cmp	w0, #0xff
    6bc4:	540000e0 	b.eq	6be0 <fwp_drop4+0x280>  // b.none
    6bc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bcc:	39000280 	strb	w0, [x20]
    6bd0:	17ffffb6 	b	6aa8 <fwp_drop4+0x148>
    6bd4:	aa1403e0 	mov	x0, x20
    6bd8:	97fff5f7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6bdc:	17ffffdc 	b	6b4c <fwp_drop4+0x1ec>
    6be0:	aa1403e0 	mov	x0, x20
    6be4:	97fff5f4 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6be8:	17fffff8 	b	6bc8 <fwp_drop4+0x268>
    6bec:	d503201f 	nop

0000000000006bf0 <fwp_arg_drop37>:
    6bf0:	7100003f 	cmp	w1, #0x0
    6bf4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bf8:	54000041 	b.ne	6c00 <fwp_arg_drop37+0x10>  // b.any
    6bfc:	d65f03c0 	ret
    6c00:	f9400000 	ldr	x0, [x0]
    6c04:	17ffff57 	b	6960 <fwp_drop4>
    6c08:	d503201f 	nop
    6c0c:	d503201f 	nop

0000000000006c10 <fwp_task_dispose>:
    6c10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c14:	910003fd 	mov	x29, sp
    6c18:	f9000bf3 	str	x19, [sp, #16]
    6c1c:	aa0003f3 	mov	x19, x0
    6c20:	39414000 	ldrb	w0, [x0, #80]
    6c24:	36000720 	tbz	w0, #0, 6d08 <fwp_task_dispose+0xf8>
    6c28:	f9400a60 	ldr	x0, [x19, #16]
    6c2c:	b50006e0 	cbnz	x0, 6d08 <fwp_task_dispose+0xf8>
    6c30:	a9478660 	ldp	x0, x1, [x19, #120]
    6c34:	39014e7f 	strb	wzr, [x19, #83]
    6c38:	f9003e7f 	str	xzr, [x19, #120]
    6c3c:	f100003f 	cmp	x1, #0x0
    6c40:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6c44:	54000040 	b.eq	6c4c <fwp_task_dispose+0x3c>  // b.none
    6c48:	d63f0020 	blr	x1
    6c4c:	f9405660 	ldr	x0, [x19, #168]
    6c50:	97fff674 	bl	4620 <fwp_mem_free>
    6c54:	f900567f 	str	xzr, [x19, #168]
    6c58:	b9405e60 	ldr	w0, [x19, #92]
    6c5c:	7100041f 	cmp	w0, #0x1
    6c60:	54000420 	b.eq	6ce4 <fwp_task_dispose+0xd4>  // b.none
    6c64:	f0000402 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    6c68:	9118c042 	add	x2, x2, #0x630
    6c6c:	f949d840 	ldr	x0, [x2, #5040]
    6c70:	f949ec41 	ldr	x1, [x2, #5080]
    6c74:	cb000260 	sub	x0, x19, x0
    6c78:	eb01401f 	cmp	x0, x1, lsl #16
    6c7c:	540002e2 	b.cs	6cd8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6c80:	d350fc01 	lsr	x1, x0, #16
    6c84:	f949fc44 	ldr	x4, [x2, #5112]
    6c88:	8b010821 	add	x1, x1, x1, lsl #2
    6c8c:	d37df021 	lsl	x1, x1, #3
    6c90:	8b010083 	add	x3, x4, x1
    6c94:	f9401062 	ldr	x2, [x3, #32]
    6c98:	b4000202 	cbz	x2, 6cd8 <fwp_task_dispose+0xc8>
    6c9c:	38616881 	ldrb	w1, [x4, x1]
    6ca0:	7100083f 	cmp	w1, #0x2
    6ca4:	54000280 	b.eq	6cf4 <fwp_task_dispose+0xe4>  // b.none
    6ca8:	7100043f 	cmp	w1, #0x1
    6cac:	54000161 	b.ne	6cd8 <fwp_task_dispose+0xc8>  // b.any
    6cb0:	29430464 	ldp	w4, w1, [x3, #24]
    6cb4:	92403c00 	and	x0, x0, #0xffff
    6cb8:	9b047c00 	mul	x0, x0, x4
    6cbc:	d360fc00 	lsr	x0, x0, #32
    6cc0:	eb01001f 	cmp	x0, x1
    6cc4:	540000a2 	b.cs	6cd8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6cc8:	8b000042 	add	x2, x2, x0
    6ccc:	39400040 	ldrb	w0, [x2]
    6cd0:	7100041f 	cmp	w0, #0x1
    6cd4:	54000080 	b.eq	6ce4 <fwp_task_dispose+0xd4>  // b.none
    6cd8:	f9400bf3 	ldr	x19, [sp, #16]
    6cdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ce0:	d65f03c0 	ret
    6ce4:	aa1303e0 	mov	x0, x19
    6ce8:	f9400bf3 	ldr	x19, [sp, #16]
    6cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cf0:	17fff64c 	b	4620 <fwp_mem_free>
    6cf4:	72003c1f 	tst	w0, #0xffff
    6cf8:	54fffea0 	b.eq	6ccc <fwp_task_dispose+0xbc>  // b.none
    6cfc:	f9400bf3 	ldr	x19, [sp, #16]
    6d00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d04:	d65f03c0 	ret
    6d08:	97ffeefa 	bl	28f0 <abort@plt>
    6d0c:	d503201f 	nop

0000000000006d10 <fwp_free_zombie>:
    6d10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d14:	910003fd 	mov	x29, sp
    6d18:	a90153f3 	stp	x19, x20, [sp, #16]
    6d1c:	d0000154 	adrp	x20, 30000 <__data_start>
    6d20:	91014281 	add	x1, x20, #0x50
    6d24:	f940b433 	ldr	x19, [x1, #360]
    6d28:	b4000333 	cbz	x19, 6d8c <fwp_free_zombie+0x7c>
    6d2c:	f9404c20 	ldr	x0, [x1, #152]
    6d30:	eb00027f 	cmp	x19, x0
    6d34:	540002c0 	b.eq	6d8c <fwp_free_zombie+0x7c>  // b.none
    6d38:	b9417022 	ldr	w2, [x1, #368]
    6d3c:	f9400a60 	ldr	x0, [x19, #16]
    6d40:	7100fc5f 	cmp	w2, #0x3f
    6d44:	5400078c 	b.gt	6e34 <fwp_free_zombie+0x124>
    6d48:	91060023 	add	x3, x1, #0x180
    6d4c:	11000444 	add	w4, w2, #0x1
    6d50:	b9017024 	str	w4, [x1, #368]
    6d54:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6d58:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6d5c:	a9530261 	ldp	x1, x0, [x19, #304]
    6d60:	b4000741 	cbz	x1, 6e48 <fwp_free_zombie+0x138>
    6d64:	f9009c20 	str	x0, [x1, #312]
    6d68:	b4000040 	cbz	x0, 6d70 <fwp_free_zombie+0x60>
    6d6c:	f9009801 	str	x1, [x0, #304]
    6d70:	91014294 	add	x20, x20, #0x50
    6d74:	b9405e60 	ldr	w0, [x19, #92]
    6d78:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6d7c:	f900b69f 	str	xzr, [x20, #360]
    6d80:	34000140 	cbz	w0, 6da8 <fwp_free_zombie+0x98>
    6d84:	7100041f 	cmp	w0, #0x1
    6d88:	54000080 	b.eq	6d98 <fwp_free_zombie+0x88>  // b.none
    6d8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d94:	d65f03c0 	ret
    6d98:	aa1303e0 	mov	x0, x19
    6d9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6da0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6da4:	17ffff9b 	b	6c10 <fwp_task_dispose>
    6da8:	f0000404 	adrp	x4, 89000 <fwp_root_context+0xbb0>
    6dac:	9118c082 	add	x2, x4, #0x630
    6db0:	f949d841 	ldr	x1, [x2, #5040]
    6db4:	f949ec40 	ldr	x0, [x2, #5080]
    6db8:	cb010261 	sub	x1, x19, x1
    6dbc:	eb00403f 	cmp	x1, x0, lsl #16
    6dc0:	54fffe62 	b.cs	6d8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6dc4:	d350fc20 	lsr	x0, x1, #16
    6dc8:	f949fc43 	ldr	x3, [x2, #5112]
    6dcc:	8b000800 	add	x0, x0, x0, lsl #2
    6dd0:	d37df000 	lsl	x0, x0, #3
    6dd4:	8b000062 	add	x2, x3, x0
    6dd8:	f9401054 	ldr	x20, [x2, #32]
    6ddc:	b4fffd94 	cbz	x20, 6d8c <fwp_free_zombie+0x7c>
    6de0:	38606860 	ldrb	w0, [x3, x0]
    6de4:	7100081f 	cmp	w0, #0x2
    6de8:	54000360 	b.eq	6e54 <fwp_free_zombie+0x144>  // b.none
    6dec:	7100041f 	cmp	w0, #0x1
    6df0:	54fffce1 	b.ne	6d8c <fwp_free_zombie+0x7c>  // b.any
    6df4:	29430043 	ldp	w3, w0, [x2, #24]
    6df8:	92403c21 	and	x1, x1, #0xffff
    6dfc:	9b037c21 	mul	x1, x1, x3
    6e00:	d360fc21 	lsr	x1, x1, #32
    6e04:	eb00003f 	cmp	x1, x0
    6e08:	54fffc22 	b.cs	6d8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6e0c:	8b010294 	add	x20, x20, x1
    6e10:	39400280 	ldrb	w0, [x20]
    6e14:	34fffbc0 	cbz	w0, 6d8c <fwp_free_zombie+0x7c>
    6e18:	7100041f 	cmp	w0, #0x1
    6e1c:	54fffbe0 	b.eq	6d98 <fwp_free_zombie+0x88>  // b.none
    6e20:	7103fc1f 	cmp	w0, #0xff
    6e24:	540001e0 	b.eq	6e60 <fwp_free_zombie+0x150>  // b.none
    6e28:	51000400 	sub	w0, w0, #0x1
    6e2c:	39000280 	strb	w0, [x20]
    6e30:	17ffffd7 	b	6d8c <fwp_free_zombie+0x7c>
    6e34:	f9400e61 	ldr	x1, [x19, #24]
    6e38:	97ffeee2 	bl	29c0 <munmap@plt>
    6e3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6e40:	a9530261 	ldp	x1, x0, [x19, #304]
    6e44:	b5fff901 	cbnz	x1, 6d64 <fwp_free_zombie+0x54>
    6e48:	91014282 	add	x2, x20, #0x50
    6e4c:	f901c040 	str	x0, [x2, #896]
    6e50:	17ffffc6 	b	6d68 <fwp_free_zombie+0x58>
    6e54:	72003c3f 	tst	w1, #0xffff
    6e58:	54fff9a1 	b.ne	6d8c <fwp_free_zombie+0x7c>  // b.any
    6e5c:	17ffffed 	b	6e10 <fwp_free_zombie+0x100>
    6e60:	ca544680 	eor	x0, x20, x20, lsr #17
    6e64:	9118c084 	add	x4, x4, #0x630
    6e68:	ca402400 	eor	x0, x0, x0, lsr #9
    6e6c:	92401c00 	and	x0, x0, #0xff
    6e70:	910a2402 	add	x2, x0, #0x289
    6e74:	8b000c80 	add	x0, x4, x0, lsl #3
    6e78:	8b020c82 	add	x2, x4, x2, lsl #3
    6e7c:	f94a2400 	ldr	x0, [x0, #5192]
    6e80:	b50000a0 	cbnz	x0, 6e94 <fwp_free_zombie+0x184>
    6e84:	14000013 	b	6ed0 <fwp_free_zombie+0x1c0>
    6e88:	91004002 	add	x2, x0, #0x10
    6e8c:	f9400800 	ldr	x0, [x0, #16]
    6e90:	b4000200 	cbz	x0, 6ed0 <fwp_free_zombie+0x1c0>
    6e94:	f9400001 	ldr	x1, [x0]
    6e98:	eb14003f 	cmp	x1, x20
    6e9c:	54ffff61 	b.ne	6e88 <fwp_free_zombie+0x178>  // b.any
    6ea0:	f9400041 	ldr	x1, [x2]
    6ea4:	f9400420 	ldr	x0, [x1, #8]
    6ea8:	d1000400 	sub	x0, x0, #0x1
    6eac:	f9000420 	str	x0, [x1, #8]
    6eb0:	f103f81f 	cmp	x0, #0xfe
    6eb4:	54fff6c1 	b.ne	6d8c <fwp_free_zombie+0x7c>  // b.any
    6eb8:	39400280 	ldrb	w0, [x20]
    6ebc:	7103fc1f 	cmp	w0, #0xff
    6ec0:	540000e0 	b.eq	6edc <fwp_free_zombie+0x1cc>  // b.none
    6ec4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ec8:	39000280 	strb	w0, [x20]
    6ecc:	17ffffb0 	b	6d8c <fwp_free_zombie+0x7c>
    6ed0:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    6ed4:	912e6000 	add	x0, x0, #0xb98
    6ed8:	97fff517 	bl	4334 <fwp_trap>
    6edc:	aa1403e0 	mov	x0, x20
    6ee0:	97fff535 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6ee4:	17fffff8 	b	6ec4 <fwp_free_zombie+0x1b4>
    6ee8:	d503201f 	nop
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_block>:
    6ef0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6ef4:	910003fd 	mov	x29, sp
    6ef8:	a90153f3 	stp	x19, x20, [sp, #16]
    6efc:	d0000153 	adrp	x19, 30000 <__data_start>
    6f00:	91014274 	add	x20, x19, #0x50
    6f04:	f9406682 	ldr	x2, [x20, #200]
    6f08:	b4000642 	cbz	x2, 6fd0 <fwp_block+0xe0>
    6f0c:	91014261 	add	x1, x19, #0x50
    6f10:	f9408040 	ldr	x0, [x2, #256]
    6f14:	f9006420 	str	x0, [x1, #200]
    6f18:	b40006a0 	cbz	x0, 6fec <fwp_block+0xfc>
    6f1c:	d503201f 	nop
    6f20:	91014263 	add	x3, x19, #0x50
    6f24:	3901505f 	strb	wzr, [x2, #84]
    6f28:	f9404c64 	ldr	x4, [x3, #152]
    6f2c:	eb02009f 	cmp	x4, x2
    6f30:	54000440 	b.eq	6fb8 <fwp_block+0xc8>  // b.none
    6f34:	f941c465 	ldr	x5, [x3, #904]
    6f38:	f9004c62 	str	x2, [x3, #152]
    6f3c:	f9400441 	ldr	x1, [x2, #8]
    6f40:	f9004885 	str	x5, [x4, #144]
    6f44:	f941c865 	ldr	x5, [x3, #912]
    6f48:	f9004c85 	str	x5, [x4, #152]
    6f4c:	f941cc65 	ldr	x5, [x3, #920]
    6f50:	f9005085 	str	x5, [x4, #160]
    6f54:	f941d065 	ldr	x5, [x3, #928]
    6f58:	f9005485 	str	x5, [x4, #168]
    6f5c:	f941d465 	ldr	x5, [x3, #936]
    6f60:	f9005885 	str	x5, [x4, #176]
    6f64:	f941d865 	ldr	x5, [x3, #944]
    6f68:	f9005c85 	str	x5, [x4, #184]
    6f6c:	f941dc65 	ldr	x5, [x3, #952]
    6f70:	f9006085 	str	x5, [x4, #192]
    6f74:	f9400480 	ldr	x0, [x4, #8]
    6f78:	f9404844 	ldr	x4, [x2, #144]
    6f7c:	f901c464 	str	x4, [x3, #904]
    6f80:	f9404c44 	ldr	x4, [x2, #152]
    6f84:	f901c864 	str	x4, [x3, #912]
    6f88:	f9405044 	ldr	x4, [x2, #160]
    6f8c:	f901cc64 	str	x4, [x3, #920]
    6f90:	f9405444 	ldr	x4, [x2, #168]
    6f94:	f901d064 	str	x4, [x3, #928]
    6f98:	f9405844 	ldr	x4, [x2, #176]
    6f9c:	f901d464 	str	x4, [x3, #936]
    6fa0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6fa4:	f901d864 	str	x4, [x3, #944]
    6fa8:	f901dc62 	str	x2, [x3, #952]
    6fac:	97ffee55 	bl	2900 <swapcontext@plt>
    6fb0:	97ffff58 	bl	6d10 <fwp_free_zombie>
    6fb4:	d503201f 	nop
    6fb8:	91014260 	add	x0, x19, #0x50
    6fbc:	b943c000 	ldr	w0, [x0, #960]
    6fc0:	340001a0 	cbz	w0, 6ff4 <fwp_block+0x104>
    6fc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fc8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fcc:	d65f03c0 	ret
    6fd0:	97fff720 	bl	4c50 <fwp_poll_events>
    6fd4:	f9406682 	ldr	x2, [x20, #200]
    6fd8:	b4ffffc2 	cbz	x2, 6fd0 <fwp_block+0xe0>
    6fdc:	91014261 	add	x1, x19, #0x50
    6fe0:	f9408040 	ldr	x0, [x2, #256]
    6fe4:	f9006420 	str	x0, [x1, #200]
    6fe8:	b5fff9c0 	cbnz	x0, 6f20 <fwp_block+0x30>
    6fec:	f900603f 	str	xzr, [x1, #192]
    6ff0:	17ffffcc 	b	6f20 <fwp_block+0x30>
    6ff4:	90000040 	adrp	x0, e000 <fwp_main_thread+0x1470>
    6ff8:	9138c000 	add	x0, x0, #0xe30
    6ffc:	97ffee8d 	bl	2a30 <getenv@plt>
    7000:	5284e202 	mov	w2, #0x2710                	// #10000
    7004:	b4000060 	cbz	x0, 7010 <fwp_block+0x120>
    7008:	39400001 	ldrb	w1, [x0]
    700c:	350000c1 	cbnz	w1, 7024 <fwp_block+0x134>
    7010:	91014273 	add	x19, x19, #0x50
    7014:	b903c262 	str	w2, [x19, #960]
    7018:	a94153f3 	ldp	x19, x20, [sp, #16]
    701c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7020:	d65f03c0 	ret
    7024:	52800142 	mov	w2, #0xa                   	// #10
    7028:	d2800001 	mov	x1, #0x0                   	// #0
    702c:	97ffedd1 	bl	2770 <strtoll@plt>
    7030:	d1000403 	sub	x3, x0, #0x1
    7034:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    7038:	eb02007f 	cmp	x3, x2
    703c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    7040:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    7044:	17fffff3 	b	7010 <fwp_block+0x120>
    7048:	d503201f 	nop
    704c:	d503201f 	nop

0000000000007050 <fwp_drop10>:
    7050:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7054:	910003fd 	mov	x29, sp
    7058:	a90153f3 	stp	x19, x20, [sp, #16]
    705c:	d0000413 	adrp	x19, 89000 <fwp_root_context+0xbb0>
    7060:	f90013f5 	str	x21, [sp, #32]
    7064:	9118c275 	add	x21, x19, #0x630
    7068:	f949daa1 	ldr	x1, [x21, #5040]
    706c:	f949eea2 	ldr	x2, [x21, #5080]
    7070:	cb010001 	sub	x1, x0, x1
    7074:	eb02403f 	cmp	x1, x2, lsl #16
    7078:	54000382 	b.cs	70e8 <fwp_drop10+0x98>  // b.hs, b.nlast
    707c:	d350fc22 	lsr	x2, x1, #16
    7080:	f949fea3 	ldr	x3, [x21, #5112]
    7084:	8b020842 	add	x2, x2, x2, lsl #2
    7088:	d37df042 	lsl	x2, x2, #3
    708c:	8b020064 	add	x4, x3, x2
    7090:	f9401094 	ldr	x20, [x4, #32]
    7094:	b40002b4 	cbz	x20, 70e8 <fwp_drop10+0x98>
    7098:	38626862 	ldrb	w2, [x3, x2]
    709c:	7100085f 	cmp	w2, #0x2
    70a0:	540007a0 	b.eq	7194 <fwp_drop10+0x144>  // b.none
    70a4:	7100045f 	cmp	w2, #0x1
    70a8:	54000201 	b.ne	70e8 <fwp_drop10+0x98>  // b.any
    70ac:	29430885 	ldp	w5, w2, [x4, #24]
    70b0:	92403c21 	and	x1, x1, #0xffff
    70b4:	9b057c21 	mul	x1, x1, x5
    70b8:	d360fc21 	lsr	x1, x1, #32
    70bc:	eb02003f 	cmp	x1, x2
    70c0:	54000142 	b.cs	70e8 <fwp_drop10+0x98>  // b.hs, b.nlast
    70c4:	8b010294 	add	x20, x20, x1
    70c8:	39400281 	ldrb	w1, [x20]
    70cc:	340000e1 	cbz	w1, 70e8 <fwp_drop10+0x98>
    70d0:	7100043f 	cmp	w1, #0x1
    70d4:	54000120 	b.eq	70f8 <fwp_drop10+0xa8>  // b.none
    70d8:	7103fc3f 	cmp	w1, #0xff
    70dc:	540007c0 	b.eq	71d4 <fwp_drop10+0x184>  // b.none
    70e0:	51000421 	sub	w1, w1, #0x1
    70e4:	39000281 	strb	w1, [x20]
    70e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    70ec:	f94013f5 	ldr	x21, [sp, #32]
    70f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70f4:	d65f03c0 	ret
    70f8:	f9400001 	ldr	x1, [x0]
    70fc:	b7f80581 	tbnz	x1, #63, 71ac <fwp_drop10+0x15c>
    7100:	9118c273 	add	x19, x19, #0x630
    7104:	f949da61 	ldr	x1, [x19, #5040]
    7108:	f949ee62 	ldr	x2, [x19, #5080]
    710c:	cb010001 	sub	x1, x0, x1
    7110:	eb02403f 	cmp	x1, x2, lsl #16
    7114:	54fffea2 	b.cs	70e8 <fwp_drop10+0x98>  // b.hs, b.nlast
    7118:	d350fc22 	lsr	x2, x1, #16
    711c:	8b020842 	add	x2, x2, x2, lsl #2
    7120:	d37df042 	lsl	x2, x2, #3
    7124:	8b020065 	add	x5, x3, x2
    7128:	f94010a4 	ldr	x4, [x5, #32]
    712c:	b4fffde4 	cbz	x4, 70e8 <fwp_drop10+0x98>
    7130:	38626862 	ldrb	w2, [x3, x2]
    7134:	7100085f 	cmp	w2, #0x2
    7138:	54000220 	b.eq	717c <fwp_drop10+0x12c>  // b.none
    713c:	7100045f 	cmp	w2, #0x1
    7140:	54fffd41 	b.ne	70e8 <fwp_drop10+0x98>  // b.any
    7144:	294308a3 	ldp	w3, w2, [x5, #24]
    7148:	92403c21 	and	x1, x1, #0xffff
    714c:	9b037c21 	mul	x1, x1, x3
    7150:	d360fc21 	lsr	x1, x1, #32
    7154:	eb02003f 	cmp	x1, x2
    7158:	54fffc82 	b.cs	70e8 <fwp_drop10+0x98>  // b.hs, b.nlast
    715c:	8b010084 	add	x4, x4, x1
    7160:	39400081 	ldrb	w1, [x4]
    7164:	7100043f 	cmp	w1, #0x1
    7168:	54fffc01 	b.ne	70e8 <fwp_drop10+0x98>  // b.any
    716c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7170:	f94013f5 	ldr	x21, [sp, #32]
    7174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7178:	17fff52a 	b	4620 <fwp_mem_free>
    717c:	72003c3f 	tst	w1, #0xffff
    7180:	54ffff00 	b.eq	7160 <fwp_drop10+0x110>  // b.none
    7184:	a94153f3 	ldp	x19, x20, [sp, #16]
    7188:	f94013f5 	ldr	x21, [sp, #32]
    718c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7190:	d65f03c0 	ret
    7194:	72003c3f 	tst	w1, #0xffff
    7198:	54fff980 	b.eq	70c8 <fwp_drop10+0x78>  // b.none
    719c:	a94153f3 	ldp	x19, x20, [sp, #16]
    71a0:	f94013f5 	ldr	x21, [sp, #32]
    71a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    71a8:	d65f03c0 	ret
    71ac:	f9400414 	ldr	x20, [x0, #8]
    71b0:	97fffb19 	bl	5e14 <fwp_rc_free_arr>
    71b4:	9118c260 	add	x0, x19, #0x630
    71b8:	f949d801 	ldr	x1, [x0, #5040]
    71bc:	f949ec00 	ldr	x0, [x0, #5080]
    71c0:	cb010281 	sub	x1, x20, x1
    71c4:	eb00403f 	cmp	x1, x0, lsl #16
    71c8:	54fff902 	b.cs	70e8 <fwp_drop10+0x98>  // b.hs, b.nlast
    71cc:	aa1403e0 	mov	x0, x20
    71d0:	17ffffab 	b	707c <fwp_drop10+0x2c>
    71d4:	ca544680 	eor	x0, x20, x20, lsr #17
    71d8:	9118c273 	add	x19, x19, #0x630
    71dc:	ca402400 	eor	x0, x0, x0, lsr #9
    71e0:	92401c00 	and	x0, x0, #0xff
    71e4:	910a2402 	add	x2, x0, #0x289
    71e8:	8b000e60 	add	x0, x19, x0, lsl #3
    71ec:	8b020e62 	add	x2, x19, x2, lsl #3
    71f0:	f94a2400 	ldr	x0, [x0, #5192]
    71f4:	b50000a0 	cbnz	x0, 7208 <fwp_drop10+0x1b8>
    71f8:	14000013 	b	7244 <fwp_drop10+0x1f4>
    71fc:	91004002 	add	x2, x0, #0x10
    7200:	f9400800 	ldr	x0, [x0, #16]
    7204:	b4000200 	cbz	x0, 7244 <fwp_drop10+0x1f4>
    7208:	f9400001 	ldr	x1, [x0]
    720c:	eb14003f 	cmp	x1, x20
    7210:	54ffff61 	b.ne	71fc <fwp_drop10+0x1ac>  // b.any
    7214:	f9400041 	ldr	x1, [x2]
    7218:	f9400420 	ldr	x0, [x1, #8]
    721c:	d1000400 	sub	x0, x0, #0x1
    7220:	f9000420 	str	x0, [x1, #8]
    7224:	f103f81f 	cmp	x0, #0xfe
    7228:	54fff601 	b.ne	70e8 <fwp_drop10+0x98>  // b.any
    722c:	39400280 	ldrb	w0, [x20]
    7230:	7103fc1f 	cmp	w0, #0xff
    7234:	540000e0 	b.eq	7250 <fwp_drop10+0x200>  // b.none
    7238:	12800020 	mov	w0, #0xfffffffe            	// #-2
    723c:	39000280 	strb	w0, [x20]
    7240:	17ffffaa 	b	70e8 <fwp_drop10+0x98>
    7244:	f0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    7248:	912e6000 	add	x0, x0, #0xb98
    724c:	97fff43a 	bl	4334 <fwp_trap>
    7250:	aa1403e0 	mov	x0, x20
    7254:	97fff458 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7258:	17fffff8 	b	7238 <fwp_drop10+0x1e8>
    725c:	d503201f 	nop

0000000000007260 <fwp_caps173>:
    7260:	34000041 	cbz	w1, 7268 <fwp_caps173+0x8>
    7264:	d65f03c0 	ret
    7268:	d0000403 	adrp	x3, 89000 <fwp_root_context+0xbb0>
    726c:	9118c063 	add	x3, x3, #0x630
    7270:	f949d861 	ldr	x1, [x3, #5040]
    7274:	f949ec62 	ldr	x2, [x3, #5080]
    7278:	cb010001 	sub	x1, x0, x1
    727c:	eb02403f 	cmp	x1, x2, lsl #16
    7280:	54ffff22 	b.cs	7264 <fwp_caps173+0x4>  // b.hs, b.nlast
    7284:	d350fc22 	lsr	x2, x1, #16
    7288:	f949fc65 	ldr	x5, [x3, #5112]
    728c:	8b020842 	add	x2, x2, x2, lsl #2
    7290:	d37df042 	lsl	x2, x2, #3
    7294:	8b0200a4 	add	x4, x5, x2
    7298:	f9401083 	ldr	x3, [x4, #32]
    729c:	b4fffe43 	cbz	x3, 7264 <fwp_caps173+0x4>
    72a0:	386268a2 	ldrb	w2, [x5, x2]
    72a4:	7100085f 	cmp	w2, #0x2
    72a8:	540001c0 	b.eq	72e0 <fwp_caps173+0x80>  // b.none
    72ac:	7100045f 	cmp	w2, #0x1
    72b0:	54fffda1 	b.ne	7264 <fwp_caps173+0x4>  // b.any
    72b4:	29430885 	ldp	w5, w2, [x4, #24]
    72b8:	92403c21 	and	x1, x1, #0xffff
    72bc:	9b057c21 	mul	x1, x1, x5
    72c0:	d360fc21 	lsr	x1, x1, #32
    72c4:	eb02003f 	cmp	x1, x2
    72c8:	54fffce2 	b.cs	7264 <fwp_caps173+0x4>  // b.hs, b.nlast
    72cc:	8b010063 	add	x3, x3, x1
    72d0:	39400061 	ldrb	w1, [x3]
    72d4:	7100043f 	cmp	w1, #0x1
    72d8:	54fffc61 	b.ne	7264 <fwp_caps173+0x4>  // b.any
    72dc:	17fff4d1 	b	4620 <fwp_mem_free>
    72e0:	72003c3f 	tst	w1, #0xffff
    72e4:	54ffff60 	b.eq	72d0 <fwp_caps173+0x70>  // b.none
    72e8:	d65f03c0 	ret
    72ec:	d503201f 	nop

00000000000072f0 <fwp_args37>:
    72f0:	7100003f 	cmp	w1, #0x0
    72f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    72f8:	54000041 	b.ne	7300 <fwp_args37+0x10>  // b.any
    72fc:	d65f03c0 	ret
    7300:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    7304:	9118c042 	add	x2, x2, #0x630
    7308:	f9400001 	ldr	x1, [x0]
    730c:	f949d843 	ldr	x3, [x2, #5040]
    7310:	f949ec40 	ldr	x0, [x2, #5080]
    7314:	cb030021 	sub	x1, x1, x3
    7318:	eb00403f 	cmp	x1, x0, lsl #16
    731c:	54ffff02 	b.cs	72fc <fwp_args37+0xc>  // b.hs, b.nlast
    7320:	d350fc20 	lsr	x0, x1, #16
    7324:	f949fc44 	ldr	x4, [x2, #5112]
    7328:	8b000800 	add	x0, x0, x0, lsl #2
    732c:	d37df002 	lsl	x2, x0, #3
    7330:	8b020083 	add	x3, x4, x2
    7334:	f9401060 	ldr	x0, [x3, #32]
    7338:	b4fffe20 	cbz	x0, 72fc <fwp_args37+0xc>
    733c:	38626882 	ldrb	w2, [x4, x2]
    7340:	7100085f 	cmp	w2, #0x2
    7344:	54000320 	b.eq	73a8 <fwp_args37+0xb8>  // b.none
    7348:	7100045f 	cmp	w2, #0x1
    734c:	54fffd81 	b.ne	72fc <fwp_args37+0xc>  // b.any
    7350:	29430864 	ldp	w4, w2, [x3, #24]
    7354:	92403c21 	and	x1, x1, #0xffff
    7358:	9b047c21 	mul	x1, x1, x4
    735c:	d360fc21 	lsr	x1, x1, #32
    7360:	eb02003f 	cmp	x1, x2
    7364:	54fffcc2 	b.cs	72fc <fwp_args37+0xc>  // b.hs, b.nlast
    7368:	8b010000 	add	x0, x0, x1
    736c:	39400001 	ldrb	w1, [x0]
    7370:	34fffc61 	cbz	w1, 72fc <fwp_args37+0xc>
    7374:	b0000142 	adrp	x2, 30000 <__data_start>
    7378:	91014042 	add	x2, x2, #0x50
    737c:	b9413043 	ldr	w3, [x2, #304]
    7380:	350000c3 	cbnz	w3, 7398 <fwp_args37+0xa8>
    7384:	7103f43f 	cmp	w1, #0xfd
    7388:	54000168 	b.hi	73b4 <fwp_args37+0xc4>  // b.pmore
    738c:	11000421 	add	w1, w1, #0x1
    7390:	39000001 	strb	w1, [x0]
    7394:	d65f03c0 	ret
    7398:	f940ac43 	ldr	x3, [x2, #344]
    739c:	91000463 	add	x3, x3, #0x1
    73a0:	f900ac43 	str	x3, [x2, #344]
    73a4:	17fffff8 	b	7384 <fwp_args37+0x94>
    73a8:	72003c3f 	tst	w1, #0xffff
    73ac:	54fffe00 	b.eq	736c <fwp_args37+0x7c>  // b.none
    73b0:	d65f03c0 	ret
    73b4:	17fff514 	b	4804 <fwp_rc_wide_dup>
    73b8:	d503201f 	nop
    73bc:	d503201f 	nop

00000000000073c0 <fwp_caps37>:
    73c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    73c4:	910003fd 	mov	x29, sp
    73c8:	f9000bf3 	str	x19, [sp, #16]
    73cc:	aa0003f3 	mov	x19, x0
    73d0:	b9400400 	ldr	w0, [x0, #4]
    73d4:	340004a0 	cbz	w0, 7468 <fwp_caps37+0xa8>
    73d8:	f9400660 	ldr	x0, [x19, #8]
    73dc:	350004e1 	cbnz	w1, 7478 <fwp_caps37+0xb8>
    73e0:	97fffd60 	bl	6960 <fwp_drop4>
    73e4:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    73e8:	9118c042 	add	x2, x2, #0x630
    73ec:	f949d840 	ldr	x0, [x2, #5040]
    73f0:	f949ec41 	ldr	x1, [x2, #5080]
    73f4:	cb000260 	sub	x0, x19, x0
    73f8:	eb01401f 	cmp	x0, x1, lsl #16
    73fc:	54000382 	b.cs	746c <fwp_caps37+0xac>  // b.hs, b.nlast
    7400:	d350fc01 	lsr	x1, x0, #16
    7404:	f949fc44 	ldr	x4, [x2, #5112]
    7408:	8b010821 	add	x1, x1, x1, lsl #2
    740c:	d37df021 	lsl	x1, x1, #3
    7410:	8b010083 	add	x3, x4, x1
    7414:	f9401062 	ldr	x2, [x3, #32]
    7418:	b40002a2 	cbz	x2, 746c <fwp_caps37+0xac>
    741c:	38616881 	ldrb	w1, [x4, x1]
    7420:	7100083f 	cmp	w1, #0x2
    7424:	54000740 	b.eq	750c <fwp_caps37+0x14c>  // b.none
    7428:	7100043f 	cmp	w1, #0x1
    742c:	54000201 	b.ne	746c <fwp_caps37+0xac>  // b.any
    7430:	29430464 	ldp	w4, w1, [x3, #24]
    7434:	92403c00 	and	x0, x0, #0xffff
    7438:	9b047c00 	mul	x0, x0, x4
    743c:	d360fc00 	lsr	x0, x0, #32
    7440:	eb01001f 	cmp	x0, x1
    7444:	54000142 	b.cs	746c <fwp_caps37+0xac>  // b.hs, b.nlast
    7448:	8b000042 	add	x2, x2, x0
    744c:	39400040 	ldrb	w0, [x2]
    7450:	7100041f 	cmp	w0, #0x1
    7454:	540000c1 	b.ne	746c <fwp_caps37+0xac>  // b.any
    7458:	aa1303e0 	mov	x0, x19
    745c:	f9400bf3 	ldr	x19, [sp, #16]
    7460:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7464:	17fff46f 	b	4620 <fwp_mem_free>
    7468:	34fffbe1 	cbz	w1, 73e4 <fwp_caps37+0x24>
    746c:	f9400bf3 	ldr	x19, [sp, #16]
    7470:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7474:	d65f03c0 	ret
    7478:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xbb0>
    747c:	9118c042 	add	x2, x2, #0x630
    7480:	f949d843 	ldr	x3, [x2, #5040]
    7484:	f949ec41 	ldr	x1, [x2, #5080]
    7488:	cb030000 	sub	x0, x0, x3
    748c:	eb01401f 	cmp	x0, x1, lsl #16
    7490:	54fffee2 	b.cs	746c <fwp_caps37+0xac>  // b.hs, b.nlast
    7494:	d350fc01 	lsr	x1, x0, #16
    7498:	f949fc44 	ldr	x4, [x2, #5112]
    749c:	8b010821 	add	x1, x1, x1, lsl #2
    74a0:	d37df021 	lsl	x1, x1, #3
    74a4:	8b010083 	add	x3, x4, x1
    74a8:	f9401062 	ldr	x2, [x3, #32]
    74ac:	b4fffe02 	cbz	x2, 746c <fwp_caps37+0xac>
    74b0:	38616881 	ldrb	w1, [x4, x1]
    74b4:	7100083f 	cmp	w1, #0x2
    74b8:	54000300 	b.eq	7518 <fwp_caps37+0x158>  // b.none
    74bc:	7100043f 	cmp	w1, #0x1
    74c0:	54fffd61 	b.ne	746c <fwp_caps37+0xac>  // b.any
    74c4:	92403c01 	and	x1, x0, #0xffff
    74c8:	29430064 	ldp	w4, w0, [x3, #24]
    74cc:	9b047c21 	mul	x1, x1, x4
    74d0:	d360fc21 	lsr	x1, x1, #32
    74d4:	eb00003f 	cmp	x1, x0
    74d8:	54fffca2 	b.cs	746c <fwp_caps37+0xac>  // b.hs, b.nlast
    74dc:	8b010042 	add	x2, x2, x1
    74e0:	39400040 	ldrb	w0, [x2]
    74e4:	34fffc40 	cbz	w0, 746c <fwp_caps37+0xac>
    74e8:	b0000141 	adrp	x1, 30000 <__data_start>
    74ec:	91014021 	add	x1, x1, #0x50
    74f0:	b9413023 	ldr	w3, [x1, #304]
    74f4:	35000183 	cbnz	w3, 7524 <fwp_caps37+0x164>
    74f8:	7103f41f 	cmp	w0, #0xfd
    74fc:	540001c8 	b.hi	7534 <fwp_caps37+0x174>  // b.pmore
    7500:	11000400 	add	w0, w0, #0x1
    7504:	39000040 	strb	w0, [x2]
    7508:	17ffffd9 	b	746c <fwp_caps37+0xac>
    750c:	72003c1f 	tst	w0, #0xffff
    7510:	54fffae1 	b.ne	746c <fwp_caps37+0xac>  // b.any
    7514:	17ffffce 	b	744c <fwp_caps37+0x8c>
    7518:	72003c1f 	tst	w0, #0xffff
    751c:	54fffa81 	b.ne	746c <fwp_caps37+0xac>  // b.any
    7520:	17fffff0 	b	74e0 <fwp_caps37+0x120>
    7524:	f940ac23 	ldr	x3, [x1, #344]
    7528:	91000463 	add	x3, x3, #0x1
    752c:	f900ac23 	str	x3, [x1, #344]
    7530:	17fffff2 	b	74f8 <fwp_caps37+0x138>
    7534:	f9400bf3 	ldr	x19, [sp, #16]
    7538:	aa0203e0 	mov	x0, x2
    753c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7540:	17fff4b1 	b	4804 <fwp_rc_wide_dup>

0000000000007544 <f37>:
    7544:	d10203ff 	sub	sp, sp, #0x80
    7548:	90000141 	adrp	x1, 2f000 <fwp_fn_table+0xc90>
    754c:	f947f421 	ldr	x1, [x1, #4072]
    7550:	a9027bfd 	stp	x29, x30, [sp, #32]
    7554:	910083fd 	add	x29, sp, #0x20
    7558:	a9045bf5 	stp	x21, x22, [sp, #64]
    755c:	d0000415 	adrp	x21, 89000 <fwp_root_context+0xbb0>
    7560:	9118c2a3 	add	x3, x21, #0x630
    7564:	a90353f3 	stp	x19, x20, [sp, #48]
    7568:	aa0003f6 	mov	x22, x0
    756c:	a90563f7 	stp	x23, x24, [sp, #80]
    7570:	a9066bf9 	stp	x25, x26, [sp, #96]
    7574:	f949ec62 	ldr	x2, [x3, #5080]
    7578:	f9400024 	ldr	x4, [x1]
    757c:	f9000fe4 	str	x4, [sp, #24]
    7580:	d2800004 	mov	x4, #0x0                   	// #0
    7584:	f949d861 	ldr	x1, [x3, #5040]
    7588:	d370bc42 	lsl	x2, x2, #16
    758c:	b4001900 	cbz	x0, 78ac <f37+0x368>
    7590:	f9400817 	ldr	x23, [x0, #16]
    7594:	cb0102e1 	sub	x1, x23, x1
    7598:	eb02003f 	cmp	x1, x2
    759c:	540003e2 	b.cs	7618 <f37+0xd4>  // b.hs, b.nlast
    75a0:	f949fc60 	ldr	x0, [x3, #5112]
    75a4:	d350fc22 	lsr	x2, x1, #16
    75a8:	8b020842 	add	x2, x2, x2, lsl #2
    75ac:	8b020c02 	add	x2, x0, x2, lsl #3
    75b0:	f9401040 	ldr	x0, [x2, #32]
    75b4:	b4000320 	cbz	x0, 7618 <f37+0xd4>
    75b8:	39400043 	ldrb	w3, [x2]
    75bc:	7100087f 	cmp	w3, #0x2
    75c0:	540015c0 	b.eq	7878 <f37+0x334>  // b.none
    75c4:	7100047f 	cmp	w3, #0x1
    75c8:	54000241 	b.ne	7610 <f37+0xcc>  // b.any
    75cc:	29430843 	ldp	w3, w2, [x2, #24]
    75d0:	92403c21 	and	x1, x1, #0xffff
    75d4:	9b037c21 	mul	x1, x1, x3
    75d8:	d360fc21 	lsr	x1, x1, #32
    75dc:	eb02003f 	cmp	x1, x2
    75e0:	54000182 	b.cs	7610 <f37+0xcc>  // b.hs, b.nlast
    75e4:	8b010000 	add	x0, x0, x1
    75e8:	39400001 	ldrb	w1, [x0]
    75ec:	34000121 	cbz	w1, 7610 <f37+0xcc>
    75f0:	b0000142 	adrp	x2, 30000 <__data_start>
    75f4:	91014042 	add	x2, x2, #0x50
    75f8:	b9413043 	ldr	w3, [x2, #304]
    75fc:	35001443 	cbnz	w3, 7884 <f37+0x340>
    7600:	7103f43f 	cmp	w1, #0xfd
    7604:	54001868 	b.hi	7910 <f37+0x3cc>  // b.pmore
    7608:	11000421 	add	w1, w1, #0x1
    760c:	39000001 	strb	w1, [x0]
    7610:	d2800002 	mov	x2, #0x0                   	// #0
    7614:	b40000d6 	cbz	x22, 762c <f37+0xe8>
    7618:	aa1603e1 	mov	x1, x22
    761c:	d2800002 	mov	x2, #0x0                   	// #0
    7620:	f9400821 	ldr	x1, [x1, #16]
    7624:	91000442 	add	x2, x2, #0x1
    7628:	b5ffffc1 	cbnz	x1, 7620 <f37+0xdc>
    762c:	b4001477 	cbz	x23, 78b8 <f37+0x374>
    7630:	aa1703e1 	mov	x1, x23
    7634:	d2800003 	mov	x3, #0x0                   	// #0
    7638:	f9400821 	ldr	x1, [x1, #16]
    763c:	91000463 	add	x3, x3, #0x1
    7640:	b5ffffc1 	cbnz	x1, 7638 <f37+0xf4>
    7644:	eb02007f 	cmp	x3, x2
    7648:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    764c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7650:	eb00027f 	cmp	x19, x0
    7654:	540010a8 	b.hi	7868 <f37+0x324>  // b.pmore
    7658:	d37ffa74 	lsl	x20, x19, #1
    765c:	52800041 	mov	w1, #0x2                   	// #2
    7660:	91000680 	add	x0, x20, #0x1
    7664:	d37df000 	lsl	x0, x0, #3
    7668:	97fff6aa 	bl	5110 <fwp_heap_alloc>
    766c:	aa0003f8 	mov	x24, x0
    7670:	9118c2a1 	add	x1, x21, #0x630
    7674:	aa0103e0 	mov	x0, x1
    7678:	f9000314 	str	x20, [x24]
    767c:	f949d821 	ldr	x1, [x1, #5040]
    7680:	f949ec00 	ldr	x0, [x0, #5080]
    7684:	cb010301 	sub	x1, x24, x1
    7688:	eb00403f 	cmp	x1, x0, lsl #16
    768c:	54000342 	b.cs	76f4 <f37+0x1b0>  // b.hs, b.nlast
    7690:	9118c2a2 	add	x2, x21, #0x630
    7694:	d350fc20 	lsr	x0, x1, #16
    7698:	8b000800 	add	x0, x0, x0, lsl #2
    769c:	f949fc43 	ldr	x3, [x2, #5112]
    76a0:	d37df002 	lsl	x2, x0, #3
    76a4:	8b020060 	add	x0, x3, x2
    76a8:	f9401014 	ldr	x20, [x0, #32]
    76ac:	b4000254 	cbz	x20, 76f4 <f37+0x1b0>
    76b0:	38626862 	ldrb	w2, [x3, x2]
    76b4:	7100085f 	cmp	w2, #0x2
    76b8:	54000ee0 	b.eq	7894 <f37+0x350>  // b.none
    76bc:	7100045f 	cmp	w2, #0x1
    76c0:	540001a1 	b.ne	76f4 <f37+0x1b0>  // b.any
    76c4:	29430002 	ldp	w2, w0, [x0, #24]
    76c8:	92403c21 	and	x1, x1, #0xffff
    76cc:	9b027c21 	mul	x1, x1, x2
    76d0:	d360fc21 	lsr	x1, x1, #32
    76d4:	eb00003f 	cmp	x1, x0
    76d8:	540000e2 	b.cs	76f4 <f37+0x1b0>  // b.hs, b.nlast
    76dc:	8b010294 	add	x20, x20, x1
    76e0:	39400280 	ldrb	w0, [x20]
    76e4:	7103fc1f 	cmp	w0, #0xff
    76e8:	54001180 	b.eq	7918 <f37+0x3d4>  // b.none
    76ec:	52800020 	mov	w0, #0x1                   	// #1
    76f0:	39000280 	strb	w0, [x20]
    76f4:	b4000253 	cbz	x19, 773c <f37+0x1f8>
    76f8:	8b131313 	add	x19, x24, x19, lsl #4
    76fc:	aa1803f4 	mov	x20, x24
    7700:	aa1603fa 	mov	x26, x22
    7704:	aa1703f9 	mov	x25, x23
    7708:	f9400723 	ldr	x3, [x25, #8]
    770c:	f9400742 	ldr	x2, [x26, #8]
    7710:	f9400861 	ldr	x1, [x3, #16]
    7714:	f9400840 	ldr	x0, [x2, #16]
    7718:	fd400461 	ldr	d1, [x3, #8]
    771c:	fd400440 	ldr	d0, [x2, #8]
    7720:	97fff830 	bl	57e0 <w120>
    7724:	f9000680 	str	x0, [x20, #8]
    7728:	f8010e81 	str	x1, [x20, #16]!
    772c:	f9400b39 	ldr	x25, [x25, #16]
    7730:	f9400b5a 	ldr	x26, [x26, #16]
    7734:	eb14027f 	cmp	x19, x20
    7738:	54fffe81 	b.ne	7708 <f37+0x1c4>  // b.any
    773c:	aa1703e0 	mov	x0, x23
    7740:	97fffc88 	bl	6960 <fwp_drop4>
    7744:	aa1603e0 	mov	x0, x22
    7748:	97fffc86 	bl	6960 <fwp_drop4>
    774c:	f9400316 	ldr	x22, [x24]
    7750:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7754:	b4000236 	cbz	x22, 7798 <f37+0x254>
    7758:	fd003be8 	str	d8, [sp, #112]
    775c:	2f00e408 	movi	d8, #0x0
    7760:	91002319 	add	x25, x24, #0x8
    7764:	91004317 	add	x23, x24, #0x10
    7768:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    776c:	d2800013 	mov	x19, #0x0                   	// #0
    7770:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7774:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7778:	91000a73 	add	x19, x19, #0x2
    777c:	1e602908 	fadd	d8, d8, d0
    7780:	97fff7c0 	bl	5680 <f141.constprop.0>
    7784:	aa0003f4 	mov	x20, x0
    7788:	eb1302df 	cmp	x22, x19
    778c:	54ffff28 	b.hi	7770 <f37+0x22c>  // b.pmore
    7790:	9e660116 	fmov	x22, d8
    7794:	fd403be8 	ldr	d8, [sp, #112]
    7798:	9118c2b5 	add	x21, x21, #0x630
    779c:	aa1803e0 	mov	x0, x24
    77a0:	97fffe2c 	bl	7050 <fwp_drop10>
    77a4:	a900d3f6 	stp	x22, x20, [sp, #8]
    77a8:	910023e1 	add	x1, sp, #0x8
    77ac:	52800000 	mov	w0, #0x0                   	// #0
    77b0:	97fff6bc 	bl	52a0 <fwp_data.part.0.constprop.0>
    77b4:	f949daa1 	ldr	x1, [x21, #5040]
    77b8:	aa0003f3 	mov	x19, x0
    77bc:	f949eea0 	ldr	x0, [x21, #5080]
    77c0:	cb010261 	sub	x1, x19, x1
    77c4:	eb00403f 	cmp	x1, x0, lsl #16
    77c8:	54000322 	b.cs	782c <f37+0x2e8>  // b.hs, b.nlast
    77cc:	d350fc22 	lsr	x2, x1, #16
    77d0:	f949fea3 	ldr	x3, [x21, #5112]
    77d4:	8b020842 	add	x2, x2, x2, lsl #2
    77d8:	d37df042 	lsl	x2, x2, #3
    77dc:	8b020060 	add	x0, x3, x2
    77e0:	f9401014 	ldr	x20, [x0, #32]
    77e4:	b4000254 	cbz	x20, 782c <f37+0x2e8>
    77e8:	38626862 	ldrb	w2, [x3, x2]
    77ec:	7100085f 	cmp	w2, #0x2
    77f0:	54000580 	b.eq	78a0 <f37+0x35c>  // b.none
    77f4:	7100045f 	cmp	w2, #0x1
    77f8:	540001a1 	b.ne	782c <f37+0x2e8>  // b.any
    77fc:	29430002 	ldp	w2, w0, [x0, #24]
    7800:	92403c21 	and	x1, x1, #0xffff
    7804:	9b027c21 	mul	x1, x1, x2
    7808:	d360fc21 	lsr	x1, x1, #32
    780c:	eb00003f 	cmp	x1, x0
    7810:	540000e2 	b.cs	782c <f37+0x2e8>  // b.hs, b.nlast
    7814:	8b010294 	add	x20, x20, x1
    7818:	39400280 	ldrb	w0, [x20]
    781c:	7103fc1f 	cmp	w0, #0xff
    7820:	54000820 	b.eq	7924 <f37+0x3e0>  // b.none
    7824:	52800020 	mov	w0, #0x1                   	// #1
    7828:	39000280 	strb	w0, [x20]
    782c:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    7830:	f947f400 	ldr	x0, [x0, #4072]
    7834:	f9400fe2 	ldr	x2, [sp, #24]
    7838:	f9400001 	ldr	x1, [x0]
    783c:	eb010042 	subs	x2, x2, x1
    7840:	d2800001 	mov	x1, #0x0                   	// #0
    7844:	540007a1 	b.ne	7938 <f37+0x3f4>  // b.any
    7848:	a9427bfd 	ldp	x29, x30, [sp, #32]
    784c:	aa1303e0 	mov	x0, x19
    7850:	a94353f3 	ldp	x19, x20, [sp, #48]
    7854:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7858:	a94563f7 	ldp	x23, x24, [sp, #80]
    785c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7860:	910203ff 	add	sp, sp, #0x80
    7864:	d65f03c0 	ret
    7868:	f0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    786c:	91390000 	add	x0, x0, #0xe40
    7870:	fd003be8 	str	d8, [sp, #112]
    7874:	97fff2b0 	bl	4334 <fwp_trap>
    7878:	72003c3f 	tst	w1, #0xffff
    787c:	54ffeca1 	b.ne	7610 <f37+0xcc>  // b.any
    7880:	17ffff5a 	b	75e8 <f37+0xa4>
    7884:	f940ac43 	ldr	x3, [x2, #344]
    7888:	91000463 	add	x3, x3, #0x1
    788c:	f900ac43 	str	x3, [x2, #344]
    7890:	17ffff5c 	b	7600 <f37+0xbc>
    7894:	72003c3f 	tst	w1, #0xffff
    7898:	54fff2e1 	b.ne	76f4 <f37+0x1b0>  // b.any
    789c:	17ffff91 	b	76e0 <f37+0x19c>
    78a0:	72003c3f 	tst	w1, #0xffff
    78a4:	54fffc41 	b.ne	782c <f37+0x2e8>  // b.any
    78a8:	17ffffdc 	b	7818 <f37+0x2d4>
    78ac:	cb0103e1 	neg	x1, x1
    78b0:	eb02003f 	cmp	x1, x2
    78b4:	540001e3 	b.cc	78f0 <f37+0x3ac>  // b.lo, b.ul, b.last
    78b8:	52800041 	mov	w1, #0x2                   	// #2
    78bc:	d2800100 	mov	x0, #0x8                   	// #8
    78c0:	97fff614 	bl	5110 <fwp_heap_alloc>
    78c4:	aa0003f8 	mov	x24, x0
    78c8:	9118c2a0 	add	x0, x21, #0x630
    78cc:	f900031f 	str	xzr, [x24]
    78d0:	f949d801 	ldr	x1, [x0, #5040]
    78d4:	f949ec00 	ldr	x0, [x0, #5080]
    78d8:	cb010301 	sub	x1, x24, x1
    78dc:	eb00403f 	cmp	x1, x0, lsl #16
    78e0:	54000282 	b.cs	7930 <f37+0x3ec>  // b.hs, b.nlast
    78e4:	d2800013 	mov	x19, #0x0                   	// #0
    78e8:	d2800017 	mov	x23, #0x0                   	// #0
    78ec:	17ffff69 	b	7690 <f37+0x14c>
    78f0:	f949fc62 	ldr	x2, [x3, #5112]
    78f4:	d350fc20 	lsr	x0, x1, #16
    78f8:	8b000800 	add	x0, x0, x0, lsl #2
    78fc:	8b000c42 	add	x2, x2, x0, lsl #3
    7900:	f9401040 	ldr	x0, [x2, #32]
    7904:	b4fffda0 	cbz	x0, 78b8 <f37+0x374>
    7908:	d2800017 	mov	x23, #0x0                   	// #0
    790c:	17ffff2b 	b	75b8 <f37+0x74>
    7910:	97fff3bd 	bl	4804 <fwp_rc_wide_dup>
    7914:	17ffff3f 	b	7610 <f37+0xcc>
    7918:	aa1403e0 	mov	x0, x20
    791c:	97fff2a6 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7920:	17ffff73 	b	76ec <f37+0x1a8>
    7924:	aa1403e0 	mov	x0, x20
    7928:	97fff2a3 	bl	43b4 <fwp_rc_forget_slot.part.0>
    792c:	17ffffbe 	b	7824 <f37+0x2e0>
    7930:	d2800017 	mov	x23, #0x0                   	// #0
    7934:	17ffff82 	b	773c <f37+0x1f8>
    7938:	fd003be8 	str	d8, [sp, #112]
    793c:	97ffebd9 	bl	28a0 <__stack_chk_fail@plt>

0000000000007940 <fwp_owned_entry37>:
    7940:	f9400000 	ldr	x0, [x0]
    7944:	17ffff00 	b	7544 <f37>
    7948:	d503201f 	nop
    794c:	d503201f 	nop

0000000000007950 <e37>:
    7950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7954:	910003fd 	mov	x29, sp
    7958:	f9000bf3 	str	x19, [sp, #16]
    795c:	f9400013 	ldr	x19, [x0]
    7960:	aa1303e0 	mov	x0, x19
    7964:	97fff8d8 	bl	5cc4 <fwp_rc_share>
    7968:	aa1303e0 	mov	x0, x19
    796c:	97fffef6 	bl	7544 <f37>
    7970:	aa0003f3 	mov	x19, x0
    7974:	97fff8d4 	bl	5cc4 <fwp_rc_share>
    7978:	aa1303e0 	mov	x0, x19
    797c:	f9400bf3 	ldr	x19, [sp, #16]
    7980:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7984:	d65f03c0 	ret
    7988:	d503201f 	nop
    798c:	d503201f 	nop

0000000000007990 <fwp_write>:
    7990:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7994:	910003fd 	mov	x29, sp
    7998:	90000144 	adrp	x4, 2f000 <fwp_fn_table+0xc90>
    799c:	f947f484 	ldr	x4, [x4, #4072]
    79a0:	a90153f3 	stp	x19, x20, [sp, #16]
    79a4:	d10943ff 	sub	sp, sp, #0x250
    79a8:	b9400045 	ldr	w5, [x2]
    79ac:	aa0003f4 	mov	x20, x0
    79b0:	f9400080 	ldr	x0, [x4]
    79b4:	f90127e0 	str	x0, [sp, #584]
    79b8:	d2800000 	mov	x0, #0x0                   	// #0
    79bc:	710064bf 	cmp	w5, #0x19
    79c0:	54000408 	b.hi	7a40 <fwp_write+0xb0>  // b.pmore
    79c4:	90000040 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    79c8:	aa0103f3 	mov	x19, x1
    79cc:	911e4000 	add	x0, x0, #0x790
    79d0:	f9013bf5 	str	x21, [sp, #624]
    79d4:	f9013ff6 	str	x22, [sp, #632]
    79d8:	f90153fb 	str	x27, [sp, #672]
    79dc:	f90157fc 	str	x28, [sp, #680]
    79e0:	aa0203fc 	mov	x28, x2
    79e4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    79e8:	10000061 	adr	x1, 79f4 <fwp_write+0x64>
    79ec:	8b20a820 	add	x0, x1, w0, sxth #2
    79f0:	d61f0000 	br	x0
    79f4:	910123e0 	add	x0, sp, #0x48
    79f8:	aa1303e5 	mov	x5, x19
    79fc:	f0000024 	adrp	x4, e000 <fwp_main_thread+0x1470>
    7a00:	aa0003f3 	mov	x19, x0
    7a04:	913a2084 	add	x4, x4, #0xe88
    7a08:	d2804003 	mov	x3, #0x200                 	// #512
    7a0c:	aa0303e1 	mov	x1, x3
    7a10:	52800042 	mov	w2, #0x2                   	// #2
    7a14:	97ffeb7f 	bl	2810 <__snprintf_chk@plt>
    7a18:	aa1303e0 	mov	x0, x19
    7a1c:	97ffeb45 	bl	2730 <strlen@plt>
    7a20:	aa1303e1 	mov	x1, x19
    7a24:	aa0003e2 	mov	x2, x0
    7a28:	aa1403e0 	mov	x0, x20
    7a2c:	97ffef19 	bl	3690 <buf_put>
    7a30:	f9413bf5 	ldr	x21, [sp, #624]
    7a34:	f9413ff6 	ldr	x22, [sp, #632]
    7a38:	f94153fb 	ldr	x27, [sp, #672]
    7a3c:	f94157fc 	ldr	x28, [sp, #680]
    7a40:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    7a44:	f947f400 	ldr	x0, [x0, #4072]
    7a48:	f94127e2 	ldr	x2, [sp, #584]
    7a4c:	f9400001 	ldr	x1, [x0]
    7a50:	eb010042 	subs	x2, x2, x1
    7a54:	d2800001 	mov	x1, #0x0                   	// #0
    7a58:	540077c1 	b.ne	8950 <fwp_write+0xfc0>  // b.any
    7a5c:	910943ff 	add	sp, sp, #0x250
    7a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    7a64:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7a68:	d65f03c0 	ret
    7a6c:	910123e0 	add	x0, sp, #0x48
    7a70:	aa1303e5 	mov	x5, x19
    7a74:	f0000024 	adrp	x4, e000 <fwp_main_thread+0x1470>
    7a78:	aa0003f3 	mov	x19, x0
    7a7c:	913a0084 	add	x4, x4, #0xe80
    7a80:	d2804003 	mov	x3, #0x200                 	// #512
    7a84:	17ffffe2 	b	7a0c <fwp_write+0x7c>
    7a88:	71004cbf 	cmp	w5, #0x13
    7a8c:	f0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    7a90:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7a94:	9139c000 	add	x0, x0, #0xe70
    7a98:	9139e021 	add	x1, x1, #0xe78
    7a9c:	d2800082 	mov	x2, #0x4                   	// #4
    7aa0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7aa4:	aa1403e0 	mov	x0, x20
    7aa8:	f90143f7 	str	x23, [sp, #640]
    7aac:	d2800016 	mov	x22, #0x0                   	// #0
    7ab0:	f90147f8 	str	x24, [sp, #648]
    7ab4:	97ffeef7 	bl	3690 <buf_put>
    7ab8:	f9400260 	ldr	x0, [x19]
    7abc:	f0000037 	adrp	x23, e000 <fwp_main_thread+0x1470>
    7ac0:	d2800015 	mov	x21, #0x0                   	// #0
    7ac4:	913be2f7 	add	x23, x23, #0xef8
    7ac8:	b40047a0 	cbz	x0, 83bc <fwp_write+0xa2c>
    7acc:	b9400380 	ldr	w0, [x28]
    7ad0:	52800003 	mov	w3, #0x0                   	// #0
    7ad4:	f9401f82 	ldr	x2, [x28, #56]
    7ad8:	71004c1f 	cmp	w0, #0x13
    7adc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	8b010e61 	add	x1, x19, x1, lsl #3
    7ae8:	f9400421 	ldr	x1, [x1, #8]
    7aec:	97ffffa9 	bl	7990 <fwp_write>
    7af0:	b9400380 	ldr	w0, [x28]
    7af4:	7100481f 	cmp	w0, #0x12
    7af8:	54004b40 	b.eq	8460 <fwp_write+0xad0>  // b.none
    7afc:	f9400260 	ldr	x0, [x19]
    7b00:	910006b5 	add	x21, x21, #0x1
    7b04:	91000ad6 	add	x22, x22, #0x2
    7b08:	eb15001f 	cmp	x0, x21
    7b0c:	54004589 	b.ls	83bc <fwp_write+0xa2c>  // b.plast
    7b10:	aa1703e1 	mov	x1, x23
    7b14:	aa1403e0 	mov	x0, x20
    7b18:	d2800042 	mov	x2, #0x2                   	// #2
    7b1c:	97ffeedd 	bl	3690 <buf_put>
    7b20:	17ffffeb 	b	7acc <fwp_write+0x13c>
    7b24:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7b28:	913ac021 	add	x1, x1, #0xeb0
    7b2c:	d28000c2 	mov	x2, #0x6                   	// #6
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	91004273 	add	x19, x19, #0x10
    7b38:	97ffeed6 	bl	3690 <buf_put>
    7b3c:	aa1303e0 	mov	x0, x19
    7b40:	97ffeafc 	bl	2730 <strlen@plt>
    7b44:	aa1303e1 	mov	x1, x19
    7b48:	aa0003e2 	mov	x2, x0
    7b4c:	aa1403e0 	mov	x0, x20
    7b50:	97ffeed0 	bl	3690 <buf_put>
    7b54:	528007c3 	mov	w3, #0x3e                  	// #62
    7b58:	aa1403e0 	mov	x0, x20
    7b5c:	91001fe1 	add	x1, sp, #0x7
    7b60:	d2800022 	mov	x2, #0x1                   	// #1
    7b64:	39001fe3 	strb	w3, [sp, #7]
    7b68:	17ffffb1 	b	7a2c <fwp_write+0x9c>
    7b6c:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    7b70:	f947f400 	ldr	x0, [x0, #4072]
    7b74:	f94127e2 	ldr	x2, [sp, #584]
    7b78:	f9400001 	ldr	x1, [x0]
    7b7c:	eb010042 	subs	x2, x2, x1
    7b80:	d2800001 	mov	x1, #0x0                   	// #0
    7b84:	540034e1 	b.ne	8220 <fwp_write+0x890>  // b.any
    7b88:	f9413bf5 	ldr	x21, [sp, #624]
    7b8c:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7b90:	f9413ff6 	ldr	x22, [sp, #632]
    7b94:	aa1403e0 	mov	x0, x20
    7b98:	913a4021 	add	x1, x1, #0xe90
    7b9c:	d2800142 	mov	x2, #0xa                   	// #10
    7ba0:	f94153fb 	ldr	x27, [sp, #672]
    7ba4:	f94157fc 	ldr	x28, [sp, #680]
    7ba8:	910943ff 	add	sp, sp, #0x250
    7bac:	a94153f3 	ldp	x19, x20, [sp, #16]
    7bb0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7bb4:	17ffeeb7 	b	3690 <buf_put>
    7bb8:	f9400456 	ldr	x22, [x2, #8]
    7bbc:	f90143f7 	str	x23, [sp, #640]
    7bc0:	f90147f8 	str	x24, [sp, #648]
    7bc4:	b4005b16 	cbz	x22, 8724 <fwp_write+0xd94>
    7bc8:	aa1603e0 	mov	x0, x22
    7bcc:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7bd0:	913c4021 	add	x1, x1, #0xf10
    7bd4:	97ffeb53 	bl	2920 <strcmp@plt>
    7bd8:	2a0003f5 	mov	w21, w0
    7bdc:	34005fe0 	cbz	w0, 87d8 <fwp_write+0xe48>
    7be0:	aa1603e0 	mov	x0, x22
    7be4:	97ffead3 	bl	2730 <strlen@plt>
    7be8:	aa1603e1 	mov	x1, x22
    7bec:	aa0003e2 	mov	x2, x0
    7bf0:	aa1403e0 	mov	x0, x20
    7bf4:	97ffeea7 	bl	3690 <buf_put>
    7bf8:	52800403 	mov	w3, #0x20                  	// #32
    7bfc:	91001ff5 	add	x21, sp, #0x7
    7c00:	aa1503e1 	mov	x1, x21
    7c04:	aa1403e0 	mov	x0, x20
    7c08:	d2800022 	mov	x2, #0x1                   	// #1
    7c0c:	39001fe3 	strb	w3, [sp, #7]
    7c10:	97ffeea0 	bl	3690 <buf_put>
    7c14:	52800f63 	mov	w3, #0x7b                  	// #123
    7c18:	aa1403e0 	mov	x0, x20
    7c1c:	aa1503e1 	mov	x1, x21
    7c20:	d2800022 	mov	x2, #0x1                   	// #1
    7c24:	39001fe3 	strb	w3, [sp, #7]
    7c28:	97ffee9a 	bl	3690 <buf_put>
    7c2c:	b9401380 	ldr	w0, [x28, #16]
    7c30:	52800018 	mov	w24, #0x0                   	// #0
    7c34:	7100001f 	cmp	w0, #0x0
    7c38:	54003aad 	b.le	838c <fwp_write+0x9fc>
    7c3c:	f9014bf9 	str	x25, [sp, #656]
    7c40:	f0000039 	adrp	x25, e000 <fwp_main_thread+0x1470>
    7c44:	913ce339 	add	x25, x25, #0xf38
    7c48:	f9014ffa 	str	x26, [sp, #664]
    7c4c:	f000003a 	adrp	x26, e000 <fwp_main_thread+0x1470>
    7c50:	913be35a 	add	x26, x26, #0xef8
    7c54:	91002276 	add	x22, x19, #0x8
    7c58:	d2800013 	mov	x19, #0x0                   	// #0
    7c5c:	b5003e93 	cbnz	x19, 842c <fwp_write+0xa9c>
    7c60:	d37df277 	lsl	x23, x19, #3
    7c64:	34003cb8 	cbz	w24, 83f8 <fwp_write+0xa68>
    7c68:	f9401382 	ldr	x2, [x28, #32]
    7c6c:	aa1403e0 	mov	x0, x20
    7c70:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7c74:	52800003 	mov	w3, #0x0                   	// #0
    7c78:	f8776842 	ldr	x2, [x2, x23]
    7c7c:	91000673 	add	x19, x19, #0x1
    7c80:	97ffff44 	bl	7990 <fwp_write>
    7c84:	b9401380 	ldr	w0, [x28, #16]
    7c88:	6b13001f 	cmp	w0, w19
    7c8c:	54fffe8c 	b.gt	7c5c <fwp_write+0x2cc>
    7c90:	f9414bf9 	ldr	x25, [sp, #656]
    7c94:	f9414ffa 	ldr	x26, [sp, #664]
    7c98:	340037b8 	cbz	w24, 838c <fwp_write+0x9fc>
    7c9c:	52800523 	mov	w3, #0x29                  	// #41
    7ca0:	aa1503e1 	mov	x1, x21
    7ca4:	aa1403e0 	mov	x0, x20
    7ca8:	d2800022 	mov	x2, #0x1                   	// #1
    7cac:	39001fe3 	strb	w3, [sp, #7]
    7cb0:	97ffee78 	bl	3690 <buf_put>
    7cb4:	f9413bf5 	ldr	x21, [sp, #624]
    7cb8:	f9413ff6 	ldr	x22, [sp, #632]
    7cbc:	f94143f7 	ldr	x23, [sp, #640]
    7cc0:	f94147f8 	ldr	x24, [sp, #648]
    7cc4:	f94153fb 	ldr	x27, [sp, #672]
    7cc8:	f94157fc 	ldr	x28, [sp, #680]
    7ccc:	17ffff5d 	b	7a40 <fwp_write+0xb0>
    7cd0:	b9404855 	ldr	w21, [x2, #72]
    7cd4:	aa1403e0 	mov	x0, x20
    7cd8:	93407eb6 	sxtw	x22, w21
    7cdc:	91000ac1 	add	x1, x22, #0x2
    7ce0:	97ffee38 	bl	35c0 <buf_grow>
    7ce4:	a9400281 	ldp	x1, x0, [x20]
    7ce8:	528e8603 	mov	w3, #0x7430                	// #29744
    7cec:	78206823 	strh	w3, [x1, x0]
    7cf0:	8b000022 	add	x2, x1, x0
    7cf4:	710002bf 	cmp	w21, #0x0
    7cf8:	540036cd 	b.le	83d0 <fwp_write+0xa40>
    7cfc:	110006a3 	add	w3, w21, #0x1
    7d00:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7d04:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7d08:	91000449 	add	x9, x2, #0x1
    7d0c:	8b23c043 	add	x3, x2, w3, sxtw
    7d10:	f28aaac6 	movk	x6, #0x5556
    7d14:	f2955568 	movk	x8, #0xaaab
    7d18:	1400000d 	b	7d4c <fwp_write+0x3bc>
    7d1c:	d2800021 	mov	x1, #0x1                   	// #1
    7d20:	528005a5 	mov	w5, #0x2d                  	// #45
    7d24:	f100001f 	cmp	x0, #0x0
    7d28:	9b467e60 	smulh	x0, x19, x6
    7d2c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7d30:	381ff465 	strb	w5, [x3], #-1
    7d34:	cb040000 	sub	x0, x0, x4
    7d38:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7d3c:	cb020000 	sub	x0, x0, x2
    7d40:	8b010013 	add	x19, x0, x1
    7d44:	eb03013f 	cmp	x9, x3
    7d48:	54003440 	b.eq	83d0 <fwp_write+0xa40>  // b.none
    7d4c:	9b467e60 	smulh	x0, x19, x6
    7d50:	937ffe64 	asr	x4, x19, #63
    7d54:	52800605 	mov	w5, #0x30                  	// #48
    7d58:	cb040000 	sub	x0, x0, x4
    7d5c:	8b000400 	add	x0, x0, x0, lsl #1
    7d60:	cb000260 	sub	x0, x19, x0
    7d64:	91000c01 	add	x1, x0, #0x3
    7d68:	9bc87c22 	umulh	x2, x1, x8
    7d6c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7d70:	8b4204e2 	add	x2, x7, x2, lsr #1
    7d74:	eb020021 	subs	x1, x1, x2
    7d78:	54fffd60 	b.eq	7d24 <fwp_write+0x394>  // b.none
    7d7c:	f100043f 	cmp	x1, #0x1
    7d80:	54fffce1 	b.ne	7d1c <fwp_write+0x38c>  // b.any
    7d84:	d2800001 	mov	x1, #0x0                   	// #0
    7d88:	52800565 	mov	w5, #0x2b                  	// #43
    7d8c:	17ffffe6 	b	7d24 <fwp_write+0x394>
    7d90:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    7d94:	f947f400 	ldr	x0, [x0, #4072]
    7d98:	f94127e2 	ldr	x2, [sp, #584]
    7d9c:	f9400001 	ldr	x1, [x0]
    7da0:	eb010042 	subs	x2, x2, x1
    7da4:	d2800001 	mov	x1, #0x0                   	// #0
    7da8:	540023c1 	b.ne	8220 <fwp_write+0x890>  // b.any
    7dac:	f9413bf5 	ldr	x21, [sp, #624]
    7db0:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7db4:	f9413ff6 	ldr	x22, [sp, #632]
    7db8:	aa1403e0 	mov	x0, x20
    7dbc:	913a8021 	add	x1, x1, #0xea0
    7dc0:	d2800102 	mov	x2, #0x8                   	// #8
    7dc4:	17ffff77 	b	7ba0 <fwp_write+0x210>
    7dc8:	aa1403e0 	mov	x0, x20
    7dcc:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7dd0:	d28000c2 	mov	x2, #0x6                   	// #6
    7dd4:	913c0021 	add	x1, x1, #0xf00
    7dd8:	97ffee2e 	bl	3690 <buf_put>
    7ddc:	d2800015 	mov	x21, #0x0                   	// #0
    7de0:	f9400263 	ldr	x3, [x19]
    7de4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7de8:	54002c60 	b.eq	8374 <fwp_write+0x9e4>  // b.none
    7dec:	f9401f82 	ldr	x2, [x28, #56]
    7df0:	f90143f7 	str	x23, [sp, #640]
    7df4:	f90147f8 	str	x24, [sp, #648]
    7df8:	d2800857 	mov	x23, #0x42                  	// #66
    7dfc:	f9014bf9 	str	x25, [sp, #656]
    7e00:	f0000036 	adrp	x22, e000 <fwp_main_thread+0x1470>
    7e04:	f9014ffa 	str	x26, [sp, #664]
    7e08:	913be2d6 	add	x22, x22, #0xef8
    7e0c:	d2800038 	mov	x24, #0x1                   	// #1
    7e10:	f2a18017 	movk	x23, #0xc00, lsl #16
    7e14:	d2809099 	mov	x25, #0x484                 	// #1156
    7e18:	b40004a2 	cbz	x2, 7eac <fwp_write+0x51c>
    7e1c:	b9400040 	ldr	w0, [x2]
    7e20:	7100701f 	cmp	w0, #0x1c
    7e24:	540042c0 	b.eq	867c <fwp_write+0xcec>  // b.none
    7e28:	71006c1f 	cmp	w0, #0x1b
    7e2c:	54000408 	b.hi	7eac <fwp_write+0x51c>  // b.pmore
    7e30:	9ac02301 	lsl	x1, x24, x0
    7e34:	ea17003f 	tst	x1, x23
    7e38:	540036a1 	b.ne	850c <fwp_write+0xb7c>  // b.any
    7e3c:	ea19003f 	tst	x1, x25
    7e40:	54003521 	b.ne	84e4 <fwp_write+0xb54>  // b.any
    7e44:	d2800424 	mov	x4, #0x21                  	// #33
    7e48:	ea04003f 	tst	x1, x4
    7e4c:	54000300 	b.eq	7eac <fwp_write+0x51c>  // b.none
    7e50:	b7f849c3 	tbnz	x3, #63, 8788 <fwp_write+0xdf8>
    7e54:	91002261 	add	x1, x19, #0x8
    7e58:	8b150021 	add	x1, x1, x21
    7e5c:	39400021 	ldrb	w1, [x1]
    7e60:	7100001f 	cmp	w0, #0x0
    7e64:	93401c23 	sxtb	x3, w1
    7e68:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e6c:	d503201f 	nop
    7e70:	aa1403e0 	mov	x0, x20
    7e74:	52800003 	mov	w3, #0x0                   	// #0
    7e78:	97fffec6 	bl	7990 <fwp_write>
    7e7c:	910006b5 	add	x21, x21, #0x1
    7e80:	f9400260 	ldr	x0, [x19]
    7e84:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7e88:	eb0002bf 	cmp	x21, x0
    7e8c:	540026c2 	b.cs	8364 <fwp_write+0x9d4>  // b.hs, b.nlast
    7e90:	d2800042 	mov	x2, #0x2                   	// #2
    7e94:	aa1603e1 	mov	x1, x22
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	97ffedfd 	bl	3690 <buf_put>
    7ea0:	f9401f82 	ldr	x2, [x28, #56]
    7ea4:	f9400263 	ldr	x3, [x19]
    7ea8:	b5fffba2 	cbnz	x2, 7e1c <fwp_write+0x48c>
    7eac:	d37df2a0 	lsl	x0, x21, #3
    7eb0:	b7f83f03 	tbnz	x3, #63, 8690 <fwp_write+0xd00>
    7eb4:	91002261 	add	x1, x19, #0x8
    7eb8:	8b000020 	add	x0, x1, x0
    7ebc:	f9400001 	ldr	x1, [x0]
    7ec0:	17ffffec 	b	7e70 <fwp_write+0x4e0>
    7ec4:	a9400e62 	ldp	x2, x3, [x19]
    7ec8:	b7f83ca3 	tbnz	x3, #63, 865c <fwp_write+0xccc>
    7ecc:	910123f5 	add	x21, sp, #0x48
    7ed0:	aa1503e0 	mov	x0, x21
    7ed4:	97ffebd3 	bl	2e20 <fwp_fmt_u128>
    7ed8:	aa1503e0 	mov	x0, x21
    7edc:	97ffea15 	bl	2730 <strlen@plt>
    7ee0:	aa1503e1 	mov	x1, x21
    7ee4:	aa0003e2 	mov	x2, x0
    7ee8:	17fffed0 	b	7a28 <fwp_write+0x98>
    7eec:	fd015be8 	str	d8, [sp, #688]
    7ef0:	1e270268 	fmov	s8, w19
    7ef4:	fd015fe9 	str	d9, [sp, #696]
    7ef8:	1e282100 	fcmp	s8, s8
    7efc:	54004d26 	b.vs	88a0 <fwp_write+0xf10>
    7f00:	1e20c101 	fabs	s1, s8
    7f04:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7f08:	1e270000 	fmov	s0, w0
    7f0c:	1e202020 	fcmp	s1, s0
    7f10:	54002c0d 	b.le	8490 <fwp_write+0xb00>
    7f14:	1e202118 	fcmpe	s8, #0.0
    7f18:	f0000022 	adrp	x2, e000 <fwp_main_thread+0x1470>
    7f1c:	9126e042 	add	x2, x2, #0x9b8
    7f20:	910123f5 	add	x21, sp, #0x48
    7f24:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7f28:	91394021 	add	x1, x1, #0xe50
    7f2c:	aa1503e0 	mov	x0, x21
    7f30:	9a81c041 	csel	x1, x2, x1, gt
    7f34:	97ffeaab 	bl	29e0 <strcpy@plt>
    7f38:	aa1503e0 	mov	x0, x21
    7f3c:	97ffe9fd 	bl	2730 <strlen@plt>
    7f40:	aa1503e1 	mov	x1, x21
    7f44:	aa0003e2 	mov	x2, x0
    7f48:	aa1403e0 	mov	x0, x20
    7f4c:	97ffedd1 	bl	3690 <buf_put>
    7f50:	f9413bf5 	ldr	x21, [sp, #624]
    7f54:	f9413ff6 	ldr	x22, [sp, #632]
    7f58:	f94153fb 	ldr	x27, [sp, #672]
    7f5c:	f94157fc 	ldr	x28, [sp, #680]
    7f60:	fd415be8 	ldr	d8, [sp, #688]
    7f64:	fd415fe9 	ldr	d9, [sp, #696]
    7f68:	17fffeb6 	b	7a40 <fwp_write+0xb0>
    7f6c:	f9400276 	ldr	x22, [x19]
    7f70:	34002e03 	cbz	w3, 8530 <fwp_write+0xba0>
    7f74:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    7f78:	f947f400 	ldr	x0, [x0, #4072]
    7f7c:	f94127e2 	ldr	x2, [sp, #584]
    7f80:	f9400001 	ldr	x1, [x0]
    7f84:	eb010042 	subs	x2, x2, x1
    7f88:	d2800001 	mov	x1, #0x0                   	// #0
    7f8c:	540014a1 	b.ne	8220 <fwp_write+0x890>  // b.any
    7f90:	aa1603e2 	mov	x2, x22
    7f94:	91002261 	add	x1, x19, #0x8
    7f98:	f9413bf5 	ldr	x21, [sp, #624]
    7f9c:	aa1403e0 	mov	x0, x20
    7fa0:	f9413ff6 	ldr	x22, [sp, #632]
    7fa4:	17fffeff 	b	7ba0 <fwp_write+0x210>
    7fa8:	fd015be8 	str	d8, [sp, #688]
    7fac:	9e670268 	fmov	d8, x19
    7fb0:	fd015fe9 	str	d9, [sp, #696]
    7fb4:	1e682100 	fcmp	d8, d8
    7fb8:	54004746 	b.vs	88a0 <fwp_write+0xf10>
    7fbc:	1e60c101 	fabs	d1, d8
    7fc0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7fc4:	9e670000 	fmov	d0, x0
    7fc8:	910123f5 	add	x21, sp, #0x48
    7fcc:	52800033 	mov	w19, #0x1                   	// #1
    7fd0:	1e602020 	fcmp	d1, d0
    7fd4:	540001ad 	b.le	8008 <fwp_write+0x678>
    7fd8:	1e602118 	fcmpe	d8, #0.0
    7fdc:	f0000022 	adrp	x2, e000 <fwp_main_thread+0x1470>
    7fe0:	9126e042 	add	x2, x2, #0x9b8
    7fe4:	f0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    7fe8:	91394021 	add	x1, x1, #0xe50
    7fec:	aa1503e0 	mov	x0, x21
    7ff0:	9a81c041 	csel	x1, x2, x1, gt
    7ff4:	97ffea7b 	bl	29e0 <strcpy@plt>
    7ff8:	17ffffd0 	b	7f38 <fwp_write+0x5a8>
    7ffc:	11000673 	add	w19, w19, #0x1
    8000:	71004a7f 	cmp	w19, #0x12
    8004:	54003860 	b.eq	8710 <fwp_write+0xd80>  // b.none
    8008:	1e604100 	fmov	d0, d8
    800c:	2a1303e1 	mov	w1, w19
    8010:	aa1503e0 	mov	x0, x21
    8014:	97ffedfb 	bl	3800 <fwp_format_g.constprop.0>
    8018:	aa1503e0 	mov	x0, x21
    801c:	d2800001 	mov	x1, #0x0                   	// #0
    8020:	97ffe9d8 	bl	2780 <strtod@plt>
    8024:	1e602100 	fcmp	d8, d0
    8028:	54fffea1 	b.ne	7ffc <fwp_write+0x66c>  // b.any
    802c:	aa1503e0 	mov	x0, x21
    8030:	97ffedd1 	bl	3774 <fwp_finish_float>
    8034:	17ffffc1 	b	7f38 <fwp_write+0x5a8>
    8038:	a9400e62 	ldp	x2, x3, [x19]
    803c:	910123f3 	add	x19, sp, #0x48
    8040:	aa1303e0 	mov	x0, x19
    8044:	97ffeb77 	bl	2e20 <fwp_fmt_u128>
    8048:	17fffe74 	b	7a18 <fwp_write+0x88>
    804c:	f90143f7 	str	x23, [sp, #640]
    8050:	f90147f8 	str	x24, [sp, #648]
    8054:	2a1303f8 	mov	w24, w19
    8058:	f9014bf9 	str	x25, [sp, #656]
    805c:	f9014ffa 	str	x26, [sp, #664]
    8060:	f13ffe7f 	cmp	x19, #0xfff
    8064:	54000049 	b.ls	806c <fwp_write+0x6dc>  // b.plast
    8068:	b9400278 	ldr	w24, [x19]
    806c:	f9400f80 	ldr	x0, [x28, #24]
    8070:	2a1803f5 	mov	w21, w24
    8074:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8078:	d37ef6b9 	lsl	x25, x21, #2
    807c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8080:	aa1603e0 	mov	x0, x22
    8084:	97ffe9ab 	bl	2730 <strlen@plt>
    8088:	aa1603e1 	mov	x1, x22
    808c:	aa0003e2 	mov	x2, x0
    8090:	aa1403e0 	mov	x0, x20
    8094:	97ffed7f 	bl	3690 <buf_put>
    8098:	f9401780 	ldr	x0, [x28, #40]
    809c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    80a0:	7100001f 	cmp	w0, #0x0
    80a4:	5400068d 	b.le	8174 <fwp_write+0x7e4>
    80a8:	91002276 	add	x22, x19, #0x8
    80ac:	91001ff5 	add	x21, sp, #0x7
    80b0:	d280001b 	mov	x27, #0x0                   	// #0
    80b4:	5280041a 	mov	w26, #0x20                  	// #32
    80b8:	f9401b80 	ldr	x0, [x28, #48]
    80bc:	aa1503e1 	mov	x1, x21
    80c0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    80c4:	d2800022 	mov	x2, #0x1                   	// #1
    80c8:	f8786803 	ldr	x3, [x0, x24]
    80cc:	aa1403e0 	mov	x0, x20
    80d0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    80d4:	39001ffa 	strb	w26, [sp, #7]
    80d8:	97ffed6e 	bl	3690 <buf_put>
    80dc:	f13ffeff 	cmp	x23, #0xfff
    80e0:	b9400261 	ldr	w1, [x19]
    80e4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    80e8:	7100383f 	cmp	w1, #0xe
    80ec:	54000160 	b.eq	8118 <fwp_write+0x788>  // b.none
    80f0:	7100403f 	cmp	w1, #0x10
    80f4:	54001a60 	b.eq	8440 <fwp_write+0xab0>  // b.none
    80f8:	7100283f 	cmp	w1, #0xa
    80fc:	54002aa0 	b.eq	8650 <fwp_write+0xcc0>  // b.none
    8100:	540014ac 	b.gt	8394 <fwp_write+0xa04>
    8104:	71000c3f 	cmp	w1, #0x3
    8108:	540029ac 	b.gt	863c <fwp_write+0xcac>
    810c:	d37ffee0 	lsr	x0, x23, #63
    8110:	37f814a1 	tbnz	w1, #31, 83a4 <fwp_write+0xa14>
    8114:	d503201f 	nop
    8118:	34001460 	cbz	w0, 83a4 <fwp_write+0xa14>
    811c:	52800503 	mov	w3, #0x28                  	// #40
    8120:	aa1503e1 	mov	x1, x21
    8124:	aa1403e0 	mov	x0, x20
    8128:	d2800022 	mov	x2, #0x1                   	// #1
    812c:	39001fe3 	strb	w3, [sp, #7]
    8130:	97ffed58 	bl	3690 <buf_put>
    8134:	aa1303e2 	mov	x2, x19
    8138:	aa1703e1 	mov	x1, x23
    813c:	aa1403e0 	mov	x0, x20
    8140:	52800003 	mov	w3, #0x0                   	// #0
    8144:	97fffe13 	bl	7990 <fwp_write>
    8148:	52800523 	mov	w3, #0x29                  	// #41
    814c:	aa1503e1 	mov	x1, x21
    8150:	aa1403e0 	mov	x0, x20
    8154:	d2800022 	mov	x2, #0x1                   	// #1
    8158:	39001fe3 	strb	w3, [sp, #7]
    815c:	97ffed4d 	bl	3690 <buf_put>
    8160:	f9401780 	ldr	x0, [x28, #40]
    8164:	9100077b 	add	x27, x27, #0x1
    8168:	b8796800 	ldr	w0, [x0, x25]
    816c:	6b1b001f 	cmp	w0, w27
    8170:	54fffa4c 	b.gt	80b8 <fwp_write+0x728>
    8174:	f9413bf5 	ldr	x21, [sp, #624]
    8178:	f9413ff6 	ldr	x22, [sp, #632]
    817c:	f94143f7 	ldr	x23, [sp, #640]
    8180:	f94147f8 	ldr	x24, [sp, #648]
    8184:	f9414bf9 	ldr	x25, [sp, #656]
    8188:	f9414ffa 	ldr	x26, [sp, #664]
    818c:	f94153fb 	ldr	x27, [sp, #672]
    8190:	f94157fc 	ldr	x28, [sp, #680]
    8194:	17fffe2b 	b	7a40 <fwp_write+0xb0>
    8198:	52800783 	mov	w3, #0x3c                  	// #60
    819c:	91001ff3 	add	x19, sp, #0x7
    81a0:	aa1303e1 	mov	x1, x19
    81a4:	d2800022 	mov	x2, #0x1                   	// #1
    81a8:	aa1403e0 	mov	x0, x20
    81ac:	39001fe3 	strb	w3, [sp, #7]
    81b0:	97ffed38 	bl	3690 <buf_put>
    81b4:	f9400795 	ldr	x21, [x28, #8]
    81b8:	aa1503e0 	mov	x0, x21
    81bc:	97ffe95d 	bl	2730 <strlen@plt>
    81c0:	aa1503e1 	mov	x1, x21
    81c4:	aa0003e2 	mov	x2, x0
    81c8:	aa1403e0 	mov	x0, x20
    81cc:	97ffed31 	bl	3690 <buf_put>
    81d0:	528007c3 	mov	w3, #0x3e                  	// #62
    81d4:	aa1303e1 	mov	x1, x19
    81d8:	aa1403e0 	mov	x0, x20
    81dc:	d2800022 	mov	x2, #0x1                   	// #1
    81e0:	39001fe3 	strb	w3, [sp, #7]
    81e4:	17fffe12 	b	7a2c <fwp_write+0x9c>
    81e8:	f100067f 	cmp	x19, #0x1
    81ec:	540025a0 	b.eq	86a0 <fwp_write+0xd10>  // b.none
    81f0:	b100067f 	cmn	x19, #0x1
    81f4:	54002bc0 	b.eq	876c <fwp_write+0xddc>  // b.none
    81f8:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    81fc:	91396021 	add	x1, x1, #0xe58
    8200:	d2800022 	mov	x2, #0x1                   	// #1
    8204:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    8208:	f947f400 	ldr	x0, [x0, #4072]
    820c:	f94127e4 	ldr	x4, [sp, #584]
    8210:	f9400003 	ldr	x3, [x0]
    8214:	eb030084 	subs	x4, x4, x3
    8218:	d2800003 	mov	x3, #0x0                   	// #0
    821c:	54ffebe0 	b.eq	7f98 <fwp_write+0x608>  // b.none
    8220:	f90143f7 	str	x23, [sp, #640]
    8224:	f90147f8 	str	x24, [sp, #648]
    8228:	f9014bf9 	str	x25, [sp, #656]
    822c:	f9014ffa 	str	x26, [sp, #664]
    8230:	fd015be8 	str	d8, [sp, #688]
    8234:	fd015fe9 	str	d9, [sp, #696]
    8238:	97ffe99a 	bl	28a0 <__stack_chk_fail@plt>
    823c:	52800b63 	mov	w3, #0x5b                  	// #91
    8240:	91001ff5 	add	x21, sp, #0x7
    8244:	aa1503e1 	mov	x1, x21
    8248:	aa1403e0 	mov	x0, x20
    824c:	d2800022 	mov	x2, #0x1                   	// #1
    8250:	d0000036 	adrp	x22, e000 <fwp_main_thread+0x1470>
    8254:	913be2d6 	add	x22, x22, #0xef8
    8258:	39001fe3 	strb	w3, [sp, #7]
    825c:	97ffed0d 	bl	3690 <buf_put>
    8260:	b4000273 	cbz	x19, 82ac <fwp_write+0x91c>
    8264:	f9400661 	ldr	x1, [x19, #8]
    8268:	aa1403e0 	mov	x0, x20
    826c:	f9401f82 	ldr	x2, [x28, #56]
    8270:	52800003 	mov	w3, #0x0                   	// #0
    8274:	97fffdc7 	bl	7990 <fwp_write>
    8278:	f9400a73 	ldr	x19, [x19, #16]
    827c:	b4000193 	cbz	x19, 82ac <fwp_write+0x91c>
    8280:	aa1603e1 	mov	x1, x22
    8284:	aa1403e0 	mov	x0, x20
    8288:	d2800042 	mov	x2, #0x2                   	// #2
    828c:	97ffed01 	bl	3690 <buf_put>
    8290:	f9400661 	ldr	x1, [x19, #8]
    8294:	aa1403e0 	mov	x0, x20
    8298:	f9401f82 	ldr	x2, [x28, #56]
    829c:	52800003 	mov	w3, #0x0                   	// #0
    82a0:	97fffdbc 	bl	7990 <fwp_write>
    82a4:	f9400a73 	ldr	x19, [x19, #16]
    82a8:	b5fffed3 	cbnz	x19, 8280 <fwp_write+0x8f0>
    82ac:	52800ba3 	mov	w3, #0x5d                  	// #93
    82b0:	aa1503e1 	mov	x1, x21
    82b4:	aa1403e0 	mov	x0, x20
    82b8:	d2800022 	mov	x2, #0x1                   	// #1
    82bc:	39001fe3 	strb	w3, [sp, #7]
    82c0:	17fffddb 	b	7a2c <fwp_write+0x9c>
    82c4:	aa1403e0 	mov	x0, x20
    82c8:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    82cc:	d28000c2 	mov	x2, #0x6                   	// #6
    82d0:	913ba021 	add	x1, x1, #0xee8
    82d4:	97ffecef 	bl	3690 <buf_put>
    82d8:	f9400260 	ldr	x0, [x19]
    82dc:	b40004c0 	cbz	x0, 8374 <fwp_write+0x9e4>
    82e0:	910123f5 	add	x21, sp, #0x48
    82e4:	91002276 	add	x22, x19, #0x8
    82e8:	f90143f7 	str	x23, [sp, #640]
    82ec:	d2800017 	mov	x23, #0x0                   	// #0
    82f0:	f90147f8 	str	x24, [sp, #648]
    82f4:	d0000038 	adrp	x24, e000 <fwp_main_thread+0x1470>
    82f8:	913bc318 	add	x24, x24, #0xef0
    82fc:	f9014bf9 	str	x25, [sp, #656]
    8300:	d0000039 	adrp	x25, e000 <fwp_main_thread+0x1470>
    8304:	913be339 	add	x25, x25, #0xef8
    8308:	f9014ffa 	str	x26, [sp, #664]
    830c:	14000005 	b	8320 <fwp_write+0x990>
    8310:	aa1903e1 	mov	x1, x25
    8314:	aa1403e0 	mov	x0, x20
    8318:	d2800042 	mov	x2, #0x2                   	// #2
    831c:	97ffecdd 	bl	3690 <buf_put>
    8320:	38776ac5 	ldrb	w5, [x22, x23]
    8324:	d2804003 	mov	x3, #0x200                 	// #512
    8328:	aa1803e4 	mov	x4, x24
    832c:	aa0303e1 	mov	x1, x3
    8330:	52800042 	mov	w2, #0x2                   	// #2
    8334:	aa1503e0 	mov	x0, x21
    8338:	910006f7 	add	x23, x23, #0x1
    833c:	97ffe935 	bl	2810 <__snprintf_chk@plt>
    8340:	aa1503e0 	mov	x0, x21
    8344:	97ffe8fb 	bl	2730 <strlen@plt>
    8348:	aa1503e1 	mov	x1, x21
    834c:	aa0003e2 	mov	x2, x0
    8350:	aa1403e0 	mov	x0, x20
    8354:	97ffeccf 	bl	3690 <buf_put>
    8358:	f9400260 	ldr	x0, [x19]
    835c:	eb17001f 	cmp	x0, x23
    8360:	54fffd88 	b.hi	8310 <fwp_write+0x980>  // b.pmore
    8364:	f94143f7 	ldr	x23, [sp, #640]
    8368:	f94147f8 	ldr	x24, [sp, #648]
    836c:	f9414bf9 	ldr	x25, [sp, #656]
    8370:	f9414ffa 	ldr	x26, [sp, #664]
    8374:	52800ba3 	mov	w3, #0x5d                  	// #93
    8378:	aa1403e0 	mov	x0, x20
    837c:	91001fe1 	add	x1, sp, #0x7
    8380:	d2800022 	mov	x2, #0x1                   	// #1
    8384:	39001fe3 	strb	w3, [sp, #7]
    8388:	17fffda9 	b	7a2c <fwp_write+0x9c>
    838c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8390:	17fffe44 	b	7ca0 <fwp_write+0x310>
    8394:	f10002ff 	cmp	x23, #0x0
    8398:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    839c:	71002c3f 	cmp	w1, #0xb
    83a0:	54ffebc0 	b.eq	8118 <fwp_write+0x788>  // b.none
    83a4:	aa1303e2 	mov	x2, x19
    83a8:	aa1703e1 	mov	x1, x23
    83ac:	aa1403e0 	mov	x0, x20
    83b0:	52800003 	mov	w3, #0x0                   	// #0
    83b4:	97fffd77 	bl	7990 <fwp_write>
    83b8:	17ffff6a 	b	8160 <fwp_write+0x7d0>
    83bc:	aa1403e0 	mov	x0, x20
    83c0:	91001fe1 	add	x1, sp, #0x7
    83c4:	52800fa3 	mov	w3, #0x7d                  	// #125
    83c8:	d2800022 	mov	x2, #0x1                   	// #1
    83cc:	17fffe38 	b	7cac <fwp_write+0x31c>
    83d0:	a9400281 	ldp	x1, x0, [x20]
    83d4:	91000800 	add	x0, x0, #0x2
    83d8:	8b160000 	add	x0, x0, x22
    83dc:	f9000680 	str	x0, [x20, #8]
    83e0:	3820683f 	strb	wzr, [x1, x0]
    83e4:	f9413bf5 	ldr	x21, [sp, #624]
    83e8:	f9413ff6 	ldr	x22, [sp, #632]
    83ec:	f94153fb 	ldr	x27, [sp, #672]
    83f0:	f94157fc 	ldr	x28, [sp, #680]
    83f4:	17fffd93 	b	7a40 <fwp_write+0xb0>
    83f8:	f9400f80 	ldr	x0, [x28, #24]
    83fc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8400:	aa1b03e0 	mov	x0, x27
    8404:	97ffe8cb 	bl	2730 <strlen@plt>
    8408:	aa1b03e1 	mov	x1, x27
    840c:	aa0003e2 	mov	x2, x0
    8410:	aa1403e0 	mov	x0, x20
    8414:	97ffec9f 	bl	3690 <buf_put>
    8418:	aa1903e1 	mov	x1, x25
    841c:	aa1403e0 	mov	x0, x20
    8420:	d2800062 	mov	x2, #0x3                   	// #3
    8424:	97ffec9b 	bl	3690 <buf_put>
    8428:	17fffe10 	b	7c68 <fwp_write+0x2d8>
    842c:	aa1a03e1 	mov	x1, x26
    8430:	aa1403e0 	mov	x0, x20
    8434:	d2800042 	mov	x2, #0x2                   	// #2
    8438:	97ffec96 	bl	3690 <buf_put>
    843c:	17fffe09 	b	7c60 <fwp_write+0x2d0>
    8440:	f9400660 	ldr	x0, [x19, #8]
    8444:	b4fffb00 	cbz	x0, 83a4 <fwp_write+0xa14>
    8448:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    844c:	913c4021 	add	x1, x1, #0xf10
    8450:	97ffe934 	bl	2920 <strcmp@plt>
    8454:	7100001f 	cmp	w0, #0x0
    8458:	1a9f07e0 	cset	w0, ne	// ne = any
    845c:	17ffff2f 	b	8118 <fwp_write+0x788>
    8460:	aa1403e0 	mov	x0, x20
    8464:	d2800042 	mov	x2, #0x2                   	// #2
    8468:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    846c:	913c2021 	add	x1, x1, #0xf08
    8470:	97ffec88 	bl	3690 <buf_put>
    8474:	91004261 	add	x1, x19, #0x10
    8478:	aa1403e0 	mov	x0, x20
    847c:	f9402382 	ldr	x2, [x28, #64]
    8480:	52800003 	mov	w3, #0x0                   	// #0
    8484:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8488:	97fffd42 	bl	7990 <fwp_write>
    848c:	17fffd9c 	b	7afc <fwp_write+0x16c>
    8490:	1e22c109 	fcvt	d9, s8
    8494:	910123f5 	add	x21, sp, #0x48
    8498:	52800033 	mov	w19, #0x1                   	// #1
    849c:	d503201f 	nop
    84a0:	1e604120 	fmov	d0, d9
    84a4:	2a1303e1 	mov	w1, w19
    84a8:	aa1503e0 	mov	x0, x21
    84ac:	97ffecd5 	bl	3800 <fwp_format_g.constprop.0>
    84b0:	aa1503e0 	mov	x0, x21
    84b4:	d2800001 	mov	x1, #0x0                   	// #0
    84b8:	97ffe926 	bl	2950 <strtof@plt>
    84bc:	1e202100 	fcmp	s8, s0
    84c0:	54ffdb60 	b.eq	802c <fwp_write+0x69c>  // b.none
    84c4:	11000673 	add	w19, w19, #0x1
    84c8:	71002a7f 	cmp	w19, #0xa
    84cc:	54fffea1 	b.ne	84a0 <fwp_write+0xb10>  // b.any
    84d0:	1e604120 	fmov	d0, d9
    84d4:	aa1503e0 	mov	x0, x21
    84d8:	52800121 	mov	w1, #0x9                   	// #9
    84dc:	97ffecc9 	bl	3800 <fwp_format_g.constprop.0>
    84e0:	17fffed3 	b	802c <fwp_write+0x69c>
    84e4:	d37ef6a1 	lsl	x1, x21, #2
    84e8:	b7f81563 	tbnz	x3, #63, 8794 <fwp_write+0xe04>
    84ec:	91002263 	add	x3, x19, #0x8
    84f0:	8b010061 	add	x1, x3, x1
    84f4:	b9400023 	ldr	w3, [x1]
    84f8:	7100081f 	cmp	w0, #0x2
    84fc:	2a0303e1 	mov	w1, w3
    8500:	93407c63 	sxtw	x3, w3
    8504:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8508:	17fffe5a 	b	7e70 <fwp_write+0x4e0>
    850c:	d37ffaa1 	lsl	x1, x21, #1
    8510:	b7f81363 	tbnz	x3, #63, 877c <fwp_write+0xdec>
    8514:	91002263 	add	x3, x19, #0x8
    8518:	8b010061 	add	x1, x3, x1
    851c:	79400021 	ldrh	w1, [x1]
    8520:	7100041f 	cmp	w0, #0x1
    8524:	93403c23 	sxth	x3, w1
    8528:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    852c:	17fffe51 	b	7e70 <fwp_write+0x4e0>
    8530:	52800443 	mov	w3, #0x22                  	// #34
    8534:	91001ff5 	add	x21, sp, #0x7
    8538:	91002273 	add	x19, x19, #0x8
    853c:	aa1503e1 	mov	x1, x21
    8540:	aa1403e0 	mov	x0, x20
    8544:	d2800022 	mov	x2, #0x1                   	// #1
    8548:	39001fe3 	strb	w3, [sp, #7]
    854c:	f90143f7 	str	x23, [sp, #640]
    8550:	8b160277 	add	x23, x19, x22
    8554:	f90147f8 	str	x24, [sp, #648]
    8558:	97ffec4e 	bl	3690 <buf_put>
    855c:	b4000696 	cbz	x22, 862c <fwp_write+0xc9c>
    8560:	d0000038 	adrp	x24, e000 <fwp_main_thread+0x1470>
    8564:	913ae318 	add	x24, x24, #0xeb8
    8568:	f9014bf9 	str	x25, [sp, #656]
    856c:	d0000039 	adrp	x25, e000 <fwp_main_thread+0x1470>
    8570:	913b6339 	add	x25, x25, #0xed8
    8574:	f9014ffa 	str	x26, [sp, #664]
    8578:	1400000d 	b	85ac <fwp_write+0xc1c>
    857c:	710024bf 	cmp	w5, #0x9
    8580:	54000460 	b.eq	860c <fwp_write+0xc7c>  // b.none
    8584:	710028bf 	cmp	w5, #0xa
    8588:	54000a61 	b.ne	86d4 <fwp_write+0xd44>  // b.any
    858c:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    8590:	aa1403e0 	mov	x0, x20
    8594:	913b2021 	add	x1, x1, #0xec8
    8598:	d2800042 	mov	x2, #0x2                   	// #2
    859c:	97ffec3d 	bl	3690 <buf_put>
    85a0:	91000673 	add	x19, x19, #0x1
    85a4:	eb17027f 	cmp	x19, x23
    85a8:	540003e0 	b.eq	8624 <fwp_write+0xc94>  // b.none
    85ac:	39400265 	ldrb	w5, [x19]
    85b0:	710034bf 	cmp	w5, #0xd
    85b4:	54000180 	b.eq	85e4 <fwp_write+0xc54>  // b.none
    85b8:	54fffe29 	b.ls	857c <fwp_write+0xbec>  // b.plast
    85bc:	710088bf 	cmp	w5, #0x22
    85c0:	540001c0 	b.eq	85f8 <fwp_write+0xc68>  // b.none
    85c4:	710170bf 	cmp	w5, #0x5c
    85c8:	54000741 	b.ne	86b0 <fwp_write+0xd20>  // b.any
    85cc:	aa1403e0 	mov	x0, x20
    85d0:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    85d4:	d2800042 	mov	x2, #0x2                   	// #2
    85d8:	913b0021 	add	x1, x1, #0xec0
    85dc:	97ffec2d 	bl	3690 <buf_put>
    85e0:	17fffff0 	b	85a0 <fwp_write+0xc10>
    85e4:	aa1903e1 	mov	x1, x25
    85e8:	aa1403e0 	mov	x0, x20
    85ec:	d2800042 	mov	x2, #0x2                   	// #2
    85f0:	97ffec28 	bl	3690 <buf_put>
    85f4:	17ffffeb 	b	85a0 <fwp_write+0xc10>
    85f8:	aa1803e1 	mov	x1, x24
    85fc:	aa1403e0 	mov	x0, x20
    8600:	d2800042 	mov	x2, #0x2                   	// #2
    8604:	97ffec23 	bl	3690 <buf_put>
    8608:	17ffffe6 	b	85a0 <fwp_write+0xc10>
    860c:	aa1403e0 	mov	x0, x20
    8610:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    8614:	d2800042 	mov	x2, #0x2                   	// #2
    8618:	913b4021 	add	x1, x1, #0xed0
    861c:	97ffec1d 	bl	3690 <buf_put>
    8620:	17ffffe0 	b	85a0 <fwp_write+0xc10>
    8624:	f9414bf9 	ldr	x25, [sp, #656]
    8628:	f9414ffa 	ldr	x26, [sp, #664]
    862c:	aa1503e1 	mov	x1, x21
    8630:	aa1403e0 	mov	x0, x20
    8634:	52800443 	mov	w3, #0x22                  	// #34
    8638:	17fffd9c 	b	7ca8 <fwp_write+0x318>
    863c:	7100103f 	cmp	w1, #0x4
    8640:	54ffeb21 	b.ne	83a4 <fwp_write+0xa14>  // b.any
    8644:	f94006e0 	ldr	x0, [x23, #8]
    8648:	d37ffc00 	lsr	x0, x0, #63
    864c:	17fffeb3 	b	8118 <fwp_write+0x788>
    8650:	710002ff 	cmp	w23, #0x0
    8654:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8658:	17fffeb0 	b	8118 <fwp_write+0x788>
    865c:	528005a1 	mov	w1, #0x2d                  	// #45
    8660:	eb0203e2 	negs	x2, x2
    8664:	da0303e3 	ngc	x3, x3
    8668:	910127e0 	add	x0, sp, #0x49
    866c:	910123f5 	add	x21, sp, #0x48
    8670:	390123e1 	strb	w1, [sp, #72]
    8674:	97ffe9eb 	bl	2e20 <fwp_fmt_u128>
    8678:	17fffe18 	b	7ed8 <fwp_write+0x548>
    867c:	d37ceea1 	lsl	x1, x21, #4
    8680:	b7f810a3 	tbnz	x3, #63, 8894 <fwp_write+0xf04>
    8684:	91002260 	add	x0, x19, #0x8
    8688:	8b010001 	add	x1, x0, x1
    868c:	17fffdf9 	b	7e70 <fwp_write+0x4e0>
    8690:	f9400a61 	ldr	x1, [x19, #16]
    8694:	8b010000 	add	x0, x0, x1
    8698:	f9400001 	ldr	x1, [x0]
    869c:	17fffdf5 	b	7e70 <fwp_write+0x4e0>
    86a0:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    86a4:	d2800042 	mov	x2, #0x2                   	// #2
    86a8:	91398021 	add	x1, x1, #0xe60
    86ac:	17fffed6 	b	8204 <fwp_write+0x874>
    86b0:	7101fcbf 	cmp	w5, #0x7f
    86b4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    86b8:	540000e9 	b.ls	86d4 <fwp_write+0xd44>  // b.plast
    86bc:	aa1503e1 	mov	x1, x21
    86c0:	aa1403e0 	mov	x0, x20
    86c4:	d2800022 	mov	x2, #0x1                   	// #1
    86c8:	39001fe5 	strb	w5, [sp, #7]
    86cc:	97ffebf1 	bl	3690 <buf_put>
    86d0:	17ffffb4 	b	85a0 <fwp_write+0xc10>
    86d4:	d2800203 	mov	x3, #0x10                  	// #16
    86d8:	d0000024 	adrp	x4, e000 <fwp_main_thread+0x1470>
    86dc:	aa0303e1 	mov	x1, x3
    86e0:	913b8084 	add	x4, x4, #0xee0
    86e4:	910123f6 	add	x22, sp, #0x48
    86e8:	52800042 	mov	w2, #0x2                   	// #2
    86ec:	aa1603e0 	mov	x0, x22
    86f0:	97ffe848 	bl	2810 <__snprintf_chk@plt>
    86f4:	aa1603e0 	mov	x0, x22
    86f8:	97ffe80e 	bl	2730 <strlen@plt>
    86fc:	aa1603e1 	mov	x1, x22
    8700:	aa0003e2 	mov	x2, x0
    8704:	aa1403e0 	mov	x0, x20
    8708:	97ffebe2 	bl	3690 <buf_put>
    870c:	17ffffa5 	b	85a0 <fwp_write+0xc10>
    8710:	1e604100 	fmov	d0, d8
    8714:	aa1503e0 	mov	x0, x21
    8718:	52800221 	mov	w1, #0x11                  	// #17
    871c:	97ffec39 	bl	3800 <fwp_format_g.constprop.0>
    8720:	17fffe43 	b	802c <fwp_write+0x69c>
    8724:	b9401040 	ldr	w0, [x2, #16]
    8728:	350003c0 	cbnz	w0, 87a0 <fwp_write+0xe10>
    872c:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    8730:	f947f400 	ldr	x0, [x0, #4072]
    8734:	f94127e2 	ldr	x2, [sp, #584]
    8738:	f9400001 	ldr	x1, [x0]
    873c:	eb010042 	subs	x2, x2, x1
    8740:	d2800001 	mov	x1, #0x0                   	// #0
    8744:	54ffd721 	b.ne	8228 <fwp_write+0x898>  // b.any
    8748:	f9413bf5 	ldr	x21, [sp, #624]
    874c:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    8750:	f9413ff6 	ldr	x22, [sp, #632]
    8754:	aa1403e0 	mov	x0, x20
    8758:	f94143f7 	ldr	x23, [sp, #640]
    875c:	913cc021 	add	x1, x1, #0xf30
    8760:	f94147f8 	ldr	x24, [sp, #648]
    8764:	d2800042 	mov	x2, #0x2                   	// #2
    8768:	17fffd0e 	b	7ba0 <fwp_write+0x210>
    876c:	d0000021 	adrp	x1, e000 <fwp_main_thread+0x1470>
    8770:	d2800042 	mov	x2, #0x2                   	// #2
    8774:	9139a021 	add	x1, x1, #0xe68
    8778:	17fffea3 	b	8204 <fwp_write+0x874>
    877c:	f9400a63 	ldr	x3, [x19, #16]
    8780:	8b030021 	add	x1, x1, x3
    8784:	17ffff66 	b	851c <fwp_write+0xb8c>
    8788:	f9400a61 	ldr	x1, [x19, #16]
    878c:	8b0102a1 	add	x1, x21, x1
    8790:	17fffdb3 	b	7e5c <fwp_write+0x4cc>
    8794:	f9400a63 	ldr	x3, [x19, #16]
    8798:	8b030021 	add	x1, x1, x3
    879c:	17ffff56 	b	84f4 <fwp_write+0xb64>
    87a0:	b9404840 	ldr	w0, [x2, #72]
    87a4:	91001ff5 	add	x21, sp, #0x7
    87a8:	34ffa360 	cbz	w0, 7c14 <fwp_write+0x284>
    87ac:	52800503 	mov	w3, #0x28                  	// #40
    87b0:	aa1403e0 	mov	x0, x20
    87b4:	aa1503e1 	mov	x1, x21
    87b8:	d2800022 	mov	x2, #0x1                   	// #1
    87bc:	39001fe3 	strb	w3, [sp, #7]
    87c0:	97ffebb4 	bl	3690 <buf_put>
    87c4:	b9401380 	ldr	w0, [x28, #16]
    87c8:	52800038 	mov	w24, #0x1                   	// #1
    87cc:	7100001f 	cmp	w0, #0x0
    87d0:	54ffa36c 	b.gt	7c3c <fwp_write+0x2ac>
    87d4:	17fffd32 	b	7c9c <fwp_write+0x30c>
    87d8:	f9014bf9 	str	x25, [sp, #656]
    87dc:	d0000139 	adrp	x25, 2e000 <__FRAME_END__+0x1d3e8>
    87e0:	f9014ffa 	str	x26, [sp, #664]
    87e4:	f9400676 	ldr	x22, [x19, #8]
    87e8:	910ac333 	add	x19, x25, #0x2b0
    87ec:	91002273 	add	x19, x19, #0x8
    87f0:	937ffed8 	asr	x24, x22, #63
    87f4:	aa1802c0 	orr	x0, x22, x24
    87f8:	b5000320 	cbnz	x0, 885c <fwp_write+0xecc>
    87fc:	110006b5 	add	w21, w21, #0x1
    8800:	710016bf 	cmp	w21, #0x5
    8804:	54ffffc1 	b.ne	87fc <fwp_write+0xe6c>  // b.any
    8808:	b7f80578 	tbnz	x24, #63, 88b4 <fwp_write+0xf24>
    880c:	910023f3 	add	x19, sp, #0x8
    8810:	aa1603e2 	mov	x2, x22
    8814:	aa1303e0 	mov	x0, x19
    8818:	d2800003 	mov	x3, #0x0                   	// #0
    881c:	97ffe981 	bl	2e20 <fwp_fmt_u128>
    8820:	910123f5 	add	x21, sp, #0x48
    8824:	d0000023 	adrp	x3, e000 <fwp_main_thread+0x1470>
    8828:	aa1303e4 	mov	x4, x19
    882c:	aa1503e0 	mov	x0, x21
    8830:	913ca063 	add	x3, x3, #0xf28
    8834:	d2804002 	mov	x2, #0x200                 	// #512
    8838:	52800041 	mov	w1, #0x2                   	// #2
    883c:	97ffe7c1 	bl	2740 <__sprintf_chk@plt>
    8840:	aa1503e0 	mov	x0, x21
    8844:	97ffe7bb 	bl	2730 <strlen@plt>
    8848:	aa1503e1 	mov	x1, x21
    884c:	aa0003e2 	mov	x2, x0
    8850:	aa1403e0 	mov	x0, x20
    8854:	97ffeb8f 	bl	3690 <buf_put>
    8858:	17fffe47 	b	8174 <fwp_write+0x7e4>
    885c:	f9400277 	ldr	x23, [x19]
    8860:	aa1603e0 	mov	x0, x22
    8864:	aa1803e1 	mov	x1, x24
    8868:	aa1703e2 	mov	x2, x23
    886c:	937ffefa 	asr	x26, x23, #63
    8870:	aa1a03e3 	mov	x3, x26
    8874:	9400170b 	bl	e4a0 <__modti3>
    8878:	aa010000 	orr	x0, x0, x1
    887c:	b40002c0 	cbz	x0, 88d4 <fwp_write+0xf44>
    8880:	110006b5 	add	w21, w21, #0x1
    8884:	91004273 	add	x19, x19, #0x10
    8888:	710016bf 	cmp	w21, #0x5
    888c:	54fffe81 	b.ne	885c <fwp_write+0xecc>  // b.any
    8890:	17ffffde 	b	8808 <fwp_write+0xe78>
    8894:	f9400a60 	ldr	x0, [x19, #16]
    8898:	8b000021 	add	x1, x1, x0
    889c:	17fffd75 	b	7e70 <fwp_write+0x4e0>
    88a0:	528c29c0 	mov	w0, #0x614e                	// #24910
    88a4:	910123f5 	add	x21, sp, #0x48
    88a8:	72a009c0 	movk	w0, #0x4e, lsl #16
    88ac:	b9004be0 	str	w0, [sp, #72]
    88b0:	17fffda2 	b	7f38 <fwp_write+0x5a8>
    88b4:	528005a1 	mov	w1, #0x2d                  	// #45
    88b8:	eb1603e2 	negs	x2, x22
    88bc:	da1803e3 	ngc	x3, x24
    88c0:	910027e0 	add	x0, sp, #0x9
    88c4:	910023f3 	add	x19, sp, #0x8
    88c8:	390023e1 	strb	w1, [sp, #8]
    88cc:	97ffe955 	bl	2e20 <fwp_fmt_u128>
    88d0:	17ffffd4 	b	8820 <fwp_write+0xe90>
    88d4:	aa1703e2 	mov	x2, x23
    88d8:	aa1a03e3 	mov	x3, x26
    88dc:	aa1603e0 	mov	x0, x22
    88e0:	aa1803e1 	mov	x1, x24
    88e4:	9400160f 	bl	e120 <__divti3>
    88e8:	aa0003e2 	mov	x2, x0
    88ec:	aa0103e3 	mov	x3, x1
    88f0:	b7f80201 	tbnz	x1, #63, 8930 <fwp_write+0xfa0>
    88f4:	910023f3 	add	x19, sp, #0x8
    88f8:	aa1303e0 	mov	x0, x19
    88fc:	97ffe949 	bl	2e20 <fwp_fmt_u128>
    8900:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8904:	910ac339 	add	x25, x25, #0x2b0
    8908:	910123f5 	add	x21, sp, #0x48
    890c:	aa1303e4 	mov	x4, x19
    8910:	aa1503e0 	mov	x0, x21
    8914:	d0000023 	adrp	x3, e000 <fwp_main_thread+0x1470>
    8918:	f8616b25 	ldr	x5, [x25, x1]
    891c:	913c8063 	add	x3, x3, #0xf20
    8920:	d2804002 	mov	x2, #0x200                 	// #512
    8924:	52800041 	mov	w1, #0x2                   	// #2
    8928:	97ffe786 	bl	2740 <__sprintf_chk@plt>
    892c:	17ffffc5 	b	8840 <fwp_write+0xeb0>
    8930:	528005a4 	mov	w4, #0x2d                  	// #45
    8934:	eb0003e2 	negs	x2, x0
    8938:	da0103e3 	ngc	x3, x1
    893c:	910027e0 	add	x0, sp, #0x9
    8940:	910023f3 	add	x19, sp, #0x8
    8944:	390023e4 	strb	w4, [sp, #8]
    8948:	97ffe936 	bl	2e20 <fwp_fmt_u128>
    894c:	17ffffed 	b	8900 <fwp_write+0xf70>
    8950:	f9013bf5 	str	x21, [sp, #624]
    8954:	f9013ff6 	str	x22, [sp, #632]
    8958:	f90143f7 	str	x23, [sp, #640]
    895c:	f90147f8 	str	x24, [sp, #648]
    8960:	f9014bf9 	str	x25, [sp, #656]
    8964:	f9014ffa 	str	x26, [sp, #664]
    8968:	f90153fb 	str	x27, [sp, #672]
    896c:	f90157fc 	str	x28, [sp, #680]
    8970:	fd015be8 	str	d8, [sp, #688]
    8974:	fd015fe9 	str	d9, [sp, #696]
    8978:	97ffe7ca 	bl	28a0 <__stack_chk_fail@plt>
    897c:	d503201f 	nop

0000000000008980 <fwp_hof0.constprop.0>:
    8980:	d105c3ff 	sub	sp, sp, #0x170
    8984:	f0000122 	adrp	x2, 2f000 <fwp_fn_table+0xc90>
    8988:	f947f442 	ldr	x2, [x2, #4072]
    898c:	a9117bfd 	stp	x29, x30, [sp, #272]
    8990:	910443fd 	add	x29, sp, #0x110
    8994:	a91673fb 	stp	x27, x28, [sp, #352]
    8998:	aa0003fc 	mov	x28, x0
    899c:	f9400040 	ldr	x0, [x2]
    89a0:	f90087e0 	str	x0, [sp, #264]
    89a4:	d2800000 	mov	x0, #0x0                   	// #0
    89a8:	b4003701 	cbz	x1, 9088 <fwp_hof0.constprop.0+0x708>
    89ac:	a91253f3 	stp	x19, x20, [sp, #288]
    89b0:	90000153 	adrp	x19, 30000 <__data_start>
    89b4:	91004273 	add	x19, x19, #0x10
    89b8:	910223e0 	add	x0, sp, #0x88
    89bc:	90000154 	adrp	x20, 30000 <__data_start>
    89c0:	91008273 	add	x19, x19, #0x20
    89c4:	a9135bf5 	stp	x21, x22, [sp, #304]
    89c8:	b0000416 	adrp	x22, 89000 <fwp_root_context+0xbb0>
    89cc:	9118c2db 	add	x27, x22, #0x630
    89d0:	a91463f7 	stp	x23, x24, [sp, #320]
    89d4:	91014297 	add	x23, x20, #0x50
    89d8:	a9156bf9 	stp	x25, x26, [sp, #336]
    89dc:	aa1c03fa 	mov	x26, x28
    89e0:	d0fffff8 	adrp	x24, 6000 <fwp_owned_entry173+0xac>
    89e4:	f90003e0 	str	x0, [sp]
    89e8:	910243e0 	add	x0, sp, #0x90
    89ec:	f90007e0 	str	x0, [sp, #8]
    89f0:	f9000fe1 	str	x1, [sp, #24]
    89f4:	f949ef64 	ldr	x4, [x27, #5080]
    89f8:	f949db61 	ldr	x1, [x27, #5040]
    89fc:	d370bc84 	lsl	x4, x4, #16
    8a00:	cb010343 	sub	x3, x26, x1
    8a04:	eb04007f 	cmp	x3, x4
    8a08:	54000442 	b.cs	8a90 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    8a0c:	d350fc60 	lsr	x0, x3, #16
    8a10:	f949ff66 	ldr	x6, [x27, #5112]
    8a14:	8b000800 	add	x0, x0, x0, lsl #2
    8a18:	d37df002 	lsl	x2, x0, #3
    8a1c:	8b0200c5 	add	x5, x6, x2
    8a20:	f94010a0 	ldr	x0, [x5, #32]
    8a24:	b4000360 	cbz	x0, 8a90 <fwp_hof0.constprop.0+0x110>
    8a28:	386268c2 	ldrb	w2, [x6, x2]
    8a2c:	7100085f 	cmp	w2, #0x2
    8a30:	54000e40 	b.eq	8bf8 <fwp_hof0.constprop.0+0x278>  // b.none
    8a34:	7100045f 	cmp	w2, #0x1
    8a38:	540002c1 	b.ne	8a90 <fwp_hof0.constprop.0+0x110>  // b.any
    8a3c:	92403c62 	and	x2, x3, #0xffff
    8a40:	29430ca6 	ldp	w6, w3, [x5, #24]
    8a44:	9b067c42 	mul	x2, x2, x6
    8a48:	d360fc42 	lsr	x2, x2, #32
    8a4c:	eb03005f 	cmp	x2, x3
    8a50:	54000202 	b.cs	8a90 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    8a54:	8b020000 	add	x0, x0, x2
    8a58:	39400002 	ldrb	w2, [x0]
    8a5c:	340001a2 	cbz	w2, 8a90 <fwp_hof0.constprop.0+0x110>
    8a60:	91014281 	add	x1, x20, #0x50
    8a64:	b9413023 	ldr	w3, [x1, #304]
    8a68:	35002003 	cbnz	w3, 8e68 <fwp_hof0.constprop.0+0x4e8>
    8a6c:	7103f45f 	cmp	w2, #0xfd
    8a70:	54005028 	b.hi	9474 <fwp_hof0.constprop.0+0xaf4>  // b.pmore
    8a74:	9118c2c1 	add	x1, x22, #0x630
    8a78:	11000442 	add	w2, w2, #0x1
    8a7c:	39000002 	strb	w2, [x0]
    8a80:	aa0103e0 	mov	x0, x1
    8a84:	f949d821 	ldr	x1, [x1, #5040]
    8a88:	f949ec04 	ldr	x4, [x0, #5080]
    8a8c:	d370bc84 	lsl	x4, x4, #16
    8a90:	91208319 	add	x25, x24, #0x820
    8a94:	a9026ffa 	stp	x26, x27, [sp, #32]
    8a98:	aa1703fb 	mov	x27, x23
    8a9c:	d28018c0 	mov	x0, #0xc6                  	// #198
    8aa0:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    8aa4:	f9000be0 	str	x0, [sp, #16]
    8aa8:	f941cb60 	ldr	x0, [x27, #912]
    8aac:	a90967e0 	stp	x0, x25, [sp, #144]
    8ab0:	12800002 	mov	w2, #0xffffffff            	// #-1
    8ab4:	f94003e0 	ldr	x0, [sp]
    8ab8:	f90053e0 	str	x0, [sp, #160]
    8abc:	f94007e0 	ldr	x0, [sp, #8]
    8ac0:	cb010261 	sub	x1, x19, x1
    8ac4:	b9008be2 	str	w2, [sp, #136]
    8ac8:	f901cb60 	str	x0, [x27, #912]
    8acc:	eb04003f 	cmp	x1, x4
    8ad0:	540007c2 	b.cs	8bc8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8ad4:	9118c2c2 	add	x2, x22, #0x630
    8ad8:	d350fc20 	lsr	x0, x1, #16
    8adc:	8b000800 	add	x0, x0, x0, lsl #2
    8ae0:	f949fc43 	ldr	x3, [x2, #5112]
    8ae4:	d37df000 	lsl	x0, x0, #3
    8ae8:	8b000062 	add	x2, x3, x0
    8aec:	f9401055 	ldr	x21, [x2, #32]
    8af0:	b40006d5 	cbz	x21, 8bc8 <fwp_hof0.constprop.0+0x248>
    8af4:	38606860 	ldrb	w0, [x3, x0]
    8af8:	7100081f 	cmp	w0, #0x2
    8afc:	54000840 	b.eq	8c04 <fwp_hof0.constprop.0+0x284>  // b.none
    8b00:	7100041f 	cmp	w0, #0x1
    8b04:	54000621 	b.ne	8bc8 <fwp_hof0.constprop.0+0x248>  // b.any
    8b08:	29430c44 	ldp	w4, w3, [x2, #24]
    8b0c:	92403c20 	and	x0, x1, #0xffff
    8b10:	9b047c00 	mul	x0, x0, x4
    8b14:	d360fc00 	lsr	x0, x0, #32
    8b18:	eb03001f 	cmp	x0, x3
    8b1c:	540002e2 	b.cs	8b78 <fwp_hof0.constprop.0+0x1f8>  // b.hs, b.nlast
    8b20:	8b0002a0 	add	x0, x21, x0
    8b24:	39400003 	ldrb	w3, [x0]
    8b28:	34000283 	cbz	w3, 8b78 <fwp_hof0.constprop.0+0x1f8>
    8b2c:	91014281 	add	x1, x20, #0x50
    8b30:	b9413022 	ldr	w2, [x1, #304]
    8b34:	35001a22 	cbnz	w2, 8e78 <fwp_hof0.constprop.0+0x4f8>
    8b38:	7103f47f 	cmp	w3, #0xfd
    8b3c:	54004a88 	b.hi	948c <fwp_hof0.constprop.0+0xb0c>  // b.pmore
    8b40:	11000463 	add	w3, w3, #0x1
    8b44:	39000003 	strb	w3, [x0]
    8b48:	9118c2c0 	add	x0, x22, #0x630
    8b4c:	f949d801 	ldr	x1, [x0, #5040]
    8b50:	f949ec02 	ldr	x2, [x0, #5080]
    8b54:	cb010261 	sub	x1, x19, x1
    8b58:	eb02403f 	cmp	x1, x2, lsl #16
    8b5c:	54000362 	b.cs	8bc8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8b60:	f949fc00 	ldr	x0, [x0, #5112]
    8b64:	d350fc22 	lsr	x2, x1, #16
    8b68:	8b020842 	add	x2, x2, x2, lsl #2
    8b6c:	8b020c02 	add	x2, x0, x2, lsl #3
    8b70:	f9401055 	ldr	x21, [x2, #32]
    8b74:	b40002b5 	cbz	x21, 8bc8 <fwp_hof0.constprop.0+0x248>
    8b78:	39400040 	ldrb	w0, [x2]
    8b7c:	7100081f 	cmp	w0, #0x2
    8b80:	54000600 	b.eq	8c40 <fwp_hof0.constprop.0+0x2c0>  // b.none
    8b84:	7100041f 	cmp	w0, #0x1
    8b88:	54000201 	b.ne	8bc8 <fwp_hof0.constprop.0+0x248>  // b.any
    8b8c:	29430043 	ldp	w3, w0, [x2, #24]
    8b90:	92403c21 	and	x1, x1, #0xffff
    8b94:	9b037c21 	mul	x1, x1, x3
    8b98:	d360fc21 	lsr	x1, x1, #32
    8b9c:	eb00003f 	cmp	x1, x0
    8ba0:	54000142 	b.cs	8bc8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8ba4:	8b0102b5 	add	x21, x21, x1
    8ba8:	394002a0 	ldrb	w0, [x21]
    8bac:	340000e0 	cbz	w0, 8bc8 <fwp_hof0.constprop.0+0x248>
    8bb0:	7100041f 	cmp	w0, #0x1
    8bb4:	54000300 	b.eq	8c14 <fwp_hof0.constprop.0+0x294>  // b.none
    8bb8:	7103fc1f 	cmp	w0, #0xff
    8bbc:	540046c0 	b.eq	9494 <fwp_hof0.constprop.0+0xb14>  // b.none
    8bc0:	51000400 	sub	w0, w0, #0x1
    8bc4:	390002a0 	strb	w0, [x21]
    8bc8:	b4003b3a 	cbz	x26, 932c <fwp_hof0.constprop.0+0x9ac>
    8bcc:	aa1a03e0 	mov	x0, x26
    8bd0:	d2800001 	mov	x1, #0x0                   	// #0
    8bd4:	d503201f 	nop
    8bd8:	f9400800 	ldr	x0, [x0, #16]
    8bdc:	91000421 	add	x1, x1, #0x1
    8be0:	b5ffffc0 	cbnz	x0, 8bd8 <fwp_hof0.constprop.0+0x258>
    8be4:	eb1c003f 	cmp	x1, x28
    8be8:	54000329 	b.ls	8c4c <fwp_hof0.constprop.0+0x2cc>  // b.plast
    8bec:	d0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    8bf0:	913d0000 	add	x0, x0, #0xf40
    8bf4:	97ffedd0 	bl	4334 <fwp_trap>
    8bf8:	72003c7f 	tst	w3, #0xffff
    8bfc:	54fff4a1 	b.ne	8a90 <fwp_hof0.constprop.0+0x110>  // b.any
    8c00:	17ffff96 	b	8a58 <fwp_hof0.constprop.0+0xd8>
    8c04:	72003c3f 	tst	w1, #0xffff
    8c08:	54fffb81 	b.ne	8b78 <fwp_hof0.constprop.0+0x1f8>  // b.any
    8c0c:	aa1503e0 	mov	x0, x21
    8c10:	17ffffc5 	b	8b24 <fwp_hof0.constprop.0+0x1a4>
    8c14:	d53bd040 	mrs	x0, tpidr_el0
    8c18:	91400000 	add	x0, x0, #0x0, lsl #12
    8c1c:	91004000 	add	x0, x0, #0x10
    8c20:	f9400000 	ldr	x0, [x0]
    8c24:	b4000080 	cbz	x0, 8c34 <fwp_hof0.constprop.0+0x2b4>
    8c28:	aa1303e1 	mov	x1, x19
    8c2c:	97ffef3d 	bl	4920 <fwp_closure_drop_push>
    8c30:	17ffffe6 	b	8bc8 <fwp_hof0.constprop.0+0x248>
    8c34:	aa1303e0 	mov	x0, x19
    8c38:	97ffef7f 	bl	4a34 <fwp_closure_drop.part.0>
    8c3c:	17ffffe3 	b	8bc8 <fwp_hof0.constprop.0+0x248>
    8c40:	72003c3f 	tst	w1, #0xffff
    8c44:	54fffc21 	b.ne	8bc8 <fwp_hof0.constprop.0+0x248>  // b.any
    8c48:	17ffffd8 	b	8ba8 <fwp_hof0.constprop.0+0x228>
    8c4c:	aa0103f7 	mov	x23, x1
    8c50:	91014295 	add	x21, x20, #0x50
    8c54:	b943c6a0 	ldr	w0, [x21, #964]
    8c58:	34002300 	cbz	w0, 90b8 <fwp_hof0.constprop.0+0x738>
    8c5c:	91014280 	add	x0, x20, #0x50
    8c60:	f9409003 	ldr	x3, [x0, #288]
    8c64:	f940b015 	ldr	x21, [x0, #352]
    8c68:	eb0302bf 	cmp	x21, x3
    8c6c:	540006ca 	b.ge	8d44 <fwp_hof0.constprop.0+0x3c4>  // b.tcont
    8c70:	f9404401 	ldr	x1, [x0, #136]
    8c74:	8b1506a0 	add	x0, x21, x21, lsl #1
    8c78:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8c7c:	8b000aa0 	add	x0, x21, x0, lsl #2
    8c80:	8b000c20 	add	x0, x1, x0, lsl #3
    8c84:	d503201f 	nop
    8c88:	b9400401 	ldr	w1, [x0, #4]
    8c8c:	35000081 	cbnz	w1, 8c9c <fwp_hof0.constprop.0+0x31c>
    8c90:	b9400001 	ldr	w1, [x0]
    8c94:	6b02003f 	cmp	w1, w2
    8c98:	54000569 	b.ls	8d44 <fwp_hof0.constprop.0+0x3c4>  // b.plast
    8c9c:	910006b5 	add	x21, x21, #0x1
    8ca0:	9101a000 	add	x0, x0, #0x68
    8ca4:	eb0302bf 	cmp	x21, x3
    8ca8:	54ffff01 	b.ne	8c88 <fwp_hof0.constprop.0+0x308>  // b.any
    8cac:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8cb0:	eb00007f 	cmp	x3, x0
    8cb4:	54003dac 	b.gt	9468 <fwp_hof0.constprop.0+0xae8>
    8cb8:	91014280 	add	x0, x20, #0x50
    8cbc:	f9408801 	ldr	x1, [x0, #272]
    8cc0:	f9404408 	ldr	x8, [x0, #136]
    8cc4:	eb03003f 	cmp	x1, x3
    8cc8:	54000261 	b.ne	8d14 <fwp_hof0.constprop.0+0x394>  // b.any
    8ccc:	b40048e3 	cbz	x3, 95e8 <fwp_hof0.constprop.0+0xc68>
    8cd0:	d37ff864 	lsl	x4, x3, #1
    8cd4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8cd8:	eb00009f 	cmp	x4, x0
    8cdc:	9a80d084 	csel	x4, x4, x0, le
    8ce0:	8b040481 	add	x1, x4, x4, lsl #1
    8ce4:	8b010881 	add	x1, x4, x1, lsl #2
    8ce8:	d37df021 	lsl	x1, x1, #3
    8cec:	aa0803e0 	mov	x0, x8
    8cf0:	52800002 	mov	w2, #0x0                   	// #0
    8cf4:	a9030fe4 	stp	x4, x3, [sp, #48]
    8cf8:	97ffecf3 	bl	40c4 <ad_raw_realloc>
    8cfc:	aa0003e8 	mov	x8, x0
    8d00:	a9430fe4 	ldp	x4, x3, [sp, #48]
    8d04:	b4007020 	cbz	x0, 9b08 <fwp_hof0.constprop.0+0x1188>
    8d08:	91014280 	add	x0, x20, #0x50
    8d0c:	f9004408 	str	x8, [x0, #136]
    8d10:	f9008804 	str	x4, [x0, #272]
    8d14:	8b030460 	add	x0, x3, x3, lsl #1
    8d18:	91014281 	add	x1, x20, #0x50
    8d1c:	4f000400 	movi	v0.4s, #0x0
    8d20:	91000462 	add	x2, x3, #0x1
    8d24:	8b000860 	add	x0, x3, x0, lsl #2
    8d28:	f9009022 	str	x2, [x1, #288]
    8d2c:	8b000d00 	add	x0, x8, x0, lsl #3
    8d30:	ad000000 	stp	q0, q0, [x0]
    8d34:	ad010000 	stp	q0, q0, [x0, #32]
    8d38:	ad020000 	stp	q0, q0, [x0, #64]
    8d3c:	f900301f 	str	xzr, [x0, #96]
    8d40:	14000005 	b	8d54 <fwp_hof0.constprop.0+0x3d4>
    8d44:	eb0302bf 	cmp	x21, x3
    8d48:	54fffb20 	b.eq	8cac <fwp_hof0.constprop.0+0x32c>  // b.none
    8d4c:	91014280 	add	x0, x20, #0x50
    8d50:	f9404408 	ldr	x8, [x0, #136]
    8d54:	8b1506a3 	add	x3, x21, x21, lsl #1
    8d58:	d0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    8d5c:	912c8000 	add	x0, x0, #0xb20
    8d60:	8b030aa3 	add	x3, x21, x3, lsl #2
    8d64:	8b030d03 	add	x3, x8, x3, lsl #3
    8d68:	a90323e3 	stp	x3, x8, [sp, #48]
    8d6c:	f900307f 	str	xzr, [x3, #96]
    8d70:	97ffe730 	bl	2a30 <getenv@plt>
    8d74:	a94323e3 	ldp	x3, x8, [sp, #48]
    8d78:	b4000080 	cbz	x0, 8d88 <fwp_hof0.constprop.0+0x408>
    8d7c:	39400001 	ldrb	w1, [x0]
    8d80:	7100c03f 	cmp	w1, #0x30
    8d84:	54000820 	b.eq	8e88 <fwp_hof0.constprop.0+0x508>  // b.none
    8d88:	91014280 	add	x0, x20, #0x50
    8d8c:	f9408401 	ldr	x1, [x0, #264]
    8d90:	b50034e1 	cbnz	x1, 942c <fwp_hof0.constprop.0+0xaac>
    8d94:	91014280 	add	x0, x20, #0x50
    8d98:	2f000400 	mvni	v0.2s, #0x0
    8d9c:	b9400067 	ldr	w7, [x3]
    8da0:	910006a9 	add	x9, x21, #0x1
    8da4:	52800022 	mov	w2, #0x1                   	// #1
    8da8:	a900dc77 	stp	x23, x23, [x3, #8]
    8dac:	110004e7 	add	w7, w7, #0x1
    8db0:	f941c801 	ldr	x1, [x0, #912]
    8db4:	29000867 	stp	w7, w2, [x3]
    8db8:	f900287f 	str	xzr, [x3, #80]
    8dbc:	f900b009 	str	x9, [x0, #352]
    8dc0:	fd002c60 	str	d0, [x3, #88]
    8dc4:	b40032e1 	cbz	x1, 9420 <fwp_hof0.constprop.0+0xaa0>
    8dc8:	91208304 	add	x4, x24, #0x820
    8dcc:	14000003 	b	8dd8 <fwp_hof0.constprop.0+0x458>
    8dd0:	f9400021 	ldr	x1, [x1]
    8dd4:	b4003261 	cbz	x1, 9420 <fwp_hof0.constprop.0+0xaa0>
    8dd8:	f9400420 	ldr	x0, [x1, #8]
    8ddc:	eb04001f 	cmp	x0, x4
    8de0:	54ffff81 	b.ne	8dd0 <fwp_hof0.constprop.0+0x450>  // b.any
    8de4:	f9400820 	ldr	x0, [x1, #16]
    8de8:	2a1503e2 	mov	w2, w21
    8dec:	b9400001 	ldr	w1, [x0]
    8df0:	f9002860 	str	x0, [x3, #80]
    8df4:	b9005c61 	str	w1, [x3, #92]
    8df8:	37f80081 	tbnz	w1, #31, 8e08 <fwp_hof0.constprop.0+0x488>
    8dfc:	52800d03 	mov	w3, #0x68                  	// #104
    8e00:	9b232021 	smaddl	x1, w1, w3, x8
    8e04:	b9005835 	str	w21, [x1, #88]
    8e08:	b9000002 	str	w2, [x0]
    8e0c:	aa1a03e0 	mov	x0, x26
    8e10:	d2800002 	mov	x2, #0x0                   	// #0
    8e14:	b400161a 	cbz	x26, 90d4 <fwp_hof0.constprop.0+0x754>
    8e18:	f9400800 	ldr	x0, [x0, #16]
    8e1c:	91000442 	add	x2, x2, #0x1
    8e20:	b5ffffc0 	cbnz	x0, 8e18 <fwp_hof0.constprop.0+0x498>
    8e24:	aa1a03e1 	mov	x1, x26
    8e28:	f9400821 	ldr	x1, [x1, #16]
    8e2c:	91000400 	add	x0, x0, #0x1
    8e30:	b5ffffc1 	cbnz	x1, 8e28 <fwp_hof0.constprop.0+0x4a8>
    8e34:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8e38:	eb01001f 	cmp	x0, x1
    8e3c:	54000108 	b.hi	8e5c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8e40:	f100005f 	cmp	x2, #0x0
    8e44:	5400148d 	b.le	90d4 <fwp_hof0.constprop.0+0x754>
    8e48:	eb00005f 	cmp	x2, x0
    8e4c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8e50:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8e54:	eb0102ff 	cmp	x23, x1
    8e58:	540026e9 	b.ls	9334 <fwp_hof0.constprop.0+0x9b4>  // b.plast
    8e5c:	d0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    8e60:	91390000 	add	x0, x0, #0xe40
    8e64:	97ffed34 	bl	4334 <fwp_trap>
    8e68:	f940ac23 	ldr	x3, [x1, #344]
    8e6c:	91000463 	add	x3, x3, #0x1
    8e70:	f900ac23 	str	x3, [x1, #344]
    8e74:	17fffefe 	b	8a6c <fwp_hof0.constprop.0+0xec>
    8e78:	f940ac22 	ldr	x2, [x1, #344]
    8e7c:	91000442 	add	x2, x2, #0x1
    8e80:	f900ac22 	str	x2, [x1, #344]
    8e84:	17ffff2d 	b	8b38 <fwp_hof0.constprop.0+0x1b8>
    8e88:	39400400 	ldrb	w0, [x0, #1]
    8e8c:	34fff840 	cbz	w0, 8d94 <fwp_hof0.constprop.0+0x414>
    8e90:	17ffffbe 	b	8d88 <fwp_hof0.constprop.0+0x408>
    8e94:	f9401be0 	ldr	x0, [sp, #48]
    8e98:	d0000122 	adrp	x2, 2e000 <__FRAME_END__+0x1d3e8>
    8e9c:	910ac042 	add	x2, x2, #0x2b0
    8ea0:	aa1a03e1 	mov	x1, x26
    8ea4:	91014042 	add	x2, x2, #0x50
    8ea8:	52800023 	mov	w3, #0x1                   	// #1
    8eac:	aa1a03f5 	mov	x21, x26
    8eb0:	aa1b03f7 	mov	x23, x27
    8eb4:	a9426ffa 	ldp	x26, x27, [sp, #32]
    8eb8:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    8ebc:	f9006bff 	str	xzr, [sp, #208]
    8ec0:	97fffab4 	bl	7990 <fwp_write>
    8ec4:	a94c0be3 	ldp	x3, x2, [sp, #192]
    8ec8:	d0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    8ecc:	91220000 	add	x0, x0, #0x880
    8ed0:	f100007f 	cmp	x3, #0x0
    8ed4:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    8ed8:	b100285f 	cmn	x2, #0xa
    8edc:	54008fa8 	b.hi	a0d0 <fwp_hof0.constprop.0+0x1750>  // b.pmore
    8ee0:	91002440 	add	x0, x2, #0x9
    8ee4:	52800021 	mov	w1, #0x1                   	// #1
    8ee8:	f9000be2 	str	x2, [sp, #16]
    8eec:	f90013e3 	str	x3, [sp, #32]
    8ef0:	97fff088 	bl	5110 <fwp_heap_alloc>
    8ef4:	f94013e3 	ldr	x3, [sp, #32]
    8ef8:	aa0003f9 	mov	x25, x0
    8efc:	f9400be2 	ldr	x2, [sp, #16]
    8f00:	aa0303e1 	mov	x1, x3
    8f04:	aa0003e3 	mov	x3, x0
    8f08:	f90013e2 	str	x2, [sp, #32]
    8f0c:	f8008462 	str	x2, [x3], #8
    8f10:	aa0303e0 	mov	x0, x3
    8f14:	f9000be3 	str	x3, [sp, #16]
    8f18:	97ffe5f6 	bl	26f0 <memcpy@plt>
    8f1c:	f94013e2 	ldr	x2, [sp, #32]
    8f20:	8b020322 	add	x2, x25, x2
    8f24:	3900205f 	strb	wzr, [x2, #8]
    8f28:	f94063e0 	ldr	x0, [sp, #192]
    8f2c:	97ffe68d 	bl	2960 <free@plt>
    8f30:	9118c2c2 	add	x2, x22, #0x630
    8f34:	f9400be3 	ldr	x3, [sp, #16]
    8f38:	f949d841 	ldr	x1, [x2, #5040]
    8f3c:	f949ec40 	ldr	x0, [x2, #5080]
    8f40:	cb010321 	sub	x1, x25, x1
    8f44:	eb00403f 	cmp	x1, x0, lsl #16
    8f48:	54000322 	b.cs	8fac <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    8f4c:	d350fc20 	lsr	x0, x1, #16
    8f50:	f949fc45 	ldr	x5, [x2, #5112]
    8f54:	8b000800 	add	x0, x0, x0, lsl #2
    8f58:	d37df002 	lsl	x2, x0, #3
    8f5c:	8b0200a4 	add	x4, x5, x2
    8f60:	f9401080 	ldr	x0, [x4, #32]
    8f64:	b4000240 	cbz	x0, 8fac <fwp_hof0.constprop.0+0x62c>
    8f68:	386268a2 	ldrb	w2, [x5, x2]
    8f6c:	7100085f 	cmp	w2, #0x2
    8f70:	54008c20 	b.eq	a0f4 <fwp_hof0.constprop.0+0x1774>  // b.none
    8f74:	7100045f 	cmp	w2, #0x1
    8f78:	540001a1 	b.ne	8fac <fwp_hof0.constprop.0+0x62c>  // b.any
    8f7c:	29430885 	ldp	w5, w2, [x4, #24]
    8f80:	92403c21 	and	x1, x1, #0xffff
    8f84:	9b057c21 	mul	x1, x1, x5
    8f88:	d360fc21 	lsr	x1, x1, #32
    8f8c:	eb02003f 	cmp	x1, x2
    8f90:	540000e2 	b.cs	8fac <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    8f94:	8b010000 	add	x0, x0, x1
    8f98:	39400001 	ldrb	w1, [x0]
    8f9c:	7103fc3f 	cmp	w1, #0xff
    8fa0:	54008b00 	b.eq	a100 <fwp_hof0.constprop.0+0x1780>  // b.none
    8fa4:	52800021 	mov	w1, #0x1                   	// #1
    8fa8:	39000001 	strb	w1, [x0]
    8fac:	aa1503e0 	mov	x0, x21
    8fb0:	f9000be3 	str	x3, [sp, #16]
    8fb4:	97fff4d3 	bl	6300 <fwp_drop0>
    8fb8:	91014295 	add	x21, x20, #0x50
    8fbc:	f9400be3 	ldr	x3, [sp, #16]
    8fc0:	d2800021 	mov	x1, #0x1                   	// #1
    8fc4:	f9400322 	ldr	x2, [x25]
    8fc8:	aa0303e0 	mov	x0, x3
    8fcc:	f9404aa3 	ldr	x3, [x21, #144]
    8fd0:	97ffe674 	bl	29a0 <fwrite@plt>
    8fd4:	f9404aa1 	ldr	x1, [x21, #144]
    8fd8:	52800140 	mov	w0, #0xa                   	// #10
    8fdc:	97ffe5f9 	bl	27c0 <fputc@plt>
    8fe0:	9118c2c2 	add	x2, x22, #0x630
    8fe4:	f949d841 	ldr	x1, [x2, #5040]
    8fe8:	f949ec40 	ldr	x0, [x2, #5080]
    8fec:	cb010321 	sub	x1, x25, x1
    8ff0:	eb00403f 	cmp	x1, x0, lsl #16
    8ff4:	54000382 	b.cs	9064 <fwp_hof0.constprop.0+0x6e4>  // b.hs, b.nlast
    8ff8:	d350fc20 	lsr	x0, x1, #16
    8ffc:	f949fc44 	ldr	x4, [x2, #5112]
    9000:	8b000800 	add	x0, x0, x0, lsl #2
    9004:	d37df002 	lsl	x2, x0, #3
    9008:	8b020083 	add	x3, x4, x2
    900c:	f9401075 	ldr	x21, [x3, #32]
    9010:	b40002b5 	cbz	x21, 9064 <fwp_hof0.constprop.0+0x6e4>
    9014:	38626882 	ldrb	w2, [x4, x2]
    9018:	7100085f 	cmp	w2, #0x2
    901c:	54008660 	b.eq	a0e8 <fwp_hof0.constprop.0+0x1768>  // b.none
    9020:	7100045f 	cmp	w2, #0x1
    9024:	54000201 	b.ne	9064 <fwp_hof0.constprop.0+0x6e4>  // b.any
    9028:	29430062 	ldp	w2, w0, [x3, #24]
    902c:	92403c21 	and	x1, x1, #0xffff
    9030:	9b027c21 	mul	x1, x1, x2
    9034:	d360fc21 	lsr	x1, x1, #32
    9038:	eb00003f 	cmp	x1, x0
    903c:	54000142 	b.cs	9064 <fwp_hof0.constprop.0+0x6e4>  // b.hs, b.nlast
    9040:	8b0102b5 	add	x21, x21, x1
    9044:	394002a1 	ldrb	w1, [x21]
    9048:	340000e1 	cbz	w1, 9064 <fwp_hof0.constprop.0+0x6e4>
    904c:	7100043f 	cmp	w1, #0x1
    9050:	54008460 	b.eq	a0dc <fwp_hof0.constprop.0+0x175c>  // b.none
    9054:	7103fc3f 	cmp	w1, #0xff
    9058:	54008600 	b.eq	a118 <fwp_hof0.constprop.0+0x1798>  // b.none
    905c:	51000421 	sub	w1, w1, #0x1
    9060:	390002a1 	strb	w1, [x21]
    9064:	f9400fe0 	ldr	x0, [sp, #24]
    9068:	f9400800 	ldr	x0, [x0, #16]
    906c:	f9000fe0 	str	x0, [sp, #24]
    9070:	b5ffcc20 	cbnz	x0, 89f4 <fwp_hof0.constprop.0+0x74>
    9074:	a95253f3 	ldp	x19, x20, [sp, #288]
    9078:	a9535bf5 	ldp	x21, x22, [sp, #304]
    907c:	a95463f7 	ldp	x23, x24, [sp, #320]
    9080:	a9556bf9 	ldp	x25, x26, [sp, #336]
    9084:	d503201f 	nop
    9088:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    908c:	f947f400 	ldr	x0, [x0, #4072]
    9090:	f94087e2 	ldr	x2, [sp, #264]
    9094:	f9400001 	ldr	x1, [x0]
    9098:	eb010042 	subs	x2, x2, x1
    909c:	d2800001 	mov	x1, #0x0                   	// #0
    90a0:	54009a21 	b.ne	a3e4 <fwp_hof0.constprop.0+0x1a64>  // b.any
    90a4:	a9517bfd 	ldp	x29, x30, [sp, #272]
    90a8:	d2800000 	mov	x0, #0x0                   	// #0
    90ac:	a95673fb 	ldp	x27, x28, [sp, #352]
    90b0:	9105c3ff 	add	sp, sp, #0x170
    90b4:	d65f03c0 	ret
    90b8:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_entry173+0xac>
    90bc:	911c4000 	add	x0, x0, #0x710
    90c0:	940015d4 	bl	e810 <atexit>
    90c4:	35005220 	cbnz	w0, 9b08 <fwp_hof0.constprop.0+0x1188>
    90c8:	52800020 	mov	w0, #0x1                   	// #1
    90cc:	b903c6a0 	str	w0, [x21, #964]
    90d0:	17fffee3 	b	8c5c <fwp_hof0.constprop.0+0x2dc>
    90d4:	d3707ce7 	ubfiz	x7, x7, #16, #32
    90d8:	52800041 	mov	w1, #0x2                   	// #2
    90dc:	aa0900e0 	orr	x0, x7, x9
    90e0:	f9001be0 	str	x0, [sp, #48]
    90e4:	d2800100 	mov	x0, #0x8                   	// #8
    90e8:	97fff00a 	bl	5110 <fwp_heap_alloc>
    90ec:	aa0003e9 	mov	x9, x0
    90f0:	9118c2c0 	add	x0, x22, #0x630
    90f4:	aa0903ea 	mov	x10, x9
    90f8:	f900013f 	str	xzr, [x9]
    90fc:	f949d801 	ldr	x1, [x0, #5040]
    9100:	f949ec00 	ldr	x0, [x0, #5080]
    9104:	cb010121 	sub	x1, x9, x1
    9108:	eb00403f 	cmp	x1, x0, lsl #16
    910c:	540013c2 	b.cs	9384 <fwp_hof0.constprop.0+0xa04>  // b.hs, b.nlast
    9110:	d2800017 	mov	x23, #0x0                   	// #0
    9114:	9118c2c2 	add	x2, x22, #0x630
    9118:	d350fc20 	lsr	x0, x1, #16
    911c:	8b000800 	add	x0, x0, x0, lsl #2
    9120:	f949fc44 	ldr	x4, [x2, #5112]
    9124:	d37df002 	lsl	x2, x0, #3
    9128:	8b020083 	add	x3, x4, x2
    912c:	f9401075 	ldr	x21, [x3, #32]
    9130:	b4000255 	cbz	x21, 9178 <fwp_hof0.constprop.0+0x7f8>
    9134:	38626882 	ldrb	w2, [x4, x2]
    9138:	7100085f 	cmp	w2, #0x2
    913c:	540012a0 	b.eq	9390 <fwp_hof0.constprop.0+0xa10>  // b.none
    9140:	7100045f 	cmp	w2, #0x1
    9144:	540001a1 	b.ne	9178 <fwp_hof0.constprop.0+0x7f8>  // b.any
    9148:	29430864 	ldp	w4, w2, [x3, #24]
    914c:	92403c21 	and	x1, x1, #0xffff
    9150:	9b047c21 	mul	x1, x1, x4
    9154:	d360fc21 	lsr	x1, x1, #32
    9158:	eb02003f 	cmp	x1, x2
    915c:	540000e2 	b.cs	9178 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    9160:	8b0102b5 	add	x21, x21, x1
    9164:	394002a1 	ldrb	w1, [x21]
    9168:	7103fc3f 	cmp	w1, #0xff
    916c:	54004a60 	b.eq	9ab8 <fwp_hof0.constprop.0+0x1138>  // b.none
    9170:	52800021 	mov	w1, #0x1                   	// #1
    9174:	390002a1 	strb	w1, [x21]
    9178:	b4000257 	cbz	x23, 91c0 <fwp_hof0.constprop.0+0x840>
    917c:	f9401be0 	ldr	x0, [sp, #48]
    9180:	aa1a03e2 	mov	x2, x26
    9184:	f9400748 	ldr	x8, [x26, #8]
    9188:	91002123 	add	x3, x9, #0x8
    918c:	d3607c07 	lsl	x7, x0, #32
    9190:	d2800001 	mov	x1, #0x0                   	// #0
    9194:	aa0703e4 	mov	x4, x7
    9198:	14000005 	b	91ac <fwp_hof0.constprop.0+0x82c>
    919c:	f9400448 	ldr	x8, [x2, #8]
    91a0:	ab070024 	adds	x4, x1, x7
    91a4:	91004063 	add	x3, x3, #0x10
    91a8:	54009b26 	b.vs	a50c <fwp_hof0.constprop.0+0x1b8c>
    91ac:	a9001068 	stp	x8, x4, [x3]
    91b0:	91000421 	add	x1, x1, #0x1
    91b4:	f9400842 	ldr	x2, [x2, #16]
    91b8:	eb17003f 	cmp	x1, x23
    91bc:	54ffff03 	b.cc	919c <fwp_hof0.constprop.0+0x81c>  // b.lo, b.ul, b.last
    91c0:	f9400120 	ldr	x0, [x9]
    91c4:	f100041f 	cmp	x0, #0x1
    91c8:	54000de9 	b.ls	9384 <fwp_hof0.constprop.0+0xa04>  // b.plast
    91cc:	d341fc17 	lsr	x23, x0, #1
    91d0:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    91d4:	d10006e0 	sub	x0, x23, #0x1
    91d8:	eb01001f 	cmp	x0, x1
    91dc:	54ffe408 	b.hi	8e5c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    91e0:	b4000d20 	cbz	x0, 9384 <fwp_hof0.constprop.0+0xa04>
    91e4:	91002135 	add	x21, x9, #0x8
    91e8:	d1002121 	sub	x1, x9, #0x8
    91ec:	8b171037 	add	x23, x1, x23, lsl #4
    91f0:	a903cfea 	stp	x10, x19, [sp, #56]
    91f4:	aa1503f3 	mov	x19, x21
    91f8:	aa0003f5 	mov	x21, x0
    91fc:	f90027e9 	str	x9, [sp, #72]
    9200:	f9400660 	ldr	x0, [x19, #8]
    9204:	f9400e61 	ldr	x1, [x19, #24]
    9208:	fd400260 	ldr	d0, [x19]
    920c:	fd400a61 	ldr	d1, [x19, #16]
    9210:	97fff174 	bl	57e0 <w120>
    9214:	a9000660 	stp	x0, x1, [x19]
    9218:	91004273 	add	x19, x19, #0x10
    921c:	eb17027f 	cmp	x19, x23
    9220:	54ffff01 	b.ne	9200 <fwp_hof0.constprop.0+0x880>  // b.any
    9224:	a94427f3 	ldp	x19, x9, [sp, #64]
    9228:	d37ffaa1 	lsl	x1, x21, #1
    922c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    9230:	d2800015 	mov	x21, #0x0                   	// #0
    9234:	aa1703e0 	mov	x0, x23
    9238:	aa1503f7 	mov	x23, x21
    923c:	aa0103f5 	mov	x21, x1
    9240:	a90467e9 	stp	x9, x25, [sp, #64]
    9244:	aa0903e2 	mov	x2, x9
    9248:	aa1303f9 	mov	x25, x19
    924c:	f8010441 	str	x1, [x2], #16
    9250:	aa0203f3 	mov	x19, x2
    9254:	d503201f 	nop
    9258:	f8777a61 	ldr	x1, [x19, x23, lsl #3]
    925c:	91000af7 	add	x23, x23, #0x2
    9260:	97fff108 	bl	5680 <f141.constprop.0>
    9264:	eb1502ff 	cmp	x23, x21
    9268:	54ffff83 	b.cc	9258 <fwp_hof0.constprop.0+0x8d8>  // b.lo, b.ul, b.last
    926c:	a943a7ea 	ldp	x10, x9, [sp, #56]
    9270:	aa1903f3 	mov	x19, x25
    9274:	f94027f9 	ldr	x25, [sp, #72]
    9278:	aa0003f7 	mov	x23, x0
    927c:	9118c2c3 	add	x3, x22, #0x630
    9280:	aa0303f5 	mov	x21, x3
    9284:	f949d861 	ldr	x1, [x3, #5040]
    9288:	f949ec60 	ldr	x0, [x3, #5080]
    928c:	cb010121 	sub	x1, x9, x1
    9290:	eb00403f 	cmp	x1, x0, lsl #16
    9294:	540003a2 	b.cs	9308 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    9298:	d350fc20 	lsr	x0, x1, #16
    929c:	f949fea4 	ldr	x4, [x21, #5112]
    92a0:	8b000800 	add	x0, x0, x0, lsl #2
    92a4:	d37df002 	lsl	x2, x0, #3
    92a8:	8b020083 	add	x3, x4, x2
    92ac:	f9401060 	ldr	x0, [x3, #32]
    92b0:	b40002c0 	cbz	x0, 9308 <fwp_hof0.constprop.0+0x988>
    92b4:	38626882 	ldrb	w2, [x4, x2]
    92b8:	7100085f 	cmp	w2, #0x2
    92bc:	540019c0 	b.eq	95f4 <fwp_hof0.constprop.0+0xc74>  // b.none
    92c0:	7100045f 	cmp	w2, #0x1
    92c4:	54000221 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    92c8:	29430865 	ldp	w5, w2, [x3, #24]
    92cc:	92403c21 	and	x1, x1, #0xffff
    92d0:	9b057c21 	mul	x1, x1, x5
    92d4:	d360fc21 	lsr	x1, x1, #32
    92d8:	eb02003f 	cmp	x1, x2
    92dc:	54000162 	b.cs	9308 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    92e0:	8b010000 	add	x0, x0, x1
    92e4:	39400001 	ldrb	w1, [x0]
    92e8:	34000101 	cbz	w1, 9308 <fwp_hof0.constprop.0+0x988>
    92ec:	7100043f 	cmp	w1, #0x1
    92f0:	54000560 	b.eq	939c <fwp_hof0.constprop.0+0xa1c>  // b.none
    92f4:	7103fc3f 	cmp	w1, #0xff
    92f8:	54004200 	b.eq	9b38 <fwp_hof0.constprop.0+0x11b8>  // b.none
    92fc:	51000421 	sub	w1, w1, #0x1
    9300:	39000001 	strb	w1, [x0]
    9304:	d503201f 	nop
    9308:	b98033f5 	ldrsw	x21, [sp, #48]
    930c:	aa1503e0 	mov	x0, x21
    9310:	97ffee0c 	bl	4b40 <fwp_tape_of>
    9314:	f9403002 	ldr	x2, [x0, #96]
    9318:	aa0003e7 	mov	x7, x0
    931c:	b4000f42 	cbz	x2, 9504 <fwp_hof0.constprop.0+0xb84>
    9320:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9324:	9136c000 	add	x0, x0, #0xdb0
    9328:	97ffec03 	bl	4334 <fwp_trap>
    932c:	d2800017 	mov	x23, #0x0                   	// #0
    9330:	17fffe48 	b	8c50 <fwp_hof0.constprop.0+0x2d0>
    9334:	d37ffae2 	lsl	x2, x23, #1
    9338:	d3707ce7 	ubfiz	x7, x7, #16, #32
    933c:	91000440 	add	x0, x2, #0x1
    9340:	aa0900e1 	orr	x1, x7, x9
    9344:	aa0203f5 	mov	x21, x2
    9348:	f9001be1 	str	x1, [sp, #48]
    934c:	d37df000 	lsl	x0, x0, #3
    9350:	52800041 	mov	w1, #0x2                   	// #2
    9354:	97ffef6f 	bl	5110 <fwp_heap_alloc>
    9358:	aa0003e9 	mov	x9, x0
    935c:	9118c2c1 	add	x1, x22, #0x630
    9360:	aa0003ea 	mov	x10, x0
    9364:	aa0103e0 	mov	x0, x1
    9368:	f9000135 	str	x21, [x9]
    936c:	f949d821 	ldr	x1, [x1, #5040]
    9370:	f949ec00 	ldr	x0, [x0, #5080]
    9374:	cb010121 	sub	x1, x9, x1
    9378:	eb00403f 	cmp	x1, x0, lsl #16
    937c:	54ffecc3 	b.cc	9114 <fwp_hof0.constprop.0+0x794>  // b.lo, b.ul, b.last
    9380:	b5ffeff7 	cbnz	x23, 917c <fwp_hof0.constprop.0+0x7fc>
    9384:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    9388:	f900013f 	str	xzr, [x9]
    938c:	17ffffbc 	b	927c <fwp_hof0.constprop.0+0x8fc>
    9390:	72003c3f 	tst	w1, #0xffff
    9394:	54ffef21 	b.ne	9178 <fwp_hof0.constprop.0+0x7f8>  // b.any
    9398:	17ffff73 	b	9164 <fwp_hof0.constprop.0+0x7e4>
    939c:	f9400143 	ldr	x3, [x10]
    93a0:	aa0a03e5 	mov	x5, x10
    93a4:	f949eea2 	ldr	x2, [x21, #5080]
    93a8:	f949daa1 	ldr	x1, [x21, #5040]
    93ac:	d370bc47 	lsl	x7, x2, #16
    93b0:	cb010140 	sub	x0, x10, x1
    93b4:	b7f81263 	tbnz	x3, #63, 9600 <fwp_hof0.constprop.0+0xc80>
    93b8:	eb0000ff 	cmp	x7, x0
    93bc:	54fffa69 	b.ls	9308 <fwp_hof0.constprop.0+0x988>  // b.plast
    93c0:	d350fc01 	lsr	x1, x0, #16
    93c4:	8b010821 	add	x1, x1, x1, lsl #2
    93c8:	d37df021 	lsl	x1, x1, #3
    93cc:	8b010083 	add	x3, x4, x1
    93d0:	f9401062 	ldr	x2, [x3, #32]
    93d4:	b4fff9a2 	cbz	x2, 9308 <fwp_hof0.constprop.0+0x988>
    93d8:	38616881 	ldrb	w1, [x4, x1]
    93dc:	7100083f 	cmp	w1, #0x2
    93e0:	54003560 	b.eq	9a8c <fwp_hof0.constprop.0+0x110c>  // b.none
    93e4:	7100043f 	cmp	w1, #0x1
    93e8:	54fff901 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    93ec:	29430464 	ldp	w4, w1, [x3, #24]
    93f0:	92403c00 	and	x0, x0, #0xffff
    93f4:	9b047c00 	mul	x0, x0, x4
    93f8:	d360fc00 	lsr	x0, x0, #32
    93fc:	eb01001f 	cmp	x0, x1
    9400:	54fff842 	b.cs	9308 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    9404:	8b000042 	add	x2, x2, x0
    9408:	39400040 	ldrb	w0, [x2]
    940c:	7100041f 	cmp	w0, #0x1
    9410:	54fff7c1 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    9414:	aa0a03e0 	mov	x0, x10
    9418:	97ffec82 	bl	4620 <fwp_mem_free>
    941c:	17ffffbb 	b	9308 <fwp_hof0.constprop.0+0x988>
    9420:	d0000020 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    9424:	91000000 	add	x0, x0, #0x0
    9428:	97ffebc3 	bl	4334 <fwp_trap>
    942c:	ad468402 	ldp	q2, q1, [x0, #208]
    9430:	91034001 	add	x1, x0, #0xd0
    9434:	4f000400 	movi	v0.4s, #0x0
    9438:	f900841f 	str	xzr, [x0, #264]
    943c:	ad010462 	stp	q2, q1, [x3, #32]
    9440:	f9408000 	ldr	x0, [x0, #256]
    9444:	f9002460 	str	x0, [x3, #72]
    9448:	f9401020 	ldr	x0, [x1, #32]
    944c:	f9002060 	str	x0, [x3, #64]
    9450:	f9401420 	ldr	x0, [x1, #40]
    9454:	f9000c60 	str	x0, [x3, #24]
    9458:	f900183f 	str	xzr, [x1, #48]
    945c:	ad000020 	stp	q0, q0, [x1]
    9460:	3d800820 	str	q0, [x1, #32]
    9464:	17fffe4c 	b	8d94 <fwp_hof0.constprop.0+0x414>
    9468:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    946c:	913d8000 	add	x0, x0, #0xf60
    9470:	97ffebb1 	bl	4334 <fwp_trap>
    9474:	97ffece4 	bl	4804 <fwp_rc_wide_dup>
    9478:	9118c2c0 	add	x0, x22, #0x630
    947c:	f949ec04 	ldr	x4, [x0, #5080]
    9480:	f949d801 	ldr	x1, [x0, #5040]
    9484:	d370bc84 	lsl	x4, x4, #16
    9488:	17fffd82 	b	8a90 <fwp_hof0.constprop.0+0x110>
    948c:	97ffecde 	bl	4804 <fwp_rc_wide_dup>
    9490:	17fffdae 	b	8b48 <fwp_hof0.constprop.0+0x1c8>
    9494:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9498:	9118c2c1 	add	x1, x22, #0x630
    949c:	ca402400 	eor	x0, x0, x0, lsr #9
    94a0:	92401c00 	and	x0, x0, #0xff
    94a4:	910a2402 	add	x2, x0, #0x289
    94a8:	8b000c20 	add	x0, x1, x0, lsl #3
    94ac:	8b020c22 	add	x2, x1, x2, lsl #3
    94b0:	f94a2400 	ldr	x0, [x0, #5192]
    94b4:	b50000a0 	cbnz	x0, 94c8 <fwp_hof0.constprop.0+0xb48>
    94b8:	14000178 	b	9a98 <fwp_hof0.constprop.0+0x1118>
    94bc:	91004002 	add	x2, x0, #0x10
    94c0:	f9400800 	ldr	x0, [x0, #16]
    94c4:	b4002ea0 	cbz	x0, 9a98 <fwp_hof0.constprop.0+0x1118>
    94c8:	f9400001 	ldr	x1, [x0]
    94cc:	eb15003f 	cmp	x1, x21
    94d0:	54ffff61 	b.ne	94bc <fwp_hof0.constprop.0+0xb3c>  // b.any
    94d4:	f9400041 	ldr	x1, [x2]
    94d8:	f9400420 	ldr	x0, [x1, #8]
    94dc:	d1000400 	sub	x0, x0, #0x1
    94e0:	f9000420 	str	x0, [x1, #8]
    94e4:	f103f81f 	cmp	x0, #0xfe
    94e8:	54ffb701 	b.ne	8bc8 <fwp_hof0.constprop.0+0x248>  // b.any
    94ec:	394002a0 	ldrb	w0, [x21]
    94f0:	7103fc1f 	cmp	w0, #0xff
    94f4:	54002f20 	b.eq	9ad8 <fwp_hof0.constprop.0+0x1158>  // b.none
    94f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    94fc:	390002a0 	strb	w0, [x21]
    9500:	17fffdb2 	b	8bc8 <fwp_hof0.constprop.0+0x248>
    9504:	97ffe6c4 	bl	3014 <fwp_tape_unlink_scope>
    9508:	b90004ff 	str	wzr, [x7, #4]
    950c:	a94190e2 	ldp	x2, x4, [x7, #24]
    9510:	f9001fe4 	str	x4, [sp, #56]
    9514:	f94014e4 	ldr	x4, [x7, #40]
    9518:	f90023e4 	str	x4, [sp, #64]
    951c:	f94018e4 	ldr	x4, [x7, #48]
    9520:	f90027e4 	str	x4, [sp, #72]
    9524:	f9401ce4 	ldr	x4, [x7, #56]
    9528:	f9002be4 	str	x4, [sp, #80]
    952c:	b94000e1 	ldr	w1, [x7]
    9530:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    9534:	a9408ce8 	ldp	x8, x3, [x7, #8]
    9538:	f94020e4 	ldr	x4, [x7, #64]
    953c:	f94024e9 	ldr	x9, [x7, #72]
    9540:	6b00003f 	cmp	w1, w0
    9544:	54000108 	b.hi	9564 <fwp_hof0.constprop.0+0xbe4>  // b.pmore
    9548:	91014281 	add	x1, x20, #0x50
    954c:	92403ea0 	and	x0, x21, #0xffff
    9550:	d1000400 	sub	x0, x0, #0x1
    9554:	f940b02a 	ldr	x10, [x1, #352]
    9558:	eb0a001f 	cmp	x0, x10
    955c:	5400004a 	b.ge	9564 <fwp_hof0.constprop.0+0xbe4>  // b.tcont
    9560:	f900b020 	str	x0, [x1, #352]
    9564:	4f000400 	movi	v0.4s, #0x0
    9568:	f9000cff 	str	xzr, [x7, #24]
    956c:	f9401fe0 	ldr	x0, [sp, #56]
    9570:	a9047cff 	stp	xzr, xzr, [x7, #64]
    9574:	91014281 	add	x1, x20, #0x50
    9578:	3c8080e0 	stur	q0, [x7, #8]
    957c:	9102a3e5 	add	x5, sp, #0xa8
    9580:	ad0100e0 	stp	q0, q0, [x7, #32]
    9584:	f90063e0 	str	x0, [sp, #192]
    9588:	f94023e0 	ldr	x0, [sp, #64]
    958c:	f90067e0 	str	x0, [sp, #200]
    9590:	f94027e0 	ldr	x0, [sp, #72]
    9594:	f9006be0 	str	x0, [sp, #208]
    9598:	f9402be0 	ldr	x0, [sp, #80]
    959c:	f9006fe0 	str	x0, [sp, #216]
    95a0:	f941c820 	ldr	x0, [x1, #912]
    95a4:	f90057e0 	str	x0, [sp, #168]
    95a8:	f0ffffc0 	adrp	x0, 4000 <ad_raw_free.part.0+0x10>
    95ac:	91065000 	add	x0, x0, #0x194
    95b0:	f9002fe5 	str	x5, [sp, #88]
    95b4:	f9005be0 	str	x0, [sp, #176]
    95b8:	910303e0 	add	x0, sp, #0xc0
    95bc:	f9001be0 	str	x0, [sp, #48]
    95c0:	f9005fe0 	str	x0, [sp, #184]
    95c4:	a90e0be4 	stp	x4, x2, [sp, #224]
    95c8:	f9007be9 	str	x9, [sp, #240]
    95cc:	f901c825 	str	x5, [x1, #912]
    95d0:	b7f826b7 	tbnz	x23, #63, 9aa4 <fwp_hof0.constprop.0+0x1124>
    95d4:	eb9782bf 	cmp	x21, x23, asr #32
    95d8:	540005c0 	b.eq	9690 <fwp_hof0.constprop.0+0xd10>  // b.none
    95dc:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    95e0:	9135a000 	add	x0, x0, #0xd68
    95e4:	97ffeb54 	bl	4334 <fwp_trap>
    95e8:	d2800d01 	mov	x1, #0x68                  	// #104
    95ec:	d2800024 	mov	x4, #0x1                   	// #1
    95f0:	17fffdbf 	b	8cec <fwp_hof0.constprop.0+0x36c>
    95f4:	72003c3f 	tst	w1, #0xffff
    95f8:	54ffe881 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    95fc:	17ffff3a 	b	92e4 <fwp_hof0.constprop.0+0x964>
    9600:	f940054a 	ldr	x10, [x10, #8]
    9604:	eb0000ff 	cmp	x7, x0
    9608:	540003c9 	b.ls	9680 <fwp_hof0.constprop.0+0xd00>  // b.plast
    960c:	d350fc02 	lsr	x2, x0, #16
    9610:	8b020842 	add	x2, x2, x2, lsl #2
    9614:	d37df042 	lsl	x2, x2, #3
    9618:	8b020086 	add	x6, x4, x2
    961c:	f94010c3 	ldr	x3, [x6, #32]
    9620:	b4000303 	cbz	x3, 9680 <fwp_hof0.constprop.0+0xd00>
    9624:	38626882 	ldrb	w2, [x4, x2]
    9628:	7100085f 	cmp	w2, #0x2
    962c:	54002500 	b.eq	9acc <fwp_hof0.constprop.0+0x114c>  // b.none
    9630:	7100045f 	cmp	w2, #0x1
    9634:	54000261 	b.ne	9680 <fwp_hof0.constprop.0+0xd00>  // b.any
    9638:	92403c02 	and	x2, x0, #0xffff
    963c:	294300c4 	ldp	w4, w0, [x6, #24]
    9640:	9b047c42 	mul	x2, x2, x4
    9644:	d360fc42 	lsr	x2, x2, #32
    9648:	eb00005f 	cmp	x2, x0
    964c:	540001a2 	b.cs	9680 <fwp_hof0.constprop.0+0xd00>  // b.hs, b.nlast
    9650:	8b020063 	add	x3, x3, x2
    9654:	39400060 	ldrb	w0, [x3]
    9658:	7100041f 	cmp	w0, #0x1
    965c:	54000121 	b.ne	9680 <fwp_hof0.constprop.0+0xd00>  // b.any
    9660:	aa0503e0 	mov	x0, x5
    9664:	f9001fea 	str	x10, [sp, #56]
    9668:	97ffebee 	bl	4620 <fwp_mem_free>
    966c:	9118c2c0 	add	x0, x22, #0x630
    9670:	f9401fea 	ldr	x10, [sp, #56]
    9674:	f949ec02 	ldr	x2, [x0, #5080]
    9678:	f949d801 	ldr	x1, [x0, #5040]
    967c:	d370bc47 	lsl	x7, x2, #16
    9680:	cb010141 	sub	x1, x10, x1
    9684:	eb07003f 	cmp	x1, x7
    9688:	54ffe083 	b.cc	9298 <fwp_hof0.constprop.0+0x918>  // b.lo, b.ul, b.last
    968c:	17ffff1f 	b	9308 <fwp_hof0.constprop.0+0x988>
    9690:	92407ee0 	and	x0, x23, #0xffffffff
    9694:	eb37407f 	cmp	x3, w23, uxtw
    9698:	540020ad 	b.le	9aac <fwp_hof0.constprop.0+0x112c>
    969c:	eb08001f 	cmp	x0, x8
    96a0:	9a80b515 	csinc	x21, x8, x0, lt	// lt = tstop
    96a4:	eb15013f 	cmp	x9, x21
    96a8:	5400220a 	b.ge	9ae8 <fwp_hof0.constprop.0+0x1168>  // b.tcont
    96ac:	f100013f 	cmp	x9, #0x0
    96b0:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    96b4:	9a951129 	csel	x9, x9, x21, ne	// ne = any
    96b8:	14000004 	b	96c8 <fwp_hof0.constprop.0+0xd48>
    96bc:	eb02013f 	cmp	x9, x2
    96c0:	d37ff929 	lsl	x9, x9, #1
    96c4:	9a95d129 	csel	x9, x9, x21, le
    96c8:	eb15013f 	cmp	x9, x21
    96cc:	54ffff8b 	b.lt	96bc <fwp_hof0.constprop.0+0xd3c>  // b.tstop
    96d0:	b4005984 	cbz	x4, a200 <fwp_hof0.constprop.0+0x1880>
    96d4:	aa0403e0 	mov	x0, x4
    96d8:	d37df121 	lsl	x1, x9, #3
    96dc:	52800062 	mov	w2, #0x3                   	// #3
    96e0:	a90623e9 	stp	x9, x8, [sp, #96]
    96e4:	97ffea78 	bl	40c4 <ad_raw_realloc>
    96e8:	a94623e9 	ldp	x9, x8, [sp, #96]
    96ec:	aa0003e4 	mov	x4, x0
    96f0:	b4001fa0 	cbz	x0, 9ae4 <fwp_hof0.constprop.0+0x1164>
    96f4:	f90073e4 	str	x4, [sp, #224]
    96f8:	f9007be9 	str	x9, [sp, #240]
    96fc:	b5001b95 	cbnz	x21, 9a6c <fwp_hof0.constprop.0+0x10ec>
    9700:	b7f800d7 	tbnz	x23, #63, 9718 <fwp_hof0.constprop.0+0xd98>
    9704:	92407ef7 	and	x23, x23, #0xffffffff
    9708:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    970c:	fc777880 	ldr	d0, [x4, x23, lsl #3]
    9710:	1e612800 	fadd	d0, d0, d1
    9714:	fc377880 	str	d0, [x4, x23, lsl #3]
    9718:	d10006a0 	sub	x0, x21, #0x1
    971c:	d1000503 	sub	x3, x8, #0x1
    9720:	eb00011f 	cmp	x8, x0
    9724:	5400042c 	b.gt	97a8 <fwp_hof0.constprop.0+0xe28>
    9728:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    972c:	1e602008 	fcmp	d0, #0.0
    9730:	54000360 	b.eq	979c <fwp_hof0.constprop.0+0xe1c>  // b.none
    9734:	f9401fe2 	ldr	x2, [sp, #56]
    9738:	cb080be1 	neg	x1, x8, lsl #2
    973c:	cb0803e5 	neg	x5, x8
    9740:	8b010042 	add	x2, x2, x1
    9744:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    9748:	37f80122 	tbnz	w2, #31, 976c <fwp_hof0.constprop.0+0xdec>
    974c:	f94027e6 	ldr	x6, [sp, #72]
    9750:	93407c42 	sxtw	x2, w2
    9754:	8b050cc6 	add	x6, x6, x5, lsl #3
    9758:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    975c:	fc6078c2 	ldr	d2, [x6, x0, lsl #3]
    9760:	1e620802 	fmul	d2, d0, d2
    9764:	1e622821 	fadd	d1, d1, d2
    9768:	fc227881 	str	d1, [x4, x2, lsl #3]
    976c:	f94023e2 	ldr	x2, [sp, #64]
    9770:	8b010041 	add	x1, x2, x1
    9774:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9778:	37f80121 	tbnz	w1, #31, 979c <fwp_hof0.constprop.0+0xe1c>
    977c:	f9402be2 	ldr	x2, [sp, #80]
    9780:	93407c21 	sxtw	x1, w1
    9784:	8b050c45 	add	x5, x2, x5, lsl #3
    9788:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    978c:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    9790:	1e620800 	fmul	d0, d0, d2
    9794:	1e602820 	fadd	d0, d1, d0
    9798:	fc217880 	str	d0, [x4, x1, lsl #3]
    979c:	d1000400 	sub	x0, x0, #0x1
    97a0:	eb03001f 	cmp	x0, x3
    97a4:	54fffc21 	b.ne	9728 <fwp_hof0.constprop.0+0xda8>  // b.any
    97a8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    97ac:	eb00011f 	cmp	x8, x0
    97b0:	54001fc8 	b.hi	9ba8 <fwp_hof0.constprop.0+0x1228>  // b.pmore
    97b4:	91000500 	add	x0, x8, #0x1
    97b8:	52800041 	mov	w1, #0x2                   	// #2
    97bc:	a90393e8 	stp	x8, x4, [sp, #56]
    97c0:	d37df000 	lsl	x0, x0, #3
    97c4:	97ffee53 	bl	5110 <fwp_heap_alloc>
    97c8:	aa0003f7 	mov	x23, x0
    97cc:	a94393e8 	ldp	x8, x4, [sp, #56]
    97d0:	f8008408 	str	x8, [x0], #8
    97d4:	d2800001 	mov	x1, #0x0                   	// #0
    97d8:	b40000c8 	cbz	x8, 97f0 <fwp_hof0.constprop.0+0xe70>
    97dc:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    97e0:	f8217802 	str	x2, [x0, x1, lsl #3]
    97e4:	91000421 	add	x1, x1, #0x1
    97e8:	eb01011f 	cmp	x8, x1
    97ec:	54ffff81 	b.ne	97dc <fwp_hof0.constprop.0+0xe5c>  // b.any
    97f0:	91014281 	add	x1, x20, #0x50
    97f4:	f9402fe2 	ldr	x2, [sp, #88]
    97f8:	f941c820 	ldr	x0, [x1, #912]
    97fc:	eb02001f 	cmp	x0, x2
    9800:	54006881 	b.ne	a510 <fwp_hof0.constprop.0+0x1b90>  // b.any
    9804:	f9401be0 	ldr	x0, [sp, #48]
    9808:	f94057e4 	ldr	x4, [sp, #168]
    980c:	f9001fe4 	str	x4, [sp, #56]
    9810:	f901c824 	str	x4, [x1, #912]
    9814:	97ffea60 	bl	4194 <fwp_tape_buffers_release>
    9818:	9118c2c2 	add	x2, x22, #0x630
    981c:	f9401fe4 	ldr	x4, [sp, #56]
    9820:	f949d841 	ldr	x1, [x2, #5040]
    9824:	f949ec40 	ldr	x0, [x2, #5080]
    9828:	cb0102e1 	sub	x1, x23, x1
    982c:	eb00403f 	cmp	x1, x0, lsl #16
    9830:	54000322 	b.cs	9894 <fwp_hof0.constprop.0+0xf14>  // b.hs, b.nlast
    9834:	d350fc20 	lsr	x0, x1, #16
    9838:	f949fc47 	ldr	x7, [x2, #5112]
    983c:	8b000800 	add	x0, x0, x0, lsl #2
    9840:	d37df002 	lsl	x2, x0, #3
    9844:	8b0200e3 	add	x3, x7, x2
    9848:	f9401075 	ldr	x21, [x3, #32]
    984c:	b4000255 	cbz	x21, 9894 <fwp_hof0.constprop.0+0xf14>
    9850:	386268e0 	ldrb	w0, [x7, x2]
    9854:	7100081f 	cmp	w0, #0x2
    9858:	54004ce0 	b.eq	a1f4 <fwp_hof0.constprop.0+0x1874>  // b.none
    985c:	7100041f 	cmp	w0, #0x1
    9860:	540001a1 	b.ne	9894 <fwp_hof0.constprop.0+0xf14>  // b.any
    9864:	29430062 	ldp	w2, w0, [x3, #24]
    9868:	92403c21 	and	x1, x1, #0xffff
    986c:	9b027c21 	mul	x1, x1, x2
    9870:	d360fc21 	lsr	x1, x1, #32
    9874:	eb00003f 	cmp	x1, x0
    9878:	540000e2 	b.cs	9894 <fwp_hof0.constprop.0+0xf14>  // b.hs, b.nlast
    987c:	8b0102b5 	add	x21, x21, x1
    9880:	394002a0 	ldrb	w0, [x21]
    9884:	7103fc1f 	cmp	w0, #0xff
    9888:	54005bc0 	b.eq	a400 <fwp_hof0.constprop.0+0x1a80>  // b.none
    988c:	52800020 	mov	w0, #0x1                   	// #1
    9890:	390002a0 	strb	w0, [x21]
    9894:	f94007e0 	ldr	x0, [sp, #8]
    9898:	eb00009f 	cmp	x4, x0
    989c:	540063a1 	b.ne	a510 <fwp_hof0.constprop.0+0x1b90>  // b.any
    98a0:	f94003e0 	ldr	x0, [sp]
    98a4:	91014281 	add	x1, x20, #0x50
    98a8:	f9404be2 	ldr	x2, [sp, #144]
    98ac:	f901c822 	str	x2, [x1, #912]
    98b0:	97fff3dc 	bl	6820 <fwp_tape_scope_release>
    98b4:	f94002e0 	ldr	x0, [x23]
    98b8:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    98bc:	b7f818a0 	tbnz	x0, #63, 9bd0 <fwp_hof0.constprop.0+0x1250>
    98c0:	9118c2c3 	add	x3, x22, #0x630
    98c4:	f949d860 	ldr	x0, [x3, #5040]
    98c8:	f949ec61 	ldr	x1, [x3, #5080]
    98cc:	cb0002e0 	sub	x0, x23, x0
    98d0:	eb01401f 	cmp	x0, x1, lsl #16
    98d4:	540017e2 	b.cs	9bd0 <fwp_hof0.constprop.0+0x1250>  // b.hs, b.nlast
    98d8:	d350fc01 	lsr	x1, x0, #16
    98dc:	f949fc67 	ldr	x7, [x3, #5112]
    98e0:	8b010821 	add	x1, x1, x1, lsl #2
    98e4:	d37df021 	lsl	x1, x1, #3
    98e8:	8b0100e4 	add	x4, x7, x1
    98ec:	f9401083 	ldr	x3, [x4, #32]
    98f0:	b4001703 	cbz	x3, 9bd0 <fwp_hof0.constprop.0+0x1250>
    98f4:	386168e1 	ldrb	w1, [x7, x1]
    98f8:	7100083f 	cmp	w1, #0x2
    98fc:	54001660 	b.eq	9bc8 <fwp_hof0.constprop.0+0x1248>  // b.none
    9900:	7100043f 	cmp	w1, #0x1
    9904:	54001661 	b.ne	9bd0 <fwp_hof0.constprop.0+0x1250>  // b.any
    9908:	29430487 	ldp	w7, w1, [x4, #24]
    990c:	92403c00 	and	x0, x0, #0xffff
    9910:	9b077c00 	mul	x0, x0, x7
    9914:	d360fc00 	lsr	x0, x0, #32
    9918:	eb01001f 	cmp	x0, x1
    991c:	540015a2 	b.cs	9bd0 <fwp_hof0.constprop.0+0x1250>  // b.hs, b.nlast
    9920:	8b000063 	add	x3, x3, x0
    9924:	39400060 	ldrb	w0, [x3]
    9928:	7100041f 	cmp	w0, #0x1
    992c:	54001521 	b.ne	9bd0 <fwp_hof0.constprop.0+0x1250>  // b.any
    9930:	aa1703f5 	mov	x21, x23
    9934:	d2800000 	mov	x0, #0x0                   	// #0
    9938:	910022a3 	add	x3, x21, #0x8
    993c:	d2800001 	mov	x1, #0x0                   	// #0
    9940:	b40001e2 	cbz	x2, 997c <fwp_hof0.constprop.0+0xffc>
    9944:	d0000024 	adrp	x4, f000 <_IO_stdin_used+0x7c0>
    9948:	910022e7 	add	x7, x23, #0x8
    994c:	fd441881 	ldr	d1, [x4, #2096]
    9950:	f94002e5 	ldr	x5, [x23]
    9954:	aa0703e4 	mov	x4, x7
    9958:	b7f81345 	tbnz	x5, #63, 9bc0 <fwp_hof0.constprop.0+0x1240>
    995c:	f94002a5 	ldr	x5, [x21]
    9960:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    9964:	b7f81285 	tbnz	x5, #63, 9bb4 <fwp_hof0.constprop.0+0x1234>
    9968:	1e600820 	fmul	d0, d1, d0
    996c:	91000421 	add	x1, x1, #0x1
    9970:	fc008460 	str	d0, [x3], #8
    9974:	eb01005f 	cmp	x2, x1
    9978:	54fffec1 	b.ne	9950 <fwp_hof0.constprop.0+0xfd0>  // b.any
    997c:	97fff5b5 	bl	7050 <fwp_drop10>
    9980:	b400575a 	cbz	x26, a468 <fwp_hof0.constprop.0+0x1ae8>
    9984:	aa1a03e0 	mov	x0, x26
    9988:	d2800017 	mov	x23, #0x0                   	// #0
    998c:	f9400800 	ldr	x0, [x0, #16]
    9990:	910006f7 	add	x23, x23, #0x1
    9994:	b5ffffc0 	cbnz	x0, 998c <fwp_hof0.constprop.0+0x100c>
    9998:	f94002a0 	ldr	x0, [x21]
    999c:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    99a0:	b7f81740 	tbnz	x0, #63, 9c88 <fwp_hof0.constprop.0+0x1308>
    99a4:	9118c2c1 	add	x1, x22, #0x630
    99a8:	f949d820 	ldr	x0, [x1, #5040]
    99ac:	f949ec22 	ldr	x2, [x1, #5080]
    99b0:	cb0002a0 	sub	x0, x21, x0
    99b4:	eb02401f 	cmp	x0, x2, lsl #16
    99b8:	54001662 	b.cs	9c84 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    99bc:	d350fc02 	lsr	x2, x0, #16
    99c0:	d2800504 	mov	x4, #0x28                  	// #40
    99c4:	f949fc27 	ldr	x7, [x1, #5112]
    99c8:	9b047c42 	mul	x2, x2, x4
    99cc:	8b0200e4 	add	x4, x7, x2
    99d0:	f9401081 	ldr	x1, [x4, #32]
    99d4:	b4001581 	cbz	x1, 9c84 <fwp_hof0.constprop.0+0x1304>
    99d8:	386268e2 	ldrb	w2, [x7, x2]
    99dc:	7100085f 	cmp	w2, #0x2
    99e0:	540014e0 	b.eq	9c7c <fwp_hof0.constprop.0+0x12fc>  // b.none
    99e4:	7100045f 	cmp	w2, #0x1
    99e8:	540014e1 	b.ne	9c84 <fwp_hof0.constprop.0+0x1304>  // b.any
    99ec:	29430887 	ldp	w7, w2, [x4, #24]
    99f0:	92403c00 	and	x0, x0, #0xffff
    99f4:	9b077c00 	mul	x0, x0, x7
    99f8:	d360fc00 	lsr	x0, x0, #32
    99fc:	eb02001f 	cmp	x0, x2
    9a00:	54001422 	b.cs	9c84 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    9a04:	8b000021 	add	x1, x1, x0
    9a08:	39400028 	ldrb	w8, [x1]
    9a0c:	7100051f 	cmp	w8, #0x1
    9a10:	540013a1 	b.ne	9c84 <fwp_hof0.constprop.0+0x1304>  // b.any
    9a14:	910022a2 	add	x2, x21, #0x8
    9a18:	eb17007f 	cmp	x3, x23
    9a1c:	9a979077 	csel	x23, x3, x23, ls	// ls = plast
    9a20:	b4005397 	cbz	x23, a490 <fwp_hof0.constprop.0+0x1b10>
    9a24:	d37df2e7 	lsl	x7, x23, #3
    9a28:	aa1a03e1 	mov	x1, x26
    9a2c:	910022a4 	add	x4, x21, #0x8
    9a30:	d2800000 	mov	x0, #0x0                   	// #0
    9a34:	14000009 	b	9a58 <fwp_hof0.constprop.0+0x10d8>
    9a38:	fc606861 	ldr	d1, [x3, x0]
    9a3c:	fd400420 	ldr	d0, [x1, #8]
    9a40:	1e613800 	fsub	d0, d0, d1
    9a44:	fc206840 	str	d0, [x2, x0]
    9a48:	91002000 	add	x0, x0, #0x8
    9a4c:	f9400821 	ldr	x1, [x1, #16]
    9a50:	eb0000ff 	cmp	x7, x0
    9a54:	54001480 	b.eq	9ce4 <fwp_hof0.constprop.0+0x1364>  // b.none
    9a58:	f94002a5 	ldr	x5, [x21]
    9a5c:	aa0403e3 	mov	x3, x4
    9a60:	b6fffec5 	tbz	x5, #63, 9a38 <fwp_hof0.constprop.0+0x10b8>
    9a64:	f9400aa3 	ldr	x3, [x21, #16]
    9a68:	17fffff4 	b	9a38 <fwp_hof0.constprop.0+0x10b8>
    9a6c:	aa0403e0 	mov	x0, x4
    9a70:	d37df2a2 	lsl	x2, x21, #3
    9a74:	52800001 	mov	w1, #0x0                   	// #0
    9a78:	f90033e8 	str	x8, [sp, #96]
    9a7c:	97ffe37d 	bl	2870 <memset@plt>
    9a80:	aa0003e4 	mov	x4, x0
    9a84:	f94033e8 	ldr	x8, [sp, #96]
    9a88:	17ffff1e 	b	9700 <fwp_hof0.constprop.0+0xd80>
    9a8c:	72003c1f 	tst	w0, #0xffff
    9a90:	54ffc3c1 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    9a94:	17fffe5d 	b	9408 <fwp_hof0.constprop.0+0xa88>
    9a98:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9a9c:	912e6000 	add	x0, x0, #0xb98
    9aa0:	97ffea25 	bl	4334 <fwp_trap>
    9aa4:	aa0803f5 	mov	x21, x8
    9aa8:	17fffeff 	b	96a4 <fwp_hof0.constprop.0+0xd24>
    9aac:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9ab0:	91378000 	add	x0, x0, #0xde0
    9ab4:	97ffea20 	bl	4334 <fwp_trap>
    9ab8:	aa1503e0 	mov	x0, x21
    9abc:	a903a7ea 	stp	x10, x9, [sp, #56]
    9ac0:	97ffea3d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9ac4:	a943a7ea 	ldp	x10, x9, [sp, #56]
    9ac8:	17fffdaa 	b	9170 <fwp_hof0.constprop.0+0x7f0>
    9acc:	72003c1f 	tst	w0, #0xffff
    9ad0:	54ffdd81 	b.ne	9680 <fwp_hof0.constprop.0+0xd00>  // b.any
    9ad4:	17fffee0 	b	9654 <fwp_hof0.constprop.0+0xcd4>
    9ad8:	aa1503e0 	mov	x0, x21
    9adc:	97ffea36 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9ae0:	17fffe86 	b	94f8 <fwp_hof0.constprop.0+0xb78>
    9ae4:	d2800004 	mov	x4, #0x0                   	// #0
    9ae8:	f10002bf 	cmp	x21, #0x0
    9aec:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9af0:	54ffe061 	b.ne	96fc <fwp_hof0.constprop.0+0xd7c>  // b.any
    9af4:	f9401be0 	ldr	x0, [sp, #48]
    9af8:	91014294 	add	x20, x20, #0x50
    9afc:	f94057e1 	ldr	x1, [sp, #168]
    9b00:	f901ca81 	str	x1, [x20, #912]
    9b04:	97ffe9a4 	bl	4194 <fwp_tape_buffers_release>
    9b08:	d0000123 	adrp	x3, 2f000 <fwp_fn_table+0xc90>
    9b0c:	f947e863 	ldr	x3, [x3, #4048]
    9b10:	d2800262 	mov	x2, #0x13                  	// #19
    9b14:	d2800021 	mov	x1, #0x1                   	// #1
    9b18:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9b1c:	91212000 	add	x0, x0, #0x848
    9b20:	f9400063 	ldr	x3, [x3]
    9b24:	97ffe39f 	bl	29a0 <fwrite@plt>
    9b28:	d2800000 	mov	x0, #0x0                   	// #0
    9b2c:	97ffe3a9 	bl	29d0 <fflush@plt>
    9b30:	52800cc0 	mov	w0, #0x66                  	// #102
    9b34:	97ffe3b7 	bl	2a10 <_Exit@plt>
    9b38:	ca404401 	eor	x1, x0, x0, lsr #17
    9b3c:	9118c2c3 	add	x3, x22, #0x630
    9b40:	ca412421 	eor	x1, x1, x1, lsr #9
    9b44:	92401c21 	and	x1, x1, #0xff
    9b48:	910a2422 	add	x2, x1, #0x289
    9b4c:	8b010c61 	add	x1, x3, x1, lsl #3
    9b50:	8b020c62 	add	x2, x3, x2, lsl #3
    9b54:	f94a2421 	ldr	x1, [x1, #5192]
    9b58:	b50000a1 	cbnz	x1, 9b6c <fwp_hof0.constprop.0+0x11ec>
    9b5c:	17ffffcf 	b	9a98 <fwp_hof0.constprop.0+0x1118>
    9b60:	91004022 	add	x2, x1, #0x10
    9b64:	f9400821 	ldr	x1, [x1, #16]
    9b68:	b4fff981 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x1118>
    9b6c:	f9400023 	ldr	x3, [x1]
    9b70:	eb00007f 	cmp	x3, x0
    9b74:	54ffff61 	b.ne	9b60 <fwp_hof0.constprop.0+0x11e0>  // b.any
    9b78:	f9400042 	ldr	x2, [x2]
    9b7c:	f9400441 	ldr	x1, [x2, #8]
    9b80:	d1000421 	sub	x1, x1, #0x1
    9b84:	f9000441 	str	x1, [x2, #8]
    9b88:	f103f83f 	cmp	x1, #0xfe
    9b8c:	54ffbbe1 	b.ne	9308 <fwp_hof0.constprop.0+0x988>  // b.any
    9b90:	39400001 	ldrb	w1, [x0]
    9b94:	7103fc3f 	cmp	w1, #0xff
    9b98:	540043e0 	b.eq	a414 <fwp_hof0.constprop.0+0x1a94>  // b.none
    9b9c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9ba0:	39000001 	strb	w1, [x0]
    9ba4:	17fffdd9 	b	9308 <fwp_hof0.constprop.0+0x988>
    9ba8:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9bac:	913ec000 	add	x0, x0, #0xfb0
    9bb0:	97ffe9e1 	bl	4334 <fwp_trap>
    9bb4:	b0000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    9bb8:	913f0000 	add	x0, x0, #0xfc0
    9bbc:	97ffe9de 	bl	4334 <fwp_trap>
    9bc0:	f9400ae4 	ldr	x4, [x23, #16]
    9bc4:	17ffff66 	b	995c <fwp_hof0.constprop.0+0xfdc>
    9bc8:	72003c1f 	tst	w0, #0xffff
    9bcc:	54ffeac0 	b.eq	9924 <fwp_hof0.constprop.0+0xfa4>  // b.none
    9bd0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9bd4:	eb00005f 	cmp	x2, x0
    9bd8:	54fffe88 	b.hi	9ba8 <fwp_hof0.constprop.0+0x1228>  // b.pmore
    9bdc:	91000440 	add	x0, x2, #0x1
    9be0:	52800021 	mov	w1, #0x1                   	// #1
    9be4:	f9001fe2 	str	x2, [sp, #56]
    9be8:	d37df000 	lsl	x0, x0, #3
    9bec:	97ffed49 	bl	5110 <fwp_heap_alloc>
    9bf0:	f9401fe2 	ldr	x2, [sp, #56]
    9bf4:	9118c2c4 	add	x4, x22, #0x630
    9bf8:	f9000002 	str	x2, [x0]
    9bfc:	aa0003f5 	mov	x21, x0
    9c00:	f949d881 	ldr	x1, [x4, #5040]
    9c04:	f949ec80 	ldr	x0, [x4, #5080]
    9c08:	cb0102a1 	sub	x1, x21, x1
    9c0c:	eb00403f 	cmp	x1, x0, lsl #16
    9c10:	54000322 	b.cs	9c74 <fwp_hof0.constprop.0+0x12f4>  // b.hs, b.nlast
    9c14:	d350fc23 	lsr	x3, x1, #16
    9c18:	d2800500 	mov	x0, #0x28                  	// #40
    9c1c:	f949fc87 	ldr	x7, [x4, #5112]
    9c20:	9b007c63 	mul	x3, x3, x0
    9c24:	8b0300e4 	add	x4, x7, x3
    9c28:	f9401080 	ldr	x0, [x4, #32]
    9c2c:	b4000240 	cbz	x0, 9c74 <fwp_hof0.constprop.0+0x12f4>
    9c30:	386368e3 	ldrb	w3, [x7, x3]
    9c34:	7100087f 	cmp	w3, #0x2
    9c38:	54003ce0 	b.eq	a3d4 <fwp_hof0.constprop.0+0x1a54>  // b.none
    9c3c:	7100047f 	cmp	w3, #0x1
    9c40:	540001a1 	b.ne	9c74 <fwp_hof0.constprop.0+0x12f4>  // b.any
    9c44:	29430c87 	ldp	w7, w3, [x4, #24]
    9c48:	92403c21 	and	x1, x1, #0xffff
    9c4c:	9b077c21 	mul	x1, x1, x7
    9c50:	d360fc21 	lsr	x1, x1, #32
    9c54:	eb03003f 	cmp	x1, x3
    9c58:	540000e2 	b.cs	9c74 <fwp_hof0.constprop.0+0x12f4>  // b.hs, b.nlast
    9c5c:	8b010000 	add	x0, x0, x1
    9c60:	39400001 	ldrb	w1, [x0]
    9c64:	7103fc3f 	cmp	w1, #0xff
    9c68:	54003ae0 	b.eq	a3c4 <fwp_hof0.constprop.0+0x1a44>  // b.none
    9c6c:	52800021 	mov	w1, #0x1                   	// #1
    9c70:	39000001 	strb	w1, [x0]
    9c74:	aa1703e0 	mov	x0, x23
    9c78:	17ffff30 	b	9938 <fwp_hof0.constprop.0+0xfb8>
    9c7c:	72003c1f 	tst	w0, #0xffff
    9c80:	54ffec40 	b.eq	9a08 <fwp_hof0.constprop.0+0x1088>  // b.none
    9c84:	b4003fda 	cbz	x26, a47c <fwp_hof0.constprop.0+0x1afc>
    9c88:	aa1a03e1 	mov	x1, x26
    9c8c:	d2800017 	mov	x23, #0x0                   	// #0
    9c90:	f9400821 	ldr	x1, [x1, #16]
    9c94:	aa1703e0 	mov	x0, x23
    9c98:	910006f7 	add	x23, x23, #0x1
    9c9c:	b5ffffa1 	cbnz	x1, 9c90 <fwp_hof0.constprop.0+0x1310>
    9ca0:	f9001fe3 	str	x3, [sp, #56]
    9ca4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9ca8:	eb0102ff 	cmp	x23, x1
    9cac:	54ff8d88 	b.hi	8e5c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    9cb0:	91000800 	add	x0, x0, #0x2
    9cb4:	52800041 	mov	w1, #0x2                   	// #2
    9cb8:	d37df000 	lsl	x0, x0, #3
    9cbc:	97ffed15 	bl	5110 <fwp_heap_alloc>
    9cc0:	f9401fe3 	ldr	x3, [sp, #56]
    9cc4:	aa1a03e1 	mov	x1, x26
    9cc8:	aa0003e2 	mov	x2, x0
    9ccc:	f9400424 	ldr	x4, [x1, #8]
    9cd0:	f8008404 	str	x4, [x0], #8
    9cd4:	f9400821 	ldr	x1, [x1, #16]
    9cd8:	b5ffffa1 	cbnz	x1, 9ccc <fwp_hof0.constprop.0+0x134c>
    9cdc:	52800008 	mov	w8, #0x0                   	// #0
    9ce0:	17ffff4e 	b	9a18 <fwp_hof0.constprop.0+0x1098>
    9ce4:	b40038ba 	cbz	x26, a3f8 <fwp_hof0.constprop.0+0x1a78>
    9ce8:	9118c2c0 	add	x0, x22, #0x630
    9cec:	aa1a03e7 	mov	x7, x26
    9cf0:	d2800004 	mov	x4, #0x0                   	// #0
    9cf4:	f949ec09 	ldr	x9, [x0, #5080]
    9cf8:	f949d80b 	ldr	x11, [x0, #5040]
    9cfc:	f949fc0c 	ldr	x12, [x0, #5112]
    9d00:	d370bd29 	lsl	x9, x9, #16
    9d04:	14000006 	b	9d1c <fwp_hof0.constprop.0+0x139c>
    9d08:	f94008e7 	ldr	x7, [x7, #16]
    9d0c:	91000484 	add	x4, x4, #0x1
    9d10:	f10000ff 	cmp	x7, #0x0
    9d14:	fa4412e0 	ccmp	x23, x4, #0x0, ne	// ne = any
    9d18:	54000329 	b.ls	9d7c <fwp_hof0.constprop.0+0x13fc>  // b.plast
    9d1c:	cb0b00e0 	sub	x0, x7, x11
    9d20:	eb09001f 	cmp	x0, x9
    9d24:	540002c2 	b.cs	9d7c <fwp_hof0.constprop.0+0x13fc>  // b.hs, b.nlast
    9d28:	d350fc01 	lsr	x1, x0, #16
    9d2c:	8b010821 	add	x1, x1, x1, lsl #2
    9d30:	d37df021 	lsl	x1, x1, #3
    9d34:	8b010185 	add	x5, x12, x1
    9d38:	f94010a3 	ldr	x3, [x5, #32]
    9d3c:	b4000203 	cbz	x3, 9d7c <fwp_hof0.constprop.0+0x13fc>
    9d40:	38616981 	ldrb	w1, [x12, x1]
    9d44:	7100083f 	cmp	w1, #0x2
    9d48:	54002500 	b.eq	a1e8 <fwp_hof0.constprop.0+0x1868>  // b.none
    9d4c:	7100043f 	cmp	w1, #0x1
    9d50:	54000161 	b.ne	9d7c <fwp_hof0.constprop.0+0x13fc>  // b.any
    9d54:	294304a6 	ldp	w6, w1, [x5, #24]
    9d58:	92403c00 	and	x0, x0, #0xffff
    9d5c:	9b067c00 	mul	x0, x0, x6
    9d60:	d360fc00 	lsr	x0, x0, #32
    9d64:	eb01001f 	cmp	x0, x1
    9d68:	540000a2 	b.cs	9d7c <fwp_hof0.constprop.0+0x13fc>  // b.hs, b.nlast
    9d6c:	8b000063 	add	x3, x3, x0
    9d70:	39400060 	ldrb	w0, [x3]
    9d74:	7100041f 	cmp	w0, #0x1
    9d78:	54fffc80 	b.eq	9d08 <fwp_hof0.constprop.0+0x1388>  // b.none
    9d7c:	d2800003 	mov	x3, #0x0                   	// #0
    9d80:	eb0402ff 	cmp	x23, x4
    9d84:	54002fe9 	b.ls	a380 <fwp_hof0.constprop.0+0x1a00>  // b.plast
    9d88:	d1002040 	sub	x0, x2, #0x8
    9d8c:	9118c2ca 	add	x10, x22, #0x630
    9d90:	d2800003 	mov	x3, #0x0                   	// #0
    9d94:	a9046be0 	stp	x0, x26, [sp, #64]
    9d98:	9103e3e0 	add	x0, sp, #0xf8
    9d9c:	aa0403fa 	mov	x26, x4
    9da0:	f9001fe0 	str	x0, [sp, #56]
    9da4:	f9002be2 	str	x2, [sp, #80]
    9da8:	b9005be8 	str	w8, [sp, #88]
    9dac:	a9064ff5 	stp	x21, x19, [sp, #96]
    9db0:	aa1703f3 	mov	x19, x23
    9db4:	aa0a03f5 	mov	x21, x10
    9db8:	14000012 	b	9e00 <fwp_hof0.constprop.0+0x1480>
    9dbc:	7100045f 	cmp	w2, #0x1
    9dc0:	540001a1 	b.ne	9df4 <fwp_hof0.constprop.0+0x1474>  // b.any
    9dc4:	29430885 	ldp	w5, w2, [x4, #24]
    9dc8:	92403c21 	and	x1, x1, #0xffff
    9dcc:	9b057c21 	mul	x1, x1, x5
    9dd0:	d360fc21 	lsr	x1, x1, #32
    9dd4:	eb02003f 	cmp	x1, x2
    9dd8:	540000e2 	b.cs	9df4 <fwp_hof0.constprop.0+0x1474>  // b.hs, b.nlast
    9ddc:	8b010000 	add	x0, x0, x1
    9de0:	39400001 	ldrb	w1, [x0]
    9de4:	7103fc3f 	cmp	w1, #0xff
    9de8:	54002e60 	b.eq	a3b4 <fwp_hof0.constprop.0+0x1a34>  // b.none
    9dec:	52800021 	mov	w1, #0x1                   	// #1
    9df0:	39000001 	strb	w1, [x0]
    9df4:	d1000673 	sub	x19, x19, #0x1
    9df8:	eb1a027f 	cmp	x19, x26
    9dfc:	54000329 	b.ls	9e60 <fwp_hof0.constprop.0+0x14e0>  // b.plast
    9e00:	a94383e1 	ldp	x1, x0, [sp, #56]
    9e04:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9e08:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9e0c:	52800020 	mov	w0, #0x1                   	// #1
    9e10:	97ffed24 	bl	52a0 <fwp_data.part.0.constprop.0>
    9e14:	aa0003e3 	mov	x3, x0
    9e18:	f949daa1 	ldr	x1, [x21, #5040]
    9e1c:	f949eea0 	ldr	x0, [x21, #5080]
    9e20:	cb010061 	sub	x1, x3, x1
    9e24:	eb00403f 	cmp	x1, x0, lsl #16
    9e28:	54fffe62 	b.cs	9df4 <fwp_hof0.constprop.0+0x1474>  // b.hs, b.nlast
    9e2c:	d350fc20 	lsr	x0, x1, #16
    9e30:	f949fea5 	ldr	x5, [x21, #5112]
    9e34:	8b000800 	add	x0, x0, x0, lsl #2
    9e38:	d37df002 	lsl	x2, x0, #3
    9e3c:	8b0200a4 	add	x4, x5, x2
    9e40:	f9401080 	ldr	x0, [x4, #32]
    9e44:	b4fffd80 	cbz	x0, 9df4 <fwp_hof0.constprop.0+0x1474>
    9e48:	386268a2 	ldrb	w2, [x5, x2]
    9e4c:	7100085f 	cmp	w2, #0x2
    9e50:	54fffb61 	b.ne	9dbc <fwp_hof0.constprop.0+0x143c>  // b.any
    9e54:	72003c3f 	tst	w1, #0xffff
    9e58:	54fffce1 	b.ne	9df4 <fwp_hof0.constprop.0+0x1474>  // b.any
    9e5c:	17ffffe1 	b	9de0 <fwp_hof0.constprop.0+0x1460>
    9e60:	d10006e1 	sub	x1, x23, #0x1
    9e64:	cb170340 	sub	x0, x26, x23
    9e68:	eb1a003f 	cmp	x1, x26
    9e6c:	aa1a03e4 	mov	x4, x26
    9e70:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    9e74:	b9405be8 	ldr	w8, [sp, #88]
    9e78:	a9448bfa 	ldp	x26, x2, [sp, #72]
    9e7c:	8b010000 	add	x0, x0, x1
    9e80:	a9464ff5 	ldp	x21, x19, [sp, #96]
    9e84:	b50027e4 	cbnz	x4, a380 <fwp_hof0.constprop.0+0x1a00>
    9e88:	7100011f 	cmp	w8, #0x0
    9e8c:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9e90:	b4002680 	cbz	x0, a360 <fwp_hof0.constprop.0+0x19e0>
    9e94:	d1000417 	sub	x23, x0, #0x1
    9e98:	9118c2c7 	add	x7, x22, #0x630
    9e9c:	a9044ff5 	stp	x21, x19, [sp, #64]
    9ea0:	aa1703f5 	mov	x21, x23
    9ea4:	aa0203f3 	mov	x19, x2
    9ea8:	f9002bf9 	str	x25, [sp, #80]
    9eac:	aa0703f9 	mov	x25, x7
    9eb0:	14000012 	b	9ef8 <fwp_hof0.constprop.0+0x1578>
    9eb4:	7100049f 	cmp	w4, #0x1
    9eb8:	540001a1 	b.ne	9eec <fwp_hof0.constprop.0+0x156c>  // b.any
    9ebc:	29430004 	ldp	w4, w0, [x0, #24]
    9ec0:	92403c21 	and	x1, x1, #0xffff
    9ec4:	9b047c21 	mul	x1, x1, x4
    9ec8:	d360fc21 	lsr	x1, x1, #32
    9ecc:	eb00003f 	cmp	x1, x0
    9ed0:	540000e2 	b.cs	9eec <fwp_hof0.constprop.0+0x156c>  // b.hs, b.nlast
    9ed4:	8b0102f7 	add	x23, x23, x1
    9ed8:	394002e0 	ldrb	w0, [x23]
    9edc:	7103fc1f 	cmp	w0, #0xff
    9ee0:	54002460 	b.eq	a36c <fwp_hof0.constprop.0+0x19ec>  // b.none
    9ee4:	52800020 	mov	w0, #0x1                   	// #1
    9ee8:	390002e0 	strb	w0, [x23]
    9eec:	d10006b5 	sub	x21, x21, #0x1
    9ef0:	b10006bf 	cmn	x21, #0x1
    9ef4:	54000320 	b.eq	9f58 <fwp_hof0.constprop.0+0x15d8>  // b.none
    9ef8:	f9401fe1 	ldr	x1, [sp, #56]
    9efc:	f8757a60 	ldr	x0, [x19, x21, lsl #3]
    9f00:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9f04:	52800020 	mov	w0, #0x1                   	// #1
    9f08:	97ffece6 	bl	52a0 <fwp_data.part.0.constprop.0>
    9f0c:	aa0003e3 	mov	x3, x0
    9f10:	f949db21 	ldr	x1, [x25, #5040]
    9f14:	f949ef20 	ldr	x0, [x25, #5080]
    9f18:	cb010061 	sub	x1, x3, x1
    9f1c:	eb00403f 	cmp	x1, x0, lsl #16
    9f20:	54fffe62 	b.cs	9eec <fwp_hof0.constprop.0+0x156c>  // b.hs, b.nlast
    9f24:	d350fc20 	lsr	x0, x1, #16
    9f28:	f949ff26 	ldr	x6, [x25, #5112]
    9f2c:	8b000800 	add	x0, x0, x0, lsl #2
    9f30:	d37df004 	lsl	x4, x0, #3
    9f34:	8b0400c0 	add	x0, x6, x4
    9f38:	f9401017 	ldr	x23, [x0, #32]
    9f3c:	b4fffd97 	cbz	x23, 9eec <fwp_hof0.constprop.0+0x156c>
    9f40:	386468c4 	ldrb	w4, [x6, x4]
    9f44:	7100089f 	cmp	w4, #0x2
    9f48:	54fffb61 	b.ne	9eb4 <fwp_hof0.constprop.0+0x1534>  // b.any
    9f4c:	72003c3f 	tst	w1, #0xffff
    9f50:	54fffce1 	b.ne	9eec <fwp_hof0.constprop.0+0x156c>  // b.any
    9f54:	17ffffe1 	b	9ed8 <fwp_hof0.constprop.0+0x1558>
    9f58:	aa1303e2 	mov	x2, x19
    9f5c:	aa1a03f7 	mov	x23, x26
    9f60:	a9444ff5 	ldp	x21, x19, [sp, #64]
    9f64:	aa0303fa 	mov	x26, x3
    9f68:	f9402bf9 	ldr	x25, [sp, #80]
    9f6c:	aa0203e0 	mov	x0, x2
    9f70:	97ffe9ac 	bl	4620 <fwp_mem_free>
    9f74:	f9001ff9 	str	x25, [sp, #56]
    9f78:	9118c2c4 	add	x4, x22, #0x630
    9f7c:	aa1303f9 	mov	x25, x19
    9f80:	aa0403f3 	mov	x19, x4
    9f84:	d2800507 	mov	x7, #0x28                  	// #40
    9f88:	f949da61 	ldr	x1, [x19, #5040]
    9f8c:	f949ee60 	ldr	x0, [x19, #5080]
    9f90:	cb0102a1 	sub	x1, x21, x1
    9f94:	eb00403f 	cmp	x1, x0, lsl #16
    9f98:	54001222 	b.cs	a1dc <fwp_hof0.constprop.0+0x185c>  // b.hs, b.nlast
    9f9c:	d350fc22 	lsr	x2, x1, #16
    9fa0:	f949fe63 	ldr	x3, [x19, #5112]
    9fa4:	9b077c42 	mul	x2, x2, x7
    9fa8:	8b020068 	add	x8, x3, x2
    9fac:	f9401100 	ldr	x0, [x8, #32]
    9fb0:	b4001160 	cbz	x0, a1dc <fwp_hof0.constprop.0+0x185c>
    9fb4:	38626863 	ldrb	w3, [x3, x2]
    9fb8:	7100087f 	cmp	w3, #0x2
    9fbc:	540010c0 	b.eq	a1d4 <fwp_hof0.constprop.0+0x1854>  // b.none
    9fc0:	7100047f 	cmp	w3, #0x1
    9fc4:	540010c1 	b.ne	a1dc <fwp_hof0.constprop.0+0x185c>  // b.any
    9fc8:	29431502 	ldp	w2, w5, [x8, #24]
    9fcc:	92403c21 	and	x1, x1, #0xffff
    9fd0:	9b027c22 	mul	x2, x1, x2
    9fd4:	d360fc42 	lsr	x2, x2, #32
    9fd8:	eb05005f 	cmp	x2, x5
    9fdc:	54001002 	b.cs	a1dc <fwp_hof0.constprop.0+0x185c>  // b.hs, b.nlast
    9fe0:	8b020000 	add	x0, x0, x2
    9fe4:	39400002 	ldrb	w2, [x0]
    9fe8:	34000fa2 	cbz	w2, a1dc <fwp_hof0.constprop.0+0x185c>
    9fec:	7100045f 	cmp	w2, #0x1
    9ff0:	54000d60 	b.eq	a19c <fwp_hof0.constprop.0+0x181c>  // b.none
    9ff4:	aa1903f3 	mov	x19, x25
    9ff8:	f9401ff9 	ldr	x25, [sp, #56]
    9ffc:	7103fc5f 	cmp	w2, #0xff
    a000:	54002120 	b.eq	a424 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    a004:	51000442 	sub	w2, w2, #0x1
    a008:	39000002 	strb	w2, [x0]
    a00c:	9118c2c4 	add	x4, x22, #0x630
    a010:	f9001ff9 	str	x25, [sp, #56]
    a014:	aa1303f9 	mov	x25, x19
    a018:	aa0403f3 	mov	x19, x4
    a01c:	d2800507 	mov	x7, #0x28                  	// #40
    a020:	f949da60 	ldr	x0, [x19, #5040]
    a024:	f949ee61 	ldr	x1, [x19, #5080]
    a028:	cb0002e0 	sub	x0, x23, x0
    a02c:	eb01401f 	cmp	x0, x1, lsl #16
    a030:	54000b02 	b.cs	a190 <fwp_hof0.constprop.0+0x1810>  // b.hs, b.nlast
    a034:	d350fc01 	lsr	x1, x0, #16
    a038:	f949fe62 	ldr	x2, [x19, #5112]
    a03c:	9b077c21 	mul	x1, x1, x7
    a040:	8b010043 	add	x3, x2, x1
    a044:	f9401075 	ldr	x21, [x3, #32]
    a048:	b4000a55 	cbz	x21, a190 <fwp_hof0.constprop.0+0x1810>
    a04c:	38616845 	ldrb	w5, [x2, x1]
    a050:	710008bf 	cmp	w5, #0x2
    a054:	540009a0 	b.eq	a188 <fwp_hof0.constprop.0+0x1808>  // b.none
    a058:	710004bf 	cmp	w5, #0x1
    a05c:	540009a1 	b.ne	a190 <fwp_hof0.constprop.0+0x1810>  // b.any
    a060:	29430861 	ldp	w1, w2, [x3, #24]
    a064:	92403c00 	and	x0, x0, #0xffff
    a068:	9b017c01 	mul	x1, x0, x1
    a06c:	d360fc21 	lsr	x1, x1, #32
    a070:	eb02003f 	cmp	x1, x2
    a074:	540008e2 	b.cs	a190 <fwp_hof0.constprop.0+0x1810>  // b.hs, b.nlast
    a078:	8b0102b5 	add	x21, x21, x1
    a07c:	394002a2 	ldrb	w2, [x21]
    a080:	34000882 	cbz	w2, a190 <fwp_hof0.constprop.0+0x1810>
    a084:	7100045f 	cmp	w2, #0x1
    a088:	540012c0 	b.eq	a2e0 <fwp_hof0.constprop.0+0x1960>  // b.none
    a08c:	aa1903f3 	mov	x19, x25
    a090:	f9401ff9 	ldr	x25, [sp, #56]
    a094:	7103fc5f 	cmp	w2, #0xff
    a098:	54001060 	b.eq	a2a4 <fwp_hof0.constprop.0+0x1924>  // b.none
    a09c:	51000442 	sub	w2, w2, #0x1
    a0a0:	390002a2 	strb	w2, [x21]
    a0a4:	f9400be0 	ldr	x0, [sp, #16]
    a0a8:	b4ff6f60 	cbz	x0, 8e94 <fwp_hof0.constprop.0+0x514>
    a0ac:	f9400be0 	ldr	x0, [sp, #16]
    a0b0:	f1000400 	subs	x0, x0, #0x1
    a0b4:	f9000be0 	str	x0, [sp, #16]
    a0b8:	540022a6 	b.vs	a50c <fwp_hof0.constprop.0+0x1b8c>
    a0bc:	9118c2c0 	add	x0, x22, #0x630
    a0c0:	f949ec04 	ldr	x4, [x0, #5080]
    a0c4:	f949d801 	ldr	x1, [x0, #5040]
    a0c8:	d370bc84 	lsl	x4, x4, #16
    a0cc:	17fffa77 	b	8aa8 <fwp_hof0.constprop.0+0x128>
    a0d0:	90000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    a0d4:	913fa000 	add	x0, x0, #0xfe8
    a0d8:	97ffe897 	bl	4334 <fwp_trap>
    a0dc:	aa1903e0 	mov	x0, x25
    a0e0:	97ffef4d 	bl	5e14 <fwp_rc_free_arr>
    a0e4:	17fffbe0 	b	9064 <fwp_hof0.constprop.0+0x6e4>
    a0e8:	72003c3f 	tst	w1, #0xffff
    a0ec:	54ff7bc1 	b.ne	9064 <fwp_hof0.constprop.0+0x6e4>  // b.any
    a0f0:	17fffbd5 	b	9044 <fwp_hof0.constprop.0+0x6c4>
    a0f4:	72003c3f 	tst	w1, #0xffff
    a0f8:	54ff75a1 	b.ne	8fac <fwp_hof0.constprop.0+0x62c>  // b.any
    a0fc:	17fffba7 	b	8f98 <fwp_hof0.constprop.0+0x618>
    a100:	f9000be0 	str	x0, [sp, #16]
    a104:	f90013e3 	str	x3, [sp, #32]
    a108:	97ffe8ab 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a10c:	f9400be0 	ldr	x0, [sp, #16]
    a110:	f94013e3 	ldr	x3, [sp, #32]
    a114:	17fffba4 	b	8fa4 <fwp_hof0.constprop.0+0x624>
    a118:	ca5546a1 	eor	x1, x21, x21, lsr #17
    a11c:	9118c2c2 	add	x2, x22, #0x630
    a120:	ca412421 	eor	x1, x1, x1, lsr #9
    a124:	92401c21 	and	x1, x1, #0xff
    a128:	910a2420 	add	x0, x1, #0x289
    a12c:	8b010c41 	add	x1, x2, x1, lsl #3
    a130:	8b000c40 	add	x0, x2, x0, lsl #3
    a134:	f94a2421 	ldr	x1, [x1, #5192]
    a138:	b50000a1 	cbnz	x1, a14c <fwp_hof0.constprop.0+0x17cc>
    a13c:	17fffe57 	b	9a98 <fwp_hof0.constprop.0+0x1118>
    a140:	91004020 	add	x0, x1, #0x10
    a144:	f9400821 	ldr	x1, [x1, #16]
    a148:	b4ffca81 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x1118>
    a14c:	f9400022 	ldr	x2, [x1]
    a150:	eb15005f 	cmp	x2, x21
    a154:	54ffff61 	b.ne	a140 <fwp_hof0.constprop.0+0x17c0>  // b.any
    a158:	f9400001 	ldr	x1, [x0]
    a15c:	f9400420 	ldr	x0, [x1, #8]
    a160:	d1000400 	sub	x0, x0, #0x1
    a164:	f9000420 	str	x0, [x1, #8]
    a168:	f103f81f 	cmp	x0, #0xfe
    a16c:	54ff77c1 	b.ne	9064 <fwp_hof0.constprop.0+0x6e4>  // b.any
    a170:	394002a0 	ldrb	w0, [x21]
    a174:	7103fc1f 	cmp	w0, #0xff
    a178:	54000e80 	b.eq	a348 <fwp_hof0.constprop.0+0x19c8>  // b.none
    a17c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a180:	390002a0 	strb	w0, [x21]
    a184:	17fffbb8 	b	9064 <fwp_hof0.constprop.0+0x6e4>
    a188:	f2403c00 	ands	x0, x0, #0xffff
    a18c:	54fff780 	b.eq	a07c <fwp_hof0.constprop.0+0x16fc>  // b.none
    a190:	aa1903f3 	mov	x19, x25
    a194:	f9401ff9 	ldr	x25, [sp, #56]
    a198:	17ffffc3 	b	a0a4 <fwp_hof0.constprop.0+0x1724>
    a19c:	f94002a2 	ldr	x2, [x21]
    a1a0:	aa1503e0 	mov	x0, x21
    a1a4:	b7f817c2 	tbnz	x2, #63, a49c <fwp_hof0.constprop.0+0x1b1c>
    a1a8:	aa1903f3 	mov	x19, x25
    a1ac:	f9401ff9 	ldr	x25, [sp, #56]
    a1b0:	7100087f 	cmp	w3, #0x2
    a1b4:	54001560 	b.eq	a460 <fwp_hof0.constprop.0+0x1ae0>  // b.none
    a1b8:	29430102 	ldp	w2, w0, [x8, #24]
    a1bc:	9b027c21 	mul	x1, x1, x2
    a1c0:	eb41801f 	cmp	x0, x1, lsr #32
    a1c4:	54fff249 	b.ls	a00c <fwp_hof0.constprop.0+0x168c>  // b.plast
    a1c8:	aa1503e0 	mov	x0, x21
    a1cc:	97ffe915 	bl	4620 <fwp_mem_free>
    a1d0:	17ffff8f 	b	a00c <fwp_hof0.constprop.0+0x168c>
    a1d4:	f2403c21 	ands	x1, x1, #0xffff
    a1d8:	54fff060 	b.eq	9fe4 <fwp_hof0.constprop.0+0x1664>  // b.none
    a1dc:	aa1903f3 	mov	x19, x25
    a1e0:	f9401ff9 	ldr	x25, [sp, #56]
    a1e4:	17ffff8a 	b	a00c <fwp_hof0.constprop.0+0x168c>
    a1e8:	72003c1f 	tst	w0, #0xffff
    a1ec:	54ffdc81 	b.ne	9d7c <fwp_hof0.constprop.0+0x13fc>  // b.any
    a1f0:	17fffee0 	b	9d70 <fwp_hof0.constprop.0+0x13f0>
    a1f4:	72003c3f 	tst	w1, #0xffff
    a1f8:	54ffb4e1 	b.ne	9894 <fwp_hof0.constprop.0+0xf14>  // b.any
    a1fc:	17fffda1 	b	9880 <fwp_hof0.constprop.0+0xf00>
    a200:	d1000521 	sub	x1, x9, #0x1
    a204:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a208:	eb00003f 	cmp	x1, x0
    a20c:	54000408 	b.hi	a28c <fwp_hof0.constprop.0+0x190c>  // b.pmore
    a210:	d0000320 	adrp	x0, 70000 <ad_raw_checkpoints+0x2fbb0>
    a214:	d2800003 	mov	x3, #0x0                   	// #0
    a218:	91114001 	add	x1, x0, #0x450
    a21c:	14000005 	b	a230 <fwp_hof0.constprop.0+0x18b0>
    a220:	91000463 	add	x3, x3, #0x1
    a224:	91006021 	add	x1, x1, #0x18
    a228:	f140047f 	cmp	x3, #0x1, lsl #12
    a22c:	54000360 	b.eq	a298 <fwp_hof0.constprop.0+0x1918>  // b.none
    a230:	f9400022 	ldr	x2, [x1]
    a234:	b5ffff62 	cbnz	x2, a220 <fwp_hof0.constprop.0+0x18a0>
    a238:	91114002 	add	x2, x0, #0x450
    a23c:	d2800304 	mov	x4, #0x18                  	// #24
    a240:	aa0903e0 	mov	x0, x9
    a244:	d2800101 	mov	x1, #0x8                   	// #8
    a248:	f9003be8 	str	x8, [sp, #112]
    a24c:	9b040862 	madd	x2, x3, x4, x2
    a250:	a90627e2 	stp	x2, x9, [sp, #96]
    a254:	97ffe18b 	bl	2880 <calloc@plt>
    a258:	aa0003e4 	mov	x4, x0
    a25c:	a946a3e9 	ldp	x9, x8, [sp, #104]
    a260:	b4ffc420 	cbz	x0, 9ae4 <fwp_hof0.constprop.0+0x1164>
    a264:	aa0003e1 	mov	x1, x0
    a268:	d37df122 	lsl	x2, x9, #3
    a26c:	f94033e0 	ldr	x0, [sp, #96]
    a270:	52800063 	mov	w3, #0x3                   	// #3
    a274:	a90627e4 	stp	x4, x9, [sp, #96]
    a278:	f9003be8 	str	x8, [sp, #112]
    a27c:	97ffe345 	bl	2f90 <ad_raw_record>
    a280:	a94627e4 	ldp	x4, x9, [sp, #96]
    a284:	f9403be8 	ldr	x8, [sp, #112]
    a288:	17fffd1b 	b	96f4 <fwp_hof0.constprop.0+0xd74>
    a28c:	90000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    a290:	913e4000 	add	x0, x0, #0xf90
    a294:	97ffe43b 	bl	3380 <ad_raw_fail>
    a298:	90000020 	adrp	x0, e000 <fwp_main_thread+0x1470>
    a29c:	912b2000 	add	x0, x0, #0xac8
    a2a0:	97ffe438 	bl	3380 <ad_raw_fail>
    a2a4:	ca5546a1 	eor	x1, x21, x21, lsr #17
    a2a8:	9118c2c0 	add	x0, x22, #0x630
    a2ac:	ca412421 	eor	x1, x1, x1, lsr #9
    a2b0:	92401c21 	and	x1, x1, #0xff
    a2b4:	910a2422 	add	x2, x1, #0x289
    a2b8:	8b010c01 	add	x1, x0, x1, lsl #3
    a2bc:	8b020c02 	add	x2, x0, x2, lsl #3
    a2c0:	f94a2420 	ldr	x0, [x1, #5192]
    a2c4:	b4ffbea0 	cbz	x0, 9a98 <fwp_hof0.constprop.0+0x1118>
    a2c8:	f9400001 	ldr	x1, [x0]
    a2cc:	eb0102bf 	cmp	x21, x1
    a2d0:	54000240 	b.eq	a318 <fwp_hof0.constprop.0+0x1998>  // b.none
    a2d4:	91004002 	add	x2, x0, #0x10
    a2d8:	f9400800 	ldr	x0, [x0, #16]
    a2dc:	17fffffa 	b	a2c4 <fwp_hof0.constprop.0+0x1944>
    a2e0:	aa1703e1 	mov	x1, x23
    a2e4:	f9400af7 	ldr	x23, [x23, #16]
    a2e8:	710008bf 	cmp	w5, #0x2
    a2ec:	54000120 	b.eq	a310 <fwp_hof0.constprop.0+0x1990>  // b.none
    a2f0:	29430865 	ldp	w5, w2, [x3, #24]
    a2f4:	9b057c00 	mul	x0, x0, x5
    a2f8:	eb40805f 	cmp	x2, x0, lsr #32
    a2fc:	54ffe929 	b.ls	a020 <fwp_hof0.constprop.0+0x16a0>  // b.plast
    a300:	aa0103e0 	mov	x0, x1
    a304:	97ffe8c7 	bl	4620 <fwp_mem_free>
    a308:	d2800507 	mov	x7, #0x28                  	// #40
    a30c:	17ffff45 	b	a020 <fwp_hof0.constprop.0+0x16a0>
    a310:	b5ffe880 	cbnz	x0, a020 <fwp_hof0.constprop.0+0x16a0>
    a314:	17fffffb 	b	a300 <fwp_hof0.constprop.0+0x1980>
    a318:	f9400041 	ldr	x1, [x2]
    a31c:	f9400420 	ldr	x0, [x1, #8]
    a320:	d1000400 	sub	x0, x0, #0x1
    a324:	f9000420 	str	x0, [x1, #8]
    a328:	f103f81f 	cmp	x0, #0xfe
    a32c:	54ffebc1 	b.ne	a0a4 <fwp_hof0.constprop.0+0x1724>  // b.any
    a330:	394002a0 	ldrb	w0, [x21]
    a334:	7103fc1f 	cmp	w0, #0xff
    a338:	540000e0 	b.eq	a354 <fwp_hof0.constprop.0+0x19d4>  // b.none
    a33c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a340:	390002a0 	strb	w0, [x21]
    a344:	17ffff58 	b	a0a4 <fwp_hof0.constprop.0+0x1724>
    a348:	aa1503e0 	mov	x0, x21
    a34c:	97ffe81a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a350:	17ffff8b 	b	a17c <fwp_hof0.constprop.0+0x17fc>
    a354:	aa1503e0 	mov	x0, x21
    a358:	97ffe817 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a35c:	17fffff8 	b	a33c <fwp_hof0.constprop.0+0x19bc>
    a360:	aa1a03f7 	mov	x23, x26
    a364:	aa0303fa 	mov	x26, x3
    a368:	17ffff01 	b	9f6c <fwp_hof0.constprop.0+0x15ec>
    a36c:	aa1703e0 	mov	x0, x23
    a370:	f9002fe3 	str	x3, [sp, #88]
    a374:	97ffe810 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a378:	f9402fe3 	ldr	x3, [sp, #88]
    a37c:	17fffeda 	b	9ee4 <fwp_hof0.constprop.0+0x1564>
    a380:	aa1a03f7 	mov	x23, x26
    a384:	d2800000 	mov	x0, #0x0                   	// #0
    a388:	f8607841 	ldr	x1, [x2, x0, lsl #3]
    a38c:	91000400 	add	x0, x0, #0x1
    a390:	f90006e1 	str	x1, [x23, #8]
    a394:	aa1703e1 	mov	x1, x23
    a398:	f9400af7 	ldr	x23, [x23, #16]
    a39c:	eb00009f 	cmp	x4, x0
    a3a0:	54ffff48 	b.hi	a388 <fwp_hof0.constprop.0+0x1a08>  // b.pmore
    a3a4:	f9000823 	str	x3, [x1, #16]
    a3a8:	7100011f 	cmp	w8, #0x0
    a3ac:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    a3b0:	17fffeef 	b	9f6c <fwp_hof0.constprop.0+0x15ec>
    a3b4:	a9070fe0 	stp	x0, x3, [sp, #112]
    a3b8:	97ffe7ff 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a3bc:	a9470fe0 	ldp	x0, x3, [sp, #112]
    a3c0:	17fffe8b 	b	9dec <fwp_hof0.constprop.0+0x146c>
    a3c4:	a9038be0 	stp	x0, x2, [sp, #56]
    a3c8:	97ffe7fb 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a3cc:	a9438be0 	ldp	x0, x2, [sp, #56]
    a3d0:	17fffe27 	b	9c6c <fwp_hof0.constprop.0+0x12ec>
    a3d4:	72003c3f 	tst	w1, #0xffff
    a3d8:	54ffc440 	b.eq	9c60 <fwp_hof0.constprop.0+0x12e0>  // b.none
    a3dc:	aa1703e0 	mov	x0, x23
    a3e0:	17fffd56 	b	9938 <fwp_hof0.constprop.0+0xfb8>
    a3e4:	a91253f3 	stp	x19, x20, [sp, #288]
    a3e8:	a9135bf5 	stp	x21, x22, [sp, #304]
    a3ec:	a91463f7 	stp	x23, x24, [sp, #320]
    a3f0:	a9156bf9 	stp	x25, x26, [sp, #336]
    a3f4:	97ffe12b 	bl	28a0 <__stack_chk_fail@plt>
    a3f8:	d2800004 	mov	x4, #0x0                   	// #0
    a3fc:	17fffe63 	b	9d88 <fwp_hof0.constprop.0+0x1408>
    a400:	aa1503e0 	mov	x0, x21
    a404:	97ffe7ec 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a408:	91014280 	add	x0, x20, #0x50
    a40c:	f941c804 	ldr	x4, [x0, #912]
    a410:	17fffd1f 	b	988c <fwp_hof0.constprop.0+0xf0c>
    a414:	f9001fe0 	str	x0, [sp, #56]
    a418:	97ffe7e7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a41c:	f9401fe0 	ldr	x0, [sp, #56]
    a420:	17fffddf 	b	9b9c <fwp_hof0.constprop.0+0x121c>
    a424:	ca404401 	eor	x1, x0, x0, lsr #17
    a428:	9118c2c3 	add	x3, x22, #0x630
    a42c:	ca412421 	eor	x1, x1, x1, lsr #9
    a430:	92401c21 	and	x1, x1, #0xff
    a434:	910a2422 	add	x2, x1, #0x289
    a438:	8b010c61 	add	x1, x3, x1, lsl #3
    a43c:	8b020c62 	add	x2, x3, x2, lsl #3
    a440:	f94a2421 	ldr	x1, [x1, #5192]
    a444:	b4ffb2a1 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x1118>
    a448:	f9400023 	ldr	x3, [x1]
    a44c:	eb03001f 	cmp	x0, x3
    a450:	540003a0 	b.eq	a4c4 <fwp_hof0.constprop.0+0x1b44>  // b.none
    a454:	91004022 	add	x2, x1, #0x10
    a458:	f9400821 	ldr	x1, [x1, #16]
    a45c:	17fffffa 	b	a444 <fwp_hof0.constprop.0+0x1ac4>
    a460:	b5ffdd61 	cbnz	x1, a00c <fwp_hof0.constprop.0+0x168c>
    a464:	17ffff59 	b	a1c8 <fwp_hof0.constprop.0+0x1848>
    a468:	f94002a3 	ldr	x3, [x21]
    a46c:	b7f80083 	tbnz	x3, #63, a47c <fwp_hof0.constprop.0+0x1afc>
    a470:	9240f863 	and	x3, x3, #0x7fffffffffffffff
    a474:	d2800017 	mov	x23, #0x0                   	// #0
    a478:	17fffd4b 	b	99a4 <fwp_hof0.constprop.0+0x1024>
    a47c:	52800041 	mov	w1, #0x2                   	// #2
    a480:	d2800100 	mov	x0, #0x8                   	// #8
    a484:	97ffeb23 	bl	5110 <fwp_heap_alloc>
    a488:	aa0003e2 	mov	x2, x0
    a48c:	52800008 	mov	w8, #0x0                   	// #0
    a490:	aa1a03f7 	mov	x23, x26
    a494:	d280001a 	mov	x26, #0x0                   	// #0
    a498:	17ffffc4 	b	a3a8 <fwp_hof0.constprop.0+0x1a28>
    a49c:	f94006b5 	ldr	x21, [x21, #8]
    a4a0:	7100087f 	cmp	w3, #0x2
    a4a4:	54000280 	b.eq	a4f4 <fwp_hof0.constprop.0+0x1b74>  // b.none
    a4a8:	29430903 	ldp	w3, w2, [x8, #24]
    a4ac:	9b037c21 	mul	x1, x1, x3
    a4b0:	eb41805f 	cmp	x2, x1, lsr #32
    a4b4:	54ffd6a9 	b.ls	9f88 <fwp_hof0.constprop.0+0x1608>  // b.plast
    a4b8:	97ffe85a 	bl	4620 <fwp_mem_free>
    a4bc:	d2800507 	mov	x7, #0x28                  	// #40
    a4c0:	17fffeb2 	b	9f88 <fwp_hof0.constprop.0+0x1608>
    a4c4:	f9400042 	ldr	x2, [x2]
    a4c8:	f9400441 	ldr	x1, [x2, #8]
    a4cc:	d1000421 	sub	x1, x1, #0x1
    a4d0:	f9000441 	str	x1, [x2, #8]
    a4d4:	f103f83f 	cmp	x1, #0xfe
    a4d8:	54ffd9a1 	b.ne	a00c <fwp_hof0.constprop.0+0x168c>  // b.any
    a4dc:	39400001 	ldrb	w1, [x0]
    a4e0:	7103fc3f 	cmp	w1, #0xff
    a4e4:	540000c0 	b.eq	a4fc <fwp_hof0.constprop.0+0x1b7c>  // b.none
    a4e8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a4ec:	39000001 	strb	w1, [x0]
    a4f0:	17fffec7 	b	a00c <fwp_hof0.constprop.0+0x168c>
    a4f4:	b5ffd4a1 	cbnz	x1, 9f88 <fwp_hof0.constprop.0+0x1608>
    a4f8:	17fffff0 	b	a4b8 <fwp_hof0.constprop.0+0x1b38>
    a4fc:	f9001fe0 	str	x0, [sp, #56]
    a500:	97ffe7ad 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a504:	f9401fe0 	ldr	x0, [sp, #56]
    a508:	17fffff8 	b	a4e8 <fwp_hof0.constprop.0+0x1b68>
    a50c:	97ffe15d 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a510:	97ffe0f8 	bl	28f0 <abort@plt>

000000000000a514 <f0>:
    a514:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a518:	910003fd 	mov	x29, sp
    a51c:	a90153f3 	stp	x19, x20, [sp, #16]
    a520:	a9025bf5 	stp	x21, x22, [sp, #32]
    a524:	a90363f7 	stp	x23, x24, [sp, #48]
    a528:	a9046bf9 	stp	x25, x26, [sp, #64]
    a52c:	a90573fb 	stp	x27, x28, [sp, #80]
    a530:	d121c3ff 	sub	sp, sp, #0x870
    a534:	f90203ff 	str	xzr, [sp, #1024]
    a538:	d0000120 	adrp	x0, 30000 <__data_start>
    a53c:	91014003 	add	x3, x0, #0x50
    a540:	b0000120 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    a544:	f947f400 	ldr	x0, [x0, #4072]
    a548:	f00003f4 	adrp	x20, 89000 <fwp_root_context+0xbb0>
    a54c:	f941c865 	ldr	x5, [x3, #912]
    a550:	f9400001 	ldr	x1, [x0]
    a554:	f90437e1 	str	x1, [sp, #2152]
    a558:	d2800001 	mov	x1, #0x0                   	// #0
    a55c:	9118c299 	add	x25, x20, #0x630
    a560:	912163f6 	add	x22, sp, #0x858
    a564:	910063e4 	add	x4, sp, #0x18
    a568:	9100c3e1 	add	x1, sp, #0x30
    a56c:	90ffffe0 	adrp	x0, 6000 <fwp_owned_entry173+0xac>
    a570:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a574:	91064000 	add	x0, x0, #0x190
    a578:	913d4042 	add	x2, x2, #0xf50
    a57c:	d2800013 	mov	x19, #0x0                   	// #0
    a580:	d280011a 	mov	x26, #0x8                   	// #8
    a584:	d2800015 	mov	x21, #0x0                   	// #0
    a588:	52800037 	mov	w23, #0x1                   	// #1
    a58c:	f90007e4 	str	x4, [sp, #8]
    a590:	a9018be5 	stp	x5, x2, [sp, #24]
    a594:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a598:	a90403ff 	stp	xzr, x0, [sp, #64]
    a59c:	f901c864 	str	x4, [x3, #912]
    a5a0:	f100075b 	subs	x27, x26, #0x1
    a5a4:	aa1603e1 	mov	x1, x22
    a5a8:	da1f02b8 	sbc	x24, x21, xzr
    a5ac:	52800020 	mov	w0, #0x1                   	// #1
    a5b0:	f9001ffb 	str	x27, [sp, #56]
    a5b4:	aa1b03fa 	mov	x26, x27
    a5b8:	f9042ffb 	str	x27, [sp, #2136]
    a5bc:	aa1803f5 	mov	x21, x24
    a5c0:	f90433f3 	str	x19, [sp, #2144]
    a5c4:	97ffeb37 	bl	52a0 <fwp_data.part.0.constprop.0>
    a5c8:	f949db22 	ldr	x2, [x25, #5040]
    a5cc:	aa0003f3 	mov	x19, x0
    a5d0:	f949ef20 	ldr	x0, [x25, #5080]
    a5d4:	cb020262 	sub	x2, x19, x2
    a5d8:	eb00405f 	cmp	x2, x0, lsl #16
    a5dc:	54000302 	b.cs	a63c <f0+0x128>  // b.hs, b.nlast
    a5e0:	d350fc40 	lsr	x0, x2, #16
    a5e4:	f949ff25 	ldr	x5, [x25, #5112]
    a5e8:	8b000800 	add	x0, x0, x0, lsl #2
    a5ec:	d37df001 	lsl	x1, x0, #3
    a5f0:	8b0100a0 	add	x0, x5, x1
    a5f4:	f940101c 	ldr	x28, [x0, #32]
    a5f8:	b400023c 	cbz	x28, a63c <f0+0x128>
    a5fc:	386168a1 	ldrb	w1, [x5, x1]
    a600:	7100083f 	cmp	w1, #0x2
    a604:	54010e60 	b.eq	c7d0 <f0+0x22bc>  // b.none
    a608:	7100043f 	cmp	w1, #0x1
    a60c:	54000181 	b.ne	a63c <f0+0x128>  // b.any
    a610:	29430001 	ldp	w1, w0, [x0, #24]
    a614:	92403c42 	and	x2, x2, #0xffff
    a618:	9b017c42 	mul	x2, x2, x1
    a61c:	d360fc42 	lsr	x2, x2, #32
    a620:	eb00005f 	cmp	x2, x0
    a624:	540000c2 	b.cs	a63c <f0+0x128>  // b.hs, b.nlast
    a628:	8b02039c 	add	x28, x28, x2
    a62c:	39400380 	ldrb	w0, [x28]
    a630:	7103fc1f 	cmp	w0, #0xff
    a634:	54010c80 	b.eq	c7c4 <f0+0x22b0>  // b.none
    a638:	39000397 	strb	w23, [x28]
    a63c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a640:	aa18037b 	orr	x27, x27, x24
    a644:	b5fffafb 	cbnz	x27, a5a0 <f0+0x8c>
    a648:	d0000120 	adrp	x0, 30000 <__data_start>
    a64c:	91014018 	add	x24, x0, #0x50
    a650:	f94007e1 	ldr	x1, [sp, #8]
    a654:	f9001bff 	str	xzr, [sp, #48]
    a658:	f941cb00 	ldr	x0, [x24, #912]
    a65c:	eb01001f 	cmp	x0, x1
    a660:	54012941 	b.ne	cb88 <f0+0x2674>  // b.any
    a664:	b0000023 	adrp	x3, f000 <_IO_stdin_used+0x7c0>
    a668:	910143e1 	add	x1, sp, #0x50
    a66c:	f9400fe2 	ldr	x2, [sp, #24]
    a670:	52800020 	mov	w0, #0x1                   	// #1
    a674:	3dc20860 	ldr	q0, [x3, #2080]
    a678:	f901cb02 	str	x2, [x24, #912]
    a67c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a680:	3d8017e0 	str	q0, [sp, #80]
    a684:	97ffeb07 	bl	52a0 <fwp_data.part.0.constprop.0>
    a688:	97ffedb3 	bl	5d54 <fwp_rc_fresh>
    a68c:	9101a3e1 	add	x1, sp, #0x68
    a690:	aa0003e2 	mov	x2, x0
    a694:	52800020 	mov	w0, #0x1                   	// #1
    a698:	a9068bf5 	stp	x21, x2, [sp, #104]
    a69c:	97ffeb01 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6a0:	97ffedad 	bl	5d54 <fwp_rc_fresh>
    a6a4:	aa0003e2 	mov	x2, x0
    a6a8:	9101e3e1 	add	x1, sp, #0x78
    a6ac:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6b4:	52800020 	mov	w0, #0x1                   	// #1
    a6b8:	a9078be3 	stp	x3, x2, [sp, #120]
    a6bc:	97ffeaf9 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6c0:	97ffeda5 	bl	5d54 <fwp_rc_fresh>
    a6c4:	aa0003e2 	mov	x2, x0
    a6c8:	910223e1 	add	x1, sp, #0x88
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	a9088bf5 	stp	x21, x2, [sp, #136]
    a6d4:	97ffeaf3 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6d8:	97ffed9f 	bl	5d54 <fwp_rc_fresh>
    a6dc:	aa0003e2 	mov	x2, x0
    a6e0:	910263e1 	add	x1, sp, #0x98
    a6e4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	a9098be3 	stp	x3, x2, [sp, #152]
    a6f4:	97ffeaeb 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6f8:	97ffed97 	bl	5d54 <fwp_rc_fresh>
    a6fc:	aa0003e2 	mov	x2, x0
    a700:	9102a3e1 	add	x1, sp, #0xa8
    a704:	52800020 	mov	w0, #0x1                   	// #1
    a708:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a70c:	97ffeae5 	bl	52a0 <fwp_data.part.0.constprop.0>
    a710:	97ffed91 	bl	5d54 <fwp_rc_fresh>
    a714:	aa0003e2 	mov	x2, x0
    a718:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a71c:	9102e3e1 	add	x1, sp, #0xb8
    a720:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a724:	52800020 	mov	w0, #0x1                   	// #1
    a728:	a90b8be3 	stp	x3, x2, [sp, #184]
    a72c:	97ffeadd 	bl	52a0 <fwp_data.part.0.constprop.0>
    a730:	97ffed89 	bl	5d54 <fwp_rc_fresh>
    a734:	aa0003e2 	mov	x2, x0
    a738:	910323e1 	add	x1, sp, #0xc8
    a73c:	52800020 	mov	w0, #0x1                   	// #1
    a740:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a744:	97ffead7 	bl	52a0 <fwp_data.part.0.constprop.0>
    a748:	9118c283 	add	x3, x20, #0x630
    a74c:	aa0003f5 	mov	x21, x0
    a750:	f949d861 	ldr	x1, [x3, #5040]
    a754:	f949ec60 	ldr	x0, [x3, #5080]
    a758:	cb0102a1 	sub	x1, x21, x1
    a75c:	eb00403f 	cmp	x1, x0, lsl #16
    a760:	54000322 	b.cs	a7c4 <f0+0x2b0>  // b.hs, b.nlast
    a764:	d350fc22 	lsr	x2, x1, #16
    a768:	f949fc63 	ldr	x3, [x3, #5112]
    a76c:	8b020842 	add	x2, x2, x2, lsl #2
    a770:	d37df042 	lsl	x2, x2, #3
    a774:	8b020060 	add	x0, x3, x2
    a778:	f9401017 	ldr	x23, [x0, #32]
    a77c:	b4000257 	cbz	x23, a7c4 <f0+0x2b0>
    a780:	38626862 	ldrb	w2, [x3, x2]
    a784:	7100085f 	cmp	w2, #0x2
    a788:	540102a0 	b.eq	c7dc <f0+0x22c8>  // b.none
    a78c:	7100045f 	cmp	w2, #0x1
    a790:	540001a1 	b.ne	a7c4 <f0+0x2b0>  // b.any
    a794:	29430002 	ldp	w2, w0, [x0, #24]
    a798:	92403c21 	and	x1, x1, #0xffff
    a79c:	9b027c21 	mul	x1, x1, x2
    a7a0:	d360fc21 	lsr	x1, x1, #32
    a7a4:	eb00003f 	cmp	x1, x0
    a7a8:	540000e2 	b.cs	a7c4 <f0+0x2b0>  // b.hs, b.nlast
    a7ac:	8b0102f7 	add	x23, x23, x1
    a7b0:	394002e0 	ldrb	w0, [x23]
    a7b4:	7103fc1f 	cmp	w0, #0xff
    a7b8:	54011020 	b.eq	c9bc <f0+0x24a8>  // b.none
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	390002e0 	strb	w0, [x23]
    a7c4:	910363e1 	add	x1, sp, #0xd8
    a7c8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a7cc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a7d0:	52800020 	mov	w0, #0x1                   	// #1
    a7d4:	a90dd7f7 	stp	x23, x21, [sp, #216]
    a7d8:	97ffeab2 	bl	52a0 <fwp_data.part.0.constprop.0>
    a7dc:	97ffed5e 	bl	5d54 <fwp_rc_fresh>
    a7e0:	aa0003e2 	mov	x2, x0
    a7e4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7e8:	9103a3e1 	add	x1, sp, #0xe8
    a7ec:	52800020 	mov	w0, #0x1                   	// #1
    a7f0:	a90e8be3 	stp	x3, x2, [sp, #232]
    a7f4:	97ffeaab 	bl	52a0 <fwp_data.part.0.constprop.0>
    a7f8:	97ffed57 	bl	5d54 <fwp_rc_fresh>
    a7fc:	aa0003e2 	mov	x2, x0
    a800:	9103e3e1 	add	x1, sp, #0xf8
    a804:	52800020 	mov	w0, #0x1                   	// #1
    a808:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a80c:	97ffeaa5 	bl	52a0 <fwp_data.part.0.constprop.0>
    a810:	9118c283 	add	x3, x20, #0x630
    a814:	aa0003f5 	mov	x21, x0
    a818:	f949d861 	ldr	x1, [x3, #5040]
    a81c:	f949ec60 	ldr	x0, [x3, #5080]
    a820:	cb0102a1 	sub	x1, x21, x1
    a824:	eb00403f 	cmp	x1, x0, lsl #16
    a828:	54000322 	b.cs	a88c <f0+0x378>  // b.hs, b.nlast
    a82c:	d350fc22 	lsr	x2, x1, #16
    a830:	f949fc63 	ldr	x3, [x3, #5112]
    a834:	8b020842 	add	x2, x2, x2, lsl #2
    a838:	d37df042 	lsl	x2, x2, #3
    a83c:	8b020060 	add	x0, x3, x2
    a840:	f9401017 	ldr	x23, [x0, #32]
    a844:	b4000257 	cbz	x23, a88c <f0+0x378>
    a848:	38626862 	ldrb	w2, [x3, x2]
    a84c:	7100085f 	cmp	w2, #0x2
    a850:	5400fd20 	b.eq	c7f4 <f0+0x22e0>  // b.none
    a854:	7100045f 	cmp	w2, #0x1
    a858:	540001a1 	b.ne	a88c <f0+0x378>  // b.any
    a85c:	29430002 	ldp	w2, w0, [x0, #24]
    a860:	92403c21 	and	x1, x1, #0xffff
    a864:	9b027c21 	mul	x1, x1, x2
    a868:	d360fc21 	lsr	x1, x1, #32
    a86c:	eb00003f 	cmp	x1, x0
    a870:	540000e2 	b.cs	a88c <f0+0x378>  // b.hs, b.nlast
    a874:	8b0102f7 	add	x23, x23, x1
    a878:	394002e0 	ldrb	w0, [x23]
    a87c:	7103fc1f 	cmp	w0, #0xff
    a880:	54010a40 	b.eq	c9c8 <f0+0x24b4>  // b.none
    a884:	52800020 	mov	w0, #0x1                   	// #1
    a888:	390002e0 	strb	w0, [x23]
    a88c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a890:	910423e1 	add	x1, sp, #0x108
    a894:	52800020 	mov	w0, #0x1                   	// #1
    a898:	a910d7e2 	stp	x2, x21, [sp, #264]
    a89c:	97ffea81 	bl	52a0 <fwp_data.part.0.constprop.0>
    a8a0:	9118c283 	add	x3, x20, #0x630
    a8a4:	aa0003f5 	mov	x21, x0
    a8a8:	f949d861 	ldr	x1, [x3, #5040]
    a8ac:	f949ec60 	ldr	x0, [x3, #5080]
    a8b0:	cb0102a1 	sub	x1, x21, x1
    a8b4:	eb00403f 	cmp	x1, x0, lsl #16
    a8b8:	54000322 	b.cs	a91c <f0+0x408>  // b.hs, b.nlast
    a8bc:	d350fc22 	lsr	x2, x1, #16
    a8c0:	f949fc63 	ldr	x3, [x3, #5112]
    a8c4:	8b020842 	add	x2, x2, x2, lsl #2
    a8c8:	d37df042 	lsl	x2, x2, #3
    a8cc:	8b020060 	add	x0, x3, x2
    a8d0:	f9401017 	ldr	x23, [x0, #32]
    a8d4:	b4000257 	cbz	x23, a91c <f0+0x408>
    a8d8:	38626862 	ldrb	w2, [x3, x2]
    a8dc:	7100085f 	cmp	w2, #0x2
    a8e0:	5400f840 	b.eq	c7e8 <f0+0x22d4>  // b.none
    a8e4:	7100045f 	cmp	w2, #0x1
    a8e8:	540001a1 	b.ne	a91c <f0+0x408>  // b.any
    a8ec:	29430002 	ldp	w2, w0, [x0, #24]
    a8f0:	92403c21 	and	x1, x1, #0xffff
    a8f4:	9b027c21 	mul	x1, x1, x2
    a8f8:	d360fc21 	lsr	x1, x1, #32
    a8fc:	eb00003f 	cmp	x1, x0
    a900:	540000e2 	b.cs	a91c <f0+0x408>  // b.hs, b.nlast
    a904:	8b0102f7 	add	x23, x23, x1
    a908:	394002e0 	ldrb	w0, [x23]
    a90c:	7103fc1f 	cmp	w0, #0xff
    a910:	54010620 	b.eq	c9d4 <f0+0x24c0>  // b.none
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	390002e0 	strb	w0, [x23]
    a91c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a920:	910463e1 	add	x1, sp, #0x118
    a924:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a928:	52800020 	mov	w0, #0x1                   	// #1
    a92c:	a911d7e2 	stp	x2, x21, [sp, #280]
    a930:	97ffea5c 	bl	52a0 <fwp_data.part.0.constprop.0>
    a934:	9118c283 	add	x3, x20, #0x630
    a938:	aa0003f7 	mov	x23, x0
    a93c:	f949d861 	ldr	x1, [x3, #5040]
    a940:	f949ec60 	ldr	x0, [x3, #5080]
    a944:	cb0102e1 	sub	x1, x23, x1
    a948:	eb00403f 	cmp	x1, x0, lsl #16
    a94c:	54000322 	b.cs	a9b0 <f0+0x49c>  // b.hs, b.nlast
    a950:	d350fc22 	lsr	x2, x1, #16
    a954:	f949fc63 	ldr	x3, [x3, #5112]
    a958:	8b020842 	add	x2, x2, x2, lsl #2
    a95c:	d37df042 	lsl	x2, x2, #3
    a960:	8b020060 	add	x0, x3, x2
    a964:	f9401015 	ldr	x21, [x0, #32]
    a968:	b4000255 	cbz	x21, a9b0 <f0+0x49c>
    a96c:	38626862 	ldrb	w2, [x3, x2]
    a970:	7100085f 	cmp	w2, #0x2
    a974:	5400f4c0 	b.eq	c80c <f0+0x22f8>  // b.none
    a978:	7100045f 	cmp	w2, #0x1
    a97c:	540001a1 	b.ne	a9b0 <f0+0x49c>  // b.any
    a980:	29430002 	ldp	w2, w0, [x0, #24]
    a984:	92403c21 	and	x1, x1, #0xffff
    a988:	9b027c21 	mul	x1, x1, x2
    a98c:	d360fc21 	lsr	x1, x1, #32
    a990:	eb00003f 	cmp	x1, x0
    a994:	540000e2 	b.cs	a9b0 <f0+0x49c>  // b.hs, b.nlast
    a998:	8b0102b5 	add	x21, x21, x1
    a99c:	394002a0 	ldrb	w0, [x21]
    a9a0:	7103fc1f 	cmp	w0, #0xff
    a9a4:	540101e0 	b.eq	c9e0 <f0+0x24cc>  // b.none
    a9a8:	52800020 	mov	w0, #0x1                   	// #1
    a9ac:	390002a0 	strb	w0, [x21]
    a9b0:	9104a3e1 	add	x1, sp, #0x128
    a9b4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	a912dff5 	stp	x21, x23, [sp, #296]
    a9c0:	97ffea38 	bl	52a0 <fwp_data.part.0.constprop.0>
    a9c4:	97ffece4 	bl	5d54 <fwp_rc_fresh>
    a9c8:	aa0003e2 	mov	x2, x0
    a9cc:	9104e3e1 	add	x1, sp, #0x138
    a9d0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a9d4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a9d8:	52800020 	mov	w0, #0x1                   	// #1
    a9dc:	a9138bf7 	stp	x23, x2, [sp, #312]
    a9e0:	97ffea30 	bl	52a0 <fwp_data.part.0.constprop.0>
    a9e4:	97ffecdc 	bl	5d54 <fwp_rc_fresh>
    a9e8:	aa0003e2 	mov	x2, x0
    a9ec:	910523e1 	add	x1, sp, #0x148
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	a9148bf5 	stp	x21, x2, [sp, #328]
    a9f8:	97ffea2a 	bl	52a0 <fwp_data.part.0.constprop.0>
    a9fc:	97ffecd6 	bl	5d54 <fwp_rc_fresh>
    aa00:	aa0003e2 	mov	x2, x0
    aa04:	910563e1 	add	x1, sp, #0x158
    aa08:	52800020 	mov	w0, #0x1                   	// #1
    aa0c:	a9158bf7 	stp	x23, x2, [sp, #344]
    aa10:	97ffea24 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa14:	97ffecd0 	bl	5d54 <fwp_rc_fresh>
    aa18:	aa0003e2 	mov	x2, x0
    aa1c:	9105a3e1 	add	x1, sp, #0x168
    aa20:	52800020 	mov	w0, #0x1                   	// #1
    aa24:	a9168bf5 	stp	x21, x2, [sp, #360]
    aa28:	97ffea1e 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa2c:	97ffecca 	bl	5d54 <fwp_rc_fresh>
    aa30:	aa0003e2 	mov	x2, x0
    aa34:	9105e3e1 	add	x1, sp, #0x178
    aa38:	52800020 	mov	w0, #0x1                   	// #1
    aa3c:	a9178bf7 	stp	x23, x2, [sp, #376]
    aa40:	97ffea18 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa44:	97ffecc4 	bl	5d54 <fwp_rc_fresh>
    aa48:	aa0003e2 	mov	x2, x0
    aa4c:	910623e1 	add	x1, sp, #0x188
    aa50:	52800020 	mov	w0, #0x1                   	// #1
    aa54:	a9188bf5 	stp	x21, x2, [sp, #392]
    aa58:	97ffea12 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa5c:	97ffecbe 	bl	5d54 <fwp_rc_fresh>
    aa60:	aa0003e2 	mov	x2, x0
    aa64:	910663e1 	add	x1, sp, #0x198
    aa68:	52800020 	mov	w0, #0x1                   	// #1
    aa6c:	a9198bf7 	stp	x23, x2, [sp, #408]
    aa70:	97ffea0c 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa74:	97ffecb8 	bl	5d54 <fwp_rc_fresh>
    aa78:	aa0003e2 	mov	x2, x0
    aa7c:	9106a3e1 	add	x1, sp, #0x1a8
    aa80:	52800020 	mov	w0, #0x1                   	// #1
    aa84:	a91a8bf5 	stp	x21, x2, [sp, #424]
    aa88:	97ffea06 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa8c:	97ffecb2 	bl	5d54 <fwp_rc_fresh>
    aa90:	aa0003e2 	mov	x2, x0
    aa94:	9106e3e1 	add	x1, sp, #0x1b8
    aa98:	52800020 	mov	w0, #0x1                   	// #1
    aa9c:	a91b8bf7 	stp	x23, x2, [sp, #440]
    aaa0:	97ffea00 	bl	52a0 <fwp_data.part.0.constprop.0>
    aaa4:	97ffecac 	bl	5d54 <fwp_rc_fresh>
    aaa8:	aa0003e2 	mov	x2, x0
    aaac:	910723e1 	add	x1, sp, #0x1c8
    aab0:	52800020 	mov	w0, #0x1                   	// #1
    aab4:	a91c8bf5 	stp	x21, x2, [sp, #456]
    aab8:	97ffe9fa 	bl	52a0 <fwp_data.part.0.constprop.0>
    aabc:	97ffeca6 	bl	5d54 <fwp_rc_fresh>
    aac0:	aa0003e2 	mov	x2, x0
    aac4:	910763e1 	add	x1, sp, #0x1d8
    aac8:	52800020 	mov	w0, #0x1                   	// #1
    aacc:	a91d8bf7 	stp	x23, x2, [sp, #472]
    aad0:	97ffe9f4 	bl	52a0 <fwp_data.part.0.constprop.0>
    aad4:	97ffeca0 	bl	5d54 <fwp_rc_fresh>
    aad8:	aa0003e2 	mov	x2, x0
    aadc:	9107a3e1 	add	x1, sp, #0x1e8
    aae0:	52800020 	mov	w0, #0x1                   	// #1
    aae4:	a91e8bf5 	stp	x21, x2, [sp, #488]
    aae8:	97ffe9ee 	bl	52a0 <fwp_data.part.0.constprop.0>
    aaec:	97ffec9a 	bl	5d54 <fwp_rc_fresh>
    aaf0:	aa0003e2 	mov	x2, x0
    aaf4:	9107e3e1 	add	x1, sp, #0x1f8
    aaf8:	52800020 	mov	w0, #0x1                   	// #1
    aafc:	a91f8bf7 	stp	x23, x2, [sp, #504]
    ab00:	97ffe9e8 	bl	52a0 <fwp_data.part.0.constprop.0>
    ab04:	97ffec94 	bl	5d54 <fwp_rc_fresh>
    ab08:	aa0003e2 	mov	x2, x0
    ab0c:	910823e1 	add	x1, sp, #0x208
    ab10:	52800020 	mov	w0, #0x1                   	// #1
    ab14:	f90107f5 	str	x21, [sp, #520]
    ab18:	f9010be2 	str	x2, [sp, #528]
    ab1c:	97ffe9e1 	bl	52a0 <fwp_data.part.0.constprop.0>
    ab20:	97ffec8d 	bl	5d54 <fwp_rc_fresh>
    ab24:	aa0003e2 	mov	x2, x0
    ab28:	910863e1 	add	x1, sp, #0x218
    ab2c:	52800020 	mov	w0, #0x1                   	// #1
    ab30:	f9010ff7 	str	x23, [sp, #536]
    ab34:	f90113e2 	str	x2, [sp, #544]
    ab38:	97ffe9da 	bl	52a0 <fwp_data.part.0.constprop.0>
    ab3c:	97ffec86 	bl	5d54 <fwp_rc_fresh>
    ab40:	aa0003e2 	mov	x2, x0
    ab44:	9108a3e1 	add	x1, sp, #0x228
    ab48:	52800020 	mov	w0, #0x1                   	// #1
    ab4c:	f90117f5 	str	x21, [sp, #552]
    ab50:	f9011be2 	str	x2, [sp, #560]
    ab54:	97ffe9d3 	bl	52a0 <fwp_data.part.0.constprop.0>
    ab58:	9118c283 	add	x3, x20, #0x630
    ab5c:	aa0003f5 	mov	x21, x0
    ab60:	f949d861 	ldr	x1, [x3, #5040]
    ab64:	f949ec60 	ldr	x0, [x3, #5080]
    ab68:	cb0102a1 	sub	x1, x21, x1
    ab6c:	eb00403f 	cmp	x1, x0, lsl #16
    ab70:	54000322 	b.cs	abd4 <f0+0x6c0>  // b.hs, b.nlast
    ab74:	d350fc22 	lsr	x2, x1, #16
    ab78:	f949fc63 	ldr	x3, [x3, #5112]
    ab7c:	8b020842 	add	x2, x2, x2, lsl #2
    ab80:	d37df042 	lsl	x2, x2, #3
    ab84:	8b020060 	add	x0, x3, x2
    ab88:	f9401017 	ldr	x23, [x0, #32]
    ab8c:	b4000257 	cbz	x23, abd4 <f0+0x6c0>
    ab90:	38626862 	ldrb	w2, [x3, x2]
    ab94:	7100085f 	cmp	w2, #0x2
    ab98:	5400e340 	b.eq	c800 <f0+0x22ec>  // b.none
    ab9c:	7100045f 	cmp	w2, #0x1
    aba0:	540001a1 	b.ne	abd4 <f0+0x6c0>  // b.any
    aba4:	29430002 	ldp	w2, w0, [x0, #24]
    aba8:	92403c21 	and	x1, x1, #0xffff
    abac:	9b027c21 	mul	x1, x1, x2
    abb0:	d360fc21 	lsr	x1, x1, #32
    abb4:	eb00003f 	cmp	x1, x0
    abb8:	540000e2 	b.cs	abd4 <f0+0x6c0>  // b.hs, b.nlast
    abbc:	8b0102f7 	add	x23, x23, x1
    abc0:	394002e0 	ldrb	w0, [x23]
    abc4:	7103fc1f 	cmp	w0, #0xff
    abc8:	5400f120 	b.eq	c9ec <f0+0x24d8>  // b.none
    abcc:	52800020 	mov	w0, #0x1                   	// #1
    abd0:	390002e0 	strb	w0, [x23]
    abd4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    abd8:	9108e3e1 	add	x1, sp, #0x238
    abdc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abe0:	52800020 	mov	w0, #0x1                   	// #1
    abe4:	f9011fe2 	str	x2, [sp, #568]
    abe8:	f90123f5 	str	x21, [sp, #576]
    abec:	97ffe9ad 	bl	52a0 <fwp_data.part.0.constprop.0>
    abf0:	9118c283 	add	x3, x20, #0x630
    abf4:	aa0003f5 	mov	x21, x0
    abf8:	f949d861 	ldr	x1, [x3, #5040]
    abfc:	f949ec60 	ldr	x0, [x3, #5080]
    ac00:	cb0102a1 	sub	x1, x21, x1
    ac04:	eb00403f 	cmp	x1, x0, lsl #16
    ac08:	54000322 	b.cs	ac6c <f0+0x758>  // b.hs, b.nlast
    ac0c:	d350fc22 	lsr	x2, x1, #16
    ac10:	f949fc63 	ldr	x3, [x3, #5112]
    ac14:	8b020842 	add	x2, x2, x2, lsl #2
    ac18:	d37df042 	lsl	x2, x2, #3
    ac1c:	8b020060 	add	x0, x3, x2
    ac20:	f9401017 	ldr	x23, [x0, #32]
    ac24:	b4000257 	cbz	x23, ac6c <f0+0x758>
    ac28:	38626862 	ldrb	w2, [x3, x2]
    ac2c:	7100085f 	cmp	w2, #0x2
    ac30:	5400dfa0 	b.eq	c824 <f0+0x2310>  // b.none
    ac34:	7100045f 	cmp	w2, #0x1
    ac38:	540001a1 	b.ne	ac6c <f0+0x758>  // b.any
    ac3c:	29430002 	ldp	w2, w0, [x0, #24]
    ac40:	92403c21 	and	x1, x1, #0xffff
    ac44:	9b027c21 	mul	x1, x1, x2
    ac48:	d360fc21 	lsr	x1, x1, #32
    ac4c:	eb00003f 	cmp	x1, x0
    ac50:	540000e2 	b.cs	ac6c <f0+0x758>  // b.hs, b.nlast
    ac54:	8b0102f7 	add	x23, x23, x1
    ac58:	394002e0 	ldrb	w0, [x23]
    ac5c:	7103fc1f 	cmp	w0, #0xff
    ac60:	5400ecc0 	b.eq	c9f8 <f0+0x24e4>  // b.none
    ac64:	52800020 	mov	w0, #0x1                   	// #1
    ac68:	390002e0 	strb	w0, [x23]
    ac6c:	910923e1 	add	x1, sp, #0x248
    ac70:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac74:	52800020 	mov	w0, #0x1                   	// #1
    ac78:	f90127f7 	str	x23, [sp, #584]
    ac7c:	f9012bf5 	str	x21, [sp, #592]
    ac80:	97ffe988 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac84:	97ffec34 	bl	5d54 <fwp_rc_fresh>
    ac88:	aa0003e2 	mov	x2, x0
    ac8c:	910963e1 	add	x1, sp, #0x258
    ac90:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ac94:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ac98:	52800020 	mov	w0, #0x1                   	// #1
    ac9c:	f9012ff5 	str	x21, [sp, #600]
    aca0:	f90133e2 	str	x2, [sp, #608]
    aca4:	97ffe97f 	bl	52a0 <fwp_data.part.0.constprop.0>
    aca8:	97ffec2b 	bl	5d54 <fwp_rc_fresh>
    acac:	aa0003e2 	mov	x2, x0
    acb0:	9109a3e1 	add	x1, sp, #0x268
    acb4:	52800020 	mov	w0, #0x1                   	// #1
    acb8:	f90137f7 	str	x23, [sp, #616]
    acbc:	f9013be2 	str	x2, [sp, #624]
    acc0:	97ffe978 	bl	52a0 <fwp_data.part.0.constprop.0>
    acc4:	97ffec24 	bl	5d54 <fwp_rc_fresh>
    acc8:	aa0003e2 	mov	x2, x0
    accc:	9109e3e1 	add	x1, sp, #0x278
    acd0:	52800020 	mov	w0, #0x1                   	// #1
    acd4:	f9013ff5 	str	x21, [sp, #632]
    acd8:	f90143e2 	str	x2, [sp, #640]
    acdc:	97ffe971 	bl	52a0 <fwp_data.part.0.constprop.0>
    ace0:	9118c283 	add	x3, x20, #0x630
    ace4:	aa0003f5 	mov	x21, x0
    ace8:	f949d861 	ldr	x1, [x3, #5040]
    acec:	f949ec60 	ldr	x0, [x3, #5080]
    acf0:	cb0102a1 	sub	x1, x21, x1
    acf4:	eb00403f 	cmp	x1, x0, lsl #16
    acf8:	54000322 	b.cs	ad5c <f0+0x848>  // b.hs, b.nlast
    acfc:	d350fc22 	lsr	x2, x1, #16
    ad00:	f949fc63 	ldr	x3, [x3, #5112]
    ad04:	8b020842 	add	x2, x2, x2, lsl #2
    ad08:	d37df042 	lsl	x2, x2, #3
    ad0c:	8b020060 	add	x0, x3, x2
    ad10:	f9401017 	ldr	x23, [x0, #32]
    ad14:	b4000257 	cbz	x23, ad5c <f0+0x848>
    ad18:	38626862 	ldrb	w2, [x3, x2]
    ad1c:	7100085f 	cmp	w2, #0x2
    ad20:	5400d7c0 	b.eq	c818 <f0+0x2304>  // b.none
    ad24:	7100045f 	cmp	w2, #0x1
    ad28:	540001a1 	b.ne	ad5c <f0+0x848>  // b.any
    ad2c:	29430002 	ldp	w2, w0, [x0, #24]
    ad30:	92403c21 	and	x1, x1, #0xffff
    ad34:	9b027c21 	mul	x1, x1, x2
    ad38:	d360fc21 	lsr	x1, x1, #32
    ad3c:	eb00003f 	cmp	x1, x0
    ad40:	540000e2 	b.cs	ad5c <f0+0x848>  // b.hs, b.nlast
    ad44:	8b0102f7 	add	x23, x23, x1
    ad48:	394002e0 	ldrb	w0, [x23]
    ad4c:	7103fc1f 	cmp	w0, #0xff
    ad50:	5400e5a0 	b.eq	ca04 <f0+0x24f0>  // b.none
    ad54:	52800020 	mov	w0, #0x1                   	// #1
    ad58:	390002e0 	strb	w0, [x23]
    ad5c:	910a23e1 	add	x1, sp, #0x288
    ad60:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad64:	52800020 	mov	w0, #0x1                   	// #1
    ad68:	f90147e2 	str	x2, [sp, #648]
    ad6c:	f9014bf5 	str	x21, [sp, #656]
    ad70:	97ffe94c 	bl	52a0 <fwp_data.part.0.constprop.0>
    ad74:	97ffebf8 	bl	5d54 <fwp_rc_fresh>
    ad78:	aa0003e2 	mov	x2, x0
    ad7c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad80:	910a63e1 	add	x1, sp, #0x298
    ad84:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad88:	52800020 	mov	w0, #0x1                   	// #1
    ad8c:	f9014fe3 	str	x3, [sp, #664]
    ad90:	f90153e2 	str	x2, [sp, #672]
    ad94:	97ffe943 	bl	52a0 <fwp_data.part.0.constprop.0>
    ad98:	9118c283 	add	x3, x20, #0x630
    ad9c:	aa0003f7 	mov	x23, x0
    ada0:	f949d861 	ldr	x1, [x3, #5040]
    ada4:	f949ec60 	ldr	x0, [x3, #5080]
    ada8:	cb0102e1 	sub	x1, x23, x1
    adac:	eb00403f 	cmp	x1, x0, lsl #16
    adb0:	54000322 	b.cs	ae14 <f0+0x900>  // b.hs, b.nlast
    adb4:	d350fc22 	lsr	x2, x1, #16
    adb8:	f949fc63 	ldr	x3, [x3, #5112]
    adbc:	8b020842 	add	x2, x2, x2, lsl #2
    adc0:	d37df042 	lsl	x2, x2, #3
    adc4:	8b020060 	add	x0, x3, x2
    adc8:	f9401015 	ldr	x21, [x0, #32]
    adcc:	b4000255 	cbz	x21, ae14 <f0+0x900>
    add0:	38626862 	ldrb	w2, [x3, x2]
    add4:	7100085f 	cmp	w2, #0x2
    add8:	5400d920 	b.eq	c8fc <f0+0x23e8>  // b.none
    addc:	7100045f 	cmp	w2, #0x1
    ade0:	540001a1 	b.ne	ae14 <f0+0x900>  // b.any
    ade4:	29430002 	ldp	w2, w0, [x0, #24]
    ade8:	92403c21 	and	x1, x1, #0xffff
    adec:	9b027c21 	mul	x1, x1, x2
    adf0:	d360fc21 	lsr	x1, x1, #32
    adf4:	eb00003f 	cmp	x1, x0
    adf8:	540000e2 	b.cs	ae14 <f0+0x900>  // b.hs, b.nlast
    adfc:	8b0102b5 	add	x21, x21, x1
    ae00:	394002a0 	ldrb	w0, [x21]
    ae04:	7103fc1f 	cmp	w0, #0xff
    ae08:	5400e040 	b.eq	ca10 <f0+0x24fc>  // b.none
    ae0c:	52800020 	mov	w0, #0x1                   	// #1
    ae10:	390002a0 	strb	w0, [x21]
    ae14:	910aa3e1 	add	x1, sp, #0x2a8
    ae18:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ae1c:	52800020 	mov	w0, #0x1                   	// #1
    ae20:	f90157f5 	str	x21, [sp, #680]
    ae24:	f9015bf7 	str	x23, [sp, #688]
    ae28:	97ffe91e 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae2c:	97ffebca 	bl	5d54 <fwp_rc_fresh>
    ae30:	aa0003e2 	mov	x2, x0
    ae34:	910ae3e1 	add	x1, sp, #0x2b8
    ae38:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae3c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae40:	52800020 	mov	w0, #0x1                   	// #1
    ae44:	f9015ff7 	str	x23, [sp, #696]
    ae48:	f90163e2 	str	x2, [sp, #704]
    ae4c:	97ffe915 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae50:	97ffebc1 	bl	5d54 <fwp_rc_fresh>
    ae54:	aa0003e2 	mov	x2, x0
    ae58:	910b23e1 	add	x1, sp, #0x2c8
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	f90167f5 	str	x21, [sp, #712]
    ae64:	f9016be2 	str	x2, [sp, #720]
    ae68:	97ffe90e 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae6c:	97ffebba 	bl	5d54 <fwp_rc_fresh>
    ae70:	aa0003e2 	mov	x2, x0
    ae74:	910b63e1 	add	x1, sp, #0x2d8
    ae78:	52800020 	mov	w0, #0x1                   	// #1
    ae7c:	f9016ff7 	str	x23, [sp, #728]
    ae80:	f90173e2 	str	x2, [sp, #736]
    ae84:	97ffe907 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae88:	97ffebb3 	bl	5d54 <fwp_rc_fresh>
    ae8c:	aa0003e2 	mov	x2, x0
    ae90:	910ba3e1 	add	x1, sp, #0x2e8
    ae94:	52800020 	mov	w0, #0x1                   	// #1
    ae98:	f90177f5 	str	x21, [sp, #744]
    ae9c:	f9017be2 	str	x2, [sp, #752]
    aea0:	97ffe900 	bl	52a0 <fwp_data.part.0.constprop.0>
    aea4:	97ffebac 	bl	5d54 <fwp_rc_fresh>
    aea8:	aa0003e2 	mov	x2, x0
    aeac:	910be3e1 	add	x1, sp, #0x2f8
    aeb0:	52800020 	mov	w0, #0x1                   	// #1
    aeb4:	f9017ff7 	str	x23, [sp, #760]
    aeb8:	f90183e2 	str	x2, [sp, #768]
    aebc:	97ffe8f9 	bl	52a0 <fwp_data.part.0.constprop.0>
    aec0:	97ffeba5 	bl	5d54 <fwp_rc_fresh>
    aec4:	aa0003e2 	mov	x2, x0
    aec8:	910c23e1 	add	x1, sp, #0x308
    aecc:	52800020 	mov	w0, #0x1                   	// #1
    aed0:	f90187f5 	str	x21, [sp, #776]
    aed4:	f9018be2 	str	x2, [sp, #784]
    aed8:	97ffe8f2 	bl	52a0 <fwp_data.part.0.constprop.0>
    aedc:	97ffeb9e 	bl	5d54 <fwp_rc_fresh>
    aee0:	aa0003e2 	mov	x2, x0
    aee4:	910c63e1 	add	x1, sp, #0x318
    aee8:	52800020 	mov	w0, #0x1                   	// #1
    aeec:	f9018ff7 	str	x23, [sp, #792]
    aef0:	f90193e2 	str	x2, [sp, #800]
    aef4:	97ffe8eb 	bl	52a0 <fwp_data.part.0.constprop.0>
    aef8:	97ffeb97 	bl	5d54 <fwp_rc_fresh>
    aefc:	aa0003e2 	mov	x2, x0
    af00:	910ca3e1 	add	x1, sp, #0x328
    af04:	52800020 	mov	w0, #0x1                   	// #1
    af08:	f90197f5 	str	x21, [sp, #808]
    af0c:	f9019be2 	str	x2, [sp, #816]
    af10:	97ffe8e4 	bl	52a0 <fwp_data.part.0.constprop.0>
    af14:	97ffeb90 	bl	5d54 <fwp_rc_fresh>
    af18:	aa0003e2 	mov	x2, x0
    af1c:	910ce3e1 	add	x1, sp, #0x338
    af20:	52800020 	mov	w0, #0x1                   	// #1
    af24:	f9019ff7 	str	x23, [sp, #824]
    af28:	f901a3e2 	str	x2, [sp, #832]
    af2c:	97ffe8dd 	bl	52a0 <fwp_data.part.0.constprop.0>
    af30:	97ffeb89 	bl	5d54 <fwp_rc_fresh>
    af34:	aa0003e2 	mov	x2, x0
    af38:	910d23e1 	add	x1, sp, #0x348
    af3c:	52800020 	mov	w0, #0x1                   	// #1
    af40:	f901a7f5 	str	x21, [sp, #840]
    af44:	f901abe2 	str	x2, [sp, #848]
    af48:	97ffe8d6 	bl	52a0 <fwp_data.part.0.constprop.0>
    af4c:	97ffeb82 	bl	5d54 <fwp_rc_fresh>
    af50:	aa0003e2 	mov	x2, x0
    af54:	910d63e1 	add	x1, sp, #0x358
    af58:	52800020 	mov	w0, #0x1                   	// #1
    af5c:	f901aff7 	str	x23, [sp, #856]
    af60:	f901b3e2 	str	x2, [sp, #864]
    af64:	97ffe8cf 	bl	52a0 <fwp_data.part.0.constprop.0>
    af68:	97ffeb7b 	bl	5d54 <fwp_rc_fresh>
    af6c:	aa0003e2 	mov	x2, x0
    af70:	910da3e1 	add	x1, sp, #0x368
    af74:	52800020 	mov	w0, #0x1                   	// #1
    af78:	f901b7f5 	str	x21, [sp, #872]
    af7c:	f901bbe2 	str	x2, [sp, #880]
    af80:	97ffe8c8 	bl	52a0 <fwp_data.part.0.constprop.0>
    af84:	97ffeb74 	bl	5d54 <fwp_rc_fresh>
    af88:	aa0003e2 	mov	x2, x0
    af8c:	910de3e1 	add	x1, sp, #0x378
    af90:	52800020 	mov	w0, #0x1                   	// #1
    af94:	f901bff7 	str	x23, [sp, #888]
    af98:	f901c3e2 	str	x2, [sp, #896]
    af9c:	97ffe8c1 	bl	52a0 <fwp_data.part.0.constprop.0>
    afa0:	97ffeb6d 	bl	5d54 <fwp_rc_fresh>
    afa4:	aa0003e2 	mov	x2, x0
    afa8:	910e23e1 	add	x1, sp, #0x388
    afac:	52800020 	mov	w0, #0x1                   	// #1
    afb0:	f901c7f5 	str	x21, [sp, #904]
    afb4:	f901cbe2 	str	x2, [sp, #912]
    afb8:	97ffe8ba 	bl	52a0 <fwp_data.part.0.constprop.0>
    afbc:	97ffeb66 	bl	5d54 <fwp_rc_fresh>
    afc0:	aa0003e2 	mov	x2, x0
    afc4:	910e63e1 	add	x1, sp, #0x398
    afc8:	52800020 	mov	w0, #0x1                   	// #1
    afcc:	f901cff7 	str	x23, [sp, #920]
    afd0:	f901d3e2 	str	x2, [sp, #928]
    afd4:	97ffe8b3 	bl	52a0 <fwp_data.part.0.constprop.0>
    afd8:	97ffeb5f 	bl	5d54 <fwp_rc_fresh>
    afdc:	aa0003e2 	mov	x2, x0
    afe0:	910ea3e1 	add	x1, sp, #0x3a8
    afe4:	52800020 	mov	w0, #0x1                   	// #1
    afe8:	f901d7f5 	str	x21, [sp, #936]
    afec:	f901dbe2 	str	x2, [sp, #944]
    aff0:	97ffe8ac 	bl	52a0 <fwp_data.part.0.constprop.0>
    aff4:	97ffeb58 	bl	5d54 <fwp_rc_fresh>
    aff8:	aa0003e2 	mov	x2, x0
    affc:	910ee3e1 	add	x1, sp, #0x3b8
    b000:	52800020 	mov	w0, #0x1                   	// #1
    b004:	f901dff7 	str	x23, [sp, #952]
    b008:	f901e3e2 	str	x2, [sp, #960]
    b00c:	97ffe8a5 	bl	52a0 <fwp_data.part.0.constprop.0>
    b010:	97ffeb51 	bl	5d54 <fwp_rc_fresh>
    b014:	aa0003e2 	mov	x2, x0
    b018:	910f23e1 	add	x1, sp, #0x3c8
    b01c:	52800020 	mov	w0, #0x1                   	// #1
    b020:	f901e7f5 	str	x21, [sp, #968]
    b024:	f901ebe2 	str	x2, [sp, #976]
    b028:	97ffe89e 	bl	52a0 <fwp_data.part.0.constprop.0>
    b02c:	9118c283 	add	x3, x20, #0x630
    b030:	aa0003f5 	mov	x21, x0
    b034:	f949d861 	ldr	x1, [x3, #5040]
    b038:	f949ec60 	ldr	x0, [x3, #5080]
    b03c:	cb0102a1 	sub	x1, x21, x1
    b040:	eb00403f 	cmp	x1, x0, lsl #16
    b044:	54000322 	b.cs	b0a8 <f0+0xb94>  // b.hs, b.nlast
    b048:	d350fc22 	lsr	x2, x1, #16
    b04c:	f949fc63 	ldr	x3, [x3, #5112]
    b050:	8b020842 	add	x2, x2, x2, lsl #2
    b054:	d37df042 	lsl	x2, x2, #3
    b058:	8b020060 	add	x0, x3, x2
    b05c:	f9401017 	ldr	x23, [x0, #32]
    b060:	b4000257 	cbz	x23, b0a8 <f0+0xb94>
    b064:	38626862 	ldrb	w2, [x3, x2]
    b068:	7100085f 	cmp	w2, #0x2
    b06c:	5400c420 	b.eq	c8f0 <f0+0x23dc>  // b.none
    b070:	7100045f 	cmp	w2, #0x1
    b074:	540001a1 	b.ne	b0a8 <f0+0xb94>  // b.any
    b078:	29430002 	ldp	w2, w0, [x0, #24]
    b07c:	92403c21 	and	x1, x1, #0xffff
    b080:	9b027c21 	mul	x1, x1, x2
    b084:	d360fc21 	lsr	x1, x1, #32
    b088:	eb00003f 	cmp	x1, x0
    b08c:	540000e2 	b.cs	b0a8 <f0+0xb94>  // b.hs, b.nlast
    b090:	8b0102f7 	add	x23, x23, x1
    b094:	394002e0 	ldrb	w0, [x23]
    b098:	7103fc1f 	cmp	w0, #0xff
    b09c:	5400cc00 	b.eq	ca1c <f0+0x2508>  // b.none
    b0a0:	52800020 	mov	w0, #0x1                   	// #1
    b0a4:	390002e0 	strb	w0, [x23]
    b0a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b0ac:	910f63e1 	add	x1, sp, #0x3d8
    b0b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	f901efe2 	str	x2, [sp, #984]
    b0bc:	f901f3f5 	str	x21, [sp, #992]
    b0c0:	97ffe878 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0c4:	97ffeb24 	bl	5d54 <fwp_rc_fresh>
    b0c8:	aa0003e2 	mov	x2, x0
    b0cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0d0:	910fa3e1 	add	x1, sp, #0x3e8
    b0d4:	52800020 	mov	w0, #0x1                   	// #1
    b0d8:	f901f7e3 	str	x3, [sp, #1000]
    b0dc:	f901fbe2 	str	x2, [sp, #1008]
    b0e0:	97ffe870 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0e4:	9118c283 	add	x3, x20, #0x630
    b0e8:	aa0003f5 	mov	x21, x0
    b0ec:	f949d861 	ldr	x1, [x3, #5040]
    b0f0:	f949ec60 	ldr	x0, [x3, #5080]
    b0f4:	cb0102a1 	sub	x1, x21, x1
    b0f8:	eb00403f 	cmp	x1, x0, lsl #16
    b0fc:	54000322 	b.cs	b160 <f0+0xc4c>  // b.hs, b.nlast
    b100:	d350fc22 	lsr	x2, x1, #16
    b104:	f949fc63 	ldr	x3, [x3, #5112]
    b108:	8b020842 	add	x2, x2, x2, lsl #2
    b10c:	d37df042 	lsl	x2, x2, #3
    b110:	8b020060 	add	x0, x3, x2
    b114:	f9401017 	ldr	x23, [x0, #32]
    b118:	b4000257 	cbz	x23, b160 <f0+0xc4c>
    b11c:	38626862 	ldrb	w2, [x3, x2]
    b120:	7100085f 	cmp	w2, #0x2
    b124:	5400bf80 	b.eq	c914 <f0+0x2400>  // b.none
    b128:	7100045f 	cmp	w2, #0x1
    b12c:	540001a1 	b.ne	b160 <f0+0xc4c>  // b.any
    b130:	29430002 	ldp	w2, w0, [x0, #24]
    b134:	92403c21 	and	x1, x1, #0xffff
    b138:	9b027c21 	mul	x1, x1, x2
    b13c:	d360fc21 	lsr	x1, x1, #32
    b140:	eb00003f 	cmp	x1, x0
    b144:	540000e2 	b.cs	b160 <f0+0xc4c>  // b.hs, b.nlast
    b148:	8b0102f7 	add	x23, x23, x1
    b14c:	394002e0 	ldrb	w0, [x23]
    b150:	7103fc1f 	cmp	w0, #0xff
    b154:	5400c6a0 	b.eq	ca28 <f0+0x2514>  // b.none
    b158:	52800020 	mov	w0, #0x1                   	// #1
    b15c:	390002e0 	strb	w0, [x23]
    b160:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b164:	910fe3e1 	add	x1, sp, #0x3f8
    b168:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b16c:	52800020 	mov	w0, #0x1                   	// #1
    b170:	f901ffe2 	str	x2, [sp, #1016]
    b174:	f90203f5 	str	x21, [sp, #1024]
    b178:	97ffe84a 	bl	52a0 <fwp_data.part.0.constprop.0>
    b17c:	9118c283 	add	x3, x20, #0x630
    b180:	aa0003f5 	mov	x21, x0
    b184:	f949d861 	ldr	x1, [x3, #5040]
    b188:	f949ec60 	ldr	x0, [x3, #5080]
    b18c:	cb0102a1 	sub	x1, x21, x1
    b190:	eb00403f 	cmp	x1, x0, lsl #16
    b194:	54000322 	b.cs	b1f8 <f0+0xce4>  // b.hs, b.nlast
    b198:	d350fc22 	lsr	x2, x1, #16
    b19c:	f949fc63 	ldr	x3, [x3, #5112]
    b1a0:	8b020842 	add	x2, x2, x2, lsl #2
    b1a4:	d37df042 	lsl	x2, x2, #3
    b1a8:	8b020060 	add	x0, x3, x2
    b1ac:	f9401017 	ldr	x23, [x0, #32]
    b1b0:	b4000257 	cbz	x23, b1f8 <f0+0xce4>
    b1b4:	38626862 	ldrb	w2, [x3, x2]
    b1b8:	7100085f 	cmp	w2, #0x2
    b1bc:	5400ba60 	b.eq	c908 <f0+0x23f4>  // b.none
    b1c0:	7100045f 	cmp	w2, #0x1
    b1c4:	540001a1 	b.ne	b1f8 <f0+0xce4>  // b.any
    b1c8:	29430002 	ldp	w2, w0, [x0, #24]
    b1cc:	92403c21 	and	x1, x1, #0xffff
    b1d0:	9b027c21 	mul	x1, x1, x2
    b1d4:	d360fc21 	lsr	x1, x1, #32
    b1d8:	eb00003f 	cmp	x1, x0
    b1dc:	540000e2 	b.cs	b1f8 <f0+0xce4>  // b.hs, b.nlast
    b1e0:	8b0102f7 	add	x23, x23, x1
    b1e4:	394002e0 	ldrb	w0, [x23]
    b1e8:	7103fc1f 	cmp	w0, #0xff
    b1ec:	5400c240 	b.eq	ca34 <f0+0x2520>  // b.none
    b1f0:	52800020 	mov	w0, #0x1                   	// #1
    b1f4:	390002e0 	strb	w0, [x23]
    b1f8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1fc:	911023e1 	add	x1, sp, #0x408
    b200:	52800020 	mov	w0, #0x1                   	// #1
    b204:	f90207e2 	str	x2, [sp, #1032]
    b208:	f9020bf5 	str	x21, [sp, #1040]
    b20c:	97ffe825 	bl	52a0 <fwp_data.part.0.constprop.0>
    b210:	9118c283 	add	x3, x20, #0x630
    b214:	aa0003f5 	mov	x21, x0
    b218:	f949d861 	ldr	x1, [x3, #5040]
    b21c:	f949ec60 	ldr	x0, [x3, #5080]
    b220:	cb0102a1 	sub	x1, x21, x1
    b224:	eb00403f 	cmp	x1, x0, lsl #16
    b228:	54000322 	b.cs	b28c <f0+0xd78>  // b.hs, b.nlast
    b22c:	d350fc22 	lsr	x2, x1, #16
    b230:	f949fc63 	ldr	x3, [x3, #5112]
    b234:	8b020842 	add	x2, x2, x2, lsl #2
    b238:	d37df042 	lsl	x2, x2, #3
    b23c:	8b020060 	add	x0, x3, x2
    b240:	f9401017 	ldr	x23, [x0, #32]
    b244:	b4000257 	cbz	x23, b28c <f0+0xd78>
    b248:	38626862 	ldrb	w2, [x3, x2]
    b24c:	7100085f 	cmp	w2, #0x2
    b250:	5400b6e0 	b.eq	c92c <f0+0x2418>  // b.none
    b254:	7100045f 	cmp	w2, #0x1
    b258:	540001a1 	b.ne	b28c <f0+0xd78>  // b.any
    b25c:	29430002 	ldp	w2, w0, [x0, #24]
    b260:	92403c21 	and	x1, x1, #0xffff
    b264:	9b027c21 	mul	x1, x1, x2
    b268:	d360fc21 	lsr	x1, x1, #32
    b26c:	eb00003f 	cmp	x1, x0
    b270:	540000e2 	b.cs	b28c <f0+0xd78>  // b.hs, b.nlast
    b274:	8b0102f7 	add	x23, x23, x1
    b278:	394002e0 	ldrb	w0, [x23]
    b27c:	7103fc1f 	cmp	w0, #0xff
    b280:	5400be00 	b.eq	ca40 <f0+0x252c>  // b.none
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	390002e0 	strb	w0, [x23]
    b28c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b290:	911063e1 	add	x1, sp, #0x418
    b294:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	f9020fe2 	str	x2, [sp, #1048]
    b2a0:	f90213f5 	str	x21, [sp, #1056]
    b2a4:	97ffe7ff 	bl	52a0 <fwp_data.part.0.constprop.0>
    b2a8:	97ffeaab 	bl	5d54 <fwp_rc_fresh>
    b2ac:	aa0003e2 	mov	x2, x0
    b2b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b2b4:	9110a3e1 	add	x1, sp, #0x428
    b2b8:	52800020 	mov	w0, #0x1                   	// #1
    b2bc:	f90217e3 	str	x3, [sp, #1064]
    b2c0:	f9021be2 	str	x2, [sp, #1072]
    b2c4:	97ffe7f7 	bl	52a0 <fwp_data.part.0.constprop.0>
    b2c8:	9118c283 	add	x3, x20, #0x630
    b2cc:	aa0003f5 	mov	x21, x0
    b2d0:	f949d861 	ldr	x1, [x3, #5040]
    b2d4:	f949ec60 	ldr	x0, [x3, #5080]
    b2d8:	cb0102a1 	sub	x1, x21, x1
    b2dc:	eb00403f 	cmp	x1, x0, lsl #16
    b2e0:	54000322 	b.cs	b344 <f0+0xe30>  // b.hs, b.nlast
    b2e4:	d350fc22 	lsr	x2, x1, #16
    b2e8:	f949fc63 	ldr	x3, [x3, #5112]
    b2ec:	8b020842 	add	x2, x2, x2, lsl #2
    b2f0:	d37df042 	lsl	x2, x2, #3
    b2f4:	8b020060 	add	x0, x3, x2
    b2f8:	f9401017 	ldr	x23, [x0, #32]
    b2fc:	b4000257 	cbz	x23, b344 <f0+0xe30>
    b300:	38626862 	ldrb	w2, [x3, x2]
    b304:	7100085f 	cmp	w2, #0x2
    b308:	5400b0c0 	b.eq	c920 <f0+0x240c>  // b.none
    b30c:	7100045f 	cmp	w2, #0x1
    b310:	540001a1 	b.ne	b344 <f0+0xe30>  // b.any
    b314:	29430002 	ldp	w2, w0, [x0, #24]
    b318:	92403c21 	and	x1, x1, #0xffff
    b31c:	9b027c21 	mul	x1, x1, x2
    b320:	d360fc21 	lsr	x1, x1, #32
    b324:	eb00003f 	cmp	x1, x0
    b328:	540000e2 	b.cs	b344 <f0+0xe30>  // b.hs, b.nlast
    b32c:	8b0102f7 	add	x23, x23, x1
    b330:	394002e0 	ldrb	w0, [x23]
    b334:	7103fc1f 	cmp	w0, #0xff
    b338:	5400b8a0 	b.eq	ca4c <f0+0x2538>  // b.none
    b33c:	52800020 	mov	w0, #0x1                   	// #1
    b340:	390002e0 	strb	w0, [x23]
    b344:	9110e3e1 	add	x1, sp, #0x438
    b348:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b34c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b350:	52800020 	mov	w0, #0x1                   	// #1
    b354:	f9021ff7 	str	x23, [sp, #1080]
    b358:	f90223f5 	str	x21, [sp, #1088]
    b35c:	97ffe7d1 	bl	52a0 <fwp_data.part.0.constprop.0>
    b360:	97ffea7d 	bl	5d54 <fwp_rc_fresh>
    b364:	aa0003e2 	mov	x2, x0
    b368:	911123e1 	add	x1, sp, #0x448
    b36c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b370:	52800020 	mov	w0, #0x1                   	// #1
    b374:	f90227f5 	str	x21, [sp, #1096]
    b378:	f9022be2 	str	x2, [sp, #1104]
    b37c:	97ffe7c9 	bl	52a0 <fwp_data.part.0.constprop.0>
    b380:	97ffea75 	bl	5d54 <fwp_rc_fresh>
    b384:	aa0003e2 	mov	x2, x0
    b388:	911163e1 	add	x1, sp, #0x458
    b38c:	52800020 	mov	w0, #0x1                   	// #1
    b390:	f9022ff7 	str	x23, [sp, #1112]
    b394:	f90233e2 	str	x2, [sp, #1120]
    b398:	97ffe7c2 	bl	52a0 <fwp_data.part.0.constprop.0>
    b39c:	97ffea6e 	bl	5d54 <fwp_rc_fresh>
    b3a0:	aa0003e2 	mov	x2, x0
    b3a4:	9111a3e1 	add	x1, sp, #0x468
    b3a8:	52800020 	mov	w0, #0x1                   	// #1
    b3ac:	f90237f5 	str	x21, [sp, #1128]
    b3b0:	f9023be2 	str	x2, [sp, #1136]
    b3b4:	97ffe7bb 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3b8:	97ffea67 	bl	5d54 <fwp_rc_fresh>
    b3bc:	aa0003e2 	mov	x2, x0
    b3c0:	9111e3e1 	add	x1, sp, #0x478
    b3c4:	52800020 	mov	w0, #0x1                   	// #1
    b3c8:	f9023ff7 	str	x23, [sp, #1144]
    b3cc:	f90243e2 	str	x2, [sp, #1152]
    b3d0:	97ffe7b4 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3d4:	9118c283 	add	x3, x20, #0x630
    b3d8:	aa0003f5 	mov	x21, x0
    b3dc:	f949d861 	ldr	x1, [x3, #5040]
    b3e0:	f949ec60 	ldr	x0, [x3, #5080]
    b3e4:	cb0102a1 	sub	x1, x21, x1
    b3e8:	eb00403f 	cmp	x1, x0, lsl #16
    b3ec:	54000322 	b.cs	b450 <f0+0xf3c>  // b.hs, b.nlast
    b3f0:	d350fc22 	lsr	x2, x1, #16
    b3f4:	f949fc63 	ldr	x3, [x3, #5112]
    b3f8:	8b020842 	add	x2, x2, x2, lsl #2
    b3fc:	d37df042 	lsl	x2, x2, #3
    b400:	8b020060 	add	x0, x3, x2
    b404:	f9401017 	ldr	x23, [x0, #32]
    b408:	b4000257 	cbz	x23, b450 <f0+0xf3c>
    b40c:	38626862 	ldrb	w2, [x3, x2]
    b410:	7100085f 	cmp	w2, #0x2
    b414:	5400a980 	b.eq	c944 <f0+0x2430>  // b.none
    b418:	7100045f 	cmp	w2, #0x1
    b41c:	540001a1 	b.ne	b450 <f0+0xf3c>  // b.any
    b420:	29430002 	ldp	w2, w0, [x0, #24]
    b424:	92403c21 	and	x1, x1, #0xffff
    b428:	9b027c21 	mul	x1, x1, x2
    b42c:	d360fc21 	lsr	x1, x1, #32
    b430:	eb00003f 	cmp	x1, x0
    b434:	540000e2 	b.cs	b450 <f0+0xf3c>  // b.hs, b.nlast
    b438:	8b0102f7 	add	x23, x23, x1
    b43c:	394002e0 	ldrb	w0, [x23]
    b440:	7103fc1f 	cmp	w0, #0xff
    b444:	5400b0a0 	b.eq	ca58 <f0+0x2544>  // b.none
    b448:	52800020 	mov	w0, #0x1                   	// #1
    b44c:	390002e0 	strb	w0, [x23]
    b450:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b454:	911223e1 	add	x1, sp, #0x488
    b458:	52800020 	mov	w0, #0x1                   	// #1
    b45c:	f90247e2 	str	x2, [sp, #1160]
    b460:	f9024bf5 	str	x21, [sp, #1168]
    b464:	97ffe78f 	bl	52a0 <fwp_data.part.0.constprop.0>
    b468:	9118c283 	add	x3, x20, #0x630
    b46c:	aa0003f5 	mov	x21, x0
    b470:	f949d861 	ldr	x1, [x3, #5040]
    b474:	f949ec60 	ldr	x0, [x3, #5080]
    b478:	cb0102a1 	sub	x1, x21, x1
    b47c:	eb00403f 	cmp	x1, x0, lsl #16
    b480:	54000322 	b.cs	b4e4 <f0+0xfd0>  // b.hs, b.nlast
    b484:	d350fc22 	lsr	x2, x1, #16
    b488:	f949fc63 	ldr	x3, [x3, #5112]
    b48c:	8b020842 	add	x2, x2, x2, lsl #2
    b490:	d37df042 	lsl	x2, x2, #3
    b494:	8b020060 	add	x0, x3, x2
    b498:	f9401017 	ldr	x23, [x0, #32]
    b49c:	b4000257 	cbz	x23, b4e4 <f0+0xfd0>
    b4a0:	38626862 	ldrb	w2, [x3, x2]
    b4a4:	7100085f 	cmp	w2, #0x2
    b4a8:	5400a480 	b.eq	c938 <f0+0x2424>  // b.none
    b4ac:	7100045f 	cmp	w2, #0x1
    b4b0:	540001a1 	b.ne	b4e4 <f0+0xfd0>  // b.any
    b4b4:	29430002 	ldp	w2, w0, [x0, #24]
    b4b8:	92403c21 	and	x1, x1, #0xffff
    b4bc:	9b027c21 	mul	x1, x1, x2
    b4c0:	d360fc21 	lsr	x1, x1, #32
    b4c4:	eb00003f 	cmp	x1, x0
    b4c8:	540000e2 	b.cs	b4e4 <f0+0xfd0>  // b.hs, b.nlast
    b4cc:	8b0102f7 	add	x23, x23, x1
    b4d0:	394002e0 	ldrb	w0, [x23]
    b4d4:	7103fc1f 	cmp	w0, #0xff
    b4d8:	5400ac60 	b.eq	ca64 <f0+0x2550>  // b.none
    b4dc:	52800020 	mov	w0, #0x1                   	// #1
    b4e0:	390002e0 	strb	w0, [x23]
    b4e4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b4e8:	911263e1 	add	x1, sp, #0x498
    b4ec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b4f0:	52800020 	mov	w0, #0x1                   	// #1
    b4f4:	f9024fe2 	str	x2, [sp, #1176]
    b4f8:	f90253f5 	str	x21, [sp, #1184]
    b4fc:	97ffe769 	bl	52a0 <fwp_data.part.0.constprop.0>
    b500:	97ffea15 	bl	5d54 <fwp_rc_fresh>
    b504:	aa0003e2 	mov	x2, x0
    b508:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b50c:	9112a3e1 	add	x1, sp, #0x4a8
    b510:	52800020 	mov	w0, #0x1                   	// #1
    b514:	f90257e3 	str	x3, [sp, #1192]
    b518:	f9025be2 	str	x2, [sp, #1200]
    b51c:	97ffe761 	bl	52a0 <fwp_data.part.0.constprop.0>
    b520:	9118c283 	add	x3, x20, #0x630
    b524:	aa0003f5 	mov	x21, x0
    b528:	f949d861 	ldr	x1, [x3, #5040]
    b52c:	f949ec60 	ldr	x0, [x3, #5080]
    b530:	cb0102a1 	sub	x1, x21, x1
    b534:	eb00403f 	cmp	x1, x0, lsl #16
    b538:	54000322 	b.cs	b59c <f0+0x1088>  // b.hs, b.nlast
    b53c:	d350fc22 	lsr	x2, x1, #16
    b540:	f949fc63 	ldr	x3, [x3, #5112]
    b544:	8b020842 	add	x2, x2, x2, lsl #2
    b548:	d37df042 	lsl	x2, x2, #3
    b54c:	8b020060 	add	x0, x3, x2
    b550:	f9401017 	ldr	x23, [x0, #32]
    b554:	b4000257 	cbz	x23, b59c <f0+0x1088>
    b558:	38626862 	ldrb	w2, [x3, x2]
    b55c:	7100085f 	cmp	w2, #0x2
    b560:	54009fe0 	b.eq	c95c <f0+0x2448>  // b.none
    b564:	7100045f 	cmp	w2, #0x1
    b568:	540001a1 	b.ne	b59c <f0+0x1088>  // b.any
    b56c:	29430002 	ldp	w2, w0, [x0, #24]
    b570:	92403c21 	and	x1, x1, #0xffff
    b574:	9b027c21 	mul	x1, x1, x2
    b578:	d360fc21 	lsr	x1, x1, #32
    b57c:	eb00003f 	cmp	x1, x0
    b580:	540000e2 	b.cs	b59c <f0+0x1088>  // b.hs, b.nlast
    b584:	8b0102f7 	add	x23, x23, x1
    b588:	394002e0 	ldrb	w0, [x23]
    b58c:	7103fc1f 	cmp	w0, #0xff
    b590:	5400a700 	b.eq	ca70 <f0+0x255c>  // b.none
    b594:	52800020 	mov	w0, #0x1                   	// #1
    b598:	390002e0 	strb	w0, [x23]
    b59c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b5a0:	9112e3e1 	add	x1, sp, #0x4b8
    b5a4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b5a8:	52800020 	mov	w0, #0x1                   	// #1
    b5ac:	f9025fe2 	str	x2, [sp, #1208]
    b5b0:	f90263f5 	str	x21, [sp, #1216]
    b5b4:	97ffe73b 	bl	52a0 <fwp_data.part.0.constprop.0>
    b5b8:	97ffe9e7 	bl	5d54 <fwp_rc_fresh>
    b5bc:	aa0003e2 	mov	x2, x0
    b5c0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b5c4:	911323e1 	add	x1, sp, #0x4c8
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f90267e3 	str	x3, [sp, #1224]
    b5d0:	f9026be2 	str	x2, [sp, #1232]
    b5d4:	97ffe733 	bl	52a0 <fwp_data.part.0.constprop.0>
    b5d8:	9118c283 	add	x3, x20, #0x630
    b5dc:	aa0003f5 	mov	x21, x0
    b5e0:	f949d861 	ldr	x1, [x3, #5040]
    b5e4:	f949ec60 	ldr	x0, [x3, #5080]
    b5e8:	cb0102a1 	sub	x1, x21, x1
    b5ec:	eb00403f 	cmp	x1, x0, lsl #16
    b5f0:	54000322 	b.cs	b654 <f0+0x1140>  // b.hs, b.nlast
    b5f4:	d350fc22 	lsr	x2, x1, #16
    b5f8:	f949fc63 	ldr	x3, [x3, #5112]
    b5fc:	8b020842 	add	x2, x2, x2, lsl #2
    b600:	d37df042 	lsl	x2, x2, #3
    b604:	8b020060 	add	x0, x3, x2
    b608:	f9401017 	ldr	x23, [x0, #32]
    b60c:	b4000257 	cbz	x23, b654 <f0+0x1140>
    b610:	38626862 	ldrb	w2, [x3, x2]
    b614:	7100085f 	cmp	w2, #0x2
    b618:	540099c0 	b.eq	c950 <f0+0x243c>  // b.none
    b61c:	7100045f 	cmp	w2, #0x1
    b620:	540001a1 	b.ne	b654 <f0+0x1140>  // b.any
    b624:	29430002 	ldp	w2, w0, [x0, #24]
    b628:	92403c21 	and	x1, x1, #0xffff
    b62c:	9b027c21 	mul	x1, x1, x2
    b630:	d360fc21 	lsr	x1, x1, #32
    b634:	eb00003f 	cmp	x1, x0
    b638:	540000e2 	b.cs	b654 <f0+0x1140>  // b.hs, b.nlast
    b63c:	8b0102f7 	add	x23, x23, x1
    b640:	394002e0 	ldrb	w0, [x23]
    b644:	7103fc1f 	cmp	w0, #0xff
    b648:	5400a1a0 	b.eq	ca7c <f0+0x2568>  // b.none
    b64c:	52800020 	mov	w0, #0x1                   	// #1
    b650:	390002e0 	strb	w0, [x23]
    b654:	911363e1 	add	x1, sp, #0x4d8
    b658:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b65c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	f9026ff7 	str	x23, [sp, #1240]
    b668:	f90273f5 	str	x21, [sp, #1248]
    b66c:	97ffe70d 	bl	52a0 <fwp_data.part.0.constprop.0>
    b670:	97ffe9b9 	bl	5d54 <fwp_rc_fresh>
    b674:	aa0003e2 	mov	x2, x0
    b678:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b67c:	9113a3e1 	add	x1, sp, #0x4e8
    b680:	52800020 	mov	w0, #0x1                   	// #1
    b684:	f90277e3 	str	x3, [sp, #1256]
    b688:	f9027be2 	str	x2, [sp, #1264]
    b68c:	97ffe705 	bl	52a0 <fwp_data.part.0.constprop.0>
    b690:	97ffe9b1 	bl	5d54 <fwp_rc_fresh>
    b694:	aa0003e2 	mov	x2, x0
    b698:	9113e3e1 	add	x1, sp, #0x4f8
    b69c:	52800020 	mov	w0, #0x1                   	// #1
    b6a0:	f9027ff7 	str	x23, [sp, #1272]
    b6a4:	f90283e2 	str	x2, [sp, #1280]
    b6a8:	97ffe6fe 	bl	52a0 <fwp_data.part.0.constprop.0>
    b6ac:	9118c283 	add	x3, x20, #0x630
    b6b0:	aa0003f5 	mov	x21, x0
    b6b4:	f949d861 	ldr	x1, [x3, #5040]
    b6b8:	f949ec60 	ldr	x0, [x3, #5080]
    b6bc:	cb0102a1 	sub	x1, x21, x1
    b6c0:	eb00403f 	cmp	x1, x0, lsl #16
    b6c4:	54000322 	b.cs	b728 <f0+0x1214>  // b.hs, b.nlast
    b6c8:	d350fc22 	lsr	x2, x1, #16
    b6cc:	f949fc63 	ldr	x3, [x3, #5112]
    b6d0:	8b020842 	add	x2, x2, x2, lsl #2
    b6d4:	d37df042 	lsl	x2, x2, #3
    b6d8:	8b020060 	add	x0, x3, x2
    b6dc:	f9401017 	ldr	x23, [x0, #32]
    b6e0:	b4000257 	cbz	x23, b728 <f0+0x1214>
    b6e4:	38626862 	ldrb	w2, [x3, x2]
    b6e8:	7100085f 	cmp	w2, #0x2
    b6ec:	54009440 	b.eq	c974 <f0+0x2460>  // b.none
    b6f0:	7100045f 	cmp	w2, #0x1
    b6f4:	540001a1 	b.ne	b728 <f0+0x1214>  // b.any
    b6f8:	29430002 	ldp	w2, w0, [x0, #24]
    b6fc:	92403c21 	and	x1, x1, #0xffff
    b700:	9b027c21 	mul	x1, x1, x2
    b704:	d360fc21 	lsr	x1, x1, #32
    b708:	eb00003f 	cmp	x1, x0
    b70c:	540000e2 	b.cs	b728 <f0+0x1214>  // b.hs, b.nlast
    b710:	8b0102f7 	add	x23, x23, x1
    b714:	394002e0 	ldrb	w0, [x23]
    b718:	7103fc1f 	cmp	w0, #0xff
    b71c:	54009b60 	b.eq	ca88 <f0+0x2574>  // b.none
    b720:	52800020 	mov	w0, #0x1                   	// #1
    b724:	390002e0 	strb	w0, [x23]
    b728:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b72c:	911423e1 	add	x1, sp, #0x508
    b730:	52800020 	mov	w0, #0x1                   	// #1
    b734:	f90287e2 	str	x2, [sp, #1288]
    b738:	f9028bf5 	str	x21, [sp, #1296]
    b73c:	97ffe6d9 	bl	52a0 <fwp_data.part.0.constprop.0>
    b740:	9118c283 	add	x3, x20, #0x630
    b744:	aa0003f5 	mov	x21, x0
    b748:	f949d861 	ldr	x1, [x3, #5040]
    b74c:	f949ec60 	ldr	x0, [x3, #5080]
    b750:	cb0102a1 	sub	x1, x21, x1
    b754:	eb00403f 	cmp	x1, x0, lsl #16
    b758:	54000322 	b.cs	b7bc <f0+0x12a8>  // b.hs, b.nlast
    b75c:	d350fc22 	lsr	x2, x1, #16
    b760:	f949fc63 	ldr	x3, [x3, #5112]
    b764:	8b020842 	add	x2, x2, x2, lsl #2
    b768:	d37df042 	lsl	x2, x2, #3
    b76c:	8b020060 	add	x0, x3, x2
    b770:	f9401017 	ldr	x23, [x0, #32]
    b774:	b4000257 	cbz	x23, b7bc <f0+0x12a8>
    b778:	38626862 	ldrb	w2, [x3, x2]
    b77c:	7100085f 	cmp	w2, #0x2
    b780:	54008f40 	b.eq	c968 <f0+0x2454>  // b.none
    b784:	7100045f 	cmp	w2, #0x1
    b788:	540001a1 	b.ne	b7bc <f0+0x12a8>  // b.any
    b78c:	29430002 	ldp	w2, w0, [x0, #24]
    b790:	92403c21 	and	x1, x1, #0xffff
    b794:	9b027c21 	mul	x1, x1, x2
    b798:	d360fc21 	lsr	x1, x1, #32
    b79c:	eb00003f 	cmp	x1, x0
    b7a0:	540000e2 	b.cs	b7bc <f0+0x12a8>  // b.hs, b.nlast
    b7a4:	8b0102f7 	add	x23, x23, x1
    b7a8:	394002e0 	ldrb	w0, [x23]
    b7ac:	7103fc1f 	cmp	w0, #0xff
    b7b0:	54009720 	b.eq	ca94 <f0+0x2580>  // b.none
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	390002e0 	strb	w0, [x23]
    b7bc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b7c0:	911463e1 	add	x1, sp, #0x518
    b7c4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b7c8:	52800020 	mov	w0, #0x1                   	// #1
    b7cc:	f9028fe2 	str	x2, [sp, #1304]
    b7d0:	f90293f5 	str	x21, [sp, #1312]
    b7d4:	97ffe6b3 	bl	52a0 <fwp_data.part.0.constprop.0>
    b7d8:	97ffe95f 	bl	5d54 <fwp_rc_fresh>
    b7dc:	aa0003e2 	mov	x2, x0
    b7e0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b7e4:	9114a3e1 	add	x1, sp, #0x528
    b7e8:	52800020 	mov	w0, #0x1                   	// #1
    b7ec:	f90297e3 	str	x3, [sp, #1320]
    b7f0:	f9029be2 	str	x2, [sp, #1328]
    b7f4:	97ffe6ab 	bl	52a0 <fwp_data.part.0.constprop.0>
    b7f8:	9118c283 	add	x3, x20, #0x630
    b7fc:	aa0003f5 	mov	x21, x0
    b800:	f949d861 	ldr	x1, [x3, #5040]
    b804:	f949ec60 	ldr	x0, [x3, #5080]
    b808:	cb0102a1 	sub	x1, x21, x1
    b80c:	eb00403f 	cmp	x1, x0, lsl #16
    b810:	54000322 	b.cs	b874 <f0+0x1360>  // b.hs, b.nlast
    b814:	d350fc22 	lsr	x2, x1, #16
    b818:	f949fc63 	ldr	x3, [x3, #5112]
    b81c:	8b020842 	add	x2, x2, x2, lsl #2
    b820:	d37df042 	lsl	x2, x2, #3
    b824:	8b020060 	add	x0, x3, x2
    b828:	f9401017 	ldr	x23, [x0, #32]
    b82c:	b4000257 	cbz	x23, b874 <f0+0x1360>
    b830:	38626862 	ldrb	w2, [x3, x2]
    b834:	7100085f 	cmp	w2, #0x2
    b838:	54008aa0 	b.eq	c98c <f0+0x2478>  // b.none
    b83c:	7100045f 	cmp	w2, #0x1
    b840:	540001a1 	b.ne	b874 <f0+0x1360>  // b.any
    b844:	29430002 	ldp	w2, w0, [x0, #24]
    b848:	92403c21 	and	x1, x1, #0xffff
    b84c:	9b027c21 	mul	x1, x1, x2
    b850:	d360fc21 	lsr	x1, x1, #32
    b854:	eb00003f 	cmp	x1, x0
    b858:	540000e2 	b.cs	b874 <f0+0x1360>  // b.hs, b.nlast
    b85c:	8b0102f7 	add	x23, x23, x1
    b860:	394002e0 	ldrb	w0, [x23]
    b864:	7103fc1f 	cmp	w0, #0xff
    b868:	540091c0 	b.eq	caa0 <f0+0x258c>  // b.none
    b86c:	52800020 	mov	w0, #0x1                   	// #1
    b870:	390002e0 	strb	w0, [x23]
    b874:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b878:	9114e3e1 	add	x1, sp, #0x538
    b87c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	f9029fe2 	str	x2, [sp, #1336]
    b888:	f902a3f5 	str	x21, [sp, #1344]
    b88c:	97ffe685 	bl	52a0 <fwp_data.part.0.constprop.0>
    b890:	97ffe931 	bl	5d54 <fwp_rc_fresh>
    b894:	aa0003e2 	mov	x2, x0
    b898:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b89c:	911523e1 	add	x1, sp, #0x548
    b8a0:	52800020 	mov	w0, #0x1                   	// #1
    b8a4:	f902a7e3 	str	x3, [sp, #1352]
    b8a8:	f902abe2 	str	x2, [sp, #1360]
    b8ac:	97ffe67d 	bl	52a0 <fwp_data.part.0.constprop.0>
    b8b0:	9118c283 	add	x3, x20, #0x630
    b8b4:	aa0003f5 	mov	x21, x0
    b8b8:	f949d861 	ldr	x1, [x3, #5040]
    b8bc:	f949ec60 	ldr	x0, [x3, #5080]
    b8c0:	cb0102a1 	sub	x1, x21, x1
    b8c4:	eb00403f 	cmp	x1, x0, lsl #16
    b8c8:	54000322 	b.cs	b92c <f0+0x1418>  // b.hs, b.nlast
    b8cc:	d350fc22 	lsr	x2, x1, #16
    b8d0:	f949fc63 	ldr	x3, [x3, #5112]
    b8d4:	8b020842 	add	x2, x2, x2, lsl #2
    b8d8:	d37df042 	lsl	x2, x2, #3
    b8dc:	8b020060 	add	x0, x3, x2
    b8e0:	f9401017 	ldr	x23, [x0, #32]
    b8e4:	b4000257 	cbz	x23, b92c <f0+0x1418>
    b8e8:	38626862 	ldrb	w2, [x3, x2]
    b8ec:	7100085f 	cmp	w2, #0x2
    b8f0:	54008480 	b.eq	c980 <f0+0x246c>  // b.none
    b8f4:	7100045f 	cmp	w2, #0x1
    b8f8:	540001a1 	b.ne	b92c <f0+0x1418>  // b.any
    b8fc:	29430002 	ldp	w2, w0, [x0, #24]
    b900:	92403c21 	and	x1, x1, #0xffff
    b904:	9b027c21 	mul	x1, x1, x2
    b908:	d360fc21 	lsr	x1, x1, #32
    b90c:	eb00003f 	cmp	x1, x0
    b910:	540000e2 	b.cs	b92c <f0+0x1418>  // b.hs, b.nlast
    b914:	8b0102f7 	add	x23, x23, x1
    b918:	394002e0 	ldrb	w0, [x23]
    b91c:	7103fc1f 	cmp	w0, #0xff
    b920:	54008c60 	b.eq	caac <f0+0x2598>  // b.none
    b924:	52800020 	mov	w0, #0x1                   	// #1
    b928:	390002e0 	strb	w0, [x23]
    b92c:	911563e1 	add	x1, sp, #0x558
    b930:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b934:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b938:	52800020 	mov	w0, #0x1                   	// #1
    b93c:	f902aff7 	str	x23, [sp, #1368]
    b940:	f902b3f5 	str	x21, [sp, #1376]
    b944:	97ffe657 	bl	52a0 <fwp_data.part.0.constprop.0>
    b948:	97ffe903 	bl	5d54 <fwp_rc_fresh>
    b94c:	aa0003e2 	mov	x2, x0
    b950:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b954:	9115a3e1 	add	x1, sp, #0x568
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f902b7e3 	str	x3, [sp, #1384]
    b960:	f902bbe2 	str	x2, [sp, #1392]
    b964:	97ffe64f 	bl	52a0 <fwp_data.part.0.constprop.0>
    b968:	97ffe8fb 	bl	5d54 <fwp_rc_fresh>
    b96c:	aa0003e2 	mov	x2, x0
    b970:	9115e3e1 	add	x1, sp, #0x578
    b974:	52800020 	mov	w0, #0x1                   	// #1
    b978:	f902bff7 	str	x23, [sp, #1400]
    b97c:	f902c3e2 	str	x2, [sp, #1408]
    b980:	97ffe648 	bl	52a0 <fwp_data.part.0.constprop.0>
    b984:	9118c283 	add	x3, x20, #0x630
    b988:	aa0003f5 	mov	x21, x0
    b98c:	f949d861 	ldr	x1, [x3, #5040]
    b990:	f949ec60 	ldr	x0, [x3, #5080]
    b994:	cb0102a1 	sub	x1, x21, x1
    b998:	eb00403f 	cmp	x1, x0, lsl #16
    b99c:	54000322 	b.cs	ba00 <f0+0x14ec>  // b.hs, b.nlast
    b9a0:	d350fc22 	lsr	x2, x1, #16
    b9a4:	f949fc63 	ldr	x3, [x3, #5112]
    b9a8:	8b020842 	add	x2, x2, x2, lsl #2
    b9ac:	d37df042 	lsl	x2, x2, #3
    b9b0:	8b020060 	add	x0, x3, x2
    b9b4:	f9401017 	ldr	x23, [x0, #32]
    b9b8:	b4000257 	cbz	x23, ba00 <f0+0x14ec>
    b9bc:	38626862 	ldrb	w2, [x3, x2]
    b9c0:	7100085f 	cmp	w2, #0x2
    b9c4:	54007f00 	b.eq	c9a4 <f0+0x2490>  // b.none
    b9c8:	7100045f 	cmp	w2, #0x1
    b9cc:	540001a1 	b.ne	ba00 <f0+0x14ec>  // b.any
    b9d0:	29430002 	ldp	w2, w0, [x0, #24]
    b9d4:	92403c21 	and	x1, x1, #0xffff
    b9d8:	9b027c21 	mul	x1, x1, x2
    b9dc:	d360fc21 	lsr	x1, x1, #32
    b9e0:	eb00003f 	cmp	x1, x0
    b9e4:	540000e2 	b.cs	ba00 <f0+0x14ec>  // b.hs, b.nlast
    b9e8:	8b0102f7 	add	x23, x23, x1
    b9ec:	394002e0 	ldrb	w0, [x23]
    b9f0:	7103fc1f 	cmp	w0, #0xff
    b9f4:	54008620 	b.eq	cab8 <f0+0x25a4>  // b.none
    b9f8:	52800020 	mov	w0, #0x1                   	// #1
    b9fc:	390002e0 	strb	w0, [x23]
    ba00:	911623e1 	add	x1, sp, #0x588
    ba04:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba08:	52800020 	mov	w0, #0x1                   	// #1
    ba0c:	f902c7f7 	str	x23, [sp, #1416]
    ba10:	f902cbf5 	str	x21, [sp, #1424]
    ba14:	97ffe623 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba18:	97ffe8cf 	bl	5d54 <fwp_rc_fresh>
    ba1c:	aa0003e2 	mov	x2, x0
    ba20:	911663e1 	add	x1, sp, #0x598
    ba24:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ba28:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	f902cff5 	str	x21, [sp, #1432]
    ba34:	f902d3e2 	str	x2, [sp, #1440]
    ba38:	97ffe61a 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba3c:	97ffe8c6 	bl	5d54 <fwp_rc_fresh>
    ba40:	aa0003e2 	mov	x2, x0
    ba44:	9116a3e1 	add	x1, sp, #0x5a8
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f902d7f7 	str	x23, [sp, #1448]
    ba50:	f902dbe2 	str	x2, [sp, #1456]
    ba54:	97ffe613 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba58:	97ffe8bf 	bl	5d54 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	9116e3e1 	add	x1, sp, #0x5b8
    ba64:	52800020 	mov	w0, #0x1                   	// #1
    ba68:	f902dff5 	str	x21, [sp, #1464]
    ba6c:	f902e3e2 	str	x2, [sp, #1472]
    ba70:	97ffe60c 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba74:	97ffe8b8 	bl	5d54 <fwp_rc_fresh>
    ba78:	aa0003e2 	mov	x2, x0
    ba7c:	911723e1 	add	x1, sp, #0x5c8
    ba80:	52800020 	mov	w0, #0x1                   	// #1
    ba84:	f902e7f7 	str	x23, [sp, #1480]
    ba88:	f902ebe2 	str	x2, [sp, #1488]
    ba8c:	97ffe605 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba90:	9118c283 	add	x3, x20, #0x630
    ba94:	aa0003f5 	mov	x21, x0
    ba98:	f949d861 	ldr	x1, [x3, #5040]
    ba9c:	f949ec60 	ldr	x0, [x3, #5080]
    baa0:	cb0102a1 	sub	x1, x21, x1
    baa4:	eb00403f 	cmp	x1, x0, lsl #16
    baa8:	54000322 	b.cs	bb0c <f0+0x15f8>  // b.hs, b.nlast
    baac:	d350fc22 	lsr	x2, x1, #16
    bab0:	f949fc63 	ldr	x3, [x3, #5112]
    bab4:	8b020842 	add	x2, x2, x2, lsl #2
    bab8:	d37df042 	lsl	x2, x2, #3
    babc:	8b020060 	add	x0, x3, x2
    bac0:	f9401017 	ldr	x23, [x0, #32]
    bac4:	b4000257 	cbz	x23, bb0c <f0+0x15f8>
    bac8:	38626862 	ldrb	w2, [x3, x2]
    bacc:	7100085f 	cmp	w2, #0x2
    bad0:	54007640 	b.eq	c998 <f0+0x2484>  // b.none
    bad4:	7100045f 	cmp	w2, #0x1
    bad8:	540001a1 	b.ne	bb0c <f0+0x15f8>  // b.any
    badc:	29430002 	ldp	w2, w0, [x0, #24]
    bae0:	92403c21 	and	x1, x1, #0xffff
    bae4:	9b027c21 	mul	x1, x1, x2
    bae8:	d360fc21 	lsr	x1, x1, #32
    baec:	eb00003f 	cmp	x1, x0
    baf0:	540000e2 	b.cs	bb0c <f0+0x15f8>  // b.hs, b.nlast
    baf4:	8b0102f7 	add	x23, x23, x1
    baf8:	394002e0 	ldrb	w0, [x23]
    bafc:	7103fc1f 	cmp	w0, #0xff
    bb00:	54007e20 	b.eq	cac4 <f0+0x25b0>  // b.none
    bb04:	52800020 	mov	w0, #0x1                   	// #1
    bb08:	390002e0 	strb	w0, [x23]
    bb0c:	911763e1 	add	x1, sp, #0x5d8
    bb10:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb14:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb18:	52800020 	mov	w0, #0x1                   	// #1
    bb1c:	f902eff7 	str	x23, [sp, #1496]
    bb20:	f902f3f5 	str	x21, [sp, #1504]
    bb24:	97ffe5df 	bl	52a0 <fwp_data.part.0.constprop.0>
    bb28:	97ffe88b 	bl	5d54 <fwp_rc_fresh>
    bb2c:	aa0003e2 	mov	x2, x0
    bb30:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bb34:	9117a3e1 	add	x1, sp, #0x5e8
    bb38:	52800020 	mov	w0, #0x1                   	// #1
    bb3c:	f902f7e3 	str	x3, [sp, #1512]
    bb40:	f902fbe2 	str	x2, [sp, #1520]
    bb44:	97ffe5d7 	bl	52a0 <fwp_data.part.0.constprop.0>
    bb48:	97ffe883 	bl	5d54 <fwp_rc_fresh>
    bb4c:	aa0003e2 	mov	x2, x0
    bb50:	9117e3e1 	add	x1, sp, #0x5f8
    bb54:	52800020 	mov	w0, #0x1                   	// #1
    bb58:	f902fff7 	str	x23, [sp, #1528]
    bb5c:	f90303e2 	str	x2, [sp, #1536]
    bb60:	97ffe5d0 	bl	52a0 <fwp_data.part.0.constprop.0>
    bb64:	9118c283 	add	x3, x20, #0x630
    bb68:	aa0003f5 	mov	x21, x0
    bb6c:	f949d861 	ldr	x1, [x3, #5040]
    bb70:	f949ec60 	ldr	x0, [x3, #5080]
    bb74:	cb0102a1 	sub	x1, x21, x1
    bb78:	eb00403f 	cmp	x1, x0, lsl #16
    bb7c:	54000322 	b.cs	bbe0 <f0+0x16cc>  // b.hs, b.nlast
    bb80:	d350fc22 	lsr	x2, x1, #16
    bb84:	f949fc63 	ldr	x3, [x3, #5112]
    bb88:	8b020842 	add	x2, x2, x2, lsl #2
    bb8c:	d37df042 	lsl	x2, x2, #3
    bb90:	8b020060 	add	x0, x3, x2
    bb94:	f9401017 	ldr	x23, [x0, #32]
    bb98:	b4000257 	cbz	x23, bbe0 <f0+0x16cc>
    bb9c:	38626862 	ldrb	w2, [x3, x2]
    bba0:	7100085f 	cmp	w2, #0x2
    bba4:	540064c0 	b.eq	c83c <f0+0x2328>  // b.none
    bba8:	7100045f 	cmp	w2, #0x1
    bbac:	540001a1 	b.ne	bbe0 <f0+0x16cc>  // b.any
    bbb0:	29430002 	ldp	w2, w0, [x0, #24]
    bbb4:	92403c21 	and	x1, x1, #0xffff
    bbb8:	9b027c21 	mul	x1, x1, x2
    bbbc:	d360fc21 	lsr	x1, x1, #32
    bbc0:	eb00003f 	cmp	x1, x0
    bbc4:	540000e2 	b.cs	bbe0 <f0+0x16cc>  // b.hs, b.nlast
    bbc8:	8b0102f7 	add	x23, x23, x1
    bbcc:	394002e0 	ldrb	w0, [x23]
    bbd0:	7103fc1f 	cmp	w0, #0xff
    bbd4:	540077e0 	b.eq	cad0 <f0+0x25bc>  // b.none
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	390002e0 	strb	w0, [x23]
    bbe0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbe4:	911823e1 	add	x1, sp, #0x608
    bbe8:	52800020 	mov	w0, #0x1                   	// #1
    bbec:	f90307e2 	str	x2, [sp, #1544]
    bbf0:	f9030bf5 	str	x21, [sp, #1552]
    bbf4:	97ffe5ab 	bl	52a0 <fwp_data.part.0.constprop.0>
    bbf8:	9118c283 	add	x3, x20, #0x630
    bbfc:	aa0003f5 	mov	x21, x0
    bc00:	f949d861 	ldr	x1, [x3, #5040]
    bc04:	f949ec60 	ldr	x0, [x3, #5080]
    bc08:	cb0102a1 	sub	x1, x21, x1
    bc0c:	eb00403f 	cmp	x1, x0, lsl #16
    bc10:	54000322 	b.cs	bc74 <f0+0x1760>  // b.hs, b.nlast
    bc14:	d350fc22 	lsr	x2, x1, #16
    bc18:	f949fc63 	ldr	x3, [x3, #5112]
    bc1c:	8b020842 	add	x2, x2, x2, lsl #2
    bc20:	d37df042 	lsl	x2, x2, #3
    bc24:	8b020060 	add	x0, x3, x2
    bc28:	f9401017 	ldr	x23, [x0, #32]
    bc2c:	b4000257 	cbz	x23, bc74 <f0+0x1760>
    bc30:	38626862 	ldrb	w2, [x3, x2]
    bc34:	7100085f 	cmp	w2, #0x2
    bc38:	54005fc0 	b.eq	c830 <f0+0x231c>  // b.none
    bc3c:	7100045f 	cmp	w2, #0x1
    bc40:	540001a1 	b.ne	bc74 <f0+0x1760>  // b.any
    bc44:	29430002 	ldp	w2, w0, [x0, #24]
    bc48:	92403c21 	and	x1, x1, #0xffff
    bc4c:	9b027c21 	mul	x1, x1, x2
    bc50:	d360fc21 	lsr	x1, x1, #32
    bc54:	eb00003f 	cmp	x1, x0
    bc58:	540000e2 	b.cs	bc74 <f0+0x1760>  // b.hs, b.nlast
    bc5c:	8b0102f7 	add	x23, x23, x1
    bc60:	394002e0 	ldrb	w0, [x23]
    bc64:	7103fc1f 	cmp	w0, #0xff
    bc68:	540073a0 	b.eq	cadc <f0+0x25c8>  // b.none
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	390002e0 	strb	w0, [x23]
    bc74:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc78:	911863e1 	add	x1, sp, #0x618
    bc7c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc80:	52800020 	mov	w0, #0x1                   	// #1
    bc84:	f9030fe2 	str	x2, [sp, #1560]
    bc88:	f90313f5 	str	x21, [sp, #1568]
    bc8c:	97ffe585 	bl	52a0 <fwp_data.part.0.constprop.0>
    bc90:	97ffe831 	bl	5d54 <fwp_rc_fresh>
    bc94:	aa0003e2 	mov	x2, x0
    bc98:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bc9c:	9118a3e1 	add	x1, sp, #0x628
    bca0:	52800020 	mov	w0, #0x1                   	// #1
    bca4:	f90317e3 	str	x3, [sp, #1576]
    bca8:	f9031be2 	str	x2, [sp, #1584]
    bcac:	97ffe57d 	bl	52a0 <fwp_data.part.0.constprop.0>
    bcb0:	9118c283 	add	x3, x20, #0x630
    bcb4:	aa0003f5 	mov	x21, x0
    bcb8:	f949d861 	ldr	x1, [x3, #5040]
    bcbc:	f949ec60 	ldr	x0, [x3, #5080]
    bcc0:	cb0102a1 	sub	x1, x21, x1
    bcc4:	eb00403f 	cmp	x1, x0, lsl #16
    bcc8:	54000322 	b.cs	bd2c <f0+0x1818>  // b.hs, b.nlast
    bccc:	d350fc22 	lsr	x2, x1, #16
    bcd0:	f949fc63 	ldr	x3, [x3, #5112]
    bcd4:	8b020842 	add	x2, x2, x2, lsl #2
    bcd8:	d37df042 	lsl	x2, x2, #3
    bcdc:	8b020060 	add	x0, x3, x2
    bce0:	f9401017 	ldr	x23, [x0, #32]
    bce4:	b4000257 	cbz	x23, bd2c <f0+0x1818>
    bce8:	38626862 	ldrb	w2, [x3, x2]
    bcec:	7100085f 	cmp	w2, #0x2
    bcf0:	54005b20 	b.eq	c854 <f0+0x2340>  // b.none
    bcf4:	7100045f 	cmp	w2, #0x1
    bcf8:	540001a1 	b.ne	bd2c <f0+0x1818>  // b.any
    bcfc:	29430002 	ldp	w2, w0, [x0, #24]
    bd00:	92403c21 	and	x1, x1, #0xffff
    bd04:	9b027c21 	mul	x1, x1, x2
    bd08:	d360fc21 	lsr	x1, x1, #32
    bd0c:	eb00003f 	cmp	x1, x0
    bd10:	540000e2 	b.cs	bd2c <f0+0x1818>  // b.hs, b.nlast
    bd14:	8b0102f7 	add	x23, x23, x1
    bd18:	394002e0 	ldrb	w0, [x23]
    bd1c:	7103fc1f 	cmp	w0, #0xff
    bd20:	54006e40 	b.eq	cae8 <f0+0x25d4>  // b.none
    bd24:	52800020 	mov	w0, #0x1                   	// #1
    bd28:	390002e0 	strb	w0, [x23]
    bd2c:	9118e3e1 	add	x1, sp, #0x638
    bd30:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd34:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd38:	52800020 	mov	w0, #0x1                   	// #1
    bd3c:	f9031ff7 	str	x23, [sp, #1592]
    bd40:	f90323f5 	str	x21, [sp, #1600]
    bd44:	97ffe557 	bl	52a0 <fwp_data.part.0.constprop.0>
    bd48:	97ffe803 	bl	5d54 <fwp_rc_fresh>
    bd4c:	aa0003e2 	mov	x2, x0
    bd50:	911923e1 	add	x1, sp, #0x648
    bd54:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd58:	52800020 	mov	w0, #0x1                   	// #1
    bd5c:	f90327f5 	str	x21, [sp, #1608]
    bd60:	f9032be2 	str	x2, [sp, #1616]
    bd64:	97ffe54f 	bl	52a0 <fwp_data.part.0.constprop.0>
    bd68:	97ffe7fb 	bl	5d54 <fwp_rc_fresh>
    bd6c:	aa0003e2 	mov	x2, x0
    bd70:	911963e1 	add	x1, sp, #0x658
    bd74:	52800020 	mov	w0, #0x1                   	// #1
    bd78:	f9032ff7 	str	x23, [sp, #1624]
    bd7c:	f90333e2 	str	x2, [sp, #1632]
    bd80:	97ffe548 	bl	52a0 <fwp_data.part.0.constprop.0>
    bd84:	97ffe7f4 	bl	5d54 <fwp_rc_fresh>
    bd88:	aa0003e2 	mov	x2, x0
    bd8c:	9119a3e1 	add	x1, sp, #0x668
    bd90:	52800020 	mov	w0, #0x1                   	// #1
    bd94:	f90337f5 	str	x21, [sp, #1640]
    bd98:	f9033be2 	str	x2, [sp, #1648]
    bd9c:	97ffe541 	bl	52a0 <fwp_data.part.0.constprop.0>
    bda0:	97ffe7ed 	bl	5d54 <fwp_rc_fresh>
    bda4:	aa0003e2 	mov	x2, x0
    bda8:	9119e3e1 	add	x1, sp, #0x678
    bdac:	52800020 	mov	w0, #0x1                   	// #1
    bdb0:	f9033ff7 	str	x23, [sp, #1656]
    bdb4:	f90343e2 	str	x2, [sp, #1664]
    bdb8:	97ffe53a 	bl	52a0 <fwp_data.part.0.constprop.0>
    bdbc:	9118c283 	add	x3, x20, #0x630
    bdc0:	aa0003f5 	mov	x21, x0
    bdc4:	f949d861 	ldr	x1, [x3, #5040]
    bdc8:	f949ec60 	ldr	x0, [x3, #5080]
    bdcc:	cb0102a1 	sub	x1, x21, x1
    bdd0:	eb00403f 	cmp	x1, x0, lsl #16
    bdd4:	54000322 	b.cs	be38 <f0+0x1924>  // b.hs, b.nlast
    bdd8:	d350fc22 	lsr	x2, x1, #16
    bddc:	f949fc63 	ldr	x3, [x3, #5112]
    bde0:	8b020842 	add	x2, x2, x2, lsl #2
    bde4:	d37df042 	lsl	x2, x2, #3
    bde8:	8b020060 	add	x0, x3, x2
    bdec:	f9401017 	ldr	x23, [x0, #32]
    bdf0:	b4000257 	cbz	x23, be38 <f0+0x1924>
    bdf4:	38626862 	ldrb	w2, [x3, x2]
    bdf8:	7100085f 	cmp	w2, #0x2
    bdfc:	54005260 	b.eq	c848 <f0+0x2334>  // b.none
    be00:	7100045f 	cmp	w2, #0x1
    be04:	540001a1 	b.ne	be38 <f0+0x1924>  // b.any
    be08:	29430002 	ldp	w2, w0, [x0, #24]
    be0c:	92403c21 	and	x1, x1, #0xffff
    be10:	9b027c21 	mul	x1, x1, x2
    be14:	d360fc21 	lsr	x1, x1, #32
    be18:	eb00003f 	cmp	x1, x0
    be1c:	540000e2 	b.cs	be38 <f0+0x1924>  // b.hs, b.nlast
    be20:	8b0102f7 	add	x23, x23, x1
    be24:	394002e0 	ldrb	w0, [x23]
    be28:	7103fc1f 	cmp	w0, #0xff
    be2c:	54006640 	b.eq	caf4 <f0+0x25e0>  // b.none
    be30:	52800020 	mov	w0, #0x1                   	// #1
    be34:	390002e0 	strb	w0, [x23]
    be38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    be3c:	911a23e1 	add	x1, sp, #0x688
    be40:	52800020 	mov	w0, #0x1                   	// #1
    be44:	f90347e2 	str	x2, [sp, #1672]
    be48:	f9034bf5 	str	x21, [sp, #1680]
    be4c:	97ffe515 	bl	52a0 <fwp_data.part.0.constprop.0>
    be50:	9118c283 	add	x3, x20, #0x630
    be54:	aa0003f5 	mov	x21, x0
    be58:	f949d861 	ldr	x1, [x3, #5040]
    be5c:	f949ec60 	ldr	x0, [x3, #5080]
    be60:	cb0102a1 	sub	x1, x21, x1
    be64:	eb00403f 	cmp	x1, x0, lsl #16
    be68:	54000322 	b.cs	becc <f0+0x19b8>  // b.hs, b.nlast
    be6c:	d350fc22 	lsr	x2, x1, #16
    be70:	f949fc63 	ldr	x3, [x3, #5112]
    be74:	8b020842 	add	x2, x2, x2, lsl #2
    be78:	d37df042 	lsl	x2, x2, #3
    be7c:	8b020060 	add	x0, x3, x2
    be80:	f9401017 	ldr	x23, [x0, #32]
    be84:	b4000257 	cbz	x23, becc <f0+0x19b8>
    be88:	38626862 	ldrb	w2, [x3, x2]
    be8c:	7100085f 	cmp	w2, #0x2
    be90:	54004ee0 	b.eq	c86c <f0+0x2358>  // b.none
    be94:	7100045f 	cmp	w2, #0x1
    be98:	540001a1 	b.ne	becc <f0+0x19b8>  // b.any
    be9c:	29430002 	ldp	w2, w0, [x0, #24]
    bea0:	92403c21 	and	x1, x1, #0xffff
    bea4:	9b027c21 	mul	x1, x1, x2
    bea8:	d360fc21 	lsr	x1, x1, #32
    beac:	eb00003f 	cmp	x1, x0
    beb0:	540000e2 	b.cs	becc <f0+0x19b8>  // b.hs, b.nlast
    beb4:	8b0102f7 	add	x23, x23, x1
    beb8:	394002e0 	ldrb	w0, [x23]
    bebc:	7103fc1f 	cmp	w0, #0xff
    bec0:	54006200 	b.eq	cb00 <f0+0x25ec>  // b.none
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	390002e0 	strb	w0, [x23]
    becc:	911a63e1 	add	x1, sp, #0x698
    bed0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bed4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bed8:	52800020 	mov	w0, #0x1                   	// #1
    bedc:	f9034ff7 	str	x23, [sp, #1688]
    bee0:	f90353f5 	str	x21, [sp, #1696]
    bee4:	97ffe4ef 	bl	52a0 <fwp_data.part.0.constprop.0>
    bee8:	97ffe79b 	bl	5d54 <fwp_rc_fresh>
    beec:	aa0003e2 	mov	x2, x0
    bef0:	911aa3e1 	add	x1, sp, #0x6a8
    bef4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bef8:	52800020 	mov	w0, #0x1                   	// #1
    befc:	f90357f5 	str	x21, [sp, #1704]
    bf00:	f9035be2 	str	x2, [sp, #1712]
    bf04:	97ffe4e7 	bl	52a0 <fwp_data.part.0.constprop.0>
    bf08:	97ffe793 	bl	5d54 <fwp_rc_fresh>
    bf0c:	aa0003e2 	mov	x2, x0
    bf10:	911ae3e1 	add	x1, sp, #0x6b8
    bf14:	52800020 	mov	w0, #0x1                   	// #1
    bf18:	f9035ff7 	str	x23, [sp, #1720]
    bf1c:	f90363e2 	str	x2, [sp, #1728]
    bf20:	97ffe4e0 	bl	52a0 <fwp_data.part.0.constprop.0>
    bf24:	97ffe78c 	bl	5d54 <fwp_rc_fresh>
    bf28:	aa0003e2 	mov	x2, x0
    bf2c:	911b23e1 	add	x1, sp, #0x6c8
    bf30:	52800020 	mov	w0, #0x1                   	// #1
    bf34:	f90367f5 	str	x21, [sp, #1736]
    bf38:	f9036be2 	str	x2, [sp, #1744]
    bf3c:	97ffe4d9 	bl	52a0 <fwp_data.part.0.constprop.0>
    bf40:	9118c283 	add	x3, x20, #0x630
    bf44:	aa0003f5 	mov	x21, x0
    bf48:	f949d861 	ldr	x1, [x3, #5040]
    bf4c:	f949ec60 	ldr	x0, [x3, #5080]
    bf50:	cb0102a1 	sub	x1, x21, x1
    bf54:	eb00403f 	cmp	x1, x0, lsl #16
    bf58:	54000322 	b.cs	bfbc <f0+0x1aa8>  // b.hs, b.nlast
    bf5c:	d350fc22 	lsr	x2, x1, #16
    bf60:	f949fc63 	ldr	x3, [x3, #5112]
    bf64:	8b020842 	add	x2, x2, x2, lsl #2
    bf68:	d37df042 	lsl	x2, x2, #3
    bf6c:	8b020060 	add	x0, x3, x2
    bf70:	f9401017 	ldr	x23, [x0, #32]
    bf74:	b4000257 	cbz	x23, bfbc <f0+0x1aa8>
    bf78:	38626862 	ldrb	w2, [x3, x2]
    bf7c:	7100085f 	cmp	w2, #0x2
    bf80:	54004700 	b.eq	c860 <f0+0x234c>  // b.none
    bf84:	7100045f 	cmp	w2, #0x1
    bf88:	540001a1 	b.ne	bfbc <f0+0x1aa8>  // b.any
    bf8c:	29430002 	ldp	w2, w0, [x0, #24]
    bf90:	92403c21 	and	x1, x1, #0xffff
    bf94:	9b027c21 	mul	x1, x1, x2
    bf98:	d360fc21 	lsr	x1, x1, #32
    bf9c:	eb00003f 	cmp	x1, x0
    bfa0:	540000e2 	b.cs	bfbc <f0+0x1aa8>  // b.hs, b.nlast
    bfa4:	8b0102f7 	add	x23, x23, x1
    bfa8:	394002e0 	ldrb	w0, [x23]
    bfac:	7103fc1f 	cmp	w0, #0xff
    bfb0:	54005ae0 	b.eq	cb0c <f0+0x25f8>  // b.none
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	390002e0 	strb	w0, [x23]
    bfbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfc0:	911b63e1 	add	x1, sp, #0x6d8
    bfc4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfc8:	52800020 	mov	w0, #0x1                   	// #1
    bfcc:	f9036fe2 	str	x2, [sp, #1752]
    bfd0:	f90373f5 	str	x21, [sp, #1760]
    bfd4:	97ffe4b3 	bl	52a0 <fwp_data.part.0.constprop.0>
    bfd8:	9118c283 	add	x3, x20, #0x630
    bfdc:	aa0003f5 	mov	x21, x0
    bfe0:	f949d861 	ldr	x1, [x3, #5040]
    bfe4:	f949ec60 	ldr	x0, [x3, #5080]
    bfe8:	cb0102a1 	sub	x1, x21, x1
    bfec:	eb00403f 	cmp	x1, x0, lsl #16
    bff0:	54000322 	b.cs	c054 <f0+0x1b40>  // b.hs, b.nlast
    bff4:	d350fc22 	lsr	x2, x1, #16
    bff8:	f949fc63 	ldr	x3, [x3, #5112]
    bffc:	8b020842 	add	x2, x2, x2, lsl #2
    c000:	d37df042 	lsl	x2, x2, #3
    c004:	8b020060 	add	x0, x3, x2
    c008:	f9401017 	ldr	x23, [x0, #32]
    c00c:	b4000257 	cbz	x23, c054 <f0+0x1b40>
    c010:	38626862 	ldrb	w2, [x3, x2]
    c014:	7100085f 	cmp	w2, #0x2
    c018:	54004360 	b.eq	c884 <f0+0x2370>  // b.none
    c01c:	7100045f 	cmp	w2, #0x1
    c020:	540001a1 	b.ne	c054 <f0+0x1b40>  // b.any
    c024:	29430002 	ldp	w2, w0, [x0, #24]
    c028:	92403c21 	and	x1, x1, #0xffff
    c02c:	9b027c21 	mul	x1, x1, x2
    c030:	d360fc21 	lsr	x1, x1, #32
    c034:	eb00003f 	cmp	x1, x0
    c038:	540000e2 	b.cs	c054 <f0+0x1b40>  // b.hs, b.nlast
    c03c:	8b0102f7 	add	x23, x23, x1
    c040:	394002e0 	ldrb	w0, [x23]
    c044:	7103fc1f 	cmp	w0, #0xff
    c048:	54005680 	b.eq	cb18 <f0+0x2604>  // b.none
    c04c:	52800020 	mov	w0, #0x1                   	// #1
    c050:	390002e0 	strb	w0, [x23]
    c054:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c058:	911ba3e1 	add	x1, sp, #0x6e8
    c05c:	52800020 	mov	w0, #0x1                   	// #1
    c060:	f90377e2 	str	x2, [sp, #1768]
    c064:	f9037bf5 	str	x21, [sp, #1776]
    c068:	97ffe48e 	bl	52a0 <fwp_data.part.0.constprop.0>
    c06c:	9118c283 	add	x3, x20, #0x630
    c070:	aa0003f5 	mov	x21, x0
    c074:	f949d861 	ldr	x1, [x3, #5040]
    c078:	f949ec60 	ldr	x0, [x3, #5080]
    c07c:	cb0102a1 	sub	x1, x21, x1
    c080:	eb00403f 	cmp	x1, x0, lsl #16
    c084:	54000322 	b.cs	c0e8 <f0+0x1bd4>  // b.hs, b.nlast
    c088:	d350fc22 	lsr	x2, x1, #16
    c08c:	f949fc63 	ldr	x3, [x3, #5112]
    c090:	8b020842 	add	x2, x2, x2, lsl #2
    c094:	d37df042 	lsl	x2, x2, #3
    c098:	8b020060 	add	x0, x3, x2
    c09c:	f9401017 	ldr	x23, [x0, #32]
    c0a0:	b4000257 	cbz	x23, c0e8 <f0+0x1bd4>
    c0a4:	38626862 	ldrb	w2, [x3, x2]
    c0a8:	7100085f 	cmp	w2, #0x2
    c0ac:	54003e60 	b.eq	c878 <f0+0x2364>  // b.none
    c0b0:	7100045f 	cmp	w2, #0x1
    c0b4:	540001a1 	b.ne	c0e8 <f0+0x1bd4>  // b.any
    c0b8:	29430002 	ldp	w2, w0, [x0, #24]
    c0bc:	92403c21 	and	x1, x1, #0xffff
    c0c0:	9b027c21 	mul	x1, x1, x2
    c0c4:	d360fc21 	lsr	x1, x1, #32
    c0c8:	eb00003f 	cmp	x1, x0
    c0cc:	540000e2 	b.cs	c0e8 <f0+0x1bd4>  // b.hs, b.nlast
    c0d0:	8b0102f7 	add	x23, x23, x1
    c0d4:	394002e0 	ldrb	w0, [x23]
    c0d8:	7103fc1f 	cmp	w0, #0xff
    c0dc:	54005240 	b.eq	cb24 <f0+0x2610>  // b.none
    c0e0:	52800020 	mov	w0, #0x1                   	// #1
    c0e4:	390002e0 	strb	w0, [x23]
    c0e8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c0ec:	911be3e1 	add	x1, sp, #0x6f8
    c0f0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c0f4:	52800020 	mov	w0, #0x1                   	// #1
    c0f8:	f9037fe2 	str	x2, [sp, #1784]
    c0fc:	f90383f5 	str	x21, [sp, #1792]
    c100:	97ffe468 	bl	52a0 <fwp_data.part.0.constprop.0>
    c104:	9118c283 	add	x3, x20, #0x630
    c108:	aa0003f5 	mov	x21, x0
    c10c:	f949d861 	ldr	x1, [x3, #5040]
    c110:	f949ec60 	ldr	x0, [x3, #5080]
    c114:	cb0102a1 	sub	x1, x21, x1
    c118:	eb00403f 	cmp	x1, x0, lsl #16
    c11c:	54000322 	b.cs	c180 <f0+0x1c6c>  // b.hs, b.nlast
    c120:	d350fc22 	lsr	x2, x1, #16
    c124:	f949fc63 	ldr	x3, [x3, #5112]
    c128:	8b020842 	add	x2, x2, x2, lsl #2
    c12c:	d37df042 	lsl	x2, x2, #3
    c130:	8b020060 	add	x0, x3, x2
    c134:	f9401017 	ldr	x23, [x0, #32]
    c138:	b4000257 	cbz	x23, c180 <f0+0x1c6c>
    c13c:	38626862 	ldrb	w2, [x3, x2]
    c140:	7100085f 	cmp	w2, #0x2
    c144:	54003ac0 	b.eq	c89c <f0+0x2388>  // b.none
    c148:	7100045f 	cmp	w2, #0x1
    c14c:	540001a1 	b.ne	c180 <f0+0x1c6c>  // b.any
    c150:	29430002 	ldp	w2, w0, [x0, #24]
    c154:	92403c21 	and	x1, x1, #0xffff
    c158:	9b027c21 	mul	x1, x1, x2
    c15c:	d360fc21 	lsr	x1, x1, #32
    c160:	eb00003f 	cmp	x1, x0
    c164:	540000e2 	b.cs	c180 <f0+0x1c6c>  // b.hs, b.nlast
    c168:	8b0102f7 	add	x23, x23, x1
    c16c:	394002e0 	ldrb	w0, [x23]
    c170:	7103fc1f 	cmp	w0, #0xff
    c174:	54004de0 	b.eq	cb30 <f0+0x261c>  // b.none
    c178:	52800020 	mov	w0, #0x1                   	// #1
    c17c:	390002e0 	strb	w0, [x23]
    c180:	911c23e1 	add	x1, sp, #0x708
    c184:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	f90387f7 	str	x23, [sp, #1800]
    c190:	f9038bf5 	str	x21, [sp, #1808]
    c194:	97ffe443 	bl	52a0 <fwp_data.part.0.constprop.0>
    c198:	97ffe6ef 	bl	5d54 <fwp_rc_fresh>
    c19c:	aa0003e2 	mov	x2, x0
    c1a0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c1a4:	911c63e1 	add	x1, sp, #0x718
    c1a8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c1ac:	52800020 	mov	w0, #0x1                   	// #1
    c1b0:	f9038fe3 	str	x3, [sp, #1816]
    c1b4:	f90393e2 	str	x2, [sp, #1824]
    c1b8:	97ffe43a 	bl	52a0 <fwp_data.part.0.constprop.0>
    c1bc:	97ffe6e6 	bl	5d54 <fwp_rc_fresh>
    c1c0:	aa0003e2 	mov	x2, x0
    c1c4:	911ca3e1 	add	x1, sp, #0x728
    c1c8:	52800020 	mov	w0, #0x1                   	// #1
    c1cc:	f90397f7 	str	x23, [sp, #1832]
    c1d0:	f9039be2 	str	x2, [sp, #1840]
    c1d4:	97ffe433 	bl	52a0 <fwp_data.part.0.constprop.0>
    c1d8:	9118c283 	add	x3, x20, #0x630
    c1dc:	aa0003f5 	mov	x21, x0
    c1e0:	f949d861 	ldr	x1, [x3, #5040]
    c1e4:	f949ec60 	ldr	x0, [x3, #5080]
    c1e8:	cb0102a1 	sub	x1, x21, x1
    c1ec:	eb00403f 	cmp	x1, x0, lsl #16
    c1f0:	54000322 	b.cs	c254 <f0+0x1d40>  // b.hs, b.nlast
    c1f4:	d350fc22 	lsr	x2, x1, #16
    c1f8:	f949fc63 	ldr	x3, [x3, #5112]
    c1fc:	8b020842 	add	x2, x2, x2, lsl #2
    c200:	d37df042 	lsl	x2, x2, #3
    c204:	8b020060 	add	x0, x3, x2
    c208:	f9401017 	ldr	x23, [x0, #32]
    c20c:	b4000257 	cbz	x23, c254 <f0+0x1d40>
    c210:	38626862 	ldrb	w2, [x3, x2]
    c214:	7100085f 	cmp	w2, #0x2
    c218:	540033c0 	b.eq	c890 <f0+0x237c>  // b.none
    c21c:	7100045f 	cmp	w2, #0x1
    c220:	540001a1 	b.ne	c254 <f0+0x1d40>  // b.any
    c224:	29430002 	ldp	w2, w0, [x0, #24]
    c228:	92403c21 	and	x1, x1, #0xffff
    c22c:	9b027c21 	mul	x1, x1, x2
    c230:	d360fc21 	lsr	x1, x1, #32
    c234:	eb00003f 	cmp	x1, x0
    c238:	540000e2 	b.cs	c254 <f0+0x1d40>  // b.hs, b.nlast
    c23c:	8b0102f7 	add	x23, x23, x1
    c240:	394002e0 	ldrb	w0, [x23]
    c244:	7103fc1f 	cmp	w0, #0xff
    c248:	540047a0 	b.eq	cb3c <f0+0x2628>  // b.none
    c24c:	52800020 	mov	w0, #0x1                   	// #1
    c250:	390002e0 	strb	w0, [x23]
    c254:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c258:	911ce3e1 	add	x1, sp, #0x738
    c25c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c260:	52800020 	mov	w0, #0x1                   	// #1
    c264:	f9039fe2 	str	x2, [sp, #1848]
    c268:	f903a3f5 	str	x21, [sp, #1856]
    c26c:	97ffe40d 	bl	52a0 <fwp_data.part.0.constprop.0>
    c270:	97ffe6b9 	bl	5d54 <fwp_rc_fresh>
    c274:	aa0003e2 	mov	x2, x0
    c278:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c27c:	911d23e1 	add	x1, sp, #0x748
    c280:	52800020 	mov	w0, #0x1                   	// #1
    c284:	f903a7e3 	str	x3, [sp, #1864]
    c288:	f903abe2 	str	x2, [sp, #1872]
    c28c:	97ffe405 	bl	52a0 <fwp_data.part.0.constprop.0>
    c290:	9118c283 	add	x3, x20, #0x630
    c294:	aa0003f5 	mov	x21, x0
    c298:	f949d861 	ldr	x1, [x3, #5040]
    c29c:	f949ec60 	ldr	x0, [x3, #5080]
    c2a0:	cb0102a1 	sub	x1, x21, x1
    c2a4:	eb00403f 	cmp	x1, x0, lsl #16
    c2a8:	54000322 	b.cs	c30c <f0+0x1df8>  // b.hs, b.nlast
    c2ac:	d350fc22 	lsr	x2, x1, #16
    c2b0:	f949fc63 	ldr	x3, [x3, #5112]
    c2b4:	8b020842 	add	x2, x2, x2, lsl #2
    c2b8:	d37df042 	lsl	x2, x2, #3
    c2bc:	8b020060 	add	x0, x3, x2
    c2c0:	f9401017 	ldr	x23, [x0, #32]
    c2c4:	b4000257 	cbz	x23, c30c <f0+0x1df8>
    c2c8:	38626862 	ldrb	w2, [x3, x2]
    c2cc:	7100085f 	cmp	w2, #0x2
    c2d0:	54002f20 	b.eq	c8b4 <f0+0x23a0>  // b.none
    c2d4:	7100045f 	cmp	w2, #0x1
    c2d8:	540001a1 	b.ne	c30c <f0+0x1df8>  // b.any
    c2dc:	29430002 	ldp	w2, w0, [x0, #24]
    c2e0:	92403c21 	and	x1, x1, #0xffff
    c2e4:	9b027c21 	mul	x1, x1, x2
    c2e8:	d360fc21 	lsr	x1, x1, #32
    c2ec:	eb00003f 	cmp	x1, x0
    c2f0:	540000e2 	b.cs	c30c <f0+0x1df8>  // b.hs, b.nlast
    c2f4:	8b0102f7 	add	x23, x23, x1
    c2f8:	394002e0 	ldrb	w0, [x23]
    c2fc:	7103fc1f 	cmp	w0, #0xff
    c300:	54004240 	b.eq	cb48 <f0+0x2634>  // b.none
    c304:	52800020 	mov	w0, #0x1                   	// #1
    c308:	390002e0 	strb	w0, [x23]
    c30c:	911d63e1 	add	x1, sp, #0x758
    c310:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c314:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c318:	52800020 	mov	w0, #0x1                   	// #1
    c31c:	f903aff7 	str	x23, [sp, #1880]
    c320:	f903b3f5 	str	x21, [sp, #1888]
    c324:	97ffe3df 	bl	52a0 <fwp_data.part.0.constprop.0>
    c328:	97ffe68b 	bl	5d54 <fwp_rc_fresh>
    c32c:	aa0003e2 	mov	x2, x0
    c330:	911da3e1 	add	x1, sp, #0x768
    c334:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c338:	52800020 	mov	w0, #0x1                   	// #1
    c33c:	f903b7f5 	str	x21, [sp, #1896]
    c340:	f903bbe2 	str	x2, [sp, #1904]
    c344:	97ffe3d7 	bl	52a0 <fwp_data.part.0.constprop.0>
    c348:	97ffe683 	bl	5d54 <fwp_rc_fresh>
    c34c:	aa0003e2 	mov	x2, x0
    c350:	911de3e1 	add	x1, sp, #0x778
    c354:	52800020 	mov	w0, #0x1                   	// #1
    c358:	f903bff7 	str	x23, [sp, #1912]
    c35c:	f903c3e2 	str	x2, [sp, #1920]
    c360:	97ffe3d0 	bl	52a0 <fwp_data.part.0.constprop.0>
    c364:	97ffe67c 	bl	5d54 <fwp_rc_fresh>
    c368:	aa0003e2 	mov	x2, x0
    c36c:	911e23e1 	add	x1, sp, #0x788
    c370:	52800020 	mov	w0, #0x1                   	// #1
    c374:	f903c7f5 	str	x21, [sp, #1928]
    c378:	f903cbe2 	str	x2, [sp, #1936]
    c37c:	97ffe3c9 	bl	52a0 <fwp_data.part.0.constprop.0>
    c380:	9118c283 	add	x3, x20, #0x630
    c384:	aa0003f5 	mov	x21, x0
    c388:	f949d861 	ldr	x1, [x3, #5040]
    c38c:	f949ec60 	ldr	x0, [x3, #5080]
    c390:	cb0102a1 	sub	x1, x21, x1
    c394:	eb00403f 	cmp	x1, x0, lsl #16
    c398:	54000322 	b.cs	c3fc <f0+0x1ee8>  // b.hs, b.nlast
    c39c:	d350fc22 	lsr	x2, x1, #16
    c3a0:	f949fc63 	ldr	x3, [x3, #5112]
    c3a4:	8b020842 	add	x2, x2, x2, lsl #2
    c3a8:	d37df042 	lsl	x2, x2, #3
    c3ac:	8b020060 	add	x0, x3, x2
    c3b0:	f9401017 	ldr	x23, [x0, #32]
    c3b4:	b4000257 	cbz	x23, c3fc <f0+0x1ee8>
    c3b8:	38626862 	ldrb	w2, [x3, x2]
    c3bc:	7100085f 	cmp	w2, #0x2
    c3c0:	54002740 	b.eq	c8a8 <f0+0x2394>  // b.none
    c3c4:	7100045f 	cmp	w2, #0x1
    c3c8:	540001a1 	b.ne	c3fc <f0+0x1ee8>  // b.any
    c3cc:	29430002 	ldp	w2, w0, [x0, #24]
    c3d0:	92403c21 	and	x1, x1, #0xffff
    c3d4:	9b027c21 	mul	x1, x1, x2
    c3d8:	d360fc21 	lsr	x1, x1, #32
    c3dc:	eb00003f 	cmp	x1, x0
    c3e0:	540000e2 	b.cs	c3fc <f0+0x1ee8>  // b.hs, b.nlast
    c3e4:	8b0102f7 	add	x23, x23, x1
    c3e8:	394002e0 	ldrb	w0, [x23]
    c3ec:	7103fc1f 	cmp	w0, #0xff
    c3f0:	54003b20 	b.eq	cb54 <f0+0x2640>  // b.none
    c3f4:	52800020 	mov	w0, #0x1                   	// #1
    c3f8:	390002e0 	strb	w0, [x23]
    c3fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c400:	911e63e1 	add	x1, sp, #0x798
    c404:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c408:	52800020 	mov	w0, #0x1                   	// #1
    c40c:	f903cfe2 	str	x2, [sp, #1944]
    c410:	f903d3f5 	str	x21, [sp, #1952]
    c414:	97ffe3a3 	bl	52a0 <fwp_data.part.0.constprop.0>
    c418:	97ffe64f 	bl	5d54 <fwp_rc_fresh>
    c41c:	aa0003e2 	mov	x2, x0
    c420:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c424:	911ea3e1 	add	x1, sp, #0x7a8
    c428:	52800020 	mov	w0, #0x1                   	// #1
    c42c:	f903d7e3 	str	x3, [sp, #1960]
    c430:	f903dbe2 	str	x2, [sp, #1968]
    c434:	97ffe39b 	bl	52a0 <fwp_data.part.0.constprop.0>
    c438:	9118c283 	add	x3, x20, #0x630
    c43c:	aa0003f5 	mov	x21, x0
    c440:	f949d861 	ldr	x1, [x3, #5040]
    c444:	f949ec60 	ldr	x0, [x3, #5080]
    c448:	cb0102a1 	sub	x1, x21, x1
    c44c:	eb00403f 	cmp	x1, x0, lsl #16
    c450:	54000322 	b.cs	c4b4 <f0+0x1fa0>  // b.hs, b.nlast
    c454:	d350fc22 	lsr	x2, x1, #16
    c458:	f949fc63 	ldr	x3, [x3, #5112]
    c45c:	8b020842 	add	x2, x2, x2, lsl #2
    c460:	d37df042 	lsl	x2, x2, #3
    c464:	8b020060 	add	x0, x3, x2
    c468:	f9401017 	ldr	x23, [x0, #32]
    c46c:	b4000257 	cbz	x23, c4b4 <f0+0x1fa0>
    c470:	38626862 	ldrb	w2, [x3, x2]
    c474:	7100085f 	cmp	w2, #0x2
    c478:	540022a0 	b.eq	c8cc <f0+0x23b8>  // b.none
    c47c:	7100045f 	cmp	w2, #0x1
    c480:	540001a1 	b.ne	c4b4 <f0+0x1fa0>  // b.any
    c484:	29430002 	ldp	w2, w0, [x0, #24]
    c488:	92403c21 	and	x1, x1, #0xffff
    c48c:	9b027c21 	mul	x1, x1, x2
    c490:	d360fc21 	lsr	x1, x1, #32
    c494:	eb00003f 	cmp	x1, x0
    c498:	540000e2 	b.cs	c4b4 <f0+0x1fa0>  // b.hs, b.nlast
    c49c:	8b0102f7 	add	x23, x23, x1
    c4a0:	394002e0 	ldrb	w0, [x23]
    c4a4:	7103fc1f 	cmp	w0, #0xff
    c4a8:	540035c0 	b.eq	cb60 <f0+0x264c>  // b.none
    c4ac:	52800020 	mov	w0, #0x1                   	// #1
    c4b0:	390002e0 	strb	w0, [x23]
    c4b4:	911ee3e1 	add	x1, sp, #0x7b8
    c4b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c4bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c4c0:	52800020 	mov	w0, #0x1                   	// #1
    c4c4:	f903dff7 	str	x23, [sp, #1976]
    c4c8:	f903e3f5 	str	x21, [sp, #1984]
    c4cc:	97ffe375 	bl	52a0 <fwp_data.part.0.constprop.0>
    c4d0:	97ffe621 	bl	5d54 <fwp_rc_fresh>
    c4d4:	aa0003e2 	mov	x2, x0
    c4d8:	911f23e1 	add	x1, sp, #0x7c8
    c4dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c4e0:	52800020 	mov	w0, #0x1                   	// #1
    c4e4:	f903e7f5 	str	x21, [sp, #1992]
    c4e8:	f903ebe2 	str	x2, [sp, #2000]
    c4ec:	97ffe36d 	bl	52a0 <fwp_data.part.0.constprop.0>
    c4f0:	97ffe619 	bl	5d54 <fwp_rc_fresh>
    c4f4:	aa0003e2 	mov	x2, x0
    c4f8:	911f63e1 	add	x1, sp, #0x7d8
    c4fc:	52800020 	mov	w0, #0x1                   	// #1
    c500:	f903eff7 	str	x23, [sp, #2008]
    c504:	f903f3e2 	str	x2, [sp, #2016]
    c508:	97ffe366 	bl	52a0 <fwp_data.part.0.constprop.0>
    c50c:	97ffe612 	bl	5d54 <fwp_rc_fresh>
    c510:	aa0003e2 	mov	x2, x0
    c514:	911fa3e1 	add	x1, sp, #0x7e8
    c518:	52800020 	mov	w0, #0x1                   	// #1
    c51c:	f903f7f5 	str	x21, [sp, #2024]
    c520:	f903fbe2 	str	x2, [sp, #2032]
    c524:	97ffe35f 	bl	52a0 <fwp_data.part.0.constprop.0>
    c528:	9118c283 	add	x3, x20, #0x630
    c52c:	aa0003f5 	mov	x21, x0
    c530:	f949d861 	ldr	x1, [x3, #5040]
    c534:	f949ec60 	ldr	x0, [x3, #5080]
    c538:	cb0102a1 	sub	x1, x21, x1
    c53c:	eb00403f 	cmp	x1, x0, lsl #16
    c540:	54000322 	b.cs	c5a4 <f0+0x2090>  // b.hs, b.nlast
    c544:	d350fc22 	lsr	x2, x1, #16
    c548:	f949fc63 	ldr	x3, [x3, #5112]
    c54c:	8b020842 	add	x2, x2, x2, lsl #2
    c550:	d37df042 	lsl	x2, x2, #3
    c554:	8b020060 	add	x0, x3, x2
    c558:	f9401017 	ldr	x23, [x0, #32]
    c55c:	b4000257 	cbz	x23, c5a4 <f0+0x2090>
    c560:	38626862 	ldrb	w2, [x3, x2]
    c564:	7100085f 	cmp	w2, #0x2
    c568:	54001ac0 	b.eq	c8c0 <f0+0x23ac>  // b.none
    c56c:	7100045f 	cmp	w2, #0x1
    c570:	540001a1 	b.ne	c5a4 <f0+0x2090>  // b.any
    c574:	29430002 	ldp	w2, w0, [x0, #24]
    c578:	92403c21 	and	x1, x1, #0xffff
    c57c:	9b027c21 	mul	x1, x1, x2
    c580:	d360fc21 	lsr	x1, x1, #32
    c584:	eb00003f 	cmp	x1, x0
    c588:	540000e2 	b.cs	c5a4 <f0+0x2090>  // b.hs, b.nlast
    c58c:	8b0102f7 	add	x23, x23, x1
    c590:	394002e0 	ldrb	w0, [x23]
    c594:	7103fc1f 	cmp	w0, #0xff
    c598:	54002ea0 	b.eq	cb6c <f0+0x2658>  // b.none
    c59c:	52800020 	mov	w0, #0x1                   	// #1
    c5a0:	390002e0 	strb	w0, [x23]
    c5a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c5a8:	911fe3e1 	add	x1, sp, #0x7f8
    c5ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c5b0:	52800020 	mov	w0, #0x1                   	// #1
    c5b4:	f903ffe2 	str	x2, [sp, #2040]
    c5b8:	f90403f5 	str	x21, [sp, #2048]
    c5bc:	97ffe339 	bl	52a0 <fwp_data.part.0.constprop.0>
    c5c0:	9118c283 	add	x3, x20, #0x630
    c5c4:	aa0003f5 	mov	x21, x0
    c5c8:	f949d861 	ldr	x1, [x3, #5040]
    c5cc:	f949ec60 	ldr	x0, [x3, #5080]
    c5d0:	cb0102a1 	sub	x1, x21, x1
    c5d4:	eb00403f 	cmp	x1, x0, lsl #16
    c5d8:	54000322 	b.cs	c63c <f0+0x2128>  // b.hs, b.nlast
    c5dc:	d350fc22 	lsr	x2, x1, #16
    c5e0:	f949fc63 	ldr	x3, [x3, #5112]
    c5e4:	8b020842 	add	x2, x2, x2, lsl #2
    c5e8:	d37df042 	lsl	x2, x2, #3
    c5ec:	8b020060 	add	x0, x3, x2
    c5f0:	f9401017 	ldr	x23, [x0, #32]
    c5f4:	b4000257 	cbz	x23, c63c <f0+0x2128>
    c5f8:	38626862 	ldrb	w2, [x3, x2]
    c5fc:	7100085f 	cmp	w2, #0x2
    c600:	54001720 	b.eq	c8e4 <f0+0x23d0>  // b.none
    c604:	7100045f 	cmp	w2, #0x1
    c608:	540001a1 	b.ne	c63c <f0+0x2128>  // b.any
    c60c:	29430002 	ldp	w2, w0, [x0, #24]
    c610:	92403c21 	and	x1, x1, #0xffff
    c614:	9b027c21 	mul	x1, x1, x2
    c618:	d360fc21 	lsr	x1, x1, #32
    c61c:	eb00003f 	cmp	x1, x0
    c620:	540000e2 	b.cs	c63c <f0+0x2128>  // b.hs, b.nlast
    c624:	8b0102f7 	add	x23, x23, x1
    c628:	394002e0 	ldrb	w0, [x23]
    c62c:	7103fc1f 	cmp	w0, #0xff
    c630:	54002a40 	b.eq	cb78 <f0+0x2664>  // b.none
    c634:	52800020 	mov	w0, #0x1                   	// #1
    c638:	390002e0 	strb	w0, [x23]
    c63c:	9118c294 	add	x20, x20, #0x630
    c640:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c644:	912023e1 	add	x1, sp, #0x808
    c648:	52800020 	mov	w0, #0x1                   	// #1
    c64c:	f90407e2 	str	x2, [sp, #2056]
    c650:	f9040bf5 	str	x21, [sp, #2064]
    c654:	97ffe313 	bl	52a0 <fwp_data.part.0.constprop.0>
    c658:	f949da81 	ldr	x1, [x20, #5040]
    c65c:	aa0003f5 	mov	x21, x0
    c660:	f949ee80 	ldr	x0, [x20, #5080]
    c664:	cb0102a1 	sub	x1, x21, x1
    c668:	eb00403f 	cmp	x1, x0, lsl #16
    c66c:	54000322 	b.cs	c6d0 <f0+0x21bc>  // b.hs, b.nlast
    c670:	d350fc22 	lsr	x2, x1, #16
    c674:	f949fe83 	ldr	x3, [x20, #5112]
    c678:	8b020842 	add	x2, x2, x2, lsl #2
    c67c:	d37df042 	lsl	x2, x2, #3
    c680:	8b020060 	add	x0, x3, x2
    c684:	f9401014 	ldr	x20, [x0, #32]
    c688:	b4000254 	cbz	x20, c6d0 <f0+0x21bc>
    c68c:	38626862 	ldrb	w2, [x3, x2]
    c690:	7100085f 	cmp	w2, #0x2
    c694:	54001220 	b.eq	c8d8 <f0+0x23c4>  // b.none
    c698:	7100045f 	cmp	w2, #0x1
    c69c:	540001a1 	b.ne	c6d0 <f0+0x21bc>  // b.any
    c6a0:	29430002 	ldp	w2, w0, [x0, #24]
    c6a4:	92403c21 	and	x1, x1, #0xffff
    c6a8:	9b027c21 	mul	x1, x1, x2
    c6ac:	d360fc21 	lsr	x1, x1, #32
    c6b0:	eb00003f 	cmp	x1, x0
    c6b4:	540000e2 	b.cs	c6d0 <f0+0x21bc>  // b.hs, b.nlast
    c6b8:	8b010294 	add	x20, x20, x1
    c6bc:	39400280 	ldrb	w0, [x20]
    c6c0:	7103fc1f 	cmp	w0, #0xff
    c6c4:	54001760 	b.eq	c9b0 <f0+0x249c>  // b.none
    c6c8:	52800020 	mov	w0, #0x1                   	// #1
    c6cc:	39000280 	strb	w0, [x20]
    c6d0:	912063e1 	add	x1, sp, #0x818
    c6d4:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c6d8:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c6dc:	52800020 	mov	w0, #0x1                   	// #1
    c6e0:	f9040ff4 	str	x20, [sp, #2072]
    c6e4:	f90413f5 	str	x21, [sp, #2080]
    c6e8:	97ffe2ee 	bl	52a0 <fwp_data.part.0.constprop.0>
    c6ec:	97ffe59a 	bl	5d54 <fwp_rc_fresh>
    c6f0:	aa0003e2 	mov	x2, x0
    c6f4:	9120a3e1 	add	x1, sp, #0x828
    c6f8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c6fc:	52800020 	mov	w0, #0x1                   	// #1
    c700:	f90417f5 	str	x21, [sp, #2088]
    c704:	f9041be2 	str	x2, [sp, #2096]
    c708:	97ffe2e6 	bl	52a0 <fwp_data.part.0.constprop.0>
    c70c:	97ffe592 	bl	5d54 <fwp_rc_fresh>
    c710:	aa0003e2 	mov	x2, x0
    c714:	9120e3e1 	add	x1, sp, #0x838
    c718:	52800020 	mov	w0, #0x1                   	// #1
    c71c:	f9041ff4 	str	x20, [sp, #2104]
    c720:	f90423e2 	str	x2, [sp, #2112]
    c724:	97ffe2df 	bl	52a0 <fwp_data.part.0.constprop.0>
    c728:	97ffe58b 	bl	5d54 <fwp_rc_fresh>
    c72c:	aa0003e2 	mov	x2, x0
    c730:	912123e1 	add	x1, sp, #0x848
    c734:	52800020 	mov	w0, #0x1                   	// #1
    c738:	f90427f5 	str	x21, [sp, #2120]
    c73c:	f9042be2 	str	x2, [sp, #2128]
    c740:	97ffe2d8 	bl	52a0 <fwp_data.part.0.constprop.0>
    c744:	97ffe584 	bl	5d54 <fwp_rc_fresh>
    c748:	aa0003e2 	mov	x2, x0
    c74c:	aa1603e1 	mov	x1, x22
    c750:	52800020 	mov	w0, #0x1                   	// #1
    c754:	f9042ff4 	str	x20, [sp, #2136]
    c758:	f90433e2 	str	x2, [sp, #2144]
    c75c:	97ffe2d1 	bl	52a0 <fwp_data.part.0.constprop.0>
    c760:	97ffe57d 	bl	5d54 <fwp_rc_fresh>
    c764:	aa0003f5 	mov	x21, x0
    c768:	aa1303e1 	mov	x1, x19
    c76c:	97fff085 	bl	8980 <fwp_hof0.constprop.0>
    c770:	aa0003f4 	mov	x20, x0
    c774:	aa1503e0 	mov	x0, x21
    c778:	97ffe6e2 	bl	6300 <fwp_drop0>
    c77c:	aa1303e0 	mov	x0, x19
    c780:	97ffe6e0 	bl	6300 <fwp_drop0>
    c784:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    c788:	f947f400 	ldr	x0, [x0, #4072]
    c78c:	f94437e2 	ldr	x2, [sp, #2152]
    c790:	f9400001 	ldr	x1, [x0]
    c794:	eb010042 	subs	x2, x2, x1
    c798:	d2800001 	mov	x1, #0x0                   	// #0
    c79c:	54001f41 	b.ne	cb84 <f0+0x2670>  // b.any
    c7a0:	9121c3ff 	add	sp, sp, #0x870
    c7a4:	aa1403e0 	mov	x0, x20
    c7a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    c7ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c7b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    c7b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c7b8:	a94573fb 	ldp	x27, x28, [sp, #80]
    c7bc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c7c0:	d65f03c0 	ret
    c7c4:	aa1c03e0 	mov	x0, x28
    c7c8:	97ffdefb 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c7cc:	17fff79b 	b	a638 <f0+0x124>
    c7d0:	72003c5f 	tst	w2, #0xffff
    c7d4:	54fef341 	b.ne	a63c <f0+0x128>  // b.any
    c7d8:	17fff795 	b	a62c <f0+0x118>
    c7dc:	72003c3f 	tst	w1, #0xffff
    c7e0:	54feff21 	b.ne	a7c4 <f0+0x2b0>  // b.any
    c7e4:	17fff7f3 	b	a7b0 <f0+0x29c>
    c7e8:	72003c3f 	tst	w1, #0xffff
    c7ec:	54ff0981 	b.ne	a91c <f0+0x408>  // b.any
    c7f0:	17fff846 	b	a908 <f0+0x3f4>
    c7f4:	72003c3f 	tst	w1, #0xffff
    c7f8:	54ff04a1 	b.ne	a88c <f0+0x378>  // b.any
    c7fc:	17fff81f 	b	a878 <f0+0x364>
    c800:	72003c3f 	tst	w1, #0xffff
    c804:	54ff1e81 	b.ne	abd4 <f0+0x6c0>  // b.any
    c808:	17fff8ee 	b	abc0 <f0+0x6ac>
    c80c:	72003c3f 	tst	w1, #0xffff
    c810:	54ff0d01 	b.ne	a9b0 <f0+0x49c>  // b.any
    c814:	17fff862 	b	a99c <f0+0x488>
    c818:	72003c3f 	tst	w1, #0xffff
    c81c:	54ff2a01 	b.ne	ad5c <f0+0x848>  // b.any
    c820:	17fff94a 	b	ad48 <f0+0x834>
    c824:	72003c3f 	tst	w1, #0xffff
    c828:	54ff2221 	b.ne	ac6c <f0+0x758>  // b.any
    c82c:	17fff90b 	b	ac58 <f0+0x744>
    c830:	72003c3f 	tst	w1, #0xffff
    c834:	54ffa201 	b.ne	bc74 <f0+0x1760>  // b.any
    c838:	17fffd0a 	b	bc60 <f0+0x174c>
    c83c:	72003c3f 	tst	w1, #0xffff
    c840:	54ff9d01 	b.ne	bbe0 <f0+0x16cc>  // b.any
    c844:	17fffce2 	b	bbcc <f0+0x16b8>
    c848:	72003c3f 	tst	w1, #0xffff
    c84c:	54ffaf61 	b.ne	be38 <f0+0x1924>  // b.any
    c850:	17fffd75 	b	be24 <f0+0x1910>
    c854:	72003c3f 	tst	w1, #0xffff
    c858:	54ffa6a1 	b.ne	bd2c <f0+0x1818>  // b.any
    c85c:	17fffd2f 	b	bd18 <f0+0x1804>
    c860:	72003c3f 	tst	w1, #0xffff
    c864:	54ffbac1 	b.ne	bfbc <f0+0x1aa8>  // b.any
    c868:	17fffdd0 	b	bfa8 <f0+0x1a94>
    c86c:	72003c3f 	tst	w1, #0xffff
    c870:	54ffb2e1 	b.ne	becc <f0+0x19b8>  // b.any
    c874:	17fffd91 	b	beb8 <f0+0x19a4>
    c878:	72003c3f 	tst	w1, #0xffff
    c87c:	54ffc361 	b.ne	c0e8 <f0+0x1bd4>  // b.any
    c880:	17fffe15 	b	c0d4 <f0+0x1bc0>
    c884:	72003c3f 	tst	w1, #0xffff
    c888:	54ffbe61 	b.ne	c054 <f0+0x1b40>  // b.any
    c88c:	17fffded 	b	c040 <f0+0x1b2c>
    c890:	72003c3f 	tst	w1, #0xffff
    c894:	54ffce01 	b.ne	c254 <f0+0x1d40>  // b.any
    c898:	17fffe6a 	b	c240 <f0+0x1d2c>
    c89c:	72003c3f 	tst	w1, #0xffff
    c8a0:	54ffc701 	b.ne	c180 <f0+0x1c6c>  // b.any
    c8a4:	17fffe32 	b	c16c <f0+0x1c58>
    c8a8:	72003c3f 	tst	w1, #0xffff
    c8ac:	54ffda81 	b.ne	c3fc <f0+0x1ee8>  // b.any
    c8b0:	17fffece 	b	c3e8 <f0+0x1ed4>
    c8b4:	72003c3f 	tst	w1, #0xffff
    c8b8:	54ffd2a1 	b.ne	c30c <f0+0x1df8>  // b.any
    c8bc:	17fffe8f 	b	c2f8 <f0+0x1de4>
    c8c0:	72003c3f 	tst	w1, #0xffff
    c8c4:	54ffe701 	b.ne	c5a4 <f0+0x2090>  // b.any
    c8c8:	17ffff32 	b	c590 <f0+0x207c>
    c8cc:	72003c3f 	tst	w1, #0xffff
    c8d0:	54ffdf21 	b.ne	c4b4 <f0+0x1fa0>  // b.any
    c8d4:	17fffef3 	b	c4a0 <f0+0x1f8c>
    c8d8:	72003c3f 	tst	w1, #0xffff
    c8dc:	54ffefa1 	b.ne	c6d0 <f0+0x21bc>  // b.any
    c8e0:	17ffff77 	b	c6bc <f0+0x21a8>
    c8e4:	72003c3f 	tst	w1, #0xffff
    c8e8:	54ffeaa1 	b.ne	c63c <f0+0x2128>  // b.any
    c8ec:	17ffff4f 	b	c628 <f0+0x2114>
    c8f0:	72003c3f 	tst	w1, #0xffff
    c8f4:	54ff3da1 	b.ne	b0a8 <f0+0xb94>  // b.any
    c8f8:	17fff9e7 	b	b094 <f0+0xb80>
    c8fc:	72003c3f 	tst	w1, #0xffff
    c900:	54ff28a1 	b.ne	ae14 <f0+0x900>  // b.any
    c904:	17fff93f 	b	ae00 <f0+0x8ec>
    c908:	72003c3f 	tst	w1, #0xffff
    c90c:	54ff4761 	b.ne	b1f8 <f0+0xce4>  // b.any
    c910:	17fffa35 	b	b1e4 <f0+0xcd0>
    c914:	72003c3f 	tst	w1, #0xffff
    c918:	54ff4241 	b.ne	b160 <f0+0xc4c>  // b.any
    c91c:	17fffa0c 	b	b14c <f0+0xc38>
    c920:	72003c3f 	tst	w1, #0xffff
    c924:	54ff5101 	b.ne	b344 <f0+0xe30>  // b.any
    c928:	17fffa82 	b	b330 <f0+0xe1c>
    c92c:	72003c3f 	tst	w1, #0xffff
    c930:	54ff4ae1 	b.ne	b28c <f0+0xd78>  // b.any
    c934:	17fffa51 	b	b278 <f0+0xd64>
    c938:	72003c3f 	tst	w1, #0xffff
    c93c:	54ff5d41 	b.ne	b4e4 <f0+0xfd0>  // b.any
    c940:	17fffae4 	b	b4d0 <f0+0xfbc>
    c944:	72003c3f 	tst	w1, #0xffff
    c948:	54ff5841 	b.ne	b450 <f0+0xf3c>  // b.any
    c94c:	17fffabc 	b	b43c <f0+0xf28>
    c950:	72003c3f 	tst	w1, #0xffff
    c954:	54ff6801 	b.ne	b654 <f0+0x1140>  // b.any
    c958:	17fffb3a 	b	b640 <f0+0x112c>
    c95c:	72003c3f 	tst	w1, #0xffff
    c960:	54ff61e1 	b.ne	b59c <f0+0x1088>  // b.any
    c964:	17fffb09 	b	b588 <f0+0x1074>
    c968:	72003c3f 	tst	w1, #0xffff
    c96c:	54ff7281 	b.ne	b7bc <f0+0x12a8>  // b.any
    c970:	17fffb8e 	b	b7a8 <f0+0x1294>
    c974:	72003c3f 	tst	w1, #0xffff
    c978:	54ff6d81 	b.ne	b728 <f0+0x1214>  // b.any
    c97c:	17fffb66 	b	b714 <f0+0x1200>
    c980:	72003c3f 	tst	w1, #0xffff
    c984:	54ff7d41 	b.ne	b92c <f0+0x1418>  // b.any
    c988:	17fffbe4 	b	b918 <f0+0x1404>
    c98c:	72003c3f 	tst	w1, #0xffff
    c990:	54ff7721 	b.ne	b874 <f0+0x1360>  // b.any
    c994:	17fffbb3 	b	b860 <f0+0x134c>
    c998:	72003c3f 	tst	w1, #0xffff
    c99c:	54ff8b81 	b.ne	bb0c <f0+0x15f8>  // b.any
    c9a0:	17fffc56 	b	baf8 <f0+0x15e4>
    c9a4:	72003c3f 	tst	w1, #0xffff
    c9a8:	54ff82c1 	b.ne	ba00 <f0+0x14ec>  // b.any
    c9ac:	17fffc10 	b	b9ec <f0+0x14d8>
    c9b0:	aa1403e0 	mov	x0, x20
    c9b4:	97ffde80 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9b8:	17ffff44 	b	c6c8 <f0+0x21b4>
    c9bc:	aa1703e0 	mov	x0, x23
    c9c0:	97ffde7d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9c4:	17fff77e 	b	a7bc <f0+0x2a8>
    c9c8:	aa1703e0 	mov	x0, x23
    c9cc:	97ffde7a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9d0:	17fff7ad 	b	a884 <f0+0x370>
    c9d4:	aa1703e0 	mov	x0, x23
    c9d8:	97ffde77 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9dc:	17fff7ce 	b	a914 <f0+0x400>
    c9e0:	aa1503e0 	mov	x0, x21
    c9e4:	97ffde74 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9e8:	17fff7f0 	b	a9a8 <f0+0x494>
    c9ec:	aa1703e0 	mov	x0, x23
    c9f0:	97ffde71 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9f4:	17fff876 	b	abcc <f0+0x6b8>
    c9f8:	aa1703e0 	mov	x0, x23
    c9fc:	97ffde6e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca00:	17fff899 	b	ac64 <f0+0x750>
    ca04:	aa1703e0 	mov	x0, x23
    ca08:	97ffde6b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca0c:	17fff8d2 	b	ad54 <f0+0x840>
    ca10:	aa1503e0 	mov	x0, x21
    ca14:	97ffde68 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca18:	17fff8fd 	b	ae0c <f0+0x8f8>
    ca1c:	aa1703e0 	mov	x0, x23
    ca20:	97ffde65 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca24:	17fff99f 	b	b0a0 <f0+0xb8c>
    ca28:	aa1703e0 	mov	x0, x23
    ca2c:	97ffde62 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca30:	17fff9ca 	b	b158 <f0+0xc44>
    ca34:	aa1703e0 	mov	x0, x23
    ca38:	97ffde5f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca3c:	17fff9ed 	b	b1f0 <f0+0xcdc>
    ca40:	aa1703e0 	mov	x0, x23
    ca44:	97ffde5c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca48:	17fffa0f 	b	b284 <f0+0xd70>
    ca4c:	aa1703e0 	mov	x0, x23
    ca50:	97ffde59 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca54:	17fffa3a 	b	b33c <f0+0xe28>
    ca58:	aa1703e0 	mov	x0, x23
    ca5c:	97ffde56 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca60:	17fffa7a 	b	b448 <f0+0xf34>
    ca64:	aa1703e0 	mov	x0, x23
    ca68:	97ffde53 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca6c:	17fffa9c 	b	b4dc <f0+0xfc8>
    ca70:	aa1703e0 	mov	x0, x23
    ca74:	97ffde50 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca78:	17fffac7 	b	b594 <f0+0x1080>
    ca7c:	aa1703e0 	mov	x0, x23
    ca80:	97ffde4d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca84:	17fffaf2 	b	b64c <f0+0x1138>
    ca88:	aa1703e0 	mov	x0, x23
    ca8c:	97ffde4a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca90:	17fffb24 	b	b720 <f0+0x120c>
    ca94:	aa1703e0 	mov	x0, x23
    ca98:	97ffde47 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca9c:	17fffb46 	b	b7b4 <f0+0x12a0>
    caa0:	aa1703e0 	mov	x0, x23
    caa4:	97ffde44 	bl	43b4 <fwp_rc_forget_slot.part.0>
    caa8:	17fffb71 	b	b86c <f0+0x1358>
    caac:	aa1703e0 	mov	x0, x23
    cab0:	97ffde41 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cab4:	17fffb9c 	b	b924 <f0+0x1410>
    cab8:	aa1703e0 	mov	x0, x23
    cabc:	97ffde3e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cac0:	17fffbce 	b	b9f8 <f0+0x14e4>
    cac4:	aa1703e0 	mov	x0, x23
    cac8:	97ffde3b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cacc:	17fffc0e 	b	bb04 <f0+0x15f0>
    cad0:	aa1703e0 	mov	x0, x23
    cad4:	97ffde38 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cad8:	17fffc40 	b	bbd8 <f0+0x16c4>
    cadc:	aa1703e0 	mov	x0, x23
    cae0:	97ffde35 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cae4:	17fffc62 	b	bc6c <f0+0x1758>
    cae8:	aa1703e0 	mov	x0, x23
    caec:	97ffde32 	bl	43b4 <fwp_rc_forget_slot.part.0>
    caf0:	17fffc8d 	b	bd24 <f0+0x1810>
    caf4:	aa1703e0 	mov	x0, x23
    caf8:	97ffde2f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cafc:	17fffccd 	b	be30 <f0+0x191c>
    cb00:	aa1703e0 	mov	x0, x23
    cb04:	97ffde2c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb08:	17fffcef 	b	bec4 <f0+0x19b0>
    cb0c:	aa1703e0 	mov	x0, x23
    cb10:	97ffde29 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb14:	17fffd28 	b	bfb4 <f0+0x1aa0>
    cb18:	aa1703e0 	mov	x0, x23
    cb1c:	97ffde26 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb20:	17fffd4b 	b	c04c <f0+0x1b38>
    cb24:	aa1703e0 	mov	x0, x23
    cb28:	97ffde23 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb2c:	17fffd6d 	b	c0e0 <f0+0x1bcc>
    cb30:	aa1703e0 	mov	x0, x23
    cb34:	97ffde20 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb38:	17fffd90 	b	c178 <f0+0x1c64>
    cb3c:	aa1703e0 	mov	x0, x23
    cb40:	97ffde1d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb44:	17fffdc2 	b	c24c <f0+0x1d38>
    cb48:	aa1703e0 	mov	x0, x23
    cb4c:	97ffde1a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb50:	17fffded 	b	c304 <f0+0x1df0>
    cb54:	aa1703e0 	mov	x0, x23
    cb58:	97ffde17 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb5c:	17fffe26 	b	c3f4 <f0+0x1ee0>
    cb60:	aa1703e0 	mov	x0, x23
    cb64:	97ffde14 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb68:	17fffe51 	b	c4ac <f0+0x1f98>
    cb6c:	aa1703e0 	mov	x0, x23
    cb70:	97ffde11 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb74:	17fffe8a 	b	c59c <f0+0x2088>
    cb78:	aa1703e0 	mov	x0, x23
    cb7c:	97ffde0e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cb80:	17fffead 	b	c634 <f0+0x2120>
    cb84:	97ffd747 	bl	28a0 <__stack_chk_fail@plt>
    cb88:	97ffd75a 	bl	28f0 <abort@plt>
    cb8c:	d503201f 	nop

000000000000cb90 <fwp_main_thread>:
    cb90:	d10443ff 	sub	sp, sp, #0x110
    cb94:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    cb98:	f947f400 	ldr	x0, [x0, #4072]
    cb9c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cba0:	910303fd 	add	x29, sp, #0xc0
    cba4:	a90d53f3 	stp	x19, x20, [sp, #208]
    cba8:	b00003f4 	adrp	x20, 89000 <fwp_root_context+0xbb0>
    cbac:	9118c281 	add	x1, x20, #0x630
    cbb0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cbb4:	a90f63f7 	stp	x23, x24, [sp, #240]
    cbb8:	b953a421 	ldr	w1, [x1, #5028]
    cbbc:	a9106bf9 	stp	x25, x26, [sp, #256]
    cbc0:	f9400002 	ldr	x2, [x0]
    cbc4:	f9005fe2 	str	x2, [sp, #184]
    cbc8:	d2800002 	mov	x2, #0x0                   	// #0
    cbcc:	34000ee1 	cbz	w1, cda8 <fwp_main_thread+0x218>
    cbd0:	9118c280 	add	x0, x20, #0x630
    cbd4:	b953a800 	ldr	w0, [x0, #5032]
    cbd8:	35000e00 	cbnz	w0, cd98 <fwp_main_thread+0x208>
    cbdc:	91001fe2 	add	x2, sp, #0x7
    cbe0:	90000135 	adrp	x21, 30000 <__data_start>
    cbe4:	90000123 	adrp	x3, 30000 <__data_start>
    cbe8:	910142b3 	add	x19, x21, #0x50
    cbec:	91114063 	add	x3, x3, #0x450
    cbf0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cbf4:	d2a00025 	mov	x5, #0x10000               	// #65536
    cbf8:	910023e0 	add	x0, sp, #0x8
    cbfc:	d2800001 	mov	x1, #0x0                   	// #0
    cc00:	f90007e3 	str	x3, [sp, #8]
    cc04:	b90013ff 	str	wzr, [sp, #16]
    cc08:	f9000fe5 	str	x5, [sp, #24]
    cc0c:	a90a1262 	stp	x2, x4, [x19, #160]
    cc10:	97ffd6bc 	bl	2700 <sigaltstack@plt>
    cc14:	35000220 	cbnz	w0, cc58 <fwp_main_thread+0xc8>
    cc18:	4f000400 	movi	v0.4s, #0x0
    cc1c:	9100a3e0 	add	x0, sp, #0x28
    cc20:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    cc24:	52800082 	mov	w2, #0x4                   	// #4
    cc28:	9102c021 	add	x1, x1, #0xb0
    cc2c:	72a10002 	movk	w2, #0x800, lsl #16
    cc30:	910083f6 	add	x22, sp, #0x20
    cc34:	f90013e1 	str	x1, [sp, #32]
    cc38:	3d802000 	str	q0, [x0, #128]
    cc3c:	b900abe2 	str	w2, [sp, #168]
    cc40:	ad000000 	stp	q0, q0, [x0]
    cc44:	ad010000 	stp	q0, q0, [x0, #32]
    cc48:	ad020000 	stp	q0, q0, [x0, #64]
    cc4c:	ad030000 	stp	q0, q0, [x0, #96]
    cc50:	97ffd704 	bl	2860 <sigemptyset@plt>
    cc54:	34000080 	cbz	w0, cc64 <fwp_main_thread+0xd4>
    cc58:	f0000000 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    cc5c:	9100c000 	add	x0, x0, #0x30
    cc60:	97ffddb5 	bl	4334 <fwp_trap>
    cc64:	aa1603e1 	mov	x1, x22
    cc68:	d2800002 	mov	x2, #0x0                   	// #0
    cc6c:	52800160 	mov	w0, #0xb                   	// #11
    cc70:	97ffd714 	bl	28c0 <sigaction@plt>
    cc74:	35ffff20 	cbnz	w0, cc58 <fwp_main_thread+0xc8>
    cc78:	aa1603e1 	mov	x1, x22
    cc7c:	d2800002 	mov	x2, #0x0                   	// #0
    cc80:	528000e0 	mov	w0, #0x7                   	// #7
    cc84:	97ffd70f 	bl	28c0 <sigaction@plt>
    cc88:	35fffe80 	cbnz	w0, cc58 <fwp_main_thread+0xc8>
    cc8c:	9118c281 	add	x1, x20, #0x630
    cc90:	52800036 	mov	w22, #0x1                   	// #1
    cc94:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cc98:	910ec000 	add	x0, x0, #0x3b0
    cc9c:	b9013276 	str	w22, [x19, #304]
    cca0:	fd4a1020 	ldr	d0, [x1, #5152]
    cca4:	7e61d800 	ucvtf	d0, d0
    cca8:	fd00a660 	str	d0, [x19, #328]
    ccac:	940006d9 	bl	e810 <atexit>
    ccb0:	350022a0 	cbnz	w0, d104 <fwp_main_thread+0x574>
    ccb4:	b943ca60 	ldr	w0, [x19, #968]
    ccb8:	34001c40 	cbz	w0, d040 <fwp_main_thread+0x4b0>
    ccbc:	910142ba 	add	x26, x21, #0x50
    ccc0:	f9404f56 	ldr	x22, [x26, #152]
    ccc4:	b4000796 	cbz	x22, cdb4 <fwp_main_thread+0x224>
    ccc8:	910102d7 	add	x23, x22, #0x40
    cccc:	39414ad9 	ldrb	w25, [x22, #82]
    ccd0:	52800038 	mov	w24, #0x1                   	// #1
    ccd4:	39014ad8 	strb	w24, [x22, #82]
    ccd8:	f94016c0 	ldr	x0, [x22, #40]
    ccdc:	b40006a0 	cbz	x0, cdb0 <fwp_main_thread+0x220>
    cce0:	f94032c1 	ldr	x1, [x22, #96]
    cce4:	394146c0 	ldrb	w0, [x22, #81]
    cce8:	b4001c61 	cbz	x1, d074 <fwp_main_thread+0x4e4>
    ccec:	36001b20 	tbz	w0, #0, d050 <fwp_main_thread+0x4c0>
    ccf0:	f9404f53 	ldr	x19, [x26, #152]
    ccf4:	f94022c0 	ldr	x0, [x22, #64]
    ccf8:	39414a61 	ldrb	w1, [x19, #82]
    ccfc:	37001e81 	tbnz	w1, #0, d0cc <fwp_main_thread+0x53c>
    cd00:	f9403261 	ldr	x1, [x19, #96]
    cd04:	a911fe77 	stp	x23, xzr, [x19, #280]
    cd08:	f9009660 	str	x0, [x19, #296]
    cd0c:	b4000040 	cbz	x0, cd14 <fwp_main_thread+0x184>
    cd10:	f9009013 	str	x19, [x0, #288]
    cd14:	f90022d3 	str	x19, [x22, #64]
    cd18:	b4000101 	cbz	x1, cd38 <fwp_main_thread+0x1a8>
    cd1c:	f9409740 	ldr	x0, [x26, #296]
    cd20:	39015678 	strb	w24, [x19, #85]
    cd24:	f9003661 	str	x1, [x19, #104]
    cd28:	a910827f 	stp	xzr, x0, [x19, #264]
    cd2c:	b4000040 	cbz	x0, cd34 <fwp_main_thread+0x1a4>
    cd30:	f9008413 	str	x19, [x0, #264]
    cd34:	f9009753 	str	x19, [x26, #296]
    cd38:	39015a7f 	strb	wzr, [x19, #86]
    cd3c:	97ffe86d 	bl	6ef0 <fwp_block>
    cd40:	f9408e62 	ldr	x2, [x19, #280]
    cd44:	b4000142 	cbz	x2, cd6c <fwp_main_thread+0x1dc>
    cd48:	a9520261 	ldp	x1, x0, [x19, #288]
    cd4c:	b4001cc1 	cbz	x1, d0e4 <fwp_main_thread+0x554>
    cd50:	f9009420 	str	x0, [x1, #296]
    cd54:	f9409660 	ldr	x0, [x19, #296]
    cd58:	b4000040 	cbz	x0, cd60 <fwp_main_thread+0x1d0>
    cd5c:	f9009001 	str	x1, [x0, #288]
    cd60:	91080260 	add	x0, x19, #0x200
    cd64:	f900967f 	str	xzr, [x19, #296]
    cd68:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cd6c:	39415660 	ldrb	w0, [x19, #85]
    cd70:	3607fb40 	tbz	w0, #0, ccd8 <fwp_main_thread+0x148>
    cd74:	a9508261 	ldp	x1, x0, [x19, #264]
    cd78:	b4001ba1 	cbz	x1, d0ec <fwp_main_thread+0x55c>
    cd7c:	f9008820 	str	x0, [x1, #272]
    cd80:	b4000040 	cbz	x0, cd88 <fwp_main_thread+0x1f8>
    cd84:	f9008401 	str	x1, [x0, #264]
    cd88:	91080260 	add	x0, x19, #0x200
    cd8c:	3901567f 	strb	wzr, [x19, #85]
    cd90:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cd94:	17ffffd1 	b	ccd8 <fwp_main_thread+0x148>
    cd98:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cd9c:	91301000 	add	x0, x0, #0xc04
    cda0:	9400069c 	bl	e810 <atexit>
    cda4:	17ffff8e 	b	cbdc <fwp_main_thread+0x4c>
    cda8:	97ffdbf2 	bl	3d70 <fwp_heap_init>
    cdac:	17ffff89 	b	cbd0 <fwp_main_thread+0x40>
    cdb0:	39014ad9 	strb	w25, [x22, #82]
    cdb4:	910142b3 	add	x19, x21, #0x50
    cdb8:	f941d660 	ldr	x0, [x19, #936]
    cdbc:	b5000180 	cbnz	x0, cdec <fwp_main_thread+0x25c>
    cdc0:	f941de60 	ldr	x0, [x19, #952]
    cdc4:	b5000140 	cbnz	x0, cdec <fwp_main_thread+0x25c>
    cdc8:	f941d260 	ldr	x0, [x19, #928]
    cdcc:	97ffde15 	bl	4620 <fwp_mem_free>
    cdd0:	f901d27f 	str	xzr, [x19, #928]
    cdd4:	f9404e60 	ldr	x0, [x19, #152]
    cdd8:	f901da7f 	str	xzr, [x19, #944]
    cddc:	b40000c0 	cbz	x0, cdf4 <fwp_main_thread+0x264>
    cde0:	f900541f 	str	xzr, [x0, #168]
    cde4:	f9005c1f 	str	xzr, [x0, #184]
    cde8:	14000003 	b	cdf4 <fwp_main_thread+0x264>
    cdec:	910142a0 	add	x0, x21, #0x50
    cdf0:	f9404c00 	ldr	x0, [x0, #152]
    cdf4:	910142a1 	add	x1, x21, #0x50
    cdf8:	f941f026 	ldr	x6, [x1, #992]
    cdfc:	b903d83f 	str	wzr, [x1, #984]
    ce00:	eb0000df 	cmp	x6, x0
    ce04:	54001861 	b.ne	d110 <fwp_main_thread+0x580>  // b.any
    ce08:	b40003a0 	cbz	x0, ce7c <fwp_main_thread+0x2ec>
    ce0c:	f941c025 	ldr	x5, [x1, #896]
    ce10:	52800021 	mov	w1, #0x1                   	// #1
    ce14:	39014801 	strb	w1, [x0, #82]
    ce18:	b4000325 	cbz	x5, ce7c <fwp_main_thread+0x2ec>
    ce1c:	d503201f 	nop
    ce20:	394140a0 	ldrb	w0, [x5, #80]
    ce24:	37000060 	tbnz	w0, #0, ce30 <fwp_main_thread+0x2a0>
    ce28:	aa0503e0 	mov	x0, x5
    ce2c:	97ffda31 	bl	36f0 <fwp_cancel_tree.part.0>
    ce30:	f9409ca5 	ldr	x5, [x5, #312]
    ce34:	b5ffff65 	cbnz	x5, ce20 <fwp_main_thread+0x290>
    ce38:	910142b3 	add	x19, x21, #0x50
    ce3c:	52800036 	mov	w22, #0x1                   	// #1
    ce40:	f94028c0 	ldr	x0, [x6, #80]
    ce44:	f2001c1f 	tst	x0, #0xff000000ff
    ce48:	540000e1 	b.ne	ce64 <fwp_main_thread+0x2d4>  // b.any
    ce4c:	f9406260 	ldr	x0, [x19, #192]
    ce50:	390150d6 	strb	w22, [x6, #84]
    ce54:	f90080df 	str	xzr, [x6, #256]
    ce58:	b4001360 	cbz	x0, d0c4 <fwp_main_thread+0x534>
    ce5c:	f9008006 	str	x6, [x0, #256]
    ce60:	f9006266 	str	x6, [x19, #192]
    ce64:	97ffe823 	bl	6ef0 <fwp_block>
    ce68:	97ffe7aa 	bl	6d10 <fwp_free_zombie>
    ce6c:	f941c260 	ldr	x0, [x19, #896]
    ce70:	b4000060 	cbz	x0, ce7c <fwp_main_thread+0x2ec>
    ce74:	f941f266 	ldr	x6, [x19, #992]
    ce78:	17fffff2 	b	ce40 <fwp_main_thread+0x2b0>
    ce7c:	910142b6 	add	x22, x21, #0x50
    ce80:	97ffe7a4 	bl	6d10 <fwp_free_zombie>
    ce84:	f94066c0 	ldr	x0, [x22, #200]
    ce88:	b5001440 	cbnz	x0, d110 <fwp_main_thread+0x580>
    ce8c:	f94096c0 	ldr	x0, [x22, #296]
    ce90:	b5001400 	cbnz	x0, d110 <fwp_main_thread+0x580>
    ce94:	b94172d3 	ldr	w19, [x22, #368]
    ce98:	340001f3 	cbz	w19, ced4 <fwp_main_thread+0x344>
    ce9c:	93407e77 	sxtw	x23, w19
    cea0:	51000673 	sub	w19, w19, #0x1
    cea4:	d1000af7 	sub	x23, x23, #0x2
    cea8:	910602d8 	add	x24, x22, #0x180
    ceac:	cb3342f7 	sub	x23, x23, w19, uxtw
    ceb0:	93407e73 	sxtw	x19, w19
    ceb4:	d503201f 	nop
    ceb8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    cebc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cec0:	b90172d3 	str	w19, [x22, #368]
    cec4:	d1000673 	sub	x19, x19, #0x1
    cec8:	97ffd6be 	bl	29c0 <munmap@plt>
    cecc:	eb1302ff 	cmp	x23, x19
    ced0:	54ffff41 	b.ne	ceb8 <fwp_main_thread+0x328>  // b.any
    ced4:	90000133 	adrp	x19, 30000 <__data_start>
    ced8:	91004260 	add	x0, x19, #0x10
    cedc:	b9402800 	ldr	w0, [x0, #40]
    cee0:	36f80ac0 	tbz	w0, #31, d038 <fwp_main_thread+0x4a8>
    cee4:	910142b6 	add	x22, x21, #0x50
    cee8:	91004273 	add	x19, x19, #0x10
    ceec:	12800001 	mov	w1, #0xffffffff            	// #-1
    cef0:	f941fac0 	ldr	x0, [x22, #1008]
    cef4:	b9002a61 	str	w1, [x19, #40]
    cef8:	f941f6c1 	ldr	x1, [x22, #1000]
    cefc:	b40001e0 	cbz	x0, cf38 <fwp_main_thread+0x3a8>
    cf00:	d2800013 	mov	x19, #0x0                   	// #0
    cf04:	d503201f 	nop
    cf08:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cf0c:	b40000e0 	cbz	x0, cf28 <fwp_main_thread+0x398>
    cf10:	f9400001 	ldr	x1, [x0]
    cf14:	b5000fe1 	cbnz	x1, d110 <fwp_main_thread+0x580>
    cf18:	f9400401 	ldr	x1, [x0, #8]
    cf1c:	b5000fa1 	cbnz	x1, d110 <fwp_main_thread+0x580>
    cf20:	97ffddc0 	bl	4620 <fwp_mem_free>
    cf24:	f941f6c1 	ldr	x1, [x22, #1000]
    cf28:	91000673 	add	x19, x19, #0x1
    cf2c:	f941fac0 	ldr	x0, [x22, #1008]
    cf30:	eb00027f 	cmp	x19, x0
    cf34:	54fffea3 	b.cc	cf08 <fwp_main_thread+0x378>  // b.lo, b.ul, b.last
    cf38:	aa0103e0 	mov	x0, x1
    cf3c:	97ffddb9 	bl	4620 <fwp_mem_free>
    cf40:	910142a0 	add	x0, x21, #0x50
    cf44:	f941f013 	ldr	x19, [x0, #992]
    cf48:	f901f41f 	str	xzr, [x0, #1000]
    cf4c:	f901f81f 	str	xzr, [x0, #1008]
    cf50:	b40001f3 	cbz	x19, cf8c <fwp_main_thread+0x3fc>
    cf54:	f9401661 	ldr	x1, [x19, #40]
    cf58:	b5000dc1 	cbnz	x1, d110 <fwp_main_thread+0x580>
    cf5c:	f9405661 	ldr	x1, [x19, #168]
    cf60:	b5000d81 	cbnz	x1, d110 <fwp_main_thread+0x580>
    cf64:	f941d401 	ldr	x1, [x0, #936]
    cf68:	b5000d41 	cbnz	x1, d110 <fwp_main_thread+0x580>
    cf6c:	f941dc00 	ldr	x0, [x0, #952]
    cf70:	b5000d00 	cbnz	x0, d110 <fwp_main_thread+0x580>
    cf74:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cf78:	900003e0 	adrp	x0, 88000 <ad_raw_blocks+0x17bb0>
    cf7c:	91114000 	add	x0, x0, #0x450
    cf80:	97ffd63c 	bl	2870 <memset@plt>
    cf84:	aa1303e0 	mov	x0, x19
    cf88:	97ffdda6 	bl	4620 <fwp_mem_free>
    cf8c:	910142a6 	add	x6, x21, #0x50
    cf90:	9118c294 	add	x20, x20, #0x630
    cf94:	3dc016a1 	ldr	q1, [x21, #80]
    cf98:	52800041 	mov	w1, #0x2                   	// #2
    cf9c:	3dc004c2 	ldr	q2, [x6, #16]
    cfa0:	f0000002 	adrp	x2, f000 <_IO_stdin_used+0x7c0>
    cfa4:	fd4a1280 	ldr	d0, [x20, #5152]
    cfa8:	9101e042 	add	x2, x2, #0x78
    cfac:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cfb0:	fd40a4c1 	ldr	d1, [x6, #328]
    cfb4:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    cfb8:	f947e800 	ldr	x0, [x0, #4048]
    cfbc:	7e61d800 	ucvtf	d0, d0
    cfc0:	a95390c3 	ldp	x3, x4, [x6, #312]
    cfc4:	f9004cdf 	str	xzr, [x6, #152]
    cfc8:	f9400000 	ldr	x0, [x0]
    cfcc:	1e613801 	fsub	d1, d0, d1
    cfd0:	f940acc5 	ldr	x5, [x6, #344]
    cfd4:	b90130df 	str	wzr, [x6, #304]
    cfd8:	5ef1b842 	addp	d2, v2.2d
    cfdc:	fd40a8c0 	ldr	d0, [x6, #336]
    cfe0:	f901f0df 	str	xzr, [x6, #992]
    cfe4:	fd0058c2 	str	d2, [x6, #176]
    cfe8:	97ffd64a 	bl	2910 <__fprintf_chk@plt>
    cfec:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xc90>
    cff0:	f947ec00 	ldr	x0, [x0, #4056]
    cff4:	f9400000 	ldr	x0, [x0]
    cff8:	97ffd676 	bl	29d0 <fflush@plt>
    cffc:	10110020 	adr	x0, 2f000 <fwp_fn_table+0xc90>
    d000:	f947f400 	ldr	x0, [x0, #4072]
    d004:	f9405fe2 	ldr	x2, [sp, #184]
    d008:	f9400001 	ldr	x1, [x0]
    d00c:	eb010042 	subs	x2, x2, x1
    d010:	d2800001 	mov	x1, #0x0                   	// #0
    d014:	54000761 	b.ne	d100 <fwp_main_thread+0x570>  // b.any
    d018:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d01c:	d2800000 	mov	x0, #0x0                   	// #0
    d020:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d024:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d028:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d02c:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d030:	910443ff 	add	sp, sp, #0x110
    d034:	d65f03c0 	ret
    d038:	97ffd61e 	bl	28b0 <close@plt>
    d03c:	17ffffaa 	b	cee4 <fwp_main_thread+0x354>
    d040:	97fff535 	bl	a514 <f0>
    d044:	b903ca76 	str	w22, [x19, #968]
    d048:	f901ea60 	str	x0, [x19, #976]
    d04c:	17ffff1c 	b	ccbc <fwp_main_thread+0x12c>
    d050:	97ffded8 	bl	4bb0 <fwp_now_ns>
    d054:	f94032c1 	ldr	x1, [x22, #96]
    d058:	eb01001f 	cmp	x0, x1
    d05c:	540000ab 	b.lt	d070 <fwp_main_thread+0x4e0>  // b.tstop
    d060:	394142c0 	ldrb	w0, [x22, #80]
    d064:	37000060 	tbnz	w0, #0, d070 <fwp_main_thread+0x4e0>
    d068:	aa1603e0 	mov	x0, x22
    d06c:	97ffd9a1 	bl	36f0 <fwp_cancel_tree.part.0>
    d070:	394146c0 	ldrb	w0, [x22, #81]
    d074:	f9404f53 	ldr	x19, [x26, #152]
    d078:	39414a62 	ldrb	w2, [x19, #82]
    d07c:	3707e3a0 	tbnz	w0, #0, ccf0 <fwp_main_thread+0x160>
    d080:	f94032c1 	ldr	x1, [x22, #96]
    d084:	370001c2 	tbnz	w2, #0, d0bc <fwp_main_thread+0x52c>
    d088:	f9403260 	ldr	x0, [x19, #96]
    d08c:	b4000180 	cbz	x0, d0bc <fwp_main_thread+0x52c>
    d090:	b4000061 	cbz	x1, d09c <fwp_main_thread+0x50c>
    d094:	eb01001f 	cmp	x0, x1
    d098:	9a81d000 	csel	x0, x0, x1, le
    d09c:	f94022c1 	ldr	x1, [x22, #64]
    d0a0:	a911fe77 	stp	x23, xzr, [x19, #280]
    d0a4:	f9009661 	str	x1, [x19, #296]
    d0a8:	b4000261 	cbz	x1, d0f4 <fwp_main_thread+0x564>
    d0ac:	f9009033 	str	x19, [x1, #288]
    d0b0:	aa0003e1 	mov	x1, x0
    d0b4:	f90022d3 	str	x19, [x22, #64]
    d0b8:	17ffff19 	b	cd1c <fwp_main_thread+0x18c>
    d0bc:	f94022c0 	ldr	x0, [x22, #64]
    d0c0:	17ffff11 	b	cd04 <fwp_main_thread+0x174>
    d0c4:	f9006666 	str	x6, [x19, #200]
    d0c8:	17ffff66 	b	ce60 <fwp_main_thread+0x2d0>
    d0cc:	a911fe77 	stp	x23, xzr, [x19, #280]
    d0d0:	f9009660 	str	x0, [x19, #296]
    d0d4:	b4000040 	cbz	x0, d0dc <fwp_main_thread+0x54c>
    d0d8:	f9009013 	str	x19, [x0, #288]
    d0dc:	f90022d3 	str	x19, [x22, #64]
    d0e0:	17ffff16 	b	cd38 <fwp_main_thread+0x1a8>
    d0e4:	f9000040 	str	x0, [x2]
    d0e8:	17ffff1c 	b	cd58 <fwp_main_thread+0x1c8>
    d0ec:	f9009740 	str	x0, [x26, #296]
    d0f0:	17ffff24 	b	cd80 <fwp_main_thread+0x1f0>
    d0f4:	aa0003e1 	mov	x1, x0
    d0f8:	f90022d3 	str	x19, [x22, #64]
    d0fc:	17ffff08 	b	cd1c <fwp_main_thread+0x18c>
    d100:	97ffd5e8 	bl	28a0 <__stack_chk_fail@plt>
    d104:	d0000000 	adrp	x0, f000 <_IO_stdin_used+0x7c0>
    d108:	91016000 	add	x0, x0, #0x58
    d10c:	97ffd89d 	bl	3380 <ad_raw_fail>
    d110:	97ffd5f8 	bl	28f0 <abort@plt>
    d114:	d503201f 	nop
    d118:	14000400 	b	e118 <fwp_main_thread+0x1588>
    d11c:	d503201f 	nop
    d120:	f9400001 	ldr	x1, [x0]
    d124:	17ffffba 	b	d00c <fwp_main_thread+0x47c>
	...
    e118:	d503201f 	nop
    e11c:	d503201f 	nop

000000000000e120 <__divti3>:
    e120:	d503245f 	bti	c
    e124:	d2800004 	mov	x4, #0x0                   	// #0
    e128:	b7f80721 	tbnz	x1, #63, e20c <__divti3+0xec>
    e12c:	b6f80083 	tbz	x3, #63, e13c <__divti3+0x1c>
    e130:	eb0203e2 	negs	x2, x2
    e134:	aa2403e4 	mvn	x4, x4
    e138:	da0303e3 	ngc	x3, x3
    e13c:	aa0203e6 	mov	x6, x2
    e140:	aa0003e7 	mov	x7, x0
    e144:	aa0103e5 	mov	x5, x1
    e148:	b5000583 	cbnz	x3, e1f8 <__divti3+0xd8>
    e14c:	eb01005f 	cmp	x2, x1
    e150:	54000e69 	b.ls	e31c <__divti3+0x1fc>  // b.plast
    e154:	dac01040 	clz	x0, x2
    e158:	b40000e0 	cbz	x0, e174 <__divti3+0x54>
    e15c:	4b0003e1 	neg	w1, w0
    e160:	9ac020a5 	lsl	x5, x5, x0
    e164:	9ac02046 	lsl	x6, x2, x0
    e168:	9ac124e1 	lsr	x1, x7, x1
    e16c:	aa050025 	orr	x5, x1, x5
    e170:	9ac020e7 	lsl	x7, x7, x0
    e174:	d360fcc8 	lsr	x8, x6, #32
    e178:	92407cc2 	and	x2, x6, #0xffffffff
    e17c:	9ac808a3 	udiv	x3, x5, x8
    e180:	9b089465 	msub	x5, x3, x8, x5
    e184:	aa0303e0 	mov	x0, x3
    e188:	9b037c41 	mul	x1, x2, x3
    e18c:	93c780a5 	extr	x5, x5, x7, #32
    e190:	eb05003f 	cmp	x1, x5
    e194:	540000a9 	b.ls	e1a8 <__divti3+0x88>  // b.plast
    e198:	ab0500c5 	adds	x5, x6, x5
    e19c:	d1000460 	sub	x0, x3, #0x1
    e1a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    e1a4:	540015a8 	b.hi	e458 <__divti3+0x338>  // b.pmore
    e1a8:	cb0100a5 	sub	x5, x5, x1
    e1ac:	9ac808a3 	udiv	x3, x5, x8
    e1b0:	9b089465 	msub	x5, x3, x8, x5
    e1b4:	aa0303e1 	mov	x1, x3
    e1b8:	9b037c42 	mul	x2, x2, x3
    e1bc:	aa0703e3 	mov	x3, x7
    e1c0:	b3607ca3 	bfi	x3, x5, #32, #32
    e1c4:	eb03005f 	cmp	x2, x3
    e1c8:	540000c9 	b.ls	e1e0 <__divti3+0xc0>  // b.plast
    e1cc:	ab0300c3 	adds	x3, x6, x3
    e1d0:	d1000425 	sub	x5, x1, #0x1
    e1d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    e1d8:	d1000821 	sub	x1, x1, #0x2
    e1dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    e1e0:	aa008020 	orr	x0, x1, x0, lsl #32
    e1e4:	d2800001 	mov	x1, #0x0                   	// #0
    e1e8:	b4000064 	cbz	x4, e1f4 <__divti3+0xd4>
    e1ec:	eb0003e0 	negs	x0, x0
    e1f0:	da0103e1 	ngc	x1, x1
    e1f4:	d65f03c0 	ret
    e1f8:	eb01007f 	cmp	x3, x1
    e1fc:	54000109 	b.ls	e21c <__divti3+0xfc>  // b.plast
    e200:	d2800001 	mov	x1, #0x0                   	// #0
    e204:	d2800000 	mov	x0, #0x0                   	// #0
    e208:	17fffff8 	b	e1e8 <__divti3+0xc8>
    e20c:	eb0003e0 	negs	x0, x0
    e210:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    e214:	da0103e1 	ngc	x1, x1
    e218:	17ffffc5 	b	e12c <__divti3+0xc>
    e21c:	dac01067 	clz	x7, x3
    e220:	b40010e7 	cbz	x7, e43c <__divti3+0x31c>
    e224:	d2800805 	mov	x5, #0x40                  	// #64
    e228:	cb0700a5 	sub	x5, x5, x7
    e22c:	9ac72063 	lsl	x3, x3, x7
    e230:	9ac52448 	lsr	x8, x2, x5
    e234:	aa030108 	orr	x8, x8, x3
    e238:	9ac52426 	lsr	x6, x1, x5
    e23c:	92407d0a 	and	x10, x8, #0xffffffff
    e240:	d360fd09 	lsr	x9, x8, #32
    e244:	9ac52403 	lsr	x3, x0, x5
    e248:	9ac72021 	lsl	x1, x1, x7
    e24c:	aa010063 	orr	x3, x3, x1
    e250:	9ac72042 	lsl	x2, x2, x7
    e254:	9ac908cb 	udiv	x11, x6, x9
    e258:	9b099965 	msub	x5, x11, x9, x6
    e25c:	aa0b03e1 	mov	x1, x11
    e260:	9b0b7d46 	mul	x6, x10, x11
    e264:	93c380a5 	extr	x5, x5, x3, #32
    e268:	eb0500df 	cmp	x6, x5
    e26c:	540000a9 	b.ls	e280 <__divti3+0x160>  // b.plast
    e270:	ab050105 	adds	x5, x8, x5
    e274:	d1000561 	sub	x1, x11, #0x1
    e278:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    e27c:	54000f48 	b.hi	e464 <__divti3+0x344>  // b.pmore
    e280:	cb0600a6 	sub	x6, x5, x6
    e284:	9ac908cb 	udiv	x11, x6, x9
    e288:	9b099969 	msub	x9, x11, x9, x6
    e28c:	aa0b03e5 	mov	x5, x11
    e290:	9b0b7d4a 	mul	x10, x10, x11
    e294:	b3607d23 	bfi	x3, x9, #32, #32
    e298:	eb03015f 	cmp	x10, x3
    e29c:	540000a9 	b.ls	e2b0 <__divti3+0x190>  // b.plast
    e2a0:	ab030103 	adds	x3, x8, x3
    e2a4:	d1000565 	sub	x5, x11, #0x1
    e2a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    e2ac:	54000e28 	b.hi	e470 <__divti3+0x350>  // b.pmore
    e2b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    e2b4:	92407c48 	and	x8, x2, #0xffffffff
    e2b8:	2a0503e5 	mov	w5, w5
    e2bc:	d360fc42 	lsr	x2, x2, #32
    e2c0:	d360fc26 	lsr	x6, x1, #32
    e2c4:	cb0a0063 	sub	x3, x3, x10
    e2c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    e2cc:	9b087caa 	mul	x10, x5, x8
    e2d0:	9b087cc8 	mul	x8, x6, x8
    e2d4:	9b0220a5 	madd	x5, x5, x2, x8
    e2d8:	9b027cc6 	mul	x6, x6, x2
    e2dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    e2e0:	8b0900c5 	add	x5, x6, x9
    e2e4:	eb02011f 	cmp	x8, x2
    e2e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    e2ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    e2f0:	eb06007f 	cmp	x3, x6
    e2f4:	540000e3 	b.cc	e310 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    e2f8:	92407d4a 	and	x10, x10, #0xffffffff
    e2fc:	9ac72000 	lsl	x0, x0, x7
    e300:	8b028142 	add	x2, x10, x2, lsl #32
    e304:	eb02001f 	cmp	x0, x2
    e308:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    e30c:	54000a01 	b.ne	e44c <__divti3+0x32c>  // b.any
    e310:	d1000420 	sub	x0, x1, #0x1
    e314:	d2800001 	mov	x1, #0x0                   	// #0
    e318:	17ffffb4 	b	e1e8 <__divti3+0xc8>
    e31c:	b5000062 	cbnz	x2, e328 <__divti3+0x208>
    e320:	d2800022 	mov	x2, #0x1                   	// #1
    e324:	9ac30846 	udiv	x6, x2, x3
    e328:	dac010c8 	clz	x8, x6
    e32c:	b5000408 	cbnz	x8, e3ac <__divti3+0x28c>
    e330:	d360fcc9 	lsr	x9, x6, #32
    e334:	92407cc5 	and	x5, x6, #0xffffffff
    e338:	cb060023 	sub	x3, x1, x6
    e33c:	d2800021 	mov	x1, #0x1                   	// #1
    e340:	9ac90868 	udiv	x8, x3, x9
    e344:	9b098d03 	msub	x3, x8, x9, x3
    e348:	aa0803e0 	mov	x0, x8
    e34c:	9b057d02 	mul	x2, x8, x5
    e350:	93c78063 	extr	x3, x3, x7, #32
    e354:	eb03005f 	cmp	x2, x3
    e358:	540000a9 	b.ls	e36c <__divti3+0x24c>  // b.plast
    e35c:	ab0300c3 	adds	x3, x6, x3
    e360:	d1000500 	sub	x0, x8, #0x1
    e364:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    e368:	54000968 	b.hi	e494 <__divti3+0x374>  // b.pmore
    e36c:	cb020063 	sub	x3, x3, x2
    e370:	9ac90862 	udiv	x2, x3, x9
    e374:	aa0203e8 	mov	x8, x2
    e378:	9b098c42 	msub	x2, x2, x9, x3
    e37c:	aa0703e3 	mov	x3, x7
    e380:	9b057d05 	mul	x5, x8, x5
    e384:	b3607c43 	bfi	x3, x2, #32, #32
    e388:	eb0300bf 	cmp	x5, x3
    e38c:	540000c9 	b.ls	e3a4 <__divti3+0x284>  // b.plast
    e390:	ab0300c2 	adds	x2, x6, x3
    e394:	d1000503 	sub	x3, x8, #0x1
    e398:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    e39c:	d1000908 	sub	x8, x8, #0x2
    e3a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    e3a4:	aa008100 	orr	x0, x8, x0, lsl #32
    e3a8:	17ffff90 	b	e1e8 <__divti3+0xc8>
    e3ac:	9ac820c6 	lsl	x6, x6, x8
    e3b0:	d2800803 	mov	x3, #0x40                  	// #64
    e3b4:	cb080063 	sub	x3, x3, x8
    e3b8:	d360fcc9 	lsr	x9, x6, #32
    e3bc:	9ac82027 	lsl	x7, x1, x8
    e3c0:	92407cc5 	and	x5, x6, #0xffffffff
    e3c4:	9ac32422 	lsr	x2, x1, x3
    e3c8:	9ac32403 	lsr	x3, x0, x3
    e3cc:	aa070063 	orr	x3, x3, x7
    e3d0:	9ac9084a 	udiv	x10, x2, x9
    e3d4:	9ac82007 	lsl	x7, x0, x8
    e3d8:	9b098940 	msub	x0, x10, x9, x2
    e3dc:	aa0a03e1 	mov	x1, x10
    e3e0:	9b0a7ca2 	mul	x2, x5, x10
    e3e4:	93c38000 	extr	x0, x0, x3, #32
    e3e8:	eb00005f 	cmp	x2, x0
    e3ec:	540000a9 	b.ls	e400 <__divti3+0x2e0>  // b.plast
    e3f0:	ab0000c0 	adds	x0, x6, x0
    e3f4:	d1000541 	sub	x1, x10, #0x1
    e3f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    e3fc:	54000468 	b.hi	e488 <__divti3+0x368>  // b.pmore
    e400:	cb020000 	sub	x0, x0, x2
    e404:	9ac9080a 	udiv	x10, x0, x9
    e408:	9b098140 	msub	x0, x10, x9, x0
    e40c:	aa0a03e2 	mov	x2, x10
    e410:	9b0a7ca8 	mul	x8, x5, x10
    e414:	b3607c03 	bfi	x3, x0, #32, #32
    e418:	eb03011f 	cmp	x8, x3
    e41c:	540000a9 	b.ls	e430 <__divti3+0x310>  // b.plast
    e420:	ab0300c3 	adds	x3, x6, x3
    e424:	d1000542 	sub	x2, x10, #0x1
    e428:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    e42c:	54000288 	b.hi	e47c <__divti3+0x35c>  // b.pmore
    e430:	cb080063 	sub	x3, x3, x8
    e434:	aa018041 	orr	x1, x2, x1, lsl #32
    e438:	17ffffc2 	b	e340 <__divti3+0x220>
    e43c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    e440:	d2800001 	mov	x1, #0x0                   	// #0
    e444:	9a9f87e0 	cset	x0, ls	// ls = plast
    e448:	17ffff68 	b	e1e8 <__divti3+0xc8>
    e44c:	aa0103e0 	mov	x0, x1
    e450:	d2800001 	mov	x1, #0x0                   	// #0
    e454:	17ffff65 	b	e1e8 <__divti3+0xc8>
    e458:	d1000860 	sub	x0, x3, #0x2
    e45c:	8b0600a5 	add	x5, x5, x6
    e460:	17ffff52 	b	e1a8 <__divti3+0x88>
    e464:	d1000961 	sub	x1, x11, #0x2
    e468:	8b0800a5 	add	x5, x5, x8
    e46c:	17ffff85 	b	e280 <__divti3+0x160>
    e470:	d1000965 	sub	x5, x11, #0x2
    e474:	8b080063 	add	x3, x3, x8
    e478:	17ffff8e 	b	e2b0 <__divti3+0x190>
    e47c:	d1000942 	sub	x2, x10, #0x2
    e480:	8b060063 	add	x3, x3, x6
    e484:	17ffffeb 	b	e430 <__divti3+0x310>
    e488:	d1000941 	sub	x1, x10, #0x2
    e48c:	8b060000 	add	x0, x0, x6
    e490:	17ffffdc 	b	e400 <__divti3+0x2e0>
    e494:	d1000900 	sub	x0, x8, #0x2
    e498:	8b060063 	add	x3, x3, x6
    e49c:	17ffffb4 	b	e36c <__divti3+0x24c>

000000000000e4a0 <__modti3>:
    e4a0:	d503245f 	bti	c
    e4a4:	d2800004 	mov	x4, #0x0                   	// #0
    e4a8:	b6f80081 	tbz	x1, #63, e4b8 <__modti3+0x18>
    e4ac:	eb0003e0 	negs	x0, x0
    e4b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    e4b4:	da0103e1 	ngc	x1, x1
    e4b8:	f100007f 	cmp	x3, #0x0
    e4bc:	5400128b 	b.lt	e70c <__modti3+0x26c>  // b.tstop
    e4c0:	aa0003e7 	mov	x7, x0
    e4c4:	aa0103e6 	mov	x6, x1
    e4c8:	540004e1 	b.ne	e564 <__modti3+0xc4>  // b.any
    e4cc:	eb02003f 	cmp	x1, x2
    e4d0:	54000dc2 	b.cs	e688 <__modti3+0x1e8>  // b.hs, b.nlast
    e4d4:	dac01043 	clz	x3, x2
    e4d8:	aa0303e5 	mov	x5, x3
    e4dc:	b40000e3 	cbz	x3, e4f8 <__modti3+0x58>
    e4e0:	4b0303e6 	neg	w6, w3
    e4e4:	9ac32021 	lsl	x1, x1, x3
    e4e8:	9ac32042 	lsl	x2, x2, x3
    e4ec:	9ac62406 	lsr	x6, x0, x6
    e4f0:	aa0100c6 	orr	x6, x6, x1
    e4f4:	9ac32007 	lsl	x7, x0, x3
    e4f8:	d360fc40 	lsr	x0, x2, #32
    e4fc:	92407c43 	and	x3, x2, #0xffffffff
    e500:	9ac008c1 	udiv	x1, x6, x0
    e504:	9b009826 	msub	x6, x1, x0, x6
    e508:	9b017c61 	mul	x1, x3, x1
    e50c:	93c780c6 	extr	x6, x6, x7, #32
    e510:	eb06003f 	cmp	x1, x6
    e514:	540000a9 	b.ls	e528 <__modti3+0x88>  // b.plast
    e518:	ab060046 	adds	x6, x2, x6
    e51c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    e520:	8b0200c8 	add	x8, x6, x2
    e524:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    e528:	cb0100c6 	sub	x6, x6, x1
    e52c:	9ac008c8 	udiv	x8, x6, x0
    e530:	9b009901 	msub	x1, x8, x0, x6
    e534:	aa0703e0 	mov	x0, x7
    e538:	9b087c63 	mul	x3, x3, x8
    e53c:	b3607c20 	bfi	x0, x1, #32, #32
    e540:	eb00007f 	cmp	x3, x0
    e544:	54001088 	b.hi	e754 <__modti3+0x2b4>  // b.pmore
    e548:	cb030000 	sub	x0, x0, x3
    e54c:	9ac52400 	lsr	x0, x0, x5
    e550:	d2800001 	mov	x1, #0x0                   	// #0
    e554:	b4000064 	cbz	x4, e560 <__modti3+0xc0>
    e558:	eb0003e0 	negs	x0, x0
    e55c:	da0103e1 	ngc	x1, x1
    e560:	d65f03c0 	ret
    e564:	dac01066 	clz	x6, x3
    e568:	eb03003f 	cmp	x1, x3
    e56c:	54ffff43 	b.cc	e554 <__modti3+0xb4>  // b.lo, b.ul, b.last
    e570:	93407cc5 	sxtw	x5, w6
    e574:	d2800808 	mov	x8, #0x40                  	// #64
    e578:	cb050108 	sub	x8, x8, x5
    e57c:	9ac62063 	lsl	x3, x3, x6
    e580:	9ac62025 	lsl	x5, x1, x6
    e584:	9ac82447 	lsr	x7, x2, x8
    e588:	aa0300e7 	orr	x7, x7, x3
    e58c:	9ac82423 	lsr	x3, x1, x8
    e590:	92407cec 	and	x12, x7, #0xffffffff
    e594:	d360fcea 	lsr	x10, x7, #32
    e598:	9ac82401 	lsr	x1, x0, x8
    e59c:	aa050021 	orr	x1, x1, x5
    e5a0:	9ac62042 	lsl	x2, x2, x6
    e5a4:	9ac62000 	lsl	x0, x0, x6
    e5a8:	9aca086b 	udiv	x11, x3, x10
    e5ac:	9b0a8d63 	msub	x3, x11, x10, x3
    e5b0:	aa0b03e5 	mov	x5, x11
    e5b4:	9b0b7d89 	mul	x9, x12, x11
    e5b8:	93c18063 	extr	x3, x3, x1, #32
    e5bc:	eb03013f 	cmp	x9, x3
    e5c0:	540000a9 	b.ls	e5d4 <__modti3+0x134>  // b.plast
    e5c4:	ab0300e3 	adds	x3, x7, x3
    e5c8:	d1000565 	sub	x5, x11, #0x1
    e5cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    e5d0:	54001168 	b.hi	e7fc <__modti3+0x35c>  // b.pmore
    e5d4:	cb090063 	sub	x3, x3, x9
    e5d8:	9aca086b 	udiv	x11, x3, x10
    e5dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    e5e0:	aa0b03e9 	mov	x9, x11
    e5e4:	9b0b7d8c 	mul	x12, x12, x11
    e5e8:	b3607d41 	bfi	x1, x10, #32, #32
    e5ec:	eb01019f 	cmp	x12, x1
    e5f0:	540000a9 	b.ls	e604 <__modti3+0x164>  // b.plast
    e5f4:	ab0100e1 	adds	x1, x7, x1
    e5f8:	d1000569 	sub	x9, x11, #0x1
    e5fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    e600:	54000f88 	b.hi	e7f0 <__modti3+0x350>  // b.pmore
    e604:	aa058123 	orr	x3, x9, x5, lsl #32
    e608:	92407c4b 	and	x11, x2, #0xffffffff
    e60c:	2a0903e9 	mov	w9, w9
    e610:	d360fc4a 	lsr	x10, x2, #32
    e614:	d360fc63 	lsr	x3, x3, #32
    e618:	cb0c0021 	sub	x1, x1, x12
    e61c:	aa0a03ec 	mov	x12, x10
    e620:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    e624:	9b0b7d25 	mul	x5, x9, x11
    e628:	9b0b7c6b 	mul	x11, x3, x11
    e62c:	9b0a2d29 	madd	x9, x9, x10, x11
    e630:	92407caa 	and	x10, x5, #0xffffffff
    e634:	9b0c7c63 	mul	x3, x3, x12
    e638:	8b458125 	add	x5, x9, x5, lsr #32
    e63c:	8b0d0069 	add	x9, x3, x13
    e640:	eb05017f 	cmp	x11, x5
    e644:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    e648:	8b058149 	add	x9, x10, x5, lsl #32
    e64c:	8b458063 	add	x3, x3, x5, lsr #32
    e650:	eb03003f 	cmp	x1, x3
    e654:	54000063 	b.cc	e660 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    e658:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    e65c:	54000082 	b.cs	e66c <__modti3+0x1cc>  // b.hs, b.nlast
    e660:	eb020129 	subs	x9, x9, x2
    e664:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    e668:	cb070063 	sub	x3, x3, x7
    e66c:	eb090000 	subs	x0, x0, x9
    e670:	da030021 	sbc	x1, x1, x3
    e674:	9ac62400 	lsr	x0, x0, x6
    e678:	9ac82028 	lsl	x8, x1, x8
    e67c:	aa000100 	orr	x0, x8, x0
    e680:	9ac62421 	lsr	x1, x1, x6
    e684:	17ffffb4 	b	e554 <__modti3+0xb4>
    e688:	b5000062 	cbnz	x2, e694 <__modti3+0x1f4>
    e68c:	d2800023 	mov	x3, #0x1                   	// #1
    e690:	9ac20862 	udiv	x2, x3, x2
    e694:	dac01048 	clz	x8, x2
    e698:	aa0803e5 	mov	x5, x8
    e69c:	b5000668 	cbnz	x8, e768 <__modti3+0x2c8>
    e6a0:	cb020020 	sub	x0, x1, x2
    e6a4:	d360fc49 	lsr	x9, x2, #32
    e6a8:	92407c4a 	and	x10, x2, #0xffffffff
    e6ac:	9ac90801 	udiv	x1, x0, x9
    e6b0:	9b098020 	msub	x0, x1, x9, x0
    e6b4:	9b0a7c21 	mul	x1, x1, x10
    e6b8:	93c78000 	extr	x0, x0, x7, #32
    e6bc:	eb00003f 	cmp	x1, x0
    e6c0:	540000a9 	b.ls	e6d4 <__modti3+0x234>  // b.plast
    e6c4:	ab000040 	adds	x0, x2, x0
    e6c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    e6cc:	8b020003 	add	x3, x0, x2
    e6d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    e6d4:	cb010001 	sub	x1, x0, x1
    e6d8:	9ac90820 	udiv	x0, x1, x9
    e6dc:	9b098403 	msub	x3, x0, x9, x1
    e6e0:	aa0703e1 	mov	x1, x7
    e6e4:	9b0a7c00 	mul	x0, x0, x10
    e6e8:	b3607c61 	bfi	x1, x3, #32, #32
    e6ec:	eb01001f 	cmp	x0, x1
    e6f0:	540000a9 	b.ls	e704 <__modti3+0x264>  // b.plast
    e6f4:	ab010041 	adds	x1, x2, x1
    e6f8:	8b020022 	add	x2, x1, x2
    e6fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    e700:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    e704:	cb000020 	sub	x0, x1, x0
    e708:	17ffff91 	b	e54c <__modti3+0xac>
    e70c:	eb0203e5 	negs	x5, x2
    e710:	aa0003e7 	mov	x7, x0
    e714:	da0303e8 	ngc	x8, x3
    e718:	aa0503e2 	mov	x2, x5
    e71c:	aa0803e3 	mov	x3, x8
    e720:	aa0103e6 	mov	x6, x1
    e724:	b4ffed48 	cbz	x8, e4cc <__modti3+0x2c>
    e728:	eb01011f 	cmp	x8, x1
    e72c:	54fff148 	b.hi	e554 <__modti3+0xb4>  // b.pmore
    e730:	dac01109 	clz	x9, x8
    e734:	2a0903e6 	mov	w6, w9
    e738:	b5fff1c9 	cbnz	x9, e570 <__modti3+0xd0>
    e73c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    e740:	54000068 	b.hi	e74c <__modti3+0x2ac>  // b.pmore
    e744:	eb050007 	subs	x7, x0, x5
    e748:	da080021 	sbc	x1, x1, x8
    e74c:	aa0703e0 	mov	x0, x7
    e750:	17ffff81 	b	e554 <__modti3+0xb4>
    e754:	ab000040 	adds	x0, x2, x0
    e758:	8b020002 	add	x2, x0, x2
    e75c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    e760:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    e764:	17ffff79 	b	e548 <__modti3+0xa8>
    e768:	9ac82042 	lsl	x2, x2, x8
    e76c:	d2800803 	mov	x3, #0x40                  	// #64
    e770:	cb080063 	sub	x3, x3, x8
    e774:	d360fc49 	lsr	x9, x2, #32
    e778:	9ac82027 	lsl	x7, x1, x8
    e77c:	92407c4a 	and	x10, x2, #0xffffffff
    e780:	9ac32426 	lsr	x6, x1, x3
    e784:	9ac32403 	lsr	x3, x0, x3
    e788:	aa070063 	orr	x3, x3, x7
    e78c:	9ac908c1 	udiv	x1, x6, x9
    e790:	9ac82007 	lsl	x7, x0, x8
    e794:	9b099820 	msub	x0, x1, x9, x6
    e798:	9b017d41 	mul	x1, x10, x1
    e79c:	93c38000 	extr	x0, x0, x3, #32
    e7a0:	eb00003f 	cmp	x1, x0
    e7a4:	540000a9 	b.ls	e7b8 <__modti3+0x318>  // b.plast
    e7a8:	ab000040 	adds	x0, x2, x0
    e7ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    e7b0:	8b020006 	add	x6, x0, x2
    e7b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    e7b8:	cb010000 	sub	x0, x0, x1
    e7bc:	9ac90801 	udiv	x1, x0, x9
    e7c0:	9b098026 	msub	x6, x1, x9, x0
    e7c4:	aa0303e0 	mov	x0, x3
    e7c8:	9b017d41 	mul	x1, x10, x1
    e7cc:	b3607cc0 	bfi	x0, x6, #32, #32
    e7d0:	eb00003f 	cmp	x1, x0
    e7d4:	540000a9 	b.ls	e7e8 <__modti3+0x348>  // b.plast
    e7d8:	ab000040 	adds	x0, x2, x0
    e7dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    e7e0:	8b020003 	add	x3, x0, x2
    e7e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    e7e8:	cb010000 	sub	x0, x0, x1
    e7ec:	17ffffb0 	b	e6ac <__modti3+0x20c>
    e7f0:	d1000969 	sub	x9, x11, #0x2
    e7f4:	8b070021 	add	x1, x1, x7
    e7f8:	17ffff83 	b	e604 <__modti3+0x164>
    e7fc:	d1000965 	sub	x5, x11, #0x2
    e800:	8b070063 	add	x3, x3, x7
    e804:	17ffff74 	b	e5d4 <__modti3+0x134>
    e808:	d503201f 	nop
    e80c:	d503201f 	nop

000000000000e810 <atexit>:
    e810:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    e814:	d0000102 	adrp	x2, 30000 <__data_start>
    e818:	d2800001 	mov	x1, #0x0                   	// #0
    e81c:	910003fd 	mov	x29, sp
    e820:	a8c17bfd 	ldp	x29, x30, [sp], #16
    e824:	f9400442 	ldr	x2, [x2, #8]
    e828:	17ffcfde 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e82c <_fini>:
    e82c:	d503201f 	nop
    e830:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    e834:	910003fd 	mov	x29, sp
    e838:	a8c17bfd 	ldp	x29, x30, [sp], #16
    e83c:	d65f03c0 	ret
