
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x47c>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912a20a5 	add	x5, x5, #0xa88
    2a20:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x47c>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	912a4084 	add	x4, x4, #0xa90
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004f0 	bl	3e10 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	910102a1 	add	x1, x21, #0x40
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe720>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003c20 	str	x0, [x1, #120]
    2aac:	940006f9 	bl	4690 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2ab4:	91368000 	add	x0, x0, #0xda0
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x1b00>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	912e1042 	add	x2, x2, #0xb84
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910102b5 	add	x21, x21, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430aa0 	ldr	w0, [x21, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2bcc:	91374000 	add	x0, x0, #0xdd0
    2bd0:	94000490 	bl	3e10 <fwp_trap>
    2bd4:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2bd8:	9136c000 	add	x0, x0, #0xdb0
    2bdc:	9400048d 	bl	3e10 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff3e 	bl	28e0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee3 	bl	27a0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2c20:	9138a000 	add	x0, x0, #0xe28
    2c24:	9400047b 	bl	3e10 <fwp_trap>
    2c28:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2c2c:	9137e000 	add	x0, x0, #0xdf8
    2c30:	94000478 	bl	3e10 <fwp_trap>
    2c34:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2c38:	91394000 	add	x0, x0, #0xe50
    2c3c:	94000475 	bl	3e10 <fwp_trap>
    2c40:	97fffeec 	bl	27f0 <__stack_chk_fail@plt>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x840>
    2e34:	91114021 	add	x1, x1, #0x450
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    2fd0:	911f2000 	add	x0, x0, #0x7c8
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x840>
    3098:	9110c021 	add	x1, x1, #0x430
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3370:	911f2000 	add	x0, x0, #0x7c8
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x47c>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	911f8021 	add	x1, x1, #0x7e0
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x47c>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	911fa021 	add	x1, x1, #0x7e8
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x47c>
    34e0:	911fc021 	add	x1, x1, #0x7f0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x47c>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	911fe084 	add	x4, x4, #0x7f8
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc7f 	bl	2760 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcd8 	bl	28d0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc3 	bl	2890 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc0c 	bl	2640 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc44 	bl	2740 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc35 	bl	2740 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbed 	bl	2640 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbf9 	bl	2680 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc89 	bl	28d0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x47c>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	91204084 	add	x4, x4, #0x810
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0a 	bl	2760 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbf9 	bl	2740 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc59 	bl	28d0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x47c>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	91200084 	add	x4, x4, #0x800
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe2 	bl	2760 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbcc 	bl	2740 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba0 	bl	2740 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbbc 	bl	27f0 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    390c:	91154042 	add	x2, x2, #0x550
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x47c>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	91206021 	add	x1, x1, #0x818
    3968:	91208000 	add	x0, x0, #0x820
    396c:	97fffb85 	bl	2780 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbaf 	bl	2890 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb5f 	bl	2770 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x47c>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	91210042 	add	x2, x2, #0x840
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb82 	b	2860 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb62 	bl	27f0 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3a78:	91114061 	add	x1, x3, #0x450
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3a88:	91154262 	add	x2, x19, #0x550
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x840>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3abc:	91124021 	add	x1, x1, #0x490
    3ac0:	3dc11843 	ldr	q3, [x2, #1120]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3aec:	91114063 	add	x3, x3, #0x450
    3af0:	9113c084 	add	x4, x4, #0x4f0
    3af4:	91154266 	add	x6, x19, #0x550
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb45 	bl	2880 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	91154275 	add	x21, x19, #0x550
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb2f 	bl	2880 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3bd8:	91232000 	add	x0, x0, #0x8c8
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb68 	bl	2980 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	91154273 	add	x19, x19, #0x550
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	91010122 	add	x2, x9, #0x40
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	91010120 	add	x0, x9, #0x40
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	91010129 	add	x9, x9, #0x40
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9401400 	ldr	x0, [x0, #40]
    3d04:	b7f80760 	tbnz	x0, #63, 3df0 <fwp_tape_buffers_release+0x100>
    3d08:	f9401a61 	ldr	x1, [x19, #48]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3d3c:	91236000 	add	x0, x0, #0x8d8
    3d40:	97fffb10 	bl	2980 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	91236000 	add	x0, x0, #0x8d8
    3d78:	97fffb02 	bl	2980 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	910102d6 	add	x22, x22, #0x40
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400a61 	ldp	q1, q2, [x19]
    3db8:	f9003ad4 	str	x20, [x22, #112]
    3dbc:	4f000400 	movi	v0.4s, #0x0
    3dc0:	ad000aa1 	stp	q1, q2, [x21]
    3dc4:	3dc00a61 	ldr	q1, [x19, #32]
    3dc8:	3d800aa1 	str	q1, [x21, #32]
    3dcc:	f9401a60 	ldr	x0, [x19, #48]
    3dd0:	f9001aa0 	str	x0, [x21, #48]
    3dd4:	f9001a7f 	str	xzr, [x19, #48]
    3dd8:	ad000260 	stp	q0, q0, [x19]
    3ddc:	3d800a60 	str	q0, [x19, #32]
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3dec:	d65f03c0 	ret
    3df0:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3df4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df8:	91236000 	add	x0, x0, #0x8d8
    3dfc:	97fffae1 	bl	2980 <getenv@plt>
    3e00:	b5fffa40 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3e04:	17ffffd6 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3e08:	d503201f 	nop
    3e0c:	d503201f 	nop

0000000000003e10 <fwp_trap>:
    3e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e14:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e18:	d53bd041 	mrs	x1, tpidr_el0
    3e1c:	910003fd 	mov	x29, sp
    3e20:	f9402442 	ldr	x2, [x2, #72]
    3e24:	91400021 	add	x1, x1, #0x0, lsl #12
    3e28:	91004021 	add	x1, x1, #0x10
    3e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e30:	aa0003f3 	mov	x19, x0
    3e34:	f9400034 	ldr	x20, [x1]
    3e38:	b4000062 	cbz	x2, 3e44 <fwp_trap+0x34>
    3e3c:	aa0203e0 	mov	x0, x2
    3e40:	97fffab8 	bl	2920 <fflush@plt>
    3e44:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3e48:	f947ec00 	ldr	x0, [x0, #4056]
    3e4c:	f9400000 	ldr	x0, [x0]
    3e50:	97fffab4 	bl	2920 <fflush@plt>
    3e54:	aa1303e3 	mov	x3, x19
    3e58:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x47c>
    3e5c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    3e60:	f947ea73 	ldr	x19, [x19, #4048]
    3e64:	9123c042 	add	x2, x2, #0x8f0
    3e68:	52800041 	mov	w1, #0x2                   	// #2
    3e6c:	f9400260 	ldr	x0, [x19]
    3e70:	97fffa7c 	bl	2860 <__fprintf_chk@plt>
    3e74:	b40000b4 	cbz	x20, 3e88 <fwp_trap+0x78>
    3e78:	f9400260 	ldr	x0, [x19]
    3e7c:	97fffaa9 	bl	2920 <fflush@plt>
    3e80:	52800ca0 	mov	w0, #0x65                  	// #101
    3e84:	97fffab7 	bl	2960 <_Exit@plt>
    3e88:	52800ca0 	mov	w0, #0x65                  	// #101
    3e8c:	97fffa05 	bl	26a0 <exit@plt>

0000000000003e90 <fwp_rc_forget_slot.part.0>:
    3e90:	ca404401 	eor	x1, x0, x0, lsr #17
    3e94:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e98:	ca412421 	eor	x1, x1, x1, lsr #9
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	92401c21 	and	x1, x1, #0xff
    3ea4:	f9000bf3 	str	x19, [sp, #16]
    3ea8:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3eac:	91154262 	add	x2, x19, #0x550
    3eb0:	910a2423 	add	x3, x1, #0x289
    3eb4:	8b010c41 	add	x1, x2, x1, lsl #3
    3eb8:	8b030c43 	add	x3, x2, x3, lsl #3
    3ebc:	f94a2421 	ldr	x1, [x1, #5192]
    3ec0:	b50000a1 	cbnz	x1, 3ed4 <fwp_rc_forget_slot.part.0+0x44>
    3ec4:	14000012 	b	3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ec8:	91004023 	add	x3, x1, #0x10
    3ecc:	f9400821 	ldr	x1, [x1, #16]
    3ed0:	b40001e1 	cbz	x1, 3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ed4:	f9400022 	ldr	x2, [x1]
    3ed8:	eb02001f 	cmp	x0, x2
    3edc:	54ffff61 	b.ne	3ec8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ee0:	f9400060 	ldr	x0, [x3]
    3ee4:	91154273 	add	x19, x19, #0x550
    3ee8:	f9400801 	ldr	x1, [x0, #16]
    3eec:	f9000061 	str	x1, [x3]
    3ef0:	97fffa70 	bl	28b0 <free@plt>
    3ef4:	f94e2660 	ldr	x0, [x19, #7240]
    3ef8:	d1000400 	sub	x0, x0, #0x1
    3efc:	f90e2660 	str	x0, [x19, #7240]
    3f00:	f9400bf3 	ldr	x19, [sp, #16]
    3f04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f08:	d65f03c0 	ret
    3f0c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    3f10:	91240000 	add	x0, x0, #0x900
    3f14:	97ffffbf 	bl	3e10 <fwp_trap>
    3f18:	d503201f 	nop
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_rc_prepare_chunk>:
    3f20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f24:	910003fd 	mov	x29, sp
    3f28:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f2c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    3f30:	911542c2 	add	x2, x22, #0x550
    3f34:	b9401c03 	ldr	w3, [x0, #28]
    3f38:	aa0103f5 	mov	x21, x1
    3f3c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f40:	aa0003f4 	mov	x20, x0
    3f44:	f94e2440 	ldr	x0, [x2, #7240]
    3f48:	b4000440 	cbz	x0, 3fd0 <fwp_rc_prepare_chunk+0xb0>
    3f4c:	d2800013 	mov	x19, #0x0                   	// #0
    3f50:	35000203 	cbnz	w3, 3f90 <fwp_rc_prepare_chunk+0x70>
    3f54:	b4000361 	cbz	x1, 3fc0 <fwp_rc_prepare_chunk+0xa0>
    3f58:	f9401280 	ldr	x0, [x20, #32]
    3f5c:	97fffa55 	bl	28b0 <free@plt>
    3f60:	aa1503e0 	mov	x0, x21
    3f64:	d2800021 	mov	x1, #0x1                   	// #1
    3f68:	97fffa1a 	bl	27d0 <calloc@plt>
    3f6c:	f9001280 	str	x0, [x20, #32]
    3f70:	b5000460 	cbnz	x0, 3ffc <fwp_rc_prepare_chunk+0xdc>
    3f74:	97fffc0f 	bl	2fb0 <fwp_heap_oom>
    3f78:	97ffffc6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    3f7c:	91000673 	add	x19, x19, #0x1
    3f80:	b9401e83 	ldr	w3, [x20, #28]
    3f84:	eb13007f 	cmp	x3, x19
    3f88:	54000169 	b.ls	3fb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f8c:	d503201f 	nop
    3f90:	f9401283 	ldr	x3, [x20, #32]
    3f94:	8b130060 	add	x0, x3, x19
    3f98:	38736863 	ldrb	w3, [x3, x19]
    3f9c:	7103fc7f 	cmp	w3, #0xff
    3fa0:	54fffec0 	b.eq	3f78 <fwp_rc_prepare_chunk+0x58>  // b.none
    3fa4:	b9401e83 	ldr	w3, [x20, #28]
    3fa8:	91000673 	add	x19, x19, #0x1
    3fac:	eb13007f 	cmp	x3, x19
    3fb0:	54ffff08 	b.hi	3f90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fb4:	eb0302bf 	cmp	x21, x3
    3fb8:	54000121 	b.ne	3fdc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fbc:	b5000335 	cbnz	x21, 4020 <fwp_rc_prepare_chunk+0x100>
    3fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fcc:	d65f03c0 	ret
    3fd0:	2a0303e3 	mov	w3, w3
    3fd4:	eb0302bf 	cmp	x21, x3
    3fd8:	54ffff20 	b.eq	3fbc <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fdc:	911542c2 	add	x2, x22, #0x550
    3fe0:	f9401280 	ldr	x0, [x20, #32]
    3fe4:	f94e2841 	ldr	x1, [x2, #7248]
    3fe8:	cb030021 	sub	x1, x1, x3
    3fec:	f90e2841 	str	x1, [x2, #7248]
    3ff0:	97fffa30 	bl	28b0 <free@plt>
    3ff4:	b5fffb75 	cbnz	x21, 3f60 <fwp_rc_prepare_chunk+0x40>
    3ff8:	f900129f 	str	xzr, [x20, #32]
    3ffc:	911542d6 	add	x22, x22, #0x550
    4000:	f94e2ac0 	ldr	x0, [x22, #7248]
    4004:	b9001e95 	str	w21, [x20, #28]
    4008:	a94153f3 	ldp	x19, x20, [sp, #16]
    400c:	8b150000 	add	x0, x0, x21
    4010:	f90e2ac0 	str	x0, [x22, #7248]
    4014:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4018:	a8c37bfd 	ldp	x29, x30, [sp], #48
    401c:	d65f03c0 	ret
    4020:	f9401280 	ldr	x0, [x20, #32]
    4024:	aa1503e2 	mov	x2, x21
    4028:	a94153f3 	ldp	x19, x20, [sp, #16]
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4034:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4038:	17fff9e2 	b	27c0 <memset@plt>
    403c:	d503201f 	nop

0000000000004040 <fwp_heap_refill>:
    4040:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4044:	910003fd 	mov	x29, sp
    4048:	a9025bf5 	stp	x21, x22, [sp, #32]
    404c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4050:	911542b5 	add	x21, x21, #0x550
    4054:	aa0003f6 	mov	x22, x0
    4058:	d2800020 	mov	x0, #0x1                   	// #1
    405c:	a90153f3 	stp	x19, x20, [sp, #16]
    4060:	a90363f7 	stp	x23, x24, [sp, #48]
    4064:	2a0103f7 	mov	w23, w1
    4068:	2a0203f8 	mov	w24, w2
    406c:	97fffc11 	bl	30b0 <fwp_heap_chunks>
    4070:	aa0003f3 	mov	x19, x0
    4074:	f949fea2 	ldr	x2, [x21, #5112]
    4078:	8b000800 	add	x0, x0, x0, lsl #2
    407c:	2a1703e1 	mov	w1, w23
    4080:	52800025 	mov	w5, #0x1                   	// #1
    4084:	d37df000 	lsl	x0, x0, #3
    4088:	910f0021 	add	x1, x1, #0x3c0
    408c:	8b000054 	add	x20, x2, x0
    4090:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4094:	52a00024 	mov	w4, #0x10000               	// #65536
    4098:	38206845 	strb	w5, [x2, x0]
    409c:	aa1403e0 	mov	x0, x20
    40a0:	39000698 	strb	w24, [x20, #1]
    40a4:	39000a97 	strb	w23, [x20, #2]
    40a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    40ac:	b9000681 	str	w1, [x20, #4]
    40b0:	2a0103e5 	mov	w5, w1
    40b4:	8b0300a2 	add	x2, x5, x3
    40b8:	1ac10881 	udiv	w1, w4, w1
    40bc:	9ac50842 	udiv	x2, x2, x5
    40c0:	b9000a81 	str	w1, [x20, #8]
    40c4:	92404021 	and	x1, x1, #0x1ffff
    40c8:	b9001a82 	str	w2, [x20, #24]
    40cc:	97ffff95 	bl	3f20 <fwp_rc_prepare_chunk>
    40d0:	f949daa0 	ldr	x0, [x21, #5040]
    40d4:	29408a81 	ldp	w1, w2, [x20, #4]
    40d8:	8b134000 	add	x0, x0, x19, lsl #16
    40dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e0:	8b214003 	add	x3, x0, w1, uxtw
    40e4:	9ba20021 	umaddl	x1, w1, w2, x0
    40e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40ec:	a90086c3 	stp	x3, x1, [x22, #8]
    40f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40f8:	d65f03c0 	ret
    40fc:	d503201f 	nop

0000000000004100 <fwp_mem_free>:
    4100:	b40003c0 	cbz	x0, 4178 <fwp_mem_free+0x78>
    4104:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4108:	910003fd 	mov	x29, sp
    410c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4110:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4114:	911542a1 	add	x1, x21, #0x550
    4118:	a90153f3 	stp	x19, x20, [sp, #16]
    411c:	aa0003f3 	mov	x19, x0
    4120:	f949d823 	ldr	x3, [x1, #5040]
    4124:	f949ec22 	ldr	x2, [x1, #5080]
    4128:	cb030000 	sub	x0, x0, x3
    412c:	eb02401f 	cmp	x0, x2, lsl #16
    4130:	540001c2 	b.cs	4168 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4134:	d350fc16 	lsr	x22, x0, #16
    4138:	a90363f7 	stp	x23, x24, [sp, #48]
    413c:	f949fc22 	ldr	x2, [x1, #5112]
    4140:	8b160ad4 	add	x20, x22, x22, lsl #2
    4144:	d37df294 	lsl	x20, x20, #3
    4148:	ab140057 	adds	x23, x2, x20
    414c:	540000c0 	b.eq	4164 <fwp_mem_free+0x64>  // b.none
    4150:	38746842 	ldrb	w2, [x2, x20]
    4154:	7100045f 	cmp	w2, #0x1
    4158:	54000120 	b.eq	417c <fwp_mem_free+0x7c>  // b.none
    415c:	7100085f 	cmp	w2, #0x2
    4160:	540005e0 	b.eq	421c <fwp_mem_free+0x11c>  // b.none
    4164:	a94363f7 	ldp	x23, x24, [sp, #48]
    4168:	a94153f3 	ldp	x19, x20, [sp, #16]
    416c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4170:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4174:	d65f03c0 	ret
    4178:	d65f03c0 	ret
    417c:	f94012f8 	ldr	x24, [x23, #32]
    4180:	b94006e1 	ldr	w1, [x23, #4]
    4184:	f90023f9 	str	x25, [sp, #64]
    4188:	2a0103e2 	mov	w2, w1
    418c:	394006f9 	ldrb	w25, [x23, #1]
    4190:	39400af4 	ldrb	w20, [x23, #2]
    4194:	b4000158 	cbz	x24, 41bc <fwp_mem_free+0xbc>
    4198:	92403e76 	and	x22, x19, #0xffff
    419c:	9ac20ad6 	udiv	x22, x22, x2
    41a0:	38766b01 	ldrb	w1, [x24, x22]
    41a4:	8b160300 	add	x0, x24, x22
    41a8:	7103fc3f 	cmp	w1, #0xff
    41ac:	54000980 	b.eq	42dc <fwp_mem_free+0x1dc>  // b.none
    41b0:	38366b1f 	strb	wzr, [x24, x22]
    41b4:	b94006e1 	ldr	w1, [x23, #4]
    41b8:	2a0103e2 	mov	w2, w1
    41bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41c4:	cb390000 	sub	x0, x0, w25, uxtb
    41c8:	8b340074 	add	x20, x3, w20, uxtb
    41cc:	911542b5 	add	x21, x21, #0x550
    41d0:	1e630021 	ucvtf	d1, w1
    41d4:	d37ae400 	lsl	x0, x0, #6
    41d8:	8b140c14 	add	x20, x0, x20, lsl #3
    41dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e0:	f8746aa0 	ldr	x0, [x21, x20]
    41e4:	f94023f9 	ldr	x25, [sp, #64]
    41e8:	aa2003e0 	mvn	x0, x0
    41ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    41f0:	f9000260 	str	x0, [x19]
    41f4:	f8346ab3 	str	x19, [x21, x20]
    41f8:	f94a12a0 	ldr	x0, [x21, #5152]
    41fc:	1e612800 	fadd	d0, d0, d1
    4200:	a94153f3 	ldp	x19, x20, [sp, #16]
    4204:	cb020000 	sub	x0, x0, x2
    4208:	f90a12a0 	str	x0, [x21, #5152]
    420c:	fd0a22a0 	str	d0, [x21, #5184]
    4210:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4214:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4218:	d65f03c0 	ret
    421c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4220:	8b000063 	add	x3, x3, x0
    4224:	eb03027f 	cmp	x19, x3
    4228:	54fff9e1 	b.ne	4164 <fwp_mem_free+0x64>  // b.any
    422c:	fd400ae1 	ldr	d1, [x23, #16]
    4230:	fd4a2020 	ldr	d0, [x1, #5184]
    4234:	f9400ae0 	ldr	x0, [x23, #16]
    4238:	7e61d821 	ucvtf	d1, d1
    423c:	f94a1022 	ldr	x2, [x1, #5152]
    4240:	f94012f3 	ldr	x19, [x23, #32]
    4244:	1e612800 	fadd	d0, d0, d1
    4248:	cb000042 	sub	x2, x2, x0
    424c:	f90a1022 	str	x2, [x1, #5152]
    4250:	fd0a2020 	str	d0, [x1, #5184]
    4254:	b40000b3 	cbz	x19, 4268 <fwp_mem_free+0x168>
    4258:	39400260 	ldrb	w0, [x19]
    425c:	7103fc1f 	cmp	w0, #0xff
    4260:	54000380 	b.eq	42d0 <fwp_mem_free+0x1d0>  // b.none
    4264:	3900027f 	strb	wzr, [x19]
    4268:	b9400ee2 	ldr	w2, [x23, #12]
    426c:	b4000142 	cbz	x2, 4294 <fwp_mem_free+0x194>
    4270:	911542a1 	add	x1, x21, #0x550
    4274:	8b160040 	add	x0, x2, x22
    4278:	8b000800 	add	x0, x0, x0, lsl #2
    427c:	f949fc21 	ldr	x1, [x1, #5112]
    4280:	8b140034 	add	x20, x1, x20
    4284:	8b000c20 	add	x0, x1, x0, lsl #3
    4288:	3802869f 	strb	wzr, [x20], #40
    428c:	eb00029f 	cmp	x20, x0
    4290:	54ffffc1 	b.ne	4288 <fwp_mem_free+0x188>  // b.any
    4294:	911542a0 	add	x0, x21, #0x550
    4298:	f94a1801 	ldr	x1, [x0, #5168]
    429c:	f949f803 	ldr	x3, [x0, #5104]
    42a0:	8b020021 	add	x1, x1, x2
    42a4:	f90a1801 	str	x1, [x0, #5168]
    42a8:	eb16007f 	cmp	x3, x22
    42ac:	54000049 	b.ls	42b4 <fwp_mem_free+0x1b4>  // b.plast
    42b0:	f909f816 	str	x22, [x0, #5104]
    42b4:	911542b5 	add	x21, x21, #0x550
    42b8:	f949f6a0 	ldr	x0, [x21, #5096]
    42bc:	eb16001f 	cmp	x0, x22
    42c0:	54fff529 	b.ls	4164 <fwp_mem_free+0x64>  // b.plast
    42c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42c8:	f909f6b6 	str	x22, [x21, #5096]
    42cc:	17ffffa7 	b	4168 <fwp_mem_free+0x68>
    42d0:	aa1303e0 	mov	x0, x19
    42d4:	97fffeef 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42d8:	17ffffe3 	b	4264 <fwp_mem_free+0x164>
    42dc:	97fffeed 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42e0:	17ffffb4 	b	41b0 <fwp_mem_free+0xb0>

00000000000042e4 <fwp_rc_wide_dup>:
    42e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42e8:	910003fd 	mov	x29, sp
    42ec:	a90153f3 	stp	x19, x20, [sp, #16]
    42f0:	aa0003f3 	mov	x19, x0
    42f4:	ca404400 	eor	x0, x0, x0, lsr #17
    42f8:	f90013f5 	str	x21, [sp, #32]
    42fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4300:	ca402400 	eor	x0, x0, x0, lsr #9
    4304:	911542a2 	add	x2, x21, #0x550
    4308:	92401c00 	and	x0, x0, #0xff
    430c:	910a2403 	add	x3, x0, #0x289
    4310:	8b000c40 	add	x0, x2, x0, lsl #3
    4314:	8b030c54 	add	x20, x2, x3, lsl #3
    4318:	f94a2401 	ldr	x1, [x0, #5192]
    431c:	b50000a1 	cbnz	x1, 4330 <fwp_rc_wide_dup+0x4c>
    4320:	14000033 	b	43ec <fwp_rc_wide_dup+0x108>
    4324:	91004034 	add	x20, x1, #0x10
    4328:	f9400821 	ldr	x1, [x1, #16]
    432c:	b4000241 	cbz	x1, 4374 <fwp_rc_wide_dup+0x90>
    4330:	f9400022 	ldr	x2, [x1]
    4334:	eb02027f 	cmp	x19, x2
    4338:	54ffff61 	b.ne	4324 <fwp_rc_wide_dup+0x40>  // b.any
    433c:	f9400281 	ldr	x1, [x20]
    4340:	39400260 	ldrb	w0, [x19]
    4344:	7103f81f 	cmp	w0, #0xfe
    4348:	54000220 	b.eq	438c <fwp_rc_wide_dup+0xa8>  // b.none
    434c:	b40001a1 	cbz	x1, 4380 <fwp_rc_wide_dup+0x9c>
    4350:	f9400420 	ldr	x0, [x1, #8]
    4354:	b100041f 	cmn	x0, #0x1
    4358:	54000440 	b.eq	43e0 <fwp_rc_wide_dup+0xfc>  // b.none
    435c:	91000400 	add	x0, x0, #0x1
    4360:	f9000420 	str	x0, [x1, #8]
    4364:	a94153f3 	ldp	x19, x20, [sp, #16]
    4368:	f94013f5 	ldr	x21, [sp, #32]
    436c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4370:	d65f03c0 	ret
    4374:	39400260 	ldrb	w0, [x19]
    4378:	7103f81f 	cmp	w0, #0xfe
    437c:	54000100 	b.eq	439c <fwp_rc_wide_dup+0xb8>  // b.none
    4380:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    4384:	91240000 	add	x0, x0, #0x900
    4388:	97fffea2 	bl	3e10 <fwp_trap>
    438c:	b4000081 	cbz	x1, 439c <fwp_rc_wide_dup+0xb8>
    4390:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    4394:	9124a000 	add	x0, x0, #0x928
    4398:	97fffe9e 	bl	3e10 <fwp_trap>
    439c:	d2800300 	mov	x0, #0x18                  	// #24
    43a0:	97fff8fc 	bl	2790 <malloc@plt>
    43a4:	b4000280 	cbz	x0, 43f4 <fwp_rc_wide_dup+0x110>
    43a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    43ac:	a9000413 	stp	x19, x1, [x0]
    43b0:	911542b5 	add	x21, x21, #0x550
    43b4:	f900081f 	str	xzr, [x0, #16]
    43b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43bc:	f9000280 	str	x0, [x20]
    43c0:	39000261 	strb	w1, [x19]
    43c4:	f94e26a0 	ldr	x0, [x21, #7240]
    43c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43cc:	91000400 	add	x0, x0, #0x1
    43d0:	f90e26a0 	str	x0, [x21, #7240]
    43d4:	f94013f5 	ldr	x21, [sp, #32]
    43d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43dc:	d65f03c0 	ret
    43e0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    43e4:	91254000 	add	x0, x0, #0x950
    43e8:	97fffe8a 	bl	3e10 <fwp_trap>
    43ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43f0:	17ffffd4 	b	4340 <fwp_rc_wide_dup+0x5c>
    43f4:	97fffaef 	bl	2fb0 <fwp_heap_oom>
    43f8:	d503201f 	nop
    43fc:	d503201f 	nop

0000000000004400 <fwp_closure_drop_push>:
    4400:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	a9408014 	ldp	x20, x0, [x0, #8]
    4414:	a9025bf5 	stp	x21, x22, [sp, #32]
    4418:	aa0103f5 	mov	x21, x1
    441c:	a90363f7 	stp	x23, x24, [sp, #48]
    4420:	eb00029f 	cmp	x20, x0
    4424:	54000160 	b.eq	4450 <fwp_closure_drop_push+0x50>  // b.none
    4428:	f9400276 	ldr	x22, [x19]
    442c:	d37df297 	lsl	x23, x20, #3
    4430:	91000694 	add	x20, x20, #0x1
    4434:	f9000674 	str	x20, [x19, #8]
    4438:	a94153f3 	ldp	x19, x20, [sp, #16]
    443c:	f8376ad5 	str	x21, [x22, x23]
    4440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4444:	a94363f7 	ldp	x23, x24, [sp, #48]
    4448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    444c:	d65f03c0 	ret
    4450:	a9046bf9 	stp	x25, x26, [sp, #64]
    4454:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4458:	eb00029f 	cmp	x20, x0
    445c:	540003e8 	b.hi	44d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4460:	d37cee99 	lsl	x25, x20, #4
    4464:	d37ffa9a 	lsl	x26, x20, #1
    4468:	aa1903e0 	mov	x0, x25
    446c:	97fff8c9 	bl	2790 <malloc@plt>
    4470:	aa0003f6 	mov	x22, x0
    4474:	b4000380 	cbz	x0, 44e4 <fwp_closure_drop_push+0xe4>
    4478:	aa1303f8 	mov	x24, x19
    447c:	aa1903e3 	mov	x3, x25
    4480:	d37df297 	lsl	x23, x20, #3
    4484:	aa1703e2 	mov	x2, x23
    4488:	f8418719 	ldr	x25, [x24], #24
    448c:	aa1903e1 	mov	x1, x25
    4490:	97fff8ac 	bl	2740 <__memcpy_chk@plt>
    4494:	eb18033f 	cmp	x25, x24
    4498:	540000a0 	b.eq	44ac <fwp_closure_drop_push+0xac>  // b.none
    449c:	aa1903e0 	mov	x0, x25
    44a0:	97fff904 	bl	28b0 <free@plt>
    44a4:	f9400674 	ldr	x20, [x19, #8]
    44a8:	d37df297 	lsl	x23, x20, #3
    44ac:	91000694 	add	x20, x20, #0x1
    44b0:	f9000276 	str	x22, [x19]
    44b4:	f9000a7a 	str	x26, [x19, #16]
    44b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44bc:	f9000674 	str	x20, [x19, #8]
    44c0:	f8376ad5 	str	x21, [x22, x23]
    44c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44d4:	d65f03c0 	ret
    44d8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    44dc:	9125c000 	add	x0, x0, #0x970
    44e0:	97fffe4c 	bl	3e10 <fwp_trap>
    44e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    44e8:	f947e863 	ldr	x3, [x3, #4048]
    44ec:	d2800262 	mov	x2, #0x13                  	// #19
    44f0:	d2800021 	mov	x1, #0x1                   	// #1
    44f4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    44f8:	911f2000 	add	x0, x0, #0x7c8
    44fc:	f9400063 	ldr	x3, [x3]
    4500:	97fff8fc 	bl	28f0 <fwrite@plt>
    4504:	d2800000 	mov	x0, #0x0                   	// #0
    4508:	97fff906 	bl	2920 <fflush@plt>
    450c:	52800cc0 	mov	w0, #0x66                  	// #102
    4510:	97fff914 	bl	2960 <_Exit@plt>

0000000000004514 <fwp_closure_drop.part.0>:
    4514:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4518:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x840>
    451c:	910003fd 	mov	x29, sp
    4520:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4524:	f947f463 	ldr	x3, [x3, #4072]
    4528:	a90153f3 	stp	x19, x20, [sp, #16]
    452c:	d10883ff 	sub	sp, sp, #0x220
    4530:	910003e2 	mov	x2, sp
    4534:	d53bd053 	mrs	x19, tpidr_el0
    4538:	910063f4 	add	x20, sp, #0x18
    453c:	3dc11c20 	ldr	q0, [x1, #1136]
    4540:	91400264 	add	x4, x19, #0x0, lsl #12
    4544:	91004084 	add	x4, x4, #0x10
    4548:	aa0003e1 	mov	x1, x0
    454c:	aa0203e0 	mov	x0, x2
    4550:	f9400062 	ldr	x2, [x3]
    4554:	f9010fe2 	str	x2, [sp, #536]
    4558:	d2800002 	mov	x2, #0x0                   	// #0
    455c:	f90003f4 	str	x20, [sp]
    4560:	f9000080 	str	x0, [x4]
    4564:	3c8083e0 	stur	q0, [sp, #8]
    4568:	97ffffa6 	bl	4400 <fwp_closure_drop_push>
    456c:	f94007e0 	ldr	x0, [sp, #8]
    4570:	b40002e0 	cbz	x0, 45cc <fwp_closure_drop.part.0+0xb8>
    4574:	f90123f5 	str	x21, [sp, #576]
    4578:	900000f5 	adrp	x21, 20000 <__data_start>
    457c:	910102b5 	add	x21, x21, #0x40
    4580:	14000006 	b	4598 <fwp_closure_drop.part.0+0x84>
    4584:	f9400422 	ldr	x2, [x1, #8]
    4588:	52800001 	mov	w1, #0x0                   	// #0
    458c:	d63f0040 	blr	x2
    4590:	f94007e0 	ldr	x0, [sp, #8]
    4594:	b40001a0 	cbz	x0, 45c8 <fwp_closure_drop.part.0+0xb4>
    4598:	f94003e1 	ldr	x1, [sp]
    459c:	d1000400 	sub	x0, x0, #0x1
    45a0:	f90007e0 	str	x0, [sp, #8]
    45a4:	f9403ea2 	ldr	x2, [x21, #120]
    45a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    45ac:	b9400001 	ldr	w1, [x0]
    45b0:	8b011441 	add	x1, x2, x1, lsl #5
    45b4:	f9400c21 	ldr	x1, [x1, #24]
    45b8:	b5fffe61 	cbnz	x1, 4584 <fwp_closure_drop.part.0+0x70>
    45bc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    45c0:	91264000 	add	x0, x0, #0x990
    45c4:	97fffe13 	bl	3e10 <fwp_trap>
    45c8:	f94123f5 	ldr	x21, [sp, #576]
    45cc:	91400273 	add	x19, x19, #0x0, lsl #12
    45d0:	91004273 	add	x19, x19, #0x10
    45d4:	f94003e0 	ldr	x0, [sp]
    45d8:	f900027f 	str	xzr, [x19]
    45dc:	eb14001f 	cmp	x0, x20
    45e0:	54000040 	b.eq	45e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45e4:	97fff8b3 	bl	28b0 <free@plt>
    45e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45ec:	f947f400 	ldr	x0, [x0, #4072]
    45f0:	f9410fe2 	ldr	x2, [sp, #536]
    45f4:	f9400001 	ldr	x1, [x0]
    45f8:	eb010042 	subs	x2, x2, x1
    45fc:	d2800001 	mov	x1, #0x0                   	// #0
    4600:	540000a1 	b.ne	4614 <fwp_closure_drop.part.0+0x100>  // b.any
    4604:	910883ff 	add	sp, sp, #0x220
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4610:	d65f03c0 	ret
    4614:	f90123f5 	str	x21, [sp, #576]
    4618:	97fff876 	bl	27f0 <__stack_chk_fail@plt>
    461c:	d503201f 	nop

0000000000004620 <fwp_tape_of>:
    4620:	aa0003e1 	mov	x1, x0
    4624:	92403c00 	and	x0, x0, #0xffff
    4628:	b40000e0 	cbz	x0, 4644 <fwp_tape_of+0x24>
    462c:	d1000402 	sub	x2, x0, #0x1
    4630:	900000e3 	adrp	x3, 20000 <__data_start>
    4634:	91010060 	add	x0, x3, #0x40
    4638:	f9404000 	ldr	x0, [x0, #128]
    463c:	eb02001f 	cmp	x0, x2
    4640:	540000cc 	b.gt	4658 <fwp_tape_of+0x38>
    4644:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4648:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    464c:	91270000 	add	x0, x0, #0x9c0
    4650:	910003fd 	mov	x29, sp
    4654:	97fffdef 	bl	3e10 <fwp_trap>
    4658:	8b020440 	add	x0, x2, x2, lsl #1
    465c:	f9402063 	ldr	x3, [x3, #64]
    4660:	8b000842 	add	x2, x2, x0, lsl #2
    4664:	d37df042 	lsl	x2, x2, #3
    4668:	8b020060 	add	x0, x3, x2
    466c:	b9400404 	ldr	w4, [x0, #4]
    4670:	34fffea4 	cbz	w4, 4644 <fwp_tape_of+0x24>
    4674:	b8626862 	ldr	w2, [x3, x2]
    4678:	9350fc21 	asr	x1, x1, #16
    467c:	6b01005f 	cmp	w2, w1
    4680:	54fffe21 	b.ne	4644 <fwp_tape_of+0x24>  // b.any
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_now_ns>:
    4690:	d100c3ff 	sub	sp, sp, #0x30
    4694:	52800020 	mov	w0, #0x1                   	// #1
    4698:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    469c:	f947f442 	ldr	x2, [x2, #4072]
    46a0:	910023e1 	add	x1, sp, #0x8
    46a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a8:	910083fd 	add	x29, sp, #0x20
    46ac:	f9400043 	ldr	x3, [x2]
    46b0:	f9000fe3 	str	x3, [sp, #24]
    46b4:	d2800003 	mov	x3, #0x0                   	// #0
    46b8:	97fff81a 	bl	2720 <clock_gettime@plt>
    46bc:	350002c0 	cbnz	w0, 4714 <fwp_now_ns+0x84>
    46c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46c4:	d2994003 	mov	x3, #0xca00                	// #51712
    46c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46cc:	9b037c20 	mul	x0, x1, x3
    46d0:	9b437c21 	smulh	x1, x1, x3
    46d4:	ab020000 	adds	x0, x0, x2
    46d8:	937ffc42 	asr	x2, x2, #63
    46dc:	9a020021 	adc	x1, x1, x2
    46e0:	f100001f 	cmp	x0, #0x0
    46e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46e8:	b50001c1 	cbnz	x1, 4720 <fwp_now_ns+0x90>
    46ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    46f0:	f947f421 	ldr	x1, [x1, #4072]
    46f4:	f9400fe3 	ldr	x3, [sp, #24]
    46f8:	f9400022 	ldr	x2, [x1]
    46fc:	eb020063 	subs	x3, x3, x2
    4700:	d2800002 	mov	x2, #0x0                   	// #0
    4704:	54000141 	b.ne	472c <fwp_now_ns+0x9c>  // b.any
    4708:	a9427bfd 	ldp	x29, x30, [sp, #32]
    470c:	9100c3ff 	add	sp, sp, #0x30
    4710:	d65f03c0 	ret
    4714:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    4718:	91284000 	add	x0, x0, #0xa10
    471c:	97fffdbd 	bl	3e10 <fwp_trap>
    4720:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    4724:	9128c000 	add	x0, x0, #0xa30
    4728:	97fffdba 	bl	3e10 <fwp_trap>
    472c:	97fff831 	bl	27f0 <__stack_chk_fail@plt>

0000000000004730 <fwp_poll_events>:
    4730:	d10103ff 	sub	sp, sp, #0x40
    4734:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4738:	f947f400 	ldr	x0, [x0, #4072]
    473c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4740:	910083fd 	add	x29, sp, #0x20
    4744:	f9001bf3 	str	x19, [sp, #48]
    4748:	900000f3 	adrp	x19, 20000 <__data_start>
    474c:	f9400001 	ldr	x1, [x0]
    4750:	f9000fe1 	str	x1, [sp, #24]
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	97ffffce 	bl	4690 <fwp_now_ns>
    475c:	91010261 	add	x1, x19, #0x40
    4760:	f9404421 	ldr	x1, [x1, #136]
    4764:	b4000e01 	cbz	x1, 4924 <fwp_poll_events+0x1f4>
    4768:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    476c:	14000005 	b	4780 <fwp_poll_events+0x50>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	eb03005f 	cmp	x2, x3
    4778:	9a83d042 	csel	x2, x2, x3, le
    477c:	b40000c1 	cbz	x1, 4794 <fwp_poll_events+0x64>
    4780:	f9403423 	ldr	x3, [x1, #104]
    4784:	b6ffff62 	tbz	x2, #63, 4770 <fwp_poll_events+0x40>
    4788:	f9408821 	ldr	x1, [x1, #272]
    478c:	aa0303e2 	mov	x2, x3
    4790:	b5ffff81 	cbnz	x1, 4780 <fwp_poll_events+0x50>
    4794:	b7f80c82 	tbnz	x2, #63, 4924 <fwp_poll_events+0x1f4>
    4798:	cb000042 	sub	x2, x2, x0
    479c:	f100005f 	cmp	x2, #0x0
    47a0:	540003ad 	b.le	4814 <fwp_poll_events+0xe4>
    47a4:	d2869b60 	mov	x0, #0x34db                	// #13531
    47a8:	d2884804 	mov	x4, #0x4240                	// #16960
    47ac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47b0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47b4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47b8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47bc:	f2e86360 	movk	x0, #0x431b, lsl #48
    47c0:	9b407c40 	smulh	x0, x2, x0
    47c4:	9352fc00 	asr	x0, x0, #18
    47c8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47cc:	9b048802 	msub	x2, x0, x4, x2
    47d0:	f100005f 	cmp	x2, #0x0
    47d4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47d8:	eb01001f 	cmp	x0, x1
    47dc:	5400098c 	b.gt	490c <fwp_poll_events+0x1dc>
    47e0:	340001a0 	cbz	w0, 4814 <fwp_poll_events+0xe4>
    47e4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47e8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47ec:	72a20c41 	movk	w1, #0x1062, lsl #16
    47f0:	9ba17c01 	umull	x1, w0, w1
    47f4:	d366fc23 	lsr	x3, x1, #38
    47f8:	aa0303e2 	mov	x2, x3
    47fc:	1b058063 	msub	w3, w3, w5, w0
    4800:	9b247c63 	smull	x3, w3, w4
    4804:	910023e0 	add	x0, sp, #0x8
    4808:	d2800001 	mov	x1, #0x0                   	// #0
    480c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4810:	97fff82c 	bl	28c0 <nanosleep@plt>
    4814:	97ffff9f 	bl	4690 <fwp_now_ns>
    4818:	91010268 	add	x8, x19, #0x40
    481c:	aa0003e7 	mov	x7, x0
    4820:	4f000400 	movi	v0.4s, #0x0
    4824:	52800029 	mov	w9, #0x1                   	// #1
    4828:	f9404506 	ldr	x6, [x8, #136]
    482c:	d503201f 	nop
    4830:	b40003e6 	cbz	x6, 48ac <fwp_poll_events+0x17c>
    4834:	f94034c1 	ldr	x1, [x6, #104]
    4838:	aa0603e5 	mov	x5, x6
    483c:	f94088c6 	ldr	x6, [x6, #272]
    4840:	eb07003f 	cmp	x1, x7
    4844:	54ffff6c 	b.gt	4830 <fwp_poll_events+0x100>
    4848:	394154a0 	ldrb	w0, [x5, #85]
    484c:	36000120 	tbz	w0, #0, 4870 <fwp_poll_events+0x140>
    4850:	f94084a0 	ldr	x0, [x5, #264]
    4854:	b4000560 	cbz	x0, 4900 <fwp_poll_events+0x1d0>
    4858:	f9008806 	str	x6, [x0, #272]
    485c:	b4000046 	cbz	x6, 4864 <fwp_poll_events+0x134>
    4860:	f90084c0 	str	x0, [x6, #264]
    4864:	910800a0 	add	x0, x5, #0x200
    4868:	390154bf 	strb	wzr, [x5, #85]
    486c:	3c908000 	stur	q0, [x0, #-248]
    4870:	f94030a0 	ldr	x0, [x5, #96]
    4874:	390158a9 	strb	w9, [x5, #86]
    4878:	f100001f 	cmp	x0, #0x0
    487c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4880:	540002cd 	b.le	48d8 <fwp_poll_events+0x1a8>
    4884:	f94028a0 	ldr	x0, [x5, #80]
    4888:	f2001c1f 	tst	x0, #0xff000000ff
    488c:	54fffd21 	b.ne	4830 <fwp_poll_events+0x100>  // b.any
    4890:	f9401500 	ldr	x0, [x8, #40]
    4894:	390150a9 	strb	w9, [x5, #84]
    4898:	f90080bf 	str	xzr, [x5, #256]
    489c:	b40002c0 	cbz	x0, 48f4 <fwp_poll_events+0x1c4>
    48a0:	f9001505 	str	x5, [x8, #40]
    48a4:	f9008005 	str	x5, [x0, #256]
    48a8:	b5fffc66 	cbnz	x6, 4834 <fwp_poll_events+0x104>
    48ac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48b0:	f947f400 	ldr	x0, [x0, #4072]
    48b4:	f9400fe2 	ldr	x2, [sp, #24]
    48b8:	f9400001 	ldr	x1, [x0]
    48bc:	eb010042 	subs	x2, x2, x1
    48c0:	d2800001 	mov	x1, #0x0                   	// #0
    48c4:	540002e1 	b.ne	4920 <fwp_poll_events+0x1f0>  // b.any
    48c8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48cc:	f9401bf3 	ldr	x19, [sp, #48]
    48d0:	910103ff 	add	sp, sp, #0x40
    48d4:	d65f03c0 	ret
    48d8:	394144a0 	ldrb	w0, [x5, #81]
    48dc:	3707fd40 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e0:	394140a0 	ldrb	w0, [x5, #80]
    48e4:	3707fd00 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e8:	aa0503e0 	mov	x0, x5
    48ec:	97fffac1 	bl	33f0 <fwp_cancel_tree.part.0>
    48f0:	17ffffe5 	b	4884 <fwp_poll_events+0x154>
    48f4:	f9001505 	str	x5, [x8, #40]
    48f8:	f9001905 	str	x5, [x8, #48]
    48fc:	17ffffeb 	b	48a8 <fwp_poll_events+0x178>
    4900:	91010261 	add	x1, x19, #0x40
    4904:	f9004426 	str	x6, [x1, #136]
    4908:	17ffffd5 	b	485c <fwp_poll_events+0x12c>
    490c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4910:	d2989362 	mov	x2, #0xc49b                	// #50331
    4914:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4918:	f2a00402 	movk	x2, #0x20, lsl #16
    491c:	17ffffba 	b	4804 <fwp_poll_events+0xd4>
    4920:	97fff7b4 	bl	27f0 <__stack_chk_fail@plt>
    4924:	97fff993 	bl	2f70 <fwp_flush>
    4928:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    492c:	f947e863 	ldr	x3, [x3, #4048]
    4930:	d2800562 	mov	x2, #0x2b                  	// #43
    4934:	d2800021 	mov	x1, #0x1                   	// #1
    4938:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    493c:	91296000 	add	x0, x0, #0xa58
    4940:	f9400063 	ldr	x3, [x3]
    4944:	97fff7eb 	bl	28f0 <fwrite@plt>
    4948:	52800ca0 	mov	w0, #0x65                  	// #101
    494c:	97fff755 	bl	26a0 <exit@plt>

0000000000004950 <fwp_heap_alloc_big>:
    4950:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4954:	910003fd 	mov	x29, sp
    4958:	a90153f3 	stp	x19, x20, [sp, #16]
    495c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4960:	a90363f7 	stp	x23, x24, [sp, #48]
    4964:	aa0003f7 	mov	x23, x0
    4968:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    496c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4970:	eb0002ff 	cmp	x23, x0
    4974:	540008a8 	b.hi	4a88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4978:	d29fffe0 	mov	x0, #0xffff                	// #65535
    497c:	8b0002f4 	add	x20, x23, x0
    4980:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4984:	91154359 	add	x25, x26, #0x550
    4988:	d350fe94 	lsr	x20, x20, #16
    498c:	2a0103f5 	mov	w21, w1
    4990:	aa1403e0 	mov	x0, x20
    4994:	97fff9c7 	bl	30b0 <fwp_heap_chunks>
    4998:	f949ff22 	ldr	x2, [x25, #5112]
    499c:	8b000813 	add	x19, x0, x0, lsl #2
    49a0:	aa0003f8 	mov	x24, x0
    49a4:	52800043 	mov	w3, #0x2                   	// #2
    49a8:	d37df273 	lsl	x19, x19, #3
    49ac:	d2800021 	mov	x1, #0x1                   	// #1
    49b0:	8b130040 	add	x0, x2, x19
    49b4:	38336843 	strb	w3, [x2, x19]
    49b8:	39000415 	strb	w21, [x0, #1]
    49bc:	b9000c14 	str	w20, [x0, #12]
    49c0:	f9000817 	str	x23, [x0, #16]
    49c4:	97fffd57 	bl	3f20 <fwp_rc_prepare_chunk>
    49c8:	f100069f 	cmp	x20, #0x1
    49cc:	54000289 	b.ls	4a1c <fwp_heap_alloc_big+0xcc>  // b.plast
    49d0:	8b180294 	add	x20, x20, x24
    49d4:	9100a273 	add	x19, x19, #0x28
    49d8:	a90573fb 	stp	x27, x28, [sp, #80]
    49dc:	5280007b 	mov	w27, #0x3                   	// #3
    49e0:	8b140a94 	add	x20, x20, x20, lsl #2
    49e4:	2a1803fc 	mov	w28, w24
    49e8:	9adb2296 	lsl	x22, x20, x27
    49ec:	d503201f 	nop
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffd48 	bl	3f20 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x108>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffbbf 	bl	3a70 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff6f 	b	4950 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffd19 	bl	4040 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9403ee0 	ldr	x0, [x23, #120]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_tape_grow.constprop.0>:
    4f24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4f28:	d2800803 	mov	x3, #0x40                  	// #64
    4f2c:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f30:	910003fd 	mov	x29, sp
    4f34:	a90153f3 	stp	x19, x20, [sp, #16]
    4f38:	f9400c13 	ldr	x19, [x0, #24]
    4f3c:	a90363f7 	stp	x23, x24, [sp, #48]
    4f40:	aa0003f7 	mov	x23, x0
    4f44:	f100027f 	cmp	x19, #0x0
    4f48:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    4f4c:	eb13003f 	cmp	x1, x19
    4f50:	540000ed 	b.le	4f6c <fwp_tape_grow.constprop.0+0x48>
    4f54:	eb02027f 	cmp	x19, x2
    4f58:	5400076d 	b.le	5044 <fwp_tape_grow.constprop.0+0x120>
    4f5c:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4f60:	eb13003f 	cmp	x1, x19
    4f64:	5400004d 	b.le	4f6c <fwp_tape_grow.constprop.0+0x48>
    4f68:	14000000 	b	4f68 <fwp_tape_grow.constprop.0+0x44>
    4f6c:	a940d2e2 	ldp	x2, x20, [x23, #8]
    4f70:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f74:	d37df276 	lsl	x22, x19, #3
    4f78:	f94012e0 	ldr	x0, [x23, #32]
    4f7c:	aa1603e1 	mov	x1, x22
    4f80:	f94032f5 	ldr	x21, [x23, #96]
    4f84:	cb020294 	sub	x20, x20, x2
    4f88:	97fff616 	bl	27e0 <realloc@plt>
    4f8c:	b4000c20 	cbz	x0, 5110 <fwp_tape_grow.constprop.0+0x1ec>
    4f90:	f9400ee1 	ldr	x1, [x23, #24]
    4f94:	8b010801 	add	x1, x0, x1, lsl #2
    4f98:	a90206e0 	stp	x0, x1, [x23, #32]
    4f9c:	b4000895 	cbz	x21, 50ac <fwp_tape_grow.constprop.0+0x188>
    4fa0:	f94032b6 	ldr	x22, [x21, #96]
    4fa4:	eb1302df 	cmp	x22, x19
    4fa8:	540003aa 	b.ge	501c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    4fac:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4fb4:	eb00027f 	cmp	x19, x0
    4fb8:	54000a68 	b.hi	5104 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    4fbc:	f94022b9 	ldr	x25, [x21, #64]
    4fc0:	d37cee7a 	lsl	x26, x19, #4
    4fc4:	aa1a03e0 	mov	x0, x26
    4fc8:	52800041 	mov	w1, #0x2                   	// #2
    4fcc:	97ffff09 	bl	4bf0 <fwp_heap_alloc>
    4fd0:	aa0003f8 	mov	x24, x0
    4fd4:	b4000119 	cbz	x25, 4ff4 <fwp_tape_grow.constprop.0+0xd0>
    4fd8:	d37ceed6 	lsl	x22, x22, #4
    4fdc:	aa1903e1 	mov	x1, x25
    4fe0:	eb1a02df 	cmp	x22, x26
    4fe4:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    4fe8:	97fff596 	bl	2640 <memcpy@plt>
    4fec:	aa1903e0 	mov	x0, x25
    4ff0:	97fffc44 	bl	4100 <fwp_mem_free>
    4ff4:	f94032a0 	ldr	x0, [x21, #96]
    4ff8:	52800001 	mov	w1, #0x0                   	// #0
    4ffc:	cb000262 	sub	x2, x19, x0
    5000:	8b001300 	add	x0, x24, x0, lsl #4
    5004:	d37cec42 	lsl	x2, x2, #4
    5008:	97fff5ee 	bl	27c0 <memset@plt>
    500c:	f94012e0 	ldr	x0, [x23, #32]
    5010:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5014:	f90022b8 	str	x24, [x21, #64]
    5018:	f90032b3 	str	x19, [x21, #96]
    501c:	d37ef675 	lsl	x21, x19, #2
    5020:	b50002b4 	cbnz	x20, 5074 <fwp_tape_grow.constprop.0+0x150>
    5024:	8b150001 	add	x1, x0, x21
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000ef3 	str	x19, [x23, #24]
    5030:	f90016e1 	str	x1, [x23, #40]
    5034:	a94153f3 	ldp	x19, x20, [sp, #16]
    5038:	a94363f7 	ldp	x23, x24, [sp, #48]
    503c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5040:	d65f03c0 	ret
    5044:	d37ffa73 	lsl	x19, x19, #1
    5048:	17ffffc1 	b	4f4c <fwp_tape_grow.constprop.0+0x28>
    504c:	eb1502df 	cmp	x22, x21
    5050:	aa0403e0 	mov	x0, x4
    5054:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    5058:	d37df282 	lsl	x2, x20, #3
    505c:	cb160063 	sub	x3, x3, x22
    5060:	97fff64c 	bl	2990 <__memmove_chk@plt>
    5064:	f9401ae1 	ldr	x1, [x23, #48]
    5068:	f94012e0 	ldr	x0, [x23, #32]
    506c:	8b160021 	add	x1, x1, x22
    5070:	f9001ee1 	str	x1, [x23, #56]
    5074:	f94016e1 	ldr	x1, [x23, #40]
    5078:	d37ef675 	lsl	x21, x19, #2
    507c:	d37ef682 	lsl	x2, x20, #2
    5080:	8b150000 	add	x0, x0, x21
    5084:	97fff577 	bl	2660 <memmove@plt>
    5088:	f94012e0 	ldr	x0, [x23, #32]
    508c:	8b150001 	add	x1, x0, x21
    5090:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5094:	f9000ef3 	str	x19, [x23, #24]
    5098:	f90016e1 	str	x1, [x23, #40]
    509c:	a94153f3 	ldp	x19, x20, [sp, #16]
    50a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    50a4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    50a8:	d65f03c0 	ret
    50ac:	f9401ae0 	ldr	x0, [x23, #48]
    50b0:	d37cee75 	lsl	x21, x19, #4
    50b4:	aa1503e1 	mov	x1, x21
    50b8:	97fff5ca 	bl	27e0 <realloc@plt>
    50bc:	b40002a0 	cbz	x0, 5110 <fwp_tape_grow.constprop.0+0x1ec>
    50c0:	f9400ee2 	ldr	x2, [x23, #24]
    50c4:	f9001ae0 	str	x0, [x23, #48]
    50c8:	8b160004 	add	x4, x0, x22
    50cc:	8b020c01 	add	x1, x0, x2, lsl #3
    50d0:	f9001ee1 	str	x1, [x23, #56]
    50d4:	b5fffbd4 	cbnz	x20, 504c <fwp_tape_grow.constprop.0+0x128>
    50d8:	f94012e0 	ldr	x0, [x23, #32]
    50dc:	d37ef675 	lsl	x21, x19, #2
    50e0:	f9001ee4 	str	x4, [x23, #56]
    50e4:	8b150001 	add	x1, x0, x21
    50e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50ec:	f9000ef3 	str	x19, [x23, #24]
    50f0:	f90016e1 	str	x1, [x23, #40]
    50f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5100:	d65f03c0 	ret
    5104:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    5108:	912ac000 	add	x0, x0, #0xab0
    510c:	97fffb41 	bl	3e10 <fwp_trap>
    5110:	aa1703e0 	mov	x0, x23
    5114:	a9046bf9 	stp	x25, x26, [sp, #64]
    5118:	97fff77e 	bl	2f10 <fwp_tape_unlink_scope>
    511c:	f94012e0 	ldr	x0, [x23, #32]
    5120:	97fff5e4 	bl	28b0 <free@plt>
    5124:	f9401ae0 	ldr	x0, [x23, #48]
    5128:	97fff5e2 	bl	28b0 <free@plt>
    512c:	f94022e0 	ldr	x0, [x23, #64]
    5130:	97fff5e0 	bl	28b0 <free@plt>
    5134:	f9000eff 	str	xzr, [x23, #24]
    5138:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    513c:	f947e821 	ldr	x1, [x1, #4048]
    5140:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5144:	d2800262 	mov	x2, #0x13                  	// #19
    5148:	4f000400 	movi	v0.4s, #0x0
    514c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    5150:	f9400023 	ldr	x3, [x1]
    5154:	b90006ff 	str	wzr, [x23, #4]
    5158:	d2800021 	mov	x1, #0x1                   	// #1
    515c:	911f2000 	add	x0, x0, #0x7c8
    5160:	3c8082e0 	stur	q0, [x23, #8]
    5164:	ad0102e0 	stp	q0, q0, [x23, #32]
    5168:	97fff5e2 	bl	28f0 <fwrite@plt>
    516c:	d2800000 	mov	x0, #0x0                   	// #0
    5170:	97fff5ec 	bl	2920 <fflush@plt>
    5174:	52800cc0 	mov	w0, #0x66                  	// #102
    5178:	97fff5fa 	bl	2960 <_Exit@plt>
    517c:	d503201f 	nop

0000000000005180 <f128.constprop.0>:
    5180:	f100001f 	cmp	x0, #0x0
    5184:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5188:	54000a2b 	b.lt	52cc <f128.constprop.0+0x14c>  // b.tstop
    518c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5190:	aa0003e2 	mov	x2, x0
    5194:	910003fd 	mov	x29, sp
    5198:	a90153f3 	stp	x19, x20, [sp, #16]
    519c:	aa0003f4 	mov	x20, x0
    51a0:	aa010000 	orr	x0, x0, x1
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	aa0103f6 	mov	x22, x1
    51ac:	f9001bf7 	str	x23, [sp, #48]
    51b0:	fd001fe8 	str	d8, [sp, #56]
    51b4:	b7f80180 	tbnz	x0, #63, 51e4 <f128.constprop.0+0x64>
    51b8:	9360fc20 	asr	x0, x1, #32
    51bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51c0:	eb82801f 	cmp	x0, x2, asr #32
    51c4:	54000881 	b.ne	52d4 <f128.constprop.0+0x154>  // b.any
    51c8:	97fffd16 	bl	4620 <fwp_tape_of>
    51cc:	aa0003f3 	mov	x19, x0
    51d0:	f9403000 	ldr	x0, [x0, #96]
    51d4:	b40001e0 	cbz	x0, 5210 <f128.constprop.0+0x90>
    51d8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    51dc:	912c6000 	add	x0, x0, #0xb18
    51e0:	97fffb0c 	bl	3e10 <fwp_trap>
    51e4:	9360fc40 	asr	x0, x2, #32
    51e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51ec:	b6fffee2 	tbz	x2, #63, 51c8 <f128.constprop.0+0x48>
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc20 	asr	x0, x1, #32
    51f8:	aa0103f4 	mov	x20, x1
    51fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5200:	97fffd08 	bl	4620 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5fffe60 	cbnz	x0, 51d8 <f128.constprop.0+0x58>
    5210:	f9400a77 	ldr	x23, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002ff 	cmp	x23, x0
    521c:	5400046c 	b.gt	52a8 <f128.constprop.0+0x128>
    5220:	eb3442ff 	cmp	x23, w20, uxtw
    5224:	540004ed 	b.le	52c0 <f128.constprop.0+0x140>
    5228:	b7f80076 	tbnz	x22, #63, 5234 <f128.constprop.0+0xb4>
    522c:	eb3642ff 	cmp	x23, w22, uxtw
    5230:	5400048d 	b.le	52c0 <f128.constprop.0+0x140>
    5234:	f9400675 	ldr	x21, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1502f5 	sub	x21, x23, x21
    5240:	910006a1 	add	x1, x21, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000308 	b.hi	52a8 <f128.constprop.0+0x128>  // b.pmore
    524c:	f9400e60 	ldr	x0, [x19, #24]
    5250:	eb00003f 	cmp	x1, x0
    5254:	5400030c 	b.gt	52b4 <f128.constprop.0+0x134>
    5258:	a9420262 	ldp	x2, x0, [x19, #32]
    525c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5260:	f9401a61 	ldr	x1, [x19, #48]
    5264:	b8357854 	str	w20, [x2, x21, lsl #2]
    5268:	f9401e62 	ldr	x2, [x19, #56]
    526c:	f10002df 	cmp	x22, #0x0
    5270:	fc357820 	str	d0, [x1, x21, lsl #3]
    5274:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5278:	b8357816 	str	w22, [x0, x21, lsl #2]
    527c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5280:	910006e1 	add	x1, x23, #0x1
    5284:	aa170000 	orr	x0, x0, x23
    5288:	fc357848 	str	d8, [x2, x21, lsl #3]
    528c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5290:	f9401bf7 	ldr	x23, [sp, #48]
    5294:	fd401fe8 	ldr	d8, [sp, #56]
    5298:	f9000a61 	str	x1, [x19, #16]
    529c:	a94153f3 	ldp	x19, x20, [sp, #16]
    52a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52a4:	d65f03c0 	ret
    52a8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    52ac:	912ac000 	add	x0, x0, #0xab0
    52b0:	97fffad8 	bl	3e10 <fwp_trap>
    52b4:	aa1303e0 	mov	x0, x19
    52b8:	97ffff1b 	bl	4f24 <fwp_tape_grow.constprop.0>
    52bc:	17ffffe7 	b	5258 <f128.constprop.0+0xd8>
    52c0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    52c4:	912d2000 	add	x0, x0, #0xb48
    52c8:	97fffad2 	bl	3e10 <fwp_trap>
    52cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52d0:	d65f03c0 	ret
    52d4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    52d8:	912b4000 	add	x0, x0, #0xad0
    52dc:	97fffacd 	bl	3e10 <fwp_trap>

00000000000052e0 <w107>:
    52e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    52e4:	910003fd 	mov	x29, sp
    52e8:	a90153f3 	stp	x19, x20, [sp, #16]
    52ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    52f0:	a90363f7 	stp	x23, x24, [sp, #48]
    52f4:	aa0003f8 	mov	x24, x0
    52f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52fc:	aa0103f9 	mov	x25, x1
    5300:	6d0527e8 	stp	d8, d9, [sp, #80]
    5304:	1e604008 	fmov	d8, d0
    5308:	1e604029 	fmov	d9, d1
    530c:	6d062fea 	stp	d10, d11, [sp, #96]
    5310:	1e60080a 	fmul	d10, d0, d0
    5314:	b7f821a0 	tbnz	x0, #63, 5748 <w107+0x468>
    5318:	9360fc17 	asr	x23, x0, #32
    531c:	aa1703e0 	mov	x0, x23
    5320:	97fffcc0 	bl	4620 <fwp_tape_of>
    5324:	f9403001 	ldr	x1, [x0, #96]
    5328:	aa0003f3 	mov	x19, x0
    532c:	b4000081 	cbz	x1, 533c <w107+0x5c>
    5330:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    5334:	912c6000 	add	x0, x0, #0xb18
    5338:	97fffab6 	bl	3e10 <fwp_trap>
    533c:	f9400815 	ldr	x21, [x0, #16]
    5340:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5344:	eb0102bf 	cmp	x21, x1
    5348:	54001d8c 	b.gt	56f8 <w107+0x418>
    534c:	eb3842bf 	cmp	x21, w24, uxtw
    5350:	54001ced 	b.le	56ec <w107+0x40c>
    5354:	f9400416 	ldr	x22, [x0, #8]
    5358:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    535c:	cb1602b6 	sub	x22, x21, x22
    5360:	910006c1 	add	x1, x22, #0x1
    5364:	eb02003f 	cmp	x1, x2
    5368:	54001c88 	b.hi	56f8 <w107+0x418>  // b.pmore
    536c:	f9400c02 	ldr	x2, [x0, #24]
    5370:	eb02003f 	cmp	x1, x2
    5374:	54001c8c 	b.gt	5704 <w107+0x424>
    5378:	a9420660 	ldp	x0, x1, [x19, #32]
    537c:	92607f14 	and	x20, x24, #0xffffffff00000000
    5380:	f9401a62 	ldr	x2, [x19, #48]
    5384:	b8367818 	str	w24, [x0, x22, lsl #2]
    5388:	f9401e60 	ldr	x0, [x19, #56]
    538c:	aa150294 	orr	x20, x20, x21
    5390:	fc367848 	str	d8, [x2, x22, lsl #3]
    5394:	910006b5 	add	x21, x21, #0x1
    5398:	b8367838 	str	w24, [x1, x22, lsl #2]
    539c:	1e6a392a 	fsub	d10, d9, d10
    53a0:	9360fe9a 	asr	x26, x20, #32
    53a4:	fc367808 	str	d8, [x0, x22, lsl #3]
    53a8:	f9000a75 	str	x21, [x19, #16]
    53ac:	b7f80079 	tbnz	x25, #63, 53b8 <w107+0xd8>
    53b0:	eb99835f 	cmp	x26, x25, asr #32
    53b4:	54001e21 	b.ne	5778 <w107+0x498>  // b.any
    53b8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    53bc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    53c0:	eb1a02ff 	cmp	x23, x26
    53c4:	540000c0 	b.eq	53dc <w107+0xfc>  // b.none
    53c8:	aa1a03e0 	mov	x0, x26
    53cc:	97fffc95 	bl	4620 <fwp_tape_of>
    53d0:	aa0003f3 	mov	x19, x0
    53d4:	f9403000 	ldr	x0, [x0, #96]
    53d8:	b5fffac0 	cbnz	x0, 5330 <w107+0x50>
    53dc:	f9400a77 	ldr	x23, [x19, #16]
    53e0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53e4:	eb0002ff 	cmp	x23, x0
    53e8:	5400188c 	b.gt	56f8 <w107+0x418>
    53ec:	eb3442ff 	cmp	x23, w20, uxtw
    53f0:	540017ed 	b.le	56ec <w107+0x40c>
    53f4:	b7f80079 	tbnz	x25, #63, 5400 <w107+0x120>
    53f8:	eb3942ff 	cmp	x23, w25, uxtw
    53fc:	5400178d 	b.le	56ec <w107+0x40c>
    5400:	f9400675 	ldr	x21, [x19, #8]
    5404:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5408:	cb1502f5 	sub	x21, x23, x21
    540c:	910006a1 	add	x1, x21, #0x1
    5410:	eb00003f 	cmp	x1, x0
    5414:	54001728 	b.hi	56f8 <w107+0x418>  // b.pmore
    5418:	f9400e60 	ldr	x0, [x19, #24]
    541c:	eb00003f 	cmp	x1, x0
    5420:	540018ec 	b.gt	573c <w107+0x45c>
    5424:	a9420e62 	ldp	x2, x3, [x19, #32]
    5428:	f100033f 	cmp	x25, #0x0
    542c:	f9401a61 	ldr	x1, [x19, #48]
    5430:	b8357854 	str	w20, [x2, x21, lsl #2]
    5434:	f9401e62 	ldr	x2, [x19, #56]
    5438:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    543c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5440:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5444:	b8357861 	str	w1, [x3, x21, lsl #2]
    5448:	910006f6 	add	x22, x23, #0x1
    544c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5450:	92607e94 	and	x20, x20, #0xffffffff00000000
    5454:	fc357849 	str	d9, [x2, x21, lsl #3]
    5458:	aa170294 	orr	x20, x20, x23
    545c:	f9000a76 	str	x22, [x19, #16]
    5460:	1e68396b 	fsub	d11, d11, d8
    5464:	b7f81a78 	tbnz	x24, #63, 57b0 <w107+0x4d0>
    5468:	9360ff17 	asr	x23, x24, #32
    546c:	eb1a02ff 	cmp	x23, x26
    5470:	540000e0 	b.eq	548c <w107+0x1ac>  // b.none
    5474:	aa1703e0 	mov	x0, x23
    5478:	97fffc6a 	bl	4620 <fwp_tape_of>
    547c:	aa0003f3 	mov	x19, x0
    5480:	f9403000 	ldr	x0, [x0, #96]
    5484:	b5fff560 	cbnz	x0, 5330 <w107+0x50>
    5488:	f9400a76 	ldr	x22, [x19, #16]
    548c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5490:	eb0002df 	cmp	x22, x0
    5494:	5400132c 	b.gt	56f8 <w107+0x418>
    5498:	eb3842df 	cmp	x22, w24, uxtw
    549c:	5400128d 	b.le	56ec <w107+0x40c>
    54a0:	f9400675 	ldr	x21, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1502d5 	sub	x21, x22, x21
    54ac:	910006a1 	add	x1, x21, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54001228 	b.hi	56f8 <w107+0x418>  // b.pmore
    54b8:	f9400e60 	ldr	x0, [x19, #24]
    54bc:	eb00003f 	cmp	x1, x0
    54c0:	5400138c 	b.gt	5730 <w107+0x450>
    54c4:	a9420262 	ldp	x2, x0, [x19, #32]
    54c8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    54cc:	f9401a63 	ldr	x3, [x19, #48]
    54d0:	b8357858 	str	w24, [x2, x21, lsl #2]
    54d4:	f9401e62 	ldr	x2, [x19, #56]
    54d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    54dc:	fc357860 	str	d0, [x3, x21, lsl #3]
    54e0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54e4:	b8357801 	str	w1, [x0, x21, lsl #2]
    54e8:	92607f00 	and	x0, x24, #0xffffffff00000000
    54ec:	aa160018 	orr	x24, x0, x22
    54f0:	910006c1 	add	x1, x22, #0x1
    54f4:	fc357840 	str	d0, [x2, x21, lsl #3]
    54f8:	f9000a61 	str	x1, [x19, #16]
    54fc:	9360fe99 	asr	x25, x20, #32
    5500:	1e6a0949 	fmul	d9, d10, d10
    5504:	eb17033f 	cmp	x25, x23
    5508:	540000c0 	b.eq	5520 <w107+0x240>  // b.none
    550c:	aa1903e0 	mov	x0, x25
    5510:	97fffc44 	bl	4620 <fwp_tape_of>
    5514:	aa0003f3 	mov	x19, x0
    5518:	f9403000 	ldr	x0, [x0, #96]
    551c:	b5fff0a0 	cbnz	x0, 5330 <w107+0x50>
    5520:	f9400a75 	ldr	x21, [x19, #16]
    5524:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5528:	eb0002bf 	cmp	x21, x0
    552c:	54000e6c 	b.gt	56f8 <w107+0x418>
    5530:	eb3442bf 	cmp	x21, w20, uxtw
    5534:	54000dcd 	b.le	56ec <w107+0x40c>
    5538:	f9400676 	ldr	x22, [x19, #8]
    553c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5540:	cb1602b6 	sub	x22, x21, x22
    5544:	910006c1 	add	x1, x22, #0x1
    5548:	eb00003f 	cmp	x1, x0
    554c:	54000d68 	b.hi	56f8 <w107+0x418>  // b.pmore
    5550:	f9400e60 	ldr	x0, [x19, #24]
    5554:	eb00003f 	cmp	x1, x0
    5558:	54000e6c 	b.gt	5724 <w107+0x444>
    555c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5560:	aa150017 	orr	x23, x0, x21
    5564:	a9420261 	ldp	x1, x0, [x19, #32]
    5568:	f9401a62 	ldr	x2, [x19, #48]
    556c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5570:	f9401e61 	ldr	x1, [x19, #56]
    5574:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5578:	b8367814 	str	w20, [x0, x22, lsl #2]
    557c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5580:	9e670000 	fmov	d0, x0
    5584:	910006b4 	add	x20, x21, #0x1
    5588:	fc36782a 	str	d10, [x1, x22, lsl #3]
    558c:	9360fef6 	asr	x22, x23, #32
    5590:	f9000a74 	str	x20, [x19, #16]
    5594:	1e600929 	fmul	d9, d9, d0
    5598:	eb1902df 	cmp	x22, x25
    559c:	540000e0 	b.eq	55b8 <w107+0x2d8>  // b.none
    55a0:	aa1603e0 	mov	x0, x22
    55a4:	97fffc1f 	bl	4620 <fwp_tape_of>
    55a8:	aa0003f3 	mov	x19, x0
    55ac:	f9403000 	ldr	x0, [x0, #96]
    55b0:	b5ffec00 	cbnz	x0, 5330 <w107+0x50>
    55b4:	f9400a74 	ldr	x20, [x19, #16]
    55b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55bc:	eb00029f 	cmp	x20, x0
    55c0:	540009cc 	b.gt	56f8 <w107+0x418>
    55c4:	eb37429f 	cmp	x20, w23, uxtw
    55c8:	5400092d 	b.le	56ec <w107+0x40c>
    55cc:	f9400675 	ldr	x21, [x19, #8]
    55d0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55d4:	cb150295 	sub	x21, x20, x21
    55d8:	910006a1 	add	x1, x21, #0x1
    55dc:	eb00003f 	cmp	x1, x0
    55e0:	540008c8 	b.hi	56f8 <w107+0x418>  // b.pmore
    55e4:	f9400e60 	ldr	x0, [x19, #24]
    55e8:	eb00003f 	cmp	x1, x0
    55ec:	5400096c 	b.gt	5718 <w107+0x438>
    55f0:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    55f4:	9e670000 	fmov	d0, x0
    55f8:	a9420262 	ldp	x2, x0, [x19, #32]
    55fc:	1e6b0968 	fmul	d8, d11, d11
    5600:	f9401a61 	ldr	x1, [x19, #48]
    5604:	b8357857 	str	w23, [x2, x21, lsl #2]
    5608:	f9401e62 	ldr	x2, [x19, #56]
    560c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5610:	12800001 	mov	w1, #0xffffffff            	// #-1
    5614:	b8357801 	str	w1, [x0, x21, lsl #2]
    5618:	91000681 	add	x1, x20, #0x1
    561c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5620:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5624:	f9000a61 	str	x1, [x19, #16]
    5628:	aa140014 	orr	x20, x0, x20
    562c:	b100071f 	cmn	x24, #0x1
    5630:	54000c60 	b.eq	57bc <w107+0x4dc>  // b.none
    5634:	9360ff00 	asr	x0, x24, #32
    5638:	eb16001f 	cmp	x0, x22
    563c:	540000a0 	b.eq	5650 <w107+0x370>  // b.none
    5640:	97fffbf8 	bl	4620 <fwp_tape_of>
    5644:	aa0003f3 	mov	x19, x0
    5648:	f9403000 	ldr	x0, [x0, #96]
    564c:	b5ffe720 	cbnz	x0, 5330 <w107+0x50>
    5650:	f9400a75 	ldr	x21, [x19, #16]
    5654:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5658:	eb0002bf 	cmp	x21, x0
    565c:	540004ec 	b.gt	56f8 <w107+0x418>
    5660:	eb3842bf 	cmp	x21, w24, uxtw
    5664:	5400044d 	b.le	56ec <w107+0x40c>
    5668:	f9400676 	ldr	x22, [x19, #8]
    566c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5670:	cb1602b6 	sub	x22, x21, x22
    5674:	910006c1 	add	x1, x22, #0x1
    5678:	eb00003f 	cmp	x1, x0
    567c:	540003e8 	b.hi	56f8 <w107+0x418>  // b.pmore
    5680:	f9400e60 	ldr	x0, [x19, #24]
    5684:	eb00003f 	cmp	x1, x0
    5688:	5400042c 	b.gt	570c <w107+0x42c>
    568c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5690:	92607f00 	and	x0, x24, #0xffffffff00000000
    5694:	f9401a63 	ldr	x3, [x19, #48]
    5698:	b8367838 	str	w24, [x1, x22, lsl #2]
    569c:	f9401e61 	ldr	x1, [x19, #56]
    56a0:	aa150000 	orr	x0, x0, x21
    56a4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    56a8:	910006b5 	add	x21, x21, #0x1
    56ac:	b8367858 	str	w24, [x2, x22, lsl #2]
    56b0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    56b4:	f9000a75 	str	x21, [x19, #16]
    56b8:	1e692908 	fadd	d8, d8, d9
    56bc:	aa1403e1 	mov	x1, x20
    56c0:	97fffeb0 	bl	5180 <f128.constprop.0>
    56c4:	aa0003e1 	mov	x1, x0
    56c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    56cc:	9e660100 	fmov	x0, d8
    56d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    56d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    56dc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    56e0:	6d462fea 	ldp	d10, d11, [sp, #96]
    56e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    56e8:	d65f03c0 	ret
    56ec:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    56f0:	912d2000 	add	x0, x0, #0xb48
    56f4:	97fff9c7 	bl	3e10 <fwp_trap>
    56f8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    56fc:	912ac000 	add	x0, x0, #0xab0
    5700:	97fff9c4 	bl	3e10 <fwp_trap>
    5704:	97fffe08 	bl	4f24 <fwp_tape_grow.constprop.0>
    5708:	17ffff1c 	b	5378 <w107+0x98>
    570c:	aa1303e0 	mov	x0, x19
    5710:	97fffe05 	bl	4f24 <fwp_tape_grow.constprop.0>
    5714:	17ffffde 	b	568c <w107+0x3ac>
    5718:	aa1303e0 	mov	x0, x19
    571c:	97fffe02 	bl	4f24 <fwp_tape_grow.constprop.0>
    5720:	17ffffb4 	b	55f0 <w107+0x310>
    5724:	aa1303e0 	mov	x0, x19
    5728:	97fffdff 	bl	4f24 <fwp_tape_grow.constprop.0>
    572c:	17ffff8c 	b	555c <w107+0x27c>
    5730:	aa1303e0 	mov	x0, x19
    5734:	97fffdfc 	bl	4f24 <fwp_tape_grow.constprop.0>
    5738:	17ffff63 	b	54c4 <w107+0x1e4>
    573c:	aa1303e0 	mov	x0, x19
    5740:	97fffdf9 	bl	4f24 <fwp_tape_grow.constprop.0>
    5744:	17ffff38 	b	5424 <w107+0x144>
    5748:	1e6a382a 	fsub	d10, d1, d10
    574c:	b6f801c1 	tbz	x1, #63, 5784 <w107+0x4a4>
    5750:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5754:	1e6a0949 	fmul	d9, d10, d10
    5758:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    575c:	9e670001 	fmov	d1, x0
    5760:	1e683808 	fsub	d8, d0, d8
    5764:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5768:	aa1403e0 	mov	x0, x20
    576c:	1e610929 	fmul	d9, d9, d1
    5770:	1e680908 	fmul	d8, d8, d8
    5774:	17ffffd1 	b	56b8 <w107+0x3d8>
    5778:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    577c:	912b4000 	add	x0, x0, #0xad0
    5780:	97fff9a4 	bl	3e10 <fwp_trap>
    5784:	2f00e409 	movi	d9, #0x0
    5788:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    578c:	9360fc3a 	asr	x26, x1, #32
    5790:	aa0103f4 	mov	x20, x1
    5794:	aa1a03e0 	mov	x0, x26
    5798:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    579c:	97fffba1 	bl	4620 <fwp_tape_of>
    57a0:	aa0003f3 	mov	x19, x0
    57a4:	f9403000 	ldr	x0, [x0, #96]
    57a8:	b5ffdc40 	cbnz	x0, 5330 <w107+0x50>
    57ac:	17ffff0c 	b	53dc <w107+0xfc>
    57b0:	aa1a03f7 	mov	x23, x26
    57b4:	aa0003f8 	mov	x24, x0
    57b8:	17ffff51 	b	54fc <w107+0x21c>
    57bc:	aa1803e0 	mov	x0, x24
    57c0:	17ffffbe 	b	56b8 <w107+0x3d8>

00000000000057c4 <fwp_data.part.0.constprop.0>:
    57c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    57d4:	91154283 	add	x3, x20, #0x550
    57d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57dc:	aa0103f5 	mov	x21, x1
    57e0:	b953a461 	ldr	w1, [x3, #5028]
    57e4:	a90363f7 	stp	x23, x24, [sp, #48]
    57e8:	2a0003f8 	mov	w24, w0
    57ec:	34000701 	cbz	w1, 58cc <fwp_data.part.0.constprop.0+0x108>
    57f0:	397e8862 	ldrb	w2, [x3, #4002]
    57f4:	910f0040 	add	x0, x2, #0x3c0
    57f8:	8b020442 	add	x2, x2, x2, lsl #1
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5804:	2a1703f6 	mov	w22, w23
    5808:	f8626873 	ldr	x19, [x3, x2]
    580c:	b40004d3 	cbz	x19, 58a4 <fwp_data.part.0.constprop.0+0xe0>
    5810:	f9400260 	ldr	x0, [x19]
    5814:	aa2003e0 	mvn	x0, x0
    5818:	f8226860 	str	x0, [x3, x2]
    581c:	f10062df 	cmp	x22, #0x18
    5820:	540000e9 	b.ls	583c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5824:	d10066c2 	sub	x2, x22, #0x19
    5828:	91006260 	add	x0, x19, #0x18
    582c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5830:	52800001 	mov	w1, #0x0                   	// #0
    5834:	91002042 	add	x2, x2, #0x8
    5838:	97fff3e2 	bl	27c0 <memset@plt>
    583c:	91154282 	add	x2, x20, #0x550
    5840:	f94a1041 	ldr	x1, [x2, #5152]
    5844:	ab160021 	adds	x1, x1, x22
    5848:	540004c2 	b.cs	58e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    584c:	f94a1440 	ldr	x0, [x2, #5160]
    5850:	f90a1041 	str	x1, [x2, #5152]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000049 	b.ls	5860 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    585c:	f90a1441 	str	x1, [x2, #5160]
    5860:	91154294 	add	x20, x20, #0x550
    5864:	1e6302e1 	ucvtf	d1, w23
    5868:	fd4a1e80 	ldr	d0, [x20, #5176]
    586c:	1e612800 	fadd	d0, d0, d1
    5870:	fd0a1e80 	str	d0, [x20, #5176]
    5874:	52800041 	mov	w1, #0x2                   	// #2
    5878:	29000678 	stp	w24, w1, [x19]
    587c:	aa1303e0 	mov	x0, x19
    5880:	f94002a1 	ldr	x1, [x21]
    5884:	f9000661 	str	x1, [x19, #8]
    5888:	f94006a1 	ldr	x1, [x21, #8]
    588c:	f9000a61 	str	x1, [x19, #16]
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5898:	a94363f7 	ldp	x23, x24, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	d65f03c0 	ret
    58a4:	8b020063 	add	x3, x3, x2
    58a8:	f9400473 	ldr	x19, [x3, #8]
    58ac:	b4000113 	cbz	x19, 58cc <fwp_data.part.0.constprop.0+0x108>
    58b0:	f9400860 	ldr	x0, [x3, #16]
    58b4:	cb130000 	sub	x0, x0, x19
    58b8:	eb0002df 	cmp	x22, x0
    58bc:	54000088 	b.hi	58cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    58c0:	8b160260 	add	x0, x19, x22
    58c4:	f9000460 	str	x0, [x3, #8]
    58c8:	17ffffd5 	b	581c <fwp_data.part.0.constprop.0+0x58>
    58cc:	52800001 	mov	w1, #0x0                   	// #0
    58d0:	d2800300 	mov	x0, #0x18                  	// #24
    58d4:	97fffcc7 	bl	4bf0 <fwp_heap_alloc>
    58d8:	aa0003f3 	mov	x19, x0
    58dc:	17ffffe6 	b	5874 <fwp_data.part.0.constprop.0+0xb0>
    58e0:	97fff5b4 	bl	2fb0 <fwp_heap_oom>

00000000000058e4 <fwp_rc_share>:
    58e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    58e8:	91154042 	add	x2, x2, #0x550
    58ec:	f949d843 	ldr	x3, [x2, #5040]
    58f0:	f949ec41 	ldr	x1, [x2, #5080]
    58f4:	cb030000 	sub	x0, x0, x3
    58f8:	eb01401f 	cmp	x0, x1, lsl #16
    58fc:	540003a2 	b.cs	5970 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5900:	d350fc01 	lsr	x1, x0, #16
    5904:	f949fc44 	ldr	x4, [x2, #5112]
    5908:	8b010821 	add	x1, x1, x1, lsl #2
    590c:	d37df021 	lsl	x1, x1, #3
    5910:	8b010083 	add	x3, x4, x1
    5914:	f9401062 	ldr	x2, [x3, #32]
    5918:	b40002c2 	cbz	x2, 5970 <fwp_rc_share+0x8c>
    591c:	38616881 	ldrb	w1, [x4, x1]
    5920:	7100083f 	cmp	w1, #0x2
    5924:	54000220 	b.eq	5968 <fwp_rc_share+0x84>  // b.none
    5928:	7100043f 	cmp	w1, #0x1
    592c:	54000221 	b.ne	5970 <fwp_rc_share+0x8c>  // b.any
    5930:	29430464 	ldp	w4, w1, [x3, #24]
    5934:	92403c00 	and	x0, x0, #0xffff
    5938:	9b047c00 	mul	x0, x0, x4
    593c:	d360fc00 	lsr	x0, x0, #32
    5940:	eb01001f 	cmp	x0, x1
    5944:	54000162 	b.cs	5970 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5948:	8b000042 	add	x2, x2, x0
    594c:	39400040 	ldrb	w0, [x2]
    5950:	34000100 	cbz	w0, 5970 <fwp_rc_share+0x8c>
    5954:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5958:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    595c:	912da000 	add	x0, x0, #0xb68
    5960:	910003fd 	mov	x29, sp
    5964:	97fff92b 	bl	3e10 <fwp_trap>
    5968:	72003c1f 	tst	w0, #0xffff
    596c:	54ffff00 	b.eq	594c <fwp_rc_share+0x68>  // b.none
    5970:	d65f03c0 	ret

0000000000005974 <fwp_rc_fresh>:
    5974:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5978:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    597c:	91154063 	add	x3, x3, #0x550
    5980:	910003fd 	mov	x29, sp
    5984:	a90153f3 	stp	x19, x20, [sp, #16]
    5988:	aa0003f3 	mov	x19, x0
    598c:	f949d861 	ldr	x1, [x3, #5040]
    5990:	f949ec60 	ldr	x0, [x3, #5080]
    5994:	cb010261 	sub	x1, x19, x1
    5998:	eb00403f 	cmp	x1, x0, lsl #16
    599c:	54000322 	b.cs	5a00 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    59a0:	d350fc22 	lsr	x2, x1, #16
    59a4:	f949fc63 	ldr	x3, [x3, #5112]
    59a8:	8b020842 	add	x2, x2, x2, lsl #2
    59ac:	d37df042 	lsl	x2, x2, #3
    59b0:	8b020060 	add	x0, x3, x2
    59b4:	f9401014 	ldr	x20, [x0, #32]
    59b8:	b4000254 	cbz	x20, 5a00 <fwp_rc_fresh+0x8c>
    59bc:	38626862 	ldrb	w2, [x3, x2]
    59c0:	7100085f 	cmp	w2, #0x2
    59c4:	54000260 	b.eq	5a10 <fwp_rc_fresh+0x9c>  // b.none
    59c8:	7100045f 	cmp	w2, #0x1
    59cc:	540001a1 	b.ne	5a00 <fwp_rc_fresh+0x8c>  // b.any
    59d0:	29430002 	ldp	w2, w0, [x0, #24]
    59d4:	92403c21 	and	x1, x1, #0xffff
    59d8:	9b027c21 	mul	x1, x1, x2
    59dc:	d360fc21 	lsr	x1, x1, #32
    59e0:	eb00003f 	cmp	x1, x0
    59e4:	540000e2 	b.cs	5a00 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    59e8:	8b010294 	add	x20, x20, x1
    59ec:	39400280 	ldrb	w0, [x20]
    59f0:	7103fc1f 	cmp	w0, #0xff
    59f4:	540001a0 	b.eq	5a28 <fwp_rc_fresh+0xb4>  // b.none
    59f8:	52800020 	mov	w0, #0x1                   	// #1
    59fc:	39000280 	strb	w0, [x20]
    5a00:	aa1303e0 	mov	x0, x19
    5a04:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a0c:	d65f03c0 	ret
    5a10:	72003c3f 	tst	w1, #0xffff
    5a14:	54fffec0 	b.eq	59ec <fwp_rc_fresh+0x78>  // b.none
    5a18:	aa1303e0 	mov	x0, x19
    5a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a24:	d65f03c0 	ret
    5a28:	aa1403e0 	mov	x0, x20
    5a2c:	97fff919 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5a30:	17fffff2 	b	59f8 <fwp_rc_fresh+0x84>

0000000000005a34 <fwp_rc_free_arr>:
    5a34:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5a38:	91154063 	add	x3, x3, #0x550
    5a3c:	f949d861 	ldr	x1, [x3, #5040]
    5a40:	f949ec62 	ldr	x2, [x3, #5080]
    5a44:	cb010001 	sub	x1, x0, x1
    5a48:	eb02403f 	cmp	x1, x2, lsl #16
    5a4c:	54000342 	b.cs	5ab4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a50:	d350fc22 	lsr	x2, x1, #16
    5a54:	f949fc65 	ldr	x5, [x3, #5112]
    5a58:	8b020842 	add	x2, x2, x2, lsl #2
    5a5c:	d37df042 	lsl	x2, x2, #3
    5a60:	8b0200a4 	add	x4, x5, x2
    5a64:	f9401083 	ldr	x3, [x4, #32]
    5a68:	b4000263 	cbz	x3, 5ab4 <fwp_rc_free_arr+0x80>
    5a6c:	386268a2 	ldrb	w2, [x5, x2]
    5a70:	7100085f 	cmp	w2, #0x2
    5a74:	540001c0 	b.eq	5aac <fwp_rc_free_arr+0x78>  // b.none
    5a78:	7100045f 	cmp	w2, #0x1
    5a7c:	540001c1 	b.ne	5ab4 <fwp_rc_free_arr+0x80>  // b.any
    5a80:	29430885 	ldp	w5, w2, [x4, #24]
    5a84:	92403c21 	and	x1, x1, #0xffff
    5a88:	9b057c21 	mul	x1, x1, x5
    5a8c:	d360fc21 	lsr	x1, x1, #32
    5a90:	eb02003f 	cmp	x1, x2
    5a94:	54000102 	b.cs	5ab4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a98:	8b010063 	add	x3, x3, x1
    5a9c:	39400061 	ldrb	w1, [x3]
    5aa0:	7100043f 	cmp	w1, #0x1
    5aa4:	54000081 	b.ne	5ab4 <fwp_rc_free_arr+0x80>  // b.any
    5aa8:	17fff996 	b	4100 <fwp_mem_free>
    5aac:	72003c3f 	tst	w1, #0xffff
    5ab0:	54ffff60 	b.eq	5a9c <fwp_rc_free_arr+0x68>  // b.none
    5ab4:	d65f03c0 	ret
    5ab8:	d503201f 	nop
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_rc_dup>:
    5ac0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5ac4:	91154042 	add	x2, x2, #0x550
    5ac8:	f949d841 	ldr	x1, [x2, #5040]
    5acc:	f949ec43 	ldr	x3, [x2, #5080]
    5ad0:	cb010001 	sub	x1, x0, x1
    5ad4:	eb03403f 	cmp	x1, x3, lsl #16
    5ad8:	54000342 	b.cs	5b40 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5adc:	d350fc20 	lsr	x0, x1, #16
    5ae0:	f949fc44 	ldr	x4, [x2, #5112]
    5ae4:	8b000800 	add	x0, x0, x0, lsl #2
    5ae8:	d37df002 	lsl	x2, x0, #3
    5aec:	8b020083 	add	x3, x4, x2
    5af0:	f9401060 	ldr	x0, [x3, #32]
    5af4:	b4000260 	cbz	x0, 5b40 <fwp_rc_dup+0x80>
    5af8:	38626882 	ldrb	w2, [x4, x2]
    5afc:	7100085f 	cmp	w2, #0x2
    5b00:	54000220 	b.eq	5b44 <fwp_rc_dup+0x84>  // b.none
    5b04:	7100045f 	cmp	w2, #0x1
    5b08:	540001c1 	b.ne	5b40 <fwp_rc_dup+0x80>  // b.any
    5b0c:	29430864 	ldp	w4, w2, [x3, #24]
    5b10:	92403c21 	and	x1, x1, #0xffff
    5b14:	9b047c21 	mul	x1, x1, x4
    5b18:	d360fc21 	lsr	x1, x1, #32
    5b1c:	eb02003f 	cmp	x1, x2
    5b20:	54000102 	b.cs	5b40 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5b24:	8b010000 	add	x0, x0, x1
    5b28:	39400001 	ldrb	w1, [x0]
    5b2c:	340000a1 	cbz	w1, 5b40 <fwp_rc_dup+0x80>
    5b30:	7103f43f 	cmp	w1, #0xfd
    5b34:	540000e8 	b.hi	5b50 <fwp_rc_dup+0x90>  // b.pmore
    5b38:	11000421 	add	w1, w1, #0x1
    5b3c:	39000001 	strb	w1, [x0]
    5b40:	d65f03c0 	ret
    5b44:	72003c3f 	tst	w1, #0xffff
    5b48:	54ffff00 	b.eq	5b28 <fwp_rc_dup+0x68>  // b.none
    5b4c:	d65f03c0 	ret
    5b50:	17fff9e5 	b	42e4 <fwp_rc_wide_dup>

0000000000005b54 <fwp_owned_entry161>:
    5b54:	d10103ff 	sub	sp, sp, #0x40
    5b58:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5b5c:	f947f442 	ldr	x2, [x2, #4072]
    5b60:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b64:	910083fd 	add	x29, sp, #0x20
    5b68:	a90353f3 	stp	x19, x20, [sp, #48]
    5b6c:	f9400043 	ldr	x3, [x2]
    5b70:	f9000fe3 	str	x3, [sp, #24]
    5b74:	d2800003 	mov	x3, #0x0                   	// #0
    5b78:	a9400c01 	ldp	x1, x3, [x0]
    5b7c:	f9400802 	ldr	x2, [x0, #16]
    5b80:	ab020022 	adds	x2, x1, x2
    5b84:	540006e6 	b.vs	5c60 <fwp_owned_entry161+0x10c>
    5b88:	910023e1 	add	x1, sp, #0x8
    5b8c:	52800000 	mov	w0, #0x0                   	// #0
    5b90:	a9008be3 	stp	x3, x2, [sp, #8]
    5b94:	97ffff0c 	bl	57c4 <fwp_data.part.0.constprop.0>
    5b98:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5b9c:	91154063 	add	x3, x3, #0x550
    5ba0:	aa0003f3 	mov	x19, x0
    5ba4:	f949d861 	ldr	x1, [x3, #5040]
    5ba8:	f949ec60 	ldr	x0, [x3, #5080]
    5bac:	cb010261 	sub	x1, x19, x1
    5bb0:	eb00403f 	cmp	x1, x0, lsl #16
    5bb4:	54000322 	b.cs	5c18 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5bb8:	d350fc22 	lsr	x2, x1, #16
    5bbc:	f949fc63 	ldr	x3, [x3, #5112]
    5bc0:	8b020842 	add	x2, x2, x2, lsl #2
    5bc4:	d37df042 	lsl	x2, x2, #3
    5bc8:	8b020060 	add	x0, x3, x2
    5bcc:	f9401014 	ldr	x20, [x0, #32]
    5bd0:	b4000254 	cbz	x20, 5c18 <fwp_owned_entry161+0xc4>
    5bd4:	38626862 	ldrb	w2, [x3, x2]
    5bd8:	7100085f 	cmp	w2, #0x2
    5bdc:	54000360 	b.eq	5c48 <fwp_owned_entry161+0xf4>  // b.none
    5be0:	7100045f 	cmp	w2, #0x1
    5be4:	540001a1 	b.ne	5c18 <fwp_owned_entry161+0xc4>  // b.any
    5be8:	29430002 	ldp	w2, w0, [x0, #24]
    5bec:	92403c21 	and	x1, x1, #0xffff
    5bf0:	9b027c21 	mul	x1, x1, x2
    5bf4:	d360fc21 	lsr	x1, x1, #32
    5bf8:	eb00003f 	cmp	x1, x0
    5bfc:	540000e2 	b.cs	5c18 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5c00:	8b010294 	add	x20, x20, x1
    5c04:	39400280 	ldrb	w0, [x20]
    5c08:	7103fc1f 	cmp	w0, #0xff
    5c0c:	54000240 	b.eq	5c54 <fwp_owned_entry161+0x100>  // b.none
    5c10:	52800020 	mov	w0, #0x1                   	// #1
    5c14:	39000280 	strb	w0, [x20]
    5c18:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c1c:	f947f400 	ldr	x0, [x0, #4072]
    5c20:	f9400fe2 	ldr	x2, [sp, #24]
    5c24:	f9400001 	ldr	x1, [x0]
    5c28:	eb010042 	subs	x2, x2, x1
    5c2c:	d2800001 	mov	x1, #0x0                   	// #0
    5c30:	540001a1 	b.ne	5c64 <fwp_owned_entry161+0x110>  // b.any
    5c34:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c38:	aa1303e0 	mov	x0, x19
    5c3c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c40:	910103ff 	add	sp, sp, #0x40
    5c44:	d65f03c0 	ret
    5c48:	72003c3f 	tst	w1, #0xffff
    5c4c:	54fffe61 	b.ne	5c18 <fwp_owned_entry161+0xc4>  // b.any
    5c50:	17ffffed 	b	5c04 <fwp_owned_entry161+0xb0>
    5c54:	aa1403e0 	mov	x0, x20
    5c58:	97fff88e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5c5c:	17ffffed 	b	5c10 <fwp_owned_entry161+0xbc>
    5c60:	97fff368 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5c64:	97fff2e3 	bl	27f0 <__stack_chk_fail@plt>
    5c68:	d503201f 	nop
    5c6c:	d503201f 	nop

0000000000005c70 <e161>:
    5c70:	d10103ff 	sub	sp, sp, #0x40
    5c74:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5c78:	f947f442 	ldr	x2, [x2, #4072]
    5c7c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c80:	910083fd 	add	x29, sp, #0x20
    5c84:	a90353f3 	stp	x19, x20, [sp, #48]
    5c88:	f9400043 	ldr	x3, [x2]
    5c8c:	f9000fe3 	str	x3, [sp, #24]
    5c90:	d2800003 	mov	x3, #0x0                   	// #0
    5c94:	a9400c01 	ldp	x1, x3, [x0]
    5c98:	f9400802 	ldr	x2, [x0, #16]
    5c9c:	ab020022 	adds	x2, x1, x2
    5ca0:	54000726 	b.vs	5d84 <e161+0x114>
    5ca4:	910023e1 	add	x1, sp, #0x8
    5ca8:	52800000 	mov	w0, #0x0                   	// #0
    5cac:	a9008be3 	stp	x3, x2, [sp, #8]
    5cb0:	97fffec5 	bl	57c4 <fwp_data.part.0.constprop.0>
    5cb4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5cb8:	91154063 	add	x3, x3, #0x550
    5cbc:	aa0003f3 	mov	x19, x0
    5cc0:	f949d861 	ldr	x1, [x3, #5040]
    5cc4:	f949ec60 	ldr	x0, [x3, #5080]
    5cc8:	cb010261 	sub	x1, x19, x1
    5ccc:	eb00403f 	cmp	x1, x0, lsl #16
    5cd0:	54000322 	b.cs	5d34 <e161+0xc4>  // b.hs, b.nlast
    5cd4:	d350fc22 	lsr	x2, x1, #16
    5cd8:	f949fc63 	ldr	x3, [x3, #5112]
    5cdc:	8b020842 	add	x2, x2, x2, lsl #2
    5ce0:	d37df042 	lsl	x2, x2, #3
    5ce4:	8b020060 	add	x0, x3, x2
    5ce8:	f9401014 	ldr	x20, [x0, #32]
    5cec:	b4000254 	cbz	x20, 5d34 <e161+0xc4>
    5cf0:	38626862 	ldrb	w2, [x3, x2]
    5cf4:	7100085f 	cmp	w2, #0x2
    5cf8:	540003a0 	b.eq	5d6c <e161+0xfc>  // b.none
    5cfc:	7100045f 	cmp	w2, #0x1
    5d00:	540001a1 	b.ne	5d34 <e161+0xc4>  // b.any
    5d04:	29430002 	ldp	w2, w0, [x0, #24]
    5d08:	92403c21 	and	x1, x1, #0xffff
    5d0c:	9b027c21 	mul	x1, x1, x2
    5d10:	d360fc21 	lsr	x1, x1, #32
    5d14:	eb00003f 	cmp	x1, x0
    5d18:	540000e2 	b.cs	5d34 <e161+0xc4>  // b.hs, b.nlast
    5d1c:	8b010294 	add	x20, x20, x1
    5d20:	39400280 	ldrb	w0, [x20]
    5d24:	7103fc1f 	cmp	w0, #0xff
    5d28:	54000280 	b.eq	5d78 <e161+0x108>  // b.none
    5d2c:	52800020 	mov	w0, #0x1                   	// #1
    5d30:	39000280 	strb	w0, [x20]
    5d34:	aa1303e0 	mov	x0, x19
    5d38:	97fffeeb 	bl	58e4 <fwp_rc_share>
    5d3c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d40:	f947f400 	ldr	x0, [x0, #4072]
    5d44:	f9400fe2 	ldr	x2, [sp, #24]
    5d48:	f9400001 	ldr	x1, [x0]
    5d4c:	eb010042 	subs	x2, x2, x1
    5d50:	d2800001 	mov	x1, #0x0                   	// #0
    5d54:	540001a1 	b.ne	5d88 <e161+0x118>  // b.any
    5d58:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d5c:	aa1303e0 	mov	x0, x19
    5d60:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d64:	910103ff 	add	sp, sp, #0x40
    5d68:	d65f03c0 	ret
    5d6c:	72003c3f 	tst	w1, #0xffff
    5d70:	54fffe21 	b.ne	5d34 <e161+0xc4>  // b.any
    5d74:	17ffffeb 	b	5d20 <e161+0xb0>
    5d78:	aa1403e0 	mov	x0, x20
    5d7c:	97fff845 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5d80:	17ffffeb 	b	5d2c <e161+0xbc>
    5d84:	97fff31f 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5d88:	97fff29a 	bl	27f0 <__stack_chk_fail@plt>
    5d8c:	d503201f 	nop

0000000000005d90 <fwp_drop1>:
    5d90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d94:	910003fd 	mov	x29, sp
    5d98:	a90153f3 	stp	x19, x20, [sp, #16]
    5d9c:	f90013f5 	str	x21, [sp, #32]
    5da0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5da4:	911542b4 	add	x20, x21, #0x550
    5da8:	f949da81 	ldr	x1, [x20, #5040]
    5dac:	f949ee82 	ldr	x2, [x20, #5080]
    5db0:	cb010001 	sub	x1, x0, x1
    5db4:	eb02403f 	cmp	x1, x2, lsl #16
    5db8:	54000382 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dbc:	d350fc22 	lsr	x2, x1, #16
    5dc0:	f949fe84 	ldr	x4, [x20, #5112]
    5dc4:	8b020842 	add	x2, x2, x2, lsl #2
    5dc8:	d37df042 	lsl	x2, x2, #3
    5dcc:	8b020083 	add	x3, x4, x2
    5dd0:	f9401073 	ldr	x19, [x3, #32]
    5dd4:	b40002b3 	cbz	x19, 5e28 <fwp_drop1+0x98>
    5dd8:	38626882 	ldrb	w2, [x4, x2]
    5ddc:	7100085f 	cmp	w2, #0x2
    5de0:	540002c0 	b.eq	5e38 <fwp_drop1+0xa8>  // b.none
    5de4:	7100045f 	cmp	w2, #0x1
    5de8:	54000201 	b.ne	5e28 <fwp_drop1+0x98>  // b.any
    5dec:	29430864 	ldp	w4, w2, [x3, #24]
    5df0:	92403c21 	and	x1, x1, #0xffff
    5df4:	9b047c21 	mul	x1, x1, x4
    5df8:	d360fc21 	lsr	x1, x1, #32
    5dfc:	eb02003f 	cmp	x1, x2
    5e00:	54000142 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e04:	8b010273 	add	x19, x19, x1
    5e08:	39400261 	ldrb	w1, [x19]
    5e0c:	340000e1 	cbz	w1, 5e28 <fwp_drop1+0x98>
    5e10:	7100043f 	cmp	w1, #0x1
    5e14:	540001e0 	b.eq	5e50 <fwp_drop1+0xc0>  // b.none
    5e18:	7103fc3f 	cmp	w1, #0xff
    5e1c:	540002e0 	b.eq	5e78 <fwp_drop1+0xe8>  // b.none
    5e20:	51000421 	sub	w1, w1, #0x1
    5e24:	39000261 	strb	w1, [x19]
    5e28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e2c:	f94013f5 	ldr	x21, [sp, #32]
    5e30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e34:	d65f03c0 	ret
    5e38:	72003c3f 	tst	w1, #0xffff
    5e3c:	54fffe60 	b.eq	5e08 <fwp_drop1+0x78>  // b.none
    5e40:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e44:	f94013f5 	ldr	x21, [sp, #32]
    5e48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e4c:	d65f03c0 	ret
    5e50:	f9400813 	ldr	x19, [x0, #16]
    5e54:	97fffef8 	bl	5a34 <fwp_rc_free_arr>
    5e58:	911542a0 	add	x0, x21, #0x550
    5e5c:	f949d801 	ldr	x1, [x0, #5040]
    5e60:	f949ec00 	ldr	x0, [x0, #5080]
    5e64:	cb010261 	sub	x1, x19, x1
    5e68:	eb00403f 	cmp	x1, x0, lsl #16
    5e6c:	54fffde2 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e70:	aa1303e0 	mov	x0, x19
    5e74:	17ffffd2 	b	5dbc <fwp_drop1+0x2c>
    5e78:	ca534660 	eor	x0, x19, x19, lsr #17
    5e7c:	911542b5 	add	x21, x21, #0x550
    5e80:	ca402400 	eor	x0, x0, x0, lsr #9
    5e84:	92401c00 	and	x0, x0, #0xff
    5e88:	910a2402 	add	x2, x0, #0x289
    5e8c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e90:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e94:	f94a2400 	ldr	x0, [x0, #5192]
    5e98:	b50000a0 	cbnz	x0, 5eac <fwp_drop1+0x11c>
    5e9c:	14000013 	b	5ee8 <fwp_drop1+0x158>
    5ea0:	91004002 	add	x2, x0, #0x10
    5ea4:	f9400800 	ldr	x0, [x0, #16]
    5ea8:	b4000200 	cbz	x0, 5ee8 <fwp_drop1+0x158>
    5eac:	f9400001 	ldr	x1, [x0]
    5eb0:	eb13003f 	cmp	x1, x19
    5eb4:	54ffff61 	b.ne	5ea0 <fwp_drop1+0x110>  // b.any
    5eb8:	f9400041 	ldr	x1, [x2]
    5ebc:	f9400420 	ldr	x0, [x1, #8]
    5ec0:	d1000400 	sub	x0, x0, #0x1
    5ec4:	f9000420 	str	x0, [x1, #8]
    5ec8:	f103f81f 	cmp	x0, #0xfe
    5ecc:	54fffae1 	b.ne	5e28 <fwp_drop1+0x98>  // b.any
    5ed0:	39400260 	ldrb	w0, [x19]
    5ed4:	7103fc1f 	cmp	w0, #0xff
    5ed8:	540000e0 	b.eq	5ef4 <fwp_drop1+0x164>  // b.none
    5edc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ee0:	39000260 	strb	w0, [x19]
    5ee4:	17ffffd1 	b	5e28 <fwp_drop1+0x98>
    5ee8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x47c>
    5eec:	91240000 	add	x0, x0, #0x900
    5ef0:	97fff7c8 	bl	3e10 <fwp_trap>
    5ef4:	aa1303e0 	mov	x0, x19
    5ef8:	97fff7e6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5efc:	17fffff8 	b	5edc <fwp_drop1+0x14c>

0000000000005f00 <fwp_drop0>:
    5f00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f04:	910003fd 	mov	x29, sp
    5f08:	a90153f3 	stp	x19, x20, [sp, #16]
    5f0c:	f90013f5 	str	x21, [sp, #32]
    5f10:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5f14:	911542b4 	add	x20, x21, #0x550
    5f18:	f949da81 	ldr	x1, [x20, #5040]
    5f1c:	f949ee82 	ldr	x2, [x20, #5080]
    5f20:	cb010001 	sub	x1, x0, x1
    5f24:	eb02403f 	cmp	x1, x2, lsl #16
    5f28:	54000382 	b.cs	5f98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f2c:	d350fc22 	lsr	x2, x1, #16
    5f30:	f949fe84 	ldr	x4, [x20, #5112]
    5f34:	8b020842 	add	x2, x2, x2, lsl #2
    5f38:	d37df042 	lsl	x2, x2, #3
    5f3c:	8b020083 	add	x3, x4, x2
    5f40:	f9401073 	ldr	x19, [x3, #32]
    5f44:	b40002b3 	cbz	x19, 5f98 <fwp_drop0+0x98>
    5f48:	38626882 	ldrb	w2, [x4, x2]
    5f4c:	7100085f 	cmp	w2, #0x2
    5f50:	540002c0 	b.eq	5fa8 <fwp_drop0+0xa8>  // b.none
    5f54:	7100045f 	cmp	w2, #0x1
    5f58:	54000201 	b.ne	5f98 <fwp_drop0+0x98>  // b.any
    5f5c:	29430864 	ldp	w4, w2, [x3, #24]
    5f60:	92403c21 	and	x1, x1, #0xffff
    5f64:	9b047c21 	mul	x1, x1, x4
    5f68:	d360fc21 	lsr	x1, x1, #32
    5f6c:	eb02003f 	cmp	x1, x2
    5f70:	54000142 	b.cs	5f98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f74:	8b010273 	add	x19, x19, x1
    5f78:	39400261 	ldrb	w1, [x19]
    5f7c:	340000e1 	cbz	w1, 5f98 <fwp_drop0+0x98>
    5f80:	7100043f 	cmp	w1, #0x1
    5f84:	540001e0 	b.eq	5fc0 <fwp_drop0+0xc0>  // b.none
    5f88:	7103fc3f 	cmp	w1, #0xff
    5f8c:	540002e0 	b.eq	5fe8 <fwp_drop0+0xe8>  // b.none
    5f90:	51000421 	sub	w1, w1, #0x1
    5f94:	39000261 	strb	w1, [x19]
    5f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f9c:	f94013f5 	ldr	x21, [sp, #32]
    5fa0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fa4:	d65f03c0 	ret
    5fa8:	72003c3f 	tst	w1, #0xffff
    5fac:	54fffe60 	b.eq	5f78 <fwp_drop0+0x78>  // b.none
    5fb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fb4:	f94013f5 	ldr	x21, [sp, #32]
    5fb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fbc:	d65f03c0 	ret
    5fc0:	f9400813 	ldr	x19, [x0, #16]
    5fc4:	97fffe9c 	bl	5a34 <fwp_rc_free_arr>
    5fc8:	911542a0 	add	x0, x21, #0x550
    5fcc:	f949d801 	ldr	x1, [x0, #5040]
    5fd0:	f949ec00 	ldr	x0, [x0, #5080]
    5fd4:	cb010261 	sub	x1, x19, x1
    5fd8:	eb00403f 	cmp	x1, x0, lsl #16
    5fdc:	54fffde2 	b.cs	5f98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fe0:	aa1303e0 	mov	x0, x19
    5fe4:	17ffffd2 	b	5f2c <fwp_drop0+0x2c>
    5fe8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fec:	911542b5 	add	x21, x21, #0x550
    5ff0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ff4:	92401c00 	and	x0, x0, #0xff
    5ff8:	910a2402 	add	x2, x0, #0x289
    5ffc:	8b000ea0 	add	x0, x21, x0, lsl #3
    6000:	8b020ea2 	add	x2, x21, x2, lsl #3
    6004:	f94a2400 	ldr	x0, [x0, #5192]
    6008:	b50000a0 	cbnz	x0, 601c <fwp_drop0+0x11c>
    600c:	14000013 	b	6058 <fwp_drop0+0x158>
    6010:	91004002 	add	x2, x0, #0x10
    6014:	f9400800 	ldr	x0, [x0, #16]
    6018:	b4000200 	cbz	x0, 6058 <fwp_drop0+0x158>
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb13003f 	cmp	x1, x19
    6024:	54ffff61 	b.ne	6010 <fwp_drop0+0x110>  // b.any
    6028:	f9400041 	ldr	x1, [x2]
    602c:	f9400420 	ldr	x0, [x1, #8]
    6030:	d1000400 	sub	x0, x0, #0x1
    6034:	f9000420 	str	x0, [x1, #8]
    6038:	f103f81f 	cmp	x0, #0xfe
    603c:	54fffae1 	b.ne	5f98 <fwp_drop0+0x98>  // b.any
    6040:	39400260 	ldrb	w0, [x19]
    6044:	7103fc1f 	cmp	w0, #0xff
    6048:	540000e0 	b.eq	6064 <fwp_drop0+0x164>  // b.none
    604c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6050:	39000260 	strb	w0, [x19]
    6054:	17ffffd1 	b	5f98 <fwp_drop0+0x98>
    6058:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    605c:	91240000 	add	x0, x0, #0x900
    6060:	97fff76c 	bl	3e10 <fwp_trap>
    6064:	aa1303e0 	mov	x0, x19
    6068:	97fff78a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    606c:	17fffff8 	b	604c <fwp_drop0+0x14c>

0000000000006070 <fwp_arg_drop12>:
    6070:	7100003f 	cmp	w1, #0x0
    6074:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6078:	54000041 	b.ne	6080 <fwp_arg_drop12+0x10>  // b.any
    607c:	d65f03c0 	ret
    6080:	f9400000 	ldr	x0, [x0]
    6084:	17ffff9f 	b	5f00 <fwp_drop0>
    6088:	d503201f 	nop
    608c:	d503201f 	nop

0000000000006090 <fwp_closure_drop>:
    6090:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc90>
    6094:	911540a4 	add	x4, x5, #0x550
    6098:	aa0003e1 	mov	x1, x0
    609c:	f949d882 	ldr	x2, [x4, #5040]
    60a0:	f949ec80 	ldr	x0, [x4, #5080]
    60a4:	cb020022 	sub	x2, x1, x2
    60a8:	eb00405f 	cmp	x2, x0, lsl #16
    60ac:	54000662 	b.cs	6178 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    60b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60b4:	d350fc43 	lsr	x3, x2, #16
    60b8:	910003fd 	mov	x29, sp
    60bc:	8b030863 	add	x3, x3, x3, lsl #2
    60c0:	f949fc84 	ldr	x4, [x4, #5112]
    60c4:	d37df063 	lsl	x3, x3, #3
    60c8:	f9000bf3 	str	x19, [sp, #16]
    60cc:	8b030080 	add	x0, x4, x3
    60d0:	f9401013 	ldr	x19, [x0, #32]
    60d4:	b40002b3 	cbz	x19, 6128 <fwp_closure_drop+0x98>
    60d8:	38636883 	ldrb	w3, [x4, x3]
    60dc:	7100087f 	cmp	w3, #0x2
    60e0:	54000420 	b.eq	6164 <fwp_closure_drop+0xd4>  // b.none
    60e4:	7100047f 	cmp	w3, #0x1
    60e8:	54000201 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    60ec:	29430003 	ldp	w3, w0, [x0, #24]
    60f0:	92403c42 	and	x2, x2, #0xffff
    60f4:	9b037c42 	mul	x2, x2, x3
    60f8:	d360fc42 	lsr	x2, x2, #32
    60fc:	eb00005f 	cmp	x2, x0
    6100:	54000142 	b.cs	6128 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6104:	8b020273 	add	x19, x19, x2
    6108:	39400260 	ldrb	w0, [x19]
    610c:	340000e0 	cbz	w0, 6128 <fwp_closure_drop+0x98>
    6110:	7100041f 	cmp	w0, #0x1
    6114:	54000100 	b.eq	6134 <fwp_closure_drop+0xa4>  // b.none
    6118:	7103fc1f 	cmp	w0, #0xff
    611c:	54000300 	b.eq	617c <fwp_closure_drop+0xec>  // b.none
    6120:	51000400 	sub	w0, w0, #0x1
    6124:	39000260 	strb	w0, [x19]
    6128:	f9400bf3 	ldr	x19, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	d65f03c0 	ret
    6134:	d53bd040 	mrs	x0, tpidr_el0
    6138:	91400000 	add	x0, x0, #0x0, lsl #12
    613c:	91004000 	add	x0, x0, #0x10
    6140:	f9400000 	ldr	x0, [x0]
    6144:	b4000080 	cbz	x0, 6154 <fwp_closure_drop+0xc4>
    6148:	f9400bf3 	ldr	x19, [sp, #16]
    614c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6150:	17fff8ac 	b	4400 <fwp_closure_drop_push>
    6154:	f9400bf3 	ldr	x19, [sp, #16]
    6158:	aa0103e0 	mov	x0, x1
    615c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6160:	17fff8ed 	b	4514 <fwp_closure_drop.part.0>
    6164:	72003c5f 	tst	w2, #0xffff
    6168:	54fffd00 	b.eq	6108 <fwp_closure_drop+0x78>  // b.none
    616c:	f9400bf3 	ldr	x19, [sp, #16]
    6170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6174:	d65f03c0 	ret
    6178:	d65f03c0 	ret
    617c:	ca534660 	eor	x0, x19, x19, lsr #17
    6180:	911540a5 	add	x5, x5, #0x550
    6184:	ca402400 	eor	x0, x0, x0, lsr #9
    6188:	92401c00 	and	x0, x0, #0xff
    618c:	910a2402 	add	x2, x0, #0x289
    6190:	8b000ca0 	add	x0, x5, x0, lsl #3
    6194:	8b020ca2 	add	x2, x5, x2, lsl #3
    6198:	f94a2400 	ldr	x0, [x0, #5192]
    619c:	b50000a0 	cbnz	x0, 61b0 <fwp_closure_drop+0x120>
    61a0:	14000013 	b	61ec <fwp_closure_drop+0x15c>
    61a4:	91004002 	add	x2, x0, #0x10
    61a8:	f9400800 	ldr	x0, [x0, #16]
    61ac:	b4000200 	cbz	x0, 61ec <fwp_closure_drop+0x15c>
    61b0:	f9400001 	ldr	x1, [x0]
    61b4:	eb13003f 	cmp	x1, x19
    61b8:	54ffff61 	b.ne	61a4 <fwp_closure_drop+0x114>  // b.any
    61bc:	f9400041 	ldr	x1, [x2]
    61c0:	f9400420 	ldr	x0, [x1, #8]
    61c4:	d1000400 	sub	x0, x0, #0x1
    61c8:	f9000420 	str	x0, [x1, #8]
    61cc:	f103f81f 	cmp	x0, #0xfe
    61d0:	54fffac1 	b.ne	6128 <fwp_closure_drop+0x98>  // b.any
    61d4:	39400260 	ldrb	w0, [x19]
    61d8:	7103fc1f 	cmp	w0, #0xff
    61dc:	540000e0 	b.eq	61f8 <fwp_closure_drop+0x168>  // b.none
    61e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61e4:	39000260 	strb	w0, [x19]
    61e8:	17ffffd0 	b	6128 <fwp_closure_drop+0x98>
    61ec:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    61f0:	91240000 	add	x0, x0, #0x900
    61f4:	97fff707 	bl	3e10 <fwp_trap>
    61f8:	aa1303e0 	mov	x0, x19
    61fc:	97fff725 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6200:	17fffff8 	b	61e0 <fwp_closure_drop+0x150>

0000000000006204 <fwp_owned_tape_release>:
    6204:	b4000920 	cbz	x0, 6328 <fwp_owned_tape_release+0x124>
    6208:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    620c:	910003fd 	mov	x29, sp
    6210:	a90153f3 	stp	x19, x20, [sp, #16]
    6214:	aa0003f3 	mov	x19, x0
    6218:	f9400000 	ldr	x0, [x0]
    621c:	b4000060 	cbz	x0, 6228 <fwp_owned_tape_release+0x24>
    6220:	f9400661 	ldr	x1, [x19, #8]
    6224:	f9000401 	str	x1, [x0, #8]
    6228:	f9400661 	ldr	x1, [x19, #8]
    622c:	b4000041 	cbz	x1, 6234 <fwp_owned_tape_release+0x30>
    6230:	f9000020 	str	x0, [x1]
    6234:	f9400a60 	ldr	x0, [x19, #16]
    6238:	f9403401 	ldr	x1, [x0, #104]
    623c:	b40005a1 	cbz	x1, 62f0 <fwp_owned_tape_release+0xec>
    6240:	a9450a60 	ldp	x0, x2, [x19, #80]
    6244:	eb00005f 	cmp	x2, x0
    6248:	540002cd 	b.le	62a0 <fwp_owned_tape_release+0x9c>
    624c:	d2800014 	mov	x20, #0x0                   	// #0
    6250:	f90013f5 	str	x21, [sp, #32]
    6254:	d2800015 	mov	x21, #0x0                   	// #0
    6258:	f9402260 	ldr	x0, [x19, #64]
    625c:	910006b5 	add	x21, x21, #0x1
    6260:	f8746800 	ldr	x0, [x0, x20]
    6264:	d63f0020 	blr	x1
    6268:	f9402260 	ldr	x0, [x19, #64]
    626c:	f9400a61 	ldr	x1, [x19, #16]
    6270:	8b140000 	add	x0, x0, x20
    6274:	91004294 	add	x20, x20, #0x10
    6278:	f9400400 	ldr	x0, [x0, #8]
    627c:	f9403421 	ldr	x1, [x1, #104]
    6280:	d63f0020 	blr	x1
    6284:	a9450261 	ldp	x1, x0, [x19, #80]
    6288:	cb010000 	sub	x0, x0, x1
    628c:	eb15001f 	cmp	x0, x21
    6290:	f9400a60 	ldr	x0, [x19, #16]
    6294:	f9403401 	ldr	x1, [x0, #104]
    6298:	54fffe0c 	b.gt	6258 <fwp_owned_tape_release+0x54>
    629c:	f94013f5 	ldr	x21, [sp, #32]
    62a0:	f9403663 	ldr	x3, [x19, #104]
    62a4:	f9401262 	ldr	x2, [x19, #32]
    62a8:	f100007f 	cmp	x3, #0x0
    62ac:	540001ed 	b.le	62e8 <fwp_owned_tape_release+0xe4>
    62b0:	d2800014 	mov	x20, #0x0                   	// #0
    62b4:	d503201f 	nop
    62b8:	f9402660 	ldr	x0, [x19, #72]
    62bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    62c0:	eb02001f 	cmp	x0, x2
    62c4:	540000c0 	b.eq	62dc <fwp_owned_tape_release+0xd8>  // b.none
    62c8:	d63f0020 	blr	x1
    62cc:	f9400a60 	ldr	x0, [x19, #16]
    62d0:	f9401262 	ldr	x2, [x19, #32]
    62d4:	f9403663 	ldr	x3, [x19, #104]
    62d8:	f9403401 	ldr	x1, [x0, #104]
    62dc:	91000694 	add	x20, x20, #0x1
    62e0:	eb14007f 	cmp	x3, x20
    62e4:	54fffeac 	b.gt	62b8 <fwp_owned_tape_release+0xb4>
    62e8:	aa0203e0 	mov	x0, x2
    62ec:	d63f0020 	blr	x1
    62f0:	f9401660 	ldr	x0, [x19, #40]
    62f4:	97ffff67 	bl	6090 <fwp_closure_drop>
    62f8:	f9401a60 	ldr	x0, [x19, #48]
    62fc:	97ffff65 	bl	6090 <fwp_closure_drop>
    6300:	f9401e60 	ldr	x0, [x19, #56]
    6304:	97ffff63 	bl	6090 <fwp_closure_drop>
    6308:	f9402260 	ldr	x0, [x19, #64]
    630c:	97fff77d 	bl	4100 <fwp_mem_free>
    6310:	f9402660 	ldr	x0, [x19, #72]
    6314:	97fff77b 	bl	4100 <fwp_mem_free>
    6318:	aa1303e0 	mov	x0, x19
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6324:	17fff777 	b	4100 <fwp_mem_free>
    6328:	d65f03c0 	ret
    632c:	d503201f 	nop

0000000000006330 <fwp_tape_finish>:
    6330:	d10203ff 	sub	sp, sp, #0x80
    6334:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6338:	f947f421 	ldr	x1, [x1, #4072]
    633c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6340:	910103fd 	add	x29, sp, #0x40
    6344:	a90553f3 	stp	x19, x20, [sp, #80]
    6348:	a9065bf5 	stp	x21, x22, [sp, #96]
    634c:	a90763f7 	stp	x23, x24, [sp, #112]
    6350:	d00000d8 	adrp	x24, 20000 <__data_start>
    6354:	91010316 	add	x22, x24, #0x40
    6358:	f9400022 	ldr	x2, [x1]
    635c:	f9001fe2 	str	x2, [sp, #56]
    6360:	d2800002 	mov	x2, #0x0                   	// #0
    6364:	9100e2c0 	add	x0, x22, #0x38
    6368:	97fff3c6 	bl	3280 <fwp_tape_buffers_dispose>
    636c:	f9003adf 	str	xzr, [x22, #112]
    6370:	f94042c0 	ldr	x0, [x22, #128]
    6374:	f100001f 	cmp	x0, #0x0
    6378:	5400030d 	b.le	63d8 <fwp_tape_finish+0xa8>
    637c:	910003f7 	mov	x23, sp
    6380:	d2800015 	mov	x21, #0x0                   	// #0
    6384:	d2800014 	mov	x20, #0x0                   	// #0
    6388:	f94002d3 	ldr	x19, [x22]
    638c:	91000694 	add	x20, x20, #0x1
    6390:	8b150273 	add	x19, x19, x21
    6394:	9101a2b5 	add	x21, x21, #0x68
    6398:	aa1303e0 	mov	x0, x19
    639c:	97fff2dd 	bl	2f10 <fwp_tape_unlink_scope>
    63a0:	aa1703e0 	mov	x0, x23
    63a4:	f9401261 	ldr	x1, [x19, #32]
    63a8:	f90003e1 	str	x1, [sp]
    63ac:	f9401a62 	ldr	x2, [x19, #48]
    63b0:	f9000be2 	str	x2, [sp, #16]
    63b4:	f9402261 	ldr	x1, [x19, #64]
    63b8:	f90013e1 	str	x1, [sp, #32]
    63bc:	97fff3b1 	bl	3280 <fwp_tape_buffers_dispose>
    63c0:	f9403260 	ldr	x0, [x19, #96]
    63c4:	97ffff90 	bl	6204 <fwp_owned_tape_release>
    63c8:	f900327f 	str	xzr, [x19, #96]
    63cc:	f94042c0 	ldr	x0, [x22, #128]
    63d0:	eb14001f 	cmp	x0, x20
    63d4:	54fffdac 	b.gt	6388 <fwp_tape_finish+0x58>
    63d8:	f9402300 	ldr	x0, [x24, #64]
    63dc:	91010313 	add	x19, x24, #0x40
    63e0:	97fff134 	bl	28b0 <free@plt>
    63e4:	f900231f 	str	xzr, [x24, #64]
    63e8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    63ec:	f947f400 	ldr	x0, [x0, #4072]
    63f0:	f900427f 	str	xzr, [x19, #128]
    63f4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    63f8:	f9401fe2 	ldr	x2, [sp, #56]
    63fc:	f9400001 	ldr	x1, [x0]
    6400:	eb010042 	subs	x2, x2, x1
    6404:	d2800001 	mov	x1, #0x0                   	// #0
    6408:	540000e1 	b.ne	6424 <fwp_tape_finish+0xf4>  // b.any
    640c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6410:	a94553f3 	ldp	x19, x20, [sp, #80]
    6414:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6418:	a94763f7 	ldp	x23, x24, [sp, #112]
    641c:	910203ff 	add	sp, sp, #0x80
    6420:	d65f03c0 	ret
    6424:	97fff0f3 	bl	27f0 <__stack_chk_fail@plt>
    6428:	d503201f 	nop
    642c:	d503201f 	nop

0000000000006430 <fwp_tape_scope_release>:
    6430:	d10243ff 	sub	sp, sp, #0x90
    6434:	a9047bfd 	stp	x29, x30, [sp, #64]
    6438:	910103fd 	add	x29, sp, #0x40
    643c:	a90553f3 	stp	x19, x20, [sp, #80]
    6440:	aa0003f4 	mov	x20, x0
    6444:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6448:	f947f400 	ldr	x0, [x0, #4072]
    644c:	b9400285 	ldr	w5, [x20]
    6450:	f9400001 	ldr	x1, [x0]
    6454:	f9001fe1 	str	x1, [sp, #56]
    6458:	d2800001 	mov	x1, #0x0                   	// #0
    645c:	37f806c5 	tbnz	w5, #31, 6534 <fwp_tape_scope_release+0x104>
    6460:	a90763f7 	stp	x23, x24, [sp, #112]
    6464:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6468:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    646c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6470:	d00000d3 	adrp	x19, 20000 <__data_start>
    6474:	910003f7 	mov	x23, sp
    6478:	91010273 	add	x19, x19, #0x40
    647c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6480:	a9065bf5 	stp	x21, x22, [sp, #96]
    6484:	52800d16 	mov	w22, #0x68                  	// #104
    6488:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    648c:	f90043f9 	str	x25, [sp, #128]
    6490:	14000006 	b	64a8 <fwp_tape_scope_release+0x78>
    6494:	97fff37b 	bl	3280 <fwp_tape_buffers_dispose>
    6498:	aa1903e0 	mov	x0, x25
    649c:	97ffff5a 	bl	6204 <fwp_owned_tape_release>
    64a0:	b9400285 	ldr	w5, [x20]
    64a4:	37f80425 	tbnz	w5, #31, 6528 <fwp_tape_scope_release+0xf8>
    64a8:	f9400266 	ldr	x6, [x19]
    64ac:	9b367ca5 	smull	x5, w5, w22
    64b0:	8b0500c0 	add	x0, x6, x5
    64b4:	97fff297 	bl	2f10 <fwp_tape_unlink_scope>
    64b8:	ad410001 	ldp	q1, q0, [x0, #32]
    64bc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    64c0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    64c4:	f9400c03 	ldr	x3, [x0, #24]
    64c8:	ad0003e1 	stp	q1, q0, [sp]
    64cc:	b86568c1 	ldr	w1, [x6, x5]
    64d0:	a9440804 	ldp	x4, x2, [x0, #64]
    64d4:	b900041f 	str	wzr, [x0, #4]
    64d8:	f9403019 	ldr	x25, [x0, #96]
    64dc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    64e0:	f9000c1f 	str	xzr, [x0, #24]
    64e4:	a9020fe4 	stp	x4, x3, [sp, #32]
    64e8:	f9001be2 	str	x2, [sp, #48]
    64ec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    64f0:	f900301f 	str	xzr, [x0, #96]
    64f4:	6b15003f 	cmp	w1, w21
    64f8:	540000e8 	b.hi	6514 <fwp_tape_scope_release+0xe4>  // b.pmore
    64fc:	9343fca5 	asr	x5, x5, #3
    6500:	f9404e60 	ldr	x0, [x19, #152]
    6504:	9b187ca5 	mul	x5, x5, x24
    6508:	eb0000bf 	cmp	x5, x0
    650c:	5400004a 	b.ge	6514 <fwp_tape_scope_release+0xe4>  // b.tcont
    6510:	f9004e65 	str	x5, [x19, #152]
    6514:	aa1703e0 	mov	x0, x23
    6518:	b5fffbf9 	cbnz	x25, 6494 <fwp_tape_scope_release+0x64>
    651c:	97fff5f5 	bl	3cf0 <fwp_tape_buffers_release>
    6520:	b9400285 	ldr	w5, [x20]
    6524:	36fffc25 	tbz	w5, #31, 64a8 <fwp_tape_scope_release+0x78>
    6528:	a9465bf5 	ldp	x21, x22, [sp, #96]
    652c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6530:	f94043f9 	ldr	x25, [sp, #128]
    6534:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6538:	f947f400 	ldr	x0, [x0, #4072]
    653c:	f9401fe2 	ldr	x2, [sp, #56]
    6540:	f9400001 	ldr	x1, [x0]
    6544:	eb010042 	subs	x2, x2, x1
    6548:	d2800001 	mov	x1, #0x0                   	// #0
    654c:	540000a1 	b.ne	6560 <fwp_tape_scope_release+0x130>  // b.any
    6550:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6554:	a94553f3 	ldp	x19, x20, [sp, #80]
    6558:	910243ff 	add	sp, sp, #0x90
    655c:	d65f03c0 	ret
    6560:	a9065bf5 	stp	x21, x22, [sp, #96]
    6564:	a90763f7 	stp	x23, x24, [sp, #112]
    6568:	f90043f9 	str	x25, [sp, #128]
    656c:	97fff0a1 	bl	27f0 <__stack_chk_fail@plt>

0000000000006570 <fwp_task_dispose>:
    6570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6574:	910003fd 	mov	x29, sp
    6578:	f9000bf3 	str	x19, [sp, #16]
    657c:	aa0003f3 	mov	x19, x0
    6580:	39414000 	ldrb	w0, [x0, #80]
    6584:	36000720 	tbz	w0, #0, 6668 <fwp_task_dispose+0xf8>
    6588:	f9400a60 	ldr	x0, [x19, #16]
    658c:	b50006e0 	cbnz	x0, 6668 <fwp_task_dispose+0xf8>
    6590:	a9478660 	ldp	x0, x1, [x19, #120]
    6594:	39014e7f 	strb	wzr, [x19, #83]
    6598:	f9003e7f 	str	xzr, [x19, #120]
    659c:	f100003f 	cmp	x1, #0x0
    65a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65a4:	54000040 	b.eq	65ac <fwp_task_dispose+0x3c>  // b.none
    65a8:	d63f0020 	blr	x1
    65ac:	f9405660 	ldr	x0, [x19, #168]
    65b0:	97fff6d4 	bl	4100 <fwp_mem_free>
    65b4:	f900567f 	str	xzr, [x19, #168]
    65b8:	b9405e60 	ldr	w0, [x19, #92]
    65bc:	7100041f 	cmp	w0, #0x1
    65c0:	54000420 	b.eq	6644 <fwp_task_dispose+0xd4>  // b.none
    65c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    65c8:	91154042 	add	x2, x2, #0x550
    65cc:	f949d840 	ldr	x0, [x2, #5040]
    65d0:	f949ec41 	ldr	x1, [x2, #5080]
    65d4:	cb000260 	sub	x0, x19, x0
    65d8:	eb01401f 	cmp	x0, x1, lsl #16
    65dc:	540002e2 	b.cs	6638 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65e0:	d350fc01 	lsr	x1, x0, #16
    65e4:	f949fc44 	ldr	x4, [x2, #5112]
    65e8:	8b010821 	add	x1, x1, x1, lsl #2
    65ec:	d37df021 	lsl	x1, x1, #3
    65f0:	8b010083 	add	x3, x4, x1
    65f4:	f9401062 	ldr	x2, [x3, #32]
    65f8:	b4000202 	cbz	x2, 6638 <fwp_task_dispose+0xc8>
    65fc:	38616881 	ldrb	w1, [x4, x1]
    6600:	7100083f 	cmp	w1, #0x2
    6604:	54000280 	b.eq	6654 <fwp_task_dispose+0xe4>  // b.none
    6608:	7100043f 	cmp	w1, #0x1
    660c:	54000161 	b.ne	6638 <fwp_task_dispose+0xc8>  // b.any
    6610:	29430464 	ldp	w4, w1, [x3, #24]
    6614:	92403c00 	and	x0, x0, #0xffff
    6618:	9b047c00 	mul	x0, x0, x4
    661c:	d360fc00 	lsr	x0, x0, #32
    6620:	eb01001f 	cmp	x0, x1
    6624:	540000a2 	b.cs	6638 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6628:	8b000042 	add	x2, x2, x0
    662c:	39400040 	ldrb	w0, [x2]
    6630:	7100041f 	cmp	w0, #0x1
    6634:	54000080 	b.eq	6644 <fwp_task_dispose+0xd4>  // b.none
    6638:	f9400bf3 	ldr	x19, [sp, #16]
    663c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6640:	d65f03c0 	ret
    6644:	aa1303e0 	mov	x0, x19
    6648:	f9400bf3 	ldr	x19, [sp, #16]
    664c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6650:	17fff6ac 	b	4100 <fwp_mem_free>
    6654:	72003c1f 	tst	w0, #0xffff
    6658:	54fffea0 	b.eq	662c <fwp_task_dispose+0xbc>  // b.none
    665c:	f9400bf3 	ldr	x19, [sp, #16]
    6660:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6664:	d65f03c0 	ret
    6668:	97fff076 	bl	2840 <abort@plt>
    666c:	d503201f 	nop

0000000000006670 <fwp_free_zombie>:
    6670:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6674:	910003fd 	mov	x29, sp
    6678:	a90153f3 	stp	x19, x20, [sp, #16]
    667c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6680:	91010281 	add	x1, x20, #0x40
    6684:	f9405033 	ldr	x19, [x1, #160]
    6688:	b4000333 	cbz	x19, 66ec <fwp_free_zombie+0x7c>
    668c:	f9400820 	ldr	x0, [x1, #16]
    6690:	eb00027f 	cmp	x19, x0
    6694:	540002c0 	b.eq	66ec <fwp_free_zombie+0x7c>  // b.none
    6698:	b940a822 	ldr	w2, [x1, #168]
    669c:	f9400a60 	ldr	x0, [x19, #16]
    66a0:	7100fc5f 	cmp	w2, #0x3f
    66a4:	5400078c 	b.gt	6794 <fwp_free_zombie+0x124>
    66a8:	9102c023 	add	x3, x1, #0xb0
    66ac:	11000444 	add	w4, w2, #0x1
    66b0:	b900a824 	str	w4, [x1, #168]
    66b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66bc:	a9530261 	ldp	x1, x0, [x19, #304]
    66c0:	b4000741 	cbz	x1, 67a8 <fwp_free_zombie+0x138>
    66c4:	f9009c20 	str	x0, [x1, #312]
    66c8:	b4000040 	cbz	x0, 66d0 <fwp_free_zombie+0x60>
    66cc:	f9009801 	str	x1, [x0, #304]
    66d0:	91010294 	add	x20, x20, #0x40
    66d4:	b9405e60 	ldr	w0, [x19, #92]
    66d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    66dc:	f900529f 	str	xzr, [x20, #160]
    66e0:	34000140 	cbz	w0, 6708 <fwp_free_zombie+0x98>
    66e4:	7100041f 	cmp	w0, #0x1
    66e8:	54000080 	b.eq	66f8 <fwp_free_zombie+0x88>  // b.none
    66ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    66f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66f4:	d65f03c0 	ret
    66f8:	aa1303e0 	mov	x0, x19
    66fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6700:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6704:	17ffff9b 	b	6570 <fwp_task_dispose>
    6708:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    670c:	91154082 	add	x2, x4, #0x550
    6710:	f949d841 	ldr	x1, [x2, #5040]
    6714:	f949ec40 	ldr	x0, [x2, #5080]
    6718:	cb010261 	sub	x1, x19, x1
    671c:	eb00403f 	cmp	x1, x0, lsl #16
    6720:	54fffe62 	b.cs	66ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6724:	d350fc20 	lsr	x0, x1, #16
    6728:	f949fc43 	ldr	x3, [x2, #5112]
    672c:	8b000800 	add	x0, x0, x0, lsl #2
    6730:	d37df000 	lsl	x0, x0, #3
    6734:	8b000062 	add	x2, x3, x0
    6738:	f9401054 	ldr	x20, [x2, #32]
    673c:	b4fffd94 	cbz	x20, 66ec <fwp_free_zombie+0x7c>
    6740:	38606860 	ldrb	w0, [x3, x0]
    6744:	7100081f 	cmp	w0, #0x2
    6748:	54000360 	b.eq	67b4 <fwp_free_zombie+0x144>  // b.none
    674c:	7100041f 	cmp	w0, #0x1
    6750:	54fffce1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    6754:	29430043 	ldp	w3, w0, [x2, #24]
    6758:	92403c21 	and	x1, x1, #0xffff
    675c:	9b037c21 	mul	x1, x1, x3
    6760:	d360fc21 	lsr	x1, x1, #32
    6764:	eb00003f 	cmp	x1, x0
    6768:	54fffc22 	b.cs	66ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    676c:	8b010294 	add	x20, x20, x1
    6770:	39400280 	ldrb	w0, [x20]
    6774:	34fffbc0 	cbz	w0, 66ec <fwp_free_zombie+0x7c>
    6778:	7100041f 	cmp	w0, #0x1
    677c:	54fffbe0 	b.eq	66f8 <fwp_free_zombie+0x88>  // b.none
    6780:	7103fc1f 	cmp	w0, #0xff
    6784:	540001e0 	b.eq	67c0 <fwp_free_zombie+0x150>  // b.none
    6788:	51000400 	sub	w0, w0, #0x1
    678c:	39000280 	strb	w0, [x20]
    6790:	17ffffd7 	b	66ec <fwp_free_zombie+0x7c>
    6794:	f9400e61 	ldr	x1, [x19, #24]
    6798:	97fff05e 	bl	2910 <munmap@plt>
    679c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67a0:	a9530261 	ldp	x1, x0, [x19, #304]
    67a4:	b5fff901 	cbnz	x1, 66c4 <fwp_free_zombie+0x54>
    67a8:	91010282 	add	x2, x20, #0x40
    67ac:	f9015840 	str	x0, [x2, #688]
    67b0:	17ffffc6 	b	66c8 <fwp_free_zombie+0x58>
    67b4:	72003c3f 	tst	w1, #0xffff
    67b8:	54fff9a1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    67bc:	17ffffed 	b	6770 <fwp_free_zombie+0x100>
    67c0:	ca544680 	eor	x0, x20, x20, lsr #17
    67c4:	91154084 	add	x4, x4, #0x550
    67c8:	ca402400 	eor	x0, x0, x0, lsr #9
    67cc:	92401c00 	and	x0, x0, #0xff
    67d0:	910a2402 	add	x2, x0, #0x289
    67d4:	8b000c80 	add	x0, x4, x0, lsl #3
    67d8:	8b020c82 	add	x2, x4, x2, lsl #3
    67dc:	f94a2400 	ldr	x0, [x0, #5192]
    67e0:	b50000a0 	cbnz	x0, 67f4 <fwp_free_zombie+0x184>
    67e4:	14000013 	b	6830 <fwp_free_zombie+0x1c0>
    67e8:	91004002 	add	x2, x0, #0x10
    67ec:	f9400800 	ldr	x0, [x0, #16]
    67f0:	b4000200 	cbz	x0, 6830 <fwp_free_zombie+0x1c0>
    67f4:	f9400001 	ldr	x1, [x0]
    67f8:	eb14003f 	cmp	x1, x20
    67fc:	54ffff61 	b.ne	67e8 <fwp_free_zombie+0x178>  // b.any
    6800:	f9400041 	ldr	x1, [x2]
    6804:	f9400420 	ldr	x0, [x1, #8]
    6808:	d1000400 	sub	x0, x0, #0x1
    680c:	f9000420 	str	x0, [x1, #8]
    6810:	f103f81f 	cmp	x0, #0xfe
    6814:	54fff6c1 	b.ne	66ec <fwp_free_zombie+0x7c>  // b.any
    6818:	39400280 	ldrb	w0, [x20]
    681c:	7103fc1f 	cmp	w0, #0xff
    6820:	540000e0 	b.eq	683c <fwp_free_zombie+0x1cc>  // b.none
    6824:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6828:	39000280 	strb	w0, [x20]
    682c:	17ffffb0 	b	66ec <fwp_free_zombie+0x7c>
    6830:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    6834:	91240000 	add	x0, x0, #0x900
    6838:	97fff576 	bl	3e10 <fwp_trap>
    683c:	aa1403e0 	mov	x0, x20
    6840:	97fff594 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6844:	17fffff8 	b	6824 <fwp_free_zombie+0x1b4>
    6848:	d503201f 	nop
    684c:	d503201f 	nop

0000000000006850 <fwp_block>:
    6850:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6854:	910003fd 	mov	x29, sp
    6858:	a90153f3 	stp	x19, x20, [sp, #16]
    685c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6860:	91010274 	add	x20, x19, #0x40
    6864:	f9401a82 	ldr	x2, [x20, #48]
    6868:	b4000642 	cbz	x2, 6930 <fwp_block+0xe0>
    686c:	91010261 	add	x1, x19, #0x40
    6870:	f9408040 	ldr	x0, [x2, #256]
    6874:	f9001820 	str	x0, [x1, #48]
    6878:	b40006a0 	cbz	x0, 694c <fwp_block+0xfc>
    687c:	d503201f 	nop
    6880:	91010263 	add	x3, x19, #0x40
    6884:	3901505f 	strb	wzr, [x2, #84]
    6888:	f9400864 	ldr	x4, [x3, #16]
    688c:	eb02009f 	cmp	x4, x2
    6890:	54000440 	b.eq	6918 <fwp_block+0xc8>  // b.none
    6894:	f9415c65 	ldr	x5, [x3, #696]
    6898:	f9000862 	str	x2, [x3, #16]
    689c:	f9400441 	ldr	x1, [x2, #8]
    68a0:	f9004885 	str	x5, [x4, #144]
    68a4:	f9416065 	ldr	x5, [x3, #704]
    68a8:	f9004c85 	str	x5, [x4, #152]
    68ac:	f9416465 	ldr	x5, [x3, #712]
    68b0:	f9005085 	str	x5, [x4, #160]
    68b4:	f9416865 	ldr	x5, [x3, #720]
    68b8:	f9005485 	str	x5, [x4, #168]
    68bc:	f9416c65 	ldr	x5, [x3, #728]
    68c0:	f9005885 	str	x5, [x4, #176]
    68c4:	f9417065 	ldr	x5, [x3, #736]
    68c8:	f9005c85 	str	x5, [x4, #184]
    68cc:	f9417465 	ldr	x5, [x3, #744]
    68d0:	f9006085 	str	x5, [x4, #192]
    68d4:	f9400480 	ldr	x0, [x4, #8]
    68d8:	f9404844 	ldr	x4, [x2, #144]
    68dc:	f9015c64 	str	x4, [x3, #696]
    68e0:	f9404c44 	ldr	x4, [x2, #152]
    68e4:	f9016064 	str	x4, [x3, #704]
    68e8:	f9405044 	ldr	x4, [x2, #160]
    68ec:	f9016464 	str	x4, [x3, #712]
    68f0:	f9405444 	ldr	x4, [x2, #168]
    68f4:	f9016864 	str	x4, [x3, #720]
    68f8:	f9405844 	ldr	x4, [x2, #176]
    68fc:	f9016c64 	str	x4, [x3, #728]
    6900:	a94b8844 	ldp	x4, x2, [x2, #184]
    6904:	f9017064 	str	x4, [x3, #736]
    6908:	f9017462 	str	x2, [x3, #744]
    690c:	97ffefd1 	bl	2850 <swapcontext@plt>
    6910:	97ffff58 	bl	6670 <fwp_free_zombie>
    6914:	d503201f 	nop
    6918:	91010260 	add	x0, x19, #0x40
    691c:	b942f000 	ldr	w0, [x0, #752]
    6920:	340001a0 	cbz	w0, 6954 <fwp_block+0x104>
    6924:	a94153f3 	ldp	x19, x20, [sp, #16]
    6928:	a8c27bfd 	ldp	x29, x30, [sp], #32
    692c:	d65f03c0 	ret
    6930:	97fff780 	bl	4730 <fwp_poll_events>
    6934:	f9401a82 	ldr	x2, [x20, #48]
    6938:	b4ffffc2 	cbz	x2, 6930 <fwp_block+0xe0>
    693c:	91010261 	add	x1, x19, #0x40
    6940:	f9408040 	ldr	x0, [x2, #256]
    6944:	f9001820 	str	x0, [x1, #48]
    6948:	b5fff9c0 	cbnz	x0, 6880 <fwp_block+0x30>
    694c:	f900143f 	str	xzr, [x1, #40]
    6950:	17ffffcc 	b	6880 <fwp_block+0x30>
    6954:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    6958:	912e6000 	add	x0, x0, #0xb98
    695c:	97fff009 	bl	2980 <getenv@plt>
    6960:	5284e202 	mov	w2, #0x2710                	// #10000
    6964:	b4000060 	cbz	x0, 6970 <fwp_block+0x120>
    6968:	39400001 	ldrb	w1, [x0]
    696c:	350000c1 	cbnz	w1, 6984 <fwp_block+0x134>
    6970:	91010273 	add	x19, x19, #0x40
    6974:	b902f262 	str	w2, [x19, #752]
    6978:	a94153f3 	ldp	x19, x20, [sp, #16]
    697c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6980:	d65f03c0 	ret
    6984:	52800142 	mov	w2, #0xa                   	// #10
    6988:	d2800001 	mov	x1, #0x0                   	// #0
    698c:	97ffef4d 	bl	26c0 <strtoll@plt>
    6990:	d1000403 	sub	x3, x0, #0x1
    6994:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6998:	eb02007f 	cmp	x3, x2
    699c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69a0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69a4:	17fffff3 	b	6970 <fwp_block+0x120>
    69a8:	d503201f 	nop
    69ac:	d503201f 	nop

00000000000069b0 <fwp_drop4>:
    69b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69b4:	910003fd 	mov	x29, sp
    69b8:	a90153f3 	stp	x19, x20, [sp, #16]
    69bc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    69c0:	f90013f5 	str	x21, [sp, #32]
    69c4:	91154275 	add	x21, x19, #0x550
    69c8:	f949daa1 	ldr	x1, [x21, #5040]
    69cc:	f949eea2 	ldr	x2, [x21, #5080]
    69d0:	cb010001 	sub	x1, x0, x1
    69d4:	eb02403f 	cmp	x1, x2, lsl #16
    69d8:	54000382 	b.cs	6a48 <fwp_drop4+0x98>  // b.hs, b.nlast
    69dc:	d350fc22 	lsr	x2, x1, #16
    69e0:	f949fea3 	ldr	x3, [x21, #5112]
    69e4:	8b020842 	add	x2, x2, x2, lsl #2
    69e8:	d37df042 	lsl	x2, x2, #3
    69ec:	8b020064 	add	x4, x3, x2
    69f0:	f9401094 	ldr	x20, [x4, #32]
    69f4:	b40002b4 	cbz	x20, 6a48 <fwp_drop4+0x98>
    69f8:	38626862 	ldrb	w2, [x3, x2]
    69fc:	7100085f 	cmp	w2, #0x2
    6a00:	540007a0 	b.eq	6af4 <fwp_drop4+0x144>  // b.none
    6a04:	7100045f 	cmp	w2, #0x1
    6a08:	54000201 	b.ne	6a48 <fwp_drop4+0x98>  // b.any
    6a0c:	29430885 	ldp	w5, w2, [x4, #24]
    6a10:	92403c21 	and	x1, x1, #0xffff
    6a14:	9b057c21 	mul	x1, x1, x5
    6a18:	d360fc21 	lsr	x1, x1, #32
    6a1c:	eb02003f 	cmp	x1, x2
    6a20:	54000142 	b.cs	6a48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a24:	8b010294 	add	x20, x20, x1
    6a28:	39400281 	ldrb	w1, [x20]
    6a2c:	340000e1 	cbz	w1, 6a48 <fwp_drop4+0x98>
    6a30:	7100043f 	cmp	w1, #0x1
    6a34:	54000120 	b.eq	6a58 <fwp_drop4+0xa8>  // b.none
    6a38:	7103fc3f 	cmp	w1, #0xff
    6a3c:	540007c0 	b.eq	6b34 <fwp_drop4+0x184>  // b.none
    6a40:	51000421 	sub	w1, w1, #0x1
    6a44:	39000281 	strb	w1, [x20]
    6a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a4c:	f94013f5 	ldr	x21, [sp, #32]
    6a50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a54:	d65f03c0 	ret
    6a58:	f9400001 	ldr	x1, [x0]
    6a5c:	b7f80581 	tbnz	x1, #63, 6b0c <fwp_drop4+0x15c>
    6a60:	91154273 	add	x19, x19, #0x550
    6a64:	f949da61 	ldr	x1, [x19, #5040]
    6a68:	f949ee62 	ldr	x2, [x19, #5080]
    6a6c:	cb010001 	sub	x1, x0, x1
    6a70:	eb02403f 	cmp	x1, x2, lsl #16
    6a74:	54fffea2 	b.cs	6a48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a78:	d350fc22 	lsr	x2, x1, #16
    6a7c:	8b020842 	add	x2, x2, x2, lsl #2
    6a80:	d37df042 	lsl	x2, x2, #3
    6a84:	8b020065 	add	x5, x3, x2
    6a88:	f94010a4 	ldr	x4, [x5, #32]
    6a8c:	b4fffde4 	cbz	x4, 6a48 <fwp_drop4+0x98>
    6a90:	38626862 	ldrb	w2, [x3, x2]
    6a94:	7100085f 	cmp	w2, #0x2
    6a98:	54000220 	b.eq	6adc <fwp_drop4+0x12c>  // b.none
    6a9c:	7100045f 	cmp	w2, #0x1
    6aa0:	54fffd41 	b.ne	6a48 <fwp_drop4+0x98>  // b.any
    6aa4:	294308a3 	ldp	w3, w2, [x5, #24]
    6aa8:	92403c21 	and	x1, x1, #0xffff
    6aac:	9b037c21 	mul	x1, x1, x3
    6ab0:	d360fc21 	lsr	x1, x1, #32
    6ab4:	eb02003f 	cmp	x1, x2
    6ab8:	54fffc82 	b.cs	6a48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6abc:	8b010084 	add	x4, x4, x1
    6ac0:	39400081 	ldrb	w1, [x4]
    6ac4:	7100043f 	cmp	w1, #0x1
    6ac8:	54fffc01 	b.ne	6a48 <fwp_drop4+0x98>  // b.any
    6acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ad0:	f94013f5 	ldr	x21, [sp, #32]
    6ad4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ad8:	17fff58a 	b	4100 <fwp_mem_free>
    6adc:	72003c3f 	tst	w1, #0xffff
    6ae0:	54ffff00 	b.eq	6ac0 <fwp_drop4+0x110>  // b.none
    6ae4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae8:	f94013f5 	ldr	x21, [sp, #32]
    6aec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6af0:	d65f03c0 	ret
    6af4:	72003c3f 	tst	w1, #0xffff
    6af8:	54fff980 	b.eq	6a28 <fwp_drop4+0x78>  // b.none
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	f94013f5 	ldr	x21, [sp, #32]
    6b04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b08:	d65f03c0 	ret
    6b0c:	f9400414 	ldr	x20, [x0, #8]
    6b10:	97fffbc9 	bl	5a34 <fwp_rc_free_arr>
    6b14:	91154260 	add	x0, x19, #0x550
    6b18:	f949d801 	ldr	x1, [x0, #5040]
    6b1c:	f949ec00 	ldr	x0, [x0, #5080]
    6b20:	cb010281 	sub	x1, x20, x1
    6b24:	eb00403f 	cmp	x1, x0, lsl #16
    6b28:	54fff902 	b.cs	6a48 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b2c:	aa1403e0 	mov	x0, x20
    6b30:	17ffffab 	b	69dc <fwp_drop4+0x2c>
    6b34:	ca544680 	eor	x0, x20, x20, lsr #17
    6b38:	91154273 	add	x19, x19, #0x550
    6b3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b40:	92401c00 	and	x0, x0, #0xff
    6b44:	910a2402 	add	x2, x0, #0x289
    6b48:	8b000e60 	add	x0, x19, x0, lsl #3
    6b4c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b50:	f94a2400 	ldr	x0, [x0, #5192]
    6b54:	b50000a0 	cbnz	x0, 6b68 <fwp_drop4+0x1b8>
    6b58:	14000013 	b	6ba4 <fwp_drop4+0x1f4>
    6b5c:	91004002 	add	x2, x0, #0x10
    6b60:	f9400800 	ldr	x0, [x0, #16]
    6b64:	b4000200 	cbz	x0, 6ba4 <fwp_drop4+0x1f4>
    6b68:	f9400001 	ldr	x1, [x0]
    6b6c:	eb14003f 	cmp	x1, x20
    6b70:	54ffff61 	b.ne	6b5c <fwp_drop4+0x1ac>  // b.any
    6b74:	f9400041 	ldr	x1, [x2]
    6b78:	f9400420 	ldr	x0, [x1, #8]
    6b7c:	d1000400 	sub	x0, x0, #0x1
    6b80:	f9000420 	str	x0, [x1, #8]
    6b84:	f103f81f 	cmp	x0, #0xfe
    6b88:	54fff601 	b.ne	6a48 <fwp_drop4+0x98>  // b.any
    6b8c:	39400280 	ldrb	w0, [x20]
    6b90:	7103fc1f 	cmp	w0, #0xff
    6b94:	540000e0 	b.eq	6bb0 <fwp_drop4+0x200>  // b.none
    6b98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b9c:	39000280 	strb	w0, [x20]
    6ba0:	17ffffaa 	b	6a48 <fwp_drop4+0x98>
    6ba4:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    6ba8:	91240000 	add	x0, x0, #0x900
    6bac:	97fff499 	bl	3e10 <fwp_trap>
    6bb0:	aa1403e0 	mov	x0, x20
    6bb4:	97fff4b7 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6bb8:	17fffff8 	b	6b98 <fwp_drop4+0x1e8>
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_caps161>:
    6bc0:	34000041 	cbz	w1, 6bc8 <fwp_caps161+0x8>
    6bc4:	d65f03c0 	ret
    6bc8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    6bcc:	91154063 	add	x3, x3, #0x550
    6bd0:	f949d861 	ldr	x1, [x3, #5040]
    6bd4:	f949ec62 	ldr	x2, [x3, #5080]
    6bd8:	cb010001 	sub	x1, x0, x1
    6bdc:	eb02403f 	cmp	x1, x2, lsl #16
    6be0:	54ffff22 	b.cs	6bc4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6be4:	d350fc22 	lsr	x2, x1, #16
    6be8:	f949fc65 	ldr	x5, [x3, #5112]
    6bec:	8b020842 	add	x2, x2, x2, lsl #2
    6bf0:	d37df042 	lsl	x2, x2, #3
    6bf4:	8b0200a4 	add	x4, x5, x2
    6bf8:	f9401083 	ldr	x3, [x4, #32]
    6bfc:	b4fffe43 	cbz	x3, 6bc4 <fwp_caps161+0x4>
    6c00:	386268a2 	ldrb	w2, [x5, x2]
    6c04:	7100085f 	cmp	w2, #0x2
    6c08:	540001c0 	b.eq	6c40 <fwp_caps161+0x80>  // b.none
    6c0c:	7100045f 	cmp	w2, #0x1
    6c10:	54fffda1 	b.ne	6bc4 <fwp_caps161+0x4>  // b.any
    6c14:	29430885 	ldp	w5, w2, [x4, #24]
    6c18:	92403c21 	and	x1, x1, #0xffff
    6c1c:	9b057c21 	mul	x1, x1, x5
    6c20:	d360fc21 	lsr	x1, x1, #32
    6c24:	eb02003f 	cmp	x1, x2
    6c28:	54fffce2 	b.cs	6bc4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c2c:	8b010063 	add	x3, x3, x1
    6c30:	39400061 	ldrb	w1, [x3]
    6c34:	7100043f 	cmp	w1, #0x1
    6c38:	54fffc61 	b.ne	6bc4 <fwp_caps161+0x4>  // b.any
    6c3c:	17fff531 	b	4100 <fwp_mem_free>
    6c40:	72003c3f 	tst	w1, #0xffff
    6c44:	54ffff60 	b.eq	6c30 <fwp_caps161+0x70>  // b.none
    6c48:	d65f03c0 	ret
    6c4c:	d503201f 	nop

0000000000006c50 <fwp_args12>:
    6c50:	7100003f 	cmp	w1, #0x0
    6c54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c58:	54000041 	b.ne	6c60 <fwp_args12+0x10>  // b.any
    6c5c:	d65f03c0 	ret
    6c60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6c64:	91154042 	add	x2, x2, #0x550
    6c68:	f9400001 	ldr	x1, [x0]
    6c6c:	f949d843 	ldr	x3, [x2, #5040]
    6c70:	f949ec40 	ldr	x0, [x2, #5080]
    6c74:	cb030021 	sub	x1, x1, x3
    6c78:	eb00403f 	cmp	x1, x0, lsl #16
    6c7c:	54ffff02 	b.cs	6c5c <fwp_args12+0xc>  // b.hs, b.nlast
    6c80:	d350fc20 	lsr	x0, x1, #16
    6c84:	f949fc44 	ldr	x4, [x2, #5112]
    6c88:	8b000800 	add	x0, x0, x0, lsl #2
    6c8c:	d37df002 	lsl	x2, x0, #3
    6c90:	8b020083 	add	x3, x4, x2
    6c94:	f9401060 	ldr	x0, [x3, #32]
    6c98:	b4fffe20 	cbz	x0, 6c5c <fwp_args12+0xc>
    6c9c:	38626882 	ldrb	w2, [x4, x2]
    6ca0:	7100085f 	cmp	w2, #0x2
    6ca4:	54000220 	b.eq	6ce8 <fwp_args12+0x98>  // b.none
    6ca8:	7100045f 	cmp	w2, #0x1
    6cac:	54fffd81 	b.ne	6c5c <fwp_args12+0xc>  // b.any
    6cb0:	29430864 	ldp	w4, w2, [x3, #24]
    6cb4:	92403c21 	and	x1, x1, #0xffff
    6cb8:	9b047c21 	mul	x1, x1, x4
    6cbc:	d360fc21 	lsr	x1, x1, #32
    6cc0:	eb02003f 	cmp	x1, x2
    6cc4:	54fffcc2 	b.cs	6c5c <fwp_args12+0xc>  // b.hs, b.nlast
    6cc8:	8b010000 	add	x0, x0, x1
    6ccc:	39400001 	ldrb	w1, [x0]
    6cd0:	34fffc61 	cbz	w1, 6c5c <fwp_args12+0xc>
    6cd4:	7103f43f 	cmp	w1, #0xfd
    6cd8:	540000e8 	b.hi	6cf4 <fwp_args12+0xa4>  // b.pmore
    6cdc:	11000421 	add	w1, w1, #0x1
    6ce0:	39000001 	strb	w1, [x0]
    6ce4:	d65f03c0 	ret
    6ce8:	72003c3f 	tst	w1, #0xffff
    6cec:	54ffff00 	b.eq	6ccc <fwp_args12+0x7c>  // b.none
    6cf0:	d65f03c0 	ret
    6cf4:	17fff57c 	b	42e4 <fwp_rc_wide_dup>
    6cf8:	d503201f 	nop
    6cfc:	d503201f 	nop

0000000000006d00 <fwp_args23>:
    6d00:	7100003f 	cmp	w1, #0x0
    6d04:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6d08:	54000041 	b.ne	6d10 <fwp_args23+0x10>  // b.any
    6d0c:	d65f03c0 	ret
    6d10:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6d14:	91154042 	add	x2, x2, #0x550
    6d18:	f9400001 	ldr	x1, [x0]
    6d1c:	f949d843 	ldr	x3, [x2, #5040]
    6d20:	f949ec40 	ldr	x0, [x2, #5080]
    6d24:	cb030021 	sub	x1, x1, x3
    6d28:	eb00403f 	cmp	x1, x0, lsl #16
    6d2c:	54ffff02 	b.cs	6d0c <fwp_args23+0xc>  // b.hs, b.nlast
    6d30:	d350fc20 	lsr	x0, x1, #16
    6d34:	f949fc44 	ldr	x4, [x2, #5112]
    6d38:	8b000800 	add	x0, x0, x0, lsl #2
    6d3c:	d37df002 	lsl	x2, x0, #3
    6d40:	8b020083 	add	x3, x4, x2
    6d44:	f9401060 	ldr	x0, [x3, #32]
    6d48:	b4fffe20 	cbz	x0, 6d0c <fwp_args23+0xc>
    6d4c:	38626882 	ldrb	w2, [x4, x2]
    6d50:	7100085f 	cmp	w2, #0x2
    6d54:	54000220 	b.eq	6d98 <fwp_args23+0x98>  // b.none
    6d58:	7100045f 	cmp	w2, #0x1
    6d5c:	54fffd81 	b.ne	6d0c <fwp_args23+0xc>  // b.any
    6d60:	29430864 	ldp	w4, w2, [x3, #24]
    6d64:	92403c21 	and	x1, x1, #0xffff
    6d68:	9b047c21 	mul	x1, x1, x4
    6d6c:	d360fc21 	lsr	x1, x1, #32
    6d70:	eb02003f 	cmp	x1, x2
    6d74:	54fffcc2 	b.cs	6d0c <fwp_args23+0xc>  // b.hs, b.nlast
    6d78:	8b010000 	add	x0, x0, x1
    6d7c:	39400001 	ldrb	w1, [x0]
    6d80:	34fffc61 	cbz	w1, 6d0c <fwp_args23+0xc>
    6d84:	7103f43f 	cmp	w1, #0xfd
    6d88:	540000e8 	b.hi	6da4 <fwp_args23+0xa4>  // b.pmore
    6d8c:	11000421 	add	w1, w1, #0x1
    6d90:	39000001 	strb	w1, [x0]
    6d94:	d65f03c0 	ret
    6d98:	72003c3f 	tst	w1, #0xffff
    6d9c:	54ffff00 	b.eq	6d7c <fwp_args23+0x7c>  // b.none
    6da0:	d65f03c0 	ret
    6da4:	17fff550 	b	42e4 <fwp_rc_wide_dup>
    6da8:	d503201f 	nop
    6dac:	d503201f 	nop

0000000000006db0 <fwp_caps12>:
    6db0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6db4:	910003fd 	mov	x29, sp
    6db8:	f9000bf3 	str	x19, [sp, #16]
    6dbc:	aa0003f3 	mov	x19, x0
    6dc0:	b9400400 	ldr	w0, [x0, #4]
    6dc4:	340004a0 	cbz	w0, 6e58 <fwp_caps12+0xa8>
    6dc8:	f9400660 	ldr	x0, [x19, #8]
    6dcc:	350004e1 	cbnz	w1, 6e68 <fwp_caps12+0xb8>
    6dd0:	97fffc4c 	bl	5f00 <fwp_drop0>
    6dd4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6dd8:	91154042 	add	x2, x2, #0x550
    6ddc:	f949d840 	ldr	x0, [x2, #5040]
    6de0:	f949ec41 	ldr	x1, [x2, #5080]
    6de4:	cb000260 	sub	x0, x19, x0
    6de8:	eb01401f 	cmp	x0, x1, lsl #16
    6dec:	54000382 	b.cs	6e5c <fwp_caps12+0xac>  // b.hs, b.nlast
    6df0:	d350fc01 	lsr	x1, x0, #16
    6df4:	f949fc44 	ldr	x4, [x2, #5112]
    6df8:	8b010821 	add	x1, x1, x1, lsl #2
    6dfc:	d37df021 	lsl	x1, x1, #3
    6e00:	8b010083 	add	x3, x4, x1
    6e04:	f9401062 	ldr	x2, [x3, #32]
    6e08:	b40002a2 	cbz	x2, 6e5c <fwp_caps12+0xac>
    6e0c:	38616881 	ldrb	w1, [x4, x1]
    6e10:	7100083f 	cmp	w1, #0x2
    6e14:	540006c0 	b.eq	6eec <fwp_caps12+0x13c>  // b.none
    6e18:	7100043f 	cmp	w1, #0x1
    6e1c:	54000201 	b.ne	6e5c <fwp_caps12+0xac>  // b.any
    6e20:	29430464 	ldp	w4, w1, [x3, #24]
    6e24:	92403c00 	and	x0, x0, #0xffff
    6e28:	9b047c00 	mul	x0, x0, x4
    6e2c:	d360fc00 	lsr	x0, x0, #32
    6e30:	eb01001f 	cmp	x0, x1
    6e34:	54000142 	b.cs	6e5c <fwp_caps12+0xac>  // b.hs, b.nlast
    6e38:	8b000042 	add	x2, x2, x0
    6e3c:	39400040 	ldrb	w0, [x2]
    6e40:	7100041f 	cmp	w0, #0x1
    6e44:	540000c1 	b.ne	6e5c <fwp_caps12+0xac>  // b.any
    6e48:	aa1303e0 	mov	x0, x19
    6e4c:	f9400bf3 	ldr	x19, [sp, #16]
    6e50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e54:	17fff4ab 	b	4100 <fwp_mem_free>
    6e58:	34fffbe1 	cbz	w1, 6dd4 <fwp_caps12+0x24>
    6e5c:	f9400bf3 	ldr	x19, [sp, #16]
    6e60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e64:	d65f03c0 	ret
    6e68:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6e6c:	91154042 	add	x2, x2, #0x550
    6e70:	f949d843 	ldr	x3, [x2, #5040]
    6e74:	f949ec41 	ldr	x1, [x2, #5080]
    6e78:	cb030000 	sub	x0, x0, x3
    6e7c:	eb01401f 	cmp	x0, x1, lsl #16
    6e80:	54fffee2 	b.cs	6e5c <fwp_caps12+0xac>  // b.hs, b.nlast
    6e84:	d350fc01 	lsr	x1, x0, #16
    6e88:	f949fc44 	ldr	x4, [x2, #5112]
    6e8c:	8b010821 	add	x1, x1, x1, lsl #2
    6e90:	d37df021 	lsl	x1, x1, #3
    6e94:	8b010083 	add	x3, x4, x1
    6e98:	f9401062 	ldr	x2, [x3, #32]
    6e9c:	b4fffe02 	cbz	x2, 6e5c <fwp_caps12+0xac>
    6ea0:	38616881 	ldrb	w1, [x4, x1]
    6ea4:	7100083f 	cmp	w1, #0x2
    6ea8:	54000280 	b.eq	6ef8 <fwp_caps12+0x148>  // b.none
    6eac:	7100043f 	cmp	w1, #0x1
    6eb0:	54fffd61 	b.ne	6e5c <fwp_caps12+0xac>  // b.any
    6eb4:	92403c01 	and	x1, x0, #0xffff
    6eb8:	29430064 	ldp	w4, w0, [x3, #24]
    6ebc:	9b047c21 	mul	x1, x1, x4
    6ec0:	d360fc21 	lsr	x1, x1, #32
    6ec4:	eb00003f 	cmp	x1, x0
    6ec8:	54fffca2 	b.cs	6e5c <fwp_caps12+0xac>  // b.hs, b.nlast
    6ecc:	8b010042 	add	x2, x2, x1
    6ed0:	39400040 	ldrb	w0, [x2]
    6ed4:	34fffc40 	cbz	w0, 6e5c <fwp_caps12+0xac>
    6ed8:	7103f41f 	cmp	w0, #0xfd
    6edc:	54000148 	b.hi	6f04 <fwp_caps12+0x154>  // b.pmore
    6ee0:	11000400 	add	w0, w0, #0x1
    6ee4:	39000040 	strb	w0, [x2]
    6ee8:	17ffffdd 	b	6e5c <fwp_caps12+0xac>
    6eec:	72003c1f 	tst	w0, #0xffff
    6ef0:	54fffb61 	b.ne	6e5c <fwp_caps12+0xac>  // b.any
    6ef4:	17ffffd2 	b	6e3c <fwp_caps12+0x8c>
    6ef8:	72003c1f 	tst	w0, #0xffff
    6efc:	54fffb01 	b.ne	6e5c <fwp_caps12+0xac>  // b.any
    6f00:	17fffff4 	b	6ed0 <fwp_caps12+0x120>
    6f04:	f9400bf3 	ldr	x19, [sp, #16]
    6f08:	aa0203e0 	mov	x0, x2
    6f0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f10:	17fff4f5 	b	42e4 <fwp_rc_wide_dup>

0000000000006f14 <fwp_drop2>:
    6f14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6f18:	910003fd 	mov	x29, sp
    6f1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6f20:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    6f24:	911542d5 	add	x21, x22, #0x550
    6f28:	a90153f3 	stp	x19, x20, [sp, #16]
    6f2c:	aa0003f3 	mov	x19, x0
    6f30:	f949daa1 	ldr	x1, [x21, #5040]
    6f34:	f949eea0 	ldr	x0, [x21, #5080]
    6f38:	cb010261 	sub	x1, x19, x1
    6f3c:	eb00403f 	cmp	x1, x0, lsl #16
    6f40:	54000382 	b.cs	6fb0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6f44:	d350fc22 	lsr	x2, x1, #16
    6f48:	f949fea3 	ldr	x3, [x21, #5112]
    6f4c:	8b020842 	add	x2, x2, x2, lsl #2
    6f50:	d37df042 	lsl	x2, x2, #3
    6f54:	8b020060 	add	x0, x3, x2
    6f58:	f9401014 	ldr	x20, [x0, #32]
    6f5c:	b40002b4 	cbz	x20, 6fb0 <fwp_drop2+0x9c>
    6f60:	38626862 	ldrb	w2, [x3, x2]
    6f64:	7100085f 	cmp	w2, #0x2
    6f68:	540002c0 	b.eq	6fc0 <fwp_drop2+0xac>  // b.none
    6f6c:	7100045f 	cmp	w2, #0x1
    6f70:	54000201 	b.ne	6fb0 <fwp_drop2+0x9c>  // b.any
    6f74:	29430002 	ldp	w2, w0, [x0, #24]
    6f78:	92403c21 	and	x1, x1, #0xffff
    6f7c:	9b027c21 	mul	x1, x1, x2
    6f80:	d360fc21 	lsr	x1, x1, #32
    6f84:	eb00003f 	cmp	x1, x0
    6f88:	54000142 	b.cs	6fb0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6f8c:	8b010294 	add	x20, x20, x1
    6f90:	39400280 	ldrb	w0, [x20]
    6f94:	340000e0 	cbz	w0, 6fb0 <fwp_drop2+0x9c>
    6f98:	7100041f 	cmp	w0, #0x1
    6f9c:	540001e0 	b.eq	6fd8 <fwp_drop2+0xc4>  // b.none
    6fa0:	7103fc1f 	cmp	w0, #0xff
    6fa4:	540007e0 	b.eq	70a0 <fwp_drop2+0x18c>  // b.none
    6fa8:	51000400 	sub	w0, w0, #0x1
    6fac:	39000280 	strb	w0, [x20]
    6fb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fb4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6fb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fbc:	d65f03c0 	ret
    6fc0:	72003c3f 	tst	w1, #0xffff
    6fc4:	54fffe60 	b.eq	6f90 <fwp_drop2+0x7c>  // b.none
    6fc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fcc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6fd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fd4:	d65f03c0 	ret
    6fd8:	911542c2 	add	x2, x22, #0x550
    6fdc:	f9400660 	ldr	x0, [x19, #8]
    6fe0:	f949d841 	ldr	x1, [x2, #5040]
    6fe4:	f949ec42 	ldr	x2, [x2, #5080]
    6fe8:	cb010001 	sub	x1, x0, x1
    6fec:	eb02403f 	cmp	x1, x2, lsl #16
    6ff0:	54000382 	b.cs	7060 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6ff4:	d350fc22 	lsr	x2, x1, #16
    6ff8:	8b020842 	add	x2, x2, x2, lsl #2
    6ffc:	d37df042 	lsl	x2, x2, #3
    7000:	8b020064 	add	x4, x3, x2
    7004:	f9401094 	ldr	x20, [x4, #32]
    7008:	b40002d4 	cbz	x20, 7060 <fwp_drop2+0x14c>
    700c:	38626862 	ldrb	w2, [x3, x2]
    7010:	7100085f 	cmp	w2, #0x2
    7014:	54000400 	b.eq	7094 <fwp_drop2+0x180>  // b.none
    7018:	7100045f 	cmp	w2, #0x1
    701c:	54000221 	b.ne	7060 <fwp_drop2+0x14c>  // b.any
    7020:	29430883 	ldp	w3, w2, [x4, #24]
    7024:	92403c21 	and	x1, x1, #0xffff
    7028:	9b037c21 	mul	x1, x1, x3
    702c:	d360fc21 	lsr	x1, x1, #32
    7030:	eb02003f 	cmp	x1, x2
    7034:	54000162 	b.cs	7060 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7038:	8b010294 	add	x20, x20, x1
    703c:	39400281 	ldrb	w1, [x20]
    7040:	34000101 	cbz	w1, 7060 <fwp_drop2+0x14c>
    7044:	7100043f 	cmp	w1, #0x1
    7048:	54000220 	b.eq	708c <fwp_drop2+0x178>  // b.none
    704c:	7103fc3f 	cmp	w1, #0xff
    7050:	54000660 	b.eq	711c <fwp_drop2+0x208>  // b.none
    7054:	51000421 	sub	w1, w1, #0x1
    7058:	39000281 	strb	w1, [x20]
    705c:	d503201f 	nop
    7060:	f9400a74 	ldr	x20, [x19, #16]
    7064:	aa1303e0 	mov	x0, x19
    7068:	97fffa73 	bl	5a34 <fwp_rc_free_arr>
    706c:	911542c0 	add	x0, x22, #0x550
    7070:	f949d801 	ldr	x1, [x0, #5040]
    7074:	f949ec00 	ldr	x0, [x0, #5080]
    7078:	cb010281 	sub	x1, x20, x1
    707c:	eb00403f 	cmp	x1, x0, lsl #16
    7080:	54fff982 	b.cs	6fb0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7084:	aa1403f3 	mov	x19, x20
    7088:	17ffffaf 	b	6f44 <fwp_drop2+0x30>
    708c:	97fffa6a 	bl	5a34 <fwp_rc_free_arr>
    7090:	17fffff4 	b	7060 <fwp_drop2+0x14c>
    7094:	72003c3f 	tst	w1, #0xffff
    7098:	54fffe41 	b.ne	7060 <fwp_drop2+0x14c>  // b.any
    709c:	17ffffe8 	b	703c <fwp_drop2+0x128>
    70a0:	ca544681 	eor	x1, x20, x20, lsr #17
    70a4:	911542c0 	add	x0, x22, #0x550
    70a8:	ca412421 	eor	x1, x1, x1, lsr #9
    70ac:	92401c21 	and	x1, x1, #0xff
    70b0:	910a2422 	add	x2, x1, #0x289
    70b4:	8b010c01 	add	x1, x0, x1, lsl #3
    70b8:	8b020c02 	add	x2, x0, x2, lsl #3
    70bc:	f94a2420 	ldr	x0, [x1, #5192]
    70c0:	b50000a0 	cbnz	x0, 70d4 <fwp_drop2+0x1c0>
    70c4:	14000013 	b	7110 <fwp_drop2+0x1fc>
    70c8:	91004002 	add	x2, x0, #0x10
    70cc:	f9400800 	ldr	x0, [x0, #16]
    70d0:	b4000200 	cbz	x0, 7110 <fwp_drop2+0x1fc>
    70d4:	f9400001 	ldr	x1, [x0]
    70d8:	eb14003f 	cmp	x1, x20
    70dc:	54ffff61 	b.ne	70c8 <fwp_drop2+0x1b4>  // b.any
    70e0:	f9400041 	ldr	x1, [x2]
    70e4:	f9400420 	ldr	x0, [x1, #8]
    70e8:	d1000400 	sub	x0, x0, #0x1
    70ec:	f9000420 	str	x0, [x1, #8]
    70f0:	f103f81f 	cmp	x0, #0xfe
    70f4:	54fff5e1 	b.ne	6fb0 <fwp_drop2+0x9c>  // b.any
    70f8:	39400280 	ldrb	w0, [x20]
    70fc:	7103fc1f 	cmp	w0, #0xff
    7100:	54000460 	b.eq	718c <fwp_drop2+0x278>  // b.none
    7104:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7108:	39000280 	strb	w0, [x20]
    710c:	17ffffa9 	b	6fb0 <fwp_drop2+0x9c>
    7110:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7114:	91240000 	add	x0, x0, #0x900
    7118:	97fff33e 	bl	3e10 <fwp_trap>
    711c:	ca544680 	eor	x0, x20, x20, lsr #17
    7120:	911542c1 	add	x1, x22, #0x550
    7124:	ca402400 	eor	x0, x0, x0, lsr #9
    7128:	92401c00 	and	x0, x0, #0xff
    712c:	910a2402 	add	x2, x0, #0x289
    7130:	8b000c20 	add	x0, x1, x0, lsl #3
    7134:	8b020c22 	add	x2, x1, x2, lsl #3
    7138:	f94a2400 	ldr	x0, [x0, #5192]
    713c:	b50000a0 	cbnz	x0, 7150 <fwp_drop2+0x23c>
    7140:	17fffff4 	b	7110 <fwp_drop2+0x1fc>
    7144:	91004002 	add	x2, x0, #0x10
    7148:	f9400800 	ldr	x0, [x0, #16]
    714c:	b4fffe20 	cbz	x0, 7110 <fwp_drop2+0x1fc>
    7150:	f9400001 	ldr	x1, [x0]
    7154:	eb14003f 	cmp	x1, x20
    7158:	54ffff61 	b.ne	7144 <fwp_drop2+0x230>  // b.any
    715c:	f9400041 	ldr	x1, [x2]
    7160:	f9400420 	ldr	x0, [x1, #8]
    7164:	d1000400 	sub	x0, x0, #0x1
    7168:	f9000420 	str	x0, [x1, #8]
    716c:	f103f81f 	cmp	x0, #0xfe
    7170:	54fff781 	b.ne	7060 <fwp_drop2+0x14c>  // b.any
    7174:	39400280 	ldrb	w0, [x20]
    7178:	7103fc1f 	cmp	w0, #0xff
    717c:	540000e0 	b.eq	7198 <fwp_drop2+0x284>  // b.none
    7180:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7184:	39000280 	strb	w0, [x20]
    7188:	17ffffb6 	b	7060 <fwp_drop2+0x14c>
    718c:	aa1403e0 	mov	x0, x20
    7190:	97fff340 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7194:	17ffffdc 	b	7104 <fwp_drop2+0x1f0>
    7198:	aa1403e0 	mov	x0, x20
    719c:	97fff33d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    71a0:	17fffff8 	b	7180 <fwp_drop2+0x26c>

00000000000071a4 <fwp_arg_drop23>:
    71a4:	7100003f 	cmp	w1, #0x0
    71a8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    71ac:	54000041 	b.ne	71b4 <fwp_arg_drop23+0x10>  // b.any
    71b0:	d65f03c0 	ret
    71b4:	f9400000 	ldr	x0, [x0]
    71b8:	17ffff57 	b	6f14 <fwp_drop2>
    71bc:	d503201f 	nop

00000000000071c0 <fwp_caps23>:
    71c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71c4:	910003fd 	mov	x29, sp
    71c8:	f9000bf3 	str	x19, [sp, #16]
    71cc:	aa0003f3 	mov	x19, x0
    71d0:	b9400400 	ldr	w0, [x0, #4]
    71d4:	340004a0 	cbz	w0, 7268 <fwp_caps23+0xa8>
    71d8:	f9400660 	ldr	x0, [x19, #8]
    71dc:	350004e1 	cbnz	w1, 7278 <fwp_caps23+0xb8>
    71e0:	97ffff4d 	bl	6f14 <fwp_drop2>
    71e4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    71e8:	91154042 	add	x2, x2, #0x550
    71ec:	f949d840 	ldr	x0, [x2, #5040]
    71f0:	f949ec41 	ldr	x1, [x2, #5080]
    71f4:	cb000260 	sub	x0, x19, x0
    71f8:	eb01401f 	cmp	x0, x1, lsl #16
    71fc:	54000382 	b.cs	726c <fwp_caps23+0xac>  // b.hs, b.nlast
    7200:	d350fc01 	lsr	x1, x0, #16
    7204:	f949fc44 	ldr	x4, [x2, #5112]
    7208:	8b010821 	add	x1, x1, x1, lsl #2
    720c:	d37df021 	lsl	x1, x1, #3
    7210:	8b010083 	add	x3, x4, x1
    7214:	f9401062 	ldr	x2, [x3, #32]
    7218:	b40002a2 	cbz	x2, 726c <fwp_caps23+0xac>
    721c:	38616881 	ldrb	w1, [x4, x1]
    7220:	7100083f 	cmp	w1, #0x2
    7224:	540006c0 	b.eq	72fc <fwp_caps23+0x13c>  // b.none
    7228:	7100043f 	cmp	w1, #0x1
    722c:	54000201 	b.ne	726c <fwp_caps23+0xac>  // b.any
    7230:	29430464 	ldp	w4, w1, [x3, #24]
    7234:	92403c00 	and	x0, x0, #0xffff
    7238:	9b047c00 	mul	x0, x0, x4
    723c:	d360fc00 	lsr	x0, x0, #32
    7240:	eb01001f 	cmp	x0, x1
    7244:	54000142 	b.cs	726c <fwp_caps23+0xac>  // b.hs, b.nlast
    7248:	8b000042 	add	x2, x2, x0
    724c:	39400040 	ldrb	w0, [x2]
    7250:	7100041f 	cmp	w0, #0x1
    7254:	540000c1 	b.ne	726c <fwp_caps23+0xac>  // b.any
    7258:	aa1303e0 	mov	x0, x19
    725c:	f9400bf3 	ldr	x19, [sp, #16]
    7260:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7264:	17fff3a7 	b	4100 <fwp_mem_free>
    7268:	34fffbe1 	cbz	w1, 71e4 <fwp_caps23+0x24>
    726c:	f9400bf3 	ldr	x19, [sp, #16]
    7270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7274:	d65f03c0 	ret
    7278:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    727c:	91154042 	add	x2, x2, #0x550
    7280:	f949d843 	ldr	x3, [x2, #5040]
    7284:	f949ec41 	ldr	x1, [x2, #5080]
    7288:	cb030000 	sub	x0, x0, x3
    728c:	eb01401f 	cmp	x0, x1, lsl #16
    7290:	54fffee2 	b.cs	726c <fwp_caps23+0xac>  // b.hs, b.nlast
    7294:	d350fc01 	lsr	x1, x0, #16
    7298:	f949fc44 	ldr	x4, [x2, #5112]
    729c:	8b010821 	add	x1, x1, x1, lsl #2
    72a0:	d37df021 	lsl	x1, x1, #3
    72a4:	8b010083 	add	x3, x4, x1
    72a8:	f9401062 	ldr	x2, [x3, #32]
    72ac:	b4fffe02 	cbz	x2, 726c <fwp_caps23+0xac>
    72b0:	38616881 	ldrb	w1, [x4, x1]
    72b4:	7100083f 	cmp	w1, #0x2
    72b8:	54000280 	b.eq	7308 <fwp_caps23+0x148>  // b.none
    72bc:	7100043f 	cmp	w1, #0x1
    72c0:	54fffd61 	b.ne	726c <fwp_caps23+0xac>  // b.any
    72c4:	92403c01 	and	x1, x0, #0xffff
    72c8:	29430064 	ldp	w4, w0, [x3, #24]
    72cc:	9b047c21 	mul	x1, x1, x4
    72d0:	d360fc21 	lsr	x1, x1, #32
    72d4:	eb00003f 	cmp	x1, x0
    72d8:	54fffca2 	b.cs	726c <fwp_caps23+0xac>  // b.hs, b.nlast
    72dc:	8b010042 	add	x2, x2, x1
    72e0:	39400040 	ldrb	w0, [x2]
    72e4:	34fffc40 	cbz	w0, 726c <fwp_caps23+0xac>
    72e8:	7103f41f 	cmp	w0, #0xfd
    72ec:	54000148 	b.hi	7314 <fwp_caps23+0x154>  // b.pmore
    72f0:	11000400 	add	w0, w0, #0x1
    72f4:	39000040 	strb	w0, [x2]
    72f8:	17ffffdd 	b	726c <fwp_caps23+0xac>
    72fc:	72003c1f 	tst	w0, #0xffff
    7300:	54fffb61 	b.ne	726c <fwp_caps23+0xac>  // b.any
    7304:	17ffffd2 	b	724c <fwp_caps23+0x8c>
    7308:	72003c1f 	tst	w0, #0xffff
    730c:	54fffb01 	b.ne	726c <fwp_caps23+0xac>  // b.any
    7310:	17fffff4 	b	72e0 <fwp_caps23+0x120>
    7314:	f9400bf3 	ldr	x19, [sp, #16]
    7318:	aa0203e0 	mov	x0, x2
    731c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7320:	17fff3f1 	b	42e4 <fwp_rc_wide_dup>

0000000000007324 <f23>:
    7324:	d10203ff 	sub	sp, sp, #0x80
    7328:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    732c:	f947f421 	ldr	x1, [x1, #4072]
    7330:	a9027bfd 	stp	x29, x30, [sp, #32]
    7334:	910083fd 	add	x29, sp, #0x20
    7338:	a9045bf5 	stp	x21, x22, [sp, #64]
    733c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    7340:	911542a3 	add	x3, x21, #0x550
    7344:	a90353f3 	stp	x19, x20, [sp, #48]
    7348:	aa0003f6 	mov	x22, x0
    734c:	a90563f7 	stp	x23, x24, [sp, #80]
    7350:	a9066bf9 	stp	x25, x26, [sp, #96]
    7354:	f949ec62 	ldr	x2, [x3, #5080]
    7358:	f9400024 	ldr	x4, [x1]
    735c:	f9000fe4 	str	x4, [sp, #24]
    7360:	d2800004 	mov	x4, #0x0                   	// #0
    7364:	f949d861 	ldr	x1, [x3, #5040]
    7368:	d370bc42 	lsl	x2, x2, #16
    736c:	b4001800 	cbz	x0, 766c <f23+0x348>
    7370:	f9400817 	ldr	x23, [x0, #16]
    7374:	cb0102e1 	sub	x1, x23, x1
    7378:	eb02003f 	cmp	x1, x2
    737c:	54000362 	b.cs	73e8 <f23+0xc4>  // b.hs, b.nlast
    7380:	f949fc60 	ldr	x0, [x3, #5112]
    7384:	d350fc22 	lsr	x2, x1, #16
    7388:	8b020842 	add	x2, x2, x2, lsl #2
    738c:	8b020c02 	add	x2, x0, x2, lsl #3
    7390:	f9401040 	ldr	x0, [x2, #32]
    7394:	b40002a0 	cbz	x0, 73e8 <f23+0xc4>
    7398:	39400043 	ldrb	w3, [x2]
    739c:	7100087f 	cmp	w3, #0x2
    73a0:	54001540 	b.eq	7648 <f23+0x324>  // b.none
    73a4:	7100047f 	cmp	w3, #0x1
    73a8:	540001c1 	b.ne	73e0 <f23+0xbc>  // b.any
    73ac:	29430843 	ldp	w3, w2, [x2, #24]
    73b0:	92403c21 	and	x1, x1, #0xffff
    73b4:	9b037c21 	mul	x1, x1, x3
    73b8:	d360fc21 	lsr	x1, x1, #32
    73bc:	eb02003f 	cmp	x1, x2
    73c0:	54000102 	b.cs	73e0 <f23+0xbc>  // b.hs, b.nlast
    73c4:	8b010000 	add	x0, x0, x1
    73c8:	39400001 	ldrb	w1, [x0]
    73cc:	340000a1 	cbz	w1, 73e0 <f23+0xbc>
    73d0:	7103f43f 	cmp	w1, #0xfd
    73d4:	540017e8 	b.hi	76d0 <f23+0x3ac>  // b.pmore
    73d8:	11000421 	add	w1, w1, #0x1
    73dc:	39000001 	strb	w1, [x0]
    73e0:	d2800002 	mov	x2, #0x0                   	// #0
    73e4:	b40000d6 	cbz	x22, 73fc <f23+0xd8>
    73e8:	aa1603e1 	mov	x1, x22
    73ec:	d2800002 	mov	x2, #0x0                   	// #0
    73f0:	f9400821 	ldr	x1, [x1, #16]
    73f4:	91000442 	add	x2, x2, #0x1
    73f8:	b5ffffc1 	cbnz	x1, 73f0 <f23+0xcc>
    73fc:	b40013f7 	cbz	x23, 7678 <f23+0x354>
    7400:	aa1703e1 	mov	x1, x23
    7404:	d2800003 	mov	x3, #0x0                   	// #0
    7408:	f9400821 	ldr	x1, [x1, #16]
    740c:	91000463 	add	x3, x3, #0x1
    7410:	b5ffffc1 	cbnz	x1, 7408 <f23+0xe4>
    7414:	eb02007f 	cmp	x3, x2
    7418:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    741c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7420:	eb00027f 	cmp	x19, x0
    7424:	540010a8 	b.hi	7638 <f23+0x314>  // b.pmore
    7428:	d37ffa74 	lsl	x20, x19, #1
    742c:	52800041 	mov	w1, #0x2                   	// #2
    7430:	91000680 	add	x0, x20, #0x1
    7434:	d37df000 	lsl	x0, x0, #3
    7438:	97fff5ee 	bl	4bf0 <fwp_heap_alloc>
    743c:	aa0003f8 	mov	x24, x0
    7440:	911542a1 	add	x1, x21, #0x550
    7444:	aa0103e0 	mov	x0, x1
    7448:	f9000314 	str	x20, [x24]
    744c:	f949d821 	ldr	x1, [x1, #5040]
    7450:	f949ec00 	ldr	x0, [x0, #5080]
    7454:	cb010301 	sub	x1, x24, x1
    7458:	eb00403f 	cmp	x1, x0, lsl #16
    745c:	54000342 	b.cs	74c4 <f23+0x1a0>  // b.hs, b.nlast
    7460:	911542a2 	add	x2, x21, #0x550
    7464:	d350fc20 	lsr	x0, x1, #16
    7468:	8b000800 	add	x0, x0, x0, lsl #2
    746c:	f949fc43 	ldr	x3, [x2, #5112]
    7470:	d37df002 	lsl	x2, x0, #3
    7474:	8b020060 	add	x0, x3, x2
    7478:	f9401014 	ldr	x20, [x0, #32]
    747c:	b4000254 	cbz	x20, 74c4 <f23+0x1a0>
    7480:	38626862 	ldrb	w2, [x3, x2]
    7484:	7100085f 	cmp	w2, #0x2
    7488:	54000ec0 	b.eq	7660 <f23+0x33c>  // b.none
    748c:	7100045f 	cmp	w2, #0x1
    7490:	540001a1 	b.ne	74c4 <f23+0x1a0>  // b.any
    7494:	29430002 	ldp	w2, w0, [x0, #24]
    7498:	92403c21 	and	x1, x1, #0xffff
    749c:	9b027c21 	mul	x1, x1, x2
    74a0:	d360fc21 	lsr	x1, x1, #32
    74a4:	eb00003f 	cmp	x1, x0
    74a8:	540000e2 	b.cs	74c4 <f23+0x1a0>  // b.hs, b.nlast
    74ac:	8b010294 	add	x20, x20, x1
    74b0:	39400280 	ldrb	w0, [x20]
    74b4:	7103fc1f 	cmp	w0, #0xff
    74b8:	54001100 	b.eq	76d8 <f23+0x3b4>  // b.none
    74bc:	52800020 	mov	w0, #0x1                   	// #1
    74c0:	39000280 	strb	w0, [x20]
    74c4:	b4000253 	cbz	x19, 750c <f23+0x1e8>
    74c8:	8b131313 	add	x19, x24, x19, lsl #4
    74cc:	aa1803f4 	mov	x20, x24
    74d0:	aa1603fa 	mov	x26, x22
    74d4:	aa1703f9 	mov	x25, x23
    74d8:	f9400723 	ldr	x3, [x25, #8]
    74dc:	f9400742 	ldr	x2, [x26, #8]
    74e0:	f9400861 	ldr	x1, [x3, #16]
    74e4:	f9400840 	ldr	x0, [x2, #16]
    74e8:	fd400461 	ldr	d1, [x3, #8]
    74ec:	fd400440 	ldr	d0, [x2, #8]
    74f0:	97fff77c 	bl	52e0 <w107>
    74f4:	f9000680 	str	x0, [x20, #8]
    74f8:	f8010e81 	str	x1, [x20, #16]!
    74fc:	f9400b39 	ldr	x25, [x25, #16]
    7500:	f9400b5a 	ldr	x26, [x26, #16]
    7504:	eb14027f 	cmp	x19, x20
    7508:	54fffe81 	b.ne	74d8 <f23+0x1b4>  // b.any
    750c:	aa1703e0 	mov	x0, x23
    7510:	97fffe81 	bl	6f14 <fwp_drop2>
    7514:	aa1603e0 	mov	x0, x22
    7518:	97fffe7f 	bl	6f14 <fwp_drop2>
    751c:	f9400316 	ldr	x22, [x24]
    7520:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7524:	b4000236 	cbz	x22, 7568 <f23+0x244>
    7528:	fd003be8 	str	d8, [sp, #112]
    752c:	2f00e408 	movi	d8, #0x0
    7530:	91002319 	add	x25, x24, #0x8
    7534:	91004317 	add	x23, x24, #0x10
    7538:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    753c:	d2800013 	mov	x19, #0x0                   	// #0
    7540:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7544:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7548:	91000a73 	add	x19, x19, #0x2
    754c:	1e602908 	fadd	d8, d8, d0
    7550:	97fff70c 	bl	5180 <f128.constprop.0>
    7554:	aa0003f4 	mov	x20, x0
    7558:	eb1302df 	cmp	x22, x19
    755c:	54ffff28 	b.hi	7540 <f23+0x21c>  // b.pmore
    7560:	9e660116 	fmov	x22, d8
    7564:	fd403be8 	ldr	d8, [sp, #112]
    7568:	911542b5 	add	x21, x21, #0x550
    756c:	aa1803e0 	mov	x0, x24
    7570:	97fffd10 	bl	69b0 <fwp_drop4>
    7574:	a900d3f6 	stp	x22, x20, [sp, #8]
    7578:	910023e1 	add	x1, sp, #0x8
    757c:	52800000 	mov	w0, #0x0                   	// #0
    7580:	97fff891 	bl	57c4 <fwp_data.part.0.constprop.0>
    7584:	f949daa1 	ldr	x1, [x21, #5040]
    7588:	aa0003f3 	mov	x19, x0
    758c:	f949eea0 	ldr	x0, [x21, #5080]
    7590:	cb010261 	sub	x1, x19, x1
    7594:	eb00403f 	cmp	x1, x0, lsl #16
    7598:	54000322 	b.cs	75fc <f23+0x2d8>  // b.hs, b.nlast
    759c:	d350fc22 	lsr	x2, x1, #16
    75a0:	f949fea3 	ldr	x3, [x21, #5112]
    75a4:	8b020842 	add	x2, x2, x2, lsl #2
    75a8:	d37df042 	lsl	x2, x2, #3
    75ac:	8b020060 	add	x0, x3, x2
    75b0:	f9401014 	ldr	x20, [x0, #32]
    75b4:	b4000254 	cbz	x20, 75fc <f23+0x2d8>
    75b8:	38626862 	ldrb	w2, [x3, x2]
    75bc:	7100085f 	cmp	w2, #0x2
    75c0:	540004a0 	b.eq	7654 <f23+0x330>  // b.none
    75c4:	7100045f 	cmp	w2, #0x1
    75c8:	540001a1 	b.ne	75fc <f23+0x2d8>  // b.any
    75cc:	29430002 	ldp	w2, w0, [x0, #24]
    75d0:	92403c21 	and	x1, x1, #0xffff
    75d4:	9b027c21 	mul	x1, x1, x2
    75d8:	d360fc21 	lsr	x1, x1, #32
    75dc:	eb00003f 	cmp	x1, x0
    75e0:	540000e2 	b.cs	75fc <f23+0x2d8>  // b.hs, b.nlast
    75e4:	8b010294 	add	x20, x20, x1
    75e8:	39400280 	ldrb	w0, [x20]
    75ec:	7103fc1f 	cmp	w0, #0xff
    75f0:	540007a0 	b.eq	76e4 <f23+0x3c0>  // b.none
    75f4:	52800020 	mov	w0, #0x1                   	// #1
    75f8:	39000280 	strb	w0, [x20]
    75fc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7600:	f947f400 	ldr	x0, [x0, #4072]
    7604:	f9400fe2 	ldr	x2, [sp, #24]
    7608:	f9400001 	ldr	x1, [x0]
    760c:	eb010042 	subs	x2, x2, x1
    7610:	d2800001 	mov	x1, #0x0                   	// #0
    7614:	54000721 	b.ne	76f8 <f23+0x3d4>  // b.any
    7618:	a9427bfd 	ldp	x29, x30, [sp, #32]
    761c:	aa1303e0 	mov	x0, x19
    7620:	a94353f3 	ldp	x19, x20, [sp, #48]
    7624:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7628:	a94563f7 	ldp	x23, x24, [sp, #80]
    762c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7630:	910203ff 	add	sp, sp, #0x80
    7634:	d65f03c0 	ret
    7638:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    763c:	912ea000 	add	x0, x0, #0xba8
    7640:	fd003be8 	str	d8, [sp, #112]
    7644:	97fff1f3 	bl	3e10 <fwp_trap>
    7648:	72003c3f 	tst	w1, #0xffff
    764c:	54ffeca1 	b.ne	73e0 <f23+0xbc>  // b.any
    7650:	17ffff5e 	b	73c8 <f23+0xa4>
    7654:	72003c3f 	tst	w1, #0xffff
    7658:	54fffd21 	b.ne	75fc <f23+0x2d8>  // b.any
    765c:	17ffffe3 	b	75e8 <f23+0x2c4>
    7660:	72003c3f 	tst	w1, #0xffff
    7664:	54fff301 	b.ne	74c4 <f23+0x1a0>  // b.any
    7668:	17ffff92 	b	74b0 <f23+0x18c>
    766c:	cb0103e1 	neg	x1, x1
    7670:	eb02003f 	cmp	x1, x2
    7674:	540001e3 	b.cc	76b0 <f23+0x38c>  // b.lo, b.ul, b.last
    7678:	52800041 	mov	w1, #0x2                   	// #2
    767c:	d2800100 	mov	x0, #0x8                   	// #8
    7680:	97fff55c 	bl	4bf0 <fwp_heap_alloc>
    7684:	aa0003f8 	mov	x24, x0
    7688:	911542a0 	add	x0, x21, #0x550
    768c:	f900031f 	str	xzr, [x24]
    7690:	f949d801 	ldr	x1, [x0, #5040]
    7694:	f949ec00 	ldr	x0, [x0, #5080]
    7698:	cb010301 	sub	x1, x24, x1
    769c:	eb00403f 	cmp	x1, x0, lsl #16
    76a0:	54000282 	b.cs	76f0 <f23+0x3cc>  // b.hs, b.nlast
    76a4:	d2800013 	mov	x19, #0x0                   	// #0
    76a8:	d2800017 	mov	x23, #0x0                   	// #0
    76ac:	17ffff6d 	b	7460 <f23+0x13c>
    76b0:	f949fc62 	ldr	x2, [x3, #5112]
    76b4:	d350fc20 	lsr	x0, x1, #16
    76b8:	8b000800 	add	x0, x0, x0, lsl #2
    76bc:	8b000c42 	add	x2, x2, x0, lsl #3
    76c0:	f9401040 	ldr	x0, [x2, #32]
    76c4:	b4fffda0 	cbz	x0, 7678 <f23+0x354>
    76c8:	d2800017 	mov	x23, #0x0                   	// #0
    76cc:	17ffff33 	b	7398 <f23+0x74>
    76d0:	97fff305 	bl	42e4 <fwp_rc_wide_dup>
    76d4:	17ffff43 	b	73e0 <f23+0xbc>
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	97fff1ed 	bl	3e90 <fwp_rc_forget_slot.part.0>
    76e0:	17ffff77 	b	74bc <f23+0x198>
    76e4:	aa1403e0 	mov	x0, x20
    76e8:	97fff1ea 	bl	3e90 <fwp_rc_forget_slot.part.0>
    76ec:	17ffffc2 	b	75f4 <f23+0x2d0>
    76f0:	d2800017 	mov	x23, #0x0                   	// #0
    76f4:	17ffff86 	b	750c <f23+0x1e8>
    76f8:	fd003be8 	str	d8, [sp, #112]
    76fc:	97ffec3d 	bl	27f0 <__stack_chk_fail@plt>

0000000000007700 <fwp_owned_entry23>:
    7700:	f9400000 	ldr	x0, [x0]
    7704:	17ffff08 	b	7324 <f23>
    7708:	d503201f 	nop
    770c:	d503201f 	nop

0000000000007710 <e23>:
    7710:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7714:	910003fd 	mov	x29, sp
    7718:	f9000bf3 	str	x19, [sp, #16]
    771c:	f9400013 	ldr	x19, [x0]
    7720:	aa1303e0 	mov	x0, x19
    7724:	97fff870 	bl	58e4 <fwp_rc_share>
    7728:	aa1303e0 	mov	x0, x19
    772c:	97fffefe 	bl	7324 <f23>
    7730:	aa0003f3 	mov	x19, x0
    7734:	97fff86c 	bl	58e4 <fwp_rc_share>
    7738:	aa1303e0 	mov	x0, x19
    773c:	f9400bf3 	ldr	x19, [sp, #16]
    7740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7744:	d65f03c0 	ret
    7748:	d503201f 	nop
    774c:	d503201f 	nop

0000000000007750 <f12>:
    7750:	d10483ff 	sub	sp, sp, #0x120
    7754:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7758:	f947f442 	ldr	x2, [x2, #4072]
    775c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7760:	910303fd 	add	x29, sp, #0xc0
    7764:	a90f63f7 	stp	x23, x24, [sp, #240]
    7768:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    776c:	911542e3 	add	x3, x23, #0x550
    7770:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7774:	b00000d6 	adrp	x22, 20000 <__data_start>
    7778:	910102c4 	add	x4, x22, #0x40
    777c:	f949d861 	ldr	x1, [x3, #5040]
    7780:	a90d53f3 	stp	x19, x20, [sp, #208]
    7784:	b00000d3 	adrp	x19, 20000 <__data_start>
    7788:	f949ec65 	ldr	x5, [x3, #5080]
    778c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7790:	91004273 	add	x19, x19, #0x10
    7794:	a91173fb 	stp	x27, x28, [sp, #272]
    7798:	910103f9 	add	x25, sp, #0x40
    779c:	9100e3f8 	add	x24, sp, #0x38
    77a0:	f9416086 	ldr	x6, [x4, #704]
    77a4:	f9400047 	ldr	x7, [x2]
    77a8:	f9005fe7 	str	x7, [sp, #184]
    77ac:	d2800007 	mov	x7, #0x0                   	// #0
    77b0:	f0fffff5 	adrp	x21, 6000 <fwp_drop0+0x100>
    77b4:	12800007 	mov	w7, #0xffffffff            	// #-1
    77b8:	9110c2a2 	add	x2, x21, #0x430
    77bc:	cb010261 	sub	x1, x19, x1
    77c0:	b9003be7 	str	w7, [sp, #56]
    77c4:	aa0003f4 	mov	x20, x0
    77c8:	a9040be6 	stp	x6, x2, [sp, #64]
    77cc:	f9002bf8 	str	x24, [sp, #80]
    77d0:	f9016099 	str	x25, [x4, #704]
    77d4:	eb05403f 	cmp	x1, x5, lsl #16
    77d8:	54000342 	b.cs	7840 <f12+0xf0>  // b.hs, b.nlast
    77dc:	d350fc20 	lsr	x0, x1, #16
    77e0:	f949fc64 	ldr	x4, [x3, #5112]
    77e4:	8b000800 	add	x0, x0, x0, lsl #2
    77e8:	d37df002 	lsl	x2, x0, #3
    77ec:	8b020083 	add	x3, x4, x2
    77f0:	f9401060 	ldr	x0, [x3, #32]
    77f4:	b4000260 	cbz	x0, 7840 <f12+0xf0>
    77f8:	38626882 	ldrb	w2, [x4, x2]
    77fc:	7100085f 	cmp	w2, #0x2
    7800:	54000b60 	b.eq	796c <f12+0x21c>  // b.none
    7804:	7100045f 	cmp	w2, #0x1
    7808:	540001c1 	b.ne	7840 <f12+0xf0>  // b.any
    780c:	29430864 	ldp	w4, w2, [x3, #24]
    7810:	92403c21 	and	x1, x1, #0xffff
    7814:	9b047c21 	mul	x1, x1, x4
    7818:	d360fc21 	lsr	x1, x1, #32
    781c:	eb02003f 	cmp	x1, x2
    7820:	54000102 	b.cs	7840 <f12+0xf0>  // b.hs, b.nlast
    7824:	8b010000 	add	x0, x0, x1
    7828:	39400001 	ldrb	w1, [x0]
    782c:	340000a1 	cbz	w1, 7840 <f12+0xf0>
    7830:	7103f43f 	cmp	w1, #0xfd
    7834:	54002688 	b.hi	7d04 <f12+0x5b4>  // b.pmore
    7838:	11000421 	add	w1, w1, #0x1
    783c:	39000001 	strb	w1, [x0]
    7840:	aa1303e0 	mov	x0, x19
    7844:	97fffa13 	bl	6090 <fwp_closure_drop>
    7848:	b40001d4 	cbz	x20, 7880 <f12+0x130>
    784c:	aa1403e1 	mov	x1, x20
    7850:	d2800002 	mov	x2, #0x0                   	// #0
    7854:	d503201f 	nop
    7858:	f9400821 	ldr	x1, [x1, #16]
    785c:	91000442 	add	x2, x2, #0x1
    7860:	b5ffffc1 	cbnz	x1, 7858 <f12+0x108>
    7864:	aa0203f3 	mov	x19, x2
    7868:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    786c:	eb00005f 	cmp	x2, x0
    7870:	540000a9 	b.ls	7884 <f12+0x134>  // b.plast
    7874:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7878:	912ee000 	add	x0, x0, #0xbb8
    787c:	97fff165 	bl	3e10 <fwp_trap>
    7880:	d2800013 	mov	x19, #0x0                   	// #0
    7884:	910102da 	add	x26, x22, #0x40
    7888:	b942f740 	ldr	w0, [x26, #756]
    788c:	34001260 	cbz	w0, 7ad8 <f12+0x388>
    7890:	910102c0 	add	x0, x22, #0x40
    7894:	f940401b 	ldr	x27, [x0, #128]
    7898:	f9404c1a 	ldr	x26, [x0, #152]
    789c:	eb1b035f 	cmp	x26, x27
    78a0:	540006ca 	b.ge	7978 <f12+0x228>  // b.tcont
    78a4:	f94022c0 	ldr	x0, [x22, #64]
    78a8:	8b1a0741 	add	x1, x26, x26, lsl #1
    78ac:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    78b0:	8b010b41 	add	x1, x26, x1, lsl #2
    78b4:	8b010c01 	add	x1, x0, x1, lsl #3
    78b8:	b9400420 	ldr	w0, [x1, #4]
    78bc:	35000080 	cbnz	w0, 78cc <f12+0x17c>
    78c0:	b9400020 	ldr	w0, [x1]
    78c4:	6b02001f 	cmp	w0, w2
    78c8:	54000589 	b.ls	7978 <f12+0x228>  // b.plast
    78cc:	9100075a 	add	x26, x26, #0x1
    78d0:	9101a021 	add	x1, x1, #0x68
    78d4:	eb1b035f 	cmp	x26, x27
    78d8:	54ffff01 	b.ne	78b8 <f12+0x168>  // b.any
    78dc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    78e0:	eb00037f 	cmp	x27, x0
    78e4:	54001e2c 	b.gt	7ca8 <f12+0x558>
    78e8:	910102c0 	add	x0, x22, #0x40
    78ec:	f94022dc 	ldr	x28, [x22, #64]
    78f0:	f9404800 	ldr	x0, [x0, #144]
    78f4:	eb1b001f 	cmp	x0, x27
    78f8:	54000201 	b.ne	7938 <f12+0x1e8>  // b.any
    78fc:	b40026fb 	cbz	x27, 7dd8 <f12+0x688>
    7900:	d37ffb7a 	lsl	x26, x27, #1
    7904:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7908:	eb00035f 	cmp	x26, x0
    790c:	9a80d35a 	csel	x26, x26, x0, le
    7910:	8b1a0741 	add	x1, x26, x26, lsl #1
    7914:	8b010b41 	add	x1, x26, x1, lsl #2
    7918:	d37df021 	lsl	x1, x1, #3
    791c:	aa1c03e0 	mov	x0, x28
    7920:	97ffebb0 	bl	27e0 <realloc@plt>
    7924:	aa0003fc 	mov	x28, x0
    7928:	b4004740 	cbz	x0, 8210 <f12+0xac0>
    792c:	910102c0 	add	x0, x22, #0x40
    7930:	f90022dc 	str	x28, [x22, #64]
    7934:	f900481a 	str	x26, [x0, #144]
    7938:	8b1b0760 	add	x0, x27, x27, lsl #1
    793c:	910102c1 	add	x1, x22, #0x40
    7940:	4f000400 	movi	v0.4s, #0x0
    7944:	aa1b03fa 	mov	x26, x27
    7948:	8b000b60 	add	x0, x27, x0, lsl #2
    794c:	9100077b 	add	x27, x27, #0x1
    7950:	f900403b 	str	x27, [x1, #128]
    7954:	8b000f80 	add	x0, x28, x0, lsl #3
    7958:	ad000000 	stp	q0, q0, [x0]
    795c:	ad010000 	stp	q0, q0, [x0, #32]
    7960:	ad020000 	stp	q0, q0, [x0, #64]
    7964:	f900301f 	str	xzr, [x0, #96]
    7968:	14000007 	b	7984 <f12+0x234>
    796c:	72003c3f 	tst	w1, #0xffff
    7970:	54fff681 	b.ne	7840 <f12+0xf0>  // b.any
    7974:	17ffffad 	b	7828 <f12+0xd8>
    7978:	eb1a037f 	cmp	x27, x26
    797c:	54fffb00 	b.eq	78dc <f12+0x18c>  // b.none
    7980:	f94022dc 	ldr	x28, [x22, #64]
    7984:	8b1a075b 	add	x27, x26, x26, lsl #1
    7988:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    798c:	91236000 	add	x0, x0, #0x8d8
    7990:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7994:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7998:	f900337f 	str	xzr, [x27, #96]
    799c:	97ffebf9 	bl	2980 <getenv@plt>
    79a0:	b4000080 	cbz	x0, 79b0 <f12+0x260>
    79a4:	39400001 	ldrb	w1, [x0]
    79a8:	7100c03f 	cmp	w1, #0x30
    79ac:	54000720 	b.eq	7a90 <f12+0x340>  // b.none
    79b0:	910102c0 	add	x0, x22, #0x40
    79b4:	f9403801 	ldr	x1, [x0, #112]
    79b8:	b5000721 	cbnz	x1, 7a9c <f12+0x34c>
    79bc:	910102c2 	add	x2, x22, #0x40
    79c0:	2f000400 	mvni	v0.2s, #0x0
    79c4:	b9400363 	ldr	w3, [x27]
    79c8:	52800020 	mov	w0, #0x1                   	// #1
    79cc:	91000744 	add	x4, x26, #0x1
    79d0:	a900cf73 	stp	x19, x19, [x27, #8]
    79d4:	0b000063 	add	w3, w3, w0
    79d8:	f9416041 	ldr	x1, [x2, #704]
    79dc:	29000363 	stp	w3, w0, [x27]
    79e0:	f9002b7f 	str	xzr, [x27, #80]
    79e4:	f9004c44 	str	x4, [x2, #152]
    79e8:	fd002f60 	str	d0, [x27, #88]
    79ec:	b4001521 	cbz	x1, 7c90 <f12+0x540>
    79f0:	9110c2b5 	add	x21, x21, #0x430
    79f4:	14000003 	b	7a00 <f12+0x2b0>
    79f8:	f9400021 	ldr	x1, [x1]
    79fc:	b40014a1 	cbz	x1, 7c90 <f12+0x540>
    7a00:	f9400422 	ldr	x2, [x1, #8]
    7a04:	eb15005f 	cmp	x2, x21
    7a08:	54ffff81 	b.ne	79f8 <f12+0x2a8>  // b.any
    7a0c:	f9400820 	ldr	x0, [x1, #16]
    7a10:	2a1a03e2 	mov	w2, w26
    7a14:	b9400001 	ldr	w1, [x0]
    7a18:	f9002b60 	str	x0, [x27, #80]
    7a1c:	b9005f61 	str	w1, [x27, #92]
    7a20:	37f80081 	tbnz	w1, #31, 7a30 <f12+0x2e0>
    7a24:	52800d05 	mov	w5, #0x68                  	// #104
    7a28:	9b257021 	smaddl	x1, w1, w5, x28
    7a2c:	b900583a 	str	w26, [x1, #88]
    7a30:	b9000002 	str	w2, [x0]
    7a34:	aa1403e0 	mov	x0, x20
    7a38:	d2800002 	mov	x2, #0x0                   	// #0
    7a3c:	b40005d4 	cbz	x20, 7af4 <f12+0x3a4>
    7a40:	f9400800 	ldr	x0, [x0, #16]
    7a44:	91000442 	add	x2, x2, #0x1
    7a48:	b5ffffc0 	cbnz	x0, 7a40 <f12+0x2f0>
    7a4c:	aa1403e1 	mov	x1, x20
    7a50:	f9400821 	ldr	x1, [x1, #16]
    7a54:	91000400 	add	x0, x0, #0x1
    7a58:	b5ffffc1 	cbnz	x1, 7a50 <f12+0x300>
    7a5c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7a60:	eb01001f 	cmp	x0, x1
    7a64:	54000108 	b.hi	7a84 <f12+0x334>  // b.pmore
    7a68:	f100005f 	cmp	x2, #0x0
    7a6c:	5400044d 	b.le	7af4 <f12+0x3a4>
    7a70:	eb00005f 	cmp	x2, x0
    7a74:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7a78:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7a7c:	eb01027f 	cmp	x19, x1
    7a80:	540011a9 	b.ls	7cb4 <f12+0x564>  // b.plast
    7a84:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7a88:	912ea000 	add	x0, x0, #0xba8
    7a8c:	97fff0e1 	bl	3e10 <fwp_trap>
    7a90:	39400400 	ldrb	w0, [x0, #1]
    7a94:	34fff940 	cbz	w0, 79bc <f12+0x26c>
    7a98:	17ffffc6 	b	79b0 <f12+0x260>
    7a9c:	3cc38002 	ldur	q2, [x0, #56]
    7aa0:	9100e001 	add	x1, x0, #0x38
    7aa4:	3cc48001 	ldur	q1, [x0, #72]
    7aa8:	f900381f 	str	xzr, [x0, #112]
    7aac:	4f000400 	movi	v0.4s, #0x0
    7ab0:	ad010762 	stp	q2, q1, [x27, #32]
    7ab4:	a9458002 	ldp	x2, x0, [x0, #88]
    7ab8:	f9000f60 	str	x0, [x27, #24]
    7abc:	f9401820 	ldr	x0, [x1, #48]
    7ac0:	f9002362 	str	x2, [x27, #64]
    7ac4:	f9002760 	str	x0, [x27, #72]
    7ac8:	ad000020 	stp	q0, q0, [x1]
    7acc:	3d800820 	str	q0, [x1, #32]
    7ad0:	f900183f 	str	xzr, [x1, #48]
    7ad4:	17ffffba 	b	79bc <f12+0x26c>
    7ad8:	f0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x100>
    7adc:	910cc000 	add	x0, x0, #0x330
    7ae0:	9400172c 	bl	d790 <atexit>
    7ae4:	35003960 	cbnz	w0, 8210 <f12+0xac0>
    7ae8:	52800020 	mov	w0, #0x1                   	// #1
    7aec:	b902f740 	str	w0, [x26, #756]
    7af0:	17ffff68 	b	7890 <f12+0x140>
    7af4:	d3707c63 	ubfiz	x3, x3, #16, #32
    7af8:	52800041 	mov	w1, #0x2                   	// #2
    7afc:	aa040075 	orr	x21, x3, x4
    7b00:	d2800100 	mov	x0, #0x8                   	// #8
    7b04:	97fff43b 	bl	4bf0 <fwp_heap_alloc>
    7b08:	aa0003fa 	mov	x26, x0
    7b0c:	911542e0 	add	x0, x23, #0x550
    7b10:	f900035f 	str	xzr, [x26]
    7b14:	f949d801 	ldr	x1, [x0, #5040]
    7b18:	f949ec00 	ldr	x0, [x0, #5080]
    7b1c:	cb010341 	sub	x1, x26, x1
    7b20:	eb00403f 	cmp	x1, x0, lsl #16
    7b24:	54000ea2 	b.cs	7cf8 <f12+0x5a8>  // b.hs, b.nlast
    7b28:	d2800013 	mov	x19, #0x0                   	// #0
    7b2c:	911542e2 	add	x2, x23, #0x550
    7b30:	d350fc20 	lsr	x0, x1, #16
    7b34:	8b000800 	add	x0, x0, x0, lsl #2
    7b38:	f949fc43 	ldr	x3, [x2, #5112]
    7b3c:	d37df002 	lsl	x2, x0, #3
    7b40:	8b020060 	add	x0, x3, x2
    7b44:	f940101b 	ldr	x27, [x0, #32]
    7b48:	b400025b 	cbz	x27, 7b90 <f12+0x440>
    7b4c:	38626862 	ldrb	w2, [x3, x2]
    7b50:	7100085f 	cmp	w2, #0x2
    7b54:	54000a40 	b.eq	7c9c <f12+0x54c>  // b.none
    7b58:	7100045f 	cmp	w2, #0x1
    7b5c:	540001a1 	b.ne	7b90 <f12+0x440>  // b.any
    7b60:	29430002 	ldp	w2, w0, [x0, #24]
    7b64:	92403c21 	and	x1, x1, #0xffff
    7b68:	9b027c21 	mul	x1, x1, x2
    7b6c:	d360fc21 	lsr	x1, x1, #32
    7b70:	eb00003f 	cmp	x1, x0
    7b74:	540000e2 	b.cs	7b90 <f12+0x440>  // b.hs, b.nlast
    7b78:	8b01037b 	add	x27, x27, x1
    7b7c:	39400360 	ldrb	w0, [x27]
    7b80:	7103fc1f 	cmp	w0, #0xff
    7b84:	540032a0 	b.eq	81d8 <f12+0xa88>  // b.none
    7b88:	52800020 	mov	w0, #0x1                   	// #1
    7b8c:	39000360 	strb	w0, [x27]
    7b90:	b4000233 	cbz	x19, 7bd4 <f12+0x484>
    7b94:	d3607ea4 	lsl	x4, x21, #32
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	f9400685 	ldr	x5, [x20, #8]
    7ba0:	aa0403e3 	mov	x3, x4
    7ba4:	91002342 	add	x2, x26, #0x8
    7ba8:	d2800001 	mov	x1, #0x0                   	// #0
    7bac:	14000005 	b	7bc0 <f12+0x470>
    7bb0:	f9400405 	ldr	x5, [x0, #8]
    7bb4:	ab010083 	adds	x3, x4, x1
    7bb8:	91004042 	add	x2, x2, #0x10
    7bbc:	54005a06 	b.vs	86fc <f12+0xfac>
    7bc0:	a9000c45 	stp	x5, x3, [x2]
    7bc4:	91000421 	add	x1, x1, #0x1
    7bc8:	f9400800 	ldr	x0, [x0, #16]
    7bcc:	eb13003f 	cmp	x1, x19
    7bd0:	54ffff03 	b.cc	7bb0 <f12+0x460>  // b.lo, b.ul, b.last
    7bd4:	f9400340 	ldr	x0, [x26]
    7bd8:	f100041f 	cmp	x0, #0x1
    7bdc:	540008e9 	b.ls	7cf8 <f12+0x5a8>  // b.plast
    7be0:	d341fc00 	lsr	x0, x0, #1
    7be4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7be8:	d100041c 	sub	x28, x0, #0x1
    7bec:	eb01039f 	cmp	x28, x1
    7bf0:	54fff4a8 	b.hi	7a84 <f12+0x334>  // b.pmore
    7bf4:	b400083c 	cbz	x28, 7cf8 <f12+0x5a8>
    7bf8:	d1002341 	sub	x1, x26, #0x8
    7bfc:	91002353 	add	x19, x26, #0x8
    7c00:	8b00103b 	add	x27, x1, x0, lsl #4
    7c04:	d503201f 	nop
    7c08:	f9400660 	ldr	x0, [x19, #8]
    7c0c:	f9400e61 	ldr	x1, [x19, #24]
    7c10:	fd400260 	ldr	d0, [x19]
    7c14:	fd400a61 	ldr	d1, [x19, #16]
    7c18:	97fff5b2 	bl	52e0 <w107>
    7c1c:	a9000660 	stp	x0, x1, [x19]
    7c20:	91004273 	add	x19, x19, #0x10
    7c24:	eb1b027f 	cmp	x19, x27
    7c28:	54ffff01 	b.ne	7c08 <f12+0x4b8>  // b.any
    7c2c:	aa1a03fb 	mov	x27, x26
    7c30:	d37ffb93 	lsl	x19, x28, #1
    7c34:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7c38:	d280001c 	mov	x28, #0x0                   	// #0
    7c3c:	f8010773 	str	x19, [x27], #16
    7c40:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    7c44:	aa0303e0 	mov	x0, x3
    7c48:	91000b9c 	add	x28, x28, #0x2
    7c4c:	97fff54d 	bl	5180 <f128.constprop.0>
    7c50:	aa0003e3 	mov	x3, x0
    7c54:	eb13039f 	cmp	x28, x19
    7c58:	54ffff43 	b.cc	7c40 <f12+0x4f0>  // b.lo, b.ul, b.last
    7c5c:	aa1a03e0 	mov	x0, x26
    7c60:	93407eb5 	sxtw	x21, w21
    7c64:	f90007e3 	str	x3, [sp, #8]
    7c68:	97fffb52 	bl	69b0 <fwp_drop4>
    7c6c:	aa1503e0 	mov	x0, x21
    7c70:	97fff26c 	bl	4620 <fwp_tape_of>
    7c74:	f940301b 	ldr	x27, [x0, #96]
    7c78:	aa0003e5 	mov	x5, x0
    7c7c:	f94007e3 	ldr	x3, [sp, #8]
    7c80:	b400047b 	cbz	x27, 7d0c <f12+0x5bc>
    7c84:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7c88:	912c6000 	add	x0, x0, #0xb18
    7c8c:	97fff061 	bl	3e10 <fwp_trap>
    7c90:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7c94:	91302000 	add	x0, x0, #0xc08
    7c98:	97fff05e 	bl	3e10 <fwp_trap>
    7c9c:	72003c3f 	tst	w1, #0xffff
    7ca0:	54fff781 	b.ne	7b90 <f12+0x440>  // b.any
    7ca4:	17ffffb6 	b	7b7c <f12+0x42c>
    7ca8:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7cac:	912f6000 	add	x0, x0, #0xbd8
    7cb0:	97fff058 	bl	3e10 <fwp_trap>
    7cb4:	d37ffa7b 	lsl	x27, x19, #1
    7cb8:	d3707c63 	ubfiz	x3, x3, #16, #32
    7cbc:	91000760 	add	x0, x27, #0x1
    7cc0:	52800041 	mov	w1, #0x2                   	// #2
    7cc4:	aa040075 	orr	x21, x3, x4
    7cc8:	d37df000 	lsl	x0, x0, #3
    7ccc:	97fff3c9 	bl	4bf0 <fwp_heap_alloc>
    7cd0:	aa0003fa 	mov	x26, x0
    7cd4:	911542e1 	add	x1, x23, #0x550
    7cd8:	aa0103e0 	mov	x0, x1
    7cdc:	f900035b 	str	x27, [x26]
    7ce0:	f949d821 	ldr	x1, [x1, #5040]
    7ce4:	f949ec00 	ldr	x0, [x0, #5080]
    7ce8:	cb010341 	sub	x1, x26, x1
    7cec:	eb00403f 	cmp	x1, x0, lsl #16
    7cf0:	54fff1e3 	b.cc	7b2c <f12+0x3dc>  // b.lo, b.ul, b.last
    7cf4:	b5fff513 	cbnz	x19, 7b94 <f12+0x444>
    7cf8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7cfc:	f900035f 	str	xzr, [x26]
    7d00:	17ffffd7 	b	7c5c <f12+0x50c>
    7d04:	97fff178 	bl	42e4 <fwp_rc_wide_dup>
    7d08:	17fffece 	b	7840 <f12+0xf0>
    7d0c:	f9000fe3 	str	x3, [sp, #24]
    7d10:	97ffec80 	bl	2f10 <fwp_tape_unlink_scope>
    7d14:	a94288bc 	ldp	x28, x2, [x5, #40]
    7d18:	f90007e2 	str	x2, [sp, #8]
    7d1c:	f9401ca2 	ldr	x2, [x5, #56]
    7d20:	b90004bf 	str	wzr, [x5, #4]
    7d24:	b94000a1 	ldr	w1, [x5]
    7d28:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7d2c:	f9000be2 	str	x2, [sp, #16]
    7d30:	a940acba 	ldp	x26, x11, [x5, #8]
    7d34:	6b00003f 	cmp	w1, w0
    7d38:	a941eca9 	ldp	x9, x27, [x5, #24]
    7d3c:	f9400fe3 	ldr	x3, [sp, #24]
    7d40:	f94020a4 	ldr	x4, [x5, #64]
    7d44:	f94024a2 	ldr	x2, [x5, #72]
    7d48:	54000108 	b.hi	7d68 <f12+0x618>  // b.pmore
    7d4c:	910102c1 	add	x1, x22, #0x40
    7d50:	92403ea0 	and	x0, x21, #0xffff
    7d54:	d1000400 	sub	x0, x0, #0x1
    7d58:	f9404c2a 	ldr	x10, [x1, #152]
    7d5c:	eb0a001f 	cmp	x0, x10
    7d60:	5400004a 	b.ge	7d68 <f12+0x618>  // b.tcont
    7d64:	f9004c20 	str	x0, [x1, #152]
    7d68:	4f000400 	movi	v0.4s, #0x0
    7d6c:	910102c1 	add	x1, x22, #0x40
    7d70:	90ffffe0 	adrp	x0, 3000 <fwp_segv+0x10>
    7d74:	9133c000 	add	x0, x0, #0xcf0
    7d78:	f9000cbf 	str	xzr, [x5, #24]
    7d7c:	910163e6 	add	x6, sp, #0x58
    7d80:	f941602a 	ldr	x10, [x1, #704]
    7d84:	3c8080a0 	stur	q0, [x5, #8]
    7d88:	9101c3f3 	add	x19, sp, #0x70
    7d8c:	a90583ea 	stp	x10, x0, [sp, #88]
    7d90:	f94007e0 	ldr	x0, [sp, #8]
    7d94:	ad0100a0 	stp	q0, q0, [x5, #32]
    7d98:	f90043e0 	str	x0, [sp, #128]
    7d9c:	f9400be0 	ldr	x0, [sp, #16]
    7da0:	f9000fe6 	str	x6, [sp, #24]
    7da4:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    7da8:	a906eff3 	stp	x19, x27, [sp, #104]
    7dac:	f9003ffc 	str	x28, [sp, #120]
    7db0:	f90047e0 	str	x0, [sp, #136]
    7db4:	a90927e4 	stp	x4, x9, [sp, #144]
    7db8:	f90053e2 	str	x2, [sp, #160]
    7dbc:	f9016026 	str	x6, [x1, #704]
    7dc0:	b7f82083 	tbnz	x3, #63, 81d0 <f12+0xa80>
    7dc4:	eb8382bf 	cmp	x21, x3, asr #32
    7dc8:	540000e0 	b.eq	7de4 <f12+0x694>  // b.none
    7dcc:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    7dd0:	912b4000 	add	x0, x0, #0xad0
    7dd4:	97fff00f 	bl	3e10 <fwp_trap>
    7dd8:	d2800d01 	mov	x1, #0x68                  	// #104
    7ddc:	d280003a 	mov	x26, #0x1                   	// #1
    7de0:	17fffecf 	b	791c <f12+0x1cc>
    7de4:	92407c60 	and	x0, x3, #0xffffffff
    7de8:	eb00035f 	cmp	x26, x0
    7dec:	9a80c755 	csinc	x21, x26, x0, gt
    7df0:	eb23417f 	cmp	x11, w3, uxtw
    7df4:	54001f8d 	b.le	81e4 <f12+0xa94>
    7df8:	eb15005f 	cmp	x2, x21
    7dfc:	54001faa 	b.ge	81f0 <f12+0xaa0>  // b.tcont
    7e00:	f100005f 	cmp	x2, #0x0
    7e04:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7e08:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    7e0c:	14000004 	b	7e1c <f12+0x6cc>
    7e10:	eb01005f 	cmp	x2, x1
    7e14:	d37ff842 	lsl	x2, x2, #1
    7e18:	9a95d042 	csel	x2, x2, x21, le
    7e1c:	eb15005f 	cmp	x2, x21
    7e20:	54ffff8b 	b.lt	7e10 <f12+0x6c0>  // b.tstop
    7e24:	f90017e3 	str	x3, [sp, #40]
    7e28:	b40027a4 	cbz	x4, 831c <f12+0xbcc>
    7e2c:	aa0403e0 	mov	x0, x4
    7e30:	d37df041 	lsl	x1, x2, #3
    7e34:	f90013e2 	str	x2, [sp, #32]
    7e38:	97ffea6a 	bl	27e0 <realloc@plt>
    7e3c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7e40:	aa0003e4 	mov	x4, x0
    7e44:	b4001d64 	cbz	x4, 81f0 <f12+0xaa0>
    7e48:	f9004be4 	str	x4, [sp, #144]
    7e4c:	f90053e2 	str	x2, [sp, #160]
    7e50:	b5001b15 	cbnz	x21, 81b0 <f12+0xa60>
    7e54:	b7f800c3 	tbnz	x3, #63, 7e6c <f12+0x71c>
    7e58:	92407c63 	and	x3, x3, #0xffffffff
    7e5c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7e60:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    7e64:	1e612800 	fadd	d0, d0, d1
    7e68:	fc237880 	str	d0, [x4, x3, lsl #3]
    7e6c:	d10006a0 	sub	x0, x21, #0x1
    7e70:	d1000743 	sub	x3, x26, #0x1
    7e74:	eb00035f 	cmp	x26, x0
    7e78:	540003ec 	b.gt	7ef4 <f12+0x7a4>
    7e7c:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    7e80:	1e602008 	fcmp	d0, #0.0
    7e84:	54000320 	b.eq	7ee8 <f12+0x798>  // b.none
    7e88:	cb1a0be1 	neg	x1, x26, lsl #2
    7e8c:	cb1a03e5 	neg	x5, x26
    7e90:	8b010362 	add	x2, x27, x1
    7e94:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    7e98:	37f80122 	tbnz	w2, #31, 7ebc <f12+0x76c>
    7e9c:	f94007e6 	ldr	x6, [sp, #8]
    7ea0:	93407c42 	sxtw	x2, w2
    7ea4:	8b050cc9 	add	x9, x6, x5, lsl #3
    7ea8:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    7eac:	fc607922 	ldr	d2, [x9, x0, lsl #3]
    7eb0:	1e620802 	fmul	d2, d0, d2
    7eb4:	1e622821 	fadd	d1, d1, d2
    7eb8:	fc227881 	str	d1, [x4, x2, lsl #3]
    7ebc:	8b010381 	add	x1, x28, x1
    7ec0:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    7ec4:	37f80121 	tbnz	w1, #31, 7ee8 <f12+0x798>
    7ec8:	f9400be2 	ldr	x2, [sp, #16]
    7ecc:	93407c21 	sxtw	x1, w1
    7ed0:	8b050c45 	add	x5, x2, x5, lsl #3
    7ed4:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    7ed8:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    7edc:	1e620800 	fmul	d0, d0, d2
    7ee0:	1e602820 	fadd	d0, d1, d0
    7ee4:	fc217880 	str	d0, [x4, x1, lsl #3]
    7ee8:	d1000400 	sub	x0, x0, #0x1
    7eec:	eb00007f 	cmp	x3, x0
    7ef0:	54fffc61 	b.ne	7e7c <f12+0x72c>  // b.any
    7ef4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7ef8:	eb00035f 	cmp	x26, x0
    7efc:	54001a28 	b.hi	8240 <f12+0xaf0>  // b.pmore
    7f00:	91000740 	add	x0, x26, #0x1
    7f04:	52800041 	mov	w1, #0x2                   	// #2
    7f08:	f90007e4 	str	x4, [sp, #8]
    7f0c:	d37df000 	lsl	x0, x0, #3
    7f10:	97fff338 	bl	4bf0 <fwp_heap_alloc>
    7f14:	aa0003fb 	mov	x27, x0
    7f18:	f800841a 	str	x26, [x0], #8
    7f1c:	f94007e4 	ldr	x4, [sp, #8]
    7f20:	d2800001 	mov	x1, #0x0                   	// #0
    7f24:	b40000da 	cbz	x26, 7f3c <f12+0x7ec>
    7f28:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    7f2c:	f8217802 	str	x2, [x0, x1, lsl #3]
    7f30:	91000421 	add	x1, x1, #0x1
    7f34:	eb01035f 	cmp	x26, x1
    7f38:	54ffff81 	b.ne	7f28 <f12+0x7d8>  // b.any
    7f3c:	910102c1 	add	x1, x22, #0x40
    7f40:	f9400fe2 	ldr	x2, [sp, #24]
    7f44:	f9416020 	ldr	x0, [x1, #704]
    7f48:	eb02001f 	cmp	x0, x2
    7f4c:	54003da1 	b.ne	8700 <f12+0xfb0>  // b.any
    7f50:	f9402ff5 	ldr	x21, [sp, #88]
    7f54:	aa1303e0 	mov	x0, x19
    7f58:	f9016035 	str	x21, [x1, #704]
    7f5c:	97ffef65 	bl	3cf0 <fwp_tape_buffers_release>
    7f60:	911542e2 	add	x2, x23, #0x550
    7f64:	f949d841 	ldr	x1, [x2, #5040]
    7f68:	f949ec40 	ldr	x0, [x2, #5080]
    7f6c:	cb010361 	sub	x1, x27, x1
    7f70:	eb00403f 	cmp	x1, x0, lsl #16
    7f74:	54000322 	b.cs	7fd8 <f12+0x888>  // b.hs, b.nlast
    7f78:	d350fc20 	lsr	x0, x1, #16
    7f7c:	f949fc43 	ldr	x3, [x2, #5112]
    7f80:	8b000800 	add	x0, x0, x0, lsl #2
    7f84:	d37df002 	lsl	x2, x0, #3
    7f88:	8b020060 	add	x0, x3, x2
    7f8c:	f9401013 	ldr	x19, [x0, #32]
    7f90:	b4000253 	cbz	x19, 7fd8 <f12+0x888>
    7f94:	38626862 	ldrb	w2, [x3, x2]
    7f98:	7100085f 	cmp	w2, #0x2
    7f9c:	54001ba0 	b.eq	8310 <f12+0xbc0>  // b.none
    7fa0:	7100045f 	cmp	w2, #0x1
    7fa4:	540001a1 	b.ne	7fd8 <f12+0x888>  // b.any
    7fa8:	29430002 	ldp	w2, w0, [x0, #24]
    7fac:	92403c21 	and	x1, x1, #0xffff
    7fb0:	9b027c21 	mul	x1, x1, x2
    7fb4:	d360fc21 	lsr	x1, x1, #32
    7fb8:	eb00003f 	cmp	x1, x0
    7fbc:	540000e2 	b.cs	7fd8 <f12+0x888>  // b.hs, b.nlast
    7fc0:	8b010273 	add	x19, x19, x1
    7fc4:	39400260 	ldrb	w0, [x19]
    7fc8:	7103fc1f 	cmp	w0, #0xff
    7fcc:	540038e0 	b.eq	86e8 <f12+0xf98>  // b.none
    7fd0:	52800020 	mov	w0, #0x1                   	// #1
    7fd4:	39000260 	strb	w0, [x19]
    7fd8:	eb1902bf 	cmp	x21, x25
    7fdc:	54003921 	b.ne	8700 <f12+0xfb0>  // b.any
    7fe0:	f94023e1 	ldr	x1, [sp, #64]
    7fe4:	910102d6 	add	x22, x22, #0x40
    7fe8:	aa1803e0 	mov	x0, x24
    7fec:	f90162c1 	str	x1, [x22, #704]
    7ff0:	97fff910 	bl	6430 <fwp_tape_scope_release>
    7ff4:	f9400360 	ldr	x0, [x27]
    7ff8:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7ffc:	b7f81360 	tbnz	x0, #63, 8268 <f12+0xb18>
    8000:	911542e2 	add	x2, x23, #0x550
    8004:	f949d840 	ldr	x0, [x2, #5040]
    8008:	f949ec41 	ldr	x1, [x2, #5080]
    800c:	cb000360 	sub	x0, x27, x0
    8010:	eb01401f 	cmp	x0, x1, lsl #16
    8014:	540012a2 	b.cs	8268 <f12+0xb18>  // b.hs, b.nlast
    8018:	d350fc01 	lsr	x1, x0, #16
    801c:	f949fc44 	ldr	x4, [x2, #5112]
    8020:	8b010821 	add	x1, x1, x1, lsl #2
    8024:	d37df021 	lsl	x1, x1, #3
    8028:	8b010083 	add	x3, x4, x1
    802c:	f9401062 	ldr	x2, [x3, #32]
    8030:	b40011c2 	cbz	x2, 8268 <f12+0xb18>
    8034:	38616881 	ldrb	w1, [x4, x1]
    8038:	7100083f 	cmp	w1, #0x2
    803c:	54001120 	b.eq	8260 <f12+0xb10>  // b.none
    8040:	7100043f 	cmp	w1, #0x1
    8044:	54001121 	b.ne	8268 <f12+0xb18>  // b.any
    8048:	29430464 	ldp	w4, w1, [x3, #24]
    804c:	92403c00 	and	x0, x0, #0xffff
    8050:	9b047c00 	mul	x0, x0, x4
    8054:	d360fc00 	lsr	x0, x0, #32
    8058:	eb01001f 	cmp	x0, x1
    805c:	54001062 	b.cs	8268 <f12+0xb18>  // b.hs, b.nlast
    8060:	8b000042 	add	x2, x2, x0
    8064:	39400040 	ldrb	w0, [x2]
    8068:	7100041f 	cmp	w0, #0x1
    806c:	54000fe1 	b.ne	8268 <f12+0xb18>  // b.any
    8070:	aa1b03f6 	mov	x22, x27
    8074:	aa1b03f5 	mov	x21, x27
    8078:	d2800000 	mov	x0, #0x0                   	// #0
    807c:	910022a2 	add	x2, x21, #0x8
    8080:	d2800001 	mov	x1, #0x0                   	// #0
    8084:	b40001f8 	cbz	x24, 80c0 <f12+0x970>
    8088:	d0000023 	adrp	x3, e000 <_IO_stdin_used+0x840>
    808c:	91002364 	add	x4, x27, #0x8
    8090:	fd424861 	ldr	d1, [x3, #1168]
    8094:	f9400365 	ldr	x5, [x27]
    8098:	aa0403e3 	mov	x3, x4
    809c:	b7f80de5 	tbnz	x5, #63, 8258 <f12+0xb08>
    80a0:	f94002c5 	ldr	x5, [x22]
    80a4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    80a8:	b7f80d25 	tbnz	x5, #63, 824c <f12+0xafc>
    80ac:	1e600820 	fmul	d0, d1, d0
    80b0:	91000421 	add	x1, x1, #0x1
    80b4:	fc008440 	str	d0, [x2], #8
    80b8:	eb01031f 	cmp	x24, x1
    80bc:	54fffec1 	b.ne	8094 <f12+0x944>  // b.any
    80c0:	97fffa3c 	bl	69b0 <fwp_drop4>
    80c4:	b4003094 	cbz	x20, 86d4 <f12+0xf84>
    80c8:	aa1403e0 	mov	x0, x20
    80cc:	d2800013 	mov	x19, #0x0                   	// #0
    80d0:	f9400800 	ldr	x0, [x0, #16]
    80d4:	91000673 	add	x19, x19, #0x1
    80d8:	b5ffffc0 	cbnz	x0, 80d0 <f12+0x980>
    80dc:	f94002c0 	ldr	x0, [x22]
    80e0:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    80e4:	b7f81300 	tbnz	x0, #63, 8344 <f12+0xbf4>
    80e8:	911542e1 	add	x1, x23, #0x550
    80ec:	f949d820 	ldr	x0, [x1, #5040]
    80f0:	f949ec22 	ldr	x2, [x1, #5080]
    80f4:	cb0002a0 	sub	x0, x21, x0
    80f8:	eb02401f 	cmp	x0, x2, lsl #16
    80fc:	54001222 	b.cs	8340 <f12+0xbf0>  // b.hs, b.nlast
    8100:	d350fc02 	lsr	x2, x0, #16
    8104:	d2800503 	mov	x3, #0x28                  	// #40
    8108:	f949fc24 	ldr	x4, [x1, #5112]
    810c:	9b037c42 	mul	x2, x2, x3
    8110:	8b020083 	add	x3, x4, x2
    8114:	f9401061 	ldr	x1, [x3, #32]
    8118:	b4001141 	cbz	x1, 8340 <f12+0xbf0>
    811c:	38626882 	ldrb	w2, [x4, x2]
    8120:	7100085f 	cmp	w2, #0x2
    8124:	540010a0 	b.eq	8338 <f12+0xbe8>  // b.none
    8128:	7100045f 	cmp	w2, #0x1
    812c:	540010a1 	b.ne	8340 <f12+0xbf0>  // b.any
    8130:	29430864 	ldp	w4, w2, [x3, #24]
    8134:	92403c00 	and	x0, x0, #0xffff
    8138:	9b047c00 	mul	x0, x0, x4
    813c:	d360fc00 	lsr	x0, x0, #32
    8140:	eb02001f 	cmp	x0, x2
    8144:	54000fe2 	b.cs	8340 <f12+0xbf0>  // b.hs, b.nlast
    8148:	8b000021 	add	x1, x1, x0
    814c:	3940003c 	ldrb	w28, [x1]
    8150:	7100079f 	cmp	w28, #0x1
    8154:	54000f61 	b.ne	8340 <f12+0xbf0>  // b.any
    8158:	910022d8 	add	x24, x22, #0x8
    815c:	eb13033f 	cmp	x25, x19
    8160:	9a939339 	csel	x25, x25, x19, ls	// ls = plast
    8164:	b4002a79 	cbz	x25, 86b0 <f12+0xf60>
    8168:	d37df324 	lsl	x4, x25, #3
    816c:	aa1403e1 	mov	x1, x20
    8170:	910022a3 	add	x3, x21, #0x8
    8174:	d2800000 	mov	x0, #0x0                   	// #0
    8178:	14000009 	b	819c <f12+0xa4c>
    817c:	fc606841 	ldr	d1, [x2, x0]
    8180:	fd400420 	ldr	d0, [x1, #8]
    8184:	1e613800 	fsub	d0, d0, d1
    8188:	fc206b00 	str	d0, [x24, x0]
    818c:	91002000 	add	x0, x0, #0x8
    8190:	f9400821 	ldr	x1, [x1, #16]
    8194:	eb04001f 	cmp	x0, x4
    8198:	54001020 	b.eq	839c <f12+0xc4c>  // b.none
    819c:	f94002c5 	ldr	x5, [x22]
    81a0:	aa0303e2 	mov	x2, x3
    81a4:	b6fffec5 	tbz	x5, #63, 817c <f12+0xa2c>
    81a8:	f9400aa2 	ldr	x2, [x21, #16]
    81ac:	17fffff4 	b	817c <f12+0xa2c>
    81b0:	aa0403e0 	mov	x0, x4
    81b4:	d37df2a2 	lsl	x2, x21, #3
    81b8:	52800001 	mov	w1, #0x0                   	// #0
    81bc:	f90013e3 	str	x3, [sp, #32]
    81c0:	97ffe980 	bl	27c0 <memset@plt>
    81c4:	aa0003e4 	mov	x4, x0
    81c8:	f94013e3 	ldr	x3, [sp, #32]
    81cc:	17ffff22 	b	7e54 <f12+0x704>
    81d0:	aa1a03f5 	mov	x21, x26
    81d4:	17ffff09 	b	7df8 <f12+0x6a8>
    81d8:	aa1b03e0 	mov	x0, x27
    81dc:	97ffef2d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    81e0:	17fffe6a 	b	7b88 <f12+0x438>
    81e4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    81e8:	912d2000 	add	x0, x0, #0xb48
    81ec:	97ffef09 	bl	3e10 <fwp_trap>
    81f0:	f10002bf 	cmp	x21, #0x0
    81f4:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    81f8:	54ffe2c1 	b.ne	7e50 <f12+0x700>  // b.any
    81fc:	f9402fe1 	ldr	x1, [sp, #88]
    8200:	910102d6 	add	x22, x22, #0x40
    8204:	aa1303e0 	mov	x0, x19
    8208:	f90162c1 	str	x1, [x22, #704]
    820c:	97ffeeb9 	bl	3cf0 <fwp_tape_buffers_release>
    8210:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8214:	f947e863 	ldr	x3, [x3, #4048]
    8218:	d2800262 	mov	x2, #0x13                  	// #19
    821c:	d2800021 	mov	x1, #0x1                   	// #1
    8220:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    8224:	911f2000 	add	x0, x0, #0x7c8
    8228:	f9400063 	ldr	x3, [x3]
    822c:	97ffe9b1 	bl	28f0 <fwrite@plt>
    8230:	d2800000 	mov	x0, #0x0                   	// #0
    8234:	97ffe9bb 	bl	2920 <fflush@plt>
    8238:	52800cc0 	mov	w0, #0x66                  	// #102
    823c:	97ffe9c9 	bl	2960 <_Exit@plt>
    8240:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    8244:	9130e000 	add	x0, x0, #0xc38
    8248:	97ffeef2 	bl	3e10 <fwp_trap>
    824c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    8250:	91312000 	add	x0, x0, #0xc48
    8254:	97ffeeef 	bl	3e10 <fwp_trap>
    8258:	f9400b63 	ldr	x3, [x27, #16]
    825c:	17ffff91 	b	80a0 <f12+0x950>
    8260:	72003c1f 	tst	w0, #0xffff
    8264:	54fff000 	b.eq	8064 <f12+0x914>  // b.none
    8268:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    826c:	eb00031f 	cmp	x24, x0
    8270:	54fffe88 	b.hi	8240 <f12+0xaf0>  // b.pmore
    8274:	91000700 	add	x0, x24, #0x1
    8278:	52800021 	mov	w1, #0x1                   	// #1
    827c:	d37df000 	lsl	x0, x0, #3
    8280:	97fff25c 	bl	4bf0 <fwp_heap_alloc>
    8284:	911542e2 	add	x2, x23, #0x550
    8288:	f9000018 	str	x24, [x0]
    828c:	aa0003f6 	mov	x22, x0
    8290:	aa0003f5 	mov	x21, x0
    8294:	f949d841 	ldr	x1, [x2, #5040]
    8298:	f949ec40 	ldr	x0, [x2, #5080]
    829c:	cb0102c1 	sub	x1, x22, x1
    82a0:	eb00403f 	cmp	x1, x0, lsl #16
    82a4:	54000322 	b.cs	8308 <f12+0xbb8>  // b.hs, b.nlast
    82a8:	d350fc20 	lsr	x0, x1, #16
    82ac:	d2800504 	mov	x4, #0x28                  	// #40
    82b0:	f949fc43 	ldr	x3, [x2, #5112]
    82b4:	9b047c00 	mul	x0, x0, x4
    82b8:	8b000062 	add	x2, x3, x0
    82bc:	f9401053 	ldr	x19, [x2, #32]
    82c0:	b4000253 	cbz	x19, 8308 <f12+0xbb8>
    82c4:	38606860 	ldrb	w0, [x3, x0]
    82c8:	7100081f 	cmp	w0, #0x2
    82cc:	54001fc0 	b.eq	86c4 <f12+0xf74>  // b.none
    82d0:	7100041f 	cmp	w0, #0x1
    82d4:	540001a1 	b.ne	8308 <f12+0xbb8>  // b.any
    82d8:	29430043 	ldp	w3, w0, [x2, #24]
    82dc:	92403c21 	and	x1, x1, #0xffff
    82e0:	9b037c21 	mul	x1, x1, x3
    82e4:	d360fc21 	lsr	x1, x1, #32
    82e8:	eb00003f 	cmp	x1, x0
    82ec:	540000e2 	b.cs	8308 <f12+0xbb8>  // b.hs, b.nlast
    82f0:	8b010273 	add	x19, x19, x1
    82f4:	39400260 	ldrb	w0, [x19]
    82f8:	7103fc1f 	cmp	w0, #0xff
    82fc:	54001de0 	b.eq	86b8 <f12+0xf68>  // b.none
    8300:	52800020 	mov	w0, #0x1                   	// #1
    8304:	39000260 	strb	w0, [x19]
    8308:	aa1b03e0 	mov	x0, x27
    830c:	17ffff5c 	b	807c <f12+0x92c>
    8310:	72003c3f 	tst	w1, #0xffff
    8314:	54ffe621 	b.ne	7fd8 <f12+0x888>  // b.any
    8318:	17ffff2b 	b	7fc4 <f12+0x874>
    831c:	aa0203e0 	mov	x0, x2
    8320:	d2800101 	mov	x1, #0x8                   	// #8
    8324:	f90013e2 	str	x2, [sp, #32]
    8328:	97ffe92a 	bl	27d0 <calloc@plt>
    832c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    8330:	aa0003e4 	mov	x4, x0
    8334:	17fffec4 	b	7e44 <f12+0x6f4>
    8338:	72003c1f 	tst	w0, #0xffff
    833c:	54fff080 	b.eq	814c <f12+0x9fc>  // b.none
    8340:	b4001af4 	cbz	x20, 869c <f12+0xf4c>
    8344:	aa1403fa 	mov	x26, x20
    8348:	d2800013 	mov	x19, #0x0                   	// #0
    834c:	f9400b5a 	ldr	x26, [x26, #16]
    8350:	aa1303e0 	mov	x0, x19
    8354:	91000673 	add	x19, x19, #0x1
    8358:	b5ffffba 	cbnz	x26, 834c <f12+0xbfc>
    835c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8360:	eb01027f 	cmp	x19, x1
    8364:	54ffb908 	b.hi	7a84 <f12+0x334>  // b.pmore
    8368:	91000800 	add	x0, x0, #0x2
    836c:	52800041 	mov	w1, #0x2                   	// #2
    8370:	d37df000 	lsl	x0, x0, #3
    8374:	97fff21f 	bl	4bf0 <fwp_heap_alloc>
    8378:	aa1403e1 	mov	x1, x20
    837c:	aa0003f8 	mov	x24, x0
    8380:	f9400420 	ldr	x0, [x1, #8]
    8384:	f83a7b00 	str	x0, [x24, x26, lsl #3]
    8388:	9100075a 	add	x26, x26, #0x1
    838c:	f9400821 	ldr	x1, [x1, #16]
    8390:	b5ffff81 	cbnz	x1, 8380 <f12+0xc30>
    8394:	5280001c 	mov	w28, #0x0                   	// #0
    8398:	17ffff71 	b	815c <f12+0xa0c>
    839c:	b40017d4 	cbz	x20, 8694 <f12+0xf44>
    83a0:	911542e0 	add	x0, x23, #0x550
    83a4:	aa1403e2 	mov	x2, x20
    83a8:	d280001b 	mov	x27, #0x0                   	// #0
    83ac:	f949ec04 	ldr	x4, [x0, #5080]
    83b0:	f949d807 	ldr	x7, [x0, #5040]
    83b4:	f949fc06 	ldr	x6, [x0, #5112]
    83b8:	d370bc84 	lsl	x4, x4, #16
    83bc:	14000006 	b	83d4 <f12+0xc84>
    83c0:	f9400842 	ldr	x2, [x2, #16]
    83c4:	9100077b 	add	x27, x27, #0x1
    83c8:	f100005f 	cmp	x2, #0x0
    83cc:	fa591362 	ccmp	x27, x25, #0x2, ne	// ne = any
    83d0:	54000322 	b.cs	8434 <f12+0xce4>  // b.hs, b.nlast
    83d4:	cb070040 	sub	x0, x2, x7
    83d8:	eb04001f 	cmp	x0, x4
    83dc:	540002c2 	b.cs	8434 <f12+0xce4>  // b.hs, b.nlast
    83e0:	d350fc01 	lsr	x1, x0, #16
    83e4:	8b010821 	add	x1, x1, x1, lsl #2
    83e8:	d37df021 	lsl	x1, x1, #3
    83ec:	8b0100c5 	add	x5, x6, x1
    83f0:	f94010a3 	ldr	x3, [x5, #32]
    83f4:	b4000203 	cbz	x3, 8434 <f12+0xce4>
    83f8:	386168c1 	ldrb	w1, [x6, x1]
    83fc:	7100083f 	cmp	w1, #0x2
    8400:	54000820 	b.eq	8504 <f12+0xdb4>  // b.none
    8404:	7100043f 	cmp	w1, #0x1
    8408:	54000161 	b.ne	8434 <f12+0xce4>  // b.any
    840c:	294304a8 	ldp	w8, w1, [x5, #24]
    8410:	92403c00 	and	x0, x0, #0xffff
    8414:	9b087c00 	mul	x0, x0, x8
    8418:	d360fc00 	lsr	x0, x0, #32
    841c:	eb01001f 	cmp	x0, x1
    8420:	540000a2 	b.cs	8434 <f12+0xce4>  // b.hs, b.nlast
    8424:	8b000063 	add	x3, x3, x0
    8428:	39400060 	ldrb	w0, [x3]
    842c:	7100041f 	cmp	w0, #0x1
    8430:	54fffc80 	b.eq	83c0 <f12+0xc70>  // b.none
    8434:	d280001a 	mov	x26, #0x0                   	// #0
    8438:	eb19037f 	cmp	x27, x25
    843c:	540010e2 	b.cs	8658 <f12+0xf08>  // b.hs, b.nlast
    8440:	d1002300 	sub	x0, x24, #0x8
    8444:	aa1903f3 	mov	x19, x25
    8448:	911542f6 	add	x22, x23, #0x550
    844c:	d280001a 	mov	x26, #0x0                   	// #0
    8450:	f9000be0 	str	x0, [sp, #16]
    8454:	9102a3e0 	add	x0, sp, #0xa8
    8458:	f90007e0 	str	x0, [sp, #8]
    845c:	14000012 	b	84a4 <f12+0xd54>
    8460:	7100045f 	cmp	w2, #0x1
    8464:	540001a1 	b.ne	8498 <f12+0xd48>  // b.any
    8468:	294308a6 	ldp	w6, w2, [x5, #24]
    846c:	92403c21 	and	x1, x1, #0xffff
    8470:	9b067c21 	mul	x1, x1, x6
    8474:	d360fc21 	lsr	x1, x1, #32
    8478:	eb02003f 	cmp	x1, x2
    847c:	540000e2 	b.cs	8498 <f12+0xd48>  // b.hs, b.nlast
    8480:	8b010000 	add	x0, x0, x1
    8484:	39400001 	ldrb	w1, [x0]
    8488:	7103fc3f 	cmp	w1, #0xff
    848c:	54000420 	b.eq	8510 <f12+0xdc0>  // b.none
    8490:	52800021 	mov	w1, #0x1                   	// #1
    8494:	39000001 	strb	w1, [x0]
    8498:	d1000673 	sub	x19, x19, #0x1
    849c:	eb1b027f 	cmp	x19, x27
    84a0:	54000409 	b.ls	8520 <f12+0xdd0>  // b.plast
    84a4:	a94083e1 	ldp	x1, x0, [sp, #8]
    84a8:	f8737802 	ldr	x2, [x0, x19, lsl #3]
    84ac:	52800020 	mov	w0, #0x1                   	// #1
    84b0:	a90aebe2 	stp	x2, x26, [sp, #168]
    84b4:	97fff4c4 	bl	57c4 <fwp_data.part.0.constprop.0>
    84b8:	aa0003fa 	mov	x26, x0
    84bc:	f949dac1 	ldr	x1, [x22, #5040]
    84c0:	f949eec0 	ldr	x0, [x22, #5080]
    84c4:	cb010341 	sub	x1, x26, x1
    84c8:	eb00403f 	cmp	x1, x0, lsl #16
    84cc:	54fffe62 	b.cs	8498 <f12+0xd48>  // b.hs, b.nlast
    84d0:	d350fc20 	lsr	x0, x1, #16
    84d4:	f949fec6 	ldr	x6, [x22, #5112]
    84d8:	8b000800 	add	x0, x0, x0, lsl #2
    84dc:	d37df002 	lsl	x2, x0, #3
    84e0:	8b0200c5 	add	x5, x6, x2
    84e4:	f94010a0 	ldr	x0, [x5, #32]
    84e8:	b4fffd80 	cbz	x0, 8498 <f12+0xd48>
    84ec:	386268c2 	ldrb	w2, [x6, x2]
    84f0:	7100085f 	cmp	w2, #0x2
    84f4:	54fffb61 	b.ne	8460 <f12+0xd10>  // b.any
    84f8:	72003c3f 	tst	w1, #0xffff
    84fc:	54fffce1 	b.ne	8498 <f12+0xd48>  // b.any
    8500:	17ffffe1 	b	8484 <f12+0xd34>
    8504:	72003c1f 	tst	w0, #0xffff
    8508:	54fff961 	b.ne	8434 <f12+0xce4>  // b.any
    850c:	17ffffc7 	b	8428 <f12+0xcd8>
    8510:	f9000fe0 	str	x0, [sp, #24]
    8514:	97ffee5f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8518:	f9400fe0 	ldr	x0, [sp, #24]
    851c:	17ffffdd 	b	8490 <f12+0xd40>
    8520:	d1000721 	sub	x1, x25, #0x1
    8524:	cb190360 	sub	x0, x27, x25
    8528:	eb01037f 	cmp	x27, x1
    852c:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8530:	8b010000 	add	x0, x0, x1
    8534:	b500093b 	cbnz	x27, 8658 <f12+0xf08>
    8538:	7100039f 	cmp	w28, #0x0
    853c:	9a9813fb 	csel	x27, xzr, x24, ne	// ne = any
    8540:	b4000520 	cbz	x0, 85e4 <f12+0xe94>
    8544:	d1000413 	sub	x19, x0, #0x1
    8548:	911542f7 	add	x23, x23, #0x550
    854c:	52800039 	mov	w25, #0x1                   	// #1
    8550:	f8737b62 	ldr	x2, [x27, x19, lsl #3]
    8554:	52800020 	mov	w0, #0x1                   	// #1
    8558:	f94007e1 	ldr	x1, [sp, #8]
    855c:	a90aebe2 	stp	x2, x26, [sp, #168]
    8560:	97fff499 	bl	57c4 <fwp_data.part.0.constprop.0>
    8564:	aa0003fa 	mov	x26, x0
    8568:	f949dae1 	ldr	x1, [x23, #5040]
    856c:	f949eee0 	ldr	x0, [x23, #5080]
    8570:	cb010341 	sub	x1, x26, x1
    8574:	eb00403f 	cmp	x1, x0, lsl #16
    8578:	54000302 	b.cs	85d8 <f12+0xe88>  // b.hs, b.nlast
    857c:	d350fc20 	lsr	x0, x1, #16
    8580:	f949fee3 	ldr	x3, [x23, #5112]
    8584:	8b000800 	add	x0, x0, x0, lsl #2
    8588:	d37df002 	lsl	x2, x0, #3
    858c:	8b020060 	add	x0, x3, x2
    8590:	f9401018 	ldr	x24, [x0, #32]
    8594:	b4000238 	cbz	x24, 85d8 <f12+0xe88>
    8598:	38626862 	ldrb	w2, [x3, x2]
    859c:	7100085f 	cmp	w2, #0x2
    85a0:	540004e0 	b.eq	863c <f12+0xeec>  // b.none
    85a4:	7100045f 	cmp	w2, #0x1
    85a8:	54000181 	b.ne	85d8 <f12+0xe88>  // b.any
    85ac:	29430002 	ldp	w2, w0, [x0, #24]
    85b0:	92403c21 	and	x1, x1, #0xffff
    85b4:	9b027c21 	mul	x1, x1, x2
    85b8:	d360fc21 	lsr	x1, x1, #32
    85bc:	eb00003f 	cmp	x1, x0
    85c0:	540000c2 	b.cs	85d8 <f12+0xe88>  // b.hs, b.nlast
    85c4:	8b010318 	add	x24, x24, x1
    85c8:	39400300 	ldrb	w0, [x24]
    85cc:	7103fc1f 	cmp	w0, #0xff
    85d0:	540003c0 	b.eq	8648 <f12+0xef8>  // b.none
    85d4:	39000319 	strb	w25, [x24]
    85d8:	d1000673 	sub	x19, x19, #0x1
    85dc:	b100067f 	cmn	x19, #0x1
    85e0:	54fffb81 	b.ne	8550 <f12+0xe00>  // b.any
    85e4:	aa1b03e0 	mov	x0, x27
    85e8:	97ffeec6 	bl	4100 <fwp_mem_free>
    85ec:	aa1503e0 	mov	x0, x21
    85f0:	97fff8f0 	bl	69b0 <fwp_drop4>
    85f4:	aa1403e0 	mov	x0, x20
    85f8:	97fff642 	bl	5f00 <fwp_drop0>
    85fc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8600:	f947f400 	ldr	x0, [x0, #4072]
    8604:	f9405fe2 	ldr	x2, [sp, #184]
    8608:	f9400001 	ldr	x1, [x0]
    860c:	eb010042 	subs	x2, x2, x1
    8610:	d2800001 	mov	x1, #0x0                   	// #0
    8614:	54000201 	b.ne	8654 <f12+0xf04>  // b.any
    8618:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    861c:	aa1a03e0 	mov	x0, x26
    8620:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8624:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8628:	a94f63f7 	ldp	x23, x24, [sp, #240]
    862c:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8630:	a95173fb 	ldp	x27, x28, [sp, #272]
    8634:	910483ff 	add	sp, sp, #0x120
    8638:	d65f03c0 	ret
    863c:	72003c3f 	tst	w1, #0xffff
    8640:	54fffcc1 	b.ne	85d8 <f12+0xe88>  // b.any
    8644:	17ffffe1 	b	85c8 <f12+0xe78>
    8648:	aa1803e0 	mov	x0, x24
    864c:	97ffee11 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8650:	17ffffe1 	b	85d4 <f12+0xe84>
    8654:	97ffe867 	bl	27f0 <__stack_chk_fail@plt>
    8658:	aa1403e0 	mov	x0, x20
    865c:	d2800001 	mov	x1, #0x0                   	// #0
    8660:	f8617b02 	ldr	x2, [x24, x1, lsl #3]
    8664:	91000421 	add	x1, x1, #0x1
    8668:	f9000402 	str	x2, [x0, #8]
    866c:	aa0003e2 	mov	x2, x0
    8670:	f9400800 	ldr	x0, [x0, #16]
    8674:	eb01037f 	cmp	x27, x1
    8678:	54ffff48 	b.hi	8660 <f12+0xf10>  // b.pmore
    867c:	f900085a 	str	x26, [x2, #16]
    8680:	aa1403fa 	mov	x26, x20
    8684:	aa0003f4 	mov	x20, x0
    8688:	7100039f 	cmp	w28, #0x0
    868c:	9a9813fb 	csel	x27, xzr, x24, ne	// ne = any
    8690:	17ffffd5 	b	85e4 <f12+0xe94>
    8694:	d280001b 	mov	x27, #0x0                   	// #0
    8698:	17ffff6a 	b	8440 <f12+0xcf0>
    869c:	52800041 	mov	w1, #0x2                   	// #2
    86a0:	d2800100 	mov	x0, #0x8                   	// #8
    86a4:	97fff153 	bl	4bf0 <fwp_heap_alloc>
    86a8:	aa0003f8 	mov	x24, x0
    86ac:	5280001c 	mov	w28, #0x0                   	// #0
    86b0:	d280001a 	mov	x26, #0x0                   	// #0
    86b4:	17fffff5 	b	8688 <f12+0xf38>
    86b8:	aa1303e0 	mov	x0, x19
    86bc:	97ffedf5 	bl	3e90 <fwp_rc_forget_slot.part.0>
    86c0:	17ffff10 	b	8300 <f12+0xbb0>
    86c4:	72003c3f 	tst	w1, #0xffff
    86c8:	54ffe160 	b.eq	82f4 <f12+0xba4>  // b.none
    86cc:	aa1b03e0 	mov	x0, x27
    86d0:	17fffe6b 	b	807c <f12+0x92c>
    86d4:	f94002d9 	ldr	x25, [x22]
    86d8:	b7fffe39 	tbnz	x25, #63, 869c <f12+0xf4c>
    86dc:	9240fb39 	and	x25, x25, #0x7fffffffffffffff
    86e0:	d2800013 	mov	x19, #0x0                   	// #0
    86e4:	17fffe81 	b	80e8 <f12+0x998>
    86e8:	aa1303e0 	mov	x0, x19
    86ec:	97ffede9 	bl	3e90 <fwp_rc_forget_slot.part.0>
    86f0:	910102c0 	add	x0, x22, #0x40
    86f4:	f9416015 	ldr	x21, [x0, #704]
    86f8:	17fffe36 	b	7fd0 <f12+0x880>
    86fc:	97ffe8c1 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8700:	97ffe850 	bl	2840 <abort@plt>

0000000000008704 <fwp_owned_entry12>:
    8704:	f9400000 	ldr	x0, [x0]
    8708:	17fffc12 	b	7750 <f12>
    870c:	d503201f 	nop

0000000000008710 <e12>:
    8710:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8714:	910003fd 	mov	x29, sp
    8718:	f9000bf3 	str	x19, [sp, #16]
    871c:	f9400013 	ldr	x19, [x0]
    8720:	aa1303e0 	mov	x0, x19
    8724:	97fff470 	bl	58e4 <fwp_rc_share>
    8728:	aa1303e0 	mov	x0, x19
    872c:	97fffc09 	bl	7750 <f12>
    8730:	aa0003f3 	mov	x19, x0
    8734:	97fff46c 	bl	58e4 <fwp_rc_share>
    8738:	aa1303e0 	mov	x0, x19
    873c:	f9400bf3 	ldr	x19, [sp, #16]
    8740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8744:	d65f03c0 	ret
    8748:	d503201f 	nop
    874c:	d503201f 	nop

0000000000008750 <fwp_write>:
    8750:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8754:	910003fd 	mov	x29, sp
    8758:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    875c:	f947f484 	ldr	x4, [x4, #4072]
    8760:	a90153f3 	stp	x19, x20, [sp, #16]
    8764:	d10943ff 	sub	sp, sp, #0x250
    8768:	b9400045 	ldr	w5, [x2]
    876c:	aa0003f4 	mov	x20, x0
    8770:	f9400080 	ldr	x0, [x4]
    8774:	f90127e0 	str	x0, [sp, #584]
    8778:	d2800000 	mov	x0, #0x0                   	// #0
    877c:	710064bf 	cmp	w5, #0x19
    8780:	54000408 	b.hi	8800 <fwp_write+0xb0>  // b.pmore
    8784:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x840>
    8788:	aa0103f3 	mov	x19, x1
    878c:	910fc000 	add	x0, x0, #0x3f0
    8790:	f9013bf5 	str	x21, [sp, #624]
    8794:	f9013ff6 	str	x22, [sp, #632]
    8798:	f90153fb 	str	x27, [sp, #672]
    879c:	f90157fc 	str	x28, [sp, #680]
    87a0:	aa0203fc 	mov	x28, x2
    87a4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    87a8:	10000061 	adr	x1, 87b4 <fwp_write+0x64>
    87ac:	8b20a820 	add	x0, x1, w0, sxth #2
    87b0:	d61f0000 	br	x0
    87b4:	910123e0 	add	x0, sp, #0x48
    87b8:	aa1303e5 	mov	x5, x19
    87bc:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x47c>
    87c0:	aa0003f3 	mov	x19, x0
    87c4:	9132a084 	add	x4, x4, #0xca8
    87c8:	d2804003 	mov	x3, #0x200                 	// #512
    87cc:	aa0303e1 	mov	x1, x3
    87d0:	52800042 	mov	w2, #0x2                   	// #2
    87d4:	97ffe7e3 	bl	2760 <__snprintf_chk@plt>
    87d8:	aa1303e0 	mov	x0, x19
    87dc:	97ffe7a9 	bl	2680 <strlen@plt>
    87e0:	aa1303e1 	mov	x1, x19
    87e4:	aa0003e2 	mov	x2, x0
    87e8:	aa1403e0 	mov	x0, x20
    87ec:	97ffeae9 	bl	3390 <buf_put>
    87f0:	f9413bf5 	ldr	x21, [sp, #624]
    87f4:	f9413ff6 	ldr	x22, [sp, #632]
    87f8:	f94153fb 	ldr	x27, [sp, #672]
    87fc:	f94157fc 	ldr	x28, [sp, #680]
    8800:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8804:	f947f400 	ldr	x0, [x0, #4072]
    8808:	f94127e2 	ldr	x2, [sp, #584]
    880c:	f9400001 	ldr	x1, [x0]
    8810:	eb010042 	subs	x2, x2, x1
    8814:	d2800001 	mov	x1, #0x0                   	// #0
    8818:	540077c1 	b.ne	9710 <fwp_write+0xfc0>  // b.any
    881c:	910943ff 	add	sp, sp, #0x250
    8820:	a94153f3 	ldp	x19, x20, [sp, #16]
    8824:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8828:	d65f03c0 	ret
    882c:	910123e0 	add	x0, sp, #0x48
    8830:	aa1303e5 	mov	x5, x19
    8834:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x47c>
    8838:	aa0003f3 	mov	x19, x0
    883c:	91328084 	add	x4, x4, #0xca0
    8840:	d2804003 	mov	x3, #0x200                 	// #512
    8844:	17ffffe2 	b	87cc <fwp_write+0x7c>
    8848:	71004cbf 	cmp	w5, #0x13
    884c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x47c>
    8850:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8854:	91324000 	add	x0, x0, #0xc90
    8858:	91326021 	add	x1, x1, #0xc98
    885c:	d2800082 	mov	x2, #0x4                   	// #4
    8860:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8864:	aa1403e0 	mov	x0, x20
    8868:	f90143f7 	str	x23, [sp, #640]
    886c:	d2800016 	mov	x22, #0x0                   	// #0
    8870:	f90147f8 	str	x24, [sp, #648]
    8874:	97ffeac7 	bl	3390 <buf_put>
    8878:	f9400260 	ldr	x0, [x19]
    887c:	b0000037 	adrp	x23, d000 <fwp_main_thread+0x47c>
    8880:	d2800015 	mov	x21, #0x0                   	// #0
    8884:	913462f7 	add	x23, x23, #0xd18
    8888:	b40047a0 	cbz	x0, 917c <fwp_write+0xa2c>
    888c:	b9400380 	ldr	w0, [x28]
    8890:	52800003 	mov	w3, #0x0                   	// #0
    8894:	f9401f82 	ldr	x2, [x28, #56]
    8898:	71004c1f 	cmp	w0, #0x13
    889c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    88a0:	aa1403e0 	mov	x0, x20
    88a4:	8b010e61 	add	x1, x19, x1, lsl #3
    88a8:	f9400421 	ldr	x1, [x1, #8]
    88ac:	97ffffa9 	bl	8750 <fwp_write>
    88b0:	b9400380 	ldr	w0, [x28]
    88b4:	7100481f 	cmp	w0, #0x12
    88b8:	54004b40 	b.eq	9220 <fwp_write+0xad0>  // b.none
    88bc:	f9400260 	ldr	x0, [x19]
    88c0:	910006b5 	add	x21, x21, #0x1
    88c4:	91000ad6 	add	x22, x22, #0x2
    88c8:	eb15001f 	cmp	x0, x21
    88cc:	54004589 	b.ls	917c <fwp_write+0xa2c>  // b.plast
    88d0:	aa1703e1 	mov	x1, x23
    88d4:	aa1403e0 	mov	x0, x20
    88d8:	d2800042 	mov	x2, #0x2                   	// #2
    88dc:	97ffeaad 	bl	3390 <buf_put>
    88e0:	17ffffeb 	b	888c <fwp_write+0x13c>
    88e4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    88e8:	91334021 	add	x1, x1, #0xcd0
    88ec:	d28000c2 	mov	x2, #0x6                   	// #6
    88f0:	aa1403e0 	mov	x0, x20
    88f4:	91004273 	add	x19, x19, #0x10
    88f8:	97ffeaa6 	bl	3390 <buf_put>
    88fc:	aa1303e0 	mov	x0, x19
    8900:	97ffe760 	bl	2680 <strlen@plt>
    8904:	aa1303e1 	mov	x1, x19
    8908:	aa0003e2 	mov	x2, x0
    890c:	aa1403e0 	mov	x0, x20
    8910:	97ffeaa0 	bl	3390 <buf_put>
    8914:	528007c3 	mov	w3, #0x3e                  	// #62
    8918:	aa1403e0 	mov	x0, x20
    891c:	91001fe1 	add	x1, sp, #0x7
    8920:	d2800022 	mov	x2, #0x1                   	// #1
    8924:	39001fe3 	strb	w3, [sp, #7]
    8928:	17ffffb1 	b	87ec <fwp_write+0x9c>
    892c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8930:	f947f400 	ldr	x0, [x0, #4072]
    8934:	f94127e2 	ldr	x2, [sp, #584]
    8938:	f9400001 	ldr	x1, [x0]
    893c:	eb010042 	subs	x2, x2, x1
    8940:	d2800001 	mov	x1, #0x0                   	// #0
    8944:	540034e1 	b.ne	8fe0 <fwp_write+0x890>  // b.any
    8948:	f9413bf5 	ldr	x21, [sp, #624]
    894c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8950:	f9413ff6 	ldr	x22, [sp, #632]
    8954:	aa1403e0 	mov	x0, x20
    8958:	9132c021 	add	x1, x1, #0xcb0
    895c:	d2800142 	mov	x2, #0xa                   	// #10
    8960:	f94153fb 	ldr	x27, [sp, #672]
    8964:	f94157fc 	ldr	x28, [sp, #680]
    8968:	910943ff 	add	sp, sp, #0x250
    896c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8970:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8974:	17ffea87 	b	3390 <buf_put>
    8978:	f9400456 	ldr	x22, [x2, #8]
    897c:	f90143f7 	str	x23, [sp, #640]
    8980:	f90147f8 	str	x24, [sp, #648]
    8984:	b4005b16 	cbz	x22, 94e4 <fwp_write+0xd94>
    8988:	aa1603e0 	mov	x0, x22
    898c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8990:	9134c021 	add	x1, x1, #0xd30
    8994:	97ffe7b7 	bl	2870 <strcmp@plt>
    8998:	2a0003f5 	mov	w21, w0
    899c:	34005fe0 	cbz	w0, 9598 <fwp_write+0xe48>
    89a0:	aa1603e0 	mov	x0, x22
    89a4:	97ffe737 	bl	2680 <strlen@plt>
    89a8:	aa1603e1 	mov	x1, x22
    89ac:	aa0003e2 	mov	x2, x0
    89b0:	aa1403e0 	mov	x0, x20
    89b4:	97ffea77 	bl	3390 <buf_put>
    89b8:	52800403 	mov	w3, #0x20                  	// #32
    89bc:	91001ff5 	add	x21, sp, #0x7
    89c0:	aa1503e1 	mov	x1, x21
    89c4:	aa1403e0 	mov	x0, x20
    89c8:	d2800022 	mov	x2, #0x1                   	// #1
    89cc:	39001fe3 	strb	w3, [sp, #7]
    89d0:	97ffea70 	bl	3390 <buf_put>
    89d4:	52800f63 	mov	w3, #0x7b                  	// #123
    89d8:	aa1403e0 	mov	x0, x20
    89dc:	aa1503e1 	mov	x1, x21
    89e0:	d2800022 	mov	x2, #0x1                   	// #1
    89e4:	39001fe3 	strb	w3, [sp, #7]
    89e8:	97ffea6a 	bl	3390 <buf_put>
    89ec:	b9401380 	ldr	w0, [x28, #16]
    89f0:	52800018 	mov	w24, #0x0                   	// #0
    89f4:	7100001f 	cmp	w0, #0x0
    89f8:	54003aad 	b.le	914c <fwp_write+0x9fc>
    89fc:	f9014bf9 	str	x25, [sp, #656]
    8a00:	b0000039 	adrp	x25, d000 <fwp_main_thread+0x47c>
    8a04:	91356339 	add	x25, x25, #0xd58
    8a08:	f9014ffa 	str	x26, [sp, #664]
    8a0c:	b000003a 	adrp	x26, d000 <fwp_main_thread+0x47c>
    8a10:	9134635a 	add	x26, x26, #0xd18
    8a14:	91002276 	add	x22, x19, #0x8
    8a18:	d2800013 	mov	x19, #0x0                   	// #0
    8a1c:	b5003e93 	cbnz	x19, 91ec <fwp_write+0xa9c>
    8a20:	d37df277 	lsl	x23, x19, #3
    8a24:	34003cb8 	cbz	w24, 91b8 <fwp_write+0xa68>
    8a28:	f9401382 	ldr	x2, [x28, #32]
    8a2c:	aa1403e0 	mov	x0, x20
    8a30:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8a34:	52800003 	mov	w3, #0x0                   	// #0
    8a38:	f8776842 	ldr	x2, [x2, x23]
    8a3c:	91000673 	add	x19, x19, #0x1
    8a40:	97ffff44 	bl	8750 <fwp_write>
    8a44:	b9401380 	ldr	w0, [x28, #16]
    8a48:	6b13001f 	cmp	w0, w19
    8a4c:	54fffe8c 	b.gt	8a1c <fwp_write+0x2cc>
    8a50:	f9414bf9 	ldr	x25, [sp, #656]
    8a54:	f9414ffa 	ldr	x26, [sp, #664]
    8a58:	340037b8 	cbz	w24, 914c <fwp_write+0x9fc>
    8a5c:	52800523 	mov	w3, #0x29                  	// #41
    8a60:	aa1503e1 	mov	x1, x21
    8a64:	aa1403e0 	mov	x0, x20
    8a68:	d2800022 	mov	x2, #0x1                   	// #1
    8a6c:	39001fe3 	strb	w3, [sp, #7]
    8a70:	97ffea48 	bl	3390 <buf_put>
    8a74:	f9413bf5 	ldr	x21, [sp, #624]
    8a78:	f9413ff6 	ldr	x22, [sp, #632]
    8a7c:	f94143f7 	ldr	x23, [sp, #640]
    8a80:	f94147f8 	ldr	x24, [sp, #648]
    8a84:	f94153fb 	ldr	x27, [sp, #672]
    8a88:	f94157fc 	ldr	x28, [sp, #680]
    8a8c:	17ffff5d 	b	8800 <fwp_write+0xb0>
    8a90:	b9404855 	ldr	w21, [x2, #72]
    8a94:	aa1403e0 	mov	x0, x20
    8a98:	93407eb6 	sxtw	x22, w21
    8a9c:	91000ac1 	add	x1, x22, #0x2
    8aa0:	97ffea09 	bl	32c4 <buf_grow>
    8aa4:	a9400281 	ldp	x1, x0, [x20]
    8aa8:	528e8603 	mov	w3, #0x7430                	// #29744
    8aac:	78206823 	strh	w3, [x1, x0]
    8ab0:	8b000022 	add	x2, x1, x0
    8ab4:	710002bf 	cmp	w21, #0x0
    8ab8:	540036cd 	b.le	9190 <fwp_write+0xa40>
    8abc:	110006a3 	add	w3, w21, #0x1
    8ac0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8ac4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8ac8:	91000449 	add	x9, x2, #0x1
    8acc:	8b23c043 	add	x3, x2, w3, sxtw
    8ad0:	f28aaac6 	movk	x6, #0x5556
    8ad4:	f2955568 	movk	x8, #0xaaab
    8ad8:	1400000d 	b	8b0c <fwp_write+0x3bc>
    8adc:	d2800021 	mov	x1, #0x1                   	// #1
    8ae0:	528005a5 	mov	w5, #0x2d                  	// #45
    8ae4:	f100001f 	cmp	x0, #0x0
    8ae8:	9b467e60 	smulh	x0, x19, x6
    8aec:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8af0:	381ff465 	strb	w5, [x3], #-1
    8af4:	cb040000 	sub	x0, x0, x4
    8af8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8afc:	cb020000 	sub	x0, x0, x2
    8b00:	8b010013 	add	x19, x0, x1
    8b04:	eb03013f 	cmp	x9, x3
    8b08:	54003440 	b.eq	9190 <fwp_write+0xa40>  // b.none
    8b0c:	9b467e60 	smulh	x0, x19, x6
    8b10:	937ffe64 	asr	x4, x19, #63
    8b14:	52800605 	mov	w5, #0x30                  	// #48
    8b18:	cb040000 	sub	x0, x0, x4
    8b1c:	8b000400 	add	x0, x0, x0, lsl #1
    8b20:	cb000260 	sub	x0, x19, x0
    8b24:	91000c01 	add	x1, x0, #0x3
    8b28:	9bc87c22 	umulh	x2, x1, x8
    8b2c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8b30:	8b4204e2 	add	x2, x7, x2, lsr #1
    8b34:	eb020021 	subs	x1, x1, x2
    8b38:	54fffd60 	b.eq	8ae4 <fwp_write+0x394>  // b.none
    8b3c:	f100043f 	cmp	x1, #0x1
    8b40:	54fffce1 	b.ne	8adc <fwp_write+0x38c>  // b.any
    8b44:	d2800001 	mov	x1, #0x0                   	// #0
    8b48:	52800565 	mov	w5, #0x2b                  	// #43
    8b4c:	17ffffe6 	b	8ae4 <fwp_write+0x394>
    8b50:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b54:	f947f400 	ldr	x0, [x0, #4072]
    8b58:	f94127e2 	ldr	x2, [sp, #584]
    8b5c:	f9400001 	ldr	x1, [x0]
    8b60:	eb010042 	subs	x2, x2, x1
    8b64:	d2800001 	mov	x1, #0x0                   	// #0
    8b68:	540023c1 	b.ne	8fe0 <fwp_write+0x890>  // b.any
    8b6c:	f9413bf5 	ldr	x21, [sp, #624]
    8b70:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8b74:	f9413ff6 	ldr	x22, [sp, #632]
    8b78:	aa1403e0 	mov	x0, x20
    8b7c:	91330021 	add	x1, x1, #0xcc0
    8b80:	d2800102 	mov	x2, #0x8                   	// #8
    8b84:	17ffff77 	b	8960 <fwp_write+0x210>
    8b88:	aa1403e0 	mov	x0, x20
    8b8c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8b90:	d28000c2 	mov	x2, #0x6                   	// #6
    8b94:	91348021 	add	x1, x1, #0xd20
    8b98:	97ffe9fe 	bl	3390 <buf_put>
    8b9c:	d2800015 	mov	x21, #0x0                   	// #0
    8ba0:	f9400263 	ldr	x3, [x19]
    8ba4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8ba8:	54002c60 	b.eq	9134 <fwp_write+0x9e4>  // b.none
    8bac:	f9401f82 	ldr	x2, [x28, #56]
    8bb0:	f90143f7 	str	x23, [sp, #640]
    8bb4:	f90147f8 	str	x24, [sp, #648]
    8bb8:	d2800857 	mov	x23, #0x42                  	// #66
    8bbc:	f9014bf9 	str	x25, [sp, #656]
    8bc0:	b0000036 	adrp	x22, d000 <fwp_main_thread+0x47c>
    8bc4:	f9014ffa 	str	x26, [sp, #664]
    8bc8:	913462d6 	add	x22, x22, #0xd18
    8bcc:	d2800038 	mov	x24, #0x1                   	// #1
    8bd0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8bd4:	d2809099 	mov	x25, #0x484                 	// #1156
    8bd8:	b40004a2 	cbz	x2, 8c6c <fwp_write+0x51c>
    8bdc:	b9400040 	ldr	w0, [x2]
    8be0:	7100701f 	cmp	w0, #0x1c
    8be4:	540042c0 	b.eq	943c <fwp_write+0xcec>  // b.none
    8be8:	71006c1f 	cmp	w0, #0x1b
    8bec:	54000408 	b.hi	8c6c <fwp_write+0x51c>  // b.pmore
    8bf0:	9ac02301 	lsl	x1, x24, x0
    8bf4:	ea17003f 	tst	x1, x23
    8bf8:	540036a1 	b.ne	92cc <fwp_write+0xb7c>  // b.any
    8bfc:	ea19003f 	tst	x1, x25
    8c00:	54003521 	b.ne	92a4 <fwp_write+0xb54>  // b.any
    8c04:	d2800424 	mov	x4, #0x21                  	// #33
    8c08:	ea04003f 	tst	x1, x4
    8c0c:	54000300 	b.eq	8c6c <fwp_write+0x51c>  // b.none
    8c10:	b7f849c3 	tbnz	x3, #63, 9548 <fwp_write+0xdf8>
    8c14:	91002261 	add	x1, x19, #0x8
    8c18:	8b150021 	add	x1, x1, x21
    8c1c:	39400021 	ldrb	w1, [x1]
    8c20:	7100001f 	cmp	w0, #0x0
    8c24:	93401c23 	sxtb	x3, w1
    8c28:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8c2c:	d503201f 	nop
    8c30:	aa1403e0 	mov	x0, x20
    8c34:	52800003 	mov	w3, #0x0                   	// #0
    8c38:	97fffec6 	bl	8750 <fwp_write>
    8c3c:	910006b5 	add	x21, x21, #0x1
    8c40:	f9400260 	ldr	x0, [x19]
    8c44:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8c48:	eb0002bf 	cmp	x21, x0
    8c4c:	540026c2 	b.cs	9124 <fwp_write+0x9d4>  // b.hs, b.nlast
    8c50:	d2800042 	mov	x2, #0x2                   	// #2
    8c54:	aa1603e1 	mov	x1, x22
    8c58:	aa1403e0 	mov	x0, x20
    8c5c:	97ffe9cd 	bl	3390 <buf_put>
    8c60:	f9401f82 	ldr	x2, [x28, #56]
    8c64:	f9400263 	ldr	x3, [x19]
    8c68:	b5fffba2 	cbnz	x2, 8bdc <fwp_write+0x48c>
    8c6c:	d37df2a0 	lsl	x0, x21, #3
    8c70:	b7f83f03 	tbnz	x3, #63, 9450 <fwp_write+0xd00>
    8c74:	91002261 	add	x1, x19, #0x8
    8c78:	8b000020 	add	x0, x1, x0
    8c7c:	f9400001 	ldr	x1, [x0]
    8c80:	17ffffec 	b	8c30 <fwp_write+0x4e0>
    8c84:	a9400e62 	ldp	x2, x3, [x19]
    8c88:	b7f83ca3 	tbnz	x3, #63, 941c <fwp_write+0xccc>
    8c8c:	910123f5 	add	x21, sp, #0x48
    8c90:	aa1503e0 	mov	x0, x21
    8c94:	97ffe843 	bl	2da0 <fwp_fmt_u128>
    8c98:	aa1503e0 	mov	x0, x21
    8c9c:	97ffe679 	bl	2680 <strlen@plt>
    8ca0:	aa1503e1 	mov	x1, x21
    8ca4:	aa0003e2 	mov	x2, x0
    8ca8:	17fffed0 	b	87e8 <fwp_write+0x98>
    8cac:	fd015be8 	str	d8, [sp, #688]
    8cb0:	1e270268 	fmov	s8, w19
    8cb4:	fd015fe9 	str	d9, [sp, #696]
    8cb8:	1e282100 	fcmp	s8, s8
    8cbc:	54004d26 	b.vs	9660 <fwp_write+0xf10>
    8cc0:	1e20c101 	fabs	s1, s8
    8cc4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8cc8:	1e270000 	fmov	s0, w0
    8ccc:	1e202020 	fcmp	s1, s0
    8cd0:	54002c0d 	b.le	9250 <fwp_write+0xb00>
    8cd4:	1e202118 	fcmpe	s8, #0.0
    8cd8:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x47c>
    8cdc:	911f8042 	add	x2, x2, #0x7e0
    8ce0:	910123f5 	add	x21, sp, #0x48
    8ce4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8ce8:	9131c021 	add	x1, x1, #0xc70
    8cec:	aa1503e0 	mov	x0, x21
    8cf0:	9a81c041 	csel	x1, x2, x1, gt
    8cf4:	97ffe70f 	bl	2930 <strcpy@plt>
    8cf8:	aa1503e0 	mov	x0, x21
    8cfc:	97ffe661 	bl	2680 <strlen@plt>
    8d00:	aa1503e1 	mov	x1, x21
    8d04:	aa0003e2 	mov	x2, x0
    8d08:	aa1403e0 	mov	x0, x20
    8d0c:	97ffe9a1 	bl	3390 <buf_put>
    8d10:	f9413bf5 	ldr	x21, [sp, #624]
    8d14:	f9413ff6 	ldr	x22, [sp, #632]
    8d18:	f94153fb 	ldr	x27, [sp, #672]
    8d1c:	f94157fc 	ldr	x28, [sp, #680]
    8d20:	fd415be8 	ldr	d8, [sp, #688]
    8d24:	fd415fe9 	ldr	d9, [sp, #696]
    8d28:	17fffeb6 	b	8800 <fwp_write+0xb0>
    8d2c:	f9400276 	ldr	x22, [x19]
    8d30:	34002e03 	cbz	w3, 92f0 <fwp_write+0xba0>
    8d34:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8d38:	f947f400 	ldr	x0, [x0, #4072]
    8d3c:	f94127e2 	ldr	x2, [sp, #584]
    8d40:	f9400001 	ldr	x1, [x0]
    8d44:	eb010042 	subs	x2, x2, x1
    8d48:	d2800001 	mov	x1, #0x0                   	// #0
    8d4c:	540014a1 	b.ne	8fe0 <fwp_write+0x890>  // b.any
    8d50:	aa1603e2 	mov	x2, x22
    8d54:	91002261 	add	x1, x19, #0x8
    8d58:	f9413bf5 	ldr	x21, [sp, #624]
    8d5c:	aa1403e0 	mov	x0, x20
    8d60:	f9413ff6 	ldr	x22, [sp, #632]
    8d64:	17fffeff 	b	8960 <fwp_write+0x210>
    8d68:	fd015be8 	str	d8, [sp, #688]
    8d6c:	9e670268 	fmov	d8, x19
    8d70:	fd015fe9 	str	d9, [sp, #696]
    8d74:	1e682100 	fcmp	d8, d8
    8d78:	54004746 	b.vs	9660 <fwp_write+0xf10>
    8d7c:	1e60c101 	fabs	d1, d8
    8d80:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8d84:	9e670000 	fmov	d0, x0
    8d88:	910123f5 	add	x21, sp, #0x48
    8d8c:	52800033 	mov	w19, #0x1                   	// #1
    8d90:	1e602020 	fcmp	d1, d0
    8d94:	540001ad 	b.le	8dc8 <fwp_write+0x678>
    8d98:	1e602118 	fcmpe	d8, #0.0
    8d9c:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x47c>
    8da0:	911f8042 	add	x2, x2, #0x7e0
    8da4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8da8:	9131c021 	add	x1, x1, #0xc70
    8dac:	aa1503e0 	mov	x0, x21
    8db0:	9a81c041 	csel	x1, x2, x1, gt
    8db4:	97ffe6df 	bl	2930 <strcpy@plt>
    8db8:	17ffffd0 	b	8cf8 <fwp_write+0x5a8>
    8dbc:	11000673 	add	w19, w19, #0x1
    8dc0:	71004a7f 	cmp	w19, #0x12
    8dc4:	54003860 	b.eq	94d0 <fwp_write+0xd80>  // b.none
    8dc8:	1e604100 	fmov	d0, d8
    8dcc:	2a1303e1 	mov	w1, w19
    8dd0:	aa1503e0 	mov	x0, x21
    8dd4:	97ffe9cb 	bl	3500 <fwp_format_g.constprop.0>
    8dd8:	aa1503e0 	mov	x0, x21
    8ddc:	d2800001 	mov	x1, #0x0                   	// #0
    8de0:	97ffe63c 	bl	26d0 <strtod@plt>
    8de4:	1e602100 	fcmp	d8, d0
    8de8:	54fffea1 	b.ne	8dbc <fwp_write+0x66c>  // b.any
    8dec:	aa1503e0 	mov	x0, x21
    8df0:	97ffe9a1 	bl	3474 <fwp_finish_float>
    8df4:	17ffffc1 	b	8cf8 <fwp_write+0x5a8>
    8df8:	a9400e62 	ldp	x2, x3, [x19]
    8dfc:	910123f3 	add	x19, sp, #0x48
    8e00:	aa1303e0 	mov	x0, x19
    8e04:	97ffe7e7 	bl	2da0 <fwp_fmt_u128>
    8e08:	17fffe74 	b	87d8 <fwp_write+0x88>
    8e0c:	f90143f7 	str	x23, [sp, #640]
    8e10:	f90147f8 	str	x24, [sp, #648]
    8e14:	2a1303f8 	mov	w24, w19
    8e18:	f9014bf9 	str	x25, [sp, #656]
    8e1c:	f9014ffa 	str	x26, [sp, #664]
    8e20:	f13ffe7f 	cmp	x19, #0xfff
    8e24:	54000049 	b.ls	8e2c <fwp_write+0x6dc>  // b.plast
    8e28:	b9400278 	ldr	w24, [x19]
    8e2c:	f9400f80 	ldr	x0, [x28, #24]
    8e30:	2a1803f5 	mov	w21, w24
    8e34:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8e38:	d37ef6b9 	lsl	x25, x21, #2
    8e3c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8e40:	aa1603e0 	mov	x0, x22
    8e44:	97ffe60f 	bl	2680 <strlen@plt>
    8e48:	aa1603e1 	mov	x1, x22
    8e4c:	aa0003e2 	mov	x2, x0
    8e50:	aa1403e0 	mov	x0, x20
    8e54:	97ffe94f 	bl	3390 <buf_put>
    8e58:	f9401780 	ldr	x0, [x28, #40]
    8e5c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8e60:	7100001f 	cmp	w0, #0x0
    8e64:	5400068d 	b.le	8f34 <fwp_write+0x7e4>
    8e68:	91002276 	add	x22, x19, #0x8
    8e6c:	91001ff5 	add	x21, sp, #0x7
    8e70:	d280001b 	mov	x27, #0x0                   	// #0
    8e74:	5280041a 	mov	w26, #0x20                  	// #32
    8e78:	f9401b80 	ldr	x0, [x28, #48]
    8e7c:	aa1503e1 	mov	x1, x21
    8e80:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8e84:	d2800022 	mov	x2, #0x1                   	// #1
    8e88:	f8786803 	ldr	x3, [x0, x24]
    8e8c:	aa1403e0 	mov	x0, x20
    8e90:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8e94:	39001ffa 	strb	w26, [sp, #7]
    8e98:	97ffe93e 	bl	3390 <buf_put>
    8e9c:	f13ffeff 	cmp	x23, #0xfff
    8ea0:	b9400261 	ldr	w1, [x19]
    8ea4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8ea8:	7100383f 	cmp	w1, #0xe
    8eac:	54000160 	b.eq	8ed8 <fwp_write+0x788>  // b.none
    8eb0:	7100403f 	cmp	w1, #0x10
    8eb4:	54001a60 	b.eq	9200 <fwp_write+0xab0>  // b.none
    8eb8:	7100283f 	cmp	w1, #0xa
    8ebc:	54002aa0 	b.eq	9410 <fwp_write+0xcc0>  // b.none
    8ec0:	540014ac 	b.gt	9154 <fwp_write+0xa04>
    8ec4:	71000c3f 	cmp	w1, #0x3
    8ec8:	540029ac 	b.gt	93fc <fwp_write+0xcac>
    8ecc:	d37ffee0 	lsr	x0, x23, #63
    8ed0:	37f814a1 	tbnz	w1, #31, 9164 <fwp_write+0xa14>
    8ed4:	d503201f 	nop
    8ed8:	34001460 	cbz	w0, 9164 <fwp_write+0xa14>
    8edc:	52800503 	mov	w3, #0x28                  	// #40
    8ee0:	aa1503e1 	mov	x1, x21
    8ee4:	aa1403e0 	mov	x0, x20
    8ee8:	d2800022 	mov	x2, #0x1                   	// #1
    8eec:	39001fe3 	strb	w3, [sp, #7]
    8ef0:	97ffe928 	bl	3390 <buf_put>
    8ef4:	aa1303e2 	mov	x2, x19
    8ef8:	aa1703e1 	mov	x1, x23
    8efc:	aa1403e0 	mov	x0, x20
    8f00:	52800003 	mov	w3, #0x0                   	// #0
    8f04:	97fffe13 	bl	8750 <fwp_write>
    8f08:	52800523 	mov	w3, #0x29                  	// #41
    8f0c:	aa1503e1 	mov	x1, x21
    8f10:	aa1403e0 	mov	x0, x20
    8f14:	d2800022 	mov	x2, #0x1                   	// #1
    8f18:	39001fe3 	strb	w3, [sp, #7]
    8f1c:	97ffe91d 	bl	3390 <buf_put>
    8f20:	f9401780 	ldr	x0, [x28, #40]
    8f24:	9100077b 	add	x27, x27, #0x1
    8f28:	b8796800 	ldr	w0, [x0, x25]
    8f2c:	6b1b001f 	cmp	w0, w27
    8f30:	54fffa4c 	b.gt	8e78 <fwp_write+0x728>
    8f34:	f9413bf5 	ldr	x21, [sp, #624]
    8f38:	f9413ff6 	ldr	x22, [sp, #632]
    8f3c:	f94143f7 	ldr	x23, [sp, #640]
    8f40:	f94147f8 	ldr	x24, [sp, #648]
    8f44:	f9414bf9 	ldr	x25, [sp, #656]
    8f48:	f9414ffa 	ldr	x26, [sp, #664]
    8f4c:	f94153fb 	ldr	x27, [sp, #672]
    8f50:	f94157fc 	ldr	x28, [sp, #680]
    8f54:	17fffe2b 	b	8800 <fwp_write+0xb0>
    8f58:	52800783 	mov	w3, #0x3c                  	// #60
    8f5c:	91001ff3 	add	x19, sp, #0x7
    8f60:	aa1303e1 	mov	x1, x19
    8f64:	d2800022 	mov	x2, #0x1                   	// #1
    8f68:	aa1403e0 	mov	x0, x20
    8f6c:	39001fe3 	strb	w3, [sp, #7]
    8f70:	97ffe908 	bl	3390 <buf_put>
    8f74:	f9400795 	ldr	x21, [x28, #8]
    8f78:	aa1503e0 	mov	x0, x21
    8f7c:	97ffe5c1 	bl	2680 <strlen@plt>
    8f80:	aa1503e1 	mov	x1, x21
    8f84:	aa0003e2 	mov	x2, x0
    8f88:	aa1403e0 	mov	x0, x20
    8f8c:	97ffe901 	bl	3390 <buf_put>
    8f90:	528007c3 	mov	w3, #0x3e                  	// #62
    8f94:	aa1303e1 	mov	x1, x19
    8f98:	aa1403e0 	mov	x0, x20
    8f9c:	d2800022 	mov	x2, #0x1                   	// #1
    8fa0:	39001fe3 	strb	w3, [sp, #7]
    8fa4:	17fffe12 	b	87ec <fwp_write+0x9c>
    8fa8:	f100067f 	cmp	x19, #0x1
    8fac:	540025a0 	b.eq	9460 <fwp_write+0xd10>  // b.none
    8fb0:	b100067f 	cmn	x19, #0x1
    8fb4:	54002bc0 	b.eq	952c <fwp_write+0xddc>  // b.none
    8fb8:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    8fbc:	9131e021 	add	x1, x1, #0xc78
    8fc0:	d2800022 	mov	x2, #0x1                   	// #1
    8fc4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8fc8:	f947f400 	ldr	x0, [x0, #4072]
    8fcc:	f94127e4 	ldr	x4, [sp, #584]
    8fd0:	f9400003 	ldr	x3, [x0]
    8fd4:	eb030084 	subs	x4, x4, x3
    8fd8:	d2800003 	mov	x3, #0x0                   	// #0
    8fdc:	54ffebe0 	b.eq	8d58 <fwp_write+0x608>  // b.none
    8fe0:	f90143f7 	str	x23, [sp, #640]
    8fe4:	f90147f8 	str	x24, [sp, #648]
    8fe8:	f9014bf9 	str	x25, [sp, #656]
    8fec:	f9014ffa 	str	x26, [sp, #664]
    8ff0:	fd015be8 	str	d8, [sp, #688]
    8ff4:	fd015fe9 	str	d9, [sp, #696]
    8ff8:	97ffe5fe 	bl	27f0 <__stack_chk_fail@plt>
    8ffc:	52800b63 	mov	w3, #0x5b                  	// #91
    9000:	91001ff5 	add	x21, sp, #0x7
    9004:	aa1503e1 	mov	x1, x21
    9008:	aa1403e0 	mov	x0, x20
    900c:	d2800022 	mov	x2, #0x1                   	// #1
    9010:	90000036 	adrp	x22, d000 <fwp_main_thread+0x47c>
    9014:	913462d6 	add	x22, x22, #0xd18
    9018:	39001fe3 	strb	w3, [sp, #7]
    901c:	97ffe8dd 	bl	3390 <buf_put>
    9020:	b4000273 	cbz	x19, 906c <fwp_write+0x91c>
    9024:	f9400661 	ldr	x1, [x19, #8]
    9028:	aa1403e0 	mov	x0, x20
    902c:	f9401f82 	ldr	x2, [x28, #56]
    9030:	52800003 	mov	w3, #0x0                   	// #0
    9034:	97fffdc7 	bl	8750 <fwp_write>
    9038:	f9400a73 	ldr	x19, [x19, #16]
    903c:	b4000193 	cbz	x19, 906c <fwp_write+0x91c>
    9040:	aa1603e1 	mov	x1, x22
    9044:	aa1403e0 	mov	x0, x20
    9048:	d2800042 	mov	x2, #0x2                   	// #2
    904c:	97ffe8d1 	bl	3390 <buf_put>
    9050:	f9400661 	ldr	x1, [x19, #8]
    9054:	aa1403e0 	mov	x0, x20
    9058:	f9401f82 	ldr	x2, [x28, #56]
    905c:	52800003 	mov	w3, #0x0                   	// #0
    9060:	97fffdbc 	bl	8750 <fwp_write>
    9064:	f9400a73 	ldr	x19, [x19, #16]
    9068:	b5fffed3 	cbnz	x19, 9040 <fwp_write+0x8f0>
    906c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9070:	aa1503e1 	mov	x1, x21
    9074:	aa1403e0 	mov	x0, x20
    9078:	d2800022 	mov	x2, #0x1                   	// #1
    907c:	39001fe3 	strb	w3, [sp, #7]
    9080:	17fffddb 	b	87ec <fwp_write+0x9c>
    9084:	aa1403e0 	mov	x0, x20
    9088:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    908c:	d28000c2 	mov	x2, #0x6                   	// #6
    9090:	91342021 	add	x1, x1, #0xd08
    9094:	97ffe8bf 	bl	3390 <buf_put>
    9098:	f9400260 	ldr	x0, [x19]
    909c:	b40004c0 	cbz	x0, 9134 <fwp_write+0x9e4>
    90a0:	910123f5 	add	x21, sp, #0x48
    90a4:	91002276 	add	x22, x19, #0x8
    90a8:	f90143f7 	str	x23, [sp, #640]
    90ac:	d2800017 	mov	x23, #0x0                   	// #0
    90b0:	f90147f8 	str	x24, [sp, #648]
    90b4:	90000038 	adrp	x24, d000 <fwp_main_thread+0x47c>
    90b8:	91344318 	add	x24, x24, #0xd10
    90bc:	f9014bf9 	str	x25, [sp, #656]
    90c0:	90000039 	adrp	x25, d000 <fwp_main_thread+0x47c>
    90c4:	91346339 	add	x25, x25, #0xd18
    90c8:	f9014ffa 	str	x26, [sp, #664]
    90cc:	14000005 	b	90e0 <fwp_write+0x990>
    90d0:	aa1903e1 	mov	x1, x25
    90d4:	aa1403e0 	mov	x0, x20
    90d8:	d2800042 	mov	x2, #0x2                   	// #2
    90dc:	97ffe8ad 	bl	3390 <buf_put>
    90e0:	38776ac5 	ldrb	w5, [x22, x23]
    90e4:	d2804003 	mov	x3, #0x200                 	// #512
    90e8:	aa1803e4 	mov	x4, x24
    90ec:	aa0303e1 	mov	x1, x3
    90f0:	52800042 	mov	w2, #0x2                   	// #2
    90f4:	aa1503e0 	mov	x0, x21
    90f8:	910006f7 	add	x23, x23, #0x1
    90fc:	97ffe599 	bl	2760 <__snprintf_chk@plt>
    9100:	aa1503e0 	mov	x0, x21
    9104:	97ffe55f 	bl	2680 <strlen@plt>
    9108:	aa1503e1 	mov	x1, x21
    910c:	aa0003e2 	mov	x2, x0
    9110:	aa1403e0 	mov	x0, x20
    9114:	97ffe89f 	bl	3390 <buf_put>
    9118:	f9400260 	ldr	x0, [x19]
    911c:	eb17001f 	cmp	x0, x23
    9120:	54fffd88 	b.hi	90d0 <fwp_write+0x980>  // b.pmore
    9124:	f94143f7 	ldr	x23, [sp, #640]
    9128:	f94147f8 	ldr	x24, [sp, #648]
    912c:	f9414bf9 	ldr	x25, [sp, #656]
    9130:	f9414ffa 	ldr	x26, [sp, #664]
    9134:	52800ba3 	mov	w3, #0x5d                  	// #93
    9138:	aa1403e0 	mov	x0, x20
    913c:	91001fe1 	add	x1, sp, #0x7
    9140:	d2800022 	mov	x2, #0x1                   	// #1
    9144:	39001fe3 	strb	w3, [sp, #7]
    9148:	17fffda9 	b	87ec <fwp_write+0x9c>
    914c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9150:	17fffe44 	b	8a60 <fwp_write+0x310>
    9154:	f10002ff 	cmp	x23, #0x0
    9158:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    915c:	71002c3f 	cmp	w1, #0xb
    9160:	54ffebc0 	b.eq	8ed8 <fwp_write+0x788>  // b.none
    9164:	aa1303e2 	mov	x2, x19
    9168:	aa1703e1 	mov	x1, x23
    916c:	aa1403e0 	mov	x0, x20
    9170:	52800003 	mov	w3, #0x0                   	// #0
    9174:	97fffd77 	bl	8750 <fwp_write>
    9178:	17ffff6a 	b	8f20 <fwp_write+0x7d0>
    917c:	aa1403e0 	mov	x0, x20
    9180:	91001fe1 	add	x1, sp, #0x7
    9184:	52800fa3 	mov	w3, #0x7d                  	// #125
    9188:	d2800022 	mov	x2, #0x1                   	// #1
    918c:	17fffe38 	b	8a6c <fwp_write+0x31c>
    9190:	a9400281 	ldp	x1, x0, [x20]
    9194:	91000800 	add	x0, x0, #0x2
    9198:	8b160000 	add	x0, x0, x22
    919c:	f9000680 	str	x0, [x20, #8]
    91a0:	3820683f 	strb	wzr, [x1, x0]
    91a4:	f9413bf5 	ldr	x21, [sp, #624]
    91a8:	f9413ff6 	ldr	x22, [sp, #632]
    91ac:	f94153fb 	ldr	x27, [sp, #672]
    91b0:	f94157fc 	ldr	x28, [sp, #680]
    91b4:	17fffd93 	b	8800 <fwp_write+0xb0>
    91b8:	f9400f80 	ldr	x0, [x28, #24]
    91bc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    91c0:	aa1b03e0 	mov	x0, x27
    91c4:	97ffe52f 	bl	2680 <strlen@plt>
    91c8:	aa1b03e1 	mov	x1, x27
    91cc:	aa0003e2 	mov	x2, x0
    91d0:	aa1403e0 	mov	x0, x20
    91d4:	97ffe86f 	bl	3390 <buf_put>
    91d8:	aa1903e1 	mov	x1, x25
    91dc:	aa1403e0 	mov	x0, x20
    91e0:	d2800062 	mov	x2, #0x3                   	// #3
    91e4:	97ffe86b 	bl	3390 <buf_put>
    91e8:	17fffe10 	b	8a28 <fwp_write+0x2d8>
    91ec:	aa1a03e1 	mov	x1, x26
    91f0:	aa1403e0 	mov	x0, x20
    91f4:	d2800042 	mov	x2, #0x2                   	// #2
    91f8:	97ffe866 	bl	3390 <buf_put>
    91fc:	17fffe09 	b	8a20 <fwp_write+0x2d0>
    9200:	f9400660 	ldr	x0, [x19, #8]
    9204:	b4fffb00 	cbz	x0, 9164 <fwp_write+0xa14>
    9208:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    920c:	9134c021 	add	x1, x1, #0xd30
    9210:	97ffe598 	bl	2870 <strcmp@plt>
    9214:	7100001f 	cmp	w0, #0x0
    9218:	1a9f07e0 	cset	w0, ne	// ne = any
    921c:	17ffff2f 	b	8ed8 <fwp_write+0x788>
    9220:	aa1403e0 	mov	x0, x20
    9224:	d2800042 	mov	x2, #0x2                   	// #2
    9228:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    922c:	9134a021 	add	x1, x1, #0xd28
    9230:	97ffe858 	bl	3390 <buf_put>
    9234:	91004261 	add	x1, x19, #0x10
    9238:	aa1403e0 	mov	x0, x20
    923c:	f9402382 	ldr	x2, [x28, #64]
    9240:	52800003 	mov	w3, #0x0                   	// #0
    9244:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9248:	97fffd42 	bl	8750 <fwp_write>
    924c:	17fffd9c 	b	88bc <fwp_write+0x16c>
    9250:	1e22c109 	fcvt	d9, s8
    9254:	910123f5 	add	x21, sp, #0x48
    9258:	52800033 	mov	w19, #0x1                   	// #1
    925c:	d503201f 	nop
    9260:	1e604120 	fmov	d0, d9
    9264:	2a1303e1 	mov	w1, w19
    9268:	aa1503e0 	mov	x0, x21
    926c:	97ffe8a5 	bl	3500 <fwp_format_g.constprop.0>
    9270:	aa1503e0 	mov	x0, x21
    9274:	d2800001 	mov	x1, #0x0                   	// #0
    9278:	97ffe58a 	bl	28a0 <strtof@plt>
    927c:	1e202100 	fcmp	s8, s0
    9280:	54ffdb60 	b.eq	8dec <fwp_write+0x69c>  // b.none
    9284:	11000673 	add	w19, w19, #0x1
    9288:	71002a7f 	cmp	w19, #0xa
    928c:	54fffea1 	b.ne	9260 <fwp_write+0xb10>  // b.any
    9290:	1e604120 	fmov	d0, d9
    9294:	aa1503e0 	mov	x0, x21
    9298:	52800121 	mov	w1, #0x9                   	// #9
    929c:	97ffe899 	bl	3500 <fwp_format_g.constprop.0>
    92a0:	17fffed3 	b	8dec <fwp_write+0x69c>
    92a4:	d37ef6a1 	lsl	x1, x21, #2
    92a8:	b7f81563 	tbnz	x3, #63, 9554 <fwp_write+0xe04>
    92ac:	91002263 	add	x3, x19, #0x8
    92b0:	8b010061 	add	x1, x3, x1
    92b4:	b9400023 	ldr	w3, [x1]
    92b8:	7100081f 	cmp	w0, #0x2
    92bc:	2a0303e1 	mov	w1, w3
    92c0:	93407c63 	sxtw	x3, w3
    92c4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    92c8:	17fffe5a 	b	8c30 <fwp_write+0x4e0>
    92cc:	d37ffaa1 	lsl	x1, x21, #1
    92d0:	b7f81363 	tbnz	x3, #63, 953c <fwp_write+0xdec>
    92d4:	91002263 	add	x3, x19, #0x8
    92d8:	8b010061 	add	x1, x3, x1
    92dc:	79400021 	ldrh	w1, [x1]
    92e0:	7100041f 	cmp	w0, #0x1
    92e4:	93403c23 	sxth	x3, w1
    92e8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    92ec:	17fffe51 	b	8c30 <fwp_write+0x4e0>
    92f0:	52800443 	mov	w3, #0x22                  	// #34
    92f4:	91001ff5 	add	x21, sp, #0x7
    92f8:	91002273 	add	x19, x19, #0x8
    92fc:	aa1503e1 	mov	x1, x21
    9300:	aa1403e0 	mov	x0, x20
    9304:	d2800022 	mov	x2, #0x1                   	// #1
    9308:	39001fe3 	strb	w3, [sp, #7]
    930c:	f90143f7 	str	x23, [sp, #640]
    9310:	8b160277 	add	x23, x19, x22
    9314:	f90147f8 	str	x24, [sp, #648]
    9318:	97ffe81e 	bl	3390 <buf_put>
    931c:	b4000696 	cbz	x22, 93ec <fwp_write+0xc9c>
    9320:	90000038 	adrp	x24, d000 <fwp_main_thread+0x47c>
    9324:	91336318 	add	x24, x24, #0xcd8
    9328:	f9014bf9 	str	x25, [sp, #656]
    932c:	90000039 	adrp	x25, d000 <fwp_main_thread+0x47c>
    9330:	9133e339 	add	x25, x25, #0xcf8
    9334:	f9014ffa 	str	x26, [sp, #664]
    9338:	1400000d 	b	936c <fwp_write+0xc1c>
    933c:	710024bf 	cmp	w5, #0x9
    9340:	54000460 	b.eq	93cc <fwp_write+0xc7c>  // b.none
    9344:	710028bf 	cmp	w5, #0xa
    9348:	54000a61 	b.ne	9494 <fwp_write+0xd44>  // b.any
    934c:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    9350:	aa1403e0 	mov	x0, x20
    9354:	9133a021 	add	x1, x1, #0xce8
    9358:	d2800042 	mov	x2, #0x2                   	// #2
    935c:	97ffe80d 	bl	3390 <buf_put>
    9360:	91000673 	add	x19, x19, #0x1
    9364:	eb17027f 	cmp	x19, x23
    9368:	540003e0 	b.eq	93e4 <fwp_write+0xc94>  // b.none
    936c:	39400265 	ldrb	w5, [x19]
    9370:	710034bf 	cmp	w5, #0xd
    9374:	54000180 	b.eq	93a4 <fwp_write+0xc54>  // b.none
    9378:	54fffe29 	b.ls	933c <fwp_write+0xbec>  // b.plast
    937c:	710088bf 	cmp	w5, #0x22
    9380:	540001c0 	b.eq	93b8 <fwp_write+0xc68>  // b.none
    9384:	710170bf 	cmp	w5, #0x5c
    9388:	54000741 	b.ne	9470 <fwp_write+0xd20>  // b.any
    938c:	aa1403e0 	mov	x0, x20
    9390:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    9394:	d2800042 	mov	x2, #0x2                   	// #2
    9398:	91338021 	add	x1, x1, #0xce0
    939c:	97ffe7fd 	bl	3390 <buf_put>
    93a0:	17fffff0 	b	9360 <fwp_write+0xc10>
    93a4:	aa1903e1 	mov	x1, x25
    93a8:	aa1403e0 	mov	x0, x20
    93ac:	d2800042 	mov	x2, #0x2                   	// #2
    93b0:	97ffe7f8 	bl	3390 <buf_put>
    93b4:	17ffffeb 	b	9360 <fwp_write+0xc10>
    93b8:	aa1803e1 	mov	x1, x24
    93bc:	aa1403e0 	mov	x0, x20
    93c0:	d2800042 	mov	x2, #0x2                   	// #2
    93c4:	97ffe7f3 	bl	3390 <buf_put>
    93c8:	17ffffe6 	b	9360 <fwp_write+0xc10>
    93cc:	aa1403e0 	mov	x0, x20
    93d0:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    93d4:	d2800042 	mov	x2, #0x2                   	// #2
    93d8:	9133c021 	add	x1, x1, #0xcf0
    93dc:	97ffe7ed 	bl	3390 <buf_put>
    93e0:	17ffffe0 	b	9360 <fwp_write+0xc10>
    93e4:	f9414bf9 	ldr	x25, [sp, #656]
    93e8:	f9414ffa 	ldr	x26, [sp, #664]
    93ec:	aa1503e1 	mov	x1, x21
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	52800443 	mov	w3, #0x22                  	// #34
    93f8:	17fffd9c 	b	8a68 <fwp_write+0x318>
    93fc:	7100103f 	cmp	w1, #0x4
    9400:	54ffeb21 	b.ne	9164 <fwp_write+0xa14>  // b.any
    9404:	f94006e0 	ldr	x0, [x23, #8]
    9408:	d37ffc00 	lsr	x0, x0, #63
    940c:	17fffeb3 	b	8ed8 <fwp_write+0x788>
    9410:	710002ff 	cmp	w23, #0x0
    9414:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9418:	17fffeb0 	b	8ed8 <fwp_write+0x788>
    941c:	528005a1 	mov	w1, #0x2d                  	// #45
    9420:	eb0203e2 	negs	x2, x2
    9424:	da0303e3 	ngc	x3, x3
    9428:	910127e0 	add	x0, sp, #0x49
    942c:	910123f5 	add	x21, sp, #0x48
    9430:	390123e1 	strb	w1, [sp, #72]
    9434:	97ffe65b 	bl	2da0 <fwp_fmt_u128>
    9438:	17fffe18 	b	8c98 <fwp_write+0x548>
    943c:	d37ceea1 	lsl	x1, x21, #4
    9440:	b7f810a3 	tbnz	x3, #63, 9654 <fwp_write+0xf04>
    9444:	91002260 	add	x0, x19, #0x8
    9448:	8b010001 	add	x1, x0, x1
    944c:	17fffdf9 	b	8c30 <fwp_write+0x4e0>
    9450:	f9400a61 	ldr	x1, [x19, #16]
    9454:	8b010000 	add	x0, x0, x1
    9458:	f9400001 	ldr	x1, [x0]
    945c:	17fffdf5 	b	8c30 <fwp_write+0x4e0>
    9460:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    9464:	d2800042 	mov	x2, #0x2                   	// #2
    9468:	91320021 	add	x1, x1, #0xc80
    946c:	17fffed6 	b	8fc4 <fwp_write+0x874>
    9470:	7101fcbf 	cmp	w5, #0x7f
    9474:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9478:	540000e9 	b.ls	9494 <fwp_write+0xd44>  // b.plast
    947c:	aa1503e1 	mov	x1, x21
    9480:	aa1403e0 	mov	x0, x20
    9484:	d2800022 	mov	x2, #0x1                   	// #1
    9488:	39001fe5 	strb	w5, [sp, #7]
    948c:	97ffe7c1 	bl	3390 <buf_put>
    9490:	17ffffb4 	b	9360 <fwp_write+0xc10>
    9494:	d2800203 	mov	x3, #0x10                  	// #16
    9498:	90000024 	adrp	x4, d000 <fwp_main_thread+0x47c>
    949c:	aa0303e1 	mov	x1, x3
    94a0:	91340084 	add	x4, x4, #0xd00
    94a4:	910123f6 	add	x22, sp, #0x48
    94a8:	52800042 	mov	w2, #0x2                   	// #2
    94ac:	aa1603e0 	mov	x0, x22
    94b0:	97ffe4ac 	bl	2760 <__snprintf_chk@plt>
    94b4:	aa1603e0 	mov	x0, x22
    94b8:	97ffe472 	bl	2680 <strlen@plt>
    94bc:	aa1603e1 	mov	x1, x22
    94c0:	aa0003e2 	mov	x2, x0
    94c4:	aa1403e0 	mov	x0, x20
    94c8:	97ffe7b2 	bl	3390 <buf_put>
    94cc:	17ffffa5 	b	9360 <fwp_write+0xc10>
    94d0:	1e604100 	fmov	d0, d8
    94d4:	aa1503e0 	mov	x0, x21
    94d8:	52800221 	mov	w1, #0x11                  	// #17
    94dc:	97ffe809 	bl	3500 <fwp_format_g.constprop.0>
    94e0:	17fffe43 	b	8dec <fwp_write+0x69c>
    94e4:	b9401040 	ldr	w0, [x2, #16]
    94e8:	350003c0 	cbnz	w0, 9560 <fwp_write+0xe10>
    94ec:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    94f0:	f947f400 	ldr	x0, [x0, #4072]
    94f4:	f94127e2 	ldr	x2, [sp, #584]
    94f8:	f9400001 	ldr	x1, [x0]
    94fc:	eb010042 	subs	x2, x2, x1
    9500:	d2800001 	mov	x1, #0x0                   	// #0
    9504:	54ffd721 	b.ne	8fe8 <fwp_write+0x898>  // b.any
    9508:	f9413bf5 	ldr	x21, [sp, #624]
    950c:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    9510:	f9413ff6 	ldr	x22, [sp, #632]
    9514:	aa1403e0 	mov	x0, x20
    9518:	f94143f7 	ldr	x23, [sp, #640]
    951c:	91354021 	add	x1, x1, #0xd50
    9520:	f94147f8 	ldr	x24, [sp, #648]
    9524:	d2800042 	mov	x2, #0x2                   	// #2
    9528:	17fffd0e 	b	8960 <fwp_write+0x210>
    952c:	90000021 	adrp	x1, d000 <fwp_main_thread+0x47c>
    9530:	d2800042 	mov	x2, #0x2                   	// #2
    9534:	91322021 	add	x1, x1, #0xc88
    9538:	17fffea3 	b	8fc4 <fwp_write+0x874>
    953c:	f9400a63 	ldr	x3, [x19, #16]
    9540:	8b030021 	add	x1, x1, x3
    9544:	17ffff66 	b	92dc <fwp_write+0xb8c>
    9548:	f9400a61 	ldr	x1, [x19, #16]
    954c:	8b0102a1 	add	x1, x21, x1
    9550:	17fffdb3 	b	8c1c <fwp_write+0x4cc>
    9554:	f9400a63 	ldr	x3, [x19, #16]
    9558:	8b030021 	add	x1, x1, x3
    955c:	17ffff56 	b	92b4 <fwp_write+0xb64>
    9560:	b9404840 	ldr	w0, [x2, #72]
    9564:	91001ff5 	add	x21, sp, #0x7
    9568:	34ffa360 	cbz	w0, 89d4 <fwp_write+0x284>
    956c:	52800503 	mov	w3, #0x28                  	// #40
    9570:	aa1403e0 	mov	x0, x20
    9574:	aa1503e1 	mov	x1, x21
    9578:	d2800022 	mov	x2, #0x1                   	// #1
    957c:	39001fe3 	strb	w3, [sp, #7]
    9580:	97ffe784 	bl	3390 <buf_put>
    9584:	b9401380 	ldr	w0, [x28, #16]
    9588:	52800038 	mov	w24, #0x1                   	// #1
    958c:	7100001f 	cmp	w0, #0x0
    9590:	54ffa36c 	b.gt	89fc <fwp_write+0x2ac>
    9594:	17fffd32 	b	8a5c <fwp_write+0x30c>
    9598:	f9014bf9 	str	x25, [sp, #656]
    959c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe720>
    95a0:	f9014ffa 	str	x26, [sp, #664]
    95a4:	f9400676 	ldr	x22, [x19, #8]
    95a8:	91102333 	add	x19, x25, #0x408
    95ac:	91002273 	add	x19, x19, #0x8
    95b0:	937ffed8 	asr	x24, x22, #63
    95b4:	aa1802c0 	orr	x0, x22, x24
    95b8:	b5000320 	cbnz	x0, 961c <fwp_write+0xecc>
    95bc:	110006b5 	add	w21, w21, #0x1
    95c0:	710016bf 	cmp	w21, #0x5
    95c4:	54ffffc1 	b.ne	95bc <fwp_write+0xe6c>  // b.any
    95c8:	b7f80578 	tbnz	x24, #63, 9674 <fwp_write+0xf24>
    95cc:	910023f3 	add	x19, sp, #0x8
    95d0:	aa1603e2 	mov	x2, x22
    95d4:	aa1303e0 	mov	x0, x19
    95d8:	d2800003 	mov	x3, #0x0                   	// #0
    95dc:	97ffe5f1 	bl	2da0 <fwp_fmt_u128>
    95e0:	910123f5 	add	x21, sp, #0x48
    95e4:	90000023 	adrp	x3, d000 <fwp_main_thread+0x47c>
    95e8:	aa1303e4 	mov	x4, x19
    95ec:	aa1503e0 	mov	x0, x21
    95f0:	91352063 	add	x3, x3, #0xd48
    95f4:	d2804002 	mov	x2, #0x200                 	// #512
    95f8:	52800041 	mov	w1, #0x2                   	// #2
    95fc:	97ffe425 	bl	2690 <__sprintf_chk@plt>
    9600:	aa1503e0 	mov	x0, x21
    9604:	97ffe41f 	bl	2680 <strlen@plt>
    9608:	aa1503e1 	mov	x1, x21
    960c:	aa0003e2 	mov	x2, x0
    9610:	aa1403e0 	mov	x0, x20
    9614:	97ffe75f 	bl	3390 <buf_put>
    9618:	17fffe47 	b	8f34 <fwp_write+0x7e4>
    961c:	f9400277 	ldr	x23, [x19]
    9620:	aa1603e0 	mov	x0, x22
    9624:	aa1803e1 	mov	x1, x24
    9628:	aa1703e2 	mov	x2, x23
    962c:	937ffefa 	asr	x26, x23, #63
    9630:	aa1a03e3 	mov	x3, x26
    9634:	94000f7b 	bl	d420 <__modti3>
    9638:	aa010000 	orr	x0, x0, x1
    963c:	b40002c0 	cbz	x0, 9694 <fwp_write+0xf44>
    9640:	110006b5 	add	w21, w21, #0x1
    9644:	91004273 	add	x19, x19, #0x10
    9648:	710016bf 	cmp	w21, #0x5
    964c:	54fffe81 	b.ne	961c <fwp_write+0xecc>  // b.any
    9650:	17ffffde 	b	95c8 <fwp_write+0xe78>
    9654:	f9400a60 	ldr	x0, [x19, #16]
    9658:	8b000021 	add	x1, x1, x0
    965c:	17fffd75 	b	8c30 <fwp_write+0x4e0>
    9660:	528c29c0 	mov	w0, #0x614e                	// #24910
    9664:	910123f5 	add	x21, sp, #0x48
    9668:	72a009c0 	movk	w0, #0x4e, lsl #16
    966c:	b9004be0 	str	w0, [sp, #72]
    9670:	17fffda2 	b	8cf8 <fwp_write+0x5a8>
    9674:	528005a1 	mov	w1, #0x2d                  	// #45
    9678:	eb1603e2 	negs	x2, x22
    967c:	da1803e3 	ngc	x3, x24
    9680:	910027e0 	add	x0, sp, #0x9
    9684:	910023f3 	add	x19, sp, #0x8
    9688:	390023e1 	strb	w1, [sp, #8]
    968c:	97ffe5c5 	bl	2da0 <fwp_fmt_u128>
    9690:	17ffffd4 	b	95e0 <fwp_write+0xe90>
    9694:	aa1703e2 	mov	x2, x23
    9698:	aa1a03e3 	mov	x3, x26
    969c:	aa1603e0 	mov	x0, x22
    96a0:	aa1803e1 	mov	x1, x24
    96a4:	94000e7f 	bl	d0a0 <__divti3>
    96a8:	aa0003e2 	mov	x2, x0
    96ac:	aa0103e3 	mov	x3, x1
    96b0:	b7f80201 	tbnz	x1, #63, 96f0 <fwp_write+0xfa0>
    96b4:	910023f3 	add	x19, sp, #0x8
    96b8:	aa1303e0 	mov	x0, x19
    96bc:	97ffe5b9 	bl	2da0 <fwp_fmt_u128>
    96c0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    96c4:	91102339 	add	x25, x25, #0x408
    96c8:	910123f5 	add	x21, sp, #0x48
    96cc:	aa1303e4 	mov	x4, x19
    96d0:	aa1503e0 	mov	x0, x21
    96d4:	90000023 	adrp	x3, d000 <fwp_main_thread+0x47c>
    96d8:	f8616b25 	ldr	x5, [x25, x1]
    96dc:	91350063 	add	x3, x3, #0xd40
    96e0:	d2804002 	mov	x2, #0x200                 	// #512
    96e4:	52800041 	mov	w1, #0x2                   	// #2
    96e8:	97ffe3ea 	bl	2690 <__sprintf_chk@plt>
    96ec:	17ffffc5 	b	9600 <fwp_write+0xeb0>
    96f0:	528005a4 	mov	w4, #0x2d                  	// #45
    96f4:	eb0003e2 	negs	x2, x0
    96f8:	da0103e3 	ngc	x3, x1
    96fc:	910027e0 	add	x0, sp, #0x9
    9700:	910023f3 	add	x19, sp, #0x8
    9704:	390023e4 	strb	w4, [sp, #8]
    9708:	97ffe5a6 	bl	2da0 <fwp_fmt_u128>
    970c:	17ffffed 	b	96c0 <fwp_write+0xf70>
    9710:	f9013bf5 	str	x21, [sp, #624]
    9714:	f9013ff6 	str	x22, [sp, #632]
    9718:	f90143f7 	str	x23, [sp, #640]
    971c:	f90147f8 	str	x24, [sp, #648]
    9720:	f9014bf9 	str	x25, [sp, #656]
    9724:	f9014ffa 	str	x26, [sp, #664]
    9728:	f90153fb 	str	x27, [sp, #672]
    972c:	f90157fc 	str	x28, [sp, #680]
    9730:	fd015be8 	str	d8, [sp, #688]
    9734:	fd015fe9 	str	d9, [sp, #696]
    9738:	97ffe42e 	bl	27f0 <__stack_chk_fail@plt>
    973c:	d503201f 	nop

0000000000009740 <fwp_hof0.constprop.0>:
    9740:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9744:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9748:	f947f442 	ldr	x2, [x2, #4072]
    974c:	910003fd 	mov	x29, sp
    9750:	a90153f3 	stp	x19, x20, [sp, #16]
    9754:	a9025bf5 	stp	x21, x22, [sp, #32]
    9758:	a90363f7 	stp	x23, x24, [sp, #48]
    975c:	aa0003f7 	mov	x23, x0
    9760:	a9046bf9 	stp	x25, x26, [sp, #64]
    9764:	a90573fb 	stp	x27, x28, [sp, #80]
    9768:	d10203ff 	sub	sp, sp, #0x80
    976c:	f9400040 	ldr	x0, [x2]
    9770:	f81f83a0 	stur	x0, [x29, #-8]
    9774:	d2800000 	mov	x0, #0x0                   	// #0
    9778:	b40039a1 	cbz	x1, 9eac <fwp_hof0.constprop.0+0x76c>
    977c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9780:	9100401c 	add	x28, x0, #0x10
    9784:	aa1703fa 	mov	x26, x23
    9788:	f00000a0 	adrp	x0, 20000 <__data_start>
    978c:	9100239c 	add	x28, x28, #0x8
    9790:	d10083b4 	sub	x20, x29, #0x20
    9794:	91010015 	add	x21, x0, #0x40
    9798:	aa0103f7 	mov	x23, x1
    979c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    97a0:	91154001 	add	x1, x0, #0x550
    97a4:	f949d822 	ldr	x2, [x1, #5040]
    97a8:	f949ec20 	ldr	x0, [x1, #5080]
    97ac:	cb020342 	sub	x2, x26, x2
    97b0:	eb00405f 	cmp	x2, x0, lsl #16
    97b4:	54000342 	b.cs	981c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    97b8:	d350fc40 	lsr	x0, x2, #16
    97bc:	f949fc24 	ldr	x4, [x1, #5112]
    97c0:	8b000800 	add	x0, x0, x0, lsl #2
    97c4:	d37df001 	lsl	x1, x0, #3
    97c8:	8b010083 	add	x3, x4, x1
    97cc:	f9401060 	ldr	x0, [x3, #32]
    97d0:	b4000260 	cbz	x0, 981c <fwp_hof0.constprop.0+0xdc>
    97d4:	38616881 	ldrb	w1, [x4, x1]
    97d8:	7100083f 	cmp	w1, #0x2
    97dc:	540055c0 	b.eq	a294 <fwp_hof0.constprop.0+0xb54>  // b.none
    97e0:	7100043f 	cmp	w1, #0x1
    97e4:	540001c1 	b.ne	981c <fwp_hof0.constprop.0+0xdc>  // b.any
    97e8:	92403c41 	and	x1, x2, #0xffff
    97ec:	29430864 	ldp	w4, w2, [x3, #24]
    97f0:	9b047c21 	mul	x1, x1, x4
    97f4:	d360fc21 	lsr	x1, x1, #32
    97f8:	eb02003f 	cmp	x1, x2
    97fc:	54000102 	b.cs	981c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9800:	8b010000 	add	x0, x0, x1
    9804:	39400001 	ldrb	w1, [x0]
    9808:	340000a1 	cbz	w1, 981c <fwp_hof0.constprop.0+0xdc>
    980c:	7103f43f 	cmp	w1, #0xfd
    9810:	540056c8 	b.hi	a2e8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9814:	11000421 	add	w1, w1, #0x1
    9818:	39000001 	strb	w1, [x0]
    981c:	aa1a03f8 	mov	x24, x26
    9820:	aa1c03f9 	mov	x25, x28
    9824:	d28018f3 	mov	x19, #0xc7                  	// #199
    9828:	a9396bb7 	stp	x23, x26, [x29, #-112]
    982c:	f81a03b3 	stur	x19, [x29, #-96]
    9830:	f00000a0 	adrp	x0, 20000 <__data_start>
    9834:	91004000 	add	x0, x0, #0x10
    9838:	f9403ea3 	ldr	x3, [x21, #120]
    983c:	91002006 	add	x6, x0, #0x8
    9840:	b9400802 	ldr	w2, [x0, #8]
    9844:	d37be842 	lsl	x2, x2, #5
    9848:	8b020064 	add	x4, x3, x2
    984c:	f9400c81 	ldr	x1, [x4, #24]
    9850:	f81e03b8 	stur	x24, [x29, #-32]
    9854:	b40052e1 	cbz	x1, a2b0 <fwp_hof0.constprop.0+0xb70>
    9858:	f9400c20 	ldr	x0, [x1, #24]
    985c:	b40046a0 	cbz	x0, a130 <fwp_hof0.constprop.0+0x9f0>
    9860:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9864:	91154002 	add	x2, x0, #0x550
    9868:	f949d841 	ldr	x1, [x2, #5040]
    986c:	f949ec40 	ldr	x0, [x2, #5080]
    9870:	cb010321 	sub	x1, x25, x1
    9874:	eb00403f 	cmp	x1, x0, lsl #16
    9878:	54000342 	b.cs	98e0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    987c:	d350fc20 	lsr	x0, x1, #16
    9880:	f949fc45 	ldr	x5, [x2, #5112]
    9884:	8b000800 	add	x0, x0, x0, lsl #2
    9888:	d37df002 	lsl	x2, x0, #3
    988c:	8b0200a3 	add	x3, x5, x2
    9890:	f9401060 	ldr	x0, [x3, #32]
    9894:	b4000260 	cbz	x0, 98e0 <fwp_hof0.constprop.0+0x1a0>
    9898:	386268a2 	ldrb	w2, [x5, x2]
    989c:	7100085f 	cmp	w2, #0x2
    98a0:	54004b40 	b.eq	a208 <fwp_hof0.constprop.0+0xac8>  // b.none
    98a4:	7100045f 	cmp	w2, #0x1
    98a8:	540001c1 	b.ne	98e0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    98ac:	29430865 	ldp	w5, w2, [x3, #24]
    98b0:	92403c21 	and	x1, x1, #0xffff
    98b4:	9b057c21 	mul	x1, x1, x5
    98b8:	d360fc21 	lsr	x1, x1, #32
    98bc:	eb02003f 	cmp	x1, x2
    98c0:	54000102 	b.cs	98e0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    98c4:	8b010000 	add	x0, x0, x1
    98c8:	39400001 	ldrb	w1, [x0]
    98cc:	340000a1 	cbz	w1, 98e0 <fwp_hof0.constprop.0+0x1a0>
    98d0:	7103f43f 	cmp	w1, #0xfd
    98d4:	54004e68 	b.hi	a2a0 <fwp_hof0.constprop.0+0xb60>  // b.pmore
    98d8:	11000421 	add	w1, w1, #0x1
    98dc:	39000001 	strb	w1, [x0]
    98e0:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    98e4:	aa1903f8 	mov	x24, x25
    98e8:	aa1903e0 	mov	x0, x25
    98ec:	91154036 	add	x22, x1, #0x550
    98f0:	52800037 	mov	w23, #0x1                   	// #1
    98f4:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    98f8:	b81cc3b7 	stur	w23, [x29, #-52]
    98fc:	f81d03b4 	stur	x20, [x29, #-48]
    9900:	b9400401 	ldr	w1, [x0, #4]
    9904:	b9400099 	ldr	w25, [x4]
    9908:	b85cc3a0 	ldur	w0, [x29, #-52]
    990c:	4b010339 	sub	w25, w25, w1
    9910:	6b17033f 	cmp	w25, w23
    9914:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    9918:	6b0000df 	cmp	w6, w0
    991c:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    9920:	b81c83a0 	stur	w0, [x29, #-56]
    9924:	6b0000c2 	subs	w2, w6, w0
    9928:	54000120 	b.eq	994c <fwp_hof0.constprop.0+0x20c>  // b.none
    992c:	f9400c83 	ldr	x3, [x4, #24]
    9930:	0b000021 	add	w1, w1, w0
    9934:	f85d03a4 	ldur	x4, [x29, #-48]
    9938:	b81d83a6 	stur	w6, [x29, #-40]
    993c:	f9400863 	ldr	x3, [x3, #16]
    9940:	8b204c80 	add	x0, x4, w0, uxtw #3
    9944:	d63f0060 	blr	x3
    9948:	b85d83a6 	ldur	w6, [x29, #-40]
    994c:	f9403ea0 	ldr	x0, [x21, #120]
    9950:	aa1803e9 	mov	x9, x24
    9954:	b9400304 	ldr	w4, [x24]
    9958:	2a0603f4 	mov	w20, w6
    995c:	f85d03bb 	ldur	x27, [x29, #-48]
    9960:	aa1803fa 	mov	x26, x24
    9964:	8b041404 	add	x4, x0, x4, lsl #5
    9968:	f9400c8a 	ldr	x10, [x4, #24]
    996c:	b400106a 	cbz	x10, 9b78 <fwp_hof0.constprop.0+0x438>
    9970:	29371bb7 	stp	w23, w6, [x29, #-72]
    9974:	aa0403f7 	mov	x23, x4
    9978:	b81c03b9 	stur	w25, [x29, #-64]
    997c:	aa1b03f9 	mov	x25, x27
    9980:	14000012 	b	99c8 <fwp_hof0.constprop.0+0x288>
    9984:	f9400141 	ldr	x1, [x10]
    9988:	aa1903e0 	mov	x0, x25
    998c:	d63f0020 	blr	x1
    9990:	aa0003fb 	mov	x27, x0
    9994:	aa1803e0 	mov	x0, x24
    9998:	97fff1be 	bl	6090 <fwp_closure_drop>
    999c:	6b14027f 	cmp	w19, w20
    99a0:	54000cc0 	b.eq	9b38 <fwp_hof0.constprop.0+0x3f8>  // b.none
    99a4:	f9403ea0 	ldr	x0, [x21, #120]
    99a8:	8b334f39 	add	x25, x25, w19, uxtw #3
    99ac:	b9400364 	ldr	w4, [x27]
    99b0:	4b1a0394 	sub	w20, w28, w26
    99b4:	aa1b03e9 	mov	x9, x27
    99b8:	8b041417 	add	x23, x0, x4, lsl #5
    99bc:	f9400eea 	ldr	x10, [x23, #24]
    99c0:	b4000d4a 	cbz	x10, 9b68 <fwp_hof0.constprop.0+0x428>
    99c4:	aa1b03f8 	mov	x24, x27
    99c8:	b9400521 	ldr	w1, [x9, #4]
    99cc:	b94002fa 	ldr	w26, [x23]
    99d0:	0b14003c 	add	w28, w1, w20
    99d4:	6b1c035f 	cmp	w26, w28
    99d8:	540028a8 	b.hi	9eec <fwp_hof0.constprop.0+0x7ac>  // b.pmore
    99dc:	7100003f 	cmp	w1, #0x0
    99e0:	4b010353 	sub	w19, w26, w1
    99e4:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    99e8:	54fffce1 	b.ne	9984 <fwp_hof0.constprop.0+0x244>  // b.any
    99ec:	910003e0 	mov	x0, sp
    99f0:	7100035f 	cmp	w26, #0x0
    99f4:	f81d83a0 	stur	x0, [x29, #-40]
    99f8:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    99fc:	d37df000 	lsl	x0, x0, #3
    9a00:	91003c00 	add	x0, x0, #0xf
    9a04:	92704c05 	and	x5, x0, #0xfffff0000
    9a08:	927c7c00 	and	x0, x0, #0xffffffff0
    9a0c:	cb2563e5 	sub	x5, sp, x5
    9a10:	eb2563ff 	cmp	sp, x5
    9a14:	540000a0 	b.eq	9a28 <fwp_hof0.constprop.0+0x2e8>  // b.none
    9a18:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9a1c:	f90203ff 	str	xzr, [sp, #1024]
    9a20:	eb2563ff 	cmp	sp, x5
    9a24:	54ffffa1 	b.ne	9a18 <fwp_hof0.constprop.0+0x2d8>  // b.any
    9a28:	92403c00 	and	x0, x0, #0xffff
    9a2c:	cb2063ff 	sub	sp, sp, x0
    9a30:	f90003ff 	str	xzr, [sp]
    9a34:	f110001f 	cmp	x0, #0x400
    9a38:	54000043 	b.cc	9a40 <fwp_hof0.constprop.0+0x300>  // b.lo, b.ul, b.last
    9a3c:	f90203ff 	str	xzr, [sp, #1024]
    9a40:	910043fb 	add	x27, sp, #0x10
    9a44:	d37d7c28 	ubfiz	x8, x1, #3, #32
    9a48:	91002127 	add	x7, x9, #0x8
    9a4c:	d2800000 	mov	x0, #0x0                   	// #0
    9a50:	340000e1 	cbz	w1, 9a6c <fwp_hof0.constprop.0+0x32c>
    9a54:	d503201f 	nop
    9a58:	f86068e2 	ldr	x2, [x7, x0]
    9a5c:	f8206b62 	str	x2, [x27, x0]
    9a60:	91002000 	add	x0, x0, #0x8
    9a64:	eb00011f 	cmp	x8, x0
    9a68:	54ffff81 	b.ne	9a58 <fwp_hof0.constprop.0+0x318>  // b.any
    9a6c:	2a1303e8 	mov	w8, w19
    9a70:	d2800000 	mov	x0, #0x0                   	// #0
    9a74:	340000f3 	cbz	w19, 9a90 <fwp_hof0.constprop.0+0x350>
    9a78:	0b000022 	add	w2, w1, w0
    9a7c:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    9a80:	91000400 	add	x0, x0, #0x1
    9a84:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9a88:	eb00011f 	cmp	x8, x0
    9a8c:	54ffff61 	b.ne	9a78 <fwp_hof0.constprop.0+0x338>  // b.any
    9a90:	f949dac0 	ldr	x0, [x22, #5040]
    9a94:	f949eec1 	ldr	x1, [x22, #5080]
    9a98:	cb000300 	sub	x0, x24, x0
    9a9c:	eb01401f 	cmp	x0, x1, lsl #16
    9aa0:	540002e2 	b.cs	9afc <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9aa4:	d350fc01 	lsr	x1, x0, #16
    9aa8:	f949fec8 	ldr	x8, [x22, #5112]
    9aac:	8b010821 	add	x1, x1, x1, lsl #2
    9ab0:	d37df021 	lsl	x1, x1, #3
    9ab4:	8b010107 	add	x7, x8, x1
    9ab8:	f94010e6 	ldr	x6, [x7, #32]
    9abc:	b4000206 	cbz	x6, 9afc <fwp_hof0.constprop.0+0x3bc>
    9ac0:	38616901 	ldrb	w1, [x8, x1]
    9ac4:	7100083f 	cmp	w1, #0x2
    9ac8:	540004a0 	b.eq	9b5c <fwp_hof0.constprop.0+0x41c>  // b.none
    9acc:	7100043f 	cmp	w1, #0x1
    9ad0:	54000161 	b.ne	9afc <fwp_hof0.constprop.0+0x3bc>  // b.any
    9ad4:	294304e8 	ldp	w8, w1, [x7, #24]
    9ad8:	92403c00 	and	x0, x0, #0xffff
    9adc:	9b087c00 	mul	x0, x0, x8
    9ae0:	d360fc00 	lsr	x0, x0, #32
    9ae4:	eb01001f 	cmp	x0, x1
    9ae8:	540000a2 	b.cs	9afc <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9aec:	8b0000c6 	add	x6, x6, x0
    9af0:	394000c0 	ldrb	w0, [x6]
    9af4:	7100041f 	cmp	w0, #0x1
    9af8:	540002e0 	b.eq	9b54 <fwp_hof0.constprop.0+0x414>  // b.none
    9afc:	f9400546 	ldr	x6, [x10, #8]
    9b00:	aa1803e0 	mov	x0, x24
    9b04:	52800021 	mov	w1, #0x1                   	// #1
    9b08:	d63f00c0 	blr	x6
    9b0c:	f9400ee1 	ldr	x1, [x23, #24]
    9b10:	aa1b03e0 	mov	x0, x27
    9b14:	f9400021 	ldr	x1, [x1]
    9b18:	d63f0020 	blr	x1
    9b1c:	aa0003fb 	mov	x27, x0
    9b20:	f85d83a0 	ldur	x0, [x29, #-40]
    9b24:	9100001f 	mov	sp, x0
    9b28:	aa1803e0 	mov	x0, x24
    9b2c:	97fff159 	bl	6090 <fwp_closure_drop>
    9b30:	6b14027f 	cmp	w19, w20
    9b34:	54fff381 	b.ne	99a4 <fwp_hof0.constprop.0+0x264>  // b.any
    9b38:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9b3c:	aa1b03f8 	mov	x24, x27
    9b40:	b85c03b9 	ldur	w25, [x29, #-64]
    9b44:	6b17033f 	cmp	w25, w23
    9b48:	54000443 	b.cc	9bd0 <fwp_hof0.constprop.0+0x490>  // b.lo, b.ul, b.last
    9b4c:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9b50:	1400003e 	b	9c48 <fwp_hof0.constprop.0+0x508>
    9b54:	b900053f 	str	wzr, [x9, #4]
    9b58:	17ffffed 	b	9b0c <fwp_hof0.constprop.0+0x3cc>
    9b5c:	72003c1f 	tst	w0, #0xffff
    9b60:	54fffce1 	b.ne	9afc <fwp_hof0.constprop.0+0x3bc>  // b.any
    9b64:	17ffffe3 	b	9af0 <fwp_hof0.constprop.0+0x3b0>
    9b68:	aa1b03fa 	mov	x26, x27
    9b6c:	aa1903fb 	mov	x27, x25
    9b70:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9b74:	b85c03b9 	ldur	w25, [x29, #-64]
    9b78:	aa1a03e0 	mov	x0, x26
    9b7c:	b81d83a6 	stur	w6, [x29, #-40]
    9b80:	97ffef59 	bl	58e4 <fwp_rc_share>
    9b84:	b85d83a6 	ldur	w6, [x29, #-40]
    9b88:	34000134 	cbz	w20, 9bac <fwp_hof0.constprop.0+0x46c>
    9b8c:	aa1b03f8 	mov	x24, x27
    9b90:	8b344f73 	add	x19, x27, w20, uxtw #3
    9b94:	2a0603fc 	mov	w28, w6
    9b98:	f8408700 	ldr	x0, [x24], #8
    9b9c:	97ffef52 	bl	58e4 <fwp_rc_share>
    9ba0:	eb18027f 	cmp	x19, x24
    9ba4:	54ffffa1 	b.ne	9b98 <fwp_hof0.constprop.0+0x458>  // b.any
    9ba8:	2a1c03e6 	mov	w6, w28
    9bac:	aa1b03e2 	mov	x2, x27
    9bb0:	2a1403e1 	mov	w1, w20
    9bb4:	aa1a03e0 	mov	x0, x26
    9bb8:	b81d83a6 	stur	w6, [x29, #-40]
    9bbc:	97ffec52 	bl	4d04 <fwp_apply>
    9bc0:	aa0003f8 	mov	x24, x0
    9bc4:	b85d83a6 	ldur	w6, [x29, #-40]
    9bc8:	6b17033f 	cmp	w25, w23
    9bcc:	54fffc02 	b.cs	9b4c <fwp_hof0.constprop.0+0x40c>  // b.hs, b.nlast
    9bd0:	f9403ea1 	ldr	x1, [x21, #120]
    9bd4:	4b0602f7 	sub	w23, w23, w6
    9bd8:	b9400304 	ldr	w4, [x24]
    9bdc:	f85d03a0 	ldur	x0, [x29, #-48]
    9be0:	8b041424 	add	x4, x1, x4, lsl #5
    9be4:	b85c83a2 	ldur	w2, [x29, #-56]
    9be8:	8b264c00 	add	x0, x0, w6, uxtw #3
    9bec:	f81d03a0 	stur	x0, [x29, #-48]
    9bf0:	f9400c81 	ldr	x1, [x4, #24]
    9bf4:	b85cc3a0 	ldur	w0, [x29, #-52]
    9bf8:	4b020000 	sub	w0, w0, w2
    9bfc:	b81cc3a0 	stur	w0, [x29, #-52]
    9c00:	aa1803e0 	mov	x0, x24
    9c04:	b5ffe7e1 	cbnz	x1, 9900 <fwp_hof0.constprop.0+0x1c0>
    9c08:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9c0c:	aa1803e0 	mov	x0, x24
    9c10:	97ffef35 	bl	58e4 <fwp_rc_share>
    9c14:	34000117 	cbz	w23, 9c34 <fwp_hof0.constprop.0+0x4f4>
    9c18:	f85d03ba 	ldur	x26, [x29, #-48]
    9c1c:	d2800016 	mov	x22, #0x0                   	// #0
    9c20:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    9c24:	910006d6 	add	x22, x22, #0x1
    9c28:	97ffef2f 	bl	58e4 <fwp_rc_share>
    9c2c:	6b1602ff 	cmp	w23, w22
    9c30:	54ffff88 	b.hi	9c20 <fwp_hof0.constprop.0+0x4e0>  // b.pmore
    9c34:	f85d03a2 	ldur	x2, [x29, #-48]
    9c38:	aa1803e0 	mov	x0, x24
    9c3c:	2a1703e1 	mov	w1, w23
    9c40:	97ffec31 	bl	4d04 <fwp_apply>
    9c44:	aa0003f8 	mov	x24, x0
    9c48:	f85a03a0 	ldur	x0, [x29, #-96]
    9c4c:	f1000400 	subs	x0, x0, #0x1
    9c50:	f81a03a0 	stur	x0, [x29, #-96]
    9c54:	54ffdee1 	b.ne	9830 <fwp_hof0.constprop.0+0xf0>  // b.any
    9c58:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe720>
    9c5c:	91102042 	add	x2, x2, #0x408
    9c60:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    9c64:	aa1803e1 	mov	x1, x24
    9c68:	aa1403e0 	mov	x0, x20
    9c6c:	aa1803fb 	mov	x27, x24
    9c70:	91014042 	add	x2, x2, #0x50
    9c74:	52800023 	mov	w3, #0x1                   	// #1
    9c78:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9c7c:	aa1903fc 	mov	x28, x25
    9c80:	f81f03bf 	stur	xzr, [x29, #-16]
    9c84:	97fffab3 	bl	8750 <fwp_write>
    9c88:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    9c8c:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x840>
    9c90:	9106e000 	add	x0, x0, #0x1b8
    9c94:	f10002df 	cmp	x22, #0x0
    9c98:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9c9c:	b1002b1f 	cmn	x24, #0xa
    9ca0:	54003288 	b.hi	a2f0 <fwp_hof0.constprop.0+0xbb0>  // b.pmore
    9ca4:	91002700 	add	x0, x24, #0x9
    9ca8:	52800021 	mov	w1, #0x1                   	// #1
    9cac:	97ffebd1 	bl	4bf0 <fwp_heap_alloc>
    9cb0:	aa0003f3 	mov	x19, x0
    9cb4:	aa1603e1 	mov	x1, x22
    9cb8:	aa0003f6 	mov	x22, x0
    9cbc:	aa1803e2 	mov	x2, x24
    9cc0:	f80086d8 	str	x24, [x22], #8
    9cc4:	8b180278 	add	x24, x19, x24
    9cc8:	aa1603e0 	mov	x0, x22
    9ccc:	97ffe25d 	bl	2640 <memcpy@plt>
    9cd0:	3900231f 	strb	wzr, [x24, #8]
    9cd4:	f85e03a0 	ldur	x0, [x29, #-32]
    9cd8:	97ffe2f6 	bl	28b0 <free@plt>
    9cdc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ce0:	91154003 	add	x3, x0, #0x550
    9ce4:	f949ec64 	ldr	x4, [x3, #5080]
    9ce8:	f949d861 	ldr	x1, [x3, #5040]
    9cec:	d370bc84 	lsl	x4, x4, #16
    9cf0:	cb010262 	sub	x2, x19, x1
    9cf4:	eb04005f 	cmp	x2, x4
    9cf8:	540003c2 	b.cs	9d70 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9cfc:	d350fc40 	lsr	x0, x2, #16
    9d00:	f949fc66 	ldr	x6, [x3, #5112]
    9d04:	8b000800 	add	x0, x0, x0, lsl #2
    9d08:	d37df003 	lsl	x3, x0, #3
    9d0c:	8b0300c0 	add	x0, x6, x3
    9d10:	f9401018 	ldr	x24, [x0, #32]
    9d14:	b40002f8 	cbz	x24, 9d70 <fwp_hof0.constprop.0+0x630>
    9d18:	386368c3 	ldrb	w3, [x6, x3]
    9d1c:	7100087f 	cmp	w3, #0x2
    9d20:	54002ee0 	b.eq	a2fc <fwp_hof0.constprop.0+0xbbc>  // b.none
    9d24:	7100047f 	cmp	w3, #0x1
    9d28:	54000241 	b.ne	9d70 <fwp_hof0.constprop.0+0x630>  // b.any
    9d2c:	29430003 	ldp	w3, w0, [x0, #24]
    9d30:	92403c42 	and	x2, x2, #0xffff
    9d34:	9b037c42 	mul	x2, x2, x3
    9d38:	d360fc42 	lsr	x2, x2, #32
    9d3c:	eb00005f 	cmp	x2, x0
    9d40:	54000182 	b.cs	9d70 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9d44:	8b020318 	add	x24, x24, x2
    9d48:	39400300 	ldrb	w0, [x24]
    9d4c:	7103fc1f 	cmp	w0, #0xff
    9d50:	54003cc0 	b.eq	a4e8 <fwp_hof0.constprop.0+0xda8>  // b.none
    9d54:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9d58:	91154000 	add	x0, x0, #0x550
    9d5c:	52800021 	mov	w1, #0x1                   	// #1
    9d60:	39000301 	strb	w1, [x24]
    9d64:	f949ec04 	ldr	x4, [x0, #5080]
    9d68:	f949d801 	ldr	x1, [x0, #5040]
    9d6c:	d370bc84 	lsl	x4, x4, #16
    9d70:	cb010361 	sub	x1, x27, x1
    9d74:	eb01009f 	cmp	x4, x1
    9d78:	540003c9 	b.ls	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.plast
    9d7c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9d80:	91154019 	add	x25, x0, #0x550
    9d84:	d350fc22 	lsr	x2, x1, #16
    9d88:	f949ff26 	ldr	x6, [x25, #5112]
    9d8c:	8b020842 	add	x2, x2, x2, lsl #2
    9d90:	d37df042 	lsl	x2, x2, #3
    9d94:	8b0200c0 	add	x0, x6, x2
    9d98:	f9401018 	ldr	x24, [x0, #32]
    9d9c:	b40002b8 	cbz	x24, 9df0 <fwp_hof0.constprop.0+0x6b0>
    9da0:	386268c2 	ldrb	w2, [x6, x2]
    9da4:	7100085f 	cmp	w2, #0x2
    9da8:	540030a0 	b.eq	a3bc <fwp_hof0.constprop.0+0xc7c>  // b.none
    9dac:	7100045f 	cmp	w2, #0x1
    9db0:	54000201 	b.ne	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.any
    9db4:	29430002 	ldp	w2, w0, [x0, #24]
    9db8:	92403c21 	and	x1, x1, #0xffff
    9dbc:	9b027c21 	mul	x1, x1, x2
    9dc0:	d360fc21 	lsr	x1, x1, #32
    9dc4:	eb00003f 	cmp	x1, x0
    9dc8:	54000142 	b.cs	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    9dcc:	8b010318 	add	x24, x24, x1
    9dd0:	39400300 	ldrb	w0, [x24]
    9dd4:	340000e0 	cbz	w0, 9df0 <fwp_hof0.constprop.0+0x6b0>
    9dd8:	7100041f 	cmp	w0, #0x1
    9ddc:	540029c0 	b.eq	a314 <fwp_hof0.constprop.0+0xbd4>  // b.none
    9de0:	7103fc1f 	cmp	w0, #0xff
    9de4:	54002fa0 	b.eq	a3d8 <fwp_hof0.constprop.0+0xc98>  // b.none
    9de8:	51000400 	sub	w0, w0, #0x1
    9dec:	39000300 	strb	w0, [x24]
    9df0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9df4:	91010003 	add	x3, x0, #0x40
    9df8:	f9400262 	ldr	x2, [x19]
    9dfc:	aa1603e0 	mov	x0, x22
    9e00:	aa0303f6 	mov	x22, x3
    9e04:	d2800021 	mov	x1, #0x1                   	// #1
    9e08:	f9400463 	ldr	x3, [x3, #8]
    9e0c:	97ffe2b9 	bl	28f0 <fwrite@plt>
    9e10:	f94006c1 	ldr	x1, [x22, #8]
    9e14:	52800140 	mov	w0, #0xa                   	// #10
    9e18:	97ffe23e 	bl	2710 <fputc@plt>
    9e1c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9e20:	91154002 	add	x2, x0, #0x550
    9e24:	f949d841 	ldr	x1, [x2, #5040]
    9e28:	f949ec40 	ldr	x0, [x2, #5080]
    9e2c:	cb010261 	sub	x1, x19, x1
    9e30:	eb00403f 	cmp	x1, x0, lsl #16
    9e34:	54000382 	b.cs	9ea4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    9e38:	d350fc20 	lsr	x0, x1, #16
    9e3c:	f949fc43 	ldr	x3, [x2, #5112]
    9e40:	8b000800 	add	x0, x0, x0, lsl #2
    9e44:	d37df000 	lsl	x0, x0, #3
    9e48:	8b000062 	add	x2, x3, x0
    9e4c:	f9401056 	ldr	x22, [x2, #32]
    9e50:	b40002b6 	cbz	x22, 9ea4 <fwp_hof0.constprop.0+0x764>
    9e54:	38606860 	ldrb	w0, [x3, x0]
    9e58:	7100081f 	cmp	w0, #0x2
    9e5c:	54002560 	b.eq	a308 <fwp_hof0.constprop.0+0xbc8>  // b.none
    9e60:	7100041f 	cmp	w0, #0x1
    9e64:	54000201 	b.ne	9ea4 <fwp_hof0.constprop.0+0x764>  // b.any
    9e68:	29430043 	ldp	w3, w0, [x2, #24]
    9e6c:	92403c21 	and	x1, x1, #0xffff
    9e70:	9b037c21 	mul	x1, x1, x3
    9e74:	d360fc21 	lsr	x1, x1, #32
    9e78:	eb00003f 	cmp	x1, x0
    9e7c:	54000142 	b.cs	9ea4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    9e80:	8b0102d6 	add	x22, x22, x1
    9e84:	394002c0 	ldrb	w0, [x22]
    9e88:	340000e0 	cbz	w0, 9ea4 <fwp_hof0.constprop.0+0x764>
    9e8c:	7100041f 	cmp	w0, #0x1
    9e90:	54002de0 	b.eq	a44c <fwp_hof0.constprop.0+0xd0c>  // b.none
    9e94:	7103fc1f 	cmp	w0, #0xff
    9e98:	54002e00 	b.eq	a458 <fwp_hof0.constprop.0+0xd18>  // b.none
    9e9c:	51000400 	sub	w0, w0, #0x1
    9ea0:	390002c0 	strb	w0, [x22]
    9ea4:	f9400af7 	ldr	x23, [x23, #16]
    9ea8:	b5ffc7b7 	cbnz	x23, 979c <fwp_hof0.constprop.0+0x5c>
    9eac:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9eb0:	f947f400 	ldr	x0, [x0, #4072]
    9eb4:	f85f83a2 	ldur	x2, [x29, #-8]
    9eb8:	f9400001 	ldr	x1, [x0]
    9ebc:	eb010042 	subs	x2, x2, x1
    9ec0:	d2800001 	mov	x1, #0x0                   	// #0
    9ec4:	54002821 	b.ne	a3c8 <fwp_hof0.constprop.0+0xc88>  // b.any
    9ec8:	910003bf 	mov	sp, x29
    9ecc:	d2800000 	mov	x0, #0x0                   	// #0
    9ed0:	a94153f3 	ldp	x19, x20, [sp, #16]
    9ed4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9ed8:	a94363f7 	ldp	x23, x24, [sp, #48]
    9edc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9ee0:	a94573fb 	ldp	x27, x28, [sp, #80]
    9ee4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9ee8:	d65f03c0 	ret
    9eec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ef0:	9115400a 	add	x10, x0, #0x550
    9ef4:	2a0103fa 	mov	w26, w1
    9ef8:	11000780 	add	w0, w28, #0x1
    9efc:	f120001f 	cmp	x0, #0x800
    9f00:	aa1703e4 	mov	x4, x23
    9f04:	b953a541 	ldr	w1, [x10, #5028]
    9f08:	aa1903fb 	mov	x27, x25
    9f0c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9f10:	d37df000 	lsl	x0, x0, #3
    9f14:	b85c03b9 	ldur	w25, [x29, #-64]
    9f18:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9f1c:	540018e0 	b.eq	a238 <fwp_hof0.constprop.0+0xaf8>  // b.none
    9f20:	91003c01 	add	x1, x0, #0xf
    9f24:	8b411141 	add	x1, x10, x1, lsr #4
    9f28:	397e8021 	ldrb	w1, [x1, #4000]
    9f2c:	910f002b 	add	x11, x1, #0x3c0
    9f30:	8b010422 	add	x2, x1, x1, lsl #1
    9f34:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9f38:	8b020d4c 	add	x12, x10, x2, lsl #3
    9f3c:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    9f40:	2a0b03e1 	mov	w1, w11
    9f44:	b4001693 	cbz	x19, a214 <fwp_hof0.constprop.0+0xad4>
    9f48:	f940026c 	ldr	x12, [x19]
    9f4c:	aa2c03ec 	mvn	x12, x12
    9f50:	f822794c 	str	x12, [x10, x2, lsl #3]
    9f54:	eb01001f 	cmp	x0, x1
    9f58:	540000c2 	b.cs	9f70 <fwp_hof0.constprop.0+0x830>  // b.hs, b.nlast
    9f5c:	d503201f 	nop
    9f60:	f8206a7f 	str	xzr, [x19, x0]
    9f64:	91002000 	add	x0, x0, #0x8
    9f68:	eb00003f 	cmp	x1, x0
    9f6c:	54ffffa8 	b.hi	9f60 <fwp_hof0.constprop.0+0x820>  // b.pmore
    9f70:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9f74:	91154002 	add	x2, x0, #0x550
    9f78:	f94a1040 	ldr	x0, [x2, #5152]
    9f7c:	ab010000 	adds	x0, x0, x1
    9f80:	54002a62 	b.cs	a4cc <fwp_hof0.constprop.0+0xd8c>  // b.hs, b.nlast
    9f84:	f94a1441 	ldr	x1, [x2, #5160]
    9f88:	f90a1040 	str	x0, [x2, #5152]
    9f8c:	eb01001f 	cmp	x0, x1
    9f90:	54000049 	b.ls	9f98 <fwp_hof0.constprop.0+0x858>  // b.plast
    9f94:	f90a1440 	str	x0, [x2, #5160]
    9f98:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9f9c:	91154000 	add	x0, x0, #0x550
    9fa0:	1e630161 	ucvtf	d1, w11
    9fa4:	fd4a1c00 	ldr	d0, [x0, #5176]
    9fa8:	1e612800 	fadd	d0, d0, d1
    9fac:	fd0a1c00 	str	d0, [x0, #5176]
    9fb0:	b9400120 	ldr	w0, [x9]
    9fb4:	29007260 	stp	w0, w28, [x19]
    9fb8:	3400017a 	cbz	w26, 9fe4 <fwp_hof0.constprop.0+0x8a4>
    9fbc:	91002121 	add	x1, x9, #0x8
    9fc0:	d37d7f42 	ubfiz	x2, x26, #3, #32
    9fc4:	91002260 	add	x0, x19, #0x8
    9fc8:	b81bc3a6 	stur	w6, [x29, #-68]
    9fcc:	f81c03a4 	stur	x4, [x29, #-64]
    9fd0:	f81d83a9 	stur	x9, [x29, #-40]
    9fd4:	97ffe1a3 	bl	2660 <memmove@plt>
    9fd8:	f85c03a4 	ldur	x4, [x29, #-64]
    9fdc:	f85d83a9 	ldur	x9, [x29, #-40]
    9fe0:	b85bc3a6 	ldur	w6, [x29, #-68]
    9fe4:	2a1403e8 	mov	w8, w20
    9fe8:	d2800001 	mov	x1, #0x0                   	// #0
    9fec:	34000114 	cbz	w20, a00c <fwp_hof0.constprop.0+0x8cc>
    9ff0:	0b010340 	add	w0, w26, w1
    9ff4:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9ff8:	8b000e60 	add	x0, x19, x0, lsl #3
    9ffc:	91000421 	add	x1, x1, #0x1
    a000:	f9000402 	str	x2, [x0, #8]
    a004:	eb01011f 	cmp	x8, x1
    a008:	54ffff41 	b.ne	9ff0 <fwp_hof0.constprop.0+0x8b0>  // b.any
    a00c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a010:	91154002 	add	x2, x0, #0x550
    a014:	f949d840 	ldr	x0, [x2, #5040]
    a018:	f949ec41 	ldr	x1, [x2, #5080]
    a01c:	cb000300 	sub	x0, x24, x0
    a020:	eb01401f 	cmp	x0, x1, lsl #16
    a024:	540002e2 	b.cs	a080 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a028:	d350fc01 	lsr	x1, x0, #16
    a02c:	f949fc45 	ldr	x5, [x2, #5112]
    a030:	8b010821 	add	x1, x1, x1, lsl #2
    a034:	d37df021 	lsl	x1, x1, #3
    a038:	8b0100a3 	add	x3, x5, x1
    a03c:	f9401062 	ldr	x2, [x3, #32]
    a040:	b4000202 	cbz	x2, a080 <fwp_hof0.constprop.0+0x940>
    a044:	386168a1 	ldrb	w1, [x5, x1]
    a048:	7100083f 	cmp	w1, #0x2
    a04c:	540010a0 	b.eq	a260 <fwp_hof0.constprop.0+0xb20>  // b.none
    a050:	7100043f 	cmp	w1, #0x1
    a054:	54000161 	b.ne	a080 <fwp_hof0.constprop.0+0x940>  // b.any
    a058:	29430465 	ldp	w5, w1, [x3, #24]
    a05c:	92403c00 	and	x0, x0, #0xffff
    a060:	9b057c00 	mul	x0, x0, x5
    a064:	d360fc00 	lsr	x0, x0, #32
    a068:	eb01001f 	cmp	x0, x1
    a06c:	540000a2 	b.cs	a080 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a070:	8b000042 	add	x2, x2, x0
    a074:	39400040 	ldrb	w0, [x2]
    a078:	7100041f 	cmp	w0, #0x1
    a07c:	54000c20 	b.eq	a200 <fwp_hof0.constprop.0+0xac0>  // b.none
    a080:	f9400c82 	ldr	x2, [x4, #24]
    a084:	aa1803e0 	mov	x0, x24
    a088:	52800021 	mov	w1, #0x1                   	// #1
    a08c:	b81d83a6 	stur	w6, [x29, #-40]
    a090:	f9400442 	ldr	x2, [x2, #8]
    a094:	d63f0040 	blr	x2
    a098:	b85d83a6 	ldur	w6, [x29, #-40]
    a09c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a0a0:	91154002 	add	x2, x0, #0x550
    a0a4:	f949d841 	ldr	x1, [x2, #5040]
    a0a8:	f949ec40 	ldr	x0, [x2, #5080]
    a0ac:	cb010261 	sub	x1, x19, x1
    a0b0:	eb00403f 	cmp	x1, x0, lsl #16
    a0b4:	54000322 	b.cs	a118 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a0b8:	d350fc20 	lsr	x0, x1, #16
    a0bc:	f949fc43 	ldr	x3, [x2, #5112]
    a0c0:	8b000800 	add	x0, x0, x0, lsl #2
    a0c4:	d37df002 	lsl	x2, x0, #3
    a0c8:	8b020060 	add	x0, x3, x2
    a0cc:	f9401014 	ldr	x20, [x0, #32]
    a0d0:	b4000254 	cbz	x20, a118 <fwp_hof0.constprop.0+0x9d8>
    a0d4:	38626862 	ldrb	w2, [x3, x2]
    a0d8:	7100085f 	cmp	w2, #0x2
    a0dc:	54000c80 	b.eq	a26c <fwp_hof0.constprop.0+0xb2c>  // b.none
    a0e0:	7100045f 	cmp	w2, #0x1
    a0e4:	540001a1 	b.ne	a118 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a0e8:	29430002 	ldp	w2, w0, [x0, #24]
    a0ec:	92403c21 	and	x1, x1, #0xffff
    a0f0:	9b027c21 	mul	x1, x1, x2
    a0f4:	d360fc21 	lsr	x1, x1, #32
    a0f8:	eb00003f 	cmp	x1, x0
    a0fc:	540000e2 	b.cs	a118 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a100:	8b010294 	add	x20, x20, x1
    a104:	39400280 	ldrb	w0, [x20]
    a108:	7103fc1f 	cmp	w0, #0xff
    a10c:	54000ba0 	b.eq	a280 <fwp_hof0.constprop.0+0xb40>  // b.none
    a110:	52800020 	mov	w0, #0x1                   	// #1
    a114:	39000280 	strb	w0, [x20]
    a118:	aa1803e0 	mov	x0, x24
    a11c:	b81d83a6 	stur	w6, [x29, #-40]
    a120:	97ffefdc 	bl	6090 <fwp_closure_drop>
    a124:	aa1303f8 	mov	x24, x19
    a128:	b85d83a6 	ldur	w6, [x29, #-40]
    a12c:	17fffea7 	b	9bc8 <fwp_hof0.constprop.0+0x488>
    a130:	b8626860 	ldr	w0, [x3, x2]
    a134:	b94004c2 	ldr	w2, [x6, #4]
    a138:	4b020003 	sub	w3, w0, w2
    a13c:	7100047f 	cmp	w3, #0x1
    a140:	54ffb901 	b.ne	9860 <fwp_hof0.constprop.0+0x120>  // b.any
    a144:	910003f6 	mov	x22, sp
    a148:	34000c42 	cbz	w2, a2d0 <fwp_hof0.constprop.0+0xb90>
    a14c:	7100001f 	cmp	w0, #0x0
    a150:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a154:	d2800101 	mov	x1, #0x8                   	// #8
    a158:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a15c:	91003ee0 	add	x0, x23, #0xf
    a160:	92704c01 	and	x1, x0, #0xfffff0000
    a164:	927c7c00 	and	x0, x0, #0xffffffff0
    a168:	cb2163e1 	sub	x1, sp, x1
    a16c:	eb2163ff 	cmp	sp, x1
    a170:	540000a0 	b.eq	a184 <fwp_hof0.constprop.0+0xa44>  // b.none
    a174:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a178:	f90203ff 	str	xzr, [sp, #1024]
    a17c:	eb2163ff 	cmp	sp, x1
    a180:	54ffffa1 	b.ne	a174 <fwp_hof0.constprop.0+0xa34>  // b.any
    a184:	92403c00 	and	x0, x0, #0xffff
    a188:	cb2063ff 	sub	sp, sp, x0
    a18c:	f90003ff 	str	xzr, [sp]
    a190:	f110001f 	cmp	x0, #0x400
    a194:	54000043 	b.cc	a19c <fwp_hof0.constprop.0+0xa5c>  // b.lo, b.ul, b.last
    a198:	f90203ff 	str	xzr, [sp, #1024]
    a19c:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a1a0:	910043fa 	add	x26, sp, #0x10
    a1a4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a1a8:	91004001 	add	x1, x0, #0x10
    a1ac:	aa1b03e2 	mov	x2, x27
    a1b0:	91004021 	add	x1, x1, #0x10
    a1b4:	aa1703e3 	mov	x3, x23
    a1b8:	aa1a03e0 	mov	x0, x26
    a1bc:	f81d83a4 	stur	x4, [x29, #-40]
    a1c0:	97ffe160 	bl	2740 <__memcpy_chk@plt>
    a1c4:	eb1b02ff 	cmp	x23, x27
    a1c8:	aa1403e1 	mov	x1, x20
    a1cc:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a1d0:	d2800102 	mov	x2, #0x8                   	// #8
    a1d4:	cb1b0063 	sub	x3, x3, x27
    a1d8:	8b1b0340 	add	x0, x26, x27
    a1dc:	97ffe159 	bl	2740 <__memcpy_chk@plt>
    a1e0:	f85d83a4 	ldur	x4, [x29, #-40]
    a1e4:	aa1a03e0 	mov	x0, x26
    a1e8:	f9400c81 	ldr	x1, [x4, #24]
    a1ec:	f9400021 	ldr	x1, [x1]
    a1f0:	d63f0020 	blr	x1
    a1f4:	aa0003f8 	mov	x24, x0
    a1f8:	910002df 	mov	sp, x22
    a1fc:	17fffe93 	b	9c48 <fwp_hof0.constprop.0+0x508>
    a200:	b900053f 	str	wzr, [x9, #4]
    a204:	17ffffa6 	b	a09c <fwp_hof0.constprop.0+0x95c>
    a208:	72003c3f 	tst	w1, #0xffff
    a20c:	54ffb6a1 	b.ne	98e0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a210:	17fffdae 	b	98c8 <fwp_hof0.constprop.0+0x188>
    a214:	f9400593 	ldr	x19, [x12, #8]
    a218:	b4000113 	cbz	x19, a238 <fwp_hof0.constprop.0+0xaf8>
    a21c:	f9400982 	ldr	x2, [x12, #16]
    a220:	cb130042 	sub	x2, x2, x19
    a224:	eb02003f 	cmp	x1, x2
    a228:	54000088 	b.hi	a238 <fwp_hof0.constprop.0+0xaf8>  // b.pmore
    a22c:	8b010262 	add	x2, x19, x1
    a230:	f9000582 	str	x2, [x12, #8]
    a234:	17ffff48 	b	9f54 <fwp_hof0.constprop.0+0x814>
    a238:	52800001 	mov	w1, #0x0                   	// #0
    a23c:	b81bc3a6 	stur	w6, [x29, #-68]
    a240:	f81c03a4 	stur	x4, [x29, #-64]
    a244:	f81d83a9 	stur	x9, [x29, #-40]
    a248:	97ffea6a 	bl	4bf0 <fwp_heap_alloc>
    a24c:	f85c03a4 	ldur	x4, [x29, #-64]
    a250:	aa0003f3 	mov	x19, x0
    a254:	f85d83a9 	ldur	x9, [x29, #-40]
    a258:	b85bc3a6 	ldur	w6, [x29, #-68]
    a25c:	17ffff55 	b	9fb0 <fwp_hof0.constprop.0+0x870>
    a260:	72003c1f 	tst	w0, #0xffff
    a264:	54fff0e1 	b.ne	a080 <fwp_hof0.constprop.0+0x940>  // b.any
    a268:	17ffff83 	b	a074 <fwp_hof0.constprop.0+0x934>
    a26c:	72003c3f 	tst	w1, #0xffff
    a270:	54fff541 	b.ne	a118 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a274:	39400280 	ldrb	w0, [x20]
    a278:	7103fc1f 	cmp	w0, #0xff
    a27c:	54fff4a1 	b.ne	a110 <fwp_hof0.constprop.0+0x9d0>  // b.any
    a280:	aa1403e0 	mov	x0, x20
    a284:	b81d83a6 	stur	w6, [x29, #-40]
    a288:	97ffe702 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a28c:	b85d83a6 	ldur	w6, [x29, #-40]
    a290:	17ffffa0 	b	a110 <fwp_hof0.constprop.0+0x9d0>
    a294:	72003c5f 	tst	w2, #0xffff
    a298:	54ffac21 	b.ne	981c <fwp_hof0.constprop.0+0xdc>  // b.any
    a29c:	17fffd5a 	b	9804 <fwp_hof0.constprop.0+0xc4>
    a2a0:	f81d83a4 	stur	x4, [x29, #-40]
    a2a4:	97ffe810 	bl	42e4 <fwp_rc_wide_dup>
    a2a8:	f85d83a4 	ldur	x4, [x29, #-40]
    a2ac:	17fffd8d 	b	98e0 <fwp_hof0.constprop.0+0x1a0>
    a2b0:	aa1903e0 	mov	x0, x25
    a2b4:	97ffed8c 	bl	58e4 <fwp_rc_share>
    a2b8:	aa1803e0 	mov	x0, x24
    a2bc:	52800037 	mov	w23, #0x1                   	// #1
    a2c0:	97ffed89 	bl	58e4 <fwp_rc_share>
    a2c4:	aa1903f8 	mov	x24, x25
    a2c8:	f81d03b4 	stur	x20, [x29, #-48]
    a2cc:	17fffe5a 	b	9c34 <fwp_hof0.constprop.0+0x4f4>
    a2d0:	f9400021 	ldr	x1, [x1]
    a2d4:	aa1403e0 	mov	x0, x20
    a2d8:	d63f0020 	blr	x1
    a2dc:	aa0003f8 	mov	x24, x0
    a2e0:	910002df 	mov	sp, x22
    a2e4:	17fffe59 	b	9c48 <fwp_hof0.constprop.0+0x508>
    a2e8:	97ffe7ff 	bl	42e4 <fwp_rc_wide_dup>
    a2ec:	17fffd4c 	b	981c <fwp_hof0.constprop.0+0xdc>
    a2f0:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x47c>
    a2f4:	91358000 	add	x0, x0, #0xd60
    a2f8:	97ffe6c6 	bl	3e10 <fwp_trap>
    a2fc:	72003c5f 	tst	w2, #0xffff
    a300:	54ffd381 	b.ne	9d70 <fwp_hof0.constprop.0+0x630>  // b.any
    a304:	17fffe91 	b	9d48 <fwp_hof0.constprop.0+0x608>
    a308:	72003c3f 	tst	w1, #0xffff
    a30c:	54ffdcc1 	b.ne	9ea4 <fwp_hof0.constprop.0+0x764>  // b.any
    a310:	17fffedd 	b	9e84 <fwp_hof0.constprop.0+0x744>
    a314:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a318:	91154000 	add	x0, x0, #0x550
    a31c:	f9400b78 	ldr	x24, [x27, #16]
    a320:	f949ec03 	ldr	x3, [x0, #5080]
    a324:	f949d801 	ldr	x1, [x0, #5040]
    a328:	d370bc63 	lsl	x3, x3, #16
    a32c:	cb010362 	sub	x2, x27, x1
    a330:	eb03005f 	cmp	x2, x3
    a334:	540003a2 	b.cs	a3a8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a338:	d350fc44 	lsr	x4, x2, #16
    a33c:	8b040884 	add	x4, x4, x4, lsl #2
    a340:	d37df084 	lsl	x4, x4, #3
    a344:	8b0400c0 	add	x0, x6, x4
    a348:	f9401005 	ldr	x5, [x0, #32]
    a34c:	b40002e5 	cbz	x5, a3a8 <fwp_hof0.constprop.0+0xc68>
    a350:	386468c4 	ldrb	w4, [x6, x4]
    a354:	7100089f 	cmp	w4, #0x2
    a358:	540003a0 	b.eq	a3cc <fwp_hof0.constprop.0+0xc8c>  // b.none
    a35c:	7100049f 	cmp	w4, #0x1
    a360:	54000241 	b.ne	a3a8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a364:	29430004 	ldp	w4, w0, [x0, #24]
    a368:	92403c42 	and	x2, x2, #0xffff
    a36c:	9b047c42 	mul	x2, x2, x4
    a370:	d360fc42 	lsr	x2, x2, #32
    a374:	eb00005f 	cmp	x2, x0
    a378:	54000182 	b.cs	a3a8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a37c:	8b0200a5 	add	x5, x5, x2
    a380:	394000a0 	ldrb	w0, [x5]
    a384:	7100041f 	cmp	w0, #0x1
    a388:	54000101 	b.ne	a3a8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a38c:	aa1b03e0 	mov	x0, x27
    a390:	97ffe75c 	bl	4100 <fwp_mem_free>
    a394:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a398:	91154000 	add	x0, x0, #0x550
    a39c:	f949ec03 	ldr	x3, [x0, #5080]
    a3a0:	f949d801 	ldr	x1, [x0, #5040]
    a3a4:	d370bc63 	lsl	x3, x3, #16
    a3a8:	cb010301 	sub	x1, x24, x1
    a3ac:	eb03003f 	cmp	x1, x3
    a3b0:	54ffd202 	b.cs	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a3b4:	aa1803fb 	mov	x27, x24
    a3b8:	17fffe73 	b	9d84 <fwp_hof0.constprop.0+0x644>
    a3bc:	72003c3f 	tst	w1, #0xffff
    a3c0:	54ffd181 	b.ne	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a3c4:	17fffe83 	b	9dd0 <fwp_hof0.constprop.0+0x690>
    a3c8:	97ffe10a 	bl	27f0 <__stack_chk_fail@plt>
    a3cc:	72003c5f 	tst	w2, #0xffff
    a3d0:	54fffec1 	b.ne	a3a8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a3d4:	17ffffeb 	b	a380 <fwp_hof0.constprop.0+0xc40>
    a3d8:	ca584700 	eor	x0, x24, x24, lsr #17
    a3dc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    a3e0:	91154022 	add	x2, x1, #0x550
    a3e4:	ca402400 	eor	x0, x0, x0, lsr #9
    a3e8:	92401c00 	and	x0, x0, #0xff
    a3ec:	910a2401 	add	x1, x0, #0x289
    a3f0:	8b000c40 	add	x0, x2, x0, lsl #3
    a3f4:	8b010c41 	add	x1, x2, x1, lsl #3
    a3f8:	f94a2400 	ldr	x0, [x0, #5192]
    a3fc:	b50000a0 	cbnz	x0, a410 <fwp_hof0.constprop.0+0xcd0>
    a400:	14000034 	b	a4d0 <fwp_hof0.constprop.0+0xd90>
    a404:	91004001 	add	x1, x0, #0x10
    a408:	f9400800 	ldr	x0, [x0, #16]
    a40c:	b4000620 	cbz	x0, a4d0 <fwp_hof0.constprop.0+0xd90>
    a410:	f9400002 	ldr	x2, [x0]
    a414:	eb02031f 	cmp	x24, x2
    a418:	54ffff61 	b.ne	a404 <fwp_hof0.constprop.0+0xcc4>  // b.any
    a41c:	f9400021 	ldr	x1, [x1]
    a420:	f9400420 	ldr	x0, [x1, #8]
    a424:	d1000400 	sub	x0, x0, #0x1
    a428:	f9000420 	str	x0, [x1, #8]
    a42c:	f103f81f 	cmp	x0, #0xfe
    a430:	54ffce01 	b.ne	9df0 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a434:	39400300 	ldrb	w0, [x24]
    a438:	7103fc1f 	cmp	w0, #0xff
    a43c:	54000500 	b.eq	a4dc <fwp_hof0.constprop.0+0xd9c>  // b.none
    a440:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a444:	39000300 	strb	w0, [x24]
    a448:	17fffe6a 	b	9df0 <fwp_hof0.constprop.0+0x6b0>
    a44c:	aa1303e0 	mov	x0, x19
    a450:	97ffe72c 	bl	4100 <fwp_mem_free>
    a454:	17fffe94 	b	9ea4 <fwp_hof0.constprop.0+0x764>
    a458:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a45c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    a460:	91154022 	add	x2, x1, #0x550
    a464:	ca402400 	eor	x0, x0, x0, lsr #9
    a468:	92401c00 	and	x0, x0, #0xff
    a46c:	910a2401 	add	x1, x0, #0x289
    a470:	8b000c40 	add	x0, x2, x0, lsl #3
    a474:	8b010c41 	add	x1, x2, x1, lsl #3
    a478:	f94a2400 	ldr	x0, [x0, #5192]
    a47c:	b50000a0 	cbnz	x0, a490 <fwp_hof0.constprop.0+0xd50>
    a480:	14000014 	b	a4d0 <fwp_hof0.constprop.0+0xd90>
    a484:	91004001 	add	x1, x0, #0x10
    a488:	f9400800 	ldr	x0, [x0, #16]
    a48c:	b4000220 	cbz	x0, a4d0 <fwp_hof0.constprop.0+0xd90>
    a490:	f9400002 	ldr	x2, [x0]
    a494:	eb16005f 	cmp	x2, x22
    a498:	54ffff61 	b.ne	a484 <fwp_hof0.constprop.0+0xd44>  // b.any
    a49c:	f9400021 	ldr	x1, [x1]
    a4a0:	f9400420 	ldr	x0, [x1, #8]
    a4a4:	d1000400 	sub	x0, x0, #0x1
    a4a8:	f9000420 	str	x0, [x1, #8]
    a4ac:	f103f81f 	cmp	x0, #0xfe
    a4b0:	54ffcfa1 	b.ne	9ea4 <fwp_hof0.constprop.0+0x764>  // b.any
    a4b4:	394002c0 	ldrb	w0, [x22]
    a4b8:	7103fc1f 	cmp	w0, #0xff
    a4bc:	540001c0 	b.eq	a4f4 <fwp_hof0.constprop.0+0xdb4>  // b.none
    a4c0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a4c4:	390002c0 	strb	w0, [x22]
    a4c8:	17fffe77 	b	9ea4 <fwp_hof0.constprop.0+0x764>
    a4cc:	97ffe2b9 	bl	2fb0 <fwp_heap_oom>
    a4d0:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x47c>
    a4d4:	91240000 	add	x0, x0, #0x900
    a4d8:	97ffe64e 	bl	3e10 <fwp_trap>
    a4dc:	aa1803e0 	mov	x0, x24
    a4e0:	97ffe66c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a4e4:	17ffffd7 	b	a440 <fwp_hof0.constprop.0+0xd00>
    a4e8:	aa1803e0 	mov	x0, x24
    a4ec:	97ffe669 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a4f0:	17fffe19 	b	9d54 <fwp_hof0.constprop.0+0x614>
    a4f4:	aa1603e0 	mov	x0, x22
    a4f8:	97ffe666 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a4fc:	17fffff1 	b	a4c0 <fwp_hof0.constprop.0+0xd80>

000000000000a500 <f0>:
    a500:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a504:	910003fd 	mov	x29, sp
    a508:	a90153f3 	stp	x19, x20, [sp, #16]
    a50c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a510:	a90363f7 	stp	x23, x24, [sp, #48]
    a514:	a9046bf9 	stp	x25, x26, [sp, #64]
    a518:	a90573fb 	stp	x27, x28, [sp, #80]
    a51c:	d121c3ff 	sub	sp, sp, #0x870
    a520:	f90203ff 	str	xzr, [sp, #1024]
    a524:	d00000a0 	adrp	x0, 20000 <__data_start>
    a528:	91010003 	add	x3, x0, #0x40
    a52c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a530:	f947f400 	ldr	x0, [x0, #4072]
    a534:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc90>
    a538:	f9416065 	ldr	x5, [x3, #704]
    a53c:	f9400001 	ldr	x1, [x0]
    a540:	f90437e1 	str	x1, [sp, #2152]
    a544:	d2800001 	mov	x1, #0x0                   	// #0
    a548:	91154299 	add	x25, x20, #0x550
    a54c:	912163f6 	add	x22, sp, #0x858
    a550:	910063e4 	add	x4, sp, #0x18
    a554:	9100c3e1 	add	x1, sp, #0x30
    a558:	f0ffffc0 	adrp	x0, 5000 <fwp_tape_grow.constprop.0+0xdc>
    a55c:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a560:	91364000 	add	x0, x0, #0xd90
    a564:	913b4042 	add	x2, x2, #0xed0
    a568:	d2800013 	mov	x19, #0x0                   	// #0
    a56c:	d280011a 	mov	x26, #0x8                   	// #8
    a570:	d2800015 	mov	x21, #0x0                   	// #0
    a574:	52800037 	mov	w23, #0x1                   	// #1
    a578:	f90007e4 	str	x4, [sp, #8]
    a57c:	a9018be5 	stp	x5, x2, [sp, #24]
    a580:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a584:	a90403ff 	stp	xzr, x0, [sp, #64]
    a588:	f9016064 	str	x4, [x3, #704]
    a58c:	d503201f 	nop
    a590:	f100075b 	subs	x27, x26, #0x1
    a594:	aa1603e1 	mov	x1, x22
    a598:	da1f02b8 	sbc	x24, x21, xzr
    a59c:	52800020 	mov	w0, #0x1                   	// #1
    a5a0:	f9001ffb 	str	x27, [sp, #56]
    a5a4:	aa1b03fa 	mov	x26, x27
    a5a8:	f9042ffb 	str	x27, [sp, #2136]
    a5ac:	aa1803f5 	mov	x21, x24
    a5b0:	f90433f3 	str	x19, [sp, #2144]
    a5b4:	97ffec84 	bl	57c4 <fwp_data.part.0.constprop.0>
    a5b8:	f949db22 	ldr	x2, [x25, #5040]
    a5bc:	aa0003f3 	mov	x19, x0
    a5c0:	f949ef20 	ldr	x0, [x25, #5080]
    a5c4:	cb020262 	sub	x2, x19, x2
    a5c8:	eb00405f 	cmp	x2, x0, lsl #16
    a5cc:	54000302 	b.cs	a62c <f0+0x12c>  // b.hs, b.nlast
    a5d0:	d350fc40 	lsr	x0, x2, #16
    a5d4:	f949ff25 	ldr	x5, [x25, #5112]
    a5d8:	8b000800 	add	x0, x0, x0, lsl #2
    a5dc:	d37df001 	lsl	x1, x0, #3
    a5e0:	8b0100a0 	add	x0, x5, x1
    a5e4:	f940101c 	ldr	x28, [x0, #32]
    a5e8:	b400023c 	cbz	x28, a62c <f0+0x12c>
    a5ec:	386168a1 	ldrb	w1, [x5, x1]
    a5f0:	7100083f 	cmp	w1, #0x2
    a5f4:	54010ea0 	b.eq	c7c8 <f0+0x22c8>  // b.none
    a5f8:	7100043f 	cmp	w1, #0x1
    a5fc:	54000181 	b.ne	a62c <f0+0x12c>  // b.any
    a600:	29430001 	ldp	w1, w0, [x0, #24]
    a604:	92403c42 	and	x2, x2, #0xffff
    a608:	9b017c42 	mul	x2, x2, x1
    a60c:	d360fc42 	lsr	x2, x2, #32
    a610:	eb00005f 	cmp	x2, x0
    a614:	540000c2 	b.cs	a62c <f0+0x12c>  // b.hs, b.nlast
    a618:	8b02039c 	add	x28, x28, x2
    a61c:	39400380 	ldrb	w0, [x28]
    a620:	7103fc1f 	cmp	w0, #0xff
    a624:	54010cc0 	b.eq	c7bc <f0+0x22bc>  // b.none
    a628:	39000397 	strb	w23, [x28]
    a62c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a630:	aa18037b 	orr	x27, x27, x24
    a634:	b5fffafb 	cbnz	x27, a590 <f0+0x90>
    a638:	d00000a0 	adrp	x0, 20000 <__data_start>
    a63c:	91010018 	add	x24, x0, #0x40
    a640:	f94007e1 	ldr	x1, [sp, #8]
    a644:	f9001bff 	str	xzr, [sp, #48]
    a648:	f9416300 	ldr	x0, [x24, #704]
    a64c:	eb01001f 	cmp	x0, x1
    a650:	54012981 	b.ne	cb80 <f0+0x2680>  // b.any
    a654:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x840>
    a658:	910143e1 	add	x1, sp, #0x50
    a65c:	f9400fe2 	ldr	x2, [sp, #24]
    a660:	f9016302 	str	x2, [x24, #704]
    a664:	3dc12000 	ldr	q0, [x0, #1152]
    a668:	52800020 	mov	w0, #0x1                   	// #1
    a66c:	3d8017e0 	str	q0, [sp, #80]
    a670:	97ffec55 	bl	57c4 <fwp_data.part.0.constprop.0>
    a674:	91154283 	add	x3, x20, #0x550
    a678:	aa0003f5 	mov	x21, x0
    a67c:	f949d861 	ldr	x1, [x3, #5040]
    a680:	f949ec60 	ldr	x0, [x3, #5080]
    a684:	cb0102a1 	sub	x1, x21, x1
    a688:	eb00403f 	cmp	x1, x0, lsl #16
    a68c:	54000322 	b.cs	a6f0 <f0+0x1f0>  // b.hs, b.nlast
    a690:	d350fc22 	lsr	x2, x1, #16
    a694:	f949fc63 	ldr	x3, [x3, #5112]
    a698:	8b020842 	add	x2, x2, x2, lsl #2
    a69c:	d37df042 	lsl	x2, x2, #3
    a6a0:	8b020060 	add	x0, x3, x2
    a6a4:	f9401017 	ldr	x23, [x0, #32]
    a6a8:	b4000257 	cbz	x23, a6f0 <f0+0x1f0>
    a6ac:	38626862 	ldrb	w2, [x3, x2]
    a6b0:	7100085f 	cmp	w2, #0x2
    a6b4:	54010900 	b.eq	c7d4 <f0+0x22d4>  // b.none
    a6b8:	7100045f 	cmp	w2, #0x1
    a6bc:	540001a1 	b.ne	a6f0 <f0+0x1f0>  // b.any
    a6c0:	29430002 	ldp	w2, w0, [x0, #24]
    a6c4:	92403c21 	and	x1, x1, #0xffff
    a6c8:	9b027c21 	mul	x1, x1, x2
    a6cc:	d360fc21 	lsr	x1, x1, #32
    a6d0:	eb00003f 	cmp	x1, x0
    a6d4:	540000e2 	b.cs	a6f0 <f0+0x1f0>  // b.hs, b.nlast
    a6d8:	8b0102f7 	add	x23, x23, x1
    a6dc:	394002e0 	ldrb	w0, [x23]
    a6e0:	7103fc1f 	cmp	w0, #0xff
    a6e4:	54011680 	b.eq	c9b4 <f0+0x24b4>  // b.none
    a6e8:	52800020 	mov	w0, #0x1                   	// #1
    a6ec:	390002e0 	strb	w0, [x23]
    a6f0:	9101a3e1 	add	x1, sp, #0x68
    a6f4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a6f8:	52800020 	mov	w0, #0x1                   	// #1
    a6fc:	a906d7f7 	stp	x23, x21, [sp, #104]
    a700:	97ffec31 	bl	57c4 <fwp_data.part.0.constprop.0>
    a704:	97ffec9c 	bl	5974 <fwp_rc_fresh>
    a708:	aa0003e2 	mov	x2, x0
    a70c:	9101e3e1 	add	x1, sp, #0x78
    a710:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a714:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a718:	52800020 	mov	w0, #0x1                   	// #1
    a71c:	a9078bf5 	stp	x21, x2, [sp, #120]
    a720:	97ffec29 	bl	57c4 <fwp_data.part.0.constprop.0>
    a724:	97ffec94 	bl	5974 <fwp_rc_fresh>
    a728:	aa0003e2 	mov	x2, x0
    a72c:	910223e1 	add	x1, sp, #0x88
    a730:	52800020 	mov	w0, #0x1                   	// #1
    a734:	a9088bf7 	stp	x23, x2, [sp, #136]
    a738:	97ffec23 	bl	57c4 <fwp_data.part.0.constprop.0>
    a73c:	97ffec8e 	bl	5974 <fwp_rc_fresh>
    a740:	aa0003e2 	mov	x2, x0
    a744:	910263e1 	add	x1, sp, #0x98
    a748:	52800020 	mov	w0, #0x1                   	// #1
    a74c:	a9098bf5 	stp	x21, x2, [sp, #152]
    a750:	97ffec1d 	bl	57c4 <fwp_data.part.0.constprop.0>
    a754:	97ffec88 	bl	5974 <fwp_rc_fresh>
    a758:	aa0003e2 	mov	x2, x0
    a75c:	9102a3e1 	add	x1, sp, #0xa8
    a760:	52800020 	mov	w0, #0x1                   	// #1
    a764:	a90a8bf7 	stp	x23, x2, [sp, #168]
    a768:	97ffec17 	bl	57c4 <fwp_data.part.0.constprop.0>
    a76c:	97ffec82 	bl	5974 <fwp_rc_fresh>
    a770:	aa0003e2 	mov	x2, x0
    a774:	9102e3e1 	add	x1, sp, #0xb8
    a778:	52800020 	mov	w0, #0x1                   	// #1
    a77c:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a780:	97ffec11 	bl	57c4 <fwp_data.part.0.constprop.0>
    a784:	91154283 	add	x3, x20, #0x550
    a788:	aa0003f5 	mov	x21, x0
    a78c:	f949d861 	ldr	x1, [x3, #5040]
    a790:	f949ec60 	ldr	x0, [x3, #5080]
    a794:	cb0102a1 	sub	x1, x21, x1
    a798:	eb00403f 	cmp	x1, x0, lsl #16
    a79c:	54000322 	b.cs	a800 <f0+0x300>  // b.hs, b.nlast
    a7a0:	d350fc22 	lsr	x2, x1, #16
    a7a4:	f949fc63 	ldr	x3, [x3, #5112]
    a7a8:	8b020842 	add	x2, x2, x2, lsl #2
    a7ac:	d37df042 	lsl	x2, x2, #3
    a7b0:	8b020060 	add	x0, x3, x2
    a7b4:	f9401017 	ldr	x23, [x0, #32]
    a7b8:	b4000257 	cbz	x23, a800 <f0+0x300>
    a7bc:	38626862 	ldrb	w2, [x3, x2]
    a7c0:	7100085f 	cmp	w2, #0x2
    a7c4:	54010140 	b.eq	c7ec <f0+0x22ec>  // b.none
    a7c8:	7100045f 	cmp	w2, #0x1
    a7cc:	540001a1 	b.ne	a800 <f0+0x300>  // b.any
    a7d0:	29430002 	ldp	w2, w0, [x0, #24]
    a7d4:	92403c21 	and	x1, x1, #0xffff
    a7d8:	9b027c21 	mul	x1, x1, x2
    a7dc:	d360fc21 	lsr	x1, x1, #32
    a7e0:	eb00003f 	cmp	x1, x0
    a7e4:	540000e2 	b.cs	a800 <f0+0x300>  // b.hs, b.nlast
    a7e8:	8b0102f7 	add	x23, x23, x1
    a7ec:	394002e0 	ldrb	w0, [x23]
    a7f0:	7103fc1f 	cmp	w0, #0xff
    a7f4:	54010e60 	b.eq	c9c0 <f0+0x24c0>  // b.none
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	390002e0 	strb	w0, [x23]
    a800:	910323e1 	add	x1, sp, #0xc8
    a804:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a808:	52800020 	mov	w0, #0x1                   	// #1
    a80c:	a90cd7e2 	stp	x2, x21, [sp, #200]
    a810:	97ffebed 	bl	57c4 <fwp_data.part.0.constprop.0>
    a814:	97ffec58 	bl	5974 <fwp_rc_fresh>
    a818:	aa0003e2 	mov	x2, x0
    a81c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a820:	910363e1 	add	x1, sp, #0xd8
    a824:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a828:	52800020 	mov	w0, #0x1                   	// #1
    a82c:	a90d8be3 	stp	x3, x2, [sp, #216]
    a830:	97ffebe5 	bl	57c4 <fwp_data.part.0.constprop.0>
    a834:	91154283 	add	x3, x20, #0x550
    a838:	aa0003f5 	mov	x21, x0
    a83c:	f949d861 	ldr	x1, [x3, #5040]
    a840:	f949ec60 	ldr	x0, [x3, #5080]
    a844:	cb0102a1 	sub	x1, x21, x1
    a848:	eb00403f 	cmp	x1, x0, lsl #16
    a84c:	54000322 	b.cs	a8b0 <f0+0x3b0>  // b.hs, b.nlast
    a850:	d350fc22 	lsr	x2, x1, #16
    a854:	f949fc63 	ldr	x3, [x3, #5112]
    a858:	8b020842 	add	x2, x2, x2, lsl #2
    a85c:	d37df042 	lsl	x2, x2, #3
    a860:	8b020060 	add	x0, x3, x2
    a864:	f9401017 	ldr	x23, [x0, #32]
    a868:	b4000257 	cbz	x23, a8b0 <f0+0x3b0>
    a86c:	38626862 	ldrb	w2, [x3, x2]
    a870:	7100085f 	cmp	w2, #0x2
    a874:	5400fb60 	b.eq	c7e0 <f0+0x22e0>  // b.none
    a878:	7100045f 	cmp	w2, #0x1
    a87c:	540001a1 	b.ne	a8b0 <f0+0x3b0>  // b.any
    a880:	29430002 	ldp	w2, w0, [x0, #24]
    a884:	92403c21 	and	x1, x1, #0xffff
    a888:	9b027c21 	mul	x1, x1, x2
    a88c:	d360fc21 	lsr	x1, x1, #32
    a890:	eb00003f 	cmp	x1, x0
    a894:	540000e2 	b.cs	a8b0 <f0+0x3b0>  // b.hs, b.nlast
    a898:	8b0102f7 	add	x23, x23, x1
    a89c:	394002e0 	ldrb	w0, [x23]
    a8a0:	7103fc1f 	cmp	w0, #0xff
    a8a4:	54010940 	b.eq	c9cc <f0+0x24cc>  // b.none
    a8a8:	52800020 	mov	w0, #0x1                   	// #1
    a8ac:	390002e0 	strb	w0, [x23]
    a8b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8b4:	9103a3e1 	add	x1, sp, #0xe8
    a8b8:	52800020 	mov	w0, #0x1                   	// #1
    a8bc:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a8c0:	97ffebc1 	bl	57c4 <fwp_data.part.0.constprop.0>
    a8c4:	91154283 	add	x3, x20, #0x550
    a8c8:	aa0003f5 	mov	x21, x0
    a8cc:	f949d861 	ldr	x1, [x3, #5040]
    a8d0:	f949ec60 	ldr	x0, [x3, #5080]
    a8d4:	cb0102a1 	sub	x1, x21, x1
    a8d8:	eb00403f 	cmp	x1, x0, lsl #16
    a8dc:	54000322 	b.cs	a940 <f0+0x440>  // b.hs, b.nlast
    a8e0:	d350fc22 	lsr	x2, x1, #16
    a8e4:	f949fc63 	ldr	x3, [x3, #5112]
    a8e8:	8b020842 	add	x2, x2, x2, lsl #2
    a8ec:	d37df042 	lsl	x2, x2, #3
    a8f0:	8b020060 	add	x0, x3, x2
    a8f4:	f9401017 	ldr	x23, [x0, #32]
    a8f8:	b4000257 	cbz	x23, a940 <f0+0x440>
    a8fc:	38626862 	ldrb	w2, [x3, x2]
    a900:	7100085f 	cmp	w2, #0x2
    a904:	5400f800 	b.eq	c804 <f0+0x2304>  // b.none
    a908:	7100045f 	cmp	w2, #0x1
    a90c:	540001a1 	b.ne	a940 <f0+0x440>  // b.any
    a910:	29430002 	ldp	w2, w0, [x0, #24]
    a914:	92403c21 	and	x1, x1, #0xffff
    a918:	9b027c21 	mul	x1, x1, x2
    a91c:	d360fc21 	lsr	x1, x1, #32
    a920:	eb00003f 	cmp	x1, x0
    a924:	540000e2 	b.cs	a940 <f0+0x440>  // b.hs, b.nlast
    a928:	8b0102f7 	add	x23, x23, x1
    a92c:	394002e0 	ldrb	w0, [x23]
    a930:	7103fc1f 	cmp	w0, #0xff
    a934:	54010520 	b.eq	c9d8 <f0+0x24d8>  // b.none
    a938:	52800020 	mov	w0, #0x1                   	// #1
    a93c:	390002e0 	strb	w0, [x23]
    a940:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a944:	9103e3e1 	add	x1, sp, #0xf8
    a948:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a94c:	52800020 	mov	w0, #0x1                   	// #1
    a950:	a90fd7e2 	stp	x2, x21, [sp, #248]
    a954:	97ffeb9c 	bl	57c4 <fwp_data.part.0.constprop.0>
    a958:	91154283 	add	x3, x20, #0x550
    a95c:	aa0003f5 	mov	x21, x0
    a960:	f949d861 	ldr	x1, [x3, #5040]
    a964:	f949ec60 	ldr	x0, [x3, #5080]
    a968:	cb0102a1 	sub	x1, x21, x1
    a96c:	eb00403f 	cmp	x1, x0, lsl #16
    a970:	54000322 	b.cs	a9d4 <f0+0x4d4>  // b.hs, b.nlast
    a974:	d350fc22 	lsr	x2, x1, #16
    a978:	f949fc63 	ldr	x3, [x3, #5112]
    a97c:	8b020842 	add	x2, x2, x2, lsl #2
    a980:	d37df042 	lsl	x2, x2, #3
    a984:	8b020060 	add	x0, x3, x2
    a988:	f9401017 	ldr	x23, [x0, #32]
    a98c:	b4000257 	cbz	x23, a9d4 <f0+0x4d4>
    a990:	38626862 	ldrb	w2, [x3, x2]
    a994:	7100085f 	cmp	w2, #0x2
    a998:	5400f300 	b.eq	c7f8 <f0+0x22f8>  // b.none
    a99c:	7100045f 	cmp	w2, #0x1
    a9a0:	540001a1 	b.ne	a9d4 <f0+0x4d4>  // b.any
    a9a4:	29430002 	ldp	w2, w0, [x0, #24]
    a9a8:	92403c21 	and	x1, x1, #0xffff
    a9ac:	9b027c21 	mul	x1, x1, x2
    a9b0:	d360fc21 	lsr	x1, x1, #32
    a9b4:	eb00003f 	cmp	x1, x0
    a9b8:	540000e2 	b.cs	a9d4 <f0+0x4d4>  // b.hs, b.nlast
    a9bc:	8b0102f7 	add	x23, x23, x1
    a9c0:	394002e0 	ldrb	w0, [x23]
    a9c4:	7103fc1f 	cmp	w0, #0xff
    a9c8:	540100e0 	b.eq	c9e4 <f0+0x24e4>  // b.none
    a9cc:	52800020 	mov	w0, #0x1                   	// #1
    a9d0:	390002e0 	strb	w0, [x23]
    a9d4:	910423e1 	add	x1, sp, #0x108
    a9d8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9dc:	52800020 	mov	w0, #0x1                   	// #1
    a9e0:	a910d7f7 	stp	x23, x21, [sp, #264]
    a9e4:	97ffeb78 	bl	57c4 <fwp_data.part.0.constprop.0>
    a9e8:	97ffebe3 	bl	5974 <fwp_rc_fresh>
    a9ec:	aa0003e2 	mov	x2, x0
    a9f0:	910463e1 	add	x1, sp, #0x118
    a9f4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9f8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9fc:	52800020 	mov	w0, #0x1                   	// #1
    aa00:	a9118bf5 	stp	x21, x2, [sp, #280]
    aa04:	97ffeb70 	bl	57c4 <fwp_data.part.0.constprop.0>
    aa08:	97ffebdb 	bl	5974 <fwp_rc_fresh>
    aa0c:	aa0003e2 	mov	x2, x0
    aa10:	9104a3e1 	add	x1, sp, #0x128
    aa14:	52800020 	mov	w0, #0x1                   	// #1
    aa18:	a9128bf7 	stp	x23, x2, [sp, #296]
    aa1c:	97ffeb6a 	bl	57c4 <fwp_data.part.0.constprop.0>
    aa20:	97ffebd5 	bl	5974 <fwp_rc_fresh>
    aa24:	aa0003e2 	mov	x2, x0
    aa28:	9104e3e1 	add	x1, sp, #0x138
    aa2c:	52800020 	mov	w0, #0x1                   	// #1
    aa30:	a9138bf5 	stp	x21, x2, [sp, #312]
    aa34:	97ffeb64 	bl	57c4 <fwp_data.part.0.constprop.0>
    aa38:	91154283 	add	x3, x20, #0x550
    aa3c:	aa0003f5 	mov	x21, x0
    aa40:	f949d861 	ldr	x1, [x3, #5040]
    aa44:	f949ec60 	ldr	x0, [x3, #5080]
    aa48:	cb0102a1 	sub	x1, x21, x1
    aa4c:	eb00403f 	cmp	x1, x0, lsl #16
    aa50:	54000322 	b.cs	aab4 <f0+0x5b4>  // b.hs, b.nlast
    aa54:	d350fc22 	lsr	x2, x1, #16
    aa58:	f949fc63 	ldr	x3, [x3, #5112]
    aa5c:	8b020842 	add	x2, x2, x2, lsl #2
    aa60:	d37df042 	lsl	x2, x2, #3
    aa64:	8b020060 	add	x0, x3, x2
    aa68:	f9401017 	ldr	x23, [x0, #32]
    aa6c:	b4000257 	cbz	x23, aab4 <f0+0x5b4>
    aa70:	38626862 	ldrb	w2, [x3, x2]
    aa74:	7100085f 	cmp	w2, #0x2
    aa78:	5400ed20 	b.eq	c81c <f0+0x231c>  // b.none
    aa7c:	7100045f 	cmp	w2, #0x1
    aa80:	540001a1 	b.ne	aab4 <f0+0x5b4>  // b.any
    aa84:	29430002 	ldp	w2, w0, [x0, #24]
    aa88:	92403c21 	and	x1, x1, #0xffff
    aa8c:	9b027c21 	mul	x1, x1, x2
    aa90:	d360fc21 	lsr	x1, x1, #32
    aa94:	eb00003f 	cmp	x1, x0
    aa98:	540000e2 	b.cs	aab4 <f0+0x5b4>  // b.hs, b.nlast
    aa9c:	8b0102f7 	add	x23, x23, x1
    aaa0:	394002e0 	ldrb	w0, [x23]
    aaa4:	7103fc1f 	cmp	w0, #0xff
    aaa8:	5400fa40 	b.eq	c9f0 <f0+0x24f0>  // b.none
    aaac:	52800020 	mov	w0, #0x1                   	// #1
    aab0:	390002e0 	strb	w0, [x23]
    aab4:	910523e1 	add	x1, sp, #0x148
    aab8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	a914d7e2 	stp	x2, x21, [sp, #328]
    aac4:	97ffeb40 	bl	57c4 <fwp_data.part.0.constprop.0>
    aac8:	97ffebab 	bl	5974 <fwp_rc_fresh>
    aacc:	aa0003e2 	mov	x2, x0
    aad0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aad4:	910563e1 	add	x1, sp, #0x158
    aad8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aadc:	52800020 	mov	w0, #0x1                   	// #1
    aae0:	a9158be3 	stp	x3, x2, [sp, #344]
    aae4:	97ffeb38 	bl	57c4 <fwp_data.part.0.constprop.0>
    aae8:	91154283 	add	x3, x20, #0x550
    aaec:	aa0003f5 	mov	x21, x0
    aaf0:	f949d861 	ldr	x1, [x3, #5040]
    aaf4:	f949ec60 	ldr	x0, [x3, #5080]
    aaf8:	cb0102a1 	sub	x1, x21, x1
    aafc:	eb00403f 	cmp	x1, x0, lsl #16
    ab00:	54000322 	b.cs	ab64 <f0+0x664>  // b.hs, b.nlast
    ab04:	d350fc22 	lsr	x2, x1, #16
    ab08:	f949fc63 	ldr	x3, [x3, #5112]
    ab0c:	8b020842 	add	x2, x2, x2, lsl #2
    ab10:	d37df042 	lsl	x2, x2, #3
    ab14:	8b020060 	add	x0, x3, x2
    ab18:	f9401017 	ldr	x23, [x0, #32]
    ab1c:	b4000257 	cbz	x23, ab64 <f0+0x664>
    ab20:	38626862 	ldrb	w2, [x3, x2]
    ab24:	7100085f 	cmp	w2, #0x2
    ab28:	5400e740 	b.eq	c810 <f0+0x2310>  // b.none
    ab2c:	7100045f 	cmp	w2, #0x1
    ab30:	540001a1 	b.ne	ab64 <f0+0x664>  // b.any
    ab34:	29430002 	ldp	w2, w0, [x0, #24]
    ab38:	92403c21 	and	x1, x1, #0xffff
    ab3c:	9b027c21 	mul	x1, x1, x2
    ab40:	d360fc21 	lsr	x1, x1, #32
    ab44:	eb00003f 	cmp	x1, x0
    ab48:	540000e2 	b.cs	ab64 <f0+0x664>  // b.hs, b.nlast
    ab4c:	8b0102f7 	add	x23, x23, x1
    ab50:	394002e0 	ldrb	w0, [x23]
    ab54:	7103fc1f 	cmp	w0, #0xff
    ab58:	5400f520 	b.eq	c9fc <f0+0x24fc>  // b.none
    ab5c:	52800020 	mov	w0, #0x1                   	// #1
    ab60:	390002e0 	strb	w0, [x23]
    ab64:	9105a3e1 	add	x1, sp, #0x168
    ab68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab6c:	52800020 	mov	w0, #0x1                   	// #1
    ab70:	a916d7e2 	stp	x2, x21, [sp, #360]
    ab74:	97ffeb14 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab78:	97ffeb7f 	bl	5974 <fwp_rc_fresh>
    ab7c:	aa0003e2 	mov	x2, x0
    ab80:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab84:	9105e3e1 	add	x1, sp, #0x178
    ab88:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab8c:	52800020 	mov	w0, #0x1                   	// #1
    ab90:	a9178be3 	stp	x3, x2, [sp, #376]
    ab94:	97ffeb0c 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab98:	91154283 	add	x3, x20, #0x550
    ab9c:	aa0003f5 	mov	x21, x0
    aba0:	f949d861 	ldr	x1, [x3, #5040]
    aba4:	f949ec60 	ldr	x0, [x3, #5080]
    aba8:	cb0102a1 	sub	x1, x21, x1
    abac:	eb00403f 	cmp	x1, x0, lsl #16
    abb0:	54000322 	b.cs	ac14 <f0+0x714>  // b.hs, b.nlast
    abb4:	d350fc22 	lsr	x2, x1, #16
    abb8:	f949fc63 	ldr	x3, [x3, #5112]
    abbc:	8b020842 	add	x2, x2, x2, lsl #2
    abc0:	d37df042 	lsl	x2, x2, #3
    abc4:	8b020060 	add	x0, x3, x2
    abc8:	f9401017 	ldr	x23, [x0, #32]
    abcc:	b4000257 	cbz	x23, ac14 <f0+0x714>
    abd0:	38626862 	ldrb	w2, [x3, x2]
    abd4:	7100085f 	cmp	w2, #0x2
    abd8:	5400e8e0 	b.eq	c8f4 <f0+0x23f4>  // b.none
    abdc:	7100045f 	cmp	w2, #0x1
    abe0:	540001a1 	b.ne	ac14 <f0+0x714>  // b.any
    abe4:	29430002 	ldp	w2, w0, [x0, #24]
    abe8:	92403c21 	and	x1, x1, #0xffff
    abec:	9b027c21 	mul	x1, x1, x2
    abf0:	d360fc21 	lsr	x1, x1, #32
    abf4:	eb00003f 	cmp	x1, x0
    abf8:	540000e2 	b.cs	ac14 <f0+0x714>  // b.hs, b.nlast
    abfc:	8b0102f7 	add	x23, x23, x1
    ac00:	394002e0 	ldrb	w0, [x23]
    ac04:	7103fc1f 	cmp	w0, #0xff
    ac08:	5400f000 	b.eq	ca08 <f0+0x2508>  // b.none
    ac0c:	52800020 	mov	w0, #0x1                   	// #1
    ac10:	390002e0 	strb	w0, [x23]
    ac14:	910623e1 	add	x1, sp, #0x188
    ac18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac1c:	52800020 	mov	w0, #0x1                   	// #1
    ac20:	a918d7e2 	stp	x2, x21, [sp, #392]
    ac24:	97ffeae8 	bl	57c4 <fwp_data.part.0.constprop.0>
    ac28:	97ffeb53 	bl	5974 <fwp_rc_fresh>
    ac2c:	aa0003e2 	mov	x2, x0
    ac30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac34:	910663e1 	add	x1, sp, #0x198
    ac38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac3c:	52800020 	mov	w0, #0x1                   	// #1
    ac40:	a9198be3 	stp	x3, x2, [sp, #408]
    ac44:	97ffeae0 	bl	57c4 <fwp_data.part.0.constprop.0>
    ac48:	91154283 	add	x3, x20, #0x550
    ac4c:	aa0003f5 	mov	x21, x0
    ac50:	f949d861 	ldr	x1, [x3, #5040]
    ac54:	f949ec60 	ldr	x0, [x3, #5080]
    ac58:	cb0102a1 	sub	x1, x21, x1
    ac5c:	eb00403f 	cmp	x1, x0, lsl #16
    ac60:	54000322 	b.cs	acc4 <f0+0x7c4>  // b.hs, b.nlast
    ac64:	d350fc22 	lsr	x2, x1, #16
    ac68:	f949fc63 	ldr	x3, [x3, #5112]
    ac6c:	8b020842 	add	x2, x2, x2, lsl #2
    ac70:	d37df042 	lsl	x2, x2, #3
    ac74:	8b020060 	add	x0, x3, x2
    ac78:	f9401017 	ldr	x23, [x0, #32]
    ac7c:	b4000257 	cbz	x23, acc4 <f0+0x7c4>
    ac80:	38626862 	ldrb	w2, [x3, x2]
    ac84:	7100085f 	cmp	w2, #0x2
    ac88:	5400e300 	b.eq	c8e8 <f0+0x23e8>  // b.none
    ac8c:	7100045f 	cmp	w2, #0x1
    ac90:	540001a1 	b.ne	acc4 <f0+0x7c4>  // b.any
    ac94:	29430002 	ldp	w2, w0, [x0, #24]
    ac98:	92403c21 	and	x1, x1, #0xffff
    ac9c:	9b027c21 	mul	x1, x1, x2
    aca0:	d360fc21 	lsr	x1, x1, #32
    aca4:	eb00003f 	cmp	x1, x0
    aca8:	540000e2 	b.cs	acc4 <f0+0x7c4>  // b.hs, b.nlast
    acac:	8b0102f7 	add	x23, x23, x1
    acb0:	394002e0 	ldrb	w0, [x23]
    acb4:	7103fc1f 	cmp	w0, #0xff
    acb8:	5400eae0 	b.eq	ca14 <f0+0x2514>  // b.none
    acbc:	52800020 	mov	w0, #0x1                   	// #1
    acc0:	390002e0 	strb	w0, [x23]
    acc4:	9106a3e1 	add	x1, sp, #0x1a8
    acc8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    accc:	52800020 	mov	w0, #0x1                   	// #1
    acd0:	a91ad7f7 	stp	x23, x21, [sp, #424]
    acd4:	97ffeabc 	bl	57c4 <fwp_data.part.0.constprop.0>
    acd8:	97ffeb27 	bl	5974 <fwp_rc_fresh>
    acdc:	aa0003e2 	mov	x2, x0
    ace0:	9106e3e1 	add	x1, sp, #0x1b8
    ace4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ace8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    acec:	52800020 	mov	w0, #0x1                   	// #1
    acf0:	a91b8bf5 	stp	x21, x2, [sp, #440]
    acf4:	97ffeab4 	bl	57c4 <fwp_data.part.0.constprop.0>
    acf8:	97ffeb1f 	bl	5974 <fwp_rc_fresh>
    acfc:	aa0003e2 	mov	x2, x0
    ad00:	910723e1 	add	x1, sp, #0x1c8
    ad04:	52800020 	mov	w0, #0x1                   	// #1
    ad08:	a91c8bf7 	stp	x23, x2, [sp, #456]
    ad0c:	97ffeaae 	bl	57c4 <fwp_data.part.0.constprop.0>
    ad10:	97ffeb19 	bl	5974 <fwp_rc_fresh>
    ad14:	aa0003e2 	mov	x2, x0
    ad18:	910763e1 	add	x1, sp, #0x1d8
    ad1c:	52800020 	mov	w0, #0x1                   	// #1
    ad20:	a91d8bf5 	stp	x21, x2, [sp, #472]
    ad24:	97ffeaa8 	bl	57c4 <fwp_data.part.0.constprop.0>
    ad28:	91154283 	add	x3, x20, #0x550
    ad2c:	aa0003f5 	mov	x21, x0
    ad30:	f949d861 	ldr	x1, [x3, #5040]
    ad34:	f949ec60 	ldr	x0, [x3, #5080]
    ad38:	cb0102a1 	sub	x1, x21, x1
    ad3c:	eb00403f 	cmp	x1, x0, lsl #16
    ad40:	54000322 	b.cs	ada4 <f0+0x8a4>  // b.hs, b.nlast
    ad44:	d350fc22 	lsr	x2, x1, #16
    ad48:	f949fc63 	ldr	x3, [x3, #5112]
    ad4c:	8b020842 	add	x2, x2, x2, lsl #2
    ad50:	d37df042 	lsl	x2, x2, #3
    ad54:	8b020060 	add	x0, x3, x2
    ad58:	f9401017 	ldr	x23, [x0, #32]
    ad5c:	b4000257 	cbz	x23, ada4 <f0+0x8a4>
    ad60:	38626862 	ldrb	w2, [x3, x2]
    ad64:	7100085f 	cmp	w2, #0x2
    ad68:	5400dd20 	b.eq	c90c <f0+0x240c>  // b.none
    ad6c:	7100045f 	cmp	w2, #0x1
    ad70:	540001a1 	b.ne	ada4 <f0+0x8a4>  // b.any
    ad74:	29430002 	ldp	w2, w0, [x0, #24]
    ad78:	92403c21 	and	x1, x1, #0xffff
    ad7c:	9b027c21 	mul	x1, x1, x2
    ad80:	d360fc21 	lsr	x1, x1, #32
    ad84:	eb00003f 	cmp	x1, x0
    ad88:	540000e2 	b.cs	ada4 <f0+0x8a4>  // b.hs, b.nlast
    ad8c:	8b0102f7 	add	x23, x23, x1
    ad90:	394002e0 	ldrb	w0, [x23]
    ad94:	7103fc1f 	cmp	w0, #0xff
    ad98:	5400e440 	b.eq	ca20 <f0+0x2520>  // b.none
    ad9c:	52800020 	mov	w0, #0x1                   	// #1
    ada0:	390002e0 	strb	w0, [x23]
    ada4:	9107a3e1 	add	x1, sp, #0x1e8
    ada8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    adac:	52800020 	mov	w0, #0x1                   	// #1
    adb0:	a91ed7e2 	stp	x2, x21, [sp, #488]
    adb4:	97ffea84 	bl	57c4 <fwp_data.part.0.constprop.0>
    adb8:	97ffeaef 	bl	5974 <fwp_rc_fresh>
    adbc:	aa0003e2 	mov	x2, x0
    adc0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    adc4:	9107e3e1 	add	x1, sp, #0x1f8
    adc8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	a91f8be3 	stp	x3, x2, [sp, #504]
    add4:	97ffea7c 	bl	57c4 <fwp_data.part.0.constprop.0>
    add8:	91154283 	add	x3, x20, #0x550
    addc:	aa0003f5 	mov	x21, x0
    ade0:	f949d861 	ldr	x1, [x3, #5040]
    ade4:	f949ec60 	ldr	x0, [x3, #5080]
    ade8:	cb0102a1 	sub	x1, x21, x1
    adec:	eb00403f 	cmp	x1, x0, lsl #16
    adf0:	54000322 	b.cs	ae54 <f0+0x954>  // b.hs, b.nlast
    adf4:	d350fc22 	lsr	x2, x1, #16
    adf8:	f949fc63 	ldr	x3, [x3, #5112]
    adfc:	8b020842 	add	x2, x2, x2, lsl #2
    ae00:	d37df042 	lsl	x2, x2, #3
    ae04:	8b020060 	add	x0, x3, x2
    ae08:	f9401017 	ldr	x23, [x0, #32]
    ae0c:	b4000257 	cbz	x23, ae54 <f0+0x954>
    ae10:	38626862 	ldrb	w2, [x3, x2]
    ae14:	7100085f 	cmp	w2, #0x2
    ae18:	5400d740 	b.eq	c900 <f0+0x2400>  // b.none
    ae1c:	7100045f 	cmp	w2, #0x1
    ae20:	540001a1 	b.ne	ae54 <f0+0x954>  // b.any
    ae24:	29430002 	ldp	w2, w0, [x0, #24]
    ae28:	92403c21 	and	x1, x1, #0xffff
    ae2c:	9b027c21 	mul	x1, x1, x2
    ae30:	d360fc21 	lsr	x1, x1, #32
    ae34:	eb00003f 	cmp	x1, x0
    ae38:	540000e2 	b.cs	ae54 <f0+0x954>  // b.hs, b.nlast
    ae3c:	8b0102f7 	add	x23, x23, x1
    ae40:	394002e0 	ldrb	w0, [x23]
    ae44:	7103fc1f 	cmp	w0, #0xff
    ae48:	5400df20 	b.eq	ca2c <f0+0x252c>  // b.none
    ae4c:	52800020 	mov	w0, #0x1                   	// #1
    ae50:	390002e0 	strb	w0, [x23]
    ae54:	910823e1 	add	x1, sp, #0x208
    ae58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	f90107e2 	str	x2, [sp, #520]
    ae64:	f9010bf5 	str	x21, [sp, #528]
    ae68:	97ffea57 	bl	57c4 <fwp_data.part.0.constprop.0>
    ae6c:	97ffeac2 	bl	5974 <fwp_rc_fresh>
    ae70:	aa0003e2 	mov	x2, x0
    ae74:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae78:	910863e1 	add	x1, sp, #0x218
    ae7c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae80:	52800020 	mov	w0, #0x1                   	// #1
    ae84:	f9010fe3 	str	x3, [sp, #536]
    ae88:	f90113e2 	str	x2, [sp, #544]
    ae8c:	97ffea4e 	bl	57c4 <fwp_data.part.0.constprop.0>
    ae90:	91154283 	add	x3, x20, #0x550
    ae94:	aa0003f5 	mov	x21, x0
    ae98:	f949d861 	ldr	x1, [x3, #5040]
    ae9c:	f949ec60 	ldr	x0, [x3, #5080]
    aea0:	cb0102a1 	sub	x1, x21, x1
    aea4:	eb00403f 	cmp	x1, x0, lsl #16
    aea8:	54000322 	b.cs	af0c <f0+0xa0c>  // b.hs, b.nlast
    aeac:	d350fc22 	lsr	x2, x1, #16
    aeb0:	f949fc63 	ldr	x3, [x3, #5112]
    aeb4:	8b020842 	add	x2, x2, x2, lsl #2
    aeb8:	d37df042 	lsl	x2, x2, #3
    aebc:	8b020060 	add	x0, x3, x2
    aec0:	f9401017 	ldr	x23, [x0, #32]
    aec4:	b4000257 	cbz	x23, af0c <f0+0xa0c>
    aec8:	38626862 	ldrb	w2, [x3, x2]
    aecc:	7100085f 	cmp	w2, #0x2
    aed0:	5400d2a0 	b.eq	c924 <f0+0x2424>  // b.none
    aed4:	7100045f 	cmp	w2, #0x1
    aed8:	540001a1 	b.ne	af0c <f0+0xa0c>  // b.any
    aedc:	29430002 	ldp	w2, w0, [x0, #24]
    aee0:	92403c21 	and	x1, x1, #0xffff
    aee4:	9b027c21 	mul	x1, x1, x2
    aee8:	d360fc21 	lsr	x1, x1, #32
    aeec:	eb00003f 	cmp	x1, x0
    aef0:	540000e2 	b.cs	af0c <f0+0xa0c>  // b.hs, b.nlast
    aef4:	8b0102f7 	add	x23, x23, x1
    aef8:	394002e0 	ldrb	w0, [x23]
    aefc:	7103fc1f 	cmp	w0, #0xff
    af00:	5400d9c0 	b.eq	ca38 <f0+0x2538>  // b.none
    af04:	52800020 	mov	w0, #0x1                   	// #1
    af08:	390002e0 	strb	w0, [x23]
    af0c:	9108a3e1 	add	x1, sp, #0x228
    af10:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af14:	52800020 	mov	w0, #0x1                   	// #1
    af18:	f90117e2 	str	x2, [sp, #552]
    af1c:	f9011bf5 	str	x21, [sp, #560]
    af20:	97ffea29 	bl	57c4 <fwp_data.part.0.constprop.0>
    af24:	97ffea94 	bl	5974 <fwp_rc_fresh>
    af28:	aa0003e2 	mov	x2, x0
    af2c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af30:	9108e3e1 	add	x1, sp, #0x238
    af34:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f9011fe3 	str	x3, [sp, #568]
    af40:	f90123e2 	str	x2, [sp, #576]
    af44:	97ffea20 	bl	57c4 <fwp_data.part.0.constprop.0>
    af48:	91154283 	add	x3, x20, #0x550
    af4c:	aa0003f5 	mov	x21, x0
    af50:	f949d861 	ldr	x1, [x3, #5040]
    af54:	f949ec60 	ldr	x0, [x3, #5080]
    af58:	cb0102a1 	sub	x1, x21, x1
    af5c:	eb00403f 	cmp	x1, x0, lsl #16
    af60:	54000322 	b.cs	afc4 <f0+0xac4>  // b.hs, b.nlast
    af64:	d350fc22 	lsr	x2, x1, #16
    af68:	f949fc63 	ldr	x3, [x3, #5112]
    af6c:	8b020842 	add	x2, x2, x2, lsl #2
    af70:	d37df042 	lsl	x2, x2, #3
    af74:	8b020060 	add	x0, x3, x2
    af78:	f9401017 	ldr	x23, [x0, #32]
    af7c:	b4000257 	cbz	x23, afc4 <f0+0xac4>
    af80:	38626862 	ldrb	w2, [x3, x2]
    af84:	7100085f 	cmp	w2, #0x2
    af88:	5400cc80 	b.eq	c918 <f0+0x2418>  // b.none
    af8c:	7100045f 	cmp	w2, #0x1
    af90:	540001a1 	b.ne	afc4 <f0+0xac4>  // b.any
    af94:	29430002 	ldp	w2, w0, [x0, #24]
    af98:	92403c21 	and	x1, x1, #0xffff
    af9c:	9b027c21 	mul	x1, x1, x2
    afa0:	d360fc21 	lsr	x1, x1, #32
    afa4:	eb00003f 	cmp	x1, x0
    afa8:	540000e2 	b.cs	afc4 <f0+0xac4>  // b.hs, b.nlast
    afac:	8b0102f7 	add	x23, x23, x1
    afb0:	394002e0 	ldrb	w0, [x23]
    afb4:	7103fc1f 	cmp	w0, #0xff
    afb8:	5400d460 	b.eq	ca44 <f0+0x2544>  // b.none
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	390002e0 	strb	w0, [x23]
    afc4:	910923e1 	add	x1, sp, #0x248
    afc8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f90127f7 	str	x23, [sp, #584]
    afd4:	f9012bf5 	str	x21, [sp, #592]
    afd8:	97ffe9fb 	bl	57c4 <fwp_data.part.0.constprop.0>
    afdc:	97ffea66 	bl	5974 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afe8:	910963e1 	add	x1, sp, #0x258
    afec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f9012fe3 	str	x3, [sp, #600]
    aff8:	f90133e2 	str	x2, [sp, #608]
    affc:	97ffe9f2 	bl	57c4 <fwp_data.part.0.constprop.0>
    b000:	97ffea5d 	bl	5974 <fwp_rc_fresh>
    b004:	aa0003e2 	mov	x2, x0
    b008:	9109a3e1 	add	x1, sp, #0x268
    b00c:	52800020 	mov	w0, #0x1                   	// #1
    b010:	f90137f7 	str	x23, [sp, #616]
    b014:	f9013be2 	str	x2, [sp, #624]
    b018:	97ffe9eb 	bl	57c4 <fwp_data.part.0.constprop.0>
    b01c:	91154283 	add	x3, x20, #0x550
    b020:	aa0003f5 	mov	x21, x0
    b024:	f949d861 	ldr	x1, [x3, #5040]
    b028:	f949ec60 	ldr	x0, [x3, #5080]
    b02c:	cb0102a1 	sub	x1, x21, x1
    b030:	eb00403f 	cmp	x1, x0, lsl #16
    b034:	54000322 	b.cs	b098 <f0+0xb98>  // b.hs, b.nlast
    b038:	d350fc22 	lsr	x2, x1, #16
    b03c:	f949fc63 	ldr	x3, [x3, #5112]
    b040:	8b020842 	add	x2, x2, x2, lsl #2
    b044:	d37df042 	lsl	x2, x2, #3
    b048:	8b020060 	add	x0, x3, x2
    b04c:	f9401017 	ldr	x23, [x0, #32]
    b050:	b4000257 	cbz	x23, b098 <f0+0xb98>
    b054:	38626862 	ldrb	w2, [x3, x2]
    b058:	7100085f 	cmp	w2, #0x2
    b05c:	5400c700 	b.eq	c93c <f0+0x243c>  // b.none
    b060:	7100045f 	cmp	w2, #0x1
    b064:	540001a1 	b.ne	b098 <f0+0xb98>  // b.any
    b068:	29430002 	ldp	w2, w0, [x0, #24]
    b06c:	92403c21 	and	x1, x1, #0xffff
    b070:	9b027c21 	mul	x1, x1, x2
    b074:	d360fc21 	lsr	x1, x1, #32
    b078:	eb00003f 	cmp	x1, x0
    b07c:	540000e2 	b.cs	b098 <f0+0xb98>  // b.hs, b.nlast
    b080:	8b0102f7 	add	x23, x23, x1
    b084:	394002e0 	ldrb	w0, [x23]
    b088:	7103fc1f 	cmp	w0, #0xff
    b08c:	5400ce20 	b.eq	ca50 <f0+0x2550>  // b.none
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	390002e0 	strb	w0, [x23]
    b098:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b09c:	9109e3e1 	add	x1, sp, #0x278
    b0a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f9013fe2 	str	x2, [sp, #632]
    b0ac:	f90143f5 	str	x21, [sp, #640]
    b0b0:	97ffe9c5 	bl	57c4 <fwp_data.part.0.constprop.0>
    b0b4:	91154283 	add	x3, x20, #0x550
    b0b8:	aa0003f5 	mov	x21, x0
    b0bc:	f949d861 	ldr	x1, [x3, #5040]
    b0c0:	f949ec60 	ldr	x0, [x3, #5080]
    b0c4:	cb0102a1 	sub	x1, x21, x1
    b0c8:	eb00403f 	cmp	x1, x0, lsl #16
    b0cc:	54000322 	b.cs	b130 <f0+0xc30>  // b.hs, b.nlast
    b0d0:	d350fc22 	lsr	x2, x1, #16
    b0d4:	f949fc63 	ldr	x3, [x3, #5112]
    b0d8:	8b020842 	add	x2, x2, x2, lsl #2
    b0dc:	d37df042 	lsl	x2, x2, #3
    b0e0:	8b020060 	add	x0, x3, x2
    b0e4:	f9401017 	ldr	x23, [x0, #32]
    b0e8:	b4000257 	cbz	x23, b130 <f0+0xc30>
    b0ec:	38626862 	ldrb	w2, [x3, x2]
    b0f0:	7100085f 	cmp	w2, #0x2
    b0f4:	5400c1e0 	b.eq	c930 <f0+0x2430>  // b.none
    b0f8:	7100045f 	cmp	w2, #0x1
    b0fc:	540001a1 	b.ne	b130 <f0+0xc30>  // b.any
    b100:	29430002 	ldp	w2, w0, [x0, #24]
    b104:	92403c21 	and	x1, x1, #0xffff
    b108:	9b027c21 	mul	x1, x1, x2
    b10c:	d360fc21 	lsr	x1, x1, #32
    b110:	eb00003f 	cmp	x1, x0
    b114:	540000e2 	b.cs	b130 <f0+0xc30>  // b.hs, b.nlast
    b118:	8b0102f7 	add	x23, x23, x1
    b11c:	394002e0 	ldrb	w0, [x23]
    b120:	7103fc1f 	cmp	w0, #0xff
    b124:	5400c9c0 	b.eq	ca5c <f0+0x255c>  // b.none
    b128:	52800020 	mov	w0, #0x1                   	// #1
    b12c:	390002e0 	strb	w0, [x23]
    b130:	910a23e1 	add	x1, sp, #0x288
    b134:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	f90147f7 	str	x23, [sp, #648]
    b140:	f9014bf5 	str	x21, [sp, #656]
    b144:	97ffe9a0 	bl	57c4 <fwp_data.part.0.constprop.0>
    b148:	97ffea0b 	bl	5974 <fwp_rc_fresh>
    b14c:	aa0003e2 	mov	x2, x0
    b150:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b154:	910a63e1 	add	x1, sp, #0x298
    b158:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b15c:	52800020 	mov	w0, #0x1                   	// #1
    b160:	f9014fe3 	str	x3, [sp, #664]
    b164:	f90153e2 	str	x2, [sp, #672]
    b168:	97ffe997 	bl	57c4 <fwp_data.part.0.constprop.0>
    b16c:	97ffea02 	bl	5974 <fwp_rc_fresh>
    b170:	aa0003e2 	mov	x2, x0
    b174:	910aa3e1 	add	x1, sp, #0x2a8
    b178:	52800020 	mov	w0, #0x1                   	// #1
    b17c:	f90157f7 	str	x23, [sp, #680]
    b180:	f9015be2 	str	x2, [sp, #688]
    b184:	97ffe990 	bl	57c4 <fwp_data.part.0.constprop.0>
    b188:	91154283 	add	x3, x20, #0x550
    b18c:	aa0003f5 	mov	x21, x0
    b190:	f949d861 	ldr	x1, [x3, #5040]
    b194:	f949ec60 	ldr	x0, [x3, #5080]
    b198:	cb0102a1 	sub	x1, x21, x1
    b19c:	eb00403f 	cmp	x1, x0, lsl #16
    b1a0:	54000322 	b.cs	b204 <f0+0xd04>  // b.hs, b.nlast
    b1a4:	d350fc22 	lsr	x2, x1, #16
    b1a8:	f949fc63 	ldr	x3, [x3, #5112]
    b1ac:	8b020842 	add	x2, x2, x2, lsl #2
    b1b0:	d37df042 	lsl	x2, x2, #3
    b1b4:	8b020060 	add	x0, x3, x2
    b1b8:	f9401017 	ldr	x23, [x0, #32]
    b1bc:	b4000257 	cbz	x23, b204 <f0+0xd04>
    b1c0:	38626862 	ldrb	w2, [x3, x2]
    b1c4:	7100085f 	cmp	w2, #0x2
    b1c8:	5400bc60 	b.eq	c954 <f0+0x2454>  // b.none
    b1cc:	7100045f 	cmp	w2, #0x1
    b1d0:	540001a1 	b.ne	b204 <f0+0xd04>  // b.any
    b1d4:	29430002 	ldp	w2, w0, [x0, #24]
    b1d8:	92403c21 	and	x1, x1, #0xffff
    b1dc:	9b027c21 	mul	x1, x1, x2
    b1e0:	d360fc21 	lsr	x1, x1, #32
    b1e4:	eb00003f 	cmp	x1, x0
    b1e8:	540000e2 	b.cs	b204 <f0+0xd04>  // b.hs, b.nlast
    b1ec:	8b0102f7 	add	x23, x23, x1
    b1f0:	394002e0 	ldrb	w0, [x23]
    b1f4:	7103fc1f 	cmp	w0, #0xff
    b1f8:	5400c380 	b.eq	ca68 <f0+0x2568>  // b.none
    b1fc:	52800020 	mov	w0, #0x1                   	// #1
    b200:	390002e0 	strb	w0, [x23]
    b204:	910ae3e1 	add	x1, sp, #0x2b8
    b208:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b20c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b210:	52800020 	mov	w0, #0x1                   	// #1
    b214:	f9015ff7 	str	x23, [sp, #696]
    b218:	f90163f5 	str	x21, [sp, #704]
    b21c:	97ffe96a 	bl	57c4 <fwp_data.part.0.constprop.0>
    b220:	97ffe9d5 	bl	5974 <fwp_rc_fresh>
    b224:	aa0003e2 	mov	x2, x0
    b228:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b22c:	910b23e1 	add	x1, sp, #0x2c8
    b230:	52800020 	mov	w0, #0x1                   	// #1
    b234:	f90167e3 	str	x3, [sp, #712]
    b238:	f9016be2 	str	x2, [sp, #720]
    b23c:	97ffe962 	bl	57c4 <fwp_data.part.0.constprop.0>
    b240:	97ffe9cd 	bl	5974 <fwp_rc_fresh>
    b244:	aa0003e2 	mov	x2, x0
    b248:	910b63e1 	add	x1, sp, #0x2d8
    b24c:	52800020 	mov	w0, #0x1                   	// #1
    b250:	f9016ff7 	str	x23, [sp, #728]
    b254:	f90173e2 	str	x2, [sp, #736]
    b258:	97ffe95b 	bl	57c4 <fwp_data.part.0.constprop.0>
    b25c:	91154283 	add	x3, x20, #0x550
    b260:	aa0003f5 	mov	x21, x0
    b264:	f949d861 	ldr	x1, [x3, #5040]
    b268:	f949ec60 	ldr	x0, [x3, #5080]
    b26c:	cb0102a1 	sub	x1, x21, x1
    b270:	eb00403f 	cmp	x1, x0, lsl #16
    b274:	54000322 	b.cs	b2d8 <f0+0xdd8>  // b.hs, b.nlast
    b278:	d350fc22 	lsr	x2, x1, #16
    b27c:	f949fc63 	ldr	x3, [x3, #5112]
    b280:	8b020842 	add	x2, x2, x2, lsl #2
    b284:	d37df042 	lsl	x2, x2, #3
    b288:	8b020060 	add	x0, x3, x2
    b28c:	f9401017 	ldr	x23, [x0, #32]
    b290:	b4000257 	cbz	x23, b2d8 <f0+0xdd8>
    b294:	38626862 	ldrb	w2, [x3, x2]
    b298:	7100085f 	cmp	w2, #0x2
    b29c:	5400b560 	b.eq	c948 <f0+0x2448>  // b.none
    b2a0:	7100045f 	cmp	w2, #0x1
    b2a4:	540001a1 	b.ne	b2d8 <f0+0xdd8>  // b.any
    b2a8:	29430002 	ldp	w2, w0, [x0, #24]
    b2ac:	92403c21 	and	x1, x1, #0xffff
    b2b0:	9b027c21 	mul	x1, x1, x2
    b2b4:	d360fc21 	lsr	x1, x1, #32
    b2b8:	eb00003f 	cmp	x1, x0
    b2bc:	540000e2 	b.cs	b2d8 <f0+0xdd8>  // b.hs, b.nlast
    b2c0:	8b0102f7 	add	x23, x23, x1
    b2c4:	394002e0 	ldrb	w0, [x23]
    b2c8:	7103fc1f 	cmp	w0, #0xff
    b2cc:	5400bd40 	b.eq	ca74 <f0+0x2574>  // b.none
    b2d0:	52800020 	mov	w0, #0x1                   	// #1
    b2d4:	390002e0 	strb	w0, [x23]
    b2d8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2dc:	910ba3e1 	add	x1, sp, #0x2e8
    b2e0:	52800020 	mov	w0, #0x1                   	// #1
    b2e4:	f90177e2 	str	x2, [sp, #744]
    b2e8:	f9017bf5 	str	x21, [sp, #752]
    b2ec:	97ffe936 	bl	57c4 <fwp_data.part.0.constprop.0>
    b2f0:	91154283 	add	x3, x20, #0x550
    b2f4:	aa0003f5 	mov	x21, x0
    b2f8:	f949d861 	ldr	x1, [x3, #5040]
    b2fc:	f949ec60 	ldr	x0, [x3, #5080]
    b300:	cb0102a1 	sub	x1, x21, x1
    b304:	eb00403f 	cmp	x1, x0, lsl #16
    b308:	54000322 	b.cs	b36c <f0+0xe6c>  // b.hs, b.nlast
    b30c:	d350fc22 	lsr	x2, x1, #16
    b310:	f949fc63 	ldr	x3, [x3, #5112]
    b314:	8b020842 	add	x2, x2, x2, lsl #2
    b318:	d37df042 	lsl	x2, x2, #3
    b31c:	8b020060 	add	x0, x3, x2
    b320:	f9401017 	ldr	x23, [x0, #32]
    b324:	b4000257 	cbz	x23, b36c <f0+0xe6c>
    b328:	38626862 	ldrb	w2, [x3, x2]
    b32c:	7100085f 	cmp	w2, #0x2
    b330:	5400b1e0 	b.eq	c96c <f0+0x246c>  // b.none
    b334:	7100045f 	cmp	w2, #0x1
    b338:	540001a1 	b.ne	b36c <f0+0xe6c>  // b.any
    b33c:	29430002 	ldp	w2, w0, [x0, #24]
    b340:	92403c21 	and	x1, x1, #0xffff
    b344:	9b027c21 	mul	x1, x1, x2
    b348:	d360fc21 	lsr	x1, x1, #32
    b34c:	eb00003f 	cmp	x1, x0
    b350:	540000e2 	b.cs	b36c <f0+0xe6c>  // b.hs, b.nlast
    b354:	8b0102f7 	add	x23, x23, x1
    b358:	394002e0 	ldrb	w0, [x23]
    b35c:	7103fc1f 	cmp	w0, #0xff
    b360:	5400b900 	b.eq	ca80 <f0+0x2580>  // b.none
    b364:	52800020 	mov	w0, #0x1                   	// #1
    b368:	390002e0 	strb	w0, [x23]
    b36c:	910be3e1 	add	x1, sp, #0x2f8
    b370:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b374:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b378:	52800020 	mov	w0, #0x1                   	// #1
    b37c:	f9017ff7 	str	x23, [sp, #760]
    b380:	f90183f5 	str	x21, [sp, #768]
    b384:	97ffe910 	bl	57c4 <fwp_data.part.0.constprop.0>
    b388:	97ffe97b 	bl	5974 <fwp_rc_fresh>
    b38c:	aa0003e2 	mov	x2, x0
    b390:	910c23e1 	add	x1, sp, #0x308
    b394:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b398:	52800020 	mov	w0, #0x1                   	// #1
    b39c:	f90187f5 	str	x21, [sp, #776]
    b3a0:	f9018be2 	str	x2, [sp, #784]
    b3a4:	97ffe908 	bl	57c4 <fwp_data.part.0.constprop.0>
    b3a8:	97ffe973 	bl	5974 <fwp_rc_fresh>
    b3ac:	aa0003e2 	mov	x2, x0
    b3b0:	910c63e1 	add	x1, sp, #0x318
    b3b4:	52800020 	mov	w0, #0x1                   	// #1
    b3b8:	f9018ff7 	str	x23, [sp, #792]
    b3bc:	f90193e2 	str	x2, [sp, #800]
    b3c0:	97ffe901 	bl	57c4 <fwp_data.part.0.constprop.0>
    b3c4:	97ffe96c 	bl	5974 <fwp_rc_fresh>
    b3c8:	aa0003e2 	mov	x2, x0
    b3cc:	910ca3e1 	add	x1, sp, #0x328
    b3d0:	52800020 	mov	w0, #0x1                   	// #1
    b3d4:	f90197f5 	str	x21, [sp, #808]
    b3d8:	f9019be2 	str	x2, [sp, #816]
    b3dc:	97ffe8fa 	bl	57c4 <fwp_data.part.0.constprop.0>
    b3e0:	97ffe965 	bl	5974 <fwp_rc_fresh>
    b3e4:	aa0003e2 	mov	x2, x0
    b3e8:	910ce3e1 	add	x1, sp, #0x338
    b3ec:	52800020 	mov	w0, #0x1                   	// #1
    b3f0:	f9019ff7 	str	x23, [sp, #824]
    b3f4:	f901a3e2 	str	x2, [sp, #832]
    b3f8:	97ffe8f3 	bl	57c4 <fwp_data.part.0.constprop.0>
    b3fc:	97ffe95e 	bl	5974 <fwp_rc_fresh>
    b400:	aa0003e2 	mov	x2, x0
    b404:	910d23e1 	add	x1, sp, #0x348
    b408:	52800020 	mov	w0, #0x1                   	// #1
    b40c:	f901a7f5 	str	x21, [sp, #840]
    b410:	f901abe2 	str	x2, [sp, #848]
    b414:	97ffe8ec 	bl	57c4 <fwp_data.part.0.constprop.0>
    b418:	97ffe957 	bl	5974 <fwp_rc_fresh>
    b41c:	aa0003e2 	mov	x2, x0
    b420:	910d63e1 	add	x1, sp, #0x358
    b424:	52800020 	mov	w0, #0x1                   	// #1
    b428:	f901aff7 	str	x23, [sp, #856]
    b42c:	f901b3e2 	str	x2, [sp, #864]
    b430:	97ffe8e5 	bl	57c4 <fwp_data.part.0.constprop.0>
    b434:	97ffe950 	bl	5974 <fwp_rc_fresh>
    b438:	aa0003e2 	mov	x2, x0
    b43c:	910da3e1 	add	x1, sp, #0x368
    b440:	52800020 	mov	w0, #0x1                   	// #1
    b444:	f901b7f5 	str	x21, [sp, #872]
    b448:	f901bbe2 	str	x2, [sp, #880]
    b44c:	97ffe8de 	bl	57c4 <fwp_data.part.0.constprop.0>
    b450:	97ffe949 	bl	5974 <fwp_rc_fresh>
    b454:	aa0003e2 	mov	x2, x0
    b458:	910de3e1 	add	x1, sp, #0x378
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	f901bff7 	str	x23, [sp, #888]
    b464:	f901c3e2 	str	x2, [sp, #896]
    b468:	97ffe8d7 	bl	57c4 <fwp_data.part.0.constprop.0>
    b46c:	97ffe942 	bl	5974 <fwp_rc_fresh>
    b470:	aa0003e2 	mov	x2, x0
    b474:	910e23e1 	add	x1, sp, #0x388
    b478:	52800020 	mov	w0, #0x1                   	// #1
    b47c:	f901c7f5 	str	x21, [sp, #904]
    b480:	f901cbe2 	str	x2, [sp, #912]
    b484:	97ffe8d0 	bl	57c4 <fwp_data.part.0.constprop.0>
    b488:	91154283 	add	x3, x20, #0x550
    b48c:	aa0003f5 	mov	x21, x0
    b490:	f949d861 	ldr	x1, [x3, #5040]
    b494:	f949ec60 	ldr	x0, [x3, #5080]
    b498:	cb0102a1 	sub	x1, x21, x1
    b49c:	eb00403f 	cmp	x1, x0, lsl #16
    b4a0:	54000322 	b.cs	b504 <f0+0x1004>  // b.hs, b.nlast
    b4a4:	d350fc22 	lsr	x2, x1, #16
    b4a8:	f949fc63 	ldr	x3, [x3, #5112]
    b4ac:	8b020842 	add	x2, x2, x2, lsl #2
    b4b0:	d37df042 	lsl	x2, x2, #3
    b4b4:	8b020060 	add	x0, x3, x2
    b4b8:	f9401017 	ldr	x23, [x0, #32]
    b4bc:	b4000257 	cbz	x23, b504 <f0+0x1004>
    b4c0:	38626862 	ldrb	w2, [x3, x2]
    b4c4:	7100085f 	cmp	w2, #0x2
    b4c8:	5400a4c0 	b.eq	c960 <f0+0x2460>  // b.none
    b4cc:	7100045f 	cmp	w2, #0x1
    b4d0:	540001a1 	b.ne	b504 <f0+0x1004>  // b.any
    b4d4:	29430002 	ldp	w2, w0, [x0, #24]
    b4d8:	92403c21 	and	x1, x1, #0xffff
    b4dc:	9b027c21 	mul	x1, x1, x2
    b4e0:	d360fc21 	lsr	x1, x1, #32
    b4e4:	eb00003f 	cmp	x1, x0
    b4e8:	540000e2 	b.cs	b504 <f0+0x1004>  // b.hs, b.nlast
    b4ec:	8b0102f7 	add	x23, x23, x1
    b4f0:	394002e0 	ldrb	w0, [x23]
    b4f4:	7103fc1f 	cmp	w0, #0xff
    b4f8:	5400aca0 	b.eq	ca8c <f0+0x258c>  // b.none
    b4fc:	52800020 	mov	w0, #0x1                   	// #1
    b500:	390002e0 	strb	w0, [x23]
    b504:	910e63e1 	add	x1, sp, #0x398
    b508:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b50c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b510:	52800020 	mov	w0, #0x1                   	// #1
    b514:	f901cff7 	str	x23, [sp, #920]
    b518:	f901d3f5 	str	x21, [sp, #928]
    b51c:	97ffe8aa 	bl	57c4 <fwp_data.part.0.constprop.0>
    b520:	97ffe915 	bl	5974 <fwp_rc_fresh>
    b524:	aa0003e2 	mov	x2, x0
    b528:	910ea3e1 	add	x1, sp, #0x3a8
    b52c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b530:	52800020 	mov	w0, #0x1                   	// #1
    b534:	f901d7f5 	str	x21, [sp, #936]
    b538:	f901dbe2 	str	x2, [sp, #944]
    b53c:	97ffe8a2 	bl	57c4 <fwp_data.part.0.constprop.0>
    b540:	97ffe90d 	bl	5974 <fwp_rc_fresh>
    b544:	aa0003e2 	mov	x2, x0
    b548:	910ee3e1 	add	x1, sp, #0x3b8
    b54c:	52800020 	mov	w0, #0x1                   	// #1
    b550:	f901dff7 	str	x23, [sp, #952]
    b554:	f901e3e2 	str	x2, [sp, #960]
    b558:	97ffe89b 	bl	57c4 <fwp_data.part.0.constprop.0>
    b55c:	97ffe906 	bl	5974 <fwp_rc_fresh>
    b560:	aa0003e2 	mov	x2, x0
    b564:	910f23e1 	add	x1, sp, #0x3c8
    b568:	52800020 	mov	w0, #0x1                   	// #1
    b56c:	f901e7f5 	str	x21, [sp, #968]
    b570:	f901ebe2 	str	x2, [sp, #976]
    b574:	97ffe894 	bl	57c4 <fwp_data.part.0.constprop.0>
    b578:	97ffe8ff 	bl	5974 <fwp_rc_fresh>
    b57c:	aa0003e2 	mov	x2, x0
    b580:	910f63e1 	add	x1, sp, #0x3d8
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	f901eff7 	str	x23, [sp, #984]
    b58c:	f901f3e2 	str	x2, [sp, #992]
    b590:	97ffe88d 	bl	57c4 <fwp_data.part.0.constprop.0>
    b594:	97ffe8f8 	bl	5974 <fwp_rc_fresh>
    b598:	aa0003e2 	mov	x2, x0
    b59c:	910fa3e1 	add	x1, sp, #0x3e8
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	f901f7f5 	str	x21, [sp, #1000]
    b5a8:	f901fbe2 	str	x2, [sp, #1008]
    b5ac:	97ffe886 	bl	57c4 <fwp_data.part.0.constprop.0>
    b5b0:	91154283 	add	x3, x20, #0x550
    b5b4:	aa0003f5 	mov	x21, x0
    b5b8:	f949d861 	ldr	x1, [x3, #5040]
    b5bc:	f949ec60 	ldr	x0, [x3, #5080]
    b5c0:	cb0102a1 	sub	x1, x21, x1
    b5c4:	eb00403f 	cmp	x1, x0, lsl #16
    b5c8:	54000322 	b.cs	b62c <f0+0x112c>  // b.hs, b.nlast
    b5cc:	d350fc22 	lsr	x2, x1, #16
    b5d0:	f949fc63 	ldr	x3, [x3, #5112]
    b5d4:	8b020842 	add	x2, x2, x2, lsl #2
    b5d8:	d37df042 	lsl	x2, x2, #3
    b5dc:	8b020060 	add	x0, x3, x2
    b5e0:	f9401017 	ldr	x23, [x0, #32]
    b5e4:	b4000257 	cbz	x23, b62c <f0+0x112c>
    b5e8:	38626862 	ldrb	w2, [x3, x2]
    b5ec:	7100085f 	cmp	w2, #0x2
    b5f0:	54009ca0 	b.eq	c984 <f0+0x2484>  // b.none
    b5f4:	7100045f 	cmp	w2, #0x1
    b5f8:	540001a1 	b.ne	b62c <f0+0x112c>  // b.any
    b5fc:	29430002 	ldp	w2, w0, [x0, #24]
    b600:	92403c21 	and	x1, x1, #0xffff
    b604:	9b027c21 	mul	x1, x1, x2
    b608:	d360fc21 	lsr	x1, x1, #32
    b60c:	eb00003f 	cmp	x1, x0
    b610:	540000e2 	b.cs	b62c <f0+0x112c>  // b.hs, b.nlast
    b614:	8b0102f7 	add	x23, x23, x1
    b618:	394002e0 	ldrb	w0, [x23]
    b61c:	7103fc1f 	cmp	w0, #0xff
    b620:	5400a3c0 	b.eq	ca98 <f0+0x2598>  // b.none
    b624:	52800020 	mov	w0, #0x1                   	// #1
    b628:	390002e0 	strb	w0, [x23]
    b62c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b630:	910fe3e1 	add	x1, sp, #0x3f8
    b634:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b638:	52800020 	mov	w0, #0x1                   	// #1
    b63c:	f901ffe2 	str	x2, [sp, #1016]
    b640:	f90203f5 	str	x21, [sp, #1024]
    b644:	97ffe860 	bl	57c4 <fwp_data.part.0.constprop.0>
    b648:	91154283 	add	x3, x20, #0x550
    b64c:	aa0003f7 	mov	x23, x0
    b650:	f949d861 	ldr	x1, [x3, #5040]
    b654:	f949ec60 	ldr	x0, [x3, #5080]
    b658:	cb0102e1 	sub	x1, x23, x1
    b65c:	eb00403f 	cmp	x1, x0, lsl #16
    b660:	54000322 	b.cs	b6c4 <f0+0x11c4>  // b.hs, b.nlast
    b664:	d350fc22 	lsr	x2, x1, #16
    b668:	f949fc63 	ldr	x3, [x3, #5112]
    b66c:	8b020842 	add	x2, x2, x2, lsl #2
    b670:	d37df042 	lsl	x2, x2, #3
    b674:	8b020060 	add	x0, x3, x2
    b678:	f9401015 	ldr	x21, [x0, #32]
    b67c:	b4000255 	cbz	x21, b6c4 <f0+0x11c4>
    b680:	38626862 	ldrb	w2, [x3, x2]
    b684:	7100085f 	cmp	w2, #0x2
    b688:	54009780 	b.eq	c978 <f0+0x2478>  // b.none
    b68c:	7100045f 	cmp	w2, #0x1
    b690:	540001a1 	b.ne	b6c4 <f0+0x11c4>  // b.any
    b694:	29430002 	ldp	w2, w0, [x0, #24]
    b698:	92403c21 	and	x1, x1, #0xffff
    b69c:	9b027c21 	mul	x1, x1, x2
    b6a0:	d360fc21 	lsr	x1, x1, #32
    b6a4:	eb00003f 	cmp	x1, x0
    b6a8:	540000e2 	b.cs	b6c4 <f0+0x11c4>  // b.hs, b.nlast
    b6ac:	8b0102b5 	add	x21, x21, x1
    b6b0:	394002a0 	ldrb	w0, [x21]
    b6b4:	7103fc1f 	cmp	w0, #0xff
    b6b8:	54009f60 	b.eq	caa4 <f0+0x25a4>  // b.none
    b6bc:	52800020 	mov	w0, #0x1                   	// #1
    b6c0:	390002a0 	strb	w0, [x21]
    b6c4:	911023e1 	add	x1, sp, #0x408
    b6c8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	f90207f5 	str	x21, [sp, #1032]
    b6d4:	f9020bf7 	str	x23, [sp, #1040]
    b6d8:	97ffe83b 	bl	57c4 <fwp_data.part.0.constprop.0>
    b6dc:	97ffe8a6 	bl	5974 <fwp_rc_fresh>
    b6e0:	aa0003e2 	mov	x2, x0
    b6e4:	911063e1 	add	x1, sp, #0x418
    b6e8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b6ec:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b6f0:	52800020 	mov	w0, #0x1                   	// #1
    b6f4:	f9020ff7 	str	x23, [sp, #1048]
    b6f8:	f90213e2 	str	x2, [sp, #1056]
    b6fc:	97ffe832 	bl	57c4 <fwp_data.part.0.constprop.0>
    b700:	97ffe89d 	bl	5974 <fwp_rc_fresh>
    b704:	aa0003e2 	mov	x2, x0
    b708:	9110a3e1 	add	x1, sp, #0x428
    b70c:	52800020 	mov	w0, #0x1                   	// #1
    b710:	f90217f5 	str	x21, [sp, #1064]
    b714:	f9021be2 	str	x2, [sp, #1072]
    b718:	97ffe82b 	bl	57c4 <fwp_data.part.0.constprop.0>
    b71c:	97ffe896 	bl	5974 <fwp_rc_fresh>
    b720:	aa0003e2 	mov	x2, x0
    b724:	9110e3e1 	add	x1, sp, #0x438
    b728:	52800020 	mov	w0, #0x1                   	// #1
    b72c:	f9021ff7 	str	x23, [sp, #1080]
    b730:	f90223e2 	str	x2, [sp, #1088]
    b734:	97ffe824 	bl	57c4 <fwp_data.part.0.constprop.0>
    b738:	97ffe88f 	bl	5974 <fwp_rc_fresh>
    b73c:	aa0003e2 	mov	x2, x0
    b740:	911123e1 	add	x1, sp, #0x448
    b744:	52800020 	mov	w0, #0x1                   	// #1
    b748:	f90227f5 	str	x21, [sp, #1096]
    b74c:	f9022be2 	str	x2, [sp, #1104]
    b750:	97ffe81d 	bl	57c4 <fwp_data.part.0.constprop.0>
    b754:	97ffe888 	bl	5974 <fwp_rc_fresh>
    b758:	aa0003e2 	mov	x2, x0
    b75c:	911163e1 	add	x1, sp, #0x458
    b760:	52800020 	mov	w0, #0x1                   	// #1
    b764:	f9022ff7 	str	x23, [sp, #1112]
    b768:	f90233e2 	str	x2, [sp, #1120]
    b76c:	97ffe816 	bl	57c4 <fwp_data.part.0.constprop.0>
    b770:	97ffe881 	bl	5974 <fwp_rc_fresh>
    b774:	aa0003e2 	mov	x2, x0
    b778:	9111a3e1 	add	x1, sp, #0x468
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f90237f5 	str	x21, [sp, #1128]
    b784:	f9023be2 	str	x2, [sp, #1136]
    b788:	97ffe80f 	bl	57c4 <fwp_data.part.0.constprop.0>
    b78c:	91154283 	add	x3, x20, #0x550
    b790:	aa0003f5 	mov	x21, x0
    b794:	f949d861 	ldr	x1, [x3, #5040]
    b798:	f949ec60 	ldr	x0, [x3, #5080]
    b79c:	cb0102a1 	sub	x1, x21, x1
    b7a0:	eb00403f 	cmp	x1, x0, lsl #16
    b7a4:	54000322 	b.cs	b808 <f0+0x1308>  // b.hs, b.nlast
    b7a8:	d350fc22 	lsr	x2, x1, #16
    b7ac:	f949fc63 	ldr	x3, [x3, #5112]
    b7b0:	8b020842 	add	x2, x2, x2, lsl #2
    b7b4:	d37df042 	lsl	x2, x2, #3
    b7b8:	8b020060 	add	x0, x3, x2
    b7bc:	f9401017 	ldr	x23, [x0, #32]
    b7c0:	b4000257 	cbz	x23, b808 <f0+0x1308>
    b7c4:	38626862 	ldrb	w2, [x3, x2]
    b7c8:	7100085f 	cmp	w2, #0x2
    b7cc:	54008e80 	b.eq	c99c <f0+0x249c>  // b.none
    b7d0:	7100045f 	cmp	w2, #0x1
    b7d4:	540001a1 	b.ne	b808 <f0+0x1308>  // b.any
    b7d8:	29430002 	ldp	w2, w0, [x0, #24]
    b7dc:	92403c21 	and	x1, x1, #0xffff
    b7e0:	9b027c21 	mul	x1, x1, x2
    b7e4:	d360fc21 	lsr	x1, x1, #32
    b7e8:	eb00003f 	cmp	x1, x0
    b7ec:	540000e2 	b.cs	b808 <f0+0x1308>  // b.hs, b.nlast
    b7f0:	8b0102f7 	add	x23, x23, x1
    b7f4:	394002e0 	ldrb	w0, [x23]
    b7f8:	7103fc1f 	cmp	w0, #0xff
    b7fc:	540095a0 	b.eq	cab0 <f0+0x25b0>  // b.none
    b800:	52800020 	mov	w0, #0x1                   	// #1
    b804:	390002e0 	strb	w0, [x23]
    b808:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b80c:	9111e3e1 	add	x1, sp, #0x478
    b810:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	f9023fe2 	str	x2, [sp, #1144]
    b81c:	f90243f5 	str	x21, [sp, #1152]
    b820:	97ffe7e9 	bl	57c4 <fwp_data.part.0.constprop.0>
    b824:	91154283 	add	x3, x20, #0x550
    b828:	aa0003f7 	mov	x23, x0
    b82c:	f949d861 	ldr	x1, [x3, #5040]
    b830:	f949ec60 	ldr	x0, [x3, #5080]
    b834:	cb0102e1 	sub	x1, x23, x1
    b838:	eb00403f 	cmp	x1, x0, lsl #16
    b83c:	54000322 	b.cs	b8a0 <f0+0x13a0>  // b.hs, b.nlast
    b840:	d350fc22 	lsr	x2, x1, #16
    b844:	f949fc63 	ldr	x3, [x3, #5112]
    b848:	8b020842 	add	x2, x2, x2, lsl #2
    b84c:	d37df042 	lsl	x2, x2, #3
    b850:	8b020060 	add	x0, x3, x2
    b854:	f9401015 	ldr	x21, [x0, #32]
    b858:	b4000255 	cbz	x21, b8a0 <f0+0x13a0>
    b85c:	38626862 	ldrb	w2, [x3, x2]
    b860:	7100085f 	cmp	w2, #0x2
    b864:	54008960 	b.eq	c990 <f0+0x2490>  // b.none
    b868:	7100045f 	cmp	w2, #0x1
    b86c:	540001a1 	b.ne	b8a0 <f0+0x13a0>  // b.any
    b870:	29430002 	ldp	w2, w0, [x0, #24]
    b874:	92403c21 	and	x1, x1, #0xffff
    b878:	9b027c21 	mul	x1, x1, x2
    b87c:	d360fc21 	lsr	x1, x1, #32
    b880:	eb00003f 	cmp	x1, x0
    b884:	540000e2 	b.cs	b8a0 <f0+0x13a0>  // b.hs, b.nlast
    b888:	8b0102b5 	add	x21, x21, x1
    b88c:	394002a0 	ldrb	w0, [x21]
    b890:	7103fc1f 	cmp	w0, #0xff
    b894:	54009140 	b.eq	cabc <f0+0x25bc>  // b.none
    b898:	52800020 	mov	w0, #0x1                   	// #1
    b89c:	390002a0 	strb	w0, [x21]
    b8a0:	911223e1 	add	x1, sp, #0x488
    b8a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b8a8:	52800020 	mov	w0, #0x1                   	// #1
    b8ac:	f90247f5 	str	x21, [sp, #1160]
    b8b0:	f9024bf7 	str	x23, [sp, #1168]
    b8b4:	97ffe7c4 	bl	57c4 <fwp_data.part.0.constprop.0>
    b8b8:	97ffe82f 	bl	5974 <fwp_rc_fresh>
    b8bc:	aa0003e2 	mov	x2, x0
    b8c0:	911263e1 	add	x1, sp, #0x498
    b8c4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b8c8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	f9024ff7 	str	x23, [sp, #1176]
    b8d4:	f90253e2 	str	x2, [sp, #1184]
    b8d8:	97ffe7bb 	bl	57c4 <fwp_data.part.0.constprop.0>
    b8dc:	97ffe826 	bl	5974 <fwp_rc_fresh>
    b8e0:	aa0003e2 	mov	x2, x0
    b8e4:	9112a3e1 	add	x1, sp, #0x4a8
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f90257f5 	str	x21, [sp, #1192]
    b8f0:	f9025be2 	str	x2, [sp, #1200]
    b8f4:	97ffe7b4 	bl	57c4 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe81f 	bl	5974 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	9112e3e1 	add	x1, sp, #0x4b8
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f9025ff7 	str	x23, [sp, #1208]
    b90c:	f90263e2 	str	x2, [sp, #1216]
    b910:	97ffe7ad 	bl	57c4 <fwp_data.part.0.constprop.0>
    b914:	97ffe818 	bl	5974 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	911323e1 	add	x1, sp, #0x4c8
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	f90267f5 	str	x21, [sp, #1224]
    b928:	f9026be2 	str	x2, [sp, #1232]
    b92c:	97ffe7a6 	bl	57c4 <fwp_data.part.0.constprop.0>
    b930:	97ffe811 	bl	5974 <fwp_rc_fresh>
    b934:	aa0003e2 	mov	x2, x0
    b938:	911363e1 	add	x1, sp, #0x4d8
    b93c:	52800020 	mov	w0, #0x1                   	// #1
    b940:	f9026ff7 	str	x23, [sp, #1240]
    b944:	f90273e2 	str	x2, [sp, #1248]
    b948:	97ffe79f 	bl	57c4 <fwp_data.part.0.constprop.0>
    b94c:	97ffe80a 	bl	5974 <fwp_rc_fresh>
    b950:	aa0003e2 	mov	x2, x0
    b954:	9113a3e1 	add	x1, sp, #0x4e8
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f90277f5 	str	x21, [sp, #1256]
    b960:	f9027be2 	str	x2, [sp, #1264]
    b964:	97ffe798 	bl	57c4 <fwp_data.part.0.constprop.0>
    b968:	91154283 	add	x3, x20, #0x550
    b96c:	aa0003f5 	mov	x21, x0
    b970:	f949d861 	ldr	x1, [x3, #5040]
    b974:	f949ec60 	ldr	x0, [x3, #5080]
    b978:	cb0102a1 	sub	x1, x21, x1
    b97c:	eb00403f 	cmp	x1, x0, lsl #16
    b980:	54000322 	b.cs	b9e4 <f0+0x14e4>  // b.hs, b.nlast
    b984:	d350fc22 	lsr	x2, x1, #16
    b988:	f949fc63 	ldr	x3, [x3, #5112]
    b98c:	8b020842 	add	x2, x2, x2, lsl #2
    b990:	d37df042 	lsl	x2, x2, #3
    b994:	8b020060 	add	x0, x3, x2
    b998:	f9401017 	ldr	x23, [x0, #32]
    b99c:	b4000257 	cbz	x23, b9e4 <f0+0x14e4>
    b9a0:	38626862 	ldrb	w2, [x3, x2]
    b9a4:	7100085f 	cmp	w2, #0x2
    b9a8:	54007460 	b.eq	c834 <f0+0x2334>  // b.none
    b9ac:	7100045f 	cmp	w2, #0x1
    b9b0:	540001a1 	b.ne	b9e4 <f0+0x14e4>  // b.any
    b9b4:	29430002 	ldp	w2, w0, [x0, #24]
    b9b8:	92403c21 	and	x1, x1, #0xffff
    b9bc:	9b027c21 	mul	x1, x1, x2
    b9c0:	d360fc21 	lsr	x1, x1, #32
    b9c4:	eb00003f 	cmp	x1, x0
    b9c8:	540000e2 	b.cs	b9e4 <f0+0x14e4>  // b.hs, b.nlast
    b9cc:	8b0102f7 	add	x23, x23, x1
    b9d0:	394002e0 	ldrb	w0, [x23]
    b9d4:	7103fc1f 	cmp	w0, #0xff
    b9d8:	54008780 	b.eq	cac8 <f0+0x25c8>  // b.none
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	390002e0 	strb	w0, [x23]
    b9e4:	9113e3e1 	add	x1, sp, #0x4f8
    b9e8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b9ec:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b9f0:	52800020 	mov	w0, #0x1                   	// #1
    b9f4:	f9027ff7 	str	x23, [sp, #1272]
    b9f8:	f90283f5 	str	x21, [sp, #1280]
    b9fc:	97ffe772 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba00:	97ffe7dd 	bl	5974 <fwp_rc_fresh>
    ba04:	aa0003e2 	mov	x2, x0
    ba08:	911423e1 	add	x1, sp, #0x508
    ba0c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba10:	52800020 	mov	w0, #0x1                   	// #1
    ba14:	f90287f5 	str	x21, [sp, #1288]
    ba18:	f9028be2 	str	x2, [sp, #1296]
    ba1c:	97ffe76a 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba20:	97ffe7d5 	bl	5974 <fwp_rc_fresh>
    ba24:	aa0003e2 	mov	x2, x0
    ba28:	911463e1 	add	x1, sp, #0x518
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	f9028ff7 	str	x23, [sp, #1304]
    ba34:	f90293e2 	str	x2, [sp, #1312]
    ba38:	97ffe763 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba3c:	97ffe7ce 	bl	5974 <fwp_rc_fresh>
    ba40:	aa0003e2 	mov	x2, x0
    ba44:	9114a3e1 	add	x1, sp, #0x528
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f90297f5 	str	x21, [sp, #1320]
    ba50:	f9029be2 	str	x2, [sp, #1328]
    ba54:	97ffe75c 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba58:	97ffe7c7 	bl	5974 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	9114e3e1 	add	x1, sp, #0x538
    ba64:	52800020 	mov	w0, #0x1                   	// #1
    ba68:	f9029ff7 	str	x23, [sp, #1336]
    ba6c:	f902a3e2 	str	x2, [sp, #1344]
    ba70:	97ffe755 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba74:	91154283 	add	x3, x20, #0x550
    ba78:	aa0003f5 	mov	x21, x0
    ba7c:	f949d861 	ldr	x1, [x3, #5040]
    ba80:	f949ec60 	ldr	x0, [x3, #5080]
    ba84:	cb0102a1 	sub	x1, x21, x1
    ba88:	eb00403f 	cmp	x1, x0, lsl #16
    ba8c:	54000322 	b.cs	baf0 <f0+0x15f0>  // b.hs, b.nlast
    ba90:	d350fc22 	lsr	x2, x1, #16
    ba94:	f949fc63 	ldr	x3, [x3, #5112]
    ba98:	8b020842 	add	x2, x2, x2, lsl #2
    ba9c:	d37df042 	lsl	x2, x2, #3
    baa0:	8b020060 	add	x0, x3, x2
    baa4:	f9401017 	ldr	x23, [x0, #32]
    baa8:	b4000257 	cbz	x23, baf0 <f0+0x15f0>
    baac:	38626862 	ldrb	w2, [x3, x2]
    bab0:	7100085f 	cmp	w2, #0x2
    bab4:	54006ba0 	b.eq	c828 <f0+0x2328>  // b.none
    bab8:	7100045f 	cmp	w2, #0x1
    babc:	540001a1 	b.ne	baf0 <f0+0x15f0>  // b.any
    bac0:	29430002 	ldp	w2, w0, [x0, #24]
    bac4:	92403c21 	and	x1, x1, #0xffff
    bac8:	9b027c21 	mul	x1, x1, x2
    bacc:	d360fc21 	lsr	x1, x1, #32
    bad0:	eb00003f 	cmp	x1, x0
    bad4:	540000e2 	b.cs	baf0 <f0+0x15f0>  // b.hs, b.nlast
    bad8:	8b0102f7 	add	x23, x23, x1
    badc:	394002e0 	ldrb	w0, [x23]
    bae0:	7103fc1f 	cmp	w0, #0xff
    bae4:	54007f80 	b.eq	cad4 <f0+0x25d4>  // b.none
    bae8:	52800020 	mov	w0, #0x1                   	// #1
    baec:	390002e0 	strb	w0, [x23]
    baf0:	911523e1 	add	x1, sp, #0x548
    baf4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    baf8:	52800020 	mov	w0, #0x1                   	// #1
    bafc:	f902a7f7 	str	x23, [sp, #1352]
    bb00:	f902abf5 	str	x21, [sp, #1360]
    bb04:	97ffe730 	bl	57c4 <fwp_data.part.0.constprop.0>
    bb08:	97ffe79b 	bl	5974 <fwp_rc_fresh>
    bb0c:	aa0003e2 	mov	x2, x0
    bb10:	911563e1 	add	x1, sp, #0x558
    bb14:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bb18:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bb1c:	52800020 	mov	w0, #0x1                   	// #1
    bb20:	f902aff5 	str	x21, [sp, #1368]
    bb24:	f902b3e2 	str	x2, [sp, #1376]
    bb28:	97ffe727 	bl	57c4 <fwp_data.part.0.constprop.0>
    bb2c:	97ffe792 	bl	5974 <fwp_rc_fresh>
    bb30:	aa0003e2 	mov	x2, x0
    bb34:	9115a3e1 	add	x1, sp, #0x568
    bb38:	52800020 	mov	w0, #0x1                   	// #1
    bb3c:	f902b7f7 	str	x23, [sp, #1384]
    bb40:	f902bbe2 	str	x2, [sp, #1392]
    bb44:	97ffe720 	bl	57c4 <fwp_data.part.0.constprop.0>
    bb48:	97ffe78b 	bl	5974 <fwp_rc_fresh>
    bb4c:	aa0003e2 	mov	x2, x0
    bb50:	9115e3e1 	add	x1, sp, #0x578
    bb54:	52800020 	mov	w0, #0x1                   	// #1
    bb58:	f902bff5 	str	x21, [sp, #1400]
    bb5c:	f902c3e2 	str	x2, [sp, #1408]
    bb60:	97ffe719 	bl	57c4 <fwp_data.part.0.constprop.0>
    bb64:	91154283 	add	x3, x20, #0x550
    bb68:	aa0003f7 	mov	x23, x0
    bb6c:	f949d861 	ldr	x1, [x3, #5040]
    bb70:	f949ec60 	ldr	x0, [x3, #5080]
    bb74:	cb0102e1 	sub	x1, x23, x1
    bb78:	eb00403f 	cmp	x1, x0, lsl #16
    bb7c:	54000322 	b.cs	bbe0 <f0+0x16e0>  // b.hs, b.nlast
    bb80:	d350fc22 	lsr	x2, x1, #16
    bb84:	f949fc63 	ldr	x3, [x3, #5112]
    bb88:	8b020842 	add	x2, x2, x2, lsl #2
    bb8c:	d37df042 	lsl	x2, x2, #3
    bb90:	8b020060 	add	x0, x3, x2
    bb94:	f9401015 	ldr	x21, [x0, #32]
    bb98:	b4000255 	cbz	x21, bbe0 <f0+0x16e0>
    bb9c:	38626862 	ldrb	w2, [x3, x2]
    bba0:	7100085f 	cmp	w2, #0x2
    bba4:	54006540 	b.eq	c84c <f0+0x234c>  // b.none
    bba8:	7100045f 	cmp	w2, #0x1
    bbac:	540001a1 	b.ne	bbe0 <f0+0x16e0>  // b.any
    bbb0:	29430002 	ldp	w2, w0, [x0, #24]
    bbb4:	92403c21 	and	x1, x1, #0xffff
    bbb8:	9b027c21 	mul	x1, x1, x2
    bbbc:	d360fc21 	lsr	x1, x1, #32
    bbc0:	eb00003f 	cmp	x1, x0
    bbc4:	540000e2 	b.cs	bbe0 <f0+0x16e0>  // b.hs, b.nlast
    bbc8:	8b0102b5 	add	x21, x21, x1
    bbcc:	394002a0 	ldrb	w0, [x21]
    bbd0:	7103fc1f 	cmp	w0, #0xff
    bbd4:	54007860 	b.eq	cae0 <f0+0x25e0>  // b.none
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	390002a0 	strb	w0, [x21]
    bbe0:	911623e1 	add	x1, sp, #0x588
    bbe4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bbe8:	52800020 	mov	w0, #0x1                   	// #1
    bbec:	f902c7f5 	str	x21, [sp, #1416]
    bbf0:	f902cbf7 	str	x23, [sp, #1424]
    bbf4:	97ffe6f4 	bl	57c4 <fwp_data.part.0.constprop.0>
    bbf8:	97ffe75f 	bl	5974 <fwp_rc_fresh>
    bbfc:	aa0003e2 	mov	x2, x0
    bc00:	911663e1 	add	x1, sp, #0x598
    bc04:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bc08:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bc0c:	52800020 	mov	w0, #0x1                   	// #1
    bc10:	f902cff7 	str	x23, [sp, #1432]
    bc14:	f902d3e2 	str	x2, [sp, #1440]
    bc18:	97ffe6eb 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc1c:	97ffe756 	bl	5974 <fwp_rc_fresh>
    bc20:	aa0003e2 	mov	x2, x0
    bc24:	9116a3e1 	add	x1, sp, #0x5a8
    bc28:	52800020 	mov	w0, #0x1                   	// #1
    bc2c:	f902d7f5 	str	x21, [sp, #1448]
    bc30:	f902dbe2 	str	x2, [sp, #1456]
    bc34:	97ffe6e4 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc38:	97ffe74f 	bl	5974 <fwp_rc_fresh>
    bc3c:	aa0003e2 	mov	x2, x0
    bc40:	9116e3e1 	add	x1, sp, #0x5b8
    bc44:	52800020 	mov	w0, #0x1                   	// #1
    bc48:	f902dff7 	str	x23, [sp, #1464]
    bc4c:	f902e3e2 	str	x2, [sp, #1472]
    bc50:	97ffe6dd 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc54:	97ffe748 	bl	5974 <fwp_rc_fresh>
    bc58:	aa0003e2 	mov	x2, x0
    bc5c:	911723e1 	add	x1, sp, #0x5c8
    bc60:	52800020 	mov	w0, #0x1                   	// #1
    bc64:	f902e7f5 	str	x21, [sp, #1480]
    bc68:	f902ebe2 	str	x2, [sp, #1488]
    bc6c:	97ffe6d6 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc70:	97ffe741 	bl	5974 <fwp_rc_fresh>
    bc74:	aa0003e2 	mov	x2, x0
    bc78:	911763e1 	add	x1, sp, #0x5d8
    bc7c:	52800020 	mov	w0, #0x1                   	// #1
    bc80:	f902eff7 	str	x23, [sp, #1496]
    bc84:	f902f3e2 	str	x2, [sp, #1504]
    bc88:	97ffe6cf 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc8c:	97ffe73a 	bl	5974 <fwp_rc_fresh>
    bc90:	aa0003e2 	mov	x2, x0
    bc94:	9117a3e1 	add	x1, sp, #0x5e8
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	f902f7f5 	str	x21, [sp, #1512]
    bca0:	f902fbe2 	str	x2, [sp, #1520]
    bca4:	97ffe6c8 	bl	57c4 <fwp_data.part.0.constprop.0>
    bca8:	91154283 	add	x3, x20, #0x550
    bcac:	aa0003f5 	mov	x21, x0
    bcb0:	f949d861 	ldr	x1, [x3, #5040]
    bcb4:	f949ec60 	ldr	x0, [x3, #5080]
    bcb8:	cb0102a1 	sub	x1, x21, x1
    bcbc:	eb00403f 	cmp	x1, x0, lsl #16
    bcc0:	54000322 	b.cs	bd24 <f0+0x1824>  // b.hs, b.nlast
    bcc4:	d350fc22 	lsr	x2, x1, #16
    bcc8:	f949fc63 	ldr	x3, [x3, #5112]
    bccc:	8b020842 	add	x2, x2, x2, lsl #2
    bcd0:	d37df042 	lsl	x2, x2, #3
    bcd4:	8b020060 	add	x0, x3, x2
    bcd8:	f9401017 	ldr	x23, [x0, #32]
    bcdc:	b4000257 	cbz	x23, bd24 <f0+0x1824>
    bce0:	38626862 	ldrb	w2, [x3, x2]
    bce4:	7100085f 	cmp	w2, #0x2
    bce8:	54005ac0 	b.eq	c840 <f0+0x2340>  // b.none
    bcec:	7100045f 	cmp	w2, #0x1
    bcf0:	540001a1 	b.ne	bd24 <f0+0x1824>  // b.any
    bcf4:	29430002 	ldp	w2, w0, [x0, #24]
    bcf8:	92403c21 	and	x1, x1, #0xffff
    bcfc:	9b027c21 	mul	x1, x1, x2
    bd00:	d360fc21 	lsr	x1, x1, #32
    bd04:	eb00003f 	cmp	x1, x0
    bd08:	540000e2 	b.cs	bd24 <f0+0x1824>  // b.hs, b.nlast
    bd0c:	8b0102f7 	add	x23, x23, x1
    bd10:	394002e0 	ldrb	w0, [x23]
    bd14:	7103fc1f 	cmp	w0, #0xff
    bd18:	54006ea0 	b.eq	caec <f0+0x25ec>  // b.none
    bd1c:	52800020 	mov	w0, #0x1                   	// #1
    bd20:	390002e0 	strb	w0, [x23]
    bd24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bd28:	9117e3e1 	add	x1, sp, #0x5f8
    bd2c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd30:	52800020 	mov	w0, #0x1                   	// #1
    bd34:	f902ffe2 	str	x2, [sp, #1528]
    bd38:	f90303f5 	str	x21, [sp, #1536]
    bd3c:	97ffe6a2 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd40:	91154283 	add	x3, x20, #0x550
    bd44:	aa0003f7 	mov	x23, x0
    bd48:	f949d861 	ldr	x1, [x3, #5040]
    bd4c:	f949ec60 	ldr	x0, [x3, #5080]
    bd50:	cb0102e1 	sub	x1, x23, x1
    bd54:	eb00403f 	cmp	x1, x0, lsl #16
    bd58:	54000322 	b.cs	bdbc <f0+0x18bc>  // b.hs, b.nlast
    bd5c:	d350fc22 	lsr	x2, x1, #16
    bd60:	f949fc63 	ldr	x3, [x3, #5112]
    bd64:	8b020842 	add	x2, x2, x2, lsl #2
    bd68:	d37df042 	lsl	x2, x2, #3
    bd6c:	8b020060 	add	x0, x3, x2
    bd70:	f9401015 	ldr	x21, [x0, #32]
    bd74:	b4000255 	cbz	x21, bdbc <f0+0x18bc>
    bd78:	38626862 	ldrb	w2, [x3, x2]
    bd7c:	7100085f 	cmp	w2, #0x2
    bd80:	54005720 	b.eq	c864 <f0+0x2364>  // b.none
    bd84:	7100045f 	cmp	w2, #0x1
    bd88:	540001a1 	b.ne	bdbc <f0+0x18bc>  // b.any
    bd8c:	29430002 	ldp	w2, w0, [x0, #24]
    bd90:	92403c21 	and	x1, x1, #0xffff
    bd94:	9b027c21 	mul	x1, x1, x2
    bd98:	d360fc21 	lsr	x1, x1, #32
    bd9c:	eb00003f 	cmp	x1, x0
    bda0:	540000e2 	b.cs	bdbc <f0+0x18bc>  // b.hs, b.nlast
    bda4:	8b0102b5 	add	x21, x21, x1
    bda8:	394002a0 	ldrb	w0, [x21]
    bdac:	7103fc1f 	cmp	w0, #0xff
    bdb0:	54006a40 	b.eq	caf8 <f0+0x25f8>  // b.none
    bdb4:	52800020 	mov	w0, #0x1                   	// #1
    bdb8:	390002a0 	strb	w0, [x21]
    bdbc:	911823e1 	add	x1, sp, #0x608
    bdc0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bdc4:	52800020 	mov	w0, #0x1                   	// #1
    bdc8:	f90307f5 	str	x21, [sp, #1544]
    bdcc:	f9030bf7 	str	x23, [sp, #1552]
    bdd0:	97ffe67d 	bl	57c4 <fwp_data.part.0.constprop.0>
    bdd4:	97ffe6e8 	bl	5974 <fwp_rc_fresh>
    bdd8:	aa0003e2 	mov	x2, x0
    bddc:	911863e1 	add	x1, sp, #0x618
    bde0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bde4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bde8:	52800020 	mov	w0, #0x1                   	// #1
    bdec:	f9030ff7 	str	x23, [sp, #1560]
    bdf0:	f90313e2 	str	x2, [sp, #1568]
    bdf4:	97ffe674 	bl	57c4 <fwp_data.part.0.constprop.0>
    bdf8:	97ffe6df 	bl	5974 <fwp_rc_fresh>
    bdfc:	aa0003e2 	mov	x2, x0
    be00:	9118a3e1 	add	x1, sp, #0x628
    be04:	52800020 	mov	w0, #0x1                   	// #1
    be08:	f90317f5 	str	x21, [sp, #1576]
    be0c:	f9031be2 	str	x2, [sp, #1584]
    be10:	97ffe66d 	bl	57c4 <fwp_data.part.0.constprop.0>
    be14:	97ffe6d8 	bl	5974 <fwp_rc_fresh>
    be18:	aa0003e2 	mov	x2, x0
    be1c:	9118e3e1 	add	x1, sp, #0x638
    be20:	52800020 	mov	w0, #0x1                   	// #1
    be24:	f9031ff7 	str	x23, [sp, #1592]
    be28:	f90323e2 	str	x2, [sp, #1600]
    be2c:	97ffe666 	bl	57c4 <fwp_data.part.0.constprop.0>
    be30:	97ffe6d1 	bl	5974 <fwp_rc_fresh>
    be34:	aa0003e2 	mov	x2, x0
    be38:	911923e1 	add	x1, sp, #0x648
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	f90327f5 	str	x21, [sp, #1608]
    be44:	f9032be2 	str	x2, [sp, #1616]
    be48:	97ffe65f 	bl	57c4 <fwp_data.part.0.constprop.0>
    be4c:	97ffe6ca 	bl	5974 <fwp_rc_fresh>
    be50:	aa0003e2 	mov	x2, x0
    be54:	911963e1 	add	x1, sp, #0x658
    be58:	52800020 	mov	w0, #0x1                   	// #1
    be5c:	f9032ff7 	str	x23, [sp, #1624]
    be60:	f90333e2 	str	x2, [sp, #1632]
    be64:	97ffe658 	bl	57c4 <fwp_data.part.0.constprop.0>
    be68:	97ffe6c3 	bl	5974 <fwp_rc_fresh>
    be6c:	aa0003e2 	mov	x2, x0
    be70:	9119a3e1 	add	x1, sp, #0x668
    be74:	52800020 	mov	w0, #0x1                   	// #1
    be78:	f90337f5 	str	x21, [sp, #1640]
    be7c:	f9033be2 	str	x2, [sp, #1648]
    be80:	97ffe651 	bl	57c4 <fwp_data.part.0.constprop.0>
    be84:	91154283 	add	x3, x20, #0x550
    be88:	aa0003f5 	mov	x21, x0
    be8c:	f949d861 	ldr	x1, [x3, #5040]
    be90:	f949ec60 	ldr	x0, [x3, #5080]
    be94:	cb0102a1 	sub	x1, x21, x1
    be98:	eb00403f 	cmp	x1, x0, lsl #16
    be9c:	54000322 	b.cs	bf00 <f0+0x1a00>  // b.hs, b.nlast
    bea0:	d350fc22 	lsr	x2, x1, #16
    bea4:	f949fc63 	ldr	x3, [x3, #5112]
    bea8:	8b020842 	add	x2, x2, x2, lsl #2
    beac:	d37df042 	lsl	x2, x2, #3
    beb0:	8b020060 	add	x0, x3, x2
    beb4:	f9401017 	ldr	x23, [x0, #32]
    beb8:	b4000257 	cbz	x23, bf00 <f0+0x1a00>
    bebc:	38626862 	ldrb	w2, [x3, x2]
    bec0:	7100085f 	cmp	w2, #0x2
    bec4:	54004ca0 	b.eq	c858 <f0+0x2358>  // b.none
    bec8:	7100045f 	cmp	w2, #0x1
    becc:	540001a1 	b.ne	bf00 <f0+0x1a00>  // b.any
    bed0:	29430002 	ldp	w2, w0, [x0, #24]
    bed4:	92403c21 	and	x1, x1, #0xffff
    bed8:	9b027c21 	mul	x1, x1, x2
    bedc:	d360fc21 	lsr	x1, x1, #32
    bee0:	eb00003f 	cmp	x1, x0
    bee4:	540000e2 	b.cs	bf00 <f0+0x1a00>  // b.hs, b.nlast
    bee8:	8b0102f7 	add	x23, x23, x1
    beec:	394002e0 	ldrb	w0, [x23]
    bef0:	7103fc1f 	cmp	w0, #0xff
    bef4:	54006080 	b.eq	cb04 <f0+0x2604>  // b.none
    bef8:	52800020 	mov	w0, #0x1                   	// #1
    befc:	390002e0 	strb	w0, [x23]
    bf00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf04:	9119e3e1 	add	x1, sp, #0x678
    bf08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf0c:	52800020 	mov	w0, #0x1                   	// #1
    bf10:	f9033fe2 	str	x2, [sp, #1656]
    bf14:	f90343f5 	str	x21, [sp, #1664]
    bf18:	97ffe62b 	bl	57c4 <fwp_data.part.0.constprop.0>
    bf1c:	91154283 	add	x3, x20, #0x550
    bf20:	aa0003f5 	mov	x21, x0
    bf24:	f949d861 	ldr	x1, [x3, #5040]
    bf28:	f949ec60 	ldr	x0, [x3, #5080]
    bf2c:	cb0102a1 	sub	x1, x21, x1
    bf30:	eb00403f 	cmp	x1, x0, lsl #16
    bf34:	54000322 	b.cs	bf98 <f0+0x1a98>  // b.hs, b.nlast
    bf38:	d350fc22 	lsr	x2, x1, #16
    bf3c:	f949fc63 	ldr	x3, [x3, #5112]
    bf40:	8b020842 	add	x2, x2, x2, lsl #2
    bf44:	d37df042 	lsl	x2, x2, #3
    bf48:	8b020060 	add	x0, x3, x2
    bf4c:	f9401017 	ldr	x23, [x0, #32]
    bf50:	b4000257 	cbz	x23, bf98 <f0+0x1a98>
    bf54:	38626862 	ldrb	w2, [x3, x2]
    bf58:	7100085f 	cmp	w2, #0x2
    bf5c:	54004900 	b.eq	c87c <f0+0x237c>  // b.none
    bf60:	7100045f 	cmp	w2, #0x1
    bf64:	540001a1 	b.ne	bf98 <f0+0x1a98>  // b.any
    bf68:	29430002 	ldp	w2, w0, [x0, #24]
    bf6c:	92403c21 	and	x1, x1, #0xffff
    bf70:	9b027c21 	mul	x1, x1, x2
    bf74:	d360fc21 	lsr	x1, x1, #32
    bf78:	eb00003f 	cmp	x1, x0
    bf7c:	540000e2 	b.cs	bf98 <f0+0x1a98>  // b.hs, b.nlast
    bf80:	8b0102f7 	add	x23, x23, x1
    bf84:	394002e0 	ldrb	w0, [x23]
    bf88:	7103fc1f 	cmp	w0, #0xff
    bf8c:	54005c20 	b.eq	cb10 <f0+0x2610>  // b.none
    bf90:	52800020 	mov	w0, #0x1                   	// #1
    bf94:	390002e0 	strb	w0, [x23]
    bf98:	911a23e1 	add	x1, sp, #0x688
    bf9c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bfa0:	52800020 	mov	w0, #0x1                   	// #1
    bfa4:	f90347f7 	str	x23, [sp, #1672]
    bfa8:	f9034bf5 	str	x21, [sp, #1680]
    bfac:	97ffe606 	bl	57c4 <fwp_data.part.0.constprop.0>
    bfb0:	97ffe671 	bl	5974 <fwp_rc_fresh>
    bfb4:	aa0003e2 	mov	x2, x0
    bfb8:	911a63e1 	add	x1, sp, #0x698
    bfbc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bfc0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bfc4:	52800020 	mov	w0, #0x1                   	// #1
    bfc8:	f9034ff5 	str	x21, [sp, #1688]
    bfcc:	f90353e2 	str	x2, [sp, #1696]
    bfd0:	97ffe5fd 	bl	57c4 <fwp_data.part.0.constprop.0>
    bfd4:	97ffe668 	bl	5974 <fwp_rc_fresh>
    bfd8:	aa0003e2 	mov	x2, x0
    bfdc:	911aa3e1 	add	x1, sp, #0x6a8
    bfe0:	52800020 	mov	w0, #0x1                   	// #1
    bfe4:	f90357f7 	str	x23, [sp, #1704]
    bfe8:	f9035be2 	str	x2, [sp, #1712]
    bfec:	97ffe5f6 	bl	57c4 <fwp_data.part.0.constprop.0>
    bff0:	97ffe661 	bl	5974 <fwp_rc_fresh>
    bff4:	aa0003e2 	mov	x2, x0
    bff8:	911ae3e1 	add	x1, sp, #0x6b8
    bffc:	52800020 	mov	w0, #0x1                   	// #1
    c000:	f9035ff5 	str	x21, [sp, #1720]
    c004:	f90363e2 	str	x2, [sp, #1728]
    c008:	97ffe5ef 	bl	57c4 <fwp_data.part.0.constprop.0>
    c00c:	91154283 	add	x3, x20, #0x550
    c010:	aa0003f5 	mov	x21, x0
    c014:	f949d861 	ldr	x1, [x3, #5040]
    c018:	f949ec60 	ldr	x0, [x3, #5080]
    c01c:	cb0102a1 	sub	x1, x21, x1
    c020:	eb00403f 	cmp	x1, x0, lsl #16
    c024:	54000322 	b.cs	c088 <f0+0x1b88>  // b.hs, b.nlast
    c028:	d350fc22 	lsr	x2, x1, #16
    c02c:	f949fc63 	ldr	x3, [x3, #5112]
    c030:	8b020842 	add	x2, x2, x2, lsl #2
    c034:	d37df042 	lsl	x2, x2, #3
    c038:	8b020060 	add	x0, x3, x2
    c03c:	f9401017 	ldr	x23, [x0, #32]
    c040:	b4000257 	cbz	x23, c088 <f0+0x1b88>
    c044:	38626862 	ldrb	w2, [x3, x2]
    c048:	7100085f 	cmp	w2, #0x2
    c04c:	54004120 	b.eq	c870 <f0+0x2370>  // b.none
    c050:	7100045f 	cmp	w2, #0x1
    c054:	540001a1 	b.ne	c088 <f0+0x1b88>  // b.any
    c058:	29430002 	ldp	w2, w0, [x0, #24]
    c05c:	92403c21 	and	x1, x1, #0xffff
    c060:	9b027c21 	mul	x1, x1, x2
    c064:	d360fc21 	lsr	x1, x1, #32
    c068:	eb00003f 	cmp	x1, x0
    c06c:	540000e2 	b.cs	c088 <f0+0x1b88>  // b.hs, b.nlast
    c070:	8b0102f7 	add	x23, x23, x1
    c074:	394002e0 	ldrb	w0, [x23]
    c078:	7103fc1f 	cmp	w0, #0xff
    c07c:	54005500 	b.eq	cb1c <f0+0x261c>  // b.none
    c080:	52800020 	mov	w0, #0x1                   	// #1
    c084:	390002e0 	strb	w0, [x23]
    c088:	911b23e1 	add	x1, sp, #0x6c8
    c08c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c090:	52800020 	mov	w0, #0x1                   	// #1
    c094:	f90367f7 	str	x23, [sp, #1736]
    c098:	f9036bf5 	str	x21, [sp, #1744]
    c09c:	97ffe5ca 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0a0:	97ffe635 	bl	5974 <fwp_rc_fresh>
    c0a4:	aa0003e2 	mov	x2, x0
    c0a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c0ac:	911b63e1 	add	x1, sp, #0x6d8
    c0b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c0b4:	52800020 	mov	w0, #0x1                   	// #1
    c0b8:	f9036fe3 	str	x3, [sp, #1752]
    c0bc:	f90373e2 	str	x2, [sp, #1760]
    c0c0:	97ffe5c1 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0c4:	97ffe62c 	bl	5974 <fwp_rc_fresh>
    c0c8:	aa0003e2 	mov	x2, x0
    c0cc:	911ba3e1 	add	x1, sp, #0x6e8
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f90377f7 	str	x23, [sp, #1768]
    c0d8:	f9037be2 	str	x2, [sp, #1776]
    c0dc:	97ffe5ba 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0e0:	91154283 	add	x3, x20, #0x550
    c0e4:	aa0003f5 	mov	x21, x0
    c0e8:	f949d861 	ldr	x1, [x3, #5040]
    c0ec:	f949ec60 	ldr	x0, [x3, #5080]
    c0f0:	cb0102a1 	sub	x1, x21, x1
    c0f4:	eb00403f 	cmp	x1, x0, lsl #16
    c0f8:	54000322 	b.cs	c15c <f0+0x1c5c>  // b.hs, b.nlast
    c0fc:	d350fc22 	lsr	x2, x1, #16
    c100:	f949fc63 	ldr	x3, [x3, #5112]
    c104:	8b020842 	add	x2, x2, x2, lsl #2
    c108:	d37df042 	lsl	x2, x2, #3
    c10c:	8b020060 	add	x0, x3, x2
    c110:	f9401017 	ldr	x23, [x0, #32]
    c114:	b4000257 	cbz	x23, c15c <f0+0x1c5c>
    c118:	38626862 	ldrb	w2, [x3, x2]
    c11c:	7100085f 	cmp	w2, #0x2
    c120:	54003ba0 	b.eq	c894 <f0+0x2394>  // b.none
    c124:	7100045f 	cmp	w2, #0x1
    c128:	540001a1 	b.ne	c15c <f0+0x1c5c>  // b.any
    c12c:	29430002 	ldp	w2, w0, [x0, #24]
    c130:	92403c21 	and	x1, x1, #0xffff
    c134:	9b027c21 	mul	x1, x1, x2
    c138:	d360fc21 	lsr	x1, x1, #32
    c13c:	eb00003f 	cmp	x1, x0
    c140:	540000e2 	b.cs	c15c <f0+0x1c5c>  // b.hs, b.nlast
    c144:	8b0102f7 	add	x23, x23, x1
    c148:	394002e0 	ldrb	w0, [x23]
    c14c:	7103fc1f 	cmp	w0, #0xff
    c150:	54004ec0 	b.eq	cb28 <f0+0x2628>  // b.none
    c154:	52800020 	mov	w0, #0x1                   	// #1
    c158:	390002e0 	strb	w0, [x23]
    c15c:	911be3e1 	add	x1, sp, #0x6f8
    c160:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c164:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c168:	52800020 	mov	w0, #0x1                   	// #1
    c16c:	f9037ff7 	str	x23, [sp, #1784]
    c170:	f90383f5 	str	x21, [sp, #1792]
    c174:	97ffe594 	bl	57c4 <fwp_data.part.0.constprop.0>
    c178:	97ffe5ff 	bl	5974 <fwp_rc_fresh>
    c17c:	aa0003e2 	mov	x2, x0
    c180:	911c23e1 	add	x1, sp, #0x708
    c184:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	f90387f5 	str	x21, [sp, #1800]
    c190:	f9038be2 	str	x2, [sp, #1808]
    c194:	97ffe58c 	bl	57c4 <fwp_data.part.0.constprop.0>
    c198:	97ffe5f7 	bl	5974 <fwp_rc_fresh>
    c19c:	aa0003e2 	mov	x2, x0
    c1a0:	911c63e1 	add	x1, sp, #0x718
    c1a4:	52800020 	mov	w0, #0x1                   	// #1
    c1a8:	f9038ff7 	str	x23, [sp, #1816]
    c1ac:	f90393e2 	str	x2, [sp, #1824]
    c1b0:	97ffe585 	bl	57c4 <fwp_data.part.0.constprop.0>
    c1b4:	97ffe5f0 	bl	5974 <fwp_rc_fresh>
    c1b8:	aa0003e2 	mov	x2, x0
    c1bc:	911ca3e1 	add	x1, sp, #0x728
    c1c0:	52800020 	mov	w0, #0x1                   	// #1
    c1c4:	f90397f5 	str	x21, [sp, #1832]
    c1c8:	f9039be2 	str	x2, [sp, #1840]
    c1cc:	97ffe57e 	bl	57c4 <fwp_data.part.0.constprop.0>
    c1d0:	97ffe5e9 	bl	5974 <fwp_rc_fresh>
    c1d4:	aa0003e2 	mov	x2, x0
    c1d8:	911ce3e1 	add	x1, sp, #0x738
    c1dc:	52800020 	mov	w0, #0x1                   	// #1
    c1e0:	f9039ff7 	str	x23, [sp, #1848]
    c1e4:	f903a3e2 	str	x2, [sp, #1856]
    c1e8:	97ffe577 	bl	57c4 <fwp_data.part.0.constprop.0>
    c1ec:	97ffe5e2 	bl	5974 <fwp_rc_fresh>
    c1f0:	aa0003e2 	mov	x2, x0
    c1f4:	911d23e1 	add	x1, sp, #0x748
    c1f8:	52800020 	mov	w0, #0x1                   	// #1
    c1fc:	f903a7f5 	str	x21, [sp, #1864]
    c200:	f903abe2 	str	x2, [sp, #1872]
    c204:	97ffe570 	bl	57c4 <fwp_data.part.0.constprop.0>
    c208:	97ffe5db 	bl	5974 <fwp_rc_fresh>
    c20c:	aa0003e2 	mov	x2, x0
    c210:	911d63e1 	add	x1, sp, #0x758
    c214:	52800020 	mov	w0, #0x1                   	// #1
    c218:	f903aff7 	str	x23, [sp, #1880]
    c21c:	f903b3e2 	str	x2, [sp, #1888]
    c220:	97ffe569 	bl	57c4 <fwp_data.part.0.constprop.0>
    c224:	97ffe5d4 	bl	5974 <fwp_rc_fresh>
    c228:	aa0003e2 	mov	x2, x0
    c22c:	911da3e1 	add	x1, sp, #0x768
    c230:	52800020 	mov	w0, #0x1                   	// #1
    c234:	f903b7f5 	str	x21, [sp, #1896]
    c238:	f903bbe2 	str	x2, [sp, #1904]
    c23c:	97ffe562 	bl	57c4 <fwp_data.part.0.constprop.0>
    c240:	91154283 	add	x3, x20, #0x550
    c244:	aa0003f5 	mov	x21, x0
    c248:	f949d861 	ldr	x1, [x3, #5040]
    c24c:	f949ec60 	ldr	x0, [x3, #5080]
    c250:	cb0102a1 	sub	x1, x21, x1
    c254:	eb00403f 	cmp	x1, x0, lsl #16
    c258:	54000322 	b.cs	c2bc <f0+0x1dbc>  // b.hs, b.nlast
    c25c:	d350fc22 	lsr	x2, x1, #16
    c260:	f949fc63 	ldr	x3, [x3, #5112]
    c264:	8b020842 	add	x2, x2, x2, lsl #2
    c268:	d37df042 	lsl	x2, x2, #3
    c26c:	8b020060 	add	x0, x3, x2
    c270:	f9401017 	ldr	x23, [x0, #32]
    c274:	b4000257 	cbz	x23, c2bc <f0+0x1dbc>
    c278:	38626862 	ldrb	w2, [x3, x2]
    c27c:	7100085f 	cmp	w2, #0x2
    c280:	54003040 	b.eq	c888 <f0+0x2388>  // b.none
    c284:	7100045f 	cmp	w2, #0x1
    c288:	540001a1 	b.ne	c2bc <f0+0x1dbc>  // b.any
    c28c:	29430002 	ldp	w2, w0, [x0, #24]
    c290:	92403c21 	and	x1, x1, #0xffff
    c294:	9b027c21 	mul	x1, x1, x2
    c298:	d360fc21 	lsr	x1, x1, #32
    c29c:	eb00003f 	cmp	x1, x0
    c2a0:	540000e2 	b.cs	c2bc <f0+0x1dbc>  // b.hs, b.nlast
    c2a4:	8b0102f7 	add	x23, x23, x1
    c2a8:	394002e0 	ldrb	w0, [x23]
    c2ac:	7103fc1f 	cmp	w0, #0xff
    c2b0:	54004420 	b.eq	cb34 <f0+0x2634>  // b.none
    c2b4:	52800020 	mov	w0, #0x1                   	// #1
    c2b8:	390002e0 	strb	w0, [x23]
    c2bc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c2c0:	911de3e1 	add	x1, sp, #0x778
    c2c4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c2c8:	52800020 	mov	w0, #0x1                   	// #1
    c2cc:	f903bfe2 	str	x2, [sp, #1912]
    c2d0:	f903c3f5 	str	x21, [sp, #1920]
    c2d4:	97ffe53c 	bl	57c4 <fwp_data.part.0.constprop.0>
    c2d8:	91154283 	add	x3, x20, #0x550
    c2dc:	aa0003f5 	mov	x21, x0
    c2e0:	f949d861 	ldr	x1, [x3, #5040]
    c2e4:	f949ec60 	ldr	x0, [x3, #5080]
    c2e8:	cb0102a1 	sub	x1, x21, x1
    c2ec:	eb00403f 	cmp	x1, x0, lsl #16
    c2f0:	54000322 	b.cs	c354 <f0+0x1e54>  // b.hs, b.nlast
    c2f4:	d350fc22 	lsr	x2, x1, #16
    c2f8:	f949fc63 	ldr	x3, [x3, #5112]
    c2fc:	8b020842 	add	x2, x2, x2, lsl #2
    c300:	d37df042 	lsl	x2, x2, #3
    c304:	8b020060 	add	x0, x3, x2
    c308:	f9401017 	ldr	x23, [x0, #32]
    c30c:	b4000257 	cbz	x23, c354 <f0+0x1e54>
    c310:	38626862 	ldrb	w2, [x3, x2]
    c314:	7100085f 	cmp	w2, #0x2
    c318:	54002ca0 	b.eq	c8ac <f0+0x23ac>  // b.none
    c31c:	7100045f 	cmp	w2, #0x1
    c320:	540001a1 	b.ne	c354 <f0+0x1e54>  // b.any
    c324:	29430002 	ldp	w2, w0, [x0, #24]
    c328:	92403c21 	and	x1, x1, #0xffff
    c32c:	9b027c21 	mul	x1, x1, x2
    c330:	d360fc21 	lsr	x1, x1, #32
    c334:	eb00003f 	cmp	x1, x0
    c338:	540000e2 	b.cs	c354 <f0+0x1e54>  // b.hs, b.nlast
    c33c:	8b0102f7 	add	x23, x23, x1
    c340:	394002e0 	ldrb	w0, [x23]
    c344:	7103fc1f 	cmp	w0, #0xff
    c348:	54003fc0 	b.eq	cb40 <f0+0x2640>  // b.none
    c34c:	52800020 	mov	w0, #0x1                   	// #1
    c350:	390002e0 	strb	w0, [x23]
    c354:	911e23e1 	add	x1, sp, #0x788
    c358:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c35c:	52800020 	mov	w0, #0x1                   	// #1
    c360:	f903c7e2 	str	x2, [sp, #1928]
    c364:	f903cbf5 	str	x21, [sp, #1936]
    c368:	97ffe517 	bl	57c4 <fwp_data.part.0.constprop.0>
    c36c:	97ffe582 	bl	5974 <fwp_rc_fresh>
    c370:	aa0003e2 	mov	x2, x0
    c374:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c378:	911e63e1 	add	x1, sp, #0x798
    c37c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c380:	52800020 	mov	w0, #0x1                   	// #1
    c384:	f903cfe3 	str	x3, [sp, #1944]
    c388:	f903d3e2 	str	x2, [sp, #1952]
    c38c:	97ffe50e 	bl	57c4 <fwp_data.part.0.constprop.0>
    c390:	91154283 	add	x3, x20, #0x550
    c394:	aa0003f5 	mov	x21, x0
    c398:	f949d861 	ldr	x1, [x3, #5040]
    c39c:	f949ec60 	ldr	x0, [x3, #5080]
    c3a0:	cb0102a1 	sub	x1, x21, x1
    c3a4:	eb00403f 	cmp	x1, x0, lsl #16
    c3a8:	54000322 	b.cs	c40c <f0+0x1f0c>  // b.hs, b.nlast
    c3ac:	d350fc22 	lsr	x2, x1, #16
    c3b0:	f949fc63 	ldr	x3, [x3, #5112]
    c3b4:	8b020842 	add	x2, x2, x2, lsl #2
    c3b8:	d37df042 	lsl	x2, x2, #3
    c3bc:	8b020060 	add	x0, x3, x2
    c3c0:	f9401017 	ldr	x23, [x0, #32]
    c3c4:	b4000257 	cbz	x23, c40c <f0+0x1f0c>
    c3c8:	38626862 	ldrb	w2, [x3, x2]
    c3cc:	7100085f 	cmp	w2, #0x2
    c3d0:	54002680 	b.eq	c8a0 <f0+0x23a0>  // b.none
    c3d4:	7100045f 	cmp	w2, #0x1
    c3d8:	540001a1 	b.ne	c40c <f0+0x1f0c>  // b.any
    c3dc:	29430002 	ldp	w2, w0, [x0, #24]
    c3e0:	92403c21 	and	x1, x1, #0xffff
    c3e4:	9b027c21 	mul	x1, x1, x2
    c3e8:	d360fc21 	lsr	x1, x1, #32
    c3ec:	eb00003f 	cmp	x1, x0
    c3f0:	540000e2 	b.cs	c40c <f0+0x1f0c>  // b.hs, b.nlast
    c3f4:	8b0102f7 	add	x23, x23, x1
    c3f8:	394002e0 	ldrb	w0, [x23]
    c3fc:	7103fc1f 	cmp	w0, #0xff
    c400:	54003a60 	b.eq	cb4c <f0+0x264c>  // b.none
    c404:	52800020 	mov	w0, #0x1                   	// #1
    c408:	390002e0 	strb	w0, [x23]
    c40c:	911ea3e1 	add	x1, sp, #0x7a8
    c410:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c414:	52800020 	mov	w0, #0x1                   	// #1
    c418:	f903d7e2 	str	x2, [sp, #1960]
    c41c:	f903dbf5 	str	x21, [sp, #1968]
    c420:	97ffe4e9 	bl	57c4 <fwp_data.part.0.constprop.0>
    c424:	97ffe554 	bl	5974 <fwp_rc_fresh>
    c428:	aa0003e2 	mov	x2, x0
    c42c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c430:	911ee3e1 	add	x1, sp, #0x7b8
    c434:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c438:	52800020 	mov	w0, #0x1                   	// #1
    c43c:	f903dfe3 	str	x3, [sp, #1976]
    c440:	f903e3e2 	str	x2, [sp, #1984]
    c444:	97ffe4e0 	bl	57c4 <fwp_data.part.0.constprop.0>
    c448:	91154283 	add	x3, x20, #0x550
    c44c:	aa0003f5 	mov	x21, x0
    c450:	f949d861 	ldr	x1, [x3, #5040]
    c454:	f949ec60 	ldr	x0, [x3, #5080]
    c458:	cb0102a1 	sub	x1, x21, x1
    c45c:	eb00403f 	cmp	x1, x0, lsl #16
    c460:	54000322 	b.cs	c4c4 <f0+0x1fc4>  // b.hs, b.nlast
    c464:	d350fc22 	lsr	x2, x1, #16
    c468:	f949fc63 	ldr	x3, [x3, #5112]
    c46c:	8b020842 	add	x2, x2, x2, lsl #2
    c470:	d37df042 	lsl	x2, x2, #3
    c474:	8b020060 	add	x0, x3, x2
    c478:	f9401017 	ldr	x23, [x0, #32]
    c47c:	b4000257 	cbz	x23, c4c4 <f0+0x1fc4>
    c480:	38626862 	ldrb	w2, [x3, x2]
    c484:	7100085f 	cmp	w2, #0x2
    c488:	540021e0 	b.eq	c8c4 <f0+0x23c4>  // b.none
    c48c:	7100045f 	cmp	w2, #0x1
    c490:	540001a1 	b.ne	c4c4 <f0+0x1fc4>  // b.any
    c494:	29430002 	ldp	w2, w0, [x0, #24]
    c498:	92403c21 	and	x1, x1, #0xffff
    c49c:	9b027c21 	mul	x1, x1, x2
    c4a0:	d360fc21 	lsr	x1, x1, #32
    c4a4:	eb00003f 	cmp	x1, x0
    c4a8:	540000e2 	b.cs	c4c4 <f0+0x1fc4>  // b.hs, b.nlast
    c4ac:	8b0102f7 	add	x23, x23, x1
    c4b0:	394002e0 	ldrb	w0, [x23]
    c4b4:	7103fc1f 	cmp	w0, #0xff
    c4b8:	54003500 	b.eq	cb58 <f0+0x2658>  // b.none
    c4bc:	52800020 	mov	w0, #0x1                   	// #1
    c4c0:	390002e0 	strb	w0, [x23]
    c4c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c4c8:	911f23e1 	add	x1, sp, #0x7c8
    c4cc:	52800020 	mov	w0, #0x1                   	// #1
    c4d0:	f903e7e2 	str	x2, [sp, #1992]
    c4d4:	f903ebf5 	str	x21, [sp, #2000]
    c4d8:	97ffe4bb 	bl	57c4 <fwp_data.part.0.constprop.0>
    c4dc:	91154283 	add	x3, x20, #0x550
    c4e0:	aa0003f5 	mov	x21, x0
    c4e4:	f949d861 	ldr	x1, [x3, #5040]
    c4e8:	f949ec60 	ldr	x0, [x3, #5080]
    c4ec:	cb0102a1 	sub	x1, x21, x1
    c4f0:	eb00403f 	cmp	x1, x0, lsl #16
    c4f4:	54000322 	b.cs	c558 <f0+0x2058>  // b.hs, b.nlast
    c4f8:	d350fc22 	lsr	x2, x1, #16
    c4fc:	f949fc63 	ldr	x3, [x3, #5112]
    c500:	8b020842 	add	x2, x2, x2, lsl #2
    c504:	d37df042 	lsl	x2, x2, #3
    c508:	8b020060 	add	x0, x3, x2
    c50c:	f9401017 	ldr	x23, [x0, #32]
    c510:	b4000257 	cbz	x23, c558 <f0+0x2058>
    c514:	38626862 	ldrb	w2, [x3, x2]
    c518:	7100085f 	cmp	w2, #0x2
    c51c:	54001ce0 	b.eq	c8b8 <f0+0x23b8>  // b.none
    c520:	7100045f 	cmp	w2, #0x1
    c524:	540001a1 	b.ne	c558 <f0+0x2058>  // b.any
    c528:	29430002 	ldp	w2, w0, [x0, #24]
    c52c:	92403c21 	and	x1, x1, #0xffff
    c530:	9b027c21 	mul	x1, x1, x2
    c534:	d360fc21 	lsr	x1, x1, #32
    c538:	eb00003f 	cmp	x1, x0
    c53c:	540000e2 	b.cs	c558 <f0+0x2058>  // b.hs, b.nlast
    c540:	8b0102f7 	add	x23, x23, x1
    c544:	394002e0 	ldrb	w0, [x23]
    c548:	7103fc1f 	cmp	w0, #0xff
    c54c:	540030c0 	b.eq	cb64 <f0+0x2664>  // b.none
    c550:	52800020 	mov	w0, #0x1                   	// #1
    c554:	390002e0 	strb	w0, [x23]
    c558:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c55c:	911f63e1 	add	x1, sp, #0x7d8
    c560:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c564:	52800020 	mov	w0, #0x1                   	// #1
    c568:	f903efe2 	str	x2, [sp, #2008]
    c56c:	f903f3f5 	str	x21, [sp, #2016]
    c570:	97ffe495 	bl	57c4 <fwp_data.part.0.constprop.0>
    c574:	97ffe500 	bl	5974 <fwp_rc_fresh>
    c578:	aa0003e2 	mov	x2, x0
    c57c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c580:	911fa3e1 	add	x1, sp, #0x7e8
    c584:	52800020 	mov	w0, #0x1                   	// #1
    c588:	f903f7e3 	str	x3, [sp, #2024]
    c58c:	f903fbe2 	str	x2, [sp, #2032]
    c590:	97ffe48d 	bl	57c4 <fwp_data.part.0.constprop.0>
    c594:	91154283 	add	x3, x20, #0x550
    c598:	aa0003f5 	mov	x21, x0
    c59c:	f949d861 	ldr	x1, [x3, #5040]
    c5a0:	f949ec60 	ldr	x0, [x3, #5080]
    c5a4:	cb0102a1 	sub	x1, x21, x1
    c5a8:	eb00403f 	cmp	x1, x0, lsl #16
    c5ac:	54000322 	b.cs	c610 <f0+0x2110>  // b.hs, b.nlast
    c5b0:	d350fc22 	lsr	x2, x1, #16
    c5b4:	f949fc63 	ldr	x3, [x3, #5112]
    c5b8:	8b020842 	add	x2, x2, x2, lsl #2
    c5bc:	d37df042 	lsl	x2, x2, #3
    c5c0:	8b020060 	add	x0, x3, x2
    c5c4:	f9401017 	ldr	x23, [x0, #32]
    c5c8:	b4000257 	cbz	x23, c610 <f0+0x2110>
    c5cc:	38626862 	ldrb	w2, [x3, x2]
    c5d0:	7100085f 	cmp	w2, #0x2
    c5d4:	54001840 	b.eq	c8dc <f0+0x23dc>  // b.none
    c5d8:	7100045f 	cmp	w2, #0x1
    c5dc:	540001a1 	b.ne	c610 <f0+0x2110>  // b.any
    c5e0:	29430002 	ldp	w2, w0, [x0, #24]
    c5e4:	92403c21 	and	x1, x1, #0xffff
    c5e8:	9b027c21 	mul	x1, x1, x2
    c5ec:	d360fc21 	lsr	x1, x1, #32
    c5f0:	eb00003f 	cmp	x1, x0
    c5f4:	540000e2 	b.cs	c610 <f0+0x2110>  // b.hs, b.nlast
    c5f8:	8b0102f7 	add	x23, x23, x1
    c5fc:	394002e0 	ldrb	w0, [x23]
    c600:	7103fc1f 	cmp	w0, #0xff
    c604:	54002b60 	b.eq	cb70 <f0+0x2670>  // b.none
    c608:	52800020 	mov	w0, #0x1                   	// #1
    c60c:	390002e0 	strb	w0, [x23]
    c610:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c614:	911fe3e1 	add	x1, sp, #0x7f8
    c618:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c61c:	52800020 	mov	w0, #0x1                   	// #1
    c620:	f903ffe2 	str	x2, [sp, #2040]
    c624:	91154294 	add	x20, x20, #0x550
    c628:	f90403f5 	str	x21, [sp, #2048]
    c62c:	97ffe466 	bl	57c4 <fwp_data.part.0.constprop.0>
    c630:	97ffe4d1 	bl	5974 <fwp_rc_fresh>
    c634:	aa0003e2 	mov	x2, x0
    c638:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c63c:	912023e1 	add	x1, sp, #0x808
    c640:	52800020 	mov	w0, #0x1                   	// #1
    c644:	f90407e3 	str	x3, [sp, #2056]
    c648:	f9040be2 	str	x2, [sp, #2064]
    c64c:	97ffe45e 	bl	57c4 <fwp_data.part.0.constprop.0>
    c650:	f949da81 	ldr	x1, [x20, #5040]
    c654:	aa0003f5 	mov	x21, x0
    c658:	f949ee80 	ldr	x0, [x20, #5080]
    c65c:	cb0102a1 	sub	x1, x21, x1
    c660:	eb00403f 	cmp	x1, x0, lsl #16
    c664:	54000322 	b.cs	c6c8 <f0+0x21c8>  // b.hs, b.nlast
    c668:	d350fc22 	lsr	x2, x1, #16
    c66c:	f949fe83 	ldr	x3, [x20, #5112]
    c670:	8b020842 	add	x2, x2, x2, lsl #2
    c674:	d37df042 	lsl	x2, x2, #3
    c678:	8b020060 	add	x0, x3, x2
    c67c:	f9401014 	ldr	x20, [x0, #32]
    c680:	b4000254 	cbz	x20, c6c8 <f0+0x21c8>
    c684:	38626862 	ldrb	w2, [x3, x2]
    c688:	7100085f 	cmp	w2, #0x2
    c68c:	54001220 	b.eq	c8d0 <f0+0x23d0>  // b.none
    c690:	7100045f 	cmp	w2, #0x1
    c694:	540001a1 	b.ne	c6c8 <f0+0x21c8>  // b.any
    c698:	29430002 	ldp	w2, w0, [x0, #24]
    c69c:	92403c21 	and	x1, x1, #0xffff
    c6a0:	9b027c21 	mul	x1, x1, x2
    c6a4:	d360fc21 	lsr	x1, x1, #32
    c6a8:	eb00003f 	cmp	x1, x0
    c6ac:	540000e2 	b.cs	c6c8 <f0+0x21c8>  // b.hs, b.nlast
    c6b0:	8b010294 	add	x20, x20, x1
    c6b4:	39400280 	ldrb	w0, [x20]
    c6b8:	7103fc1f 	cmp	w0, #0xff
    c6bc:	54001760 	b.eq	c9a8 <f0+0x24a8>  // b.none
    c6c0:	52800020 	mov	w0, #0x1                   	// #1
    c6c4:	39000280 	strb	w0, [x20]
    c6c8:	912063e1 	add	x1, sp, #0x818
    c6cc:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c6d0:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c6d4:	52800020 	mov	w0, #0x1                   	// #1
    c6d8:	f9040ff4 	str	x20, [sp, #2072]
    c6dc:	f90413f5 	str	x21, [sp, #2080]
    c6e0:	97ffe439 	bl	57c4 <fwp_data.part.0.constprop.0>
    c6e4:	97ffe4a4 	bl	5974 <fwp_rc_fresh>
    c6e8:	aa0003e2 	mov	x2, x0
    c6ec:	9120a3e1 	add	x1, sp, #0x828
    c6f0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c6f4:	52800020 	mov	w0, #0x1                   	// #1
    c6f8:	f90417f5 	str	x21, [sp, #2088]
    c6fc:	f9041be2 	str	x2, [sp, #2096]
    c700:	97ffe431 	bl	57c4 <fwp_data.part.0.constprop.0>
    c704:	97ffe49c 	bl	5974 <fwp_rc_fresh>
    c708:	aa0003e2 	mov	x2, x0
    c70c:	9120e3e1 	add	x1, sp, #0x838
    c710:	52800020 	mov	w0, #0x1                   	// #1
    c714:	f9041ff4 	str	x20, [sp, #2104]
    c718:	f90423e2 	str	x2, [sp, #2112]
    c71c:	97ffe42a 	bl	57c4 <fwp_data.part.0.constprop.0>
    c720:	97ffe495 	bl	5974 <fwp_rc_fresh>
    c724:	aa0003e2 	mov	x2, x0
    c728:	912123e1 	add	x1, sp, #0x848
    c72c:	52800020 	mov	w0, #0x1                   	// #1
    c730:	f90427f5 	str	x21, [sp, #2120]
    c734:	f9042be2 	str	x2, [sp, #2128]
    c738:	97ffe423 	bl	57c4 <fwp_data.part.0.constprop.0>
    c73c:	97ffe48e 	bl	5974 <fwp_rc_fresh>
    c740:	aa0003e2 	mov	x2, x0
    c744:	aa1603e1 	mov	x1, x22
    c748:	52800020 	mov	w0, #0x1                   	// #1
    c74c:	f9042ff4 	str	x20, [sp, #2136]
    c750:	f90433e2 	str	x2, [sp, #2144]
    c754:	97ffe41c 	bl	57c4 <fwp_data.part.0.constprop.0>
    c758:	97ffe487 	bl	5974 <fwp_rc_fresh>
    c75c:	aa0003f5 	mov	x21, x0
    c760:	aa1303e1 	mov	x1, x19
    c764:	97fff3f7 	bl	9740 <fwp_hof0.constprop.0>
    c768:	aa0003f4 	mov	x20, x0
    c76c:	aa1503e0 	mov	x0, x21
    c770:	97ffe5e4 	bl	5f00 <fwp_drop0>
    c774:	aa1303e0 	mov	x0, x19
    c778:	97ffe5e2 	bl	5f00 <fwp_drop0>
    c77c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c780:	f947f400 	ldr	x0, [x0, #4072]
    c784:	f94437e2 	ldr	x2, [sp, #2152]
    c788:	f9400001 	ldr	x1, [x0]
    c78c:	eb010042 	subs	x2, x2, x1
    c790:	d2800001 	mov	x1, #0x0                   	// #0
    c794:	54001f41 	b.ne	cb7c <f0+0x267c>  // b.any
    c798:	9121c3ff 	add	sp, sp, #0x870
    c79c:	aa1403e0 	mov	x0, x20
    c7a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c7a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c7a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c7ac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c7b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    c7b4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c7b8:	d65f03c0 	ret
    c7bc:	aa1c03e0 	mov	x0, x28
    c7c0:	97ffddb4 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c7c4:	17fff799 	b	a628 <f0+0x128>
    c7c8:	72003c5f 	tst	w2, #0xffff
    c7cc:	54fef301 	b.ne	a62c <f0+0x12c>  // b.any
    c7d0:	17fff793 	b	a61c <f0+0x11c>
    c7d4:	72003c3f 	tst	w1, #0xffff
    c7d8:	54fef8c1 	b.ne	a6f0 <f0+0x1f0>  // b.any
    c7dc:	17fff7c0 	b	a6dc <f0+0x1dc>
    c7e0:	72003c3f 	tst	w1, #0xffff
    c7e4:	54ff0661 	b.ne	a8b0 <f0+0x3b0>  // b.any
    c7e8:	17fff82d 	b	a89c <f0+0x39c>
    c7ec:	72003c3f 	tst	w1, #0xffff
    c7f0:	54ff0081 	b.ne	a800 <f0+0x300>  // b.any
    c7f4:	17fff7fe 	b	a7ec <f0+0x2ec>
    c7f8:	72003c3f 	tst	w1, #0xffff
    c7fc:	54ff0ec1 	b.ne	a9d4 <f0+0x4d4>  // b.any
    c800:	17fff870 	b	a9c0 <f0+0x4c0>
    c804:	72003c3f 	tst	w1, #0xffff
    c808:	54ff09c1 	b.ne	a940 <f0+0x440>  // b.any
    c80c:	17fff848 	b	a92c <f0+0x42c>
    c810:	72003c3f 	tst	w1, #0xffff
    c814:	54ff1a81 	b.ne	ab64 <f0+0x664>  // b.any
    c818:	17fff8ce 	b	ab50 <f0+0x650>
    c81c:	72003c3f 	tst	w1, #0xffff
    c820:	54ff14a1 	b.ne	aab4 <f0+0x5b4>  // b.any
    c824:	17fff89f 	b	aaa0 <f0+0x5a0>
    c828:	72003c3f 	tst	w1, #0xffff
    c82c:	54ff9621 	b.ne	baf0 <f0+0x15f0>  // b.any
    c830:	17fffcab 	b	badc <f0+0x15dc>
    c834:	72003c3f 	tst	w1, #0xffff
    c838:	54ff8d61 	b.ne	b9e4 <f0+0x14e4>  // b.any
    c83c:	17fffc65 	b	b9d0 <f0+0x14d0>
    c840:	72003c3f 	tst	w1, #0xffff
    c844:	54ffa701 	b.ne	bd24 <f0+0x1824>  // b.any
    c848:	17fffd32 	b	bd10 <f0+0x1810>
    c84c:	72003c3f 	tst	w1, #0xffff
    c850:	54ff9c81 	b.ne	bbe0 <f0+0x16e0>  // b.any
    c854:	17fffcde 	b	bbcc <f0+0x16cc>
    c858:	72003c3f 	tst	w1, #0xffff
    c85c:	54ffb521 	b.ne	bf00 <f0+0x1a00>  // b.any
    c860:	17fffda3 	b	beec <f0+0x19ec>
    c864:	72003c3f 	tst	w1, #0xffff
    c868:	54ffaaa1 	b.ne	bdbc <f0+0x18bc>  // b.any
    c86c:	17fffd4f 	b	bda8 <f0+0x18a8>
    c870:	72003c3f 	tst	w1, #0xffff
    c874:	54ffc0a1 	b.ne	c088 <f0+0x1b88>  // b.any
    c878:	17fffdff 	b	c074 <f0+0x1b74>
    c87c:	72003c3f 	tst	w1, #0xffff
    c880:	54ffb8c1 	b.ne	bf98 <f0+0x1a98>  // b.any
    c884:	17fffdc0 	b	bf84 <f0+0x1a84>
    c888:	72003c3f 	tst	w1, #0xffff
    c88c:	54ffd181 	b.ne	c2bc <f0+0x1dbc>  // b.any
    c890:	17fffe86 	b	c2a8 <f0+0x1da8>
    c894:	72003c3f 	tst	w1, #0xffff
    c898:	54ffc621 	b.ne	c15c <f0+0x1c5c>  // b.any
    c89c:	17fffe2b 	b	c148 <f0+0x1c48>
    c8a0:	72003c3f 	tst	w1, #0xffff
    c8a4:	54ffdb41 	b.ne	c40c <f0+0x1f0c>  // b.any
    c8a8:	17fffed4 	b	c3f8 <f0+0x1ef8>
    c8ac:	72003c3f 	tst	w1, #0xffff
    c8b0:	54ffd521 	b.ne	c354 <f0+0x1e54>  // b.any
    c8b4:	17fffea3 	b	c340 <f0+0x1e40>
    c8b8:	72003c3f 	tst	w1, #0xffff
    c8bc:	54ffe4e1 	b.ne	c558 <f0+0x2058>  // b.any
    c8c0:	17ffff21 	b	c544 <f0+0x2044>
    c8c4:	72003c3f 	tst	w1, #0xffff
    c8c8:	54ffdfe1 	b.ne	c4c4 <f0+0x1fc4>  // b.any
    c8cc:	17fffef9 	b	c4b0 <f0+0x1fb0>
    c8d0:	72003c3f 	tst	w1, #0xffff
    c8d4:	54ffefa1 	b.ne	c6c8 <f0+0x21c8>  // b.any
    c8d8:	17ffff77 	b	c6b4 <f0+0x21b4>
    c8dc:	72003c3f 	tst	w1, #0xffff
    c8e0:	54ffe981 	b.ne	c610 <f0+0x2110>  // b.any
    c8e4:	17ffff46 	b	c5fc <f0+0x20fc>
    c8e8:	72003c3f 	tst	w1, #0xffff
    c8ec:	54ff1ec1 	b.ne	acc4 <f0+0x7c4>  // b.any
    c8f0:	17fff8f0 	b	acb0 <f0+0x7b0>
    c8f4:	72003c3f 	tst	w1, #0xffff
    c8f8:	54ff18e1 	b.ne	ac14 <f0+0x714>  // b.any
    c8fc:	17fff8c1 	b	ac00 <f0+0x700>
    c900:	72003c3f 	tst	w1, #0xffff
    c904:	54ff2a81 	b.ne	ae54 <f0+0x954>  // b.any
    c908:	17fff94e 	b	ae40 <f0+0x940>
    c90c:	72003c3f 	tst	w1, #0xffff
    c910:	54ff24a1 	b.ne	ada4 <f0+0x8a4>  // b.any
    c914:	17fff91f 	b	ad90 <f0+0x890>
    c918:	72003c3f 	tst	w1, #0xffff
    c91c:	54ff3541 	b.ne	afc4 <f0+0xac4>  // b.any
    c920:	17fff9a4 	b	afb0 <f0+0xab0>
    c924:	72003c3f 	tst	w1, #0xffff
    c928:	54ff2f21 	b.ne	af0c <f0+0xa0c>  // b.any
    c92c:	17fff973 	b	aef8 <f0+0x9f8>
    c930:	72003c3f 	tst	w1, #0xffff
    c934:	54ff3fe1 	b.ne	b130 <f0+0xc30>  // b.any
    c938:	17fff9f9 	b	b11c <f0+0xc1c>
    c93c:	72003c3f 	tst	w1, #0xffff
    c940:	54ff3ac1 	b.ne	b098 <f0+0xb98>  // b.any
    c944:	17fff9d0 	b	b084 <f0+0xb84>
    c948:	72003c3f 	tst	w1, #0xffff
    c94c:	54ff4c61 	b.ne	b2d8 <f0+0xdd8>  // b.any
    c950:	17fffa5d 	b	b2c4 <f0+0xdc4>
    c954:	72003c3f 	tst	w1, #0xffff
    c958:	54ff4561 	b.ne	b204 <f0+0xd04>  // b.any
    c95c:	17fffa25 	b	b1f0 <f0+0xcf0>
    c960:	72003c3f 	tst	w1, #0xffff
    c964:	54ff5d01 	b.ne	b504 <f0+0x1004>  // b.any
    c968:	17fffae2 	b	b4f0 <f0+0xff0>
    c96c:	72003c3f 	tst	w1, #0xffff
    c970:	54ff4fe1 	b.ne	b36c <f0+0xe6c>  // b.any
    c974:	17fffa79 	b	b358 <f0+0xe58>
    c978:	72003c3f 	tst	w1, #0xffff
    c97c:	54ff6a41 	b.ne	b6c4 <f0+0x11c4>  // b.any
    c980:	17fffb4c 	b	b6b0 <f0+0x11b0>
    c984:	72003c3f 	tst	w1, #0xffff
    c988:	54ff6521 	b.ne	b62c <f0+0x112c>  // b.any
    c98c:	17fffb23 	b	b618 <f0+0x1118>
    c990:	72003c3f 	tst	w1, #0xffff
    c994:	54ff7861 	b.ne	b8a0 <f0+0x13a0>  // b.any
    c998:	17fffbbd 	b	b88c <f0+0x138c>
    c99c:	72003c3f 	tst	w1, #0xffff
    c9a0:	54ff7341 	b.ne	b808 <f0+0x1308>  // b.any
    c9a4:	17fffb94 	b	b7f4 <f0+0x12f4>
    c9a8:	aa1403e0 	mov	x0, x20
    c9ac:	97ffdd39 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9b0:	17ffff44 	b	c6c0 <f0+0x21c0>
    c9b4:	aa1703e0 	mov	x0, x23
    c9b8:	97ffdd36 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9bc:	17fff74b 	b	a6e8 <f0+0x1e8>
    c9c0:	aa1703e0 	mov	x0, x23
    c9c4:	97ffdd33 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9c8:	17fff78c 	b	a7f8 <f0+0x2f8>
    c9cc:	aa1703e0 	mov	x0, x23
    c9d0:	97ffdd30 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9d4:	17fff7b5 	b	a8a8 <f0+0x3a8>
    c9d8:	aa1703e0 	mov	x0, x23
    c9dc:	97ffdd2d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9e0:	17fff7d6 	b	a938 <f0+0x438>
    c9e4:	aa1703e0 	mov	x0, x23
    c9e8:	97ffdd2a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9ec:	17fff7f8 	b	a9cc <f0+0x4cc>
    c9f0:	aa1703e0 	mov	x0, x23
    c9f4:	97ffdd27 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9f8:	17fff82d 	b	aaac <f0+0x5ac>
    c9fc:	aa1703e0 	mov	x0, x23
    ca00:	97ffdd24 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca04:	17fff856 	b	ab5c <f0+0x65c>
    ca08:	aa1703e0 	mov	x0, x23
    ca0c:	97ffdd21 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca10:	17fff87f 	b	ac0c <f0+0x70c>
    ca14:	aa1703e0 	mov	x0, x23
    ca18:	97ffdd1e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca1c:	17fff8a8 	b	acbc <f0+0x7bc>
    ca20:	aa1703e0 	mov	x0, x23
    ca24:	97ffdd1b 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca28:	17fff8dd 	b	ad9c <f0+0x89c>
    ca2c:	aa1703e0 	mov	x0, x23
    ca30:	97ffdd18 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca34:	17fff906 	b	ae4c <f0+0x94c>
    ca38:	aa1703e0 	mov	x0, x23
    ca3c:	97ffdd15 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca40:	17fff931 	b	af04 <f0+0xa04>
    ca44:	aa1703e0 	mov	x0, x23
    ca48:	97ffdd12 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca4c:	17fff95c 	b	afbc <f0+0xabc>
    ca50:	aa1703e0 	mov	x0, x23
    ca54:	97ffdd0f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca58:	17fff98e 	b	b090 <f0+0xb90>
    ca5c:	aa1703e0 	mov	x0, x23
    ca60:	97ffdd0c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca64:	17fff9b1 	b	b128 <f0+0xc28>
    ca68:	aa1703e0 	mov	x0, x23
    ca6c:	97ffdd09 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca70:	17fff9e3 	b	b1fc <f0+0xcfc>
    ca74:	aa1703e0 	mov	x0, x23
    ca78:	97ffdd06 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca7c:	17fffa15 	b	b2d0 <f0+0xdd0>
    ca80:	aa1703e0 	mov	x0, x23
    ca84:	97ffdd03 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca88:	17fffa37 	b	b364 <f0+0xe64>
    ca8c:	aa1703e0 	mov	x0, x23
    ca90:	97ffdd00 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca94:	17fffa9a 	b	b4fc <f0+0xffc>
    ca98:	aa1703e0 	mov	x0, x23
    ca9c:	97ffdcfd 	bl	3e90 <fwp_rc_forget_slot.part.0>
    caa0:	17fffae1 	b	b624 <f0+0x1124>
    caa4:	aa1503e0 	mov	x0, x21
    caa8:	97ffdcfa 	bl	3e90 <fwp_rc_forget_slot.part.0>
    caac:	17fffb04 	b	b6bc <f0+0x11bc>
    cab0:	aa1703e0 	mov	x0, x23
    cab4:	97ffdcf7 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cab8:	17fffb52 	b	b800 <f0+0x1300>
    cabc:	aa1503e0 	mov	x0, x21
    cac0:	97ffdcf4 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cac4:	17fffb75 	b	b898 <f0+0x1398>
    cac8:	aa1703e0 	mov	x0, x23
    cacc:	97ffdcf1 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cad0:	17fffbc3 	b	b9dc <f0+0x14dc>
    cad4:	aa1703e0 	mov	x0, x23
    cad8:	97ffdcee 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cadc:	17fffc03 	b	bae8 <f0+0x15e8>
    cae0:	aa1503e0 	mov	x0, x21
    cae4:	97ffdceb 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cae8:	17fffc3c 	b	bbd8 <f0+0x16d8>
    caec:	aa1703e0 	mov	x0, x23
    caf0:	97ffdce8 	bl	3e90 <fwp_rc_forget_slot.part.0>
    caf4:	17fffc8a 	b	bd1c <f0+0x181c>
    caf8:	aa1503e0 	mov	x0, x21
    cafc:	97ffdce5 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb00:	17fffcad 	b	bdb4 <f0+0x18b4>
    cb04:	aa1703e0 	mov	x0, x23
    cb08:	97ffdce2 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb0c:	17fffcfb 	b	bef8 <f0+0x19f8>
    cb10:	aa1703e0 	mov	x0, x23
    cb14:	97ffdcdf 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb18:	17fffd1e 	b	bf90 <f0+0x1a90>
    cb1c:	aa1703e0 	mov	x0, x23
    cb20:	97ffdcdc 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb24:	17fffd57 	b	c080 <f0+0x1b80>
    cb28:	aa1703e0 	mov	x0, x23
    cb2c:	97ffdcd9 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb30:	17fffd89 	b	c154 <f0+0x1c54>
    cb34:	aa1703e0 	mov	x0, x23
    cb38:	97ffdcd6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb3c:	17fffdde 	b	c2b4 <f0+0x1db4>
    cb40:	aa1703e0 	mov	x0, x23
    cb44:	97ffdcd3 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb48:	17fffe01 	b	c34c <f0+0x1e4c>
    cb4c:	aa1703e0 	mov	x0, x23
    cb50:	97ffdcd0 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb54:	17fffe2c 	b	c404 <f0+0x1f04>
    cb58:	aa1703e0 	mov	x0, x23
    cb5c:	97ffdccd 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb60:	17fffe57 	b	c4bc <f0+0x1fbc>
    cb64:	aa1703e0 	mov	x0, x23
    cb68:	97ffdcca 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb6c:	17fffe79 	b	c550 <f0+0x2050>
    cb70:	aa1703e0 	mov	x0, x23
    cb74:	97ffdcc7 	bl	3e90 <fwp_rc_forget_slot.part.0>
    cb78:	17fffea4 	b	c608 <f0+0x2108>
    cb7c:	97ffd71d 	bl	27f0 <__stack_chk_fail@plt>
    cb80:	97ffd730 	bl	2840 <abort@plt>

000000000000cb84 <fwp_main_thread>:
    cb84:	d10443ff 	sub	sp, sp, #0x110
    cb88:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cb8c:	f947f400 	ldr	x0, [x0, #4072]
    cb90:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cb94:	910303fd 	add	x29, sp, #0xc0
    cb98:	a90d53f3 	stp	x19, x20, [sp, #208]
    cb9c:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc90>
    cba0:	91154261 	add	x1, x19, #0x550
    cba4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cba8:	b953a421 	ldr	w1, [x1, #5028]
    cbac:	f9400002 	ldr	x2, [x0]
    cbb0:	f9005fe2 	str	x2, [sp, #184]
    cbb4:	d2800002 	mov	x2, #0x0                   	// #0
    cbb8:	34000e41 	cbz	w1, cd80 <fwp_main_thread+0x1fc>
    cbbc:	91154273 	add	x19, x19, #0x550
    cbc0:	b953aa60 	ldr	w0, [x19, #5032]
    cbc4:	35000d60 	cbnz	w0, cd70 <fwp_main_thread+0x1ec>
    cbc8:	91001fe2 	add	x2, sp, #0x7
    cbcc:	900000b4 	adrp	x20, 20000 <__data_start>
    cbd0:	900000a3 	adrp	x3, 20000 <__data_start>
    cbd4:	91010293 	add	x19, x20, #0x40
    cbd8:	910dc063 	add	x3, x3, #0x370
    cbdc:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cbe0:	d2a00025 	mov	x5, #0x10000               	// #65536
    cbe4:	910023e0 	add	x0, sp, #0x8
    cbe8:	d2800001 	mov	x1, #0x0                   	// #0
    cbec:	f90007e3 	str	x3, [sp, #8]
    cbf0:	b90013ff 	str	wzr, [sp, #16]
    cbf4:	a9019262 	stp	x2, x4, [x19, #24]
    cbf8:	f9000fe5 	str	x5, [sp, #24]
    cbfc:	97ffd695 	bl	2650 <sigaltstack@plt>
    cc00:	35000220 	cbnz	w0, cc44 <fwp_main_thread+0xc0>
    cc04:	4f000400 	movi	v0.4s, #0x0
    cc08:	9100a3e0 	add	x0, sp, #0x28
    cc0c:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    cc10:	52800082 	mov	w2, #0x4                   	// #4
    cc14:	913fc021 	add	x1, x1, #0xff0
    cc18:	72a10002 	movk	w2, #0x800, lsl #16
    cc1c:	910083f5 	add	x21, sp, #0x20
    cc20:	f90013e1 	str	x1, [sp, #32]
    cc24:	3d802000 	str	q0, [x0, #128]
    cc28:	b900abe2 	str	w2, [sp, #168]
    cc2c:	ad000000 	stp	q0, q0, [x0]
    cc30:	ad010000 	stp	q0, q0, [x0, #32]
    cc34:	ad020000 	stp	q0, q0, [x0, #64]
    cc38:	ad030000 	stp	q0, q0, [x0, #96]
    cc3c:	97ffd6dd 	bl	27b0 <sigemptyset@plt>
    cc40:	340000c0 	cbz	w0, cc58 <fwp_main_thread+0xd4>
    cc44:	b0000000 	adrp	x0, d000 <fwp_main_thread+0x47c>
    cc48:	9135e000 	add	x0, x0, #0xd78
    cc4c:	a90f63f7 	stp	x23, x24, [sp, #240]
    cc50:	f90083f9 	str	x25, [sp, #256]
    cc54:	97ffdc6f 	bl	3e10 <fwp_trap>
    cc58:	aa1503e1 	mov	x1, x21
    cc5c:	d2800002 	mov	x2, #0x0                   	// #0
    cc60:	52800160 	mov	w0, #0xb                   	// #11
    cc64:	97ffd6eb 	bl	2810 <sigaction@plt>
    cc68:	35fffee0 	cbnz	w0, cc44 <fwp_main_thread+0xc0>
    cc6c:	aa1503e1 	mov	x1, x21
    cc70:	d2800002 	mov	x2, #0x0                   	// #0
    cc74:	528000e0 	mov	w0, #0x7                   	// #7
    cc78:	97ffd6e6 	bl	2810 <sigaction@plt>
    cc7c:	35fffe40 	cbnz	w0, cc44 <fwp_main_thread+0xc0>
    cc80:	b942fa60 	ldr	w0, [x19, #760]
    cc84:	a90f63f7 	stp	x23, x24, [sp, #240]
    cc88:	340019c0 	cbz	w0, cfc0 <fwp_main_thread+0x43c>
    cc8c:	91010296 	add	x22, x20, #0x40
    cc90:	f9400ad5 	ldr	x21, [x22, #16]
    cc94:	b40007f5 	cbz	x21, cd90 <fwp_main_thread+0x20c>
    cc98:	910102b7 	add	x23, x21, #0x40
    cc9c:	f90083f9 	str	x25, [sp, #256]
    cca0:	52800038 	mov	w24, #0x1                   	// #1
    cca4:	39414ab9 	ldrb	w25, [x21, #82]
    cca8:	39014ab8 	strb	w24, [x21, #82]
    ccac:	d503201f 	nop
    ccb0:	f94016a0 	ldr	x0, [x21, #40]
    ccb4:	b40006a0 	cbz	x0, cd88 <fwp_main_thread+0x204>
    ccb8:	f94032a1 	ldr	x1, [x21, #96]
    ccbc:	394146a0 	ldrb	w0, [x21, #81]
    ccc0:	b40019c1 	cbz	x1, cff8 <fwp_main_thread+0x474>
    ccc4:	36001880 	tbz	w0, #0, cfd4 <fwp_main_thread+0x450>
    ccc8:	f9400ad3 	ldr	x19, [x22, #16]
    cccc:	f94022a0 	ldr	x0, [x21, #64]
    ccd0:	39414a61 	ldrb	w1, [x19, #82]
    ccd4:	37001be1 	tbnz	w1, #0, d050 <fwp_main_thread+0x4cc>
    ccd8:	f9403261 	ldr	x1, [x19, #96]
    ccdc:	a911fe77 	stp	x23, xzr, [x19, #280]
    cce0:	f9009660 	str	x0, [x19, #296]
    cce4:	b4000040 	cbz	x0, ccec <fwp_main_thread+0x168>
    cce8:	f9009013 	str	x19, [x0, #288]
    ccec:	f90022b3 	str	x19, [x21, #64]
    ccf0:	b4000101 	cbz	x1, cd10 <fwp_main_thread+0x18c>
    ccf4:	f94046c0 	ldr	x0, [x22, #136]
    ccf8:	39015678 	strb	w24, [x19, #85]
    ccfc:	f9003661 	str	x1, [x19, #104]
    cd00:	a910827f 	stp	xzr, x0, [x19, #264]
    cd04:	b4000040 	cbz	x0, cd0c <fwp_main_thread+0x188>
    cd08:	f9008413 	str	x19, [x0, #264]
    cd0c:	f90046d3 	str	x19, [x22, #136]
    cd10:	39015a7f 	strb	wzr, [x19, #86]
    cd14:	97ffe6cf 	bl	6850 <fwp_block>
    cd18:	f9408e62 	ldr	x2, [x19, #280]
    cd1c:	b4000142 	cbz	x2, cd44 <fwp_main_thread+0x1c0>
    cd20:	a9520261 	ldp	x1, x0, [x19, #288]
    cd24:	b4001a21 	cbz	x1, d068 <fwp_main_thread+0x4e4>
    cd28:	f9009420 	str	x0, [x1, #296]
    cd2c:	f9409660 	ldr	x0, [x19, #296]
    cd30:	b4000040 	cbz	x0, cd38 <fwp_main_thread+0x1b4>
    cd34:	f9009001 	str	x1, [x0, #288]
    cd38:	91080260 	add	x0, x19, #0x200
    cd3c:	f900967f 	str	xzr, [x19, #296]
    cd40:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cd44:	39415660 	ldrb	w0, [x19, #85]
    cd48:	3607fb40 	tbz	w0, #0, ccb0 <fwp_main_thread+0x12c>
    cd4c:	a9508261 	ldp	x1, x0, [x19, #264]
    cd50:	b4001901 	cbz	x1, d070 <fwp_main_thread+0x4ec>
    cd54:	f9008820 	str	x0, [x1, #272]
    cd58:	b4000040 	cbz	x0, cd60 <fwp_main_thread+0x1dc>
    cd5c:	f9008401 	str	x1, [x0, #264]
    cd60:	91080260 	add	x0, x19, #0x200
    cd64:	3901567f 	strb	wzr, [x19, #85]
    cd68:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cd6c:	17ffffd1 	b	ccb0 <fwp_main_thread+0x12c>
    cd70:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    cd74:	91241000 	add	x0, x0, #0x904
    cd78:	94000286 	bl	d790 <atexit>
    cd7c:	17ffff93 	b	cbc8 <fwp_main_thread+0x44>
    cd80:	97ffdb3c 	bl	3a70 <fwp_heap_init>
    cd84:	17ffff8e 	b	cbbc <fwp_main_thread+0x38>
    cd88:	39014ab9 	strb	w25, [x21, #82]
    cd8c:	f94083f9 	ldr	x25, [sp, #256]
    cd90:	91010293 	add	x19, x20, #0x40
    cd94:	f9416e60 	ldr	x0, [x19, #728]
    cd98:	b5000180 	cbnz	x0, cdc8 <fwp_main_thread+0x244>
    cd9c:	f9417660 	ldr	x0, [x19, #744]
    cda0:	b5000140 	cbnz	x0, cdc8 <fwp_main_thread+0x244>
    cda4:	f9416a60 	ldr	x0, [x19, #720]
    cda8:	97ffdcd6 	bl	4100 <fwp_mem_free>
    cdac:	f9016a7f 	str	xzr, [x19, #720]
    cdb0:	f9400a60 	ldr	x0, [x19, #16]
    cdb4:	f901727f 	str	xzr, [x19, #736]
    cdb8:	b40000c0 	cbz	x0, cdd0 <fwp_main_thread+0x24c>
    cdbc:	f900541f 	str	xzr, [x0, #168]
    cdc0:	f9005c1f 	str	xzr, [x0, #184]
    cdc4:	14000003 	b	cdd0 <fwp_main_thread+0x24c>
    cdc8:	91010280 	add	x0, x20, #0x40
    cdcc:	f9400800 	ldr	x0, [x0, #16]
    cdd0:	91010281 	add	x1, x20, #0x40
    cdd4:	f9418826 	ldr	x6, [x1, #784]
    cdd8:	b903083f 	str	wzr, [x1, #776]
    cddc:	eb0000df 	cmp	x6, x0
    cde0:	54001561 	b.ne	d08c <fwp_main_thread+0x508>  // b.any
    cde4:	b4000380 	cbz	x0, ce54 <fwp_main_thread+0x2d0>
    cde8:	f9415825 	ldr	x5, [x1, #688]
    cdec:	52800021 	mov	w1, #0x1                   	// #1
    cdf0:	39014801 	strb	w1, [x0, #82]
    cdf4:	b4000305 	cbz	x5, ce54 <fwp_main_thread+0x2d0>
    cdf8:	394140a0 	ldrb	w0, [x5, #80]
    cdfc:	37000060 	tbnz	w0, #0, ce08 <fwp_main_thread+0x284>
    ce00:	aa0503e0 	mov	x0, x5
    ce04:	97ffd97b 	bl	33f0 <fwp_cancel_tree.part.0>
    ce08:	f9409ca5 	ldr	x5, [x5, #312]
    ce0c:	b5ffff65 	cbnz	x5, cdf8 <fwp_main_thread+0x274>
    ce10:	91010293 	add	x19, x20, #0x40
    ce14:	52800035 	mov	w21, #0x1                   	// #1
    ce18:	f94028c0 	ldr	x0, [x6, #80]
    ce1c:	f2001c1f 	tst	x0, #0xff000000ff
    ce20:	540000e1 	b.ne	ce3c <fwp_main_thread+0x2b8>  // b.any
    ce24:	f9401660 	ldr	x0, [x19, #40]
    ce28:	390150d5 	strb	w21, [x6, #84]
    ce2c:	f90080df 	str	xzr, [x6, #256]
    ce30:	b40010c0 	cbz	x0, d048 <fwp_main_thread+0x4c4>
    ce34:	f9008006 	str	x6, [x0, #256]
    ce38:	f9001666 	str	x6, [x19, #40]
    ce3c:	97ffe685 	bl	6850 <fwp_block>
    ce40:	97ffe60c 	bl	6670 <fwp_free_zombie>
    ce44:	f9415a60 	ldr	x0, [x19, #688]
    ce48:	b4000060 	cbz	x0, ce54 <fwp_main_thread+0x2d0>
    ce4c:	f9418a66 	ldr	x6, [x19, #784]
    ce50:	17fffff2 	b	ce18 <fwp_main_thread+0x294>
    ce54:	91010295 	add	x21, x20, #0x40
    ce58:	97ffe606 	bl	6670 <fwp_free_zombie>
    ce5c:	f9401aa0 	ldr	x0, [x21, #48]
    ce60:	b5001160 	cbnz	x0, d08c <fwp_main_thread+0x508>
    ce64:	f94046a0 	ldr	x0, [x21, #136]
    ce68:	b5001120 	cbnz	x0, d08c <fwp_main_thread+0x508>
    ce6c:	b940aab3 	ldr	w19, [x21, #168]
    ce70:	340001f3 	cbz	w19, ceac <fwp_main_thread+0x328>
    ce74:	93407e76 	sxtw	x22, w19
    ce78:	51000673 	sub	w19, w19, #0x1
    ce7c:	d1000ad6 	sub	x22, x22, #0x2
    ce80:	9102c2b7 	add	x23, x21, #0xb0
    ce84:	cb3342d6 	sub	x22, x22, w19, uxtw
    ce88:	93407e73 	sxtw	x19, w19
    ce8c:	d503201f 	nop
    ce90:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    ce94:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    ce98:	b900aab3 	str	w19, [x21, #168]
    ce9c:	d1000673 	sub	x19, x19, #0x1
    cea0:	97ffd69c 	bl	2910 <munmap@plt>
    cea4:	eb1302df 	cmp	x22, x19
    cea8:	54ffff41 	b.ne	ce90 <fwp_main_thread+0x30c>  // b.any
    ceac:	900000b3 	adrp	x19, 20000 <__data_start>
    ceb0:	91004260 	add	x0, x19, #0x10
    ceb4:	b9401000 	ldr	w0, [x0, #16]
    ceb8:	36f80800 	tbz	w0, #31, cfb8 <fwp_main_thread+0x434>
    cebc:	91010295 	add	x21, x20, #0x40
    cec0:	91004273 	add	x19, x19, #0x10
    cec4:	12800001 	mov	w1, #0xffffffff            	// #-1
    cec8:	f94192a0 	ldr	x0, [x21, #800]
    cecc:	b9001261 	str	w1, [x19, #16]
    ced0:	f9418ea1 	ldr	x1, [x21, #792]
    ced4:	b40001e0 	cbz	x0, cf10 <fwp_main_thread+0x38c>
    ced8:	d2800013 	mov	x19, #0x0                   	// #0
    cedc:	d503201f 	nop
    cee0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cee4:	b40000e0 	cbz	x0, cf00 <fwp_main_thread+0x37c>
    cee8:	f9400001 	ldr	x1, [x0]
    ceec:	b5000d01 	cbnz	x1, d08c <fwp_main_thread+0x508>
    cef0:	f9400401 	ldr	x1, [x0, #8]
    cef4:	b5000cc1 	cbnz	x1, d08c <fwp_main_thread+0x508>
    cef8:	97ffdc82 	bl	4100 <fwp_mem_free>
    cefc:	f9418ea1 	ldr	x1, [x21, #792]
    cf00:	91000673 	add	x19, x19, #0x1
    cf04:	f94192a0 	ldr	x0, [x21, #800]
    cf08:	eb00027f 	cmp	x19, x0
    cf0c:	54fffea3 	b.cc	cee0 <fwp_main_thread+0x35c>  // b.lo, b.ul, b.last
    cf10:	aa0103e0 	mov	x0, x1
    cf14:	97ffdc7b 	bl	4100 <fwp_mem_free>
    cf18:	91010280 	add	x0, x20, #0x40
    cf1c:	f9418813 	ldr	x19, [x0, #784]
    cf20:	f9018c1f 	str	xzr, [x0, #792]
    cf24:	f901901f 	str	xzr, [x0, #800]
    cf28:	b40001f3 	cbz	x19, cf64 <fwp_main_thread+0x3e0>
    cf2c:	f9401661 	ldr	x1, [x19, #40]
    cf30:	b5000ae1 	cbnz	x1, d08c <fwp_main_thread+0x508>
    cf34:	f9405661 	ldr	x1, [x19, #168]
    cf38:	b5000aa1 	cbnz	x1, d08c <fwp_main_thread+0x508>
    cf3c:	f9416c01 	ldr	x1, [x0, #728]
    cf40:	b5000a61 	cbnz	x1, d08c <fwp_main_thread+0x508>
    cf44:	f9417400 	ldr	x0, [x0, #744]
    cf48:	b5000a20 	cbnz	x0, d08c <fwp_main_thread+0x508>
    cf4c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cf50:	90000120 	adrp	x0, 30000 <alt.5+0xfc90>
    cf54:	910dc000 	add	x0, x0, #0x370
    cf58:	97ffd61a 	bl	27c0 <memset@plt>
    cf5c:	aa1303e0 	mov	x0, x19
    cf60:	97ffdc68 	bl	4100 <fwp_mem_free>
    cf64:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cf68:	f947ec00 	ldr	x0, [x0, #4056]
    cf6c:	91010294 	add	x20, x20, #0x40
    cf70:	f9400000 	ldr	x0, [x0]
    cf74:	f9000a9f 	str	xzr, [x20, #16]
    cf78:	f9018a9f 	str	xzr, [x20, #784]
    cf7c:	97ffd669 	bl	2920 <fflush@plt>
    cf80:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cf84:	f947f400 	ldr	x0, [x0, #4072]
    cf88:	f9405fe2 	ldr	x2, [sp, #184]
    cf8c:	f9400001 	ldr	x1, [x0]
    cf90:	eb010042 	subs	x2, x2, x1
    cf94:	d2800001 	mov	x1, #0x0                   	// #0
    cf98:	54000761 	b.ne	d084 <fwp_main_thread+0x500>  // b.any
    cf9c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cfa0:	d2800000 	mov	x0, #0x0                   	// #0
    cfa4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cfa8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cfac:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cfb0:	910443ff 	add	sp, sp, #0x110
    cfb4:	d65f03c0 	ret
    cfb8:	97ffd612 	bl	2800 <close@plt>
    cfbc:	17ffffc0 	b	cebc <fwp_main_thread+0x338>
    cfc0:	97fff550 	bl	a500 <f0>
    cfc4:	f9018260 	str	x0, [x19, #768]
    cfc8:	52800021 	mov	w1, #0x1                   	// #1
    cfcc:	b902fa61 	str	w1, [x19, #760]
    cfd0:	17ffff2f 	b	cc8c <fwp_main_thread+0x108>
    cfd4:	97ffddaf 	bl	4690 <fwp_now_ns>
    cfd8:	f94032a1 	ldr	x1, [x21, #96]
    cfdc:	eb01001f 	cmp	x0, x1
    cfe0:	540000ab 	b.lt	cff4 <fwp_main_thread+0x470>  // b.tstop
    cfe4:	394142a0 	ldrb	w0, [x21, #80]
    cfe8:	37000060 	tbnz	w0, #0, cff4 <fwp_main_thread+0x470>
    cfec:	aa1503e0 	mov	x0, x21
    cff0:	97ffd900 	bl	33f0 <fwp_cancel_tree.part.0>
    cff4:	394146a0 	ldrb	w0, [x21, #81]
    cff8:	f9400ad3 	ldr	x19, [x22, #16]
    cffc:	39414a62 	ldrb	w2, [x19, #82]
    d000:	3707e640 	tbnz	w0, #0, ccc8 <fwp_main_thread+0x144>
    d004:	f94032a1 	ldr	x1, [x21, #96]
    d008:	370001c2 	tbnz	w2, #0, d040 <fwp_main_thread+0x4bc>
    d00c:	f9403260 	ldr	x0, [x19, #96]
    d010:	b4000180 	cbz	x0, d040 <fwp_main_thread+0x4bc>
    d014:	b4000061 	cbz	x1, d020 <fwp_main_thread+0x49c>
    d018:	eb01001f 	cmp	x0, x1
    d01c:	9a81d000 	csel	x0, x0, x1, le
    d020:	f94022a1 	ldr	x1, [x21, #64]
    d024:	a911fe77 	stp	x23, xzr, [x19, #280]
    d028:	f9009661 	str	x1, [x19, #296]
    d02c:	b4000261 	cbz	x1, d078 <fwp_main_thread+0x4f4>
    d030:	f9009033 	str	x19, [x1, #288]
    d034:	aa0003e1 	mov	x1, x0
    d038:	f90022b3 	str	x19, [x21, #64]
    d03c:	17ffff2e 	b	ccf4 <fwp_main_thread+0x170>
    d040:	f94022a0 	ldr	x0, [x21, #64]
    d044:	17ffff26 	b	ccdc <fwp_main_thread+0x158>
    d048:	f9001a66 	str	x6, [x19, #48]
    d04c:	17ffff7b 	b	ce38 <fwp_main_thread+0x2b4>
    d050:	a911fe77 	stp	x23, xzr, [x19, #280]
    d054:	f9009660 	str	x0, [x19, #296]
    d058:	b4000040 	cbz	x0, d060 <fwp_main_thread+0x4dc>
    d05c:	f9009013 	str	x19, [x0, #288]
    d060:	f90022b3 	str	x19, [x21, #64]
    d064:	17ffff2b 	b	cd10 <fwp_main_thread+0x18c>
    d068:	f9000040 	str	x0, [x2]
    d06c:	17ffff31 	b	cd30 <fwp_main_thread+0x1ac>
    d070:	f90046c0 	str	x0, [x22, #136]
    d074:	17ffff39 	b	cd58 <fwp_main_thread+0x1d4>
    d078:	aa0003e1 	mov	x1, x0
    d07c:	f90022b3 	str	x19, [x21, #64]
    d080:	17ffff1d 	b	ccf4 <fwp_main_thread+0x170>
    d084:	f90083f9 	str	x25, [sp, #256]
    d088:	97ffd5da 	bl	27f0 <__stack_chk_fail@plt>
    d08c:	f90083f9 	str	x25, [sp, #256]
    d090:	97ffd5ec 	bl	2840 <abort@plt>
    d094:	d503201f 	nop
    d098:	d503201f 	nop
    d09c:	d503201f 	nop

000000000000d0a0 <__divti3>:
    d0a0:	d503245f 	bti	c
    d0a4:	d2800004 	mov	x4, #0x0                   	// #0
    d0a8:	b7f80721 	tbnz	x1, #63, d18c <__divti3+0xec>
    d0ac:	b6f80083 	tbz	x3, #63, d0bc <__divti3+0x1c>
    d0b0:	eb0203e2 	negs	x2, x2
    d0b4:	aa2403e4 	mvn	x4, x4
    d0b8:	da0303e3 	ngc	x3, x3
    d0bc:	aa0203e6 	mov	x6, x2
    d0c0:	aa0003e7 	mov	x7, x0
    d0c4:	aa0103e5 	mov	x5, x1
    d0c8:	b5000583 	cbnz	x3, d178 <__divti3+0xd8>
    d0cc:	eb01005f 	cmp	x2, x1
    d0d0:	54000e69 	b.ls	d29c <__divti3+0x1fc>  // b.plast
    d0d4:	dac01040 	clz	x0, x2
    d0d8:	b40000e0 	cbz	x0, d0f4 <__divti3+0x54>
    d0dc:	4b0003e1 	neg	w1, w0
    d0e0:	9ac020a5 	lsl	x5, x5, x0
    d0e4:	9ac02046 	lsl	x6, x2, x0
    d0e8:	9ac124e1 	lsr	x1, x7, x1
    d0ec:	aa050025 	orr	x5, x1, x5
    d0f0:	9ac020e7 	lsl	x7, x7, x0
    d0f4:	d360fcc8 	lsr	x8, x6, #32
    d0f8:	92407cc2 	and	x2, x6, #0xffffffff
    d0fc:	9ac808a3 	udiv	x3, x5, x8
    d100:	9b089465 	msub	x5, x3, x8, x5
    d104:	aa0303e0 	mov	x0, x3
    d108:	9b037c41 	mul	x1, x2, x3
    d10c:	93c780a5 	extr	x5, x5, x7, #32
    d110:	eb05003f 	cmp	x1, x5
    d114:	540000a9 	b.ls	d128 <__divti3+0x88>  // b.plast
    d118:	ab0500c5 	adds	x5, x6, x5
    d11c:	d1000460 	sub	x0, x3, #0x1
    d120:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d124:	540015a8 	b.hi	d3d8 <__divti3+0x338>  // b.pmore
    d128:	cb0100a5 	sub	x5, x5, x1
    d12c:	9ac808a3 	udiv	x3, x5, x8
    d130:	9b089465 	msub	x5, x3, x8, x5
    d134:	aa0303e1 	mov	x1, x3
    d138:	9b037c42 	mul	x2, x2, x3
    d13c:	aa0703e3 	mov	x3, x7
    d140:	b3607ca3 	bfi	x3, x5, #32, #32
    d144:	eb03005f 	cmp	x2, x3
    d148:	540000c9 	b.ls	d160 <__divti3+0xc0>  // b.plast
    d14c:	ab0300c3 	adds	x3, x6, x3
    d150:	d1000425 	sub	x5, x1, #0x1
    d154:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d158:	d1000821 	sub	x1, x1, #0x2
    d15c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d160:	aa008020 	orr	x0, x1, x0, lsl #32
    d164:	d2800001 	mov	x1, #0x0                   	// #0
    d168:	b4000064 	cbz	x4, d174 <__divti3+0xd4>
    d16c:	eb0003e0 	negs	x0, x0
    d170:	da0103e1 	ngc	x1, x1
    d174:	d65f03c0 	ret
    d178:	eb01007f 	cmp	x3, x1
    d17c:	54000109 	b.ls	d19c <__divti3+0xfc>  // b.plast
    d180:	d2800001 	mov	x1, #0x0                   	// #0
    d184:	d2800000 	mov	x0, #0x0                   	// #0
    d188:	17fffff8 	b	d168 <__divti3+0xc8>
    d18c:	eb0003e0 	negs	x0, x0
    d190:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d194:	da0103e1 	ngc	x1, x1
    d198:	17ffffc5 	b	d0ac <__divti3+0xc>
    d19c:	dac01067 	clz	x7, x3
    d1a0:	b40010e7 	cbz	x7, d3bc <__divti3+0x31c>
    d1a4:	d2800805 	mov	x5, #0x40                  	// #64
    d1a8:	cb0700a5 	sub	x5, x5, x7
    d1ac:	9ac72063 	lsl	x3, x3, x7
    d1b0:	9ac52448 	lsr	x8, x2, x5
    d1b4:	aa030108 	orr	x8, x8, x3
    d1b8:	9ac52426 	lsr	x6, x1, x5
    d1bc:	92407d0a 	and	x10, x8, #0xffffffff
    d1c0:	d360fd09 	lsr	x9, x8, #32
    d1c4:	9ac52403 	lsr	x3, x0, x5
    d1c8:	9ac72021 	lsl	x1, x1, x7
    d1cc:	aa010063 	orr	x3, x3, x1
    d1d0:	9ac72042 	lsl	x2, x2, x7
    d1d4:	9ac908cb 	udiv	x11, x6, x9
    d1d8:	9b099965 	msub	x5, x11, x9, x6
    d1dc:	aa0b03e1 	mov	x1, x11
    d1e0:	9b0b7d46 	mul	x6, x10, x11
    d1e4:	93c380a5 	extr	x5, x5, x3, #32
    d1e8:	eb0500df 	cmp	x6, x5
    d1ec:	540000a9 	b.ls	d200 <__divti3+0x160>  // b.plast
    d1f0:	ab050105 	adds	x5, x8, x5
    d1f4:	d1000561 	sub	x1, x11, #0x1
    d1f8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d1fc:	54000f48 	b.hi	d3e4 <__divti3+0x344>  // b.pmore
    d200:	cb0600a6 	sub	x6, x5, x6
    d204:	9ac908cb 	udiv	x11, x6, x9
    d208:	9b099969 	msub	x9, x11, x9, x6
    d20c:	aa0b03e5 	mov	x5, x11
    d210:	9b0b7d4a 	mul	x10, x10, x11
    d214:	b3607d23 	bfi	x3, x9, #32, #32
    d218:	eb03015f 	cmp	x10, x3
    d21c:	540000a9 	b.ls	d230 <__divti3+0x190>  // b.plast
    d220:	ab030103 	adds	x3, x8, x3
    d224:	d1000565 	sub	x5, x11, #0x1
    d228:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d22c:	54000e28 	b.hi	d3f0 <__divti3+0x350>  // b.pmore
    d230:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d234:	92407c48 	and	x8, x2, #0xffffffff
    d238:	2a0503e5 	mov	w5, w5
    d23c:	d360fc42 	lsr	x2, x2, #32
    d240:	d360fc26 	lsr	x6, x1, #32
    d244:	cb0a0063 	sub	x3, x3, x10
    d248:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d24c:	9b087caa 	mul	x10, x5, x8
    d250:	9b087cc8 	mul	x8, x6, x8
    d254:	9b0220a5 	madd	x5, x5, x2, x8
    d258:	9b027cc6 	mul	x6, x6, x2
    d25c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d260:	8b0900c5 	add	x5, x6, x9
    d264:	eb02011f 	cmp	x8, x2
    d268:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d26c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d270:	eb06007f 	cmp	x3, x6
    d274:	540000e3 	b.cc	d290 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d278:	92407d4a 	and	x10, x10, #0xffffffff
    d27c:	9ac72000 	lsl	x0, x0, x7
    d280:	8b028142 	add	x2, x10, x2, lsl #32
    d284:	eb02001f 	cmp	x0, x2
    d288:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d28c:	54000a01 	b.ne	d3cc <__divti3+0x32c>  // b.any
    d290:	d1000420 	sub	x0, x1, #0x1
    d294:	d2800001 	mov	x1, #0x0                   	// #0
    d298:	17ffffb4 	b	d168 <__divti3+0xc8>
    d29c:	b5000062 	cbnz	x2, d2a8 <__divti3+0x208>
    d2a0:	d2800022 	mov	x2, #0x1                   	// #1
    d2a4:	9ac30846 	udiv	x6, x2, x3
    d2a8:	dac010c8 	clz	x8, x6
    d2ac:	b5000408 	cbnz	x8, d32c <__divti3+0x28c>
    d2b0:	d360fcc9 	lsr	x9, x6, #32
    d2b4:	92407cc5 	and	x5, x6, #0xffffffff
    d2b8:	cb060023 	sub	x3, x1, x6
    d2bc:	d2800021 	mov	x1, #0x1                   	// #1
    d2c0:	9ac90868 	udiv	x8, x3, x9
    d2c4:	9b098d03 	msub	x3, x8, x9, x3
    d2c8:	aa0803e0 	mov	x0, x8
    d2cc:	9b057d02 	mul	x2, x8, x5
    d2d0:	93c78063 	extr	x3, x3, x7, #32
    d2d4:	eb03005f 	cmp	x2, x3
    d2d8:	540000a9 	b.ls	d2ec <__divti3+0x24c>  // b.plast
    d2dc:	ab0300c3 	adds	x3, x6, x3
    d2e0:	d1000500 	sub	x0, x8, #0x1
    d2e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d2e8:	54000968 	b.hi	d414 <__divti3+0x374>  // b.pmore
    d2ec:	cb020063 	sub	x3, x3, x2
    d2f0:	9ac90862 	udiv	x2, x3, x9
    d2f4:	aa0203e8 	mov	x8, x2
    d2f8:	9b098c42 	msub	x2, x2, x9, x3
    d2fc:	aa0703e3 	mov	x3, x7
    d300:	9b057d05 	mul	x5, x8, x5
    d304:	b3607c43 	bfi	x3, x2, #32, #32
    d308:	eb0300bf 	cmp	x5, x3
    d30c:	540000c9 	b.ls	d324 <__divti3+0x284>  // b.plast
    d310:	ab0300c2 	adds	x2, x6, x3
    d314:	d1000503 	sub	x3, x8, #0x1
    d318:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d31c:	d1000908 	sub	x8, x8, #0x2
    d320:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d324:	aa008100 	orr	x0, x8, x0, lsl #32
    d328:	17ffff90 	b	d168 <__divti3+0xc8>
    d32c:	9ac820c6 	lsl	x6, x6, x8
    d330:	d2800803 	mov	x3, #0x40                  	// #64
    d334:	cb080063 	sub	x3, x3, x8
    d338:	d360fcc9 	lsr	x9, x6, #32
    d33c:	9ac82027 	lsl	x7, x1, x8
    d340:	92407cc5 	and	x5, x6, #0xffffffff
    d344:	9ac32422 	lsr	x2, x1, x3
    d348:	9ac32403 	lsr	x3, x0, x3
    d34c:	aa070063 	orr	x3, x3, x7
    d350:	9ac9084a 	udiv	x10, x2, x9
    d354:	9ac82007 	lsl	x7, x0, x8
    d358:	9b098940 	msub	x0, x10, x9, x2
    d35c:	aa0a03e1 	mov	x1, x10
    d360:	9b0a7ca2 	mul	x2, x5, x10
    d364:	93c38000 	extr	x0, x0, x3, #32
    d368:	eb00005f 	cmp	x2, x0
    d36c:	540000a9 	b.ls	d380 <__divti3+0x2e0>  // b.plast
    d370:	ab0000c0 	adds	x0, x6, x0
    d374:	d1000541 	sub	x1, x10, #0x1
    d378:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d37c:	54000468 	b.hi	d408 <__divti3+0x368>  // b.pmore
    d380:	cb020000 	sub	x0, x0, x2
    d384:	9ac9080a 	udiv	x10, x0, x9
    d388:	9b098140 	msub	x0, x10, x9, x0
    d38c:	aa0a03e2 	mov	x2, x10
    d390:	9b0a7ca8 	mul	x8, x5, x10
    d394:	b3607c03 	bfi	x3, x0, #32, #32
    d398:	eb03011f 	cmp	x8, x3
    d39c:	540000a9 	b.ls	d3b0 <__divti3+0x310>  // b.plast
    d3a0:	ab0300c3 	adds	x3, x6, x3
    d3a4:	d1000542 	sub	x2, x10, #0x1
    d3a8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d3ac:	54000288 	b.hi	d3fc <__divti3+0x35c>  // b.pmore
    d3b0:	cb080063 	sub	x3, x3, x8
    d3b4:	aa018041 	orr	x1, x2, x1, lsl #32
    d3b8:	17ffffc2 	b	d2c0 <__divti3+0x220>
    d3bc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d3c0:	d2800001 	mov	x1, #0x0                   	// #0
    d3c4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d3c8:	17ffff68 	b	d168 <__divti3+0xc8>
    d3cc:	aa0103e0 	mov	x0, x1
    d3d0:	d2800001 	mov	x1, #0x0                   	// #0
    d3d4:	17ffff65 	b	d168 <__divti3+0xc8>
    d3d8:	d1000860 	sub	x0, x3, #0x2
    d3dc:	8b0600a5 	add	x5, x5, x6
    d3e0:	17ffff52 	b	d128 <__divti3+0x88>
    d3e4:	d1000961 	sub	x1, x11, #0x2
    d3e8:	8b0800a5 	add	x5, x5, x8
    d3ec:	17ffff85 	b	d200 <__divti3+0x160>
    d3f0:	d1000965 	sub	x5, x11, #0x2
    d3f4:	8b080063 	add	x3, x3, x8
    d3f8:	17ffff8e 	b	d230 <__divti3+0x190>
    d3fc:	d1000942 	sub	x2, x10, #0x2
    d400:	8b060063 	add	x3, x3, x6
    d404:	17ffffeb 	b	d3b0 <__divti3+0x310>
    d408:	d1000941 	sub	x1, x10, #0x2
    d40c:	8b060000 	add	x0, x0, x6
    d410:	17ffffdc 	b	d380 <__divti3+0x2e0>
    d414:	d1000900 	sub	x0, x8, #0x2
    d418:	8b060063 	add	x3, x3, x6
    d41c:	17ffffb4 	b	d2ec <__divti3+0x24c>

000000000000d420 <__modti3>:
    d420:	d503245f 	bti	c
    d424:	d2800004 	mov	x4, #0x0                   	// #0
    d428:	b6f80081 	tbz	x1, #63, d438 <__modti3+0x18>
    d42c:	eb0003e0 	negs	x0, x0
    d430:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d434:	da0103e1 	ngc	x1, x1
    d438:	f100007f 	cmp	x3, #0x0
    d43c:	5400128b 	b.lt	d68c <__modti3+0x26c>  // b.tstop
    d440:	aa0003e7 	mov	x7, x0
    d444:	aa0103e6 	mov	x6, x1
    d448:	540004e1 	b.ne	d4e4 <__modti3+0xc4>  // b.any
    d44c:	eb02003f 	cmp	x1, x2
    d450:	54000dc2 	b.cs	d608 <__modti3+0x1e8>  // b.hs, b.nlast
    d454:	dac01043 	clz	x3, x2
    d458:	aa0303e5 	mov	x5, x3
    d45c:	b40000e3 	cbz	x3, d478 <__modti3+0x58>
    d460:	4b0303e6 	neg	w6, w3
    d464:	9ac32021 	lsl	x1, x1, x3
    d468:	9ac32042 	lsl	x2, x2, x3
    d46c:	9ac62406 	lsr	x6, x0, x6
    d470:	aa0100c6 	orr	x6, x6, x1
    d474:	9ac32007 	lsl	x7, x0, x3
    d478:	d360fc40 	lsr	x0, x2, #32
    d47c:	92407c43 	and	x3, x2, #0xffffffff
    d480:	9ac008c1 	udiv	x1, x6, x0
    d484:	9b009826 	msub	x6, x1, x0, x6
    d488:	9b017c61 	mul	x1, x3, x1
    d48c:	93c780c6 	extr	x6, x6, x7, #32
    d490:	eb06003f 	cmp	x1, x6
    d494:	540000a9 	b.ls	d4a8 <__modti3+0x88>  // b.plast
    d498:	ab060046 	adds	x6, x2, x6
    d49c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d4a0:	8b0200c8 	add	x8, x6, x2
    d4a4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d4a8:	cb0100c6 	sub	x6, x6, x1
    d4ac:	9ac008c8 	udiv	x8, x6, x0
    d4b0:	9b009901 	msub	x1, x8, x0, x6
    d4b4:	aa0703e0 	mov	x0, x7
    d4b8:	9b087c63 	mul	x3, x3, x8
    d4bc:	b3607c20 	bfi	x0, x1, #32, #32
    d4c0:	eb00007f 	cmp	x3, x0
    d4c4:	54001088 	b.hi	d6d4 <__modti3+0x2b4>  // b.pmore
    d4c8:	cb030000 	sub	x0, x0, x3
    d4cc:	9ac52400 	lsr	x0, x0, x5
    d4d0:	d2800001 	mov	x1, #0x0                   	// #0
    d4d4:	b4000064 	cbz	x4, d4e0 <__modti3+0xc0>
    d4d8:	eb0003e0 	negs	x0, x0
    d4dc:	da0103e1 	ngc	x1, x1
    d4e0:	d65f03c0 	ret
    d4e4:	dac01066 	clz	x6, x3
    d4e8:	eb03003f 	cmp	x1, x3
    d4ec:	54ffff43 	b.cc	d4d4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d4f0:	93407cc5 	sxtw	x5, w6
    d4f4:	d2800808 	mov	x8, #0x40                  	// #64
    d4f8:	cb050108 	sub	x8, x8, x5
    d4fc:	9ac62063 	lsl	x3, x3, x6
    d500:	9ac62025 	lsl	x5, x1, x6
    d504:	9ac82447 	lsr	x7, x2, x8
    d508:	aa0300e7 	orr	x7, x7, x3
    d50c:	9ac82423 	lsr	x3, x1, x8
    d510:	92407cec 	and	x12, x7, #0xffffffff
    d514:	d360fcea 	lsr	x10, x7, #32
    d518:	9ac82401 	lsr	x1, x0, x8
    d51c:	aa050021 	orr	x1, x1, x5
    d520:	9ac62042 	lsl	x2, x2, x6
    d524:	9ac62000 	lsl	x0, x0, x6
    d528:	9aca086b 	udiv	x11, x3, x10
    d52c:	9b0a8d63 	msub	x3, x11, x10, x3
    d530:	aa0b03e5 	mov	x5, x11
    d534:	9b0b7d89 	mul	x9, x12, x11
    d538:	93c18063 	extr	x3, x3, x1, #32
    d53c:	eb03013f 	cmp	x9, x3
    d540:	540000a9 	b.ls	d554 <__modti3+0x134>  // b.plast
    d544:	ab0300e3 	adds	x3, x7, x3
    d548:	d1000565 	sub	x5, x11, #0x1
    d54c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d550:	54001168 	b.hi	d77c <__modti3+0x35c>  // b.pmore
    d554:	cb090063 	sub	x3, x3, x9
    d558:	9aca086b 	udiv	x11, x3, x10
    d55c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d560:	aa0b03e9 	mov	x9, x11
    d564:	9b0b7d8c 	mul	x12, x12, x11
    d568:	b3607d41 	bfi	x1, x10, #32, #32
    d56c:	eb01019f 	cmp	x12, x1
    d570:	540000a9 	b.ls	d584 <__modti3+0x164>  // b.plast
    d574:	ab0100e1 	adds	x1, x7, x1
    d578:	d1000569 	sub	x9, x11, #0x1
    d57c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d580:	54000f88 	b.hi	d770 <__modti3+0x350>  // b.pmore
    d584:	aa058123 	orr	x3, x9, x5, lsl #32
    d588:	92407c4b 	and	x11, x2, #0xffffffff
    d58c:	2a0903e9 	mov	w9, w9
    d590:	d360fc4a 	lsr	x10, x2, #32
    d594:	d360fc63 	lsr	x3, x3, #32
    d598:	cb0c0021 	sub	x1, x1, x12
    d59c:	aa0a03ec 	mov	x12, x10
    d5a0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d5a4:	9b0b7d25 	mul	x5, x9, x11
    d5a8:	9b0b7c6b 	mul	x11, x3, x11
    d5ac:	9b0a2d29 	madd	x9, x9, x10, x11
    d5b0:	92407caa 	and	x10, x5, #0xffffffff
    d5b4:	9b0c7c63 	mul	x3, x3, x12
    d5b8:	8b458125 	add	x5, x9, x5, lsr #32
    d5bc:	8b0d0069 	add	x9, x3, x13
    d5c0:	eb05017f 	cmp	x11, x5
    d5c4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d5c8:	8b058149 	add	x9, x10, x5, lsl #32
    d5cc:	8b458063 	add	x3, x3, x5, lsr #32
    d5d0:	eb03003f 	cmp	x1, x3
    d5d4:	54000063 	b.cc	d5e0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d5d8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d5dc:	54000082 	b.cs	d5ec <__modti3+0x1cc>  // b.hs, b.nlast
    d5e0:	eb020129 	subs	x9, x9, x2
    d5e4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d5e8:	cb070063 	sub	x3, x3, x7
    d5ec:	eb090000 	subs	x0, x0, x9
    d5f0:	da030021 	sbc	x1, x1, x3
    d5f4:	9ac62400 	lsr	x0, x0, x6
    d5f8:	9ac82028 	lsl	x8, x1, x8
    d5fc:	aa000100 	orr	x0, x8, x0
    d600:	9ac62421 	lsr	x1, x1, x6
    d604:	17ffffb4 	b	d4d4 <__modti3+0xb4>
    d608:	b5000062 	cbnz	x2, d614 <__modti3+0x1f4>
    d60c:	d2800023 	mov	x3, #0x1                   	// #1
    d610:	9ac20862 	udiv	x2, x3, x2
    d614:	dac01048 	clz	x8, x2
    d618:	aa0803e5 	mov	x5, x8
    d61c:	b5000668 	cbnz	x8, d6e8 <__modti3+0x2c8>
    d620:	cb020020 	sub	x0, x1, x2
    d624:	d360fc49 	lsr	x9, x2, #32
    d628:	92407c4a 	and	x10, x2, #0xffffffff
    d62c:	9ac90801 	udiv	x1, x0, x9
    d630:	9b098020 	msub	x0, x1, x9, x0
    d634:	9b0a7c21 	mul	x1, x1, x10
    d638:	93c78000 	extr	x0, x0, x7, #32
    d63c:	eb00003f 	cmp	x1, x0
    d640:	540000a9 	b.ls	d654 <__modti3+0x234>  // b.plast
    d644:	ab000040 	adds	x0, x2, x0
    d648:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d64c:	8b020003 	add	x3, x0, x2
    d650:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d654:	cb010001 	sub	x1, x0, x1
    d658:	9ac90820 	udiv	x0, x1, x9
    d65c:	9b098403 	msub	x3, x0, x9, x1
    d660:	aa0703e1 	mov	x1, x7
    d664:	9b0a7c00 	mul	x0, x0, x10
    d668:	b3607c61 	bfi	x1, x3, #32, #32
    d66c:	eb01001f 	cmp	x0, x1
    d670:	540000a9 	b.ls	d684 <__modti3+0x264>  // b.plast
    d674:	ab010041 	adds	x1, x2, x1
    d678:	8b020022 	add	x2, x1, x2
    d67c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d680:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d684:	cb000020 	sub	x0, x1, x0
    d688:	17ffff91 	b	d4cc <__modti3+0xac>
    d68c:	eb0203e5 	negs	x5, x2
    d690:	aa0003e7 	mov	x7, x0
    d694:	da0303e8 	ngc	x8, x3
    d698:	aa0503e2 	mov	x2, x5
    d69c:	aa0803e3 	mov	x3, x8
    d6a0:	aa0103e6 	mov	x6, x1
    d6a4:	b4ffed48 	cbz	x8, d44c <__modti3+0x2c>
    d6a8:	eb01011f 	cmp	x8, x1
    d6ac:	54fff148 	b.hi	d4d4 <__modti3+0xb4>  // b.pmore
    d6b0:	dac01109 	clz	x9, x8
    d6b4:	2a0903e6 	mov	w6, w9
    d6b8:	b5fff1c9 	cbnz	x9, d4f0 <__modti3+0xd0>
    d6bc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d6c0:	54000068 	b.hi	d6cc <__modti3+0x2ac>  // b.pmore
    d6c4:	eb050007 	subs	x7, x0, x5
    d6c8:	da080021 	sbc	x1, x1, x8
    d6cc:	aa0703e0 	mov	x0, x7
    d6d0:	17ffff81 	b	d4d4 <__modti3+0xb4>
    d6d4:	ab000040 	adds	x0, x2, x0
    d6d8:	8b020002 	add	x2, x0, x2
    d6dc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d6e0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d6e4:	17ffff79 	b	d4c8 <__modti3+0xa8>
    d6e8:	9ac82042 	lsl	x2, x2, x8
    d6ec:	d2800803 	mov	x3, #0x40                  	// #64
    d6f0:	cb080063 	sub	x3, x3, x8
    d6f4:	d360fc49 	lsr	x9, x2, #32
    d6f8:	9ac82027 	lsl	x7, x1, x8
    d6fc:	92407c4a 	and	x10, x2, #0xffffffff
    d700:	9ac32426 	lsr	x6, x1, x3
    d704:	9ac32403 	lsr	x3, x0, x3
    d708:	aa070063 	orr	x3, x3, x7
    d70c:	9ac908c1 	udiv	x1, x6, x9
    d710:	9ac82007 	lsl	x7, x0, x8
    d714:	9b099820 	msub	x0, x1, x9, x6
    d718:	9b017d41 	mul	x1, x10, x1
    d71c:	93c38000 	extr	x0, x0, x3, #32
    d720:	eb00003f 	cmp	x1, x0
    d724:	540000a9 	b.ls	d738 <__modti3+0x318>  // b.plast
    d728:	ab000040 	adds	x0, x2, x0
    d72c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d730:	8b020006 	add	x6, x0, x2
    d734:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d738:	cb010000 	sub	x0, x0, x1
    d73c:	9ac90801 	udiv	x1, x0, x9
    d740:	9b098026 	msub	x6, x1, x9, x0
    d744:	aa0303e0 	mov	x0, x3
    d748:	9b017d41 	mul	x1, x10, x1
    d74c:	b3607cc0 	bfi	x0, x6, #32, #32
    d750:	eb00003f 	cmp	x1, x0
    d754:	540000a9 	b.ls	d768 <__modti3+0x348>  // b.plast
    d758:	ab000040 	adds	x0, x2, x0
    d75c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d760:	8b020003 	add	x3, x0, x2
    d764:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d768:	cb010000 	sub	x0, x0, x1
    d76c:	17ffffb0 	b	d62c <__modti3+0x20c>
    d770:	d1000969 	sub	x9, x11, #0x2
    d774:	8b070021 	add	x1, x1, x7
    d778:	17ffff83 	b	d584 <__modti3+0x164>
    d77c:	d1000965 	sub	x5, x11, #0x2
    d780:	8b070063 	add	x3, x3, x7
    d784:	17ffff74 	b	d554 <__modti3+0x134>
    d788:	d503201f 	nop
    d78c:	d503201f 	nop

000000000000d790 <atexit>:
    d790:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d794:	f0000082 	adrp	x2, 20000 <__data_start>
    d798:	d2800001 	mov	x1, #0x0                   	// #0
    d79c:	910003fd 	mov	x29, sp
    d7a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d7a4:	f9400442 	ldr	x2, [x2, #8]
    d7a8:	17ffd3d2 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d7ac <_fini>:
    d7ac:	d503201f 	nop
    d7b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d7b4:	910003fd 	mov	x29, sp
    d7b8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d7bc:	d65f03c0 	ret
