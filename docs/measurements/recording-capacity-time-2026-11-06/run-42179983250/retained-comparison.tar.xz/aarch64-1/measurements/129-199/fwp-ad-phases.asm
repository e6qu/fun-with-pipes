
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <__divti3+0x240>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	912180a5 	add	x5, x5, #0x860
    2b20:	f0000044 	adrp	x4, d000 <__divti3+0x240>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	9121a084 	add	x4, x4, #0x868
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	94000590 	bl	4190 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b7c:	f947ee94 	ldr	x20, [x20, #4056]
    2b80:	f9400282 	ldr	x2, [x20]
    2b84:	f90043f5 	str	x21, [sp, #128]
    2b88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b8c:	9101c2a1 	add	x1, x21, #0x70
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe930>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9006420 	str	x0, [x1, #200]
    2bac:	94000799 	bl	4a10 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2bb4:	912de000 	add	x0, x0, #0xb78
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f3 	mov	x19, x0
    2bc8:	350008c1 	cbnz	w1, 2ce0 <main+0x180>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	350007e0 	cbnz	w0, 2cd4 <main+0x174>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b5000620 	cbnz	x0, 2cc8 <main+0x168>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f3 	add	x19, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1303e0 	mov	x0, x19
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007a0 	cbnz	w0, 2d28 <main+0x1c8>
    2c38:	aa1303e0 	mov	x0, x19
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000660 	cbnz	w0, 2d10 <main+0x1b0>
    2c48:	aa1303e1 	mov	x1, x19
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x1e10>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91221042 	add	x2, x2, #0x884
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	2a0103f3 	mov	w19, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	35000613 	cbnz	w19, 2d34 <main+0x1d4>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c2b5 	add	x21, x21, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435aa0 	ldr	w0, [x21, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	54000481 	b.ne	2d40 <main+0x1e0>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2ccc:	912ea000 	add	x0, x0, #0xba8
    2cd0:	94000530 	bl	4190 <fwp_trap>
    2cd4:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2cd8:	912e2000 	add	x0, x0, #0xb88
    2cdc:	9400052d 	bl	4190 <fwp_trap>
    2ce0:	910003e1 	mov	x1, sp
    2ce4:	52800142 	mov	w2, #0xa                   	// #10
    2ce8:	97ffff46 	bl	2a00 <strtoull@plt>
    2cec:	f94003e0 	ldr	x0, [sp]
    2cf0:	39400000 	ldrb	w0, [x0]
    2cf4:	35fff6c0 	cbnz	w0, 2bcc <main+0x6c>
    2cf8:	39400260 	ldrb	w0, [x19]
    2cfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2d00:	5100ac00 	sub	w0, w0, #0x2b
    2d04:	6a01001f 	tst	w0, w1
    2d08:	54fff620 	b.eq	2bcc <main+0x6c>  // b.none
    2d0c:	17ffffbf 	b	2c08 <main+0xa8>
    2d10:	aa1303e0 	mov	x0, x19
    2d14:	97fffeeb 	bl	28c0 <pthread_attr_destroy@plt>
    2d18:	35000160 	cbnz	w0, 2d44 <main+0x1e4>
    2d1c:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2d20:	91300000 	add	x0, x0, #0xc00
    2d24:	9400051b 	bl	4190 <fwp_trap>
    2d28:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2d2c:	912f4000 	add	x0, x0, #0xbd0
    2d30:	94000518 	bl	4190 <fwp_trap>
    2d34:	f0000040 	adrp	x0, d000 <__divti3+0x240>
    2d38:	9130a000 	add	x0, x0, #0xc28
    2d3c:	94000515 	bl	4190 <fwp_trap>
    2d40:	97fffef4 	bl	2910 <__stack_chk_fail@plt>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xb20>
    2f34:	910ac021 	add	x1, x1, #0x2b0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    30d0:	9113a000 	add	x0, x0, #0x4e8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb20>
    3198:	910a4021 	add	x1, x1, #0x290
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    31d0:	91140000 	add	x0, x0, #0x500
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000042 	adrp	x2, d000 <__divti3+0x240>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000056 	adrp	x22, d000 <__divti3+0x240>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	f0000058 	adrp	x24, e000 <_IO_stdin_used+0xb20>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	91152042 	add	x2, x2, #0x548
    3260:	911682d6 	add	x22, x22, #0x5a0
    3264:	9100c318 	add	x24, x24, #0x30
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000059 	adrp	x25, d000 <__divti3+0x240>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	91166323 	add	x3, x25, #0x598
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	9116c000 	add	x0, x0, #0x5b0
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    35f0:	9113a000 	add	x0, x0, #0x4e8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000041 	adrp	x1, d000 <__divti3+0x240>
    3830:	aa1303e0 	mov	x0, x19
    3834:	9116e021 	add	x1, x1, #0x5b8
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <__divti3+0x240>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91170021 	add	x1, x1, #0x5c0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <__divti3+0x240>
    3860:	91172021 	add	x1, x1, #0x5c8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_format_g.constprop.0>:
    3880:	d10483ff 	sub	sp, sp, #0x120
    3884:	d0000044 	adrp	x4, d000 <__divti3+0x240>
    3888:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    388c:	f947f442 	ldr	x2, [x2, #4072]
    3890:	91174084 	add	x4, x4, #0x5d0
    3894:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3898:	9102c3fd 	add	x29, sp, #0xb0
    389c:	d2800803 	mov	x3, #0x40                  	// #64
    38a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    38a4:	93407c38 	sxtw	x24, w1
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	fd008be8 	str	d8, [sp, #272]
    38b0:	1e604008 	fmov	d8, d0
    38b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    38b8:	910083f4 	add	x20, sp, #0x20
    38bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38c0:	aa0003f5 	mov	x21, x0
    38c4:	a91073fb 	stp	x27, x28, [sp, #256]
    38c8:	5100071c 	sub	w28, w24, #0x1
    38cc:	2a1c03e5 	mov	w5, w28
    38d0:	f9400040 	ldr	x0, [x2]
    38d4:	f90057e0 	str	x0, [sp, #168]
    38d8:	d2800000 	mov	x0, #0x0                   	// #0
    38dc:	52800042 	mov	w2, #0x2                   	// #2
    38e0:	aa1403e0 	mov	x0, x20
    38e4:	97fffbe7 	bl	2880 <__snprintf_chk@plt>
    38e8:	52800ca1 	mov	w1, #0x65                  	// #101
    38ec:	aa1403e0 	mov	x0, x20
    38f0:	97fffc40 	bl	29f0 <strchr@plt>
    38f4:	aa0003f3 	mov	x19, x0
    38f8:	52800142 	mov	w2, #0xa                   	// #10
    38fc:	91000400 	add	x0, x0, #0x1
    3900:	d2800001 	mov	x1, #0x0                   	// #0
    3904:	97fffc2b 	bl	29b0 <strtol@plt>
    3908:	aa0003f7 	mov	x23, x0
    390c:	11001400 	add	w0, w0, #0x5
    3910:	7100541f 	cmp	w0, #0x15
    3914:	54000d68 	b.hi	3ac0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3918:	4b170385 	sub	w5, w28, w23
    391c:	710000bf 	cmp	w5, #0x0
    3920:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3924:	54000b80 	b.eq	3a94 <fwp_format_g.constprop.0+0x214>  // b.none
    3928:	394083e0 	ldrb	w0, [sp, #32]
    392c:	cb180273 	sub	x19, x19, x24
    3930:	91000673 	add	x19, x19, #0x1
    3934:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3938:	7100b41f 	cmp	w0, #0x2d
    393c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3940:	1a9f17e4 	cset	w4, eq	// eq = none
    3944:	cb010266 	sub	x6, x19, x1
    3948:	d10004da 	sub	x26, x6, #0x1
    394c:	540018a0 	b.eq	3c60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3950:	910183f9 	add	x25, sp, #0x60
    3954:	d280091b 	mov	x27, #0x48                  	// #72
    3958:	aa1903e7 	mov	x7, x25
    395c:	91000423 	add	x3, x1, #0x1
    3960:	91011cc6 	add	x6, x6, #0x47
    3964:	910004f6 	add	x22, x7, #0x1
    3968:	37f80ff7 	tbnz	w23, #31, 3b64 <fwp_format_g.constprop.0+0x2e4>
    396c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3970:	93407ef7 	sxtw	x23, w23
    3974:	390000e4 	strb	w4, [x7]
    3978:	aa1303e1 	mov	x1, x19
    397c:	aa1703e2 	mov	x2, x23
    3980:	aa1603e0 	mov	x0, x22
    3984:	b9000be5 	str	w5, [sp, #8]
    3988:	cb170374 	sub	x20, x27, x23
    398c:	a9011be3 	stp	x3, x6, [sp, #16]
    3990:	97fffb74 	bl	2760 <memcpy@plt>
    3994:	d1000694 	sub	x20, x20, #0x1
    3998:	f9400be3 	ldr	x3, [sp, #16]
    399c:	8b1702d6 	add	x22, x22, x23
    39a0:	aa1603e0 	mov	x0, x22
    39a4:	aa1a03e2 	mov	x2, x26
    39a8:	aa0303e1 	mov	x1, x3
    39ac:	aa1403e3 	mov	x3, x20
    39b0:	97fffbac 	bl	2860 <__memcpy_chk@plt>
    39b4:	8b1a02d6 	add	x22, x22, x26
    39b8:	f9400fe6 	ldr	x6, [sp, #24]
    39bc:	d2800900 	mov	x0, #0x48                  	// #72
    39c0:	b9400be5 	ldr	w5, [sp, #8]
    39c4:	8b170261 	add	x1, x19, x23
    39c8:	cb1400c3 	sub	x3, x6, x20
    39cc:	cb060294 	sub	x20, x20, x6
    39d0:	f101207f 	cmp	x3, #0x48
    39d4:	93407cb8 	sxtw	x24, w5
    39d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39dc:	aa1803e2 	mov	x2, x24
    39e0:	8b1802d3 	add	x19, x22, x24
    39e4:	8b140063 	add	x3, x3, x20
    39e8:	aa1603e0 	mov	x0, x22
    39ec:	97fffb9d 	bl	2860 <__memcpy_chk@plt>
    39f0:	cb190273 	sub	x19, x19, x25
    39f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    39f8:	eb00027f 	cmp	x19, x0
    39fc:	aa1903e1 	mov	x1, x25
    3a00:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a04:	aa1503e0 	mov	x0, x21
    3a08:	aa1303e2 	mov	x2, x19
    3a0c:	97fffb55 	bl	2760 <memcpy@plt>
    3a10:	38336abf 	strb	wzr, [x21, x19]
    3a14:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	97fffb61 	bl	27a0 <strlen@plt>
    3a20:	aa0003f3 	mov	x19, x0
    3a24:	528005c1 	mov	w1, #0x2e                  	// #46
    3a28:	aa1503e0 	mov	x0, x21
    3a2c:	97fffbf1 	bl	29f0 <strchr@plt>
    3a30:	b4000140 	cbz	x0, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a34:	b4000133 	cbz	x19, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a38:	aa1303e1 	mov	x1, x19
    3a3c:	d1000673 	sub	x19, x19, #0x1
    3a40:	38736aa0 	ldrb	w0, [x21, x19]
    3a44:	7100c01f 	cmp	w0, #0x30
    3a48:	54001001 	b.ne	3c48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    3a4c:	38336abf 	strb	wzr, [x21, x19]
    3a50:	b5ffff53 	cbnz	x19, 3a38 <fwp_format_g.constprop.0+0x1b8>
    3a54:	d503201f 	nop
    3a58:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a5c:	f947f400 	ldr	x0, [x0, #4072]
    3a60:	f94057e2 	ldr	x2, [sp, #168]
    3a64:	f9400001 	ldr	x1, [x0]
    3a68:	eb010042 	subs	x2, x2, x1
    3a6c:	d2800001 	mov	x1, #0x0                   	// #0
    3a70:	54001061 	b.ne	3c7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3a74:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a78:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a7c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a80:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a84:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a88:	fd408be8 	ldr	d8, [sp, #272]
    3a8c:	910483ff 	add	sp, sp, #0x120
    3a90:	d65f03c0 	ret
    3a94:	1e604100 	fmov	d0, d8
    3a98:	710000bf 	cmp	w5, #0x0
    3a9c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3aa0:	aa1503e0 	mov	x0, x21
    3aa4:	d0000044 	adrp	x4, d000 <__divti3+0x240>
    3aa8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3aac:	9117a084 	add	x4, x4, #0x5e8
    3ab0:	52800042 	mov	w2, #0x2                   	// #2
    3ab4:	d2803201 	mov	x1, #0x190                 	// #400
    3ab8:	97fffb72 	bl	2880 <__snprintf_chk@plt>
    3abc:	17ffffd7 	b	3a18 <fwp_format_g.constprop.0+0x198>
    3ac0:	cb140273 	sub	x19, x19, x20
    3ac4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ac8:	910183f9 	add	x25, sp, #0x60
    3acc:	aa1303e2 	mov	x2, x19
    3ad0:	aa1403e1 	mov	x1, x20
    3ad4:	aa1903e0 	mov	x0, x25
    3ad8:	d2800803 	mov	x3, #0x40                  	// #64
    3adc:	97fffb61 	bl	2860 <__memcpy_chk@plt>
    3ae0:	38336b3f 	strb	wzr, [x25, x19]
    3ae4:	aa1903e0 	mov	x0, x25
    3ae8:	528005c1 	mov	w1, #0x2e                  	// #46
    3aec:	97fffbc1 	bl	29f0 <strchr@plt>
    3af0:	b40001c0 	cbz	x0, 3b28 <fwp_format_g.constprop.0+0x2a8>
    3af4:	b50000b3 	cbnz	x19, 3b08 <fwp_format_g.constprop.0+0x288>
    3af8:	1400000c 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3afc:	381ff01f 	sturb	wzr, [x0, #-1]
    3b00:	f1000673 	subs	x19, x19, #0x1
    3b04:	54000120 	b.eq	3b28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3b08:	8b130320 	add	x0, x25, x19
    3b0c:	385ff001 	ldurb	w1, [x0, #-1]
    3b10:	7100c03f 	cmp	w1, #0x30
    3b14:	54ffff40 	b.eq	3afc <fwp_format_g.constprop.0+0x27c>  // b.none
    3b18:	d1000673 	sub	x19, x19, #0x1
    3b1c:	38736b20 	ldrb	w0, [x25, x19]
    3b20:	7100b81f 	cmp	w0, #0x2e
    3b24:	54000a80 	b.eq	3c74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3b28:	710002ff 	cmp	w23, #0x0
    3b2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3b30:	aa1903e5 	mov	x5, x25
    3b34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	52800566 	mov	w6, #0x2b                  	// #43
    3b40:	d0000044 	adrp	x4, d000 <__divti3+0x240>
    3b44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b48:	91176084 	add	x4, x4, #0x5d8
    3b4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b50:	52800042 	mov	w2, #0x2                   	// #2
    3b54:	d2803201 	mov	x1, #0x190                 	// #400
    3b58:	97fffb4a 	bl	2880 <__snprintf_chk@plt>
    3b5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b60:	17ffffbe 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3b64:	52800605 	mov	w5, #0x30                  	// #48
    3b68:	390000e5 	strb	w5, [x7]
    3b6c:	d100077b 	sub	x27, x27, #0x1
    3b70:	aa0303e1 	mov	x1, x3
    3b74:	aa1603e0 	mov	x0, x22
    3b78:	aa1b03e3 	mov	x3, x27
    3b7c:	aa1a03e2 	mov	x2, x26
    3b80:	f90007e6 	str	x6, [sp, #8]
    3b84:	b90013e4 	str	w4, [sp, #16]
    3b88:	8b1a02d6 	add	x22, x22, x26
    3b8c:	b9001be5 	str	w5, [sp, #24]
    3b90:	97fffb34 	bl	2860 <__memcpy_chk@plt>
    3b94:	f94007e6 	ldr	x6, [sp, #8]
    3b98:	2a3703e7 	mvn	w7, w23
    3b9c:	b94013e4 	ldr	w4, [sp, #16]
    3ba0:	cb1b00c1 	sub	x1, x6, x27
    3ba4:	cb06037b 	sub	x27, x27, x6
    3ba8:	f101203f 	cmp	x1, #0x48
    3bac:	d2800906 	mov	x6, #0x48                  	// #72
    3bb0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bb4:	8b1b0023 	add	x3, x1, x27
    3bb8:	310006ff 	cmn	w23, #0x1
    3bbc:	54000220 	b.eq	3c00 <fwp_format_g.constprop.0+0x380>  // b.none
    3bc0:	b9401be5 	ldr	w5, [sp, #24]
    3bc4:	d2800001 	mov	x1, #0x0                   	// #0
    3bc8:	f101207f 	cmp	x3, #0x48
    3bcc:	d1000462 	sub	x2, x3, #0x1
    3bd0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bd4:	38216ac5 	strb	w5, [x22, x1]
    3bd8:	cb030003 	sub	x3, x0, x3
    3bdc:	91000421 	add	x1, x1, #0x1
    3be0:	91000463 	add	x3, x3, #0x1
    3be4:	eb00007f 	cmp	x3, x0
    3be8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3bec:	cb000063 	sub	x3, x3, x0
    3bf0:	8b020063 	add	x3, x3, x2
    3bf4:	6b0100ff 	cmp	w7, w1
    3bf8:	54fffe8c 	b.gt	3bc8 <fwp_format_g.constprop.0+0x348>
    3bfc:	8b2742d6 	add	x22, x22, w7, uxtw
    3c00:	f101207f 	cmp	x3, #0x48
    3c04:	d2800905 	mov	x5, #0x48                  	// #72
    3c08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	cb0300a1 	sub	x1, x5, x3
    3c14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c18:	91000421 	add	x1, x1, #0x1
    3c1c:	d1000463 	sub	x3, x3, #0x1
    3c20:	eb05003f 	cmp	x1, x5
    3c24:	38001402 	strb	w2, [x0], #1
    3c28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c2c:	93407f82 	sxtw	x2, w28
    3c30:	cb050025 	sub	x5, x1, x5
    3c34:	aa1303e1 	mov	x1, x19
    3c38:	8b0300a3 	add	x3, x5, x3
    3c3c:	8b1802d3 	add	x19, x22, x24
    3c40:	97fffb08 	bl	2860 <__memcpy_chk@plt>
    3c44:	17ffff6b 	b	39f0 <fwp_format_g.constprop.0+0x170>
    3c48:	d1000421 	sub	x1, x1, #0x1
    3c4c:	38616aa0 	ldrb	w0, [x21, x1]
    3c50:	7100b81f 	cmp	w0, #0x2e
    3c54:	54fff021 	b.ne	3a58 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3c58:	38216abf 	strb	wzr, [x21, x1]
    3c5c:	17ffff7f 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3c60:	910187e7 	add	x7, sp, #0x61
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d28008fb 	mov	x27, #0x47                  	// #71
    3c6c:	390183e0 	strb	w0, [sp, #96]
    3c70:	17ffff3b 	b	395c <fwp_format_g.constprop.0+0xdc>
    3c74:	38336b3f 	strb	wzr, [x25, x19]
    3c78:	17ffffac 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3c7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c80:	97fffb24 	bl	2910 <__stack_chk_fail@plt>

0000000000003c84 <fwp_heap_report>:
    3c84:	d105c3ff 	sub	sp, sp, #0x170
    3c88:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c8c:	91174042 	add	x2, x2, #0x5d0
    3c90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3c94:	f947e821 	ldr	x1, [x1, #4048]
    3c98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c9c:	910443fd 	add	x29, sp, #0x110
    3ca0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ca4:	f947f400 	ldr	x0, [x0, #4072]
    3ca8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cac:	a91463f7 	stp	x23, x24, [sp, #320]
    3cb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3cc0:	f9400036 	ldr	x22, [x1]
    3cc4:	f9400001 	ldr	x1, [x0]
    3cc8:	f90087e1 	str	x1, [sp, #264]
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	f949e459 	ldr	x25, [x2, #5064]
    3cd4:	d0000041 	adrp	x1, d000 <__divti3+0x240>
    3cd8:	f94a1057 	ldr	x23, [x2, #5152]
    3cdc:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    3ce0:	f94a1458 	ldr	x24, [x2, #5160]
    3ce4:	9117c021 	add	x1, x1, #0x5f0
    3ce8:	9117e000 	add	x0, x0, #0x5f8
    3cec:	97fffaed 	bl	28a0 <fopen@plt>
    3cf0:	b4000760 	cbz	x0, 3ddc <fwp_heap_report+0x158>
    3cf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3cf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3cfc:	aa0003f4 	mov	x20, x0
    3d00:	910023f3 	add	x19, sp, #0x8
    3d04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d08:	72aae915 	movk	w21, #0x5748, lsl #16
    3d0c:	d503201f 	nop
    3d10:	aa1403e2 	mov	x2, x20
    3d14:	aa1303e0 	mov	x0, x19
    3d18:	52802001 	mov	w1, #0x100                 	// #256
    3d1c:	97fffb6d 	bl	2ad0 <fgets@plt>
    3d20:	b4000280 	cbz	x0, 3d70 <fwp_heap_report+0xec>
    3d24:	b9400261 	ldr	w1, [x19]
    3d28:	6b15003f 	cmp	w1, w21
    3d2c:	54ffff21 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d30:	39401260 	ldrb	w0, [x19, #4]
    3d34:	7101341f 	cmp	w0, #0x4d
    3d38:	54fffec1 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d3c:	394037e0 	ldrb	w0, [sp, #13]
    3d40:	7100e81f 	cmp	w0, #0x3a
    3d44:	54fffe61 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d48:	52800142 	mov	w2, #0xa                   	// #10
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	91003be0 	add	x0, sp, #0xe
    3d54:	97fffb17 	bl	29b0 <strtol@plt>
    3d58:	aa1403e2 	mov	x2, x20
    3d5c:	aa0003fa 	mov	x26, x0
    3d60:	52802001 	mov	w1, #0x100                 	// #256
    3d64:	aa1303e0 	mov	x0, x19
    3d68:	97fffb5a 	bl	2ad0 <fgets@plt>
    3d6c:	b5fffdc0 	cbnz	x0, 3d24 <fwp_heap_report+0xa0>
    3d70:	aa1403e0 	mov	x0, x20
    3d74:	97fffac7 	bl	2890 <fclose@plt>
    3d78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d80:	f947f400 	ldr	x0, [x0, #4072]
    3d84:	f94087e2 	ldr	x2, [sp, #264]
    3d88:	f9400001 	ldr	x1, [x0]
    3d8c:	eb010042 	subs	x2, x2, x1
    3d90:	d2800001 	mov	x1, #0x0                   	// #0
    3d94:	54000281 	b.ne	3de4 <fwp_heap_report+0x160>  // b.any
    3d98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d9c:	aa1a03e6 	mov	x6, x26
    3da0:	aa1903e5 	mov	x5, x25
    3da4:	aa1803e4 	mov	x4, x24
    3da8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dac:	aa1703e3 	mov	x3, x23
    3db0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3db4:	aa1603e0 	mov	x0, x22
    3db8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dbc:	1e604121 	fmov	d1, d9
    3dc0:	1e604100 	fmov	d0, d8
    3dc4:	d0000042 	adrp	x2, d000 <__divti3+0x240>
    3dc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3dcc:	91186042 	add	x2, x2, #0x618
    3dd0:	9105c3ff 	add	sp, sp, #0x170
    3dd4:	52800041 	mov	w1, #0x2                   	// #2
    3dd8:	17fffaea 	b	2980 <__fprintf_chk@plt>
    3ddc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3de0:	17ffffe7 	b	3d7c <fwp_heap_report+0xf8>
    3de4:	a91253f3 	stp	x19, x20, [sp, #288]
    3de8:	97fffaca 	bl	2910 <__stack_chk_fail@plt>
    3dec:	d503201f 	nop

0000000000003df0 <fwp_heap_init>:
    3df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3df4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3df8:	91134061 	add	x1, x3, #0x4d0
    3dfc:	910003fd 	mov	x29, sp
    3e00:	a90153f3 	stp	x19, x20, [sp, #16]
    3e04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3e08:	91174262 	add	x2, x19, #0x5d0
    3e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e10:	52800024 	mov	w4, #0x1                   	// #1
    3e14:	52800200 	mov	w0, #0x10                  	// #16
    3e18:	b913a444 	str	w4, [x2, #5028]
    3e1c:	d503201f 	nop
    3e20:	b8004420 	str	w0, [x1], #4
    3e24:	11004000 	add	w0, w0, #0x10
    3e28:	7104401f 	cmp	w0, #0x110
    3e2c:	54ffffa1 	b.ne	3e20 <fwp_heap_init+0x30>  // b.any
    3e30:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0xb20>
    3e34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3e3c:	91144021 	add	x1, x1, #0x510
    3e40:	3dc0b043 	ldr	q3, [x2, #704]
    3e44:	d2800000 	mov	x0, #0x0                   	// #0
    3e48:	4e040401 	dup	v1.4s, v0.s[0]
    3e4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e50:	0f215400 	shl	v0.2s, v0.2s, #1
    3e54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e58:	3ca06821 	str	q1, [x1, x0]
    3e5c:	91004000 	add	x0, x0, #0x10
    3e60:	f101801f 	cmp	x0, #0x60
    3e64:	54ffff21 	b.ne	3e48 <fwp_heap_init+0x58>  // b.any
    3e68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3e6c:	91134063 	add	x3, x3, #0x4d0
    3e70:	9115c084 	add	x4, x4, #0x570
    3e74:	91174266 	add	x6, x19, #0x5d0
    3e78:	d2800002 	mov	x2, #0x0                   	// #0
    3e7c:	d2800000 	mov	x0, #0x0                   	// #0
    3e80:	d2880205 	mov	x5, #0x4010                	// #16400
    3e84:	d503201f 	nop
    3e88:	910f0001 	add	x1, x0, #0x3c0
    3e8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e90:	eb02003f 	cmp	x1, x2
    3e94:	540000a2 	b.cs	3ea8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e98:	91000400 	add	x0, x0, #0x1
    3e9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	54ffffa3 	b.cc	3e98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ea8:	91004042 	add	x2, x2, #0x10
    3eac:	38001480 	strb	w0, [x4], #1
    3eb0:	eb05005f 	cmp	x2, x5
    3eb4:	54fffea1 	b.ne	3e88 <fwp_heap_init+0x98>  // b.any
    3eb8:	528000b5 	mov	w21, #0x5                   	// #5
    3ebc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ec0:	14000004 	b	3ed0 <fwp_heap_init+0xe0>
    3ec4:	d342fe94 	lsr	x20, x20, #2
    3ec8:	710006b5 	subs	w21, w21, #0x1
    3ecc:	54000720 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3ed0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ed4:	d2800005 	mov	x5, #0x0                   	// #0
    3ed8:	aa1603e1 	mov	x1, x22
    3edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ee0:	52880443 	mov	w3, #0x4022                	// #16418
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	d2800000 	mov	x0, #0x0                   	// #0
    3eec:	97fffaad 	bl	29a0 <mmap@plt>
    3ef0:	aa0003e6 	mov	x6, x0
    3ef4:	b100041f 	cmn	x0, #0x1
    3ef8:	54fffe60 	b.eq	3ec4 <fwp_heap_init+0xd4>  // b.none
    3efc:	b40005a0 	cbz	x0, 3fb0 <fwp_heap_init+0x1c0>
    3f00:	d350fe94 	lsr	x20, x20, #16
    3f04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f08:	8b0000c7 	add	x7, x6, x0
    3f0c:	91174275 	add	x21, x19, #0x5d0
    3f10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f14:	8b140a81 	add	x1, x20, x20, lsl #2
    3f18:	d2800005 	mov	x5, #0x0                   	// #0
    3f1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f20:	d37df021 	lsl	x1, x1, #3
    3f24:	52880443 	mov	w3, #0x4022                	// #16418
    3f28:	52800002 	mov	w2, #0x0                   	// #0
    3f2c:	d2800000 	mov	x0, #0x0                   	// #0
    3f30:	f909daa7 	str	x7, [x21, #5040]
    3f34:	f909dea6 	str	x6, [x21, #5048]
    3f38:	f909e2b6 	str	x22, [x21, #5056]
    3f3c:	f909eab4 	str	x20, [x21, #5072]
    3f40:	f90a02a1 	str	x1, [x21, #5120]
    3f44:	97fffa97 	bl	29a0 <mmap@plt>
    3f48:	aa0003e1 	mov	x1, x0
    3f4c:	b100041f 	cmn	x0, #0x1
    3f50:	54000300 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3f54:	d0000040 	adrp	x0, d000 <__divti3+0x240>
    3f58:	911a8000 	add	x0, x0, #0x6a0
    3f5c:	f909fea1 	str	x1, [x21, #5112]
    3f60:	97fffad0 	bl	2aa0 <getenv@plt>
    3f64:	52800002 	mov	w2, #0x0                   	// #0
    3f68:	aa0003e1 	mov	x1, x0
    3f6c:	b40000e0 	cbz	x0, 3f88 <fwp_heap_init+0x198>
    3f70:	39400000 	ldrb	w0, [x0]
    3f74:	340000a0 	cbz	w0, 3f88 <fwp_heap_init+0x198>
    3f78:	7100c000 	subs	w0, w0, #0x30
    3f7c:	54000120 	b.eq	3fa0 <fwp_heap_init+0x1b0>  // b.none
    3f80:	7100001f 	cmp	w0, #0x0
    3f84:	1a9f07e2 	cset	w2, ne	// ne = any
    3f88:	91174273 	add	x19, x19, #0x5d0
    3f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f90:	b913aa62 	str	w2, [x19, #5032]
    3f94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f9c:	d65f03c0 	ret
    3fa0:	39400420 	ldrb	w0, [x1, #1]
    3fa4:	7100001f 	cmp	w0, #0x0
    3fa8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fac:	17fffff7 	b	3f88 <fwp_heap_init+0x198>
    3fb0:	97fffc40 	bl	30b0 <fwp_heap_oom>

0000000000003fb4 <fwp_wake_io>:
    3fb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fb8:	9101c122 	add	x2, x9, #0x70
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	5280000a 	mov	w10, #0x0                   	// #0
    3fc4:	f9403c46 	ldr	x6, [x2, #120]
    3fc8:	52800008 	mov	w8, #0x0                   	// #0
    3fcc:	4f000400 	movi	v0.4s, #0x0
    3fd0:	52800027 	mov	w7, #0x1                   	// #1
    3fd4:	aa0103e2 	mov	x2, x1
    3fd8:	b4000321 	cbz	x1, 403c <fwp_wake_io+0x88>
    3fdc:	f9408c25 	ldr	x5, [x1, #280]
    3fe0:	39015c27 	strb	w7, [x1, #87]
    3fe4:	b4000165 	cbz	x5, 4010 <fwp_wake_io+0x5c>
    3fe8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3fec:	b4000364 	cbz	x4, 4058 <fwp_wake_io+0xa4>
    3ff0:	f9009483 	str	x3, [x4, #296]
    3ff4:	f9409423 	ldr	x3, [x1, #296]
    3ff8:	b4000043 	cbz	x3, 4000 <fwp_wake_io+0x4c>
    3ffc:	f9009064 	str	x4, [x3, #288]
    4000:	91080023 	add	x3, x1, #0x200
    4004:	f900943f 	str	xzr, [x1, #296]
    4008:	3c918060 	stur	q0, [x3, #-232]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	f9402843 	ldr	x3, [x2, #80]
    4014:	f2001c7f 	tst	x3, #0xff000000ff
    4018:	54fffde1 	b.ne	3fd4 <fwp_wake_io+0x20>  // b.any
    401c:	39015047 	strb	w7, [x2, #84]
    4020:	f900805f 	str	xzr, [x2, #256]
    4024:	b40001e6 	cbz	x6, 4060 <fwp_wake_io+0xac>
    4028:	f90080c2 	str	x2, [x6, #256]
    402c:	aa0203e6 	mov	x6, x2
    4030:	52800028 	mov	w8, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b5fffd21 	cbnz	x1, 3fdc <fwp_wake_io+0x28>
    403c:	3400006a 	cbz	w10, 4048 <fwp_wake_io+0x94>
    4040:	9101c120 	add	x0, x9, #0x70
    4044:	f900400b 	str	x11, [x0, #128]
    4048:	34000068 	cbz	w8, 4054 <fwp_wake_io+0xa0>
    404c:	9101c129 	add	x9, x9, #0x70
    4050:	f9003d26 	str	x6, [x9, #120]
    4054:	d65f03c0 	ret
    4058:	f90000a3 	str	x3, [x5]
    405c:	17ffffe7 	b	3ff8 <fwp_wake_io+0x44>
    4060:	aa0203eb 	mov	x11, x2
    4064:	5280002a 	mov	w10, #0x1                   	// #1
    4068:	17fffff1 	b	402c <fwp_wake_io+0x78>
    406c:	d503201f 	nop

0000000000004070 <fwp_tape_buffers_release>:
    4070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4074:	910003fd 	mov	x29, sp
    4078:	a90153f3 	stp	x19, x20, [sp, #16]
    407c:	aa0003f3 	mov	x19, x0
    4080:	f9401400 	ldr	x0, [x0, #40]
    4084:	b7f80760 	tbnz	x0, #63, 4170 <fwp_tape_buffers_release+0x100>
    4088:	f9401a61 	ldr	x1, [x19, #48]
    408c:	b7f80301 	tbnz	x1, #63, 40ec <fwp_tape_buffers_release+0x7c>
    4090:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4094:	eb02001f 	cmp	x0, x2
    4098:	540002a8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    409c:	8b000400 	add	x0, x0, x0, lsl #1
    40a0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40a4:	d37df000 	lsl	x0, x0, #3
    40a8:	cb000042 	sub	x2, x2, x0
    40ac:	eb420c3f 	cmp	x1, x2, lsr #3
    40b0:	540001e8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    40b4:	8b010c14 	add	x20, x0, x1, lsl #3
    40b8:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    40bc:	911ac000 	add	x0, x0, #0x6b0
    40c0:	97fffa78 	bl	2aa0 <getenv@plt>
    40c4:	b4000240 	cbz	x0, 410c <fwp_tape_buffers_release+0x9c>
    40c8:	39400001 	ldrb	w1, [x0]
    40cc:	7100c03f 	cmp	w1, #0x30
    40d0:	540001e1 	b.ne	410c <fwp_tape_buffers_release+0x9c>  // b.any
    40d4:	39400400 	ldrb	w0, [x0, #1]
    40d8:	350001a0 	cbnz	w0, 410c <fwp_tape_buffers_release+0x9c>
    40dc:	aa1303e0 	mov	x0, x19
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e8:	17fffd06 	b	3500 <fwp_tape_buffers_dispose>
    40ec:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    40f0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f4:	911ac000 	add	x0, x0, #0x6b0
    40f8:	97fffa6a 	bl	2aa0 <getenv@plt>
    40fc:	b4ffff00 	cbz	x0, 40dc <fwp_tape_buffers_release+0x6c>
    4100:	39400001 	ldrb	w1, [x0]
    4104:	7100c03f 	cmp	w1, #0x30
    4108:	54fffe60 	b.eq	40d4 <fwp_tape_buffers_release+0x64>  // b.none
    410c:	d1000681 	sub	x1, x20, #0x1
    4110:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4114:	eb00003f 	cmp	x1, x0
    4118:	54fffe28 	b.hi	40dc <fwp_tape_buffers_release+0x6c>  // b.pmore
    411c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4120:	900000f6 	adrp	x22, 20000 <__data_start>
    4124:	9101c2d6 	add	x22, x22, #0x70
    4128:	910222d5 	add	x21, x22, #0x88
    412c:	aa1503e0 	mov	x0, x21
    4130:	97fffcf4 	bl	3500 <fwp_tape_buffers_dispose>
    4134:	ad400a61 	ldp	q1, q2, [x19]
    4138:	f90062d4 	str	x20, [x22, #192]
    413c:	4f000400 	movi	v0.4s, #0x0
    4140:	ad000aa1 	stp	q1, q2, [x21]
    4144:	3dc00a61 	ldr	q1, [x19, #32]
    4148:	3d800aa1 	str	q1, [x21, #32]
    414c:	f9401a60 	ldr	x0, [x19, #48]
    4150:	f9001aa0 	str	x0, [x21, #48]
    4154:	f9001a7f 	str	xzr, [x19, #48]
    4158:	ad000260 	stp	q0, q0, [x19]
    415c:	3d800a60 	str	q0, [x19, #32]
    4160:	a94153f3 	ldp	x19, x20, [sp, #16]
    4164:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    416c:	d65f03c0 	ret
    4170:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4174:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4178:	911ac000 	add	x0, x0, #0x6b0
    417c:	97fffa49 	bl	2aa0 <getenv@plt>
    4180:	b5fffa40 	cbnz	x0, 40c8 <fwp_tape_buffers_release+0x58>
    4184:	17ffffd6 	b	40dc <fwp_tape_buffers_release+0x6c>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <fwp_trap>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	900000e2 	adrp	x2, 20000 <__data_start>
    4198:	d53bd041 	mrs	x1, tpidr_el0
    419c:	910003fd 	mov	x29, sp
    41a0:	f9403c42 	ldr	x2, [x2, #120]
    41a4:	91400021 	add	x1, x1, #0x0, lsl #12
    41a8:	91004021 	add	x1, x1, #0x10
    41ac:	a90153f3 	stp	x19, x20, [sp, #16]
    41b0:	aa0003f3 	mov	x19, x0
    41b4:	f9400034 	ldr	x20, [x1]
    41b8:	b4000062 	cbz	x2, 41c4 <fwp_trap+0x34>
    41bc:	aa0203e0 	mov	x0, x2
    41c0:	97fffa20 	bl	2a40 <fflush@plt>
    41c4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    41c8:	f947ec00 	ldr	x0, [x0, #4056]
    41cc:	f9400000 	ldr	x0, [x0]
    41d0:	97fffa1c 	bl	2a40 <fflush@plt>
    41d4:	aa1303e3 	mov	x3, x19
    41d8:	b0000042 	adrp	x2, d000 <__divti3+0x240>
    41dc:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    41e0:	f947ea73 	ldr	x19, [x19, #4048]
    41e4:	911b2042 	add	x2, x2, #0x6c8
    41e8:	52800041 	mov	w1, #0x2                   	// #2
    41ec:	f9400260 	ldr	x0, [x19]
    41f0:	97fff9e4 	bl	2980 <__fprintf_chk@plt>
    41f4:	b40000b4 	cbz	x20, 4208 <fwp_trap+0x78>
    41f8:	f9400260 	ldr	x0, [x19]
    41fc:	97fffa11 	bl	2a40 <fflush@plt>
    4200:	52800ca0 	mov	w0, #0x65                  	// #101
    4204:	97fffa1f 	bl	2a80 <_Exit@plt>
    4208:	52800ca0 	mov	w0, #0x65                  	// #101
    420c:	97fff96d 	bl	27c0 <exit@plt>

0000000000004210 <fwp_rc_forget_slot.part.0>:
    4210:	ca404401 	eor	x1, x0, x0, lsr #17
    4214:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4218:	ca412421 	eor	x1, x1, x1, lsr #9
    421c:	910003fd 	mov	x29, sp
    4220:	92401c21 	and	x1, x1, #0xff
    4224:	f9000bf3 	str	x19, [sp, #16]
    4228:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    422c:	91174262 	add	x2, x19, #0x5d0
    4230:	910a2423 	add	x3, x1, #0x289
    4234:	8b010c41 	add	x1, x2, x1, lsl #3
    4238:	8b030c43 	add	x3, x2, x3, lsl #3
    423c:	f94a2421 	ldr	x1, [x1, #5192]
    4240:	b50000a1 	cbnz	x1, 4254 <fwp_rc_forget_slot.part.0+0x44>
    4244:	14000012 	b	428c <fwp_rc_forget_slot.part.0+0x7c>
    4248:	91004023 	add	x3, x1, #0x10
    424c:	f9400821 	ldr	x1, [x1, #16]
    4250:	b40001e1 	cbz	x1, 428c <fwp_rc_forget_slot.part.0+0x7c>
    4254:	f9400022 	ldr	x2, [x1]
    4258:	eb02001f 	cmp	x0, x2
    425c:	54ffff61 	b.ne	4248 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4260:	f9400060 	ldr	x0, [x3]
    4264:	91174273 	add	x19, x19, #0x5d0
    4268:	f9400801 	ldr	x1, [x0, #16]
    426c:	f9000061 	str	x1, [x3]
    4270:	97fff9d8 	bl	29d0 <free@plt>
    4274:	f94e2660 	ldr	x0, [x19, #7240]
    4278:	d1000400 	sub	x0, x0, #0x1
    427c:	f90e2660 	str	x0, [x19, #7240]
    4280:	f9400bf3 	ldr	x19, [sp, #16]
    4284:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4288:	d65f03c0 	ret
    428c:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4290:	911b6000 	add	x0, x0, #0x6d8
    4294:	97ffffbf 	bl	4190 <fwp_trap>
    4298:	d503201f 	nop
    429c:	d503201f 	nop

00000000000042a0 <fwp_rc_prepare_chunk>:
    42a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42a4:	910003fd 	mov	x29, sp
    42a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    42ac:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    42b0:	911742c2 	add	x2, x22, #0x5d0
    42b4:	b9401c03 	ldr	w3, [x0, #28]
    42b8:	aa0103f5 	mov	x21, x1
    42bc:	a90153f3 	stp	x19, x20, [sp, #16]
    42c0:	aa0003f4 	mov	x20, x0
    42c4:	f94e2440 	ldr	x0, [x2, #7240]
    42c8:	b4000440 	cbz	x0, 4350 <fwp_rc_prepare_chunk+0xb0>
    42cc:	d2800013 	mov	x19, #0x0                   	// #0
    42d0:	35000203 	cbnz	w3, 4310 <fwp_rc_prepare_chunk+0x70>
    42d4:	b4000361 	cbz	x1, 4340 <fwp_rc_prepare_chunk+0xa0>
    42d8:	f9401280 	ldr	x0, [x20, #32]
    42dc:	97fff9bd 	bl	29d0 <free@plt>
    42e0:	aa1503e0 	mov	x0, x21
    42e4:	d2800021 	mov	x1, #0x1                   	// #1
    42e8:	97fff982 	bl	28f0 <calloc@plt>
    42ec:	f9001280 	str	x0, [x20, #32]
    42f0:	b5000460 	cbnz	x0, 437c <fwp_rc_prepare_chunk+0xdc>
    42f4:	97fffb6f 	bl	30b0 <fwp_heap_oom>
    42f8:	97ffffc6 	bl	4210 <fwp_rc_forget_slot.part.0>
    42fc:	91000673 	add	x19, x19, #0x1
    4300:	b9401e83 	ldr	w3, [x20, #28]
    4304:	eb13007f 	cmp	x3, x19
    4308:	54000169 	b.ls	4334 <fwp_rc_prepare_chunk+0x94>  // b.plast
    430c:	d503201f 	nop
    4310:	f9401283 	ldr	x3, [x20, #32]
    4314:	8b130060 	add	x0, x3, x19
    4318:	38736863 	ldrb	w3, [x3, x19]
    431c:	7103fc7f 	cmp	w3, #0xff
    4320:	54fffec0 	b.eq	42f8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4324:	b9401e83 	ldr	w3, [x20, #28]
    4328:	91000673 	add	x19, x19, #0x1
    432c:	eb13007f 	cmp	x3, x19
    4330:	54ffff08 	b.hi	4310 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4334:	eb0302bf 	cmp	x21, x3
    4338:	54000121 	b.ne	435c <fwp_rc_prepare_chunk+0xbc>  // b.any
    433c:	b5000335 	cbnz	x21, 43a0 <fwp_rc_prepare_chunk+0x100>
    4340:	a94153f3 	ldp	x19, x20, [sp, #16]
    4344:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4348:	a8c37bfd 	ldp	x29, x30, [sp], #48
    434c:	d65f03c0 	ret
    4350:	2a0303e3 	mov	w3, w3
    4354:	eb0302bf 	cmp	x21, x3
    4358:	54ffff20 	b.eq	433c <fwp_rc_prepare_chunk+0x9c>  // b.none
    435c:	911742c2 	add	x2, x22, #0x5d0
    4360:	f9401280 	ldr	x0, [x20, #32]
    4364:	f94e2841 	ldr	x1, [x2, #7248]
    4368:	cb030021 	sub	x1, x1, x3
    436c:	f90e2841 	str	x1, [x2, #7248]
    4370:	97fff998 	bl	29d0 <free@plt>
    4374:	b5fffb75 	cbnz	x21, 42e0 <fwp_rc_prepare_chunk+0x40>
    4378:	f900129f 	str	xzr, [x20, #32]
    437c:	911742d6 	add	x22, x22, #0x5d0
    4380:	f94e2ac0 	ldr	x0, [x22, #7248]
    4384:	b9001e95 	str	w21, [x20, #28]
    4388:	a94153f3 	ldp	x19, x20, [sp, #16]
    438c:	8b150000 	add	x0, x0, x21
    4390:	f90e2ac0 	str	x0, [x22, #7248]
    4394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4398:	a8c37bfd 	ldp	x29, x30, [sp], #48
    439c:	d65f03c0 	ret
    43a0:	f9401280 	ldr	x0, [x20, #32]
    43a4:	aa1503e2 	mov	x2, x21
    43a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43ac:	52800001 	mov	w1, #0x0                   	// #0
    43b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43b8:	17fff94a 	b	28e0 <memset@plt>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_heap_refill>:
    43c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    43d0:	911742b5 	add	x21, x21, #0x5d0
    43d4:	aa0003f6 	mov	x22, x0
    43d8:	d2800020 	mov	x0, #0x1                   	// #1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	a90363f7 	stp	x23, x24, [sp, #48]
    43e4:	2a0103f7 	mov	w23, w1
    43e8:	2a0203f8 	mov	w24, w2
    43ec:	97fffbd1 	bl	3330 <fwp_heap_chunks>
    43f0:	aa0003f3 	mov	x19, x0
    43f4:	f949fea2 	ldr	x2, [x21, #5112]
    43f8:	8b000800 	add	x0, x0, x0, lsl #2
    43fc:	2a1703e1 	mov	w1, w23
    4400:	52800025 	mov	w5, #0x1                   	// #1
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	910f0021 	add	x1, x1, #0x3c0
    440c:	8b000054 	add	x20, x2, x0
    4410:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4414:	52a00024 	mov	w4, #0x10000               	// #65536
    4418:	38206845 	strb	w5, [x2, x0]
    441c:	aa1403e0 	mov	x0, x20
    4420:	39000698 	strb	w24, [x20, #1]
    4424:	39000a97 	strb	w23, [x20, #2]
    4428:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    442c:	b9000681 	str	w1, [x20, #4]
    4430:	2a0103e5 	mov	w5, w1
    4434:	8b0300a2 	add	x2, x5, x3
    4438:	1ac10881 	udiv	w1, w4, w1
    443c:	9ac50842 	udiv	x2, x2, x5
    4440:	b9000a81 	str	w1, [x20, #8]
    4444:	92404021 	and	x1, x1, #0x1ffff
    4448:	b9001a82 	str	w2, [x20, #24]
    444c:	97ffff95 	bl	42a0 <fwp_rc_prepare_chunk>
    4450:	f949daa0 	ldr	x0, [x21, #5040]
    4454:	29408a81 	ldp	w1, w2, [x20, #4]
    4458:	8b134000 	add	x0, x0, x19, lsl #16
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	8b214003 	add	x3, x0, w1, uxtw
    4464:	9ba20021 	umaddl	x1, w1, w2, x0
    4468:	a94363f7 	ldp	x23, x24, [sp, #48]
    446c:	a90086c3 	stp	x3, x1, [x22, #8]
    4470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4474:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4478:	d65f03c0 	ret
    447c:	d503201f 	nop

0000000000004480 <fwp_mem_free>:
    4480:	b40003c0 	cbz	x0, 44f8 <fwp_mem_free+0x78>
    4484:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4488:	910003fd 	mov	x29, sp
    448c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4490:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4494:	911742a1 	add	x1, x21, #0x5d0
    4498:	a90153f3 	stp	x19, x20, [sp, #16]
    449c:	aa0003f3 	mov	x19, x0
    44a0:	f949d823 	ldr	x3, [x1, #5040]
    44a4:	f949ec22 	ldr	x2, [x1, #5080]
    44a8:	cb030000 	sub	x0, x0, x3
    44ac:	eb02401f 	cmp	x0, x2, lsl #16
    44b0:	540001c2 	b.cs	44e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    44b4:	d350fc16 	lsr	x22, x0, #16
    44b8:	a90363f7 	stp	x23, x24, [sp, #48]
    44bc:	f949fc22 	ldr	x2, [x1, #5112]
    44c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    44c4:	d37df294 	lsl	x20, x20, #3
    44c8:	ab140057 	adds	x23, x2, x20
    44cc:	540000c0 	b.eq	44e4 <fwp_mem_free+0x64>  // b.none
    44d0:	38746842 	ldrb	w2, [x2, x20]
    44d4:	7100045f 	cmp	w2, #0x1
    44d8:	54000120 	b.eq	44fc <fwp_mem_free+0x7c>  // b.none
    44dc:	7100085f 	cmp	w2, #0x2
    44e0:	540005e0 	b.eq	459c <fwp_mem_free+0x11c>  // b.none
    44e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44f4:	d65f03c0 	ret
    44f8:	d65f03c0 	ret
    44fc:	f94012f8 	ldr	x24, [x23, #32]
    4500:	b94006e1 	ldr	w1, [x23, #4]
    4504:	f90023f9 	str	x25, [sp, #64]
    4508:	2a0103e2 	mov	w2, w1
    450c:	394006f9 	ldrb	w25, [x23, #1]
    4510:	39400af4 	ldrb	w20, [x23, #2]
    4514:	b4000158 	cbz	x24, 453c <fwp_mem_free+0xbc>
    4518:	92403e76 	and	x22, x19, #0xffff
    451c:	9ac20ad6 	udiv	x22, x22, x2
    4520:	38766b01 	ldrb	w1, [x24, x22]
    4524:	8b160300 	add	x0, x24, x22
    4528:	7103fc3f 	cmp	w1, #0xff
    452c:	54000980 	b.eq	465c <fwp_mem_free+0x1dc>  // b.none
    4530:	38366b1f 	strb	wzr, [x24, x22]
    4534:	b94006e1 	ldr	w1, [x23, #4]
    4538:	2a0103e2 	mov	w2, w1
    453c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4540:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4544:	cb390000 	sub	x0, x0, w25, uxtb
    4548:	8b340074 	add	x20, x3, w20, uxtb
    454c:	911742b5 	add	x21, x21, #0x5d0
    4550:	1e630021 	ucvtf	d1, w1
    4554:	d37ae400 	lsl	x0, x0, #6
    4558:	8b140c14 	add	x20, x0, x20, lsl #3
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	f8746aa0 	ldr	x0, [x21, x20]
    4564:	f94023f9 	ldr	x25, [sp, #64]
    4568:	aa2003e0 	mvn	x0, x0
    456c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4570:	f9000260 	str	x0, [x19]
    4574:	f8346ab3 	str	x19, [x21, x20]
    4578:	f94a12a0 	ldr	x0, [x21, #5152]
    457c:	1e612800 	fadd	d0, d0, d1
    4580:	a94153f3 	ldp	x19, x20, [sp, #16]
    4584:	cb020000 	sub	x0, x0, x2
    4588:	f90a12a0 	str	x0, [x21, #5152]
    458c:	fd0a22a0 	str	d0, [x21, #5184]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4598:	d65f03c0 	ret
    459c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    45a0:	8b000063 	add	x3, x3, x0
    45a4:	eb03027f 	cmp	x19, x3
    45a8:	54fff9e1 	b.ne	44e4 <fwp_mem_free+0x64>  // b.any
    45ac:	fd400ae1 	ldr	d1, [x23, #16]
    45b0:	fd4a2020 	ldr	d0, [x1, #5184]
    45b4:	f9400ae0 	ldr	x0, [x23, #16]
    45b8:	7e61d821 	ucvtf	d1, d1
    45bc:	f94a1022 	ldr	x2, [x1, #5152]
    45c0:	f94012f3 	ldr	x19, [x23, #32]
    45c4:	1e612800 	fadd	d0, d0, d1
    45c8:	cb000042 	sub	x2, x2, x0
    45cc:	f90a1022 	str	x2, [x1, #5152]
    45d0:	fd0a2020 	str	d0, [x1, #5184]
    45d4:	b40000b3 	cbz	x19, 45e8 <fwp_mem_free+0x168>
    45d8:	39400260 	ldrb	w0, [x19]
    45dc:	7103fc1f 	cmp	w0, #0xff
    45e0:	54000380 	b.eq	4650 <fwp_mem_free+0x1d0>  // b.none
    45e4:	3900027f 	strb	wzr, [x19]
    45e8:	b9400ee2 	ldr	w2, [x23, #12]
    45ec:	b4000142 	cbz	x2, 4614 <fwp_mem_free+0x194>
    45f0:	911742a1 	add	x1, x21, #0x5d0
    45f4:	8b160040 	add	x0, x2, x22
    45f8:	8b000800 	add	x0, x0, x0, lsl #2
    45fc:	f949fc21 	ldr	x1, [x1, #5112]
    4600:	8b140034 	add	x20, x1, x20
    4604:	8b000c20 	add	x0, x1, x0, lsl #3
    4608:	3802869f 	strb	wzr, [x20], #40
    460c:	eb00029f 	cmp	x20, x0
    4610:	54ffffc1 	b.ne	4608 <fwp_mem_free+0x188>  // b.any
    4614:	911742a0 	add	x0, x21, #0x5d0
    4618:	f94a1801 	ldr	x1, [x0, #5168]
    461c:	f949f803 	ldr	x3, [x0, #5104]
    4620:	8b020021 	add	x1, x1, x2
    4624:	f90a1801 	str	x1, [x0, #5168]
    4628:	eb16007f 	cmp	x3, x22
    462c:	54000049 	b.ls	4634 <fwp_mem_free+0x1b4>  // b.plast
    4630:	f909f816 	str	x22, [x0, #5104]
    4634:	911742b5 	add	x21, x21, #0x5d0
    4638:	f949f6a0 	ldr	x0, [x21, #5096]
    463c:	eb16001f 	cmp	x0, x22
    4640:	54fff529 	b.ls	44e4 <fwp_mem_free+0x64>  // b.plast
    4644:	a94363f7 	ldp	x23, x24, [sp, #48]
    4648:	f909f6b6 	str	x22, [x21, #5096]
    464c:	17ffffa7 	b	44e8 <fwp_mem_free+0x68>
    4650:	aa1303e0 	mov	x0, x19
    4654:	97fffeef 	bl	4210 <fwp_rc_forget_slot.part.0>
    4658:	17ffffe3 	b	45e4 <fwp_mem_free+0x164>
    465c:	97fffeed 	bl	4210 <fwp_rc_forget_slot.part.0>
    4660:	17ffffb4 	b	4530 <fwp_mem_free+0xb0>

0000000000004664 <fwp_rc_wide_dup>:
    4664:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4668:	910003fd 	mov	x29, sp
    466c:	a90153f3 	stp	x19, x20, [sp, #16]
    4670:	aa0003f3 	mov	x19, x0
    4674:	ca404400 	eor	x0, x0, x0, lsr #17
    4678:	f90013f5 	str	x21, [sp, #32]
    467c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4680:	ca402400 	eor	x0, x0, x0, lsr #9
    4684:	911742a2 	add	x2, x21, #0x5d0
    4688:	92401c00 	and	x0, x0, #0xff
    468c:	910a2403 	add	x3, x0, #0x289
    4690:	8b000c40 	add	x0, x2, x0, lsl #3
    4694:	8b030c54 	add	x20, x2, x3, lsl #3
    4698:	f94a2401 	ldr	x1, [x0, #5192]
    469c:	b50000a1 	cbnz	x1, 46b0 <fwp_rc_wide_dup+0x4c>
    46a0:	14000033 	b	476c <fwp_rc_wide_dup+0x108>
    46a4:	91004034 	add	x20, x1, #0x10
    46a8:	f9400821 	ldr	x1, [x1, #16]
    46ac:	b4000241 	cbz	x1, 46f4 <fwp_rc_wide_dup+0x90>
    46b0:	f9400022 	ldr	x2, [x1]
    46b4:	eb02027f 	cmp	x19, x2
    46b8:	54ffff61 	b.ne	46a4 <fwp_rc_wide_dup+0x40>  // b.any
    46bc:	f9400281 	ldr	x1, [x20]
    46c0:	39400260 	ldrb	w0, [x19]
    46c4:	7103f81f 	cmp	w0, #0xfe
    46c8:	54000220 	b.eq	470c <fwp_rc_wide_dup+0xa8>  // b.none
    46cc:	b40001a1 	cbz	x1, 4700 <fwp_rc_wide_dup+0x9c>
    46d0:	f9400420 	ldr	x0, [x1, #8]
    46d4:	b100041f 	cmn	x0, #0x1
    46d8:	54000440 	b.eq	4760 <fwp_rc_wide_dup+0xfc>  // b.none
    46dc:	91000400 	add	x0, x0, #0x1
    46e0:	f9000420 	str	x0, [x1, #8]
    46e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e8:	f94013f5 	ldr	x21, [sp, #32]
    46ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f0:	d65f03c0 	ret
    46f4:	39400260 	ldrb	w0, [x19]
    46f8:	7103f81f 	cmp	w0, #0xfe
    46fc:	54000100 	b.eq	471c <fwp_rc_wide_dup+0xb8>  // b.none
    4700:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4704:	911b6000 	add	x0, x0, #0x6d8
    4708:	97fffea2 	bl	4190 <fwp_trap>
    470c:	b4000081 	cbz	x1, 471c <fwp_rc_wide_dup+0xb8>
    4710:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4714:	911c0000 	add	x0, x0, #0x700
    4718:	97fffe9e 	bl	4190 <fwp_trap>
    471c:	d2800300 	mov	x0, #0x18                  	// #24
    4720:	97fff864 	bl	28b0 <malloc@plt>
    4724:	b4000280 	cbz	x0, 4774 <fwp_rc_wide_dup+0x110>
    4728:	d2801fe1 	mov	x1, #0xff                  	// #255
    472c:	a9000413 	stp	x19, x1, [x0]
    4730:	911742b5 	add	x21, x21, #0x5d0
    4734:	f900081f 	str	xzr, [x0, #16]
    4738:	12800001 	mov	w1, #0xffffffff            	// #-1
    473c:	f9000280 	str	x0, [x20]
    4740:	39000261 	strb	w1, [x19]
    4744:	f94e26a0 	ldr	x0, [x21, #7240]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f90e26a0 	str	x0, [x21, #7240]
    4754:	f94013f5 	ldr	x21, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4764:	911ca000 	add	x0, x0, #0x728
    4768:	97fffe8a 	bl	4190 <fwp_trap>
    476c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4770:	17ffffd4 	b	46c0 <fwp_rc_wide_dup+0x5c>
    4774:	97fffa4f 	bl	30b0 <fwp_heap_oom>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_closure_drop_push>:
    4780:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	a9408014 	ldp	x20, x0, [x0, #8]
    4794:	a9025bf5 	stp	x21, x22, [sp, #32]
    4798:	aa0103f5 	mov	x21, x1
    479c:	a90363f7 	stp	x23, x24, [sp, #48]
    47a0:	eb00029f 	cmp	x20, x0
    47a4:	54000160 	b.eq	47d0 <fwp_closure_drop_push+0x50>  // b.none
    47a8:	f9400276 	ldr	x22, [x19]
    47ac:	d37df297 	lsl	x23, x20, #3
    47b0:	91000694 	add	x20, x20, #0x1
    47b4:	f9000674 	str	x20, [x19, #8]
    47b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47bc:	f8376ad5 	str	x21, [x22, x23]
    47c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47cc:	d65f03c0 	ret
    47d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    47d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    47d8:	eb00029f 	cmp	x20, x0
    47dc:	540003e8 	b.hi	4858 <fwp_closure_drop_push+0xd8>  // b.pmore
    47e0:	d37cee99 	lsl	x25, x20, #4
    47e4:	d37ffa9a 	lsl	x26, x20, #1
    47e8:	aa1903e0 	mov	x0, x25
    47ec:	97fff831 	bl	28b0 <malloc@plt>
    47f0:	aa0003f6 	mov	x22, x0
    47f4:	b4000380 	cbz	x0, 4864 <fwp_closure_drop_push+0xe4>
    47f8:	aa1303f8 	mov	x24, x19
    47fc:	aa1903e3 	mov	x3, x25
    4800:	d37df297 	lsl	x23, x20, #3
    4804:	aa1703e2 	mov	x2, x23
    4808:	f8418719 	ldr	x25, [x24], #24
    480c:	aa1903e1 	mov	x1, x25
    4810:	97fff814 	bl	2860 <__memcpy_chk@plt>
    4814:	eb18033f 	cmp	x25, x24
    4818:	540000a0 	b.eq	482c <fwp_closure_drop_push+0xac>  // b.none
    481c:	aa1903e0 	mov	x0, x25
    4820:	97fff86c 	bl	29d0 <free@plt>
    4824:	f9400674 	ldr	x20, [x19, #8]
    4828:	d37df297 	lsl	x23, x20, #3
    482c:	91000694 	add	x20, x20, #0x1
    4830:	f9000276 	str	x22, [x19]
    4834:	f9000a7a 	str	x26, [x19, #16]
    4838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    483c:	f9000674 	str	x20, [x19, #8]
    4840:	f8376ad5 	str	x21, [x22, x23]
    4844:	a94153f3 	ldp	x19, x20, [sp, #16]
    4848:	a9425bf5 	ldp	x21, x22, [sp, #32]
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4854:	d65f03c0 	ret
    4858:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    485c:	911d2000 	add	x0, x0, #0x748
    4860:	97fffe4c 	bl	4190 <fwp_trap>
    4864:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4868:	f947e863 	ldr	x3, [x3, #4048]
    486c:	d2800262 	mov	x2, #0x13                  	// #19
    4870:	d2800021 	mov	x1, #0x1                   	// #1
    4874:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4878:	9113a000 	add	x0, x0, #0x4e8
    487c:	f9400063 	ldr	x3, [x3]
    4880:	97fff864 	bl	2a10 <fwrite@plt>
    4884:	d2800000 	mov	x0, #0x0                   	// #0
    4888:	97fff86e 	bl	2a40 <fflush@plt>
    488c:	52800cc0 	mov	w0, #0x66                  	// #102
    4890:	97fff87c 	bl	2a80 <_Exit@plt>

0000000000004894 <fwp_closure_drop.part.0>:
    4894:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4898:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0xb20>
    489c:	910003fd 	mov	x29, sp
    48a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    48a4:	f947f463 	ldr	x3, [x3, #4072]
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	d10883ff 	sub	sp, sp, #0x220
    48b0:	910003e2 	mov	x2, sp
    48b4:	d53bd053 	mrs	x19, tpidr_el0
    48b8:	910063f4 	add	x20, sp, #0x18
    48bc:	3dc0b420 	ldr	q0, [x1, #720]
    48c0:	91400264 	add	x4, x19, #0x0, lsl #12
    48c4:	91004084 	add	x4, x4, #0x10
    48c8:	aa0003e1 	mov	x1, x0
    48cc:	aa0203e0 	mov	x0, x2
    48d0:	f9400062 	ldr	x2, [x3]
    48d4:	f9010fe2 	str	x2, [sp, #536]
    48d8:	d2800002 	mov	x2, #0x0                   	// #0
    48dc:	f90003f4 	str	x20, [sp]
    48e0:	f9000080 	str	x0, [x4]
    48e4:	3c8083e0 	stur	q0, [sp, #8]
    48e8:	97ffffa6 	bl	4780 <fwp_closure_drop_push>
    48ec:	f94007e0 	ldr	x0, [sp, #8]
    48f0:	b40002e0 	cbz	x0, 494c <fwp_closure_drop.part.0+0xb8>
    48f4:	f90123f5 	str	x21, [sp, #576]
    48f8:	900000f5 	adrp	x21, 20000 <__data_start>
    48fc:	9101c2b5 	add	x21, x21, #0x70
    4900:	14000006 	b	4918 <fwp_closure_drop.part.0+0x84>
    4904:	f9400422 	ldr	x2, [x1, #8]
    4908:	52800001 	mov	w1, #0x0                   	// #0
    490c:	d63f0040 	blr	x2
    4910:	f94007e0 	ldr	x0, [sp, #8]
    4914:	b40001a0 	cbz	x0, 4948 <fwp_closure_drop.part.0+0xb4>
    4918:	f94003e1 	ldr	x1, [sp]
    491c:	d1000400 	sub	x0, x0, #0x1
    4920:	f90007e0 	str	x0, [sp, #8]
    4924:	f94066a2 	ldr	x2, [x21, #200]
    4928:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    492c:	b9400001 	ldr	w1, [x0]
    4930:	8b011441 	add	x1, x2, x1, lsl #5
    4934:	f9400c21 	ldr	x1, [x1, #24]
    4938:	b5fffe61 	cbnz	x1, 4904 <fwp_closure_drop.part.0+0x70>
    493c:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4940:	911da000 	add	x0, x0, #0x768
    4944:	97fffe13 	bl	4190 <fwp_trap>
    4948:	f94123f5 	ldr	x21, [sp, #576]
    494c:	91400273 	add	x19, x19, #0x0, lsl #12
    4950:	91004273 	add	x19, x19, #0x10
    4954:	f94003e0 	ldr	x0, [sp]
    4958:	f900027f 	str	xzr, [x19]
    495c:	eb14001f 	cmp	x0, x20
    4960:	54000040 	b.eq	4968 <fwp_closure_drop.part.0+0xd4>  // b.none
    4964:	97fff81b 	bl	29d0 <free@plt>
    4968:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    496c:	f947f400 	ldr	x0, [x0, #4072]
    4970:	f9410fe2 	ldr	x2, [sp, #536]
    4974:	f9400001 	ldr	x1, [x0]
    4978:	eb010042 	subs	x2, x2, x1
    497c:	d2800001 	mov	x1, #0x0                   	// #0
    4980:	540000a1 	b.ne	4994 <fwp_closure_drop.part.0+0x100>  // b.any
    4984:	910883ff 	add	sp, sp, #0x220
    4988:	a94153f3 	ldp	x19, x20, [sp, #16]
    498c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4990:	d65f03c0 	ret
    4994:	f90123f5 	str	x21, [sp, #576]
    4998:	97fff7de 	bl	2910 <__stack_chk_fail@plt>
    499c:	d503201f 	nop

00000000000049a0 <fwp_tape_of>:
    49a0:	aa0003e1 	mov	x1, x0
    49a4:	92403c00 	and	x0, x0, #0xffff
    49a8:	b40000e0 	cbz	x0, 49c4 <fwp_tape_of+0x24>
    49ac:	d1000402 	sub	x2, x0, #0x1
    49b0:	900000e3 	adrp	x3, 20000 <__data_start>
    49b4:	9101c060 	add	x0, x3, #0x70
    49b8:	f9406800 	ldr	x0, [x0, #208]
    49bc:	eb02001f 	cmp	x0, x2
    49c0:	540000cc 	b.gt	49d8 <fwp_tape_of+0x38>
    49c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    49c8:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    49cc:	911e6000 	add	x0, x0, #0x798
    49d0:	910003fd 	mov	x29, sp
    49d4:	97fffdef 	bl	4190 <fwp_trap>
    49d8:	8b020440 	add	x0, x2, x2, lsl #1
    49dc:	f9403863 	ldr	x3, [x3, #112]
    49e0:	8b000842 	add	x2, x2, x0, lsl #2
    49e4:	d37df042 	lsl	x2, x2, #3
    49e8:	8b020060 	add	x0, x3, x2
    49ec:	b9400404 	ldr	w4, [x0, #4]
    49f0:	34fffea4 	cbz	w4, 49c4 <fwp_tape_of+0x24>
    49f4:	b8626862 	ldr	w2, [x3, x2]
    49f8:	9350fc21 	asr	x1, x1, #16
    49fc:	6b01005f 	cmp	w2, w1
    4a00:	54fffe21 	b.ne	49c4 <fwp_tape_of+0x24>  // b.any
    4a04:	d65f03c0 	ret
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_now_ns>:
    4a10:	d100c3ff 	sub	sp, sp, #0x30
    4a14:	52800020 	mov	w0, #0x1                   	// #1
    4a18:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    4a1c:	f947f442 	ldr	x2, [x2, #4072]
    4a20:	910023e1 	add	x1, sp, #0x8
    4a24:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a28:	910083fd 	add	x29, sp, #0x20
    4a2c:	f9400043 	ldr	x3, [x2]
    4a30:	f9000fe3 	str	x3, [sp, #24]
    4a34:	d2800003 	mov	x3, #0x0                   	// #0
    4a38:	97fff782 	bl	2840 <clock_gettime@plt>
    4a3c:	350002c0 	cbnz	w0, 4a94 <fwp_now_ns+0x84>
    4a40:	a9408be1 	ldp	x1, x2, [sp, #8]
    4a44:	d2994003 	mov	x3, #0xca00                	// #51712
    4a48:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4a4c:	9b037c20 	mul	x0, x1, x3
    4a50:	9b437c21 	smulh	x1, x1, x3
    4a54:	ab020000 	adds	x0, x0, x2
    4a58:	937ffc42 	asr	x2, x2, #63
    4a5c:	9a020021 	adc	x1, x1, x2
    4a60:	f100001f 	cmp	x0, #0x0
    4a64:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4a68:	b50001c1 	cbnz	x1, 4aa0 <fwp_now_ns+0x90>
    4a6c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4a70:	f947f421 	ldr	x1, [x1, #4072]
    4a74:	f9400fe3 	ldr	x3, [sp, #24]
    4a78:	f9400022 	ldr	x2, [x1]
    4a7c:	eb020063 	subs	x3, x3, x2
    4a80:	d2800002 	mov	x2, #0x0                   	// #0
    4a84:	54000141 	b.ne	4aac <fwp_now_ns+0x9c>  // b.any
    4a88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a8c:	9100c3ff 	add	sp, sp, #0x30
    4a90:	d65f03c0 	ret
    4a94:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4a98:	911fa000 	add	x0, x0, #0x7e8
    4a9c:	97fffdbd 	bl	4190 <fwp_trap>
    4aa0:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4aa4:	91202000 	add	x0, x0, #0x808
    4aa8:	97fffdba 	bl	4190 <fwp_trap>
    4aac:	97fff799 	bl	2910 <__stack_chk_fail@plt>

0000000000004ab0 <fwp_poll_events>:
    4ab0:	d10103ff 	sub	sp, sp, #0x40
    4ab4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4ab8:	f947f400 	ldr	x0, [x0, #4072]
    4abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4ac0:	910083fd 	add	x29, sp, #0x20
    4ac4:	f9001bf3 	str	x19, [sp, #48]
    4ac8:	900000f3 	adrp	x19, 20000 <__data_start>
    4acc:	f9400001 	ldr	x1, [x0]
    4ad0:	f9000fe1 	str	x1, [sp, #24]
    4ad4:	d2800001 	mov	x1, #0x0                   	// #0
    4ad8:	97ffffce 	bl	4a10 <fwp_now_ns>
    4adc:	9101c261 	add	x1, x19, #0x70
    4ae0:	f9406c21 	ldr	x1, [x1, #216]
    4ae4:	b4000e01 	cbz	x1, 4ca4 <fwp_poll_events+0x1f4>
    4ae8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4aec:	14000005 	b	4b00 <fwp_poll_events+0x50>
    4af0:	f9408821 	ldr	x1, [x1, #272]
    4af4:	eb03005f 	cmp	x2, x3
    4af8:	9a83d042 	csel	x2, x2, x3, le
    4afc:	b40000c1 	cbz	x1, 4b14 <fwp_poll_events+0x64>
    4b00:	f9403423 	ldr	x3, [x1, #104]
    4b04:	b6ffff62 	tbz	x2, #63, 4af0 <fwp_poll_events+0x40>
    4b08:	f9408821 	ldr	x1, [x1, #272]
    4b0c:	aa0303e2 	mov	x2, x3
    4b10:	b5ffff81 	cbnz	x1, 4b00 <fwp_poll_events+0x50>
    4b14:	b7f80c82 	tbnz	x2, #63, 4ca4 <fwp_poll_events+0x1f4>
    4b18:	cb000042 	sub	x2, x2, x0
    4b1c:	f100005f 	cmp	x2, #0x0
    4b20:	540003ad 	b.le	4b94 <fwp_poll_events+0xe4>
    4b24:	d2869b60 	mov	x0, #0x34db                	// #13531
    4b28:	d2884804 	mov	x4, #0x4240                	// #16960
    4b2c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4b30:	f2a001e4 	movk	x4, #0xf, lsl #16
    4b34:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4b38:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4b3c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4b40:	9b407c40 	smulh	x0, x2, x0
    4b44:	9352fc00 	asr	x0, x0, #18
    4b48:	cb82fc00 	sub	x0, x0, x2, asr #63
    4b4c:	9b048802 	msub	x2, x0, x4, x2
    4b50:	f100005f 	cmp	x2, #0x0
    4b54:	9a800400 	cinc	x0, x0, ne	// ne = any
    4b58:	eb01001f 	cmp	x0, x1
    4b5c:	5400098c 	b.gt	4c8c <fwp_poll_events+0x1dc>
    4b60:	340001a0 	cbz	w0, 4b94 <fwp_poll_events+0xe4>
    4b64:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4b68:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4b6c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4b70:	9ba17c01 	umull	x1, w0, w1
    4b74:	d366fc23 	lsr	x3, x1, #38
    4b78:	aa0303e2 	mov	x2, x3
    4b7c:	1b058063 	msub	w3, w3, w5, w0
    4b80:	9b247c63 	smull	x3, w3, w4
    4b84:	910023e0 	add	x0, sp, #0x8
    4b88:	d2800001 	mov	x1, #0x0                   	// #0
    4b8c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b90:	97fff794 	bl	29e0 <nanosleep@plt>
    4b94:	97ffff9f 	bl	4a10 <fwp_now_ns>
    4b98:	9101c268 	add	x8, x19, #0x70
    4b9c:	aa0003e7 	mov	x7, x0
    4ba0:	4f000400 	movi	v0.4s, #0x0
    4ba4:	52800029 	mov	w9, #0x1                   	// #1
    4ba8:	f9406d06 	ldr	x6, [x8, #216]
    4bac:	d503201f 	nop
    4bb0:	b40003e6 	cbz	x6, 4c2c <fwp_poll_events+0x17c>
    4bb4:	f94034c1 	ldr	x1, [x6, #104]
    4bb8:	aa0603e5 	mov	x5, x6
    4bbc:	f94088c6 	ldr	x6, [x6, #272]
    4bc0:	eb07003f 	cmp	x1, x7
    4bc4:	54ffff6c 	b.gt	4bb0 <fwp_poll_events+0x100>
    4bc8:	394154a0 	ldrb	w0, [x5, #85]
    4bcc:	36000120 	tbz	w0, #0, 4bf0 <fwp_poll_events+0x140>
    4bd0:	f94084a0 	ldr	x0, [x5, #264]
    4bd4:	b4000560 	cbz	x0, 4c80 <fwp_poll_events+0x1d0>
    4bd8:	f9008806 	str	x6, [x0, #272]
    4bdc:	b4000046 	cbz	x6, 4be4 <fwp_poll_events+0x134>
    4be0:	f90084c0 	str	x0, [x6, #264]
    4be4:	910800a0 	add	x0, x5, #0x200
    4be8:	390154bf 	strb	wzr, [x5, #85]
    4bec:	3c908000 	stur	q0, [x0, #-248]
    4bf0:	f94030a0 	ldr	x0, [x5, #96]
    4bf4:	390158a9 	strb	w9, [x5, #86]
    4bf8:	f100001f 	cmp	x0, #0x0
    4bfc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4c00:	540002cd 	b.le	4c58 <fwp_poll_events+0x1a8>
    4c04:	f94028a0 	ldr	x0, [x5, #80]
    4c08:	f2001c1f 	tst	x0, #0xff000000ff
    4c0c:	54fffd21 	b.ne	4bb0 <fwp_poll_events+0x100>  // b.any
    4c10:	f9403d00 	ldr	x0, [x8, #120]
    4c14:	390150a9 	strb	w9, [x5, #84]
    4c18:	f90080bf 	str	xzr, [x5, #256]
    4c1c:	b40002c0 	cbz	x0, 4c74 <fwp_poll_events+0x1c4>
    4c20:	f9003d05 	str	x5, [x8, #120]
    4c24:	f9008005 	str	x5, [x0, #256]
    4c28:	b5fffc66 	cbnz	x6, 4bb4 <fwp_poll_events+0x104>
    4c2c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4c30:	f947f400 	ldr	x0, [x0, #4072]
    4c34:	f9400fe2 	ldr	x2, [sp, #24]
    4c38:	f9400001 	ldr	x1, [x0]
    4c3c:	eb010042 	subs	x2, x2, x1
    4c40:	d2800001 	mov	x1, #0x0                   	// #0
    4c44:	540002e1 	b.ne	4ca0 <fwp_poll_events+0x1f0>  // b.any
    4c48:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c4c:	f9401bf3 	ldr	x19, [sp, #48]
    4c50:	910103ff 	add	sp, sp, #0x40
    4c54:	d65f03c0 	ret
    4c58:	394144a0 	ldrb	w0, [x5, #81]
    4c5c:	3707fd40 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c60:	394140a0 	ldrb	w0, [x5, #80]
    4c64:	3707fd00 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c68:	aa0503e0 	mov	x0, x5
    4c6c:	97fffac1 	bl	3770 <fwp_cancel_tree.part.0>
    4c70:	17ffffe5 	b	4c04 <fwp_poll_events+0x154>
    4c74:	f9003d05 	str	x5, [x8, #120]
    4c78:	f9004105 	str	x5, [x8, #128]
    4c7c:	17ffffeb 	b	4c28 <fwp_poll_events+0x178>
    4c80:	9101c261 	add	x1, x19, #0x70
    4c84:	f9006c26 	str	x6, [x1, #216]
    4c88:	17ffffd5 	b	4bdc <fwp_poll_events+0x12c>
    4c8c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c90:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c94:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c98:	f2a00402 	movk	x2, #0x20, lsl #16
    4c9c:	17ffffba 	b	4b84 <fwp_poll_events+0xd4>
    4ca0:	97fff71c 	bl	2910 <__stack_chk_fail@plt>
    4ca4:	97fff8f3 	bl	3070 <fwp_flush>
    4ca8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4cac:	f947e863 	ldr	x3, [x3, #4048]
    4cb0:	d2800562 	mov	x2, #0x2b                  	// #43
    4cb4:	d2800021 	mov	x1, #0x1                   	// #1
    4cb8:	b0000040 	adrp	x0, d000 <__divti3+0x240>
    4cbc:	9120c000 	add	x0, x0, #0x830
    4cc0:	f9400063 	ldr	x3, [x3]
    4cc4:	97fff753 	bl	2a10 <fwrite@plt>
    4cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    4ccc:	97fff6bd 	bl	27c0 <exit@plt>

0000000000004cd0 <fwp_heap_alloc_big>:
    4cd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd4:	910003fd 	mov	x29, sp
    4cd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce4:	aa0003f7 	mov	x23, x0
    4ce8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf0:	eb0002ff 	cmp	x23, x0
    4cf4:	540008a8 	b.hi	4e08 <fwp_heap_alloc_big+0x138>  // b.pmore
    4cf8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cfc:	8b0002f4 	add	x20, x23, x0
    4d00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d04:	91174359 	add	x25, x26, #0x5d0
    4d08:	d350fe94 	lsr	x20, x20, #16
    4d0c:	2a0103f5 	mov	w21, w1
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff987 	bl	3330 <fwp_heap_chunks>
    4d18:	f949ff22 	ldr	x2, [x25, #5112]
    4d1c:	8b000813 	add	x19, x0, x0, lsl #2
    4d20:	aa0003f8 	mov	x24, x0
    4d24:	52800043 	mov	w3, #0x2                   	// #2
    4d28:	d37df273 	lsl	x19, x19, #3
    4d2c:	d2800021 	mov	x1, #0x1                   	// #1
    4d30:	8b130040 	add	x0, x2, x19
    4d34:	38336843 	strb	w3, [x2, x19]
    4d38:	39000415 	strb	w21, [x0, #1]
    4d3c:	b9000c14 	str	w20, [x0, #12]
    4d40:	f9000817 	str	x23, [x0, #16]
    4d44:	97fffd57 	bl	42a0 <fwp_rc_prepare_chunk>
    4d48:	f100069f 	cmp	x20, #0x1
    4d4c:	54000289 	b.ls	4d9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4d50:	8b180294 	add	x20, x20, x24
    4d54:	9100a273 	add	x19, x19, #0x28
    4d58:	a90573fb 	stp	x27, x28, [sp, #80]
    4d5c:	5280007b 	mov	w27, #0x3                   	// #3
    4d60:	8b140a94 	add	x20, x20, x20, lsl #2
    4d64:	2a1803fc 	mov	w28, w24
    4d68:	9adb2296 	lsl	x22, x20, x27
    4d6c:	d503201f 	nop
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffd48 	bl	42a0 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0xa0>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x108>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffbbf 	bl	3df0 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff6f 	b	4cd0 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffd19 	bl	43c0 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_tape_grow.constprop.0>:
    51a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51a8:	d2800803 	mov	x3, #0x40                  	// #64
    51ac:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    51b0:	910003fd 	mov	x29, sp
    51b4:	a90153f3 	stp	x19, x20, [sp, #16]
    51b8:	f9400c13 	ldr	x19, [x0, #24]
    51bc:	a90363f7 	stp	x23, x24, [sp, #48]
    51c0:	aa0003f7 	mov	x23, x0
    51c4:	f100027f 	cmp	x19, #0x0
    51c8:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    51cc:	eb13003f 	cmp	x1, x19
    51d0:	540000ed 	b.le	51ec <fwp_tape_grow.constprop.0+0x48>
    51d4:	eb02027f 	cmp	x19, x2
    51d8:	5400076d 	b.le	52c4 <fwp_tape_grow.constprop.0+0x120>
    51dc:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    51e0:	eb13003f 	cmp	x1, x19
    51e4:	5400004d 	b.le	51ec <fwp_tape_grow.constprop.0+0x48>
    51e8:	14000000 	b	51e8 <fwp_tape_grow.constprop.0+0x44>
    51ec:	a940d2e2 	ldp	x2, x20, [x23, #8]
    51f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    51f4:	d37df276 	lsl	x22, x19, #3
    51f8:	f94012e0 	ldr	x0, [x23, #32]
    51fc:	aa1603e1 	mov	x1, x22
    5200:	f94032f5 	ldr	x21, [x23, #96]
    5204:	cb020294 	sub	x20, x20, x2
    5208:	97fff5be 	bl	2900 <realloc@plt>
    520c:	b4000c20 	cbz	x0, 5390 <fwp_tape_grow.constprop.0+0x1ec>
    5210:	f9400ee1 	ldr	x1, [x23, #24]
    5214:	8b010801 	add	x1, x0, x1, lsl #2
    5218:	a90206e0 	stp	x0, x1, [x23, #32]
    521c:	b4000895 	cbz	x21, 532c <fwp_tape_grow.constprop.0+0x188>
    5220:	f94032b6 	ldr	x22, [x21, #96]
    5224:	eb1302df 	cmp	x22, x19
    5228:	540003aa 	b.ge	529c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    522c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5230:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    5234:	eb00027f 	cmp	x19, x0
    5238:	54000a68 	b.hi	5384 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    523c:	f94022b9 	ldr	x25, [x21, #64]
    5240:	d37cee7a 	lsl	x26, x19, #4
    5244:	aa1a03e0 	mov	x0, x26
    5248:	52800041 	mov	w1, #0x2                   	// #2
    524c:	97ffff49 	bl	4f70 <fwp_heap_alloc>
    5250:	aa0003f8 	mov	x24, x0
    5254:	b4000119 	cbz	x25, 5274 <fwp_tape_grow.constprop.0+0xd0>
    5258:	d37ceed6 	lsl	x22, x22, #4
    525c:	aa1903e1 	mov	x1, x25
    5260:	eb1a02df 	cmp	x22, x26
    5264:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    5268:	97fff53e 	bl	2760 <memcpy@plt>
    526c:	aa1903e0 	mov	x0, x25
    5270:	97fffc84 	bl	4480 <fwp_mem_free>
    5274:	f94032a0 	ldr	x0, [x21, #96]
    5278:	52800001 	mov	w1, #0x0                   	// #0
    527c:	cb000262 	sub	x2, x19, x0
    5280:	8b001300 	add	x0, x24, x0, lsl #4
    5284:	d37cec42 	lsl	x2, x2, #4
    5288:	97fff596 	bl	28e0 <memset@plt>
    528c:	f94012e0 	ldr	x0, [x23, #32]
    5290:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5294:	f90022b8 	str	x24, [x21, #64]
    5298:	f90032b3 	str	x19, [x21, #96]
    529c:	d37ef675 	lsl	x21, x19, #2
    52a0:	b50002b4 	cbnz	x20, 52f4 <fwp_tape_grow.constprop.0+0x150>
    52a4:	8b150001 	add	x1, x0, x21
    52a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52ac:	f9000ef3 	str	x19, [x23, #24]
    52b0:	f90016e1 	str	x1, [x23, #40]
    52b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    52bc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52c0:	d65f03c0 	ret
    52c4:	d37ffa73 	lsl	x19, x19, #1
    52c8:	17ffffc1 	b	51cc <fwp_tape_grow.constprop.0+0x28>
    52cc:	eb1502df 	cmp	x22, x21
    52d0:	aa0403e0 	mov	x0, x4
    52d4:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    52d8:	d37df282 	lsl	x2, x20, #3
    52dc:	cb160063 	sub	x3, x3, x22
    52e0:	97fff5f4 	bl	2ab0 <__memmove_chk@plt>
    52e4:	f9401ae1 	ldr	x1, [x23, #48]
    52e8:	f94012e0 	ldr	x0, [x23, #32]
    52ec:	8b160021 	add	x1, x1, x22
    52f0:	f9001ee1 	str	x1, [x23, #56]
    52f4:	f94016e1 	ldr	x1, [x23, #40]
    52f8:	d37ef675 	lsl	x21, x19, #2
    52fc:	d37ef682 	lsl	x2, x20, #2
    5300:	8b150000 	add	x0, x0, x21
    5304:	97fff51f 	bl	2780 <memmove@plt>
    5308:	f94012e0 	ldr	x0, [x23, #32]
    530c:	8b150001 	add	x1, x0, x21
    5310:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5314:	f9000ef3 	str	x19, [x23, #24]
    5318:	f90016e1 	str	x1, [x23, #40]
    531c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5328:	d65f03c0 	ret
    532c:	f9401ae0 	ldr	x0, [x23, #48]
    5330:	d37cee75 	lsl	x21, x19, #4
    5334:	aa1503e1 	mov	x1, x21
    5338:	97fff572 	bl	2900 <realloc@plt>
    533c:	b40002a0 	cbz	x0, 5390 <fwp_tape_grow.constprop.0+0x1ec>
    5340:	f9400ee2 	ldr	x2, [x23, #24]
    5344:	f9001ae0 	str	x0, [x23, #48]
    5348:	8b160004 	add	x4, x0, x22
    534c:	8b020c01 	add	x1, x0, x2, lsl #3
    5350:	f9001ee1 	str	x1, [x23, #56]
    5354:	b5fffbd4 	cbnz	x20, 52cc <fwp_tape_grow.constprop.0+0x128>
    5358:	f94012e0 	ldr	x0, [x23, #32]
    535c:	d37ef675 	lsl	x21, x19, #2
    5360:	f9001ee4 	str	x4, [x23, #56]
    5364:	8b150001 	add	x1, x0, x21
    5368:	a9425bf5 	ldp	x21, x22, [sp, #32]
    536c:	f9000ef3 	str	x19, [x23, #24]
    5370:	f90016e1 	str	x1, [x23, #40]
    5374:	a94153f3 	ldp	x19, x20, [sp, #16]
    5378:	a94363f7 	ldp	x23, x24, [sp, #48]
    537c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5380:	d65f03c0 	ret
    5384:	90000040 	adrp	x0, d000 <__divti3+0x240>
    5388:	91222000 	add	x0, x0, #0x888
    538c:	97fffb81 	bl	4190 <fwp_trap>
    5390:	aa1703e0 	mov	x0, x23
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	97fff71e 	bl	3010 <fwp_tape_unlink_scope>
    539c:	f94012e0 	ldr	x0, [x23, #32]
    53a0:	97fff58c 	bl	29d0 <free@plt>
    53a4:	f9401ae0 	ldr	x0, [x23, #48]
    53a8:	97fff58a 	bl	29d0 <free@plt>
    53ac:	f94022e0 	ldr	x0, [x23, #64]
    53b0:	97fff588 	bl	29d0 <free@plt>
    53b4:	f9000eff 	str	xzr, [x23, #24]
    53b8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    53bc:	f947e821 	ldr	x1, [x1, #4048]
    53c0:	a9047eff 	stp	xzr, xzr, [x23, #64]
    53c4:	d2800262 	mov	x2, #0x13                  	// #19
    53c8:	4f000400 	movi	v0.4s, #0x0
    53cc:	90000040 	adrp	x0, d000 <__divti3+0x240>
    53d0:	f9400023 	ldr	x3, [x1]
    53d4:	b90006ff 	str	wzr, [x23, #4]
    53d8:	d2800021 	mov	x1, #0x1                   	// #1
    53dc:	9113a000 	add	x0, x0, #0x4e8
    53e0:	3c8082e0 	stur	q0, [x23, #8]
    53e4:	ad0102e0 	stp	q0, q0, [x23, #32]
    53e8:	97fff58a 	bl	2a10 <fwrite@plt>
    53ec:	d2800000 	mov	x0, #0x0                   	// #0
    53f0:	97fff594 	bl	2a40 <fflush@plt>
    53f4:	52800cc0 	mov	w0, #0x66                  	// #102
    53f8:	97fff5a2 	bl	2a80 <_Exit@plt>
    53fc:	d503201f 	nop

0000000000005400 <f141.constprop.0>:
    5400:	f100001f 	cmp	x0, #0x0
    5404:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5408:	54000a2b 	b.lt	554c <f141.constprop.0+0x14c>  // b.tstop
    540c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5410:	aa0003e2 	mov	x2, x0
    5414:	910003fd 	mov	x29, sp
    5418:	a90153f3 	stp	x19, x20, [sp, #16]
    541c:	aa0003f4 	mov	x20, x0
    5420:	aa010000 	orr	x0, x0, x1
    5424:	a9025bf5 	stp	x21, x22, [sp, #32]
    5428:	aa0103f6 	mov	x22, x1
    542c:	f9001bf7 	str	x23, [sp, #48]
    5430:	fd001fe8 	str	d8, [sp, #56]
    5434:	b7f80180 	tbnz	x0, #63, 5464 <f141.constprop.0+0x64>
    5438:	9360fc20 	asr	x0, x1, #32
    543c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5440:	eb82801f 	cmp	x0, x2, asr #32
    5444:	54000881 	b.ne	5554 <f141.constprop.0+0x154>  // b.any
    5448:	97fffd56 	bl	49a0 <fwp_tape_of>
    544c:	aa0003f3 	mov	x19, x0
    5450:	f9403000 	ldr	x0, [x0, #96]
    5454:	b40001e0 	cbz	x0, 5490 <f141.constprop.0+0x90>
    5458:	90000040 	adrp	x0, d000 <__divti3+0x240>
    545c:	9123c000 	add	x0, x0, #0x8f0
    5460:	97fffb4c 	bl	4190 <fwp_trap>
    5464:	9360fc40 	asr	x0, x2, #32
    5468:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    546c:	b6fffee2 	tbz	x2, #63, 5448 <f141.constprop.0+0x48>
    5470:	2f00e408 	movi	d8, #0x0
    5474:	9360fc20 	asr	x0, x1, #32
    5478:	aa0103f4 	mov	x20, x1
    547c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5480:	97fffd48 	bl	49a0 <fwp_tape_of>
    5484:	aa0003f3 	mov	x19, x0
    5488:	f9403000 	ldr	x0, [x0, #96]
    548c:	b5fffe60 	cbnz	x0, 5458 <f141.constprop.0+0x58>
    5490:	f9400a77 	ldr	x23, [x19, #16]
    5494:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5498:	eb0002ff 	cmp	x23, x0
    549c:	5400046c 	b.gt	5528 <f141.constprop.0+0x128>
    54a0:	eb3442ff 	cmp	x23, w20, uxtw
    54a4:	540004ed 	b.le	5540 <f141.constprop.0+0x140>
    54a8:	b7f80076 	tbnz	x22, #63, 54b4 <f141.constprop.0+0xb4>
    54ac:	eb3642ff 	cmp	x23, w22, uxtw
    54b0:	5400048d 	b.le	5540 <f141.constprop.0+0x140>
    54b4:	f9400675 	ldr	x21, [x19, #8]
    54b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54bc:	cb1502f5 	sub	x21, x23, x21
    54c0:	910006a1 	add	x1, x21, #0x1
    54c4:	eb00003f 	cmp	x1, x0
    54c8:	54000308 	b.hi	5528 <f141.constprop.0+0x128>  // b.pmore
    54cc:	f9400e60 	ldr	x0, [x19, #24]
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	5400030c 	b.gt	5534 <f141.constprop.0+0x134>
    54d8:	a9420262 	ldp	x2, x0, [x19, #32]
    54dc:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54e0:	f9401a61 	ldr	x1, [x19, #48]
    54e4:	b8357854 	str	w20, [x2, x21, lsl #2]
    54e8:	f9401e62 	ldr	x2, [x19, #56]
    54ec:	f10002df 	cmp	x22, #0x0
    54f0:	fc357820 	str	d0, [x1, x21, lsl #3]
    54f4:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    54f8:	b8357816 	str	w22, [x0, x21, lsl #2]
    54fc:	92607e80 	and	x0, x20, #0xffffffff00000000
    5500:	910006e1 	add	x1, x23, #0x1
    5504:	aa170000 	orr	x0, x0, x23
    5508:	fc357848 	str	d8, [x2, x21, lsl #3]
    550c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5510:	f9401bf7 	ldr	x23, [sp, #48]
    5514:	fd401fe8 	ldr	d8, [sp, #56]
    5518:	f9000a61 	str	x1, [x19, #16]
    551c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5520:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5524:	d65f03c0 	ret
    5528:	90000040 	adrp	x0, d000 <__divti3+0x240>
    552c:	91222000 	add	x0, x0, #0x888
    5530:	97fffb18 	bl	4190 <fwp_trap>
    5534:	aa1303e0 	mov	x0, x19
    5538:	97ffff1b 	bl	51a4 <fwp_tape_grow.constprop.0>
    553c:	17ffffe7 	b	54d8 <f141.constprop.0+0xd8>
    5540:	90000040 	adrp	x0, d000 <__divti3+0x240>
    5544:	91248000 	add	x0, x0, #0x920
    5548:	97fffb12 	bl	4190 <fwp_trap>
    554c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5550:	d65f03c0 	ret
    5554:	90000040 	adrp	x0, d000 <__divti3+0x240>
    5558:	9122a000 	add	x0, x0, #0x8a8
    555c:	97fffb0d 	bl	4190 <fwp_trap>

0000000000005560 <w120>:
    5560:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5564:	910003fd 	mov	x29, sp
    5568:	a90153f3 	stp	x19, x20, [sp, #16]
    556c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5570:	a90363f7 	stp	x23, x24, [sp, #48]
    5574:	aa0003f8 	mov	x24, x0
    5578:	a9046bf9 	stp	x25, x26, [sp, #64]
    557c:	aa0103f9 	mov	x25, x1
    5580:	6d0527e8 	stp	d8, d9, [sp, #80]
    5584:	1e604008 	fmov	d8, d0
    5588:	1e604029 	fmov	d9, d1
    558c:	6d062fea 	stp	d10, d11, [sp, #96]
    5590:	1e60080a 	fmul	d10, d0, d0
    5594:	b7f821a0 	tbnz	x0, #63, 59c8 <w120+0x468>
    5598:	9360fc17 	asr	x23, x0, #32
    559c:	aa1703e0 	mov	x0, x23
    55a0:	97fffd00 	bl	49a0 <fwp_tape_of>
    55a4:	f9403001 	ldr	x1, [x0, #96]
    55a8:	aa0003f3 	mov	x19, x0
    55ac:	b4000081 	cbz	x1, 55bc <w120+0x5c>
    55b0:	90000040 	adrp	x0, d000 <__divti3+0x240>
    55b4:	9123c000 	add	x0, x0, #0x8f0
    55b8:	97fffaf6 	bl	4190 <fwp_trap>
    55bc:	f9400815 	ldr	x21, [x0, #16]
    55c0:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    55c4:	eb0102bf 	cmp	x21, x1
    55c8:	54001d8c 	b.gt	5978 <w120+0x418>
    55cc:	eb3842bf 	cmp	x21, w24, uxtw
    55d0:	54001ced 	b.le	596c <w120+0x40c>
    55d4:	f9400416 	ldr	x22, [x0, #8]
    55d8:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    55dc:	cb1602b6 	sub	x22, x21, x22
    55e0:	910006c1 	add	x1, x22, #0x1
    55e4:	eb02003f 	cmp	x1, x2
    55e8:	54001c88 	b.hi	5978 <w120+0x418>  // b.pmore
    55ec:	f9400c02 	ldr	x2, [x0, #24]
    55f0:	eb02003f 	cmp	x1, x2
    55f4:	54001c8c 	b.gt	5984 <w120+0x424>
    55f8:	a9420660 	ldp	x0, x1, [x19, #32]
    55fc:	92607f14 	and	x20, x24, #0xffffffff00000000
    5600:	f9401a62 	ldr	x2, [x19, #48]
    5604:	b8367818 	str	w24, [x0, x22, lsl #2]
    5608:	f9401e60 	ldr	x0, [x19, #56]
    560c:	aa150294 	orr	x20, x20, x21
    5610:	fc367848 	str	d8, [x2, x22, lsl #3]
    5614:	910006b5 	add	x21, x21, #0x1
    5618:	b8367838 	str	w24, [x1, x22, lsl #2]
    561c:	1e6a392a 	fsub	d10, d9, d10
    5620:	9360fe9a 	asr	x26, x20, #32
    5624:	fc367808 	str	d8, [x0, x22, lsl #3]
    5628:	f9000a75 	str	x21, [x19, #16]
    562c:	b7f80079 	tbnz	x25, #63, 5638 <w120+0xd8>
    5630:	eb99835f 	cmp	x26, x25, asr #32
    5634:	54001e21 	b.ne	59f8 <w120+0x498>  // b.any
    5638:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    563c:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    5640:	eb1a02ff 	cmp	x23, x26
    5644:	540000c0 	b.eq	565c <w120+0xfc>  // b.none
    5648:	aa1a03e0 	mov	x0, x26
    564c:	97fffcd5 	bl	49a0 <fwp_tape_of>
    5650:	aa0003f3 	mov	x19, x0
    5654:	f9403000 	ldr	x0, [x0, #96]
    5658:	b5fffac0 	cbnz	x0, 55b0 <w120+0x50>
    565c:	f9400a77 	ldr	x23, [x19, #16]
    5660:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5664:	eb0002ff 	cmp	x23, x0
    5668:	5400188c 	b.gt	5978 <w120+0x418>
    566c:	eb3442ff 	cmp	x23, w20, uxtw
    5670:	540017ed 	b.le	596c <w120+0x40c>
    5674:	b7f80079 	tbnz	x25, #63, 5680 <w120+0x120>
    5678:	eb3942ff 	cmp	x23, w25, uxtw
    567c:	5400178d 	b.le	596c <w120+0x40c>
    5680:	f9400675 	ldr	x21, [x19, #8]
    5684:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5688:	cb1502f5 	sub	x21, x23, x21
    568c:	910006a1 	add	x1, x21, #0x1
    5690:	eb00003f 	cmp	x1, x0
    5694:	54001728 	b.hi	5978 <w120+0x418>  // b.pmore
    5698:	f9400e60 	ldr	x0, [x19, #24]
    569c:	eb00003f 	cmp	x1, x0
    56a0:	540018ec 	b.gt	59bc <w120+0x45c>
    56a4:	a9420e62 	ldp	x2, x3, [x19, #32]
    56a8:	f100033f 	cmp	x25, #0x0
    56ac:	f9401a61 	ldr	x1, [x19, #48]
    56b0:	b8357854 	str	w20, [x2, x21, lsl #2]
    56b4:	f9401e62 	ldr	x2, [x19, #56]
    56b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56bc:	fc35782b 	str	d11, [x1, x21, lsl #3]
    56c0:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    56c4:	b8357861 	str	w1, [x3, x21, lsl #2]
    56c8:	910006f6 	add	x22, x23, #0x1
    56cc:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    56d0:	92607e94 	and	x20, x20, #0xffffffff00000000
    56d4:	fc357849 	str	d9, [x2, x21, lsl #3]
    56d8:	aa170294 	orr	x20, x20, x23
    56dc:	f9000a76 	str	x22, [x19, #16]
    56e0:	1e68396b 	fsub	d11, d11, d8
    56e4:	b7f81a78 	tbnz	x24, #63, 5a30 <w120+0x4d0>
    56e8:	9360ff17 	asr	x23, x24, #32
    56ec:	eb1a02ff 	cmp	x23, x26
    56f0:	540000e0 	b.eq	570c <w120+0x1ac>  // b.none
    56f4:	aa1703e0 	mov	x0, x23
    56f8:	97fffcaa 	bl	49a0 <fwp_tape_of>
    56fc:	aa0003f3 	mov	x19, x0
    5700:	f9403000 	ldr	x0, [x0, #96]
    5704:	b5fff560 	cbnz	x0, 55b0 <w120+0x50>
    5708:	f9400a76 	ldr	x22, [x19, #16]
    570c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5710:	eb0002df 	cmp	x22, x0
    5714:	5400132c 	b.gt	5978 <w120+0x418>
    5718:	eb3842df 	cmp	x22, w24, uxtw
    571c:	5400128d 	b.le	596c <w120+0x40c>
    5720:	f9400675 	ldr	x21, [x19, #8]
    5724:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5728:	cb1502d5 	sub	x21, x22, x21
    572c:	910006a1 	add	x1, x21, #0x1
    5730:	eb00003f 	cmp	x1, x0
    5734:	54001228 	b.hi	5978 <w120+0x418>  // b.pmore
    5738:	f9400e60 	ldr	x0, [x19, #24]
    573c:	eb00003f 	cmp	x1, x0
    5740:	5400138c 	b.gt	59b0 <w120+0x450>
    5744:	a9420262 	ldp	x2, x0, [x19, #32]
    5748:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    574c:	f9401a63 	ldr	x3, [x19, #48]
    5750:	b8357858 	str	w24, [x2, x21, lsl #2]
    5754:	f9401e62 	ldr	x2, [x19, #56]
    5758:	12800001 	mov	w1, #0xffffffff            	// #-1
    575c:	fc357860 	str	d0, [x3, x21, lsl #3]
    5760:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5764:	b8357801 	str	w1, [x0, x21, lsl #2]
    5768:	92607f00 	and	x0, x24, #0xffffffff00000000
    576c:	aa160018 	orr	x24, x0, x22
    5770:	910006c1 	add	x1, x22, #0x1
    5774:	fc357840 	str	d0, [x2, x21, lsl #3]
    5778:	f9000a61 	str	x1, [x19, #16]
    577c:	9360fe99 	asr	x25, x20, #32
    5780:	1e6a0949 	fmul	d9, d10, d10
    5784:	eb17033f 	cmp	x25, x23
    5788:	540000c0 	b.eq	57a0 <w120+0x240>  // b.none
    578c:	aa1903e0 	mov	x0, x25
    5790:	97fffc84 	bl	49a0 <fwp_tape_of>
    5794:	aa0003f3 	mov	x19, x0
    5798:	f9403000 	ldr	x0, [x0, #96]
    579c:	b5fff0a0 	cbnz	x0, 55b0 <w120+0x50>
    57a0:	f9400a75 	ldr	x21, [x19, #16]
    57a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57a8:	eb0002bf 	cmp	x21, x0
    57ac:	54000e6c 	b.gt	5978 <w120+0x418>
    57b0:	eb3442bf 	cmp	x21, w20, uxtw
    57b4:	54000dcd 	b.le	596c <w120+0x40c>
    57b8:	f9400676 	ldr	x22, [x19, #8]
    57bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57c0:	cb1602b6 	sub	x22, x21, x22
    57c4:	910006c1 	add	x1, x22, #0x1
    57c8:	eb00003f 	cmp	x1, x0
    57cc:	54000d68 	b.hi	5978 <w120+0x418>  // b.pmore
    57d0:	f9400e60 	ldr	x0, [x19, #24]
    57d4:	eb00003f 	cmp	x1, x0
    57d8:	54000e6c 	b.gt	59a4 <w120+0x444>
    57dc:	92607e80 	and	x0, x20, #0xffffffff00000000
    57e0:	aa150017 	orr	x23, x0, x21
    57e4:	a9420261 	ldp	x1, x0, [x19, #32]
    57e8:	f9401a62 	ldr	x2, [x19, #48]
    57ec:	b8367834 	str	w20, [x1, x22, lsl #2]
    57f0:	f9401e61 	ldr	x1, [x19, #56]
    57f4:	fc36784a 	str	d10, [x2, x22, lsl #3]
    57f8:	b8367814 	str	w20, [x0, x22, lsl #2]
    57fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5800:	9e670000 	fmov	d0, x0
    5804:	910006b4 	add	x20, x21, #0x1
    5808:	fc36782a 	str	d10, [x1, x22, lsl #3]
    580c:	9360fef6 	asr	x22, x23, #32
    5810:	f9000a74 	str	x20, [x19, #16]
    5814:	1e600929 	fmul	d9, d9, d0
    5818:	eb1902df 	cmp	x22, x25
    581c:	540000e0 	b.eq	5838 <w120+0x2d8>  // b.none
    5820:	aa1603e0 	mov	x0, x22
    5824:	97fffc5f 	bl	49a0 <fwp_tape_of>
    5828:	aa0003f3 	mov	x19, x0
    582c:	f9403000 	ldr	x0, [x0, #96]
    5830:	b5ffec00 	cbnz	x0, 55b0 <w120+0x50>
    5834:	f9400a74 	ldr	x20, [x19, #16]
    5838:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    583c:	eb00029f 	cmp	x20, x0
    5840:	540009cc 	b.gt	5978 <w120+0x418>
    5844:	eb37429f 	cmp	x20, w23, uxtw
    5848:	5400092d 	b.le	596c <w120+0x40c>
    584c:	f9400675 	ldr	x21, [x19, #8]
    5850:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5854:	cb150295 	sub	x21, x20, x21
    5858:	910006a1 	add	x1, x21, #0x1
    585c:	eb00003f 	cmp	x1, x0
    5860:	540008c8 	b.hi	5978 <w120+0x418>  // b.pmore
    5864:	f9400e60 	ldr	x0, [x19, #24]
    5868:	eb00003f 	cmp	x1, x0
    586c:	5400096c 	b.gt	5998 <w120+0x438>
    5870:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5874:	9e670000 	fmov	d0, x0
    5878:	a9420262 	ldp	x2, x0, [x19, #32]
    587c:	1e6b0968 	fmul	d8, d11, d11
    5880:	f9401a61 	ldr	x1, [x19, #48]
    5884:	b8357857 	str	w23, [x2, x21, lsl #2]
    5888:	f9401e62 	ldr	x2, [x19, #56]
    588c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5890:	12800001 	mov	w1, #0xffffffff            	// #-1
    5894:	b8357801 	str	w1, [x0, x21, lsl #2]
    5898:	91000681 	add	x1, x20, #0x1
    589c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    58a0:	92607ee0 	and	x0, x23, #0xffffffff00000000
    58a4:	f9000a61 	str	x1, [x19, #16]
    58a8:	aa140014 	orr	x20, x0, x20
    58ac:	b100071f 	cmn	x24, #0x1
    58b0:	54000c60 	b.eq	5a3c <w120+0x4dc>  // b.none
    58b4:	9360ff00 	asr	x0, x24, #32
    58b8:	eb16001f 	cmp	x0, x22
    58bc:	540000a0 	b.eq	58d0 <w120+0x370>  // b.none
    58c0:	97fffc38 	bl	49a0 <fwp_tape_of>
    58c4:	aa0003f3 	mov	x19, x0
    58c8:	f9403000 	ldr	x0, [x0, #96]
    58cc:	b5ffe720 	cbnz	x0, 55b0 <w120+0x50>
    58d0:	f9400a75 	ldr	x21, [x19, #16]
    58d4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58d8:	eb0002bf 	cmp	x21, x0
    58dc:	540004ec 	b.gt	5978 <w120+0x418>
    58e0:	eb3842bf 	cmp	x21, w24, uxtw
    58e4:	5400044d 	b.le	596c <w120+0x40c>
    58e8:	f9400676 	ldr	x22, [x19, #8]
    58ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    58f0:	cb1602b6 	sub	x22, x21, x22
    58f4:	910006c1 	add	x1, x22, #0x1
    58f8:	eb00003f 	cmp	x1, x0
    58fc:	540003e8 	b.hi	5978 <w120+0x418>  // b.pmore
    5900:	f9400e60 	ldr	x0, [x19, #24]
    5904:	eb00003f 	cmp	x1, x0
    5908:	5400042c 	b.gt	598c <w120+0x42c>
    590c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5910:	92607f00 	and	x0, x24, #0xffffffff00000000
    5914:	f9401a63 	ldr	x3, [x19, #48]
    5918:	b8367838 	str	w24, [x1, x22, lsl #2]
    591c:	f9401e61 	ldr	x1, [x19, #56]
    5920:	aa150000 	orr	x0, x0, x21
    5924:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5928:	910006b5 	add	x21, x21, #0x1
    592c:	b8367858 	str	w24, [x2, x22, lsl #2]
    5930:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5934:	f9000a75 	str	x21, [x19, #16]
    5938:	1e692908 	fadd	d8, d8, d9
    593c:	aa1403e1 	mov	x1, x20
    5940:	97fffeb0 	bl	5400 <f141.constprop.0>
    5944:	aa0003e1 	mov	x1, x0
    5948:	a94153f3 	ldp	x19, x20, [sp, #16]
    594c:	9e660100 	fmov	x0, d8
    5950:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5954:	a94363f7 	ldp	x23, x24, [sp, #48]
    5958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    595c:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5960:	6d462fea 	ldp	d10, d11, [sp, #96]
    5964:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5968:	d65f03c0 	ret
    596c:	90000040 	adrp	x0, d000 <__divti3+0x240>
    5970:	91248000 	add	x0, x0, #0x920
    5974:	97fffa07 	bl	4190 <fwp_trap>
    5978:	90000040 	adrp	x0, d000 <__divti3+0x240>
    597c:	91222000 	add	x0, x0, #0x888
    5980:	97fffa04 	bl	4190 <fwp_trap>
    5984:	97fffe08 	bl	51a4 <fwp_tape_grow.constprop.0>
    5988:	17ffff1c 	b	55f8 <w120+0x98>
    598c:	aa1303e0 	mov	x0, x19
    5990:	97fffe05 	bl	51a4 <fwp_tape_grow.constprop.0>
    5994:	17ffffde 	b	590c <w120+0x3ac>
    5998:	aa1303e0 	mov	x0, x19
    599c:	97fffe02 	bl	51a4 <fwp_tape_grow.constprop.0>
    59a0:	17ffffb4 	b	5870 <w120+0x310>
    59a4:	aa1303e0 	mov	x0, x19
    59a8:	97fffdff 	bl	51a4 <fwp_tape_grow.constprop.0>
    59ac:	17ffff8c 	b	57dc <w120+0x27c>
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	97fffdfc 	bl	51a4 <fwp_tape_grow.constprop.0>
    59b8:	17ffff63 	b	5744 <w120+0x1e4>
    59bc:	aa1303e0 	mov	x0, x19
    59c0:	97fffdf9 	bl	51a4 <fwp_tape_grow.constprop.0>
    59c4:	17ffff38 	b	56a4 <w120+0x144>
    59c8:	1e6a382a 	fsub	d10, d1, d10
    59cc:	b6f801c1 	tbz	x1, #63, 5a04 <w120+0x4a4>
    59d0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    59d4:	1e6a0949 	fmul	d9, d10, d10
    59d8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    59dc:	9e670001 	fmov	d1, x0
    59e0:	1e683808 	fsub	d8, d0, d8
    59e4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    59e8:	aa1403e0 	mov	x0, x20
    59ec:	1e610929 	fmul	d9, d9, d1
    59f0:	1e680908 	fmul	d8, d8, d8
    59f4:	17ffffd1 	b	5938 <w120+0x3d8>
    59f8:	90000040 	adrp	x0, d000 <__divti3+0x240>
    59fc:	9122a000 	add	x0, x0, #0x8a8
    5a00:	97fff9e4 	bl	4190 <fwp_trap>
    5a04:	2f00e409 	movi	d9, #0x0
    5a08:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5a0c:	9360fc3a 	asr	x26, x1, #32
    5a10:	aa0103f4 	mov	x20, x1
    5a14:	aa1a03e0 	mov	x0, x26
    5a18:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5a1c:	97fffbe1 	bl	49a0 <fwp_tape_of>
    5a20:	aa0003f3 	mov	x19, x0
    5a24:	f9403000 	ldr	x0, [x0, #96]
    5a28:	b5ffdc40 	cbnz	x0, 55b0 <w120+0x50>
    5a2c:	17ffff0c 	b	565c <w120+0xfc>
    5a30:	aa1a03f7 	mov	x23, x26
    5a34:	aa0003f8 	mov	x24, x0
    5a38:	17ffff51 	b	577c <w120+0x21c>
    5a3c:	aa1803e0 	mov	x0, x24
    5a40:	17ffffbe 	b	5938 <w120+0x3d8>

0000000000005a44 <fwp_rc_share>:
    5a44:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5a48:	91174042 	add	x2, x2, #0x5d0
    5a4c:	f949d843 	ldr	x3, [x2, #5040]
    5a50:	f949ec41 	ldr	x1, [x2, #5080]
    5a54:	cb030000 	sub	x0, x0, x3
    5a58:	eb01401f 	cmp	x0, x1, lsl #16
    5a5c:	540003a2 	b.cs	5ad0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5a60:	d350fc01 	lsr	x1, x0, #16
    5a64:	f949fc44 	ldr	x4, [x2, #5112]
    5a68:	8b010821 	add	x1, x1, x1, lsl #2
    5a6c:	d37df021 	lsl	x1, x1, #3
    5a70:	8b010083 	add	x3, x4, x1
    5a74:	f9401062 	ldr	x2, [x3, #32]
    5a78:	b40002c2 	cbz	x2, 5ad0 <fwp_rc_share+0x8c>
    5a7c:	38616881 	ldrb	w1, [x4, x1]
    5a80:	7100083f 	cmp	w1, #0x2
    5a84:	54000220 	b.eq	5ac8 <fwp_rc_share+0x84>  // b.none
    5a88:	7100043f 	cmp	w1, #0x1
    5a8c:	54000221 	b.ne	5ad0 <fwp_rc_share+0x8c>  // b.any
    5a90:	29430464 	ldp	w4, w1, [x3, #24]
    5a94:	92403c00 	and	x0, x0, #0xffff
    5a98:	9b047c00 	mul	x0, x0, x4
    5a9c:	d360fc00 	lsr	x0, x0, #32
    5aa0:	eb01001f 	cmp	x0, x1
    5aa4:	54000162 	b.cs	5ad0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5aa8:	8b000042 	add	x2, x2, x0
    5aac:	39400040 	ldrb	w0, [x2]
    5ab0:	34000100 	cbz	w0, 5ad0 <fwp_rc_share+0x8c>
    5ab4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ab8:	90000040 	adrp	x0, d000 <__divti3+0x240>
    5abc:	91250000 	add	x0, x0, #0x940
    5ac0:	910003fd 	mov	x29, sp
    5ac4:	97fff9b3 	bl	4190 <fwp_trap>
    5ac8:	72003c1f 	tst	w0, #0xffff
    5acc:	54ffff00 	b.eq	5aac <fwp_rc_share+0x68>  // b.none
    5ad0:	d65f03c0 	ret

0000000000005ad4 <fwp_rc_fresh>:
    5ad4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ad8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5adc:	91174063 	add	x3, x3, #0x5d0
    5ae0:	910003fd 	mov	x29, sp
    5ae4:	a90153f3 	stp	x19, x20, [sp, #16]
    5ae8:	aa0003f3 	mov	x19, x0
    5aec:	f949d861 	ldr	x1, [x3, #5040]
    5af0:	f949ec60 	ldr	x0, [x3, #5080]
    5af4:	cb010261 	sub	x1, x19, x1
    5af8:	eb00403f 	cmp	x1, x0, lsl #16
    5afc:	54000322 	b.cs	5b60 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b00:	d350fc22 	lsr	x2, x1, #16
    5b04:	f949fc63 	ldr	x3, [x3, #5112]
    5b08:	8b020842 	add	x2, x2, x2, lsl #2
    5b0c:	d37df042 	lsl	x2, x2, #3
    5b10:	8b020060 	add	x0, x3, x2
    5b14:	f9401014 	ldr	x20, [x0, #32]
    5b18:	b4000254 	cbz	x20, 5b60 <fwp_rc_fresh+0x8c>
    5b1c:	38626862 	ldrb	w2, [x3, x2]
    5b20:	7100085f 	cmp	w2, #0x2
    5b24:	54000260 	b.eq	5b70 <fwp_rc_fresh+0x9c>  // b.none
    5b28:	7100045f 	cmp	w2, #0x1
    5b2c:	540001a1 	b.ne	5b60 <fwp_rc_fresh+0x8c>  // b.any
    5b30:	29430002 	ldp	w2, w0, [x0, #24]
    5b34:	92403c21 	and	x1, x1, #0xffff
    5b38:	9b027c21 	mul	x1, x1, x2
    5b3c:	d360fc21 	lsr	x1, x1, #32
    5b40:	eb00003f 	cmp	x1, x0
    5b44:	540000e2 	b.cs	5b60 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b48:	8b010294 	add	x20, x20, x1
    5b4c:	39400280 	ldrb	w0, [x20]
    5b50:	7103fc1f 	cmp	w0, #0xff
    5b54:	540001a0 	b.eq	5b88 <fwp_rc_fresh+0xb4>  // b.none
    5b58:	52800020 	mov	w0, #0x1                   	// #1
    5b5c:	39000280 	strb	w0, [x20]
    5b60:	aa1303e0 	mov	x0, x19
    5b64:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b68:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b6c:	d65f03c0 	ret
    5b70:	72003c3f 	tst	w1, #0xffff
    5b74:	54fffec0 	b.eq	5b4c <fwp_rc_fresh+0x78>  // b.none
    5b78:	aa1303e0 	mov	x0, x19
    5b7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b84:	d65f03c0 	ret
    5b88:	aa1403e0 	mov	x0, x20
    5b8c:	97fff9a1 	bl	4210 <fwp_rc_forget_slot.part.0>
    5b90:	17fffff2 	b	5b58 <fwp_rc_fresh+0x84>

0000000000005b94 <fwp_rc_free_arr>:
    5b94:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5b98:	91174063 	add	x3, x3, #0x5d0
    5b9c:	f949d861 	ldr	x1, [x3, #5040]
    5ba0:	f949ec62 	ldr	x2, [x3, #5080]
    5ba4:	cb010001 	sub	x1, x0, x1
    5ba8:	eb02403f 	cmp	x1, x2, lsl #16
    5bac:	54000342 	b.cs	5c14 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5bb0:	d350fc22 	lsr	x2, x1, #16
    5bb4:	f949fc65 	ldr	x5, [x3, #5112]
    5bb8:	8b020842 	add	x2, x2, x2, lsl #2
    5bbc:	d37df042 	lsl	x2, x2, #3
    5bc0:	8b0200a4 	add	x4, x5, x2
    5bc4:	f9401083 	ldr	x3, [x4, #32]
    5bc8:	b4000263 	cbz	x3, 5c14 <fwp_rc_free_arr+0x80>
    5bcc:	386268a2 	ldrb	w2, [x5, x2]
    5bd0:	7100085f 	cmp	w2, #0x2
    5bd4:	540001c0 	b.eq	5c0c <fwp_rc_free_arr+0x78>  // b.none
    5bd8:	7100045f 	cmp	w2, #0x1
    5bdc:	540001c1 	b.ne	5c14 <fwp_rc_free_arr+0x80>  // b.any
    5be0:	29430885 	ldp	w5, w2, [x4, #24]
    5be4:	92403c21 	and	x1, x1, #0xffff
    5be8:	9b057c21 	mul	x1, x1, x5
    5bec:	d360fc21 	lsr	x1, x1, #32
    5bf0:	eb02003f 	cmp	x1, x2
    5bf4:	54000102 	b.cs	5c14 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5bf8:	8b010063 	add	x3, x3, x1
    5bfc:	39400061 	ldrb	w1, [x3]
    5c00:	7100043f 	cmp	w1, #0x1
    5c04:	54000081 	b.ne	5c14 <fwp_rc_free_arr+0x80>  // b.any
    5c08:	17fffa1e 	b	4480 <fwp_mem_free>
    5c0c:	72003c3f 	tst	w1, #0xffff
    5c10:	54ffff60 	b.eq	5bfc <fwp_rc_free_arr+0x68>  // b.none
    5c14:	d65f03c0 	ret
    5c18:	d503201f 	nop
    5c1c:	d503201f 	nop

0000000000005c20 <fwp_rc_dup>:
    5c20:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5c24:	91174042 	add	x2, x2, #0x5d0
    5c28:	f949d841 	ldr	x1, [x2, #5040]
    5c2c:	f949ec43 	ldr	x3, [x2, #5080]
    5c30:	cb010001 	sub	x1, x0, x1
    5c34:	eb03403f 	cmp	x1, x3, lsl #16
    5c38:	54000342 	b.cs	5ca0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5c3c:	d350fc20 	lsr	x0, x1, #16
    5c40:	f949fc44 	ldr	x4, [x2, #5112]
    5c44:	8b000800 	add	x0, x0, x0, lsl #2
    5c48:	d37df002 	lsl	x2, x0, #3
    5c4c:	8b020083 	add	x3, x4, x2
    5c50:	f9401060 	ldr	x0, [x3, #32]
    5c54:	b4000260 	cbz	x0, 5ca0 <fwp_rc_dup+0x80>
    5c58:	38626882 	ldrb	w2, [x4, x2]
    5c5c:	7100085f 	cmp	w2, #0x2
    5c60:	54000220 	b.eq	5ca4 <fwp_rc_dup+0x84>  // b.none
    5c64:	7100045f 	cmp	w2, #0x1
    5c68:	540001c1 	b.ne	5ca0 <fwp_rc_dup+0x80>  // b.any
    5c6c:	29430864 	ldp	w4, w2, [x3, #24]
    5c70:	92403c21 	and	x1, x1, #0xffff
    5c74:	9b047c21 	mul	x1, x1, x4
    5c78:	d360fc21 	lsr	x1, x1, #32
    5c7c:	eb02003f 	cmp	x1, x2
    5c80:	54000102 	b.cs	5ca0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5c84:	8b010000 	add	x0, x0, x1
    5c88:	39400001 	ldrb	w1, [x0]
    5c8c:	340000a1 	cbz	w1, 5ca0 <fwp_rc_dup+0x80>
    5c90:	7103f43f 	cmp	w1, #0xfd
    5c94:	540000e8 	b.hi	5cb0 <fwp_rc_dup+0x90>  // b.pmore
    5c98:	11000421 	add	w1, w1, #0x1
    5c9c:	39000001 	strb	w1, [x0]
    5ca0:	d65f03c0 	ret
    5ca4:	72003c3f 	tst	w1, #0xffff
    5ca8:	54ffff00 	b.eq	5c88 <fwp_rc_dup+0x68>  // b.none
    5cac:	d65f03c0 	ret
    5cb0:	17fffa6d 	b	4664 <fwp_rc_wide_dup>

0000000000005cb4 <fwp_owned_entry173>:
    5cb4:	d10103ff 	sub	sp, sp, #0x40
    5cb8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5cbc:	f947f442 	ldr	x2, [x2, #4072]
    5cc0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5cc4:	910083fd 	add	x29, sp, #0x20
    5cc8:	a90353f3 	stp	x19, x20, [sp, #48]
    5ccc:	f9400043 	ldr	x3, [x2]
    5cd0:	f9000fe3 	str	x3, [sp, #24]
    5cd4:	d2800003 	mov	x3, #0x0                   	// #0
    5cd8:	a9400c01 	ldp	x1, x3, [x0]
    5cdc:	f9400802 	ldr	x2, [x0, #16]
    5ce0:	ab020022 	adds	x2, x1, x2
    5ce4:	540006e6 	b.vs	5dc0 <fwp_owned_entry173+0x10c>
    5ce8:	910023e1 	add	x1, sp, #0x8
    5cec:	52800000 	mov	w0, #0x0                   	// #0
    5cf0:	a9008be3 	stp	x3, x2, [sp, #8]
    5cf4:	97fffce4 	bl	5084 <fwp_data.part.0.constprop.0>
    5cf8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5cfc:	91174063 	add	x3, x3, #0x5d0
    5d00:	aa0003f3 	mov	x19, x0
    5d04:	f949d861 	ldr	x1, [x3, #5040]
    5d08:	f949ec60 	ldr	x0, [x3, #5080]
    5d0c:	cb010261 	sub	x1, x19, x1
    5d10:	eb00403f 	cmp	x1, x0, lsl #16
    5d14:	54000322 	b.cs	5d78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5d18:	d350fc22 	lsr	x2, x1, #16
    5d1c:	f949fc63 	ldr	x3, [x3, #5112]
    5d20:	8b020842 	add	x2, x2, x2, lsl #2
    5d24:	d37df042 	lsl	x2, x2, #3
    5d28:	8b020060 	add	x0, x3, x2
    5d2c:	f9401014 	ldr	x20, [x0, #32]
    5d30:	b4000254 	cbz	x20, 5d78 <fwp_owned_entry173+0xc4>
    5d34:	38626862 	ldrb	w2, [x3, x2]
    5d38:	7100085f 	cmp	w2, #0x2
    5d3c:	54000360 	b.eq	5da8 <fwp_owned_entry173+0xf4>  // b.none
    5d40:	7100045f 	cmp	w2, #0x1
    5d44:	540001a1 	b.ne	5d78 <fwp_owned_entry173+0xc4>  // b.any
    5d48:	29430002 	ldp	w2, w0, [x0, #24]
    5d4c:	92403c21 	and	x1, x1, #0xffff
    5d50:	9b027c21 	mul	x1, x1, x2
    5d54:	d360fc21 	lsr	x1, x1, #32
    5d58:	eb00003f 	cmp	x1, x0
    5d5c:	540000e2 	b.cs	5d78 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5d60:	8b010294 	add	x20, x20, x1
    5d64:	39400280 	ldrb	w0, [x20]
    5d68:	7103fc1f 	cmp	w0, #0xff
    5d6c:	54000240 	b.eq	5db4 <fwp_owned_entry173+0x100>  // b.none
    5d70:	52800020 	mov	w0, #0x1                   	// #1
    5d74:	39000280 	strb	w0, [x20]
    5d78:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d7c:	f947f400 	ldr	x0, [x0, #4072]
    5d80:	f9400fe2 	ldr	x2, [sp, #24]
    5d84:	f9400001 	ldr	x1, [x0]
    5d88:	eb010042 	subs	x2, x2, x1
    5d8c:	d2800001 	mov	x1, #0x0                   	// #0
    5d90:	540001a1 	b.ne	5dc4 <fwp_owned_entry173+0x110>  // b.any
    5d94:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d98:	aa1303e0 	mov	x0, x19
    5d9c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5da0:	910103ff 	add	sp, sp, #0x40
    5da4:	d65f03c0 	ret
    5da8:	72003c3f 	tst	w1, #0xffff
    5dac:	54fffe61 	b.ne	5d78 <fwp_owned_entry173+0xc4>  // b.any
    5db0:	17ffffed 	b	5d64 <fwp_owned_entry173+0xb0>
    5db4:	aa1403e0 	mov	x0, x20
    5db8:	97fff916 	bl	4210 <fwp_rc_forget_slot.part.0>
    5dbc:	17ffffed 	b	5d70 <fwp_owned_entry173+0xbc>
    5dc0:	97fff350 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5dc4:	97fff2d3 	bl	2910 <__stack_chk_fail@plt>
    5dc8:	d503201f 	nop
    5dcc:	d503201f 	nop

0000000000005dd0 <e173>:
    5dd0:	d10103ff 	sub	sp, sp, #0x40
    5dd4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5dd8:	f947f442 	ldr	x2, [x2, #4072]
    5ddc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5de0:	910083fd 	add	x29, sp, #0x20
    5de4:	a90353f3 	stp	x19, x20, [sp, #48]
    5de8:	f9400043 	ldr	x3, [x2]
    5dec:	f9000fe3 	str	x3, [sp, #24]
    5df0:	d2800003 	mov	x3, #0x0                   	// #0
    5df4:	a9400c01 	ldp	x1, x3, [x0]
    5df8:	f9400802 	ldr	x2, [x0, #16]
    5dfc:	ab020022 	adds	x2, x1, x2
    5e00:	54000726 	b.vs	5ee4 <e173+0x114>
    5e04:	910023e1 	add	x1, sp, #0x8
    5e08:	52800000 	mov	w0, #0x0                   	// #0
    5e0c:	a9008be3 	stp	x3, x2, [sp, #8]
    5e10:	97fffc9d 	bl	5084 <fwp_data.part.0.constprop.0>
    5e14:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5e18:	91174063 	add	x3, x3, #0x5d0
    5e1c:	aa0003f3 	mov	x19, x0
    5e20:	f949d861 	ldr	x1, [x3, #5040]
    5e24:	f949ec60 	ldr	x0, [x3, #5080]
    5e28:	cb010261 	sub	x1, x19, x1
    5e2c:	eb00403f 	cmp	x1, x0, lsl #16
    5e30:	54000322 	b.cs	5e94 <e173+0xc4>  // b.hs, b.nlast
    5e34:	d350fc22 	lsr	x2, x1, #16
    5e38:	f949fc63 	ldr	x3, [x3, #5112]
    5e3c:	8b020842 	add	x2, x2, x2, lsl #2
    5e40:	d37df042 	lsl	x2, x2, #3
    5e44:	8b020060 	add	x0, x3, x2
    5e48:	f9401014 	ldr	x20, [x0, #32]
    5e4c:	b4000254 	cbz	x20, 5e94 <e173+0xc4>
    5e50:	38626862 	ldrb	w2, [x3, x2]
    5e54:	7100085f 	cmp	w2, #0x2
    5e58:	540003a0 	b.eq	5ecc <e173+0xfc>  // b.none
    5e5c:	7100045f 	cmp	w2, #0x1
    5e60:	540001a1 	b.ne	5e94 <e173+0xc4>  // b.any
    5e64:	29430002 	ldp	w2, w0, [x0, #24]
    5e68:	92403c21 	and	x1, x1, #0xffff
    5e6c:	9b027c21 	mul	x1, x1, x2
    5e70:	d360fc21 	lsr	x1, x1, #32
    5e74:	eb00003f 	cmp	x1, x0
    5e78:	540000e2 	b.cs	5e94 <e173+0xc4>  // b.hs, b.nlast
    5e7c:	8b010294 	add	x20, x20, x1
    5e80:	39400280 	ldrb	w0, [x20]
    5e84:	7103fc1f 	cmp	w0, #0xff
    5e88:	54000280 	b.eq	5ed8 <e173+0x108>  // b.none
    5e8c:	52800020 	mov	w0, #0x1                   	// #1
    5e90:	39000280 	strb	w0, [x20]
    5e94:	aa1303e0 	mov	x0, x19
    5e98:	97fffeeb 	bl	5a44 <fwp_rc_share>
    5e9c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ea0:	f947f400 	ldr	x0, [x0, #4072]
    5ea4:	f9400fe2 	ldr	x2, [sp, #24]
    5ea8:	f9400001 	ldr	x1, [x0]
    5eac:	eb010042 	subs	x2, x2, x1
    5eb0:	d2800001 	mov	x1, #0x0                   	// #0
    5eb4:	540001a1 	b.ne	5ee8 <e173+0x118>  // b.any
    5eb8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ebc:	aa1303e0 	mov	x0, x19
    5ec0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ec4:	910103ff 	add	sp, sp, #0x40
    5ec8:	d65f03c0 	ret
    5ecc:	72003c3f 	tst	w1, #0xffff
    5ed0:	54fffe21 	b.ne	5e94 <e173+0xc4>  // b.any
    5ed4:	17ffffeb 	b	5e80 <e173+0xb0>
    5ed8:	aa1403e0 	mov	x0, x20
    5edc:	97fff8cd 	bl	4210 <fwp_rc_forget_slot.part.0>
    5ee0:	17ffffeb 	b	5e8c <e173+0xbc>
    5ee4:	97fff307 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5ee8:	97fff28a 	bl	2910 <__stack_chk_fail@plt>
    5eec:	d503201f 	nop

0000000000005ef0 <fwp_drop1>:
    5ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ef4:	910003fd 	mov	x29, sp
    5ef8:	a90153f3 	stp	x19, x20, [sp, #16]
    5efc:	f90013f5 	str	x21, [sp, #32]
    5f00:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5f04:	911742b4 	add	x20, x21, #0x5d0
    5f08:	f949da81 	ldr	x1, [x20, #5040]
    5f0c:	f949ee82 	ldr	x2, [x20, #5080]
    5f10:	cb010001 	sub	x1, x0, x1
    5f14:	eb02403f 	cmp	x1, x2, lsl #16
    5f18:	54000382 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f1c:	d350fc22 	lsr	x2, x1, #16
    5f20:	f949fe84 	ldr	x4, [x20, #5112]
    5f24:	8b020842 	add	x2, x2, x2, lsl #2
    5f28:	d37df042 	lsl	x2, x2, #3
    5f2c:	8b020083 	add	x3, x4, x2
    5f30:	f9401073 	ldr	x19, [x3, #32]
    5f34:	b40002b3 	cbz	x19, 5f88 <fwp_drop1+0x98>
    5f38:	38626882 	ldrb	w2, [x4, x2]
    5f3c:	7100085f 	cmp	w2, #0x2
    5f40:	540002c0 	b.eq	5f98 <fwp_drop1+0xa8>  // b.none
    5f44:	7100045f 	cmp	w2, #0x1
    5f48:	54000201 	b.ne	5f88 <fwp_drop1+0x98>  // b.any
    5f4c:	29430864 	ldp	w4, w2, [x3, #24]
    5f50:	92403c21 	and	x1, x1, #0xffff
    5f54:	9b047c21 	mul	x1, x1, x4
    5f58:	d360fc21 	lsr	x1, x1, #32
    5f5c:	eb02003f 	cmp	x1, x2
    5f60:	54000142 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f64:	8b010273 	add	x19, x19, x1
    5f68:	39400261 	ldrb	w1, [x19]
    5f6c:	340000e1 	cbz	w1, 5f88 <fwp_drop1+0x98>
    5f70:	7100043f 	cmp	w1, #0x1
    5f74:	540001e0 	b.eq	5fb0 <fwp_drop1+0xc0>  // b.none
    5f78:	7103fc3f 	cmp	w1, #0xff
    5f7c:	540002e0 	b.eq	5fd8 <fwp_drop1+0xe8>  // b.none
    5f80:	51000421 	sub	w1, w1, #0x1
    5f84:	39000261 	strb	w1, [x19]
    5f88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f8c:	f94013f5 	ldr	x21, [sp, #32]
    5f90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f94:	d65f03c0 	ret
    5f98:	72003c3f 	tst	w1, #0xffff
    5f9c:	54fffe60 	b.eq	5f68 <fwp_drop1+0x78>  // b.none
    5fa0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fa4:	f94013f5 	ldr	x21, [sp, #32]
    5fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fac:	d65f03c0 	ret
    5fb0:	f9400813 	ldr	x19, [x0, #16]
    5fb4:	97fffef8 	bl	5b94 <fwp_rc_free_arr>
    5fb8:	911742a0 	add	x0, x21, #0x5d0
    5fbc:	f949d801 	ldr	x1, [x0, #5040]
    5fc0:	f949ec00 	ldr	x0, [x0, #5080]
    5fc4:	cb010261 	sub	x1, x19, x1
    5fc8:	eb00403f 	cmp	x1, x0, lsl #16
    5fcc:	54fffde2 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fd0:	aa1303e0 	mov	x0, x19
    5fd4:	17ffffd2 	b	5f1c <fwp_drop1+0x2c>
    5fd8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fdc:	911742b5 	add	x21, x21, #0x5d0
    5fe0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fe4:	92401c00 	and	x0, x0, #0xff
    5fe8:	910a2402 	add	x2, x0, #0x289
    5fec:	8b000ea0 	add	x0, x21, x0, lsl #3
    5ff0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5ff4:	f94a2400 	ldr	x0, [x0, #5192]
    5ff8:	b50000a0 	cbnz	x0, 600c <fwp_drop1+0x11c>
    5ffc:	14000013 	b	6048 <fwp_drop1+0x158>
    6000:	91004002 	add	x2, x0, #0x10
    6004:	f9400800 	ldr	x0, [x0, #16]
    6008:	b4000200 	cbz	x0, 6048 <fwp_drop1+0x158>
    600c:	f9400001 	ldr	x1, [x0]
    6010:	eb13003f 	cmp	x1, x19
    6014:	54ffff61 	b.ne	6000 <fwp_drop1+0x110>  // b.any
    6018:	f9400041 	ldr	x1, [x2]
    601c:	f9400420 	ldr	x0, [x1, #8]
    6020:	d1000400 	sub	x0, x0, #0x1
    6024:	f9000420 	str	x0, [x1, #8]
    6028:	f103f81f 	cmp	x0, #0xfe
    602c:	54fffae1 	b.ne	5f88 <fwp_drop1+0x98>  // b.any
    6030:	39400260 	ldrb	w0, [x19]
    6034:	7103fc1f 	cmp	w0, #0xff
    6038:	540000e0 	b.eq	6054 <fwp_drop1+0x164>  // b.none
    603c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6040:	39000260 	strb	w0, [x19]
    6044:	17ffffd1 	b	5f88 <fwp_drop1+0x98>
    6048:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    604c:	911b6000 	add	x0, x0, #0x6d8
    6050:	97fff850 	bl	4190 <fwp_trap>
    6054:	aa1303e0 	mov	x0, x19
    6058:	97fff86e 	bl	4210 <fwp_rc_forget_slot.part.0>
    605c:	17fffff8 	b	603c <fwp_drop1+0x14c>

0000000000006060 <fwp_drop0>:
    6060:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6064:	910003fd 	mov	x29, sp
    6068:	a90153f3 	stp	x19, x20, [sp, #16]
    606c:	f90013f5 	str	x21, [sp, #32]
    6070:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    6074:	911742b4 	add	x20, x21, #0x5d0
    6078:	f949da81 	ldr	x1, [x20, #5040]
    607c:	f949ee82 	ldr	x2, [x20, #5080]
    6080:	cb010001 	sub	x1, x0, x1
    6084:	eb02403f 	cmp	x1, x2, lsl #16
    6088:	54000382 	b.cs	60f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    608c:	d350fc22 	lsr	x2, x1, #16
    6090:	f949fe84 	ldr	x4, [x20, #5112]
    6094:	8b020842 	add	x2, x2, x2, lsl #2
    6098:	d37df042 	lsl	x2, x2, #3
    609c:	8b020083 	add	x3, x4, x2
    60a0:	f9401073 	ldr	x19, [x3, #32]
    60a4:	b40002b3 	cbz	x19, 60f8 <fwp_drop0+0x98>
    60a8:	38626882 	ldrb	w2, [x4, x2]
    60ac:	7100085f 	cmp	w2, #0x2
    60b0:	540002c0 	b.eq	6108 <fwp_drop0+0xa8>  // b.none
    60b4:	7100045f 	cmp	w2, #0x1
    60b8:	54000201 	b.ne	60f8 <fwp_drop0+0x98>  // b.any
    60bc:	29430864 	ldp	w4, w2, [x3, #24]
    60c0:	92403c21 	and	x1, x1, #0xffff
    60c4:	9b047c21 	mul	x1, x1, x4
    60c8:	d360fc21 	lsr	x1, x1, #32
    60cc:	eb02003f 	cmp	x1, x2
    60d0:	54000142 	b.cs	60f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    60d4:	8b010273 	add	x19, x19, x1
    60d8:	39400261 	ldrb	w1, [x19]
    60dc:	340000e1 	cbz	w1, 60f8 <fwp_drop0+0x98>
    60e0:	7100043f 	cmp	w1, #0x1
    60e4:	540001e0 	b.eq	6120 <fwp_drop0+0xc0>  // b.none
    60e8:	7103fc3f 	cmp	w1, #0xff
    60ec:	540002e0 	b.eq	6148 <fwp_drop0+0xe8>  // b.none
    60f0:	51000421 	sub	w1, w1, #0x1
    60f4:	39000261 	strb	w1, [x19]
    60f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    60fc:	f94013f5 	ldr	x21, [sp, #32]
    6100:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6104:	d65f03c0 	ret
    6108:	72003c3f 	tst	w1, #0xffff
    610c:	54fffe60 	b.eq	60d8 <fwp_drop0+0x78>  // b.none
    6110:	a94153f3 	ldp	x19, x20, [sp, #16]
    6114:	f94013f5 	ldr	x21, [sp, #32]
    6118:	a8c37bfd 	ldp	x29, x30, [sp], #48
    611c:	d65f03c0 	ret
    6120:	f9400813 	ldr	x19, [x0, #16]
    6124:	97fffe9c 	bl	5b94 <fwp_rc_free_arr>
    6128:	911742a0 	add	x0, x21, #0x5d0
    612c:	f949d801 	ldr	x1, [x0, #5040]
    6130:	f949ec00 	ldr	x0, [x0, #5080]
    6134:	cb010261 	sub	x1, x19, x1
    6138:	eb00403f 	cmp	x1, x0, lsl #16
    613c:	54fffde2 	b.cs	60f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6140:	aa1303e0 	mov	x0, x19
    6144:	17ffffd2 	b	608c <fwp_drop0+0x2c>
    6148:	ca534660 	eor	x0, x19, x19, lsr #17
    614c:	911742b5 	add	x21, x21, #0x5d0
    6150:	ca402400 	eor	x0, x0, x0, lsr #9
    6154:	92401c00 	and	x0, x0, #0xff
    6158:	910a2402 	add	x2, x0, #0x289
    615c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6160:	8b020ea2 	add	x2, x21, x2, lsl #3
    6164:	f94a2400 	ldr	x0, [x0, #5192]
    6168:	b50000a0 	cbnz	x0, 617c <fwp_drop0+0x11c>
    616c:	14000013 	b	61b8 <fwp_drop0+0x158>
    6170:	91004002 	add	x2, x0, #0x10
    6174:	f9400800 	ldr	x0, [x0, #16]
    6178:	b4000200 	cbz	x0, 61b8 <fwp_drop0+0x158>
    617c:	f9400001 	ldr	x1, [x0]
    6180:	eb13003f 	cmp	x1, x19
    6184:	54ffff61 	b.ne	6170 <fwp_drop0+0x110>  // b.any
    6188:	f9400041 	ldr	x1, [x2]
    618c:	f9400420 	ldr	x0, [x1, #8]
    6190:	d1000400 	sub	x0, x0, #0x1
    6194:	f9000420 	str	x0, [x1, #8]
    6198:	f103f81f 	cmp	x0, #0xfe
    619c:	54fffae1 	b.ne	60f8 <fwp_drop0+0x98>  // b.any
    61a0:	39400260 	ldrb	w0, [x19]
    61a4:	7103fc1f 	cmp	w0, #0xff
    61a8:	540000e0 	b.eq	61c4 <fwp_drop0+0x164>  // b.none
    61ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61b0:	39000260 	strb	w0, [x19]
    61b4:	17ffffd1 	b	60f8 <fwp_drop0+0x98>
    61b8:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    61bc:	911b6000 	add	x0, x0, #0x6d8
    61c0:	97fff7f4 	bl	4190 <fwp_trap>
    61c4:	aa1303e0 	mov	x0, x19
    61c8:	97fff812 	bl	4210 <fwp_rc_forget_slot.part.0>
    61cc:	17fffff8 	b	61ac <fwp_drop0+0x14c>

00000000000061d0 <fwp_closure_drop>:
    61d0:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    61d4:	911740a4 	add	x4, x5, #0x5d0
    61d8:	aa0003e1 	mov	x1, x0
    61dc:	f949d882 	ldr	x2, [x4, #5040]
    61e0:	f949ec80 	ldr	x0, [x4, #5080]
    61e4:	cb020022 	sub	x2, x1, x2
    61e8:	eb00405f 	cmp	x2, x0, lsl #16
    61ec:	54000662 	b.cs	62b8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    61f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61f4:	d350fc43 	lsr	x3, x2, #16
    61f8:	910003fd 	mov	x29, sp
    61fc:	8b030863 	add	x3, x3, x3, lsl #2
    6200:	f949fc84 	ldr	x4, [x4, #5112]
    6204:	d37df063 	lsl	x3, x3, #3
    6208:	f9000bf3 	str	x19, [sp, #16]
    620c:	8b030080 	add	x0, x4, x3
    6210:	f9401013 	ldr	x19, [x0, #32]
    6214:	b40002b3 	cbz	x19, 6268 <fwp_closure_drop+0x98>
    6218:	38636883 	ldrb	w3, [x4, x3]
    621c:	7100087f 	cmp	w3, #0x2
    6220:	54000420 	b.eq	62a4 <fwp_closure_drop+0xd4>  // b.none
    6224:	7100047f 	cmp	w3, #0x1
    6228:	54000201 	b.ne	6268 <fwp_closure_drop+0x98>  // b.any
    622c:	29430003 	ldp	w3, w0, [x0, #24]
    6230:	92403c42 	and	x2, x2, #0xffff
    6234:	9b037c42 	mul	x2, x2, x3
    6238:	d360fc42 	lsr	x2, x2, #32
    623c:	eb00005f 	cmp	x2, x0
    6240:	54000142 	b.cs	6268 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6244:	8b020273 	add	x19, x19, x2
    6248:	39400260 	ldrb	w0, [x19]
    624c:	340000e0 	cbz	w0, 6268 <fwp_closure_drop+0x98>
    6250:	7100041f 	cmp	w0, #0x1
    6254:	54000100 	b.eq	6274 <fwp_closure_drop+0xa4>  // b.none
    6258:	7103fc1f 	cmp	w0, #0xff
    625c:	54000300 	b.eq	62bc <fwp_closure_drop+0xec>  // b.none
    6260:	51000400 	sub	w0, w0, #0x1
    6264:	39000260 	strb	w0, [x19]
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	d65f03c0 	ret
    6274:	d53bd040 	mrs	x0, tpidr_el0
    6278:	91400000 	add	x0, x0, #0x0, lsl #12
    627c:	91004000 	add	x0, x0, #0x10
    6280:	f9400000 	ldr	x0, [x0]
    6284:	b4000080 	cbz	x0, 6294 <fwp_closure_drop+0xc4>
    6288:	f9400bf3 	ldr	x19, [sp, #16]
    628c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6290:	17fff93c 	b	4780 <fwp_closure_drop_push>
    6294:	f9400bf3 	ldr	x19, [sp, #16]
    6298:	aa0103e0 	mov	x0, x1
    629c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62a0:	17fff97d 	b	4894 <fwp_closure_drop.part.0>
    62a4:	72003c5f 	tst	w2, #0xffff
    62a8:	54fffd00 	b.eq	6248 <fwp_closure_drop+0x78>  // b.none
    62ac:	f9400bf3 	ldr	x19, [sp, #16]
    62b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62b4:	d65f03c0 	ret
    62b8:	d65f03c0 	ret
    62bc:	ca534660 	eor	x0, x19, x19, lsr #17
    62c0:	911740a5 	add	x5, x5, #0x5d0
    62c4:	ca402400 	eor	x0, x0, x0, lsr #9
    62c8:	92401c00 	and	x0, x0, #0xff
    62cc:	910a2402 	add	x2, x0, #0x289
    62d0:	8b000ca0 	add	x0, x5, x0, lsl #3
    62d4:	8b020ca2 	add	x2, x5, x2, lsl #3
    62d8:	f94a2400 	ldr	x0, [x0, #5192]
    62dc:	b50000a0 	cbnz	x0, 62f0 <fwp_closure_drop+0x120>
    62e0:	14000013 	b	632c <fwp_closure_drop+0x15c>
    62e4:	91004002 	add	x2, x0, #0x10
    62e8:	f9400800 	ldr	x0, [x0, #16]
    62ec:	b4000200 	cbz	x0, 632c <fwp_closure_drop+0x15c>
    62f0:	f9400001 	ldr	x1, [x0]
    62f4:	eb13003f 	cmp	x1, x19
    62f8:	54ffff61 	b.ne	62e4 <fwp_closure_drop+0x114>  // b.any
    62fc:	f9400041 	ldr	x1, [x2]
    6300:	f9400420 	ldr	x0, [x1, #8]
    6304:	d1000400 	sub	x0, x0, #0x1
    6308:	f9000420 	str	x0, [x1, #8]
    630c:	f103f81f 	cmp	x0, #0xfe
    6310:	54fffac1 	b.ne	6268 <fwp_closure_drop+0x98>  // b.any
    6314:	39400260 	ldrb	w0, [x19]
    6318:	7103fc1f 	cmp	w0, #0xff
    631c:	540000e0 	b.eq	6338 <fwp_closure_drop+0x168>  // b.none
    6320:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6324:	39000260 	strb	w0, [x19]
    6328:	17ffffd0 	b	6268 <fwp_closure_drop+0x98>
    632c:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    6330:	911b6000 	add	x0, x0, #0x6d8
    6334:	97fff797 	bl	4190 <fwp_trap>
    6338:	aa1303e0 	mov	x0, x19
    633c:	97fff7b5 	bl	4210 <fwp_rc_forget_slot.part.0>
    6340:	17fffff8 	b	6320 <fwp_closure_drop+0x150>

0000000000006344 <fwp_owned_tape_release>:
    6344:	b4000920 	cbz	x0, 6468 <fwp_owned_tape_release+0x124>
    6348:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    634c:	910003fd 	mov	x29, sp
    6350:	a90153f3 	stp	x19, x20, [sp, #16]
    6354:	aa0003f3 	mov	x19, x0
    6358:	f9400000 	ldr	x0, [x0]
    635c:	b4000060 	cbz	x0, 6368 <fwp_owned_tape_release+0x24>
    6360:	f9400661 	ldr	x1, [x19, #8]
    6364:	f9000401 	str	x1, [x0, #8]
    6368:	f9400661 	ldr	x1, [x19, #8]
    636c:	b4000041 	cbz	x1, 6374 <fwp_owned_tape_release+0x30>
    6370:	f9000020 	str	x0, [x1]
    6374:	f9400a60 	ldr	x0, [x19, #16]
    6378:	f9403401 	ldr	x1, [x0, #104]
    637c:	b40005a1 	cbz	x1, 6430 <fwp_owned_tape_release+0xec>
    6380:	a9450a60 	ldp	x0, x2, [x19, #80]
    6384:	eb00005f 	cmp	x2, x0
    6388:	540002cd 	b.le	63e0 <fwp_owned_tape_release+0x9c>
    638c:	d2800014 	mov	x20, #0x0                   	// #0
    6390:	f90013f5 	str	x21, [sp, #32]
    6394:	d2800015 	mov	x21, #0x0                   	// #0
    6398:	f9402260 	ldr	x0, [x19, #64]
    639c:	910006b5 	add	x21, x21, #0x1
    63a0:	f8746800 	ldr	x0, [x0, x20]
    63a4:	d63f0020 	blr	x1
    63a8:	f9402260 	ldr	x0, [x19, #64]
    63ac:	f9400a61 	ldr	x1, [x19, #16]
    63b0:	8b140000 	add	x0, x0, x20
    63b4:	91004294 	add	x20, x20, #0x10
    63b8:	f9400400 	ldr	x0, [x0, #8]
    63bc:	f9403421 	ldr	x1, [x1, #104]
    63c0:	d63f0020 	blr	x1
    63c4:	a9450261 	ldp	x1, x0, [x19, #80]
    63c8:	cb010000 	sub	x0, x0, x1
    63cc:	eb15001f 	cmp	x0, x21
    63d0:	f9400a60 	ldr	x0, [x19, #16]
    63d4:	f9403401 	ldr	x1, [x0, #104]
    63d8:	54fffe0c 	b.gt	6398 <fwp_owned_tape_release+0x54>
    63dc:	f94013f5 	ldr	x21, [sp, #32]
    63e0:	f9403663 	ldr	x3, [x19, #104]
    63e4:	f9401262 	ldr	x2, [x19, #32]
    63e8:	f100007f 	cmp	x3, #0x0
    63ec:	540001ed 	b.le	6428 <fwp_owned_tape_release+0xe4>
    63f0:	d2800014 	mov	x20, #0x0                   	// #0
    63f4:	d503201f 	nop
    63f8:	f9402660 	ldr	x0, [x19, #72]
    63fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6400:	eb02001f 	cmp	x0, x2
    6404:	540000c0 	b.eq	641c <fwp_owned_tape_release+0xd8>  // b.none
    6408:	d63f0020 	blr	x1
    640c:	f9400a60 	ldr	x0, [x19, #16]
    6410:	f9401262 	ldr	x2, [x19, #32]
    6414:	f9403663 	ldr	x3, [x19, #104]
    6418:	f9403401 	ldr	x1, [x0, #104]
    641c:	91000694 	add	x20, x20, #0x1
    6420:	eb14007f 	cmp	x3, x20
    6424:	54fffeac 	b.gt	63f8 <fwp_owned_tape_release+0xb4>
    6428:	aa0203e0 	mov	x0, x2
    642c:	d63f0020 	blr	x1
    6430:	f9401660 	ldr	x0, [x19, #40]
    6434:	97ffff67 	bl	61d0 <fwp_closure_drop>
    6438:	f9401a60 	ldr	x0, [x19, #48]
    643c:	97ffff65 	bl	61d0 <fwp_closure_drop>
    6440:	f9401e60 	ldr	x0, [x19, #56]
    6444:	97ffff63 	bl	61d0 <fwp_closure_drop>
    6448:	f9402260 	ldr	x0, [x19, #64]
    644c:	97fff80d 	bl	4480 <fwp_mem_free>
    6450:	f9402660 	ldr	x0, [x19, #72]
    6454:	97fff80b 	bl	4480 <fwp_mem_free>
    6458:	aa1303e0 	mov	x0, x19
    645c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6464:	17fff807 	b	4480 <fwp_mem_free>
    6468:	d65f03c0 	ret
    646c:	d503201f 	nop

0000000000006470 <fwp_tape_finish>:
    6470:	d10203ff 	sub	sp, sp, #0x80
    6474:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6478:	f947f421 	ldr	x1, [x1, #4072]
    647c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6480:	910103fd 	add	x29, sp, #0x40
    6484:	a90553f3 	stp	x19, x20, [sp, #80]
    6488:	a9065bf5 	stp	x21, x22, [sp, #96]
    648c:	a90763f7 	stp	x23, x24, [sp, #112]
    6490:	d00000d8 	adrp	x24, 20000 <__data_start>
    6494:	9101c316 	add	x22, x24, #0x70
    6498:	f9400022 	ldr	x2, [x1]
    649c:	f9001fe2 	str	x2, [sp, #56]
    64a0:	d2800002 	mov	x2, #0x0                   	// #0
    64a4:	910222c0 	add	x0, x22, #0x88
    64a8:	97fff416 	bl	3500 <fwp_tape_buffers_dispose>
    64ac:	f90062df 	str	xzr, [x22, #192]
    64b0:	f9406ac0 	ldr	x0, [x22, #208]
    64b4:	f100001f 	cmp	x0, #0x0
    64b8:	5400030d 	b.le	6518 <fwp_tape_finish+0xa8>
    64bc:	910003f7 	mov	x23, sp
    64c0:	d2800015 	mov	x21, #0x0                   	// #0
    64c4:	d2800014 	mov	x20, #0x0                   	// #0
    64c8:	f94002d3 	ldr	x19, [x22]
    64cc:	91000694 	add	x20, x20, #0x1
    64d0:	8b150273 	add	x19, x19, x21
    64d4:	9101a2b5 	add	x21, x21, #0x68
    64d8:	aa1303e0 	mov	x0, x19
    64dc:	97fff2cd 	bl	3010 <fwp_tape_unlink_scope>
    64e0:	aa1703e0 	mov	x0, x23
    64e4:	f9401261 	ldr	x1, [x19, #32]
    64e8:	f90003e1 	str	x1, [sp]
    64ec:	f9401a62 	ldr	x2, [x19, #48]
    64f0:	f9000be2 	str	x2, [sp, #16]
    64f4:	f9402261 	ldr	x1, [x19, #64]
    64f8:	f90013e1 	str	x1, [sp, #32]
    64fc:	97fff401 	bl	3500 <fwp_tape_buffers_dispose>
    6500:	f9403260 	ldr	x0, [x19, #96]
    6504:	97ffff90 	bl	6344 <fwp_owned_tape_release>
    6508:	f900327f 	str	xzr, [x19, #96]
    650c:	f9406ac0 	ldr	x0, [x22, #208]
    6510:	eb14001f 	cmp	x0, x20
    6514:	54fffdac 	b.gt	64c8 <fwp_tape_finish+0x58>
    6518:	f9403b00 	ldr	x0, [x24, #112]
    651c:	9101c313 	add	x19, x24, #0x70
    6520:	97fff12c 	bl	29d0 <free@plt>
    6524:	f9003b1f 	str	xzr, [x24, #112]
    6528:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    652c:	f947f400 	ldr	x0, [x0, #4072]
    6530:	f9006a7f 	str	xzr, [x19, #208]
    6534:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6538:	f9401fe2 	ldr	x2, [sp, #56]
    653c:	f9400001 	ldr	x1, [x0]
    6540:	eb010042 	subs	x2, x2, x1
    6544:	d2800001 	mov	x1, #0x0                   	// #0
    6548:	540000e1 	b.ne	6564 <fwp_tape_finish+0xf4>  // b.any
    654c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6550:	a94553f3 	ldp	x19, x20, [sp, #80]
    6554:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6558:	a94763f7 	ldp	x23, x24, [sp, #112]
    655c:	910203ff 	add	sp, sp, #0x80
    6560:	d65f03c0 	ret
    6564:	97fff0eb 	bl	2910 <__stack_chk_fail@plt>
    6568:	d503201f 	nop
    656c:	d503201f 	nop

0000000000006570 <fwp_tape_scope_release>:
    6570:	d10243ff 	sub	sp, sp, #0x90
    6574:	a9047bfd 	stp	x29, x30, [sp, #64]
    6578:	910103fd 	add	x29, sp, #0x40
    657c:	a90553f3 	stp	x19, x20, [sp, #80]
    6580:	aa0003f4 	mov	x20, x0
    6584:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6588:	f947f400 	ldr	x0, [x0, #4072]
    658c:	b9400285 	ldr	w5, [x20]
    6590:	f9400001 	ldr	x1, [x0]
    6594:	f9001fe1 	str	x1, [sp, #56]
    6598:	d2800001 	mov	x1, #0x0                   	// #0
    659c:	37f806c5 	tbnz	w5, #31, 6674 <fwp_tape_scope_release+0x104>
    65a0:	a90763f7 	stp	x23, x24, [sp, #112]
    65a4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    65a8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    65ac:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    65b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    65b4:	910003f7 	mov	x23, sp
    65b8:	9101c273 	add	x19, x19, #0x70
    65bc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    65c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65c4:	52800d16 	mov	w22, #0x68                  	// #104
    65c8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    65cc:	f90043f9 	str	x25, [sp, #128]
    65d0:	14000006 	b	65e8 <fwp_tape_scope_release+0x78>
    65d4:	97fff3cb 	bl	3500 <fwp_tape_buffers_dispose>
    65d8:	aa1903e0 	mov	x0, x25
    65dc:	97ffff5a 	bl	6344 <fwp_owned_tape_release>
    65e0:	b9400285 	ldr	w5, [x20]
    65e4:	37f80425 	tbnz	w5, #31, 6668 <fwp_tape_scope_release+0xf8>
    65e8:	f9400266 	ldr	x6, [x19]
    65ec:	9b367ca5 	smull	x5, w5, w22
    65f0:	8b0500c0 	add	x0, x6, x5
    65f4:	97fff287 	bl	3010 <fwp_tape_unlink_scope>
    65f8:	ad410001 	ldp	q1, q0, [x0, #32]
    65fc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6600:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6604:	f9400c03 	ldr	x3, [x0, #24]
    6608:	ad0003e1 	stp	q1, q0, [sp]
    660c:	b86568c1 	ldr	w1, [x6, x5]
    6610:	a9440804 	ldp	x4, x2, [x0, #64]
    6614:	b900041f 	str	wzr, [x0, #4]
    6618:	f9403019 	ldr	x25, [x0, #96]
    661c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6620:	f9000c1f 	str	xzr, [x0, #24]
    6624:	a9020fe4 	stp	x4, x3, [sp, #32]
    6628:	f9001be2 	str	x2, [sp, #48]
    662c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6630:	f900301f 	str	xzr, [x0, #96]
    6634:	6b15003f 	cmp	w1, w21
    6638:	540000e8 	b.hi	6654 <fwp_tape_scope_release+0xe4>  // b.pmore
    663c:	9343fca5 	asr	x5, x5, #3
    6640:	f9407660 	ldr	x0, [x19, #232]
    6644:	9b187ca5 	mul	x5, x5, x24
    6648:	eb0000bf 	cmp	x5, x0
    664c:	5400004a 	b.ge	6654 <fwp_tape_scope_release+0xe4>  // b.tcont
    6650:	f9007665 	str	x5, [x19, #232]
    6654:	aa1703e0 	mov	x0, x23
    6658:	b5fffbf9 	cbnz	x25, 65d4 <fwp_tape_scope_release+0x64>
    665c:	97fff685 	bl	4070 <fwp_tape_buffers_release>
    6660:	b9400285 	ldr	w5, [x20]
    6664:	36fffc25 	tbz	w5, #31, 65e8 <fwp_tape_scope_release+0x78>
    6668:	a9465bf5 	ldp	x21, x22, [sp, #96]
    666c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6670:	f94043f9 	ldr	x25, [sp, #128]
    6674:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6678:	f947f400 	ldr	x0, [x0, #4072]
    667c:	f9401fe2 	ldr	x2, [sp, #56]
    6680:	f9400001 	ldr	x1, [x0]
    6684:	eb010042 	subs	x2, x2, x1
    6688:	d2800001 	mov	x1, #0x0                   	// #0
    668c:	540000a1 	b.ne	66a0 <fwp_tape_scope_release+0x130>  // b.any
    6690:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6694:	a94553f3 	ldp	x19, x20, [sp, #80]
    6698:	910243ff 	add	sp, sp, #0x90
    669c:	d65f03c0 	ret
    66a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66a4:	a90763f7 	stp	x23, x24, [sp, #112]
    66a8:	f90043f9 	str	x25, [sp, #128]
    66ac:	97fff099 	bl	2910 <__stack_chk_fail@plt>

00000000000066b0 <fwp_drop4>:
    66b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66b4:	910003fd 	mov	x29, sp
    66b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    66bc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    66c0:	911742d5 	add	x21, x22, #0x5d0
    66c4:	a90153f3 	stp	x19, x20, [sp, #16]
    66c8:	aa0003f3 	mov	x19, x0
    66cc:	f949daa1 	ldr	x1, [x21, #5040]
    66d0:	f949eea0 	ldr	x0, [x21, #5080]
    66d4:	cb010261 	sub	x1, x19, x1
    66d8:	eb00403f 	cmp	x1, x0, lsl #16
    66dc:	54000382 	b.cs	674c <fwp_drop4+0x9c>  // b.hs, b.nlast
    66e0:	d350fc22 	lsr	x2, x1, #16
    66e4:	f949fea3 	ldr	x3, [x21, #5112]
    66e8:	8b020842 	add	x2, x2, x2, lsl #2
    66ec:	d37df042 	lsl	x2, x2, #3
    66f0:	8b020060 	add	x0, x3, x2
    66f4:	f9401014 	ldr	x20, [x0, #32]
    66f8:	b40002b4 	cbz	x20, 674c <fwp_drop4+0x9c>
    66fc:	38626862 	ldrb	w2, [x3, x2]
    6700:	7100085f 	cmp	w2, #0x2
    6704:	540002c0 	b.eq	675c <fwp_drop4+0xac>  // b.none
    6708:	7100045f 	cmp	w2, #0x1
    670c:	54000201 	b.ne	674c <fwp_drop4+0x9c>  // b.any
    6710:	29430002 	ldp	w2, w0, [x0, #24]
    6714:	92403c21 	and	x1, x1, #0xffff
    6718:	9b027c21 	mul	x1, x1, x2
    671c:	d360fc21 	lsr	x1, x1, #32
    6720:	eb00003f 	cmp	x1, x0
    6724:	54000142 	b.cs	674c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6728:	8b010294 	add	x20, x20, x1
    672c:	39400280 	ldrb	w0, [x20]
    6730:	340000e0 	cbz	w0, 674c <fwp_drop4+0x9c>
    6734:	7100041f 	cmp	w0, #0x1
    6738:	540001e0 	b.eq	6774 <fwp_drop4+0xc4>  // b.none
    673c:	7103fc1f 	cmp	w0, #0xff
    6740:	540007c0 	b.eq	6838 <fwp_drop4+0x188>  // b.none
    6744:	51000400 	sub	w0, w0, #0x1
    6748:	39000280 	strb	w0, [x20]
    674c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6750:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6754:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6758:	d65f03c0 	ret
    675c:	72003c3f 	tst	w1, #0xffff
    6760:	54fffe60 	b.eq	672c <fwp_drop4+0x7c>  // b.none
    6764:	a94153f3 	ldp	x19, x20, [sp, #16]
    6768:	a9425bf5 	ldp	x21, x22, [sp, #32]
    676c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6770:	d65f03c0 	ret
    6774:	911742c2 	add	x2, x22, #0x5d0
    6778:	f9400660 	ldr	x0, [x19, #8]
    677c:	f949d841 	ldr	x1, [x2, #5040]
    6780:	f949ec42 	ldr	x2, [x2, #5080]
    6784:	cb010001 	sub	x1, x0, x1
    6788:	eb02403f 	cmp	x1, x2, lsl #16
    678c:	54000362 	b.cs	67f8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6790:	d350fc22 	lsr	x2, x1, #16
    6794:	8b020842 	add	x2, x2, x2, lsl #2
    6798:	d37df042 	lsl	x2, x2, #3
    679c:	8b020064 	add	x4, x3, x2
    67a0:	f9401094 	ldr	x20, [x4, #32]
    67a4:	b40002b4 	cbz	x20, 67f8 <fwp_drop4+0x148>
    67a8:	38626862 	ldrb	w2, [x3, x2]
    67ac:	7100085f 	cmp	w2, #0x2
    67b0:	540003e0 	b.eq	682c <fwp_drop4+0x17c>  // b.none
    67b4:	7100045f 	cmp	w2, #0x1
    67b8:	54000201 	b.ne	67f8 <fwp_drop4+0x148>  // b.any
    67bc:	29430883 	ldp	w3, w2, [x4, #24]
    67c0:	92403c21 	and	x1, x1, #0xffff
    67c4:	9b037c21 	mul	x1, x1, x3
    67c8:	d360fc21 	lsr	x1, x1, #32
    67cc:	eb02003f 	cmp	x1, x2
    67d0:	54000142 	b.cs	67f8 <fwp_drop4+0x148>  // b.hs, b.nlast
    67d4:	8b010294 	add	x20, x20, x1
    67d8:	39400281 	ldrb	w1, [x20]
    67dc:	340000e1 	cbz	w1, 67f8 <fwp_drop4+0x148>
    67e0:	7100043f 	cmp	w1, #0x1
    67e4:	54000200 	b.eq	6824 <fwp_drop4+0x174>  // b.none
    67e8:	7103fc3f 	cmp	w1, #0xff
    67ec:	54000640 	b.eq	68b4 <fwp_drop4+0x204>  // b.none
    67f0:	51000421 	sub	w1, w1, #0x1
    67f4:	39000281 	strb	w1, [x20]
    67f8:	f9400a74 	ldr	x20, [x19, #16]
    67fc:	aa1303e0 	mov	x0, x19
    6800:	97fffce5 	bl	5b94 <fwp_rc_free_arr>
    6804:	911742c0 	add	x0, x22, #0x5d0
    6808:	f949d801 	ldr	x1, [x0, #5040]
    680c:	f949ec00 	ldr	x0, [x0, #5080]
    6810:	cb010281 	sub	x1, x20, x1
    6814:	eb00403f 	cmp	x1, x0, lsl #16
    6818:	54fff9a2 	b.cs	674c <fwp_drop4+0x9c>  // b.hs, b.nlast
    681c:	aa1403f3 	mov	x19, x20
    6820:	17ffffb0 	b	66e0 <fwp_drop4+0x30>
    6824:	97fffcdc 	bl	5b94 <fwp_rc_free_arr>
    6828:	17fffff4 	b	67f8 <fwp_drop4+0x148>
    682c:	72003c3f 	tst	w1, #0xffff
    6830:	54fffe41 	b.ne	67f8 <fwp_drop4+0x148>  // b.any
    6834:	17ffffe9 	b	67d8 <fwp_drop4+0x128>
    6838:	ca544681 	eor	x1, x20, x20, lsr #17
    683c:	911742c0 	add	x0, x22, #0x5d0
    6840:	ca412421 	eor	x1, x1, x1, lsr #9
    6844:	92401c21 	and	x1, x1, #0xff
    6848:	910a2422 	add	x2, x1, #0x289
    684c:	8b010c01 	add	x1, x0, x1, lsl #3
    6850:	8b020c02 	add	x2, x0, x2, lsl #3
    6854:	f94a2420 	ldr	x0, [x1, #5192]
    6858:	b50000a0 	cbnz	x0, 686c <fwp_drop4+0x1bc>
    685c:	14000013 	b	68a8 <fwp_drop4+0x1f8>
    6860:	91004002 	add	x2, x0, #0x10
    6864:	f9400800 	ldr	x0, [x0, #16]
    6868:	b4000200 	cbz	x0, 68a8 <fwp_drop4+0x1f8>
    686c:	f9400001 	ldr	x1, [x0]
    6870:	eb14003f 	cmp	x1, x20
    6874:	54ffff61 	b.ne	6860 <fwp_drop4+0x1b0>  // b.any
    6878:	f9400041 	ldr	x1, [x2]
    687c:	f9400420 	ldr	x0, [x1, #8]
    6880:	d1000400 	sub	x0, x0, #0x1
    6884:	f9000420 	str	x0, [x1, #8]
    6888:	f103f81f 	cmp	x0, #0xfe
    688c:	54fff601 	b.ne	674c <fwp_drop4+0x9c>  // b.any
    6890:	39400280 	ldrb	w0, [x20]
    6894:	7103fc1f 	cmp	w0, #0xff
    6898:	54000460 	b.eq	6924 <fwp_drop4+0x274>  // b.none
    689c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    68a0:	39000280 	strb	w0, [x20]
    68a4:	17ffffaa 	b	674c <fwp_drop4+0x9c>
    68a8:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    68ac:	911b6000 	add	x0, x0, #0x6d8
    68b0:	97fff638 	bl	4190 <fwp_trap>
    68b4:	ca544680 	eor	x0, x20, x20, lsr #17
    68b8:	911742c1 	add	x1, x22, #0x5d0
    68bc:	ca402400 	eor	x0, x0, x0, lsr #9
    68c0:	92401c00 	and	x0, x0, #0xff
    68c4:	910a2402 	add	x2, x0, #0x289
    68c8:	8b000c20 	add	x0, x1, x0, lsl #3
    68cc:	8b020c22 	add	x2, x1, x2, lsl #3
    68d0:	f94a2400 	ldr	x0, [x0, #5192]
    68d4:	b50000a0 	cbnz	x0, 68e8 <fwp_drop4+0x238>
    68d8:	17fffff4 	b	68a8 <fwp_drop4+0x1f8>
    68dc:	91004002 	add	x2, x0, #0x10
    68e0:	f9400800 	ldr	x0, [x0, #16]
    68e4:	b4fffe20 	cbz	x0, 68a8 <fwp_drop4+0x1f8>
    68e8:	f9400001 	ldr	x1, [x0]
    68ec:	eb14003f 	cmp	x1, x20
    68f0:	54ffff61 	b.ne	68dc <fwp_drop4+0x22c>  // b.any
    68f4:	f9400041 	ldr	x1, [x2]
    68f8:	f9400420 	ldr	x0, [x1, #8]
    68fc:	d1000400 	sub	x0, x0, #0x1
    6900:	f9000420 	str	x0, [x1, #8]
    6904:	f103f81f 	cmp	x0, #0xfe
    6908:	54fff781 	b.ne	67f8 <fwp_drop4+0x148>  // b.any
    690c:	39400280 	ldrb	w0, [x20]
    6910:	7103fc1f 	cmp	w0, #0xff
    6914:	540000e0 	b.eq	6930 <fwp_drop4+0x280>  // b.none
    6918:	12800020 	mov	w0, #0xfffffffe            	// #-2
    691c:	39000280 	strb	w0, [x20]
    6920:	17ffffb6 	b	67f8 <fwp_drop4+0x148>
    6924:	aa1403e0 	mov	x0, x20
    6928:	97fff63a 	bl	4210 <fwp_rc_forget_slot.part.0>
    692c:	17ffffdc 	b	689c <fwp_drop4+0x1ec>
    6930:	aa1403e0 	mov	x0, x20
    6934:	97fff637 	bl	4210 <fwp_rc_forget_slot.part.0>
    6938:	17fffff8 	b	6918 <fwp_drop4+0x268>
    693c:	d503201f 	nop

0000000000006940 <fwp_arg_drop37>:
    6940:	7100003f 	cmp	w1, #0x0
    6944:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6948:	54000041 	b.ne	6950 <fwp_arg_drop37+0x10>  // b.any
    694c:	d65f03c0 	ret
    6950:	f9400000 	ldr	x0, [x0]
    6954:	17ffff57 	b	66b0 <fwp_drop4>
    6958:	d503201f 	nop
    695c:	d503201f 	nop

0000000000006960 <fwp_task_dispose>:
    6960:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6964:	910003fd 	mov	x29, sp
    6968:	f9000bf3 	str	x19, [sp, #16]
    696c:	aa0003f3 	mov	x19, x0
    6970:	39414000 	ldrb	w0, [x0, #80]
    6974:	36000720 	tbz	w0, #0, 6a58 <fwp_task_dispose+0xf8>
    6978:	f9400a60 	ldr	x0, [x19, #16]
    697c:	b50006e0 	cbnz	x0, 6a58 <fwp_task_dispose+0xf8>
    6980:	a9478660 	ldp	x0, x1, [x19, #120]
    6984:	39014e7f 	strb	wzr, [x19, #83]
    6988:	f9003e7f 	str	xzr, [x19, #120]
    698c:	f100003f 	cmp	x1, #0x0
    6990:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6994:	54000040 	b.eq	699c <fwp_task_dispose+0x3c>  // b.none
    6998:	d63f0020 	blr	x1
    699c:	f9405660 	ldr	x0, [x19, #168]
    69a0:	97fff6b8 	bl	4480 <fwp_mem_free>
    69a4:	f900567f 	str	xzr, [x19, #168]
    69a8:	b9405e60 	ldr	w0, [x19, #92]
    69ac:	7100041f 	cmp	w0, #0x1
    69b0:	54000420 	b.eq	6a34 <fwp_task_dispose+0xd4>  // b.none
    69b4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    69b8:	91174042 	add	x2, x2, #0x5d0
    69bc:	f949d840 	ldr	x0, [x2, #5040]
    69c0:	f949ec41 	ldr	x1, [x2, #5080]
    69c4:	cb000260 	sub	x0, x19, x0
    69c8:	eb01401f 	cmp	x0, x1, lsl #16
    69cc:	540002e2 	b.cs	6a28 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    69d0:	d350fc01 	lsr	x1, x0, #16
    69d4:	f949fc44 	ldr	x4, [x2, #5112]
    69d8:	8b010821 	add	x1, x1, x1, lsl #2
    69dc:	d37df021 	lsl	x1, x1, #3
    69e0:	8b010083 	add	x3, x4, x1
    69e4:	f9401062 	ldr	x2, [x3, #32]
    69e8:	b4000202 	cbz	x2, 6a28 <fwp_task_dispose+0xc8>
    69ec:	38616881 	ldrb	w1, [x4, x1]
    69f0:	7100083f 	cmp	w1, #0x2
    69f4:	54000280 	b.eq	6a44 <fwp_task_dispose+0xe4>  // b.none
    69f8:	7100043f 	cmp	w1, #0x1
    69fc:	54000161 	b.ne	6a28 <fwp_task_dispose+0xc8>  // b.any
    6a00:	29430464 	ldp	w4, w1, [x3, #24]
    6a04:	92403c00 	and	x0, x0, #0xffff
    6a08:	9b047c00 	mul	x0, x0, x4
    6a0c:	d360fc00 	lsr	x0, x0, #32
    6a10:	eb01001f 	cmp	x0, x1
    6a14:	540000a2 	b.cs	6a28 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6a18:	8b000042 	add	x2, x2, x0
    6a1c:	39400040 	ldrb	w0, [x2]
    6a20:	7100041f 	cmp	w0, #0x1
    6a24:	54000080 	b.eq	6a34 <fwp_task_dispose+0xd4>  // b.none
    6a28:	f9400bf3 	ldr	x19, [sp, #16]
    6a2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a30:	d65f03c0 	ret
    6a34:	aa1303e0 	mov	x0, x19
    6a38:	f9400bf3 	ldr	x19, [sp, #16]
    6a3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a40:	17fff690 	b	4480 <fwp_mem_free>
    6a44:	72003c1f 	tst	w0, #0xffff
    6a48:	54fffea0 	b.eq	6a1c <fwp_task_dispose+0xbc>  // b.none
    6a4c:	f9400bf3 	ldr	x19, [sp, #16]
    6a50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a54:	d65f03c0 	ret
    6a58:	97ffefc2 	bl	2960 <abort@plt>
    6a5c:	d503201f 	nop

0000000000006a60 <fwp_free_zombie>:
    6a60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a64:	910003fd 	mov	x29, sp
    6a68:	a90153f3 	stp	x19, x20, [sp, #16]
    6a6c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6a70:	9101c281 	add	x1, x20, #0x70
    6a74:	f9407833 	ldr	x19, [x1, #240]
    6a78:	b4000333 	cbz	x19, 6adc <fwp_free_zombie+0x7c>
    6a7c:	f9400820 	ldr	x0, [x1, #16]
    6a80:	eb00027f 	cmp	x19, x0
    6a84:	540002c0 	b.eq	6adc <fwp_free_zombie+0x7c>  // b.none
    6a88:	b940f822 	ldr	w2, [x1, #248]
    6a8c:	f9400a60 	ldr	x0, [x19, #16]
    6a90:	7100fc5f 	cmp	w2, #0x3f
    6a94:	5400078c 	b.gt	6b84 <fwp_free_zombie+0x124>
    6a98:	91040023 	add	x3, x1, #0x100
    6a9c:	11000444 	add	w4, w2, #0x1
    6aa0:	b900f824 	str	w4, [x1, #248]
    6aa4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6aa8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6aac:	a9530261 	ldp	x1, x0, [x19, #304]
    6ab0:	b4000741 	cbz	x1, 6b98 <fwp_free_zombie+0x138>
    6ab4:	f9009c20 	str	x0, [x1, #312]
    6ab8:	b4000040 	cbz	x0, 6ac0 <fwp_free_zombie+0x60>
    6abc:	f9009801 	str	x1, [x0, #304]
    6ac0:	9101c294 	add	x20, x20, #0x70
    6ac4:	b9405e60 	ldr	w0, [x19, #92]
    6ac8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6acc:	f9007a9f 	str	xzr, [x20, #240]
    6ad0:	34000140 	cbz	w0, 6af8 <fwp_free_zombie+0x98>
    6ad4:	7100041f 	cmp	w0, #0x1
    6ad8:	54000080 	b.eq	6ae8 <fwp_free_zombie+0x88>  // b.none
    6adc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ae4:	d65f03c0 	ret
    6ae8:	aa1303e0 	mov	x0, x19
    6aec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6af4:	17ffff9b 	b	6960 <fwp_task_dispose>
    6af8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    6afc:	91174082 	add	x2, x4, #0x5d0
    6b00:	f949d841 	ldr	x1, [x2, #5040]
    6b04:	f949ec40 	ldr	x0, [x2, #5080]
    6b08:	cb010261 	sub	x1, x19, x1
    6b0c:	eb00403f 	cmp	x1, x0, lsl #16
    6b10:	54fffe62 	b.cs	6adc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b14:	d350fc20 	lsr	x0, x1, #16
    6b18:	f949fc43 	ldr	x3, [x2, #5112]
    6b1c:	8b000800 	add	x0, x0, x0, lsl #2
    6b20:	d37df000 	lsl	x0, x0, #3
    6b24:	8b000062 	add	x2, x3, x0
    6b28:	f9401054 	ldr	x20, [x2, #32]
    6b2c:	b4fffd94 	cbz	x20, 6adc <fwp_free_zombie+0x7c>
    6b30:	38606860 	ldrb	w0, [x3, x0]
    6b34:	7100081f 	cmp	w0, #0x2
    6b38:	54000360 	b.eq	6ba4 <fwp_free_zombie+0x144>  // b.none
    6b3c:	7100041f 	cmp	w0, #0x1
    6b40:	54fffce1 	b.ne	6adc <fwp_free_zombie+0x7c>  // b.any
    6b44:	29430043 	ldp	w3, w0, [x2, #24]
    6b48:	92403c21 	and	x1, x1, #0xffff
    6b4c:	9b037c21 	mul	x1, x1, x3
    6b50:	d360fc21 	lsr	x1, x1, #32
    6b54:	eb00003f 	cmp	x1, x0
    6b58:	54fffc22 	b.cs	6adc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b5c:	8b010294 	add	x20, x20, x1
    6b60:	39400280 	ldrb	w0, [x20]
    6b64:	34fffbc0 	cbz	w0, 6adc <fwp_free_zombie+0x7c>
    6b68:	7100041f 	cmp	w0, #0x1
    6b6c:	54fffbe0 	b.eq	6ae8 <fwp_free_zombie+0x88>  // b.none
    6b70:	7103fc1f 	cmp	w0, #0xff
    6b74:	540001e0 	b.eq	6bb0 <fwp_free_zombie+0x150>  // b.none
    6b78:	51000400 	sub	w0, w0, #0x1
    6b7c:	39000280 	strb	w0, [x20]
    6b80:	17ffffd7 	b	6adc <fwp_free_zombie+0x7c>
    6b84:	f9400e61 	ldr	x1, [x19, #24]
    6b88:	97ffefaa 	bl	2a30 <munmap@plt>
    6b8c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6b90:	a9530261 	ldp	x1, x0, [x19, #304]
    6b94:	b5fff901 	cbnz	x1, 6ab4 <fwp_free_zombie+0x54>
    6b98:	9101c282 	add	x2, x20, #0x70
    6b9c:	f9018040 	str	x0, [x2, #768]
    6ba0:	17ffffc6 	b	6ab8 <fwp_free_zombie+0x58>
    6ba4:	72003c3f 	tst	w1, #0xffff
    6ba8:	54fff9a1 	b.ne	6adc <fwp_free_zombie+0x7c>  // b.any
    6bac:	17ffffed 	b	6b60 <fwp_free_zombie+0x100>
    6bb0:	ca544680 	eor	x0, x20, x20, lsr #17
    6bb4:	91174084 	add	x4, x4, #0x5d0
    6bb8:	ca402400 	eor	x0, x0, x0, lsr #9
    6bbc:	92401c00 	and	x0, x0, #0xff
    6bc0:	910a2402 	add	x2, x0, #0x289
    6bc4:	8b000c80 	add	x0, x4, x0, lsl #3
    6bc8:	8b020c82 	add	x2, x4, x2, lsl #3
    6bcc:	f94a2400 	ldr	x0, [x0, #5192]
    6bd0:	b50000a0 	cbnz	x0, 6be4 <fwp_free_zombie+0x184>
    6bd4:	14000013 	b	6c20 <fwp_free_zombie+0x1c0>
    6bd8:	91004002 	add	x2, x0, #0x10
    6bdc:	f9400800 	ldr	x0, [x0, #16]
    6be0:	b4000200 	cbz	x0, 6c20 <fwp_free_zombie+0x1c0>
    6be4:	f9400001 	ldr	x1, [x0]
    6be8:	eb14003f 	cmp	x1, x20
    6bec:	54ffff61 	b.ne	6bd8 <fwp_free_zombie+0x178>  // b.any
    6bf0:	f9400041 	ldr	x1, [x2]
    6bf4:	f9400420 	ldr	x0, [x1, #8]
    6bf8:	d1000400 	sub	x0, x0, #0x1
    6bfc:	f9000420 	str	x0, [x1, #8]
    6c00:	f103f81f 	cmp	x0, #0xfe
    6c04:	54fff6c1 	b.ne	6adc <fwp_free_zombie+0x7c>  // b.any
    6c08:	39400280 	ldrb	w0, [x20]
    6c0c:	7103fc1f 	cmp	w0, #0xff
    6c10:	540000e0 	b.eq	6c2c <fwp_free_zombie+0x1cc>  // b.none
    6c14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c18:	39000280 	strb	w0, [x20]
    6c1c:	17ffffb0 	b	6adc <fwp_free_zombie+0x7c>
    6c20:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    6c24:	911b6000 	add	x0, x0, #0x6d8
    6c28:	97fff55a 	bl	4190 <fwp_trap>
    6c2c:	aa1403e0 	mov	x0, x20
    6c30:	97fff578 	bl	4210 <fwp_rc_forget_slot.part.0>
    6c34:	17fffff8 	b	6c14 <fwp_free_zombie+0x1b4>
    6c38:	d503201f 	nop
    6c3c:	d503201f 	nop

0000000000006c40 <fwp_block>:
    6c40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c44:	910003fd 	mov	x29, sp
    6c48:	a90153f3 	stp	x19, x20, [sp, #16]
    6c4c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6c50:	9101c274 	add	x20, x19, #0x70
    6c54:	f9404282 	ldr	x2, [x20, #128]
    6c58:	b4000642 	cbz	x2, 6d20 <fwp_block+0xe0>
    6c5c:	9101c261 	add	x1, x19, #0x70
    6c60:	f9408040 	ldr	x0, [x2, #256]
    6c64:	f9004020 	str	x0, [x1, #128]
    6c68:	b40006a0 	cbz	x0, 6d3c <fwp_block+0xfc>
    6c6c:	d503201f 	nop
    6c70:	9101c263 	add	x3, x19, #0x70
    6c74:	3901505f 	strb	wzr, [x2, #84]
    6c78:	f9400864 	ldr	x4, [x3, #16]
    6c7c:	eb02009f 	cmp	x4, x2
    6c80:	54000440 	b.eq	6d08 <fwp_block+0xc8>  // b.none
    6c84:	f9418465 	ldr	x5, [x3, #776]
    6c88:	f9000862 	str	x2, [x3, #16]
    6c8c:	f9400441 	ldr	x1, [x2, #8]
    6c90:	f9004885 	str	x5, [x4, #144]
    6c94:	f9418865 	ldr	x5, [x3, #784]
    6c98:	f9004c85 	str	x5, [x4, #152]
    6c9c:	f9418c65 	ldr	x5, [x3, #792]
    6ca0:	f9005085 	str	x5, [x4, #160]
    6ca4:	f9419065 	ldr	x5, [x3, #800]
    6ca8:	f9005485 	str	x5, [x4, #168]
    6cac:	f9419465 	ldr	x5, [x3, #808]
    6cb0:	f9005885 	str	x5, [x4, #176]
    6cb4:	f9419865 	ldr	x5, [x3, #816]
    6cb8:	f9005c85 	str	x5, [x4, #184]
    6cbc:	f9419c65 	ldr	x5, [x3, #824]
    6cc0:	f9006085 	str	x5, [x4, #192]
    6cc4:	f9400480 	ldr	x0, [x4, #8]
    6cc8:	f9404844 	ldr	x4, [x2, #144]
    6ccc:	f9018464 	str	x4, [x3, #776]
    6cd0:	f9404c44 	ldr	x4, [x2, #152]
    6cd4:	f9018864 	str	x4, [x3, #784]
    6cd8:	f9405044 	ldr	x4, [x2, #160]
    6cdc:	f9018c64 	str	x4, [x3, #792]
    6ce0:	f9405444 	ldr	x4, [x2, #168]
    6ce4:	f9019064 	str	x4, [x3, #800]
    6ce8:	f9405844 	ldr	x4, [x2, #176]
    6cec:	f9019464 	str	x4, [x3, #808]
    6cf0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6cf4:	f9019864 	str	x4, [x3, #816]
    6cf8:	f9019c62 	str	x2, [x3, #824]
    6cfc:	97ffef1d 	bl	2970 <swapcontext@plt>
    6d00:	97ffff58 	bl	6a60 <fwp_free_zombie>
    6d04:	d503201f 	nop
    6d08:	9101c260 	add	x0, x19, #0x70
    6d0c:	b9434000 	ldr	w0, [x0, #832]
    6d10:	340001a0 	cbz	w0, 6d44 <fwp_block+0x104>
    6d14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d18:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d1c:	d65f03c0 	ret
    6d20:	97fff764 	bl	4ab0 <fwp_poll_events>
    6d24:	f9404282 	ldr	x2, [x20, #128]
    6d28:	b4ffffc2 	cbz	x2, 6d20 <fwp_block+0xe0>
    6d2c:	9101c261 	add	x1, x19, #0x70
    6d30:	f9408040 	ldr	x0, [x2, #256]
    6d34:	f9004020 	str	x0, [x1, #128]
    6d38:	b5fff9c0 	cbnz	x0, 6c70 <fwp_block+0x30>
    6d3c:	f9003c3f 	str	xzr, [x1, #120]
    6d40:	17ffffcc 	b	6c70 <fwp_block+0x30>
    6d44:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    6d48:	9125c000 	add	x0, x0, #0x970
    6d4c:	97ffef55 	bl	2aa0 <getenv@plt>
    6d50:	5284e202 	mov	w2, #0x2710                	// #10000
    6d54:	b4000060 	cbz	x0, 6d60 <fwp_block+0x120>
    6d58:	39400001 	ldrb	w1, [x0]
    6d5c:	350000c1 	cbnz	w1, 6d74 <fwp_block+0x134>
    6d60:	9101c273 	add	x19, x19, #0x70
    6d64:	b9034262 	str	w2, [x19, #832]
    6d68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d70:	d65f03c0 	ret
    6d74:	52800142 	mov	w2, #0xa                   	// #10
    6d78:	d2800001 	mov	x1, #0x0                   	// #0
    6d7c:	97ffee99 	bl	27e0 <strtoll@plt>
    6d80:	d1000403 	sub	x3, x0, #0x1
    6d84:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6d88:	eb02007f 	cmp	x3, x2
    6d8c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6d90:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6d94:	17fffff3 	b	6d60 <fwp_block+0x120>
    6d98:	d503201f 	nop
    6d9c:	d503201f 	nop

0000000000006da0 <fwp_drop10>:
    6da0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6da4:	910003fd 	mov	x29, sp
    6da8:	a90153f3 	stp	x19, x20, [sp, #16]
    6dac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6db0:	f90013f5 	str	x21, [sp, #32]
    6db4:	91174275 	add	x21, x19, #0x5d0
    6db8:	f949daa1 	ldr	x1, [x21, #5040]
    6dbc:	f949eea2 	ldr	x2, [x21, #5080]
    6dc0:	cb010001 	sub	x1, x0, x1
    6dc4:	eb02403f 	cmp	x1, x2, lsl #16
    6dc8:	54000382 	b.cs	6e38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6dcc:	d350fc22 	lsr	x2, x1, #16
    6dd0:	f949fea3 	ldr	x3, [x21, #5112]
    6dd4:	8b020842 	add	x2, x2, x2, lsl #2
    6dd8:	d37df042 	lsl	x2, x2, #3
    6ddc:	8b020064 	add	x4, x3, x2
    6de0:	f9401094 	ldr	x20, [x4, #32]
    6de4:	b40002b4 	cbz	x20, 6e38 <fwp_drop10+0x98>
    6de8:	38626862 	ldrb	w2, [x3, x2]
    6dec:	7100085f 	cmp	w2, #0x2
    6df0:	540007a0 	b.eq	6ee4 <fwp_drop10+0x144>  // b.none
    6df4:	7100045f 	cmp	w2, #0x1
    6df8:	54000201 	b.ne	6e38 <fwp_drop10+0x98>  // b.any
    6dfc:	29430885 	ldp	w5, w2, [x4, #24]
    6e00:	92403c21 	and	x1, x1, #0xffff
    6e04:	9b057c21 	mul	x1, x1, x5
    6e08:	d360fc21 	lsr	x1, x1, #32
    6e0c:	eb02003f 	cmp	x1, x2
    6e10:	54000142 	b.cs	6e38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e14:	8b010294 	add	x20, x20, x1
    6e18:	39400281 	ldrb	w1, [x20]
    6e1c:	340000e1 	cbz	w1, 6e38 <fwp_drop10+0x98>
    6e20:	7100043f 	cmp	w1, #0x1
    6e24:	54000120 	b.eq	6e48 <fwp_drop10+0xa8>  // b.none
    6e28:	7103fc3f 	cmp	w1, #0xff
    6e2c:	540007c0 	b.eq	6f24 <fwp_drop10+0x184>  // b.none
    6e30:	51000421 	sub	w1, w1, #0x1
    6e34:	39000281 	strb	w1, [x20]
    6e38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e3c:	f94013f5 	ldr	x21, [sp, #32]
    6e40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e44:	d65f03c0 	ret
    6e48:	f9400001 	ldr	x1, [x0]
    6e4c:	b7f80581 	tbnz	x1, #63, 6efc <fwp_drop10+0x15c>
    6e50:	91174273 	add	x19, x19, #0x5d0
    6e54:	f949da61 	ldr	x1, [x19, #5040]
    6e58:	f949ee62 	ldr	x2, [x19, #5080]
    6e5c:	cb010001 	sub	x1, x0, x1
    6e60:	eb02403f 	cmp	x1, x2, lsl #16
    6e64:	54fffea2 	b.cs	6e38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e68:	d350fc22 	lsr	x2, x1, #16
    6e6c:	8b020842 	add	x2, x2, x2, lsl #2
    6e70:	d37df042 	lsl	x2, x2, #3
    6e74:	8b020065 	add	x5, x3, x2
    6e78:	f94010a4 	ldr	x4, [x5, #32]
    6e7c:	b4fffde4 	cbz	x4, 6e38 <fwp_drop10+0x98>
    6e80:	38626862 	ldrb	w2, [x3, x2]
    6e84:	7100085f 	cmp	w2, #0x2
    6e88:	54000220 	b.eq	6ecc <fwp_drop10+0x12c>  // b.none
    6e8c:	7100045f 	cmp	w2, #0x1
    6e90:	54fffd41 	b.ne	6e38 <fwp_drop10+0x98>  // b.any
    6e94:	294308a3 	ldp	w3, w2, [x5, #24]
    6e98:	92403c21 	and	x1, x1, #0xffff
    6e9c:	9b037c21 	mul	x1, x1, x3
    6ea0:	d360fc21 	lsr	x1, x1, #32
    6ea4:	eb02003f 	cmp	x1, x2
    6ea8:	54fffc82 	b.cs	6e38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6eac:	8b010084 	add	x4, x4, x1
    6eb0:	39400081 	ldrb	w1, [x4]
    6eb4:	7100043f 	cmp	w1, #0x1
    6eb8:	54fffc01 	b.ne	6e38 <fwp_drop10+0x98>  // b.any
    6ebc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ec0:	f94013f5 	ldr	x21, [sp, #32]
    6ec4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ec8:	17fff56e 	b	4480 <fwp_mem_free>
    6ecc:	72003c3f 	tst	w1, #0xffff
    6ed0:	54ffff00 	b.eq	6eb0 <fwp_drop10+0x110>  // b.none
    6ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ed8:	f94013f5 	ldr	x21, [sp, #32]
    6edc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ee0:	d65f03c0 	ret
    6ee4:	72003c3f 	tst	w1, #0xffff
    6ee8:	54fff980 	b.eq	6e18 <fwp_drop10+0x78>  // b.none
    6eec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ef0:	f94013f5 	ldr	x21, [sp, #32]
    6ef4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ef8:	d65f03c0 	ret
    6efc:	f9400414 	ldr	x20, [x0, #8]
    6f00:	97fffb25 	bl	5b94 <fwp_rc_free_arr>
    6f04:	91174260 	add	x0, x19, #0x5d0
    6f08:	f949d801 	ldr	x1, [x0, #5040]
    6f0c:	f949ec00 	ldr	x0, [x0, #5080]
    6f10:	cb010281 	sub	x1, x20, x1
    6f14:	eb00403f 	cmp	x1, x0, lsl #16
    6f18:	54fff902 	b.cs	6e38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f1c:	aa1403e0 	mov	x0, x20
    6f20:	17ffffab 	b	6dcc <fwp_drop10+0x2c>
    6f24:	ca544680 	eor	x0, x20, x20, lsr #17
    6f28:	91174273 	add	x19, x19, #0x5d0
    6f2c:	ca402400 	eor	x0, x0, x0, lsr #9
    6f30:	92401c00 	and	x0, x0, #0xff
    6f34:	910a2402 	add	x2, x0, #0x289
    6f38:	8b000e60 	add	x0, x19, x0, lsl #3
    6f3c:	8b020e62 	add	x2, x19, x2, lsl #3
    6f40:	f94a2400 	ldr	x0, [x0, #5192]
    6f44:	b50000a0 	cbnz	x0, 6f58 <fwp_drop10+0x1b8>
    6f48:	14000013 	b	6f94 <fwp_drop10+0x1f4>
    6f4c:	91004002 	add	x2, x0, #0x10
    6f50:	f9400800 	ldr	x0, [x0, #16]
    6f54:	b4000200 	cbz	x0, 6f94 <fwp_drop10+0x1f4>
    6f58:	f9400001 	ldr	x1, [x0]
    6f5c:	eb14003f 	cmp	x1, x20
    6f60:	54ffff61 	b.ne	6f4c <fwp_drop10+0x1ac>  // b.any
    6f64:	f9400041 	ldr	x1, [x2]
    6f68:	f9400420 	ldr	x0, [x1, #8]
    6f6c:	d1000400 	sub	x0, x0, #0x1
    6f70:	f9000420 	str	x0, [x1, #8]
    6f74:	f103f81f 	cmp	x0, #0xfe
    6f78:	54fff601 	b.ne	6e38 <fwp_drop10+0x98>  // b.any
    6f7c:	39400280 	ldrb	w0, [x20]
    6f80:	7103fc1f 	cmp	w0, #0xff
    6f84:	540000e0 	b.eq	6fa0 <fwp_drop10+0x200>  // b.none
    6f88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f8c:	39000280 	strb	w0, [x20]
    6f90:	17ffffaa 	b	6e38 <fwp_drop10+0x98>
    6f94:	f0000020 	adrp	x0, d000 <__divti3+0x240>
    6f98:	911b6000 	add	x0, x0, #0x6d8
    6f9c:	97fff47d 	bl	4190 <fwp_trap>
    6fa0:	aa1403e0 	mov	x0, x20
    6fa4:	97fff49b 	bl	4210 <fwp_rc_forget_slot.part.0>
    6fa8:	17fffff8 	b	6f88 <fwp_drop10+0x1e8>
    6fac:	d503201f 	nop

0000000000006fb0 <fwp_caps173>:
    6fb0:	34000041 	cbz	w1, 6fb8 <fwp_caps173+0x8>
    6fb4:	d65f03c0 	ret
    6fb8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6fbc:	91174063 	add	x3, x3, #0x5d0
    6fc0:	f949d861 	ldr	x1, [x3, #5040]
    6fc4:	f949ec62 	ldr	x2, [x3, #5080]
    6fc8:	cb010001 	sub	x1, x0, x1
    6fcc:	eb02403f 	cmp	x1, x2, lsl #16
    6fd0:	54ffff22 	b.cs	6fb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6fd4:	d350fc22 	lsr	x2, x1, #16
    6fd8:	f949fc65 	ldr	x5, [x3, #5112]
    6fdc:	8b020842 	add	x2, x2, x2, lsl #2
    6fe0:	d37df042 	lsl	x2, x2, #3
    6fe4:	8b0200a4 	add	x4, x5, x2
    6fe8:	f9401083 	ldr	x3, [x4, #32]
    6fec:	b4fffe43 	cbz	x3, 6fb4 <fwp_caps173+0x4>
    6ff0:	386268a2 	ldrb	w2, [x5, x2]
    6ff4:	7100085f 	cmp	w2, #0x2
    6ff8:	540001c0 	b.eq	7030 <fwp_caps173+0x80>  // b.none
    6ffc:	7100045f 	cmp	w2, #0x1
    7000:	54fffda1 	b.ne	6fb4 <fwp_caps173+0x4>  // b.any
    7004:	29430885 	ldp	w5, w2, [x4, #24]
    7008:	92403c21 	and	x1, x1, #0xffff
    700c:	9b057c21 	mul	x1, x1, x5
    7010:	d360fc21 	lsr	x1, x1, #32
    7014:	eb02003f 	cmp	x1, x2
    7018:	54fffce2 	b.cs	6fb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    701c:	8b010063 	add	x3, x3, x1
    7020:	39400061 	ldrb	w1, [x3]
    7024:	7100043f 	cmp	w1, #0x1
    7028:	54fffc61 	b.ne	6fb4 <fwp_caps173+0x4>  // b.any
    702c:	17fff515 	b	4480 <fwp_mem_free>
    7030:	72003c3f 	tst	w1, #0xffff
    7034:	54ffff60 	b.eq	7020 <fwp_caps173+0x70>  // b.none
    7038:	d65f03c0 	ret
    703c:	d503201f 	nop

0000000000007040 <fwp_args37>:
    7040:	7100003f 	cmp	w1, #0x0
    7044:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7048:	54000041 	b.ne	7050 <fwp_args37+0x10>  // b.any
    704c:	d65f03c0 	ret
    7050:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7054:	91174042 	add	x2, x2, #0x5d0
    7058:	f9400001 	ldr	x1, [x0]
    705c:	f949d843 	ldr	x3, [x2, #5040]
    7060:	f949ec40 	ldr	x0, [x2, #5080]
    7064:	cb030021 	sub	x1, x1, x3
    7068:	eb00403f 	cmp	x1, x0, lsl #16
    706c:	54ffff02 	b.cs	704c <fwp_args37+0xc>  // b.hs, b.nlast
    7070:	d350fc20 	lsr	x0, x1, #16
    7074:	f949fc44 	ldr	x4, [x2, #5112]
    7078:	8b000800 	add	x0, x0, x0, lsl #2
    707c:	d37df002 	lsl	x2, x0, #3
    7080:	8b020083 	add	x3, x4, x2
    7084:	f9401060 	ldr	x0, [x3, #32]
    7088:	b4fffe20 	cbz	x0, 704c <fwp_args37+0xc>
    708c:	38626882 	ldrb	w2, [x4, x2]
    7090:	7100085f 	cmp	w2, #0x2
    7094:	54000220 	b.eq	70d8 <fwp_args37+0x98>  // b.none
    7098:	7100045f 	cmp	w2, #0x1
    709c:	54fffd81 	b.ne	704c <fwp_args37+0xc>  // b.any
    70a0:	29430864 	ldp	w4, w2, [x3, #24]
    70a4:	92403c21 	and	x1, x1, #0xffff
    70a8:	9b047c21 	mul	x1, x1, x4
    70ac:	d360fc21 	lsr	x1, x1, #32
    70b0:	eb02003f 	cmp	x1, x2
    70b4:	54fffcc2 	b.cs	704c <fwp_args37+0xc>  // b.hs, b.nlast
    70b8:	8b010000 	add	x0, x0, x1
    70bc:	39400001 	ldrb	w1, [x0]
    70c0:	34fffc61 	cbz	w1, 704c <fwp_args37+0xc>
    70c4:	7103f43f 	cmp	w1, #0xfd
    70c8:	540000e8 	b.hi	70e4 <fwp_args37+0xa4>  // b.pmore
    70cc:	11000421 	add	w1, w1, #0x1
    70d0:	39000001 	strb	w1, [x0]
    70d4:	d65f03c0 	ret
    70d8:	72003c3f 	tst	w1, #0xffff
    70dc:	54ffff00 	b.eq	70bc <fwp_args37+0x7c>  // b.none
    70e0:	d65f03c0 	ret
    70e4:	17fff560 	b	4664 <fwp_rc_wide_dup>
    70e8:	d503201f 	nop
    70ec:	d503201f 	nop

00000000000070f0 <fwp_caps37>:
    70f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70f4:	910003fd 	mov	x29, sp
    70f8:	f9000bf3 	str	x19, [sp, #16]
    70fc:	aa0003f3 	mov	x19, x0
    7100:	b9400400 	ldr	w0, [x0, #4]
    7104:	340004a0 	cbz	w0, 7198 <fwp_caps37+0xa8>
    7108:	f9400660 	ldr	x0, [x19, #8]
    710c:	350004e1 	cbnz	w1, 71a8 <fwp_caps37+0xb8>
    7110:	97fffd68 	bl	66b0 <fwp_drop4>
    7114:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7118:	91174042 	add	x2, x2, #0x5d0
    711c:	f949d840 	ldr	x0, [x2, #5040]
    7120:	f949ec41 	ldr	x1, [x2, #5080]
    7124:	cb000260 	sub	x0, x19, x0
    7128:	eb01401f 	cmp	x0, x1, lsl #16
    712c:	54000382 	b.cs	719c <fwp_caps37+0xac>  // b.hs, b.nlast
    7130:	d350fc01 	lsr	x1, x0, #16
    7134:	f949fc44 	ldr	x4, [x2, #5112]
    7138:	8b010821 	add	x1, x1, x1, lsl #2
    713c:	d37df021 	lsl	x1, x1, #3
    7140:	8b010083 	add	x3, x4, x1
    7144:	f9401062 	ldr	x2, [x3, #32]
    7148:	b40002a2 	cbz	x2, 719c <fwp_caps37+0xac>
    714c:	38616881 	ldrb	w1, [x4, x1]
    7150:	7100083f 	cmp	w1, #0x2
    7154:	540006c0 	b.eq	722c <fwp_caps37+0x13c>  // b.none
    7158:	7100043f 	cmp	w1, #0x1
    715c:	54000201 	b.ne	719c <fwp_caps37+0xac>  // b.any
    7160:	29430464 	ldp	w4, w1, [x3, #24]
    7164:	92403c00 	and	x0, x0, #0xffff
    7168:	9b047c00 	mul	x0, x0, x4
    716c:	d360fc00 	lsr	x0, x0, #32
    7170:	eb01001f 	cmp	x0, x1
    7174:	54000142 	b.cs	719c <fwp_caps37+0xac>  // b.hs, b.nlast
    7178:	8b000042 	add	x2, x2, x0
    717c:	39400040 	ldrb	w0, [x2]
    7180:	7100041f 	cmp	w0, #0x1
    7184:	540000c1 	b.ne	719c <fwp_caps37+0xac>  // b.any
    7188:	aa1303e0 	mov	x0, x19
    718c:	f9400bf3 	ldr	x19, [sp, #16]
    7190:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7194:	17fff4bb 	b	4480 <fwp_mem_free>
    7198:	34fffbe1 	cbz	w1, 7114 <fwp_caps37+0x24>
    719c:	f9400bf3 	ldr	x19, [sp, #16]
    71a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71a4:	d65f03c0 	ret
    71a8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    71ac:	91174042 	add	x2, x2, #0x5d0
    71b0:	f949d843 	ldr	x3, [x2, #5040]
    71b4:	f949ec41 	ldr	x1, [x2, #5080]
    71b8:	cb030000 	sub	x0, x0, x3
    71bc:	eb01401f 	cmp	x0, x1, lsl #16
    71c0:	54fffee2 	b.cs	719c <fwp_caps37+0xac>  // b.hs, b.nlast
    71c4:	d350fc01 	lsr	x1, x0, #16
    71c8:	f949fc44 	ldr	x4, [x2, #5112]
    71cc:	8b010821 	add	x1, x1, x1, lsl #2
    71d0:	d37df021 	lsl	x1, x1, #3
    71d4:	8b010083 	add	x3, x4, x1
    71d8:	f9401062 	ldr	x2, [x3, #32]
    71dc:	b4fffe02 	cbz	x2, 719c <fwp_caps37+0xac>
    71e0:	38616881 	ldrb	w1, [x4, x1]
    71e4:	7100083f 	cmp	w1, #0x2
    71e8:	54000280 	b.eq	7238 <fwp_caps37+0x148>  // b.none
    71ec:	7100043f 	cmp	w1, #0x1
    71f0:	54fffd61 	b.ne	719c <fwp_caps37+0xac>  // b.any
    71f4:	92403c01 	and	x1, x0, #0xffff
    71f8:	29430064 	ldp	w4, w0, [x3, #24]
    71fc:	9b047c21 	mul	x1, x1, x4
    7200:	d360fc21 	lsr	x1, x1, #32
    7204:	eb00003f 	cmp	x1, x0
    7208:	54fffca2 	b.cs	719c <fwp_caps37+0xac>  // b.hs, b.nlast
    720c:	8b010042 	add	x2, x2, x1
    7210:	39400040 	ldrb	w0, [x2]
    7214:	34fffc40 	cbz	w0, 719c <fwp_caps37+0xac>
    7218:	7103f41f 	cmp	w0, #0xfd
    721c:	54000148 	b.hi	7244 <fwp_caps37+0x154>  // b.pmore
    7220:	11000400 	add	w0, w0, #0x1
    7224:	39000040 	strb	w0, [x2]
    7228:	17ffffdd 	b	719c <fwp_caps37+0xac>
    722c:	72003c1f 	tst	w0, #0xffff
    7230:	54fffb61 	b.ne	719c <fwp_caps37+0xac>  // b.any
    7234:	17ffffd2 	b	717c <fwp_caps37+0x8c>
    7238:	72003c1f 	tst	w0, #0xffff
    723c:	54fffb01 	b.ne	719c <fwp_caps37+0xac>  // b.any
    7240:	17fffff4 	b	7210 <fwp_caps37+0x120>
    7244:	f9400bf3 	ldr	x19, [sp, #16]
    7248:	aa0203e0 	mov	x0, x2
    724c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7250:	17fff505 	b	4664 <fwp_rc_wide_dup>

0000000000007254 <f37>:
    7254:	d10203ff 	sub	sp, sp, #0x80
    7258:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    725c:	f947f421 	ldr	x1, [x1, #4072]
    7260:	a9027bfd 	stp	x29, x30, [sp, #32]
    7264:	910083fd 	add	x29, sp, #0x20
    7268:	a9045bf5 	stp	x21, x22, [sp, #64]
    726c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    7270:	911742a3 	add	x3, x21, #0x5d0
    7274:	a90353f3 	stp	x19, x20, [sp, #48]
    7278:	aa0003f6 	mov	x22, x0
    727c:	a90563f7 	stp	x23, x24, [sp, #80]
    7280:	a9066bf9 	stp	x25, x26, [sp, #96]
    7284:	f949ec62 	ldr	x2, [x3, #5080]
    7288:	f9400024 	ldr	x4, [x1]
    728c:	f9000fe4 	str	x4, [sp, #24]
    7290:	d2800004 	mov	x4, #0x0                   	// #0
    7294:	f949d861 	ldr	x1, [x3, #5040]
    7298:	d370bc42 	lsl	x2, x2, #16
    729c:	b4001800 	cbz	x0, 759c <f37+0x348>
    72a0:	f9400817 	ldr	x23, [x0, #16]
    72a4:	cb0102e1 	sub	x1, x23, x1
    72a8:	eb02003f 	cmp	x1, x2
    72ac:	54000362 	b.cs	7318 <f37+0xc4>  // b.hs, b.nlast
    72b0:	f949fc60 	ldr	x0, [x3, #5112]
    72b4:	d350fc22 	lsr	x2, x1, #16
    72b8:	8b020842 	add	x2, x2, x2, lsl #2
    72bc:	8b020c02 	add	x2, x0, x2, lsl #3
    72c0:	f9401040 	ldr	x0, [x2, #32]
    72c4:	b40002a0 	cbz	x0, 7318 <f37+0xc4>
    72c8:	39400043 	ldrb	w3, [x2]
    72cc:	7100087f 	cmp	w3, #0x2
    72d0:	54001540 	b.eq	7578 <f37+0x324>  // b.none
    72d4:	7100047f 	cmp	w3, #0x1
    72d8:	540001c1 	b.ne	7310 <f37+0xbc>  // b.any
    72dc:	29430843 	ldp	w3, w2, [x2, #24]
    72e0:	92403c21 	and	x1, x1, #0xffff
    72e4:	9b037c21 	mul	x1, x1, x3
    72e8:	d360fc21 	lsr	x1, x1, #32
    72ec:	eb02003f 	cmp	x1, x2
    72f0:	54000102 	b.cs	7310 <f37+0xbc>  // b.hs, b.nlast
    72f4:	8b010000 	add	x0, x0, x1
    72f8:	39400001 	ldrb	w1, [x0]
    72fc:	340000a1 	cbz	w1, 7310 <f37+0xbc>
    7300:	7103f43f 	cmp	w1, #0xfd
    7304:	540017e8 	b.hi	7600 <f37+0x3ac>  // b.pmore
    7308:	11000421 	add	w1, w1, #0x1
    730c:	39000001 	strb	w1, [x0]
    7310:	d2800002 	mov	x2, #0x0                   	// #0
    7314:	b40000d6 	cbz	x22, 732c <f37+0xd8>
    7318:	aa1603e1 	mov	x1, x22
    731c:	d2800002 	mov	x2, #0x0                   	// #0
    7320:	f9400821 	ldr	x1, [x1, #16]
    7324:	91000442 	add	x2, x2, #0x1
    7328:	b5ffffc1 	cbnz	x1, 7320 <f37+0xcc>
    732c:	b40013f7 	cbz	x23, 75a8 <f37+0x354>
    7330:	aa1703e1 	mov	x1, x23
    7334:	d2800003 	mov	x3, #0x0                   	// #0
    7338:	f9400821 	ldr	x1, [x1, #16]
    733c:	91000463 	add	x3, x3, #0x1
    7340:	b5ffffc1 	cbnz	x1, 7338 <f37+0xe4>
    7344:	eb02007f 	cmp	x3, x2
    7348:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    734c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7350:	eb00027f 	cmp	x19, x0
    7354:	540010a8 	b.hi	7568 <f37+0x314>  // b.pmore
    7358:	d37ffa74 	lsl	x20, x19, #1
    735c:	52800041 	mov	w1, #0x2                   	// #2
    7360:	91000680 	add	x0, x20, #0x1
    7364:	d37df000 	lsl	x0, x0, #3
    7368:	97fff702 	bl	4f70 <fwp_heap_alloc>
    736c:	aa0003f8 	mov	x24, x0
    7370:	911742a1 	add	x1, x21, #0x5d0
    7374:	aa0103e0 	mov	x0, x1
    7378:	f9000314 	str	x20, [x24]
    737c:	f949d821 	ldr	x1, [x1, #5040]
    7380:	f949ec00 	ldr	x0, [x0, #5080]
    7384:	cb010301 	sub	x1, x24, x1
    7388:	eb00403f 	cmp	x1, x0, lsl #16
    738c:	54000342 	b.cs	73f4 <f37+0x1a0>  // b.hs, b.nlast
    7390:	911742a2 	add	x2, x21, #0x5d0
    7394:	d350fc20 	lsr	x0, x1, #16
    7398:	8b000800 	add	x0, x0, x0, lsl #2
    739c:	f949fc43 	ldr	x3, [x2, #5112]
    73a0:	d37df002 	lsl	x2, x0, #3
    73a4:	8b020060 	add	x0, x3, x2
    73a8:	f9401014 	ldr	x20, [x0, #32]
    73ac:	b4000254 	cbz	x20, 73f4 <f37+0x1a0>
    73b0:	38626862 	ldrb	w2, [x3, x2]
    73b4:	7100085f 	cmp	w2, #0x2
    73b8:	54000ec0 	b.eq	7590 <f37+0x33c>  // b.none
    73bc:	7100045f 	cmp	w2, #0x1
    73c0:	540001a1 	b.ne	73f4 <f37+0x1a0>  // b.any
    73c4:	29430002 	ldp	w2, w0, [x0, #24]
    73c8:	92403c21 	and	x1, x1, #0xffff
    73cc:	9b027c21 	mul	x1, x1, x2
    73d0:	d360fc21 	lsr	x1, x1, #32
    73d4:	eb00003f 	cmp	x1, x0
    73d8:	540000e2 	b.cs	73f4 <f37+0x1a0>  // b.hs, b.nlast
    73dc:	8b010294 	add	x20, x20, x1
    73e0:	39400280 	ldrb	w0, [x20]
    73e4:	7103fc1f 	cmp	w0, #0xff
    73e8:	54001100 	b.eq	7608 <f37+0x3b4>  // b.none
    73ec:	52800020 	mov	w0, #0x1                   	// #1
    73f0:	39000280 	strb	w0, [x20]
    73f4:	b4000253 	cbz	x19, 743c <f37+0x1e8>
    73f8:	8b131313 	add	x19, x24, x19, lsl #4
    73fc:	aa1803f4 	mov	x20, x24
    7400:	aa1603fa 	mov	x26, x22
    7404:	aa1703f9 	mov	x25, x23
    7408:	f9400723 	ldr	x3, [x25, #8]
    740c:	f9400742 	ldr	x2, [x26, #8]
    7410:	f9400861 	ldr	x1, [x3, #16]
    7414:	f9400840 	ldr	x0, [x2, #16]
    7418:	fd400461 	ldr	d1, [x3, #8]
    741c:	fd400440 	ldr	d0, [x2, #8]
    7420:	97fff850 	bl	5560 <w120>
    7424:	f9000680 	str	x0, [x20, #8]
    7428:	f8010e81 	str	x1, [x20, #16]!
    742c:	f9400b39 	ldr	x25, [x25, #16]
    7430:	f9400b5a 	ldr	x26, [x26, #16]
    7434:	eb14027f 	cmp	x19, x20
    7438:	54fffe81 	b.ne	7408 <f37+0x1b4>  // b.any
    743c:	aa1703e0 	mov	x0, x23
    7440:	97fffc9c 	bl	66b0 <fwp_drop4>
    7444:	aa1603e0 	mov	x0, x22
    7448:	97fffc9a 	bl	66b0 <fwp_drop4>
    744c:	f9400316 	ldr	x22, [x24]
    7450:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7454:	b4000236 	cbz	x22, 7498 <f37+0x244>
    7458:	fd003be8 	str	d8, [sp, #112]
    745c:	2f00e408 	movi	d8, #0x0
    7460:	91002319 	add	x25, x24, #0x8
    7464:	91004317 	add	x23, x24, #0x10
    7468:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    746c:	d2800013 	mov	x19, #0x0                   	// #0
    7470:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7474:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7478:	91000a73 	add	x19, x19, #0x2
    747c:	1e602908 	fadd	d8, d8, d0
    7480:	97fff7e0 	bl	5400 <f141.constprop.0>
    7484:	aa0003f4 	mov	x20, x0
    7488:	eb1302df 	cmp	x22, x19
    748c:	54ffff28 	b.hi	7470 <f37+0x21c>  // b.pmore
    7490:	9e660116 	fmov	x22, d8
    7494:	fd403be8 	ldr	d8, [sp, #112]
    7498:	911742b5 	add	x21, x21, #0x5d0
    749c:	aa1803e0 	mov	x0, x24
    74a0:	97fffe40 	bl	6da0 <fwp_drop10>
    74a4:	a900d3f6 	stp	x22, x20, [sp, #8]
    74a8:	910023e1 	add	x1, sp, #0x8
    74ac:	52800000 	mov	w0, #0x0                   	// #0
    74b0:	97fff6f5 	bl	5084 <fwp_data.part.0.constprop.0>
    74b4:	f949daa1 	ldr	x1, [x21, #5040]
    74b8:	aa0003f3 	mov	x19, x0
    74bc:	f949eea0 	ldr	x0, [x21, #5080]
    74c0:	cb010261 	sub	x1, x19, x1
    74c4:	eb00403f 	cmp	x1, x0, lsl #16
    74c8:	54000322 	b.cs	752c <f37+0x2d8>  // b.hs, b.nlast
    74cc:	d350fc22 	lsr	x2, x1, #16
    74d0:	f949fea3 	ldr	x3, [x21, #5112]
    74d4:	8b020842 	add	x2, x2, x2, lsl #2
    74d8:	d37df042 	lsl	x2, x2, #3
    74dc:	8b020060 	add	x0, x3, x2
    74e0:	f9401014 	ldr	x20, [x0, #32]
    74e4:	b4000254 	cbz	x20, 752c <f37+0x2d8>
    74e8:	38626862 	ldrb	w2, [x3, x2]
    74ec:	7100085f 	cmp	w2, #0x2
    74f0:	540004a0 	b.eq	7584 <f37+0x330>  // b.none
    74f4:	7100045f 	cmp	w2, #0x1
    74f8:	540001a1 	b.ne	752c <f37+0x2d8>  // b.any
    74fc:	29430002 	ldp	w2, w0, [x0, #24]
    7500:	92403c21 	and	x1, x1, #0xffff
    7504:	9b027c21 	mul	x1, x1, x2
    7508:	d360fc21 	lsr	x1, x1, #32
    750c:	eb00003f 	cmp	x1, x0
    7510:	540000e2 	b.cs	752c <f37+0x2d8>  // b.hs, b.nlast
    7514:	8b010294 	add	x20, x20, x1
    7518:	39400280 	ldrb	w0, [x20]
    751c:	7103fc1f 	cmp	w0, #0xff
    7520:	540007a0 	b.eq	7614 <f37+0x3c0>  // b.none
    7524:	52800020 	mov	w0, #0x1                   	// #1
    7528:	39000280 	strb	w0, [x20]
    752c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7530:	f947f400 	ldr	x0, [x0, #4072]
    7534:	f9400fe2 	ldr	x2, [sp, #24]
    7538:	f9400001 	ldr	x1, [x0]
    753c:	eb010042 	subs	x2, x2, x1
    7540:	d2800001 	mov	x1, #0x0                   	// #0
    7544:	54000721 	b.ne	7628 <f37+0x3d4>  // b.any
    7548:	a9427bfd 	ldp	x29, x30, [sp, #32]
    754c:	aa1303e0 	mov	x0, x19
    7550:	a94353f3 	ldp	x19, x20, [sp, #48]
    7554:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7558:	a94563f7 	ldp	x23, x24, [sp, #80]
    755c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7560:	910203ff 	add	sp, sp, #0x80
    7564:	d65f03c0 	ret
    7568:	d0000020 	adrp	x0, d000 <__divti3+0x240>
    756c:	91260000 	add	x0, x0, #0x980
    7570:	fd003be8 	str	d8, [sp, #112]
    7574:	97fff307 	bl	4190 <fwp_trap>
    7578:	72003c3f 	tst	w1, #0xffff
    757c:	54ffeca1 	b.ne	7310 <f37+0xbc>  // b.any
    7580:	17ffff5e 	b	72f8 <f37+0xa4>
    7584:	72003c3f 	tst	w1, #0xffff
    7588:	54fffd21 	b.ne	752c <f37+0x2d8>  // b.any
    758c:	17ffffe3 	b	7518 <f37+0x2c4>
    7590:	72003c3f 	tst	w1, #0xffff
    7594:	54fff301 	b.ne	73f4 <f37+0x1a0>  // b.any
    7598:	17ffff92 	b	73e0 <f37+0x18c>
    759c:	cb0103e1 	neg	x1, x1
    75a0:	eb02003f 	cmp	x1, x2
    75a4:	540001e3 	b.cc	75e0 <f37+0x38c>  // b.lo, b.ul, b.last
    75a8:	52800041 	mov	w1, #0x2                   	// #2
    75ac:	d2800100 	mov	x0, #0x8                   	// #8
    75b0:	97fff670 	bl	4f70 <fwp_heap_alloc>
    75b4:	aa0003f8 	mov	x24, x0
    75b8:	911742a0 	add	x0, x21, #0x5d0
    75bc:	f900031f 	str	xzr, [x24]
    75c0:	f949d801 	ldr	x1, [x0, #5040]
    75c4:	f949ec00 	ldr	x0, [x0, #5080]
    75c8:	cb010301 	sub	x1, x24, x1
    75cc:	eb00403f 	cmp	x1, x0, lsl #16
    75d0:	54000282 	b.cs	7620 <f37+0x3cc>  // b.hs, b.nlast
    75d4:	d2800013 	mov	x19, #0x0                   	// #0
    75d8:	d2800017 	mov	x23, #0x0                   	// #0
    75dc:	17ffff6d 	b	7390 <f37+0x13c>
    75e0:	f949fc62 	ldr	x2, [x3, #5112]
    75e4:	d350fc20 	lsr	x0, x1, #16
    75e8:	8b000800 	add	x0, x0, x0, lsl #2
    75ec:	8b000c42 	add	x2, x2, x0, lsl #3
    75f0:	f9401040 	ldr	x0, [x2, #32]
    75f4:	b4fffda0 	cbz	x0, 75a8 <f37+0x354>
    75f8:	d2800017 	mov	x23, #0x0                   	// #0
    75fc:	17ffff33 	b	72c8 <f37+0x74>
    7600:	97fff419 	bl	4664 <fwp_rc_wide_dup>
    7604:	17ffff43 	b	7310 <f37+0xbc>
    7608:	aa1403e0 	mov	x0, x20
    760c:	97fff301 	bl	4210 <fwp_rc_forget_slot.part.0>
    7610:	17ffff77 	b	73ec <f37+0x198>
    7614:	aa1403e0 	mov	x0, x20
    7618:	97fff2fe 	bl	4210 <fwp_rc_forget_slot.part.0>
    761c:	17ffffc2 	b	7524 <f37+0x2d0>
    7620:	d2800017 	mov	x23, #0x0                   	// #0
    7624:	17ffff86 	b	743c <f37+0x1e8>
    7628:	fd003be8 	str	d8, [sp, #112]
    762c:	97ffecb9 	bl	2910 <__stack_chk_fail@plt>

0000000000007630 <fwp_owned_entry37>:
    7630:	f9400000 	ldr	x0, [x0]
    7634:	17ffff08 	b	7254 <f37>
    7638:	d503201f 	nop
    763c:	d503201f 	nop

0000000000007640 <e37>:
    7640:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7644:	910003fd 	mov	x29, sp
    7648:	f9000bf3 	str	x19, [sp, #16]
    764c:	f9400013 	ldr	x19, [x0]
    7650:	aa1303e0 	mov	x0, x19
    7654:	97fff8fc 	bl	5a44 <fwp_rc_share>
    7658:	aa1303e0 	mov	x0, x19
    765c:	97fffefe 	bl	7254 <f37>
    7660:	aa0003f3 	mov	x19, x0
    7664:	97fff8f8 	bl	5a44 <fwp_rc_share>
    7668:	aa1303e0 	mov	x0, x19
    766c:	f9400bf3 	ldr	x19, [sp, #16]
    7670:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7674:	d65f03c0 	ret
    7678:	d503201f 	nop
    767c:	d503201f 	nop

0000000000007680 <fwp_write>:
    7680:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7684:	910003fd 	mov	x29, sp
    7688:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    768c:	f947f484 	ldr	x4, [x4, #4072]
    7690:	a90153f3 	stp	x19, x20, [sp, #16]
    7694:	d10943ff 	sub	sp, sp, #0x250
    7698:	b9400045 	ldr	w5, [x2]
    769c:	aa0003f4 	mov	x20, x0
    76a0:	f9400080 	ldr	x0, [x4]
    76a4:	f90127e0 	str	x0, [sp, #584]
    76a8:	d2800000 	mov	x0, #0x0                   	// #0
    76ac:	710064bf 	cmp	w5, #0x19
    76b0:	54000408 	b.hi	7730 <fwp_write+0xb0>  // b.pmore
    76b4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xb20>
    76b8:	aa0103f3 	mov	x19, x1
    76bc:	91094000 	add	x0, x0, #0x250
    76c0:	f9013bf5 	str	x21, [sp, #624]
    76c4:	f9013ff6 	str	x22, [sp, #632]
    76c8:	f90153fb 	str	x27, [sp, #672]
    76cc:	f90157fc 	str	x28, [sp, #680]
    76d0:	aa0203fc 	mov	x28, x2
    76d4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    76d8:	10000061 	adr	x1, 76e4 <fwp_write+0x64>
    76dc:	8b20a820 	add	x0, x1, w0, sxth #2
    76e0:	d61f0000 	br	x0
    76e4:	910123e0 	add	x0, sp, #0x48
    76e8:	aa1303e5 	mov	x5, x19
    76ec:	d0000024 	adrp	x4, d000 <__divti3+0x240>
    76f0:	aa0003f3 	mov	x19, x0
    76f4:	91272084 	add	x4, x4, #0x9c8
    76f8:	d2804003 	mov	x3, #0x200                 	// #512
    76fc:	aa0303e1 	mov	x1, x3
    7700:	52800042 	mov	w2, #0x2                   	// #2
    7704:	97ffec5f 	bl	2880 <__snprintf_chk@plt>
    7708:	aa1303e0 	mov	x0, x19
    770c:	97ffec25 	bl	27a0 <strlen@plt>
    7710:	aa1303e1 	mov	x1, x19
    7714:	aa0003e2 	mov	x2, x0
    7718:	aa1403e0 	mov	x0, x20
    771c:	97ffefbd 	bl	3610 <buf_put>
    7720:	f9413bf5 	ldr	x21, [sp, #624]
    7724:	f9413ff6 	ldr	x22, [sp, #632]
    7728:	f94153fb 	ldr	x27, [sp, #672]
    772c:	f94157fc 	ldr	x28, [sp, #680]
    7730:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7734:	f947f400 	ldr	x0, [x0, #4072]
    7738:	f94127e2 	ldr	x2, [sp, #584]
    773c:	f9400001 	ldr	x1, [x0]
    7740:	eb010042 	subs	x2, x2, x1
    7744:	d2800001 	mov	x1, #0x0                   	// #0
    7748:	540077c1 	b.ne	8640 <fwp_write+0xfc0>  // b.any
    774c:	910943ff 	add	sp, sp, #0x250
    7750:	a94153f3 	ldp	x19, x20, [sp, #16]
    7754:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7758:	d65f03c0 	ret
    775c:	910123e0 	add	x0, sp, #0x48
    7760:	aa1303e5 	mov	x5, x19
    7764:	d0000024 	adrp	x4, d000 <__divti3+0x240>
    7768:	aa0003f3 	mov	x19, x0
    776c:	91270084 	add	x4, x4, #0x9c0
    7770:	d2804003 	mov	x3, #0x200                 	// #512
    7774:	17ffffe2 	b	76fc <fwp_write+0x7c>
    7778:	71004cbf 	cmp	w5, #0x13
    777c:	d0000020 	adrp	x0, d000 <__divti3+0x240>
    7780:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7784:	9126c000 	add	x0, x0, #0x9b0
    7788:	9126e021 	add	x1, x1, #0x9b8
    778c:	d2800082 	mov	x2, #0x4                   	// #4
    7790:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7794:	aa1403e0 	mov	x0, x20
    7798:	f90143f7 	str	x23, [sp, #640]
    779c:	d2800016 	mov	x22, #0x0                   	// #0
    77a0:	f90147f8 	str	x24, [sp, #648]
    77a4:	97ffef9b 	bl	3610 <buf_put>
    77a8:	f9400260 	ldr	x0, [x19]
    77ac:	d0000037 	adrp	x23, d000 <__divti3+0x240>
    77b0:	d2800015 	mov	x21, #0x0                   	// #0
    77b4:	9128e2f7 	add	x23, x23, #0xa38
    77b8:	b40047a0 	cbz	x0, 80ac <fwp_write+0xa2c>
    77bc:	b9400380 	ldr	w0, [x28]
    77c0:	52800003 	mov	w3, #0x0                   	// #0
    77c4:	f9401f82 	ldr	x2, [x28, #56]
    77c8:	71004c1f 	cmp	w0, #0x13
    77cc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    77d0:	aa1403e0 	mov	x0, x20
    77d4:	8b010e61 	add	x1, x19, x1, lsl #3
    77d8:	f9400421 	ldr	x1, [x1, #8]
    77dc:	97ffffa9 	bl	7680 <fwp_write>
    77e0:	b9400380 	ldr	w0, [x28]
    77e4:	7100481f 	cmp	w0, #0x12
    77e8:	54004b40 	b.eq	8150 <fwp_write+0xad0>  // b.none
    77ec:	f9400260 	ldr	x0, [x19]
    77f0:	910006b5 	add	x21, x21, #0x1
    77f4:	91000ad6 	add	x22, x22, #0x2
    77f8:	eb15001f 	cmp	x0, x21
    77fc:	54004589 	b.ls	80ac <fwp_write+0xa2c>  // b.plast
    7800:	aa1703e1 	mov	x1, x23
    7804:	aa1403e0 	mov	x0, x20
    7808:	d2800042 	mov	x2, #0x2                   	// #2
    780c:	97ffef81 	bl	3610 <buf_put>
    7810:	17ffffeb 	b	77bc <fwp_write+0x13c>
    7814:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7818:	9127c021 	add	x1, x1, #0x9f0
    781c:	d28000c2 	mov	x2, #0x6                   	// #6
    7820:	aa1403e0 	mov	x0, x20
    7824:	91004273 	add	x19, x19, #0x10
    7828:	97ffef7a 	bl	3610 <buf_put>
    782c:	aa1303e0 	mov	x0, x19
    7830:	97ffebdc 	bl	27a0 <strlen@plt>
    7834:	aa1303e1 	mov	x1, x19
    7838:	aa0003e2 	mov	x2, x0
    783c:	aa1403e0 	mov	x0, x20
    7840:	97ffef74 	bl	3610 <buf_put>
    7844:	528007c3 	mov	w3, #0x3e                  	// #62
    7848:	aa1403e0 	mov	x0, x20
    784c:	91001fe1 	add	x1, sp, #0x7
    7850:	d2800022 	mov	x2, #0x1                   	// #1
    7854:	39001fe3 	strb	w3, [sp, #7]
    7858:	17ffffb1 	b	771c <fwp_write+0x9c>
    785c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7860:	f947f400 	ldr	x0, [x0, #4072]
    7864:	f94127e2 	ldr	x2, [sp, #584]
    7868:	f9400001 	ldr	x1, [x0]
    786c:	eb010042 	subs	x2, x2, x1
    7870:	d2800001 	mov	x1, #0x0                   	// #0
    7874:	540034e1 	b.ne	7f10 <fwp_write+0x890>  // b.any
    7878:	f9413bf5 	ldr	x21, [sp, #624]
    787c:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7880:	f9413ff6 	ldr	x22, [sp, #632]
    7884:	aa1403e0 	mov	x0, x20
    7888:	91274021 	add	x1, x1, #0x9d0
    788c:	d2800142 	mov	x2, #0xa                   	// #10
    7890:	f94153fb 	ldr	x27, [sp, #672]
    7894:	f94157fc 	ldr	x28, [sp, #680]
    7898:	910943ff 	add	sp, sp, #0x250
    789c:	a94153f3 	ldp	x19, x20, [sp, #16]
    78a0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    78a4:	17ffef5b 	b	3610 <buf_put>
    78a8:	f9400456 	ldr	x22, [x2, #8]
    78ac:	f90143f7 	str	x23, [sp, #640]
    78b0:	f90147f8 	str	x24, [sp, #648]
    78b4:	b4005b16 	cbz	x22, 8414 <fwp_write+0xd94>
    78b8:	aa1603e0 	mov	x0, x22
    78bc:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    78c0:	91294021 	add	x1, x1, #0xa50
    78c4:	97ffec33 	bl	2990 <strcmp@plt>
    78c8:	2a0003f5 	mov	w21, w0
    78cc:	34005fe0 	cbz	w0, 84c8 <fwp_write+0xe48>
    78d0:	aa1603e0 	mov	x0, x22
    78d4:	97ffebb3 	bl	27a0 <strlen@plt>
    78d8:	aa1603e1 	mov	x1, x22
    78dc:	aa0003e2 	mov	x2, x0
    78e0:	aa1403e0 	mov	x0, x20
    78e4:	97ffef4b 	bl	3610 <buf_put>
    78e8:	52800403 	mov	w3, #0x20                  	// #32
    78ec:	91001ff5 	add	x21, sp, #0x7
    78f0:	aa1503e1 	mov	x1, x21
    78f4:	aa1403e0 	mov	x0, x20
    78f8:	d2800022 	mov	x2, #0x1                   	// #1
    78fc:	39001fe3 	strb	w3, [sp, #7]
    7900:	97ffef44 	bl	3610 <buf_put>
    7904:	52800f63 	mov	w3, #0x7b                  	// #123
    7908:	aa1403e0 	mov	x0, x20
    790c:	aa1503e1 	mov	x1, x21
    7910:	d2800022 	mov	x2, #0x1                   	// #1
    7914:	39001fe3 	strb	w3, [sp, #7]
    7918:	97ffef3e 	bl	3610 <buf_put>
    791c:	b9401380 	ldr	w0, [x28, #16]
    7920:	52800018 	mov	w24, #0x0                   	// #0
    7924:	7100001f 	cmp	w0, #0x0
    7928:	54003aad 	b.le	807c <fwp_write+0x9fc>
    792c:	f9014bf9 	str	x25, [sp, #656]
    7930:	d0000039 	adrp	x25, d000 <__divti3+0x240>
    7934:	9129e339 	add	x25, x25, #0xa78
    7938:	f9014ffa 	str	x26, [sp, #664]
    793c:	d000003a 	adrp	x26, d000 <__divti3+0x240>
    7940:	9128e35a 	add	x26, x26, #0xa38
    7944:	91002276 	add	x22, x19, #0x8
    7948:	d2800013 	mov	x19, #0x0                   	// #0
    794c:	b5003e93 	cbnz	x19, 811c <fwp_write+0xa9c>
    7950:	d37df277 	lsl	x23, x19, #3
    7954:	34003cb8 	cbz	w24, 80e8 <fwp_write+0xa68>
    7958:	f9401382 	ldr	x2, [x28, #32]
    795c:	aa1403e0 	mov	x0, x20
    7960:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7964:	52800003 	mov	w3, #0x0                   	// #0
    7968:	f8776842 	ldr	x2, [x2, x23]
    796c:	91000673 	add	x19, x19, #0x1
    7970:	97ffff44 	bl	7680 <fwp_write>
    7974:	b9401380 	ldr	w0, [x28, #16]
    7978:	6b13001f 	cmp	w0, w19
    797c:	54fffe8c 	b.gt	794c <fwp_write+0x2cc>
    7980:	f9414bf9 	ldr	x25, [sp, #656]
    7984:	f9414ffa 	ldr	x26, [sp, #664]
    7988:	340037b8 	cbz	w24, 807c <fwp_write+0x9fc>
    798c:	52800523 	mov	w3, #0x29                  	// #41
    7990:	aa1503e1 	mov	x1, x21
    7994:	aa1403e0 	mov	x0, x20
    7998:	d2800022 	mov	x2, #0x1                   	// #1
    799c:	39001fe3 	strb	w3, [sp, #7]
    79a0:	97ffef1c 	bl	3610 <buf_put>
    79a4:	f9413bf5 	ldr	x21, [sp, #624]
    79a8:	f9413ff6 	ldr	x22, [sp, #632]
    79ac:	f94143f7 	ldr	x23, [sp, #640]
    79b0:	f94147f8 	ldr	x24, [sp, #648]
    79b4:	f94153fb 	ldr	x27, [sp, #672]
    79b8:	f94157fc 	ldr	x28, [sp, #680]
    79bc:	17ffff5d 	b	7730 <fwp_write+0xb0>
    79c0:	b9404855 	ldr	w21, [x2, #72]
    79c4:	aa1403e0 	mov	x0, x20
    79c8:	93407eb6 	sxtw	x22, w21
    79cc:	91000ac1 	add	x1, x22, #0x2
    79d0:	97ffeedd 	bl	3544 <buf_grow>
    79d4:	a9400281 	ldp	x1, x0, [x20]
    79d8:	528e8603 	mov	w3, #0x7430                	// #29744
    79dc:	78206823 	strh	w3, [x1, x0]
    79e0:	8b000022 	add	x2, x1, x0
    79e4:	710002bf 	cmp	w21, #0x0
    79e8:	540036cd 	b.le	80c0 <fwp_write+0xa40>
    79ec:	110006a3 	add	w3, w21, #0x1
    79f0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    79f4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    79f8:	91000449 	add	x9, x2, #0x1
    79fc:	8b23c043 	add	x3, x2, w3, sxtw
    7a00:	f28aaac6 	movk	x6, #0x5556
    7a04:	f2955568 	movk	x8, #0xaaab
    7a08:	1400000d 	b	7a3c <fwp_write+0x3bc>
    7a0c:	d2800021 	mov	x1, #0x1                   	// #1
    7a10:	528005a5 	mov	w5, #0x2d                  	// #45
    7a14:	f100001f 	cmp	x0, #0x0
    7a18:	9b467e60 	smulh	x0, x19, x6
    7a1c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7a20:	381ff465 	strb	w5, [x3], #-1
    7a24:	cb040000 	sub	x0, x0, x4
    7a28:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7a2c:	cb020000 	sub	x0, x0, x2
    7a30:	8b010013 	add	x19, x0, x1
    7a34:	eb03013f 	cmp	x9, x3
    7a38:	54003440 	b.eq	80c0 <fwp_write+0xa40>  // b.none
    7a3c:	9b467e60 	smulh	x0, x19, x6
    7a40:	937ffe64 	asr	x4, x19, #63
    7a44:	52800605 	mov	w5, #0x30                  	// #48
    7a48:	cb040000 	sub	x0, x0, x4
    7a4c:	8b000400 	add	x0, x0, x0, lsl #1
    7a50:	cb000260 	sub	x0, x19, x0
    7a54:	91000c01 	add	x1, x0, #0x3
    7a58:	9bc87c22 	umulh	x2, x1, x8
    7a5c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7a60:	8b4204e2 	add	x2, x7, x2, lsr #1
    7a64:	eb020021 	subs	x1, x1, x2
    7a68:	54fffd60 	b.eq	7a14 <fwp_write+0x394>  // b.none
    7a6c:	f100043f 	cmp	x1, #0x1
    7a70:	54fffce1 	b.ne	7a0c <fwp_write+0x38c>  // b.any
    7a74:	d2800001 	mov	x1, #0x0                   	// #0
    7a78:	52800565 	mov	w5, #0x2b                  	// #43
    7a7c:	17ffffe6 	b	7a14 <fwp_write+0x394>
    7a80:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7a84:	f947f400 	ldr	x0, [x0, #4072]
    7a88:	f94127e2 	ldr	x2, [sp, #584]
    7a8c:	f9400001 	ldr	x1, [x0]
    7a90:	eb010042 	subs	x2, x2, x1
    7a94:	d2800001 	mov	x1, #0x0                   	// #0
    7a98:	540023c1 	b.ne	7f10 <fwp_write+0x890>  // b.any
    7a9c:	f9413bf5 	ldr	x21, [sp, #624]
    7aa0:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7aa4:	f9413ff6 	ldr	x22, [sp, #632]
    7aa8:	aa1403e0 	mov	x0, x20
    7aac:	91278021 	add	x1, x1, #0x9e0
    7ab0:	d2800102 	mov	x2, #0x8                   	// #8
    7ab4:	17ffff77 	b	7890 <fwp_write+0x210>
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7ac0:	d28000c2 	mov	x2, #0x6                   	// #6
    7ac4:	91290021 	add	x1, x1, #0xa40
    7ac8:	97ffeed2 	bl	3610 <buf_put>
    7acc:	d2800015 	mov	x21, #0x0                   	// #0
    7ad0:	f9400263 	ldr	x3, [x19]
    7ad4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7ad8:	54002c60 	b.eq	8064 <fwp_write+0x9e4>  // b.none
    7adc:	f9401f82 	ldr	x2, [x28, #56]
    7ae0:	f90143f7 	str	x23, [sp, #640]
    7ae4:	f90147f8 	str	x24, [sp, #648]
    7ae8:	d2800857 	mov	x23, #0x42                  	// #66
    7aec:	f9014bf9 	str	x25, [sp, #656]
    7af0:	d0000036 	adrp	x22, d000 <__divti3+0x240>
    7af4:	f9014ffa 	str	x26, [sp, #664]
    7af8:	9128e2d6 	add	x22, x22, #0xa38
    7afc:	d2800038 	mov	x24, #0x1                   	// #1
    7b00:	f2a18017 	movk	x23, #0xc00, lsl #16
    7b04:	d2809099 	mov	x25, #0x484                 	// #1156
    7b08:	b40004a2 	cbz	x2, 7b9c <fwp_write+0x51c>
    7b0c:	b9400040 	ldr	w0, [x2]
    7b10:	7100701f 	cmp	w0, #0x1c
    7b14:	540042c0 	b.eq	836c <fwp_write+0xcec>  // b.none
    7b18:	71006c1f 	cmp	w0, #0x1b
    7b1c:	54000408 	b.hi	7b9c <fwp_write+0x51c>  // b.pmore
    7b20:	9ac02301 	lsl	x1, x24, x0
    7b24:	ea17003f 	tst	x1, x23
    7b28:	540036a1 	b.ne	81fc <fwp_write+0xb7c>  // b.any
    7b2c:	ea19003f 	tst	x1, x25
    7b30:	54003521 	b.ne	81d4 <fwp_write+0xb54>  // b.any
    7b34:	d2800424 	mov	x4, #0x21                  	// #33
    7b38:	ea04003f 	tst	x1, x4
    7b3c:	54000300 	b.eq	7b9c <fwp_write+0x51c>  // b.none
    7b40:	b7f849c3 	tbnz	x3, #63, 8478 <fwp_write+0xdf8>
    7b44:	91002261 	add	x1, x19, #0x8
    7b48:	8b150021 	add	x1, x1, x21
    7b4c:	39400021 	ldrb	w1, [x1]
    7b50:	7100001f 	cmp	w0, #0x0
    7b54:	93401c23 	sxtb	x3, w1
    7b58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7b5c:	d503201f 	nop
    7b60:	aa1403e0 	mov	x0, x20
    7b64:	52800003 	mov	w3, #0x0                   	// #0
    7b68:	97fffec6 	bl	7680 <fwp_write>
    7b6c:	910006b5 	add	x21, x21, #0x1
    7b70:	f9400260 	ldr	x0, [x19]
    7b74:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7b78:	eb0002bf 	cmp	x21, x0
    7b7c:	540026c2 	b.cs	8054 <fwp_write+0x9d4>  // b.hs, b.nlast
    7b80:	d2800042 	mov	x2, #0x2                   	// #2
    7b84:	aa1603e1 	mov	x1, x22
    7b88:	aa1403e0 	mov	x0, x20
    7b8c:	97ffeea1 	bl	3610 <buf_put>
    7b90:	f9401f82 	ldr	x2, [x28, #56]
    7b94:	f9400263 	ldr	x3, [x19]
    7b98:	b5fffba2 	cbnz	x2, 7b0c <fwp_write+0x48c>
    7b9c:	d37df2a0 	lsl	x0, x21, #3
    7ba0:	b7f83f03 	tbnz	x3, #63, 8380 <fwp_write+0xd00>
    7ba4:	91002261 	add	x1, x19, #0x8
    7ba8:	8b000020 	add	x0, x1, x0
    7bac:	f9400001 	ldr	x1, [x0]
    7bb0:	17ffffec 	b	7b60 <fwp_write+0x4e0>
    7bb4:	a9400e62 	ldp	x2, x3, [x19]
    7bb8:	b7f83ca3 	tbnz	x3, #63, 834c <fwp_write+0xccc>
    7bbc:	910123f5 	add	x21, sp, #0x48
    7bc0:	aa1503e0 	mov	x0, x21
    7bc4:	97ffecb7 	bl	2ea0 <fwp_fmt_u128>
    7bc8:	aa1503e0 	mov	x0, x21
    7bcc:	97ffeaf5 	bl	27a0 <strlen@plt>
    7bd0:	aa1503e1 	mov	x1, x21
    7bd4:	aa0003e2 	mov	x2, x0
    7bd8:	17fffed0 	b	7718 <fwp_write+0x98>
    7bdc:	fd015be8 	str	d8, [sp, #688]
    7be0:	1e270268 	fmov	s8, w19
    7be4:	fd015fe9 	str	d9, [sp, #696]
    7be8:	1e282100 	fcmp	s8, s8
    7bec:	54004d26 	b.vs	8590 <fwp_write+0xf10>
    7bf0:	1e20c101 	fabs	s1, s8
    7bf4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7bf8:	1e270000 	fmov	s0, w0
    7bfc:	1e202020 	fcmp	s1, s0
    7c00:	54002c0d 	b.le	8180 <fwp_write+0xb00>
    7c04:	1e202118 	fcmpe	s8, #0.0
    7c08:	d0000022 	adrp	x2, d000 <__divti3+0x240>
    7c0c:	9116e042 	add	x2, x2, #0x5b8
    7c10:	910123f5 	add	x21, sp, #0x48
    7c14:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7c18:	91264021 	add	x1, x1, #0x990
    7c1c:	aa1503e0 	mov	x0, x21
    7c20:	9a81c041 	csel	x1, x2, x1, gt
    7c24:	97ffeb8b 	bl	2a50 <strcpy@plt>
    7c28:	aa1503e0 	mov	x0, x21
    7c2c:	97ffeadd 	bl	27a0 <strlen@plt>
    7c30:	aa1503e1 	mov	x1, x21
    7c34:	aa0003e2 	mov	x2, x0
    7c38:	aa1403e0 	mov	x0, x20
    7c3c:	97ffee75 	bl	3610 <buf_put>
    7c40:	f9413bf5 	ldr	x21, [sp, #624]
    7c44:	f9413ff6 	ldr	x22, [sp, #632]
    7c48:	f94153fb 	ldr	x27, [sp, #672]
    7c4c:	f94157fc 	ldr	x28, [sp, #680]
    7c50:	fd415be8 	ldr	d8, [sp, #688]
    7c54:	fd415fe9 	ldr	d9, [sp, #696]
    7c58:	17fffeb6 	b	7730 <fwp_write+0xb0>
    7c5c:	f9400276 	ldr	x22, [x19]
    7c60:	34002e03 	cbz	w3, 8220 <fwp_write+0xba0>
    7c64:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7c68:	f947f400 	ldr	x0, [x0, #4072]
    7c6c:	f94127e2 	ldr	x2, [sp, #584]
    7c70:	f9400001 	ldr	x1, [x0]
    7c74:	eb010042 	subs	x2, x2, x1
    7c78:	d2800001 	mov	x1, #0x0                   	// #0
    7c7c:	540014a1 	b.ne	7f10 <fwp_write+0x890>  // b.any
    7c80:	aa1603e2 	mov	x2, x22
    7c84:	91002261 	add	x1, x19, #0x8
    7c88:	f9413bf5 	ldr	x21, [sp, #624]
    7c8c:	aa1403e0 	mov	x0, x20
    7c90:	f9413ff6 	ldr	x22, [sp, #632]
    7c94:	17fffeff 	b	7890 <fwp_write+0x210>
    7c98:	fd015be8 	str	d8, [sp, #688]
    7c9c:	9e670268 	fmov	d8, x19
    7ca0:	fd015fe9 	str	d9, [sp, #696]
    7ca4:	1e682100 	fcmp	d8, d8
    7ca8:	54004746 	b.vs	8590 <fwp_write+0xf10>
    7cac:	1e60c101 	fabs	d1, d8
    7cb0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7cb4:	9e670000 	fmov	d0, x0
    7cb8:	910123f5 	add	x21, sp, #0x48
    7cbc:	52800033 	mov	w19, #0x1                   	// #1
    7cc0:	1e602020 	fcmp	d1, d0
    7cc4:	540001ad 	b.le	7cf8 <fwp_write+0x678>
    7cc8:	1e602118 	fcmpe	d8, #0.0
    7ccc:	d0000022 	adrp	x2, d000 <__divti3+0x240>
    7cd0:	9116e042 	add	x2, x2, #0x5b8
    7cd4:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7cd8:	91264021 	add	x1, x1, #0x990
    7cdc:	aa1503e0 	mov	x0, x21
    7ce0:	9a81c041 	csel	x1, x2, x1, gt
    7ce4:	97ffeb5b 	bl	2a50 <strcpy@plt>
    7ce8:	17ffffd0 	b	7c28 <fwp_write+0x5a8>
    7cec:	11000673 	add	w19, w19, #0x1
    7cf0:	71004a7f 	cmp	w19, #0x12
    7cf4:	54003860 	b.eq	8400 <fwp_write+0xd80>  // b.none
    7cf8:	1e604100 	fmov	d0, d8
    7cfc:	2a1303e1 	mov	w1, w19
    7d00:	aa1503e0 	mov	x0, x21
    7d04:	97ffeedf 	bl	3880 <fwp_format_g.constprop.0>
    7d08:	aa1503e0 	mov	x0, x21
    7d0c:	d2800001 	mov	x1, #0x0                   	// #0
    7d10:	97ffeab8 	bl	27f0 <strtod@plt>
    7d14:	1e602100 	fcmp	d8, d0
    7d18:	54fffea1 	b.ne	7cec <fwp_write+0x66c>  // b.any
    7d1c:	aa1503e0 	mov	x0, x21
    7d20:	97ffeeb5 	bl	37f4 <fwp_finish_float>
    7d24:	17ffffc1 	b	7c28 <fwp_write+0x5a8>
    7d28:	a9400e62 	ldp	x2, x3, [x19]
    7d2c:	910123f3 	add	x19, sp, #0x48
    7d30:	aa1303e0 	mov	x0, x19
    7d34:	97ffec5b 	bl	2ea0 <fwp_fmt_u128>
    7d38:	17fffe74 	b	7708 <fwp_write+0x88>
    7d3c:	f90143f7 	str	x23, [sp, #640]
    7d40:	f90147f8 	str	x24, [sp, #648]
    7d44:	2a1303f8 	mov	w24, w19
    7d48:	f9014bf9 	str	x25, [sp, #656]
    7d4c:	f9014ffa 	str	x26, [sp, #664]
    7d50:	f13ffe7f 	cmp	x19, #0xfff
    7d54:	54000049 	b.ls	7d5c <fwp_write+0x6dc>  // b.plast
    7d58:	b9400278 	ldr	w24, [x19]
    7d5c:	f9400f80 	ldr	x0, [x28, #24]
    7d60:	2a1803f5 	mov	w21, w24
    7d64:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7d68:	d37ef6b9 	lsl	x25, x21, #2
    7d6c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7d70:	aa1603e0 	mov	x0, x22
    7d74:	97ffea8b 	bl	27a0 <strlen@plt>
    7d78:	aa1603e1 	mov	x1, x22
    7d7c:	aa0003e2 	mov	x2, x0
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	97ffee23 	bl	3610 <buf_put>
    7d88:	f9401780 	ldr	x0, [x28, #40]
    7d8c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7d90:	7100001f 	cmp	w0, #0x0
    7d94:	5400068d 	b.le	7e64 <fwp_write+0x7e4>
    7d98:	91002276 	add	x22, x19, #0x8
    7d9c:	91001ff5 	add	x21, sp, #0x7
    7da0:	d280001b 	mov	x27, #0x0                   	// #0
    7da4:	5280041a 	mov	w26, #0x20                  	// #32
    7da8:	f9401b80 	ldr	x0, [x28, #48]
    7dac:	aa1503e1 	mov	x1, x21
    7db0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7db4:	d2800022 	mov	x2, #0x1                   	// #1
    7db8:	f8786803 	ldr	x3, [x0, x24]
    7dbc:	aa1403e0 	mov	x0, x20
    7dc0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7dc4:	39001ffa 	strb	w26, [sp, #7]
    7dc8:	97ffee12 	bl	3610 <buf_put>
    7dcc:	f13ffeff 	cmp	x23, #0xfff
    7dd0:	b9400261 	ldr	w1, [x19]
    7dd4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7dd8:	7100383f 	cmp	w1, #0xe
    7ddc:	54000160 	b.eq	7e08 <fwp_write+0x788>  // b.none
    7de0:	7100403f 	cmp	w1, #0x10
    7de4:	54001a60 	b.eq	8130 <fwp_write+0xab0>  // b.none
    7de8:	7100283f 	cmp	w1, #0xa
    7dec:	54002aa0 	b.eq	8340 <fwp_write+0xcc0>  // b.none
    7df0:	540014ac 	b.gt	8084 <fwp_write+0xa04>
    7df4:	71000c3f 	cmp	w1, #0x3
    7df8:	540029ac 	b.gt	832c <fwp_write+0xcac>
    7dfc:	d37ffee0 	lsr	x0, x23, #63
    7e00:	37f814a1 	tbnz	w1, #31, 8094 <fwp_write+0xa14>
    7e04:	d503201f 	nop
    7e08:	34001460 	cbz	w0, 8094 <fwp_write+0xa14>
    7e0c:	52800503 	mov	w3, #0x28                  	// #40
    7e10:	aa1503e1 	mov	x1, x21
    7e14:	aa1403e0 	mov	x0, x20
    7e18:	d2800022 	mov	x2, #0x1                   	// #1
    7e1c:	39001fe3 	strb	w3, [sp, #7]
    7e20:	97ffedfc 	bl	3610 <buf_put>
    7e24:	aa1303e2 	mov	x2, x19
    7e28:	aa1703e1 	mov	x1, x23
    7e2c:	aa1403e0 	mov	x0, x20
    7e30:	52800003 	mov	w3, #0x0                   	// #0
    7e34:	97fffe13 	bl	7680 <fwp_write>
    7e38:	52800523 	mov	w3, #0x29                  	// #41
    7e3c:	aa1503e1 	mov	x1, x21
    7e40:	aa1403e0 	mov	x0, x20
    7e44:	d2800022 	mov	x2, #0x1                   	// #1
    7e48:	39001fe3 	strb	w3, [sp, #7]
    7e4c:	97ffedf1 	bl	3610 <buf_put>
    7e50:	f9401780 	ldr	x0, [x28, #40]
    7e54:	9100077b 	add	x27, x27, #0x1
    7e58:	b8796800 	ldr	w0, [x0, x25]
    7e5c:	6b1b001f 	cmp	w0, w27
    7e60:	54fffa4c 	b.gt	7da8 <fwp_write+0x728>
    7e64:	f9413bf5 	ldr	x21, [sp, #624]
    7e68:	f9413ff6 	ldr	x22, [sp, #632]
    7e6c:	f94143f7 	ldr	x23, [sp, #640]
    7e70:	f94147f8 	ldr	x24, [sp, #648]
    7e74:	f9414bf9 	ldr	x25, [sp, #656]
    7e78:	f9414ffa 	ldr	x26, [sp, #664]
    7e7c:	f94153fb 	ldr	x27, [sp, #672]
    7e80:	f94157fc 	ldr	x28, [sp, #680]
    7e84:	17fffe2b 	b	7730 <fwp_write+0xb0>
    7e88:	52800783 	mov	w3, #0x3c                  	// #60
    7e8c:	91001ff3 	add	x19, sp, #0x7
    7e90:	aa1303e1 	mov	x1, x19
    7e94:	d2800022 	mov	x2, #0x1                   	// #1
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	39001fe3 	strb	w3, [sp, #7]
    7ea0:	97ffeddc 	bl	3610 <buf_put>
    7ea4:	f9400795 	ldr	x21, [x28, #8]
    7ea8:	aa1503e0 	mov	x0, x21
    7eac:	97ffea3d 	bl	27a0 <strlen@plt>
    7eb0:	aa1503e1 	mov	x1, x21
    7eb4:	aa0003e2 	mov	x2, x0
    7eb8:	aa1403e0 	mov	x0, x20
    7ebc:	97ffedd5 	bl	3610 <buf_put>
    7ec0:	528007c3 	mov	w3, #0x3e                  	// #62
    7ec4:	aa1303e1 	mov	x1, x19
    7ec8:	aa1403e0 	mov	x0, x20
    7ecc:	d2800022 	mov	x2, #0x1                   	// #1
    7ed0:	39001fe3 	strb	w3, [sp, #7]
    7ed4:	17fffe12 	b	771c <fwp_write+0x9c>
    7ed8:	f100067f 	cmp	x19, #0x1
    7edc:	540025a0 	b.eq	8390 <fwp_write+0xd10>  // b.none
    7ee0:	b100067f 	cmn	x19, #0x1
    7ee4:	54002bc0 	b.eq	845c <fwp_write+0xddc>  // b.none
    7ee8:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7eec:	91266021 	add	x1, x1, #0x998
    7ef0:	d2800022 	mov	x2, #0x1                   	// #1
    7ef4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ef8:	f947f400 	ldr	x0, [x0, #4072]
    7efc:	f94127e4 	ldr	x4, [sp, #584]
    7f00:	f9400003 	ldr	x3, [x0]
    7f04:	eb030084 	subs	x4, x4, x3
    7f08:	d2800003 	mov	x3, #0x0                   	// #0
    7f0c:	54ffebe0 	b.eq	7c88 <fwp_write+0x608>  // b.none
    7f10:	f90143f7 	str	x23, [sp, #640]
    7f14:	f90147f8 	str	x24, [sp, #648]
    7f18:	f9014bf9 	str	x25, [sp, #656]
    7f1c:	f9014ffa 	str	x26, [sp, #664]
    7f20:	fd015be8 	str	d8, [sp, #688]
    7f24:	fd015fe9 	str	d9, [sp, #696]
    7f28:	97ffea7a 	bl	2910 <__stack_chk_fail@plt>
    7f2c:	52800b63 	mov	w3, #0x5b                  	// #91
    7f30:	91001ff5 	add	x21, sp, #0x7
    7f34:	aa1503e1 	mov	x1, x21
    7f38:	aa1403e0 	mov	x0, x20
    7f3c:	d2800022 	mov	x2, #0x1                   	// #1
    7f40:	d0000036 	adrp	x22, d000 <__divti3+0x240>
    7f44:	9128e2d6 	add	x22, x22, #0xa38
    7f48:	39001fe3 	strb	w3, [sp, #7]
    7f4c:	97ffedb1 	bl	3610 <buf_put>
    7f50:	b4000273 	cbz	x19, 7f9c <fwp_write+0x91c>
    7f54:	f9400661 	ldr	x1, [x19, #8]
    7f58:	aa1403e0 	mov	x0, x20
    7f5c:	f9401f82 	ldr	x2, [x28, #56]
    7f60:	52800003 	mov	w3, #0x0                   	// #0
    7f64:	97fffdc7 	bl	7680 <fwp_write>
    7f68:	f9400a73 	ldr	x19, [x19, #16]
    7f6c:	b4000193 	cbz	x19, 7f9c <fwp_write+0x91c>
    7f70:	aa1603e1 	mov	x1, x22
    7f74:	aa1403e0 	mov	x0, x20
    7f78:	d2800042 	mov	x2, #0x2                   	// #2
    7f7c:	97ffeda5 	bl	3610 <buf_put>
    7f80:	f9400661 	ldr	x1, [x19, #8]
    7f84:	aa1403e0 	mov	x0, x20
    7f88:	f9401f82 	ldr	x2, [x28, #56]
    7f8c:	52800003 	mov	w3, #0x0                   	// #0
    7f90:	97fffdbc 	bl	7680 <fwp_write>
    7f94:	f9400a73 	ldr	x19, [x19, #16]
    7f98:	b5fffed3 	cbnz	x19, 7f70 <fwp_write+0x8f0>
    7f9c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7fa0:	aa1503e1 	mov	x1, x21
    7fa4:	aa1403e0 	mov	x0, x20
    7fa8:	d2800022 	mov	x2, #0x1                   	// #1
    7fac:	39001fe3 	strb	w3, [sp, #7]
    7fb0:	17fffddb 	b	771c <fwp_write+0x9c>
    7fb4:	aa1403e0 	mov	x0, x20
    7fb8:	d0000021 	adrp	x1, d000 <__divti3+0x240>
    7fbc:	d28000c2 	mov	x2, #0x6                   	// #6
    7fc0:	9128a021 	add	x1, x1, #0xa28
    7fc4:	97ffed93 	bl	3610 <buf_put>
    7fc8:	f9400260 	ldr	x0, [x19]
    7fcc:	b40004c0 	cbz	x0, 8064 <fwp_write+0x9e4>
    7fd0:	910123f5 	add	x21, sp, #0x48
    7fd4:	91002276 	add	x22, x19, #0x8
    7fd8:	f90143f7 	str	x23, [sp, #640]
    7fdc:	d2800017 	mov	x23, #0x0                   	// #0
    7fe0:	f90147f8 	str	x24, [sp, #648]
    7fe4:	d0000038 	adrp	x24, d000 <__divti3+0x240>
    7fe8:	9128c318 	add	x24, x24, #0xa30
    7fec:	f9014bf9 	str	x25, [sp, #656]
    7ff0:	d0000039 	adrp	x25, d000 <__divti3+0x240>
    7ff4:	9128e339 	add	x25, x25, #0xa38
    7ff8:	f9014ffa 	str	x26, [sp, #664]
    7ffc:	14000005 	b	8010 <fwp_write+0x990>
    8000:	aa1903e1 	mov	x1, x25
    8004:	aa1403e0 	mov	x0, x20
    8008:	d2800042 	mov	x2, #0x2                   	// #2
    800c:	97ffed81 	bl	3610 <buf_put>
    8010:	38776ac5 	ldrb	w5, [x22, x23]
    8014:	d2804003 	mov	x3, #0x200                 	// #512
    8018:	aa1803e4 	mov	x4, x24
    801c:	aa0303e1 	mov	x1, x3
    8020:	52800042 	mov	w2, #0x2                   	// #2
    8024:	aa1503e0 	mov	x0, x21
    8028:	910006f7 	add	x23, x23, #0x1
    802c:	97ffea15 	bl	2880 <__snprintf_chk@plt>
    8030:	aa1503e0 	mov	x0, x21
    8034:	97ffe9db 	bl	27a0 <strlen@plt>
    8038:	aa1503e1 	mov	x1, x21
    803c:	aa0003e2 	mov	x2, x0
    8040:	aa1403e0 	mov	x0, x20
    8044:	97ffed73 	bl	3610 <buf_put>
    8048:	f9400260 	ldr	x0, [x19]
    804c:	eb17001f 	cmp	x0, x23
    8050:	54fffd88 	b.hi	8000 <fwp_write+0x980>  // b.pmore
    8054:	f94143f7 	ldr	x23, [sp, #640]
    8058:	f94147f8 	ldr	x24, [sp, #648]
    805c:	f9414bf9 	ldr	x25, [sp, #656]
    8060:	f9414ffa 	ldr	x26, [sp, #664]
    8064:	52800ba3 	mov	w3, #0x5d                  	// #93
    8068:	aa1403e0 	mov	x0, x20
    806c:	91001fe1 	add	x1, sp, #0x7
    8070:	d2800022 	mov	x2, #0x1                   	// #1
    8074:	39001fe3 	strb	w3, [sp, #7]
    8078:	17fffda9 	b	771c <fwp_write+0x9c>
    807c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8080:	17fffe44 	b	7990 <fwp_write+0x310>
    8084:	f10002ff 	cmp	x23, #0x0
    8088:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    808c:	71002c3f 	cmp	w1, #0xb
    8090:	54ffebc0 	b.eq	7e08 <fwp_write+0x788>  // b.none
    8094:	aa1303e2 	mov	x2, x19
    8098:	aa1703e1 	mov	x1, x23
    809c:	aa1403e0 	mov	x0, x20
    80a0:	52800003 	mov	w3, #0x0                   	// #0
    80a4:	97fffd77 	bl	7680 <fwp_write>
    80a8:	17ffff6a 	b	7e50 <fwp_write+0x7d0>
    80ac:	aa1403e0 	mov	x0, x20
    80b0:	91001fe1 	add	x1, sp, #0x7
    80b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    80b8:	d2800022 	mov	x2, #0x1                   	// #1
    80bc:	17fffe38 	b	799c <fwp_write+0x31c>
    80c0:	a9400281 	ldp	x1, x0, [x20]
    80c4:	91000800 	add	x0, x0, #0x2
    80c8:	8b160000 	add	x0, x0, x22
    80cc:	f9000680 	str	x0, [x20, #8]
    80d0:	3820683f 	strb	wzr, [x1, x0]
    80d4:	f9413bf5 	ldr	x21, [sp, #624]
    80d8:	f9413ff6 	ldr	x22, [sp, #632]
    80dc:	f94153fb 	ldr	x27, [sp, #672]
    80e0:	f94157fc 	ldr	x28, [sp, #680]
    80e4:	17fffd93 	b	7730 <fwp_write+0xb0>
    80e8:	f9400f80 	ldr	x0, [x28, #24]
    80ec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    80f0:	aa1b03e0 	mov	x0, x27
    80f4:	97ffe9ab 	bl	27a0 <strlen@plt>
    80f8:	aa1b03e1 	mov	x1, x27
    80fc:	aa0003e2 	mov	x2, x0
    8100:	aa1403e0 	mov	x0, x20
    8104:	97ffed43 	bl	3610 <buf_put>
    8108:	aa1903e1 	mov	x1, x25
    810c:	aa1403e0 	mov	x0, x20
    8110:	d2800062 	mov	x2, #0x3                   	// #3
    8114:	97ffed3f 	bl	3610 <buf_put>
    8118:	17fffe10 	b	7958 <fwp_write+0x2d8>
    811c:	aa1a03e1 	mov	x1, x26
    8120:	aa1403e0 	mov	x0, x20
    8124:	d2800042 	mov	x2, #0x2                   	// #2
    8128:	97ffed3a 	bl	3610 <buf_put>
    812c:	17fffe09 	b	7950 <fwp_write+0x2d0>
    8130:	f9400660 	ldr	x0, [x19, #8]
    8134:	b4fffb00 	cbz	x0, 8094 <fwp_write+0xa14>
    8138:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    813c:	91294021 	add	x1, x1, #0xa50
    8140:	97ffea14 	bl	2990 <strcmp@plt>
    8144:	7100001f 	cmp	w0, #0x0
    8148:	1a9f07e0 	cset	w0, ne	// ne = any
    814c:	17ffff2f 	b	7e08 <fwp_write+0x788>
    8150:	aa1403e0 	mov	x0, x20
    8154:	d2800042 	mov	x2, #0x2                   	// #2
    8158:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    815c:	91292021 	add	x1, x1, #0xa48
    8160:	97ffed2c 	bl	3610 <buf_put>
    8164:	91004261 	add	x1, x19, #0x10
    8168:	aa1403e0 	mov	x0, x20
    816c:	f9402382 	ldr	x2, [x28, #64]
    8170:	52800003 	mov	w3, #0x0                   	// #0
    8174:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8178:	97fffd42 	bl	7680 <fwp_write>
    817c:	17fffd9c 	b	77ec <fwp_write+0x16c>
    8180:	1e22c109 	fcvt	d9, s8
    8184:	910123f5 	add	x21, sp, #0x48
    8188:	52800033 	mov	w19, #0x1                   	// #1
    818c:	d503201f 	nop
    8190:	1e604120 	fmov	d0, d9
    8194:	2a1303e1 	mov	w1, w19
    8198:	aa1503e0 	mov	x0, x21
    819c:	97ffedb9 	bl	3880 <fwp_format_g.constprop.0>
    81a0:	aa1503e0 	mov	x0, x21
    81a4:	d2800001 	mov	x1, #0x0                   	// #0
    81a8:	97ffea06 	bl	29c0 <strtof@plt>
    81ac:	1e202100 	fcmp	s8, s0
    81b0:	54ffdb60 	b.eq	7d1c <fwp_write+0x69c>  // b.none
    81b4:	11000673 	add	w19, w19, #0x1
    81b8:	71002a7f 	cmp	w19, #0xa
    81bc:	54fffea1 	b.ne	8190 <fwp_write+0xb10>  // b.any
    81c0:	1e604120 	fmov	d0, d9
    81c4:	aa1503e0 	mov	x0, x21
    81c8:	52800121 	mov	w1, #0x9                   	// #9
    81cc:	97ffedad 	bl	3880 <fwp_format_g.constprop.0>
    81d0:	17fffed3 	b	7d1c <fwp_write+0x69c>
    81d4:	d37ef6a1 	lsl	x1, x21, #2
    81d8:	b7f81563 	tbnz	x3, #63, 8484 <fwp_write+0xe04>
    81dc:	91002263 	add	x3, x19, #0x8
    81e0:	8b010061 	add	x1, x3, x1
    81e4:	b9400023 	ldr	w3, [x1]
    81e8:	7100081f 	cmp	w0, #0x2
    81ec:	2a0303e1 	mov	w1, w3
    81f0:	93407c63 	sxtw	x3, w3
    81f4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    81f8:	17fffe5a 	b	7b60 <fwp_write+0x4e0>
    81fc:	d37ffaa1 	lsl	x1, x21, #1
    8200:	b7f81363 	tbnz	x3, #63, 846c <fwp_write+0xdec>
    8204:	91002263 	add	x3, x19, #0x8
    8208:	8b010061 	add	x1, x3, x1
    820c:	79400021 	ldrh	w1, [x1]
    8210:	7100041f 	cmp	w0, #0x1
    8214:	93403c23 	sxth	x3, w1
    8218:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    821c:	17fffe51 	b	7b60 <fwp_write+0x4e0>
    8220:	52800443 	mov	w3, #0x22                  	// #34
    8224:	91001ff5 	add	x21, sp, #0x7
    8228:	91002273 	add	x19, x19, #0x8
    822c:	aa1503e1 	mov	x1, x21
    8230:	aa1403e0 	mov	x0, x20
    8234:	d2800022 	mov	x2, #0x1                   	// #1
    8238:	39001fe3 	strb	w3, [sp, #7]
    823c:	f90143f7 	str	x23, [sp, #640]
    8240:	8b160277 	add	x23, x19, x22
    8244:	f90147f8 	str	x24, [sp, #648]
    8248:	97ffecf2 	bl	3610 <buf_put>
    824c:	b4000696 	cbz	x22, 831c <fwp_write+0xc9c>
    8250:	b0000038 	adrp	x24, d000 <__divti3+0x240>
    8254:	9127e318 	add	x24, x24, #0x9f8
    8258:	f9014bf9 	str	x25, [sp, #656]
    825c:	b0000039 	adrp	x25, d000 <__divti3+0x240>
    8260:	91286339 	add	x25, x25, #0xa18
    8264:	f9014ffa 	str	x26, [sp, #664]
    8268:	1400000d 	b	829c <fwp_write+0xc1c>
    826c:	710024bf 	cmp	w5, #0x9
    8270:	54000460 	b.eq	82fc <fwp_write+0xc7c>  // b.none
    8274:	710028bf 	cmp	w5, #0xa
    8278:	54000a61 	b.ne	83c4 <fwp_write+0xd44>  // b.any
    827c:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    8280:	aa1403e0 	mov	x0, x20
    8284:	91282021 	add	x1, x1, #0xa08
    8288:	d2800042 	mov	x2, #0x2                   	// #2
    828c:	97ffece1 	bl	3610 <buf_put>
    8290:	91000673 	add	x19, x19, #0x1
    8294:	eb17027f 	cmp	x19, x23
    8298:	540003e0 	b.eq	8314 <fwp_write+0xc94>  // b.none
    829c:	39400265 	ldrb	w5, [x19]
    82a0:	710034bf 	cmp	w5, #0xd
    82a4:	54000180 	b.eq	82d4 <fwp_write+0xc54>  // b.none
    82a8:	54fffe29 	b.ls	826c <fwp_write+0xbec>  // b.plast
    82ac:	710088bf 	cmp	w5, #0x22
    82b0:	540001c0 	b.eq	82e8 <fwp_write+0xc68>  // b.none
    82b4:	710170bf 	cmp	w5, #0x5c
    82b8:	54000741 	b.ne	83a0 <fwp_write+0xd20>  // b.any
    82bc:	aa1403e0 	mov	x0, x20
    82c0:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    82c4:	d2800042 	mov	x2, #0x2                   	// #2
    82c8:	91280021 	add	x1, x1, #0xa00
    82cc:	97ffecd1 	bl	3610 <buf_put>
    82d0:	17fffff0 	b	8290 <fwp_write+0xc10>
    82d4:	aa1903e1 	mov	x1, x25
    82d8:	aa1403e0 	mov	x0, x20
    82dc:	d2800042 	mov	x2, #0x2                   	// #2
    82e0:	97ffeccc 	bl	3610 <buf_put>
    82e4:	17ffffeb 	b	8290 <fwp_write+0xc10>
    82e8:	aa1803e1 	mov	x1, x24
    82ec:	aa1403e0 	mov	x0, x20
    82f0:	d2800042 	mov	x2, #0x2                   	// #2
    82f4:	97ffecc7 	bl	3610 <buf_put>
    82f8:	17ffffe6 	b	8290 <fwp_write+0xc10>
    82fc:	aa1403e0 	mov	x0, x20
    8300:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    8304:	d2800042 	mov	x2, #0x2                   	// #2
    8308:	91284021 	add	x1, x1, #0xa10
    830c:	97ffecc1 	bl	3610 <buf_put>
    8310:	17ffffe0 	b	8290 <fwp_write+0xc10>
    8314:	f9414bf9 	ldr	x25, [sp, #656]
    8318:	f9414ffa 	ldr	x26, [sp, #664]
    831c:	aa1503e1 	mov	x1, x21
    8320:	aa1403e0 	mov	x0, x20
    8324:	52800443 	mov	w3, #0x22                  	// #34
    8328:	17fffd9c 	b	7998 <fwp_write+0x318>
    832c:	7100103f 	cmp	w1, #0x4
    8330:	54ffeb21 	b.ne	8094 <fwp_write+0xa14>  // b.any
    8334:	f94006e0 	ldr	x0, [x23, #8]
    8338:	d37ffc00 	lsr	x0, x0, #63
    833c:	17fffeb3 	b	7e08 <fwp_write+0x788>
    8340:	710002ff 	cmp	w23, #0x0
    8344:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8348:	17fffeb0 	b	7e08 <fwp_write+0x788>
    834c:	528005a1 	mov	w1, #0x2d                  	// #45
    8350:	eb0203e2 	negs	x2, x2
    8354:	da0303e3 	ngc	x3, x3
    8358:	910127e0 	add	x0, sp, #0x49
    835c:	910123f5 	add	x21, sp, #0x48
    8360:	390123e1 	strb	w1, [sp, #72]
    8364:	97ffeacf 	bl	2ea0 <fwp_fmt_u128>
    8368:	17fffe18 	b	7bc8 <fwp_write+0x548>
    836c:	d37ceea1 	lsl	x1, x21, #4
    8370:	b7f810a3 	tbnz	x3, #63, 8584 <fwp_write+0xf04>
    8374:	91002260 	add	x0, x19, #0x8
    8378:	8b010001 	add	x1, x0, x1
    837c:	17fffdf9 	b	7b60 <fwp_write+0x4e0>
    8380:	f9400a61 	ldr	x1, [x19, #16]
    8384:	8b010000 	add	x0, x0, x1
    8388:	f9400001 	ldr	x1, [x0]
    838c:	17fffdf5 	b	7b60 <fwp_write+0x4e0>
    8390:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    8394:	d2800042 	mov	x2, #0x2                   	// #2
    8398:	91268021 	add	x1, x1, #0x9a0
    839c:	17fffed6 	b	7ef4 <fwp_write+0x874>
    83a0:	7101fcbf 	cmp	w5, #0x7f
    83a4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    83a8:	540000e9 	b.ls	83c4 <fwp_write+0xd44>  // b.plast
    83ac:	aa1503e1 	mov	x1, x21
    83b0:	aa1403e0 	mov	x0, x20
    83b4:	d2800022 	mov	x2, #0x1                   	// #1
    83b8:	39001fe5 	strb	w5, [sp, #7]
    83bc:	97ffec95 	bl	3610 <buf_put>
    83c0:	17ffffb4 	b	8290 <fwp_write+0xc10>
    83c4:	d2800203 	mov	x3, #0x10                  	// #16
    83c8:	b0000024 	adrp	x4, d000 <__divti3+0x240>
    83cc:	aa0303e1 	mov	x1, x3
    83d0:	91288084 	add	x4, x4, #0xa20
    83d4:	910123f6 	add	x22, sp, #0x48
    83d8:	52800042 	mov	w2, #0x2                   	// #2
    83dc:	aa1603e0 	mov	x0, x22
    83e0:	97ffe928 	bl	2880 <__snprintf_chk@plt>
    83e4:	aa1603e0 	mov	x0, x22
    83e8:	97ffe8ee 	bl	27a0 <strlen@plt>
    83ec:	aa1603e1 	mov	x1, x22
    83f0:	aa0003e2 	mov	x2, x0
    83f4:	aa1403e0 	mov	x0, x20
    83f8:	97ffec86 	bl	3610 <buf_put>
    83fc:	17ffffa5 	b	8290 <fwp_write+0xc10>
    8400:	1e604100 	fmov	d0, d8
    8404:	aa1503e0 	mov	x0, x21
    8408:	52800221 	mov	w1, #0x11                  	// #17
    840c:	97ffed1d 	bl	3880 <fwp_format_g.constprop.0>
    8410:	17fffe43 	b	7d1c <fwp_write+0x69c>
    8414:	b9401040 	ldr	w0, [x2, #16]
    8418:	350003c0 	cbnz	w0, 8490 <fwp_write+0xe10>
    841c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8420:	f947f400 	ldr	x0, [x0, #4072]
    8424:	f94127e2 	ldr	x2, [sp, #584]
    8428:	f9400001 	ldr	x1, [x0]
    842c:	eb010042 	subs	x2, x2, x1
    8430:	d2800001 	mov	x1, #0x0                   	// #0
    8434:	54ffd721 	b.ne	7f18 <fwp_write+0x898>  // b.any
    8438:	f9413bf5 	ldr	x21, [sp, #624]
    843c:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    8440:	f9413ff6 	ldr	x22, [sp, #632]
    8444:	aa1403e0 	mov	x0, x20
    8448:	f94143f7 	ldr	x23, [sp, #640]
    844c:	9129c021 	add	x1, x1, #0xa70
    8450:	f94147f8 	ldr	x24, [sp, #648]
    8454:	d2800042 	mov	x2, #0x2                   	// #2
    8458:	17fffd0e 	b	7890 <fwp_write+0x210>
    845c:	b0000021 	adrp	x1, d000 <__divti3+0x240>
    8460:	d2800042 	mov	x2, #0x2                   	// #2
    8464:	9126a021 	add	x1, x1, #0x9a8
    8468:	17fffea3 	b	7ef4 <fwp_write+0x874>
    846c:	f9400a63 	ldr	x3, [x19, #16]
    8470:	8b030021 	add	x1, x1, x3
    8474:	17ffff66 	b	820c <fwp_write+0xb8c>
    8478:	f9400a61 	ldr	x1, [x19, #16]
    847c:	8b0102a1 	add	x1, x21, x1
    8480:	17fffdb3 	b	7b4c <fwp_write+0x4cc>
    8484:	f9400a63 	ldr	x3, [x19, #16]
    8488:	8b030021 	add	x1, x1, x3
    848c:	17ffff56 	b	81e4 <fwp_write+0xb64>
    8490:	b9404840 	ldr	w0, [x2, #72]
    8494:	91001ff5 	add	x21, sp, #0x7
    8498:	34ffa360 	cbz	w0, 7904 <fwp_write+0x284>
    849c:	52800503 	mov	w3, #0x28                  	// #40
    84a0:	aa1403e0 	mov	x0, x20
    84a4:	aa1503e1 	mov	x1, x21
    84a8:	d2800022 	mov	x2, #0x1                   	// #1
    84ac:	39001fe3 	strb	w3, [sp, #7]
    84b0:	97ffec58 	bl	3610 <buf_put>
    84b4:	b9401380 	ldr	w0, [x28, #16]
    84b8:	52800038 	mov	w24, #0x1                   	// #1
    84bc:	7100001f 	cmp	w0, #0x0
    84c0:	54ffa36c 	b.gt	792c <fwp_write+0x2ac>
    84c4:	17fffd32 	b	798c <fwp_write+0x30c>
    84c8:	f9014bf9 	str	x25, [sp, #656]
    84cc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe930>
    84d0:	f9014ffa 	str	x26, [sp, #664]
    84d4:	f9400676 	ldr	x22, [x19, #8]
    84d8:	910aa333 	add	x19, x25, #0x2a8
    84dc:	91002273 	add	x19, x19, #0x8
    84e0:	937ffed8 	asr	x24, x22, #63
    84e4:	aa1802c0 	orr	x0, x22, x24
    84e8:	b5000320 	cbnz	x0, 854c <fwp_write+0xecc>
    84ec:	110006b5 	add	w21, w21, #0x1
    84f0:	710016bf 	cmp	w21, #0x5
    84f4:	54ffffc1 	b.ne	84ec <fwp_write+0xe6c>  // b.any
    84f8:	b7f80578 	tbnz	x24, #63, 85a4 <fwp_write+0xf24>
    84fc:	910023f3 	add	x19, sp, #0x8
    8500:	aa1603e2 	mov	x2, x22
    8504:	aa1303e0 	mov	x0, x19
    8508:	d2800003 	mov	x3, #0x0                   	// #0
    850c:	97ffea65 	bl	2ea0 <fwp_fmt_u128>
    8510:	910123f5 	add	x21, sp, #0x48
    8514:	b0000023 	adrp	x3, d000 <__divti3+0x240>
    8518:	aa1303e4 	mov	x4, x19
    851c:	aa1503e0 	mov	x0, x21
    8520:	9129a063 	add	x3, x3, #0xa68
    8524:	d2804002 	mov	x2, #0x200                 	// #512
    8528:	52800041 	mov	w1, #0x2                   	// #2
    852c:	97ffe8a1 	bl	27b0 <__sprintf_chk@plt>
    8530:	aa1503e0 	mov	x0, x21
    8534:	97ffe89b 	bl	27a0 <strlen@plt>
    8538:	aa1503e1 	mov	x1, x21
    853c:	aa0003e2 	mov	x2, x0
    8540:	aa1403e0 	mov	x0, x20
    8544:	97ffec33 	bl	3610 <buf_put>
    8548:	17fffe47 	b	7e64 <fwp_write+0x7e4>
    854c:	f9400277 	ldr	x23, [x19]
    8550:	aa1603e0 	mov	x0, x22
    8554:	aa1803e1 	mov	x1, x24
    8558:	aa1703e2 	mov	x2, x23
    855c:	937ffefa 	asr	x26, x23, #63
    8560:	aa1a03e3 	mov	x3, x26
    8564:	940012f7 	bl	d140 <__modti3>
    8568:	aa010000 	orr	x0, x0, x1
    856c:	b40002c0 	cbz	x0, 85c4 <fwp_write+0xf44>
    8570:	110006b5 	add	w21, w21, #0x1
    8574:	91004273 	add	x19, x19, #0x10
    8578:	710016bf 	cmp	w21, #0x5
    857c:	54fffe81 	b.ne	854c <fwp_write+0xecc>  // b.any
    8580:	17ffffde 	b	84f8 <fwp_write+0xe78>
    8584:	f9400a60 	ldr	x0, [x19, #16]
    8588:	8b000021 	add	x1, x1, x0
    858c:	17fffd75 	b	7b60 <fwp_write+0x4e0>
    8590:	528c29c0 	mov	w0, #0x614e                	// #24910
    8594:	910123f5 	add	x21, sp, #0x48
    8598:	72a009c0 	movk	w0, #0x4e, lsl #16
    859c:	b9004be0 	str	w0, [sp, #72]
    85a0:	17fffda2 	b	7c28 <fwp_write+0x5a8>
    85a4:	528005a1 	mov	w1, #0x2d                  	// #45
    85a8:	eb1603e2 	negs	x2, x22
    85ac:	da1803e3 	ngc	x3, x24
    85b0:	910027e0 	add	x0, sp, #0x9
    85b4:	910023f3 	add	x19, sp, #0x8
    85b8:	390023e1 	strb	w1, [sp, #8]
    85bc:	97ffea39 	bl	2ea0 <fwp_fmt_u128>
    85c0:	17ffffd4 	b	8510 <fwp_write+0xe90>
    85c4:	aa1703e2 	mov	x2, x23
    85c8:	aa1a03e3 	mov	x3, x26
    85cc:	aa1603e0 	mov	x0, x22
    85d0:	aa1803e1 	mov	x1, x24
    85d4:	940011fb 	bl	cdc0 <__divti3>
    85d8:	aa0003e2 	mov	x2, x0
    85dc:	aa0103e3 	mov	x3, x1
    85e0:	b7f80201 	tbnz	x1, #63, 8620 <fwp_write+0xfa0>
    85e4:	910023f3 	add	x19, sp, #0x8
    85e8:	aa1303e0 	mov	x0, x19
    85ec:	97ffea2d 	bl	2ea0 <fwp_fmt_u128>
    85f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    85f4:	910aa339 	add	x25, x25, #0x2a8
    85f8:	910123f5 	add	x21, sp, #0x48
    85fc:	aa1303e4 	mov	x4, x19
    8600:	aa1503e0 	mov	x0, x21
    8604:	b0000023 	adrp	x3, d000 <__divti3+0x240>
    8608:	f8616b25 	ldr	x5, [x25, x1]
    860c:	91298063 	add	x3, x3, #0xa60
    8610:	d2804002 	mov	x2, #0x200                 	// #512
    8614:	52800041 	mov	w1, #0x2                   	// #2
    8618:	97ffe866 	bl	27b0 <__sprintf_chk@plt>
    861c:	17ffffc5 	b	8530 <fwp_write+0xeb0>
    8620:	528005a4 	mov	w4, #0x2d                  	// #45
    8624:	eb0003e2 	negs	x2, x0
    8628:	da0103e3 	ngc	x3, x1
    862c:	910027e0 	add	x0, sp, #0x9
    8630:	910023f3 	add	x19, sp, #0x8
    8634:	390023e4 	strb	w4, [sp, #8]
    8638:	97ffea1a 	bl	2ea0 <fwp_fmt_u128>
    863c:	17ffffed 	b	85f0 <fwp_write+0xf70>
    8640:	f9013bf5 	str	x21, [sp, #624]
    8644:	f9013ff6 	str	x22, [sp, #632]
    8648:	f90143f7 	str	x23, [sp, #640]
    864c:	f90147f8 	str	x24, [sp, #648]
    8650:	f9014bf9 	str	x25, [sp, #656]
    8654:	f9014ffa 	str	x26, [sp, #664]
    8658:	f90153fb 	str	x27, [sp, #672]
    865c:	f90157fc 	str	x28, [sp, #680]
    8660:	fd015be8 	str	d8, [sp, #688]
    8664:	fd015fe9 	str	d9, [sp, #696]
    8668:	97ffe8aa 	bl	2910 <__stack_chk_fail@plt>
    866c:	d503201f 	nop

0000000000008670 <fwp_hof0.constprop.0>:
    8670:	d105c3ff 	sub	sp, sp, #0x170
    8674:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8678:	f947f442 	ldr	x2, [x2, #4072]
    867c:	a9117bfd 	stp	x29, x30, [sp, #272]
    8680:	910443fd 	add	x29, sp, #0x110
    8684:	a91673fb 	stp	x27, x28, [sp, #352]
    8688:	aa0003fc 	mov	x28, x0
    868c:	f9400040 	ldr	x0, [x2]
    8690:	f90087e0 	str	x0, [sp, #264]
    8694:	d2800000 	mov	x0, #0x0                   	// #0
    8698:	b40036c1 	cbz	x1, 8d70 <fwp_hof0.constprop.0+0x700>
    869c:	a91253f3 	stp	x19, x20, [sp, #288]
    86a0:	900000d4 	adrp	x20, 20000 <__data_start>
    86a4:	91004294 	add	x20, x20, #0x10
    86a8:	a91463f7 	stp	x23, x24, [sp, #320]
    86ac:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    86b0:	911742e4 	add	x4, x23, #0x5d0
    86b4:	910223e0 	add	x0, sp, #0x88
    86b8:	9100e294 	add	x20, x20, #0x38
    86bc:	aa1c03fb 	mov	x27, x28
    86c0:	a9135bf5 	stp	x21, x22, [sp, #304]
    86c4:	900000d5 	adrp	x21, 20000 <__data_start>
    86c8:	9101c2b8 	add	x24, x21, #0x70
    86cc:	a9156bf9 	stp	x25, x26, [sp, #336]
    86d0:	aa0403fa 	mov	x26, x4
    86d4:	d0fffff9 	adrp	x25, 6000 <fwp_drop1+0x110>
    86d8:	f90003e0 	str	x0, [sp]
    86dc:	910243e0 	add	x0, sp, #0x90
    86e0:	f90007e0 	str	x0, [sp, #8]
    86e4:	f9000fe1 	str	x1, [sp, #24]
    86e8:	f949ef45 	ldr	x5, [x26, #5080]
    86ec:	f949db41 	ldr	x1, [x26, #5040]
    86f0:	d370bca5 	lsl	x5, x5, #16
    86f4:	cb010363 	sub	x3, x27, x1
    86f8:	eb05007f 	cmp	x3, x5
    86fc:	540003e2 	b.cs	8778 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    8700:	d350fc60 	lsr	x0, x3, #16
    8704:	f949ff47 	ldr	x7, [x26, #5112]
    8708:	8b000800 	add	x0, x0, x0, lsl #2
    870c:	d37df002 	lsl	x2, x0, #3
    8710:	8b0200e6 	add	x6, x7, x2
    8714:	f94010c0 	ldr	x0, [x6, #32]
    8718:	b4000300 	cbz	x0, 8778 <fwp_hof0.constprop.0+0x108>
    871c:	386268e2 	ldrb	w2, [x7, x2]
    8720:	7100085f 	cmp	w2, #0x2
    8724:	54000de0 	b.eq	88e0 <fwp_hof0.constprop.0+0x270>  // b.none
    8728:	7100045f 	cmp	w2, #0x1
    872c:	54000261 	b.ne	8778 <fwp_hof0.constprop.0+0x108>  // b.any
    8730:	92403c62 	and	x2, x3, #0xffff
    8734:	29430cc7 	ldp	w7, w3, [x6, #24]
    8738:	9b077c42 	mul	x2, x2, x7
    873c:	d360fc42 	lsr	x2, x2, #32
    8740:	eb03005f 	cmp	x2, x3
    8744:	540001a2 	b.cs	8778 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    8748:	8b020000 	add	x0, x0, x2
    874c:	39400002 	ldrb	w2, [x0]
    8750:	34000142 	cbz	w2, 8778 <fwp_hof0.constprop.0+0x108>
    8754:	7103f45f 	cmp	w2, #0xfd
    8758:	54005028 	b.hi	915c <fwp_hof0.constprop.0+0xaec>  // b.pmore
    875c:	911742e1 	add	x1, x23, #0x5d0
    8760:	11000442 	add	w2, w2, #0x1
    8764:	39000002 	strb	w2, [x0]
    8768:	aa0103e0 	mov	x0, x1
    876c:	f949d821 	ldr	x1, [x1, #5040]
    8770:	f949ec05 	ldr	x5, [x0, #5080]
    8774:	d370bca5 	lsl	x5, x5, #16
    8778:	aa1b03f3 	mov	x19, x27
    877c:	9115c336 	add	x22, x25, #0x570
    8780:	d28018c0 	mov	x0, #0xc6                  	// #198
    8784:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    8788:	f9000be0 	str	x0, [sp, #16]
    878c:	a9026bfb 	stp	x27, x26, [sp, #32]
    8790:	12800002 	mov	w2, #0xffffffff            	// #-1
    8794:	f9418b00 	ldr	x0, [x24, #784]
    8798:	a9095be0 	stp	x0, x22, [sp, #144]
    879c:	cb010281 	sub	x1, x20, x1
    87a0:	f94003e0 	ldr	x0, [sp]
    87a4:	f90053e0 	str	x0, [sp, #160]
    87a8:	f94007e0 	ldr	x0, [sp, #8]
    87ac:	b9008be2 	str	w2, [sp, #136]
    87b0:	f9018b00 	str	x0, [x24, #784]
    87b4:	eb05003f 	cmp	x1, x5
    87b8:	54000782 	b.cs	88a8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    87bc:	911742e2 	add	x2, x23, #0x5d0
    87c0:	d350fc20 	lsr	x0, x1, #16
    87c4:	8b000800 	add	x0, x0, x0, lsl #2
    87c8:	f949fc43 	ldr	x3, [x2, #5112]
    87cc:	d37df000 	lsl	x0, x0, #3
    87d0:	8b000062 	add	x2, x3, x0
    87d4:	f940105a 	ldr	x26, [x2, #32]
    87d8:	b400069a 	cbz	x26, 88a8 <fwp_hof0.constprop.0+0x238>
    87dc:	38606860 	ldrb	w0, [x3, x0]
    87e0:	7100081f 	cmp	w0, #0x2
    87e4:	54000840 	b.eq	88ec <fwp_hof0.constprop.0+0x27c>  // b.none
    87e8:	7100041f 	cmp	w0, #0x1
    87ec:	540005e1 	b.ne	88a8 <fwp_hof0.constprop.0+0x238>  // b.any
    87f0:	29430c44 	ldp	w4, w3, [x2, #24]
    87f4:	92403c20 	and	x0, x1, #0xffff
    87f8:	9b047c00 	mul	x0, x0, x4
    87fc:	d360fc00 	lsr	x0, x0, #32
    8800:	eb03001f 	cmp	x0, x3
    8804:	54000282 	b.cs	8854 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    8808:	8b000340 	add	x0, x26, x0
    880c:	39400003 	ldrb	w3, [x0]
    8810:	34000223 	cbz	w3, 8854 <fwp_hof0.constprop.0+0x1e4>
    8814:	7103f47f 	cmp	w3, #0xfd
    8818:	54004e68 	b.hi	91e4 <fwp_hof0.constprop.0+0xb74>  // b.pmore
    881c:	11000463 	add	w3, w3, #0x1
    8820:	39000003 	strb	w3, [x0]
    8824:	911742e0 	add	x0, x23, #0x5d0
    8828:	f949d801 	ldr	x1, [x0, #5040]
    882c:	f949ec02 	ldr	x2, [x0, #5080]
    8830:	cb010281 	sub	x1, x20, x1
    8834:	eb02403f 	cmp	x1, x2, lsl #16
    8838:	54000382 	b.cs	88a8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    883c:	f949fc00 	ldr	x0, [x0, #5112]
    8840:	d350fc22 	lsr	x2, x1, #16
    8844:	8b020842 	add	x2, x2, x2, lsl #2
    8848:	8b020c02 	add	x2, x0, x2, lsl #3
    884c:	f940105a 	ldr	x26, [x2, #32]
    8850:	b40002da 	cbz	x26, 88a8 <fwp_hof0.constprop.0+0x238>
    8854:	39400040 	ldrb	w0, [x2]
    8858:	7100081f 	cmp	w0, #0x2
    885c:	54000dc0 	b.eq	8a14 <fwp_hof0.constprop.0+0x3a4>  // b.none
    8860:	7100041f 	cmp	w0, #0x1
    8864:	54000221 	b.ne	88a8 <fwp_hof0.constprop.0+0x238>  // b.any
    8868:	29430043 	ldp	w3, w0, [x2, #24]
    886c:	92403c21 	and	x1, x1, #0xffff
    8870:	9b037c21 	mul	x1, x1, x3
    8874:	d360fc21 	lsr	x1, x1, #32
    8878:	eb00003f 	cmp	x1, x0
    887c:	54000162 	b.cs	88a8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    8880:	8b01035a 	add	x26, x26, x1
    8884:	39400340 	ldrb	w0, [x26]
    8888:	34000100 	cbz	w0, 88a8 <fwp_hof0.constprop.0+0x238>
    888c:	7100041f 	cmp	w0, #0x1
    8890:	54000360 	b.eq	88fc <fwp_hof0.constprop.0+0x28c>  // b.none
    8894:	7103fc1f 	cmp	w0, #0xff
    8898:	540046e0 	b.eq	9174 <fwp_hof0.constprop.0+0xb04>  // b.none
    889c:	51000400 	sub	w0, w0, #0x1
    88a0:	39000340 	strb	w0, [x26]
    88a4:	d503201f 	nop
    88a8:	b40003b3 	cbz	x19, 891c <fwp_hof0.constprop.0+0x2ac>
    88ac:	aa1303e0 	mov	x0, x19
    88b0:	d280001b 	mov	x27, #0x0                   	// #0
    88b4:	d503201f 	nop
    88b8:	f9400800 	ldr	x0, [x0, #16]
    88bc:	9100077b 	add	x27, x27, #0x1
    88c0:	b5ffffc0 	cbnz	x0, 88b8 <fwp_hof0.constprop.0+0x248>
    88c4:	52800000 	mov	w0, #0x0                   	// #0
    88c8:	97ffeb6a 	bl	3670 <descent_phase_step>
    88cc:	eb1c037f 	cmp	x27, x28
    88d0:	540002c9 	b.ls	8928 <fwp_hof0.constprop.0+0x2b8>  // b.plast
    88d4:	b0000020 	adrp	x0, d000 <__divti3+0x240>
    88d8:	912a0000 	add	x0, x0, #0xa80
    88dc:	97ffee2d 	bl	4190 <fwp_trap>
    88e0:	72003c7f 	tst	w3, #0xffff
    88e4:	54fff4a1 	b.ne	8778 <fwp_hof0.constprop.0+0x108>  // b.any
    88e8:	17ffff99 	b	874c <fwp_hof0.constprop.0+0xdc>
    88ec:	72003c3f 	tst	w1, #0xffff
    88f0:	54fffb21 	b.ne	8854 <fwp_hof0.constprop.0+0x1e4>  // b.any
    88f4:	aa1a03e0 	mov	x0, x26
    88f8:	17ffffc5 	b	880c <fwp_hof0.constprop.0+0x19c>
    88fc:	d53bd040 	mrs	x0, tpidr_el0
    8900:	91400000 	add	x0, x0, #0x0, lsl #12
    8904:	91004000 	add	x0, x0, #0x10
    8908:	f9400000 	ldr	x0, [x0]
    890c:	b40007e0 	cbz	x0, 8a08 <fwp_hof0.constprop.0+0x398>
    8910:	aa1403e1 	mov	x1, x20
    8914:	97ffef9b 	bl	4780 <fwp_closure_drop_push>
    8918:	17ffffe4 	b	88a8 <fwp_hof0.constprop.0+0x238>
    891c:	d280001b 	mov	x27, #0x0                   	// #0
    8920:	52800000 	mov	w0, #0x0                   	// #0
    8924:	97ffeb53 	bl	3670 <descent_phase_step>
    8928:	9101c2ba 	add	x26, x21, #0x70
    892c:	b9434740 	ldr	w0, [x26, #836]
    8930:	34002380 	cbz	w0, 8da0 <fwp_hof0.constprop.0+0x730>
    8934:	9101c2a0 	add	x0, x21, #0x70
    8938:	f9406802 	ldr	x2, [x0, #208]
    893c:	f940741a 	ldr	x26, [x0, #232]
    8940:	eb02035f 	cmp	x26, x2
    8944:	540006ea 	b.ge	8a20 <fwp_hof0.constprop.0+0x3b0>  // b.tcont
    8948:	f9403aa1 	ldr	x1, [x21, #112]
    894c:	8b1a0740 	add	x0, x26, x26, lsl #1
    8950:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8954:	8b000b40 	add	x0, x26, x0, lsl #2
    8958:	8b000c20 	add	x0, x1, x0, lsl #3
    895c:	d503201f 	nop
    8960:	b9400401 	ldr	w1, [x0, #4]
    8964:	35000081 	cbnz	w1, 8974 <fwp_hof0.constprop.0+0x304>
    8968:	b9400001 	ldr	w1, [x0]
    896c:	6b03003f 	cmp	w1, w3
    8970:	54000589 	b.ls	8a20 <fwp_hof0.constprop.0+0x3b0>  // b.plast
    8974:	9100075a 	add	x26, x26, #0x1
    8978:	9101a000 	add	x0, x0, #0x68
    897c:	eb02035f 	cmp	x26, x2
    8980:	54ffff01 	b.ne	8960 <fwp_hof0.constprop.0+0x2f0>  // b.any
    8984:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8988:	eb00005f 	cmp	x2, x0
    898c:	5400348c 	b.gt	901c <fwp_hof0.constprop.0+0x9ac>
    8990:	9101c2a0 	add	x0, x21, #0x70
    8994:	f9403aa5 	ldr	x5, [x21, #112]
    8998:	f9407000 	ldr	x0, [x0, #224]
    899c:	eb02001f 	cmp	x0, x2
    89a0:	540001a1 	b.ne	89d4 <fwp_hof0.constprop.0+0x364>  // b.any
    89a4:	b5003422 	cbnz	x2, 9028 <fwp_hof0.constprop.0+0x9b8>
    89a8:	d2800d01 	mov	x1, #0x68                  	// #104
    89ac:	d280003a 	mov	x26, #0x1                   	// #1
    89b0:	aa0503e0 	mov	x0, x5
    89b4:	f9001be2 	str	x2, [sp, #48]
    89b8:	97ffe7d2 	bl	2900 <realloc@plt>
    89bc:	aa0003e5 	mov	x5, x0
    89c0:	f9401be2 	ldr	x2, [sp, #48]
    89c4:	b4007360 	cbz	x0, 9830 <fwp_hof0.constprop.0+0x11c0>
    89c8:	9101c2a0 	add	x0, x21, #0x70
    89cc:	f9003aa5 	str	x5, [x21, #112]
    89d0:	f900701a 	str	x26, [x0, #224]
    89d4:	8b020440 	add	x0, x2, x2, lsl #1
    89d8:	9101c2a1 	add	x1, x21, #0x70
    89dc:	4f000400 	movi	v0.4s, #0x0
    89e0:	aa0203fa 	mov	x26, x2
    89e4:	8b000840 	add	x0, x2, x0, lsl #2
    89e8:	91000442 	add	x2, x2, #0x1
    89ec:	f9006822 	str	x2, [x1, #208]
    89f0:	8b000ca0 	add	x0, x5, x0, lsl #3
    89f4:	ad000000 	stp	q0, q0, [x0]
    89f8:	ad010000 	stp	q0, q0, [x0, #32]
    89fc:	ad020000 	stp	q0, q0, [x0, #64]
    8a00:	f900301f 	str	xzr, [x0, #96]
    8a04:	1400000a 	b	8a2c <fwp_hof0.constprop.0+0x3bc>
    8a08:	aa1403e0 	mov	x0, x20
    8a0c:	97ffefa2 	bl	4894 <fwp_closure_drop.part.0>
    8a10:	17ffffa6 	b	88a8 <fwp_hof0.constprop.0+0x238>
    8a14:	72003c3f 	tst	w1, #0xffff
    8a18:	54fff481 	b.ne	88a8 <fwp_hof0.constprop.0+0x238>  // b.any
    8a1c:	17ffff9a 	b	8884 <fwp_hof0.constprop.0+0x214>
    8a20:	eb1a005f 	cmp	x2, x26
    8a24:	54fffb00 	b.eq	8984 <fwp_hof0.constprop.0+0x314>  // b.none
    8a28:	f9403aa5 	ldr	x5, [x21, #112]
    8a2c:	8b1a0743 	add	x3, x26, x26, lsl #1
    8a30:	b0000020 	adrp	x0, d000 <__divti3+0x240>
    8a34:	911ac000 	add	x0, x0, #0x6b0
    8a38:	8b030b43 	add	x3, x26, x3, lsl #2
    8a3c:	8b030ca3 	add	x3, x5, x3, lsl #3
    8a40:	a90317e3 	stp	x3, x5, [sp, #48]
    8a44:	f900307f 	str	xzr, [x3, #96]
    8a48:	97ffe816 	bl	2aa0 <getenv@plt>
    8a4c:	a94317e3 	ldp	x3, x5, [sp, #48]
    8a50:	b4000840 	cbz	x0, 8b58 <fwp_hof0.constprop.0+0x4e8>
    8a54:	39400001 	ldrb	w1, [x0]
    8a58:	7100c03f 	cmp	w1, #0x30
    8a5c:	540007e1 	b.ne	8b58 <fwp_hof0.constprop.0+0x4e8>  // b.any
    8a60:	39400400 	ldrb	w0, [x0, #1]
    8a64:	350007a0 	cbnz	w0, 8b58 <fwp_hof0.constprop.0+0x4e8>
    8a68:	9101c2a2 	add	x2, x21, #0x70
    8a6c:	2f000400 	mvni	v0.2s, #0x0
    8a70:	b9400060 	ldr	w0, [x3]
    8a74:	91000747 	add	x7, x26, #0x1
    8a78:	a900ec7b 	stp	x27, x27, [x3, #8]
    8a7c:	11000406 	add	w6, w0, #0x1
    8a80:	f9418841 	ldr	x1, [x2, #784]
    8a84:	52800020 	mov	w0, #0x1                   	// #1
    8a88:	29000066 	stp	w6, w0, [x3]
    8a8c:	f900287f 	str	xzr, [x3, #80]
    8a90:	f9007447 	str	x7, [x2, #232]
    8a94:	fd002c60 	str	d0, [x3, #88]
    8a98:	b4003541 	cbz	x1, 9140 <fwp_hof0.constprop.0+0xad0>
    8a9c:	9115c324 	add	x4, x25, #0x570
    8aa0:	14000003 	b	8aac <fwp_hof0.constprop.0+0x43c>
    8aa4:	f9400021 	ldr	x1, [x1]
    8aa8:	b40034c1 	cbz	x1, 9140 <fwp_hof0.constprop.0+0xad0>
    8aac:	f9400420 	ldr	x0, [x1, #8]
    8ab0:	eb04001f 	cmp	x0, x4
    8ab4:	54ffff81 	b.ne	8aa4 <fwp_hof0.constprop.0+0x434>  // b.any
    8ab8:	f9400820 	ldr	x0, [x1, #16]
    8abc:	2a1a03e2 	mov	w2, w26
    8ac0:	b9400001 	ldr	w1, [x0]
    8ac4:	f9002860 	str	x0, [x3, #80]
    8ac8:	b9005c61 	str	w1, [x3, #92]
    8acc:	37f80081 	tbnz	w1, #31, 8adc <fwp_hof0.constprop.0+0x46c>
    8ad0:	52800d03 	mov	w3, #0x68                  	// #104
    8ad4:	9b231421 	smaddl	x1, w1, w3, x5
    8ad8:	b900583a 	str	w26, [x1, #88]
    8adc:	b9000002 	str	w2, [x0]
    8ae0:	52800020 	mov	w0, #0x1                   	// #1
    8ae4:	b90033e6 	str	w6, [sp, #48]
    8ae8:	f9001fe7 	str	x7, [sp, #56]
    8aec:	97ffeae1 	bl	3670 <descent_phase_step>
    8af0:	f9401fe7 	ldr	x7, [sp, #56]
    8af4:	aa1303e0 	mov	x0, x19
    8af8:	b94033e6 	ldr	w6, [sp, #48]
    8afc:	d2800002 	mov	x2, #0x0                   	// #0
    8b00:	b40015f3 	cbz	x19, 8dbc <fwp_hof0.constprop.0+0x74c>
    8b04:	d503201f 	nop
    8b08:	f9400800 	ldr	x0, [x0, #16]
    8b0c:	91000442 	add	x2, x2, #0x1
    8b10:	b5ffffc0 	cbnz	x0, 8b08 <fwp_hof0.constprop.0+0x498>
    8b14:	aa1303e1 	mov	x1, x19
    8b18:	f9400821 	ldr	x1, [x1, #16]
    8b1c:	91000400 	add	x0, x0, #0x1
    8b20:	b5ffffc1 	cbnz	x1, 8b18 <fwp_hof0.constprop.0+0x4a8>
    8b24:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8b28:	eb01001f 	cmp	x0, x1
    8b2c:	54000108 	b.hi	8b4c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8b30:	f100005f 	cmp	x2, #0x0
    8b34:	5400144d 	b.le	8dbc <fwp_hof0.constprop.0+0x74c>
    8b38:	eb00005f 	cmp	x2, x0
    8b3c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8b40:	9a80905b 	csel	x27, x2, x0, ls	// ls = plast
    8b44:	eb01037f 	cmp	x27, x1
    8b48:	54002809 	b.ls	9048 <fwp_hof0.constprop.0+0x9d8>  // b.plast
    8b4c:	b0000020 	adrp	x0, d000 <__divti3+0x240>
    8b50:	91260000 	add	x0, x0, #0x980
    8b54:	97ffed8f 	bl	4190 <fwp_trap>
    8b58:	9101c2a0 	add	x0, x21, #0x70
    8b5c:	f9406001 	ldr	x1, [x0, #192]
    8b60:	b4fff841 	cbz	x1, 8a68 <fwp_hof0.constprop.0+0x3f8>
    8b64:	3cc88002 	ldur	q2, [x0, #136]
    8b68:	91022001 	add	x1, x0, #0x88
    8b6c:	3cc98001 	ldur	q1, [x0, #152]
    8b70:	f900601f 	str	xzr, [x0, #192]
    8b74:	4f000400 	movi	v0.4s, #0x0
    8b78:	ad010462 	stp	q2, q1, [x3, #32]
    8b7c:	f9405c00 	ldr	x0, [x0, #184]
    8b80:	f9002460 	str	x0, [x3, #72]
    8b84:	f9401020 	ldr	x0, [x1, #32]
    8b88:	f9002060 	str	x0, [x3, #64]
    8b8c:	f9401420 	ldr	x0, [x1, #40]
    8b90:	f9000c60 	str	x0, [x3, #24]
    8b94:	f900183f 	str	xzr, [x1, #48]
    8b98:	ad000020 	stp	q0, q0, [x1]
    8b9c:	3d800820 	str	q0, [x1, #32]
    8ba0:	17ffffb2 	b	8a68 <fwp_hof0.constprop.0+0x3f8>
    8ba4:	f9401be0 	ldr	x0, [sp, #48]
    8ba8:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe930>
    8bac:	910aa042 	add	x2, x2, #0x2a8
    8bb0:	aa1303e1 	mov	x1, x19
    8bb4:	a9426bfb 	ldp	x27, x26, [sp, #32]
    8bb8:	91014042 	add	x2, x2, #0x50
    8bbc:	52800023 	mov	w3, #0x1                   	// #1
    8bc0:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    8bc4:	f9006bff 	str	xzr, [sp, #208]
    8bc8:	97fffaae 	bl	7680 <fwp_write>
    8bcc:	a94c0bfc 	ldp	x28, x2, [sp, #192]
    8bd0:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xb20>
    8bd4:	9100c000 	add	x0, x0, #0x30
    8bd8:	f100039f 	cmp	x28, #0x0
    8bdc:	9a9c001c 	csel	x28, x0, x28, eq	// eq = none
    8be0:	b100285f 	cmn	x2, #0xa
    8be4:	54008de8 	b.hi	9da0 <fwp_hof0.constprop.0+0x1730>  // b.pmore
    8be8:	91002440 	add	x0, x2, #0x9
    8bec:	52800021 	mov	w1, #0x1                   	// #1
    8bf0:	f9000be2 	str	x2, [sp, #16]
    8bf4:	97fff0df 	bl	4f70 <fwp_heap_alloc>
    8bf8:	aa1c03e1 	mov	x1, x28
    8bfc:	aa0003fc 	mov	x28, x0
    8c00:	f9400be2 	ldr	x2, [sp, #16]
    8c04:	aa0003f6 	mov	x22, x0
    8c08:	f8008782 	str	x2, [x28], #8
    8c0c:	aa1c03e0 	mov	x0, x28
    8c10:	97ffe6d4 	bl	2760 <memcpy@plt>
    8c14:	f9400be2 	ldr	x2, [sp, #16]
    8c18:	8b0202c2 	add	x2, x22, x2
    8c1c:	3900205f 	strb	wzr, [x2, #8]
    8c20:	f94063e0 	ldr	x0, [sp, #192]
    8c24:	97ffe76b 	bl	29d0 <free@plt>
    8c28:	911742e2 	add	x2, x23, #0x5d0
    8c2c:	f949d841 	ldr	x1, [x2, #5040]
    8c30:	f949ec40 	ldr	x0, [x2, #5080]
    8c34:	cb0102c1 	sub	x1, x22, x1
    8c38:	eb00403f 	cmp	x1, x0, lsl #16
    8c3c:	54000322 	b.cs	8ca0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8c40:	d350fc20 	lsr	x0, x1, #16
    8c44:	f949fc45 	ldr	x5, [x2, #5112]
    8c48:	8b000800 	add	x0, x0, x0, lsl #2
    8c4c:	d37df002 	lsl	x2, x0, #3
    8c50:	8b0200a3 	add	x3, x5, x2
    8c54:	f9401060 	ldr	x0, [x3, #32]
    8c58:	b4000240 	cbz	x0, 8ca0 <fwp_hof0.constprop.0+0x630>
    8c5c:	386268a2 	ldrb	w2, [x5, x2]
    8c60:	7100085f 	cmp	w2, #0x2
    8c64:	54008b00 	b.eq	9dc4 <fwp_hof0.constprop.0+0x1754>  // b.none
    8c68:	7100045f 	cmp	w2, #0x1
    8c6c:	540001a1 	b.ne	8ca0 <fwp_hof0.constprop.0+0x630>  // b.any
    8c70:	29430865 	ldp	w5, w2, [x3, #24]
    8c74:	92403c21 	and	x1, x1, #0xffff
    8c78:	9b057c21 	mul	x1, x1, x5
    8c7c:	d360fc21 	lsr	x1, x1, #32
    8c80:	eb02003f 	cmp	x1, x2
    8c84:	540000e2 	b.cs	8ca0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8c88:	8b010000 	add	x0, x0, x1
    8c8c:	39400001 	ldrb	w1, [x0]
    8c90:	7103fc3f 	cmp	w1, #0xff
    8c94:	540089e0 	b.eq	9dd0 <fwp_hof0.constprop.0+0x1760>  // b.none
    8c98:	52800021 	mov	w1, #0x1                   	// #1
    8c9c:	39000001 	strb	w1, [x0]
    8ca0:	aa1303e0 	mov	x0, x19
    8ca4:	9101c2b3 	add	x19, x21, #0x70
    8ca8:	97fff4ee 	bl	6060 <fwp_drop0>
    8cac:	f94002c2 	ldr	x2, [x22]
    8cb0:	d2800021 	mov	x1, #0x1                   	// #1
    8cb4:	f9400663 	ldr	x3, [x19, #8]
    8cb8:	aa1c03e0 	mov	x0, x28
    8cbc:	97ffe755 	bl	2a10 <fwrite@plt>
    8cc0:	f9400661 	ldr	x1, [x19, #8]
    8cc4:	52800140 	mov	w0, #0xa                   	// #10
    8cc8:	97ffe6da 	bl	2830 <fputc@plt>
    8ccc:	911742e2 	add	x2, x23, #0x5d0
    8cd0:	f949d841 	ldr	x1, [x2, #5040]
    8cd4:	f949ec40 	ldr	x0, [x2, #5080]
    8cd8:	cb0102c1 	sub	x1, x22, x1
    8cdc:	eb00403f 	cmp	x1, x0, lsl #16
    8ce0:	54000382 	b.cs	8d50 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8ce4:	d350fc20 	lsr	x0, x1, #16
    8ce8:	f949fc45 	ldr	x5, [x2, #5112]
    8cec:	8b000800 	add	x0, x0, x0, lsl #2
    8cf0:	d37df002 	lsl	x2, x0, #3
    8cf4:	8b0200a3 	add	x3, x5, x2
    8cf8:	f9401073 	ldr	x19, [x3, #32]
    8cfc:	b40002b3 	cbz	x19, 8d50 <fwp_hof0.constprop.0+0x6e0>
    8d00:	386268a2 	ldrb	w2, [x5, x2]
    8d04:	7100085f 	cmp	w2, #0x2
    8d08:	54008580 	b.eq	9db8 <fwp_hof0.constprop.0+0x1748>  // b.none
    8d0c:	7100045f 	cmp	w2, #0x1
    8d10:	54000201 	b.ne	8d50 <fwp_hof0.constprop.0+0x6e0>  // b.any
    8d14:	29430062 	ldp	w2, w0, [x3, #24]
    8d18:	92403c21 	and	x1, x1, #0xffff
    8d1c:	9b027c21 	mul	x1, x1, x2
    8d20:	d360fc21 	lsr	x1, x1, #32
    8d24:	eb00003f 	cmp	x1, x0
    8d28:	54000142 	b.cs	8d50 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8d2c:	8b010273 	add	x19, x19, x1
    8d30:	39400261 	ldrb	w1, [x19]
    8d34:	340000e1 	cbz	w1, 8d50 <fwp_hof0.constprop.0+0x6e0>
    8d38:	7100043f 	cmp	w1, #0x1
    8d3c:	54008380 	b.eq	9dac <fwp_hof0.constprop.0+0x173c>  // b.none
    8d40:	7103fc3f 	cmp	w1, #0xff
    8d44:	540084e0 	b.eq	9de0 <fwp_hof0.constprop.0+0x1770>  // b.none
    8d48:	51000421 	sub	w1, w1, #0x1
    8d4c:	39000261 	strb	w1, [x19]
    8d50:	f9400fe0 	ldr	x0, [sp, #24]
    8d54:	f9400800 	ldr	x0, [x0, #16]
    8d58:	f9000fe0 	str	x0, [sp, #24]
    8d5c:	b5ffcc60 	cbnz	x0, 86e8 <fwp_hof0.constprop.0+0x78>
    8d60:	a95253f3 	ldp	x19, x20, [sp, #288]
    8d64:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8d68:	a95463f7 	ldp	x23, x24, [sp, #320]
    8d6c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8d70:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8d74:	f947f400 	ldr	x0, [x0, #4072]
    8d78:	f94087e2 	ldr	x2, [sp, #264]
    8d7c:	f9400001 	ldr	x1, [x0]
    8d80:	eb010042 	subs	x2, x2, x1
    8d84:	d2800001 	mov	x1, #0x0                   	// #0
    8d88:	54009621 	b.ne	a04c <fwp_hof0.constprop.0+0x19dc>  // b.any
    8d8c:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8d90:	d2800000 	mov	x0, #0x0                   	// #0
    8d94:	a95673fb 	ldp	x27, x28, [sp, #352]
    8d98:	9105c3ff 	add	sp, sp, #0x170
    8d9c:	d65f03c0 	ret
    8da0:	d0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x110>
    8da4:	9111c000 	add	x0, x0, #0x470
    8da8:	940011c2 	bl	d4b0 <atexit>
    8dac:	35005420 	cbnz	w0, 9830 <fwp_hof0.constprop.0+0x11c0>
    8db0:	52800020 	mov	w0, #0x1                   	// #1
    8db4:	b9034740 	str	w0, [x26, #836]
    8db8:	17fffedf 	b	8934 <fwp_hof0.constprop.0+0x2c4>
    8dbc:	d3707cc0 	ubfiz	x0, x6, #16, #32
    8dc0:	52800041 	mov	w1, #0x2                   	// #2
    8dc4:	aa070000 	orr	x0, x0, x7
    8dc8:	f9001be0 	str	x0, [sp, #48]
    8dcc:	d2800100 	mov	x0, #0x8                   	// #8
    8dd0:	97fff068 	bl	4f70 <fwp_heap_alloc>
    8dd4:	aa0003e7 	mov	x7, x0
    8dd8:	911742e0 	add	x0, x23, #0x5d0
    8ddc:	aa0703e8 	mov	x8, x7
    8de0:	f90000ff 	str	xzr, [x7]
    8de4:	f949d801 	ldr	x1, [x0, #5040]
    8de8:	f949ec00 	ldr	x0, [x0, #5080]
    8dec:	cb0100e1 	sub	x1, x7, x1
    8df0:	eb00403f 	cmp	x1, x0, lsl #16
    8df4:	54001522 	b.cs	9098 <fwp_hof0.constprop.0+0xa28>  // b.hs, b.nlast
    8df8:	d280001b 	mov	x27, #0x0                   	// #0
    8dfc:	911742e2 	add	x2, x23, #0x5d0
    8e00:	d350fc20 	lsr	x0, x1, #16
    8e04:	8b000800 	add	x0, x0, x0, lsl #2
    8e08:	f949fc44 	ldr	x4, [x2, #5112]
    8e0c:	d37df002 	lsl	x2, x0, #3
    8e10:	8b020083 	add	x3, x4, x2
    8e14:	f940107a 	ldr	x26, [x3, #32]
    8e18:	b400025a 	cbz	x26, 8e60 <fwp_hof0.constprop.0+0x7f0>
    8e1c:	38626882 	ldrb	w2, [x4, x2]
    8e20:	7100085f 	cmp	w2, #0x2
    8e24:	54001400 	b.eq	90a4 <fwp_hof0.constprop.0+0xa34>  // b.none
    8e28:	7100045f 	cmp	w2, #0x1
    8e2c:	540001a1 	b.ne	8e60 <fwp_hof0.constprop.0+0x7f0>  // b.any
    8e30:	29430864 	ldp	w4, w2, [x3, #24]
    8e34:	92403c21 	and	x1, x1, #0xffff
    8e38:	9b047c21 	mul	x1, x1, x4
    8e3c:	d360fc21 	lsr	x1, x1, #32
    8e40:	eb02003f 	cmp	x1, x2
    8e44:	540000e2 	b.cs	8e60 <fwp_hof0.constprop.0+0x7f0>  // b.hs, b.nlast
    8e48:	8b01035a 	add	x26, x26, x1
    8e4c:	39400341 	ldrb	w1, [x26]
    8e50:	7103fc3f 	cmp	w1, #0xff
    8e54:	54004c20 	b.eq	97d8 <fwp_hof0.constprop.0+0x1168>  // b.none
    8e58:	52800021 	mov	w1, #0x1                   	// #1
    8e5c:	39000341 	strb	w1, [x26]
    8e60:	b400025b 	cbz	x27, 8ea8 <fwp_hof0.constprop.0+0x838>
    8e64:	f9401be0 	ldr	x0, [sp, #48]
    8e68:	aa1303e2 	mov	x2, x19
    8e6c:	f9400666 	ldr	x6, [x19, #8]
    8e70:	910020e3 	add	x3, x7, #0x8
    8e74:	d3607c05 	lsl	x5, x0, #32
    8e78:	d2800001 	mov	x1, #0x0                   	// #0
    8e7c:	aa0503e4 	mov	x4, x5
    8e80:	14000005 	b	8e94 <fwp_hof0.constprop.0+0x824>
    8e84:	f9400446 	ldr	x6, [x2, #8]
    8e88:	ab0100a4 	adds	x4, x5, x1
    8e8c:	91004063 	add	x3, x3, #0x10
    8e90:	54009ae6 	b.vs	a1ec <fwp_hof0.constprop.0+0x1b7c>
    8e94:	a9001066 	stp	x6, x4, [x3]
    8e98:	91000421 	add	x1, x1, #0x1
    8e9c:	f9400842 	ldr	x2, [x2, #16]
    8ea0:	eb1b003f 	cmp	x1, x27
    8ea4:	54ffff03 	b.cc	8e84 <fwp_hof0.constprop.0+0x814>  // b.lo, b.ul, b.last
    8ea8:	f94000e0 	ldr	x0, [x7]
    8eac:	f100041f 	cmp	x0, #0x1
    8eb0:	54000f49 	b.ls	9098 <fwp_hof0.constprop.0+0xa28>  // b.plast
    8eb4:	d341fc1b 	lsr	x27, x0, #1
    8eb8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8ebc:	d1000760 	sub	x0, x27, #0x1
    8ec0:	eb01001f 	cmp	x0, x1
    8ec4:	54ffe448 	b.hi	8b4c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8ec8:	b4000e80 	cbz	x0, 9098 <fwp_hof0.constprop.0+0xa28>
    8ecc:	910020fa 	add	x26, x7, #0x8
    8ed0:	d10020e1 	sub	x1, x7, #0x8
    8ed4:	8b1b103b 	add	x27, x1, x27, lsl #4
    8ed8:	a903a3f3 	stp	x19, x8, [sp, #56]
    8edc:	aa1a03f3 	mov	x19, x26
    8ee0:	aa0003fa 	mov	x26, x0
    8ee4:	f90027e7 	str	x7, [sp, #72]
    8ee8:	f9400660 	ldr	x0, [x19, #8]
    8eec:	f9400e61 	ldr	x1, [x19, #24]
    8ef0:	fd400260 	ldr	d0, [x19]
    8ef4:	fd400a61 	ldr	d1, [x19, #16]
    8ef8:	97fff19a 	bl	5560 <w120>
    8efc:	a9000660 	stp	x0, x1, [x19]
    8f00:	91004273 	add	x19, x19, #0x10
    8f04:	eb1b027f 	cmp	x19, x27
    8f08:	54ffff01 	b.ne	8ee8 <fwp_hof0.constprop.0+0x878>  // b.any
    8f0c:	f94027e7 	ldr	x7, [sp, #72]
    8f10:	d37ffb41 	lsl	x1, x26, #1
    8f14:	d280001b 	mov	x27, #0x0                   	// #0
    8f18:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    8f1c:	aa0703fa 	mov	x26, x7
    8f20:	aa1b03f3 	mov	x19, x27
    8f24:	aa0303e0 	mov	x0, x3
    8f28:	f8010741 	str	x1, [x26], #16
    8f2c:	aa1a03fb 	mov	x27, x26
    8f30:	aa0103fa 	mov	x26, x1
    8f34:	d503201f 	nop
    8f38:	f8737b61 	ldr	x1, [x27, x19, lsl #3]
    8f3c:	91000a73 	add	x19, x19, #0x2
    8f40:	97fff130 	bl	5400 <f141.constprop.0>
    8f44:	eb1a027f 	cmp	x19, x26
    8f48:	54ffff83 	b.cc	8f38 <fwp_hof0.constprop.0+0x8c8>  // b.lo, b.ul, b.last
    8f4c:	a943a3f3 	ldp	x19, x8, [sp, #56]
    8f50:	aa0003e3 	mov	x3, x0
    8f54:	f94027e7 	ldr	x7, [sp, #72]
    8f58:	911742fb 	add	x27, x23, #0x5d0
    8f5c:	aa0303fa 	mov	x26, x3
    8f60:	f949db61 	ldr	x1, [x27, #5040]
    8f64:	f949ef60 	ldr	x0, [x27, #5080]
    8f68:	cb0100e1 	sub	x1, x7, x1
    8f6c:	eb00403f 	cmp	x1, x0, lsl #16
    8f70:	540003c2 	b.cs	8fe8 <fwp_hof0.constprop.0+0x978>  // b.hs, b.nlast
    8f74:	d350fc20 	lsr	x0, x1, #16
    8f78:	f949ff65 	ldr	x5, [x27, #5112]
    8f7c:	8b000800 	add	x0, x0, x0, lsl #2
    8f80:	d37df002 	lsl	x2, x0, #3
    8f84:	8b0200a4 	add	x4, x5, x2
    8f88:	f9401080 	ldr	x0, [x4, #32]
    8f8c:	b4000e40 	cbz	x0, 9154 <fwp_hof0.constprop.0+0xae4>
    8f90:	386268a2 	ldrb	w2, [x5, x2]
    8f94:	7100085f 	cmp	w2, #0x2
    8f98:	54000da0 	b.eq	914c <fwp_hof0.constprop.0+0xadc>  // b.none
    8f9c:	7100045f 	cmp	w2, #0x1
    8fa0:	54000da1 	b.ne	9154 <fwp_hof0.constprop.0+0xae4>  // b.any
    8fa4:	29430886 	ldp	w6, w2, [x4, #24]
    8fa8:	92403c21 	and	x1, x1, #0xffff
    8fac:	9b067c21 	mul	x1, x1, x6
    8fb0:	d360fc21 	lsr	x1, x1, #32
    8fb4:	eb02003f 	cmp	x1, x2
    8fb8:	54000ce2 	b.cs	9154 <fwp_hof0.constprop.0+0xae4>  // b.hs, b.nlast
    8fbc:	8b010000 	add	x0, x0, x1
    8fc0:	39400001 	ldrb	w1, [x0]
    8fc4:	34000c81 	cbz	w1, 9154 <fwp_hof0.constprop.0+0xae4>
    8fc8:	7100043f 	cmp	w1, #0x1
    8fcc:	54000720 	b.eq	90b0 <fwp_hof0.constprop.0+0xa40>  // b.none
    8fd0:	aa1a03e3 	mov	x3, x26
    8fd4:	7103fc3f 	cmp	w1, #0xff
    8fd8:	54004440 	b.eq	9860 <fwp_hof0.constprop.0+0x11f0>  // b.none
    8fdc:	51000421 	sub	w1, w1, #0x1
    8fe0:	39000001 	strb	w1, [x0]
    8fe4:	d503201f 	nop
    8fe8:	52800040 	mov	w0, #0x2                   	// #2
    8fec:	f9001fe3 	str	x3, [sp, #56]
    8ff0:	97ffe9a0 	bl	3670 <descent_phase_step>
    8ff4:	b98033fa 	ldrsw	x26, [sp, #48]
    8ff8:	aa1a03e0 	mov	x0, x26
    8ffc:	97ffee69 	bl	49a0 <fwp_tape_of>
    9000:	f940301b 	ldr	x27, [x0, #96]
    9004:	aa0003e5 	mov	x5, x0
    9008:	f9401fe3 	ldr	x3, [sp, #56]
    900c:	b4000f1b 	cbz	x27, 91ec <fwp_hof0.constprop.0+0xb7c>
    9010:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9014:	9123c000 	add	x0, x0, #0x8f0
    9018:	97ffec5e 	bl	4190 <fwp_trap>
    901c:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9020:	912a8000 	add	x0, x0, #0xaa0
    9024:	97ffec5b 	bl	4190 <fwp_trap>
    9028:	d37ff85a 	lsl	x26, x2, #1
    902c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    9030:	eb00035f 	cmp	x26, x0
    9034:	9a80d35a 	csel	x26, x26, x0, le
    9038:	8b1a0741 	add	x1, x26, x26, lsl #1
    903c:	8b010b41 	add	x1, x26, x1, lsl #2
    9040:	d37df021 	lsl	x1, x1, #3
    9044:	17fffe5b 	b	89b0 <fwp_hof0.constprop.0+0x340>
    9048:	d37ffb62 	lsl	x2, x27, #1
    904c:	d3707cc6 	ubfiz	x6, x6, #16, #32
    9050:	91000440 	add	x0, x2, #0x1
    9054:	aa0700c1 	orr	x1, x6, x7
    9058:	aa0203fa 	mov	x26, x2
    905c:	f9001be1 	str	x1, [sp, #48]
    9060:	d37df000 	lsl	x0, x0, #3
    9064:	52800041 	mov	w1, #0x2                   	// #2
    9068:	97ffefc2 	bl	4f70 <fwp_heap_alloc>
    906c:	aa0003e7 	mov	x7, x0
    9070:	911742e1 	add	x1, x23, #0x5d0
    9074:	aa0003e8 	mov	x8, x0
    9078:	aa0103e0 	mov	x0, x1
    907c:	f90000fa 	str	x26, [x7]
    9080:	f949d821 	ldr	x1, [x1, #5040]
    9084:	f949ec00 	ldr	x0, [x0, #5080]
    9088:	cb0100e1 	sub	x1, x7, x1
    908c:	eb00403f 	cmp	x1, x0, lsl #16
    9090:	54ffeb63 	b.cc	8dfc <fwp_hof0.constprop.0+0x78c>  // b.lo, b.ul, b.last
    9094:	b5ffee9b 	cbnz	x27, 8e64 <fwp_hof0.constprop.0+0x7f4>
    9098:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    909c:	f90000ff 	str	xzr, [x7]
    90a0:	17ffffae 	b	8f58 <fwp_hof0.constprop.0+0x8e8>
    90a4:	72003c3f 	tst	w1, #0xffff
    90a8:	54ffedc1 	b.ne	8e60 <fwp_hof0.constprop.0+0x7f0>  // b.any
    90ac:	17ffff68 	b	8e4c <fwp_hof0.constprop.0+0x7dc>
    90b0:	f9400106 	ldr	x6, [x8]
    90b4:	aa0803e0 	mov	x0, x8
    90b8:	f949ef62 	ldr	x2, [x27, #5080]
    90bc:	f949db61 	ldr	x1, [x27, #5040]
    90c0:	d370bc44 	lsl	x4, x2, #16
    90c4:	cb010102 	sub	x2, x8, x1
    90c8:	b7f81086 	tbnz	x6, #63, 92d8 <fwp_hof0.constprop.0+0xc68>
    90cc:	aa1a03e3 	mov	x3, x26
    90d0:	eb02009f 	cmp	x4, x2
    90d4:	54fff8a9 	b.ls	8fe8 <fwp_hof0.constprop.0+0x978>  // b.plast
    90d8:	d350fc40 	lsr	x0, x2, #16
    90dc:	8b000800 	add	x0, x0, x0, lsl #2
    90e0:	d37df000 	lsl	x0, x0, #3
    90e4:	8b0000a4 	add	x4, x5, x0
    90e8:	f9401081 	ldr	x1, [x4, #32]
    90ec:	b4fff7e1 	cbz	x1, 8fe8 <fwp_hof0.constprop.0+0x978>
    90f0:	386068a0 	ldrb	w0, [x5, x0]
    90f4:	7100081f 	cmp	w0, #0x2
    90f8:	54003600 	b.eq	97b8 <fwp_hof0.constprop.0+0x1148>  // b.none
    90fc:	7100041f 	cmp	w0, #0x1
    9100:	54fff741 	b.ne	8fe8 <fwp_hof0.constprop.0+0x978>  // b.any
    9104:	92403c40 	and	x0, x2, #0xffff
    9108:	29430885 	ldp	w5, w2, [x4, #24]
    910c:	9b057c00 	mul	x0, x0, x5
    9110:	d360fc00 	lsr	x0, x0, #32
    9114:	eb02001f 	cmp	x0, x2
    9118:	54fff682 	b.cs	8fe8 <fwp_hof0.constprop.0+0x978>  // b.hs, b.nlast
    911c:	8b000021 	add	x1, x1, x0
    9120:	39400020 	ldrb	w0, [x1]
    9124:	7100041f 	cmp	w0, #0x1
    9128:	54fff601 	b.ne	8fe8 <fwp_hof0.constprop.0+0x978>  // b.any
    912c:	aa0803e0 	mov	x0, x8
    9130:	f9001fe3 	str	x3, [sp, #56]
    9134:	97ffecd3 	bl	4480 <fwp_mem_free>
    9138:	f9401fe3 	ldr	x3, [sp, #56]
    913c:	17ffffab 	b	8fe8 <fwp_hof0.constprop.0+0x978>
    9140:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9144:	912c8000 	add	x0, x0, #0xb20
    9148:	97ffec12 	bl	4190 <fwp_trap>
    914c:	72003c3f 	tst	w1, #0xffff
    9150:	54fff380 	b.eq	8fc0 <fwp_hof0.constprop.0+0x950>  // b.none
    9154:	aa1a03e3 	mov	x3, x26
    9158:	17ffffa4 	b	8fe8 <fwp_hof0.constprop.0+0x978>
    915c:	97ffed42 	bl	4664 <fwp_rc_wide_dup>
    9160:	911742e0 	add	x0, x23, #0x5d0
    9164:	f949ec05 	ldr	x5, [x0, #5080]
    9168:	f949d801 	ldr	x1, [x0, #5040]
    916c:	d370bca5 	lsl	x5, x5, #16
    9170:	17fffd82 	b	8778 <fwp_hof0.constprop.0+0x108>
    9174:	ca5a4740 	eor	x0, x26, x26, lsr #17
    9178:	911742e1 	add	x1, x23, #0x5d0
    917c:	ca402400 	eor	x0, x0, x0, lsr #9
    9180:	92401c00 	and	x0, x0, #0xff
    9184:	910a2402 	add	x2, x0, #0x289
    9188:	8b000c20 	add	x0, x1, x0, lsl #3
    918c:	8b020c22 	add	x2, x1, x2, lsl #3
    9190:	f94a2400 	ldr	x0, [x0, #5192]
    9194:	b50000a0 	cbnz	x0, 91a8 <fwp_hof0.constprop.0+0xb38>
    9198:	1400018b 	b	97c4 <fwp_hof0.constprop.0+0x1154>
    919c:	91004002 	add	x2, x0, #0x10
    91a0:	f9400800 	ldr	x0, [x0, #16]
    91a4:	b4003100 	cbz	x0, 97c4 <fwp_hof0.constprop.0+0x1154>
    91a8:	f9400001 	ldr	x1, [x0]
    91ac:	eb1a003f 	cmp	x1, x26
    91b0:	54ffff61 	b.ne	919c <fwp_hof0.constprop.0+0xb2c>  // b.any
    91b4:	f9400041 	ldr	x1, [x2]
    91b8:	f9400420 	ldr	x0, [x1, #8]
    91bc:	d1000400 	sub	x0, x0, #0x1
    91c0:	f9000420 	str	x0, [x1, #8]
    91c4:	f103f81f 	cmp	x0, #0xfe
    91c8:	54ffb701 	b.ne	88a8 <fwp_hof0.constprop.0+0x238>  // b.any
    91cc:	39400340 	ldrb	w0, [x26]
    91d0:	7103fc1f 	cmp	w0, #0xff
    91d4:	54003180 	b.eq	9804 <fwp_hof0.constprop.0+0x1194>  // b.none
    91d8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    91dc:	39000340 	strb	w0, [x26]
    91e0:	17fffdb2 	b	88a8 <fwp_hof0.constprop.0+0x238>
    91e4:	97ffed20 	bl	4664 <fwp_rc_wide_dup>
    91e8:	17fffd8f 	b	8824 <fwp_hof0.constprop.0+0x1b4>
    91ec:	f9001be3 	str	x3, [sp, #48]
    91f0:	97ffe788 	bl	3010 <fwp_tape_unlink_scope>
    91f4:	a94188a7 	ldp	x7, x2, [x5, #24]
    91f8:	f90023e2 	str	x2, [sp, #64]
    91fc:	f94014a2 	ldr	x2, [x5, #40]
    9200:	f90027e2 	str	x2, [sp, #72]
    9204:	f94018a2 	ldr	x2, [x5, #48]
    9208:	f9002be2 	str	x2, [sp, #80]
    920c:	f9401ca2 	ldr	x2, [x5, #56]
    9210:	b90004bf 	str	wzr, [x5, #4]
    9214:	b94000a1 	ldr	w1, [x5]
    9218:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    921c:	f9002fe2 	str	x2, [sp, #88]
    9220:	a940a0bb 	ldp	x27, x8, [x5, #8]
    9224:	6b00003f 	cmp	w1, w0
    9228:	f9401be3 	ldr	x3, [sp, #48]
    922c:	f94020a4 	ldr	x4, [x5, #64]
    9230:	f94024a2 	ldr	x2, [x5, #72]
    9234:	54000108 	b.hi	9254 <fwp_hof0.constprop.0+0xbe4>  // b.pmore
    9238:	9101c2a1 	add	x1, x21, #0x70
    923c:	92403f40 	and	x0, x26, #0xffff
    9240:	d1000400 	sub	x0, x0, #0x1
    9244:	f9407429 	ldr	x9, [x1, #232]
    9248:	eb09001f 	cmp	x0, x9
    924c:	5400004a 	b.ge	9254 <fwp_hof0.constprop.0+0xbe4>  // b.tcont
    9250:	f9007420 	str	x0, [x1, #232]
    9254:	4f000400 	movi	v0.4s, #0x0
    9258:	f9000cbf 	str	xzr, [x5, #24]
    925c:	f94023e0 	ldr	x0, [sp, #64]
    9260:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    9264:	9101c2a1 	add	x1, x21, #0x70
    9268:	3c8080a0 	stur	q0, [x5, #8]
    926c:	ad0100a0 	stp	q0, q0, [x5, #32]
    9270:	9102a3e5 	add	x5, sp, #0xa8
    9274:	f90063e0 	str	x0, [sp, #192]
    9278:	f94027e0 	ldr	x0, [sp, #72]
    927c:	f90067e0 	str	x0, [sp, #200]
    9280:	f9402be0 	ldr	x0, [sp, #80]
    9284:	f9006be0 	str	x0, [sp, #208]
    9288:	f9402fe0 	ldr	x0, [sp, #88]
    928c:	f9006fe0 	str	x0, [sp, #216]
    9290:	f9418820 	ldr	x0, [x1, #784]
    9294:	f90057e0 	str	x0, [sp, #168]
    9298:	f0ffffc0 	adrp	x0, 4000 <fwp_wake_io+0x4c>
    929c:	9101c000 	add	x0, x0, #0x70
    92a0:	f90033e5 	str	x5, [sp, #96]
    92a4:	f9005be0 	str	x0, [sp, #176]
    92a8:	910303e0 	add	x0, sp, #0xc0
    92ac:	f9001be0 	str	x0, [sp, #48]
    92b0:	f9005fe0 	str	x0, [sp, #184]
    92b4:	a90e1fe4 	stp	x4, x7, [sp, #224]
    92b8:	f9007be2 	str	x2, [sp, #240]
    92bc:	f9018825 	str	x5, [x1, #784]
    92c0:	b7f82883 	tbnz	x3, #63, 97d0 <fwp_hof0.constprop.0+0x1160>
    92c4:	eb83835f 	cmp	x26, x3, asr #32
    92c8:	54000500 	b.eq	9368 <fwp_hof0.constprop.0+0xcf8>  // b.none
    92cc:	90000020 	adrp	x0, d000 <__divti3+0x240>
    92d0:	9122a000 	add	x0, x0, #0x8a8
    92d4:	97ffebaf 	bl	4190 <fwp_trap>
    92d8:	f9400508 	ldr	x8, [x8, #8]
    92dc:	eb02009f 	cmp	x4, x2
    92e0:	540003a9 	b.ls	9354 <fwp_hof0.constprop.0+0xce4>  // b.plast
    92e4:	d350fc46 	lsr	x6, x2, #16
    92e8:	8b0608c6 	add	x6, x6, x6, lsl #2
    92ec:	d37df0c6 	lsl	x6, x6, #3
    92f0:	8b0600a9 	add	x9, x5, x6
    92f4:	f9401127 	ldr	x7, [x9, #32]
    92f8:	b40002e7 	cbz	x7, 9354 <fwp_hof0.constprop.0+0xce4>
    92fc:	386668a5 	ldrb	w5, [x5, x6]
    9300:	710008bf 	cmp	w5, #0x2
    9304:	54002740 	b.eq	97ec <fwp_hof0.constprop.0+0x117c>  // b.none
    9308:	710004bf 	cmp	w5, #0x1
    930c:	54000241 	b.ne	9354 <fwp_hof0.constprop.0+0xce4>  // b.any
    9310:	29431526 	ldp	w6, w5, [x9, #24]
    9314:	92403c42 	and	x2, x2, #0xffff
    9318:	9b067c42 	mul	x2, x2, x6
    931c:	d360fc42 	lsr	x2, x2, #32
    9320:	eb05005f 	cmp	x2, x5
    9324:	54000182 	b.cs	9354 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    9328:	8b0200e7 	add	x7, x7, x2
    932c:	394000e2 	ldrb	w2, [x7]
    9330:	7100045f 	cmp	w2, #0x1
    9334:	54000101 	b.ne	9354 <fwp_hof0.constprop.0+0xce4>  // b.any
    9338:	f9001fe8 	str	x8, [sp, #56]
    933c:	97ffec51 	bl	4480 <fwp_mem_free>
    9340:	911742e0 	add	x0, x23, #0x5d0
    9344:	f9401fe8 	ldr	x8, [sp, #56]
    9348:	f949ec02 	ldr	x2, [x0, #5080]
    934c:	f949d801 	ldr	x1, [x0, #5040]
    9350:	d370bc44 	lsl	x4, x2, #16
    9354:	cb010101 	sub	x1, x8, x1
    9358:	eb01009f 	cmp	x4, x1
    935c:	54ffe0c8 	b.hi	8f74 <fwp_hof0.constprop.0+0x904>  // b.pmore
    9360:	aa1a03e3 	mov	x3, x26
    9364:	17ffff21 	b	8fe8 <fwp_hof0.constprop.0+0x978>
    9368:	92407c60 	and	x0, x3, #0xffffffff
    936c:	eb23411f 	cmp	x8, w3, uxtw
    9370:	5400244d 	b.le	97f8 <fwp_hof0.constprop.0+0x1188>
    9374:	eb00037f 	cmp	x27, x0
    9378:	9a80c77a 	csinc	x26, x27, x0, gt
    937c:	eb1a005f 	cmp	x2, x26
    9380:	5400248a 	b.ge	9810 <fwp_hof0.constprop.0+0x11a0>  // b.tcont
    9384:	f100005f 	cmp	x2, #0x0
    9388:	b24077e5 	mov	x5, #0x3fffffff            	// #1073741823
    938c:	9a9a1042 	csel	x2, x2, x26, ne	// ne = any
    9390:	14000004 	b	93a0 <fwp_hof0.constprop.0+0xd30>
    9394:	eb05005f 	cmp	x2, x5
    9398:	d37ff842 	lsl	x2, x2, #1
    939c:	9a9ad042 	csel	x2, x2, x26, le
    93a0:	eb1a005f 	cmp	x2, x26
    93a4:	54ffff8b 	b.lt	9394 <fwp_hof0.constprop.0+0xd24>  // b.tstop
    93a8:	f90037e3 	str	x3, [sp, #104]
    93ac:	b4003ec4 	cbz	x4, 9b84 <fwp_hof0.constprop.0+0x1514>
    93b0:	aa0403e0 	mov	x0, x4
    93b4:	d37df041 	lsl	x1, x2, #3
    93b8:	f9001fe2 	str	x2, [sp, #56]
    93bc:	97ffe551 	bl	2900 <realloc@plt>
    93c0:	f9401fe2 	ldr	x2, [sp, #56]
    93c4:	aa0003e4 	mov	x4, x0
    93c8:	f94037e3 	ldr	x3, [sp, #104]
    93cc:	b4002224 	cbz	x4, 9810 <fwp_hof0.constprop.0+0x11a0>
    93d0:	f90073e4 	str	x4, [sp, #224]
    93d4:	f9007be2 	str	x2, [sp, #240]
    93d8:	b5001e1a 	cbnz	x26, 9798 <fwp_hof0.constprop.0+0x1128>
    93dc:	b7f800c3 	tbnz	x3, #63, 93f4 <fwp_hof0.constprop.0+0xd84>
    93e0:	92407c63 	and	x3, x3, #0xffffffff
    93e4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    93e8:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    93ec:	1e612800 	fadd	d0, d0, d1
    93f0:	fc237880 	str	d0, [x4, x3, lsl #3]
    93f4:	9101c2a1 	add	x1, x21, #0x70
    93f8:	cb1b0342 	sub	x2, x26, x27
    93fc:	52800060 	mov	w0, #0x3                   	// #3
    9400:	f9001fe4 	str	x4, [sp, #56]
    9404:	a9428c25 	ldp	x5, x3, [x1, #40]
    9408:	8b050042 	add	x2, x2, x5
    940c:	8b1b0063 	add	x3, x3, x27
    9410:	a9028c22 	stp	x2, x3, [x1, #40]
    9414:	97ffe897 	bl	3670 <descent_phase_step>
    9418:	d1000740 	sub	x0, x26, #0x1
    941c:	d1000762 	sub	x2, x27, #0x1
    9420:	f9401fe4 	ldr	x4, [sp, #56]
    9424:	eb00037f 	cmp	x27, x0
    9428:	5400042c 	b.gt	94ac <fwp_hof0.constprop.0+0xe3c>
    942c:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    9430:	1e602008 	fcmp	d0, #0.0
    9434:	54000360 	b.eq	94a0 <fwp_hof0.constprop.0+0xe30>  // b.none
    9438:	f94023e3 	ldr	x3, [sp, #64]
    943c:	cb1b0be1 	neg	x1, x27, lsl #2
    9440:	cb1b03e5 	neg	x5, x27
    9444:	8b010063 	add	x3, x3, x1
    9448:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    944c:	37f80123 	tbnz	w3, #31, 9470 <fwp_hof0.constprop.0+0xe00>
    9450:	f9402be6 	ldr	x6, [sp, #80]
    9454:	93407c63 	sxtw	x3, w3
    9458:	8b050cc6 	add	x6, x6, x5, lsl #3
    945c:	fc637881 	ldr	d1, [x4, x3, lsl #3]
    9460:	fc6078c2 	ldr	d2, [x6, x0, lsl #3]
    9464:	1e620802 	fmul	d2, d0, d2
    9468:	1e622821 	fadd	d1, d1, d2
    946c:	fc237881 	str	d1, [x4, x3, lsl #3]
    9470:	f94027e3 	ldr	x3, [sp, #72]
    9474:	8b010061 	add	x1, x3, x1
    9478:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    947c:	37f80121 	tbnz	w1, #31, 94a0 <fwp_hof0.constprop.0+0xe30>
    9480:	f9402fe3 	ldr	x3, [sp, #88]
    9484:	93407c21 	sxtw	x1, w1
    9488:	8b050c65 	add	x5, x3, x5, lsl #3
    948c:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    9490:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    9494:	1e620800 	fmul	d0, d0, d2
    9498:	1e602820 	fadd	d0, d1, d0
    949c:	fc217880 	str	d0, [x4, x1, lsl #3]
    94a0:	d1000400 	sub	x0, x0, #0x1
    94a4:	eb02001f 	cmp	x0, x2
    94a8:	54fffc21 	b.ne	942c <fwp_hof0.constprop.0+0xdbc>  // b.any
    94ac:	52800080 	mov	w0, #0x4                   	// #4
    94b0:	f9001fe4 	str	x4, [sp, #56]
    94b4:	97ffe86f 	bl	3670 <descent_phase_step>
    94b8:	f9401fe4 	ldr	x4, [sp, #56]
    94bc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    94c0:	eb00037f 	cmp	x27, x0
    94c4:	540025c8 	b.hi	997c <fwp_hof0.constprop.0+0x130c>  // b.pmore
    94c8:	91000760 	add	x0, x27, #0x1
    94cc:	52800041 	mov	w1, #0x2                   	// #2
    94d0:	f9001fe4 	str	x4, [sp, #56]
    94d4:	d37df000 	lsl	x0, x0, #3
    94d8:	97ffeea6 	bl	4f70 <fwp_heap_alloc>
    94dc:	aa0003fa 	mov	x26, x0
    94e0:	f800841b 	str	x27, [x0], #8
    94e4:	f9401fe4 	ldr	x4, [sp, #56]
    94e8:	d2800001 	mov	x1, #0x0                   	// #0
    94ec:	b40000db 	cbz	x27, 9504 <fwp_hof0.constprop.0+0xe94>
    94f0:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    94f4:	f8217802 	str	x2, [x0, x1, lsl #3]
    94f8:	91000421 	add	x1, x1, #0x1
    94fc:	eb01037f 	cmp	x27, x1
    9500:	54ffff81 	b.ne	94f0 <fwp_hof0.constprop.0+0xe80>  // b.any
    9504:	528000a0 	mov	w0, #0x5                   	// #5
    9508:	97ffe85a 	bl	3670 <descent_phase_step>
    950c:	9101c2a1 	add	x1, x21, #0x70
    9510:	f94033e2 	ldr	x2, [sp, #96]
    9514:	f9418820 	ldr	x0, [x1, #784]
    9518:	eb02001f 	cmp	x0, x2
    951c:	54006661 	b.ne	a1e8 <fwp_hof0.constprop.0+0x1b78>  // b.any
    9520:	f9401be0 	ldr	x0, [sp, #48]
    9524:	f94057e3 	ldr	x3, [sp, #168]
    9528:	f9001fe3 	str	x3, [sp, #56]
    952c:	f9018823 	str	x3, [x1, #784]
    9530:	97ffead0 	bl	4070 <fwp_tape_buffers_release>
    9534:	528000c0 	mov	w0, #0x6                   	// #6
    9538:	97ffe84e 	bl	3670 <descent_phase_step>
    953c:	911742e2 	add	x2, x23, #0x5d0
    9540:	f9401fe3 	ldr	x3, [sp, #56]
    9544:	f949d841 	ldr	x1, [x2, #5040]
    9548:	f949ec40 	ldr	x0, [x2, #5080]
    954c:	cb010341 	sub	x1, x26, x1
    9550:	eb00403f 	cmp	x1, x0, lsl #16
    9554:	54000322 	b.cs	95b8 <fwp_hof0.constprop.0+0xf48>  // b.hs, b.nlast
    9558:	d350fc20 	lsr	x0, x1, #16
    955c:	f949fc44 	ldr	x4, [x2, #5112]
    9560:	8b000800 	add	x0, x0, x0, lsl #2
    9564:	d37df002 	lsl	x2, x0, #3
    9568:	8b020080 	add	x0, x4, x2
    956c:	f940101b 	ldr	x27, [x0, #32]
    9570:	b400025b 	cbz	x27, 95b8 <fwp_hof0.constprop.0+0xf48>
    9574:	38626882 	ldrb	w2, [x4, x2]
    9578:	7100085f 	cmp	w2, #0x2
    957c:	54002fe0 	b.eq	9b78 <fwp_hof0.constprop.0+0x1508>  // b.none
    9580:	7100045f 	cmp	w2, #0x1
    9584:	540001a1 	b.ne	95b8 <fwp_hof0.constprop.0+0xf48>  // b.any
    9588:	29430002 	ldp	w2, w0, [x0, #24]
    958c:	92403c21 	and	x1, x1, #0xffff
    9590:	9b027c21 	mul	x1, x1, x2
    9594:	d360fc21 	lsr	x1, x1, #32
    9598:	eb00003f 	cmp	x1, x0
    959c:	540000e2 	b.cs	95b8 <fwp_hof0.constprop.0+0xf48>  // b.hs, b.nlast
    95a0:	8b01037b 	add	x27, x27, x1
    95a4:	39400360 	ldrb	w0, [x27]
    95a8:	7103fc1f 	cmp	w0, #0xff
    95ac:	54003020 	b.eq	9bb0 <fwp_hof0.constprop.0+0x1540>  // b.none
    95b0:	52800020 	mov	w0, #0x1                   	// #1
    95b4:	39000360 	strb	w0, [x27]
    95b8:	f94007e0 	ldr	x0, [sp, #8]
    95bc:	eb00007f 	cmp	x3, x0
    95c0:	54006141 	b.ne	a1e8 <fwp_hof0.constprop.0+0x1b78>  // b.any
    95c4:	f94003e0 	ldr	x0, [sp]
    95c8:	9101c2a1 	add	x1, x21, #0x70
    95cc:	f9404be2 	ldr	x2, [sp, #144]
    95d0:	f9018822 	str	x2, [x1, #784]
    95d4:	97fff3e7 	bl	6570 <fwp_tape_scope_release>
    95d8:	f9400340 	ldr	x0, [x26]
    95dc:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    95e0:	b7f817c0 	tbnz	x0, #63, 98d8 <fwp_hof0.constprop.0+0x1268>
    95e4:	911742e2 	add	x2, x23, #0x5d0
    95e8:	f949d840 	ldr	x0, [x2, #5040]
    95ec:	f949ec41 	ldr	x1, [x2, #5080]
    95f0:	cb000340 	sub	x0, x26, x0
    95f4:	eb01401f 	cmp	x0, x1, lsl #16
    95f8:	54001702 	b.cs	98d8 <fwp_hof0.constprop.0+0x1268>  // b.hs, b.nlast
    95fc:	d350fc01 	lsr	x1, x0, #16
    9600:	f949fc44 	ldr	x4, [x2, #5112]
    9604:	8b010821 	add	x1, x1, x1, lsl #2
    9608:	d37df021 	lsl	x1, x1, #3
    960c:	8b010083 	add	x3, x4, x1
    9610:	f9401062 	ldr	x2, [x3, #32]
    9614:	b4001622 	cbz	x2, 98d8 <fwp_hof0.constprop.0+0x1268>
    9618:	38616881 	ldrb	w1, [x4, x1]
    961c:	7100083f 	cmp	w1, #0x2
    9620:	54001580 	b.eq	98d0 <fwp_hof0.constprop.0+0x1260>  // b.none
    9624:	7100043f 	cmp	w1, #0x1
    9628:	54001581 	b.ne	98d8 <fwp_hof0.constprop.0+0x1268>  // b.any
    962c:	29430464 	ldp	w4, w1, [x3, #24]
    9630:	92403c00 	and	x0, x0, #0xffff
    9634:	9b047c00 	mul	x0, x0, x4
    9638:	d360fc00 	lsr	x0, x0, #32
    963c:	eb01001f 	cmp	x0, x1
    9640:	540014c2 	b.cs	98d8 <fwp_hof0.constprop.0+0x1268>  // b.hs, b.nlast
    9644:	8b000042 	add	x2, x2, x0
    9648:	39400040 	ldrb	w0, [x2]
    964c:	7100041f 	cmp	w0, #0x1
    9650:	54001441 	b.ne	98d8 <fwp_hof0.constprop.0+0x1268>  // b.any
    9654:	aa1a03e3 	mov	x3, x26
    9658:	d2800000 	mov	x0, #0x0                   	// #0
    965c:	91002062 	add	x2, x3, #0x8
    9660:	d2800001 	mov	x1, #0x0                   	// #0
    9664:	b40001fb 	cbz	x27, 96a0 <fwp_hof0.constprop.0+0x1030>
    9668:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0xb20>
    966c:	91002345 	add	x5, x26, #0x8
    9670:	fd417881 	ldr	d1, [x4, #752]
    9674:	f9400346 	ldr	x6, [x26]
    9678:	aa0503e4 	mov	x4, x5
    967c:	b7f81866 	tbnz	x6, #63, 9988 <fwp_hof0.constprop.0+0x1318>
    9680:	f9400066 	ldr	x6, [x3]
    9684:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    9688:	b7f828e6 	tbnz	x6, #63, 9ba4 <fwp_hof0.constprop.0+0x1534>
    968c:	1e600820 	fmul	d0, d1, d0
    9690:	91000421 	add	x1, x1, #0x1
    9694:	fc008440 	str	d0, [x2], #8
    9698:	eb01037f 	cmp	x27, x1
    969c:	54fffec1 	b.ne	9674 <fwp_hof0.constprop.0+0x1004>  // b.any
    96a0:	f9001fe3 	str	x3, [sp, #56]
    96a4:	97fff5bf 	bl	6da0 <fwp_drop10>
    96a8:	f9401fe3 	ldr	x3, [sp, #56]
    96ac:	b4002953 	cbz	x19, 9bd4 <fwp_hof0.constprop.0+0x1564>
    96b0:	aa1303e0 	mov	x0, x19
    96b4:	d280001a 	mov	x26, #0x0                   	// #0
    96b8:	f9400800 	ldr	x0, [x0, #16]
    96bc:	9100075a 	add	x26, x26, #0x1
    96c0:	b5ffffc0 	cbnz	x0, 96b8 <fwp_hof0.constprop.0+0x1048>
    96c4:	f9400060 	ldr	x0, [x3]
    96c8:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    96cc:	b7f81620 	tbnz	x0, #63, 9990 <fwp_hof0.constprop.0+0x1320>
    96d0:	911742e1 	add	x1, x23, #0x5d0
    96d4:	f949d820 	ldr	x0, [x1, #5040]
    96d8:	f949ec22 	ldr	x2, [x1, #5080]
    96dc:	cb000060 	sub	x0, x3, x0
    96e0:	eb02401f 	cmp	x0, x2, lsl #16
    96e4:	54002862 	b.cs	9bf0 <fwp_hof0.constprop.0+0x1580>  // b.hs, b.nlast
    96e8:	d350fc02 	lsr	x2, x0, #16
    96ec:	d2800504 	mov	x4, #0x28                  	// #40
    96f0:	f949fc25 	ldr	x5, [x1, #5112]
    96f4:	9b047c42 	mul	x2, x2, x4
    96f8:	8b0200a4 	add	x4, x5, x2
    96fc:	f9401081 	ldr	x1, [x4, #32]
    9700:	b4002781 	cbz	x1, 9bf0 <fwp_hof0.constprop.0+0x1580>
    9704:	386268a2 	ldrb	w2, [x5, x2]
    9708:	7100085f 	cmp	w2, #0x2
    970c:	540026e0 	b.eq	9be8 <fwp_hof0.constprop.0+0x1578>  // b.none
    9710:	7100045f 	cmp	w2, #0x1
    9714:	540026e1 	b.ne	9bf0 <fwp_hof0.constprop.0+0x1580>  // b.any
    9718:	29430885 	ldp	w5, w2, [x4, #24]
    971c:	92403c00 	and	x0, x0, #0xffff
    9720:	9b057c00 	mul	x0, x0, x5
    9724:	d360fc00 	lsr	x0, x0, #32
    9728:	eb02001f 	cmp	x0, x2
    972c:	54002622 	b.cs	9bf0 <fwp_hof0.constprop.0+0x1580>  // b.hs, b.nlast
    9730:	8b000021 	add	x1, x1, x0
    9734:	39400028 	ldrb	w8, [x1]
    9738:	7100051f 	cmp	w8, #0x1
    973c:	540025a1 	b.ne	9bf0 <fwp_hof0.constprop.0+0x1580>  // b.any
    9740:	91002065 	add	x5, x3, #0x8
    9744:	eb1a037f 	cmp	x27, x26
    9748:	9a9a9362 	csel	x2, x27, x26, ls	// ls = plast
    974c:	b4002622 	cbz	x2, 9c10 <fwp_hof0.constprop.0+0x15a0>
    9750:	d37df047 	lsl	x7, x2, #3
    9754:	aa1303e1 	mov	x1, x19
    9758:	91002066 	add	x6, x3, #0x8
    975c:	d2800000 	mov	x0, #0x0                   	// #0
    9760:	14000009 	b	9784 <fwp_hof0.constprop.0+0x1114>
    9764:	fc606881 	ldr	d1, [x4, x0]
    9768:	fd400420 	ldr	d0, [x1, #8]
    976c:	1e613800 	fsub	d0, d0, d1
    9770:	fc2068a0 	str	d0, [x5, x0]
    9774:	91002000 	add	x0, x0, #0x8
    9778:	f9400821 	ldr	x1, [x1, #16]
    977c:	eb0000ff 	cmp	x7, x0
    9780:	54001360 	b.eq	99ec <fwp_hof0.constprop.0+0x137c>  // b.none
    9784:	f9400069 	ldr	x9, [x3]
    9788:	aa0603e4 	mov	x4, x6
    978c:	b6fffec9 	tbz	x9, #63, 9764 <fwp_hof0.constprop.0+0x10f4>
    9790:	f9400864 	ldr	x4, [x3, #16]
    9794:	17fffff4 	b	9764 <fwp_hof0.constprop.0+0x10f4>
    9798:	aa0403e0 	mov	x0, x4
    979c:	d37df342 	lsl	x2, x26, #3
    97a0:	52800001 	mov	w1, #0x0                   	// #0
    97a4:	f9001fe3 	str	x3, [sp, #56]
    97a8:	97ffe44e 	bl	28e0 <memset@plt>
    97ac:	aa0003e4 	mov	x4, x0
    97b0:	f9401fe3 	ldr	x3, [sp, #56]
    97b4:	17ffff0a 	b	93dc <fwp_hof0.constprop.0+0xd6c>
    97b8:	72003c5f 	tst	w2, #0xffff
    97bc:	54ffc161 	b.ne	8fe8 <fwp_hof0.constprop.0+0x978>  // b.any
    97c0:	17fffe58 	b	9120 <fwp_hof0.constprop.0+0xab0>
    97c4:	90000020 	adrp	x0, d000 <__divti3+0x240>
    97c8:	911b6000 	add	x0, x0, #0x6d8
    97cc:	97ffea71 	bl	4190 <fwp_trap>
    97d0:	aa1b03fa 	mov	x26, x27
    97d4:	17fffeea 	b	937c <fwp_hof0.constprop.0+0xd0c>
    97d8:	aa1a03e0 	mov	x0, x26
    97dc:	a9039fe8 	stp	x8, x7, [sp, #56]
    97e0:	97ffea8c 	bl	4210 <fwp_rc_forget_slot.part.0>
    97e4:	a9439fe8 	ldp	x8, x7, [sp, #56]
    97e8:	17fffd9c 	b	8e58 <fwp_hof0.constprop.0+0x7e8>
    97ec:	72003c5f 	tst	w2, #0xffff
    97f0:	54ffdb21 	b.ne	9354 <fwp_hof0.constprop.0+0xce4>  // b.any
    97f4:	17fffece 	b	932c <fwp_hof0.constprop.0+0xcbc>
    97f8:	90000020 	adrp	x0, d000 <__divti3+0x240>
    97fc:	91248000 	add	x0, x0, #0x920
    9800:	97ffea64 	bl	4190 <fwp_trap>
    9804:	aa1a03e0 	mov	x0, x26
    9808:	97ffea82 	bl	4210 <fwp_rc_forget_slot.part.0>
    980c:	17fffe73 	b	91d8 <fwp_hof0.constprop.0+0xb68>
    9810:	f100035f 	cmp	x26, #0x0
    9814:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9818:	54ffde01 	b.ne	93d8 <fwp_hof0.constprop.0+0xd68>  // b.any
    981c:	f9401be0 	ldr	x0, [sp, #48]
    9820:	9101c2b5 	add	x21, x21, #0x70
    9824:	f94057e1 	ldr	x1, [sp, #168]
    9828:	f9018aa1 	str	x1, [x21, #784]
    982c:	97ffea11 	bl	4070 <fwp_tape_buffers_release>
    9830:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9834:	f947e863 	ldr	x3, [x3, #4048]
    9838:	d2800262 	mov	x2, #0x13                  	// #19
    983c:	d2800021 	mov	x1, #0x1                   	// #1
    9840:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9844:	9113a000 	add	x0, x0, #0x4e8
    9848:	f9400063 	ldr	x3, [x3]
    984c:	97ffe471 	bl	2a10 <fwrite@plt>
    9850:	d2800000 	mov	x0, #0x0                   	// #0
    9854:	97ffe47b 	bl	2a40 <fflush@plt>
    9858:	52800cc0 	mov	w0, #0x66                  	// #102
    985c:	97ffe489 	bl	2a80 <_Exit@plt>
    9860:	ca404401 	eor	x1, x0, x0, lsr #17
    9864:	911742e4 	add	x4, x23, #0x5d0
    9868:	ca412421 	eor	x1, x1, x1, lsr #9
    986c:	92401c21 	and	x1, x1, #0xff
    9870:	910a2422 	add	x2, x1, #0x289
    9874:	8b010c81 	add	x1, x4, x1, lsl #3
    9878:	8b020c82 	add	x2, x4, x2, lsl #3
    987c:	f94a2421 	ldr	x1, [x1, #5192]
    9880:	b50000a1 	cbnz	x1, 9894 <fwp_hof0.constprop.0+0x1224>
    9884:	17ffffd0 	b	97c4 <fwp_hof0.constprop.0+0x1154>
    9888:	91004022 	add	x2, x1, #0x10
    988c:	f9400821 	ldr	x1, [x1, #16]
    9890:	b4fff9a1 	cbz	x1, 97c4 <fwp_hof0.constprop.0+0x1154>
    9894:	f9400024 	ldr	x4, [x1]
    9898:	eb00009f 	cmp	x4, x0
    989c:	54ffff61 	b.ne	9888 <fwp_hof0.constprop.0+0x1218>  // b.any
    98a0:	f9400042 	ldr	x2, [x2]
    98a4:	f9400441 	ldr	x1, [x2, #8]
    98a8:	d1000421 	sub	x1, x1, #0x1
    98ac:	f9000441 	str	x1, [x2, #8]
    98b0:	f103f83f 	cmp	x1, #0xfe
    98b4:	54ffb9a1 	b.ne	8fe8 <fwp_hof0.constprop.0+0x978>  // b.any
    98b8:	39400001 	ldrb	w1, [x0]
    98bc:	7103fc3f 	cmp	w1, #0xff
    98c0:	54001820 	b.eq	9bc4 <fwp_hof0.constprop.0+0x1554>  // b.none
    98c4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    98c8:	39000001 	strb	w1, [x0]
    98cc:	17fffdc7 	b	8fe8 <fwp_hof0.constprop.0+0x978>
    98d0:	72003c1f 	tst	w0, #0xffff
    98d4:	54ffeba0 	b.eq	9648 <fwp_hof0.constprop.0+0xfd8>  // b.none
    98d8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    98dc:	eb00037f 	cmp	x27, x0
    98e0:	540004e8 	b.hi	997c <fwp_hof0.constprop.0+0x130c>  // b.pmore
    98e4:	91000760 	add	x0, x27, #0x1
    98e8:	52800021 	mov	w1, #0x1                   	// #1
    98ec:	d37df000 	lsl	x0, x0, #3
    98f0:	97ffeda0 	bl	4f70 <fwp_heap_alloc>
    98f4:	911742e4 	add	x4, x23, #0x5d0
    98f8:	f900001b 	str	x27, [x0]
    98fc:	aa0003e3 	mov	x3, x0
    9900:	f949d881 	ldr	x1, [x4, #5040]
    9904:	f949ec80 	ldr	x0, [x4, #5080]
    9908:	cb010061 	sub	x1, x3, x1
    990c:	eb00403f 	cmp	x1, x0, lsl #16
    9910:	54000322 	b.cs	9974 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    9914:	d350fc22 	lsr	x2, x1, #16
    9918:	d2800500 	mov	x0, #0x28                  	// #40
    991c:	f949fc85 	ldr	x5, [x4, #5112]
    9920:	9b007c42 	mul	x2, x2, x0
    9924:	8b0200a4 	add	x4, x5, x2
    9928:	f9401080 	ldr	x0, [x4, #32]
    992c:	b4000240 	cbz	x0, 9974 <fwp_hof0.constprop.0+0x1304>
    9930:	386268a2 	ldrb	w2, [x5, x2]
    9934:	7100085f 	cmp	w2, #0x2
    9938:	54003820 	b.eq	a03c <fwp_hof0.constprop.0+0x19cc>  // b.none
    993c:	7100045f 	cmp	w2, #0x1
    9940:	540001a1 	b.ne	9974 <fwp_hof0.constprop.0+0x1304>  // b.any
    9944:	29430885 	ldp	w5, w2, [x4, #24]
    9948:	92403c21 	and	x1, x1, #0xffff
    994c:	9b057c21 	mul	x1, x1, x5
    9950:	d360fc21 	lsr	x1, x1, #32
    9954:	eb02003f 	cmp	x1, x2
    9958:	540000e2 	b.cs	9974 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    995c:	8b010000 	add	x0, x0, x1
    9960:	39400001 	ldrb	w1, [x0]
    9964:	7103fc3f 	cmp	w1, #0xff
    9968:	54003620 	b.eq	a02c <fwp_hof0.constprop.0+0x19bc>  // b.none
    996c:	52800021 	mov	w1, #0x1                   	// #1
    9970:	39000001 	strb	w1, [x0]
    9974:	aa1a03e0 	mov	x0, x26
    9978:	17ffff39 	b	965c <fwp_hof0.constprop.0+0xfec>
    997c:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9980:	912b4000 	add	x0, x0, #0xad0
    9984:	97ffea03 	bl	4190 <fwp_trap>
    9988:	f9400b44 	ldr	x4, [x26, #16]
    998c:	17ffff3d 	b	9680 <fwp_hof0.constprop.0+0x1010>
    9990:	aa1303e1 	mov	x1, x19
    9994:	d280001a 	mov	x26, #0x0                   	// #0
    9998:	f9400821 	ldr	x1, [x1, #16]
    999c:	aa1a03e0 	mov	x0, x26
    99a0:	9100075a 	add	x26, x26, #0x1
    99a4:	b5ffffa1 	cbnz	x1, 9998 <fwp_hof0.constprop.0+0x1328>
    99a8:	f9001fe3 	str	x3, [sp, #56]
    99ac:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    99b0:	eb01035f 	cmp	x26, x1
    99b4:	54ff8cc8 	b.hi	8b4c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    99b8:	91000800 	add	x0, x0, #0x2
    99bc:	52800041 	mov	w1, #0x2                   	// #2
    99c0:	d37df000 	lsl	x0, x0, #3
    99c4:	97ffed6b 	bl	4f70 <fwp_heap_alloc>
    99c8:	f9401fe3 	ldr	x3, [sp, #56]
    99cc:	aa1303e1 	mov	x1, x19
    99d0:	aa0003e5 	mov	x5, x0
    99d4:	f9400422 	ldr	x2, [x1, #8]
    99d8:	f8008402 	str	x2, [x0], #8
    99dc:	f9400821 	ldr	x1, [x1, #16]
    99e0:	b5ffffa1 	cbnz	x1, 99d4 <fwp_hof0.constprop.0+0x1364>
    99e4:	52800008 	mov	w8, #0x0                   	// #0
    99e8:	17ffff57 	b	9744 <fwp_hof0.constprop.0+0x10d4>
    99ec:	b4003e33 	cbz	x19, a1b0 <fwp_hof0.constprop.0+0x1b40>
    99f0:	911742e0 	add	x0, x23, #0x5d0
    99f4:	aa1303e4 	mov	x4, x19
    99f8:	d280001b 	mov	x27, #0x0                   	// #0
    99fc:	f949ec09 	ldr	x9, [x0, #5080]
    9a00:	f949d80b 	ldr	x11, [x0, #5040]
    9a04:	f949fc0c 	ldr	x12, [x0, #5112]
    9a08:	d370bd29 	lsl	x9, x9, #16
    9a0c:	14000006 	b	9a24 <fwp_hof0.constprop.0+0x13b4>
    9a10:	f9400884 	ldr	x4, [x4, #16]
    9a14:	9100077b 	add	x27, x27, #0x1
    9a18:	f100009f 	cmp	x4, #0x0
    9a1c:	fa5b1040 	ccmp	x2, x27, #0x0, ne	// ne = any
    9a20:	54000329 	b.ls	9a84 <fwp_hof0.constprop.0+0x1414>  // b.plast
    9a24:	cb0b0080 	sub	x0, x4, x11
    9a28:	eb09001f 	cmp	x0, x9
    9a2c:	540002c2 	b.cs	9a84 <fwp_hof0.constprop.0+0x1414>  // b.hs, b.nlast
    9a30:	d350fc01 	lsr	x1, x0, #16
    9a34:	8b010821 	add	x1, x1, x1, lsl #2
    9a38:	d37df021 	lsl	x1, x1, #3
    9a3c:	8b010187 	add	x7, x12, x1
    9a40:	f94010e6 	ldr	x6, [x7, #32]
    9a44:	b4000206 	cbz	x6, 9a84 <fwp_hof0.constprop.0+0x1414>
    9a48:	38616981 	ldrb	w1, [x12, x1]
    9a4c:	7100083f 	cmp	w1, #0x2
    9a50:	540008e0 	b.eq	9b6c <fwp_hof0.constprop.0+0x14fc>  // b.none
    9a54:	7100043f 	cmp	w1, #0x1
    9a58:	54000161 	b.ne	9a84 <fwp_hof0.constprop.0+0x1414>  // b.any
    9a5c:	294304ea 	ldp	w10, w1, [x7, #24]
    9a60:	92403c00 	and	x0, x0, #0xffff
    9a64:	9b0a7c00 	mul	x0, x0, x10
    9a68:	d360fc00 	lsr	x0, x0, #32
    9a6c:	eb01001f 	cmp	x0, x1
    9a70:	540000a2 	b.cs	9a84 <fwp_hof0.constprop.0+0x1414>  // b.hs, b.nlast
    9a74:	8b0000c6 	add	x6, x6, x0
    9a78:	394000c0 	ldrb	w0, [x6]
    9a7c:	7100041f 	cmp	w0, #0x1
    9a80:	54fffc80 	b.eq	9a10 <fwp_hof0.constprop.0+0x13a0>  // b.none
    9a84:	d2800004 	mov	x4, #0x0                   	// #0
    9a88:	eb1b005f 	cmp	x2, x27
    9a8c:	540036e9 	b.ls	a168 <fwp_hof0.constprop.0+0x1af8>  // b.plast
    9a90:	d10020a0 	sub	x0, x5, #0x8
    9a94:	911742fa 	add	x26, x23, #0x5d0
    9a98:	d2800004 	mov	x4, #0x0                   	// #0
    9a9c:	a9044fe0 	stp	x0, x19, [sp, #64]
    9aa0:	9103e3e0 	add	x0, sp, #0xf8
    9aa4:	aa0203f3 	mov	x19, x2
    9aa8:	f9001fe0 	str	x0, [sp, #56]
    9aac:	a90517f4 	stp	x20, x5, [sp, #80]
    9ab0:	aa1a03f4 	mov	x20, x26
    9ab4:	aa1603fa 	mov	x26, x22
    9ab8:	aa0303f6 	mov	x22, x3
    9abc:	b90063e8 	str	w8, [sp, #96]
    9ac0:	f90037e2 	str	x2, [sp, #104]
    9ac4:	14000012 	b	9b0c <fwp_hof0.constprop.0+0x149c>
    9ac8:	7100045f 	cmp	w2, #0x1
    9acc:	540001a1 	b.ne	9b00 <fwp_hof0.constprop.0+0x1490>  // b.any
    9ad0:	29430866 	ldp	w6, w2, [x3, #24]
    9ad4:	92403c21 	and	x1, x1, #0xffff
    9ad8:	9b067c21 	mul	x1, x1, x6
    9adc:	d360fc21 	lsr	x1, x1, #32
    9ae0:	eb02003f 	cmp	x1, x2
    9ae4:	540000e2 	b.cs	9b00 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    9ae8:	8b010000 	add	x0, x0, x1
    9aec:	39400001 	ldrb	w1, [x0]
    9af0:	7103fc3f 	cmp	w1, #0xff
    9af4:	54003500 	b.eq	a194 <fwp_hof0.constprop.0+0x1b24>  // b.none
    9af8:	52800021 	mov	w1, #0x1                   	// #1
    9afc:	39000001 	strb	w1, [x0]
    9b00:	d1000673 	sub	x19, x19, #0x1
    9b04:	eb13037f 	cmp	x27, x19
    9b08:	54002ac2 	b.cs	a060 <fwp_hof0.constprop.0+0x19f0>  // b.hs, b.nlast
    9b0c:	a94383e1 	ldp	x1, x0, [sp, #56]
    9b10:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9b14:	a90f93e0 	stp	x0, x4, [sp, #248]
    9b18:	52800020 	mov	w0, #0x1                   	// #1
    9b1c:	97ffed5a 	bl	5084 <fwp_data.part.0.constprop.0>
    9b20:	aa0003e4 	mov	x4, x0
    9b24:	f949da81 	ldr	x1, [x20, #5040]
    9b28:	f949ee80 	ldr	x0, [x20, #5080]
    9b2c:	cb010081 	sub	x1, x4, x1
    9b30:	eb00403f 	cmp	x1, x0, lsl #16
    9b34:	54fffe62 	b.cs	9b00 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    9b38:	d350fc20 	lsr	x0, x1, #16
    9b3c:	f949fe86 	ldr	x6, [x20, #5112]
    9b40:	8b000800 	add	x0, x0, x0, lsl #2
    9b44:	d37df002 	lsl	x2, x0, #3
    9b48:	8b0200c3 	add	x3, x6, x2
    9b4c:	f9401060 	ldr	x0, [x3, #32]
    9b50:	b4fffd80 	cbz	x0, 9b00 <fwp_hof0.constprop.0+0x1490>
    9b54:	386268c2 	ldrb	w2, [x6, x2]
    9b58:	7100085f 	cmp	w2, #0x2
    9b5c:	54fffb61 	b.ne	9ac8 <fwp_hof0.constprop.0+0x1458>  // b.any
    9b60:	72003c3f 	tst	w1, #0xffff
    9b64:	54fffce1 	b.ne	9b00 <fwp_hof0.constprop.0+0x1490>  // b.any
    9b68:	17ffffe1 	b	9aec <fwp_hof0.constprop.0+0x147c>
    9b6c:	72003c1f 	tst	w0, #0xffff
    9b70:	54fff8a1 	b.ne	9a84 <fwp_hof0.constprop.0+0x1414>  // b.any
    9b74:	17ffffc1 	b	9a78 <fwp_hof0.constprop.0+0x1408>
    9b78:	72003c3f 	tst	w1, #0xffff
    9b7c:	54ffd1e1 	b.ne	95b8 <fwp_hof0.constprop.0+0xf48>  // b.any
    9b80:	17fffe89 	b	95a4 <fwp_hof0.constprop.0+0xf34>
    9b84:	aa0203e0 	mov	x0, x2
    9b88:	d2800101 	mov	x1, #0x8                   	// #8
    9b8c:	f9001fe2 	str	x2, [sp, #56]
    9b90:	97ffe358 	bl	28f0 <calloc@plt>
    9b94:	f9401fe2 	ldr	x2, [sp, #56]
    9b98:	aa0003e4 	mov	x4, x0
    9b9c:	f94037e3 	ldr	x3, [sp, #104]
    9ba0:	17fffe0b 	b	93cc <fwp_hof0.constprop.0+0xd5c>
    9ba4:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9ba8:	912b8000 	add	x0, x0, #0xae0
    9bac:	97ffe979 	bl	4190 <fwp_trap>
    9bb0:	aa1b03e0 	mov	x0, x27
    9bb4:	97ffe997 	bl	4210 <fwp_rc_forget_slot.part.0>
    9bb8:	9101c2a0 	add	x0, x21, #0x70
    9bbc:	f9418803 	ldr	x3, [x0, #784]
    9bc0:	17fffe7c 	b	95b0 <fwp_hof0.constprop.0+0xf40>
    9bc4:	a9038fe0 	stp	x0, x3, [sp, #56]
    9bc8:	97ffe992 	bl	4210 <fwp_rc_forget_slot.part.0>
    9bcc:	a9438fe0 	ldp	x0, x3, [sp, #56]
    9bd0:	17ffff3d 	b	98c4 <fwp_hof0.constprop.0+0x1254>
    9bd4:	f9400062 	ldr	x2, [x3]
    9bd8:	b7f800e2 	tbnz	x2, #63, 9bf4 <fwp_hof0.constprop.0+0x1584>
    9bdc:	9240f85b 	and	x27, x2, #0x7fffffffffffffff
    9be0:	d280001a 	mov	x26, #0x0                   	// #0
    9be4:	17fffebb 	b	96d0 <fwp_hof0.constprop.0+0x1060>
    9be8:	72003c1f 	tst	w0, #0xffff
    9bec:	54ffda40 	b.eq	9734 <fwp_hof0.constprop.0+0x10c4>  // b.none
    9bf0:	b5ffed13 	cbnz	x19, 9990 <fwp_hof0.constprop.0+0x1320>
    9bf4:	52800041 	mov	w1, #0x2                   	// #2
    9bf8:	d2800100 	mov	x0, #0x8                   	// #8
    9bfc:	f9001fe3 	str	x3, [sp, #56]
    9c00:	97ffecdc 	bl	4f70 <fwp_heap_alloc>
    9c04:	f9401fe3 	ldr	x3, [sp, #56]
    9c08:	aa0003e5 	mov	x5, x0
    9c0c:	52800008 	mov	w8, #0x0                   	// #0
    9c10:	aa1303fa 	mov	x26, x19
    9c14:	d2800013 	mov	x19, #0x0                   	// #0
    9c18:	7100011f 	cmp	w8, #0x0
    9c1c:	9a8513fb 	csel	x27, xzr, x5, ne	// ne = any
    9c20:	aa1b03e0 	mov	x0, x27
    9c24:	f90027e3 	str	x3, [sp, #72]
    9c28:	97ffea16 	bl	4480 <fwp_mem_free>
    9c2c:	a903dbf8 	stp	x24, x22, [sp, #56]
    9c30:	911742e6 	add	x6, x23, #0x5d0
    9c34:	f94027e3 	ldr	x3, [sp, #72]
    9c38:	aa1403f8 	mov	x24, x20
    9c3c:	aa1303f6 	mov	x22, x19
    9c40:	aa0603f4 	mov	x20, x6
    9c44:	aa0303f3 	mov	x19, x3
    9c48:	d2800507 	mov	x7, #0x28                  	// #40
    9c4c:	f949da80 	ldr	x0, [x20, #5040]
    9c50:	f949ee81 	ldr	x1, [x20, #5080]
    9c54:	cb000260 	sub	x0, x19, x0
    9c58:	eb01401f 	cmp	x0, x1, lsl #16
    9c5c:	540012a2 	b.cs	9eb0 <fwp_hof0.constprop.0+0x1840>  // b.hs, b.nlast
    9c60:	d350fc01 	lsr	x1, x0, #16
    9c64:	f949fe82 	ldr	x2, [x20, #5112]
    9c68:	9b077c21 	mul	x1, x1, x7
    9c6c:	8b010044 	add	x4, x2, x1
    9c70:	f940109b 	ldr	x27, [x4, #32]
    9c74:	b40011fb 	cbz	x27, 9eb0 <fwp_hof0.constprop.0+0x1840>
    9c78:	38616845 	ldrb	w5, [x2, x1]
    9c7c:	710008bf 	cmp	w5, #0x2
    9c80:	54001140 	b.eq	9ea8 <fwp_hof0.constprop.0+0x1838>  // b.none
    9c84:	710004bf 	cmp	w5, #0x1
    9c88:	54001141 	b.ne	9eb0 <fwp_hof0.constprop.0+0x1840>  // b.any
    9c8c:	29432082 	ldp	w2, w8, [x4, #24]
    9c90:	92403c01 	and	x1, x0, #0xffff
    9c94:	9b027c20 	mul	x0, x1, x2
    9c98:	d360fc00 	lsr	x0, x0, #32
    9c9c:	eb08001f 	cmp	x0, x8
    9ca0:	54001082 	b.cs	9eb0 <fwp_hof0.constprop.0+0x1840>  // b.hs, b.nlast
    9ca4:	8b00037b 	add	x27, x27, x0
    9ca8:	39400362 	ldrb	w2, [x27]
    9cac:	34001022 	cbz	w2, 9eb0 <fwp_hof0.constprop.0+0x1840>
    9cb0:	7100045f 	cmp	w2, #0x1
    9cb4:	54000da0 	b.eq	9e68 <fwp_hof0.constprop.0+0x17f8>  // b.none
    9cb8:	aa1603f3 	mov	x19, x22
    9cbc:	aa1803f4 	mov	x20, x24
    9cc0:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9cc4:	7103fc5f 	cmp	w2, #0xff
    9cc8:	54000fc0 	b.eq	9ec0 <fwp_hof0.constprop.0+0x1850>  // b.none
    9ccc:	51000442 	sub	w2, w2, #0x1
    9cd0:	39000362 	strb	w2, [x27]
    9cd4:	911742e4 	add	x4, x23, #0x5d0
    9cd8:	f9001ff6 	str	x22, [sp, #56]
    9cdc:	aa1403f6 	mov	x22, x20
    9ce0:	aa1303f4 	mov	x20, x19
    9ce4:	aa0403f3 	mov	x19, x4
    9ce8:	d2800506 	mov	x6, #0x28                  	// #40
    9cec:	f949da60 	ldr	x0, [x19, #5040]
    9cf0:	f949ee61 	ldr	x1, [x19, #5080]
    9cf4:	cb000340 	sub	x0, x26, x0
    9cf8:	eb01401f 	cmp	x0, x1, lsl #16
    9cfc:	54000ae2 	b.cs	9e58 <fwp_hof0.constprop.0+0x17e8>  // b.hs, b.nlast
    9d00:	d350fc01 	lsr	x1, x0, #16
    9d04:	f949fe62 	ldr	x2, [x19, #5112]
    9d08:	9b067c21 	mul	x1, x1, x6
    9d0c:	8b010043 	add	x3, x2, x1
    9d10:	f940107b 	ldr	x27, [x3, #32]
    9d14:	b4000a3b 	cbz	x27, 9e58 <fwp_hof0.constprop.0+0x17e8>
    9d18:	38616845 	ldrb	w5, [x2, x1]
    9d1c:	710008bf 	cmp	w5, #0x2
    9d20:	54000980 	b.eq	9e50 <fwp_hof0.constprop.0+0x17e0>  // b.none
    9d24:	710004bf 	cmp	w5, #0x1
    9d28:	54000981 	b.ne	9e58 <fwp_hof0.constprop.0+0x17e8>  // b.any
    9d2c:	29430861 	ldp	w1, w2, [x3, #24]
    9d30:	92403c00 	and	x0, x0, #0xffff
    9d34:	9b017c01 	mul	x1, x0, x1
    9d38:	d360fc21 	lsr	x1, x1, #32
    9d3c:	eb02003f 	cmp	x1, x2
    9d40:	540008c2 	b.cs	9e58 <fwp_hof0.constprop.0+0x17e8>  // b.hs, b.nlast
    9d44:	8b01037b 	add	x27, x27, x1
    9d48:	39400362 	ldrb	w2, [x27]
    9d4c:	34000862 	cbz	w2, 9e58 <fwp_hof0.constprop.0+0x17e8>
    9d50:	7100045f 	cmp	w2, #0x1
    9d54:	540012c0 	b.eq	9fac <fwp_hof0.constprop.0+0x193c>  // b.none
    9d58:	aa1403f3 	mov	x19, x20
    9d5c:	aa1603f4 	mov	x20, x22
    9d60:	f9401ff6 	ldr	x22, [sp, #56]
    9d64:	7103fc5f 	cmp	w2, #0xff
    9d68:	54001040 	b.eq	9f70 <fwp_hof0.constprop.0+0x1900>  // b.none
    9d6c:	51000442 	sub	w2, w2, #0x1
    9d70:	39000362 	strb	w2, [x27]
    9d74:	f9400be0 	ldr	x0, [sp, #16]
    9d78:	b4ff7160 	cbz	x0, 8ba4 <fwp_hof0.constprop.0+0x534>
    9d7c:	f9400be0 	ldr	x0, [sp, #16]
    9d80:	f1000400 	subs	x0, x0, #0x1
    9d84:	f9000be0 	str	x0, [sp, #16]
    9d88:	54002326 	b.vs	a1ec <fwp_hof0.constprop.0+0x1b7c>
    9d8c:	911742e0 	add	x0, x23, #0x5d0
    9d90:	f949ec05 	ldr	x5, [x0, #5080]
    9d94:	f949d801 	ldr	x1, [x0, #5040]
    9d98:	d370bca5 	lsl	x5, x5, #16
    9d9c:	17fffa7d 	b	8790 <fwp_hof0.constprop.0+0x120>
    9da0:	90000020 	adrp	x0, d000 <__divti3+0x240>
    9da4:	912c2000 	add	x0, x0, #0xb08
    9da8:	97ffe8fa 	bl	4190 <fwp_trap>
    9dac:	aa1603e0 	mov	x0, x22
    9db0:	97ffef79 	bl	5b94 <fwp_rc_free_arr>
    9db4:	17fffbe7 	b	8d50 <fwp_hof0.constprop.0+0x6e0>
    9db8:	72003c3f 	tst	w1, #0xffff
    9dbc:	54ff7ca1 	b.ne	8d50 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9dc0:	17fffbdc 	b	8d30 <fwp_hof0.constprop.0+0x6c0>
    9dc4:	72003c3f 	tst	w1, #0xffff
    9dc8:	54ff76c1 	b.ne	8ca0 <fwp_hof0.constprop.0+0x630>  // b.any
    9dcc:	17fffbb0 	b	8c8c <fwp_hof0.constprop.0+0x61c>
    9dd0:	f9000be0 	str	x0, [sp, #16]
    9dd4:	97ffe90f 	bl	4210 <fwp_rc_forget_slot.part.0>
    9dd8:	f9400be0 	ldr	x0, [sp, #16]
    9ddc:	17fffbaf 	b	8c98 <fwp_hof0.constprop.0+0x628>
    9de0:	ca534661 	eor	x1, x19, x19, lsr #17
    9de4:	911742e2 	add	x2, x23, #0x5d0
    9de8:	ca412421 	eor	x1, x1, x1, lsr #9
    9dec:	92401c21 	and	x1, x1, #0xff
    9df0:	910a2420 	add	x0, x1, #0x289
    9df4:	8b010c41 	add	x1, x2, x1, lsl #3
    9df8:	8b000c40 	add	x0, x2, x0, lsl #3
    9dfc:	f94a2421 	ldr	x1, [x1, #5192]
    9e00:	b50000a1 	cbnz	x1, 9e14 <fwp_hof0.constprop.0+0x17a4>
    9e04:	17fffe70 	b	97c4 <fwp_hof0.constprop.0+0x1154>
    9e08:	91004020 	add	x0, x1, #0x10
    9e0c:	f9400821 	ldr	x1, [x1, #16]
    9e10:	b4ffcda1 	cbz	x1, 97c4 <fwp_hof0.constprop.0+0x1154>
    9e14:	f9400022 	ldr	x2, [x1]
    9e18:	eb13005f 	cmp	x2, x19
    9e1c:	54ffff61 	b.ne	9e08 <fwp_hof0.constprop.0+0x1798>  // b.any
    9e20:	f9400001 	ldr	x1, [x0]
    9e24:	f9400420 	ldr	x0, [x1, #8]
    9e28:	d1000400 	sub	x0, x0, #0x1
    9e2c:	f9000420 	str	x0, [x1, #8]
    9e30:	f103f81f 	cmp	x0, #0xfe
    9e34:	54ff78e1 	b.ne	8d50 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9e38:	39400260 	ldrb	w0, [x19]
    9e3c:	7103fc1f 	cmp	w0, #0xff
    9e40:	54000ea0 	b.eq	a014 <fwp_hof0.constprop.0+0x19a4>  // b.none
    9e44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e48:	39000260 	strb	w0, [x19]
    9e4c:	17fffbc1 	b	8d50 <fwp_hof0.constprop.0+0x6e0>
    9e50:	f2403c00 	ands	x0, x0, #0xffff
    9e54:	54fff7a0 	b.eq	9d48 <fwp_hof0.constprop.0+0x16d8>  // b.none
    9e58:	aa1403f3 	mov	x19, x20
    9e5c:	aa1603f4 	mov	x20, x22
    9e60:	f9401ff6 	ldr	x22, [sp, #56]
    9e64:	17ffffc4 	b	9d74 <fwp_hof0.constprop.0+0x1704>
    9e68:	f9400262 	ldr	x2, [x19]
    9e6c:	aa1303e0 	mov	x0, x19
    9e70:	b7f804a2 	tbnz	x2, #63, 9f04 <fwp_hof0.constprop.0+0x1894>
    9e74:	aa1803f4 	mov	x20, x24
    9e78:	aa1303e3 	mov	x3, x19
    9e7c:	aa1603f3 	mov	x19, x22
    9e80:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9e84:	710008bf 	cmp	w5, #0x2
    9e88:	540003a0 	b.eq	9efc <fwp_hof0.constprop.0+0x188c>  // b.none
    9e8c:	29430082 	ldp	w2, w0, [x4, #24]
    9e90:	9b027c21 	mul	x1, x1, x2
    9e94:	eb41801f 	cmp	x0, x1, lsr #32
    9e98:	54fff1e9 	b.ls	9cd4 <fwp_hof0.constprop.0+0x1664>  // b.plast
    9e9c:	aa0303e0 	mov	x0, x3
    9ea0:	97ffe978 	bl	4480 <fwp_mem_free>
    9ea4:	17ffff8c 	b	9cd4 <fwp_hof0.constprop.0+0x1664>
    9ea8:	f2403c01 	ands	x1, x0, #0xffff
    9eac:	54ffefe0 	b.eq	9ca8 <fwp_hof0.constprop.0+0x1638>  // b.none
    9eb0:	aa1603f3 	mov	x19, x22
    9eb4:	aa1803f4 	mov	x20, x24
    9eb8:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9ebc:	17ffff86 	b	9cd4 <fwp_hof0.constprop.0+0x1664>
    9ec0:	ca5b4761 	eor	x1, x27, x27, lsr #17
    9ec4:	911742e0 	add	x0, x23, #0x5d0
    9ec8:	ca412421 	eor	x1, x1, x1, lsr #9
    9ecc:	92401c21 	and	x1, x1, #0xff
    9ed0:	910a2422 	add	x2, x1, #0x289
    9ed4:	8b010c01 	add	x1, x0, x1, lsl #3
    9ed8:	8b020c02 	add	x2, x0, x2, lsl #3
    9edc:	f94a2420 	ldr	x0, [x1, #5192]
    9ee0:	b4ffc720 	cbz	x0, 97c4 <fwp_hof0.constprop.0+0x1154>
    9ee4:	f9400001 	ldr	x1, [x0]
    9ee8:	eb01037f 	cmp	x27, x1
    9eec:	54000200 	b.eq	9f2c <fwp_hof0.constprop.0+0x18bc>  // b.none
    9ef0:	91004002 	add	x2, x0, #0x10
    9ef4:	f9400800 	ldr	x0, [x0, #16]
    9ef8:	17fffffa 	b	9ee0 <fwp_hof0.constprop.0+0x1870>
    9efc:	b5ffeec1 	cbnz	x1, 9cd4 <fwp_hof0.constprop.0+0x1664>
    9f00:	17ffffe7 	b	9e9c <fwp_hof0.constprop.0+0x182c>
    9f04:	f9400673 	ldr	x19, [x19, #8]
    9f08:	710008bf 	cmp	w5, #0x2
    9f0c:	54000280 	b.eq	9f5c <fwp_hof0.constprop.0+0x18ec>  // b.none
    9f10:	29430885 	ldp	w5, w2, [x4, #24]
    9f14:	9b057c21 	mul	x1, x1, x5
    9f18:	eb41805f 	cmp	x2, x1, lsr #32
    9f1c:	54ffe989 	b.ls	9c4c <fwp_hof0.constprop.0+0x15dc>  // b.plast
    9f20:	97ffe958 	bl	4480 <fwp_mem_free>
    9f24:	d2800507 	mov	x7, #0x28                  	// #40
    9f28:	17ffff49 	b	9c4c <fwp_hof0.constprop.0+0x15dc>
    9f2c:	f9400041 	ldr	x1, [x2]
    9f30:	f9400420 	ldr	x0, [x1, #8]
    9f34:	d1000400 	sub	x0, x0, #0x1
    9f38:	f9000420 	str	x0, [x1, #8]
    9f3c:	f103f81f 	cmp	x0, #0xfe
    9f40:	54ffeca1 	b.ne	9cd4 <fwp_hof0.constprop.0+0x1664>  // b.any
    9f44:	39400360 	ldrb	w0, [x27]
    9f48:	7103fc1f 	cmp	w0, #0xff
    9f4c:	540000c0 	b.eq	9f64 <fwp_hof0.constprop.0+0x18f4>  // b.none
    9f50:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9f54:	39000360 	strb	w0, [x27]
    9f58:	17ffff5f 	b	9cd4 <fwp_hof0.constprop.0+0x1664>
    9f5c:	b5ffe781 	cbnz	x1, 9c4c <fwp_hof0.constprop.0+0x15dc>
    9f60:	17fffff0 	b	9f20 <fwp_hof0.constprop.0+0x18b0>
    9f64:	aa1b03e0 	mov	x0, x27
    9f68:	97ffe8aa 	bl	4210 <fwp_rc_forget_slot.part.0>
    9f6c:	17fffff9 	b	9f50 <fwp_hof0.constprop.0+0x18e0>
    9f70:	ca5b4761 	eor	x1, x27, x27, lsr #17
    9f74:	911742e0 	add	x0, x23, #0x5d0
    9f78:	ca412421 	eor	x1, x1, x1, lsr #9
    9f7c:	92401c21 	and	x1, x1, #0xff
    9f80:	910a2422 	add	x2, x1, #0x289
    9f84:	8b010c01 	add	x1, x0, x1, lsl #3
    9f88:	8b020c02 	add	x2, x0, x2, lsl #3
    9f8c:	f94a2420 	ldr	x0, [x1, #5192]
    9f90:	b4ffc1a0 	cbz	x0, 97c4 <fwp_hof0.constprop.0+0x1154>
    9f94:	f9400001 	ldr	x1, [x0]
    9f98:	eb01037f 	cmp	x27, x1
    9f9c:	54000240 	b.eq	9fe4 <fwp_hof0.constprop.0+0x1974>  // b.none
    9fa0:	91004002 	add	x2, x0, #0x10
    9fa4:	f9400800 	ldr	x0, [x0, #16]
    9fa8:	17fffffa 	b	9f90 <fwp_hof0.constprop.0+0x1920>
    9fac:	aa1a03e1 	mov	x1, x26
    9fb0:	f9400b5a 	ldr	x26, [x26, #16]
    9fb4:	710008bf 	cmp	w5, #0x2
    9fb8:	54000120 	b.eq	9fdc <fwp_hof0.constprop.0+0x196c>  // b.none
    9fbc:	29430865 	ldp	w5, w2, [x3, #24]
    9fc0:	9b057c00 	mul	x0, x0, x5
    9fc4:	eb40805f 	cmp	x2, x0, lsr #32
    9fc8:	54ffe929 	b.ls	9cec <fwp_hof0.constprop.0+0x167c>  // b.plast
    9fcc:	aa0103e0 	mov	x0, x1
    9fd0:	97ffe92c 	bl	4480 <fwp_mem_free>
    9fd4:	d2800506 	mov	x6, #0x28                  	// #40
    9fd8:	17ffff45 	b	9cec <fwp_hof0.constprop.0+0x167c>
    9fdc:	b5ffe880 	cbnz	x0, 9cec <fwp_hof0.constprop.0+0x167c>
    9fe0:	17fffffb 	b	9fcc <fwp_hof0.constprop.0+0x195c>
    9fe4:	f9400041 	ldr	x1, [x2]
    9fe8:	f9400420 	ldr	x0, [x1, #8]
    9fec:	d1000400 	sub	x0, x0, #0x1
    9ff0:	f9000420 	str	x0, [x1, #8]
    9ff4:	f103f81f 	cmp	x0, #0xfe
    9ff8:	54ffebe1 	b.ne	9d74 <fwp_hof0.constprop.0+0x1704>  // b.any
    9ffc:	39400360 	ldrb	w0, [x27]
    a000:	7103fc1f 	cmp	w0, #0xff
    a004:	540000e0 	b.eq	a020 <fwp_hof0.constprop.0+0x19b0>  // b.none
    a008:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a00c:	39000360 	strb	w0, [x27]
    a010:	17ffff59 	b	9d74 <fwp_hof0.constprop.0+0x1704>
    a014:	aa1303e0 	mov	x0, x19
    a018:	97ffe87e 	bl	4210 <fwp_rc_forget_slot.part.0>
    a01c:	17ffff8a 	b	9e44 <fwp_hof0.constprop.0+0x17d4>
    a020:	aa1b03e0 	mov	x0, x27
    a024:	97ffe87b 	bl	4210 <fwp_rc_forget_slot.part.0>
    a028:	17fffff8 	b	a008 <fwp_hof0.constprop.0+0x1998>
    a02c:	a9038fe0 	stp	x0, x3, [sp, #56]
    a030:	97ffe878 	bl	4210 <fwp_rc_forget_slot.part.0>
    a034:	a9438fe0 	ldp	x0, x3, [sp, #56]
    a038:	17fffe4d 	b	996c <fwp_hof0.constprop.0+0x12fc>
    a03c:	72003c3f 	tst	w1, #0xffff
    a040:	54ffc900 	b.eq	9960 <fwp_hof0.constprop.0+0x12f0>  // b.none
    a044:	aa1a03e0 	mov	x0, x26
    a048:	17fffd85 	b	965c <fwp_hof0.constprop.0+0xfec>
    a04c:	a91253f3 	stp	x19, x20, [sp, #288]
    a050:	a9135bf5 	stp	x21, x22, [sp, #304]
    a054:	a91463f7 	stp	x23, x24, [sp, #320]
    a058:	a9156bf9 	stp	x25, x26, [sp, #336]
    a05c:	97ffe22d 	bl	2910 <__stack_chk_fail@plt>
    a060:	f94037e2 	ldr	x2, [sp, #104]
    a064:	aa1603e3 	mov	x3, x22
    a068:	a944d3f3 	ldp	x19, x20, [sp, #72]
    a06c:	d1000441 	sub	x1, x2, #0x1
    a070:	cb020360 	sub	x0, x27, x2
    a074:	eb01037f 	cmp	x27, x1
    a078:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    a07c:	b94063e8 	ldr	w8, [sp, #96]
    a080:	f9402fe5 	ldr	x5, [sp, #88]
    a084:	aa1a03f6 	mov	x22, x26
    a088:	8b010000 	add	x0, x0, x1
    a08c:	b50006fb 	cbnz	x27, a168 <fwp_hof0.constprop.0+0x1af8>
    a090:	7100011f 	cmp	w8, #0x0
    a094:	9a8513fb 	csel	x27, xzr, x5, ne	// ne = any
    a098:	b4000860 	cbz	x0, a1a4 <fwp_hof0.constprop.0+0x1b34>
    a09c:	911742fa 	add	x26, x23, #0x5d0
    a0a0:	d1000406 	sub	x6, x0, #0x1
    a0a4:	aa1a03e0 	mov	x0, x26
    a0a8:	aa1603fa 	mov	x26, x22
    a0ac:	aa0003f6 	mov	x22, x0
    a0b0:	a90453f3 	stp	x19, x20, [sp, #64]
    a0b4:	aa1b03f3 	mov	x19, x27
    a0b8:	aa0603f4 	mov	x20, x6
    a0bc:	f9002be3 	str	x3, [sp, #80]
    a0c0:	14000012 	b	a108 <fwp_hof0.constprop.0+0x1a98>
    a0c4:	7100045f 	cmp	w2, #0x1
    a0c8:	540001a1 	b.ne	a0fc <fwp_hof0.constprop.0+0x1a8c>  // b.any
    a0cc:	29430002 	ldp	w2, w0, [x0, #24]
    a0d0:	92403c21 	and	x1, x1, #0xffff
    a0d4:	9b027c21 	mul	x1, x1, x2
    a0d8:	d360fc21 	lsr	x1, x1, #32
    a0dc:	eb00003f 	cmp	x1, x0
    a0e0:	540000e2 	b.cs	a0fc <fwp_hof0.constprop.0+0x1a8c>  // b.hs, b.nlast
    a0e4:	8b01037b 	add	x27, x27, x1
    a0e8:	39400360 	ldrb	w0, [x27]
    a0ec:	7103fc1f 	cmp	w0, #0xff
    a0f0:	54000640 	b.eq	a1b8 <fwp_hof0.constprop.0+0x1b48>  // b.none
    a0f4:	52800020 	mov	w0, #0x1                   	// #1
    a0f8:	39000360 	strb	w0, [x27]
    a0fc:	d1000694 	sub	x20, x20, #0x1
    a100:	b100069f 	cmn	x20, #0x1
    a104:	54000640 	b.eq	a1cc <fwp_hof0.constprop.0+0x1b5c>  // b.none
    a108:	f9401fe1 	ldr	x1, [sp, #56]
    a10c:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    a110:	a90f93e0 	stp	x0, x4, [sp, #248]
    a114:	52800020 	mov	w0, #0x1                   	// #1
    a118:	97ffebdb 	bl	5084 <fwp_data.part.0.constprop.0>
    a11c:	aa0003e4 	mov	x4, x0
    a120:	f949dac1 	ldr	x1, [x22, #5040]
    a124:	f949eec0 	ldr	x0, [x22, #5080]
    a128:	cb010081 	sub	x1, x4, x1
    a12c:	eb00403f 	cmp	x1, x0, lsl #16
    a130:	54fffe62 	b.cs	a0fc <fwp_hof0.constprop.0+0x1a8c>  // b.hs, b.nlast
    a134:	d350fc20 	lsr	x0, x1, #16
    a138:	f949fec7 	ldr	x7, [x22, #5112]
    a13c:	8b000800 	add	x0, x0, x0, lsl #2
    a140:	d37df002 	lsl	x2, x0, #3
    a144:	8b0200e0 	add	x0, x7, x2
    a148:	f940101b 	ldr	x27, [x0, #32]
    a14c:	b4fffd9b 	cbz	x27, a0fc <fwp_hof0.constprop.0+0x1a8c>
    a150:	386268e2 	ldrb	w2, [x7, x2]
    a154:	7100085f 	cmp	w2, #0x2
    a158:	54fffb61 	b.ne	a0c4 <fwp_hof0.constprop.0+0x1a54>  // b.any
    a15c:	72003c3f 	tst	w1, #0xffff
    a160:	54fffce1 	b.ne	a0fc <fwp_hof0.constprop.0+0x1a8c>  // b.any
    a164:	17ffffe1 	b	a0e8 <fwp_hof0.constprop.0+0x1a78>
    a168:	aa1303fa 	mov	x26, x19
    a16c:	d2800000 	mov	x0, #0x0                   	// #0
    a170:	f86078a1 	ldr	x1, [x5, x0, lsl #3]
    a174:	91000400 	add	x0, x0, #0x1
    a178:	f9000741 	str	x1, [x26, #8]
    a17c:	aa1a03e1 	mov	x1, x26
    a180:	f9400b5a 	ldr	x26, [x26, #16]
    a184:	eb00037f 	cmp	x27, x0
    a188:	54ffff48 	b.hi	a170 <fwp_hof0.constprop.0+0x1b00>  // b.pmore
    a18c:	f9000824 	str	x4, [x1, #16]
    a190:	17fffea2 	b	9c18 <fwp_hof0.constprop.0+0x15a8>
    a194:	a90713e0 	stp	x0, x4, [sp, #112]
    a198:	97ffe81e 	bl	4210 <fwp_rc_forget_slot.part.0>
    a19c:	a94713e0 	ldp	x0, x4, [sp, #112]
    a1a0:	17fffe56 	b	9af8 <fwp_hof0.constprop.0+0x1488>
    a1a4:	aa1303fa 	mov	x26, x19
    a1a8:	aa0403f3 	mov	x19, x4
    a1ac:	17fffe9d 	b	9c20 <fwp_hof0.constprop.0+0x15b0>
    a1b0:	d280001b 	mov	x27, #0x0                   	// #0
    a1b4:	17fffe37 	b	9a90 <fwp_hof0.constprop.0+0x1420>
    a1b8:	aa1b03e0 	mov	x0, x27
    a1bc:	f9002fe4 	str	x4, [sp, #88]
    a1c0:	97ffe814 	bl	4210 <fwp_rc_forget_slot.part.0>
    a1c4:	f9402fe4 	ldr	x4, [sp, #88]
    a1c8:	17ffffcb 	b	a0f4 <fwp_hof0.constprop.0+0x1a84>
    a1cc:	aa1303fb 	mov	x27, x19
    a1d0:	aa1a03f6 	mov	x22, x26
    a1d4:	a94453f3 	ldp	x19, x20, [sp, #64]
    a1d8:	f9402be3 	ldr	x3, [sp, #80]
    a1dc:	aa1303fa 	mov	x26, x19
    a1e0:	aa0403f3 	mov	x19, x4
    a1e4:	17fffe8f 	b	9c20 <fwp_hof0.constprop.0+0x15b0>
    a1e8:	97ffe1de 	bl	2960 <abort@plt>
    a1ec:	97ffe245 	bl	2b00 <fwp_trap_overflow.constprop.0>

000000000000a1f0 <f0>:
    a1f0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a1f4:	910003fd 	mov	x29, sp
    a1f8:	a90153f3 	stp	x19, x20, [sp, #16]
    a1fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    a200:	a90363f7 	stp	x23, x24, [sp, #48]
    a204:	a9046bf9 	stp	x25, x26, [sp, #64]
    a208:	a90573fb 	stp	x27, x28, [sp, #80]
    a20c:	d121c3ff 	sub	sp, sp, #0x870
    a210:	f90203ff 	str	xzr, [sp, #1024]
    a214:	d00000a0 	adrp	x0, 20000 <__data_start>
    a218:	9101c003 	add	x3, x0, #0x70
    a21c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    a220:	f947f400 	ldr	x0, [x0, #4072]
    a224:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a228:	f9418865 	ldr	x5, [x3, #784]
    a22c:	f9400001 	ldr	x1, [x0]
    a230:	f90437e1 	str	x1, [sp, #2152]
    a234:	d2800001 	mov	x1, #0x0                   	// #0
    a238:	91174299 	add	x25, x20, #0x5d0
    a23c:	912163f6 	add	x22, sp, #0x858
    a240:	910063e4 	add	x4, sp, #0x18
    a244:	9100c3e1 	add	x1, sp, #0x30
    a248:	f0ffffc0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    a24c:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a250:	913bc000 	add	x0, x0, #0xef0
    a254:	913f4042 	add	x2, x2, #0xfd0
    a258:	d2800013 	mov	x19, #0x0                   	// #0
    a25c:	d280011a 	mov	x26, #0x8                   	// #8
    a260:	d2800015 	mov	x21, #0x0                   	// #0
    a264:	52800037 	mov	w23, #0x1                   	// #1
    a268:	f90007e4 	str	x4, [sp, #8]
    a26c:	a9018be5 	stp	x5, x2, [sp, #24]
    a270:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a274:	a90403ff 	stp	xzr, x0, [sp, #64]
    a278:	f9018864 	str	x4, [x3, #784]
    a27c:	d503201f 	nop
    a280:	f100075b 	subs	x27, x26, #0x1
    a284:	aa1603e1 	mov	x1, x22
    a288:	da1f02b8 	sbc	x24, x21, xzr
    a28c:	52800020 	mov	w0, #0x1                   	// #1
    a290:	f9001ffb 	str	x27, [sp, #56]
    a294:	aa1b03fa 	mov	x26, x27
    a298:	f9042ffb 	str	x27, [sp, #2136]
    a29c:	aa1803f5 	mov	x21, x24
    a2a0:	f90433f3 	str	x19, [sp, #2144]
    a2a4:	97ffeb78 	bl	5084 <fwp_data.part.0.constprop.0>
    a2a8:	f949db22 	ldr	x2, [x25, #5040]
    a2ac:	aa0003f3 	mov	x19, x0
    a2b0:	f949ef20 	ldr	x0, [x25, #5080]
    a2b4:	cb020262 	sub	x2, x19, x2
    a2b8:	eb00405f 	cmp	x2, x0, lsl #16
    a2bc:	54000302 	b.cs	a31c <f0+0x12c>  // b.hs, b.nlast
    a2c0:	d350fc40 	lsr	x0, x2, #16
    a2c4:	f949ff25 	ldr	x5, [x25, #5112]
    a2c8:	8b000800 	add	x0, x0, x0, lsl #2
    a2cc:	d37df001 	lsl	x1, x0, #3
    a2d0:	8b0100a0 	add	x0, x5, x1
    a2d4:	f940101c 	ldr	x28, [x0, #32]
    a2d8:	b400023c 	cbz	x28, a31c <f0+0x12c>
    a2dc:	386168a1 	ldrb	w1, [x5, x1]
    a2e0:	7100083f 	cmp	w1, #0x2
    a2e4:	54010f20 	b.eq	c4c8 <f0+0x22d8>  // b.none
    a2e8:	7100043f 	cmp	w1, #0x1
    a2ec:	54000181 	b.ne	a31c <f0+0x12c>  // b.any
    a2f0:	29430001 	ldp	w1, w0, [x0, #24]
    a2f4:	92403c42 	and	x2, x2, #0xffff
    a2f8:	9b017c42 	mul	x2, x2, x1
    a2fc:	d360fc42 	lsr	x2, x2, #32
    a300:	eb00005f 	cmp	x2, x0
    a304:	540000c2 	b.cs	a31c <f0+0x12c>  // b.hs, b.nlast
    a308:	8b02039c 	add	x28, x28, x2
    a30c:	39400380 	ldrb	w0, [x28]
    a310:	7103fc1f 	cmp	w0, #0xff
    a314:	54010d40 	b.eq	c4bc <f0+0x22cc>  // b.none
    a318:	39000397 	strb	w23, [x28]
    a31c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a320:	aa18037b 	orr	x27, x27, x24
    a324:	b5fffafb 	cbnz	x27, a280 <f0+0x90>
    a328:	d00000a0 	adrp	x0, 20000 <__data_start>
    a32c:	9101c018 	add	x24, x0, #0x70
    a330:	f94007e1 	ldr	x1, [sp, #8]
    a334:	f9001bff 	str	xzr, [sp, #48]
    a338:	f9418b00 	ldr	x0, [x24, #784]
    a33c:	eb01001f 	cmp	x0, x1
    a340:	54012a01 	b.ne	c880 <f0+0x2690>  // b.any
    a344:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xb20>
    a348:	910143e1 	add	x1, sp, #0x50
    a34c:	f9400fe2 	ldr	x2, [sp, #24]
    a350:	f9018b02 	str	x2, [x24, #784]
    a354:	3dc0b800 	ldr	q0, [x0, #736]
    a358:	52800020 	mov	w0, #0x1                   	// #1
    a35c:	3d8017e0 	str	q0, [sp, #80]
    a360:	97ffeb49 	bl	5084 <fwp_data.part.0.constprop.0>
    a364:	97ffeddc 	bl	5ad4 <fwp_rc_fresh>
    a368:	aa0003e2 	mov	x2, x0
    a36c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a370:	9101a3e1 	add	x1, sp, #0x68
    a374:	52800020 	mov	w0, #0x1                   	// #1
    a378:	a9068be3 	stp	x3, x2, [sp, #104]
    a37c:	97ffeb42 	bl	5084 <fwp_data.part.0.constprop.0>
    a380:	91174283 	add	x3, x20, #0x5d0
    a384:	aa0003f5 	mov	x21, x0
    a388:	f949d861 	ldr	x1, [x3, #5040]
    a38c:	f949ec60 	ldr	x0, [x3, #5080]
    a390:	cb0102a1 	sub	x1, x21, x1
    a394:	eb00403f 	cmp	x1, x0, lsl #16
    a398:	54000322 	b.cs	a3fc <f0+0x20c>  // b.hs, b.nlast
    a39c:	d350fc22 	lsr	x2, x1, #16
    a3a0:	f949fc63 	ldr	x3, [x3, #5112]
    a3a4:	8b020842 	add	x2, x2, x2, lsl #2
    a3a8:	d37df042 	lsl	x2, x2, #3
    a3ac:	8b020060 	add	x0, x3, x2
    a3b0:	f9401017 	ldr	x23, [x0, #32]
    a3b4:	b4000257 	cbz	x23, a3fc <f0+0x20c>
    a3b8:	38626862 	ldrb	w2, [x3, x2]
    a3bc:	7100085f 	cmp	w2, #0x2
    a3c0:	540108a0 	b.eq	c4d4 <f0+0x22e4>  // b.none
    a3c4:	7100045f 	cmp	w2, #0x1
    a3c8:	540001a1 	b.ne	a3fc <f0+0x20c>  // b.any
    a3cc:	29430002 	ldp	w2, w0, [x0, #24]
    a3d0:	92403c21 	and	x1, x1, #0xffff
    a3d4:	9b027c21 	mul	x1, x1, x2
    a3d8:	d360fc21 	lsr	x1, x1, #32
    a3dc:	eb00003f 	cmp	x1, x0
    a3e0:	540000e2 	b.cs	a3fc <f0+0x20c>  // b.hs, b.nlast
    a3e4:	8b0102f7 	add	x23, x23, x1
    a3e8:	394002e0 	ldrb	w0, [x23]
    a3ec:	7103fc1f 	cmp	w0, #0xff
    a3f0:	54011620 	b.eq	c6b4 <f0+0x24c4>  // b.none
    a3f4:	52800020 	mov	w0, #0x1                   	// #1
    a3f8:	390002e0 	strb	w0, [x23]
    a3fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a400:	9101e3e1 	add	x1, sp, #0x78
    a404:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a408:	52800020 	mov	w0, #0x1                   	// #1
    a40c:	a907d7e2 	stp	x2, x21, [sp, #120]
    a410:	97ffeb1d 	bl	5084 <fwp_data.part.0.constprop.0>
    a414:	97ffedb0 	bl	5ad4 <fwp_rc_fresh>
    a418:	aa0003e2 	mov	x2, x0
    a41c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a420:	910223e1 	add	x1, sp, #0x88
    a424:	52800020 	mov	w0, #0x1                   	// #1
    a428:	a9088be3 	stp	x3, x2, [sp, #136]
    a42c:	97ffeb16 	bl	5084 <fwp_data.part.0.constprop.0>
    a430:	91174283 	add	x3, x20, #0x5d0
    a434:	aa0003f5 	mov	x21, x0
    a438:	f949d861 	ldr	x1, [x3, #5040]
    a43c:	f949ec60 	ldr	x0, [x3, #5080]
    a440:	cb0102a1 	sub	x1, x21, x1
    a444:	eb00403f 	cmp	x1, x0, lsl #16
    a448:	54000322 	b.cs	a4ac <f0+0x2bc>  // b.hs, b.nlast
    a44c:	d350fc22 	lsr	x2, x1, #16
    a450:	f949fc63 	ldr	x3, [x3, #5112]
    a454:	8b020842 	add	x2, x2, x2, lsl #2
    a458:	d37df042 	lsl	x2, x2, #3
    a45c:	8b020060 	add	x0, x3, x2
    a460:	f9401017 	ldr	x23, [x0, #32]
    a464:	b4000257 	cbz	x23, a4ac <f0+0x2bc>
    a468:	38626862 	ldrb	w2, [x3, x2]
    a46c:	7100085f 	cmp	w2, #0x2
    a470:	540103e0 	b.eq	c4ec <f0+0x22fc>  // b.none
    a474:	7100045f 	cmp	w2, #0x1
    a478:	540001a1 	b.ne	a4ac <f0+0x2bc>  // b.any
    a47c:	29430002 	ldp	w2, w0, [x0, #24]
    a480:	92403c21 	and	x1, x1, #0xffff
    a484:	9b027c21 	mul	x1, x1, x2
    a488:	d360fc21 	lsr	x1, x1, #32
    a48c:	eb00003f 	cmp	x1, x0
    a490:	540000e2 	b.cs	a4ac <f0+0x2bc>  // b.hs, b.nlast
    a494:	8b0102f7 	add	x23, x23, x1
    a498:	394002e0 	ldrb	w0, [x23]
    a49c:	7103fc1f 	cmp	w0, #0xff
    a4a0:	54011100 	b.eq	c6c0 <f0+0x24d0>  // b.none
    a4a4:	52800020 	mov	w0, #0x1                   	// #1
    a4a8:	390002e0 	strb	w0, [x23]
    a4ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4b0:	910263e1 	add	x1, sp, #0x98
    a4b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4b8:	52800020 	mov	w0, #0x1                   	// #1
    a4bc:	a909d7e2 	stp	x2, x21, [sp, #152]
    a4c0:	97ffeaf1 	bl	5084 <fwp_data.part.0.constprop.0>
    a4c4:	97ffed84 	bl	5ad4 <fwp_rc_fresh>
    a4c8:	aa0003e2 	mov	x2, x0
    a4cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a4d0:	9102a3e1 	add	x1, sp, #0xa8
    a4d4:	52800020 	mov	w0, #0x1                   	// #1
    a4d8:	a90a8be3 	stp	x3, x2, [sp, #168]
    a4dc:	97ffeaea 	bl	5084 <fwp_data.part.0.constprop.0>
    a4e0:	91174283 	add	x3, x20, #0x5d0
    a4e4:	aa0003f5 	mov	x21, x0
    a4e8:	f949d861 	ldr	x1, [x3, #5040]
    a4ec:	f949ec60 	ldr	x0, [x3, #5080]
    a4f0:	cb0102a1 	sub	x1, x21, x1
    a4f4:	eb00403f 	cmp	x1, x0, lsl #16
    a4f8:	54000322 	b.cs	a55c <f0+0x36c>  // b.hs, b.nlast
    a4fc:	d350fc22 	lsr	x2, x1, #16
    a500:	f949fc63 	ldr	x3, [x3, #5112]
    a504:	8b020842 	add	x2, x2, x2, lsl #2
    a508:	d37df042 	lsl	x2, x2, #3
    a50c:	8b020060 	add	x0, x3, x2
    a510:	f9401017 	ldr	x23, [x0, #32]
    a514:	b4000257 	cbz	x23, a55c <f0+0x36c>
    a518:	38626862 	ldrb	w2, [x3, x2]
    a51c:	7100085f 	cmp	w2, #0x2
    a520:	5400fe00 	b.eq	c4e0 <f0+0x22f0>  // b.none
    a524:	7100045f 	cmp	w2, #0x1
    a528:	540001a1 	b.ne	a55c <f0+0x36c>  // b.any
    a52c:	29430002 	ldp	w2, w0, [x0, #24]
    a530:	92403c21 	and	x1, x1, #0xffff
    a534:	9b027c21 	mul	x1, x1, x2
    a538:	d360fc21 	lsr	x1, x1, #32
    a53c:	eb00003f 	cmp	x1, x0
    a540:	540000e2 	b.cs	a55c <f0+0x36c>  // b.hs, b.nlast
    a544:	8b0102f7 	add	x23, x23, x1
    a548:	394002e0 	ldrb	w0, [x23]
    a54c:	7103fc1f 	cmp	w0, #0xff
    a550:	54010be0 	b.eq	c6cc <f0+0x24dc>  // b.none
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	390002e0 	strb	w0, [x23]
    a55c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a560:	9102e3e1 	add	x1, sp, #0xb8
    a564:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a568:	52800020 	mov	w0, #0x1                   	// #1
    a56c:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a570:	97ffeac5 	bl	5084 <fwp_data.part.0.constprop.0>
    a574:	97ffed58 	bl	5ad4 <fwp_rc_fresh>
    a578:	aa0003e2 	mov	x2, x0
    a57c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a580:	910323e1 	add	x1, sp, #0xc8
    a584:	52800020 	mov	w0, #0x1                   	// #1
    a588:	a90c8be3 	stp	x3, x2, [sp, #200]
    a58c:	97ffeabe 	bl	5084 <fwp_data.part.0.constprop.0>
    a590:	91174283 	add	x3, x20, #0x5d0
    a594:	aa0003f5 	mov	x21, x0
    a598:	f949d861 	ldr	x1, [x3, #5040]
    a59c:	f949ec60 	ldr	x0, [x3, #5080]
    a5a0:	cb0102a1 	sub	x1, x21, x1
    a5a4:	eb00403f 	cmp	x1, x0, lsl #16
    a5a8:	54000322 	b.cs	a60c <f0+0x41c>  // b.hs, b.nlast
    a5ac:	d350fc22 	lsr	x2, x1, #16
    a5b0:	f949fc63 	ldr	x3, [x3, #5112]
    a5b4:	8b020842 	add	x2, x2, x2, lsl #2
    a5b8:	d37df042 	lsl	x2, x2, #3
    a5bc:	8b020060 	add	x0, x3, x2
    a5c0:	f9401017 	ldr	x23, [x0, #32]
    a5c4:	b4000257 	cbz	x23, a60c <f0+0x41c>
    a5c8:	38626862 	ldrb	w2, [x3, x2]
    a5cc:	7100085f 	cmp	w2, #0x2
    a5d0:	5400f9a0 	b.eq	c504 <f0+0x2314>  // b.none
    a5d4:	7100045f 	cmp	w2, #0x1
    a5d8:	540001a1 	b.ne	a60c <f0+0x41c>  // b.any
    a5dc:	29430002 	ldp	w2, w0, [x0, #24]
    a5e0:	92403c21 	and	x1, x1, #0xffff
    a5e4:	9b027c21 	mul	x1, x1, x2
    a5e8:	d360fc21 	lsr	x1, x1, #32
    a5ec:	eb00003f 	cmp	x1, x0
    a5f0:	540000e2 	b.cs	a60c <f0+0x41c>  // b.hs, b.nlast
    a5f4:	8b0102f7 	add	x23, x23, x1
    a5f8:	394002e0 	ldrb	w0, [x23]
    a5fc:	7103fc1f 	cmp	w0, #0xff
    a600:	540106c0 	b.eq	c6d8 <f0+0x24e8>  // b.none
    a604:	52800020 	mov	w0, #0x1                   	// #1
    a608:	390002e0 	strb	w0, [x23]
    a60c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a610:	910363e1 	add	x1, sp, #0xd8
    a614:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a618:	52800020 	mov	w0, #0x1                   	// #1
    a61c:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a620:	97ffea99 	bl	5084 <fwp_data.part.0.constprop.0>
    a624:	97ffed2c 	bl	5ad4 <fwp_rc_fresh>
    a628:	aa0003e2 	mov	x2, x0
    a62c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a630:	9103a3e1 	add	x1, sp, #0xe8
    a634:	52800020 	mov	w0, #0x1                   	// #1
    a638:	a90e8be3 	stp	x3, x2, [sp, #232]
    a63c:	97ffea92 	bl	5084 <fwp_data.part.0.constprop.0>
    a640:	91174283 	add	x3, x20, #0x5d0
    a644:	aa0003f5 	mov	x21, x0
    a648:	f949d861 	ldr	x1, [x3, #5040]
    a64c:	f949ec60 	ldr	x0, [x3, #5080]
    a650:	cb0102a1 	sub	x1, x21, x1
    a654:	eb00403f 	cmp	x1, x0, lsl #16
    a658:	54000322 	b.cs	a6bc <f0+0x4cc>  // b.hs, b.nlast
    a65c:	d350fc22 	lsr	x2, x1, #16
    a660:	f949fc63 	ldr	x3, [x3, #5112]
    a664:	8b020842 	add	x2, x2, x2, lsl #2
    a668:	d37df042 	lsl	x2, x2, #3
    a66c:	8b020060 	add	x0, x3, x2
    a670:	f9401017 	ldr	x23, [x0, #32]
    a674:	b4000257 	cbz	x23, a6bc <f0+0x4cc>
    a678:	38626862 	ldrb	w2, [x3, x2]
    a67c:	7100085f 	cmp	w2, #0x2
    a680:	5400f3c0 	b.eq	c4f8 <f0+0x2308>  // b.none
    a684:	7100045f 	cmp	w2, #0x1
    a688:	540001a1 	b.ne	a6bc <f0+0x4cc>  // b.any
    a68c:	29430002 	ldp	w2, w0, [x0, #24]
    a690:	92403c21 	and	x1, x1, #0xffff
    a694:	9b027c21 	mul	x1, x1, x2
    a698:	d360fc21 	lsr	x1, x1, #32
    a69c:	eb00003f 	cmp	x1, x0
    a6a0:	540000e2 	b.cs	a6bc <f0+0x4cc>  // b.hs, b.nlast
    a6a4:	8b0102f7 	add	x23, x23, x1
    a6a8:	394002e0 	ldrb	w0, [x23]
    a6ac:	7103fc1f 	cmp	w0, #0xff
    a6b0:	540101a0 	b.eq	c6e4 <f0+0x24f4>  // b.none
    a6b4:	52800020 	mov	w0, #0x1                   	// #1
    a6b8:	390002e0 	strb	w0, [x23]
    a6bc:	9103e3e1 	add	x1, sp, #0xf8
    a6c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a6c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a6c8:	52800020 	mov	w0, #0x1                   	// #1
    a6cc:	a90fd7f7 	stp	x23, x21, [sp, #248]
    a6d0:	97ffea6d 	bl	5084 <fwp_data.part.0.constprop.0>
    a6d4:	97ffed00 	bl	5ad4 <fwp_rc_fresh>
    a6d8:	aa0003e2 	mov	x2, x0
    a6dc:	910423e1 	add	x1, sp, #0x108
    a6e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a6e4:	52800020 	mov	w0, #0x1                   	// #1
    a6e8:	a9108bf5 	stp	x21, x2, [sp, #264]
    a6ec:	97ffea66 	bl	5084 <fwp_data.part.0.constprop.0>
    a6f0:	97ffecf9 	bl	5ad4 <fwp_rc_fresh>
    a6f4:	aa0003e2 	mov	x2, x0
    a6f8:	910463e1 	add	x1, sp, #0x118
    a6fc:	52800020 	mov	w0, #0x1                   	// #1
    a700:	a9118bf7 	stp	x23, x2, [sp, #280]
    a704:	97ffea60 	bl	5084 <fwp_data.part.0.constprop.0>
    a708:	97ffecf3 	bl	5ad4 <fwp_rc_fresh>
    a70c:	aa0003e2 	mov	x2, x0
    a710:	9104a3e1 	add	x1, sp, #0x128
    a714:	52800020 	mov	w0, #0x1                   	// #1
    a718:	a9128bf5 	stp	x21, x2, [sp, #296]
    a71c:	97ffea5a 	bl	5084 <fwp_data.part.0.constprop.0>
    a720:	91174283 	add	x3, x20, #0x5d0
    a724:	aa0003f5 	mov	x21, x0
    a728:	f949d861 	ldr	x1, [x3, #5040]
    a72c:	f949ec60 	ldr	x0, [x3, #5080]
    a730:	cb0102a1 	sub	x1, x21, x1
    a734:	eb00403f 	cmp	x1, x0, lsl #16
    a738:	54000322 	b.cs	a79c <f0+0x5ac>  // b.hs, b.nlast
    a73c:	d350fc22 	lsr	x2, x1, #16
    a740:	f949fc63 	ldr	x3, [x3, #5112]
    a744:	8b020842 	add	x2, x2, x2, lsl #2
    a748:	d37df042 	lsl	x2, x2, #3
    a74c:	8b020060 	add	x0, x3, x2
    a750:	f9401017 	ldr	x23, [x0, #32]
    a754:	b4000257 	cbz	x23, a79c <f0+0x5ac>
    a758:	38626862 	ldrb	w2, [x3, x2]
    a75c:	7100085f 	cmp	w2, #0x2
    a760:	5400ede0 	b.eq	c51c <f0+0x232c>  // b.none
    a764:	7100045f 	cmp	w2, #0x1
    a768:	540001a1 	b.ne	a79c <f0+0x5ac>  // b.any
    a76c:	29430002 	ldp	w2, w0, [x0, #24]
    a770:	92403c21 	and	x1, x1, #0xffff
    a774:	9b027c21 	mul	x1, x1, x2
    a778:	d360fc21 	lsr	x1, x1, #32
    a77c:	eb00003f 	cmp	x1, x0
    a780:	540000e2 	b.cs	a79c <f0+0x5ac>  // b.hs, b.nlast
    a784:	8b0102f7 	add	x23, x23, x1
    a788:	394002e0 	ldrb	w0, [x23]
    a78c:	7103fc1f 	cmp	w0, #0xff
    a790:	5400fb00 	b.eq	c6f0 <f0+0x2500>  // b.none
    a794:	52800020 	mov	w0, #0x1                   	// #1
    a798:	390002e0 	strb	w0, [x23]
    a79c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7a0:	9104e3e1 	add	x1, sp, #0x138
    a7a4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7a8:	52800020 	mov	w0, #0x1                   	// #1
    a7ac:	a913d7e2 	stp	x2, x21, [sp, #312]
    a7b0:	97ffea35 	bl	5084 <fwp_data.part.0.constprop.0>
    a7b4:	97ffecc8 	bl	5ad4 <fwp_rc_fresh>
    a7b8:	aa0003e2 	mov	x2, x0
    a7bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7c0:	910523e1 	add	x1, sp, #0x148
    a7c4:	52800020 	mov	w0, #0x1                   	// #1
    a7c8:	a9148be3 	stp	x3, x2, [sp, #328]
    a7cc:	97ffea2e 	bl	5084 <fwp_data.part.0.constprop.0>
    a7d0:	91174283 	add	x3, x20, #0x5d0
    a7d4:	aa0003f5 	mov	x21, x0
    a7d8:	f949d861 	ldr	x1, [x3, #5040]
    a7dc:	f949ec60 	ldr	x0, [x3, #5080]
    a7e0:	cb0102a1 	sub	x1, x21, x1
    a7e4:	eb00403f 	cmp	x1, x0, lsl #16
    a7e8:	54000322 	b.cs	a84c <f0+0x65c>  // b.hs, b.nlast
    a7ec:	d350fc22 	lsr	x2, x1, #16
    a7f0:	f949fc63 	ldr	x3, [x3, #5112]
    a7f4:	8b020842 	add	x2, x2, x2, lsl #2
    a7f8:	d37df042 	lsl	x2, x2, #3
    a7fc:	8b020060 	add	x0, x3, x2
    a800:	f9401017 	ldr	x23, [x0, #32]
    a804:	b4000257 	cbz	x23, a84c <f0+0x65c>
    a808:	38626862 	ldrb	w2, [x3, x2]
    a80c:	7100085f 	cmp	w2, #0x2
    a810:	5400e800 	b.eq	c510 <f0+0x2320>  // b.none
    a814:	7100045f 	cmp	w2, #0x1
    a818:	540001a1 	b.ne	a84c <f0+0x65c>  // b.any
    a81c:	29430002 	ldp	w2, w0, [x0, #24]
    a820:	92403c21 	and	x1, x1, #0xffff
    a824:	9b027c21 	mul	x1, x1, x2
    a828:	d360fc21 	lsr	x1, x1, #32
    a82c:	eb00003f 	cmp	x1, x0
    a830:	540000e2 	b.cs	a84c <f0+0x65c>  // b.hs, b.nlast
    a834:	8b0102f7 	add	x23, x23, x1
    a838:	394002e0 	ldrb	w0, [x23]
    a83c:	7103fc1f 	cmp	w0, #0xff
    a840:	5400f5e0 	b.eq	c6fc <f0+0x250c>  // b.none
    a844:	52800020 	mov	w0, #0x1                   	// #1
    a848:	390002e0 	strb	w0, [x23]
    a84c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a850:	910563e1 	add	x1, sp, #0x158
    a854:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a858:	52800020 	mov	w0, #0x1                   	// #1
    a85c:	a915d7e2 	stp	x2, x21, [sp, #344]
    a860:	97ffea09 	bl	5084 <fwp_data.part.0.constprop.0>
    a864:	97ffec9c 	bl	5ad4 <fwp_rc_fresh>
    a868:	aa0003e2 	mov	x2, x0
    a86c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a870:	9105a3e1 	add	x1, sp, #0x168
    a874:	52800020 	mov	w0, #0x1                   	// #1
    a878:	a9168be3 	stp	x3, x2, [sp, #360]
    a87c:	97ffea02 	bl	5084 <fwp_data.part.0.constprop.0>
    a880:	91174283 	add	x3, x20, #0x5d0
    a884:	aa0003f5 	mov	x21, x0
    a888:	f949d861 	ldr	x1, [x3, #5040]
    a88c:	f949ec60 	ldr	x0, [x3, #5080]
    a890:	cb0102a1 	sub	x1, x21, x1
    a894:	eb00403f 	cmp	x1, x0, lsl #16
    a898:	54000322 	b.cs	a8fc <f0+0x70c>  // b.hs, b.nlast
    a89c:	d350fc22 	lsr	x2, x1, #16
    a8a0:	f949fc63 	ldr	x3, [x3, #5112]
    a8a4:	8b020842 	add	x2, x2, x2, lsl #2
    a8a8:	d37df042 	lsl	x2, x2, #3
    a8ac:	8b020060 	add	x0, x3, x2
    a8b0:	f9401017 	ldr	x23, [x0, #32]
    a8b4:	b4000257 	cbz	x23, a8fc <f0+0x70c>
    a8b8:	38626862 	ldrb	w2, [x3, x2]
    a8bc:	7100085f 	cmp	w2, #0x2
    a8c0:	5400e9a0 	b.eq	c5f4 <f0+0x2404>  // b.none
    a8c4:	7100045f 	cmp	w2, #0x1
    a8c8:	540001a1 	b.ne	a8fc <f0+0x70c>  // b.any
    a8cc:	29430002 	ldp	w2, w0, [x0, #24]
    a8d0:	92403c21 	and	x1, x1, #0xffff
    a8d4:	9b027c21 	mul	x1, x1, x2
    a8d8:	d360fc21 	lsr	x1, x1, #32
    a8dc:	eb00003f 	cmp	x1, x0
    a8e0:	540000e2 	b.cs	a8fc <f0+0x70c>  // b.hs, b.nlast
    a8e4:	8b0102f7 	add	x23, x23, x1
    a8e8:	394002e0 	ldrb	w0, [x23]
    a8ec:	7103fc1f 	cmp	w0, #0xff
    a8f0:	5400f0c0 	b.eq	c708 <f0+0x2518>  // b.none
    a8f4:	52800020 	mov	w0, #0x1                   	// #1
    a8f8:	390002e0 	strb	w0, [x23]
    a8fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a900:	9105e3e1 	add	x1, sp, #0x178
    a904:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a908:	52800020 	mov	w0, #0x1                   	// #1
    a90c:	a917d7e2 	stp	x2, x21, [sp, #376]
    a910:	97ffe9dd 	bl	5084 <fwp_data.part.0.constprop.0>
    a914:	97ffec70 	bl	5ad4 <fwp_rc_fresh>
    a918:	aa0003e2 	mov	x2, x0
    a91c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a920:	910623e1 	add	x1, sp, #0x188
    a924:	52800020 	mov	w0, #0x1                   	// #1
    a928:	a9188be3 	stp	x3, x2, [sp, #392]
    a92c:	97ffe9d6 	bl	5084 <fwp_data.part.0.constprop.0>
    a930:	91174283 	add	x3, x20, #0x5d0
    a934:	aa0003f5 	mov	x21, x0
    a938:	f949d861 	ldr	x1, [x3, #5040]
    a93c:	f949ec60 	ldr	x0, [x3, #5080]
    a940:	cb0102a1 	sub	x1, x21, x1
    a944:	eb00403f 	cmp	x1, x0, lsl #16
    a948:	54000322 	b.cs	a9ac <f0+0x7bc>  // b.hs, b.nlast
    a94c:	d350fc22 	lsr	x2, x1, #16
    a950:	f949fc63 	ldr	x3, [x3, #5112]
    a954:	8b020842 	add	x2, x2, x2, lsl #2
    a958:	d37df042 	lsl	x2, x2, #3
    a95c:	8b020060 	add	x0, x3, x2
    a960:	f9401017 	ldr	x23, [x0, #32]
    a964:	b4000257 	cbz	x23, a9ac <f0+0x7bc>
    a968:	38626862 	ldrb	w2, [x3, x2]
    a96c:	7100085f 	cmp	w2, #0x2
    a970:	5400e3c0 	b.eq	c5e8 <f0+0x23f8>  // b.none
    a974:	7100045f 	cmp	w2, #0x1
    a978:	540001a1 	b.ne	a9ac <f0+0x7bc>  // b.any
    a97c:	29430002 	ldp	w2, w0, [x0, #24]
    a980:	92403c21 	and	x1, x1, #0xffff
    a984:	9b027c21 	mul	x1, x1, x2
    a988:	d360fc21 	lsr	x1, x1, #32
    a98c:	eb00003f 	cmp	x1, x0
    a990:	540000e2 	b.cs	a9ac <f0+0x7bc>  // b.hs, b.nlast
    a994:	8b0102f7 	add	x23, x23, x1
    a998:	394002e0 	ldrb	w0, [x23]
    a99c:	7103fc1f 	cmp	w0, #0xff
    a9a0:	5400eba0 	b.eq	c714 <f0+0x2524>  // b.none
    a9a4:	52800020 	mov	w0, #0x1                   	// #1
    a9a8:	390002e0 	strb	w0, [x23]
    a9ac:	910663e1 	add	x1, sp, #0x198
    a9b0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a9b4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	a919d7f7 	stp	x23, x21, [sp, #408]
    a9c0:	97ffe9b1 	bl	5084 <fwp_data.part.0.constprop.0>
    a9c4:	97ffec44 	bl	5ad4 <fwp_rc_fresh>
    a9c8:	aa0003e2 	mov	x2, x0
    a9cc:	9106a3e1 	add	x1, sp, #0x1a8
    a9d0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a9d4:	52800020 	mov	w0, #0x1                   	// #1
    a9d8:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a9dc:	97ffe9aa 	bl	5084 <fwp_data.part.0.constprop.0>
    a9e0:	97ffec3d 	bl	5ad4 <fwp_rc_fresh>
    a9e4:	aa0003e2 	mov	x2, x0
    a9e8:	9106e3e1 	add	x1, sp, #0x1b8
    a9ec:	52800020 	mov	w0, #0x1                   	// #1
    a9f0:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a9f4:	97ffe9a4 	bl	5084 <fwp_data.part.0.constprop.0>
    a9f8:	97ffec37 	bl	5ad4 <fwp_rc_fresh>
    a9fc:	aa0003e2 	mov	x2, x0
    aa00:	910723e1 	add	x1, sp, #0x1c8
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	a91c8bf5 	stp	x21, x2, [sp, #456]
    aa0c:	97ffe99e 	bl	5084 <fwp_data.part.0.constprop.0>
    aa10:	91174283 	add	x3, x20, #0x5d0
    aa14:	aa0003f5 	mov	x21, x0
    aa18:	f949d861 	ldr	x1, [x3, #5040]
    aa1c:	f949ec60 	ldr	x0, [x3, #5080]
    aa20:	cb0102a1 	sub	x1, x21, x1
    aa24:	eb00403f 	cmp	x1, x0, lsl #16
    aa28:	54000322 	b.cs	aa8c <f0+0x89c>  // b.hs, b.nlast
    aa2c:	d350fc22 	lsr	x2, x1, #16
    aa30:	f949fc63 	ldr	x3, [x3, #5112]
    aa34:	8b020842 	add	x2, x2, x2, lsl #2
    aa38:	d37df042 	lsl	x2, x2, #3
    aa3c:	8b020060 	add	x0, x3, x2
    aa40:	f9401017 	ldr	x23, [x0, #32]
    aa44:	b4000257 	cbz	x23, aa8c <f0+0x89c>
    aa48:	38626862 	ldrb	w2, [x3, x2]
    aa4c:	7100085f 	cmp	w2, #0x2
    aa50:	5400dde0 	b.eq	c60c <f0+0x241c>  // b.none
    aa54:	7100045f 	cmp	w2, #0x1
    aa58:	540001a1 	b.ne	aa8c <f0+0x89c>  // b.any
    aa5c:	29430002 	ldp	w2, w0, [x0, #24]
    aa60:	92403c21 	and	x1, x1, #0xffff
    aa64:	9b027c21 	mul	x1, x1, x2
    aa68:	d360fc21 	lsr	x1, x1, #32
    aa6c:	eb00003f 	cmp	x1, x0
    aa70:	540000e2 	b.cs	aa8c <f0+0x89c>  // b.hs, b.nlast
    aa74:	8b0102f7 	add	x23, x23, x1
    aa78:	394002e0 	ldrb	w0, [x23]
    aa7c:	7103fc1f 	cmp	w0, #0xff
    aa80:	5400e500 	b.eq	c720 <f0+0x2530>  // b.none
    aa84:	52800020 	mov	w0, #0x1                   	// #1
    aa88:	390002e0 	strb	w0, [x23]
    aa8c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa90:	910763e1 	add	x1, sp, #0x1d8
    aa94:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa98:	52800020 	mov	w0, #0x1                   	// #1
    aa9c:	a91dd7e2 	stp	x2, x21, [sp, #472]
    aaa0:	97ffe979 	bl	5084 <fwp_data.part.0.constprop.0>
    aaa4:	97ffec0c 	bl	5ad4 <fwp_rc_fresh>
    aaa8:	aa0003e2 	mov	x2, x0
    aaac:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aab0:	9107a3e1 	add	x1, sp, #0x1e8
    aab4:	52800020 	mov	w0, #0x1                   	// #1
    aab8:	a91e8be3 	stp	x3, x2, [sp, #488]
    aabc:	97ffe972 	bl	5084 <fwp_data.part.0.constprop.0>
    aac0:	91174283 	add	x3, x20, #0x5d0
    aac4:	aa0003f5 	mov	x21, x0
    aac8:	f949d861 	ldr	x1, [x3, #5040]
    aacc:	f949ec60 	ldr	x0, [x3, #5080]
    aad0:	cb0102a1 	sub	x1, x21, x1
    aad4:	eb00403f 	cmp	x1, x0, lsl #16
    aad8:	54000322 	b.cs	ab3c <f0+0x94c>  // b.hs, b.nlast
    aadc:	d350fc22 	lsr	x2, x1, #16
    aae0:	f949fc63 	ldr	x3, [x3, #5112]
    aae4:	8b020842 	add	x2, x2, x2, lsl #2
    aae8:	d37df042 	lsl	x2, x2, #3
    aaec:	8b020060 	add	x0, x3, x2
    aaf0:	f9401017 	ldr	x23, [x0, #32]
    aaf4:	b4000257 	cbz	x23, ab3c <f0+0x94c>
    aaf8:	38626862 	ldrb	w2, [x3, x2]
    aafc:	7100085f 	cmp	w2, #0x2
    ab00:	5400d800 	b.eq	c600 <f0+0x2410>  // b.none
    ab04:	7100045f 	cmp	w2, #0x1
    ab08:	540001a1 	b.ne	ab3c <f0+0x94c>  // b.any
    ab0c:	29430002 	ldp	w2, w0, [x0, #24]
    ab10:	92403c21 	and	x1, x1, #0xffff
    ab14:	9b027c21 	mul	x1, x1, x2
    ab18:	d360fc21 	lsr	x1, x1, #32
    ab1c:	eb00003f 	cmp	x1, x0
    ab20:	540000e2 	b.cs	ab3c <f0+0x94c>  // b.hs, b.nlast
    ab24:	8b0102f7 	add	x23, x23, x1
    ab28:	394002e0 	ldrb	w0, [x23]
    ab2c:	7103fc1f 	cmp	w0, #0xff
    ab30:	5400dfe0 	b.eq	c72c <f0+0x253c>  // b.none
    ab34:	52800020 	mov	w0, #0x1                   	// #1
    ab38:	390002e0 	strb	w0, [x23]
    ab3c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab40:	9107e3e1 	add	x1, sp, #0x1f8
    ab44:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab48:	52800020 	mov	w0, #0x1                   	// #1
    ab4c:	a91fd7e2 	stp	x2, x21, [sp, #504]
    ab50:	97ffe94d 	bl	5084 <fwp_data.part.0.constprop.0>
    ab54:	97ffebe0 	bl	5ad4 <fwp_rc_fresh>
    ab58:	aa0003e2 	mov	x2, x0
    ab5c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ab60:	910823e1 	add	x1, sp, #0x208
    ab64:	52800020 	mov	w0, #0x1                   	// #1
    ab68:	f90107e3 	str	x3, [sp, #520]
    ab6c:	f9010be2 	str	x2, [sp, #528]
    ab70:	97ffe945 	bl	5084 <fwp_data.part.0.constprop.0>
    ab74:	91174283 	add	x3, x20, #0x5d0
    ab78:	aa0003f5 	mov	x21, x0
    ab7c:	f949d861 	ldr	x1, [x3, #5040]
    ab80:	f949ec60 	ldr	x0, [x3, #5080]
    ab84:	cb0102a1 	sub	x1, x21, x1
    ab88:	eb00403f 	cmp	x1, x0, lsl #16
    ab8c:	54000322 	b.cs	abf0 <f0+0xa00>  // b.hs, b.nlast
    ab90:	d350fc22 	lsr	x2, x1, #16
    ab94:	f949fc63 	ldr	x3, [x3, #5112]
    ab98:	8b020842 	add	x2, x2, x2, lsl #2
    ab9c:	d37df042 	lsl	x2, x2, #3
    aba0:	8b020060 	add	x0, x3, x2
    aba4:	f9401017 	ldr	x23, [x0, #32]
    aba8:	b4000257 	cbz	x23, abf0 <f0+0xa00>
    abac:	38626862 	ldrb	w2, [x3, x2]
    abb0:	7100085f 	cmp	w2, #0x2
    abb4:	5400d380 	b.eq	c624 <f0+0x2434>  // b.none
    abb8:	7100045f 	cmp	w2, #0x1
    abbc:	540001a1 	b.ne	abf0 <f0+0xa00>  // b.any
    abc0:	29430002 	ldp	w2, w0, [x0, #24]
    abc4:	92403c21 	and	x1, x1, #0xffff
    abc8:	9b027c21 	mul	x1, x1, x2
    abcc:	d360fc21 	lsr	x1, x1, #32
    abd0:	eb00003f 	cmp	x1, x0
    abd4:	540000e2 	b.cs	abf0 <f0+0xa00>  // b.hs, b.nlast
    abd8:	8b0102f7 	add	x23, x23, x1
    abdc:	394002e0 	ldrb	w0, [x23]
    abe0:	7103fc1f 	cmp	w0, #0xff
    abe4:	5400daa0 	b.eq	c738 <f0+0x2548>  // b.none
    abe8:	52800020 	mov	w0, #0x1                   	// #1
    abec:	390002e0 	strb	w0, [x23]
    abf0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    abf4:	910863e1 	add	x1, sp, #0x218
    abf8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abfc:	52800020 	mov	w0, #0x1                   	// #1
    ac00:	f9010fe2 	str	x2, [sp, #536]
    ac04:	f90113f5 	str	x21, [sp, #544]
    ac08:	97ffe91f 	bl	5084 <fwp_data.part.0.constprop.0>
    ac0c:	97ffebb2 	bl	5ad4 <fwp_rc_fresh>
    ac10:	aa0003e2 	mov	x2, x0
    ac14:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ac18:	9108a3e1 	add	x1, sp, #0x228
    ac1c:	52800020 	mov	w0, #0x1                   	// #1
    ac20:	f90117e3 	str	x3, [sp, #552]
    ac24:	f9011be2 	str	x2, [sp, #560]
    ac28:	97ffe917 	bl	5084 <fwp_data.part.0.constprop.0>
    ac2c:	91174283 	add	x3, x20, #0x5d0
    ac30:	aa0003f5 	mov	x21, x0
    ac34:	f949d861 	ldr	x1, [x3, #5040]
    ac38:	f949ec60 	ldr	x0, [x3, #5080]
    ac3c:	cb0102a1 	sub	x1, x21, x1
    ac40:	eb00403f 	cmp	x1, x0, lsl #16
    ac44:	54000322 	b.cs	aca8 <f0+0xab8>  // b.hs, b.nlast
    ac48:	d350fc22 	lsr	x2, x1, #16
    ac4c:	f949fc63 	ldr	x3, [x3, #5112]
    ac50:	8b020842 	add	x2, x2, x2, lsl #2
    ac54:	d37df042 	lsl	x2, x2, #3
    ac58:	8b020060 	add	x0, x3, x2
    ac5c:	f9401017 	ldr	x23, [x0, #32]
    ac60:	b4000257 	cbz	x23, aca8 <f0+0xab8>
    ac64:	38626862 	ldrb	w2, [x3, x2]
    ac68:	7100085f 	cmp	w2, #0x2
    ac6c:	5400cd60 	b.eq	c618 <f0+0x2428>  // b.none
    ac70:	7100045f 	cmp	w2, #0x1
    ac74:	540001a1 	b.ne	aca8 <f0+0xab8>  // b.any
    ac78:	29430002 	ldp	w2, w0, [x0, #24]
    ac7c:	92403c21 	and	x1, x1, #0xffff
    ac80:	9b027c21 	mul	x1, x1, x2
    ac84:	d360fc21 	lsr	x1, x1, #32
    ac88:	eb00003f 	cmp	x1, x0
    ac8c:	540000e2 	b.cs	aca8 <f0+0xab8>  // b.hs, b.nlast
    ac90:	8b0102f7 	add	x23, x23, x1
    ac94:	394002e0 	ldrb	w0, [x23]
    ac98:	7103fc1f 	cmp	w0, #0xff
    ac9c:	5400d540 	b.eq	c744 <f0+0x2554>  // b.none
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	390002e0 	strb	w0, [x23]
    aca8:	9108e3e1 	add	x1, sp, #0x238
    acac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    acb0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    acb4:	52800020 	mov	w0, #0x1                   	// #1
    acb8:	f9011ff7 	str	x23, [sp, #568]
    acbc:	f90123f5 	str	x21, [sp, #576]
    acc0:	97ffe8f1 	bl	5084 <fwp_data.part.0.constprop.0>
    acc4:	97ffeb84 	bl	5ad4 <fwp_rc_fresh>
    acc8:	aa0003e2 	mov	x2, x0
    accc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    acd0:	910923e1 	add	x1, sp, #0x248
    acd4:	52800020 	mov	w0, #0x1                   	// #1
    acd8:	f90127e3 	str	x3, [sp, #584]
    acdc:	f9012be2 	str	x2, [sp, #592]
    ace0:	97ffe8e9 	bl	5084 <fwp_data.part.0.constprop.0>
    ace4:	97ffeb7c 	bl	5ad4 <fwp_rc_fresh>
    ace8:	aa0003e2 	mov	x2, x0
    acec:	910963e1 	add	x1, sp, #0x258
    acf0:	52800020 	mov	w0, #0x1                   	// #1
    acf4:	f9012ff7 	str	x23, [sp, #600]
    acf8:	f90133e2 	str	x2, [sp, #608]
    acfc:	97ffe8e2 	bl	5084 <fwp_data.part.0.constprop.0>
    ad00:	91174283 	add	x3, x20, #0x5d0
    ad04:	aa0003f5 	mov	x21, x0
    ad08:	f949d861 	ldr	x1, [x3, #5040]
    ad0c:	f949ec60 	ldr	x0, [x3, #5080]
    ad10:	cb0102a1 	sub	x1, x21, x1
    ad14:	eb00403f 	cmp	x1, x0, lsl #16
    ad18:	54000322 	b.cs	ad7c <f0+0xb8c>  // b.hs, b.nlast
    ad1c:	d350fc22 	lsr	x2, x1, #16
    ad20:	f949fc63 	ldr	x3, [x3, #5112]
    ad24:	8b020842 	add	x2, x2, x2, lsl #2
    ad28:	d37df042 	lsl	x2, x2, #3
    ad2c:	8b020060 	add	x0, x3, x2
    ad30:	f9401017 	ldr	x23, [x0, #32]
    ad34:	b4000257 	cbz	x23, ad7c <f0+0xb8c>
    ad38:	38626862 	ldrb	w2, [x3, x2]
    ad3c:	7100085f 	cmp	w2, #0x2
    ad40:	5400c7e0 	b.eq	c63c <f0+0x244c>  // b.none
    ad44:	7100045f 	cmp	w2, #0x1
    ad48:	540001a1 	b.ne	ad7c <f0+0xb8c>  // b.any
    ad4c:	29430002 	ldp	w2, w0, [x0, #24]
    ad50:	92403c21 	and	x1, x1, #0xffff
    ad54:	9b027c21 	mul	x1, x1, x2
    ad58:	d360fc21 	lsr	x1, x1, #32
    ad5c:	eb00003f 	cmp	x1, x0
    ad60:	540000e2 	b.cs	ad7c <f0+0xb8c>  // b.hs, b.nlast
    ad64:	8b0102f7 	add	x23, x23, x1
    ad68:	394002e0 	ldrb	w0, [x23]
    ad6c:	7103fc1f 	cmp	w0, #0xff
    ad70:	5400cf00 	b.eq	c750 <f0+0x2560>  // b.none
    ad74:	52800020 	mov	w0, #0x1                   	// #1
    ad78:	390002e0 	strb	w0, [x23]
    ad7c:	9109a3e1 	add	x1, sp, #0x268
    ad80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad84:	52800020 	mov	w0, #0x1                   	// #1
    ad88:	f90137f7 	str	x23, [sp, #616]
    ad8c:	f9013bf5 	str	x21, [sp, #624]
    ad90:	97ffe8bd 	bl	5084 <fwp_data.part.0.constprop.0>
    ad94:	97ffeb50 	bl	5ad4 <fwp_rc_fresh>
    ad98:	aa0003e2 	mov	x2, x0
    ad9c:	9109e3e1 	add	x1, sp, #0x278
    ada0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ada4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ada8:	52800020 	mov	w0, #0x1                   	// #1
    adac:	f9013ff5 	str	x21, [sp, #632]
    adb0:	f90143e2 	str	x2, [sp, #640]
    adb4:	97ffe8b4 	bl	5084 <fwp_data.part.0.constprop.0>
    adb8:	97ffeb47 	bl	5ad4 <fwp_rc_fresh>
    adbc:	aa0003e2 	mov	x2, x0
    adc0:	910a23e1 	add	x1, sp, #0x288
    adc4:	52800020 	mov	w0, #0x1                   	// #1
    adc8:	f90147f7 	str	x23, [sp, #648]
    adcc:	f9014be2 	str	x2, [sp, #656]
    add0:	97ffe8ad 	bl	5084 <fwp_data.part.0.constprop.0>
    add4:	97ffeb40 	bl	5ad4 <fwp_rc_fresh>
    add8:	aa0003e2 	mov	x2, x0
    addc:	910a63e1 	add	x1, sp, #0x298
    ade0:	52800020 	mov	w0, #0x1                   	// #1
    ade4:	f9014ff5 	str	x21, [sp, #664]
    ade8:	f90153e2 	str	x2, [sp, #672]
    adec:	97ffe8a6 	bl	5084 <fwp_data.part.0.constprop.0>
    adf0:	91174283 	add	x3, x20, #0x5d0
    adf4:	aa0003f5 	mov	x21, x0
    adf8:	f949d861 	ldr	x1, [x3, #5040]
    adfc:	f949ec60 	ldr	x0, [x3, #5080]
    ae00:	cb0102a1 	sub	x1, x21, x1
    ae04:	eb00403f 	cmp	x1, x0, lsl #16
    ae08:	54000322 	b.cs	ae6c <f0+0xc7c>  // b.hs, b.nlast
    ae0c:	d350fc22 	lsr	x2, x1, #16
    ae10:	f949fc63 	ldr	x3, [x3, #5112]
    ae14:	8b020842 	add	x2, x2, x2, lsl #2
    ae18:	d37df042 	lsl	x2, x2, #3
    ae1c:	8b020060 	add	x0, x3, x2
    ae20:	f9401017 	ldr	x23, [x0, #32]
    ae24:	b4000257 	cbz	x23, ae6c <f0+0xc7c>
    ae28:	38626862 	ldrb	w2, [x3, x2]
    ae2c:	7100085f 	cmp	w2, #0x2
    ae30:	5400c000 	b.eq	c630 <f0+0x2440>  // b.none
    ae34:	7100045f 	cmp	w2, #0x1
    ae38:	540001a1 	b.ne	ae6c <f0+0xc7c>  // b.any
    ae3c:	29430002 	ldp	w2, w0, [x0, #24]
    ae40:	92403c21 	and	x1, x1, #0xffff
    ae44:	9b027c21 	mul	x1, x1, x2
    ae48:	d360fc21 	lsr	x1, x1, #32
    ae4c:	eb00003f 	cmp	x1, x0
    ae50:	540000e2 	b.cs	ae6c <f0+0xc7c>  // b.hs, b.nlast
    ae54:	8b0102f7 	add	x23, x23, x1
    ae58:	394002e0 	ldrb	w0, [x23]
    ae5c:	7103fc1f 	cmp	w0, #0xff
    ae60:	5400c7e0 	b.eq	c75c <f0+0x256c>  // b.none
    ae64:	52800020 	mov	w0, #0x1                   	// #1
    ae68:	390002e0 	strb	w0, [x23]
    ae6c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae70:	910aa3e1 	add	x1, sp, #0x2a8
    ae74:	52800020 	mov	w0, #0x1                   	// #1
    ae78:	f90157e2 	str	x2, [sp, #680]
    ae7c:	f9015bf5 	str	x21, [sp, #688]
    ae80:	97ffe881 	bl	5084 <fwp_data.part.0.constprop.0>
    ae84:	91174283 	add	x3, x20, #0x5d0
    ae88:	aa0003f5 	mov	x21, x0
    ae8c:	f949d861 	ldr	x1, [x3, #5040]
    ae90:	f949ec60 	ldr	x0, [x3, #5080]
    ae94:	cb0102a1 	sub	x1, x21, x1
    ae98:	eb00403f 	cmp	x1, x0, lsl #16
    ae9c:	54000322 	b.cs	af00 <f0+0xd10>  // b.hs, b.nlast
    aea0:	d350fc22 	lsr	x2, x1, #16
    aea4:	f949fc63 	ldr	x3, [x3, #5112]
    aea8:	8b020842 	add	x2, x2, x2, lsl #2
    aeac:	d37df042 	lsl	x2, x2, #3
    aeb0:	8b020060 	add	x0, x3, x2
    aeb4:	f9401017 	ldr	x23, [x0, #32]
    aeb8:	b4000257 	cbz	x23, af00 <f0+0xd10>
    aebc:	38626862 	ldrb	w2, [x3, x2]
    aec0:	7100085f 	cmp	w2, #0x2
    aec4:	5400bc80 	b.eq	c654 <f0+0x2464>  // b.none
    aec8:	7100045f 	cmp	w2, #0x1
    aecc:	540001a1 	b.ne	af00 <f0+0xd10>  // b.any
    aed0:	29430002 	ldp	w2, w0, [x0, #24]
    aed4:	92403c21 	and	x1, x1, #0xffff
    aed8:	9b027c21 	mul	x1, x1, x2
    aedc:	d360fc21 	lsr	x1, x1, #32
    aee0:	eb00003f 	cmp	x1, x0
    aee4:	540000e2 	b.cs	af00 <f0+0xd10>  // b.hs, b.nlast
    aee8:	8b0102f7 	add	x23, x23, x1
    aeec:	394002e0 	ldrb	w0, [x23]
    aef0:	7103fc1f 	cmp	w0, #0xff
    aef4:	5400c3a0 	b.eq	c768 <f0+0x2578>  // b.none
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	390002e0 	strb	w0, [x23]
    af00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af04:	910ae3e1 	add	x1, sp, #0x2b8
    af08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af0c:	52800020 	mov	w0, #0x1                   	// #1
    af10:	f9015fe2 	str	x2, [sp, #696]
    af14:	f90163f5 	str	x21, [sp, #704]
    af18:	97ffe85b 	bl	5084 <fwp_data.part.0.constprop.0>
    af1c:	97ffeaee 	bl	5ad4 <fwp_rc_fresh>
    af20:	aa0003e2 	mov	x2, x0
    af24:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    af28:	910b23e1 	add	x1, sp, #0x2c8
    af2c:	52800020 	mov	w0, #0x1                   	// #1
    af30:	f90167e3 	str	x3, [sp, #712]
    af34:	f9016be2 	str	x2, [sp, #720]
    af38:	97ffe853 	bl	5084 <fwp_data.part.0.constprop.0>
    af3c:	91174283 	add	x3, x20, #0x5d0
    af40:	aa0003f5 	mov	x21, x0
    af44:	f949d861 	ldr	x1, [x3, #5040]
    af48:	f949ec60 	ldr	x0, [x3, #5080]
    af4c:	cb0102a1 	sub	x1, x21, x1
    af50:	eb00403f 	cmp	x1, x0, lsl #16
    af54:	54000322 	b.cs	afb8 <f0+0xdc8>  // b.hs, b.nlast
    af58:	d350fc22 	lsr	x2, x1, #16
    af5c:	f949fc63 	ldr	x3, [x3, #5112]
    af60:	8b020842 	add	x2, x2, x2, lsl #2
    af64:	d37df042 	lsl	x2, x2, #3
    af68:	8b020060 	add	x0, x3, x2
    af6c:	f9401017 	ldr	x23, [x0, #32]
    af70:	b4000257 	cbz	x23, afb8 <f0+0xdc8>
    af74:	38626862 	ldrb	w2, [x3, x2]
    af78:	7100085f 	cmp	w2, #0x2
    af7c:	5400b660 	b.eq	c648 <f0+0x2458>  // b.none
    af80:	7100045f 	cmp	w2, #0x1
    af84:	540001a1 	b.ne	afb8 <f0+0xdc8>  // b.any
    af88:	29430002 	ldp	w2, w0, [x0, #24]
    af8c:	92403c21 	and	x1, x1, #0xffff
    af90:	9b027c21 	mul	x1, x1, x2
    af94:	d360fc21 	lsr	x1, x1, #32
    af98:	eb00003f 	cmp	x1, x0
    af9c:	540000e2 	b.cs	afb8 <f0+0xdc8>  // b.hs, b.nlast
    afa0:	8b0102f7 	add	x23, x23, x1
    afa4:	394002e0 	ldrb	w0, [x23]
    afa8:	7103fc1f 	cmp	w0, #0xff
    afac:	5400be40 	b.eq	c774 <f0+0x2584>  // b.none
    afb0:	52800020 	mov	w0, #0x1                   	// #1
    afb4:	390002e0 	strb	w0, [x23]
    afb8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    afbc:	910b63e1 	add	x1, sp, #0x2d8
    afc0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    afc4:	52800020 	mov	w0, #0x1                   	// #1
    afc8:	f9016fe2 	str	x2, [sp, #728]
    afcc:	f90173f5 	str	x21, [sp, #736]
    afd0:	97ffe82d 	bl	5084 <fwp_data.part.0.constprop.0>
    afd4:	91174283 	add	x3, x20, #0x5d0
    afd8:	aa0003f5 	mov	x21, x0
    afdc:	f949d861 	ldr	x1, [x3, #5040]
    afe0:	f949ec60 	ldr	x0, [x3, #5080]
    afe4:	cb0102a1 	sub	x1, x21, x1
    afe8:	eb00403f 	cmp	x1, x0, lsl #16
    afec:	54000322 	b.cs	b050 <f0+0xe60>  // b.hs, b.nlast
    aff0:	d350fc22 	lsr	x2, x1, #16
    aff4:	f949fc63 	ldr	x3, [x3, #5112]
    aff8:	8b020842 	add	x2, x2, x2, lsl #2
    affc:	d37df042 	lsl	x2, x2, #3
    b000:	8b020060 	add	x0, x3, x2
    b004:	f9401017 	ldr	x23, [x0, #32]
    b008:	b4000257 	cbz	x23, b050 <f0+0xe60>
    b00c:	38626862 	ldrb	w2, [x3, x2]
    b010:	7100085f 	cmp	w2, #0x2
    b014:	5400b2c0 	b.eq	c66c <f0+0x247c>  // b.none
    b018:	7100045f 	cmp	w2, #0x1
    b01c:	540001a1 	b.ne	b050 <f0+0xe60>  // b.any
    b020:	29430002 	ldp	w2, w0, [x0, #24]
    b024:	92403c21 	and	x1, x1, #0xffff
    b028:	9b027c21 	mul	x1, x1, x2
    b02c:	d360fc21 	lsr	x1, x1, #32
    b030:	eb00003f 	cmp	x1, x0
    b034:	540000e2 	b.cs	b050 <f0+0xe60>  // b.hs, b.nlast
    b038:	8b0102f7 	add	x23, x23, x1
    b03c:	394002e0 	ldrb	w0, [x23]
    b040:	7103fc1f 	cmp	w0, #0xff
    b044:	5400b9e0 	b.eq	c780 <f0+0x2590>  // b.none
    b048:	52800020 	mov	w0, #0x1                   	// #1
    b04c:	390002e0 	strb	w0, [x23]
    b050:	910ba3e1 	add	x1, sp, #0x2e8
    b054:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b058:	52800020 	mov	w0, #0x1                   	// #1
    b05c:	f90177f7 	str	x23, [sp, #744]
    b060:	f9017bf5 	str	x21, [sp, #752]
    b064:	97ffe808 	bl	5084 <fwp_data.part.0.constprop.0>
    b068:	97ffea9b 	bl	5ad4 <fwp_rc_fresh>
    b06c:	aa0003e2 	mov	x2, x0
    b070:	910be3e1 	add	x1, sp, #0x2f8
    b074:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b078:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b07c:	52800020 	mov	w0, #0x1                   	// #1
    b080:	f9017ff5 	str	x21, [sp, #760]
    b084:	f90183e2 	str	x2, [sp, #768]
    b088:	97ffe7ff 	bl	5084 <fwp_data.part.0.constprop.0>
    b08c:	97ffea92 	bl	5ad4 <fwp_rc_fresh>
    b090:	aa0003e2 	mov	x2, x0
    b094:	910c23e1 	add	x1, sp, #0x308
    b098:	52800020 	mov	w0, #0x1                   	// #1
    b09c:	f90187f7 	str	x23, [sp, #776]
    b0a0:	f9018be2 	str	x2, [sp, #784]
    b0a4:	97ffe7f8 	bl	5084 <fwp_data.part.0.constprop.0>
    b0a8:	97ffea8b 	bl	5ad4 <fwp_rc_fresh>
    b0ac:	aa0003e2 	mov	x2, x0
    b0b0:	910c63e1 	add	x1, sp, #0x318
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	f9018ff5 	str	x21, [sp, #792]
    b0bc:	f90193e2 	str	x2, [sp, #800]
    b0c0:	97ffe7f1 	bl	5084 <fwp_data.part.0.constprop.0>
    b0c4:	91174283 	add	x3, x20, #0x5d0
    b0c8:	aa0003f7 	mov	x23, x0
    b0cc:	f949d861 	ldr	x1, [x3, #5040]
    b0d0:	f949ec60 	ldr	x0, [x3, #5080]
    b0d4:	cb0102e1 	sub	x1, x23, x1
    b0d8:	eb00403f 	cmp	x1, x0, lsl #16
    b0dc:	54000322 	b.cs	b140 <f0+0xf50>  // b.hs, b.nlast
    b0e0:	d350fc22 	lsr	x2, x1, #16
    b0e4:	f949fc63 	ldr	x3, [x3, #5112]
    b0e8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ec:	d37df042 	lsl	x2, x2, #3
    b0f0:	8b020060 	add	x0, x3, x2
    b0f4:	f9401015 	ldr	x21, [x0, #32]
    b0f8:	b4000255 	cbz	x21, b140 <f0+0xf50>
    b0fc:	38626862 	ldrb	w2, [x3, x2]
    b100:	7100085f 	cmp	w2, #0x2
    b104:	5400aae0 	b.eq	c660 <f0+0x2470>  // b.none
    b108:	7100045f 	cmp	w2, #0x1
    b10c:	540001a1 	b.ne	b140 <f0+0xf50>  // b.any
    b110:	29430002 	ldp	w2, w0, [x0, #24]
    b114:	92403c21 	and	x1, x1, #0xffff
    b118:	9b027c21 	mul	x1, x1, x2
    b11c:	d360fc21 	lsr	x1, x1, #32
    b120:	eb00003f 	cmp	x1, x0
    b124:	540000e2 	b.cs	b140 <f0+0xf50>  // b.hs, b.nlast
    b128:	8b0102b5 	add	x21, x21, x1
    b12c:	394002a0 	ldrb	w0, [x21]
    b130:	7103fc1f 	cmp	w0, #0xff
    b134:	5400b2c0 	b.eq	c78c <f0+0x259c>  // b.none
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	390002a0 	strb	w0, [x21]
    b140:	910ca3e1 	add	x1, sp, #0x328
    b144:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b148:	52800020 	mov	w0, #0x1                   	// #1
    b14c:	f90197f5 	str	x21, [sp, #808]
    b150:	f9019bf7 	str	x23, [sp, #816]
    b154:	97ffe7cc 	bl	5084 <fwp_data.part.0.constprop.0>
    b158:	97ffea5f 	bl	5ad4 <fwp_rc_fresh>
    b15c:	aa0003e2 	mov	x2, x0
    b160:	910ce3e1 	add	x1, sp, #0x338
    b164:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b168:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b16c:	52800020 	mov	w0, #0x1                   	// #1
    b170:	f9019ff7 	str	x23, [sp, #824]
    b174:	f901a3e2 	str	x2, [sp, #832]
    b178:	97ffe7c3 	bl	5084 <fwp_data.part.0.constprop.0>
    b17c:	97ffea56 	bl	5ad4 <fwp_rc_fresh>
    b180:	aa0003e2 	mov	x2, x0
    b184:	910d23e1 	add	x1, sp, #0x348
    b188:	52800020 	mov	w0, #0x1                   	// #1
    b18c:	f901a7f5 	str	x21, [sp, #840]
    b190:	f901abe2 	str	x2, [sp, #848]
    b194:	97ffe7bc 	bl	5084 <fwp_data.part.0.constprop.0>
    b198:	97ffea4f 	bl	5ad4 <fwp_rc_fresh>
    b19c:	aa0003e2 	mov	x2, x0
    b1a0:	910d63e1 	add	x1, sp, #0x358
    b1a4:	52800020 	mov	w0, #0x1                   	// #1
    b1a8:	f901aff7 	str	x23, [sp, #856]
    b1ac:	f901b3e2 	str	x2, [sp, #864]
    b1b0:	97ffe7b5 	bl	5084 <fwp_data.part.0.constprop.0>
    b1b4:	97ffea48 	bl	5ad4 <fwp_rc_fresh>
    b1b8:	aa0003e2 	mov	x2, x0
    b1bc:	910da3e1 	add	x1, sp, #0x368
    b1c0:	52800020 	mov	w0, #0x1                   	// #1
    b1c4:	f901b7f5 	str	x21, [sp, #872]
    b1c8:	f901bbe2 	str	x2, [sp, #880]
    b1cc:	97ffe7ae 	bl	5084 <fwp_data.part.0.constprop.0>
    b1d0:	97ffea41 	bl	5ad4 <fwp_rc_fresh>
    b1d4:	aa0003e2 	mov	x2, x0
    b1d8:	910de3e1 	add	x1, sp, #0x378
    b1dc:	52800020 	mov	w0, #0x1                   	// #1
    b1e0:	f901bff7 	str	x23, [sp, #888]
    b1e4:	f901c3e2 	str	x2, [sp, #896]
    b1e8:	97ffe7a7 	bl	5084 <fwp_data.part.0.constprop.0>
    b1ec:	97ffea3a 	bl	5ad4 <fwp_rc_fresh>
    b1f0:	aa0003e2 	mov	x2, x0
    b1f4:	910e23e1 	add	x1, sp, #0x388
    b1f8:	52800020 	mov	w0, #0x1                   	// #1
    b1fc:	f901c7f5 	str	x21, [sp, #904]
    b200:	f901cbe2 	str	x2, [sp, #912]
    b204:	97ffe7a0 	bl	5084 <fwp_data.part.0.constprop.0>
    b208:	97ffea33 	bl	5ad4 <fwp_rc_fresh>
    b20c:	aa0003e2 	mov	x2, x0
    b210:	910e63e1 	add	x1, sp, #0x398
    b214:	52800020 	mov	w0, #0x1                   	// #1
    b218:	f901cff7 	str	x23, [sp, #920]
    b21c:	f901d3e2 	str	x2, [sp, #928]
    b220:	97ffe799 	bl	5084 <fwp_data.part.0.constprop.0>
    b224:	97ffea2c 	bl	5ad4 <fwp_rc_fresh>
    b228:	aa0003e2 	mov	x2, x0
    b22c:	910ea3e1 	add	x1, sp, #0x3a8
    b230:	52800020 	mov	w0, #0x1                   	// #1
    b234:	f901d7f5 	str	x21, [sp, #936]
    b238:	f901dbe2 	str	x2, [sp, #944]
    b23c:	97ffe792 	bl	5084 <fwp_data.part.0.constprop.0>
    b240:	97ffea25 	bl	5ad4 <fwp_rc_fresh>
    b244:	aa0003e2 	mov	x2, x0
    b248:	910ee3e1 	add	x1, sp, #0x3b8
    b24c:	52800020 	mov	w0, #0x1                   	// #1
    b250:	f901dff7 	str	x23, [sp, #952]
    b254:	f901e3e2 	str	x2, [sp, #960]
    b258:	97ffe78b 	bl	5084 <fwp_data.part.0.constprop.0>
    b25c:	97ffea1e 	bl	5ad4 <fwp_rc_fresh>
    b260:	aa0003e2 	mov	x2, x0
    b264:	910f23e1 	add	x1, sp, #0x3c8
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	f901e7f5 	str	x21, [sp, #968]
    b270:	f901ebe2 	str	x2, [sp, #976]
    b274:	97ffe784 	bl	5084 <fwp_data.part.0.constprop.0>
    b278:	97ffea17 	bl	5ad4 <fwp_rc_fresh>
    b27c:	aa0003e2 	mov	x2, x0
    b280:	910f63e1 	add	x1, sp, #0x3d8
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	f901eff7 	str	x23, [sp, #984]
    b28c:	f901f3e2 	str	x2, [sp, #992]
    b290:	97ffe77d 	bl	5084 <fwp_data.part.0.constprop.0>
    b294:	97ffea10 	bl	5ad4 <fwp_rc_fresh>
    b298:	aa0003e2 	mov	x2, x0
    b29c:	910fa3e1 	add	x1, sp, #0x3e8
    b2a0:	52800020 	mov	w0, #0x1                   	// #1
    b2a4:	f901f7f5 	str	x21, [sp, #1000]
    b2a8:	f901fbe2 	str	x2, [sp, #1008]
    b2ac:	97ffe776 	bl	5084 <fwp_data.part.0.constprop.0>
    b2b0:	91174283 	add	x3, x20, #0x5d0
    b2b4:	aa0003f5 	mov	x21, x0
    b2b8:	f949d861 	ldr	x1, [x3, #5040]
    b2bc:	f949ec60 	ldr	x0, [x3, #5080]
    b2c0:	cb0102a1 	sub	x1, x21, x1
    b2c4:	eb00403f 	cmp	x1, x0, lsl #16
    b2c8:	54000322 	b.cs	b32c <f0+0x113c>  // b.hs, b.nlast
    b2cc:	d350fc22 	lsr	x2, x1, #16
    b2d0:	f949fc63 	ldr	x3, [x3, #5112]
    b2d4:	8b020842 	add	x2, x2, x2, lsl #2
    b2d8:	d37df042 	lsl	x2, x2, #3
    b2dc:	8b020060 	add	x0, x3, x2
    b2e0:	f9401017 	ldr	x23, [x0, #32]
    b2e4:	b4000257 	cbz	x23, b32c <f0+0x113c>
    b2e8:	38626862 	ldrb	w2, [x3, x2]
    b2ec:	7100085f 	cmp	w2, #0x2
    b2f0:	54009ca0 	b.eq	c684 <f0+0x2494>  // b.none
    b2f4:	7100045f 	cmp	w2, #0x1
    b2f8:	540001a1 	b.ne	b32c <f0+0x113c>  // b.any
    b2fc:	29430002 	ldp	w2, w0, [x0, #24]
    b300:	92403c21 	and	x1, x1, #0xffff
    b304:	9b027c21 	mul	x1, x1, x2
    b308:	d360fc21 	lsr	x1, x1, #32
    b30c:	eb00003f 	cmp	x1, x0
    b310:	540000e2 	b.cs	b32c <f0+0x113c>  // b.hs, b.nlast
    b314:	8b0102f7 	add	x23, x23, x1
    b318:	394002e0 	ldrb	w0, [x23]
    b31c:	7103fc1f 	cmp	w0, #0xff
    b320:	5400a3c0 	b.eq	c798 <f0+0x25a8>  // b.none
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	390002e0 	strb	w0, [x23]
    b32c:	910fe3e1 	add	x1, sp, #0x3f8
    b330:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b334:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b338:	52800020 	mov	w0, #0x1                   	// #1
    b33c:	f901fff7 	str	x23, [sp, #1016]
    b340:	f90203f5 	str	x21, [sp, #1024]
    b344:	97ffe750 	bl	5084 <fwp_data.part.0.constprop.0>
    b348:	97ffe9e3 	bl	5ad4 <fwp_rc_fresh>
    b34c:	aa0003e2 	mov	x2, x0
    b350:	911023e1 	add	x1, sp, #0x408
    b354:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b358:	52800020 	mov	w0, #0x1                   	// #1
    b35c:	f90207f5 	str	x21, [sp, #1032]
    b360:	f9020be2 	str	x2, [sp, #1040]
    b364:	97ffe748 	bl	5084 <fwp_data.part.0.constprop.0>
    b368:	97ffe9db 	bl	5ad4 <fwp_rc_fresh>
    b36c:	aa0003e2 	mov	x2, x0
    b370:	911063e1 	add	x1, sp, #0x418
    b374:	52800020 	mov	w0, #0x1                   	// #1
    b378:	f9020ff7 	str	x23, [sp, #1048]
    b37c:	f90213e2 	str	x2, [sp, #1056]
    b380:	97ffe741 	bl	5084 <fwp_data.part.0.constprop.0>
    b384:	97ffe9d4 	bl	5ad4 <fwp_rc_fresh>
    b388:	aa0003e2 	mov	x2, x0
    b38c:	9110a3e1 	add	x1, sp, #0x428
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f90217f5 	str	x21, [sp, #1064]
    b398:	f9021be2 	str	x2, [sp, #1072]
    b39c:	97ffe73a 	bl	5084 <fwp_data.part.0.constprop.0>
    b3a0:	97ffe9cd 	bl	5ad4 <fwp_rc_fresh>
    b3a4:	aa0003e2 	mov	x2, x0
    b3a8:	9110e3e1 	add	x1, sp, #0x438
    b3ac:	52800020 	mov	w0, #0x1                   	// #1
    b3b0:	f9021ff7 	str	x23, [sp, #1080]
    b3b4:	f90223e2 	str	x2, [sp, #1088]
    b3b8:	97ffe733 	bl	5084 <fwp_data.part.0.constprop.0>
    b3bc:	97ffe9c6 	bl	5ad4 <fwp_rc_fresh>
    b3c0:	aa0003e2 	mov	x2, x0
    b3c4:	911123e1 	add	x1, sp, #0x448
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	f90227f5 	str	x21, [sp, #1096]
    b3d0:	f9022be2 	str	x2, [sp, #1104]
    b3d4:	97ffe72c 	bl	5084 <fwp_data.part.0.constprop.0>
    b3d8:	91174283 	add	x3, x20, #0x5d0
    b3dc:	aa0003f5 	mov	x21, x0
    b3e0:	f949d861 	ldr	x1, [x3, #5040]
    b3e4:	f949ec60 	ldr	x0, [x3, #5080]
    b3e8:	cb0102a1 	sub	x1, x21, x1
    b3ec:	eb00403f 	cmp	x1, x0, lsl #16
    b3f0:	54000322 	b.cs	b454 <f0+0x1264>  // b.hs, b.nlast
    b3f4:	d350fc22 	lsr	x2, x1, #16
    b3f8:	f949fc63 	ldr	x3, [x3, #5112]
    b3fc:	8b020842 	add	x2, x2, x2, lsl #2
    b400:	d37df042 	lsl	x2, x2, #3
    b404:	8b020060 	add	x0, x3, x2
    b408:	f9401017 	ldr	x23, [x0, #32]
    b40c:	b4000257 	cbz	x23, b454 <f0+0x1264>
    b410:	38626862 	ldrb	w2, [x3, x2]
    b414:	7100085f 	cmp	w2, #0x2
    b418:	54009300 	b.eq	c678 <f0+0x2488>  // b.none
    b41c:	7100045f 	cmp	w2, #0x1
    b420:	540001a1 	b.ne	b454 <f0+0x1264>  // b.any
    b424:	29430002 	ldp	w2, w0, [x0, #24]
    b428:	92403c21 	and	x1, x1, #0xffff
    b42c:	9b027c21 	mul	x1, x1, x2
    b430:	d360fc21 	lsr	x1, x1, #32
    b434:	eb00003f 	cmp	x1, x0
    b438:	540000e2 	b.cs	b454 <f0+0x1264>  // b.hs, b.nlast
    b43c:	8b0102f7 	add	x23, x23, x1
    b440:	394002e0 	ldrb	w0, [x23]
    b444:	7103fc1f 	cmp	w0, #0xff
    b448:	54009ae0 	b.eq	c7a4 <f0+0x25b4>  // b.none
    b44c:	52800020 	mov	w0, #0x1                   	// #1
    b450:	390002e0 	strb	w0, [x23]
    b454:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b458:	911163e1 	add	x1, sp, #0x458
    b45c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b460:	52800020 	mov	w0, #0x1                   	// #1
    b464:	f9022fe2 	str	x2, [sp, #1112]
    b468:	f90233f5 	str	x21, [sp, #1120]
    b46c:	97ffe706 	bl	5084 <fwp_data.part.0.constprop.0>
    b470:	97ffe999 	bl	5ad4 <fwp_rc_fresh>
    b474:	aa0003e2 	mov	x2, x0
    b478:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b47c:	9111a3e1 	add	x1, sp, #0x468
    b480:	52800020 	mov	w0, #0x1                   	// #1
    b484:	f90237e3 	str	x3, [sp, #1128]
    b488:	f9023be2 	str	x2, [sp, #1136]
    b48c:	97ffe6fe 	bl	5084 <fwp_data.part.0.constprop.0>
    b490:	91174283 	add	x3, x20, #0x5d0
    b494:	aa0003f5 	mov	x21, x0
    b498:	f949d861 	ldr	x1, [x3, #5040]
    b49c:	f949ec60 	ldr	x0, [x3, #5080]
    b4a0:	cb0102a1 	sub	x1, x21, x1
    b4a4:	eb00403f 	cmp	x1, x0, lsl #16
    b4a8:	54000322 	b.cs	b50c <f0+0x131c>  // b.hs, b.nlast
    b4ac:	d350fc22 	lsr	x2, x1, #16
    b4b0:	f949fc63 	ldr	x3, [x3, #5112]
    b4b4:	8b020842 	add	x2, x2, x2, lsl #2
    b4b8:	d37df042 	lsl	x2, x2, #3
    b4bc:	8b020060 	add	x0, x3, x2
    b4c0:	f9401017 	ldr	x23, [x0, #32]
    b4c4:	b4000257 	cbz	x23, b50c <f0+0x131c>
    b4c8:	38626862 	ldrb	w2, [x3, x2]
    b4cc:	7100085f 	cmp	w2, #0x2
    b4d0:	54008e60 	b.eq	c69c <f0+0x24ac>  // b.none
    b4d4:	7100045f 	cmp	w2, #0x1
    b4d8:	540001a1 	b.ne	b50c <f0+0x131c>  // b.any
    b4dc:	29430002 	ldp	w2, w0, [x0, #24]
    b4e0:	92403c21 	and	x1, x1, #0xffff
    b4e4:	9b027c21 	mul	x1, x1, x2
    b4e8:	d360fc21 	lsr	x1, x1, #32
    b4ec:	eb00003f 	cmp	x1, x0
    b4f0:	540000e2 	b.cs	b50c <f0+0x131c>  // b.hs, b.nlast
    b4f4:	8b0102f7 	add	x23, x23, x1
    b4f8:	394002e0 	ldrb	w0, [x23]
    b4fc:	7103fc1f 	cmp	w0, #0xff
    b500:	54009580 	b.eq	c7b0 <f0+0x25c0>  // b.none
    b504:	52800020 	mov	w0, #0x1                   	// #1
    b508:	390002e0 	strb	w0, [x23]
    b50c:	9111e3e1 	add	x1, sp, #0x478
    b510:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b514:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b518:	52800020 	mov	w0, #0x1                   	// #1
    b51c:	f9023ff7 	str	x23, [sp, #1144]
    b520:	f90243f5 	str	x21, [sp, #1152]
    b524:	97ffe6d8 	bl	5084 <fwp_data.part.0.constprop.0>
    b528:	97ffe96b 	bl	5ad4 <fwp_rc_fresh>
    b52c:	aa0003e2 	mov	x2, x0
    b530:	911223e1 	add	x1, sp, #0x488
    b534:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b538:	52800020 	mov	w0, #0x1                   	// #1
    b53c:	f90247f5 	str	x21, [sp, #1160]
    b540:	f9024be2 	str	x2, [sp, #1168]
    b544:	97ffe6d0 	bl	5084 <fwp_data.part.0.constprop.0>
    b548:	97ffe963 	bl	5ad4 <fwp_rc_fresh>
    b54c:	aa0003e2 	mov	x2, x0
    b550:	911263e1 	add	x1, sp, #0x498
    b554:	52800020 	mov	w0, #0x1                   	// #1
    b558:	f9024ff7 	str	x23, [sp, #1176]
    b55c:	f90253e2 	str	x2, [sp, #1184]
    b560:	97ffe6c9 	bl	5084 <fwp_data.part.0.constprop.0>
    b564:	97ffe95c 	bl	5ad4 <fwp_rc_fresh>
    b568:	aa0003e2 	mov	x2, x0
    b56c:	9112a3e1 	add	x1, sp, #0x4a8
    b570:	52800020 	mov	w0, #0x1                   	// #1
    b574:	f90257f5 	str	x21, [sp, #1192]
    b578:	f9025be2 	str	x2, [sp, #1200]
    b57c:	97ffe6c2 	bl	5084 <fwp_data.part.0.constprop.0>
    b580:	91174283 	add	x3, x20, #0x5d0
    b584:	aa0003f5 	mov	x21, x0
    b588:	f949d861 	ldr	x1, [x3, #5040]
    b58c:	f949ec60 	ldr	x0, [x3, #5080]
    b590:	cb0102a1 	sub	x1, x21, x1
    b594:	eb00403f 	cmp	x1, x0, lsl #16
    b598:	54000322 	b.cs	b5fc <f0+0x140c>  // b.hs, b.nlast
    b59c:	d350fc22 	lsr	x2, x1, #16
    b5a0:	f949fc63 	ldr	x3, [x3, #5112]
    b5a4:	8b020842 	add	x2, x2, x2, lsl #2
    b5a8:	d37df042 	lsl	x2, x2, #3
    b5ac:	8b020060 	add	x0, x3, x2
    b5b0:	f9401017 	ldr	x23, [x0, #32]
    b5b4:	b4000257 	cbz	x23, b5fc <f0+0x140c>
    b5b8:	38626862 	ldrb	w2, [x3, x2]
    b5bc:	7100085f 	cmp	w2, #0x2
    b5c0:	54008680 	b.eq	c690 <f0+0x24a0>  // b.none
    b5c4:	7100045f 	cmp	w2, #0x1
    b5c8:	540001a1 	b.ne	b5fc <f0+0x140c>  // b.any
    b5cc:	29430002 	ldp	w2, w0, [x0, #24]
    b5d0:	92403c21 	and	x1, x1, #0xffff
    b5d4:	9b027c21 	mul	x1, x1, x2
    b5d8:	d360fc21 	lsr	x1, x1, #32
    b5dc:	eb00003f 	cmp	x1, x0
    b5e0:	540000e2 	b.cs	b5fc <f0+0x140c>  // b.hs, b.nlast
    b5e4:	8b0102f7 	add	x23, x23, x1
    b5e8:	394002e0 	ldrb	w0, [x23]
    b5ec:	7103fc1f 	cmp	w0, #0xff
    b5f0:	54008e60 	b.eq	c7bc <f0+0x25cc>  // b.none
    b5f4:	52800020 	mov	w0, #0x1                   	// #1
    b5f8:	390002e0 	strb	w0, [x23]
    b5fc:	9112e3e1 	add	x1, sp, #0x4b8
    b600:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b604:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b608:	52800020 	mov	w0, #0x1                   	// #1
    b60c:	f9025ff7 	str	x23, [sp, #1208]
    b610:	f90263f5 	str	x21, [sp, #1216]
    b614:	97ffe69c 	bl	5084 <fwp_data.part.0.constprop.0>
    b618:	97ffe92f 	bl	5ad4 <fwp_rc_fresh>
    b61c:	aa0003e2 	mov	x2, x0
    b620:	911323e1 	add	x1, sp, #0x4c8
    b624:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b628:	52800020 	mov	w0, #0x1                   	// #1
    b62c:	f90267f5 	str	x21, [sp, #1224]
    b630:	f9026be2 	str	x2, [sp, #1232]
    b634:	97ffe694 	bl	5084 <fwp_data.part.0.constprop.0>
    b638:	97ffe927 	bl	5ad4 <fwp_rc_fresh>
    b63c:	aa0003e2 	mov	x2, x0
    b640:	911363e1 	add	x1, sp, #0x4d8
    b644:	52800020 	mov	w0, #0x1                   	// #1
    b648:	f9026ff7 	str	x23, [sp, #1240]
    b64c:	f90273e2 	str	x2, [sp, #1248]
    b650:	97ffe68d 	bl	5084 <fwp_data.part.0.constprop.0>
    b654:	97ffe920 	bl	5ad4 <fwp_rc_fresh>
    b658:	aa0003e2 	mov	x2, x0
    b65c:	9113a3e1 	add	x1, sp, #0x4e8
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	f90277f5 	str	x21, [sp, #1256]
    b668:	f9027be2 	str	x2, [sp, #1264]
    b66c:	97ffe686 	bl	5084 <fwp_data.part.0.constprop.0>
    b670:	91174283 	add	x3, x20, #0x5d0
    b674:	aa0003f5 	mov	x21, x0
    b678:	f949d861 	ldr	x1, [x3, #5040]
    b67c:	f949ec60 	ldr	x0, [x3, #5080]
    b680:	cb0102a1 	sub	x1, x21, x1
    b684:	eb00403f 	cmp	x1, x0, lsl #16
    b688:	54000322 	b.cs	b6ec <f0+0x14fc>  // b.hs, b.nlast
    b68c:	d350fc22 	lsr	x2, x1, #16
    b690:	f949fc63 	ldr	x3, [x3, #5112]
    b694:	8b020842 	add	x2, x2, x2, lsl #2
    b698:	d37df042 	lsl	x2, x2, #3
    b69c:	8b020060 	add	x0, x3, x2
    b6a0:	f9401017 	ldr	x23, [x0, #32]
    b6a4:	b4000257 	cbz	x23, b6ec <f0+0x14fc>
    b6a8:	38626862 	ldrb	w2, [x3, x2]
    b6ac:	7100085f 	cmp	w2, #0x2
    b6b0:	54007420 	b.eq	c534 <f0+0x2344>  // b.none
    b6b4:	7100045f 	cmp	w2, #0x1
    b6b8:	540001a1 	b.ne	b6ec <f0+0x14fc>  // b.any
    b6bc:	29430002 	ldp	w2, w0, [x0, #24]
    b6c0:	92403c21 	and	x1, x1, #0xffff
    b6c4:	9b027c21 	mul	x1, x1, x2
    b6c8:	d360fc21 	lsr	x1, x1, #32
    b6cc:	eb00003f 	cmp	x1, x0
    b6d0:	540000e2 	b.cs	b6ec <f0+0x14fc>  // b.hs, b.nlast
    b6d4:	8b0102f7 	add	x23, x23, x1
    b6d8:	394002e0 	ldrb	w0, [x23]
    b6dc:	7103fc1f 	cmp	w0, #0xff
    b6e0:	54008740 	b.eq	c7c8 <f0+0x25d8>  // b.none
    b6e4:	52800020 	mov	w0, #0x1                   	// #1
    b6e8:	390002e0 	strb	w0, [x23]
    b6ec:	9113e3e1 	add	x1, sp, #0x4f8
    b6f0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b6f4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b6f8:	52800020 	mov	w0, #0x1                   	// #1
    b6fc:	f9027ff7 	str	x23, [sp, #1272]
    b700:	f90283f5 	str	x21, [sp, #1280]
    b704:	97ffe660 	bl	5084 <fwp_data.part.0.constprop.0>
    b708:	97ffe8f3 	bl	5ad4 <fwp_rc_fresh>
    b70c:	aa0003e2 	mov	x2, x0
    b710:	911423e1 	add	x1, sp, #0x508
    b714:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b718:	52800020 	mov	w0, #0x1                   	// #1
    b71c:	f90287f5 	str	x21, [sp, #1288]
    b720:	f9028be2 	str	x2, [sp, #1296]
    b724:	97ffe658 	bl	5084 <fwp_data.part.0.constprop.0>
    b728:	97ffe8eb 	bl	5ad4 <fwp_rc_fresh>
    b72c:	aa0003e2 	mov	x2, x0
    b730:	911463e1 	add	x1, sp, #0x518
    b734:	52800020 	mov	w0, #0x1                   	// #1
    b738:	f9028ff7 	str	x23, [sp, #1304]
    b73c:	f90293e2 	str	x2, [sp, #1312]
    b740:	97ffe651 	bl	5084 <fwp_data.part.0.constprop.0>
    b744:	97ffe8e4 	bl	5ad4 <fwp_rc_fresh>
    b748:	aa0003e2 	mov	x2, x0
    b74c:	9114a3e1 	add	x1, sp, #0x528
    b750:	52800020 	mov	w0, #0x1                   	// #1
    b754:	f90297f5 	str	x21, [sp, #1320]
    b758:	f9029be2 	str	x2, [sp, #1328]
    b75c:	97ffe64a 	bl	5084 <fwp_data.part.0.constprop.0>
    b760:	97ffe8dd 	bl	5ad4 <fwp_rc_fresh>
    b764:	aa0003e2 	mov	x2, x0
    b768:	9114e3e1 	add	x1, sp, #0x538
    b76c:	52800020 	mov	w0, #0x1                   	// #1
    b770:	f9029ff7 	str	x23, [sp, #1336]
    b774:	f902a3e2 	str	x2, [sp, #1344]
    b778:	97ffe643 	bl	5084 <fwp_data.part.0.constprop.0>
    b77c:	97ffe8d6 	bl	5ad4 <fwp_rc_fresh>
    b780:	aa0003e2 	mov	x2, x0
    b784:	911523e1 	add	x1, sp, #0x548
    b788:	52800020 	mov	w0, #0x1                   	// #1
    b78c:	f902a7f5 	str	x21, [sp, #1352]
    b790:	f902abe2 	str	x2, [sp, #1360]
    b794:	97ffe63c 	bl	5084 <fwp_data.part.0.constprop.0>
    b798:	97ffe8cf 	bl	5ad4 <fwp_rc_fresh>
    b79c:	aa0003e2 	mov	x2, x0
    b7a0:	911563e1 	add	x1, sp, #0x558
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	f902aff7 	str	x23, [sp, #1368]
    b7ac:	f902b3e2 	str	x2, [sp, #1376]
    b7b0:	97ffe635 	bl	5084 <fwp_data.part.0.constprop.0>
    b7b4:	97ffe8c8 	bl	5ad4 <fwp_rc_fresh>
    b7b8:	aa0003e2 	mov	x2, x0
    b7bc:	9115a3e1 	add	x1, sp, #0x568
    b7c0:	52800020 	mov	w0, #0x1                   	// #1
    b7c4:	f902b7f5 	str	x21, [sp, #1384]
    b7c8:	f902bbe2 	str	x2, [sp, #1392]
    b7cc:	97ffe62e 	bl	5084 <fwp_data.part.0.constprop.0>
    b7d0:	91174283 	add	x3, x20, #0x5d0
    b7d4:	aa0003f5 	mov	x21, x0
    b7d8:	f949d861 	ldr	x1, [x3, #5040]
    b7dc:	f949ec60 	ldr	x0, [x3, #5080]
    b7e0:	cb0102a1 	sub	x1, x21, x1
    b7e4:	eb00403f 	cmp	x1, x0, lsl #16
    b7e8:	54000322 	b.cs	b84c <f0+0x165c>  // b.hs, b.nlast
    b7ec:	d350fc22 	lsr	x2, x1, #16
    b7f0:	f949fc63 	ldr	x3, [x3, #5112]
    b7f4:	8b020842 	add	x2, x2, x2, lsl #2
    b7f8:	d37df042 	lsl	x2, x2, #3
    b7fc:	8b020060 	add	x0, x3, x2
    b800:	f9401017 	ldr	x23, [x0, #32]
    b804:	b4000257 	cbz	x23, b84c <f0+0x165c>
    b808:	38626862 	ldrb	w2, [x3, x2]
    b80c:	7100085f 	cmp	w2, #0x2
    b810:	540068c0 	b.eq	c528 <f0+0x2338>  // b.none
    b814:	7100045f 	cmp	w2, #0x1
    b818:	540001a1 	b.ne	b84c <f0+0x165c>  // b.any
    b81c:	29430002 	ldp	w2, w0, [x0, #24]
    b820:	92403c21 	and	x1, x1, #0xffff
    b824:	9b027c21 	mul	x1, x1, x2
    b828:	d360fc21 	lsr	x1, x1, #32
    b82c:	eb00003f 	cmp	x1, x0
    b830:	540000e2 	b.cs	b84c <f0+0x165c>  // b.hs, b.nlast
    b834:	8b0102f7 	add	x23, x23, x1
    b838:	394002e0 	ldrb	w0, [x23]
    b83c:	7103fc1f 	cmp	w0, #0xff
    b840:	54007ca0 	b.eq	c7d4 <f0+0x25e4>  // b.none
    b844:	52800020 	mov	w0, #0x1                   	// #1
    b848:	390002e0 	strb	w0, [x23]
    b84c:	9115e3e1 	add	x1, sp, #0x578
    b850:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b854:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b858:	52800020 	mov	w0, #0x1                   	// #1
    b85c:	f902bff7 	str	x23, [sp, #1400]
    b860:	f902c3f5 	str	x21, [sp, #1408]
    b864:	97ffe608 	bl	5084 <fwp_data.part.0.constprop.0>
    b868:	97ffe89b 	bl	5ad4 <fwp_rc_fresh>
    b86c:	aa0003e2 	mov	x2, x0
    b870:	911623e1 	add	x1, sp, #0x588
    b874:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b878:	52800020 	mov	w0, #0x1                   	// #1
    b87c:	f902c7f5 	str	x21, [sp, #1416]
    b880:	f902cbe2 	str	x2, [sp, #1424]
    b884:	97ffe600 	bl	5084 <fwp_data.part.0.constprop.0>
    b888:	97ffe893 	bl	5ad4 <fwp_rc_fresh>
    b88c:	aa0003e2 	mov	x2, x0
    b890:	911663e1 	add	x1, sp, #0x598
    b894:	52800020 	mov	w0, #0x1                   	// #1
    b898:	f902cff7 	str	x23, [sp, #1432]
    b89c:	f902d3e2 	str	x2, [sp, #1440]
    b8a0:	97ffe5f9 	bl	5084 <fwp_data.part.0.constprop.0>
    b8a4:	97ffe88c 	bl	5ad4 <fwp_rc_fresh>
    b8a8:	aa0003e2 	mov	x2, x0
    b8ac:	9116a3e1 	add	x1, sp, #0x5a8
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	f902d7f5 	str	x21, [sp, #1448]
    b8b8:	f902dbe2 	str	x2, [sp, #1456]
    b8bc:	97ffe5f2 	bl	5084 <fwp_data.part.0.constprop.0>
    b8c0:	97ffe885 	bl	5ad4 <fwp_rc_fresh>
    b8c4:	aa0003e2 	mov	x2, x0
    b8c8:	9116e3e1 	add	x1, sp, #0x5b8
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	f902dff7 	str	x23, [sp, #1464]
    b8d4:	f902e3e2 	str	x2, [sp, #1472]
    b8d8:	97ffe5eb 	bl	5084 <fwp_data.part.0.constprop.0>
    b8dc:	97ffe87e 	bl	5ad4 <fwp_rc_fresh>
    b8e0:	aa0003e2 	mov	x2, x0
    b8e4:	911723e1 	add	x1, sp, #0x5c8
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f902e7f5 	str	x21, [sp, #1480]
    b8f0:	f902ebe2 	str	x2, [sp, #1488]
    b8f4:	97ffe5e4 	bl	5084 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe877 	bl	5ad4 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	911763e1 	add	x1, sp, #0x5d8
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f902eff7 	str	x23, [sp, #1496]
    b90c:	f902f3e2 	str	x2, [sp, #1504]
    b910:	97ffe5dd 	bl	5084 <fwp_data.part.0.constprop.0>
    b914:	97ffe870 	bl	5ad4 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	9117a3e1 	add	x1, sp, #0x5e8
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	f902f7f5 	str	x21, [sp, #1512]
    b928:	f902fbe2 	str	x2, [sp, #1520]
    b92c:	97ffe5d6 	bl	5084 <fwp_data.part.0.constprop.0>
    b930:	97ffe869 	bl	5ad4 <fwp_rc_fresh>
    b934:	aa0003e2 	mov	x2, x0
    b938:	9117e3e1 	add	x1, sp, #0x5f8
    b93c:	52800020 	mov	w0, #0x1                   	// #1
    b940:	f902fff7 	str	x23, [sp, #1528]
    b944:	f90303e2 	str	x2, [sp, #1536]
    b948:	97ffe5cf 	bl	5084 <fwp_data.part.0.constprop.0>
    b94c:	97ffe862 	bl	5ad4 <fwp_rc_fresh>
    b950:	aa0003e2 	mov	x2, x0
    b954:	911823e1 	add	x1, sp, #0x608
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f90307f5 	str	x21, [sp, #1544]
    b960:	f9030be2 	str	x2, [sp, #1552]
    b964:	97ffe5c8 	bl	5084 <fwp_data.part.0.constprop.0>
    b968:	97ffe85b 	bl	5ad4 <fwp_rc_fresh>
    b96c:	aa0003e2 	mov	x2, x0
    b970:	911863e1 	add	x1, sp, #0x618
    b974:	52800020 	mov	w0, #0x1                   	// #1
    b978:	f9030ff7 	str	x23, [sp, #1560]
    b97c:	f90313e2 	str	x2, [sp, #1568]
    b980:	97ffe5c1 	bl	5084 <fwp_data.part.0.constprop.0>
    b984:	97ffe854 	bl	5ad4 <fwp_rc_fresh>
    b988:	aa0003e2 	mov	x2, x0
    b98c:	9118a3e1 	add	x1, sp, #0x628
    b990:	52800020 	mov	w0, #0x1                   	// #1
    b994:	f90317f5 	str	x21, [sp, #1576]
    b998:	f9031be2 	str	x2, [sp, #1584]
    b99c:	97ffe5ba 	bl	5084 <fwp_data.part.0.constprop.0>
    b9a0:	97ffe84d 	bl	5ad4 <fwp_rc_fresh>
    b9a4:	aa0003e2 	mov	x2, x0
    b9a8:	9118e3e1 	add	x1, sp, #0x638
    b9ac:	52800020 	mov	w0, #0x1                   	// #1
    b9b0:	f9031ff7 	str	x23, [sp, #1592]
    b9b4:	f90323e2 	str	x2, [sp, #1600]
    b9b8:	97ffe5b3 	bl	5084 <fwp_data.part.0.constprop.0>
    b9bc:	97ffe846 	bl	5ad4 <fwp_rc_fresh>
    b9c0:	aa0003e2 	mov	x2, x0
    b9c4:	911923e1 	add	x1, sp, #0x648
    b9c8:	52800020 	mov	w0, #0x1                   	// #1
    b9cc:	f90327f5 	str	x21, [sp, #1608]
    b9d0:	f9032be2 	str	x2, [sp, #1616]
    b9d4:	97ffe5ac 	bl	5084 <fwp_data.part.0.constprop.0>
    b9d8:	97ffe83f 	bl	5ad4 <fwp_rc_fresh>
    b9dc:	aa0003e2 	mov	x2, x0
    b9e0:	911963e1 	add	x1, sp, #0x658
    b9e4:	52800020 	mov	w0, #0x1                   	// #1
    b9e8:	f9032ff7 	str	x23, [sp, #1624]
    b9ec:	f90333e2 	str	x2, [sp, #1632]
    b9f0:	97ffe5a5 	bl	5084 <fwp_data.part.0.constprop.0>
    b9f4:	97ffe838 	bl	5ad4 <fwp_rc_fresh>
    b9f8:	aa0003e2 	mov	x2, x0
    b9fc:	9119a3e1 	add	x1, sp, #0x668
    ba00:	52800020 	mov	w0, #0x1                   	// #1
    ba04:	f90337f5 	str	x21, [sp, #1640]
    ba08:	f9033be2 	str	x2, [sp, #1648]
    ba0c:	97ffe59e 	bl	5084 <fwp_data.part.0.constprop.0>
    ba10:	91174283 	add	x3, x20, #0x5d0
    ba14:	aa0003f5 	mov	x21, x0
    ba18:	f949d861 	ldr	x1, [x3, #5040]
    ba1c:	f949ec60 	ldr	x0, [x3, #5080]
    ba20:	cb0102a1 	sub	x1, x21, x1
    ba24:	eb00403f 	cmp	x1, x0, lsl #16
    ba28:	54000322 	b.cs	ba8c <f0+0x189c>  // b.hs, b.nlast
    ba2c:	d350fc22 	lsr	x2, x1, #16
    ba30:	f949fc63 	ldr	x3, [x3, #5112]
    ba34:	8b020842 	add	x2, x2, x2, lsl #2
    ba38:	d37df042 	lsl	x2, x2, #3
    ba3c:	8b020060 	add	x0, x3, x2
    ba40:	f9401017 	ldr	x23, [x0, #32]
    ba44:	b4000257 	cbz	x23, ba8c <f0+0x189c>
    ba48:	38626862 	ldrb	w2, [x3, x2]
    ba4c:	7100085f 	cmp	w2, #0x2
    ba50:	540057e0 	b.eq	c54c <f0+0x235c>  // b.none
    ba54:	7100045f 	cmp	w2, #0x1
    ba58:	540001a1 	b.ne	ba8c <f0+0x189c>  // b.any
    ba5c:	29430002 	ldp	w2, w0, [x0, #24]
    ba60:	92403c21 	and	x1, x1, #0xffff
    ba64:	9b027c21 	mul	x1, x1, x2
    ba68:	d360fc21 	lsr	x1, x1, #32
    ba6c:	eb00003f 	cmp	x1, x0
    ba70:	540000e2 	b.cs	ba8c <f0+0x189c>  // b.hs, b.nlast
    ba74:	8b0102f7 	add	x23, x23, x1
    ba78:	394002e0 	ldrb	w0, [x23]
    ba7c:	7103fc1f 	cmp	w0, #0xff
    ba80:	54006b00 	b.eq	c7e0 <f0+0x25f0>  // b.none
    ba84:	52800020 	mov	w0, #0x1                   	// #1
    ba88:	390002e0 	strb	w0, [x23]
    ba8c:	9119e3e1 	add	x1, sp, #0x678
    ba90:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba98:	52800020 	mov	w0, #0x1                   	// #1
    ba9c:	f9033ff7 	str	x23, [sp, #1656]
    baa0:	f90343f5 	str	x21, [sp, #1664]
    baa4:	97ffe578 	bl	5084 <fwp_data.part.0.constprop.0>
    baa8:	97ffe80b 	bl	5ad4 <fwp_rc_fresh>
    baac:	aa0003e2 	mov	x2, x0
    bab0:	911a23e1 	add	x1, sp, #0x688
    bab4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bab8:	52800020 	mov	w0, #0x1                   	// #1
    babc:	f90347f5 	str	x21, [sp, #1672]
    bac0:	f9034be2 	str	x2, [sp, #1680]
    bac4:	97ffe570 	bl	5084 <fwp_data.part.0.constprop.0>
    bac8:	97ffe803 	bl	5ad4 <fwp_rc_fresh>
    bacc:	aa0003e2 	mov	x2, x0
    bad0:	911a63e1 	add	x1, sp, #0x698
    bad4:	52800020 	mov	w0, #0x1                   	// #1
    bad8:	f9034ff7 	str	x23, [sp, #1688]
    badc:	f90353e2 	str	x2, [sp, #1696]
    bae0:	97ffe569 	bl	5084 <fwp_data.part.0.constprop.0>
    bae4:	97ffe7fc 	bl	5ad4 <fwp_rc_fresh>
    bae8:	aa0003e2 	mov	x2, x0
    baec:	911aa3e1 	add	x1, sp, #0x6a8
    baf0:	52800020 	mov	w0, #0x1                   	// #1
    baf4:	f90357f5 	str	x21, [sp, #1704]
    baf8:	f9035be2 	str	x2, [sp, #1712]
    bafc:	97ffe562 	bl	5084 <fwp_data.part.0.constprop.0>
    bb00:	91174283 	add	x3, x20, #0x5d0
    bb04:	aa0003f5 	mov	x21, x0
    bb08:	f949d861 	ldr	x1, [x3, #5040]
    bb0c:	f949ec60 	ldr	x0, [x3, #5080]
    bb10:	cb0102a1 	sub	x1, x21, x1
    bb14:	eb00403f 	cmp	x1, x0, lsl #16
    bb18:	54000322 	b.cs	bb7c <f0+0x198c>  // b.hs, b.nlast
    bb1c:	d350fc22 	lsr	x2, x1, #16
    bb20:	f949fc63 	ldr	x3, [x3, #5112]
    bb24:	8b020842 	add	x2, x2, x2, lsl #2
    bb28:	d37df042 	lsl	x2, x2, #3
    bb2c:	8b020060 	add	x0, x3, x2
    bb30:	f9401017 	ldr	x23, [x0, #32]
    bb34:	b4000257 	cbz	x23, bb7c <f0+0x198c>
    bb38:	38626862 	ldrb	w2, [x3, x2]
    bb3c:	7100085f 	cmp	w2, #0x2
    bb40:	54005000 	b.eq	c540 <f0+0x2350>  // b.none
    bb44:	7100045f 	cmp	w2, #0x1
    bb48:	540001a1 	b.ne	bb7c <f0+0x198c>  // b.any
    bb4c:	29430002 	ldp	w2, w0, [x0, #24]
    bb50:	92403c21 	and	x1, x1, #0xffff
    bb54:	9b027c21 	mul	x1, x1, x2
    bb58:	d360fc21 	lsr	x1, x1, #32
    bb5c:	eb00003f 	cmp	x1, x0
    bb60:	540000e2 	b.cs	bb7c <f0+0x198c>  // b.hs, b.nlast
    bb64:	8b0102f7 	add	x23, x23, x1
    bb68:	394002e0 	ldrb	w0, [x23]
    bb6c:	7103fc1f 	cmp	w0, #0xff
    bb70:	540063e0 	b.eq	c7ec <f0+0x25fc>  // b.none
    bb74:	52800020 	mov	w0, #0x1                   	// #1
    bb78:	390002e0 	strb	w0, [x23]
    bb7c:	911ae3e1 	add	x1, sp, #0x6b8
    bb80:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb84:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb88:	52800020 	mov	w0, #0x1                   	// #1
    bb8c:	f9035ff7 	str	x23, [sp, #1720]
    bb90:	f90363f5 	str	x21, [sp, #1728]
    bb94:	97ffe53c 	bl	5084 <fwp_data.part.0.constprop.0>
    bb98:	97ffe7cf 	bl	5ad4 <fwp_rc_fresh>
    bb9c:	aa0003e2 	mov	x2, x0
    bba0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bba4:	911b23e1 	add	x1, sp, #0x6c8
    bba8:	52800020 	mov	w0, #0x1                   	// #1
    bbac:	f90367e3 	str	x3, [sp, #1736]
    bbb0:	f9036be2 	str	x2, [sp, #1744]
    bbb4:	97ffe534 	bl	5084 <fwp_data.part.0.constprop.0>
    bbb8:	97ffe7c7 	bl	5ad4 <fwp_rc_fresh>
    bbbc:	aa0003e2 	mov	x2, x0
    bbc0:	911b63e1 	add	x1, sp, #0x6d8
    bbc4:	52800020 	mov	w0, #0x1                   	// #1
    bbc8:	f9036ff7 	str	x23, [sp, #1752]
    bbcc:	f90373e2 	str	x2, [sp, #1760]
    bbd0:	97ffe52d 	bl	5084 <fwp_data.part.0.constprop.0>
    bbd4:	91174283 	add	x3, x20, #0x5d0
    bbd8:	aa0003f5 	mov	x21, x0
    bbdc:	f949d861 	ldr	x1, [x3, #5040]
    bbe0:	f949ec60 	ldr	x0, [x3, #5080]
    bbe4:	cb0102a1 	sub	x1, x21, x1
    bbe8:	eb00403f 	cmp	x1, x0, lsl #16
    bbec:	54000322 	b.cs	bc50 <f0+0x1a60>  // b.hs, b.nlast
    bbf0:	d350fc22 	lsr	x2, x1, #16
    bbf4:	f949fc63 	ldr	x3, [x3, #5112]
    bbf8:	8b020842 	add	x2, x2, x2, lsl #2
    bbfc:	d37df042 	lsl	x2, x2, #3
    bc00:	8b020060 	add	x0, x3, x2
    bc04:	f9401017 	ldr	x23, [x0, #32]
    bc08:	b4000257 	cbz	x23, bc50 <f0+0x1a60>
    bc0c:	38626862 	ldrb	w2, [x3, x2]
    bc10:	7100085f 	cmp	w2, #0x2
    bc14:	54004a80 	b.eq	c564 <f0+0x2374>  // b.none
    bc18:	7100045f 	cmp	w2, #0x1
    bc1c:	540001a1 	b.ne	bc50 <f0+0x1a60>  // b.any
    bc20:	29430002 	ldp	w2, w0, [x0, #24]
    bc24:	92403c21 	and	x1, x1, #0xffff
    bc28:	9b027c21 	mul	x1, x1, x2
    bc2c:	d360fc21 	lsr	x1, x1, #32
    bc30:	eb00003f 	cmp	x1, x0
    bc34:	540000e2 	b.cs	bc50 <f0+0x1a60>  // b.hs, b.nlast
    bc38:	8b0102f7 	add	x23, x23, x1
    bc3c:	394002e0 	ldrb	w0, [x23]
    bc40:	7103fc1f 	cmp	w0, #0xff
    bc44:	54005da0 	b.eq	c7f8 <f0+0x2608>  // b.none
    bc48:	52800020 	mov	w0, #0x1                   	// #1
    bc4c:	390002e0 	strb	w0, [x23]
    bc50:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc54:	911ba3e1 	add	x1, sp, #0x6e8
    bc58:	52800020 	mov	w0, #0x1                   	// #1
    bc5c:	f90377e2 	str	x2, [sp, #1768]
    bc60:	f9037bf5 	str	x21, [sp, #1776]
    bc64:	97ffe508 	bl	5084 <fwp_data.part.0.constprop.0>
    bc68:	91174283 	add	x3, x20, #0x5d0
    bc6c:	aa0003f5 	mov	x21, x0
    bc70:	f949d861 	ldr	x1, [x3, #5040]
    bc74:	f949ec60 	ldr	x0, [x3, #5080]
    bc78:	cb0102a1 	sub	x1, x21, x1
    bc7c:	eb00403f 	cmp	x1, x0, lsl #16
    bc80:	54000322 	b.cs	bce4 <f0+0x1af4>  // b.hs, b.nlast
    bc84:	d350fc22 	lsr	x2, x1, #16
    bc88:	f949fc63 	ldr	x3, [x3, #5112]
    bc8c:	8b020842 	add	x2, x2, x2, lsl #2
    bc90:	d37df042 	lsl	x2, x2, #3
    bc94:	8b020060 	add	x0, x3, x2
    bc98:	f9401017 	ldr	x23, [x0, #32]
    bc9c:	b4000257 	cbz	x23, bce4 <f0+0x1af4>
    bca0:	38626862 	ldrb	w2, [x3, x2]
    bca4:	7100085f 	cmp	w2, #0x2
    bca8:	54004580 	b.eq	c558 <f0+0x2368>  // b.none
    bcac:	7100045f 	cmp	w2, #0x1
    bcb0:	540001a1 	b.ne	bce4 <f0+0x1af4>  // b.any
    bcb4:	29430002 	ldp	w2, w0, [x0, #24]
    bcb8:	92403c21 	and	x1, x1, #0xffff
    bcbc:	9b027c21 	mul	x1, x1, x2
    bcc0:	d360fc21 	lsr	x1, x1, #32
    bcc4:	eb00003f 	cmp	x1, x0
    bcc8:	540000e2 	b.cs	bce4 <f0+0x1af4>  // b.hs, b.nlast
    bccc:	8b0102f7 	add	x23, x23, x1
    bcd0:	394002e0 	ldrb	w0, [x23]
    bcd4:	7103fc1f 	cmp	w0, #0xff
    bcd8:	54005960 	b.eq	c804 <f0+0x2614>  // b.none
    bcdc:	52800020 	mov	w0, #0x1                   	// #1
    bce0:	390002e0 	strb	w0, [x23]
    bce4:	911be3e1 	add	x1, sp, #0x6f8
    bce8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bcec:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bcf0:	52800020 	mov	w0, #0x1                   	// #1
    bcf4:	f9037ff7 	str	x23, [sp, #1784]
    bcf8:	f90383f5 	str	x21, [sp, #1792]
    bcfc:	97ffe4e2 	bl	5084 <fwp_data.part.0.constprop.0>
    bd00:	97ffe775 	bl	5ad4 <fwp_rc_fresh>
    bd04:	aa0003e2 	mov	x2, x0
    bd08:	911c23e1 	add	x1, sp, #0x708
    bd0c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd10:	52800020 	mov	w0, #0x1                   	// #1
    bd14:	f90387f5 	str	x21, [sp, #1800]
    bd18:	f9038be2 	str	x2, [sp, #1808]
    bd1c:	97ffe4da 	bl	5084 <fwp_data.part.0.constprop.0>
    bd20:	97ffe76d 	bl	5ad4 <fwp_rc_fresh>
    bd24:	aa0003e2 	mov	x2, x0
    bd28:	911c63e1 	add	x1, sp, #0x718
    bd2c:	52800020 	mov	w0, #0x1                   	// #1
    bd30:	f9038ff7 	str	x23, [sp, #1816]
    bd34:	f90393e2 	str	x2, [sp, #1824]
    bd38:	97ffe4d3 	bl	5084 <fwp_data.part.0.constprop.0>
    bd3c:	97ffe766 	bl	5ad4 <fwp_rc_fresh>
    bd40:	aa0003e2 	mov	x2, x0
    bd44:	911ca3e1 	add	x1, sp, #0x728
    bd48:	52800020 	mov	w0, #0x1                   	// #1
    bd4c:	f90397f5 	str	x21, [sp, #1832]
    bd50:	f9039be2 	str	x2, [sp, #1840]
    bd54:	97ffe4cc 	bl	5084 <fwp_data.part.0.constprop.0>
    bd58:	91174283 	add	x3, x20, #0x5d0
    bd5c:	aa0003f5 	mov	x21, x0
    bd60:	f949d861 	ldr	x1, [x3, #5040]
    bd64:	f949ec60 	ldr	x0, [x3, #5080]
    bd68:	cb0102a1 	sub	x1, x21, x1
    bd6c:	eb00403f 	cmp	x1, x0, lsl #16
    bd70:	54000322 	b.cs	bdd4 <f0+0x1be4>  // b.hs, b.nlast
    bd74:	d350fc22 	lsr	x2, x1, #16
    bd78:	f949fc63 	ldr	x3, [x3, #5112]
    bd7c:	8b020842 	add	x2, x2, x2, lsl #2
    bd80:	d37df042 	lsl	x2, x2, #3
    bd84:	8b020060 	add	x0, x3, x2
    bd88:	f9401017 	ldr	x23, [x0, #32]
    bd8c:	b4000257 	cbz	x23, bdd4 <f0+0x1be4>
    bd90:	38626862 	ldrb	w2, [x3, x2]
    bd94:	7100085f 	cmp	w2, #0x2
    bd98:	54003f20 	b.eq	c57c <f0+0x238c>  // b.none
    bd9c:	7100045f 	cmp	w2, #0x1
    bda0:	540001a1 	b.ne	bdd4 <f0+0x1be4>  // b.any
    bda4:	29430002 	ldp	w2, w0, [x0, #24]
    bda8:	92403c21 	and	x1, x1, #0xffff
    bdac:	9b027c21 	mul	x1, x1, x2
    bdb0:	d360fc21 	lsr	x1, x1, #32
    bdb4:	eb00003f 	cmp	x1, x0
    bdb8:	540000e2 	b.cs	bdd4 <f0+0x1be4>  // b.hs, b.nlast
    bdbc:	8b0102f7 	add	x23, x23, x1
    bdc0:	394002e0 	ldrb	w0, [x23]
    bdc4:	7103fc1f 	cmp	w0, #0xff
    bdc8:	54005240 	b.eq	c810 <f0+0x2620>  // b.none
    bdcc:	52800020 	mov	w0, #0x1                   	// #1
    bdd0:	390002e0 	strb	w0, [x23]
    bdd4:	911ce3e1 	add	x1, sp, #0x738
    bdd8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bddc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bde0:	52800020 	mov	w0, #0x1                   	// #1
    bde4:	f9039ff7 	str	x23, [sp, #1848]
    bde8:	f903a3f5 	str	x21, [sp, #1856]
    bdec:	97ffe4a6 	bl	5084 <fwp_data.part.0.constprop.0>
    bdf0:	97ffe739 	bl	5ad4 <fwp_rc_fresh>
    bdf4:	aa0003e2 	mov	x2, x0
    bdf8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bdfc:	911d23e1 	add	x1, sp, #0x748
    be00:	52800020 	mov	w0, #0x1                   	// #1
    be04:	f903a7e3 	str	x3, [sp, #1864]
    be08:	f903abe2 	str	x2, [sp, #1872]
    be0c:	97ffe49e 	bl	5084 <fwp_data.part.0.constprop.0>
    be10:	97ffe731 	bl	5ad4 <fwp_rc_fresh>
    be14:	aa0003e2 	mov	x2, x0
    be18:	911d63e1 	add	x1, sp, #0x758
    be1c:	52800020 	mov	w0, #0x1                   	// #1
    be20:	f903aff7 	str	x23, [sp, #1880]
    be24:	f903b3e2 	str	x2, [sp, #1888]
    be28:	97ffe497 	bl	5084 <fwp_data.part.0.constprop.0>
    be2c:	91174283 	add	x3, x20, #0x5d0
    be30:	aa0003f5 	mov	x21, x0
    be34:	f949d861 	ldr	x1, [x3, #5040]
    be38:	f949ec60 	ldr	x0, [x3, #5080]
    be3c:	cb0102a1 	sub	x1, x21, x1
    be40:	eb00403f 	cmp	x1, x0, lsl #16
    be44:	54000322 	b.cs	bea8 <f0+0x1cb8>  // b.hs, b.nlast
    be48:	d350fc22 	lsr	x2, x1, #16
    be4c:	f949fc63 	ldr	x3, [x3, #5112]
    be50:	8b020842 	add	x2, x2, x2, lsl #2
    be54:	d37df042 	lsl	x2, x2, #3
    be58:	8b020060 	add	x0, x3, x2
    be5c:	f9401017 	ldr	x23, [x0, #32]
    be60:	b4000257 	cbz	x23, bea8 <f0+0x1cb8>
    be64:	38626862 	ldrb	w2, [x3, x2]
    be68:	7100085f 	cmp	w2, #0x2
    be6c:	54003820 	b.eq	c570 <f0+0x2380>  // b.none
    be70:	7100045f 	cmp	w2, #0x1
    be74:	540001a1 	b.ne	bea8 <f0+0x1cb8>  // b.any
    be78:	29430002 	ldp	w2, w0, [x0, #24]
    be7c:	92403c21 	and	x1, x1, #0xffff
    be80:	9b027c21 	mul	x1, x1, x2
    be84:	d360fc21 	lsr	x1, x1, #32
    be88:	eb00003f 	cmp	x1, x0
    be8c:	540000e2 	b.cs	bea8 <f0+0x1cb8>  // b.hs, b.nlast
    be90:	8b0102f7 	add	x23, x23, x1
    be94:	394002e0 	ldrb	w0, [x23]
    be98:	7103fc1f 	cmp	w0, #0xff
    be9c:	54004c00 	b.eq	c81c <f0+0x262c>  // b.none
    bea0:	52800020 	mov	w0, #0x1                   	// #1
    bea4:	390002e0 	strb	w0, [x23]
    bea8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    beac:	911da3e1 	add	x1, sp, #0x768
    beb0:	52800020 	mov	w0, #0x1                   	// #1
    beb4:	f903b7e2 	str	x2, [sp, #1896]
    beb8:	f903bbf5 	str	x21, [sp, #1904]
    bebc:	97ffe472 	bl	5084 <fwp_data.part.0.constprop.0>
    bec0:	91174283 	add	x3, x20, #0x5d0
    bec4:	aa0003f5 	mov	x21, x0
    bec8:	f949d861 	ldr	x1, [x3, #5040]
    becc:	f949ec60 	ldr	x0, [x3, #5080]
    bed0:	cb0102a1 	sub	x1, x21, x1
    bed4:	eb00403f 	cmp	x1, x0, lsl #16
    bed8:	54000322 	b.cs	bf3c <f0+0x1d4c>  // b.hs, b.nlast
    bedc:	d350fc22 	lsr	x2, x1, #16
    bee0:	f949fc63 	ldr	x3, [x3, #5112]
    bee4:	8b020842 	add	x2, x2, x2, lsl #2
    bee8:	d37df042 	lsl	x2, x2, #3
    beec:	8b020060 	add	x0, x3, x2
    bef0:	f9401017 	ldr	x23, [x0, #32]
    bef4:	b4000257 	cbz	x23, bf3c <f0+0x1d4c>
    bef8:	38626862 	ldrb	w2, [x3, x2]
    befc:	7100085f 	cmp	w2, #0x2
    bf00:	540034a0 	b.eq	c594 <f0+0x23a4>  // b.none
    bf04:	7100045f 	cmp	w2, #0x1
    bf08:	540001a1 	b.ne	bf3c <f0+0x1d4c>  // b.any
    bf0c:	29430002 	ldp	w2, w0, [x0, #24]
    bf10:	92403c21 	and	x1, x1, #0xffff
    bf14:	9b027c21 	mul	x1, x1, x2
    bf18:	d360fc21 	lsr	x1, x1, #32
    bf1c:	eb00003f 	cmp	x1, x0
    bf20:	540000e2 	b.cs	bf3c <f0+0x1d4c>  // b.hs, b.nlast
    bf24:	8b0102f7 	add	x23, x23, x1
    bf28:	394002e0 	ldrb	w0, [x23]
    bf2c:	7103fc1f 	cmp	w0, #0xff
    bf30:	540047c0 	b.eq	c828 <f0+0x2638>  // b.none
    bf34:	52800020 	mov	w0, #0x1                   	// #1
    bf38:	390002e0 	strb	w0, [x23]
    bf3c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf40:	911de3e1 	add	x1, sp, #0x778
    bf44:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	f903bfe2 	str	x2, [sp, #1912]
    bf50:	f903c3f5 	str	x21, [sp, #1920]
    bf54:	97ffe44c 	bl	5084 <fwp_data.part.0.constprop.0>
    bf58:	97ffe6df 	bl	5ad4 <fwp_rc_fresh>
    bf5c:	aa0003e2 	mov	x2, x0
    bf60:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bf64:	911e23e1 	add	x1, sp, #0x788
    bf68:	52800020 	mov	w0, #0x1                   	// #1
    bf6c:	f903c7e3 	str	x3, [sp, #1928]
    bf70:	f903cbe2 	str	x2, [sp, #1936]
    bf74:	97ffe444 	bl	5084 <fwp_data.part.0.constprop.0>
    bf78:	91174283 	add	x3, x20, #0x5d0
    bf7c:	aa0003f5 	mov	x21, x0
    bf80:	f949d861 	ldr	x1, [x3, #5040]
    bf84:	f949ec60 	ldr	x0, [x3, #5080]
    bf88:	cb0102a1 	sub	x1, x21, x1
    bf8c:	eb00403f 	cmp	x1, x0, lsl #16
    bf90:	54000322 	b.cs	bff4 <f0+0x1e04>  // b.hs, b.nlast
    bf94:	d350fc22 	lsr	x2, x1, #16
    bf98:	f949fc63 	ldr	x3, [x3, #5112]
    bf9c:	8b020842 	add	x2, x2, x2, lsl #2
    bfa0:	d37df042 	lsl	x2, x2, #3
    bfa4:	8b020060 	add	x0, x3, x2
    bfa8:	f9401017 	ldr	x23, [x0, #32]
    bfac:	b4000257 	cbz	x23, bff4 <f0+0x1e04>
    bfb0:	38626862 	ldrb	w2, [x3, x2]
    bfb4:	7100085f 	cmp	w2, #0x2
    bfb8:	54002e80 	b.eq	c588 <f0+0x2398>  // b.none
    bfbc:	7100045f 	cmp	w2, #0x1
    bfc0:	540001a1 	b.ne	bff4 <f0+0x1e04>  // b.any
    bfc4:	29430002 	ldp	w2, w0, [x0, #24]
    bfc8:	92403c21 	and	x1, x1, #0xffff
    bfcc:	9b027c21 	mul	x1, x1, x2
    bfd0:	d360fc21 	lsr	x1, x1, #32
    bfd4:	eb00003f 	cmp	x1, x0
    bfd8:	540000e2 	b.cs	bff4 <f0+0x1e04>  // b.hs, b.nlast
    bfdc:	8b0102f7 	add	x23, x23, x1
    bfe0:	394002e0 	ldrb	w0, [x23]
    bfe4:	7103fc1f 	cmp	w0, #0xff
    bfe8:	54004260 	b.eq	c834 <f0+0x2644>  // b.none
    bfec:	52800020 	mov	w0, #0x1                   	// #1
    bff0:	390002e0 	strb	w0, [x23]
    bff4:	911e63e1 	add	x1, sp, #0x798
    bff8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bffc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c000:	52800020 	mov	w0, #0x1                   	// #1
    c004:	f903cff7 	str	x23, [sp, #1944]
    c008:	f903d3f5 	str	x21, [sp, #1952]
    c00c:	97ffe41e 	bl	5084 <fwp_data.part.0.constprop.0>
    c010:	97ffe6b1 	bl	5ad4 <fwp_rc_fresh>
    c014:	aa0003e2 	mov	x2, x0
    c018:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c01c:	911ea3e1 	add	x1, sp, #0x7a8
    c020:	52800020 	mov	w0, #0x1                   	// #1
    c024:	f903d7e3 	str	x3, [sp, #1960]
    c028:	f903dbe2 	str	x2, [sp, #1968]
    c02c:	97ffe416 	bl	5084 <fwp_data.part.0.constprop.0>
    c030:	97ffe6a9 	bl	5ad4 <fwp_rc_fresh>
    c034:	aa0003e2 	mov	x2, x0
    c038:	911ee3e1 	add	x1, sp, #0x7b8
    c03c:	52800020 	mov	w0, #0x1                   	// #1
    c040:	f903dff7 	str	x23, [sp, #1976]
    c044:	f903e3e2 	str	x2, [sp, #1984]
    c048:	97ffe40f 	bl	5084 <fwp_data.part.0.constprop.0>
    c04c:	91174283 	add	x3, x20, #0x5d0
    c050:	aa0003f5 	mov	x21, x0
    c054:	f949d861 	ldr	x1, [x3, #5040]
    c058:	f949ec60 	ldr	x0, [x3, #5080]
    c05c:	cb0102a1 	sub	x1, x21, x1
    c060:	eb00403f 	cmp	x1, x0, lsl #16
    c064:	54000322 	b.cs	c0c8 <f0+0x1ed8>  // b.hs, b.nlast
    c068:	d350fc22 	lsr	x2, x1, #16
    c06c:	f949fc63 	ldr	x3, [x3, #5112]
    c070:	8b020842 	add	x2, x2, x2, lsl #2
    c074:	d37df042 	lsl	x2, x2, #3
    c078:	8b020060 	add	x0, x3, x2
    c07c:	f9401017 	ldr	x23, [x0, #32]
    c080:	b4000257 	cbz	x23, c0c8 <f0+0x1ed8>
    c084:	38626862 	ldrb	w2, [x3, x2]
    c088:	7100085f 	cmp	w2, #0x2
    c08c:	54002900 	b.eq	c5ac <f0+0x23bc>  // b.none
    c090:	7100045f 	cmp	w2, #0x1
    c094:	540001a1 	b.ne	c0c8 <f0+0x1ed8>  // b.any
    c098:	29430002 	ldp	w2, w0, [x0, #24]
    c09c:	92403c21 	and	x1, x1, #0xffff
    c0a0:	9b027c21 	mul	x1, x1, x2
    c0a4:	d360fc21 	lsr	x1, x1, #32
    c0a8:	eb00003f 	cmp	x1, x0
    c0ac:	540000e2 	b.cs	c0c8 <f0+0x1ed8>  // b.hs, b.nlast
    c0b0:	8b0102f7 	add	x23, x23, x1
    c0b4:	394002e0 	ldrb	w0, [x23]
    c0b8:	7103fc1f 	cmp	w0, #0xff
    c0bc:	54003c20 	b.eq	c840 <f0+0x2650>  // b.none
    c0c0:	52800020 	mov	w0, #0x1                   	// #1
    c0c4:	390002e0 	strb	w0, [x23]
    c0c8:	911f23e1 	add	x1, sp, #0x7c8
    c0cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f903e7e2 	str	x2, [sp, #1992]
    c0d8:	f903ebf5 	str	x21, [sp, #2000]
    c0dc:	97ffe3ea 	bl	5084 <fwp_data.part.0.constprop.0>
    c0e0:	97ffe67d 	bl	5ad4 <fwp_rc_fresh>
    c0e4:	aa0003e2 	mov	x2, x0
    c0e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c0ec:	911f63e1 	add	x1, sp, #0x7d8
    c0f0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c0f4:	52800020 	mov	w0, #0x1                   	// #1
    c0f8:	f903efe3 	str	x3, [sp, #2008]
    c0fc:	f903f3e2 	str	x2, [sp, #2016]
    c100:	97ffe3e1 	bl	5084 <fwp_data.part.0.constprop.0>
    c104:	91174283 	add	x3, x20, #0x5d0
    c108:	aa0003f5 	mov	x21, x0
    c10c:	f949d861 	ldr	x1, [x3, #5040]
    c110:	f949ec60 	ldr	x0, [x3, #5080]
    c114:	cb0102a1 	sub	x1, x21, x1
    c118:	eb00403f 	cmp	x1, x0, lsl #16
    c11c:	54000322 	b.cs	c180 <f0+0x1f90>  // b.hs, b.nlast
    c120:	d350fc22 	lsr	x2, x1, #16
    c124:	f949fc63 	ldr	x3, [x3, #5112]
    c128:	8b020842 	add	x2, x2, x2, lsl #2
    c12c:	d37df042 	lsl	x2, x2, #3
    c130:	8b020060 	add	x0, x3, x2
    c134:	f9401017 	ldr	x23, [x0, #32]
    c138:	b4000257 	cbz	x23, c180 <f0+0x1f90>
    c13c:	38626862 	ldrb	w2, [x3, x2]
    c140:	7100085f 	cmp	w2, #0x2
    c144:	540022e0 	b.eq	c5a0 <f0+0x23b0>  // b.none
    c148:	7100045f 	cmp	w2, #0x1
    c14c:	540001a1 	b.ne	c180 <f0+0x1f90>  // b.any
    c150:	29430002 	ldp	w2, w0, [x0, #24]
    c154:	92403c21 	and	x1, x1, #0xffff
    c158:	9b027c21 	mul	x1, x1, x2
    c15c:	d360fc21 	lsr	x1, x1, #32
    c160:	eb00003f 	cmp	x1, x0
    c164:	540000e2 	b.cs	c180 <f0+0x1f90>  // b.hs, b.nlast
    c168:	8b0102f7 	add	x23, x23, x1
    c16c:	394002e0 	ldrb	w0, [x23]
    c170:	7103fc1f 	cmp	w0, #0xff
    c174:	540036c0 	b.eq	c84c <f0+0x265c>  // b.none
    c178:	52800020 	mov	w0, #0x1                   	// #1
    c17c:	390002e0 	strb	w0, [x23]
    c180:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c184:	911fa3e1 	add	x1, sp, #0x7e8
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	f903f7e2 	str	x2, [sp, #2024]
    c190:	f903fbf5 	str	x21, [sp, #2032]
    c194:	97ffe3bc 	bl	5084 <fwp_data.part.0.constprop.0>
    c198:	91174283 	add	x3, x20, #0x5d0
    c19c:	aa0003f5 	mov	x21, x0
    c1a0:	f949d861 	ldr	x1, [x3, #5040]
    c1a4:	f949ec60 	ldr	x0, [x3, #5080]
    c1a8:	cb0102a1 	sub	x1, x21, x1
    c1ac:	eb00403f 	cmp	x1, x0, lsl #16
    c1b0:	54000322 	b.cs	c214 <f0+0x2024>  // b.hs, b.nlast
    c1b4:	d350fc22 	lsr	x2, x1, #16
    c1b8:	f949fc63 	ldr	x3, [x3, #5112]
    c1bc:	8b020842 	add	x2, x2, x2, lsl #2
    c1c0:	d37df042 	lsl	x2, x2, #3
    c1c4:	8b020060 	add	x0, x3, x2
    c1c8:	f9401017 	ldr	x23, [x0, #32]
    c1cc:	b4000257 	cbz	x23, c214 <f0+0x2024>
    c1d0:	38626862 	ldrb	w2, [x3, x2]
    c1d4:	7100085f 	cmp	w2, #0x2
    c1d8:	54001f60 	b.eq	c5c4 <f0+0x23d4>  // b.none
    c1dc:	7100045f 	cmp	w2, #0x1
    c1e0:	540001a1 	b.ne	c214 <f0+0x2024>  // b.any
    c1e4:	29430002 	ldp	w2, w0, [x0, #24]
    c1e8:	92403c21 	and	x1, x1, #0xffff
    c1ec:	9b027c21 	mul	x1, x1, x2
    c1f0:	d360fc21 	lsr	x1, x1, #32
    c1f4:	eb00003f 	cmp	x1, x0
    c1f8:	540000e2 	b.cs	c214 <f0+0x2024>  // b.hs, b.nlast
    c1fc:	8b0102f7 	add	x23, x23, x1
    c200:	394002e0 	ldrb	w0, [x23]
    c204:	7103fc1f 	cmp	w0, #0xff
    c208:	54003280 	b.eq	c858 <f0+0x2668>  // b.none
    c20c:	52800020 	mov	w0, #0x1                   	// #1
    c210:	390002e0 	strb	w0, [x23]
    c214:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c218:	911fe3e1 	add	x1, sp, #0x7f8
    c21c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c220:	52800020 	mov	w0, #0x1                   	// #1
    c224:	f903ffe2 	str	x2, [sp, #2040]
    c228:	f90403f5 	str	x21, [sp, #2048]
    c22c:	97ffe396 	bl	5084 <fwp_data.part.0.constprop.0>
    c230:	97ffe629 	bl	5ad4 <fwp_rc_fresh>
    c234:	aa0003e2 	mov	x2, x0
    c238:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c23c:	912023e1 	add	x1, sp, #0x808
    c240:	52800020 	mov	w0, #0x1                   	// #1
    c244:	f90407e3 	str	x3, [sp, #2056]
    c248:	f9040be2 	str	x2, [sp, #2064]
    c24c:	97ffe38e 	bl	5084 <fwp_data.part.0.constprop.0>
    c250:	91174283 	add	x3, x20, #0x5d0
    c254:	aa0003f5 	mov	x21, x0
    c258:	f949d861 	ldr	x1, [x3, #5040]
    c25c:	f949ec60 	ldr	x0, [x3, #5080]
    c260:	cb0102a1 	sub	x1, x21, x1
    c264:	eb00403f 	cmp	x1, x0, lsl #16
    c268:	54000322 	b.cs	c2cc <f0+0x20dc>  // b.hs, b.nlast
    c26c:	d350fc22 	lsr	x2, x1, #16
    c270:	f949fc63 	ldr	x3, [x3, #5112]
    c274:	8b020842 	add	x2, x2, x2, lsl #2
    c278:	d37df042 	lsl	x2, x2, #3
    c27c:	8b020060 	add	x0, x3, x2
    c280:	f9401017 	ldr	x23, [x0, #32]
    c284:	b4000257 	cbz	x23, c2cc <f0+0x20dc>
    c288:	38626862 	ldrb	w2, [x3, x2]
    c28c:	7100085f 	cmp	w2, #0x2
    c290:	54001940 	b.eq	c5b8 <f0+0x23c8>  // b.none
    c294:	7100045f 	cmp	w2, #0x1
    c298:	540001a1 	b.ne	c2cc <f0+0x20dc>  // b.any
    c29c:	29430002 	ldp	w2, w0, [x0, #24]
    c2a0:	92403c21 	and	x1, x1, #0xffff
    c2a4:	9b027c21 	mul	x1, x1, x2
    c2a8:	d360fc21 	lsr	x1, x1, #32
    c2ac:	eb00003f 	cmp	x1, x0
    c2b0:	540000e2 	b.cs	c2cc <f0+0x20dc>  // b.hs, b.nlast
    c2b4:	8b0102f7 	add	x23, x23, x1
    c2b8:	394002e0 	ldrb	w0, [x23]
    c2bc:	7103fc1f 	cmp	w0, #0xff
    c2c0:	54002d20 	b.eq	c864 <f0+0x2674>  // b.none
    c2c4:	52800020 	mov	w0, #0x1                   	// #1
    c2c8:	390002e0 	strb	w0, [x23]
    c2cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c2d0:	912063e1 	add	x1, sp, #0x818
    c2d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c2d8:	52800020 	mov	w0, #0x1                   	// #1
    c2dc:	f9040fe2 	str	x2, [sp, #2072]
    c2e0:	f90413f5 	str	x21, [sp, #2080]
    c2e4:	97ffe368 	bl	5084 <fwp_data.part.0.constprop.0>
    c2e8:	97ffe5fb 	bl	5ad4 <fwp_rc_fresh>
    c2ec:	aa0003e2 	mov	x2, x0
    c2f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c2f4:	9120a3e1 	add	x1, sp, #0x828
    c2f8:	52800020 	mov	w0, #0x1                   	// #1
    c2fc:	f90417e3 	str	x3, [sp, #2088]
    c300:	f9041be2 	str	x2, [sp, #2096]
    c304:	97ffe360 	bl	5084 <fwp_data.part.0.constprop.0>
    c308:	91174283 	add	x3, x20, #0x5d0
    c30c:	aa0003f5 	mov	x21, x0
    c310:	f949d861 	ldr	x1, [x3, #5040]
    c314:	f949ec60 	ldr	x0, [x3, #5080]
    c318:	cb0102a1 	sub	x1, x21, x1
    c31c:	eb00403f 	cmp	x1, x0, lsl #16
    c320:	54000322 	b.cs	c384 <f0+0x2194>  // b.hs, b.nlast
    c324:	d350fc22 	lsr	x2, x1, #16
    c328:	f949fc63 	ldr	x3, [x3, #5112]
    c32c:	8b020842 	add	x2, x2, x2, lsl #2
    c330:	d37df042 	lsl	x2, x2, #3
    c334:	8b020060 	add	x0, x3, x2
    c338:	f9401017 	ldr	x23, [x0, #32]
    c33c:	b4000257 	cbz	x23, c384 <f0+0x2194>
    c340:	38626862 	ldrb	w2, [x3, x2]
    c344:	7100085f 	cmp	w2, #0x2
    c348:	540014a0 	b.eq	c5dc <f0+0x23ec>  // b.none
    c34c:	7100045f 	cmp	w2, #0x1
    c350:	540001a1 	b.ne	c384 <f0+0x2194>  // b.any
    c354:	29430002 	ldp	w2, w0, [x0, #24]
    c358:	92403c21 	and	x1, x1, #0xffff
    c35c:	9b027c21 	mul	x1, x1, x2
    c360:	d360fc21 	lsr	x1, x1, #32
    c364:	eb00003f 	cmp	x1, x0
    c368:	540000e2 	b.cs	c384 <f0+0x2194>  // b.hs, b.nlast
    c36c:	8b0102f7 	add	x23, x23, x1
    c370:	394002e0 	ldrb	w0, [x23]
    c374:	7103fc1f 	cmp	w0, #0xff
    c378:	540027c0 	b.eq	c870 <f0+0x2680>  // b.none
    c37c:	52800020 	mov	w0, #0x1                   	// #1
    c380:	390002e0 	strb	w0, [x23]
    c384:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c388:	9120e3e1 	add	x1, sp, #0x838
    c38c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c390:	52800020 	mov	w0, #0x1                   	// #1
    c394:	f9041fe2 	str	x2, [sp, #2104]
    c398:	91174294 	add	x20, x20, #0x5d0
    c39c:	f90423f5 	str	x21, [sp, #2112]
    c3a0:	97ffe339 	bl	5084 <fwp_data.part.0.constprop.0>
    c3a4:	97ffe5cc 	bl	5ad4 <fwp_rc_fresh>
    c3a8:	aa0003e2 	mov	x2, x0
    c3ac:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c3b0:	912123e1 	add	x1, sp, #0x848
    c3b4:	52800020 	mov	w0, #0x1                   	// #1
    c3b8:	f90427e3 	str	x3, [sp, #2120]
    c3bc:	f9042be2 	str	x2, [sp, #2128]
    c3c0:	97ffe331 	bl	5084 <fwp_data.part.0.constprop.0>
    c3c4:	f949da81 	ldr	x1, [x20, #5040]
    c3c8:	aa0003f5 	mov	x21, x0
    c3cc:	f949ee80 	ldr	x0, [x20, #5080]
    c3d0:	cb0102a1 	sub	x1, x21, x1
    c3d4:	eb00403f 	cmp	x1, x0, lsl #16
    c3d8:	54000322 	b.cs	c43c <f0+0x224c>  // b.hs, b.nlast
    c3dc:	d350fc22 	lsr	x2, x1, #16
    c3e0:	f949fe83 	ldr	x3, [x20, #5112]
    c3e4:	8b020842 	add	x2, x2, x2, lsl #2
    c3e8:	d37df042 	lsl	x2, x2, #3
    c3ec:	8b020060 	add	x0, x3, x2
    c3f0:	f9401014 	ldr	x20, [x0, #32]
    c3f4:	b4000254 	cbz	x20, c43c <f0+0x224c>
    c3f8:	38626862 	ldrb	w2, [x3, x2]
    c3fc:	7100085f 	cmp	w2, #0x2
    c400:	54000e80 	b.eq	c5d0 <f0+0x23e0>  // b.none
    c404:	7100045f 	cmp	w2, #0x1
    c408:	540001a1 	b.ne	c43c <f0+0x224c>  // b.any
    c40c:	29430002 	ldp	w2, w0, [x0, #24]
    c410:	92403c21 	and	x1, x1, #0xffff
    c414:	9b027c21 	mul	x1, x1, x2
    c418:	d360fc21 	lsr	x1, x1, #32
    c41c:	eb00003f 	cmp	x1, x0
    c420:	540000e2 	b.cs	c43c <f0+0x224c>  // b.hs, b.nlast
    c424:	8b010294 	add	x20, x20, x1
    c428:	39400280 	ldrb	w0, [x20]
    c42c:	7103fc1f 	cmp	w0, #0xff
    c430:	540013c0 	b.eq	c6a8 <f0+0x24b8>  // b.none
    c434:	52800020 	mov	w0, #0x1                   	// #1
    c438:	39000280 	strb	w0, [x20]
    c43c:	aa1603e1 	mov	x1, x22
    c440:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c444:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c448:	52800020 	mov	w0, #0x1                   	// #1
    c44c:	f9042fe2 	str	x2, [sp, #2136]
    c450:	f90433f5 	str	x21, [sp, #2144]
    c454:	97ffe30c 	bl	5084 <fwp_data.part.0.constprop.0>
    c458:	97ffe59f 	bl	5ad4 <fwp_rc_fresh>
    c45c:	aa0003f5 	mov	x21, x0
    c460:	aa1303e1 	mov	x1, x19
    c464:	97fff083 	bl	8670 <fwp_hof0.constprop.0>
    c468:	aa0003f4 	mov	x20, x0
    c46c:	aa1503e0 	mov	x0, x21
    c470:	97ffe6fc 	bl	6060 <fwp_drop0>
    c474:	aa1303e0 	mov	x0, x19
    c478:	97ffe6fa 	bl	6060 <fwp_drop0>
    c47c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c480:	f947f400 	ldr	x0, [x0, #4072]
    c484:	f94437e2 	ldr	x2, [sp, #2152]
    c488:	f9400001 	ldr	x1, [x0]
    c48c:	eb010042 	subs	x2, x2, x1
    c490:	d2800001 	mov	x1, #0x0                   	// #0
    c494:	54001f41 	b.ne	c87c <f0+0x268c>  // b.any
    c498:	9121c3ff 	add	sp, sp, #0x870
    c49c:	aa1403e0 	mov	x0, x20
    c4a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c4a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c4a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c4ac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c4b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    c4b4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c4b8:	d65f03c0 	ret
    c4bc:	aa1c03e0 	mov	x0, x28
    c4c0:	97ffdf54 	bl	4210 <fwp_rc_forget_slot.part.0>
    c4c4:	17fff795 	b	a318 <f0+0x128>
    c4c8:	72003c5f 	tst	w2, #0xffff
    c4cc:	54fef281 	b.ne	a31c <f0+0x12c>  // b.any
    c4d0:	17fff78f 	b	a30c <f0+0x11c>
    c4d4:	72003c3f 	tst	w1, #0xffff
    c4d8:	54fef921 	b.ne	a3fc <f0+0x20c>  // b.any
    c4dc:	17fff7c3 	b	a3e8 <f0+0x1f8>
    c4e0:	72003c3f 	tst	w1, #0xffff
    c4e4:	54ff03c1 	b.ne	a55c <f0+0x36c>  // b.any
    c4e8:	17fff818 	b	a548 <f0+0x358>
    c4ec:	72003c3f 	tst	w1, #0xffff
    c4f0:	54fefde1 	b.ne	a4ac <f0+0x2bc>  // b.any
    c4f4:	17fff7e9 	b	a498 <f0+0x2a8>
    c4f8:	72003c3f 	tst	w1, #0xffff
    c4fc:	54ff0e01 	b.ne	a6bc <f0+0x4cc>  // b.any
    c500:	17fff86a 	b	a6a8 <f0+0x4b8>
    c504:	72003c3f 	tst	w1, #0xffff
    c508:	54ff0821 	b.ne	a60c <f0+0x41c>  // b.any
    c50c:	17fff83b 	b	a5f8 <f0+0x408>
    c510:	72003c3f 	tst	w1, #0xffff
    c514:	54ff19c1 	b.ne	a84c <f0+0x65c>  // b.any
    c518:	17fff8c8 	b	a838 <f0+0x648>
    c51c:	72003c3f 	tst	w1, #0xffff
    c520:	54ff13e1 	b.ne	a79c <f0+0x5ac>  // b.any
    c524:	17fff899 	b	a788 <f0+0x598>
    c528:	72003c3f 	tst	w1, #0xffff
    c52c:	54ff9901 	b.ne	b84c <f0+0x165c>  // b.any
    c530:	17fffcc2 	b	b838 <f0+0x1648>
    c534:	72003c3f 	tst	w1, #0xffff
    c538:	54ff8da1 	b.ne	b6ec <f0+0x14fc>  // b.any
    c53c:	17fffc67 	b	b6d8 <f0+0x14e8>
    c540:	72003c3f 	tst	w1, #0xffff
    c544:	54ffb1c1 	b.ne	bb7c <f0+0x198c>  // b.any
    c548:	17fffd88 	b	bb68 <f0+0x1978>
    c54c:	72003c3f 	tst	w1, #0xffff
    c550:	54ffa9e1 	b.ne	ba8c <f0+0x189c>  // b.any
    c554:	17fffd49 	b	ba78 <f0+0x1888>
    c558:	72003c3f 	tst	w1, #0xffff
    c55c:	54ffbc41 	b.ne	bce4 <f0+0x1af4>  // b.any
    c560:	17fffddc 	b	bcd0 <f0+0x1ae0>
    c564:	72003c3f 	tst	w1, #0xffff
    c568:	54ffb741 	b.ne	bc50 <f0+0x1a60>  // b.any
    c56c:	17fffdb4 	b	bc3c <f0+0x1a4c>
    c570:	72003c3f 	tst	w1, #0xffff
    c574:	54ffc9a1 	b.ne	bea8 <f0+0x1cb8>  // b.any
    c578:	17fffe47 	b	be94 <f0+0x1ca4>
    c57c:	72003c3f 	tst	w1, #0xffff
    c580:	54ffc2a1 	b.ne	bdd4 <f0+0x1be4>  // b.any
    c584:	17fffe0f 	b	bdc0 <f0+0x1bd0>
    c588:	72003c3f 	tst	w1, #0xffff
    c58c:	54ffd341 	b.ne	bff4 <f0+0x1e04>  // b.any
    c590:	17fffe94 	b	bfe0 <f0+0x1df0>
    c594:	72003c3f 	tst	w1, #0xffff
    c598:	54ffcd21 	b.ne	bf3c <f0+0x1d4c>  // b.any
    c59c:	17fffe63 	b	bf28 <f0+0x1d38>
    c5a0:	72003c3f 	tst	w1, #0xffff
    c5a4:	54ffdee1 	b.ne	c180 <f0+0x1f90>  // b.any
    c5a8:	17fffef1 	b	c16c <f0+0x1f7c>
    c5ac:	72003c3f 	tst	w1, #0xffff
    c5b0:	54ffd8c1 	b.ne	c0c8 <f0+0x1ed8>  // b.any
    c5b4:	17fffec0 	b	c0b4 <f0+0x1ec4>
    c5b8:	72003c3f 	tst	w1, #0xffff
    c5bc:	54ffe881 	b.ne	c2cc <f0+0x20dc>  // b.any
    c5c0:	17ffff3e 	b	c2b8 <f0+0x20c8>
    c5c4:	72003c3f 	tst	w1, #0xffff
    c5c8:	54ffe261 	b.ne	c214 <f0+0x2024>  // b.any
    c5cc:	17ffff0d 	b	c200 <f0+0x2010>
    c5d0:	72003c3f 	tst	w1, #0xffff
    c5d4:	54fff341 	b.ne	c43c <f0+0x224c>  // b.any
    c5d8:	17ffff94 	b	c428 <f0+0x2238>
    c5dc:	72003c3f 	tst	w1, #0xffff
    c5e0:	54ffed21 	b.ne	c384 <f0+0x2194>  // b.any
    c5e4:	17ffff63 	b	c370 <f0+0x2180>
    c5e8:	72003c3f 	tst	w1, #0xffff
    c5ec:	54ff1e01 	b.ne	a9ac <f0+0x7bc>  // b.any
    c5f0:	17fff8ea 	b	a998 <f0+0x7a8>
    c5f4:	72003c3f 	tst	w1, #0xffff
    c5f8:	54ff1821 	b.ne	a8fc <f0+0x70c>  // b.any
    c5fc:	17fff8bb 	b	a8e8 <f0+0x6f8>
    c600:	72003c3f 	tst	w1, #0xffff
    c604:	54ff29c1 	b.ne	ab3c <f0+0x94c>  // b.any
    c608:	17fff948 	b	ab28 <f0+0x938>
    c60c:	72003c3f 	tst	w1, #0xffff
    c610:	54ff23e1 	b.ne	aa8c <f0+0x89c>  // b.any
    c614:	17fff919 	b	aa78 <f0+0x888>
    c618:	72003c3f 	tst	w1, #0xffff
    c61c:	54ff3461 	b.ne	aca8 <f0+0xab8>  // b.any
    c620:	17fff99d 	b	ac94 <f0+0xaa4>
    c624:	72003c3f 	tst	w1, #0xffff
    c628:	54ff2e41 	b.ne	abf0 <f0+0xa00>  // b.any
    c62c:	17fff96c 	b	abdc <f0+0x9ec>
    c630:	72003c3f 	tst	w1, #0xffff
    c634:	54ff41c1 	b.ne	ae6c <f0+0xc7c>  // b.any
    c638:	17fffa08 	b	ae58 <f0+0xc68>
    c63c:	72003c3f 	tst	w1, #0xffff
    c640:	54ff39e1 	b.ne	ad7c <f0+0xb8c>  // b.any
    c644:	17fff9c9 	b	ad68 <f0+0xb78>
    c648:	72003c3f 	tst	w1, #0xffff
    c64c:	54ff4b61 	b.ne	afb8 <f0+0xdc8>  // b.any
    c650:	17fffa55 	b	afa4 <f0+0xdb4>
    c654:	72003c3f 	tst	w1, #0xffff
    c658:	54ff4541 	b.ne	af00 <f0+0xd10>  // b.any
    c65c:	17fffa24 	b	aeec <f0+0xcfc>
    c660:	72003c3f 	tst	w1, #0xffff
    c664:	54ff56e1 	b.ne	b140 <f0+0xf50>  // b.any
    c668:	17fffab1 	b	b12c <f0+0xf3c>
    c66c:	72003c3f 	tst	w1, #0xffff
    c670:	54ff4f01 	b.ne	b050 <f0+0xe60>  // b.any
    c674:	17fffa72 	b	b03c <f0+0xe4c>
    c678:	72003c3f 	tst	w1, #0xffff
    c67c:	54ff6ec1 	b.ne	b454 <f0+0x1264>  // b.any
    c680:	17fffb70 	b	b440 <f0+0x1250>
    c684:	72003c3f 	tst	w1, #0xffff
    c688:	54ff6521 	b.ne	b32c <f0+0x113c>  // b.any
    c68c:	17fffb23 	b	b318 <f0+0x1128>
    c690:	72003c3f 	tst	w1, #0xffff
    c694:	54ff7b41 	b.ne	b5fc <f0+0x140c>  // b.any
    c698:	17fffbd4 	b	b5e8 <f0+0x13f8>
    c69c:	72003c3f 	tst	w1, #0xffff
    c6a0:	54ff7361 	b.ne	b50c <f0+0x131c>  // b.any
    c6a4:	17fffb95 	b	b4f8 <f0+0x1308>
    c6a8:	aa1403e0 	mov	x0, x20
    c6ac:	97ffded9 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6b0:	17ffff61 	b	c434 <f0+0x2244>
    c6b4:	aa1703e0 	mov	x0, x23
    c6b8:	97ffded6 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6bc:	17fff74e 	b	a3f4 <f0+0x204>
    c6c0:	aa1703e0 	mov	x0, x23
    c6c4:	97ffded3 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6c8:	17fff777 	b	a4a4 <f0+0x2b4>
    c6cc:	aa1703e0 	mov	x0, x23
    c6d0:	97ffded0 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6d4:	17fff7a0 	b	a554 <f0+0x364>
    c6d8:	aa1703e0 	mov	x0, x23
    c6dc:	97ffdecd 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6e0:	17fff7c9 	b	a604 <f0+0x414>
    c6e4:	aa1703e0 	mov	x0, x23
    c6e8:	97ffdeca 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6ec:	17fff7f2 	b	a6b4 <f0+0x4c4>
    c6f0:	aa1703e0 	mov	x0, x23
    c6f4:	97ffdec7 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6f8:	17fff827 	b	a794 <f0+0x5a4>
    c6fc:	aa1703e0 	mov	x0, x23
    c700:	97ffdec4 	bl	4210 <fwp_rc_forget_slot.part.0>
    c704:	17fff850 	b	a844 <f0+0x654>
    c708:	aa1703e0 	mov	x0, x23
    c70c:	97ffdec1 	bl	4210 <fwp_rc_forget_slot.part.0>
    c710:	17fff879 	b	a8f4 <f0+0x704>
    c714:	aa1703e0 	mov	x0, x23
    c718:	97ffdebe 	bl	4210 <fwp_rc_forget_slot.part.0>
    c71c:	17fff8a2 	b	a9a4 <f0+0x7b4>
    c720:	aa1703e0 	mov	x0, x23
    c724:	97ffdebb 	bl	4210 <fwp_rc_forget_slot.part.0>
    c728:	17fff8d7 	b	aa84 <f0+0x894>
    c72c:	aa1703e0 	mov	x0, x23
    c730:	97ffdeb8 	bl	4210 <fwp_rc_forget_slot.part.0>
    c734:	17fff900 	b	ab34 <f0+0x944>
    c738:	aa1703e0 	mov	x0, x23
    c73c:	97ffdeb5 	bl	4210 <fwp_rc_forget_slot.part.0>
    c740:	17fff92a 	b	abe8 <f0+0x9f8>
    c744:	aa1703e0 	mov	x0, x23
    c748:	97ffdeb2 	bl	4210 <fwp_rc_forget_slot.part.0>
    c74c:	17fff955 	b	aca0 <f0+0xab0>
    c750:	aa1703e0 	mov	x0, x23
    c754:	97ffdeaf 	bl	4210 <fwp_rc_forget_slot.part.0>
    c758:	17fff987 	b	ad74 <f0+0xb84>
    c75c:	aa1703e0 	mov	x0, x23
    c760:	97ffdeac 	bl	4210 <fwp_rc_forget_slot.part.0>
    c764:	17fff9c0 	b	ae64 <f0+0xc74>
    c768:	aa1703e0 	mov	x0, x23
    c76c:	97ffdea9 	bl	4210 <fwp_rc_forget_slot.part.0>
    c770:	17fff9e2 	b	aef8 <f0+0xd08>
    c774:	aa1703e0 	mov	x0, x23
    c778:	97ffdea6 	bl	4210 <fwp_rc_forget_slot.part.0>
    c77c:	17fffa0d 	b	afb0 <f0+0xdc0>
    c780:	aa1703e0 	mov	x0, x23
    c784:	97ffdea3 	bl	4210 <fwp_rc_forget_slot.part.0>
    c788:	17fffa30 	b	b048 <f0+0xe58>
    c78c:	aa1503e0 	mov	x0, x21
    c790:	97ffdea0 	bl	4210 <fwp_rc_forget_slot.part.0>
    c794:	17fffa69 	b	b138 <f0+0xf48>
    c798:	aa1703e0 	mov	x0, x23
    c79c:	97ffde9d 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7a0:	17fffae1 	b	b324 <f0+0x1134>
    c7a4:	aa1703e0 	mov	x0, x23
    c7a8:	97ffde9a 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7ac:	17fffb28 	b	b44c <f0+0x125c>
    c7b0:	aa1703e0 	mov	x0, x23
    c7b4:	97ffde97 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7b8:	17fffb53 	b	b504 <f0+0x1314>
    c7bc:	aa1703e0 	mov	x0, x23
    c7c0:	97ffde94 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7c4:	17fffb8c 	b	b5f4 <f0+0x1404>
    c7c8:	aa1703e0 	mov	x0, x23
    c7cc:	97ffde91 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7d0:	17fffbc5 	b	b6e4 <f0+0x14f4>
    c7d4:	aa1703e0 	mov	x0, x23
    c7d8:	97ffde8e 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7dc:	17fffc1a 	b	b844 <f0+0x1654>
    c7e0:	aa1703e0 	mov	x0, x23
    c7e4:	97ffde8b 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7e8:	17fffca7 	b	ba84 <f0+0x1894>
    c7ec:	aa1703e0 	mov	x0, x23
    c7f0:	97ffde88 	bl	4210 <fwp_rc_forget_slot.part.0>
    c7f4:	17fffce0 	b	bb74 <f0+0x1984>
    c7f8:	aa1703e0 	mov	x0, x23
    c7fc:	97ffde85 	bl	4210 <fwp_rc_forget_slot.part.0>
    c800:	17fffd12 	b	bc48 <f0+0x1a58>
    c804:	aa1703e0 	mov	x0, x23
    c808:	97ffde82 	bl	4210 <fwp_rc_forget_slot.part.0>
    c80c:	17fffd34 	b	bcdc <f0+0x1aec>
    c810:	aa1703e0 	mov	x0, x23
    c814:	97ffde7f 	bl	4210 <fwp_rc_forget_slot.part.0>
    c818:	17fffd6d 	b	bdcc <f0+0x1bdc>
    c81c:	aa1703e0 	mov	x0, x23
    c820:	97ffde7c 	bl	4210 <fwp_rc_forget_slot.part.0>
    c824:	17fffd9f 	b	bea0 <f0+0x1cb0>
    c828:	aa1703e0 	mov	x0, x23
    c82c:	97ffde79 	bl	4210 <fwp_rc_forget_slot.part.0>
    c830:	17fffdc1 	b	bf34 <f0+0x1d44>
    c834:	aa1703e0 	mov	x0, x23
    c838:	97ffde76 	bl	4210 <fwp_rc_forget_slot.part.0>
    c83c:	17fffdec 	b	bfec <f0+0x1dfc>
    c840:	aa1703e0 	mov	x0, x23
    c844:	97ffde73 	bl	4210 <fwp_rc_forget_slot.part.0>
    c848:	17fffe1e 	b	c0c0 <f0+0x1ed0>
    c84c:	aa1703e0 	mov	x0, x23
    c850:	97ffde70 	bl	4210 <fwp_rc_forget_slot.part.0>
    c854:	17fffe49 	b	c178 <f0+0x1f88>
    c858:	aa1703e0 	mov	x0, x23
    c85c:	97ffde6d 	bl	4210 <fwp_rc_forget_slot.part.0>
    c860:	17fffe6b 	b	c20c <f0+0x201c>
    c864:	aa1703e0 	mov	x0, x23
    c868:	97ffde6a 	bl	4210 <fwp_rc_forget_slot.part.0>
    c86c:	17fffe96 	b	c2c4 <f0+0x20d4>
    c870:	aa1703e0 	mov	x0, x23
    c874:	97ffde67 	bl	4210 <fwp_rc_forget_slot.part.0>
    c878:	17fffec1 	b	c37c <f0+0x218c>
    c87c:	97ffd825 	bl	2910 <__stack_chk_fail@plt>
    c880:	97ffd838 	bl	2960 <abort@plt>

000000000000c884 <fwp_main_thread>:
    c884:	d10443ff 	sub	sp, sp, #0x110
    c888:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c88c:	f947f400 	ldr	x0, [x0, #4072]
    c890:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c894:	910303fd 	add	x29, sp, #0xc0
    c898:	a90d53f3 	stp	x19, x20, [sp, #208]
    c89c:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c8a0:	91174261 	add	x1, x19, #0x5d0
    c8a4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c8a8:	b953a421 	ldr	w1, [x1, #5028]
    c8ac:	f9400002 	ldr	x2, [x0]
    c8b0:	f9005fe2 	str	x2, [sp, #184]
    c8b4:	d2800002 	mov	x2, #0x0                   	// #0
    c8b8:	34000e81 	cbz	w1, ca88 <fwp_main_thread+0x204>
    c8bc:	91174273 	add	x19, x19, #0x5d0
    c8c0:	b953aa60 	ldr	w0, [x19, #5032]
    c8c4:	35000da0 	cbnz	w0, ca78 <fwp_main_thread+0x1f4>
    c8c8:	91001fe2 	add	x2, sp, #0x7
    c8cc:	900000b4 	adrp	x20, 20000 <__data_start>
    c8d0:	900000a3 	adrp	x3, 20000 <__data_start>
    c8d4:	9101c293 	add	x19, x20, #0x70
    c8d8:	910fc063 	add	x3, x3, #0x3f0
    c8dc:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c8e0:	d2a00025 	mov	x5, #0x10000               	// #65536
    c8e4:	910023e0 	add	x0, sp, #0x8
    c8e8:	d2800001 	mov	x1, #0x0                   	// #0
    c8ec:	f90007e3 	str	x3, [sp, #8]
    c8f0:	b90013ff 	str	wzr, [sp, #16]
    c8f4:	a9019262 	stp	x2, x4, [x19, #24]
    c8f8:	f9000fe5 	str	x5, [sp, #24]
    c8fc:	97ffd79d 	bl	2770 <sigaltstack@plt>
    c900:	35000220 	cbnz	w0, c944 <fwp_main_thread+0xc0>
    c904:	4f000400 	movi	v0.4s, #0x0
    c908:	9100a3e0 	add	x0, sp, #0x28
    c90c:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c910:	52800082 	mov	w2, #0x4                   	// #4
    c914:	9103c021 	add	x1, x1, #0xf0
    c918:	72a10002 	movk	w2, #0x800, lsl #16
    c91c:	910083f5 	add	x21, sp, #0x20
    c920:	f90013e1 	str	x1, [sp, #32]
    c924:	3d802000 	str	q0, [x0, #128]
    c928:	b900abe2 	str	w2, [sp, #168]
    c92c:	ad000000 	stp	q0, q0, [x0]
    c930:	ad010000 	stp	q0, q0, [x0, #32]
    c934:	ad020000 	stp	q0, q0, [x0, #64]
    c938:	ad030000 	stp	q0, q0, [x0, #96]
    c93c:	97ffd7e5 	bl	28d0 <sigemptyset@plt>
    c940:	340000c0 	cbz	w0, c958 <fwp_main_thread+0xd4>
    c944:	b0000000 	adrp	x0, d000 <__divti3+0x240>
    c948:	912d4000 	add	x0, x0, #0xb50
    c94c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c950:	f90083f9 	str	x25, [sp, #256]
    c954:	97ffde0f 	bl	4190 <fwp_trap>
    c958:	aa1503e1 	mov	x1, x21
    c95c:	d2800002 	mov	x2, #0x0                   	// #0
    c960:	52800160 	mov	w0, #0xb                   	// #11
    c964:	97ffd7f3 	bl	2930 <sigaction@plt>
    c968:	35fffee0 	cbnz	w0, c944 <fwp_main_thread+0xc0>
    c96c:	aa1503e1 	mov	x1, x21
    c970:	d2800002 	mov	x2, #0x0                   	// #0
    c974:	528000e0 	mov	w0, #0x7                   	// #7
    c978:	97ffd7ee 	bl	2930 <sigaction@plt>
    c97c:	35fffe40 	cbnz	w0, c944 <fwp_main_thread+0xc0>
    c980:	b9434a60 	ldr	w0, [x19, #840]
    c984:	34000860 	cbz	w0, ca90 <fwp_main_thread+0x20c>
    c988:	a90f63f7 	stp	x23, x24, [sp, #240]
    c98c:	9101c293 	add	x19, x20, #0x70
    c990:	b9434e60 	ldr	w0, [x19, #844]
    c994:	34001e60 	cbz	w0, cd60 <fwp_main_thread+0x4dc>
    c998:	9101c296 	add	x22, x20, #0x70
    c99c:	f9400ad5 	ldr	x21, [x22, #16]
    c9a0:	b4000d75 	cbz	x21, cb4c <fwp_main_thread+0x2c8>
    c9a4:	910102b7 	add	x23, x21, #0x40
    c9a8:	f90083f9 	str	x25, [sp, #256]
    c9ac:	52800038 	mov	w24, #0x1                   	// #1
    c9b0:	39414ab9 	ldrb	w25, [x21, #82]
    c9b4:	39014ab8 	strb	w24, [x21, #82]
    c9b8:	f94016a0 	ldr	x0, [x21, #40]
    c9bc:	b4000c40 	cbz	x0, cb44 <fwp_main_thread+0x2c0>
    c9c0:	f94032a1 	ldr	x1, [x21, #96]
    c9c4:	394146a0 	ldrb	w0, [x21, #81]
    c9c8:	b4000861 	cbz	x1, cad4 <fwp_main_thread+0x250>
    c9cc:	36000720 	tbz	w0, #0, cab0 <fwp_main_thread+0x22c>
    c9d0:	f9400ad3 	ldr	x19, [x22, #16]
    c9d4:	f94022a0 	ldr	x0, [x21, #64]
    c9d8:	39414a61 	ldrb	w1, [x19, #82]
    c9dc:	37000a41 	tbnz	w1, #0, cb24 <fwp_main_thread+0x2a0>
    c9e0:	f9403261 	ldr	x1, [x19, #96]
    c9e4:	a911fe77 	stp	x23, xzr, [x19, #280]
    c9e8:	f9009660 	str	x0, [x19, #296]
    c9ec:	b4000040 	cbz	x0, c9f4 <fwp_main_thread+0x170>
    c9f0:	f9009013 	str	x19, [x0, #288]
    c9f4:	f90022b3 	str	x19, [x21, #64]
    c9f8:	b4000101 	cbz	x1, ca18 <fwp_main_thread+0x194>
    c9fc:	f9406ec0 	ldr	x0, [x22, #216]
    ca00:	39015678 	strb	w24, [x19, #85]
    ca04:	f9003661 	str	x1, [x19, #104]
    ca08:	a910827f 	stp	xzr, x0, [x19, #264]
    ca0c:	b4000040 	cbz	x0, ca14 <fwp_main_thread+0x190>
    ca10:	f9008413 	str	x19, [x0, #264]
    ca14:	f9006ed3 	str	x19, [x22, #216]
    ca18:	39015a7f 	strb	wzr, [x19, #86]
    ca1c:	97ffe889 	bl	6c40 <fwp_block>
    ca20:	f9408e62 	ldr	x2, [x19, #280]
    ca24:	b4000142 	cbz	x2, ca4c <fwp_main_thread+0x1c8>
    ca28:	a9520261 	ldp	x1, x0, [x19, #288]
    ca2c:	b4000881 	cbz	x1, cb3c <fwp_main_thread+0x2b8>
    ca30:	f9009420 	str	x0, [x1, #296]
    ca34:	f9409660 	ldr	x0, [x19, #296]
    ca38:	b4000040 	cbz	x0, ca40 <fwp_main_thread+0x1bc>
    ca3c:	f9009001 	str	x1, [x0, #288]
    ca40:	91080260 	add	x0, x19, #0x200
    ca44:	f900967f 	str	xzr, [x19, #296]
    ca48:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    ca4c:	39415660 	ldrb	w0, [x19, #85]
    ca50:	3607fb40 	tbz	w0, #0, c9b8 <fwp_main_thread+0x134>
    ca54:	a9508261 	ldp	x1, x0, [x19, #264]
    ca58:	b4001801 	cbz	x1, cd58 <fwp_main_thread+0x4d4>
    ca5c:	f9008820 	str	x0, [x1, #272]
    ca60:	b4000040 	cbz	x0, ca68 <fwp_main_thread+0x1e4>
    ca64:	f9008401 	str	x1, [x0, #264]
    ca68:	91080260 	add	x0, x19, #0x200
    ca6c:	3901567f 	strb	wzr, [x19, #85]
    ca70:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    ca74:	17ffffd1 	b	c9b8 <fwp_main_thread+0x134>
    ca78:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    ca7c:	91321000 	add	x0, x0, #0xc84
    ca80:	9400028c 	bl	d4b0 <atexit>
    ca84:	17ffff91 	b	c8c8 <fwp_main_thread+0x44>
    ca88:	97ffdcda 	bl	3df0 <fwp_heap_init>
    ca8c:	17ffff8c 	b	c8bc <fwp_main_thread+0x38>
    ca90:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    ca94:	91078000 	add	x0, x0, #0x1e0
    ca98:	94000286 	bl	d4b0 <atexit>
    ca9c:	a90f63f7 	stp	x23, x24, [sp, #240]
    caa0:	35001860 	cbnz	w0, cdac <fwp_main_thread+0x528>
    caa4:	52800020 	mov	w0, #0x1                   	// #1
    caa8:	b9034a60 	str	w0, [x19, #840]
    caac:	17ffffb8 	b	c98c <fwp_main_thread+0x108>
    cab0:	97ffdfd8 	bl	4a10 <fwp_now_ns>
    cab4:	f94032a1 	ldr	x1, [x21, #96]
    cab8:	eb01001f 	cmp	x0, x1
    cabc:	540000ab 	b.lt	cad0 <fwp_main_thread+0x24c>  // b.tstop
    cac0:	394142a0 	ldrb	w0, [x21, #80]
    cac4:	37000060 	tbnz	w0, #0, cad0 <fwp_main_thread+0x24c>
    cac8:	aa1503e0 	mov	x0, x21
    cacc:	97ffdb29 	bl	3770 <fwp_cancel_tree.part.0>
    cad0:	394146a0 	ldrb	w0, [x21, #81]
    cad4:	f9400ad3 	ldr	x19, [x22, #16]
    cad8:	39414a62 	ldrb	w2, [x19, #82]
    cadc:	3707f7a0 	tbnz	w0, #0, c9d0 <fwp_main_thread+0x14c>
    cae0:	f94032a1 	ldr	x1, [x21, #96]
    cae4:	370001c2 	tbnz	w2, #0, cb1c <fwp_main_thread+0x298>
    cae8:	f9403260 	ldr	x0, [x19, #96]
    caec:	b4000180 	cbz	x0, cb1c <fwp_main_thread+0x298>
    caf0:	b4000061 	cbz	x1, cafc <fwp_main_thread+0x278>
    caf4:	eb01001f 	cmp	x0, x1
    caf8:	9a81d000 	csel	x0, x0, x1, le
    cafc:	f94022a1 	ldr	x1, [x21, #64]
    cb00:	a911fe77 	stp	x23, xzr, [x19, #280]
    cb04:	f9009661 	str	x1, [x19, #296]
    cb08:	b4001361 	cbz	x1, cd74 <fwp_main_thread+0x4f0>
    cb0c:	f9009033 	str	x19, [x1, #288]
    cb10:	aa0003e1 	mov	x1, x0
    cb14:	f90022b3 	str	x19, [x21, #64]
    cb18:	17ffffb9 	b	c9fc <fwp_main_thread+0x178>
    cb1c:	f94022a0 	ldr	x0, [x21, #64]
    cb20:	17ffffb1 	b	c9e4 <fwp_main_thread+0x160>
    cb24:	a911fe77 	stp	x23, xzr, [x19, #280]
    cb28:	f9009660 	str	x0, [x19, #296]
    cb2c:	b4000040 	cbz	x0, cb34 <fwp_main_thread+0x2b0>
    cb30:	f9009013 	str	x19, [x0, #288]
    cb34:	f90022b3 	str	x19, [x21, #64]
    cb38:	17ffffb8 	b	ca18 <fwp_main_thread+0x194>
    cb3c:	f9000040 	str	x0, [x2]
    cb40:	17ffffbe 	b	ca38 <fwp_main_thread+0x1b4>
    cb44:	39014ab9 	strb	w25, [x21, #82]
    cb48:	f94083f9 	ldr	x25, [sp, #256]
    cb4c:	9101c293 	add	x19, x20, #0x70
    cb50:	f9419660 	ldr	x0, [x19, #808]
    cb54:	b5000060 	cbnz	x0, cb60 <fwp_main_thread+0x2dc>
    cb58:	f9419e60 	ldr	x0, [x19, #824]
    cb5c:	b4001120 	cbz	x0, cd80 <fwp_main_thread+0x4fc>
    cb60:	9101c280 	add	x0, x20, #0x70
    cb64:	f9400800 	ldr	x0, [x0, #16]
    cb68:	9101c281 	add	x1, x20, #0x70
    cb6c:	f941b026 	ldr	x6, [x1, #864]
    cb70:	b903583f 	str	wzr, [x1, #856]
    cb74:	eb0000df 	cmp	x6, x0
    cb78:	540011e1 	b.ne	cdb4 <fwp_main_thread+0x530>  // b.any
    cb7c:	b40003c0 	cbz	x0, cbf4 <fwp_main_thread+0x370>
    cb80:	f9418025 	ldr	x5, [x1, #768]
    cb84:	52800021 	mov	w1, #0x1                   	// #1
    cb88:	39014801 	strb	w1, [x0, #82]
    cb8c:	b4000345 	cbz	x5, cbf4 <fwp_main_thread+0x370>
    cb90:	394140a0 	ldrb	w0, [x5, #80]
    cb94:	37000060 	tbnz	w0, #0, cba0 <fwp_main_thread+0x31c>
    cb98:	aa0503e0 	mov	x0, x5
    cb9c:	97ffdaf5 	bl	3770 <fwp_cancel_tree.part.0>
    cba0:	f9409ca5 	ldr	x5, [x5, #312]
    cba4:	b5ffff65 	cbnz	x5, cb90 <fwp_main_thread+0x30c>
    cba8:	9101c293 	add	x19, x20, #0x70
    cbac:	52800035 	mov	w21, #0x1                   	// #1
    cbb0:	f94028c0 	ldr	x0, [x6, #80]
    cbb4:	f2001c1f 	tst	x0, #0xff000000ff
    cbb8:	540000e1 	b.ne	cbd4 <fwp_main_thread+0x350>  // b.any
    cbbc:	f9403e60 	ldr	x0, [x19, #120]
    cbc0:	390150d5 	strb	w21, [x6, #84]
    cbc4:	f90080df 	str	xzr, [x6, #256]
    cbc8:	b4000120 	cbz	x0, cbec <fwp_main_thread+0x368>
    cbcc:	f9008006 	str	x6, [x0, #256]
    cbd0:	f9003e66 	str	x6, [x19, #120]
    cbd4:	97ffe81b 	bl	6c40 <fwp_block>
    cbd8:	97ffe7a2 	bl	6a60 <fwp_free_zombie>
    cbdc:	f9418260 	ldr	x0, [x19, #768]
    cbe0:	b40000a0 	cbz	x0, cbf4 <fwp_main_thread+0x370>
    cbe4:	f941b266 	ldr	x6, [x19, #864]
    cbe8:	17fffff2 	b	cbb0 <fwp_main_thread+0x32c>
    cbec:	f9004266 	str	x6, [x19, #128]
    cbf0:	17fffff8 	b	cbd0 <fwp_main_thread+0x34c>
    cbf4:	9101c295 	add	x21, x20, #0x70
    cbf8:	97ffe79a 	bl	6a60 <fwp_free_zombie>
    cbfc:	f94042a0 	ldr	x0, [x21, #128]
    cc00:	b5000da0 	cbnz	x0, cdb4 <fwp_main_thread+0x530>
    cc04:	f9406ea0 	ldr	x0, [x21, #216]
    cc08:	b5000d60 	cbnz	x0, cdb4 <fwp_main_thread+0x530>
    cc0c:	b940fab3 	ldr	w19, [x21, #248]
    cc10:	340001f3 	cbz	w19, cc4c <fwp_main_thread+0x3c8>
    cc14:	93407e76 	sxtw	x22, w19
    cc18:	51000673 	sub	w19, w19, #0x1
    cc1c:	d1000ad6 	sub	x22, x22, #0x2
    cc20:	910402b7 	add	x23, x21, #0x100
    cc24:	cb3342d6 	sub	x22, x22, w19, uxtw
    cc28:	93407e73 	sxtw	x19, w19
    cc2c:	d503201f 	nop
    cc30:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cc34:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cc38:	b900fab3 	str	w19, [x21, #248]
    cc3c:	d1000673 	sub	x19, x19, #0x1
    cc40:	97ffd77c 	bl	2a30 <munmap@plt>
    cc44:	eb1302df 	cmp	x22, x19
    cc48:	54ffff41 	b.ne	cc30 <fwp_main_thread+0x3ac>  // b.any
    cc4c:	900000b3 	adrp	x19, 20000 <__data_start>
    cc50:	91004260 	add	x0, x19, #0x10
    cc54:	b9404000 	ldr	w0, [x0, #64]
    cc58:	37f80040 	tbnz	w0, #31, cc60 <fwp_main_thread+0x3dc>
    cc5c:	97ffd731 	bl	2920 <close@plt>
    cc60:	9101c295 	add	x21, x20, #0x70
    cc64:	91004273 	add	x19, x19, #0x10
    cc68:	12800001 	mov	w1, #0xffffffff            	// #-1
    cc6c:	f941baa0 	ldr	x0, [x21, #880]
    cc70:	b9004261 	str	w1, [x19, #64]
    cc74:	f941b6a1 	ldr	x1, [x21, #872]
    cc78:	b40001c0 	cbz	x0, ccb0 <fwp_main_thread+0x42c>
    cc7c:	d2800013 	mov	x19, #0x0                   	// #0
    cc80:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cc84:	b40000e0 	cbz	x0, cca0 <fwp_main_thread+0x41c>
    cc88:	f9400001 	ldr	x1, [x0]
    cc8c:	b5000941 	cbnz	x1, cdb4 <fwp_main_thread+0x530>
    cc90:	f9400401 	ldr	x1, [x0, #8]
    cc94:	b5000901 	cbnz	x1, cdb4 <fwp_main_thread+0x530>
    cc98:	97ffddfa 	bl	4480 <fwp_mem_free>
    cc9c:	f941b6a1 	ldr	x1, [x21, #872]
    cca0:	91000673 	add	x19, x19, #0x1
    cca4:	f941baa0 	ldr	x0, [x21, #880]
    cca8:	eb00027f 	cmp	x19, x0
    ccac:	54fffea3 	b.cc	cc80 <fwp_main_thread+0x3fc>  // b.lo, b.ul, b.last
    ccb0:	aa0103e0 	mov	x0, x1
    ccb4:	97ffddf3 	bl	4480 <fwp_mem_free>
    ccb8:	9101c280 	add	x0, x20, #0x70
    ccbc:	f941b013 	ldr	x19, [x0, #864]
    ccc0:	f901b41f 	str	xzr, [x0, #872]
    ccc4:	f901b81f 	str	xzr, [x0, #880]
    ccc8:	b40001f3 	cbz	x19, cd04 <fwp_main_thread+0x480>
    cccc:	f9401661 	ldr	x1, [x19, #40]
    ccd0:	b5000721 	cbnz	x1, cdb4 <fwp_main_thread+0x530>
    ccd4:	f9405661 	ldr	x1, [x19, #168]
    ccd8:	b50006e1 	cbnz	x1, cdb4 <fwp_main_thread+0x530>
    ccdc:	f9419401 	ldr	x1, [x0, #808]
    cce0:	b50006a1 	cbnz	x1, cdb4 <fwp_main_thread+0x530>
    cce4:	f9419c00 	ldr	x0, [x0, #824]
    cce8:	b5000660 	cbnz	x0, cdb4 <fwp_main_thread+0x530>
    ccec:	d2823a02 	mov	x2, #0x11d0                	// #4560
    ccf0:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    ccf4:	910fc000 	add	x0, x0, #0x3f0
    ccf8:	97ffd6fa 	bl	28e0 <memset@plt>
    ccfc:	aa1303e0 	mov	x0, x19
    cd00:	97ffdde0 	bl	4480 <fwp_mem_free>
    cd04:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    cd08:	f947ec00 	ldr	x0, [x0, #4056]
    cd0c:	9101c294 	add	x20, x20, #0x70
    cd10:	f9400000 	ldr	x0, [x0]
    cd14:	f9000a9f 	str	xzr, [x20, #16]
    cd18:	f901b29f 	str	xzr, [x20, #864]
    cd1c:	97ffd749 	bl	2a40 <fflush@plt>
    cd20:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    cd24:	f947f400 	ldr	x0, [x0, #4072]
    cd28:	f9405fe2 	ldr	x2, [sp, #184]
    cd2c:	f9400001 	ldr	x1, [x0]
    cd30:	eb010042 	subs	x2, x2, x1
    cd34:	d2800001 	mov	x1, #0x0                   	// #0
    cd38:	54000361 	b.ne	cda4 <fwp_main_thread+0x520>  // b.any
    cd3c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cd40:	d2800000 	mov	x0, #0x0                   	// #0
    cd44:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cd48:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cd4c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cd50:	910443ff 	add	sp, sp, #0x110
    cd54:	d65f03c0 	ret
    cd58:	f9006ec0 	str	x0, [x22, #216]
    cd5c:	17ffff41 	b	ca60 <fwp_main_thread+0x1dc>
    cd60:	97fff524 	bl	a1f0 <f0>
    cd64:	f901aa60 	str	x0, [x19, #848]
    cd68:	52800021 	mov	w1, #0x1                   	// #1
    cd6c:	b9034e61 	str	w1, [x19, #844]
    cd70:	17ffff0a 	b	c998 <fwp_main_thread+0x114>
    cd74:	aa0003e1 	mov	x1, x0
    cd78:	f90022b3 	str	x19, [x21, #64]
    cd7c:	17ffff20 	b	c9fc <fwp_main_thread+0x178>
    cd80:	f9419260 	ldr	x0, [x19, #800]
    cd84:	97ffddbf 	bl	4480 <fwp_mem_free>
    cd88:	f901927f 	str	xzr, [x19, #800]
    cd8c:	f9400a60 	ldr	x0, [x19, #16]
    cd90:	f9019a7f 	str	xzr, [x19, #816]
    cd94:	b4ffeea0 	cbz	x0, cb68 <fwp_main_thread+0x2e4>
    cd98:	f900541f 	str	xzr, [x0, #168]
    cd9c:	f9005c1f 	str	xzr, [x0, #184]
    cda0:	17ffff72 	b	cb68 <fwp_main_thread+0x2e4>
    cda4:	f90083f9 	str	x25, [sp, #256]
    cda8:	97ffd6da 	bl	2910 <__stack_chk_fail@plt>
    cdac:	f90083f9 	str	x25, [sp, #256]
    cdb0:	97ffd900 	bl	31b0 <descent_phase_fail>
    cdb4:	f90083f9 	str	x25, [sp, #256]
    cdb8:	97ffd6ea 	bl	2960 <abort@plt>
    cdbc:	d503201f 	nop

000000000000cdc0 <__divti3>:
    cdc0:	d503245f 	bti	c
    cdc4:	d2800004 	mov	x4, #0x0                   	// #0
    cdc8:	b7f80721 	tbnz	x1, #63, ceac <__divti3+0xec>
    cdcc:	b6f80083 	tbz	x3, #63, cddc <__divti3+0x1c>
    cdd0:	eb0203e2 	negs	x2, x2
    cdd4:	aa2403e4 	mvn	x4, x4
    cdd8:	da0303e3 	ngc	x3, x3
    cddc:	aa0203e6 	mov	x6, x2
    cde0:	aa0003e7 	mov	x7, x0
    cde4:	aa0103e5 	mov	x5, x1
    cde8:	b5000583 	cbnz	x3, ce98 <__divti3+0xd8>
    cdec:	eb01005f 	cmp	x2, x1
    cdf0:	54000e69 	b.ls	cfbc <__divti3+0x1fc>  // b.plast
    cdf4:	dac01040 	clz	x0, x2
    cdf8:	b40000e0 	cbz	x0, ce14 <__divti3+0x54>
    cdfc:	4b0003e1 	neg	w1, w0
    ce00:	9ac020a5 	lsl	x5, x5, x0
    ce04:	9ac02046 	lsl	x6, x2, x0
    ce08:	9ac124e1 	lsr	x1, x7, x1
    ce0c:	aa050025 	orr	x5, x1, x5
    ce10:	9ac020e7 	lsl	x7, x7, x0
    ce14:	d360fcc8 	lsr	x8, x6, #32
    ce18:	92407cc2 	and	x2, x6, #0xffffffff
    ce1c:	9ac808a3 	udiv	x3, x5, x8
    ce20:	9b089465 	msub	x5, x3, x8, x5
    ce24:	aa0303e0 	mov	x0, x3
    ce28:	9b037c41 	mul	x1, x2, x3
    ce2c:	93c780a5 	extr	x5, x5, x7, #32
    ce30:	eb05003f 	cmp	x1, x5
    ce34:	540000a9 	b.ls	ce48 <__divti3+0x88>  // b.plast
    ce38:	ab0500c5 	adds	x5, x6, x5
    ce3c:	d1000460 	sub	x0, x3, #0x1
    ce40:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ce44:	540015a8 	b.hi	d0f8 <__divti3+0x338>  // b.pmore
    ce48:	cb0100a5 	sub	x5, x5, x1
    ce4c:	9ac808a3 	udiv	x3, x5, x8
    ce50:	9b089465 	msub	x5, x3, x8, x5
    ce54:	aa0303e1 	mov	x1, x3
    ce58:	9b037c42 	mul	x2, x2, x3
    ce5c:	aa0703e3 	mov	x3, x7
    ce60:	b3607ca3 	bfi	x3, x5, #32, #32
    ce64:	eb03005f 	cmp	x2, x3
    ce68:	540000c9 	b.ls	ce80 <__divti3+0xc0>  // b.plast
    ce6c:	ab0300c3 	adds	x3, x6, x3
    ce70:	d1000425 	sub	x5, x1, #0x1
    ce74:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce78:	d1000821 	sub	x1, x1, #0x2
    ce7c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ce80:	aa008020 	orr	x0, x1, x0, lsl #32
    ce84:	d2800001 	mov	x1, #0x0                   	// #0
    ce88:	b4000064 	cbz	x4, ce94 <__divti3+0xd4>
    ce8c:	eb0003e0 	negs	x0, x0
    ce90:	da0103e1 	ngc	x1, x1
    ce94:	d65f03c0 	ret
    ce98:	eb01007f 	cmp	x3, x1
    ce9c:	54000109 	b.ls	cebc <__divti3+0xfc>  // b.plast
    cea0:	d2800001 	mov	x1, #0x0                   	// #0
    cea4:	d2800000 	mov	x0, #0x0                   	// #0
    cea8:	17fffff8 	b	ce88 <__divti3+0xc8>
    ceac:	eb0003e0 	negs	x0, x0
    ceb0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ceb4:	da0103e1 	ngc	x1, x1
    ceb8:	17ffffc5 	b	cdcc <__divti3+0xc>
    cebc:	dac01067 	clz	x7, x3
    cec0:	b40010e7 	cbz	x7, d0dc <__divti3+0x31c>
    cec4:	d2800805 	mov	x5, #0x40                  	// #64
    cec8:	cb0700a5 	sub	x5, x5, x7
    cecc:	9ac72063 	lsl	x3, x3, x7
    ced0:	9ac52448 	lsr	x8, x2, x5
    ced4:	aa030108 	orr	x8, x8, x3
    ced8:	9ac52426 	lsr	x6, x1, x5
    cedc:	92407d0a 	and	x10, x8, #0xffffffff
    cee0:	d360fd09 	lsr	x9, x8, #32
    cee4:	9ac52403 	lsr	x3, x0, x5
    cee8:	9ac72021 	lsl	x1, x1, x7
    ceec:	aa010063 	orr	x3, x3, x1
    cef0:	9ac72042 	lsl	x2, x2, x7
    cef4:	9ac908cb 	udiv	x11, x6, x9
    cef8:	9b099965 	msub	x5, x11, x9, x6
    cefc:	aa0b03e1 	mov	x1, x11
    cf00:	9b0b7d46 	mul	x6, x10, x11
    cf04:	93c380a5 	extr	x5, x5, x3, #32
    cf08:	eb0500df 	cmp	x6, x5
    cf0c:	540000a9 	b.ls	cf20 <__divti3+0x160>  // b.plast
    cf10:	ab050105 	adds	x5, x8, x5
    cf14:	d1000561 	sub	x1, x11, #0x1
    cf18:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cf1c:	54000f48 	b.hi	d104 <__divti3+0x344>  // b.pmore
    cf20:	cb0600a6 	sub	x6, x5, x6
    cf24:	9ac908cb 	udiv	x11, x6, x9
    cf28:	9b099969 	msub	x9, x11, x9, x6
    cf2c:	aa0b03e5 	mov	x5, x11
    cf30:	9b0b7d4a 	mul	x10, x10, x11
    cf34:	b3607d23 	bfi	x3, x9, #32, #32
    cf38:	eb03015f 	cmp	x10, x3
    cf3c:	540000a9 	b.ls	cf50 <__divti3+0x190>  // b.plast
    cf40:	ab030103 	adds	x3, x8, x3
    cf44:	d1000565 	sub	x5, x11, #0x1
    cf48:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cf4c:	54000e28 	b.hi	d110 <__divti3+0x350>  // b.pmore
    cf50:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cf54:	92407c48 	and	x8, x2, #0xffffffff
    cf58:	2a0503e5 	mov	w5, w5
    cf5c:	d360fc42 	lsr	x2, x2, #32
    cf60:	d360fc26 	lsr	x6, x1, #32
    cf64:	cb0a0063 	sub	x3, x3, x10
    cf68:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cf6c:	9b087caa 	mul	x10, x5, x8
    cf70:	9b087cc8 	mul	x8, x6, x8
    cf74:	9b0220a5 	madd	x5, x5, x2, x8
    cf78:	9b027cc6 	mul	x6, x6, x2
    cf7c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cf80:	8b0900c5 	add	x5, x6, x9
    cf84:	eb02011f 	cmp	x8, x2
    cf88:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cf8c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cf90:	eb06007f 	cmp	x3, x6
    cf94:	540000e3 	b.cc	cfb0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cf98:	92407d4a 	and	x10, x10, #0xffffffff
    cf9c:	9ac72000 	lsl	x0, x0, x7
    cfa0:	8b028142 	add	x2, x10, x2, lsl #32
    cfa4:	eb02001f 	cmp	x0, x2
    cfa8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cfac:	54000a01 	b.ne	d0ec <__divti3+0x32c>  // b.any
    cfb0:	d1000420 	sub	x0, x1, #0x1
    cfb4:	d2800001 	mov	x1, #0x0                   	// #0
    cfb8:	17ffffb4 	b	ce88 <__divti3+0xc8>
    cfbc:	b5000062 	cbnz	x2, cfc8 <__divti3+0x208>
    cfc0:	d2800022 	mov	x2, #0x1                   	// #1
    cfc4:	9ac30846 	udiv	x6, x2, x3
    cfc8:	dac010c8 	clz	x8, x6
    cfcc:	b5000408 	cbnz	x8, d04c <__divti3+0x28c>
    cfd0:	d360fcc9 	lsr	x9, x6, #32
    cfd4:	92407cc5 	and	x5, x6, #0xffffffff
    cfd8:	cb060023 	sub	x3, x1, x6
    cfdc:	d2800021 	mov	x1, #0x1                   	// #1
    cfe0:	9ac90868 	udiv	x8, x3, x9
    cfe4:	9b098d03 	msub	x3, x8, x9, x3
    cfe8:	aa0803e0 	mov	x0, x8
    cfec:	9b057d02 	mul	x2, x8, x5
    cff0:	93c78063 	extr	x3, x3, x7, #32
    cff4:	eb03005f 	cmp	x2, x3
    cff8:	540000a9 	b.ls	d00c <__divti3+0x24c>  // b.plast
    cffc:	ab0300c3 	adds	x3, x6, x3
    d000:	d1000500 	sub	x0, x8, #0x1
    d004:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d008:	54000968 	b.hi	d134 <__divti3+0x374>  // b.pmore
    d00c:	cb020063 	sub	x3, x3, x2
    d010:	9ac90862 	udiv	x2, x3, x9
    d014:	aa0203e8 	mov	x8, x2
    d018:	9b098c42 	msub	x2, x2, x9, x3
    d01c:	aa0703e3 	mov	x3, x7
    d020:	9b057d05 	mul	x5, x8, x5
    d024:	b3607c43 	bfi	x3, x2, #32, #32
    d028:	eb0300bf 	cmp	x5, x3
    d02c:	540000c9 	b.ls	d044 <__divti3+0x284>  // b.plast
    d030:	ab0300c2 	adds	x2, x6, x3
    d034:	d1000503 	sub	x3, x8, #0x1
    d038:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d03c:	d1000908 	sub	x8, x8, #0x2
    d040:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d044:	aa008100 	orr	x0, x8, x0, lsl #32
    d048:	17ffff90 	b	ce88 <__divti3+0xc8>
    d04c:	9ac820c6 	lsl	x6, x6, x8
    d050:	d2800803 	mov	x3, #0x40                  	// #64
    d054:	cb080063 	sub	x3, x3, x8
    d058:	d360fcc9 	lsr	x9, x6, #32
    d05c:	9ac82027 	lsl	x7, x1, x8
    d060:	92407cc5 	and	x5, x6, #0xffffffff
    d064:	9ac32422 	lsr	x2, x1, x3
    d068:	9ac32403 	lsr	x3, x0, x3
    d06c:	aa070063 	orr	x3, x3, x7
    d070:	9ac9084a 	udiv	x10, x2, x9
    d074:	9ac82007 	lsl	x7, x0, x8
    d078:	9b098940 	msub	x0, x10, x9, x2
    d07c:	aa0a03e1 	mov	x1, x10
    d080:	9b0a7ca2 	mul	x2, x5, x10
    d084:	93c38000 	extr	x0, x0, x3, #32
    d088:	eb00005f 	cmp	x2, x0
    d08c:	540000a9 	b.ls	d0a0 <__divti3+0x2e0>  // b.plast
    d090:	ab0000c0 	adds	x0, x6, x0
    d094:	d1000541 	sub	x1, x10, #0x1
    d098:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d09c:	54000468 	b.hi	d128 <__divti3+0x368>  // b.pmore
    d0a0:	cb020000 	sub	x0, x0, x2
    d0a4:	9ac9080a 	udiv	x10, x0, x9
    d0a8:	9b098140 	msub	x0, x10, x9, x0
    d0ac:	aa0a03e2 	mov	x2, x10
    d0b0:	9b0a7ca8 	mul	x8, x5, x10
    d0b4:	b3607c03 	bfi	x3, x0, #32, #32
    d0b8:	eb03011f 	cmp	x8, x3
    d0bc:	540000a9 	b.ls	d0d0 <__divti3+0x310>  // b.plast
    d0c0:	ab0300c3 	adds	x3, x6, x3
    d0c4:	d1000542 	sub	x2, x10, #0x1
    d0c8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d0cc:	54000288 	b.hi	d11c <__divti3+0x35c>  // b.pmore
    d0d0:	cb080063 	sub	x3, x3, x8
    d0d4:	aa018041 	orr	x1, x2, x1, lsl #32
    d0d8:	17ffffc2 	b	cfe0 <__divti3+0x220>
    d0dc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d0e0:	d2800001 	mov	x1, #0x0                   	// #0
    d0e4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d0e8:	17ffff68 	b	ce88 <__divti3+0xc8>
    d0ec:	aa0103e0 	mov	x0, x1
    d0f0:	d2800001 	mov	x1, #0x0                   	// #0
    d0f4:	17ffff65 	b	ce88 <__divti3+0xc8>
    d0f8:	d1000860 	sub	x0, x3, #0x2
    d0fc:	8b0600a5 	add	x5, x5, x6
    d100:	17ffff52 	b	ce48 <__divti3+0x88>
    d104:	d1000961 	sub	x1, x11, #0x2
    d108:	8b0800a5 	add	x5, x5, x8
    d10c:	17ffff85 	b	cf20 <__divti3+0x160>
    d110:	d1000965 	sub	x5, x11, #0x2
    d114:	8b080063 	add	x3, x3, x8
    d118:	17ffff8e 	b	cf50 <__divti3+0x190>
    d11c:	d1000942 	sub	x2, x10, #0x2
    d120:	8b060063 	add	x3, x3, x6
    d124:	17ffffeb 	b	d0d0 <__divti3+0x310>
    d128:	d1000941 	sub	x1, x10, #0x2
    d12c:	8b060000 	add	x0, x0, x6
    d130:	17ffffdc 	b	d0a0 <__divti3+0x2e0>
    d134:	d1000900 	sub	x0, x8, #0x2
    d138:	8b060063 	add	x3, x3, x6
    d13c:	17ffffb4 	b	d00c <__divti3+0x24c>

000000000000d140 <__modti3>:
    d140:	d503245f 	bti	c
    d144:	d2800004 	mov	x4, #0x0                   	// #0
    d148:	b6f80081 	tbz	x1, #63, d158 <__modti3+0x18>
    d14c:	eb0003e0 	negs	x0, x0
    d150:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d154:	da0103e1 	ngc	x1, x1
    d158:	f100007f 	cmp	x3, #0x0
    d15c:	5400128b 	b.lt	d3ac <__modti3+0x26c>  // b.tstop
    d160:	aa0003e7 	mov	x7, x0
    d164:	aa0103e6 	mov	x6, x1
    d168:	540004e1 	b.ne	d204 <__modti3+0xc4>  // b.any
    d16c:	eb02003f 	cmp	x1, x2
    d170:	54000dc2 	b.cs	d328 <__modti3+0x1e8>  // b.hs, b.nlast
    d174:	dac01043 	clz	x3, x2
    d178:	aa0303e5 	mov	x5, x3
    d17c:	b40000e3 	cbz	x3, d198 <__modti3+0x58>
    d180:	4b0303e6 	neg	w6, w3
    d184:	9ac32021 	lsl	x1, x1, x3
    d188:	9ac32042 	lsl	x2, x2, x3
    d18c:	9ac62406 	lsr	x6, x0, x6
    d190:	aa0100c6 	orr	x6, x6, x1
    d194:	9ac32007 	lsl	x7, x0, x3
    d198:	d360fc40 	lsr	x0, x2, #32
    d19c:	92407c43 	and	x3, x2, #0xffffffff
    d1a0:	9ac008c1 	udiv	x1, x6, x0
    d1a4:	9b009826 	msub	x6, x1, x0, x6
    d1a8:	9b017c61 	mul	x1, x3, x1
    d1ac:	93c780c6 	extr	x6, x6, x7, #32
    d1b0:	eb06003f 	cmp	x1, x6
    d1b4:	540000a9 	b.ls	d1c8 <__modti3+0x88>  // b.plast
    d1b8:	ab060046 	adds	x6, x2, x6
    d1bc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d1c0:	8b0200c8 	add	x8, x6, x2
    d1c4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d1c8:	cb0100c6 	sub	x6, x6, x1
    d1cc:	9ac008c8 	udiv	x8, x6, x0
    d1d0:	9b009901 	msub	x1, x8, x0, x6
    d1d4:	aa0703e0 	mov	x0, x7
    d1d8:	9b087c63 	mul	x3, x3, x8
    d1dc:	b3607c20 	bfi	x0, x1, #32, #32
    d1e0:	eb00007f 	cmp	x3, x0
    d1e4:	54001088 	b.hi	d3f4 <__modti3+0x2b4>  // b.pmore
    d1e8:	cb030000 	sub	x0, x0, x3
    d1ec:	9ac52400 	lsr	x0, x0, x5
    d1f0:	d2800001 	mov	x1, #0x0                   	// #0
    d1f4:	b4000064 	cbz	x4, d200 <__modti3+0xc0>
    d1f8:	eb0003e0 	negs	x0, x0
    d1fc:	da0103e1 	ngc	x1, x1
    d200:	d65f03c0 	ret
    d204:	dac01066 	clz	x6, x3
    d208:	eb03003f 	cmp	x1, x3
    d20c:	54ffff43 	b.cc	d1f4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d210:	93407cc5 	sxtw	x5, w6
    d214:	d2800808 	mov	x8, #0x40                  	// #64
    d218:	cb050108 	sub	x8, x8, x5
    d21c:	9ac62063 	lsl	x3, x3, x6
    d220:	9ac62025 	lsl	x5, x1, x6
    d224:	9ac82447 	lsr	x7, x2, x8
    d228:	aa0300e7 	orr	x7, x7, x3
    d22c:	9ac82423 	lsr	x3, x1, x8
    d230:	92407cec 	and	x12, x7, #0xffffffff
    d234:	d360fcea 	lsr	x10, x7, #32
    d238:	9ac82401 	lsr	x1, x0, x8
    d23c:	aa050021 	orr	x1, x1, x5
    d240:	9ac62042 	lsl	x2, x2, x6
    d244:	9ac62000 	lsl	x0, x0, x6
    d248:	9aca086b 	udiv	x11, x3, x10
    d24c:	9b0a8d63 	msub	x3, x11, x10, x3
    d250:	aa0b03e5 	mov	x5, x11
    d254:	9b0b7d89 	mul	x9, x12, x11
    d258:	93c18063 	extr	x3, x3, x1, #32
    d25c:	eb03013f 	cmp	x9, x3
    d260:	540000a9 	b.ls	d274 <__modti3+0x134>  // b.plast
    d264:	ab0300e3 	adds	x3, x7, x3
    d268:	d1000565 	sub	x5, x11, #0x1
    d26c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d270:	54001168 	b.hi	d49c <__modti3+0x35c>  // b.pmore
    d274:	cb090063 	sub	x3, x3, x9
    d278:	9aca086b 	udiv	x11, x3, x10
    d27c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d280:	aa0b03e9 	mov	x9, x11
    d284:	9b0b7d8c 	mul	x12, x12, x11
    d288:	b3607d41 	bfi	x1, x10, #32, #32
    d28c:	eb01019f 	cmp	x12, x1
    d290:	540000a9 	b.ls	d2a4 <__modti3+0x164>  // b.plast
    d294:	ab0100e1 	adds	x1, x7, x1
    d298:	d1000569 	sub	x9, x11, #0x1
    d29c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d2a0:	54000f88 	b.hi	d490 <__modti3+0x350>  // b.pmore
    d2a4:	aa058123 	orr	x3, x9, x5, lsl #32
    d2a8:	92407c4b 	and	x11, x2, #0xffffffff
    d2ac:	2a0903e9 	mov	w9, w9
    d2b0:	d360fc4a 	lsr	x10, x2, #32
    d2b4:	d360fc63 	lsr	x3, x3, #32
    d2b8:	cb0c0021 	sub	x1, x1, x12
    d2bc:	aa0a03ec 	mov	x12, x10
    d2c0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d2c4:	9b0b7d25 	mul	x5, x9, x11
    d2c8:	9b0b7c6b 	mul	x11, x3, x11
    d2cc:	9b0a2d29 	madd	x9, x9, x10, x11
    d2d0:	92407caa 	and	x10, x5, #0xffffffff
    d2d4:	9b0c7c63 	mul	x3, x3, x12
    d2d8:	8b458125 	add	x5, x9, x5, lsr #32
    d2dc:	8b0d0069 	add	x9, x3, x13
    d2e0:	eb05017f 	cmp	x11, x5
    d2e4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d2e8:	8b058149 	add	x9, x10, x5, lsl #32
    d2ec:	8b458063 	add	x3, x3, x5, lsr #32
    d2f0:	eb03003f 	cmp	x1, x3
    d2f4:	54000063 	b.cc	d300 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d2f8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d2fc:	54000082 	b.cs	d30c <__modti3+0x1cc>  // b.hs, b.nlast
    d300:	eb020129 	subs	x9, x9, x2
    d304:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d308:	cb070063 	sub	x3, x3, x7
    d30c:	eb090000 	subs	x0, x0, x9
    d310:	da030021 	sbc	x1, x1, x3
    d314:	9ac62400 	lsr	x0, x0, x6
    d318:	9ac82028 	lsl	x8, x1, x8
    d31c:	aa000100 	orr	x0, x8, x0
    d320:	9ac62421 	lsr	x1, x1, x6
    d324:	17ffffb4 	b	d1f4 <__modti3+0xb4>
    d328:	b5000062 	cbnz	x2, d334 <__modti3+0x1f4>
    d32c:	d2800023 	mov	x3, #0x1                   	// #1
    d330:	9ac20862 	udiv	x2, x3, x2
    d334:	dac01048 	clz	x8, x2
    d338:	aa0803e5 	mov	x5, x8
    d33c:	b5000668 	cbnz	x8, d408 <__modti3+0x2c8>
    d340:	cb020020 	sub	x0, x1, x2
    d344:	d360fc49 	lsr	x9, x2, #32
    d348:	92407c4a 	and	x10, x2, #0xffffffff
    d34c:	9ac90801 	udiv	x1, x0, x9
    d350:	9b098020 	msub	x0, x1, x9, x0
    d354:	9b0a7c21 	mul	x1, x1, x10
    d358:	93c78000 	extr	x0, x0, x7, #32
    d35c:	eb00003f 	cmp	x1, x0
    d360:	540000a9 	b.ls	d374 <__modti3+0x234>  // b.plast
    d364:	ab000040 	adds	x0, x2, x0
    d368:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d36c:	8b020003 	add	x3, x0, x2
    d370:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d374:	cb010001 	sub	x1, x0, x1
    d378:	9ac90820 	udiv	x0, x1, x9
    d37c:	9b098403 	msub	x3, x0, x9, x1
    d380:	aa0703e1 	mov	x1, x7
    d384:	9b0a7c00 	mul	x0, x0, x10
    d388:	b3607c61 	bfi	x1, x3, #32, #32
    d38c:	eb01001f 	cmp	x0, x1
    d390:	540000a9 	b.ls	d3a4 <__modti3+0x264>  // b.plast
    d394:	ab010041 	adds	x1, x2, x1
    d398:	8b020022 	add	x2, x1, x2
    d39c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d3a0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d3a4:	cb000020 	sub	x0, x1, x0
    d3a8:	17ffff91 	b	d1ec <__modti3+0xac>
    d3ac:	eb0203e5 	negs	x5, x2
    d3b0:	aa0003e7 	mov	x7, x0
    d3b4:	da0303e8 	ngc	x8, x3
    d3b8:	aa0503e2 	mov	x2, x5
    d3bc:	aa0803e3 	mov	x3, x8
    d3c0:	aa0103e6 	mov	x6, x1
    d3c4:	b4ffed48 	cbz	x8, d16c <__modti3+0x2c>
    d3c8:	eb01011f 	cmp	x8, x1
    d3cc:	54fff148 	b.hi	d1f4 <__modti3+0xb4>  // b.pmore
    d3d0:	dac01109 	clz	x9, x8
    d3d4:	2a0903e6 	mov	w6, w9
    d3d8:	b5fff1c9 	cbnz	x9, d210 <__modti3+0xd0>
    d3dc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d3e0:	54000068 	b.hi	d3ec <__modti3+0x2ac>  // b.pmore
    d3e4:	eb050007 	subs	x7, x0, x5
    d3e8:	da080021 	sbc	x1, x1, x8
    d3ec:	aa0703e0 	mov	x0, x7
    d3f0:	17ffff81 	b	d1f4 <__modti3+0xb4>
    d3f4:	ab000040 	adds	x0, x2, x0
    d3f8:	8b020002 	add	x2, x0, x2
    d3fc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d400:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d404:	17ffff79 	b	d1e8 <__modti3+0xa8>
    d408:	9ac82042 	lsl	x2, x2, x8
    d40c:	d2800803 	mov	x3, #0x40                  	// #64
    d410:	cb080063 	sub	x3, x3, x8
    d414:	d360fc49 	lsr	x9, x2, #32
    d418:	9ac82027 	lsl	x7, x1, x8
    d41c:	92407c4a 	and	x10, x2, #0xffffffff
    d420:	9ac32426 	lsr	x6, x1, x3
    d424:	9ac32403 	lsr	x3, x0, x3
    d428:	aa070063 	orr	x3, x3, x7
    d42c:	9ac908c1 	udiv	x1, x6, x9
    d430:	9ac82007 	lsl	x7, x0, x8
    d434:	9b099820 	msub	x0, x1, x9, x6
    d438:	9b017d41 	mul	x1, x10, x1
    d43c:	93c38000 	extr	x0, x0, x3, #32
    d440:	eb00003f 	cmp	x1, x0
    d444:	540000a9 	b.ls	d458 <__modti3+0x318>  // b.plast
    d448:	ab000040 	adds	x0, x2, x0
    d44c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d450:	8b020006 	add	x6, x0, x2
    d454:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d458:	cb010000 	sub	x0, x0, x1
    d45c:	9ac90801 	udiv	x1, x0, x9
    d460:	9b098026 	msub	x6, x1, x9, x0
    d464:	aa0303e0 	mov	x0, x3
    d468:	9b017d41 	mul	x1, x10, x1
    d46c:	b3607cc0 	bfi	x0, x6, #32, #32
    d470:	eb00003f 	cmp	x1, x0
    d474:	540000a9 	b.ls	d488 <__modti3+0x348>  // b.plast
    d478:	ab000040 	adds	x0, x2, x0
    d47c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d480:	8b020003 	add	x3, x0, x2
    d484:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d488:	cb010000 	sub	x0, x0, x1
    d48c:	17ffffb0 	b	d34c <__modti3+0x20c>
    d490:	d1000969 	sub	x9, x11, #0x2
    d494:	8b070021 	add	x1, x1, x7
    d498:	17ffff83 	b	d2a4 <__modti3+0x164>
    d49c:	d1000965 	sub	x5, x11, #0x2
    d4a0:	8b070063 	add	x3, x3, x7
    d4a4:	17ffff74 	b	d274 <__modti3+0x134>
    d4a8:	d503201f 	nop
    d4ac:	d503201f 	nop

000000000000d4b0 <atexit>:
    d4b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d4b4:	f0000082 	adrp	x2, 20000 <__data_start>
    d4b8:	d2800001 	mov	x1, #0x0                   	// #0
    d4bc:	910003fd 	mov	x29, sp
    d4c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d4c4:	f9400442 	ldr	x2, [x2, #8]
    d4c8:	17ffd4d2 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d4cc <_fini>:
    d4cc:	d503201f 	nop
    d4d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d4d4:	910003fd 	mov	x29, sp
    d4d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d4dc:	d65f03c0 	ret
