
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__divti3+0x40>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9126a0a5 	add	x5, x5, #0x9a8
    2a20:	f0000044 	adrp	x4, d000 <__divti3+0x40>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9126c084 	add	x4, x4, #0x9b0
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004f0 	bl	3e10 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	910102a1 	add	x1, x21, #0x40
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe818>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003c20 	str	x0, [x1, #120]
    2aac:	940006f9 	bl	4690 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2ab4:	91330000 	add	x0, x0, #0xcc0
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x1be0>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	912ac042 	add	x2, x2, #0xab0
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910102b5 	add	x21, x21, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430aa0 	ldr	w0, [x21, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2bcc:	9133c000 	add	x0, x0, #0xcf0
    2bd0:	94000490 	bl	3e10 <fwp_trap>
    2bd4:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2bd8:	91334000 	add	x0, x0, #0xcd0
    2bdc:	9400048d 	bl	3e10 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff3e 	bl	28e0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee3 	bl	27a0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2c20:	91352000 	add	x0, x0, #0xd48
    2c24:	9400047b 	bl	3e10 <fwp_trap>
    2c28:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2c2c:	91346000 	add	x0, x0, #0xd18
    2c30:	94000478 	bl	3e10 <fwp_trap>
    2c34:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2c38:	9135c000 	add	x0, x0, #0xd70
    2c3c:	94000475 	bl	3e10 <fwp_trap>
    2c40:	97fffeec 	bl	27f0 <__stack_chk_fail@plt>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x920>
    2e34:	910dc021 	add	x1, x1, #0x370
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__divti3+0x40>
    2fd0:	911ba000 	add	x0, x0, #0x6e8
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x920>
    3098:	910d4021 	add	x1, x1, #0x350
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3370:	911ba000 	add	x0, x0, #0x6e8
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__divti3+0x40>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	911c0021 	add	x1, x1, #0x700
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__divti3+0x40>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	911c2021 	add	x1, x1, #0x708
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__divti3+0x40>
    34e0:	911c4021 	add	x1, x1, #0x710
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	d0000044 	adrp	x4, d000 <__divti3+0x40>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	911c6084 	add	x4, x4, #0x718
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc7f 	bl	2760 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcd8 	bl	28d0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc3 	bl	2890 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc0c 	bl	2640 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc44 	bl	2740 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc35 	bl	2740 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbed 	bl	2640 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbf9 	bl	2680 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc89 	bl	28d0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	d0000044 	adrp	x4, d000 <__divti3+0x40>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	911cc084 	add	x4, x4, #0x730
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0a 	bl	2760 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbf9 	bl	2740 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc59 	bl	28d0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	d0000044 	adrp	x4, d000 <__divti3+0x40>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	911c8084 	add	x4, x4, #0x720
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe2 	bl	2760 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbcc 	bl	2740 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba0 	bl	2740 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbbc 	bl	27f0 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    390c:	91154042 	add	x2, x2, #0x550
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	d0000041 	adrp	x1, d000 <__divti3+0x40>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	911ce021 	add	x1, x1, #0x738
    3968:	911d0000 	add	x0, x0, #0x740
    396c:	97fffb85 	bl	2780 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbaf 	bl	2890 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb5f 	bl	2770 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	d0000042 	adrp	x2, d000 <__divti3+0x40>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	911d8042 	add	x2, x2, #0x760
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb82 	b	2860 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb62 	bl	27f0 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3a78:	91114061 	add	x1, x3, #0x450
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3a88:	91154262 	add	x2, x19, #0x550
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x920>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3abc:	91124021 	add	x1, x1, #0x490
    3ac0:	3dc0e043 	ldr	q3, [x2, #896]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3aec:	91114063 	add	x3, x3, #0x450
    3af0:	9113c084 	add	x4, x4, #0x4f0
    3af4:	91154266 	add	x6, x19, #0x550
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb45 	bl	2880 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	91154275 	add	x21, x19, #0x550
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb2f 	bl	2880 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3bd8:	911fa000 	add	x0, x0, #0x7e8
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb68 	bl	2980 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	91154273 	add	x19, x19, #0x550
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	91010122 	add	x2, x9, #0x40
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	91010120 	add	x0, x9, #0x40
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	91010129 	add	x9, x9, #0x40
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9401400 	ldr	x0, [x0, #40]
    3d04:	b7f80760 	tbnz	x0, #63, 3df0 <fwp_tape_buffers_release+0x100>
    3d08:	f9401a61 	ldr	x1, [x19, #48]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3d3c:	911fe000 	add	x0, x0, #0x7f8
    3d40:	97fffb10 	bl	2980 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	911fe000 	add	x0, x0, #0x7f8
    3d78:	97fffb02 	bl	2980 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	910102d6 	add	x22, x22, #0x40
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400a61 	ldp	q1, q2, [x19]
    3db8:	f9003ad4 	str	x20, [x22, #112]
    3dbc:	4f000400 	movi	v0.4s, #0x0
    3dc0:	ad000aa1 	stp	q1, q2, [x21]
    3dc4:	3dc00a61 	ldr	q1, [x19, #32]
    3dc8:	3d800aa1 	str	q1, [x21, #32]
    3dcc:	f9401a60 	ldr	x0, [x19, #48]
    3dd0:	f9001aa0 	str	x0, [x21, #48]
    3dd4:	f9001a7f 	str	xzr, [x19, #48]
    3dd8:	ad000260 	stp	q0, q0, [x19]
    3ddc:	3d800a60 	str	q0, [x19, #32]
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3dec:	d65f03c0 	ret
    3df0:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3df4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df8:	911fe000 	add	x0, x0, #0x7f8
    3dfc:	97fffae1 	bl	2980 <getenv@plt>
    3e00:	b5fffa40 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3e04:	17ffffd6 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3e08:	d503201f 	nop
    3e0c:	d503201f 	nop

0000000000003e10 <fwp_trap>:
    3e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e14:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e18:	d53bd041 	mrs	x1, tpidr_el0
    3e1c:	910003fd 	mov	x29, sp
    3e20:	f9402442 	ldr	x2, [x2, #72]
    3e24:	91400021 	add	x1, x1, #0x0, lsl #12
    3e28:	91004021 	add	x1, x1, #0x10
    3e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e30:	aa0003f3 	mov	x19, x0
    3e34:	f9400034 	ldr	x20, [x1]
    3e38:	b4000062 	cbz	x2, 3e44 <fwp_trap+0x34>
    3e3c:	aa0203e0 	mov	x0, x2
    3e40:	97fffab8 	bl	2920 <fflush@plt>
    3e44:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3e48:	f947ec00 	ldr	x0, [x0, #4056]
    3e4c:	f9400000 	ldr	x0, [x0]
    3e50:	97fffab4 	bl	2920 <fflush@plt>
    3e54:	aa1303e3 	mov	x3, x19
    3e58:	d0000042 	adrp	x2, d000 <__divti3+0x40>
    3e5c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    3e60:	f947ea73 	ldr	x19, [x19, #4048]
    3e64:	91204042 	add	x2, x2, #0x810
    3e68:	52800041 	mov	w1, #0x2                   	// #2
    3e6c:	f9400260 	ldr	x0, [x19]
    3e70:	97fffa7c 	bl	2860 <__fprintf_chk@plt>
    3e74:	b40000b4 	cbz	x20, 3e88 <fwp_trap+0x78>
    3e78:	f9400260 	ldr	x0, [x19]
    3e7c:	97fffaa9 	bl	2920 <fflush@plt>
    3e80:	52800ca0 	mov	w0, #0x65                  	// #101
    3e84:	97fffab7 	bl	2960 <_Exit@plt>
    3e88:	52800ca0 	mov	w0, #0x65                  	// #101
    3e8c:	97fffa05 	bl	26a0 <exit@plt>

0000000000003e90 <fwp_rc_forget_slot.part.0>:
    3e90:	ca404401 	eor	x1, x0, x0, lsr #17
    3e94:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e98:	ca412421 	eor	x1, x1, x1, lsr #9
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	92401c21 	and	x1, x1, #0xff
    3ea4:	f9000bf3 	str	x19, [sp, #16]
    3ea8:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3eac:	91154262 	add	x2, x19, #0x550
    3eb0:	910a2423 	add	x3, x1, #0x289
    3eb4:	8b010c41 	add	x1, x2, x1, lsl #3
    3eb8:	8b030c43 	add	x3, x2, x3, lsl #3
    3ebc:	f94a2421 	ldr	x1, [x1, #5192]
    3ec0:	b50000a1 	cbnz	x1, 3ed4 <fwp_rc_forget_slot.part.0+0x44>
    3ec4:	14000012 	b	3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ec8:	91004023 	add	x3, x1, #0x10
    3ecc:	f9400821 	ldr	x1, [x1, #16]
    3ed0:	b40001e1 	cbz	x1, 3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ed4:	f9400022 	ldr	x2, [x1]
    3ed8:	eb02001f 	cmp	x0, x2
    3edc:	54ffff61 	b.ne	3ec8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ee0:	f9400060 	ldr	x0, [x3]
    3ee4:	91154273 	add	x19, x19, #0x550
    3ee8:	f9400801 	ldr	x1, [x0, #16]
    3eec:	f9000061 	str	x1, [x3]
    3ef0:	97fffa70 	bl	28b0 <free@plt>
    3ef4:	f94e2660 	ldr	x0, [x19, #7240]
    3ef8:	d1000400 	sub	x0, x0, #0x1
    3efc:	f90e2660 	str	x0, [x19, #7240]
    3f00:	f9400bf3 	ldr	x19, [sp, #16]
    3f04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f08:	d65f03c0 	ret
    3f0c:	d0000040 	adrp	x0, d000 <__divti3+0x40>
    3f10:	91208000 	add	x0, x0, #0x820
    3f14:	97ffffbf 	bl	3e10 <fwp_trap>
    3f18:	d503201f 	nop
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_rc_prepare_chunk>:
    3f20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f24:	910003fd 	mov	x29, sp
    3f28:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f2c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    3f30:	911542c2 	add	x2, x22, #0x550
    3f34:	b9401c03 	ldr	w3, [x0, #28]
    3f38:	aa0103f5 	mov	x21, x1
    3f3c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f40:	aa0003f4 	mov	x20, x0
    3f44:	f94e2440 	ldr	x0, [x2, #7240]
    3f48:	b4000440 	cbz	x0, 3fd0 <fwp_rc_prepare_chunk+0xb0>
    3f4c:	d2800013 	mov	x19, #0x0                   	// #0
    3f50:	35000203 	cbnz	w3, 3f90 <fwp_rc_prepare_chunk+0x70>
    3f54:	b4000361 	cbz	x1, 3fc0 <fwp_rc_prepare_chunk+0xa0>
    3f58:	f9401280 	ldr	x0, [x20, #32]
    3f5c:	97fffa55 	bl	28b0 <free@plt>
    3f60:	aa1503e0 	mov	x0, x21
    3f64:	d2800021 	mov	x1, #0x1                   	// #1
    3f68:	97fffa1a 	bl	27d0 <calloc@plt>
    3f6c:	f9001280 	str	x0, [x20, #32]
    3f70:	b5000460 	cbnz	x0, 3ffc <fwp_rc_prepare_chunk+0xdc>
    3f74:	97fffc0f 	bl	2fb0 <fwp_heap_oom>
    3f78:	97ffffc6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    3f7c:	91000673 	add	x19, x19, #0x1
    3f80:	b9401e83 	ldr	w3, [x20, #28]
    3f84:	eb13007f 	cmp	x3, x19
    3f88:	54000169 	b.ls	3fb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f8c:	d503201f 	nop
    3f90:	f9401283 	ldr	x3, [x20, #32]
    3f94:	8b130060 	add	x0, x3, x19
    3f98:	38736863 	ldrb	w3, [x3, x19]
    3f9c:	7103fc7f 	cmp	w3, #0xff
    3fa0:	54fffec0 	b.eq	3f78 <fwp_rc_prepare_chunk+0x58>  // b.none
    3fa4:	b9401e83 	ldr	w3, [x20, #28]
    3fa8:	91000673 	add	x19, x19, #0x1
    3fac:	eb13007f 	cmp	x3, x19
    3fb0:	54ffff08 	b.hi	3f90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fb4:	eb0302bf 	cmp	x21, x3
    3fb8:	54000121 	b.ne	3fdc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fbc:	b5000335 	cbnz	x21, 4020 <fwp_rc_prepare_chunk+0x100>
    3fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fcc:	d65f03c0 	ret
    3fd0:	2a0303e3 	mov	w3, w3
    3fd4:	eb0302bf 	cmp	x21, x3
    3fd8:	54ffff20 	b.eq	3fbc <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fdc:	911542c2 	add	x2, x22, #0x550
    3fe0:	f9401280 	ldr	x0, [x20, #32]
    3fe4:	f94e2841 	ldr	x1, [x2, #7248]
    3fe8:	cb030021 	sub	x1, x1, x3
    3fec:	f90e2841 	str	x1, [x2, #7248]
    3ff0:	97fffa30 	bl	28b0 <free@plt>
    3ff4:	b5fffb75 	cbnz	x21, 3f60 <fwp_rc_prepare_chunk+0x40>
    3ff8:	f900129f 	str	xzr, [x20, #32]
    3ffc:	911542d6 	add	x22, x22, #0x550
    4000:	f94e2ac0 	ldr	x0, [x22, #7248]
    4004:	b9001e95 	str	w21, [x20, #28]
    4008:	a94153f3 	ldp	x19, x20, [sp, #16]
    400c:	8b150000 	add	x0, x0, x21
    4010:	f90e2ac0 	str	x0, [x22, #7248]
    4014:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4018:	a8c37bfd 	ldp	x29, x30, [sp], #48
    401c:	d65f03c0 	ret
    4020:	f9401280 	ldr	x0, [x20, #32]
    4024:	aa1503e2 	mov	x2, x21
    4028:	a94153f3 	ldp	x19, x20, [sp, #16]
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4034:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4038:	17fff9e2 	b	27c0 <memset@plt>
    403c:	d503201f 	nop

0000000000004040 <fwp_heap_refill>:
    4040:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4044:	910003fd 	mov	x29, sp
    4048:	a9025bf5 	stp	x21, x22, [sp, #32]
    404c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4050:	911542b5 	add	x21, x21, #0x550
    4054:	aa0003f6 	mov	x22, x0
    4058:	d2800020 	mov	x0, #0x1                   	// #1
    405c:	a90153f3 	stp	x19, x20, [sp, #16]
    4060:	a90363f7 	stp	x23, x24, [sp, #48]
    4064:	2a0103f7 	mov	w23, w1
    4068:	2a0203f8 	mov	w24, w2
    406c:	97fffc11 	bl	30b0 <fwp_heap_chunks>
    4070:	aa0003f3 	mov	x19, x0
    4074:	f949fea2 	ldr	x2, [x21, #5112]
    4078:	8b000800 	add	x0, x0, x0, lsl #2
    407c:	2a1703e1 	mov	w1, w23
    4080:	52800025 	mov	w5, #0x1                   	// #1
    4084:	d37df000 	lsl	x0, x0, #3
    4088:	910f0021 	add	x1, x1, #0x3c0
    408c:	8b000054 	add	x20, x2, x0
    4090:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4094:	52a00024 	mov	w4, #0x10000               	// #65536
    4098:	38206845 	strb	w5, [x2, x0]
    409c:	aa1403e0 	mov	x0, x20
    40a0:	39000698 	strb	w24, [x20, #1]
    40a4:	39000a97 	strb	w23, [x20, #2]
    40a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    40ac:	b9000681 	str	w1, [x20, #4]
    40b0:	2a0103e5 	mov	w5, w1
    40b4:	8b0300a2 	add	x2, x5, x3
    40b8:	1ac10881 	udiv	w1, w4, w1
    40bc:	9ac50842 	udiv	x2, x2, x5
    40c0:	b9000a81 	str	w1, [x20, #8]
    40c4:	92404021 	and	x1, x1, #0x1ffff
    40c8:	b9001a82 	str	w2, [x20, #24]
    40cc:	97ffff95 	bl	3f20 <fwp_rc_prepare_chunk>
    40d0:	f949daa0 	ldr	x0, [x21, #5040]
    40d4:	29408a81 	ldp	w1, w2, [x20, #4]
    40d8:	8b134000 	add	x0, x0, x19, lsl #16
    40dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e0:	8b214003 	add	x3, x0, w1, uxtw
    40e4:	9ba20021 	umaddl	x1, w1, w2, x0
    40e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40ec:	a90086c3 	stp	x3, x1, [x22, #8]
    40f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40f8:	d65f03c0 	ret
    40fc:	d503201f 	nop

0000000000004100 <fwp_mem_free>:
    4100:	b40003c0 	cbz	x0, 4178 <fwp_mem_free+0x78>
    4104:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4108:	910003fd 	mov	x29, sp
    410c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4110:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4114:	911542a1 	add	x1, x21, #0x550
    4118:	a90153f3 	stp	x19, x20, [sp, #16]
    411c:	aa0003f3 	mov	x19, x0
    4120:	f949d823 	ldr	x3, [x1, #5040]
    4124:	f949ec22 	ldr	x2, [x1, #5080]
    4128:	cb030000 	sub	x0, x0, x3
    412c:	eb02401f 	cmp	x0, x2, lsl #16
    4130:	540001c2 	b.cs	4168 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4134:	d350fc16 	lsr	x22, x0, #16
    4138:	a90363f7 	stp	x23, x24, [sp, #48]
    413c:	f949fc22 	ldr	x2, [x1, #5112]
    4140:	8b160ad4 	add	x20, x22, x22, lsl #2
    4144:	d37df294 	lsl	x20, x20, #3
    4148:	ab140057 	adds	x23, x2, x20
    414c:	540000c0 	b.eq	4164 <fwp_mem_free+0x64>  // b.none
    4150:	38746842 	ldrb	w2, [x2, x20]
    4154:	7100045f 	cmp	w2, #0x1
    4158:	54000120 	b.eq	417c <fwp_mem_free+0x7c>  // b.none
    415c:	7100085f 	cmp	w2, #0x2
    4160:	540005e0 	b.eq	421c <fwp_mem_free+0x11c>  // b.none
    4164:	a94363f7 	ldp	x23, x24, [sp, #48]
    4168:	a94153f3 	ldp	x19, x20, [sp, #16]
    416c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4170:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4174:	d65f03c0 	ret
    4178:	d65f03c0 	ret
    417c:	f94012f8 	ldr	x24, [x23, #32]
    4180:	b94006e1 	ldr	w1, [x23, #4]
    4184:	f90023f9 	str	x25, [sp, #64]
    4188:	2a0103e2 	mov	w2, w1
    418c:	394006f9 	ldrb	w25, [x23, #1]
    4190:	39400af4 	ldrb	w20, [x23, #2]
    4194:	b4000158 	cbz	x24, 41bc <fwp_mem_free+0xbc>
    4198:	92403e76 	and	x22, x19, #0xffff
    419c:	9ac20ad6 	udiv	x22, x22, x2
    41a0:	38766b01 	ldrb	w1, [x24, x22]
    41a4:	8b160300 	add	x0, x24, x22
    41a8:	7103fc3f 	cmp	w1, #0xff
    41ac:	54000980 	b.eq	42dc <fwp_mem_free+0x1dc>  // b.none
    41b0:	38366b1f 	strb	wzr, [x24, x22]
    41b4:	b94006e1 	ldr	w1, [x23, #4]
    41b8:	2a0103e2 	mov	w2, w1
    41bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41c4:	cb390000 	sub	x0, x0, w25, uxtb
    41c8:	8b340074 	add	x20, x3, w20, uxtb
    41cc:	911542b5 	add	x21, x21, #0x550
    41d0:	1e630021 	ucvtf	d1, w1
    41d4:	d37ae400 	lsl	x0, x0, #6
    41d8:	8b140c14 	add	x20, x0, x20, lsl #3
    41dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e0:	f8746aa0 	ldr	x0, [x21, x20]
    41e4:	f94023f9 	ldr	x25, [sp, #64]
    41e8:	aa2003e0 	mvn	x0, x0
    41ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    41f0:	f9000260 	str	x0, [x19]
    41f4:	f8346ab3 	str	x19, [x21, x20]
    41f8:	f94a12a0 	ldr	x0, [x21, #5152]
    41fc:	1e612800 	fadd	d0, d0, d1
    4200:	a94153f3 	ldp	x19, x20, [sp, #16]
    4204:	cb020000 	sub	x0, x0, x2
    4208:	f90a12a0 	str	x0, [x21, #5152]
    420c:	fd0a22a0 	str	d0, [x21, #5184]
    4210:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4214:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4218:	d65f03c0 	ret
    421c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4220:	8b000063 	add	x3, x3, x0
    4224:	eb03027f 	cmp	x19, x3
    4228:	54fff9e1 	b.ne	4164 <fwp_mem_free+0x64>  // b.any
    422c:	fd400ae1 	ldr	d1, [x23, #16]
    4230:	fd4a2020 	ldr	d0, [x1, #5184]
    4234:	f9400ae0 	ldr	x0, [x23, #16]
    4238:	7e61d821 	ucvtf	d1, d1
    423c:	f94a1022 	ldr	x2, [x1, #5152]
    4240:	f94012f3 	ldr	x19, [x23, #32]
    4244:	1e612800 	fadd	d0, d0, d1
    4248:	cb000042 	sub	x2, x2, x0
    424c:	f90a1022 	str	x2, [x1, #5152]
    4250:	fd0a2020 	str	d0, [x1, #5184]
    4254:	b40000b3 	cbz	x19, 4268 <fwp_mem_free+0x168>
    4258:	39400260 	ldrb	w0, [x19]
    425c:	7103fc1f 	cmp	w0, #0xff
    4260:	54000380 	b.eq	42d0 <fwp_mem_free+0x1d0>  // b.none
    4264:	3900027f 	strb	wzr, [x19]
    4268:	b9400ee2 	ldr	w2, [x23, #12]
    426c:	b4000142 	cbz	x2, 4294 <fwp_mem_free+0x194>
    4270:	911542a1 	add	x1, x21, #0x550
    4274:	8b160040 	add	x0, x2, x22
    4278:	8b000800 	add	x0, x0, x0, lsl #2
    427c:	f949fc21 	ldr	x1, [x1, #5112]
    4280:	8b140034 	add	x20, x1, x20
    4284:	8b000c20 	add	x0, x1, x0, lsl #3
    4288:	3802869f 	strb	wzr, [x20], #40
    428c:	eb00029f 	cmp	x20, x0
    4290:	54ffffc1 	b.ne	4288 <fwp_mem_free+0x188>  // b.any
    4294:	911542a0 	add	x0, x21, #0x550
    4298:	f94a1801 	ldr	x1, [x0, #5168]
    429c:	f949f803 	ldr	x3, [x0, #5104]
    42a0:	8b020021 	add	x1, x1, x2
    42a4:	f90a1801 	str	x1, [x0, #5168]
    42a8:	eb16007f 	cmp	x3, x22
    42ac:	54000049 	b.ls	42b4 <fwp_mem_free+0x1b4>  // b.plast
    42b0:	f909f816 	str	x22, [x0, #5104]
    42b4:	911542b5 	add	x21, x21, #0x550
    42b8:	f949f6a0 	ldr	x0, [x21, #5096]
    42bc:	eb16001f 	cmp	x0, x22
    42c0:	54fff529 	b.ls	4164 <fwp_mem_free+0x64>  // b.plast
    42c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42c8:	f909f6b6 	str	x22, [x21, #5096]
    42cc:	17ffffa7 	b	4168 <fwp_mem_free+0x68>
    42d0:	aa1303e0 	mov	x0, x19
    42d4:	97fffeef 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42d8:	17ffffe3 	b	4264 <fwp_mem_free+0x164>
    42dc:	97fffeed 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42e0:	17ffffb4 	b	41b0 <fwp_mem_free+0xb0>

00000000000042e4 <fwp_rc_wide_dup>:
    42e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42e8:	910003fd 	mov	x29, sp
    42ec:	a90153f3 	stp	x19, x20, [sp, #16]
    42f0:	aa0003f3 	mov	x19, x0
    42f4:	ca404400 	eor	x0, x0, x0, lsr #17
    42f8:	f90013f5 	str	x21, [sp, #32]
    42fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4300:	ca402400 	eor	x0, x0, x0, lsr #9
    4304:	911542a2 	add	x2, x21, #0x550
    4308:	92401c00 	and	x0, x0, #0xff
    430c:	910a2403 	add	x3, x0, #0x289
    4310:	8b000c40 	add	x0, x2, x0, lsl #3
    4314:	8b030c54 	add	x20, x2, x3, lsl #3
    4318:	f94a2401 	ldr	x1, [x0, #5192]
    431c:	b50000a1 	cbnz	x1, 4330 <fwp_rc_wide_dup+0x4c>
    4320:	14000033 	b	43ec <fwp_rc_wide_dup+0x108>
    4324:	91004034 	add	x20, x1, #0x10
    4328:	f9400821 	ldr	x1, [x1, #16]
    432c:	b4000241 	cbz	x1, 4374 <fwp_rc_wide_dup+0x90>
    4330:	f9400022 	ldr	x2, [x1]
    4334:	eb02027f 	cmp	x19, x2
    4338:	54ffff61 	b.ne	4324 <fwp_rc_wide_dup+0x40>  // b.any
    433c:	f9400281 	ldr	x1, [x20]
    4340:	39400260 	ldrb	w0, [x19]
    4344:	7103f81f 	cmp	w0, #0xfe
    4348:	54000220 	b.eq	438c <fwp_rc_wide_dup+0xa8>  // b.none
    434c:	b40001a1 	cbz	x1, 4380 <fwp_rc_wide_dup+0x9c>
    4350:	f9400420 	ldr	x0, [x1, #8]
    4354:	b100041f 	cmn	x0, #0x1
    4358:	54000440 	b.eq	43e0 <fwp_rc_wide_dup+0xfc>  // b.none
    435c:	91000400 	add	x0, x0, #0x1
    4360:	f9000420 	str	x0, [x1, #8]
    4364:	a94153f3 	ldp	x19, x20, [sp, #16]
    4368:	f94013f5 	ldr	x21, [sp, #32]
    436c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4370:	d65f03c0 	ret
    4374:	39400260 	ldrb	w0, [x19]
    4378:	7103f81f 	cmp	w0, #0xfe
    437c:	54000100 	b.eq	439c <fwp_rc_wide_dup+0xb8>  // b.none
    4380:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    4384:	91208000 	add	x0, x0, #0x820
    4388:	97fffea2 	bl	3e10 <fwp_trap>
    438c:	b4000081 	cbz	x1, 439c <fwp_rc_wide_dup+0xb8>
    4390:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    4394:	91212000 	add	x0, x0, #0x848
    4398:	97fffe9e 	bl	3e10 <fwp_trap>
    439c:	d2800300 	mov	x0, #0x18                  	// #24
    43a0:	97fff8fc 	bl	2790 <malloc@plt>
    43a4:	b4000280 	cbz	x0, 43f4 <fwp_rc_wide_dup+0x110>
    43a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    43ac:	a9000413 	stp	x19, x1, [x0]
    43b0:	911542b5 	add	x21, x21, #0x550
    43b4:	f900081f 	str	xzr, [x0, #16]
    43b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43bc:	f9000280 	str	x0, [x20]
    43c0:	39000261 	strb	w1, [x19]
    43c4:	f94e26a0 	ldr	x0, [x21, #7240]
    43c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43cc:	91000400 	add	x0, x0, #0x1
    43d0:	f90e26a0 	str	x0, [x21, #7240]
    43d4:	f94013f5 	ldr	x21, [sp, #32]
    43d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43dc:	d65f03c0 	ret
    43e0:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    43e4:	9121c000 	add	x0, x0, #0x870
    43e8:	97fffe8a 	bl	3e10 <fwp_trap>
    43ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43f0:	17ffffd4 	b	4340 <fwp_rc_wide_dup+0x5c>
    43f4:	97fffaef 	bl	2fb0 <fwp_heap_oom>
    43f8:	d503201f 	nop
    43fc:	d503201f 	nop

0000000000004400 <fwp_closure_drop_push>:
    4400:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	a9408014 	ldp	x20, x0, [x0, #8]
    4414:	a9025bf5 	stp	x21, x22, [sp, #32]
    4418:	aa0103f5 	mov	x21, x1
    441c:	a90363f7 	stp	x23, x24, [sp, #48]
    4420:	eb00029f 	cmp	x20, x0
    4424:	54000160 	b.eq	4450 <fwp_closure_drop_push+0x50>  // b.none
    4428:	f9400276 	ldr	x22, [x19]
    442c:	d37df297 	lsl	x23, x20, #3
    4430:	91000694 	add	x20, x20, #0x1
    4434:	f9000674 	str	x20, [x19, #8]
    4438:	a94153f3 	ldp	x19, x20, [sp, #16]
    443c:	f8376ad5 	str	x21, [x22, x23]
    4440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4444:	a94363f7 	ldp	x23, x24, [sp, #48]
    4448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    444c:	d65f03c0 	ret
    4450:	a9046bf9 	stp	x25, x26, [sp, #64]
    4454:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4458:	eb00029f 	cmp	x20, x0
    445c:	540003e8 	b.hi	44d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4460:	d37cee99 	lsl	x25, x20, #4
    4464:	d37ffa9a 	lsl	x26, x20, #1
    4468:	aa1903e0 	mov	x0, x25
    446c:	97fff8c9 	bl	2790 <malloc@plt>
    4470:	aa0003f6 	mov	x22, x0
    4474:	b4000380 	cbz	x0, 44e4 <fwp_closure_drop_push+0xe4>
    4478:	aa1303f8 	mov	x24, x19
    447c:	aa1903e3 	mov	x3, x25
    4480:	d37df297 	lsl	x23, x20, #3
    4484:	aa1703e2 	mov	x2, x23
    4488:	f8418719 	ldr	x25, [x24], #24
    448c:	aa1903e1 	mov	x1, x25
    4490:	97fff8ac 	bl	2740 <__memcpy_chk@plt>
    4494:	eb18033f 	cmp	x25, x24
    4498:	540000a0 	b.eq	44ac <fwp_closure_drop_push+0xac>  // b.none
    449c:	aa1903e0 	mov	x0, x25
    44a0:	97fff904 	bl	28b0 <free@plt>
    44a4:	f9400674 	ldr	x20, [x19, #8]
    44a8:	d37df297 	lsl	x23, x20, #3
    44ac:	91000694 	add	x20, x20, #0x1
    44b0:	f9000276 	str	x22, [x19]
    44b4:	f9000a7a 	str	x26, [x19, #16]
    44b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44bc:	f9000674 	str	x20, [x19, #8]
    44c0:	f8376ad5 	str	x21, [x22, x23]
    44c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44d4:	d65f03c0 	ret
    44d8:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    44dc:	91224000 	add	x0, x0, #0x890
    44e0:	97fffe4c 	bl	3e10 <fwp_trap>
    44e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    44e8:	f947e863 	ldr	x3, [x3, #4048]
    44ec:	d2800262 	mov	x2, #0x13                  	// #19
    44f0:	d2800021 	mov	x1, #0x1                   	// #1
    44f4:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    44f8:	911ba000 	add	x0, x0, #0x6e8
    44fc:	f9400063 	ldr	x3, [x3]
    4500:	97fff8fc 	bl	28f0 <fwrite@plt>
    4504:	d2800000 	mov	x0, #0x0                   	// #0
    4508:	97fff906 	bl	2920 <fflush@plt>
    450c:	52800cc0 	mov	w0, #0x66                  	// #102
    4510:	97fff914 	bl	2960 <_Exit@plt>

0000000000004514 <fwp_closure_drop.part.0>:
    4514:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4518:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x920>
    451c:	910003fd 	mov	x29, sp
    4520:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4524:	f947f463 	ldr	x3, [x3, #4072]
    4528:	a90153f3 	stp	x19, x20, [sp, #16]
    452c:	d10883ff 	sub	sp, sp, #0x220
    4530:	910003e2 	mov	x2, sp
    4534:	d53bd053 	mrs	x19, tpidr_el0
    4538:	910063f4 	add	x20, sp, #0x18
    453c:	3dc0e420 	ldr	q0, [x1, #912]
    4540:	91400264 	add	x4, x19, #0x0, lsl #12
    4544:	91004084 	add	x4, x4, #0x10
    4548:	aa0003e1 	mov	x1, x0
    454c:	aa0203e0 	mov	x0, x2
    4550:	f9400062 	ldr	x2, [x3]
    4554:	f9010fe2 	str	x2, [sp, #536]
    4558:	d2800002 	mov	x2, #0x0                   	// #0
    455c:	f90003f4 	str	x20, [sp]
    4560:	f9000080 	str	x0, [x4]
    4564:	3c8083e0 	stur	q0, [sp, #8]
    4568:	97ffffa6 	bl	4400 <fwp_closure_drop_push>
    456c:	f94007e0 	ldr	x0, [sp, #8]
    4570:	b40002e0 	cbz	x0, 45cc <fwp_closure_drop.part.0+0xb8>
    4574:	f90123f5 	str	x21, [sp, #576]
    4578:	900000f5 	adrp	x21, 20000 <__data_start>
    457c:	910102b5 	add	x21, x21, #0x40
    4580:	14000006 	b	4598 <fwp_closure_drop.part.0+0x84>
    4584:	f9400422 	ldr	x2, [x1, #8]
    4588:	52800001 	mov	w1, #0x0                   	// #0
    458c:	d63f0040 	blr	x2
    4590:	f94007e0 	ldr	x0, [sp, #8]
    4594:	b40001a0 	cbz	x0, 45c8 <fwp_closure_drop.part.0+0xb4>
    4598:	f94003e1 	ldr	x1, [sp]
    459c:	d1000400 	sub	x0, x0, #0x1
    45a0:	f90007e0 	str	x0, [sp, #8]
    45a4:	f9403ea2 	ldr	x2, [x21, #120]
    45a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    45ac:	b9400001 	ldr	w1, [x0]
    45b0:	8b011441 	add	x1, x2, x1, lsl #5
    45b4:	f9400c21 	ldr	x1, [x1, #24]
    45b8:	b5fffe61 	cbnz	x1, 4584 <fwp_closure_drop.part.0+0x70>
    45bc:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    45c0:	9122c000 	add	x0, x0, #0x8b0
    45c4:	97fffe13 	bl	3e10 <fwp_trap>
    45c8:	f94123f5 	ldr	x21, [sp, #576]
    45cc:	91400273 	add	x19, x19, #0x0, lsl #12
    45d0:	91004273 	add	x19, x19, #0x10
    45d4:	f94003e0 	ldr	x0, [sp]
    45d8:	f900027f 	str	xzr, [x19]
    45dc:	eb14001f 	cmp	x0, x20
    45e0:	54000040 	b.eq	45e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45e4:	97fff8b3 	bl	28b0 <free@plt>
    45e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45ec:	f947f400 	ldr	x0, [x0, #4072]
    45f0:	f9410fe2 	ldr	x2, [sp, #536]
    45f4:	f9400001 	ldr	x1, [x0]
    45f8:	eb010042 	subs	x2, x2, x1
    45fc:	d2800001 	mov	x1, #0x0                   	// #0
    4600:	540000a1 	b.ne	4614 <fwp_closure_drop.part.0+0x100>  // b.any
    4604:	910883ff 	add	sp, sp, #0x220
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4610:	d65f03c0 	ret
    4614:	f90123f5 	str	x21, [sp, #576]
    4618:	97fff876 	bl	27f0 <__stack_chk_fail@plt>
    461c:	d503201f 	nop

0000000000004620 <fwp_tape_of>:
    4620:	aa0003e1 	mov	x1, x0
    4624:	92403c00 	and	x0, x0, #0xffff
    4628:	b40000e0 	cbz	x0, 4644 <fwp_tape_of+0x24>
    462c:	d1000402 	sub	x2, x0, #0x1
    4630:	900000e3 	adrp	x3, 20000 <__data_start>
    4634:	91010060 	add	x0, x3, #0x40
    4638:	f9404000 	ldr	x0, [x0, #128]
    463c:	eb02001f 	cmp	x0, x2
    4640:	540000cc 	b.gt	4658 <fwp_tape_of+0x38>
    4644:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4648:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    464c:	91238000 	add	x0, x0, #0x8e0
    4650:	910003fd 	mov	x29, sp
    4654:	97fffdef 	bl	3e10 <fwp_trap>
    4658:	8b020440 	add	x0, x2, x2, lsl #1
    465c:	f9402063 	ldr	x3, [x3, #64]
    4660:	8b000842 	add	x2, x2, x0, lsl #2
    4664:	d37df042 	lsl	x2, x2, #3
    4668:	8b020060 	add	x0, x3, x2
    466c:	b9400404 	ldr	w4, [x0, #4]
    4670:	34fffea4 	cbz	w4, 4644 <fwp_tape_of+0x24>
    4674:	b8626862 	ldr	w2, [x3, x2]
    4678:	9350fc21 	asr	x1, x1, #16
    467c:	6b01005f 	cmp	w2, w1
    4680:	54fffe21 	b.ne	4644 <fwp_tape_of+0x24>  // b.any
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_now_ns>:
    4690:	d100c3ff 	sub	sp, sp, #0x30
    4694:	52800020 	mov	w0, #0x1                   	// #1
    4698:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    469c:	f947f442 	ldr	x2, [x2, #4072]
    46a0:	910023e1 	add	x1, sp, #0x8
    46a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a8:	910083fd 	add	x29, sp, #0x20
    46ac:	f9400043 	ldr	x3, [x2]
    46b0:	f9000fe3 	str	x3, [sp, #24]
    46b4:	d2800003 	mov	x3, #0x0                   	// #0
    46b8:	97fff81a 	bl	2720 <clock_gettime@plt>
    46bc:	350002c0 	cbnz	w0, 4714 <fwp_now_ns+0x84>
    46c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46c4:	d2994003 	mov	x3, #0xca00                	// #51712
    46c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46cc:	9b037c20 	mul	x0, x1, x3
    46d0:	9b437c21 	smulh	x1, x1, x3
    46d4:	ab020000 	adds	x0, x0, x2
    46d8:	937ffc42 	asr	x2, x2, #63
    46dc:	9a020021 	adc	x1, x1, x2
    46e0:	f100001f 	cmp	x0, #0x0
    46e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46e8:	b50001c1 	cbnz	x1, 4720 <fwp_now_ns+0x90>
    46ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    46f0:	f947f421 	ldr	x1, [x1, #4072]
    46f4:	f9400fe3 	ldr	x3, [sp, #24]
    46f8:	f9400022 	ldr	x2, [x1]
    46fc:	eb020063 	subs	x3, x3, x2
    4700:	d2800002 	mov	x2, #0x0                   	// #0
    4704:	54000141 	b.ne	472c <fwp_now_ns+0x9c>  // b.any
    4708:	a9427bfd 	ldp	x29, x30, [sp, #32]
    470c:	9100c3ff 	add	sp, sp, #0x30
    4710:	d65f03c0 	ret
    4714:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    4718:	9124c000 	add	x0, x0, #0x930
    471c:	97fffdbd 	bl	3e10 <fwp_trap>
    4720:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    4724:	91254000 	add	x0, x0, #0x950
    4728:	97fffdba 	bl	3e10 <fwp_trap>
    472c:	97fff831 	bl	27f0 <__stack_chk_fail@plt>

0000000000004730 <fwp_poll_events>:
    4730:	d10103ff 	sub	sp, sp, #0x40
    4734:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4738:	f947f400 	ldr	x0, [x0, #4072]
    473c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4740:	910083fd 	add	x29, sp, #0x20
    4744:	f9001bf3 	str	x19, [sp, #48]
    4748:	900000f3 	adrp	x19, 20000 <__data_start>
    474c:	f9400001 	ldr	x1, [x0]
    4750:	f9000fe1 	str	x1, [sp, #24]
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	97ffffce 	bl	4690 <fwp_now_ns>
    475c:	91010261 	add	x1, x19, #0x40
    4760:	f9404421 	ldr	x1, [x1, #136]
    4764:	b4000e01 	cbz	x1, 4924 <fwp_poll_events+0x1f4>
    4768:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    476c:	14000005 	b	4780 <fwp_poll_events+0x50>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	eb03005f 	cmp	x2, x3
    4778:	9a83d042 	csel	x2, x2, x3, le
    477c:	b40000c1 	cbz	x1, 4794 <fwp_poll_events+0x64>
    4780:	f9403423 	ldr	x3, [x1, #104]
    4784:	b6ffff62 	tbz	x2, #63, 4770 <fwp_poll_events+0x40>
    4788:	f9408821 	ldr	x1, [x1, #272]
    478c:	aa0303e2 	mov	x2, x3
    4790:	b5ffff81 	cbnz	x1, 4780 <fwp_poll_events+0x50>
    4794:	b7f80c82 	tbnz	x2, #63, 4924 <fwp_poll_events+0x1f4>
    4798:	cb000042 	sub	x2, x2, x0
    479c:	f100005f 	cmp	x2, #0x0
    47a0:	540003ad 	b.le	4814 <fwp_poll_events+0xe4>
    47a4:	d2869b60 	mov	x0, #0x34db                	// #13531
    47a8:	d2884804 	mov	x4, #0x4240                	// #16960
    47ac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47b0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47b4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47b8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47bc:	f2e86360 	movk	x0, #0x431b, lsl #48
    47c0:	9b407c40 	smulh	x0, x2, x0
    47c4:	9352fc00 	asr	x0, x0, #18
    47c8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47cc:	9b048802 	msub	x2, x0, x4, x2
    47d0:	f100005f 	cmp	x2, #0x0
    47d4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47d8:	eb01001f 	cmp	x0, x1
    47dc:	5400098c 	b.gt	490c <fwp_poll_events+0x1dc>
    47e0:	340001a0 	cbz	w0, 4814 <fwp_poll_events+0xe4>
    47e4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47e8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47ec:	72a20c41 	movk	w1, #0x1062, lsl #16
    47f0:	9ba17c01 	umull	x1, w0, w1
    47f4:	d366fc23 	lsr	x3, x1, #38
    47f8:	aa0303e2 	mov	x2, x3
    47fc:	1b058063 	msub	w3, w3, w5, w0
    4800:	9b247c63 	smull	x3, w3, w4
    4804:	910023e0 	add	x0, sp, #0x8
    4808:	d2800001 	mov	x1, #0x0                   	// #0
    480c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4810:	97fff82c 	bl	28c0 <nanosleep@plt>
    4814:	97ffff9f 	bl	4690 <fwp_now_ns>
    4818:	91010268 	add	x8, x19, #0x40
    481c:	aa0003e7 	mov	x7, x0
    4820:	4f000400 	movi	v0.4s, #0x0
    4824:	52800029 	mov	w9, #0x1                   	// #1
    4828:	f9404506 	ldr	x6, [x8, #136]
    482c:	d503201f 	nop
    4830:	b40003e6 	cbz	x6, 48ac <fwp_poll_events+0x17c>
    4834:	f94034c1 	ldr	x1, [x6, #104]
    4838:	aa0603e5 	mov	x5, x6
    483c:	f94088c6 	ldr	x6, [x6, #272]
    4840:	eb07003f 	cmp	x1, x7
    4844:	54ffff6c 	b.gt	4830 <fwp_poll_events+0x100>
    4848:	394154a0 	ldrb	w0, [x5, #85]
    484c:	36000120 	tbz	w0, #0, 4870 <fwp_poll_events+0x140>
    4850:	f94084a0 	ldr	x0, [x5, #264]
    4854:	b4000560 	cbz	x0, 4900 <fwp_poll_events+0x1d0>
    4858:	f9008806 	str	x6, [x0, #272]
    485c:	b4000046 	cbz	x6, 4864 <fwp_poll_events+0x134>
    4860:	f90084c0 	str	x0, [x6, #264]
    4864:	910800a0 	add	x0, x5, #0x200
    4868:	390154bf 	strb	wzr, [x5, #85]
    486c:	3c908000 	stur	q0, [x0, #-248]
    4870:	f94030a0 	ldr	x0, [x5, #96]
    4874:	390158a9 	strb	w9, [x5, #86]
    4878:	f100001f 	cmp	x0, #0x0
    487c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4880:	540002cd 	b.le	48d8 <fwp_poll_events+0x1a8>
    4884:	f94028a0 	ldr	x0, [x5, #80]
    4888:	f2001c1f 	tst	x0, #0xff000000ff
    488c:	54fffd21 	b.ne	4830 <fwp_poll_events+0x100>  // b.any
    4890:	f9401500 	ldr	x0, [x8, #40]
    4894:	390150a9 	strb	w9, [x5, #84]
    4898:	f90080bf 	str	xzr, [x5, #256]
    489c:	b40002c0 	cbz	x0, 48f4 <fwp_poll_events+0x1c4>
    48a0:	f9001505 	str	x5, [x8, #40]
    48a4:	f9008005 	str	x5, [x0, #256]
    48a8:	b5fffc66 	cbnz	x6, 4834 <fwp_poll_events+0x104>
    48ac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48b0:	f947f400 	ldr	x0, [x0, #4072]
    48b4:	f9400fe2 	ldr	x2, [sp, #24]
    48b8:	f9400001 	ldr	x1, [x0]
    48bc:	eb010042 	subs	x2, x2, x1
    48c0:	d2800001 	mov	x1, #0x0                   	// #0
    48c4:	540002e1 	b.ne	4920 <fwp_poll_events+0x1f0>  // b.any
    48c8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48cc:	f9401bf3 	ldr	x19, [sp, #48]
    48d0:	910103ff 	add	sp, sp, #0x40
    48d4:	d65f03c0 	ret
    48d8:	394144a0 	ldrb	w0, [x5, #81]
    48dc:	3707fd40 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e0:	394140a0 	ldrb	w0, [x5, #80]
    48e4:	3707fd00 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e8:	aa0503e0 	mov	x0, x5
    48ec:	97fffac1 	bl	33f0 <fwp_cancel_tree.part.0>
    48f0:	17ffffe5 	b	4884 <fwp_poll_events+0x154>
    48f4:	f9001505 	str	x5, [x8, #40]
    48f8:	f9001905 	str	x5, [x8, #48]
    48fc:	17ffffeb 	b	48a8 <fwp_poll_events+0x178>
    4900:	91010261 	add	x1, x19, #0x40
    4904:	f9004426 	str	x6, [x1, #136]
    4908:	17ffffd5 	b	485c <fwp_poll_events+0x12c>
    490c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4910:	d2989362 	mov	x2, #0xc49b                	// #50331
    4914:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4918:	f2a00402 	movk	x2, #0x20, lsl #16
    491c:	17ffffba 	b	4804 <fwp_poll_events+0xd4>
    4920:	97fff7b4 	bl	27f0 <__stack_chk_fail@plt>
    4924:	97fff993 	bl	2f70 <fwp_flush>
    4928:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    492c:	f947e863 	ldr	x3, [x3, #4048]
    4930:	d2800562 	mov	x2, #0x2b                  	// #43
    4934:	d2800021 	mov	x1, #0x1                   	// #1
    4938:	b0000040 	adrp	x0, d000 <__divti3+0x40>
    493c:	9125e000 	add	x0, x0, #0x978
    4940:	f9400063 	ldr	x3, [x3]
    4944:	97fff7eb 	bl	28f0 <fwrite@plt>
    4948:	52800ca0 	mov	w0, #0x65                  	// #101
    494c:	97fff755 	bl	26a0 <exit@plt>

0000000000004950 <fwp_heap_alloc_big>:
    4950:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4954:	910003fd 	mov	x29, sp
    4958:	a90153f3 	stp	x19, x20, [sp, #16]
    495c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4960:	a90363f7 	stp	x23, x24, [sp, #48]
    4964:	aa0003f7 	mov	x23, x0
    4968:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    496c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4970:	eb0002ff 	cmp	x23, x0
    4974:	540008a8 	b.hi	4a88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4978:	d29fffe0 	mov	x0, #0xffff                	// #65535
    497c:	8b0002f4 	add	x20, x23, x0
    4980:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4984:	91154359 	add	x25, x26, #0x550
    4988:	d350fe94 	lsr	x20, x20, #16
    498c:	2a0103f5 	mov	w21, w1
    4990:	aa1403e0 	mov	x0, x20
    4994:	97fff9c7 	bl	30b0 <fwp_heap_chunks>
    4998:	f949ff22 	ldr	x2, [x25, #5112]
    499c:	8b000813 	add	x19, x0, x0, lsl #2
    49a0:	aa0003f8 	mov	x24, x0
    49a4:	52800043 	mov	w3, #0x2                   	// #2
    49a8:	d37df273 	lsl	x19, x19, #3
    49ac:	d2800021 	mov	x1, #0x1                   	// #1
    49b0:	8b130040 	add	x0, x2, x19
    49b4:	38336843 	strb	w3, [x2, x19]
    49b8:	39000415 	strb	w21, [x0, #1]
    49bc:	b9000c14 	str	w20, [x0, #12]
    49c0:	f9000817 	str	x23, [x0, #16]
    49c4:	97fffd57 	bl	3f20 <fwp_rc_prepare_chunk>
    49c8:	f100069f 	cmp	x20, #0x1
    49cc:	54000289 	b.ls	4a1c <fwp_heap_alloc_big+0xcc>  // b.plast
    49d0:	8b180294 	add	x20, x20, x24
    49d4:	9100a273 	add	x19, x19, #0x28
    49d8:	a90573fb 	stp	x27, x28, [sp, #80]
    49dc:	5280007b 	mov	w27, #0x3                   	// #3
    49e0:	8b140a94 	add	x20, x20, x20, lsl #2
    49e4:	2a1803fc 	mov	w28, w24
    49e8:	9adb2296 	lsl	x22, x20, x27
    49ec:	d503201f 	nop
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffd48 	bl	3f20 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x108>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffbbf 	bl	3a70 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff6f 	b	4950 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffd19 	bl	4040 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9403ee0 	ldr	x0, [x23, #120]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_tape_reserve>:
    4f24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4f28:	910003fd 	mov	x29, sp
    4f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f30:	aa0003f3 	mov	x19, x0
    4f34:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f38:	eb00003f 	cmp	x1, x0
    4f3c:	54000868 	b.hi	5048 <fwp_tape_reserve+0x124>  // b.pmore
    4f40:	f9400e74 	ldr	x20, [x19, #24]
    4f44:	eb01029f 	cmp	x20, x1
    4f48:	5400076a 	b.ge	5034 <fwp_tape_reserve+0x110>  // b.tcont
    4f4c:	f100029f 	cmp	x20, #0x0
    4f50:	d2800802 	mov	x2, #0x40                  	// #64
    4f54:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    4f58:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4f5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f60:	a90363f7 	stp	x23, x24, [sp, #48]
    4f64:	eb01029f 	cmp	x20, x1
    4f68:	5400008a 	b.ge	4f78 <fwp_tape_reserve+0x54>  // b.tcont
    4f6c:	eb00029f 	cmp	x20, x0
    4f70:	5400068d 	b.le	5040 <fwp_tape_reserve+0x11c>
    4f74:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f78:	a940d662 	ldp	x2, x21, [x19, #8]
    4f7c:	d37df297 	lsl	x23, x20, #3
    4f80:	f9401260 	ldr	x0, [x19, #32]
    4f84:	aa1703e1 	mov	x1, x23
    4f88:	f9403276 	ldr	x22, [x19, #96]
    4f8c:	cb0202b5 	sub	x21, x21, x2
    4f90:	97fff614 	bl	27e0 <realloc@plt>
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_tape_reserve+0x1d0>
    4f98:	f9400e61 	ldr	x1, [x19, #24]
    4f9c:	8b010801 	add	x1, x0, x1, lsl #2
    4fa0:	a9020660 	stp	x0, x1, [x19, #32]
    4fa4:	b40008b6 	cbz	x22, 50b8 <fwp_tape_reserve+0x194>
    4fa8:	f94032d7 	ldr	x23, [x22, #96]
    4fac:	eb17029f 	cmp	x20, x23
    4fb0:	5400034d 	b.le	5018 <fwp_tape_reserve+0xf4>
    4fb4:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb8:	d37cee9a 	lsl	x26, x20, #4
    4fbc:	aa1a03e0 	mov	x0, x26
    4fc0:	f94022d9 	ldr	x25, [x22, #64]
    4fc4:	52800041 	mov	w1, #0x2                   	// #2
    4fc8:	97ffff0a 	bl	4bf0 <fwp_heap_alloc>
    4fcc:	aa0003f8 	mov	x24, x0
    4fd0:	b4000119 	cbz	x25, 4ff0 <fwp_tape_reserve+0xcc>
    4fd4:	d37ceef7 	lsl	x23, x23, #4
    4fd8:	aa1903e1 	mov	x1, x25
    4fdc:	eb1a02ff 	cmp	x23, x26
    4fe0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    4fe4:	97fff597 	bl	2640 <memcpy@plt>
    4fe8:	aa1903e0 	mov	x0, x25
    4fec:	97fffc45 	bl	4100 <fwp_mem_free>
    4ff0:	f94032c0 	ldr	x0, [x22, #96]
    4ff4:	52800001 	mov	w1, #0x0                   	// #0
    4ff8:	cb000282 	sub	x2, x20, x0
    4ffc:	8b001300 	add	x0, x24, x0, lsl #4
    5000:	d37cec42 	lsl	x2, x2, #4
    5004:	97fff5ef 	bl	27c0 <memset@plt>
    5008:	f9401260 	ldr	x0, [x19, #32]
    500c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5010:	f90022d8 	str	x24, [x22, #64]
    5014:	f90032d4 	str	x20, [x22, #96]
    5018:	d37ef696 	lsl	x22, x20, #2
    501c:	b5000375 	cbnz	x21, 5088 <fwp_tape_reserve+0x164>
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	8b160000 	add	x0, x0, x22
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000e74 	str	x20, [x19, #24]
    5030:	f9001660 	str	x0, [x19, #40]
    5034:	a94153f3 	ldp	x19, x20, [sp, #16]
    5038:	a8c57bfd 	ldp	x29, x30, [sp], #80
    503c:	d65f03c0 	ret
    5040:	d37ffa94 	lsl	x20, x20, #1
    5044:	17ffffc8 	b	4f64 <fwp_tape_reserve+0x40>
    5048:	90000040 	adrp	x0, d000 <__divti3+0x40>
    504c:	91274000 	add	x0, x0, #0x9d0
    5050:	a9025bf5 	stp	x21, x22, [sp, #32]
    5054:	a90363f7 	stp	x23, x24, [sp, #48]
    5058:	a9046bf9 	stp	x25, x26, [sp, #64]
    505c:	97fffb6d 	bl	3e10 <fwp_trap>
    5060:	eb1602ff 	cmp	x23, x22
    5064:	aa0403e0 	mov	x0, x4
    5068:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    506c:	d37df2a2 	lsl	x2, x21, #3
    5070:	cb170063 	sub	x3, x3, x23
    5074:	97fff647 	bl	2990 <__memmove_chk@plt>
    5078:	f9401a61 	ldr	x1, [x19, #48]
    507c:	f9401260 	ldr	x0, [x19, #32]
    5080:	8b170021 	add	x1, x1, x23
    5084:	f9001e61 	str	x1, [x19, #56]
    5088:	f9401661 	ldr	x1, [x19, #40]
    508c:	d37ef696 	lsl	x22, x20, #2
    5090:	d37ef6a2 	lsl	x2, x21, #2
    5094:	8b160000 	add	x0, x0, x22
    5098:	97fff572 	bl	2660 <memmove@plt>
    509c:	f9401260 	ldr	x0, [x19, #32]
    50a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    50a4:	8b160000 	add	x0, x0, x22
    50a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50ac:	f9000e74 	str	x20, [x19, #24]
    50b0:	f9001660 	str	x0, [x19, #40]
    50b4:	17ffffe0 	b	5034 <fwp_tape_reserve+0x110>
    50b8:	f9401a60 	ldr	x0, [x19, #48]
    50bc:	d37cee96 	lsl	x22, x20, #4
    50c0:	aa1603e1 	mov	x1, x22
    50c4:	97fff5c7 	bl	27e0 <realloc@plt>
    50c8:	b4000160 	cbz	x0, 50f4 <fwp_tape_reserve+0x1d0>
    50cc:	f9400e62 	ldr	x2, [x19, #24]
    50d0:	f9001a60 	str	x0, [x19, #48]
    50d4:	8b170004 	add	x4, x0, x23
    50d8:	8b020c01 	add	x1, x0, x2, lsl #3
    50dc:	f9001e61 	str	x1, [x19, #56]
    50e0:	b5fffc15 	cbnz	x21, 5060 <fwp_tape_reserve+0x13c>
    50e4:	f9401260 	ldr	x0, [x19, #32]
    50e8:	d37ef696 	lsl	x22, x20, #2
    50ec:	f9001e64 	str	x4, [x19, #56]
    50f0:	17ffffcc 	b	5020 <fwp_tape_reserve+0xfc>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50fc:	97fff785 	bl	2f10 <fwp_tape_unlink_scope>
    5100:	f9401260 	ldr	x0, [x19, #32]
    5104:	97fff5eb 	bl	28b0 <free@plt>
    5108:	f9401a60 	ldr	x0, [x19, #48]
    510c:	97fff5e9 	bl	28b0 <free@plt>
    5110:	f9402260 	ldr	x0, [x19, #64]
    5114:	97fff5e7 	bl	28b0 <free@plt>
    5118:	f9000e7f 	str	xzr, [x19, #24]
    511c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5120:	f947e821 	ldr	x1, [x1, #4048]
    5124:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5128:	d2800262 	mov	x2, #0x13                  	// #19
    512c:	4f000400 	movi	v0.4s, #0x0
    5130:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5134:	f9400023 	ldr	x3, [x1]
    5138:	b900067f 	str	wzr, [x19, #4]
    513c:	d2800021 	mov	x1, #0x1                   	// #1
    5140:	911ba000 	add	x0, x0, #0x6e8
    5144:	3c808260 	stur	q0, [x19, #8]
    5148:	ad010260 	stp	q0, q0, [x19, #32]
    514c:	97fff5e9 	bl	28f0 <fwrite@plt>
    5150:	d2800000 	mov	x0, #0x0                   	// #0
    5154:	97fff5f3 	bl	2920 <fflush@plt>
    5158:	52800cc0 	mov	w0, #0x66                  	// #102
    515c:	97fff601 	bl	2960 <_Exit@plt>

0000000000005160 <f128.constprop.0>:
    5160:	f100001f 	cmp	x0, #0x0
    5164:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5168:	5400094b 	b.lt	5290 <f128.constprop.0+0x130>  // b.tstop
    516c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5170:	aa0003e2 	mov	x2, x0
    5174:	910003fd 	mov	x29, sp
    5178:	a90153f3 	stp	x19, x20, [sp, #16]
    517c:	aa0003f4 	mov	x20, x0
    5180:	aa010000 	orr	x0, x0, x1
    5184:	a9025bf5 	stp	x21, x22, [sp, #32]
    5188:	aa0103f6 	mov	x22, x1
    518c:	f9001bf7 	str	x23, [sp, #48]
    5190:	fd001fe8 	str	d8, [sp, #56]
    5194:	b7f80180 	tbnz	x0, #63, 51c4 <f128.constprop.0+0x64>
    5198:	9360fc20 	asr	x0, x1, #32
    519c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51a0:	eb82801f 	cmp	x0, x2, asr #32
    51a4:	540007a1 	b.ne	5298 <f128.constprop.0+0x138>  // b.any
    51a8:	97fffd1e 	bl	4620 <fwp_tape_of>
    51ac:	aa0003f3 	mov	x19, x0
    51b0:	f9403000 	ldr	x0, [x0, #96]
    51b4:	b40001e0 	cbz	x0, 51f0 <f128.constprop.0+0x90>
    51b8:	90000040 	adrp	x0, d000 <__divti3+0x40>
    51bc:	9128e000 	add	x0, x0, #0xa38
    51c0:	97fffb14 	bl	3e10 <fwp_trap>
    51c4:	9360fc40 	asr	x0, x2, #32
    51c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51cc:	b6fffee2 	tbz	x2, #63, 51a8 <f128.constprop.0+0x48>
    51d0:	2f00e408 	movi	d8, #0x0
    51d4:	9360fc20 	asr	x0, x1, #32
    51d8:	aa0103f4 	mov	x20, x1
    51dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    51e0:	97fffd10 	bl	4620 <fwp_tape_of>
    51e4:	aa0003f3 	mov	x19, x0
    51e8:	f9403000 	ldr	x0, [x0, #96]
    51ec:	b5fffe60 	cbnz	x0, 51b8 <f128.constprop.0+0x58>
    51f0:	f9400a77 	ldr	x23, [x19, #16]
    51f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    51f8:	eb0002ff 	cmp	x23, x0
    51fc:	5400044c 	b.gt	5284 <f128.constprop.0+0x124>
    5200:	eb3442ff 	cmp	x23, w20, uxtw
    5204:	5400008d 	b.le	5214 <f128.constprop.0+0xb4>
    5208:	b7f800d6 	tbnz	x22, #63, 5220 <f128.constprop.0+0xc0>
    520c:	eb3642ff 	cmp	x23, w22, uxtw
    5210:	5400008c 	b.gt	5220 <f128.constprop.0+0xc0>
    5214:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5218:	9129a000 	add	x0, x0, #0xa68
    521c:	97fffafd 	bl	3e10 <fwp_trap>
    5220:	f9400675 	ldr	x21, [x19, #8]
    5224:	aa1303e0 	mov	x0, x19
    5228:	cb1502f5 	sub	x21, x23, x21
    522c:	910006a1 	add	x1, x21, #0x1
    5230:	97ffff3d 	bl	4f24 <fwp_tape_reserve>
    5234:	a9420262 	ldp	x2, x0, [x19, #32]
    5238:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    523c:	f9401a61 	ldr	x1, [x19, #48]
    5240:	b8357854 	str	w20, [x2, x21, lsl #2]
    5244:	f9401e62 	ldr	x2, [x19, #56]
    5248:	f10002df 	cmp	x22, #0x0
    524c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5250:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5254:	b8357816 	str	w22, [x0, x21, lsl #2]
    5258:	92607e80 	and	x0, x20, #0xffffffff00000000
    525c:	910006e1 	add	x1, x23, #0x1
    5260:	aa170000 	orr	x0, x0, x23
    5264:	fc357848 	str	d8, [x2, x21, lsl #3]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	f9401bf7 	ldr	x23, [sp, #48]
    5270:	fd401fe8 	ldr	d8, [sp, #56]
    5274:	f9000a61 	str	x1, [x19, #16]
    5278:	a94153f3 	ldp	x19, x20, [sp, #16]
    527c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5280:	d65f03c0 	ret
    5284:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5288:	91274000 	add	x0, x0, #0x9d0
    528c:	97fffae1 	bl	3e10 <fwp_trap>
    5290:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5294:	d65f03c0 	ret
    5298:	90000040 	adrp	x0, d000 <__divti3+0x40>
    529c:	9127c000 	add	x0, x0, #0x9f0
    52a0:	97fffadc 	bl	3e10 <fwp_trap>

00000000000052a4 <w107>:
    52a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    52a8:	910003fd 	mov	x29, sp
    52ac:	a90153f3 	stp	x19, x20, [sp, #16]
    52b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    52b4:	aa0003f5 	mov	x21, x0
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	aa0103f7 	mov	x23, x1
    52c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    52c4:	f9002bfb 	str	x27, [sp, #80]
    52c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    52cc:	1e604028 	fmov	d8, d1
    52d0:	1e600809 	fmul	d9, d0, d0
    52d4:	6d072fea 	stp	d10, d11, [sp, #112]
    52d8:	1e60400b 	fmov	d11, d0
    52dc:	b7f81c80 	tbnz	x0, #63, 566c <w107+0x3c8>
    52e0:	9360fc19 	asr	x25, x0, #32
    52e4:	aa1903e0 	mov	x0, x25
    52e8:	97fffcce 	bl	4620 <fwp_tape_of>
    52ec:	f9403001 	ldr	x1, [x0, #96]
    52f0:	aa0003f3 	mov	x19, x0
    52f4:	b4000081 	cbz	x1, 5304 <w107+0x60>
    52f8:	90000040 	adrp	x0, d000 <__divti3+0x40>
    52fc:	9128e000 	add	x0, x0, #0xa38
    5300:	97fffac4 	bl	3e10 <fwp_trap>
    5304:	f9400818 	ldr	x24, [x0, #16]
    5308:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    530c:	eb01031f 	cmp	x24, x1
    5310:	54001a8c 	b.gt	5660 <w107+0x3bc>
    5314:	eb35431f 	cmp	x24, w21, uxtw
    5318:	540019ed 	b.le	5654 <w107+0x3b0>
    531c:	f9400416 	ldr	x22, [x0, #8]
    5320:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5324:	aa180294 	orr	x20, x20, x24
    5328:	cb160316 	sub	x22, x24, x22
    532c:	910006c1 	add	x1, x22, #0x1
    5330:	97fffefd 	bl	4f24 <fwp_tape_reserve>
    5334:	a9420a61 	ldp	x1, x2, [x19, #32]
    5338:	91000700 	add	x0, x24, #0x1
    533c:	f9401a63 	ldr	x3, [x19, #48]
    5340:	b8367835 	str	w21, [x1, x22, lsl #2]
    5344:	f9401e61 	ldr	x1, [x19, #56]
    5348:	1e693908 	fsub	d8, d8, d9
    534c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5350:	9360fe9a 	asr	x26, x20, #32
    5354:	b8367855 	str	w21, [x2, x22, lsl #2]
    5358:	fc36782b 	str	d11, [x1, x22, lsl #3]
    535c:	f9000a60 	str	x0, [x19, #16]
    5360:	b7f80077 	tbnz	x23, #63, 536c <w107+0xc8>
    5364:	eb97835f 	cmp	x26, x23, asr #32
    5368:	540019a1 	b.ne	569c <w107+0x3f8>  // b.any
    536c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5370:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5374:	eb19035f 	cmp	x26, x25
    5378:	540000c0 	b.eq	5390 <w107+0xec>  // b.none
    537c:	aa1a03e0 	mov	x0, x26
    5380:	97fffca8 	bl	4620 <fwp_tape_of>
    5384:	aa0003f3 	mov	x19, x0
    5388:	f9403000 	ldr	x0, [x0, #96]
    538c:	b5fffb60 	cbnz	x0, 52f8 <w107+0x54>
    5390:	f9400a79 	ldr	x25, [x19, #16]
    5394:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5398:	eb00033f 	cmp	x25, x0
    539c:	5400162c 	b.gt	5660 <w107+0x3bc>
    53a0:	eb34433f 	cmp	x25, w20, uxtw
    53a4:	5400158d 	b.le	5654 <w107+0x3b0>
    53a8:	b7f80077 	tbnz	x23, #63, 53b4 <w107+0x110>
    53ac:	eb37433f 	cmp	x25, w23, uxtw
    53b0:	5400152d 	b.le	5654 <w107+0x3b0>
    53b4:	f9400676 	ldr	x22, [x19, #8]
    53b8:	aa1303e0 	mov	x0, x19
    53bc:	cb160336 	sub	x22, x25, x22
    53c0:	910006c1 	add	x1, x22, #0x1
    53c4:	97fffed8 	bl	4f24 <fwp_tape_reserve>
    53c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    53cc:	f10002ff 	cmp	x23, #0x0
    53d0:	f9401a61 	ldr	x1, [x19, #48]
    53d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    53d8:	f9401e62 	ldr	x2, [x19, #56]
    53dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    53e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    53e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    53ec:	91000737 	add	x23, x25, #0x1
    53f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    53f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    53f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    53fc:	aa190294 	orr	x20, x20, x25
    5400:	f9000a77 	str	x23, [x19, #16]
    5404:	1e6b3929 	fsub	d9, d9, d11
    5408:	b7f81675 	tbnz	x21, #63, 56d4 <w107+0x430>
    540c:	9360febb 	asr	x27, x21, #32
    5410:	eb1a037f 	cmp	x27, x26
    5414:	540000e0 	b.eq	5430 <w107+0x18c>  // b.none
    5418:	aa1b03e0 	mov	x0, x27
    541c:	97fffc81 	bl	4620 <fwp_tape_of>
    5420:	aa0003f3 	mov	x19, x0
    5424:	f9403000 	ldr	x0, [x0, #96]
    5428:	b5fff680 	cbnz	x0, 52f8 <w107+0x54>
    542c:	f9400a77 	ldr	x23, [x19, #16]
    5430:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5434:	eb0002ff 	cmp	x23, x0
    5438:	5400114c 	b.gt	5660 <w107+0x3bc>
    543c:	eb3542ff 	cmp	x23, w21, uxtw
    5440:	540010ad 	b.le	5654 <w107+0x3b0>
    5444:	f9400676 	ldr	x22, [x19, #8]
    5448:	aa1303e0 	mov	x0, x19
    544c:	cb1602f6 	sub	x22, x23, x22
    5450:	910006c1 	add	x1, x22, #0x1
    5454:	97fffeb4 	bl	4f24 <fwp_tape_reserve>
    5458:	a9420261 	ldp	x1, x0, [x19, #32]
    545c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5460:	f9401a63 	ldr	x3, [x19, #48]
    5464:	b8367835 	str	w21, [x1, x22, lsl #2]
    5468:	f9401e61 	ldr	x1, [x19, #56]
    546c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5470:	fc367860 	str	d0, [x3, x22, lsl #3]
    5474:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5478:	b8367802 	str	w2, [x0, x22, lsl #2]
    547c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5480:	910006e0 	add	x0, x23, #0x1
    5484:	aa1702b7 	orr	x23, x21, x23
    5488:	fc367820 	str	d0, [x1, x22, lsl #3]
    548c:	f9000a60 	str	x0, [x19, #16]
    5490:	9360fe99 	asr	x25, x20, #32
    5494:	1e68090a 	fmul	d10, d8, d8
    5498:	eb1b033f 	cmp	x25, x27
    549c:	540000c0 	b.eq	54b4 <w107+0x210>  // b.none
    54a0:	aa1903e0 	mov	x0, x25
    54a4:	97fffc5f 	bl	4620 <fwp_tape_of>
    54a8:	aa0003f3 	mov	x19, x0
    54ac:	f9403000 	ldr	x0, [x0, #96]
    54b0:	b5fff240 	cbnz	x0, 52f8 <w107+0x54>
    54b4:	f9400a75 	ldr	x21, [x19, #16]
    54b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54bc:	eb0002bf 	cmp	x21, x0
    54c0:	54000d0c 	b.gt	5660 <w107+0x3bc>
    54c4:	eb3442bf 	cmp	x21, w20, uxtw
    54c8:	54000c6d 	b.le	5654 <w107+0x3b0>
    54cc:	f9400678 	ldr	x24, [x19, #8]
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    54d8:	cb1802b8 	sub	x24, x21, x24
    54dc:	aa1502d6 	orr	x22, x22, x21
    54e0:	91000701 	add	x1, x24, #0x1
    54e4:	97fffe90 	bl	4f24 <fwp_tape_reserve>
    54e8:	a9420261 	ldp	x1, x0, [x19, #32]
    54ec:	f9401a62 	ldr	x2, [x19, #48]
    54f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    54f4:	f9401e61 	ldr	x1, [x19, #56]
    54f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    54fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5500:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5504:	9e670000 	fmov	d0, x0
    5508:	910006b4 	add	x20, x21, #0x1
    550c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5510:	9360fed8 	asr	x24, x22, #32
    5514:	f9000a74 	str	x20, [x19, #16]
    5518:	1e60094a 	fmul	d10, d10, d0
    551c:	eb19031f 	cmp	x24, x25
    5520:	540000e0 	b.eq	553c <w107+0x298>  // b.none
    5524:	aa1803e0 	mov	x0, x24
    5528:	97fffc3e 	bl	4620 <fwp_tape_of>
    552c:	aa0003f3 	mov	x19, x0
    5530:	f9403000 	ldr	x0, [x0, #96]
    5534:	b5ffee20 	cbnz	x0, 52f8 <w107+0x54>
    5538:	f9400a74 	ldr	x20, [x19, #16]
    553c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5540:	eb00029f 	cmp	x20, x0
    5544:	540008ec 	b.gt	5660 <w107+0x3bc>
    5548:	eb36429f 	cmp	x20, w22, uxtw
    554c:	5400084d 	b.le	5654 <w107+0x3b0>
    5550:	f9400675 	ldr	x21, [x19, #8]
    5554:	aa1303e0 	mov	x0, x19
    5558:	cb150295 	sub	x21, x20, x21
    555c:	910006a1 	add	x1, x21, #0x1
    5560:	97fffe71 	bl	4f24 <fwp_tape_reserve>
    5564:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5568:	9e670000 	fmov	d0, x0
    556c:	a9420261 	ldp	x1, x0, [x19, #32]
    5570:	1e690928 	fmul	d8, d9, d9
    5574:	f9401a62 	ldr	x2, [x19, #48]
    5578:	b8357836 	str	w22, [x1, x21, lsl #2]
    557c:	f9401e61 	ldr	x1, [x19, #56]
    5580:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5584:	fc357840 	str	d0, [x2, x21, lsl #3]
    5588:	12800002 	mov	w2, #0xffffffff            	// #-1
    558c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5590:	91000680 	add	x0, x20, #0x1
    5594:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5598:	aa1402d6 	orr	x22, x22, x20
    559c:	f9000a60 	str	x0, [x19, #16]
    55a0:	b10006ff 	cmn	x23, #0x1
    55a4:	540009e0 	b.eq	56e0 <w107+0x43c>  // b.none
    55a8:	9360fee0 	asr	x0, x23, #32
    55ac:	eb18001f 	cmp	x0, x24
    55b0:	540000a0 	b.eq	55c4 <w107+0x320>  // b.none
    55b4:	97fffc1b 	bl	4620 <fwp_tape_of>
    55b8:	aa0003f3 	mov	x19, x0
    55bc:	f9403000 	ldr	x0, [x0, #96]
    55c0:	b5ffe9c0 	cbnz	x0, 52f8 <w107+0x54>
    55c4:	f9400a74 	ldr	x20, [x19, #16]
    55c8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55cc:	eb00029f 	cmp	x20, x0
    55d0:	5400048c 	b.gt	5660 <w107+0x3bc>
    55d4:	eb37429f 	cmp	x20, w23, uxtw
    55d8:	540003ed 	b.le	5654 <w107+0x3b0>
    55dc:	f9400675 	ldr	x21, [x19, #8]
    55e0:	aa1303e0 	mov	x0, x19
    55e4:	cb150295 	sub	x21, x20, x21
    55e8:	910006a1 	add	x1, x21, #0x1
    55ec:	97fffe4e 	bl	4f24 <fwp_tape_reserve>
    55f0:	a9420a61 	ldp	x1, x2, [x19, #32]
    55f4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    55f8:	f9401a63 	ldr	x3, [x19, #48]
    55fc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5600:	f9401e61 	ldr	x1, [x19, #56]
    5604:	aa140000 	orr	x0, x0, x20
    5608:	fc357869 	str	d9, [x3, x21, lsl #3]
    560c:	91000694 	add	x20, x20, #0x1
    5610:	b8357857 	str	w23, [x2, x21, lsl #2]
    5614:	fc357829 	str	d9, [x1, x21, lsl #3]
    5618:	f9000a74 	str	x20, [x19, #16]
    561c:	1e6a2908 	fadd	d8, d8, d10
    5620:	aa1603e1 	mov	x1, x22
    5624:	97fffecf 	bl	5160 <f128.constprop.0>
    5628:	aa0003e1 	mov	x1, x0
    562c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5630:	9e660100 	fmov	x0, d8
    5634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5638:	a94363f7 	ldp	x23, x24, [sp, #48]
    563c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5640:	f9402bfb 	ldr	x27, [sp, #80]
    5644:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5648:	6d472fea 	ldp	d10, d11, [sp, #112]
    564c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5650:	d65f03c0 	ret
    5654:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5658:	9129a000 	add	x0, x0, #0xa68
    565c:	97fff9ed 	bl	3e10 <fwp_trap>
    5660:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5664:	91274000 	add	x0, x0, #0x9d0
    5668:	97fff9ea 	bl	3e10 <fwp_trap>
    566c:	1e693828 	fsub	d8, d1, d9
    5670:	b6f801c1 	tbz	x1, #63, 56a8 <w107+0x404>
    5674:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5678:	1e68090a 	fmul	d10, d8, d8
    567c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5680:	9e670000 	fmov	d0, x0
    5684:	1e6b3828 	fsub	d8, d1, d11
    5688:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    568c:	aa1603e0 	mov	x0, x22
    5690:	1e60094a 	fmul	d10, d10, d0
    5694:	1e680908 	fmul	d8, d8, d8
    5698:	17ffffe1 	b	561c <w107+0x378>
    569c:	90000040 	adrp	x0, d000 <__divti3+0x40>
    56a0:	9127c000 	add	x0, x0, #0x9f0
    56a4:	97fff9db 	bl	3e10 <fwp_trap>
    56a8:	2f00e40a 	movi	d10, #0x0
    56ac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56b0:	9360fc3a 	asr	x26, x1, #32
    56b4:	aa0103f4 	mov	x20, x1
    56b8:	aa1a03e0 	mov	x0, x26
    56bc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    56c0:	97fffbd8 	bl	4620 <fwp_tape_of>
    56c4:	aa0003f3 	mov	x19, x0
    56c8:	f9403000 	ldr	x0, [x0, #96]
    56cc:	b5ffe160 	cbnz	x0, 52f8 <w107+0x54>
    56d0:	17ffff30 	b	5390 <w107+0xec>
    56d4:	aa1a03fb 	mov	x27, x26
    56d8:	aa0003f7 	mov	x23, x0
    56dc:	17ffff6d 	b	5490 <w107+0x1ec>
    56e0:	aa1703e0 	mov	x0, x23
    56e4:	17ffffce 	b	561c <w107+0x378>
    56e8:	d503201f 	nop
    56ec:	d503201f 	nop

00000000000056f0 <fwp_data.part.0.constprop.0>:
    56f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56f4:	910003fd 	mov	x29, sp
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    5700:	91154283 	add	x3, x20, #0x550
    5704:	a9025bf5 	stp	x21, x22, [sp, #32]
    5708:	aa0103f5 	mov	x21, x1
    570c:	b953a461 	ldr	w1, [x3, #5028]
    5710:	a90363f7 	stp	x23, x24, [sp, #48]
    5714:	2a0003f8 	mov	w24, w0
    5718:	34000701 	cbz	w1, 57f8 <fwp_data.part.0.constprop.0+0x108>
    571c:	397e8862 	ldrb	w2, [x3, #4002]
    5720:	910f0040 	add	x0, x2, #0x3c0
    5724:	8b020442 	add	x2, x2, x2, lsl #1
    5728:	d37df042 	lsl	x2, x2, #3
    572c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5730:	2a1703f6 	mov	w22, w23
    5734:	f8626873 	ldr	x19, [x3, x2]
    5738:	b40004d3 	cbz	x19, 57d0 <fwp_data.part.0.constprop.0+0xe0>
    573c:	f9400260 	ldr	x0, [x19]
    5740:	aa2003e0 	mvn	x0, x0
    5744:	f8226860 	str	x0, [x3, x2]
    5748:	f10062df 	cmp	x22, #0x18
    574c:	540000e9 	b.ls	5768 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5750:	d10066c2 	sub	x2, x22, #0x19
    5754:	91006260 	add	x0, x19, #0x18
    5758:	927df042 	and	x2, x2, #0xfffffffffffffff8
    575c:	52800001 	mov	w1, #0x0                   	// #0
    5760:	91002042 	add	x2, x2, #0x8
    5764:	97fff417 	bl	27c0 <memset@plt>
    5768:	91154282 	add	x2, x20, #0x550
    576c:	f94a1041 	ldr	x1, [x2, #5152]
    5770:	ab160021 	adds	x1, x1, x22
    5774:	540004c2 	b.cs	580c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5778:	f94a1440 	ldr	x0, [x2, #5160]
    577c:	f90a1041 	str	x1, [x2, #5152]
    5780:	eb00003f 	cmp	x1, x0
    5784:	54000049 	b.ls	578c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5788:	f90a1441 	str	x1, [x2, #5160]
    578c:	91154294 	add	x20, x20, #0x550
    5790:	1e6302e1 	ucvtf	d1, w23
    5794:	fd4a1e80 	ldr	d0, [x20, #5176]
    5798:	1e612800 	fadd	d0, d0, d1
    579c:	fd0a1e80 	str	d0, [x20, #5176]
    57a0:	52800041 	mov	w1, #0x2                   	// #2
    57a4:	29000678 	stp	w24, w1, [x19]
    57a8:	aa1303e0 	mov	x0, x19
    57ac:	f94002a1 	ldr	x1, [x21]
    57b0:	f9000661 	str	x1, [x19, #8]
    57b4:	f94006a1 	ldr	x1, [x21, #8]
    57b8:	f9000a61 	str	x1, [x19, #16]
    57bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    57c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57cc:	d65f03c0 	ret
    57d0:	8b020063 	add	x3, x3, x2
    57d4:	f9400473 	ldr	x19, [x3, #8]
    57d8:	b4000113 	cbz	x19, 57f8 <fwp_data.part.0.constprop.0+0x108>
    57dc:	f9400860 	ldr	x0, [x3, #16]
    57e0:	cb130000 	sub	x0, x0, x19
    57e4:	eb0002df 	cmp	x22, x0
    57e8:	54000088 	b.hi	57f8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    57ec:	8b160260 	add	x0, x19, x22
    57f0:	f9000460 	str	x0, [x3, #8]
    57f4:	17ffffd5 	b	5748 <fwp_data.part.0.constprop.0+0x58>
    57f8:	52800001 	mov	w1, #0x0                   	// #0
    57fc:	d2800300 	mov	x0, #0x18                  	// #24
    5800:	97fffcfc 	bl	4bf0 <fwp_heap_alloc>
    5804:	aa0003f3 	mov	x19, x0
    5808:	17ffffe6 	b	57a0 <fwp_data.part.0.constprop.0+0xb0>
    580c:	97fff5e9 	bl	2fb0 <fwp_heap_oom>

0000000000005810 <fwp_rc_share>:
    5810:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5814:	91154042 	add	x2, x2, #0x550
    5818:	f949d843 	ldr	x3, [x2, #5040]
    581c:	f949ec41 	ldr	x1, [x2, #5080]
    5820:	cb030000 	sub	x0, x0, x3
    5824:	eb01401f 	cmp	x0, x1, lsl #16
    5828:	540003a2 	b.cs	589c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    582c:	d350fc01 	lsr	x1, x0, #16
    5830:	f949fc44 	ldr	x4, [x2, #5112]
    5834:	8b010821 	add	x1, x1, x1, lsl #2
    5838:	d37df021 	lsl	x1, x1, #3
    583c:	8b010083 	add	x3, x4, x1
    5840:	f9401062 	ldr	x2, [x3, #32]
    5844:	b40002c2 	cbz	x2, 589c <fwp_rc_share+0x8c>
    5848:	38616881 	ldrb	w1, [x4, x1]
    584c:	7100083f 	cmp	w1, #0x2
    5850:	54000220 	b.eq	5894 <fwp_rc_share+0x84>  // b.none
    5854:	7100043f 	cmp	w1, #0x1
    5858:	54000221 	b.ne	589c <fwp_rc_share+0x8c>  // b.any
    585c:	29430464 	ldp	w4, w1, [x3, #24]
    5860:	92403c00 	and	x0, x0, #0xffff
    5864:	9b047c00 	mul	x0, x0, x4
    5868:	d360fc00 	lsr	x0, x0, #32
    586c:	eb01001f 	cmp	x0, x1
    5870:	54000162 	b.cs	589c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5874:	8b000042 	add	x2, x2, x0
    5878:	39400040 	ldrb	w0, [x2]
    587c:	34000100 	cbz	w0, 589c <fwp_rc_share+0x8c>
    5880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5884:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5888:	912a2000 	add	x0, x0, #0xa88
    588c:	910003fd 	mov	x29, sp
    5890:	97fff960 	bl	3e10 <fwp_trap>
    5894:	72003c1f 	tst	w0, #0xffff
    5898:	54ffff00 	b.eq	5878 <fwp_rc_share+0x68>  // b.none
    589c:	d65f03c0 	ret

00000000000058a0 <fwp_rc_fresh>:
    58a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    58a4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    58a8:	91154063 	add	x3, x3, #0x550
    58ac:	910003fd 	mov	x29, sp
    58b0:	a90153f3 	stp	x19, x20, [sp, #16]
    58b4:	aa0003f3 	mov	x19, x0
    58b8:	f949d861 	ldr	x1, [x3, #5040]
    58bc:	f949ec60 	ldr	x0, [x3, #5080]
    58c0:	cb010261 	sub	x1, x19, x1
    58c4:	eb00403f 	cmp	x1, x0, lsl #16
    58c8:	54000322 	b.cs	592c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    58cc:	d350fc22 	lsr	x2, x1, #16
    58d0:	f949fc63 	ldr	x3, [x3, #5112]
    58d4:	8b020842 	add	x2, x2, x2, lsl #2
    58d8:	d37df042 	lsl	x2, x2, #3
    58dc:	8b020060 	add	x0, x3, x2
    58e0:	f9401014 	ldr	x20, [x0, #32]
    58e4:	b4000254 	cbz	x20, 592c <fwp_rc_fresh+0x8c>
    58e8:	38626862 	ldrb	w2, [x3, x2]
    58ec:	7100085f 	cmp	w2, #0x2
    58f0:	54000260 	b.eq	593c <fwp_rc_fresh+0x9c>  // b.none
    58f4:	7100045f 	cmp	w2, #0x1
    58f8:	540001a1 	b.ne	592c <fwp_rc_fresh+0x8c>  // b.any
    58fc:	29430002 	ldp	w2, w0, [x0, #24]
    5900:	92403c21 	and	x1, x1, #0xffff
    5904:	9b027c21 	mul	x1, x1, x2
    5908:	d360fc21 	lsr	x1, x1, #32
    590c:	eb00003f 	cmp	x1, x0
    5910:	540000e2 	b.cs	592c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5914:	8b010294 	add	x20, x20, x1
    5918:	39400280 	ldrb	w0, [x20]
    591c:	7103fc1f 	cmp	w0, #0xff
    5920:	540001a0 	b.eq	5954 <fwp_rc_fresh+0xb4>  // b.none
    5924:	52800020 	mov	w0, #0x1                   	// #1
    5928:	39000280 	strb	w0, [x20]
    592c:	aa1303e0 	mov	x0, x19
    5930:	a94153f3 	ldp	x19, x20, [sp, #16]
    5934:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5938:	d65f03c0 	ret
    593c:	72003c3f 	tst	w1, #0xffff
    5940:	54fffec0 	b.eq	5918 <fwp_rc_fresh+0x78>  // b.none
    5944:	aa1303e0 	mov	x0, x19
    5948:	a94153f3 	ldp	x19, x20, [sp, #16]
    594c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5950:	d65f03c0 	ret
    5954:	aa1403e0 	mov	x0, x20
    5958:	97fff94e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    595c:	17fffff2 	b	5924 <fwp_rc_fresh+0x84>

0000000000005960 <fwp_rc_free_arr>:
    5960:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5964:	91154063 	add	x3, x3, #0x550
    5968:	f949d861 	ldr	x1, [x3, #5040]
    596c:	f949ec62 	ldr	x2, [x3, #5080]
    5970:	cb010001 	sub	x1, x0, x1
    5974:	eb02403f 	cmp	x1, x2, lsl #16
    5978:	54000342 	b.cs	59e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    597c:	d350fc22 	lsr	x2, x1, #16
    5980:	f949fc65 	ldr	x5, [x3, #5112]
    5984:	8b020842 	add	x2, x2, x2, lsl #2
    5988:	d37df042 	lsl	x2, x2, #3
    598c:	8b0200a4 	add	x4, x5, x2
    5990:	f9401083 	ldr	x3, [x4, #32]
    5994:	b4000263 	cbz	x3, 59e0 <fwp_rc_free_arr+0x80>
    5998:	386268a2 	ldrb	w2, [x5, x2]
    599c:	7100085f 	cmp	w2, #0x2
    59a0:	540001c0 	b.eq	59d8 <fwp_rc_free_arr+0x78>  // b.none
    59a4:	7100045f 	cmp	w2, #0x1
    59a8:	540001c1 	b.ne	59e0 <fwp_rc_free_arr+0x80>  // b.any
    59ac:	29430885 	ldp	w5, w2, [x4, #24]
    59b0:	92403c21 	and	x1, x1, #0xffff
    59b4:	9b057c21 	mul	x1, x1, x5
    59b8:	d360fc21 	lsr	x1, x1, #32
    59bc:	eb02003f 	cmp	x1, x2
    59c0:	54000102 	b.cs	59e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59c4:	8b010063 	add	x3, x3, x1
    59c8:	39400061 	ldrb	w1, [x3]
    59cc:	7100043f 	cmp	w1, #0x1
    59d0:	54000081 	b.ne	59e0 <fwp_rc_free_arr+0x80>  // b.any
    59d4:	17fff9cb 	b	4100 <fwp_mem_free>
    59d8:	72003c3f 	tst	w1, #0xffff
    59dc:	54ffff60 	b.eq	59c8 <fwp_rc_free_arr+0x68>  // b.none
    59e0:	d65f03c0 	ret

00000000000059e4 <fwp_rc_dup>:
    59e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    59e8:	91154042 	add	x2, x2, #0x550
    59ec:	f949d841 	ldr	x1, [x2, #5040]
    59f0:	f949ec43 	ldr	x3, [x2, #5080]
    59f4:	cb010001 	sub	x1, x0, x1
    59f8:	eb03403f 	cmp	x1, x3, lsl #16
    59fc:	54000342 	b.cs	5a64 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a00:	d350fc20 	lsr	x0, x1, #16
    5a04:	f949fc44 	ldr	x4, [x2, #5112]
    5a08:	8b000800 	add	x0, x0, x0, lsl #2
    5a0c:	d37df002 	lsl	x2, x0, #3
    5a10:	8b020083 	add	x3, x4, x2
    5a14:	f9401060 	ldr	x0, [x3, #32]
    5a18:	b4000260 	cbz	x0, 5a64 <fwp_rc_dup+0x80>
    5a1c:	38626882 	ldrb	w2, [x4, x2]
    5a20:	7100085f 	cmp	w2, #0x2
    5a24:	54000220 	b.eq	5a68 <fwp_rc_dup+0x84>  // b.none
    5a28:	7100045f 	cmp	w2, #0x1
    5a2c:	540001c1 	b.ne	5a64 <fwp_rc_dup+0x80>  // b.any
    5a30:	29430864 	ldp	w4, w2, [x3, #24]
    5a34:	92403c21 	and	x1, x1, #0xffff
    5a38:	9b047c21 	mul	x1, x1, x4
    5a3c:	d360fc21 	lsr	x1, x1, #32
    5a40:	eb02003f 	cmp	x1, x2
    5a44:	54000102 	b.cs	5a64 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a48:	8b010000 	add	x0, x0, x1
    5a4c:	39400001 	ldrb	w1, [x0]
    5a50:	340000a1 	cbz	w1, 5a64 <fwp_rc_dup+0x80>
    5a54:	7103f43f 	cmp	w1, #0xfd
    5a58:	540000e8 	b.hi	5a74 <fwp_rc_dup+0x90>  // b.pmore
    5a5c:	11000421 	add	w1, w1, #0x1
    5a60:	39000001 	strb	w1, [x0]
    5a64:	d65f03c0 	ret
    5a68:	72003c3f 	tst	w1, #0xffff
    5a6c:	54ffff00 	b.eq	5a4c <fwp_rc_dup+0x68>  // b.none
    5a70:	d65f03c0 	ret
    5a74:	17fffa1c 	b	42e4 <fwp_rc_wide_dup>
    5a78:	d503201f 	nop
    5a7c:	d503201f 	nop

0000000000005a80 <fwp_owned_entry161>:
    5a80:	d10103ff 	sub	sp, sp, #0x40
    5a84:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5a88:	f947f442 	ldr	x2, [x2, #4072]
    5a8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a90:	910083fd 	add	x29, sp, #0x20
    5a94:	a90353f3 	stp	x19, x20, [sp, #48]
    5a98:	f9400043 	ldr	x3, [x2]
    5a9c:	f9000fe3 	str	x3, [sp, #24]
    5aa0:	d2800003 	mov	x3, #0x0                   	// #0
    5aa4:	a9400c01 	ldp	x1, x3, [x0]
    5aa8:	f9400802 	ldr	x2, [x0, #16]
    5aac:	ab020022 	adds	x2, x1, x2
    5ab0:	540006e6 	b.vs	5b8c <fwp_owned_entry161+0x10c>
    5ab4:	910023e1 	add	x1, sp, #0x8
    5ab8:	52800000 	mov	w0, #0x0                   	// #0
    5abc:	a9008be3 	stp	x3, x2, [sp, #8]
    5ac0:	97ffff0c 	bl	56f0 <fwp_data.part.0.constprop.0>
    5ac4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5ac8:	91154063 	add	x3, x3, #0x550
    5acc:	aa0003f3 	mov	x19, x0
    5ad0:	f949d861 	ldr	x1, [x3, #5040]
    5ad4:	f949ec60 	ldr	x0, [x3, #5080]
    5ad8:	cb010261 	sub	x1, x19, x1
    5adc:	eb00403f 	cmp	x1, x0, lsl #16
    5ae0:	54000322 	b.cs	5b44 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5ae4:	d350fc22 	lsr	x2, x1, #16
    5ae8:	f949fc63 	ldr	x3, [x3, #5112]
    5aec:	8b020842 	add	x2, x2, x2, lsl #2
    5af0:	d37df042 	lsl	x2, x2, #3
    5af4:	8b020060 	add	x0, x3, x2
    5af8:	f9401014 	ldr	x20, [x0, #32]
    5afc:	b4000254 	cbz	x20, 5b44 <fwp_owned_entry161+0xc4>
    5b00:	38626862 	ldrb	w2, [x3, x2]
    5b04:	7100085f 	cmp	w2, #0x2
    5b08:	54000360 	b.eq	5b74 <fwp_owned_entry161+0xf4>  // b.none
    5b0c:	7100045f 	cmp	w2, #0x1
    5b10:	540001a1 	b.ne	5b44 <fwp_owned_entry161+0xc4>  // b.any
    5b14:	29430002 	ldp	w2, w0, [x0, #24]
    5b18:	92403c21 	and	x1, x1, #0xffff
    5b1c:	9b027c21 	mul	x1, x1, x2
    5b20:	d360fc21 	lsr	x1, x1, #32
    5b24:	eb00003f 	cmp	x1, x0
    5b28:	540000e2 	b.cs	5b44 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5b2c:	8b010294 	add	x20, x20, x1
    5b30:	39400280 	ldrb	w0, [x20]
    5b34:	7103fc1f 	cmp	w0, #0xff
    5b38:	54000240 	b.eq	5b80 <fwp_owned_entry161+0x100>  // b.none
    5b3c:	52800020 	mov	w0, #0x1                   	// #1
    5b40:	39000280 	strb	w0, [x20]
    5b44:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5b48:	f947f400 	ldr	x0, [x0, #4072]
    5b4c:	f9400fe2 	ldr	x2, [sp, #24]
    5b50:	f9400001 	ldr	x1, [x0]
    5b54:	eb010042 	subs	x2, x2, x1
    5b58:	d2800001 	mov	x1, #0x0                   	// #0
    5b5c:	540001a1 	b.ne	5b90 <fwp_owned_entry161+0x110>  // b.any
    5b60:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b64:	aa1303e0 	mov	x0, x19
    5b68:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b6c:	910103ff 	add	sp, sp, #0x40
    5b70:	d65f03c0 	ret
    5b74:	72003c3f 	tst	w1, #0xffff
    5b78:	54fffe61 	b.ne	5b44 <fwp_owned_entry161+0xc4>  // b.any
    5b7c:	17ffffed 	b	5b30 <fwp_owned_entry161+0xb0>
    5b80:	aa1403e0 	mov	x0, x20
    5b84:	97fff8c3 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5b88:	17ffffed 	b	5b3c <fwp_owned_entry161+0xbc>
    5b8c:	97fff39d 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5b90:	97fff318 	bl	27f0 <__stack_chk_fail@plt>

0000000000005b94 <e161>:
    5b94:	d10103ff 	sub	sp, sp, #0x40
    5b98:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5b9c:	f947f442 	ldr	x2, [x2, #4072]
    5ba0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ba4:	910083fd 	add	x29, sp, #0x20
    5ba8:	a90353f3 	stp	x19, x20, [sp, #48]
    5bac:	f9400043 	ldr	x3, [x2]
    5bb0:	f9000fe3 	str	x3, [sp, #24]
    5bb4:	d2800003 	mov	x3, #0x0                   	// #0
    5bb8:	a9400c01 	ldp	x1, x3, [x0]
    5bbc:	f9400802 	ldr	x2, [x0, #16]
    5bc0:	ab020022 	adds	x2, x1, x2
    5bc4:	54000726 	b.vs	5ca8 <e161+0x114>
    5bc8:	910023e1 	add	x1, sp, #0x8
    5bcc:	52800000 	mov	w0, #0x0                   	// #0
    5bd0:	a9008be3 	stp	x3, x2, [sp, #8]
    5bd4:	97fffec7 	bl	56f0 <fwp_data.part.0.constprop.0>
    5bd8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5bdc:	91154063 	add	x3, x3, #0x550
    5be0:	aa0003f3 	mov	x19, x0
    5be4:	f949d861 	ldr	x1, [x3, #5040]
    5be8:	f949ec60 	ldr	x0, [x3, #5080]
    5bec:	cb010261 	sub	x1, x19, x1
    5bf0:	eb00403f 	cmp	x1, x0, lsl #16
    5bf4:	54000322 	b.cs	5c58 <e161+0xc4>  // b.hs, b.nlast
    5bf8:	d350fc22 	lsr	x2, x1, #16
    5bfc:	f949fc63 	ldr	x3, [x3, #5112]
    5c00:	8b020842 	add	x2, x2, x2, lsl #2
    5c04:	d37df042 	lsl	x2, x2, #3
    5c08:	8b020060 	add	x0, x3, x2
    5c0c:	f9401014 	ldr	x20, [x0, #32]
    5c10:	b4000254 	cbz	x20, 5c58 <e161+0xc4>
    5c14:	38626862 	ldrb	w2, [x3, x2]
    5c18:	7100085f 	cmp	w2, #0x2
    5c1c:	540003a0 	b.eq	5c90 <e161+0xfc>  // b.none
    5c20:	7100045f 	cmp	w2, #0x1
    5c24:	540001a1 	b.ne	5c58 <e161+0xc4>  // b.any
    5c28:	29430002 	ldp	w2, w0, [x0, #24]
    5c2c:	92403c21 	and	x1, x1, #0xffff
    5c30:	9b027c21 	mul	x1, x1, x2
    5c34:	d360fc21 	lsr	x1, x1, #32
    5c38:	eb00003f 	cmp	x1, x0
    5c3c:	540000e2 	b.cs	5c58 <e161+0xc4>  // b.hs, b.nlast
    5c40:	8b010294 	add	x20, x20, x1
    5c44:	39400280 	ldrb	w0, [x20]
    5c48:	7103fc1f 	cmp	w0, #0xff
    5c4c:	54000280 	b.eq	5c9c <e161+0x108>  // b.none
    5c50:	52800020 	mov	w0, #0x1                   	// #1
    5c54:	39000280 	strb	w0, [x20]
    5c58:	aa1303e0 	mov	x0, x19
    5c5c:	97fffeed 	bl	5810 <fwp_rc_share>
    5c60:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c64:	f947f400 	ldr	x0, [x0, #4072]
    5c68:	f9400fe2 	ldr	x2, [sp, #24]
    5c6c:	f9400001 	ldr	x1, [x0]
    5c70:	eb010042 	subs	x2, x2, x1
    5c74:	d2800001 	mov	x1, #0x0                   	// #0
    5c78:	540001a1 	b.ne	5cac <e161+0x118>  // b.any
    5c7c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c80:	aa1303e0 	mov	x0, x19
    5c84:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c88:	910103ff 	add	sp, sp, #0x40
    5c8c:	d65f03c0 	ret
    5c90:	72003c3f 	tst	w1, #0xffff
    5c94:	54fffe21 	b.ne	5c58 <e161+0xc4>  // b.any
    5c98:	17ffffeb 	b	5c44 <e161+0xb0>
    5c9c:	aa1403e0 	mov	x0, x20
    5ca0:	97fff87c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5ca4:	17ffffeb 	b	5c50 <e161+0xbc>
    5ca8:	97fff356 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5cac:	97fff2d1 	bl	27f0 <__stack_chk_fail@plt>

0000000000005cb0 <fwp_drop1>:
    5cb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5cb4:	910003fd 	mov	x29, sp
    5cb8:	a90153f3 	stp	x19, x20, [sp, #16]
    5cbc:	f90013f5 	str	x21, [sp, #32]
    5cc0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5cc4:	911542b4 	add	x20, x21, #0x550
    5cc8:	f949da81 	ldr	x1, [x20, #5040]
    5ccc:	f949ee82 	ldr	x2, [x20, #5080]
    5cd0:	cb010001 	sub	x1, x0, x1
    5cd4:	eb02403f 	cmp	x1, x2, lsl #16
    5cd8:	54000382 	b.cs	5d48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cdc:	d350fc22 	lsr	x2, x1, #16
    5ce0:	f949fe84 	ldr	x4, [x20, #5112]
    5ce4:	8b020842 	add	x2, x2, x2, lsl #2
    5ce8:	d37df042 	lsl	x2, x2, #3
    5cec:	8b020083 	add	x3, x4, x2
    5cf0:	f9401073 	ldr	x19, [x3, #32]
    5cf4:	b40002b3 	cbz	x19, 5d48 <fwp_drop1+0x98>
    5cf8:	38626882 	ldrb	w2, [x4, x2]
    5cfc:	7100085f 	cmp	w2, #0x2
    5d00:	540002c0 	b.eq	5d58 <fwp_drop1+0xa8>  // b.none
    5d04:	7100045f 	cmp	w2, #0x1
    5d08:	54000201 	b.ne	5d48 <fwp_drop1+0x98>  // b.any
    5d0c:	29430864 	ldp	w4, w2, [x3, #24]
    5d10:	92403c21 	and	x1, x1, #0xffff
    5d14:	9b047c21 	mul	x1, x1, x4
    5d18:	d360fc21 	lsr	x1, x1, #32
    5d1c:	eb02003f 	cmp	x1, x2
    5d20:	54000142 	b.cs	5d48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d24:	8b010273 	add	x19, x19, x1
    5d28:	39400261 	ldrb	w1, [x19]
    5d2c:	340000e1 	cbz	w1, 5d48 <fwp_drop1+0x98>
    5d30:	7100043f 	cmp	w1, #0x1
    5d34:	540001e0 	b.eq	5d70 <fwp_drop1+0xc0>  // b.none
    5d38:	7103fc3f 	cmp	w1, #0xff
    5d3c:	540002e0 	b.eq	5d98 <fwp_drop1+0xe8>  // b.none
    5d40:	51000421 	sub	w1, w1, #0x1
    5d44:	39000261 	strb	w1, [x19]
    5d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d4c:	f94013f5 	ldr	x21, [sp, #32]
    5d50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d54:	d65f03c0 	ret
    5d58:	72003c3f 	tst	w1, #0xffff
    5d5c:	54fffe60 	b.eq	5d28 <fwp_drop1+0x78>  // b.none
    5d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d64:	f94013f5 	ldr	x21, [sp, #32]
    5d68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d6c:	d65f03c0 	ret
    5d70:	f9400813 	ldr	x19, [x0, #16]
    5d74:	97fffefb 	bl	5960 <fwp_rc_free_arr>
    5d78:	911542a0 	add	x0, x21, #0x550
    5d7c:	f949d801 	ldr	x1, [x0, #5040]
    5d80:	f949ec00 	ldr	x0, [x0, #5080]
    5d84:	cb010261 	sub	x1, x19, x1
    5d88:	eb00403f 	cmp	x1, x0, lsl #16
    5d8c:	54fffde2 	b.cs	5d48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d90:	aa1303e0 	mov	x0, x19
    5d94:	17ffffd2 	b	5cdc <fwp_drop1+0x2c>
    5d98:	ca534660 	eor	x0, x19, x19, lsr #17
    5d9c:	911542b5 	add	x21, x21, #0x550
    5da0:	ca402400 	eor	x0, x0, x0, lsr #9
    5da4:	92401c00 	and	x0, x0, #0xff
    5da8:	910a2402 	add	x2, x0, #0x289
    5dac:	8b000ea0 	add	x0, x21, x0, lsl #3
    5db0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5db4:	f94a2400 	ldr	x0, [x0, #5192]
    5db8:	b50000a0 	cbnz	x0, 5dcc <fwp_drop1+0x11c>
    5dbc:	14000013 	b	5e08 <fwp_drop1+0x158>
    5dc0:	91004002 	add	x2, x0, #0x10
    5dc4:	f9400800 	ldr	x0, [x0, #16]
    5dc8:	b4000200 	cbz	x0, 5e08 <fwp_drop1+0x158>
    5dcc:	f9400001 	ldr	x1, [x0]
    5dd0:	eb13003f 	cmp	x1, x19
    5dd4:	54ffff61 	b.ne	5dc0 <fwp_drop1+0x110>  // b.any
    5dd8:	f9400041 	ldr	x1, [x2]
    5ddc:	f9400420 	ldr	x0, [x1, #8]
    5de0:	d1000400 	sub	x0, x0, #0x1
    5de4:	f9000420 	str	x0, [x1, #8]
    5de8:	f103f81f 	cmp	x0, #0xfe
    5dec:	54fffae1 	b.ne	5d48 <fwp_drop1+0x98>  // b.any
    5df0:	39400260 	ldrb	w0, [x19]
    5df4:	7103fc1f 	cmp	w0, #0xff
    5df8:	540000e0 	b.eq	5e14 <fwp_drop1+0x164>  // b.none
    5dfc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e00:	39000260 	strb	w0, [x19]
    5e04:	17ffffd1 	b	5d48 <fwp_drop1+0x98>
    5e08:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5e0c:	91208000 	add	x0, x0, #0x820
    5e10:	97fff800 	bl	3e10 <fwp_trap>
    5e14:	aa1303e0 	mov	x0, x19
    5e18:	97fff81e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5e1c:	17fffff8 	b	5dfc <fwp_drop1+0x14c>

0000000000005e20 <fwp_drop0>:
    5e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e24:	910003fd 	mov	x29, sp
    5e28:	a90153f3 	stp	x19, x20, [sp, #16]
    5e2c:	f90013f5 	str	x21, [sp, #32]
    5e30:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5e34:	911542b4 	add	x20, x21, #0x550
    5e38:	f949da81 	ldr	x1, [x20, #5040]
    5e3c:	f949ee82 	ldr	x2, [x20, #5080]
    5e40:	cb010001 	sub	x1, x0, x1
    5e44:	eb02403f 	cmp	x1, x2, lsl #16
    5e48:	54000382 	b.cs	5eb8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e4c:	d350fc22 	lsr	x2, x1, #16
    5e50:	f949fe84 	ldr	x4, [x20, #5112]
    5e54:	8b020842 	add	x2, x2, x2, lsl #2
    5e58:	d37df042 	lsl	x2, x2, #3
    5e5c:	8b020083 	add	x3, x4, x2
    5e60:	f9401073 	ldr	x19, [x3, #32]
    5e64:	b40002b3 	cbz	x19, 5eb8 <fwp_drop0+0x98>
    5e68:	38626882 	ldrb	w2, [x4, x2]
    5e6c:	7100085f 	cmp	w2, #0x2
    5e70:	540002c0 	b.eq	5ec8 <fwp_drop0+0xa8>  // b.none
    5e74:	7100045f 	cmp	w2, #0x1
    5e78:	54000201 	b.ne	5eb8 <fwp_drop0+0x98>  // b.any
    5e7c:	29430864 	ldp	w4, w2, [x3, #24]
    5e80:	92403c21 	and	x1, x1, #0xffff
    5e84:	9b047c21 	mul	x1, x1, x4
    5e88:	d360fc21 	lsr	x1, x1, #32
    5e8c:	eb02003f 	cmp	x1, x2
    5e90:	54000142 	b.cs	5eb8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e94:	8b010273 	add	x19, x19, x1
    5e98:	39400261 	ldrb	w1, [x19]
    5e9c:	340000e1 	cbz	w1, 5eb8 <fwp_drop0+0x98>
    5ea0:	7100043f 	cmp	w1, #0x1
    5ea4:	540001e0 	b.eq	5ee0 <fwp_drop0+0xc0>  // b.none
    5ea8:	7103fc3f 	cmp	w1, #0xff
    5eac:	540002e0 	b.eq	5f08 <fwp_drop0+0xe8>  // b.none
    5eb0:	51000421 	sub	w1, w1, #0x1
    5eb4:	39000261 	strb	w1, [x19]
    5eb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ebc:	f94013f5 	ldr	x21, [sp, #32]
    5ec0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ec4:	d65f03c0 	ret
    5ec8:	72003c3f 	tst	w1, #0xffff
    5ecc:	54fffe60 	b.eq	5e98 <fwp_drop0+0x78>  // b.none
    5ed0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ed4:	f94013f5 	ldr	x21, [sp, #32]
    5ed8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5edc:	d65f03c0 	ret
    5ee0:	f9400813 	ldr	x19, [x0, #16]
    5ee4:	97fffe9f 	bl	5960 <fwp_rc_free_arr>
    5ee8:	911542a0 	add	x0, x21, #0x550
    5eec:	f949d801 	ldr	x1, [x0, #5040]
    5ef0:	f949ec00 	ldr	x0, [x0, #5080]
    5ef4:	cb010261 	sub	x1, x19, x1
    5ef8:	eb00403f 	cmp	x1, x0, lsl #16
    5efc:	54fffde2 	b.cs	5eb8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f00:	aa1303e0 	mov	x0, x19
    5f04:	17ffffd2 	b	5e4c <fwp_drop0+0x2c>
    5f08:	ca534660 	eor	x0, x19, x19, lsr #17
    5f0c:	911542b5 	add	x21, x21, #0x550
    5f10:	ca402400 	eor	x0, x0, x0, lsr #9
    5f14:	92401c00 	and	x0, x0, #0xff
    5f18:	910a2402 	add	x2, x0, #0x289
    5f1c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5f20:	8b020ea2 	add	x2, x21, x2, lsl #3
    5f24:	f94a2400 	ldr	x0, [x0, #5192]
    5f28:	b50000a0 	cbnz	x0, 5f3c <fwp_drop0+0x11c>
    5f2c:	14000013 	b	5f78 <fwp_drop0+0x158>
    5f30:	91004002 	add	x2, x0, #0x10
    5f34:	f9400800 	ldr	x0, [x0, #16]
    5f38:	b4000200 	cbz	x0, 5f78 <fwp_drop0+0x158>
    5f3c:	f9400001 	ldr	x1, [x0]
    5f40:	eb13003f 	cmp	x1, x19
    5f44:	54ffff61 	b.ne	5f30 <fwp_drop0+0x110>  // b.any
    5f48:	f9400041 	ldr	x1, [x2]
    5f4c:	f9400420 	ldr	x0, [x1, #8]
    5f50:	d1000400 	sub	x0, x0, #0x1
    5f54:	f9000420 	str	x0, [x1, #8]
    5f58:	f103f81f 	cmp	x0, #0xfe
    5f5c:	54fffae1 	b.ne	5eb8 <fwp_drop0+0x98>  // b.any
    5f60:	39400260 	ldrb	w0, [x19]
    5f64:	7103fc1f 	cmp	w0, #0xff
    5f68:	540000e0 	b.eq	5f84 <fwp_drop0+0x164>  // b.none
    5f6c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f70:	39000260 	strb	w0, [x19]
    5f74:	17ffffd1 	b	5eb8 <fwp_drop0+0x98>
    5f78:	90000040 	adrp	x0, d000 <__divti3+0x40>
    5f7c:	91208000 	add	x0, x0, #0x820
    5f80:	97fff7a4 	bl	3e10 <fwp_trap>
    5f84:	aa1303e0 	mov	x0, x19
    5f88:	97fff7c2 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5f8c:	17fffff8 	b	5f6c <fwp_drop0+0x14c>

0000000000005f90 <fwp_arg_drop12>:
    5f90:	7100003f 	cmp	w1, #0x0
    5f94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5f98:	54000041 	b.ne	5fa0 <fwp_arg_drop12+0x10>  // b.any
    5f9c:	d65f03c0 	ret
    5fa0:	f9400000 	ldr	x0, [x0]
    5fa4:	17ffff9f 	b	5e20 <fwp_drop0>
    5fa8:	d503201f 	nop
    5fac:	d503201f 	nop

0000000000005fb0 <fwp_closure_drop>:
    5fb0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5fb4:	911540a4 	add	x4, x5, #0x550
    5fb8:	aa0003e1 	mov	x1, x0
    5fbc:	f949d882 	ldr	x2, [x4, #5040]
    5fc0:	f949ec80 	ldr	x0, [x4, #5080]
    5fc4:	cb020022 	sub	x2, x1, x2
    5fc8:	eb00405f 	cmp	x2, x0, lsl #16
    5fcc:	54000662 	b.cs	6098 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5fd4:	d350fc43 	lsr	x3, x2, #16
    5fd8:	910003fd 	mov	x29, sp
    5fdc:	8b030863 	add	x3, x3, x3, lsl #2
    5fe0:	f949fc84 	ldr	x4, [x4, #5112]
    5fe4:	d37df063 	lsl	x3, x3, #3
    5fe8:	f9000bf3 	str	x19, [sp, #16]
    5fec:	8b030080 	add	x0, x4, x3
    5ff0:	f9401013 	ldr	x19, [x0, #32]
    5ff4:	b40002b3 	cbz	x19, 6048 <fwp_closure_drop+0x98>
    5ff8:	38636883 	ldrb	w3, [x4, x3]
    5ffc:	7100087f 	cmp	w3, #0x2
    6000:	54000420 	b.eq	6084 <fwp_closure_drop+0xd4>  // b.none
    6004:	7100047f 	cmp	w3, #0x1
    6008:	54000201 	b.ne	6048 <fwp_closure_drop+0x98>  // b.any
    600c:	29430003 	ldp	w3, w0, [x0, #24]
    6010:	92403c42 	and	x2, x2, #0xffff
    6014:	9b037c42 	mul	x2, x2, x3
    6018:	d360fc42 	lsr	x2, x2, #32
    601c:	eb00005f 	cmp	x2, x0
    6020:	54000142 	b.cs	6048 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6024:	8b020273 	add	x19, x19, x2
    6028:	39400260 	ldrb	w0, [x19]
    602c:	340000e0 	cbz	w0, 6048 <fwp_closure_drop+0x98>
    6030:	7100041f 	cmp	w0, #0x1
    6034:	54000100 	b.eq	6054 <fwp_closure_drop+0xa4>  // b.none
    6038:	7103fc1f 	cmp	w0, #0xff
    603c:	54000300 	b.eq	609c <fwp_closure_drop+0xec>  // b.none
    6040:	51000400 	sub	w0, w0, #0x1
    6044:	39000260 	strb	w0, [x19]
    6048:	f9400bf3 	ldr	x19, [sp, #16]
    604c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6050:	d65f03c0 	ret
    6054:	d53bd040 	mrs	x0, tpidr_el0
    6058:	91400000 	add	x0, x0, #0x0, lsl #12
    605c:	91004000 	add	x0, x0, #0x10
    6060:	f9400000 	ldr	x0, [x0]
    6064:	b4000080 	cbz	x0, 6074 <fwp_closure_drop+0xc4>
    6068:	f9400bf3 	ldr	x19, [sp, #16]
    606c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6070:	17fff8e4 	b	4400 <fwp_closure_drop_push>
    6074:	f9400bf3 	ldr	x19, [sp, #16]
    6078:	aa0103e0 	mov	x0, x1
    607c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6080:	17fff925 	b	4514 <fwp_closure_drop.part.0>
    6084:	72003c5f 	tst	w2, #0xffff
    6088:	54fffd00 	b.eq	6028 <fwp_closure_drop+0x78>  // b.none
    608c:	f9400bf3 	ldr	x19, [sp, #16]
    6090:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6094:	d65f03c0 	ret
    6098:	d65f03c0 	ret
    609c:	ca534660 	eor	x0, x19, x19, lsr #17
    60a0:	911540a5 	add	x5, x5, #0x550
    60a4:	ca402400 	eor	x0, x0, x0, lsr #9
    60a8:	92401c00 	and	x0, x0, #0xff
    60ac:	910a2402 	add	x2, x0, #0x289
    60b0:	8b000ca0 	add	x0, x5, x0, lsl #3
    60b4:	8b020ca2 	add	x2, x5, x2, lsl #3
    60b8:	f94a2400 	ldr	x0, [x0, #5192]
    60bc:	b50000a0 	cbnz	x0, 60d0 <fwp_closure_drop+0x120>
    60c0:	14000013 	b	610c <fwp_closure_drop+0x15c>
    60c4:	91004002 	add	x2, x0, #0x10
    60c8:	f9400800 	ldr	x0, [x0, #16]
    60cc:	b4000200 	cbz	x0, 610c <fwp_closure_drop+0x15c>
    60d0:	f9400001 	ldr	x1, [x0]
    60d4:	eb13003f 	cmp	x1, x19
    60d8:	54ffff61 	b.ne	60c4 <fwp_closure_drop+0x114>  // b.any
    60dc:	f9400041 	ldr	x1, [x2]
    60e0:	f9400420 	ldr	x0, [x1, #8]
    60e4:	d1000400 	sub	x0, x0, #0x1
    60e8:	f9000420 	str	x0, [x1, #8]
    60ec:	f103f81f 	cmp	x0, #0xfe
    60f0:	54fffac1 	b.ne	6048 <fwp_closure_drop+0x98>  // b.any
    60f4:	39400260 	ldrb	w0, [x19]
    60f8:	7103fc1f 	cmp	w0, #0xff
    60fc:	540000e0 	b.eq	6118 <fwp_closure_drop+0x168>  // b.none
    6100:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6104:	39000260 	strb	w0, [x19]
    6108:	17ffffd0 	b	6048 <fwp_closure_drop+0x98>
    610c:	f0000020 	adrp	x0, d000 <__divti3+0x40>
    6110:	91208000 	add	x0, x0, #0x820
    6114:	97fff73f 	bl	3e10 <fwp_trap>
    6118:	aa1303e0 	mov	x0, x19
    611c:	97fff75d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6120:	17fffff8 	b	6100 <fwp_closure_drop+0x150>

0000000000006124 <fwp_owned_tape_release>:
    6124:	b4000920 	cbz	x0, 6248 <fwp_owned_tape_release+0x124>
    6128:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    612c:	910003fd 	mov	x29, sp
    6130:	a90153f3 	stp	x19, x20, [sp, #16]
    6134:	aa0003f3 	mov	x19, x0
    6138:	f9400000 	ldr	x0, [x0]
    613c:	b4000060 	cbz	x0, 6148 <fwp_owned_tape_release+0x24>
    6140:	f9400661 	ldr	x1, [x19, #8]
    6144:	f9000401 	str	x1, [x0, #8]
    6148:	f9400661 	ldr	x1, [x19, #8]
    614c:	b4000041 	cbz	x1, 6154 <fwp_owned_tape_release+0x30>
    6150:	f9000020 	str	x0, [x1]
    6154:	f9400a60 	ldr	x0, [x19, #16]
    6158:	f9403401 	ldr	x1, [x0, #104]
    615c:	b40005a1 	cbz	x1, 6210 <fwp_owned_tape_release+0xec>
    6160:	a9450a60 	ldp	x0, x2, [x19, #80]
    6164:	eb00005f 	cmp	x2, x0
    6168:	540002cd 	b.le	61c0 <fwp_owned_tape_release+0x9c>
    616c:	d2800014 	mov	x20, #0x0                   	// #0
    6170:	f90013f5 	str	x21, [sp, #32]
    6174:	d2800015 	mov	x21, #0x0                   	// #0
    6178:	f9402260 	ldr	x0, [x19, #64]
    617c:	910006b5 	add	x21, x21, #0x1
    6180:	f8746800 	ldr	x0, [x0, x20]
    6184:	d63f0020 	blr	x1
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	f9400a61 	ldr	x1, [x19, #16]
    6190:	8b140000 	add	x0, x0, x20
    6194:	91004294 	add	x20, x20, #0x10
    6198:	f9400400 	ldr	x0, [x0, #8]
    619c:	f9403421 	ldr	x1, [x1, #104]
    61a0:	d63f0020 	blr	x1
    61a4:	a9450261 	ldp	x1, x0, [x19, #80]
    61a8:	cb010000 	sub	x0, x0, x1
    61ac:	eb15001f 	cmp	x0, x21
    61b0:	f9400a60 	ldr	x0, [x19, #16]
    61b4:	f9403401 	ldr	x1, [x0, #104]
    61b8:	54fffe0c 	b.gt	6178 <fwp_owned_tape_release+0x54>
    61bc:	f94013f5 	ldr	x21, [sp, #32]
    61c0:	f9403663 	ldr	x3, [x19, #104]
    61c4:	f9401262 	ldr	x2, [x19, #32]
    61c8:	f100007f 	cmp	x3, #0x0
    61cc:	540001ed 	b.le	6208 <fwp_owned_tape_release+0xe4>
    61d0:	d2800014 	mov	x20, #0x0                   	// #0
    61d4:	d503201f 	nop
    61d8:	f9402660 	ldr	x0, [x19, #72]
    61dc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    61e0:	eb02001f 	cmp	x0, x2
    61e4:	540000c0 	b.eq	61fc <fwp_owned_tape_release+0xd8>  // b.none
    61e8:	d63f0020 	blr	x1
    61ec:	f9400a60 	ldr	x0, [x19, #16]
    61f0:	f9401262 	ldr	x2, [x19, #32]
    61f4:	f9403663 	ldr	x3, [x19, #104]
    61f8:	f9403401 	ldr	x1, [x0, #104]
    61fc:	91000694 	add	x20, x20, #0x1
    6200:	eb14007f 	cmp	x3, x20
    6204:	54fffeac 	b.gt	61d8 <fwp_owned_tape_release+0xb4>
    6208:	aa0203e0 	mov	x0, x2
    620c:	d63f0020 	blr	x1
    6210:	f9401660 	ldr	x0, [x19, #40]
    6214:	97ffff67 	bl	5fb0 <fwp_closure_drop>
    6218:	f9401a60 	ldr	x0, [x19, #48]
    621c:	97ffff65 	bl	5fb0 <fwp_closure_drop>
    6220:	f9401e60 	ldr	x0, [x19, #56]
    6224:	97ffff63 	bl	5fb0 <fwp_closure_drop>
    6228:	f9402260 	ldr	x0, [x19, #64]
    622c:	97fff7b5 	bl	4100 <fwp_mem_free>
    6230:	f9402660 	ldr	x0, [x19, #72]
    6234:	97fff7b3 	bl	4100 <fwp_mem_free>
    6238:	aa1303e0 	mov	x0, x19
    623c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6240:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6244:	17fff7af 	b	4100 <fwp_mem_free>
    6248:	d65f03c0 	ret
    624c:	d503201f 	nop

0000000000006250 <fwp_tape_finish>:
    6250:	d10203ff 	sub	sp, sp, #0x80
    6254:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6258:	f947f421 	ldr	x1, [x1, #4072]
    625c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6260:	910103fd 	add	x29, sp, #0x40
    6264:	a90553f3 	stp	x19, x20, [sp, #80]
    6268:	a9065bf5 	stp	x21, x22, [sp, #96]
    626c:	a90763f7 	stp	x23, x24, [sp, #112]
    6270:	d00000d8 	adrp	x24, 20000 <__data_start>
    6274:	91010316 	add	x22, x24, #0x40
    6278:	f9400022 	ldr	x2, [x1]
    627c:	f9001fe2 	str	x2, [sp, #56]
    6280:	d2800002 	mov	x2, #0x0                   	// #0
    6284:	9100e2c0 	add	x0, x22, #0x38
    6288:	97fff3fe 	bl	3280 <fwp_tape_buffers_dispose>
    628c:	f9003adf 	str	xzr, [x22, #112]
    6290:	f94042c0 	ldr	x0, [x22, #128]
    6294:	f100001f 	cmp	x0, #0x0
    6298:	5400030d 	b.le	62f8 <fwp_tape_finish+0xa8>
    629c:	910003f7 	mov	x23, sp
    62a0:	d2800015 	mov	x21, #0x0                   	// #0
    62a4:	d2800014 	mov	x20, #0x0                   	// #0
    62a8:	f94002d3 	ldr	x19, [x22]
    62ac:	91000694 	add	x20, x20, #0x1
    62b0:	8b150273 	add	x19, x19, x21
    62b4:	9101a2b5 	add	x21, x21, #0x68
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	97fff315 	bl	2f10 <fwp_tape_unlink_scope>
    62c0:	aa1703e0 	mov	x0, x23
    62c4:	f9401261 	ldr	x1, [x19, #32]
    62c8:	f90003e1 	str	x1, [sp]
    62cc:	f9401a62 	ldr	x2, [x19, #48]
    62d0:	f9000be2 	str	x2, [sp, #16]
    62d4:	f9402261 	ldr	x1, [x19, #64]
    62d8:	f90013e1 	str	x1, [sp, #32]
    62dc:	97fff3e9 	bl	3280 <fwp_tape_buffers_dispose>
    62e0:	f9403260 	ldr	x0, [x19, #96]
    62e4:	97ffff90 	bl	6124 <fwp_owned_tape_release>
    62e8:	f900327f 	str	xzr, [x19, #96]
    62ec:	f94042c0 	ldr	x0, [x22, #128]
    62f0:	eb14001f 	cmp	x0, x20
    62f4:	54fffdac 	b.gt	62a8 <fwp_tape_finish+0x58>
    62f8:	f9402300 	ldr	x0, [x24, #64]
    62fc:	91010313 	add	x19, x24, #0x40
    6300:	97fff16c 	bl	28b0 <free@plt>
    6304:	f900231f 	str	xzr, [x24, #64]
    6308:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    630c:	f947f400 	ldr	x0, [x0, #4072]
    6310:	f900427f 	str	xzr, [x19, #128]
    6314:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6318:	f9401fe2 	ldr	x2, [sp, #56]
    631c:	f9400001 	ldr	x1, [x0]
    6320:	eb010042 	subs	x2, x2, x1
    6324:	d2800001 	mov	x1, #0x0                   	// #0
    6328:	540000e1 	b.ne	6344 <fwp_tape_finish+0xf4>  // b.any
    632c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6330:	a94553f3 	ldp	x19, x20, [sp, #80]
    6334:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6338:	a94763f7 	ldp	x23, x24, [sp, #112]
    633c:	910203ff 	add	sp, sp, #0x80
    6340:	d65f03c0 	ret
    6344:	97fff12b 	bl	27f0 <__stack_chk_fail@plt>
    6348:	d503201f 	nop
    634c:	d503201f 	nop

0000000000006350 <fwp_tape_scope_release>:
    6350:	d10243ff 	sub	sp, sp, #0x90
    6354:	a9047bfd 	stp	x29, x30, [sp, #64]
    6358:	910103fd 	add	x29, sp, #0x40
    635c:	a90553f3 	stp	x19, x20, [sp, #80]
    6360:	aa0003f4 	mov	x20, x0
    6364:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6368:	f947f400 	ldr	x0, [x0, #4072]
    636c:	b9400285 	ldr	w5, [x20]
    6370:	f9400001 	ldr	x1, [x0]
    6374:	f9001fe1 	str	x1, [sp, #56]
    6378:	d2800001 	mov	x1, #0x0                   	// #0
    637c:	37f806c5 	tbnz	w5, #31, 6454 <fwp_tape_scope_release+0x104>
    6380:	a90763f7 	stp	x23, x24, [sp, #112]
    6384:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6388:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    638c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6390:	d00000d3 	adrp	x19, 20000 <__data_start>
    6394:	910003f7 	mov	x23, sp
    6398:	91010273 	add	x19, x19, #0x40
    639c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    63a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63a4:	52800d16 	mov	w22, #0x68                  	// #104
    63a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    63ac:	f90043f9 	str	x25, [sp, #128]
    63b0:	14000006 	b	63c8 <fwp_tape_scope_release+0x78>
    63b4:	97fff3b3 	bl	3280 <fwp_tape_buffers_dispose>
    63b8:	aa1903e0 	mov	x0, x25
    63bc:	97ffff5a 	bl	6124 <fwp_owned_tape_release>
    63c0:	b9400285 	ldr	w5, [x20]
    63c4:	37f80425 	tbnz	w5, #31, 6448 <fwp_tape_scope_release+0xf8>
    63c8:	f9400266 	ldr	x6, [x19]
    63cc:	9b367ca5 	smull	x5, w5, w22
    63d0:	8b0500c0 	add	x0, x6, x5
    63d4:	97fff2cf 	bl	2f10 <fwp_tape_unlink_scope>
    63d8:	ad410001 	ldp	q1, q0, [x0, #32]
    63dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    63e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    63e4:	f9400c03 	ldr	x3, [x0, #24]
    63e8:	ad0003e1 	stp	q1, q0, [sp]
    63ec:	b86568c1 	ldr	w1, [x6, x5]
    63f0:	a9440804 	ldp	x4, x2, [x0, #64]
    63f4:	b900041f 	str	wzr, [x0, #4]
    63f8:	f9403019 	ldr	x25, [x0, #96]
    63fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6400:	f9000c1f 	str	xzr, [x0, #24]
    6404:	a9020fe4 	stp	x4, x3, [sp, #32]
    6408:	f9001be2 	str	x2, [sp, #48]
    640c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6410:	f900301f 	str	xzr, [x0, #96]
    6414:	6b15003f 	cmp	w1, w21
    6418:	540000e8 	b.hi	6434 <fwp_tape_scope_release+0xe4>  // b.pmore
    641c:	9343fca5 	asr	x5, x5, #3
    6420:	f9404e60 	ldr	x0, [x19, #152]
    6424:	9b187ca5 	mul	x5, x5, x24
    6428:	eb0000bf 	cmp	x5, x0
    642c:	5400004a 	b.ge	6434 <fwp_tape_scope_release+0xe4>  // b.tcont
    6430:	f9004e65 	str	x5, [x19, #152]
    6434:	aa1703e0 	mov	x0, x23
    6438:	b5fffbf9 	cbnz	x25, 63b4 <fwp_tape_scope_release+0x64>
    643c:	97fff62d 	bl	3cf0 <fwp_tape_buffers_release>
    6440:	b9400285 	ldr	w5, [x20]
    6444:	36fffc25 	tbz	w5, #31, 63c8 <fwp_tape_scope_release+0x78>
    6448:	a9465bf5 	ldp	x21, x22, [sp, #96]
    644c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6450:	f94043f9 	ldr	x25, [sp, #128]
    6454:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6458:	f947f400 	ldr	x0, [x0, #4072]
    645c:	f9401fe2 	ldr	x2, [sp, #56]
    6460:	f9400001 	ldr	x1, [x0]
    6464:	eb010042 	subs	x2, x2, x1
    6468:	d2800001 	mov	x1, #0x0                   	// #0
    646c:	540000a1 	b.ne	6480 <fwp_tape_scope_release+0x130>  // b.any
    6470:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6474:	a94553f3 	ldp	x19, x20, [sp, #80]
    6478:	910243ff 	add	sp, sp, #0x90
    647c:	d65f03c0 	ret
    6480:	a9065bf5 	stp	x21, x22, [sp, #96]
    6484:	a90763f7 	stp	x23, x24, [sp, #112]
    6488:	f90043f9 	str	x25, [sp, #128]
    648c:	97fff0d9 	bl	27f0 <__stack_chk_fail@plt>

0000000000006490 <fwp_task_dispose>:
    6490:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6494:	910003fd 	mov	x29, sp
    6498:	f9000bf3 	str	x19, [sp, #16]
    649c:	aa0003f3 	mov	x19, x0
    64a0:	39414000 	ldrb	w0, [x0, #80]
    64a4:	36000720 	tbz	w0, #0, 6588 <fwp_task_dispose+0xf8>
    64a8:	f9400a60 	ldr	x0, [x19, #16]
    64ac:	b50006e0 	cbnz	x0, 6588 <fwp_task_dispose+0xf8>
    64b0:	a9478660 	ldp	x0, x1, [x19, #120]
    64b4:	39014e7f 	strb	wzr, [x19, #83]
    64b8:	f9003e7f 	str	xzr, [x19, #120]
    64bc:	f100003f 	cmp	x1, #0x0
    64c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64c4:	54000040 	b.eq	64cc <fwp_task_dispose+0x3c>  // b.none
    64c8:	d63f0020 	blr	x1
    64cc:	f9405660 	ldr	x0, [x19, #168]
    64d0:	97fff70c 	bl	4100 <fwp_mem_free>
    64d4:	f900567f 	str	xzr, [x19, #168]
    64d8:	b9405e60 	ldr	w0, [x19, #92]
    64dc:	7100041f 	cmp	w0, #0x1
    64e0:	54000420 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    64e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    64e8:	91154042 	add	x2, x2, #0x550
    64ec:	f949d840 	ldr	x0, [x2, #5040]
    64f0:	f949ec41 	ldr	x1, [x2, #5080]
    64f4:	cb000260 	sub	x0, x19, x0
    64f8:	eb01401f 	cmp	x0, x1, lsl #16
    64fc:	540002e2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6500:	d350fc01 	lsr	x1, x0, #16
    6504:	f949fc44 	ldr	x4, [x2, #5112]
    6508:	8b010821 	add	x1, x1, x1, lsl #2
    650c:	d37df021 	lsl	x1, x1, #3
    6510:	8b010083 	add	x3, x4, x1
    6514:	f9401062 	ldr	x2, [x3, #32]
    6518:	b4000202 	cbz	x2, 6558 <fwp_task_dispose+0xc8>
    651c:	38616881 	ldrb	w1, [x4, x1]
    6520:	7100083f 	cmp	w1, #0x2
    6524:	54000280 	b.eq	6574 <fwp_task_dispose+0xe4>  // b.none
    6528:	7100043f 	cmp	w1, #0x1
    652c:	54000161 	b.ne	6558 <fwp_task_dispose+0xc8>  // b.any
    6530:	29430464 	ldp	w4, w1, [x3, #24]
    6534:	92403c00 	and	x0, x0, #0xffff
    6538:	9b047c00 	mul	x0, x0, x4
    653c:	d360fc00 	lsr	x0, x0, #32
    6540:	eb01001f 	cmp	x0, x1
    6544:	540000a2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6548:	8b000042 	add	x2, x2, x0
    654c:	39400040 	ldrb	w0, [x2]
    6550:	7100041f 	cmp	w0, #0x1
    6554:	54000080 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    6558:	f9400bf3 	ldr	x19, [sp, #16]
    655c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6560:	d65f03c0 	ret
    6564:	aa1303e0 	mov	x0, x19
    6568:	f9400bf3 	ldr	x19, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	17fff6e4 	b	4100 <fwp_mem_free>
    6574:	72003c1f 	tst	w0, #0xffff
    6578:	54fffea0 	b.eq	654c <fwp_task_dispose+0xbc>  // b.none
    657c:	f9400bf3 	ldr	x19, [sp, #16]
    6580:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6584:	d65f03c0 	ret
    6588:	97fff0ae 	bl	2840 <abort@plt>
    658c:	d503201f 	nop

0000000000006590 <fwp_free_zombie>:
    6590:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6594:	910003fd 	mov	x29, sp
    6598:	a90153f3 	stp	x19, x20, [sp, #16]
    659c:	d00000d4 	adrp	x20, 20000 <__data_start>
    65a0:	91010281 	add	x1, x20, #0x40
    65a4:	f9405033 	ldr	x19, [x1, #160]
    65a8:	b4000333 	cbz	x19, 660c <fwp_free_zombie+0x7c>
    65ac:	f9400820 	ldr	x0, [x1, #16]
    65b0:	eb00027f 	cmp	x19, x0
    65b4:	540002c0 	b.eq	660c <fwp_free_zombie+0x7c>  // b.none
    65b8:	b940a822 	ldr	w2, [x1, #168]
    65bc:	f9400a60 	ldr	x0, [x19, #16]
    65c0:	7100fc5f 	cmp	w2, #0x3f
    65c4:	5400078c 	b.gt	66b4 <fwp_free_zombie+0x124>
    65c8:	9102c023 	add	x3, x1, #0xb0
    65cc:	11000444 	add	w4, w2, #0x1
    65d0:	b900a824 	str	w4, [x1, #168]
    65d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65dc:	a9530261 	ldp	x1, x0, [x19, #304]
    65e0:	b4000741 	cbz	x1, 66c8 <fwp_free_zombie+0x138>
    65e4:	f9009c20 	str	x0, [x1, #312]
    65e8:	b4000040 	cbz	x0, 65f0 <fwp_free_zombie+0x60>
    65ec:	f9009801 	str	x1, [x0, #304]
    65f0:	91010294 	add	x20, x20, #0x40
    65f4:	b9405e60 	ldr	w0, [x19, #92]
    65f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    65fc:	f900529f 	str	xzr, [x20, #160]
    6600:	34000140 	cbz	w0, 6628 <fwp_free_zombie+0x98>
    6604:	7100041f 	cmp	w0, #0x1
    6608:	54000080 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    660c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6614:	d65f03c0 	ret
    6618:	aa1303e0 	mov	x0, x19
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6624:	17ffff9b 	b	6490 <fwp_task_dispose>
    6628:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    662c:	91154082 	add	x2, x4, #0x550
    6630:	f949d841 	ldr	x1, [x2, #5040]
    6634:	f949ec40 	ldr	x0, [x2, #5080]
    6638:	cb010261 	sub	x1, x19, x1
    663c:	eb00403f 	cmp	x1, x0, lsl #16
    6640:	54fffe62 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6644:	d350fc20 	lsr	x0, x1, #16
    6648:	f949fc43 	ldr	x3, [x2, #5112]
    664c:	8b000800 	add	x0, x0, x0, lsl #2
    6650:	d37df000 	lsl	x0, x0, #3
    6654:	8b000062 	add	x2, x3, x0
    6658:	f9401054 	ldr	x20, [x2, #32]
    665c:	b4fffd94 	cbz	x20, 660c <fwp_free_zombie+0x7c>
    6660:	38606860 	ldrb	w0, [x3, x0]
    6664:	7100081f 	cmp	w0, #0x2
    6668:	54000360 	b.eq	66d4 <fwp_free_zombie+0x144>  // b.none
    666c:	7100041f 	cmp	w0, #0x1
    6670:	54fffce1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6674:	29430043 	ldp	w3, w0, [x2, #24]
    6678:	92403c21 	and	x1, x1, #0xffff
    667c:	9b037c21 	mul	x1, x1, x3
    6680:	d360fc21 	lsr	x1, x1, #32
    6684:	eb00003f 	cmp	x1, x0
    6688:	54fffc22 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    668c:	8b010294 	add	x20, x20, x1
    6690:	39400280 	ldrb	w0, [x20]
    6694:	34fffbc0 	cbz	w0, 660c <fwp_free_zombie+0x7c>
    6698:	7100041f 	cmp	w0, #0x1
    669c:	54fffbe0 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    66a0:	7103fc1f 	cmp	w0, #0xff
    66a4:	540001e0 	b.eq	66e0 <fwp_free_zombie+0x150>  // b.none
    66a8:	51000400 	sub	w0, w0, #0x1
    66ac:	39000280 	strb	w0, [x20]
    66b0:	17ffffd7 	b	660c <fwp_free_zombie+0x7c>
    66b4:	f9400e61 	ldr	x1, [x19, #24]
    66b8:	97fff096 	bl	2910 <munmap@plt>
    66bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66c0:	a9530261 	ldp	x1, x0, [x19, #304]
    66c4:	b5fff901 	cbnz	x1, 65e4 <fwp_free_zombie+0x54>
    66c8:	91010282 	add	x2, x20, #0x40
    66cc:	f9015840 	str	x0, [x2, #688]
    66d0:	17ffffc6 	b	65e8 <fwp_free_zombie+0x58>
    66d4:	72003c3f 	tst	w1, #0xffff
    66d8:	54fff9a1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    66dc:	17ffffed 	b	6690 <fwp_free_zombie+0x100>
    66e0:	ca544680 	eor	x0, x20, x20, lsr #17
    66e4:	91154084 	add	x4, x4, #0x550
    66e8:	ca402400 	eor	x0, x0, x0, lsr #9
    66ec:	92401c00 	and	x0, x0, #0xff
    66f0:	910a2402 	add	x2, x0, #0x289
    66f4:	8b000c80 	add	x0, x4, x0, lsl #3
    66f8:	8b020c82 	add	x2, x4, x2, lsl #3
    66fc:	f94a2400 	ldr	x0, [x0, #5192]
    6700:	b50000a0 	cbnz	x0, 6714 <fwp_free_zombie+0x184>
    6704:	14000013 	b	6750 <fwp_free_zombie+0x1c0>
    6708:	91004002 	add	x2, x0, #0x10
    670c:	f9400800 	ldr	x0, [x0, #16]
    6710:	b4000200 	cbz	x0, 6750 <fwp_free_zombie+0x1c0>
    6714:	f9400001 	ldr	x1, [x0]
    6718:	eb14003f 	cmp	x1, x20
    671c:	54ffff61 	b.ne	6708 <fwp_free_zombie+0x178>  // b.any
    6720:	f9400041 	ldr	x1, [x2]
    6724:	f9400420 	ldr	x0, [x1, #8]
    6728:	d1000400 	sub	x0, x0, #0x1
    672c:	f9000420 	str	x0, [x1, #8]
    6730:	f103f81f 	cmp	x0, #0xfe
    6734:	54fff6c1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6738:	39400280 	ldrb	w0, [x20]
    673c:	7103fc1f 	cmp	w0, #0xff
    6740:	540000e0 	b.eq	675c <fwp_free_zombie+0x1cc>  // b.none
    6744:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6748:	39000280 	strb	w0, [x20]
    674c:	17ffffb0 	b	660c <fwp_free_zombie+0x7c>
    6750:	f0000020 	adrp	x0, d000 <__divti3+0x40>
    6754:	91208000 	add	x0, x0, #0x820
    6758:	97fff5ae 	bl	3e10 <fwp_trap>
    675c:	aa1403e0 	mov	x0, x20
    6760:	97fff5cc 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6764:	17fffff8 	b	6744 <fwp_free_zombie+0x1b4>
    6768:	d503201f 	nop
    676c:	d503201f 	nop

0000000000006770 <fwp_block>:
    6770:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6774:	910003fd 	mov	x29, sp
    6778:	a90153f3 	stp	x19, x20, [sp, #16]
    677c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6780:	91010274 	add	x20, x19, #0x40
    6784:	f9401a82 	ldr	x2, [x20, #48]
    6788:	b4000642 	cbz	x2, 6850 <fwp_block+0xe0>
    678c:	91010261 	add	x1, x19, #0x40
    6790:	f9408040 	ldr	x0, [x2, #256]
    6794:	f9001820 	str	x0, [x1, #48]
    6798:	b40006a0 	cbz	x0, 686c <fwp_block+0xfc>
    679c:	d503201f 	nop
    67a0:	91010263 	add	x3, x19, #0x40
    67a4:	3901505f 	strb	wzr, [x2, #84]
    67a8:	f9400864 	ldr	x4, [x3, #16]
    67ac:	eb02009f 	cmp	x4, x2
    67b0:	54000440 	b.eq	6838 <fwp_block+0xc8>  // b.none
    67b4:	f9415c65 	ldr	x5, [x3, #696]
    67b8:	f9000862 	str	x2, [x3, #16]
    67bc:	f9400441 	ldr	x1, [x2, #8]
    67c0:	f9004885 	str	x5, [x4, #144]
    67c4:	f9416065 	ldr	x5, [x3, #704]
    67c8:	f9004c85 	str	x5, [x4, #152]
    67cc:	f9416465 	ldr	x5, [x3, #712]
    67d0:	f9005085 	str	x5, [x4, #160]
    67d4:	f9416865 	ldr	x5, [x3, #720]
    67d8:	f9005485 	str	x5, [x4, #168]
    67dc:	f9416c65 	ldr	x5, [x3, #728]
    67e0:	f9005885 	str	x5, [x4, #176]
    67e4:	f9417065 	ldr	x5, [x3, #736]
    67e8:	f9005c85 	str	x5, [x4, #184]
    67ec:	f9417465 	ldr	x5, [x3, #744]
    67f0:	f9006085 	str	x5, [x4, #192]
    67f4:	f9400480 	ldr	x0, [x4, #8]
    67f8:	f9404844 	ldr	x4, [x2, #144]
    67fc:	f9015c64 	str	x4, [x3, #696]
    6800:	f9404c44 	ldr	x4, [x2, #152]
    6804:	f9016064 	str	x4, [x3, #704]
    6808:	f9405044 	ldr	x4, [x2, #160]
    680c:	f9016464 	str	x4, [x3, #712]
    6810:	f9405444 	ldr	x4, [x2, #168]
    6814:	f9016864 	str	x4, [x3, #720]
    6818:	f9405844 	ldr	x4, [x2, #176]
    681c:	f9016c64 	str	x4, [x3, #728]
    6820:	a94b8844 	ldp	x4, x2, [x2, #184]
    6824:	f9017064 	str	x4, [x3, #736]
    6828:	f9017462 	str	x2, [x3, #744]
    682c:	97fff009 	bl	2850 <swapcontext@plt>
    6830:	97ffff58 	bl	6590 <fwp_free_zombie>
    6834:	d503201f 	nop
    6838:	91010260 	add	x0, x19, #0x40
    683c:	b942f000 	ldr	w0, [x0, #752]
    6840:	340001a0 	cbz	w0, 6874 <fwp_block+0x104>
    6844:	a94153f3 	ldp	x19, x20, [sp, #16]
    6848:	a8c27bfd 	ldp	x29, x30, [sp], #32
    684c:	d65f03c0 	ret
    6850:	97fff7b8 	bl	4730 <fwp_poll_events>
    6854:	f9401a82 	ldr	x2, [x20, #48]
    6858:	b4ffffc2 	cbz	x2, 6850 <fwp_block+0xe0>
    685c:	91010261 	add	x1, x19, #0x40
    6860:	f9408040 	ldr	x0, [x2, #256]
    6864:	f9001820 	str	x0, [x1, #48]
    6868:	b5fff9c0 	cbnz	x0, 67a0 <fwp_block+0x30>
    686c:	f900143f 	str	xzr, [x1, #40]
    6870:	17ffffcc 	b	67a0 <fwp_block+0x30>
    6874:	f0000020 	adrp	x0, d000 <__divti3+0x40>
    6878:	912ae000 	add	x0, x0, #0xab8
    687c:	97fff041 	bl	2980 <getenv@plt>
    6880:	5284e202 	mov	w2, #0x2710                	// #10000
    6884:	b4000060 	cbz	x0, 6890 <fwp_block+0x120>
    6888:	39400001 	ldrb	w1, [x0]
    688c:	350000c1 	cbnz	w1, 68a4 <fwp_block+0x134>
    6890:	91010273 	add	x19, x19, #0x40
    6894:	b902f262 	str	w2, [x19, #752]
    6898:	a94153f3 	ldp	x19, x20, [sp, #16]
    689c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a0:	d65f03c0 	ret
    68a4:	52800142 	mov	w2, #0xa                   	// #10
    68a8:	d2800001 	mov	x1, #0x0                   	// #0
    68ac:	97ffef85 	bl	26c0 <strtoll@plt>
    68b0:	d1000403 	sub	x3, x0, #0x1
    68b4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    68b8:	eb02007f 	cmp	x3, x2
    68bc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    68c0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    68c4:	17fffff3 	b	6890 <fwp_block+0x120>
    68c8:	d503201f 	nop
    68cc:	d503201f 	nop

00000000000068d0 <fwp_drop4>:
    68d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    68d4:	910003fd 	mov	x29, sp
    68d8:	a90153f3 	stp	x19, x20, [sp, #16]
    68dc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    68e0:	f90013f5 	str	x21, [sp, #32]
    68e4:	91154275 	add	x21, x19, #0x550
    68e8:	f949daa1 	ldr	x1, [x21, #5040]
    68ec:	f949eea2 	ldr	x2, [x21, #5080]
    68f0:	cb010001 	sub	x1, x0, x1
    68f4:	eb02403f 	cmp	x1, x2, lsl #16
    68f8:	54000382 	b.cs	6968 <fwp_drop4+0x98>  // b.hs, b.nlast
    68fc:	d350fc22 	lsr	x2, x1, #16
    6900:	f949fea3 	ldr	x3, [x21, #5112]
    6904:	8b020842 	add	x2, x2, x2, lsl #2
    6908:	d37df042 	lsl	x2, x2, #3
    690c:	8b020064 	add	x4, x3, x2
    6910:	f9401094 	ldr	x20, [x4, #32]
    6914:	b40002b4 	cbz	x20, 6968 <fwp_drop4+0x98>
    6918:	38626862 	ldrb	w2, [x3, x2]
    691c:	7100085f 	cmp	w2, #0x2
    6920:	540007a0 	b.eq	6a14 <fwp_drop4+0x144>  // b.none
    6924:	7100045f 	cmp	w2, #0x1
    6928:	54000201 	b.ne	6968 <fwp_drop4+0x98>  // b.any
    692c:	29430885 	ldp	w5, w2, [x4, #24]
    6930:	92403c21 	and	x1, x1, #0xffff
    6934:	9b057c21 	mul	x1, x1, x5
    6938:	d360fc21 	lsr	x1, x1, #32
    693c:	eb02003f 	cmp	x1, x2
    6940:	54000142 	b.cs	6968 <fwp_drop4+0x98>  // b.hs, b.nlast
    6944:	8b010294 	add	x20, x20, x1
    6948:	39400281 	ldrb	w1, [x20]
    694c:	340000e1 	cbz	w1, 6968 <fwp_drop4+0x98>
    6950:	7100043f 	cmp	w1, #0x1
    6954:	54000120 	b.eq	6978 <fwp_drop4+0xa8>  // b.none
    6958:	7103fc3f 	cmp	w1, #0xff
    695c:	540007c0 	b.eq	6a54 <fwp_drop4+0x184>  // b.none
    6960:	51000421 	sub	w1, w1, #0x1
    6964:	39000281 	strb	w1, [x20]
    6968:	a94153f3 	ldp	x19, x20, [sp, #16]
    696c:	f94013f5 	ldr	x21, [sp, #32]
    6970:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6974:	d65f03c0 	ret
    6978:	f9400001 	ldr	x1, [x0]
    697c:	b7f80581 	tbnz	x1, #63, 6a2c <fwp_drop4+0x15c>
    6980:	91154273 	add	x19, x19, #0x550
    6984:	f949da61 	ldr	x1, [x19, #5040]
    6988:	f949ee62 	ldr	x2, [x19, #5080]
    698c:	cb010001 	sub	x1, x0, x1
    6990:	eb02403f 	cmp	x1, x2, lsl #16
    6994:	54fffea2 	b.cs	6968 <fwp_drop4+0x98>  // b.hs, b.nlast
    6998:	d350fc22 	lsr	x2, x1, #16
    699c:	8b020842 	add	x2, x2, x2, lsl #2
    69a0:	d37df042 	lsl	x2, x2, #3
    69a4:	8b020065 	add	x5, x3, x2
    69a8:	f94010a4 	ldr	x4, [x5, #32]
    69ac:	b4fffde4 	cbz	x4, 6968 <fwp_drop4+0x98>
    69b0:	38626862 	ldrb	w2, [x3, x2]
    69b4:	7100085f 	cmp	w2, #0x2
    69b8:	54000220 	b.eq	69fc <fwp_drop4+0x12c>  // b.none
    69bc:	7100045f 	cmp	w2, #0x1
    69c0:	54fffd41 	b.ne	6968 <fwp_drop4+0x98>  // b.any
    69c4:	294308a3 	ldp	w3, w2, [x5, #24]
    69c8:	92403c21 	and	x1, x1, #0xffff
    69cc:	9b037c21 	mul	x1, x1, x3
    69d0:	d360fc21 	lsr	x1, x1, #32
    69d4:	eb02003f 	cmp	x1, x2
    69d8:	54fffc82 	b.cs	6968 <fwp_drop4+0x98>  // b.hs, b.nlast
    69dc:	8b010084 	add	x4, x4, x1
    69e0:	39400081 	ldrb	w1, [x4]
    69e4:	7100043f 	cmp	w1, #0x1
    69e8:	54fffc01 	b.ne	6968 <fwp_drop4+0x98>  // b.any
    69ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    69f0:	f94013f5 	ldr	x21, [sp, #32]
    69f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69f8:	17fff5c2 	b	4100 <fwp_mem_free>
    69fc:	72003c3f 	tst	w1, #0xffff
    6a00:	54ffff00 	b.eq	69e0 <fwp_drop4+0x110>  // b.none
    6a04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a08:	f94013f5 	ldr	x21, [sp, #32]
    6a0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a10:	d65f03c0 	ret
    6a14:	72003c3f 	tst	w1, #0xffff
    6a18:	54fff980 	b.eq	6948 <fwp_drop4+0x78>  // b.none
    6a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a20:	f94013f5 	ldr	x21, [sp, #32]
    6a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a28:	d65f03c0 	ret
    6a2c:	f9400414 	ldr	x20, [x0, #8]
    6a30:	97fffbcc 	bl	5960 <fwp_rc_free_arr>
    6a34:	91154260 	add	x0, x19, #0x550
    6a38:	f949d801 	ldr	x1, [x0, #5040]
    6a3c:	f949ec00 	ldr	x0, [x0, #5080]
    6a40:	cb010281 	sub	x1, x20, x1
    6a44:	eb00403f 	cmp	x1, x0, lsl #16
    6a48:	54fff902 	b.cs	6968 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a4c:	aa1403e0 	mov	x0, x20
    6a50:	17ffffab 	b	68fc <fwp_drop4+0x2c>
    6a54:	ca544680 	eor	x0, x20, x20, lsr #17
    6a58:	91154273 	add	x19, x19, #0x550
    6a5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a60:	92401c00 	and	x0, x0, #0xff
    6a64:	910a2402 	add	x2, x0, #0x289
    6a68:	8b000e60 	add	x0, x19, x0, lsl #3
    6a6c:	8b020e62 	add	x2, x19, x2, lsl #3
    6a70:	f94a2400 	ldr	x0, [x0, #5192]
    6a74:	b50000a0 	cbnz	x0, 6a88 <fwp_drop4+0x1b8>
    6a78:	14000013 	b	6ac4 <fwp_drop4+0x1f4>
    6a7c:	91004002 	add	x2, x0, #0x10
    6a80:	f9400800 	ldr	x0, [x0, #16]
    6a84:	b4000200 	cbz	x0, 6ac4 <fwp_drop4+0x1f4>
    6a88:	f9400001 	ldr	x1, [x0]
    6a8c:	eb14003f 	cmp	x1, x20
    6a90:	54ffff61 	b.ne	6a7c <fwp_drop4+0x1ac>  // b.any
    6a94:	f9400041 	ldr	x1, [x2]
    6a98:	f9400420 	ldr	x0, [x1, #8]
    6a9c:	d1000400 	sub	x0, x0, #0x1
    6aa0:	f9000420 	str	x0, [x1, #8]
    6aa4:	f103f81f 	cmp	x0, #0xfe
    6aa8:	54fff601 	b.ne	6968 <fwp_drop4+0x98>  // b.any
    6aac:	39400280 	ldrb	w0, [x20]
    6ab0:	7103fc1f 	cmp	w0, #0xff
    6ab4:	540000e0 	b.eq	6ad0 <fwp_drop4+0x200>  // b.none
    6ab8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6abc:	39000280 	strb	w0, [x20]
    6ac0:	17ffffaa 	b	6968 <fwp_drop4+0x98>
    6ac4:	f0000020 	adrp	x0, d000 <__divti3+0x40>
    6ac8:	91208000 	add	x0, x0, #0x820
    6acc:	97fff4d1 	bl	3e10 <fwp_trap>
    6ad0:	aa1403e0 	mov	x0, x20
    6ad4:	97fff4ef 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6ad8:	17fffff8 	b	6ab8 <fwp_drop4+0x1e8>
    6adc:	d503201f 	nop

0000000000006ae0 <fwp_caps161>:
    6ae0:	34000041 	cbz	w1, 6ae8 <fwp_caps161+0x8>
    6ae4:	d65f03c0 	ret
    6ae8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    6aec:	91154063 	add	x3, x3, #0x550
    6af0:	f949d861 	ldr	x1, [x3, #5040]
    6af4:	f949ec62 	ldr	x2, [x3, #5080]
    6af8:	cb010001 	sub	x1, x0, x1
    6afc:	eb02403f 	cmp	x1, x2, lsl #16
    6b00:	54ffff22 	b.cs	6ae4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b04:	d350fc22 	lsr	x2, x1, #16
    6b08:	f949fc65 	ldr	x5, [x3, #5112]
    6b0c:	8b020842 	add	x2, x2, x2, lsl #2
    6b10:	d37df042 	lsl	x2, x2, #3
    6b14:	8b0200a4 	add	x4, x5, x2
    6b18:	f9401083 	ldr	x3, [x4, #32]
    6b1c:	b4fffe43 	cbz	x3, 6ae4 <fwp_caps161+0x4>
    6b20:	386268a2 	ldrb	w2, [x5, x2]
    6b24:	7100085f 	cmp	w2, #0x2
    6b28:	540001c0 	b.eq	6b60 <fwp_caps161+0x80>  // b.none
    6b2c:	7100045f 	cmp	w2, #0x1
    6b30:	54fffda1 	b.ne	6ae4 <fwp_caps161+0x4>  // b.any
    6b34:	29430885 	ldp	w5, w2, [x4, #24]
    6b38:	92403c21 	and	x1, x1, #0xffff
    6b3c:	9b057c21 	mul	x1, x1, x5
    6b40:	d360fc21 	lsr	x1, x1, #32
    6b44:	eb02003f 	cmp	x1, x2
    6b48:	54fffce2 	b.cs	6ae4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b4c:	8b010063 	add	x3, x3, x1
    6b50:	39400061 	ldrb	w1, [x3]
    6b54:	7100043f 	cmp	w1, #0x1
    6b58:	54fffc61 	b.ne	6ae4 <fwp_caps161+0x4>  // b.any
    6b5c:	17fff569 	b	4100 <fwp_mem_free>
    6b60:	72003c3f 	tst	w1, #0xffff
    6b64:	54ffff60 	b.eq	6b50 <fwp_caps161+0x70>  // b.none
    6b68:	d65f03c0 	ret
    6b6c:	d503201f 	nop

0000000000006b70 <fwp_args12>:
    6b70:	7100003f 	cmp	w1, #0x0
    6b74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b78:	54000041 	b.ne	6b80 <fwp_args12+0x10>  // b.any
    6b7c:	d65f03c0 	ret
    6b80:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6b84:	91154042 	add	x2, x2, #0x550
    6b88:	f9400001 	ldr	x1, [x0]
    6b8c:	f949d843 	ldr	x3, [x2, #5040]
    6b90:	f949ec40 	ldr	x0, [x2, #5080]
    6b94:	cb030021 	sub	x1, x1, x3
    6b98:	eb00403f 	cmp	x1, x0, lsl #16
    6b9c:	54ffff02 	b.cs	6b7c <fwp_args12+0xc>  // b.hs, b.nlast
    6ba0:	d350fc20 	lsr	x0, x1, #16
    6ba4:	f949fc44 	ldr	x4, [x2, #5112]
    6ba8:	8b000800 	add	x0, x0, x0, lsl #2
    6bac:	d37df002 	lsl	x2, x0, #3
    6bb0:	8b020083 	add	x3, x4, x2
    6bb4:	f9401060 	ldr	x0, [x3, #32]
    6bb8:	b4fffe20 	cbz	x0, 6b7c <fwp_args12+0xc>
    6bbc:	38626882 	ldrb	w2, [x4, x2]
    6bc0:	7100085f 	cmp	w2, #0x2
    6bc4:	54000220 	b.eq	6c08 <fwp_args12+0x98>  // b.none
    6bc8:	7100045f 	cmp	w2, #0x1
    6bcc:	54fffd81 	b.ne	6b7c <fwp_args12+0xc>  // b.any
    6bd0:	29430864 	ldp	w4, w2, [x3, #24]
    6bd4:	92403c21 	and	x1, x1, #0xffff
    6bd8:	9b047c21 	mul	x1, x1, x4
    6bdc:	d360fc21 	lsr	x1, x1, #32
    6be0:	eb02003f 	cmp	x1, x2
    6be4:	54fffcc2 	b.cs	6b7c <fwp_args12+0xc>  // b.hs, b.nlast
    6be8:	8b010000 	add	x0, x0, x1
    6bec:	39400001 	ldrb	w1, [x0]
    6bf0:	34fffc61 	cbz	w1, 6b7c <fwp_args12+0xc>
    6bf4:	7103f43f 	cmp	w1, #0xfd
    6bf8:	540000e8 	b.hi	6c14 <fwp_args12+0xa4>  // b.pmore
    6bfc:	11000421 	add	w1, w1, #0x1
    6c00:	39000001 	strb	w1, [x0]
    6c04:	d65f03c0 	ret
    6c08:	72003c3f 	tst	w1, #0xffff
    6c0c:	54ffff00 	b.eq	6bec <fwp_args12+0x7c>  // b.none
    6c10:	d65f03c0 	ret
    6c14:	17fff5b4 	b	42e4 <fwp_rc_wide_dup>
    6c18:	d503201f 	nop
    6c1c:	d503201f 	nop

0000000000006c20 <fwp_args23>:
    6c20:	7100003f 	cmp	w1, #0x0
    6c24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c28:	54000041 	b.ne	6c30 <fwp_args23+0x10>  // b.any
    6c2c:	d65f03c0 	ret
    6c30:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6c34:	91154042 	add	x2, x2, #0x550
    6c38:	f9400001 	ldr	x1, [x0]
    6c3c:	f949d843 	ldr	x3, [x2, #5040]
    6c40:	f949ec40 	ldr	x0, [x2, #5080]
    6c44:	cb030021 	sub	x1, x1, x3
    6c48:	eb00403f 	cmp	x1, x0, lsl #16
    6c4c:	54ffff02 	b.cs	6c2c <fwp_args23+0xc>  // b.hs, b.nlast
    6c50:	d350fc20 	lsr	x0, x1, #16
    6c54:	f949fc44 	ldr	x4, [x2, #5112]
    6c58:	8b000800 	add	x0, x0, x0, lsl #2
    6c5c:	d37df002 	lsl	x2, x0, #3
    6c60:	8b020083 	add	x3, x4, x2
    6c64:	f9401060 	ldr	x0, [x3, #32]
    6c68:	b4fffe20 	cbz	x0, 6c2c <fwp_args23+0xc>
    6c6c:	38626882 	ldrb	w2, [x4, x2]
    6c70:	7100085f 	cmp	w2, #0x2
    6c74:	54000220 	b.eq	6cb8 <fwp_args23+0x98>  // b.none
    6c78:	7100045f 	cmp	w2, #0x1
    6c7c:	54fffd81 	b.ne	6c2c <fwp_args23+0xc>  // b.any
    6c80:	29430864 	ldp	w4, w2, [x3, #24]
    6c84:	92403c21 	and	x1, x1, #0xffff
    6c88:	9b047c21 	mul	x1, x1, x4
    6c8c:	d360fc21 	lsr	x1, x1, #32
    6c90:	eb02003f 	cmp	x1, x2
    6c94:	54fffcc2 	b.cs	6c2c <fwp_args23+0xc>  // b.hs, b.nlast
    6c98:	8b010000 	add	x0, x0, x1
    6c9c:	39400001 	ldrb	w1, [x0]
    6ca0:	34fffc61 	cbz	w1, 6c2c <fwp_args23+0xc>
    6ca4:	7103f43f 	cmp	w1, #0xfd
    6ca8:	540000e8 	b.hi	6cc4 <fwp_args23+0xa4>  // b.pmore
    6cac:	11000421 	add	w1, w1, #0x1
    6cb0:	39000001 	strb	w1, [x0]
    6cb4:	d65f03c0 	ret
    6cb8:	72003c3f 	tst	w1, #0xffff
    6cbc:	54ffff00 	b.eq	6c9c <fwp_args23+0x7c>  // b.none
    6cc0:	d65f03c0 	ret
    6cc4:	17fff588 	b	42e4 <fwp_rc_wide_dup>
    6cc8:	d503201f 	nop
    6ccc:	d503201f 	nop

0000000000006cd0 <fwp_caps12>:
    6cd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6cd4:	910003fd 	mov	x29, sp
    6cd8:	f9000bf3 	str	x19, [sp, #16]
    6cdc:	aa0003f3 	mov	x19, x0
    6ce0:	b9400400 	ldr	w0, [x0, #4]
    6ce4:	340004a0 	cbz	w0, 6d78 <fwp_caps12+0xa8>
    6ce8:	f9400660 	ldr	x0, [x19, #8]
    6cec:	350004e1 	cbnz	w1, 6d88 <fwp_caps12+0xb8>
    6cf0:	97fffc4c 	bl	5e20 <fwp_drop0>
    6cf4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6cf8:	91154042 	add	x2, x2, #0x550
    6cfc:	f949d840 	ldr	x0, [x2, #5040]
    6d00:	f949ec41 	ldr	x1, [x2, #5080]
    6d04:	cb000260 	sub	x0, x19, x0
    6d08:	eb01401f 	cmp	x0, x1, lsl #16
    6d0c:	54000382 	b.cs	6d7c <fwp_caps12+0xac>  // b.hs, b.nlast
    6d10:	d350fc01 	lsr	x1, x0, #16
    6d14:	f949fc44 	ldr	x4, [x2, #5112]
    6d18:	8b010821 	add	x1, x1, x1, lsl #2
    6d1c:	d37df021 	lsl	x1, x1, #3
    6d20:	8b010083 	add	x3, x4, x1
    6d24:	f9401062 	ldr	x2, [x3, #32]
    6d28:	b40002a2 	cbz	x2, 6d7c <fwp_caps12+0xac>
    6d2c:	38616881 	ldrb	w1, [x4, x1]
    6d30:	7100083f 	cmp	w1, #0x2
    6d34:	540006c0 	b.eq	6e0c <fwp_caps12+0x13c>  // b.none
    6d38:	7100043f 	cmp	w1, #0x1
    6d3c:	54000201 	b.ne	6d7c <fwp_caps12+0xac>  // b.any
    6d40:	29430464 	ldp	w4, w1, [x3, #24]
    6d44:	92403c00 	and	x0, x0, #0xffff
    6d48:	9b047c00 	mul	x0, x0, x4
    6d4c:	d360fc00 	lsr	x0, x0, #32
    6d50:	eb01001f 	cmp	x0, x1
    6d54:	54000142 	b.cs	6d7c <fwp_caps12+0xac>  // b.hs, b.nlast
    6d58:	8b000042 	add	x2, x2, x0
    6d5c:	39400040 	ldrb	w0, [x2]
    6d60:	7100041f 	cmp	w0, #0x1
    6d64:	540000c1 	b.ne	6d7c <fwp_caps12+0xac>  // b.any
    6d68:	aa1303e0 	mov	x0, x19
    6d6c:	f9400bf3 	ldr	x19, [sp, #16]
    6d70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d74:	17fff4e3 	b	4100 <fwp_mem_free>
    6d78:	34fffbe1 	cbz	w1, 6cf4 <fwp_caps12+0x24>
    6d7c:	f9400bf3 	ldr	x19, [sp, #16]
    6d80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d84:	d65f03c0 	ret
    6d88:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6d8c:	91154042 	add	x2, x2, #0x550
    6d90:	f949d843 	ldr	x3, [x2, #5040]
    6d94:	f949ec41 	ldr	x1, [x2, #5080]
    6d98:	cb030000 	sub	x0, x0, x3
    6d9c:	eb01401f 	cmp	x0, x1, lsl #16
    6da0:	54fffee2 	b.cs	6d7c <fwp_caps12+0xac>  // b.hs, b.nlast
    6da4:	d350fc01 	lsr	x1, x0, #16
    6da8:	f949fc44 	ldr	x4, [x2, #5112]
    6dac:	8b010821 	add	x1, x1, x1, lsl #2
    6db0:	d37df021 	lsl	x1, x1, #3
    6db4:	8b010083 	add	x3, x4, x1
    6db8:	f9401062 	ldr	x2, [x3, #32]
    6dbc:	b4fffe02 	cbz	x2, 6d7c <fwp_caps12+0xac>
    6dc0:	38616881 	ldrb	w1, [x4, x1]
    6dc4:	7100083f 	cmp	w1, #0x2
    6dc8:	54000280 	b.eq	6e18 <fwp_caps12+0x148>  // b.none
    6dcc:	7100043f 	cmp	w1, #0x1
    6dd0:	54fffd61 	b.ne	6d7c <fwp_caps12+0xac>  // b.any
    6dd4:	92403c01 	and	x1, x0, #0xffff
    6dd8:	29430064 	ldp	w4, w0, [x3, #24]
    6ddc:	9b047c21 	mul	x1, x1, x4
    6de0:	d360fc21 	lsr	x1, x1, #32
    6de4:	eb00003f 	cmp	x1, x0
    6de8:	54fffca2 	b.cs	6d7c <fwp_caps12+0xac>  // b.hs, b.nlast
    6dec:	8b010042 	add	x2, x2, x1
    6df0:	39400040 	ldrb	w0, [x2]
    6df4:	34fffc40 	cbz	w0, 6d7c <fwp_caps12+0xac>
    6df8:	7103f41f 	cmp	w0, #0xfd
    6dfc:	54000148 	b.hi	6e24 <fwp_caps12+0x154>  // b.pmore
    6e00:	11000400 	add	w0, w0, #0x1
    6e04:	39000040 	strb	w0, [x2]
    6e08:	17ffffdd 	b	6d7c <fwp_caps12+0xac>
    6e0c:	72003c1f 	tst	w0, #0xffff
    6e10:	54fffb61 	b.ne	6d7c <fwp_caps12+0xac>  // b.any
    6e14:	17ffffd2 	b	6d5c <fwp_caps12+0x8c>
    6e18:	72003c1f 	tst	w0, #0xffff
    6e1c:	54fffb01 	b.ne	6d7c <fwp_caps12+0xac>  // b.any
    6e20:	17fffff4 	b	6df0 <fwp_caps12+0x120>
    6e24:	f9400bf3 	ldr	x19, [sp, #16]
    6e28:	aa0203e0 	mov	x0, x2
    6e2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e30:	17fff52d 	b	42e4 <fwp_rc_wide_dup>

0000000000006e34 <fwp_drop2>:
    6e34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6e38:	910003fd 	mov	x29, sp
    6e3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6e40:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    6e44:	911542d5 	add	x21, x22, #0x550
    6e48:	a90153f3 	stp	x19, x20, [sp, #16]
    6e4c:	aa0003f3 	mov	x19, x0
    6e50:	f949daa1 	ldr	x1, [x21, #5040]
    6e54:	f949eea0 	ldr	x0, [x21, #5080]
    6e58:	cb010261 	sub	x1, x19, x1
    6e5c:	eb00403f 	cmp	x1, x0, lsl #16
    6e60:	54000382 	b.cs	6ed0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e64:	d350fc22 	lsr	x2, x1, #16
    6e68:	f949fea3 	ldr	x3, [x21, #5112]
    6e6c:	8b020842 	add	x2, x2, x2, lsl #2
    6e70:	d37df042 	lsl	x2, x2, #3
    6e74:	8b020060 	add	x0, x3, x2
    6e78:	f9401014 	ldr	x20, [x0, #32]
    6e7c:	b40002b4 	cbz	x20, 6ed0 <fwp_drop2+0x9c>
    6e80:	38626862 	ldrb	w2, [x3, x2]
    6e84:	7100085f 	cmp	w2, #0x2
    6e88:	540002c0 	b.eq	6ee0 <fwp_drop2+0xac>  // b.none
    6e8c:	7100045f 	cmp	w2, #0x1
    6e90:	54000201 	b.ne	6ed0 <fwp_drop2+0x9c>  // b.any
    6e94:	29430002 	ldp	w2, w0, [x0, #24]
    6e98:	92403c21 	and	x1, x1, #0xffff
    6e9c:	9b027c21 	mul	x1, x1, x2
    6ea0:	d360fc21 	lsr	x1, x1, #32
    6ea4:	eb00003f 	cmp	x1, x0
    6ea8:	54000142 	b.cs	6ed0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6eac:	8b010294 	add	x20, x20, x1
    6eb0:	39400280 	ldrb	w0, [x20]
    6eb4:	340000e0 	cbz	w0, 6ed0 <fwp_drop2+0x9c>
    6eb8:	7100041f 	cmp	w0, #0x1
    6ebc:	540001e0 	b.eq	6ef8 <fwp_drop2+0xc4>  // b.none
    6ec0:	7103fc1f 	cmp	w0, #0xff
    6ec4:	540007e0 	b.eq	6fc0 <fwp_drop2+0x18c>  // b.none
    6ec8:	51000400 	sub	w0, w0, #0x1
    6ecc:	39000280 	strb	w0, [x20]
    6ed0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ed4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ed8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6edc:	d65f03c0 	ret
    6ee0:	72003c3f 	tst	w1, #0xffff
    6ee4:	54fffe60 	b.eq	6eb0 <fwp_drop2+0x7c>  // b.none
    6ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6eec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ef0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ef4:	d65f03c0 	ret
    6ef8:	911542c2 	add	x2, x22, #0x550
    6efc:	f9400660 	ldr	x0, [x19, #8]
    6f00:	f949d841 	ldr	x1, [x2, #5040]
    6f04:	f949ec42 	ldr	x2, [x2, #5080]
    6f08:	cb010001 	sub	x1, x0, x1
    6f0c:	eb02403f 	cmp	x1, x2, lsl #16
    6f10:	54000382 	b.cs	6f80 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6f14:	d350fc22 	lsr	x2, x1, #16
    6f18:	8b020842 	add	x2, x2, x2, lsl #2
    6f1c:	d37df042 	lsl	x2, x2, #3
    6f20:	8b020064 	add	x4, x3, x2
    6f24:	f9401094 	ldr	x20, [x4, #32]
    6f28:	b40002d4 	cbz	x20, 6f80 <fwp_drop2+0x14c>
    6f2c:	38626862 	ldrb	w2, [x3, x2]
    6f30:	7100085f 	cmp	w2, #0x2
    6f34:	54000400 	b.eq	6fb4 <fwp_drop2+0x180>  // b.none
    6f38:	7100045f 	cmp	w2, #0x1
    6f3c:	54000221 	b.ne	6f80 <fwp_drop2+0x14c>  // b.any
    6f40:	29430883 	ldp	w3, w2, [x4, #24]
    6f44:	92403c21 	and	x1, x1, #0xffff
    6f48:	9b037c21 	mul	x1, x1, x3
    6f4c:	d360fc21 	lsr	x1, x1, #32
    6f50:	eb02003f 	cmp	x1, x2
    6f54:	54000162 	b.cs	6f80 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6f58:	8b010294 	add	x20, x20, x1
    6f5c:	39400281 	ldrb	w1, [x20]
    6f60:	34000101 	cbz	w1, 6f80 <fwp_drop2+0x14c>
    6f64:	7100043f 	cmp	w1, #0x1
    6f68:	54000220 	b.eq	6fac <fwp_drop2+0x178>  // b.none
    6f6c:	7103fc3f 	cmp	w1, #0xff
    6f70:	54000660 	b.eq	703c <fwp_drop2+0x208>  // b.none
    6f74:	51000421 	sub	w1, w1, #0x1
    6f78:	39000281 	strb	w1, [x20]
    6f7c:	d503201f 	nop
    6f80:	f9400a74 	ldr	x20, [x19, #16]
    6f84:	aa1303e0 	mov	x0, x19
    6f88:	97fffa76 	bl	5960 <fwp_rc_free_arr>
    6f8c:	911542c0 	add	x0, x22, #0x550
    6f90:	f949d801 	ldr	x1, [x0, #5040]
    6f94:	f949ec00 	ldr	x0, [x0, #5080]
    6f98:	cb010281 	sub	x1, x20, x1
    6f9c:	eb00403f 	cmp	x1, x0, lsl #16
    6fa0:	54fff982 	b.cs	6ed0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6fa4:	aa1403f3 	mov	x19, x20
    6fa8:	17ffffaf 	b	6e64 <fwp_drop2+0x30>
    6fac:	97fffa6d 	bl	5960 <fwp_rc_free_arr>
    6fb0:	17fffff4 	b	6f80 <fwp_drop2+0x14c>
    6fb4:	72003c3f 	tst	w1, #0xffff
    6fb8:	54fffe41 	b.ne	6f80 <fwp_drop2+0x14c>  // b.any
    6fbc:	17ffffe8 	b	6f5c <fwp_drop2+0x128>
    6fc0:	ca544681 	eor	x1, x20, x20, lsr #17
    6fc4:	911542c0 	add	x0, x22, #0x550
    6fc8:	ca412421 	eor	x1, x1, x1, lsr #9
    6fcc:	92401c21 	and	x1, x1, #0xff
    6fd0:	910a2422 	add	x2, x1, #0x289
    6fd4:	8b010c01 	add	x1, x0, x1, lsl #3
    6fd8:	8b020c02 	add	x2, x0, x2, lsl #3
    6fdc:	f94a2420 	ldr	x0, [x1, #5192]
    6fe0:	b50000a0 	cbnz	x0, 6ff4 <fwp_drop2+0x1c0>
    6fe4:	14000013 	b	7030 <fwp_drop2+0x1fc>
    6fe8:	91004002 	add	x2, x0, #0x10
    6fec:	f9400800 	ldr	x0, [x0, #16]
    6ff0:	b4000200 	cbz	x0, 7030 <fwp_drop2+0x1fc>
    6ff4:	f9400001 	ldr	x1, [x0]
    6ff8:	eb14003f 	cmp	x1, x20
    6ffc:	54ffff61 	b.ne	6fe8 <fwp_drop2+0x1b4>  // b.any
    7000:	f9400041 	ldr	x1, [x2]
    7004:	f9400420 	ldr	x0, [x1, #8]
    7008:	d1000400 	sub	x0, x0, #0x1
    700c:	f9000420 	str	x0, [x1, #8]
    7010:	f103f81f 	cmp	x0, #0xfe
    7014:	54fff5e1 	b.ne	6ed0 <fwp_drop2+0x9c>  // b.any
    7018:	39400280 	ldrb	w0, [x20]
    701c:	7103fc1f 	cmp	w0, #0xff
    7020:	54000460 	b.eq	70ac <fwp_drop2+0x278>  // b.none
    7024:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7028:	39000280 	strb	w0, [x20]
    702c:	17ffffa9 	b	6ed0 <fwp_drop2+0x9c>
    7030:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7034:	91208000 	add	x0, x0, #0x820
    7038:	97fff376 	bl	3e10 <fwp_trap>
    703c:	ca544680 	eor	x0, x20, x20, lsr #17
    7040:	911542c1 	add	x1, x22, #0x550
    7044:	ca402400 	eor	x0, x0, x0, lsr #9
    7048:	92401c00 	and	x0, x0, #0xff
    704c:	910a2402 	add	x2, x0, #0x289
    7050:	8b000c20 	add	x0, x1, x0, lsl #3
    7054:	8b020c22 	add	x2, x1, x2, lsl #3
    7058:	f94a2400 	ldr	x0, [x0, #5192]
    705c:	b50000a0 	cbnz	x0, 7070 <fwp_drop2+0x23c>
    7060:	17fffff4 	b	7030 <fwp_drop2+0x1fc>
    7064:	91004002 	add	x2, x0, #0x10
    7068:	f9400800 	ldr	x0, [x0, #16]
    706c:	b4fffe20 	cbz	x0, 7030 <fwp_drop2+0x1fc>
    7070:	f9400001 	ldr	x1, [x0]
    7074:	eb14003f 	cmp	x1, x20
    7078:	54ffff61 	b.ne	7064 <fwp_drop2+0x230>  // b.any
    707c:	f9400041 	ldr	x1, [x2]
    7080:	f9400420 	ldr	x0, [x1, #8]
    7084:	d1000400 	sub	x0, x0, #0x1
    7088:	f9000420 	str	x0, [x1, #8]
    708c:	f103f81f 	cmp	x0, #0xfe
    7090:	54fff781 	b.ne	6f80 <fwp_drop2+0x14c>  // b.any
    7094:	39400280 	ldrb	w0, [x20]
    7098:	7103fc1f 	cmp	w0, #0xff
    709c:	540000e0 	b.eq	70b8 <fwp_drop2+0x284>  // b.none
    70a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    70a4:	39000280 	strb	w0, [x20]
    70a8:	17ffffb6 	b	6f80 <fwp_drop2+0x14c>
    70ac:	aa1403e0 	mov	x0, x20
    70b0:	97fff378 	bl	3e90 <fwp_rc_forget_slot.part.0>
    70b4:	17ffffdc 	b	7024 <fwp_drop2+0x1f0>
    70b8:	aa1403e0 	mov	x0, x20
    70bc:	97fff375 	bl	3e90 <fwp_rc_forget_slot.part.0>
    70c0:	17fffff8 	b	70a0 <fwp_drop2+0x26c>

00000000000070c4 <fwp_arg_drop23>:
    70c4:	7100003f 	cmp	w1, #0x0
    70c8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70cc:	54000041 	b.ne	70d4 <fwp_arg_drop23+0x10>  // b.any
    70d0:	d65f03c0 	ret
    70d4:	f9400000 	ldr	x0, [x0]
    70d8:	17ffff57 	b	6e34 <fwp_drop2>
    70dc:	d503201f 	nop

00000000000070e0 <fwp_caps23>:
    70e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70e4:	910003fd 	mov	x29, sp
    70e8:	f9000bf3 	str	x19, [sp, #16]
    70ec:	aa0003f3 	mov	x19, x0
    70f0:	b9400400 	ldr	w0, [x0, #4]
    70f4:	340004a0 	cbz	w0, 7188 <fwp_caps23+0xa8>
    70f8:	f9400660 	ldr	x0, [x19, #8]
    70fc:	350004e1 	cbnz	w1, 7198 <fwp_caps23+0xb8>
    7100:	97ffff4d 	bl	6e34 <fwp_drop2>
    7104:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7108:	91154042 	add	x2, x2, #0x550
    710c:	f949d840 	ldr	x0, [x2, #5040]
    7110:	f949ec41 	ldr	x1, [x2, #5080]
    7114:	cb000260 	sub	x0, x19, x0
    7118:	eb01401f 	cmp	x0, x1, lsl #16
    711c:	54000382 	b.cs	718c <fwp_caps23+0xac>  // b.hs, b.nlast
    7120:	d350fc01 	lsr	x1, x0, #16
    7124:	f949fc44 	ldr	x4, [x2, #5112]
    7128:	8b010821 	add	x1, x1, x1, lsl #2
    712c:	d37df021 	lsl	x1, x1, #3
    7130:	8b010083 	add	x3, x4, x1
    7134:	f9401062 	ldr	x2, [x3, #32]
    7138:	b40002a2 	cbz	x2, 718c <fwp_caps23+0xac>
    713c:	38616881 	ldrb	w1, [x4, x1]
    7140:	7100083f 	cmp	w1, #0x2
    7144:	540006c0 	b.eq	721c <fwp_caps23+0x13c>  // b.none
    7148:	7100043f 	cmp	w1, #0x1
    714c:	54000201 	b.ne	718c <fwp_caps23+0xac>  // b.any
    7150:	29430464 	ldp	w4, w1, [x3, #24]
    7154:	92403c00 	and	x0, x0, #0xffff
    7158:	9b047c00 	mul	x0, x0, x4
    715c:	d360fc00 	lsr	x0, x0, #32
    7160:	eb01001f 	cmp	x0, x1
    7164:	54000142 	b.cs	718c <fwp_caps23+0xac>  // b.hs, b.nlast
    7168:	8b000042 	add	x2, x2, x0
    716c:	39400040 	ldrb	w0, [x2]
    7170:	7100041f 	cmp	w0, #0x1
    7174:	540000c1 	b.ne	718c <fwp_caps23+0xac>  // b.any
    7178:	aa1303e0 	mov	x0, x19
    717c:	f9400bf3 	ldr	x19, [sp, #16]
    7180:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7184:	17fff3df 	b	4100 <fwp_mem_free>
    7188:	34fffbe1 	cbz	w1, 7104 <fwp_caps23+0x24>
    718c:	f9400bf3 	ldr	x19, [sp, #16]
    7190:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7194:	d65f03c0 	ret
    7198:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    719c:	91154042 	add	x2, x2, #0x550
    71a0:	f949d843 	ldr	x3, [x2, #5040]
    71a4:	f949ec41 	ldr	x1, [x2, #5080]
    71a8:	cb030000 	sub	x0, x0, x3
    71ac:	eb01401f 	cmp	x0, x1, lsl #16
    71b0:	54fffee2 	b.cs	718c <fwp_caps23+0xac>  // b.hs, b.nlast
    71b4:	d350fc01 	lsr	x1, x0, #16
    71b8:	f949fc44 	ldr	x4, [x2, #5112]
    71bc:	8b010821 	add	x1, x1, x1, lsl #2
    71c0:	d37df021 	lsl	x1, x1, #3
    71c4:	8b010083 	add	x3, x4, x1
    71c8:	f9401062 	ldr	x2, [x3, #32]
    71cc:	b4fffe02 	cbz	x2, 718c <fwp_caps23+0xac>
    71d0:	38616881 	ldrb	w1, [x4, x1]
    71d4:	7100083f 	cmp	w1, #0x2
    71d8:	54000280 	b.eq	7228 <fwp_caps23+0x148>  // b.none
    71dc:	7100043f 	cmp	w1, #0x1
    71e0:	54fffd61 	b.ne	718c <fwp_caps23+0xac>  // b.any
    71e4:	92403c01 	and	x1, x0, #0xffff
    71e8:	29430064 	ldp	w4, w0, [x3, #24]
    71ec:	9b047c21 	mul	x1, x1, x4
    71f0:	d360fc21 	lsr	x1, x1, #32
    71f4:	eb00003f 	cmp	x1, x0
    71f8:	54fffca2 	b.cs	718c <fwp_caps23+0xac>  // b.hs, b.nlast
    71fc:	8b010042 	add	x2, x2, x1
    7200:	39400040 	ldrb	w0, [x2]
    7204:	34fffc40 	cbz	w0, 718c <fwp_caps23+0xac>
    7208:	7103f41f 	cmp	w0, #0xfd
    720c:	54000148 	b.hi	7234 <fwp_caps23+0x154>  // b.pmore
    7210:	11000400 	add	w0, w0, #0x1
    7214:	39000040 	strb	w0, [x2]
    7218:	17ffffdd 	b	718c <fwp_caps23+0xac>
    721c:	72003c1f 	tst	w0, #0xffff
    7220:	54fffb61 	b.ne	718c <fwp_caps23+0xac>  // b.any
    7224:	17ffffd2 	b	716c <fwp_caps23+0x8c>
    7228:	72003c1f 	tst	w0, #0xffff
    722c:	54fffb01 	b.ne	718c <fwp_caps23+0xac>  // b.any
    7230:	17fffff4 	b	7200 <fwp_caps23+0x120>
    7234:	f9400bf3 	ldr	x19, [sp, #16]
    7238:	aa0203e0 	mov	x0, x2
    723c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7240:	17fff429 	b	42e4 <fwp_rc_wide_dup>

0000000000007244 <f23>:
    7244:	d10203ff 	sub	sp, sp, #0x80
    7248:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    724c:	f947f421 	ldr	x1, [x1, #4072]
    7250:	a9027bfd 	stp	x29, x30, [sp, #32]
    7254:	910083fd 	add	x29, sp, #0x20
    7258:	a9045bf5 	stp	x21, x22, [sp, #64]
    725c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    7260:	911542a3 	add	x3, x21, #0x550
    7264:	a90353f3 	stp	x19, x20, [sp, #48]
    7268:	aa0003f6 	mov	x22, x0
    726c:	a90563f7 	stp	x23, x24, [sp, #80]
    7270:	a9066bf9 	stp	x25, x26, [sp, #96]
    7274:	f949ec62 	ldr	x2, [x3, #5080]
    7278:	f9400024 	ldr	x4, [x1]
    727c:	f9000fe4 	str	x4, [sp, #24]
    7280:	d2800004 	mov	x4, #0x0                   	// #0
    7284:	f949d861 	ldr	x1, [x3, #5040]
    7288:	d370bc42 	lsl	x2, x2, #16
    728c:	b4001800 	cbz	x0, 758c <f23+0x348>
    7290:	f9400817 	ldr	x23, [x0, #16]
    7294:	cb0102e1 	sub	x1, x23, x1
    7298:	eb02003f 	cmp	x1, x2
    729c:	54000362 	b.cs	7308 <f23+0xc4>  // b.hs, b.nlast
    72a0:	f949fc60 	ldr	x0, [x3, #5112]
    72a4:	d350fc22 	lsr	x2, x1, #16
    72a8:	8b020842 	add	x2, x2, x2, lsl #2
    72ac:	8b020c02 	add	x2, x0, x2, lsl #3
    72b0:	f9401040 	ldr	x0, [x2, #32]
    72b4:	b40002a0 	cbz	x0, 7308 <f23+0xc4>
    72b8:	39400043 	ldrb	w3, [x2]
    72bc:	7100087f 	cmp	w3, #0x2
    72c0:	54001540 	b.eq	7568 <f23+0x324>  // b.none
    72c4:	7100047f 	cmp	w3, #0x1
    72c8:	540001c1 	b.ne	7300 <f23+0xbc>  // b.any
    72cc:	29430843 	ldp	w3, w2, [x2, #24]
    72d0:	92403c21 	and	x1, x1, #0xffff
    72d4:	9b037c21 	mul	x1, x1, x3
    72d8:	d360fc21 	lsr	x1, x1, #32
    72dc:	eb02003f 	cmp	x1, x2
    72e0:	54000102 	b.cs	7300 <f23+0xbc>  // b.hs, b.nlast
    72e4:	8b010000 	add	x0, x0, x1
    72e8:	39400001 	ldrb	w1, [x0]
    72ec:	340000a1 	cbz	w1, 7300 <f23+0xbc>
    72f0:	7103f43f 	cmp	w1, #0xfd
    72f4:	540017e8 	b.hi	75f0 <f23+0x3ac>  // b.pmore
    72f8:	11000421 	add	w1, w1, #0x1
    72fc:	39000001 	strb	w1, [x0]
    7300:	d2800002 	mov	x2, #0x0                   	// #0
    7304:	b40000d6 	cbz	x22, 731c <f23+0xd8>
    7308:	aa1603e1 	mov	x1, x22
    730c:	d2800002 	mov	x2, #0x0                   	// #0
    7310:	f9400821 	ldr	x1, [x1, #16]
    7314:	91000442 	add	x2, x2, #0x1
    7318:	b5ffffc1 	cbnz	x1, 7310 <f23+0xcc>
    731c:	b40013f7 	cbz	x23, 7598 <f23+0x354>
    7320:	aa1703e1 	mov	x1, x23
    7324:	d2800003 	mov	x3, #0x0                   	// #0
    7328:	f9400821 	ldr	x1, [x1, #16]
    732c:	91000463 	add	x3, x3, #0x1
    7330:	b5ffffc1 	cbnz	x1, 7328 <f23+0xe4>
    7334:	eb02007f 	cmp	x3, x2
    7338:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    733c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7340:	eb00027f 	cmp	x19, x0
    7344:	540010a8 	b.hi	7558 <f23+0x314>  // b.pmore
    7348:	d37ffa74 	lsl	x20, x19, #1
    734c:	52800041 	mov	w1, #0x2                   	// #2
    7350:	91000680 	add	x0, x20, #0x1
    7354:	d37df000 	lsl	x0, x0, #3
    7358:	97fff626 	bl	4bf0 <fwp_heap_alloc>
    735c:	aa0003f8 	mov	x24, x0
    7360:	911542a1 	add	x1, x21, #0x550
    7364:	aa0103e0 	mov	x0, x1
    7368:	f9000314 	str	x20, [x24]
    736c:	f949d821 	ldr	x1, [x1, #5040]
    7370:	f949ec00 	ldr	x0, [x0, #5080]
    7374:	cb010301 	sub	x1, x24, x1
    7378:	eb00403f 	cmp	x1, x0, lsl #16
    737c:	54000342 	b.cs	73e4 <f23+0x1a0>  // b.hs, b.nlast
    7380:	911542a2 	add	x2, x21, #0x550
    7384:	d350fc20 	lsr	x0, x1, #16
    7388:	8b000800 	add	x0, x0, x0, lsl #2
    738c:	f949fc43 	ldr	x3, [x2, #5112]
    7390:	d37df002 	lsl	x2, x0, #3
    7394:	8b020060 	add	x0, x3, x2
    7398:	f9401014 	ldr	x20, [x0, #32]
    739c:	b4000254 	cbz	x20, 73e4 <f23+0x1a0>
    73a0:	38626862 	ldrb	w2, [x3, x2]
    73a4:	7100085f 	cmp	w2, #0x2
    73a8:	54000ec0 	b.eq	7580 <f23+0x33c>  // b.none
    73ac:	7100045f 	cmp	w2, #0x1
    73b0:	540001a1 	b.ne	73e4 <f23+0x1a0>  // b.any
    73b4:	29430002 	ldp	w2, w0, [x0, #24]
    73b8:	92403c21 	and	x1, x1, #0xffff
    73bc:	9b027c21 	mul	x1, x1, x2
    73c0:	d360fc21 	lsr	x1, x1, #32
    73c4:	eb00003f 	cmp	x1, x0
    73c8:	540000e2 	b.cs	73e4 <f23+0x1a0>  // b.hs, b.nlast
    73cc:	8b010294 	add	x20, x20, x1
    73d0:	39400280 	ldrb	w0, [x20]
    73d4:	7103fc1f 	cmp	w0, #0xff
    73d8:	54001100 	b.eq	75f8 <f23+0x3b4>  // b.none
    73dc:	52800020 	mov	w0, #0x1                   	// #1
    73e0:	39000280 	strb	w0, [x20]
    73e4:	b4000253 	cbz	x19, 742c <f23+0x1e8>
    73e8:	8b131313 	add	x19, x24, x19, lsl #4
    73ec:	aa1803f4 	mov	x20, x24
    73f0:	aa1603fa 	mov	x26, x22
    73f4:	aa1703f9 	mov	x25, x23
    73f8:	f9400723 	ldr	x3, [x25, #8]
    73fc:	f9400742 	ldr	x2, [x26, #8]
    7400:	f9400861 	ldr	x1, [x3, #16]
    7404:	f9400840 	ldr	x0, [x2, #16]
    7408:	fd400461 	ldr	d1, [x3, #8]
    740c:	fd400440 	ldr	d0, [x2, #8]
    7410:	97fff7a5 	bl	52a4 <w107>
    7414:	f9000680 	str	x0, [x20, #8]
    7418:	f8010e81 	str	x1, [x20, #16]!
    741c:	f9400b39 	ldr	x25, [x25, #16]
    7420:	f9400b5a 	ldr	x26, [x26, #16]
    7424:	eb14027f 	cmp	x19, x20
    7428:	54fffe81 	b.ne	73f8 <f23+0x1b4>  // b.any
    742c:	aa1703e0 	mov	x0, x23
    7430:	97fffe81 	bl	6e34 <fwp_drop2>
    7434:	aa1603e0 	mov	x0, x22
    7438:	97fffe7f 	bl	6e34 <fwp_drop2>
    743c:	f9400316 	ldr	x22, [x24]
    7440:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7444:	b4000236 	cbz	x22, 7488 <f23+0x244>
    7448:	fd003be8 	str	d8, [sp, #112]
    744c:	2f00e408 	movi	d8, #0x0
    7450:	91002319 	add	x25, x24, #0x8
    7454:	91004317 	add	x23, x24, #0x10
    7458:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    745c:	d2800013 	mov	x19, #0x0                   	// #0
    7460:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7464:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7468:	91000a73 	add	x19, x19, #0x2
    746c:	1e602908 	fadd	d8, d8, d0
    7470:	97fff73c 	bl	5160 <f128.constprop.0>
    7474:	aa0003f4 	mov	x20, x0
    7478:	eb1302df 	cmp	x22, x19
    747c:	54ffff28 	b.hi	7460 <f23+0x21c>  // b.pmore
    7480:	9e660116 	fmov	x22, d8
    7484:	fd403be8 	ldr	d8, [sp, #112]
    7488:	911542b5 	add	x21, x21, #0x550
    748c:	aa1803e0 	mov	x0, x24
    7490:	97fffd10 	bl	68d0 <fwp_drop4>
    7494:	a900d3f6 	stp	x22, x20, [sp, #8]
    7498:	910023e1 	add	x1, sp, #0x8
    749c:	52800000 	mov	w0, #0x0                   	// #0
    74a0:	97fff894 	bl	56f0 <fwp_data.part.0.constprop.0>
    74a4:	f949daa1 	ldr	x1, [x21, #5040]
    74a8:	aa0003f3 	mov	x19, x0
    74ac:	f949eea0 	ldr	x0, [x21, #5080]
    74b0:	cb010261 	sub	x1, x19, x1
    74b4:	eb00403f 	cmp	x1, x0, lsl #16
    74b8:	54000322 	b.cs	751c <f23+0x2d8>  // b.hs, b.nlast
    74bc:	d350fc22 	lsr	x2, x1, #16
    74c0:	f949fea3 	ldr	x3, [x21, #5112]
    74c4:	8b020842 	add	x2, x2, x2, lsl #2
    74c8:	d37df042 	lsl	x2, x2, #3
    74cc:	8b020060 	add	x0, x3, x2
    74d0:	f9401014 	ldr	x20, [x0, #32]
    74d4:	b4000254 	cbz	x20, 751c <f23+0x2d8>
    74d8:	38626862 	ldrb	w2, [x3, x2]
    74dc:	7100085f 	cmp	w2, #0x2
    74e0:	540004a0 	b.eq	7574 <f23+0x330>  // b.none
    74e4:	7100045f 	cmp	w2, #0x1
    74e8:	540001a1 	b.ne	751c <f23+0x2d8>  // b.any
    74ec:	29430002 	ldp	w2, w0, [x0, #24]
    74f0:	92403c21 	and	x1, x1, #0xffff
    74f4:	9b027c21 	mul	x1, x1, x2
    74f8:	d360fc21 	lsr	x1, x1, #32
    74fc:	eb00003f 	cmp	x1, x0
    7500:	540000e2 	b.cs	751c <f23+0x2d8>  // b.hs, b.nlast
    7504:	8b010294 	add	x20, x20, x1
    7508:	39400280 	ldrb	w0, [x20]
    750c:	7103fc1f 	cmp	w0, #0xff
    7510:	540007a0 	b.eq	7604 <f23+0x3c0>  // b.none
    7514:	52800020 	mov	w0, #0x1                   	// #1
    7518:	39000280 	strb	w0, [x20]
    751c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7520:	f947f400 	ldr	x0, [x0, #4072]
    7524:	f9400fe2 	ldr	x2, [sp, #24]
    7528:	f9400001 	ldr	x1, [x0]
    752c:	eb010042 	subs	x2, x2, x1
    7530:	d2800001 	mov	x1, #0x0                   	// #0
    7534:	54000721 	b.ne	7618 <f23+0x3d4>  // b.any
    7538:	a9427bfd 	ldp	x29, x30, [sp, #32]
    753c:	aa1303e0 	mov	x0, x19
    7540:	a94353f3 	ldp	x19, x20, [sp, #48]
    7544:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7548:	a94563f7 	ldp	x23, x24, [sp, #80]
    754c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7550:	910203ff 	add	sp, sp, #0x80
    7554:	d65f03c0 	ret
    7558:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    755c:	912b2000 	add	x0, x0, #0xac8
    7560:	fd003be8 	str	d8, [sp, #112]
    7564:	97fff22b 	bl	3e10 <fwp_trap>
    7568:	72003c3f 	tst	w1, #0xffff
    756c:	54ffeca1 	b.ne	7300 <f23+0xbc>  // b.any
    7570:	17ffff5e 	b	72e8 <f23+0xa4>
    7574:	72003c3f 	tst	w1, #0xffff
    7578:	54fffd21 	b.ne	751c <f23+0x2d8>  // b.any
    757c:	17ffffe3 	b	7508 <f23+0x2c4>
    7580:	72003c3f 	tst	w1, #0xffff
    7584:	54fff301 	b.ne	73e4 <f23+0x1a0>  // b.any
    7588:	17ffff92 	b	73d0 <f23+0x18c>
    758c:	cb0103e1 	neg	x1, x1
    7590:	eb02003f 	cmp	x1, x2
    7594:	540001e3 	b.cc	75d0 <f23+0x38c>  // b.lo, b.ul, b.last
    7598:	52800041 	mov	w1, #0x2                   	// #2
    759c:	d2800100 	mov	x0, #0x8                   	// #8
    75a0:	97fff594 	bl	4bf0 <fwp_heap_alloc>
    75a4:	aa0003f8 	mov	x24, x0
    75a8:	911542a0 	add	x0, x21, #0x550
    75ac:	f900031f 	str	xzr, [x24]
    75b0:	f949d801 	ldr	x1, [x0, #5040]
    75b4:	f949ec00 	ldr	x0, [x0, #5080]
    75b8:	cb010301 	sub	x1, x24, x1
    75bc:	eb00403f 	cmp	x1, x0, lsl #16
    75c0:	54000282 	b.cs	7610 <f23+0x3cc>  // b.hs, b.nlast
    75c4:	d2800013 	mov	x19, #0x0                   	// #0
    75c8:	d2800017 	mov	x23, #0x0                   	// #0
    75cc:	17ffff6d 	b	7380 <f23+0x13c>
    75d0:	f949fc62 	ldr	x2, [x3, #5112]
    75d4:	d350fc20 	lsr	x0, x1, #16
    75d8:	8b000800 	add	x0, x0, x0, lsl #2
    75dc:	8b000c42 	add	x2, x2, x0, lsl #3
    75e0:	f9401040 	ldr	x0, [x2, #32]
    75e4:	b4fffda0 	cbz	x0, 7598 <f23+0x354>
    75e8:	d2800017 	mov	x23, #0x0                   	// #0
    75ec:	17ffff33 	b	72b8 <f23+0x74>
    75f0:	97fff33d 	bl	42e4 <fwp_rc_wide_dup>
    75f4:	17ffff43 	b	7300 <f23+0xbc>
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	97fff225 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7600:	17ffff77 	b	73dc <f23+0x198>
    7604:	aa1403e0 	mov	x0, x20
    7608:	97fff222 	bl	3e90 <fwp_rc_forget_slot.part.0>
    760c:	17ffffc2 	b	7514 <f23+0x2d0>
    7610:	d2800017 	mov	x23, #0x0                   	// #0
    7614:	17ffff86 	b	742c <f23+0x1e8>
    7618:	fd003be8 	str	d8, [sp, #112]
    761c:	97ffec75 	bl	27f0 <__stack_chk_fail@plt>

0000000000007620 <fwp_owned_entry23>:
    7620:	f9400000 	ldr	x0, [x0]
    7624:	17ffff08 	b	7244 <f23>
    7628:	d503201f 	nop
    762c:	d503201f 	nop

0000000000007630 <e23>:
    7630:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7634:	910003fd 	mov	x29, sp
    7638:	f9000bf3 	str	x19, [sp, #16]
    763c:	f9400013 	ldr	x19, [x0]
    7640:	aa1303e0 	mov	x0, x19
    7644:	97fff873 	bl	5810 <fwp_rc_share>
    7648:	aa1303e0 	mov	x0, x19
    764c:	97fffefe 	bl	7244 <f23>
    7650:	aa0003f3 	mov	x19, x0
    7654:	97fff86f 	bl	5810 <fwp_rc_share>
    7658:	aa1303e0 	mov	x0, x19
    765c:	f9400bf3 	ldr	x19, [sp, #16]
    7660:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7664:	d65f03c0 	ret
    7668:	d503201f 	nop
    766c:	d503201f 	nop

0000000000007670 <f12>:
    7670:	d10483ff 	sub	sp, sp, #0x120
    7674:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7678:	f947f442 	ldr	x2, [x2, #4072]
    767c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7680:	910303fd 	add	x29, sp, #0xc0
    7684:	a90f63f7 	stp	x23, x24, [sp, #240]
    7688:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    768c:	911542e3 	add	x3, x23, #0x550
    7690:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7694:	b00000d6 	adrp	x22, 20000 <__data_start>
    7698:	910102c4 	add	x4, x22, #0x40
    769c:	f949d861 	ldr	x1, [x3, #5040]
    76a0:	a90d53f3 	stp	x19, x20, [sp, #208]
    76a4:	b00000d3 	adrp	x19, 20000 <__data_start>
    76a8:	f949ec65 	ldr	x5, [x3, #5080]
    76ac:	a9106bf9 	stp	x25, x26, [sp, #256]
    76b0:	91004273 	add	x19, x19, #0x10
    76b4:	a91173fb 	stp	x27, x28, [sp, #272]
    76b8:	910103f9 	add	x25, sp, #0x40
    76bc:	9100e3f8 	add	x24, sp, #0x38
    76c0:	f9416086 	ldr	x6, [x4, #704]
    76c4:	f9400047 	ldr	x7, [x2]
    76c8:	f9005fe7 	str	x7, [sp, #184]
    76cc:	d2800007 	mov	x7, #0x0                   	// #0
    76d0:	f0fffff5 	adrp	x21, 6000 <fwp_closure_drop+0x50>
    76d4:	12800007 	mov	w7, #0xffffffff            	// #-1
    76d8:	910d42a2 	add	x2, x21, #0x350
    76dc:	cb010261 	sub	x1, x19, x1
    76e0:	b9003be7 	str	w7, [sp, #56]
    76e4:	aa0003f4 	mov	x20, x0
    76e8:	a9040be6 	stp	x6, x2, [sp, #64]
    76ec:	f9002bf8 	str	x24, [sp, #80]
    76f0:	f9016099 	str	x25, [x4, #704]
    76f4:	eb05403f 	cmp	x1, x5, lsl #16
    76f8:	54000342 	b.cs	7760 <f12+0xf0>  // b.hs, b.nlast
    76fc:	d350fc20 	lsr	x0, x1, #16
    7700:	f949fc64 	ldr	x4, [x3, #5112]
    7704:	8b000800 	add	x0, x0, x0, lsl #2
    7708:	d37df002 	lsl	x2, x0, #3
    770c:	8b020083 	add	x3, x4, x2
    7710:	f9401060 	ldr	x0, [x3, #32]
    7714:	b4000260 	cbz	x0, 7760 <f12+0xf0>
    7718:	38626882 	ldrb	w2, [x4, x2]
    771c:	7100085f 	cmp	w2, #0x2
    7720:	54000b60 	b.eq	788c <f12+0x21c>  // b.none
    7724:	7100045f 	cmp	w2, #0x1
    7728:	540001c1 	b.ne	7760 <f12+0xf0>  // b.any
    772c:	29430864 	ldp	w4, w2, [x3, #24]
    7730:	92403c21 	and	x1, x1, #0xffff
    7734:	9b047c21 	mul	x1, x1, x4
    7738:	d360fc21 	lsr	x1, x1, #32
    773c:	eb02003f 	cmp	x1, x2
    7740:	54000102 	b.cs	7760 <f12+0xf0>  // b.hs, b.nlast
    7744:	8b010000 	add	x0, x0, x1
    7748:	39400001 	ldrb	w1, [x0]
    774c:	340000a1 	cbz	w1, 7760 <f12+0xf0>
    7750:	7103f43f 	cmp	w1, #0xfd
    7754:	54002688 	b.hi	7c24 <f12+0x5b4>  // b.pmore
    7758:	11000421 	add	w1, w1, #0x1
    775c:	39000001 	strb	w1, [x0]
    7760:	aa1303e0 	mov	x0, x19
    7764:	97fffa13 	bl	5fb0 <fwp_closure_drop>
    7768:	b40001d4 	cbz	x20, 77a0 <f12+0x130>
    776c:	aa1403e1 	mov	x1, x20
    7770:	d2800002 	mov	x2, #0x0                   	// #0
    7774:	d503201f 	nop
    7778:	f9400821 	ldr	x1, [x1, #16]
    777c:	91000442 	add	x2, x2, #0x1
    7780:	b5ffffc1 	cbnz	x1, 7778 <f12+0x108>
    7784:	aa0203f3 	mov	x19, x2
    7788:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    778c:	eb00005f 	cmp	x2, x0
    7790:	540000a9 	b.ls	77a4 <f12+0x134>  // b.plast
    7794:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7798:	912b6000 	add	x0, x0, #0xad8
    779c:	97fff19d 	bl	3e10 <fwp_trap>
    77a0:	d2800013 	mov	x19, #0x0                   	// #0
    77a4:	910102da 	add	x26, x22, #0x40
    77a8:	b942f740 	ldr	w0, [x26, #756]
    77ac:	34001260 	cbz	w0, 79f8 <f12+0x388>
    77b0:	910102c0 	add	x0, x22, #0x40
    77b4:	f940401b 	ldr	x27, [x0, #128]
    77b8:	f9404c1a 	ldr	x26, [x0, #152]
    77bc:	eb1b035f 	cmp	x26, x27
    77c0:	540006ca 	b.ge	7898 <f12+0x228>  // b.tcont
    77c4:	f94022c0 	ldr	x0, [x22, #64]
    77c8:	8b1a0741 	add	x1, x26, x26, lsl #1
    77cc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    77d0:	8b010b41 	add	x1, x26, x1, lsl #2
    77d4:	8b010c01 	add	x1, x0, x1, lsl #3
    77d8:	b9400420 	ldr	w0, [x1, #4]
    77dc:	35000080 	cbnz	w0, 77ec <f12+0x17c>
    77e0:	b9400020 	ldr	w0, [x1]
    77e4:	6b02001f 	cmp	w0, w2
    77e8:	54000589 	b.ls	7898 <f12+0x228>  // b.plast
    77ec:	9100075a 	add	x26, x26, #0x1
    77f0:	9101a021 	add	x1, x1, #0x68
    77f4:	eb1b035f 	cmp	x26, x27
    77f8:	54ffff01 	b.ne	77d8 <f12+0x168>  // b.any
    77fc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7800:	eb00037f 	cmp	x27, x0
    7804:	54001e2c 	b.gt	7bc8 <f12+0x558>
    7808:	910102c0 	add	x0, x22, #0x40
    780c:	f94022dc 	ldr	x28, [x22, #64]
    7810:	f9404800 	ldr	x0, [x0, #144]
    7814:	eb1b001f 	cmp	x0, x27
    7818:	54000201 	b.ne	7858 <f12+0x1e8>  // b.any
    781c:	b40026fb 	cbz	x27, 7cf8 <f12+0x688>
    7820:	d37ffb7a 	lsl	x26, x27, #1
    7824:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7828:	eb00035f 	cmp	x26, x0
    782c:	9a80d35a 	csel	x26, x26, x0, le
    7830:	8b1a0741 	add	x1, x26, x26, lsl #1
    7834:	8b010b41 	add	x1, x26, x1, lsl #2
    7838:	d37df021 	lsl	x1, x1, #3
    783c:	aa1c03e0 	mov	x0, x28
    7840:	97ffebe8 	bl	27e0 <realloc@plt>
    7844:	aa0003fc 	mov	x28, x0
    7848:	b4004740 	cbz	x0, 8130 <f12+0xac0>
    784c:	910102c0 	add	x0, x22, #0x40
    7850:	f90022dc 	str	x28, [x22, #64]
    7854:	f900481a 	str	x26, [x0, #144]
    7858:	8b1b0760 	add	x0, x27, x27, lsl #1
    785c:	910102c1 	add	x1, x22, #0x40
    7860:	4f000400 	movi	v0.4s, #0x0
    7864:	aa1b03fa 	mov	x26, x27
    7868:	8b000b60 	add	x0, x27, x0, lsl #2
    786c:	9100077b 	add	x27, x27, #0x1
    7870:	f900403b 	str	x27, [x1, #128]
    7874:	8b000f80 	add	x0, x28, x0, lsl #3
    7878:	ad000000 	stp	q0, q0, [x0]
    787c:	ad010000 	stp	q0, q0, [x0, #32]
    7880:	ad020000 	stp	q0, q0, [x0, #64]
    7884:	f900301f 	str	xzr, [x0, #96]
    7888:	14000007 	b	78a4 <f12+0x234>
    788c:	72003c3f 	tst	w1, #0xffff
    7890:	54fff681 	b.ne	7760 <f12+0xf0>  // b.any
    7894:	17ffffad 	b	7748 <f12+0xd8>
    7898:	eb1a037f 	cmp	x27, x26
    789c:	54fffb00 	b.eq	77fc <f12+0x18c>  // b.none
    78a0:	f94022dc 	ldr	x28, [x22, #64]
    78a4:	8b1a075b 	add	x27, x26, x26, lsl #1
    78a8:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    78ac:	911fe000 	add	x0, x0, #0x7f8
    78b0:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    78b4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    78b8:	f900337f 	str	xzr, [x27, #96]
    78bc:	97ffec31 	bl	2980 <getenv@plt>
    78c0:	b4000080 	cbz	x0, 78d0 <f12+0x260>
    78c4:	39400001 	ldrb	w1, [x0]
    78c8:	7100c03f 	cmp	w1, #0x30
    78cc:	54000720 	b.eq	79b0 <f12+0x340>  // b.none
    78d0:	910102c0 	add	x0, x22, #0x40
    78d4:	f9403801 	ldr	x1, [x0, #112]
    78d8:	b5000721 	cbnz	x1, 79bc <f12+0x34c>
    78dc:	910102c2 	add	x2, x22, #0x40
    78e0:	2f000400 	mvni	v0.2s, #0x0
    78e4:	b9400363 	ldr	w3, [x27]
    78e8:	52800020 	mov	w0, #0x1                   	// #1
    78ec:	91000744 	add	x4, x26, #0x1
    78f0:	a900cf73 	stp	x19, x19, [x27, #8]
    78f4:	0b000063 	add	w3, w3, w0
    78f8:	f9416041 	ldr	x1, [x2, #704]
    78fc:	29000363 	stp	w3, w0, [x27]
    7900:	f9002b7f 	str	xzr, [x27, #80]
    7904:	f9004c44 	str	x4, [x2, #152]
    7908:	fd002f60 	str	d0, [x27, #88]
    790c:	b4001521 	cbz	x1, 7bb0 <f12+0x540>
    7910:	910d42b5 	add	x21, x21, #0x350
    7914:	14000003 	b	7920 <f12+0x2b0>
    7918:	f9400021 	ldr	x1, [x1]
    791c:	b40014a1 	cbz	x1, 7bb0 <f12+0x540>
    7920:	f9400422 	ldr	x2, [x1, #8]
    7924:	eb15005f 	cmp	x2, x21
    7928:	54ffff81 	b.ne	7918 <f12+0x2a8>  // b.any
    792c:	f9400820 	ldr	x0, [x1, #16]
    7930:	2a1a03e2 	mov	w2, w26
    7934:	b9400001 	ldr	w1, [x0]
    7938:	f9002b60 	str	x0, [x27, #80]
    793c:	b9005f61 	str	w1, [x27, #92]
    7940:	37f80081 	tbnz	w1, #31, 7950 <f12+0x2e0>
    7944:	52800d05 	mov	w5, #0x68                  	// #104
    7948:	9b257021 	smaddl	x1, w1, w5, x28
    794c:	b900583a 	str	w26, [x1, #88]
    7950:	b9000002 	str	w2, [x0]
    7954:	aa1403e0 	mov	x0, x20
    7958:	d2800002 	mov	x2, #0x0                   	// #0
    795c:	b40005d4 	cbz	x20, 7a14 <f12+0x3a4>
    7960:	f9400800 	ldr	x0, [x0, #16]
    7964:	91000442 	add	x2, x2, #0x1
    7968:	b5ffffc0 	cbnz	x0, 7960 <f12+0x2f0>
    796c:	aa1403e1 	mov	x1, x20
    7970:	f9400821 	ldr	x1, [x1, #16]
    7974:	91000400 	add	x0, x0, #0x1
    7978:	b5ffffc1 	cbnz	x1, 7970 <f12+0x300>
    797c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7980:	eb01001f 	cmp	x0, x1
    7984:	54000108 	b.hi	79a4 <f12+0x334>  // b.pmore
    7988:	f100005f 	cmp	x2, #0x0
    798c:	5400044d 	b.le	7a14 <f12+0x3a4>
    7990:	eb00005f 	cmp	x2, x0
    7994:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7998:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    799c:	eb01027f 	cmp	x19, x1
    79a0:	540011a9 	b.ls	7bd4 <f12+0x564>  // b.plast
    79a4:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    79a8:	912b2000 	add	x0, x0, #0xac8
    79ac:	97fff119 	bl	3e10 <fwp_trap>
    79b0:	39400400 	ldrb	w0, [x0, #1]
    79b4:	34fff940 	cbz	w0, 78dc <f12+0x26c>
    79b8:	17ffffc6 	b	78d0 <f12+0x260>
    79bc:	3cc38002 	ldur	q2, [x0, #56]
    79c0:	9100e001 	add	x1, x0, #0x38
    79c4:	3cc48001 	ldur	q1, [x0, #72]
    79c8:	f900381f 	str	xzr, [x0, #112]
    79cc:	4f000400 	movi	v0.4s, #0x0
    79d0:	ad010762 	stp	q2, q1, [x27, #32]
    79d4:	a9458002 	ldp	x2, x0, [x0, #88]
    79d8:	f9000f60 	str	x0, [x27, #24]
    79dc:	f9401820 	ldr	x0, [x1, #48]
    79e0:	f9002362 	str	x2, [x27, #64]
    79e4:	f9002760 	str	x0, [x27, #72]
    79e8:	ad000020 	stp	q0, q0, [x1]
    79ec:	3d800820 	str	q0, [x1, #32]
    79f0:	f900183f 	str	xzr, [x1, #48]
    79f4:	17ffffba 	b	78dc <f12+0x26c>
    79f8:	f0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x50>
    79fc:	91094000 	add	x0, x0, #0x250
    7a00:	9400172c 	bl	d6b0 <atexit>
    7a04:	35003960 	cbnz	w0, 8130 <f12+0xac0>
    7a08:	52800020 	mov	w0, #0x1                   	// #1
    7a0c:	b902f740 	str	w0, [x26, #756]
    7a10:	17ffff68 	b	77b0 <f12+0x140>
    7a14:	d3707c63 	ubfiz	x3, x3, #16, #32
    7a18:	52800041 	mov	w1, #0x2                   	// #2
    7a1c:	aa040075 	orr	x21, x3, x4
    7a20:	d2800100 	mov	x0, #0x8                   	// #8
    7a24:	97fff473 	bl	4bf0 <fwp_heap_alloc>
    7a28:	aa0003fa 	mov	x26, x0
    7a2c:	911542e0 	add	x0, x23, #0x550
    7a30:	f900035f 	str	xzr, [x26]
    7a34:	f949d801 	ldr	x1, [x0, #5040]
    7a38:	f949ec00 	ldr	x0, [x0, #5080]
    7a3c:	cb010341 	sub	x1, x26, x1
    7a40:	eb00403f 	cmp	x1, x0, lsl #16
    7a44:	54000ea2 	b.cs	7c18 <f12+0x5a8>  // b.hs, b.nlast
    7a48:	d2800013 	mov	x19, #0x0                   	// #0
    7a4c:	911542e2 	add	x2, x23, #0x550
    7a50:	d350fc20 	lsr	x0, x1, #16
    7a54:	8b000800 	add	x0, x0, x0, lsl #2
    7a58:	f949fc43 	ldr	x3, [x2, #5112]
    7a5c:	d37df002 	lsl	x2, x0, #3
    7a60:	8b020060 	add	x0, x3, x2
    7a64:	f940101b 	ldr	x27, [x0, #32]
    7a68:	b400025b 	cbz	x27, 7ab0 <f12+0x440>
    7a6c:	38626862 	ldrb	w2, [x3, x2]
    7a70:	7100085f 	cmp	w2, #0x2
    7a74:	54000a40 	b.eq	7bbc <f12+0x54c>  // b.none
    7a78:	7100045f 	cmp	w2, #0x1
    7a7c:	540001a1 	b.ne	7ab0 <f12+0x440>  // b.any
    7a80:	29430002 	ldp	w2, w0, [x0, #24]
    7a84:	92403c21 	and	x1, x1, #0xffff
    7a88:	9b027c21 	mul	x1, x1, x2
    7a8c:	d360fc21 	lsr	x1, x1, #32
    7a90:	eb00003f 	cmp	x1, x0
    7a94:	540000e2 	b.cs	7ab0 <f12+0x440>  // b.hs, b.nlast
    7a98:	8b01037b 	add	x27, x27, x1
    7a9c:	39400360 	ldrb	w0, [x27]
    7aa0:	7103fc1f 	cmp	w0, #0xff
    7aa4:	540032a0 	b.eq	80f8 <f12+0xa88>  // b.none
    7aa8:	52800020 	mov	w0, #0x1                   	// #1
    7aac:	39000360 	strb	w0, [x27]
    7ab0:	b4000233 	cbz	x19, 7af4 <f12+0x484>
    7ab4:	d3607ea4 	lsl	x4, x21, #32
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	f9400685 	ldr	x5, [x20, #8]
    7ac0:	aa0403e3 	mov	x3, x4
    7ac4:	91002342 	add	x2, x26, #0x8
    7ac8:	d2800001 	mov	x1, #0x0                   	// #0
    7acc:	14000005 	b	7ae0 <f12+0x470>
    7ad0:	f9400405 	ldr	x5, [x0, #8]
    7ad4:	ab010083 	adds	x3, x4, x1
    7ad8:	91004042 	add	x2, x2, #0x10
    7adc:	54005a06 	b.vs	861c <f12+0xfac>
    7ae0:	a9000c45 	stp	x5, x3, [x2]
    7ae4:	91000421 	add	x1, x1, #0x1
    7ae8:	f9400800 	ldr	x0, [x0, #16]
    7aec:	eb13003f 	cmp	x1, x19
    7af0:	54ffff03 	b.cc	7ad0 <f12+0x460>  // b.lo, b.ul, b.last
    7af4:	f9400340 	ldr	x0, [x26]
    7af8:	f100041f 	cmp	x0, #0x1
    7afc:	540008e9 	b.ls	7c18 <f12+0x5a8>  // b.plast
    7b00:	d341fc00 	lsr	x0, x0, #1
    7b04:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7b08:	d100041c 	sub	x28, x0, #0x1
    7b0c:	eb01039f 	cmp	x28, x1
    7b10:	54fff4a8 	b.hi	79a4 <f12+0x334>  // b.pmore
    7b14:	b400083c 	cbz	x28, 7c18 <f12+0x5a8>
    7b18:	d1002341 	sub	x1, x26, #0x8
    7b1c:	91002353 	add	x19, x26, #0x8
    7b20:	8b00103b 	add	x27, x1, x0, lsl #4
    7b24:	d503201f 	nop
    7b28:	f9400660 	ldr	x0, [x19, #8]
    7b2c:	f9400e61 	ldr	x1, [x19, #24]
    7b30:	fd400260 	ldr	d0, [x19]
    7b34:	fd400a61 	ldr	d1, [x19, #16]
    7b38:	97fff5db 	bl	52a4 <w107>
    7b3c:	a9000660 	stp	x0, x1, [x19]
    7b40:	91004273 	add	x19, x19, #0x10
    7b44:	eb1b027f 	cmp	x19, x27
    7b48:	54ffff01 	b.ne	7b28 <f12+0x4b8>  // b.any
    7b4c:	aa1a03fb 	mov	x27, x26
    7b50:	d37ffb93 	lsl	x19, x28, #1
    7b54:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7b58:	d280001c 	mov	x28, #0x0                   	// #0
    7b5c:	f8010773 	str	x19, [x27], #16
    7b60:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    7b64:	aa0303e0 	mov	x0, x3
    7b68:	91000b9c 	add	x28, x28, #0x2
    7b6c:	97fff57d 	bl	5160 <f128.constprop.0>
    7b70:	aa0003e3 	mov	x3, x0
    7b74:	eb13039f 	cmp	x28, x19
    7b78:	54ffff43 	b.cc	7b60 <f12+0x4f0>  // b.lo, b.ul, b.last
    7b7c:	aa1a03e0 	mov	x0, x26
    7b80:	93407eb5 	sxtw	x21, w21
    7b84:	f90007e3 	str	x3, [sp, #8]
    7b88:	97fffb52 	bl	68d0 <fwp_drop4>
    7b8c:	aa1503e0 	mov	x0, x21
    7b90:	97fff2a4 	bl	4620 <fwp_tape_of>
    7b94:	f940301b 	ldr	x27, [x0, #96]
    7b98:	aa0003e5 	mov	x5, x0
    7b9c:	f94007e3 	ldr	x3, [sp, #8]
    7ba0:	b400047b 	cbz	x27, 7c2c <f12+0x5bc>
    7ba4:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7ba8:	9128e000 	add	x0, x0, #0xa38
    7bac:	97fff099 	bl	3e10 <fwp_trap>
    7bb0:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7bb4:	912ca000 	add	x0, x0, #0xb28
    7bb8:	97fff096 	bl	3e10 <fwp_trap>
    7bbc:	72003c3f 	tst	w1, #0xffff
    7bc0:	54fff781 	b.ne	7ab0 <f12+0x440>  // b.any
    7bc4:	17ffffb6 	b	7a9c <f12+0x42c>
    7bc8:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7bcc:	912be000 	add	x0, x0, #0xaf8
    7bd0:	97fff090 	bl	3e10 <fwp_trap>
    7bd4:	d37ffa7b 	lsl	x27, x19, #1
    7bd8:	d3707c63 	ubfiz	x3, x3, #16, #32
    7bdc:	91000760 	add	x0, x27, #0x1
    7be0:	52800041 	mov	w1, #0x2                   	// #2
    7be4:	aa040075 	orr	x21, x3, x4
    7be8:	d37df000 	lsl	x0, x0, #3
    7bec:	97fff401 	bl	4bf0 <fwp_heap_alloc>
    7bf0:	aa0003fa 	mov	x26, x0
    7bf4:	911542e1 	add	x1, x23, #0x550
    7bf8:	aa0103e0 	mov	x0, x1
    7bfc:	f900035b 	str	x27, [x26]
    7c00:	f949d821 	ldr	x1, [x1, #5040]
    7c04:	f949ec00 	ldr	x0, [x0, #5080]
    7c08:	cb010341 	sub	x1, x26, x1
    7c0c:	eb00403f 	cmp	x1, x0, lsl #16
    7c10:	54fff1e3 	b.cc	7a4c <f12+0x3dc>  // b.lo, b.ul, b.last
    7c14:	b5fff513 	cbnz	x19, 7ab4 <f12+0x444>
    7c18:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7c1c:	f900035f 	str	xzr, [x26]
    7c20:	17ffffd7 	b	7b7c <f12+0x50c>
    7c24:	97fff1b0 	bl	42e4 <fwp_rc_wide_dup>
    7c28:	17fffece 	b	7760 <f12+0xf0>
    7c2c:	f9000fe3 	str	x3, [sp, #24]
    7c30:	97ffecb8 	bl	2f10 <fwp_tape_unlink_scope>
    7c34:	a94288bc 	ldp	x28, x2, [x5, #40]
    7c38:	f90007e2 	str	x2, [sp, #8]
    7c3c:	f9401ca2 	ldr	x2, [x5, #56]
    7c40:	b90004bf 	str	wzr, [x5, #4]
    7c44:	b94000a1 	ldr	w1, [x5]
    7c48:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7c4c:	f9000be2 	str	x2, [sp, #16]
    7c50:	a940acba 	ldp	x26, x11, [x5, #8]
    7c54:	6b00003f 	cmp	w1, w0
    7c58:	a941eca9 	ldp	x9, x27, [x5, #24]
    7c5c:	f9400fe3 	ldr	x3, [sp, #24]
    7c60:	f94020a4 	ldr	x4, [x5, #64]
    7c64:	f94024a2 	ldr	x2, [x5, #72]
    7c68:	54000108 	b.hi	7c88 <f12+0x618>  // b.pmore
    7c6c:	910102c1 	add	x1, x22, #0x40
    7c70:	92403ea0 	and	x0, x21, #0xffff
    7c74:	d1000400 	sub	x0, x0, #0x1
    7c78:	f9404c2a 	ldr	x10, [x1, #152]
    7c7c:	eb0a001f 	cmp	x0, x10
    7c80:	5400004a 	b.ge	7c88 <f12+0x618>  // b.tcont
    7c84:	f9004c20 	str	x0, [x1, #152]
    7c88:	4f000400 	movi	v0.4s, #0x0
    7c8c:	910102c1 	add	x1, x22, #0x40
    7c90:	90ffffe0 	adrp	x0, 3000 <fwp_segv+0x10>
    7c94:	9133c000 	add	x0, x0, #0xcf0
    7c98:	f9000cbf 	str	xzr, [x5, #24]
    7c9c:	910163e6 	add	x6, sp, #0x58
    7ca0:	f941602a 	ldr	x10, [x1, #704]
    7ca4:	3c8080a0 	stur	q0, [x5, #8]
    7ca8:	9101c3f3 	add	x19, sp, #0x70
    7cac:	a90583ea 	stp	x10, x0, [sp, #88]
    7cb0:	f94007e0 	ldr	x0, [sp, #8]
    7cb4:	ad0100a0 	stp	q0, q0, [x5, #32]
    7cb8:	f90043e0 	str	x0, [sp, #128]
    7cbc:	f9400be0 	ldr	x0, [sp, #16]
    7cc0:	f9000fe6 	str	x6, [sp, #24]
    7cc4:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    7cc8:	a906eff3 	stp	x19, x27, [sp, #104]
    7ccc:	f9003ffc 	str	x28, [sp, #120]
    7cd0:	f90047e0 	str	x0, [sp, #136]
    7cd4:	a90927e4 	stp	x4, x9, [sp, #144]
    7cd8:	f90053e2 	str	x2, [sp, #160]
    7cdc:	f9016026 	str	x6, [x1, #704]
    7ce0:	b7f82083 	tbnz	x3, #63, 80f0 <f12+0xa80>
    7ce4:	eb8382bf 	cmp	x21, x3, asr #32
    7ce8:	540000e0 	b.eq	7d04 <f12+0x694>  // b.none
    7cec:	d0000020 	adrp	x0, d000 <__divti3+0x40>
    7cf0:	9127c000 	add	x0, x0, #0x9f0
    7cf4:	97fff047 	bl	3e10 <fwp_trap>
    7cf8:	d2800d01 	mov	x1, #0x68                  	// #104
    7cfc:	d280003a 	mov	x26, #0x1                   	// #1
    7d00:	17fffecf 	b	783c <f12+0x1cc>
    7d04:	92407c60 	and	x0, x3, #0xffffffff
    7d08:	eb00035f 	cmp	x26, x0
    7d0c:	9a80c755 	csinc	x21, x26, x0, gt
    7d10:	eb23417f 	cmp	x11, w3, uxtw
    7d14:	54001f8d 	b.le	8104 <f12+0xa94>
    7d18:	eb15005f 	cmp	x2, x21
    7d1c:	54001faa 	b.ge	8110 <f12+0xaa0>  // b.tcont
    7d20:	f100005f 	cmp	x2, #0x0
    7d24:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7d28:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    7d2c:	14000004 	b	7d3c <f12+0x6cc>
    7d30:	eb01005f 	cmp	x2, x1
    7d34:	d37ff842 	lsl	x2, x2, #1
    7d38:	9a95d042 	csel	x2, x2, x21, le
    7d3c:	eb15005f 	cmp	x2, x21
    7d40:	54ffff8b 	b.lt	7d30 <f12+0x6c0>  // b.tstop
    7d44:	f90017e3 	str	x3, [sp, #40]
    7d48:	b40027a4 	cbz	x4, 823c <f12+0xbcc>
    7d4c:	aa0403e0 	mov	x0, x4
    7d50:	d37df041 	lsl	x1, x2, #3
    7d54:	f90013e2 	str	x2, [sp, #32]
    7d58:	97ffeaa2 	bl	27e0 <realloc@plt>
    7d5c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7d60:	aa0003e4 	mov	x4, x0
    7d64:	b4001d64 	cbz	x4, 8110 <f12+0xaa0>
    7d68:	f9004be4 	str	x4, [sp, #144]
    7d6c:	f90053e2 	str	x2, [sp, #160]
    7d70:	b5001b15 	cbnz	x21, 80d0 <f12+0xa60>
    7d74:	b7f800c3 	tbnz	x3, #63, 7d8c <f12+0x71c>
    7d78:	92407c63 	and	x3, x3, #0xffffffff
    7d7c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7d80:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    7d84:	1e612800 	fadd	d0, d0, d1
    7d88:	fc237880 	str	d0, [x4, x3, lsl #3]
    7d8c:	d10006a0 	sub	x0, x21, #0x1
    7d90:	d1000743 	sub	x3, x26, #0x1
    7d94:	eb00035f 	cmp	x26, x0
    7d98:	540003ec 	b.gt	7e14 <f12+0x7a4>
    7d9c:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    7da0:	1e602008 	fcmp	d0, #0.0
    7da4:	54000320 	b.eq	7e08 <f12+0x798>  // b.none
    7da8:	cb1a0be1 	neg	x1, x26, lsl #2
    7dac:	cb1a03e5 	neg	x5, x26
    7db0:	8b010362 	add	x2, x27, x1
    7db4:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    7db8:	37f80122 	tbnz	w2, #31, 7ddc <f12+0x76c>
    7dbc:	f94007e6 	ldr	x6, [sp, #8]
    7dc0:	93407c42 	sxtw	x2, w2
    7dc4:	8b050cc9 	add	x9, x6, x5, lsl #3
    7dc8:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    7dcc:	fc607922 	ldr	d2, [x9, x0, lsl #3]
    7dd0:	1e620802 	fmul	d2, d0, d2
    7dd4:	1e622821 	fadd	d1, d1, d2
    7dd8:	fc227881 	str	d1, [x4, x2, lsl #3]
    7ddc:	8b010381 	add	x1, x28, x1
    7de0:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    7de4:	37f80121 	tbnz	w1, #31, 7e08 <f12+0x798>
    7de8:	f9400be2 	ldr	x2, [sp, #16]
    7dec:	93407c21 	sxtw	x1, w1
    7df0:	8b050c45 	add	x5, x2, x5, lsl #3
    7df4:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    7df8:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    7dfc:	1e620800 	fmul	d0, d0, d2
    7e00:	1e602820 	fadd	d0, d1, d0
    7e04:	fc217880 	str	d0, [x4, x1, lsl #3]
    7e08:	d1000400 	sub	x0, x0, #0x1
    7e0c:	eb00007f 	cmp	x3, x0
    7e10:	54fffc61 	b.ne	7d9c <f12+0x72c>  // b.any
    7e14:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7e18:	eb00035f 	cmp	x26, x0
    7e1c:	54001a28 	b.hi	8160 <f12+0xaf0>  // b.pmore
    7e20:	91000740 	add	x0, x26, #0x1
    7e24:	52800041 	mov	w1, #0x2                   	// #2
    7e28:	f90007e4 	str	x4, [sp, #8]
    7e2c:	d37df000 	lsl	x0, x0, #3
    7e30:	97fff370 	bl	4bf0 <fwp_heap_alloc>
    7e34:	aa0003fb 	mov	x27, x0
    7e38:	f800841a 	str	x26, [x0], #8
    7e3c:	f94007e4 	ldr	x4, [sp, #8]
    7e40:	d2800001 	mov	x1, #0x0                   	// #0
    7e44:	b40000da 	cbz	x26, 7e5c <f12+0x7ec>
    7e48:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    7e4c:	f8217802 	str	x2, [x0, x1, lsl #3]
    7e50:	91000421 	add	x1, x1, #0x1
    7e54:	eb01035f 	cmp	x26, x1
    7e58:	54ffff81 	b.ne	7e48 <f12+0x7d8>  // b.any
    7e5c:	910102c1 	add	x1, x22, #0x40
    7e60:	f9400fe2 	ldr	x2, [sp, #24]
    7e64:	f9416020 	ldr	x0, [x1, #704]
    7e68:	eb02001f 	cmp	x0, x2
    7e6c:	54003da1 	b.ne	8620 <f12+0xfb0>  // b.any
    7e70:	f9402ff5 	ldr	x21, [sp, #88]
    7e74:	aa1303e0 	mov	x0, x19
    7e78:	f9016035 	str	x21, [x1, #704]
    7e7c:	97ffef9d 	bl	3cf0 <fwp_tape_buffers_release>
    7e80:	911542e2 	add	x2, x23, #0x550
    7e84:	f949d841 	ldr	x1, [x2, #5040]
    7e88:	f949ec40 	ldr	x0, [x2, #5080]
    7e8c:	cb010361 	sub	x1, x27, x1
    7e90:	eb00403f 	cmp	x1, x0, lsl #16
    7e94:	54000322 	b.cs	7ef8 <f12+0x888>  // b.hs, b.nlast
    7e98:	d350fc20 	lsr	x0, x1, #16
    7e9c:	f949fc43 	ldr	x3, [x2, #5112]
    7ea0:	8b000800 	add	x0, x0, x0, lsl #2
    7ea4:	d37df002 	lsl	x2, x0, #3
    7ea8:	8b020060 	add	x0, x3, x2
    7eac:	f9401013 	ldr	x19, [x0, #32]
    7eb0:	b4000253 	cbz	x19, 7ef8 <f12+0x888>
    7eb4:	38626862 	ldrb	w2, [x3, x2]
    7eb8:	7100085f 	cmp	w2, #0x2
    7ebc:	54001ba0 	b.eq	8230 <f12+0xbc0>  // b.none
    7ec0:	7100045f 	cmp	w2, #0x1
    7ec4:	540001a1 	b.ne	7ef8 <f12+0x888>  // b.any
    7ec8:	29430002 	ldp	w2, w0, [x0, #24]
    7ecc:	92403c21 	and	x1, x1, #0xffff
    7ed0:	9b027c21 	mul	x1, x1, x2
    7ed4:	d360fc21 	lsr	x1, x1, #32
    7ed8:	eb00003f 	cmp	x1, x0
    7edc:	540000e2 	b.cs	7ef8 <f12+0x888>  // b.hs, b.nlast
    7ee0:	8b010273 	add	x19, x19, x1
    7ee4:	39400260 	ldrb	w0, [x19]
    7ee8:	7103fc1f 	cmp	w0, #0xff
    7eec:	540038e0 	b.eq	8608 <f12+0xf98>  // b.none
    7ef0:	52800020 	mov	w0, #0x1                   	// #1
    7ef4:	39000260 	strb	w0, [x19]
    7ef8:	eb1902bf 	cmp	x21, x25
    7efc:	54003921 	b.ne	8620 <f12+0xfb0>  // b.any
    7f00:	f94023e1 	ldr	x1, [sp, #64]
    7f04:	910102d6 	add	x22, x22, #0x40
    7f08:	aa1803e0 	mov	x0, x24
    7f0c:	f90162c1 	str	x1, [x22, #704]
    7f10:	97fff910 	bl	6350 <fwp_tape_scope_release>
    7f14:	f9400360 	ldr	x0, [x27]
    7f18:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7f1c:	b7f81360 	tbnz	x0, #63, 8188 <f12+0xb18>
    7f20:	911542e2 	add	x2, x23, #0x550
    7f24:	f949d840 	ldr	x0, [x2, #5040]
    7f28:	f949ec41 	ldr	x1, [x2, #5080]
    7f2c:	cb000360 	sub	x0, x27, x0
    7f30:	eb01401f 	cmp	x0, x1, lsl #16
    7f34:	540012a2 	b.cs	8188 <f12+0xb18>  // b.hs, b.nlast
    7f38:	d350fc01 	lsr	x1, x0, #16
    7f3c:	f949fc44 	ldr	x4, [x2, #5112]
    7f40:	8b010821 	add	x1, x1, x1, lsl #2
    7f44:	d37df021 	lsl	x1, x1, #3
    7f48:	8b010083 	add	x3, x4, x1
    7f4c:	f9401062 	ldr	x2, [x3, #32]
    7f50:	b40011c2 	cbz	x2, 8188 <f12+0xb18>
    7f54:	38616881 	ldrb	w1, [x4, x1]
    7f58:	7100083f 	cmp	w1, #0x2
    7f5c:	54001120 	b.eq	8180 <f12+0xb10>  // b.none
    7f60:	7100043f 	cmp	w1, #0x1
    7f64:	54001121 	b.ne	8188 <f12+0xb18>  // b.any
    7f68:	29430464 	ldp	w4, w1, [x3, #24]
    7f6c:	92403c00 	and	x0, x0, #0xffff
    7f70:	9b047c00 	mul	x0, x0, x4
    7f74:	d360fc00 	lsr	x0, x0, #32
    7f78:	eb01001f 	cmp	x0, x1
    7f7c:	54001062 	b.cs	8188 <f12+0xb18>  // b.hs, b.nlast
    7f80:	8b000042 	add	x2, x2, x0
    7f84:	39400040 	ldrb	w0, [x2]
    7f88:	7100041f 	cmp	w0, #0x1
    7f8c:	54000fe1 	b.ne	8188 <f12+0xb18>  // b.any
    7f90:	aa1b03f6 	mov	x22, x27
    7f94:	aa1b03f5 	mov	x21, x27
    7f98:	d2800000 	mov	x0, #0x0                   	// #0
    7f9c:	910022a2 	add	x2, x21, #0x8
    7fa0:	d2800001 	mov	x1, #0x0                   	// #0
    7fa4:	b40001f8 	cbz	x24, 7fe0 <f12+0x970>
    7fa8:	f0000023 	adrp	x3, e000 <_IO_stdin_used+0x920>
    7fac:	91002364 	add	x4, x27, #0x8
    7fb0:	fd41d861 	ldr	d1, [x3, #944]
    7fb4:	f9400365 	ldr	x5, [x27]
    7fb8:	aa0403e3 	mov	x3, x4
    7fbc:	b7f80de5 	tbnz	x5, #63, 8178 <f12+0xb08>
    7fc0:	f94002c5 	ldr	x5, [x22]
    7fc4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    7fc8:	b7f80d25 	tbnz	x5, #63, 816c <f12+0xafc>
    7fcc:	1e600820 	fmul	d0, d1, d0
    7fd0:	91000421 	add	x1, x1, #0x1
    7fd4:	fc008440 	str	d0, [x2], #8
    7fd8:	eb01031f 	cmp	x24, x1
    7fdc:	54fffec1 	b.ne	7fb4 <f12+0x944>  // b.any
    7fe0:	97fffa3c 	bl	68d0 <fwp_drop4>
    7fe4:	b4003094 	cbz	x20, 85f4 <f12+0xf84>
    7fe8:	aa1403e0 	mov	x0, x20
    7fec:	d2800013 	mov	x19, #0x0                   	// #0
    7ff0:	f9400800 	ldr	x0, [x0, #16]
    7ff4:	91000673 	add	x19, x19, #0x1
    7ff8:	b5ffffc0 	cbnz	x0, 7ff0 <f12+0x980>
    7ffc:	f94002c0 	ldr	x0, [x22]
    8000:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    8004:	b7f81300 	tbnz	x0, #63, 8264 <f12+0xbf4>
    8008:	911542e1 	add	x1, x23, #0x550
    800c:	f949d820 	ldr	x0, [x1, #5040]
    8010:	f949ec22 	ldr	x2, [x1, #5080]
    8014:	cb0002a0 	sub	x0, x21, x0
    8018:	eb02401f 	cmp	x0, x2, lsl #16
    801c:	54001222 	b.cs	8260 <f12+0xbf0>  // b.hs, b.nlast
    8020:	d350fc02 	lsr	x2, x0, #16
    8024:	d2800503 	mov	x3, #0x28                  	// #40
    8028:	f949fc24 	ldr	x4, [x1, #5112]
    802c:	9b037c42 	mul	x2, x2, x3
    8030:	8b020083 	add	x3, x4, x2
    8034:	f9401061 	ldr	x1, [x3, #32]
    8038:	b4001141 	cbz	x1, 8260 <f12+0xbf0>
    803c:	38626882 	ldrb	w2, [x4, x2]
    8040:	7100085f 	cmp	w2, #0x2
    8044:	540010a0 	b.eq	8258 <f12+0xbe8>  // b.none
    8048:	7100045f 	cmp	w2, #0x1
    804c:	540010a1 	b.ne	8260 <f12+0xbf0>  // b.any
    8050:	29430864 	ldp	w4, w2, [x3, #24]
    8054:	92403c00 	and	x0, x0, #0xffff
    8058:	9b047c00 	mul	x0, x0, x4
    805c:	d360fc00 	lsr	x0, x0, #32
    8060:	eb02001f 	cmp	x0, x2
    8064:	54000fe2 	b.cs	8260 <f12+0xbf0>  // b.hs, b.nlast
    8068:	8b000021 	add	x1, x1, x0
    806c:	3940003c 	ldrb	w28, [x1]
    8070:	7100079f 	cmp	w28, #0x1
    8074:	54000f61 	b.ne	8260 <f12+0xbf0>  // b.any
    8078:	910022d8 	add	x24, x22, #0x8
    807c:	eb13033f 	cmp	x25, x19
    8080:	9a939339 	csel	x25, x25, x19, ls	// ls = plast
    8084:	b4002a79 	cbz	x25, 85d0 <f12+0xf60>
    8088:	d37df324 	lsl	x4, x25, #3
    808c:	aa1403e1 	mov	x1, x20
    8090:	910022a3 	add	x3, x21, #0x8
    8094:	d2800000 	mov	x0, #0x0                   	// #0
    8098:	14000009 	b	80bc <f12+0xa4c>
    809c:	fc606841 	ldr	d1, [x2, x0]
    80a0:	fd400420 	ldr	d0, [x1, #8]
    80a4:	1e613800 	fsub	d0, d0, d1
    80a8:	fc206b00 	str	d0, [x24, x0]
    80ac:	91002000 	add	x0, x0, #0x8
    80b0:	f9400821 	ldr	x1, [x1, #16]
    80b4:	eb04001f 	cmp	x0, x4
    80b8:	54001020 	b.eq	82bc <f12+0xc4c>  // b.none
    80bc:	f94002c5 	ldr	x5, [x22]
    80c0:	aa0303e2 	mov	x2, x3
    80c4:	b6fffec5 	tbz	x5, #63, 809c <f12+0xa2c>
    80c8:	f9400aa2 	ldr	x2, [x21, #16]
    80cc:	17fffff4 	b	809c <f12+0xa2c>
    80d0:	aa0403e0 	mov	x0, x4
    80d4:	d37df2a2 	lsl	x2, x21, #3
    80d8:	52800001 	mov	w1, #0x0                   	// #0
    80dc:	f90013e3 	str	x3, [sp, #32]
    80e0:	97ffe9b8 	bl	27c0 <memset@plt>
    80e4:	aa0003e4 	mov	x4, x0
    80e8:	f94013e3 	ldr	x3, [sp, #32]
    80ec:	17ffff22 	b	7d74 <f12+0x704>
    80f0:	aa1a03f5 	mov	x21, x26
    80f4:	17ffff09 	b	7d18 <f12+0x6a8>
    80f8:	aa1b03e0 	mov	x0, x27
    80fc:	97ffef65 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8100:	17fffe6a 	b	7aa8 <f12+0x438>
    8104:	b0000020 	adrp	x0, d000 <__divti3+0x40>
    8108:	9129a000 	add	x0, x0, #0xa68
    810c:	97ffef41 	bl	3e10 <fwp_trap>
    8110:	f10002bf 	cmp	x21, #0x0
    8114:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    8118:	54ffe2c1 	b.ne	7d70 <f12+0x700>  // b.any
    811c:	f9402fe1 	ldr	x1, [sp, #88]
    8120:	910102d6 	add	x22, x22, #0x40
    8124:	aa1303e0 	mov	x0, x19
    8128:	f90162c1 	str	x1, [x22, #704]
    812c:	97ffeef1 	bl	3cf0 <fwp_tape_buffers_release>
    8130:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8134:	f947e863 	ldr	x3, [x3, #4048]
    8138:	d2800262 	mov	x2, #0x13                  	// #19
    813c:	d2800021 	mov	x1, #0x1                   	// #1
    8140:	b0000020 	adrp	x0, d000 <__divti3+0x40>
    8144:	911ba000 	add	x0, x0, #0x6e8
    8148:	f9400063 	ldr	x3, [x3]
    814c:	97ffe9e9 	bl	28f0 <fwrite@plt>
    8150:	d2800000 	mov	x0, #0x0                   	// #0
    8154:	97ffe9f3 	bl	2920 <fflush@plt>
    8158:	52800cc0 	mov	w0, #0x66                  	// #102
    815c:	97ffea01 	bl	2960 <_Exit@plt>
    8160:	b0000020 	adrp	x0, d000 <__divti3+0x40>
    8164:	912d6000 	add	x0, x0, #0xb58
    8168:	97ffef2a 	bl	3e10 <fwp_trap>
    816c:	b0000020 	adrp	x0, d000 <__divti3+0x40>
    8170:	912da000 	add	x0, x0, #0xb68
    8174:	97ffef27 	bl	3e10 <fwp_trap>
    8178:	f9400b63 	ldr	x3, [x27, #16]
    817c:	17ffff91 	b	7fc0 <f12+0x950>
    8180:	72003c1f 	tst	w0, #0xffff
    8184:	54fff000 	b.eq	7f84 <f12+0x914>  // b.none
    8188:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    818c:	eb00031f 	cmp	x24, x0
    8190:	54fffe88 	b.hi	8160 <f12+0xaf0>  // b.pmore
    8194:	91000700 	add	x0, x24, #0x1
    8198:	52800021 	mov	w1, #0x1                   	// #1
    819c:	d37df000 	lsl	x0, x0, #3
    81a0:	97fff294 	bl	4bf0 <fwp_heap_alloc>
    81a4:	911542e2 	add	x2, x23, #0x550
    81a8:	f9000018 	str	x24, [x0]
    81ac:	aa0003f6 	mov	x22, x0
    81b0:	aa0003f5 	mov	x21, x0
    81b4:	f949d841 	ldr	x1, [x2, #5040]
    81b8:	f949ec40 	ldr	x0, [x2, #5080]
    81bc:	cb0102c1 	sub	x1, x22, x1
    81c0:	eb00403f 	cmp	x1, x0, lsl #16
    81c4:	54000322 	b.cs	8228 <f12+0xbb8>  // b.hs, b.nlast
    81c8:	d350fc20 	lsr	x0, x1, #16
    81cc:	d2800504 	mov	x4, #0x28                  	// #40
    81d0:	f949fc43 	ldr	x3, [x2, #5112]
    81d4:	9b047c00 	mul	x0, x0, x4
    81d8:	8b000062 	add	x2, x3, x0
    81dc:	f9401053 	ldr	x19, [x2, #32]
    81e0:	b4000253 	cbz	x19, 8228 <f12+0xbb8>
    81e4:	38606860 	ldrb	w0, [x3, x0]
    81e8:	7100081f 	cmp	w0, #0x2
    81ec:	54001fc0 	b.eq	85e4 <f12+0xf74>  // b.none
    81f0:	7100041f 	cmp	w0, #0x1
    81f4:	540001a1 	b.ne	8228 <f12+0xbb8>  // b.any
    81f8:	29430043 	ldp	w3, w0, [x2, #24]
    81fc:	92403c21 	and	x1, x1, #0xffff
    8200:	9b037c21 	mul	x1, x1, x3
    8204:	d360fc21 	lsr	x1, x1, #32
    8208:	eb00003f 	cmp	x1, x0
    820c:	540000e2 	b.cs	8228 <f12+0xbb8>  // b.hs, b.nlast
    8210:	8b010273 	add	x19, x19, x1
    8214:	39400260 	ldrb	w0, [x19]
    8218:	7103fc1f 	cmp	w0, #0xff
    821c:	54001de0 	b.eq	85d8 <f12+0xf68>  // b.none
    8220:	52800020 	mov	w0, #0x1                   	// #1
    8224:	39000260 	strb	w0, [x19]
    8228:	aa1b03e0 	mov	x0, x27
    822c:	17ffff5c 	b	7f9c <f12+0x92c>
    8230:	72003c3f 	tst	w1, #0xffff
    8234:	54ffe621 	b.ne	7ef8 <f12+0x888>  // b.any
    8238:	17ffff2b 	b	7ee4 <f12+0x874>
    823c:	aa0203e0 	mov	x0, x2
    8240:	d2800101 	mov	x1, #0x8                   	// #8
    8244:	f90013e2 	str	x2, [sp, #32]
    8248:	97ffe962 	bl	27d0 <calloc@plt>
    824c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    8250:	aa0003e4 	mov	x4, x0
    8254:	17fffec4 	b	7d64 <f12+0x6f4>
    8258:	72003c1f 	tst	w0, #0xffff
    825c:	54fff080 	b.eq	806c <f12+0x9fc>  // b.none
    8260:	b4001af4 	cbz	x20, 85bc <f12+0xf4c>
    8264:	aa1403fa 	mov	x26, x20
    8268:	d2800013 	mov	x19, #0x0                   	// #0
    826c:	f9400b5a 	ldr	x26, [x26, #16]
    8270:	aa1303e0 	mov	x0, x19
    8274:	91000673 	add	x19, x19, #0x1
    8278:	b5ffffba 	cbnz	x26, 826c <f12+0xbfc>
    827c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8280:	eb01027f 	cmp	x19, x1
    8284:	54ffb908 	b.hi	79a4 <f12+0x334>  // b.pmore
    8288:	91000800 	add	x0, x0, #0x2
    828c:	52800041 	mov	w1, #0x2                   	// #2
    8290:	d37df000 	lsl	x0, x0, #3
    8294:	97fff257 	bl	4bf0 <fwp_heap_alloc>
    8298:	aa1403e1 	mov	x1, x20
    829c:	aa0003f8 	mov	x24, x0
    82a0:	f9400420 	ldr	x0, [x1, #8]
    82a4:	f83a7b00 	str	x0, [x24, x26, lsl #3]
    82a8:	9100075a 	add	x26, x26, #0x1
    82ac:	f9400821 	ldr	x1, [x1, #16]
    82b0:	b5ffff81 	cbnz	x1, 82a0 <f12+0xc30>
    82b4:	5280001c 	mov	w28, #0x0                   	// #0
    82b8:	17ffff71 	b	807c <f12+0xa0c>
    82bc:	b40017d4 	cbz	x20, 85b4 <f12+0xf44>
    82c0:	911542e0 	add	x0, x23, #0x550
    82c4:	aa1403e2 	mov	x2, x20
    82c8:	d280001b 	mov	x27, #0x0                   	// #0
    82cc:	f949ec04 	ldr	x4, [x0, #5080]
    82d0:	f949d807 	ldr	x7, [x0, #5040]
    82d4:	f949fc06 	ldr	x6, [x0, #5112]
    82d8:	d370bc84 	lsl	x4, x4, #16
    82dc:	14000006 	b	82f4 <f12+0xc84>
    82e0:	f9400842 	ldr	x2, [x2, #16]
    82e4:	9100077b 	add	x27, x27, #0x1
    82e8:	f100005f 	cmp	x2, #0x0
    82ec:	fa591362 	ccmp	x27, x25, #0x2, ne	// ne = any
    82f0:	54000322 	b.cs	8354 <f12+0xce4>  // b.hs, b.nlast
    82f4:	cb070040 	sub	x0, x2, x7
    82f8:	eb04001f 	cmp	x0, x4
    82fc:	540002c2 	b.cs	8354 <f12+0xce4>  // b.hs, b.nlast
    8300:	d350fc01 	lsr	x1, x0, #16
    8304:	8b010821 	add	x1, x1, x1, lsl #2
    8308:	d37df021 	lsl	x1, x1, #3
    830c:	8b0100c5 	add	x5, x6, x1
    8310:	f94010a3 	ldr	x3, [x5, #32]
    8314:	b4000203 	cbz	x3, 8354 <f12+0xce4>
    8318:	386168c1 	ldrb	w1, [x6, x1]
    831c:	7100083f 	cmp	w1, #0x2
    8320:	54000820 	b.eq	8424 <f12+0xdb4>  // b.none
    8324:	7100043f 	cmp	w1, #0x1
    8328:	54000161 	b.ne	8354 <f12+0xce4>  // b.any
    832c:	294304a8 	ldp	w8, w1, [x5, #24]
    8330:	92403c00 	and	x0, x0, #0xffff
    8334:	9b087c00 	mul	x0, x0, x8
    8338:	d360fc00 	lsr	x0, x0, #32
    833c:	eb01001f 	cmp	x0, x1
    8340:	540000a2 	b.cs	8354 <f12+0xce4>  // b.hs, b.nlast
    8344:	8b000063 	add	x3, x3, x0
    8348:	39400060 	ldrb	w0, [x3]
    834c:	7100041f 	cmp	w0, #0x1
    8350:	54fffc80 	b.eq	82e0 <f12+0xc70>  // b.none
    8354:	d280001a 	mov	x26, #0x0                   	// #0
    8358:	eb19037f 	cmp	x27, x25
    835c:	540010e2 	b.cs	8578 <f12+0xf08>  // b.hs, b.nlast
    8360:	d1002300 	sub	x0, x24, #0x8
    8364:	aa1903f3 	mov	x19, x25
    8368:	911542f6 	add	x22, x23, #0x550
    836c:	d280001a 	mov	x26, #0x0                   	// #0
    8370:	f9000be0 	str	x0, [sp, #16]
    8374:	9102a3e0 	add	x0, sp, #0xa8
    8378:	f90007e0 	str	x0, [sp, #8]
    837c:	14000012 	b	83c4 <f12+0xd54>
    8380:	7100045f 	cmp	w2, #0x1
    8384:	540001a1 	b.ne	83b8 <f12+0xd48>  // b.any
    8388:	294308a6 	ldp	w6, w2, [x5, #24]
    838c:	92403c21 	and	x1, x1, #0xffff
    8390:	9b067c21 	mul	x1, x1, x6
    8394:	d360fc21 	lsr	x1, x1, #32
    8398:	eb02003f 	cmp	x1, x2
    839c:	540000e2 	b.cs	83b8 <f12+0xd48>  // b.hs, b.nlast
    83a0:	8b010000 	add	x0, x0, x1
    83a4:	39400001 	ldrb	w1, [x0]
    83a8:	7103fc3f 	cmp	w1, #0xff
    83ac:	54000420 	b.eq	8430 <f12+0xdc0>  // b.none
    83b0:	52800021 	mov	w1, #0x1                   	// #1
    83b4:	39000001 	strb	w1, [x0]
    83b8:	d1000673 	sub	x19, x19, #0x1
    83bc:	eb1b027f 	cmp	x19, x27
    83c0:	54000409 	b.ls	8440 <f12+0xdd0>  // b.plast
    83c4:	a94083e1 	ldp	x1, x0, [sp, #8]
    83c8:	f8737802 	ldr	x2, [x0, x19, lsl #3]
    83cc:	52800020 	mov	w0, #0x1                   	// #1
    83d0:	a90aebe2 	stp	x2, x26, [sp, #168]
    83d4:	97fff4c7 	bl	56f0 <fwp_data.part.0.constprop.0>
    83d8:	aa0003fa 	mov	x26, x0
    83dc:	f949dac1 	ldr	x1, [x22, #5040]
    83e0:	f949eec0 	ldr	x0, [x22, #5080]
    83e4:	cb010341 	sub	x1, x26, x1
    83e8:	eb00403f 	cmp	x1, x0, lsl #16
    83ec:	54fffe62 	b.cs	83b8 <f12+0xd48>  // b.hs, b.nlast
    83f0:	d350fc20 	lsr	x0, x1, #16
    83f4:	f949fec6 	ldr	x6, [x22, #5112]
    83f8:	8b000800 	add	x0, x0, x0, lsl #2
    83fc:	d37df002 	lsl	x2, x0, #3
    8400:	8b0200c5 	add	x5, x6, x2
    8404:	f94010a0 	ldr	x0, [x5, #32]
    8408:	b4fffd80 	cbz	x0, 83b8 <f12+0xd48>
    840c:	386268c2 	ldrb	w2, [x6, x2]
    8410:	7100085f 	cmp	w2, #0x2
    8414:	54fffb61 	b.ne	8380 <f12+0xd10>  // b.any
    8418:	72003c3f 	tst	w1, #0xffff
    841c:	54fffce1 	b.ne	83b8 <f12+0xd48>  // b.any
    8420:	17ffffe1 	b	83a4 <f12+0xd34>
    8424:	72003c1f 	tst	w0, #0xffff
    8428:	54fff961 	b.ne	8354 <f12+0xce4>  // b.any
    842c:	17ffffc7 	b	8348 <f12+0xcd8>
    8430:	f9000fe0 	str	x0, [sp, #24]
    8434:	97ffee97 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8438:	f9400fe0 	ldr	x0, [sp, #24]
    843c:	17ffffdd 	b	83b0 <f12+0xd40>
    8440:	d1000721 	sub	x1, x25, #0x1
    8444:	cb190360 	sub	x0, x27, x25
    8448:	eb01037f 	cmp	x27, x1
    844c:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8450:	8b010000 	add	x0, x0, x1
    8454:	b500093b 	cbnz	x27, 8578 <f12+0xf08>
    8458:	7100039f 	cmp	w28, #0x0
    845c:	9a9813fb 	csel	x27, xzr, x24, ne	// ne = any
    8460:	b4000520 	cbz	x0, 8504 <f12+0xe94>
    8464:	d1000413 	sub	x19, x0, #0x1
    8468:	911542f7 	add	x23, x23, #0x550
    846c:	52800039 	mov	w25, #0x1                   	// #1
    8470:	f8737b62 	ldr	x2, [x27, x19, lsl #3]
    8474:	52800020 	mov	w0, #0x1                   	// #1
    8478:	f94007e1 	ldr	x1, [sp, #8]
    847c:	a90aebe2 	stp	x2, x26, [sp, #168]
    8480:	97fff49c 	bl	56f0 <fwp_data.part.0.constprop.0>
    8484:	aa0003fa 	mov	x26, x0
    8488:	f949dae1 	ldr	x1, [x23, #5040]
    848c:	f949eee0 	ldr	x0, [x23, #5080]
    8490:	cb010341 	sub	x1, x26, x1
    8494:	eb00403f 	cmp	x1, x0, lsl #16
    8498:	54000302 	b.cs	84f8 <f12+0xe88>  // b.hs, b.nlast
    849c:	d350fc20 	lsr	x0, x1, #16
    84a0:	f949fee3 	ldr	x3, [x23, #5112]
    84a4:	8b000800 	add	x0, x0, x0, lsl #2
    84a8:	d37df002 	lsl	x2, x0, #3
    84ac:	8b020060 	add	x0, x3, x2
    84b0:	f9401018 	ldr	x24, [x0, #32]
    84b4:	b4000238 	cbz	x24, 84f8 <f12+0xe88>
    84b8:	38626862 	ldrb	w2, [x3, x2]
    84bc:	7100085f 	cmp	w2, #0x2
    84c0:	540004e0 	b.eq	855c <f12+0xeec>  // b.none
    84c4:	7100045f 	cmp	w2, #0x1
    84c8:	54000181 	b.ne	84f8 <f12+0xe88>  // b.any
    84cc:	29430002 	ldp	w2, w0, [x0, #24]
    84d0:	92403c21 	and	x1, x1, #0xffff
    84d4:	9b027c21 	mul	x1, x1, x2
    84d8:	d360fc21 	lsr	x1, x1, #32
    84dc:	eb00003f 	cmp	x1, x0
    84e0:	540000c2 	b.cs	84f8 <f12+0xe88>  // b.hs, b.nlast
    84e4:	8b010318 	add	x24, x24, x1
    84e8:	39400300 	ldrb	w0, [x24]
    84ec:	7103fc1f 	cmp	w0, #0xff
    84f0:	540003c0 	b.eq	8568 <f12+0xef8>  // b.none
    84f4:	39000319 	strb	w25, [x24]
    84f8:	d1000673 	sub	x19, x19, #0x1
    84fc:	b100067f 	cmn	x19, #0x1
    8500:	54fffb81 	b.ne	8470 <f12+0xe00>  // b.any
    8504:	aa1b03e0 	mov	x0, x27
    8508:	97ffeefe 	bl	4100 <fwp_mem_free>
    850c:	aa1503e0 	mov	x0, x21
    8510:	97fff8f0 	bl	68d0 <fwp_drop4>
    8514:	aa1403e0 	mov	x0, x20
    8518:	97fff642 	bl	5e20 <fwp_drop0>
    851c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8520:	f947f400 	ldr	x0, [x0, #4072]
    8524:	f9405fe2 	ldr	x2, [sp, #184]
    8528:	f9400001 	ldr	x1, [x0]
    852c:	eb010042 	subs	x2, x2, x1
    8530:	d2800001 	mov	x1, #0x0                   	// #0
    8534:	54000201 	b.ne	8574 <f12+0xf04>  // b.any
    8538:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    853c:	aa1a03e0 	mov	x0, x26
    8540:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8544:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8548:	a94f63f7 	ldp	x23, x24, [sp, #240]
    854c:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8550:	a95173fb 	ldp	x27, x28, [sp, #272]
    8554:	910483ff 	add	sp, sp, #0x120
    8558:	d65f03c0 	ret
    855c:	72003c3f 	tst	w1, #0xffff
    8560:	54fffcc1 	b.ne	84f8 <f12+0xe88>  // b.any
    8564:	17ffffe1 	b	84e8 <f12+0xe78>
    8568:	aa1803e0 	mov	x0, x24
    856c:	97ffee49 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8570:	17ffffe1 	b	84f4 <f12+0xe84>
    8574:	97ffe89f 	bl	27f0 <__stack_chk_fail@plt>
    8578:	aa1403e0 	mov	x0, x20
    857c:	d2800001 	mov	x1, #0x0                   	// #0
    8580:	f8617b02 	ldr	x2, [x24, x1, lsl #3]
    8584:	91000421 	add	x1, x1, #0x1
    8588:	f9000402 	str	x2, [x0, #8]
    858c:	aa0003e2 	mov	x2, x0
    8590:	f9400800 	ldr	x0, [x0, #16]
    8594:	eb01037f 	cmp	x27, x1
    8598:	54ffff48 	b.hi	8580 <f12+0xf10>  // b.pmore
    859c:	f900085a 	str	x26, [x2, #16]
    85a0:	aa1403fa 	mov	x26, x20
    85a4:	aa0003f4 	mov	x20, x0
    85a8:	7100039f 	cmp	w28, #0x0
    85ac:	9a9813fb 	csel	x27, xzr, x24, ne	// ne = any
    85b0:	17ffffd5 	b	8504 <f12+0xe94>
    85b4:	d280001b 	mov	x27, #0x0                   	// #0
    85b8:	17ffff6a 	b	8360 <f12+0xcf0>
    85bc:	52800041 	mov	w1, #0x2                   	// #2
    85c0:	d2800100 	mov	x0, #0x8                   	// #8
    85c4:	97fff18b 	bl	4bf0 <fwp_heap_alloc>
    85c8:	aa0003f8 	mov	x24, x0
    85cc:	5280001c 	mov	w28, #0x0                   	// #0
    85d0:	d280001a 	mov	x26, #0x0                   	// #0
    85d4:	17fffff5 	b	85a8 <f12+0xf38>
    85d8:	aa1303e0 	mov	x0, x19
    85dc:	97ffee2d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    85e0:	17ffff10 	b	8220 <f12+0xbb0>
    85e4:	72003c3f 	tst	w1, #0xffff
    85e8:	54ffe160 	b.eq	8214 <f12+0xba4>  // b.none
    85ec:	aa1b03e0 	mov	x0, x27
    85f0:	17fffe6b 	b	7f9c <f12+0x92c>
    85f4:	f94002d9 	ldr	x25, [x22]
    85f8:	b7fffe39 	tbnz	x25, #63, 85bc <f12+0xf4c>
    85fc:	9240fb39 	and	x25, x25, #0x7fffffffffffffff
    8600:	d2800013 	mov	x19, #0x0                   	// #0
    8604:	17fffe81 	b	8008 <f12+0x998>
    8608:	aa1303e0 	mov	x0, x19
    860c:	97ffee21 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8610:	910102c0 	add	x0, x22, #0x40
    8614:	f9416015 	ldr	x21, [x0, #704]
    8618:	17fffe36 	b	7ef0 <f12+0x880>
    861c:	97ffe8f9 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8620:	97ffe888 	bl	2840 <abort@plt>

0000000000008624 <fwp_owned_entry12>:
    8624:	f9400000 	ldr	x0, [x0]
    8628:	17fffc12 	b	7670 <f12>
    862c:	d503201f 	nop

0000000000008630 <e12>:
    8630:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8634:	910003fd 	mov	x29, sp
    8638:	f9000bf3 	str	x19, [sp, #16]
    863c:	f9400013 	ldr	x19, [x0]
    8640:	aa1303e0 	mov	x0, x19
    8644:	97fff473 	bl	5810 <fwp_rc_share>
    8648:	aa1303e0 	mov	x0, x19
    864c:	97fffc09 	bl	7670 <f12>
    8650:	aa0003f3 	mov	x19, x0
    8654:	97fff46f 	bl	5810 <fwp_rc_share>
    8658:	aa1303e0 	mov	x0, x19
    865c:	f9400bf3 	ldr	x19, [sp, #16]
    8660:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8664:	d65f03c0 	ret
    8668:	d503201f 	nop
    866c:	d503201f 	nop

0000000000008670 <fwp_write>:
    8670:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8674:	910003fd 	mov	x29, sp
    8678:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    867c:	f947f484 	ldr	x4, [x4, #4072]
    8680:	a90153f3 	stp	x19, x20, [sp, #16]
    8684:	d10943ff 	sub	sp, sp, #0x250
    8688:	b9400045 	ldr	w5, [x2]
    868c:	aa0003f4 	mov	x20, x0
    8690:	f9400080 	ldr	x0, [x4]
    8694:	f90127e0 	str	x0, [sp, #584]
    8698:	d2800000 	mov	x0, #0x0                   	// #0
    869c:	710064bf 	cmp	w5, #0x19
    86a0:	54000408 	b.hi	8720 <fwp_write+0xb0>  // b.pmore
    86a4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x920>
    86a8:	aa0103f3 	mov	x19, x1
    86ac:	910c4000 	add	x0, x0, #0x310
    86b0:	f9013bf5 	str	x21, [sp, #624]
    86b4:	f9013ff6 	str	x22, [sp, #632]
    86b8:	f90153fb 	str	x27, [sp, #672]
    86bc:	f90157fc 	str	x28, [sp, #680]
    86c0:	aa0203fc 	mov	x28, x2
    86c4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    86c8:	10000061 	adr	x1, 86d4 <fwp_write+0x64>
    86cc:	8b20a820 	add	x0, x1, w0, sxth #2
    86d0:	d61f0000 	br	x0
    86d4:	910123e0 	add	x0, sp, #0x48
    86d8:	aa1303e5 	mov	x5, x19
    86dc:	b0000024 	adrp	x4, d000 <__divti3+0x40>
    86e0:	aa0003f3 	mov	x19, x0
    86e4:	912f2084 	add	x4, x4, #0xbc8
    86e8:	d2804003 	mov	x3, #0x200                 	// #512
    86ec:	aa0303e1 	mov	x1, x3
    86f0:	52800042 	mov	w2, #0x2                   	// #2
    86f4:	97ffe81b 	bl	2760 <__snprintf_chk@plt>
    86f8:	aa1303e0 	mov	x0, x19
    86fc:	97ffe7e1 	bl	2680 <strlen@plt>
    8700:	aa1303e1 	mov	x1, x19
    8704:	aa0003e2 	mov	x2, x0
    8708:	aa1403e0 	mov	x0, x20
    870c:	97ffeb21 	bl	3390 <buf_put>
    8710:	f9413bf5 	ldr	x21, [sp, #624]
    8714:	f9413ff6 	ldr	x22, [sp, #632]
    8718:	f94153fb 	ldr	x27, [sp, #672]
    871c:	f94157fc 	ldr	x28, [sp, #680]
    8720:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8724:	f947f400 	ldr	x0, [x0, #4072]
    8728:	f94127e2 	ldr	x2, [sp, #584]
    872c:	f9400001 	ldr	x1, [x0]
    8730:	eb010042 	subs	x2, x2, x1
    8734:	d2800001 	mov	x1, #0x0                   	// #0
    8738:	540077c1 	b.ne	9630 <fwp_write+0xfc0>  // b.any
    873c:	910943ff 	add	sp, sp, #0x250
    8740:	a94153f3 	ldp	x19, x20, [sp, #16]
    8744:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8748:	d65f03c0 	ret
    874c:	910123e0 	add	x0, sp, #0x48
    8750:	aa1303e5 	mov	x5, x19
    8754:	b0000024 	adrp	x4, d000 <__divti3+0x40>
    8758:	aa0003f3 	mov	x19, x0
    875c:	912f0084 	add	x4, x4, #0xbc0
    8760:	d2804003 	mov	x3, #0x200                 	// #512
    8764:	17ffffe2 	b	86ec <fwp_write+0x7c>
    8768:	71004cbf 	cmp	w5, #0x13
    876c:	b0000020 	adrp	x0, d000 <__divti3+0x40>
    8770:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8774:	912ec000 	add	x0, x0, #0xbb0
    8778:	912ee021 	add	x1, x1, #0xbb8
    877c:	d2800082 	mov	x2, #0x4                   	// #4
    8780:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8784:	aa1403e0 	mov	x0, x20
    8788:	f90143f7 	str	x23, [sp, #640]
    878c:	d2800016 	mov	x22, #0x0                   	// #0
    8790:	f90147f8 	str	x24, [sp, #648]
    8794:	97ffeaff 	bl	3390 <buf_put>
    8798:	f9400260 	ldr	x0, [x19]
    879c:	b0000037 	adrp	x23, d000 <__divti3+0x40>
    87a0:	d2800015 	mov	x21, #0x0                   	// #0
    87a4:	9130e2f7 	add	x23, x23, #0xc38
    87a8:	b40047a0 	cbz	x0, 909c <fwp_write+0xa2c>
    87ac:	b9400380 	ldr	w0, [x28]
    87b0:	52800003 	mov	w3, #0x0                   	// #0
    87b4:	f9401f82 	ldr	x2, [x28, #56]
    87b8:	71004c1f 	cmp	w0, #0x13
    87bc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    87c0:	aa1403e0 	mov	x0, x20
    87c4:	8b010e61 	add	x1, x19, x1, lsl #3
    87c8:	f9400421 	ldr	x1, [x1, #8]
    87cc:	97ffffa9 	bl	8670 <fwp_write>
    87d0:	b9400380 	ldr	w0, [x28]
    87d4:	7100481f 	cmp	w0, #0x12
    87d8:	54004b40 	b.eq	9140 <fwp_write+0xad0>  // b.none
    87dc:	f9400260 	ldr	x0, [x19]
    87e0:	910006b5 	add	x21, x21, #0x1
    87e4:	91000ad6 	add	x22, x22, #0x2
    87e8:	eb15001f 	cmp	x0, x21
    87ec:	54004589 	b.ls	909c <fwp_write+0xa2c>  // b.plast
    87f0:	aa1703e1 	mov	x1, x23
    87f4:	aa1403e0 	mov	x0, x20
    87f8:	d2800042 	mov	x2, #0x2                   	// #2
    87fc:	97ffeae5 	bl	3390 <buf_put>
    8800:	17ffffeb 	b	87ac <fwp_write+0x13c>
    8804:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8808:	912fc021 	add	x1, x1, #0xbf0
    880c:	d28000c2 	mov	x2, #0x6                   	// #6
    8810:	aa1403e0 	mov	x0, x20
    8814:	91004273 	add	x19, x19, #0x10
    8818:	97ffeade 	bl	3390 <buf_put>
    881c:	aa1303e0 	mov	x0, x19
    8820:	97ffe798 	bl	2680 <strlen@plt>
    8824:	aa1303e1 	mov	x1, x19
    8828:	aa0003e2 	mov	x2, x0
    882c:	aa1403e0 	mov	x0, x20
    8830:	97ffead8 	bl	3390 <buf_put>
    8834:	528007c3 	mov	w3, #0x3e                  	// #62
    8838:	aa1403e0 	mov	x0, x20
    883c:	91001fe1 	add	x1, sp, #0x7
    8840:	d2800022 	mov	x2, #0x1                   	// #1
    8844:	39001fe3 	strb	w3, [sp, #7]
    8848:	17ffffb1 	b	870c <fwp_write+0x9c>
    884c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8850:	f947f400 	ldr	x0, [x0, #4072]
    8854:	f94127e2 	ldr	x2, [sp, #584]
    8858:	f9400001 	ldr	x1, [x0]
    885c:	eb010042 	subs	x2, x2, x1
    8860:	d2800001 	mov	x1, #0x0                   	// #0
    8864:	540034e1 	b.ne	8f00 <fwp_write+0x890>  // b.any
    8868:	f9413bf5 	ldr	x21, [sp, #624]
    886c:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8870:	f9413ff6 	ldr	x22, [sp, #632]
    8874:	aa1403e0 	mov	x0, x20
    8878:	912f4021 	add	x1, x1, #0xbd0
    887c:	d2800142 	mov	x2, #0xa                   	// #10
    8880:	f94153fb 	ldr	x27, [sp, #672]
    8884:	f94157fc 	ldr	x28, [sp, #680]
    8888:	910943ff 	add	sp, sp, #0x250
    888c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8890:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8894:	17ffeabf 	b	3390 <buf_put>
    8898:	f9400456 	ldr	x22, [x2, #8]
    889c:	f90143f7 	str	x23, [sp, #640]
    88a0:	f90147f8 	str	x24, [sp, #648]
    88a4:	b4005b16 	cbz	x22, 9404 <fwp_write+0xd94>
    88a8:	aa1603e0 	mov	x0, x22
    88ac:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    88b0:	91314021 	add	x1, x1, #0xc50
    88b4:	97ffe7ef 	bl	2870 <strcmp@plt>
    88b8:	2a0003f5 	mov	w21, w0
    88bc:	34005fe0 	cbz	w0, 94b8 <fwp_write+0xe48>
    88c0:	aa1603e0 	mov	x0, x22
    88c4:	97ffe76f 	bl	2680 <strlen@plt>
    88c8:	aa1603e1 	mov	x1, x22
    88cc:	aa0003e2 	mov	x2, x0
    88d0:	aa1403e0 	mov	x0, x20
    88d4:	97ffeaaf 	bl	3390 <buf_put>
    88d8:	52800403 	mov	w3, #0x20                  	// #32
    88dc:	91001ff5 	add	x21, sp, #0x7
    88e0:	aa1503e1 	mov	x1, x21
    88e4:	aa1403e0 	mov	x0, x20
    88e8:	d2800022 	mov	x2, #0x1                   	// #1
    88ec:	39001fe3 	strb	w3, [sp, #7]
    88f0:	97ffeaa8 	bl	3390 <buf_put>
    88f4:	52800f63 	mov	w3, #0x7b                  	// #123
    88f8:	aa1403e0 	mov	x0, x20
    88fc:	aa1503e1 	mov	x1, x21
    8900:	d2800022 	mov	x2, #0x1                   	// #1
    8904:	39001fe3 	strb	w3, [sp, #7]
    8908:	97ffeaa2 	bl	3390 <buf_put>
    890c:	b9401380 	ldr	w0, [x28, #16]
    8910:	52800018 	mov	w24, #0x0                   	// #0
    8914:	7100001f 	cmp	w0, #0x0
    8918:	54003aad 	b.le	906c <fwp_write+0x9fc>
    891c:	f9014bf9 	str	x25, [sp, #656]
    8920:	b0000039 	adrp	x25, d000 <__divti3+0x40>
    8924:	9131e339 	add	x25, x25, #0xc78
    8928:	f9014ffa 	str	x26, [sp, #664]
    892c:	b000003a 	adrp	x26, d000 <__divti3+0x40>
    8930:	9130e35a 	add	x26, x26, #0xc38
    8934:	91002276 	add	x22, x19, #0x8
    8938:	d2800013 	mov	x19, #0x0                   	// #0
    893c:	b5003e93 	cbnz	x19, 910c <fwp_write+0xa9c>
    8940:	d37df277 	lsl	x23, x19, #3
    8944:	34003cb8 	cbz	w24, 90d8 <fwp_write+0xa68>
    8948:	f9401382 	ldr	x2, [x28, #32]
    894c:	aa1403e0 	mov	x0, x20
    8950:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8954:	52800003 	mov	w3, #0x0                   	// #0
    8958:	f8776842 	ldr	x2, [x2, x23]
    895c:	91000673 	add	x19, x19, #0x1
    8960:	97ffff44 	bl	8670 <fwp_write>
    8964:	b9401380 	ldr	w0, [x28, #16]
    8968:	6b13001f 	cmp	w0, w19
    896c:	54fffe8c 	b.gt	893c <fwp_write+0x2cc>
    8970:	f9414bf9 	ldr	x25, [sp, #656]
    8974:	f9414ffa 	ldr	x26, [sp, #664]
    8978:	340037b8 	cbz	w24, 906c <fwp_write+0x9fc>
    897c:	52800523 	mov	w3, #0x29                  	// #41
    8980:	aa1503e1 	mov	x1, x21
    8984:	aa1403e0 	mov	x0, x20
    8988:	d2800022 	mov	x2, #0x1                   	// #1
    898c:	39001fe3 	strb	w3, [sp, #7]
    8990:	97ffea80 	bl	3390 <buf_put>
    8994:	f9413bf5 	ldr	x21, [sp, #624]
    8998:	f9413ff6 	ldr	x22, [sp, #632]
    899c:	f94143f7 	ldr	x23, [sp, #640]
    89a0:	f94147f8 	ldr	x24, [sp, #648]
    89a4:	f94153fb 	ldr	x27, [sp, #672]
    89a8:	f94157fc 	ldr	x28, [sp, #680]
    89ac:	17ffff5d 	b	8720 <fwp_write+0xb0>
    89b0:	b9404855 	ldr	w21, [x2, #72]
    89b4:	aa1403e0 	mov	x0, x20
    89b8:	93407eb6 	sxtw	x22, w21
    89bc:	91000ac1 	add	x1, x22, #0x2
    89c0:	97ffea41 	bl	32c4 <buf_grow>
    89c4:	a9400281 	ldp	x1, x0, [x20]
    89c8:	528e8603 	mov	w3, #0x7430                	// #29744
    89cc:	78206823 	strh	w3, [x1, x0]
    89d0:	8b000022 	add	x2, x1, x0
    89d4:	710002bf 	cmp	w21, #0x0
    89d8:	540036cd 	b.le	90b0 <fwp_write+0xa40>
    89dc:	110006a3 	add	w3, w21, #0x1
    89e0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    89e4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    89e8:	91000449 	add	x9, x2, #0x1
    89ec:	8b23c043 	add	x3, x2, w3, sxtw
    89f0:	f28aaac6 	movk	x6, #0x5556
    89f4:	f2955568 	movk	x8, #0xaaab
    89f8:	1400000d 	b	8a2c <fwp_write+0x3bc>
    89fc:	d2800021 	mov	x1, #0x1                   	// #1
    8a00:	528005a5 	mov	w5, #0x2d                  	// #45
    8a04:	f100001f 	cmp	x0, #0x0
    8a08:	9b467e60 	smulh	x0, x19, x6
    8a0c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8a10:	381ff465 	strb	w5, [x3], #-1
    8a14:	cb040000 	sub	x0, x0, x4
    8a18:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8a1c:	cb020000 	sub	x0, x0, x2
    8a20:	8b010013 	add	x19, x0, x1
    8a24:	eb03013f 	cmp	x9, x3
    8a28:	54003440 	b.eq	90b0 <fwp_write+0xa40>  // b.none
    8a2c:	9b467e60 	smulh	x0, x19, x6
    8a30:	937ffe64 	asr	x4, x19, #63
    8a34:	52800605 	mov	w5, #0x30                  	// #48
    8a38:	cb040000 	sub	x0, x0, x4
    8a3c:	8b000400 	add	x0, x0, x0, lsl #1
    8a40:	cb000260 	sub	x0, x19, x0
    8a44:	91000c01 	add	x1, x0, #0x3
    8a48:	9bc87c22 	umulh	x2, x1, x8
    8a4c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8a50:	8b4204e2 	add	x2, x7, x2, lsr #1
    8a54:	eb020021 	subs	x1, x1, x2
    8a58:	54fffd60 	b.eq	8a04 <fwp_write+0x394>  // b.none
    8a5c:	f100043f 	cmp	x1, #0x1
    8a60:	54fffce1 	b.ne	89fc <fwp_write+0x38c>  // b.any
    8a64:	d2800001 	mov	x1, #0x0                   	// #0
    8a68:	52800565 	mov	w5, #0x2b                  	// #43
    8a6c:	17ffffe6 	b	8a04 <fwp_write+0x394>
    8a70:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a74:	f947f400 	ldr	x0, [x0, #4072]
    8a78:	f94127e2 	ldr	x2, [sp, #584]
    8a7c:	f9400001 	ldr	x1, [x0]
    8a80:	eb010042 	subs	x2, x2, x1
    8a84:	d2800001 	mov	x1, #0x0                   	// #0
    8a88:	540023c1 	b.ne	8f00 <fwp_write+0x890>  // b.any
    8a8c:	f9413bf5 	ldr	x21, [sp, #624]
    8a90:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8a94:	f9413ff6 	ldr	x22, [sp, #632]
    8a98:	aa1403e0 	mov	x0, x20
    8a9c:	912f8021 	add	x1, x1, #0xbe0
    8aa0:	d2800102 	mov	x2, #0x8                   	// #8
    8aa4:	17ffff77 	b	8880 <fwp_write+0x210>
    8aa8:	aa1403e0 	mov	x0, x20
    8aac:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8ab0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ab4:	91310021 	add	x1, x1, #0xc40
    8ab8:	97ffea36 	bl	3390 <buf_put>
    8abc:	d2800015 	mov	x21, #0x0                   	// #0
    8ac0:	f9400263 	ldr	x3, [x19]
    8ac4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8ac8:	54002c60 	b.eq	9054 <fwp_write+0x9e4>  // b.none
    8acc:	f9401f82 	ldr	x2, [x28, #56]
    8ad0:	f90143f7 	str	x23, [sp, #640]
    8ad4:	f90147f8 	str	x24, [sp, #648]
    8ad8:	d2800857 	mov	x23, #0x42                  	// #66
    8adc:	f9014bf9 	str	x25, [sp, #656]
    8ae0:	b0000036 	adrp	x22, d000 <__divti3+0x40>
    8ae4:	f9014ffa 	str	x26, [sp, #664]
    8ae8:	9130e2d6 	add	x22, x22, #0xc38
    8aec:	d2800038 	mov	x24, #0x1                   	// #1
    8af0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8af4:	d2809099 	mov	x25, #0x484                 	// #1156
    8af8:	b40004a2 	cbz	x2, 8b8c <fwp_write+0x51c>
    8afc:	b9400040 	ldr	w0, [x2]
    8b00:	7100701f 	cmp	w0, #0x1c
    8b04:	540042c0 	b.eq	935c <fwp_write+0xcec>  // b.none
    8b08:	71006c1f 	cmp	w0, #0x1b
    8b0c:	54000408 	b.hi	8b8c <fwp_write+0x51c>  // b.pmore
    8b10:	9ac02301 	lsl	x1, x24, x0
    8b14:	ea17003f 	tst	x1, x23
    8b18:	540036a1 	b.ne	91ec <fwp_write+0xb7c>  // b.any
    8b1c:	ea19003f 	tst	x1, x25
    8b20:	54003521 	b.ne	91c4 <fwp_write+0xb54>  // b.any
    8b24:	d2800424 	mov	x4, #0x21                  	// #33
    8b28:	ea04003f 	tst	x1, x4
    8b2c:	54000300 	b.eq	8b8c <fwp_write+0x51c>  // b.none
    8b30:	b7f849c3 	tbnz	x3, #63, 9468 <fwp_write+0xdf8>
    8b34:	91002261 	add	x1, x19, #0x8
    8b38:	8b150021 	add	x1, x1, x21
    8b3c:	39400021 	ldrb	w1, [x1]
    8b40:	7100001f 	cmp	w0, #0x0
    8b44:	93401c23 	sxtb	x3, w1
    8b48:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8b4c:	d503201f 	nop
    8b50:	aa1403e0 	mov	x0, x20
    8b54:	52800003 	mov	w3, #0x0                   	// #0
    8b58:	97fffec6 	bl	8670 <fwp_write>
    8b5c:	910006b5 	add	x21, x21, #0x1
    8b60:	f9400260 	ldr	x0, [x19]
    8b64:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8b68:	eb0002bf 	cmp	x21, x0
    8b6c:	540026c2 	b.cs	9044 <fwp_write+0x9d4>  // b.hs, b.nlast
    8b70:	d2800042 	mov	x2, #0x2                   	// #2
    8b74:	aa1603e1 	mov	x1, x22
    8b78:	aa1403e0 	mov	x0, x20
    8b7c:	97ffea05 	bl	3390 <buf_put>
    8b80:	f9401f82 	ldr	x2, [x28, #56]
    8b84:	f9400263 	ldr	x3, [x19]
    8b88:	b5fffba2 	cbnz	x2, 8afc <fwp_write+0x48c>
    8b8c:	d37df2a0 	lsl	x0, x21, #3
    8b90:	b7f83f03 	tbnz	x3, #63, 9370 <fwp_write+0xd00>
    8b94:	91002261 	add	x1, x19, #0x8
    8b98:	8b000020 	add	x0, x1, x0
    8b9c:	f9400001 	ldr	x1, [x0]
    8ba0:	17ffffec 	b	8b50 <fwp_write+0x4e0>
    8ba4:	a9400e62 	ldp	x2, x3, [x19]
    8ba8:	b7f83ca3 	tbnz	x3, #63, 933c <fwp_write+0xccc>
    8bac:	910123f5 	add	x21, sp, #0x48
    8bb0:	aa1503e0 	mov	x0, x21
    8bb4:	97ffe87b 	bl	2da0 <fwp_fmt_u128>
    8bb8:	aa1503e0 	mov	x0, x21
    8bbc:	97ffe6b1 	bl	2680 <strlen@plt>
    8bc0:	aa1503e1 	mov	x1, x21
    8bc4:	aa0003e2 	mov	x2, x0
    8bc8:	17fffed0 	b	8708 <fwp_write+0x98>
    8bcc:	fd015be8 	str	d8, [sp, #688]
    8bd0:	1e270268 	fmov	s8, w19
    8bd4:	fd015fe9 	str	d9, [sp, #696]
    8bd8:	1e282100 	fcmp	s8, s8
    8bdc:	54004d26 	b.vs	9580 <fwp_write+0xf10>
    8be0:	1e20c101 	fabs	s1, s8
    8be4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8be8:	1e270000 	fmov	s0, w0
    8bec:	1e202020 	fcmp	s1, s0
    8bf0:	54002c0d 	b.le	9170 <fwp_write+0xb00>
    8bf4:	1e202118 	fcmpe	s8, #0.0
    8bf8:	b0000022 	adrp	x2, d000 <__divti3+0x40>
    8bfc:	911c0042 	add	x2, x2, #0x700
    8c00:	910123f5 	add	x21, sp, #0x48
    8c04:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8c08:	912e4021 	add	x1, x1, #0xb90
    8c0c:	aa1503e0 	mov	x0, x21
    8c10:	9a81c041 	csel	x1, x2, x1, gt
    8c14:	97ffe747 	bl	2930 <strcpy@plt>
    8c18:	aa1503e0 	mov	x0, x21
    8c1c:	97ffe699 	bl	2680 <strlen@plt>
    8c20:	aa1503e1 	mov	x1, x21
    8c24:	aa0003e2 	mov	x2, x0
    8c28:	aa1403e0 	mov	x0, x20
    8c2c:	97ffe9d9 	bl	3390 <buf_put>
    8c30:	f9413bf5 	ldr	x21, [sp, #624]
    8c34:	f9413ff6 	ldr	x22, [sp, #632]
    8c38:	f94153fb 	ldr	x27, [sp, #672]
    8c3c:	f94157fc 	ldr	x28, [sp, #680]
    8c40:	fd415be8 	ldr	d8, [sp, #688]
    8c44:	fd415fe9 	ldr	d9, [sp, #696]
    8c48:	17fffeb6 	b	8720 <fwp_write+0xb0>
    8c4c:	f9400276 	ldr	x22, [x19]
    8c50:	34002e03 	cbz	w3, 9210 <fwp_write+0xba0>
    8c54:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8c58:	f947f400 	ldr	x0, [x0, #4072]
    8c5c:	f94127e2 	ldr	x2, [sp, #584]
    8c60:	f9400001 	ldr	x1, [x0]
    8c64:	eb010042 	subs	x2, x2, x1
    8c68:	d2800001 	mov	x1, #0x0                   	// #0
    8c6c:	540014a1 	b.ne	8f00 <fwp_write+0x890>  // b.any
    8c70:	aa1603e2 	mov	x2, x22
    8c74:	91002261 	add	x1, x19, #0x8
    8c78:	f9413bf5 	ldr	x21, [sp, #624]
    8c7c:	aa1403e0 	mov	x0, x20
    8c80:	f9413ff6 	ldr	x22, [sp, #632]
    8c84:	17fffeff 	b	8880 <fwp_write+0x210>
    8c88:	fd015be8 	str	d8, [sp, #688]
    8c8c:	9e670268 	fmov	d8, x19
    8c90:	fd015fe9 	str	d9, [sp, #696]
    8c94:	1e682100 	fcmp	d8, d8
    8c98:	54004746 	b.vs	9580 <fwp_write+0xf10>
    8c9c:	1e60c101 	fabs	d1, d8
    8ca0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8ca4:	9e670000 	fmov	d0, x0
    8ca8:	910123f5 	add	x21, sp, #0x48
    8cac:	52800033 	mov	w19, #0x1                   	// #1
    8cb0:	1e602020 	fcmp	d1, d0
    8cb4:	540001ad 	b.le	8ce8 <fwp_write+0x678>
    8cb8:	1e602118 	fcmpe	d8, #0.0
    8cbc:	b0000022 	adrp	x2, d000 <__divti3+0x40>
    8cc0:	911c0042 	add	x2, x2, #0x700
    8cc4:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8cc8:	912e4021 	add	x1, x1, #0xb90
    8ccc:	aa1503e0 	mov	x0, x21
    8cd0:	9a81c041 	csel	x1, x2, x1, gt
    8cd4:	97ffe717 	bl	2930 <strcpy@plt>
    8cd8:	17ffffd0 	b	8c18 <fwp_write+0x5a8>
    8cdc:	11000673 	add	w19, w19, #0x1
    8ce0:	71004a7f 	cmp	w19, #0x12
    8ce4:	54003860 	b.eq	93f0 <fwp_write+0xd80>  // b.none
    8ce8:	1e604100 	fmov	d0, d8
    8cec:	2a1303e1 	mov	w1, w19
    8cf0:	aa1503e0 	mov	x0, x21
    8cf4:	97ffea03 	bl	3500 <fwp_format_g.constprop.0>
    8cf8:	aa1503e0 	mov	x0, x21
    8cfc:	d2800001 	mov	x1, #0x0                   	// #0
    8d00:	97ffe674 	bl	26d0 <strtod@plt>
    8d04:	1e602100 	fcmp	d8, d0
    8d08:	54fffea1 	b.ne	8cdc <fwp_write+0x66c>  // b.any
    8d0c:	aa1503e0 	mov	x0, x21
    8d10:	97ffe9d9 	bl	3474 <fwp_finish_float>
    8d14:	17ffffc1 	b	8c18 <fwp_write+0x5a8>
    8d18:	a9400e62 	ldp	x2, x3, [x19]
    8d1c:	910123f3 	add	x19, sp, #0x48
    8d20:	aa1303e0 	mov	x0, x19
    8d24:	97ffe81f 	bl	2da0 <fwp_fmt_u128>
    8d28:	17fffe74 	b	86f8 <fwp_write+0x88>
    8d2c:	f90143f7 	str	x23, [sp, #640]
    8d30:	f90147f8 	str	x24, [sp, #648]
    8d34:	2a1303f8 	mov	w24, w19
    8d38:	f9014bf9 	str	x25, [sp, #656]
    8d3c:	f9014ffa 	str	x26, [sp, #664]
    8d40:	f13ffe7f 	cmp	x19, #0xfff
    8d44:	54000049 	b.ls	8d4c <fwp_write+0x6dc>  // b.plast
    8d48:	b9400278 	ldr	w24, [x19]
    8d4c:	f9400f80 	ldr	x0, [x28, #24]
    8d50:	2a1803f5 	mov	w21, w24
    8d54:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8d58:	d37ef6b9 	lsl	x25, x21, #2
    8d5c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8d60:	aa1603e0 	mov	x0, x22
    8d64:	97ffe647 	bl	2680 <strlen@plt>
    8d68:	aa1603e1 	mov	x1, x22
    8d6c:	aa0003e2 	mov	x2, x0
    8d70:	aa1403e0 	mov	x0, x20
    8d74:	97ffe987 	bl	3390 <buf_put>
    8d78:	f9401780 	ldr	x0, [x28, #40]
    8d7c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8d80:	7100001f 	cmp	w0, #0x0
    8d84:	5400068d 	b.le	8e54 <fwp_write+0x7e4>
    8d88:	91002276 	add	x22, x19, #0x8
    8d8c:	91001ff5 	add	x21, sp, #0x7
    8d90:	d280001b 	mov	x27, #0x0                   	// #0
    8d94:	5280041a 	mov	w26, #0x20                  	// #32
    8d98:	f9401b80 	ldr	x0, [x28, #48]
    8d9c:	aa1503e1 	mov	x1, x21
    8da0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8da4:	d2800022 	mov	x2, #0x1                   	// #1
    8da8:	f8786803 	ldr	x3, [x0, x24]
    8dac:	aa1403e0 	mov	x0, x20
    8db0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8db4:	39001ffa 	strb	w26, [sp, #7]
    8db8:	97ffe976 	bl	3390 <buf_put>
    8dbc:	f13ffeff 	cmp	x23, #0xfff
    8dc0:	b9400261 	ldr	w1, [x19]
    8dc4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8dc8:	7100383f 	cmp	w1, #0xe
    8dcc:	54000160 	b.eq	8df8 <fwp_write+0x788>  // b.none
    8dd0:	7100403f 	cmp	w1, #0x10
    8dd4:	54001a60 	b.eq	9120 <fwp_write+0xab0>  // b.none
    8dd8:	7100283f 	cmp	w1, #0xa
    8ddc:	54002aa0 	b.eq	9330 <fwp_write+0xcc0>  // b.none
    8de0:	540014ac 	b.gt	9074 <fwp_write+0xa04>
    8de4:	71000c3f 	cmp	w1, #0x3
    8de8:	540029ac 	b.gt	931c <fwp_write+0xcac>
    8dec:	d37ffee0 	lsr	x0, x23, #63
    8df0:	37f814a1 	tbnz	w1, #31, 9084 <fwp_write+0xa14>
    8df4:	d503201f 	nop
    8df8:	34001460 	cbz	w0, 9084 <fwp_write+0xa14>
    8dfc:	52800503 	mov	w3, #0x28                  	// #40
    8e00:	aa1503e1 	mov	x1, x21
    8e04:	aa1403e0 	mov	x0, x20
    8e08:	d2800022 	mov	x2, #0x1                   	// #1
    8e0c:	39001fe3 	strb	w3, [sp, #7]
    8e10:	97ffe960 	bl	3390 <buf_put>
    8e14:	aa1303e2 	mov	x2, x19
    8e18:	aa1703e1 	mov	x1, x23
    8e1c:	aa1403e0 	mov	x0, x20
    8e20:	52800003 	mov	w3, #0x0                   	// #0
    8e24:	97fffe13 	bl	8670 <fwp_write>
    8e28:	52800523 	mov	w3, #0x29                  	// #41
    8e2c:	aa1503e1 	mov	x1, x21
    8e30:	aa1403e0 	mov	x0, x20
    8e34:	d2800022 	mov	x2, #0x1                   	// #1
    8e38:	39001fe3 	strb	w3, [sp, #7]
    8e3c:	97ffe955 	bl	3390 <buf_put>
    8e40:	f9401780 	ldr	x0, [x28, #40]
    8e44:	9100077b 	add	x27, x27, #0x1
    8e48:	b8796800 	ldr	w0, [x0, x25]
    8e4c:	6b1b001f 	cmp	w0, w27
    8e50:	54fffa4c 	b.gt	8d98 <fwp_write+0x728>
    8e54:	f9413bf5 	ldr	x21, [sp, #624]
    8e58:	f9413ff6 	ldr	x22, [sp, #632]
    8e5c:	f94143f7 	ldr	x23, [sp, #640]
    8e60:	f94147f8 	ldr	x24, [sp, #648]
    8e64:	f9414bf9 	ldr	x25, [sp, #656]
    8e68:	f9414ffa 	ldr	x26, [sp, #664]
    8e6c:	f94153fb 	ldr	x27, [sp, #672]
    8e70:	f94157fc 	ldr	x28, [sp, #680]
    8e74:	17fffe2b 	b	8720 <fwp_write+0xb0>
    8e78:	52800783 	mov	w3, #0x3c                  	// #60
    8e7c:	91001ff3 	add	x19, sp, #0x7
    8e80:	aa1303e1 	mov	x1, x19
    8e84:	d2800022 	mov	x2, #0x1                   	// #1
    8e88:	aa1403e0 	mov	x0, x20
    8e8c:	39001fe3 	strb	w3, [sp, #7]
    8e90:	97ffe940 	bl	3390 <buf_put>
    8e94:	f9400795 	ldr	x21, [x28, #8]
    8e98:	aa1503e0 	mov	x0, x21
    8e9c:	97ffe5f9 	bl	2680 <strlen@plt>
    8ea0:	aa1503e1 	mov	x1, x21
    8ea4:	aa0003e2 	mov	x2, x0
    8ea8:	aa1403e0 	mov	x0, x20
    8eac:	97ffe939 	bl	3390 <buf_put>
    8eb0:	528007c3 	mov	w3, #0x3e                  	// #62
    8eb4:	aa1303e1 	mov	x1, x19
    8eb8:	aa1403e0 	mov	x0, x20
    8ebc:	d2800022 	mov	x2, #0x1                   	// #1
    8ec0:	39001fe3 	strb	w3, [sp, #7]
    8ec4:	17fffe12 	b	870c <fwp_write+0x9c>
    8ec8:	f100067f 	cmp	x19, #0x1
    8ecc:	540025a0 	b.eq	9380 <fwp_write+0xd10>  // b.none
    8ed0:	b100067f 	cmn	x19, #0x1
    8ed4:	54002bc0 	b.eq	944c <fwp_write+0xddc>  // b.none
    8ed8:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8edc:	912e6021 	add	x1, x1, #0xb98
    8ee0:	d2800022 	mov	x2, #0x1                   	// #1
    8ee4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ee8:	f947f400 	ldr	x0, [x0, #4072]
    8eec:	f94127e4 	ldr	x4, [sp, #584]
    8ef0:	f9400003 	ldr	x3, [x0]
    8ef4:	eb030084 	subs	x4, x4, x3
    8ef8:	d2800003 	mov	x3, #0x0                   	// #0
    8efc:	54ffebe0 	b.eq	8c78 <fwp_write+0x608>  // b.none
    8f00:	f90143f7 	str	x23, [sp, #640]
    8f04:	f90147f8 	str	x24, [sp, #648]
    8f08:	f9014bf9 	str	x25, [sp, #656]
    8f0c:	f9014ffa 	str	x26, [sp, #664]
    8f10:	fd015be8 	str	d8, [sp, #688]
    8f14:	fd015fe9 	str	d9, [sp, #696]
    8f18:	97ffe636 	bl	27f0 <__stack_chk_fail@plt>
    8f1c:	52800b63 	mov	w3, #0x5b                  	// #91
    8f20:	91001ff5 	add	x21, sp, #0x7
    8f24:	aa1503e1 	mov	x1, x21
    8f28:	aa1403e0 	mov	x0, x20
    8f2c:	d2800022 	mov	x2, #0x1                   	// #1
    8f30:	b0000036 	adrp	x22, d000 <__divti3+0x40>
    8f34:	9130e2d6 	add	x22, x22, #0xc38
    8f38:	39001fe3 	strb	w3, [sp, #7]
    8f3c:	97ffe915 	bl	3390 <buf_put>
    8f40:	b4000273 	cbz	x19, 8f8c <fwp_write+0x91c>
    8f44:	f9400661 	ldr	x1, [x19, #8]
    8f48:	aa1403e0 	mov	x0, x20
    8f4c:	f9401f82 	ldr	x2, [x28, #56]
    8f50:	52800003 	mov	w3, #0x0                   	// #0
    8f54:	97fffdc7 	bl	8670 <fwp_write>
    8f58:	f9400a73 	ldr	x19, [x19, #16]
    8f5c:	b4000193 	cbz	x19, 8f8c <fwp_write+0x91c>
    8f60:	aa1603e1 	mov	x1, x22
    8f64:	aa1403e0 	mov	x0, x20
    8f68:	d2800042 	mov	x2, #0x2                   	// #2
    8f6c:	97ffe909 	bl	3390 <buf_put>
    8f70:	f9400661 	ldr	x1, [x19, #8]
    8f74:	aa1403e0 	mov	x0, x20
    8f78:	f9401f82 	ldr	x2, [x28, #56]
    8f7c:	52800003 	mov	w3, #0x0                   	// #0
    8f80:	97fffdbc 	bl	8670 <fwp_write>
    8f84:	f9400a73 	ldr	x19, [x19, #16]
    8f88:	b5fffed3 	cbnz	x19, 8f60 <fwp_write+0x8f0>
    8f8c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8f90:	aa1503e1 	mov	x1, x21
    8f94:	aa1403e0 	mov	x0, x20
    8f98:	d2800022 	mov	x2, #0x1                   	// #1
    8f9c:	39001fe3 	strb	w3, [sp, #7]
    8fa0:	17fffddb 	b	870c <fwp_write+0x9c>
    8fa4:	aa1403e0 	mov	x0, x20
    8fa8:	b0000021 	adrp	x1, d000 <__divti3+0x40>
    8fac:	d28000c2 	mov	x2, #0x6                   	// #6
    8fb0:	9130a021 	add	x1, x1, #0xc28
    8fb4:	97ffe8f7 	bl	3390 <buf_put>
    8fb8:	f9400260 	ldr	x0, [x19]
    8fbc:	b40004c0 	cbz	x0, 9054 <fwp_write+0x9e4>
    8fc0:	910123f5 	add	x21, sp, #0x48
    8fc4:	91002276 	add	x22, x19, #0x8
    8fc8:	f90143f7 	str	x23, [sp, #640]
    8fcc:	d2800017 	mov	x23, #0x0                   	// #0
    8fd0:	f90147f8 	str	x24, [sp, #648]
    8fd4:	b0000038 	adrp	x24, d000 <__divti3+0x40>
    8fd8:	9130c318 	add	x24, x24, #0xc30
    8fdc:	f9014bf9 	str	x25, [sp, #656]
    8fe0:	b0000039 	adrp	x25, d000 <__divti3+0x40>
    8fe4:	9130e339 	add	x25, x25, #0xc38
    8fe8:	f9014ffa 	str	x26, [sp, #664]
    8fec:	14000005 	b	9000 <fwp_write+0x990>
    8ff0:	aa1903e1 	mov	x1, x25
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	d2800042 	mov	x2, #0x2                   	// #2
    8ffc:	97ffe8e5 	bl	3390 <buf_put>
    9000:	38776ac5 	ldrb	w5, [x22, x23]
    9004:	d2804003 	mov	x3, #0x200                 	// #512
    9008:	aa1803e4 	mov	x4, x24
    900c:	aa0303e1 	mov	x1, x3
    9010:	52800042 	mov	w2, #0x2                   	// #2
    9014:	aa1503e0 	mov	x0, x21
    9018:	910006f7 	add	x23, x23, #0x1
    901c:	97ffe5d1 	bl	2760 <__snprintf_chk@plt>
    9020:	aa1503e0 	mov	x0, x21
    9024:	97ffe597 	bl	2680 <strlen@plt>
    9028:	aa1503e1 	mov	x1, x21
    902c:	aa0003e2 	mov	x2, x0
    9030:	aa1403e0 	mov	x0, x20
    9034:	97ffe8d7 	bl	3390 <buf_put>
    9038:	f9400260 	ldr	x0, [x19]
    903c:	eb17001f 	cmp	x0, x23
    9040:	54fffd88 	b.hi	8ff0 <fwp_write+0x980>  // b.pmore
    9044:	f94143f7 	ldr	x23, [sp, #640]
    9048:	f94147f8 	ldr	x24, [sp, #648]
    904c:	f9414bf9 	ldr	x25, [sp, #656]
    9050:	f9414ffa 	ldr	x26, [sp, #664]
    9054:	52800ba3 	mov	w3, #0x5d                  	// #93
    9058:	aa1403e0 	mov	x0, x20
    905c:	91001fe1 	add	x1, sp, #0x7
    9060:	d2800022 	mov	x2, #0x1                   	// #1
    9064:	39001fe3 	strb	w3, [sp, #7]
    9068:	17fffda9 	b	870c <fwp_write+0x9c>
    906c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9070:	17fffe44 	b	8980 <fwp_write+0x310>
    9074:	f10002ff 	cmp	x23, #0x0
    9078:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    907c:	71002c3f 	cmp	w1, #0xb
    9080:	54ffebc0 	b.eq	8df8 <fwp_write+0x788>  // b.none
    9084:	aa1303e2 	mov	x2, x19
    9088:	aa1703e1 	mov	x1, x23
    908c:	aa1403e0 	mov	x0, x20
    9090:	52800003 	mov	w3, #0x0                   	// #0
    9094:	97fffd77 	bl	8670 <fwp_write>
    9098:	17ffff6a 	b	8e40 <fwp_write+0x7d0>
    909c:	aa1403e0 	mov	x0, x20
    90a0:	91001fe1 	add	x1, sp, #0x7
    90a4:	52800fa3 	mov	w3, #0x7d                  	// #125
    90a8:	d2800022 	mov	x2, #0x1                   	// #1
    90ac:	17fffe38 	b	898c <fwp_write+0x31c>
    90b0:	a9400281 	ldp	x1, x0, [x20]
    90b4:	91000800 	add	x0, x0, #0x2
    90b8:	8b160000 	add	x0, x0, x22
    90bc:	f9000680 	str	x0, [x20, #8]
    90c0:	3820683f 	strb	wzr, [x1, x0]
    90c4:	f9413bf5 	ldr	x21, [sp, #624]
    90c8:	f9413ff6 	ldr	x22, [sp, #632]
    90cc:	f94153fb 	ldr	x27, [sp, #672]
    90d0:	f94157fc 	ldr	x28, [sp, #680]
    90d4:	17fffd93 	b	8720 <fwp_write+0xb0>
    90d8:	f9400f80 	ldr	x0, [x28, #24]
    90dc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    90e0:	aa1b03e0 	mov	x0, x27
    90e4:	97ffe567 	bl	2680 <strlen@plt>
    90e8:	aa1b03e1 	mov	x1, x27
    90ec:	aa0003e2 	mov	x2, x0
    90f0:	aa1403e0 	mov	x0, x20
    90f4:	97ffe8a7 	bl	3390 <buf_put>
    90f8:	aa1903e1 	mov	x1, x25
    90fc:	aa1403e0 	mov	x0, x20
    9100:	d2800062 	mov	x2, #0x3                   	// #3
    9104:	97ffe8a3 	bl	3390 <buf_put>
    9108:	17fffe10 	b	8948 <fwp_write+0x2d8>
    910c:	aa1a03e1 	mov	x1, x26
    9110:	aa1403e0 	mov	x0, x20
    9114:	d2800042 	mov	x2, #0x2                   	// #2
    9118:	97ffe89e 	bl	3390 <buf_put>
    911c:	17fffe09 	b	8940 <fwp_write+0x2d0>
    9120:	f9400660 	ldr	x0, [x19, #8]
    9124:	b4fffb00 	cbz	x0, 9084 <fwp_write+0xa14>
    9128:	90000021 	adrp	x1, d000 <__divti3+0x40>
    912c:	91314021 	add	x1, x1, #0xc50
    9130:	97ffe5d0 	bl	2870 <strcmp@plt>
    9134:	7100001f 	cmp	w0, #0x0
    9138:	1a9f07e0 	cset	w0, ne	// ne = any
    913c:	17ffff2f 	b	8df8 <fwp_write+0x788>
    9140:	aa1403e0 	mov	x0, x20
    9144:	d2800042 	mov	x2, #0x2                   	// #2
    9148:	90000021 	adrp	x1, d000 <__divti3+0x40>
    914c:	91312021 	add	x1, x1, #0xc48
    9150:	97ffe890 	bl	3390 <buf_put>
    9154:	91004261 	add	x1, x19, #0x10
    9158:	aa1403e0 	mov	x0, x20
    915c:	f9402382 	ldr	x2, [x28, #64]
    9160:	52800003 	mov	w3, #0x0                   	// #0
    9164:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9168:	97fffd42 	bl	8670 <fwp_write>
    916c:	17fffd9c 	b	87dc <fwp_write+0x16c>
    9170:	1e22c109 	fcvt	d9, s8
    9174:	910123f5 	add	x21, sp, #0x48
    9178:	52800033 	mov	w19, #0x1                   	// #1
    917c:	d503201f 	nop
    9180:	1e604120 	fmov	d0, d9
    9184:	2a1303e1 	mov	w1, w19
    9188:	aa1503e0 	mov	x0, x21
    918c:	97ffe8dd 	bl	3500 <fwp_format_g.constprop.0>
    9190:	aa1503e0 	mov	x0, x21
    9194:	d2800001 	mov	x1, #0x0                   	// #0
    9198:	97ffe5c2 	bl	28a0 <strtof@plt>
    919c:	1e202100 	fcmp	s8, s0
    91a0:	54ffdb60 	b.eq	8d0c <fwp_write+0x69c>  // b.none
    91a4:	11000673 	add	w19, w19, #0x1
    91a8:	71002a7f 	cmp	w19, #0xa
    91ac:	54fffea1 	b.ne	9180 <fwp_write+0xb10>  // b.any
    91b0:	1e604120 	fmov	d0, d9
    91b4:	aa1503e0 	mov	x0, x21
    91b8:	52800121 	mov	w1, #0x9                   	// #9
    91bc:	97ffe8d1 	bl	3500 <fwp_format_g.constprop.0>
    91c0:	17fffed3 	b	8d0c <fwp_write+0x69c>
    91c4:	d37ef6a1 	lsl	x1, x21, #2
    91c8:	b7f81563 	tbnz	x3, #63, 9474 <fwp_write+0xe04>
    91cc:	91002263 	add	x3, x19, #0x8
    91d0:	8b010061 	add	x1, x3, x1
    91d4:	b9400023 	ldr	w3, [x1]
    91d8:	7100081f 	cmp	w0, #0x2
    91dc:	2a0303e1 	mov	w1, w3
    91e0:	93407c63 	sxtw	x3, w3
    91e4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    91e8:	17fffe5a 	b	8b50 <fwp_write+0x4e0>
    91ec:	d37ffaa1 	lsl	x1, x21, #1
    91f0:	b7f81363 	tbnz	x3, #63, 945c <fwp_write+0xdec>
    91f4:	91002263 	add	x3, x19, #0x8
    91f8:	8b010061 	add	x1, x3, x1
    91fc:	79400021 	ldrh	w1, [x1]
    9200:	7100041f 	cmp	w0, #0x1
    9204:	93403c23 	sxth	x3, w1
    9208:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    920c:	17fffe51 	b	8b50 <fwp_write+0x4e0>
    9210:	52800443 	mov	w3, #0x22                  	// #34
    9214:	91001ff5 	add	x21, sp, #0x7
    9218:	91002273 	add	x19, x19, #0x8
    921c:	aa1503e1 	mov	x1, x21
    9220:	aa1403e0 	mov	x0, x20
    9224:	d2800022 	mov	x2, #0x1                   	// #1
    9228:	39001fe3 	strb	w3, [sp, #7]
    922c:	f90143f7 	str	x23, [sp, #640]
    9230:	8b160277 	add	x23, x19, x22
    9234:	f90147f8 	str	x24, [sp, #648]
    9238:	97ffe856 	bl	3390 <buf_put>
    923c:	b4000696 	cbz	x22, 930c <fwp_write+0xc9c>
    9240:	90000038 	adrp	x24, d000 <__divti3+0x40>
    9244:	912fe318 	add	x24, x24, #0xbf8
    9248:	f9014bf9 	str	x25, [sp, #656]
    924c:	90000039 	adrp	x25, d000 <__divti3+0x40>
    9250:	91306339 	add	x25, x25, #0xc18
    9254:	f9014ffa 	str	x26, [sp, #664]
    9258:	1400000d 	b	928c <fwp_write+0xc1c>
    925c:	710024bf 	cmp	w5, #0x9
    9260:	54000460 	b.eq	92ec <fwp_write+0xc7c>  // b.none
    9264:	710028bf 	cmp	w5, #0xa
    9268:	54000a61 	b.ne	93b4 <fwp_write+0xd44>  // b.any
    926c:	90000021 	adrp	x1, d000 <__divti3+0x40>
    9270:	aa1403e0 	mov	x0, x20
    9274:	91302021 	add	x1, x1, #0xc08
    9278:	d2800042 	mov	x2, #0x2                   	// #2
    927c:	97ffe845 	bl	3390 <buf_put>
    9280:	91000673 	add	x19, x19, #0x1
    9284:	eb17027f 	cmp	x19, x23
    9288:	540003e0 	b.eq	9304 <fwp_write+0xc94>  // b.none
    928c:	39400265 	ldrb	w5, [x19]
    9290:	710034bf 	cmp	w5, #0xd
    9294:	54000180 	b.eq	92c4 <fwp_write+0xc54>  // b.none
    9298:	54fffe29 	b.ls	925c <fwp_write+0xbec>  // b.plast
    929c:	710088bf 	cmp	w5, #0x22
    92a0:	540001c0 	b.eq	92d8 <fwp_write+0xc68>  // b.none
    92a4:	710170bf 	cmp	w5, #0x5c
    92a8:	54000741 	b.ne	9390 <fwp_write+0xd20>  // b.any
    92ac:	aa1403e0 	mov	x0, x20
    92b0:	90000021 	adrp	x1, d000 <__divti3+0x40>
    92b4:	d2800042 	mov	x2, #0x2                   	// #2
    92b8:	91300021 	add	x1, x1, #0xc00
    92bc:	97ffe835 	bl	3390 <buf_put>
    92c0:	17fffff0 	b	9280 <fwp_write+0xc10>
    92c4:	aa1903e1 	mov	x1, x25
    92c8:	aa1403e0 	mov	x0, x20
    92cc:	d2800042 	mov	x2, #0x2                   	// #2
    92d0:	97ffe830 	bl	3390 <buf_put>
    92d4:	17ffffeb 	b	9280 <fwp_write+0xc10>
    92d8:	aa1803e1 	mov	x1, x24
    92dc:	aa1403e0 	mov	x0, x20
    92e0:	d2800042 	mov	x2, #0x2                   	// #2
    92e4:	97ffe82b 	bl	3390 <buf_put>
    92e8:	17ffffe6 	b	9280 <fwp_write+0xc10>
    92ec:	aa1403e0 	mov	x0, x20
    92f0:	90000021 	adrp	x1, d000 <__divti3+0x40>
    92f4:	d2800042 	mov	x2, #0x2                   	// #2
    92f8:	91304021 	add	x1, x1, #0xc10
    92fc:	97ffe825 	bl	3390 <buf_put>
    9300:	17ffffe0 	b	9280 <fwp_write+0xc10>
    9304:	f9414bf9 	ldr	x25, [sp, #656]
    9308:	f9414ffa 	ldr	x26, [sp, #664]
    930c:	aa1503e1 	mov	x1, x21
    9310:	aa1403e0 	mov	x0, x20
    9314:	52800443 	mov	w3, #0x22                  	// #34
    9318:	17fffd9c 	b	8988 <fwp_write+0x318>
    931c:	7100103f 	cmp	w1, #0x4
    9320:	54ffeb21 	b.ne	9084 <fwp_write+0xa14>  // b.any
    9324:	f94006e0 	ldr	x0, [x23, #8]
    9328:	d37ffc00 	lsr	x0, x0, #63
    932c:	17fffeb3 	b	8df8 <fwp_write+0x788>
    9330:	710002ff 	cmp	w23, #0x0
    9334:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9338:	17fffeb0 	b	8df8 <fwp_write+0x788>
    933c:	528005a1 	mov	w1, #0x2d                  	// #45
    9340:	eb0203e2 	negs	x2, x2
    9344:	da0303e3 	ngc	x3, x3
    9348:	910127e0 	add	x0, sp, #0x49
    934c:	910123f5 	add	x21, sp, #0x48
    9350:	390123e1 	strb	w1, [sp, #72]
    9354:	97ffe693 	bl	2da0 <fwp_fmt_u128>
    9358:	17fffe18 	b	8bb8 <fwp_write+0x548>
    935c:	d37ceea1 	lsl	x1, x21, #4
    9360:	b7f810a3 	tbnz	x3, #63, 9574 <fwp_write+0xf04>
    9364:	91002260 	add	x0, x19, #0x8
    9368:	8b010001 	add	x1, x0, x1
    936c:	17fffdf9 	b	8b50 <fwp_write+0x4e0>
    9370:	f9400a61 	ldr	x1, [x19, #16]
    9374:	8b010000 	add	x0, x0, x1
    9378:	f9400001 	ldr	x1, [x0]
    937c:	17fffdf5 	b	8b50 <fwp_write+0x4e0>
    9380:	90000021 	adrp	x1, d000 <__divti3+0x40>
    9384:	d2800042 	mov	x2, #0x2                   	// #2
    9388:	912e8021 	add	x1, x1, #0xba0
    938c:	17fffed6 	b	8ee4 <fwp_write+0x874>
    9390:	7101fcbf 	cmp	w5, #0x7f
    9394:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9398:	540000e9 	b.ls	93b4 <fwp_write+0xd44>  // b.plast
    939c:	aa1503e1 	mov	x1, x21
    93a0:	aa1403e0 	mov	x0, x20
    93a4:	d2800022 	mov	x2, #0x1                   	// #1
    93a8:	39001fe5 	strb	w5, [sp, #7]
    93ac:	97ffe7f9 	bl	3390 <buf_put>
    93b0:	17ffffb4 	b	9280 <fwp_write+0xc10>
    93b4:	d2800203 	mov	x3, #0x10                  	// #16
    93b8:	90000024 	adrp	x4, d000 <__divti3+0x40>
    93bc:	aa0303e1 	mov	x1, x3
    93c0:	91308084 	add	x4, x4, #0xc20
    93c4:	910123f6 	add	x22, sp, #0x48
    93c8:	52800042 	mov	w2, #0x2                   	// #2
    93cc:	aa1603e0 	mov	x0, x22
    93d0:	97ffe4e4 	bl	2760 <__snprintf_chk@plt>
    93d4:	aa1603e0 	mov	x0, x22
    93d8:	97ffe4aa 	bl	2680 <strlen@plt>
    93dc:	aa1603e1 	mov	x1, x22
    93e0:	aa0003e2 	mov	x2, x0
    93e4:	aa1403e0 	mov	x0, x20
    93e8:	97ffe7ea 	bl	3390 <buf_put>
    93ec:	17ffffa5 	b	9280 <fwp_write+0xc10>
    93f0:	1e604100 	fmov	d0, d8
    93f4:	aa1503e0 	mov	x0, x21
    93f8:	52800221 	mov	w1, #0x11                  	// #17
    93fc:	97ffe841 	bl	3500 <fwp_format_g.constprop.0>
    9400:	17fffe43 	b	8d0c <fwp_write+0x69c>
    9404:	b9401040 	ldr	w0, [x2, #16]
    9408:	350003c0 	cbnz	w0, 9480 <fwp_write+0xe10>
    940c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9410:	f947f400 	ldr	x0, [x0, #4072]
    9414:	f94127e2 	ldr	x2, [sp, #584]
    9418:	f9400001 	ldr	x1, [x0]
    941c:	eb010042 	subs	x2, x2, x1
    9420:	d2800001 	mov	x1, #0x0                   	// #0
    9424:	54ffd721 	b.ne	8f08 <fwp_write+0x898>  // b.any
    9428:	f9413bf5 	ldr	x21, [sp, #624]
    942c:	90000021 	adrp	x1, d000 <__divti3+0x40>
    9430:	f9413ff6 	ldr	x22, [sp, #632]
    9434:	aa1403e0 	mov	x0, x20
    9438:	f94143f7 	ldr	x23, [sp, #640]
    943c:	9131c021 	add	x1, x1, #0xc70
    9440:	f94147f8 	ldr	x24, [sp, #648]
    9444:	d2800042 	mov	x2, #0x2                   	// #2
    9448:	17fffd0e 	b	8880 <fwp_write+0x210>
    944c:	90000021 	adrp	x1, d000 <__divti3+0x40>
    9450:	d2800042 	mov	x2, #0x2                   	// #2
    9454:	912ea021 	add	x1, x1, #0xba8
    9458:	17fffea3 	b	8ee4 <fwp_write+0x874>
    945c:	f9400a63 	ldr	x3, [x19, #16]
    9460:	8b030021 	add	x1, x1, x3
    9464:	17ffff66 	b	91fc <fwp_write+0xb8c>
    9468:	f9400a61 	ldr	x1, [x19, #16]
    946c:	8b0102a1 	add	x1, x21, x1
    9470:	17fffdb3 	b	8b3c <fwp_write+0x4cc>
    9474:	f9400a63 	ldr	x3, [x19, #16]
    9478:	8b030021 	add	x1, x1, x3
    947c:	17ffff56 	b	91d4 <fwp_write+0xb64>
    9480:	b9404840 	ldr	w0, [x2, #72]
    9484:	91001ff5 	add	x21, sp, #0x7
    9488:	34ffa360 	cbz	w0, 88f4 <fwp_write+0x284>
    948c:	52800503 	mov	w3, #0x28                  	// #40
    9490:	aa1403e0 	mov	x0, x20
    9494:	aa1503e1 	mov	x1, x21
    9498:	d2800022 	mov	x2, #0x1                   	// #1
    949c:	39001fe3 	strb	w3, [sp, #7]
    94a0:	97ffe7bc 	bl	3390 <buf_put>
    94a4:	b9401380 	ldr	w0, [x28, #16]
    94a8:	52800038 	mov	w24, #0x1                   	// #1
    94ac:	7100001f 	cmp	w0, #0x0
    94b0:	54ffa36c 	b.gt	891c <fwp_write+0x2ac>
    94b4:	17fffd32 	b	897c <fwp_write+0x30c>
    94b8:	f9014bf9 	str	x25, [sp, #656]
    94bc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe818>
    94c0:	f9014ffa 	str	x26, [sp, #664]
    94c4:	f9400676 	ldr	x22, [x19, #8]
    94c8:	91102333 	add	x19, x25, #0x408
    94cc:	91002273 	add	x19, x19, #0x8
    94d0:	937ffed8 	asr	x24, x22, #63
    94d4:	aa1802c0 	orr	x0, x22, x24
    94d8:	b5000320 	cbnz	x0, 953c <fwp_write+0xecc>
    94dc:	110006b5 	add	w21, w21, #0x1
    94e0:	710016bf 	cmp	w21, #0x5
    94e4:	54ffffc1 	b.ne	94dc <fwp_write+0xe6c>  // b.any
    94e8:	b7f80578 	tbnz	x24, #63, 9594 <fwp_write+0xf24>
    94ec:	910023f3 	add	x19, sp, #0x8
    94f0:	aa1603e2 	mov	x2, x22
    94f4:	aa1303e0 	mov	x0, x19
    94f8:	d2800003 	mov	x3, #0x0                   	// #0
    94fc:	97ffe629 	bl	2da0 <fwp_fmt_u128>
    9500:	910123f5 	add	x21, sp, #0x48
    9504:	90000023 	adrp	x3, d000 <__divti3+0x40>
    9508:	aa1303e4 	mov	x4, x19
    950c:	aa1503e0 	mov	x0, x21
    9510:	9131a063 	add	x3, x3, #0xc68
    9514:	d2804002 	mov	x2, #0x200                 	// #512
    9518:	52800041 	mov	w1, #0x2                   	// #2
    951c:	97ffe45d 	bl	2690 <__sprintf_chk@plt>
    9520:	aa1503e0 	mov	x0, x21
    9524:	97ffe457 	bl	2680 <strlen@plt>
    9528:	aa1503e1 	mov	x1, x21
    952c:	aa0003e2 	mov	x2, x0
    9530:	aa1403e0 	mov	x0, x20
    9534:	97ffe797 	bl	3390 <buf_put>
    9538:	17fffe47 	b	8e54 <fwp_write+0x7e4>
    953c:	f9400277 	ldr	x23, [x19]
    9540:	aa1603e0 	mov	x0, x22
    9544:	aa1803e1 	mov	x1, x24
    9548:	aa1703e2 	mov	x2, x23
    954c:	937ffefa 	asr	x26, x23, #63
    9550:	aa1a03e3 	mov	x3, x26
    9554:	94000f7b 	bl	d340 <__modti3>
    9558:	aa010000 	orr	x0, x0, x1
    955c:	b40002c0 	cbz	x0, 95b4 <fwp_write+0xf44>
    9560:	110006b5 	add	w21, w21, #0x1
    9564:	91004273 	add	x19, x19, #0x10
    9568:	710016bf 	cmp	w21, #0x5
    956c:	54fffe81 	b.ne	953c <fwp_write+0xecc>  // b.any
    9570:	17ffffde 	b	94e8 <fwp_write+0xe78>
    9574:	f9400a60 	ldr	x0, [x19, #16]
    9578:	8b000021 	add	x1, x1, x0
    957c:	17fffd75 	b	8b50 <fwp_write+0x4e0>
    9580:	528c29c0 	mov	w0, #0x614e                	// #24910
    9584:	910123f5 	add	x21, sp, #0x48
    9588:	72a009c0 	movk	w0, #0x4e, lsl #16
    958c:	b9004be0 	str	w0, [sp, #72]
    9590:	17fffda2 	b	8c18 <fwp_write+0x5a8>
    9594:	528005a1 	mov	w1, #0x2d                  	// #45
    9598:	eb1603e2 	negs	x2, x22
    959c:	da1803e3 	ngc	x3, x24
    95a0:	910027e0 	add	x0, sp, #0x9
    95a4:	910023f3 	add	x19, sp, #0x8
    95a8:	390023e1 	strb	w1, [sp, #8]
    95ac:	97ffe5fd 	bl	2da0 <fwp_fmt_u128>
    95b0:	17ffffd4 	b	9500 <fwp_write+0xe90>
    95b4:	aa1703e2 	mov	x2, x23
    95b8:	aa1a03e3 	mov	x3, x26
    95bc:	aa1603e0 	mov	x0, x22
    95c0:	aa1803e1 	mov	x1, x24
    95c4:	94000e7f 	bl	cfc0 <__divti3>
    95c8:	aa0003e2 	mov	x2, x0
    95cc:	aa0103e3 	mov	x3, x1
    95d0:	b7f80201 	tbnz	x1, #63, 9610 <fwp_write+0xfa0>
    95d4:	910023f3 	add	x19, sp, #0x8
    95d8:	aa1303e0 	mov	x0, x19
    95dc:	97ffe5f1 	bl	2da0 <fwp_fmt_u128>
    95e0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    95e4:	91102339 	add	x25, x25, #0x408
    95e8:	910123f5 	add	x21, sp, #0x48
    95ec:	aa1303e4 	mov	x4, x19
    95f0:	aa1503e0 	mov	x0, x21
    95f4:	90000023 	adrp	x3, d000 <__divti3+0x40>
    95f8:	f8616b25 	ldr	x5, [x25, x1]
    95fc:	91318063 	add	x3, x3, #0xc60
    9600:	d2804002 	mov	x2, #0x200                 	// #512
    9604:	52800041 	mov	w1, #0x2                   	// #2
    9608:	97ffe422 	bl	2690 <__sprintf_chk@plt>
    960c:	17ffffc5 	b	9520 <fwp_write+0xeb0>
    9610:	528005a4 	mov	w4, #0x2d                  	// #45
    9614:	eb0003e2 	negs	x2, x0
    9618:	da0103e3 	ngc	x3, x1
    961c:	910027e0 	add	x0, sp, #0x9
    9620:	910023f3 	add	x19, sp, #0x8
    9624:	390023e4 	strb	w4, [sp, #8]
    9628:	97ffe5de 	bl	2da0 <fwp_fmt_u128>
    962c:	17ffffed 	b	95e0 <fwp_write+0xf70>
    9630:	f9013bf5 	str	x21, [sp, #624]
    9634:	f9013ff6 	str	x22, [sp, #632]
    9638:	f90143f7 	str	x23, [sp, #640]
    963c:	f90147f8 	str	x24, [sp, #648]
    9640:	f9014bf9 	str	x25, [sp, #656]
    9644:	f9014ffa 	str	x26, [sp, #664]
    9648:	f90153fb 	str	x27, [sp, #672]
    964c:	f90157fc 	str	x28, [sp, #680]
    9650:	fd015be8 	str	d8, [sp, #688]
    9654:	fd015fe9 	str	d9, [sp, #696]
    9658:	97ffe466 	bl	27f0 <__stack_chk_fail@plt>
    965c:	d503201f 	nop

0000000000009660 <fwp_hof0.constprop.0>:
    9660:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9664:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9668:	f947f442 	ldr	x2, [x2, #4072]
    966c:	910003fd 	mov	x29, sp
    9670:	a90153f3 	stp	x19, x20, [sp, #16]
    9674:	a9025bf5 	stp	x21, x22, [sp, #32]
    9678:	a90363f7 	stp	x23, x24, [sp, #48]
    967c:	aa0003f7 	mov	x23, x0
    9680:	a9046bf9 	stp	x25, x26, [sp, #64]
    9684:	a90573fb 	stp	x27, x28, [sp, #80]
    9688:	d10203ff 	sub	sp, sp, #0x80
    968c:	f9400040 	ldr	x0, [x2]
    9690:	f81f83a0 	stur	x0, [x29, #-8]
    9694:	d2800000 	mov	x0, #0x0                   	// #0
    9698:	b40039a1 	cbz	x1, 9dcc <fwp_hof0.constprop.0+0x76c>
    969c:	f00000a0 	adrp	x0, 20000 <__data_start>
    96a0:	9100401c 	add	x28, x0, #0x10
    96a4:	aa1703fa 	mov	x26, x23
    96a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    96ac:	9100239c 	add	x28, x28, #0x8
    96b0:	d10083b4 	sub	x20, x29, #0x20
    96b4:	91010015 	add	x21, x0, #0x40
    96b8:	aa0103f7 	mov	x23, x1
    96bc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    96c0:	91154001 	add	x1, x0, #0x550
    96c4:	f949d822 	ldr	x2, [x1, #5040]
    96c8:	f949ec20 	ldr	x0, [x1, #5080]
    96cc:	cb020342 	sub	x2, x26, x2
    96d0:	eb00405f 	cmp	x2, x0, lsl #16
    96d4:	54000342 	b.cs	973c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    96d8:	d350fc40 	lsr	x0, x2, #16
    96dc:	f949fc24 	ldr	x4, [x1, #5112]
    96e0:	8b000800 	add	x0, x0, x0, lsl #2
    96e4:	d37df001 	lsl	x1, x0, #3
    96e8:	8b010083 	add	x3, x4, x1
    96ec:	f9401060 	ldr	x0, [x3, #32]
    96f0:	b4000260 	cbz	x0, 973c <fwp_hof0.constprop.0+0xdc>
    96f4:	38616881 	ldrb	w1, [x4, x1]
    96f8:	7100083f 	cmp	w1, #0x2
    96fc:	540055c0 	b.eq	a1b4 <fwp_hof0.constprop.0+0xb54>  // b.none
    9700:	7100043f 	cmp	w1, #0x1
    9704:	540001c1 	b.ne	973c <fwp_hof0.constprop.0+0xdc>  // b.any
    9708:	92403c41 	and	x1, x2, #0xffff
    970c:	29430864 	ldp	w4, w2, [x3, #24]
    9710:	9b047c21 	mul	x1, x1, x4
    9714:	d360fc21 	lsr	x1, x1, #32
    9718:	eb02003f 	cmp	x1, x2
    971c:	54000102 	b.cs	973c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9720:	8b010000 	add	x0, x0, x1
    9724:	39400001 	ldrb	w1, [x0]
    9728:	340000a1 	cbz	w1, 973c <fwp_hof0.constprop.0+0xdc>
    972c:	7103f43f 	cmp	w1, #0xfd
    9730:	540056c8 	b.hi	a208 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9734:	11000421 	add	w1, w1, #0x1
    9738:	39000001 	strb	w1, [x0]
    973c:	aa1a03f8 	mov	x24, x26
    9740:	aa1c03f9 	mov	x25, x28
    9744:	d28018f3 	mov	x19, #0xc7                  	// #199
    9748:	a9396bb7 	stp	x23, x26, [x29, #-112]
    974c:	f81a03b3 	stur	x19, [x29, #-96]
    9750:	f00000a0 	adrp	x0, 20000 <__data_start>
    9754:	91004000 	add	x0, x0, #0x10
    9758:	f9403ea3 	ldr	x3, [x21, #120]
    975c:	91002006 	add	x6, x0, #0x8
    9760:	b9400802 	ldr	w2, [x0, #8]
    9764:	d37be842 	lsl	x2, x2, #5
    9768:	8b020064 	add	x4, x3, x2
    976c:	f9400c81 	ldr	x1, [x4, #24]
    9770:	f81e03b8 	stur	x24, [x29, #-32]
    9774:	b40052e1 	cbz	x1, a1d0 <fwp_hof0.constprop.0+0xb70>
    9778:	f9400c20 	ldr	x0, [x1, #24]
    977c:	b40046a0 	cbz	x0, a050 <fwp_hof0.constprop.0+0x9f0>
    9780:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9784:	91154002 	add	x2, x0, #0x550
    9788:	f949d841 	ldr	x1, [x2, #5040]
    978c:	f949ec40 	ldr	x0, [x2, #5080]
    9790:	cb010321 	sub	x1, x25, x1
    9794:	eb00403f 	cmp	x1, x0, lsl #16
    9798:	54000342 	b.cs	9800 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    979c:	d350fc20 	lsr	x0, x1, #16
    97a0:	f949fc45 	ldr	x5, [x2, #5112]
    97a4:	8b000800 	add	x0, x0, x0, lsl #2
    97a8:	d37df002 	lsl	x2, x0, #3
    97ac:	8b0200a3 	add	x3, x5, x2
    97b0:	f9401060 	ldr	x0, [x3, #32]
    97b4:	b4000260 	cbz	x0, 9800 <fwp_hof0.constprop.0+0x1a0>
    97b8:	386268a2 	ldrb	w2, [x5, x2]
    97bc:	7100085f 	cmp	w2, #0x2
    97c0:	54004b40 	b.eq	a128 <fwp_hof0.constprop.0+0xac8>  // b.none
    97c4:	7100045f 	cmp	w2, #0x1
    97c8:	540001c1 	b.ne	9800 <fwp_hof0.constprop.0+0x1a0>  // b.any
    97cc:	29430865 	ldp	w5, w2, [x3, #24]
    97d0:	92403c21 	and	x1, x1, #0xffff
    97d4:	9b057c21 	mul	x1, x1, x5
    97d8:	d360fc21 	lsr	x1, x1, #32
    97dc:	eb02003f 	cmp	x1, x2
    97e0:	54000102 	b.cs	9800 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    97e4:	8b010000 	add	x0, x0, x1
    97e8:	39400001 	ldrb	w1, [x0]
    97ec:	340000a1 	cbz	w1, 9800 <fwp_hof0.constprop.0+0x1a0>
    97f0:	7103f43f 	cmp	w1, #0xfd
    97f4:	54004e68 	b.hi	a1c0 <fwp_hof0.constprop.0+0xb60>  // b.pmore
    97f8:	11000421 	add	w1, w1, #0x1
    97fc:	39000001 	strb	w1, [x0]
    9800:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9804:	aa1903f8 	mov	x24, x25
    9808:	aa1903e0 	mov	x0, x25
    980c:	91154036 	add	x22, x1, #0x550
    9810:	52800037 	mov	w23, #0x1                   	// #1
    9814:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    9818:	b81cc3b7 	stur	w23, [x29, #-52]
    981c:	f81d03b4 	stur	x20, [x29, #-48]
    9820:	b9400401 	ldr	w1, [x0, #4]
    9824:	b9400099 	ldr	w25, [x4]
    9828:	b85cc3a0 	ldur	w0, [x29, #-52]
    982c:	4b010339 	sub	w25, w25, w1
    9830:	6b17033f 	cmp	w25, w23
    9834:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    9838:	6b0000df 	cmp	w6, w0
    983c:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    9840:	b81c83a0 	stur	w0, [x29, #-56]
    9844:	6b0000c2 	subs	w2, w6, w0
    9848:	54000120 	b.eq	986c <fwp_hof0.constprop.0+0x20c>  // b.none
    984c:	f9400c83 	ldr	x3, [x4, #24]
    9850:	0b000021 	add	w1, w1, w0
    9854:	f85d03a4 	ldur	x4, [x29, #-48]
    9858:	b81d83a6 	stur	w6, [x29, #-40]
    985c:	f9400863 	ldr	x3, [x3, #16]
    9860:	8b204c80 	add	x0, x4, w0, uxtw #3
    9864:	d63f0060 	blr	x3
    9868:	b85d83a6 	ldur	w6, [x29, #-40]
    986c:	f9403ea0 	ldr	x0, [x21, #120]
    9870:	aa1803e9 	mov	x9, x24
    9874:	b9400304 	ldr	w4, [x24]
    9878:	2a0603f4 	mov	w20, w6
    987c:	f85d03bb 	ldur	x27, [x29, #-48]
    9880:	aa1803fa 	mov	x26, x24
    9884:	8b041404 	add	x4, x0, x4, lsl #5
    9888:	f9400c8a 	ldr	x10, [x4, #24]
    988c:	b400106a 	cbz	x10, 9a98 <fwp_hof0.constprop.0+0x438>
    9890:	29371bb7 	stp	w23, w6, [x29, #-72]
    9894:	aa0403f7 	mov	x23, x4
    9898:	b81c03b9 	stur	w25, [x29, #-64]
    989c:	aa1b03f9 	mov	x25, x27
    98a0:	14000012 	b	98e8 <fwp_hof0.constprop.0+0x288>
    98a4:	f9400141 	ldr	x1, [x10]
    98a8:	aa1903e0 	mov	x0, x25
    98ac:	d63f0020 	blr	x1
    98b0:	aa0003fb 	mov	x27, x0
    98b4:	aa1803e0 	mov	x0, x24
    98b8:	97fff1be 	bl	5fb0 <fwp_closure_drop>
    98bc:	6b14027f 	cmp	w19, w20
    98c0:	54000cc0 	b.eq	9a58 <fwp_hof0.constprop.0+0x3f8>  // b.none
    98c4:	f9403ea0 	ldr	x0, [x21, #120]
    98c8:	8b334f39 	add	x25, x25, w19, uxtw #3
    98cc:	b9400364 	ldr	w4, [x27]
    98d0:	4b1a0394 	sub	w20, w28, w26
    98d4:	aa1b03e9 	mov	x9, x27
    98d8:	8b041417 	add	x23, x0, x4, lsl #5
    98dc:	f9400eea 	ldr	x10, [x23, #24]
    98e0:	b4000d4a 	cbz	x10, 9a88 <fwp_hof0.constprop.0+0x428>
    98e4:	aa1b03f8 	mov	x24, x27
    98e8:	b9400521 	ldr	w1, [x9, #4]
    98ec:	b94002fa 	ldr	w26, [x23]
    98f0:	0b14003c 	add	w28, w1, w20
    98f4:	6b1c035f 	cmp	w26, w28
    98f8:	540028a8 	b.hi	9e0c <fwp_hof0.constprop.0+0x7ac>  // b.pmore
    98fc:	7100003f 	cmp	w1, #0x0
    9900:	4b010353 	sub	w19, w26, w1
    9904:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9908:	54fffce1 	b.ne	98a4 <fwp_hof0.constprop.0+0x244>  // b.any
    990c:	910003e0 	mov	x0, sp
    9910:	7100035f 	cmp	w26, #0x0
    9914:	f81d83a0 	stur	x0, [x29, #-40]
    9918:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    991c:	d37df000 	lsl	x0, x0, #3
    9920:	91003c00 	add	x0, x0, #0xf
    9924:	92704c05 	and	x5, x0, #0xfffff0000
    9928:	927c7c00 	and	x0, x0, #0xffffffff0
    992c:	cb2563e5 	sub	x5, sp, x5
    9930:	eb2563ff 	cmp	sp, x5
    9934:	540000a0 	b.eq	9948 <fwp_hof0.constprop.0+0x2e8>  // b.none
    9938:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    993c:	f90203ff 	str	xzr, [sp, #1024]
    9940:	eb2563ff 	cmp	sp, x5
    9944:	54ffffa1 	b.ne	9938 <fwp_hof0.constprop.0+0x2d8>  // b.any
    9948:	92403c00 	and	x0, x0, #0xffff
    994c:	cb2063ff 	sub	sp, sp, x0
    9950:	f90003ff 	str	xzr, [sp]
    9954:	f110001f 	cmp	x0, #0x400
    9958:	54000043 	b.cc	9960 <fwp_hof0.constprop.0+0x300>  // b.lo, b.ul, b.last
    995c:	f90203ff 	str	xzr, [sp, #1024]
    9960:	910043fb 	add	x27, sp, #0x10
    9964:	d37d7c28 	ubfiz	x8, x1, #3, #32
    9968:	91002127 	add	x7, x9, #0x8
    996c:	d2800000 	mov	x0, #0x0                   	// #0
    9970:	340000e1 	cbz	w1, 998c <fwp_hof0.constprop.0+0x32c>
    9974:	d503201f 	nop
    9978:	f86068e2 	ldr	x2, [x7, x0]
    997c:	f8206b62 	str	x2, [x27, x0]
    9980:	91002000 	add	x0, x0, #0x8
    9984:	eb00011f 	cmp	x8, x0
    9988:	54ffff81 	b.ne	9978 <fwp_hof0.constprop.0+0x318>  // b.any
    998c:	2a1303e8 	mov	w8, w19
    9990:	d2800000 	mov	x0, #0x0                   	// #0
    9994:	340000f3 	cbz	w19, 99b0 <fwp_hof0.constprop.0+0x350>
    9998:	0b000022 	add	w2, w1, w0
    999c:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    99a0:	91000400 	add	x0, x0, #0x1
    99a4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    99a8:	eb00011f 	cmp	x8, x0
    99ac:	54ffff61 	b.ne	9998 <fwp_hof0.constprop.0+0x338>  // b.any
    99b0:	f949dac0 	ldr	x0, [x22, #5040]
    99b4:	f949eec1 	ldr	x1, [x22, #5080]
    99b8:	cb000300 	sub	x0, x24, x0
    99bc:	eb01401f 	cmp	x0, x1, lsl #16
    99c0:	540002e2 	b.cs	9a1c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    99c4:	d350fc01 	lsr	x1, x0, #16
    99c8:	f949fec8 	ldr	x8, [x22, #5112]
    99cc:	8b010821 	add	x1, x1, x1, lsl #2
    99d0:	d37df021 	lsl	x1, x1, #3
    99d4:	8b010107 	add	x7, x8, x1
    99d8:	f94010e6 	ldr	x6, [x7, #32]
    99dc:	b4000206 	cbz	x6, 9a1c <fwp_hof0.constprop.0+0x3bc>
    99e0:	38616901 	ldrb	w1, [x8, x1]
    99e4:	7100083f 	cmp	w1, #0x2
    99e8:	540004a0 	b.eq	9a7c <fwp_hof0.constprop.0+0x41c>  // b.none
    99ec:	7100043f 	cmp	w1, #0x1
    99f0:	54000161 	b.ne	9a1c <fwp_hof0.constprop.0+0x3bc>  // b.any
    99f4:	294304e8 	ldp	w8, w1, [x7, #24]
    99f8:	92403c00 	and	x0, x0, #0xffff
    99fc:	9b087c00 	mul	x0, x0, x8
    9a00:	d360fc00 	lsr	x0, x0, #32
    9a04:	eb01001f 	cmp	x0, x1
    9a08:	540000a2 	b.cs	9a1c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9a0c:	8b0000c6 	add	x6, x6, x0
    9a10:	394000c0 	ldrb	w0, [x6]
    9a14:	7100041f 	cmp	w0, #0x1
    9a18:	540002e0 	b.eq	9a74 <fwp_hof0.constprop.0+0x414>  // b.none
    9a1c:	f9400546 	ldr	x6, [x10, #8]
    9a20:	aa1803e0 	mov	x0, x24
    9a24:	52800021 	mov	w1, #0x1                   	// #1
    9a28:	d63f00c0 	blr	x6
    9a2c:	f9400ee1 	ldr	x1, [x23, #24]
    9a30:	aa1b03e0 	mov	x0, x27
    9a34:	f9400021 	ldr	x1, [x1]
    9a38:	d63f0020 	blr	x1
    9a3c:	aa0003fb 	mov	x27, x0
    9a40:	f85d83a0 	ldur	x0, [x29, #-40]
    9a44:	9100001f 	mov	sp, x0
    9a48:	aa1803e0 	mov	x0, x24
    9a4c:	97fff159 	bl	5fb0 <fwp_closure_drop>
    9a50:	6b14027f 	cmp	w19, w20
    9a54:	54fff381 	b.ne	98c4 <fwp_hof0.constprop.0+0x264>  // b.any
    9a58:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9a5c:	aa1b03f8 	mov	x24, x27
    9a60:	b85c03b9 	ldur	w25, [x29, #-64]
    9a64:	6b17033f 	cmp	w25, w23
    9a68:	54000443 	b.cc	9af0 <fwp_hof0.constprop.0+0x490>  // b.lo, b.ul, b.last
    9a6c:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9a70:	1400003e 	b	9b68 <fwp_hof0.constprop.0+0x508>
    9a74:	b900053f 	str	wzr, [x9, #4]
    9a78:	17ffffed 	b	9a2c <fwp_hof0.constprop.0+0x3cc>
    9a7c:	72003c1f 	tst	w0, #0xffff
    9a80:	54fffce1 	b.ne	9a1c <fwp_hof0.constprop.0+0x3bc>  // b.any
    9a84:	17ffffe3 	b	9a10 <fwp_hof0.constprop.0+0x3b0>
    9a88:	aa1b03fa 	mov	x26, x27
    9a8c:	aa1903fb 	mov	x27, x25
    9a90:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9a94:	b85c03b9 	ldur	w25, [x29, #-64]
    9a98:	aa1a03e0 	mov	x0, x26
    9a9c:	b81d83a6 	stur	w6, [x29, #-40]
    9aa0:	97ffef5c 	bl	5810 <fwp_rc_share>
    9aa4:	b85d83a6 	ldur	w6, [x29, #-40]
    9aa8:	34000134 	cbz	w20, 9acc <fwp_hof0.constprop.0+0x46c>
    9aac:	aa1b03f8 	mov	x24, x27
    9ab0:	8b344f73 	add	x19, x27, w20, uxtw #3
    9ab4:	2a0603fc 	mov	w28, w6
    9ab8:	f8408700 	ldr	x0, [x24], #8
    9abc:	97ffef55 	bl	5810 <fwp_rc_share>
    9ac0:	eb18027f 	cmp	x19, x24
    9ac4:	54ffffa1 	b.ne	9ab8 <fwp_hof0.constprop.0+0x458>  // b.any
    9ac8:	2a1c03e6 	mov	w6, w28
    9acc:	aa1b03e2 	mov	x2, x27
    9ad0:	2a1403e1 	mov	w1, w20
    9ad4:	aa1a03e0 	mov	x0, x26
    9ad8:	b81d83a6 	stur	w6, [x29, #-40]
    9adc:	97ffec8a 	bl	4d04 <fwp_apply>
    9ae0:	aa0003f8 	mov	x24, x0
    9ae4:	b85d83a6 	ldur	w6, [x29, #-40]
    9ae8:	6b17033f 	cmp	w25, w23
    9aec:	54fffc02 	b.cs	9a6c <fwp_hof0.constprop.0+0x40c>  // b.hs, b.nlast
    9af0:	f9403ea1 	ldr	x1, [x21, #120]
    9af4:	4b0602f7 	sub	w23, w23, w6
    9af8:	b9400304 	ldr	w4, [x24]
    9afc:	f85d03a0 	ldur	x0, [x29, #-48]
    9b00:	8b041424 	add	x4, x1, x4, lsl #5
    9b04:	b85c83a2 	ldur	w2, [x29, #-56]
    9b08:	8b264c00 	add	x0, x0, w6, uxtw #3
    9b0c:	f81d03a0 	stur	x0, [x29, #-48]
    9b10:	f9400c81 	ldr	x1, [x4, #24]
    9b14:	b85cc3a0 	ldur	w0, [x29, #-52]
    9b18:	4b020000 	sub	w0, w0, w2
    9b1c:	b81cc3a0 	stur	w0, [x29, #-52]
    9b20:	aa1803e0 	mov	x0, x24
    9b24:	b5ffe7e1 	cbnz	x1, 9820 <fwp_hof0.constprop.0+0x1c0>
    9b28:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9b2c:	aa1803e0 	mov	x0, x24
    9b30:	97ffef38 	bl	5810 <fwp_rc_share>
    9b34:	34000117 	cbz	w23, 9b54 <fwp_hof0.constprop.0+0x4f4>
    9b38:	f85d03ba 	ldur	x26, [x29, #-48]
    9b3c:	d2800016 	mov	x22, #0x0                   	// #0
    9b40:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    9b44:	910006d6 	add	x22, x22, #0x1
    9b48:	97ffef32 	bl	5810 <fwp_rc_share>
    9b4c:	6b1602ff 	cmp	w23, w22
    9b50:	54ffff88 	b.hi	9b40 <fwp_hof0.constprop.0+0x4e0>  // b.pmore
    9b54:	f85d03a2 	ldur	x2, [x29, #-48]
    9b58:	aa1803e0 	mov	x0, x24
    9b5c:	2a1703e1 	mov	w1, w23
    9b60:	97ffec69 	bl	4d04 <fwp_apply>
    9b64:	aa0003f8 	mov	x24, x0
    9b68:	f85a03a0 	ldur	x0, [x29, #-96]
    9b6c:	f1000400 	subs	x0, x0, #0x1
    9b70:	f81a03a0 	stur	x0, [x29, #-96]
    9b74:	54ffdee1 	b.ne	9750 <fwp_hof0.constprop.0+0xf0>  // b.any
    9b78:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe818>
    9b7c:	91102042 	add	x2, x2, #0x408
    9b80:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    9b84:	aa1803e1 	mov	x1, x24
    9b88:	aa1403e0 	mov	x0, x20
    9b8c:	aa1803fb 	mov	x27, x24
    9b90:	91014042 	add	x2, x2, #0x50
    9b94:	52800023 	mov	w3, #0x1                   	// #1
    9b98:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9b9c:	aa1903fc 	mov	x28, x25
    9ba0:	f81f03bf 	stur	xzr, [x29, #-16]
    9ba4:	97fffab3 	bl	8670 <fwp_write>
    9ba8:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    9bac:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x920>
    9bb0:	91036000 	add	x0, x0, #0xd8
    9bb4:	f10002df 	cmp	x22, #0x0
    9bb8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9bbc:	b1002b1f 	cmn	x24, #0xa
    9bc0:	54003288 	b.hi	a210 <fwp_hof0.constprop.0+0xbb0>  // b.pmore
    9bc4:	91002700 	add	x0, x24, #0x9
    9bc8:	52800021 	mov	w1, #0x1                   	// #1
    9bcc:	97ffec09 	bl	4bf0 <fwp_heap_alloc>
    9bd0:	aa0003f3 	mov	x19, x0
    9bd4:	aa1603e1 	mov	x1, x22
    9bd8:	aa0003f6 	mov	x22, x0
    9bdc:	aa1803e2 	mov	x2, x24
    9be0:	f80086d8 	str	x24, [x22], #8
    9be4:	8b180278 	add	x24, x19, x24
    9be8:	aa1603e0 	mov	x0, x22
    9bec:	97ffe295 	bl	2640 <memcpy@plt>
    9bf0:	3900231f 	strb	wzr, [x24, #8]
    9bf4:	f85e03a0 	ldur	x0, [x29, #-32]
    9bf8:	97ffe32e 	bl	28b0 <free@plt>
    9bfc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9c00:	91154003 	add	x3, x0, #0x550
    9c04:	f949ec64 	ldr	x4, [x3, #5080]
    9c08:	f949d861 	ldr	x1, [x3, #5040]
    9c0c:	d370bc84 	lsl	x4, x4, #16
    9c10:	cb010262 	sub	x2, x19, x1
    9c14:	eb04005f 	cmp	x2, x4
    9c18:	540003c2 	b.cs	9c90 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9c1c:	d350fc40 	lsr	x0, x2, #16
    9c20:	f949fc66 	ldr	x6, [x3, #5112]
    9c24:	8b000800 	add	x0, x0, x0, lsl #2
    9c28:	d37df003 	lsl	x3, x0, #3
    9c2c:	8b0300c0 	add	x0, x6, x3
    9c30:	f9401018 	ldr	x24, [x0, #32]
    9c34:	b40002f8 	cbz	x24, 9c90 <fwp_hof0.constprop.0+0x630>
    9c38:	386368c3 	ldrb	w3, [x6, x3]
    9c3c:	7100087f 	cmp	w3, #0x2
    9c40:	54002ee0 	b.eq	a21c <fwp_hof0.constprop.0+0xbbc>  // b.none
    9c44:	7100047f 	cmp	w3, #0x1
    9c48:	54000241 	b.ne	9c90 <fwp_hof0.constprop.0+0x630>  // b.any
    9c4c:	29430003 	ldp	w3, w0, [x0, #24]
    9c50:	92403c42 	and	x2, x2, #0xffff
    9c54:	9b037c42 	mul	x2, x2, x3
    9c58:	d360fc42 	lsr	x2, x2, #32
    9c5c:	eb00005f 	cmp	x2, x0
    9c60:	54000182 	b.cs	9c90 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9c64:	8b020318 	add	x24, x24, x2
    9c68:	39400300 	ldrb	w0, [x24]
    9c6c:	7103fc1f 	cmp	w0, #0xff
    9c70:	54003cc0 	b.eq	a408 <fwp_hof0.constprop.0+0xda8>  // b.none
    9c74:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9c78:	91154000 	add	x0, x0, #0x550
    9c7c:	52800021 	mov	w1, #0x1                   	// #1
    9c80:	39000301 	strb	w1, [x24]
    9c84:	f949ec04 	ldr	x4, [x0, #5080]
    9c88:	f949d801 	ldr	x1, [x0, #5040]
    9c8c:	d370bc84 	lsl	x4, x4, #16
    9c90:	cb010361 	sub	x1, x27, x1
    9c94:	eb01009f 	cmp	x4, x1
    9c98:	540003c9 	b.ls	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.plast
    9c9c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ca0:	91154019 	add	x25, x0, #0x550
    9ca4:	d350fc22 	lsr	x2, x1, #16
    9ca8:	f949ff26 	ldr	x6, [x25, #5112]
    9cac:	8b020842 	add	x2, x2, x2, lsl #2
    9cb0:	d37df042 	lsl	x2, x2, #3
    9cb4:	8b0200c0 	add	x0, x6, x2
    9cb8:	f9401018 	ldr	x24, [x0, #32]
    9cbc:	b40002b8 	cbz	x24, 9d10 <fwp_hof0.constprop.0+0x6b0>
    9cc0:	386268c2 	ldrb	w2, [x6, x2]
    9cc4:	7100085f 	cmp	w2, #0x2
    9cc8:	540030a0 	b.eq	a2dc <fwp_hof0.constprop.0+0xc7c>  // b.none
    9ccc:	7100045f 	cmp	w2, #0x1
    9cd0:	54000201 	b.ne	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.any
    9cd4:	29430002 	ldp	w2, w0, [x0, #24]
    9cd8:	92403c21 	and	x1, x1, #0xffff
    9cdc:	9b027c21 	mul	x1, x1, x2
    9ce0:	d360fc21 	lsr	x1, x1, #32
    9ce4:	eb00003f 	cmp	x1, x0
    9ce8:	54000142 	b.cs	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    9cec:	8b010318 	add	x24, x24, x1
    9cf0:	39400300 	ldrb	w0, [x24]
    9cf4:	340000e0 	cbz	w0, 9d10 <fwp_hof0.constprop.0+0x6b0>
    9cf8:	7100041f 	cmp	w0, #0x1
    9cfc:	540029c0 	b.eq	a234 <fwp_hof0.constprop.0+0xbd4>  // b.none
    9d00:	7103fc1f 	cmp	w0, #0xff
    9d04:	54002fa0 	b.eq	a2f8 <fwp_hof0.constprop.0+0xc98>  // b.none
    9d08:	51000400 	sub	w0, w0, #0x1
    9d0c:	39000300 	strb	w0, [x24]
    9d10:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d14:	91010003 	add	x3, x0, #0x40
    9d18:	f9400262 	ldr	x2, [x19]
    9d1c:	aa1603e0 	mov	x0, x22
    9d20:	aa0303f6 	mov	x22, x3
    9d24:	d2800021 	mov	x1, #0x1                   	// #1
    9d28:	f9400463 	ldr	x3, [x3, #8]
    9d2c:	97ffe2f1 	bl	28f0 <fwrite@plt>
    9d30:	f94006c1 	ldr	x1, [x22, #8]
    9d34:	52800140 	mov	w0, #0xa                   	// #10
    9d38:	97ffe276 	bl	2710 <fputc@plt>
    9d3c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9d40:	91154002 	add	x2, x0, #0x550
    9d44:	f949d841 	ldr	x1, [x2, #5040]
    9d48:	f949ec40 	ldr	x0, [x2, #5080]
    9d4c:	cb010261 	sub	x1, x19, x1
    9d50:	eb00403f 	cmp	x1, x0, lsl #16
    9d54:	54000382 	b.cs	9dc4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    9d58:	d350fc20 	lsr	x0, x1, #16
    9d5c:	f949fc43 	ldr	x3, [x2, #5112]
    9d60:	8b000800 	add	x0, x0, x0, lsl #2
    9d64:	d37df000 	lsl	x0, x0, #3
    9d68:	8b000062 	add	x2, x3, x0
    9d6c:	f9401056 	ldr	x22, [x2, #32]
    9d70:	b40002b6 	cbz	x22, 9dc4 <fwp_hof0.constprop.0+0x764>
    9d74:	38606860 	ldrb	w0, [x3, x0]
    9d78:	7100081f 	cmp	w0, #0x2
    9d7c:	54002560 	b.eq	a228 <fwp_hof0.constprop.0+0xbc8>  // b.none
    9d80:	7100041f 	cmp	w0, #0x1
    9d84:	54000201 	b.ne	9dc4 <fwp_hof0.constprop.0+0x764>  // b.any
    9d88:	29430043 	ldp	w3, w0, [x2, #24]
    9d8c:	92403c21 	and	x1, x1, #0xffff
    9d90:	9b037c21 	mul	x1, x1, x3
    9d94:	d360fc21 	lsr	x1, x1, #32
    9d98:	eb00003f 	cmp	x1, x0
    9d9c:	54000142 	b.cs	9dc4 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    9da0:	8b0102d6 	add	x22, x22, x1
    9da4:	394002c0 	ldrb	w0, [x22]
    9da8:	340000e0 	cbz	w0, 9dc4 <fwp_hof0.constprop.0+0x764>
    9dac:	7100041f 	cmp	w0, #0x1
    9db0:	54002de0 	b.eq	a36c <fwp_hof0.constprop.0+0xd0c>  // b.none
    9db4:	7103fc1f 	cmp	w0, #0xff
    9db8:	54002e00 	b.eq	a378 <fwp_hof0.constprop.0+0xd18>  // b.none
    9dbc:	51000400 	sub	w0, w0, #0x1
    9dc0:	390002c0 	strb	w0, [x22]
    9dc4:	f9400af7 	ldr	x23, [x23, #16]
    9dc8:	b5ffc7b7 	cbnz	x23, 96bc <fwp_hof0.constprop.0+0x5c>
    9dcc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9dd0:	f947f400 	ldr	x0, [x0, #4072]
    9dd4:	f85f83a2 	ldur	x2, [x29, #-8]
    9dd8:	f9400001 	ldr	x1, [x0]
    9ddc:	eb010042 	subs	x2, x2, x1
    9de0:	d2800001 	mov	x1, #0x0                   	// #0
    9de4:	54002821 	b.ne	a2e8 <fwp_hof0.constprop.0+0xc88>  // b.any
    9de8:	910003bf 	mov	sp, x29
    9dec:	d2800000 	mov	x0, #0x0                   	// #0
    9df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    9df4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9df8:	a94363f7 	ldp	x23, x24, [sp, #48]
    9dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9e00:	a94573fb 	ldp	x27, x28, [sp, #80]
    9e04:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9e08:	d65f03c0 	ret
    9e0c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9e10:	9115400a 	add	x10, x0, #0x550
    9e14:	2a0103fa 	mov	w26, w1
    9e18:	11000780 	add	w0, w28, #0x1
    9e1c:	f120001f 	cmp	x0, #0x800
    9e20:	aa1703e4 	mov	x4, x23
    9e24:	b953a541 	ldr	w1, [x10, #5028]
    9e28:	aa1903fb 	mov	x27, x25
    9e2c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9e30:	d37df000 	lsl	x0, x0, #3
    9e34:	b85c03b9 	ldur	w25, [x29, #-64]
    9e38:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9e3c:	540018e0 	b.eq	a158 <fwp_hof0.constprop.0+0xaf8>  // b.none
    9e40:	91003c01 	add	x1, x0, #0xf
    9e44:	8b411141 	add	x1, x10, x1, lsr #4
    9e48:	397e8021 	ldrb	w1, [x1, #4000]
    9e4c:	910f002b 	add	x11, x1, #0x3c0
    9e50:	8b010422 	add	x2, x1, x1, lsl #1
    9e54:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9e58:	8b020d4c 	add	x12, x10, x2, lsl #3
    9e5c:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    9e60:	2a0b03e1 	mov	w1, w11
    9e64:	b4001693 	cbz	x19, a134 <fwp_hof0.constprop.0+0xad4>
    9e68:	f940026c 	ldr	x12, [x19]
    9e6c:	aa2c03ec 	mvn	x12, x12
    9e70:	f822794c 	str	x12, [x10, x2, lsl #3]
    9e74:	eb01001f 	cmp	x0, x1
    9e78:	540000c2 	b.cs	9e90 <fwp_hof0.constprop.0+0x830>  // b.hs, b.nlast
    9e7c:	d503201f 	nop
    9e80:	f8206a7f 	str	xzr, [x19, x0]
    9e84:	91002000 	add	x0, x0, #0x8
    9e88:	eb00003f 	cmp	x1, x0
    9e8c:	54ffffa8 	b.hi	9e80 <fwp_hof0.constprop.0+0x820>  // b.pmore
    9e90:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9e94:	91154002 	add	x2, x0, #0x550
    9e98:	f94a1040 	ldr	x0, [x2, #5152]
    9e9c:	ab010000 	adds	x0, x0, x1
    9ea0:	54002a62 	b.cs	a3ec <fwp_hof0.constprop.0+0xd8c>  // b.hs, b.nlast
    9ea4:	f94a1441 	ldr	x1, [x2, #5160]
    9ea8:	f90a1040 	str	x0, [x2, #5152]
    9eac:	eb01001f 	cmp	x0, x1
    9eb0:	54000049 	b.ls	9eb8 <fwp_hof0.constprop.0+0x858>  // b.plast
    9eb4:	f90a1440 	str	x0, [x2, #5160]
    9eb8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ebc:	91154000 	add	x0, x0, #0x550
    9ec0:	1e630161 	ucvtf	d1, w11
    9ec4:	fd4a1c00 	ldr	d0, [x0, #5176]
    9ec8:	1e612800 	fadd	d0, d0, d1
    9ecc:	fd0a1c00 	str	d0, [x0, #5176]
    9ed0:	b9400120 	ldr	w0, [x9]
    9ed4:	29007260 	stp	w0, w28, [x19]
    9ed8:	3400017a 	cbz	w26, 9f04 <fwp_hof0.constprop.0+0x8a4>
    9edc:	91002121 	add	x1, x9, #0x8
    9ee0:	d37d7f42 	ubfiz	x2, x26, #3, #32
    9ee4:	91002260 	add	x0, x19, #0x8
    9ee8:	b81bc3a6 	stur	w6, [x29, #-68]
    9eec:	f81c03a4 	stur	x4, [x29, #-64]
    9ef0:	f81d83a9 	stur	x9, [x29, #-40]
    9ef4:	97ffe1db 	bl	2660 <memmove@plt>
    9ef8:	f85c03a4 	ldur	x4, [x29, #-64]
    9efc:	f85d83a9 	ldur	x9, [x29, #-40]
    9f00:	b85bc3a6 	ldur	w6, [x29, #-68]
    9f04:	2a1403e8 	mov	w8, w20
    9f08:	d2800001 	mov	x1, #0x0                   	// #0
    9f0c:	34000114 	cbz	w20, 9f2c <fwp_hof0.constprop.0+0x8cc>
    9f10:	0b010340 	add	w0, w26, w1
    9f14:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9f18:	8b000e60 	add	x0, x19, x0, lsl #3
    9f1c:	91000421 	add	x1, x1, #0x1
    9f20:	f9000402 	str	x2, [x0, #8]
    9f24:	eb01011f 	cmp	x8, x1
    9f28:	54ffff41 	b.ne	9f10 <fwp_hof0.constprop.0+0x8b0>  // b.any
    9f2c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9f30:	91154002 	add	x2, x0, #0x550
    9f34:	f949d840 	ldr	x0, [x2, #5040]
    9f38:	f949ec41 	ldr	x1, [x2, #5080]
    9f3c:	cb000300 	sub	x0, x24, x0
    9f40:	eb01401f 	cmp	x0, x1, lsl #16
    9f44:	540002e2 	b.cs	9fa0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    9f48:	d350fc01 	lsr	x1, x0, #16
    9f4c:	f949fc45 	ldr	x5, [x2, #5112]
    9f50:	8b010821 	add	x1, x1, x1, lsl #2
    9f54:	d37df021 	lsl	x1, x1, #3
    9f58:	8b0100a3 	add	x3, x5, x1
    9f5c:	f9401062 	ldr	x2, [x3, #32]
    9f60:	b4000202 	cbz	x2, 9fa0 <fwp_hof0.constprop.0+0x940>
    9f64:	386168a1 	ldrb	w1, [x5, x1]
    9f68:	7100083f 	cmp	w1, #0x2
    9f6c:	540010a0 	b.eq	a180 <fwp_hof0.constprop.0+0xb20>  // b.none
    9f70:	7100043f 	cmp	w1, #0x1
    9f74:	54000161 	b.ne	9fa0 <fwp_hof0.constprop.0+0x940>  // b.any
    9f78:	29430465 	ldp	w5, w1, [x3, #24]
    9f7c:	92403c00 	and	x0, x0, #0xffff
    9f80:	9b057c00 	mul	x0, x0, x5
    9f84:	d360fc00 	lsr	x0, x0, #32
    9f88:	eb01001f 	cmp	x0, x1
    9f8c:	540000a2 	b.cs	9fa0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    9f90:	8b000042 	add	x2, x2, x0
    9f94:	39400040 	ldrb	w0, [x2]
    9f98:	7100041f 	cmp	w0, #0x1
    9f9c:	54000c20 	b.eq	a120 <fwp_hof0.constprop.0+0xac0>  // b.none
    9fa0:	f9400c82 	ldr	x2, [x4, #24]
    9fa4:	aa1803e0 	mov	x0, x24
    9fa8:	52800021 	mov	w1, #0x1                   	// #1
    9fac:	b81d83a6 	stur	w6, [x29, #-40]
    9fb0:	f9400442 	ldr	x2, [x2, #8]
    9fb4:	d63f0040 	blr	x2
    9fb8:	b85d83a6 	ldur	w6, [x29, #-40]
    9fbc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9fc0:	91154002 	add	x2, x0, #0x550
    9fc4:	f949d841 	ldr	x1, [x2, #5040]
    9fc8:	f949ec40 	ldr	x0, [x2, #5080]
    9fcc:	cb010261 	sub	x1, x19, x1
    9fd0:	eb00403f 	cmp	x1, x0, lsl #16
    9fd4:	54000322 	b.cs	a038 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    9fd8:	d350fc20 	lsr	x0, x1, #16
    9fdc:	f949fc43 	ldr	x3, [x2, #5112]
    9fe0:	8b000800 	add	x0, x0, x0, lsl #2
    9fe4:	d37df002 	lsl	x2, x0, #3
    9fe8:	8b020060 	add	x0, x3, x2
    9fec:	f9401014 	ldr	x20, [x0, #32]
    9ff0:	b4000254 	cbz	x20, a038 <fwp_hof0.constprop.0+0x9d8>
    9ff4:	38626862 	ldrb	w2, [x3, x2]
    9ff8:	7100085f 	cmp	w2, #0x2
    9ffc:	54000c80 	b.eq	a18c <fwp_hof0.constprop.0+0xb2c>  // b.none
    a000:	7100045f 	cmp	w2, #0x1
    a004:	540001a1 	b.ne	a038 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a008:	29430002 	ldp	w2, w0, [x0, #24]
    a00c:	92403c21 	and	x1, x1, #0xffff
    a010:	9b027c21 	mul	x1, x1, x2
    a014:	d360fc21 	lsr	x1, x1, #32
    a018:	eb00003f 	cmp	x1, x0
    a01c:	540000e2 	b.cs	a038 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a020:	8b010294 	add	x20, x20, x1
    a024:	39400280 	ldrb	w0, [x20]
    a028:	7103fc1f 	cmp	w0, #0xff
    a02c:	54000ba0 	b.eq	a1a0 <fwp_hof0.constprop.0+0xb40>  // b.none
    a030:	52800020 	mov	w0, #0x1                   	// #1
    a034:	39000280 	strb	w0, [x20]
    a038:	aa1803e0 	mov	x0, x24
    a03c:	b81d83a6 	stur	w6, [x29, #-40]
    a040:	97ffefdc 	bl	5fb0 <fwp_closure_drop>
    a044:	aa1303f8 	mov	x24, x19
    a048:	b85d83a6 	ldur	w6, [x29, #-40]
    a04c:	17fffea7 	b	9ae8 <fwp_hof0.constprop.0+0x488>
    a050:	b8626860 	ldr	w0, [x3, x2]
    a054:	b94004c2 	ldr	w2, [x6, #4]
    a058:	4b020003 	sub	w3, w0, w2
    a05c:	7100047f 	cmp	w3, #0x1
    a060:	54ffb901 	b.ne	9780 <fwp_hof0.constprop.0+0x120>  // b.any
    a064:	910003f6 	mov	x22, sp
    a068:	34000c42 	cbz	w2, a1f0 <fwp_hof0.constprop.0+0xb90>
    a06c:	7100001f 	cmp	w0, #0x0
    a070:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a074:	d2800101 	mov	x1, #0x8                   	// #8
    a078:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a07c:	91003ee0 	add	x0, x23, #0xf
    a080:	92704c01 	and	x1, x0, #0xfffff0000
    a084:	927c7c00 	and	x0, x0, #0xffffffff0
    a088:	cb2163e1 	sub	x1, sp, x1
    a08c:	eb2163ff 	cmp	sp, x1
    a090:	540000a0 	b.eq	a0a4 <fwp_hof0.constprop.0+0xa44>  // b.none
    a094:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a098:	f90203ff 	str	xzr, [sp, #1024]
    a09c:	eb2163ff 	cmp	sp, x1
    a0a0:	54ffffa1 	b.ne	a094 <fwp_hof0.constprop.0+0xa34>  // b.any
    a0a4:	92403c00 	and	x0, x0, #0xffff
    a0a8:	cb2063ff 	sub	sp, sp, x0
    a0ac:	f90003ff 	str	xzr, [sp]
    a0b0:	f110001f 	cmp	x0, #0x400
    a0b4:	54000043 	b.cc	a0bc <fwp_hof0.constprop.0+0xa5c>  // b.lo, b.ul, b.last
    a0b8:	f90203ff 	str	xzr, [sp, #1024]
    a0bc:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a0c0:	910043fa 	add	x26, sp, #0x10
    a0c4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0c8:	91004001 	add	x1, x0, #0x10
    a0cc:	aa1b03e2 	mov	x2, x27
    a0d0:	91004021 	add	x1, x1, #0x10
    a0d4:	aa1703e3 	mov	x3, x23
    a0d8:	aa1a03e0 	mov	x0, x26
    a0dc:	f81d83a4 	stur	x4, [x29, #-40]
    a0e0:	97ffe198 	bl	2740 <__memcpy_chk@plt>
    a0e4:	eb1b02ff 	cmp	x23, x27
    a0e8:	aa1403e1 	mov	x1, x20
    a0ec:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a0f0:	d2800102 	mov	x2, #0x8                   	// #8
    a0f4:	cb1b0063 	sub	x3, x3, x27
    a0f8:	8b1b0340 	add	x0, x26, x27
    a0fc:	97ffe191 	bl	2740 <__memcpy_chk@plt>
    a100:	f85d83a4 	ldur	x4, [x29, #-40]
    a104:	aa1a03e0 	mov	x0, x26
    a108:	f9400c81 	ldr	x1, [x4, #24]
    a10c:	f9400021 	ldr	x1, [x1]
    a110:	d63f0020 	blr	x1
    a114:	aa0003f8 	mov	x24, x0
    a118:	910002df 	mov	sp, x22
    a11c:	17fffe93 	b	9b68 <fwp_hof0.constprop.0+0x508>
    a120:	b900053f 	str	wzr, [x9, #4]
    a124:	17ffffa6 	b	9fbc <fwp_hof0.constprop.0+0x95c>
    a128:	72003c3f 	tst	w1, #0xffff
    a12c:	54ffb6a1 	b.ne	9800 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a130:	17fffdae 	b	97e8 <fwp_hof0.constprop.0+0x188>
    a134:	f9400593 	ldr	x19, [x12, #8]
    a138:	b4000113 	cbz	x19, a158 <fwp_hof0.constprop.0+0xaf8>
    a13c:	f9400982 	ldr	x2, [x12, #16]
    a140:	cb130042 	sub	x2, x2, x19
    a144:	eb02003f 	cmp	x1, x2
    a148:	54000088 	b.hi	a158 <fwp_hof0.constprop.0+0xaf8>  // b.pmore
    a14c:	8b010262 	add	x2, x19, x1
    a150:	f9000582 	str	x2, [x12, #8]
    a154:	17ffff48 	b	9e74 <fwp_hof0.constprop.0+0x814>
    a158:	52800001 	mov	w1, #0x0                   	// #0
    a15c:	b81bc3a6 	stur	w6, [x29, #-68]
    a160:	f81c03a4 	stur	x4, [x29, #-64]
    a164:	f81d83a9 	stur	x9, [x29, #-40]
    a168:	97ffeaa2 	bl	4bf0 <fwp_heap_alloc>
    a16c:	f85c03a4 	ldur	x4, [x29, #-64]
    a170:	aa0003f3 	mov	x19, x0
    a174:	f85d83a9 	ldur	x9, [x29, #-40]
    a178:	b85bc3a6 	ldur	w6, [x29, #-68]
    a17c:	17ffff55 	b	9ed0 <fwp_hof0.constprop.0+0x870>
    a180:	72003c1f 	tst	w0, #0xffff
    a184:	54fff0e1 	b.ne	9fa0 <fwp_hof0.constprop.0+0x940>  // b.any
    a188:	17ffff83 	b	9f94 <fwp_hof0.constprop.0+0x934>
    a18c:	72003c3f 	tst	w1, #0xffff
    a190:	54fff541 	b.ne	a038 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a194:	39400280 	ldrb	w0, [x20]
    a198:	7103fc1f 	cmp	w0, #0xff
    a19c:	54fff4a1 	b.ne	a030 <fwp_hof0.constprop.0+0x9d0>  // b.any
    a1a0:	aa1403e0 	mov	x0, x20
    a1a4:	b81d83a6 	stur	w6, [x29, #-40]
    a1a8:	97ffe73a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a1ac:	b85d83a6 	ldur	w6, [x29, #-40]
    a1b0:	17ffffa0 	b	a030 <fwp_hof0.constprop.0+0x9d0>
    a1b4:	72003c5f 	tst	w2, #0xffff
    a1b8:	54ffac21 	b.ne	973c <fwp_hof0.constprop.0+0xdc>  // b.any
    a1bc:	17fffd5a 	b	9724 <fwp_hof0.constprop.0+0xc4>
    a1c0:	f81d83a4 	stur	x4, [x29, #-40]
    a1c4:	97ffe848 	bl	42e4 <fwp_rc_wide_dup>
    a1c8:	f85d83a4 	ldur	x4, [x29, #-40]
    a1cc:	17fffd8d 	b	9800 <fwp_hof0.constprop.0+0x1a0>
    a1d0:	aa1903e0 	mov	x0, x25
    a1d4:	97ffed8f 	bl	5810 <fwp_rc_share>
    a1d8:	aa1803e0 	mov	x0, x24
    a1dc:	52800037 	mov	w23, #0x1                   	// #1
    a1e0:	97ffed8c 	bl	5810 <fwp_rc_share>
    a1e4:	aa1903f8 	mov	x24, x25
    a1e8:	f81d03b4 	stur	x20, [x29, #-48]
    a1ec:	17fffe5a 	b	9b54 <fwp_hof0.constprop.0+0x4f4>
    a1f0:	f9400021 	ldr	x1, [x1]
    a1f4:	aa1403e0 	mov	x0, x20
    a1f8:	d63f0020 	blr	x1
    a1fc:	aa0003f8 	mov	x24, x0
    a200:	910002df 	mov	sp, x22
    a204:	17fffe59 	b	9b68 <fwp_hof0.constprop.0+0x508>
    a208:	97ffe837 	bl	42e4 <fwp_rc_wide_dup>
    a20c:	17fffd4c 	b	973c <fwp_hof0.constprop.0+0xdc>
    a210:	f0000000 	adrp	x0, d000 <__divti3+0x40>
    a214:	91320000 	add	x0, x0, #0xc80
    a218:	97ffe6fe 	bl	3e10 <fwp_trap>
    a21c:	72003c5f 	tst	w2, #0xffff
    a220:	54ffd381 	b.ne	9c90 <fwp_hof0.constprop.0+0x630>  // b.any
    a224:	17fffe91 	b	9c68 <fwp_hof0.constprop.0+0x608>
    a228:	72003c3f 	tst	w1, #0xffff
    a22c:	54ffdcc1 	b.ne	9dc4 <fwp_hof0.constprop.0+0x764>  // b.any
    a230:	17fffedd 	b	9da4 <fwp_hof0.constprop.0+0x744>
    a234:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a238:	91154000 	add	x0, x0, #0x550
    a23c:	f9400b78 	ldr	x24, [x27, #16]
    a240:	f949ec03 	ldr	x3, [x0, #5080]
    a244:	f949d801 	ldr	x1, [x0, #5040]
    a248:	d370bc63 	lsl	x3, x3, #16
    a24c:	cb010362 	sub	x2, x27, x1
    a250:	eb03005f 	cmp	x2, x3
    a254:	540003a2 	b.cs	a2c8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a258:	d350fc44 	lsr	x4, x2, #16
    a25c:	8b040884 	add	x4, x4, x4, lsl #2
    a260:	d37df084 	lsl	x4, x4, #3
    a264:	8b0400c0 	add	x0, x6, x4
    a268:	f9401005 	ldr	x5, [x0, #32]
    a26c:	b40002e5 	cbz	x5, a2c8 <fwp_hof0.constprop.0+0xc68>
    a270:	386468c4 	ldrb	w4, [x6, x4]
    a274:	7100089f 	cmp	w4, #0x2
    a278:	540003a0 	b.eq	a2ec <fwp_hof0.constprop.0+0xc8c>  // b.none
    a27c:	7100049f 	cmp	w4, #0x1
    a280:	54000241 	b.ne	a2c8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a284:	29430004 	ldp	w4, w0, [x0, #24]
    a288:	92403c42 	and	x2, x2, #0xffff
    a28c:	9b047c42 	mul	x2, x2, x4
    a290:	d360fc42 	lsr	x2, x2, #32
    a294:	eb00005f 	cmp	x2, x0
    a298:	54000182 	b.cs	a2c8 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a29c:	8b0200a5 	add	x5, x5, x2
    a2a0:	394000a0 	ldrb	w0, [x5]
    a2a4:	7100041f 	cmp	w0, #0x1
    a2a8:	54000101 	b.ne	a2c8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a2ac:	aa1b03e0 	mov	x0, x27
    a2b0:	97ffe794 	bl	4100 <fwp_mem_free>
    a2b4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a2b8:	91154000 	add	x0, x0, #0x550
    a2bc:	f949ec03 	ldr	x3, [x0, #5080]
    a2c0:	f949d801 	ldr	x1, [x0, #5040]
    a2c4:	d370bc63 	lsl	x3, x3, #16
    a2c8:	cb010301 	sub	x1, x24, x1
    a2cc:	eb03003f 	cmp	x1, x3
    a2d0:	54ffd202 	b.cs	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a2d4:	aa1803fb 	mov	x27, x24
    a2d8:	17fffe73 	b	9ca4 <fwp_hof0.constprop.0+0x644>
    a2dc:	72003c3f 	tst	w1, #0xffff
    a2e0:	54ffd181 	b.ne	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a2e4:	17fffe83 	b	9cf0 <fwp_hof0.constprop.0+0x690>
    a2e8:	97ffe142 	bl	27f0 <__stack_chk_fail@plt>
    a2ec:	72003c5f 	tst	w2, #0xffff
    a2f0:	54fffec1 	b.ne	a2c8 <fwp_hof0.constprop.0+0xc68>  // b.any
    a2f4:	17ffffeb 	b	a2a0 <fwp_hof0.constprop.0+0xc40>
    a2f8:	ca584700 	eor	x0, x24, x24, lsr #17
    a2fc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    a300:	91154022 	add	x2, x1, #0x550
    a304:	ca402400 	eor	x0, x0, x0, lsr #9
    a308:	92401c00 	and	x0, x0, #0xff
    a30c:	910a2401 	add	x1, x0, #0x289
    a310:	8b000c40 	add	x0, x2, x0, lsl #3
    a314:	8b010c41 	add	x1, x2, x1, lsl #3
    a318:	f94a2400 	ldr	x0, [x0, #5192]
    a31c:	b50000a0 	cbnz	x0, a330 <fwp_hof0.constprop.0+0xcd0>
    a320:	14000034 	b	a3f0 <fwp_hof0.constprop.0+0xd90>
    a324:	91004001 	add	x1, x0, #0x10
    a328:	f9400800 	ldr	x0, [x0, #16]
    a32c:	b4000620 	cbz	x0, a3f0 <fwp_hof0.constprop.0+0xd90>
    a330:	f9400002 	ldr	x2, [x0]
    a334:	eb02031f 	cmp	x24, x2
    a338:	54ffff61 	b.ne	a324 <fwp_hof0.constprop.0+0xcc4>  // b.any
    a33c:	f9400021 	ldr	x1, [x1]
    a340:	f9400420 	ldr	x0, [x1, #8]
    a344:	d1000400 	sub	x0, x0, #0x1
    a348:	f9000420 	str	x0, [x1, #8]
    a34c:	f103f81f 	cmp	x0, #0xfe
    a350:	54ffce01 	b.ne	9d10 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a354:	39400300 	ldrb	w0, [x24]
    a358:	7103fc1f 	cmp	w0, #0xff
    a35c:	54000500 	b.eq	a3fc <fwp_hof0.constprop.0+0xd9c>  // b.none
    a360:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a364:	39000300 	strb	w0, [x24]
    a368:	17fffe6a 	b	9d10 <fwp_hof0.constprop.0+0x6b0>
    a36c:	aa1303e0 	mov	x0, x19
    a370:	97ffe764 	bl	4100 <fwp_mem_free>
    a374:	17fffe94 	b	9dc4 <fwp_hof0.constprop.0+0x764>
    a378:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a37c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    a380:	91154022 	add	x2, x1, #0x550
    a384:	ca402400 	eor	x0, x0, x0, lsr #9
    a388:	92401c00 	and	x0, x0, #0xff
    a38c:	910a2401 	add	x1, x0, #0x289
    a390:	8b000c40 	add	x0, x2, x0, lsl #3
    a394:	8b010c41 	add	x1, x2, x1, lsl #3
    a398:	f94a2400 	ldr	x0, [x0, #5192]
    a39c:	b50000a0 	cbnz	x0, a3b0 <fwp_hof0.constprop.0+0xd50>
    a3a0:	14000014 	b	a3f0 <fwp_hof0.constprop.0+0xd90>
    a3a4:	91004001 	add	x1, x0, #0x10
    a3a8:	f9400800 	ldr	x0, [x0, #16]
    a3ac:	b4000220 	cbz	x0, a3f0 <fwp_hof0.constprop.0+0xd90>
    a3b0:	f9400002 	ldr	x2, [x0]
    a3b4:	eb16005f 	cmp	x2, x22
    a3b8:	54ffff61 	b.ne	a3a4 <fwp_hof0.constprop.0+0xd44>  // b.any
    a3bc:	f9400021 	ldr	x1, [x1]
    a3c0:	f9400420 	ldr	x0, [x1, #8]
    a3c4:	d1000400 	sub	x0, x0, #0x1
    a3c8:	f9000420 	str	x0, [x1, #8]
    a3cc:	f103f81f 	cmp	x0, #0xfe
    a3d0:	54ffcfa1 	b.ne	9dc4 <fwp_hof0.constprop.0+0x764>  // b.any
    a3d4:	394002c0 	ldrb	w0, [x22]
    a3d8:	7103fc1f 	cmp	w0, #0xff
    a3dc:	540001c0 	b.eq	a414 <fwp_hof0.constprop.0+0xdb4>  // b.none
    a3e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a3e4:	390002c0 	strb	w0, [x22]
    a3e8:	17fffe77 	b	9dc4 <fwp_hof0.constprop.0+0x764>
    a3ec:	97ffe2f1 	bl	2fb0 <fwp_heap_oom>
    a3f0:	f0000000 	adrp	x0, d000 <__divti3+0x40>
    a3f4:	91208000 	add	x0, x0, #0x820
    a3f8:	97ffe686 	bl	3e10 <fwp_trap>
    a3fc:	aa1803e0 	mov	x0, x24
    a400:	97ffe6a4 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a404:	17ffffd7 	b	a360 <fwp_hof0.constprop.0+0xd00>
    a408:	aa1803e0 	mov	x0, x24
    a40c:	97ffe6a1 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a410:	17fffe19 	b	9c74 <fwp_hof0.constprop.0+0x614>
    a414:	aa1603e0 	mov	x0, x22
    a418:	97ffe69e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a41c:	17fffff1 	b	a3e0 <fwp_hof0.constprop.0+0xd80>

000000000000a420 <f0>:
    a420:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a424:	910003fd 	mov	x29, sp
    a428:	a90153f3 	stp	x19, x20, [sp, #16]
    a42c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a430:	a90363f7 	stp	x23, x24, [sp, #48]
    a434:	a9046bf9 	stp	x25, x26, [sp, #64]
    a438:	a90573fb 	stp	x27, x28, [sp, #80]
    a43c:	d121c3ff 	sub	sp, sp, #0x870
    a440:	f90203ff 	str	xzr, [sp, #1024]
    a444:	d00000a0 	adrp	x0, 20000 <__data_start>
    a448:	91010003 	add	x3, x0, #0x40
    a44c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a450:	f947f400 	ldr	x0, [x0, #4072]
    a454:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc90>
    a458:	f9416065 	ldr	x5, [x3, #704]
    a45c:	f9400001 	ldr	x1, [x0]
    a460:	f90437e1 	str	x1, [sp, #2152]
    a464:	d2800001 	mov	x1, #0x0                   	// #0
    a468:	91154299 	add	x25, x20, #0x550
    a46c:	912163f6 	add	x22, sp, #0x858
    a470:	910063e4 	add	x4, sp, #0x18
    a474:	9100c3e1 	add	x1, sp, #0x30
    a478:	f0ffffc0 	adrp	x0, 5000 <fwp_tape_reserve+0xdc>
    a47c:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a480:	9132c000 	add	x0, x0, #0xcb0
    a484:	913b4042 	add	x2, x2, #0xed0
    a488:	d2800013 	mov	x19, #0x0                   	// #0
    a48c:	d280011a 	mov	x26, #0x8                   	// #8
    a490:	d2800015 	mov	x21, #0x0                   	// #0
    a494:	52800037 	mov	w23, #0x1                   	// #1
    a498:	f90007e4 	str	x4, [sp, #8]
    a49c:	a9018be5 	stp	x5, x2, [sp, #24]
    a4a0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a4a4:	a90403ff 	stp	xzr, x0, [sp, #64]
    a4a8:	f9016064 	str	x4, [x3, #704]
    a4ac:	d503201f 	nop
    a4b0:	f100075b 	subs	x27, x26, #0x1
    a4b4:	aa1603e1 	mov	x1, x22
    a4b8:	da1f02b8 	sbc	x24, x21, xzr
    a4bc:	52800020 	mov	w0, #0x1                   	// #1
    a4c0:	f9001ffb 	str	x27, [sp, #56]
    a4c4:	aa1b03fa 	mov	x26, x27
    a4c8:	f9042ffb 	str	x27, [sp, #2136]
    a4cc:	aa1803f5 	mov	x21, x24
    a4d0:	f90433f3 	str	x19, [sp, #2144]
    a4d4:	97ffec87 	bl	56f0 <fwp_data.part.0.constprop.0>
    a4d8:	f949db22 	ldr	x2, [x25, #5040]
    a4dc:	aa0003f3 	mov	x19, x0
    a4e0:	f949ef20 	ldr	x0, [x25, #5080]
    a4e4:	cb020262 	sub	x2, x19, x2
    a4e8:	eb00405f 	cmp	x2, x0, lsl #16
    a4ec:	54000302 	b.cs	a54c <f0+0x12c>  // b.hs, b.nlast
    a4f0:	d350fc40 	lsr	x0, x2, #16
    a4f4:	f949ff25 	ldr	x5, [x25, #5112]
    a4f8:	8b000800 	add	x0, x0, x0, lsl #2
    a4fc:	d37df001 	lsl	x1, x0, #3
    a500:	8b0100a0 	add	x0, x5, x1
    a504:	f940101c 	ldr	x28, [x0, #32]
    a508:	b400023c 	cbz	x28, a54c <f0+0x12c>
    a50c:	386168a1 	ldrb	w1, [x5, x1]
    a510:	7100083f 	cmp	w1, #0x2
    a514:	54010ee0 	b.eq	c6f0 <f0+0x22d0>  // b.none
    a518:	7100043f 	cmp	w1, #0x1
    a51c:	54000181 	b.ne	a54c <f0+0x12c>  // b.any
    a520:	29430001 	ldp	w1, w0, [x0, #24]
    a524:	92403c42 	and	x2, x2, #0xffff
    a528:	9b017c42 	mul	x2, x2, x1
    a52c:	d360fc42 	lsr	x2, x2, #32
    a530:	eb00005f 	cmp	x2, x0
    a534:	540000c2 	b.cs	a54c <f0+0x12c>  // b.hs, b.nlast
    a538:	8b02039c 	add	x28, x28, x2
    a53c:	39400380 	ldrb	w0, [x28]
    a540:	7103fc1f 	cmp	w0, #0xff
    a544:	54010d00 	b.eq	c6e4 <f0+0x22c4>  // b.none
    a548:	39000397 	strb	w23, [x28]
    a54c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a550:	aa18037b 	orr	x27, x27, x24
    a554:	b5fffafb 	cbnz	x27, a4b0 <f0+0x90>
    a558:	d00000a0 	adrp	x0, 20000 <__data_start>
    a55c:	91010018 	add	x24, x0, #0x40
    a560:	f94007e1 	ldr	x1, [sp, #8]
    a564:	f9001bff 	str	xzr, [sp, #48]
    a568:	f9416300 	ldr	x0, [x24, #704]
    a56c:	eb01001f 	cmp	x0, x1
    a570:	540129c1 	b.ne	caa8 <f0+0x2688>  // b.any
    a574:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x920>
    a578:	910143e1 	add	x1, sp, #0x50
    a57c:	f9400fe2 	ldr	x2, [sp, #24]
    a580:	f9016302 	str	x2, [x24, #704]
    a584:	3dc0e800 	ldr	q0, [x0, #928]
    a588:	52800020 	mov	w0, #0x1                   	// #1
    a58c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a590:	3d8017e0 	str	q0, [sp, #80]
    a594:	97ffec57 	bl	56f0 <fwp_data.part.0.constprop.0>
    a598:	97ffecc2 	bl	58a0 <fwp_rc_fresh>
    a59c:	9101a3e1 	add	x1, sp, #0x68
    a5a0:	aa0003e2 	mov	x2, x0
    a5a4:	52800020 	mov	w0, #0x1                   	// #1
    a5a8:	a9068bf5 	stp	x21, x2, [sp, #104]
    a5ac:	97ffec51 	bl	56f0 <fwp_data.part.0.constprop.0>
    a5b0:	97ffecbc 	bl	58a0 <fwp_rc_fresh>
    a5b4:	aa0003e2 	mov	x2, x0
    a5b8:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x920>
    a5bc:	9101e3e1 	add	x1, sp, #0x78
    a5c0:	52800020 	mov	w0, #0x1                   	// #1
    a5c4:	f90043e2 	str	x2, [sp, #128]
    a5c8:	3dc0e860 	ldr	q0, [x3, #928]
    a5cc:	fd003fe0 	str	d0, [sp, #120]
    a5d0:	97ffec48 	bl	56f0 <fwp_data.part.0.constprop.0>
    a5d4:	97ffecb3 	bl	58a0 <fwp_rc_fresh>
    a5d8:	aa0003e2 	mov	x2, x0
    a5dc:	910223e1 	add	x1, sp, #0x88
    a5e0:	52800020 	mov	w0, #0x1                   	// #1
    a5e4:	a9088bf5 	stp	x21, x2, [sp, #136]
    a5e8:	97ffec42 	bl	56f0 <fwp_data.part.0.constprop.0>
    a5ec:	91154283 	add	x3, x20, #0x550
    a5f0:	aa0003f5 	mov	x21, x0
    a5f4:	f949d861 	ldr	x1, [x3, #5040]
    a5f8:	f949ec60 	ldr	x0, [x3, #5080]
    a5fc:	cb0102a1 	sub	x1, x21, x1
    a600:	eb00403f 	cmp	x1, x0, lsl #16
    a604:	54000322 	b.cs	a668 <f0+0x248>  // b.hs, b.nlast
    a608:	d350fc22 	lsr	x2, x1, #16
    a60c:	f949fc63 	ldr	x3, [x3, #5112]
    a610:	8b020842 	add	x2, x2, x2, lsl #2
    a614:	d37df042 	lsl	x2, x2, #3
    a618:	8b020060 	add	x0, x3, x2
    a61c:	f9401017 	ldr	x23, [x0, #32]
    a620:	b4000257 	cbz	x23, a668 <f0+0x248>
    a624:	38626862 	ldrb	w2, [x3, x2]
    a628:	7100085f 	cmp	w2, #0x2
    a62c:	54010680 	b.eq	c6fc <f0+0x22dc>  // b.none
    a630:	7100045f 	cmp	w2, #0x1
    a634:	540001a1 	b.ne	a668 <f0+0x248>  // b.any
    a638:	29430002 	ldp	w2, w0, [x0, #24]
    a63c:	92403c21 	and	x1, x1, #0xffff
    a640:	9b027c21 	mul	x1, x1, x2
    a644:	d360fc21 	lsr	x1, x1, #32
    a648:	eb00003f 	cmp	x1, x0
    a64c:	540000e2 	b.cs	a668 <f0+0x248>  // b.hs, b.nlast
    a650:	8b0102f7 	add	x23, x23, x1
    a654:	394002e0 	ldrb	w0, [x23]
    a658:	7103fc1f 	cmp	w0, #0xff
    a65c:	54011400 	b.eq	c8dc <f0+0x24bc>  // b.none
    a660:	52800020 	mov	w0, #0x1                   	// #1
    a664:	390002e0 	strb	w0, [x23]
    a668:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a66c:	910263e1 	add	x1, sp, #0x98
    a670:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a674:	52800020 	mov	w0, #0x1                   	// #1
    a678:	a909d7e2 	stp	x2, x21, [sp, #152]
    a67c:	97ffec1d 	bl	56f0 <fwp_data.part.0.constprop.0>
    a680:	97ffec88 	bl	58a0 <fwp_rc_fresh>
    a684:	aa0003e2 	mov	x2, x0
    a688:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a68c:	9102a3e1 	add	x1, sp, #0xa8
    a690:	52800020 	mov	w0, #0x1                   	// #1
    a694:	a90a8be3 	stp	x3, x2, [sp, #168]
    a698:	97ffec16 	bl	56f0 <fwp_data.part.0.constprop.0>
    a69c:	91154283 	add	x3, x20, #0x550
    a6a0:	aa0003f5 	mov	x21, x0
    a6a4:	f949d861 	ldr	x1, [x3, #5040]
    a6a8:	f949ec60 	ldr	x0, [x3, #5080]
    a6ac:	cb0102a1 	sub	x1, x21, x1
    a6b0:	eb00403f 	cmp	x1, x0, lsl #16
    a6b4:	54000322 	b.cs	a718 <f0+0x2f8>  // b.hs, b.nlast
    a6b8:	d350fc22 	lsr	x2, x1, #16
    a6bc:	f949fc63 	ldr	x3, [x3, #5112]
    a6c0:	8b020842 	add	x2, x2, x2, lsl #2
    a6c4:	d37df042 	lsl	x2, x2, #3
    a6c8:	8b020060 	add	x0, x3, x2
    a6cc:	f9401017 	ldr	x23, [x0, #32]
    a6d0:	b4000257 	cbz	x23, a718 <f0+0x2f8>
    a6d4:	38626862 	ldrb	w2, [x3, x2]
    a6d8:	7100085f 	cmp	w2, #0x2
    a6dc:	540101c0 	b.eq	c714 <f0+0x22f4>  // b.none
    a6e0:	7100045f 	cmp	w2, #0x1
    a6e4:	540001a1 	b.ne	a718 <f0+0x2f8>  // b.any
    a6e8:	29430002 	ldp	w2, w0, [x0, #24]
    a6ec:	92403c21 	and	x1, x1, #0xffff
    a6f0:	9b027c21 	mul	x1, x1, x2
    a6f4:	d360fc21 	lsr	x1, x1, #32
    a6f8:	eb00003f 	cmp	x1, x0
    a6fc:	540000e2 	b.cs	a718 <f0+0x2f8>  // b.hs, b.nlast
    a700:	8b0102f7 	add	x23, x23, x1
    a704:	394002e0 	ldrb	w0, [x23]
    a708:	7103fc1f 	cmp	w0, #0xff
    a70c:	54010ee0 	b.eq	c8e8 <f0+0x24c8>  // b.none
    a710:	52800020 	mov	w0, #0x1                   	// #1
    a714:	390002e0 	strb	w0, [x23]
    a718:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a71c:	9102e3e1 	add	x1, sp, #0xb8
    a720:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a724:	52800020 	mov	w0, #0x1                   	// #1
    a728:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a72c:	97ffebf1 	bl	56f0 <fwp_data.part.0.constprop.0>
    a730:	97ffec5c 	bl	58a0 <fwp_rc_fresh>
    a734:	aa0003e2 	mov	x2, x0
    a738:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a73c:	910323e1 	add	x1, sp, #0xc8
    a740:	52800020 	mov	w0, #0x1                   	// #1
    a744:	a90c8be3 	stp	x3, x2, [sp, #200]
    a748:	97ffebea 	bl	56f0 <fwp_data.part.0.constprop.0>
    a74c:	91154283 	add	x3, x20, #0x550
    a750:	aa0003f5 	mov	x21, x0
    a754:	f949d861 	ldr	x1, [x3, #5040]
    a758:	f949ec60 	ldr	x0, [x3, #5080]
    a75c:	cb0102a1 	sub	x1, x21, x1
    a760:	eb00403f 	cmp	x1, x0, lsl #16
    a764:	54000322 	b.cs	a7c8 <f0+0x3a8>  // b.hs, b.nlast
    a768:	d350fc22 	lsr	x2, x1, #16
    a76c:	f949fc63 	ldr	x3, [x3, #5112]
    a770:	8b020842 	add	x2, x2, x2, lsl #2
    a774:	d37df042 	lsl	x2, x2, #3
    a778:	8b020060 	add	x0, x3, x2
    a77c:	f9401017 	ldr	x23, [x0, #32]
    a780:	b4000257 	cbz	x23, a7c8 <f0+0x3a8>
    a784:	38626862 	ldrb	w2, [x3, x2]
    a788:	7100085f 	cmp	w2, #0x2
    a78c:	5400fbe0 	b.eq	c708 <f0+0x22e8>  // b.none
    a790:	7100045f 	cmp	w2, #0x1
    a794:	540001a1 	b.ne	a7c8 <f0+0x3a8>  // b.any
    a798:	29430002 	ldp	w2, w0, [x0, #24]
    a79c:	92403c21 	and	x1, x1, #0xffff
    a7a0:	9b027c21 	mul	x1, x1, x2
    a7a4:	d360fc21 	lsr	x1, x1, #32
    a7a8:	eb00003f 	cmp	x1, x0
    a7ac:	540000e2 	b.cs	a7c8 <f0+0x3a8>  // b.hs, b.nlast
    a7b0:	8b0102f7 	add	x23, x23, x1
    a7b4:	394002e0 	ldrb	w0, [x23]
    a7b8:	7103fc1f 	cmp	w0, #0xff
    a7bc:	540109c0 	b.eq	c8f4 <f0+0x24d4>  // b.none
    a7c0:	52800020 	mov	w0, #0x1                   	// #1
    a7c4:	390002e0 	strb	w0, [x23]
    a7c8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7cc:	910363e1 	add	x1, sp, #0xd8
    a7d0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7d4:	52800020 	mov	w0, #0x1                   	// #1
    a7d8:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a7dc:	97ffebc5 	bl	56f0 <fwp_data.part.0.constprop.0>
    a7e0:	91154283 	add	x3, x20, #0x550
    a7e4:	aa0003f5 	mov	x21, x0
    a7e8:	f949d861 	ldr	x1, [x3, #5040]
    a7ec:	f949ec60 	ldr	x0, [x3, #5080]
    a7f0:	cb0102a1 	sub	x1, x21, x1
    a7f4:	eb00403f 	cmp	x1, x0, lsl #16
    a7f8:	54000322 	b.cs	a85c <f0+0x43c>  // b.hs, b.nlast
    a7fc:	d350fc22 	lsr	x2, x1, #16
    a800:	f949fc63 	ldr	x3, [x3, #5112]
    a804:	8b020842 	add	x2, x2, x2, lsl #2
    a808:	d37df042 	lsl	x2, x2, #3
    a80c:	8b020060 	add	x0, x3, x2
    a810:	f9401017 	ldr	x23, [x0, #32]
    a814:	b4000257 	cbz	x23, a85c <f0+0x43c>
    a818:	38626862 	ldrb	w2, [x3, x2]
    a81c:	7100085f 	cmp	w2, #0x2
    a820:	5400f860 	b.eq	c72c <f0+0x230c>  // b.none
    a824:	7100045f 	cmp	w2, #0x1
    a828:	540001a1 	b.ne	a85c <f0+0x43c>  // b.any
    a82c:	29430002 	ldp	w2, w0, [x0, #24]
    a830:	92403c21 	and	x1, x1, #0xffff
    a834:	9b027c21 	mul	x1, x1, x2
    a838:	d360fc21 	lsr	x1, x1, #32
    a83c:	eb00003f 	cmp	x1, x0
    a840:	540000e2 	b.cs	a85c <f0+0x43c>  // b.hs, b.nlast
    a844:	8b0102f7 	add	x23, x23, x1
    a848:	394002e0 	ldrb	w0, [x23]
    a84c:	7103fc1f 	cmp	w0, #0xff
    a850:	54010580 	b.eq	c900 <f0+0x24e0>  // b.none
    a854:	52800020 	mov	w0, #0x1                   	// #1
    a858:	390002e0 	strb	w0, [x23]
    a85c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a860:	9103a3e1 	add	x1, sp, #0xe8
    a864:	52800020 	mov	w0, #0x1                   	// #1
    a868:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a86c:	97ffeba1 	bl	56f0 <fwp_data.part.0.constprop.0>
    a870:	91154283 	add	x3, x20, #0x550
    a874:	aa0003f5 	mov	x21, x0
    a878:	f949d861 	ldr	x1, [x3, #5040]
    a87c:	f949ec60 	ldr	x0, [x3, #5080]
    a880:	cb0102a1 	sub	x1, x21, x1
    a884:	eb00403f 	cmp	x1, x0, lsl #16
    a888:	54000322 	b.cs	a8ec <f0+0x4cc>  // b.hs, b.nlast
    a88c:	d350fc22 	lsr	x2, x1, #16
    a890:	f949fc63 	ldr	x3, [x3, #5112]
    a894:	8b020842 	add	x2, x2, x2, lsl #2
    a898:	d37df042 	lsl	x2, x2, #3
    a89c:	8b020060 	add	x0, x3, x2
    a8a0:	f9401017 	ldr	x23, [x0, #32]
    a8a4:	b4000257 	cbz	x23, a8ec <f0+0x4cc>
    a8a8:	38626862 	ldrb	w2, [x3, x2]
    a8ac:	7100085f 	cmp	w2, #0x2
    a8b0:	5400f380 	b.eq	c720 <f0+0x2300>  // b.none
    a8b4:	7100045f 	cmp	w2, #0x1
    a8b8:	540001a1 	b.ne	a8ec <f0+0x4cc>  // b.any
    a8bc:	29430002 	ldp	w2, w0, [x0, #24]
    a8c0:	92403c21 	and	x1, x1, #0xffff
    a8c4:	9b027c21 	mul	x1, x1, x2
    a8c8:	d360fc21 	lsr	x1, x1, #32
    a8cc:	eb00003f 	cmp	x1, x0
    a8d0:	540000e2 	b.cs	a8ec <f0+0x4cc>  // b.hs, b.nlast
    a8d4:	8b0102f7 	add	x23, x23, x1
    a8d8:	394002e0 	ldrb	w0, [x23]
    a8dc:	7103fc1f 	cmp	w0, #0xff
    a8e0:	54010160 	b.eq	c90c <f0+0x24ec>  // b.none
    a8e4:	52800020 	mov	w0, #0x1                   	// #1
    a8e8:	390002e0 	strb	w0, [x23]
    a8ec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a8f0:	9103e3e1 	add	x1, sp, #0xf8
    a8f4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a8f8:	52800020 	mov	w0, #0x1                   	// #1
    a8fc:	a90fd7e2 	stp	x2, x21, [sp, #248]
    a900:	97ffeb7c 	bl	56f0 <fwp_data.part.0.constprop.0>
    a904:	97ffebe7 	bl	58a0 <fwp_rc_fresh>
    a908:	aa0003e2 	mov	x2, x0
    a90c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a910:	910423e1 	add	x1, sp, #0x108
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	a9108be3 	stp	x3, x2, [sp, #264]
    a91c:	97ffeb75 	bl	56f0 <fwp_data.part.0.constprop.0>
    a920:	91154283 	add	x3, x20, #0x550
    a924:	aa0003f7 	mov	x23, x0
    a928:	f949d861 	ldr	x1, [x3, #5040]
    a92c:	f949ec60 	ldr	x0, [x3, #5080]
    a930:	cb0102e1 	sub	x1, x23, x1
    a934:	eb00403f 	cmp	x1, x0, lsl #16
    a938:	54000322 	b.cs	a99c <f0+0x57c>  // b.hs, b.nlast
    a93c:	d350fc22 	lsr	x2, x1, #16
    a940:	f949fc63 	ldr	x3, [x3, #5112]
    a944:	8b020842 	add	x2, x2, x2, lsl #2
    a948:	d37df042 	lsl	x2, x2, #3
    a94c:	8b020060 	add	x0, x3, x2
    a950:	f9401015 	ldr	x21, [x0, #32]
    a954:	b4000255 	cbz	x21, a99c <f0+0x57c>
    a958:	38626862 	ldrb	w2, [x3, x2]
    a95c:	7100085f 	cmp	w2, #0x2
    a960:	5400ef20 	b.eq	c744 <f0+0x2324>  // b.none
    a964:	7100045f 	cmp	w2, #0x1
    a968:	540001a1 	b.ne	a99c <f0+0x57c>  // b.any
    a96c:	29430002 	ldp	w2, w0, [x0, #24]
    a970:	92403c21 	and	x1, x1, #0xffff
    a974:	9b027c21 	mul	x1, x1, x2
    a978:	d360fc21 	lsr	x1, x1, #32
    a97c:	eb00003f 	cmp	x1, x0
    a980:	540000e2 	b.cs	a99c <f0+0x57c>  // b.hs, b.nlast
    a984:	8b0102b5 	add	x21, x21, x1
    a988:	394002a0 	ldrb	w0, [x21]
    a98c:	7103fc1f 	cmp	w0, #0xff
    a990:	5400fc40 	b.eq	c918 <f0+0x24f8>  // b.none
    a994:	52800020 	mov	w0, #0x1                   	// #1
    a998:	390002a0 	strb	w0, [x21]
    a99c:	910463e1 	add	x1, sp, #0x118
    a9a0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9a4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9a8:	52800020 	mov	w0, #0x1                   	// #1
    a9ac:	a911dff5 	stp	x21, x23, [sp, #280]
    a9b0:	97ffeb50 	bl	56f0 <fwp_data.part.0.constprop.0>
    a9b4:	97ffebbb 	bl	58a0 <fwp_rc_fresh>
    a9b8:	aa0003e2 	mov	x2, x0
    a9bc:	9104a3e1 	add	x1, sp, #0x128
    a9c0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9c4:	52800020 	mov	w0, #0x1                   	// #1
    a9c8:	a9128bf7 	stp	x23, x2, [sp, #296]
    a9cc:	97ffeb49 	bl	56f0 <fwp_data.part.0.constprop.0>
    a9d0:	97ffebb4 	bl	58a0 <fwp_rc_fresh>
    a9d4:	aa0003e2 	mov	x2, x0
    a9d8:	9104e3e1 	add	x1, sp, #0x138
    a9dc:	52800020 	mov	w0, #0x1                   	// #1
    a9e0:	a9138bf5 	stp	x21, x2, [sp, #312]
    a9e4:	97ffeb43 	bl	56f0 <fwp_data.part.0.constprop.0>
    a9e8:	97ffebae 	bl	58a0 <fwp_rc_fresh>
    a9ec:	aa0003e2 	mov	x2, x0
    a9f0:	910523e1 	add	x1, sp, #0x148
    a9f4:	52800020 	mov	w0, #0x1                   	// #1
    a9f8:	a9148bf7 	stp	x23, x2, [sp, #328]
    a9fc:	97ffeb3d 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa00:	97ffeba8 	bl	58a0 <fwp_rc_fresh>
    aa04:	aa0003e2 	mov	x2, x0
    aa08:	910563e1 	add	x1, sp, #0x158
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	a9158bf5 	stp	x21, x2, [sp, #344]
    aa14:	97ffeb37 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa18:	97ffeba2 	bl	58a0 <fwp_rc_fresh>
    aa1c:	aa0003e2 	mov	x2, x0
    aa20:	9105a3e1 	add	x1, sp, #0x168
    aa24:	52800020 	mov	w0, #0x1                   	// #1
    aa28:	a9168bf7 	stp	x23, x2, [sp, #360]
    aa2c:	97ffeb31 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa30:	97ffeb9c 	bl	58a0 <fwp_rc_fresh>
    aa34:	aa0003e2 	mov	x2, x0
    aa38:	9105e3e1 	add	x1, sp, #0x178
    aa3c:	52800020 	mov	w0, #0x1                   	// #1
    aa40:	a9178bf5 	stp	x21, x2, [sp, #376]
    aa44:	97ffeb2b 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa48:	97ffeb96 	bl	58a0 <fwp_rc_fresh>
    aa4c:	aa0003e2 	mov	x2, x0
    aa50:	910623e1 	add	x1, sp, #0x188
    aa54:	52800020 	mov	w0, #0x1                   	// #1
    aa58:	a9188bf7 	stp	x23, x2, [sp, #392]
    aa5c:	97ffeb25 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa60:	97ffeb90 	bl	58a0 <fwp_rc_fresh>
    aa64:	aa0003e2 	mov	x2, x0
    aa68:	910663e1 	add	x1, sp, #0x198
    aa6c:	52800020 	mov	w0, #0x1                   	// #1
    aa70:	a9198bf5 	stp	x21, x2, [sp, #408]
    aa74:	97ffeb1f 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa78:	97ffeb8a 	bl	58a0 <fwp_rc_fresh>
    aa7c:	aa0003e2 	mov	x2, x0
    aa80:	9106a3e1 	add	x1, sp, #0x1a8
    aa84:	52800020 	mov	w0, #0x1                   	// #1
    aa88:	a91a8bf7 	stp	x23, x2, [sp, #424]
    aa8c:	97ffeb19 	bl	56f0 <fwp_data.part.0.constprop.0>
    aa90:	97ffeb84 	bl	58a0 <fwp_rc_fresh>
    aa94:	aa0003e2 	mov	x2, x0
    aa98:	9106e3e1 	add	x1, sp, #0x1b8
    aa9c:	52800020 	mov	w0, #0x1                   	// #1
    aaa0:	a91b8bf5 	stp	x21, x2, [sp, #440]
    aaa4:	97ffeb13 	bl	56f0 <fwp_data.part.0.constprop.0>
    aaa8:	97ffeb7e 	bl	58a0 <fwp_rc_fresh>
    aaac:	aa0003e2 	mov	x2, x0
    aab0:	910723e1 	add	x1, sp, #0x1c8
    aab4:	52800020 	mov	w0, #0x1                   	// #1
    aab8:	a91c8bf7 	stp	x23, x2, [sp, #456]
    aabc:	97ffeb0d 	bl	56f0 <fwp_data.part.0.constprop.0>
    aac0:	97ffeb78 	bl	58a0 <fwp_rc_fresh>
    aac4:	aa0003e2 	mov	x2, x0
    aac8:	910763e1 	add	x1, sp, #0x1d8
    aacc:	52800020 	mov	w0, #0x1                   	// #1
    aad0:	a91d8bf5 	stp	x21, x2, [sp, #472]
    aad4:	97ffeb07 	bl	56f0 <fwp_data.part.0.constprop.0>
    aad8:	97ffeb72 	bl	58a0 <fwp_rc_fresh>
    aadc:	aa0003e2 	mov	x2, x0
    aae0:	9107a3e1 	add	x1, sp, #0x1e8
    aae4:	52800020 	mov	w0, #0x1                   	// #1
    aae8:	a91e8bf7 	stp	x23, x2, [sp, #488]
    aaec:	97ffeb01 	bl	56f0 <fwp_data.part.0.constprop.0>
    aaf0:	97ffeb6c 	bl	58a0 <fwp_rc_fresh>
    aaf4:	aa0003e2 	mov	x2, x0
    aaf8:	9107e3e1 	add	x1, sp, #0x1f8
    aafc:	52800020 	mov	w0, #0x1                   	// #1
    ab00:	a91f8bf5 	stp	x21, x2, [sp, #504]
    ab04:	97ffeafb 	bl	56f0 <fwp_data.part.0.constprop.0>
    ab08:	91154283 	add	x3, x20, #0x550
    ab0c:	aa0003f5 	mov	x21, x0
    ab10:	f949d861 	ldr	x1, [x3, #5040]
    ab14:	f949ec60 	ldr	x0, [x3, #5080]
    ab18:	cb0102a1 	sub	x1, x21, x1
    ab1c:	eb00403f 	cmp	x1, x0, lsl #16
    ab20:	54000322 	b.cs	ab84 <f0+0x764>  // b.hs, b.nlast
    ab24:	d350fc22 	lsr	x2, x1, #16
    ab28:	f949fc63 	ldr	x3, [x3, #5112]
    ab2c:	8b020842 	add	x2, x2, x2, lsl #2
    ab30:	d37df042 	lsl	x2, x2, #3
    ab34:	8b020060 	add	x0, x3, x2
    ab38:	f9401017 	ldr	x23, [x0, #32]
    ab3c:	b4000257 	cbz	x23, ab84 <f0+0x764>
    ab40:	38626862 	ldrb	w2, [x3, x2]
    ab44:	7100085f 	cmp	w2, #0x2
    ab48:	5400df80 	b.eq	c738 <f0+0x2318>  // b.none
    ab4c:	7100045f 	cmp	w2, #0x1
    ab50:	540001a1 	b.ne	ab84 <f0+0x764>  // b.any
    ab54:	29430002 	ldp	w2, w0, [x0, #24]
    ab58:	92403c21 	and	x1, x1, #0xffff
    ab5c:	9b027c21 	mul	x1, x1, x2
    ab60:	d360fc21 	lsr	x1, x1, #32
    ab64:	eb00003f 	cmp	x1, x0
    ab68:	540000e2 	b.cs	ab84 <f0+0x764>  // b.hs, b.nlast
    ab6c:	8b0102f7 	add	x23, x23, x1
    ab70:	394002e0 	ldrb	w0, [x23]
    ab74:	7103fc1f 	cmp	w0, #0xff
    ab78:	5400ed60 	b.eq	c924 <f0+0x2504>  // b.none
    ab7c:	52800020 	mov	w0, #0x1                   	// #1
    ab80:	390002e0 	strb	w0, [x23]
    ab84:	910823e1 	add	x1, sp, #0x208
    ab88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab8c:	52800020 	mov	w0, #0x1                   	// #1
    ab90:	f90107e2 	str	x2, [sp, #520]
    ab94:	f9010bf5 	str	x21, [sp, #528]
    ab98:	97ffead6 	bl	56f0 <fwp_data.part.0.constprop.0>
    ab9c:	97ffeb41 	bl	58a0 <fwp_rc_fresh>
    aba0:	aa0003e2 	mov	x2, x0
    aba4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aba8:	910863e1 	add	x1, sp, #0x218
    abac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    abb0:	52800020 	mov	w0, #0x1                   	// #1
    abb4:	f9010fe3 	str	x3, [sp, #536]
    abb8:	f90113e2 	str	x2, [sp, #544]
    abbc:	97ffeacd 	bl	56f0 <fwp_data.part.0.constprop.0>
    abc0:	91154283 	add	x3, x20, #0x550
    abc4:	aa0003f5 	mov	x21, x0
    abc8:	f949d861 	ldr	x1, [x3, #5040]
    abcc:	f949ec60 	ldr	x0, [x3, #5080]
    abd0:	cb0102a1 	sub	x1, x21, x1
    abd4:	eb00403f 	cmp	x1, x0, lsl #16
    abd8:	54000322 	b.cs	ac3c <f0+0x81c>  // b.hs, b.nlast
    abdc:	d350fc22 	lsr	x2, x1, #16
    abe0:	f949fc63 	ldr	x3, [x3, #5112]
    abe4:	8b020842 	add	x2, x2, x2, lsl #2
    abe8:	d37df042 	lsl	x2, x2, #3
    abec:	8b020060 	add	x0, x3, x2
    abf0:	f9401017 	ldr	x23, [x0, #32]
    abf4:	b4000257 	cbz	x23, ac3c <f0+0x81c>
    abf8:	38626862 	ldrb	w2, [x3, x2]
    abfc:	7100085f 	cmp	w2, #0x2
    ac00:	5400e0e0 	b.eq	c81c <f0+0x23fc>  // b.none
    ac04:	7100045f 	cmp	w2, #0x1
    ac08:	540001a1 	b.ne	ac3c <f0+0x81c>  // b.any
    ac0c:	29430002 	ldp	w2, w0, [x0, #24]
    ac10:	92403c21 	and	x1, x1, #0xffff
    ac14:	9b027c21 	mul	x1, x1, x2
    ac18:	d360fc21 	lsr	x1, x1, #32
    ac1c:	eb00003f 	cmp	x1, x0
    ac20:	540000e2 	b.cs	ac3c <f0+0x81c>  // b.hs, b.nlast
    ac24:	8b0102f7 	add	x23, x23, x1
    ac28:	394002e0 	ldrb	w0, [x23]
    ac2c:	7103fc1f 	cmp	w0, #0xff
    ac30:	5400e800 	b.eq	c930 <f0+0x2510>  // b.none
    ac34:	52800020 	mov	w0, #0x1                   	// #1
    ac38:	390002e0 	strb	w0, [x23]
    ac3c:	9108a3e1 	add	x1, sp, #0x228
    ac40:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac44:	52800020 	mov	w0, #0x1                   	// #1
    ac48:	f90117e2 	str	x2, [sp, #552]
    ac4c:	f9011bf5 	str	x21, [sp, #560]
    ac50:	97ffeaa8 	bl	56f0 <fwp_data.part.0.constprop.0>
    ac54:	97ffeb13 	bl	58a0 <fwp_rc_fresh>
    ac58:	aa0003e2 	mov	x2, x0
    ac5c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac60:	9108e3e1 	add	x1, sp, #0x238
    ac64:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac68:	52800020 	mov	w0, #0x1                   	// #1
    ac6c:	f9011fe3 	str	x3, [sp, #568]
    ac70:	f90123e2 	str	x2, [sp, #576]
    ac74:	97ffea9f 	bl	56f0 <fwp_data.part.0.constprop.0>
    ac78:	91154283 	add	x3, x20, #0x550
    ac7c:	aa0003f5 	mov	x21, x0
    ac80:	f949d861 	ldr	x1, [x3, #5040]
    ac84:	f949ec60 	ldr	x0, [x3, #5080]
    ac88:	cb0102a1 	sub	x1, x21, x1
    ac8c:	eb00403f 	cmp	x1, x0, lsl #16
    ac90:	54000322 	b.cs	acf4 <f0+0x8d4>  // b.hs, b.nlast
    ac94:	d350fc22 	lsr	x2, x1, #16
    ac98:	f949fc63 	ldr	x3, [x3, #5112]
    ac9c:	8b020842 	add	x2, x2, x2, lsl #2
    aca0:	d37df042 	lsl	x2, x2, #3
    aca4:	8b020060 	add	x0, x3, x2
    aca8:	f9401017 	ldr	x23, [x0, #32]
    acac:	b4000257 	cbz	x23, acf4 <f0+0x8d4>
    acb0:	38626862 	ldrb	w2, [x3, x2]
    acb4:	7100085f 	cmp	w2, #0x2
    acb8:	5400dac0 	b.eq	c810 <f0+0x23f0>  // b.none
    acbc:	7100045f 	cmp	w2, #0x1
    acc0:	540001a1 	b.ne	acf4 <f0+0x8d4>  // b.any
    acc4:	29430002 	ldp	w2, w0, [x0, #24]
    acc8:	92403c21 	and	x1, x1, #0xffff
    accc:	9b027c21 	mul	x1, x1, x2
    acd0:	d360fc21 	lsr	x1, x1, #32
    acd4:	eb00003f 	cmp	x1, x0
    acd8:	540000e2 	b.cs	acf4 <f0+0x8d4>  // b.hs, b.nlast
    acdc:	8b0102f7 	add	x23, x23, x1
    ace0:	394002e0 	ldrb	w0, [x23]
    ace4:	7103fc1f 	cmp	w0, #0xff
    ace8:	5400e2a0 	b.eq	c93c <f0+0x251c>  // b.none
    acec:	52800020 	mov	w0, #0x1                   	// #1
    acf0:	390002e0 	strb	w0, [x23]
    acf4:	910923e1 	add	x1, sp, #0x248
    acf8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acfc:	52800020 	mov	w0, #0x1                   	// #1
    ad00:	f90127e2 	str	x2, [sp, #584]
    ad04:	f9012bf5 	str	x21, [sp, #592]
    ad08:	97ffea7a 	bl	56f0 <fwp_data.part.0.constprop.0>
    ad0c:	97ffeae5 	bl	58a0 <fwp_rc_fresh>
    ad10:	aa0003e2 	mov	x2, x0
    ad14:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad18:	910963e1 	add	x1, sp, #0x258
    ad1c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad20:	52800020 	mov	w0, #0x1                   	// #1
    ad24:	f9012fe3 	str	x3, [sp, #600]
    ad28:	f90133e2 	str	x2, [sp, #608]
    ad2c:	97ffea71 	bl	56f0 <fwp_data.part.0.constprop.0>
    ad30:	91154283 	add	x3, x20, #0x550
    ad34:	aa0003f7 	mov	x23, x0
    ad38:	f949d861 	ldr	x1, [x3, #5040]
    ad3c:	f949ec60 	ldr	x0, [x3, #5080]
    ad40:	cb0102e1 	sub	x1, x23, x1
    ad44:	eb00403f 	cmp	x1, x0, lsl #16
    ad48:	54000322 	b.cs	adac <f0+0x98c>  // b.hs, b.nlast
    ad4c:	d350fc22 	lsr	x2, x1, #16
    ad50:	f949fc63 	ldr	x3, [x3, #5112]
    ad54:	8b020842 	add	x2, x2, x2, lsl #2
    ad58:	d37df042 	lsl	x2, x2, #3
    ad5c:	8b020060 	add	x0, x3, x2
    ad60:	f9401015 	ldr	x21, [x0, #32]
    ad64:	b4000255 	cbz	x21, adac <f0+0x98c>
    ad68:	38626862 	ldrb	w2, [x3, x2]
    ad6c:	7100085f 	cmp	w2, #0x2
    ad70:	5400d620 	b.eq	c834 <f0+0x2414>  // b.none
    ad74:	7100045f 	cmp	w2, #0x1
    ad78:	540001a1 	b.ne	adac <f0+0x98c>  // b.any
    ad7c:	29430002 	ldp	w2, w0, [x0, #24]
    ad80:	92403c21 	and	x1, x1, #0xffff
    ad84:	9b027c21 	mul	x1, x1, x2
    ad88:	d360fc21 	lsr	x1, x1, #32
    ad8c:	eb00003f 	cmp	x1, x0
    ad90:	540000e2 	b.cs	adac <f0+0x98c>  // b.hs, b.nlast
    ad94:	8b0102b5 	add	x21, x21, x1
    ad98:	394002a0 	ldrb	w0, [x21]
    ad9c:	7103fc1f 	cmp	w0, #0xff
    ada0:	5400dd40 	b.eq	c948 <f0+0x2528>  // b.none
    ada4:	52800020 	mov	w0, #0x1                   	// #1
    ada8:	390002a0 	strb	w0, [x21]
    adac:	9109a3e1 	add	x1, sp, #0x268
    adb0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    adb4:	52800020 	mov	w0, #0x1                   	// #1
    adb8:	f90137f5 	str	x21, [sp, #616]
    adbc:	f9013bf7 	str	x23, [sp, #624]
    adc0:	97ffea4c 	bl	56f0 <fwp_data.part.0.constprop.0>
    adc4:	97ffeab7 	bl	58a0 <fwp_rc_fresh>
    adc8:	aa0003e2 	mov	x2, x0
    adcc:	9109e3e1 	add	x1, sp, #0x278
    add0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    add4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	f9013ff7 	str	x23, [sp, #632]
    ade0:	f90143e2 	str	x2, [sp, #640]
    ade4:	97ffea43 	bl	56f0 <fwp_data.part.0.constprop.0>
    ade8:	97ffeaae 	bl	58a0 <fwp_rc_fresh>
    adec:	aa0003e2 	mov	x2, x0
    adf0:	910a23e1 	add	x1, sp, #0x288
    adf4:	52800020 	mov	w0, #0x1                   	// #1
    adf8:	f90147f5 	str	x21, [sp, #648]
    adfc:	f9014be2 	str	x2, [sp, #656]
    ae00:	97ffea3c 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae04:	97ffeaa7 	bl	58a0 <fwp_rc_fresh>
    ae08:	aa0003e2 	mov	x2, x0
    ae0c:	910a63e1 	add	x1, sp, #0x298
    ae10:	52800020 	mov	w0, #0x1                   	// #1
    ae14:	f9014ff7 	str	x23, [sp, #664]
    ae18:	f90153e2 	str	x2, [sp, #672]
    ae1c:	97ffea35 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae20:	97ffeaa0 	bl	58a0 <fwp_rc_fresh>
    ae24:	aa0003e2 	mov	x2, x0
    ae28:	910aa3e1 	add	x1, sp, #0x2a8
    ae2c:	52800020 	mov	w0, #0x1                   	// #1
    ae30:	f90157f5 	str	x21, [sp, #680]
    ae34:	f9015be2 	str	x2, [sp, #688]
    ae38:	97ffea2e 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae3c:	97ffea99 	bl	58a0 <fwp_rc_fresh>
    ae40:	aa0003e2 	mov	x2, x0
    ae44:	910ae3e1 	add	x1, sp, #0x2b8
    ae48:	52800020 	mov	w0, #0x1                   	// #1
    ae4c:	f9015ff7 	str	x23, [sp, #696]
    ae50:	f90163e2 	str	x2, [sp, #704]
    ae54:	97ffea27 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae58:	97ffea92 	bl	58a0 <fwp_rc_fresh>
    ae5c:	aa0003e2 	mov	x2, x0
    ae60:	910b23e1 	add	x1, sp, #0x2c8
    ae64:	52800020 	mov	w0, #0x1                   	// #1
    ae68:	f90167f5 	str	x21, [sp, #712]
    ae6c:	f9016be2 	str	x2, [sp, #720]
    ae70:	97ffea20 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae74:	97ffea8b 	bl	58a0 <fwp_rc_fresh>
    ae78:	aa0003e2 	mov	x2, x0
    ae7c:	910b63e1 	add	x1, sp, #0x2d8
    ae80:	52800020 	mov	w0, #0x1                   	// #1
    ae84:	f9016ff7 	str	x23, [sp, #728]
    ae88:	f90173e2 	str	x2, [sp, #736]
    ae8c:	97ffea19 	bl	56f0 <fwp_data.part.0.constprop.0>
    ae90:	97ffea84 	bl	58a0 <fwp_rc_fresh>
    ae94:	aa0003e2 	mov	x2, x0
    ae98:	910ba3e1 	add	x1, sp, #0x2e8
    ae9c:	52800020 	mov	w0, #0x1                   	// #1
    aea0:	f90177f5 	str	x21, [sp, #744]
    aea4:	f9017be2 	str	x2, [sp, #752]
    aea8:	97ffea12 	bl	56f0 <fwp_data.part.0.constprop.0>
    aeac:	97ffea7d 	bl	58a0 <fwp_rc_fresh>
    aeb0:	aa0003e2 	mov	x2, x0
    aeb4:	910be3e1 	add	x1, sp, #0x2f8
    aeb8:	52800020 	mov	w0, #0x1                   	// #1
    aebc:	f9017ff7 	str	x23, [sp, #760]
    aec0:	f90183e2 	str	x2, [sp, #768]
    aec4:	97ffea0b 	bl	56f0 <fwp_data.part.0.constprop.0>
    aec8:	97ffea76 	bl	58a0 <fwp_rc_fresh>
    aecc:	aa0003e2 	mov	x2, x0
    aed0:	910c23e1 	add	x1, sp, #0x308
    aed4:	52800020 	mov	w0, #0x1                   	// #1
    aed8:	f90187f5 	str	x21, [sp, #776]
    aedc:	f9018be2 	str	x2, [sp, #784]
    aee0:	97ffea04 	bl	56f0 <fwp_data.part.0.constprop.0>
    aee4:	97ffea6f 	bl	58a0 <fwp_rc_fresh>
    aee8:	aa0003e2 	mov	x2, x0
    aeec:	910c63e1 	add	x1, sp, #0x318
    aef0:	52800020 	mov	w0, #0x1                   	// #1
    aef4:	f9018ff7 	str	x23, [sp, #792]
    aef8:	f90193e2 	str	x2, [sp, #800]
    aefc:	97ffe9fd 	bl	56f0 <fwp_data.part.0.constprop.0>
    af00:	97ffea68 	bl	58a0 <fwp_rc_fresh>
    af04:	aa0003e2 	mov	x2, x0
    af08:	910ca3e1 	add	x1, sp, #0x328
    af0c:	52800020 	mov	w0, #0x1                   	// #1
    af10:	f90197f5 	str	x21, [sp, #808]
    af14:	f9019be2 	str	x2, [sp, #816]
    af18:	97ffe9f6 	bl	56f0 <fwp_data.part.0.constprop.0>
    af1c:	97ffea61 	bl	58a0 <fwp_rc_fresh>
    af20:	aa0003e2 	mov	x2, x0
    af24:	910ce3e1 	add	x1, sp, #0x338
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	f9019ff7 	str	x23, [sp, #824]
    af30:	f901a3e2 	str	x2, [sp, #832]
    af34:	97ffe9ef 	bl	56f0 <fwp_data.part.0.constprop.0>
    af38:	97ffea5a 	bl	58a0 <fwp_rc_fresh>
    af3c:	aa0003e2 	mov	x2, x0
    af40:	910d23e1 	add	x1, sp, #0x348
    af44:	52800020 	mov	w0, #0x1                   	// #1
    af48:	f901a7f5 	str	x21, [sp, #840]
    af4c:	f901abe2 	str	x2, [sp, #848]
    af50:	97ffe9e8 	bl	56f0 <fwp_data.part.0.constprop.0>
    af54:	97ffea53 	bl	58a0 <fwp_rc_fresh>
    af58:	aa0003e2 	mov	x2, x0
    af5c:	910d63e1 	add	x1, sp, #0x358
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	f901aff7 	str	x23, [sp, #856]
    af68:	f901b3e2 	str	x2, [sp, #864]
    af6c:	97ffe9e1 	bl	56f0 <fwp_data.part.0.constprop.0>
    af70:	97ffea4c 	bl	58a0 <fwp_rc_fresh>
    af74:	aa0003e2 	mov	x2, x0
    af78:	910da3e1 	add	x1, sp, #0x368
    af7c:	52800020 	mov	w0, #0x1                   	// #1
    af80:	f901b7f5 	str	x21, [sp, #872]
    af84:	f901bbe2 	str	x2, [sp, #880]
    af88:	97ffe9da 	bl	56f0 <fwp_data.part.0.constprop.0>
    af8c:	97ffea45 	bl	58a0 <fwp_rc_fresh>
    af90:	aa0003e2 	mov	x2, x0
    af94:	910de3e1 	add	x1, sp, #0x378
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	f901bff7 	str	x23, [sp, #888]
    afa0:	f901c3e2 	str	x2, [sp, #896]
    afa4:	97ffe9d3 	bl	56f0 <fwp_data.part.0.constprop.0>
    afa8:	97ffea3e 	bl	58a0 <fwp_rc_fresh>
    afac:	aa0003e2 	mov	x2, x0
    afb0:	910e23e1 	add	x1, sp, #0x388
    afb4:	52800020 	mov	w0, #0x1                   	// #1
    afb8:	f901c7f5 	str	x21, [sp, #904]
    afbc:	f901cbe2 	str	x2, [sp, #912]
    afc0:	97ffe9cc 	bl	56f0 <fwp_data.part.0.constprop.0>
    afc4:	97ffea37 	bl	58a0 <fwp_rc_fresh>
    afc8:	aa0003e2 	mov	x2, x0
    afcc:	910e63e1 	add	x1, sp, #0x398
    afd0:	52800020 	mov	w0, #0x1                   	// #1
    afd4:	f901cff7 	str	x23, [sp, #920]
    afd8:	f901d3e2 	str	x2, [sp, #928]
    afdc:	97ffe9c5 	bl	56f0 <fwp_data.part.0.constprop.0>
    afe0:	97ffea30 	bl	58a0 <fwp_rc_fresh>
    afe4:	aa0003e2 	mov	x2, x0
    afe8:	910ea3e1 	add	x1, sp, #0x3a8
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f901d7f5 	str	x21, [sp, #936]
    aff4:	f901dbe2 	str	x2, [sp, #944]
    aff8:	97ffe9be 	bl	56f0 <fwp_data.part.0.constprop.0>
    affc:	91154283 	add	x3, x20, #0x550
    b000:	aa0003f5 	mov	x21, x0
    b004:	f949d861 	ldr	x1, [x3, #5040]
    b008:	f949ec60 	ldr	x0, [x3, #5080]
    b00c:	cb0102a1 	sub	x1, x21, x1
    b010:	eb00403f 	cmp	x1, x0, lsl #16
    b014:	54000322 	b.cs	b078 <f0+0xc58>  // b.hs, b.nlast
    b018:	d350fc22 	lsr	x2, x1, #16
    b01c:	f949fc63 	ldr	x3, [x3, #5112]
    b020:	8b020842 	add	x2, x2, x2, lsl #2
    b024:	d37df042 	lsl	x2, x2, #3
    b028:	8b020060 	add	x0, x3, x2
    b02c:	f9401017 	ldr	x23, [x0, #32]
    b030:	b4000257 	cbz	x23, b078 <f0+0xc58>
    b034:	38626862 	ldrb	w2, [x3, x2]
    b038:	7100085f 	cmp	w2, #0x2
    b03c:	5400bf60 	b.eq	c828 <f0+0x2408>  // b.none
    b040:	7100045f 	cmp	w2, #0x1
    b044:	540001a1 	b.ne	b078 <f0+0xc58>  // b.any
    b048:	29430002 	ldp	w2, w0, [x0, #24]
    b04c:	92403c21 	and	x1, x1, #0xffff
    b050:	9b027c21 	mul	x1, x1, x2
    b054:	d360fc21 	lsr	x1, x1, #32
    b058:	eb00003f 	cmp	x1, x0
    b05c:	540000e2 	b.cs	b078 <f0+0xc58>  // b.hs, b.nlast
    b060:	8b0102f7 	add	x23, x23, x1
    b064:	394002e0 	ldrb	w0, [x23]
    b068:	7103fc1f 	cmp	w0, #0xff
    b06c:	5400c740 	b.eq	c954 <f0+0x2534>  // b.none
    b070:	52800020 	mov	w0, #0x1                   	// #1
    b074:	390002e0 	strb	w0, [x23]
    b078:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b07c:	910ee3e1 	add	x1, sp, #0x3b8
    b080:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	f901dfe2 	str	x2, [sp, #952]
    b08c:	f901e3f5 	str	x21, [sp, #960]
    b090:	97ffe998 	bl	56f0 <fwp_data.part.0.constprop.0>
    b094:	97ffea03 	bl	58a0 <fwp_rc_fresh>
    b098:	aa0003e2 	mov	x2, x0
    b09c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0a0:	910f23e1 	add	x1, sp, #0x3c8
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f901e7e3 	str	x3, [sp, #968]
    b0ac:	f901ebe2 	str	x2, [sp, #976]
    b0b0:	97ffe990 	bl	56f0 <fwp_data.part.0.constprop.0>
    b0b4:	91154283 	add	x3, x20, #0x550
    b0b8:	aa0003f5 	mov	x21, x0
    b0bc:	f949d861 	ldr	x1, [x3, #5040]
    b0c0:	f949ec60 	ldr	x0, [x3, #5080]
    b0c4:	cb0102a1 	sub	x1, x21, x1
    b0c8:	eb00403f 	cmp	x1, x0, lsl #16
    b0cc:	54000322 	b.cs	b130 <f0+0xd10>  // b.hs, b.nlast
    b0d0:	d350fc22 	lsr	x2, x1, #16
    b0d4:	f949fc63 	ldr	x3, [x3, #5112]
    b0d8:	8b020842 	add	x2, x2, x2, lsl #2
    b0dc:	d37df042 	lsl	x2, x2, #3
    b0e0:	8b020060 	add	x0, x3, x2
    b0e4:	f9401017 	ldr	x23, [x0, #32]
    b0e8:	b4000257 	cbz	x23, b130 <f0+0xd10>
    b0ec:	38626862 	ldrb	w2, [x3, x2]
    b0f0:	7100085f 	cmp	w2, #0x2
    b0f4:	5400bac0 	b.eq	c84c <f0+0x242c>  // b.none
    b0f8:	7100045f 	cmp	w2, #0x1
    b0fc:	540001a1 	b.ne	b130 <f0+0xd10>  // b.any
    b100:	29430002 	ldp	w2, w0, [x0, #24]
    b104:	92403c21 	and	x1, x1, #0xffff
    b108:	9b027c21 	mul	x1, x1, x2
    b10c:	d360fc21 	lsr	x1, x1, #32
    b110:	eb00003f 	cmp	x1, x0
    b114:	540000e2 	b.cs	b130 <f0+0xd10>  // b.hs, b.nlast
    b118:	8b0102f7 	add	x23, x23, x1
    b11c:	394002e0 	ldrb	w0, [x23]
    b120:	7103fc1f 	cmp	w0, #0xff
    b124:	5400c1e0 	b.eq	c960 <f0+0x2540>  // b.none
    b128:	52800020 	mov	w0, #0x1                   	// #1
    b12c:	390002e0 	strb	w0, [x23]
    b130:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b134:	910f63e1 	add	x1, sp, #0x3d8
    b138:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b13c:	52800020 	mov	w0, #0x1                   	// #1
    b140:	f901efe2 	str	x2, [sp, #984]
    b144:	f901f3f5 	str	x21, [sp, #992]
    b148:	97ffe96a 	bl	56f0 <fwp_data.part.0.constprop.0>
    b14c:	97ffe9d5 	bl	58a0 <fwp_rc_fresh>
    b150:	aa0003e2 	mov	x2, x0
    b154:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b158:	910fa3e1 	add	x1, sp, #0x3e8
    b15c:	52800020 	mov	w0, #0x1                   	// #1
    b160:	f901f7e3 	str	x3, [sp, #1000]
    b164:	f901fbe2 	str	x2, [sp, #1008]
    b168:	97ffe962 	bl	56f0 <fwp_data.part.0.constprop.0>
    b16c:	91154283 	add	x3, x20, #0x550
    b170:	aa0003f7 	mov	x23, x0
    b174:	f949d861 	ldr	x1, [x3, #5040]
    b178:	f949ec60 	ldr	x0, [x3, #5080]
    b17c:	cb0102e1 	sub	x1, x23, x1
    b180:	eb00403f 	cmp	x1, x0, lsl #16
    b184:	54000322 	b.cs	b1e8 <f0+0xdc8>  // b.hs, b.nlast
    b188:	d350fc22 	lsr	x2, x1, #16
    b18c:	f949fc63 	ldr	x3, [x3, #5112]
    b190:	8b020842 	add	x2, x2, x2, lsl #2
    b194:	d37df042 	lsl	x2, x2, #3
    b198:	8b020060 	add	x0, x3, x2
    b19c:	f9401015 	ldr	x21, [x0, #32]
    b1a0:	b4000255 	cbz	x21, b1e8 <f0+0xdc8>
    b1a4:	38626862 	ldrb	w2, [x3, x2]
    b1a8:	7100085f 	cmp	w2, #0x2
    b1ac:	5400b4a0 	b.eq	c840 <f0+0x2420>  // b.none
    b1b0:	7100045f 	cmp	w2, #0x1
    b1b4:	540001a1 	b.ne	b1e8 <f0+0xdc8>  // b.any
    b1b8:	29430002 	ldp	w2, w0, [x0, #24]
    b1bc:	92403c21 	and	x1, x1, #0xffff
    b1c0:	9b027c21 	mul	x1, x1, x2
    b1c4:	d360fc21 	lsr	x1, x1, #32
    b1c8:	eb00003f 	cmp	x1, x0
    b1cc:	540000e2 	b.cs	b1e8 <f0+0xdc8>  // b.hs, b.nlast
    b1d0:	8b0102b5 	add	x21, x21, x1
    b1d4:	394002a0 	ldrb	w0, [x21]
    b1d8:	7103fc1f 	cmp	w0, #0xff
    b1dc:	5400bc80 	b.eq	c96c <f0+0x254c>  // b.none
    b1e0:	52800020 	mov	w0, #0x1                   	// #1
    b1e4:	390002a0 	strb	w0, [x21]
    b1e8:	910fe3e1 	add	x1, sp, #0x3f8
    b1ec:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b1f0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b1f4:	52800020 	mov	w0, #0x1                   	// #1
    b1f8:	f901fff5 	str	x21, [sp, #1016]
    b1fc:	f90203f7 	str	x23, [sp, #1024]
    b200:	97ffe93c 	bl	56f0 <fwp_data.part.0.constprop.0>
    b204:	97ffe9a7 	bl	58a0 <fwp_rc_fresh>
    b208:	aa0003e2 	mov	x2, x0
    b20c:	911023e1 	add	x1, sp, #0x408
    b210:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b214:	52800020 	mov	w0, #0x1                   	// #1
    b218:	f90207f7 	str	x23, [sp, #1032]
    b21c:	f9020be2 	str	x2, [sp, #1040]
    b220:	97ffe934 	bl	56f0 <fwp_data.part.0.constprop.0>
    b224:	97ffe99f 	bl	58a0 <fwp_rc_fresh>
    b228:	aa0003e2 	mov	x2, x0
    b22c:	911063e1 	add	x1, sp, #0x418
    b230:	52800020 	mov	w0, #0x1                   	// #1
    b234:	f9020ff5 	str	x21, [sp, #1048]
    b238:	f90213e2 	str	x2, [sp, #1056]
    b23c:	97ffe92d 	bl	56f0 <fwp_data.part.0.constprop.0>
    b240:	97ffe998 	bl	58a0 <fwp_rc_fresh>
    b244:	aa0003e2 	mov	x2, x0
    b248:	9110a3e1 	add	x1, sp, #0x428
    b24c:	52800020 	mov	w0, #0x1                   	// #1
    b250:	f90217f7 	str	x23, [sp, #1064]
    b254:	f9021be2 	str	x2, [sp, #1072]
    b258:	97ffe926 	bl	56f0 <fwp_data.part.0.constprop.0>
    b25c:	97ffe991 	bl	58a0 <fwp_rc_fresh>
    b260:	aa0003e2 	mov	x2, x0
    b264:	9110e3e1 	add	x1, sp, #0x438
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	f9021ff5 	str	x21, [sp, #1080]
    b270:	f90223e2 	str	x2, [sp, #1088]
    b274:	97ffe91f 	bl	56f0 <fwp_data.part.0.constprop.0>
    b278:	97ffe98a 	bl	58a0 <fwp_rc_fresh>
    b27c:	aa0003e2 	mov	x2, x0
    b280:	911123e1 	add	x1, sp, #0x448
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	f90227f7 	str	x23, [sp, #1096]
    b28c:	f9022be2 	str	x2, [sp, #1104]
    b290:	97ffe918 	bl	56f0 <fwp_data.part.0.constprop.0>
    b294:	97ffe983 	bl	58a0 <fwp_rc_fresh>
    b298:	aa0003e2 	mov	x2, x0
    b29c:	911163e1 	add	x1, sp, #0x458
    b2a0:	52800020 	mov	w0, #0x1                   	// #1
    b2a4:	f9022ff5 	str	x21, [sp, #1112]
    b2a8:	f90233e2 	str	x2, [sp, #1120]
    b2ac:	97ffe911 	bl	56f0 <fwp_data.part.0.constprop.0>
    b2b0:	91154283 	add	x3, x20, #0x550
    b2b4:	aa0003f5 	mov	x21, x0
    b2b8:	f949d861 	ldr	x1, [x3, #5040]
    b2bc:	f949ec60 	ldr	x0, [x3, #5080]
    b2c0:	cb0102a1 	sub	x1, x21, x1
    b2c4:	eb00403f 	cmp	x1, x0, lsl #16
    b2c8:	54000322 	b.cs	b32c <f0+0xf0c>  // b.hs, b.nlast
    b2cc:	d350fc22 	lsr	x2, x1, #16
    b2d0:	f949fc63 	ldr	x3, [x3, #5112]
    b2d4:	8b020842 	add	x2, x2, x2, lsl #2
    b2d8:	d37df042 	lsl	x2, x2, #3
    b2dc:	8b020060 	add	x0, x3, x2
    b2e0:	f9401017 	ldr	x23, [x0, #32]
    b2e4:	b4000257 	cbz	x23, b32c <f0+0xf0c>
    b2e8:	38626862 	ldrb	w2, [x3, x2]
    b2ec:	7100085f 	cmp	w2, #0x2
    b2f0:	5400aba0 	b.eq	c864 <f0+0x2444>  // b.none
    b2f4:	7100045f 	cmp	w2, #0x1
    b2f8:	540001a1 	b.ne	b32c <f0+0xf0c>  // b.any
    b2fc:	29430002 	ldp	w2, w0, [x0, #24]
    b300:	92403c21 	and	x1, x1, #0xffff
    b304:	9b027c21 	mul	x1, x1, x2
    b308:	d360fc21 	lsr	x1, x1, #32
    b30c:	eb00003f 	cmp	x1, x0
    b310:	540000e2 	b.cs	b32c <f0+0xf0c>  // b.hs, b.nlast
    b314:	8b0102f7 	add	x23, x23, x1
    b318:	394002e0 	ldrb	w0, [x23]
    b31c:	7103fc1f 	cmp	w0, #0xff
    b320:	5400b2c0 	b.eq	c978 <f0+0x2558>  // b.none
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	390002e0 	strb	w0, [x23]
    b32c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b330:	9111a3e1 	add	x1, sp, #0x468
    b334:	52800020 	mov	w0, #0x1                   	// #1
    b338:	f90237e2 	str	x2, [sp, #1128]
    b33c:	f9023bf5 	str	x21, [sp, #1136]
    b340:	97ffe8ec 	bl	56f0 <fwp_data.part.0.constprop.0>
    b344:	91154283 	add	x3, x20, #0x550
    b348:	aa0003f5 	mov	x21, x0
    b34c:	f949d861 	ldr	x1, [x3, #5040]
    b350:	f949ec60 	ldr	x0, [x3, #5080]
    b354:	cb0102a1 	sub	x1, x21, x1
    b358:	eb00403f 	cmp	x1, x0, lsl #16
    b35c:	54000322 	b.cs	b3c0 <f0+0xfa0>  // b.hs, b.nlast
    b360:	d350fc22 	lsr	x2, x1, #16
    b364:	f949fc63 	ldr	x3, [x3, #5112]
    b368:	8b020842 	add	x2, x2, x2, lsl #2
    b36c:	d37df042 	lsl	x2, x2, #3
    b370:	8b020060 	add	x0, x3, x2
    b374:	f9401017 	ldr	x23, [x0, #32]
    b378:	b4000257 	cbz	x23, b3c0 <f0+0xfa0>
    b37c:	38626862 	ldrb	w2, [x3, x2]
    b380:	7100085f 	cmp	w2, #0x2
    b384:	5400a6a0 	b.eq	c858 <f0+0x2438>  // b.none
    b388:	7100045f 	cmp	w2, #0x1
    b38c:	540001a1 	b.ne	b3c0 <f0+0xfa0>  // b.any
    b390:	29430002 	ldp	w2, w0, [x0, #24]
    b394:	92403c21 	and	x1, x1, #0xffff
    b398:	9b027c21 	mul	x1, x1, x2
    b39c:	d360fc21 	lsr	x1, x1, #32
    b3a0:	eb00003f 	cmp	x1, x0
    b3a4:	540000e2 	b.cs	b3c0 <f0+0xfa0>  // b.hs, b.nlast
    b3a8:	8b0102f7 	add	x23, x23, x1
    b3ac:	394002e0 	ldrb	w0, [x23]
    b3b0:	7103fc1f 	cmp	w0, #0xff
    b3b4:	5400ae80 	b.eq	c984 <f0+0x2564>  // b.none
    b3b8:	52800020 	mov	w0, #0x1                   	// #1
    b3bc:	390002e0 	strb	w0, [x23]
    b3c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b3c4:	9111e3e1 	add	x1, sp, #0x478
    b3c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b3cc:	52800020 	mov	w0, #0x1                   	// #1
    b3d0:	f9023fe2 	str	x2, [sp, #1144]
    b3d4:	f90243f5 	str	x21, [sp, #1152]
    b3d8:	97ffe8c6 	bl	56f0 <fwp_data.part.0.constprop.0>
    b3dc:	97ffe931 	bl	58a0 <fwp_rc_fresh>
    b3e0:	aa0003e2 	mov	x2, x0
    b3e4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b3e8:	911223e1 	add	x1, sp, #0x488
    b3ec:	52800020 	mov	w0, #0x1                   	// #1
    b3f0:	f90247e3 	str	x3, [sp, #1160]
    b3f4:	f9024be2 	str	x2, [sp, #1168]
    b3f8:	97ffe8be 	bl	56f0 <fwp_data.part.0.constprop.0>
    b3fc:	91154283 	add	x3, x20, #0x550
    b400:	aa0003f5 	mov	x21, x0
    b404:	f949d861 	ldr	x1, [x3, #5040]
    b408:	f949ec60 	ldr	x0, [x3, #5080]
    b40c:	cb0102a1 	sub	x1, x21, x1
    b410:	eb00403f 	cmp	x1, x0, lsl #16
    b414:	54000322 	b.cs	b478 <f0+0x1058>  // b.hs, b.nlast
    b418:	d350fc22 	lsr	x2, x1, #16
    b41c:	f949fc63 	ldr	x3, [x3, #5112]
    b420:	8b020842 	add	x2, x2, x2, lsl #2
    b424:	d37df042 	lsl	x2, x2, #3
    b428:	8b020060 	add	x0, x3, x2
    b42c:	f9401017 	ldr	x23, [x0, #32]
    b430:	b4000257 	cbz	x23, b478 <f0+0x1058>
    b434:	38626862 	ldrb	w2, [x3, x2]
    b438:	7100085f 	cmp	w2, #0x2
    b43c:	5400a200 	b.eq	c87c <f0+0x245c>  // b.none
    b440:	7100045f 	cmp	w2, #0x1
    b444:	540001a1 	b.ne	b478 <f0+0x1058>  // b.any
    b448:	29430002 	ldp	w2, w0, [x0, #24]
    b44c:	92403c21 	and	x1, x1, #0xffff
    b450:	9b027c21 	mul	x1, x1, x2
    b454:	d360fc21 	lsr	x1, x1, #32
    b458:	eb00003f 	cmp	x1, x0
    b45c:	540000e2 	b.cs	b478 <f0+0x1058>  // b.hs, b.nlast
    b460:	8b0102f7 	add	x23, x23, x1
    b464:	394002e0 	ldrb	w0, [x23]
    b468:	7103fc1f 	cmp	w0, #0xff
    b46c:	5400a920 	b.eq	c990 <f0+0x2570>  // b.none
    b470:	52800020 	mov	w0, #0x1                   	// #1
    b474:	390002e0 	strb	w0, [x23]
    b478:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b47c:	911263e1 	add	x1, sp, #0x498
    b480:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b484:	52800020 	mov	w0, #0x1                   	// #1
    b488:	f9024fe2 	str	x2, [sp, #1176]
    b48c:	f90253f5 	str	x21, [sp, #1184]
    b490:	97ffe898 	bl	56f0 <fwp_data.part.0.constprop.0>
    b494:	97ffe903 	bl	58a0 <fwp_rc_fresh>
    b498:	aa0003e2 	mov	x2, x0
    b49c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4a0:	9112a3e1 	add	x1, sp, #0x4a8
    b4a4:	52800020 	mov	w0, #0x1                   	// #1
    b4a8:	f90257e3 	str	x3, [sp, #1192]
    b4ac:	f9025be2 	str	x2, [sp, #1200]
    b4b0:	97ffe890 	bl	56f0 <fwp_data.part.0.constprop.0>
    b4b4:	91154283 	add	x3, x20, #0x550
    b4b8:	aa0003f5 	mov	x21, x0
    b4bc:	f949d861 	ldr	x1, [x3, #5040]
    b4c0:	f949ec60 	ldr	x0, [x3, #5080]
    b4c4:	cb0102a1 	sub	x1, x21, x1
    b4c8:	eb00403f 	cmp	x1, x0, lsl #16
    b4cc:	54000322 	b.cs	b530 <f0+0x1110>  // b.hs, b.nlast
    b4d0:	d350fc22 	lsr	x2, x1, #16
    b4d4:	f949fc63 	ldr	x3, [x3, #5112]
    b4d8:	8b020842 	add	x2, x2, x2, lsl #2
    b4dc:	d37df042 	lsl	x2, x2, #3
    b4e0:	8b020060 	add	x0, x3, x2
    b4e4:	f9401017 	ldr	x23, [x0, #32]
    b4e8:	b4000257 	cbz	x23, b530 <f0+0x1110>
    b4ec:	38626862 	ldrb	w2, [x3, x2]
    b4f0:	7100085f 	cmp	w2, #0x2
    b4f4:	54009be0 	b.eq	c870 <f0+0x2450>  // b.none
    b4f8:	7100045f 	cmp	w2, #0x1
    b4fc:	540001a1 	b.ne	b530 <f0+0x1110>  // b.any
    b500:	29430002 	ldp	w2, w0, [x0, #24]
    b504:	92403c21 	and	x1, x1, #0xffff
    b508:	9b027c21 	mul	x1, x1, x2
    b50c:	d360fc21 	lsr	x1, x1, #32
    b510:	eb00003f 	cmp	x1, x0
    b514:	540000e2 	b.cs	b530 <f0+0x1110>  // b.hs, b.nlast
    b518:	8b0102f7 	add	x23, x23, x1
    b51c:	394002e0 	ldrb	w0, [x23]
    b520:	7103fc1f 	cmp	w0, #0xff
    b524:	5400a3c0 	b.eq	c99c <f0+0x257c>  // b.none
    b528:	52800020 	mov	w0, #0x1                   	// #1
    b52c:	390002e0 	strb	w0, [x23]
    b530:	9112e3e1 	add	x1, sp, #0x4b8
    b534:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b538:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b53c:	52800020 	mov	w0, #0x1                   	// #1
    b540:	f9025ff7 	str	x23, [sp, #1208]
    b544:	f90263f5 	str	x21, [sp, #1216]
    b548:	97ffe86a 	bl	56f0 <fwp_data.part.0.constprop.0>
    b54c:	97ffe8d5 	bl	58a0 <fwp_rc_fresh>
    b550:	aa0003e2 	mov	x2, x0
    b554:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b558:	911323e1 	add	x1, sp, #0x4c8
    b55c:	52800020 	mov	w0, #0x1                   	// #1
    b560:	f90267e3 	str	x3, [sp, #1224]
    b564:	f9026be2 	str	x2, [sp, #1232]
    b568:	97ffe862 	bl	56f0 <fwp_data.part.0.constprop.0>
    b56c:	97ffe8cd 	bl	58a0 <fwp_rc_fresh>
    b570:	aa0003e2 	mov	x2, x0
    b574:	911363e1 	add	x1, sp, #0x4d8
    b578:	52800020 	mov	w0, #0x1                   	// #1
    b57c:	f9026ff7 	str	x23, [sp, #1240]
    b580:	f90273e2 	str	x2, [sp, #1248]
    b584:	97ffe85b 	bl	56f0 <fwp_data.part.0.constprop.0>
    b588:	91154283 	add	x3, x20, #0x550
    b58c:	aa0003f5 	mov	x21, x0
    b590:	f949d861 	ldr	x1, [x3, #5040]
    b594:	f949ec60 	ldr	x0, [x3, #5080]
    b598:	cb0102a1 	sub	x1, x21, x1
    b59c:	eb00403f 	cmp	x1, x0, lsl #16
    b5a0:	54000322 	b.cs	b604 <f0+0x11e4>  // b.hs, b.nlast
    b5a4:	d350fc22 	lsr	x2, x1, #16
    b5a8:	f949fc63 	ldr	x3, [x3, #5112]
    b5ac:	8b020842 	add	x2, x2, x2, lsl #2
    b5b0:	d37df042 	lsl	x2, x2, #3
    b5b4:	8b020060 	add	x0, x3, x2
    b5b8:	f9401017 	ldr	x23, [x0, #32]
    b5bc:	b4000257 	cbz	x23, b604 <f0+0x11e4>
    b5c0:	38626862 	ldrb	w2, [x3, x2]
    b5c4:	7100085f 	cmp	w2, #0x2
    b5c8:	54009660 	b.eq	c894 <f0+0x2474>  // b.none
    b5cc:	7100045f 	cmp	w2, #0x1
    b5d0:	540001a1 	b.ne	b604 <f0+0x11e4>  // b.any
    b5d4:	29430002 	ldp	w2, w0, [x0, #24]
    b5d8:	92403c21 	and	x1, x1, #0xffff
    b5dc:	9b027c21 	mul	x1, x1, x2
    b5e0:	d360fc21 	lsr	x1, x1, #32
    b5e4:	eb00003f 	cmp	x1, x0
    b5e8:	540000e2 	b.cs	b604 <f0+0x11e4>  // b.hs, b.nlast
    b5ec:	8b0102f7 	add	x23, x23, x1
    b5f0:	394002e0 	ldrb	w0, [x23]
    b5f4:	7103fc1f 	cmp	w0, #0xff
    b5f8:	54009d80 	b.eq	c9a8 <f0+0x2588>  // b.none
    b5fc:	52800020 	mov	w0, #0x1                   	// #1
    b600:	390002e0 	strb	w0, [x23]
    b604:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b608:	9113a3e1 	add	x1, sp, #0x4e8
    b60c:	52800020 	mov	w0, #0x1                   	// #1
    b610:	f90277e2 	str	x2, [sp, #1256]
    b614:	f9027bf5 	str	x21, [sp, #1264]
    b618:	97ffe836 	bl	56f0 <fwp_data.part.0.constprop.0>
    b61c:	91154283 	add	x3, x20, #0x550
    b620:	aa0003f5 	mov	x21, x0
    b624:	f949d861 	ldr	x1, [x3, #5040]
    b628:	f949ec60 	ldr	x0, [x3, #5080]
    b62c:	cb0102a1 	sub	x1, x21, x1
    b630:	eb00403f 	cmp	x1, x0, lsl #16
    b634:	54000322 	b.cs	b698 <f0+0x1278>  // b.hs, b.nlast
    b638:	d350fc22 	lsr	x2, x1, #16
    b63c:	f949fc63 	ldr	x3, [x3, #5112]
    b640:	8b020842 	add	x2, x2, x2, lsl #2
    b644:	d37df042 	lsl	x2, x2, #3
    b648:	8b020060 	add	x0, x3, x2
    b64c:	f9401017 	ldr	x23, [x0, #32]
    b650:	b4000257 	cbz	x23, b698 <f0+0x1278>
    b654:	38626862 	ldrb	w2, [x3, x2]
    b658:	7100085f 	cmp	w2, #0x2
    b65c:	54009160 	b.eq	c888 <f0+0x2468>  // b.none
    b660:	7100045f 	cmp	w2, #0x1
    b664:	540001a1 	b.ne	b698 <f0+0x1278>  // b.any
    b668:	29430002 	ldp	w2, w0, [x0, #24]
    b66c:	92403c21 	and	x1, x1, #0xffff
    b670:	9b027c21 	mul	x1, x1, x2
    b674:	d360fc21 	lsr	x1, x1, #32
    b678:	eb00003f 	cmp	x1, x0
    b67c:	540000e2 	b.cs	b698 <f0+0x1278>  // b.hs, b.nlast
    b680:	8b0102f7 	add	x23, x23, x1
    b684:	394002e0 	ldrb	w0, [x23]
    b688:	7103fc1f 	cmp	w0, #0xff
    b68c:	54009940 	b.eq	c9b4 <f0+0x2594>  // b.none
    b690:	52800020 	mov	w0, #0x1                   	// #1
    b694:	390002e0 	strb	w0, [x23]
    b698:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b69c:	9113e3e1 	add	x1, sp, #0x4f8
    b6a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6a4:	52800020 	mov	w0, #0x1                   	// #1
    b6a8:	f9027fe2 	str	x2, [sp, #1272]
    b6ac:	f90283f5 	str	x21, [sp, #1280]
    b6b0:	97ffe810 	bl	56f0 <fwp_data.part.0.constprop.0>
    b6b4:	97ffe87b 	bl	58a0 <fwp_rc_fresh>
    b6b8:	aa0003e2 	mov	x2, x0
    b6bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b6c0:	911423e1 	add	x1, sp, #0x508
    b6c4:	52800020 	mov	w0, #0x1                   	// #1
    b6c8:	f90287e3 	str	x3, [sp, #1288]
    b6cc:	f9028be2 	str	x2, [sp, #1296]
    b6d0:	97ffe808 	bl	56f0 <fwp_data.part.0.constprop.0>
    b6d4:	91154283 	add	x3, x20, #0x550
    b6d8:	aa0003f5 	mov	x21, x0
    b6dc:	f949d861 	ldr	x1, [x3, #5040]
    b6e0:	f949ec60 	ldr	x0, [x3, #5080]
    b6e4:	cb0102a1 	sub	x1, x21, x1
    b6e8:	eb00403f 	cmp	x1, x0, lsl #16
    b6ec:	54000322 	b.cs	b750 <f0+0x1330>  // b.hs, b.nlast
    b6f0:	d350fc22 	lsr	x2, x1, #16
    b6f4:	f949fc63 	ldr	x3, [x3, #5112]
    b6f8:	8b020842 	add	x2, x2, x2, lsl #2
    b6fc:	d37df042 	lsl	x2, x2, #3
    b700:	8b020060 	add	x0, x3, x2
    b704:	f9401017 	ldr	x23, [x0, #32]
    b708:	b4000257 	cbz	x23, b750 <f0+0x1330>
    b70c:	38626862 	ldrb	w2, [x3, x2]
    b710:	7100085f 	cmp	w2, #0x2
    b714:	54008cc0 	b.eq	c8ac <f0+0x248c>  // b.none
    b718:	7100045f 	cmp	w2, #0x1
    b71c:	540001a1 	b.ne	b750 <f0+0x1330>  // b.any
    b720:	29430002 	ldp	w2, w0, [x0, #24]
    b724:	92403c21 	and	x1, x1, #0xffff
    b728:	9b027c21 	mul	x1, x1, x2
    b72c:	d360fc21 	lsr	x1, x1, #32
    b730:	eb00003f 	cmp	x1, x0
    b734:	540000e2 	b.cs	b750 <f0+0x1330>  // b.hs, b.nlast
    b738:	8b0102f7 	add	x23, x23, x1
    b73c:	394002e0 	ldrb	w0, [x23]
    b740:	7103fc1f 	cmp	w0, #0xff
    b744:	540093e0 	b.eq	c9c0 <f0+0x25a0>  // b.none
    b748:	52800020 	mov	w0, #0x1                   	// #1
    b74c:	390002e0 	strb	w0, [x23]
    b750:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b754:	911463e1 	add	x1, sp, #0x518
    b758:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b75c:	52800020 	mov	w0, #0x1                   	// #1
    b760:	f9028fe2 	str	x2, [sp, #1304]
    b764:	f90293f5 	str	x21, [sp, #1312]
    b768:	97ffe7e2 	bl	56f0 <fwp_data.part.0.constprop.0>
    b76c:	97ffe84d 	bl	58a0 <fwp_rc_fresh>
    b770:	aa0003e2 	mov	x2, x0
    b774:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b778:	9114a3e1 	add	x1, sp, #0x528
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f90297e3 	str	x3, [sp, #1320]
    b784:	f9029be2 	str	x2, [sp, #1328]
    b788:	97ffe7da 	bl	56f0 <fwp_data.part.0.constprop.0>
    b78c:	91154283 	add	x3, x20, #0x550
    b790:	aa0003f5 	mov	x21, x0
    b794:	f949d861 	ldr	x1, [x3, #5040]
    b798:	f949ec60 	ldr	x0, [x3, #5080]
    b79c:	cb0102a1 	sub	x1, x21, x1
    b7a0:	eb00403f 	cmp	x1, x0, lsl #16
    b7a4:	54000322 	b.cs	b808 <f0+0x13e8>  // b.hs, b.nlast
    b7a8:	d350fc22 	lsr	x2, x1, #16
    b7ac:	f949fc63 	ldr	x3, [x3, #5112]
    b7b0:	8b020842 	add	x2, x2, x2, lsl #2
    b7b4:	d37df042 	lsl	x2, x2, #3
    b7b8:	8b020060 	add	x0, x3, x2
    b7bc:	f9401017 	ldr	x23, [x0, #32]
    b7c0:	b4000257 	cbz	x23, b808 <f0+0x13e8>
    b7c4:	38626862 	ldrb	w2, [x3, x2]
    b7c8:	7100085f 	cmp	w2, #0x2
    b7cc:	540086a0 	b.eq	c8a0 <f0+0x2480>  // b.none
    b7d0:	7100045f 	cmp	w2, #0x1
    b7d4:	540001a1 	b.ne	b808 <f0+0x13e8>  // b.any
    b7d8:	29430002 	ldp	w2, w0, [x0, #24]
    b7dc:	92403c21 	and	x1, x1, #0xffff
    b7e0:	9b027c21 	mul	x1, x1, x2
    b7e4:	d360fc21 	lsr	x1, x1, #32
    b7e8:	eb00003f 	cmp	x1, x0
    b7ec:	540000e2 	b.cs	b808 <f0+0x13e8>  // b.hs, b.nlast
    b7f0:	8b0102f7 	add	x23, x23, x1
    b7f4:	394002e0 	ldrb	w0, [x23]
    b7f8:	7103fc1f 	cmp	w0, #0xff
    b7fc:	54008e80 	b.eq	c9cc <f0+0x25ac>  // b.none
    b800:	52800020 	mov	w0, #0x1                   	// #1
    b804:	390002e0 	strb	w0, [x23]
    b808:	9114e3e1 	add	x1, sp, #0x538
    b80c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b810:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	f9029ff7 	str	x23, [sp, #1336]
    b81c:	f902a3f5 	str	x21, [sp, #1344]
    b820:	97ffe7b4 	bl	56f0 <fwp_data.part.0.constprop.0>
    b824:	97ffe81f 	bl	58a0 <fwp_rc_fresh>
    b828:	aa0003e2 	mov	x2, x0
    b82c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b830:	911523e1 	add	x1, sp, #0x548
    b834:	52800020 	mov	w0, #0x1                   	// #1
    b838:	f902a7e3 	str	x3, [sp, #1352]
    b83c:	f902abe2 	str	x2, [sp, #1360]
    b840:	97ffe7ac 	bl	56f0 <fwp_data.part.0.constprop.0>
    b844:	97ffe817 	bl	58a0 <fwp_rc_fresh>
    b848:	aa0003e2 	mov	x2, x0
    b84c:	911563e1 	add	x1, sp, #0x558
    b850:	52800020 	mov	w0, #0x1                   	// #1
    b854:	f902aff7 	str	x23, [sp, #1368]
    b858:	f902b3e2 	str	x2, [sp, #1376]
    b85c:	97ffe7a5 	bl	56f0 <fwp_data.part.0.constprop.0>
    b860:	91154283 	add	x3, x20, #0x550
    b864:	aa0003f5 	mov	x21, x0
    b868:	f949d861 	ldr	x1, [x3, #5040]
    b86c:	f949ec60 	ldr	x0, [x3, #5080]
    b870:	cb0102a1 	sub	x1, x21, x1
    b874:	eb00403f 	cmp	x1, x0, lsl #16
    b878:	54000322 	b.cs	b8dc <f0+0x14bc>  // b.hs, b.nlast
    b87c:	d350fc22 	lsr	x2, x1, #16
    b880:	f949fc63 	ldr	x3, [x3, #5112]
    b884:	8b020842 	add	x2, x2, x2, lsl #2
    b888:	d37df042 	lsl	x2, x2, #3
    b88c:	8b020060 	add	x0, x3, x2
    b890:	f9401017 	ldr	x23, [x0, #32]
    b894:	b4000257 	cbz	x23, b8dc <f0+0x14bc>
    b898:	38626862 	ldrb	w2, [x3, x2]
    b89c:	7100085f 	cmp	w2, #0x2
    b8a0:	54008120 	b.eq	c8c4 <f0+0x24a4>  // b.none
    b8a4:	7100045f 	cmp	w2, #0x1
    b8a8:	540001a1 	b.ne	b8dc <f0+0x14bc>  // b.any
    b8ac:	29430002 	ldp	w2, w0, [x0, #24]
    b8b0:	92403c21 	and	x1, x1, #0xffff
    b8b4:	9b027c21 	mul	x1, x1, x2
    b8b8:	d360fc21 	lsr	x1, x1, #32
    b8bc:	eb00003f 	cmp	x1, x0
    b8c0:	540000e2 	b.cs	b8dc <f0+0x14bc>  // b.hs, b.nlast
    b8c4:	8b0102f7 	add	x23, x23, x1
    b8c8:	394002e0 	ldrb	w0, [x23]
    b8cc:	7103fc1f 	cmp	w0, #0xff
    b8d0:	54008840 	b.eq	c9d8 <f0+0x25b8>  // b.none
    b8d4:	52800020 	mov	w0, #0x1                   	// #1
    b8d8:	390002e0 	strb	w0, [x23]
    b8dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b8e0:	9115a3e1 	add	x1, sp, #0x568
    b8e4:	52800020 	mov	w0, #0x1                   	// #1
    b8e8:	f902b7e2 	str	x2, [sp, #1384]
    b8ec:	f902bbf5 	str	x21, [sp, #1392]
    b8f0:	97ffe780 	bl	56f0 <fwp_data.part.0.constprop.0>
    b8f4:	91154283 	add	x3, x20, #0x550
    b8f8:	aa0003f5 	mov	x21, x0
    b8fc:	f949d861 	ldr	x1, [x3, #5040]
    b900:	f949ec60 	ldr	x0, [x3, #5080]
    b904:	cb0102a1 	sub	x1, x21, x1
    b908:	eb00403f 	cmp	x1, x0, lsl #16
    b90c:	54000322 	b.cs	b970 <f0+0x1550>  // b.hs, b.nlast
    b910:	d350fc22 	lsr	x2, x1, #16
    b914:	f949fc63 	ldr	x3, [x3, #5112]
    b918:	8b020842 	add	x2, x2, x2, lsl #2
    b91c:	d37df042 	lsl	x2, x2, #3
    b920:	8b020060 	add	x0, x3, x2
    b924:	f9401017 	ldr	x23, [x0, #32]
    b928:	b4000257 	cbz	x23, b970 <f0+0x1550>
    b92c:	38626862 	ldrb	w2, [x3, x2]
    b930:	7100085f 	cmp	w2, #0x2
    b934:	54007c20 	b.eq	c8b8 <f0+0x2498>  // b.none
    b938:	7100045f 	cmp	w2, #0x1
    b93c:	540001a1 	b.ne	b970 <f0+0x1550>  // b.any
    b940:	29430002 	ldp	w2, w0, [x0, #24]
    b944:	92403c21 	and	x1, x1, #0xffff
    b948:	9b027c21 	mul	x1, x1, x2
    b94c:	d360fc21 	lsr	x1, x1, #32
    b950:	eb00003f 	cmp	x1, x0
    b954:	540000e2 	b.cs	b970 <f0+0x1550>  // b.hs, b.nlast
    b958:	8b0102f7 	add	x23, x23, x1
    b95c:	394002e0 	ldrb	w0, [x23]
    b960:	7103fc1f 	cmp	w0, #0xff
    b964:	54008400 	b.eq	c9e4 <f0+0x25c4>  // b.none
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	390002e0 	strb	w0, [x23]
    b970:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b974:	9115e3e1 	add	x1, sp, #0x578
    b978:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b97c:	52800020 	mov	w0, #0x1                   	// #1
    b980:	f902bfe2 	str	x2, [sp, #1400]
    b984:	f902c3f5 	str	x21, [sp, #1408]
    b988:	97ffe75a 	bl	56f0 <fwp_data.part.0.constprop.0>
    b98c:	97ffe7c5 	bl	58a0 <fwp_rc_fresh>
    b990:	aa0003e2 	mov	x2, x0
    b994:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b998:	911623e1 	add	x1, sp, #0x588
    b99c:	52800020 	mov	w0, #0x1                   	// #1
    b9a0:	f902c7e3 	str	x3, [sp, #1416]
    b9a4:	f902cbe2 	str	x2, [sp, #1424]
    b9a8:	97ffe752 	bl	56f0 <fwp_data.part.0.constprop.0>
    b9ac:	91154283 	add	x3, x20, #0x550
    b9b0:	aa0003f5 	mov	x21, x0
    b9b4:	f949d861 	ldr	x1, [x3, #5040]
    b9b8:	f949ec60 	ldr	x0, [x3, #5080]
    b9bc:	cb0102a1 	sub	x1, x21, x1
    b9c0:	eb00403f 	cmp	x1, x0, lsl #16
    b9c4:	54000322 	b.cs	ba28 <f0+0x1608>  // b.hs, b.nlast
    b9c8:	d350fc22 	lsr	x2, x1, #16
    b9cc:	f949fc63 	ldr	x3, [x3, #5112]
    b9d0:	8b020842 	add	x2, x2, x2, lsl #2
    b9d4:	d37df042 	lsl	x2, x2, #3
    b9d8:	8b020060 	add	x0, x3, x2
    b9dc:	f9401017 	ldr	x23, [x0, #32]
    b9e0:	b4000257 	cbz	x23, ba28 <f0+0x1608>
    b9e4:	38626862 	ldrb	w2, [x3, x2]
    b9e8:	7100085f 	cmp	w2, #0x2
    b9ec:	54006b80 	b.eq	c75c <f0+0x233c>  // b.none
    b9f0:	7100045f 	cmp	w2, #0x1
    b9f4:	540001a1 	b.ne	ba28 <f0+0x1608>  // b.any
    b9f8:	29430002 	ldp	w2, w0, [x0, #24]
    b9fc:	92403c21 	and	x1, x1, #0xffff
    ba00:	9b027c21 	mul	x1, x1, x2
    ba04:	d360fc21 	lsr	x1, x1, #32
    ba08:	eb00003f 	cmp	x1, x0
    ba0c:	540000e2 	b.cs	ba28 <f0+0x1608>  // b.hs, b.nlast
    ba10:	8b0102f7 	add	x23, x23, x1
    ba14:	394002e0 	ldrb	w0, [x23]
    ba18:	7103fc1f 	cmp	w0, #0xff
    ba1c:	54007ea0 	b.eq	c9f0 <f0+0x25d0>  // b.none
    ba20:	52800020 	mov	w0, #0x1                   	// #1
    ba24:	390002e0 	strb	w0, [x23]
    ba28:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ba2c:	911663e1 	add	x1, sp, #0x598
    ba30:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ba34:	52800020 	mov	w0, #0x1                   	// #1
    ba38:	f902cfe2 	str	x2, [sp, #1432]
    ba3c:	f902d3f5 	str	x21, [sp, #1440]
    ba40:	97ffe72c 	bl	56f0 <fwp_data.part.0.constprop.0>
    ba44:	97ffe797 	bl	58a0 <fwp_rc_fresh>
    ba48:	aa0003e2 	mov	x2, x0
    ba4c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ba50:	9116a3e1 	add	x1, sp, #0x5a8
    ba54:	52800020 	mov	w0, #0x1                   	// #1
    ba58:	f902d7e3 	str	x3, [sp, #1448]
    ba5c:	f902dbe2 	str	x2, [sp, #1456]
    ba60:	97ffe724 	bl	56f0 <fwp_data.part.0.constprop.0>
    ba64:	91154283 	add	x3, x20, #0x550
    ba68:	aa0003f5 	mov	x21, x0
    ba6c:	f949d861 	ldr	x1, [x3, #5040]
    ba70:	f949ec60 	ldr	x0, [x3, #5080]
    ba74:	cb0102a1 	sub	x1, x21, x1
    ba78:	eb00403f 	cmp	x1, x0, lsl #16
    ba7c:	54000322 	b.cs	bae0 <f0+0x16c0>  // b.hs, b.nlast
    ba80:	d350fc22 	lsr	x2, x1, #16
    ba84:	f949fc63 	ldr	x3, [x3, #5112]
    ba88:	8b020842 	add	x2, x2, x2, lsl #2
    ba8c:	d37df042 	lsl	x2, x2, #3
    ba90:	8b020060 	add	x0, x3, x2
    ba94:	f9401017 	ldr	x23, [x0, #32]
    ba98:	b4000257 	cbz	x23, bae0 <f0+0x16c0>
    ba9c:	38626862 	ldrb	w2, [x3, x2]
    baa0:	7100085f 	cmp	w2, #0x2
    baa4:	54006560 	b.eq	c750 <f0+0x2330>  // b.none
    baa8:	7100045f 	cmp	w2, #0x1
    baac:	540001a1 	b.ne	bae0 <f0+0x16c0>  // b.any
    bab0:	29430002 	ldp	w2, w0, [x0, #24]
    bab4:	92403c21 	and	x1, x1, #0xffff
    bab8:	9b027c21 	mul	x1, x1, x2
    babc:	d360fc21 	lsr	x1, x1, #32
    bac0:	eb00003f 	cmp	x1, x0
    bac4:	540000e2 	b.cs	bae0 <f0+0x16c0>  // b.hs, b.nlast
    bac8:	8b0102f7 	add	x23, x23, x1
    bacc:	394002e0 	ldrb	w0, [x23]
    bad0:	7103fc1f 	cmp	w0, #0xff
    bad4:	54007940 	b.eq	c9fc <f0+0x25dc>  // b.none
    bad8:	52800020 	mov	w0, #0x1                   	// #1
    badc:	390002e0 	strb	w0, [x23]
    bae0:	9116e3e1 	add	x1, sp, #0x5b8
    bae4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bae8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    baec:	52800020 	mov	w0, #0x1                   	// #1
    baf0:	f902dff7 	str	x23, [sp, #1464]
    baf4:	f902e3f5 	str	x21, [sp, #1472]
    baf8:	97ffe6fe 	bl	56f0 <fwp_data.part.0.constprop.0>
    bafc:	97ffe769 	bl	58a0 <fwp_rc_fresh>
    bb00:	aa0003e2 	mov	x2, x0
    bb04:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bb08:	911723e1 	add	x1, sp, #0x5c8
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	f902e7e3 	str	x3, [sp, #1480]
    bb14:	f902ebe2 	str	x2, [sp, #1488]
    bb18:	97ffe6f6 	bl	56f0 <fwp_data.part.0.constprop.0>
    bb1c:	97ffe761 	bl	58a0 <fwp_rc_fresh>
    bb20:	aa0003e2 	mov	x2, x0
    bb24:	911763e1 	add	x1, sp, #0x5d8
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	f902eff7 	str	x23, [sp, #1496]
    bb30:	f902f3e2 	str	x2, [sp, #1504]
    bb34:	97ffe6ef 	bl	56f0 <fwp_data.part.0.constprop.0>
    bb38:	91154283 	add	x3, x20, #0x550
    bb3c:	aa0003f5 	mov	x21, x0
    bb40:	f949d861 	ldr	x1, [x3, #5040]
    bb44:	f949ec60 	ldr	x0, [x3, #5080]
    bb48:	cb0102a1 	sub	x1, x21, x1
    bb4c:	eb00403f 	cmp	x1, x0, lsl #16
    bb50:	54000322 	b.cs	bbb4 <f0+0x1794>  // b.hs, b.nlast
    bb54:	d350fc22 	lsr	x2, x1, #16
    bb58:	f949fc63 	ldr	x3, [x3, #5112]
    bb5c:	8b020842 	add	x2, x2, x2, lsl #2
    bb60:	d37df042 	lsl	x2, x2, #3
    bb64:	8b020060 	add	x0, x3, x2
    bb68:	f9401017 	ldr	x23, [x0, #32]
    bb6c:	b4000257 	cbz	x23, bbb4 <f0+0x1794>
    bb70:	38626862 	ldrb	w2, [x3, x2]
    bb74:	7100085f 	cmp	w2, #0x2
    bb78:	54005fe0 	b.eq	c774 <f0+0x2354>  // b.none
    bb7c:	7100045f 	cmp	w2, #0x1
    bb80:	540001a1 	b.ne	bbb4 <f0+0x1794>  // b.any
    bb84:	29430002 	ldp	w2, w0, [x0, #24]
    bb88:	92403c21 	and	x1, x1, #0xffff
    bb8c:	9b027c21 	mul	x1, x1, x2
    bb90:	d360fc21 	lsr	x1, x1, #32
    bb94:	eb00003f 	cmp	x1, x0
    bb98:	540000e2 	b.cs	bbb4 <f0+0x1794>  // b.hs, b.nlast
    bb9c:	8b0102f7 	add	x23, x23, x1
    bba0:	394002e0 	ldrb	w0, [x23]
    bba4:	7103fc1f 	cmp	w0, #0xff
    bba8:	54007300 	b.eq	ca08 <f0+0x25e8>  // b.none
    bbac:	52800020 	mov	w0, #0x1                   	// #1
    bbb0:	390002e0 	strb	w0, [x23]
    bbb4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbb8:	9117a3e1 	add	x1, sp, #0x5e8
    bbbc:	52800020 	mov	w0, #0x1                   	// #1
    bbc0:	f902f7e2 	str	x2, [sp, #1512]
    bbc4:	f902fbf5 	str	x21, [sp, #1520]
    bbc8:	97ffe6ca 	bl	56f0 <fwp_data.part.0.constprop.0>
    bbcc:	91154283 	add	x3, x20, #0x550
    bbd0:	aa0003f5 	mov	x21, x0
    bbd4:	f949d861 	ldr	x1, [x3, #5040]
    bbd8:	f949ec60 	ldr	x0, [x3, #5080]
    bbdc:	cb0102a1 	sub	x1, x21, x1
    bbe0:	eb00403f 	cmp	x1, x0, lsl #16
    bbe4:	54000322 	b.cs	bc48 <f0+0x1828>  // b.hs, b.nlast
    bbe8:	d350fc22 	lsr	x2, x1, #16
    bbec:	f949fc63 	ldr	x3, [x3, #5112]
    bbf0:	8b020842 	add	x2, x2, x2, lsl #2
    bbf4:	d37df042 	lsl	x2, x2, #3
    bbf8:	8b020060 	add	x0, x3, x2
    bbfc:	f9401017 	ldr	x23, [x0, #32]
    bc00:	b4000257 	cbz	x23, bc48 <f0+0x1828>
    bc04:	38626862 	ldrb	w2, [x3, x2]
    bc08:	7100085f 	cmp	w2, #0x2
    bc0c:	54005ae0 	b.eq	c768 <f0+0x2348>  // b.none
    bc10:	7100045f 	cmp	w2, #0x1
    bc14:	540001a1 	b.ne	bc48 <f0+0x1828>  // b.any
    bc18:	29430002 	ldp	w2, w0, [x0, #24]
    bc1c:	92403c21 	and	x1, x1, #0xffff
    bc20:	9b027c21 	mul	x1, x1, x2
    bc24:	d360fc21 	lsr	x1, x1, #32
    bc28:	eb00003f 	cmp	x1, x0
    bc2c:	540000e2 	b.cs	bc48 <f0+0x1828>  // b.hs, b.nlast
    bc30:	8b0102f7 	add	x23, x23, x1
    bc34:	394002e0 	ldrb	w0, [x23]
    bc38:	7103fc1f 	cmp	w0, #0xff
    bc3c:	54006ec0 	b.eq	ca14 <f0+0x25f4>  // b.none
    bc40:	52800020 	mov	w0, #0x1                   	// #1
    bc44:	390002e0 	strb	w0, [x23]
    bc48:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc4c:	9117e3e1 	add	x1, sp, #0x5f8
    bc50:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc54:	52800020 	mov	w0, #0x1                   	// #1
    bc58:	f902ffe2 	str	x2, [sp, #1528]
    bc5c:	f90303f5 	str	x21, [sp, #1536]
    bc60:	97ffe6a4 	bl	56f0 <fwp_data.part.0.constprop.0>
    bc64:	97ffe70f 	bl	58a0 <fwp_rc_fresh>
    bc68:	aa0003e2 	mov	x2, x0
    bc6c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bc70:	911823e1 	add	x1, sp, #0x608
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	f90307e3 	str	x3, [sp, #1544]
    bc7c:	f9030be2 	str	x2, [sp, #1552]
    bc80:	97ffe69c 	bl	56f0 <fwp_data.part.0.constprop.0>
    bc84:	91154283 	add	x3, x20, #0x550
    bc88:	aa0003f5 	mov	x21, x0
    bc8c:	f949d861 	ldr	x1, [x3, #5040]
    bc90:	f949ec60 	ldr	x0, [x3, #5080]
    bc94:	cb0102a1 	sub	x1, x21, x1
    bc98:	eb00403f 	cmp	x1, x0, lsl #16
    bc9c:	54000322 	b.cs	bd00 <f0+0x18e0>  // b.hs, b.nlast
    bca0:	d350fc22 	lsr	x2, x1, #16
    bca4:	f949fc63 	ldr	x3, [x3, #5112]
    bca8:	8b020842 	add	x2, x2, x2, lsl #2
    bcac:	d37df042 	lsl	x2, x2, #3
    bcb0:	8b020060 	add	x0, x3, x2
    bcb4:	f9401017 	ldr	x23, [x0, #32]
    bcb8:	b4000257 	cbz	x23, bd00 <f0+0x18e0>
    bcbc:	38626862 	ldrb	w2, [x3, x2]
    bcc0:	7100085f 	cmp	w2, #0x2
    bcc4:	54005640 	b.eq	c78c <f0+0x236c>  // b.none
    bcc8:	7100045f 	cmp	w2, #0x1
    bccc:	540001a1 	b.ne	bd00 <f0+0x18e0>  // b.any
    bcd0:	29430002 	ldp	w2, w0, [x0, #24]
    bcd4:	92403c21 	and	x1, x1, #0xffff
    bcd8:	9b027c21 	mul	x1, x1, x2
    bcdc:	d360fc21 	lsr	x1, x1, #32
    bce0:	eb00003f 	cmp	x1, x0
    bce4:	540000e2 	b.cs	bd00 <f0+0x18e0>  // b.hs, b.nlast
    bce8:	8b0102f7 	add	x23, x23, x1
    bcec:	394002e0 	ldrb	w0, [x23]
    bcf0:	7103fc1f 	cmp	w0, #0xff
    bcf4:	54006960 	b.eq	ca20 <f0+0x2600>  // b.none
    bcf8:	52800020 	mov	w0, #0x1                   	// #1
    bcfc:	390002e0 	strb	w0, [x23]
    bd00:	911863e1 	add	x1, sp, #0x618
    bd04:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd08:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd0c:	52800020 	mov	w0, #0x1                   	// #1
    bd10:	f9030ff7 	str	x23, [sp, #1560]
    bd14:	f90313f5 	str	x21, [sp, #1568]
    bd18:	97ffe676 	bl	56f0 <fwp_data.part.0.constprop.0>
    bd1c:	97ffe6e1 	bl	58a0 <fwp_rc_fresh>
    bd20:	aa0003e2 	mov	x2, x0
    bd24:	9118a3e1 	add	x1, sp, #0x628
    bd28:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd2c:	52800020 	mov	w0, #0x1                   	// #1
    bd30:	f90317f5 	str	x21, [sp, #1576]
    bd34:	f9031be2 	str	x2, [sp, #1584]
    bd38:	97ffe66e 	bl	56f0 <fwp_data.part.0.constprop.0>
    bd3c:	97ffe6d9 	bl	58a0 <fwp_rc_fresh>
    bd40:	aa0003e2 	mov	x2, x0
    bd44:	9118e3e1 	add	x1, sp, #0x638
    bd48:	52800020 	mov	w0, #0x1                   	// #1
    bd4c:	f9031ff7 	str	x23, [sp, #1592]
    bd50:	f90323e2 	str	x2, [sp, #1600]
    bd54:	97ffe667 	bl	56f0 <fwp_data.part.0.constprop.0>
    bd58:	97ffe6d2 	bl	58a0 <fwp_rc_fresh>
    bd5c:	aa0003e2 	mov	x2, x0
    bd60:	911923e1 	add	x1, sp, #0x648
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	f90327f5 	str	x21, [sp, #1608]
    bd6c:	f9032be2 	str	x2, [sp, #1616]
    bd70:	97ffe660 	bl	56f0 <fwp_data.part.0.constprop.0>
    bd74:	91154283 	add	x3, x20, #0x550
    bd78:	aa0003f5 	mov	x21, x0
    bd7c:	f949d861 	ldr	x1, [x3, #5040]
    bd80:	f949ec60 	ldr	x0, [x3, #5080]
    bd84:	cb0102a1 	sub	x1, x21, x1
    bd88:	eb00403f 	cmp	x1, x0, lsl #16
    bd8c:	54000322 	b.cs	bdf0 <f0+0x19d0>  // b.hs, b.nlast
    bd90:	d350fc22 	lsr	x2, x1, #16
    bd94:	f949fc63 	ldr	x3, [x3, #5112]
    bd98:	8b020842 	add	x2, x2, x2, lsl #2
    bd9c:	d37df042 	lsl	x2, x2, #3
    bda0:	8b020060 	add	x0, x3, x2
    bda4:	f9401017 	ldr	x23, [x0, #32]
    bda8:	b4000257 	cbz	x23, bdf0 <f0+0x19d0>
    bdac:	38626862 	ldrb	w2, [x3, x2]
    bdb0:	7100085f 	cmp	w2, #0x2
    bdb4:	54004e60 	b.eq	c780 <f0+0x2360>  // b.none
    bdb8:	7100045f 	cmp	w2, #0x1
    bdbc:	540001a1 	b.ne	bdf0 <f0+0x19d0>  // b.any
    bdc0:	29430002 	ldp	w2, w0, [x0, #24]
    bdc4:	92403c21 	and	x1, x1, #0xffff
    bdc8:	9b027c21 	mul	x1, x1, x2
    bdcc:	d360fc21 	lsr	x1, x1, #32
    bdd0:	eb00003f 	cmp	x1, x0
    bdd4:	540000e2 	b.cs	bdf0 <f0+0x19d0>  // b.hs, b.nlast
    bdd8:	8b0102f7 	add	x23, x23, x1
    bddc:	394002e0 	ldrb	w0, [x23]
    bde0:	7103fc1f 	cmp	w0, #0xff
    bde4:	54006240 	b.eq	ca2c <f0+0x260c>  // b.none
    bde8:	52800020 	mov	w0, #0x1                   	// #1
    bdec:	390002e0 	strb	w0, [x23]
    bdf0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bdf4:	911963e1 	add	x1, sp, #0x658
    bdf8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bdfc:	52800020 	mov	w0, #0x1                   	// #1
    be00:	f9032fe2 	str	x2, [sp, #1624]
    be04:	f90333f5 	str	x21, [sp, #1632]
    be08:	97ffe63a 	bl	56f0 <fwp_data.part.0.constprop.0>
    be0c:	91154283 	add	x3, x20, #0x550
    be10:	aa0003f5 	mov	x21, x0
    be14:	f949d861 	ldr	x1, [x3, #5040]
    be18:	f949ec60 	ldr	x0, [x3, #5080]
    be1c:	cb0102a1 	sub	x1, x21, x1
    be20:	eb00403f 	cmp	x1, x0, lsl #16
    be24:	54000322 	b.cs	be88 <f0+0x1a68>  // b.hs, b.nlast
    be28:	d350fc22 	lsr	x2, x1, #16
    be2c:	f949fc63 	ldr	x3, [x3, #5112]
    be30:	8b020842 	add	x2, x2, x2, lsl #2
    be34:	d37df042 	lsl	x2, x2, #3
    be38:	8b020060 	add	x0, x3, x2
    be3c:	f9401017 	ldr	x23, [x0, #32]
    be40:	b4000257 	cbz	x23, be88 <f0+0x1a68>
    be44:	38626862 	ldrb	w2, [x3, x2]
    be48:	7100085f 	cmp	w2, #0x2
    be4c:	54004ac0 	b.eq	c7a4 <f0+0x2384>  // b.none
    be50:	7100045f 	cmp	w2, #0x1
    be54:	540001a1 	b.ne	be88 <f0+0x1a68>  // b.any
    be58:	29430002 	ldp	w2, w0, [x0, #24]
    be5c:	92403c21 	and	x1, x1, #0xffff
    be60:	9b027c21 	mul	x1, x1, x2
    be64:	d360fc21 	lsr	x1, x1, #32
    be68:	eb00003f 	cmp	x1, x0
    be6c:	540000e2 	b.cs	be88 <f0+0x1a68>  // b.hs, b.nlast
    be70:	8b0102f7 	add	x23, x23, x1
    be74:	394002e0 	ldrb	w0, [x23]
    be78:	7103fc1f 	cmp	w0, #0xff
    be7c:	54005de0 	b.eq	ca38 <f0+0x2618>  // b.none
    be80:	52800020 	mov	w0, #0x1                   	// #1
    be84:	390002e0 	strb	w0, [x23]
    be88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    be8c:	9119a3e1 	add	x1, sp, #0x668
    be90:	52800020 	mov	w0, #0x1                   	// #1
    be94:	f90337e2 	str	x2, [sp, #1640]
    be98:	f9033bf5 	str	x21, [sp, #1648]
    be9c:	97ffe615 	bl	56f0 <fwp_data.part.0.constprop.0>
    bea0:	91154283 	add	x3, x20, #0x550
    bea4:	aa0003f5 	mov	x21, x0
    bea8:	f949d861 	ldr	x1, [x3, #5040]
    beac:	f949ec60 	ldr	x0, [x3, #5080]
    beb0:	cb0102a1 	sub	x1, x21, x1
    beb4:	eb00403f 	cmp	x1, x0, lsl #16
    beb8:	54000322 	b.cs	bf1c <f0+0x1afc>  // b.hs, b.nlast
    bebc:	d350fc22 	lsr	x2, x1, #16
    bec0:	f949fc63 	ldr	x3, [x3, #5112]
    bec4:	8b020842 	add	x2, x2, x2, lsl #2
    bec8:	d37df042 	lsl	x2, x2, #3
    becc:	8b020060 	add	x0, x3, x2
    bed0:	f9401017 	ldr	x23, [x0, #32]
    bed4:	b4000257 	cbz	x23, bf1c <f0+0x1afc>
    bed8:	38626862 	ldrb	w2, [x3, x2]
    bedc:	7100085f 	cmp	w2, #0x2
    bee0:	540045c0 	b.eq	c798 <f0+0x2378>  // b.none
    bee4:	7100045f 	cmp	w2, #0x1
    bee8:	540001a1 	b.ne	bf1c <f0+0x1afc>  // b.any
    beec:	29430002 	ldp	w2, w0, [x0, #24]
    bef0:	92403c21 	and	x1, x1, #0xffff
    bef4:	9b027c21 	mul	x1, x1, x2
    bef8:	d360fc21 	lsr	x1, x1, #32
    befc:	eb00003f 	cmp	x1, x0
    bf00:	540000e2 	b.cs	bf1c <f0+0x1afc>  // b.hs, b.nlast
    bf04:	8b0102f7 	add	x23, x23, x1
    bf08:	394002e0 	ldrb	w0, [x23]
    bf0c:	7103fc1f 	cmp	w0, #0xff
    bf10:	540059a0 	b.eq	ca44 <f0+0x2624>  // b.none
    bf14:	52800020 	mov	w0, #0x1                   	// #1
    bf18:	390002e0 	strb	w0, [x23]
    bf1c:	9119e3e1 	add	x1, sp, #0x678
    bf20:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bf24:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bf28:	52800020 	mov	w0, #0x1                   	// #1
    bf2c:	f9033ff7 	str	x23, [sp, #1656]
    bf30:	f90343f5 	str	x21, [sp, #1664]
    bf34:	97ffe5ef 	bl	56f0 <fwp_data.part.0.constprop.0>
    bf38:	97ffe65a 	bl	58a0 <fwp_rc_fresh>
    bf3c:	aa0003e2 	mov	x2, x0
    bf40:	911a23e1 	add	x1, sp, #0x688
    bf44:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	f90347f5 	str	x21, [sp, #1672]
    bf50:	f9034be2 	str	x2, [sp, #1680]
    bf54:	97ffe5e7 	bl	56f0 <fwp_data.part.0.constprop.0>
    bf58:	97ffe652 	bl	58a0 <fwp_rc_fresh>
    bf5c:	aa0003e2 	mov	x2, x0
    bf60:	911a63e1 	add	x1, sp, #0x698
    bf64:	52800020 	mov	w0, #0x1                   	// #1
    bf68:	f9034ff7 	str	x23, [sp, #1688]
    bf6c:	f90353e2 	str	x2, [sp, #1696]
    bf70:	97ffe5e0 	bl	56f0 <fwp_data.part.0.constprop.0>
    bf74:	97ffe64b 	bl	58a0 <fwp_rc_fresh>
    bf78:	aa0003e2 	mov	x2, x0
    bf7c:	911aa3e1 	add	x1, sp, #0x6a8
    bf80:	52800020 	mov	w0, #0x1                   	// #1
    bf84:	f90357f5 	str	x21, [sp, #1704]
    bf88:	f9035be2 	str	x2, [sp, #1712]
    bf8c:	97ffe5d9 	bl	56f0 <fwp_data.part.0.constprop.0>
    bf90:	91154283 	add	x3, x20, #0x550
    bf94:	aa0003f5 	mov	x21, x0
    bf98:	f949d861 	ldr	x1, [x3, #5040]
    bf9c:	f949ec60 	ldr	x0, [x3, #5080]
    bfa0:	cb0102a1 	sub	x1, x21, x1
    bfa4:	eb00403f 	cmp	x1, x0, lsl #16
    bfa8:	54000322 	b.cs	c00c <f0+0x1bec>  // b.hs, b.nlast
    bfac:	d350fc22 	lsr	x2, x1, #16
    bfb0:	f949fc63 	ldr	x3, [x3, #5112]
    bfb4:	8b020842 	add	x2, x2, x2, lsl #2
    bfb8:	d37df042 	lsl	x2, x2, #3
    bfbc:	8b020060 	add	x0, x3, x2
    bfc0:	f9401017 	ldr	x23, [x0, #32]
    bfc4:	b4000257 	cbz	x23, c00c <f0+0x1bec>
    bfc8:	38626862 	ldrb	w2, [x3, x2]
    bfcc:	7100085f 	cmp	w2, #0x2
    bfd0:	54003f60 	b.eq	c7bc <f0+0x239c>  // b.none
    bfd4:	7100045f 	cmp	w2, #0x1
    bfd8:	540001a1 	b.ne	c00c <f0+0x1bec>  // b.any
    bfdc:	29430002 	ldp	w2, w0, [x0, #24]
    bfe0:	92403c21 	and	x1, x1, #0xffff
    bfe4:	9b027c21 	mul	x1, x1, x2
    bfe8:	d360fc21 	lsr	x1, x1, #32
    bfec:	eb00003f 	cmp	x1, x0
    bff0:	540000e2 	b.cs	c00c <f0+0x1bec>  // b.hs, b.nlast
    bff4:	8b0102f7 	add	x23, x23, x1
    bff8:	394002e0 	ldrb	w0, [x23]
    bffc:	7103fc1f 	cmp	w0, #0xff
    c000:	54005280 	b.eq	ca50 <f0+0x2630>  // b.none
    c004:	52800020 	mov	w0, #0x1                   	// #1
    c008:	390002e0 	strb	w0, [x23]
    c00c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c010:	911ae3e1 	add	x1, sp, #0x6b8
    c014:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c018:	52800020 	mov	w0, #0x1                   	// #1
    c01c:	f9035fe2 	str	x2, [sp, #1720]
    c020:	f90363f5 	str	x21, [sp, #1728]
    c024:	97ffe5b3 	bl	56f0 <fwp_data.part.0.constprop.0>
    c028:	97ffe61e 	bl	58a0 <fwp_rc_fresh>
    c02c:	aa0003e2 	mov	x2, x0
    c030:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c034:	911b23e1 	add	x1, sp, #0x6c8
    c038:	52800020 	mov	w0, #0x1                   	// #1
    c03c:	f90367e3 	str	x3, [sp, #1736]
    c040:	f9036be2 	str	x2, [sp, #1744]
    c044:	97ffe5ab 	bl	56f0 <fwp_data.part.0.constprop.0>
    c048:	91154283 	add	x3, x20, #0x550
    c04c:	aa0003f5 	mov	x21, x0
    c050:	f949d861 	ldr	x1, [x3, #5040]
    c054:	f949ec60 	ldr	x0, [x3, #5080]
    c058:	cb0102a1 	sub	x1, x21, x1
    c05c:	eb00403f 	cmp	x1, x0, lsl #16
    c060:	54000322 	b.cs	c0c4 <f0+0x1ca4>  // b.hs, b.nlast
    c064:	d350fc22 	lsr	x2, x1, #16
    c068:	f949fc63 	ldr	x3, [x3, #5112]
    c06c:	8b020842 	add	x2, x2, x2, lsl #2
    c070:	d37df042 	lsl	x2, x2, #3
    c074:	8b020060 	add	x0, x3, x2
    c078:	f9401017 	ldr	x23, [x0, #32]
    c07c:	b4000257 	cbz	x23, c0c4 <f0+0x1ca4>
    c080:	38626862 	ldrb	w2, [x3, x2]
    c084:	7100085f 	cmp	w2, #0x2
    c088:	54003940 	b.eq	c7b0 <f0+0x2390>  // b.none
    c08c:	7100045f 	cmp	w2, #0x1
    c090:	540001a1 	b.ne	c0c4 <f0+0x1ca4>  // b.any
    c094:	29430002 	ldp	w2, w0, [x0, #24]
    c098:	92403c21 	and	x1, x1, #0xffff
    c09c:	9b027c21 	mul	x1, x1, x2
    c0a0:	d360fc21 	lsr	x1, x1, #32
    c0a4:	eb00003f 	cmp	x1, x0
    c0a8:	540000e2 	b.cs	c0c4 <f0+0x1ca4>  // b.hs, b.nlast
    c0ac:	8b0102f7 	add	x23, x23, x1
    c0b0:	394002e0 	ldrb	w0, [x23]
    c0b4:	7103fc1f 	cmp	w0, #0xff
    c0b8:	54004d20 	b.eq	ca5c <f0+0x263c>  // b.none
    c0bc:	52800020 	mov	w0, #0x1                   	// #1
    c0c0:	390002e0 	strb	w0, [x23]
    c0c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c0c8:	911b63e1 	add	x1, sp, #0x6d8
    c0cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	f9036fe2 	str	x2, [sp, #1752]
    c0d8:	f90373f5 	str	x21, [sp, #1760]
    c0dc:	97ffe585 	bl	56f0 <fwp_data.part.0.constprop.0>
    c0e0:	91154283 	add	x3, x20, #0x550
    c0e4:	aa0003f5 	mov	x21, x0
    c0e8:	f949d861 	ldr	x1, [x3, #5040]
    c0ec:	f949ec60 	ldr	x0, [x3, #5080]
    c0f0:	cb0102a1 	sub	x1, x21, x1
    c0f4:	eb00403f 	cmp	x1, x0, lsl #16
    c0f8:	54000322 	b.cs	c15c <f0+0x1d3c>  // b.hs, b.nlast
    c0fc:	d350fc22 	lsr	x2, x1, #16
    c100:	f949fc63 	ldr	x3, [x3, #5112]
    c104:	8b020842 	add	x2, x2, x2, lsl #2
    c108:	d37df042 	lsl	x2, x2, #3
    c10c:	8b020060 	add	x0, x3, x2
    c110:	f9401017 	ldr	x23, [x0, #32]
    c114:	b4000257 	cbz	x23, c15c <f0+0x1d3c>
    c118:	38626862 	ldrb	w2, [x3, x2]
    c11c:	7100085f 	cmp	w2, #0x2
    c120:	540035a0 	b.eq	c7d4 <f0+0x23b4>  // b.none
    c124:	7100045f 	cmp	w2, #0x1
    c128:	540001a1 	b.ne	c15c <f0+0x1d3c>  // b.any
    c12c:	29430002 	ldp	w2, w0, [x0, #24]
    c130:	92403c21 	and	x1, x1, #0xffff
    c134:	9b027c21 	mul	x1, x1, x2
    c138:	d360fc21 	lsr	x1, x1, #32
    c13c:	eb00003f 	cmp	x1, x0
    c140:	540000e2 	b.cs	c15c <f0+0x1d3c>  // b.hs, b.nlast
    c144:	8b0102f7 	add	x23, x23, x1
    c148:	394002e0 	ldrb	w0, [x23]
    c14c:	7103fc1f 	cmp	w0, #0xff
    c150:	540048c0 	b.eq	ca68 <f0+0x2648>  // b.none
    c154:	52800020 	mov	w0, #0x1                   	// #1
    c158:	390002e0 	strb	w0, [x23]
    c15c:	911ba3e1 	add	x1, sp, #0x6e8
    c160:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c164:	52800020 	mov	w0, #0x1                   	// #1
    c168:	f90377f7 	str	x23, [sp, #1768]
    c16c:	f9037bf5 	str	x21, [sp, #1776]
    c170:	97ffe560 	bl	56f0 <fwp_data.part.0.constprop.0>
    c174:	97ffe5cb 	bl	58a0 <fwp_rc_fresh>
    c178:	aa0003e2 	mov	x2, x0
    c17c:	911be3e1 	add	x1, sp, #0x6f8
    c180:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c184:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	f9037ff5 	str	x21, [sp, #1784]
    c190:	f90383e2 	str	x2, [sp, #1792]
    c194:	97ffe557 	bl	56f0 <fwp_data.part.0.constprop.0>
    c198:	97ffe5c2 	bl	58a0 <fwp_rc_fresh>
    c19c:	aa0003e2 	mov	x2, x0
    c1a0:	911c23e1 	add	x1, sp, #0x708
    c1a4:	52800020 	mov	w0, #0x1                   	// #1
    c1a8:	f90387f7 	str	x23, [sp, #1800]
    c1ac:	f9038be2 	str	x2, [sp, #1808]
    c1b0:	97ffe550 	bl	56f0 <fwp_data.part.0.constprop.0>
    c1b4:	97ffe5bb 	bl	58a0 <fwp_rc_fresh>
    c1b8:	aa0003e2 	mov	x2, x0
    c1bc:	911c63e1 	add	x1, sp, #0x718
    c1c0:	52800020 	mov	w0, #0x1                   	// #1
    c1c4:	f9038ff5 	str	x21, [sp, #1816]
    c1c8:	f90393e2 	str	x2, [sp, #1824]
    c1cc:	97ffe549 	bl	56f0 <fwp_data.part.0.constprop.0>
    c1d0:	97ffe5b4 	bl	58a0 <fwp_rc_fresh>
    c1d4:	aa0003e2 	mov	x2, x0
    c1d8:	911ca3e1 	add	x1, sp, #0x728
    c1dc:	52800020 	mov	w0, #0x1                   	// #1
    c1e0:	f90397f7 	str	x23, [sp, #1832]
    c1e4:	f9039be2 	str	x2, [sp, #1840]
    c1e8:	97ffe542 	bl	56f0 <fwp_data.part.0.constprop.0>
    c1ec:	91154283 	add	x3, x20, #0x550
    c1f0:	aa0003f5 	mov	x21, x0
    c1f4:	f949d861 	ldr	x1, [x3, #5040]
    c1f8:	f949ec60 	ldr	x0, [x3, #5080]
    c1fc:	cb0102a1 	sub	x1, x21, x1
    c200:	eb00403f 	cmp	x1, x0, lsl #16
    c204:	54000322 	b.cs	c268 <f0+0x1e48>  // b.hs, b.nlast
    c208:	d350fc22 	lsr	x2, x1, #16
    c20c:	f949fc63 	ldr	x3, [x3, #5112]
    c210:	8b020842 	add	x2, x2, x2, lsl #2
    c214:	d37df042 	lsl	x2, x2, #3
    c218:	8b020060 	add	x0, x3, x2
    c21c:	f9401017 	ldr	x23, [x0, #32]
    c220:	b4000257 	cbz	x23, c268 <f0+0x1e48>
    c224:	38626862 	ldrb	w2, [x3, x2]
    c228:	7100085f 	cmp	w2, #0x2
    c22c:	54002ce0 	b.eq	c7c8 <f0+0x23a8>  // b.none
    c230:	7100045f 	cmp	w2, #0x1
    c234:	540001a1 	b.ne	c268 <f0+0x1e48>  // b.any
    c238:	29430002 	ldp	w2, w0, [x0, #24]
    c23c:	92403c21 	and	x1, x1, #0xffff
    c240:	9b027c21 	mul	x1, x1, x2
    c244:	d360fc21 	lsr	x1, x1, #32
    c248:	eb00003f 	cmp	x1, x0
    c24c:	540000e2 	b.cs	c268 <f0+0x1e48>  // b.hs, b.nlast
    c250:	8b0102f7 	add	x23, x23, x1
    c254:	394002e0 	ldrb	w0, [x23]
    c258:	7103fc1f 	cmp	w0, #0xff
    c25c:	540040c0 	b.eq	ca74 <f0+0x2654>  // b.none
    c260:	52800020 	mov	w0, #0x1                   	// #1
    c264:	390002e0 	strb	w0, [x23]
    c268:	911ce3e1 	add	x1, sp, #0x738
    c26c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c270:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c274:	52800020 	mov	w0, #0x1                   	// #1
    c278:	f9039ff7 	str	x23, [sp, #1848]
    c27c:	f903a3f5 	str	x21, [sp, #1856]
    c280:	97ffe51c 	bl	56f0 <fwp_data.part.0.constprop.0>
    c284:	97ffe587 	bl	58a0 <fwp_rc_fresh>
    c288:	aa0003e2 	mov	x2, x0
    c28c:	911d23e1 	add	x1, sp, #0x748
    c290:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c294:	52800020 	mov	w0, #0x1                   	// #1
    c298:	f903a7f5 	str	x21, [sp, #1864]
    c29c:	f903abe2 	str	x2, [sp, #1872]
    c2a0:	97ffe514 	bl	56f0 <fwp_data.part.0.constprop.0>
    c2a4:	97ffe57f 	bl	58a0 <fwp_rc_fresh>
    c2a8:	aa0003e2 	mov	x2, x0
    c2ac:	911d63e1 	add	x1, sp, #0x758
    c2b0:	52800020 	mov	w0, #0x1                   	// #1
    c2b4:	f903aff7 	str	x23, [sp, #1880]
    c2b8:	f903b3e2 	str	x2, [sp, #1888]
    c2bc:	97ffe50d 	bl	56f0 <fwp_data.part.0.constprop.0>
    c2c0:	97ffe578 	bl	58a0 <fwp_rc_fresh>
    c2c4:	aa0003e2 	mov	x2, x0
    c2c8:	911da3e1 	add	x1, sp, #0x768
    c2cc:	52800020 	mov	w0, #0x1                   	// #1
    c2d0:	f903b7f5 	str	x21, [sp, #1896]
    c2d4:	f903bbe2 	str	x2, [sp, #1904]
    c2d8:	97ffe506 	bl	56f0 <fwp_data.part.0.constprop.0>
    c2dc:	91154283 	add	x3, x20, #0x550
    c2e0:	aa0003f5 	mov	x21, x0
    c2e4:	f949d861 	ldr	x1, [x3, #5040]
    c2e8:	f949ec60 	ldr	x0, [x3, #5080]
    c2ec:	cb0102a1 	sub	x1, x21, x1
    c2f0:	eb00403f 	cmp	x1, x0, lsl #16
    c2f4:	54000322 	b.cs	c358 <f0+0x1f38>  // b.hs, b.nlast
    c2f8:	d350fc22 	lsr	x2, x1, #16
    c2fc:	f949fc63 	ldr	x3, [x3, #5112]
    c300:	8b020842 	add	x2, x2, x2, lsl #2
    c304:	d37df042 	lsl	x2, x2, #3
    c308:	8b020060 	add	x0, x3, x2
    c30c:	f9401017 	ldr	x23, [x0, #32]
    c310:	b4000257 	cbz	x23, c358 <f0+0x1f38>
    c314:	38626862 	ldrb	w2, [x3, x2]
    c318:	7100085f 	cmp	w2, #0x2
    c31c:	54002680 	b.eq	c7ec <f0+0x23cc>  // b.none
    c320:	7100045f 	cmp	w2, #0x1
    c324:	540001a1 	b.ne	c358 <f0+0x1f38>  // b.any
    c328:	29430002 	ldp	w2, w0, [x0, #24]
    c32c:	92403c21 	and	x1, x1, #0xffff
    c330:	9b027c21 	mul	x1, x1, x2
    c334:	d360fc21 	lsr	x1, x1, #32
    c338:	eb00003f 	cmp	x1, x0
    c33c:	540000e2 	b.cs	c358 <f0+0x1f38>  // b.hs, b.nlast
    c340:	8b0102f7 	add	x23, x23, x1
    c344:	394002e0 	ldrb	w0, [x23]
    c348:	7103fc1f 	cmp	w0, #0xff
    c34c:	540039a0 	b.eq	ca80 <f0+0x2660>  // b.none
    c350:	52800020 	mov	w0, #0x1                   	// #1
    c354:	390002e0 	strb	w0, [x23]
    c358:	911de3e1 	add	x1, sp, #0x778
    c35c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c360:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c364:	52800020 	mov	w0, #0x1                   	// #1
    c368:	f903bff7 	str	x23, [sp, #1912]
    c36c:	f903c3f5 	str	x21, [sp, #1920]
    c370:	97ffe4e0 	bl	56f0 <fwp_data.part.0.constprop.0>
    c374:	97ffe54b 	bl	58a0 <fwp_rc_fresh>
    c378:	aa0003e2 	mov	x2, x0
    c37c:	911e23e1 	add	x1, sp, #0x788
    c380:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c384:	52800020 	mov	w0, #0x1                   	// #1
    c388:	f903c7f5 	str	x21, [sp, #1928]
    c38c:	f903cbe2 	str	x2, [sp, #1936]
    c390:	97ffe4d8 	bl	56f0 <fwp_data.part.0.constprop.0>
    c394:	97ffe543 	bl	58a0 <fwp_rc_fresh>
    c398:	aa0003e2 	mov	x2, x0
    c39c:	911e63e1 	add	x1, sp, #0x798
    c3a0:	52800020 	mov	w0, #0x1                   	// #1
    c3a4:	f903cff7 	str	x23, [sp, #1944]
    c3a8:	f903d3e2 	str	x2, [sp, #1952]
    c3ac:	97ffe4d1 	bl	56f0 <fwp_data.part.0.constprop.0>
    c3b0:	97ffe53c 	bl	58a0 <fwp_rc_fresh>
    c3b4:	aa0003e2 	mov	x2, x0
    c3b8:	911ea3e1 	add	x1, sp, #0x7a8
    c3bc:	52800020 	mov	w0, #0x1                   	// #1
    c3c0:	f903d7f5 	str	x21, [sp, #1960]
    c3c4:	f903dbe2 	str	x2, [sp, #1968]
    c3c8:	97ffe4ca 	bl	56f0 <fwp_data.part.0.constprop.0>
    c3cc:	91154283 	add	x3, x20, #0x550
    c3d0:	aa0003f5 	mov	x21, x0
    c3d4:	f949d861 	ldr	x1, [x3, #5040]
    c3d8:	f949ec60 	ldr	x0, [x3, #5080]
    c3dc:	cb0102a1 	sub	x1, x21, x1
    c3e0:	eb00403f 	cmp	x1, x0, lsl #16
    c3e4:	54000322 	b.cs	c448 <f0+0x2028>  // b.hs, b.nlast
    c3e8:	d350fc22 	lsr	x2, x1, #16
    c3ec:	f949fc63 	ldr	x3, [x3, #5112]
    c3f0:	8b020842 	add	x2, x2, x2, lsl #2
    c3f4:	d37df042 	lsl	x2, x2, #3
    c3f8:	8b020060 	add	x0, x3, x2
    c3fc:	f9401017 	ldr	x23, [x0, #32]
    c400:	b4000257 	cbz	x23, c448 <f0+0x2028>
    c404:	38626862 	ldrb	w2, [x3, x2]
    c408:	7100085f 	cmp	w2, #0x2
    c40c:	54001ea0 	b.eq	c7e0 <f0+0x23c0>  // b.none
    c410:	7100045f 	cmp	w2, #0x1
    c414:	540001a1 	b.ne	c448 <f0+0x2028>  // b.any
    c418:	29430002 	ldp	w2, w0, [x0, #24]
    c41c:	92403c21 	and	x1, x1, #0xffff
    c420:	9b027c21 	mul	x1, x1, x2
    c424:	d360fc21 	lsr	x1, x1, #32
    c428:	eb00003f 	cmp	x1, x0
    c42c:	540000e2 	b.cs	c448 <f0+0x2028>  // b.hs, b.nlast
    c430:	8b0102f7 	add	x23, x23, x1
    c434:	394002e0 	ldrb	w0, [x23]
    c438:	7103fc1f 	cmp	w0, #0xff
    c43c:	54003280 	b.eq	ca8c <f0+0x266c>  // b.none
    c440:	52800020 	mov	w0, #0x1                   	// #1
    c444:	390002e0 	strb	w0, [x23]
    c448:	911ee3e1 	add	x1, sp, #0x7b8
    c44c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c450:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c454:	52800020 	mov	w0, #0x1                   	// #1
    c458:	f903dff7 	str	x23, [sp, #1976]
    c45c:	f903e3f5 	str	x21, [sp, #1984]
    c460:	97ffe4a4 	bl	56f0 <fwp_data.part.0.constprop.0>
    c464:	97ffe50f 	bl	58a0 <fwp_rc_fresh>
    c468:	aa0003e2 	mov	x2, x0
    c46c:	911f23e1 	add	x1, sp, #0x7c8
    c470:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c474:	52800020 	mov	w0, #0x1                   	// #1
    c478:	f903e7f5 	str	x21, [sp, #1992]
    c47c:	f903ebe2 	str	x2, [sp, #2000]
    c480:	97ffe49c 	bl	56f0 <fwp_data.part.0.constprop.0>
    c484:	97ffe507 	bl	58a0 <fwp_rc_fresh>
    c488:	aa0003e2 	mov	x2, x0
    c48c:	911f63e1 	add	x1, sp, #0x7d8
    c490:	52800020 	mov	w0, #0x1                   	// #1
    c494:	f903eff7 	str	x23, [sp, #2008]
    c498:	f903f3e2 	str	x2, [sp, #2016]
    c49c:	97ffe495 	bl	56f0 <fwp_data.part.0.constprop.0>
    c4a0:	97ffe500 	bl	58a0 <fwp_rc_fresh>
    c4a4:	aa0003e2 	mov	x2, x0
    c4a8:	911fa3e1 	add	x1, sp, #0x7e8
    c4ac:	52800020 	mov	w0, #0x1                   	// #1
    c4b0:	f903f7f5 	str	x21, [sp, #2024]
    c4b4:	f903fbe2 	str	x2, [sp, #2032]
    c4b8:	97ffe48e 	bl	56f0 <fwp_data.part.0.constprop.0>
    c4bc:	91154283 	add	x3, x20, #0x550
    c4c0:	aa0003f5 	mov	x21, x0
    c4c4:	f949d861 	ldr	x1, [x3, #5040]
    c4c8:	f949ec60 	ldr	x0, [x3, #5080]
    c4cc:	cb0102a1 	sub	x1, x21, x1
    c4d0:	eb00403f 	cmp	x1, x0, lsl #16
    c4d4:	54000322 	b.cs	c538 <f0+0x2118>  // b.hs, b.nlast
    c4d8:	d350fc22 	lsr	x2, x1, #16
    c4dc:	f949fc63 	ldr	x3, [x3, #5112]
    c4e0:	8b020842 	add	x2, x2, x2, lsl #2
    c4e4:	d37df042 	lsl	x2, x2, #3
    c4e8:	8b020060 	add	x0, x3, x2
    c4ec:	f9401017 	ldr	x23, [x0, #32]
    c4f0:	b4000257 	cbz	x23, c538 <f0+0x2118>
    c4f4:	38626862 	ldrb	w2, [x3, x2]
    c4f8:	7100085f 	cmp	w2, #0x2
    c4fc:	54001840 	b.eq	c804 <f0+0x23e4>  // b.none
    c500:	7100045f 	cmp	w2, #0x1
    c504:	540001a1 	b.ne	c538 <f0+0x2118>  // b.any
    c508:	29430002 	ldp	w2, w0, [x0, #24]
    c50c:	92403c21 	and	x1, x1, #0xffff
    c510:	9b027c21 	mul	x1, x1, x2
    c514:	d360fc21 	lsr	x1, x1, #32
    c518:	eb00003f 	cmp	x1, x0
    c51c:	540000e2 	b.cs	c538 <f0+0x2118>  // b.hs, b.nlast
    c520:	8b0102f7 	add	x23, x23, x1
    c524:	394002e0 	ldrb	w0, [x23]
    c528:	7103fc1f 	cmp	w0, #0xff
    c52c:	54002b60 	b.eq	ca98 <f0+0x2678>  // b.none
    c530:	52800020 	mov	w0, #0x1                   	// #1
    c534:	390002e0 	strb	w0, [x23]
    c538:	911fe3e1 	add	x1, sp, #0x7f8
    c53c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c540:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c544:	52800020 	mov	w0, #0x1                   	// #1
    c548:	f903fff7 	str	x23, [sp, #2040]
    c54c:	91154294 	add	x20, x20, #0x550
    c550:	f90403f5 	str	x21, [sp, #2048]
    c554:	97ffe467 	bl	56f0 <fwp_data.part.0.constprop.0>
    c558:	97ffe4d2 	bl	58a0 <fwp_rc_fresh>
    c55c:	aa0003e2 	mov	x2, x0
    c560:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c564:	912023e1 	add	x1, sp, #0x808
    c568:	52800020 	mov	w0, #0x1                   	// #1
    c56c:	f90407e3 	str	x3, [sp, #2056]
    c570:	f9040be2 	str	x2, [sp, #2064]
    c574:	97ffe45f 	bl	56f0 <fwp_data.part.0.constprop.0>
    c578:	97ffe4ca 	bl	58a0 <fwp_rc_fresh>
    c57c:	aa0003e2 	mov	x2, x0
    c580:	912063e1 	add	x1, sp, #0x818
    c584:	52800020 	mov	w0, #0x1                   	// #1
    c588:	f9040ff7 	str	x23, [sp, #2072]
    c58c:	f90413e2 	str	x2, [sp, #2080]
    c590:	97ffe458 	bl	56f0 <fwp_data.part.0.constprop.0>
    c594:	f949da81 	ldr	x1, [x20, #5040]
    c598:	aa0003f5 	mov	x21, x0
    c59c:	f949ee80 	ldr	x0, [x20, #5080]
    c5a0:	cb0102a1 	sub	x1, x21, x1
    c5a4:	eb00403f 	cmp	x1, x0, lsl #16
    c5a8:	54000322 	b.cs	c60c <f0+0x21ec>  // b.hs, b.nlast
    c5ac:	d350fc22 	lsr	x2, x1, #16
    c5b0:	f949fe83 	ldr	x3, [x20, #5112]
    c5b4:	8b020842 	add	x2, x2, x2, lsl #2
    c5b8:	d37df042 	lsl	x2, x2, #3
    c5bc:	8b020060 	add	x0, x3, x2
    c5c0:	f9401014 	ldr	x20, [x0, #32]
    c5c4:	b4000254 	cbz	x20, c60c <f0+0x21ec>
    c5c8:	38626862 	ldrb	w2, [x3, x2]
    c5cc:	7100085f 	cmp	w2, #0x2
    c5d0:	54001140 	b.eq	c7f8 <f0+0x23d8>  // b.none
    c5d4:	7100045f 	cmp	w2, #0x1
    c5d8:	540001a1 	b.ne	c60c <f0+0x21ec>  // b.any
    c5dc:	29430002 	ldp	w2, w0, [x0, #24]
    c5e0:	92403c21 	and	x1, x1, #0xffff
    c5e4:	9b027c21 	mul	x1, x1, x2
    c5e8:	d360fc21 	lsr	x1, x1, #32
    c5ec:	eb00003f 	cmp	x1, x0
    c5f0:	540000e2 	b.cs	c60c <f0+0x21ec>  // b.hs, b.nlast
    c5f4:	8b010294 	add	x20, x20, x1
    c5f8:	39400280 	ldrb	w0, [x20]
    c5fc:	7103fc1f 	cmp	w0, #0xff
    c600:	54001680 	b.eq	c8d0 <f0+0x24b0>  // b.none
    c604:	52800020 	mov	w0, #0x1                   	// #1
    c608:	39000280 	strb	w0, [x20]
    c60c:	9120a3e1 	add	x1, sp, #0x828
    c610:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c614:	52800020 	mov	w0, #0x1                   	// #1
    c618:	f90417f7 	str	x23, [sp, #2088]
    c61c:	f9041bf5 	str	x21, [sp, #2096]
    c620:	97ffe434 	bl	56f0 <fwp_data.part.0.constprop.0>
    c624:	97ffe49f 	bl	58a0 <fwp_rc_fresh>
    c628:	aa0003e2 	mov	x2, x0
    c62c:	9120e3e1 	add	x1, sp, #0x838
    c630:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c634:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c638:	52800020 	mov	w0, #0x1                   	// #1
    c63c:	f9041ff4 	str	x20, [sp, #2104]
    c640:	f90423e2 	str	x2, [sp, #2112]
    c644:	97ffe42b 	bl	56f0 <fwp_data.part.0.constprop.0>
    c648:	97ffe496 	bl	58a0 <fwp_rc_fresh>
    c64c:	aa0003e2 	mov	x2, x0
    c650:	912123e1 	add	x1, sp, #0x848
    c654:	52800020 	mov	w0, #0x1                   	// #1
    c658:	f90427f7 	str	x23, [sp, #2120]
    c65c:	f9042be2 	str	x2, [sp, #2128]
    c660:	97ffe424 	bl	56f0 <fwp_data.part.0.constprop.0>
    c664:	97ffe48f 	bl	58a0 <fwp_rc_fresh>
    c668:	aa0003e2 	mov	x2, x0
    c66c:	aa1603e1 	mov	x1, x22
    c670:	52800020 	mov	w0, #0x1                   	// #1
    c674:	f9042ff4 	str	x20, [sp, #2136]
    c678:	f90433e2 	str	x2, [sp, #2144]
    c67c:	97ffe41d 	bl	56f0 <fwp_data.part.0.constprop.0>
    c680:	97ffe488 	bl	58a0 <fwp_rc_fresh>
    c684:	aa0003f5 	mov	x21, x0
    c688:	aa1303e1 	mov	x1, x19
    c68c:	97fff3f5 	bl	9660 <fwp_hof0.constprop.0>
    c690:	aa0003f4 	mov	x20, x0
    c694:	aa1503e0 	mov	x0, x21
    c698:	97ffe5e2 	bl	5e20 <fwp_drop0>
    c69c:	aa1303e0 	mov	x0, x19
    c6a0:	97ffe5e0 	bl	5e20 <fwp_drop0>
    c6a4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c6a8:	f947f400 	ldr	x0, [x0, #4072]
    c6ac:	f94437e2 	ldr	x2, [sp, #2152]
    c6b0:	f9400001 	ldr	x1, [x0]
    c6b4:	eb010042 	subs	x2, x2, x1
    c6b8:	d2800001 	mov	x1, #0x0                   	// #0
    c6bc:	54001f41 	b.ne	caa4 <f0+0x2684>  // b.any
    c6c0:	9121c3ff 	add	sp, sp, #0x870
    c6c4:	aa1403e0 	mov	x0, x20
    c6c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    c6cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c6d0:	a94363f7 	ldp	x23, x24, [sp, #48]
    c6d4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c6d8:	a94573fb 	ldp	x27, x28, [sp, #80]
    c6dc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c6e0:	d65f03c0 	ret
    c6e4:	aa1c03e0 	mov	x0, x28
    c6e8:	97ffddea 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c6ec:	17fff797 	b	a548 <f0+0x128>
    c6f0:	72003c5f 	tst	w2, #0xffff
    c6f4:	54fef2c1 	b.ne	a54c <f0+0x12c>  // b.any
    c6f8:	17fff791 	b	a53c <f0+0x11c>
    c6fc:	72003c3f 	tst	w1, #0xffff
    c700:	54fefb41 	b.ne	a668 <f0+0x248>  // b.any
    c704:	17fff7d4 	b	a654 <f0+0x234>
    c708:	72003c3f 	tst	w1, #0xffff
    c70c:	54ff05e1 	b.ne	a7c8 <f0+0x3a8>  // b.any
    c710:	17fff829 	b	a7b4 <f0+0x394>
    c714:	72003c3f 	tst	w1, #0xffff
    c718:	54ff0001 	b.ne	a718 <f0+0x2f8>  // b.any
    c71c:	17fff7fa 	b	a704 <f0+0x2e4>
    c720:	72003c3f 	tst	w1, #0xffff
    c724:	54ff0e41 	b.ne	a8ec <f0+0x4cc>  // b.any
    c728:	17fff86c 	b	a8d8 <f0+0x4b8>
    c72c:	72003c3f 	tst	w1, #0xffff
    c730:	54ff0961 	b.ne	a85c <f0+0x43c>  // b.any
    c734:	17fff845 	b	a848 <f0+0x428>
    c738:	72003c3f 	tst	w1, #0xffff
    c73c:	54ff2241 	b.ne	ab84 <f0+0x764>  // b.any
    c740:	17fff90c 	b	ab70 <f0+0x750>
    c744:	72003c3f 	tst	w1, #0xffff
    c748:	54ff12a1 	b.ne	a99c <f0+0x57c>  // b.any
    c74c:	17fff88f 	b	a988 <f0+0x568>
    c750:	72003c3f 	tst	w1, #0xffff
    c754:	54ff9c61 	b.ne	bae0 <f0+0x16c0>  // b.any
    c758:	17fffcdd 	b	bacc <f0+0x16ac>
    c75c:	72003c3f 	tst	w1, #0xffff
    c760:	54ff9641 	b.ne	ba28 <f0+0x1608>  // b.any
    c764:	17fffcac 	b	ba14 <f0+0x15f4>
    c768:	72003c3f 	tst	w1, #0xffff
    c76c:	54ffa6e1 	b.ne	bc48 <f0+0x1828>  // b.any
    c770:	17fffd31 	b	bc34 <f0+0x1814>
    c774:	72003c3f 	tst	w1, #0xffff
    c778:	54ffa1e1 	b.ne	bbb4 <f0+0x1794>  // b.any
    c77c:	17fffd09 	b	bba0 <f0+0x1780>
    c780:	72003c3f 	tst	w1, #0xffff
    c784:	54ffb361 	b.ne	bdf0 <f0+0x19d0>  // b.any
    c788:	17fffd95 	b	bddc <f0+0x19bc>
    c78c:	72003c3f 	tst	w1, #0xffff
    c790:	54ffab81 	b.ne	bd00 <f0+0x18e0>  // b.any
    c794:	17fffd56 	b	bcec <f0+0x18cc>
    c798:	72003c3f 	tst	w1, #0xffff
    c79c:	54ffbc01 	b.ne	bf1c <f0+0x1afc>  // b.any
    c7a0:	17fffdda 	b	bf08 <f0+0x1ae8>
    c7a4:	72003c3f 	tst	w1, #0xffff
    c7a8:	54ffb701 	b.ne	be88 <f0+0x1a68>  // b.any
    c7ac:	17fffdb2 	b	be74 <f0+0x1a54>
    c7b0:	72003c3f 	tst	w1, #0xffff
    c7b4:	54ffc881 	b.ne	c0c4 <f0+0x1ca4>  // b.any
    c7b8:	17fffe3e 	b	c0b0 <f0+0x1c90>
    c7bc:	72003c3f 	tst	w1, #0xffff
    c7c0:	54ffc261 	b.ne	c00c <f0+0x1bec>  // b.any
    c7c4:	17fffe0d 	b	bff8 <f0+0x1bd8>
    c7c8:	72003c3f 	tst	w1, #0xffff
    c7cc:	54ffd4e1 	b.ne	c268 <f0+0x1e48>  // b.any
    c7d0:	17fffea1 	b	c254 <f0+0x1e34>
    c7d4:	72003c3f 	tst	w1, #0xffff
    c7d8:	54ffcc21 	b.ne	c15c <f0+0x1d3c>  // b.any
    c7dc:	17fffe5b 	b	c148 <f0+0x1d28>
    c7e0:	72003c3f 	tst	w1, #0xffff
    c7e4:	54ffe321 	b.ne	c448 <f0+0x2028>  // b.any
    c7e8:	17ffff13 	b	c434 <f0+0x2014>
    c7ec:	72003c3f 	tst	w1, #0xffff
    c7f0:	54ffdb41 	b.ne	c358 <f0+0x1f38>  // b.any
    c7f4:	17fffed4 	b	c344 <f0+0x1f24>
    c7f8:	72003c3f 	tst	w1, #0xffff
    c7fc:	54fff081 	b.ne	c60c <f0+0x21ec>  // b.any
    c800:	17ffff7e 	b	c5f8 <f0+0x21d8>
    c804:	72003c3f 	tst	w1, #0xffff
    c808:	54ffe981 	b.ne	c538 <f0+0x2118>  // b.any
    c80c:	17ffff46 	b	c524 <f0+0x2104>
    c810:	72003c3f 	tst	w1, #0xffff
    c814:	54ff2701 	b.ne	acf4 <f0+0x8d4>  // b.any
    c818:	17fff932 	b	ace0 <f0+0x8c0>
    c81c:	72003c3f 	tst	w1, #0xffff
    c820:	54ff20e1 	b.ne	ac3c <f0+0x81c>  // b.any
    c824:	17fff901 	b	ac28 <f0+0x808>
    c828:	72003c3f 	tst	w1, #0xffff
    c82c:	54ff4261 	b.ne	b078 <f0+0xc58>  // b.any
    c830:	17fffa0d 	b	b064 <f0+0xc44>
    c834:	72003c3f 	tst	w1, #0xffff
    c838:	54ff2ba1 	b.ne	adac <f0+0x98c>  // b.any
    c83c:	17fff957 	b	ad98 <f0+0x978>
    c840:	72003c3f 	tst	w1, #0xffff
    c844:	54ff4d21 	b.ne	b1e8 <f0+0xdc8>  // b.any
    c848:	17fffa63 	b	b1d4 <f0+0xdb4>
    c84c:	72003c3f 	tst	w1, #0xffff
    c850:	54ff4701 	b.ne	b130 <f0+0xd10>  // b.any
    c854:	17fffa32 	b	b11c <f0+0xcfc>
    c858:	72003c3f 	tst	w1, #0xffff
    c85c:	54ff5b21 	b.ne	b3c0 <f0+0xfa0>  // b.any
    c860:	17fffad3 	b	b3ac <f0+0xf8c>
    c864:	72003c3f 	tst	w1, #0xffff
    c868:	54ff5621 	b.ne	b32c <f0+0xf0c>  // b.any
    c86c:	17fffaab 	b	b318 <f0+0xef8>
    c870:	72003c3f 	tst	w1, #0xffff
    c874:	54ff65e1 	b.ne	b530 <f0+0x1110>  // b.any
    c878:	17fffb29 	b	b51c <f0+0x10fc>
    c87c:	72003c3f 	tst	w1, #0xffff
    c880:	54ff5fc1 	b.ne	b478 <f0+0x1058>  // b.any
    c884:	17fffaf8 	b	b464 <f0+0x1044>
    c888:	72003c3f 	tst	w1, #0xffff
    c88c:	54ff7061 	b.ne	b698 <f0+0x1278>  // b.any
    c890:	17fffb7d 	b	b684 <f0+0x1264>
    c894:	72003c3f 	tst	w1, #0xffff
    c898:	54ff6b61 	b.ne	b604 <f0+0x11e4>  // b.any
    c89c:	17fffb55 	b	b5f0 <f0+0x11d0>
    c8a0:	72003c3f 	tst	w1, #0xffff
    c8a4:	54ff7b21 	b.ne	b808 <f0+0x13e8>  // b.any
    c8a8:	17fffbd3 	b	b7f4 <f0+0x13d4>
    c8ac:	72003c3f 	tst	w1, #0xffff
    c8b0:	54ff7501 	b.ne	b750 <f0+0x1330>  // b.any
    c8b4:	17fffba2 	b	b73c <f0+0x131c>
    c8b8:	72003c3f 	tst	w1, #0xffff
    c8bc:	54ff85a1 	b.ne	b970 <f0+0x1550>  // b.any
    c8c0:	17fffc27 	b	b95c <f0+0x153c>
    c8c4:	72003c3f 	tst	w1, #0xffff
    c8c8:	54ff80a1 	b.ne	b8dc <f0+0x14bc>  // b.any
    c8cc:	17fffbff 	b	b8c8 <f0+0x14a8>
    c8d0:	aa1403e0 	mov	x0, x20
    c8d4:	97ffdd6f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c8d8:	17ffff4b 	b	c604 <f0+0x21e4>
    c8dc:	aa1703e0 	mov	x0, x23
    c8e0:	97ffdd6c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c8e4:	17fff75f 	b	a660 <f0+0x240>
    c8e8:	aa1703e0 	mov	x0, x23
    c8ec:	97ffdd69 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c8f0:	17fff788 	b	a710 <f0+0x2f0>
    c8f4:	aa1703e0 	mov	x0, x23
    c8f8:	97ffdd66 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c8fc:	17fff7b1 	b	a7c0 <f0+0x3a0>
    c900:	aa1703e0 	mov	x0, x23
    c904:	97ffdd63 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c908:	17fff7d3 	b	a854 <f0+0x434>
    c90c:	aa1703e0 	mov	x0, x23
    c910:	97ffdd60 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c914:	17fff7f4 	b	a8e4 <f0+0x4c4>
    c918:	aa1503e0 	mov	x0, x21
    c91c:	97ffdd5d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c920:	17fff81d 	b	a994 <f0+0x574>
    c924:	aa1703e0 	mov	x0, x23
    c928:	97ffdd5a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c92c:	17fff894 	b	ab7c <f0+0x75c>
    c930:	aa1703e0 	mov	x0, x23
    c934:	97ffdd57 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c938:	17fff8bf 	b	ac34 <f0+0x814>
    c93c:	aa1703e0 	mov	x0, x23
    c940:	97ffdd54 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c944:	17fff8ea 	b	acec <f0+0x8cc>
    c948:	aa1503e0 	mov	x0, x21
    c94c:	97ffdd51 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c950:	17fff915 	b	ada4 <f0+0x984>
    c954:	aa1703e0 	mov	x0, x23
    c958:	97ffdd4e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c95c:	17fff9c5 	b	b070 <f0+0xc50>
    c960:	aa1703e0 	mov	x0, x23
    c964:	97ffdd4b 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c968:	17fff9f0 	b	b128 <f0+0xd08>
    c96c:	aa1503e0 	mov	x0, x21
    c970:	97ffdd48 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c974:	17fffa1b 	b	b1e0 <f0+0xdc0>
    c978:	aa1703e0 	mov	x0, x23
    c97c:	97ffdd45 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c980:	17fffa69 	b	b324 <f0+0xf04>
    c984:	aa1703e0 	mov	x0, x23
    c988:	97ffdd42 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c98c:	17fffa8b 	b	b3b8 <f0+0xf98>
    c990:	aa1703e0 	mov	x0, x23
    c994:	97ffdd3f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c998:	17fffab6 	b	b470 <f0+0x1050>
    c99c:	aa1703e0 	mov	x0, x23
    c9a0:	97ffdd3c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9a4:	17fffae1 	b	b528 <f0+0x1108>
    c9a8:	aa1703e0 	mov	x0, x23
    c9ac:	97ffdd39 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9b0:	17fffb13 	b	b5fc <f0+0x11dc>
    c9b4:	aa1703e0 	mov	x0, x23
    c9b8:	97ffdd36 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9bc:	17fffb35 	b	b690 <f0+0x1270>
    c9c0:	aa1703e0 	mov	x0, x23
    c9c4:	97ffdd33 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9c8:	17fffb60 	b	b748 <f0+0x1328>
    c9cc:	aa1703e0 	mov	x0, x23
    c9d0:	97ffdd30 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9d4:	17fffb8b 	b	b800 <f0+0x13e0>
    c9d8:	aa1703e0 	mov	x0, x23
    c9dc:	97ffdd2d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9e0:	17fffbbd 	b	b8d4 <f0+0x14b4>
    c9e4:	aa1703e0 	mov	x0, x23
    c9e8:	97ffdd2a 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9ec:	17fffbdf 	b	b968 <f0+0x1548>
    c9f0:	aa1703e0 	mov	x0, x23
    c9f4:	97ffdd27 	bl	3e90 <fwp_rc_forget_slot.part.0>
    c9f8:	17fffc0a 	b	ba20 <f0+0x1600>
    c9fc:	aa1703e0 	mov	x0, x23
    ca00:	97ffdd24 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca04:	17fffc35 	b	bad8 <f0+0x16b8>
    ca08:	aa1703e0 	mov	x0, x23
    ca0c:	97ffdd21 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca10:	17fffc67 	b	bbac <f0+0x178c>
    ca14:	aa1703e0 	mov	x0, x23
    ca18:	97ffdd1e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca1c:	17fffc89 	b	bc40 <f0+0x1820>
    ca20:	aa1703e0 	mov	x0, x23
    ca24:	97ffdd1b 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca28:	17fffcb4 	b	bcf8 <f0+0x18d8>
    ca2c:	aa1703e0 	mov	x0, x23
    ca30:	97ffdd18 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca34:	17fffced 	b	bde8 <f0+0x19c8>
    ca38:	aa1703e0 	mov	x0, x23
    ca3c:	97ffdd15 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca40:	17fffd10 	b	be80 <f0+0x1a60>
    ca44:	aa1703e0 	mov	x0, x23
    ca48:	97ffdd12 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca4c:	17fffd32 	b	bf14 <f0+0x1af4>
    ca50:	aa1703e0 	mov	x0, x23
    ca54:	97ffdd0f 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca58:	17fffd6b 	b	c004 <f0+0x1be4>
    ca5c:	aa1703e0 	mov	x0, x23
    ca60:	97ffdd0c 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca64:	17fffd96 	b	c0bc <f0+0x1c9c>
    ca68:	aa1703e0 	mov	x0, x23
    ca6c:	97ffdd09 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca70:	17fffdb9 	b	c154 <f0+0x1d34>
    ca74:	aa1703e0 	mov	x0, x23
    ca78:	97ffdd06 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca7c:	17fffdf9 	b	c260 <f0+0x1e40>
    ca80:	aa1703e0 	mov	x0, x23
    ca84:	97ffdd03 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca88:	17fffe32 	b	c350 <f0+0x1f30>
    ca8c:	aa1703e0 	mov	x0, x23
    ca90:	97ffdd00 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ca94:	17fffe6b 	b	c440 <f0+0x2020>
    ca98:	aa1703e0 	mov	x0, x23
    ca9c:	97ffdcfd 	bl	3e90 <fwp_rc_forget_slot.part.0>
    caa0:	17fffea4 	b	c530 <f0+0x2110>
    caa4:	97ffd753 	bl	27f0 <__stack_chk_fail@plt>
    caa8:	97ffd766 	bl	2840 <abort@plt>
    caac:	d503201f 	nop

000000000000cab0 <fwp_main_thread>:
    cab0:	d10443ff 	sub	sp, sp, #0x110
    cab4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cab8:	f947f400 	ldr	x0, [x0, #4072]
    cabc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cac0:	910303fd 	add	x29, sp, #0xc0
    cac4:	a90d53f3 	stp	x19, x20, [sp, #208]
    cac8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc90>
    cacc:	91154261 	add	x1, x19, #0x550
    cad0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cad4:	b953a421 	ldr	w1, [x1, #5028]
    cad8:	f9400002 	ldr	x2, [x0]
    cadc:	f9005fe2 	str	x2, [sp, #184]
    cae0:	d2800002 	mov	x2, #0x0                   	// #0
    cae4:	34000e21 	cbz	w1, cca8 <fwp_main_thread+0x1f8>
    cae8:	91154273 	add	x19, x19, #0x550
    caec:	b953aa60 	ldr	w0, [x19, #5032]
    caf0:	35000d40 	cbnz	w0, cc98 <fwp_main_thread+0x1e8>
    caf4:	91001fe2 	add	x2, sp, #0x7
    caf8:	900000b4 	adrp	x20, 20000 <__data_start>
    cafc:	900000a3 	adrp	x3, 20000 <__data_start>
    cb00:	91010293 	add	x19, x20, #0x40
    cb04:	910dc063 	add	x3, x3, #0x370
    cb08:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cb0c:	d2a00025 	mov	x5, #0x10000               	// #65536
    cb10:	910023e0 	add	x0, sp, #0x8
    cb14:	d2800001 	mov	x1, #0x0                   	// #0
    cb18:	f90007e3 	str	x3, [sp, #8]
    cb1c:	b90013ff 	str	wzr, [sp, #16]
    cb20:	a9019262 	stp	x2, x4, [x19, #24]
    cb24:	f9000fe5 	str	x5, [sp, #24]
    cb28:	97ffd6ca 	bl	2650 <sigaltstack@plt>
    cb2c:	35000220 	cbnz	w0, cb70 <fwp_main_thread+0xc0>
    cb30:	4f000400 	movi	v0.4s, #0x0
    cb34:	9100a3e0 	add	x0, sp, #0x28
    cb38:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    cb3c:	52800082 	mov	w2, #0x4                   	// #4
    cb40:	913fc021 	add	x1, x1, #0xff0
    cb44:	72a10002 	movk	w2, #0x800, lsl #16
    cb48:	910083f5 	add	x21, sp, #0x20
    cb4c:	f90013e1 	str	x1, [sp, #32]
    cb50:	3d802000 	str	q0, [x0, #128]
    cb54:	b900abe2 	str	w2, [sp, #168]
    cb58:	ad000000 	stp	q0, q0, [x0]
    cb5c:	ad010000 	stp	q0, q0, [x0, #32]
    cb60:	ad020000 	stp	q0, q0, [x0, #64]
    cb64:	ad030000 	stp	q0, q0, [x0, #96]
    cb68:	97ffd712 	bl	27b0 <sigemptyset@plt>
    cb6c:	340000c0 	cbz	w0, cb84 <fwp_main_thread+0xd4>
    cb70:	b0000000 	adrp	x0, d000 <__divti3+0x40>
    cb74:	91326000 	add	x0, x0, #0xc98
    cb78:	a90f63f7 	stp	x23, x24, [sp, #240]
    cb7c:	f90083f9 	str	x25, [sp, #256]
    cb80:	97ffdca4 	bl	3e10 <fwp_trap>
    cb84:	aa1503e1 	mov	x1, x21
    cb88:	d2800002 	mov	x2, #0x0                   	// #0
    cb8c:	52800160 	mov	w0, #0xb                   	// #11
    cb90:	97ffd720 	bl	2810 <sigaction@plt>
    cb94:	35fffee0 	cbnz	w0, cb70 <fwp_main_thread+0xc0>
    cb98:	aa1503e1 	mov	x1, x21
    cb9c:	d2800002 	mov	x2, #0x0                   	// #0
    cba0:	528000e0 	mov	w0, #0x7                   	// #7
    cba4:	97ffd71b 	bl	2810 <sigaction@plt>
    cba8:	35fffe40 	cbnz	w0, cb70 <fwp_main_thread+0xc0>
    cbac:	b942fa60 	ldr	w0, [x19, #760]
    cbb0:	a90f63f7 	stp	x23, x24, [sp, #240]
    cbb4:	340019a0 	cbz	w0, cee8 <fwp_main_thread+0x438>
    cbb8:	91010296 	add	x22, x20, #0x40
    cbbc:	f9400ad5 	ldr	x21, [x22, #16]
    cbc0:	b40007d5 	cbz	x21, ccb8 <fwp_main_thread+0x208>
    cbc4:	910102b7 	add	x23, x21, #0x40
    cbc8:	f90083f9 	str	x25, [sp, #256]
    cbcc:	52800038 	mov	w24, #0x1                   	// #1
    cbd0:	39414ab9 	ldrb	w25, [x21, #82]
    cbd4:	39014ab8 	strb	w24, [x21, #82]
    cbd8:	f94016a0 	ldr	x0, [x21, #40]
    cbdc:	b40006a0 	cbz	x0, ccb0 <fwp_main_thread+0x200>
    cbe0:	f94032a1 	ldr	x1, [x21, #96]
    cbe4:	394146a0 	ldrb	w0, [x21, #81]
    cbe8:	b40019c1 	cbz	x1, cf20 <fwp_main_thread+0x470>
    cbec:	36001880 	tbz	w0, #0, cefc <fwp_main_thread+0x44c>
    cbf0:	f9400ad3 	ldr	x19, [x22, #16]
    cbf4:	f94022a0 	ldr	x0, [x21, #64]
    cbf8:	39414a61 	ldrb	w1, [x19, #82]
    cbfc:	37001be1 	tbnz	w1, #0, cf78 <fwp_main_thread+0x4c8>
    cc00:	f9403261 	ldr	x1, [x19, #96]
    cc04:	a911fe77 	stp	x23, xzr, [x19, #280]
    cc08:	f9009660 	str	x0, [x19, #296]
    cc0c:	b4000040 	cbz	x0, cc14 <fwp_main_thread+0x164>
    cc10:	f9009013 	str	x19, [x0, #288]
    cc14:	f90022b3 	str	x19, [x21, #64]
    cc18:	b4000101 	cbz	x1, cc38 <fwp_main_thread+0x188>
    cc1c:	f94046c0 	ldr	x0, [x22, #136]
    cc20:	39015678 	strb	w24, [x19, #85]
    cc24:	f9003661 	str	x1, [x19, #104]
    cc28:	a910827f 	stp	xzr, x0, [x19, #264]
    cc2c:	b4000040 	cbz	x0, cc34 <fwp_main_thread+0x184>
    cc30:	f9008413 	str	x19, [x0, #264]
    cc34:	f90046d3 	str	x19, [x22, #136]
    cc38:	39015a7f 	strb	wzr, [x19, #86]
    cc3c:	97ffe6cd 	bl	6770 <fwp_block>
    cc40:	f9408e62 	ldr	x2, [x19, #280]
    cc44:	b4000142 	cbz	x2, cc6c <fwp_main_thread+0x1bc>
    cc48:	a9520261 	ldp	x1, x0, [x19, #288]
    cc4c:	b4001a21 	cbz	x1, cf90 <fwp_main_thread+0x4e0>
    cc50:	f9009420 	str	x0, [x1, #296]
    cc54:	f9409660 	ldr	x0, [x19, #296]
    cc58:	b4000040 	cbz	x0, cc60 <fwp_main_thread+0x1b0>
    cc5c:	f9009001 	str	x1, [x0, #288]
    cc60:	91080260 	add	x0, x19, #0x200
    cc64:	f900967f 	str	xzr, [x19, #296]
    cc68:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cc6c:	39415660 	ldrb	w0, [x19, #85]
    cc70:	3607fb40 	tbz	w0, #0, cbd8 <fwp_main_thread+0x128>
    cc74:	a9508261 	ldp	x1, x0, [x19, #264]
    cc78:	b4001901 	cbz	x1, cf98 <fwp_main_thread+0x4e8>
    cc7c:	f9008820 	str	x0, [x1, #272]
    cc80:	b4000040 	cbz	x0, cc88 <fwp_main_thread+0x1d8>
    cc84:	f9008401 	str	x1, [x0, #264]
    cc88:	91080260 	add	x0, x19, #0x200
    cc8c:	3901567f 	strb	wzr, [x19, #85]
    cc90:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cc94:	17ffffd1 	b	cbd8 <fwp_main_thread+0x128>
    cc98:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    cc9c:	91241000 	add	x0, x0, #0x904
    cca0:	94000284 	bl	d6b0 <atexit>
    cca4:	17ffff94 	b	caf4 <fwp_main_thread+0x44>
    cca8:	97ffdb72 	bl	3a70 <fwp_heap_init>
    ccac:	17ffff8f 	b	cae8 <fwp_main_thread+0x38>
    ccb0:	39014ab9 	strb	w25, [x21, #82]
    ccb4:	f94083f9 	ldr	x25, [sp, #256]
    ccb8:	91010293 	add	x19, x20, #0x40
    ccbc:	f9416e60 	ldr	x0, [x19, #728]
    ccc0:	b5000180 	cbnz	x0, ccf0 <fwp_main_thread+0x240>
    ccc4:	f9417660 	ldr	x0, [x19, #744]
    ccc8:	b5000140 	cbnz	x0, ccf0 <fwp_main_thread+0x240>
    cccc:	f9416a60 	ldr	x0, [x19, #720]
    ccd0:	97ffdd0c 	bl	4100 <fwp_mem_free>
    ccd4:	f9016a7f 	str	xzr, [x19, #720]
    ccd8:	f9400a60 	ldr	x0, [x19, #16]
    ccdc:	f901727f 	str	xzr, [x19, #736]
    cce0:	b40000c0 	cbz	x0, ccf8 <fwp_main_thread+0x248>
    cce4:	f900541f 	str	xzr, [x0, #168]
    cce8:	f9005c1f 	str	xzr, [x0, #184]
    ccec:	14000003 	b	ccf8 <fwp_main_thread+0x248>
    ccf0:	91010280 	add	x0, x20, #0x40
    ccf4:	f9400800 	ldr	x0, [x0, #16]
    ccf8:	91010281 	add	x1, x20, #0x40
    ccfc:	f9418826 	ldr	x6, [x1, #784]
    cd00:	b903083f 	str	wzr, [x1, #776]
    cd04:	eb0000df 	cmp	x6, x0
    cd08:	54001561 	b.ne	cfb4 <fwp_main_thread+0x504>  // b.any
    cd0c:	b4000380 	cbz	x0, cd7c <fwp_main_thread+0x2cc>
    cd10:	f9415825 	ldr	x5, [x1, #688]
    cd14:	52800021 	mov	w1, #0x1                   	// #1
    cd18:	39014801 	strb	w1, [x0, #82]
    cd1c:	b4000305 	cbz	x5, cd7c <fwp_main_thread+0x2cc>
    cd20:	394140a0 	ldrb	w0, [x5, #80]
    cd24:	37000060 	tbnz	w0, #0, cd30 <fwp_main_thread+0x280>
    cd28:	aa0503e0 	mov	x0, x5
    cd2c:	97ffd9b1 	bl	33f0 <fwp_cancel_tree.part.0>
    cd30:	f9409ca5 	ldr	x5, [x5, #312]
    cd34:	b5ffff65 	cbnz	x5, cd20 <fwp_main_thread+0x270>
    cd38:	91010293 	add	x19, x20, #0x40
    cd3c:	52800035 	mov	w21, #0x1                   	// #1
    cd40:	f94028c0 	ldr	x0, [x6, #80]
    cd44:	f2001c1f 	tst	x0, #0xff000000ff
    cd48:	540000e1 	b.ne	cd64 <fwp_main_thread+0x2b4>  // b.any
    cd4c:	f9401660 	ldr	x0, [x19, #40]
    cd50:	390150d5 	strb	w21, [x6, #84]
    cd54:	f90080df 	str	xzr, [x6, #256]
    cd58:	b40010c0 	cbz	x0, cf70 <fwp_main_thread+0x4c0>
    cd5c:	f9008006 	str	x6, [x0, #256]
    cd60:	f9001666 	str	x6, [x19, #40]
    cd64:	97ffe683 	bl	6770 <fwp_block>
    cd68:	97ffe60a 	bl	6590 <fwp_free_zombie>
    cd6c:	f9415a60 	ldr	x0, [x19, #688]
    cd70:	b4000060 	cbz	x0, cd7c <fwp_main_thread+0x2cc>
    cd74:	f9418a66 	ldr	x6, [x19, #784]
    cd78:	17fffff2 	b	cd40 <fwp_main_thread+0x290>
    cd7c:	91010295 	add	x21, x20, #0x40
    cd80:	97ffe604 	bl	6590 <fwp_free_zombie>
    cd84:	f9401aa0 	ldr	x0, [x21, #48]
    cd88:	b5001160 	cbnz	x0, cfb4 <fwp_main_thread+0x504>
    cd8c:	f94046a0 	ldr	x0, [x21, #136]
    cd90:	b5001120 	cbnz	x0, cfb4 <fwp_main_thread+0x504>
    cd94:	b940aab3 	ldr	w19, [x21, #168]
    cd98:	340001f3 	cbz	w19, cdd4 <fwp_main_thread+0x324>
    cd9c:	93407e76 	sxtw	x22, w19
    cda0:	51000673 	sub	w19, w19, #0x1
    cda4:	d1000ad6 	sub	x22, x22, #0x2
    cda8:	9102c2b7 	add	x23, x21, #0xb0
    cdac:	cb3342d6 	sub	x22, x22, w19, uxtw
    cdb0:	93407e73 	sxtw	x19, w19
    cdb4:	d503201f 	nop
    cdb8:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cdbc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cdc0:	b900aab3 	str	w19, [x21, #168]
    cdc4:	d1000673 	sub	x19, x19, #0x1
    cdc8:	97ffd6d2 	bl	2910 <munmap@plt>
    cdcc:	eb1302df 	cmp	x22, x19
    cdd0:	54ffff41 	b.ne	cdb8 <fwp_main_thread+0x308>  // b.any
    cdd4:	900000b3 	adrp	x19, 20000 <__data_start>
    cdd8:	91004260 	add	x0, x19, #0x10
    cddc:	b9401000 	ldr	w0, [x0, #16]
    cde0:	36f80800 	tbz	w0, #31, cee0 <fwp_main_thread+0x430>
    cde4:	91010295 	add	x21, x20, #0x40
    cde8:	91004273 	add	x19, x19, #0x10
    cdec:	12800001 	mov	w1, #0xffffffff            	// #-1
    cdf0:	f94192a0 	ldr	x0, [x21, #800]
    cdf4:	b9001261 	str	w1, [x19, #16]
    cdf8:	f9418ea1 	ldr	x1, [x21, #792]
    cdfc:	b40001e0 	cbz	x0, ce38 <fwp_main_thread+0x388>
    ce00:	d2800013 	mov	x19, #0x0                   	// #0
    ce04:	d503201f 	nop
    ce08:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    ce0c:	b40000e0 	cbz	x0, ce28 <fwp_main_thread+0x378>
    ce10:	f9400001 	ldr	x1, [x0]
    ce14:	b5000d01 	cbnz	x1, cfb4 <fwp_main_thread+0x504>
    ce18:	f9400401 	ldr	x1, [x0, #8]
    ce1c:	b5000cc1 	cbnz	x1, cfb4 <fwp_main_thread+0x504>
    ce20:	97ffdcb8 	bl	4100 <fwp_mem_free>
    ce24:	f9418ea1 	ldr	x1, [x21, #792]
    ce28:	91000673 	add	x19, x19, #0x1
    ce2c:	f94192a0 	ldr	x0, [x21, #800]
    ce30:	eb00027f 	cmp	x19, x0
    ce34:	54fffea3 	b.cc	ce08 <fwp_main_thread+0x358>  // b.lo, b.ul, b.last
    ce38:	aa0103e0 	mov	x0, x1
    ce3c:	97ffdcb1 	bl	4100 <fwp_mem_free>
    ce40:	91010280 	add	x0, x20, #0x40
    ce44:	f9418813 	ldr	x19, [x0, #784]
    ce48:	f9018c1f 	str	xzr, [x0, #792]
    ce4c:	f901901f 	str	xzr, [x0, #800]
    ce50:	b40001f3 	cbz	x19, ce8c <fwp_main_thread+0x3dc>
    ce54:	f9401661 	ldr	x1, [x19, #40]
    ce58:	b5000ae1 	cbnz	x1, cfb4 <fwp_main_thread+0x504>
    ce5c:	f9405661 	ldr	x1, [x19, #168]
    ce60:	b5000aa1 	cbnz	x1, cfb4 <fwp_main_thread+0x504>
    ce64:	f9416c01 	ldr	x1, [x0, #728]
    ce68:	b5000a61 	cbnz	x1, cfb4 <fwp_main_thread+0x504>
    ce6c:	f9417400 	ldr	x0, [x0, #744]
    ce70:	b5000a20 	cbnz	x0, cfb4 <fwp_main_thread+0x504>
    ce74:	d2823a02 	mov	x2, #0x11d0                	// #4560
    ce78:	90000120 	adrp	x0, 30000 <alt.5+0xfc90>
    ce7c:	910dc000 	add	x0, x0, #0x370
    ce80:	97ffd650 	bl	27c0 <memset@plt>
    ce84:	aa1303e0 	mov	x0, x19
    ce88:	97ffdc9e 	bl	4100 <fwp_mem_free>
    ce8c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    ce90:	f947ec00 	ldr	x0, [x0, #4056]
    ce94:	91010294 	add	x20, x20, #0x40
    ce98:	f9400000 	ldr	x0, [x0]
    ce9c:	f9000a9f 	str	xzr, [x20, #16]
    cea0:	f9018a9f 	str	xzr, [x20, #784]
    cea4:	97ffd69f 	bl	2920 <fflush@plt>
    cea8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    ceac:	f947f400 	ldr	x0, [x0, #4072]
    ceb0:	f9405fe2 	ldr	x2, [sp, #184]
    ceb4:	f9400001 	ldr	x1, [x0]
    ceb8:	eb010042 	subs	x2, x2, x1
    cebc:	d2800001 	mov	x1, #0x0                   	// #0
    cec0:	54000761 	b.ne	cfac <fwp_main_thread+0x4fc>  // b.any
    cec4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cec8:	d2800000 	mov	x0, #0x0                   	// #0
    cecc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    ced0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    ced4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    ced8:	910443ff 	add	sp, sp, #0x110
    cedc:	d65f03c0 	ret
    cee0:	97ffd648 	bl	2800 <close@plt>
    cee4:	17ffffc0 	b	cde4 <fwp_main_thread+0x334>
    cee8:	97fff54e 	bl	a420 <f0>
    ceec:	f9018260 	str	x0, [x19, #768]
    cef0:	52800021 	mov	w1, #0x1                   	// #1
    cef4:	b902fa61 	str	w1, [x19, #760]
    cef8:	17ffff30 	b	cbb8 <fwp_main_thread+0x108>
    cefc:	97ffdde5 	bl	4690 <fwp_now_ns>
    cf00:	f94032a1 	ldr	x1, [x21, #96]
    cf04:	eb01001f 	cmp	x0, x1
    cf08:	540000ab 	b.lt	cf1c <fwp_main_thread+0x46c>  // b.tstop
    cf0c:	394142a0 	ldrb	w0, [x21, #80]
    cf10:	37000060 	tbnz	w0, #0, cf1c <fwp_main_thread+0x46c>
    cf14:	aa1503e0 	mov	x0, x21
    cf18:	97ffd936 	bl	33f0 <fwp_cancel_tree.part.0>
    cf1c:	394146a0 	ldrb	w0, [x21, #81]
    cf20:	f9400ad3 	ldr	x19, [x22, #16]
    cf24:	39414a62 	ldrb	w2, [x19, #82]
    cf28:	3707e640 	tbnz	w0, #0, cbf0 <fwp_main_thread+0x140>
    cf2c:	f94032a1 	ldr	x1, [x21, #96]
    cf30:	370001c2 	tbnz	w2, #0, cf68 <fwp_main_thread+0x4b8>
    cf34:	f9403260 	ldr	x0, [x19, #96]
    cf38:	b4000180 	cbz	x0, cf68 <fwp_main_thread+0x4b8>
    cf3c:	b4000061 	cbz	x1, cf48 <fwp_main_thread+0x498>
    cf40:	eb01001f 	cmp	x0, x1
    cf44:	9a81d000 	csel	x0, x0, x1, le
    cf48:	f94022a1 	ldr	x1, [x21, #64]
    cf4c:	a911fe77 	stp	x23, xzr, [x19, #280]
    cf50:	f9009661 	str	x1, [x19, #296]
    cf54:	b4000261 	cbz	x1, cfa0 <fwp_main_thread+0x4f0>
    cf58:	f9009033 	str	x19, [x1, #288]
    cf5c:	aa0003e1 	mov	x1, x0
    cf60:	f90022b3 	str	x19, [x21, #64]
    cf64:	17ffff2e 	b	cc1c <fwp_main_thread+0x16c>
    cf68:	f94022a0 	ldr	x0, [x21, #64]
    cf6c:	17ffff26 	b	cc04 <fwp_main_thread+0x154>
    cf70:	f9001a66 	str	x6, [x19, #48]
    cf74:	17ffff7b 	b	cd60 <fwp_main_thread+0x2b0>
    cf78:	a911fe77 	stp	x23, xzr, [x19, #280]
    cf7c:	f9009660 	str	x0, [x19, #296]
    cf80:	b4000040 	cbz	x0, cf88 <fwp_main_thread+0x4d8>
    cf84:	f9009013 	str	x19, [x0, #288]
    cf88:	f90022b3 	str	x19, [x21, #64]
    cf8c:	17ffff2b 	b	cc38 <fwp_main_thread+0x188>
    cf90:	f9000040 	str	x0, [x2]
    cf94:	17ffff31 	b	cc58 <fwp_main_thread+0x1a8>
    cf98:	f90046c0 	str	x0, [x22, #136]
    cf9c:	17ffff39 	b	cc80 <fwp_main_thread+0x1d0>
    cfa0:	aa0003e1 	mov	x1, x0
    cfa4:	f90022b3 	str	x19, [x21, #64]
    cfa8:	17ffff1d 	b	cc1c <fwp_main_thread+0x16c>
    cfac:	f90083f9 	str	x25, [sp, #256]
    cfb0:	97ffd610 	bl	27f0 <__stack_chk_fail@plt>
    cfb4:	f90083f9 	str	x25, [sp, #256]
    cfb8:	97ffd622 	bl	2840 <abort@plt>
    cfbc:	d503201f 	nop

000000000000cfc0 <__divti3>:
    cfc0:	d503245f 	bti	c
    cfc4:	d2800004 	mov	x4, #0x0                   	// #0
    cfc8:	b7f80721 	tbnz	x1, #63, d0ac <__divti3+0xec>
    cfcc:	b6f80083 	tbz	x3, #63, cfdc <__divti3+0x1c>
    cfd0:	eb0203e2 	negs	x2, x2
    cfd4:	aa2403e4 	mvn	x4, x4
    cfd8:	da0303e3 	ngc	x3, x3
    cfdc:	aa0203e6 	mov	x6, x2
    cfe0:	aa0003e7 	mov	x7, x0
    cfe4:	aa0103e5 	mov	x5, x1
    cfe8:	b5000583 	cbnz	x3, d098 <__divti3+0xd8>
    cfec:	eb01005f 	cmp	x2, x1
    cff0:	54000e69 	b.ls	d1bc <__divti3+0x1fc>  // b.plast
    cff4:	dac01040 	clz	x0, x2
    cff8:	b40000e0 	cbz	x0, d014 <__divti3+0x54>
    cffc:	4b0003e1 	neg	w1, w0
    d000:	9ac020a5 	lsl	x5, x5, x0
    d004:	9ac02046 	lsl	x6, x2, x0
    d008:	9ac124e1 	lsr	x1, x7, x1
    d00c:	aa050025 	orr	x5, x1, x5
    d010:	9ac020e7 	lsl	x7, x7, x0
    d014:	d360fcc8 	lsr	x8, x6, #32
    d018:	92407cc2 	and	x2, x6, #0xffffffff
    d01c:	9ac808a3 	udiv	x3, x5, x8
    d020:	9b089465 	msub	x5, x3, x8, x5
    d024:	aa0303e0 	mov	x0, x3
    d028:	9b037c41 	mul	x1, x2, x3
    d02c:	93c780a5 	extr	x5, x5, x7, #32
    d030:	eb05003f 	cmp	x1, x5
    d034:	540000a9 	b.ls	d048 <__divti3+0x88>  // b.plast
    d038:	ab0500c5 	adds	x5, x6, x5
    d03c:	d1000460 	sub	x0, x3, #0x1
    d040:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d044:	540015a8 	b.hi	d2f8 <__divti3+0x338>  // b.pmore
    d048:	cb0100a5 	sub	x5, x5, x1
    d04c:	9ac808a3 	udiv	x3, x5, x8
    d050:	9b089465 	msub	x5, x3, x8, x5
    d054:	aa0303e1 	mov	x1, x3
    d058:	9b037c42 	mul	x2, x2, x3
    d05c:	aa0703e3 	mov	x3, x7
    d060:	b3607ca3 	bfi	x3, x5, #32, #32
    d064:	eb03005f 	cmp	x2, x3
    d068:	540000c9 	b.ls	d080 <__divti3+0xc0>  // b.plast
    d06c:	ab0300c3 	adds	x3, x6, x3
    d070:	d1000425 	sub	x5, x1, #0x1
    d074:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d078:	d1000821 	sub	x1, x1, #0x2
    d07c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d080:	aa008020 	orr	x0, x1, x0, lsl #32
    d084:	d2800001 	mov	x1, #0x0                   	// #0
    d088:	b4000064 	cbz	x4, d094 <__divti3+0xd4>
    d08c:	eb0003e0 	negs	x0, x0
    d090:	da0103e1 	ngc	x1, x1
    d094:	d65f03c0 	ret
    d098:	eb01007f 	cmp	x3, x1
    d09c:	54000109 	b.ls	d0bc <__divti3+0xfc>  // b.plast
    d0a0:	d2800001 	mov	x1, #0x0                   	// #0
    d0a4:	d2800000 	mov	x0, #0x0                   	// #0
    d0a8:	17fffff8 	b	d088 <__divti3+0xc8>
    d0ac:	eb0003e0 	negs	x0, x0
    d0b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d0b4:	da0103e1 	ngc	x1, x1
    d0b8:	17ffffc5 	b	cfcc <__divti3+0xc>
    d0bc:	dac01067 	clz	x7, x3
    d0c0:	b40010e7 	cbz	x7, d2dc <__divti3+0x31c>
    d0c4:	d2800805 	mov	x5, #0x40                  	// #64
    d0c8:	cb0700a5 	sub	x5, x5, x7
    d0cc:	9ac72063 	lsl	x3, x3, x7
    d0d0:	9ac52448 	lsr	x8, x2, x5
    d0d4:	aa030108 	orr	x8, x8, x3
    d0d8:	9ac52426 	lsr	x6, x1, x5
    d0dc:	92407d0a 	and	x10, x8, #0xffffffff
    d0e0:	d360fd09 	lsr	x9, x8, #32
    d0e4:	9ac52403 	lsr	x3, x0, x5
    d0e8:	9ac72021 	lsl	x1, x1, x7
    d0ec:	aa010063 	orr	x3, x3, x1
    d0f0:	9ac72042 	lsl	x2, x2, x7
    d0f4:	9ac908cb 	udiv	x11, x6, x9
    d0f8:	9b099965 	msub	x5, x11, x9, x6
    d0fc:	aa0b03e1 	mov	x1, x11
    d100:	9b0b7d46 	mul	x6, x10, x11
    d104:	93c380a5 	extr	x5, x5, x3, #32
    d108:	eb0500df 	cmp	x6, x5
    d10c:	540000a9 	b.ls	d120 <__divti3+0x160>  // b.plast
    d110:	ab050105 	adds	x5, x8, x5
    d114:	d1000561 	sub	x1, x11, #0x1
    d118:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d11c:	54000f48 	b.hi	d304 <__divti3+0x344>  // b.pmore
    d120:	cb0600a6 	sub	x6, x5, x6
    d124:	9ac908cb 	udiv	x11, x6, x9
    d128:	9b099969 	msub	x9, x11, x9, x6
    d12c:	aa0b03e5 	mov	x5, x11
    d130:	9b0b7d4a 	mul	x10, x10, x11
    d134:	b3607d23 	bfi	x3, x9, #32, #32
    d138:	eb03015f 	cmp	x10, x3
    d13c:	540000a9 	b.ls	d150 <__divti3+0x190>  // b.plast
    d140:	ab030103 	adds	x3, x8, x3
    d144:	d1000565 	sub	x5, x11, #0x1
    d148:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d14c:	54000e28 	b.hi	d310 <__divti3+0x350>  // b.pmore
    d150:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d154:	92407c48 	and	x8, x2, #0xffffffff
    d158:	2a0503e5 	mov	w5, w5
    d15c:	d360fc42 	lsr	x2, x2, #32
    d160:	d360fc26 	lsr	x6, x1, #32
    d164:	cb0a0063 	sub	x3, x3, x10
    d168:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d16c:	9b087caa 	mul	x10, x5, x8
    d170:	9b087cc8 	mul	x8, x6, x8
    d174:	9b0220a5 	madd	x5, x5, x2, x8
    d178:	9b027cc6 	mul	x6, x6, x2
    d17c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d180:	8b0900c5 	add	x5, x6, x9
    d184:	eb02011f 	cmp	x8, x2
    d188:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d18c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d190:	eb06007f 	cmp	x3, x6
    d194:	540000e3 	b.cc	d1b0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d198:	92407d4a 	and	x10, x10, #0xffffffff
    d19c:	9ac72000 	lsl	x0, x0, x7
    d1a0:	8b028142 	add	x2, x10, x2, lsl #32
    d1a4:	eb02001f 	cmp	x0, x2
    d1a8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d1ac:	54000a01 	b.ne	d2ec <__divti3+0x32c>  // b.any
    d1b0:	d1000420 	sub	x0, x1, #0x1
    d1b4:	d2800001 	mov	x1, #0x0                   	// #0
    d1b8:	17ffffb4 	b	d088 <__divti3+0xc8>
    d1bc:	b5000062 	cbnz	x2, d1c8 <__divti3+0x208>
    d1c0:	d2800022 	mov	x2, #0x1                   	// #1
    d1c4:	9ac30846 	udiv	x6, x2, x3
    d1c8:	dac010c8 	clz	x8, x6
    d1cc:	b5000408 	cbnz	x8, d24c <__divti3+0x28c>
    d1d0:	d360fcc9 	lsr	x9, x6, #32
    d1d4:	92407cc5 	and	x5, x6, #0xffffffff
    d1d8:	cb060023 	sub	x3, x1, x6
    d1dc:	d2800021 	mov	x1, #0x1                   	// #1
    d1e0:	9ac90868 	udiv	x8, x3, x9
    d1e4:	9b098d03 	msub	x3, x8, x9, x3
    d1e8:	aa0803e0 	mov	x0, x8
    d1ec:	9b057d02 	mul	x2, x8, x5
    d1f0:	93c78063 	extr	x3, x3, x7, #32
    d1f4:	eb03005f 	cmp	x2, x3
    d1f8:	540000a9 	b.ls	d20c <__divti3+0x24c>  // b.plast
    d1fc:	ab0300c3 	adds	x3, x6, x3
    d200:	d1000500 	sub	x0, x8, #0x1
    d204:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d208:	54000968 	b.hi	d334 <__divti3+0x374>  // b.pmore
    d20c:	cb020063 	sub	x3, x3, x2
    d210:	9ac90862 	udiv	x2, x3, x9
    d214:	aa0203e8 	mov	x8, x2
    d218:	9b098c42 	msub	x2, x2, x9, x3
    d21c:	aa0703e3 	mov	x3, x7
    d220:	9b057d05 	mul	x5, x8, x5
    d224:	b3607c43 	bfi	x3, x2, #32, #32
    d228:	eb0300bf 	cmp	x5, x3
    d22c:	540000c9 	b.ls	d244 <__divti3+0x284>  // b.plast
    d230:	ab0300c2 	adds	x2, x6, x3
    d234:	d1000503 	sub	x3, x8, #0x1
    d238:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d23c:	d1000908 	sub	x8, x8, #0x2
    d240:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d244:	aa008100 	orr	x0, x8, x0, lsl #32
    d248:	17ffff90 	b	d088 <__divti3+0xc8>
    d24c:	9ac820c6 	lsl	x6, x6, x8
    d250:	d2800803 	mov	x3, #0x40                  	// #64
    d254:	cb080063 	sub	x3, x3, x8
    d258:	d360fcc9 	lsr	x9, x6, #32
    d25c:	9ac82027 	lsl	x7, x1, x8
    d260:	92407cc5 	and	x5, x6, #0xffffffff
    d264:	9ac32422 	lsr	x2, x1, x3
    d268:	9ac32403 	lsr	x3, x0, x3
    d26c:	aa070063 	orr	x3, x3, x7
    d270:	9ac9084a 	udiv	x10, x2, x9
    d274:	9ac82007 	lsl	x7, x0, x8
    d278:	9b098940 	msub	x0, x10, x9, x2
    d27c:	aa0a03e1 	mov	x1, x10
    d280:	9b0a7ca2 	mul	x2, x5, x10
    d284:	93c38000 	extr	x0, x0, x3, #32
    d288:	eb00005f 	cmp	x2, x0
    d28c:	540000a9 	b.ls	d2a0 <__divti3+0x2e0>  // b.plast
    d290:	ab0000c0 	adds	x0, x6, x0
    d294:	d1000541 	sub	x1, x10, #0x1
    d298:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d29c:	54000468 	b.hi	d328 <__divti3+0x368>  // b.pmore
    d2a0:	cb020000 	sub	x0, x0, x2
    d2a4:	9ac9080a 	udiv	x10, x0, x9
    d2a8:	9b098140 	msub	x0, x10, x9, x0
    d2ac:	aa0a03e2 	mov	x2, x10
    d2b0:	9b0a7ca8 	mul	x8, x5, x10
    d2b4:	b3607c03 	bfi	x3, x0, #32, #32
    d2b8:	eb03011f 	cmp	x8, x3
    d2bc:	540000a9 	b.ls	d2d0 <__divti3+0x310>  // b.plast
    d2c0:	ab0300c3 	adds	x3, x6, x3
    d2c4:	d1000542 	sub	x2, x10, #0x1
    d2c8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d2cc:	54000288 	b.hi	d31c <__divti3+0x35c>  // b.pmore
    d2d0:	cb080063 	sub	x3, x3, x8
    d2d4:	aa018041 	orr	x1, x2, x1, lsl #32
    d2d8:	17ffffc2 	b	d1e0 <__divti3+0x220>
    d2dc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d2e0:	d2800001 	mov	x1, #0x0                   	// #0
    d2e4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d2e8:	17ffff68 	b	d088 <__divti3+0xc8>
    d2ec:	aa0103e0 	mov	x0, x1
    d2f0:	d2800001 	mov	x1, #0x0                   	// #0
    d2f4:	17ffff65 	b	d088 <__divti3+0xc8>
    d2f8:	d1000860 	sub	x0, x3, #0x2
    d2fc:	8b0600a5 	add	x5, x5, x6
    d300:	17ffff52 	b	d048 <__divti3+0x88>
    d304:	d1000961 	sub	x1, x11, #0x2
    d308:	8b0800a5 	add	x5, x5, x8
    d30c:	17ffff85 	b	d120 <__divti3+0x160>
    d310:	d1000965 	sub	x5, x11, #0x2
    d314:	8b080063 	add	x3, x3, x8
    d318:	17ffff8e 	b	d150 <__divti3+0x190>
    d31c:	d1000942 	sub	x2, x10, #0x2
    d320:	8b060063 	add	x3, x3, x6
    d324:	17ffffeb 	b	d2d0 <__divti3+0x310>
    d328:	d1000941 	sub	x1, x10, #0x2
    d32c:	8b060000 	add	x0, x0, x6
    d330:	17ffffdc 	b	d2a0 <__divti3+0x2e0>
    d334:	d1000900 	sub	x0, x8, #0x2
    d338:	8b060063 	add	x3, x3, x6
    d33c:	17ffffb4 	b	d20c <__divti3+0x24c>

000000000000d340 <__modti3>:
    d340:	d503245f 	bti	c
    d344:	d2800004 	mov	x4, #0x0                   	// #0
    d348:	b6f80081 	tbz	x1, #63, d358 <__modti3+0x18>
    d34c:	eb0003e0 	negs	x0, x0
    d350:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d354:	da0103e1 	ngc	x1, x1
    d358:	f100007f 	cmp	x3, #0x0
    d35c:	5400128b 	b.lt	d5ac <__modti3+0x26c>  // b.tstop
    d360:	aa0003e7 	mov	x7, x0
    d364:	aa0103e6 	mov	x6, x1
    d368:	540004e1 	b.ne	d404 <__modti3+0xc4>  // b.any
    d36c:	eb02003f 	cmp	x1, x2
    d370:	54000dc2 	b.cs	d528 <__modti3+0x1e8>  // b.hs, b.nlast
    d374:	dac01043 	clz	x3, x2
    d378:	aa0303e5 	mov	x5, x3
    d37c:	b40000e3 	cbz	x3, d398 <__modti3+0x58>
    d380:	4b0303e6 	neg	w6, w3
    d384:	9ac32021 	lsl	x1, x1, x3
    d388:	9ac32042 	lsl	x2, x2, x3
    d38c:	9ac62406 	lsr	x6, x0, x6
    d390:	aa0100c6 	orr	x6, x6, x1
    d394:	9ac32007 	lsl	x7, x0, x3
    d398:	d360fc40 	lsr	x0, x2, #32
    d39c:	92407c43 	and	x3, x2, #0xffffffff
    d3a0:	9ac008c1 	udiv	x1, x6, x0
    d3a4:	9b009826 	msub	x6, x1, x0, x6
    d3a8:	9b017c61 	mul	x1, x3, x1
    d3ac:	93c780c6 	extr	x6, x6, x7, #32
    d3b0:	eb06003f 	cmp	x1, x6
    d3b4:	540000a9 	b.ls	d3c8 <__modti3+0x88>  // b.plast
    d3b8:	ab060046 	adds	x6, x2, x6
    d3bc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d3c0:	8b0200c8 	add	x8, x6, x2
    d3c4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d3c8:	cb0100c6 	sub	x6, x6, x1
    d3cc:	9ac008c8 	udiv	x8, x6, x0
    d3d0:	9b009901 	msub	x1, x8, x0, x6
    d3d4:	aa0703e0 	mov	x0, x7
    d3d8:	9b087c63 	mul	x3, x3, x8
    d3dc:	b3607c20 	bfi	x0, x1, #32, #32
    d3e0:	eb00007f 	cmp	x3, x0
    d3e4:	54001088 	b.hi	d5f4 <__modti3+0x2b4>  // b.pmore
    d3e8:	cb030000 	sub	x0, x0, x3
    d3ec:	9ac52400 	lsr	x0, x0, x5
    d3f0:	d2800001 	mov	x1, #0x0                   	// #0
    d3f4:	b4000064 	cbz	x4, d400 <__modti3+0xc0>
    d3f8:	eb0003e0 	negs	x0, x0
    d3fc:	da0103e1 	ngc	x1, x1
    d400:	d65f03c0 	ret
    d404:	dac01066 	clz	x6, x3
    d408:	eb03003f 	cmp	x1, x3
    d40c:	54ffff43 	b.cc	d3f4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d410:	93407cc5 	sxtw	x5, w6
    d414:	d2800808 	mov	x8, #0x40                  	// #64
    d418:	cb050108 	sub	x8, x8, x5
    d41c:	9ac62063 	lsl	x3, x3, x6
    d420:	9ac62025 	lsl	x5, x1, x6
    d424:	9ac82447 	lsr	x7, x2, x8
    d428:	aa0300e7 	orr	x7, x7, x3
    d42c:	9ac82423 	lsr	x3, x1, x8
    d430:	92407cec 	and	x12, x7, #0xffffffff
    d434:	d360fcea 	lsr	x10, x7, #32
    d438:	9ac82401 	lsr	x1, x0, x8
    d43c:	aa050021 	orr	x1, x1, x5
    d440:	9ac62042 	lsl	x2, x2, x6
    d444:	9ac62000 	lsl	x0, x0, x6
    d448:	9aca086b 	udiv	x11, x3, x10
    d44c:	9b0a8d63 	msub	x3, x11, x10, x3
    d450:	aa0b03e5 	mov	x5, x11
    d454:	9b0b7d89 	mul	x9, x12, x11
    d458:	93c18063 	extr	x3, x3, x1, #32
    d45c:	eb03013f 	cmp	x9, x3
    d460:	540000a9 	b.ls	d474 <__modti3+0x134>  // b.plast
    d464:	ab0300e3 	adds	x3, x7, x3
    d468:	d1000565 	sub	x5, x11, #0x1
    d46c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d470:	54001168 	b.hi	d69c <__modti3+0x35c>  // b.pmore
    d474:	cb090063 	sub	x3, x3, x9
    d478:	9aca086b 	udiv	x11, x3, x10
    d47c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d480:	aa0b03e9 	mov	x9, x11
    d484:	9b0b7d8c 	mul	x12, x12, x11
    d488:	b3607d41 	bfi	x1, x10, #32, #32
    d48c:	eb01019f 	cmp	x12, x1
    d490:	540000a9 	b.ls	d4a4 <__modti3+0x164>  // b.plast
    d494:	ab0100e1 	adds	x1, x7, x1
    d498:	d1000569 	sub	x9, x11, #0x1
    d49c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d4a0:	54000f88 	b.hi	d690 <__modti3+0x350>  // b.pmore
    d4a4:	aa058123 	orr	x3, x9, x5, lsl #32
    d4a8:	92407c4b 	and	x11, x2, #0xffffffff
    d4ac:	2a0903e9 	mov	w9, w9
    d4b0:	d360fc4a 	lsr	x10, x2, #32
    d4b4:	d360fc63 	lsr	x3, x3, #32
    d4b8:	cb0c0021 	sub	x1, x1, x12
    d4bc:	aa0a03ec 	mov	x12, x10
    d4c0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d4c4:	9b0b7d25 	mul	x5, x9, x11
    d4c8:	9b0b7c6b 	mul	x11, x3, x11
    d4cc:	9b0a2d29 	madd	x9, x9, x10, x11
    d4d0:	92407caa 	and	x10, x5, #0xffffffff
    d4d4:	9b0c7c63 	mul	x3, x3, x12
    d4d8:	8b458125 	add	x5, x9, x5, lsr #32
    d4dc:	8b0d0069 	add	x9, x3, x13
    d4e0:	eb05017f 	cmp	x11, x5
    d4e4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d4e8:	8b058149 	add	x9, x10, x5, lsl #32
    d4ec:	8b458063 	add	x3, x3, x5, lsr #32
    d4f0:	eb03003f 	cmp	x1, x3
    d4f4:	54000063 	b.cc	d500 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d4f8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d4fc:	54000082 	b.cs	d50c <__modti3+0x1cc>  // b.hs, b.nlast
    d500:	eb020129 	subs	x9, x9, x2
    d504:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d508:	cb070063 	sub	x3, x3, x7
    d50c:	eb090000 	subs	x0, x0, x9
    d510:	da030021 	sbc	x1, x1, x3
    d514:	9ac62400 	lsr	x0, x0, x6
    d518:	9ac82028 	lsl	x8, x1, x8
    d51c:	aa000100 	orr	x0, x8, x0
    d520:	9ac62421 	lsr	x1, x1, x6
    d524:	17ffffb4 	b	d3f4 <__modti3+0xb4>
    d528:	b5000062 	cbnz	x2, d534 <__modti3+0x1f4>
    d52c:	d2800023 	mov	x3, #0x1                   	// #1
    d530:	9ac20862 	udiv	x2, x3, x2
    d534:	dac01048 	clz	x8, x2
    d538:	aa0803e5 	mov	x5, x8
    d53c:	b5000668 	cbnz	x8, d608 <__modti3+0x2c8>
    d540:	cb020020 	sub	x0, x1, x2
    d544:	d360fc49 	lsr	x9, x2, #32
    d548:	92407c4a 	and	x10, x2, #0xffffffff
    d54c:	9ac90801 	udiv	x1, x0, x9
    d550:	9b098020 	msub	x0, x1, x9, x0
    d554:	9b0a7c21 	mul	x1, x1, x10
    d558:	93c78000 	extr	x0, x0, x7, #32
    d55c:	eb00003f 	cmp	x1, x0
    d560:	540000a9 	b.ls	d574 <__modti3+0x234>  // b.plast
    d564:	ab000040 	adds	x0, x2, x0
    d568:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d56c:	8b020003 	add	x3, x0, x2
    d570:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d574:	cb010001 	sub	x1, x0, x1
    d578:	9ac90820 	udiv	x0, x1, x9
    d57c:	9b098403 	msub	x3, x0, x9, x1
    d580:	aa0703e1 	mov	x1, x7
    d584:	9b0a7c00 	mul	x0, x0, x10
    d588:	b3607c61 	bfi	x1, x3, #32, #32
    d58c:	eb01001f 	cmp	x0, x1
    d590:	540000a9 	b.ls	d5a4 <__modti3+0x264>  // b.plast
    d594:	ab010041 	adds	x1, x2, x1
    d598:	8b020022 	add	x2, x1, x2
    d59c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d5a0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d5a4:	cb000020 	sub	x0, x1, x0
    d5a8:	17ffff91 	b	d3ec <__modti3+0xac>
    d5ac:	eb0203e5 	negs	x5, x2
    d5b0:	aa0003e7 	mov	x7, x0
    d5b4:	da0303e8 	ngc	x8, x3
    d5b8:	aa0503e2 	mov	x2, x5
    d5bc:	aa0803e3 	mov	x3, x8
    d5c0:	aa0103e6 	mov	x6, x1
    d5c4:	b4ffed48 	cbz	x8, d36c <__modti3+0x2c>
    d5c8:	eb01011f 	cmp	x8, x1
    d5cc:	54fff148 	b.hi	d3f4 <__modti3+0xb4>  // b.pmore
    d5d0:	dac01109 	clz	x9, x8
    d5d4:	2a0903e6 	mov	w6, w9
    d5d8:	b5fff1c9 	cbnz	x9, d410 <__modti3+0xd0>
    d5dc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d5e0:	54000068 	b.hi	d5ec <__modti3+0x2ac>  // b.pmore
    d5e4:	eb050007 	subs	x7, x0, x5
    d5e8:	da080021 	sbc	x1, x1, x8
    d5ec:	aa0703e0 	mov	x0, x7
    d5f0:	17ffff81 	b	d3f4 <__modti3+0xb4>
    d5f4:	ab000040 	adds	x0, x2, x0
    d5f8:	8b020002 	add	x2, x0, x2
    d5fc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d600:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d604:	17ffff79 	b	d3e8 <__modti3+0xa8>
    d608:	9ac82042 	lsl	x2, x2, x8
    d60c:	d2800803 	mov	x3, #0x40                  	// #64
    d610:	cb080063 	sub	x3, x3, x8
    d614:	d360fc49 	lsr	x9, x2, #32
    d618:	9ac82027 	lsl	x7, x1, x8
    d61c:	92407c4a 	and	x10, x2, #0xffffffff
    d620:	9ac32426 	lsr	x6, x1, x3
    d624:	9ac32403 	lsr	x3, x0, x3
    d628:	aa070063 	orr	x3, x3, x7
    d62c:	9ac908c1 	udiv	x1, x6, x9
    d630:	9ac82007 	lsl	x7, x0, x8
    d634:	9b099820 	msub	x0, x1, x9, x6
    d638:	9b017d41 	mul	x1, x10, x1
    d63c:	93c38000 	extr	x0, x0, x3, #32
    d640:	eb00003f 	cmp	x1, x0
    d644:	540000a9 	b.ls	d658 <__modti3+0x318>  // b.plast
    d648:	ab000040 	adds	x0, x2, x0
    d64c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d650:	8b020006 	add	x6, x0, x2
    d654:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d658:	cb010000 	sub	x0, x0, x1
    d65c:	9ac90801 	udiv	x1, x0, x9
    d660:	9b098026 	msub	x6, x1, x9, x0
    d664:	aa0303e0 	mov	x0, x3
    d668:	9b017d41 	mul	x1, x10, x1
    d66c:	b3607cc0 	bfi	x0, x6, #32, #32
    d670:	eb00003f 	cmp	x1, x0
    d674:	540000a9 	b.ls	d688 <__modti3+0x348>  // b.plast
    d678:	ab000040 	adds	x0, x2, x0
    d67c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d680:	8b020003 	add	x3, x0, x2
    d684:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d688:	cb010000 	sub	x0, x0, x1
    d68c:	17ffffb0 	b	d54c <__modti3+0x20c>
    d690:	d1000969 	sub	x9, x11, #0x2
    d694:	8b070021 	add	x1, x1, x7
    d698:	17ffff83 	b	d4a4 <__modti3+0x164>
    d69c:	d1000965 	sub	x5, x11, #0x2
    d6a0:	8b070063 	add	x3, x3, x7
    d6a4:	17ffff74 	b	d474 <__modti3+0x134>
    d6a8:	d503201f 	nop
    d6ac:	d503201f 	nop

000000000000d6b0 <atexit>:
    d6b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d6b4:	f0000082 	adrp	x2, 20000 <__data_start>
    d6b8:	d2800001 	mov	x1, #0x0                   	// #0
    d6bc:	910003fd 	mov	x29, sp
    d6c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d6c4:	f9400442 	ldr	x2, [x2, #8]
    d6c8:	17ffd40a 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d6cc <_fini>:
    d6cc:	d503201f 	nop
    d6d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d6d4:	910003fd 	mov	x29, sp
    d6d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d6dc:	d65f03c0 	ret
