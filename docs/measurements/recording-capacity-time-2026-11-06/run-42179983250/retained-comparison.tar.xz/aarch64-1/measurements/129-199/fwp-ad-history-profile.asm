
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b0000170 	adrp	x16, 2f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	90000065 	adrp	x5, e000 <_IO_stdin_used+0x70>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9111c0a5 	add	x5, x5, #0x470
    2a20:	90000064 	adrp	x4, e000 <_IO_stdin_used+0x70>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9111e084 	add	x4, x4, #0x478
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	94000619 	bl	42b4 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b0000174 	adrp	x20, 2f000 <fwp_fn_table+0xb30>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d0000175 	adrp	x21, 30000 <__data_start>
    2a8c:	910182a1 	add	x1, x21, #0x60
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	90000160 	adrp	x0, 2e000 <__FRAME_END__+0x1dba0>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9008c20 	str	x0, [x1, #280]
    2aac:	94000821 	bl	4b30 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2ab4:	9120e000 	add	x0, x0, #0x838
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000042 	adrp	x2, d000 <f0+0x2390>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	910b9042 	add	x2, x2, #0x2e4
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910182b5 	add	x21, x21, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943daa0 	ldr	w0, [x21, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2bcc:	9121a000 	add	x0, x0, #0x868
    2bd0:	940005b9 	bl	42b4 <fwp_trap>
    2bd4:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2bd8:	91212000 	add	x0, x0, #0x848
    2bdc:	940005b6 	bl	42b4 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff46 	bl	2900 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffeeb 	bl	27c0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2c20:	91230000 	add	x0, x0, #0x8c0
    2c24:	940005a4 	bl	42b4 <fwp_trap>
    2c28:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2c2c:	91224000 	add	x0, x0, #0x890
    2c30:	940005a1 	bl	42b4 <fwp_trap>
    2c34:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x70>
    2c38:	9123a000 	add	x0, x0, #0x8e8
    2c3c:	9400059e 	bl	42b4 <fwp_trap>
    2c40:	97fffef4 	bl	2810 <__stack_chk_fail@plt>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d0000160 	adrp	x0, 30000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d0000161 	adrp	x1, 30000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d0000160 	adrp	x0, 30000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d0000161 	adrp	x1, 30000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b0000162 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d0000173 	adrp	x19, 30000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b0000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d0000160 	adrp	x0, 30000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b0000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x70>
    2e34:	913c8021 	add	x1, x1, #0xf20
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d0000167 	adrp	x7, 30000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d0000164 	adrp	x4, 30000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d0000163 	adrp	x3, 30000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d0000160 	adrp	x0, 30000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b0000162 	adrp	x2, 30000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    30d8:	913c0021 	add	x1, x1, #0xf00
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <f0+0x2390>
    3110:	913e6000 	add	x0, x0, #0xf98
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000425 	adrp	x5, 8a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	90000164 	adrp	x4, 2f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <f0+0x2390>
    331c:	913ec042 	add	x2, x2, #0xfb0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b0000178 	adrp	x24, 30000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	90000176 	adrp	x22, 2f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x70>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	91002042 	add	x2, x2, #0x8
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	f0000059 	adrp	x25, e000 <_IO_stdin_used+0x70>
    33a8:	d000005a 	adrp	x26, d000 <f0+0x2390>
    33ac:	9101a339 	add	x25, x25, #0x68
    33b0:	913f435a 	add	x26, x26, #0xfd0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b0000160 	adrp	x0, 30000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <f0+0x2390>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	913f6377 	add	x23, x27, #0xfd8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	9102a000 	add	x0, x0, #0xa8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b00001e1 	adrp	x1, 40000 <alt.5+0xfba0>
    3474:	b00001e5 	adrp	x5, 40000 <alt.5+0xfba0>
    3478:	b00001e2 	adrp	x2, 40000 <alt.5+0xfba0>
    347c:	d0000043 	adrp	x3, d000 <f0+0x2390>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	f0000055 	adrp	x21, e000 <_IO_stdin_used+0x70>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	913f4063 	add	x3, x3, #0xfd0
    34a0:	910302b5 	add	x21, x21, #0xc0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91040000 	add	x0, x0, #0x100
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <f0+0x2390>
    352c:	913f8000 	add	x0, x0, #0xfe0
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	90000163 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <f0+0x2390>
    35ec:	913e6000 	add	x0, x0, #0xf98
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b0000161 	adrp	x1, 30000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    3730:	aa1303e0 	mov	x0, x19
    3734:	91042021 	add	x1, x1, #0x108
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    3744:	aa1303e0 	mov	x0, x19
    3748:	91044021 	add	x1, x1, #0x110
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    3760:	91046021 	add	x1, x1, #0x118
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_format_g.constprop.0>:
    3780:	d10483ff 	sub	sp, sp, #0x120
    3784:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x70>
    3788:	90000162 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    378c:	f947f442 	ldr	x2, [x2, #4072]
    3790:	91048084 	add	x4, x4, #0x120
    3794:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3798:	9102c3fd 	add	x29, sp, #0xb0
    379c:	d2800803 	mov	x3, #0x40                  	// #64
    37a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37a4:	93407c38 	sxtw	x24, w1
    37a8:	aa0303e1 	mov	x1, x3
    37ac:	fd008be8 	str	d8, [sp, #272]
    37b0:	1e604008 	fmov	d8, d0
    37b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37b8:	910083f4 	add	x20, sp, #0x20
    37bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    37c0:	aa0003f5 	mov	x21, x0
    37c4:	a91073fb 	stp	x27, x28, [sp, #256]
    37c8:	5100071c 	sub	w28, w24, #0x1
    37cc:	2a1c03e5 	mov	w5, w28
    37d0:	f9400040 	ldr	x0, [x2]
    37d4:	f90057e0 	str	x0, [sp, #168]
    37d8:	d2800000 	mov	x0, #0x0                   	// #0
    37dc:	52800042 	mov	w2, #0x2                   	// #2
    37e0:	aa1403e0 	mov	x0, x20
    37e4:	97fffbe7 	bl	2780 <__snprintf_chk@plt>
    37e8:	52800ca1 	mov	w1, #0x65                  	// #101
    37ec:	aa1403e0 	mov	x0, x20
    37f0:	97fffc40 	bl	28f0 <strchr@plt>
    37f4:	aa0003f3 	mov	x19, x0
    37f8:	52800142 	mov	w2, #0xa                   	// #10
    37fc:	91000400 	add	x0, x0, #0x1
    3800:	d2800001 	mov	x1, #0x0                   	// #0
    3804:	97fffc2b 	bl	28b0 <strtol@plt>
    3808:	aa0003f7 	mov	x23, x0
    380c:	11001400 	add	w0, w0, #0x5
    3810:	7100541f 	cmp	w0, #0x15
    3814:	54000d68 	b.hi	39c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3818:	4b170385 	sub	w5, w28, w23
    381c:	710000bf 	cmp	w5, #0x0
    3820:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3824:	54000b80 	b.eq	3994 <fwp_format_g.constprop.0+0x214>  // b.none
    3828:	394083e0 	ldrb	w0, [sp, #32]
    382c:	cb180273 	sub	x19, x19, x24
    3830:	91000673 	add	x19, x19, #0x1
    3834:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3838:	7100b41f 	cmp	w0, #0x2d
    383c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3840:	1a9f17e4 	cset	w4, eq	// eq = none
    3844:	cb010266 	sub	x6, x19, x1
    3848:	d10004da 	sub	x26, x6, #0x1
    384c:	540018a0 	b.eq	3b60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3850:	910183f9 	add	x25, sp, #0x60
    3854:	d280091b 	mov	x27, #0x48                  	// #72
    3858:	aa1903e7 	mov	x7, x25
    385c:	91000423 	add	x3, x1, #0x1
    3860:	91011cc6 	add	x6, x6, #0x47
    3864:	910004f6 	add	x22, x7, #0x1
    3868:	37f80ff7 	tbnz	w23, #31, 3a64 <fwp_format_g.constprop.0+0x2e4>
    386c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3870:	93407ef7 	sxtw	x23, w23
    3874:	390000e4 	strb	w4, [x7]
    3878:	aa1303e1 	mov	x1, x19
    387c:	aa1703e2 	mov	x2, x23
    3880:	aa1603e0 	mov	x0, x22
    3884:	b9000be5 	str	w5, [sp, #8]
    3888:	cb170374 	sub	x20, x27, x23
    388c:	a9011be3 	stp	x3, x6, [sp, #16]
    3890:	97fffb74 	bl	2660 <memcpy@plt>
    3894:	d1000694 	sub	x20, x20, #0x1
    3898:	f9400be3 	ldr	x3, [sp, #16]
    389c:	8b1702d6 	add	x22, x22, x23
    38a0:	aa1603e0 	mov	x0, x22
    38a4:	aa1a03e2 	mov	x2, x26
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	aa1403e3 	mov	x3, x20
    38b0:	97fffbac 	bl	2760 <__memcpy_chk@plt>
    38b4:	8b1a02d6 	add	x22, x22, x26
    38b8:	f9400fe6 	ldr	x6, [sp, #24]
    38bc:	d2800900 	mov	x0, #0x48                  	// #72
    38c0:	b9400be5 	ldr	w5, [sp, #8]
    38c4:	8b170261 	add	x1, x19, x23
    38c8:	cb1400c3 	sub	x3, x6, x20
    38cc:	cb060294 	sub	x20, x20, x6
    38d0:	f101207f 	cmp	x3, #0x48
    38d4:	93407cb8 	sxtw	x24, w5
    38d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38dc:	aa1803e2 	mov	x2, x24
    38e0:	8b1802d3 	add	x19, x22, x24
    38e4:	8b140063 	add	x3, x3, x20
    38e8:	aa1603e0 	mov	x0, x22
    38ec:	97fffb9d 	bl	2760 <__memcpy_chk@plt>
    38f0:	cb190273 	sub	x19, x19, x25
    38f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    38f8:	eb00027f 	cmp	x19, x0
    38fc:	aa1903e1 	mov	x1, x25
    3900:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3904:	aa1503e0 	mov	x0, x21
    3908:	aa1303e2 	mov	x2, x19
    390c:	97fffb55 	bl	2660 <memcpy@plt>
    3910:	38336abf 	strb	wzr, [x21, x19]
    3914:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3918:	aa1503e0 	mov	x0, x21
    391c:	97fffb61 	bl	26a0 <strlen@plt>
    3920:	aa0003f3 	mov	x19, x0
    3924:	528005c1 	mov	w1, #0x2e                  	// #46
    3928:	aa1503e0 	mov	x0, x21
    392c:	97fffbf1 	bl	28f0 <strchr@plt>
    3930:	b4000140 	cbz	x0, 3958 <fwp_format_g.constprop.0+0x1d8>
    3934:	b4000133 	cbz	x19, 3958 <fwp_format_g.constprop.0+0x1d8>
    3938:	aa1303e1 	mov	x1, x19
    393c:	d1000673 	sub	x19, x19, #0x1
    3940:	38736aa0 	ldrb	w0, [x21, x19]
    3944:	7100c01f 	cmp	w0, #0x30
    3948:	54001001 	b.ne	3b48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    394c:	38336abf 	strb	wzr, [x21, x19]
    3950:	b5ffff53 	cbnz	x19, 3938 <fwp_format_g.constprop.0+0x1b8>
    3954:	d503201f 	nop
    3958:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    395c:	f947f400 	ldr	x0, [x0, #4072]
    3960:	f94057e2 	ldr	x2, [sp, #168]
    3964:	f9400001 	ldr	x1, [x0]
    3968:	eb010042 	subs	x2, x2, x1
    396c:	d2800001 	mov	x1, #0x0                   	// #0
    3970:	54001061 	b.ne	3b7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3974:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3978:	a94c53f3 	ldp	x19, x20, [sp, #192]
    397c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3980:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3984:	a95073fb 	ldp	x27, x28, [sp, #256]
    3988:	fd408be8 	ldr	d8, [sp, #272]
    398c:	910483ff 	add	sp, sp, #0x120
    3990:	d65f03c0 	ret
    3994:	1e604100 	fmov	d0, d8
    3998:	710000bf 	cmp	w5, #0x0
    399c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39a0:	aa1503e0 	mov	x0, x21
    39a4:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x70>
    39a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ac:	9104e084 	add	x4, x4, #0x138
    39b0:	52800042 	mov	w2, #0x2                   	// #2
    39b4:	d2803201 	mov	x1, #0x190                 	// #400
    39b8:	97fffb72 	bl	2780 <__snprintf_chk@plt>
    39bc:	17ffffd7 	b	3918 <fwp_format_g.constprop.0+0x198>
    39c0:	cb140273 	sub	x19, x19, x20
    39c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39c8:	910183f9 	add	x25, sp, #0x60
    39cc:	aa1303e2 	mov	x2, x19
    39d0:	aa1403e1 	mov	x1, x20
    39d4:	aa1903e0 	mov	x0, x25
    39d8:	d2800803 	mov	x3, #0x40                  	// #64
    39dc:	97fffb61 	bl	2760 <__memcpy_chk@plt>
    39e0:	38336b3f 	strb	wzr, [x25, x19]
    39e4:	aa1903e0 	mov	x0, x25
    39e8:	528005c1 	mov	w1, #0x2e                  	// #46
    39ec:	97fffbc1 	bl	28f0 <strchr@plt>
    39f0:	b40001c0 	cbz	x0, 3a28 <fwp_format_g.constprop.0+0x2a8>
    39f4:	b50000b3 	cbnz	x19, 3a08 <fwp_format_g.constprop.0+0x288>
    39f8:	1400000c 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    39fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3a00:	f1000673 	subs	x19, x19, #0x1
    3a04:	54000120 	b.eq	3a28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a08:	8b130320 	add	x0, x25, x19
    3a0c:	385ff001 	ldurb	w1, [x0, #-1]
    3a10:	7100c03f 	cmp	w1, #0x30
    3a14:	54ffff40 	b.eq	39fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3a18:	d1000673 	sub	x19, x19, #0x1
    3a1c:	38736b20 	ldrb	w0, [x25, x19]
    3a20:	7100b81f 	cmp	w0, #0x2e
    3a24:	54000a80 	b.eq	3b74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a28:	710002ff 	cmp	w23, #0x0
    3a2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a30:	aa1903e5 	mov	x5, x25
    3a34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a38:	aa1503e0 	mov	x0, x21
    3a3c:	52800566 	mov	w6, #0x2b                  	// #43
    3a40:	f0000044 	adrp	x4, e000 <_IO_stdin_used+0x70>
    3a44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a48:	9104a084 	add	x4, x4, #0x128
    3a4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a50:	52800042 	mov	w2, #0x2                   	// #2
    3a54:	d2803201 	mov	x1, #0x190                 	// #400
    3a58:	97fffb4a 	bl	2780 <__snprintf_chk@plt>
    3a5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a60:	17ffffbe 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3a64:	52800605 	mov	w5, #0x30                  	// #48
    3a68:	390000e5 	strb	w5, [x7]
    3a6c:	d100077b 	sub	x27, x27, #0x1
    3a70:	aa0303e1 	mov	x1, x3
    3a74:	aa1603e0 	mov	x0, x22
    3a78:	aa1b03e3 	mov	x3, x27
    3a7c:	aa1a03e2 	mov	x2, x26
    3a80:	f90007e6 	str	x6, [sp, #8]
    3a84:	b90013e4 	str	w4, [sp, #16]
    3a88:	8b1a02d6 	add	x22, x22, x26
    3a8c:	b9001be5 	str	w5, [sp, #24]
    3a90:	97fffb34 	bl	2760 <__memcpy_chk@plt>
    3a94:	f94007e6 	ldr	x6, [sp, #8]
    3a98:	2a3703e7 	mvn	w7, w23
    3a9c:	b94013e4 	ldr	w4, [sp, #16]
    3aa0:	cb1b00c1 	sub	x1, x6, x27
    3aa4:	cb06037b 	sub	x27, x27, x6
    3aa8:	f101203f 	cmp	x1, #0x48
    3aac:	d2800906 	mov	x6, #0x48                  	// #72
    3ab0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ab4:	8b1b0023 	add	x3, x1, x27
    3ab8:	310006ff 	cmn	w23, #0x1
    3abc:	54000220 	b.eq	3b00 <fwp_format_g.constprop.0+0x380>  // b.none
    3ac0:	b9401be5 	ldr	w5, [sp, #24]
    3ac4:	d2800001 	mov	x1, #0x0                   	// #0
    3ac8:	f101207f 	cmp	x3, #0x48
    3acc:	d1000462 	sub	x2, x3, #0x1
    3ad0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3ad4:	38216ac5 	strb	w5, [x22, x1]
    3ad8:	cb030003 	sub	x3, x0, x3
    3adc:	91000421 	add	x1, x1, #0x1
    3ae0:	91000463 	add	x3, x3, #0x1
    3ae4:	eb00007f 	cmp	x3, x0
    3ae8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3aec:	cb000063 	sub	x3, x3, x0
    3af0:	8b020063 	add	x3, x3, x2
    3af4:	6b0100ff 	cmp	w7, w1
    3af8:	54fffe8c 	b.gt	3ac8 <fwp_format_g.constprop.0+0x348>
    3afc:	8b2742d6 	add	x22, x22, w7, uxtw
    3b00:	f101207f 	cmp	x3, #0x48
    3b04:	d2800905 	mov	x5, #0x48                  	// #72
    3b08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b0c:	aa1603e0 	mov	x0, x22
    3b10:	cb0300a1 	sub	x1, x5, x3
    3b14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b18:	91000421 	add	x1, x1, #0x1
    3b1c:	d1000463 	sub	x3, x3, #0x1
    3b20:	eb05003f 	cmp	x1, x5
    3b24:	38001402 	strb	w2, [x0], #1
    3b28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b2c:	93407f82 	sxtw	x2, w28
    3b30:	cb050025 	sub	x5, x1, x5
    3b34:	aa1303e1 	mov	x1, x19
    3b38:	8b0300a3 	add	x3, x5, x3
    3b3c:	8b1802d3 	add	x19, x22, x24
    3b40:	97fffb08 	bl	2760 <__memcpy_chk@plt>
    3b44:	17ffff6b 	b	38f0 <fwp_format_g.constprop.0+0x170>
    3b48:	d1000421 	sub	x1, x1, #0x1
    3b4c:	38616aa0 	ldrb	w0, [x21, x1]
    3b50:	7100b81f 	cmp	w0, #0x2e
    3b54:	54fff021 	b.ne	3958 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b58:	38216abf 	strb	wzr, [x21, x1]
    3b5c:	17ffff7f 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3b60:	910187e7 	add	x7, sp, #0x61
    3b64:	910183f9 	add	x25, sp, #0x60
    3b68:	d28008fb 	mov	x27, #0x47                  	// #71
    3b6c:	390183e0 	strb	w0, [sp, #96]
    3b70:	17ffff3b 	b	385c <fwp_format_g.constprop.0+0xdc>
    3b74:	38336b3f 	strb	wzr, [x25, x19]
    3b78:	17ffffac 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    3b7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b80:	97fffb24 	bl	2810 <__stack_chk_fail@plt>

0000000000003b84 <fwp_heap_report>:
    3b84:	d105c3ff 	sub	sp, sp, #0x170
    3b88:	d0000422 	adrp	x2, 89000 <fwp_root_context+0xba0>
    3b8c:	91190042 	add	x2, x2, #0x640
    3b90:	90000161 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    3b94:	f947e821 	ldr	x1, [x1, #4048]
    3b98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3b9c:	910443fd 	add	x29, sp, #0x110
    3ba0:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3ba4:	f947f400 	ldr	x0, [x0, #4072]
    3ba8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bac:	a91463f7 	stp	x23, x24, [sp, #320]
    3bb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3bc0:	f9400036 	ldr	x22, [x1]
    3bc4:	f9400001 	ldr	x1, [x0]
    3bc8:	f90087e1 	str	x1, [sp, #264]
    3bcc:	d2800001 	mov	x1, #0x0                   	// #0
    3bd0:	f949e459 	ldr	x25, [x2, #5064]
    3bd4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    3bd8:	f94a1057 	ldr	x23, [x2, #5152]
    3bdc:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    3be0:	f94a1458 	ldr	x24, [x2, #5160]
    3be4:	91050021 	add	x1, x1, #0x140
    3be8:	91052000 	add	x0, x0, #0x148
    3bec:	97fffaed 	bl	27a0 <fopen@plt>
    3bf0:	b4000760 	cbz	x0, 3cdc <fwp_heap_report+0x158>
    3bf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3bf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3bfc:	aa0003f4 	mov	x20, x0
    3c00:	910023f3 	add	x19, sp, #0x8
    3c04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c08:	72aae915 	movk	w21, #0x5748, lsl #16
    3c0c:	d503201f 	nop
    3c10:	aa1403e2 	mov	x2, x20
    3c14:	aa1303e0 	mov	x0, x19
    3c18:	52802001 	mov	w1, #0x100                 	// #256
    3c1c:	97fffb69 	bl	29c0 <fgets@plt>
    3c20:	b4000280 	cbz	x0, 3c70 <fwp_heap_report+0xec>
    3c24:	b9400261 	ldr	w1, [x19]
    3c28:	6b15003f 	cmp	w1, w21
    3c2c:	54ffff21 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c30:	39401260 	ldrb	w0, [x19, #4]
    3c34:	7101341f 	cmp	w0, #0x4d
    3c38:	54fffec1 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c3c:	394037e0 	ldrb	w0, [sp, #13]
    3c40:	7100e81f 	cmp	w0, #0x3a
    3c44:	54fffe61 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c48:	52800142 	mov	w2, #0xa                   	// #10
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	91003be0 	add	x0, sp, #0xe
    3c54:	97fffb17 	bl	28b0 <strtol@plt>
    3c58:	aa1403e2 	mov	x2, x20
    3c5c:	aa0003fa 	mov	x26, x0
    3c60:	52802001 	mov	w1, #0x100                 	// #256
    3c64:	aa1303e0 	mov	x0, x19
    3c68:	97fffb56 	bl	29c0 <fgets@plt>
    3c6c:	b5fffdc0 	cbnz	x0, 3c24 <fwp_heap_report+0xa0>
    3c70:	aa1403e0 	mov	x0, x20
    3c74:	97fffac7 	bl	2790 <fclose@plt>
    3c78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3c7c:	90000160 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    3c80:	f947f400 	ldr	x0, [x0, #4072]
    3c84:	f94087e2 	ldr	x2, [sp, #264]
    3c88:	f9400001 	ldr	x1, [x0]
    3c8c:	eb010042 	subs	x2, x2, x1
    3c90:	d2800001 	mov	x1, #0x0                   	// #0
    3c94:	54000281 	b.ne	3ce4 <fwp_heap_report+0x160>  // b.any
    3c98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3c9c:	aa1a03e6 	mov	x6, x26
    3ca0:	aa1903e5 	mov	x5, x25
    3ca4:	aa1803e4 	mov	x4, x24
    3ca8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cac:	aa1703e3 	mov	x3, x23
    3cb0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cbc:	1e604121 	fmov	d1, d9
    3cc0:	1e604100 	fmov	d0, d8
    3cc4:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x70>
    3cc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3ccc:	9105a042 	add	x2, x2, #0x168
    3cd0:	9105c3ff 	add	sp, sp, #0x170
    3cd4:	52800041 	mov	w1, #0x2                   	// #2
    3cd8:	17fffaea 	b	2880 <__fprintf_chk@plt>
    3cdc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ce0:	17ffffe7 	b	3c7c <fwp_heap_report+0xf8>
    3ce4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ce8:	97fffaca 	bl	2810 <__stack_chk_fail@plt>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_heap_init>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	f0000423 	adrp	x3, 8a000 <fwp_heap+0x9c0>
    3cf8:	91150061 	add	x1, x3, #0x540
    3cfc:	910003fd 	mov	x29, sp
    3d00:	a90153f3 	stp	x19, x20, [sp, #16]
    3d04:	d0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    3d08:	91190262 	add	x2, x19, #0x640
    3d0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d10:	52800024 	mov	w4, #0x1                   	// #1
    3d14:	52800200 	mov	w0, #0x10                  	// #16
    3d18:	b913a444 	str	w4, [x2, #5028]
    3d1c:	d503201f 	nop
    3d20:	b8004420 	str	w0, [x1], #4
    3d24:	11004000 	add	w0, w0, #0x10
    3d28:	7104401f 	cmp	w0, #0x110
    3d2c:	54ffffa1 	b.ne	3d20 <fwp_heap_init+0x30>  // b.any
    3d30:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x70>
    3d34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d38:	f0000421 	adrp	x1, 8a000 <fwp_heap+0x9c0>
    3d3c:	91160021 	add	x1, x1, #0x580
    3d40:	3dc3cc43 	ldr	q3, [x2, #3888]
    3d44:	d2800000 	mov	x0, #0x0                   	// #0
    3d48:	4e040401 	dup	v1.4s, v0.s[0]
    3d4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d50:	0f215400 	shl	v0.2s, v0.2s, #1
    3d54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d58:	3ca06821 	str	q1, [x1, x0]
    3d5c:	91004000 	add	x0, x0, #0x10
    3d60:	f101801f 	cmp	x0, #0x60
    3d64:	54ffff21 	b.ne	3d48 <fwp_heap_init+0x58>  // b.any
    3d68:	f0000424 	adrp	x4, 8a000 <fwp_heap+0x9c0>
    3d6c:	91150063 	add	x3, x3, #0x540
    3d70:	91178084 	add	x4, x4, #0x5e0
    3d74:	91190266 	add	x6, x19, #0x640
    3d78:	d2800002 	mov	x2, #0x0                   	// #0
    3d7c:	d2800000 	mov	x0, #0x0                   	// #0
    3d80:	d2880205 	mov	x5, #0x4010                	// #16400
    3d84:	d503201f 	nop
    3d88:	910f0001 	add	x1, x0, #0x3c0
    3d8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3d90:	eb02003f 	cmp	x1, x2
    3d94:	540000a2 	b.cs	3da8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3d98:	91000400 	add	x0, x0, #0x1
    3d9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3da0:	eb02003f 	cmp	x1, x2
    3da4:	54ffffa3 	b.cc	3d98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3da8:	91004042 	add	x2, x2, #0x10
    3dac:	38001480 	strb	w0, [x4], #1
    3db0:	eb05005f 	cmp	x2, x5
    3db4:	54fffea1 	b.ne	3d88 <fwp_heap_init+0x98>  // b.any
    3db8:	528000b5 	mov	w21, #0x5                   	// #5
    3dbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3dc0:	14000004 	b	3dd0 <fwp_heap_init+0xe0>
    3dc4:	d342fe94 	lsr	x20, x20, #2
    3dc8:	710006b5 	subs	w21, w21, #0x1
    3dcc:	54000720 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3dd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3dd4:	d2800005 	mov	x5, #0x0                   	// #0
    3dd8:	aa1603e1 	mov	x1, x22
    3ddc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3de0:	52880443 	mov	w3, #0x4022                	// #16418
    3de4:	52800002 	mov	w2, #0x0                   	// #0
    3de8:	d2800000 	mov	x0, #0x0                   	// #0
    3dec:	97fffaad 	bl	28a0 <mmap@plt>
    3df0:	aa0003e6 	mov	x6, x0
    3df4:	b100041f 	cmn	x0, #0x1
    3df8:	54fffe60 	b.eq	3dc4 <fwp_heap_init+0xd4>  // b.none
    3dfc:	b40005a0 	cbz	x0, 3eb0 <fwp_heap_init+0x1c0>
    3e00:	d350fe94 	lsr	x20, x20, #16
    3e04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e08:	8b0000c7 	add	x7, x6, x0
    3e0c:	91190275 	add	x21, x19, #0x640
    3e10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e14:	8b140a81 	add	x1, x20, x20, lsl #2
    3e18:	d2800005 	mov	x5, #0x0                   	// #0
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	d37df021 	lsl	x1, x1, #3
    3e24:	52880443 	mov	w3, #0x4022                	// #16418
    3e28:	52800002 	mov	w2, #0x0                   	// #0
    3e2c:	d2800000 	mov	x0, #0x0                   	// #0
    3e30:	f909daa7 	str	x7, [x21, #5040]
    3e34:	f909dea6 	str	x6, [x21, #5048]
    3e38:	f909e2b6 	str	x22, [x21, #5056]
    3e3c:	f909eab4 	str	x20, [x21, #5072]
    3e40:	f90a02a1 	str	x1, [x21, #5120]
    3e44:	97fffa97 	bl	28a0 <mmap@plt>
    3e48:	aa0003e1 	mov	x1, x0
    3e4c:	b100041f 	cmn	x0, #0x1
    3e50:	54000300 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3e54:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    3e58:	9107c000 	add	x0, x0, #0x1f0
    3e5c:	f909fea1 	str	x1, [x21, #5112]
    3e60:	97fffad0 	bl	29a0 <getenv@plt>
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	aa0003e1 	mov	x1, x0
    3e6c:	b40000e0 	cbz	x0, 3e88 <fwp_heap_init+0x198>
    3e70:	39400000 	ldrb	w0, [x0]
    3e74:	340000a0 	cbz	w0, 3e88 <fwp_heap_init+0x198>
    3e78:	7100c000 	subs	w0, w0, #0x30
    3e7c:	54000120 	b.eq	3ea0 <fwp_heap_init+0x1b0>  // b.none
    3e80:	7100001f 	cmp	w0, #0x0
    3e84:	1a9f07e2 	cset	w2, ne	// ne = any
    3e88:	91190273 	add	x19, x19, #0x640
    3e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e90:	b913aa62 	str	w2, [x19, #5032]
    3e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e9c:	d65f03c0 	ret
    3ea0:	39400420 	ldrb	w0, [x1, #1]
    3ea4:	7100001f 	cmp	w0, #0x0
    3ea8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eac:	17fffff7 	b	3e88 <fwp_heap_init+0x198>
    3eb0:	97fffc90 	bl	30f0 <fwp_heap_oom>

0000000000003eb4 <fwp_wake_io>:
    3eb4:	b0000169 	adrp	x9, 30000 <__data_start>
    3eb8:	91018122 	add	x2, x9, #0x60
    3ebc:	f9400001 	ldr	x1, [x0]
    3ec0:	5280000a 	mov	w10, #0x0                   	// #0
    3ec4:	f9406046 	ldr	x6, [x2, #192]
    3ec8:	52800008 	mov	w8, #0x0                   	// #0
    3ecc:	4f000400 	movi	v0.4s, #0x0
    3ed0:	52800027 	mov	w7, #0x1                   	// #1
    3ed4:	aa0103e2 	mov	x2, x1
    3ed8:	b4000321 	cbz	x1, 3f3c <fwp_wake_io+0x88>
    3edc:	f9408c25 	ldr	x5, [x1, #280]
    3ee0:	39015c27 	strb	w7, [x1, #87]
    3ee4:	b4000165 	cbz	x5, 3f10 <fwp_wake_io+0x5c>
    3ee8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3eec:	b4000364 	cbz	x4, 3f58 <fwp_wake_io+0xa4>
    3ef0:	f9009483 	str	x3, [x4, #296]
    3ef4:	f9409423 	ldr	x3, [x1, #296]
    3ef8:	b4000043 	cbz	x3, 3f00 <fwp_wake_io+0x4c>
    3efc:	f9009064 	str	x4, [x3, #288]
    3f00:	91080023 	add	x3, x1, #0x200
    3f04:	f900943f 	str	xzr, [x1, #296]
    3f08:	3c918060 	stur	q0, [x3, #-232]
    3f0c:	f9400001 	ldr	x1, [x0]
    3f10:	f9402843 	ldr	x3, [x2, #80]
    3f14:	f2001c7f 	tst	x3, #0xff000000ff
    3f18:	54fffde1 	b.ne	3ed4 <fwp_wake_io+0x20>  // b.any
    3f1c:	39015047 	strb	w7, [x2, #84]
    3f20:	f900805f 	str	xzr, [x2, #256]
    3f24:	b40001e6 	cbz	x6, 3f60 <fwp_wake_io+0xac>
    3f28:	f90080c2 	str	x2, [x6, #256]
    3f2c:	aa0203e6 	mov	x6, x2
    3f30:	52800028 	mov	w8, #0x1                   	// #1
    3f34:	aa0103e2 	mov	x2, x1
    3f38:	b5fffd21 	cbnz	x1, 3edc <fwp_wake_io+0x28>
    3f3c:	3400006a 	cbz	w10, 3f48 <fwp_wake_io+0x94>
    3f40:	91018120 	add	x0, x9, #0x60
    3f44:	f900640b 	str	x11, [x0, #200]
    3f48:	34000068 	cbz	w8, 3f54 <fwp_wake_io+0xa0>
    3f4c:	91018129 	add	x9, x9, #0x60
    3f50:	f9006126 	str	x6, [x9, #192]
    3f54:	d65f03c0 	ret
    3f58:	f90000a3 	str	x3, [x5]
    3f5c:	17ffffe7 	b	3ef8 <fwp_wake_io+0x44>
    3f60:	aa0203eb 	mov	x11, x2
    3f64:	5280002a 	mov	w10, #0x1                   	// #1
    3f68:	17fffff1 	b	3f2c <fwp_wake_io+0x78>
    3f6c:	d503201f 	nop

0000000000003f70 <ad_raw_free.part.0>:
    3f70:	b0000364 	adrp	x4, 70000 <ad_raw_checkpoints+0x2fba0>
    3f74:	d2800001 	mov	x1, #0x0                   	// #0
    3f78:	91118082 	add	x2, x4, #0x460
    3f7c:	14000005 	b	3f90 <ad_raw_free.part.0+0x20>
    3f80:	91000421 	add	x1, x1, #0x1
    3f84:	91006042 	add	x2, x2, #0x18
    3f88:	f140043f 	cmp	x1, #0x1, lsl #12
    3f8c:	54000220 	b.eq	3fd0 <ad_raw_free.part.0+0x60>  // b.none
    3f90:	f9400043 	ldr	x3, [x2]
    3f94:	eb03001f 	cmp	x0, x3
    3f98:	54ffff41 	b.ne	3f80 <ad_raw_free.part.0+0x10>  // b.any
    3f9c:	8b010421 	add	x1, x1, x1, lsl #1
    3fa0:	91118084 	add	x4, x4, #0x460
    3fa4:	b0000162 	adrp	x2, 30000 <__data_start>
    3fa8:	91018042 	add	x2, x2, #0x60
    3fac:	8b010c81 	add	x1, x4, x1, lsl #3
    3fb0:	b9401024 	ldr	w4, [x1, #16]
    3fb4:	f9400425 	ldr	x5, [x1, #8]
    3fb8:	a9007c3f 	stp	xzr, xzr, [x1]
    3fbc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    3fc0:	f900083f 	str	xzr, [x1, #16]
    3fc4:	cb050061 	sub	x1, x3, x5
    3fc8:	f8247841 	str	x1, [x2, x4, lsl #3]
    3fcc:	17fffa41 	b	28d0 <free@plt>
    3fd0:	f100001f 	cmp	x0, #0x0
    3fd4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    3fd8:	91086021 	add	x1, x1, #0x218
    3fdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3fe0:	f0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    3fe4:	91080000 	add	x0, x0, #0x200
    3fe8:	910003fd 	mov	x29, sp
    3fec:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    3ff0:	97fffcc4 	bl	3300 <ad_raw_fail>

0000000000003ff4 <fwp_tape_buffers_dispose>:
    3ff4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ff8:	910003fd 	mov	x29, sp
    3ffc:	f9000bf3 	str	x19, [sp, #16]
    4000:	aa0003f3 	mov	x19, x0
    4004:	f9400000 	ldr	x0, [x0]
    4008:	b4000040 	cbz	x0, 4010 <fwp_tape_buffers_dispose+0x1c>
    400c:	97ffffd9 	bl	3f70 <ad_raw_free.part.0>
    4010:	f9400a60 	ldr	x0, [x19, #16]
    4014:	b4000040 	cbz	x0, 401c <fwp_tape_buffers_dispose+0x28>
    4018:	97ffffd6 	bl	3f70 <ad_raw_free.part.0>
    401c:	f9401260 	ldr	x0, [x19, #32]
    4020:	b4000040 	cbz	x0, 4028 <fwp_tape_buffers_dispose+0x34>
    4024:	97ffffd3 	bl	3f70 <ad_raw_free.part.0>
    4028:	4f000400 	movi	v0.4s, #0x0
    402c:	f9001a7f 	str	xzr, [x19, #48]
    4030:	ad000260 	stp	q0, q0, [x19]
    4034:	3d800a60 	str	q0, [x19, #32]
    4038:	f9400bf3 	ldr	x19, [sp, #16]
    403c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4040:	d65f03c0 	ret

0000000000004044 <ad_raw_realloc>:
    4044:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4048:	910003fd 	mov	x29, sp
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	f90013f5 	str	x21, [sp, #32]
    4054:	b40005a1 	cbz	x1, 4108 <ad_raw_realloc+0xc4>
    4058:	aa0103f4 	mov	x20, x1
    405c:	2a0203f5 	mov	w21, w2
    4060:	90000361 	adrp	x1, 70000 <ad_raw_checkpoints+0x2fba0>
    4064:	d2800004 	mov	x4, #0x0                   	// #0
    4068:	91118025 	add	x5, x1, #0x460
    406c:	14000005 	b	4080 <ad_raw_realloc+0x3c>
    4070:	91000484 	add	x4, x4, #0x1
    4074:	910060a5 	add	x5, x5, #0x18
    4078:	f140049f 	cmp	x4, #0x1, lsl #12
    407c:	54000320 	b.eq	40e0 <ad_raw_realloc+0x9c>  // b.none
    4080:	f94000a6 	ldr	x6, [x5]
    4084:	eb06001f 	cmp	x0, x6
    4088:	54ffff41 	b.ne	4070 <ad_raw_realloc+0x2c>  // b.any
    408c:	8b040484 	add	x4, x4, x4, lsl #1
    4090:	91118021 	add	x1, x1, #0x460
    4094:	8b040c33 	add	x19, x1, x4, lsl #3
    4098:	b4000080 	cbz	x0, 40a8 <ad_raw_realloc+0x64>
    409c:	b9401261 	ldr	w1, [x19, #16]
    40a0:	6b15003f 	cmp	w1, w21
    40a4:	540002c1 	b.ne	40fc <ad_raw_realloc+0xb8>  // b.any
    40a8:	aa1403e1 	mov	x1, x20
    40ac:	97fff9d5 	bl	2800 <realloc@plt>
    40b0:	aa0003ed 	mov	x13, x0
    40b4:	b40000c0 	cbz	x0, 40cc <ad_raw_realloc+0x88>
    40b8:	2a1503e3 	mov	w3, w21
    40bc:	aa1403e2 	mov	x2, x20
    40c0:	aa1303e0 	mov	x0, x19
    40c4:	aa0d03e1 	mov	x1, x13
    40c8:	97fffb92 	bl	2f10 <ad_raw_record>
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	aa0d03e0 	mov	x0, x13
    40d4:	f94013f5 	ldr	x21, [sp, #32]
    40d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40dc:	d65f03c0 	ret
    40e0:	f100001f 	cmp	x0, #0x0
    40e4:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    40e8:	91086021 	add	x1, x1, #0x218
    40ec:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    40f0:	91080000 	add	x0, x0, #0x200
    40f4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    40f8:	97fffc82 	bl	3300 <ad_raw_fail>
    40fc:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4100:	91096000 	add	x0, x0, #0x258
    4104:	97fffc7f 	bl	3300 <ad_raw_fail>
    4108:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    410c:	9108e000 	add	x0, x0, #0x238
    4110:	97fffc7c 	bl	3300 <ad_raw_fail>

0000000000004114 <fwp_tape_buffers_release>:
    4114:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4118:	910003fd 	mov	x29, sp
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f4 	mov	x20, x0
    4124:	f9401400 	ldr	x0, [x0, #40]
    4128:	a9025bf5 	stp	x21, x22, [sp, #32]
    412c:	b7f80560 	tbnz	x0, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4130:	f9401a93 	ldr	x19, [x20, #48]
    4134:	b7f80533 	tbnz	x19, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4138:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    413c:	eb01001f 	cmp	x0, x1
    4140:	540004c8 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4144:	8b000400 	add	x0, x0, x0, lsl #1
    4148:	d2a00101 	mov	x1, #0x80000               	// #524288
    414c:	d37df000 	lsl	x0, x0, #3
    4150:	cb000021 	sub	x1, x1, x0
    4154:	eb410e7f 	cmp	x19, x1, lsr #3
    4158:	54000408 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    415c:	8b130c13 	add	x19, x0, x19, lsl #3
    4160:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4164:	9109c000 	add	x0, x0, #0x270
    4168:	97fffa0e 	bl	29a0 <getenv@plt>
    416c:	b4000080 	cbz	x0, 417c <fwp_tape_buffers_release+0x68>
    4170:	39400001 	ldrb	w1, [x0]
    4174:	7100c03f 	cmp	w1, #0x30
    4178:	54000880 	b.eq	4288 <fwp_tape_buffers_release+0x174>  // b.none
    417c:	d1000661 	sub	x1, x19, #0x1
    4180:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4184:	eb00003f 	cmp	x1, x0
    4188:	54000328 	b.hi	41ec <fwp_tape_buffers_release+0xd8>  // b.pmore
    418c:	90000175 	adrp	x21, 30000 <__data_start>
    4190:	f9001bf7 	str	x23, [sp, #48]
    4194:	910182b7 	add	x23, x21, #0x60
    4198:	910342f6 	add	x22, x23, #0xd0
    419c:	aa1603e0 	mov	x0, x22
    41a0:	97ffff95 	bl	3ff4 <fwp_tape_buffers_dispose>
    41a4:	ad400a81 	ldp	q1, q2, [x20]
    41a8:	f90086f3 	str	x19, [x23, #264]
    41ac:	4f000400 	movi	v0.4s, #0x0
    41b0:	ad000ac1 	stp	q1, q2, [x22]
    41b4:	3dc00a81 	ldr	q1, [x20, #32]
    41b8:	3d800ac1 	str	q1, [x22, #32]
    41bc:	f9401a80 	ldr	x0, [x20, #48]
    41c0:	f9001ac0 	str	x0, [x22, #48]
    41c4:	f9001a9f 	str	xzr, [x20, #48]
    41c8:	ad000280 	stp	q0, q0, [x20]
    41cc:	3d800a80 	str	q0, [x20, #32]
    41d0:	f9401bf7 	ldr	x23, [sp, #48]
    41d4:	1400000b 	b	4200 <fwp_tape_buffers_release+0xec>
    41d8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    41dc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    41e0:	9109c000 	add	x0, x0, #0x270
    41e4:	97fff9ef 	bl	29a0 <getenv@plt>
    41e8:	b5fffc40 	cbnz	x0, 4170 <fwp_tape_buffers_release+0x5c>
    41ec:	aa1403e0 	mov	x0, x20
    41f0:	97ffff81 	bl	3ff4 <fwp_tape_buffers_dispose>
    41f4:	90000175 	adrp	x21, 30000 <__data_start>
    41f8:	910182a0 	add	x0, x21, #0x60
    41fc:	f9408413 	ldr	x19, [x0, #264]
    4200:	910182a2 	add	x2, x21, #0x60
    4204:	f9408844 	ldr	x4, [x2, #272]
    4208:	a9400c45 	ldp	x5, x3, [x2]
    420c:	8b040481 	add	x1, x4, x4, lsl #1
    4210:	f9400840 	ldr	x0, [x2, #16]
    4214:	8b010881 	add	x1, x4, x1, lsl #2
    4218:	f9400c44 	ldr	x4, [x2, #24]
    421c:	8b0300a3 	add	x3, x5, x3
    4220:	d37df021 	lsl	x1, x1, #3
    4224:	8b040000 	add	x0, x0, x4
    4228:	8b030000 	add	x0, x0, x3
    422c:	eb05003f 	cmp	x1, x5
    4230:	54000321 	b.ne	4294 <fwp_tape_buffers_release+0x180>  // b.any
    4234:	8b130023 	add	x3, x1, x19
    4238:	eb00007f 	cmp	x3, x0
    423c:	540002c8 	b.hi	4294 <fwp_tape_buffers_release+0x180>  // b.pmore
    4240:	f9405c43 	ldr	x3, [x2, #184]
    4244:	f140087f 	cmp	x3, #0x2, lsl #12
    4248:	540002e0 	b.eq	42a4 <fwp_tape_buffers_release+0x190>  // b.none
    424c:	8b030464 	add	x4, x3, x3, lsl #1
    4250:	900001e5 	adrp	x5, 40000 <alt.5+0xfba0>
    4254:	911180a5 	add	x5, x5, #0x460
    4258:	cb010000 	sub	x0, x0, x1
    425c:	d37df084 	lsl	x4, x4, #3
    4260:	cb130000 	sub	x0, x0, x19
    4264:	8b0400a6 	add	x6, x5, x4
    4268:	91000463 	add	x3, x3, #0x1
    426c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4270:	f82468a1 	str	x1, [x5, x4]
    4274:	a90080d3 	stp	x19, x0, [x6, #8]
    4278:	f9005c43 	str	x3, [x2, #184]
    427c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4280:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4284:	d65f03c0 	ret
    4288:	39400400 	ldrb	w0, [x0, #1]
    428c:	34fffb00 	cbz	w0, 41ec <fwp_tape_buffers_release+0xd8>
    4290:	17ffffbb 	b	417c <fwp_tape_buffers_release+0x68>
    4294:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4298:	910a2000 	add	x0, x0, #0x288
    429c:	f9001bf7 	str	x23, [sp, #48]
    42a0:	97fffc18 	bl	3300 <ad_raw_fail>
    42a4:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    42a8:	910ae000 	add	x0, x0, #0x2b8
    42ac:	f9001bf7 	str	x23, [sp, #48]
    42b0:	97fffc14 	bl	3300 <ad_raw_fail>

00000000000042b4 <fwp_trap>:
    42b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42b8:	90000162 	adrp	x2, 30000 <__data_start>
    42bc:	d53bd041 	mrs	x1, tpidr_el0
    42c0:	910003fd 	mov	x29, sp
    42c4:	f9407842 	ldr	x2, [x2, #240]
    42c8:	91400021 	add	x1, x1, #0x0, lsl #12
    42cc:	91004021 	add	x1, x1, #0x10
    42d0:	a90153f3 	stp	x19, x20, [sp, #16]
    42d4:	aa0003f3 	mov	x19, x0
    42d8:	f9400034 	ldr	x20, [x1]
    42dc:	b4000062 	cbz	x2, 42e8 <fwp_trap+0x34>
    42e0:	aa0203e0 	mov	x0, x2
    42e4:	97fff997 	bl	2940 <fflush@plt>
    42e8:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    42ec:	f947ec00 	ldr	x0, [x0, #4056]
    42f0:	f9400000 	ldr	x0, [x0]
    42f4:	97fff993 	bl	2940 <fflush@plt>
    42f8:	aa1303e3 	mov	x3, x19
    42fc:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x70>
    4300:	f0000153 	adrp	x19, 2f000 <fwp_fn_table+0xb30>
    4304:	f947ea73 	ldr	x19, [x19, #4048]
    4308:	910b6042 	add	x2, x2, #0x2d8
    430c:	52800041 	mov	w1, #0x2                   	// #2
    4310:	f9400260 	ldr	x0, [x19]
    4314:	97fff95b 	bl	2880 <__fprintf_chk@plt>
    4318:	b40000b4 	cbz	x20, 432c <fwp_trap+0x78>
    431c:	f9400260 	ldr	x0, [x19]
    4320:	97fff988 	bl	2940 <fflush@plt>
    4324:	52800ca0 	mov	w0, #0x65                  	// #101
    4328:	97fff996 	bl	2980 <_Exit@plt>
    432c:	52800ca0 	mov	w0, #0x65                  	// #101
    4330:	97fff8e4 	bl	26c0 <exit@plt>

0000000000004334 <fwp_rc_forget_slot.part.0>:
    4334:	ca404401 	eor	x1, x0, x0, lsr #17
    4338:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    433c:	ca412421 	eor	x1, x1, x1, lsr #9
    4340:	910003fd 	mov	x29, sp
    4344:	92401c21 	and	x1, x1, #0xff
    4348:	f9000bf3 	str	x19, [sp, #16]
    434c:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    4350:	91190262 	add	x2, x19, #0x640
    4354:	910a2423 	add	x3, x1, #0x289
    4358:	8b010c41 	add	x1, x2, x1, lsl #3
    435c:	8b030c43 	add	x3, x2, x3, lsl #3
    4360:	f94a2421 	ldr	x1, [x1, #5192]
    4364:	b50000a1 	cbnz	x1, 4378 <fwp_rc_forget_slot.part.0+0x44>
    4368:	14000012 	b	43b0 <fwp_rc_forget_slot.part.0+0x7c>
    436c:	91004023 	add	x3, x1, #0x10
    4370:	f9400821 	ldr	x1, [x1, #16]
    4374:	b40001e1 	cbz	x1, 43b0 <fwp_rc_forget_slot.part.0+0x7c>
    4378:	f9400022 	ldr	x2, [x1]
    437c:	eb02001f 	cmp	x0, x2
    4380:	54ffff61 	b.ne	436c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4384:	f9400060 	ldr	x0, [x3]
    4388:	91190273 	add	x19, x19, #0x640
    438c:	f9400801 	ldr	x1, [x0, #16]
    4390:	f9000061 	str	x1, [x3]
    4394:	97fff94f 	bl	28d0 <free@plt>
    4398:	f94e2660 	ldr	x0, [x19, #7240]
    439c:	d1000400 	sub	x0, x0, #0x1
    43a0:	f90e2660 	str	x0, [x19, #7240]
    43a4:	f9400bf3 	ldr	x19, [sp, #16]
    43a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43ac:	d65f03c0 	ret
    43b0:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    43b4:	910ba000 	add	x0, x0, #0x2e8
    43b8:	97ffffbf 	bl	42b4 <fwp_trap>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_rc_prepare_chunk>:
    43c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000436 	adrp	x22, 89000 <fwp_root_context+0xba0>
    43d0:	911902c2 	add	x2, x22, #0x640
    43d4:	b9401c03 	ldr	w3, [x0, #28]
    43d8:	aa0103f5 	mov	x21, x1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f4 	mov	x20, x0
    43e4:	f94e2440 	ldr	x0, [x2, #7240]
    43e8:	b4000440 	cbz	x0, 4470 <fwp_rc_prepare_chunk+0xb0>
    43ec:	d2800013 	mov	x19, #0x0                   	// #0
    43f0:	35000203 	cbnz	w3, 4430 <fwp_rc_prepare_chunk+0x70>
    43f4:	b4000361 	cbz	x1, 4460 <fwp_rc_prepare_chunk+0xa0>
    43f8:	f9401280 	ldr	x0, [x20, #32]
    43fc:	97fff935 	bl	28d0 <free@plt>
    4400:	aa1503e0 	mov	x0, x21
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	97fff8fa 	bl	27f0 <calloc@plt>
    440c:	f9001280 	str	x0, [x20, #32]
    4410:	b5000460 	cbnz	x0, 449c <fwp_rc_prepare_chunk+0xdc>
    4414:	97fffb37 	bl	30f0 <fwp_heap_oom>
    4418:	97ffffc7 	bl	4334 <fwp_rc_forget_slot.part.0>
    441c:	91000673 	add	x19, x19, #0x1
    4420:	b9401e83 	ldr	w3, [x20, #28]
    4424:	eb13007f 	cmp	x3, x19
    4428:	54000169 	b.ls	4454 <fwp_rc_prepare_chunk+0x94>  // b.plast
    442c:	d503201f 	nop
    4430:	f9401283 	ldr	x3, [x20, #32]
    4434:	8b130060 	add	x0, x3, x19
    4438:	38736863 	ldrb	w3, [x3, x19]
    443c:	7103fc7f 	cmp	w3, #0xff
    4440:	54fffec0 	b.eq	4418 <fwp_rc_prepare_chunk+0x58>  // b.none
    4444:	b9401e83 	ldr	w3, [x20, #28]
    4448:	91000673 	add	x19, x19, #0x1
    444c:	eb13007f 	cmp	x3, x19
    4450:	54ffff08 	b.hi	4430 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4454:	eb0302bf 	cmp	x21, x3
    4458:	54000121 	b.ne	447c <fwp_rc_prepare_chunk+0xbc>  // b.any
    445c:	b5000335 	cbnz	x21, 44c0 <fwp_rc_prepare_chunk+0x100>
    4460:	a94153f3 	ldp	x19, x20, [sp, #16]
    4464:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	2a0303e3 	mov	w3, w3
    4474:	eb0302bf 	cmp	x21, x3
    4478:	54ffff20 	b.eq	445c <fwp_rc_prepare_chunk+0x9c>  // b.none
    447c:	911902c2 	add	x2, x22, #0x640
    4480:	f9401280 	ldr	x0, [x20, #32]
    4484:	f94e2841 	ldr	x1, [x2, #7248]
    4488:	cb030021 	sub	x1, x1, x3
    448c:	f90e2841 	str	x1, [x2, #7248]
    4490:	97fff910 	bl	28d0 <free@plt>
    4494:	b5fffb75 	cbnz	x21, 4400 <fwp_rc_prepare_chunk+0x40>
    4498:	f900129f 	str	xzr, [x20, #32]
    449c:	911902d6 	add	x22, x22, #0x640
    44a0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44a4:	b9001e95 	str	w21, [x20, #28]
    44a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ac:	8b150000 	add	x0, x0, x21
    44b0:	f90e2ac0 	str	x0, [x22, #7248]
    44b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f9401280 	ldr	x0, [x20, #32]
    44c4:	aa1503e2 	mov	x2, x21
    44c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44cc:	52800001 	mov	w1, #0x0                   	// #0
    44d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44d8:	17fff8c2 	b	27e0 <memset@plt>
    44dc:	d503201f 	nop

00000000000044e0 <fwp_heap_refill>:
    44e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44e4:	910003fd 	mov	x29, sp
    44e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44ec:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    44f0:	911902b5 	add	x21, x21, #0x640
    44f4:	aa0003f6 	mov	x22, x0
    44f8:	d2800020 	mov	x0, #0x1                   	// #1
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	a90363f7 	stp	x23, x24, [sp, #48]
    4504:	2a0103f7 	mov	w23, w1
    4508:	2a0203f8 	mov	w24, w2
    450c:	97fffb09 	bl	3130 <fwp_heap_chunks>
    4510:	aa0003f3 	mov	x19, x0
    4514:	f949fea2 	ldr	x2, [x21, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	2a1703e1 	mov	w1, w23
    4520:	52800025 	mov	w5, #0x1                   	// #1
    4524:	d37df000 	lsl	x0, x0, #3
    4528:	910f0021 	add	x1, x1, #0x3c0
    452c:	8b000054 	add	x20, x2, x0
    4530:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4534:	52a00024 	mov	w4, #0x10000               	// #65536
    4538:	38206845 	strb	w5, [x2, x0]
    453c:	aa1403e0 	mov	x0, x20
    4540:	39000698 	strb	w24, [x20, #1]
    4544:	39000a97 	strb	w23, [x20, #2]
    4548:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    454c:	b9000681 	str	w1, [x20, #4]
    4550:	2a0103e5 	mov	w5, w1
    4554:	8b0300a2 	add	x2, x5, x3
    4558:	1ac10881 	udiv	w1, w4, w1
    455c:	9ac50842 	udiv	x2, x2, x5
    4560:	b9000a81 	str	w1, [x20, #8]
    4564:	92404021 	and	x1, x1, #0x1ffff
    4568:	b9001a82 	str	w2, [x20, #24]
    456c:	97ffff95 	bl	43c0 <fwp_rc_prepare_chunk>
    4570:	f949daa0 	ldr	x0, [x21, #5040]
    4574:	29408a81 	ldp	w1, w2, [x20, #4]
    4578:	8b134000 	add	x0, x0, x19, lsl #16
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	8b214003 	add	x3, x0, w1, uxtw
    4584:	9ba20021 	umaddl	x1, w1, w2, x0
    4588:	a94363f7 	ldp	x23, x24, [sp, #48]
    458c:	a90086c3 	stp	x3, x1, [x22, #8]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4598:	d65f03c0 	ret
    459c:	d503201f 	nop

00000000000045a0 <fwp_mem_free>:
    45a0:	b40003c0 	cbz	x0, 4618 <fwp_mem_free+0x78>
    45a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45a8:	910003fd 	mov	x29, sp
    45ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    45b0:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    45b4:	911902a1 	add	x1, x21, #0x640
    45b8:	a90153f3 	stp	x19, x20, [sp, #16]
    45bc:	aa0003f3 	mov	x19, x0
    45c0:	f949d823 	ldr	x3, [x1, #5040]
    45c4:	f949ec22 	ldr	x2, [x1, #5080]
    45c8:	cb030000 	sub	x0, x0, x3
    45cc:	eb02401f 	cmp	x0, x2, lsl #16
    45d0:	540001c2 	b.cs	4608 <fwp_mem_free+0x68>  // b.hs, b.nlast
    45d4:	d350fc16 	lsr	x22, x0, #16
    45d8:	a90363f7 	stp	x23, x24, [sp, #48]
    45dc:	f949fc22 	ldr	x2, [x1, #5112]
    45e0:	8b160ad4 	add	x20, x22, x22, lsl #2
    45e4:	d37df294 	lsl	x20, x20, #3
    45e8:	ab140057 	adds	x23, x2, x20
    45ec:	540000c0 	b.eq	4604 <fwp_mem_free+0x64>  // b.none
    45f0:	38746842 	ldrb	w2, [x2, x20]
    45f4:	7100045f 	cmp	w2, #0x1
    45f8:	54000120 	b.eq	461c <fwp_mem_free+0x7c>  // b.none
    45fc:	7100085f 	cmp	w2, #0x2
    4600:	540005e0 	b.eq	46bc <fwp_mem_free+0x11c>  // b.none
    4604:	a94363f7 	ldp	x23, x24, [sp, #48]
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4614:	d65f03c0 	ret
    4618:	d65f03c0 	ret
    461c:	f94012f8 	ldr	x24, [x23, #32]
    4620:	b94006e1 	ldr	w1, [x23, #4]
    4624:	f90023f9 	str	x25, [sp, #64]
    4628:	2a0103e2 	mov	w2, w1
    462c:	394006f9 	ldrb	w25, [x23, #1]
    4630:	39400af4 	ldrb	w20, [x23, #2]
    4634:	b4000158 	cbz	x24, 465c <fwp_mem_free+0xbc>
    4638:	92403e76 	and	x22, x19, #0xffff
    463c:	9ac20ad6 	udiv	x22, x22, x2
    4640:	38766b01 	ldrb	w1, [x24, x22]
    4644:	8b160300 	add	x0, x24, x22
    4648:	7103fc3f 	cmp	w1, #0xff
    464c:	54000980 	b.eq	477c <fwp_mem_free+0x1dc>  // b.none
    4650:	38366b1f 	strb	wzr, [x24, x22]
    4654:	b94006e1 	ldr	w1, [x23, #4]
    4658:	2a0103e2 	mov	w2, w1
    465c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4660:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4664:	cb390000 	sub	x0, x0, w25, uxtb
    4668:	8b340074 	add	x20, x3, w20, uxtb
    466c:	911902b5 	add	x21, x21, #0x640
    4670:	1e630021 	ucvtf	d1, w1
    4674:	d37ae400 	lsl	x0, x0, #6
    4678:	8b140c14 	add	x20, x0, x20, lsl #3
    467c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4680:	f8746aa0 	ldr	x0, [x21, x20]
    4684:	f94023f9 	ldr	x25, [sp, #64]
    4688:	aa2003e0 	mvn	x0, x0
    468c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4690:	f9000260 	str	x0, [x19]
    4694:	f8346ab3 	str	x19, [x21, x20]
    4698:	f94a12a0 	ldr	x0, [x21, #5152]
    469c:	1e612800 	fadd	d0, d0, d1
    46a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46a4:	cb020000 	sub	x0, x0, x2
    46a8:	f90a12a0 	str	x0, [x21, #5152]
    46ac:	fd0a22a0 	str	d0, [x21, #5184]
    46b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46b8:	d65f03c0 	ret
    46bc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46c0:	8b000063 	add	x3, x3, x0
    46c4:	eb03027f 	cmp	x19, x3
    46c8:	54fff9e1 	b.ne	4604 <fwp_mem_free+0x64>  // b.any
    46cc:	fd400ae1 	ldr	d1, [x23, #16]
    46d0:	fd4a2020 	ldr	d0, [x1, #5184]
    46d4:	f9400ae0 	ldr	x0, [x23, #16]
    46d8:	7e61d821 	ucvtf	d1, d1
    46dc:	f94a1022 	ldr	x2, [x1, #5152]
    46e0:	f94012f3 	ldr	x19, [x23, #32]
    46e4:	1e612800 	fadd	d0, d0, d1
    46e8:	cb000042 	sub	x2, x2, x0
    46ec:	f90a1022 	str	x2, [x1, #5152]
    46f0:	fd0a2020 	str	d0, [x1, #5184]
    46f4:	b40000b3 	cbz	x19, 4708 <fwp_mem_free+0x168>
    46f8:	39400260 	ldrb	w0, [x19]
    46fc:	7103fc1f 	cmp	w0, #0xff
    4700:	54000380 	b.eq	4770 <fwp_mem_free+0x1d0>  // b.none
    4704:	3900027f 	strb	wzr, [x19]
    4708:	b9400ee2 	ldr	w2, [x23, #12]
    470c:	b4000142 	cbz	x2, 4734 <fwp_mem_free+0x194>
    4710:	911902a1 	add	x1, x21, #0x640
    4714:	8b160040 	add	x0, x2, x22
    4718:	8b000800 	add	x0, x0, x0, lsl #2
    471c:	f949fc21 	ldr	x1, [x1, #5112]
    4720:	8b140034 	add	x20, x1, x20
    4724:	8b000c20 	add	x0, x1, x0, lsl #3
    4728:	3802869f 	strb	wzr, [x20], #40
    472c:	eb00029f 	cmp	x20, x0
    4730:	54ffffc1 	b.ne	4728 <fwp_mem_free+0x188>  // b.any
    4734:	911902a0 	add	x0, x21, #0x640
    4738:	f94a1801 	ldr	x1, [x0, #5168]
    473c:	f949f803 	ldr	x3, [x0, #5104]
    4740:	8b020021 	add	x1, x1, x2
    4744:	f90a1801 	str	x1, [x0, #5168]
    4748:	eb16007f 	cmp	x3, x22
    474c:	54000049 	b.ls	4754 <fwp_mem_free+0x1b4>  // b.plast
    4750:	f909f816 	str	x22, [x0, #5104]
    4754:	911902b5 	add	x21, x21, #0x640
    4758:	f949f6a0 	ldr	x0, [x21, #5096]
    475c:	eb16001f 	cmp	x0, x22
    4760:	54fff529 	b.ls	4604 <fwp_mem_free+0x64>  // b.plast
    4764:	a94363f7 	ldp	x23, x24, [sp, #48]
    4768:	f909f6b6 	str	x22, [x21, #5096]
    476c:	17ffffa7 	b	4608 <fwp_mem_free+0x68>
    4770:	aa1303e0 	mov	x0, x19
    4774:	97fffef0 	bl	4334 <fwp_rc_forget_slot.part.0>
    4778:	17ffffe3 	b	4704 <fwp_mem_free+0x164>
    477c:	97fffeee 	bl	4334 <fwp_rc_forget_slot.part.0>
    4780:	17ffffb4 	b	4650 <fwp_mem_free+0xb0>

0000000000004784 <fwp_rc_wide_dup>:
    4784:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4788:	910003fd 	mov	x29, sp
    478c:	a90153f3 	stp	x19, x20, [sp, #16]
    4790:	aa0003f3 	mov	x19, x0
    4794:	ca404400 	eor	x0, x0, x0, lsr #17
    4798:	f90013f5 	str	x21, [sp, #32]
    479c:	b0000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    47a0:	ca402400 	eor	x0, x0, x0, lsr #9
    47a4:	911902a2 	add	x2, x21, #0x640
    47a8:	92401c00 	and	x0, x0, #0xff
    47ac:	910a2403 	add	x3, x0, #0x289
    47b0:	8b000c40 	add	x0, x2, x0, lsl #3
    47b4:	8b030c54 	add	x20, x2, x3, lsl #3
    47b8:	f94a2401 	ldr	x1, [x0, #5192]
    47bc:	b50000a1 	cbnz	x1, 47d0 <fwp_rc_wide_dup+0x4c>
    47c0:	14000033 	b	488c <fwp_rc_wide_dup+0x108>
    47c4:	91004034 	add	x20, x1, #0x10
    47c8:	f9400821 	ldr	x1, [x1, #16]
    47cc:	b4000241 	cbz	x1, 4814 <fwp_rc_wide_dup+0x90>
    47d0:	f9400022 	ldr	x2, [x1]
    47d4:	eb02027f 	cmp	x19, x2
    47d8:	54ffff61 	b.ne	47c4 <fwp_rc_wide_dup+0x40>  // b.any
    47dc:	f9400281 	ldr	x1, [x20]
    47e0:	39400260 	ldrb	w0, [x19]
    47e4:	7103f81f 	cmp	w0, #0xfe
    47e8:	54000220 	b.eq	482c <fwp_rc_wide_dup+0xa8>  // b.none
    47ec:	b40001a1 	cbz	x1, 4820 <fwp_rc_wide_dup+0x9c>
    47f0:	f9400420 	ldr	x0, [x1, #8]
    47f4:	b100041f 	cmn	x0, #0x1
    47f8:	54000440 	b.eq	4880 <fwp_rc_wide_dup+0xfc>  // b.none
    47fc:	91000400 	add	x0, x0, #0x1
    4800:	f9000420 	str	x0, [x1, #8]
    4804:	a94153f3 	ldp	x19, x20, [sp, #16]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	39400260 	ldrb	w0, [x19]
    4818:	7103f81f 	cmp	w0, #0xfe
    481c:	54000100 	b.eq	483c <fwp_rc_wide_dup+0xb8>  // b.none
    4820:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4824:	910ba000 	add	x0, x0, #0x2e8
    4828:	97fffea3 	bl	42b4 <fwp_trap>
    482c:	b4000081 	cbz	x1, 483c <fwp_rc_wide_dup+0xb8>
    4830:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4834:	910c4000 	add	x0, x0, #0x310
    4838:	97fffe9f 	bl	42b4 <fwp_trap>
    483c:	d2800300 	mov	x0, #0x18                  	// #24
    4840:	97fff7dc 	bl	27b0 <malloc@plt>
    4844:	b4000280 	cbz	x0, 4894 <fwp_rc_wide_dup+0x110>
    4848:	d2801fe1 	mov	x1, #0xff                  	// #255
    484c:	a9000413 	stp	x19, x1, [x0]
    4850:	911902b5 	add	x21, x21, #0x640
    4854:	f900081f 	str	xzr, [x0, #16]
    4858:	12800001 	mov	w1, #0xffffffff            	// #-1
    485c:	f9000280 	str	x0, [x20]
    4860:	39000261 	strb	w1, [x19]
    4864:	f94e26a0 	ldr	x0, [x21, #7240]
    4868:	a94153f3 	ldp	x19, x20, [sp, #16]
    486c:	91000400 	add	x0, x0, #0x1
    4870:	f90e26a0 	str	x0, [x21, #7240]
    4874:	f94013f5 	ldr	x21, [sp, #32]
    4878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    487c:	d65f03c0 	ret
    4880:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4884:	910ce000 	add	x0, x0, #0x338
    4888:	97fffe8b 	bl	42b4 <fwp_trap>
    488c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4890:	17ffffd4 	b	47e0 <fwp_rc_wide_dup+0x5c>
    4894:	97fffa17 	bl	30f0 <fwp_heap_oom>
    4898:	d503201f 	nop
    489c:	d503201f 	nop

00000000000048a0 <fwp_closure_drop_push>:
    48a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48a4:	910003fd 	mov	x29, sp
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	aa0003f3 	mov	x19, x0
    48b0:	a9408014 	ldp	x20, x0, [x0, #8]
    48b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48b8:	aa0103f5 	mov	x21, x1
    48bc:	a90363f7 	stp	x23, x24, [sp, #48]
    48c0:	eb00029f 	cmp	x20, x0
    48c4:	54000160 	b.eq	48f0 <fwp_closure_drop_push+0x50>  // b.none
    48c8:	f9400276 	ldr	x22, [x19]
    48cc:	d37df297 	lsl	x23, x20, #3
    48d0:	91000694 	add	x20, x20, #0x1
    48d4:	f9000674 	str	x20, [x19, #8]
    48d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48dc:	f8376ad5 	str	x21, [x22, x23]
    48e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48e8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48ec:	d65f03c0 	ret
    48f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    48f4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    48f8:	eb00029f 	cmp	x20, x0
    48fc:	540003e8 	b.hi	4978 <fwp_closure_drop_push+0xd8>  // b.pmore
    4900:	d37cee99 	lsl	x25, x20, #4
    4904:	d37ffa9a 	lsl	x26, x20, #1
    4908:	aa1903e0 	mov	x0, x25
    490c:	97fff7a9 	bl	27b0 <malloc@plt>
    4910:	aa0003f6 	mov	x22, x0
    4914:	b4000380 	cbz	x0, 4984 <fwp_closure_drop_push+0xe4>
    4918:	aa1303f8 	mov	x24, x19
    491c:	aa1903e3 	mov	x3, x25
    4920:	d37df297 	lsl	x23, x20, #3
    4924:	aa1703e2 	mov	x2, x23
    4928:	f8418719 	ldr	x25, [x24], #24
    492c:	aa1903e1 	mov	x1, x25
    4930:	97fff78c 	bl	2760 <__memcpy_chk@plt>
    4934:	eb18033f 	cmp	x25, x24
    4938:	540000a0 	b.eq	494c <fwp_closure_drop_push+0xac>  // b.none
    493c:	aa1903e0 	mov	x0, x25
    4940:	97fff7e4 	bl	28d0 <free@plt>
    4944:	f9400674 	ldr	x20, [x19, #8]
    4948:	d37df297 	lsl	x23, x20, #3
    494c:	91000694 	add	x20, x20, #0x1
    4950:	f9000276 	str	x22, [x19]
    4954:	f9000a7a 	str	x26, [x19, #16]
    4958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    495c:	f9000674 	str	x20, [x19, #8]
    4960:	f8376ad5 	str	x21, [x22, x23]
    4964:	a94153f3 	ldp	x19, x20, [sp, #16]
    4968:	a9425bf5 	ldp	x21, x22, [sp, #32]
    496c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4970:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4974:	d65f03c0 	ret
    4978:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    497c:	910d6000 	add	x0, x0, #0x358
    4980:	97fffe4d 	bl	42b4 <fwp_trap>
    4984:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    4988:	f947e863 	ldr	x3, [x3, #4048]
    498c:	d2800262 	mov	x2, #0x13                  	// #19
    4990:	d2800021 	mov	x1, #0x1                   	// #1
    4994:	b0000040 	adrp	x0, d000 <f0+0x2390>
    4998:	913e6000 	add	x0, x0, #0xf98
    499c:	f9400063 	ldr	x3, [x3]
    49a0:	97fff7dc 	bl	2910 <fwrite@plt>
    49a4:	d2800000 	mov	x0, #0x0                   	// #0
    49a8:	97fff7e6 	bl	2940 <fflush@plt>
    49ac:	52800cc0 	mov	w0, #0x66                  	// #102
    49b0:	97fff7f4 	bl	2980 <_Exit@plt>

00000000000049b4 <fwp_closure_drop.part.0>:
    49b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49b8:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x70>
    49bc:	910003fd 	mov	x29, sp
    49c0:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    49c4:	f947f463 	ldr	x3, [x3, #4072]
    49c8:	a90153f3 	stp	x19, x20, [sp, #16]
    49cc:	d10883ff 	sub	sp, sp, #0x220
    49d0:	910003e2 	mov	x2, sp
    49d4:	d53bd053 	mrs	x19, tpidr_el0
    49d8:	910063f4 	add	x20, sp, #0x18
    49dc:	3dc3d020 	ldr	q0, [x1, #3904]
    49e0:	91400264 	add	x4, x19, #0x0, lsl #12
    49e4:	91004084 	add	x4, x4, #0x10
    49e8:	aa0003e1 	mov	x1, x0
    49ec:	aa0203e0 	mov	x0, x2
    49f0:	f9400062 	ldr	x2, [x3]
    49f4:	f9010fe2 	str	x2, [sp, #536]
    49f8:	d2800002 	mov	x2, #0x0                   	// #0
    49fc:	f90003f4 	str	x20, [sp]
    4a00:	f9000080 	str	x0, [x4]
    4a04:	3c8083e0 	stur	q0, [sp, #8]
    4a08:	97ffffa6 	bl	48a0 <fwp_closure_drop_push>
    4a0c:	f94007e0 	ldr	x0, [sp, #8]
    4a10:	b40002e0 	cbz	x0, 4a6c <fwp_closure_drop.part.0+0xb8>
    4a14:	f90123f5 	str	x21, [sp, #576]
    4a18:	90000175 	adrp	x21, 30000 <__data_start>
    4a1c:	910182b5 	add	x21, x21, #0x60
    4a20:	14000006 	b	4a38 <fwp_closure_drop.part.0+0x84>
    4a24:	f9400422 	ldr	x2, [x1, #8]
    4a28:	52800001 	mov	w1, #0x0                   	// #0
    4a2c:	d63f0040 	blr	x2
    4a30:	f94007e0 	ldr	x0, [sp, #8]
    4a34:	b40001a0 	cbz	x0, 4a68 <fwp_closure_drop.part.0+0xb4>
    4a38:	f94003e1 	ldr	x1, [sp]
    4a3c:	d1000400 	sub	x0, x0, #0x1
    4a40:	f90007e0 	str	x0, [sp, #8]
    4a44:	f9408ea2 	ldr	x2, [x21, #280]
    4a48:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a4c:	b9400001 	ldr	w1, [x0]
    4a50:	8b011441 	add	x1, x2, x1, lsl #5
    4a54:	f9400c21 	ldr	x1, [x1, #24]
    4a58:	b5fffe61 	cbnz	x1, 4a24 <fwp_closure_drop.part.0+0x70>
    4a5c:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4a60:	910de000 	add	x0, x0, #0x378
    4a64:	97fffe14 	bl	42b4 <fwp_trap>
    4a68:	f94123f5 	ldr	x21, [sp, #576]
    4a6c:	91400273 	add	x19, x19, #0x0, lsl #12
    4a70:	91004273 	add	x19, x19, #0x10
    4a74:	f94003e0 	ldr	x0, [sp]
    4a78:	f900027f 	str	xzr, [x19]
    4a7c:	eb14001f 	cmp	x0, x20
    4a80:	54000040 	b.eq	4a88 <fwp_closure_drop.part.0+0xd4>  // b.none
    4a84:	97fff793 	bl	28d0 <free@plt>
    4a88:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4a8c:	f947f400 	ldr	x0, [x0, #4072]
    4a90:	f9410fe2 	ldr	x2, [sp, #536]
    4a94:	f9400001 	ldr	x1, [x0]
    4a98:	eb010042 	subs	x2, x2, x1
    4a9c:	d2800001 	mov	x1, #0x0                   	// #0
    4aa0:	540000a1 	b.ne	4ab4 <fwp_closure_drop.part.0+0x100>  // b.any
    4aa4:	910883ff 	add	sp, sp, #0x220
    4aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ab0:	d65f03c0 	ret
    4ab4:	f90123f5 	str	x21, [sp, #576]
    4ab8:	97fff756 	bl	2810 <__stack_chk_fail@plt>
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_tape_of>:
    4ac0:	aa0003e1 	mov	x1, x0
    4ac4:	92403c00 	and	x0, x0, #0xffff
    4ac8:	b40000e0 	cbz	x0, 4ae4 <fwp_tape_of+0x24>
    4acc:	d1000402 	sub	x2, x0, #0x1
    4ad0:	90000160 	adrp	x0, 30000 <__data_start>
    4ad4:	91018000 	add	x0, x0, #0x60
    4ad8:	f9409003 	ldr	x3, [x0, #288]
    4adc:	eb02007f 	cmp	x3, x2
    4ae0:	540000cc 	b.gt	4af8 <fwp_tape_of+0x38>
    4ae4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4ae8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4aec:	910ea000 	add	x0, x0, #0x3a8
    4af0:	910003fd 	mov	x29, sp
    4af4:	97fffdf0 	bl	42b4 <fwp_trap>
    4af8:	8b020443 	add	x3, x2, x2, lsl #1
    4afc:	f9404404 	ldr	x4, [x0, #136]
    4b00:	8b030842 	add	x2, x2, x3, lsl #2
    4b04:	d37df042 	lsl	x2, x2, #3
    4b08:	8b020080 	add	x0, x4, x2
    4b0c:	b9400403 	ldr	w3, [x0, #4]
    4b10:	34fffea3 	cbz	w3, 4ae4 <fwp_tape_of+0x24>
    4b14:	b8626882 	ldr	w2, [x4, x2]
    4b18:	9350fc21 	asr	x1, x1, #16
    4b1c:	6b01005f 	cmp	w2, w1
    4b20:	54fffe21 	b.ne	4ae4 <fwp_tape_of+0x24>  // b.any
    4b24:	d65f03c0 	ret
    4b28:	d503201f 	nop
    4b2c:	d503201f 	nop

0000000000004b30 <fwp_now_ns>:
    4b30:	d100c3ff 	sub	sp, sp, #0x30
    4b34:	52800020 	mov	w0, #0x1                   	// #1
    4b38:	f0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    4b3c:	f947f442 	ldr	x2, [x2, #4072]
    4b40:	910023e1 	add	x1, sp, #0x8
    4b44:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b48:	910083fd 	add	x29, sp, #0x20
    4b4c:	f9400043 	ldr	x3, [x2]
    4b50:	f9000fe3 	str	x3, [sp, #24]
    4b54:	d2800003 	mov	x3, #0x0                   	// #0
    4b58:	97fff6fa 	bl	2740 <clock_gettime@plt>
    4b5c:	350002c0 	cbnz	w0, 4bb4 <fwp_now_ns+0x84>
    4b60:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b64:	d2994003 	mov	x3, #0xca00                	// #51712
    4b68:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b6c:	9b037c20 	mul	x0, x1, x3
    4b70:	9b437c21 	smulh	x1, x1, x3
    4b74:	ab020000 	adds	x0, x0, x2
    4b78:	937ffc42 	asr	x2, x2, #63
    4b7c:	9a020021 	adc	x1, x1, x2
    4b80:	f100001f 	cmp	x0, #0x0
    4b84:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4b88:	b50001c1 	cbnz	x1, 4bc0 <fwp_now_ns+0x90>
    4b8c:	f0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    4b90:	f947f421 	ldr	x1, [x1, #4072]
    4b94:	f9400fe3 	ldr	x3, [sp, #24]
    4b98:	f9400022 	ldr	x2, [x1]
    4b9c:	eb020063 	subs	x3, x3, x2
    4ba0:	d2800002 	mov	x2, #0x0                   	// #0
    4ba4:	54000141 	b.ne	4bcc <fwp_now_ns+0x9c>  // b.any
    4ba8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bac:	9100c3ff 	add	sp, sp, #0x30
    4bb0:	d65f03c0 	ret
    4bb4:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4bb8:	910fe000 	add	x0, x0, #0x3f8
    4bbc:	97fffdbe 	bl	42b4 <fwp_trap>
    4bc0:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4bc4:	91106000 	add	x0, x0, #0x418
    4bc8:	97fffdbb 	bl	42b4 <fwp_trap>
    4bcc:	97fff711 	bl	2810 <__stack_chk_fail@plt>

0000000000004bd0 <fwp_poll_events>:
    4bd0:	d10103ff 	sub	sp, sp, #0x40
    4bd4:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4bd8:	f947f400 	ldr	x0, [x0, #4072]
    4bdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4be0:	910083fd 	add	x29, sp, #0x20
    4be4:	f9001bf3 	str	x19, [sp, #48]
    4be8:	90000173 	adrp	x19, 30000 <__data_start>
    4bec:	f9400001 	ldr	x1, [x0]
    4bf0:	f9000fe1 	str	x1, [sp, #24]
    4bf4:	d2800001 	mov	x1, #0x0                   	// #0
    4bf8:	97ffffce 	bl	4b30 <fwp_now_ns>
    4bfc:	91018261 	add	x1, x19, #0x60
    4c00:	f9409421 	ldr	x1, [x1, #296]
    4c04:	b4000e01 	cbz	x1, 4dc4 <fwp_poll_events+0x1f4>
    4c08:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c0c:	14000005 	b	4c20 <fwp_poll_events+0x50>
    4c10:	f9408821 	ldr	x1, [x1, #272]
    4c14:	eb03005f 	cmp	x2, x3
    4c18:	9a83d042 	csel	x2, x2, x3, le
    4c1c:	b40000c1 	cbz	x1, 4c34 <fwp_poll_events+0x64>
    4c20:	f9403423 	ldr	x3, [x1, #104]
    4c24:	b6ffff62 	tbz	x2, #63, 4c10 <fwp_poll_events+0x40>
    4c28:	f9408821 	ldr	x1, [x1, #272]
    4c2c:	aa0303e2 	mov	x2, x3
    4c30:	b5ffff81 	cbnz	x1, 4c20 <fwp_poll_events+0x50>
    4c34:	b7f80c82 	tbnz	x2, #63, 4dc4 <fwp_poll_events+0x1f4>
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f100005f 	cmp	x2, #0x0
    4c40:	540003ad 	b.le	4cb4 <fwp_poll_events+0xe4>
    4c44:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c48:	d2884804 	mov	x4, #0x4240                	// #16960
    4c4c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c50:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c54:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c58:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c5c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c60:	9b407c40 	smulh	x0, x2, x0
    4c64:	9352fc00 	asr	x0, x0, #18
    4c68:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c6c:	9b048802 	msub	x2, x0, x4, x2
    4c70:	f100005f 	cmp	x2, #0x0
    4c74:	9a800400 	cinc	x0, x0, ne	// ne = any
    4c78:	eb01001f 	cmp	x0, x1
    4c7c:	5400098c 	b.gt	4dac <fwp_poll_events+0x1dc>
    4c80:	340001a0 	cbz	w0, 4cb4 <fwp_poll_events+0xe4>
    4c84:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4c88:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4c8c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4c90:	9ba17c01 	umull	x1, w0, w1
    4c94:	d366fc23 	lsr	x3, x1, #38
    4c98:	aa0303e2 	mov	x2, x3
    4c9c:	1b058063 	msub	w3, w3, w5, w0
    4ca0:	9b247c63 	smull	x3, w3, w4
    4ca4:	910023e0 	add	x0, sp, #0x8
    4ca8:	d2800001 	mov	x1, #0x0                   	// #0
    4cac:	a9008fe2 	stp	x2, x3, [sp, #8]
    4cb0:	97fff70c 	bl	28e0 <nanosleep@plt>
    4cb4:	97ffff9f 	bl	4b30 <fwp_now_ns>
    4cb8:	91018268 	add	x8, x19, #0x60
    4cbc:	aa0003e7 	mov	x7, x0
    4cc0:	4f000400 	movi	v0.4s, #0x0
    4cc4:	52800029 	mov	w9, #0x1                   	// #1
    4cc8:	f9409506 	ldr	x6, [x8, #296]
    4ccc:	d503201f 	nop
    4cd0:	b40003e6 	cbz	x6, 4d4c <fwp_poll_events+0x17c>
    4cd4:	f94034c1 	ldr	x1, [x6, #104]
    4cd8:	aa0603e5 	mov	x5, x6
    4cdc:	f94088c6 	ldr	x6, [x6, #272]
    4ce0:	eb07003f 	cmp	x1, x7
    4ce4:	54ffff6c 	b.gt	4cd0 <fwp_poll_events+0x100>
    4ce8:	394154a0 	ldrb	w0, [x5, #85]
    4cec:	36000120 	tbz	w0, #0, 4d10 <fwp_poll_events+0x140>
    4cf0:	f94084a0 	ldr	x0, [x5, #264]
    4cf4:	b4000560 	cbz	x0, 4da0 <fwp_poll_events+0x1d0>
    4cf8:	f9008806 	str	x6, [x0, #272]
    4cfc:	b4000046 	cbz	x6, 4d04 <fwp_poll_events+0x134>
    4d00:	f90084c0 	str	x0, [x6, #264]
    4d04:	910800a0 	add	x0, x5, #0x200
    4d08:	390154bf 	strb	wzr, [x5, #85]
    4d0c:	3c908000 	stur	q0, [x0, #-248]
    4d10:	f94030a0 	ldr	x0, [x5, #96]
    4d14:	390158a9 	strb	w9, [x5, #86]
    4d18:	f100001f 	cmp	x0, #0x0
    4d1c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d20:	540002cd 	b.le	4d78 <fwp_poll_events+0x1a8>
    4d24:	f94028a0 	ldr	x0, [x5, #80]
    4d28:	f2001c1f 	tst	x0, #0xff000000ff
    4d2c:	54fffd21 	b.ne	4cd0 <fwp_poll_events+0x100>  // b.any
    4d30:	f9406100 	ldr	x0, [x8, #192]
    4d34:	390150a9 	strb	w9, [x5, #84]
    4d38:	f90080bf 	str	xzr, [x5, #256]
    4d3c:	b40002c0 	cbz	x0, 4d94 <fwp_poll_events+0x1c4>
    4d40:	f9006105 	str	x5, [x8, #192]
    4d44:	f9008005 	str	x5, [x0, #256]
    4d48:	b5fffc66 	cbnz	x6, 4cd4 <fwp_poll_events+0x104>
    4d4c:	f0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    4d50:	f947f400 	ldr	x0, [x0, #4072]
    4d54:	f9400fe2 	ldr	x2, [sp, #24]
    4d58:	f9400001 	ldr	x1, [x0]
    4d5c:	eb010042 	subs	x2, x2, x1
    4d60:	d2800001 	mov	x1, #0x0                   	// #0
    4d64:	540002e1 	b.ne	4dc0 <fwp_poll_events+0x1f0>  // b.any
    4d68:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d6c:	f9401bf3 	ldr	x19, [sp, #48]
    4d70:	910103ff 	add	sp, sp, #0x40
    4d74:	d65f03c0 	ret
    4d78:	394144a0 	ldrb	w0, [x5, #81]
    4d7c:	3707fd40 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d80:	394140a0 	ldrb	w0, [x5, #80]
    4d84:	3707fd00 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d88:	aa0503e0 	mov	x0, x5
    4d8c:	97fffa39 	bl	3670 <fwp_cancel_tree.part.0>
    4d90:	17ffffe5 	b	4d24 <fwp_poll_events+0x154>
    4d94:	f9006105 	str	x5, [x8, #192]
    4d98:	f9006505 	str	x5, [x8, #200]
    4d9c:	17ffffeb 	b	4d48 <fwp_poll_events+0x178>
    4da0:	91018261 	add	x1, x19, #0x60
    4da4:	f9009426 	str	x6, [x1, #296]
    4da8:	17ffffd5 	b	4cfc <fwp_poll_events+0x12c>
    4dac:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4db0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4db4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4db8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dbc:	17ffffba 	b	4ca4 <fwp_poll_events+0xd4>
    4dc0:	97fff694 	bl	2810 <__stack_chk_fail@plt>
    4dc4:	97fff88c 	bl	2ff4 <fwp_flush>
    4dc8:	f0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    4dcc:	f947e863 	ldr	x3, [x3, #4048]
    4dd0:	d2800562 	mov	x2, #0x2b                  	// #43
    4dd4:	d2800021 	mov	x1, #0x1                   	// #1
    4dd8:	d0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    4ddc:	91110000 	add	x0, x0, #0x440
    4de0:	f9400063 	ldr	x3, [x3]
    4de4:	97fff6cb 	bl	2910 <fwrite@plt>
    4de8:	52800ca0 	mov	w0, #0x65                  	// #101
    4dec:	97fff635 	bl	26c0 <exit@plt>

0000000000004df0 <fwp_heap_alloc_big>:
    4df0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df4:	910003fd 	mov	x29, sp
    4df8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e00:	a90363f7 	stp	x23, x24, [sp, #48]
    4e04:	aa0003f7 	mov	x23, x0
    4e08:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e0c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e10:	eb0002ff 	cmp	x23, x0
    4e14:	540008a8 	b.hi	4f28 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e18:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e1c:	8b0002f4 	add	x20, x23, x0
    4e20:	b000043a 	adrp	x26, 89000 <fwp_root_context+0xba0>
    4e24:	91190359 	add	x25, x26, #0x640
    4e28:	d350fe94 	lsr	x20, x20, #16
    4e2c:	2a0103f5 	mov	w21, w1
    4e30:	aa1403e0 	mov	x0, x20
    4e34:	97fff8bf 	bl	3130 <fwp_heap_chunks>
    4e38:	f949ff22 	ldr	x2, [x25, #5112]
    4e3c:	8b000813 	add	x19, x0, x0, lsl #2
    4e40:	aa0003f8 	mov	x24, x0
    4e44:	52800043 	mov	w3, #0x2                   	// #2
    4e48:	d37df273 	lsl	x19, x19, #3
    4e4c:	d2800021 	mov	x1, #0x1                   	// #1
    4e50:	8b130040 	add	x0, x2, x19
    4e54:	38336843 	strb	w3, [x2, x19]
    4e58:	39000415 	strb	w21, [x0, #1]
    4e5c:	b9000c14 	str	w20, [x0, #12]
    4e60:	f9000817 	str	x23, [x0, #16]
    4e64:	97fffd57 	bl	43c0 <fwp_rc_prepare_chunk>
    4e68:	f100069f 	cmp	x20, #0x1
    4e6c:	54000289 	b.ls	4ebc <fwp_heap_alloc_big+0xcc>  // b.plast
    4e70:	8b180294 	add	x20, x20, x24
    4e74:	9100a273 	add	x19, x19, #0x28
    4e78:	a90573fb 	stp	x27, x28, [sp, #80]
    4e7c:	5280007b 	mov	w27, #0x3                   	// #3
    4e80:	8b140a94 	add	x20, x20, x20, lsl #2
    4e84:	2a1803fc 	mov	w28, w24
    4e88:	9adb2296 	lsl	x22, x20, x27
    4e8c:	d503201f 	nop
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffd48 	bl	43c0 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0xa0>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b0000433 	adrp	x19, 89000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffb37 	bl	3cf0 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff6f 	b	4df0 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffd19 	bl	44e0 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f0000156 	adrp	x22, 30000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	540008a1 	b.ne	51cc <fwp_heap_alloc+0x13c>  // b.any
    50bc:	90000437 	adrp	x23, 89000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	54000722 	b.cs	5218 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	5400030c 	b.gt	51e0 <fwp_heap_alloc+0x150>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000249 	b.ls	51fc <fwp_heap_alloc+0x16c>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	910182c1 	add	x1, x22, #0x60
    51c4:	b9413038 	ldr	w24, [x1, #304]
    51c8:	17ffffe6 	b	5160 <fwp_heap_alloc+0xd0>
    51cc:	a9538c44 	ldp	x4, x3, [x2, #312]
    51d0:	91000484 	add	x4, x4, #0x1
    51d4:	8b000063 	add	x3, x3, x0
    51d8:	a9138c44 	stp	x4, x3, [x2, #312]
    51dc:	17ffffb8 	b	50bc <fwp_heap_alloc+0x2c>
    51e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51e4:	fd00a800 	str	d0, [x0, #336]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	aa0403e0 	mov	x0, x4
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f8:	d65f03c0 	ret
    51fc:	7100043f 	cmp	w1, #0x1
    5200:	8b140085 	add	x5, x4, x20
    5204:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5208:	52800001 	mov	w1, #0x0                   	// #0
    520c:	aa0403e0 	mov	x0, x4
    5210:	f9000465 	str	x5, [x3, #8]
    5214:	17ffffc4 	b	5124 <fwp_heap_alloc+0x94>
    5218:	97fff7b6 	bl	30f0 <fwp_heap_oom>
    521c:	d503201f 	nop

0000000000005220 <fwp_apply>:
    5220:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5224:	aa0003e6 	mov	x6, x0
    5228:	910003fd 	mov	x29, sp
    522c:	d0000143 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    5230:	f947f463 	ldr	x3, [x3, #4072]
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	aa0203f4 	mov	x20, x2
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	2a0103f5 	mov	w21, w1
    5244:	52800033 	mov	w19, #0x1                   	// #1
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	f0000157 	adrp	x23, 30000 <__data_start>
    5250:	910182f7 	add	x23, x23, #0x60
    5254:	a9046bf9 	stp	x25, x26, [sp, #64]
    5258:	d100c3ff 	sub	sp, sp, #0x30
    525c:	f9400060 	ldr	x0, [x3]
    5260:	f81f83a0 	stur	x0, [x29, #-8]
    5264:	d2800000 	mov	x0, #0x0                   	// #0
    5268:	294058c3 	ldp	w3, w22, [x6]
    526c:	910003f8 	mov	x24, sp
    5270:	f9408ee0 	ldr	x0, [x23, #280]
    5274:	710002df 	cmp	w22, #0x0
    5278:	d37be863 	lsl	x3, x3, #5
    527c:	8b030007 	add	x7, x0, x3
    5280:	b8636819 	ldr	w25, [x0, x3]
    5284:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    5288:	54000163 	b.cc	52b4 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    528c:	f94004e3 	ldr	x3, [x7, #8]
    5290:	34000bb9 	cbz	w25, 5404 <fwp_apply+0x1e4>
    5294:	aa1403e0 	mov	x0, x20
    5298:	d63f0060 	blr	x3
    529c:	aa0003e6 	mov	x6, x0
    52a0:	6b1902bf 	cmp	w21, w25
    52a4:	54000920 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    52a8:	8b394e94 	add	x20, x20, w25, uxtw #3
    52ac:	4b1902b5 	sub	w21, w21, w25
    52b0:	17ffffee 	b	5268 <fwp_apply+0x48>
    52b4:	0b1602ba 	add	w26, w21, w22
    52b8:	6b19035f 	cmp	w26, w25
    52bc:	54000523 	b.cc	5360 <fwp_apply+0x140>  // b.lo, b.ul, b.last
    52c0:	7100033f 	cmp	w25, #0x0
    52c4:	4b16033a 	sub	w26, w25, w22
    52c8:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52cc:	d37df000 	lsl	x0, x0, #3
    52d0:	91003c00 	add	x0, x0, #0xf
    52d4:	92704c01 	and	x1, x0, #0xfffff0000
    52d8:	927c7c00 	and	x0, x0, #0xffffffff0
    52dc:	cb2163e1 	sub	x1, sp, x1
    52e0:	eb2163ff 	cmp	sp, x1
    52e4:	540000a0 	b.eq	52f8 <fwp_apply+0xd8>  // b.none
    52e8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52ec:	f90203ff 	str	xzr, [sp, #1024]
    52f0:	eb2163ff 	cmp	sp, x1
    52f4:	54ffffa1 	b.ne	52e8 <fwp_apply+0xc8>  // b.any
    52f8:	92403c00 	and	x0, x0, #0xffff
    52fc:	cb2063ff 	sub	sp, sp, x0
    5300:	f90003ff 	str	xzr, [sp]
    5304:	f110001f 	cmp	x0, #0x400
    5308:	54000942 	b.cs	5430 <fwp_apply+0x210>  // b.hs, b.nlast
    530c:	910020c6 	add	x6, x6, #0x8
    5310:	910043e0 	add	x0, sp, #0x10
    5314:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    5318:	d2800003 	mov	x3, #0x0                   	// #0
    531c:	340000d6 	cbz	w22, 5334 <fwp_apply+0x114>
    5320:	f86368c4 	ldr	x4, [x6, x3]
    5324:	f8236804 	str	x4, [x0, x3]
    5328:	91002063 	add	x3, x3, #0x8
    532c:	eb0300bf 	cmp	x5, x3
    5330:	54ffff81 	b.ne	5320 <fwp_apply+0x100>  // b.any
    5334:	3400013a 	cbz	w26, 5358 <fwp_apply+0x138>
    5338:	2a1a03e6 	mov	w6, w26
    533c:	d2800003 	mov	x3, #0x0                   	// #0
    5340:	0b0302c4 	add	w4, w22, w3
    5344:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5348:	91000463 	add	x3, x3, #0x1
    534c:	f8247805 	str	x5, [x0, x4, lsl #3]
    5350:	eb0300df 	cmp	x6, x3
    5354:	54ffff61 	b.ne	5340 <fwp_apply+0x120>  // b.any
    5358:	f94004e3 	ldr	x3, [x7, #8]
    535c:	1400002c 	b	540c <fwp_apply+0x1ec>
    5360:	11000740 	add	w0, w26, #0x1
    5364:	52800041 	mov	w1, #0x2                   	// #2
    5368:	f81e83a6 	stur	x6, [x29, #-24]
    536c:	d37df000 	lsl	x0, x0, #3
    5370:	97ffff48 	bl	5090 <fwp_heap_alloc>
    5374:	f85e83a6 	ldur	x6, [x29, #-24]
    5378:	aa0003f3 	mov	x19, x0
    537c:	b94000c1 	ldr	w1, [x6]
    5380:	29006801 	stp	w1, w26, [x0]
    5384:	340000b6 	cbz	w22, 5398 <fwp_apply+0x178>
    5388:	910020c1 	add	x1, x6, #0x8
    538c:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5390:	91002000 	add	x0, x0, #0x8
    5394:	97fff4bb 	bl	2680 <memmove@plt>
    5398:	2a1503e3 	mov	w3, w21
    539c:	d2800000 	mov	x0, #0x0                   	// #0
    53a0:	34000135 	cbz	w21, 53c4 <fwp_apply+0x1a4>
    53a4:	d503201f 	nop
    53a8:	0b0002c1 	add	w1, w22, w0
    53ac:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53b0:	8b010e61 	add	x1, x19, x1, lsl #3
    53b4:	91000400 	add	x0, x0, #0x1
    53b8:	f9000422 	str	x2, [x1, #8]
    53bc:	eb00007f 	cmp	x3, x0
    53c0:	54ffff41 	b.ne	53a8 <fwp_apply+0x188>  // b.any
    53c4:	aa1303e6 	mov	x6, x19
    53c8:	d0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    53cc:	f947f400 	ldr	x0, [x0, #4072]
    53d0:	f85f83a2 	ldur	x2, [x29, #-8]
    53d4:	f9400001 	ldr	x1, [x0]
    53d8:	eb010042 	subs	x2, x2, x1
    53dc:	d2800001 	mov	x1, #0x0                   	// #0
    53e0:	540002c1 	b.ne	5438 <fwp_apply+0x218>  // b.any
    53e4:	910003bf 	mov	sp, x29
    53e8:	aa0603e0 	mov	x0, x6
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	d10043a0 	sub	x0, x29, #0x10
    5408:	5280001a 	mov	w26, #0x0                   	// #0
    540c:	d63f0060 	blr	x3
    5410:	aa0003e6 	mov	x6, x0
    5414:	6b1a02bf 	cmp	w21, w26
    5418:	54fffd80 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    541c:	0b1602b6 	add	w22, w21, w22
    5420:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    5424:	4b1902d5 	sub	w21, w22, w25
    5428:	9100031f 	mov	sp, x24
    542c:	17ffff8f 	b	5268 <fwp_apply+0x48>
    5430:	f90203ff 	str	xzr, [sp, #1024]
    5434:	17ffffb6 	b	530c <fwp_apply+0xec>
    5438:	97fff4f6 	bl	2810 <__stack_chk_fail@plt>
    543c:	d503201f 	nop

0000000000005440 <fwp_tape_grow.constprop.0>:
    5440:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5444:	d2800803 	mov	x3, #0x40                  	// #64
    5448:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    544c:	910003fd 	mov	x29, sp
    5450:	a90153f3 	stp	x19, x20, [sp, #16]
    5454:	f9400c13 	ldr	x19, [x0, #24]
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0003f7 	mov	x23, x0
    5460:	f100027f 	cmp	x19, #0x0
    5464:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    5468:	eb13003f 	cmp	x1, x19
    546c:	540000ed 	b.le	5488 <fwp_tape_grow.constprop.0+0x48>
    5470:	eb02027f 	cmp	x19, x2
    5474:	5400078d 	b.le	5564 <fwp_tape_grow.constprop.0+0x124>
    5478:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    547c:	eb13003f 	cmp	x1, x19
    5480:	5400004d 	b.le	5488 <fwp_tape_grow.constprop.0+0x48>
    5484:	14000000 	b	5484 <fwp_tape_grow.constprop.0+0x44>
    5488:	a940d2e3 	ldp	x3, x20, [x23, #8]
    548c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5490:	d37df276 	lsl	x22, x19, #3
    5494:	f94012e0 	ldr	x0, [x23, #32]
    5498:	aa1603e1 	mov	x1, x22
    549c:	f94032f5 	ldr	x21, [x23, #96]
    54a0:	cb030294 	sub	x20, x20, x3
    54a4:	52800022 	mov	w2, #0x1                   	// #1
    54a8:	97fffae7 	bl	4044 <ad_raw_realloc>
    54ac:	b4000bc0 	cbz	x0, 5624 <fwp_tape_grow.constprop.0+0x1e4>
    54b0:	f9400ee1 	ldr	x1, [x23, #24]
    54b4:	8b010801 	add	x1, x0, x1, lsl #2
    54b8:	a90206e0 	stp	x0, x1, [x23, #32]
    54bc:	b4000835 	cbz	x21, 55c0 <fwp_tape_grow.constprop.0+0x180>
    54c0:	f94032b6 	ldr	x22, [x21, #96]
    54c4:	eb1302df 	cmp	x22, x19
    54c8:	540003aa 	b.ge	553c <fwp_tape_grow.constprop.0+0xfc>  // b.tcont
    54cc:	a9046bf9 	stp	x25, x26, [sp, #64]
    54d0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    54d4:	eb00027f 	cmp	x19, x0
    54d8:	54000a08 	b.hi	5618 <fwp_tape_grow.constprop.0+0x1d8>  // b.pmore
    54dc:	f94022b9 	ldr	x25, [x21, #64]
    54e0:	d37cee7a 	lsl	x26, x19, #4
    54e4:	aa1a03e0 	mov	x0, x26
    54e8:	52800041 	mov	w1, #0x2                   	// #2
    54ec:	97fffee9 	bl	5090 <fwp_heap_alloc>
    54f0:	aa0003f8 	mov	x24, x0
    54f4:	b4000119 	cbz	x25, 5514 <fwp_tape_grow.constprop.0+0xd4>
    54f8:	d37ceed6 	lsl	x22, x22, #4
    54fc:	aa1903e1 	mov	x1, x25
    5500:	eb1a02df 	cmp	x22, x26
    5504:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    5508:	97fff456 	bl	2660 <memcpy@plt>
    550c:	aa1903e0 	mov	x0, x25
    5510:	97fffc24 	bl	45a0 <fwp_mem_free>
    5514:	f94032a0 	ldr	x0, [x21, #96]
    5518:	52800001 	mov	w1, #0x0                   	// #0
    551c:	cb000262 	sub	x2, x19, x0
    5520:	8b001300 	add	x0, x24, x0, lsl #4
    5524:	d37cec42 	lsl	x2, x2, #4
    5528:	97fff4ae 	bl	27e0 <memset@plt>
    552c:	f94012e0 	ldr	x0, [x23, #32]
    5530:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5534:	f90022b8 	str	x24, [x21, #64]
    5538:	f90032b3 	str	x19, [x21, #96]
    553c:	d37ef675 	lsl	x21, x19, #2
    5540:	b5000254 	cbnz	x20, 5588 <fwp_tape_grow.constprop.0+0x148>
    5544:	8b150001 	add	x1, x0, x21
    5548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    554c:	f9000ef3 	str	x19, [x23, #24]
    5550:	f90016e1 	str	x1, [x23, #40]
    5554:	a94153f3 	ldp	x19, x20, [sp, #16]
    5558:	a94363f7 	ldp	x23, x24, [sp, #48]
    555c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5560:	d65f03c0 	ret
    5564:	d37ffa73 	lsl	x19, x19, #1
    5568:	17ffffc0 	b	5468 <fwp_tape_grow.constprop.0+0x28>
    556c:	aa0303e0 	mov	x0, x3
    5570:	d37df282 	lsl	x2, x20, #3
    5574:	97fff443 	bl	2680 <memmove@plt>
    5578:	f9401ae1 	ldr	x1, [x23, #48]
    557c:	f94012e0 	ldr	x0, [x23, #32]
    5580:	8b160021 	add	x1, x1, x22
    5584:	f9001ee1 	str	x1, [x23, #56]
    5588:	f94016e1 	ldr	x1, [x23, #40]
    558c:	d37ef675 	lsl	x21, x19, #2
    5590:	d37ef682 	lsl	x2, x20, #2
    5594:	8b150000 	add	x0, x0, x21
    5598:	97fff43a 	bl	2680 <memmove@plt>
    559c:	f94012e0 	ldr	x0, [x23, #32]
    55a0:	8b150001 	add	x1, x0, x21
    55a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55a8:	f9000ef3 	str	x19, [x23, #24]
    55ac:	f90016e1 	str	x1, [x23, #40]
    55b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    55b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    55b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55bc:	d65f03c0 	ret
    55c0:	f9401ae0 	ldr	x0, [x23, #48]
    55c4:	d37cee61 	lsl	x1, x19, #4
    55c8:	52800042 	mov	w2, #0x2                   	// #2
    55cc:	97fffa9e 	bl	4044 <ad_raw_realloc>
    55d0:	b40002a0 	cbz	x0, 5624 <fwp_tape_grow.constprop.0+0x1e4>
    55d4:	f9400ee2 	ldr	x2, [x23, #24]
    55d8:	f9001ae0 	str	x0, [x23, #48]
    55dc:	8b160003 	add	x3, x0, x22
    55e0:	8b020c01 	add	x1, x0, x2, lsl #3
    55e4:	f9001ee1 	str	x1, [x23, #56]
    55e8:	b5fffc34 	cbnz	x20, 556c <fwp_tape_grow.constprop.0+0x12c>
    55ec:	f94012e0 	ldr	x0, [x23, #32]
    55f0:	d37ef675 	lsl	x21, x19, #2
    55f4:	f9001ee3 	str	x3, [x23, #56]
    55f8:	8b150001 	add	x1, x0, x21
    55fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5600:	f9000ef3 	str	x19, [x23, #24]
    5604:	f90016e1 	str	x1, [x23, #40]
    5608:	a94153f3 	ldp	x19, x20, [sp, #16]
    560c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5614:	d65f03c0 	ret
    5618:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    561c:	91126000 	add	x0, x0, #0x498
    5620:	97fffb25 	bl	42b4 <fwp_trap>
    5624:	aa1703e0 	mov	x0, x23
    5628:	a9046bf9 	stp	x25, x26, [sp, #64]
    562c:	97fff65a 	bl	2f94 <fwp_tape_unlink_scope>
    5630:	f94012e0 	ldr	x0, [x23, #32]
    5634:	b4000040 	cbz	x0, 563c <fwp_tape_grow.constprop.0+0x1fc>
    5638:	97fffa4e 	bl	3f70 <ad_raw_free.part.0>
    563c:	f9401ae0 	ldr	x0, [x23, #48]
    5640:	b4000040 	cbz	x0, 5648 <fwp_tape_grow.constprop.0+0x208>
    5644:	97fffa4b 	bl	3f70 <ad_raw_free.part.0>
    5648:	f94022e0 	ldr	x0, [x23, #64]
    564c:	b4000040 	cbz	x0, 5654 <fwp_tape_grow.constprop.0+0x214>
    5650:	97fffa48 	bl	3f70 <ad_raw_free.part.0>
    5654:	d0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    5658:	f947e821 	ldr	x1, [x1, #4048]
    565c:	f9000eff 	str	xzr, [x23, #24]
    5660:	4f000400 	movi	v0.4s, #0x0
    5664:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5668:	d2800262 	mov	x2, #0x13                  	// #19
    566c:	f9400023 	ldr	x3, [x1]
    5670:	b90006ff 	str	wzr, [x23, #4]
    5674:	d2800021 	mov	x1, #0x1                   	// #1
    5678:	90000040 	adrp	x0, d000 <f0+0x2390>
    567c:	913e6000 	add	x0, x0, #0xf98
    5680:	3c8082e0 	stur	q0, [x23, #8]
    5684:	ad0102e0 	stp	q0, q0, [x23, #32]
    5688:	97fff4a2 	bl	2910 <fwrite@plt>
    568c:	d2800000 	mov	x0, #0x0                   	// #0
    5690:	97fff4ac 	bl	2940 <fflush@plt>
    5694:	52800cc0 	mov	w0, #0x66                  	// #102
    5698:	97fff4ba 	bl	2980 <_Exit@plt>
    569c:	d503201f 	nop

00000000000056a0 <f128.constprop.0>:
    56a0:	f100001f 	cmp	x0, #0x0
    56a4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    56a8:	54000a2b 	b.lt	57ec <f128.constprop.0+0x14c>  // b.tstop
    56ac:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56b0:	aa0003e2 	mov	x2, x0
    56b4:	910003fd 	mov	x29, sp
    56b8:	a90153f3 	stp	x19, x20, [sp, #16]
    56bc:	aa0003f4 	mov	x20, x0
    56c0:	aa010000 	orr	x0, x0, x1
    56c4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56c8:	aa0103f6 	mov	x22, x1
    56cc:	f9001bf7 	str	x23, [sp, #48]
    56d0:	fd001fe8 	str	d8, [sp, #56]
    56d4:	b7f80180 	tbnz	x0, #63, 5704 <f128.constprop.0+0x64>
    56d8:	9360fc20 	asr	x0, x1, #32
    56dc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56e0:	eb82801f 	cmp	x0, x2, asr #32
    56e4:	54000881 	b.ne	57f4 <f128.constprop.0+0x154>  // b.any
    56e8:	97fffcf6 	bl	4ac0 <fwp_tape_of>
    56ec:	aa0003f3 	mov	x19, x0
    56f0:	f9403000 	ldr	x0, [x0, #96]
    56f4:	b40001e0 	cbz	x0, 5730 <f128.constprop.0+0x90>
    56f8:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    56fc:	91140000 	add	x0, x0, #0x500
    5700:	97fffaed 	bl	42b4 <fwp_trap>
    5704:	9360fc40 	asr	x0, x2, #32
    5708:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    570c:	b6fffee2 	tbz	x2, #63, 56e8 <f128.constprop.0+0x48>
    5710:	2f00e408 	movi	d8, #0x0
    5714:	9360fc20 	asr	x0, x1, #32
    5718:	aa0103f4 	mov	x20, x1
    571c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5720:	97fffce8 	bl	4ac0 <fwp_tape_of>
    5724:	aa0003f3 	mov	x19, x0
    5728:	f9403000 	ldr	x0, [x0, #96]
    572c:	b5fffe60 	cbnz	x0, 56f8 <f128.constprop.0+0x58>
    5730:	f9400a77 	ldr	x23, [x19, #16]
    5734:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5738:	eb0002ff 	cmp	x23, x0
    573c:	5400046c 	b.gt	57c8 <f128.constprop.0+0x128>
    5740:	eb3442ff 	cmp	x23, w20, uxtw
    5744:	540004ed 	b.le	57e0 <f128.constprop.0+0x140>
    5748:	b7f80076 	tbnz	x22, #63, 5754 <f128.constprop.0+0xb4>
    574c:	eb3642ff 	cmp	x23, w22, uxtw
    5750:	5400048d 	b.le	57e0 <f128.constprop.0+0x140>
    5754:	f9400675 	ldr	x21, [x19, #8]
    5758:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    575c:	cb1502f5 	sub	x21, x23, x21
    5760:	910006a1 	add	x1, x21, #0x1
    5764:	eb00003f 	cmp	x1, x0
    5768:	54000308 	b.hi	57c8 <f128.constprop.0+0x128>  // b.pmore
    576c:	f9400e60 	ldr	x0, [x19, #24]
    5770:	eb00003f 	cmp	x1, x0
    5774:	5400030c 	b.gt	57d4 <f128.constprop.0+0x134>
    5778:	a9420262 	ldp	x2, x0, [x19, #32]
    577c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5780:	f9401a61 	ldr	x1, [x19, #48]
    5784:	b8357854 	str	w20, [x2, x21, lsl #2]
    5788:	f9401e62 	ldr	x2, [x19, #56]
    578c:	f10002df 	cmp	x22, #0x0
    5790:	fc357820 	str	d0, [x1, x21, lsl #3]
    5794:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5798:	b8357816 	str	w22, [x0, x21, lsl #2]
    579c:	92607e80 	and	x0, x20, #0xffffffff00000000
    57a0:	910006e1 	add	x1, x23, #0x1
    57a4:	aa170000 	orr	x0, x0, x23
    57a8:	fc357848 	str	d8, [x2, x21, lsl #3]
    57ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57b0:	f9401bf7 	ldr	x23, [sp, #48]
    57b4:	fd401fe8 	ldr	d8, [sp, #56]
    57b8:	f9000a61 	str	x1, [x19, #16]
    57bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57c4:	d65f03c0 	ret
    57c8:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    57cc:	91126000 	add	x0, x0, #0x498
    57d0:	97fffab9 	bl	42b4 <fwp_trap>
    57d4:	aa1303e0 	mov	x0, x19
    57d8:	97ffff1a 	bl	5440 <fwp_tape_grow.constprop.0>
    57dc:	17ffffe7 	b	5778 <f128.constprop.0+0xd8>
    57e0:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    57e4:	9114c000 	add	x0, x0, #0x530
    57e8:	97fffab3 	bl	42b4 <fwp_trap>
    57ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57f0:	d65f03c0 	ret
    57f4:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    57f8:	9112e000 	add	x0, x0, #0x4b8
    57fc:	97fffaae 	bl	42b4 <fwp_trap>

0000000000005800 <w107>:
    5800:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5804:	910003fd 	mov	x29, sp
    5808:	a90153f3 	stp	x19, x20, [sp, #16]
    580c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5810:	a90363f7 	stp	x23, x24, [sp, #48]
    5814:	aa0003f8 	mov	x24, x0
    5818:	a9046bf9 	stp	x25, x26, [sp, #64]
    581c:	aa0103f9 	mov	x25, x1
    5820:	6d0527e8 	stp	d8, d9, [sp, #80]
    5824:	1e604008 	fmov	d8, d0
    5828:	1e604029 	fmov	d9, d1
    582c:	6d062fea 	stp	d10, d11, [sp, #96]
    5830:	1e60080a 	fmul	d10, d0, d0
    5834:	b7f821a0 	tbnz	x0, #63, 5c68 <w107+0x468>
    5838:	9360fc17 	asr	x23, x0, #32
    583c:	aa1703e0 	mov	x0, x23
    5840:	97fffca0 	bl	4ac0 <fwp_tape_of>
    5844:	f9403001 	ldr	x1, [x0, #96]
    5848:	aa0003f3 	mov	x19, x0
    584c:	b4000081 	cbz	x1, 585c <w107+0x5c>
    5850:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    5854:	91140000 	add	x0, x0, #0x500
    5858:	97fffa97 	bl	42b4 <fwp_trap>
    585c:	f9400815 	ldr	x21, [x0, #16]
    5860:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5864:	eb0102bf 	cmp	x21, x1
    5868:	54001d8c 	b.gt	5c18 <w107+0x418>
    586c:	eb3842bf 	cmp	x21, w24, uxtw
    5870:	54001ced 	b.le	5c0c <w107+0x40c>
    5874:	f9400416 	ldr	x22, [x0, #8]
    5878:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    587c:	cb1602b6 	sub	x22, x21, x22
    5880:	910006c1 	add	x1, x22, #0x1
    5884:	eb02003f 	cmp	x1, x2
    5888:	54001c88 	b.hi	5c18 <w107+0x418>  // b.pmore
    588c:	f9400c02 	ldr	x2, [x0, #24]
    5890:	eb02003f 	cmp	x1, x2
    5894:	54001c8c 	b.gt	5c24 <w107+0x424>
    5898:	a9420660 	ldp	x0, x1, [x19, #32]
    589c:	92607f14 	and	x20, x24, #0xffffffff00000000
    58a0:	f9401a62 	ldr	x2, [x19, #48]
    58a4:	b8367818 	str	w24, [x0, x22, lsl #2]
    58a8:	f9401e60 	ldr	x0, [x19, #56]
    58ac:	aa150294 	orr	x20, x20, x21
    58b0:	fc367848 	str	d8, [x2, x22, lsl #3]
    58b4:	910006b5 	add	x21, x21, #0x1
    58b8:	b8367838 	str	w24, [x1, x22, lsl #2]
    58bc:	1e6a392a 	fsub	d10, d9, d10
    58c0:	9360fe9a 	asr	x26, x20, #32
    58c4:	fc367808 	str	d8, [x0, x22, lsl #3]
    58c8:	f9000a75 	str	x21, [x19, #16]
    58cc:	b7f80079 	tbnz	x25, #63, 58d8 <w107+0xd8>
    58d0:	eb99835f 	cmp	x26, x25, asr #32
    58d4:	54001e21 	b.ne	5c98 <w107+0x498>  // b.any
    58d8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58dc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    58e0:	eb1a02ff 	cmp	x23, x26
    58e4:	540000c0 	b.eq	58fc <w107+0xfc>  // b.none
    58e8:	aa1a03e0 	mov	x0, x26
    58ec:	97fffc75 	bl	4ac0 <fwp_tape_of>
    58f0:	aa0003f3 	mov	x19, x0
    58f4:	f9403000 	ldr	x0, [x0, #96]
    58f8:	b5fffac0 	cbnz	x0, 5850 <w107+0x50>
    58fc:	f9400a77 	ldr	x23, [x19, #16]
    5900:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5904:	eb0002ff 	cmp	x23, x0
    5908:	5400188c 	b.gt	5c18 <w107+0x418>
    590c:	eb3442ff 	cmp	x23, w20, uxtw
    5910:	540017ed 	b.le	5c0c <w107+0x40c>
    5914:	b7f80079 	tbnz	x25, #63, 5920 <w107+0x120>
    5918:	eb3942ff 	cmp	x23, w25, uxtw
    591c:	5400178d 	b.le	5c0c <w107+0x40c>
    5920:	f9400675 	ldr	x21, [x19, #8]
    5924:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5928:	cb1502f5 	sub	x21, x23, x21
    592c:	910006a1 	add	x1, x21, #0x1
    5930:	eb00003f 	cmp	x1, x0
    5934:	54001728 	b.hi	5c18 <w107+0x418>  // b.pmore
    5938:	f9400e60 	ldr	x0, [x19, #24]
    593c:	eb00003f 	cmp	x1, x0
    5940:	540018ec 	b.gt	5c5c <w107+0x45c>
    5944:	a9420e62 	ldp	x2, x3, [x19, #32]
    5948:	f100033f 	cmp	x25, #0x0
    594c:	f9401a61 	ldr	x1, [x19, #48]
    5950:	b8357854 	str	w20, [x2, x21, lsl #2]
    5954:	f9401e62 	ldr	x2, [x19, #56]
    5958:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    595c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5960:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5964:	b8357861 	str	w1, [x3, x21, lsl #2]
    5968:	910006f6 	add	x22, x23, #0x1
    596c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5970:	92607e94 	and	x20, x20, #0xffffffff00000000
    5974:	fc357849 	str	d9, [x2, x21, lsl #3]
    5978:	aa170294 	orr	x20, x20, x23
    597c:	f9000a76 	str	x22, [x19, #16]
    5980:	1e68396b 	fsub	d11, d11, d8
    5984:	b7f81a78 	tbnz	x24, #63, 5cd0 <w107+0x4d0>
    5988:	9360ff17 	asr	x23, x24, #32
    598c:	eb1a02ff 	cmp	x23, x26
    5990:	540000e0 	b.eq	59ac <w107+0x1ac>  // b.none
    5994:	aa1703e0 	mov	x0, x23
    5998:	97fffc4a 	bl	4ac0 <fwp_tape_of>
    599c:	aa0003f3 	mov	x19, x0
    59a0:	f9403000 	ldr	x0, [x0, #96]
    59a4:	b5fff560 	cbnz	x0, 5850 <w107+0x50>
    59a8:	f9400a76 	ldr	x22, [x19, #16]
    59ac:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59b0:	eb0002df 	cmp	x22, x0
    59b4:	5400132c 	b.gt	5c18 <w107+0x418>
    59b8:	eb3842df 	cmp	x22, w24, uxtw
    59bc:	5400128d 	b.le	5c0c <w107+0x40c>
    59c0:	f9400675 	ldr	x21, [x19, #8]
    59c4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59c8:	cb1502d5 	sub	x21, x22, x21
    59cc:	910006a1 	add	x1, x21, #0x1
    59d0:	eb00003f 	cmp	x1, x0
    59d4:	54001228 	b.hi	5c18 <w107+0x418>  // b.pmore
    59d8:	f9400e60 	ldr	x0, [x19, #24]
    59dc:	eb00003f 	cmp	x1, x0
    59e0:	5400138c 	b.gt	5c50 <w107+0x450>
    59e4:	a9420262 	ldp	x2, x0, [x19, #32]
    59e8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    59ec:	f9401a63 	ldr	x3, [x19, #48]
    59f0:	b8357858 	str	w24, [x2, x21, lsl #2]
    59f4:	f9401e62 	ldr	x2, [x19, #56]
    59f8:	12800001 	mov	w1, #0xffffffff            	// #-1
    59fc:	fc357860 	str	d0, [x3, x21, lsl #3]
    5a00:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5a04:	b8357801 	str	w1, [x0, x21, lsl #2]
    5a08:	92607f00 	and	x0, x24, #0xffffffff00000000
    5a0c:	aa160018 	orr	x24, x0, x22
    5a10:	910006c1 	add	x1, x22, #0x1
    5a14:	fc357840 	str	d0, [x2, x21, lsl #3]
    5a18:	f9000a61 	str	x1, [x19, #16]
    5a1c:	9360fe99 	asr	x25, x20, #32
    5a20:	1e6a0949 	fmul	d9, d10, d10
    5a24:	eb17033f 	cmp	x25, x23
    5a28:	540000c0 	b.eq	5a40 <w107+0x240>  // b.none
    5a2c:	aa1903e0 	mov	x0, x25
    5a30:	97fffc24 	bl	4ac0 <fwp_tape_of>
    5a34:	aa0003f3 	mov	x19, x0
    5a38:	f9403000 	ldr	x0, [x0, #96]
    5a3c:	b5fff0a0 	cbnz	x0, 5850 <w107+0x50>
    5a40:	f9400a75 	ldr	x21, [x19, #16]
    5a44:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a48:	eb0002bf 	cmp	x21, x0
    5a4c:	54000e6c 	b.gt	5c18 <w107+0x418>
    5a50:	eb3442bf 	cmp	x21, w20, uxtw
    5a54:	54000dcd 	b.le	5c0c <w107+0x40c>
    5a58:	f9400676 	ldr	x22, [x19, #8]
    5a5c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a60:	cb1602b6 	sub	x22, x21, x22
    5a64:	910006c1 	add	x1, x22, #0x1
    5a68:	eb00003f 	cmp	x1, x0
    5a6c:	54000d68 	b.hi	5c18 <w107+0x418>  // b.pmore
    5a70:	f9400e60 	ldr	x0, [x19, #24]
    5a74:	eb00003f 	cmp	x1, x0
    5a78:	54000e6c 	b.gt	5c44 <w107+0x444>
    5a7c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5a80:	aa150017 	orr	x23, x0, x21
    5a84:	a9420261 	ldp	x1, x0, [x19, #32]
    5a88:	f9401a62 	ldr	x2, [x19, #48]
    5a8c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5a90:	f9401e61 	ldr	x1, [x19, #56]
    5a94:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5a98:	b8367814 	str	w20, [x0, x22, lsl #2]
    5a9c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5aa0:	9e670000 	fmov	d0, x0
    5aa4:	910006b4 	add	x20, x21, #0x1
    5aa8:	fc36782a 	str	d10, [x1, x22, lsl #3]
    5aac:	9360fef6 	asr	x22, x23, #32
    5ab0:	f9000a74 	str	x20, [x19, #16]
    5ab4:	1e600929 	fmul	d9, d9, d0
    5ab8:	eb1902df 	cmp	x22, x25
    5abc:	540000e0 	b.eq	5ad8 <w107+0x2d8>  // b.none
    5ac0:	aa1603e0 	mov	x0, x22
    5ac4:	97fffbff 	bl	4ac0 <fwp_tape_of>
    5ac8:	aa0003f3 	mov	x19, x0
    5acc:	f9403000 	ldr	x0, [x0, #96]
    5ad0:	b5ffec00 	cbnz	x0, 5850 <w107+0x50>
    5ad4:	f9400a74 	ldr	x20, [x19, #16]
    5ad8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5adc:	eb00029f 	cmp	x20, x0
    5ae0:	540009cc 	b.gt	5c18 <w107+0x418>
    5ae4:	eb37429f 	cmp	x20, w23, uxtw
    5ae8:	5400092d 	b.le	5c0c <w107+0x40c>
    5aec:	f9400675 	ldr	x21, [x19, #8]
    5af0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5af4:	cb150295 	sub	x21, x20, x21
    5af8:	910006a1 	add	x1, x21, #0x1
    5afc:	eb00003f 	cmp	x1, x0
    5b00:	540008c8 	b.hi	5c18 <w107+0x418>  // b.pmore
    5b04:	f9400e60 	ldr	x0, [x19, #24]
    5b08:	eb00003f 	cmp	x1, x0
    5b0c:	5400096c 	b.gt	5c38 <w107+0x438>
    5b10:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5b14:	9e670000 	fmov	d0, x0
    5b18:	a9420262 	ldp	x2, x0, [x19, #32]
    5b1c:	1e6b0968 	fmul	d8, d11, d11
    5b20:	f9401a61 	ldr	x1, [x19, #48]
    5b24:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b28:	f9401e62 	ldr	x2, [x19, #56]
    5b2c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5b30:	12800001 	mov	w1, #0xffffffff            	// #-1
    5b34:	b8357801 	str	w1, [x0, x21, lsl #2]
    5b38:	91000681 	add	x1, x20, #0x1
    5b3c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5b40:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b44:	f9000a61 	str	x1, [x19, #16]
    5b48:	aa140014 	orr	x20, x0, x20
    5b4c:	b100071f 	cmn	x24, #0x1
    5b50:	54000c60 	b.eq	5cdc <w107+0x4dc>  // b.none
    5b54:	9360ff00 	asr	x0, x24, #32
    5b58:	eb16001f 	cmp	x0, x22
    5b5c:	540000a0 	b.eq	5b70 <w107+0x370>  // b.none
    5b60:	97fffbd8 	bl	4ac0 <fwp_tape_of>
    5b64:	aa0003f3 	mov	x19, x0
    5b68:	f9403000 	ldr	x0, [x0, #96]
    5b6c:	b5ffe720 	cbnz	x0, 5850 <w107+0x50>
    5b70:	f9400a75 	ldr	x21, [x19, #16]
    5b74:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b78:	eb0002bf 	cmp	x21, x0
    5b7c:	540004ec 	b.gt	5c18 <w107+0x418>
    5b80:	eb3842bf 	cmp	x21, w24, uxtw
    5b84:	5400044d 	b.le	5c0c <w107+0x40c>
    5b88:	f9400676 	ldr	x22, [x19, #8]
    5b8c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b90:	cb1602b6 	sub	x22, x21, x22
    5b94:	910006c1 	add	x1, x22, #0x1
    5b98:	eb00003f 	cmp	x1, x0
    5b9c:	540003e8 	b.hi	5c18 <w107+0x418>  // b.pmore
    5ba0:	f9400e60 	ldr	x0, [x19, #24]
    5ba4:	eb00003f 	cmp	x1, x0
    5ba8:	5400042c 	b.gt	5c2c <w107+0x42c>
    5bac:	a9420a61 	ldp	x1, x2, [x19, #32]
    5bb0:	92607f00 	and	x0, x24, #0xffffffff00000000
    5bb4:	f9401a63 	ldr	x3, [x19, #48]
    5bb8:	b8367838 	str	w24, [x1, x22, lsl #2]
    5bbc:	f9401e61 	ldr	x1, [x19, #56]
    5bc0:	aa150000 	orr	x0, x0, x21
    5bc4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5bc8:	910006b5 	add	x21, x21, #0x1
    5bcc:	b8367858 	str	w24, [x2, x22, lsl #2]
    5bd0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5bd4:	f9000a75 	str	x21, [x19, #16]
    5bd8:	1e692908 	fadd	d8, d8, d9
    5bdc:	aa1403e1 	mov	x1, x20
    5be0:	97fffeb0 	bl	56a0 <f128.constprop.0>
    5be4:	aa0003e1 	mov	x1, x0
    5be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bec:	9e660100 	fmov	x0, d8
    5bf0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5bf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bf8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5bfc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5c00:	6d462fea 	ldp	d10, d11, [sp, #96]
    5c04:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5c08:	d65f03c0 	ret
    5c0c:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    5c10:	9114c000 	add	x0, x0, #0x530
    5c14:	97fff9a8 	bl	42b4 <fwp_trap>
    5c18:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    5c1c:	91126000 	add	x0, x0, #0x498
    5c20:	97fff9a5 	bl	42b4 <fwp_trap>
    5c24:	97fffe07 	bl	5440 <fwp_tape_grow.constprop.0>
    5c28:	17ffff1c 	b	5898 <w107+0x98>
    5c2c:	aa1303e0 	mov	x0, x19
    5c30:	97fffe04 	bl	5440 <fwp_tape_grow.constprop.0>
    5c34:	17ffffde 	b	5bac <w107+0x3ac>
    5c38:	aa1303e0 	mov	x0, x19
    5c3c:	97fffe01 	bl	5440 <fwp_tape_grow.constprop.0>
    5c40:	17ffffb4 	b	5b10 <w107+0x310>
    5c44:	aa1303e0 	mov	x0, x19
    5c48:	97fffdfe 	bl	5440 <fwp_tape_grow.constprop.0>
    5c4c:	17ffff8c 	b	5a7c <w107+0x27c>
    5c50:	aa1303e0 	mov	x0, x19
    5c54:	97fffdfb 	bl	5440 <fwp_tape_grow.constprop.0>
    5c58:	17ffff63 	b	59e4 <w107+0x1e4>
    5c5c:	aa1303e0 	mov	x0, x19
    5c60:	97fffdf8 	bl	5440 <fwp_tape_grow.constprop.0>
    5c64:	17ffff38 	b	5944 <w107+0x144>
    5c68:	1e6a382a 	fsub	d10, d1, d10
    5c6c:	b6f801c1 	tbz	x1, #63, 5ca4 <w107+0x4a4>
    5c70:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c74:	1e6a0949 	fmul	d9, d10, d10
    5c78:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c7c:	9e670001 	fmov	d1, x0
    5c80:	1e683808 	fsub	d8, d0, d8
    5c84:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5c88:	aa1403e0 	mov	x0, x20
    5c8c:	1e610929 	fmul	d9, d9, d1
    5c90:	1e680908 	fmul	d8, d8, d8
    5c94:	17ffffd1 	b	5bd8 <w107+0x3d8>
    5c98:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    5c9c:	9112e000 	add	x0, x0, #0x4b8
    5ca0:	97fff985 	bl	42b4 <fwp_trap>
    5ca4:	2f00e409 	movi	d9, #0x0
    5ca8:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5cac:	9360fc3a 	asr	x26, x1, #32
    5cb0:	aa0103f4 	mov	x20, x1
    5cb4:	aa1a03e0 	mov	x0, x26
    5cb8:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5cbc:	97fffb81 	bl	4ac0 <fwp_tape_of>
    5cc0:	aa0003f3 	mov	x19, x0
    5cc4:	f9403000 	ldr	x0, [x0, #96]
    5cc8:	b5ffdc40 	cbnz	x0, 5850 <w107+0x50>
    5ccc:	17ffff0c 	b	58fc <w107+0xfc>
    5cd0:	aa1a03f7 	mov	x23, x26
    5cd4:	aa0003f8 	mov	x24, x0
    5cd8:	17ffff51 	b	5a1c <w107+0x21c>
    5cdc:	aa1803e0 	mov	x0, x24
    5ce0:	17ffffbe 	b	5bd8 <w107+0x3d8>

0000000000005ce4 <fwp_data.part.0.constprop.0>:
    5ce4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5ce8:	910003fd 	mov	x29, sp
    5cec:	a9025bf5 	stp	x21, x22, [sp, #32]
    5cf0:	f0000156 	adrp	x22, 30000 <__data_start>
    5cf4:	910182c2 	add	x2, x22, #0x60
    5cf8:	a9046bf9 	stp	x25, x26, [sp, #64]
    5cfc:	b9413059 	ldr	w25, [x2, #304]
    5d00:	a90153f3 	stp	x19, x20, [sp, #16]
    5d04:	aa0103f4 	mov	x20, x1
    5d08:	a90363f7 	stp	x23, x24, [sp, #48]
    5d0c:	2a0003f7 	mov	w23, w0
    5d10:	340000b9 	cbz	w25, 5d24 <fwp_data.part.0.constprop.0+0x40>
    5d14:	a9538041 	ldp	x1, x0, [x2, #312]
    5d18:	91000421 	add	x1, x1, #0x1
    5d1c:	91006000 	add	x0, x0, #0x18
    5d20:	a9138041 	stp	x1, x0, [x2, #312]
    5d24:	90000435 	adrp	x21, 89000 <fwp_root_context+0xba0>
    5d28:	911902a3 	add	x3, x21, #0x640
    5d2c:	b953a460 	ldr	w0, [x3, #5028]
    5d30:	34000840 	cbz	w0, 5e38 <fwp_data.part.0.constprop.0+0x154>
    5d34:	397e8862 	ldrb	w2, [x3, #4002]
    5d38:	910f0040 	add	x0, x2, #0x3c0
    5d3c:	8b020442 	add	x2, x2, x2, lsl #1
    5d40:	d37df042 	lsl	x2, x2, #3
    5d44:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5d48:	2a1a03f8 	mov	w24, w26
    5d4c:	f8626873 	ldr	x19, [x3, x2]
    5d50:	b4000613 	cbz	x19, 5e10 <fwp_data.part.0.constprop.0+0x12c>
    5d54:	f9400260 	ldr	x0, [x19]
    5d58:	aa2003e0 	mvn	x0, x0
    5d5c:	f8226860 	str	x0, [x3, x2]
    5d60:	f100631f 	cmp	x24, #0x18
    5d64:	540000e9 	b.ls	5d80 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5d68:	d1006702 	sub	x2, x24, #0x19
    5d6c:	91006260 	add	x0, x19, #0x18
    5d70:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5d74:	52800001 	mov	w1, #0x0                   	// #0
    5d78:	91002042 	add	x2, x2, #0x8
    5d7c:	97fff299 	bl	27e0 <memset@plt>
    5d80:	911902a0 	add	x0, x21, #0x640
    5d84:	f94a1001 	ldr	x1, [x0, #5152]
    5d88:	ab180021 	adds	x1, x1, x24
    5d8c:	54000682 	b.cs	5e5c <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    5d90:	f94a1402 	ldr	x2, [x0, #5160]
    5d94:	f90a1001 	str	x1, [x0, #5152]
    5d98:	eb02003f 	cmp	x1, x2
    5d9c:	54000049 	b.ls	5da4 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5da0:	f90a1401 	str	x1, [x0, #5160]
    5da4:	911902a0 	add	x0, x21, #0x640
    5da8:	1e630341 	ucvtf	d1, w26
    5dac:	fd4a1c00 	ldr	d0, [x0, #5176]
    5db0:	1e612800 	fadd	d0, d0, d1
    5db4:	fd0a1c00 	str	d0, [x0, #5176]
    5db8:	34000139 	cbz	w25, 5ddc <fwp_data.part.0.constprop.0+0xf8>
    5dbc:	911902b5 	add	x21, x21, #0x640
    5dc0:	910182d6 	add	x22, x22, #0x60
    5dc4:	fd4a12a0 	ldr	d0, [x21, #5152]
    5dc8:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5dcc:	7e61d800 	ucvtf	d0, d0
    5dd0:	1e623800 	fsub	d0, d0, d2
    5dd4:	1e612010 	fcmpe	d0, d1
    5dd8:	540003ec 	b.gt	5e54 <fwp_data.part.0.constprop.0+0x170>
    5ddc:	52800040 	mov	w0, #0x2                   	// #2
    5de0:	29000277 	stp	w23, w0, [x19]
    5de4:	aa1303e0 	mov	x0, x19
    5de8:	f9400281 	ldr	x1, [x20]
    5dec:	f9000661 	str	x1, [x19, #8]
    5df0:	f9400681 	ldr	x1, [x20, #8]
    5df4:	f9000a61 	str	x1, [x19, #16]
    5df8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5e00:	a94363f7 	ldp	x23, x24, [sp, #48]
    5e04:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5e08:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5e0c:	d65f03c0 	ret
    5e10:	8b020063 	add	x3, x3, x2
    5e14:	f9400473 	ldr	x19, [x3, #8]
    5e18:	b4000113 	cbz	x19, 5e38 <fwp_data.part.0.constprop.0+0x154>
    5e1c:	f9400860 	ldr	x0, [x3, #16]
    5e20:	cb130000 	sub	x0, x0, x19
    5e24:	eb00031f 	cmp	x24, x0
    5e28:	54000088 	b.hi	5e38 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5e2c:	8b180260 	add	x0, x19, x24
    5e30:	f9000460 	str	x0, [x3, #8]
    5e34:	17ffffcb 	b	5d60 <fwp_data.part.0.constprop.0+0x7c>
    5e38:	52800001 	mov	w1, #0x0                   	// #0
    5e3c:	d2800300 	mov	x0, #0x18                  	// #24
    5e40:	97fffc94 	bl	5090 <fwp_heap_alloc>
    5e44:	aa0003f3 	mov	x19, x0
    5e48:	910182c1 	add	x1, x22, #0x60
    5e4c:	b9413039 	ldr	w25, [x1, #304]
    5e50:	17ffffda 	b	5db8 <fwp_data.part.0.constprop.0+0xd4>
    5e54:	fd00aac0 	str	d0, [x22, #336]
    5e58:	17ffffe1 	b	5ddc <fwp_data.part.0.constprop.0+0xf8>
    5e5c:	97fff4a5 	bl	30f0 <fwp_heap_oom>

0000000000005e60 <fwp_rc_share>:
    5e60:	90000422 	adrp	x2, 89000 <fwp_root_context+0xba0>
    5e64:	91190042 	add	x2, x2, #0x640
    5e68:	f949d843 	ldr	x3, [x2, #5040]
    5e6c:	f949ec41 	ldr	x1, [x2, #5080]
    5e70:	cb030000 	sub	x0, x0, x3
    5e74:	eb01401f 	cmp	x0, x1, lsl #16
    5e78:	540003a2 	b.cs	5eec <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5e7c:	d350fc01 	lsr	x1, x0, #16
    5e80:	f949fc44 	ldr	x4, [x2, #5112]
    5e84:	8b010821 	add	x1, x1, x1, lsl #2
    5e88:	d37df021 	lsl	x1, x1, #3
    5e8c:	8b010083 	add	x3, x4, x1
    5e90:	f9401062 	ldr	x2, [x3, #32]
    5e94:	b40002c2 	cbz	x2, 5eec <fwp_rc_share+0x8c>
    5e98:	38616881 	ldrb	w1, [x4, x1]
    5e9c:	7100083f 	cmp	w1, #0x2
    5ea0:	54000220 	b.eq	5ee4 <fwp_rc_share+0x84>  // b.none
    5ea4:	7100043f 	cmp	w1, #0x1
    5ea8:	54000221 	b.ne	5eec <fwp_rc_share+0x8c>  // b.any
    5eac:	29430464 	ldp	w4, w1, [x3, #24]
    5eb0:	92403c00 	and	x0, x0, #0xffff
    5eb4:	9b047c00 	mul	x0, x0, x4
    5eb8:	d360fc00 	lsr	x0, x0, #32
    5ebc:	eb01001f 	cmp	x0, x1
    5ec0:	54000162 	b.cs	5eec <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ec4:	8b000042 	add	x2, x2, x0
    5ec8:	39400040 	ldrb	w0, [x2]
    5ecc:	34000100 	cbz	w0, 5eec <fwp_rc_share+0x8c>
    5ed0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ed4:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    5ed8:	91154000 	add	x0, x0, #0x550
    5edc:	910003fd 	mov	x29, sp
    5ee0:	97fff8f5 	bl	42b4 <fwp_trap>
    5ee4:	72003c1f 	tst	w0, #0xffff
    5ee8:	54ffff00 	b.eq	5ec8 <fwp_rc_share+0x68>  // b.none
    5eec:	d65f03c0 	ret

0000000000005ef0 <fwp_rc_fresh>:
    5ef0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ef4:	90000423 	adrp	x3, 89000 <fwp_root_context+0xba0>
    5ef8:	91190063 	add	x3, x3, #0x640
    5efc:	910003fd 	mov	x29, sp
    5f00:	a90153f3 	stp	x19, x20, [sp, #16]
    5f04:	aa0003f3 	mov	x19, x0
    5f08:	f949d861 	ldr	x1, [x3, #5040]
    5f0c:	f949ec60 	ldr	x0, [x3, #5080]
    5f10:	cb010261 	sub	x1, x19, x1
    5f14:	eb00403f 	cmp	x1, x0, lsl #16
    5f18:	54000322 	b.cs	5f7c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5f1c:	d350fc22 	lsr	x2, x1, #16
    5f20:	f949fc63 	ldr	x3, [x3, #5112]
    5f24:	8b020842 	add	x2, x2, x2, lsl #2
    5f28:	d37df042 	lsl	x2, x2, #3
    5f2c:	8b020060 	add	x0, x3, x2
    5f30:	f9401014 	ldr	x20, [x0, #32]
    5f34:	b4000254 	cbz	x20, 5f7c <fwp_rc_fresh+0x8c>
    5f38:	38626862 	ldrb	w2, [x3, x2]
    5f3c:	7100085f 	cmp	w2, #0x2
    5f40:	54000260 	b.eq	5f8c <fwp_rc_fresh+0x9c>  // b.none
    5f44:	7100045f 	cmp	w2, #0x1
    5f48:	540001a1 	b.ne	5f7c <fwp_rc_fresh+0x8c>  // b.any
    5f4c:	29430002 	ldp	w2, w0, [x0, #24]
    5f50:	92403c21 	and	x1, x1, #0xffff
    5f54:	9b027c21 	mul	x1, x1, x2
    5f58:	d360fc21 	lsr	x1, x1, #32
    5f5c:	eb00003f 	cmp	x1, x0
    5f60:	540000e2 	b.cs	5f7c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5f64:	8b010294 	add	x20, x20, x1
    5f68:	39400280 	ldrb	w0, [x20]
    5f6c:	7103fc1f 	cmp	w0, #0xff
    5f70:	540001a0 	b.eq	5fa4 <fwp_rc_fresh+0xb4>  // b.none
    5f74:	52800020 	mov	w0, #0x1                   	// #1
    5f78:	39000280 	strb	w0, [x20]
    5f7c:	aa1303e0 	mov	x0, x19
    5f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f88:	d65f03c0 	ret
    5f8c:	72003c3f 	tst	w1, #0xffff
    5f90:	54fffec0 	b.eq	5f68 <fwp_rc_fresh+0x78>  // b.none
    5f94:	aa1303e0 	mov	x0, x19
    5f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fa0:	d65f03c0 	ret
    5fa4:	aa1403e0 	mov	x0, x20
    5fa8:	97fff8e3 	bl	4334 <fwp_rc_forget_slot.part.0>
    5fac:	17fffff2 	b	5f74 <fwp_rc_fresh+0x84>

0000000000005fb0 <fwp_rc_free_arr>:
    5fb0:	90000423 	adrp	x3, 89000 <fwp_root_context+0xba0>
    5fb4:	91190063 	add	x3, x3, #0x640
    5fb8:	f949d861 	ldr	x1, [x3, #5040]
    5fbc:	f949ec62 	ldr	x2, [x3, #5080]
    5fc0:	cb010001 	sub	x1, x0, x1
    5fc4:	eb02403f 	cmp	x1, x2, lsl #16
    5fc8:	54000342 	b.cs	6030 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5fcc:	d350fc22 	lsr	x2, x1, #16
    5fd0:	f949fc65 	ldr	x5, [x3, #5112]
    5fd4:	8b020842 	add	x2, x2, x2, lsl #2
    5fd8:	d37df042 	lsl	x2, x2, #3
    5fdc:	8b0200a4 	add	x4, x5, x2
    5fe0:	f9401083 	ldr	x3, [x4, #32]
    5fe4:	b4000263 	cbz	x3, 6030 <fwp_rc_free_arr+0x80>
    5fe8:	386268a2 	ldrb	w2, [x5, x2]
    5fec:	7100085f 	cmp	w2, #0x2
    5ff0:	540001c0 	b.eq	6028 <fwp_rc_free_arr+0x78>  // b.none
    5ff4:	7100045f 	cmp	w2, #0x1
    5ff8:	540001c1 	b.ne	6030 <fwp_rc_free_arr+0x80>  // b.any
    5ffc:	29430885 	ldp	w5, w2, [x4, #24]
    6000:	92403c21 	and	x1, x1, #0xffff
    6004:	9b057c21 	mul	x1, x1, x5
    6008:	d360fc21 	lsr	x1, x1, #32
    600c:	eb02003f 	cmp	x1, x2
    6010:	54000102 	b.cs	6030 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    6014:	8b010063 	add	x3, x3, x1
    6018:	39400061 	ldrb	w1, [x3]
    601c:	7100043f 	cmp	w1, #0x1
    6020:	54000081 	b.ne	6030 <fwp_rc_free_arr+0x80>  // b.any
    6024:	17fff95f 	b	45a0 <fwp_mem_free>
    6028:	72003c3f 	tst	w1, #0xffff
    602c:	54ffff60 	b.eq	6018 <fwp_rc_free_arr+0x68>  // b.none
    6030:	d65f03c0 	ret

0000000000006034 <fwp_rc_dup>:
    6034:	f0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    6038:	91190042 	add	x2, x2, #0x640
    603c:	f949d841 	ldr	x1, [x2, #5040]
    6040:	f949ec43 	ldr	x3, [x2, #5080]
    6044:	cb010001 	sub	x1, x0, x1
    6048:	eb03403f 	cmp	x1, x3, lsl #16
    604c:	540003c2 	b.cs	60c4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    6050:	d350fc20 	lsr	x0, x1, #16
    6054:	f949fc44 	ldr	x4, [x2, #5112]
    6058:	8b000800 	add	x0, x0, x0, lsl #2
    605c:	d37df002 	lsl	x2, x0, #3
    6060:	8b020083 	add	x3, x4, x2
    6064:	f9401060 	ldr	x0, [x3, #32]
    6068:	b40002e0 	cbz	x0, 60c4 <fwp_rc_dup+0x90>
    606c:	38626882 	ldrb	w2, [x4, x2]
    6070:	7100085f 	cmp	w2, #0x2
    6074:	540002a0 	b.eq	60c8 <fwp_rc_dup+0x94>  // b.none
    6078:	7100045f 	cmp	w2, #0x1
    607c:	54000241 	b.ne	60c4 <fwp_rc_dup+0x90>  // b.any
    6080:	29430864 	ldp	w4, w2, [x3, #24]
    6084:	92403c21 	and	x1, x1, #0xffff
    6088:	9b047c21 	mul	x1, x1, x4
    608c:	d360fc21 	lsr	x1, x1, #32
    6090:	eb02003f 	cmp	x1, x2
    6094:	54000182 	b.cs	60c4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    6098:	8b010000 	add	x0, x0, x1
    609c:	39400001 	ldrb	w1, [x0]
    60a0:	34000121 	cbz	w1, 60c4 <fwp_rc_dup+0x90>
    60a4:	d0000142 	adrp	x2, 30000 <__data_start>
    60a8:	91018042 	add	x2, x2, #0x60
    60ac:	b9413043 	ldr	w3, [x2, #304]
    60b0:	35000123 	cbnz	w3, 60d4 <fwp_rc_dup+0xa0>
    60b4:	7103f43f 	cmp	w1, #0xfd
    60b8:	54000168 	b.hi	60e4 <fwp_rc_dup+0xb0>  // b.pmore
    60bc:	11000421 	add	w1, w1, #0x1
    60c0:	39000001 	strb	w1, [x0]
    60c4:	d65f03c0 	ret
    60c8:	72003c3f 	tst	w1, #0xffff
    60cc:	54fffe80 	b.eq	609c <fwp_rc_dup+0x68>  // b.none
    60d0:	d65f03c0 	ret
    60d4:	f940ac43 	ldr	x3, [x2, #344]
    60d8:	91000463 	add	x3, x3, #0x1
    60dc:	f900ac43 	str	x3, [x2, #344]
    60e0:	17fffff5 	b	60b4 <fwp_rc_dup+0x80>
    60e4:	17fff9a8 	b	4784 <fwp_rc_wide_dup>
    60e8:	d503201f 	nop
    60ec:	d503201f 	nop

00000000000060f0 <fwp_owned_entry161>:
    60f0:	d10103ff 	sub	sp, sp, #0x40
    60f4:	b0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    60f8:	f947f442 	ldr	x2, [x2, #4072]
    60fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    6100:	910083fd 	add	x29, sp, #0x20
    6104:	a90353f3 	stp	x19, x20, [sp, #48]
    6108:	f9400043 	ldr	x3, [x2]
    610c:	f9000fe3 	str	x3, [sp, #24]
    6110:	d2800003 	mov	x3, #0x0                   	// #0
    6114:	a9400c01 	ldp	x1, x3, [x0]
    6118:	f9400802 	ldr	x2, [x0, #16]
    611c:	ab020022 	adds	x2, x1, x2
    6120:	540006e6 	b.vs	61fc <fwp_owned_entry161+0x10c>
    6124:	910023e1 	add	x1, sp, #0x8
    6128:	52800000 	mov	w0, #0x0                   	// #0
    612c:	a9008be3 	stp	x3, x2, [sp, #8]
    6130:	97fffeed 	bl	5ce4 <fwp_data.part.0.constprop.0>
    6134:	f0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    6138:	91190063 	add	x3, x3, #0x640
    613c:	aa0003f3 	mov	x19, x0
    6140:	f949d861 	ldr	x1, [x3, #5040]
    6144:	f949ec60 	ldr	x0, [x3, #5080]
    6148:	cb010261 	sub	x1, x19, x1
    614c:	eb00403f 	cmp	x1, x0, lsl #16
    6150:	54000322 	b.cs	61b4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    6154:	d350fc22 	lsr	x2, x1, #16
    6158:	f949fc63 	ldr	x3, [x3, #5112]
    615c:	8b020842 	add	x2, x2, x2, lsl #2
    6160:	d37df042 	lsl	x2, x2, #3
    6164:	8b020060 	add	x0, x3, x2
    6168:	f9401014 	ldr	x20, [x0, #32]
    616c:	b4000254 	cbz	x20, 61b4 <fwp_owned_entry161+0xc4>
    6170:	38626862 	ldrb	w2, [x3, x2]
    6174:	7100085f 	cmp	w2, #0x2
    6178:	54000360 	b.eq	61e4 <fwp_owned_entry161+0xf4>  // b.none
    617c:	7100045f 	cmp	w2, #0x1
    6180:	540001a1 	b.ne	61b4 <fwp_owned_entry161+0xc4>  // b.any
    6184:	29430002 	ldp	w2, w0, [x0, #24]
    6188:	92403c21 	and	x1, x1, #0xffff
    618c:	9b027c21 	mul	x1, x1, x2
    6190:	d360fc21 	lsr	x1, x1, #32
    6194:	eb00003f 	cmp	x1, x0
    6198:	540000e2 	b.cs	61b4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    619c:	8b010294 	add	x20, x20, x1
    61a0:	39400280 	ldrb	w0, [x20]
    61a4:	7103fc1f 	cmp	w0, #0xff
    61a8:	54000240 	b.eq	61f0 <fwp_owned_entry161+0x100>  // b.none
    61ac:	52800020 	mov	w0, #0x1                   	// #1
    61b0:	39000280 	strb	w0, [x20]
    61b4:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    61b8:	f947f400 	ldr	x0, [x0, #4072]
    61bc:	f9400fe2 	ldr	x2, [sp, #24]
    61c0:	f9400001 	ldr	x1, [x0]
    61c4:	eb010042 	subs	x2, x2, x1
    61c8:	d2800001 	mov	x1, #0x0                   	// #0
    61cc:	540001a1 	b.ne	6200 <fwp_owned_entry161+0x110>  // b.any
    61d0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    61d4:	aa1303e0 	mov	x0, x19
    61d8:	a94353f3 	ldp	x19, x20, [sp, #48]
    61dc:	910103ff 	add	sp, sp, #0x40
    61e0:	d65f03c0 	ret
    61e4:	72003c3f 	tst	w1, #0xffff
    61e8:	54fffe61 	b.ne	61b4 <fwp_owned_entry161+0xc4>  // b.any
    61ec:	17ffffed 	b	61a0 <fwp_owned_entry161+0xb0>
    61f0:	aa1403e0 	mov	x0, x20
    61f4:	97fff850 	bl	4334 <fwp_rc_forget_slot.part.0>
    61f8:	17ffffed 	b	61ac <fwp_owned_entry161+0xbc>
    61fc:	97fff201 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6200:	97fff184 	bl	2810 <__stack_chk_fail@plt>

0000000000006204 <e161>:
    6204:	d10103ff 	sub	sp, sp, #0x40
    6208:	b0000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    620c:	f947f442 	ldr	x2, [x2, #4072]
    6210:	a9027bfd 	stp	x29, x30, [sp, #32]
    6214:	910083fd 	add	x29, sp, #0x20
    6218:	a90353f3 	stp	x19, x20, [sp, #48]
    621c:	f9400043 	ldr	x3, [x2]
    6220:	f9000fe3 	str	x3, [sp, #24]
    6224:	d2800003 	mov	x3, #0x0                   	// #0
    6228:	a9400c01 	ldp	x1, x3, [x0]
    622c:	f9400802 	ldr	x2, [x0, #16]
    6230:	ab020022 	adds	x2, x1, x2
    6234:	54000726 	b.vs	6318 <e161+0x114>
    6238:	910023e1 	add	x1, sp, #0x8
    623c:	52800000 	mov	w0, #0x0                   	// #0
    6240:	a9008be3 	stp	x3, x2, [sp, #8]
    6244:	97fffea8 	bl	5ce4 <fwp_data.part.0.constprop.0>
    6248:	f0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    624c:	91190063 	add	x3, x3, #0x640
    6250:	aa0003f3 	mov	x19, x0
    6254:	f949d861 	ldr	x1, [x3, #5040]
    6258:	f949ec60 	ldr	x0, [x3, #5080]
    625c:	cb010261 	sub	x1, x19, x1
    6260:	eb00403f 	cmp	x1, x0, lsl #16
    6264:	54000322 	b.cs	62c8 <e161+0xc4>  // b.hs, b.nlast
    6268:	d350fc22 	lsr	x2, x1, #16
    626c:	f949fc63 	ldr	x3, [x3, #5112]
    6270:	8b020842 	add	x2, x2, x2, lsl #2
    6274:	d37df042 	lsl	x2, x2, #3
    6278:	8b020060 	add	x0, x3, x2
    627c:	f9401014 	ldr	x20, [x0, #32]
    6280:	b4000254 	cbz	x20, 62c8 <e161+0xc4>
    6284:	38626862 	ldrb	w2, [x3, x2]
    6288:	7100085f 	cmp	w2, #0x2
    628c:	540003a0 	b.eq	6300 <e161+0xfc>  // b.none
    6290:	7100045f 	cmp	w2, #0x1
    6294:	540001a1 	b.ne	62c8 <e161+0xc4>  // b.any
    6298:	29430002 	ldp	w2, w0, [x0, #24]
    629c:	92403c21 	and	x1, x1, #0xffff
    62a0:	9b027c21 	mul	x1, x1, x2
    62a4:	d360fc21 	lsr	x1, x1, #32
    62a8:	eb00003f 	cmp	x1, x0
    62ac:	540000e2 	b.cs	62c8 <e161+0xc4>  // b.hs, b.nlast
    62b0:	8b010294 	add	x20, x20, x1
    62b4:	39400280 	ldrb	w0, [x20]
    62b8:	7103fc1f 	cmp	w0, #0xff
    62bc:	54000280 	b.eq	630c <e161+0x108>  // b.none
    62c0:	52800020 	mov	w0, #0x1                   	// #1
    62c4:	39000280 	strb	w0, [x20]
    62c8:	aa1303e0 	mov	x0, x19
    62cc:	97fffee5 	bl	5e60 <fwp_rc_share>
    62d0:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    62d4:	f947f400 	ldr	x0, [x0, #4072]
    62d8:	f9400fe2 	ldr	x2, [sp, #24]
    62dc:	f9400001 	ldr	x1, [x0]
    62e0:	eb010042 	subs	x2, x2, x1
    62e4:	d2800001 	mov	x1, #0x0                   	// #0
    62e8:	540001a1 	b.ne	631c <e161+0x118>  // b.any
    62ec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    62f0:	aa1303e0 	mov	x0, x19
    62f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    62f8:	910103ff 	add	sp, sp, #0x40
    62fc:	d65f03c0 	ret
    6300:	72003c3f 	tst	w1, #0xffff
    6304:	54fffe21 	b.ne	62c8 <e161+0xc4>  // b.any
    6308:	17ffffeb 	b	62b4 <e161+0xb0>
    630c:	aa1403e0 	mov	x0, x20
    6310:	97fff809 	bl	4334 <fwp_rc_forget_slot.part.0>
    6314:	17ffffeb 	b	62c0 <e161+0xbc>
    6318:	97fff1ba 	bl	2a00 <fwp_trap_overflow.constprop.0>
    631c:	97fff13d 	bl	2810 <__stack_chk_fail@plt>

0000000000006320 <fwp_drop1>:
    6320:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6324:	910003fd 	mov	x29, sp
    6328:	a90153f3 	stp	x19, x20, [sp, #16]
    632c:	f90013f5 	str	x21, [sp, #32]
    6330:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    6334:	911902b4 	add	x20, x21, #0x640
    6338:	f949da81 	ldr	x1, [x20, #5040]
    633c:	f949ee82 	ldr	x2, [x20, #5080]
    6340:	cb010001 	sub	x1, x0, x1
    6344:	eb02403f 	cmp	x1, x2, lsl #16
    6348:	54000382 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    634c:	d350fc22 	lsr	x2, x1, #16
    6350:	f949fe84 	ldr	x4, [x20, #5112]
    6354:	8b020842 	add	x2, x2, x2, lsl #2
    6358:	d37df042 	lsl	x2, x2, #3
    635c:	8b020083 	add	x3, x4, x2
    6360:	f9401073 	ldr	x19, [x3, #32]
    6364:	b40002b3 	cbz	x19, 63b8 <fwp_drop1+0x98>
    6368:	38626882 	ldrb	w2, [x4, x2]
    636c:	7100085f 	cmp	w2, #0x2
    6370:	540002c0 	b.eq	63c8 <fwp_drop1+0xa8>  // b.none
    6374:	7100045f 	cmp	w2, #0x1
    6378:	54000201 	b.ne	63b8 <fwp_drop1+0x98>  // b.any
    637c:	29430864 	ldp	w4, w2, [x3, #24]
    6380:	92403c21 	and	x1, x1, #0xffff
    6384:	9b047c21 	mul	x1, x1, x4
    6388:	d360fc21 	lsr	x1, x1, #32
    638c:	eb02003f 	cmp	x1, x2
    6390:	54000142 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6394:	8b010273 	add	x19, x19, x1
    6398:	39400261 	ldrb	w1, [x19]
    639c:	340000e1 	cbz	w1, 63b8 <fwp_drop1+0x98>
    63a0:	7100043f 	cmp	w1, #0x1
    63a4:	540001e0 	b.eq	63e0 <fwp_drop1+0xc0>  // b.none
    63a8:	7103fc3f 	cmp	w1, #0xff
    63ac:	540002e0 	b.eq	6408 <fwp_drop1+0xe8>  // b.none
    63b0:	51000421 	sub	w1, w1, #0x1
    63b4:	39000261 	strb	w1, [x19]
    63b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    63bc:	f94013f5 	ldr	x21, [sp, #32]
    63c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63c4:	d65f03c0 	ret
    63c8:	72003c3f 	tst	w1, #0xffff
    63cc:	54fffe60 	b.eq	6398 <fwp_drop1+0x78>  // b.none
    63d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    63d4:	f94013f5 	ldr	x21, [sp, #32]
    63d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63dc:	d65f03c0 	ret
    63e0:	f9400813 	ldr	x19, [x0, #16]
    63e4:	97fffef3 	bl	5fb0 <fwp_rc_free_arr>
    63e8:	911902a0 	add	x0, x21, #0x640
    63ec:	f949d801 	ldr	x1, [x0, #5040]
    63f0:	f949ec00 	ldr	x0, [x0, #5080]
    63f4:	cb010261 	sub	x1, x19, x1
    63f8:	eb00403f 	cmp	x1, x0, lsl #16
    63fc:	54fffde2 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6400:	aa1303e0 	mov	x0, x19
    6404:	17ffffd2 	b	634c <fwp_drop1+0x2c>
    6408:	ca534660 	eor	x0, x19, x19, lsr #17
    640c:	911902b5 	add	x21, x21, #0x640
    6410:	ca402400 	eor	x0, x0, x0, lsr #9
    6414:	92401c00 	and	x0, x0, #0xff
    6418:	910a2402 	add	x2, x0, #0x289
    641c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6420:	8b020ea2 	add	x2, x21, x2, lsl #3
    6424:	f94a2400 	ldr	x0, [x0, #5192]
    6428:	b50000a0 	cbnz	x0, 643c <fwp_drop1+0x11c>
    642c:	14000013 	b	6478 <fwp_drop1+0x158>
    6430:	91004002 	add	x2, x0, #0x10
    6434:	f9400800 	ldr	x0, [x0, #16]
    6438:	b4000200 	cbz	x0, 6478 <fwp_drop1+0x158>
    643c:	f9400001 	ldr	x1, [x0]
    6440:	eb13003f 	cmp	x1, x19
    6444:	54ffff61 	b.ne	6430 <fwp_drop1+0x110>  // b.any
    6448:	f9400041 	ldr	x1, [x2]
    644c:	f9400420 	ldr	x0, [x1, #8]
    6450:	d1000400 	sub	x0, x0, #0x1
    6454:	f9000420 	str	x0, [x1, #8]
    6458:	f103f81f 	cmp	x0, #0xfe
    645c:	54fffae1 	b.ne	63b8 <fwp_drop1+0x98>  // b.any
    6460:	39400260 	ldrb	w0, [x19]
    6464:	7103fc1f 	cmp	w0, #0xff
    6468:	540000e0 	b.eq	6484 <fwp_drop1+0x164>  // b.none
    646c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6470:	39000260 	strb	w0, [x19]
    6474:	17ffffd1 	b	63b8 <fwp_drop1+0x98>
    6478:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    647c:	910ba000 	add	x0, x0, #0x2e8
    6480:	97fff78d 	bl	42b4 <fwp_trap>
    6484:	aa1303e0 	mov	x0, x19
    6488:	97fff7ab 	bl	4334 <fwp_rc_forget_slot.part.0>
    648c:	17fffff8 	b	646c <fwp_drop1+0x14c>

0000000000006490 <fwp_drop0>:
    6490:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6494:	910003fd 	mov	x29, sp
    6498:	a90153f3 	stp	x19, x20, [sp, #16]
    649c:	f90013f5 	str	x21, [sp, #32]
    64a0:	f0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    64a4:	911902b4 	add	x20, x21, #0x640
    64a8:	f949da81 	ldr	x1, [x20, #5040]
    64ac:	f949ee82 	ldr	x2, [x20, #5080]
    64b0:	cb010001 	sub	x1, x0, x1
    64b4:	eb02403f 	cmp	x1, x2, lsl #16
    64b8:	54000382 	b.cs	6528 <fwp_drop0+0x98>  // b.hs, b.nlast
    64bc:	d350fc22 	lsr	x2, x1, #16
    64c0:	f949fe84 	ldr	x4, [x20, #5112]
    64c4:	8b020842 	add	x2, x2, x2, lsl #2
    64c8:	d37df042 	lsl	x2, x2, #3
    64cc:	8b020083 	add	x3, x4, x2
    64d0:	f9401073 	ldr	x19, [x3, #32]
    64d4:	b40002b3 	cbz	x19, 6528 <fwp_drop0+0x98>
    64d8:	38626882 	ldrb	w2, [x4, x2]
    64dc:	7100085f 	cmp	w2, #0x2
    64e0:	540002c0 	b.eq	6538 <fwp_drop0+0xa8>  // b.none
    64e4:	7100045f 	cmp	w2, #0x1
    64e8:	54000201 	b.ne	6528 <fwp_drop0+0x98>  // b.any
    64ec:	29430864 	ldp	w4, w2, [x3, #24]
    64f0:	92403c21 	and	x1, x1, #0xffff
    64f4:	9b047c21 	mul	x1, x1, x4
    64f8:	d360fc21 	lsr	x1, x1, #32
    64fc:	eb02003f 	cmp	x1, x2
    6500:	54000142 	b.cs	6528 <fwp_drop0+0x98>  // b.hs, b.nlast
    6504:	8b010273 	add	x19, x19, x1
    6508:	39400261 	ldrb	w1, [x19]
    650c:	340000e1 	cbz	w1, 6528 <fwp_drop0+0x98>
    6510:	7100043f 	cmp	w1, #0x1
    6514:	540001e0 	b.eq	6550 <fwp_drop0+0xc0>  // b.none
    6518:	7103fc3f 	cmp	w1, #0xff
    651c:	540002e0 	b.eq	6578 <fwp_drop0+0xe8>  // b.none
    6520:	51000421 	sub	w1, w1, #0x1
    6524:	39000261 	strb	w1, [x19]
    6528:	a94153f3 	ldp	x19, x20, [sp, #16]
    652c:	f94013f5 	ldr	x21, [sp, #32]
    6530:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6534:	d65f03c0 	ret
    6538:	72003c3f 	tst	w1, #0xffff
    653c:	54fffe60 	b.eq	6508 <fwp_drop0+0x78>  // b.none
    6540:	a94153f3 	ldp	x19, x20, [sp, #16]
    6544:	f94013f5 	ldr	x21, [sp, #32]
    6548:	a8c37bfd 	ldp	x29, x30, [sp], #48
    654c:	d65f03c0 	ret
    6550:	f9400813 	ldr	x19, [x0, #16]
    6554:	97fffe97 	bl	5fb0 <fwp_rc_free_arr>
    6558:	911902a0 	add	x0, x21, #0x640
    655c:	f949d801 	ldr	x1, [x0, #5040]
    6560:	f949ec00 	ldr	x0, [x0, #5080]
    6564:	cb010261 	sub	x1, x19, x1
    6568:	eb00403f 	cmp	x1, x0, lsl #16
    656c:	54fffde2 	b.cs	6528 <fwp_drop0+0x98>  // b.hs, b.nlast
    6570:	aa1303e0 	mov	x0, x19
    6574:	17ffffd2 	b	64bc <fwp_drop0+0x2c>
    6578:	ca534660 	eor	x0, x19, x19, lsr #17
    657c:	911902b5 	add	x21, x21, #0x640
    6580:	ca402400 	eor	x0, x0, x0, lsr #9
    6584:	92401c00 	and	x0, x0, #0xff
    6588:	910a2402 	add	x2, x0, #0x289
    658c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6590:	8b020ea2 	add	x2, x21, x2, lsl #3
    6594:	f94a2400 	ldr	x0, [x0, #5192]
    6598:	b50000a0 	cbnz	x0, 65ac <fwp_drop0+0x11c>
    659c:	14000013 	b	65e8 <fwp_drop0+0x158>
    65a0:	91004002 	add	x2, x0, #0x10
    65a4:	f9400800 	ldr	x0, [x0, #16]
    65a8:	b4000200 	cbz	x0, 65e8 <fwp_drop0+0x158>
    65ac:	f9400001 	ldr	x1, [x0]
    65b0:	eb13003f 	cmp	x1, x19
    65b4:	54ffff61 	b.ne	65a0 <fwp_drop0+0x110>  // b.any
    65b8:	f9400041 	ldr	x1, [x2]
    65bc:	f9400420 	ldr	x0, [x1, #8]
    65c0:	d1000400 	sub	x0, x0, #0x1
    65c4:	f9000420 	str	x0, [x1, #8]
    65c8:	f103f81f 	cmp	x0, #0xfe
    65cc:	54fffae1 	b.ne	6528 <fwp_drop0+0x98>  // b.any
    65d0:	39400260 	ldrb	w0, [x19]
    65d4:	7103fc1f 	cmp	w0, #0xff
    65d8:	540000e0 	b.eq	65f4 <fwp_drop0+0x164>  // b.none
    65dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65e0:	39000260 	strb	w0, [x19]
    65e4:	17ffffd1 	b	6528 <fwp_drop0+0x98>
    65e8:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    65ec:	910ba000 	add	x0, x0, #0x2e8
    65f0:	97fff731 	bl	42b4 <fwp_trap>
    65f4:	aa1303e0 	mov	x0, x19
    65f8:	97fff74f 	bl	4334 <fwp_rc_forget_slot.part.0>
    65fc:	17fffff8 	b	65dc <fwp_drop0+0x14c>

0000000000006600 <fwp_arg_drop12>:
    6600:	7100003f 	cmp	w1, #0x0
    6604:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6608:	54000041 	b.ne	6610 <fwp_arg_drop12+0x10>  // b.any
    660c:	d65f03c0 	ret
    6610:	f9400000 	ldr	x0, [x0]
    6614:	17ffff9f 	b	6490 <fwp_drop0>
    6618:	d503201f 	nop
    661c:	d503201f 	nop

0000000000006620 <fwp_closure_drop>:
    6620:	f0000405 	adrp	x5, 89000 <fwp_root_context+0xba0>
    6624:	911900a4 	add	x4, x5, #0x640
    6628:	aa0003e1 	mov	x1, x0
    662c:	f949d882 	ldr	x2, [x4, #5040]
    6630:	f949ec80 	ldr	x0, [x4, #5080]
    6634:	cb020022 	sub	x2, x1, x2
    6638:	eb00405f 	cmp	x2, x0, lsl #16
    663c:	54000662 	b.cs	6708 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6640:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6644:	d350fc43 	lsr	x3, x2, #16
    6648:	910003fd 	mov	x29, sp
    664c:	8b030863 	add	x3, x3, x3, lsl #2
    6650:	f949fc84 	ldr	x4, [x4, #5112]
    6654:	d37df063 	lsl	x3, x3, #3
    6658:	f9000bf3 	str	x19, [sp, #16]
    665c:	8b030080 	add	x0, x4, x3
    6660:	f9401013 	ldr	x19, [x0, #32]
    6664:	b40002b3 	cbz	x19, 66b8 <fwp_closure_drop+0x98>
    6668:	38636883 	ldrb	w3, [x4, x3]
    666c:	7100087f 	cmp	w3, #0x2
    6670:	54000420 	b.eq	66f4 <fwp_closure_drop+0xd4>  // b.none
    6674:	7100047f 	cmp	w3, #0x1
    6678:	54000201 	b.ne	66b8 <fwp_closure_drop+0x98>  // b.any
    667c:	29430003 	ldp	w3, w0, [x0, #24]
    6680:	92403c42 	and	x2, x2, #0xffff
    6684:	9b037c42 	mul	x2, x2, x3
    6688:	d360fc42 	lsr	x2, x2, #32
    668c:	eb00005f 	cmp	x2, x0
    6690:	54000142 	b.cs	66b8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6694:	8b020273 	add	x19, x19, x2
    6698:	39400260 	ldrb	w0, [x19]
    669c:	340000e0 	cbz	w0, 66b8 <fwp_closure_drop+0x98>
    66a0:	7100041f 	cmp	w0, #0x1
    66a4:	54000100 	b.eq	66c4 <fwp_closure_drop+0xa4>  // b.none
    66a8:	7103fc1f 	cmp	w0, #0xff
    66ac:	54000300 	b.eq	670c <fwp_closure_drop+0xec>  // b.none
    66b0:	51000400 	sub	w0, w0, #0x1
    66b4:	39000260 	strb	w0, [x19]
    66b8:	f9400bf3 	ldr	x19, [sp, #16]
    66bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66c0:	d65f03c0 	ret
    66c4:	d53bd040 	mrs	x0, tpidr_el0
    66c8:	91400000 	add	x0, x0, #0x0, lsl #12
    66cc:	91004000 	add	x0, x0, #0x10
    66d0:	f9400000 	ldr	x0, [x0]
    66d4:	b4000080 	cbz	x0, 66e4 <fwp_closure_drop+0xc4>
    66d8:	f9400bf3 	ldr	x19, [sp, #16]
    66dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66e0:	17fff870 	b	48a0 <fwp_closure_drop_push>
    66e4:	f9400bf3 	ldr	x19, [sp, #16]
    66e8:	aa0103e0 	mov	x0, x1
    66ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66f0:	17fff8b1 	b	49b4 <fwp_closure_drop.part.0>
    66f4:	72003c5f 	tst	w2, #0xffff
    66f8:	54fffd00 	b.eq	6698 <fwp_closure_drop+0x78>  // b.none
    66fc:	f9400bf3 	ldr	x19, [sp, #16]
    6700:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6704:	d65f03c0 	ret
    6708:	d65f03c0 	ret
    670c:	ca534660 	eor	x0, x19, x19, lsr #17
    6710:	911900a5 	add	x5, x5, #0x640
    6714:	ca402400 	eor	x0, x0, x0, lsr #9
    6718:	92401c00 	and	x0, x0, #0xff
    671c:	910a2402 	add	x2, x0, #0x289
    6720:	8b000ca0 	add	x0, x5, x0, lsl #3
    6724:	8b020ca2 	add	x2, x5, x2, lsl #3
    6728:	f94a2400 	ldr	x0, [x0, #5192]
    672c:	b50000a0 	cbnz	x0, 6740 <fwp_closure_drop+0x120>
    6730:	14000013 	b	677c <fwp_closure_drop+0x15c>
    6734:	91004002 	add	x2, x0, #0x10
    6738:	f9400800 	ldr	x0, [x0, #16]
    673c:	b4000200 	cbz	x0, 677c <fwp_closure_drop+0x15c>
    6740:	f9400001 	ldr	x1, [x0]
    6744:	eb13003f 	cmp	x1, x19
    6748:	54ffff61 	b.ne	6734 <fwp_closure_drop+0x114>  // b.any
    674c:	f9400041 	ldr	x1, [x2]
    6750:	f9400420 	ldr	x0, [x1, #8]
    6754:	d1000400 	sub	x0, x0, #0x1
    6758:	f9000420 	str	x0, [x1, #8]
    675c:	f103f81f 	cmp	x0, #0xfe
    6760:	54fffac1 	b.ne	66b8 <fwp_closure_drop+0x98>  // b.any
    6764:	39400260 	ldrb	w0, [x19]
    6768:	7103fc1f 	cmp	w0, #0xff
    676c:	540000e0 	b.eq	6788 <fwp_closure_drop+0x168>  // b.none
    6770:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6774:	39000260 	strb	w0, [x19]
    6778:	17ffffd0 	b	66b8 <fwp_closure_drop+0x98>
    677c:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    6780:	910ba000 	add	x0, x0, #0x2e8
    6784:	97fff6cc 	bl	42b4 <fwp_trap>
    6788:	aa1303e0 	mov	x0, x19
    678c:	97fff6ea 	bl	4334 <fwp_rc_forget_slot.part.0>
    6790:	17fffff8 	b	6770 <fwp_closure_drop+0x150>

0000000000006794 <fwp_owned_tape_release>:
    6794:	b4000920 	cbz	x0, 68b8 <fwp_owned_tape_release+0x124>
    6798:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    679c:	910003fd 	mov	x29, sp
    67a0:	a90153f3 	stp	x19, x20, [sp, #16]
    67a4:	aa0003f3 	mov	x19, x0
    67a8:	f9400000 	ldr	x0, [x0]
    67ac:	b4000060 	cbz	x0, 67b8 <fwp_owned_tape_release+0x24>
    67b0:	f9400661 	ldr	x1, [x19, #8]
    67b4:	f9000401 	str	x1, [x0, #8]
    67b8:	f9400661 	ldr	x1, [x19, #8]
    67bc:	b4000041 	cbz	x1, 67c4 <fwp_owned_tape_release+0x30>
    67c0:	f9000020 	str	x0, [x1]
    67c4:	f9400a60 	ldr	x0, [x19, #16]
    67c8:	f9403401 	ldr	x1, [x0, #104]
    67cc:	b40005a1 	cbz	x1, 6880 <fwp_owned_tape_release+0xec>
    67d0:	a9450a60 	ldp	x0, x2, [x19, #80]
    67d4:	eb00005f 	cmp	x2, x0
    67d8:	540002cd 	b.le	6830 <fwp_owned_tape_release+0x9c>
    67dc:	d2800014 	mov	x20, #0x0                   	// #0
    67e0:	f90013f5 	str	x21, [sp, #32]
    67e4:	d2800015 	mov	x21, #0x0                   	// #0
    67e8:	f9402260 	ldr	x0, [x19, #64]
    67ec:	910006b5 	add	x21, x21, #0x1
    67f0:	f8746800 	ldr	x0, [x0, x20]
    67f4:	d63f0020 	blr	x1
    67f8:	f9402260 	ldr	x0, [x19, #64]
    67fc:	f9400a61 	ldr	x1, [x19, #16]
    6800:	8b140000 	add	x0, x0, x20
    6804:	91004294 	add	x20, x20, #0x10
    6808:	f9400400 	ldr	x0, [x0, #8]
    680c:	f9403421 	ldr	x1, [x1, #104]
    6810:	d63f0020 	blr	x1
    6814:	a9450261 	ldp	x1, x0, [x19, #80]
    6818:	cb010000 	sub	x0, x0, x1
    681c:	eb15001f 	cmp	x0, x21
    6820:	f9400a60 	ldr	x0, [x19, #16]
    6824:	f9403401 	ldr	x1, [x0, #104]
    6828:	54fffe0c 	b.gt	67e8 <fwp_owned_tape_release+0x54>
    682c:	f94013f5 	ldr	x21, [sp, #32]
    6830:	f9403663 	ldr	x3, [x19, #104]
    6834:	f9401262 	ldr	x2, [x19, #32]
    6838:	f100007f 	cmp	x3, #0x0
    683c:	540001ed 	b.le	6878 <fwp_owned_tape_release+0xe4>
    6840:	d2800014 	mov	x20, #0x0                   	// #0
    6844:	d503201f 	nop
    6848:	f9402660 	ldr	x0, [x19, #72]
    684c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6850:	eb02001f 	cmp	x0, x2
    6854:	540000c0 	b.eq	686c <fwp_owned_tape_release+0xd8>  // b.none
    6858:	d63f0020 	blr	x1
    685c:	f9400a60 	ldr	x0, [x19, #16]
    6860:	f9401262 	ldr	x2, [x19, #32]
    6864:	f9403663 	ldr	x3, [x19, #104]
    6868:	f9403401 	ldr	x1, [x0, #104]
    686c:	91000694 	add	x20, x20, #0x1
    6870:	eb14007f 	cmp	x3, x20
    6874:	54fffeac 	b.gt	6848 <fwp_owned_tape_release+0xb4>
    6878:	aa0203e0 	mov	x0, x2
    687c:	d63f0020 	blr	x1
    6880:	f9401660 	ldr	x0, [x19, #40]
    6884:	97ffff67 	bl	6620 <fwp_closure_drop>
    6888:	f9401a60 	ldr	x0, [x19, #48]
    688c:	97ffff65 	bl	6620 <fwp_closure_drop>
    6890:	f9401e60 	ldr	x0, [x19, #56]
    6894:	97ffff63 	bl	6620 <fwp_closure_drop>
    6898:	f9402260 	ldr	x0, [x19, #64]
    689c:	97fff741 	bl	45a0 <fwp_mem_free>
    68a0:	f9402660 	ldr	x0, [x19, #72]
    68a4:	97fff73f 	bl	45a0 <fwp_mem_free>
    68a8:	aa1303e0 	mov	x0, x19
    68ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    68b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68b4:	17fff73b 	b	45a0 <fwp_mem_free>
    68b8:	d65f03c0 	ret
    68bc:	d503201f 	nop

00000000000068c0 <fwp_tape_finish>:
    68c0:	d10203ff 	sub	sp, sp, #0x80
    68c4:	b0000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    68c8:	f947f421 	ldr	x1, [x1, #4072]
    68cc:	a9047bfd 	stp	x29, x30, [sp, #64]
    68d0:	910103fd 	add	x29, sp, #0x40
    68d4:	a9065bf5 	stp	x21, x22, [sp, #96]
    68d8:	a90763f7 	stp	x23, x24, [sp, #112]
    68dc:	d0000157 	adrp	x23, 30000 <__data_start>
    68e0:	910182f6 	add	x22, x23, #0x60
    68e4:	f9400022 	ldr	x2, [x1]
    68e8:	f9001fe2 	str	x2, [sp, #56]
    68ec:	d2800002 	mov	x2, #0x0                   	// #0
    68f0:	910342c0 	add	x0, x22, #0xd0
    68f4:	97fff5c0 	bl	3ff4 <fwp_tape_buffers_dispose>
    68f8:	f90086df 	str	xzr, [x22, #264]
    68fc:	f94092c0 	ldr	x0, [x22, #288]
    6900:	f100001f 	cmp	x0, #0x0
    6904:	5400034d 	b.le	696c <fwp_tape_finish+0xac>
    6908:	910003f8 	mov	x24, sp
    690c:	d2800015 	mov	x21, #0x0                   	// #0
    6910:	a90553f3 	stp	x19, x20, [sp, #80]
    6914:	d2800014 	mov	x20, #0x0                   	// #0
    6918:	91000694 	add	x20, x20, #0x1
    691c:	f94046d3 	ldr	x19, [x22, #136]
    6920:	8b150273 	add	x19, x19, x21
    6924:	9101a2b5 	add	x21, x21, #0x68
    6928:	aa1303e0 	mov	x0, x19
    692c:	97fff19a 	bl	2f94 <fwp_tape_unlink_scope>
    6930:	aa1803e0 	mov	x0, x24
    6934:	a9440663 	ldp	x3, x1, [x19, #64]
    6938:	f9001be1 	str	x1, [sp, #48]
    693c:	f9400e62 	ldr	x2, [x19, #24]
    6940:	a9020be3 	stp	x3, x2, [sp, #32]
    6944:	ad410261 	ldp	q1, q0, [x19, #32]
    6948:	ad0003e1 	stp	q1, q0, [sp]
    694c:	97fff5aa 	bl	3ff4 <fwp_tape_buffers_dispose>
    6950:	f9403260 	ldr	x0, [x19, #96]
    6954:	97ffff90 	bl	6794 <fwp_owned_tape_release>
    6958:	f900327f 	str	xzr, [x19, #96]
    695c:	f94092c0 	ldr	x0, [x22, #288]
    6960:	eb14001f 	cmp	x0, x20
    6964:	54fffdac 	b.gt	6918 <fwp_tape_finish+0x58>
    6968:	a94553f3 	ldp	x19, x20, [sp, #80]
    696c:	910182e0 	add	x0, x23, #0x60
    6970:	f9404400 	ldr	x0, [x0, #136]
    6974:	b4000040 	cbz	x0, 697c <fwp_tape_finish+0xbc>
    6978:	97fff57e 	bl	3f70 <ad_raw_free.part.0>
    697c:	910182f7 	add	x23, x23, #0x60
    6980:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    6984:	f947f400 	ldr	x0, [x0, #4072]
    6988:	f90046ff 	str	xzr, [x23, #136]
    698c:	f9008aff 	str	xzr, [x23, #272]
    6990:	f90092ff 	str	xzr, [x23, #288]
    6994:	f900b2ff 	str	xzr, [x23, #352]
    6998:	f9401fe2 	ldr	x2, [sp, #56]
    699c:	f9400001 	ldr	x1, [x0]
    69a0:	eb010042 	subs	x2, x2, x1
    69a4:	d2800001 	mov	x1, #0x0                   	// #0
    69a8:	540000c1 	b.ne	69c0 <fwp_tape_finish+0x100>  // b.any
    69ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    69b0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    69b4:	a94763f7 	ldp	x23, x24, [sp, #112]
    69b8:	910203ff 	add	sp, sp, #0x80
    69bc:	d65f03c0 	ret
    69c0:	a90553f3 	stp	x19, x20, [sp, #80]
    69c4:	97ffef93 	bl	2810 <__stack_chk_fail@plt>
    69c8:	d503201f 	nop
    69cc:	d503201f 	nop

00000000000069d0 <fwp_tape_scope_release>:
    69d0:	d10243ff 	sub	sp, sp, #0x90
    69d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    69d8:	910103fd 	add	x29, sp, #0x40
    69dc:	a90553f3 	stp	x19, x20, [sp, #80]
    69e0:	aa0003f4 	mov	x20, x0
    69e4:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    69e8:	f947f400 	ldr	x0, [x0, #4072]
    69ec:	b9400285 	ldr	w5, [x20]
    69f0:	f9400001 	ldr	x1, [x0]
    69f4:	f9001fe1 	str	x1, [sp, #56]
    69f8:	d2800001 	mov	x1, #0x0                   	// #0
    69fc:	37f806c5 	tbnz	w5, #31, 6ad4 <fwp_tape_scope_release+0x104>
    6a00:	a90763f7 	stp	x23, x24, [sp, #112]
    6a04:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6a08:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    6a0c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6a10:	d0000153 	adrp	x19, 30000 <__data_start>
    6a14:	910003f7 	mov	x23, sp
    6a18:	91018273 	add	x19, x19, #0x60
    6a1c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6a20:	a9065bf5 	stp	x21, x22, [sp, #96]
    6a24:	52800d16 	mov	w22, #0x68                  	// #104
    6a28:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    6a2c:	f90043f9 	str	x25, [sp, #128]
    6a30:	14000006 	b	6a48 <fwp_tape_scope_release+0x78>
    6a34:	97fff570 	bl	3ff4 <fwp_tape_buffers_dispose>
    6a38:	aa1903e0 	mov	x0, x25
    6a3c:	97ffff56 	bl	6794 <fwp_owned_tape_release>
    6a40:	b9400285 	ldr	w5, [x20]
    6a44:	37f80425 	tbnz	w5, #31, 6ac8 <fwp_tape_scope_release+0xf8>
    6a48:	f9404666 	ldr	x6, [x19, #136]
    6a4c:	9b367ca5 	smull	x5, w5, w22
    6a50:	8b0500c0 	add	x0, x6, x5
    6a54:	97fff150 	bl	2f94 <fwp_tape_unlink_scope>
    6a58:	ad410001 	ldp	q1, q0, [x0, #32]
    6a5c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6a60:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6a64:	f9400c03 	ldr	x3, [x0, #24]
    6a68:	ad0003e1 	stp	q1, q0, [sp]
    6a6c:	b86568c1 	ldr	w1, [x6, x5]
    6a70:	a9440804 	ldp	x4, x2, [x0, #64]
    6a74:	b900041f 	str	wzr, [x0, #4]
    6a78:	f9403019 	ldr	x25, [x0, #96]
    6a7c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6a80:	f9000c1f 	str	xzr, [x0, #24]
    6a84:	a9020fe4 	stp	x4, x3, [sp, #32]
    6a88:	f9001be2 	str	x2, [sp, #48]
    6a8c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6a90:	f900301f 	str	xzr, [x0, #96]
    6a94:	6b15003f 	cmp	w1, w21
    6a98:	540000e8 	b.hi	6ab4 <fwp_tape_scope_release+0xe4>  // b.pmore
    6a9c:	9343fca5 	asr	x5, x5, #3
    6aa0:	f940b260 	ldr	x0, [x19, #352]
    6aa4:	9b187ca5 	mul	x5, x5, x24
    6aa8:	eb0000bf 	cmp	x5, x0
    6aac:	5400004a 	b.ge	6ab4 <fwp_tape_scope_release+0xe4>  // b.tcont
    6ab0:	f900b265 	str	x5, [x19, #352]
    6ab4:	aa1703e0 	mov	x0, x23
    6ab8:	b5fffbf9 	cbnz	x25, 6a34 <fwp_tape_scope_release+0x64>
    6abc:	97fff596 	bl	4114 <fwp_tape_buffers_release>
    6ac0:	b9400285 	ldr	w5, [x20]
    6ac4:	36fffc25 	tbz	w5, #31, 6a48 <fwp_tape_scope_release+0x78>
    6ac8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6acc:	a94763f7 	ldp	x23, x24, [sp, #112]
    6ad0:	f94043f9 	ldr	x25, [sp, #128]
    6ad4:	b0000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    6ad8:	f947f400 	ldr	x0, [x0, #4072]
    6adc:	f9401fe2 	ldr	x2, [sp, #56]
    6ae0:	f9400001 	ldr	x1, [x0]
    6ae4:	eb010042 	subs	x2, x2, x1
    6ae8:	d2800001 	mov	x1, #0x0                   	// #0
    6aec:	540000a1 	b.ne	6b00 <fwp_tape_scope_release+0x130>  // b.any
    6af0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6af4:	a94553f3 	ldp	x19, x20, [sp, #80]
    6af8:	910243ff 	add	sp, sp, #0x90
    6afc:	d65f03c0 	ret
    6b00:	a9065bf5 	stp	x21, x22, [sp, #96]
    6b04:	a90763f7 	stp	x23, x24, [sp, #112]
    6b08:	f90043f9 	str	x25, [sp, #128]
    6b0c:	97ffef41 	bl	2810 <__stack_chk_fail@plt>

0000000000006b10 <fwp_task_dispose>:
    6b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b14:	910003fd 	mov	x29, sp
    6b18:	f9000bf3 	str	x19, [sp, #16]
    6b1c:	aa0003f3 	mov	x19, x0
    6b20:	39414000 	ldrb	w0, [x0, #80]
    6b24:	36000720 	tbz	w0, #0, 6c08 <fwp_task_dispose+0xf8>
    6b28:	f9400a60 	ldr	x0, [x19, #16]
    6b2c:	b50006e0 	cbnz	x0, 6c08 <fwp_task_dispose+0xf8>
    6b30:	a9478660 	ldp	x0, x1, [x19, #120]
    6b34:	39014e7f 	strb	wzr, [x19, #83]
    6b38:	f9003e7f 	str	xzr, [x19, #120]
    6b3c:	f100003f 	cmp	x1, #0x0
    6b40:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6b44:	54000040 	b.eq	6b4c <fwp_task_dispose+0x3c>  // b.none
    6b48:	d63f0020 	blr	x1
    6b4c:	f9405660 	ldr	x0, [x19, #168]
    6b50:	97fff694 	bl	45a0 <fwp_mem_free>
    6b54:	f900567f 	str	xzr, [x19, #168]
    6b58:	b9405e60 	ldr	w0, [x19, #92]
    6b5c:	7100041f 	cmp	w0, #0x1
    6b60:	54000420 	b.eq	6be4 <fwp_task_dispose+0xd4>  // b.none
    6b64:	f0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    6b68:	91190042 	add	x2, x2, #0x640
    6b6c:	f949d840 	ldr	x0, [x2, #5040]
    6b70:	f949ec41 	ldr	x1, [x2, #5080]
    6b74:	cb000260 	sub	x0, x19, x0
    6b78:	eb01401f 	cmp	x0, x1, lsl #16
    6b7c:	540002e2 	b.cs	6bd8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6b80:	d350fc01 	lsr	x1, x0, #16
    6b84:	f949fc44 	ldr	x4, [x2, #5112]
    6b88:	8b010821 	add	x1, x1, x1, lsl #2
    6b8c:	d37df021 	lsl	x1, x1, #3
    6b90:	8b010083 	add	x3, x4, x1
    6b94:	f9401062 	ldr	x2, [x3, #32]
    6b98:	b4000202 	cbz	x2, 6bd8 <fwp_task_dispose+0xc8>
    6b9c:	38616881 	ldrb	w1, [x4, x1]
    6ba0:	7100083f 	cmp	w1, #0x2
    6ba4:	54000280 	b.eq	6bf4 <fwp_task_dispose+0xe4>  // b.none
    6ba8:	7100043f 	cmp	w1, #0x1
    6bac:	54000161 	b.ne	6bd8 <fwp_task_dispose+0xc8>  // b.any
    6bb0:	29430464 	ldp	w4, w1, [x3, #24]
    6bb4:	92403c00 	and	x0, x0, #0xffff
    6bb8:	9b047c00 	mul	x0, x0, x4
    6bbc:	d360fc00 	lsr	x0, x0, #32
    6bc0:	eb01001f 	cmp	x0, x1
    6bc4:	540000a2 	b.cs	6bd8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6bc8:	8b000042 	add	x2, x2, x0
    6bcc:	39400040 	ldrb	w0, [x2]
    6bd0:	7100041f 	cmp	w0, #0x1
    6bd4:	54000080 	b.eq	6be4 <fwp_task_dispose+0xd4>  // b.none
    6bd8:	f9400bf3 	ldr	x19, [sp, #16]
    6bdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6be0:	d65f03c0 	ret
    6be4:	aa1303e0 	mov	x0, x19
    6be8:	f9400bf3 	ldr	x19, [sp, #16]
    6bec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bf0:	17fff66c 	b	45a0 <fwp_mem_free>
    6bf4:	72003c1f 	tst	w0, #0xffff
    6bf8:	54fffea0 	b.eq	6bcc <fwp_task_dispose+0xbc>  // b.none
    6bfc:	f9400bf3 	ldr	x19, [sp, #16]
    6c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c04:	d65f03c0 	ret
    6c08:	97ffef16 	bl	2860 <abort@plt>
    6c0c:	d503201f 	nop

0000000000006c10 <fwp_free_zombie>:
    6c10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c14:	910003fd 	mov	x29, sp
    6c18:	a90153f3 	stp	x19, x20, [sp, #16]
    6c1c:	d0000154 	adrp	x20, 30000 <__data_start>
    6c20:	91018281 	add	x1, x20, #0x60
    6c24:	f940b433 	ldr	x19, [x1, #360]
    6c28:	b4000333 	cbz	x19, 6c8c <fwp_free_zombie+0x7c>
    6c2c:	f9404c20 	ldr	x0, [x1, #152]
    6c30:	eb00027f 	cmp	x19, x0
    6c34:	540002c0 	b.eq	6c8c <fwp_free_zombie+0x7c>  // b.none
    6c38:	b9417022 	ldr	w2, [x1, #368]
    6c3c:	f9400a60 	ldr	x0, [x19, #16]
    6c40:	7100fc5f 	cmp	w2, #0x3f
    6c44:	5400078c 	b.gt	6d34 <fwp_free_zombie+0x124>
    6c48:	91060023 	add	x3, x1, #0x180
    6c4c:	11000444 	add	w4, w2, #0x1
    6c50:	b9017024 	str	w4, [x1, #368]
    6c54:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6c58:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6c5c:	a9530261 	ldp	x1, x0, [x19, #304]
    6c60:	b4000741 	cbz	x1, 6d48 <fwp_free_zombie+0x138>
    6c64:	f9009c20 	str	x0, [x1, #312]
    6c68:	b4000040 	cbz	x0, 6c70 <fwp_free_zombie+0x60>
    6c6c:	f9009801 	str	x1, [x0, #304]
    6c70:	91018294 	add	x20, x20, #0x60
    6c74:	b9405e60 	ldr	w0, [x19, #92]
    6c78:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6c7c:	f900b69f 	str	xzr, [x20, #360]
    6c80:	34000140 	cbz	w0, 6ca8 <fwp_free_zombie+0x98>
    6c84:	7100041f 	cmp	w0, #0x1
    6c88:	54000080 	b.eq	6c98 <fwp_free_zombie+0x88>  // b.none
    6c8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c94:	d65f03c0 	ret
    6c98:	aa1303e0 	mov	x0, x19
    6c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ca0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ca4:	17ffff9b 	b	6b10 <fwp_task_dispose>
    6ca8:	f0000404 	adrp	x4, 89000 <fwp_root_context+0xba0>
    6cac:	91190082 	add	x2, x4, #0x640
    6cb0:	f949d841 	ldr	x1, [x2, #5040]
    6cb4:	f949ec40 	ldr	x0, [x2, #5080]
    6cb8:	cb010261 	sub	x1, x19, x1
    6cbc:	eb00403f 	cmp	x1, x0, lsl #16
    6cc0:	54fffe62 	b.cs	6c8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6cc4:	d350fc20 	lsr	x0, x1, #16
    6cc8:	f949fc43 	ldr	x3, [x2, #5112]
    6ccc:	8b000800 	add	x0, x0, x0, lsl #2
    6cd0:	d37df000 	lsl	x0, x0, #3
    6cd4:	8b000062 	add	x2, x3, x0
    6cd8:	f9401054 	ldr	x20, [x2, #32]
    6cdc:	b4fffd94 	cbz	x20, 6c8c <fwp_free_zombie+0x7c>
    6ce0:	38606860 	ldrb	w0, [x3, x0]
    6ce4:	7100081f 	cmp	w0, #0x2
    6ce8:	54000360 	b.eq	6d54 <fwp_free_zombie+0x144>  // b.none
    6cec:	7100041f 	cmp	w0, #0x1
    6cf0:	54fffce1 	b.ne	6c8c <fwp_free_zombie+0x7c>  // b.any
    6cf4:	29430043 	ldp	w3, w0, [x2, #24]
    6cf8:	92403c21 	and	x1, x1, #0xffff
    6cfc:	9b037c21 	mul	x1, x1, x3
    6d00:	d360fc21 	lsr	x1, x1, #32
    6d04:	eb00003f 	cmp	x1, x0
    6d08:	54fffc22 	b.cs	6c8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6d0c:	8b010294 	add	x20, x20, x1
    6d10:	39400280 	ldrb	w0, [x20]
    6d14:	34fffbc0 	cbz	w0, 6c8c <fwp_free_zombie+0x7c>
    6d18:	7100041f 	cmp	w0, #0x1
    6d1c:	54fffbe0 	b.eq	6c98 <fwp_free_zombie+0x88>  // b.none
    6d20:	7103fc1f 	cmp	w0, #0xff
    6d24:	540001e0 	b.eq	6d60 <fwp_free_zombie+0x150>  // b.none
    6d28:	51000400 	sub	w0, w0, #0x1
    6d2c:	39000280 	strb	w0, [x20]
    6d30:	17ffffd7 	b	6c8c <fwp_free_zombie+0x7c>
    6d34:	f9400e61 	ldr	x1, [x19, #24]
    6d38:	97ffeefe 	bl	2930 <munmap@plt>
    6d3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6d40:	a9530261 	ldp	x1, x0, [x19, #304]
    6d44:	b5fff901 	cbnz	x1, 6c64 <fwp_free_zombie+0x54>
    6d48:	91018282 	add	x2, x20, #0x60
    6d4c:	f901c040 	str	x0, [x2, #896]
    6d50:	17ffffc6 	b	6c68 <fwp_free_zombie+0x58>
    6d54:	72003c3f 	tst	w1, #0xffff
    6d58:	54fff9a1 	b.ne	6c8c <fwp_free_zombie+0x7c>  // b.any
    6d5c:	17ffffed 	b	6d10 <fwp_free_zombie+0x100>
    6d60:	ca544680 	eor	x0, x20, x20, lsr #17
    6d64:	91190084 	add	x4, x4, #0x640
    6d68:	ca402400 	eor	x0, x0, x0, lsr #9
    6d6c:	92401c00 	and	x0, x0, #0xff
    6d70:	910a2402 	add	x2, x0, #0x289
    6d74:	8b000c80 	add	x0, x4, x0, lsl #3
    6d78:	8b020c82 	add	x2, x4, x2, lsl #3
    6d7c:	f94a2400 	ldr	x0, [x0, #5192]
    6d80:	b50000a0 	cbnz	x0, 6d94 <fwp_free_zombie+0x184>
    6d84:	14000013 	b	6dd0 <fwp_free_zombie+0x1c0>
    6d88:	91004002 	add	x2, x0, #0x10
    6d8c:	f9400800 	ldr	x0, [x0, #16]
    6d90:	b4000200 	cbz	x0, 6dd0 <fwp_free_zombie+0x1c0>
    6d94:	f9400001 	ldr	x1, [x0]
    6d98:	eb14003f 	cmp	x1, x20
    6d9c:	54ffff61 	b.ne	6d88 <fwp_free_zombie+0x178>  // b.any
    6da0:	f9400041 	ldr	x1, [x2]
    6da4:	f9400420 	ldr	x0, [x1, #8]
    6da8:	d1000400 	sub	x0, x0, #0x1
    6dac:	f9000420 	str	x0, [x1, #8]
    6db0:	f103f81f 	cmp	x0, #0xfe
    6db4:	54fff6c1 	b.ne	6c8c <fwp_free_zombie+0x7c>  // b.any
    6db8:	39400280 	ldrb	w0, [x20]
    6dbc:	7103fc1f 	cmp	w0, #0xff
    6dc0:	540000e0 	b.eq	6ddc <fwp_free_zombie+0x1cc>  // b.none
    6dc4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6dc8:	39000280 	strb	w0, [x20]
    6dcc:	17ffffb0 	b	6c8c <fwp_free_zombie+0x7c>
    6dd0:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    6dd4:	910ba000 	add	x0, x0, #0x2e8
    6dd8:	97fff537 	bl	42b4 <fwp_trap>
    6ddc:	aa1403e0 	mov	x0, x20
    6de0:	97fff555 	bl	4334 <fwp_rc_forget_slot.part.0>
    6de4:	17fffff8 	b	6dc4 <fwp_free_zombie+0x1b4>
    6de8:	d503201f 	nop
    6dec:	d503201f 	nop

0000000000006df0 <fwp_block>:
    6df0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6df4:	910003fd 	mov	x29, sp
    6df8:	a90153f3 	stp	x19, x20, [sp, #16]
    6dfc:	d0000153 	adrp	x19, 30000 <__data_start>
    6e00:	91018274 	add	x20, x19, #0x60
    6e04:	f9406682 	ldr	x2, [x20, #200]
    6e08:	b4000642 	cbz	x2, 6ed0 <fwp_block+0xe0>
    6e0c:	91018261 	add	x1, x19, #0x60
    6e10:	f9408040 	ldr	x0, [x2, #256]
    6e14:	f9006420 	str	x0, [x1, #200]
    6e18:	b40006a0 	cbz	x0, 6eec <fwp_block+0xfc>
    6e1c:	d503201f 	nop
    6e20:	91018263 	add	x3, x19, #0x60
    6e24:	3901505f 	strb	wzr, [x2, #84]
    6e28:	f9404c64 	ldr	x4, [x3, #152]
    6e2c:	eb02009f 	cmp	x4, x2
    6e30:	54000440 	b.eq	6eb8 <fwp_block+0xc8>  // b.none
    6e34:	f941c465 	ldr	x5, [x3, #904]
    6e38:	f9004c62 	str	x2, [x3, #152]
    6e3c:	f9400441 	ldr	x1, [x2, #8]
    6e40:	f9004885 	str	x5, [x4, #144]
    6e44:	f941c865 	ldr	x5, [x3, #912]
    6e48:	f9004c85 	str	x5, [x4, #152]
    6e4c:	f941cc65 	ldr	x5, [x3, #920]
    6e50:	f9005085 	str	x5, [x4, #160]
    6e54:	f941d065 	ldr	x5, [x3, #928]
    6e58:	f9005485 	str	x5, [x4, #168]
    6e5c:	f941d465 	ldr	x5, [x3, #936]
    6e60:	f9005885 	str	x5, [x4, #176]
    6e64:	f941d865 	ldr	x5, [x3, #944]
    6e68:	f9005c85 	str	x5, [x4, #184]
    6e6c:	f941dc65 	ldr	x5, [x3, #952]
    6e70:	f9006085 	str	x5, [x4, #192]
    6e74:	f9400480 	ldr	x0, [x4, #8]
    6e78:	f9404844 	ldr	x4, [x2, #144]
    6e7c:	f901c464 	str	x4, [x3, #904]
    6e80:	f9404c44 	ldr	x4, [x2, #152]
    6e84:	f901c864 	str	x4, [x3, #912]
    6e88:	f9405044 	ldr	x4, [x2, #160]
    6e8c:	f901cc64 	str	x4, [x3, #920]
    6e90:	f9405444 	ldr	x4, [x2, #168]
    6e94:	f901d064 	str	x4, [x3, #928]
    6e98:	f9405844 	ldr	x4, [x2, #176]
    6e9c:	f901d464 	str	x4, [x3, #936]
    6ea0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6ea4:	f901d864 	str	x4, [x3, #944]
    6ea8:	f901dc62 	str	x2, [x3, #952]
    6eac:	97ffee71 	bl	2870 <swapcontext@plt>
    6eb0:	97ffff58 	bl	6c10 <fwp_free_zombie>
    6eb4:	d503201f 	nop
    6eb8:	91018260 	add	x0, x19, #0x60
    6ebc:	b943c000 	ldr	w0, [x0, #960]
    6ec0:	340001a0 	cbz	w0, 6ef4 <fwp_block+0x104>
    6ec4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ec8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ecc:	d65f03c0 	ret
    6ed0:	97fff740 	bl	4bd0 <fwp_poll_events>
    6ed4:	f9406682 	ldr	x2, [x20, #200]
    6ed8:	b4ffffc2 	cbz	x2, 6ed0 <fwp_block+0xe0>
    6edc:	91018261 	add	x1, x19, #0x60
    6ee0:	f9408040 	ldr	x0, [x2, #256]
    6ee4:	f9006420 	str	x0, [x1, #200]
    6ee8:	b5fff9c0 	cbnz	x0, 6e20 <fwp_block+0x30>
    6eec:	f900603f 	str	xzr, [x1, #192]
    6ef0:	17ffffcc 	b	6e20 <fwp_block+0x30>
    6ef4:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x70>
    6ef8:	91160000 	add	x0, x0, #0x580
    6efc:	97ffeea9 	bl	29a0 <getenv@plt>
    6f00:	5284e202 	mov	w2, #0x2710                	// #10000
    6f04:	b4000060 	cbz	x0, 6f10 <fwp_block+0x120>
    6f08:	39400001 	ldrb	w1, [x0]
    6f0c:	350000c1 	cbnz	w1, 6f24 <fwp_block+0x134>
    6f10:	91018273 	add	x19, x19, #0x60
    6f14:	b903c262 	str	w2, [x19, #960]
    6f18:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f20:	d65f03c0 	ret
    6f24:	52800142 	mov	w2, #0xa                   	// #10
    6f28:	d2800001 	mov	x1, #0x0                   	// #0
    6f2c:	97ffeded 	bl	26e0 <strtoll@plt>
    6f30:	d1000403 	sub	x3, x0, #0x1
    6f34:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6f38:	eb02007f 	cmp	x3, x2
    6f3c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6f40:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6f44:	17fffff3 	b	6f10 <fwp_block+0x120>
    6f48:	d503201f 	nop
    6f4c:	d503201f 	nop

0000000000006f50 <fwp_drop4>:
    6f50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6f54:	910003fd 	mov	x29, sp
    6f58:	a90153f3 	stp	x19, x20, [sp, #16]
    6f5c:	f0000413 	adrp	x19, 89000 <fwp_root_context+0xba0>
    6f60:	f90013f5 	str	x21, [sp, #32]
    6f64:	91190275 	add	x21, x19, #0x640
    6f68:	f949daa1 	ldr	x1, [x21, #5040]
    6f6c:	f949eea2 	ldr	x2, [x21, #5080]
    6f70:	cb010001 	sub	x1, x0, x1
    6f74:	eb02403f 	cmp	x1, x2, lsl #16
    6f78:	54000382 	b.cs	6fe8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f7c:	d350fc22 	lsr	x2, x1, #16
    6f80:	f949fea3 	ldr	x3, [x21, #5112]
    6f84:	8b020842 	add	x2, x2, x2, lsl #2
    6f88:	d37df042 	lsl	x2, x2, #3
    6f8c:	8b020064 	add	x4, x3, x2
    6f90:	f9401094 	ldr	x20, [x4, #32]
    6f94:	b40002b4 	cbz	x20, 6fe8 <fwp_drop4+0x98>
    6f98:	38626862 	ldrb	w2, [x3, x2]
    6f9c:	7100085f 	cmp	w2, #0x2
    6fa0:	540007a0 	b.eq	7094 <fwp_drop4+0x144>  // b.none
    6fa4:	7100045f 	cmp	w2, #0x1
    6fa8:	54000201 	b.ne	6fe8 <fwp_drop4+0x98>  // b.any
    6fac:	29430885 	ldp	w5, w2, [x4, #24]
    6fb0:	92403c21 	and	x1, x1, #0xffff
    6fb4:	9b057c21 	mul	x1, x1, x5
    6fb8:	d360fc21 	lsr	x1, x1, #32
    6fbc:	eb02003f 	cmp	x1, x2
    6fc0:	54000142 	b.cs	6fe8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6fc4:	8b010294 	add	x20, x20, x1
    6fc8:	39400281 	ldrb	w1, [x20]
    6fcc:	340000e1 	cbz	w1, 6fe8 <fwp_drop4+0x98>
    6fd0:	7100043f 	cmp	w1, #0x1
    6fd4:	54000120 	b.eq	6ff8 <fwp_drop4+0xa8>  // b.none
    6fd8:	7103fc3f 	cmp	w1, #0xff
    6fdc:	540007c0 	b.eq	70d4 <fwp_drop4+0x184>  // b.none
    6fe0:	51000421 	sub	w1, w1, #0x1
    6fe4:	39000281 	strb	w1, [x20]
    6fe8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fec:	f94013f5 	ldr	x21, [sp, #32]
    6ff0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ff4:	d65f03c0 	ret
    6ff8:	f9400001 	ldr	x1, [x0]
    6ffc:	b7f80581 	tbnz	x1, #63, 70ac <fwp_drop4+0x15c>
    7000:	91190273 	add	x19, x19, #0x640
    7004:	f949da61 	ldr	x1, [x19, #5040]
    7008:	f949ee62 	ldr	x2, [x19, #5080]
    700c:	cb010001 	sub	x1, x0, x1
    7010:	eb02403f 	cmp	x1, x2, lsl #16
    7014:	54fffea2 	b.cs	6fe8 <fwp_drop4+0x98>  // b.hs, b.nlast
    7018:	d350fc22 	lsr	x2, x1, #16
    701c:	8b020842 	add	x2, x2, x2, lsl #2
    7020:	d37df042 	lsl	x2, x2, #3
    7024:	8b020065 	add	x5, x3, x2
    7028:	f94010a4 	ldr	x4, [x5, #32]
    702c:	b4fffde4 	cbz	x4, 6fe8 <fwp_drop4+0x98>
    7030:	38626862 	ldrb	w2, [x3, x2]
    7034:	7100085f 	cmp	w2, #0x2
    7038:	54000220 	b.eq	707c <fwp_drop4+0x12c>  // b.none
    703c:	7100045f 	cmp	w2, #0x1
    7040:	54fffd41 	b.ne	6fe8 <fwp_drop4+0x98>  // b.any
    7044:	294308a3 	ldp	w3, w2, [x5, #24]
    7048:	92403c21 	and	x1, x1, #0xffff
    704c:	9b037c21 	mul	x1, x1, x3
    7050:	d360fc21 	lsr	x1, x1, #32
    7054:	eb02003f 	cmp	x1, x2
    7058:	54fffc82 	b.cs	6fe8 <fwp_drop4+0x98>  // b.hs, b.nlast
    705c:	8b010084 	add	x4, x4, x1
    7060:	39400081 	ldrb	w1, [x4]
    7064:	7100043f 	cmp	w1, #0x1
    7068:	54fffc01 	b.ne	6fe8 <fwp_drop4+0x98>  // b.any
    706c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7070:	f94013f5 	ldr	x21, [sp, #32]
    7074:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7078:	17fff54a 	b	45a0 <fwp_mem_free>
    707c:	72003c3f 	tst	w1, #0xffff
    7080:	54ffff00 	b.eq	7060 <fwp_drop4+0x110>  // b.none
    7084:	a94153f3 	ldp	x19, x20, [sp, #16]
    7088:	f94013f5 	ldr	x21, [sp, #32]
    708c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7090:	d65f03c0 	ret
    7094:	72003c3f 	tst	w1, #0xffff
    7098:	54fff980 	b.eq	6fc8 <fwp_drop4+0x78>  // b.none
    709c:	a94153f3 	ldp	x19, x20, [sp, #16]
    70a0:	f94013f5 	ldr	x21, [sp, #32]
    70a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70a8:	d65f03c0 	ret
    70ac:	f9400414 	ldr	x20, [x0, #8]
    70b0:	97fffbc0 	bl	5fb0 <fwp_rc_free_arr>
    70b4:	91190260 	add	x0, x19, #0x640
    70b8:	f949d801 	ldr	x1, [x0, #5040]
    70bc:	f949ec00 	ldr	x0, [x0, #5080]
    70c0:	cb010281 	sub	x1, x20, x1
    70c4:	eb00403f 	cmp	x1, x0, lsl #16
    70c8:	54fff902 	b.cs	6fe8 <fwp_drop4+0x98>  // b.hs, b.nlast
    70cc:	aa1403e0 	mov	x0, x20
    70d0:	17ffffab 	b	6f7c <fwp_drop4+0x2c>
    70d4:	ca544680 	eor	x0, x20, x20, lsr #17
    70d8:	91190273 	add	x19, x19, #0x640
    70dc:	ca402400 	eor	x0, x0, x0, lsr #9
    70e0:	92401c00 	and	x0, x0, #0xff
    70e4:	910a2402 	add	x2, x0, #0x289
    70e8:	8b000e60 	add	x0, x19, x0, lsl #3
    70ec:	8b020e62 	add	x2, x19, x2, lsl #3
    70f0:	f94a2400 	ldr	x0, [x0, #5192]
    70f4:	b50000a0 	cbnz	x0, 7108 <fwp_drop4+0x1b8>
    70f8:	14000013 	b	7144 <fwp_drop4+0x1f4>
    70fc:	91004002 	add	x2, x0, #0x10
    7100:	f9400800 	ldr	x0, [x0, #16]
    7104:	b4000200 	cbz	x0, 7144 <fwp_drop4+0x1f4>
    7108:	f9400001 	ldr	x1, [x0]
    710c:	eb14003f 	cmp	x1, x20
    7110:	54ffff61 	b.ne	70fc <fwp_drop4+0x1ac>  // b.any
    7114:	f9400041 	ldr	x1, [x2]
    7118:	f9400420 	ldr	x0, [x1, #8]
    711c:	d1000400 	sub	x0, x0, #0x1
    7120:	f9000420 	str	x0, [x1, #8]
    7124:	f103f81f 	cmp	x0, #0xfe
    7128:	54fff601 	b.ne	6fe8 <fwp_drop4+0x98>  // b.any
    712c:	39400280 	ldrb	w0, [x20]
    7130:	7103fc1f 	cmp	w0, #0xff
    7134:	540000e0 	b.eq	7150 <fwp_drop4+0x200>  // b.none
    7138:	12800020 	mov	w0, #0xfffffffe            	// #-2
    713c:	39000280 	strb	w0, [x20]
    7140:	17ffffaa 	b	6fe8 <fwp_drop4+0x98>
    7144:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    7148:	910ba000 	add	x0, x0, #0x2e8
    714c:	97fff45a 	bl	42b4 <fwp_trap>
    7150:	aa1403e0 	mov	x0, x20
    7154:	97fff478 	bl	4334 <fwp_rc_forget_slot.part.0>
    7158:	17fffff8 	b	7138 <fwp_drop4+0x1e8>
    715c:	d503201f 	nop

0000000000007160 <fwp_caps161>:
    7160:	34000041 	cbz	w1, 7168 <fwp_caps161+0x8>
    7164:	d65f03c0 	ret
    7168:	d0000403 	adrp	x3, 89000 <fwp_root_context+0xba0>
    716c:	91190063 	add	x3, x3, #0x640
    7170:	f949d861 	ldr	x1, [x3, #5040]
    7174:	f949ec62 	ldr	x2, [x3, #5080]
    7178:	cb010001 	sub	x1, x0, x1
    717c:	eb02403f 	cmp	x1, x2, lsl #16
    7180:	54ffff22 	b.cs	7164 <fwp_caps161+0x4>  // b.hs, b.nlast
    7184:	d350fc22 	lsr	x2, x1, #16
    7188:	f949fc65 	ldr	x5, [x3, #5112]
    718c:	8b020842 	add	x2, x2, x2, lsl #2
    7190:	d37df042 	lsl	x2, x2, #3
    7194:	8b0200a4 	add	x4, x5, x2
    7198:	f9401083 	ldr	x3, [x4, #32]
    719c:	b4fffe43 	cbz	x3, 7164 <fwp_caps161+0x4>
    71a0:	386268a2 	ldrb	w2, [x5, x2]
    71a4:	7100085f 	cmp	w2, #0x2
    71a8:	540001c0 	b.eq	71e0 <fwp_caps161+0x80>  // b.none
    71ac:	7100045f 	cmp	w2, #0x1
    71b0:	54fffda1 	b.ne	7164 <fwp_caps161+0x4>  // b.any
    71b4:	29430885 	ldp	w5, w2, [x4, #24]
    71b8:	92403c21 	and	x1, x1, #0xffff
    71bc:	9b057c21 	mul	x1, x1, x5
    71c0:	d360fc21 	lsr	x1, x1, #32
    71c4:	eb02003f 	cmp	x1, x2
    71c8:	54fffce2 	b.cs	7164 <fwp_caps161+0x4>  // b.hs, b.nlast
    71cc:	8b010063 	add	x3, x3, x1
    71d0:	39400061 	ldrb	w1, [x3]
    71d4:	7100043f 	cmp	w1, #0x1
    71d8:	54fffc61 	b.ne	7164 <fwp_caps161+0x4>  // b.any
    71dc:	17fff4f1 	b	45a0 <fwp_mem_free>
    71e0:	72003c3f 	tst	w1, #0xffff
    71e4:	54ffff60 	b.eq	71d0 <fwp_caps161+0x70>  // b.none
    71e8:	d65f03c0 	ret
    71ec:	d503201f 	nop

00000000000071f0 <fwp_args23>:
    71f0:	7100003f 	cmp	w1, #0x0
    71f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    71f8:	54000041 	b.ne	7200 <fwp_args23+0x10>  // b.any
    71fc:	d65f03c0 	ret
    7200:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7204:	91190042 	add	x2, x2, #0x640
    7208:	f9400001 	ldr	x1, [x0]
    720c:	f949d843 	ldr	x3, [x2, #5040]
    7210:	f949ec40 	ldr	x0, [x2, #5080]
    7214:	cb030021 	sub	x1, x1, x3
    7218:	eb00403f 	cmp	x1, x0, lsl #16
    721c:	54ffff02 	b.cs	71fc <fwp_args23+0xc>  // b.hs, b.nlast
    7220:	d350fc20 	lsr	x0, x1, #16
    7224:	f949fc44 	ldr	x4, [x2, #5112]
    7228:	8b000800 	add	x0, x0, x0, lsl #2
    722c:	d37df002 	lsl	x2, x0, #3
    7230:	8b020083 	add	x3, x4, x2
    7234:	f9401060 	ldr	x0, [x3, #32]
    7238:	b4fffe20 	cbz	x0, 71fc <fwp_args23+0xc>
    723c:	38626882 	ldrb	w2, [x4, x2]
    7240:	7100085f 	cmp	w2, #0x2
    7244:	54000320 	b.eq	72a8 <fwp_args23+0xb8>  // b.none
    7248:	7100045f 	cmp	w2, #0x1
    724c:	54fffd81 	b.ne	71fc <fwp_args23+0xc>  // b.any
    7250:	29430864 	ldp	w4, w2, [x3, #24]
    7254:	92403c21 	and	x1, x1, #0xffff
    7258:	9b047c21 	mul	x1, x1, x4
    725c:	d360fc21 	lsr	x1, x1, #32
    7260:	eb02003f 	cmp	x1, x2
    7264:	54fffcc2 	b.cs	71fc <fwp_args23+0xc>  // b.hs, b.nlast
    7268:	8b010000 	add	x0, x0, x1
    726c:	39400001 	ldrb	w1, [x0]
    7270:	34fffc61 	cbz	w1, 71fc <fwp_args23+0xc>
    7274:	b0000142 	adrp	x2, 30000 <__data_start>
    7278:	91018042 	add	x2, x2, #0x60
    727c:	b9413043 	ldr	w3, [x2, #304]
    7280:	350000c3 	cbnz	w3, 7298 <fwp_args23+0xa8>
    7284:	7103f43f 	cmp	w1, #0xfd
    7288:	54000168 	b.hi	72b4 <fwp_args23+0xc4>  // b.pmore
    728c:	11000421 	add	w1, w1, #0x1
    7290:	39000001 	strb	w1, [x0]
    7294:	d65f03c0 	ret
    7298:	f940ac43 	ldr	x3, [x2, #344]
    729c:	91000463 	add	x3, x3, #0x1
    72a0:	f900ac43 	str	x3, [x2, #344]
    72a4:	17fffff8 	b	7284 <fwp_args23+0x94>
    72a8:	72003c3f 	tst	w1, #0xffff
    72ac:	54fffe00 	b.eq	726c <fwp_args23+0x7c>  // b.none
    72b0:	d65f03c0 	ret
    72b4:	17fff534 	b	4784 <fwp_rc_wide_dup>
    72b8:	d503201f 	nop
    72bc:	d503201f 	nop

00000000000072c0 <fwp_args12>:
    72c0:	7100003f 	cmp	w1, #0x0
    72c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    72c8:	54000041 	b.ne	72d0 <fwp_args12+0x10>  // b.any
    72cc:	d65f03c0 	ret
    72d0:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    72d4:	91190042 	add	x2, x2, #0x640
    72d8:	f9400001 	ldr	x1, [x0]
    72dc:	f949d843 	ldr	x3, [x2, #5040]
    72e0:	f949ec40 	ldr	x0, [x2, #5080]
    72e4:	cb030021 	sub	x1, x1, x3
    72e8:	eb00403f 	cmp	x1, x0, lsl #16
    72ec:	54ffff02 	b.cs	72cc <fwp_args12+0xc>  // b.hs, b.nlast
    72f0:	d350fc20 	lsr	x0, x1, #16
    72f4:	f949fc44 	ldr	x4, [x2, #5112]
    72f8:	8b000800 	add	x0, x0, x0, lsl #2
    72fc:	d37df002 	lsl	x2, x0, #3
    7300:	8b020083 	add	x3, x4, x2
    7304:	f9401060 	ldr	x0, [x3, #32]
    7308:	b4fffe20 	cbz	x0, 72cc <fwp_args12+0xc>
    730c:	38626882 	ldrb	w2, [x4, x2]
    7310:	7100085f 	cmp	w2, #0x2
    7314:	54000320 	b.eq	7378 <fwp_args12+0xb8>  // b.none
    7318:	7100045f 	cmp	w2, #0x1
    731c:	54fffd81 	b.ne	72cc <fwp_args12+0xc>  // b.any
    7320:	29430864 	ldp	w4, w2, [x3, #24]
    7324:	92403c21 	and	x1, x1, #0xffff
    7328:	9b047c21 	mul	x1, x1, x4
    732c:	d360fc21 	lsr	x1, x1, #32
    7330:	eb02003f 	cmp	x1, x2
    7334:	54fffcc2 	b.cs	72cc <fwp_args12+0xc>  // b.hs, b.nlast
    7338:	8b010000 	add	x0, x0, x1
    733c:	39400001 	ldrb	w1, [x0]
    7340:	34fffc61 	cbz	w1, 72cc <fwp_args12+0xc>
    7344:	b0000142 	adrp	x2, 30000 <__data_start>
    7348:	91018042 	add	x2, x2, #0x60
    734c:	b9413043 	ldr	w3, [x2, #304]
    7350:	350000c3 	cbnz	w3, 7368 <fwp_args12+0xa8>
    7354:	7103f43f 	cmp	w1, #0xfd
    7358:	54000168 	b.hi	7384 <fwp_args12+0xc4>  // b.pmore
    735c:	11000421 	add	w1, w1, #0x1
    7360:	39000001 	strb	w1, [x0]
    7364:	d65f03c0 	ret
    7368:	f940ac43 	ldr	x3, [x2, #344]
    736c:	91000463 	add	x3, x3, #0x1
    7370:	f900ac43 	str	x3, [x2, #344]
    7374:	17fffff8 	b	7354 <fwp_args12+0x94>
    7378:	72003c3f 	tst	w1, #0xffff
    737c:	54fffe00 	b.eq	733c <fwp_args12+0x7c>  // b.none
    7380:	d65f03c0 	ret
    7384:	17fff500 	b	4784 <fwp_rc_wide_dup>
    7388:	d503201f 	nop
    738c:	d503201f 	nop

0000000000007390 <fwp_drop2>:
    7390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7394:	910003fd 	mov	x29, sp
    7398:	a9025bf5 	stp	x21, x22, [sp, #32]
    739c:	d0000416 	adrp	x22, 89000 <fwp_root_context+0xba0>
    73a0:	911902d5 	add	x21, x22, #0x640
    73a4:	a90153f3 	stp	x19, x20, [sp, #16]
    73a8:	aa0003f3 	mov	x19, x0
    73ac:	f949daa1 	ldr	x1, [x21, #5040]
    73b0:	f949eea0 	ldr	x0, [x21, #5080]
    73b4:	cb010261 	sub	x1, x19, x1
    73b8:	eb00403f 	cmp	x1, x0, lsl #16
    73bc:	54000382 	b.cs	742c <fwp_drop2+0x9c>  // b.hs, b.nlast
    73c0:	d350fc22 	lsr	x2, x1, #16
    73c4:	f949fea3 	ldr	x3, [x21, #5112]
    73c8:	8b020842 	add	x2, x2, x2, lsl #2
    73cc:	d37df042 	lsl	x2, x2, #3
    73d0:	8b020060 	add	x0, x3, x2
    73d4:	f9401014 	ldr	x20, [x0, #32]
    73d8:	b40002b4 	cbz	x20, 742c <fwp_drop2+0x9c>
    73dc:	38626862 	ldrb	w2, [x3, x2]
    73e0:	7100085f 	cmp	w2, #0x2
    73e4:	540002c0 	b.eq	743c <fwp_drop2+0xac>  // b.none
    73e8:	7100045f 	cmp	w2, #0x1
    73ec:	54000201 	b.ne	742c <fwp_drop2+0x9c>  // b.any
    73f0:	29430002 	ldp	w2, w0, [x0, #24]
    73f4:	92403c21 	and	x1, x1, #0xffff
    73f8:	9b027c21 	mul	x1, x1, x2
    73fc:	d360fc21 	lsr	x1, x1, #32
    7400:	eb00003f 	cmp	x1, x0
    7404:	54000142 	b.cs	742c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7408:	8b010294 	add	x20, x20, x1
    740c:	39400280 	ldrb	w0, [x20]
    7410:	340000e0 	cbz	w0, 742c <fwp_drop2+0x9c>
    7414:	7100041f 	cmp	w0, #0x1
    7418:	540001e0 	b.eq	7454 <fwp_drop2+0xc4>  // b.none
    741c:	7103fc1f 	cmp	w0, #0xff
    7420:	540007c0 	b.eq	7518 <fwp_drop2+0x188>  // b.none
    7424:	51000400 	sub	w0, w0, #0x1
    7428:	39000280 	strb	w0, [x20]
    742c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7430:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7434:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7438:	d65f03c0 	ret
    743c:	72003c3f 	tst	w1, #0xffff
    7440:	54fffe60 	b.eq	740c <fwp_drop2+0x7c>  // b.none
    7444:	a94153f3 	ldp	x19, x20, [sp, #16]
    7448:	a9425bf5 	ldp	x21, x22, [sp, #32]
    744c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7450:	d65f03c0 	ret
    7454:	911902c2 	add	x2, x22, #0x640
    7458:	f9400660 	ldr	x0, [x19, #8]
    745c:	f949d841 	ldr	x1, [x2, #5040]
    7460:	f949ec42 	ldr	x2, [x2, #5080]
    7464:	cb010001 	sub	x1, x0, x1
    7468:	eb02403f 	cmp	x1, x2, lsl #16
    746c:	54000362 	b.cs	74d8 <fwp_drop2+0x148>  // b.hs, b.nlast
    7470:	d350fc22 	lsr	x2, x1, #16
    7474:	8b020842 	add	x2, x2, x2, lsl #2
    7478:	d37df042 	lsl	x2, x2, #3
    747c:	8b020064 	add	x4, x3, x2
    7480:	f9401094 	ldr	x20, [x4, #32]
    7484:	b40002b4 	cbz	x20, 74d8 <fwp_drop2+0x148>
    7488:	38626862 	ldrb	w2, [x3, x2]
    748c:	7100085f 	cmp	w2, #0x2
    7490:	540003e0 	b.eq	750c <fwp_drop2+0x17c>  // b.none
    7494:	7100045f 	cmp	w2, #0x1
    7498:	54000201 	b.ne	74d8 <fwp_drop2+0x148>  // b.any
    749c:	29430883 	ldp	w3, w2, [x4, #24]
    74a0:	92403c21 	and	x1, x1, #0xffff
    74a4:	9b037c21 	mul	x1, x1, x3
    74a8:	d360fc21 	lsr	x1, x1, #32
    74ac:	eb02003f 	cmp	x1, x2
    74b0:	54000142 	b.cs	74d8 <fwp_drop2+0x148>  // b.hs, b.nlast
    74b4:	8b010294 	add	x20, x20, x1
    74b8:	39400281 	ldrb	w1, [x20]
    74bc:	340000e1 	cbz	w1, 74d8 <fwp_drop2+0x148>
    74c0:	7100043f 	cmp	w1, #0x1
    74c4:	54000200 	b.eq	7504 <fwp_drop2+0x174>  // b.none
    74c8:	7103fc3f 	cmp	w1, #0xff
    74cc:	54000640 	b.eq	7594 <fwp_drop2+0x204>  // b.none
    74d0:	51000421 	sub	w1, w1, #0x1
    74d4:	39000281 	strb	w1, [x20]
    74d8:	f9400a74 	ldr	x20, [x19, #16]
    74dc:	aa1303e0 	mov	x0, x19
    74e0:	97fffab4 	bl	5fb0 <fwp_rc_free_arr>
    74e4:	911902c0 	add	x0, x22, #0x640
    74e8:	f949d801 	ldr	x1, [x0, #5040]
    74ec:	f949ec00 	ldr	x0, [x0, #5080]
    74f0:	cb010281 	sub	x1, x20, x1
    74f4:	eb00403f 	cmp	x1, x0, lsl #16
    74f8:	54fff9a2 	b.cs	742c <fwp_drop2+0x9c>  // b.hs, b.nlast
    74fc:	aa1403f3 	mov	x19, x20
    7500:	17ffffb0 	b	73c0 <fwp_drop2+0x30>
    7504:	97fffaab 	bl	5fb0 <fwp_rc_free_arr>
    7508:	17fffff4 	b	74d8 <fwp_drop2+0x148>
    750c:	72003c3f 	tst	w1, #0xffff
    7510:	54fffe41 	b.ne	74d8 <fwp_drop2+0x148>  // b.any
    7514:	17ffffe9 	b	74b8 <fwp_drop2+0x128>
    7518:	ca544681 	eor	x1, x20, x20, lsr #17
    751c:	911902c0 	add	x0, x22, #0x640
    7520:	ca412421 	eor	x1, x1, x1, lsr #9
    7524:	92401c21 	and	x1, x1, #0xff
    7528:	910a2422 	add	x2, x1, #0x289
    752c:	8b010c01 	add	x1, x0, x1, lsl #3
    7530:	8b020c02 	add	x2, x0, x2, lsl #3
    7534:	f94a2420 	ldr	x0, [x1, #5192]
    7538:	b50000a0 	cbnz	x0, 754c <fwp_drop2+0x1bc>
    753c:	14000013 	b	7588 <fwp_drop2+0x1f8>
    7540:	91004002 	add	x2, x0, #0x10
    7544:	f9400800 	ldr	x0, [x0, #16]
    7548:	b4000200 	cbz	x0, 7588 <fwp_drop2+0x1f8>
    754c:	f9400001 	ldr	x1, [x0]
    7550:	eb14003f 	cmp	x1, x20
    7554:	54ffff61 	b.ne	7540 <fwp_drop2+0x1b0>  // b.any
    7558:	f9400041 	ldr	x1, [x2]
    755c:	f9400420 	ldr	x0, [x1, #8]
    7560:	d1000400 	sub	x0, x0, #0x1
    7564:	f9000420 	str	x0, [x1, #8]
    7568:	f103f81f 	cmp	x0, #0xfe
    756c:	54fff601 	b.ne	742c <fwp_drop2+0x9c>  // b.any
    7570:	39400280 	ldrb	w0, [x20]
    7574:	7103fc1f 	cmp	w0, #0xff
    7578:	54000460 	b.eq	7604 <fwp_drop2+0x274>  // b.none
    757c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7580:	39000280 	strb	w0, [x20]
    7584:	17ffffaa 	b	742c <fwp_drop2+0x9c>
    7588:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    758c:	910ba000 	add	x0, x0, #0x2e8
    7590:	97fff349 	bl	42b4 <fwp_trap>
    7594:	ca544680 	eor	x0, x20, x20, lsr #17
    7598:	911902c1 	add	x1, x22, #0x640
    759c:	ca402400 	eor	x0, x0, x0, lsr #9
    75a0:	92401c00 	and	x0, x0, #0xff
    75a4:	910a2402 	add	x2, x0, #0x289
    75a8:	8b000c20 	add	x0, x1, x0, lsl #3
    75ac:	8b020c22 	add	x2, x1, x2, lsl #3
    75b0:	f94a2400 	ldr	x0, [x0, #5192]
    75b4:	b50000a0 	cbnz	x0, 75c8 <fwp_drop2+0x238>
    75b8:	17fffff4 	b	7588 <fwp_drop2+0x1f8>
    75bc:	91004002 	add	x2, x0, #0x10
    75c0:	f9400800 	ldr	x0, [x0, #16]
    75c4:	b4fffe20 	cbz	x0, 7588 <fwp_drop2+0x1f8>
    75c8:	f9400001 	ldr	x1, [x0]
    75cc:	eb14003f 	cmp	x1, x20
    75d0:	54ffff61 	b.ne	75bc <fwp_drop2+0x22c>  // b.any
    75d4:	f9400041 	ldr	x1, [x2]
    75d8:	f9400420 	ldr	x0, [x1, #8]
    75dc:	d1000400 	sub	x0, x0, #0x1
    75e0:	f9000420 	str	x0, [x1, #8]
    75e4:	f103f81f 	cmp	x0, #0xfe
    75e8:	54fff781 	b.ne	74d8 <fwp_drop2+0x148>  // b.any
    75ec:	39400280 	ldrb	w0, [x20]
    75f0:	7103fc1f 	cmp	w0, #0xff
    75f4:	540000e0 	b.eq	7610 <fwp_drop2+0x280>  // b.none
    75f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    75fc:	39000280 	strb	w0, [x20]
    7600:	17ffffb6 	b	74d8 <fwp_drop2+0x148>
    7604:	aa1403e0 	mov	x0, x20
    7608:	97fff34b 	bl	4334 <fwp_rc_forget_slot.part.0>
    760c:	17ffffdc 	b	757c <fwp_drop2+0x1ec>
    7610:	aa1403e0 	mov	x0, x20
    7614:	97fff348 	bl	4334 <fwp_rc_forget_slot.part.0>
    7618:	17fffff8 	b	75f8 <fwp_drop2+0x268>
    761c:	d503201f 	nop

0000000000007620 <fwp_arg_drop23>:
    7620:	7100003f 	cmp	w1, #0x0
    7624:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7628:	54000041 	b.ne	7630 <fwp_arg_drop23+0x10>  // b.any
    762c:	d65f03c0 	ret
    7630:	f9400000 	ldr	x0, [x0]
    7634:	17ffff57 	b	7390 <fwp_drop2>
    7638:	d503201f 	nop
    763c:	d503201f 	nop

0000000000007640 <fwp_caps12>:
    7640:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7644:	910003fd 	mov	x29, sp
    7648:	f9000bf3 	str	x19, [sp, #16]
    764c:	aa0003f3 	mov	x19, x0
    7650:	b9400400 	ldr	w0, [x0, #4]
    7654:	340004a0 	cbz	w0, 76e8 <fwp_caps12+0xa8>
    7658:	f9400660 	ldr	x0, [x19, #8]
    765c:	350004e1 	cbnz	w1, 76f8 <fwp_caps12+0xb8>
    7660:	97fffb8c 	bl	6490 <fwp_drop0>
    7664:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7668:	91190042 	add	x2, x2, #0x640
    766c:	f949d840 	ldr	x0, [x2, #5040]
    7670:	f949ec41 	ldr	x1, [x2, #5080]
    7674:	cb000260 	sub	x0, x19, x0
    7678:	eb01401f 	cmp	x0, x1, lsl #16
    767c:	54000382 	b.cs	76ec <fwp_caps12+0xac>  // b.hs, b.nlast
    7680:	d350fc01 	lsr	x1, x0, #16
    7684:	f949fc44 	ldr	x4, [x2, #5112]
    7688:	8b010821 	add	x1, x1, x1, lsl #2
    768c:	d37df021 	lsl	x1, x1, #3
    7690:	8b010083 	add	x3, x4, x1
    7694:	f9401062 	ldr	x2, [x3, #32]
    7698:	b40002a2 	cbz	x2, 76ec <fwp_caps12+0xac>
    769c:	38616881 	ldrb	w1, [x4, x1]
    76a0:	7100083f 	cmp	w1, #0x2
    76a4:	54000740 	b.eq	778c <fwp_caps12+0x14c>  // b.none
    76a8:	7100043f 	cmp	w1, #0x1
    76ac:	54000201 	b.ne	76ec <fwp_caps12+0xac>  // b.any
    76b0:	29430464 	ldp	w4, w1, [x3, #24]
    76b4:	92403c00 	and	x0, x0, #0xffff
    76b8:	9b047c00 	mul	x0, x0, x4
    76bc:	d360fc00 	lsr	x0, x0, #32
    76c0:	eb01001f 	cmp	x0, x1
    76c4:	54000142 	b.cs	76ec <fwp_caps12+0xac>  // b.hs, b.nlast
    76c8:	8b000042 	add	x2, x2, x0
    76cc:	39400040 	ldrb	w0, [x2]
    76d0:	7100041f 	cmp	w0, #0x1
    76d4:	540000c1 	b.ne	76ec <fwp_caps12+0xac>  // b.any
    76d8:	aa1303e0 	mov	x0, x19
    76dc:	f9400bf3 	ldr	x19, [sp, #16]
    76e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    76e4:	17fff3af 	b	45a0 <fwp_mem_free>
    76e8:	34fffbe1 	cbz	w1, 7664 <fwp_caps12+0x24>
    76ec:	f9400bf3 	ldr	x19, [sp, #16]
    76f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    76f4:	d65f03c0 	ret
    76f8:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    76fc:	91190042 	add	x2, x2, #0x640
    7700:	f949d843 	ldr	x3, [x2, #5040]
    7704:	f949ec41 	ldr	x1, [x2, #5080]
    7708:	cb030000 	sub	x0, x0, x3
    770c:	eb01401f 	cmp	x0, x1, lsl #16
    7710:	54fffee2 	b.cs	76ec <fwp_caps12+0xac>  // b.hs, b.nlast
    7714:	d350fc01 	lsr	x1, x0, #16
    7718:	f949fc44 	ldr	x4, [x2, #5112]
    771c:	8b010821 	add	x1, x1, x1, lsl #2
    7720:	d37df021 	lsl	x1, x1, #3
    7724:	8b010083 	add	x3, x4, x1
    7728:	f9401062 	ldr	x2, [x3, #32]
    772c:	b4fffe02 	cbz	x2, 76ec <fwp_caps12+0xac>
    7730:	38616881 	ldrb	w1, [x4, x1]
    7734:	7100083f 	cmp	w1, #0x2
    7738:	54000300 	b.eq	7798 <fwp_caps12+0x158>  // b.none
    773c:	7100043f 	cmp	w1, #0x1
    7740:	54fffd61 	b.ne	76ec <fwp_caps12+0xac>  // b.any
    7744:	92403c01 	and	x1, x0, #0xffff
    7748:	29430064 	ldp	w4, w0, [x3, #24]
    774c:	9b047c21 	mul	x1, x1, x4
    7750:	d360fc21 	lsr	x1, x1, #32
    7754:	eb00003f 	cmp	x1, x0
    7758:	54fffca2 	b.cs	76ec <fwp_caps12+0xac>  // b.hs, b.nlast
    775c:	8b010042 	add	x2, x2, x1
    7760:	39400040 	ldrb	w0, [x2]
    7764:	34fffc40 	cbz	w0, 76ec <fwp_caps12+0xac>
    7768:	b0000141 	adrp	x1, 30000 <__data_start>
    776c:	91018021 	add	x1, x1, #0x60
    7770:	b9413023 	ldr	w3, [x1, #304]
    7774:	35000183 	cbnz	w3, 77a4 <fwp_caps12+0x164>
    7778:	7103f41f 	cmp	w0, #0xfd
    777c:	540001c8 	b.hi	77b4 <fwp_caps12+0x174>  // b.pmore
    7780:	11000400 	add	w0, w0, #0x1
    7784:	39000040 	strb	w0, [x2]
    7788:	17ffffd9 	b	76ec <fwp_caps12+0xac>
    778c:	72003c1f 	tst	w0, #0xffff
    7790:	54fffae1 	b.ne	76ec <fwp_caps12+0xac>  // b.any
    7794:	17ffffce 	b	76cc <fwp_caps12+0x8c>
    7798:	72003c1f 	tst	w0, #0xffff
    779c:	54fffa81 	b.ne	76ec <fwp_caps12+0xac>  // b.any
    77a0:	17fffff0 	b	7760 <fwp_caps12+0x120>
    77a4:	f940ac23 	ldr	x3, [x1, #344]
    77a8:	91000463 	add	x3, x3, #0x1
    77ac:	f900ac23 	str	x3, [x1, #344]
    77b0:	17fffff2 	b	7778 <fwp_caps12+0x138>
    77b4:	f9400bf3 	ldr	x19, [sp, #16]
    77b8:	aa0203e0 	mov	x0, x2
    77bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77c0:	17fff3f1 	b	4784 <fwp_rc_wide_dup>

00000000000077c4 <fwp_caps23>:
    77c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    77c8:	910003fd 	mov	x29, sp
    77cc:	f9000bf3 	str	x19, [sp, #16]
    77d0:	aa0003f3 	mov	x19, x0
    77d4:	b9400400 	ldr	w0, [x0, #4]
    77d8:	340004a0 	cbz	w0, 786c <fwp_caps23+0xa8>
    77dc:	f9400660 	ldr	x0, [x19, #8]
    77e0:	350004e1 	cbnz	w1, 787c <fwp_caps23+0xb8>
    77e4:	97fffeeb 	bl	7390 <fwp_drop2>
    77e8:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    77ec:	91190042 	add	x2, x2, #0x640
    77f0:	f949d840 	ldr	x0, [x2, #5040]
    77f4:	f949ec41 	ldr	x1, [x2, #5080]
    77f8:	cb000260 	sub	x0, x19, x0
    77fc:	eb01401f 	cmp	x0, x1, lsl #16
    7800:	54000382 	b.cs	7870 <fwp_caps23+0xac>  // b.hs, b.nlast
    7804:	d350fc01 	lsr	x1, x0, #16
    7808:	f949fc44 	ldr	x4, [x2, #5112]
    780c:	8b010821 	add	x1, x1, x1, lsl #2
    7810:	d37df021 	lsl	x1, x1, #3
    7814:	8b010083 	add	x3, x4, x1
    7818:	f9401062 	ldr	x2, [x3, #32]
    781c:	b40002a2 	cbz	x2, 7870 <fwp_caps23+0xac>
    7820:	38616881 	ldrb	w1, [x4, x1]
    7824:	7100083f 	cmp	w1, #0x2
    7828:	54000740 	b.eq	7910 <fwp_caps23+0x14c>  // b.none
    782c:	7100043f 	cmp	w1, #0x1
    7830:	54000201 	b.ne	7870 <fwp_caps23+0xac>  // b.any
    7834:	29430464 	ldp	w4, w1, [x3, #24]
    7838:	92403c00 	and	x0, x0, #0xffff
    783c:	9b047c00 	mul	x0, x0, x4
    7840:	d360fc00 	lsr	x0, x0, #32
    7844:	eb01001f 	cmp	x0, x1
    7848:	54000142 	b.cs	7870 <fwp_caps23+0xac>  // b.hs, b.nlast
    784c:	8b000042 	add	x2, x2, x0
    7850:	39400040 	ldrb	w0, [x2]
    7854:	7100041f 	cmp	w0, #0x1
    7858:	540000c1 	b.ne	7870 <fwp_caps23+0xac>  // b.any
    785c:	aa1303e0 	mov	x0, x19
    7860:	f9400bf3 	ldr	x19, [sp, #16]
    7864:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7868:	17fff34e 	b	45a0 <fwp_mem_free>
    786c:	34fffbe1 	cbz	w1, 77e8 <fwp_caps23+0x24>
    7870:	f9400bf3 	ldr	x19, [sp, #16]
    7874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7878:	d65f03c0 	ret
    787c:	d0000402 	adrp	x2, 89000 <fwp_root_context+0xba0>
    7880:	91190042 	add	x2, x2, #0x640
    7884:	f949d843 	ldr	x3, [x2, #5040]
    7888:	f949ec41 	ldr	x1, [x2, #5080]
    788c:	cb030000 	sub	x0, x0, x3
    7890:	eb01401f 	cmp	x0, x1, lsl #16
    7894:	54fffee2 	b.cs	7870 <fwp_caps23+0xac>  // b.hs, b.nlast
    7898:	d350fc01 	lsr	x1, x0, #16
    789c:	f949fc44 	ldr	x4, [x2, #5112]
    78a0:	8b010821 	add	x1, x1, x1, lsl #2
    78a4:	d37df021 	lsl	x1, x1, #3
    78a8:	8b010083 	add	x3, x4, x1
    78ac:	f9401062 	ldr	x2, [x3, #32]
    78b0:	b4fffe02 	cbz	x2, 7870 <fwp_caps23+0xac>
    78b4:	38616881 	ldrb	w1, [x4, x1]
    78b8:	7100083f 	cmp	w1, #0x2
    78bc:	54000300 	b.eq	791c <fwp_caps23+0x158>  // b.none
    78c0:	7100043f 	cmp	w1, #0x1
    78c4:	54fffd61 	b.ne	7870 <fwp_caps23+0xac>  // b.any
    78c8:	92403c01 	and	x1, x0, #0xffff
    78cc:	29430064 	ldp	w4, w0, [x3, #24]
    78d0:	9b047c21 	mul	x1, x1, x4
    78d4:	d360fc21 	lsr	x1, x1, #32
    78d8:	eb00003f 	cmp	x1, x0
    78dc:	54fffca2 	b.cs	7870 <fwp_caps23+0xac>  // b.hs, b.nlast
    78e0:	8b010042 	add	x2, x2, x1
    78e4:	39400040 	ldrb	w0, [x2]
    78e8:	34fffc40 	cbz	w0, 7870 <fwp_caps23+0xac>
    78ec:	b0000141 	adrp	x1, 30000 <__data_start>
    78f0:	91018021 	add	x1, x1, #0x60
    78f4:	b9413023 	ldr	w3, [x1, #304]
    78f8:	35000183 	cbnz	w3, 7928 <fwp_caps23+0x164>
    78fc:	7103f41f 	cmp	w0, #0xfd
    7900:	540001c8 	b.hi	7938 <fwp_caps23+0x174>  // b.pmore
    7904:	11000400 	add	w0, w0, #0x1
    7908:	39000040 	strb	w0, [x2]
    790c:	17ffffd9 	b	7870 <fwp_caps23+0xac>
    7910:	72003c1f 	tst	w0, #0xffff
    7914:	54fffae1 	b.ne	7870 <fwp_caps23+0xac>  // b.any
    7918:	17ffffce 	b	7850 <fwp_caps23+0x8c>
    791c:	72003c1f 	tst	w0, #0xffff
    7920:	54fffa81 	b.ne	7870 <fwp_caps23+0xac>  // b.any
    7924:	17fffff0 	b	78e4 <fwp_caps23+0x120>
    7928:	f940ac23 	ldr	x3, [x1, #344]
    792c:	91000463 	add	x3, x3, #0x1
    7930:	f900ac23 	str	x3, [x1, #344]
    7934:	17fffff2 	b	78fc <fwp_caps23+0x138>
    7938:	f9400bf3 	ldr	x19, [sp, #16]
    793c:	aa0203e0 	mov	x0, x2
    7940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7944:	17fff390 	b	4784 <fwp_rc_wide_dup>
    7948:	d503201f 	nop
    794c:	d503201f 	nop

0000000000007950 <f23>:
    7950:	d10203ff 	sub	sp, sp, #0x80
    7954:	90000141 	adrp	x1, 2f000 <fwp_fn_table+0xb30>
    7958:	f947f421 	ldr	x1, [x1, #4072]
    795c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7960:	910083fd 	add	x29, sp, #0x20
    7964:	a9045bf5 	stp	x21, x22, [sp, #64]
    7968:	d0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    796c:	911902a3 	add	x3, x21, #0x640
    7970:	a90353f3 	stp	x19, x20, [sp, #48]
    7974:	aa0003f6 	mov	x22, x0
    7978:	a90563f7 	stp	x23, x24, [sp, #80]
    797c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7980:	f949ec62 	ldr	x2, [x3, #5080]
    7984:	f9400024 	ldr	x4, [x1]
    7988:	f9000fe4 	str	x4, [sp, #24]
    798c:	d2800004 	mov	x4, #0x0                   	// #0
    7990:	f949d861 	ldr	x1, [x3, #5040]
    7994:	d370bc42 	lsl	x2, x2, #16
    7998:	b4001920 	cbz	x0, 7cbc <f23+0x36c>
    799c:	f9400817 	ldr	x23, [x0, #16]
    79a0:	cb0102e1 	sub	x1, x23, x1
    79a4:	eb02003f 	cmp	x1, x2
    79a8:	540003e2 	b.cs	7a24 <f23+0xd4>  // b.hs, b.nlast
    79ac:	f949fc60 	ldr	x0, [x3, #5112]
    79b0:	d350fc22 	lsr	x2, x1, #16
    79b4:	8b020842 	add	x2, x2, x2, lsl #2
    79b8:	8b020c02 	add	x2, x0, x2, lsl #3
    79bc:	f9401040 	ldr	x0, [x2, #32]
    79c0:	b4000320 	cbz	x0, 7a24 <f23+0xd4>
    79c4:	39400043 	ldrb	w3, [x2]
    79c8:	7100087f 	cmp	w3, #0x2
    79cc:	540015e0 	b.eq	7c88 <f23+0x338>  // b.none
    79d0:	7100047f 	cmp	w3, #0x1
    79d4:	54000241 	b.ne	7a1c <f23+0xcc>  // b.any
    79d8:	29430843 	ldp	w3, w2, [x2, #24]
    79dc:	92403c21 	and	x1, x1, #0xffff
    79e0:	9b037c21 	mul	x1, x1, x3
    79e4:	d360fc21 	lsr	x1, x1, #32
    79e8:	eb02003f 	cmp	x1, x2
    79ec:	54000182 	b.cs	7a1c <f23+0xcc>  // b.hs, b.nlast
    79f0:	8b010000 	add	x0, x0, x1
    79f4:	39400001 	ldrb	w1, [x0]
    79f8:	34000121 	cbz	w1, 7a1c <f23+0xcc>
    79fc:	b0000142 	adrp	x2, 30000 <__data_start>
    7a00:	91018042 	add	x2, x2, #0x60
    7a04:	b9413043 	ldr	w3, [x2, #304]
    7a08:	35001463 	cbnz	w3, 7c94 <f23+0x344>
    7a0c:	7103f43f 	cmp	w1, #0xfd
    7a10:	54001888 	b.hi	7d20 <f23+0x3d0>  // b.pmore
    7a14:	11000421 	add	w1, w1, #0x1
    7a18:	39000001 	strb	w1, [x0]
    7a1c:	d2800002 	mov	x2, #0x0                   	// #0
    7a20:	b40000f6 	cbz	x22, 7a3c <f23+0xec>
    7a24:	aa1603e1 	mov	x1, x22
    7a28:	d2800002 	mov	x2, #0x0                   	// #0
    7a2c:	d503201f 	nop
    7a30:	f9400821 	ldr	x1, [x1, #16]
    7a34:	91000442 	add	x2, x2, #0x1
    7a38:	b5ffffc1 	cbnz	x1, 7a30 <f23+0xe0>
    7a3c:	b4001477 	cbz	x23, 7cc8 <f23+0x378>
    7a40:	aa1703e1 	mov	x1, x23
    7a44:	d2800003 	mov	x3, #0x0                   	// #0
    7a48:	f9400821 	ldr	x1, [x1, #16]
    7a4c:	91000463 	add	x3, x3, #0x1
    7a50:	b5ffffc1 	cbnz	x1, 7a48 <f23+0xf8>
    7a54:	eb02007f 	cmp	x3, x2
    7a58:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    7a5c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7a60:	eb00027f 	cmp	x19, x0
    7a64:	540010a8 	b.hi	7c78 <f23+0x328>  // b.pmore
    7a68:	d37ffa74 	lsl	x20, x19, #1
    7a6c:	52800041 	mov	w1, #0x2                   	// #2
    7a70:	91000680 	add	x0, x20, #0x1
    7a74:	d37df000 	lsl	x0, x0, #3
    7a78:	97fff586 	bl	5090 <fwp_heap_alloc>
    7a7c:	aa0003f8 	mov	x24, x0
    7a80:	911902a1 	add	x1, x21, #0x640
    7a84:	aa0103e0 	mov	x0, x1
    7a88:	f9000314 	str	x20, [x24]
    7a8c:	f949d821 	ldr	x1, [x1, #5040]
    7a90:	f949ec00 	ldr	x0, [x0, #5080]
    7a94:	cb010301 	sub	x1, x24, x1
    7a98:	eb00403f 	cmp	x1, x0, lsl #16
    7a9c:	54000342 	b.cs	7b04 <f23+0x1b4>  // b.hs, b.nlast
    7aa0:	911902a2 	add	x2, x21, #0x640
    7aa4:	d350fc20 	lsr	x0, x1, #16
    7aa8:	8b000800 	add	x0, x0, x0, lsl #2
    7aac:	f949fc43 	ldr	x3, [x2, #5112]
    7ab0:	d37df002 	lsl	x2, x0, #3
    7ab4:	8b020060 	add	x0, x3, x2
    7ab8:	f9401014 	ldr	x20, [x0, #32]
    7abc:	b4000254 	cbz	x20, 7b04 <f23+0x1b4>
    7ac0:	38626862 	ldrb	w2, [x3, x2]
    7ac4:	7100085f 	cmp	w2, #0x2
    7ac8:	54000ee0 	b.eq	7ca4 <f23+0x354>  // b.none
    7acc:	7100045f 	cmp	w2, #0x1
    7ad0:	540001a1 	b.ne	7b04 <f23+0x1b4>  // b.any
    7ad4:	29430002 	ldp	w2, w0, [x0, #24]
    7ad8:	92403c21 	and	x1, x1, #0xffff
    7adc:	9b027c21 	mul	x1, x1, x2
    7ae0:	d360fc21 	lsr	x1, x1, #32
    7ae4:	eb00003f 	cmp	x1, x0
    7ae8:	540000e2 	b.cs	7b04 <f23+0x1b4>  // b.hs, b.nlast
    7aec:	8b010294 	add	x20, x20, x1
    7af0:	39400280 	ldrb	w0, [x20]
    7af4:	7103fc1f 	cmp	w0, #0xff
    7af8:	54001180 	b.eq	7d28 <f23+0x3d8>  // b.none
    7afc:	52800020 	mov	w0, #0x1                   	// #1
    7b00:	39000280 	strb	w0, [x20]
    7b04:	b4000253 	cbz	x19, 7b4c <f23+0x1fc>
    7b08:	8b131313 	add	x19, x24, x19, lsl #4
    7b0c:	aa1803f4 	mov	x20, x24
    7b10:	aa1603fa 	mov	x26, x22
    7b14:	aa1703f9 	mov	x25, x23
    7b18:	f9400723 	ldr	x3, [x25, #8]
    7b1c:	f9400742 	ldr	x2, [x26, #8]
    7b20:	f9400861 	ldr	x1, [x3, #16]
    7b24:	f9400840 	ldr	x0, [x2, #16]
    7b28:	fd400461 	ldr	d1, [x3, #8]
    7b2c:	fd400440 	ldr	d0, [x2, #8]
    7b30:	97fff734 	bl	5800 <w107>
    7b34:	f9000680 	str	x0, [x20, #8]
    7b38:	f8010e81 	str	x1, [x20, #16]!
    7b3c:	f9400b39 	ldr	x25, [x25, #16]
    7b40:	f9400b5a 	ldr	x26, [x26, #16]
    7b44:	eb14027f 	cmp	x19, x20
    7b48:	54fffe81 	b.ne	7b18 <f23+0x1c8>  // b.any
    7b4c:	aa1703e0 	mov	x0, x23
    7b50:	97fffe10 	bl	7390 <fwp_drop2>
    7b54:	aa1603e0 	mov	x0, x22
    7b58:	97fffe0e 	bl	7390 <fwp_drop2>
    7b5c:	f9400316 	ldr	x22, [x24]
    7b60:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7b64:	b4000236 	cbz	x22, 7ba8 <f23+0x258>
    7b68:	fd003be8 	str	d8, [sp, #112]
    7b6c:	2f00e408 	movi	d8, #0x0
    7b70:	91002319 	add	x25, x24, #0x8
    7b74:	91004317 	add	x23, x24, #0x10
    7b78:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    7b7c:	d2800013 	mov	x19, #0x0                   	// #0
    7b80:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7b84:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7b88:	91000a73 	add	x19, x19, #0x2
    7b8c:	1e602908 	fadd	d8, d8, d0
    7b90:	97fff6c4 	bl	56a0 <f128.constprop.0>
    7b94:	aa0003f4 	mov	x20, x0
    7b98:	eb1302df 	cmp	x22, x19
    7b9c:	54ffff28 	b.hi	7b80 <f23+0x230>  // b.pmore
    7ba0:	9e660116 	fmov	x22, d8
    7ba4:	fd403be8 	ldr	d8, [sp, #112]
    7ba8:	911902b5 	add	x21, x21, #0x640
    7bac:	aa1803e0 	mov	x0, x24
    7bb0:	97fffce8 	bl	6f50 <fwp_drop4>
    7bb4:	a900d3f6 	stp	x22, x20, [sp, #8]
    7bb8:	910023e1 	add	x1, sp, #0x8
    7bbc:	52800000 	mov	w0, #0x0                   	// #0
    7bc0:	97fff849 	bl	5ce4 <fwp_data.part.0.constprop.0>
    7bc4:	f949daa1 	ldr	x1, [x21, #5040]
    7bc8:	aa0003f3 	mov	x19, x0
    7bcc:	f949eea0 	ldr	x0, [x21, #5080]
    7bd0:	cb010261 	sub	x1, x19, x1
    7bd4:	eb00403f 	cmp	x1, x0, lsl #16
    7bd8:	54000322 	b.cs	7c3c <f23+0x2ec>  // b.hs, b.nlast
    7bdc:	d350fc22 	lsr	x2, x1, #16
    7be0:	f949fea3 	ldr	x3, [x21, #5112]
    7be4:	8b020842 	add	x2, x2, x2, lsl #2
    7be8:	d37df042 	lsl	x2, x2, #3
    7bec:	8b020060 	add	x0, x3, x2
    7bf0:	f9401014 	ldr	x20, [x0, #32]
    7bf4:	b4000254 	cbz	x20, 7c3c <f23+0x2ec>
    7bf8:	38626862 	ldrb	w2, [x3, x2]
    7bfc:	7100085f 	cmp	w2, #0x2
    7c00:	54000580 	b.eq	7cb0 <f23+0x360>  // b.none
    7c04:	7100045f 	cmp	w2, #0x1
    7c08:	540001a1 	b.ne	7c3c <f23+0x2ec>  // b.any
    7c0c:	29430002 	ldp	w2, w0, [x0, #24]
    7c10:	92403c21 	and	x1, x1, #0xffff
    7c14:	9b027c21 	mul	x1, x1, x2
    7c18:	d360fc21 	lsr	x1, x1, #32
    7c1c:	eb00003f 	cmp	x1, x0
    7c20:	540000e2 	b.cs	7c3c <f23+0x2ec>  // b.hs, b.nlast
    7c24:	8b010294 	add	x20, x20, x1
    7c28:	39400280 	ldrb	w0, [x20]
    7c2c:	7103fc1f 	cmp	w0, #0xff
    7c30:	54000820 	b.eq	7d34 <f23+0x3e4>  // b.none
    7c34:	52800020 	mov	w0, #0x1                   	// #1
    7c38:	39000280 	strb	w0, [x20]
    7c3c:	90000140 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    7c40:	f947f400 	ldr	x0, [x0, #4072]
    7c44:	f9400fe2 	ldr	x2, [sp, #24]
    7c48:	f9400001 	ldr	x1, [x0]
    7c4c:	eb010042 	subs	x2, x2, x1
    7c50:	d2800001 	mov	x1, #0x0                   	// #0
    7c54:	540007a1 	b.ne	7d48 <f23+0x3f8>  // b.any
    7c58:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7c5c:	aa1303e0 	mov	x0, x19
    7c60:	a94353f3 	ldp	x19, x20, [sp, #48]
    7c64:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7c68:	a94563f7 	ldp	x23, x24, [sp, #80]
    7c6c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7c70:	910203ff 	add	sp, sp, #0x80
    7c74:	d65f03c0 	ret
    7c78:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    7c7c:	91164000 	add	x0, x0, #0x590
    7c80:	fd003be8 	str	d8, [sp, #112]
    7c84:	97fff18c 	bl	42b4 <fwp_trap>
    7c88:	72003c3f 	tst	w1, #0xffff
    7c8c:	54ffec81 	b.ne	7a1c <f23+0xcc>  // b.any
    7c90:	17ffff59 	b	79f4 <f23+0xa4>
    7c94:	f940ac43 	ldr	x3, [x2, #344]
    7c98:	91000463 	add	x3, x3, #0x1
    7c9c:	f900ac43 	str	x3, [x2, #344]
    7ca0:	17ffff5b 	b	7a0c <f23+0xbc>
    7ca4:	72003c3f 	tst	w1, #0xffff
    7ca8:	54fff2e1 	b.ne	7b04 <f23+0x1b4>  // b.any
    7cac:	17ffff91 	b	7af0 <f23+0x1a0>
    7cb0:	72003c3f 	tst	w1, #0xffff
    7cb4:	54fffc41 	b.ne	7c3c <f23+0x2ec>  // b.any
    7cb8:	17ffffdc 	b	7c28 <f23+0x2d8>
    7cbc:	cb0103e1 	neg	x1, x1
    7cc0:	eb02003f 	cmp	x1, x2
    7cc4:	540001e3 	b.cc	7d00 <f23+0x3b0>  // b.lo, b.ul, b.last
    7cc8:	52800041 	mov	w1, #0x2                   	// #2
    7ccc:	d2800100 	mov	x0, #0x8                   	// #8
    7cd0:	97fff4f0 	bl	5090 <fwp_heap_alloc>
    7cd4:	aa0003f8 	mov	x24, x0
    7cd8:	911902a0 	add	x0, x21, #0x640
    7cdc:	f900031f 	str	xzr, [x24]
    7ce0:	f949d801 	ldr	x1, [x0, #5040]
    7ce4:	f949ec00 	ldr	x0, [x0, #5080]
    7ce8:	cb010301 	sub	x1, x24, x1
    7cec:	eb00403f 	cmp	x1, x0, lsl #16
    7cf0:	54000282 	b.cs	7d40 <f23+0x3f0>  // b.hs, b.nlast
    7cf4:	d2800013 	mov	x19, #0x0                   	// #0
    7cf8:	d2800017 	mov	x23, #0x0                   	// #0
    7cfc:	17ffff69 	b	7aa0 <f23+0x150>
    7d00:	f949fc62 	ldr	x2, [x3, #5112]
    7d04:	d350fc20 	lsr	x0, x1, #16
    7d08:	8b000800 	add	x0, x0, x0, lsl #2
    7d0c:	8b000c42 	add	x2, x2, x0, lsl #3
    7d10:	f9401040 	ldr	x0, [x2, #32]
    7d14:	b4fffda0 	cbz	x0, 7cc8 <f23+0x378>
    7d18:	d2800017 	mov	x23, #0x0                   	// #0
    7d1c:	17ffff2a 	b	79c4 <f23+0x74>
    7d20:	97fff299 	bl	4784 <fwp_rc_wide_dup>
    7d24:	17ffff3e 	b	7a1c <f23+0xcc>
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	97fff182 	bl	4334 <fwp_rc_forget_slot.part.0>
    7d30:	17ffff73 	b	7afc <f23+0x1ac>
    7d34:	aa1403e0 	mov	x0, x20
    7d38:	97fff17f 	bl	4334 <fwp_rc_forget_slot.part.0>
    7d3c:	17ffffbe 	b	7c34 <f23+0x2e4>
    7d40:	d2800017 	mov	x23, #0x0                   	// #0
    7d44:	17ffff82 	b	7b4c <f23+0x1fc>
    7d48:	fd003be8 	str	d8, [sp, #112]
    7d4c:	97ffeab1 	bl	2810 <__stack_chk_fail@plt>

0000000000007d50 <fwp_owned_entry23>:
    7d50:	f9400000 	ldr	x0, [x0]
    7d54:	17fffeff 	b	7950 <f23>
    7d58:	d503201f 	nop
    7d5c:	d503201f 	nop

0000000000007d60 <e23>:
    7d60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7d64:	910003fd 	mov	x29, sp
    7d68:	f9000bf3 	str	x19, [sp, #16]
    7d6c:	f9400013 	ldr	x19, [x0]
    7d70:	aa1303e0 	mov	x0, x19
    7d74:	97fff83b 	bl	5e60 <fwp_rc_share>
    7d78:	aa1303e0 	mov	x0, x19
    7d7c:	97fffef5 	bl	7950 <f23>
    7d80:	aa0003f3 	mov	x19, x0
    7d84:	97fff837 	bl	5e60 <fwp_rc_share>
    7d88:	aa1303e0 	mov	x0, x19
    7d8c:	f9400bf3 	ldr	x19, [sp, #16]
    7d90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d94:	d65f03c0 	ret
    7d98:	d503201f 	nop
    7d9c:	d503201f 	nop

0000000000007da0 <f12>:
    7da0:	d104c3ff 	sub	sp, sp, #0x130
    7da4:	90000142 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    7da8:	f947f442 	ldr	x2, [x2, #4072]
    7dac:	a90d7bfd 	stp	x29, x30, [sp, #208]
    7db0:	910343fd 	add	x29, sp, #0xd0
    7db4:	a90f5bf5 	stp	x21, x22, [sp, #240]
    7db8:	d0000415 	adrp	x21, 89000 <fwp_root_context+0xba0>
    7dbc:	911902a3 	add	x3, x21, #0x640
    7dc0:	a90e53f3 	stp	x19, x20, [sp, #224]
    7dc4:	b0000154 	adrp	x20, 30000 <__data_start>
    7dc8:	91018284 	add	x4, x20, #0x60
    7dcc:	f949d861 	ldr	x1, [x3, #5040]
    7dd0:	a91063f7 	stp	x23, x24, [sp, #256]
    7dd4:	b0000158 	adrp	x24, 30000 <__data_start>
    7dd8:	f949ec65 	ldr	x5, [x3, #5080]
    7ddc:	a9116bf9 	stp	x25, x26, [sp, #272]
    7de0:	91004318 	add	x24, x24, #0x10
    7de4:	a91273fb 	stp	x27, x28, [sp, #288]
    7de8:	91008318 	add	x24, x24, #0x20
    7dec:	910143f7 	add	x23, sp, #0x50
    7df0:	f941c886 	ldr	x6, [x4, #912]
    7df4:	f9400047 	ldr	x7, [x2]
    7df8:	f90067e7 	str	x7, [sp, #200]
    7dfc:	d2800007 	mov	x7, #0x0                   	// #0
    7e00:	910123f6 	add	x22, sp, #0x48
    7e04:	f0fffff9 	adrp	x25, 6000 <fwp_rc_free_arr+0x50>
    7e08:	12800007 	mov	w7, #0xffffffff            	// #-1
    7e0c:	91274322 	add	x2, x25, #0x9d0
    7e10:	cb010301 	sub	x1, x24, x1
    7e14:	b9004be7 	str	w7, [sp, #72]
    7e18:	a9050be6 	stp	x6, x2, [sp, #80]
    7e1c:	aa0003f3 	mov	x19, x0
    7e20:	f90033f6 	str	x22, [sp, #96]
    7e24:	f901c897 	str	x23, [x4, #912]
    7e28:	eb05403f 	cmp	x1, x5, lsl #16
    7e2c:	540003a2 	b.cs	7ea0 <f12+0x100>  // b.hs, b.nlast
    7e30:	d350fc20 	lsr	x0, x1, #16
    7e34:	f949fc64 	ldr	x4, [x3, #5112]
    7e38:	8b000800 	add	x0, x0, x0, lsl #2
    7e3c:	d37df002 	lsl	x2, x0, #3
    7e40:	8b020083 	add	x3, x4, x2
    7e44:	f9401060 	ldr	x0, [x3, #32]
    7e48:	b40002c0 	cbz	x0, 7ea0 <f12+0x100>
    7e4c:	38626882 	ldrb	w2, [x4, x2]
    7e50:	7100085f 	cmp	w2, #0x2
    7e54:	54000c00 	b.eq	7fd4 <f12+0x234>  // b.none
    7e58:	7100045f 	cmp	w2, #0x1
    7e5c:	54000221 	b.ne	7ea0 <f12+0x100>  // b.any
    7e60:	29430864 	ldp	w4, w2, [x3, #24]
    7e64:	92403c21 	and	x1, x1, #0xffff
    7e68:	9b047c21 	mul	x1, x1, x4
    7e6c:	d360fc21 	lsr	x1, x1, #32
    7e70:	eb02003f 	cmp	x1, x2
    7e74:	54000162 	b.cs	7ea0 <f12+0x100>  // b.hs, b.nlast
    7e78:	8b010000 	add	x0, x0, x1
    7e7c:	39400001 	ldrb	w1, [x0]
    7e80:	34000101 	cbz	w1, 7ea0 <f12+0x100>
    7e84:	91018282 	add	x2, x20, #0x60
    7e88:	b9413043 	ldr	w3, [x2, #304]
    7e8c:	350013a3 	cbnz	w3, 8100 <f12+0x360>
    7e90:	7103f43f 	cmp	w1, #0xfd
    7e94:	54002748 	b.hi	837c <f12+0x5dc>  // b.pmore
    7e98:	11000421 	add	w1, w1, #0x1
    7e9c:	39000001 	strb	w1, [x0]
    7ea0:	aa1803e0 	mov	x0, x24
    7ea4:	97fff9df 	bl	6620 <fwp_closure_drop>
    7ea8:	b40001d3 	cbz	x19, 7ee0 <f12+0x140>
    7eac:	aa1303e0 	mov	x0, x19
    7eb0:	d2800001 	mov	x1, #0x0                   	// #0
    7eb4:	d503201f 	nop
    7eb8:	f9400800 	ldr	x0, [x0, #16]
    7ebc:	91000421 	add	x1, x1, #0x1
    7ec0:	b5ffffc0 	cbnz	x0, 7eb8 <f12+0x118>
    7ec4:	aa0103f8 	mov	x24, x1
    7ec8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7ecc:	eb00003f 	cmp	x1, x0
    7ed0:	540000a9 	b.ls	7ee4 <f12+0x144>  // b.plast
    7ed4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    7ed8:	91168000 	add	x0, x0, #0x5a0
    7edc:	97fff0f6 	bl	42b4 <fwp_trap>
    7ee0:	d2800018 	mov	x24, #0x0                   	// #0
    7ee4:	9101829a 	add	x26, x20, #0x60
    7ee8:	b943c740 	ldr	w0, [x26, #964]
    7eec:	34001340 	cbz	w0, 8154 <f12+0x3b4>
    7ef0:	91018280 	add	x0, x20, #0x60
    7ef4:	f940901b 	ldr	x27, [x0, #288]
    7ef8:	f940b01a 	ldr	x26, [x0, #352]
    7efc:	eb1b035f 	cmp	x26, x27
    7f00:	5400070a 	b.ge	7fe0 <f12+0x240>  // b.tcont
    7f04:	f9404401 	ldr	x1, [x0, #136]
    7f08:	8b1a0740 	add	x0, x26, x26, lsl #1
    7f0c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7f10:	8b000b40 	add	x0, x26, x0, lsl #2
    7f14:	8b000c20 	add	x0, x1, x0, lsl #3
    7f18:	b9400401 	ldr	w1, [x0, #4]
    7f1c:	35000081 	cbnz	w1, 7f2c <f12+0x18c>
    7f20:	b9400001 	ldr	w1, [x0]
    7f24:	6b02003f 	cmp	w1, w2
    7f28:	540005c9 	b.ls	7fe0 <f12+0x240>  // b.plast
    7f2c:	9100075a 	add	x26, x26, #0x1
    7f30:	9101a000 	add	x0, x0, #0x68
    7f34:	eb1b035f 	cmp	x26, x27
    7f38:	54ffff01 	b.ne	7f18 <f12+0x178>  // b.any
    7f3c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7f40:	eb00037f 	cmp	x27, x0
    7f44:	54001eec 	b.gt	8320 <f12+0x580>
    7f48:	91018280 	add	x0, x20, #0x60
    7f4c:	f9408801 	ldr	x1, [x0, #272]
    7f50:	f940441c 	ldr	x28, [x0, #136]
    7f54:	eb1b003f 	cmp	x1, x27
    7f58:	54000261 	b.ne	7fa4 <f12+0x204>  // b.any
    7f5c:	b40027bb 	cbz	x27, 8450 <f12+0x6b0>
    7f60:	d37ffb63 	lsl	x3, x27, #1
    7f64:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7f68:	eb00007f 	cmp	x3, x0
    7f6c:	9a80d063 	csel	x3, x3, x0, le
    7f70:	8b030461 	add	x1, x3, x3, lsl #1
    7f74:	8b010861 	add	x1, x3, x1, lsl #2
    7f78:	d37df021 	lsl	x1, x1, #3
    7f7c:	aa1c03e0 	mov	x0, x28
    7f80:	52800002 	mov	w2, #0x0                   	// #0
    7f84:	f90007e3 	str	x3, [sp, #8]
    7f88:	97fff02f 	bl	4044 <ad_raw_realloc>
    7f8c:	f94007e3 	ldr	x3, [sp, #8]
    7f90:	aa0003fc 	mov	x28, x0
    7f94:	b4004760 	cbz	x0, 8880 <f12+0xae0>
    7f98:	91018280 	add	x0, x20, #0x60
    7f9c:	f900441c 	str	x28, [x0, #136]
    7fa0:	f9008803 	str	x3, [x0, #272]
    7fa4:	8b1b0760 	add	x0, x27, x27, lsl #1
    7fa8:	91018281 	add	x1, x20, #0x60
    7fac:	4f000400 	movi	v0.4s, #0x0
    7fb0:	91000762 	add	x2, x27, #0x1
    7fb4:	8b000b60 	add	x0, x27, x0, lsl #2
    7fb8:	f9009022 	str	x2, [x1, #288]
    7fbc:	8b000f80 	add	x0, x28, x0, lsl #3
    7fc0:	ad000000 	stp	q0, q0, [x0]
    7fc4:	ad010000 	stp	q0, q0, [x0, #32]
    7fc8:	ad020000 	stp	q0, q0, [x0, #64]
    7fcc:	f900301f 	str	xzr, [x0, #96]
    7fd0:	14000008 	b	7ff0 <f12+0x250>
    7fd4:	72003c3f 	tst	w1, #0xffff
    7fd8:	54fff641 	b.ne	7ea0 <f12+0x100>  // b.any
    7fdc:	17ffffa8 	b	7e7c <f12+0xdc>
    7fe0:	eb1b035f 	cmp	x26, x27
    7fe4:	54fffac0 	b.eq	7f3c <f12+0x19c>  // b.none
    7fe8:	91018280 	add	x0, x20, #0x60
    7fec:	f940441c 	ldr	x28, [x0, #136]
    7ff0:	8b1a075b 	add	x27, x26, x26, lsl #1
    7ff4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    7ff8:	9109c000 	add	x0, x0, #0x270
    7ffc:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    8000:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8004:	f900337f 	str	xzr, [x27, #96]
    8008:	97ffea66 	bl	29a0 <getenv@plt>
    800c:	b4000080 	cbz	x0, 801c <f12+0x27c>
    8010:	39400001 	ldrb	w1, [x0]
    8014:	7100c03f 	cmp	w1, #0x30
    8018:	540007c0 	b.eq	8110 <f12+0x370>  // b.none
    801c:	91018280 	add	x0, x20, #0x60
    8020:	f9408401 	ldr	x1, [x0, #264]
    8024:	b50007c1 	cbnz	x1, 811c <f12+0x37c>
    8028:	91018282 	add	x2, x20, #0x60
    802c:	2f000400 	mvni	v0.2s, #0x0
    8030:	b9400363 	ldr	w3, [x27]
    8034:	52800020 	mov	w0, #0x1                   	// #1
    8038:	91000744 	add	x4, x26, #0x1
    803c:	a900e378 	stp	x24, x24, [x27, #8]
    8040:	0b000063 	add	w3, w3, w0
    8044:	f941c841 	ldr	x1, [x2, #912]
    8048:	29000363 	stp	w3, w0, [x27]
    804c:	f9002b7f 	str	xzr, [x27, #80]
    8050:	f900b044 	str	x4, [x2, #352]
    8054:	fd002f60 	str	d0, [x27, #88]
    8058:	b4001581 	cbz	x1, 8308 <f12+0x568>
    805c:	91274339 	add	x25, x25, #0x9d0
    8060:	14000003 	b	806c <f12+0x2cc>
    8064:	f9400021 	ldr	x1, [x1]
    8068:	b4001501 	cbz	x1, 8308 <f12+0x568>
    806c:	f9400422 	ldr	x2, [x1, #8]
    8070:	eb19005f 	cmp	x2, x25
    8074:	54ffff81 	b.ne	8064 <f12+0x2c4>  // b.any
    8078:	f9400820 	ldr	x0, [x1, #16]
    807c:	2a1a03e2 	mov	w2, w26
    8080:	b9400001 	ldr	w1, [x0]
    8084:	f9002b60 	str	x0, [x27, #80]
    8088:	b9005f61 	str	w1, [x27, #92]
    808c:	37f80081 	tbnz	w1, #31, 809c <f12+0x2fc>
    8090:	52800d05 	mov	w5, #0x68                  	// #104
    8094:	9b257021 	smaddl	x1, w1, w5, x28
    8098:	b900583a 	str	w26, [x1, #88]
    809c:	b9000002 	str	w2, [x0]
    80a0:	aa1303e0 	mov	x0, x19
    80a4:	d2800002 	mov	x2, #0x0                   	// #0
    80a8:	b4000653 	cbz	x19, 8170 <f12+0x3d0>
    80ac:	d503201f 	nop
    80b0:	f9400800 	ldr	x0, [x0, #16]
    80b4:	91000442 	add	x2, x2, #0x1
    80b8:	b5ffffc0 	cbnz	x0, 80b0 <f12+0x310>
    80bc:	aa1303e1 	mov	x1, x19
    80c0:	f9400821 	ldr	x1, [x1, #16]
    80c4:	91000400 	add	x0, x0, #0x1
    80c8:	b5ffffc1 	cbnz	x1, 80c0 <f12+0x320>
    80cc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    80d0:	eb01001f 	cmp	x0, x1
    80d4:	54000108 	b.hi	80f4 <f12+0x354>  // b.pmore
    80d8:	f100005f 	cmp	x2, #0x0
    80dc:	540004ad 	b.le	8170 <f12+0x3d0>
    80e0:	eb00005f 	cmp	x2, x0
    80e4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    80e8:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    80ec:	eb01033f 	cmp	x25, x1
    80f0:	540011e9 	b.ls	832c <f12+0x58c>  // b.plast
    80f4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    80f8:	91164000 	add	x0, x0, #0x590
    80fc:	97fff06e 	bl	42b4 <fwp_trap>
    8100:	f940ac43 	ldr	x3, [x2, #344]
    8104:	91000463 	add	x3, x3, #0x1
    8108:	f900ac43 	str	x3, [x2, #344]
    810c:	17ffff61 	b	7e90 <f12+0xf0>
    8110:	39400400 	ldrb	w0, [x0, #1]
    8114:	34fff8a0 	cbz	w0, 8028 <f12+0x288>
    8118:	17ffffc1 	b	801c <f12+0x27c>
    811c:	ad468402 	ldp	q2, q1, [x0, #208]
    8120:	91034001 	add	x1, x0, #0xd0
    8124:	4f000400 	movi	v0.4s, #0x0
    8128:	f900841f 	str	xzr, [x0, #264]
    812c:	ad010762 	stp	q2, q1, [x27, #32]
    8130:	a94f0002 	ldp	x2, x0, [x0, #240]
    8134:	f9000f60 	str	x0, [x27, #24]
    8138:	f9401820 	ldr	x0, [x1, #48]
    813c:	f9002362 	str	x2, [x27, #64]
    8140:	f9002760 	str	x0, [x27, #72]
    8144:	ad000020 	stp	q0, q0, [x1]
    8148:	3d800820 	str	q0, [x1, #32]
    814c:	f900183f 	str	xzr, [x1, #48]
    8150:	17ffffb6 	b	8028 <f12+0x288>
    8154:	d0ffffe0 	adrp	x0, 6000 <fwp_rc_free_arr+0x50>
    8158:	91230000 	add	x0, x0, #0x8c0
    815c:	94001781 	bl	df60 <atexit>
    8160:	35003900 	cbnz	w0, 8880 <f12+0xae0>
    8164:	52800020 	mov	w0, #0x1                   	// #1
    8168:	b903c740 	str	w0, [x26, #964]
    816c:	17ffff61 	b	7ef0 <f12+0x150>
    8170:	d3707c63 	ubfiz	x3, x3, #16, #32
    8174:	52800041 	mov	w1, #0x2                   	// #2
    8178:	aa040078 	orr	x24, x3, x4
    817c:	d2800100 	mov	x0, #0x8                   	// #8
    8180:	97fff3c4 	bl	5090 <fwp_heap_alloc>
    8184:	aa0003fa 	mov	x26, x0
    8188:	911902a0 	add	x0, x21, #0x640
    818c:	f900035f 	str	xzr, [x26]
    8190:	f949d801 	ldr	x1, [x0, #5040]
    8194:	f949ec00 	ldr	x0, [x0, #5080]
    8198:	cb010341 	sub	x1, x26, x1
    819c:	eb00403f 	cmp	x1, x0, lsl #16
    81a0:	54000e82 	b.cs	8370 <f12+0x5d0>  // b.hs, b.nlast
    81a4:	d2800019 	mov	x25, #0x0                   	// #0
    81a8:	911902a2 	add	x2, x21, #0x640
    81ac:	d350fc20 	lsr	x0, x1, #16
    81b0:	8b000800 	add	x0, x0, x0, lsl #2
    81b4:	f949fc43 	ldr	x3, [x2, #5112]
    81b8:	d37df002 	lsl	x2, x0, #3
    81bc:	8b020060 	add	x0, x3, x2
    81c0:	f940101b 	ldr	x27, [x0, #32]
    81c4:	b400025b 	cbz	x27, 820c <f12+0x46c>
    81c8:	38626862 	ldrb	w2, [x3, x2]
    81cc:	7100085f 	cmp	w2, #0x2
    81d0:	54000a20 	b.eq	8314 <f12+0x574>  // b.none
    81d4:	7100045f 	cmp	w2, #0x1
    81d8:	540001a1 	b.ne	820c <f12+0x46c>  // b.any
    81dc:	29430002 	ldp	w2, w0, [x0, #24]
    81e0:	92403c21 	and	x1, x1, #0xffff
    81e4:	9b027c21 	mul	x1, x1, x2
    81e8:	d360fc21 	lsr	x1, x1, #32
    81ec:	eb00003f 	cmp	x1, x0
    81f0:	540000e2 	b.cs	820c <f12+0x46c>  // b.hs, b.nlast
    81f4:	8b01037b 	add	x27, x27, x1
    81f8:	39400360 	ldrb	w0, [x27]
    81fc:	7103fc1f 	cmp	w0, #0xff
    8200:	54003220 	b.eq	8844 <f12+0xaa4>  // b.none
    8204:	52800020 	mov	w0, #0x1                   	// #1
    8208:	39000360 	strb	w0, [x27]
    820c:	b4000239 	cbz	x25, 8250 <f12+0x4b0>
    8210:	d3607f04 	lsl	x4, x24, #32
    8214:	aa1303e0 	mov	x0, x19
    8218:	f9400665 	ldr	x5, [x19, #8]
    821c:	aa0403e3 	mov	x3, x4
    8220:	91002342 	add	x2, x26, #0x8
    8224:	d2800001 	mov	x1, #0x0                   	// #0
    8228:	14000005 	b	823c <f12+0x49c>
    822c:	f9400405 	ldr	x5, [x0, #8]
    8230:	ab040023 	adds	x3, x1, x4
    8234:	91004042 	add	x2, x2, #0x10
    8238:	54005da6 	b.vs	8dec <f12+0x104c>
    823c:	a9000c45 	stp	x5, x3, [x2]
    8240:	91000421 	add	x1, x1, #0x1
    8244:	f9400800 	ldr	x0, [x0, #16]
    8248:	eb19003f 	cmp	x1, x25
    824c:	54ffff03 	b.cc	822c <f12+0x48c>  // b.lo, b.ul, b.last
    8250:	f9400340 	ldr	x0, [x26]
    8254:	f100041f 	cmp	x0, #0x1
    8258:	540008c9 	b.ls	8370 <f12+0x5d0>  // b.plast
    825c:	d341fc00 	lsr	x0, x0, #1
    8260:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8264:	d100041c 	sub	x28, x0, #0x1
    8268:	eb01039f 	cmp	x28, x1
    826c:	54fff448 	b.hi	80f4 <f12+0x354>  // b.pmore
    8270:	b400081c 	cbz	x28, 8370 <f12+0x5d0>
    8274:	d1002341 	sub	x1, x26, #0x8
    8278:	91002359 	add	x25, x26, #0x8
    827c:	8b00103b 	add	x27, x1, x0, lsl #4
    8280:	f9400720 	ldr	x0, [x25, #8]
    8284:	f9400f21 	ldr	x1, [x25, #24]
    8288:	fd400320 	ldr	d0, [x25]
    828c:	fd400b21 	ldr	d1, [x25, #16]
    8290:	97fff55c 	bl	5800 <w107>
    8294:	a9000720 	stp	x0, x1, [x25]
    8298:	91004339 	add	x25, x25, #0x10
    829c:	eb1b033f 	cmp	x25, x27
    82a0:	54ffff01 	b.ne	8280 <f12+0x4e0>  // b.any
    82a4:	aa1a03fb 	mov	x27, x26
    82a8:	d37ffb99 	lsl	x25, x28, #1
    82ac:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    82b0:	d280001c 	mov	x28, #0x0                   	// #0
    82b4:	f8010779 	str	x25, [x27], #16
    82b8:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    82bc:	aa0403e0 	mov	x0, x4
    82c0:	91000b9c 	add	x28, x28, #0x2
    82c4:	97fff4f7 	bl	56a0 <f128.constprop.0>
    82c8:	aa0003e4 	mov	x4, x0
    82cc:	eb19039f 	cmp	x28, x25
    82d0:	54ffff43 	b.cc	82b8 <f12+0x518>  // b.lo, b.ul, b.last
    82d4:	aa1a03e0 	mov	x0, x26
    82d8:	93407f18 	sxtw	x24, w24
    82dc:	f90007e4 	str	x4, [sp, #8]
    82e0:	97fffb1c 	bl	6f50 <fwp_drop4>
    82e4:	aa1803e0 	mov	x0, x24
    82e8:	97fff1f6 	bl	4ac0 <fwp_tape_of>
    82ec:	f9403019 	ldr	x25, [x0, #96]
    82f0:	aa0003e5 	mov	x5, x0
    82f4:	f94007e4 	ldr	x4, [sp, #8]
    82f8:	b4000479 	cbz	x25, 8384 <f12+0x5e4>
    82fc:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8300:	91140000 	add	x0, x0, #0x500
    8304:	97ffefec 	bl	42b4 <fwp_trap>
    8308:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    830c:	9117c000 	add	x0, x0, #0x5f0
    8310:	97ffefe9 	bl	42b4 <fwp_trap>
    8314:	72003c3f 	tst	w1, #0xffff
    8318:	54fff7a1 	b.ne	820c <f12+0x46c>  // b.any
    831c:	17ffffb7 	b	81f8 <f12+0x458>
    8320:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8324:	91170000 	add	x0, x0, #0x5c0
    8328:	97ffefe3 	bl	42b4 <fwp_trap>
    832c:	d37ffb3b 	lsl	x27, x25, #1
    8330:	d3707c63 	ubfiz	x3, x3, #16, #32
    8334:	91000760 	add	x0, x27, #0x1
    8338:	52800041 	mov	w1, #0x2                   	// #2
    833c:	aa040078 	orr	x24, x3, x4
    8340:	d37df000 	lsl	x0, x0, #3
    8344:	97fff353 	bl	5090 <fwp_heap_alloc>
    8348:	aa0003fa 	mov	x26, x0
    834c:	911902a1 	add	x1, x21, #0x640
    8350:	aa0103e0 	mov	x0, x1
    8354:	f900035b 	str	x27, [x26]
    8358:	f949d821 	ldr	x1, [x1, #5040]
    835c:	f949ec00 	ldr	x0, [x0, #5080]
    8360:	cb010341 	sub	x1, x26, x1
    8364:	eb00403f 	cmp	x1, x0, lsl #16
    8368:	54fff203 	b.cc	81a8 <f12+0x408>  // b.lo, b.ul, b.last
    836c:	b5fff539 	cbnz	x25, 8210 <f12+0x470>
    8370:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8374:	f900035f 	str	xzr, [x26]
    8378:	17ffffd7 	b	82d4 <f12+0x534>
    837c:	97fff102 	bl	4784 <fwp_rc_wide_dup>
    8380:	17fffec8 	b	7ea0 <f12+0x100>
    8384:	f9000fe4 	str	x4, [sp, #24]
    8388:	97ffeb03 	bl	2f94 <fwp_tape_unlink_scope>
    838c:	a9428cba 	ldp	x26, x3, [x5, #40]
    8390:	f90007e3 	str	x3, [sp, #8]
    8394:	f9401ca3 	ldr	x3, [x5, #56]
    8398:	b90004bf 	str	wzr, [x5, #4]
    839c:	b94000a1 	ldr	w1, [x5]
    83a0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    83a4:	f9000be3 	str	x3, [sp, #16]
    83a8:	a940a4bc 	ldp	x28, x9, [x5, #8]
    83ac:	6b00003f 	cmp	w1, w0
    83b0:	a941e4a2 	ldp	x2, x25, [x5, #24]
    83b4:	f9400fe4 	ldr	x4, [sp, #24]
    83b8:	a94418bb 	ldp	x27, x6, [x5, #64]
    83bc:	54000108 	b.hi	83dc <f12+0x63c>  // b.pmore
    83c0:	91018281 	add	x1, x20, #0x60
    83c4:	92403f00 	and	x0, x24, #0xffff
    83c8:	d1000400 	sub	x0, x0, #0x1
    83cc:	f940b023 	ldr	x3, [x1, #352]
    83d0:	eb03001f 	cmp	x0, x3
    83d4:	5400004a 	b.ge	83dc <f12+0x63c>  // b.tcont
    83d8:	f900b020 	str	x0, [x1, #352]
    83dc:	4f000400 	movi	v0.4s, #0x0
    83e0:	91018281 	add	x1, x20, #0x60
    83e4:	90ffffe0 	adrp	x0, 4000 <fwp_tape_buffers_dispose+0xc>
    83e8:	91045000 	add	x0, x0, #0x114
    83ec:	f9000cbf 	str	xzr, [x5, #24]
    83f0:	9101a3e7 	add	x7, sp, #0x68
    83f4:	f941c823 	ldr	x3, [x1, #912]
    83f8:	3c8080a0 	stur	q0, [x5, #8]
    83fc:	a90683e3 	stp	x3, x0, [sp, #104]
    8400:	910203e3 	add	x3, sp, #0x80
    8404:	f94007e0 	ldr	x0, [sp, #8]
    8408:	ad0100a0 	stp	q0, q0, [x5, #32]
    840c:	f9004be0 	str	x0, [sp, #144]
    8410:	f9400be0 	ldr	x0, [sp, #16]
    8414:	f9000fe3 	str	x3, [sp, #24]
    8418:	f90013e7 	str	x7, [sp, #32]
    841c:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    8420:	f9003fe3 	str	x3, [sp, #120]
    8424:	a9086bf9 	stp	x25, x26, [sp, #128]
    8428:	f9004fe0 	str	x0, [sp, #152]
    842c:	a90a0bfb 	stp	x27, x2, [sp, #160]
    8430:	f9005be6 	str	x6, [sp, #176]
    8434:	f901c827 	str	x7, [x1, #912]
    8438:	b7f82024 	tbnz	x4, #63, 883c <f12+0xa9c>
    843c:	eb84831f 	cmp	x24, x4, asr #32
    8440:	540000e0 	b.eq	845c <f12+0x6bc>  // b.none
    8444:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8448:	9112e000 	add	x0, x0, #0x4b8
    844c:	97ffef9a 	bl	42b4 <fwp_trap>
    8450:	d2800d01 	mov	x1, #0x68                  	// #104
    8454:	d2800023 	mov	x3, #0x1                   	// #1
    8458:	17fffec9 	b	7f7c <f12+0x1dc>
    845c:	92407c80 	and	x0, x4, #0xffffffff
    8460:	eb00039f 	cmp	x28, x0
    8464:	9a80c798 	csinc	x24, x28, x0, gt
    8468:	eb24413f 	cmp	x9, w4, uxtw
    846c:	54001f2d 	b.le	8850 <f12+0xab0>
    8470:	eb1800df 	cmp	x6, x24
    8474:	54001f6a 	b.ge	8860 <f12+0xac0>  // b.tcont
    8478:	f10000df 	cmp	x6, #0x0
    847c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    8480:	9a9810c6 	csel	x6, x6, x24, ne	// ne = any
    8484:	14000004 	b	8494 <f12+0x6f4>
    8488:	eb0100df 	cmp	x6, x1
    848c:	d37ff8c6 	lsl	x6, x6, #1
    8490:	9a98d0c6 	csel	x6, x6, x24, le
    8494:	eb1800df 	cmp	x6, x24
    8498:	54ffff8b 	b.lt	8488 <f12+0x6e8>  // b.tstop
    849c:	b400365b 	cbz	x27, 8b64 <f12+0xdc4>
    84a0:	aa1b03e0 	mov	x0, x27
    84a4:	d37df0c1 	lsl	x1, x6, #3
    84a8:	52800062 	mov	w2, #0x3                   	// #3
    84ac:	a90293e6 	stp	x6, x4, [sp, #40]
    84b0:	97ffeee5 	bl	4044 <ad_raw_realloc>
    84b4:	a94293e6 	ldp	x6, x4, [sp, #40]
    84b8:	aa0003fb 	mov	x27, x0
    84bc:	b4001d00 	cbz	x0, 885c <f12+0xabc>
    84c0:	f90053fb 	str	x27, [sp, #160]
    84c4:	f9005be6 	str	x6, [sp, #176]
    84c8:	b5001ad8 	cbnz	x24, 8820 <f12+0xa80>
    84cc:	b7f800c4 	tbnz	x4, #63, 84e4 <f12+0x744>
    84d0:	92407c84 	and	x4, x4, #0xffffffff
    84d4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    84d8:	fc647b60 	ldr	d0, [x27, x4, lsl #3]
    84dc:	1e612800 	fadd	d0, d0, d1
    84e0:	fc247b60 	str	d0, [x27, x4, lsl #3]
    84e4:	d1000700 	sub	x0, x24, #0x1
    84e8:	d1000783 	sub	x3, x28, #0x1
    84ec:	eb00039f 	cmp	x28, x0
    84f0:	540003ec 	b.gt	856c <f12+0x7cc>
    84f4:	fc607b60 	ldr	d0, [x27, x0, lsl #3]
    84f8:	1e602008 	fcmp	d0, #0.0
    84fc:	54000320 	b.eq	8560 <f12+0x7c0>  // b.none
    8500:	cb1c0be1 	neg	x1, x28, lsl #2
    8504:	cb1c03e4 	neg	x4, x28
    8508:	8b010322 	add	x2, x25, x1
    850c:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    8510:	37f80122 	tbnz	w2, #31, 8534 <f12+0x794>
    8514:	f94007e5 	ldr	x5, [sp, #8]
    8518:	93407c42 	sxtw	x2, w2
    851c:	8b040ca5 	add	x5, x5, x4, lsl #3
    8520:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    8524:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    8528:	1e620802 	fmul	d2, d0, d2
    852c:	1e622821 	fadd	d1, d1, d2
    8530:	fc227b61 	str	d1, [x27, x2, lsl #3]
    8534:	8b010341 	add	x1, x26, x1
    8538:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    853c:	37f80121 	tbnz	w1, #31, 8560 <f12+0x7c0>
    8540:	f9400be2 	ldr	x2, [sp, #16]
    8544:	93407c21 	sxtw	x1, w1
    8548:	8b040c44 	add	x4, x2, x4, lsl #3
    854c:	fc617b61 	ldr	d1, [x27, x1, lsl #3]
    8550:	fc607882 	ldr	d2, [x4, x0, lsl #3]
    8554:	1e620800 	fmul	d0, d0, d2
    8558:	1e602820 	fadd	d0, d1, d0
    855c:	fc217b60 	str	d0, [x27, x1, lsl #3]
    8560:	d1000400 	sub	x0, x0, #0x1
    8564:	eb00007f 	cmp	x3, x0
    8568:	54fffc61 	b.ne	84f4 <f12+0x754>  // b.any
    856c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8570:	eb00039f 	cmp	x28, x0
    8574:	540019e8 	b.hi	88b0 <f12+0xb10>  // b.pmore
    8578:	91000780 	add	x0, x28, #0x1
    857c:	52800041 	mov	w1, #0x2                   	// #2
    8580:	d37df000 	lsl	x0, x0, #3
    8584:	97fff2c3 	bl	5090 <fwp_heap_alloc>
    8588:	aa0003f8 	mov	x24, x0
    858c:	f800841c 	str	x28, [x0], #8
    8590:	d2800001 	mov	x1, #0x0                   	// #0
    8594:	b40000dc 	cbz	x28, 85ac <f12+0x80c>
    8598:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    859c:	f8217802 	str	x2, [x0, x1, lsl #3]
    85a0:	91000421 	add	x1, x1, #0x1
    85a4:	eb01039f 	cmp	x28, x1
    85a8:	54ffff81 	b.ne	8598 <f12+0x7f8>  // b.any
    85ac:	91018281 	add	x1, x20, #0x60
    85b0:	f94013e2 	ldr	x2, [sp, #32]
    85b4:	f941c820 	ldr	x0, [x1, #912]
    85b8:	eb02001f 	cmp	x0, x2
    85bc:	540041a1 	b.ne	8df0 <f12+0x1050>  // b.any
    85c0:	f9400fe0 	ldr	x0, [sp, #24]
    85c4:	f94037fa 	ldr	x26, [sp, #104]
    85c8:	f901c83a 	str	x26, [x1, #912]
    85cc:	97ffeed2 	bl	4114 <fwp_tape_buffers_release>
    85d0:	911902a2 	add	x2, x21, #0x640
    85d4:	f949d841 	ldr	x1, [x2, #5040]
    85d8:	f949ec40 	ldr	x0, [x2, #5080]
    85dc:	cb010301 	sub	x1, x24, x1
    85e0:	eb00403f 	cmp	x1, x0, lsl #16
    85e4:	54000322 	b.cs	8648 <f12+0x8a8>  // b.hs, b.nlast
    85e8:	d350fc20 	lsr	x0, x1, #16
    85ec:	f949fc43 	ldr	x3, [x2, #5112]
    85f0:	8b000800 	add	x0, x0, x0, lsl #2
    85f4:	d37df002 	lsl	x2, x0, #3
    85f8:	8b020060 	add	x0, x3, x2
    85fc:	f9401019 	ldr	x25, [x0, #32]
    8600:	b4000259 	cbz	x25, 8648 <f12+0x8a8>
    8604:	38626862 	ldrb	w2, [x3, x2]
    8608:	7100085f 	cmp	w2, #0x2
    860c:	54002a00 	b.eq	8b4c <f12+0xdac>  // b.none
    8610:	7100045f 	cmp	w2, #0x1
    8614:	540001a1 	b.ne	8648 <f12+0x8a8>  // b.any
    8618:	29430002 	ldp	w2, w0, [x0, #24]
    861c:	92403c21 	and	x1, x1, #0xffff
    8620:	9b027c21 	mul	x1, x1, x2
    8624:	d360fc21 	lsr	x1, x1, #32
    8628:	eb00003f 	cmp	x1, x0
    862c:	540000e2 	b.cs	8648 <f12+0x8a8>  // b.hs, b.nlast
    8630:	8b010339 	add	x25, x25, x1
    8634:	39400320 	ldrb	w0, [x25]
    8638:	7103fc1f 	cmp	w0, #0xff
    863c:	54003a80 	b.eq	8d8c <f12+0xfec>  // b.none
    8640:	52800020 	mov	w0, #0x1                   	// #1
    8644:	39000320 	strb	w0, [x25]
    8648:	eb17035f 	cmp	x26, x23
    864c:	54003d21 	b.ne	8df0 <f12+0x1050>  // b.any
    8650:	f9402be1 	ldr	x1, [sp, #80]
    8654:	91018294 	add	x20, x20, #0x60
    8658:	aa1603e0 	mov	x0, x22
    865c:	f901ca81 	str	x1, [x20, #912]
    8660:	97fff8dc 	bl	69d0 <fwp_tape_scope_release>
    8664:	f9400300 	ldr	x0, [x24]
    8668:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    866c:	b7f81360 	tbnz	x0, #63, 88d8 <f12+0xb38>
    8670:	911902a2 	add	x2, x21, #0x640
    8674:	f949d840 	ldr	x0, [x2, #5040]
    8678:	f949ec41 	ldr	x1, [x2, #5080]
    867c:	cb000300 	sub	x0, x24, x0
    8680:	eb01401f 	cmp	x0, x1, lsl #16
    8684:	540012a2 	b.cs	88d8 <f12+0xb38>  // b.hs, b.nlast
    8688:	d350fc01 	lsr	x1, x0, #16
    868c:	f949fc44 	ldr	x4, [x2, #5112]
    8690:	8b010821 	add	x1, x1, x1, lsl #2
    8694:	d37df021 	lsl	x1, x1, #3
    8698:	8b010083 	add	x3, x4, x1
    869c:	f9401062 	ldr	x2, [x3, #32]
    86a0:	b40011c2 	cbz	x2, 88d8 <f12+0xb38>
    86a4:	38616881 	ldrb	w1, [x4, x1]
    86a8:	7100083f 	cmp	w1, #0x2
    86ac:	54001120 	b.eq	88d0 <f12+0xb30>  // b.none
    86b0:	7100043f 	cmp	w1, #0x1
    86b4:	54001121 	b.ne	88d8 <f12+0xb38>  // b.any
    86b8:	29430464 	ldp	w4, w1, [x3, #24]
    86bc:	92403c00 	and	x0, x0, #0xffff
    86c0:	9b047c00 	mul	x0, x0, x4
    86c4:	d360fc00 	lsr	x0, x0, #32
    86c8:	eb01001f 	cmp	x0, x1
    86cc:	54001062 	b.cs	88d8 <f12+0xb38>  // b.hs, b.nlast
    86d0:	8b000042 	add	x2, x2, x0
    86d4:	39400040 	ldrb	w0, [x2]
    86d8:	7100041f 	cmp	w0, #0x1
    86dc:	54000fe1 	b.ne	88d8 <f12+0xb38>  // b.any
    86e0:	aa1803f7 	mov	x23, x24
    86e4:	aa1803f6 	mov	x22, x24
    86e8:	d2800000 	mov	x0, #0x0                   	// #0
    86ec:	910022c2 	add	x2, x22, #0x8
    86f0:	d2800001 	mov	x1, #0x0                   	// #0
    86f4:	b40001f9 	cbz	x25, 8730 <f12+0x990>
    86f8:	d0000023 	adrp	x3, e000 <_IO_stdin_used+0x70>
    86fc:	91002304 	add	x4, x24, #0x8
    8700:	fd47b061 	ldr	d1, [x3, #3936]
    8704:	f9400305 	ldr	x5, [x24]
    8708:	aa0403e3 	mov	x3, x4
    870c:	b7f80de5 	tbnz	x5, #63, 88c8 <f12+0xb28>
    8710:	f94002e5 	ldr	x5, [x23]
    8714:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    8718:	b7f80d25 	tbnz	x5, #63, 88bc <f12+0xb1c>
    871c:	1e600820 	fmul	d0, d1, d0
    8720:	91000421 	add	x1, x1, #0x1
    8724:	fc008440 	str	d0, [x2], #8
    8728:	eb01033f 	cmp	x25, x1
    872c:	54fffec1 	b.ne	8704 <f12+0x964>  // b.any
    8730:	97fffa08 	bl	6f50 <fwp_drop4>
    8734:	b4002a53 	cbz	x19, 8c7c <f12+0xedc>
    8738:	aa1303e0 	mov	x0, x19
    873c:	d2800014 	mov	x20, #0x0                   	// #0
    8740:	f9400800 	ldr	x0, [x0, #16]
    8744:	91000694 	add	x20, x20, #0x1
    8748:	b5ffffc0 	cbnz	x0, 8740 <f12+0x9a0>
    874c:	f94002e0 	ldr	x0, [x23]
    8750:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8754:	b7f811c0 	tbnz	x0, #63, 898c <f12+0xbec>
    8758:	911902a1 	add	x1, x21, #0x640
    875c:	f949d820 	ldr	x0, [x1, #5040]
    8760:	f949ec22 	ldr	x2, [x1, #5080]
    8764:	cb0002c0 	sub	x0, x22, x0
    8768:	eb02401f 	cmp	x0, x2, lsl #16
    876c:	540010e2 	b.cs	8988 <f12+0xbe8>  // b.hs, b.nlast
    8770:	d350fc02 	lsr	x2, x0, #16
    8774:	d2800503 	mov	x3, #0x28                  	// #40
    8778:	f949fc24 	ldr	x4, [x1, #5112]
    877c:	9b037c42 	mul	x2, x2, x3
    8780:	8b020083 	add	x3, x4, x2
    8784:	f9401061 	ldr	x1, [x3, #32]
    8788:	b4001001 	cbz	x1, 8988 <f12+0xbe8>
    878c:	38626882 	ldrb	w2, [x4, x2]
    8790:	7100085f 	cmp	w2, #0x2
    8794:	54000f60 	b.eq	8980 <f12+0xbe0>  // b.none
    8798:	7100045f 	cmp	w2, #0x1
    879c:	54000f61 	b.ne	8988 <f12+0xbe8>  // b.any
    87a0:	29430864 	ldp	w4, w2, [x3, #24]
    87a4:	92403c00 	and	x0, x0, #0xffff
    87a8:	9b047c00 	mul	x0, x0, x4
    87ac:	d360fc00 	lsr	x0, x0, #32
    87b0:	eb02001f 	cmp	x0, x2
    87b4:	54000ea2 	b.cs	8988 <f12+0xbe8>  // b.hs, b.nlast
    87b8:	8b000021 	add	x1, x1, x0
    87bc:	3940003c 	ldrb	w28, [x1]
    87c0:	7100079f 	cmp	w28, #0x1
    87c4:	54000e21 	b.ne	8988 <f12+0xbe8>  // b.any
    87c8:	910022f9 	add	x25, x23, #0x8
    87cc:	eb14031f 	cmp	x24, x20
    87d0:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    87d4:	b4002218 	cbz	x24, 8c14 <f12+0xe74>
    87d8:	d37df304 	lsl	x4, x24, #3
    87dc:	aa1303e1 	mov	x1, x19
    87e0:	910022c3 	add	x3, x22, #0x8
    87e4:	d2800000 	mov	x0, #0x0                   	// #0
    87e8:	14000009 	b	880c <f12+0xa6c>
    87ec:	fc606841 	ldr	d1, [x2, x0]
    87f0:	fd400420 	ldr	d0, [x1, #8]
    87f4:	1e613800 	fsub	d0, d0, d1
    87f8:	fc206b20 	str	d0, [x25, x0]
    87fc:	91002000 	add	x0, x0, #0x8
    8800:	f9400821 	ldr	x1, [x1, #16]
    8804:	eb00009f 	cmp	x4, x0
    8808:	54000ee0 	b.eq	89e4 <f12+0xc44>  // b.none
    880c:	f94002e5 	ldr	x5, [x23]
    8810:	aa0303e2 	mov	x2, x3
    8814:	b6fffec5 	tbz	x5, #63, 87ec <f12+0xa4c>
    8818:	f9400ac2 	ldr	x2, [x22, #16]
    881c:	17fffff4 	b	87ec <f12+0xa4c>
    8820:	d37df302 	lsl	x2, x24, #3
    8824:	aa1b03e0 	mov	x0, x27
    8828:	52800001 	mov	w1, #0x0                   	// #0
    882c:	f90017e4 	str	x4, [sp, #40]
    8830:	97ffe7ec 	bl	27e0 <memset@plt>
    8834:	f94017e4 	ldr	x4, [sp, #40]
    8838:	17ffff25 	b	84cc <f12+0x72c>
    883c:	aa1c03f8 	mov	x24, x28
    8840:	17ffff0c 	b	8470 <f12+0x6d0>
    8844:	aa1b03e0 	mov	x0, x27
    8848:	97ffeebb 	bl	4334 <fwp_rc_forget_slot.part.0>
    884c:	17fffe6e 	b	8204 <f12+0x464>
    8850:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8854:	9114c000 	add	x0, x0, #0x530
    8858:	97ffee97 	bl	42b4 <fwp_trap>
    885c:	d280001b 	mov	x27, #0x0                   	// #0
    8860:	f100031f 	cmp	x24, #0x0
    8864:	fa401b60 	ccmp	x27, #0x0, #0x0, ne	// ne = any
    8868:	54ffe301 	b.ne	84c8 <f12+0x728>  // b.any
    886c:	f9400fe0 	ldr	x0, [sp, #24]
    8870:	91018294 	add	x20, x20, #0x60
    8874:	f94037e1 	ldr	x1, [sp, #104]
    8878:	f901ca81 	str	x1, [x20, #912]
    887c:	97ffee26 	bl	4114 <fwp_tape_buffers_release>
    8880:	f0000123 	adrp	x3, 2f000 <fwp_fn_table+0xb30>
    8884:	f947e863 	ldr	x3, [x3, #4048]
    8888:	d2800262 	mov	x2, #0x13                  	// #19
    888c:	d2800021 	mov	x1, #0x1                   	// #1
    8890:	b0000020 	adrp	x0, d000 <f0+0x2390>
    8894:	913e6000 	add	x0, x0, #0xf98
    8898:	f9400063 	ldr	x3, [x3]
    889c:	97ffe81d 	bl	2910 <fwrite@plt>
    88a0:	d2800000 	mov	x0, #0x0                   	// #0
    88a4:	97ffe827 	bl	2940 <fflush@plt>
    88a8:	52800cc0 	mov	w0, #0x66                  	// #102
    88ac:	97ffe835 	bl	2980 <_Exit@plt>
    88b0:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    88b4:	91190000 	add	x0, x0, #0x640
    88b8:	97ffee7f 	bl	42b4 <fwp_trap>
    88bc:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    88c0:	91194000 	add	x0, x0, #0x650
    88c4:	97ffee7c 	bl	42b4 <fwp_trap>
    88c8:	f9400b03 	ldr	x3, [x24, #16]
    88cc:	17ffff91 	b	8710 <f12+0x970>
    88d0:	72003c1f 	tst	w0, #0xffff
    88d4:	54fff000 	b.eq	86d4 <f12+0x934>  // b.none
    88d8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    88dc:	eb00033f 	cmp	x25, x0
    88e0:	54fffe88 	b.hi	88b0 <f12+0xb10>  // b.pmore
    88e4:	91000720 	add	x0, x25, #0x1
    88e8:	52800021 	mov	w1, #0x1                   	// #1
    88ec:	d37df000 	lsl	x0, x0, #3
    88f0:	97fff1e8 	bl	5090 <fwp_heap_alloc>
    88f4:	911902a2 	add	x2, x21, #0x640
    88f8:	f9000019 	str	x25, [x0]
    88fc:	aa0003f7 	mov	x23, x0
    8900:	aa0003f6 	mov	x22, x0
    8904:	f949d841 	ldr	x1, [x2, #5040]
    8908:	f949ec40 	ldr	x0, [x2, #5080]
    890c:	cb0102e1 	sub	x1, x23, x1
    8910:	eb00403f 	cmp	x1, x0, lsl #16
    8914:	54000322 	b.cs	8978 <f12+0xbd8>  // b.hs, b.nlast
    8918:	d350fc20 	lsr	x0, x1, #16
    891c:	d2800504 	mov	x4, #0x28                  	// #40
    8920:	f949fc43 	ldr	x3, [x2, #5112]
    8924:	9b047c00 	mul	x0, x0, x4
    8928:	8b000062 	add	x2, x3, x0
    892c:	f9401054 	ldr	x20, [x2, #32]
    8930:	b4000254 	cbz	x20, 8978 <f12+0xbd8>
    8934:	38606860 	ldrb	w0, [x3, x0]
    8938:	7100081f 	cmp	w0, #0x2
    893c:	54002200 	b.eq	8d7c <f12+0xfdc>  // b.none
    8940:	7100041f 	cmp	w0, #0x1
    8944:	540001a1 	b.ne	8978 <f12+0xbd8>  // b.any
    8948:	29430043 	ldp	w3, w0, [x2, #24]
    894c:	92403c21 	and	x1, x1, #0xffff
    8950:	9b037c21 	mul	x1, x1, x3
    8954:	d360fc21 	lsr	x1, x1, #32
    8958:	eb00003f 	cmp	x1, x0
    895c:	540000e2 	b.cs	8978 <f12+0xbd8>  // b.hs, b.nlast
    8960:	8b010294 	add	x20, x20, x1
    8964:	39400280 	ldrb	w0, [x20]
    8968:	7103fc1f 	cmp	w0, #0xff
    896c:	54002020 	b.eq	8d70 <f12+0xfd0>  // b.none
    8970:	52800020 	mov	w0, #0x1                   	// #1
    8974:	39000280 	strb	w0, [x20]
    8978:	aa1803e0 	mov	x0, x24
    897c:	17ffff5c 	b	86ec <f12+0x94c>
    8980:	72003c1f 	tst	w0, #0xffff
    8984:	54fff1c0 	b.eq	87bc <f12+0xa1c>  // b.none
    8988:	b40013d3 	cbz	x19, 8c00 <f12+0xe60>
    898c:	aa1303fa 	mov	x26, x19
    8990:	d2800014 	mov	x20, #0x0                   	// #0
    8994:	f9400b5a 	ldr	x26, [x26, #16]
    8998:	aa1403e0 	mov	x0, x20
    899c:	91000694 	add	x20, x20, #0x1
    89a0:	b5ffffba 	cbnz	x26, 8994 <f12+0xbf4>
    89a4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    89a8:	eb01029f 	cmp	x20, x1
    89ac:	54ffba48 	b.hi	80f4 <f12+0x354>  // b.pmore
    89b0:	91000800 	add	x0, x0, #0x2
    89b4:	52800041 	mov	w1, #0x2                   	// #2
    89b8:	d37df000 	lsl	x0, x0, #3
    89bc:	97fff1b5 	bl	5090 <fwp_heap_alloc>
    89c0:	aa1303e1 	mov	x1, x19
    89c4:	aa0003f9 	mov	x25, x0
    89c8:	f9400420 	ldr	x0, [x1, #8]
    89cc:	f83a7b20 	str	x0, [x25, x26, lsl #3]
    89d0:	9100075a 	add	x26, x26, #0x1
    89d4:	f9400821 	ldr	x1, [x1, #16]
    89d8:	b5ffff81 	cbnz	x1, 89c8 <f12+0xc28>
    89dc:	5280001c 	mov	w28, #0x0                   	// #0
    89e0:	17ffff7b 	b	87cc <f12+0xa2c>
    89e4:	b4001f93 	cbz	x19, 8dd4 <f12+0x1034>
    89e8:	911902a0 	add	x0, x21, #0x640
    89ec:	aa1303e2 	mov	x2, x19
    89f0:	d280001b 	mov	x27, #0x0                   	// #0
    89f4:	f949ec04 	ldr	x4, [x0, #5080]
    89f8:	f949d807 	ldr	x7, [x0, #5040]
    89fc:	f949fc06 	ldr	x6, [x0, #5112]
    8a00:	d370bc84 	lsl	x4, x4, #16
    8a04:	14000006 	b	8a1c <f12+0xc7c>
    8a08:	f9400842 	ldr	x2, [x2, #16]
    8a0c:	9100077b 	add	x27, x27, #0x1
    8a10:	f100005f 	cmp	x2, #0x0
    8a14:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    8a18:	54000322 	b.cs	8a7c <f12+0xcdc>  // b.hs, b.nlast
    8a1c:	cb070040 	sub	x0, x2, x7
    8a20:	eb04001f 	cmp	x0, x4
    8a24:	540002c2 	b.cs	8a7c <f12+0xcdc>  // b.hs, b.nlast
    8a28:	d350fc01 	lsr	x1, x0, #16
    8a2c:	8b010821 	add	x1, x1, x1, lsl #2
    8a30:	d37df021 	lsl	x1, x1, #3
    8a34:	8b0100c5 	add	x5, x6, x1
    8a38:	f94010a3 	ldr	x3, [x5, #32]
    8a3c:	b4000203 	cbz	x3, 8a7c <f12+0xcdc>
    8a40:	386168c1 	ldrb	w1, [x6, x1]
    8a44:	7100083f 	cmp	w1, #0x2
    8a48:	54000880 	b.eq	8b58 <f12+0xdb8>  // b.none
    8a4c:	7100043f 	cmp	w1, #0x1
    8a50:	54000161 	b.ne	8a7c <f12+0xcdc>  // b.any
    8a54:	294304a8 	ldp	w8, w1, [x5, #24]
    8a58:	92403c00 	and	x0, x0, #0xffff
    8a5c:	9b087c00 	mul	x0, x0, x8
    8a60:	d360fc00 	lsr	x0, x0, #32
    8a64:	eb01001f 	cmp	x0, x1
    8a68:	540000a2 	b.cs	8a7c <f12+0xcdc>  // b.hs, b.nlast
    8a6c:	8b000063 	add	x3, x3, x0
    8a70:	39400060 	ldrb	w0, [x3]
    8a74:	7100041f 	cmp	w0, #0x1
    8a78:	54fffc80 	b.eq	8a08 <f12+0xc68>  // b.none
    8a7c:	d280001a 	mov	x26, #0x0                   	// #0
    8a80:	eb1b031f 	cmp	x24, x27
    8a84:	540018e9 	b.ls	8da0 <f12+0x1000>  // b.plast
    8a88:	d1002320 	sub	x0, x25, #0x8
    8a8c:	aa1803f4 	mov	x20, x24
    8a90:	911902b7 	add	x23, x21, #0x640
    8a94:	d280001a 	mov	x26, #0x0                   	// #0
    8a98:	f9000be0 	str	x0, [sp, #16]
    8a9c:	9102e3e0 	add	x0, sp, #0xb8
    8aa0:	f90007e0 	str	x0, [sp, #8]
    8aa4:	14000012 	b	8aec <f12+0xd4c>
    8aa8:	7100045f 	cmp	w2, #0x1
    8aac:	540001a1 	b.ne	8ae0 <f12+0xd40>  // b.any
    8ab0:	294308a6 	ldp	w6, w2, [x5, #24]
    8ab4:	92403c21 	and	x1, x1, #0xffff
    8ab8:	9b067c21 	mul	x1, x1, x6
    8abc:	d360fc21 	lsr	x1, x1, #32
    8ac0:	eb02003f 	cmp	x1, x2
    8ac4:	540000e2 	b.cs	8ae0 <f12+0xd40>  // b.hs, b.nlast
    8ac8:	8b010000 	add	x0, x0, x1
    8acc:	39400001 	ldrb	w1, [x0]
    8ad0:	7103fc3f 	cmp	w1, #0xff
    8ad4:	54001840 	b.eq	8ddc <f12+0x103c>  // b.none
    8ad8:	52800021 	mov	w1, #0x1                   	// #1
    8adc:	39000001 	strb	w1, [x0]
    8ae0:	d1000694 	sub	x20, x20, #0x1
    8ae4:	eb14037f 	cmp	x27, x20
    8ae8:	54000d42 	b.cs	8c90 <f12+0xef0>  // b.hs, b.nlast
    8aec:	a94083e1 	ldp	x1, x0, [sp, #8]
    8af0:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    8af4:	52800020 	mov	w0, #0x1                   	// #1
    8af8:	a90bebe2 	stp	x2, x26, [sp, #184]
    8afc:	97fff47a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    8b00:	aa0003fa 	mov	x26, x0
    8b04:	f949dae1 	ldr	x1, [x23, #5040]
    8b08:	f949eee0 	ldr	x0, [x23, #5080]
    8b0c:	cb010341 	sub	x1, x26, x1
    8b10:	eb00403f 	cmp	x1, x0, lsl #16
    8b14:	54fffe62 	b.cs	8ae0 <f12+0xd40>  // b.hs, b.nlast
    8b18:	d350fc20 	lsr	x0, x1, #16
    8b1c:	f949fee6 	ldr	x6, [x23, #5112]
    8b20:	8b000800 	add	x0, x0, x0, lsl #2
    8b24:	d37df002 	lsl	x2, x0, #3
    8b28:	8b0200c5 	add	x5, x6, x2
    8b2c:	f94010a0 	ldr	x0, [x5, #32]
    8b30:	b4fffd80 	cbz	x0, 8ae0 <f12+0xd40>
    8b34:	386268c2 	ldrb	w2, [x6, x2]
    8b38:	7100085f 	cmp	w2, #0x2
    8b3c:	54fffb61 	b.ne	8aa8 <f12+0xd08>  // b.any
    8b40:	72003c3f 	tst	w1, #0xffff
    8b44:	54fffce1 	b.ne	8ae0 <f12+0xd40>  // b.any
    8b48:	17ffffe1 	b	8acc <f12+0xd2c>
    8b4c:	72003c3f 	tst	w1, #0xffff
    8b50:	54ffd7c1 	b.ne	8648 <f12+0x8a8>  // b.any
    8b54:	17fffeb8 	b	8634 <f12+0x894>
    8b58:	72003c1f 	tst	w0, #0xffff
    8b5c:	54fff901 	b.ne	8a7c <f12+0xcdc>  // b.any
    8b60:	17ffffc4 	b	8a70 <f12+0xcd0>
    8b64:	d10004c1 	sub	x1, x6, #0x1
    8b68:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8b6c:	eb00003f 	cmp	x1, x0
    8b70:	540003c8 	b.hi	8be8 <f12+0xe48>  // b.pmore
    8b74:	90000340 	adrp	x0, 70000 <ad_raw_checkpoints+0x2fba0>
    8b78:	d2800003 	mov	x3, #0x0                   	// #0
    8b7c:	91118001 	add	x1, x0, #0x460
    8b80:	14000005 	b	8b94 <f12+0xdf4>
    8b84:	91000463 	add	x3, x3, #0x1
    8b88:	91006021 	add	x1, x1, #0x18
    8b8c:	f140047f 	cmp	x3, #0x1, lsl #12
    8b90:	54000320 	b.eq	8bf4 <f12+0xe54>  // b.none
    8b94:	f9400022 	ldr	x2, [x1]
    8b98:	b5ffff62 	cbnz	x2, 8b84 <f12+0xde4>
    8b9c:	91118002 	add	x2, x0, #0x460
    8ba0:	d2800307 	mov	x7, #0x18                  	// #24
    8ba4:	aa0603e0 	mov	x0, x6
    8ba8:	d2800101 	mov	x1, #0x8                   	// #8
    8bac:	f9001fe4 	str	x4, [sp, #56]
    8bb0:	9b070862 	madd	x2, x3, x7, x2
    8bb4:	a9029be2 	stp	x2, x6, [sp, #40]
    8bb8:	97ffe70e 	bl	27f0 <calloc@plt>
    8bbc:	aa0003fb 	mov	x27, x0
    8bc0:	a94313e6 	ldp	x6, x4, [sp, #48]
    8bc4:	b4ffe4c0 	cbz	x0, 885c <f12+0xabc>
    8bc8:	aa0003e1 	mov	x1, x0
    8bcc:	d37df0c2 	lsl	x2, x6, #3
    8bd0:	f94017e0 	ldr	x0, [sp, #40]
    8bd4:	52800063 	mov	w3, #0x3                   	// #3
    8bd8:	a90293e6 	stp	x6, x4, [sp, #40]
    8bdc:	97ffe8cd 	bl	2f10 <ad_raw_record>
    8be0:	a94293e6 	ldp	x6, x4, [sp, #40]
    8be4:	17fffe37 	b	84c0 <f12+0x720>
    8be8:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8bec:	91188000 	add	x0, x0, #0x620
    8bf0:	97ffe9c4 	bl	3300 <ad_raw_fail>
    8bf4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8bf8:	91086000 	add	x0, x0, #0x218
    8bfc:	97ffe9c1 	bl	3300 <ad_raw_fail>
    8c00:	52800041 	mov	w1, #0x2                   	// #2
    8c04:	d2800100 	mov	x0, #0x8                   	// #8
    8c08:	97fff122 	bl	5090 <fwp_heap_alloc>
    8c0c:	aa0003f9 	mov	x25, x0
    8c10:	5280001c 	mov	w28, #0x0                   	// #0
    8c14:	d280001a 	mov	x26, #0x0                   	// #0
    8c18:	7100039f 	cmp	w28, #0x0
    8c1c:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8c20:	aa1903e0 	mov	x0, x25
    8c24:	97ffee5f 	bl	45a0 <fwp_mem_free>
    8c28:	aa1603e0 	mov	x0, x22
    8c2c:	97fff8c9 	bl	6f50 <fwp_drop4>
    8c30:	aa1303e0 	mov	x0, x19
    8c34:	97fff617 	bl	6490 <fwp_drop0>
    8c38:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    8c3c:	f947f400 	ldr	x0, [x0, #4072]
    8c40:	f94067e2 	ldr	x2, [sp, #200]
    8c44:	f9400001 	ldr	x1, [x0]
    8c48:	eb010042 	subs	x2, x2, x1
    8c4c:	d2800001 	mov	x1, #0x0                   	// #0
    8c50:	54000141 	b.ne	8c78 <f12+0xed8>  // b.any
    8c54:	a94d7bfd 	ldp	x29, x30, [sp, #208]
    8c58:	aa1a03e0 	mov	x0, x26
    8c5c:	a94e53f3 	ldp	x19, x20, [sp, #224]
    8c60:	a94f5bf5 	ldp	x21, x22, [sp, #240]
    8c64:	a95063f7 	ldp	x23, x24, [sp, #256]
    8c68:	a9516bf9 	ldp	x25, x26, [sp, #272]
    8c6c:	a95273fb 	ldp	x27, x28, [sp, #288]
    8c70:	9104c3ff 	add	sp, sp, #0x130
    8c74:	d65f03c0 	ret
    8c78:	97ffe6e6 	bl	2810 <__stack_chk_fail@plt>
    8c7c:	f94002f8 	ldr	x24, [x23]
    8c80:	b7fffc18 	tbnz	x24, #63, 8c00 <f12+0xe60>
    8c84:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    8c88:	d2800014 	mov	x20, #0x0                   	// #0
    8c8c:	17fffeb3 	b	8758 <f12+0x9b8>
    8c90:	d1000701 	sub	x1, x24, #0x1
    8c94:	cb180360 	sub	x0, x27, x24
    8c98:	eb01037f 	cmp	x27, x1
    8c9c:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8ca0:	8b010000 	add	x0, x0, x1
    8ca4:	b50007fb 	cbnz	x27, 8da0 <f12+0x1000>
    8ca8:	7100039f 	cmp	w28, #0x0
    8cac:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8cb0:	b4fffb80 	cbz	x0, 8c20 <f12+0xe80>
    8cb4:	d1000414 	sub	x20, x0, #0x1
    8cb8:	911902b5 	add	x21, x21, #0x640
    8cbc:	52800038 	mov	w24, #0x1                   	// #1
    8cc0:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    8cc4:	52800020 	mov	w0, #0x1                   	// #1
    8cc8:	f94007e1 	ldr	x1, [sp, #8]
    8ccc:	a90bebe2 	stp	x2, x26, [sp, #184]
    8cd0:	97fff405 	bl	5ce4 <fwp_data.part.0.constprop.0>
    8cd4:	aa0003fa 	mov	x26, x0
    8cd8:	f949daa1 	ldr	x1, [x21, #5040]
    8cdc:	f949eea0 	ldr	x0, [x21, #5080]
    8ce0:	cb010341 	sub	x1, x26, x1
    8ce4:	eb00403f 	cmp	x1, x0, lsl #16
    8ce8:	54000302 	b.cs	8d48 <f12+0xfa8>  // b.hs, b.nlast
    8cec:	d350fc20 	lsr	x0, x1, #16
    8cf0:	f949fea3 	ldr	x3, [x21, #5112]
    8cf4:	8b000800 	add	x0, x0, x0, lsl #2
    8cf8:	d37df002 	lsl	x2, x0, #3
    8cfc:	8b020060 	add	x0, x3, x2
    8d00:	f940101b 	ldr	x27, [x0, #32]
    8d04:	b400023b 	cbz	x27, 8d48 <f12+0xfa8>
    8d08:	38626862 	ldrb	w2, [x3, x2]
    8d0c:	7100085f 	cmp	w2, #0x2
    8d10:	54000240 	b.eq	8d58 <f12+0xfb8>  // b.none
    8d14:	7100045f 	cmp	w2, #0x1
    8d18:	54000181 	b.ne	8d48 <f12+0xfa8>  // b.any
    8d1c:	29430002 	ldp	w2, w0, [x0, #24]
    8d20:	92403c21 	and	x1, x1, #0xffff
    8d24:	9b027c21 	mul	x1, x1, x2
    8d28:	d360fc21 	lsr	x1, x1, #32
    8d2c:	eb00003f 	cmp	x1, x0
    8d30:	540000c2 	b.cs	8d48 <f12+0xfa8>  // b.hs, b.nlast
    8d34:	8b01037b 	add	x27, x27, x1
    8d38:	39400360 	ldrb	w0, [x27]
    8d3c:	7103fc1f 	cmp	w0, #0xff
    8d40:	54000120 	b.eq	8d64 <f12+0xfc4>  // b.none
    8d44:	39000378 	strb	w24, [x27]
    8d48:	d1000694 	sub	x20, x20, #0x1
    8d4c:	b100069f 	cmn	x20, #0x1
    8d50:	54fffb81 	b.ne	8cc0 <f12+0xf20>  // b.any
    8d54:	17ffffb3 	b	8c20 <f12+0xe80>
    8d58:	72003c3f 	tst	w1, #0xffff
    8d5c:	54ffff61 	b.ne	8d48 <f12+0xfa8>  // b.any
    8d60:	17fffff6 	b	8d38 <f12+0xf98>
    8d64:	aa1b03e0 	mov	x0, x27
    8d68:	97ffed73 	bl	4334 <fwp_rc_forget_slot.part.0>
    8d6c:	17fffff6 	b	8d44 <f12+0xfa4>
    8d70:	aa1403e0 	mov	x0, x20
    8d74:	97ffed70 	bl	4334 <fwp_rc_forget_slot.part.0>
    8d78:	17fffefe 	b	8970 <f12+0xbd0>
    8d7c:	72003c3f 	tst	w1, #0xffff
    8d80:	54ffdf20 	b.eq	8964 <f12+0xbc4>  // b.none
    8d84:	aa1803e0 	mov	x0, x24
    8d88:	17fffe59 	b	86ec <f12+0x94c>
    8d8c:	aa1903e0 	mov	x0, x25
    8d90:	97ffed69 	bl	4334 <fwp_rc_forget_slot.part.0>
    8d94:	91018280 	add	x0, x20, #0x60
    8d98:	f941c81a 	ldr	x26, [x0, #912]
    8d9c:	17fffe29 	b	8640 <f12+0x8a0>
    8da0:	aa1303e0 	mov	x0, x19
    8da4:	d2800001 	mov	x1, #0x0                   	// #0
    8da8:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    8dac:	91000421 	add	x1, x1, #0x1
    8db0:	f9000402 	str	x2, [x0, #8]
    8db4:	aa0003e2 	mov	x2, x0
    8db8:	f9400800 	ldr	x0, [x0, #16]
    8dbc:	eb1b003f 	cmp	x1, x27
    8dc0:	54ffff43 	b.cc	8da8 <f12+0x1008>  // b.lo, b.ul, b.last
    8dc4:	f900085a 	str	x26, [x2, #16]
    8dc8:	aa1303fa 	mov	x26, x19
    8dcc:	aa0003f3 	mov	x19, x0
    8dd0:	17ffff92 	b	8c18 <f12+0xe78>
    8dd4:	d280001b 	mov	x27, #0x0                   	// #0
    8dd8:	17ffff2c 	b	8a88 <f12+0xce8>
    8ddc:	f9000fe0 	str	x0, [sp, #24]
    8de0:	97ffed55 	bl	4334 <fwp_rc_forget_slot.part.0>
    8de4:	f9400fe0 	ldr	x0, [sp, #24]
    8de8:	17ffff3c 	b	8ad8 <f12+0xd38>
    8dec:	97ffe705 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8df0:	97ffe69c 	bl	2860 <abort@plt>

0000000000008df4 <fwp_owned_entry12>:
    8df4:	f9400000 	ldr	x0, [x0]
    8df8:	17fffbea 	b	7da0 <f12>
    8dfc:	d503201f 	nop

0000000000008e00 <e12>:
    8e00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8e04:	910003fd 	mov	x29, sp
    8e08:	f9000bf3 	str	x19, [sp, #16]
    8e0c:	f9400013 	ldr	x19, [x0]
    8e10:	aa1303e0 	mov	x0, x19
    8e14:	97fff413 	bl	5e60 <fwp_rc_share>
    8e18:	aa1303e0 	mov	x0, x19
    8e1c:	97fffbe1 	bl	7da0 <f12>
    8e20:	aa0003f3 	mov	x19, x0
    8e24:	97fff40f 	bl	5e60 <fwp_rc_share>
    8e28:	aa1303e0 	mov	x0, x19
    8e2c:	f9400bf3 	ldr	x19, [sp, #16]
    8e30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8e34:	d65f03c0 	ret
    8e38:	d503201f 	nop
    8e3c:	d503201f 	nop

0000000000008e40 <fwp_write>:
    8e40:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8e44:	910003fd 	mov	x29, sp
    8e48:	f0000124 	adrp	x4, 2f000 <fwp_fn_table+0xb30>
    8e4c:	f947f484 	ldr	x4, [x4, #4072]
    8e50:	a90153f3 	stp	x19, x20, [sp, #16]
    8e54:	d10943ff 	sub	sp, sp, #0x250
    8e58:	b9400045 	ldr	w5, [x2]
    8e5c:	aa0003f4 	mov	x20, x0
    8e60:	f9400080 	ldr	x0, [x4]
    8e64:	f90127e0 	str	x0, [sp, #584]
    8e68:	d2800000 	mov	x0, #0x0                   	// #0
    8e6c:	710064bf 	cmp	w5, #0x19
    8e70:	54000408 	b.hi	8ef0 <fwp_write+0xb0>  // b.pmore
    8e74:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8e78:	aa0103f3 	mov	x19, x1
    8e7c:	913b0000 	add	x0, x0, #0xec0
    8e80:	f9013bf5 	str	x21, [sp, #624]
    8e84:	f9013ff6 	str	x22, [sp, #632]
    8e88:	f90153fb 	str	x27, [sp, #672]
    8e8c:	f90157fc 	str	x28, [sp, #680]
    8e90:	aa0203fc 	mov	x28, x2
    8e94:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8e98:	10000061 	adr	x1, 8ea4 <fwp_write+0x64>
    8e9c:	8b20a820 	add	x0, x1, w0, sxth #2
    8ea0:	d61f0000 	br	x0
    8ea4:	910123e0 	add	x0, sp, #0x48
    8ea8:	aa1303e5 	mov	x5, x19
    8eac:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x70>
    8eb0:	aa0003f3 	mov	x19, x0
    8eb4:	911ac084 	add	x4, x4, #0x6b0
    8eb8:	d2804003 	mov	x3, #0x200                 	// #512
    8ebc:	aa0303e1 	mov	x1, x3
    8ec0:	52800042 	mov	w2, #0x2                   	// #2
    8ec4:	97ffe62f 	bl	2780 <__snprintf_chk@plt>
    8ec8:	aa1303e0 	mov	x0, x19
    8ecc:	97ffe5f5 	bl	26a0 <strlen@plt>
    8ed0:	aa1303e1 	mov	x1, x19
    8ed4:	aa0003e2 	mov	x2, x0
    8ed8:	aa1403e0 	mov	x0, x20
    8edc:	97ffe9cd 	bl	3610 <buf_put>
    8ee0:	f9413bf5 	ldr	x21, [sp, #624]
    8ee4:	f9413ff6 	ldr	x22, [sp, #632]
    8ee8:	f94153fb 	ldr	x27, [sp, #672]
    8eec:	f94157fc 	ldr	x28, [sp, #680]
    8ef0:	f0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    8ef4:	f947f400 	ldr	x0, [x0, #4072]
    8ef8:	f94127e2 	ldr	x2, [sp, #584]
    8efc:	f9400001 	ldr	x1, [x0]
    8f00:	eb010042 	subs	x2, x2, x1
    8f04:	d2800001 	mov	x1, #0x0                   	// #0
    8f08:	540077c1 	b.ne	9e00 <fwp_write+0xfc0>  // b.any
    8f0c:	910943ff 	add	sp, sp, #0x250
    8f10:	a94153f3 	ldp	x19, x20, [sp, #16]
    8f14:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8f18:	d65f03c0 	ret
    8f1c:	910123e0 	add	x0, sp, #0x48
    8f20:	aa1303e5 	mov	x5, x19
    8f24:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x70>
    8f28:	aa0003f3 	mov	x19, x0
    8f2c:	911aa084 	add	x4, x4, #0x6a8
    8f30:	d2804003 	mov	x3, #0x200                 	// #512
    8f34:	17ffffe2 	b	8ebc <fwp_write+0x7c>
    8f38:	71004cbf 	cmp	w5, #0x13
    8f3c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    8f40:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    8f44:	911a6000 	add	x0, x0, #0x698
    8f48:	911a8021 	add	x1, x1, #0x6a0
    8f4c:	d2800082 	mov	x2, #0x4                   	// #4
    8f50:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8f54:	aa1403e0 	mov	x0, x20
    8f58:	f90143f7 	str	x23, [sp, #640]
    8f5c:	d2800016 	mov	x22, #0x0                   	// #0
    8f60:	f90147f8 	str	x24, [sp, #648]
    8f64:	97ffe9ab 	bl	3610 <buf_put>
    8f68:	f9400260 	ldr	x0, [x19]
    8f6c:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x70>
    8f70:	d2800015 	mov	x21, #0x0                   	// #0
    8f74:	911c82f7 	add	x23, x23, #0x720
    8f78:	b40047a0 	cbz	x0, 986c <fwp_write+0xa2c>
    8f7c:	b9400380 	ldr	w0, [x28]
    8f80:	52800003 	mov	w3, #0x0                   	// #0
    8f84:	f9401f82 	ldr	x2, [x28, #56]
    8f88:	71004c1f 	cmp	w0, #0x13
    8f8c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8f90:	aa1403e0 	mov	x0, x20
    8f94:	8b010e61 	add	x1, x19, x1, lsl #3
    8f98:	f9400421 	ldr	x1, [x1, #8]
    8f9c:	97ffffa9 	bl	8e40 <fwp_write>
    8fa0:	b9400380 	ldr	w0, [x28]
    8fa4:	7100481f 	cmp	w0, #0x12
    8fa8:	54004b40 	b.eq	9910 <fwp_write+0xad0>  // b.none
    8fac:	f9400260 	ldr	x0, [x19]
    8fb0:	910006b5 	add	x21, x21, #0x1
    8fb4:	91000ad6 	add	x22, x22, #0x2
    8fb8:	eb15001f 	cmp	x0, x21
    8fbc:	54004589 	b.ls	986c <fwp_write+0xa2c>  // b.plast
    8fc0:	aa1703e1 	mov	x1, x23
    8fc4:	aa1403e0 	mov	x0, x20
    8fc8:	d2800042 	mov	x2, #0x2                   	// #2
    8fcc:	97ffe991 	bl	3610 <buf_put>
    8fd0:	17ffffeb 	b	8f7c <fwp_write+0x13c>
    8fd4:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    8fd8:	911b6021 	add	x1, x1, #0x6d8
    8fdc:	d28000c2 	mov	x2, #0x6                   	// #6
    8fe0:	aa1403e0 	mov	x0, x20
    8fe4:	91004273 	add	x19, x19, #0x10
    8fe8:	97ffe98a 	bl	3610 <buf_put>
    8fec:	aa1303e0 	mov	x0, x19
    8ff0:	97ffe5ac 	bl	26a0 <strlen@plt>
    8ff4:	aa1303e1 	mov	x1, x19
    8ff8:	aa0003e2 	mov	x2, x0
    8ffc:	aa1403e0 	mov	x0, x20
    9000:	97ffe984 	bl	3610 <buf_put>
    9004:	528007c3 	mov	w3, #0x3e                  	// #62
    9008:	aa1403e0 	mov	x0, x20
    900c:	91001fe1 	add	x1, sp, #0x7
    9010:	d2800022 	mov	x2, #0x1                   	// #1
    9014:	39001fe3 	strb	w3, [sp, #7]
    9018:	17ffffb1 	b	8edc <fwp_write+0x9c>
    901c:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9020:	f947f400 	ldr	x0, [x0, #4072]
    9024:	f94127e2 	ldr	x2, [sp, #584]
    9028:	f9400001 	ldr	x1, [x0]
    902c:	eb010042 	subs	x2, x2, x1
    9030:	d2800001 	mov	x1, #0x0                   	// #0
    9034:	540034e1 	b.ne	96d0 <fwp_write+0x890>  // b.any
    9038:	f9413bf5 	ldr	x21, [sp, #624]
    903c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9040:	f9413ff6 	ldr	x22, [sp, #632]
    9044:	aa1403e0 	mov	x0, x20
    9048:	911ae021 	add	x1, x1, #0x6b8
    904c:	d2800142 	mov	x2, #0xa                   	// #10
    9050:	f94153fb 	ldr	x27, [sp, #672]
    9054:	f94157fc 	ldr	x28, [sp, #680]
    9058:	910943ff 	add	sp, sp, #0x250
    905c:	a94153f3 	ldp	x19, x20, [sp, #16]
    9060:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9064:	17ffe96b 	b	3610 <buf_put>
    9068:	f9400456 	ldr	x22, [x2, #8]
    906c:	f90143f7 	str	x23, [sp, #640]
    9070:	f90147f8 	str	x24, [sp, #648]
    9074:	b4005b16 	cbz	x22, 9bd4 <fwp_write+0xd94>
    9078:	aa1603e0 	mov	x0, x22
    907c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9080:	911ce021 	add	x1, x1, #0x738
    9084:	97ffe603 	bl	2890 <strcmp@plt>
    9088:	2a0003f5 	mov	w21, w0
    908c:	34005fe0 	cbz	w0, 9c88 <fwp_write+0xe48>
    9090:	aa1603e0 	mov	x0, x22
    9094:	97ffe583 	bl	26a0 <strlen@plt>
    9098:	aa1603e1 	mov	x1, x22
    909c:	aa0003e2 	mov	x2, x0
    90a0:	aa1403e0 	mov	x0, x20
    90a4:	97ffe95b 	bl	3610 <buf_put>
    90a8:	52800403 	mov	w3, #0x20                  	// #32
    90ac:	91001ff5 	add	x21, sp, #0x7
    90b0:	aa1503e1 	mov	x1, x21
    90b4:	aa1403e0 	mov	x0, x20
    90b8:	d2800022 	mov	x2, #0x1                   	// #1
    90bc:	39001fe3 	strb	w3, [sp, #7]
    90c0:	97ffe954 	bl	3610 <buf_put>
    90c4:	52800f63 	mov	w3, #0x7b                  	// #123
    90c8:	aa1403e0 	mov	x0, x20
    90cc:	aa1503e1 	mov	x1, x21
    90d0:	d2800022 	mov	x2, #0x1                   	// #1
    90d4:	39001fe3 	strb	w3, [sp, #7]
    90d8:	97ffe94e 	bl	3610 <buf_put>
    90dc:	b9401380 	ldr	w0, [x28, #16]
    90e0:	52800018 	mov	w24, #0x0                   	// #0
    90e4:	7100001f 	cmp	w0, #0x0
    90e8:	54003aad 	b.le	983c <fwp_write+0x9fc>
    90ec:	f9014bf9 	str	x25, [sp, #656]
    90f0:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x70>
    90f4:	911d8339 	add	x25, x25, #0x760
    90f8:	f9014ffa 	str	x26, [sp, #664]
    90fc:	b000003a 	adrp	x26, e000 <_IO_stdin_used+0x70>
    9100:	911c835a 	add	x26, x26, #0x720
    9104:	91002276 	add	x22, x19, #0x8
    9108:	d2800013 	mov	x19, #0x0                   	// #0
    910c:	b5003e93 	cbnz	x19, 98dc <fwp_write+0xa9c>
    9110:	d37df277 	lsl	x23, x19, #3
    9114:	34003cb8 	cbz	w24, 98a8 <fwp_write+0xa68>
    9118:	f9401382 	ldr	x2, [x28, #32]
    911c:	aa1403e0 	mov	x0, x20
    9120:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    9124:	52800003 	mov	w3, #0x0                   	// #0
    9128:	f8776842 	ldr	x2, [x2, x23]
    912c:	91000673 	add	x19, x19, #0x1
    9130:	97ffff44 	bl	8e40 <fwp_write>
    9134:	b9401380 	ldr	w0, [x28, #16]
    9138:	6b13001f 	cmp	w0, w19
    913c:	54fffe8c 	b.gt	910c <fwp_write+0x2cc>
    9140:	f9414bf9 	ldr	x25, [sp, #656]
    9144:	f9414ffa 	ldr	x26, [sp, #664]
    9148:	340037b8 	cbz	w24, 983c <fwp_write+0x9fc>
    914c:	52800523 	mov	w3, #0x29                  	// #41
    9150:	aa1503e1 	mov	x1, x21
    9154:	aa1403e0 	mov	x0, x20
    9158:	d2800022 	mov	x2, #0x1                   	// #1
    915c:	39001fe3 	strb	w3, [sp, #7]
    9160:	97ffe92c 	bl	3610 <buf_put>
    9164:	f9413bf5 	ldr	x21, [sp, #624]
    9168:	f9413ff6 	ldr	x22, [sp, #632]
    916c:	f94143f7 	ldr	x23, [sp, #640]
    9170:	f94147f8 	ldr	x24, [sp, #648]
    9174:	f94153fb 	ldr	x27, [sp, #672]
    9178:	f94157fc 	ldr	x28, [sp, #680]
    917c:	17ffff5d 	b	8ef0 <fwp_write+0xb0>
    9180:	b9404855 	ldr	w21, [x2, #72]
    9184:	aa1403e0 	mov	x0, x20
    9188:	93407eb6 	sxtw	x22, w21
    918c:	91000ac1 	add	x1, x22, #0x2
    9190:	97ffe8ec 	bl	3540 <buf_grow>
    9194:	a9400281 	ldp	x1, x0, [x20]
    9198:	528e8603 	mov	w3, #0x7430                	// #29744
    919c:	78206823 	strh	w3, [x1, x0]
    91a0:	8b000022 	add	x2, x1, x0
    91a4:	710002bf 	cmp	w21, #0x0
    91a8:	540036cd 	b.le	9880 <fwp_write+0xa40>
    91ac:	110006a3 	add	w3, w21, #0x1
    91b0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    91b4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    91b8:	91000449 	add	x9, x2, #0x1
    91bc:	8b23c043 	add	x3, x2, w3, sxtw
    91c0:	f28aaac6 	movk	x6, #0x5556
    91c4:	f2955568 	movk	x8, #0xaaab
    91c8:	1400000d 	b	91fc <fwp_write+0x3bc>
    91cc:	d2800021 	mov	x1, #0x1                   	// #1
    91d0:	528005a5 	mov	w5, #0x2d                  	// #45
    91d4:	f100001f 	cmp	x0, #0x0
    91d8:	9b467e60 	smulh	x0, x19, x6
    91dc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    91e0:	381ff465 	strb	w5, [x3], #-1
    91e4:	cb040000 	sub	x0, x0, x4
    91e8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    91ec:	cb020000 	sub	x0, x0, x2
    91f0:	8b010013 	add	x19, x0, x1
    91f4:	eb03013f 	cmp	x9, x3
    91f8:	54003440 	b.eq	9880 <fwp_write+0xa40>  // b.none
    91fc:	9b467e60 	smulh	x0, x19, x6
    9200:	937ffe64 	asr	x4, x19, #63
    9204:	52800605 	mov	w5, #0x30                  	// #48
    9208:	cb040000 	sub	x0, x0, x4
    920c:	8b000400 	add	x0, x0, x0, lsl #1
    9210:	cb000260 	sub	x0, x19, x0
    9214:	91000c01 	add	x1, x0, #0x3
    9218:	9bc87c22 	umulh	x2, x1, x8
    921c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    9220:	8b4204e2 	add	x2, x7, x2, lsr #1
    9224:	eb020021 	subs	x1, x1, x2
    9228:	54fffd60 	b.eq	91d4 <fwp_write+0x394>  // b.none
    922c:	f100043f 	cmp	x1, #0x1
    9230:	54fffce1 	b.ne	91cc <fwp_write+0x38c>  // b.any
    9234:	d2800001 	mov	x1, #0x0                   	// #0
    9238:	52800565 	mov	w5, #0x2b                  	// #43
    923c:	17ffffe6 	b	91d4 <fwp_write+0x394>
    9240:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9244:	f947f400 	ldr	x0, [x0, #4072]
    9248:	f94127e2 	ldr	x2, [sp, #584]
    924c:	f9400001 	ldr	x1, [x0]
    9250:	eb010042 	subs	x2, x2, x1
    9254:	d2800001 	mov	x1, #0x0                   	// #0
    9258:	540023c1 	b.ne	96d0 <fwp_write+0x890>  // b.any
    925c:	f9413bf5 	ldr	x21, [sp, #624]
    9260:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9264:	f9413ff6 	ldr	x22, [sp, #632]
    9268:	aa1403e0 	mov	x0, x20
    926c:	911b2021 	add	x1, x1, #0x6c8
    9270:	d2800102 	mov	x2, #0x8                   	// #8
    9274:	17ffff77 	b	9050 <fwp_write+0x210>
    9278:	aa1403e0 	mov	x0, x20
    927c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9280:	d28000c2 	mov	x2, #0x6                   	// #6
    9284:	911ca021 	add	x1, x1, #0x728
    9288:	97ffe8e2 	bl	3610 <buf_put>
    928c:	d2800015 	mov	x21, #0x0                   	// #0
    9290:	f9400263 	ldr	x3, [x19]
    9294:	f240f87f 	tst	x3, #0x7fffffffffffffff
    9298:	54002c60 	b.eq	9824 <fwp_write+0x9e4>  // b.none
    929c:	f9401f82 	ldr	x2, [x28, #56]
    92a0:	f90143f7 	str	x23, [sp, #640]
    92a4:	f90147f8 	str	x24, [sp, #648]
    92a8:	d2800857 	mov	x23, #0x42                  	// #66
    92ac:	f9014bf9 	str	x25, [sp, #656]
    92b0:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x70>
    92b4:	f9014ffa 	str	x26, [sp, #664]
    92b8:	911c82d6 	add	x22, x22, #0x720
    92bc:	d2800038 	mov	x24, #0x1                   	// #1
    92c0:	f2a18017 	movk	x23, #0xc00, lsl #16
    92c4:	d2809099 	mov	x25, #0x484                 	// #1156
    92c8:	b40004a2 	cbz	x2, 935c <fwp_write+0x51c>
    92cc:	b9400040 	ldr	w0, [x2]
    92d0:	7100701f 	cmp	w0, #0x1c
    92d4:	540042c0 	b.eq	9b2c <fwp_write+0xcec>  // b.none
    92d8:	71006c1f 	cmp	w0, #0x1b
    92dc:	54000408 	b.hi	935c <fwp_write+0x51c>  // b.pmore
    92e0:	9ac02301 	lsl	x1, x24, x0
    92e4:	ea17003f 	tst	x1, x23
    92e8:	540036a1 	b.ne	99bc <fwp_write+0xb7c>  // b.any
    92ec:	ea19003f 	tst	x1, x25
    92f0:	54003521 	b.ne	9994 <fwp_write+0xb54>  // b.any
    92f4:	d2800424 	mov	x4, #0x21                  	// #33
    92f8:	ea04003f 	tst	x1, x4
    92fc:	54000300 	b.eq	935c <fwp_write+0x51c>  // b.none
    9300:	b7f849c3 	tbnz	x3, #63, 9c38 <fwp_write+0xdf8>
    9304:	91002261 	add	x1, x19, #0x8
    9308:	8b150021 	add	x1, x1, x21
    930c:	39400021 	ldrb	w1, [x1]
    9310:	7100001f 	cmp	w0, #0x0
    9314:	93401c23 	sxtb	x3, w1
    9318:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    931c:	d503201f 	nop
    9320:	aa1403e0 	mov	x0, x20
    9324:	52800003 	mov	w3, #0x0                   	// #0
    9328:	97fffec6 	bl	8e40 <fwp_write>
    932c:	910006b5 	add	x21, x21, #0x1
    9330:	f9400260 	ldr	x0, [x19]
    9334:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    9338:	eb0002bf 	cmp	x21, x0
    933c:	540026c2 	b.cs	9814 <fwp_write+0x9d4>  // b.hs, b.nlast
    9340:	d2800042 	mov	x2, #0x2                   	// #2
    9344:	aa1603e1 	mov	x1, x22
    9348:	aa1403e0 	mov	x0, x20
    934c:	97ffe8b1 	bl	3610 <buf_put>
    9350:	f9401f82 	ldr	x2, [x28, #56]
    9354:	f9400263 	ldr	x3, [x19]
    9358:	b5fffba2 	cbnz	x2, 92cc <fwp_write+0x48c>
    935c:	d37df2a0 	lsl	x0, x21, #3
    9360:	b7f83f03 	tbnz	x3, #63, 9b40 <fwp_write+0xd00>
    9364:	91002261 	add	x1, x19, #0x8
    9368:	8b000020 	add	x0, x1, x0
    936c:	f9400001 	ldr	x1, [x0]
    9370:	17ffffec 	b	9320 <fwp_write+0x4e0>
    9374:	a9400e62 	ldp	x2, x3, [x19]
    9378:	b7f83ca3 	tbnz	x3, #63, 9b0c <fwp_write+0xccc>
    937c:	910123f5 	add	x21, sp, #0x48
    9380:	aa1503e0 	mov	x0, x21
    9384:	97ffe687 	bl	2da0 <fwp_fmt_u128>
    9388:	aa1503e0 	mov	x0, x21
    938c:	97ffe4c5 	bl	26a0 <strlen@plt>
    9390:	aa1503e1 	mov	x1, x21
    9394:	aa0003e2 	mov	x2, x0
    9398:	17fffed0 	b	8ed8 <fwp_write+0x98>
    939c:	fd015be8 	str	d8, [sp, #688]
    93a0:	1e270268 	fmov	s8, w19
    93a4:	fd015fe9 	str	d9, [sp, #696]
    93a8:	1e282100 	fcmp	s8, s8
    93ac:	54004d26 	b.vs	9d50 <fwp_write+0xf10>
    93b0:	1e20c101 	fabs	s1, s8
    93b4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    93b8:	1e270000 	fmov	s0, w0
    93bc:	1e202020 	fcmp	s1, s0
    93c0:	54002c0d 	b.le	9940 <fwp_write+0xb00>
    93c4:	1e202118 	fcmpe	s8, #0.0
    93c8:	b0000022 	adrp	x2, e000 <_IO_stdin_used+0x70>
    93cc:	91042042 	add	x2, x2, #0x108
    93d0:	910123f5 	add	x21, sp, #0x48
    93d4:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    93d8:	9119e021 	add	x1, x1, #0x678
    93dc:	aa1503e0 	mov	x0, x21
    93e0:	9a81c041 	csel	x1, x2, x1, gt
    93e4:	97ffe55b 	bl	2950 <strcpy@plt>
    93e8:	aa1503e0 	mov	x0, x21
    93ec:	97ffe4ad 	bl	26a0 <strlen@plt>
    93f0:	aa1503e1 	mov	x1, x21
    93f4:	aa0003e2 	mov	x2, x0
    93f8:	aa1403e0 	mov	x0, x20
    93fc:	97ffe885 	bl	3610 <buf_put>
    9400:	f9413bf5 	ldr	x21, [sp, #624]
    9404:	f9413ff6 	ldr	x22, [sp, #632]
    9408:	f94153fb 	ldr	x27, [sp, #672]
    940c:	f94157fc 	ldr	x28, [sp, #680]
    9410:	fd415be8 	ldr	d8, [sp, #688]
    9414:	fd415fe9 	ldr	d9, [sp, #696]
    9418:	17fffeb6 	b	8ef0 <fwp_write+0xb0>
    941c:	f9400276 	ldr	x22, [x19]
    9420:	34002e03 	cbz	w3, 99e0 <fwp_write+0xba0>
    9424:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9428:	f947f400 	ldr	x0, [x0, #4072]
    942c:	f94127e2 	ldr	x2, [sp, #584]
    9430:	f9400001 	ldr	x1, [x0]
    9434:	eb010042 	subs	x2, x2, x1
    9438:	d2800001 	mov	x1, #0x0                   	// #0
    943c:	540014a1 	b.ne	96d0 <fwp_write+0x890>  // b.any
    9440:	aa1603e2 	mov	x2, x22
    9444:	91002261 	add	x1, x19, #0x8
    9448:	f9413bf5 	ldr	x21, [sp, #624]
    944c:	aa1403e0 	mov	x0, x20
    9450:	f9413ff6 	ldr	x22, [sp, #632]
    9454:	17fffeff 	b	9050 <fwp_write+0x210>
    9458:	fd015be8 	str	d8, [sp, #688]
    945c:	9e670268 	fmov	d8, x19
    9460:	fd015fe9 	str	d9, [sp, #696]
    9464:	1e682100 	fcmp	d8, d8
    9468:	54004746 	b.vs	9d50 <fwp_write+0xf10>
    946c:	1e60c101 	fabs	d1, d8
    9470:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    9474:	9e670000 	fmov	d0, x0
    9478:	910123f5 	add	x21, sp, #0x48
    947c:	52800033 	mov	w19, #0x1                   	// #1
    9480:	1e602020 	fcmp	d1, d0
    9484:	540001ad 	b.le	94b8 <fwp_write+0x678>
    9488:	1e602118 	fcmpe	d8, #0.0
    948c:	b0000022 	adrp	x2, e000 <_IO_stdin_used+0x70>
    9490:	91042042 	add	x2, x2, #0x108
    9494:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9498:	9119e021 	add	x1, x1, #0x678
    949c:	aa1503e0 	mov	x0, x21
    94a0:	9a81c041 	csel	x1, x2, x1, gt
    94a4:	97ffe52b 	bl	2950 <strcpy@plt>
    94a8:	17ffffd0 	b	93e8 <fwp_write+0x5a8>
    94ac:	11000673 	add	w19, w19, #0x1
    94b0:	71004a7f 	cmp	w19, #0x12
    94b4:	54003860 	b.eq	9bc0 <fwp_write+0xd80>  // b.none
    94b8:	1e604100 	fmov	d0, d8
    94bc:	2a1303e1 	mov	w1, w19
    94c0:	aa1503e0 	mov	x0, x21
    94c4:	97ffe8af 	bl	3780 <fwp_format_g.constprop.0>
    94c8:	aa1503e0 	mov	x0, x21
    94cc:	d2800001 	mov	x1, #0x0                   	// #0
    94d0:	97ffe488 	bl	26f0 <strtod@plt>
    94d4:	1e602100 	fcmp	d8, d0
    94d8:	54fffea1 	b.ne	94ac <fwp_write+0x66c>  // b.any
    94dc:	aa1503e0 	mov	x0, x21
    94e0:	97ffe885 	bl	36f4 <fwp_finish_float>
    94e4:	17ffffc1 	b	93e8 <fwp_write+0x5a8>
    94e8:	a9400e62 	ldp	x2, x3, [x19]
    94ec:	910123f3 	add	x19, sp, #0x48
    94f0:	aa1303e0 	mov	x0, x19
    94f4:	97ffe62b 	bl	2da0 <fwp_fmt_u128>
    94f8:	17fffe74 	b	8ec8 <fwp_write+0x88>
    94fc:	f90143f7 	str	x23, [sp, #640]
    9500:	f90147f8 	str	x24, [sp, #648]
    9504:	2a1303f8 	mov	w24, w19
    9508:	f9014bf9 	str	x25, [sp, #656]
    950c:	f9014ffa 	str	x26, [sp, #664]
    9510:	f13ffe7f 	cmp	x19, #0xfff
    9514:	54000049 	b.ls	951c <fwp_write+0x6dc>  // b.plast
    9518:	b9400278 	ldr	w24, [x19]
    951c:	f9400f80 	ldr	x0, [x28, #24]
    9520:	2a1803f5 	mov	w21, w24
    9524:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9528:	d37ef6b9 	lsl	x25, x21, #2
    952c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9530:	aa1603e0 	mov	x0, x22
    9534:	97ffe45b 	bl	26a0 <strlen@plt>
    9538:	aa1603e1 	mov	x1, x22
    953c:	aa0003e2 	mov	x2, x0
    9540:	aa1403e0 	mov	x0, x20
    9544:	97ffe833 	bl	3610 <buf_put>
    9548:	f9401780 	ldr	x0, [x28, #40]
    954c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9550:	7100001f 	cmp	w0, #0x0
    9554:	5400068d 	b.le	9624 <fwp_write+0x7e4>
    9558:	91002276 	add	x22, x19, #0x8
    955c:	91001ff5 	add	x21, sp, #0x7
    9560:	d280001b 	mov	x27, #0x0                   	// #0
    9564:	5280041a 	mov	w26, #0x20                  	// #32
    9568:	f9401b80 	ldr	x0, [x28, #48]
    956c:	aa1503e1 	mov	x1, x21
    9570:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9574:	d2800022 	mov	x2, #0x1                   	// #1
    9578:	f8786803 	ldr	x3, [x0, x24]
    957c:	aa1403e0 	mov	x0, x20
    9580:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9584:	39001ffa 	strb	w26, [sp, #7]
    9588:	97ffe822 	bl	3610 <buf_put>
    958c:	f13ffeff 	cmp	x23, #0xfff
    9590:	b9400261 	ldr	w1, [x19]
    9594:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9598:	7100383f 	cmp	w1, #0xe
    959c:	54000160 	b.eq	95c8 <fwp_write+0x788>  // b.none
    95a0:	7100403f 	cmp	w1, #0x10
    95a4:	54001a60 	b.eq	98f0 <fwp_write+0xab0>  // b.none
    95a8:	7100283f 	cmp	w1, #0xa
    95ac:	54002aa0 	b.eq	9b00 <fwp_write+0xcc0>  // b.none
    95b0:	540014ac 	b.gt	9844 <fwp_write+0xa04>
    95b4:	71000c3f 	cmp	w1, #0x3
    95b8:	540029ac 	b.gt	9aec <fwp_write+0xcac>
    95bc:	d37ffee0 	lsr	x0, x23, #63
    95c0:	37f814a1 	tbnz	w1, #31, 9854 <fwp_write+0xa14>
    95c4:	d503201f 	nop
    95c8:	34001460 	cbz	w0, 9854 <fwp_write+0xa14>
    95cc:	52800503 	mov	w3, #0x28                  	// #40
    95d0:	aa1503e1 	mov	x1, x21
    95d4:	aa1403e0 	mov	x0, x20
    95d8:	d2800022 	mov	x2, #0x1                   	// #1
    95dc:	39001fe3 	strb	w3, [sp, #7]
    95e0:	97ffe80c 	bl	3610 <buf_put>
    95e4:	aa1303e2 	mov	x2, x19
    95e8:	aa1703e1 	mov	x1, x23
    95ec:	aa1403e0 	mov	x0, x20
    95f0:	52800003 	mov	w3, #0x0                   	// #0
    95f4:	97fffe13 	bl	8e40 <fwp_write>
    95f8:	52800523 	mov	w3, #0x29                  	// #41
    95fc:	aa1503e1 	mov	x1, x21
    9600:	aa1403e0 	mov	x0, x20
    9604:	d2800022 	mov	x2, #0x1                   	// #1
    9608:	39001fe3 	strb	w3, [sp, #7]
    960c:	97ffe801 	bl	3610 <buf_put>
    9610:	f9401780 	ldr	x0, [x28, #40]
    9614:	9100077b 	add	x27, x27, #0x1
    9618:	b8796800 	ldr	w0, [x0, x25]
    961c:	6b1b001f 	cmp	w0, w27
    9620:	54fffa4c 	b.gt	9568 <fwp_write+0x728>
    9624:	f9413bf5 	ldr	x21, [sp, #624]
    9628:	f9413ff6 	ldr	x22, [sp, #632]
    962c:	f94143f7 	ldr	x23, [sp, #640]
    9630:	f94147f8 	ldr	x24, [sp, #648]
    9634:	f9414bf9 	ldr	x25, [sp, #656]
    9638:	f9414ffa 	ldr	x26, [sp, #664]
    963c:	f94153fb 	ldr	x27, [sp, #672]
    9640:	f94157fc 	ldr	x28, [sp, #680]
    9644:	17fffe2b 	b	8ef0 <fwp_write+0xb0>
    9648:	52800783 	mov	w3, #0x3c                  	// #60
    964c:	91001ff3 	add	x19, sp, #0x7
    9650:	aa1303e1 	mov	x1, x19
    9654:	d2800022 	mov	x2, #0x1                   	// #1
    9658:	aa1403e0 	mov	x0, x20
    965c:	39001fe3 	strb	w3, [sp, #7]
    9660:	97ffe7ec 	bl	3610 <buf_put>
    9664:	f9400795 	ldr	x21, [x28, #8]
    9668:	aa1503e0 	mov	x0, x21
    966c:	97ffe40d 	bl	26a0 <strlen@plt>
    9670:	aa1503e1 	mov	x1, x21
    9674:	aa0003e2 	mov	x2, x0
    9678:	aa1403e0 	mov	x0, x20
    967c:	97ffe7e5 	bl	3610 <buf_put>
    9680:	528007c3 	mov	w3, #0x3e                  	// #62
    9684:	aa1303e1 	mov	x1, x19
    9688:	aa1403e0 	mov	x0, x20
    968c:	d2800022 	mov	x2, #0x1                   	// #1
    9690:	39001fe3 	strb	w3, [sp, #7]
    9694:	17fffe12 	b	8edc <fwp_write+0x9c>
    9698:	f100067f 	cmp	x19, #0x1
    969c:	540025a0 	b.eq	9b50 <fwp_write+0xd10>  // b.none
    96a0:	b100067f 	cmn	x19, #0x1
    96a4:	54002bc0 	b.eq	9c1c <fwp_write+0xddc>  // b.none
    96a8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    96ac:	911a0021 	add	x1, x1, #0x680
    96b0:	d2800022 	mov	x2, #0x1                   	// #1
    96b4:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    96b8:	f947f400 	ldr	x0, [x0, #4072]
    96bc:	f94127e4 	ldr	x4, [sp, #584]
    96c0:	f9400003 	ldr	x3, [x0]
    96c4:	eb030084 	subs	x4, x4, x3
    96c8:	d2800003 	mov	x3, #0x0                   	// #0
    96cc:	54ffebe0 	b.eq	9448 <fwp_write+0x608>  // b.none
    96d0:	f90143f7 	str	x23, [sp, #640]
    96d4:	f90147f8 	str	x24, [sp, #648]
    96d8:	f9014bf9 	str	x25, [sp, #656]
    96dc:	f9014ffa 	str	x26, [sp, #664]
    96e0:	fd015be8 	str	d8, [sp, #688]
    96e4:	fd015fe9 	str	d9, [sp, #696]
    96e8:	97ffe44a 	bl	2810 <__stack_chk_fail@plt>
    96ec:	52800b63 	mov	w3, #0x5b                  	// #91
    96f0:	91001ff5 	add	x21, sp, #0x7
    96f4:	aa1503e1 	mov	x1, x21
    96f8:	aa1403e0 	mov	x0, x20
    96fc:	d2800022 	mov	x2, #0x1                   	// #1
    9700:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x70>
    9704:	911c82d6 	add	x22, x22, #0x720
    9708:	39001fe3 	strb	w3, [sp, #7]
    970c:	97ffe7c1 	bl	3610 <buf_put>
    9710:	b4000273 	cbz	x19, 975c <fwp_write+0x91c>
    9714:	f9400661 	ldr	x1, [x19, #8]
    9718:	aa1403e0 	mov	x0, x20
    971c:	f9401f82 	ldr	x2, [x28, #56]
    9720:	52800003 	mov	w3, #0x0                   	// #0
    9724:	97fffdc7 	bl	8e40 <fwp_write>
    9728:	f9400a73 	ldr	x19, [x19, #16]
    972c:	b4000193 	cbz	x19, 975c <fwp_write+0x91c>
    9730:	aa1603e1 	mov	x1, x22
    9734:	aa1403e0 	mov	x0, x20
    9738:	d2800042 	mov	x2, #0x2                   	// #2
    973c:	97ffe7b5 	bl	3610 <buf_put>
    9740:	f9400661 	ldr	x1, [x19, #8]
    9744:	aa1403e0 	mov	x0, x20
    9748:	f9401f82 	ldr	x2, [x28, #56]
    974c:	52800003 	mov	w3, #0x0                   	// #0
    9750:	97fffdbc 	bl	8e40 <fwp_write>
    9754:	f9400a73 	ldr	x19, [x19, #16]
    9758:	b5fffed3 	cbnz	x19, 9730 <fwp_write+0x8f0>
    975c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9760:	aa1503e1 	mov	x1, x21
    9764:	aa1403e0 	mov	x0, x20
    9768:	d2800022 	mov	x2, #0x1                   	// #1
    976c:	39001fe3 	strb	w3, [sp, #7]
    9770:	17fffddb 	b	8edc <fwp_write+0x9c>
    9774:	aa1403e0 	mov	x0, x20
    9778:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    977c:	d28000c2 	mov	x2, #0x6                   	// #6
    9780:	911c4021 	add	x1, x1, #0x710
    9784:	97ffe7a3 	bl	3610 <buf_put>
    9788:	f9400260 	ldr	x0, [x19]
    978c:	b40004c0 	cbz	x0, 9824 <fwp_write+0x9e4>
    9790:	910123f5 	add	x21, sp, #0x48
    9794:	91002276 	add	x22, x19, #0x8
    9798:	f90143f7 	str	x23, [sp, #640]
    979c:	d2800017 	mov	x23, #0x0                   	// #0
    97a0:	f90147f8 	str	x24, [sp, #648]
    97a4:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x70>
    97a8:	911c6318 	add	x24, x24, #0x718
    97ac:	f9014bf9 	str	x25, [sp, #656]
    97b0:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x70>
    97b4:	911c8339 	add	x25, x25, #0x720
    97b8:	f9014ffa 	str	x26, [sp, #664]
    97bc:	14000005 	b	97d0 <fwp_write+0x990>
    97c0:	aa1903e1 	mov	x1, x25
    97c4:	aa1403e0 	mov	x0, x20
    97c8:	d2800042 	mov	x2, #0x2                   	// #2
    97cc:	97ffe791 	bl	3610 <buf_put>
    97d0:	38776ac5 	ldrb	w5, [x22, x23]
    97d4:	d2804003 	mov	x3, #0x200                 	// #512
    97d8:	aa1803e4 	mov	x4, x24
    97dc:	aa0303e1 	mov	x1, x3
    97e0:	52800042 	mov	w2, #0x2                   	// #2
    97e4:	aa1503e0 	mov	x0, x21
    97e8:	910006f7 	add	x23, x23, #0x1
    97ec:	97ffe3e5 	bl	2780 <__snprintf_chk@plt>
    97f0:	aa1503e0 	mov	x0, x21
    97f4:	97ffe3ab 	bl	26a0 <strlen@plt>
    97f8:	aa1503e1 	mov	x1, x21
    97fc:	aa0003e2 	mov	x2, x0
    9800:	aa1403e0 	mov	x0, x20
    9804:	97ffe783 	bl	3610 <buf_put>
    9808:	f9400260 	ldr	x0, [x19]
    980c:	eb17001f 	cmp	x0, x23
    9810:	54fffd88 	b.hi	97c0 <fwp_write+0x980>  // b.pmore
    9814:	f94143f7 	ldr	x23, [sp, #640]
    9818:	f94147f8 	ldr	x24, [sp, #648]
    981c:	f9414bf9 	ldr	x25, [sp, #656]
    9820:	f9414ffa 	ldr	x26, [sp, #664]
    9824:	52800ba3 	mov	w3, #0x5d                  	// #93
    9828:	aa1403e0 	mov	x0, x20
    982c:	91001fe1 	add	x1, sp, #0x7
    9830:	d2800022 	mov	x2, #0x1                   	// #1
    9834:	39001fe3 	strb	w3, [sp, #7]
    9838:	17fffda9 	b	8edc <fwp_write+0x9c>
    983c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9840:	17fffe44 	b	9150 <fwp_write+0x310>
    9844:	f10002ff 	cmp	x23, #0x0
    9848:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    984c:	71002c3f 	cmp	w1, #0xb
    9850:	54ffebc0 	b.eq	95c8 <fwp_write+0x788>  // b.none
    9854:	aa1303e2 	mov	x2, x19
    9858:	aa1703e1 	mov	x1, x23
    985c:	aa1403e0 	mov	x0, x20
    9860:	52800003 	mov	w3, #0x0                   	// #0
    9864:	97fffd77 	bl	8e40 <fwp_write>
    9868:	17ffff6a 	b	9610 <fwp_write+0x7d0>
    986c:	aa1403e0 	mov	x0, x20
    9870:	91001fe1 	add	x1, sp, #0x7
    9874:	52800fa3 	mov	w3, #0x7d                  	// #125
    9878:	d2800022 	mov	x2, #0x1                   	// #1
    987c:	17fffe38 	b	915c <fwp_write+0x31c>
    9880:	a9400281 	ldp	x1, x0, [x20]
    9884:	91000800 	add	x0, x0, #0x2
    9888:	8b160000 	add	x0, x0, x22
    988c:	f9000680 	str	x0, [x20, #8]
    9890:	3820683f 	strb	wzr, [x1, x0]
    9894:	f9413bf5 	ldr	x21, [sp, #624]
    9898:	f9413ff6 	ldr	x22, [sp, #632]
    989c:	f94153fb 	ldr	x27, [sp, #672]
    98a0:	f94157fc 	ldr	x28, [sp, #680]
    98a4:	17fffd93 	b	8ef0 <fwp_write+0xb0>
    98a8:	f9400f80 	ldr	x0, [x28, #24]
    98ac:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    98b0:	aa1b03e0 	mov	x0, x27
    98b4:	97ffe37b 	bl	26a0 <strlen@plt>
    98b8:	aa1b03e1 	mov	x1, x27
    98bc:	aa0003e2 	mov	x2, x0
    98c0:	aa1403e0 	mov	x0, x20
    98c4:	97ffe753 	bl	3610 <buf_put>
    98c8:	aa1903e1 	mov	x1, x25
    98cc:	aa1403e0 	mov	x0, x20
    98d0:	d2800062 	mov	x2, #0x3                   	// #3
    98d4:	97ffe74f 	bl	3610 <buf_put>
    98d8:	17fffe10 	b	9118 <fwp_write+0x2d8>
    98dc:	aa1a03e1 	mov	x1, x26
    98e0:	aa1403e0 	mov	x0, x20
    98e4:	d2800042 	mov	x2, #0x2                   	// #2
    98e8:	97ffe74a 	bl	3610 <buf_put>
    98ec:	17fffe09 	b	9110 <fwp_write+0x2d0>
    98f0:	f9400660 	ldr	x0, [x19, #8]
    98f4:	b4fffb00 	cbz	x0, 9854 <fwp_write+0xa14>
    98f8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    98fc:	911ce021 	add	x1, x1, #0x738
    9900:	97ffe3e4 	bl	2890 <strcmp@plt>
    9904:	7100001f 	cmp	w0, #0x0
    9908:	1a9f07e0 	cset	w0, ne	// ne = any
    990c:	17ffff2f 	b	95c8 <fwp_write+0x788>
    9910:	aa1403e0 	mov	x0, x20
    9914:	d2800042 	mov	x2, #0x2                   	// #2
    9918:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    991c:	911cc021 	add	x1, x1, #0x730
    9920:	97ffe73c 	bl	3610 <buf_put>
    9924:	91004261 	add	x1, x19, #0x10
    9928:	aa1403e0 	mov	x0, x20
    992c:	f9402382 	ldr	x2, [x28, #64]
    9930:	52800003 	mov	w3, #0x0                   	// #0
    9934:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9938:	97fffd42 	bl	8e40 <fwp_write>
    993c:	17fffd9c 	b	8fac <fwp_write+0x16c>
    9940:	1e22c109 	fcvt	d9, s8
    9944:	910123f5 	add	x21, sp, #0x48
    9948:	52800033 	mov	w19, #0x1                   	// #1
    994c:	d503201f 	nop
    9950:	1e604120 	fmov	d0, d9
    9954:	2a1303e1 	mov	w1, w19
    9958:	aa1503e0 	mov	x0, x21
    995c:	97ffe789 	bl	3780 <fwp_format_g.constprop.0>
    9960:	aa1503e0 	mov	x0, x21
    9964:	d2800001 	mov	x1, #0x0                   	// #0
    9968:	97ffe3d6 	bl	28c0 <strtof@plt>
    996c:	1e202100 	fcmp	s8, s0
    9970:	54ffdb60 	b.eq	94dc <fwp_write+0x69c>  // b.none
    9974:	11000673 	add	w19, w19, #0x1
    9978:	71002a7f 	cmp	w19, #0xa
    997c:	54fffea1 	b.ne	9950 <fwp_write+0xb10>  // b.any
    9980:	1e604120 	fmov	d0, d9
    9984:	aa1503e0 	mov	x0, x21
    9988:	52800121 	mov	w1, #0x9                   	// #9
    998c:	97ffe77d 	bl	3780 <fwp_format_g.constprop.0>
    9990:	17fffed3 	b	94dc <fwp_write+0x69c>
    9994:	d37ef6a1 	lsl	x1, x21, #2
    9998:	b7f81563 	tbnz	x3, #63, 9c44 <fwp_write+0xe04>
    999c:	91002263 	add	x3, x19, #0x8
    99a0:	8b010061 	add	x1, x3, x1
    99a4:	b9400023 	ldr	w3, [x1]
    99a8:	7100081f 	cmp	w0, #0x2
    99ac:	2a0303e1 	mov	w1, w3
    99b0:	93407c63 	sxtw	x3, w3
    99b4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    99b8:	17fffe5a 	b	9320 <fwp_write+0x4e0>
    99bc:	d37ffaa1 	lsl	x1, x21, #1
    99c0:	b7f81363 	tbnz	x3, #63, 9c2c <fwp_write+0xdec>
    99c4:	91002263 	add	x3, x19, #0x8
    99c8:	8b010061 	add	x1, x3, x1
    99cc:	79400021 	ldrh	w1, [x1]
    99d0:	7100041f 	cmp	w0, #0x1
    99d4:	93403c23 	sxth	x3, w1
    99d8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    99dc:	17fffe51 	b	9320 <fwp_write+0x4e0>
    99e0:	52800443 	mov	w3, #0x22                  	// #34
    99e4:	91001ff5 	add	x21, sp, #0x7
    99e8:	91002273 	add	x19, x19, #0x8
    99ec:	aa1503e1 	mov	x1, x21
    99f0:	aa1403e0 	mov	x0, x20
    99f4:	d2800022 	mov	x2, #0x1                   	// #1
    99f8:	39001fe3 	strb	w3, [sp, #7]
    99fc:	f90143f7 	str	x23, [sp, #640]
    9a00:	8b160277 	add	x23, x19, x22
    9a04:	f90147f8 	str	x24, [sp, #648]
    9a08:	97ffe702 	bl	3610 <buf_put>
    9a0c:	b4000696 	cbz	x22, 9adc <fwp_write+0xc9c>
    9a10:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x70>
    9a14:	911b8318 	add	x24, x24, #0x6e0
    9a18:	f9014bf9 	str	x25, [sp, #656]
    9a1c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x70>
    9a20:	911c0339 	add	x25, x25, #0x700
    9a24:	f9014ffa 	str	x26, [sp, #664]
    9a28:	1400000d 	b	9a5c <fwp_write+0xc1c>
    9a2c:	710024bf 	cmp	w5, #0x9
    9a30:	54000460 	b.eq	9abc <fwp_write+0xc7c>  // b.none
    9a34:	710028bf 	cmp	w5, #0xa
    9a38:	54000a61 	b.ne	9b84 <fwp_write+0xd44>  // b.any
    9a3c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9a40:	aa1403e0 	mov	x0, x20
    9a44:	911bc021 	add	x1, x1, #0x6f0
    9a48:	d2800042 	mov	x2, #0x2                   	// #2
    9a4c:	97ffe6f1 	bl	3610 <buf_put>
    9a50:	91000673 	add	x19, x19, #0x1
    9a54:	eb17027f 	cmp	x19, x23
    9a58:	540003e0 	b.eq	9ad4 <fwp_write+0xc94>  // b.none
    9a5c:	39400265 	ldrb	w5, [x19]
    9a60:	710034bf 	cmp	w5, #0xd
    9a64:	54000180 	b.eq	9a94 <fwp_write+0xc54>  // b.none
    9a68:	54fffe29 	b.ls	9a2c <fwp_write+0xbec>  // b.plast
    9a6c:	710088bf 	cmp	w5, #0x22
    9a70:	540001c0 	b.eq	9aa8 <fwp_write+0xc68>  // b.none
    9a74:	710170bf 	cmp	w5, #0x5c
    9a78:	54000741 	b.ne	9b60 <fwp_write+0xd20>  // b.any
    9a7c:	aa1403e0 	mov	x0, x20
    9a80:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9a84:	d2800042 	mov	x2, #0x2                   	// #2
    9a88:	911ba021 	add	x1, x1, #0x6e8
    9a8c:	97ffe6e1 	bl	3610 <buf_put>
    9a90:	17fffff0 	b	9a50 <fwp_write+0xc10>
    9a94:	aa1903e1 	mov	x1, x25
    9a98:	aa1403e0 	mov	x0, x20
    9a9c:	d2800042 	mov	x2, #0x2                   	// #2
    9aa0:	97ffe6dc 	bl	3610 <buf_put>
    9aa4:	17ffffeb 	b	9a50 <fwp_write+0xc10>
    9aa8:	aa1803e1 	mov	x1, x24
    9aac:	aa1403e0 	mov	x0, x20
    9ab0:	d2800042 	mov	x2, #0x2                   	// #2
    9ab4:	97ffe6d7 	bl	3610 <buf_put>
    9ab8:	17ffffe6 	b	9a50 <fwp_write+0xc10>
    9abc:	aa1403e0 	mov	x0, x20
    9ac0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9ac4:	d2800042 	mov	x2, #0x2                   	// #2
    9ac8:	911be021 	add	x1, x1, #0x6f8
    9acc:	97ffe6d1 	bl	3610 <buf_put>
    9ad0:	17ffffe0 	b	9a50 <fwp_write+0xc10>
    9ad4:	f9414bf9 	ldr	x25, [sp, #656]
    9ad8:	f9414ffa 	ldr	x26, [sp, #664]
    9adc:	aa1503e1 	mov	x1, x21
    9ae0:	aa1403e0 	mov	x0, x20
    9ae4:	52800443 	mov	w3, #0x22                  	// #34
    9ae8:	17fffd9c 	b	9158 <fwp_write+0x318>
    9aec:	7100103f 	cmp	w1, #0x4
    9af0:	54ffeb21 	b.ne	9854 <fwp_write+0xa14>  // b.any
    9af4:	f94006e0 	ldr	x0, [x23, #8]
    9af8:	d37ffc00 	lsr	x0, x0, #63
    9afc:	17fffeb3 	b	95c8 <fwp_write+0x788>
    9b00:	710002ff 	cmp	w23, #0x0
    9b04:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9b08:	17fffeb0 	b	95c8 <fwp_write+0x788>
    9b0c:	528005a1 	mov	w1, #0x2d                  	// #45
    9b10:	eb0203e2 	negs	x2, x2
    9b14:	da0303e3 	ngc	x3, x3
    9b18:	910127e0 	add	x0, sp, #0x49
    9b1c:	910123f5 	add	x21, sp, #0x48
    9b20:	390123e1 	strb	w1, [sp, #72]
    9b24:	97ffe49f 	bl	2da0 <fwp_fmt_u128>
    9b28:	17fffe18 	b	9388 <fwp_write+0x548>
    9b2c:	d37ceea1 	lsl	x1, x21, #4
    9b30:	b7f810a3 	tbnz	x3, #63, 9d44 <fwp_write+0xf04>
    9b34:	91002260 	add	x0, x19, #0x8
    9b38:	8b010001 	add	x1, x0, x1
    9b3c:	17fffdf9 	b	9320 <fwp_write+0x4e0>
    9b40:	f9400a61 	ldr	x1, [x19, #16]
    9b44:	8b010000 	add	x0, x0, x1
    9b48:	f9400001 	ldr	x1, [x0]
    9b4c:	17fffdf5 	b	9320 <fwp_write+0x4e0>
    9b50:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9b54:	d2800042 	mov	x2, #0x2                   	// #2
    9b58:	911a2021 	add	x1, x1, #0x688
    9b5c:	17fffed6 	b	96b4 <fwp_write+0x874>
    9b60:	7101fcbf 	cmp	w5, #0x7f
    9b64:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9b68:	540000e9 	b.ls	9b84 <fwp_write+0xd44>  // b.plast
    9b6c:	aa1503e1 	mov	x1, x21
    9b70:	aa1403e0 	mov	x0, x20
    9b74:	d2800022 	mov	x2, #0x1                   	// #1
    9b78:	39001fe5 	strb	w5, [sp, #7]
    9b7c:	97ffe6a5 	bl	3610 <buf_put>
    9b80:	17ffffb4 	b	9a50 <fwp_write+0xc10>
    9b84:	d2800203 	mov	x3, #0x10                  	// #16
    9b88:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x70>
    9b8c:	aa0303e1 	mov	x1, x3
    9b90:	911c2084 	add	x4, x4, #0x708
    9b94:	910123f6 	add	x22, sp, #0x48
    9b98:	52800042 	mov	w2, #0x2                   	// #2
    9b9c:	aa1603e0 	mov	x0, x22
    9ba0:	97ffe2f8 	bl	2780 <__snprintf_chk@plt>
    9ba4:	aa1603e0 	mov	x0, x22
    9ba8:	97ffe2be 	bl	26a0 <strlen@plt>
    9bac:	aa1603e1 	mov	x1, x22
    9bb0:	aa0003e2 	mov	x2, x0
    9bb4:	aa1403e0 	mov	x0, x20
    9bb8:	97ffe696 	bl	3610 <buf_put>
    9bbc:	17ffffa5 	b	9a50 <fwp_write+0xc10>
    9bc0:	1e604100 	fmov	d0, d8
    9bc4:	aa1503e0 	mov	x0, x21
    9bc8:	52800221 	mov	w1, #0x11                  	// #17
    9bcc:	97ffe6ed 	bl	3780 <fwp_format_g.constprop.0>
    9bd0:	17fffe43 	b	94dc <fwp_write+0x69c>
    9bd4:	b9401040 	ldr	w0, [x2, #16]
    9bd8:	350003c0 	cbnz	w0, 9c50 <fwp_write+0xe10>
    9bdc:	d0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    9be0:	f947f400 	ldr	x0, [x0, #4072]
    9be4:	f94127e2 	ldr	x2, [sp, #584]
    9be8:	f9400001 	ldr	x1, [x0]
    9bec:	eb010042 	subs	x2, x2, x1
    9bf0:	d2800001 	mov	x1, #0x0                   	// #0
    9bf4:	54ffd721 	b.ne	96d8 <fwp_write+0x898>  // b.any
    9bf8:	f9413bf5 	ldr	x21, [sp, #624]
    9bfc:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9c00:	f9413ff6 	ldr	x22, [sp, #632]
    9c04:	aa1403e0 	mov	x0, x20
    9c08:	f94143f7 	ldr	x23, [sp, #640]
    9c0c:	911d6021 	add	x1, x1, #0x758
    9c10:	f94147f8 	ldr	x24, [sp, #648]
    9c14:	d2800042 	mov	x2, #0x2                   	// #2
    9c18:	17fffd0e 	b	9050 <fwp_write+0x210>
    9c1c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x70>
    9c20:	d2800042 	mov	x2, #0x2                   	// #2
    9c24:	911a4021 	add	x1, x1, #0x690
    9c28:	17fffea3 	b	96b4 <fwp_write+0x874>
    9c2c:	f9400a63 	ldr	x3, [x19, #16]
    9c30:	8b030021 	add	x1, x1, x3
    9c34:	17ffff66 	b	99cc <fwp_write+0xb8c>
    9c38:	f9400a61 	ldr	x1, [x19, #16]
    9c3c:	8b0102a1 	add	x1, x21, x1
    9c40:	17fffdb3 	b	930c <fwp_write+0x4cc>
    9c44:	f9400a63 	ldr	x3, [x19, #16]
    9c48:	8b030021 	add	x1, x1, x3
    9c4c:	17ffff56 	b	99a4 <fwp_write+0xb64>
    9c50:	b9404840 	ldr	w0, [x2, #72]
    9c54:	91001ff5 	add	x21, sp, #0x7
    9c58:	34ffa360 	cbz	w0, 90c4 <fwp_write+0x284>
    9c5c:	52800503 	mov	w3, #0x28                  	// #40
    9c60:	aa1403e0 	mov	x0, x20
    9c64:	aa1503e1 	mov	x1, x21
    9c68:	d2800022 	mov	x2, #0x1                   	// #1
    9c6c:	39001fe3 	strb	w3, [sp, #7]
    9c70:	97ffe668 	bl	3610 <buf_put>
    9c74:	b9401380 	ldr	w0, [x28, #16]
    9c78:	52800038 	mov	w24, #0x1                   	// #1
    9c7c:	7100001f 	cmp	w0, #0x0
    9c80:	54ffa36c 	b.gt	90ec <fwp_write+0x2ac>
    9c84:	17fffd32 	b	914c <fwp_write+0x30c>
    9c88:	f9014bf9 	str	x25, [sp, #656]
    9c8c:	b0000139 	adrp	x25, 2e000 <__FRAME_END__+0x1dba0>
    9c90:	f9014ffa 	str	x26, [sp, #664]
    9c94:	f9400676 	ldr	x22, [x19, #8]
    9c98:	91104333 	add	x19, x25, #0x410
    9c9c:	91002273 	add	x19, x19, #0x8
    9ca0:	937ffed8 	asr	x24, x22, #63
    9ca4:	aa1802c0 	orr	x0, x22, x24
    9ca8:	b5000320 	cbnz	x0, 9d0c <fwp_write+0xecc>
    9cac:	110006b5 	add	w21, w21, #0x1
    9cb0:	710016bf 	cmp	w21, #0x5
    9cb4:	54ffffc1 	b.ne	9cac <fwp_write+0xe6c>  // b.any
    9cb8:	b7f80578 	tbnz	x24, #63, 9d64 <fwp_write+0xf24>
    9cbc:	910023f3 	add	x19, sp, #0x8
    9cc0:	aa1603e2 	mov	x2, x22
    9cc4:	aa1303e0 	mov	x0, x19
    9cc8:	d2800003 	mov	x3, #0x0                   	// #0
    9ccc:	97ffe435 	bl	2da0 <fwp_fmt_u128>
    9cd0:	910123f5 	add	x21, sp, #0x48
    9cd4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x70>
    9cd8:	aa1303e4 	mov	x4, x19
    9cdc:	aa1503e0 	mov	x0, x21
    9ce0:	911d4063 	add	x3, x3, #0x750
    9ce4:	d2804002 	mov	x2, #0x200                 	// #512
    9ce8:	52800041 	mov	w1, #0x2                   	// #2
    9cec:	97ffe271 	bl	26b0 <__sprintf_chk@plt>
    9cf0:	aa1503e0 	mov	x0, x21
    9cf4:	97ffe26b 	bl	26a0 <strlen@plt>
    9cf8:	aa1503e1 	mov	x1, x21
    9cfc:	aa0003e2 	mov	x2, x0
    9d00:	aa1403e0 	mov	x0, x20
    9d04:	97ffe643 	bl	3610 <buf_put>
    9d08:	17fffe47 	b	9624 <fwp_write+0x7e4>
    9d0c:	f9400277 	ldr	x23, [x19]
    9d10:	aa1603e0 	mov	x0, x22
    9d14:	aa1803e1 	mov	x1, x24
    9d18:	aa1703e2 	mov	x2, x23
    9d1c:	937ffefa 	asr	x26, x23, #63
    9d20:	aa1a03e3 	mov	x3, x26
    9d24:	94000fb3 	bl	dbf0 <__modti3>
    9d28:	aa010000 	orr	x0, x0, x1
    9d2c:	b40002c0 	cbz	x0, 9d84 <fwp_write+0xf44>
    9d30:	110006b5 	add	w21, w21, #0x1
    9d34:	91004273 	add	x19, x19, #0x10
    9d38:	710016bf 	cmp	w21, #0x5
    9d3c:	54fffe81 	b.ne	9d0c <fwp_write+0xecc>  // b.any
    9d40:	17ffffde 	b	9cb8 <fwp_write+0xe78>
    9d44:	f9400a60 	ldr	x0, [x19, #16]
    9d48:	8b000021 	add	x1, x1, x0
    9d4c:	17fffd75 	b	9320 <fwp_write+0x4e0>
    9d50:	528c29c0 	mov	w0, #0x614e                	// #24910
    9d54:	910123f5 	add	x21, sp, #0x48
    9d58:	72a009c0 	movk	w0, #0x4e, lsl #16
    9d5c:	b9004be0 	str	w0, [sp, #72]
    9d60:	17fffda2 	b	93e8 <fwp_write+0x5a8>
    9d64:	528005a1 	mov	w1, #0x2d                  	// #45
    9d68:	eb1603e2 	negs	x2, x22
    9d6c:	da1803e3 	ngc	x3, x24
    9d70:	910027e0 	add	x0, sp, #0x9
    9d74:	910023f3 	add	x19, sp, #0x8
    9d78:	390023e1 	strb	w1, [sp, #8]
    9d7c:	97ffe409 	bl	2da0 <fwp_fmt_u128>
    9d80:	17ffffd4 	b	9cd0 <fwp_write+0xe90>
    9d84:	aa1703e2 	mov	x2, x23
    9d88:	aa1a03e3 	mov	x3, x26
    9d8c:	aa1603e0 	mov	x0, x22
    9d90:	aa1803e1 	mov	x1, x24
    9d94:	94000eb7 	bl	d870 <__divti3>
    9d98:	aa0003e2 	mov	x2, x0
    9d9c:	aa0103e3 	mov	x3, x1
    9da0:	b7f80201 	tbnz	x1, #63, 9de0 <fwp_write+0xfa0>
    9da4:	910023f3 	add	x19, sp, #0x8
    9da8:	aa1303e0 	mov	x0, x19
    9dac:	97ffe3fd 	bl	2da0 <fwp_fmt_u128>
    9db0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9db4:	91104339 	add	x25, x25, #0x410
    9db8:	910123f5 	add	x21, sp, #0x48
    9dbc:	aa1303e4 	mov	x4, x19
    9dc0:	aa1503e0 	mov	x0, x21
    9dc4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x70>
    9dc8:	f8616b25 	ldr	x5, [x25, x1]
    9dcc:	911d2063 	add	x3, x3, #0x748
    9dd0:	d2804002 	mov	x2, #0x200                 	// #512
    9dd4:	52800041 	mov	w1, #0x2                   	// #2
    9dd8:	97ffe236 	bl	26b0 <__sprintf_chk@plt>
    9ddc:	17ffffc5 	b	9cf0 <fwp_write+0xeb0>
    9de0:	528005a4 	mov	w4, #0x2d                  	// #45
    9de4:	eb0003e2 	negs	x2, x0
    9de8:	da0103e3 	ngc	x3, x1
    9dec:	910027e0 	add	x0, sp, #0x9
    9df0:	910023f3 	add	x19, sp, #0x8
    9df4:	390023e4 	strb	w4, [sp, #8]
    9df8:	97ffe3ea 	bl	2da0 <fwp_fmt_u128>
    9dfc:	17ffffed 	b	9db0 <fwp_write+0xf70>
    9e00:	f9013bf5 	str	x21, [sp, #624]
    9e04:	f9013ff6 	str	x22, [sp, #632]
    9e08:	f90143f7 	str	x23, [sp, #640]
    9e0c:	f90147f8 	str	x24, [sp, #648]
    9e10:	f9014bf9 	str	x25, [sp, #656]
    9e14:	f9014ffa 	str	x26, [sp, #664]
    9e18:	f90153fb 	str	x27, [sp, #672]
    9e1c:	f90157fc 	str	x28, [sp, #680]
    9e20:	fd015be8 	str	d8, [sp, #688]
    9e24:	fd015fe9 	str	d9, [sp, #696]
    9e28:	97ffe27a 	bl	2810 <__stack_chk_fail@plt>
    9e2c:	d503201f 	nop

0000000000009e30 <fwp_hof0.constprop.0>:
    9e30:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9e34:	d0000122 	adrp	x2, 2f000 <fwp_fn_table+0xb30>
    9e38:	f947f442 	ldr	x2, [x2, #4072]
    9e3c:	910003fd 	mov	x29, sp
    9e40:	a90153f3 	stp	x19, x20, [sp, #16]
    9e44:	a9025bf5 	stp	x21, x22, [sp, #32]
    9e48:	a90363f7 	stp	x23, x24, [sp, #48]
    9e4c:	aa0003f7 	mov	x23, x0
    9e50:	a9046bf9 	stp	x25, x26, [sp, #64]
    9e54:	a90573fb 	stp	x27, x28, [sp, #80]
    9e58:	d10203ff 	sub	sp, sp, #0x80
    9e5c:	f9400040 	ldr	x0, [x2]
    9e60:	f81f83a0 	stur	x0, [x29, #-8]
    9e64:	d2800000 	mov	x0, #0x0                   	// #0
    9e68:	b4003aa1 	cbz	x1, a5bc <fwp_hof0.constprop.0+0x78c>
    9e6c:	f0000120 	adrp	x0, 30000 <__data_start>
    9e70:	9100401c 	add	x28, x0, #0x10
    9e74:	aa1703fa 	mov	x26, x23
    9e78:	f0000120 	adrp	x0, 30000 <__data_start>
    9e7c:	9100a39c 	add	x28, x28, #0x28
    9e80:	d10083b4 	sub	x20, x29, #0x20
    9e84:	91018015 	add	x21, x0, #0x60
    9e88:	aa0103f7 	mov	x23, x1
    9e8c:	90000400 	adrp	x0, 89000 <fwp_root_context+0xba0>
    9e90:	91190001 	add	x1, x0, #0x640
    9e94:	f949d822 	ldr	x2, [x1, #5040]
    9e98:	f949ec20 	ldr	x0, [x1, #5080]
    9e9c:	cb020342 	sub	x2, x26, x2
    9ea0:	eb00405f 	cmp	x2, x0, lsl #16
    9ea4:	540003c2 	b.cs	9f1c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9ea8:	d350fc40 	lsr	x0, x2, #16
    9eac:	f949fc24 	ldr	x4, [x1, #5112]
    9eb0:	8b000800 	add	x0, x0, x0, lsl #2
    9eb4:	d37df001 	lsl	x1, x0, #3
    9eb8:	8b010083 	add	x3, x4, x1
    9ebc:	f9401060 	ldr	x0, [x3, #32]
    9ec0:	b40002e0 	cbz	x0, 9f1c <fwp_hof0.constprop.0+0xec>
    9ec4:	38616881 	ldrb	w1, [x4, x1]
    9ec8:	7100083f 	cmp	w1, #0x2
    9ecc:	54005920 	b.eq	a9f0 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9ed0:	7100043f 	cmp	w1, #0x1
    9ed4:	54000241 	b.ne	9f1c <fwp_hof0.constprop.0+0xec>  // b.any
    9ed8:	92403c41 	and	x1, x2, #0xffff
    9edc:	29430864 	ldp	w4, w2, [x3, #24]
    9ee0:	9b047c21 	mul	x1, x1, x4
    9ee4:	d360fc21 	lsr	x1, x1, #32
    9ee8:	eb02003f 	cmp	x1, x2
    9eec:	54000182 	b.cs	9f1c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9ef0:	8b010000 	add	x0, x0, x1
    9ef4:	39400001 	ldrb	w1, [x0]
    9ef8:	34000121 	cbz	w1, 9f1c <fwp_hof0.constprop.0+0xec>
    9efc:	f0000122 	adrp	x2, 30000 <__data_start>
    9f00:	91018042 	add	x2, x2, #0x60
    9f04:	b9413043 	ldr	w3, [x2, #304]
    9f08:	350057a3 	cbnz	w3, a9fc <fwp_hof0.constprop.0+0xbcc>
    9f0c:	7103f43f 	cmp	w1, #0xfd
    9f10:	54005a28 	b.hi	aa54 <fwp_hof0.constprop.0+0xc24>  // b.pmore
    9f14:	11000421 	add	w1, w1, #0x1
    9f18:	39000001 	strb	w1, [x0]
    9f1c:	aa1a03f8 	mov	x24, x26
    9f20:	aa1c03f9 	mov	x25, x28
    9f24:	d28018f3 	mov	x19, #0xc7                  	// #199
    9f28:	a9396bb7 	stp	x23, x26, [x29, #-112]
    9f2c:	f81a03b3 	stur	x19, [x29, #-96]
    9f30:	f0000120 	adrp	x0, 30000 <__data_start>
    9f34:	91004000 	add	x0, x0, #0x10
    9f38:	f9408ea3 	ldr	x3, [x21, #280]
    9f3c:	9100a006 	add	x6, x0, #0x28
    9f40:	b9402802 	ldr	w2, [x0, #40]
    9f44:	d37be842 	lsl	x2, x2, #5
    9f48:	8b020064 	add	x4, x3, x2
    9f4c:	f9400c81 	ldr	x1, [x4, #24]
    9f50:	f81e03b8 	stur	x24, [x29, #-32]
    9f54:	b4005641 	cbz	x1, aa1c <fwp_hof0.constprop.0+0xbec>
    9f58:	f9400c20 	ldr	x0, [x1, #24]
    9f5c:	b4004920 	cbz	x0, a880 <fwp_hof0.constprop.0+0xa50>
    9f60:	90000400 	adrp	x0, 89000 <fwp_root_context+0xba0>
    9f64:	91190002 	add	x2, x0, #0x640
    9f68:	f949d841 	ldr	x1, [x2, #5040]
    9f6c:	f949ec40 	ldr	x0, [x2, #5080]
    9f70:	cb010321 	sub	x1, x25, x1
    9f74:	eb00403f 	cmp	x1, x0, lsl #16
    9f78:	540003e2 	b.cs	9ff4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9f7c:	d350fc20 	lsr	x0, x1, #16
    9f80:	f949fc45 	ldr	x5, [x2, #5112]
    9f84:	8b000800 	add	x0, x0, x0, lsl #2
    9f88:	d37df002 	lsl	x2, x0, #3
    9f8c:	8b0200a3 	add	x3, x5, x2
    9f90:	f9401060 	ldr	x0, [x3, #32]
    9f94:	b4000300 	cbz	x0, 9ff4 <fwp_hof0.constprop.0+0x1c4>
    9f98:	386268a2 	ldrb	w2, [x5, x2]
    9f9c:	7100085f 	cmp	w2, #0x2
    9fa0:	54004dc0 	b.eq	a958 <fwp_hof0.constprop.0+0xb28>  // b.none
    9fa4:	7100045f 	cmp	w2, #0x1
    9fa8:	54000261 	b.ne	9ff4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9fac:	29430865 	ldp	w5, w2, [x3, #24]
    9fb0:	92403c21 	and	x1, x1, #0xffff
    9fb4:	9b057c21 	mul	x1, x1, x5
    9fb8:	d360fc21 	lsr	x1, x1, #32
    9fbc:	eb02003f 	cmp	x1, x2
    9fc0:	540001a2 	b.cs	9ff4 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9fc4:	8b010000 	add	x0, x0, x1
    9fc8:	39400001 	ldrb	w1, [x0]
    9fcc:	34000141 	cbz	w1, 9ff4 <fwp_hof0.constprop.0+0x1c4>
    9fd0:	b94132a2 	ldr	w2, [x21, #304]
    9fd4:	34000082 	cbz	w2, 9fe4 <fwp_hof0.constprop.0+0x1b4>
    9fd8:	f940aea2 	ldr	x2, [x21, #344]
    9fdc:	91000442 	add	x2, x2, #0x1
    9fe0:	f900aea2 	str	x2, [x21, #344]
    9fe4:	7103f43f 	cmp	w1, #0xfd
    9fe8:	54005128 	b.hi	aa0c <fwp_hof0.constprop.0+0xbdc>  // b.pmore
    9fec:	11000421 	add	w1, w1, #0x1
    9ff0:	39000001 	strb	w1, [x0]
    9ff4:	90000401 	adrp	x1, 89000 <fwp_root_context+0xba0>
    9ff8:	aa1903f8 	mov	x24, x25
    9ffc:	aa1903e0 	mov	x0, x25
    a000:	91190036 	add	x22, x1, #0x640
    a004:	52800037 	mov	w23, #0x1                   	// #1
    a008:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    a00c:	b81cc3b7 	stur	w23, [x29, #-52]
    a010:	f81d03b4 	stur	x20, [x29, #-48]
    a014:	b9400401 	ldr	w1, [x0, #4]
    a018:	b9400099 	ldr	w25, [x4]
    a01c:	b85cc3a0 	ldur	w0, [x29, #-52]
    a020:	4b010339 	sub	w25, w25, w1
    a024:	6b17033f 	cmp	w25, w23
    a028:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    a02c:	6b0000df 	cmp	w6, w0
    a030:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    a034:	b81c83a0 	stur	w0, [x29, #-56]
    a038:	6b0000c2 	subs	w2, w6, w0
    a03c:	54000120 	b.eq	a060 <fwp_hof0.constprop.0+0x230>  // b.none
    a040:	f9400c83 	ldr	x3, [x4, #24]
    a044:	0b000021 	add	w1, w1, w0
    a048:	f85d03a4 	ldur	x4, [x29, #-48]
    a04c:	b81d83a6 	stur	w6, [x29, #-40]
    a050:	f9400863 	ldr	x3, [x3, #16]
    a054:	8b204c80 	add	x0, x4, w0, uxtw #3
    a058:	d63f0060 	blr	x3
    a05c:	b85d83a6 	ldur	w6, [x29, #-40]
    a060:	f9408ea0 	ldr	x0, [x21, #280]
    a064:	aa1803e9 	mov	x9, x24
    a068:	b9400304 	ldr	w4, [x24]
    a06c:	2a0603f4 	mov	w20, w6
    a070:	f85d03bb 	ldur	x27, [x29, #-48]
    a074:	aa1803fa 	mov	x26, x24
    a078:	8b041404 	add	x4, x0, x4, lsl #5
    a07c:	f9400c8a 	ldr	x10, [x4, #24]
    a080:	b400104a 	cbz	x10, a288 <fwp_hof0.constprop.0+0x458>
    a084:	29371bb7 	stp	w23, w6, [x29, #-72]
    a088:	aa0403f7 	mov	x23, x4
    a08c:	b81c03b9 	stur	w25, [x29, #-64]
    a090:	aa1b03f9 	mov	x25, x27
    a094:	14000012 	b	a0dc <fwp_hof0.constprop.0+0x2ac>
    a098:	f9400141 	ldr	x1, [x10]
    a09c:	aa1903e0 	mov	x0, x25
    a0a0:	d63f0020 	blr	x1
    a0a4:	aa0003fb 	mov	x27, x0
    a0a8:	aa1803e0 	mov	x0, x24
    a0ac:	97fff15d 	bl	6620 <fwp_closure_drop>
    a0b0:	6b14027f 	cmp	w19, w20
    a0b4:	54000ca0 	b.eq	a248 <fwp_hof0.constprop.0+0x418>  // b.none
    a0b8:	f9408ea0 	ldr	x0, [x21, #280]
    a0bc:	8b334f39 	add	x25, x25, w19, uxtw #3
    a0c0:	b9400364 	ldr	w4, [x27]
    a0c4:	4b1a0394 	sub	w20, w28, w26
    a0c8:	aa1b03e9 	mov	x9, x27
    a0cc:	8b041417 	add	x23, x0, x4, lsl #5
    a0d0:	f9400eea 	ldr	x10, [x23, #24]
    a0d4:	b4000d2a 	cbz	x10, a278 <fwp_hof0.constprop.0+0x448>
    a0d8:	aa1b03f8 	mov	x24, x27
    a0dc:	b9400521 	ldr	w1, [x9, #4]
    a0e0:	b94002fa 	ldr	w26, [x23]
    a0e4:	0b14003c 	add	w28, w1, w20
    a0e8:	6b1c035f 	cmp	w26, w28
    a0ec:	54002888 	b.hi	a5fc <fwp_hof0.constprop.0+0x7cc>  // b.pmore
    a0f0:	7100003f 	cmp	w1, #0x0
    a0f4:	4b010353 	sub	w19, w26, w1
    a0f8:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    a0fc:	54fffce1 	b.ne	a098 <fwp_hof0.constprop.0+0x268>  // b.any
    a100:	910003e0 	mov	x0, sp
    a104:	7100035f 	cmp	w26, #0x0
    a108:	f81d83a0 	stur	x0, [x29, #-40]
    a10c:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    a110:	d37df000 	lsl	x0, x0, #3
    a114:	91003c00 	add	x0, x0, #0xf
    a118:	92704c05 	and	x5, x0, #0xfffff0000
    a11c:	927c7c00 	and	x0, x0, #0xffffffff0
    a120:	cb2563e5 	sub	x5, sp, x5
    a124:	eb2563ff 	cmp	sp, x5
    a128:	540000a0 	b.eq	a13c <fwp_hof0.constprop.0+0x30c>  // b.none
    a12c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a130:	f90203ff 	str	xzr, [sp, #1024]
    a134:	eb2563ff 	cmp	sp, x5
    a138:	54ffffa1 	b.ne	a12c <fwp_hof0.constprop.0+0x2fc>  // b.any
    a13c:	92403c00 	and	x0, x0, #0xffff
    a140:	cb2063ff 	sub	sp, sp, x0
    a144:	f90003ff 	str	xzr, [sp]
    a148:	f110001f 	cmp	x0, #0x400
    a14c:	54000043 	b.cc	a154 <fwp_hof0.constprop.0+0x324>  // b.lo, b.ul, b.last
    a150:	f90203ff 	str	xzr, [sp, #1024]
    a154:	910043fb 	add	x27, sp, #0x10
    a158:	d37d7c28 	ubfiz	x8, x1, #3, #32
    a15c:	91002127 	add	x7, x9, #0x8
    a160:	d2800000 	mov	x0, #0x0                   	// #0
    a164:	340000c1 	cbz	w1, a17c <fwp_hof0.constprop.0+0x34c>
    a168:	f86068e2 	ldr	x2, [x7, x0]
    a16c:	f8206b62 	str	x2, [x27, x0]
    a170:	91002000 	add	x0, x0, #0x8
    a174:	eb00011f 	cmp	x8, x0
    a178:	54ffff81 	b.ne	a168 <fwp_hof0.constprop.0+0x338>  // b.any
    a17c:	2a1303e8 	mov	w8, w19
    a180:	d2800000 	mov	x0, #0x0                   	// #0
    a184:	340000f3 	cbz	w19, a1a0 <fwp_hof0.constprop.0+0x370>
    a188:	0b000022 	add	w2, w1, w0
    a18c:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    a190:	91000400 	add	x0, x0, #0x1
    a194:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a198:	eb00011f 	cmp	x8, x0
    a19c:	54ffff61 	b.ne	a188 <fwp_hof0.constprop.0+0x358>  // b.any
    a1a0:	f949dac0 	ldr	x0, [x22, #5040]
    a1a4:	f949eec1 	ldr	x1, [x22, #5080]
    a1a8:	cb000300 	sub	x0, x24, x0
    a1ac:	eb01401f 	cmp	x0, x1, lsl #16
    a1b0:	540002e2 	b.cs	a20c <fwp_hof0.constprop.0+0x3dc>  // b.hs, b.nlast
    a1b4:	d350fc01 	lsr	x1, x0, #16
    a1b8:	f949fec8 	ldr	x8, [x22, #5112]
    a1bc:	8b010821 	add	x1, x1, x1, lsl #2
    a1c0:	d37df021 	lsl	x1, x1, #3
    a1c4:	8b010107 	add	x7, x8, x1
    a1c8:	f94010e6 	ldr	x6, [x7, #32]
    a1cc:	b4000206 	cbz	x6, a20c <fwp_hof0.constprop.0+0x3dc>
    a1d0:	38616901 	ldrb	w1, [x8, x1]
    a1d4:	7100083f 	cmp	w1, #0x2
    a1d8:	540004a0 	b.eq	a26c <fwp_hof0.constprop.0+0x43c>  // b.none
    a1dc:	7100043f 	cmp	w1, #0x1
    a1e0:	54000161 	b.ne	a20c <fwp_hof0.constprop.0+0x3dc>  // b.any
    a1e4:	294304e8 	ldp	w8, w1, [x7, #24]
    a1e8:	92403c00 	and	x0, x0, #0xffff
    a1ec:	9b087c00 	mul	x0, x0, x8
    a1f0:	d360fc00 	lsr	x0, x0, #32
    a1f4:	eb01001f 	cmp	x0, x1
    a1f8:	540000a2 	b.cs	a20c <fwp_hof0.constprop.0+0x3dc>  // b.hs, b.nlast
    a1fc:	8b0000c6 	add	x6, x6, x0
    a200:	394000c0 	ldrb	w0, [x6]
    a204:	7100041f 	cmp	w0, #0x1
    a208:	540002e0 	b.eq	a264 <fwp_hof0.constprop.0+0x434>  // b.none
    a20c:	f9400546 	ldr	x6, [x10, #8]
    a210:	aa1803e0 	mov	x0, x24
    a214:	52800021 	mov	w1, #0x1                   	// #1
    a218:	d63f00c0 	blr	x6
    a21c:	f9400ee1 	ldr	x1, [x23, #24]
    a220:	aa1b03e0 	mov	x0, x27
    a224:	f9400021 	ldr	x1, [x1]
    a228:	d63f0020 	blr	x1
    a22c:	aa0003fb 	mov	x27, x0
    a230:	f85d83a0 	ldur	x0, [x29, #-40]
    a234:	9100001f 	mov	sp, x0
    a238:	aa1803e0 	mov	x0, x24
    a23c:	97fff0f9 	bl	6620 <fwp_closure_drop>
    a240:	6b14027f 	cmp	w19, w20
    a244:	54fff3a1 	b.ne	a0b8 <fwp_hof0.constprop.0+0x288>  // b.any
    a248:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a24c:	aa1b03f8 	mov	x24, x27
    a250:	b85c03b9 	ldur	w25, [x29, #-64]
    a254:	6b17033f 	cmp	w25, w23
    a258:	54000443 	b.cc	a2e0 <fwp_hof0.constprop.0+0x4b0>  // b.lo, b.ul, b.last
    a25c:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    a260:	1400003e 	b	a358 <fwp_hof0.constprop.0+0x528>
    a264:	b900053f 	str	wzr, [x9, #4]
    a268:	17ffffed 	b	a21c <fwp_hof0.constprop.0+0x3ec>
    a26c:	72003c1f 	tst	w0, #0xffff
    a270:	54fffce1 	b.ne	a20c <fwp_hof0.constprop.0+0x3dc>  // b.any
    a274:	17ffffe3 	b	a200 <fwp_hof0.constprop.0+0x3d0>
    a278:	aa1b03fa 	mov	x26, x27
    a27c:	aa1903fb 	mov	x27, x25
    a280:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a284:	b85c03b9 	ldur	w25, [x29, #-64]
    a288:	aa1a03e0 	mov	x0, x26
    a28c:	b81d83a6 	stur	w6, [x29, #-40]
    a290:	97ffeef4 	bl	5e60 <fwp_rc_share>
    a294:	b85d83a6 	ldur	w6, [x29, #-40]
    a298:	34000134 	cbz	w20, a2bc <fwp_hof0.constprop.0+0x48c>
    a29c:	aa1b03f8 	mov	x24, x27
    a2a0:	8b344f73 	add	x19, x27, w20, uxtw #3
    a2a4:	2a0603fc 	mov	w28, w6
    a2a8:	f8408700 	ldr	x0, [x24], #8
    a2ac:	97ffeeed 	bl	5e60 <fwp_rc_share>
    a2b0:	eb18027f 	cmp	x19, x24
    a2b4:	54ffffa1 	b.ne	a2a8 <fwp_hof0.constprop.0+0x478>  // b.any
    a2b8:	2a1c03e6 	mov	w6, w28
    a2bc:	aa1b03e2 	mov	x2, x27
    a2c0:	2a1403e1 	mov	w1, w20
    a2c4:	aa1a03e0 	mov	x0, x26
    a2c8:	b81d83a6 	stur	w6, [x29, #-40]
    a2cc:	97ffebd5 	bl	5220 <fwp_apply>
    a2d0:	aa0003f8 	mov	x24, x0
    a2d4:	b85d83a6 	ldur	w6, [x29, #-40]
    a2d8:	6b17033f 	cmp	w25, w23
    a2dc:	54fffc02 	b.cs	a25c <fwp_hof0.constprop.0+0x42c>  // b.hs, b.nlast
    a2e0:	f9408ea1 	ldr	x1, [x21, #280]
    a2e4:	4b0602f7 	sub	w23, w23, w6
    a2e8:	b9400304 	ldr	w4, [x24]
    a2ec:	f85d03a0 	ldur	x0, [x29, #-48]
    a2f0:	8b041424 	add	x4, x1, x4, lsl #5
    a2f4:	b85c83a2 	ldur	w2, [x29, #-56]
    a2f8:	8b264c00 	add	x0, x0, w6, uxtw #3
    a2fc:	f81d03a0 	stur	x0, [x29, #-48]
    a300:	f9400c81 	ldr	x1, [x4, #24]
    a304:	b85cc3a0 	ldur	w0, [x29, #-52]
    a308:	4b020000 	sub	w0, w0, w2
    a30c:	b81cc3a0 	stur	w0, [x29, #-52]
    a310:	aa1803e0 	mov	x0, x24
    a314:	b5ffe801 	cbnz	x1, a014 <fwp_hof0.constprop.0+0x1e4>
    a318:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    a31c:	aa1803e0 	mov	x0, x24
    a320:	97ffeed0 	bl	5e60 <fwp_rc_share>
    a324:	34000117 	cbz	w23, a344 <fwp_hof0.constprop.0+0x514>
    a328:	f85d03ba 	ldur	x26, [x29, #-48]
    a32c:	d2800016 	mov	x22, #0x0                   	// #0
    a330:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    a334:	910006d6 	add	x22, x22, #0x1
    a338:	97ffeeca 	bl	5e60 <fwp_rc_share>
    a33c:	6b1602ff 	cmp	w23, w22
    a340:	54ffff88 	b.hi	a330 <fwp_hof0.constprop.0+0x500>  // b.pmore
    a344:	f85d03a2 	ldur	x2, [x29, #-48]
    a348:	aa1803e0 	mov	x0, x24
    a34c:	2a1703e1 	mov	w1, w23
    a350:	97ffebb4 	bl	5220 <fwp_apply>
    a354:	aa0003f8 	mov	x24, x0
    a358:	f85a03a0 	ldur	x0, [x29, #-96]
    a35c:	f1000400 	subs	x0, x0, #0x1
    a360:	f81a03a0 	stur	x0, [x29, #-96]
    a364:	54ffde61 	b.ne	9f30 <fwp_hof0.constprop.0+0x100>  // b.any
    a368:	90000122 	adrp	x2, 2e000 <__FRAME_END__+0x1dba0>
    a36c:	91104042 	add	x2, x2, #0x410
    a370:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    a374:	aa1803e1 	mov	x1, x24
    a378:	aa1403e0 	mov	x0, x20
    a37c:	aa1803fb 	mov	x27, x24
    a380:	91014042 	add	x2, x2, #0x50
    a384:	52800023 	mov	w3, #0x1                   	// #1
    a388:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    a38c:	aa1903fc 	mov	x28, x25
    a390:	f81f03bf 	stur	xzr, [x29, #-16]
    a394:	97fffaab 	bl	8e40 <fwp_write>
    a398:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    a39c:	f0000000 	adrp	x0, d000 <f0+0x2390>
    a3a0:	913f4000 	add	x0, x0, #0xfd0
    a3a4:	f10002df 	cmp	x22, #0x0
    a3a8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    a3ac:	b1002b1f 	cmn	x24, #0xa
    a3b0:	54003568 	b.hi	aa5c <fwp_hof0.constprop.0+0xc2c>  // b.pmore
    a3b4:	91002700 	add	x0, x24, #0x9
    a3b8:	52800021 	mov	w1, #0x1                   	// #1
    a3bc:	97ffeb35 	bl	5090 <fwp_heap_alloc>
    a3c0:	aa0003f3 	mov	x19, x0
    a3c4:	aa1603e1 	mov	x1, x22
    a3c8:	aa0003f6 	mov	x22, x0
    a3cc:	aa1803e2 	mov	x2, x24
    a3d0:	f80086d8 	str	x24, [x22], #8
    a3d4:	8b180278 	add	x24, x19, x24
    a3d8:	aa1603e0 	mov	x0, x22
    a3dc:	97ffe0a1 	bl	2660 <memcpy@plt>
    a3e0:	3900231f 	strb	wzr, [x24, #8]
    a3e4:	f85e03a0 	ldur	x0, [x29, #-32]
    a3e8:	97ffe13a 	bl	28d0 <free@plt>
    a3ec:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a3f0:	91190003 	add	x3, x0, #0x640
    a3f4:	f949ec64 	ldr	x4, [x3, #5080]
    a3f8:	f949d861 	ldr	x1, [x3, #5040]
    a3fc:	d370bc84 	lsl	x4, x4, #16
    a400:	cb010262 	sub	x2, x19, x1
    a404:	eb04005f 	cmp	x2, x4
    a408:	540003c2 	b.cs	a480 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    a40c:	d350fc40 	lsr	x0, x2, #16
    a410:	f949fc66 	ldr	x6, [x3, #5112]
    a414:	8b000800 	add	x0, x0, x0, lsl #2
    a418:	d37df003 	lsl	x3, x0, #3
    a41c:	8b0300c0 	add	x0, x6, x3
    a420:	f9401018 	ldr	x24, [x0, #32]
    a424:	b40002f8 	cbz	x24, a480 <fwp_hof0.constprop.0+0x650>
    a428:	386368c3 	ldrb	w3, [x6, x3]
    a42c:	7100087f 	cmp	w3, #0x2
    a430:	540031c0 	b.eq	aa68 <fwp_hof0.constprop.0+0xc38>  // b.none
    a434:	7100047f 	cmp	w3, #0x1
    a438:	54000241 	b.ne	a480 <fwp_hof0.constprop.0+0x650>  // b.any
    a43c:	29430003 	ldp	w3, w0, [x0, #24]
    a440:	92403c42 	and	x2, x2, #0xffff
    a444:	9b037c42 	mul	x2, x2, x3
    a448:	d360fc42 	lsr	x2, x2, #32
    a44c:	eb00005f 	cmp	x2, x0
    a450:	54000182 	b.cs	a480 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    a454:	8b020318 	add	x24, x24, x2
    a458:	39400300 	ldrb	w0, [x24]
    a45c:	7103fc1f 	cmp	w0, #0xff
    a460:	54003fa0 	b.eq	ac54 <fwp_hof0.constprop.0+0xe24>  // b.none
    a464:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a468:	91190000 	add	x0, x0, #0x640
    a46c:	52800021 	mov	w1, #0x1                   	// #1
    a470:	39000301 	strb	w1, [x24]
    a474:	f949ec04 	ldr	x4, [x0, #5080]
    a478:	f949d801 	ldr	x1, [x0, #5040]
    a47c:	d370bc84 	lsl	x4, x4, #16
    a480:	cb010361 	sub	x1, x27, x1
    a484:	eb01009f 	cmp	x4, x1
    a488:	540003c9 	b.ls	a500 <fwp_hof0.constprop.0+0x6d0>  // b.plast
    a48c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a490:	91190019 	add	x25, x0, #0x640
    a494:	d350fc22 	lsr	x2, x1, #16
    a498:	f949ff26 	ldr	x6, [x25, #5112]
    a49c:	8b020842 	add	x2, x2, x2, lsl #2
    a4a0:	d37df042 	lsl	x2, x2, #3
    a4a4:	8b0200c0 	add	x0, x6, x2
    a4a8:	f9401018 	ldr	x24, [x0, #32]
    a4ac:	b40002b8 	cbz	x24, a500 <fwp_hof0.constprop.0+0x6d0>
    a4b0:	386268c2 	ldrb	w2, [x6, x2]
    a4b4:	7100085f 	cmp	w2, #0x2
    a4b8:	54003380 	b.eq	ab28 <fwp_hof0.constprop.0+0xcf8>  // b.none
    a4bc:	7100045f 	cmp	w2, #0x1
    a4c0:	54000201 	b.ne	a500 <fwp_hof0.constprop.0+0x6d0>  // b.any
    a4c4:	29430002 	ldp	w2, w0, [x0, #24]
    a4c8:	92403c21 	and	x1, x1, #0xffff
    a4cc:	9b027c21 	mul	x1, x1, x2
    a4d0:	d360fc21 	lsr	x1, x1, #32
    a4d4:	eb00003f 	cmp	x1, x0
    a4d8:	54000142 	b.cs	a500 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    a4dc:	8b010318 	add	x24, x24, x1
    a4e0:	39400300 	ldrb	w0, [x24]
    a4e4:	340000e0 	cbz	w0, a500 <fwp_hof0.constprop.0+0x6d0>
    a4e8:	7100041f 	cmp	w0, #0x1
    a4ec:	54002ca0 	b.eq	aa80 <fwp_hof0.constprop.0+0xc50>  // b.none
    a4f0:	7103fc1f 	cmp	w0, #0xff
    a4f4:	54003280 	b.eq	ab44 <fwp_hof0.constprop.0+0xd14>  // b.none
    a4f8:	51000400 	sub	w0, w0, #0x1
    a4fc:	39000300 	strb	w0, [x24]
    a500:	d0000120 	adrp	x0, 30000 <__data_start>
    a504:	91018003 	add	x3, x0, #0x60
    a508:	f9400262 	ldr	x2, [x19]
    a50c:	aa1603e0 	mov	x0, x22
    a510:	aa0303f6 	mov	x22, x3
    a514:	d2800021 	mov	x1, #0x1                   	// #1
    a518:	f9404863 	ldr	x3, [x3, #144]
    a51c:	97ffe0fd 	bl	2910 <fwrite@plt>
    a520:	f9404ac1 	ldr	x1, [x22, #144]
    a524:	52800140 	mov	w0, #0xa                   	// #10
    a528:	97ffe082 	bl	2730 <fputc@plt>
    a52c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a530:	91190002 	add	x2, x0, #0x640
    a534:	f949d841 	ldr	x1, [x2, #5040]
    a538:	f949ec40 	ldr	x0, [x2, #5080]
    a53c:	cb010261 	sub	x1, x19, x1
    a540:	eb00403f 	cmp	x1, x0, lsl #16
    a544:	54000382 	b.cs	a5b4 <fwp_hof0.constprop.0+0x784>  // b.hs, b.nlast
    a548:	d350fc20 	lsr	x0, x1, #16
    a54c:	f949fc43 	ldr	x3, [x2, #5112]
    a550:	8b000800 	add	x0, x0, x0, lsl #2
    a554:	d37df000 	lsl	x0, x0, #3
    a558:	8b000062 	add	x2, x3, x0
    a55c:	f9401056 	ldr	x22, [x2, #32]
    a560:	b40002b6 	cbz	x22, a5b4 <fwp_hof0.constprop.0+0x784>
    a564:	38606860 	ldrb	w0, [x3, x0]
    a568:	7100081f 	cmp	w0, #0x2
    a56c:	54002840 	b.eq	aa74 <fwp_hof0.constprop.0+0xc44>  // b.none
    a570:	7100041f 	cmp	w0, #0x1
    a574:	54000201 	b.ne	a5b4 <fwp_hof0.constprop.0+0x784>  // b.any
    a578:	29430043 	ldp	w3, w0, [x2, #24]
    a57c:	92403c21 	and	x1, x1, #0xffff
    a580:	9b037c21 	mul	x1, x1, x3
    a584:	d360fc21 	lsr	x1, x1, #32
    a588:	eb00003f 	cmp	x1, x0
    a58c:	54000142 	b.cs	a5b4 <fwp_hof0.constprop.0+0x784>  // b.hs, b.nlast
    a590:	8b0102d6 	add	x22, x22, x1
    a594:	394002c0 	ldrb	w0, [x22]
    a598:	340000e0 	cbz	w0, a5b4 <fwp_hof0.constprop.0+0x784>
    a59c:	7100041f 	cmp	w0, #0x1
    a5a0:	540030c0 	b.eq	abb8 <fwp_hof0.constprop.0+0xd88>  // b.none
    a5a4:	7103fc1f 	cmp	w0, #0xff
    a5a8:	540030e0 	b.eq	abc4 <fwp_hof0.constprop.0+0xd94>  // b.none
    a5ac:	51000400 	sub	w0, w0, #0x1
    a5b0:	390002c0 	strb	w0, [x22]
    a5b4:	f9400af7 	ldr	x23, [x23, #16]
    a5b8:	b5ffc6b7 	cbnz	x23, 9e8c <fwp_hof0.constprop.0+0x5c>
    a5bc:	b0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    a5c0:	f947f400 	ldr	x0, [x0, #4072]
    a5c4:	f85f83a2 	ldur	x2, [x29, #-8]
    a5c8:	f9400001 	ldr	x1, [x0]
    a5cc:	eb010042 	subs	x2, x2, x1
    a5d0:	d2800001 	mov	x1, #0x0                   	// #0
    a5d4:	54002b01 	b.ne	ab34 <fwp_hof0.constprop.0+0xd04>  // b.any
    a5d8:	910003bf 	mov	sp, x29
    a5dc:	d2800000 	mov	x0, #0x0                   	// #0
    a5e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    a5e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a5e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    a5ec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a5f0:	a94573fb 	ldp	x27, x28, [sp, #80]
    a5f4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a5f8:	d65f03c0 	ret
    a5fc:	b94132ab 	ldr	w11, [x21, #304]
    a600:	11000780 	add	w0, w28, #0x1
    a604:	aa1703e4 	mov	x4, x23
    a608:	aa1903fb 	mov	x27, x25
    a60c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a610:	2a0103fa 	mov	w26, w1
    a614:	b85c03b9 	ldur	w25, [x29, #-64]
    a618:	d37df000 	lsl	x0, x0, #3
    a61c:	340000ab 	cbz	w11, a630 <fwp_hof0.constprop.0+0x800>
    a620:	a95386a2 	ldp	x2, x1, [x21, #312]
    a624:	91000442 	add	x2, x2, #0x1
    a628:	8b000021 	add	x1, x1, x0
    a62c:	a91386a2 	stp	x2, x1, [x21, #312]
    a630:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    a634:	9119002a 	add	x10, x1, #0x640
    a638:	f140101f 	cmp	x0, #0x4, lsl #12
    a63c:	b953a541 	ldr	w1, [x10, #5028]
    a640:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a644:	54001a20 	b.eq	a988 <fwp_hof0.constprop.0+0xb58>  // b.none
    a648:	91003c01 	add	x1, x0, #0xf
    a64c:	8b411141 	add	x1, x10, x1, lsr #4
    a650:	397e8021 	ldrb	w1, [x1, #4000]
    a654:	910f002c 	add	x12, x1, #0x3c0
    a658:	8b010422 	add	x2, x1, x1, lsl #1
    a65c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a660:	8b020d4d 	add	x13, x10, x2, lsl #3
    a664:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    a668:	2a0c03e1 	mov	w1, w12
    a66c:	b40017d3 	cbz	x19, a964 <fwp_hof0.constprop.0+0xb34>
    a670:	f940026d 	ldr	x13, [x19]
    a674:	aa2d03ed 	mvn	x13, x13
    a678:	f822794d 	str	x13, [x10, x2, lsl #3]
    a67c:	eb01001f 	cmp	x0, x1
    a680:	540000c2 	b.cs	a698 <fwp_hof0.constprop.0+0x868>  // b.hs, b.nlast
    a684:	d503201f 	nop
    a688:	f8206a7f 	str	xzr, [x19, x0]
    a68c:	91002000 	add	x0, x0, #0x8
    a690:	eb00003f 	cmp	x1, x0
    a694:	54ffffa8 	b.hi	a688 <fwp_hof0.constprop.0+0x858>  // b.pmore
    a698:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a69c:	91190002 	add	x2, x0, #0x640
    a6a0:	f94a1040 	ldr	x0, [x2, #5152]
    a6a4:	ab010000 	adds	x0, x0, x1
    a6a8:	54002c82 	b.cs	ac38 <fwp_hof0.constprop.0+0xe08>  // b.hs, b.nlast
    a6ac:	f94a1441 	ldr	x1, [x2, #5160]
    a6b0:	f90a1040 	str	x0, [x2, #5152]
    a6b4:	eb01001f 	cmp	x0, x1
    a6b8:	54000049 	b.ls	a6c0 <fwp_hof0.constprop.0+0x890>  // b.plast
    a6bc:	f90a1440 	str	x0, [x2, #5160]
    a6c0:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a6c4:	91190000 	add	x0, x0, #0x640
    a6c8:	1e630181 	ucvtf	d1, w12
    a6cc:	fd4a1c00 	ldr	d0, [x0, #5176]
    a6d0:	1e612800 	fadd	d0, d0, d1
    a6d4:	fd0a1c00 	str	d0, [x0, #5176]
    a6d8:	3400012b 	cbz	w11, a6fc <fwp_hof0.constprop.0+0x8cc>
    a6dc:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a6e0:	91190000 	add	x0, x0, #0x640
    a6e4:	6d5486a2 	ldp	d2, d1, [x21, #328]
    a6e8:	fd4a1000 	ldr	d0, [x0, #5152]
    a6ec:	7e61d800 	ucvtf	d0, d0
    a6f0:	1e623800 	fsub	d0, d0, d2
    a6f4:	1e612010 	fcmpe	d0, d1
    a6f8:	5400178c 	b.gt	a9e8 <fwp_hof0.constprop.0+0xbb8>
    a6fc:	b9400120 	ldr	w0, [x9]
    a700:	29007260 	stp	w0, w28, [x19]
    a704:	3400017a 	cbz	w26, a730 <fwp_hof0.constprop.0+0x900>
    a708:	91002121 	add	x1, x9, #0x8
    a70c:	d37d7f42 	ubfiz	x2, x26, #3, #32
    a710:	91002260 	add	x0, x19, #0x8
    a714:	b81bc3a6 	stur	w6, [x29, #-68]
    a718:	f81c03a4 	stur	x4, [x29, #-64]
    a71c:	f81d83a9 	stur	x9, [x29, #-40]
    a720:	97ffdfd8 	bl	2680 <memmove@plt>
    a724:	f85c03a4 	ldur	x4, [x29, #-64]
    a728:	f85d83a9 	ldur	x9, [x29, #-40]
    a72c:	b85bc3a6 	ldur	w6, [x29, #-68]
    a730:	2a1403e8 	mov	w8, w20
    a734:	d2800001 	mov	x1, #0x0                   	// #0
    a738:	34000134 	cbz	w20, a75c <fwp_hof0.constprop.0+0x92c>
    a73c:	d503201f 	nop
    a740:	0b010340 	add	w0, w26, w1
    a744:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a748:	8b000e60 	add	x0, x19, x0, lsl #3
    a74c:	91000421 	add	x1, x1, #0x1
    a750:	f9000402 	str	x2, [x0, #8]
    a754:	eb01011f 	cmp	x8, x1
    a758:	54ffff41 	b.ne	a740 <fwp_hof0.constprop.0+0x910>  // b.any
    a75c:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a760:	91190002 	add	x2, x0, #0x640
    a764:	f949d840 	ldr	x0, [x2, #5040]
    a768:	f949ec41 	ldr	x1, [x2, #5080]
    a76c:	cb000300 	sub	x0, x24, x0
    a770:	eb01401f 	cmp	x0, x1, lsl #16
    a774:	540002e2 	b.cs	a7d0 <fwp_hof0.constprop.0+0x9a0>  // b.hs, b.nlast
    a778:	d350fc01 	lsr	x1, x0, #16
    a77c:	f949fc45 	ldr	x5, [x2, #5112]
    a780:	8b010821 	add	x1, x1, x1, lsl #2
    a784:	d37df021 	lsl	x1, x1, #3
    a788:	8b0100a3 	add	x3, x5, x1
    a78c:	f9401062 	ldr	x2, [x3, #32]
    a790:	b4000202 	cbz	x2, a7d0 <fwp_hof0.constprop.0+0x9a0>
    a794:	386168a1 	ldrb	w1, [x5, x1]
    a798:	7100083f 	cmp	w1, #0x2
    a79c:	540010c0 	b.eq	a9b4 <fwp_hof0.constprop.0+0xb84>  // b.none
    a7a0:	7100043f 	cmp	w1, #0x1
    a7a4:	54000161 	b.ne	a7d0 <fwp_hof0.constprop.0+0x9a0>  // b.any
    a7a8:	29430465 	ldp	w5, w1, [x3, #24]
    a7ac:	92403c00 	and	x0, x0, #0xffff
    a7b0:	9b057c00 	mul	x0, x0, x5
    a7b4:	d360fc00 	lsr	x0, x0, #32
    a7b8:	eb01001f 	cmp	x0, x1
    a7bc:	540000a2 	b.cs	a7d0 <fwp_hof0.constprop.0+0x9a0>  // b.hs, b.nlast
    a7c0:	8b000042 	add	x2, x2, x0
    a7c4:	39400040 	ldrb	w0, [x2]
    a7c8:	7100041f 	cmp	w0, #0x1
    a7cc:	54000c20 	b.eq	a950 <fwp_hof0.constprop.0+0xb20>  // b.none
    a7d0:	f9400c82 	ldr	x2, [x4, #24]
    a7d4:	aa1803e0 	mov	x0, x24
    a7d8:	52800021 	mov	w1, #0x1                   	// #1
    a7dc:	b81d83a6 	stur	w6, [x29, #-40]
    a7e0:	f9400442 	ldr	x2, [x2, #8]
    a7e4:	d63f0040 	blr	x2
    a7e8:	b85d83a6 	ldur	w6, [x29, #-40]
    a7ec:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    a7f0:	91190002 	add	x2, x0, #0x640
    a7f4:	f949d841 	ldr	x1, [x2, #5040]
    a7f8:	f949ec40 	ldr	x0, [x2, #5080]
    a7fc:	cb010261 	sub	x1, x19, x1
    a800:	eb00403f 	cmp	x1, x0, lsl #16
    a804:	54000322 	b.cs	a868 <fwp_hof0.constprop.0+0xa38>  // b.hs, b.nlast
    a808:	d350fc20 	lsr	x0, x1, #16
    a80c:	f949fc43 	ldr	x3, [x2, #5112]
    a810:	8b000800 	add	x0, x0, x0, lsl #2
    a814:	d37df002 	lsl	x2, x0, #3
    a818:	8b020060 	add	x0, x3, x2
    a81c:	f9401014 	ldr	x20, [x0, #32]
    a820:	b4000254 	cbz	x20, a868 <fwp_hof0.constprop.0+0xa38>
    a824:	38626862 	ldrb	w2, [x3, x2]
    a828:	7100085f 	cmp	w2, #0x2
    a82c:	54000ca0 	b.eq	a9c0 <fwp_hof0.constprop.0+0xb90>  // b.none
    a830:	7100045f 	cmp	w2, #0x1
    a834:	540001a1 	b.ne	a868 <fwp_hof0.constprop.0+0xa38>  // b.any
    a838:	29430002 	ldp	w2, w0, [x0, #24]
    a83c:	92403c21 	and	x1, x1, #0xffff
    a840:	9b027c21 	mul	x1, x1, x2
    a844:	d360fc21 	lsr	x1, x1, #32
    a848:	eb00003f 	cmp	x1, x0
    a84c:	540000e2 	b.cs	a868 <fwp_hof0.constprop.0+0xa38>  // b.hs, b.nlast
    a850:	8b010294 	add	x20, x20, x1
    a854:	39400280 	ldrb	w0, [x20]
    a858:	7103fc1f 	cmp	w0, #0xff
    a85c:	54000bc0 	b.eq	a9d4 <fwp_hof0.constprop.0+0xba4>  // b.none
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	39000280 	strb	w0, [x20]
    a868:	aa1803e0 	mov	x0, x24
    a86c:	b81d83a6 	stur	w6, [x29, #-40]
    a870:	97ffef6c 	bl	6620 <fwp_closure_drop>
    a874:	aa1303f8 	mov	x24, x19
    a878:	b85d83a6 	ldur	w6, [x29, #-40]
    a87c:	17fffe97 	b	a2d8 <fwp_hof0.constprop.0+0x4a8>
    a880:	b8626860 	ldr	w0, [x3, x2]
    a884:	b94004c2 	ldr	w2, [x6, #4]
    a888:	4b020003 	sub	w3, w0, w2
    a88c:	7100047f 	cmp	w3, #0x1
    a890:	54ffb681 	b.ne	9f60 <fwp_hof0.constprop.0+0x130>  // b.any
    a894:	910003f6 	mov	x22, sp
    a898:	34000d22 	cbz	w2, aa3c <fwp_hof0.constprop.0+0xc0c>
    a89c:	7100001f 	cmp	w0, #0x0
    a8a0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a8a4:	d2800101 	mov	x1, #0x8                   	// #8
    a8a8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a8ac:	91003ee0 	add	x0, x23, #0xf
    a8b0:	92704c01 	and	x1, x0, #0xfffff0000
    a8b4:	927c7c00 	and	x0, x0, #0xffffffff0
    a8b8:	cb2163e1 	sub	x1, sp, x1
    a8bc:	eb2163ff 	cmp	sp, x1
    a8c0:	540000a0 	b.eq	a8d4 <fwp_hof0.constprop.0+0xaa4>  // b.none
    a8c4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a8c8:	f90203ff 	str	xzr, [sp, #1024]
    a8cc:	eb2163ff 	cmp	sp, x1
    a8d0:	54ffffa1 	b.ne	a8c4 <fwp_hof0.constprop.0+0xa94>  // b.any
    a8d4:	92403c00 	and	x0, x0, #0xffff
    a8d8:	cb2063ff 	sub	sp, sp, x0
    a8dc:	f90003ff 	str	xzr, [sp]
    a8e0:	f110001f 	cmp	x0, #0x400
    a8e4:	54000043 	b.cc	a8ec <fwp_hof0.constprop.0+0xabc>  // b.lo, b.ul, b.last
    a8e8:	f90203ff 	str	xzr, [sp, #1024]
    a8ec:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a8f0:	910043fa 	add	x26, sp, #0x10
    a8f4:	d0000120 	adrp	x0, 30000 <__data_start>
    a8f8:	91004001 	add	x1, x0, #0x10
    a8fc:	aa1b03e2 	mov	x2, x27
    a900:	9100c021 	add	x1, x1, #0x30
    a904:	aa1703e3 	mov	x3, x23
    a908:	aa1a03e0 	mov	x0, x26
    a90c:	f81d83a4 	stur	x4, [x29, #-40]
    a910:	97ffdf94 	bl	2760 <__memcpy_chk@plt>
    a914:	eb1b02ff 	cmp	x23, x27
    a918:	aa1403e1 	mov	x1, x20
    a91c:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a920:	d2800102 	mov	x2, #0x8                   	// #8
    a924:	cb1b0063 	sub	x3, x3, x27
    a928:	8b1b0340 	add	x0, x26, x27
    a92c:	97ffdf8d 	bl	2760 <__memcpy_chk@plt>
    a930:	f85d83a4 	ldur	x4, [x29, #-40]
    a934:	aa1a03e0 	mov	x0, x26
    a938:	f9400c81 	ldr	x1, [x4, #24]
    a93c:	f9400021 	ldr	x1, [x1]
    a940:	d63f0020 	blr	x1
    a944:	aa0003f8 	mov	x24, x0
    a948:	910002df 	mov	sp, x22
    a94c:	17fffe83 	b	a358 <fwp_hof0.constprop.0+0x528>
    a950:	b900053f 	str	wzr, [x9, #4]
    a954:	17ffffa6 	b	a7ec <fwp_hof0.constprop.0+0x9bc>
    a958:	72003c3f 	tst	w1, #0xffff
    a95c:	54ffb4c1 	b.ne	9ff4 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a960:	17fffd9a 	b	9fc8 <fwp_hof0.constprop.0+0x198>
    a964:	f94005b3 	ldr	x19, [x13, #8]
    a968:	b4000113 	cbz	x19, a988 <fwp_hof0.constprop.0+0xb58>
    a96c:	f94009a2 	ldr	x2, [x13, #16]
    a970:	cb130042 	sub	x2, x2, x19
    a974:	eb02003f 	cmp	x1, x2
    a978:	54000088 	b.hi	a988 <fwp_hof0.constprop.0+0xb58>  // b.pmore
    a97c:	8b010262 	add	x2, x19, x1
    a980:	f90005a2 	str	x2, [x13, #8]
    a984:	17ffff3e 	b	a67c <fwp_hof0.constprop.0+0x84c>
    a988:	52800001 	mov	w1, #0x0                   	// #0
    a98c:	b81bc3a6 	stur	w6, [x29, #-68]
    a990:	f81c03a4 	stur	x4, [x29, #-64]
    a994:	f81d83a9 	stur	x9, [x29, #-40]
    a998:	97ffe9be 	bl	5090 <fwp_heap_alloc>
    a99c:	f85c03a4 	ldur	x4, [x29, #-64]
    a9a0:	aa0003f3 	mov	x19, x0
    a9a4:	f85d83a9 	ldur	x9, [x29, #-40]
    a9a8:	b94132ab 	ldr	w11, [x21, #304]
    a9ac:	b85bc3a6 	ldur	w6, [x29, #-68]
    a9b0:	17ffff4a 	b	a6d8 <fwp_hof0.constprop.0+0x8a8>
    a9b4:	72003c1f 	tst	w0, #0xffff
    a9b8:	54fff0c1 	b.ne	a7d0 <fwp_hof0.constprop.0+0x9a0>  // b.any
    a9bc:	17ffff82 	b	a7c4 <fwp_hof0.constprop.0+0x994>
    a9c0:	72003c3f 	tst	w1, #0xffff
    a9c4:	54fff521 	b.ne	a868 <fwp_hof0.constprop.0+0xa38>  // b.any
    a9c8:	39400280 	ldrb	w0, [x20]
    a9cc:	7103fc1f 	cmp	w0, #0xff
    a9d0:	54fff481 	b.ne	a860 <fwp_hof0.constprop.0+0xa30>  // b.any
    a9d4:	aa1403e0 	mov	x0, x20
    a9d8:	b81d83a6 	stur	w6, [x29, #-40]
    a9dc:	97ffe656 	bl	4334 <fwp_rc_forget_slot.part.0>
    a9e0:	b85d83a6 	ldur	w6, [x29, #-40]
    a9e4:	17ffff9f 	b	a860 <fwp_hof0.constprop.0+0xa30>
    a9e8:	fd00aaa0 	str	d0, [x21, #336]
    a9ec:	17ffff44 	b	a6fc <fwp_hof0.constprop.0+0x8cc>
    a9f0:	72003c5f 	tst	w2, #0xffff
    a9f4:	54ffa941 	b.ne	9f1c <fwp_hof0.constprop.0+0xec>  // b.any
    a9f8:	17fffd3f 	b	9ef4 <fwp_hof0.constprop.0+0xc4>
    a9fc:	f940ac43 	ldr	x3, [x2, #344]
    aa00:	91000463 	add	x3, x3, #0x1
    aa04:	f900ac43 	str	x3, [x2, #344]
    aa08:	17fffd41 	b	9f0c <fwp_hof0.constprop.0+0xdc>
    aa0c:	f81d83a4 	stur	x4, [x29, #-40]
    aa10:	97ffe75d 	bl	4784 <fwp_rc_wide_dup>
    aa14:	f85d83a4 	ldur	x4, [x29, #-40]
    aa18:	17fffd77 	b	9ff4 <fwp_hof0.constprop.0+0x1c4>
    aa1c:	aa1903e0 	mov	x0, x25
    aa20:	97ffed10 	bl	5e60 <fwp_rc_share>
    aa24:	aa1803e0 	mov	x0, x24
    aa28:	52800037 	mov	w23, #0x1                   	// #1
    aa2c:	97ffed0d 	bl	5e60 <fwp_rc_share>
    aa30:	aa1903f8 	mov	x24, x25
    aa34:	f81d03b4 	stur	x20, [x29, #-48]
    aa38:	17fffe43 	b	a344 <fwp_hof0.constprop.0+0x514>
    aa3c:	f9400021 	ldr	x1, [x1]
    aa40:	aa1403e0 	mov	x0, x20
    aa44:	d63f0020 	blr	x1
    aa48:	aa0003f8 	mov	x24, x0
    aa4c:	910002df 	mov	sp, x22
    aa50:	17fffe42 	b	a358 <fwp_hof0.constprop.0+0x528>
    aa54:	97ffe74c 	bl	4784 <fwp_rc_wide_dup>
    aa58:	17fffd31 	b	9f1c <fwp_hof0.constprop.0+0xec>
    aa5c:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    aa60:	911da000 	add	x0, x0, #0x768
    aa64:	97ffe614 	bl	42b4 <fwp_trap>
    aa68:	72003c5f 	tst	w2, #0xffff
    aa6c:	54ffd0a1 	b.ne	a480 <fwp_hof0.constprop.0+0x650>  // b.any
    aa70:	17fffe7a 	b	a458 <fwp_hof0.constprop.0+0x628>
    aa74:	72003c3f 	tst	w1, #0xffff
    aa78:	54ffd9e1 	b.ne	a5b4 <fwp_hof0.constprop.0+0x784>  // b.any
    aa7c:	17fffec6 	b	a594 <fwp_hof0.constprop.0+0x764>
    aa80:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    aa84:	91190000 	add	x0, x0, #0x640
    aa88:	f9400b78 	ldr	x24, [x27, #16]
    aa8c:	f949ec03 	ldr	x3, [x0, #5080]
    aa90:	f949d801 	ldr	x1, [x0, #5040]
    aa94:	d370bc63 	lsl	x3, x3, #16
    aa98:	cb010362 	sub	x2, x27, x1
    aa9c:	eb03005f 	cmp	x2, x3
    aaa0:	540003a2 	b.cs	ab14 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    aaa4:	d350fc44 	lsr	x4, x2, #16
    aaa8:	8b040884 	add	x4, x4, x4, lsl #2
    aaac:	d37df084 	lsl	x4, x4, #3
    aab0:	8b0400c0 	add	x0, x6, x4
    aab4:	f9401005 	ldr	x5, [x0, #32]
    aab8:	b40002e5 	cbz	x5, ab14 <fwp_hof0.constprop.0+0xce4>
    aabc:	386468c4 	ldrb	w4, [x6, x4]
    aac0:	7100089f 	cmp	w4, #0x2
    aac4:	540003a0 	b.eq	ab38 <fwp_hof0.constprop.0+0xd08>  // b.none
    aac8:	7100049f 	cmp	w4, #0x1
    aacc:	54000241 	b.ne	ab14 <fwp_hof0.constprop.0+0xce4>  // b.any
    aad0:	29430004 	ldp	w4, w0, [x0, #24]
    aad4:	92403c42 	and	x2, x2, #0xffff
    aad8:	9b047c42 	mul	x2, x2, x4
    aadc:	d360fc42 	lsr	x2, x2, #32
    aae0:	eb00005f 	cmp	x2, x0
    aae4:	54000182 	b.cs	ab14 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    aae8:	8b0200a5 	add	x5, x5, x2
    aaec:	394000a0 	ldrb	w0, [x5]
    aaf0:	7100041f 	cmp	w0, #0x1
    aaf4:	54000101 	b.ne	ab14 <fwp_hof0.constprop.0+0xce4>  // b.any
    aaf8:	aa1b03e0 	mov	x0, x27
    aafc:	97ffe6a9 	bl	45a0 <fwp_mem_free>
    ab00:	f00003e0 	adrp	x0, 89000 <fwp_root_context+0xba0>
    ab04:	91190000 	add	x0, x0, #0x640
    ab08:	f949ec03 	ldr	x3, [x0, #5080]
    ab0c:	f949d801 	ldr	x1, [x0, #5040]
    ab10:	d370bc63 	lsl	x3, x3, #16
    ab14:	cb010301 	sub	x1, x24, x1
    ab18:	eb03003f 	cmp	x1, x3
    ab1c:	54ffcf22 	b.cs	a500 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    ab20:	aa1803fb 	mov	x27, x24
    ab24:	17fffe5c 	b	a494 <fwp_hof0.constprop.0+0x664>
    ab28:	72003c3f 	tst	w1, #0xffff
    ab2c:	54ffcea1 	b.ne	a500 <fwp_hof0.constprop.0+0x6d0>  // b.any
    ab30:	17fffe6c 	b	a4e0 <fwp_hof0.constprop.0+0x6b0>
    ab34:	97ffdf37 	bl	2810 <__stack_chk_fail@plt>
    ab38:	72003c5f 	tst	w2, #0xffff
    ab3c:	54fffec1 	b.ne	ab14 <fwp_hof0.constprop.0+0xce4>  // b.any
    ab40:	17ffffeb 	b	aaec <fwp_hof0.constprop.0+0xcbc>
    ab44:	ca584700 	eor	x0, x24, x24, lsr #17
    ab48:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    ab4c:	91190022 	add	x2, x1, #0x640
    ab50:	ca402400 	eor	x0, x0, x0, lsr #9
    ab54:	92401c00 	and	x0, x0, #0xff
    ab58:	910a2401 	add	x1, x0, #0x289
    ab5c:	8b000c40 	add	x0, x2, x0, lsl #3
    ab60:	8b010c41 	add	x1, x2, x1, lsl #3
    ab64:	f94a2400 	ldr	x0, [x0, #5192]
    ab68:	b50000a0 	cbnz	x0, ab7c <fwp_hof0.constprop.0+0xd4c>
    ab6c:	14000034 	b	ac3c <fwp_hof0.constprop.0+0xe0c>
    ab70:	91004001 	add	x1, x0, #0x10
    ab74:	f9400800 	ldr	x0, [x0, #16]
    ab78:	b4000620 	cbz	x0, ac3c <fwp_hof0.constprop.0+0xe0c>
    ab7c:	f9400002 	ldr	x2, [x0]
    ab80:	eb02031f 	cmp	x24, x2
    ab84:	54ffff61 	b.ne	ab70 <fwp_hof0.constprop.0+0xd40>  // b.any
    ab88:	f9400021 	ldr	x1, [x1]
    ab8c:	f9400420 	ldr	x0, [x1, #8]
    ab90:	d1000400 	sub	x0, x0, #0x1
    ab94:	f9000420 	str	x0, [x1, #8]
    ab98:	f103f81f 	cmp	x0, #0xfe
    ab9c:	54ffcb21 	b.ne	a500 <fwp_hof0.constprop.0+0x6d0>  // b.any
    aba0:	39400300 	ldrb	w0, [x24]
    aba4:	7103fc1f 	cmp	w0, #0xff
    aba8:	54000500 	b.eq	ac48 <fwp_hof0.constprop.0+0xe18>  // b.none
    abac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    abb0:	39000300 	strb	w0, [x24]
    abb4:	17fffe53 	b	a500 <fwp_hof0.constprop.0+0x6d0>
    abb8:	aa1303e0 	mov	x0, x19
    abbc:	97ffe679 	bl	45a0 <fwp_mem_free>
    abc0:	17fffe7d 	b	a5b4 <fwp_hof0.constprop.0+0x784>
    abc4:	ca5646c0 	eor	x0, x22, x22, lsr #17
    abc8:	f00003e1 	adrp	x1, 89000 <fwp_root_context+0xba0>
    abcc:	91190022 	add	x2, x1, #0x640
    abd0:	ca402400 	eor	x0, x0, x0, lsr #9
    abd4:	92401c00 	and	x0, x0, #0xff
    abd8:	910a2401 	add	x1, x0, #0x289
    abdc:	8b000c40 	add	x0, x2, x0, lsl #3
    abe0:	8b010c41 	add	x1, x2, x1, lsl #3
    abe4:	f94a2400 	ldr	x0, [x0, #5192]
    abe8:	b50000a0 	cbnz	x0, abfc <fwp_hof0.constprop.0+0xdcc>
    abec:	14000014 	b	ac3c <fwp_hof0.constprop.0+0xe0c>
    abf0:	91004001 	add	x1, x0, #0x10
    abf4:	f9400800 	ldr	x0, [x0, #16]
    abf8:	b4000220 	cbz	x0, ac3c <fwp_hof0.constprop.0+0xe0c>
    abfc:	f9400002 	ldr	x2, [x0]
    ac00:	eb0202df 	cmp	x22, x2
    ac04:	54ffff61 	b.ne	abf0 <fwp_hof0.constprop.0+0xdc0>  // b.any
    ac08:	f9400021 	ldr	x1, [x1]
    ac0c:	f9400420 	ldr	x0, [x1, #8]
    ac10:	d1000400 	sub	x0, x0, #0x1
    ac14:	f9000420 	str	x0, [x1, #8]
    ac18:	f103f81f 	cmp	x0, #0xfe
    ac1c:	54ffccc1 	b.ne	a5b4 <fwp_hof0.constprop.0+0x784>  // b.any
    ac20:	394002c0 	ldrb	w0, [x22]
    ac24:	7103fc1f 	cmp	w0, #0xff
    ac28:	540001c0 	b.eq	ac60 <fwp_hof0.constprop.0+0xe30>  // b.none
    ac2c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ac30:	390002c0 	strb	w0, [x22]
    ac34:	17fffe60 	b	a5b4 <fwp_hof0.constprop.0+0x784>
    ac38:	97ffe12e 	bl	30f0 <fwp_heap_oom>
    ac3c:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    ac40:	910ba000 	add	x0, x0, #0x2e8
    ac44:	97ffe59c 	bl	42b4 <fwp_trap>
    ac48:	aa1803e0 	mov	x0, x24
    ac4c:	97ffe5ba 	bl	4334 <fwp_rc_forget_slot.part.0>
    ac50:	17ffffd7 	b	abac <fwp_hof0.constprop.0+0xd7c>
    ac54:	aa1803e0 	mov	x0, x24
    ac58:	97ffe5b7 	bl	4334 <fwp_rc_forget_slot.part.0>
    ac5c:	17fffe02 	b	a464 <fwp_hof0.constprop.0+0x634>
    ac60:	aa1603e0 	mov	x0, x22
    ac64:	97ffe5b4 	bl	4334 <fwp_rc_forget_slot.part.0>
    ac68:	17fffff1 	b	ac2c <fwp_hof0.constprop.0+0xdfc>
    ac6c:	d503201f 	nop

000000000000ac70 <f0>:
    ac70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    ac74:	910003fd 	mov	x29, sp
    ac78:	a90153f3 	stp	x19, x20, [sp, #16]
    ac7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    ac80:	a90363f7 	stp	x23, x24, [sp, #48]
    ac84:	a9046bf9 	stp	x25, x26, [sp, #64]
    ac88:	a90573fb 	stp	x27, x28, [sp, #80]
    ac8c:	d121c3ff 	sub	sp, sp, #0x870
    ac90:	f90203ff 	str	xzr, [sp, #1024]
    ac94:	d0000120 	adrp	x0, 30000 <__data_start>
    ac98:	91018003 	add	x3, x0, #0x60
    ac9c:	b0000120 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    aca0:	f947f400 	ldr	x0, [x0, #4072]
    aca4:	f00003f4 	adrp	x20, 89000 <fwp_root_context+0xba0>
    aca8:	f941c865 	ldr	x5, [x3, #912]
    acac:	f9400001 	ldr	x1, [x0]
    acb0:	f90437e1 	str	x1, [sp, #2152]
    acb4:	d2800001 	mov	x1, #0x0                   	// #0
    acb8:	91190299 	add	x25, x20, #0x640
    acbc:	912163f6 	add	x22, sp, #0x858
    acc0:	910063e4 	add	x4, sp, #0x18
    acc4:	9100c3e1 	add	x1, sp, #0x30
    acc8:	90ffffe0 	adrp	x0, 6000 <fwp_rc_free_arr+0x50>
    accc:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    acd0:	910c8000 	add	x0, x0, #0x320
    acd4:	913b4042 	add	x2, x2, #0xed0
    acd8:	d2800013 	mov	x19, #0x0                   	// #0
    acdc:	d280011a 	mov	x26, #0x8                   	// #8
    ace0:	d2800015 	mov	x21, #0x0                   	// #0
    ace4:	52800037 	mov	w23, #0x1                   	// #1
    ace8:	f90007e4 	str	x4, [sp, #8]
    acec:	a9018be5 	stp	x5, x2, [sp, #24]
    acf0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    acf4:	a90403ff 	stp	xzr, x0, [sp, #64]
    acf8:	f901c864 	str	x4, [x3, #912]
    acfc:	d503201f 	nop
    ad00:	f100075b 	subs	x27, x26, #0x1
    ad04:	aa1603e1 	mov	x1, x22
    ad08:	da1f02b8 	sbc	x24, x21, xzr
    ad0c:	52800020 	mov	w0, #0x1                   	// #1
    ad10:	f9001ffb 	str	x27, [sp, #56]
    ad14:	aa1b03fa 	mov	x26, x27
    ad18:	f9042ffb 	str	x27, [sp, #2136]
    ad1c:	aa1803f5 	mov	x21, x24
    ad20:	f90433f3 	str	x19, [sp, #2144]
    ad24:	97ffebf0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ad28:	f949db22 	ldr	x2, [x25, #5040]
    ad2c:	aa0003f3 	mov	x19, x0
    ad30:	f949ef20 	ldr	x0, [x25, #5080]
    ad34:	cb020262 	sub	x2, x19, x2
    ad38:	eb00405f 	cmp	x2, x0, lsl #16
    ad3c:	54000302 	b.cs	ad9c <f0+0x12c>  // b.hs, b.nlast
    ad40:	d350fc40 	lsr	x0, x2, #16
    ad44:	f949ff25 	ldr	x5, [x25, #5112]
    ad48:	8b000800 	add	x0, x0, x0, lsl #2
    ad4c:	d37df001 	lsl	x1, x0, #3
    ad50:	8b0100a0 	add	x0, x5, x1
    ad54:	f940101c 	ldr	x28, [x0, #32]
    ad58:	b400023c 	cbz	x28, ad9c <f0+0x12c>
    ad5c:	386168a1 	ldrb	w1, [x5, x1]
    ad60:	7100083f 	cmp	w1, #0x2
    ad64:	54010e20 	b.eq	cf28 <f0+0x22b8>  // b.none
    ad68:	7100043f 	cmp	w1, #0x1
    ad6c:	54000181 	b.ne	ad9c <f0+0x12c>  // b.any
    ad70:	29430001 	ldp	w1, w0, [x0, #24]
    ad74:	92403c42 	and	x2, x2, #0xffff
    ad78:	9b017c42 	mul	x2, x2, x1
    ad7c:	d360fc42 	lsr	x2, x2, #32
    ad80:	eb00005f 	cmp	x2, x0
    ad84:	540000c2 	b.cs	ad9c <f0+0x12c>  // b.hs, b.nlast
    ad88:	8b02039c 	add	x28, x28, x2
    ad8c:	39400380 	ldrb	w0, [x28]
    ad90:	7103fc1f 	cmp	w0, #0xff
    ad94:	54010c40 	b.eq	cf1c <f0+0x22ac>  // b.none
    ad98:	39000397 	strb	w23, [x28]
    ad9c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    ada0:	aa18037b 	orr	x27, x27, x24
    ada4:	b5fffafb 	cbnz	x27, ad00 <f0+0x90>
    ada8:	d0000120 	adrp	x0, 30000 <__data_start>
    adac:	91018018 	add	x24, x0, #0x60
    adb0:	f94007e1 	ldr	x1, [sp, #8]
    adb4:	f9001bff 	str	xzr, [sp, #48]
    adb8:	f941cb00 	ldr	x0, [x24, #912]
    adbc:	eb01001f 	cmp	x0, x1
    adc0:	54012901 	b.ne	d2e0 <f0+0x2670>  // b.any
    adc4:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x70>
    adc8:	910143e1 	add	x1, sp, #0x50
    adcc:	f9400fe2 	ldr	x2, [sp, #24]
    add0:	f901cb02 	str	x2, [x24, #912]
    add4:	3dc3d400 	ldr	q0, [x0, #3920]
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ade0:	3d8017e0 	str	q0, [sp, #80]
    ade4:	97ffebc0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ade8:	97ffec42 	bl	5ef0 <fwp_rc_fresh>
    adec:	9101a3e1 	add	x1, sp, #0x68
    adf0:	aa0003e2 	mov	x2, x0
    adf4:	52800020 	mov	w0, #0x1                   	// #1
    adf8:	a9068bf5 	stp	x21, x2, [sp, #104]
    adfc:	97ffebba 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ae00:	97ffec3c 	bl	5ef0 <fwp_rc_fresh>
    ae04:	aa0003e2 	mov	x2, x0
    ae08:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x70>
    ae0c:	9101e3e1 	add	x1, sp, #0x78
    ae10:	52800020 	mov	w0, #0x1                   	// #1
    ae14:	f90043e2 	str	x2, [sp, #128]
    ae18:	3dc3d460 	ldr	q0, [x3, #3920]
    ae1c:	fd003fe0 	str	d0, [sp, #120]
    ae20:	97ffebb1 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ae24:	97ffec33 	bl	5ef0 <fwp_rc_fresh>
    ae28:	aa0003e2 	mov	x2, x0
    ae2c:	910223e1 	add	x1, sp, #0x88
    ae30:	52800020 	mov	w0, #0x1                   	// #1
    ae34:	a9088bf5 	stp	x21, x2, [sp, #136]
    ae38:	97ffebab 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ae3c:	91190283 	add	x3, x20, #0x640
    ae40:	aa0003f7 	mov	x23, x0
    ae44:	f949d861 	ldr	x1, [x3, #5040]
    ae48:	f949ec60 	ldr	x0, [x3, #5080]
    ae4c:	cb0102e1 	sub	x1, x23, x1
    ae50:	eb00403f 	cmp	x1, x0, lsl #16
    ae54:	54000322 	b.cs	aeb8 <f0+0x248>  // b.hs, b.nlast
    ae58:	d350fc22 	lsr	x2, x1, #16
    ae5c:	f949fc63 	ldr	x3, [x3, #5112]
    ae60:	8b020842 	add	x2, x2, x2, lsl #2
    ae64:	d37df042 	lsl	x2, x2, #3
    ae68:	8b020060 	add	x0, x3, x2
    ae6c:	f9401015 	ldr	x21, [x0, #32]
    ae70:	b4000255 	cbz	x21, aeb8 <f0+0x248>
    ae74:	38626862 	ldrb	w2, [x3, x2]
    ae78:	7100085f 	cmp	w2, #0x2
    ae7c:	540105c0 	b.eq	cf34 <f0+0x22c4>  // b.none
    ae80:	7100045f 	cmp	w2, #0x1
    ae84:	540001a1 	b.ne	aeb8 <f0+0x248>  // b.any
    ae88:	29430002 	ldp	w2, w0, [x0, #24]
    ae8c:	92403c21 	and	x1, x1, #0xffff
    ae90:	9b027c21 	mul	x1, x1, x2
    ae94:	d360fc21 	lsr	x1, x1, #32
    ae98:	eb00003f 	cmp	x1, x0
    ae9c:	540000e2 	b.cs	aeb8 <f0+0x248>  // b.hs, b.nlast
    aea0:	8b0102b5 	add	x21, x21, x1
    aea4:	394002a0 	ldrb	w0, [x21]
    aea8:	7103fc1f 	cmp	w0, #0xff
    aeac:	54011340 	b.eq	d114 <f0+0x24a4>  // b.none
    aeb0:	52800020 	mov	w0, #0x1                   	// #1
    aeb4:	390002a0 	strb	w0, [x21]
    aeb8:	910263e1 	add	x1, sp, #0x98
    aebc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aec0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aec4:	52800020 	mov	w0, #0x1                   	// #1
    aec8:	a909dff5 	stp	x21, x23, [sp, #152]
    aecc:	97ffeb86 	bl	5ce4 <fwp_data.part.0.constprop.0>
    aed0:	97ffec08 	bl	5ef0 <fwp_rc_fresh>
    aed4:	aa0003e2 	mov	x2, x0
    aed8:	9102a3e1 	add	x1, sp, #0xa8
    aedc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aee0:	52800020 	mov	w0, #0x1                   	// #1
    aee4:	a90a8bf7 	stp	x23, x2, [sp, #168]
    aee8:	97ffeb7f 	bl	5ce4 <fwp_data.part.0.constprop.0>
    aeec:	97ffec01 	bl	5ef0 <fwp_rc_fresh>
    aef0:	aa0003e2 	mov	x2, x0
    aef4:	9102e3e1 	add	x1, sp, #0xb8
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	a90b8bf5 	stp	x21, x2, [sp, #184]
    af00:	97ffeb79 	bl	5ce4 <fwp_data.part.0.constprop.0>
    af04:	97ffebfb 	bl	5ef0 <fwp_rc_fresh>
    af08:	aa0003e2 	mov	x2, x0
    af0c:	910323e1 	add	x1, sp, #0xc8
    af10:	52800020 	mov	w0, #0x1                   	// #1
    af14:	a90c8bf7 	stp	x23, x2, [sp, #200]
    af18:	97ffeb73 	bl	5ce4 <fwp_data.part.0.constprop.0>
    af1c:	97ffebf5 	bl	5ef0 <fwp_rc_fresh>
    af20:	aa0003e2 	mov	x2, x0
    af24:	910363e1 	add	x1, sp, #0xd8
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	a90d8bf5 	stp	x21, x2, [sp, #216]
    af30:	97ffeb6d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    af34:	97ffebef 	bl	5ef0 <fwp_rc_fresh>
    af38:	aa0003e2 	mov	x2, x0
    af3c:	9103a3e1 	add	x1, sp, #0xe8
    af40:	52800020 	mov	w0, #0x1                   	// #1
    af44:	a90e8bf7 	stp	x23, x2, [sp, #232]
    af48:	97ffeb67 	bl	5ce4 <fwp_data.part.0.constprop.0>
    af4c:	97ffebe9 	bl	5ef0 <fwp_rc_fresh>
    af50:	aa0003e2 	mov	x2, x0
    af54:	9103e3e1 	add	x1, sp, #0xf8
    af58:	52800020 	mov	w0, #0x1                   	// #1
    af5c:	a90f8bf5 	stp	x21, x2, [sp, #248]
    af60:	97ffeb61 	bl	5ce4 <fwp_data.part.0.constprop.0>
    af64:	91190283 	add	x3, x20, #0x640
    af68:	aa0003f5 	mov	x21, x0
    af6c:	f949d861 	ldr	x1, [x3, #5040]
    af70:	f949ec60 	ldr	x0, [x3, #5080]
    af74:	cb0102a1 	sub	x1, x21, x1
    af78:	eb00403f 	cmp	x1, x0, lsl #16
    af7c:	54000322 	b.cs	afe0 <f0+0x370>  // b.hs, b.nlast
    af80:	d350fc22 	lsr	x2, x1, #16
    af84:	f949fc63 	ldr	x3, [x3, #5112]
    af88:	8b020842 	add	x2, x2, x2, lsl #2
    af8c:	d37df042 	lsl	x2, x2, #3
    af90:	8b020060 	add	x0, x3, x2
    af94:	f9401017 	ldr	x23, [x0, #32]
    af98:	b4000257 	cbz	x23, afe0 <f0+0x370>
    af9c:	38626862 	ldrb	w2, [x3, x2]
    afa0:	7100085f 	cmp	w2, #0x2
    afa4:	5400fd40 	b.eq	cf4c <f0+0x22dc>  // b.none
    afa8:	7100045f 	cmp	w2, #0x1
    afac:	540001a1 	b.ne	afe0 <f0+0x370>  // b.any
    afb0:	29430002 	ldp	w2, w0, [x0, #24]
    afb4:	92403c21 	and	x1, x1, #0xffff
    afb8:	9b027c21 	mul	x1, x1, x2
    afbc:	d360fc21 	lsr	x1, x1, #32
    afc0:	eb00003f 	cmp	x1, x0
    afc4:	540000e2 	b.cs	afe0 <f0+0x370>  // b.hs, b.nlast
    afc8:	8b0102f7 	add	x23, x23, x1
    afcc:	394002e0 	ldrb	w0, [x23]
    afd0:	7103fc1f 	cmp	w0, #0xff
    afd4:	54010a60 	b.eq	d120 <f0+0x24b0>  // b.none
    afd8:	52800020 	mov	w0, #0x1                   	// #1
    afdc:	390002e0 	strb	w0, [x23]
    afe0:	910423e1 	add	x1, sp, #0x108
    afe4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	a910d7f7 	stp	x23, x21, [sp, #264]
    aff0:	97ffeb3d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    aff4:	97ffebbf 	bl	5ef0 <fwp_rc_fresh>
    aff8:	aa0003e2 	mov	x2, x0
    affc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b000:	910463e1 	add	x1, sp, #0x118
    b004:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	a9118be3 	stp	x3, x2, [sp, #280]
    b010:	97ffeb35 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b014:	97ffebb7 	bl	5ef0 <fwp_rc_fresh>
    b018:	aa0003e2 	mov	x2, x0
    b01c:	9104a3e1 	add	x1, sp, #0x128
    b020:	52800020 	mov	w0, #0x1                   	// #1
    b024:	a9128bf7 	stp	x23, x2, [sp, #296]
    b028:	97ffeb2f 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b02c:	91190283 	add	x3, x20, #0x640
    b030:	aa0003f5 	mov	x21, x0
    b034:	f949d861 	ldr	x1, [x3, #5040]
    b038:	f949ec60 	ldr	x0, [x3, #5080]
    b03c:	cb0102a1 	sub	x1, x21, x1
    b040:	eb00403f 	cmp	x1, x0, lsl #16
    b044:	54000322 	b.cs	b0a8 <f0+0x438>  // b.hs, b.nlast
    b048:	d350fc22 	lsr	x2, x1, #16
    b04c:	f949fc63 	ldr	x3, [x3, #5112]
    b050:	8b020842 	add	x2, x2, x2, lsl #2
    b054:	d37df042 	lsl	x2, x2, #3
    b058:	8b020060 	add	x0, x3, x2
    b05c:	f9401017 	ldr	x23, [x0, #32]
    b060:	b4000257 	cbz	x23, b0a8 <f0+0x438>
    b064:	38626862 	ldrb	w2, [x3, x2]
    b068:	7100085f 	cmp	w2, #0x2
    b06c:	5400f6a0 	b.eq	cf40 <f0+0x22d0>  // b.none
    b070:	7100045f 	cmp	w2, #0x1
    b074:	540001a1 	b.ne	b0a8 <f0+0x438>  // b.any
    b078:	29430002 	ldp	w2, w0, [x0, #24]
    b07c:	92403c21 	and	x1, x1, #0xffff
    b080:	9b027c21 	mul	x1, x1, x2
    b084:	d360fc21 	lsr	x1, x1, #32
    b088:	eb00003f 	cmp	x1, x0
    b08c:	540000e2 	b.cs	b0a8 <f0+0x438>  // b.hs, b.nlast
    b090:	8b0102f7 	add	x23, x23, x1
    b094:	394002e0 	ldrb	w0, [x23]
    b098:	7103fc1f 	cmp	w0, #0xff
    b09c:	54010480 	b.eq	d12c <f0+0x24bc>  // b.none
    b0a0:	52800020 	mov	w0, #0x1                   	// #1
    b0a4:	390002e0 	strb	w0, [x23]
    b0a8:	9104e3e1 	add	x1, sp, #0x138
    b0ac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b0b0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	a913d7f7 	stp	x23, x21, [sp, #312]
    b0bc:	97ffeb0a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b0c0:	97ffeb8c 	bl	5ef0 <fwp_rc_fresh>
    b0c4:	aa0003e2 	mov	x2, x0
    b0c8:	910523e1 	add	x1, sp, #0x148
    b0cc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0d0:	52800020 	mov	w0, #0x1                   	// #1
    b0d4:	a9148bf5 	stp	x21, x2, [sp, #328]
    b0d8:	97ffeb03 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b0dc:	97ffeb85 	bl	5ef0 <fwp_rc_fresh>
    b0e0:	aa0003e2 	mov	x2, x0
    b0e4:	910563e1 	add	x1, sp, #0x158
    b0e8:	52800020 	mov	w0, #0x1                   	// #1
    b0ec:	a9158bf7 	stp	x23, x2, [sp, #344]
    b0f0:	97ffeafd 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b0f4:	97ffeb7f 	bl	5ef0 <fwp_rc_fresh>
    b0f8:	aa0003e2 	mov	x2, x0
    b0fc:	9105a3e1 	add	x1, sp, #0x168
    b100:	52800020 	mov	w0, #0x1                   	// #1
    b104:	a9168bf5 	stp	x21, x2, [sp, #360]
    b108:	97ffeaf7 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b10c:	91190283 	add	x3, x20, #0x640
    b110:	aa0003f5 	mov	x21, x0
    b114:	f949d861 	ldr	x1, [x3, #5040]
    b118:	f949ec60 	ldr	x0, [x3, #5080]
    b11c:	cb0102a1 	sub	x1, x21, x1
    b120:	eb00403f 	cmp	x1, x0, lsl #16
    b124:	54000322 	b.cs	b188 <f0+0x518>  // b.hs, b.nlast
    b128:	d350fc22 	lsr	x2, x1, #16
    b12c:	f949fc63 	ldr	x3, [x3, #5112]
    b130:	8b020842 	add	x2, x2, x2, lsl #2
    b134:	d37df042 	lsl	x2, x2, #3
    b138:	8b020060 	add	x0, x3, x2
    b13c:	f9401017 	ldr	x23, [x0, #32]
    b140:	b4000257 	cbz	x23, b188 <f0+0x518>
    b144:	38626862 	ldrb	w2, [x3, x2]
    b148:	7100085f 	cmp	w2, #0x2
    b14c:	5400f0c0 	b.eq	cf64 <f0+0x22f4>  // b.none
    b150:	7100045f 	cmp	w2, #0x1
    b154:	540001a1 	b.ne	b188 <f0+0x518>  // b.any
    b158:	29430002 	ldp	w2, w0, [x0, #24]
    b15c:	92403c21 	and	x1, x1, #0xffff
    b160:	9b027c21 	mul	x1, x1, x2
    b164:	d360fc21 	lsr	x1, x1, #32
    b168:	eb00003f 	cmp	x1, x0
    b16c:	540000e2 	b.cs	b188 <f0+0x518>  // b.hs, b.nlast
    b170:	8b0102f7 	add	x23, x23, x1
    b174:	394002e0 	ldrb	w0, [x23]
    b178:	7103fc1f 	cmp	w0, #0xff
    b17c:	5400fde0 	b.eq	d138 <f0+0x24c8>  // b.none
    b180:	52800020 	mov	w0, #0x1                   	// #1
    b184:	390002e0 	strb	w0, [x23]
    b188:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b18c:	9105e3e1 	add	x1, sp, #0x178
    b190:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b194:	52800020 	mov	w0, #0x1                   	// #1
    b198:	a917d7e2 	stp	x2, x21, [sp, #376]
    b19c:	97ffead2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b1a0:	91190283 	add	x3, x20, #0x640
    b1a4:	aa0003f5 	mov	x21, x0
    b1a8:	f949d861 	ldr	x1, [x3, #5040]
    b1ac:	f949ec60 	ldr	x0, [x3, #5080]
    b1b0:	cb0102a1 	sub	x1, x21, x1
    b1b4:	eb00403f 	cmp	x1, x0, lsl #16
    b1b8:	54000322 	b.cs	b21c <f0+0x5ac>  // b.hs, b.nlast
    b1bc:	d350fc22 	lsr	x2, x1, #16
    b1c0:	f949fc63 	ldr	x3, [x3, #5112]
    b1c4:	8b020842 	add	x2, x2, x2, lsl #2
    b1c8:	d37df042 	lsl	x2, x2, #3
    b1cc:	8b020060 	add	x0, x3, x2
    b1d0:	f9401017 	ldr	x23, [x0, #32]
    b1d4:	b4000257 	cbz	x23, b21c <f0+0x5ac>
    b1d8:	38626862 	ldrb	w2, [x3, x2]
    b1dc:	7100085f 	cmp	w2, #0x2
    b1e0:	5400ebc0 	b.eq	cf58 <f0+0x22e8>  // b.none
    b1e4:	7100045f 	cmp	w2, #0x1
    b1e8:	540001a1 	b.ne	b21c <f0+0x5ac>  // b.any
    b1ec:	29430002 	ldp	w2, w0, [x0, #24]
    b1f0:	92403c21 	and	x1, x1, #0xffff
    b1f4:	9b027c21 	mul	x1, x1, x2
    b1f8:	d360fc21 	lsr	x1, x1, #32
    b1fc:	eb00003f 	cmp	x1, x0
    b200:	540000e2 	b.cs	b21c <f0+0x5ac>  // b.hs, b.nlast
    b204:	8b0102f7 	add	x23, x23, x1
    b208:	394002e0 	ldrb	w0, [x23]
    b20c:	7103fc1f 	cmp	w0, #0xff
    b210:	5400f9a0 	b.eq	d144 <f0+0x24d4>  // b.none
    b214:	52800020 	mov	w0, #0x1                   	// #1
    b218:	390002e0 	strb	w0, [x23]
    b21c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b220:	910623e1 	add	x1, sp, #0x188
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	a918d7e2 	stp	x2, x21, [sp, #392]
    b22c:	97ffeaae 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b230:	91190283 	add	x3, x20, #0x640
    b234:	aa0003f5 	mov	x21, x0
    b238:	f949d861 	ldr	x1, [x3, #5040]
    b23c:	f949ec60 	ldr	x0, [x3, #5080]
    b240:	cb0102a1 	sub	x1, x21, x1
    b244:	eb00403f 	cmp	x1, x0, lsl #16
    b248:	54000322 	b.cs	b2ac <f0+0x63c>  // b.hs, b.nlast
    b24c:	d350fc22 	lsr	x2, x1, #16
    b250:	f949fc63 	ldr	x3, [x3, #5112]
    b254:	8b020842 	add	x2, x2, x2, lsl #2
    b258:	d37df042 	lsl	x2, x2, #3
    b25c:	8b020060 	add	x0, x3, x2
    b260:	f9401017 	ldr	x23, [x0, #32]
    b264:	b4000257 	cbz	x23, b2ac <f0+0x63c>
    b268:	38626862 	ldrb	w2, [x3, x2]
    b26c:	7100085f 	cmp	w2, #0x2
    b270:	5400e860 	b.eq	cf7c <f0+0x230c>  // b.none
    b274:	7100045f 	cmp	w2, #0x1
    b278:	540001a1 	b.ne	b2ac <f0+0x63c>  // b.any
    b27c:	29430002 	ldp	w2, w0, [x0, #24]
    b280:	92403c21 	and	x1, x1, #0xffff
    b284:	9b027c21 	mul	x1, x1, x2
    b288:	d360fc21 	lsr	x1, x1, #32
    b28c:	eb00003f 	cmp	x1, x0
    b290:	540000e2 	b.cs	b2ac <f0+0x63c>  // b.hs, b.nlast
    b294:	8b0102f7 	add	x23, x23, x1
    b298:	394002e0 	ldrb	w0, [x23]
    b29c:	7103fc1f 	cmp	w0, #0xff
    b2a0:	5400f580 	b.eq	d150 <f0+0x24e0>  // b.none
    b2a4:	52800020 	mov	w0, #0x1                   	// #1
    b2a8:	390002e0 	strb	w0, [x23]
    b2ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2b0:	910663e1 	add	x1, sp, #0x198
    b2b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2b8:	52800020 	mov	w0, #0x1                   	// #1
    b2bc:	a919d7e2 	stp	x2, x21, [sp, #408]
    b2c0:	97ffea89 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b2c4:	97ffeb0b 	bl	5ef0 <fwp_rc_fresh>
    b2c8:	aa0003e2 	mov	x2, x0
    b2cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b2d0:	9106a3e1 	add	x1, sp, #0x1a8
    b2d4:	52800020 	mov	w0, #0x1                   	// #1
    b2d8:	a91a8be3 	stp	x3, x2, [sp, #424]
    b2dc:	97ffea82 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b2e0:	91190283 	add	x3, x20, #0x640
    b2e4:	aa0003f5 	mov	x21, x0
    b2e8:	f949d861 	ldr	x1, [x3, #5040]
    b2ec:	f949ec60 	ldr	x0, [x3, #5080]
    b2f0:	cb0102a1 	sub	x1, x21, x1
    b2f4:	eb00403f 	cmp	x1, x0, lsl #16
    b2f8:	54000322 	b.cs	b35c <f0+0x6ec>  // b.hs, b.nlast
    b2fc:	d350fc22 	lsr	x2, x1, #16
    b300:	f949fc63 	ldr	x3, [x3, #5112]
    b304:	8b020842 	add	x2, x2, x2, lsl #2
    b308:	d37df042 	lsl	x2, x2, #3
    b30c:	8b020060 	add	x0, x3, x2
    b310:	f9401017 	ldr	x23, [x0, #32]
    b314:	b4000257 	cbz	x23, b35c <f0+0x6ec>
    b318:	38626862 	ldrb	w2, [x3, x2]
    b31c:	7100085f 	cmp	w2, #0x2
    b320:	5400e280 	b.eq	cf70 <f0+0x2300>  // b.none
    b324:	7100045f 	cmp	w2, #0x1
    b328:	540001a1 	b.ne	b35c <f0+0x6ec>  // b.any
    b32c:	29430002 	ldp	w2, w0, [x0, #24]
    b330:	92403c21 	and	x1, x1, #0xffff
    b334:	9b027c21 	mul	x1, x1, x2
    b338:	d360fc21 	lsr	x1, x1, #32
    b33c:	eb00003f 	cmp	x1, x0
    b340:	540000e2 	b.cs	b35c <f0+0x6ec>  // b.hs, b.nlast
    b344:	8b0102f7 	add	x23, x23, x1
    b348:	394002e0 	ldrb	w0, [x23]
    b34c:	7103fc1f 	cmp	w0, #0xff
    b350:	5400f060 	b.eq	d15c <f0+0x24ec>  // b.none
    b354:	52800020 	mov	w0, #0x1                   	// #1
    b358:	390002e0 	strb	w0, [x23]
    b35c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b360:	9106e3e1 	add	x1, sp, #0x1b8
    b364:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b368:	52800020 	mov	w0, #0x1                   	// #1
    b36c:	a91bd7e2 	stp	x2, x21, [sp, #440]
    b370:	97ffea5d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b374:	97ffeadf 	bl	5ef0 <fwp_rc_fresh>
    b378:	aa0003e2 	mov	x2, x0
    b37c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b380:	910723e1 	add	x1, sp, #0x1c8
    b384:	52800020 	mov	w0, #0x1                   	// #1
    b388:	a91c8be3 	stp	x3, x2, [sp, #456]
    b38c:	97ffea56 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b390:	91190283 	add	x3, x20, #0x640
    b394:	aa0003f5 	mov	x21, x0
    b398:	f949d861 	ldr	x1, [x3, #5040]
    b39c:	f949ec60 	ldr	x0, [x3, #5080]
    b3a0:	cb0102a1 	sub	x1, x21, x1
    b3a4:	eb00403f 	cmp	x1, x0, lsl #16
    b3a8:	54000322 	b.cs	b40c <f0+0x79c>  // b.hs, b.nlast
    b3ac:	d350fc22 	lsr	x2, x1, #16
    b3b0:	f949fc63 	ldr	x3, [x3, #5112]
    b3b4:	8b020842 	add	x2, x2, x2, lsl #2
    b3b8:	d37df042 	lsl	x2, x2, #3
    b3bc:	8b020060 	add	x0, x3, x2
    b3c0:	f9401017 	ldr	x23, [x0, #32]
    b3c4:	b4000257 	cbz	x23, b40c <f0+0x79c>
    b3c8:	38626862 	ldrb	w2, [x3, x2]
    b3cc:	7100085f 	cmp	w2, #0x2
    b3d0:	5400e420 	b.eq	d054 <f0+0x23e4>  // b.none
    b3d4:	7100045f 	cmp	w2, #0x1
    b3d8:	540001a1 	b.ne	b40c <f0+0x79c>  // b.any
    b3dc:	29430002 	ldp	w2, w0, [x0, #24]
    b3e0:	92403c21 	and	x1, x1, #0xffff
    b3e4:	9b027c21 	mul	x1, x1, x2
    b3e8:	d360fc21 	lsr	x1, x1, #32
    b3ec:	eb00003f 	cmp	x1, x0
    b3f0:	540000e2 	b.cs	b40c <f0+0x79c>  // b.hs, b.nlast
    b3f4:	8b0102f7 	add	x23, x23, x1
    b3f8:	394002e0 	ldrb	w0, [x23]
    b3fc:	7103fc1f 	cmp	w0, #0xff
    b400:	5400eb40 	b.eq	d168 <f0+0x24f8>  // b.none
    b404:	52800020 	mov	w0, #0x1                   	// #1
    b408:	390002e0 	strb	w0, [x23]
    b40c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b410:	910763e1 	add	x1, sp, #0x1d8
    b414:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b418:	52800020 	mov	w0, #0x1                   	// #1
    b41c:	a91dd7e2 	stp	x2, x21, [sp, #472]
    b420:	97ffea31 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b424:	97ffeab3 	bl	5ef0 <fwp_rc_fresh>
    b428:	aa0003e2 	mov	x2, x0
    b42c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b430:	9107a3e1 	add	x1, sp, #0x1e8
    b434:	52800020 	mov	w0, #0x1                   	// #1
    b438:	a91e8be3 	stp	x3, x2, [sp, #488]
    b43c:	97ffea2a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b440:	91190283 	add	x3, x20, #0x640
    b444:	aa0003f5 	mov	x21, x0
    b448:	f949d861 	ldr	x1, [x3, #5040]
    b44c:	f949ec60 	ldr	x0, [x3, #5080]
    b450:	cb0102a1 	sub	x1, x21, x1
    b454:	eb00403f 	cmp	x1, x0, lsl #16
    b458:	54000322 	b.cs	b4bc <f0+0x84c>  // b.hs, b.nlast
    b45c:	d350fc22 	lsr	x2, x1, #16
    b460:	f949fc63 	ldr	x3, [x3, #5112]
    b464:	8b020842 	add	x2, x2, x2, lsl #2
    b468:	d37df042 	lsl	x2, x2, #3
    b46c:	8b020060 	add	x0, x3, x2
    b470:	f9401017 	ldr	x23, [x0, #32]
    b474:	b4000257 	cbz	x23, b4bc <f0+0x84c>
    b478:	38626862 	ldrb	w2, [x3, x2]
    b47c:	7100085f 	cmp	w2, #0x2
    b480:	5400de40 	b.eq	d048 <f0+0x23d8>  // b.none
    b484:	7100045f 	cmp	w2, #0x1
    b488:	540001a1 	b.ne	b4bc <f0+0x84c>  // b.any
    b48c:	29430002 	ldp	w2, w0, [x0, #24]
    b490:	92403c21 	and	x1, x1, #0xffff
    b494:	9b027c21 	mul	x1, x1, x2
    b498:	d360fc21 	lsr	x1, x1, #32
    b49c:	eb00003f 	cmp	x1, x0
    b4a0:	540000e2 	b.cs	b4bc <f0+0x84c>  // b.hs, b.nlast
    b4a4:	8b0102f7 	add	x23, x23, x1
    b4a8:	394002e0 	ldrb	w0, [x23]
    b4ac:	7103fc1f 	cmp	w0, #0xff
    b4b0:	5400e620 	b.eq	d174 <f0+0x2504>  // b.none
    b4b4:	52800020 	mov	w0, #0x1                   	// #1
    b4b8:	390002e0 	strb	w0, [x23]
    b4bc:	9107e3e1 	add	x1, sp, #0x1f8
    b4c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4c8:	52800020 	mov	w0, #0x1                   	// #1
    b4cc:	a91fd7f7 	stp	x23, x21, [sp, #504]
    b4d0:	97ffea05 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b4d4:	97ffea87 	bl	5ef0 <fwp_rc_fresh>
    b4d8:	aa0003e2 	mov	x2, x0
    b4dc:	910823e1 	add	x1, sp, #0x208
    b4e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b4e4:	52800020 	mov	w0, #0x1                   	// #1
    b4e8:	f90107f5 	str	x21, [sp, #520]
    b4ec:	f9010be2 	str	x2, [sp, #528]
    b4f0:	97ffe9fd 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b4f4:	97ffea7f 	bl	5ef0 <fwp_rc_fresh>
    b4f8:	aa0003e2 	mov	x2, x0
    b4fc:	910863e1 	add	x1, sp, #0x218
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	f9010ff7 	str	x23, [sp, #536]
    b508:	f90113e2 	str	x2, [sp, #544]
    b50c:	97ffe9f6 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b510:	97ffea78 	bl	5ef0 <fwp_rc_fresh>
    b514:	aa0003e2 	mov	x2, x0
    b518:	9108a3e1 	add	x1, sp, #0x228
    b51c:	52800020 	mov	w0, #0x1                   	// #1
    b520:	f90117f5 	str	x21, [sp, #552]
    b524:	f9011be2 	str	x2, [sp, #560]
    b528:	97ffe9ef 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b52c:	91190283 	add	x3, x20, #0x640
    b530:	aa0003f5 	mov	x21, x0
    b534:	f949d861 	ldr	x1, [x3, #5040]
    b538:	f949ec60 	ldr	x0, [x3, #5080]
    b53c:	cb0102a1 	sub	x1, x21, x1
    b540:	eb00403f 	cmp	x1, x0, lsl #16
    b544:	54000322 	b.cs	b5a8 <f0+0x938>  // b.hs, b.nlast
    b548:	d350fc22 	lsr	x2, x1, #16
    b54c:	f949fc63 	ldr	x3, [x3, #5112]
    b550:	8b020842 	add	x2, x2, x2, lsl #2
    b554:	d37df042 	lsl	x2, x2, #3
    b558:	8b020060 	add	x0, x3, x2
    b55c:	f9401017 	ldr	x23, [x0, #32]
    b560:	b4000257 	cbz	x23, b5a8 <f0+0x938>
    b564:	38626862 	ldrb	w2, [x3, x2]
    b568:	7100085f 	cmp	w2, #0x2
    b56c:	5400d800 	b.eq	d06c <f0+0x23fc>  // b.none
    b570:	7100045f 	cmp	w2, #0x1
    b574:	540001a1 	b.ne	b5a8 <f0+0x938>  // b.any
    b578:	29430002 	ldp	w2, w0, [x0, #24]
    b57c:	92403c21 	and	x1, x1, #0xffff
    b580:	9b027c21 	mul	x1, x1, x2
    b584:	d360fc21 	lsr	x1, x1, #32
    b588:	eb00003f 	cmp	x1, x0
    b58c:	540000e2 	b.cs	b5a8 <f0+0x938>  // b.hs, b.nlast
    b590:	8b0102f7 	add	x23, x23, x1
    b594:	394002e0 	ldrb	w0, [x23]
    b598:	7103fc1f 	cmp	w0, #0xff
    b59c:	5400df20 	b.eq	d180 <f0+0x2510>  // b.none
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	390002e0 	strb	w0, [x23]
    b5a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b5ac:	9108e3e1 	add	x1, sp, #0x238
    b5b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b5b4:	52800020 	mov	w0, #0x1                   	// #1
    b5b8:	f9011fe2 	str	x2, [sp, #568]
    b5bc:	f90123f5 	str	x21, [sp, #576]
    b5c0:	97ffe9c9 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b5c4:	97ffea4b 	bl	5ef0 <fwp_rc_fresh>
    b5c8:	aa0003e2 	mov	x2, x0
    b5cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b5d0:	910923e1 	add	x1, sp, #0x248
    b5d4:	52800020 	mov	w0, #0x1                   	// #1
    b5d8:	f90127e3 	str	x3, [sp, #584]
    b5dc:	f9012be2 	str	x2, [sp, #592]
    b5e0:	97ffe9c1 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b5e4:	91190283 	add	x3, x20, #0x640
    b5e8:	aa0003f5 	mov	x21, x0
    b5ec:	f949d861 	ldr	x1, [x3, #5040]
    b5f0:	f949ec60 	ldr	x0, [x3, #5080]
    b5f4:	cb0102a1 	sub	x1, x21, x1
    b5f8:	eb00403f 	cmp	x1, x0, lsl #16
    b5fc:	54000322 	b.cs	b660 <f0+0x9f0>  // b.hs, b.nlast
    b600:	d350fc22 	lsr	x2, x1, #16
    b604:	f949fc63 	ldr	x3, [x3, #5112]
    b608:	8b020842 	add	x2, x2, x2, lsl #2
    b60c:	d37df042 	lsl	x2, x2, #3
    b610:	8b020060 	add	x0, x3, x2
    b614:	f9401017 	ldr	x23, [x0, #32]
    b618:	b4000257 	cbz	x23, b660 <f0+0x9f0>
    b61c:	38626862 	ldrb	w2, [x3, x2]
    b620:	7100085f 	cmp	w2, #0x2
    b624:	5400d1e0 	b.eq	d060 <f0+0x23f0>  // b.none
    b628:	7100045f 	cmp	w2, #0x1
    b62c:	540001a1 	b.ne	b660 <f0+0x9f0>  // b.any
    b630:	29430002 	ldp	w2, w0, [x0, #24]
    b634:	92403c21 	and	x1, x1, #0xffff
    b638:	9b027c21 	mul	x1, x1, x2
    b63c:	d360fc21 	lsr	x1, x1, #32
    b640:	eb00003f 	cmp	x1, x0
    b644:	540000e2 	b.cs	b660 <f0+0x9f0>  // b.hs, b.nlast
    b648:	8b0102f7 	add	x23, x23, x1
    b64c:	394002e0 	ldrb	w0, [x23]
    b650:	7103fc1f 	cmp	w0, #0xff
    b654:	5400d9c0 	b.eq	d18c <f0+0x251c>  // b.none
    b658:	52800020 	mov	w0, #0x1                   	// #1
    b65c:	390002e0 	strb	w0, [x23]
    b660:	910963e1 	add	x1, sp, #0x258
    b664:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b668:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b66c:	52800020 	mov	w0, #0x1                   	// #1
    b670:	f9012ff7 	str	x23, [sp, #600]
    b674:	f90133f5 	str	x21, [sp, #608]
    b678:	97ffe99b 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b67c:	97ffea1d 	bl	5ef0 <fwp_rc_fresh>
    b680:	aa0003e2 	mov	x2, x0
    b684:	9109a3e1 	add	x1, sp, #0x268
    b688:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b68c:	52800020 	mov	w0, #0x1                   	// #1
    b690:	f90137f5 	str	x21, [sp, #616]
    b694:	f9013be2 	str	x2, [sp, #624]
    b698:	97ffe993 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b69c:	97ffea15 	bl	5ef0 <fwp_rc_fresh>
    b6a0:	aa0003e2 	mov	x2, x0
    b6a4:	9109e3e1 	add	x1, sp, #0x278
    b6a8:	52800020 	mov	w0, #0x1                   	// #1
    b6ac:	f9013ff7 	str	x23, [sp, #632]
    b6b0:	f90143e2 	str	x2, [sp, #640]
    b6b4:	97ffe98c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b6b8:	97ffea0e 	bl	5ef0 <fwp_rc_fresh>
    b6bc:	aa0003e2 	mov	x2, x0
    b6c0:	910a23e1 	add	x1, sp, #0x288
    b6c4:	52800020 	mov	w0, #0x1                   	// #1
    b6c8:	f90147f5 	str	x21, [sp, #648]
    b6cc:	f9014be2 	str	x2, [sp, #656]
    b6d0:	97ffe985 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b6d4:	91190283 	add	x3, x20, #0x640
    b6d8:	aa0003f5 	mov	x21, x0
    b6dc:	f949d861 	ldr	x1, [x3, #5040]
    b6e0:	f949ec60 	ldr	x0, [x3, #5080]
    b6e4:	cb0102a1 	sub	x1, x21, x1
    b6e8:	eb00403f 	cmp	x1, x0, lsl #16
    b6ec:	54000322 	b.cs	b750 <f0+0xae0>  // b.hs, b.nlast
    b6f0:	d350fc22 	lsr	x2, x1, #16
    b6f4:	f949fc63 	ldr	x3, [x3, #5112]
    b6f8:	8b020842 	add	x2, x2, x2, lsl #2
    b6fc:	d37df042 	lsl	x2, x2, #3
    b700:	8b020060 	add	x0, x3, x2
    b704:	f9401017 	ldr	x23, [x0, #32]
    b708:	b4000257 	cbz	x23, b750 <f0+0xae0>
    b70c:	38626862 	ldrb	w2, [x3, x2]
    b710:	7100085f 	cmp	w2, #0x2
    b714:	5400cb80 	b.eq	d084 <f0+0x2414>  // b.none
    b718:	7100045f 	cmp	w2, #0x1
    b71c:	540001a1 	b.ne	b750 <f0+0xae0>  // b.any
    b720:	29430002 	ldp	w2, w0, [x0, #24]
    b724:	92403c21 	and	x1, x1, #0xffff
    b728:	9b027c21 	mul	x1, x1, x2
    b72c:	d360fc21 	lsr	x1, x1, #32
    b730:	eb00003f 	cmp	x1, x0
    b734:	540000e2 	b.cs	b750 <f0+0xae0>  // b.hs, b.nlast
    b738:	8b0102f7 	add	x23, x23, x1
    b73c:	394002e0 	ldrb	w0, [x23]
    b740:	7103fc1f 	cmp	w0, #0xff
    b744:	5400d2a0 	b.eq	d198 <f0+0x2528>  // b.none
    b748:	52800020 	mov	w0, #0x1                   	// #1
    b74c:	390002e0 	strb	w0, [x23]
    b750:	910a63e1 	add	x1, sp, #0x298
    b754:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b758:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b75c:	52800020 	mov	w0, #0x1                   	// #1
    b760:	f9014ff7 	str	x23, [sp, #664]
    b764:	f90153f5 	str	x21, [sp, #672]
    b768:	97ffe95f 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b76c:	97ffe9e1 	bl	5ef0 <fwp_rc_fresh>
    b770:	aa0003e2 	mov	x2, x0
    b774:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b778:	910aa3e1 	add	x1, sp, #0x2a8
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f90157e3 	str	x3, [sp, #680]
    b784:	f9015be2 	str	x2, [sp, #688]
    b788:	97ffe957 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b78c:	97ffe9d9 	bl	5ef0 <fwp_rc_fresh>
    b790:	aa0003e2 	mov	x2, x0
    b794:	910ae3e1 	add	x1, sp, #0x2b8
    b798:	52800020 	mov	w0, #0x1                   	// #1
    b79c:	f9015ff7 	str	x23, [sp, #696]
    b7a0:	f90163e2 	str	x2, [sp, #704]
    b7a4:	97ffe950 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b7a8:	91190283 	add	x3, x20, #0x640
    b7ac:	aa0003f5 	mov	x21, x0
    b7b0:	f949d861 	ldr	x1, [x3, #5040]
    b7b4:	f949ec60 	ldr	x0, [x3, #5080]
    b7b8:	cb0102a1 	sub	x1, x21, x1
    b7bc:	eb00403f 	cmp	x1, x0, lsl #16
    b7c0:	54000322 	b.cs	b824 <f0+0xbb4>  // b.hs, b.nlast
    b7c4:	d350fc22 	lsr	x2, x1, #16
    b7c8:	f949fc63 	ldr	x3, [x3, #5112]
    b7cc:	8b020842 	add	x2, x2, x2, lsl #2
    b7d0:	d37df042 	lsl	x2, x2, #3
    b7d4:	8b020060 	add	x0, x3, x2
    b7d8:	f9401017 	ldr	x23, [x0, #32]
    b7dc:	b4000257 	cbz	x23, b824 <f0+0xbb4>
    b7e0:	38626862 	ldrb	w2, [x3, x2]
    b7e4:	7100085f 	cmp	w2, #0x2
    b7e8:	5400c480 	b.eq	d078 <f0+0x2408>  // b.none
    b7ec:	7100045f 	cmp	w2, #0x1
    b7f0:	540001a1 	b.ne	b824 <f0+0xbb4>  // b.any
    b7f4:	29430002 	ldp	w2, w0, [x0, #24]
    b7f8:	92403c21 	and	x1, x1, #0xffff
    b7fc:	9b027c21 	mul	x1, x1, x2
    b800:	d360fc21 	lsr	x1, x1, #32
    b804:	eb00003f 	cmp	x1, x0
    b808:	540000e2 	b.cs	b824 <f0+0xbb4>  // b.hs, b.nlast
    b80c:	8b0102f7 	add	x23, x23, x1
    b810:	394002e0 	ldrb	w0, [x23]
    b814:	7103fc1f 	cmp	w0, #0xff
    b818:	5400cc60 	b.eq	d1a4 <f0+0x2534>  // b.none
    b81c:	52800020 	mov	w0, #0x1                   	// #1
    b820:	390002e0 	strb	w0, [x23]
    b824:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b828:	910b23e1 	add	x1, sp, #0x2c8
    b82c:	52800020 	mov	w0, #0x1                   	// #1
    b830:	f90167e2 	str	x2, [sp, #712]
    b834:	f9016bf5 	str	x21, [sp, #720]
    b838:	97ffe92b 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b83c:	91190283 	add	x3, x20, #0x640
    b840:	aa0003f5 	mov	x21, x0
    b844:	f949d861 	ldr	x1, [x3, #5040]
    b848:	f949ec60 	ldr	x0, [x3, #5080]
    b84c:	cb0102a1 	sub	x1, x21, x1
    b850:	eb00403f 	cmp	x1, x0, lsl #16
    b854:	54000322 	b.cs	b8b8 <f0+0xc48>  // b.hs, b.nlast
    b858:	d350fc22 	lsr	x2, x1, #16
    b85c:	f949fc63 	ldr	x3, [x3, #5112]
    b860:	8b020842 	add	x2, x2, x2, lsl #2
    b864:	d37df042 	lsl	x2, x2, #3
    b868:	8b020060 	add	x0, x3, x2
    b86c:	f9401017 	ldr	x23, [x0, #32]
    b870:	b4000257 	cbz	x23, b8b8 <f0+0xc48>
    b874:	38626862 	ldrb	w2, [x3, x2]
    b878:	7100085f 	cmp	w2, #0x2
    b87c:	5400c100 	b.eq	d09c <f0+0x242c>  // b.none
    b880:	7100045f 	cmp	w2, #0x1
    b884:	540001a1 	b.ne	b8b8 <f0+0xc48>  // b.any
    b888:	29430002 	ldp	w2, w0, [x0, #24]
    b88c:	92403c21 	and	x1, x1, #0xffff
    b890:	9b027c21 	mul	x1, x1, x2
    b894:	d360fc21 	lsr	x1, x1, #32
    b898:	eb00003f 	cmp	x1, x0
    b89c:	540000e2 	b.cs	b8b8 <f0+0xc48>  // b.hs, b.nlast
    b8a0:	8b0102f7 	add	x23, x23, x1
    b8a4:	394002e0 	ldrb	w0, [x23]
    b8a8:	7103fc1f 	cmp	w0, #0xff
    b8ac:	5400c820 	b.eq	d1b0 <f0+0x2540>  // b.none
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	390002e0 	strb	w0, [x23]
    b8b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b8bc:	910b63e1 	add	x1, sp, #0x2d8
    b8c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b8c4:	52800020 	mov	w0, #0x1                   	// #1
    b8c8:	f9016fe2 	str	x2, [sp, #728]
    b8cc:	f90173f5 	str	x21, [sp, #736]
    b8d0:	97ffe905 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b8d4:	91190283 	add	x3, x20, #0x640
    b8d8:	aa0003f5 	mov	x21, x0
    b8dc:	f949d861 	ldr	x1, [x3, #5040]
    b8e0:	f949ec60 	ldr	x0, [x3, #5080]
    b8e4:	cb0102a1 	sub	x1, x21, x1
    b8e8:	eb00403f 	cmp	x1, x0, lsl #16
    b8ec:	54000322 	b.cs	b950 <f0+0xce0>  // b.hs, b.nlast
    b8f0:	d350fc22 	lsr	x2, x1, #16
    b8f4:	f949fc63 	ldr	x3, [x3, #5112]
    b8f8:	8b020842 	add	x2, x2, x2, lsl #2
    b8fc:	d37df042 	lsl	x2, x2, #3
    b900:	8b020060 	add	x0, x3, x2
    b904:	f9401017 	ldr	x23, [x0, #32]
    b908:	b4000257 	cbz	x23, b950 <f0+0xce0>
    b90c:	38626862 	ldrb	w2, [x3, x2]
    b910:	7100085f 	cmp	w2, #0x2
    b914:	5400bbe0 	b.eq	d090 <f0+0x2420>  // b.none
    b918:	7100045f 	cmp	w2, #0x1
    b91c:	540001a1 	b.ne	b950 <f0+0xce0>  // b.any
    b920:	29430002 	ldp	w2, w0, [x0, #24]
    b924:	92403c21 	and	x1, x1, #0xffff
    b928:	9b027c21 	mul	x1, x1, x2
    b92c:	d360fc21 	lsr	x1, x1, #32
    b930:	eb00003f 	cmp	x1, x0
    b934:	540000e2 	b.cs	b950 <f0+0xce0>  // b.hs, b.nlast
    b938:	8b0102f7 	add	x23, x23, x1
    b93c:	394002e0 	ldrb	w0, [x23]
    b940:	7103fc1f 	cmp	w0, #0xff
    b944:	5400c3c0 	b.eq	d1bc <f0+0x254c>  // b.none
    b948:	52800020 	mov	w0, #0x1                   	// #1
    b94c:	390002e0 	strb	w0, [x23]
    b950:	910ba3e1 	add	x1, sp, #0x2e8
    b954:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f90177e2 	str	x2, [sp, #744]
    b960:	f9017bf5 	str	x21, [sp, #752]
    b964:	97ffe8e0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b968:	97ffe962 	bl	5ef0 <fwp_rc_fresh>
    b96c:	aa0003e2 	mov	x2, x0
    b970:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b974:	910be3e1 	add	x1, sp, #0x2f8
    b978:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b97c:	52800020 	mov	w0, #0x1                   	// #1
    b980:	f9017fe3 	str	x3, [sp, #760]
    b984:	f90183e2 	str	x2, [sp, #768]
    b988:	97ffe8d7 	bl	5ce4 <fwp_data.part.0.constprop.0>
    b98c:	91190283 	add	x3, x20, #0x640
    b990:	aa0003f5 	mov	x21, x0
    b994:	f949d861 	ldr	x1, [x3, #5040]
    b998:	f949ec60 	ldr	x0, [x3, #5080]
    b99c:	cb0102a1 	sub	x1, x21, x1
    b9a0:	eb00403f 	cmp	x1, x0, lsl #16
    b9a4:	54000322 	b.cs	ba08 <f0+0xd98>  // b.hs, b.nlast
    b9a8:	d350fc22 	lsr	x2, x1, #16
    b9ac:	f949fc63 	ldr	x3, [x3, #5112]
    b9b0:	8b020842 	add	x2, x2, x2, lsl #2
    b9b4:	d37df042 	lsl	x2, x2, #3
    b9b8:	8b020060 	add	x0, x3, x2
    b9bc:	f9401017 	ldr	x23, [x0, #32]
    b9c0:	b4000257 	cbz	x23, ba08 <f0+0xd98>
    b9c4:	38626862 	ldrb	w2, [x3, x2]
    b9c8:	7100085f 	cmp	w2, #0x2
    b9cc:	5400b740 	b.eq	d0b4 <f0+0x2444>  // b.none
    b9d0:	7100045f 	cmp	w2, #0x1
    b9d4:	540001a1 	b.ne	ba08 <f0+0xd98>  // b.any
    b9d8:	29430002 	ldp	w2, w0, [x0, #24]
    b9dc:	92403c21 	and	x1, x1, #0xffff
    b9e0:	9b027c21 	mul	x1, x1, x2
    b9e4:	d360fc21 	lsr	x1, x1, #32
    b9e8:	eb00003f 	cmp	x1, x0
    b9ec:	540000e2 	b.cs	ba08 <f0+0xd98>  // b.hs, b.nlast
    b9f0:	8b0102f7 	add	x23, x23, x1
    b9f4:	394002e0 	ldrb	w0, [x23]
    b9f8:	7103fc1f 	cmp	w0, #0xff
    b9fc:	5400be60 	b.eq	d1c8 <f0+0x2558>  // b.none
    ba00:	52800020 	mov	w0, #0x1                   	// #1
    ba04:	390002e0 	strb	w0, [x23]
    ba08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba0c:	910c23e1 	add	x1, sp, #0x308
    ba10:	52800020 	mov	w0, #0x1                   	// #1
    ba14:	f90187e2 	str	x2, [sp, #776]
    ba18:	f9018bf5 	str	x21, [sp, #784]
    ba1c:	97ffe8b2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ba20:	91190283 	add	x3, x20, #0x640
    ba24:	aa0003f5 	mov	x21, x0
    ba28:	f949d861 	ldr	x1, [x3, #5040]
    ba2c:	f949ec60 	ldr	x0, [x3, #5080]
    ba30:	cb0102a1 	sub	x1, x21, x1
    ba34:	eb00403f 	cmp	x1, x0, lsl #16
    ba38:	54000322 	b.cs	ba9c <f0+0xe2c>  // b.hs, b.nlast
    ba3c:	d350fc22 	lsr	x2, x1, #16
    ba40:	f949fc63 	ldr	x3, [x3, #5112]
    ba44:	8b020842 	add	x2, x2, x2, lsl #2
    ba48:	d37df042 	lsl	x2, x2, #3
    ba4c:	8b020060 	add	x0, x3, x2
    ba50:	f9401017 	ldr	x23, [x0, #32]
    ba54:	b4000257 	cbz	x23, ba9c <f0+0xe2c>
    ba58:	38626862 	ldrb	w2, [x3, x2]
    ba5c:	7100085f 	cmp	w2, #0x2
    ba60:	5400b240 	b.eq	d0a8 <f0+0x2438>  // b.none
    ba64:	7100045f 	cmp	w2, #0x1
    ba68:	540001a1 	b.ne	ba9c <f0+0xe2c>  // b.any
    ba6c:	29430002 	ldp	w2, w0, [x0, #24]
    ba70:	92403c21 	and	x1, x1, #0xffff
    ba74:	9b027c21 	mul	x1, x1, x2
    ba78:	d360fc21 	lsr	x1, x1, #32
    ba7c:	eb00003f 	cmp	x1, x0
    ba80:	540000e2 	b.cs	ba9c <f0+0xe2c>  // b.hs, b.nlast
    ba84:	8b0102f7 	add	x23, x23, x1
    ba88:	394002e0 	ldrb	w0, [x23]
    ba8c:	7103fc1f 	cmp	w0, #0xff
    ba90:	5400ba20 	b.eq	d1d4 <f0+0x2564>  // b.none
    ba94:	52800020 	mov	w0, #0x1                   	// #1
    ba98:	390002e0 	strb	w0, [x23]
    ba9c:	910c63e1 	add	x1, sp, #0x318
    baa0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    baa4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    baa8:	52800020 	mov	w0, #0x1                   	// #1
    baac:	f9018ff7 	str	x23, [sp, #792]
    bab0:	f90193f5 	str	x21, [sp, #800]
    bab4:	97ffe88c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bab8:	97ffe90e 	bl	5ef0 <fwp_rc_fresh>
    babc:	aa0003e2 	mov	x2, x0
    bac0:	910ca3e1 	add	x1, sp, #0x328
    bac4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bac8:	52800020 	mov	w0, #0x1                   	// #1
    bacc:	f90197f5 	str	x21, [sp, #808]
    bad0:	f9019be2 	str	x2, [sp, #816]
    bad4:	97ffe884 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bad8:	97ffe906 	bl	5ef0 <fwp_rc_fresh>
    badc:	aa0003e2 	mov	x2, x0
    bae0:	910ce3e1 	add	x1, sp, #0x338
    bae4:	52800020 	mov	w0, #0x1                   	// #1
    bae8:	f9019ff7 	str	x23, [sp, #824]
    baec:	f901a3e2 	str	x2, [sp, #832]
    baf0:	97ffe87d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    baf4:	97ffe8ff 	bl	5ef0 <fwp_rc_fresh>
    baf8:	aa0003e2 	mov	x2, x0
    bafc:	910d23e1 	add	x1, sp, #0x348
    bb00:	52800020 	mov	w0, #0x1                   	// #1
    bb04:	f901a7f5 	str	x21, [sp, #840]
    bb08:	f901abe2 	str	x2, [sp, #848]
    bb0c:	97ffe876 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bb10:	91190283 	add	x3, x20, #0x640
    bb14:	aa0003f5 	mov	x21, x0
    bb18:	f949d861 	ldr	x1, [x3, #5040]
    bb1c:	f949ec60 	ldr	x0, [x3, #5080]
    bb20:	cb0102a1 	sub	x1, x21, x1
    bb24:	eb00403f 	cmp	x1, x0, lsl #16
    bb28:	54000322 	b.cs	bb8c <f0+0xf1c>  // b.hs, b.nlast
    bb2c:	d350fc22 	lsr	x2, x1, #16
    bb30:	f949fc63 	ldr	x3, [x3, #5112]
    bb34:	8b020842 	add	x2, x2, x2, lsl #2
    bb38:	d37df042 	lsl	x2, x2, #3
    bb3c:	8b020060 	add	x0, x3, x2
    bb40:	f9401017 	ldr	x23, [x0, #32]
    bb44:	b4000257 	cbz	x23, bb8c <f0+0xf1c>
    bb48:	38626862 	ldrb	w2, [x3, x2]
    bb4c:	7100085f 	cmp	w2, #0x2
    bb50:	5400abe0 	b.eq	d0cc <f0+0x245c>  // b.none
    bb54:	7100045f 	cmp	w2, #0x1
    bb58:	540001a1 	b.ne	bb8c <f0+0xf1c>  // b.any
    bb5c:	29430002 	ldp	w2, w0, [x0, #24]
    bb60:	92403c21 	and	x1, x1, #0xffff
    bb64:	9b027c21 	mul	x1, x1, x2
    bb68:	d360fc21 	lsr	x1, x1, #32
    bb6c:	eb00003f 	cmp	x1, x0
    bb70:	540000e2 	b.cs	bb8c <f0+0xf1c>  // b.hs, b.nlast
    bb74:	8b0102f7 	add	x23, x23, x1
    bb78:	394002e0 	ldrb	w0, [x23]
    bb7c:	7103fc1f 	cmp	w0, #0xff
    bb80:	5400b300 	b.eq	d1e0 <f0+0x2570>  // b.none
    bb84:	52800020 	mov	w0, #0x1                   	// #1
    bb88:	390002e0 	strb	w0, [x23]
    bb8c:	910d63e1 	add	x1, sp, #0x358
    bb90:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb98:	52800020 	mov	w0, #0x1                   	// #1
    bb9c:	f901aff7 	str	x23, [sp, #856]
    bba0:	f901b3f5 	str	x21, [sp, #864]
    bba4:	97ffe850 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bba8:	97ffe8d2 	bl	5ef0 <fwp_rc_fresh>
    bbac:	aa0003e2 	mov	x2, x0
    bbb0:	910da3e1 	add	x1, sp, #0x368
    bbb4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bbb8:	52800020 	mov	w0, #0x1                   	// #1
    bbbc:	f901b7f5 	str	x21, [sp, #872]
    bbc0:	f901bbe2 	str	x2, [sp, #880]
    bbc4:	97ffe848 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bbc8:	97ffe8ca 	bl	5ef0 <fwp_rc_fresh>
    bbcc:	aa0003e2 	mov	x2, x0
    bbd0:	910de3e1 	add	x1, sp, #0x378
    bbd4:	52800020 	mov	w0, #0x1                   	// #1
    bbd8:	f901bff7 	str	x23, [sp, #888]
    bbdc:	f901c3e2 	str	x2, [sp, #896]
    bbe0:	97ffe841 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bbe4:	97ffe8c3 	bl	5ef0 <fwp_rc_fresh>
    bbe8:	aa0003e2 	mov	x2, x0
    bbec:	910e23e1 	add	x1, sp, #0x388
    bbf0:	52800020 	mov	w0, #0x1                   	// #1
    bbf4:	f901c7f5 	str	x21, [sp, #904]
    bbf8:	f901cbe2 	str	x2, [sp, #912]
    bbfc:	97ffe83a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bc00:	91190283 	add	x3, x20, #0x640
    bc04:	aa0003f5 	mov	x21, x0
    bc08:	f949d861 	ldr	x1, [x3, #5040]
    bc0c:	f949ec60 	ldr	x0, [x3, #5080]
    bc10:	cb0102a1 	sub	x1, x21, x1
    bc14:	eb00403f 	cmp	x1, x0, lsl #16
    bc18:	54000322 	b.cs	bc7c <f0+0x100c>  // b.hs, b.nlast
    bc1c:	d350fc22 	lsr	x2, x1, #16
    bc20:	f949fc63 	ldr	x3, [x3, #5112]
    bc24:	8b020842 	add	x2, x2, x2, lsl #2
    bc28:	d37df042 	lsl	x2, x2, #3
    bc2c:	8b020060 	add	x0, x3, x2
    bc30:	f9401017 	ldr	x23, [x0, #32]
    bc34:	b4000257 	cbz	x23, bc7c <f0+0x100c>
    bc38:	38626862 	ldrb	w2, [x3, x2]
    bc3c:	7100085f 	cmp	w2, #0x2
    bc40:	5400a400 	b.eq	d0c0 <f0+0x2450>  // b.none
    bc44:	7100045f 	cmp	w2, #0x1
    bc48:	540001a1 	b.ne	bc7c <f0+0x100c>  // b.any
    bc4c:	29430002 	ldp	w2, w0, [x0, #24]
    bc50:	92403c21 	and	x1, x1, #0xffff
    bc54:	9b027c21 	mul	x1, x1, x2
    bc58:	d360fc21 	lsr	x1, x1, #32
    bc5c:	eb00003f 	cmp	x1, x0
    bc60:	540000e2 	b.cs	bc7c <f0+0x100c>  // b.hs, b.nlast
    bc64:	8b0102f7 	add	x23, x23, x1
    bc68:	394002e0 	ldrb	w0, [x23]
    bc6c:	7103fc1f 	cmp	w0, #0xff
    bc70:	5400abe0 	b.eq	d1ec <f0+0x257c>  // b.none
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	390002e0 	strb	w0, [x23]
    bc7c:	910e63e1 	add	x1, sp, #0x398
    bc80:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bc84:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	f901cff7 	str	x23, [sp, #920]
    bc90:	f901d3f5 	str	x21, [sp, #928]
    bc94:	97ffe814 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bc98:	97ffe896 	bl	5ef0 <fwp_rc_fresh>
    bc9c:	aa0003e2 	mov	x2, x0
    bca0:	910ea3e1 	add	x1, sp, #0x3a8
    bca4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bca8:	52800020 	mov	w0, #0x1                   	// #1
    bcac:	f901d7f5 	str	x21, [sp, #936]
    bcb0:	f901dbe2 	str	x2, [sp, #944]
    bcb4:	97ffe80c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bcb8:	97ffe88e 	bl	5ef0 <fwp_rc_fresh>
    bcbc:	aa0003e2 	mov	x2, x0
    bcc0:	910ee3e1 	add	x1, sp, #0x3b8
    bcc4:	52800020 	mov	w0, #0x1                   	// #1
    bcc8:	f901dff7 	str	x23, [sp, #952]
    bccc:	f901e3e2 	str	x2, [sp, #960]
    bcd0:	97ffe805 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bcd4:	97ffe887 	bl	5ef0 <fwp_rc_fresh>
    bcd8:	aa0003e2 	mov	x2, x0
    bcdc:	910f23e1 	add	x1, sp, #0x3c8
    bce0:	52800020 	mov	w0, #0x1                   	// #1
    bce4:	f901e7f5 	str	x21, [sp, #968]
    bce8:	f901ebe2 	str	x2, [sp, #976]
    bcec:	97ffe7fe 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bcf0:	91190283 	add	x3, x20, #0x640
    bcf4:	aa0003f5 	mov	x21, x0
    bcf8:	f949d861 	ldr	x1, [x3, #5040]
    bcfc:	f949ec60 	ldr	x0, [x3, #5080]
    bd00:	cb0102a1 	sub	x1, x21, x1
    bd04:	eb00403f 	cmp	x1, x0, lsl #16
    bd08:	54000322 	b.cs	bd6c <f0+0x10fc>  // b.hs, b.nlast
    bd0c:	d350fc22 	lsr	x2, x1, #16
    bd10:	f949fc63 	ldr	x3, [x3, #5112]
    bd14:	8b020842 	add	x2, x2, x2, lsl #2
    bd18:	d37df042 	lsl	x2, x2, #3
    bd1c:	8b020060 	add	x0, x3, x2
    bd20:	f9401017 	ldr	x23, [x0, #32]
    bd24:	b4000257 	cbz	x23, bd6c <f0+0x10fc>
    bd28:	38626862 	ldrb	w2, [x3, x2]
    bd2c:	7100085f 	cmp	w2, #0x2
    bd30:	54009da0 	b.eq	d0e4 <f0+0x2474>  // b.none
    bd34:	7100045f 	cmp	w2, #0x1
    bd38:	540001a1 	b.ne	bd6c <f0+0x10fc>  // b.any
    bd3c:	29430002 	ldp	w2, w0, [x0, #24]
    bd40:	92403c21 	and	x1, x1, #0xffff
    bd44:	9b027c21 	mul	x1, x1, x2
    bd48:	d360fc21 	lsr	x1, x1, #32
    bd4c:	eb00003f 	cmp	x1, x0
    bd50:	540000e2 	b.cs	bd6c <f0+0x10fc>  // b.hs, b.nlast
    bd54:	8b0102f7 	add	x23, x23, x1
    bd58:	394002e0 	ldrb	w0, [x23]
    bd5c:	7103fc1f 	cmp	w0, #0xff
    bd60:	5400a4c0 	b.eq	d1f8 <f0+0x2588>  // b.none
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	390002e0 	strb	w0, [x23]
    bd6c:	910f63e1 	add	x1, sp, #0x3d8
    bd70:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd74:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd78:	52800020 	mov	w0, #0x1                   	// #1
    bd7c:	f901eff7 	str	x23, [sp, #984]
    bd80:	f901f3f5 	str	x21, [sp, #992]
    bd84:	97ffe7d8 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bd88:	97ffe85a 	bl	5ef0 <fwp_rc_fresh>
    bd8c:	aa0003e2 	mov	x2, x0
    bd90:	910fa3e1 	add	x1, sp, #0x3e8
    bd94:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd98:	52800020 	mov	w0, #0x1                   	// #1
    bd9c:	f901f7f5 	str	x21, [sp, #1000]
    bda0:	f901fbe2 	str	x2, [sp, #1008]
    bda4:	97ffe7d0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bda8:	97ffe852 	bl	5ef0 <fwp_rc_fresh>
    bdac:	aa0003e2 	mov	x2, x0
    bdb0:	910fe3e1 	add	x1, sp, #0x3f8
    bdb4:	52800020 	mov	w0, #0x1                   	// #1
    bdb8:	f901fff7 	str	x23, [sp, #1016]
    bdbc:	f90203e2 	str	x2, [sp, #1024]
    bdc0:	97ffe7c9 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bdc4:	97ffe84b 	bl	5ef0 <fwp_rc_fresh>
    bdc8:	aa0003e2 	mov	x2, x0
    bdcc:	911023e1 	add	x1, sp, #0x408
    bdd0:	52800020 	mov	w0, #0x1                   	// #1
    bdd4:	f90207f5 	str	x21, [sp, #1032]
    bdd8:	f9020be2 	str	x2, [sp, #1040]
    bddc:	97ffe7c2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bde0:	91190283 	add	x3, x20, #0x640
    bde4:	aa0003f5 	mov	x21, x0
    bde8:	f949d861 	ldr	x1, [x3, #5040]
    bdec:	f949ec60 	ldr	x0, [x3, #5080]
    bdf0:	cb0102a1 	sub	x1, x21, x1
    bdf4:	eb00403f 	cmp	x1, x0, lsl #16
    bdf8:	54000322 	b.cs	be5c <f0+0x11ec>  // b.hs, b.nlast
    bdfc:	d350fc22 	lsr	x2, x1, #16
    be00:	f949fc63 	ldr	x3, [x3, #5112]
    be04:	8b020842 	add	x2, x2, x2, lsl #2
    be08:	d37df042 	lsl	x2, x2, #3
    be0c:	8b020060 	add	x0, x3, x2
    be10:	f9401017 	ldr	x23, [x0, #32]
    be14:	b4000257 	cbz	x23, be5c <f0+0x11ec>
    be18:	38626862 	ldrb	w2, [x3, x2]
    be1c:	7100085f 	cmp	w2, #0x2
    be20:	540095c0 	b.eq	d0d8 <f0+0x2468>  // b.none
    be24:	7100045f 	cmp	w2, #0x1
    be28:	540001a1 	b.ne	be5c <f0+0x11ec>  // b.any
    be2c:	29430002 	ldp	w2, w0, [x0, #24]
    be30:	92403c21 	and	x1, x1, #0xffff
    be34:	9b027c21 	mul	x1, x1, x2
    be38:	d360fc21 	lsr	x1, x1, #32
    be3c:	eb00003f 	cmp	x1, x0
    be40:	540000e2 	b.cs	be5c <f0+0x11ec>  // b.hs, b.nlast
    be44:	8b0102f7 	add	x23, x23, x1
    be48:	394002e0 	ldrb	w0, [x23]
    be4c:	7103fc1f 	cmp	w0, #0xff
    be50:	54009da0 	b.eq	d204 <f0+0x2594>  // b.none
    be54:	52800020 	mov	w0, #0x1                   	// #1
    be58:	390002e0 	strb	w0, [x23]
    be5c:	911063e1 	add	x1, sp, #0x418
    be60:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    be64:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    be68:	52800020 	mov	w0, #0x1                   	// #1
    be6c:	f9020ff7 	str	x23, [sp, #1048]
    be70:	f90213f5 	str	x21, [sp, #1056]
    be74:	97ffe79c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    be78:	97ffe81e 	bl	5ef0 <fwp_rc_fresh>
    be7c:	aa0003e2 	mov	x2, x0
    be80:	9110a3e1 	add	x1, sp, #0x428
    be84:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    be88:	52800020 	mov	w0, #0x1                   	// #1
    be8c:	f90217f5 	str	x21, [sp, #1064]
    be90:	f9021be2 	str	x2, [sp, #1072]
    be94:	97ffe794 	bl	5ce4 <fwp_data.part.0.constprop.0>
    be98:	97ffe816 	bl	5ef0 <fwp_rc_fresh>
    be9c:	aa0003e2 	mov	x2, x0
    bea0:	9110e3e1 	add	x1, sp, #0x438
    bea4:	52800020 	mov	w0, #0x1                   	// #1
    bea8:	f9021ff7 	str	x23, [sp, #1080]
    beac:	f90223e2 	str	x2, [sp, #1088]
    beb0:	97ffe78d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    beb4:	97ffe80f 	bl	5ef0 <fwp_rc_fresh>
    beb8:	aa0003e2 	mov	x2, x0
    bebc:	911123e1 	add	x1, sp, #0x448
    bec0:	52800020 	mov	w0, #0x1                   	// #1
    bec4:	f90227f5 	str	x21, [sp, #1096]
    bec8:	f9022be2 	str	x2, [sp, #1104]
    becc:	97ffe786 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bed0:	91190283 	add	x3, x20, #0x640
    bed4:	aa0003f5 	mov	x21, x0
    bed8:	f949d861 	ldr	x1, [x3, #5040]
    bedc:	f949ec60 	ldr	x0, [x3, #5080]
    bee0:	cb0102a1 	sub	x1, x21, x1
    bee4:	eb00403f 	cmp	x1, x0, lsl #16
    bee8:	54000322 	b.cs	bf4c <f0+0x12dc>  // b.hs, b.nlast
    beec:	d350fc22 	lsr	x2, x1, #16
    bef0:	f949fc63 	ldr	x3, [x3, #5112]
    bef4:	8b020842 	add	x2, x2, x2, lsl #2
    bef8:	d37df042 	lsl	x2, x2, #3
    befc:	8b020060 	add	x0, x3, x2
    bf00:	f9401017 	ldr	x23, [x0, #32]
    bf04:	b4000257 	cbz	x23, bf4c <f0+0x12dc>
    bf08:	38626862 	ldrb	w2, [x3, x2]
    bf0c:	7100085f 	cmp	w2, #0x2
    bf10:	54008f60 	b.eq	d0fc <f0+0x248c>  // b.none
    bf14:	7100045f 	cmp	w2, #0x1
    bf18:	540001a1 	b.ne	bf4c <f0+0x12dc>  // b.any
    bf1c:	29430002 	ldp	w2, w0, [x0, #24]
    bf20:	92403c21 	and	x1, x1, #0xffff
    bf24:	9b027c21 	mul	x1, x1, x2
    bf28:	d360fc21 	lsr	x1, x1, #32
    bf2c:	eb00003f 	cmp	x1, x0
    bf30:	540000e2 	b.cs	bf4c <f0+0x12dc>  // b.hs, b.nlast
    bf34:	8b0102f7 	add	x23, x23, x1
    bf38:	394002e0 	ldrb	w0, [x23]
    bf3c:	7103fc1f 	cmp	w0, #0xff
    bf40:	54009680 	b.eq	d210 <f0+0x25a0>  // b.none
    bf44:	52800020 	mov	w0, #0x1                   	// #1
    bf48:	390002e0 	strb	w0, [x23]
    bf4c:	911163e1 	add	x1, sp, #0x458
    bf50:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bf54:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bf58:	52800020 	mov	w0, #0x1                   	// #1
    bf5c:	f9022ff7 	str	x23, [sp, #1112]
    bf60:	f90233f5 	str	x21, [sp, #1120]
    bf64:	97ffe760 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bf68:	97ffe7e2 	bl	5ef0 <fwp_rc_fresh>
    bf6c:	aa0003e2 	mov	x2, x0
    bf70:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bf74:	9111a3e1 	add	x1, sp, #0x468
    bf78:	52800020 	mov	w0, #0x1                   	// #1
    bf7c:	f90237e3 	str	x3, [sp, #1128]
    bf80:	f9023be2 	str	x2, [sp, #1136]
    bf84:	97ffe758 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bf88:	97ffe7da 	bl	5ef0 <fwp_rc_fresh>
    bf8c:	aa0003e2 	mov	x2, x0
    bf90:	9111e3e1 	add	x1, sp, #0x478
    bf94:	52800020 	mov	w0, #0x1                   	// #1
    bf98:	f9023ff7 	str	x23, [sp, #1144]
    bf9c:	f90243e2 	str	x2, [sp, #1152]
    bfa0:	97ffe751 	bl	5ce4 <fwp_data.part.0.constprop.0>
    bfa4:	91190283 	add	x3, x20, #0x640
    bfa8:	aa0003f5 	mov	x21, x0
    bfac:	f949d861 	ldr	x1, [x3, #5040]
    bfb0:	f949ec60 	ldr	x0, [x3, #5080]
    bfb4:	cb0102a1 	sub	x1, x21, x1
    bfb8:	eb00403f 	cmp	x1, x0, lsl #16
    bfbc:	54000322 	b.cs	c020 <f0+0x13b0>  // b.hs, b.nlast
    bfc0:	d350fc22 	lsr	x2, x1, #16
    bfc4:	f949fc63 	ldr	x3, [x3, #5112]
    bfc8:	8b020842 	add	x2, x2, x2, lsl #2
    bfcc:	d37df042 	lsl	x2, x2, #3
    bfd0:	8b020060 	add	x0, x3, x2
    bfd4:	f9401017 	ldr	x23, [x0, #32]
    bfd8:	b4000257 	cbz	x23, c020 <f0+0x13b0>
    bfdc:	38626862 	ldrb	w2, [x3, x2]
    bfe0:	7100085f 	cmp	w2, #0x2
    bfe4:	54008860 	b.eq	d0f0 <f0+0x2480>  // b.none
    bfe8:	7100045f 	cmp	w2, #0x1
    bfec:	540001a1 	b.ne	c020 <f0+0x13b0>  // b.any
    bff0:	29430002 	ldp	w2, w0, [x0, #24]
    bff4:	92403c21 	and	x1, x1, #0xffff
    bff8:	9b027c21 	mul	x1, x1, x2
    bffc:	d360fc21 	lsr	x1, x1, #32
    c000:	eb00003f 	cmp	x1, x0
    c004:	540000e2 	b.cs	c020 <f0+0x13b0>  // b.hs, b.nlast
    c008:	8b0102f7 	add	x23, x23, x1
    c00c:	394002e0 	ldrb	w0, [x23]
    c010:	7103fc1f 	cmp	w0, #0xff
    c014:	54009040 	b.eq	d21c <f0+0x25ac>  // b.none
    c018:	52800020 	mov	w0, #0x1                   	// #1
    c01c:	390002e0 	strb	w0, [x23]
    c020:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c024:	911223e1 	add	x1, sp, #0x488
    c028:	52800020 	mov	w0, #0x1                   	// #1
    c02c:	f90247e2 	str	x2, [sp, #1160]
    c030:	f9024bf5 	str	x21, [sp, #1168]
    c034:	97ffe72c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c038:	91190283 	add	x3, x20, #0x640
    c03c:	aa0003f5 	mov	x21, x0
    c040:	f949d861 	ldr	x1, [x3, #5040]
    c044:	f949ec60 	ldr	x0, [x3, #5080]
    c048:	cb0102a1 	sub	x1, x21, x1
    c04c:	eb00403f 	cmp	x1, x0, lsl #16
    c050:	54000322 	b.cs	c0b4 <f0+0x1444>  // b.hs, b.nlast
    c054:	d350fc22 	lsr	x2, x1, #16
    c058:	f949fc63 	ldr	x3, [x3, #5112]
    c05c:	8b020842 	add	x2, x2, x2, lsl #2
    c060:	d37df042 	lsl	x2, x2, #3
    c064:	8b020060 	add	x0, x3, x2
    c068:	f9401017 	ldr	x23, [x0, #32]
    c06c:	b4000257 	cbz	x23, c0b4 <f0+0x1444>
    c070:	38626862 	ldrb	w2, [x3, x2]
    c074:	7100085f 	cmp	w2, #0x2
    c078:	540078e0 	b.eq	cf94 <f0+0x2324>  // b.none
    c07c:	7100045f 	cmp	w2, #0x1
    c080:	540001a1 	b.ne	c0b4 <f0+0x1444>  // b.any
    c084:	29430002 	ldp	w2, w0, [x0, #24]
    c088:	92403c21 	and	x1, x1, #0xffff
    c08c:	9b027c21 	mul	x1, x1, x2
    c090:	d360fc21 	lsr	x1, x1, #32
    c094:	eb00003f 	cmp	x1, x0
    c098:	540000e2 	b.cs	c0b4 <f0+0x1444>  // b.hs, b.nlast
    c09c:	8b0102f7 	add	x23, x23, x1
    c0a0:	394002e0 	ldrb	w0, [x23]
    c0a4:	7103fc1f 	cmp	w0, #0xff
    c0a8:	54008c00 	b.eq	d228 <f0+0x25b8>  // b.none
    c0ac:	52800020 	mov	w0, #0x1                   	// #1
    c0b0:	390002e0 	strb	w0, [x23]
    c0b4:	911263e1 	add	x1, sp, #0x498
    c0b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c0bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c0c0:	52800020 	mov	w0, #0x1                   	// #1
    c0c4:	f9024ff7 	str	x23, [sp, #1176]
    c0c8:	f90253f5 	str	x21, [sp, #1184]
    c0cc:	97ffe706 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c0d0:	97ffe788 	bl	5ef0 <fwp_rc_fresh>
    c0d4:	aa0003e2 	mov	x2, x0
    c0d8:	9112a3e1 	add	x1, sp, #0x4a8
    c0dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c0e0:	52800020 	mov	w0, #0x1                   	// #1
    c0e4:	f90257f5 	str	x21, [sp, #1192]
    c0e8:	f9025be2 	str	x2, [sp, #1200]
    c0ec:	97ffe6fe 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c0f0:	97ffe780 	bl	5ef0 <fwp_rc_fresh>
    c0f4:	aa0003e2 	mov	x2, x0
    c0f8:	9112e3e1 	add	x1, sp, #0x4b8
    c0fc:	52800020 	mov	w0, #0x1                   	// #1
    c100:	f9025ff7 	str	x23, [sp, #1208]
    c104:	f90263e2 	str	x2, [sp, #1216]
    c108:	97ffe6f7 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c10c:	97ffe779 	bl	5ef0 <fwp_rc_fresh>
    c110:	aa0003e2 	mov	x2, x0
    c114:	911323e1 	add	x1, sp, #0x4c8
    c118:	52800020 	mov	w0, #0x1                   	// #1
    c11c:	f90267f5 	str	x21, [sp, #1224]
    c120:	f9026be2 	str	x2, [sp, #1232]
    c124:	97ffe6f0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c128:	91190283 	add	x3, x20, #0x640
    c12c:	aa0003f5 	mov	x21, x0
    c130:	f949d861 	ldr	x1, [x3, #5040]
    c134:	f949ec60 	ldr	x0, [x3, #5080]
    c138:	cb0102a1 	sub	x1, x21, x1
    c13c:	eb00403f 	cmp	x1, x0, lsl #16
    c140:	54000322 	b.cs	c1a4 <f0+0x1534>  // b.hs, b.nlast
    c144:	d350fc22 	lsr	x2, x1, #16
    c148:	f949fc63 	ldr	x3, [x3, #5112]
    c14c:	8b020842 	add	x2, x2, x2, lsl #2
    c150:	d37df042 	lsl	x2, x2, #3
    c154:	8b020060 	add	x0, x3, x2
    c158:	f9401017 	ldr	x23, [x0, #32]
    c15c:	b4000257 	cbz	x23, c1a4 <f0+0x1534>
    c160:	38626862 	ldrb	w2, [x3, x2]
    c164:	7100085f 	cmp	w2, #0x2
    c168:	54007100 	b.eq	cf88 <f0+0x2318>  // b.none
    c16c:	7100045f 	cmp	w2, #0x1
    c170:	540001a1 	b.ne	c1a4 <f0+0x1534>  // b.any
    c174:	29430002 	ldp	w2, w0, [x0, #24]
    c178:	92403c21 	and	x1, x1, #0xffff
    c17c:	9b027c21 	mul	x1, x1, x2
    c180:	d360fc21 	lsr	x1, x1, #32
    c184:	eb00003f 	cmp	x1, x0
    c188:	540000e2 	b.cs	c1a4 <f0+0x1534>  // b.hs, b.nlast
    c18c:	8b0102f7 	add	x23, x23, x1
    c190:	394002e0 	ldrb	w0, [x23]
    c194:	7103fc1f 	cmp	w0, #0xff
    c198:	540084e0 	b.eq	d234 <f0+0x25c4>  // b.none
    c19c:	52800020 	mov	w0, #0x1                   	// #1
    c1a0:	390002e0 	strb	w0, [x23]
    c1a4:	911363e1 	add	x1, sp, #0x4d8
    c1a8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c1ac:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c1b0:	52800020 	mov	w0, #0x1                   	// #1
    c1b4:	f9026ff7 	str	x23, [sp, #1240]
    c1b8:	f90273f5 	str	x21, [sp, #1248]
    c1bc:	97ffe6ca 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c1c0:	97ffe74c 	bl	5ef0 <fwp_rc_fresh>
    c1c4:	aa0003e2 	mov	x2, x0
    c1c8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c1cc:	9113a3e1 	add	x1, sp, #0x4e8
    c1d0:	52800020 	mov	w0, #0x1                   	// #1
    c1d4:	f90277e3 	str	x3, [sp, #1256]
    c1d8:	f9027be2 	str	x2, [sp, #1264]
    c1dc:	97ffe6c2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c1e0:	97ffe744 	bl	5ef0 <fwp_rc_fresh>
    c1e4:	aa0003e2 	mov	x2, x0
    c1e8:	9113e3e1 	add	x1, sp, #0x4f8
    c1ec:	52800020 	mov	w0, #0x1                   	// #1
    c1f0:	f9027ff7 	str	x23, [sp, #1272]
    c1f4:	f90283e2 	str	x2, [sp, #1280]
    c1f8:	97ffe6bb 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c1fc:	91190283 	add	x3, x20, #0x640
    c200:	aa0003f5 	mov	x21, x0
    c204:	f949d861 	ldr	x1, [x3, #5040]
    c208:	f949ec60 	ldr	x0, [x3, #5080]
    c20c:	cb0102a1 	sub	x1, x21, x1
    c210:	eb00403f 	cmp	x1, x0, lsl #16
    c214:	54000322 	b.cs	c278 <f0+0x1608>  // b.hs, b.nlast
    c218:	d350fc22 	lsr	x2, x1, #16
    c21c:	f949fc63 	ldr	x3, [x3, #5112]
    c220:	8b020842 	add	x2, x2, x2, lsl #2
    c224:	d37df042 	lsl	x2, x2, #3
    c228:	8b020060 	add	x0, x3, x2
    c22c:	f9401017 	ldr	x23, [x0, #32]
    c230:	b4000257 	cbz	x23, c278 <f0+0x1608>
    c234:	38626862 	ldrb	w2, [x3, x2]
    c238:	7100085f 	cmp	w2, #0x2
    c23c:	54006b80 	b.eq	cfac <f0+0x233c>  // b.none
    c240:	7100045f 	cmp	w2, #0x1
    c244:	540001a1 	b.ne	c278 <f0+0x1608>  // b.any
    c248:	29430002 	ldp	w2, w0, [x0, #24]
    c24c:	92403c21 	and	x1, x1, #0xffff
    c250:	9b027c21 	mul	x1, x1, x2
    c254:	d360fc21 	lsr	x1, x1, #32
    c258:	eb00003f 	cmp	x1, x0
    c25c:	540000e2 	b.cs	c278 <f0+0x1608>  // b.hs, b.nlast
    c260:	8b0102f7 	add	x23, x23, x1
    c264:	394002e0 	ldrb	w0, [x23]
    c268:	7103fc1f 	cmp	w0, #0xff
    c26c:	54007ea0 	b.eq	d240 <f0+0x25d0>  // b.none
    c270:	52800020 	mov	w0, #0x1                   	// #1
    c274:	390002e0 	strb	w0, [x23]
    c278:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c27c:	911423e1 	add	x1, sp, #0x508
    c280:	52800020 	mov	w0, #0x1                   	// #1
    c284:	f90287e2 	str	x2, [sp, #1288]
    c288:	f9028bf5 	str	x21, [sp, #1296]
    c28c:	97ffe696 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c290:	91190283 	add	x3, x20, #0x640
    c294:	aa0003f5 	mov	x21, x0
    c298:	f949d861 	ldr	x1, [x3, #5040]
    c29c:	f949ec60 	ldr	x0, [x3, #5080]
    c2a0:	cb0102a1 	sub	x1, x21, x1
    c2a4:	eb00403f 	cmp	x1, x0, lsl #16
    c2a8:	54000322 	b.cs	c30c <f0+0x169c>  // b.hs, b.nlast
    c2ac:	d350fc22 	lsr	x2, x1, #16
    c2b0:	f949fc63 	ldr	x3, [x3, #5112]
    c2b4:	8b020842 	add	x2, x2, x2, lsl #2
    c2b8:	d37df042 	lsl	x2, x2, #3
    c2bc:	8b020060 	add	x0, x3, x2
    c2c0:	f9401017 	ldr	x23, [x0, #32]
    c2c4:	b4000257 	cbz	x23, c30c <f0+0x169c>
    c2c8:	38626862 	ldrb	w2, [x3, x2]
    c2cc:	7100085f 	cmp	w2, #0x2
    c2d0:	54006680 	b.eq	cfa0 <f0+0x2330>  // b.none
    c2d4:	7100045f 	cmp	w2, #0x1
    c2d8:	540001a1 	b.ne	c30c <f0+0x169c>  // b.any
    c2dc:	29430002 	ldp	w2, w0, [x0, #24]
    c2e0:	92403c21 	and	x1, x1, #0xffff
    c2e4:	9b027c21 	mul	x1, x1, x2
    c2e8:	d360fc21 	lsr	x1, x1, #32
    c2ec:	eb00003f 	cmp	x1, x0
    c2f0:	540000e2 	b.cs	c30c <f0+0x169c>  // b.hs, b.nlast
    c2f4:	8b0102f7 	add	x23, x23, x1
    c2f8:	394002e0 	ldrb	w0, [x23]
    c2fc:	7103fc1f 	cmp	w0, #0xff
    c300:	54007a60 	b.eq	d24c <f0+0x25dc>  // b.none
    c304:	52800020 	mov	w0, #0x1                   	// #1
    c308:	390002e0 	strb	w0, [x23]
    c30c:	911463e1 	add	x1, sp, #0x518
    c310:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c314:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c318:	52800020 	mov	w0, #0x1                   	// #1
    c31c:	f9028ff7 	str	x23, [sp, #1304]
    c320:	f90293f5 	str	x21, [sp, #1312]
    c324:	97ffe670 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c328:	97ffe6f2 	bl	5ef0 <fwp_rc_fresh>
    c32c:	aa0003e2 	mov	x2, x0
    c330:	9114a3e1 	add	x1, sp, #0x528
    c334:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c338:	52800020 	mov	w0, #0x1                   	// #1
    c33c:	f90297f5 	str	x21, [sp, #1320]
    c340:	f9029be2 	str	x2, [sp, #1328]
    c344:	97ffe668 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c348:	97ffe6ea 	bl	5ef0 <fwp_rc_fresh>
    c34c:	aa0003e2 	mov	x2, x0
    c350:	9114e3e1 	add	x1, sp, #0x538
    c354:	52800020 	mov	w0, #0x1                   	// #1
    c358:	f9029ff7 	str	x23, [sp, #1336]
    c35c:	f902a3e2 	str	x2, [sp, #1344]
    c360:	97ffe661 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c364:	97ffe6e3 	bl	5ef0 <fwp_rc_fresh>
    c368:	aa0003e2 	mov	x2, x0
    c36c:	911523e1 	add	x1, sp, #0x548
    c370:	52800020 	mov	w0, #0x1                   	// #1
    c374:	f902a7f5 	str	x21, [sp, #1352]
    c378:	f902abe2 	str	x2, [sp, #1360]
    c37c:	97ffe65a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c380:	97ffe6dc 	bl	5ef0 <fwp_rc_fresh>
    c384:	aa0003e2 	mov	x2, x0
    c388:	911563e1 	add	x1, sp, #0x558
    c38c:	52800020 	mov	w0, #0x1                   	// #1
    c390:	f902aff7 	str	x23, [sp, #1368]
    c394:	f902b3e2 	str	x2, [sp, #1376]
    c398:	97ffe653 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c39c:	97ffe6d5 	bl	5ef0 <fwp_rc_fresh>
    c3a0:	aa0003e2 	mov	x2, x0
    c3a4:	9115a3e1 	add	x1, sp, #0x568
    c3a8:	52800020 	mov	w0, #0x1                   	// #1
    c3ac:	f902b7f5 	str	x21, [sp, #1384]
    c3b0:	f902bbe2 	str	x2, [sp, #1392]
    c3b4:	97ffe64c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c3b8:	97ffe6ce 	bl	5ef0 <fwp_rc_fresh>
    c3bc:	aa0003e2 	mov	x2, x0
    c3c0:	9115e3e1 	add	x1, sp, #0x578
    c3c4:	52800020 	mov	w0, #0x1                   	// #1
    c3c8:	f902bff7 	str	x23, [sp, #1400]
    c3cc:	f902c3e2 	str	x2, [sp, #1408]
    c3d0:	97ffe645 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c3d4:	97ffe6c7 	bl	5ef0 <fwp_rc_fresh>
    c3d8:	aa0003e2 	mov	x2, x0
    c3dc:	911623e1 	add	x1, sp, #0x588
    c3e0:	52800020 	mov	w0, #0x1                   	// #1
    c3e4:	f902c7f5 	str	x21, [sp, #1416]
    c3e8:	f902cbe2 	str	x2, [sp, #1424]
    c3ec:	97ffe63e 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c3f0:	97ffe6c0 	bl	5ef0 <fwp_rc_fresh>
    c3f4:	aa0003e2 	mov	x2, x0
    c3f8:	911663e1 	add	x1, sp, #0x598
    c3fc:	52800020 	mov	w0, #0x1                   	// #1
    c400:	f902cff7 	str	x23, [sp, #1432]
    c404:	f902d3e2 	str	x2, [sp, #1440]
    c408:	97ffe637 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c40c:	97ffe6b9 	bl	5ef0 <fwp_rc_fresh>
    c410:	aa0003e2 	mov	x2, x0
    c414:	9116a3e1 	add	x1, sp, #0x5a8
    c418:	52800020 	mov	w0, #0x1                   	// #1
    c41c:	f902d7f5 	str	x21, [sp, #1448]
    c420:	f902dbe2 	str	x2, [sp, #1456]
    c424:	97ffe630 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c428:	97ffe6b2 	bl	5ef0 <fwp_rc_fresh>
    c42c:	aa0003e2 	mov	x2, x0
    c430:	9116e3e1 	add	x1, sp, #0x5b8
    c434:	52800020 	mov	w0, #0x1                   	// #1
    c438:	f902dff7 	str	x23, [sp, #1464]
    c43c:	f902e3e2 	str	x2, [sp, #1472]
    c440:	97ffe629 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c444:	97ffe6ab 	bl	5ef0 <fwp_rc_fresh>
    c448:	aa0003e2 	mov	x2, x0
    c44c:	911723e1 	add	x1, sp, #0x5c8
    c450:	52800020 	mov	w0, #0x1                   	// #1
    c454:	f902e7f5 	str	x21, [sp, #1480]
    c458:	f902ebe2 	str	x2, [sp, #1488]
    c45c:	97ffe622 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c460:	91190283 	add	x3, x20, #0x640
    c464:	aa0003f5 	mov	x21, x0
    c468:	f949d861 	ldr	x1, [x3, #5040]
    c46c:	f949ec60 	ldr	x0, [x3, #5080]
    c470:	cb0102a1 	sub	x1, x21, x1
    c474:	eb00403f 	cmp	x1, x0, lsl #16
    c478:	54000322 	b.cs	c4dc <f0+0x186c>  // b.hs, b.nlast
    c47c:	d350fc22 	lsr	x2, x1, #16
    c480:	f949fc63 	ldr	x3, [x3, #5112]
    c484:	8b020842 	add	x2, x2, x2, lsl #2
    c488:	d37df042 	lsl	x2, x2, #3
    c48c:	8b020060 	add	x0, x3, x2
    c490:	f9401017 	ldr	x23, [x0, #32]
    c494:	b4000257 	cbz	x23, c4dc <f0+0x186c>
    c498:	38626862 	ldrb	w2, [x3, x2]
    c49c:	7100085f 	cmp	w2, #0x2
    c4a0:	54005920 	b.eq	cfc4 <f0+0x2354>  // b.none
    c4a4:	7100045f 	cmp	w2, #0x1
    c4a8:	540001a1 	b.ne	c4dc <f0+0x186c>  // b.any
    c4ac:	29430002 	ldp	w2, w0, [x0, #24]
    c4b0:	92403c21 	and	x1, x1, #0xffff
    c4b4:	9b027c21 	mul	x1, x1, x2
    c4b8:	d360fc21 	lsr	x1, x1, #32
    c4bc:	eb00003f 	cmp	x1, x0
    c4c0:	540000e2 	b.cs	c4dc <f0+0x186c>  // b.hs, b.nlast
    c4c4:	8b0102f7 	add	x23, x23, x1
    c4c8:	394002e0 	ldrb	w0, [x23]
    c4cc:	7103fc1f 	cmp	w0, #0xff
    c4d0:	54006c40 	b.eq	d258 <f0+0x25e8>  // b.none
    c4d4:	52800020 	mov	w0, #0x1                   	// #1
    c4d8:	390002e0 	strb	w0, [x23]
    c4dc:	911763e1 	add	x1, sp, #0x5d8
    c4e0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c4e4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c4e8:	52800020 	mov	w0, #0x1                   	// #1
    c4ec:	f902eff7 	str	x23, [sp, #1496]
    c4f0:	f902f3f5 	str	x21, [sp, #1504]
    c4f4:	97ffe5fc 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c4f8:	97ffe67e 	bl	5ef0 <fwp_rc_fresh>
    c4fc:	aa0003e2 	mov	x2, x0
    c500:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c504:	9117a3e1 	add	x1, sp, #0x5e8
    c508:	52800020 	mov	w0, #0x1                   	// #1
    c50c:	f902f7e3 	str	x3, [sp, #1512]
    c510:	f902fbe2 	str	x2, [sp, #1520]
    c514:	97ffe5f4 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c518:	97ffe676 	bl	5ef0 <fwp_rc_fresh>
    c51c:	aa0003e2 	mov	x2, x0
    c520:	9117e3e1 	add	x1, sp, #0x5f8
    c524:	52800020 	mov	w0, #0x1                   	// #1
    c528:	f902fff7 	str	x23, [sp, #1528]
    c52c:	f90303e2 	str	x2, [sp, #1536]
    c530:	97ffe5ed 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c534:	91190283 	add	x3, x20, #0x640
    c538:	aa0003f5 	mov	x21, x0
    c53c:	f949d861 	ldr	x1, [x3, #5040]
    c540:	f949ec60 	ldr	x0, [x3, #5080]
    c544:	cb0102a1 	sub	x1, x21, x1
    c548:	eb00403f 	cmp	x1, x0, lsl #16
    c54c:	54000322 	b.cs	c5b0 <f0+0x1940>  // b.hs, b.nlast
    c550:	d350fc22 	lsr	x2, x1, #16
    c554:	f949fc63 	ldr	x3, [x3, #5112]
    c558:	8b020842 	add	x2, x2, x2, lsl #2
    c55c:	d37df042 	lsl	x2, x2, #3
    c560:	8b020060 	add	x0, x3, x2
    c564:	f9401017 	ldr	x23, [x0, #32]
    c568:	b4000257 	cbz	x23, c5b0 <f0+0x1940>
    c56c:	38626862 	ldrb	w2, [x3, x2]
    c570:	7100085f 	cmp	w2, #0x2
    c574:	54005220 	b.eq	cfb8 <f0+0x2348>  // b.none
    c578:	7100045f 	cmp	w2, #0x1
    c57c:	540001a1 	b.ne	c5b0 <f0+0x1940>  // b.any
    c580:	29430002 	ldp	w2, w0, [x0, #24]
    c584:	92403c21 	and	x1, x1, #0xffff
    c588:	9b027c21 	mul	x1, x1, x2
    c58c:	d360fc21 	lsr	x1, x1, #32
    c590:	eb00003f 	cmp	x1, x0
    c594:	540000e2 	b.cs	c5b0 <f0+0x1940>  // b.hs, b.nlast
    c598:	8b0102f7 	add	x23, x23, x1
    c59c:	394002e0 	ldrb	w0, [x23]
    c5a0:	7103fc1f 	cmp	w0, #0xff
    c5a4:	54006600 	b.eq	d264 <f0+0x25f4>  // b.none
    c5a8:	52800020 	mov	w0, #0x1                   	// #1
    c5ac:	390002e0 	strb	w0, [x23]
    c5b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c5b4:	911823e1 	add	x1, sp, #0x608
    c5b8:	52800020 	mov	w0, #0x1                   	// #1
    c5bc:	f90307e2 	str	x2, [sp, #1544]
    c5c0:	f9030bf5 	str	x21, [sp, #1552]
    c5c4:	97ffe5c8 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c5c8:	91190283 	add	x3, x20, #0x640
    c5cc:	aa0003f7 	mov	x23, x0
    c5d0:	f949d861 	ldr	x1, [x3, #5040]
    c5d4:	f949ec60 	ldr	x0, [x3, #5080]
    c5d8:	cb0102e1 	sub	x1, x23, x1
    c5dc:	eb00403f 	cmp	x1, x0, lsl #16
    c5e0:	54000322 	b.cs	c644 <f0+0x19d4>  // b.hs, b.nlast
    c5e4:	d350fc22 	lsr	x2, x1, #16
    c5e8:	f949fc63 	ldr	x3, [x3, #5112]
    c5ec:	8b020842 	add	x2, x2, x2, lsl #2
    c5f0:	d37df042 	lsl	x2, x2, #3
    c5f4:	8b020060 	add	x0, x3, x2
    c5f8:	f9401015 	ldr	x21, [x0, #32]
    c5fc:	b4000255 	cbz	x21, c644 <f0+0x19d4>
    c600:	38626862 	ldrb	w2, [x3, x2]
    c604:	7100085f 	cmp	w2, #0x2
    c608:	54004ea0 	b.eq	cfdc <f0+0x236c>  // b.none
    c60c:	7100045f 	cmp	w2, #0x1
    c610:	540001a1 	b.ne	c644 <f0+0x19d4>  // b.any
    c614:	29430002 	ldp	w2, w0, [x0, #24]
    c618:	92403c21 	and	x1, x1, #0xffff
    c61c:	9b027c21 	mul	x1, x1, x2
    c620:	d360fc21 	lsr	x1, x1, #32
    c624:	eb00003f 	cmp	x1, x0
    c628:	540000e2 	b.cs	c644 <f0+0x19d4>  // b.hs, b.nlast
    c62c:	8b0102b5 	add	x21, x21, x1
    c630:	394002a0 	ldrb	w0, [x21]
    c634:	7103fc1f 	cmp	w0, #0xff
    c638:	540061c0 	b.eq	d270 <f0+0x2600>  // b.none
    c63c:	52800020 	mov	w0, #0x1                   	// #1
    c640:	390002a0 	strb	w0, [x21]
    c644:	911863e1 	add	x1, sp, #0x618
    c648:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c64c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c650:	52800020 	mov	w0, #0x1                   	// #1
    c654:	f9030ff5 	str	x21, [sp, #1560]
    c658:	f90313f7 	str	x23, [sp, #1568]
    c65c:	97ffe5a2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c660:	97ffe624 	bl	5ef0 <fwp_rc_fresh>
    c664:	aa0003e2 	mov	x2, x0
    c668:	9118a3e1 	add	x1, sp, #0x628
    c66c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c670:	52800020 	mov	w0, #0x1                   	// #1
    c674:	f90317f7 	str	x23, [sp, #1576]
    c678:	f9031be2 	str	x2, [sp, #1584]
    c67c:	97ffe59a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c680:	97ffe61c 	bl	5ef0 <fwp_rc_fresh>
    c684:	aa0003e2 	mov	x2, x0
    c688:	9118e3e1 	add	x1, sp, #0x638
    c68c:	52800020 	mov	w0, #0x1                   	// #1
    c690:	f9031ff5 	str	x21, [sp, #1592]
    c694:	f90323e2 	str	x2, [sp, #1600]
    c698:	97ffe593 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c69c:	97ffe615 	bl	5ef0 <fwp_rc_fresh>
    c6a0:	aa0003e2 	mov	x2, x0
    c6a4:	911923e1 	add	x1, sp, #0x648
    c6a8:	52800020 	mov	w0, #0x1                   	// #1
    c6ac:	f90327f7 	str	x23, [sp, #1608]
    c6b0:	f9032be2 	str	x2, [sp, #1616]
    c6b4:	97ffe58c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c6b8:	97ffe60e 	bl	5ef0 <fwp_rc_fresh>
    c6bc:	aa0003e2 	mov	x2, x0
    c6c0:	911963e1 	add	x1, sp, #0x658
    c6c4:	52800020 	mov	w0, #0x1                   	// #1
    c6c8:	f9032ff5 	str	x21, [sp, #1624]
    c6cc:	f90333e2 	str	x2, [sp, #1632]
    c6d0:	97ffe585 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c6d4:	97ffe607 	bl	5ef0 <fwp_rc_fresh>
    c6d8:	aa0003e2 	mov	x2, x0
    c6dc:	9119a3e1 	add	x1, sp, #0x668
    c6e0:	52800020 	mov	w0, #0x1                   	// #1
    c6e4:	f90337f7 	str	x23, [sp, #1640]
    c6e8:	f9033be2 	str	x2, [sp, #1648]
    c6ec:	97ffe57e 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c6f0:	97ffe600 	bl	5ef0 <fwp_rc_fresh>
    c6f4:	aa0003e2 	mov	x2, x0
    c6f8:	9119e3e1 	add	x1, sp, #0x678
    c6fc:	52800020 	mov	w0, #0x1                   	// #1
    c700:	f9033ff5 	str	x21, [sp, #1656]
    c704:	f90343e2 	str	x2, [sp, #1664]
    c708:	97ffe577 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c70c:	91190283 	add	x3, x20, #0x640
    c710:	aa0003f5 	mov	x21, x0
    c714:	f949d861 	ldr	x1, [x3, #5040]
    c718:	f949ec60 	ldr	x0, [x3, #5080]
    c71c:	cb0102a1 	sub	x1, x21, x1
    c720:	eb00403f 	cmp	x1, x0, lsl #16
    c724:	54000322 	b.cs	c788 <f0+0x1b18>  // b.hs, b.nlast
    c728:	d350fc22 	lsr	x2, x1, #16
    c72c:	f949fc63 	ldr	x3, [x3, #5112]
    c730:	8b020842 	add	x2, x2, x2, lsl #2
    c734:	d37df042 	lsl	x2, x2, #3
    c738:	8b020060 	add	x0, x3, x2
    c73c:	f9401017 	ldr	x23, [x0, #32]
    c740:	b4000257 	cbz	x23, c788 <f0+0x1b18>
    c744:	38626862 	ldrb	w2, [x3, x2]
    c748:	7100085f 	cmp	w2, #0x2
    c74c:	54004420 	b.eq	cfd0 <f0+0x2360>  // b.none
    c750:	7100045f 	cmp	w2, #0x1
    c754:	540001a1 	b.ne	c788 <f0+0x1b18>  // b.any
    c758:	29430002 	ldp	w2, w0, [x0, #24]
    c75c:	92403c21 	and	x1, x1, #0xffff
    c760:	9b027c21 	mul	x1, x1, x2
    c764:	d360fc21 	lsr	x1, x1, #32
    c768:	eb00003f 	cmp	x1, x0
    c76c:	540000e2 	b.cs	c788 <f0+0x1b18>  // b.hs, b.nlast
    c770:	8b0102f7 	add	x23, x23, x1
    c774:	394002e0 	ldrb	w0, [x23]
    c778:	7103fc1f 	cmp	w0, #0xff
    c77c:	54005800 	b.eq	d27c <f0+0x260c>  // b.none
    c780:	52800020 	mov	w0, #0x1                   	// #1
    c784:	390002e0 	strb	w0, [x23]
    c788:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c78c:	911a23e1 	add	x1, sp, #0x688
    c790:	52800020 	mov	w0, #0x1                   	// #1
    c794:	f90347e2 	str	x2, [sp, #1672]
    c798:	f9034bf5 	str	x21, [sp, #1680]
    c79c:	97ffe552 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c7a0:	91190283 	add	x3, x20, #0x640
    c7a4:	aa0003f5 	mov	x21, x0
    c7a8:	f949d861 	ldr	x1, [x3, #5040]
    c7ac:	f949ec60 	ldr	x0, [x3, #5080]
    c7b0:	cb0102a1 	sub	x1, x21, x1
    c7b4:	eb00403f 	cmp	x1, x0, lsl #16
    c7b8:	54000322 	b.cs	c81c <f0+0x1bac>  // b.hs, b.nlast
    c7bc:	d350fc22 	lsr	x2, x1, #16
    c7c0:	f949fc63 	ldr	x3, [x3, #5112]
    c7c4:	8b020842 	add	x2, x2, x2, lsl #2
    c7c8:	d37df042 	lsl	x2, x2, #3
    c7cc:	8b020060 	add	x0, x3, x2
    c7d0:	f9401017 	ldr	x23, [x0, #32]
    c7d4:	b4000257 	cbz	x23, c81c <f0+0x1bac>
    c7d8:	38626862 	ldrb	w2, [x3, x2]
    c7dc:	7100085f 	cmp	w2, #0x2
    c7e0:	540040a0 	b.eq	cff4 <f0+0x2384>  // b.none
    c7e4:	7100045f 	cmp	w2, #0x1
    c7e8:	540001a1 	b.ne	c81c <f0+0x1bac>  // b.any
    c7ec:	29430002 	ldp	w2, w0, [x0, #24]
    c7f0:	92403c21 	and	x1, x1, #0xffff
    c7f4:	9b027c21 	mul	x1, x1, x2
    c7f8:	d360fc21 	lsr	x1, x1, #32
    c7fc:	eb00003f 	cmp	x1, x0
    c800:	540000e2 	b.cs	c81c <f0+0x1bac>  // b.hs, b.nlast
    c804:	8b0102f7 	add	x23, x23, x1
    c808:	394002e0 	ldrb	w0, [x23]
    c80c:	7103fc1f 	cmp	w0, #0xff
    c810:	540053c0 	b.eq	d288 <f0+0x2618>  // b.none
    c814:	52800020 	mov	w0, #0x1                   	// #1
    c818:	390002e0 	strb	w0, [x23]
    c81c:	911a63e1 	add	x1, sp, #0x698
    c820:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c824:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c828:	52800020 	mov	w0, #0x1                   	// #1
    c82c:	f9034ff7 	str	x23, [sp, #1688]
    c830:	f90353f5 	str	x21, [sp, #1696]
    c834:	97ffe52c 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c838:	97ffe5ae 	bl	5ef0 <fwp_rc_fresh>
    c83c:	aa0003e2 	mov	x2, x0
    c840:	911aa3e1 	add	x1, sp, #0x6a8
    c844:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c848:	52800020 	mov	w0, #0x1                   	// #1
    c84c:	f90357f5 	str	x21, [sp, #1704]
    c850:	f9035be2 	str	x2, [sp, #1712]
    c854:	97ffe524 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c858:	97ffe5a6 	bl	5ef0 <fwp_rc_fresh>
    c85c:	aa0003e2 	mov	x2, x0
    c860:	911ae3e1 	add	x1, sp, #0x6b8
    c864:	52800020 	mov	w0, #0x1                   	// #1
    c868:	f9035ff7 	str	x23, [sp, #1720]
    c86c:	f90363e2 	str	x2, [sp, #1728]
    c870:	97ffe51d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c874:	97ffe59f 	bl	5ef0 <fwp_rc_fresh>
    c878:	aa0003e2 	mov	x2, x0
    c87c:	911b23e1 	add	x1, sp, #0x6c8
    c880:	52800020 	mov	w0, #0x1                   	// #1
    c884:	f90367f5 	str	x21, [sp, #1736]
    c888:	f9036be2 	str	x2, [sp, #1744]
    c88c:	97ffe516 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c890:	91190283 	add	x3, x20, #0x640
    c894:	aa0003f5 	mov	x21, x0
    c898:	f949d861 	ldr	x1, [x3, #5040]
    c89c:	f949ec60 	ldr	x0, [x3, #5080]
    c8a0:	cb0102a1 	sub	x1, x21, x1
    c8a4:	eb00403f 	cmp	x1, x0, lsl #16
    c8a8:	54000322 	b.cs	c90c <f0+0x1c9c>  // b.hs, b.nlast
    c8ac:	d350fc22 	lsr	x2, x1, #16
    c8b0:	f949fc63 	ldr	x3, [x3, #5112]
    c8b4:	8b020842 	add	x2, x2, x2, lsl #2
    c8b8:	d37df042 	lsl	x2, x2, #3
    c8bc:	8b020060 	add	x0, x3, x2
    c8c0:	f9401017 	ldr	x23, [x0, #32]
    c8c4:	b4000257 	cbz	x23, c90c <f0+0x1c9c>
    c8c8:	38626862 	ldrb	w2, [x3, x2]
    c8cc:	7100085f 	cmp	w2, #0x2
    c8d0:	540038c0 	b.eq	cfe8 <f0+0x2378>  // b.none
    c8d4:	7100045f 	cmp	w2, #0x1
    c8d8:	540001a1 	b.ne	c90c <f0+0x1c9c>  // b.any
    c8dc:	29430002 	ldp	w2, w0, [x0, #24]
    c8e0:	92403c21 	and	x1, x1, #0xffff
    c8e4:	9b027c21 	mul	x1, x1, x2
    c8e8:	d360fc21 	lsr	x1, x1, #32
    c8ec:	eb00003f 	cmp	x1, x0
    c8f0:	540000e2 	b.cs	c90c <f0+0x1c9c>  // b.hs, b.nlast
    c8f4:	8b0102f7 	add	x23, x23, x1
    c8f8:	394002e0 	ldrb	w0, [x23]
    c8fc:	7103fc1f 	cmp	w0, #0xff
    c900:	54004ca0 	b.eq	d294 <f0+0x2624>  // b.none
    c904:	52800020 	mov	w0, #0x1                   	// #1
    c908:	390002e0 	strb	w0, [x23]
    c90c:	911b63e1 	add	x1, sp, #0x6d8
    c910:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c914:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c918:	52800020 	mov	w0, #0x1                   	// #1
    c91c:	f9036ff7 	str	x23, [sp, #1752]
    c920:	f90373f5 	str	x21, [sp, #1760]
    c924:	97ffe4f0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c928:	97ffe572 	bl	5ef0 <fwp_rc_fresh>
    c92c:	aa0003e2 	mov	x2, x0
    c930:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c934:	911ba3e1 	add	x1, sp, #0x6e8
    c938:	52800020 	mov	w0, #0x1                   	// #1
    c93c:	f90377e3 	str	x3, [sp, #1768]
    c940:	f9037be2 	str	x2, [sp, #1776]
    c944:	97ffe4e8 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c948:	97ffe56a 	bl	5ef0 <fwp_rc_fresh>
    c94c:	aa0003e2 	mov	x2, x0
    c950:	911be3e1 	add	x1, sp, #0x6f8
    c954:	52800020 	mov	w0, #0x1                   	// #1
    c958:	f9037ff7 	str	x23, [sp, #1784]
    c95c:	f90383e2 	str	x2, [sp, #1792]
    c960:	97ffe4e1 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c964:	91190283 	add	x3, x20, #0x640
    c968:	aa0003f5 	mov	x21, x0
    c96c:	f949d861 	ldr	x1, [x3, #5040]
    c970:	f949ec60 	ldr	x0, [x3, #5080]
    c974:	cb0102a1 	sub	x1, x21, x1
    c978:	eb00403f 	cmp	x1, x0, lsl #16
    c97c:	54000322 	b.cs	c9e0 <f0+0x1d70>  // b.hs, b.nlast
    c980:	d350fc22 	lsr	x2, x1, #16
    c984:	f949fc63 	ldr	x3, [x3, #5112]
    c988:	8b020842 	add	x2, x2, x2, lsl #2
    c98c:	d37df042 	lsl	x2, x2, #3
    c990:	8b020060 	add	x0, x3, x2
    c994:	f9401017 	ldr	x23, [x0, #32]
    c998:	b4000257 	cbz	x23, c9e0 <f0+0x1d70>
    c99c:	38626862 	ldrb	w2, [x3, x2]
    c9a0:	7100085f 	cmp	w2, #0x2
    c9a4:	54003340 	b.eq	d00c <f0+0x239c>  // b.none
    c9a8:	7100045f 	cmp	w2, #0x1
    c9ac:	540001a1 	b.ne	c9e0 <f0+0x1d70>  // b.any
    c9b0:	29430002 	ldp	w2, w0, [x0, #24]
    c9b4:	92403c21 	and	x1, x1, #0xffff
    c9b8:	9b027c21 	mul	x1, x1, x2
    c9bc:	d360fc21 	lsr	x1, x1, #32
    c9c0:	eb00003f 	cmp	x1, x0
    c9c4:	540000e2 	b.cs	c9e0 <f0+0x1d70>  // b.hs, b.nlast
    c9c8:	8b0102f7 	add	x23, x23, x1
    c9cc:	394002e0 	ldrb	w0, [x23]
    c9d0:	7103fc1f 	cmp	w0, #0xff
    c9d4:	54004660 	b.eq	d2a0 <f0+0x2630>  // b.none
    c9d8:	52800020 	mov	w0, #0x1                   	// #1
    c9dc:	390002e0 	strb	w0, [x23]
    c9e0:	911c23e1 	add	x1, sp, #0x708
    c9e4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c9e8:	52800020 	mov	w0, #0x1                   	// #1
    c9ec:	f90387f7 	str	x23, [sp, #1800]
    c9f0:	f9038bf5 	str	x21, [sp, #1808]
    c9f4:	97ffe4bc 	bl	5ce4 <fwp_data.part.0.constprop.0>
    c9f8:	97ffe53e 	bl	5ef0 <fwp_rc_fresh>
    c9fc:	aa0003e2 	mov	x2, x0
    ca00:	911c63e1 	add	x1, sp, #0x718
    ca04:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ca08:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ca0c:	52800020 	mov	w0, #0x1                   	// #1
    ca10:	f9038ff5 	str	x21, [sp, #1816]
    ca14:	f90393e2 	str	x2, [sp, #1824]
    ca18:	97ffe4b3 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ca1c:	97ffe535 	bl	5ef0 <fwp_rc_fresh>
    ca20:	aa0003e2 	mov	x2, x0
    ca24:	911ca3e1 	add	x1, sp, #0x728
    ca28:	52800020 	mov	w0, #0x1                   	// #1
    ca2c:	f90397f7 	str	x23, [sp, #1832]
    ca30:	f9039be2 	str	x2, [sp, #1840]
    ca34:	97ffe4ac 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ca38:	97ffe52e 	bl	5ef0 <fwp_rc_fresh>
    ca3c:	aa0003e2 	mov	x2, x0
    ca40:	911ce3e1 	add	x1, sp, #0x738
    ca44:	52800020 	mov	w0, #0x1                   	// #1
    ca48:	f9039ff5 	str	x21, [sp, #1848]
    ca4c:	f903a3e2 	str	x2, [sp, #1856]
    ca50:	97ffe4a5 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ca54:	97ffe527 	bl	5ef0 <fwp_rc_fresh>
    ca58:	aa0003e2 	mov	x2, x0
    ca5c:	911d23e1 	add	x1, sp, #0x748
    ca60:	52800020 	mov	w0, #0x1                   	// #1
    ca64:	f903a7f7 	str	x23, [sp, #1864]
    ca68:	f903abe2 	str	x2, [sp, #1872]
    ca6c:	97ffe49e 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ca70:	97ffe520 	bl	5ef0 <fwp_rc_fresh>
    ca74:	aa0003e2 	mov	x2, x0
    ca78:	911d63e1 	add	x1, sp, #0x758
    ca7c:	52800020 	mov	w0, #0x1                   	// #1
    ca80:	f903aff5 	str	x21, [sp, #1880]
    ca84:	f903b3e2 	str	x2, [sp, #1888]
    ca88:	97ffe497 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ca8c:	97ffe519 	bl	5ef0 <fwp_rc_fresh>
    ca90:	aa0003e2 	mov	x2, x0
    ca94:	911da3e1 	add	x1, sp, #0x768
    ca98:	52800020 	mov	w0, #0x1                   	// #1
    ca9c:	f903b7f7 	str	x23, [sp, #1896]
    caa0:	f903bbe2 	str	x2, [sp, #1904]
    caa4:	97ffe490 	bl	5ce4 <fwp_data.part.0.constprop.0>
    caa8:	97ffe512 	bl	5ef0 <fwp_rc_fresh>
    caac:	aa0003e2 	mov	x2, x0
    cab0:	911de3e1 	add	x1, sp, #0x778
    cab4:	52800020 	mov	w0, #0x1                   	// #1
    cab8:	f903bff5 	str	x21, [sp, #1912]
    cabc:	f903c3e2 	str	x2, [sp, #1920]
    cac0:	97ffe489 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cac4:	97ffe50b 	bl	5ef0 <fwp_rc_fresh>
    cac8:	aa0003e2 	mov	x2, x0
    cacc:	911e23e1 	add	x1, sp, #0x788
    cad0:	52800020 	mov	w0, #0x1                   	// #1
    cad4:	f903c7f7 	str	x23, [sp, #1928]
    cad8:	f903cbe2 	str	x2, [sp, #1936]
    cadc:	97ffe482 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cae0:	97ffe504 	bl	5ef0 <fwp_rc_fresh>
    cae4:	aa0003e2 	mov	x2, x0
    cae8:	911e63e1 	add	x1, sp, #0x798
    caec:	52800020 	mov	w0, #0x1                   	// #1
    caf0:	f903cff5 	str	x21, [sp, #1944]
    caf4:	f903d3e2 	str	x2, [sp, #1952]
    caf8:	97ffe47b 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cafc:	91190283 	add	x3, x20, #0x640
    cb00:	aa0003f5 	mov	x21, x0
    cb04:	f949d861 	ldr	x1, [x3, #5040]
    cb08:	f949ec60 	ldr	x0, [x3, #5080]
    cb0c:	cb0102a1 	sub	x1, x21, x1
    cb10:	eb00403f 	cmp	x1, x0, lsl #16
    cb14:	54000322 	b.cs	cb78 <f0+0x1f08>  // b.hs, b.nlast
    cb18:	d350fc22 	lsr	x2, x1, #16
    cb1c:	f949fc63 	ldr	x3, [x3, #5112]
    cb20:	8b020842 	add	x2, x2, x2, lsl #2
    cb24:	d37df042 	lsl	x2, x2, #3
    cb28:	8b020060 	add	x0, x3, x2
    cb2c:	f9401017 	ldr	x23, [x0, #32]
    cb30:	b4000257 	cbz	x23, cb78 <f0+0x1f08>
    cb34:	38626862 	ldrb	w2, [x3, x2]
    cb38:	7100085f 	cmp	w2, #0x2
    cb3c:	54002620 	b.eq	d000 <f0+0x2390>  // b.none
    cb40:	7100045f 	cmp	w2, #0x1
    cb44:	540001a1 	b.ne	cb78 <f0+0x1f08>  // b.any
    cb48:	29430002 	ldp	w2, w0, [x0, #24]
    cb4c:	92403c21 	and	x1, x1, #0xffff
    cb50:	9b027c21 	mul	x1, x1, x2
    cb54:	d360fc21 	lsr	x1, x1, #32
    cb58:	eb00003f 	cmp	x1, x0
    cb5c:	540000e2 	b.cs	cb78 <f0+0x1f08>  // b.hs, b.nlast
    cb60:	8b0102f7 	add	x23, x23, x1
    cb64:	394002e0 	ldrb	w0, [x23]
    cb68:	7103fc1f 	cmp	w0, #0xff
    cb6c:	54003a00 	b.eq	d2ac <f0+0x263c>  // b.none
    cb70:	52800020 	mov	w0, #0x1                   	// #1
    cb74:	390002e0 	strb	w0, [x23]
    cb78:	911ea3e1 	add	x1, sp, #0x7a8
    cb7c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    cb80:	52800020 	mov	w0, #0x1                   	// #1
    cb84:	f903d7f7 	str	x23, [sp, #1960]
    cb88:	f903dbf5 	str	x21, [sp, #1968]
    cb8c:	97ffe456 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cb90:	97ffe4d8 	bl	5ef0 <fwp_rc_fresh>
    cb94:	aa0003e2 	mov	x2, x0
    cb98:	911ee3e1 	add	x1, sp, #0x7b8
    cb9c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    cba0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    cba4:	52800020 	mov	w0, #0x1                   	// #1
    cba8:	f903dff5 	str	x21, [sp, #1976]
    cbac:	f903e3e2 	str	x2, [sp, #1984]
    cbb0:	97ffe44d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cbb4:	97ffe4cf 	bl	5ef0 <fwp_rc_fresh>
    cbb8:	aa0003e2 	mov	x2, x0
    cbbc:	911f23e1 	add	x1, sp, #0x7c8
    cbc0:	52800020 	mov	w0, #0x1                   	// #1
    cbc4:	f903e7f7 	str	x23, [sp, #1992]
    cbc8:	f903ebe2 	str	x2, [sp, #2000]
    cbcc:	97ffe446 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cbd0:	97ffe4c8 	bl	5ef0 <fwp_rc_fresh>
    cbd4:	aa0003e2 	mov	x2, x0
    cbd8:	911f63e1 	add	x1, sp, #0x7d8
    cbdc:	52800020 	mov	w0, #0x1                   	// #1
    cbe0:	f903eff5 	str	x21, [sp, #2008]
    cbe4:	f903f3e2 	str	x2, [sp, #2016]
    cbe8:	97ffe43f 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cbec:	91190283 	add	x3, x20, #0x640
    cbf0:	aa0003f5 	mov	x21, x0
    cbf4:	f949d861 	ldr	x1, [x3, #5040]
    cbf8:	f949ec60 	ldr	x0, [x3, #5080]
    cbfc:	cb0102a1 	sub	x1, x21, x1
    cc00:	eb00403f 	cmp	x1, x0, lsl #16
    cc04:	54000322 	b.cs	cc68 <f0+0x1ff8>  // b.hs, b.nlast
    cc08:	d350fc22 	lsr	x2, x1, #16
    cc0c:	f949fc63 	ldr	x3, [x3, #5112]
    cc10:	8b020842 	add	x2, x2, x2, lsl #2
    cc14:	d37df042 	lsl	x2, x2, #3
    cc18:	8b020060 	add	x0, x3, x2
    cc1c:	f9401017 	ldr	x23, [x0, #32]
    cc20:	b4000257 	cbz	x23, cc68 <f0+0x1ff8>
    cc24:	38626862 	ldrb	w2, [x3, x2]
    cc28:	7100085f 	cmp	w2, #0x2
    cc2c:	54001fc0 	b.eq	d024 <f0+0x23b4>  // b.none
    cc30:	7100045f 	cmp	w2, #0x1
    cc34:	540001a1 	b.ne	cc68 <f0+0x1ff8>  // b.any
    cc38:	29430002 	ldp	w2, w0, [x0, #24]
    cc3c:	92403c21 	and	x1, x1, #0xffff
    cc40:	9b027c21 	mul	x1, x1, x2
    cc44:	d360fc21 	lsr	x1, x1, #32
    cc48:	eb00003f 	cmp	x1, x0
    cc4c:	540000e2 	b.cs	cc68 <f0+0x1ff8>  // b.hs, b.nlast
    cc50:	8b0102f7 	add	x23, x23, x1
    cc54:	394002e0 	ldrb	w0, [x23]
    cc58:	7103fc1f 	cmp	w0, #0xff
    cc5c:	540032e0 	b.eq	d2b8 <f0+0x2648>  // b.none
    cc60:	52800020 	mov	w0, #0x1                   	// #1
    cc64:	390002e0 	strb	w0, [x23]
    cc68:	911fa3e1 	add	x1, sp, #0x7e8
    cc6c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    cc70:	52800020 	mov	w0, #0x1                   	// #1
    cc74:	f903f7f7 	str	x23, [sp, #2024]
    cc78:	f903fbf5 	str	x21, [sp, #2032]
    cc7c:	97ffe41a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cc80:	97ffe49c 	bl	5ef0 <fwp_rc_fresh>
    cc84:	aa0003e2 	mov	x2, x0
    cc88:	911fe3e1 	add	x1, sp, #0x7f8
    cc8c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    cc90:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    cc94:	52800020 	mov	w0, #0x1                   	// #1
    cc98:	f903fff5 	str	x21, [sp, #2040]
    cc9c:	f90403e2 	str	x2, [sp, #2048]
    cca0:	97ffe411 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cca4:	97ffe493 	bl	5ef0 <fwp_rc_fresh>
    cca8:	aa0003e2 	mov	x2, x0
    ccac:	912023e1 	add	x1, sp, #0x808
    ccb0:	52800020 	mov	w0, #0x1                   	// #1
    ccb4:	f90407f7 	str	x23, [sp, #2056]
    ccb8:	f9040be2 	str	x2, [sp, #2064]
    ccbc:	97ffe40a 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ccc0:	97ffe48c 	bl	5ef0 <fwp_rc_fresh>
    ccc4:	aa0003e2 	mov	x2, x0
    ccc8:	912063e1 	add	x1, sp, #0x818
    cccc:	52800020 	mov	w0, #0x1                   	// #1
    ccd0:	f9040ff5 	str	x21, [sp, #2072]
    ccd4:	f90413e2 	str	x2, [sp, #2080]
    ccd8:	97ffe403 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ccdc:	97ffe485 	bl	5ef0 <fwp_rc_fresh>
    cce0:	aa0003e2 	mov	x2, x0
    cce4:	9120a3e1 	add	x1, sp, #0x828
    cce8:	52800020 	mov	w0, #0x1                   	// #1
    ccec:	f90417f7 	str	x23, [sp, #2088]
    ccf0:	f9041be2 	str	x2, [sp, #2096]
    ccf4:	97ffe3fc 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ccf8:	97ffe47e 	bl	5ef0 <fwp_rc_fresh>
    ccfc:	aa0003e2 	mov	x2, x0
    cd00:	9120e3e1 	add	x1, sp, #0x838
    cd04:	52800020 	mov	w0, #0x1                   	// #1
    cd08:	f9041ff5 	str	x21, [sp, #2104]
    cd0c:	f90423e2 	str	x2, [sp, #2112]
    cd10:	97ffe3f5 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cd14:	91190283 	add	x3, x20, #0x640
    cd18:	aa0003f5 	mov	x21, x0
    cd1c:	f949d861 	ldr	x1, [x3, #5040]
    cd20:	f949ec60 	ldr	x0, [x3, #5080]
    cd24:	cb0102a1 	sub	x1, x21, x1
    cd28:	eb00403f 	cmp	x1, x0, lsl #16
    cd2c:	54000322 	b.cs	cd90 <f0+0x2120>  // b.hs, b.nlast
    cd30:	d350fc22 	lsr	x2, x1, #16
    cd34:	f949fc63 	ldr	x3, [x3, #5112]
    cd38:	8b020842 	add	x2, x2, x2, lsl #2
    cd3c:	d37df042 	lsl	x2, x2, #3
    cd40:	8b020060 	add	x0, x3, x2
    cd44:	f9401017 	ldr	x23, [x0, #32]
    cd48:	b4000257 	cbz	x23, cd90 <f0+0x2120>
    cd4c:	38626862 	ldrb	w2, [x3, x2]
    cd50:	7100085f 	cmp	w2, #0x2
    cd54:	54001620 	b.eq	d018 <f0+0x23a8>  // b.none
    cd58:	7100045f 	cmp	w2, #0x1
    cd5c:	540001a1 	b.ne	cd90 <f0+0x2120>  // b.any
    cd60:	29430002 	ldp	w2, w0, [x0, #24]
    cd64:	92403c21 	and	x1, x1, #0xffff
    cd68:	9b027c21 	mul	x1, x1, x2
    cd6c:	d360fc21 	lsr	x1, x1, #32
    cd70:	eb00003f 	cmp	x1, x0
    cd74:	540000e2 	b.cs	cd90 <f0+0x2120>  // b.hs, b.nlast
    cd78:	8b0102f7 	add	x23, x23, x1
    cd7c:	394002e0 	ldrb	w0, [x23]
    cd80:	7103fc1f 	cmp	w0, #0xff
    cd84:	54002a00 	b.eq	d2c4 <f0+0x2654>  // b.none
    cd88:	52800020 	mov	w0, #0x1                   	// #1
    cd8c:	390002e0 	strb	w0, [x23]
    cd90:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    cd94:	912123e1 	add	x1, sp, #0x848
    cd98:	52800020 	mov	w0, #0x1                   	// #1
    cd9c:	f90427e2 	str	x2, [sp, #2120]
    cda0:	f9042bf5 	str	x21, [sp, #2128]
    cda4:	97ffe3d0 	bl	5ce4 <fwp_data.part.0.constprop.0>
    cda8:	91190283 	add	x3, x20, #0x640
    cdac:	aa0003f5 	mov	x21, x0
    cdb0:	f949d861 	ldr	x1, [x3, #5040]
    cdb4:	f949ec60 	ldr	x0, [x3, #5080]
    cdb8:	cb0102a1 	sub	x1, x21, x1
    cdbc:	eb00403f 	cmp	x1, x0, lsl #16
    cdc0:	54000322 	b.cs	ce24 <f0+0x21b4>  // b.hs, b.nlast
    cdc4:	d350fc22 	lsr	x2, x1, #16
    cdc8:	f949fc63 	ldr	x3, [x3, #5112]
    cdcc:	8b020842 	add	x2, x2, x2, lsl #2
    cdd0:	d37df042 	lsl	x2, x2, #3
    cdd4:	8b020060 	add	x0, x3, x2
    cdd8:	f9401017 	ldr	x23, [x0, #32]
    cddc:	b4000257 	cbz	x23, ce24 <f0+0x21b4>
    cde0:	38626862 	ldrb	w2, [x3, x2]
    cde4:	7100085f 	cmp	w2, #0x2
    cde8:	540012a0 	b.eq	d03c <f0+0x23cc>  // b.none
    cdec:	7100045f 	cmp	w2, #0x1
    cdf0:	540001a1 	b.ne	ce24 <f0+0x21b4>  // b.any
    cdf4:	29430002 	ldp	w2, w0, [x0, #24]
    cdf8:	92403c21 	and	x1, x1, #0xffff
    cdfc:	9b027c21 	mul	x1, x1, x2
    ce00:	d360fc21 	lsr	x1, x1, #32
    ce04:	eb00003f 	cmp	x1, x0
    ce08:	540000e2 	b.cs	ce24 <f0+0x21b4>  // b.hs, b.nlast
    ce0c:	8b0102f7 	add	x23, x23, x1
    ce10:	394002e0 	ldrb	w0, [x23]
    ce14:	7103fc1f 	cmp	w0, #0xff
    ce18:	540025c0 	b.eq	d2d0 <f0+0x2660>  // b.none
    ce1c:	52800020 	mov	w0, #0x1                   	// #1
    ce20:	390002e0 	strb	w0, [x23]
    ce24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ce28:	91190294 	add	x20, x20, #0x640
    ce2c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ce30:	aa1603e1 	mov	x1, x22
    ce34:	52800020 	mov	w0, #0x1                   	// #1
    ce38:	f9042fe2 	str	x2, [sp, #2136]
    ce3c:	f90433f5 	str	x21, [sp, #2144]
    ce40:	97ffe3a9 	bl	5ce4 <fwp_data.part.0.constprop.0>
    ce44:	f949da81 	ldr	x1, [x20, #5040]
    ce48:	aa0003f5 	mov	x21, x0
    ce4c:	f949ee80 	ldr	x0, [x20, #5080]
    ce50:	cb0102a1 	sub	x1, x21, x1
    ce54:	eb00403f 	cmp	x1, x0, lsl #16
    ce58:	54000322 	b.cs	cebc <f0+0x224c>  // b.hs, b.nlast
    ce5c:	d350fc22 	lsr	x2, x1, #16
    ce60:	f949fe83 	ldr	x3, [x20, #5112]
    ce64:	8b020842 	add	x2, x2, x2, lsl #2
    ce68:	d37df042 	lsl	x2, x2, #3
    ce6c:	8b020060 	add	x0, x3, x2
    ce70:	f9401014 	ldr	x20, [x0, #32]
    ce74:	b4000254 	cbz	x20, cebc <f0+0x224c>
    ce78:	38626862 	ldrb	w2, [x3, x2]
    ce7c:	7100085f 	cmp	w2, #0x2
    ce80:	54000d80 	b.eq	d030 <f0+0x23c0>  // b.none
    ce84:	7100045f 	cmp	w2, #0x1
    ce88:	540001a1 	b.ne	cebc <f0+0x224c>  // b.any
    ce8c:	29430002 	ldp	w2, w0, [x0, #24]
    ce90:	92403c21 	and	x1, x1, #0xffff
    ce94:	9b027c21 	mul	x1, x1, x2
    ce98:	d360fc21 	lsr	x1, x1, #32
    ce9c:	eb00003f 	cmp	x1, x0
    cea0:	540000e2 	b.cs	cebc <f0+0x224c>  // b.hs, b.nlast
    cea4:	8b010294 	add	x20, x20, x1
    cea8:	39400280 	ldrb	w0, [x20]
    ceac:	7103fc1f 	cmp	w0, #0xff
    ceb0:	540012c0 	b.eq	d108 <f0+0x2498>  // b.none
    ceb4:	52800020 	mov	w0, #0x1                   	// #1
    ceb8:	39000280 	strb	w0, [x20]
    cebc:	aa1303e1 	mov	x1, x19
    cec0:	aa1503e0 	mov	x0, x21
    cec4:	97fff3db 	bl	9e30 <fwp_hof0.constprop.0>
    cec8:	aa0003f4 	mov	x20, x0
    cecc:	aa1503e0 	mov	x0, x21
    ced0:	97ffe570 	bl	6490 <fwp_drop0>
    ced4:	aa1303e0 	mov	x0, x19
    ced8:	97ffe56e 	bl	6490 <fwp_drop0>
    cedc:	f0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    cee0:	f947f400 	ldr	x0, [x0, #4072]
    cee4:	f94437e2 	ldr	x2, [sp, #2152]
    cee8:	f9400001 	ldr	x1, [x0]
    ceec:	eb010042 	subs	x2, x2, x1
    cef0:	d2800001 	mov	x1, #0x0                   	// #0
    cef4:	54001f41 	b.ne	d2dc <f0+0x266c>  // b.any
    cef8:	9121c3ff 	add	sp, sp, #0x870
    cefc:	aa1403e0 	mov	x0, x20
    cf00:	a94153f3 	ldp	x19, x20, [sp, #16]
    cf04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    cf08:	a94363f7 	ldp	x23, x24, [sp, #48]
    cf0c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    cf10:	a94573fb 	ldp	x27, x28, [sp, #80]
    cf14:	a8c67bfd 	ldp	x29, x30, [sp], #96
    cf18:	d65f03c0 	ret
    cf1c:	aa1c03e0 	mov	x0, x28
    cf20:	97ffdd05 	bl	4334 <fwp_rc_forget_slot.part.0>
    cf24:	17fff79d 	b	ad98 <f0+0x128>
    cf28:	72003c5f 	tst	w2, #0xffff
    cf2c:	54fef381 	b.ne	ad9c <f0+0x12c>  // b.any
    cf30:	17fff797 	b	ad8c <f0+0x11c>
    cf34:	72003c3f 	tst	w1, #0xffff
    cf38:	54fefc01 	b.ne	aeb8 <f0+0x248>  // b.any
    cf3c:	17fff7da 	b	aea4 <f0+0x234>
    cf40:	72003c3f 	tst	w1, #0xffff
    cf44:	54ff0b21 	b.ne	b0a8 <f0+0x438>  // b.any
    cf48:	17fff853 	b	b094 <f0+0x424>
    cf4c:	72003c3f 	tst	w1, #0xffff
    cf50:	54ff0481 	b.ne	afe0 <f0+0x370>  // b.any
    cf54:	17fff81e 	b	afcc <f0+0x35c>
    cf58:	72003c3f 	tst	w1, #0xffff
    cf5c:	54ff1601 	b.ne	b21c <f0+0x5ac>  // b.any
    cf60:	17fff8aa 	b	b208 <f0+0x598>
    cf64:	72003c3f 	tst	w1, #0xffff
    cf68:	54ff1101 	b.ne	b188 <f0+0x518>  // b.any
    cf6c:	17fff882 	b	b174 <f0+0x504>
    cf70:	72003c3f 	tst	w1, #0xffff
    cf74:	54ff1f41 	b.ne	b35c <f0+0x6ec>  // b.any
    cf78:	17fff8f4 	b	b348 <f0+0x6d8>
    cf7c:	72003c3f 	tst	w1, #0xffff
    cf80:	54ff1961 	b.ne	b2ac <f0+0x63c>  // b.any
    cf84:	17fff8c5 	b	b298 <f0+0x628>
    cf88:	72003c3f 	tst	w1, #0xffff
    cf8c:	54ff90c1 	b.ne	c1a4 <f0+0x1534>  // b.any
    cf90:	17fffc80 	b	c190 <f0+0x1520>
    cf94:	72003c3f 	tst	w1, #0xffff
    cf98:	54ff88e1 	b.ne	c0b4 <f0+0x1444>  // b.any
    cf9c:	17fffc41 	b	c0a0 <f0+0x1430>
    cfa0:	72003c3f 	tst	w1, #0xffff
    cfa4:	54ff9b41 	b.ne	c30c <f0+0x169c>  // b.any
    cfa8:	17fffcd4 	b	c2f8 <f0+0x1688>
    cfac:	72003c3f 	tst	w1, #0xffff
    cfb0:	54ff9641 	b.ne	c278 <f0+0x1608>  // b.any
    cfb4:	17fffcac 	b	c264 <f0+0x15f4>
    cfb8:	72003c3f 	tst	w1, #0xffff
    cfbc:	54ffafa1 	b.ne	c5b0 <f0+0x1940>  // b.any
    cfc0:	17fffd77 	b	c59c <f0+0x192c>
    cfc4:	72003c3f 	tst	w1, #0xffff
    cfc8:	54ffa8a1 	b.ne	c4dc <f0+0x186c>  // b.any
    cfcc:	17fffd3f 	b	c4c8 <f0+0x1858>
    cfd0:	72003c3f 	tst	w1, #0xffff
    cfd4:	54ffbda1 	b.ne	c788 <f0+0x1b18>  // b.any
    cfd8:	17fffde7 	b	c774 <f0+0x1b04>
    cfdc:	72003c3f 	tst	w1, #0xffff
    cfe0:	54ffb321 	b.ne	c644 <f0+0x19d4>  // b.any
    cfe4:	17fffd93 	b	c630 <f0+0x19c0>
    cfe8:	72003c3f 	tst	w1, #0xffff
    cfec:	54ffc901 	b.ne	c90c <f0+0x1c9c>  // b.any
    cff0:	17fffe42 	b	c8f8 <f0+0x1c88>
    cff4:	72003c3f 	tst	w1, #0xffff
    cff8:	54ffc121 	b.ne	c81c <f0+0x1bac>  // b.any
    cffc:	17fffe03 	b	c808 <f0+0x1b98>
    d000:	72003c3f 	tst	w1, #0xffff
    d004:	54ffdba1 	b.ne	cb78 <f0+0x1f08>  // b.any
    d008:	17fffed7 	b	cb64 <f0+0x1ef4>
    d00c:	72003c3f 	tst	w1, #0xffff
    d010:	54ffce81 	b.ne	c9e0 <f0+0x1d70>  // b.any
    d014:	17fffe6e 	b	c9cc <f0+0x1d5c>
    d018:	72003c3f 	tst	w1, #0xffff
    d01c:	54ffeba1 	b.ne	cd90 <f0+0x2120>  // b.any
    d020:	17ffff57 	b	cd7c <f0+0x210c>
    d024:	72003c3f 	tst	w1, #0xffff
    d028:	54ffe201 	b.ne	cc68 <f0+0x1ff8>  // b.any
    d02c:	17ffff0a 	b	cc54 <f0+0x1fe4>
    d030:	72003c3f 	tst	w1, #0xffff
    d034:	54fff441 	b.ne	cebc <f0+0x224c>  // b.any
    d038:	17ffff9c 	b	cea8 <f0+0x2238>
    d03c:	72003c3f 	tst	w1, #0xffff
    d040:	54ffef21 	b.ne	ce24 <f0+0x21b4>  // b.any
    d044:	17ffff73 	b	ce10 <f0+0x21a0>
    d048:	72003c3f 	tst	w1, #0xffff
    d04c:	54ff2381 	b.ne	b4bc <f0+0x84c>  // b.any
    d050:	17fff916 	b	b4a8 <f0+0x838>
    d054:	72003c3f 	tst	w1, #0xffff
    d058:	54ff1da1 	b.ne	b40c <f0+0x79c>  // b.any
    d05c:	17fff8e7 	b	b3f8 <f0+0x788>
    d060:	72003c3f 	tst	w1, #0xffff
    d064:	54ff2fe1 	b.ne	b660 <f0+0x9f0>  // b.any
    d068:	17fff979 	b	b64c <f0+0x9dc>
    d06c:	72003c3f 	tst	w1, #0xffff
    d070:	54ff29c1 	b.ne	b5a8 <f0+0x938>  // b.any
    d074:	17fff948 	b	b594 <f0+0x924>
    d078:	72003c3f 	tst	w1, #0xffff
    d07c:	54ff3d41 	b.ne	b824 <f0+0xbb4>  // b.any
    d080:	17fff9e4 	b	b810 <f0+0xba0>
    d084:	72003c3f 	tst	w1, #0xffff
    d088:	54ff3641 	b.ne	b750 <f0+0xae0>  // b.any
    d08c:	17fff9ac 	b	b73c <f0+0xacc>
    d090:	72003c3f 	tst	w1, #0xffff
    d094:	54ff45e1 	b.ne	b950 <f0+0xce0>  // b.any
    d098:	17fffa29 	b	b93c <f0+0xccc>
    d09c:	72003c3f 	tst	w1, #0xffff
    d0a0:	54ff40c1 	b.ne	b8b8 <f0+0xc48>  // b.any
    d0a4:	17fffa00 	b	b8a4 <f0+0xc34>
    d0a8:	72003c3f 	tst	w1, #0xffff
    d0ac:	54ff4f81 	b.ne	ba9c <f0+0xe2c>  // b.any
    d0b0:	17fffa76 	b	ba88 <f0+0xe18>
    d0b4:	72003c3f 	tst	w1, #0xffff
    d0b8:	54ff4a81 	b.ne	ba08 <f0+0xd98>  // b.any
    d0bc:	17fffa4e 	b	b9f4 <f0+0xd84>
    d0c0:	72003c3f 	tst	w1, #0xffff
    d0c4:	54ff5dc1 	b.ne	bc7c <f0+0x100c>  // b.any
    d0c8:	17fffae8 	b	bc68 <f0+0xff8>
    d0cc:	72003c3f 	tst	w1, #0xffff
    d0d0:	54ff55e1 	b.ne	bb8c <f0+0xf1c>  // b.any
    d0d4:	17fffaa9 	b	bb78 <f0+0xf08>
    d0d8:	72003c3f 	tst	w1, #0xffff
    d0dc:	54ff6c01 	b.ne	be5c <f0+0x11ec>  // b.any
    d0e0:	17fffb5a 	b	be48 <f0+0x11d8>
    d0e4:	72003c3f 	tst	w1, #0xffff
    d0e8:	54ff6421 	b.ne	bd6c <f0+0x10fc>  // b.any
    d0ec:	17fffb1b 	b	bd58 <f0+0x10e8>
    d0f0:	72003c3f 	tst	w1, #0xffff
    d0f4:	54ff7961 	b.ne	c020 <f0+0x13b0>  // b.any
    d0f8:	17fffbc5 	b	c00c <f0+0x139c>
    d0fc:	72003c3f 	tst	w1, #0xffff
    d100:	54ff7261 	b.ne	bf4c <f0+0x12dc>  // b.any
    d104:	17fffb8d 	b	bf38 <f0+0x12c8>
    d108:	aa1403e0 	mov	x0, x20
    d10c:	97ffdc8a 	bl	4334 <fwp_rc_forget_slot.part.0>
    d110:	17ffff69 	b	ceb4 <f0+0x2244>
    d114:	aa1503e0 	mov	x0, x21
    d118:	97ffdc87 	bl	4334 <fwp_rc_forget_slot.part.0>
    d11c:	17fff765 	b	aeb0 <f0+0x240>
    d120:	aa1703e0 	mov	x0, x23
    d124:	97ffdc84 	bl	4334 <fwp_rc_forget_slot.part.0>
    d128:	17fff7ac 	b	afd8 <f0+0x368>
    d12c:	aa1703e0 	mov	x0, x23
    d130:	97ffdc81 	bl	4334 <fwp_rc_forget_slot.part.0>
    d134:	17fff7db 	b	b0a0 <f0+0x430>
    d138:	aa1703e0 	mov	x0, x23
    d13c:	97ffdc7e 	bl	4334 <fwp_rc_forget_slot.part.0>
    d140:	17fff810 	b	b180 <f0+0x510>
    d144:	aa1703e0 	mov	x0, x23
    d148:	97ffdc7b 	bl	4334 <fwp_rc_forget_slot.part.0>
    d14c:	17fff832 	b	b214 <f0+0x5a4>
    d150:	aa1703e0 	mov	x0, x23
    d154:	97ffdc78 	bl	4334 <fwp_rc_forget_slot.part.0>
    d158:	17fff853 	b	b2a4 <f0+0x634>
    d15c:	aa1703e0 	mov	x0, x23
    d160:	97ffdc75 	bl	4334 <fwp_rc_forget_slot.part.0>
    d164:	17fff87c 	b	b354 <f0+0x6e4>
    d168:	aa1703e0 	mov	x0, x23
    d16c:	97ffdc72 	bl	4334 <fwp_rc_forget_slot.part.0>
    d170:	17fff8a5 	b	b404 <f0+0x794>
    d174:	aa1703e0 	mov	x0, x23
    d178:	97ffdc6f 	bl	4334 <fwp_rc_forget_slot.part.0>
    d17c:	17fff8ce 	b	b4b4 <f0+0x844>
    d180:	aa1703e0 	mov	x0, x23
    d184:	97ffdc6c 	bl	4334 <fwp_rc_forget_slot.part.0>
    d188:	17fff906 	b	b5a0 <f0+0x930>
    d18c:	aa1703e0 	mov	x0, x23
    d190:	97ffdc69 	bl	4334 <fwp_rc_forget_slot.part.0>
    d194:	17fff931 	b	b658 <f0+0x9e8>
    d198:	aa1703e0 	mov	x0, x23
    d19c:	97ffdc66 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1a0:	17fff96a 	b	b748 <f0+0xad8>
    d1a4:	aa1703e0 	mov	x0, x23
    d1a8:	97ffdc63 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1ac:	17fff99c 	b	b81c <f0+0xbac>
    d1b0:	aa1703e0 	mov	x0, x23
    d1b4:	97ffdc60 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1b8:	17fff9be 	b	b8b0 <f0+0xc40>
    d1bc:	aa1703e0 	mov	x0, x23
    d1c0:	97ffdc5d 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1c4:	17fff9e1 	b	b948 <f0+0xcd8>
    d1c8:	aa1703e0 	mov	x0, x23
    d1cc:	97ffdc5a 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1d0:	17fffa0c 	b	ba00 <f0+0xd90>
    d1d4:	aa1703e0 	mov	x0, x23
    d1d8:	97ffdc57 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1dc:	17fffa2e 	b	ba94 <f0+0xe24>
    d1e0:	aa1703e0 	mov	x0, x23
    d1e4:	97ffdc54 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1e8:	17fffa67 	b	bb84 <f0+0xf14>
    d1ec:	aa1703e0 	mov	x0, x23
    d1f0:	97ffdc51 	bl	4334 <fwp_rc_forget_slot.part.0>
    d1f4:	17fffaa0 	b	bc74 <f0+0x1004>
    d1f8:	aa1703e0 	mov	x0, x23
    d1fc:	97ffdc4e 	bl	4334 <fwp_rc_forget_slot.part.0>
    d200:	17fffad9 	b	bd64 <f0+0x10f4>
    d204:	aa1703e0 	mov	x0, x23
    d208:	97ffdc4b 	bl	4334 <fwp_rc_forget_slot.part.0>
    d20c:	17fffb12 	b	be54 <f0+0x11e4>
    d210:	aa1703e0 	mov	x0, x23
    d214:	97ffdc48 	bl	4334 <fwp_rc_forget_slot.part.0>
    d218:	17fffb4b 	b	bf44 <f0+0x12d4>
    d21c:	aa1703e0 	mov	x0, x23
    d220:	97ffdc45 	bl	4334 <fwp_rc_forget_slot.part.0>
    d224:	17fffb7d 	b	c018 <f0+0x13a8>
    d228:	aa1703e0 	mov	x0, x23
    d22c:	97ffdc42 	bl	4334 <fwp_rc_forget_slot.part.0>
    d230:	17fffb9f 	b	c0ac <f0+0x143c>
    d234:	aa1703e0 	mov	x0, x23
    d238:	97ffdc3f 	bl	4334 <fwp_rc_forget_slot.part.0>
    d23c:	17fffbd8 	b	c19c <f0+0x152c>
    d240:	aa1703e0 	mov	x0, x23
    d244:	97ffdc3c 	bl	4334 <fwp_rc_forget_slot.part.0>
    d248:	17fffc0a 	b	c270 <f0+0x1600>
    d24c:	aa1703e0 	mov	x0, x23
    d250:	97ffdc39 	bl	4334 <fwp_rc_forget_slot.part.0>
    d254:	17fffc2c 	b	c304 <f0+0x1694>
    d258:	aa1703e0 	mov	x0, x23
    d25c:	97ffdc36 	bl	4334 <fwp_rc_forget_slot.part.0>
    d260:	17fffc9d 	b	c4d4 <f0+0x1864>
    d264:	aa1703e0 	mov	x0, x23
    d268:	97ffdc33 	bl	4334 <fwp_rc_forget_slot.part.0>
    d26c:	17fffccf 	b	c5a8 <f0+0x1938>
    d270:	aa1503e0 	mov	x0, x21
    d274:	97ffdc30 	bl	4334 <fwp_rc_forget_slot.part.0>
    d278:	17fffcf1 	b	c63c <f0+0x19cc>
    d27c:	aa1703e0 	mov	x0, x23
    d280:	97ffdc2d 	bl	4334 <fwp_rc_forget_slot.part.0>
    d284:	17fffd3f 	b	c780 <f0+0x1b10>
    d288:	aa1703e0 	mov	x0, x23
    d28c:	97ffdc2a 	bl	4334 <fwp_rc_forget_slot.part.0>
    d290:	17fffd61 	b	c814 <f0+0x1ba4>
    d294:	aa1703e0 	mov	x0, x23
    d298:	97ffdc27 	bl	4334 <fwp_rc_forget_slot.part.0>
    d29c:	17fffd9a 	b	c904 <f0+0x1c94>
    d2a0:	aa1703e0 	mov	x0, x23
    d2a4:	97ffdc24 	bl	4334 <fwp_rc_forget_slot.part.0>
    d2a8:	17fffdcc 	b	c9d8 <f0+0x1d68>
    d2ac:	aa1703e0 	mov	x0, x23
    d2b0:	97ffdc21 	bl	4334 <fwp_rc_forget_slot.part.0>
    d2b4:	17fffe2f 	b	cb70 <f0+0x1f00>
    d2b8:	aa1703e0 	mov	x0, x23
    d2bc:	97ffdc1e 	bl	4334 <fwp_rc_forget_slot.part.0>
    d2c0:	17fffe68 	b	cc60 <f0+0x1ff0>
    d2c4:	aa1703e0 	mov	x0, x23
    d2c8:	97ffdc1b 	bl	4334 <fwp_rc_forget_slot.part.0>
    d2cc:	17fffeaf 	b	cd88 <f0+0x2118>
    d2d0:	aa1703e0 	mov	x0, x23
    d2d4:	97ffdc18 	bl	4334 <fwp_rc_forget_slot.part.0>
    d2d8:	17fffed1 	b	ce1c <f0+0x21ac>
    d2dc:	97ffd54d 	bl	2810 <__stack_chk_fail@plt>
    d2e0:	97ffd560 	bl	2860 <abort@plt>

000000000000d2e4 <fwp_main_thread>:
    d2e4:	d10443ff 	sub	sp, sp, #0x110
    d2e8:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d2ec:	f947f400 	ldr	x0, [x0, #4072]
    d2f0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    d2f4:	910303fd 	add	x29, sp, #0xc0
    d2f8:	a90d53f3 	stp	x19, x20, [sp, #208]
    d2fc:	900003f4 	adrp	x20, 89000 <fwp_root_context+0xba0>
    d300:	91190281 	add	x1, x20, #0x640
    d304:	a90e5bf5 	stp	x21, x22, [sp, #224]
    d308:	a90f63f7 	stp	x23, x24, [sp, #240]
    d30c:	b953a421 	ldr	w1, [x1, #5028]
    d310:	a9106bf9 	stp	x25, x26, [sp, #256]
    d314:	f9400002 	ldr	x2, [x0]
    d318:	f9005fe2 	str	x2, [sp, #184]
    d31c:	d2800002 	mov	x2, #0x0                   	// #0
    d320:	34000f01 	cbz	w1, d500 <fwp_main_thread+0x21c>
    d324:	91190280 	add	x0, x20, #0x640
    d328:	b953a800 	ldr	w0, [x0, #5032]
    d32c:	35000e20 	cbnz	w0, d4f0 <fwp_main_thread+0x20c>
    d330:	91001fe2 	add	x2, sp, #0x7
    d334:	f0000115 	adrp	x21, 30000 <__data_start>
    d338:	f0000103 	adrp	x3, 30000 <__data_start>
    d33c:	910182b3 	add	x19, x21, #0x60
    d340:	91118063 	add	x3, x3, #0x460
    d344:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    d348:	d2a00025 	mov	x5, #0x10000               	// #65536
    d34c:	910023e0 	add	x0, sp, #0x8
    d350:	d2800001 	mov	x1, #0x0                   	// #0
    d354:	f90007e3 	str	x3, [sp, #8]
    d358:	b90013ff 	str	wzr, [sp, #16]
    d35c:	f9000fe5 	str	x5, [sp, #24]
    d360:	a90a1262 	stp	x2, x4, [x19, #160]
    d364:	97ffd4c3 	bl	2670 <sigaltstack@plt>
    d368:	35000220 	cbnz	w0, d3ac <fwp_main_thread+0xc8>
    d36c:	4f000400 	movi	v0.4s, #0x0
    d370:	9100a3e0 	add	x0, sp, #0x28
    d374:	d0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    d378:	52800082 	mov	w2, #0x4                   	// #4
    d37c:	9100c021 	add	x1, x1, #0x30
    d380:	72a10002 	movk	w2, #0x800, lsl #16
    d384:	910083f6 	add	x22, sp, #0x20
    d388:	f90013e1 	str	x1, [sp, #32]
    d38c:	3d802000 	str	q0, [x0, #128]
    d390:	b900abe2 	str	w2, [sp, #168]
    d394:	ad000000 	stp	q0, q0, [x0]
    d398:	ad010000 	stp	q0, q0, [x0, #32]
    d39c:	ad020000 	stp	q0, q0, [x0, #64]
    d3a0:	ad030000 	stp	q0, q0, [x0, #96]
    d3a4:	97ffd50b 	bl	27d0 <sigemptyset@plt>
    d3a8:	34000080 	cbz	w0, d3b8 <fwp_main_thread+0xd4>
    d3ac:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x70>
    d3b0:	911e0000 	add	x0, x0, #0x780
    d3b4:	97ffdbc0 	bl	42b4 <fwp_trap>
    d3b8:	aa1603e1 	mov	x1, x22
    d3bc:	d2800002 	mov	x2, #0x0                   	// #0
    d3c0:	52800160 	mov	w0, #0xb                   	// #11
    d3c4:	97ffd51b 	bl	2830 <sigaction@plt>
    d3c8:	35ffff20 	cbnz	w0, d3ac <fwp_main_thread+0xc8>
    d3cc:	aa1603e1 	mov	x1, x22
    d3d0:	d2800002 	mov	x2, #0x0                   	// #0
    d3d4:	528000e0 	mov	w0, #0x7                   	// #7
    d3d8:	97ffd516 	bl	2830 <sigaction@plt>
    d3dc:	35fffe80 	cbnz	w0, d3ac <fwp_main_thread+0xc8>
    d3e0:	91190281 	add	x1, x20, #0x640
    d3e4:	52800036 	mov	w22, #0x1                   	// #1
    d3e8:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d3ec:	910cc000 	add	x0, x0, #0x330
    d3f0:	b9013276 	str	w22, [x19, #304]
    d3f4:	fd4a1020 	ldr	d0, [x1, #5152]
    d3f8:	7e61d800 	ucvtf	d0, d0
    d3fc:	fd00a660 	str	d0, [x19, #328]
    d400:	940002d8 	bl	df60 <atexit>
    d404:	350022c0 	cbnz	w0, d85c <fwp_main_thread+0x578>
    d408:	b943ca60 	ldr	w0, [x19, #968]
    d40c:	34001c60 	cbz	w0, d798 <fwp_main_thread+0x4b4>
    d410:	910182ba 	add	x26, x21, #0x60
    d414:	f9404f56 	ldr	x22, [x26, #152]
    d418:	b40007b6 	cbz	x22, d50c <fwp_main_thread+0x228>
    d41c:	910102d7 	add	x23, x22, #0x40
    d420:	39414ad9 	ldrb	w25, [x22, #82]
    d424:	52800038 	mov	w24, #0x1                   	// #1
    d428:	39014ad8 	strb	w24, [x22, #82]
    d42c:	d503201f 	nop
    d430:	f94016c0 	ldr	x0, [x22, #40]
    d434:	b40006a0 	cbz	x0, d508 <fwp_main_thread+0x224>
    d438:	f94032c1 	ldr	x1, [x22, #96]
    d43c:	394146c0 	ldrb	w0, [x22, #81]
    d440:	b4001c61 	cbz	x1, d7cc <fwp_main_thread+0x4e8>
    d444:	36001b20 	tbz	w0, #0, d7a8 <fwp_main_thread+0x4c4>
    d448:	f9404f53 	ldr	x19, [x26, #152]
    d44c:	f94022c0 	ldr	x0, [x22, #64]
    d450:	39414a61 	ldrb	w1, [x19, #82]
    d454:	37001e81 	tbnz	w1, #0, d824 <fwp_main_thread+0x540>
    d458:	f9403261 	ldr	x1, [x19, #96]
    d45c:	a911fe77 	stp	x23, xzr, [x19, #280]
    d460:	f9009660 	str	x0, [x19, #296]
    d464:	b4000040 	cbz	x0, d46c <fwp_main_thread+0x188>
    d468:	f9009013 	str	x19, [x0, #288]
    d46c:	f90022d3 	str	x19, [x22, #64]
    d470:	b4000101 	cbz	x1, d490 <fwp_main_thread+0x1ac>
    d474:	f9409740 	ldr	x0, [x26, #296]
    d478:	39015678 	strb	w24, [x19, #85]
    d47c:	f9003661 	str	x1, [x19, #104]
    d480:	a910827f 	stp	xzr, x0, [x19, #264]
    d484:	b4000040 	cbz	x0, d48c <fwp_main_thread+0x1a8>
    d488:	f9008413 	str	x19, [x0, #264]
    d48c:	f9009753 	str	x19, [x26, #296]
    d490:	39015a7f 	strb	wzr, [x19, #86]
    d494:	97ffe657 	bl	6df0 <fwp_block>
    d498:	f9408e62 	ldr	x2, [x19, #280]
    d49c:	b4000142 	cbz	x2, d4c4 <fwp_main_thread+0x1e0>
    d4a0:	a9520261 	ldp	x1, x0, [x19, #288]
    d4a4:	b4001cc1 	cbz	x1, d83c <fwp_main_thread+0x558>
    d4a8:	f9009420 	str	x0, [x1, #296]
    d4ac:	f9409660 	ldr	x0, [x19, #296]
    d4b0:	b4000040 	cbz	x0, d4b8 <fwp_main_thread+0x1d4>
    d4b4:	f9009001 	str	x1, [x0, #288]
    d4b8:	91080260 	add	x0, x19, #0x200
    d4bc:	f900967f 	str	xzr, [x19, #296]
    d4c0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    d4c4:	39415660 	ldrb	w0, [x19, #85]
    d4c8:	3607fb40 	tbz	w0, #0, d430 <fwp_main_thread+0x14c>
    d4cc:	a9508261 	ldp	x1, x0, [x19, #264]
    d4d0:	b4001ba1 	cbz	x1, d844 <fwp_main_thread+0x560>
    d4d4:	f9008820 	str	x0, [x1, #272]
    d4d8:	b4000040 	cbz	x0, d4e0 <fwp_main_thread+0x1fc>
    d4dc:	f9008401 	str	x1, [x0, #264]
    d4e0:	91080260 	add	x0, x19, #0x200
    d4e4:	3901567f 	strb	wzr, [x19, #85]
    d4e8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    d4ec:	17ffffd1 	b	d430 <fwp_main_thread+0x14c>
    d4f0:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d4f4:	912e1000 	add	x0, x0, #0xb84
    d4f8:	9400029a 	bl	df60 <atexit>
    d4fc:	17ffff8d 	b	d330 <fwp_main_thread+0x4c>
    d500:	97ffd9fc 	bl	3cf0 <fwp_heap_init>
    d504:	17ffff88 	b	d324 <fwp_main_thread+0x40>
    d508:	39014ad9 	strb	w25, [x22, #82]
    d50c:	910182b3 	add	x19, x21, #0x60
    d510:	f941d660 	ldr	x0, [x19, #936]
    d514:	b5000180 	cbnz	x0, d544 <fwp_main_thread+0x260>
    d518:	f941de60 	ldr	x0, [x19, #952]
    d51c:	b5000140 	cbnz	x0, d544 <fwp_main_thread+0x260>
    d520:	f941d260 	ldr	x0, [x19, #928]
    d524:	97ffdc1f 	bl	45a0 <fwp_mem_free>
    d528:	f901d27f 	str	xzr, [x19, #928]
    d52c:	f9404e60 	ldr	x0, [x19, #152]
    d530:	f901da7f 	str	xzr, [x19, #944]
    d534:	b40000c0 	cbz	x0, d54c <fwp_main_thread+0x268>
    d538:	f900541f 	str	xzr, [x0, #168]
    d53c:	f9005c1f 	str	xzr, [x0, #184]
    d540:	14000003 	b	d54c <fwp_main_thread+0x268>
    d544:	910182a0 	add	x0, x21, #0x60
    d548:	f9404c00 	ldr	x0, [x0, #152]
    d54c:	910182a1 	add	x1, x21, #0x60
    d550:	f941f026 	ldr	x6, [x1, #992]
    d554:	b903d83f 	str	wzr, [x1, #984]
    d558:	eb0000df 	cmp	x6, x0
    d55c:	54001861 	b.ne	d868 <fwp_main_thread+0x584>  // b.any
    d560:	b40003a0 	cbz	x0, d5d4 <fwp_main_thread+0x2f0>
    d564:	f941c025 	ldr	x5, [x1, #896]
    d568:	52800021 	mov	w1, #0x1                   	// #1
    d56c:	39014801 	strb	w1, [x0, #82]
    d570:	b4000325 	cbz	x5, d5d4 <fwp_main_thread+0x2f0>
    d574:	d503201f 	nop
    d578:	394140a0 	ldrb	w0, [x5, #80]
    d57c:	37000060 	tbnz	w0, #0, d588 <fwp_main_thread+0x2a4>
    d580:	aa0503e0 	mov	x0, x5
    d584:	97ffd83b 	bl	3670 <fwp_cancel_tree.part.0>
    d588:	f9409ca5 	ldr	x5, [x5, #312]
    d58c:	b5ffff65 	cbnz	x5, d578 <fwp_main_thread+0x294>
    d590:	910182b3 	add	x19, x21, #0x60
    d594:	52800036 	mov	w22, #0x1                   	// #1
    d598:	f94028c0 	ldr	x0, [x6, #80]
    d59c:	f2001c1f 	tst	x0, #0xff000000ff
    d5a0:	540000e1 	b.ne	d5bc <fwp_main_thread+0x2d8>  // b.any
    d5a4:	f9406260 	ldr	x0, [x19, #192]
    d5a8:	390150d6 	strb	w22, [x6, #84]
    d5ac:	f90080df 	str	xzr, [x6, #256]
    d5b0:	b4001360 	cbz	x0, d81c <fwp_main_thread+0x538>
    d5b4:	f9008006 	str	x6, [x0, #256]
    d5b8:	f9006266 	str	x6, [x19, #192]
    d5bc:	97ffe60d 	bl	6df0 <fwp_block>
    d5c0:	97ffe594 	bl	6c10 <fwp_free_zombie>
    d5c4:	f941c260 	ldr	x0, [x19, #896]
    d5c8:	b4000060 	cbz	x0, d5d4 <fwp_main_thread+0x2f0>
    d5cc:	f941f266 	ldr	x6, [x19, #992]
    d5d0:	17fffff2 	b	d598 <fwp_main_thread+0x2b4>
    d5d4:	910182b6 	add	x22, x21, #0x60
    d5d8:	97ffe58e 	bl	6c10 <fwp_free_zombie>
    d5dc:	f94066c0 	ldr	x0, [x22, #200]
    d5e0:	b5001440 	cbnz	x0, d868 <fwp_main_thread+0x584>
    d5e4:	f94096c0 	ldr	x0, [x22, #296]
    d5e8:	b5001400 	cbnz	x0, d868 <fwp_main_thread+0x584>
    d5ec:	b94172d3 	ldr	w19, [x22, #368]
    d5f0:	340001f3 	cbz	w19, d62c <fwp_main_thread+0x348>
    d5f4:	93407e77 	sxtw	x23, w19
    d5f8:	51000673 	sub	w19, w19, #0x1
    d5fc:	d1000af7 	sub	x23, x23, #0x2
    d600:	910602d8 	add	x24, x22, #0x180
    d604:	cb3342f7 	sub	x23, x23, w19, uxtw
    d608:	93407e73 	sxtw	x19, w19
    d60c:	d503201f 	nop
    d610:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    d614:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d618:	b90172d3 	str	w19, [x22, #368]
    d61c:	d1000673 	sub	x19, x19, #0x1
    d620:	97ffd4c4 	bl	2930 <munmap@plt>
    d624:	eb1302ff 	cmp	x23, x19
    d628:	54ffff41 	b.ne	d610 <fwp_main_thread+0x32c>  // b.any
    d62c:	f0000113 	adrp	x19, 30000 <__data_start>
    d630:	91004260 	add	x0, x19, #0x10
    d634:	b9403000 	ldr	w0, [x0, #48]
    d638:	36f80ac0 	tbz	w0, #31, d790 <fwp_main_thread+0x4ac>
    d63c:	910182b6 	add	x22, x21, #0x60
    d640:	91004273 	add	x19, x19, #0x10
    d644:	12800001 	mov	w1, #0xffffffff            	// #-1
    d648:	f941fac0 	ldr	x0, [x22, #1008]
    d64c:	b9003261 	str	w1, [x19, #48]
    d650:	f941f6c1 	ldr	x1, [x22, #1000]
    d654:	b40001e0 	cbz	x0, d690 <fwp_main_thread+0x3ac>
    d658:	d2800013 	mov	x19, #0x0                   	// #0
    d65c:	d503201f 	nop
    d660:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    d664:	b40000e0 	cbz	x0, d680 <fwp_main_thread+0x39c>
    d668:	f9400001 	ldr	x1, [x0]
    d66c:	b5000fe1 	cbnz	x1, d868 <fwp_main_thread+0x584>
    d670:	f9400401 	ldr	x1, [x0, #8]
    d674:	b5000fa1 	cbnz	x1, d868 <fwp_main_thread+0x584>
    d678:	97ffdbca 	bl	45a0 <fwp_mem_free>
    d67c:	f941f6c1 	ldr	x1, [x22, #1000]
    d680:	91000673 	add	x19, x19, #0x1
    d684:	f941fac0 	ldr	x0, [x22, #1008]
    d688:	eb00027f 	cmp	x19, x0
    d68c:	54fffea3 	b.cc	d660 <fwp_main_thread+0x37c>  // b.lo, b.ul, b.last
    d690:	aa0103e0 	mov	x0, x1
    d694:	97ffdbc3 	bl	45a0 <fwp_mem_free>
    d698:	910182a0 	add	x0, x21, #0x60
    d69c:	f941f013 	ldr	x19, [x0, #992]
    d6a0:	f901f41f 	str	xzr, [x0, #1000]
    d6a4:	f901f81f 	str	xzr, [x0, #1008]
    d6a8:	b40001f3 	cbz	x19, d6e4 <fwp_main_thread+0x400>
    d6ac:	f9401661 	ldr	x1, [x19, #40]
    d6b0:	b5000dc1 	cbnz	x1, d868 <fwp_main_thread+0x584>
    d6b4:	f9405661 	ldr	x1, [x19, #168]
    d6b8:	b5000d81 	cbnz	x1, d868 <fwp_main_thread+0x584>
    d6bc:	f941d401 	ldr	x1, [x0, #936]
    d6c0:	b5000d41 	cbnz	x1, d868 <fwp_main_thread+0x584>
    d6c4:	f941dc00 	ldr	x0, [x0, #952]
    d6c8:	b5000d00 	cbnz	x0, d868 <fwp_main_thread+0x584>
    d6cc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d6d0:	f00003c0 	adrp	x0, 88000 <ad_raw_blocks+0x17ba0>
    d6d4:	91118000 	add	x0, x0, #0x460
    d6d8:	97ffd442 	bl	27e0 <memset@plt>
    d6dc:	aa1303e0 	mov	x0, x19
    d6e0:	97ffdbb0 	bl	45a0 <fwp_mem_free>
    d6e4:	910182a6 	add	x6, x21, #0x60
    d6e8:	91190294 	add	x20, x20, #0x640
    d6ec:	3dc01aa1 	ldr	q1, [x21, #96]
    d6f0:	52800041 	mov	w1, #0x2                   	// #2
    d6f4:	3dc004c2 	ldr	q2, [x6, #16]
    d6f8:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x70>
    d6fc:	fd4a1280 	ldr	d0, [x20, #5152]
    d700:	911f2042 	add	x2, x2, #0x7c8
    d704:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d708:	fd40a4c1 	ldr	d1, [x6, #328]
    d70c:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d710:	f947e800 	ldr	x0, [x0, #4048]
    d714:	7e61d800 	ucvtf	d0, d0
    d718:	a95390c3 	ldp	x3, x4, [x6, #312]
    d71c:	f9004cdf 	str	xzr, [x6, #152]
    d720:	f9400000 	ldr	x0, [x0]
    d724:	1e613801 	fsub	d1, d0, d1
    d728:	f940acc5 	ldr	x5, [x6, #344]
    d72c:	b90130df 	str	wzr, [x6, #304]
    d730:	5ef1b842 	addp	d2, v2.2d
    d734:	fd40a8c0 	ldr	d0, [x6, #336]
    d738:	f901f0df 	str	xzr, [x6, #992]
    d73c:	fd0058c2 	str	d2, [x6, #176]
    d740:	97ffd450 	bl	2880 <__fprintf_chk@plt>
    d744:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d748:	f947ec00 	ldr	x0, [x0, #4056]
    d74c:	f9400000 	ldr	x0, [x0]
    d750:	97ffd47c 	bl	2940 <fflush@plt>
    d754:	d0000100 	adrp	x0, 2f000 <fwp_fn_table+0xb30>
    d758:	f947f400 	ldr	x0, [x0, #4072]
    d75c:	f9405fe2 	ldr	x2, [sp, #184]
    d760:	f9400001 	ldr	x1, [x0]
    d764:	eb010042 	subs	x2, x2, x1
    d768:	d2800001 	mov	x1, #0x0                   	// #0
    d76c:	54000761 	b.ne	d858 <fwp_main_thread+0x574>  // b.any
    d770:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d774:	d2800000 	mov	x0, #0x0                   	// #0
    d778:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d77c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d780:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d784:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d788:	910443ff 	add	sp, sp, #0x110
    d78c:	d65f03c0 	ret
    d790:	97ffd424 	bl	2820 <close@plt>
    d794:	17ffffaa 	b	d63c <fwp_main_thread+0x358>
    d798:	97fff536 	bl	ac70 <f0>
    d79c:	b903ca76 	str	w22, [x19, #968]
    d7a0:	f901ea60 	str	x0, [x19, #976]
    d7a4:	17ffff1b 	b	d410 <fwp_main_thread+0x12c>
    d7a8:	97ffdce2 	bl	4b30 <fwp_now_ns>
    d7ac:	f94032c1 	ldr	x1, [x22, #96]
    d7b0:	eb01001f 	cmp	x0, x1
    d7b4:	540000ab 	b.lt	d7c8 <fwp_main_thread+0x4e4>  // b.tstop
    d7b8:	394142c0 	ldrb	w0, [x22, #80]
    d7bc:	37000060 	tbnz	w0, #0, d7c8 <fwp_main_thread+0x4e4>
    d7c0:	aa1603e0 	mov	x0, x22
    d7c4:	97ffd7ab 	bl	3670 <fwp_cancel_tree.part.0>
    d7c8:	394146c0 	ldrb	w0, [x22, #81]
    d7cc:	f9404f53 	ldr	x19, [x26, #152]
    d7d0:	39414a62 	ldrb	w2, [x19, #82]
    d7d4:	3707e3a0 	tbnz	w0, #0, d448 <fwp_main_thread+0x164>
    d7d8:	f94032c1 	ldr	x1, [x22, #96]
    d7dc:	370001c2 	tbnz	w2, #0, d814 <fwp_main_thread+0x530>
    d7e0:	f9403260 	ldr	x0, [x19, #96]
    d7e4:	b4000180 	cbz	x0, d814 <fwp_main_thread+0x530>
    d7e8:	b4000061 	cbz	x1, d7f4 <fwp_main_thread+0x510>
    d7ec:	eb01001f 	cmp	x0, x1
    d7f0:	9a81d000 	csel	x0, x0, x1, le
    d7f4:	f94022c1 	ldr	x1, [x22, #64]
    d7f8:	a911fe77 	stp	x23, xzr, [x19, #280]
    d7fc:	f9009661 	str	x1, [x19, #296]
    d800:	b4000261 	cbz	x1, d84c <fwp_main_thread+0x568>
    d804:	f9009033 	str	x19, [x1, #288]
    d808:	aa0003e1 	mov	x1, x0
    d80c:	f90022d3 	str	x19, [x22, #64]
    d810:	17ffff19 	b	d474 <fwp_main_thread+0x190>
    d814:	f94022c0 	ldr	x0, [x22, #64]
    d818:	17ffff11 	b	d45c <fwp_main_thread+0x178>
    d81c:	f9006666 	str	x6, [x19, #200]
    d820:	17ffff66 	b	d5b8 <fwp_main_thread+0x2d4>
    d824:	a911fe77 	stp	x23, xzr, [x19, #280]
    d828:	f9009660 	str	x0, [x19, #296]
    d82c:	b4000040 	cbz	x0, d834 <fwp_main_thread+0x550>
    d830:	f9009013 	str	x19, [x0, #288]
    d834:	f90022d3 	str	x19, [x22, #64]
    d838:	17ffff16 	b	d490 <fwp_main_thread+0x1ac>
    d83c:	f9000040 	str	x0, [x2]
    d840:	17ffff1c 	b	d4b0 <fwp_main_thread+0x1cc>
    d844:	f9009740 	str	x0, [x26, #296]
    d848:	17ffff24 	b	d4d8 <fwp_main_thread+0x1f4>
    d84c:	aa0003e1 	mov	x1, x0
    d850:	f90022d3 	str	x19, [x22, #64]
    d854:	17ffff08 	b	d474 <fwp_main_thread+0x190>
    d858:	97ffd3ee 	bl	2810 <__stack_chk_fail@plt>
    d85c:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x70>
    d860:	911ea000 	add	x0, x0, #0x7a8
    d864:	97ffd6a7 	bl	3300 <ad_raw_fail>
    d868:	97ffd3fe 	bl	2860 <abort@plt>
    d86c:	d503201f 	nop

000000000000d870 <__divti3>:
    d870:	d503245f 	bti	c
    d874:	d2800004 	mov	x4, #0x0                   	// #0
    d878:	b7f80721 	tbnz	x1, #63, d95c <__divti3+0xec>
    d87c:	b6f80083 	tbz	x3, #63, d88c <__divti3+0x1c>
    d880:	eb0203e2 	negs	x2, x2
    d884:	aa2403e4 	mvn	x4, x4
    d888:	da0303e3 	ngc	x3, x3
    d88c:	aa0203e6 	mov	x6, x2
    d890:	aa0003e7 	mov	x7, x0
    d894:	aa0103e5 	mov	x5, x1
    d898:	b5000583 	cbnz	x3, d948 <__divti3+0xd8>
    d89c:	eb01005f 	cmp	x2, x1
    d8a0:	54000e69 	b.ls	da6c <__divti3+0x1fc>  // b.plast
    d8a4:	dac01040 	clz	x0, x2
    d8a8:	b40000e0 	cbz	x0, d8c4 <__divti3+0x54>
    d8ac:	4b0003e1 	neg	w1, w0
    d8b0:	9ac020a5 	lsl	x5, x5, x0
    d8b4:	9ac02046 	lsl	x6, x2, x0
    d8b8:	9ac124e1 	lsr	x1, x7, x1
    d8bc:	aa050025 	orr	x5, x1, x5
    d8c0:	9ac020e7 	lsl	x7, x7, x0
    d8c4:	d360fcc8 	lsr	x8, x6, #32
    d8c8:	92407cc2 	and	x2, x6, #0xffffffff
    d8cc:	9ac808a3 	udiv	x3, x5, x8
    d8d0:	9b089465 	msub	x5, x3, x8, x5
    d8d4:	aa0303e0 	mov	x0, x3
    d8d8:	9b037c41 	mul	x1, x2, x3
    d8dc:	93c780a5 	extr	x5, x5, x7, #32
    d8e0:	eb05003f 	cmp	x1, x5
    d8e4:	540000a9 	b.ls	d8f8 <__divti3+0x88>  // b.plast
    d8e8:	ab0500c5 	adds	x5, x6, x5
    d8ec:	d1000460 	sub	x0, x3, #0x1
    d8f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d8f4:	540015a8 	b.hi	dba8 <__divti3+0x338>  // b.pmore
    d8f8:	cb0100a5 	sub	x5, x5, x1
    d8fc:	9ac808a3 	udiv	x3, x5, x8
    d900:	9b089465 	msub	x5, x3, x8, x5
    d904:	aa0303e1 	mov	x1, x3
    d908:	9b037c42 	mul	x2, x2, x3
    d90c:	aa0703e3 	mov	x3, x7
    d910:	b3607ca3 	bfi	x3, x5, #32, #32
    d914:	eb03005f 	cmp	x2, x3
    d918:	540000c9 	b.ls	d930 <__divti3+0xc0>  // b.plast
    d91c:	ab0300c3 	adds	x3, x6, x3
    d920:	d1000425 	sub	x5, x1, #0x1
    d924:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d928:	d1000821 	sub	x1, x1, #0x2
    d92c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d930:	aa008020 	orr	x0, x1, x0, lsl #32
    d934:	d2800001 	mov	x1, #0x0                   	// #0
    d938:	b4000064 	cbz	x4, d944 <__divti3+0xd4>
    d93c:	eb0003e0 	negs	x0, x0
    d940:	da0103e1 	ngc	x1, x1
    d944:	d65f03c0 	ret
    d948:	eb01007f 	cmp	x3, x1
    d94c:	54000109 	b.ls	d96c <__divti3+0xfc>  // b.plast
    d950:	d2800001 	mov	x1, #0x0                   	// #0
    d954:	d2800000 	mov	x0, #0x0                   	// #0
    d958:	17fffff8 	b	d938 <__divti3+0xc8>
    d95c:	eb0003e0 	negs	x0, x0
    d960:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d964:	da0103e1 	ngc	x1, x1
    d968:	17ffffc5 	b	d87c <__divti3+0xc>
    d96c:	dac01067 	clz	x7, x3
    d970:	b40010e7 	cbz	x7, db8c <__divti3+0x31c>
    d974:	d2800805 	mov	x5, #0x40                  	// #64
    d978:	cb0700a5 	sub	x5, x5, x7
    d97c:	9ac72063 	lsl	x3, x3, x7
    d980:	9ac52448 	lsr	x8, x2, x5
    d984:	aa030108 	orr	x8, x8, x3
    d988:	9ac52426 	lsr	x6, x1, x5
    d98c:	92407d0a 	and	x10, x8, #0xffffffff
    d990:	d360fd09 	lsr	x9, x8, #32
    d994:	9ac52403 	lsr	x3, x0, x5
    d998:	9ac72021 	lsl	x1, x1, x7
    d99c:	aa010063 	orr	x3, x3, x1
    d9a0:	9ac72042 	lsl	x2, x2, x7
    d9a4:	9ac908cb 	udiv	x11, x6, x9
    d9a8:	9b099965 	msub	x5, x11, x9, x6
    d9ac:	aa0b03e1 	mov	x1, x11
    d9b0:	9b0b7d46 	mul	x6, x10, x11
    d9b4:	93c380a5 	extr	x5, x5, x3, #32
    d9b8:	eb0500df 	cmp	x6, x5
    d9bc:	540000a9 	b.ls	d9d0 <__divti3+0x160>  // b.plast
    d9c0:	ab050105 	adds	x5, x8, x5
    d9c4:	d1000561 	sub	x1, x11, #0x1
    d9c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d9cc:	54000f48 	b.hi	dbb4 <__divti3+0x344>  // b.pmore
    d9d0:	cb0600a6 	sub	x6, x5, x6
    d9d4:	9ac908cb 	udiv	x11, x6, x9
    d9d8:	9b099969 	msub	x9, x11, x9, x6
    d9dc:	aa0b03e5 	mov	x5, x11
    d9e0:	9b0b7d4a 	mul	x10, x10, x11
    d9e4:	b3607d23 	bfi	x3, x9, #32, #32
    d9e8:	eb03015f 	cmp	x10, x3
    d9ec:	540000a9 	b.ls	da00 <__divti3+0x190>  // b.plast
    d9f0:	ab030103 	adds	x3, x8, x3
    d9f4:	d1000565 	sub	x5, x11, #0x1
    d9f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d9fc:	54000e28 	b.hi	dbc0 <__divti3+0x350>  // b.pmore
    da00:	aa0180a1 	orr	x1, x5, x1, lsl #32
    da04:	92407c48 	and	x8, x2, #0xffffffff
    da08:	2a0503e5 	mov	w5, w5
    da0c:	d360fc42 	lsr	x2, x2, #32
    da10:	d360fc26 	lsr	x6, x1, #32
    da14:	cb0a0063 	sub	x3, x3, x10
    da18:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    da1c:	9b087caa 	mul	x10, x5, x8
    da20:	9b087cc8 	mul	x8, x6, x8
    da24:	9b0220a5 	madd	x5, x5, x2, x8
    da28:	9b027cc6 	mul	x6, x6, x2
    da2c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    da30:	8b0900c5 	add	x5, x6, x9
    da34:	eb02011f 	cmp	x8, x2
    da38:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    da3c:	8b4280c6 	add	x6, x6, x2, lsr #32
    da40:	eb06007f 	cmp	x3, x6
    da44:	540000e3 	b.cc	da60 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    da48:	92407d4a 	and	x10, x10, #0xffffffff
    da4c:	9ac72000 	lsl	x0, x0, x7
    da50:	8b028142 	add	x2, x10, x2, lsl #32
    da54:	eb02001f 	cmp	x0, x2
    da58:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    da5c:	54000a01 	b.ne	db9c <__divti3+0x32c>  // b.any
    da60:	d1000420 	sub	x0, x1, #0x1
    da64:	d2800001 	mov	x1, #0x0                   	// #0
    da68:	17ffffb4 	b	d938 <__divti3+0xc8>
    da6c:	b5000062 	cbnz	x2, da78 <__divti3+0x208>
    da70:	d2800022 	mov	x2, #0x1                   	// #1
    da74:	9ac30846 	udiv	x6, x2, x3
    da78:	dac010c8 	clz	x8, x6
    da7c:	b5000408 	cbnz	x8, dafc <__divti3+0x28c>
    da80:	d360fcc9 	lsr	x9, x6, #32
    da84:	92407cc5 	and	x5, x6, #0xffffffff
    da88:	cb060023 	sub	x3, x1, x6
    da8c:	d2800021 	mov	x1, #0x1                   	// #1
    da90:	9ac90868 	udiv	x8, x3, x9
    da94:	9b098d03 	msub	x3, x8, x9, x3
    da98:	aa0803e0 	mov	x0, x8
    da9c:	9b057d02 	mul	x2, x8, x5
    daa0:	93c78063 	extr	x3, x3, x7, #32
    daa4:	eb03005f 	cmp	x2, x3
    daa8:	540000a9 	b.ls	dabc <__divti3+0x24c>  // b.plast
    daac:	ab0300c3 	adds	x3, x6, x3
    dab0:	d1000500 	sub	x0, x8, #0x1
    dab4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    dab8:	54000968 	b.hi	dbe4 <__divti3+0x374>  // b.pmore
    dabc:	cb020063 	sub	x3, x3, x2
    dac0:	9ac90862 	udiv	x2, x3, x9
    dac4:	aa0203e8 	mov	x8, x2
    dac8:	9b098c42 	msub	x2, x2, x9, x3
    dacc:	aa0703e3 	mov	x3, x7
    dad0:	9b057d05 	mul	x5, x8, x5
    dad4:	b3607c43 	bfi	x3, x2, #32, #32
    dad8:	eb0300bf 	cmp	x5, x3
    dadc:	540000c9 	b.ls	daf4 <__divti3+0x284>  // b.plast
    dae0:	ab0300c2 	adds	x2, x6, x3
    dae4:	d1000503 	sub	x3, x8, #0x1
    dae8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    daec:	d1000908 	sub	x8, x8, #0x2
    daf0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    daf4:	aa008100 	orr	x0, x8, x0, lsl #32
    daf8:	17ffff90 	b	d938 <__divti3+0xc8>
    dafc:	9ac820c6 	lsl	x6, x6, x8
    db00:	d2800803 	mov	x3, #0x40                  	// #64
    db04:	cb080063 	sub	x3, x3, x8
    db08:	d360fcc9 	lsr	x9, x6, #32
    db0c:	9ac82027 	lsl	x7, x1, x8
    db10:	92407cc5 	and	x5, x6, #0xffffffff
    db14:	9ac32422 	lsr	x2, x1, x3
    db18:	9ac32403 	lsr	x3, x0, x3
    db1c:	aa070063 	orr	x3, x3, x7
    db20:	9ac9084a 	udiv	x10, x2, x9
    db24:	9ac82007 	lsl	x7, x0, x8
    db28:	9b098940 	msub	x0, x10, x9, x2
    db2c:	aa0a03e1 	mov	x1, x10
    db30:	9b0a7ca2 	mul	x2, x5, x10
    db34:	93c38000 	extr	x0, x0, x3, #32
    db38:	eb00005f 	cmp	x2, x0
    db3c:	540000a9 	b.ls	db50 <__divti3+0x2e0>  // b.plast
    db40:	ab0000c0 	adds	x0, x6, x0
    db44:	d1000541 	sub	x1, x10, #0x1
    db48:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    db4c:	54000468 	b.hi	dbd8 <__divti3+0x368>  // b.pmore
    db50:	cb020000 	sub	x0, x0, x2
    db54:	9ac9080a 	udiv	x10, x0, x9
    db58:	9b098140 	msub	x0, x10, x9, x0
    db5c:	aa0a03e2 	mov	x2, x10
    db60:	9b0a7ca8 	mul	x8, x5, x10
    db64:	b3607c03 	bfi	x3, x0, #32, #32
    db68:	eb03011f 	cmp	x8, x3
    db6c:	540000a9 	b.ls	db80 <__divti3+0x310>  // b.plast
    db70:	ab0300c3 	adds	x3, x6, x3
    db74:	d1000542 	sub	x2, x10, #0x1
    db78:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    db7c:	54000288 	b.hi	dbcc <__divti3+0x35c>  // b.pmore
    db80:	cb080063 	sub	x3, x3, x8
    db84:	aa018041 	orr	x1, x2, x1, lsl #32
    db88:	17ffffc2 	b	da90 <__divti3+0x220>
    db8c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    db90:	d2800001 	mov	x1, #0x0                   	// #0
    db94:	9a9f87e0 	cset	x0, ls	// ls = plast
    db98:	17ffff68 	b	d938 <__divti3+0xc8>
    db9c:	aa0103e0 	mov	x0, x1
    dba0:	d2800001 	mov	x1, #0x0                   	// #0
    dba4:	17ffff65 	b	d938 <__divti3+0xc8>
    dba8:	d1000860 	sub	x0, x3, #0x2
    dbac:	8b0600a5 	add	x5, x5, x6
    dbb0:	17ffff52 	b	d8f8 <__divti3+0x88>
    dbb4:	d1000961 	sub	x1, x11, #0x2
    dbb8:	8b0800a5 	add	x5, x5, x8
    dbbc:	17ffff85 	b	d9d0 <__divti3+0x160>
    dbc0:	d1000965 	sub	x5, x11, #0x2
    dbc4:	8b080063 	add	x3, x3, x8
    dbc8:	17ffff8e 	b	da00 <__divti3+0x190>
    dbcc:	d1000942 	sub	x2, x10, #0x2
    dbd0:	8b060063 	add	x3, x3, x6
    dbd4:	17ffffeb 	b	db80 <__divti3+0x310>
    dbd8:	d1000941 	sub	x1, x10, #0x2
    dbdc:	8b060000 	add	x0, x0, x6
    dbe0:	17ffffdc 	b	db50 <__divti3+0x2e0>
    dbe4:	d1000900 	sub	x0, x8, #0x2
    dbe8:	8b060063 	add	x3, x3, x6
    dbec:	17ffffb4 	b	dabc <__divti3+0x24c>

000000000000dbf0 <__modti3>:
    dbf0:	d503245f 	bti	c
    dbf4:	d2800004 	mov	x4, #0x0                   	// #0
    dbf8:	b6f80081 	tbz	x1, #63, dc08 <__modti3+0x18>
    dbfc:	eb0003e0 	negs	x0, x0
    dc00:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    dc04:	da0103e1 	ngc	x1, x1
    dc08:	f100007f 	cmp	x3, #0x0
    dc0c:	5400128b 	b.lt	de5c <__modti3+0x26c>  // b.tstop
    dc10:	aa0003e7 	mov	x7, x0
    dc14:	aa0103e6 	mov	x6, x1
    dc18:	540004e1 	b.ne	dcb4 <__modti3+0xc4>  // b.any
    dc1c:	eb02003f 	cmp	x1, x2
    dc20:	54000dc2 	b.cs	ddd8 <__modti3+0x1e8>  // b.hs, b.nlast
    dc24:	dac01043 	clz	x3, x2
    dc28:	aa0303e5 	mov	x5, x3
    dc2c:	b40000e3 	cbz	x3, dc48 <__modti3+0x58>
    dc30:	4b0303e6 	neg	w6, w3
    dc34:	9ac32021 	lsl	x1, x1, x3
    dc38:	9ac32042 	lsl	x2, x2, x3
    dc3c:	9ac62406 	lsr	x6, x0, x6
    dc40:	aa0100c6 	orr	x6, x6, x1
    dc44:	9ac32007 	lsl	x7, x0, x3
    dc48:	d360fc40 	lsr	x0, x2, #32
    dc4c:	92407c43 	and	x3, x2, #0xffffffff
    dc50:	9ac008c1 	udiv	x1, x6, x0
    dc54:	9b009826 	msub	x6, x1, x0, x6
    dc58:	9b017c61 	mul	x1, x3, x1
    dc5c:	93c780c6 	extr	x6, x6, x7, #32
    dc60:	eb06003f 	cmp	x1, x6
    dc64:	540000a9 	b.ls	dc78 <__modti3+0x88>  // b.plast
    dc68:	ab060046 	adds	x6, x2, x6
    dc6c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    dc70:	8b0200c8 	add	x8, x6, x2
    dc74:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    dc78:	cb0100c6 	sub	x6, x6, x1
    dc7c:	9ac008c8 	udiv	x8, x6, x0
    dc80:	9b009901 	msub	x1, x8, x0, x6
    dc84:	aa0703e0 	mov	x0, x7
    dc88:	9b087c63 	mul	x3, x3, x8
    dc8c:	b3607c20 	bfi	x0, x1, #32, #32
    dc90:	eb00007f 	cmp	x3, x0
    dc94:	54001088 	b.hi	dea4 <__modti3+0x2b4>  // b.pmore
    dc98:	cb030000 	sub	x0, x0, x3
    dc9c:	9ac52400 	lsr	x0, x0, x5
    dca0:	d2800001 	mov	x1, #0x0                   	// #0
    dca4:	b4000064 	cbz	x4, dcb0 <__modti3+0xc0>
    dca8:	eb0003e0 	negs	x0, x0
    dcac:	da0103e1 	ngc	x1, x1
    dcb0:	d65f03c0 	ret
    dcb4:	dac01066 	clz	x6, x3
    dcb8:	eb03003f 	cmp	x1, x3
    dcbc:	54ffff43 	b.cc	dca4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    dcc0:	93407cc5 	sxtw	x5, w6
    dcc4:	d2800808 	mov	x8, #0x40                  	// #64
    dcc8:	cb050108 	sub	x8, x8, x5
    dccc:	9ac62063 	lsl	x3, x3, x6
    dcd0:	9ac62025 	lsl	x5, x1, x6
    dcd4:	9ac82447 	lsr	x7, x2, x8
    dcd8:	aa0300e7 	orr	x7, x7, x3
    dcdc:	9ac82423 	lsr	x3, x1, x8
    dce0:	92407cec 	and	x12, x7, #0xffffffff
    dce4:	d360fcea 	lsr	x10, x7, #32
    dce8:	9ac82401 	lsr	x1, x0, x8
    dcec:	aa050021 	orr	x1, x1, x5
    dcf0:	9ac62042 	lsl	x2, x2, x6
    dcf4:	9ac62000 	lsl	x0, x0, x6
    dcf8:	9aca086b 	udiv	x11, x3, x10
    dcfc:	9b0a8d63 	msub	x3, x11, x10, x3
    dd00:	aa0b03e5 	mov	x5, x11
    dd04:	9b0b7d89 	mul	x9, x12, x11
    dd08:	93c18063 	extr	x3, x3, x1, #32
    dd0c:	eb03013f 	cmp	x9, x3
    dd10:	540000a9 	b.ls	dd24 <__modti3+0x134>  // b.plast
    dd14:	ab0300e3 	adds	x3, x7, x3
    dd18:	d1000565 	sub	x5, x11, #0x1
    dd1c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    dd20:	54001168 	b.hi	df4c <__modti3+0x35c>  // b.pmore
    dd24:	cb090063 	sub	x3, x3, x9
    dd28:	9aca086b 	udiv	x11, x3, x10
    dd2c:	9b0a8d6a 	msub	x10, x11, x10, x3
    dd30:	aa0b03e9 	mov	x9, x11
    dd34:	9b0b7d8c 	mul	x12, x12, x11
    dd38:	b3607d41 	bfi	x1, x10, #32, #32
    dd3c:	eb01019f 	cmp	x12, x1
    dd40:	540000a9 	b.ls	dd54 <__modti3+0x164>  // b.plast
    dd44:	ab0100e1 	adds	x1, x7, x1
    dd48:	d1000569 	sub	x9, x11, #0x1
    dd4c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    dd50:	54000f88 	b.hi	df40 <__modti3+0x350>  // b.pmore
    dd54:	aa058123 	orr	x3, x9, x5, lsl #32
    dd58:	92407c4b 	and	x11, x2, #0xffffffff
    dd5c:	2a0903e9 	mov	w9, w9
    dd60:	d360fc4a 	lsr	x10, x2, #32
    dd64:	d360fc63 	lsr	x3, x3, #32
    dd68:	cb0c0021 	sub	x1, x1, x12
    dd6c:	aa0a03ec 	mov	x12, x10
    dd70:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    dd74:	9b0b7d25 	mul	x5, x9, x11
    dd78:	9b0b7c6b 	mul	x11, x3, x11
    dd7c:	9b0a2d29 	madd	x9, x9, x10, x11
    dd80:	92407caa 	and	x10, x5, #0xffffffff
    dd84:	9b0c7c63 	mul	x3, x3, x12
    dd88:	8b458125 	add	x5, x9, x5, lsr #32
    dd8c:	8b0d0069 	add	x9, x3, x13
    dd90:	eb05017f 	cmp	x11, x5
    dd94:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    dd98:	8b058149 	add	x9, x10, x5, lsl #32
    dd9c:	8b458063 	add	x3, x3, x5, lsr #32
    dda0:	eb03003f 	cmp	x1, x3
    dda4:	54000063 	b.cc	ddb0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    dda8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ddac:	54000082 	b.cs	ddbc <__modti3+0x1cc>  // b.hs, b.nlast
    ddb0:	eb020129 	subs	x9, x9, x2
    ddb4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ddb8:	cb070063 	sub	x3, x3, x7
    ddbc:	eb090000 	subs	x0, x0, x9
    ddc0:	da030021 	sbc	x1, x1, x3
    ddc4:	9ac62400 	lsr	x0, x0, x6
    ddc8:	9ac82028 	lsl	x8, x1, x8
    ddcc:	aa000100 	orr	x0, x8, x0
    ddd0:	9ac62421 	lsr	x1, x1, x6
    ddd4:	17ffffb4 	b	dca4 <__modti3+0xb4>
    ddd8:	b5000062 	cbnz	x2, dde4 <__modti3+0x1f4>
    dddc:	d2800023 	mov	x3, #0x1                   	// #1
    dde0:	9ac20862 	udiv	x2, x3, x2
    dde4:	dac01048 	clz	x8, x2
    dde8:	aa0803e5 	mov	x5, x8
    ddec:	b5000668 	cbnz	x8, deb8 <__modti3+0x2c8>
    ddf0:	cb020020 	sub	x0, x1, x2
    ddf4:	d360fc49 	lsr	x9, x2, #32
    ddf8:	92407c4a 	and	x10, x2, #0xffffffff
    ddfc:	9ac90801 	udiv	x1, x0, x9
    de00:	9b098020 	msub	x0, x1, x9, x0
    de04:	9b0a7c21 	mul	x1, x1, x10
    de08:	93c78000 	extr	x0, x0, x7, #32
    de0c:	eb00003f 	cmp	x1, x0
    de10:	540000a9 	b.ls	de24 <__modti3+0x234>  // b.plast
    de14:	ab000040 	adds	x0, x2, x0
    de18:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    de1c:	8b020003 	add	x3, x0, x2
    de20:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    de24:	cb010001 	sub	x1, x0, x1
    de28:	9ac90820 	udiv	x0, x1, x9
    de2c:	9b098403 	msub	x3, x0, x9, x1
    de30:	aa0703e1 	mov	x1, x7
    de34:	9b0a7c00 	mul	x0, x0, x10
    de38:	b3607c61 	bfi	x1, x3, #32, #32
    de3c:	eb01001f 	cmp	x0, x1
    de40:	540000a9 	b.ls	de54 <__modti3+0x264>  // b.plast
    de44:	ab010041 	adds	x1, x2, x1
    de48:	8b020022 	add	x2, x1, x2
    de4c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    de50:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    de54:	cb000020 	sub	x0, x1, x0
    de58:	17ffff91 	b	dc9c <__modti3+0xac>
    de5c:	eb0203e5 	negs	x5, x2
    de60:	aa0003e7 	mov	x7, x0
    de64:	da0303e8 	ngc	x8, x3
    de68:	aa0503e2 	mov	x2, x5
    de6c:	aa0803e3 	mov	x3, x8
    de70:	aa0103e6 	mov	x6, x1
    de74:	b4ffed48 	cbz	x8, dc1c <__modti3+0x2c>
    de78:	eb01011f 	cmp	x8, x1
    de7c:	54fff148 	b.hi	dca4 <__modti3+0xb4>  // b.pmore
    de80:	dac01109 	clz	x9, x8
    de84:	2a0903e6 	mov	w6, w9
    de88:	b5fff1c9 	cbnz	x9, dcc0 <__modti3+0xd0>
    de8c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    de90:	54000068 	b.hi	de9c <__modti3+0x2ac>  // b.pmore
    de94:	eb050007 	subs	x7, x0, x5
    de98:	da080021 	sbc	x1, x1, x8
    de9c:	aa0703e0 	mov	x0, x7
    dea0:	17ffff81 	b	dca4 <__modti3+0xb4>
    dea4:	ab000040 	adds	x0, x2, x0
    dea8:	8b020002 	add	x2, x0, x2
    deac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    deb0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    deb4:	17ffff79 	b	dc98 <__modti3+0xa8>
    deb8:	9ac82042 	lsl	x2, x2, x8
    debc:	d2800803 	mov	x3, #0x40                  	// #64
    dec0:	cb080063 	sub	x3, x3, x8
    dec4:	d360fc49 	lsr	x9, x2, #32
    dec8:	9ac82027 	lsl	x7, x1, x8
    decc:	92407c4a 	and	x10, x2, #0xffffffff
    ded0:	9ac32426 	lsr	x6, x1, x3
    ded4:	9ac32403 	lsr	x3, x0, x3
    ded8:	aa070063 	orr	x3, x3, x7
    dedc:	9ac908c1 	udiv	x1, x6, x9
    dee0:	9ac82007 	lsl	x7, x0, x8
    dee4:	9b099820 	msub	x0, x1, x9, x6
    dee8:	9b017d41 	mul	x1, x10, x1
    deec:	93c38000 	extr	x0, x0, x3, #32
    def0:	eb00003f 	cmp	x1, x0
    def4:	540000a9 	b.ls	df08 <__modti3+0x318>  // b.plast
    def8:	ab000040 	adds	x0, x2, x0
    defc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    df00:	8b020006 	add	x6, x0, x2
    df04:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    df08:	cb010000 	sub	x0, x0, x1
    df0c:	9ac90801 	udiv	x1, x0, x9
    df10:	9b098026 	msub	x6, x1, x9, x0
    df14:	aa0303e0 	mov	x0, x3
    df18:	9b017d41 	mul	x1, x10, x1
    df1c:	b3607cc0 	bfi	x0, x6, #32, #32
    df20:	eb00003f 	cmp	x1, x0
    df24:	540000a9 	b.ls	df38 <__modti3+0x348>  // b.plast
    df28:	ab000040 	adds	x0, x2, x0
    df2c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    df30:	8b020003 	add	x3, x0, x2
    df34:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    df38:	cb010000 	sub	x0, x0, x1
    df3c:	17ffffb0 	b	ddfc <__modti3+0x20c>
    df40:	d1000969 	sub	x9, x11, #0x2
    df44:	8b070021 	add	x1, x1, x7
    df48:	17ffff83 	b	dd54 <__modti3+0x164>
    df4c:	d1000965 	sub	x5, x11, #0x2
    df50:	8b070063 	add	x3, x3, x7
    df54:	17ffff74 	b	dd24 <__modti3+0x134>
    df58:	d503201f 	nop
    df5c:	d503201f 	nop

000000000000df60 <atexit>:
    df60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    df64:	f0000102 	adrp	x2, 30000 <__data_start>
    df68:	d2800001 	mov	x1, #0x0                   	// #0
    df6c:	910003fd 	mov	x29, sp
    df70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    df74:	f9400442 	ldr	x2, [x2, #8]
    df78:	17ffd1e6 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000df7c <_fini>:
    df7c:	d503201f 	nop
    df80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    df84:	910003fd 	mov	x29, sp
    df88:	a8c17bfd 	ldp	x29, x30, [sp], #16
    df8c:	d65f03c0 	ret
